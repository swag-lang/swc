# Handling the bundle

The root README describes the sample project. Data files use UTF-8 and comma-separated
values. Folder names are kept in the archive so a reader can browse the original hierarchy.
