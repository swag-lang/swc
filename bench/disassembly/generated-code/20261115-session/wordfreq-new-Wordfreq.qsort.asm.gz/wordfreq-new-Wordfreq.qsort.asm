
/workspace/prompt2-20261115/session-combined-micro/new/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

00000000004072f0 <__swc_fn_4fa09e82_000003_6937fe70>:
  4072f0:	push   rsi
  4072f1:	push   rdi
  4072f2:	push   r12
  4072f4:	push   r13
  4072f6:	push   r14
  4072f8:	push   r15
  4072fa:	sub    rsp,0xd8
  407301:	mov    rsi,rdx
  407304:	mov    QWORD PTR [rsp+0x88],rdx
  40730c:	mov    rdi,rcx
  40730f:	cmp    rdi,rsi
  407312:	jge    407529 <__swc_fn_4fa09e82_000003_6937fe70+0x239>
  407318:	nop    DWORD PTR [rax+rax*1+0x0]
  407320:	lea    rax,[rdi+rsi*1]
  407324:	mov    rcx,rax
  407327:	shr    rax,0x3f
  40732b:	add    rcx,rax
  40732e:	sar    rcx,1
  407331:	mov    rax,QWORD PTR [rip+0x1cd10]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  407338:	mov    r12,QWORD PTR [rax+rcx*8]
  40733c:	mov    r13,rdi
  40733f:	mov    QWORD PTR [rsp+0x90],rdi
  407347:	mov    r14,rsi
  40734a:	nop    WORD PTR [rax+rax*1+0x0]
  407350:	cmp    r13,r14
  407353:	jle    407360 <__swc_fn_4fa09e82_000003_6937fe70+0x70>
  407355:	mov    rax,r13
  407358:	mov    r13,r14
  40735b:	jmp    407505 <__swc_fn_4fa09e82_000003_6937fe70+0x215>
  407360:	mov    r15,QWORD PTR [rip+0x1cce1]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  407367:	mov    rsi,QWORD PTR [rip+0x1cce2]        # 424050 <__swc_bss_base_4fa09e82+0x10>
  40736e:	mov    QWORD PTR [rsp+0xa8],rsi
  407376:	mov    rdi,QWORD PTR [rsi+r12*8]
  40737a:	mov    QWORD PTR [rsp+0xa0],r14
  407382:	mov    r14,QWORD PTR [rip+0x1cccf]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  407389:	mov    rax,QWORD PTR [rip+0x1ccd0]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  407390:	mov    QWORD PTR [rsp+0xb0],rax
  407398:	mov    r9,QWORD PTR [rip+0x1ccc9]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40739f:	mov    QWORD PTR [rsp+0xb8],r9
  4073a7:	nop    WORD PTR [rax+rax*1+0x0]
  4073b0:	mov    r10,QWORD PTR [r15+r13*8]
  4073b4:	cmp    QWORD PTR [rsi+r10*8],rdi
  4073b8:	je     4073be <__swc_fn_4fa09e82_000003_6937fe70+0xce>
  4073ba:	ja     40740d <__swc_fn_4fa09e82_000003_6937fe70+0x11d>
  4073bc:	jmp    407412 <__swc_fn_4fa09e82_000003_6937fe70+0x122>
  4073be:	mov    rcx,QWORD PTR [r14+r10*8]
  4073c2:	mov    r8,QWORD PTR [r14+r12*8]
  4073c6:	cmp    r8,rcx
  4073c9:	cmovae r8,rcx
  4073cd:	mov    rcx,QWORD PTR [rax+r10*8]
  4073d1:	add    rcx,r9
  4073d4:	mov    rdx,QWORD PTR [rax+r12*8]
  4073d8:	add    rdx,r9
  4073db:	mov    rsi,r10
  4073de:	call   40cb70 <__swc_fn_4fa09e82_000112_3dc01326>
  4073e3:	test   eax,eax
  4073e5:	je     4073eb <__swc_fn_4fa09e82_000003_6937fe70+0xfb>
  4073e7:	jl     4073f5 <__swc_fn_4fa09e82_000003_6937fe70+0x105>
  4073e9:	jmp    407412 <__swc_fn_4fa09e82_000003_6937fe70+0x122>
  4073eb:	mov    rax,QWORD PTR [r14+r12*8]
  4073ef:	cmp    QWORD PTR [r14+rsi*8],rax
  4073f3:	jae    407412 <__swc_fn_4fa09e82_000003_6937fe70+0x122>
  4073f5:	mov    rsi,QWORD PTR [rsp+0xa8]
  4073fd:	mov    rax,QWORD PTR [rsp+0xb0]
  407405:	mov    r9,QWORD PTR [rsp+0xb8]
  40740d:	inc    r13
  407410:	jmp    4073b0 <__swc_fn_4fa09e82_000003_6937fe70+0xc0>
  407412:	mov    rsi,QWORD PTR [rip+0x1cc2f]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  407419:	mov    QWORD PTR [rsp+0xc0],rsi
  407421:	mov    rdi,QWORD PTR [rip+0x1cc28]        # 424050 <__swc_bss_base_4fa09e82+0x10>
  407428:	mov    r14,QWORD PTR [rip+0x1cc29]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40742f:	mov    r15,QWORD PTR [rip+0x1cc2a]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  407436:	mov    QWORD PTR [rsp+0x98],r13
  40743e:	mov    r13,QWORD PTR [rsp+0xa0]
  407446:	mov    rax,QWORD PTR [rip+0x1cc1b]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40744d:	mov    QWORD PTR [rsp+0xc8],rax
  407455:	cs nop WORD PTR [rax+rax*1+0x0]
  40745f:	nop
  407460:	mov    r9,QWORD PTR [rsi+r13*8]
  407464:	mov    rcx,QWORD PTR [rdi+r9*8]
  407468:	cmp    QWORD PTR [rdi+r12*8],rcx
  40746c:	je     407472 <__swc_fn_4fa09e82_000003_6937fe70+0x182>
  40746e:	ja     4074b9 <__swc_fn_4fa09e82_000003_6937fe70+0x1c9>
  407470:	jmp    4074be <__swc_fn_4fa09e82_000003_6937fe70+0x1ce>
  407472:	mov    rcx,QWORD PTR [r14+r12*8]
  407476:	mov    r8,QWORD PTR [r14+r9*8]
  40747a:	cmp    r8,rcx
  40747d:	cmovae r8,rcx
  407481:	mov    rcx,QWORD PTR [r15+r12*8]
  407485:	add    rcx,rax
  407488:	mov    rdx,QWORD PTR [r15+r9*8]
  40748c:	add    rdx,rax
  40748f:	mov    rsi,r9
  407492:	call   40cb70 <__swc_fn_4fa09e82_000112_3dc01326>
  407497:	test   eax,eax
  407499:	je     40749f <__swc_fn_4fa09e82_000003_6937fe70+0x1af>
  40749b:	jl     4074a9 <__swc_fn_4fa09e82_000003_6937fe70+0x1b9>
  40749d:	jmp    4074be <__swc_fn_4fa09e82_000003_6937fe70+0x1ce>
  40749f:	mov    rax,QWORD PTR [r14+rsi*8]
  4074a3:	cmp    QWORD PTR [r14+r12*8],rax
  4074a7:	jae    4074be <__swc_fn_4fa09e82_000003_6937fe70+0x1ce>
  4074a9:	mov    rsi,QWORD PTR [rsp+0xc0]
  4074b1:	mov    rax,QWORD PTR [rsp+0xc8]
  4074b9:	dec    r13
  4074bc:	jmp    407460 <__swc_fn_4fa09e82_000003_6937fe70+0x170>
  4074be:	mov    rax,QWORD PTR [rsp+0x98]
  4074c6:	cmp    rax,r13
  4074c9:	jle    4074d6 <__swc_fn_4fa09e82_000003_6937fe70+0x1e6>
  4074cb:	mov    r14,r13
  4074ce:	mov    r13,rax
  4074d1:	jmp    407350 <__swc_fn_4fa09e82_000003_6937fe70+0x60>
  4074d6:	mov    rcx,QWORD PTR [rip+0x1cb6b]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  4074dd:	mov    rdx,QWORD PTR [rcx+rax*8]
  4074e1:	mov    r8,QWORD PTR [rcx+r13*8]
  4074e5:	mov    QWORD PTR [rcx+rax*8],r8
  4074e9:	mov    rcx,QWORD PTR [rip+0x1cb58]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  4074f0:	mov    QWORD PTR [rcx+r13*8],rdx
  4074f4:	inc    rax
  4074f7:	dec    r13
  4074fa:	mov    r14,r13
  4074fd:	mov    r13,rax
  407500:	jmp    407350 <__swc_fn_4fa09e82_000003_6937fe70+0x60>
  407505:	mov    rcx,QWORD PTR [rsp+0x90]
  40750d:	mov    rdx,r13
  407510:	mov    rdi,rax
  407513:	call   4072f0 <__swc_fn_4fa09e82_000003_6937fe70>
  407518:	mov    rsi,QWORD PTR [rsp+0x88]
  407520:	cmp    rdi,rsi
  407523:	jl     407320 <__swc_fn_4fa09e82_000003_6937fe70+0x30>
  407529:	add    rsp,0xd8
  407530:	pop    r15
  407532:	pop    r14
  407534:	pop    r13
  407536:	pop    r12
  407538:	pop    rdi
  407539:	pop    rsi
  40753a:	ret
