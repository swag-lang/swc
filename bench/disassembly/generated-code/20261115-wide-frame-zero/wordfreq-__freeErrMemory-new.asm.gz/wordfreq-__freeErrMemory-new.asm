
/workspace/prompt2-20261115/batch5-final-micro/new/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

000000000040f4c0 <__swc_fn_4fa09e82_000101_d4bdcaa4>:
  40f4c0:	push   rbx
  40f4c1:	sub    rsp,0x70
  40f4c5:	vxorps xmm0,xmm0,xmm0
  40f4c9:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40f4cf:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40f4d5:	vzeroupper
  40f4d8:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40f4de:	mov    QWORD PTR [rsp+0x48],rdx
  40f4e3:	mov    rax,r8
  40f4e6:	cmp    r8,0x1
  40f4ea:	mov    edx,0x1
  40f4ef:	cmovb  rax,rdx
  40f4f3:	mov    QWORD PTR [rsp+0x50],rax
  40f4f8:	mov    rbx,QWORD PTR [rcx+0x8]
  40f4fc:	mov    rbx,QWORD PTR [rbx+0x18]
  40f500:	mov    rcx,QWORD PTR [rcx]
  40f503:	lea    rdx,[rsp+0x8]
  40f508:	call   rbx
  40f50a:	add    rsp,0x70
  40f50e:	pop    rbx
  40f50f:	ret
