#global private
alias U32x8 = #simd [8] u32

#[Swag.NoInline]
func dynamic(first, second: const *U32x8, indices: const *U32x8, output: *U32x8)
{
    output[] = Swag.vecShuffle2(first[], second[], indices[])
}

#main
{
    var first  = [11'u32, 22, 33, 44, 55, 66, 77, 88]
    var second = [13'u32, 23, 37, 41, 59, 61, 79, 83]
    let a = cast(const *U32x8, &first)[]
    let b = cast(const *U32x8, &second)[]
    var output: [8] u32
    let outVec = cast(*U32x8, &output)

    scope
    {
        const Indices = cast(U32x8, [0'u32, 8, 1, 9, 4, 12, 5, 13])
        const Expected = [11'u32, 13, 22, 23, 55, 59, 66, 61]
        outVec[] = Swag.vecShuffle2(a, b, Indices)
        for lane in 8 do
            Swag.require(output[lane] == Expected[lane], "unpack32Lo")
    }

    scope
    {
        const Indices = cast(U32x8, [2'u32, 10, 3, 11, 6, 14, 7, 15])
        const Expected = [33'u32, 37, 44, 41, 77, 79, 88, 83]
        outVec[] = Swag.vecShuffle2(a, b, Indices)
        for lane in 8 do
            Swag.require(output[lane] == Expected[lane], "unpack32Hi")
    }

    scope
    {
        const Indices = cast(U32x8, [0'u32, 1, 8, 9, 4, 5, 12, 13])
        const Expected = [11'u32, 22, 13, 23, 55, 66, 59, 61]
        outVec[] = Swag.vecShuffle2(a, b, Indices)
        for lane in 8 do
            Swag.require(output[lane] == Expected[lane], "unpack64Lo")
    }

    scope
    {
        const Indices = cast(U32x8, [2'u32, 3, 10, 11, 6, 7, 14, 15])
        const Expected = [33'u32, 44, 37, 41, 77, 88, 79, 83]
        outVec[] = Swag.vecShuffle2(a, b, Indices)
        for lane in 8 do
            Swag.require(output[lane] == Expected[lane], "unpack64Hi")
    }

    scope
    {
        const Indices = cast(U32x8, [0'u32, 1, 2, 3, 8, 9, 10, 11])
        const Expected = [11'u32, 22, 33, 44, 13, 23, 37, 41]
        outVec[] = Swag.vecShuffle2(a, b, Indices)
        for lane in 8 do
            Swag.require(output[lane] == Expected[lane], "permute128Lo")
    }

    scope
    {
        const Indices = cast(U32x8, [4'u32, 5, 6, 7, 12, 13, 14, 15])
        const Expected = [55'u32, 66, 77, 88, 59, 61, 79, 83]
        outVec[] = Swag.vecShuffle2(a, b, Indices)
        for lane in 8 do
            Swag.require(output[lane] == Expected[lane], "permute128Hi")
    }

    scope
    {
        const Indices = cast(U32x8, [3'u32, 12, 14, 5, 9, 0, 15, 7])
        const Expected = [44'u32, 59, 79, 66, 23, 11, 83, 88]
        outVec[] = Swag.vecShuffle2(a, b, Indices)
        for lane in 8 do
            Swag.require(output[lane] == Expected[lane], "constantMixed")
    }

    var indices = [0x33'u32, 0x2C, 0x1E, 0x15, 0x99, 0x80, 0x3F, 0xB7]
    dynamic(cast(const *U32x8, &first), cast(const *U32x8, &second), cast(const *U32x8, &indices), outVec)
    const Expected = [44'u32, 59, 79, 66, 23, 11, 83, 88]
    for lane in 8 do
        Swag.require(output[lane] == Expected[lane], "dynamic pattern")
}
