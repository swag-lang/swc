
/workspace/prompt2-20261115/batch2-final-micro/base/binarytrees/binarytrees:     file format elf64-x86-64


Disassembly of section .text:

000000000040d650 <__swc_fn_7dafa2b1_000175_82999b37>:
  40d650:	push   rbx
  40d651:	push   rsi
  40d652:	sub    rsp,0x68
  40d656:	mov    rbx,rcx
  40d659:	lea    rsi,[rsp+0x8]
  40d65e:	vxorps xmm0,xmm0,xmm0
  40d662:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40d668:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40d66e:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40d674:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40d67a:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40d680:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40d686:	mov    QWORD PTR [rsp+0x50],0x20
  40d68f:	mov    DWORD PTR [rsp+0x60],0x10
  40d697:	mov    rcx,QWORD PTR [rip+0x186a2]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40d69e:	test   rcx,rcx
  40d6a1:	jne    40d6b3 <__swc_fn_7dafa2b1_000175_82999b37+0x63>
  40d6a3:	call   40a1d0 <__swc_fn_7dafa2b1_000165_e7009868>
  40d6a8:	lea    rcx,[rax+0x1]
  40d6ac:	mov    QWORD PTR [rip+0x1868d],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40d6b3:	dec    rcx
  40d6b6:	call   4119a0 <__swc_fn_7dafa2b1_000167_2eeacd5f>
  40d6bb:	mov    rcx,QWORD PTR [rax]
  40d6be:	mov    rdx,rsi
  40d6c1:	mov    rsi,QWORD PTR [rax+0x8]
  40d6c5:	mov    rsi,QWORD PTR [rsi+0x8]
  40d6c9:	call   rsi
  40d6cb:	mov    rax,QWORD PTR [rsp+0x48]
  40d6d0:	test   rax,rax
  40d6d3:	jne    40d6d9 <__swc_fn_7dafa2b1_000175_82999b37+0x89>
  40d6d5:	xor    esi,esi
  40d6d7:	jmp    40d6ed <__swc_fn_7dafa2b1_000175_82999b37+0x9d>
  40d6d9:	mov    rcx,QWORD PTR [rsp+0x50]
  40d6de:	mov    QWORD PTR [rax],rcx
  40d6e1:	mov    QWORD PTR [rax+0x8],0x0
  40d6e9:	lea    rsi,[rax+0x10]
  40d6ed:	test   ebx,ebx
  40d6ef:	jle    40d70a <__swc_fn_7dafa2b1_000175_82999b37+0xba>
  40d6f1:	dec    ebx
  40d6f3:	mov    ecx,ebx
  40d6f5:	call   40d650 <__swc_fn_7dafa2b1_000175_82999b37>
  40d6fa:	mov    QWORD PTR [rsi],rax
  40d6fd:	mov    ecx,ebx
  40d6ff:	call   40d650 <__swc_fn_7dafa2b1_000175_82999b37>
  40d704:	mov    QWORD PTR [rsi+0x8],rax
  40d708:	jmp    40d712 <__swc_fn_7dafa2b1_000175_82999b37+0xc2>
  40d70a:	vxorps xmm0,xmm0,xmm0
  40d70e:	vmovdqu XMMWORD PTR [rsi],xmm0
  40d712:	mov    rax,rsi
  40d715:	add    rsp,0x68
  40d719:	pop    rsi
  40d71a:	pop    rbx
  40d71b:	ret
