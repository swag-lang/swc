
/workspace/prompt2-20261115/batch1-micro/new/leven/leven:     file format elf64-x86-64


Disassembly of section .text:

000000000040d720 <__swc_fn_fc36583a_000002_aa67484d>:
  40d720:	push   rbp
  40d721:	push   rbx
  40d722:	push   r15
  40d724:	push   rsi
  40d725:	push   rdi
  40d726:	push   r12
  40d728:	push   r14
  40d72a:	push   r13
  40d72c:	sub    rsp,0x10
  40d730:	mov    rbp,rsp
  40d733:	vmovups XMMWORD PTR [rsp],xmm6
  40d738:	sub    rsp,0x610
  40d73f:	mov    rbx,rsp
  40d742:	mov    ecx,0x17700
  40d747:	sub    rsp,0x8
  40d74b:	call   407270 <__swc_fn_fc36583a_000000_2744b483>
  40d750:	add    rsp,0x8
  40d754:	mov    QWORD PTR [rip+0x168ed],rax        # 424048 <__swc_bss_base_fc36583a+0x8>
  40d75b:	mov    ecx,0xbb80
  40d760:	sub    rsp,0x8
  40d764:	call   407270 <__swc_fn_fc36583a_000000_2744b483>
  40d769:	add    rsp,0x8
  40d76d:	mov    QWORD PTR [rip+0x168dc],rax        # 424050 <__swc_bss_base_fc36583a+0x10>
  40d774:	mov    ecx,0xbb80
  40d779:	sub    rsp,0x8
  40d77d:	call   407270 <__swc_fn_fc36583a_000000_2744b483>
  40d782:	add    rsp,0x8
  40d786:	mov    QWORD PTR [rip+0x168cb],rax        # 424058 <__swc_bss_base_fc36583a+0x18>
  40d78d:	xor    ecx,ecx
  40d78f:	xor    r8d,r8d
  40d792:	cs nop WORD PTR [rax+rax*1+0x0]
  40d79c:	cs nop WORD PTR [rax+rax*1+0x0]
  40d7a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40d7b0:	lea    r9,[r8+0x1]
  40d7b4:	mov    r10,r9
  40d7b7:	movabs rdx,0x2492492492492493
  40d7c1:	mov    r15,rax
  40d7c4:	mov    rax,r8
  40d7c7:	mul    rdx
  40d7ca:	mov    r11,rdx
  40d7cd:	mov    rax,r15
  40d7d0:	mov    rdx,r8
  40d7d3:	sub    rdx,r11
  40d7d6:	shr    rdx,1
  40d7d9:	add    rdx,r11
  40d7dc:	shr    rdx,0x2
  40d7e0:	imul   r11,rdx,0x7
  40d7e4:	mov    rdx,r8
  40d7e7:	sub    rdx,r11
  40d7ea:	lea    r11,[rdx+0x4]
  40d7ee:	mov    rdx,QWORD PTR [rip+0x1685b]        # 424050 <__swc_bss_base_fc36583a+0x10>
  40d7f5:	mov    QWORD PTR [rdx+r8*8],rcx
  40d7f9:	mov    rdx,QWORD PTR [rip+0x16858]        # 424058 <__swc_bss_base_fc36583a+0x18>
  40d800:	mov    QWORD PTR [rdx+r8*8],r11
  40d804:	xor    r8d,r8d
  40d807:	test   r11,r11
  40d80a:	jbe    40d874 <__swc_fn_fc36583a_000002_aa67484d+0x154>
  40d810:	xor    esi,esi
  40d812:	mov    rdi,QWORD PTR [rip+0x1682f]        # 424048 <__swc_bss_base_fc36583a+0x8>
  40d819:	cs nop WORD PTR [rax+rax*1+0x0]
  40d823:	cs nop WORD PTR [rax+rax*1+0x0]
  40d82d:	nop    DWORD PTR [rax]
  40d830:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40d83a:	mov    r15,rax
  40d83d:	mov    rax,r10
  40d840:	mul    rdx
  40d843:	mov    r12,rdx
  40d846:	mov    rax,r15
  40d849:	shr    r12,0x3
  40d84d:	imul   r12,r12,0x1a
  40d851:	sub    r10,r12
  40d854:	lea    r10,[r10+0x61]
  40d858:	mov    BYTE PTR [rdi+rcx*1],r10b
  40d85c:	inc    rcx
  40d85f:	shr    rdx,0x3
  40d863:	lea    r10,[rdx+rsi*1]
  40d867:	add    r8,0x1
  40d86b:	add    rsi,0x7
  40d86f:	cmp    r8,r11
  40d872:	jb     40d830 <__swc_fn_fc36583a_000002_aa67484d+0x110>
  40d874:	mov    r8,r9
  40d877:	cmp    r9,0x1770
  40d87e:	jb     40d7b0 <__swc_fn_fc36583a_000002_aa67484d+0x90>
  40d884:	mov    ecx,0x500
  40d889:	sub    rsp,0x8
  40d88d:	call   407270 <__swc_fn_fc36583a_000000_2744b483>
  40d892:	add    rsp,0x8
  40d896:	mov    QWORD PTR [rip+0x167c3],rax        # 424060 <__swc_bss_base_fc36583a+0x20>
  40d89d:	mov    ecx,0x140
  40d8a2:	sub    rsp,0x8
  40d8a6:	call   407270 <__swc_fn_fc36583a_000000_2744b483>
  40d8ab:	add    rsp,0x8
  40d8af:	mov    QWORD PTR [rip+0x167b2],rax        # 424068 <__swc_bss_base_fc36583a+0x28>
  40d8b6:	mov    ecx,0x140
  40d8bb:	sub    rsp,0x8
  40d8bf:	call   407270 <__swc_fn_fc36583a_000000_2744b483>
  40d8c4:	add    rsp,0x8
  40d8c8:	mov    QWORD PTR [rip+0x167a1],rax        # 424070 <__swc_bss_base_fc36583a+0x30>
  40d8cf:	xor    ecx,ecx
  40d8d1:	xor    r8d,r8d
  40d8d4:	lea    r9,[rbx+0x68]
  40d8d8:	vxorps xmm0,xmm0,xmm0
  40d8dc:	cs nop WORD PTR [rax+rax*1+0x0]
  40d8e6:	cs nop WORD PTR [rax+rax*1+0x0]
  40d8f0:	vmovups XMMWORD PTR [rbx+0x68],xmm0
  40d8f5:	vmovups XMMWORD PTR [rbx+0x78],xmm0
  40d8fa:	mov    r10,QWORD PTR [rip+0x146ff]        # 422000 <__swc_data_base_fc36583a>
  40d901:	imul   r10,r10,0x41a7
  40d908:	movabs rdx,0x200000005
  40d912:	mov    r15,rax
  40d915:	mov    rax,r10
  40d918:	mul    rdx
  40d91b:	mov    r11,rdx
  40d91e:	mov    rdx,r10
  40d921:	sub    rdx,r11
  40d924:	shr    rdx,1
  40d927:	add    rdx,r11
  40d92a:	shr    rdx,0x1e
  40d92e:	imul   r11,rdx,0x7fffffff
  40d935:	sub    r10,r11
  40d938:	mov    QWORD PTR [rip+0x146c1],r10        # 422000 <__swc_data_base_fc36583a>
  40d93f:	movabs rdx,0xaec33e1f671529a5
  40d949:	mov    rax,r10
  40d94c:	mul    rdx
  40d94f:	mov    rax,r15
  40d952:	shr    rdx,0xc
  40d956:	imul   rdx,rdx,0x1770
  40d95d:	sub    r10,rdx
  40d960:	mov    rdx,QWORD PTR [rip+0x166f1]        # 424058 <__swc_bss_base_fc36583a+0x18>
  40d967:	mov    rdx,QWORD PTR [rdx+r10*8]
  40d96b:	mov    r11,rdx
  40d96e:	xor    esi,esi
  40d970:	test   rdx,rdx
  40d973:	jbe    40d9a8 <__swc_fn_fc36583a_000002_aa67484d+0x288>
  40d975:	mov    rdi,QWORD PTR [rip+0x166d4]        # 424050 <__swc_bss_base_fc36583a+0x10>
  40d97c:	mov    r12,QWORD PTR [rip+0x166c5]        # 424048 <__swc_bss_base_fc36583a+0x8>
  40d983:	cs nop WORD PTR [rax+rax*1+0x0]
  40d98d:	nop    DWORD PTR [rax]
  40d990:	mov    r13,QWORD PTR [rdi+r10*8]
  40d994:	add    r13,rsi
  40d997:	mov    r13b,BYTE PTR [r12+r13*1]
  40d99b:	mov    BYTE PTR [r9+rsi*1],r13b
  40d99f:	add    rsi,0x1
  40d9a3:	cmp    rsi,rdx
  40d9a6:	jb     40d990 <__swc_fn_fc36583a_000002_aa67484d+0x270>
  40d9a8:	xor    r10d,r10d
  40d9ab:	nop    DWORD PTR [rax+rax*1+0x0]
  40d9b0:	mov    rsi,QWORD PTR [rip+0x14649]        # 422000 <__swc_data_base_fc36583a>
  40d9b7:	imul   rsi,rsi,0x41a7
  40d9be:	movabs r12,0x200000005
  40d9c8:	mov    r14,rax
  40d9cb:	mov    rax,rsi
  40d9ce:	mul    r12
  40d9d1:	mov    r12,rsi
  40d9d4:	sub    r12,rdx
  40d9d7:	shr    r12,1
  40d9da:	add    r12,rdx
  40d9dd:	shr    r12,0x1e
  40d9e1:	imul   rdi,r12,0x7fffffff
  40d9e8:	sub    rsi,rdi
  40d9eb:	mov    QWORD PTR [rip+0x1460e],rsi        # 422000 <__swc_data_base_fc36583a>
  40d9f2:	mov    rax,rsi
  40d9f5:	xor    edx,edx
  40d9f7:	div    r11
  40d9fa:	mov    rax,rdx
  40d9fd:	mov    r12,rax
  40da00:	imul   rsi,rsi,0x41a7
  40da07:	movabs rdx,0x200000005
  40da11:	mov    r15,r14
  40da14:	mov    rax,rsi
  40da17:	mul    rdx
  40da1a:	mov    rdi,rdx
  40da1d:	mov    rdx,rsi
  40da20:	sub    rdx,rdi
  40da23:	shr    rdx,1
  40da26:	add    rdx,rdi
  40da29:	shr    rdx,0x1e
  40da2d:	imul   rdi,rdx,0x7fffffff
  40da34:	sub    rsi,rdi
  40da37:	mov    QWORD PTR [rip+0x145c2],rsi        # 422000 <__swc_data_base_fc36583a>
  40da3e:	movabs rdx,0xaaaaaaaaaaaaaaab
  40da48:	mov    rax,rsi
  40da4b:	mul    rdx
  40da4e:	shr    rdx,1
  40da51:	lea    rdx,[rdx+rdx*2]
  40da55:	mov    r13,rsi
  40da58:	sub    r13,rdx
  40da5b:	imul   rsi,rsi,0x41a7
  40da62:	movabs rdx,0x200000005
  40da6c:	mov    rax,rsi
  40da6f:	mul    rdx
  40da72:	mov    rdi,rdx
  40da75:	mov    rdx,rsi
  40da78:	sub    rdx,rdi
  40da7b:	shr    rdx,1
  40da7e:	add    rdx,rdi
  40da81:	shr    rdx,0x1e
  40da85:	imul   rdi,rdx,0x7fffffff
  40da8c:	sub    rsi,rdi
  40da8f:	mov    QWORD PTR [rip+0x1456a],rsi        # 422000 <__swc_data_base_fc36583a>
  40da96:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40daa0:	mov    rax,rsi
  40daa3:	mul    rdx
  40daa6:	mov    rax,r15
  40daa9:	shr    rdx,0x3
  40daad:	imul   rdx,rdx,0x1a
  40dab1:	sub    rsi,rdx
  40dab4:	lea    rdx,[rsi+0x61]
  40dab8:	test   r13,r13
  40dabb:	jne    40dac6 <__swc_fn_fc36583a_000002_aa67484d+0x3a6>
  40dabd:	mov    BYTE PTR [r9+r12*1],dl
  40dac1:	jmp    40db39 <__swc_fn_fc36583a_000002_aa67484d+0x419>
  40dac6:	cmp    r13,0x1
  40daca:	jne    40dafa <__swc_fn_fc36583a_000002_aa67484d+0x3da>
  40dacc:	cmp    r11,0x2
  40dad0:	jbe    40db39 <__swc_fn_fc36583a_000002_aa67484d+0x419>
  40dad6:	lea    rdx,[r12+0x1]
  40dadb:	cmp    rdx,r11
  40dade:	jae    40daf4 <__swc_fn_fc36583a_000002_aa67484d+0x3d4>
  40dae0:	mov    sil,BYTE PTR [r9+r12*1+0x1]
  40dae5:	mov    BYTE PTR [r9+r12*1],sil
  40dae9:	mov    r12,rdx
  40daec:	inc    rdx
  40daef:	cmp    rdx,r11
  40daf2:	jb     40dae0 <__swc_fn_fc36583a_000002_aa67484d+0x3c0>
  40daf4:	sub    r11,0x1
  40daf8:	jmp    40db39 <__swc_fn_fc36583a_000002_aa67484d+0x419>
  40dafa:	mov    rsi,r11
  40dafd:	cmp    rsi,r12
  40db00:	jbe    40db31 <__swc_fn_fc36583a_000002_aa67484d+0x411>
  40db02:	cs nop WORD PTR [rax+rax*1+0x0]
  40db0c:	cs nop WORD PTR [rax+rax*1+0x0]
  40db16:	cs nop WORD PTR [rax+rax*1+0x0]
  40db20:	mov    dil,BYTE PTR [r9+rsi*1-0x1]
  40db25:	mov    BYTE PTR [r9+rsi*1],dil
  40db29:	dec    rsi
  40db2c:	cmp    rsi,r12
  40db2f:	ja     40db20 <__swc_fn_fc36583a_000002_aa67484d+0x400>
  40db31:	mov    BYTE PTR [r9+r12*1],dl
  40db35:	add    r11,0x1
  40db39:	add    r10,0x1
  40db3d:	cmp    r10,0x2
  40db41:	jb     40d9b0 <__swc_fn_fc36583a_000002_aa67484d+0x290>
  40db47:	mov    rdx,QWORD PTR [rip+0x1651a]        # 424068 <__swc_bss_base_fc36583a+0x28>
  40db4e:	mov    QWORD PTR [rdx+r8*8],rcx
  40db52:	mov    rdx,QWORD PTR [rip+0x16517]        # 424070 <__swc_bss_base_fc36583a+0x30>
  40db59:	mov    QWORD PTR [rdx+r8*8],r11
  40db5d:	xor    edx,edx
  40db5f:	test   r11,r11
  40db62:	jbe    40db94 <__swc_fn_fc36583a_000002_aa67484d+0x474>
  40db64:	mov    r10,QWORD PTR [rip+0x164f5]        # 424060 <__swc_bss_base_fc36583a+0x20>
  40db6b:	cs nop WORD PTR [rax+rax*1+0x0]
  40db75:	cs nop WORD PTR [rax+rax*1+0x0]
  40db7f:	nop
  40db80:	mov    sil,BYTE PTR [r9+rdx*1]
  40db84:	mov    BYTE PTR [r10+rcx*1],sil
  40db88:	inc    rcx
  40db8b:	add    rdx,0x1
  40db8f:	cmp    rdx,r11
  40db92:	jb     40db80 <__swc_fn_fc36583a_000002_aa67484d+0x460>
  40db94:	add    r8,0x1
  40db98:	cmp    r8,0x28
  40db9c:	jb     40d8f0 <__swc_fn_fc36583a_000002_aa67484d+0x1d0>
  40dba2:	sub    rsp,0x8
  40dba6:	call   40a420 <__swc_fn_fc36583a_000001_1ca87929>
  40dbab:	add    rsp,0x8
  40dbaf:	vmovups xmm6,xmm0
  40dbb3:	lea    rax,[rbx+0xf8]
  40dbba:	vxorps xmm0,xmm0,xmm0
  40dbbe:	xor    ecx,ecx
  40dbc0:	vmovdqu XMMWORD PTR [rax+rcx*1],xmm0
  40dbc5:	add    rcx,0x10
  40dbc9:	cmp    rcx,0x200
  40dbd0:	jne    40dbc0 <__swc_fn_fc36583a_000002_aa67484d+0x4a0>
  40dbd2:	lea    rcx,[rbx+0x2f8]
  40dbd9:	vxorps xmm0,xmm0,xmm0
  40dbdd:	xor    edx,edx
  40dbdf:	nop
  40dbe0:	vmovdqu XMMWORD PTR [rcx+rdx*1],xmm0
  40dbe5:	add    rdx,0x10
  40dbe9:	cmp    rdx,0x200
  40dbf0:	jne    40dbe0 <__swc_fn_fc36583a_000002_aa67484d+0x4c0>
  40dbf2:	xor    edx,edx
  40dbf4:	mov    r8,QWORD PTR [rip+0x1646d]        # 424068 <__swc_bss_base_fc36583a+0x28>
  40dbfb:	mov    QWORD PTR [rsp+0x5b0],r8
  40dc03:	mov    r9,QWORD PTR [rip+0x16466]        # 424070 <__swc_bss_base_fc36583a+0x30>
  40dc0a:	mov    QWORD PTR [rsp+0x5b8],r9
  40dc12:	mov    r10,QWORD PTR [rip+0x16437]        # 424050 <__swc_bss_base_fc36583a+0x10>
  40dc19:	mov    QWORD PTR [rsp+0x5a0],0x0
  40dc25:	mov    QWORD PTR [rsp+0x5c0],r10
  40dc2d:	mov    r11,QWORD PTR [rip+0x16424]        # 424058 <__swc_bss_base_fc36583a+0x18>
  40dc34:	mov    QWORD PTR [rsp+0x5c8],r11
  40dc3c:	jmp    40dc78 <__swc_fn_fc36583a_000002_aa67484d+0x558>
  40dc3e:	cs nop WORD PTR [rax+rax*1+0x0]
  40dc48:	nop    DWORD PTR [rax+rax*1+0x0]
  40dc50:	mov    QWORD PTR [rsp+0x5a0],rsi
  40dc58:	mov    r8,QWORD PTR [rsp+0x5b0]
  40dc60:	mov    r9,QWORD PTR [rsp+0x5b8]
  40dc68:	mov    r10,QWORD PTR [rsp+0x5c0]
  40dc70:	mov    r11,QWORD PTR [rsp+0x5c8]
  40dc78:	mov    rdi,QWORD PTR [r8+rdx*8]
  40dc7c:	mov    QWORD PTR [rsp+0x5d0],rdi
  40dc84:	mov    r12,QWORD PTR [r9+rdx*8]
  40dc88:	mov    QWORD PTR [rsp+0x5d8],r12
  40dc90:	mov    r13d,0x40000000
  40dc96:	mov    r14,0xffffffffffffffff
  40dc9d:	xor    r15d,r15d
  40dca0:	mov    QWORD PTR [rsp+0x5a8],rdx
  40dca8:	vmovq  xmm3,r13
  40dcad:	vmovq  xmm4,r14
  40dcb2:	vmovq  xmm5,r15
  40dcb7:	jmp    40dce2 <__swc_fn_fc36583a_000002_aa67484d+0x5c2>
  40dcb9:	nop    DWORD PTR [rax+0x0]
  40dcc0:	mov    r10,QWORD PTR [rsp+0x5c0]
  40dcc8:	mov    r11,QWORD PTR [rsp+0x5c8]
  40dcd0:	mov    rdi,QWORD PTR [rsp+0x5d0]
  40dcd8:	vmovq  xmm3,r13
  40dcdd:	vmovq  xmm4,r14
  40dce2:	mov    r8,QWORD PTR [r10+r15*8]
  40dce6:	mov    QWORD PTR [rsp+0x5f8],r8
  40dcee:	mov    r9,QWORD PTR [r11+r15*8]
  40dcf2:	mov    rdx,r9
  40dcf5:	sub    rdx,r12
  40dcf8:	mov    rsi,r12
  40dcfb:	sub    rsi,r9
  40dcfe:	cmovbe rsi,rdx
  40dd02:	cmp    rsi,0x3
  40dd06:	jbe    40dd17 <__swc_fn_fc36583a_000002_aa67484d+0x5f7>
  40dd08:	vmovq  r13,xmm3
  40dd0d:	vmovq  r14,xmm4
  40dd12:	jmp    40de8b <__swc_fn_fc36583a_000002_aa67484d+0x76b>
  40dd17:	lea    rdx,[r9+0x1]
  40dd1b:	xor    esi,esi
  40dd1d:	test   rdx,rdx
  40dd20:	jbe    40dd3d <__swc_fn_fc36583a_000002_aa67484d+0x61d>
  40dd22:	cs nop WORD PTR [rax+rax*1+0x0]
  40dd2c:	nop    DWORD PTR [rax+0x0]
  40dd30:	mov    QWORD PTR [rax+rsi*8],rsi
  40dd34:	add    rsi,0x1
  40dd38:	cmp    rsi,rdx
  40dd3b:	jb     40dd30 <__swc_fn_fc36583a_000002_aa67484d+0x610>
  40dd3d:	xor    esi,esi
  40dd3f:	test   r12,r12
  40dd42:	jbe    40de6d <__swc_fn_fc36583a_000002_aa67484d+0x74d>
  40dd48:	mov    r10,QWORD PTR [rip+0x16311]        # 424060 <__swc_bss_base_fc36583a+0x20>
  40dd4f:	add    r10,rdi
  40dd52:	vmovsd xmm0,QWORD PTR [rsp+0x5d8]
  40dd5b:	vmovsd xmm1,QWORD PTR [rsp+0x5f8]
  40dd64:	vmovq  xmm2,r10
  40dd69:	nop    DWORD PTR [rax+0x0]
  40dd70:	lea    r11,[rsi+0x1]
  40dd74:	mov    QWORD PTR [rbx+0x2f8],r11
  40dd7b:	mov    sil,BYTE PTR [r10+rsi*1]
  40dd7f:	xor    edi,edi
  40dd81:	test   r9,r9
  40dd84:	jbe    40ddd6 <__swc_fn_fc36583a_000002_aa67484d+0x6b6>
  40dd86:	mov    r14,QWORD PTR [rip+0x162bb]        # 424048 <__swc_bss_base_fc36583a+0x8>
  40dd8d:	add    r14,r8
  40dd90:	mov    r15,QWORD PTR [rbx+0xf8]
  40dd97:	mov    r13,r11
  40dd9a:	nop    WORD PTR [rax+rax*1+0x0]
  40dda0:	xor    r8d,r8d
  40dda3:	cmp    BYTE PTR [r14+rdi*1],sil
  40dda7:	setne  r8b
  40ddab:	add    r8,r15
  40ddae:	mov    r15,QWORD PTR [rax+rdi*8+0x8]
  40ddb3:	lea    r10,[r15+0x1]
  40ddb7:	cmp    r10,r8
  40ddba:	cmovb  r8,r10
  40ddbe:	inc    r13
  40ddc1:	cmp    r13,r8
  40ddc4:	cmovae r13,r8
  40ddc8:	mov    QWORD PTR [rcx+rdi*8+0x8],r13
  40ddcd:	add    rdi,0x1
  40ddd1:	cmp    rdi,r9
  40ddd4:	jb     40dda0 <__swc_fn_fc36583a_000002_aa67484d+0x680>
  40ddd6:	xor    r8d,r8d
  40ddd9:	test   rdx,rdx
  40dddc:	jbe    40de51 <__swc_fn_fc36583a_000002_aa67484d+0x731>
  40dde2:	cmp    rdx,0x4
  40dde6:	jb     40de40 <__swc_fn_fc36583a_000002_aa67484d+0x720>
  40dde8:	lea    r10,[rdx-0x3]
  40ddec:	nop    DWORD PTR [rax+0x0]
  40ddf0:	mov    rsi,QWORD PTR [rcx+r8*8]
  40ddf4:	mov    QWORD PTR [rax+r8*8],rsi
  40ddf8:	mov    rsi,QWORD PTR [rcx+r8*8+0x8]
  40ddfd:	mov    QWORD PTR [rax+r8*8+0x8],rsi
  40de02:	mov    rsi,QWORD PTR [rcx+r8*8+0x10]
  40de07:	mov    QWORD PTR [rax+r8*8+0x10],rsi
  40de0c:	mov    rsi,QWORD PTR [rcx+r8*8+0x18]
  40de11:	mov    QWORD PTR [rax+r8*8+0x18],rsi
  40de16:	add    r8,0x4
  40de1a:	cmp    r8,r10
  40de1d:	jb     40ddf0 <__swc_fn_fc36583a_000002_aa67484d+0x6d0>
  40de1f:	cmp    r8,rdx
  40de22:	jae    40de51 <__swc_fn_fc36583a_000002_aa67484d+0x731>
  40de24:	cs nop WORD PTR [rax+rax*1+0x0]
  40de2e:	cs nop WORD PTR [rax+rax*1+0x0]
  40de38:	nop    DWORD PTR [rax+rax*1+0x0]
  40de40:	mov    rsi,QWORD PTR [rcx+r8*8]
  40de44:	mov    QWORD PTR [rax+r8*8],rsi
  40de48:	add    r8,0x1
  40de4c:	cmp    r8,rdx
  40de4f:	jb     40de40 <__swc_fn_fc36583a_000002_aa67484d+0x720>
  40de51:	mov    rsi,r11
  40de54:	vmovq  r12,xmm0
  40de59:	cmp    r11,r12
  40de5c:	jae    40de6d <__swc_fn_fc36583a_000002_aa67484d+0x74d>
  40de5e:	vmovq  r8,xmm1
  40de63:	vmovq  r10,xmm2
  40de68:	jmp    40dd70 <__swc_fn_fc36583a_000002_aa67484d+0x650>
  40de6d:	mov    rdx,QWORD PTR [rax+r9*8]
  40de71:	vmovq  r13,xmm3
  40de76:	cmp    rdx,r13
  40de79:	cmovb  r13,rdx
  40de7d:	vmovq  r14,xmm4
  40de82:	vmovq  r15,xmm5
  40de87:	cmovb  r14,r15
  40de8b:	add    r15,0x1
  40de8f:	vmovq  xmm5,r15
  40de94:	cmp    r15,0x1770
  40de9b:	jb     40dcc0 <__swc_fn_fc36583a_000002_aa67484d+0x5a0>
  40dea1:	imul   r13,r13,0x1f
  40dea5:	add    r13,r14
  40dea8:	mov    rsi,QWORD PTR [rsp+0x5a0]
  40deb0:	add    rsi,r13
  40deb3:	mov    rdx,QWORD PTR [rsp+0x5a8]
  40debb:	add    rdx,0x1
  40debf:	cmp    rdx,0x28
  40dec3:	jb     40dc50 <__swc_fn_fc36583a_000002_aa67484d+0x530>
  40dec9:	sub    rsp,0x8
  40decd:	call   40a420 <__swc_fn_fc36583a_000001_1ca87929>
  40ded2:	add    rsp,0x8
  40ded6:	vsubsd xmm0,xmm0,xmm6
  40deda:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x5346]        # 413228 <__swc_rdata_base_fc36583a+0x118>
  40dee2:	lea    rax,[rip+0x5237]        # 413120 <__swc_rdata_base_fc36583a+0x10>
  40dee9:	sub    rsp,0x90
  40def0:	mov    rcx,rsp
  40def3:	vmovups xmm1,XMMWORD PTR [rip+0x530d]        # 413208 <__swc_rdata_base_fc36583a+0xf8>
  40defb:	vmovups XMMWORD PTR [rcx],xmm1
  40deff:	mov    QWORD PTR [rcx+0x30],rsp
  40df03:	lea    rdx,[rip+0x5226]        # 413130 <__swc_rdata_base_fc36583a+0x20>
  40df0a:	mov    QWORD PTR [rcx+0x38],rdx
  40df0e:	mov    QWORD PTR [rcx+0x10],rsi
  40df12:	lea    r8,[rsp+0x10]
  40df17:	mov    QWORD PTR [rcx+0x40],r8
  40df1b:	lea    r8,[rip+0x5256]        # 413178 <__swc_rdata_base_fc36583a+0x68>
  40df22:	mov    QWORD PTR [rcx+0x48],r8
  40df26:	vmovups xmm1,XMMWORD PTR [rip+0x52ea]        # 413218 <__swc_rdata_base_fc36583a+0x108>
  40df2e:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40df33:	lea    r8,[rsp+0x18]
  40df38:	mov    QWORD PTR [rcx+0x50],r8
  40df3c:	mov    QWORD PTR [rcx+0x58],rdx
  40df40:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40df45:	lea    r8,[rcx+0x28]
  40df49:	mov    QWORD PTR [rcx+0x60],r8
  40df4d:	lea    r8,[rip+0x526c]        # 4131c0 <__swc_rdata_base_fc36583a+0xb0>
  40df54:	mov    QWORD PTR [rcx+0x68],r8
  40df58:	mov    QWORD PTR [rcx+0x70],rax
  40df5c:	mov    QWORD PTR [rcx+0x78],rdx
  40df60:	lea    rax,[rcx+0x30]
  40df64:	mov    QWORD PTR [rcx+0x80],rax
  40df6b:	mov    QWORD PTR [rcx+0x88],0x5
  40df76:	lea    rcx,[rcx+0x80]
  40df7d:	sub    rsp,0x8
  40df81:	call   410b00 <__swc_fn_fc36583a_000149_6203dca2>
  40df86:	add    rsp,0x6a8
  40df8d:	vmovups xmm6,XMMWORD PTR [rsp]
  40df92:	add    rsp,0x10
  40df96:	pop    r13
  40df98:	pop    r14
  40df9a:	pop    r12
  40df9c:	pop    rdi
  40df9d:	pop    rsi
  40df9e:	pop    r15
  40dfa0:	pop    rbx
  40dfa1:	pop    rbp
  40dfa2:	ret
