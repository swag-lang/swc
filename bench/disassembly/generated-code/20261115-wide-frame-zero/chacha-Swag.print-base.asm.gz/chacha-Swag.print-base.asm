
/workspace/prompt2-20261115/batch5-final-micro/base/chacha/chacha:     file format elf64-x86-64


Disassembly of section .text:

0000000000410980 <__swc_fn_3464c816_000146_4dba8c3c>:
  410980:	push   rbx
  410981:	push   rsi
  410982:	push   rdi
  410983:	push   r12
  410985:	push   r13
  410987:	push   r15
  410989:	sub    rsp,0x4e8
  410990:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  410999:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  4109a2:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  4109ab:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  4109b4:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  4109bd:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  4109c6:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  4109cf:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  4109d8:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  4109e1:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  4109ea:	mov    rbx,QWORD PTR [rcx]
  4109ed:	mov    rcx,QWORD PTR [rcx+0x8]
  4109f1:	mov    rsi,rcx
  4109f4:	xor    edi,edi
  4109f6:	vmovsd xmm6,QWORD PTR [rip+0x2b92]        # 413590 <__swc_rdata_base_3464c816+0x480>
  4109fe:	vmovsd xmm7,QWORD PTR [rip+0x2b93]        # 413599 <__swc_rdata_base_3464c816+0x489>
  410a06:	vmovsd xmm8,QWORD PTR [rip+0x2b94]        # 4135a2 <__swc_rdata_base_3464c816+0x492>
  410a0e:	vmovsd xmm9,QWORD PTR [rip+0x2b95]        # 4135ab <__swc_rdata_base_3464c816+0x49b>
  410a16:	vmovsd xmm10,QWORD PTR [rip+0x2b96]        # 4135b4 <__swc_rdata_base_3464c816+0x4a4>
  410a1e:	vmovups xmm11,xmm6
  410a22:	vmovsd QWORD PTR [rsp+0x418],xmm7
  410a2b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  410a34:	vmovsd QWORD PTR [rsp+0x428],xmm9
  410a3d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  410a46:	vmovsd xmm15,QWORD PTR [rip+0x2b6f]        # 4135bd <__swc_rdata_base_3464c816+0x4ad>
  410a4e:	vmovups xmm14,xmm15
  410a53:	vmovups xmm0,xmm9
  410a58:	vmovsd QWORD PTR [rsp+0x438],xmm15
  410a61:	vmovups xmm13,xmm8
  410a66:	vmovsd QWORD PTR [rsp+0x440],xmm15
  410a6f:	test   rsi,rsi
  410a72:	je     411aa3 <__swc_fn_3464c816_000146_4dba8c3c+0x1123>
  410a78:	cs nop WORD PTR [rax+rax*1+0x0]
  410a82:	cs nop WORD PTR [rax+rax*1+0x0]
  410a8c:	nop    DWORD PTR [rax+0x0]
  410a90:	lea    rcx,[rdi+rdi*1]
  410a94:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  410a99:	vpshufd xmm3,xmm2,0xee
  410a9e:	vmovq  rcx,xmm3
  410aa3:	test   rcx,rcx
  410aa6:	je     410abc <__swc_fn_3464c816_000146_4dba8c3c+0x13c>
  410aa8:	test   DWORD PTR [rcx+0x28],0x400000
  410aaf:	je     410abc <__swc_fn_3464c816_000146_4dba8c3c+0x13c>
  410ab1:	mov    rdx,QWORD PTR [rcx+0x30]
  410ab5:	test   rdx,rdx
  410ab8:	cmovne rcx,rdx
  410abc:	test   DWORD PTR [rcx+0x28],0x1000
  410ac3:	je     410ae4 <__swc_fn_3464c816_000146_4dba8c3c+0x164>
  410ac5:	mov    rdx,QWORD PTR [rcx+0x40]
  410ac9:	mov    rcx,rdx
  410acc:	vmovq  r8,xmm2
  410ad1:	mov    r8,QWORD PTR [r8]
  410ad4:	mov    QWORD PTR [rsp+0x60],r8
  410ad9:	mov    QWORD PTR [rsp+0x68],rdx
  410ade:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  410ae4:	test   BYTE PTR [rcx+0x28],0x1
  410ae8:	jne    410af0 <__swc_fn_3464c816_000146_4dba8c3c+0x170>
  410aea:	vmovups xmm12,xmm0
  410aee:	jmp    410b0a <__swc_fn_3464c816_000146_4dba8c3c+0x18a>
  410af0:	vmovq  rax,xmm2
  410af5:	mov    rax,QWORD PTR [rax]
  410af8:	lea    rcx,[rax+0x10]
  410afc:	vmovups xmm12,xmm0
  410b00:	call   410100 <__swc_fn_3464c816_000116_18ca1307>
  410b05:	jmp    411a85 <__swc_fn_3464c816_000146_4dba8c3c+0x1105>
  410b0a:	test   DWORD PTR [rcx+0x28],0x400
  410b11:	je     410b72 <__swc_fn_3464c816_000146_4dba8c3c+0x1f2>
  410b13:	vmovq  rax,xmm2
  410b18:	mov    rax,QWORD PTR [rax]
  410b1b:	xor    ecx,ecx
  410b1d:	test   rax,rax
  410b20:	je     410b50 <__swc_fn_3464c816_000146_4dba8c3c+0x1d0>
  410b22:	mov    rdx,rax
  410b25:	mov    r8b,BYTE PTR [rdx]
  410b28:	test   r8b,r8b
  410b2b:	je     410b50 <__swc_fn_3464c816_000146_4dba8c3c+0x1d0>
  410b2d:	cs nop WORD PTR [rax+rax*1+0x0]
  410b37:	nop    WORD PTR [rax+rax*1+0x0]
  410b40:	add    rdx,0x1
  410b44:	add    rcx,0x1
  410b48:	mov    r8b,BYTE PTR [rdx]
  410b4b:	test   r8b,r8b
  410b4e:	jne    410b40 <__swc_fn_3464c816_000146_4dba8c3c+0x1c0>
  410b50:	mov    QWORD PTR [rsp+0x88],rax
  410b58:	mov    QWORD PTR [rsp+0x90],rcx
  410b60:	lea    rcx,[rsp+0x88]
  410b68:	call   410100 <__swc_fn_3464c816_000116_18ca1307>
  410b6d:	jmp    411a85 <__swc_fn_3464c816_000146_4dba8c3c+0x1105>
  410b72:	cmp    BYTE PTR [rcx+0x2c],0x6
  410b76:	jne    410b8d <__swc_fn_3464c816_000146_4dba8c3c+0x20d>
  410b78:	vmovq  rax,xmm2
  410b7d:	mov    rax,QWORD PTR [rax]
  410b80:	mov    rcx,rax
  410b83:	call   409cd0 <__swc_fn_3464c816_000144_34d6a3dc>
  410b88:	jmp    411a85 <__swc_fn_3464c816_000146_4dba8c3c+0x1105>
  410b8d:	cmp    BYTE PTR [rcx+0x2c],0x1
  410b91:	jne    411a79 <__swc_fn_3464c816_000146_4dba8c3c+0x10f9>
  410b97:	vmovq  rdx,xmm2
  410b9c:	mov    cl,BYTE PTR [rcx+0x40]
  410b9f:	cmp    cl,0x7
  410ba2:	jb     410be5 <__swc_fn_3464c816_000146_4dba8c3c+0x265>
  410ba4:	je     410c58 <__swc_fn_3464c816_000146_4dba8c3c+0x2d8>
  410baa:	cmp    cl,0x8
  410bad:	je     410c64 <__swc_fn_3464c816_000146_4dba8c3c+0x2e4>
  410bb3:	cmp    cl,0x9
  410bb6:	je     410c7d <__swc_fn_3464c816_000146_4dba8c3c+0x2fd>
  410bbc:	cmp    cl,0xa
  410bbf:	je     411364 <__swc_fn_3464c816_000146_4dba8c3c+0x9e4>
  410bc5:	cmp    cl,0xb
  410bc8:	je     411a4b <__swc_fn_3464c816_000146_4dba8c3c+0x10cb>
  410bce:	cmp    cl,0xc
  410bd1:	je     410c71 <__swc_fn_3464c816_000146_4dba8c3c+0x2f1>
  410bd7:	cmp    cl,0xd
  410bda:	je     411a41 <__swc_fn_3464c816_000146_4dba8c3c+0x10c1>
  410be0:	jmp    411a6b <__swc_fn_3464c816_000146_4dba8c3c+0x10eb>
  410be5:	cmp    cl,0x1
  410be8:	je     410c08 <__swc_fn_3464c816_000146_4dba8c3c+0x288>
  410bea:	cmp    cl,0x2
  410bed:	je     410c16 <__swc_fn_3464c816_000146_4dba8c3c+0x296>
  410bef:	cmp    cl,0x3
  410bf2:	je     410c24 <__swc_fn_3464c816_000146_4dba8c3c+0x2a4>
  410bf4:	cmp    cl,0x4
  410bf7:	je     410c31 <__swc_fn_3464c816_000146_4dba8c3c+0x2b1>
  410bf9:	cmp    cl,0x5
  410bfc:	je     410c3e <__swc_fn_3464c816_000146_4dba8c3c+0x2be>
  410bfe:	cmp    cl,0x6
  410c01:	je     410c4b <__swc_fn_3464c816_000146_4dba8c3c+0x2cb>
  410c03:	jmp    411a6b <__swc_fn_3464c816_000146_4dba8c3c+0x10eb>
  410c08:	movsx  rcx,BYTE PTR [rdx]
  410c0c:	call   40cf80 <__swc_fn_3464c816_000145_140c84e9>
  410c11:	jmp    411a85 <__swc_fn_3464c816_000146_4dba8c3c+0x1105>
  410c16:	movsx  rcx,WORD PTR [rdx]
  410c1a:	call   40cf80 <__swc_fn_3464c816_000145_140c84e9>
  410c1f:	jmp    411a85 <__swc_fn_3464c816_000146_4dba8c3c+0x1105>
  410c24:	movsxd rcx,DWORD PTR [rdx]
  410c27:	call   40cf80 <__swc_fn_3464c816_000145_140c84e9>
  410c2c:	jmp    411a85 <__swc_fn_3464c816_000146_4dba8c3c+0x1105>
  410c31:	mov    rcx,QWORD PTR [rdx]
  410c34:	call   40cf80 <__swc_fn_3464c816_000145_140c84e9>
  410c39:	jmp    411a85 <__swc_fn_3464c816_000146_4dba8c3c+0x1105>
  410c3e:	movzx  ecx,BYTE PTR [rdx]
  410c41:	call   409cd0 <__swc_fn_3464c816_000144_34d6a3dc>
  410c46:	jmp    411a85 <__swc_fn_3464c816_000146_4dba8c3c+0x1105>
  410c4b:	movzx  ecx,WORD PTR [rdx]
  410c4e:	call   409cd0 <__swc_fn_3464c816_000144_34d6a3dc>
  410c53:	jmp    411a85 <__swc_fn_3464c816_000146_4dba8c3c+0x1105>
  410c58:	mov    ecx,DWORD PTR [rdx]
  410c5a:	call   409cd0 <__swc_fn_3464c816_000144_34d6a3dc>
  410c5f:	jmp    411a85 <__swc_fn_3464c816_000146_4dba8c3c+0x1105>
  410c64:	mov    rcx,QWORD PTR [rdx]
  410c67:	call   409cd0 <__swc_fn_3464c816_000144_34d6a3dc>
  410c6c:	jmp    411a85 <__swc_fn_3464c816_000146_4dba8c3c+0x1105>
  410c71:	mov    ecx,DWORD PTR [rdx]
  410c73:	call   409cd0 <__swc_fn_3464c816_000144_34d6a3dc>
  410c78:	jmp    411a85 <__swc_fn_3464c816_000146_4dba8c3c+0x1105>
  410c7d:	lea    rcx,[rsp+0xa8]
  410c85:	vxorps xmm0,xmm0,xmm0
  410c89:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  410c92:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  410c9b:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  410ca4:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  410cad:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  410cb6:	vmovups XMMWORD PTR [rsp+0xf8],xmm0
  410cbf:	mov    DWORD PTR [rsp+0x108],0x0
  410cca:	vxorpd xmm0,xmm0,xmm0
  410cce:	vmovss xmm1,DWORD PTR [rdx]
  410cd2:	vcvtss2sd xmm0,xmm0,xmm1
  410cd6:	vmovsd xmm1,xmm1,xmm0
  410cda:	vcomisd xmm0,xmm0
  410cde:	setne  dl
  410ce1:	movzx  edx,dl
  410ce4:	setp   r8b
  410ce8:	movzx  r8d,r8b
  410cec:	or     edx,r8d
  410cef:	test   dl,dl
  410cf1:	je     410cfe <__swc_fn_3464c816_000146_4dba8c3c+0x37e>
  410cf3:	mov    DWORD PTR [rcx],0x6e616e
  410cf9:	jmp    4112f8 <__swc_fn_3464c816_000146_4dba8c3c+0x978>
  410cfe:	vcomisd xmm1,xmm6
  410d02:	ja     410d0a <__swc_fn_3464c816_000146_4dba8c3c+0x38a>
  410d04:	vcomisd xmm7,xmm1
  410d08:	jbe    410d2e <__swc_fn_3464c816_000146_4dba8c3c+0x3ae>
  410d0a:	vxorpd xmm0,xmm0,xmm0
  410d0e:	vcomisd xmm0,xmm1
  410d12:	jbe    410d23 <__swc_fn_3464c816_000146_4dba8c3c+0x3a3>
  410d14:	mov    DWORD PTR [rcx],0x666e692d
  410d1a:	mov    BYTE PTR [rcx+0x4],0x0
  410d1e:	jmp    4112f8 <__swc_fn_3464c816_000146_4dba8c3c+0x978>
  410d23:	mov    DWORD PTR [rcx],0x666e69
  410d29:	jmp    4112f8 <__swc_fn_3464c816_000146_4dba8c3c+0x978>
  410d2e:	vcomisd xmm1,xmm8
  410d33:	jae    410d3f <__swc_fn_3464c816_000146_4dba8c3c+0x3bf>
  410d35:	vcomisd xmm9,xmm1
  410d39:	jbe    4110be <__swc_fn_3464c816_000146_4dba8c3c+0x73e>
  410d3f:	vmovups xmm0,xmm1
  410d43:	vxorpd xmm2,xmm2,xmm2
  410d47:	vcomisd xmm2,xmm1
  410d4b:	jbe    410d5b <__swc_fn_3464c816_000146_4dba8c3c+0x3db>
  410d4d:	vmovsd xmm1,xmm1,xmm0
  410d51:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x27f7]        # 413550 <__swc_rdata_base_3464c816+0x440>
  410d59:	jmp    410d5f <__swc_fn_3464c816_000146_4dba8c3c+0x3df>
  410d5b:	vmovsd xmm1,xmm1,xmm0
  410d5f:	xor    r8d,r8d
  410d62:	vcomisd xmm1,xmm15
  410d67:	jb     410d90 <__swc_fn_3464c816_000146_4dba8c3c+0x410>
  410d69:	cs nop WORD PTR [rax+rax*1+0x0]
  410d73:	cs nop WORD PTR [rax+rax*1+0x0]
  410d7d:	nop    DWORD PTR [rax]
  410d80:	vdivsd xmm1,xmm1,xmm15
  410d85:	add    r8,0x1
  410d89:	vcomisd xmm1,xmm15
  410d8e:	jae    410d80 <__swc_fn_3464c816_000146_4dba8c3c+0x400>
  410d90:	mov    r9,rcx
  410d93:	vxorpd xmm2,xmm2,xmm2
  410d97:	vcomisd xmm2,xmm0
  410d9b:	jbe    410da4 <__swc_fn_3464c816_000146_4dba8c3c+0x424>
  410d9d:	mov    BYTE PTR [rcx],0x2d
  410da0:	lea    r9,[rcx+0x1]
  410da4:	vcvttsd2si rdx,xmm1
  410da9:	mov    r10b,dl
  410dac:	add    r10b,0x30
  410db0:	mov    BYTE PTR [r9],r10b
  410db3:	vxorpd xmm0,xmm0,xmm0
  410db7:	movzx  edx,dl
  410dba:	vcvtsi2sd xmm0,xmm0,rdx
  410dbf:	vsubsd xmm0,xmm1,xmm0
  410dc3:	vmulsd xmm1,xmm0,xmm15
  410dc8:	mov    BYTE PTR [r9+0x1],0x2e
  410dcd:	vcvttsd2si rdx,xmm1
  410dd2:	mov    r10b,dl
  410dd5:	add    r10b,0x30
  410dd9:	mov    BYTE PTR [r9+0x2],r10b
  410ddd:	vxorpd xmm0,xmm0,xmm0
  410de1:	movzx  edx,dl
  410de4:	vcvtsi2sd xmm0,xmm0,rdx
  410de9:	vsubsd xmm0,xmm1,xmm0
  410ded:	vmulsd xmm1,xmm0,xmm15
  410df2:	vcvttsd2si rdx,xmm1
  410df7:	mov    r10b,dl
  410dfa:	add    r10b,0x30
  410dfe:	mov    BYTE PTR [r9+0x3],r10b
  410e02:	vxorpd xmm0,xmm0,xmm0
  410e06:	movzx  edx,dl
  410e09:	vcvtsi2sd xmm0,xmm0,rdx
  410e0e:	vsubsd xmm0,xmm1,xmm0
  410e12:	vmulsd xmm1,xmm0,xmm15
  410e17:	vcvttsd2si rdx,xmm1
  410e1c:	mov    r10b,dl
  410e1f:	add    r10b,0x30
  410e23:	mov    BYTE PTR [r9+0x4],r10b
  410e27:	vxorpd xmm0,xmm0,xmm0
  410e2b:	movzx  edx,dl
  410e2e:	vcvtsi2sd xmm0,xmm0,rdx
  410e33:	vsubsd xmm0,xmm1,xmm0
  410e37:	vmulsd xmm1,xmm0,xmm15
  410e3c:	vcvttsd2si rdx,xmm1
  410e41:	mov    r10b,dl
  410e44:	add    r10b,0x30
  410e48:	mov    BYTE PTR [r9+0x5],r10b
  410e4c:	vxorpd xmm0,xmm0,xmm0
  410e50:	movzx  edx,dl
  410e53:	vcvtsi2sd xmm0,xmm0,rdx
  410e58:	vsubsd xmm0,xmm1,xmm0
  410e5c:	vmulsd xmm1,xmm0,xmm15
  410e61:	vcvttsd2si rdx,xmm1
  410e66:	mov    r10b,dl
  410e69:	add    r10b,0x30
  410e6d:	mov    BYTE PTR [r9+0x6],r10b
  410e71:	vxorpd xmm0,xmm0,xmm0
  410e75:	movzx  edx,dl
  410e78:	vcvtsi2sd xmm0,xmm0,rdx
  410e7d:	vsubsd xmm0,xmm1,xmm0
  410e81:	vmulsd xmm1,xmm0,xmm15
  410e86:	vcvttsd2si rdx,xmm1
  410e8b:	mov    r10b,dl
  410e8e:	add    r10b,0x30
  410e92:	mov    BYTE PTR [r9+0x7],r10b
  410e96:	vxorpd xmm0,xmm0,xmm0
  410e9a:	movzx  edx,dl
  410e9d:	vcvtsi2sd xmm0,xmm0,rdx
  410ea2:	vsubsd xmm0,xmm1,xmm0
  410ea6:	vmulsd xmm1,xmm0,xmm15
  410eab:	vcvttsd2si rdx,xmm1
  410eb0:	mov    r10b,dl
  410eb3:	add    r10b,0x30
  410eb7:	mov    BYTE PTR [r9+0x8],r10b
  410ebb:	vxorpd xmm0,xmm0,xmm0
  410ebf:	movzx  edx,dl
  410ec2:	vcvtsi2sd xmm0,xmm0,rdx
  410ec7:	vsubsd xmm0,xmm1,xmm0
  410ecb:	vmulsd xmm1,xmm0,xmm15
  410ed0:	vcvttsd2si rdx,xmm1
  410ed5:	mov    r10b,dl
  410ed8:	add    r10b,0x30
  410edc:	mov    BYTE PTR [r9+0x9],r10b
  410ee0:	vxorpd xmm0,xmm0,xmm0
  410ee4:	movzx  edx,dl
  410ee7:	vcvtsi2sd xmm0,xmm0,rdx
  410eec:	vsubsd xmm0,xmm1,xmm0
  410ef0:	vmulsd xmm1,xmm0,xmm15
  410ef5:	vcvttsd2si rdx,xmm1
  410efa:	mov    r10b,dl
  410efd:	add    r10b,0x30
  410f01:	mov    BYTE PTR [r9+0xa],r10b
  410f05:	vxorpd xmm0,xmm0,xmm0
  410f09:	movzx  edx,dl
  410f0c:	vcvtsi2sd xmm0,xmm0,rdx
  410f11:	vsubsd xmm0,xmm1,xmm0
  410f15:	vmulsd xmm1,xmm0,xmm15
  410f1a:	vcvttsd2si rdx,xmm1
  410f1f:	mov    r10b,dl
  410f22:	add    r10b,0x30
  410f26:	mov    BYTE PTR [r9+0xb],r10b
  410f2a:	lea    r10,[r9+0x4]
  410f2e:	vxorpd xmm0,xmm0,xmm0
  410f32:	movzx  edx,dl
  410f35:	vcvtsi2sd xmm0,xmm0,rdx
  410f3a:	vsubsd xmm0,xmm1,xmm0
  410f3e:	vmulsd xmm1,xmm0,xmm15
  410f43:	vcvttsd2si rdx,xmm1
  410f48:	mov    r11b,dl
  410f4b:	add    r11b,0x30
  410f4f:	mov    BYTE PTR [r9+0xc],r11b
  410f53:	vxorpd xmm0,xmm0,xmm0
  410f57:	movzx  edx,dl
  410f5a:	vcvtsi2sd xmm0,xmm0,rdx
  410f5f:	vsubsd xmm0,xmm1,xmm0
  410f63:	vmulsd xmm1,xmm0,xmm15
  410f68:	vcvttsd2si rdx,xmm1
  410f6d:	mov    r11b,dl
  410f70:	add    r11b,0x30
  410f74:	mov    BYTE PTR [r9+0xd],r11b
  410f78:	lea    r10,[r10+0x2]
  410f7c:	vxorpd xmm0,xmm0,xmm0
  410f80:	movzx  edx,dl
  410f83:	vcvtsi2sd xmm0,xmm0,rdx
  410f88:	vsubsd xmm0,xmm1,xmm0
  410f8c:	vmulsd xmm1,xmm0,xmm15
  410f91:	vcvttsd2si rdx,xmm1
  410f96:	mov    r11b,dl
  410f99:	add    r11b,0x30
  410f9d:	mov    BYTE PTR [r9+0xe],r11b
  410fa1:	vxorpd xmm0,xmm0,xmm0
  410fa5:	movzx  edx,dl
  410fa8:	vcvtsi2sd xmm0,xmm0,rdx
  410fad:	vsubsd xmm0,xmm1,xmm0
  410fb1:	vmulsd xmm1,xmm0,xmm15
  410fb6:	vcvttsd2si rdx,xmm1
  410fbb:	mov    r11b,dl
  410fbe:	add    r11b,0x30
  410fc2:	mov    BYTE PTR [r9+0xf],r11b
  410fc6:	lea    r10,[r10+0x2]
  410fca:	lea    r10,[r10+0x2]
  410fce:	lea    r10,[r10+0x2]
  410fd2:	lea    r10,[r10+0x2]
  410fd6:	lea    r10,[r10+0x2]
  410fda:	vxorpd xmm0,xmm0,xmm0
  410fde:	movzx  edx,dl
  410fe1:	vcvtsi2sd xmm0,xmm0,rdx
  410fe6:	vsubsd xmm0,xmm1,xmm0
  410fea:	vmulsd xmm1,xmm0,xmm15
  410fef:	vcvttsd2si rdx,xmm1
  410ff4:	mov    r11b,dl
  410ff7:	add    r11b,0x30
  410ffb:	mov    BYTE PTR [r9+0x10],r11b
  410fff:	vxorpd xmm0,xmm0,xmm0
  411003:	movzx  edx,dl
  411006:	vcvtsi2sd xmm0,xmm0,rdx
  41100b:	vsubsd xmm0,xmm1,xmm0
  41100f:	vmulsd xmm1,xmm0,xmm15
  411014:	vcvttsd2si rdx,xmm1
  411019:	add    dl,0x30
  41101c:	mov    BYTE PTR [r9+0x11],dl
  411020:	mov    BYTE PTR [r10+0x2],0x65
  411025:	lea    r9,[r10+0x3]
  411029:	test   r8,r8
  41102c:	jl     411035 <__swc_fn_3464c816_000146_4dba8c3c+0x6b5>
  41102e:	mov    BYTE PTR [r9],0x2b
  411032:	inc    r9
  411035:	mov    r10,r9
  411038:	mov    rdx,r8
  41103b:	nop    DWORD PTR [rax+rax*1+0x0]
  411040:	mov    r11,rdx
  411043:	movabs rdx,0x6666666666666667
  41104d:	mov    rax,r11
  411050:	imul   rdx
  411053:	sar    rdx,0x2
  411057:	mov    r12,rdx
  41105a:	shr    rdx,0x3f
  41105e:	add    r12,rdx
  411061:	mov    rdx,r12
  411064:	imul   r13,r12,0xa
  411068:	sub    r11,r13
  41106b:	mov    r13,QWORD PTR [rip+0x24ce]        # 413540 <__swc_rdata_base_3464c816+0x430>
  411072:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411077:	mov    BYTE PTR [r10],r11b
  41107a:	lea    r11,[r10+0x1]
  41107e:	mov    r10,r11
  411081:	test   r12,r12
  411084:	jne    411040 <__swc_fn_3464c816_000146_4dba8c3c+0x6c0>
  411086:	test   r8,r8
  411089:	jge    411093 <__swc_fn_3464c816_000146_4dba8c3c+0x713>
  41108b:	mov    BYTE PTR [r11],0x2d
  41108f:	lea    r10,[r11+0x1]
  411093:	mov    BYTE PTR [r10],0x0
  411097:	sub    r10,0x1
  41109b:	nop    DWORD PTR [rax+rax*1+0x0]
  4110a0:	cmp    r9,r10
  4110a3:	jae    4112f8 <__swc_fn_3464c816_000146_4dba8c3c+0x978>
  4110a9:	mov    al,BYTE PTR [r10]
  4110ac:	mov    dl,BYTE PTR [r9]
  4110af:	mov    BYTE PTR [r10],dl
  4110b2:	sub    r10,0x1
  4110b6:	mov    BYTE PTR [r9],al
  4110b9:	inc    r9
  4110bc:	jmp    4110a0 <__swc_fn_3464c816_000146_4dba8c3c+0x720>
  4110be:	vcvttsd2si rdx,xmm1
  4110c3:	mov    r8,rdx
  4110c6:	vxorpd xmm0,xmm0,xmm0
  4110ca:	vcvtsi2sd xmm0,xmm0,rdx
  4110cf:	vsubsd xmm0,xmm1,xmm0
  4110d3:	mov    r9d,0x8
  4110d9:	vxorpd xmm2,xmm2,xmm2
  4110dd:	vcomisd xmm2,xmm0
  4110e1:	jbe    4110eb <__swc_fn_3464c816_000146_4dba8c3c+0x76b>
  4110e3:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x2465]        # 413550 <__swc_rdata_base_3464c816+0x440>
  4110eb:	test   r9d,r9d
  4110ee:	je     4110fa <__swc_fn_3464c816_000146_4dba8c3c+0x77a>
  4110f0:	vmulsd xmm0,xmm0,xmm14
  4110f5:	dec    r9d
  4110f8:	jne    4110f0 <__swc_fn_3464c816_000146_4dba8c3c+0x770>
  4110fa:	vcvttsd2si r9,xmm0
  4110ff:	mov    r10,r9
  411102:	vxorpd xmm2,xmm2,xmm2
  411106:	vcvtsi2sd xmm2,xmm2,r9
  41110b:	vsubsd xmm0,xmm0,xmm2
  41110f:	vcomisd xmm0,xmm10
  411114:	lea    r9,[r9+0x1]
  411118:	cmova  r10,r9
  41111c:	cmp    r10,0x5f5e100
  411123:	jne    41113c <__swc_fn_3464c816_000146_4dba8c3c+0x7bc>
  411125:	lea    r8,[rdx-0x1]
  411129:	vxorpd xmm0,xmm0,xmm0
  41112d:	vcomisd xmm0,xmm1
  411131:	lea    rdx,[rdx+0x1]
  411135:	cmovbe r8,rdx
  411139:	xor    r10d,r10d
  41113c:	mov    r9,rcx
  41113f:	test   r8,r8
  411142:	jne    411162 <__swc_fn_3464c816_000146_4dba8c3c+0x7e2>
  411144:	vxorpd xmm0,xmm0,xmm0
  411148:	vcomisd xmm0,xmm1
  41114c:	jbe    411155 <__swc_fn_3464c816_000146_4dba8c3c+0x7d5>
  41114e:	mov    BYTE PTR [rcx],0x2d
  411151:	lea    r9,[rcx+0x1]
  411155:	mov    BYTE PTR [r9],0x30
  411159:	add    r9,0x1
  41115d:	jmp    4111fb <__swc_fn_3464c816_000146_4dba8c3c+0x87b>
  411162:	mov    r9,rcx
  411165:	mov    rdx,r8
  411168:	nop    DWORD PTR [rax+rax*1+0x0]
  411170:	mov    r11,rdx
  411173:	movabs rdx,0x6666666666666667
  41117d:	mov    r15,rax
  411180:	mov    rax,r11
  411183:	imul   rdx
  411186:	mov    r12,rdx
  411189:	mov    rax,r15
  41118c:	sar    r12,0x2
  411190:	mov    rdx,r12
  411193:	shr    rdx,0x3f
  411197:	add    r12,rdx
  41119a:	mov    rdx,r12
  41119d:	imul   r13,r12,0xa
  4111a1:	sub    r11,r13
  4111a4:	mov    r13,QWORD PTR [rip+0x2395]        # 413540 <__swc_rdata_base_3464c816+0x430>
  4111ab:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4111b0:	mov    BYTE PTR [r9],r11b
  4111b3:	lea    r11,[r9+0x1]
  4111b7:	mov    r9,r11
  4111ba:	test   r12,r12
  4111bd:	jne    411170 <__swc_fn_3464c816_000146_4dba8c3c+0x7f0>
  4111bf:	test   r8,r8
  4111c2:	jge    4111cc <__swc_fn_3464c816_000146_4dba8c3c+0x84c>
  4111c4:	mov    BYTE PTR [r11],0x2d
  4111c8:	lea    r9,[r11+0x1]
  4111cc:	mov    rdx,r9
  4111cf:	mov    BYTE PTR [r9],0x0
  4111d3:	sub    r9,0x1
  4111d7:	mov    r8,rcx
  4111da:	cmp    r8,r9
  4111dd:	jae    4111f8 <__swc_fn_3464c816_000146_4dba8c3c+0x878>
  4111df:	nop
  4111e0:	mov    r11b,BYTE PTR [r9]
  4111e3:	mov    r12b,BYTE PTR [r8]
  4111e6:	mov    BYTE PTR [r9],r12b
  4111e9:	sub    r9,0x1
  4111ed:	mov    BYTE PTR [r8],r11b
  4111f0:	inc    r8
  4111f3:	cmp    r8,r9
  4111f6:	jb     4111e0 <__swc_fn_3464c816_000146_4dba8c3c+0x860>
  4111f8:	mov    r9,rdx
  4111fb:	mov    BYTE PTR [r9],0x2e
  4111ff:	add    r9,0x1
  411203:	xor    r8d,r8d
  411206:	test   r10,r10
  411209:	je     41124f <__swc_fn_3464c816_000146_4dba8c3c+0x8cf>
  41120b:	mov    r11d,0x989680
  411211:	cmp    r10,r11
  411214:	jge    41124f <__swc_fn_3464c816_000146_4dba8c3c+0x8cf>
  411216:	cs nop WORD PTR [rax+rax*1+0x0]
  411220:	inc    r8d
  411223:	movabs rdx,0x6666666666666667
  41122d:	mov    r15,rax
  411230:	mov    rax,r11
  411233:	imul   rdx
  411236:	mov    r11,rdx
  411239:	mov    rax,r15
  41123c:	sar    r11,0x2
  411240:	mov    rdx,r11
  411243:	shr    rdx,0x3f
  411247:	add    r11,rdx
  41124a:	cmp    r10,r11
  41124d:	jl     411220 <__swc_fn_3464c816_000146_4dba8c3c+0x8a0>
  41124f:	test   r8d,r8d
  411252:	je     41126d <__swc_fn_3464c816_000146_4dba8c3c+0x8ed>
  411254:	cs nop WORD PTR [rax+rax*1+0x0]
  41125e:	xchg   ax,ax
  411260:	mov    BYTE PTR [r9],0x30
  411264:	add    r9,0x1
  411268:	dec    r8d
  41126b:	jne    411260 <__swc_fn_3464c816_000146_4dba8c3c+0x8e0>
  41126d:	mov    r8,r9
  411270:	mov    rdx,r10
  411273:	cs nop WORD PTR [rax+rax*1+0x0]
  41127d:	nop    DWORD PTR [rax]
  411280:	mov    r11,rdx
  411283:	movabs rdx,0x6666666666666667
  41128d:	mov    rax,r11
  411290:	imul   rdx
  411293:	sar    rdx,0x2
  411297:	mov    r12,rdx
  41129a:	shr    rdx,0x3f
  41129e:	add    r12,rdx
  4112a1:	mov    rdx,r12
  4112a4:	imul   r13,r12,0xa
  4112a8:	sub    r11,r13
  4112ab:	mov    r13,QWORD PTR [rip+0x228e]        # 413540 <__swc_rdata_base_3464c816+0x430>
  4112b2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4112b7:	mov    BYTE PTR [r8],r11b
  4112ba:	lea    r11,[r8+0x1]
  4112be:	mov    r8,r11
  4112c1:	test   r12,r12
  4112c4:	jne    411280 <__swc_fn_3464c816_000146_4dba8c3c+0x900>
  4112c6:	test   r10,r10
  4112c9:	jge    4112d3 <__swc_fn_3464c816_000146_4dba8c3c+0x953>
  4112cb:	mov    BYTE PTR [r11],0x2d
  4112cf:	lea    r8,[r11+0x1]
  4112d3:	mov    BYTE PTR [r8],0x0
  4112d7:	sub    r8,0x1
  4112db:	cmp    r9,r8
  4112de:	jae    4112f8 <__swc_fn_3464c816_000146_4dba8c3c+0x978>
  4112e0:	mov    al,BYTE PTR [r8]
  4112e3:	mov    dl,BYTE PTR [r9]
  4112e6:	mov    BYTE PTR [r8],dl
  4112e9:	sub    r8,0x1
  4112ed:	mov    BYTE PTR [r9],al
  4112f0:	inc    r9
  4112f3:	cmp    r9,r8
  4112f6:	jb     4112e0 <__swc_fn_3464c816_000146_4dba8c3c+0x960>
  4112f8:	xor    eax,eax
  4112fa:	test   rcx,rcx
  4112fd:	je     411330 <__swc_fn_3464c816_000146_4dba8c3c+0x9b0>
  4112ff:	mov    rdx,rcx
  411302:	mov    r8b,BYTE PTR [rdx]
  411305:	test   r8b,r8b
  411308:	je     411330 <__swc_fn_3464c816_000146_4dba8c3c+0x9b0>
  41130a:	cs nop WORD PTR [rax+rax*1+0x0]
  411314:	cs nop WORD PTR [rax+rax*1+0x0]
  41131e:	xchg   ax,ax
  411320:	add    rdx,0x1
  411324:	add    rax,0x1
  411328:	mov    r8b,BYTE PTR [rdx]
  41132b:	test   r8b,r8b
  41132e:	jne    411320 <__swc_fn_3464c816_000146_4dba8c3c+0x9a0>
  411330:	mov    QWORD PTR [rsp+0x240],rcx
  411338:	mov    QWORD PTR [rsp+0x248],rax
  411340:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  411349:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  411352:	lea    rcx,[rsp+0x250]
  41135a:	call   410100 <__swc_fn_3464c816_000116_18ca1307>
  41135f:	jmp    411a85 <__swc_fn_3464c816_000146_4dba8c3c+0x1105>
  411364:	lea    rcx,[rsp+0x260]
  41136c:	vxorps xmm0,xmm0,xmm0
  411370:	vmovups XMMWORD PTR [rsp+0x260],xmm0
  411379:	vmovups XMMWORD PTR [rsp+0x270],xmm0
  411382:	vmovups XMMWORD PTR [rsp+0x280],xmm0
  41138b:	vmovups XMMWORD PTR [rsp+0x290],xmm0
  411394:	vmovups XMMWORD PTR [rsp+0x2a0],xmm0
  41139d:	vmovups XMMWORD PTR [rsp+0x2b0],xmm0
  4113a6:	mov    DWORD PTR [rsp+0x2c0],0x0
  4113b1:	vmovsd xmm0,QWORD PTR [rdx]
  4113b5:	vcomisd xmm0,xmm0
  4113b9:	setne  dl
  4113bc:	movzx  edx,dl
  4113bf:	setp   r8b
  4113c3:	movzx  r8d,r8b
  4113c7:	or     edx,r8d
  4113ca:	test   dl,dl
  4113cc:	je     4113d9 <__swc_fn_3464c816_000146_4dba8c3c+0xa59>
  4113ce:	mov    DWORD PTR [rcx],0x6e616e
  4113d4:	jmp    4119e8 <__swc_fn_3464c816_000146_4dba8c3c+0x1068>
  4113d9:	vcomisd xmm0,xmm11
  4113de:	ja     4113ef <__swc_fn_3464c816_000146_4dba8c3c+0xa6f>
  4113e0:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  4113e9:	vcomisd xmm6,xmm0
  4113ed:	jbe    411413 <__swc_fn_3464c816_000146_4dba8c3c+0xa93>
  4113ef:	vxorpd xmm1,xmm1,xmm1
  4113f3:	vcomisd xmm1,xmm0
  4113f7:	jbe    411408 <__swc_fn_3464c816_000146_4dba8c3c+0xa88>
  4113f9:	mov    DWORD PTR [rcx],0x666e692d
  4113ff:	mov    BYTE PTR [rcx+0x4],0x0
  411403:	jmp    4119e8 <__swc_fn_3464c816_000146_4dba8c3c+0x1068>
  411408:	mov    DWORD PTR [rcx],0x666e69
  41140e:	jmp    4119e8 <__swc_fn_3464c816_000146_4dba8c3c+0x1068>
  411413:	vcomisd xmm0,xmm13
  411418:	jae    411424 <__swc_fn_3464c816_000146_4dba8c3c+0xaa4>
  41141a:	vcomisd xmm12,xmm0
  41141e:	jbe    41178e <__swc_fn_3464c816_000146_4dba8c3c+0xe0e>
  411424:	vmovups xmm1,xmm0
  411428:	vxorpd xmm2,xmm2,xmm2
  41142c:	vcomisd xmm2,xmm0
  411430:	jbe    411440 <__swc_fn_3464c816_000146_4dba8c3c+0xac0>
  411432:	vmovsd xmm0,xmm0,xmm1
  411436:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x2112]        # 413550 <__swc_rdata_base_3464c816+0x440>
  41143e:	jmp    411444 <__swc_fn_3464c816_000146_4dba8c3c+0xac4>
  411440:	vmovsd xmm0,xmm0,xmm1
  411444:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  41144d:	xor    r8d,r8d
  411450:	vcomisd xmm0,xmm6
  411454:	jb     41146e <__swc_fn_3464c816_000146_4dba8c3c+0xaee>
  411456:	cs nop WORD PTR [rax+rax*1+0x0]
  411460:	vdivsd xmm0,xmm0,xmm6
  411464:	add    r8,0x1
  411468:	vcomisd xmm0,xmm6
  41146c:	jae    411460 <__swc_fn_3464c816_000146_4dba8c3c+0xae0>
  41146e:	mov    r9,rcx
  411471:	vxorpd xmm2,xmm2,xmm2
  411475:	vcomisd xmm2,xmm1
  411479:	jbe    411482 <__swc_fn_3464c816_000146_4dba8c3c+0xb02>
  41147b:	mov    BYTE PTR [rcx],0x2d
  41147e:	lea    r9,[rcx+0x1]
  411482:	vcvttsd2si rdx,xmm0
  411487:	mov    r10b,dl
  41148a:	add    r10b,0x30
  41148e:	mov    BYTE PTR [r9],r10b
  411491:	vxorpd xmm1,xmm1,xmm1
  411495:	movzx  edx,dl
  411498:	vcvtsi2sd xmm1,xmm1,rdx
  41149d:	vsubsd xmm0,xmm0,xmm1
  4114a1:	vmulsd xmm0,xmm0,xmm6
  4114a5:	mov    BYTE PTR [r9+0x1],0x2e
  4114aa:	vcvttsd2si rdx,xmm0
  4114af:	mov    r10b,dl
  4114b2:	add    r10b,0x30
  4114b6:	mov    BYTE PTR [r9+0x2],r10b
  4114ba:	vxorpd xmm1,xmm1,xmm1
  4114be:	movzx  edx,dl
  4114c1:	vcvtsi2sd xmm1,xmm1,rdx
  4114c6:	vsubsd xmm0,xmm0,xmm1
  4114ca:	vmulsd xmm0,xmm0,xmm6
  4114ce:	vcvttsd2si rdx,xmm0
  4114d3:	mov    r10b,dl
  4114d6:	add    r10b,0x30
  4114da:	mov    BYTE PTR [r9+0x3],r10b
  4114de:	vxorpd xmm1,xmm1,xmm1
  4114e2:	movzx  edx,dl
  4114e5:	vcvtsi2sd xmm1,xmm1,rdx
  4114ea:	vsubsd xmm0,xmm0,xmm1
  4114ee:	vmulsd xmm0,xmm0,xmm6
  4114f2:	vcvttsd2si rdx,xmm0
  4114f7:	mov    r10b,dl
  4114fa:	add    r10b,0x30
  4114fe:	mov    BYTE PTR [r9+0x4],r10b
  411502:	vxorpd xmm1,xmm1,xmm1
  411506:	movzx  edx,dl
  411509:	vcvtsi2sd xmm1,xmm1,rdx
  41150e:	vsubsd xmm0,xmm0,xmm1
  411512:	vmulsd xmm0,xmm0,xmm6
  411516:	vcvttsd2si rdx,xmm0
  41151b:	mov    r10b,dl
  41151e:	add    r10b,0x30
  411522:	mov    BYTE PTR [r9+0x5],r10b
  411526:	vxorpd xmm1,xmm1,xmm1
  41152a:	movzx  edx,dl
  41152d:	vcvtsi2sd xmm1,xmm1,rdx
  411532:	vsubsd xmm0,xmm0,xmm1
  411536:	vmulsd xmm0,xmm0,xmm6
  41153a:	vcvttsd2si rdx,xmm0
  41153f:	mov    r10b,dl
  411542:	add    r10b,0x30
  411546:	mov    BYTE PTR [r9+0x6],r10b
  41154a:	vxorpd xmm1,xmm1,xmm1
  41154e:	movzx  edx,dl
  411551:	vcvtsi2sd xmm1,xmm1,rdx
  411556:	vsubsd xmm0,xmm0,xmm1
  41155a:	vmulsd xmm0,xmm0,xmm6
  41155e:	vcvttsd2si rdx,xmm0
  411563:	mov    r10b,dl
  411566:	add    r10b,0x30
  41156a:	mov    BYTE PTR [r9+0x7],r10b
  41156e:	vxorpd xmm1,xmm1,xmm1
  411572:	movzx  edx,dl
  411575:	vcvtsi2sd xmm1,xmm1,rdx
  41157a:	vsubsd xmm0,xmm0,xmm1
  41157e:	vmulsd xmm0,xmm0,xmm6
  411582:	vcvttsd2si rdx,xmm0
  411587:	mov    r10b,dl
  41158a:	add    r10b,0x30
  41158e:	mov    BYTE PTR [r9+0x8],r10b
  411592:	vxorpd xmm1,xmm1,xmm1
  411596:	movzx  edx,dl
  411599:	vcvtsi2sd xmm1,xmm1,rdx
  41159e:	vsubsd xmm0,xmm0,xmm1
  4115a2:	vmulsd xmm0,xmm0,xmm6
  4115a6:	vcvttsd2si rdx,xmm0
  4115ab:	mov    r10b,dl
  4115ae:	add    r10b,0x30
  4115b2:	mov    BYTE PTR [r9+0x9],r10b
  4115b6:	vxorpd xmm1,xmm1,xmm1
  4115ba:	movzx  edx,dl
  4115bd:	vcvtsi2sd xmm1,xmm1,rdx
  4115c2:	vsubsd xmm0,xmm0,xmm1
  4115c6:	vmulsd xmm0,xmm0,xmm6
  4115ca:	vcvttsd2si rdx,xmm0
  4115cf:	mov    r10b,dl
  4115d2:	add    r10b,0x30
  4115d6:	mov    BYTE PTR [r9+0xa],r10b
  4115da:	vxorpd xmm1,xmm1,xmm1
  4115de:	movzx  edx,dl
  4115e1:	vcvtsi2sd xmm1,xmm1,rdx
  4115e6:	vsubsd xmm0,xmm0,xmm1
  4115ea:	vmulsd xmm0,xmm0,xmm6
  4115ee:	vcvttsd2si rdx,xmm0
  4115f3:	mov    r10b,dl
  4115f6:	add    r10b,0x30
  4115fa:	mov    BYTE PTR [r9+0xb],r10b
  4115fe:	lea    r10,[r9+0x4]
  411602:	vxorpd xmm1,xmm1,xmm1
  411606:	movzx  edx,dl
  411609:	vcvtsi2sd xmm1,xmm1,rdx
  41160e:	vsubsd xmm0,xmm0,xmm1
  411612:	vmulsd xmm0,xmm0,xmm6
  411616:	vcvttsd2si rdx,xmm0
  41161b:	mov    r11b,dl
  41161e:	add    r11b,0x30
  411622:	mov    BYTE PTR [r9+0xc],r11b
  411626:	vxorpd xmm1,xmm1,xmm1
  41162a:	movzx  edx,dl
  41162d:	vcvtsi2sd xmm1,xmm1,rdx
  411632:	vsubsd xmm0,xmm0,xmm1
  411636:	vmulsd xmm0,xmm0,xmm6
  41163a:	vcvttsd2si rdx,xmm0
  41163f:	mov    r11b,dl
  411642:	add    r11b,0x30
  411646:	mov    BYTE PTR [r9+0xd],r11b
  41164a:	lea    r10,[r10+0x2]
  41164e:	vxorpd xmm1,xmm1,xmm1
  411652:	movzx  edx,dl
  411655:	vcvtsi2sd xmm1,xmm1,rdx
  41165a:	vsubsd xmm0,xmm0,xmm1
  41165e:	vmulsd xmm0,xmm0,xmm6
  411662:	vcvttsd2si rdx,xmm0
  411667:	mov    r11b,dl
  41166a:	add    r11b,0x30
  41166e:	mov    BYTE PTR [r9+0xe],r11b
  411672:	vxorpd xmm1,xmm1,xmm1
  411676:	movzx  edx,dl
  411679:	vcvtsi2sd xmm1,xmm1,rdx
  41167e:	vsubsd xmm0,xmm0,xmm1
  411682:	vmulsd xmm0,xmm0,xmm6
  411686:	vcvttsd2si rdx,xmm0
  41168b:	mov    r11b,dl
  41168e:	add    r11b,0x30
  411692:	mov    BYTE PTR [r9+0xf],r11b
  411696:	lea    r10,[r10+0x2]
  41169a:	lea    r10,[r10+0x2]
  41169e:	lea    r10,[r10+0x2]
  4116a2:	lea    r10,[r10+0x2]
  4116a6:	lea    r10,[r10+0x2]
  4116aa:	vxorpd xmm1,xmm1,xmm1
  4116ae:	movzx  edx,dl
  4116b1:	vcvtsi2sd xmm1,xmm1,rdx
  4116b6:	vsubsd xmm0,xmm0,xmm1
  4116ba:	vmulsd xmm0,xmm0,xmm6
  4116be:	vcvttsd2si rdx,xmm0
  4116c3:	mov    r11b,dl
  4116c6:	add    r11b,0x30
  4116ca:	mov    BYTE PTR [r9+0x10],r11b
  4116ce:	vxorpd xmm1,xmm1,xmm1
  4116d2:	movzx  edx,dl
  4116d5:	vcvtsi2sd xmm1,xmm1,rdx
  4116da:	vsubsd xmm0,xmm0,xmm1
  4116de:	vmulsd xmm0,xmm0,xmm6
  4116e2:	vcvttsd2si rdx,xmm0
  4116e7:	add    dl,0x30
  4116ea:	mov    BYTE PTR [r9+0x11],dl
  4116ee:	mov    BYTE PTR [r10+0x2],0x65
  4116f3:	lea    r9,[r10+0x3]
  4116f7:	test   r8,r8
  4116fa:	jl     411703 <__swc_fn_3464c816_000146_4dba8c3c+0xd83>
  4116fc:	mov    BYTE PTR [r9],0x2b
  411700:	inc    r9
  411703:	mov    r10,r9
  411706:	mov    rdx,r8
  411709:	nop    DWORD PTR [rax+0x0]
  411710:	mov    r11,rdx
  411713:	movabs rdx,0x6666666666666667
  41171d:	mov    rax,r11
  411720:	imul   rdx
  411723:	sar    rdx,0x2
  411727:	mov    r12,rdx
  41172a:	shr    rdx,0x3f
  41172e:	add    r12,rdx
  411731:	mov    rdx,r12
  411734:	imul   r13,r12,0xa
  411738:	sub    r11,r13
  41173b:	mov    r13,QWORD PTR [rip+0x1dfe]        # 413540 <__swc_rdata_base_3464c816+0x430>
  411742:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411747:	mov    BYTE PTR [r10],r11b
  41174a:	lea    r11,[r10+0x1]
  41174e:	mov    r10,r11
  411751:	test   r12,r12
  411754:	jne    411710 <__swc_fn_3464c816_000146_4dba8c3c+0xd90>
  411756:	test   r8,r8
  411759:	jge    411763 <__swc_fn_3464c816_000146_4dba8c3c+0xde3>
  41175b:	mov    BYTE PTR [r11],0x2d
  41175f:	lea    r10,[r11+0x1]
  411763:	mov    BYTE PTR [r10],0x0
  411767:	sub    r10,0x1
  41176b:	nop    DWORD PTR [rax+rax*1+0x0]
  411770:	cmp    r9,r10
  411773:	jae    4119e8 <__swc_fn_3464c816_000146_4dba8c3c+0x1068>
  411779:	mov    al,BYTE PTR [r10]
  41177c:	mov    dl,BYTE PTR [r9]
  41177f:	mov    BYTE PTR [r10],dl
  411782:	sub    r10,0x1
  411786:	mov    BYTE PTR [r9],al
  411789:	inc    r9
  41178c:	jmp    411770 <__swc_fn_3464c816_000146_4dba8c3c+0xdf0>
  41178e:	vcvttsd2si rdx,xmm0
  411793:	mov    r8,rdx
  411796:	vxorpd xmm1,xmm1,xmm1
  41179a:	vcvtsi2sd xmm1,xmm1,rdx
  41179f:	vsubsd xmm1,xmm0,xmm1
  4117a3:	mov    r9d,0x8
  4117a9:	vxorpd xmm2,xmm2,xmm2
  4117ad:	vcomisd xmm2,xmm1
  4117b1:	ja     4117be <__swc_fn_3464c816_000146_4dba8c3c+0xe3e>
  4117b3:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  4117bc:	jmp    4117cf <__swc_fn_3464c816_000146_4dba8c3c+0xe4f>
  4117be:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1d8a]        # 413550 <__swc_rdata_base_3464c816+0x440>
  4117c6:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  4117cf:	test   r9d,r9d
  4117d2:	je     4117e9 <__swc_fn_3464c816_000146_4dba8c3c+0xe69>
  4117d4:	cs nop WORD PTR [rax+rax*1+0x0]
  4117de:	xchg   ax,ax
  4117e0:	vmulsd xmm1,xmm1,xmm6
  4117e4:	dec    r9d
  4117e7:	jne    4117e0 <__swc_fn_3464c816_000146_4dba8c3c+0xe60>
  4117e9:	vcvttsd2si r9,xmm1
  4117ee:	mov    r10,r9
  4117f1:	vxorpd xmm2,xmm2,xmm2
  4117f5:	vcvtsi2sd xmm2,xmm2,r9
  4117fa:	vsubsd xmm1,xmm1,xmm2
  4117fe:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  411807:	vcomisd xmm1,xmm6
  41180b:	lea    r9,[r9+0x1]
  41180f:	cmova  r10,r9
  411813:	cmp    r10,0x5f5e100
  41181a:	jne    411833 <__swc_fn_3464c816_000146_4dba8c3c+0xeb3>
  41181c:	lea    r8,[rdx-0x1]
  411820:	vxorpd xmm1,xmm1,xmm1
  411824:	vcomisd xmm1,xmm0
  411828:	lea    rdx,[rdx+0x1]
  41182c:	cmovbe r8,rdx
  411830:	xor    r10d,r10d
  411833:	mov    r9,rcx
  411836:	test   r8,r8
  411839:	jne    411859 <__swc_fn_3464c816_000146_4dba8c3c+0xed9>
  41183b:	vxorpd xmm1,xmm1,xmm1
  41183f:	vcomisd xmm1,xmm0
  411843:	jbe    41184c <__swc_fn_3464c816_000146_4dba8c3c+0xecc>
  411845:	mov    BYTE PTR [rcx],0x2d
  411848:	lea    r9,[rcx+0x1]
  41184c:	mov    BYTE PTR [r9],0x30
  411850:	add    r9,0x1
  411854:	jmp    4118eb <__swc_fn_3464c816_000146_4dba8c3c+0xf6b>
  411859:	mov    r9,rcx
  41185c:	mov    rdx,r8
  41185f:	nop
  411860:	mov    r11,rdx
  411863:	movabs rdx,0x6666666666666667
  41186d:	mov    r15,rax
  411870:	mov    rax,r11
  411873:	imul   rdx
  411876:	mov    r12,rdx
  411879:	mov    rax,r15
  41187c:	sar    r12,0x2
  411880:	mov    rdx,r12
  411883:	shr    rdx,0x3f
  411887:	add    r12,rdx
  41188a:	mov    rdx,r12
  41188d:	imul   r13,r12,0xa
  411891:	sub    r11,r13
  411894:	mov    r13,QWORD PTR [rip+0x1ca5]        # 413540 <__swc_rdata_base_3464c816+0x430>
  41189b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4118a0:	mov    BYTE PTR [r9],r11b
  4118a3:	lea    r11,[r9+0x1]
  4118a7:	mov    r9,r11
  4118aa:	test   r12,r12
  4118ad:	jne    411860 <__swc_fn_3464c816_000146_4dba8c3c+0xee0>
  4118af:	test   r8,r8
  4118b2:	jge    4118bc <__swc_fn_3464c816_000146_4dba8c3c+0xf3c>
  4118b4:	mov    BYTE PTR [r11],0x2d
  4118b8:	lea    r9,[r11+0x1]
  4118bc:	mov    rdx,r9
  4118bf:	mov    BYTE PTR [r9],0x0
  4118c3:	sub    r9,0x1
  4118c7:	mov    r8,rcx
  4118ca:	cmp    r8,r9
  4118cd:	jae    4118e8 <__swc_fn_3464c816_000146_4dba8c3c+0xf68>
  4118cf:	nop
  4118d0:	mov    r11b,BYTE PTR [r9]
  4118d3:	mov    r12b,BYTE PTR [r8]
  4118d6:	mov    BYTE PTR [r9],r12b
  4118d9:	sub    r9,0x1
  4118dd:	mov    BYTE PTR [r8],r11b
  4118e0:	inc    r8
  4118e3:	cmp    r8,r9
  4118e6:	jb     4118d0 <__swc_fn_3464c816_000146_4dba8c3c+0xf50>
  4118e8:	mov    r9,rdx
  4118eb:	mov    BYTE PTR [r9],0x2e
  4118ef:	add    r9,0x1
  4118f3:	xor    r8d,r8d
  4118f6:	test   r10,r10
  4118f9:	je     41193f <__swc_fn_3464c816_000146_4dba8c3c+0xfbf>
  4118fb:	mov    r11d,0x989680
  411901:	cmp    r10,r11
  411904:	jge    41193f <__swc_fn_3464c816_000146_4dba8c3c+0xfbf>
  411906:	cs nop WORD PTR [rax+rax*1+0x0]
  411910:	inc    r8d
  411913:	movabs rdx,0x6666666666666667
  41191d:	mov    r15,rax
  411920:	mov    rax,r11
  411923:	imul   rdx
  411926:	mov    r11,rdx
  411929:	mov    rax,r15
  41192c:	sar    r11,0x2
  411930:	mov    rdx,r11
  411933:	shr    rdx,0x3f
  411937:	add    r11,rdx
  41193a:	cmp    r10,r11
  41193d:	jl     411910 <__swc_fn_3464c816_000146_4dba8c3c+0xf90>
  41193f:	test   r8d,r8d
  411942:	je     41195d <__swc_fn_3464c816_000146_4dba8c3c+0xfdd>
  411944:	cs nop WORD PTR [rax+rax*1+0x0]
  41194e:	xchg   ax,ax
  411950:	mov    BYTE PTR [r9],0x30
  411954:	add    r9,0x1
  411958:	dec    r8d
  41195b:	jne    411950 <__swc_fn_3464c816_000146_4dba8c3c+0xfd0>
  41195d:	mov    r8,r9
  411960:	mov    rdx,r10
  411963:	cs nop WORD PTR [rax+rax*1+0x0]
  41196d:	nop    DWORD PTR [rax]
  411970:	mov    r11,rdx
  411973:	movabs rdx,0x6666666666666667
  41197d:	mov    rax,r11
  411980:	imul   rdx
  411983:	sar    rdx,0x2
  411987:	mov    r12,rdx
  41198a:	shr    rdx,0x3f
  41198e:	add    r12,rdx
  411991:	mov    rdx,r12
  411994:	imul   r13,r12,0xa
  411998:	sub    r11,r13
  41199b:	mov    r13,QWORD PTR [rip+0x1b9e]        # 413540 <__swc_rdata_base_3464c816+0x430>
  4119a2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4119a7:	mov    BYTE PTR [r8],r11b
  4119aa:	lea    r11,[r8+0x1]
  4119ae:	mov    r8,r11
  4119b1:	test   r12,r12
  4119b4:	jne    411970 <__swc_fn_3464c816_000146_4dba8c3c+0xff0>
  4119b6:	test   r10,r10
  4119b9:	jge    4119c3 <__swc_fn_3464c816_000146_4dba8c3c+0x1043>
  4119bb:	mov    BYTE PTR [r11],0x2d
  4119bf:	lea    r8,[r11+0x1]
  4119c3:	mov    BYTE PTR [r8],0x0
  4119c7:	sub    r8,0x1
  4119cb:	cmp    r9,r8
  4119ce:	jae    4119e8 <__swc_fn_3464c816_000146_4dba8c3c+0x1068>
  4119d0:	mov    al,BYTE PTR [r8]
  4119d3:	mov    dl,BYTE PTR [r9]
  4119d6:	mov    BYTE PTR [r8],dl
  4119d9:	sub    r8,0x1
  4119dd:	mov    BYTE PTR [r9],al
  4119e0:	inc    r9
  4119e3:	cmp    r9,r8
  4119e6:	jb     4119d0 <__swc_fn_3464c816_000146_4dba8c3c+0x1050>
  4119e8:	xor    eax,eax
  4119ea:	test   rcx,rcx
  4119ed:	je     411a10 <__swc_fn_3464c816_000146_4dba8c3c+0x1090>
  4119ef:	mov    rdx,rcx
  4119f2:	mov    r8b,BYTE PTR [rdx]
  4119f5:	test   r8b,r8b
  4119f8:	je     411a10 <__swc_fn_3464c816_000146_4dba8c3c+0x1090>
  4119fa:	nop    WORD PTR [rax+rax*1+0x0]
  411a00:	add    rdx,0x1
  411a04:	add    rax,0x1
  411a08:	mov    r8b,BYTE PTR [rdx]
  411a0b:	test   r8b,r8b
  411a0e:	jne    411a00 <__swc_fn_3464c816_000146_4dba8c3c+0x1080>
  411a10:	mov    QWORD PTR [rsp+0x3f8],rcx
  411a18:	mov    QWORD PTR [rsp+0x400],rax
  411a20:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  411a29:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  411a32:	lea    rcx,[rsp+0x408]
  411a3a:	call   410100 <__swc_fn_3464c816_000116_18ca1307>
  411a3f:	jmp    411a85 <__swc_fn_3464c816_000146_4dba8c3c+0x1105>
  411a41:	mov    rcx,rdx
  411a44:	call   410100 <__swc_fn_3464c816_000116_18ca1307>
  411a49:	jmp    411a85 <__swc_fn_3464c816_000146_4dba8c3c+0x1105>
  411a4b:	mov    al,BYTE PTR [rdx]
  411a4d:	test   al,al
  411a4f:	je     411a5a <__swc_fn_3464c816_000146_4dba8c3c+0x10da>
  411a51:	lea    rax,[rip+0x1b08]        # 413560 <__swc_rdata_base_3464c816+0x450>
  411a58:	jmp    411a61 <__swc_fn_3464c816_000146_4dba8c3c+0x10e1>
  411a5a:	lea    rax,[rip+0x1b0f]        # 413570 <__swc_rdata_base_3464c816+0x460>
  411a61:	mov    rcx,rax
  411a64:	call   410100 <__swc_fn_3464c816_000116_18ca1307>
  411a69:	jmp    411a85 <__swc_fn_3464c816_000146_4dba8c3c+0x1105>
  411a6b:	lea    rcx,[rip+0x1b0e]        # 413580 <__swc_rdata_base_3464c816+0x470>
  411a72:	call   410100 <__swc_fn_3464c816_000116_18ca1307>
  411a77:	jmp    411a85 <__swc_fn_3464c816_000146_4dba8c3c+0x1105>
  411a79:	lea    rcx,[rip+0x1b00]        # 413580 <__swc_rdata_base_3464c816+0x470>
  411a80:	call   410100 <__swc_fn_3464c816_000116_18ca1307>
  411a85:	add    rdi,0x1
  411a89:	sub    rsi,0x1
  411a8d:	vmovups xmm0,xmm12
  411a92:	vmovsd xmm6,QWORD PTR [rip+0x1af6]        # 413590 <__swc_rdata_base_3464c816+0x480>
  411a9a:	test   rsi,rsi
  411a9d:	jne    410a90 <__swc_fn_3464c816_000146_4dba8c3c+0x110>
  411aa3:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  411aac:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  411ab5:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  411abe:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411ac7:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411ad0:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411ad9:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411ae2:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  411aeb:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411af4:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  411afd:	add    rsp,0x4e8
  411b04:	pop    r15
  411b06:	pop    r13
  411b08:	pop    r12
  411b0a:	pop    rdi
  411b0b:	pop    rsi
  411b0c:	pop    rbx
  411b0d:	ret
