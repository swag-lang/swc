
/workspace/prompt2-20261115/session-combined-micro/base/leven/leven:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <getpid@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <getpid@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <munmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <munmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <exit@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <exit@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <pthread_key_create@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <pthread_key_create@GLIBC_2.34>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_setspecific@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <pthread_setspecific@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <syscall@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <syscall@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dladdr@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <dladdr@GLIBC_2.34>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <open@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <open@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <lseek@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <lseek@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <close@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <close@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <mmap@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <mmap@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <malloc@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <malloc@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <madvise@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf9a]        # 413080 <madvise@GLIBC_2.2.5>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <pthread_key_delete@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf92]        # 413088 <pthread_key_delete@GLIBC_2.34>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <gettid@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf8a]        # 413090 <gettid@GLIBC_2.30>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <flock@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf82]        # 413098 <flock@GLIBC_2.2.5>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <__errno_location@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf7a]        # 4130a0 <__errno_location@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <opendir@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf72]        # 4130a8 <opendir@GLIBC_2.2.5>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <dirfd@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf6a]        # 4130b0 <dirfd@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <readdir@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf62]        # 4130b8 <readdir@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <readlinkat@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <readlinkat@GLIBC_2.4>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <openat@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <openat@GLIBC_2.4>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <closedir@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <closedir@GLIBC_2.2.5>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <memfd_create@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <memfd_create@GLIBC_2.27>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <ftruncate@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <ftruncate@GLIBC_2.2.5>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <write@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <write@GLIBC_2.2.5>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <backtrace@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <backtrace@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <clock_gettime@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <clock_gettime@GLIBC_2.17>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <__x86_get_cpuid_feature_leaf@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <free@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <free@GLIBC_2.2.5>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_fc36583a_000176_1ca87929+0xea0>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40d280 <__swc_fn_fc36583a_000121_12b4ed22>
  40724e:	xor    ecx,ecx
  407250:	call   40c9a0 <__swc_fn_fc36583a_000094_14db3cf9>
  407255:	call   40a380 <__swc_fn_fc36583a_000177_aa67484d>
  40725a:	call   40f730 <__swc_fn_fc36583a_000095_337e587a>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_fc36583a_000000_46f18a51>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_fc36583a_000003_7ab4792e>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_fc36583a_000003_7ab4792e+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   409260 <__swc_fn_fc36583a_000111_b25e3a45>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_fc36583a_000003_7ab4792e+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1cd81]        # 424048 <__swc_bss_base_fc36583a+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1cd7a]        # 424048 <__swc_bss_base_fc36583a+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_fc36583a_000003_7ab4792e+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_fc36583a_000003_7ab4792e+0x30>
  4072e6:	lea    rcx,[rip+0x1cd63]        # 424050 <__swc_bss_base_fc36583a+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1cd5c]        # 424050 <__swc_bss_base_fc36583a+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_fc36583a_000003_7ab4792e+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_fc36583a_000003_7ab4792e+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_fc36583a_000006_a23dca5f>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40dfe0 <__swc_fn_fc36583a_000011_6493fbbc>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_fc36583a_000012_c7df5d22>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_fc36583a_000006_a23dca5f+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_fc36583a_000003_7ab4792e>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_fc36583a_000006_a23dca5f+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_fc36583a_000009_d7e2bb25>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_fc36583a_000009_d7e2bb25+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40ad30 <__swc_fn_fc36583a_000007_614a4804>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40dfd0 <__swc_fn_fc36583a_000008_4e857afc>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_fc36583a_000009_d7e2bb25+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_fc36583a_000009_d7e2bb25+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_fc36583a_000012_c7df5d22>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_fc36583a_000015_07eb9884>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_fc36583a_000015_07eb9884+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_fc36583a_000015_07eb9884+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_fc36583a_000015_07eb9884+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_fc36583a_000015_07eb9884+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40e140 <__swc_fn_fc36583a_000017_4df2d1a0>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_fc36583a_000015_07eb9884+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1cb3d]        # 424058 <__swc_bss_base_fc36583a+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1cb36]        # 424058 <__swc_bss_base_fc36583a+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_fc36583a_000015_07eb9884+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_fc36583a_000015_07eb9884+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40dfe0 <__swc_fn_fc36583a_000011_6493fbbc>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_fc36583a_000015_07eb9884+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   40cfa0 <__swc_fn_fc36583a_000112_759e9ceb>
  407569:	lea    rcx,[rip+0x1cad8]        # 424048 <__swc_bss_base_fc36583a+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1cad1]        # 424048 <__swc_bss_base_fc36583a+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_fc36583a_000015_07eb9884+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_fc36583a_000015_07eb9884+0x110>
  407598:	lea    rcx,[rip+0x1cac1]        # 424060 <__swc_bss_base_fc36583a+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1caba]        # 424060 <__swc_bss_base_fc36583a+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_fc36583a_000015_07eb9884+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_fc36583a_000015_07eb9884+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_fc36583a_000018_7d1e8a10>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_fc36583a_000015_07eb9884+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_fc36583a_000018_7d1e8a10>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_fc36583a_000018_7d1e8a10+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_fc36583a_000018_7d1e8a10+0x10>

0000000000407630 <__swc_fn_fc36583a_000021_491ac000>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_fc36583a_000015_07eb9884>
  40763e:	lea    rdi,[rip+0x1cbab]        # 4241f0 <__swc_bss_base_fc36583a+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   4098c0 <__swc_fn_fc36583a_000135_e3032dc2>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1cb94]        # 4241f8 <__swc_bss_base_fc36583a+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1cb89],rsi        # 4241f8 <__swc_bss_base_fc36583a+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_fc36583a_000024_4aca8b9e>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_fc36583a_000027_4aca8b9e>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_fc36583a_000030_06a93956>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_fc36583a_000030_06a93956+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1a92c]        # 422000 <__swc_data_base_fc36583a>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_fc36583a_000030_06a93956+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_fc36583a_000030_06a93956+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_fc36583a_000030_06a93956+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40e300 <__swc_fn_fc36583a_000032_84881cd8>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_fc36583a_000030_06a93956+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_fc36583a_000036_8d895ba1>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_fc36583a_000030_06a93956+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_fc36583a_000042_bab03645>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_fc36583a_000033_7ca1566d>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40b1e0 <__swc_fn_fc36583a_000031_90860ff2>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   409740 <__swc_fn_fc36583a_000129_74b163fe>
  407734:	mov    rcx,rsi
  407737:	call   40e300 <__swc_fn_fc36583a_000032_84881cd8>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_fc36583a_000036_8d895ba1>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_fc36583a_000039_40d1e569>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_fc36583a_000039_40d1e569+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_fc36583a_000039_40d1e569+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_fc36583a_000039_40d1e569+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_fc36583a_000039_40d1e569+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_fc36583a_000039_40d1e569+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   409340 <__swc_fn_fc36583a_000114_27d95464>
  4077ca:	lea    rcx,[rip+0x1c877]        # 424048 <__swc_bss_base_fc36583a+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1c870]        # 424048 <__swc_bss_base_fc36583a+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_fc36583a_000039_40d1e569+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_fc36583a_000039_40d1e569+0x90>
  4077f8:	lea    rcx,[rip+0x1c861]        # 424060 <__swc_bss_base_fc36583a+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1c85a]        # 424060 <__swc_bss_base_fc36583a+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_fc36583a_000039_40d1e569+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_fc36583a_000039_40d1e569+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_fc36583a_000042_bab03645>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_fc36583a_000042_bab03645+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40e8d0 <__swc_fn_fc36583a_000059_3ca3ac64>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   4098c0 <__swc_fn_fc36583a_000135_e3032dc2>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_fc36583a_000042_bab03645+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_fc36583a_000042_bab03645+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_fc36583a_000009_d7e2bb25>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_fc36583a_000042_bab03645+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40e000 <__swc_fn_fc36583a_000014_afb279e2>
  40791e:	jmp    407941 <__swc_fn_fc36583a_000042_bab03645+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_fc36583a_000042_bab03645+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_fc36583a_000042_bab03645+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_fc36583a_000042_bab03645+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40b3a0 <__swc_fn_fc36583a_000043_957e4917>
  407997:	mov    rcx,rdi
  40799a:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_fc36583a_000039_40d1e569>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_fc36583a_000045_1fe0f4e2>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_fc36583a_000045_1fe0f4e2+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_fc36583a_000045_1fe0f4e2+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_fc36583a_000045_1fe0f4e2+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_fc36583a_000045_1fe0f4e2+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   4098c0 <__swc_fn_fc36583a_000135_e3032dc2>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_fc36583a_000045_1fe0f4e2+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_fc36583a_000045_1fe0f4e2+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_fc36583a_000045_1fe0f4e2+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_fc36583a_000045_1fe0f4e2+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_fc36583a_000009_d7e2bb25>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_fc36583a_000045_1fe0f4e2+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_fc36583a_000045_1fe0f4e2+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_fc36583a_000045_1fe0f4e2+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_fc36583a_000045_1fe0f4e2+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_fc36583a_000045_1fe0f4e2+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40ade0 <__swc_fn_fc36583a_000013_9ba72deb>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_fc36583a_000045_1fe0f4e2+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_fc36583a_000045_1fe0f4e2+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_fc36583a_000045_1fe0f4e2+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_fc36583a_000045_1fe0f4e2+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40e180 <__swc_fn_fc36583a_000020_a66e8b97>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_fc36583a_000045_1fe0f4e2+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40ade0 <__swc_fn_fc36583a_000013_9ba72deb>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_fc36583a_000045_1fe0f4e2+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_fc36583a_000021_491ac000>
  407c07:	mov    rcx,r14
  407c0a:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_fc36583a_000045_1fe0f4e2+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_fc36583a_000045_1fe0f4e2+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_fc36583a_000045_1fe0f4e2+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_fc36583a_000048_c877e9d2>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_fc36583a_000048_c877e9d2+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_fc36583a_000048_c877e9d2+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_fc36583a_000048_c877e9d2+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_fc36583a_000048_c877e9d2+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40e530 <__swc_fn_fc36583a_000047_bc5ec610>
  407d14:	jmp    407ce0 <__swc_fn_fc36583a_000048_c877e9d2+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_fc36583a_000048_c877e9d2+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_fc36583a_000048_c877e9d2+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_fc36583a_000048_c877e9d2+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_fc36583a_000048_c877e9d2+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_fc36583a_000048_c877e9d2+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_fc36583a_000048_c877e9d2+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_fc36583a_000048_c877e9d2+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_fc36583a_000051_f7021588>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_fc36583a_000051_f7021588+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_fc36583a_000051_f7021588+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_fc36583a_000051_f7021588+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_fc36583a_000051_f7021588+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40e490 <__swc_fn_fc36583a_000044_9c2ade9b>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40e000 <__swc_fn_fc36583a_000014_afb279e2>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_fc36583a_000054_ae20ea33>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   4098c0 <__swc_fn_fc36583a_000135_e3032dc2>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_fc36583a_000054_ae20ea33+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_fc36583a_000054_ae20ea33+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_fc36583a_000054_ae20ea33+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_fc36583a_000057_5b81d8b6>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_fc36583a_000060_e6407a0a>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_fc36583a_000060_e6407a0a+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_fc36583a_000039_40d1e569>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_fc36583a_000060_e6407a0a+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_fc36583a_000063_c8a062d6>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40b720 <__swc_fn_fc36583a_000052_c7484fb0>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_fc36583a_000054_ae20ea33>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_fc36583a_000063_c8a062d6+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_fc36583a_000063_c8a062d6+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40b840 <__swc_fn_fc36583a_000058_8bd8d1d5>
  407f7f:	mov    rcx,rsi
  407f82:	call   40b480 <__swc_fn_fc36583a_000049_2ff013cc>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_fc36583a_000066_254b71af>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_fc36583a_000066_254b71af+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1c049]        # 424070 <__swc_bss_base_fc36583a+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1c04b]        # 424080 <__swc_bss_base_fc36583a+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_fc36583a_000066_254b71af+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_fc36583a_000066_254b71af+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40b110 <__swc_fn_fc36583a_000022_3a2e2048>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_fc36583a_000066_254b71af+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_fc36583a_000063_c8a062d6>
  40808f:	jmp    408122 <__swc_fn_fc36583a_000066_254b71af+0x192>
  408094:	lea    rax,[rip+0x19f65]        # 422000 <__swc_data_base_fc36583a>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_fc36583a_000066_254b71af+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_fc36583a_000066_254b71af+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_fc36583a_000066_254b71af+0x135>
  4080b8:	call   40b1e0 <__swc_fn_fc36583a_000031_90860ff2>
  4080bd:	mov    rcx,rax
  4080c0:	call   410500 <__swc_fn_fc36583a_000128_41c3251c>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_fc36583a_000066_254b71af+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_fc36583a_000066_254b71af+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_fc36583a_000066_254b71af+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40e530 <__swc_fn_fc36583a_000047_bc5ec610>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_fc36583a_000066_254b71af+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_fc36583a_000051_f7021588>
  408115:	jmp    408122 <__swc_fn_fc36583a_000066_254b71af+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40ad50 <__swc_fn_fc36583a_000010_395bb04b>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_fc36583a_000069_e681a956>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_fc36583a_000036_8d895ba1>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_fc36583a_000069_e681a956+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1c09a]        # 424240 <__swc_bss_base_fc36583a+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_fc36583a_000069_e681a956+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   4098c0 <__swc_fn_fc36583a_000135_e3032dc2>
  4081b5:	mov    rcx,rsi
  4081b8:	call   40ed00 <__swc_fn_fc36583a_000068_7d4c42bf>
  4081bd:	mov    rcx,rsi
  4081c0:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_fc36583a_000072_bfa08900>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40ea50 <__swc_fn_fc36583a_000065_f9f4b610>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_fc36583a_000075_524b0734>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   40ed00 <__swc_fn_fc36583a_000068_7d4c42bf>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_fc36583a_000078_a120bd2b>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_fc36583a_000078_a120bd2b+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_fc36583a_000078_a120bd2b+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_fc36583a_000081_c25a0e73>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_fc36583a_000084_ddf2b8a1>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_fc36583a_000090_a2d50c23>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_fc36583a_000084_ddf2b8a1+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_fc36583a_000084_ddf2b8a1+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_fc36583a_000084_ddf2b8a1+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_fc36583a_000084_ddf2b8a1+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_fc36583a_000090_a2d50c23>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_fc36583a_000084_ddf2b8a1+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_fc36583a_000084_ddf2b8a1+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_fc36583a_000084_ddf2b8a1+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_fc36583a_000084_ddf2b8a1+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_fc36583a_000084_ddf2b8a1+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_fc36583a_000084_ddf2b8a1+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_fc36583a_000084_ddf2b8a1+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_fc36583a_000084_ddf2b8a1+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_fc36583a_000084_ddf2b8a1+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_fc36583a_000084_ddf2b8a1+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40c820 <__swc_fn_fc36583a_000082_754dcd57>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_fc36583a_000084_ddf2b8a1+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_fc36583a_000084_ddf2b8a1+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_fc36583a_000084_ddf2b8a1+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40c820 <__swc_fn_fc36583a_000082_754dcd57>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_fc36583a_000084_ddf2b8a1+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_fc36583a_000084_ddf2b8a1>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_fc36583a_000084_ddf2b8a1+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_fc36583a_000084_ddf2b8a1+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_fc36583a_000087_ea575bb3>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_fc36583a_000090_a2d50c23>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_fc36583a_000087_ea575bb3+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   40f160 <__swc_fn_fc36583a_000086_c45095aa>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_fc36583a_000087_ea575bb3+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_fc36583a_000087_ea575bb3+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_fc36583a_000087_ea575bb3+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40c820 <__swc_fn_fc36583a_000082_754dcd57>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_fc36583a_000087_ea575bb3+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_fc36583a_000087_ea575bb3>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_fc36583a_000087_ea575bb3+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_fc36583a_000087_ea575bb3+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_fc36583a_000090_a2d50c23>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_fc36583a_000090_a2d50c23+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_fc36583a_000090_a2d50c23+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_fc36583a_000090_a2d50c23+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_fc36583a_000090_a2d50c23+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40c820 <__swc_fn_fc36583a_000082_754dcd57>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40c820 <__swc_fn_fc36583a_000082_754dcd57>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_fc36583a_000090_a2d50c23+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_fc36583a_000090_a2d50c23+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_fc36583a_000090_a2d50c23+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_fc36583a_000090_a2d50c23+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_fc36583a_000090_a2d50c23>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_fc36583a_000090_a2d50c23+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_fc36583a_000090_a2d50c23+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_fc36583a_000090_a2d50c23+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_fc36583a_000090_a2d50c23+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_fc36583a_000090_a2d50c23+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_fc36583a_000090_a2d50c23+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_fc36583a_000090_a2d50c23+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_fc36583a_000090_a2d50c23+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_fc36583a_000090_a2d50c23+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_fc36583a_000090_a2d50c23+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_fc36583a_000090_a2d50c23+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_fc36583a_000090_a2d50c23+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_fc36583a_000090_a2d50c23+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_fc36583a_000090_a2d50c23+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_fc36583a_000090_a2d50c23+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_fc36583a_000090_a2d50c23+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   409de0 <__swc_fn_fc36583a_000147_32a497f3>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_fc36583a_000090_a2d50c23+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_fc36583a_000090_a2d50c23>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_fc36583a_000090_a2d50c23+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_fc36583a_000090_a2d50c23+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_fc36583a_000090_a2d50c23+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   409de0 <__swc_fn_fc36583a_000147_32a497f3>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   409de0 <__swc_fn_fc36583a_000147_32a497f3>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_fc36583a_000093_f8c16535>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40c950 <__swc_fn_fc36583a_000091_3d2f5a0d>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_fc36583a_000093_f8c16535+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_fc36583a_000093_f8c16535+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   4106a0 <__swc_fn_fc36583a_000137_a4ba10ed>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_fc36583a_000093_f8c16535+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0xa872]        # 4131c0 <__swc_rdata_base_fc36583a+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   4101c0 <__swc_fn_fc36583a_000116_035d76a1>
  408959:	call   40d1d0 <__swc_fn_fc36583a_000118_7f430081>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_fc36583a_000096_ad982b35>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40896f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408975:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40897b:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  408981:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  408987:	mov    QWORD PTR [rsp+0x48],rdx
  40898c:	mov    rax,r8
  40898f:	cmp    r8,0x1
  408993:	mov    edx,0x1
  408998:	cmovb  rax,rdx
  40899c:	mov    QWORD PTR [rsp+0x50],rax
  4089a1:	mov    rbx,QWORD PTR [rcx+0x8]
  4089a5:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a9:	mov    rcx,QWORD PTR [rcx]
  4089ac:	lea    rdx,[rsp+0x8]
  4089b1:	call   rbx
  4089b3:	add    rsp,0x70
  4089b7:	pop    rbx
  4089b8:	ret
  4089b9:	add    BYTE PTR [rax],al
  4089bb:	add    BYTE PTR [rax],al
  4089bd:	add    BYTE PTR [rax],al
	...

00000000004089c0 <__swc_fn_fc36583a_000099_b4c6da83>:
  4089c0:	push   rbx
  4089c1:	push   rsi
  4089c2:	push   rdi
  4089c3:	sub    rsp,0x30
  4089c7:	mov    rbx,rcx
  4089ca:	test   rcx,rcx
  4089cd:	je     4089e2 <__swc_fn_fc36583a_000099_b4c6da83+0x22>
  4089cf:	mov    rcx,rbx
  4089d2:	mov    edx,0x1
  4089d7:	call   408200 <__swc_fn_fc36583a_000078_a120bd2b>
  4089dc:	cmp    rax,0x1
  4089e0:	je     4089ea <__swc_fn_fc36583a_000099_b4c6da83+0x2a>
  4089e2:	add    rsp,0x30
  4089e6:	pop    rdi
  4089e7:	pop    rsi
  4089e8:	pop    rbx
  4089e9:	ret
  4089ea:	lea    rsi,[rsp+0x8]
  4089ef:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089f4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089fa:	lea    rax,[rsp+0x18]
  4089ff:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  408a04:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408a0a:	mov    rcx,QWORD PTR [rsp+0x20]
  408a0f:	test   rcx,rcx
  408a12:	je     408a28 <__swc_fn_fc36583a_000099_b4c6da83+0x68>
  408a14:	test   DWORD PTR [rcx+0x28],0x400000
  408a1b:	je     408a28 <__swc_fn_fc36583a_000099_b4c6da83+0x68>
  408a1d:	mov    rdx,QWORD PTR [rcx+0x30]
  408a21:	test   rdx,rdx
  408a24:	cmovne rcx,rdx
  408a28:	mov    edi,DWORD PTR [rcx+0x20]
  408a2b:	mov    rcx,rax
  408a2e:	call   40cb30 <__swc_fn_fc36583a_000100_3ed08774>
  408a33:	mov    rcx,rsi
  408a36:	mov    rdx,QWORD PTR [rsp+0x18]
  408a3b:	mov    r8,rdi
  408a3e:	call   408960 <__swc_fn_fc36583a_000096_ad982b35>
  408a43:	mov    rcx,QWORD PTR [rbx+0x28]
  408a47:	call   40f740 <__swc_fn_fc36583a_000098_00f01091>
  408a4c:	mov    rcx,rsi
  408a4f:	mov    rdx,rbx
  408a52:	mov    r8d,0x30
  408a58:	call   408960 <__swc_fn_fc36583a_000096_ad982b35>
  408a5d:	add    rsp,0x30
  408a61:	pop    rdi
  408a62:	pop    rsi
  408a63:	pop    rbx
  408a64:	ret
	...

0000000000408a80 <__swc_fn_fc36583a_000102_e9fdc18e>:
  408a80:	push   rbp
  408a81:	push   rbx
  408a82:	push   rsi
  408a83:	push   rdi
  408a84:	push   r12
  408a86:	push   r13
  408a88:	push   r14
  408a8a:	push   r15
  408a8c:	sub    rsp,0x500
  408a93:	mov    rbp,rsp
  408a96:	mov    rbx,rsp
  408a99:	mov    rsi,rdx
  408a9c:	mov    rdi,rcx
  408a9f:	mov    rcx,QWORD PTR [rip+0x1e29a]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  408aa6:	test   rcx,rcx
  408aa9:	jne    408ac3 <__swc_fn_fc36583a_000102_e9fdc18e+0x43>
  408aab:	sub    rsp,0x8
  408aaf:	call   40a1d0 <__swc_fn_fc36583a_000165_cf398896>
  408ab4:	add    rsp,0x8
  408ab8:	lea    rcx,[rax+0x1]
  408abc:	mov    QWORD PTR [rip+0x1e27d],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  408ac3:	dec    rcx
  408ac6:	sub    rsp,0x8
  408aca:	call   411fc0 <__swc_fn_fc36583a_000167_fce60b2b>
  408acf:	add    rsp,0x8
  408ad3:	mov    r12,rax
  408ad6:	mov    QWORD PTR [rsp+0x4f0],rax
  408ade:	lea    rax,[rip+0xa81b]        # 413300 <__swc_rdata_base_fc36583a+0x1f0>
  408ae5:	sub    rsp,0x20
  408ae9:	mov    rcx,rsp
  408aec:	mov    QWORD PTR [rcx],rax
  408aef:	lea    r13,[rip+0xa81a]        # 413310 <__swc_rdata_base_fc36583a+0x200>
  408af6:	mov    QWORD PTR [rcx+0x8],r13
  408afa:	mov    QWORD PTR [rcx+0x10],rsp
  408afe:	mov    QWORD PTR [rcx+0x18],0x1
  408b06:	lea    rcx,[rsp+0x10]
  408b0b:	sub    rsp,0x8
  408b0f:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  408b14:	add    rsp,0x8
  408b18:	add    rsp,0x20
  408b1c:	lea    rax,[rip+0xa835]        # 413358 <__swc_rdata_base_fc36583a+0x248>
  408b23:	sub    rsp,0x20
  408b27:	mov    rcx,rsp
  408b2a:	mov    QWORD PTR [rcx],rax
  408b2d:	mov    QWORD PTR [rcx+0x8],r13
  408b31:	mov    QWORD PTR [rcx+0x10],rsp
  408b35:	mov    QWORD PTR [rcx+0x18],0x1
  408b3d:	lea    rcx,[rsp+0x10]
  408b42:	sub    rsp,0x8
  408b46:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  408b4b:	add    rsp,0x8
  408b4f:	add    rsp,0x20
  408b53:	lea    r14,[rip+0xa80e]        # 413368 <__swc_rdata_base_fc36583a+0x258>
  408b5a:	sub    rsp,0x50
  408b5e:	mov    rax,rsp
  408b61:	vmovups xmm0,XMMWORD PTR [rip+0xa937]        # 4134a0 <__swc_rdata_base_fc36583a+0x390>
  408b69:	vmovups XMMWORD PTR [rax],xmm0
  408b6d:	mov    QWORD PTR [rax+0x10],rsp
  408b71:	mov    QWORD PTR [rax+0x18],r13
  408b75:	mov    QWORD PTR [rax+0x20],rdi
  408b79:	lea    rdi,[rip+0xa7f8]        # 413378 <__swc_rdata_base_fc36583a+0x268>
  408b80:	mov    QWORD PTR [rax+0x28],rdi
  408b84:	mov    QWORD PTR [rax+0x30],r14
  408b88:	mov    QWORD PTR [rax+0x38],r13
  408b8c:	lea    rcx,[rsp+0x10]
  408b91:	mov    QWORD PTR [rax+0x40],rcx
  408b95:	mov    QWORD PTR [rax+0x48],0x3
  408b9d:	lea    rcx,[rsp+0x40]
  408ba2:	sub    rsp,0x8
  408ba6:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  408bab:	add    rsp,0x8
  408baf:	add    rsp,0x50
  408bb3:	lea    rax,[rip+0xa806]        # 4133c0 <__swc_rdata_base_fc36583a+0x2b0>
  408bba:	sub    rsp,0x20
  408bbe:	mov    rcx,rsp
  408bc1:	mov    QWORD PTR [rcx],rax
  408bc4:	mov    QWORD PTR [rcx+0x8],r13
  408bc8:	mov    QWORD PTR [rcx+0x10],rsp
  408bcc:	mov    QWORD PTR [rcx+0x18],0x1
  408bd4:	lea    rcx,[rsp+0x10]
  408bd9:	sub    rsp,0x8
  408bdd:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  408be2:	add    rsp,0x8
  408be6:	add    rsp,0x20
  408bea:	mov    eax,DWORD PTR [rsi+0x20]
  408bed:	mov    ecx,DWORD PTR [rsi+0x24]
  408bf0:	sub    rsp,0xa0
  408bf7:	mov    rdx,rsp
  408bfa:	mov    QWORD PTR [rdx+0x30],rsi
  408bfe:	mov    QWORD PTR [rdx+0x38],rdi
  408c02:	vmovups xmm0,XMMWORD PTR [rip+0xa82e]        # 413438 <__swc_rdata_base_fc36583a+0x328>
  408c0a:	vmovups XMMWORD PTR [rdx],xmm0
  408c0e:	mov    QWORD PTR [rdx+0x40],rsp
  408c12:	mov    QWORD PTR [rdx+0x48],r13
  408c16:	mov    DWORD PTR [rdx+0x10],eax
  408c19:	lea    rax,[rsp+0x10]
  408c1e:	mov    QWORD PTR [rdx+0x50],rax
  408c22:	lea    rax,[rip+0xa7a7]        # 4133d0 <__swc_rdata_base_fc36583a+0x2c0>
  408c29:	mov    QWORD PTR [rdx+0x58],rax
  408c2d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c32:	lea    r8,[rsp+0x18]
  408c37:	mov    QWORD PTR [rdx+0x60],r8
  408c3b:	mov    QWORD PTR [rdx+0x68],r13
  408c3f:	mov    DWORD PTR [rdx+0x28],ecx
  408c42:	lea    rcx,[rdx+0x28]
  408c46:	mov    QWORD PTR [rdx+0x70],rcx
  408c4a:	mov    QWORD PTR [rdx+0x78],rax
  408c4e:	mov    QWORD PTR [rdx+0x80],r14
  408c55:	mov    QWORD PTR [rdx+0x88],r13
  408c5c:	lea    rax,[rdx+0x30]
  408c60:	mov    QWORD PTR [rdx+0x90],rax
  408c67:	mov    QWORD PTR [rdx+0x98],0x6
  408c72:	lea    rcx,[rdx+0x90]
  408c79:	sub    rsp,0x8
  408c7d:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  408c82:	add    rsp,0x8
  408c86:	add    rsp,0xa0
  408c8d:	sub    rsp,0x20
  408c91:	mov    rax,rsp
  408c94:	mov    QWORD PTR [rax],r14
  408c97:	mov    QWORD PTR [rax+0x8],r13
  408c9b:	mov    QWORD PTR [rax+0x10],rsp
  408c9f:	mov    QWORD PTR [rax+0x18],0x1
  408ca7:	lea    rcx,[rsp+0x10]
  408cac:	sub    rsp,0x8
  408cb0:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  408cb5:	add    rsp,0x8
  408cb9:	add    rsp,0x20
  408cbd:	mov    eax,DWORD PTR [r12+0x9ac]
  408cc5:	test   eax,eax
  408cc7:	je     408f00 <__swc_fn_fc36583a_000102_e9fdc18e+0x480>
  408ccd:	lea    rax,[rip+0xa744]        # 413418 <__swc_rdata_base_fc36583a+0x308>
  408cd4:	sub    rsp,0x20
  408cd8:	mov    rcx,rsp
  408cdb:	mov    QWORD PTR [rcx],rax
  408cde:	mov    QWORD PTR [rcx+0x8],r13
  408ce2:	mov    QWORD PTR [rcx+0x10],rsp
  408ce6:	mov    QWORD PTR [rcx+0x18],0x1
  408cee:	lea    rcx,[rsp+0x10]
  408cf3:	sub    rsp,0x8
  408cf7:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  408cfc:	add    rsp,0x8
  408d00:	add    rsp,0x20
  408d04:	mov    eax,DWORD PTR [r12+0x9ac]
  408d0c:	dec    eax
  408d0e:	mov    esi,eax
  408d10:	test   esi,esi
  408d12:	jl     408ed0 <__swc_fn_fc36583a_000102_e9fdc18e+0x450>
  408d18:	jmp    408d24 <__swc_fn_fc36583a_000102_e9fdc18e+0x2a4>
  408d1a:	nop    WORD PTR [rax+rax*1+0x0]
  408d20:	dec    esi
  408d22:	jmp    408d10 <__swc_fn_fc36583a_000102_e9fdc18e+0x290>
  408d24:	lea    rax,[rip+0xa6fd]        # 413428 <__swc_rdata_base_fc36583a+0x318>
  408d2b:	sub    rsp,0x20
  408d2f:	mov    rcx,rsp
  408d32:	mov    QWORD PTR [rcx],rax
  408d35:	mov    QWORD PTR [rcx+0x8],r13
  408d39:	mov    QWORD PTR [rcx+0x10],rsp
  408d3d:	mov    QWORD PTR [rcx+0x18],0x1
  408d45:	lea    rcx,[rsp+0x10]
  408d4a:	sub    rsp,0x8
  408d4e:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  408d53:	add    rsp,0x8
  408d57:	add    rsp,0x20
  408d5b:	movsxd rax,esi
  408d5e:	imul   r15,rax,0x30
  408d62:	add    r15,r12
  408d65:	add    r15,0xf8
  408d6c:	sub    rsp,0x20
  408d70:	mov    rax,rsp
  408d73:	mov    QWORD PTR [rax],r15
  408d76:	mov    QWORD PTR [rax+0x8],rdi
  408d7a:	mov    QWORD PTR [rax+0x10],rsp
  408d7e:	mov    QWORD PTR [rax+0x18],0x1
  408d86:	lea    rcx,[rsp+0x10]
  408d8b:	sub    rsp,0x8
  408d8f:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  408d94:	add    rsp,0x8
  408d98:	add    rsp,0x20
  408d9c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408da4:	lea    rsi,[rip+0xa68d]        # 413438 <__swc_rdata_base_fc36583a+0x328>
  408dab:	sub    rsp,0x20
  408daf:	mov    rax,rsp
  408db2:	mov    QWORD PTR [rax],rsi
  408db5:	mov    QWORD PTR [rax+0x8],r13
  408db9:	mov    QWORD PTR [rax+0x10],rsp
  408dbd:	mov    QWORD PTR [rax+0x18],0x1
  408dc5:	lea    rcx,[rsp+0x10]
  408dca:	sub    rsp,0x8
  408dce:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  408dd3:	add    rsp,0x8
  408dd7:	add    rsp,0x20
  408ddb:	sub    rsp,0x30
  408ddf:	mov    rax,rsp
  408de2:	mov    ecx,DWORD PTR [r15+0x20]
  408de6:	mov    QWORD PTR [rax],rcx
  408de9:	mov    QWORD PTR [rax+0x8],rsp
  408ded:	lea    rdi,[rip+0xa654]        # 413448 <__swc_rdata_base_fc36583a+0x338>
  408df4:	mov    QWORD PTR [rax+0x10],rdi
  408df8:	lea    rcx,[rsp+0x8]
  408dfd:	mov    QWORD PTR [rax+0x18],rcx
  408e01:	mov    QWORD PTR [rax+0x20],0x1
  408e09:	lea    rcx,[rsp+0x18]
  408e0e:	sub    rsp,0x8
  408e12:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  408e17:	add    rsp,0x8
  408e1b:	add    rsp,0x30
  408e1f:	sub    rsp,0x20
  408e23:	mov    rax,rsp
  408e26:	mov    QWORD PTR [rax],rsi
  408e29:	mov    QWORD PTR [rax+0x8],r13
  408e2d:	mov    QWORD PTR [rax+0x10],rsp
  408e31:	mov    QWORD PTR [rax+0x18],0x1
  408e39:	lea    rcx,[rsp+0x10]
  408e3e:	sub    rsp,0x8
  408e42:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  408e47:	add    rsp,0x8
  408e4b:	add    rsp,0x20
  408e4f:	sub    rsp,0x30
  408e53:	mov    rax,rsp
  408e56:	mov    ecx,DWORD PTR [r15+0x24]
  408e5a:	mov    QWORD PTR [rax],rcx
  408e5d:	mov    QWORD PTR [rax+0x8],rsp
  408e61:	mov    QWORD PTR [rax+0x10],rdi
  408e65:	lea    rcx,[rsp+0x8]
  408e6a:	mov    QWORD PTR [rax+0x18],rcx
  408e6e:	mov    QWORD PTR [rax+0x20],0x1
  408e76:	lea    rcx,[rsp+0x18]
  408e7b:	sub    rsp,0x8
  408e7f:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  408e84:	add    rsp,0x8
  408e88:	add    rsp,0x30
  408e8c:	sub    rsp,0x20
  408e90:	mov    rax,rsp
  408e93:	mov    QWORD PTR [rax],r14
  408e96:	mov    QWORD PTR [rax+0x8],r13
  408e9a:	mov    QWORD PTR [rax+0x10],rsp
  408e9e:	mov    QWORD PTR [rax+0x18],0x1
  408ea6:	lea    rcx,[rsp+0x10]
  408eab:	sub    rsp,0x8
  408eaf:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  408eb4:	add    rsp,0x8
  408eb8:	add    rsp,0x20
  408ebc:	lea    rdi,[rip+0xa4b5]        # 413378 <__swc_rdata_base_fc36583a+0x268>
  408ec3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408ecb:	jmp    408d20 <__swc_fn_fc36583a_000102_e9fdc18e+0x2a0>
  408ed0:	sub    rsp,0x20
  408ed4:	mov    rax,rsp
  408ed7:	mov    QWORD PTR [rax],r14
  408eda:	mov    QWORD PTR [rax+0x8],r13
  408ede:	mov    QWORD PTR [rax+0x10],rsp
  408ee2:	mov    QWORD PTR [rax+0x18],0x1
  408eea:	lea    rcx,[rsp+0x10]
  408eef:	sub    rsp,0x8
  408ef3:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  408ef8:	add    rsp,0x8
  408efc:	add    rsp,0x20
  408f00:	lea    rax,[rbx+0x28]
  408f04:	mov    rcx,rax
  408f07:	mov    QWORD PTR [rbx+0x28],0x0
  408f0f:	mov    QWORD PTR [rbx+0x30],0x0
  408f17:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408f1c:	add    rcx,0x10
  408f20:	mov    edx,0x1f
  408f25:	cs nop WORD PTR [rax+rax*1+0x0]
  408f2f:	nop
  408f30:	vmovups XMMWORD PTR [rcx],xmm0
  408f34:	add    rcx,0x10
  408f38:	sub    rdx,0x1
  408f3c:	jne    408f30 <__swc_fn_fc36583a_000102_e9fdc18e+0x4b0>
  408f3e:	lea    rsi,[rbx+0x228]
  408f45:	xor    ecx,ecx
  408f47:	cs nop WORD PTR [rax+rax*1+0x0]
  408f51:	cs nop WORD PTR [rax+rax*1+0x0]
  408f5b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f60:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f65:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f6a:	add    rcx,0x10
  408f6e:	cmp    rcx,0x200
  408f75:	jne    408f60 <__swc_fn_fc36583a_000102_e9fdc18e+0x4e0>
  408f77:	mov    eax,DWORD PTR [r12+0xbc8]
  408f7f:	lea    rcx,[r12+0x9c8]
  408f87:	mov    QWORD PTR [rbx+0x428],rcx
  408f8e:	mov    QWORD PTR [rbx+0x430],rax
  408f95:	lea    rdi,[rbx+0x438]
  408f9c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408fa4:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fac:	mov    eax,DWORD PTR [r12+0xbc8]
  408fb4:	test   eax,eax
  408fb6:	jne    409003 <__swc_fn_fc36583a_000102_e9fdc18e+0x583>
  408fb8:	lea    rax,[rbx+0x448]
  408fbf:	mov    QWORD PTR [rbx+0x448],rsi
  408fc6:	mov    QWORD PTR [rax+0x8],0x40
  408fce:	mov    ecx,0x1
  408fd3:	mov    rdx,rax
  408fd6:	sub    rsp,0x8
  408fda:	call   4102e0 <__swc_fn_fc36583a_000119_9175a56a>
  408fdf:	add    rsp,0x8
  408fe3:	mov    QWORD PTR [rbx+0x460],rsi
  408fea:	mov    ecx,eax
  408fec:	mov    QWORD PTR [rbx+0x468],rcx
  408ff3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408ffb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  409003:	mov    rsi,QWORD PTR [rbx+0x438]
  40900a:	mov    rax,QWORD PTR [rbx+0x440]
  409011:	mov    r15,rax
  409014:	xor    r12d,r12d
  409017:	test   r15,r15
  40901a:	je     4090d0 <__swc_fn_fc36583a_000102_e9fdc18e+0x650>
  409020:	mov    rax,QWORD PTR [rsi+r12*8]
  409024:	test   rax,rax
  409027:	je     409046 <__swc_fn_fc36583a_000102_e9fdc18e+0x5c6>
  409029:	lea    rcx,[rbx+0x4b8]
  409030:	mov    rdx,rax
  409033:	sub    rsp,0x8
  409037:	call   409f40 <__swc_fn_fc36583a_000162_60216e69>
  40903c:	add    rsp,0x8
  409040:	mov    al,BYTE PTR [rax]
  409042:	test   al,al
  409044:	jne    409052 <__swc_fn_fc36583a_000102_e9fdc18e+0x5d2>
  409046:	add    r12,0x1
  40904a:	sub    r15,0x1
  40904e:	jne    409020 <__swc_fn_fc36583a_000102_e9fdc18e+0x5a0>
  409050:	jmp    4090d0 <__swc_fn_fc36583a_000102_e9fdc18e+0x650>
  409052:	lea    rax,[rip+0xa437]        # 413490 <__swc_rdata_base_fc36583a+0x380>
  409059:	sub    rsp,0x20
  40905d:	mov    rcx,rsp
  409060:	mov    QWORD PTR [rcx],rax
  409063:	mov    QWORD PTR [rcx+0x8],r13
  409067:	mov    QWORD PTR [rcx+0x10],rsp
  40906b:	mov    QWORD PTR [rcx+0x18],0x1
  409073:	lea    rcx,[rsp+0x10]
  409078:	sub    rsp,0x8
  40907c:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  409081:	add    rsp,0x8
  409085:	add    rsp,0x20
  409089:	mov    rcx,rdi
  40908c:	xor    edx,edx
  40908e:	mov    al,0x1
  409090:	mov    r8,rax
  409093:	sub    rsp,0x8
  409097:	call   40da80 <__swc_fn_fc36583a_000163_8e41797b>
  40909c:	add    rsp,0x8
  4090a0:	sub    rsp,0x20
  4090a4:	mov    rax,rsp
  4090a7:	mov    QWORD PTR [rax],r14
  4090aa:	mov    QWORD PTR [rax+0x8],r13
  4090ae:	mov    QWORD PTR [rax+0x10],rsp
  4090b2:	mov    QWORD PTR [rax+0x18],0x1
  4090ba:	lea    rcx,[rsp+0x10]
  4090bf:	sub    rsp,0x8
  4090c3:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  4090c8:	add    rsp,0x8
  4090cc:	add    rsp,0x20
  4090d0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090d8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090e4:	add    rsp,0x500
  4090eb:	pop    r15
  4090ed:	pop    r14
  4090ef:	pop    r13
  4090f1:	pop    r12
  4090f3:	pop    rdi
  4090f4:	pop    rsi
  4090f5:	pop    rbx
  4090f6:	pop    rbp
  4090f7:	ret
	...

0000000000409100 <__swc_fn_fc36583a_000105_6fd80914>:
  409100:	sub    rsp,0x8
  409104:	test   r8,r8
  409107:	je     40910e <__swc_fn_fc36583a_000105_6fd80914+0xe>
  409109:	call   40f9d0 <__swc_fn_fc36583a_000104_5589fdbd>
  40910e:	add    rsp,0x8
  409112:	ret
	...

0000000000409120 <__swc_fn_fc36583a_000108_84af7666>:
  409120:	push   rsi
  409121:	push   rdi
  409122:	push   r12
  409124:	push   r13
  409126:	sub    rsp,0xd8
  40912d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409133:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  409139:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40913f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  409145:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40914b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  409154:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40915d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  409166:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40916f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  409178:	xor    eax,eax
  40917a:	call   407010 <getpid@plt>
  40917f:	mov    rsi,rax
  409182:	lea    rdi,[rip+0x1dbbf]        # 426d48 <__swc_bss_base_fc36583a+0x2d08>
  409189:	mov    r12,QWORD PTR [rdi]
  40918c:	test   r12,r12
  40918f:	je     40919d <__swc_fn_fc36583a_000108_84af7666+0x7d>
  409191:	cmp    DWORD PTR [r12+0x10],esi
  409196:	jne    40919d <__swc_fn_fc36583a_000108_84af7666+0x7d>
  409198:	mov    rax,r12
  40919b:	jmp    409200 <__swc_fn_fc36583a_000108_84af7666+0xe0>
  40919d:	mov    ecx,0x4
  4091a2:	mov    edx,0x18
  4091a7:	call   40fac0 <__swc_fn_fc36583a_000107_4796e893>
  4091ac:	mov    rcx,rax
  4091af:	test   rax,rax
  4091b2:	jne    4091b8 <__swc_fn_fc36583a_000108_84af7666+0x98>
  4091b4:	xor    eax,eax
  4091b6:	jmp    409200 <__swc_fn_fc36583a_000108_84af7666+0xe0>
  4091b8:	mov    DWORD PTR [rcx+0x10],esi
  4091bb:	mov    rax,r12
  4091be:	lock cmpxchg QWORD PTR [rdi],rcx
  4091c3:	mov    r13,rax
  4091c6:	cmp    rax,r12
  4091c9:	je     4091df <__swc_fn_fc36583a_000108_84af7666+0xbf>
  4091cb:	mov    rdi,rcx
  4091ce:	mov    esi,0x18
  4091d3:	xor    eax,eax
  4091d5:	call   407020 <munmap@plt>
  4091da:	mov    rax,r13
  4091dd:	jmp    409200 <__swc_fn_fc36583a_000108_84af7666+0xe0>
  4091df:	test   r12,r12
  4091e2:	je     4091fd <__swc_fn_fc36583a_000108_84af7666+0xdd>
  4091e4:	mov    rdi,r12
  4091e7:	mov    esi,0x18
  4091ec:	xor    eax,eax
  4091ee:	mov    QWORD PTR [rsp+0x28],rcx
  4091f3:	call   407020 <munmap@plt>
  4091f8:	mov    rcx,QWORD PTR [rsp+0x28]
  4091fd:	mov    rax,rcx
  409200:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  409206:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40920c:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  409212:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  409218:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40921e:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409227:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  409230:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409239:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  409242:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40924b:	add    rsp,0xd8
  409252:	pop    r13
  409254:	pop    r12
  409256:	pop    rdi
  409257:	pop    rsi
  409258:	ret
  409259:	add    BYTE PTR [rax],al
  40925b:	add    BYTE PTR [rax],al
  40925d:	add    BYTE PTR [rax],al
	...

0000000000409260 <__swc_fn_fc36583a_000111_b25e3a45>:
  409260:	push   rbx
  409261:	push   r12
  409263:	push   rdi
  409264:	push   rsi
  409265:	sub    rsp,0xa8
  40926c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409272:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409278:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40927e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409284:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40928a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409290:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409296:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40929c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4092a5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4092ae:	mov    rbx,rdx
  4092b1:	mov    r12,rcx
  4092b4:	mov    rdi,rcx
  4092b7:	mov    rsi,rdx
  4092ba:	mov    edx,0x3
  4092bf:	xor    eax,eax
  4092c1:	call   407030 <mprotect@plt>
  4092c6:	test   eax,eax
  4092c8:	je     4092ce <__swc_fn_fc36583a_000111_b25e3a45+0x6e>
  4092ca:	xor    eax,eax
  4092cc:	jmp    4092e3 <__swc_fn_fc36583a_000111_b25e3a45+0x83>
  4092ce:	mov    rcx,r12
  4092d1:	mov    rdx,rbx
  4092d4:	mov    al,0x1
  4092d6:	mov    r8,rax
  4092d9:	call   410110 <__swc_fn_fc36583a_000110_a808fe76>
  4092de:	mov    eax,0x1
  4092e3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4092e9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4092ef:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4092f5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4092fb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409301:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409307:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40930d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409313:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40931c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409325:	add    rsp,0xa8
  40932c:	pop    rsi
  40932d:	pop    rdi
  40932e:	pop    r12
  409330:	pop    rbx
  409331:	ret
	...

0000000000409340 <__swc_fn_fc36583a_000114_27d95464>:
  409340:	sub    rsp,0x8
  409344:	test   rcx,rcx
  409347:	jne    40934e <__swc_fn_fc36583a_000114_27d95464+0xe>
  409349:	add    rsp,0x8
  40934d:	ret
  40934e:	call   40d080 <__swc_fn_fc36583a_000115_1ba33335>
  409353:	add    rsp,0x8
  409357:	ret
	...

0000000000409360 <__swc_fn_fc36583a_000117_86a7fb9e>:
  409360:	push   rdi
  409361:	push   rsi
  409362:	sub    rsp,0xa8
  409369:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40936f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409375:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40937b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409381:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409387:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40938d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409393:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409399:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4093a2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4093ab:	xor    edi,edi
  4093ad:	xor    eax,eax
  4093af:	call   407040 <exit@plt>
  4093b4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4093ba:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4093c0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4093c6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4093cc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4093d2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4093d8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4093de:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4093e4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4093ed:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4093f6:	add    rsp,0xa8
  4093fd:	pop    rsi
  4093fe:	pop    rdi
  4093ff:	ret

0000000000409400 <__swc_fn_fc36583a_000120_ea68f292>:
  409400:	push   rbx
  409401:	push   rsi
  409402:	push   rdi
  409403:	push   r12
  409405:	sub    rsp,0x18
  409409:	mov    rbx,r8
  40940c:	mov    rsi,rcx
  40940f:	mov    rdi,rdx
  409412:	mov    rcx,QWORD PTR [rip+0x1d927]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  409419:	test   rcx,rcx
  40941c:	jne    40942e <__swc_fn_fc36583a_000120_ea68f292+0x2e>
  40941e:	call   40a1d0 <__swc_fn_fc36583a_000165_cf398896>
  409423:	lea    rcx,[rax+0x1]
  409427:	mov    QWORD PTR [rip+0x1d912],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40942e:	dec    rcx
  409431:	call   411fc0 <__swc_fn_fc36583a_000167_fce60b2b>
  409436:	mov    r12,rax
  409439:	cmp    ebx,0x3
  40943c:	jne    40944f <__swc_fn_fc36583a_000120_ea68f292+0x4f>
  40943e:	mov    rax,QWORD PTR [r12+0xbd0]
  409446:	test   rax,rax
  409449:	jne    40958f <__swc_fn_fc36583a_000120_ea68f292+0x18f>
  40944f:	cmp    ebx,0x5
  409452:	jne    409476 <__swc_fn_fc36583a_000120_ea68f292+0x76>
  409454:	call   40c950 <__swc_fn_fc36583a_000091_3d2f5a0d>
  409459:	test   al,al
  40945b:	jne    409476 <__swc_fn_fc36583a_000120_ea68f292+0x76>
  40945d:	mov    rcx,rsi
  409460:	mov    rdx,rdi
  409463:	call   411f70 <__swc_fn_fc36583a_000164_1962e12a>
  409468:	test   al,al
  40946a:	je     409476 <__swc_fn_fc36583a_000120_ea68f292+0x76>
  40946c:	add    rsp,0x18
  409470:	pop    r12
  409472:	pop    rdi
  409473:	pop    rsi
  409474:	pop    rbx
  409475:	ret
  409476:	call   40c950 <__swc_fn_fc36583a_000091_3d2f5a0d>
  40947b:	test   al,al
  40947d:	jne    4094f2 <__swc_fn_fc36583a_000120_ea68f292+0xf2>
  40947f:	lea    rax,[rsp+0x8]
  409484:	vmovups xmm0,XMMWORD PTR [rsi]
  409488:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40948e:	mov    rcx,QWORD PTR [rsp+0x8]
  409493:	test   rcx,rcx
  409496:	jne    4094e7 <__swc_fn_fc36583a_000120_ea68f292+0xe7>
  409498:	cmp    ebx,0x3
  40949b:	je     4094a9 <__swc_fn_fc36583a_000120_ea68f292+0xa9>
  40949d:	cmp    ebx,0x4
  4094a0:	je     4094b9 <__swc_fn_fc36583a_000120_ea68f292+0xb9>
  4094a2:	cmp    ebx,0x5
  4094a5:	je     4094c9 <__swc_fn_fc36583a_000120_ea68f292+0xc9>
  4094a7:	jmp    4094d9 <__swc_fn_fc36583a_000120_ea68f292+0xd9>
  4094a9:	vmovups xmm0,XMMWORD PTR [rip+0xa02f]        # 4134e0 <__swc_rdata_base_fc36583a+0x3d0>
  4094b1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094b7:	jmp    4094e7 <__swc_fn_fc36583a_000120_ea68f292+0xe7>
  4094b9:	vmovups xmm0,XMMWORD PTR [rip+0xa02f]        # 4134f0 <__swc_rdata_base_fc36583a+0x3e0>
  4094c1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094c7:	jmp    4094e7 <__swc_fn_fc36583a_000120_ea68f292+0xe7>
  4094c9:	vmovups xmm0,XMMWORD PTR [rip+0xa02f]        # 413500 <__swc_rdata_base_fc36583a+0x3f0>
  4094d1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094d7:	jmp    4094e7 <__swc_fn_fc36583a_000120_ea68f292+0xe7>
  4094d9:	vmovups xmm0,XMMWORD PTR [rip+0xa02f]        # 413510 <__swc_rdata_base_fc36583a+0x400>
  4094e1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094e7:	mov    rcx,rax
  4094ea:	mov    rdx,rdi
  4094ed:	call   40cba0 <__swc_fn_fc36583a_000103_67100064>
  4094f2:	vmovups xmm0,XMMWORD PTR [rdi]
  4094f6:	vmovups XMMWORD PTR [r12+0x940],xmm0
  409500:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  409505:	vmovups XMMWORD PTR [r12+0x950],xmm0
  40950f:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  409514:	vmovups XMMWORD PTR [r12+0x960],xmm0
  40951e:	lea    rax,[r12+0x940]
  409526:	mov    QWORD PTR [r12+0x970],rax
  40952e:	mov    rax,QWORD PTR [rsi]
  409531:	mov    QWORD PTR [r12+0x978],rax
  409539:	mov    rax,QWORD PTR [rsi+0x8]
  40953d:	mov    QWORD PTR [r12+0x980],rax
  409545:	movsxd rax,ebx
  409548:	mov    QWORD PTR [r12+0x988],rax
  409550:	cmp    ebx,0x5
  409553:	je     40955c <__swc_fn_fc36583a_000120_ea68f292+0x15c>
  409555:	xor    ecx,ecx
  409557:	call   40a300 <__swc_fn_fc36583a_000174_176517f9>
  40955c:	mov    rbx,QWORD PTR [r12+0xbe8]
  409564:	test   rbx,rbx
  409567:	je     409578 <__swc_fn_fc36583a_000120_ea68f292+0x178>
  409569:	mov    rcx,r12
  40956c:	call   rbx
  40956e:	add    rsp,0x18
  409572:	pop    r12
  409574:	pop    rdi
  409575:	pop    rsi
  409576:	pop    rbx
  409577:	ret
  409578:	mov    rcx,rsi
  40957b:	call   4101c0 <__swc_fn_fc36583a_000116_035d76a1>
  409580:	call   40d1d0 <__swc_fn_fc36583a_000118_7f430081>
  409585:	add    rsp,0x18
  409589:	pop    r12
  40958b:	pop    rdi
  40958c:	pop    rsi
  40958d:	pop    rbx
  40958e:	ret
  40958f:	mov    rcx,rsi
  409592:	mov    rdx,rdi
  409595:	call   40cba0 <__swc_fn_fc36583a_000103_67100064>
  40959a:	jmp    40944f <__swc_fn_fc36583a_000120_ea68f292+0x4f>
	...

00000000004095a0 <__swc_fn_fc36583a_000123_9d2cbd72>:
  4095a0:	push   rdi
  4095a1:	push   rsi
  4095a2:	sub    rsp,0xb8
  4095a9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4095af:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4095b5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4095bb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4095c1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4095c7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4095cd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4095d3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4095dc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4095e5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4095ee:	mov    DWORD PTR [rsp+0x8],0x0
  4095f6:	lea    rdi,[rsp+0x8]
  4095fb:	xor    esi,esi
  4095fd:	xor    eax,eax
  4095ff:	call   407050 <pthread_key_create@plt>
  409604:	test   eax,eax
  409606:	jne    40960e <__swc_fn_fc36583a_000123_9d2cbd72+0x6e>
  409608:	mov    eax,DWORD PTR [rsp+0x8]
  40960c:	jmp    409615 <__swc_fn_fc36583a_000123_9d2cbd72+0x75>
  40960e:	mov    rax,0xffffffffffffffff
  409615:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40961b:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409621:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409627:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40962d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409633:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409639:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40963f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409648:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409651:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40965a:	add    rsp,0xb8
  409661:	pop    rsi
  409662:	pop    rdi
  409663:	ret
	...

0000000000409670 <__swc_fn_fc36583a_000126_102fe7b9>:
  409670:	push   rdi
  409671:	push   rsi
  409672:	sub    rsp,0xb8
  409679:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40967f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409685:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40968b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409691:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409697:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40969d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4096a3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4096ac:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4096b5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4096be:	mov    DWORD PTR [rsp+0x8],0x0
  4096c6:	lea    rdi,[rsp+0x8]
  4096cb:	mov    rsi,rcx
  4096ce:	xor    eax,eax
  4096d0:	call   407050 <pthread_key_create@plt>
  4096d5:	test   eax,eax
  4096d7:	jne    4096e2 <__swc_fn_fc36583a_000126_102fe7b9+0x72>
  4096d9:	mov    eax,DWORD PTR [rsp+0x8]
  4096dd:	inc    rax
  4096e0:	jmp    4096e4 <__swc_fn_fc36583a_000126_102fe7b9+0x74>
  4096e2:	xor    eax,eax
  4096e4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4096ea:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4096f0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4096f6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4096fc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409702:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409708:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40970e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409717:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409720:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409729:	add    rsp,0xb8
  409730:	pop    rsi
  409731:	pop    rdi
  409732:	ret
	...

0000000000409740 <__swc_fn_fc36583a_000129_74b163fe>:
  409740:	push   rdi
  409741:	push   rsi
  409742:	sub    rsp,0xa8
  409749:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40974f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409755:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40975b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409761:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409767:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40976d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409773:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409779:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409782:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40978b:	test   rcx,rcx
  40978e:	setne  al
  409791:	je     4097aa <__swc_fn_fc36583a_000129_74b163fe+0x6a>
  409793:	lea    rax,[rcx-0x1]
  409797:	mov    eax,eax
  409799:	mov    edi,eax
  40979b:	mov    rsi,rdx
  40979e:	xor    eax,eax
  4097a0:	call   407060 <pthread_setspecific@plt>
  4097a5:	test   eax,eax
  4097a7:	sete   al
  4097aa:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4097b0:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4097b6:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4097bc:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4097c2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4097c8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4097ce:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4097d4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4097da:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4097e3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4097ec:	add    rsp,0xa8
  4097f3:	pop    rsi
  4097f4:	pop    rdi
  4097f5:	ret
	...

0000000000409800 <__swc_fn_fc36583a_000132_f908e7f9>:
  409800:	push   rdi
  409801:	push   rsi
  409802:	sub    rsp,0xa8
  409809:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40980f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409815:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40981b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409821:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409827:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40982d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409833:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409839:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409842:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40984b:	mov    rax,rdx
  40984e:	mov    QWORD PTR [rsp],0x0
  409856:	mov    edi,0xca
  40985b:	mov    rsi,rcx
  40985e:	mov    edx,0x81
  409863:	mov    eax,eax
  409865:	mov    ecx,eax
  409867:	xor    r8d,r8d
  40986a:	xor    r9d,r9d
  40986d:	xor    eax,eax
  40986f:	call   407070 <syscall@plt>
  409874:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40987a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409880:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409886:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40988c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409892:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409898:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40989e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4098a4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4098ad:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4098b6:	add    rsp,0xa8
  4098bd:	pop    rsi
  4098be:	pop    rdi
  4098bf:	ret

00000000004098c0 <__swc_fn_fc36583a_000135_e3032dc2>:
  4098c0:	sub    rsp,0x8
  4098c4:	call   40d570 <__swc_fn_fc36583a_000133_4b2af8da>
  4098c9:	add    rsp,0x8
  4098cd:	ret
	...

00000000004098d0 <__swc_fn_fc36583a_000138_0c00232f>:
  4098d0:	push   rdi
  4098d1:	push   rsi
  4098d2:	sub    rsp,0xc8
  4098d9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4098df:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4098e5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4098eb:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4098f1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4098f7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4098fd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  409906:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40990f:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  409918:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  409921:	vxorps xmm0,xmm0,xmm0
  409925:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40992b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409931:	mov    rdi,rcx
  409934:	lea    rsi,[rsp+0x8]
  409939:	xor    eax,eax
  40993b:	call   407080 <dladdr@plt>
  409940:	xor    ecx,ecx
  409942:	test   eax,eax
  409944:	je     40994b <__swc_fn_fc36583a_000138_0c00232f+0x7b>
  409946:	mov    rcx,QWORD PTR [rsp+0x10]
  40994b:	mov    rax,rcx
  40994e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  409954:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40995a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  409960:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  409966:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40996c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  409972:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40997b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  409984:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40998d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  409996:	add    rsp,0xc8
  40999d:	pop    rsi
  40999e:	pop    rdi
  40999f:	ret

00000000004099a0 <__swc_fn_fc36583a_000141_2ce79e3b>:
  4099a0:	push   rbx
  4099a1:	push   r12
  4099a3:	push   r13
  4099a5:	push   rdi
  4099a6:	push   rsi
  4099a7:	push   r14
  4099a9:	push   r15
  4099ab:	sub    rsp,0x150
  4099b2:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  4099bb:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  4099c4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  4099cd:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  4099d6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  4099df:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4099e8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4099f1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4099fa:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  409a03:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  409a0c:	mov    rbx,rdx
  409a0f:	mov    QWORD PTR [rsp+0x98],rdx
  409a17:	mov    r12,rcx
  409a1a:	mov    QWORD PTR [rsp+0xa0],rcx
  409a22:	mov    QWORD PTR [rbx],0x0
  409a29:	lea    r13,[rip+0x1d350]        # 426d80 <__swc_bss_base_fc36583a+0x2d40>
  409a30:	mov    rcx,r13
  409a33:	call   4098c0 <__swc_fn_fc36583a_000135_e3032dc2>
  409a38:	mov    rax,QWORD PTR [rip+0x1d349]        # 426d88 <__swc_bss_base_fc36583a+0x2d48>
  409a3f:	test   rax,rax
  409a42:	je     409a79 <__swc_fn_fc36583a_000141_2ce79e3b+0xd9>
  409a44:	cs nop WORD PTR [rax+rax*1+0x0]
  409a4e:	xchg   ax,ax
  409a50:	cmp    QWORD PTR [rax+0x8],r12
  409a54:	jne    409a71 <__swc_fn_fc36583a_000141_2ce79e3b+0xd1>
  409a56:	mov    rcx,QWORD PTR [rax+0x18]
  409a5a:	mov    QWORD PTR [rbx],rcx
  409a5d:	mov    rbx,QWORD PTR [rax+0x10]
  409a61:	mov    rcx,r13
  409a64:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  409a69:	mov    rax,rbx
  409a6c:	jmp    409c5b <__swc_fn_fc36583a_000141_2ce79e3b+0x2bb>
  409a71:	mov    rax,QWORD PTR [rax]
  409a74:	test   rax,rax
  409a77:	jne    409a50 <__swc_fn_fc36583a_000141_2ce79e3b+0xb0>
  409a79:	vxorps xmm0,xmm0,xmm0
  409a7d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  409a83:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  409a89:	mov    rdi,r12
  409a8c:	lea    rsi,[rsp+0x10]
  409a91:	xor    eax,eax
  409a93:	call   407080 <dladdr@plt>
  409a98:	test   eax,eax
  409a9a:	sete   al
  409a9d:	je     409aaa <__swc_fn_fc36583a_000141_2ce79e3b+0x10a>
  409a9f:	mov    rax,QWORD PTR [rsp+0x10]
  409aa4:	test   rax,rax
  409aa7:	sete   al
  409aaa:	test   al,al
  409aac:	je     409abd <__swc_fn_fc36583a_000141_2ce79e3b+0x11d>
  409aae:	mov    rcx,r13
  409ab1:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  409ab6:	xor    eax,eax
  409ab8:	jmp    409c5b <__swc_fn_fc36583a_000141_2ce79e3b+0x2bb>
  409abd:	mov    rdi,QWORD PTR [rsp+0x10]
  409ac2:	mov    esi,0x80000
  409ac7:	xor    eax,eax
  409ac9:	call   407090 <open@plt>
  409ace:	lea    r14,[rsp+0x30]
  409ad3:	mov    DWORD PTR [rsp+0x30],eax
  409ad7:	cmp    DWORD PTR [r14],0x0
  409adb:	jge    409aec <__swc_fn_fc36583a_000141_2ce79e3b+0x14c>
  409add:	mov    rcx,r13
  409ae0:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  409ae5:	xor    eax,eax
  409ae7:	jmp    409c5b <__swc_fn_fc36583a_000141_2ce79e3b+0x2bb>
  409aec:	mov    rax,r14
  409aef:	movsxd rdi,DWORD PTR [rax]
  409af2:	xor    esi,esi
  409af4:	mov    edx,0x2
  409af9:	xor    eax,eax
  409afb:	call   4070a0 <lseek@plt>
  409b00:	mov    r15,rax
  409b03:	test   rax,rax
  409b06:	jg     409b21 <__swc_fn_fc36583a_000141_2ce79e3b+0x181>
  409b08:	movsxd rdi,DWORD PTR [r14]
  409b0b:	xor    eax,eax
  409b0d:	call   4070b0 <close@plt>
  409b12:	mov    rcx,r13
  409b15:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  409b1a:	xor    eax,eax
  409b1c:	jmp    409c5b <__swc_fn_fc36583a_000141_2ce79e3b+0x2bb>
  409b21:	xor    edi,edi
  409b23:	mov    rsi,r15
  409b26:	mov    edx,0x1
  409b2b:	mov    ecx,0x2
  409b30:	mov    rax,r14
  409b33:	movsxd r8,DWORD PTR [rax]
  409b36:	xor    r9d,r9d
  409b39:	xor    eax,eax
  409b3b:	call   4070c0 <mmap@plt>
  409b40:	mov    rbx,rax
  409b43:	test   rax,rax
  409b46:	sete   al
  409b49:	cmp    rbx,0xffffffffffffffff
  409b4d:	sete   cl
  409b50:	or     al,cl
  409b52:	je     409b6d <__swc_fn_fc36583a_000141_2ce79e3b+0x1cd>
  409b54:	movsxd rdi,DWORD PTR [r14]
  409b57:	xor    eax,eax
  409b59:	call   4070b0 <close@plt>
  409b5e:	mov    rcx,r13
  409b61:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  409b66:	xor    eax,eax
  409b68:	jmp    409c5b <__swc_fn_fc36583a_000141_2ce79e3b+0x2bb>
  409b6d:	lea    rax,[rsp+0x50]
  409b72:	mov    QWORD PTR [rax],0x0
  409b79:	mov    rcx,rbx
  409b7c:	mov    rdx,r15
  409b7f:	mov    r8,rax
  409b82:	call   410760 <__swc_fn_fc36583a_000140_c6b99a56>
  409b87:	mov    r12,rax
  409b8a:	test   rax,rax
  409b8d:	jne    409bb5 <__swc_fn_fc36583a_000141_2ce79e3b+0x215>
  409b8f:	mov    rdi,rbx
  409b92:	mov    rsi,r15
  409b95:	xor    eax,eax
  409b97:	call   407020 <munmap@plt>
  409b9c:	movsxd rdi,DWORD PTR [r14]
  409b9f:	xor    eax,eax
  409ba1:	call   4070b0 <close@plt>
  409ba6:	mov    rcx,r13
  409ba9:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  409bae:	xor    eax,eax
  409bb0:	jmp    409c5b <__swc_fn_fc36583a_000141_2ce79e3b+0x2bb>
  409bb5:	mov    edi,0x20
  409bba:	xor    eax,eax
  409bbc:	call   4070d0 <malloc@plt>
  409bc1:	test   rax,rax
  409bc4:	jne    409be9 <__swc_fn_fc36583a_000141_2ce79e3b+0x249>
  409bc6:	mov    rdi,rbx
  409bc9:	mov    rsi,r15
  409bcc:	xor    eax,eax
  409bce:	call   407020 <munmap@plt>
  409bd3:	movsxd rdi,DWORD PTR [r14]
  409bd6:	xor    eax,eax
  409bd8:	call   4070b0 <close@plt>
  409bdd:	mov    rcx,r13
  409be0:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  409be5:	xor    eax,eax
  409be7:	jmp    409c5b <__swc_fn_fc36583a_000141_2ce79e3b+0x2bb>
  409be9:	mov    rcx,QWORD PTR [rip+0x1d198]        # 426d88 <__swc_bss_base_fc36583a+0x2d48>
  409bf0:	mov    QWORD PTR [rsp+0x70],rcx
  409bf5:	mov    rcx,QWORD PTR [rsp+0xa0]
  409bfd:	mov    QWORD PTR [rsp+0x78],rcx
  409c02:	mov    QWORD PTR [rsp+0x80],r12
  409c0a:	mov    rcx,QWORD PTR [rsp+0x50]
  409c0f:	mov    QWORD PTR [rsp+0x88],rcx
  409c17:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  409c1d:	vmovups XMMWORD PTR [rax],xmm0
  409c21:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  409c2a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  409c2f:	mov    QWORD PTR [rip+0x1d152],rax        # 426d88 <__swc_bss_base_fc36583a+0x2d48>
  409c36:	mov    rax,QWORD PTR [rsp+0x50]
  409c3b:	mov    rbx,QWORD PTR [rsp+0x98]
  409c43:	mov    QWORD PTR [rbx],rax
  409c46:	movsxd rdi,DWORD PTR [r14]
  409c49:	xor    eax,eax
  409c4b:	call   4070b0 <close@plt>
  409c50:	mov    rcx,r13
  409c53:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  409c58:	mov    rax,r12
  409c5b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  409c64:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  409c6d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  409c76:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  409c7f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  409c88:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  409c91:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  409c9a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  409ca3:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  409cac:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  409cb5:	add    rsp,0x150
  409cbc:	pop    r15
  409cbe:	pop    r14
  409cc0:	pop    rsi
  409cc1:	pop    rdi
  409cc2:	pop    r13
  409cc4:	pop    r12
  409cc6:	pop    rbx
  409cc7:	ret
	...

0000000000409cd0 <__swc_fn_fc36583a_000144_72996a5b>:
  409cd0:	push   rbx
  409cd1:	sub    rsp,0xe0
  409cd8:	lea    rbx,[rsp+0x8]
  409cdd:	vxorps xmm0,xmm0,xmm0
  409ce1:	vmovups XMMWORD PTR [rbx],xmm0
  409ce5:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409cea:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409cef:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  409cf4:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  409cf9:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  409cfe:	mov    DWORD PTR [rbx+0x60],0x0
  409d05:	mov    r8,rbx
  409d08:	nop    DWORD PTR [rax+rax*1+0x0]
  409d10:	mov    r9,rcx
  409d13:	movabs rcx,0xcccccccccccccccd
  409d1d:	mov    rax,r9
  409d20:	mul    rcx
  409d23:	mov    r10,rdx
  409d26:	shr    r10,0x3
  409d2a:	mov    rcx,r10
  409d2d:	imul   rdx,r10,0xa
  409d31:	sub    r9,rdx
  409d34:	mov    rdx,QWORD PTR [rip+0x9805]        # 413540 <__swc_rdata_base_fc36583a+0x430>
  409d3b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  409d40:	mov    BYTE PTR [r8],dl
  409d43:	lea    rdx,[r8+0x1]
  409d47:	mov    r8,rdx
  409d4a:	test   r10,r10
  409d4d:	jne    409d10 <__swc_fn_fc36583a_000144_72996a5b+0x40>
  409d4f:	mov    BYTE PTR [rdx],0x0
  409d52:	sub    r8,0x1
  409d56:	mov    rax,rbx
  409d59:	cmp    rax,r8
  409d5c:	jae    409d76 <__swc_fn_fc36583a_000144_72996a5b+0xa6>
  409d5e:	xchg   ax,ax
  409d60:	mov    cl,BYTE PTR [r8]
  409d63:	mov    dl,BYTE PTR [rax]
  409d65:	mov    BYTE PTR [r8],dl
  409d68:	sub    r8,0x1
  409d6c:	mov    BYTE PTR [rax],cl
  409d6e:	inc    rax
  409d71:	cmp    rax,r8
  409d74:	jb     409d60 <__swc_fn_fc36583a_000144_72996a5b+0x90>
  409d76:	xor    eax,eax
  409d78:	test   rbx,rbx
  409d7b:	je     409d9e <__swc_fn_fc36583a_000144_72996a5b+0xce>
  409d7d:	mov    rcx,rbx
  409d80:	mov    dl,BYTE PTR [rcx]
  409d82:	test   dl,dl
  409d84:	je     409d9e <__swc_fn_fc36583a_000144_72996a5b+0xce>
  409d86:	cs nop WORD PTR [rax+rax*1+0x0]
  409d90:	add    rcx,0x1
  409d94:	add    rax,0x1
  409d98:	mov    dl,BYTE PTR [rcx]
  409d9a:	test   dl,dl
  409d9c:	jne    409d90 <__swc_fn_fc36583a_000144_72996a5b+0xc0>
  409d9e:	mov    QWORD PTR [rbx+0xa8],rbx
  409da5:	mov    QWORD PTR [rbx+0xb0],rax
  409dac:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  409db4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  409dbc:	lea    rcx,[rbx+0xb8]
  409dc3:	call   4101c0 <__swc_fn_fc36583a_000116_035d76a1>
  409dc8:	add    rsp,0xe0
  409dcf:	pop    rbx
  409dd0:	ret
	...

0000000000409de0 <__swc_fn_fc36583a_000147_32a497f3>:
  409de0:	sub    rsp,0x8
  409de4:	mov    rax,QWORD PTR [rcx+0x8]
  409de8:	mov    r8,QWORD PTR [rdx+0x8]
  409dec:	cmp    rax,r8
  409def:	je     409df8 <__swc_fn_fc36583a_000147_32a497f3+0x18>
  409df1:	xor    eax,eax
  409df3:	add    rsp,0x8
  409df7:	ret
  409df8:	test   rax,rax
  409dfb:	jne    409e0c <__swc_fn_fc36583a_000147_32a497f3+0x2c>
  409dfd:	test   r8,r8
  409e00:	jne    409e0c <__swc_fn_fc36583a_000147_32a497f3+0x2c>
  409e02:	mov    eax,0x1
  409e07:	add    rsp,0x8
  409e0b:	ret
  409e0c:	mov    rcx,QWORD PTR [rcx]
  409e0f:	mov    rdx,QWORD PTR [rdx]
  409e12:	test   rcx,rcx
  409e15:	sete   r8b
  409e19:	test   rdx,rdx
  409e1c:	sete   r9b
  409e20:	or     r8b,r9b
  409e23:	je     409e30 <__swc_fn_fc36583a_000147_32a497f3+0x50>
  409e25:	cmp    rcx,rdx
  409e28:	sete   al
  409e2b:	add    rsp,0x8
  409e2f:	ret
  409e30:	cmp    rcx,rdx
  409e33:	jne    409e3f <__swc_fn_fc36583a_000147_32a497f3+0x5f>
  409e35:	mov    eax,0x1
  409e3a:	add    rsp,0x8
  409e3e:	ret
  409e3f:	mov    r8,rax
  409e42:	call   40cc60 <__swc_fn_fc36583a_000106_ed4b1681>
  409e47:	test   eax,eax
  409e49:	sete   al
  409e4c:	add    rsp,0x8
  409e50:	ret
	...

0000000000409e60 <__swc_fn_fc36583a_000150_9e4bc402>:
  409e60:	vxorps xmm0,xmm0,xmm0
  409e64:	vmovups XMMWORD PTR [rcx],xmm0
  409e68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e6d:	vxorps xmm0,xmm0,xmm0
  409e71:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e76:	vmovups xmm0,XMMWORD PTR [rip+0x977a]        # 4135f8 <__swc_rdata_base_fc36583a+0x4e8>
  409e7e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e83:	ret
	...

0000000000409e90 <__swc_fn_fc36583a_000153_9e4bc402>:
  409e90:	vxorps xmm0,xmm0,xmm0
  409e94:	vmovups XMMWORD PTR [rcx],xmm0
  409e98:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e9d:	vxorps xmm0,xmm0,xmm0
  409ea1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409ea6:	vmovups xmm0,XMMWORD PTR [rip+0x986a]        # 413718 <__swc_rdata_base_fc36583a+0x608>
  409eae:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409eb3:	mov    QWORD PTR [rcx+0x40],0x0
  409ebb:	ret
  409ebc:	add    BYTE PTR [rax],al
	...

0000000000409ec0 <__swc_fn_fc36583a_000156_2745c4a5>:
  409ec0:	push   rbx
  409ec1:	sub    rsp,0x70
  409ec5:	mov    rax,QWORD PTR [rcx]
  409ec8:	mov    rbx,QWORD PTR [rcx+0x8]
  409ecc:	vxorps xmm0,xmm0,xmm0
  409ed0:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409ed6:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409edc:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409ee2:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  409ee8:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  409eee:	mov    QWORD PTR [rsp+0x48],rdx
  409ef3:	mov    QWORD PTR [rsp+0x50],r8
  409ef8:	mov    rcx,rax
  409efb:	lea    rdx,[rsp+0x8]
  409f00:	mov    rbx,QWORD PTR [rbx+0x18]
  409f04:	call   rbx
  409f06:	add    rsp,0x70
  409f0a:	pop    rbx
  409f0b:	ret
  409f0c:	add    BYTE PTR [rax],al
	...

0000000000409f10 <__swc_fn_fc36583a_000159_d8afac28>:
  409f10:	push   rbx
  409f11:	push   rsi
  409f12:	push   rdi
  409f13:	mov    rbx,r8
  409f16:	mov    rsi,rcx
  409f19:	mov    rdi,rdx
  409f1c:	call   40d980 <__swc_fn_fc36583a_000157_232ffa22>
  409f21:	vmovups xmm0,XMMWORD PTR [rbx]
  409f25:	vmovups XMMWORD PTR [rsi],xmm0
  409f29:	mov    QWORD PTR [rsi+0x18],rdi
  409f2d:	pop    rdi
  409f2e:	pop    rsi
  409f2f:	pop    rbx
  409f30:	ret
	...

0000000000409f40 <__swc_fn_fc36583a_000162_60216e69>:
  409f40:	push   rbx
  409f41:	push   rsi
  409f42:	push   rdi
  409f43:	push   r12
  409f45:	push   r13
  409f47:	sub    rsp,0x50
  409f4b:	mov    rbx,rcx
  409f4e:	mov    rsi,rdx
  409f51:	vmovups xmm0,XMMWORD PTR [rip+0x98cf]        # 413828 <__swc_rdata_base_fc36583a+0x718>
  409f59:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409f5f:	vmovups xmm0,XMMWORD PTR [rip+0x98d1]        # 413838 <__swc_rdata_base_fc36583a+0x728>
  409f67:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409f6d:	vxorps xmm0,xmm0,xmm0
  409f71:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409f77:	mov    rcx,rdx
  409f7a:	call   4098d0 <__swc_fn_fc36583a_000138_0c00232f>
  409f7f:	mov    rdi,rax
  409f82:	test   rax,rax
  409f85:	jne    409fb6 <__swc_fn_fc36583a_000162_60216e69+0x76>
  409f87:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409f8d:	vmovups XMMWORD PTR [rbx],xmm0
  409f91:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409f97:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409f9c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fa2:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fa7:	mov    rax,rbx
  409faa:	add    rsp,0x50
  409fae:	pop    r13
  409fb0:	pop    r12
  409fb2:	pop    rdi
  409fb3:	pop    rsi
  409fb4:	pop    rbx
  409fb5:	ret
  409fb6:	mov    rcx,rdi
  409fb9:	call   411cc0 <__swc_fn_fc36583a_000161_b5a9d657>
  409fbe:	mov    r11,rax
  409fc1:	test   rax,rax
  409fc4:	je     409fce <__swc_fn_fc36583a_000162_60216e69+0x8e>
  409fc6:	mov    al,BYTE PTR [r11+0x24]
  409fca:	test   al,al
  409fcc:	jne    409ffd <__swc_fn_fc36583a_000162_60216e69+0xbd>
  409fce:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fd4:	vmovups XMMWORD PTR [rbx],xmm0
  409fd8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fde:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fe3:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fe9:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fee:	mov    rax,rbx
  409ff1:	add    rsp,0x50
  409ff5:	pop    r13
  409ff7:	pop    r12
  409ff9:	pop    rdi
  409ffa:	pop    rsi
  409ffb:	pop    rbx
  409ffc:	ret
  409ffd:	sub    rsi,rdi
  40a000:	mov    eax,0xffffffff
  40a005:	cmp    rsi,rax
  40a008:	jbe    40a039 <__swc_fn_fc36583a_000162_60216e69+0xf9>
  40a00a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a010:	vmovups XMMWORD PTR [rbx],xmm0
  40a014:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a01a:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a01f:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a025:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a02a:	mov    rax,rbx
  40a02d:	add    rsp,0x50
  40a031:	pop    r13
  40a033:	pop    r12
  40a035:	pop    rdi
  40a036:	pop    rsi
  40a037:	pop    rbx
  40a038:	ret
  40a039:	mov    rdi,QWORD PTR [r11+0x10]
  40a03d:	mov    eax,DWORD PTR [r11+0x20]
  40a041:	xor    ecx,ecx
  40a043:	test   rax,rax
  40a046:	jbe    40a198 <__swc_fn_fc36583a_000162_60216e69+0x258>
  40a04c:	nop    DWORD PTR [rax+0x0]
  40a050:	mov    edx,ecx
  40a052:	imul   r12,rdx,0x14
  40a056:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40a05b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40a060:	mov    r9d,esi
  40a063:	cmp    r9,rdx
  40a066:	jb     40a18b <__swc_fn_fc36583a_000162_60216e69+0x24b>
  40a06c:	add    rdx,r8
  40a06f:	mov    r8d,esi
  40a072:	cmp    r8,rdx
  40a075:	jae    40a18b <__swc_fn_fc36583a_000162_60216e69+0x24b>
  40a07b:	lea    rsi,[rsp+0x38]
  40a080:	mov    eax,DWORD PTR [rdi+0xc]
  40a083:	mov    DWORD PTR [rsp+0x38],eax
  40a087:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40a08c:	mov    rcx,rdi
  40a08f:	mov    rdx,QWORD PTR [r11+0x18]
  40a093:	mov    r8,rsi
  40a096:	mov    r8d,DWORD PTR [r8]
  40a099:	mov    r9,rax
  40a09c:	lea    r10,[rsp+0x10]
  40a0a1:	call   40d9e0 <__swc_fn_fc36583a_000160_01cbb887>
  40a0a6:	test   al,al
  40a0a8:	jne    40a0db <__swc_fn_fc36583a_000162_60216e69+0x19b>
  40a0aa:	vmovups xmm0,XMMWORD PTR [rip+0x97a6]        # 413858 <__swc_rdata_base_fc36583a+0x748>
  40a0b2:	vmovups XMMWORD PTR [rbx],xmm0
  40a0b6:	vmovups xmm0,XMMWORD PTR [rip+0x97aa]        # 413868 <__swc_rdata_base_fc36583a+0x758>
  40a0be:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a0c3:	vxorps xmm0,xmm0,xmm0
  40a0c7:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a0cc:	mov    rax,rbx
  40a0cf:	add    rsp,0x50
  40a0d3:	pop    r13
  40a0d5:	pop    r12
  40a0d7:	pop    rdi
  40a0d8:	pop    rsi
  40a0d9:	pop    rbx
  40a0da:	ret
  40a0db:	lea    r13,[rsp+0x3c]
  40a0e0:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40a0e5:	mov    DWORD PTR [rsp+0x3c],eax
  40a0e9:	test   eax,eax
  40a0eb:	je     40a13c <__swc_fn_fc36583a_000162_60216e69+0x1fc>
  40a0ed:	mov    rcx,rdi
  40a0f0:	mov    rdx,QWORD PTR [r11+0x18]
  40a0f4:	mov    r8d,DWORD PTR [rsi]
  40a0f7:	mov    rax,r13
  40a0fa:	mov    r9d,DWORD PTR [rax]
  40a0fd:	lea    r10,[rsp+0x20]
  40a102:	call   40d9e0 <__swc_fn_fc36583a_000160_01cbb887>
  40a107:	test   al,al
  40a109:	jne    40a13c <__swc_fn_fc36583a_000162_60216e69+0x1fc>
  40a10b:	vmovups xmm0,XMMWORD PTR [rip+0x9775]        # 413888 <__swc_rdata_base_fc36583a+0x778>
  40a113:	vmovups XMMWORD PTR [rbx],xmm0
  40a117:	vmovups xmm0,XMMWORD PTR [rip+0x9779]        # 413898 <__swc_rdata_base_fc36583a+0x788>
  40a11f:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a124:	vxorps xmm0,xmm0,xmm0
  40a128:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a12d:	mov    rax,rbx
  40a130:	add    rsp,0x50
  40a134:	pop    r13
  40a136:	pop    r12
  40a138:	pop    rdi
  40a139:	pop    rsi
  40a13a:	pop    rbx
  40a13b:	ret
  40a13c:	mov    eax,0x1
  40a141:	rex mov BYTE PTR [rsp+0x8],al
  40a146:	cmp    DWORD PTR [r13+0x0],0x0
  40a14b:	je     40a15c <__swc_fn_fc36583a_000162_60216e69+0x21c>
  40a14d:	rex mov BYTE PTR [rsp+0x9],0x1
  40a153:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40a158:	mov    DWORD PTR [rsp+0x30],eax
  40a15c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a162:	vmovups XMMWORD PTR [rbx],xmm0
  40a166:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a16c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a171:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a177:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a17c:	mov    rax,rbx
  40a17f:	add    rsp,0x50
  40a183:	pop    r13
  40a185:	pop    r12
  40a187:	pop    rdi
  40a188:	pop    rsi
  40a189:	pop    rbx
  40a18a:	ret
  40a18b:	add    rcx,0x1
  40a18f:	cmp    rcx,rax
  40a192:	jb     40a050 <__swc_fn_fc36583a_000162_60216e69+0x110>
  40a198:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a19e:	vmovups XMMWORD PTR [rbx],xmm0
  40a1a2:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a1a8:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a1ad:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a1b3:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a1b8:	mov    rax,rbx
  40a1bb:	add    rsp,0x50
  40a1bf:	pop    r13
  40a1c1:	pop    r12
  40a1c3:	pop    rdi
  40a1c4:	pop    rsi
  40a1c5:	pop    rbx
  40a1c6:	ret
	...

000000000040a1d0 <__swc_fn_fc36583a_000165_cf398896>:
  40a1d0:	sub    rsp,0x48
  40a1d4:	call   4095a0 <__swc_fn_fc36583a_000123_9d2cbd72>
  40a1d9:	cmp    rax,0xffffffffffffffff
  40a1dd:	je     40a1e4 <__swc_fn_fc36583a_000165_cf398896+0x14>
  40a1df:	add    rsp,0x48
  40a1e3:	ret
  40a1e4:	lea    rcx,[rip+0x96dd]        # 4138c8 <__swc_rdata_base_fc36583a+0x7b8>
  40a1eb:	vmovups xmm0,XMMWORD PTR [rip+0x96e5]        # 4138d8 <__swc_rdata_base_fc36583a+0x7c8>
  40a1f3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a1f9:	vmovups xmm0,XMMWORD PTR [rip+0x96e7]        # 4138e8 <__swc_rdata_base_fc36583a+0x7d8>
  40a201:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a207:	vmovups xmm0,XMMWORD PTR [rip+0x96e9]        # 4138f8 <__swc_rdata_base_fc36583a+0x7e8>
  40a20f:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a215:	lea    rdx,[rsp+0x8]
  40a21a:	mov    QWORD PTR [rsp+0x38],rax
  40a21f:	call   40cba0 <__swc_fn_fc36583a_000103_67100064>
  40a224:	mov    rax,QWORD PTR [rsp+0x38]
  40a229:	jmp    40a1df <__swc_fn_fc36583a_000165_cf398896+0xf>
  40a22b:	add    BYTE PTR [rax],al
  40a22d:	add    BYTE PTR [rax],al
	...

000000000040a230 <__swc_fn_fc36583a_000168_92b7d63c>:
  40a230:	push   rbx
  40a231:	push   rsi
  40a232:	sub    rsp,0x28
  40a236:	mov    rbx,rcx
  40a239:	mov    DWORD PTR [rsp+0x8],0xbf0
  40a241:	mov    ecx,0xbf0
  40a246:	call   40c790 <__swc_fn_fc36583a_000079_34776ded>
  40a24b:	mov    rsi,rax
  40a24e:	test   rax,rax
  40a251:	jne    40a25c <__swc_fn_fc36583a_000168_92b7d63c+0x2c>
  40a253:	xor    eax,eax
  40a255:	add    rsp,0x28
  40a259:	pop    rsi
  40a25a:	pop    rbx
  40a25b:	ret
  40a25c:	vxorps xmm0,xmm0,xmm0
  40a260:	xor    eax,eax
  40a262:	cs nop WORD PTR [rax+rax*1+0x0]
  40a26c:	nop    DWORD PTR [rax+0x0]
  40a270:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40a275:	add    rax,0x10
  40a279:	cmp    rax,0xbf0
  40a280:	jne    40a270 <__swc_fn_fc36583a_000168_92b7d63c+0x40>
  40a282:	lea    rax,[rbx+0x1]
  40a286:	mov    QWORD PTR [rsi+0x9c0],rax
  40a28d:	mov    rcx,rbx
  40a290:	mov    rdx,rsi
  40a293:	call   40dd40 <__swc_fn_fc36583a_000166_f6173642>
  40a298:	test   al,al
  40a29a:	jne    40a2ad <__swc_fn_fc36583a_000168_92b7d63c+0x7d>
  40a29c:	mov    rcx,rsi
  40a29f:	call   40f110 <__swc_fn_fc36583a_000080_c1514492>
  40a2a4:	xor    eax,eax
  40a2a6:	add    rsp,0x28
  40a2aa:	pop    rsi
  40a2ab:	pop    rbx
  40a2ac:	ret
  40a2ad:	lea    rcx,[rsp+0x18]
  40a2b2:	call   40f690 <__swc_fn_fc36583a_000092_8252f8c0>
  40a2b7:	mov    rax,rsi
  40a2ba:	add    rsp,0x28
  40a2be:	pop    rsi
  40a2bf:	pop    rbx
  40a2c0:	ret
	...

000000000040a2d0 <__swc_fn_fc36583a_000171_c0e8acb1>:
  40a2d0:	xor    eax,eax
  40a2d2:	mov    edx,0x1
  40a2d7:	lock cmpxchg QWORD PTR [rcx],rdx
  40a2dc:	test   rax,rax
  40a2df:	jne    40a2e2 <__swc_fn_fc36583a_000171_c0e8acb1+0x12>
  40a2e1:	ret
  40a2e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2ec:	nop    DWORD PTR [rax+0x0]
  40a2f0:	mov    rax,QWORD PTR [rcx]
  40a2f3:	test   rax,rax
  40a2f6:	je     40a2d0 <__swc_fn_fc36583a_000171_c0e8acb1>
  40a2f8:	jmp    40a2f0 <__swc_fn_fc36583a_000171_c0e8acb1+0x20>
  40a2fa:	add    BYTE PTR [rax],al
  40a2fc:	add    BYTE PTR [rax],al
	...

000000000040a300 <__swc_fn_fc36583a_000174_176517f9>:
  40a300:	push   rsi
  40a301:	push   rdi
  40a302:	sub    rsp,0x38
  40a306:	mov    rsi,rcx
  40a309:	call   40dd50 <__swc_fn_fc36583a_000169_4579a84c>
  40a30e:	mov    rdi,rax
  40a311:	call   40d4c0 <__swc_fn_fc36583a_000130_c1196dfb>
  40a316:	mov    r8,rax
  40a319:	mov    rcx,rdi
  40a31c:	call   40a2d0 <__swc_fn_fc36583a_000171_c0e8acb1>
  40a321:	mov    rax,QWORD PTR [rdi+0x8]
  40a325:	test   rax,rax
  40a328:	je     40a365 <__swc_fn_fc36583a_000174_176517f9+0x65>
  40a32a:	nop    WORD PTR [rax+rax*1+0x0]
  40a330:	cmp    rax,rsi
  40a333:	je     40a365 <__swc_fn_fc36583a_000174_176517f9+0x65>
  40a335:	mov    r9,QWORD PTR [rax]
  40a338:	cmp    QWORD PTR [rax+0x20],r8
  40a33c:	jne    40a35d <__swc_fn_fc36583a_000174_176517f9+0x5d>
  40a33e:	mov    rcx,rdi
  40a341:	mov    rdx,rax
  40a344:	mov    QWORD PTR [rsp+0x28],r8
  40a349:	mov    QWORD PTR [rsp+0x30],r9
  40a34e:	call   4120e0 <__swc_fn_fc36583a_000173_f69b1f05>
  40a353:	mov    r8,QWORD PTR [rsp+0x28]
  40a358:	mov    r9,QWORD PTR [rsp+0x30]
  40a35d:	mov    rax,r9
  40a360:	test   r9,r9
  40a363:	jne    40a330 <__swc_fn_fc36583a_000174_176517f9+0x30>
  40a365:	xor    eax,eax
  40a367:	mov    QWORD PTR [rdi],rax
  40a36a:	add    rsp,0x38
  40a36e:	pop    rdi
  40a36f:	pop    rsi
  40a370:	ret
	...

000000000040a380 <__swc_fn_fc36583a_000177_aa67484d>:
  40a380:	push   rbp
  40a381:	push   rbx
  40a382:	push   r15
  40a384:	push   rsi
  40a385:	push   rdi
  40a386:	push   r12
  40a388:	push   r14
  40a38a:	push   r13
  40a38c:	sub    rsp,0x10
  40a390:	mov    rbp,rsp
  40a393:	vmovups XMMWORD PTR [rsp],xmm6
  40a398:	sub    rsp,0x610
  40a39f:	mov    rbx,rsp
  40a3a2:	mov    ecx,0x17700
  40a3a7:	sub    rsp,0x8
  40a3ab:	call   40de50 <__swc_fn_fc36583a_000175_2744b483>
  40a3b0:	add    rsp,0x8
  40a3b4:	mov    QWORD PTR [rip+0x1c9f5],rax        # 426db0 <__swc_bss_base_fc36583a+0x2d70>
  40a3bb:	mov    ecx,0xbb80
  40a3c0:	sub    rsp,0x8
  40a3c4:	call   40de50 <__swc_fn_fc36583a_000175_2744b483>
  40a3c9:	add    rsp,0x8
  40a3cd:	mov    QWORD PTR [rip+0x1c9e4],rax        # 426db8 <__swc_bss_base_fc36583a+0x2d78>
  40a3d4:	mov    ecx,0xbb80
  40a3d9:	sub    rsp,0x8
  40a3dd:	call   40de50 <__swc_fn_fc36583a_000175_2744b483>
  40a3e2:	add    rsp,0x8
  40a3e6:	mov    QWORD PTR [rip+0x1c9d3],rax        # 426dc0 <__swc_bss_base_fc36583a+0x2d80>
  40a3ed:	xor    ecx,ecx
  40a3ef:	xor    r8d,r8d
  40a3f2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a3fc:	cs nop WORD PTR [rax+rax*1+0x0]
  40a406:	cs nop WORD PTR [rax+rax*1+0x0]
  40a410:	lea    r9,[r8+0x1]
  40a414:	mov    r10,r9
  40a417:	movabs rdx,0x2492492492492493
  40a421:	mov    r15,rax
  40a424:	mov    rax,r8
  40a427:	mul    rdx
  40a42a:	mov    r11,rdx
  40a42d:	mov    rax,r15
  40a430:	mov    rdx,r8
  40a433:	sub    rdx,r11
  40a436:	shr    rdx,1
  40a439:	add    rdx,r11
  40a43c:	shr    rdx,0x2
  40a440:	imul   r11,rdx,0x7
  40a444:	mov    rdx,r8
  40a447:	sub    rdx,r11
  40a44a:	lea    r11,[rdx+0x4]
  40a44e:	mov    rdx,QWORD PTR [rip+0x1c963]        # 426db8 <__swc_bss_base_fc36583a+0x2d78>
  40a455:	mov    QWORD PTR [rdx+r8*8],rcx
  40a459:	mov    rdx,QWORD PTR [rip+0x1c960]        # 426dc0 <__swc_bss_base_fc36583a+0x2d80>
  40a460:	mov    QWORD PTR [rdx+r8*8],r11
  40a464:	xor    r8d,r8d
  40a467:	test   r11,r11
  40a46a:	jbe    40a4d4 <__swc_fn_fc36583a_000177_aa67484d+0x154>
  40a470:	xor    esi,esi
  40a472:	mov    rdi,QWORD PTR [rip+0x1c937]        # 426db0 <__swc_bss_base_fc36583a+0x2d70>
  40a479:	cs nop WORD PTR [rax+rax*1+0x0]
  40a483:	cs nop WORD PTR [rax+rax*1+0x0]
  40a48d:	nop    DWORD PTR [rax]
  40a490:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40a49a:	mov    r15,rax
  40a49d:	mov    rax,r10
  40a4a0:	mul    rdx
  40a4a3:	mov    r12,rdx
  40a4a6:	mov    rax,r15
  40a4a9:	shr    r12,0x3
  40a4ad:	imul   r12,r12,0x1a
  40a4b1:	sub    r10,r12
  40a4b4:	lea    r10,[r10+0x61]
  40a4b8:	mov    BYTE PTR [rdi+rcx*1],r10b
  40a4bc:	inc    rcx
  40a4bf:	shr    rdx,0x3
  40a4c3:	lea    r10,[rdx+rsi*1]
  40a4c7:	add    r8,0x1
  40a4cb:	add    rsi,0x7
  40a4cf:	cmp    r8,r11
  40a4d2:	jb     40a490 <__swc_fn_fc36583a_000177_aa67484d+0x110>
  40a4d4:	mov    r8,r9
  40a4d7:	cmp    r9,0x1770
  40a4de:	jb     40a410 <__swc_fn_fc36583a_000177_aa67484d+0x90>
  40a4e4:	mov    ecx,0x500
  40a4e9:	sub    rsp,0x8
  40a4ed:	call   40de50 <__swc_fn_fc36583a_000175_2744b483>
  40a4f2:	add    rsp,0x8
  40a4f6:	mov    QWORD PTR [rip+0x1c8cb],rax        # 426dc8 <__swc_bss_base_fc36583a+0x2d88>
  40a4fd:	mov    ecx,0x140
  40a502:	sub    rsp,0x8
  40a506:	call   40de50 <__swc_fn_fc36583a_000175_2744b483>
  40a50b:	add    rsp,0x8
  40a50f:	mov    QWORD PTR [rip+0x1c8ba],rax        # 426dd0 <__swc_bss_base_fc36583a+0x2d90>
  40a516:	mov    ecx,0x140
  40a51b:	sub    rsp,0x8
  40a51f:	call   40de50 <__swc_fn_fc36583a_000175_2744b483>
  40a524:	add    rsp,0x8
  40a528:	mov    QWORD PTR [rip+0x1c8a9],rax        # 426dd8 <__swc_bss_base_fc36583a+0x2d98>
  40a52f:	xor    ecx,ecx
  40a531:	xor    r8d,r8d
  40a534:	lea    r9,[rbx+0x68]
  40a538:	vxorps xmm0,xmm0,xmm0
  40a53c:	cs nop WORD PTR [rax+rax*1+0x0]
  40a546:	cs nop WORD PTR [rax+rax*1+0x0]
  40a550:	vmovups XMMWORD PTR [rbx+0x68],xmm0
  40a555:	vmovups XMMWORD PTR [rbx+0x78],xmm0
  40a55a:	mov    r10,QWORD PTR [rip+0x17aaf]        # 422010 <__swc_data_base_fc36583a+0x10>
  40a561:	imul   r10,r10,0x41a7
  40a568:	movabs rdx,0x200000005
  40a572:	mov    r15,rax
  40a575:	mov    rax,r10
  40a578:	mul    rdx
  40a57b:	mov    r11,rdx
  40a57e:	mov    rdx,r10
  40a581:	sub    rdx,r11
  40a584:	shr    rdx,1
  40a587:	add    rdx,r11
  40a58a:	shr    rdx,0x1e
  40a58e:	imul   r11,rdx,0x7fffffff
  40a595:	sub    r10,r11
  40a598:	mov    QWORD PTR [rip+0x17a71],r10        # 422010 <__swc_data_base_fc36583a+0x10>
  40a59f:	movabs rdx,0xaec33e1f671529a5
  40a5a9:	mov    rax,r10
  40a5ac:	mul    rdx
  40a5af:	mov    rax,r15
  40a5b2:	shr    rdx,0xc
  40a5b6:	imul   rdx,rdx,0x1770
  40a5bd:	sub    r10,rdx
  40a5c0:	mov    rdx,QWORD PTR [rip+0x1c7f9]        # 426dc0 <__swc_bss_base_fc36583a+0x2d80>
  40a5c7:	mov    rdx,QWORD PTR [rdx+r10*8]
  40a5cb:	mov    r11,rdx
  40a5ce:	xor    esi,esi
  40a5d0:	test   rdx,rdx
  40a5d3:	jbe    40a608 <__swc_fn_fc36583a_000177_aa67484d+0x288>
  40a5d5:	mov    rdi,QWORD PTR [rip+0x1c7dc]        # 426db8 <__swc_bss_base_fc36583a+0x2d78>
  40a5dc:	mov    r12,QWORD PTR [rip+0x1c7cd]        # 426db0 <__swc_bss_base_fc36583a+0x2d70>
  40a5e3:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5ed:	nop    DWORD PTR [rax]
  40a5f0:	mov    r13,QWORD PTR [rdi+r10*8]
  40a5f4:	add    r13,rsi
  40a5f7:	mov    r13b,BYTE PTR [r12+r13*1]
  40a5fb:	mov    BYTE PTR [r9+rsi*1],r13b
  40a5ff:	add    rsi,0x1
  40a603:	cmp    rsi,rdx
  40a606:	jb     40a5f0 <__swc_fn_fc36583a_000177_aa67484d+0x270>
  40a608:	xor    r10d,r10d
  40a60b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a610:	mov    rsi,QWORD PTR [rip+0x179f9]        # 422010 <__swc_data_base_fc36583a+0x10>
  40a617:	imul   rsi,rsi,0x41a7
  40a61e:	movabs r12,0x200000005
  40a628:	mov    r14,rax
  40a62b:	mov    rax,rsi
  40a62e:	mul    r12
  40a631:	mov    r12,rsi
  40a634:	sub    r12,rdx
  40a637:	shr    r12,1
  40a63a:	add    r12,rdx
  40a63d:	shr    r12,0x1e
  40a641:	imul   rdi,r12,0x7fffffff
  40a648:	sub    rsi,rdi
  40a64b:	mov    QWORD PTR [rip+0x179be],rsi        # 422010 <__swc_data_base_fc36583a+0x10>
  40a652:	mov    rax,rsi
  40a655:	xor    edx,edx
  40a657:	div    r11
  40a65a:	mov    rax,rdx
  40a65d:	mov    r12,rax
  40a660:	imul   rsi,rsi,0x41a7
  40a667:	movabs rdx,0x200000005
  40a671:	mov    r15,r14
  40a674:	mov    rax,rsi
  40a677:	mul    rdx
  40a67a:	mov    rdi,rdx
  40a67d:	mov    rdx,rsi
  40a680:	sub    rdx,rdi
  40a683:	shr    rdx,1
  40a686:	add    rdx,rdi
  40a689:	shr    rdx,0x1e
  40a68d:	imul   rdi,rdx,0x7fffffff
  40a694:	sub    rsi,rdi
  40a697:	mov    QWORD PTR [rip+0x17972],rsi        # 422010 <__swc_data_base_fc36583a+0x10>
  40a69e:	movabs rdx,0xaaaaaaaaaaaaaaab
  40a6a8:	mov    rax,rsi
  40a6ab:	mul    rdx
  40a6ae:	shr    rdx,1
  40a6b1:	lea    rdx,[rdx+rdx*2]
  40a6b5:	mov    r13,rsi
  40a6b8:	sub    r13,rdx
  40a6bb:	imul   rsi,rsi,0x41a7
  40a6c2:	movabs rdx,0x200000005
  40a6cc:	mov    rax,rsi
  40a6cf:	mul    rdx
  40a6d2:	mov    rdi,rdx
  40a6d5:	mov    rdx,rsi
  40a6d8:	sub    rdx,rdi
  40a6db:	shr    rdx,1
  40a6de:	add    rdx,rdi
  40a6e1:	shr    rdx,0x1e
  40a6e5:	imul   rdi,rdx,0x7fffffff
  40a6ec:	sub    rsi,rdi
  40a6ef:	mov    QWORD PTR [rip+0x1791a],rsi        # 422010 <__swc_data_base_fc36583a+0x10>
  40a6f6:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40a700:	mov    rax,rsi
  40a703:	mul    rdx
  40a706:	mov    rax,r15
  40a709:	shr    rdx,0x3
  40a70d:	imul   rdx,rdx,0x1a
  40a711:	sub    rsi,rdx
  40a714:	lea    rdx,[rsi+0x61]
  40a718:	test   r13,r13
  40a71b:	jne    40a726 <__swc_fn_fc36583a_000177_aa67484d+0x3a6>
  40a71d:	mov    BYTE PTR [r9+r12*1],dl
  40a721:	jmp    40a799 <__swc_fn_fc36583a_000177_aa67484d+0x419>
  40a726:	cmp    r13,0x1
  40a72a:	jne    40a75a <__swc_fn_fc36583a_000177_aa67484d+0x3da>
  40a72c:	cmp    r11,0x2
  40a730:	jbe    40a799 <__swc_fn_fc36583a_000177_aa67484d+0x419>
  40a736:	lea    rdx,[r12+0x1]
  40a73b:	cmp    rdx,r11
  40a73e:	jae    40a754 <__swc_fn_fc36583a_000177_aa67484d+0x3d4>
  40a740:	mov    sil,BYTE PTR [r9+r12*1+0x1]
  40a745:	mov    BYTE PTR [r9+r12*1],sil
  40a749:	mov    r12,rdx
  40a74c:	inc    rdx
  40a74f:	cmp    rdx,r11
  40a752:	jb     40a740 <__swc_fn_fc36583a_000177_aa67484d+0x3c0>
  40a754:	sub    r11,0x1
  40a758:	jmp    40a799 <__swc_fn_fc36583a_000177_aa67484d+0x419>
  40a75a:	mov    rsi,r11
  40a75d:	cmp    rsi,r12
  40a760:	jbe    40a791 <__swc_fn_fc36583a_000177_aa67484d+0x411>
  40a762:	cs nop WORD PTR [rax+rax*1+0x0]
  40a76c:	cs nop WORD PTR [rax+rax*1+0x0]
  40a776:	cs nop WORD PTR [rax+rax*1+0x0]
  40a780:	mov    dil,BYTE PTR [r9+rsi*1-0x1]
  40a785:	mov    BYTE PTR [r9+rsi*1],dil
  40a789:	dec    rsi
  40a78c:	cmp    rsi,r12
  40a78f:	ja     40a780 <__swc_fn_fc36583a_000177_aa67484d+0x400>
  40a791:	mov    BYTE PTR [r9+r12*1],dl
  40a795:	add    r11,0x1
  40a799:	add    r10,0x1
  40a79d:	cmp    r10,0x2
  40a7a1:	jb     40a610 <__swc_fn_fc36583a_000177_aa67484d+0x290>
  40a7a7:	mov    rdx,QWORD PTR [rip+0x1c622]        # 426dd0 <__swc_bss_base_fc36583a+0x2d90>
  40a7ae:	mov    QWORD PTR [rdx+r8*8],rcx
  40a7b2:	mov    rdx,QWORD PTR [rip+0x1c61f]        # 426dd8 <__swc_bss_base_fc36583a+0x2d98>
  40a7b9:	mov    QWORD PTR [rdx+r8*8],r11
  40a7bd:	xor    edx,edx
  40a7bf:	test   r11,r11
  40a7c2:	jbe    40a7f4 <__swc_fn_fc36583a_000177_aa67484d+0x474>
  40a7c4:	mov    r10,QWORD PTR [rip+0x1c5fd]        # 426dc8 <__swc_bss_base_fc36583a+0x2d88>
  40a7cb:	cs nop WORD PTR [rax+rax*1+0x0]
  40a7d5:	cs nop WORD PTR [rax+rax*1+0x0]
  40a7df:	nop
  40a7e0:	mov    sil,BYTE PTR [r9+rdx*1]
  40a7e4:	mov    BYTE PTR [r10+rcx*1],sil
  40a7e8:	inc    rcx
  40a7eb:	add    rdx,0x1
  40a7ef:	cmp    rdx,r11
  40a7f2:	jb     40a7e0 <__swc_fn_fc36583a_000177_aa67484d+0x460>
  40a7f4:	add    r8,0x1
  40a7f8:	cmp    r8,0x28
  40a7fc:	jb     40a550 <__swc_fn_fc36583a_000177_aa67484d+0x1d0>
  40a802:	sub    rsp,0x8
  40a806:	call   412160 <__swc_fn_fc36583a_000176_1ca87929>
  40a80b:	add    rsp,0x8
  40a80f:	vmovups xmm6,xmm0
  40a813:	lea    rax,[rbx+0xf8]
  40a81a:	vxorps xmm0,xmm0,xmm0
  40a81e:	xor    ecx,ecx
  40a820:	vmovdqu XMMWORD PTR [rax+rcx*1],xmm0
  40a825:	add    rcx,0x10
  40a829:	cmp    rcx,0x200
  40a830:	jne    40a820 <__swc_fn_fc36583a_000177_aa67484d+0x4a0>
  40a832:	lea    rcx,[rbx+0x2f8]
  40a839:	vxorps xmm0,xmm0,xmm0
  40a83d:	xor    edx,edx
  40a83f:	nop
  40a840:	vmovdqu XMMWORD PTR [rcx+rdx*1],xmm0
  40a845:	add    rdx,0x10
  40a849:	cmp    rdx,0x200
  40a850:	jne    40a840 <__swc_fn_fc36583a_000177_aa67484d+0x4c0>
  40a852:	xor    edx,edx
  40a854:	mov    r8,QWORD PTR [rip+0x1c575]        # 426dd0 <__swc_bss_base_fc36583a+0x2d90>
  40a85b:	mov    QWORD PTR [rsp+0x5b0],r8
  40a863:	mov    r9,QWORD PTR [rip+0x1c56e]        # 426dd8 <__swc_bss_base_fc36583a+0x2d98>
  40a86a:	mov    QWORD PTR [rsp+0x5b8],r9
  40a872:	mov    r10,QWORD PTR [rip+0x1c53f]        # 426db8 <__swc_bss_base_fc36583a+0x2d78>
  40a879:	mov    QWORD PTR [rsp+0x5a0],0x0
  40a885:	mov    QWORD PTR [rsp+0x5c0],r10
  40a88d:	mov    r11,QWORD PTR [rip+0x1c52c]        # 426dc0 <__swc_bss_base_fc36583a+0x2d80>
  40a894:	mov    QWORD PTR [rsp+0x5c8],r11
  40a89c:	jmp    40a8d8 <__swc_fn_fc36583a_000177_aa67484d+0x558>
  40a89e:	cs nop WORD PTR [rax+rax*1+0x0]
  40a8a8:	nop    DWORD PTR [rax+rax*1+0x0]
  40a8b0:	mov    QWORD PTR [rsp+0x5a0],rsi
  40a8b8:	mov    r8,QWORD PTR [rsp+0x5b0]
  40a8c0:	mov    r9,QWORD PTR [rsp+0x5b8]
  40a8c8:	mov    r10,QWORD PTR [rsp+0x5c0]
  40a8d0:	mov    r11,QWORD PTR [rsp+0x5c8]
  40a8d8:	mov    rdi,QWORD PTR [r8+rdx*8]
  40a8dc:	mov    QWORD PTR [rsp+0x5d0],rdi
  40a8e4:	mov    r12,QWORD PTR [r9+rdx*8]
  40a8e8:	mov    QWORD PTR [rsp+0x5d8],r12
  40a8f0:	mov    r13d,0x40000000
  40a8f6:	mov    r14,0xffffffffffffffff
  40a8fd:	xor    r15d,r15d
  40a900:	mov    QWORD PTR [rsp+0x5a8],rdx
  40a908:	vmovq  xmm3,r13
  40a90d:	vmovq  xmm4,r14
  40a912:	vmovq  xmm5,r15
  40a917:	jmp    40a952 <__swc_fn_fc36583a_000177_aa67484d+0x5d2>
  40a919:	cs nop WORD PTR [rax+rax*1+0x0]
  40a923:	cs nop WORD PTR [rax+rax*1+0x0]
  40a92d:	nop    DWORD PTR [rax]
  40a930:	mov    r10,QWORD PTR [rsp+0x5c0]
  40a938:	mov    r11,QWORD PTR [rsp+0x5c8]
  40a940:	mov    rdi,QWORD PTR [rsp+0x5d0]
  40a948:	vmovq  xmm3,r13
  40a94d:	vmovq  xmm4,r14
  40a952:	mov    r8,QWORD PTR [r10+r15*8]
  40a956:	mov    QWORD PTR [rsp+0x5f8],r8
  40a95e:	mov    r9,QWORD PTR [r11+r15*8]
  40a962:	mov    rdx,r9
  40a965:	sub    rdx,r12
  40a968:	mov    rsi,r12
  40a96b:	sub    rsi,r9
  40a96e:	cmovbe rsi,rdx
  40a972:	cmp    rsi,0x3
  40a976:	jbe    40a987 <__swc_fn_fc36583a_000177_aa67484d+0x607>
  40a978:	vmovq  r13,xmm3
  40a97d:	vmovq  r14,xmm4
  40a982:	jmp    40ab0b <__swc_fn_fc36583a_000177_aa67484d+0x78b>
  40a987:	lea    rdx,[r9+0x1]
  40a98b:	xor    esi,esi
  40a98d:	test   rdx,rdx
  40a990:	jbe    40a9ad <__swc_fn_fc36583a_000177_aa67484d+0x62d>
  40a992:	cs nop WORD PTR [rax+rax*1+0x0]
  40a99c:	nop    DWORD PTR [rax+0x0]
  40a9a0:	mov    QWORD PTR [rax+rsi*8],rsi
  40a9a4:	add    rsi,0x1
  40a9a8:	cmp    rsi,rdx
  40a9ab:	jb     40a9a0 <__swc_fn_fc36583a_000177_aa67484d+0x620>
  40a9ad:	xor    esi,esi
  40a9af:	test   r12,r12
  40a9b2:	jbe    40aaed <__swc_fn_fc36583a_000177_aa67484d+0x76d>
  40a9b8:	mov    r10,QWORD PTR [rip+0x1c409]        # 426dc8 <__swc_bss_base_fc36583a+0x2d88>
  40a9bf:	add    r10,rdi
  40a9c2:	vmovsd xmm0,QWORD PTR [rsp+0x5d8]
  40a9cb:	vmovsd xmm1,QWORD PTR [rsp+0x5f8]
  40a9d4:	vmovq  xmm2,r10
  40a9d9:	nop    DWORD PTR [rax+0x0]
  40a9e0:	lea    r11,[rsi+0x1]
  40a9e4:	mov    QWORD PTR [rbx+0x2f8],r11
  40a9eb:	mov    sil,BYTE PTR [r10+rsi*1]
  40a9ef:	xor    edi,edi
  40a9f1:	test   r9,r9
  40a9f4:	jbe    40aa4d <__swc_fn_fc36583a_000177_aa67484d+0x6cd>
  40a9f6:	mov    r14,QWORD PTR [rip+0x1c3b3]        # 426db0 <__swc_bss_base_fc36583a+0x2d70>
  40a9fd:	add    r14,r8
  40aa00:	mov    r15,QWORD PTR [rbx+0xf8]
  40aa07:	mov    r13,r11
  40aa0a:	nop    WORD PTR [rax+rax*1+0x0]
  40aa10:	xor    r8d,r8d
  40aa13:	cmp    BYTE PTR [r14+rdi*1],sil
  40aa17:	setne  r8b
  40aa1b:	add    r8,r15
  40aa1e:	mov    r10,QWORD PTR [rax+rdi*8+0x8]
  40aa23:	mov    r15,r10
  40aa26:	add    r10,0x1
  40aa2a:	cmp    r10,r8
  40aa2d:	cmovb  r8,r10
  40aa31:	lea    r10,[r13+0x1]
  40aa35:	cmp    r10,r8
  40aa38:	cmovb  r8,r10
  40aa3c:	mov    QWORD PTR [rcx+rdi*8+0x8],r8
  40aa41:	mov    r13,r8
  40aa44:	add    rdi,0x1
  40aa48:	cmp    rdi,r9
  40aa4b:	jb     40aa10 <__swc_fn_fc36583a_000177_aa67484d+0x690>
  40aa4d:	xor    r8d,r8d
  40aa50:	test   rdx,rdx
  40aa53:	jbe    40aad1 <__swc_fn_fc36583a_000177_aa67484d+0x751>
  40aa59:	cmp    rdx,0x4
  40aa5d:	jb     40aac0 <__swc_fn_fc36583a_000177_aa67484d+0x740>
  40aa63:	lea    r10,[rdx-0x3]
  40aa67:	nop    WORD PTR [rax+rax*1+0x0]
  40aa70:	mov    rsi,QWORD PTR [rcx+r8*8]
  40aa74:	mov    QWORD PTR [rax+r8*8],rsi
  40aa78:	mov    rsi,QWORD PTR [rcx+r8*8+0x8]
  40aa7d:	mov    QWORD PTR [rax+r8*8+0x8],rsi
  40aa82:	mov    rsi,QWORD PTR [rcx+r8*8+0x10]
  40aa87:	mov    QWORD PTR [rax+r8*8+0x10],rsi
  40aa8c:	mov    rsi,QWORD PTR [rcx+r8*8+0x18]
  40aa91:	mov    QWORD PTR [rax+r8*8+0x18],rsi
  40aa96:	add    r8,0x4
  40aa9a:	cmp    r8,r10
  40aa9d:	jb     40aa70 <__swc_fn_fc36583a_000177_aa67484d+0x6f0>
  40aa9f:	cmp    r8,rdx
  40aaa2:	jae    40aad1 <__swc_fn_fc36583a_000177_aa67484d+0x751>
  40aaa4:	cs nop WORD PTR [rax+rax*1+0x0]
  40aaae:	cs nop WORD PTR [rax+rax*1+0x0]
  40aab8:	nop    DWORD PTR [rax+rax*1+0x0]
  40aac0:	mov    rsi,QWORD PTR [rcx+r8*8]
  40aac4:	mov    QWORD PTR [rax+r8*8],rsi
  40aac8:	add    r8,0x1
  40aacc:	cmp    r8,rdx
  40aacf:	jb     40aac0 <__swc_fn_fc36583a_000177_aa67484d+0x740>
  40aad1:	mov    rsi,r11
  40aad4:	vmovq  r12,xmm0
  40aad9:	cmp    r11,r12
  40aadc:	jae    40aaed <__swc_fn_fc36583a_000177_aa67484d+0x76d>
  40aade:	vmovq  r8,xmm1
  40aae3:	vmovq  r10,xmm2
  40aae8:	jmp    40a9e0 <__swc_fn_fc36583a_000177_aa67484d+0x660>
  40aaed:	mov    rdx,QWORD PTR [rax+r9*8]
  40aaf1:	vmovq  r13,xmm3
  40aaf6:	cmp    rdx,r13
  40aaf9:	cmovb  r13,rdx
  40aafd:	vmovq  r14,xmm4
  40ab02:	vmovq  r15,xmm5
  40ab07:	cmovb  r14,r15
  40ab0b:	add    r15,0x1
  40ab0f:	vmovq  xmm5,r15
  40ab14:	cmp    r15,0x1770
  40ab1b:	jb     40a930 <__swc_fn_fc36583a_000177_aa67484d+0x5b0>
  40ab21:	imul   r13,r13,0x1f
  40ab25:	add    r13,r14
  40ab28:	mov    rsi,QWORD PTR [rsp+0x5a0]
  40ab30:	add    rsi,r13
  40ab33:	mov    rdx,QWORD PTR [rsp+0x5a8]
  40ab3b:	add    rdx,0x1
  40ab3f:	cmp    rdx,0x28
  40ab43:	jb     40a8b0 <__swc_fn_fc36583a_000177_aa67484d+0x530>
  40ab49:	sub    rsp,0x8
  40ab4d:	call   412160 <__swc_fn_fc36583a_000176_1ca87929>
  40ab52:	add    rsp,0x8
  40ab56:	vsubsd xmm0,xmm0,xmm6
  40ab5a:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x8e66]        # 4139c8 <__swc_rdata_base_fc36583a+0x8b8>
  40ab62:	lea    rax,[rip+0x87ff]        # 413368 <__swc_rdata_base_fc36583a+0x258>
  40ab69:	sub    rsp,0x90
  40ab70:	mov    rcx,rsp
  40ab73:	vmovups xmm1,XMMWORD PTR [rip+0x8e2d]        # 4139a8 <__swc_rdata_base_fc36583a+0x898>
  40ab7b:	vmovups XMMWORD PTR [rcx],xmm1
  40ab7f:	mov    QWORD PTR [rcx+0x30],rsp
  40ab83:	lea    rdx,[rip+0x8786]        # 413310 <__swc_rdata_base_fc36583a+0x200>
  40ab8a:	mov    QWORD PTR [rcx+0x38],rdx
  40ab8e:	mov    QWORD PTR [rcx+0x10],rsi
  40ab92:	lea    r8,[rsp+0x10]
  40ab97:	mov    QWORD PTR [rcx+0x40],r8
  40ab9b:	lea    r8,[rip+0x8d76]        # 413918 <__swc_rdata_base_fc36583a+0x808>
  40aba2:	mov    QWORD PTR [rcx+0x48],r8
  40aba6:	vmovups xmm1,XMMWORD PTR [rip+0x8e0a]        # 4139b8 <__swc_rdata_base_fc36583a+0x8a8>
  40abae:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40abb3:	lea    r8,[rsp+0x18]
  40abb8:	mov    QWORD PTR [rcx+0x50],r8
  40abbc:	mov    QWORD PTR [rcx+0x58],rdx
  40abc0:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40abc5:	lea    r8,[rcx+0x28]
  40abc9:	mov    QWORD PTR [rcx+0x60],r8
  40abcd:	lea    r8,[rip+0x8d8c]        # 413960 <__swc_rdata_base_fc36583a+0x850>
  40abd4:	mov    QWORD PTR [rcx+0x68],r8
  40abd8:	mov    QWORD PTR [rcx+0x70],rax
  40abdc:	mov    QWORD PTR [rcx+0x78],rdx
  40abe0:	lea    rax,[rcx+0x30]
  40abe4:	mov    QWORD PTR [rcx+0x80],rax
  40abeb:	mov    QWORD PTR [rcx+0x88],0x5
  40abf6:	lea    rcx,[rcx+0x80]
  40abfd:	sub    rsp,0x8
  40ac01:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  40ac06:	add    rsp,0x6a8
  40ac0d:	vmovups xmm6,XMMWORD PTR [rsp]
  40ac12:	add    rsp,0x10
  40ac16:	pop    r13
  40ac18:	pop    r14
  40ac1a:	pop    r12
  40ac1c:	pop    rdi
  40ac1d:	pop    rsi
  40ac1e:	pop    r15
  40ac20:	pop    rbx
  40ac21:	pop    rbp
  40ac22:	ret
	...

000000000040ac40 <__swc_fn_fc36583a_000001_46f18a51>:
  40ac40:	vxorps xmm0,xmm0,xmm0
  40ac44:	xor    eax,eax
  40ac46:	cs nop WORD PTR [rax+rax*1+0x0]
  40ac50:	cs nop WORD PTR [rax+rax*1+0x0]
  40ac5a:	nop    WORD PTR [rax+rax*1+0x0]
  40ac60:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40ac65:	add    rax,0x10
  40ac69:	cmp    rax,0x2080
  40ac70:	jne    40ac60 <__swc_fn_fc36583a_000001_46f18a51+0x20>
  40ac72:	ret
	...

000000000040ac80 <__swc_fn_fc36583a_000004_1acc36a6>:
  40ac80:	push   rsi
  40ac81:	push   rdi
  40ac82:	push   r12
  40ac84:	push   r13
  40ac86:	push   r14
  40ac88:	mov    rsi,rcx
  40ac8b:	mov    edi,r10d
  40ac8e:	mov    r12,rcx
  40ac91:	mov    r13,r9
  40ac94:	mov    ecx,DWORD PTR [rdx+0x28]
  40ac97:	shlx   r14d,r8d,ecx
  40ac9c:	mov    rcx,rdx
  40ac9f:	mov    edx,r8d
  40aca2:	call   40dfe0 <__swc_fn_fc36583a_000011_6493fbbc>
  40aca7:	mov    rcx,rax
  40acaa:	mov    eax,DWORD PTR [r12+0x3c]
  40acaf:	xor    edx,edx
  40acb1:	div    rdi
  40acb4:	vxorps xmm0,xmm0,xmm0
  40acb8:	vmovdqu XMMWORD PTR [rsi],xmm0
  40acbc:	mov    QWORD PTR [r12+0x60],0x0
  40acc5:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40acca:	mov    QWORD PTR [r12+0x10],rcx
  40accf:	imul   rax,rdi
  40acd3:	lea    rdx,[rcx+rax*1]
  40acd7:	mov    QWORD PTR [r12+0x18],rdx
  40acdc:	mov    QWORD PTR [r12+0x20],rcx
  40ace1:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40ace6:	mov    DWORD PTR [r12+0x28],0x0
  40acef:	mov    DWORD PTR [r12+0x68],0x0
  40acf8:	mov    BYTE PTR [r12+0x39],r13b
  40acfd:	mov    BYTE PTR [r12+0x3a],r14b
  40ad02:	mov    BYTE PTR [r12+0x3b],0x1
  40ad08:	mov    DWORD PTR [r12+0x6c],0x0
  40ad11:	mov    rcx,r12
  40ad14:	mov    edx,edi
  40ad16:	call   40df40 <__swc_fn_fc36583a_000005_b2240b56>
  40ad1b:	pop    r14
  40ad1d:	pop    r13
  40ad1f:	pop    r12
  40ad21:	pop    rdi
  40ad22:	pop    rsi
  40ad23:	ret
	...

000000000040ad30 <__swc_fn_fc36583a_000007_614a4804>:
  40ad30:	mov    r8d,0x1
  40ad36:	xor    eax,eax
  40ad38:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40ad3e:	test   eax,eax
  40ad40:	jne    40ad30 <__swc_fn_fc36583a_000007_614a4804>
  40ad42:	ret
	...

000000000040ad50 <__swc_fn_fc36583a_000010_395bb04b>:
  40ad50:	lea    r8,[rcx+0x60]
  40ad54:	mov    rax,QWORD PTR [r8]
  40ad57:	mov    r9,rax
  40ad5a:	nop    WORD PTR [rax+rax*1+0x0]
  40ad60:	mov    QWORD PTR [rdx],r9
  40ad63:	mov    rax,r9
  40ad66:	lock cmpxchg QWORD PTR [r8],rdx
  40ad6b:	cmp    rax,r9
  40ad6e:	jne    40add7 <__swc_fn_fc36583a_000010_395bb04b+0x87>
  40ad70:	mov    eax,DWORD PTR [rcx+0x6c]
  40ad73:	test   eax,eax
  40ad75:	je     40add6 <__swc_fn_fc36583a_000010_395bb04b+0x86>
  40ad77:	lea    rdx,[rcx+0x70]
  40ad7b:	mov    r9d,0x1
  40ad81:	xor    eax,eax
  40ad83:	lock cmpxchg DWORD PTR [rdx],r9d
  40ad88:	test   eax,eax
  40ad8a:	jne    40add6 <__swc_fn_fc36583a_000010_395bb04b+0x86>
  40ad8c:	mov    rax,rcx
  40ad8f:	and    rax,0xffffffffffc00000
  40ad96:	mov    rax,QWORD PTR [rax+0x8]
  40ad9a:	test   rax,rax
  40ad9d:	jne    40ada5 <__swc_fn_fc36583a_000010_395bb04b+0x55>
  40ad9f:	xor    eax,eax
  40ada1:	xchg   DWORD PTR [rdx],eax
  40ada3:	jmp    40add6 <__swc_fn_fc36583a_000010_395bb04b+0x86>
  40ada5:	lea    rdx,[rax+0x2a80]
  40adac:	mov    rax,QWORD PTR [rdx]
  40adaf:	mov    r8,rax
  40adb2:	cs nop WORD PTR [rax+rax*1+0x0]
  40adbc:	nop    DWORD PTR [rax+0x0]
  40adc0:	mov    QWORD PTR [rcx+0x78],r8
  40adc4:	mov    rax,r8
  40adc7:	lock cmpxchg QWORD PTR [rdx],rcx
  40adcc:	cmp    rax,r8
  40adcf:	je     40add6 <__swc_fn_fc36583a_000010_395bb04b+0x86>
  40add1:	mov    r8,rax
  40add4:	jmp    40adc0 <__swc_fn_fc36583a_000010_395bb04b+0x70>
  40add6:	ret
  40add7:	mov    r9,rax
  40adda:	jmp    40ad60 <__swc_fn_fc36583a_000010_395bb04b+0x10>
	...

000000000040ade0 <__swc_fn_fc36583a_000013_9ba72deb>:
  40ade0:	push   rsi
  40ade1:	push   rdi
  40ade2:	push   r12
  40ade4:	push   r13
  40ade6:	push   r14
  40ade8:	push   r15
  40adea:	push   rbx
  40adeb:	sub    rsp,0x30
  40adef:	mov    QWORD PTR [rsp+0x18],r8
  40adf4:	mov    rsi,rcx
  40adf7:	mov    rdi,rdx
  40adfa:	mov    rdx,QWORD PTR [rsi+0x40]
  40adfe:	xchg   ax,ax
  40ae00:	mov    rax,rdx
  40ae03:	not    rax
  40ae06:	and    rax,QWORD PTR [rsi+0x20]
  40ae0a:	test   rax,rax
  40ae0d:	jne    40ae21 <__swc_fn_fc36583a_000013_9ba72deb+0x41>
  40ae0f:	xor    eax,eax
  40ae11:	add    rsp,0x30
  40ae15:	pop    rbx
  40ae16:	pop    r15
  40ae18:	pop    r14
  40ae1a:	pop    r13
  40ae1c:	pop    r12
  40ae1e:	pop    rdi
  40ae1f:	pop    rsi
  40ae20:	ret
  40ae21:	xor    ecx,ecx
  40ae23:	tzcnt  rcx,rax
  40ae28:	lea    r12,[rsp+0x8]
  40ae2d:	mov    DWORD PTR [rsp+0x8],ecx
  40ae31:	mov    r13d,0x1
  40ae37:	shl    r13,cl
  40ae3a:	mov    rcx,rdx
  40ae3d:	or     rcx,r13
  40ae40:	mov    rax,rdx
  40ae43:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40ae49:	cmp    rax,rdx
  40ae4c:	je     40ae53 <__swc_fn_fc36583a_000013_9ba72deb+0x73>
  40ae4e:	mov    rdx,rax
  40ae51:	jmp    40ae00 <__swc_fn_fc36583a_000013_9ba72deb+0x20>
  40ae53:	mov    eax,DWORD PTR [r12]
  40ae57:	shl    rax,0x4
  40ae5b:	lea    r14,[rsi+rax*8+0x80]
  40ae63:	mov    rcx,rsi
  40ae66:	mov    rax,r12
  40ae69:	mov    edx,DWORD PTR [rax]
  40ae6b:	call   40dfe0 <__swc_fn_fc36583a_000011_6493fbbc>
  40ae70:	mov    r15,rax
  40ae73:	mov    rcx,rsi
  40ae76:	mov    rdx,r13
  40ae79:	call   40e140 <__swc_fn_fc36583a_000017_4df2d1a0>
  40ae7e:	test   al,al
  40ae80:	je     40aeb8 <__swc_fn_fc36583a_000013_9ba72deb+0xd8>
  40ae82:	mov    ecx,DWORD PTR [r14+0x3c]
  40ae86:	lea    rdx,[rip+0x191cb]        # 424058 <__swc_bss_base_fc36583a+0x18>
  40ae8d:	mov    r8,QWORD PTR [rip+0x191c4]        # 424058 <__swc_bss_base_fc36583a+0x18>
  40ae94:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae9e:	xchg   ax,ax
  40aea0:	mov    r9,r8
  40aea3:	sub    r9,rcx
  40aea6:	mov    rax,r8
  40aea9:	lock cmpxchg QWORD PTR [rdx],r9
  40aeae:	cmp    rax,r8
  40aeb1:	je     40af19 <__swc_fn_fc36583a_000013_9ba72deb+0x139>
  40aeb3:	mov    r8,rax
  40aeb6:	jmp    40aea0 <__swc_fn_fc36583a_000013_9ba72deb+0xc0>
  40aeb8:	mov    rcx,rsi
  40aebb:	mov    rax,r12
  40aebe:	mov    edx,DWORD PTR [rax]
  40aec0:	call   407450 <__swc_fn_fc36583a_000012_c7df5d22>
  40aec5:	mov    rcx,r15
  40aec8:	and    rcx,0xffffffffffff0000
  40aecf:	lea    rcx,[rcx+0x10000]
  40aed6:	mov    rbx,rax
  40aed9:	cmp    rax,rcx
  40aedc:	cmova  rbx,rcx
  40aee0:	mov    rax,rbx
  40aee3:	sub    rax,r15
  40aee6:	mov    rcx,r15
  40aee9:	mov    rdx,rax
  40aeec:	call   4072a0 <__swc_fn_fc36583a_000003_7ab4792e>
  40aef1:	test   al,al
  40aef3:	jne    40af12 <__swc_fn_fc36583a_000013_9ba72deb+0x132>
  40aef5:	mov    rcx,rsi
  40aef8:	mov    rdx,r13
  40aefb:	call   407600 <__swc_fn_fc36583a_000018_7d1e8a10>
  40af00:	xor    eax,eax
  40af02:	add    rsp,0x30
  40af06:	pop    rbx
  40af07:	pop    r15
  40af09:	pop    r14
  40af0b:	pop    r13
  40af0d:	pop    r12
  40af0f:	pop    rdi
  40af10:	pop    rsi
  40af11:	ret
  40af12:	sub    rbx,r15
  40af15:	mov    DWORD PTR [r14+0x3c],ebx
  40af19:	mov    rcx,r14
  40af1c:	mov    rdx,rsi
  40af1f:	mov    r8d,DWORD PTR [r12]
  40af23:	mov    r9d,edi
  40af26:	mov    rbx,QWORD PTR [rsp+0x18]
  40af2b:	mov    r10d,ebx
  40af2e:	call   40ac80 <__swc_fn_fc36583a_000004_1acc36a6>
  40af33:	mov    rax,r14
  40af36:	add    rsp,0x30
  40af3a:	pop    rbx
  40af3b:	pop    r15
  40af3d:	pop    r14
  40af3f:	pop    r13
  40af41:	pop    r12
  40af43:	pop    rdi
  40af44:	pop    rsi
  40af45:	ret
	...

000000000040af50 <__swc_fn_fc36583a_000016_4b207b58>:
  40af50:	mov    r8,QWORD PTR [rcx+0x48]
  40af54:	cs nop WORD PTR [rax+rax*1+0x0]
  40af5e:	xchg   ax,ax
  40af60:	mov    r9,r8
  40af63:	or     r9,rdx
  40af66:	mov    rax,r8
  40af69:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40af6f:	cmp    rax,r8
  40af72:	jne    40af75 <__swc_fn_fc36583a_000016_4b207b58+0x25>
  40af74:	ret
  40af75:	mov    r8,rax
  40af78:	jmp    40af60 <__swc_fn_fc36583a_000016_4b207b58+0x10>
  40af7a:	add    BYTE PTR [rax],al
  40af7c:	add    BYTE PTR [rax],al
	...

000000000040af80 <__swc_fn_fc36583a_000019_2cc1532c>:
  40af80:	push   rsi
  40af81:	push   rdi
  40af82:	push   r12
  40af84:	mov    rsi,rcx
  40af87:	xor    edi,edi
  40af89:	lea    r12,[rip+0x190d8]        # 424068 <__swc_bss_base_fc36583a+0x28>
  40af90:	mov    eax,DWORD PTR [r12]
  40af94:	xor    ecx,ecx
  40af96:	test   rax,rax
  40af99:	jbe    40afd4 <__swc_fn_fc36583a_000019_2cc1532c+0x54>
  40af9b:	nop    DWORD PTR [rax+rax*1+0x0]
  40afa0:	lea    rdx,[rip+0x190c9]        # 424070 <__swc_bss_base_fc36583a+0x30>
  40afa7:	mov    r8d,ecx
  40afaa:	lea    r8,[r8+r8*2]
  40afae:	lea    r8,[rdx+r8*8]
  40afb2:	mov    rdx,QWORD PTR [r8+0x10]
  40afb6:	add    rdx,0x400000
  40afbd:	cmp    rdx,0x40000000
  40afc4:	ja     40afcb <__swc_fn_fc36583a_000019_2cc1532c+0x4b>
  40afc6:	mov    rdi,r8
  40afc9:	jmp    40afd4 <__swc_fn_fc36583a_000019_2cc1532c+0x54>
  40afcb:	add    rcx,0x1
  40afcf:	cmp    rcx,rax
  40afd2:	jb     40afa0 <__swc_fn_fc36583a_000019_2cc1532c+0x20>
  40afd4:	test   rdi,rdi
  40afd7:	jne    40b063 <__swc_fn_fc36583a_000019_2cc1532c+0xe3>
  40afdd:	cmp    DWORD PTR [r12],0x10
  40afe2:	jae    40b04b <__swc_fn_fc36583a_000019_2cc1532c+0xcb>
  40afe4:	mov    ecx,0x40400000
  40afe9:	call   40df00 <__swc_fn_fc36583a_000002_884bb5c0>
  40afee:	test   rax,rax
  40aff1:	je     40b04b <__swc_fn_fc36583a_000019_2cc1532c+0xcb>
  40aff3:	lea    rcx,[rip+0x19076]        # 424070 <__swc_bss_base_fc36583a+0x30>
  40affa:	mov    edx,DWORD PTR [r12]
  40affe:	lea    rdx,[rdx+rdx*2]
  40b002:	lea    rdx,[rcx+rdx*8]
  40b006:	mov    QWORD PTR [rdx],rax
  40b009:	lea    rax,[rax+0x3fffff]
  40b010:	and    rax,0xffffffffffc00000
  40b017:	mov    QWORD PTR [rdx+0x8],rax
  40b01b:	mov    QWORD PTR [rdx+0x10],0x0
  40b023:	mov    edx,DWORD PTR [rip+0x1903f]        # 424068 <__swc_bss_base_fc36583a+0x28>
  40b029:	nop    DWORD PTR [rax+0x0]
  40b030:	lea    r9d,[rdx+0x1]
  40b034:	mov    rax,rdx
  40b037:	lock cmpxchg DWORD PTR [r12],r9d
  40b03d:	mov    r8d,eax
  40b040:	cmp    eax,edx
  40b042:	je     40b052 <__swc_fn_fc36583a_000019_2cc1532c+0xd2>
  40b044:	mov    rdx,r8
  40b047:	jmp    40b030 <__swc_fn_fc36583a_000019_2cc1532c+0xb0>
  40b049:	jmp    40b052 <__swc_fn_fc36583a_000019_2cc1532c+0xd2>
  40b04b:	xor    eax,eax
  40b04d:	pop    r12
  40b04f:	pop    rdi
  40b050:	pop    rsi
  40b051:	ret
  40b052:	mov    eax,DWORD PTR [rip+0x19010]        # 424068 <__swc_bss_base_fc36583a+0x28>
  40b058:	sub    eax,0x1
  40b05b:	lea    rdi,[rax+rax*2]
  40b05f:	lea    rdi,[rcx+rdi*8]
  40b063:	mov    r12,QWORD PTR [rdi+0x8]
  40b067:	add    r12,QWORD PTR [rdi+0x10]
  40b06b:	mov    rcx,r12
  40b06e:	mov    edx,0x3000
  40b073:	call   4072a0 <__swc_fn_fc36583a_000003_7ab4792e>
  40b078:	test   al,al
  40b07a:	jne    40b083 <__swc_fn_fc36583a_000019_2cc1532c+0x103>
  40b07c:	xor    eax,eax
  40b07e:	pop    r12
  40b080:	pop    rdi
  40b081:	pop    rsi
  40b082:	ret
  40b083:	vxorps xmm0,xmm0,xmm0
  40b087:	xor    eax,eax
  40b089:	cs nop WORD PTR [rax+rax*1+0x0]
  40b093:	cs nop WORD PTR [rax+rax*1+0x0]
  40b09d:	nop    DWORD PTR [rax]
  40b0a0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40b0a6:	add    rax,0x10
  40b0aa:	cmp    rax,0x3000
  40b0b1:	jne    40b0a0 <__swc_fn_fc36583a_000019_2cc1532c+0x120>
  40b0b3:	mov    DWORD PTR [r12+0x28],esi
  40b0b8:	mov    eax,0x40
  40b0bd:	mov    ecx,esi
  40b0bf:	shr    eax,cl
  40b0c1:	mov    DWORD PTR [r12+0x2c],eax
  40b0c6:	cmp    DWORD PTR [r12+0x2c],0x40
  40b0cc:	jb     40b0d7 <__swc_fn_fc36583a_000019_2cc1532c+0x157>
  40b0ce:	mov    rax,0xffffffffffffffff
  40b0d5:	jmp    40b0e7 <__swc_fn_fc36583a_000019_2cc1532c+0x167>
  40b0d7:	mov    eax,0x1
  40b0dc:	mov    ecx,DWORD PTR [r12+0x2c]
  40b0e1:	shl    rax,cl
  40b0e4:	dec    rax
  40b0e7:	mov    QWORD PTR [r12+0x20],rax
  40b0ec:	mov    DWORD PTR [r12],0x4e540001
  40b0f4:	mov    DWORD PTR [r12+0x4],0x53474d45
  40b0fd:	add    QWORD PTR [rdi+0x10],0x400000
  40b105:	mov    rax,r12
  40b108:	pop    r12
  40b10a:	pop    rdi
  40b10b:	pop    rsi
  40b10c:	ret
  40b10d:	add    BYTE PTR [rax],al
	...

000000000040b110 <__swc_fn_fc36583a_000022_3a2e2048>:
  40b110:	mov    eax,0x1
  40b115:	mov    edx,DWORD PTR [rip+0x18f4d]        # 424068 <__swc_bss_base_fc36583a+0x28>
  40b11b:	cmp    eax,edx
  40b11d:	jae    40b16b <__swc_fn_fc36583a_000022_3a2e2048+0x5b>
  40b11f:	nop
  40b120:	lea    r8,[rip+0x18f49]        # 424070 <__swc_bss_base_fc36583a+0x30>
  40b127:	lea    r9,[rax+rax*2]
  40b12b:	lea    r9,[r8+r9*8]
  40b12f:	mov    r8,rcx
  40b132:	sub    r8,QWORD PTR [r9+0x8]
  40b136:	mov    r9,QWORD PTR [r9+0x10]
  40b13a:	cmp    r8,r9
  40b13d:	jae    40b165 <__swc_fn_fc36583a_000022_3a2e2048+0x55>
  40b13f:	mov    rax,rcx
  40b142:	and    rax,0xffffffffffc00000
  40b149:	shr    rcx,0x10
  40b14d:	and    ecx,0x3f
  40b150:	mov    edx,DWORD PTR [rax+0x28]
  40b153:	shrx   ecx,ecx,edx
  40b158:	shl    rcx,0x4
  40b15c:	lea    rax,[rax+rcx*8+0x80]
  40b164:	ret
  40b165:	inc    eax
  40b167:	cmp    eax,edx
  40b169:	jb     40b120 <__swc_fn_fc36583a_000022_3a2e2048+0x10>
  40b16b:	xor    eax,eax
  40b16d:	ret
	...

000000000040b170 <__swc_fn_fc36583a_000025_4aca8b9e>:
  40b170:	vxorps xmm0,xmm0,xmm0
  40b174:	vmovups XMMWORD PTR [rcx],xmm0
  40b178:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b17d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b182:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b187:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40b18c:	mov    QWORD PTR [rcx+0x50],0x0
  40b194:	ret
	...

000000000040b1a0 <__swc_fn_fc36583a_000028_4aca8b9e>:
  40b1a0:	vxorps xmm0,xmm0,xmm0
  40b1a4:	xor    eax,eax
  40b1a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40b1b0:	cs nop WORD PTR [rax+rax*1+0x0]
  40b1ba:	nop    WORD PTR [rax+rax*1+0x0]
  40b1c0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40b1c5:	add    rax,0x10
  40b1c9:	cmp    rax,0x9b0
  40b1d0:	jne    40b1c0 <__swc_fn_fc36583a_000028_4aca8b9e+0x20>
  40b1d2:	mov    QWORD PTR [rcx+0x9b0],0x0
  40b1dd:	ret
	...

000000000040b1e0 <__swc_fn_fc36583a_000031_90860ff2>:
  40b1e0:	push   rsi
  40b1e1:	push   rdi
  40b1e2:	sub    rsp,0x8
  40b1e6:	lea    rsi,[rip+0x16e1b]        # 422008 <__swc_data_base_fc36583a+0x8>
  40b1ed:	mov    rax,QWORD PTR [rsi]
  40b1f0:	mov    ecx,0xffffffff
  40b1f5:	cmp    rax,rcx
  40b1f8:	je     40b201 <__swc_fn_fc36583a_000031_90860ff2+0x21>
  40b1fa:	add    rsp,0x8
  40b1fe:	pop    rdi
  40b1ff:	pop    rsi
  40b200:	ret
  40b201:	mov    rcx,QWORD PTR [rip+0x7e70]        # 413078 <__swc_fn_fc36583a_000176_1ca87929+0xf18>
  40b208:	call   409670 <__swc_fn_fc36583a_000126_102fe7b9>
  40b20d:	mov    rcx,rax
  40b210:	mov    eax,0xffffffff
  40b215:	lock cmpxchg QWORD PTR [rsi],rcx
  40b21a:	mov    rdi,rax
  40b21d:	mov    eax,0xffffffff
  40b222:	cmp    rdi,rax
  40b225:	je     40b236 <__swc_fn_fc36583a_000031_90860ff2+0x56>
  40b227:	call   40d410 <__swc_fn_fc36583a_000127_8dffa290>
  40b22c:	mov    rax,rdi
  40b22f:	add    rsp,0x8
  40b233:	pop    rdi
  40b234:	pop    rsi
  40b235:	ret
  40b236:	mov    rax,rcx
  40b239:	add    rsp,0x8
  40b23d:	pop    rdi
  40b23e:	pop    rsi
  40b23f:	ret

000000000040b240 <__swc_fn_fc36583a_000034_25f19556>:
  40b240:	sub    rsp,0x8
  40b244:	vxorps xmm0,xmm0,xmm0
  40b248:	xor    eax,eax
  40b24a:	cs nop WORD PTR [rax+rax*1+0x0]
  40b254:	cs nop WORD PTR [rax+rax*1+0x0]
  40b25e:	xchg   ax,ax
  40b260:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40b265:	add    rax,0x10
  40b269:	cmp    rax,0x2b00
  40b270:	jne    40b260 <__swc_fn_fc36583a_000034_25f19556+0x20>
  40b272:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40b27c:	xor    al,al
  40b27e:	mov    rdx,rax
  40b281:	xor    al,al
  40b283:	mov    r8,rax
  40b286:	xor    al,al
  40b288:	mov    r9,rax
  40b28b:	xor    al,al
  40b28d:	mov    r10,rax
  40b290:	xor    al,al
  40b292:	mov    r11,rax
  40b295:	call   40e370 <__swc_fn_fc36583a_000035_95622a2b>
  40b29a:	add    rsp,0x8
  40b29e:	ret
	...

000000000040b2a0 <__swc_fn_fc36583a_000037_b4982903>:
  40b2a0:	push   rsi
  40b2a1:	push   rdi
  40b2a2:	push   r12
  40b2a4:	mov    rsi,r8
  40b2a7:	mov    rdi,rdx
  40b2aa:	mov    rcx,rdx
  40b2ad:	call   40df00 <__swc_fn_fc36583a_000002_884bb5c0>
  40b2b2:	mov    r12,rax
  40b2b5:	test   rax,rax
  40b2b8:	jne    40b2c1 <__swc_fn_fc36583a_000037_b4982903+0x21>
  40b2ba:	xor    eax,eax
  40b2bc:	pop    r12
  40b2be:	pop    rdi
  40b2bf:	pop    rsi
  40b2c0:	ret
  40b2c1:	mov    rcx,r12
  40b2c4:	mov    rdx,rsi
  40b2c7:	call   4072a0 <__swc_fn_fc36583a_000003_7ab4792e>
  40b2cc:	test   al,al
  40b2ce:	jne    40b2e2 <__swc_fn_fc36583a_000037_b4982903+0x42>
  40b2d0:	mov    rcx,r12
  40b2d3:	mov    rdx,rdi
  40b2d6:	call   4101a0 <__swc_fn_fc36583a_000113_49b378a9>
  40b2db:	xor    eax,eax
  40b2dd:	pop    r12
  40b2df:	pop    rdi
  40b2e0:	pop    rsi
  40b2e1:	ret
  40b2e2:	mov    rax,r12
  40b2e5:	pop    r12
  40b2e7:	pop    rdi
  40b2e8:	pop    rsi
  40b2e9:	ret
	...

000000000040b300 <__swc_fn_fc36583a_000040_6895916d>:
  40b300:	push   rsi
  40b301:	push   rdi
  40b302:	push   r12
  40b304:	mov    rsi,rcx
  40b307:	mov    edx,0x9b8
  40b30c:	call   40e3e0 <__swc_fn_fc36583a_000038_788ceb38>
  40b311:	mov    rdi,rax
  40b314:	test   rax,rax
  40b317:	jne    40b320 <__swc_fn_fc36583a_000040_6895916d+0x20>
  40b319:	xor    eax,eax
  40b31b:	pop    r12
  40b31d:	pop    rdi
  40b31e:	pop    rsi
  40b31f:	ret
  40b320:	vxorps xmm0,xmm0,xmm0
  40b324:	xor    eax,eax
  40b326:	cs nop WORD PTR [rax+rax*1+0x0]
  40b330:	cs nop WORD PTR [rax+rax*1+0x0]
  40b33a:	nop    WORD PTR [rax+rax*1+0x0]
  40b340:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40b345:	add    rax,0x10
  40b349:	cmp    rax,0x9b0
  40b350:	jne    40b340 <__swc_fn_fc36583a_000040_6895916d+0x40>
  40b352:	mov    QWORD PTR [rdi+0x9b0],0x0
  40b35d:	mov    QWORD PTR [rdi],rsi
  40b360:	call   40d4c0 <__swc_fn_fc36583a_000130_c1196dfb>
  40b365:	mov    QWORD PTR [rdi+0x18],rax
  40b369:	lea    r12,[rsi+0x10]
  40b36d:	mov    rcx,r12
  40b370:	call   4098c0 <__swc_fn_fc36583a_000135_e3032dc2>
  40b375:	mov    rax,QWORD PTR [rsi+0x20]
  40b379:	mov    QWORD PTR [rdi+0x8],rax
  40b37d:	mov    rax,QWORD PTR [rsi+0x20]
  40b381:	test   rax,rax
  40b384:	je     40b38a <__swc_fn_fc36583a_000040_6895916d+0x8a>
  40b386:	mov    QWORD PTR [rax+0x10],rdi
  40b38a:	mov    QWORD PTR [rsi+0x20],rdi
  40b38e:	mov    rcx,r12
  40b391:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  40b396:	mov    rax,rdi
  40b399:	pop    r12
  40b39b:	pop    rdi
  40b39c:	pop    rsi
  40b39d:	ret
	...

000000000040b3a0 <__swc_fn_fc36583a_000043_957e4917>:
  40b3a0:	mov    rax,QWORD PTR [rdx+0x10]
  40b3a4:	test   rax,rax
  40b3a7:	je     40b3b3 <__swc_fn_fc36583a_000043_957e4917+0x13>
  40b3a9:	mov    rcx,QWORD PTR [rdx+0x8]
  40b3ad:	mov    QWORD PTR [rax+0x8],rcx
  40b3b1:	jmp    40b3bb <__swc_fn_fc36583a_000043_957e4917+0x1b>
  40b3b3:	mov    rax,QWORD PTR [rdx+0x8]
  40b3b7:	mov    QWORD PTR [rcx+0x20],rax
  40b3bb:	mov    rax,QWORD PTR [rdx+0x8]
  40b3bf:	test   rax,rax
  40b3c2:	je     40b3cc <__swc_fn_fc36583a_000043_957e4917+0x2c>
  40b3c4:	mov    rcx,QWORD PTR [rdx+0x10]
  40b3c8:	mov    QWORD PTR [rax+0x10],rcx
  40b3cc:	vxorps xmm0,xmm0,xmm0
  40b3d0:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40b3d5:	ret
	...

000000000040b3e0 <__swc_fn_fc36583a_000046_88f44774>:
  40b3e0:	sub    rsp,0x8
  40b3e4:	mov    r9,r8
  40b3e7:	mov    r10,rdx
  40b3ea:	call   40e490 <__swc_fn_fc36583a_000044_9c2ade9b>
  40b3ef:	mov    eax,0x1
  40b3f4:	xchg   DWORD PTR [r9+0x6c],eax
  40b3f8:	mov    rax,QWORD PTR [r9+0x60]
  40b3fc:	test   rax,rax
  40b3ff:	je     40b443 <__swc_fn_fc36583a_000046_88f44774+0x63>
  40b401:	xor    eax,eax
  40b403:	xchg   DWORD PTR [r9+0x6c],eax
  40b407:	movzx  eax,BYTE PTR [r9+0x39]
  40b40c:	lea    rax,[rax+rax*4]
  40b410:	lea    rax,[r10+rax*8+0x28]
  40b415:	mov    QWORD PTR [r9+0x50],0x0
  40b41d:	mov    rcx,QWORD PTR [rax+0x8]
  40b421:	mov    QWORD PTR [r9+0x48],rcx
  40b425:	mov    rcx,QWORD PTR [rax+0x8]
  40b429:	test   rcx,rcx
  40b42c:	je     40b434 <__swc_fn_fc36583a_000046_88f44774+0x54>
  40b42e:	mov    QWORD PTR [rcx+0x50],r9
  40b432:	jmp    40b438 <__swc_fn_fc36583a_000046_88f44774+0x58>
  40b434:	mov    QWORD PTR [rax+0x10],r9
  40b438:	mov    QWORD PTR [rax+0x8],r9
  40b43c:	xor    eax,eax
  40b43e:	add    rsp,0x8
  40b442:	ret
  40b443:	movzx  eax,BYTE PTR [r9+0x39]
  40b448:	lea    rax,[rax+rax*4]
  40b44c:	lea    rax,[r10+rax*8+0x28]
  40b451:	mov    QWORD PTR [r9+0x50],0x0
  40b459:	mov    rcx,QWORD PTR [rax+0x18]
  40b45d:	mov    QWORD PTR [r9+0x48],rcx
  40b461:	mov    rcx,QWORD PTR [rax+0x18]
  40b465:	test   rcx,rcx
  40b468:	je     40b46e <__swc_fn_fc36583a_000046_88f44774+0x8e>
  40b46a:	mov    QWORD PTR [rcx+0x50],r9
  40b46e:	mov    QWORD PTR [rax+0x18],r9
  40b472:	mov    eax,0x1
  40b477:	add    rsp,0x8
  40b47b:	ret
  40b47c:	add    BYTE PTR [rax],al
	...

000000000040b480 <__swc_fn_fc36583a_000049_2ff013cc>:
  40b480:	push   r12
  40b482:	push   r13
  40b484:	push   rdi
  40b485:	push   rsi
  40b486:	push   r14
  40b488:	push   r15
  40b48a:	sub    rsp,0x178
  40b491:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40b49a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40b4a3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40b4ac:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40b4b5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40b4be:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40b4c7:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40b4d0:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40b4d9:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40b4e2:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40b4eb:	mov    r12,rcx
  40b4ee:	lea    rax,[rip+0x18d0b]        # 424200 <__swc_bss_base_fc36583a+0x1c0>
  40b4f5:	mov    rcx,QWORD PTR [rax]
  40b4f8:	mov    r13,rcx
  40b4fb:	test   rcx,rcx
  40b4fe:	jne    40b50e <__swc_fn_fc36583a_000049_2ff013cc+0x8e>
  40b500:	mov    r13d,0x1dcd6500
  40b506:	mov    ecx,0x1dcd6500
  40b50b:	xchg   QWORD PTR [rax],rcx
  40b50e:	lea    rax,[rip+0x16aeb]        # 422000 <__swc_data_base_fc36583a>
  40b515:	mov    rax,QWORD PTR [rax]
  40b518:	cmp    rax,0xffffffffffffffff
  40b51c:	je     40b52b <__swc_fn_fc36583a_000049_2ff013cc+0xab>
  40b51e:	mov    eax,eax
  40b520:	mov    edi,eax
  40b522:	xor    eax,eax
  40b524:	call   407000 <pthread_getspecific@plt>
  40b529:	jmp    40b52d <__swc_fn_fc36583a_000049_2ff013cc+0xad>
  40b52b:	xor    eax,eax
  40b52d:	test   rax,rax
  40b530:	jne    40b53f <__swc_fn_fc36583a_000049_2ff013cc+0xbf>
  40b532:	call   40b1e0 <__swc_fn_fc36583a_000031_90860ff2>
  40b537:	mov    rcx,rax
  40b53a:	call   410500 <__swc_fn_fc36583a_000128_41c3251c>
  40b53f:	test   rax,rax
  40b542:	je     40b554 <__swc_fn_fc36583a_000049_2ff013cc+0xd4>
  40b544:	cmp    QWORD PTR [rax],r12
  40b547:	jne    40b554 <__swc_fn_fc36583a_000049_2ff013cc+0xd4>
  40b549:	cmp    DWORD PTR [rax+0x20],0x0
  40b54d:	jne    40b554 <__swc_fn_fc36583a_000049_2ff013cc+0xd4>
  40b54f:	mov    rsi,rax
  40b552:	jmp    40b556 <__swc_fn_fc36583a_000049_2ff013cc+0xd6>
  40b554:	xor    esi,esi
  40b556:	lea    rdi,[r12+0x2a88]
  40b55e:	mov    r14,QWORD PTR [rdi]
  40b561:	test   r14,r14
  40b564:	jne    40b5b3 <__swc_fn_fc36583a_000049_2ff013cc+0x133>
  40b566:	lea    rax,[rip+0x18aeb]        # 424058 <__swc_bss_base_fc36583a+0x18>
  40b56d:	mov    rax,QWORD PTR [rax]
  40b570:	test   rax,rax
  40b573:	setne  al
  40b576:	jne    40b59a <__swc_fn_fc36583a_000049_2ff013cc+0x11a>
  40b578:	mov    rax,QWORD PTR [r12+0x2a70]
  40b580:	test   rax,rax
  40b583:	setne  al
  40b586:	jne    40b59a <__swc_fn_fc36583a_000049_2ff013cc+0x11a>
  40b588:	test   rsi,rsi
  40b58b:	setne  al
  40b58e:	je     40b59a <__swc_fn_fc36583a_000049_2ff013cc+0x11a>
  40b590:	cmp    DWORD PTR [rsi+0x730],0x0
  40b597:	setne  al
  40b59a:	test   al,al
  40b59c:	je     40b5ae <__swc_fn_fc36583a_000049_2ff013cc+0x12e>
  40b59e:	call   4105b0 <__swc_fn_fc36583a_000131_944f555b>
  40b5a3:	lea    rcx,[rax+r13*1]
  40b5a7:	xor    eax,eax
  40b5a9:	lock cmpxchg QWORD PTR [rdi],rcx
  40b5ae:	jmp    40b6b3 <__swc_fn_fc36583a_000049_2ff013cc+0x233>
  40b5b3:	call   4105b0 <__swc_fn_fc36583a_000131_944f555b>
  40b5b8:	mov    r15,rax
  40b5bb:	cmp    rax,r14
  40b5be:	jb     40b5cf <__swc_fn_fc36583a_000049_2ff013cc+0x14f>
  40b5c0:	xor    ecx,ecx
  40b5c2:	mov    rax,r14
  40b5c5:	lock cmpxchg QWORD PTR [rdi],rcx
  40b5ca:	cmp    rax,r14
  40b5cd:	je     40b5d4 <__swc_fn_fc36583a_000049_2ff013cc+0x154>
  40b5cf:	jmp    40b6b3 <__swc_fn_fc36583a_000049_2ff013cc+0x233>
  40b5d4:	test   rsi,rsi
  40b5d7:	je     40b5f2 <__swc_fn_fc36583a_000049_2ff013cc+0x172>
  40b5d9:	cmp    r15,r13
  40b5dc:	jb     40b5f2 <__swc_fn_fc36583a_000049_2ff013cc+0x172>
  40b5de:	mov    rax,r15
  40b5e1:	sub    rax,r13
  40b5e4:	mov    rcx,r12
  40b5e7:	mov    rdx,rsi
  40b5ea:	mov    r8,rax
  40b5ed:	call   40e8d0 <__swc_fn_fc36583a_000059_3ca3ac64>
  40b5f2:	lea    rsi,[r12+0x10]
  40b5f7:	mov    rcx,rsi
  40b5fa:	call   4098c0 <__swc_fn_fc36583a_000135_e3032dc2>
  40b5ff:	mov    rax,QWORD PTR [r12+0x18]
  40b604:	mov    rdi,rax
  40b607:	test   rdi,rdi
  40b60a:	je     40b634 <__swc_fn_fc36583a_000049_2ff013cc+0x1b4>
  40b60c:	cs nop WORD PTR [rax+rax*1+0x0]
  40b616:	cs nop WORD PTR [rax+rax*1+0x0]
  40b620:	mov    rcx,rdi
  40b623:	call   407470 <__swc_fn_fc36583a_000015_07eb9884>
  40b628:	mov    rax,QWORD PTR [rdi+0x10]
  40b62c:	mov    rdi,rax
  40b62f:	test   rax,rax
  40b632:	jne    40b620 <__swc_fn_fc36583a_000049_2ff013cc+0x1a0>
  40b634:	mov    rcx,rsi
  40b637:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  40b63c:	mov    rcx,r12
  40b63f:	call   4098c0 <__swc_fn_fc36583a_000135_e3032dc2>
  40b644:	xor    esi,esi
  40b646:	cs nop WORD PTR [rax+rax*1+0x0]
  40b650:	mov    rax,QWORD PTR [r12+0x2a70]
  40b658:	cmp    rsi,rax
  40b65b:	jae    40b6ab <__swc_fn_fc36583a_000049_2ff013cc+0x22b>
  40b65d:	lea    rax,[rsi+rsi*4]
  40b661:	lea    rax,[r12+rax*8+0x268]
  40b669:	mov    r8,QWORD PTR [rax]
  40b66c:	mov    r9,QWORD PTR [rax+0x8]
  40b670:	mov    r10,QWORD PTR [rax+0x10]
  40b674:	mov    rax,QWORD PTR [rax+0x20]
  40b678:	cmp    rax,r15
  40b67b:	jae    40b688 <__swc_fn_fc36583a_000049_2ff013cc+0x208>
  40b67d:	mov    rcx,r15
  40b680:	sub    rcx,rax
  40b683:	cmp    rcx,r13
  40b686:	jae    40b68d <__swc_fn_fc36583a_000049_2ff013cc+0x20d>
  40b688:	inc    rsi
  40b68b:	jmp    40b650 <__swc_fn_fc36583a_000049_2ff013cc+0x1d0>
  40b68d:	mov    rcx,r12
  40b690:	mov    rdx,rsi
  40b693:	call   40e880 <__swc_fn_fc36583a_000056_38b21f11>
  40b698:	mov    rcx,r12
  40b69b:	mov    rdx,r8
  40b69e:	mov    r8,r9
  40b6a1:	mov    r9,r10
  40b6a4:	call   407750 <__swc_fn_fc36583a_000039_40d1e569>
  40b6a9:	jmp    40b650 <__swc_fn_fc36583a_000049_2ff013cc+0x1d0>
  40b6ab:	mov    rcx,r12
  40b6ae:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  40b6b3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40b6bc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40b6c5:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40b6ce:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40b6d7:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40b6e0:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40b6e9:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40b6f2:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40b6fb:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40b704:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40b70d:	add    rsp,0x178
  40b714:	pop    r15
  40b716:	pop    r14
  40b718:	pop    rsi
  40b719:	pop    rdi
  40b71a:	pop    r13
  40b71c:	pop    r12
  40b71e:	ret
	...

000000000040b720 <__swc_fn_fc36583a_000052_c7484fb0>:
  40b720:	lea    rax,[rdx-0x58]
  40b724:	ret
	...

000000000040b730 <__swc_fn_fc36583a_000055_81f7713d>:
  40b730:	push   rsi
  40b731:	push   rdi
  40b732:	push   r12
  40b734:	push   r13
  40b736:	sub    rsp,0x68
  40b73a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40b740:	mov    rsi,r9
  40b743:	mov    rdi,rcx
  40b746:	mov    r12,rdx
  40b749:	mov    r13,r8
  40b74c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40b754:	jne    40b763 <__swc_fn_fc36583a_000055_81f7713d+0x33>
  40b756:	xor    eax,eax
  40b758:	add    rsp,0x68
  40b75c:	pop    r13
  40b75e:	pop    r12
  40b760:	pop    rdi
  40b761:	pop    rsi
  40b762:	ret
  40b763:	mov    rcx,rdi
  40b766:	call   4098c0 <__swc_fn_fc36583a_000135_e3032dc2>
  40b76b:	movabs rax,0x7fffffffffffffff
  40b775:	cmp    r12,rax
  40b778:	mov    rax,0xffffffffffffffff
  40b77f:	lea    rcx,[r12+r12*1]
  40b783:	cmovbe rax,rcx
  40b787:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40b78e:	mov    rdx,rcx
  40b791:	sub    rax,r12
  40b794:	inc    rax
  40b797:	xor    r8d,r8d
  40b79a:	test   rcx,rcx
  40b79d:	jbe    40b7c8 <__swc_fn_fc36583a_000055_81f7713d+0x98>
  40b79f:	nop
  40b7a0:	lea    r9,[r8+r8*4]
  40b7a4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40b7ac:	sub    r9,r12
  40b7af:	cmp    r9,rax
  40b7b2:	jae    40b7bf <__swc_fn_fc36583a_000055_81f7713d+0x8f>
  40b7b4:	mov    rdx,r8
  40b7b7:	mov    rax,r9
  40b7ba:	test   r9,r9
  40b7bd:	je     40b7c8 <__swc_fn_fc36583a_000055_81f7713d+0x98>
  40b7bf:	add    r8,0x1
  40b7c3:	cmp    r8,rcx
  40b7c6:	jb     40b7a0 <__swc_fn_fc36583a_000055_81f7713d+0x70>
  40b7c8:	mov    rax,QWORD PTR [rdi+0x2a70]
  40b7cf:	cmp    rdx,rax
  40b7d2:	jne    40b7ef <__swc_fn_fc36583a_000055_81f7713d+0xbf>
  40b7d4:	mov    rcx,rdi
  40b7d7:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  40b7dc:	xor    eax,eax
  40b7de:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b7e4:	add    rsp,0x68
  40b7e8:	pop    r13
  40b7ea:	pop    r12
  40b7ec:	pop    rdi
  40b7ed:	pop    rsi
  40b7ee:	ret
  40b7ef:	lea    rax,[rdx+rdx*4]
  40b7f3:	lea    rax,[rdi+rax*8+0x268]
  40b7fb:	vmovups xmm6,XMMWORD PTR [rax]
  40b7ff:	mov    r8,QWORD PTR [rax+0x10]
  40b803:	mov    rcx,rdi
  40b806:	call   40e880 <__swc_fn_fc36583a_000056_38b21f11>
  40b80b:	vpshufd xmm0,xmm6,0xee
  40b810:	vmovsd QWORD PTR [r13+0x0],xmm0
  40b816:	mov    QWORD PTR [rsi],r8
  40b819:	mov    rcx,rdi
  40b81c:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  40b821:	vmovq  rax,xmm6
  40b826:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b82c:	add    rsp,0x68
  40b830:	pop    r13
  40b832:	pop    r12
  40b834:	pop    rdi
  40b835:	pop    rsi
  40b836:	ret
	...

000000000040b840 <__swc_fn_fc36583a_000058_8bd8d1d5>:
  40b840:	push   r12
  40b842:	push   r13
  40b844:	push   r14
  40b846:	push   r15
  40b848:	push   rdi
  40b849:	push   rsi
  40b84a:	sub    rsp,0x148
  40b851:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40b85a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40b863:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40b86c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40b875:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40b87e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40b887:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40b890:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40b899:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40b8a2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40b8ab:	mov    r12,r9
  40b8ae:	mov    r13,rcx
  40b8b1:	mov    r14,rdx
  40b8b4:	mov    r15,r8
  40b8b7:	test   rdx,rdx
  40b8ba:	jne    40b8ce <__swc_fn_fc36583a_000058_8bd8d1d5+0x8e>
  40b8bc:	add    rsp,0x148
  40b8c3:	pop    rsi
  40b8c4:	pop    rdi
  40b8c5:	pop    r15
  40b8c7:	pop    r14
  40b8c9:	pop    r13
  40b8cb:	pop    r12
  40b8cd:	ret
  40b8ce:	cmp    r12,0x200000
  40b8d5:	ja     40b967 <__swc_fn_fc36583a_000058_8bd8d1d5+0x127>
  40b8db:	lea    rax,[rip+0x1671e]        # 422000 <__swc_data_base_fc36583a>
  40b8e2:	mov    rax,QWORD PTR [rax]
  40b8e5:	cmp    rax,0xffffffffffffffff
  40b8e9:	je     40b8f8 <__swc_fn_fc36583a_000058_8bd8d1d5+0xb8>
  40b8eb:	mov    eax,eax
  40b8ed:	mov    edi,eax
  40b8ef:	xor    eax,eax
  40b8f1:	call   407000 <pthread_getspecific@plt>
  40b8f6:	jmp    40b8fa <__swc_fn_fc36583a_000058_8bd8d1d5+0xba>
  40b8f8:	xor    eax,eax
  40b8fa:	test   rax,rax
  40b8fd:	je     40b904 <__swc_fn_fc36583a_000058_8bd8d1d5+0xc4>
  40b8ff:	mov    rsi,rax
  40b902:	jmp    40b914 <__swc_fn_fc36583a_000058_8bd8d1d5+0xd4>
  40b904:	call   40b1e0 <__swc_fn_fc36583a_000031_90860ff2>
  40b909:	mov    rcx,rax
  40b90c:	call   410500 <__swc_fn_fc36583a_000128_41c3251c>
  40b911:	mov    rsi,rax
  40b914:	test   rsi,rsi
  40b917:	je     40b967 <__swc_fn_fc36583a_000058_8bd8d1d5+0x127>
  40b919:	cmp    QWORD PTR [rsi],r13
  40b91c:	jne    40b967 <__swc_fn_fc36583a_000058_8bd8d1d5+0x127>
  40b91e:	cmp    DWORD PTR [rsi+0x20],0x0
  40b922:	jne    40b967 <__swc_fn_fc36583a_000058_8bd8d1d5+0x127>
  40b924:	cmp    DWORD PTR [rsi+0x730],0x10
  40b92b:	jae    40b967 <__swc_fn_fc36583a_000058_8bd8d1d5+0x127>
  40b92d:	mov    eax,DWORD PTR [rsi+0x730]
  40b933:	lea    rdi,[rax+rax*4]
  40b937:	lea    rdi,[rsi+rdi*8+0x738]
  40b93f:	mov    QWORD PTR [rdi],r14
  40b942:	mov    QWORD PTR [rdi+0x8],r15
  40b946:	mov    QWORD PTR [rdi+0x10],r12
  40b94a:	mov    QWORD PTR [rdi+0x18],0x0
  40b952:	call   4105b0 <__swc_fn_fc36583a_000131_944f555b>
  40b957:	mov    QWORD PTR [rdi+0x20],rax
  40b95b:	add    DWORD PTR [rsi+0x730],0x1
  40b962:	jmp    40bac6 <__swc_fn_fc36583a_000058_8bd8d1d5+0x286>
  40b967:	mov    rcx,r13
  40b96a:	call   407e90 <__swc_fn_fc36583a_000057_5b81d8b6>
  40b96f:	mov    rsi,rax
  40b972:	cmp    r12,rax
  40b975:	jbe    40b9aa <__swc_fn_fc36583a_000058_8bd8d1d5+0x16a>
  40b977:	cmp    r12,0x10000000
  40b97e:	seta   al
  40b981:	ja     40b990 <__swc_fn_fc36583a_000058_8bd8d1d5+0x150>
  40b983:	mov    rax,QWORD PTR [r13+0x2a70]
  40b98a:	test   rax,rax
  40b98d:	setne  al
  40b990:	test   al,al
  40b992:	je     40b9aa <__swc_fn_fc36583a_000058_8bd8d1d5+0x16a>
  40b994:	mov    rcx,r13
  40b997:	mov    rdx,r14
  40b99a:	mov    r8,r15
  40b99d:	mov    r9,r12
  40b9a0:	call   407750 <__swc_fn_fc36583a_000039_40d1e569>
  40b9a5:	jmp    40bac6 <__swc_fn_fc36583a_000058_8bd8d1d5+0x286>
  40b9aa:	call   4105b0 <__swc_fn_fc36583a_000131_944f555b>
  40b9af:	mov    rdi,rax
  40b9b2:	mov    rcx,r13
  40b9b5:	call   4098c0 <__swc_fn_fc36583a_000135_e3032dc2>
  40b9ba:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b9c2:	je     40ba7a <__swc_fn_fc36583a_000058_8bd8d1d5+0x23a>
  40b9c8:	nop    DWORD PTR [rax+rax*1+0x0]
  40b9d0:	cmp    QWORD PTR [r13+0x2a70],0x100
  40b9db:	jae    40b9f0 <__swc_fn_fc36583a_000058_8bd8d1d5+0x1b0>
  40b9dd:	mov    rax,QWORD PTR [r13+0x2a68]
  40b9e4:	add    rax,r12
  40b9e7:	cmp    rax,rsi
  40b9ea:	jbe    40ba7a <__swc_fn_fc36583a_000058_8bd8d1d5+0x23a>
  40b9f0:	xor    eax,eax
  40b9f2:	mov    rcx,QWORD PTR [r13+0x2a70]
  40b9f9:	mov    edx,0x1
  40b9fe:	cmp    rcx,0x1
  40ba02:	jbe    40ba39 <__swc_fn_fc36583a_000058_8bd8d1d5+0x1f9>
  40ba04:	cs nop WORD PTR [rax+rax*1+0x0]
  40ba0e:	xchg   ax,ax
  40ba10:	lea    r8,[rdx+rdx*4]
  40ba14:	lea    r8,[r13+r8*8+0x268]
  40ba1c:	lea    r9,[rax+rax*4]
  40ba20:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40ba28:	cmp    QWORD PTR [r8+0x18],r9
  40ba2c:	cmovb  rax,rdx
  40ba30:	add    rdx,0x1
  40ba34:	cmp    rdx,rcx
  40ba37:	jb     40ba10 <__swc_fn_fc36583a_000058_8bd8d1d5+0x1d0>
  40ba39:	lea    rcx,[rax+rax*4]
  40ba3d:	lea    rcx,[r13+rcx*8+0x268]
  40ba45:	mov    r8,QWORD PTR [rcx]
  40ba48:	mov    r9,QWORD PTR [rcx+0x8]
  40ba4c:	mov    r10,QWORD PTR [rcx+0x10]
  40ba50:	mov    rcx,r13
  40ba53:	mov    rdx,rax
  40ba56:	call   40e880 <__swc_fn_fc36583a_000056_38b21f11>
  40ba5b:	mov    rcx,r13
  40ba5e:	mov    rdx,r8
  40ba61:	mov    r8,r9
  40ba64:	mov    r9,r10
  40ba67:	call   407750 <__swc_fn_fc36583a_000039_40d1e569>
  40ba6c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40ba74:	jne    40b9d0 <__swc_fn_fc36583a_000058_8bd8d1d5+0x190>
  40ba7a:	add    QWORD PTR [r13+0x2a78],0x1
  40ba82:	mov    rax,QWORD PTR [r13+0x2a70]
  40ba89:	lea    rax,[rax+rax*4]
  40ba8d:	lea    rax,[r13+rax*8+0x268]
  40ba95:	mov    QWORD PTR [rax],r14
  40ba98:	mov    QWORD PTR [rax+0x8],r15
  40ba9c:	mov    QWORD PTR [rax+0x10],r12
  40baa0:	mov    rcx,QWORD PTR [r13+0x2a78]
  40baa7:	mov    QWORD PTR [rax+0x18],rcx
  40baab:	mov    QWORD PTR [rax+0x20],rdi
  40baaf:	add    QWORD PTR [r13+0x2a68],r12
  40bab6:	add    QWORD PTR [r13+0x2a70],0x1
  40babe:	mov    rcx,r13
  40bac1:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  40bac6:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40bacf:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40bad8:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40bae1:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40baea:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40baf3:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40bafc:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40bb05:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40bb0e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40bb17:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40bb20:	add    rsp,0x148
  40bb27:	pop    rsi
  40bb28:	pop    rdi
  40bb29:	pop    r15
  40bb2b:	pop    r14
  40bb2d:	pop    r13
  40bb2f:	pop    r12
  40bb31:	ret
	...

000000000040bb40 <__swc_fn_fc36583a_000061_0a7f67d9>:
  40bb40:	push   rbx
  40bb41:	push   r12
  40bb43:	push   r13
  40bb45:	push   r14
  40bb47:	push   r15
  40bb49:	push   rdi
  40bb4a:	push   rsi
  40bb4b:	sub    rsp,0xf0
  40bb52:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40bb58:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40bb5e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40bb64:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40bb6a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40bb73:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40bb7c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40bb85:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40bb8e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40bb97:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40bba0:	mov    eax,r8d
  40bba3:	mov    rbx,rcx
  40bba6:	mov    r12,rdx
  40bba9:	mov    QWORD PTR [rsp+0x18],rdx
  40bbae:	mov    ecx,DWORD PTR [r12+0x58]
  40bbb3:	mov    r13d,ecx
  40bbb6:	cmp    ecx,0x10
  40bbb9:	mov    ecx,0x10
  40bbbe:	cmovb  r13d,ecx
  40bbc2:	test   r13d,r13d
  40bbc5:	mov    rcx,r13
  40bbc8:	mov    edx,0x8
  40bbcd:	cmove  ecx,edx
  40bbd0:	dec    rcx
  40bbd3:	mov    rdx,0xffffffffffffffff
  40bbda:	sub    rdx,rcx
  40bbdd:	xor    r14d,r14d
  40bbe0:	mov    r8,rcx
  40bbe3:	not    r8
  40bbe6:	lea    rcx,[rcx+0x58]
  40bbea:	and    rcx,r8
  40bbed:	cmp    rdx,0x58
  40bbf1:	cmovae r14,rcx
  40bbf5:	cmp    eax,0xffffffff
  40bbf8:	jne    40bc01 <__swc_fn_fc36583a_000061_0a7f67d9+0xc1>
  40bbfa:	mov    r15,QWORD PTR [r12+0x48]
  40bbff:	jmp    40bc33 <__swc_fn_fc36583a_000061_0a7f67d9+0xf3>
  40bc01:	test   eax,eax
  40bc03:	jne    40bc0c <__swc_fn_fc36583a_000061_0a7f67d9+0xcc>
  40bc05:	mov    eax,0x8
  40bc0a:	jmp    40bc30 <__swc_fn_fc36583a_000061_0a7f67d9+0xf0>
  40bc0c:	cmp    eax,0x8
  40bc0f:	ja     40bc17 <__swc_fn_fc36583a_000061_0a7f67d9+0xd7>
  40bc11:	shl    rax,0x4
  40bc15:	jmp    40bc30 <__swc_fn_fc36583a_000061_0a7f67d9+0xf0>
  40bc17:	lea    eax,[rax-0x9]
  40bc1a:	mov    ecx,eax
  40bc1c:	shr    ecx,0x2
  40bc1f:	and    eax,0x3
  40bc22:	lea    ecx,[rcx+0x7]
  40bc25:	lea    ecx,[rcx-0x2]
  40bc28:	lea    eax,[rax+0x5]
  40bc2b:	shlx   rax,rax,rcx
  40bc30:	mov    r15,rax
  40bc33:	lea    rax,[r14+r13*1]
  40bc37:	mov    rcx,0xffffffffffffffff
  40bc3e:	sub    rcx,rax
  40bc41:	cmp    r15,rcx
  40bc44:	jbe    40bc54 <__swc_fn_fc36583a_000061_0a7f67d9+0x114>
  40bc46:	mov    QWORD PTR [r12+0x40],0x0
  40bc4f:	jmp    40c026 <__swc_fn_fc36583a_000061_0a7f67d9+0x4e6>
  40bc54:	mov    QWORD PTR [rsp+0x20],r13
  40bc59:	lea    r13,[rsp+0x8]
  40bc5e:	add    rax,r15
  40bc61:	mov    ecx,0x1000
  40bc66:	test   ecx,ecx
  40bc68:	mov    edx,0x8
  40bc6d:	cmove  ecx,edx
  40bc70:	dec    rcx
  40bc73:	mov    rdx,0xffffffffffffffff
  40bc7a:	sub    rdx,rcx
  40bc7d:	cmp    rax,rdx
  40bc80:	jbe    40bc8c <__swc_fn_fc36583a_000061_0a7f67d9+0x14c>
  40bc82:	mov    QWORD PTR [r13+0x0],0x0
  40bc8a:	jmp    40bc99 <__swc_fn_fc36583a_000061_0a7f67d9+0x159>
  40bc8c:	add    rax,rcx
  40bc8f:	andn   rax,rcx,rax
  40bc94:	mov    QWORD PTR [rsp+0x8],rax
  40bc99:	cmp    QWORD PTR [r13+0x0],0x0
  40bc9e:	jne    40bcae <__swc_fn_fc36583a_000061_0a7f67d9+0x16e>
  40bca0:	mov    QWORD PTR [r12+0x40],0x0
  40bca9:	jmp    40c026 <__swc_fn_fc36583a_000061_0a7f67d9+0x4e6>
  40bcae:	mov    QWORD PTR [rsp+0x30],r15
  40bcb3:	xor    r15d,r15d
  40bcb6:	mov    QWORD PTR [rsp+0x38],0x0
  40bcbf:	lea    r12,[rsp+0x10]
  40bcc4:	mov    QWORD PTR [rsp+0x28],r14
  40bcc9:	mov    r14,QWORD PTR [rsp+0x8]
  40bcce:	mov    QWORD PTR [rsp+0x10],r14
  40bcd3:	cmp    r14,0x10000
  40bcda:	ja     40bce1 <__swc_fn_fc36583a_000061_0a7f67d9+0x1a1>
  40bcdc:	mov    rax,r14
  40bcdf:	jmp    40bd32 <__swc_fn_fc36583a_000061_0a7f67d9+0x1f2>
  40bce1:	xor    eax,eax
  40bce3:	lea    rcx,[r14-0x1]
  40bce7:	lzcnt  rax,rcx
  40bcec:	mov    ecx,0x3f
  40bcf1:	sub    rcx,rax
  40bcf4:	mov    eax,0x1
  40bcf9:	lea    rcx,[rcx-0x3]
  40bcfd:	shl    rax,cl
  40bd00:	mov    rcx,rax
  40bd03:	cmp    rax,0x1000
  40bd0a:	mov    eax,0x1000
  40bd0f:	cmovb  rcx,rax
  40bd13:	mov    rdx,0xffffffffffffffff
  40bd1a:	sub    rdx,rcx
  40bd1d:	mov    rax,r14
  40bd20:	lea    r8,[r14+rcx*1-0x1]
  40bd25:	neg    rcx
  40bd28:	and    r8,rcx
  40bd2b:	cmp    r14,rdx
  40bd2e:	cmovbe rax,r8
  40bd32:	mov    QWORD PTR [rsp+0x8],rax
  40bd37:	lea    rax,[rip+0x162c2]        # 422000 <__swc_data_base_fc36583a>
  40bd3e:	mov    rax,QWORD PTR [rax]
  40bd41:	cmp    rax,0xffffffffffffffff
  40bd45:	je     40bd54 <__swc_fn_fc36583a_000061_0a7f67d9+0x214>
  40bd47:	mov    eax,eax
  40bd49:	mov    edi,eax
  40bd4b:	xor    eax,eax
  40bd4d:	call   407000 <pthread_getspecific@plt>
  40bd52:	jmp    40bd56 <__swc_fn_fc36583a_000061_0a7f67d9+0x216>
  40bd54:	xor    eax,eax
  40bd56:	test   rax,rax
  40bd59:	jne    40bd68 <__swc_fn_fc36583a_000061_0a7f67d9+0x228>
  40bd5b:	call   40b1e0 <__swc_fn_fc36583a_000031_90860ff2>
  40bd60:	mov    rcx,rax
  40bd63:	call   410500 <__swc_fn_fc36583a_000128_41c3251c>
  40bd68:	test   rax,rax
  40bd6b:	je     40be5c <__swc_fn_fc36583a_000061_0a7f67d9+0x31c>
  40bd71:	cmp    QWORD PTR [rax],rbx
  40bd74:	jne    40be5c <__swc_fn_fc36583a_000061_0a7f67d9+0x31c>
  40bd7a:	cmp    DWORD PTR [rax+0x20],0x0
  40bd7e:	jne    40be5c <__swc_fn_fc36583a_000061_0a7f67d9+0x31c>
  40bd84:	mov    rcx,QWORD PTR [rsp+0x8]
  40bd89:	movabs rdx,0x7fffffffffffffff
  40bd93:	cmp    rcx,rdx
  40bd96:	mov    rdx,0xffffffffffffffff
  40bd9d:	lea    r8,[rcx+rcx*1]
  40bda1:	cmovbe rdx,r8
  40bda5:	mov    r8d,DWORD PTR [rax+0x730]
  40bdac:	mov    r9d,r8d
  40bdaf:	sub    rdx,rcx
  40bdb2:	inc    rdx
  40bdb5:	xor    r10d,r10d
  40bdb8:	test   r8,r8
  40bdbb:	jbe    40bdeb <__swc_fn_fc36583a_000061_0a7f67d9+0x2ab>
  40bdbd:	nop    DWORD PTR [rax]
  40bdc0:	mov    r11d,r10d
  40bdc3:	lea    r11,[r11+r11*4]
  40bdc7:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40bdcf:	sub    r11,rcx
  40bdd2:	cmp    r11,rdx
  40bdd5:	jae    40bde2 <__swc_fn_fc36583a_000061_0a7f67d9+0x2a2>
  40bdd7:	mov    r9d,r10d
  40bdda:	mov    rdx,r11
  40bddd:	test   r11,r11
  40bde0:	je     40bdeb <__swc_fn_fc36583a_000061_0a7f67d9+0x2ab>
  40bde2:	add    r10,0x1
  40bde6:	cmp    r10,r8
  40bde9:	jb     40bdc0 <__swc_fn_fc36583a_000061_0a7f67d9+0x280>
  40bdeb:	mov    ecx,DWORD PTR [rax+0x730]
  40bdf1:	cmp    r9d,ecx
  40bdf4:	jne    40bdfa <__swc_fn_fc36583a_000061_0a7f67d9+0x2ba>
  40bdf6:	xor    eax,eax
  40bdf8:	jmp    40be59 <__swc_fn_fc36583a_000061_0a7f67d9+0x319>
  40bdfa:	lea    rcx,[r9+r9*4]
  40bdfe:	lea    rcx,[rax+rcx*8+0x738]
  40be06:	vmovups xmm0,XMMWORD PTR [rcx]
  40be0a:	mov    rdx,QWORD PTR [rcx+0x10]
  40be0e:	sub    DWORD PTR [rax+0x730],0x1
  40be15:	mov    r8d,DWORD PTR [rax+0x730]
  40be1c:	lea    r8,[r8+r8*4]
  40be20:	lea    r8,[rax+r8*8+0x738]
  40be28:	vmovups xmm1,XMMWORD PTR [r8]
  40be2d:	vmovups XMMWORD PTR [rcx],xmm1
  40be31:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40be37:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40be3c:	mov    rax,QWORD PTR [r8+0x20]
  40be40:	mov    QWORD PTR [rcx+0x20],rax
  40be44:	vpshufd xmm1,xmm0,0xee
  40be49:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40be4f:	mov    QWORD PTR [rsp+0x10],rdx
  40be54:	vmovq  rax,xmm0
  40be59:	mov    r15,rax
  40be5c:	test   r15,r15
  40be5f:	jne    40be77 <__swc_fn_fc36583a_000061_0a7f67d9+0x337>
  40be61:	mov    rcx,rbx
  40be64:	mov    rdx,QWORD PTR [rsp+0x8]
  40be69:	mov    r8,r13
  40be6c:	mov    r9,r12
  40be6f:	call   40b730 <__swc_fn_fc36583a_000055_81f7713d>
  40be74:	mov    r15,rax
  40be77:	test   r15,r15
  40be7a:	je     40bebb <__swc_fn_fc36583a_000061_0a7f67d9+0x37b>
  40be7c:	cmp    QWORD PTR [r12],r14
  40be80:	jae    40bebb <__swc_fn_fc36583a_000061_0a7f67d9+0x37b>
  40be82:	mov    rax,r15
  40be85:	add    rax,QWORD PTR [r12]
  40be89:	mov    rdx,r14
  40be8c:	sub    rdx,QWORD PTR [r12]
  40be90:	mov    rcx,rax
  40be93:	call   4072a0 <__swc_fn_fc36583a_000003_7ab4792e>
  40be98:	test   al,al
  40be9a:	je     40bea3 <__swc_fn_fc36583a_000061_0a7f67d9+0x363>
  40be9c:	mov    QWORD PTR [rsp+0x10],r14
  40bea1:	jmp    40bebb <__swc_fn_fc36583a_000061_0a7f67d9+0x37b>
  40bea3:	mov    rcx,rbx
  40bea6:	mov    rdx,r15
  40bea9:	mov    r8,QWORD PTR [rsp+0x8]
  40beae:	mov    r9,QWORD PTR [rsp+0x10]
  40beb3:	call   40b840 <__swc_fn_fc36583a_000058_8bd8d1d5>
  40beb8:	xor    r15d,r15d
  40bebb:	test   r15,r15
  40bebe:	jne    40bf3a <__swc_fn_fc36583a_000061_0a7f67d9+0x3fa>
  40bec0:	cmp    r14,0x10000
  40bec7:	ja     40bece <__swc_fn_fc36583a_000061_0a7f67d9+0x38e>
  40bec9:	mov    rax,r14
  40becc:	jmp    40bf1f <__swc_fn_fc36583a_000061_0a7f67d9+0x3df>
  40bece:	xor    eax,eax
  40bed0:	lea    rcx,[r14-0x1]
  40bed4:	lzcnt  rax,rcx
  40bed9:	mov    ecx,0x3f
  40bede:	sub    rcx,rax
  40bee1:	mov    eax,0x1
  40bee6:	lea    rcx,[rcx-0x3]
  40beea:	shl    rax,cl
  40beed:	mov    rcx,rax
  40bef0:	cmp    rax,0x1000
  40bef7:	mov    eax,0x1000
  40befc:	cmovb  rcx,rax
  40bf00:	mov    rdx,0xffffffffffffffff
  40bf07:	sub    rdx,rcx
  40bf0a:	mov    rax,r14
  40bf0d:	lea    r8,[r14+rcx*1-0x1]
  40bf12:	neg    rcx
  40bf15:	and    r8,rcx
  40bf18:	cmp    r14,rdx
  40bf1b:	cmovbe rax,r8
  40bf1f:	mov    QWORD PTR [rsp+0x8],rax
  40bf24:	mov    QWORD PTR [rsp+0x10],r14
  40bf29:	mov    rcx,rbx
  40bf2c:	mov    rdx,rax
  40bf2f:	mov    r8,r14
  40bf32:	call   40b2a0 <__swc_fn_fc36583a_000037_b4982903>
  40bf37:	mov    r15,rax
  40bf3a:	test   r15,r15
  40bf3d:	jne    40bf4b <__swc_fn_fc36583a_000061_0a7f67d9+0x40b>
  40bf3f:	mov    r13,QWORD PTR [rsp+0x20]
  40bf44:	mov    rsi,QWORD PTR [rsp+0x38]
  40bf49:	jmp    40bf87 <__swc_fn_fc36583a_000061_0a7f67d9+0x447>
  40bf4b:	mov    rax,r15
  40bf4e:	add    rax,QWORD PTR [rsp+0x28]
  40bf53:	mov    r13,QWORD PTR [rsp+0x20]
  40bf58:	test   r13d,r13d
  40bf5b:	mov    rcx,r13
  40bf5e:	mov    edx,0x8
  40bf63:	cmove  ecx,edx
  40bf66:	dec    rcx
  40bf69:	mov    rdx,0xffffffffffffffff
  40bf70:	sub    rdx,rcx
  40bf73:	cmp    rax,rdx
  40bf76:	jbe    40bf7c <__swc_fn_fc36583a_000061_0a7f67d9+0x43c>
  40bf78:	xor    eax,eax
  40bf7a:	jmp    40bf84 <__swc_fn_fc36583a_000061_0a7f67d9+0x444>
  40bf7c:	add    rax,rcx
  40bf7f:	andn   rax,rcx,rax
  40bf84:	mov    rsi,rax
  40bf87:	mov    rax,QWORD PTR [rsp+0x8]
  40bf8c:	test   r15,r15
  40bf8f:	je     40bf98 <__swc_fn_fc36583a_000061_0a7f67d9+0x458>
  40bf91:	mov    rdi,QWORD PTR [rsp+0x18]
  40bf96:	jmp    40bfaa <__swc_fn_fc36583a_000061_0a7f67d9+0x46a>
  40bf98:	mov    rdi,QWORD PTR [rsp+0x18]
  40bf9d:	mov    QWORD PTR [rdi+0x40],0x0
  40bfa5:	jmp    40c026 <__swc_fn_fc36583a_000061_0a7f67d9+0x4e6>
  40bfaa:	lea    rdx,[rsi-0x58]
  40bfae:	mov    QWORD PTR [rsi-0x58],r15
  40bfb2:	mov    QWORD PTR [rsi-0x50],rax
  40bfb6:	mov    rax,QWORD PTR [rsp+0x10]
  40bfbb:	mov    QWORD PTR [rsi-0x48],rax
  40bfbf:	mov    QWORD PTR [rsi-0x40],rsi
  40bfc3:	mov    rax,QWORD PTR [rdi+0x48]
  40bfc7:	mov    QWORD PTR [rsi-0x38],rax
  40bfcb:	mov    rax,QWORD PTR [rsp+0x30]
  40bfd0:	mov    QWORD PTR [rsi-0x30],rax
  40bfd4:	mov    DWORD PTR [rsi-0x10],r13d
  40bfd8:	mov    QWORD PTR [rsi-0x28],0x0
  40bfe0:	mov    QWORD PTR [rsi-0x20],0x0
  40bfe8:	add    r15,QWORD PTR [r12]
  40bfec:	sub    r15,rsi
  40bfef:	mov    QWORD PTR [rsi-0x30],r15
  40bff3:	mov    rcx,QWORD PTR [rbx+0x250]
  40bffa:	nop    WORD PTR [rax+rax*1+0x0]
  40c000:	lea    r8,[rcx+r15*1]
  40c004:	mov    rax,rcx
  40c007:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40c010:	cmp    rax,rcx
  40c013:	je     40c01a <__swc_fn_fc36583a_000061_0a7f67d9+0x4da>
  40c015:	mov    rcx,rax
  40c018:	jmp    40c000 <__swc_fn_fc36583a_000061_0a7f67d9+0x4c0>
  40c01a:	mov    rcx,rbx
  40c01d:	call   40e7f0 <__swc_fn_fc36583a_000053_82546d94>
  40c022:	mov    QWORD PTR [rdi+0x40],rsi
  40c026:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40c02c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40c032:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40c038:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40c03e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40c047:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40c050:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40c059:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40c062:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40c06b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40c074:	add    rsp,0xf0
  40c07b:	pop    rsi
  40c07c:	pop    rdi
  40c07d:	pop    r15
  40c07f:	pop    r14
  40c081:	pop    r13
  40c083:	pop    r12
  40c085:	pop    rbx
  40c086:	ret
	...

000000000040c090 <__swc_fn_fc36583a_000064_b0d63361>:
  40c090:	push   rbx
  40c091:	push   r12
  40c093:	push   rdi
  40c094:	push   rsi
  40c095:	sub    rsp,0xb8
  40c09c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40c0a2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40c0a8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40c0ae:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40c0b4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40c0ba:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40c0c0:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40c0c6:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40c0cf:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40c0d8:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40c0e1:	mov    rbx,rdx
  40c0e4:	mov    r12,rcx
  40c0e7:	cmp    DWORD PTR [rbx+0x58],0x0
  40c0eb:	je     40c105 <__swc_fn_fc36583a_000064_b0d63361+0x75>
  40c0ed:	mov    eax,DWORD PTR [rbx+0x58]
  40c0f0:	sub    eax,0x1
  40c0f3:	test   DWORD PTR [rbx+0x58],eax
  40c0f6:	je     40c105 <__swc_fn_fc36583a_000064_b0d63361+0x75>
  40c0f8:	mov    QWORD PTR [rbx+0x40],0x0
  40c100:	jmp    40c317 <__swc_fn_fc36583a_000064_b0d63361+0x287>
  40c105:	cmp    QWORD PTR [rbx+0x48],0x0
  40c10a:	jne    40c119 <__swc_fn_fc36583a_000064_b0d63361+0x89>
  40c10c:	mov    QWORD PTR [rbx+0x40],0x0
  40c114:	jmp    40c317 <__swc_fn_fc36583a_000064_b0d63361+0x287>
  40c119:	lea    rax,[rsp+0x8]
  40c11e:	mov    rcx,QWORD PTR [rbx+0x48]
  40c122:	cmp    rcx,0x8
  40c126:	ja     40c130 <__swc_fn_fc36583a_000064_b0d63361+0xa0>
  40c128:	mov    DWORD PTR [rax],0x0
  40c12e:	jmp    40c18b <__swc_fn_fc36583a_000064_b0d63361+0xfb>
  40c130:	cmp    rcx,0x80
  40c137:	ja     40c147 <__swc_fn_fc36583a_000064_b0d63361+0xb7>
  40c139:	lea    rcx,[rcx+0xf]
  40c13d:	shr    rcx,0x4
  40c141:	mov    DWORD PTR [rsp+0x8],ecx
  40c145:	jmp    40c18b <__swc_fn_fc36583a_000064_b0d63361+0xfb>
  40c147:	cmp    rcx,0x10000
  40c14e:	jbe    40c158 <__swc_fn_fc36583a_000064_b0d63361+0xc8>
  40c150:	mov    DWORD PTR [rax],0xffffffff
  40c156:	jmp    40c18b <__swc_fn_fc36583a_000064_b0d63361+0xfb>
  40c158:	dec    rcx
  40c15b:	xor    edx,edx
  40c15d:	lzcnt  rdx,rcx
  40c162:	mov    r8d,0x3f
  40c168:	sub    r8d,edx
  40c16b:	lea    edx,[r8-0x2]
  40c16f:	shrx   rcx,rcx,rdx
  40c174:	and    ecx,0x3
  40c177:	lea    edx,[r8-0x7]
  40c17b:	lea    edx,[rdx*4+0x0]
  40c182:	lea    edx,[rdx+0x9]
  40c185:	add    edx,ecx
  40c187:	mov    DWORD PTR [rsp+0x8],edx
  40c18b:	cmp    DWORD PTR [rax],0x0
  40c18e:	jne    40c19e <__swc_fn_fc36583a_000064_b0d63361+0x10e>
  40c190:	cmp    DWORD PTR [rbx+0x58],0x8
  40c194:	jbe    40c19e <__swc_fn_fc36583a_000064_b0d63361+0x10e>
  40c196:	mov    DWORD PTR [rsp+0x8],0x1
  40c19e:	cmp    DWORD PTR [rbx+0x58],0x10
  40c1a2:	jbe    40c221 <__swc_fn_fc36583a_000064_b0d63361+0x191>
  40c1a8:	cmp    DWORD PTR [rbx+0x58],0x40
  40c1ac:	ja     40c221 <__swc_fn_fc36583a_000064_b0d63361+0x191>
  40c1ae:	cmp    DWORD PTR [rax],0xffffffff
  40c1b1:	je     40c221 <__swc_fn_fc36583a_000064_b0d63361+0x191>
  40c1b3:	mov    ecx,DWORD PTR [rsp+0x8]
  40c1b7:	mov    edx,DWORD PTR [rbx+0x58]
  40c1ba:	dec    rdx
  40c1bd:	cmp    ecx,0x2d
  40c1c0:	jae    40c218 <__swc_fn_fc36583a_000064_b0d63361+0x188>
  40c1c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40c1cc:	nop    DWORD PTR [rax+0x0]
  40c1d0:	mov    r8d,ecx
  40c1d3:	test   ecx,ecx
  40c1d5:	jne    40c1df <__swc_fn_fc36583a_000064_b0d63361+0x14f>
  40c1d7:	mov    r8d,0x8
  40c1dd:	jmp    40c20b <__swc_fn_fc36583a_000064_b0d63361+0x17b>
  40c1df:	cmp    r8d,0x8
  40c1e3:	ja     40c1eb <__swc_fn_fc36583a_000064_b0d63361+0x15b>
  40c1e5:	shl    r8,0x4
  40c1e9:	jmp    40c20b <__swc_fn_fc36583a_000064_b0d63361+0x17b>
  40c1eb:	lea    r8d,[r8-0x9]
  40c1ef:	mov    r9d,r8d
  40c1f2:	shr    r9d,0x2
  40c1f6:	and    r8d,0x3
  40c1fa:	lea    r9d,[r9+0x7]
  40c1fe:	lea    r9d,[r9-0x2]
  40c202:	lea    r8d,[r8+0x5]
  40c206:	shlx   r8,r8,r9
  40c20b:	test   r8,rdx
  40c20e:	je     40c21d <__swc_fn_fc36583a_000064_b0d63361+0x18d>
  40c210:	add    ecx,0x1
  40c213:	cmp    ecx,0x2d
  40c216:	jb     40c1d0 <__swc_fn_fc36583a_000064_b0d63361+0x140>
  40c218:	mov    ecx,0xffffffff
  40c21d:	mov    DWORD PTR [rsp+0x8],ecx
  40c221:	mov    ecx,DWORD PTR [rsp+0x8]
  40c225:	cmp    ecx,0xffffffff
  40c228:	je     40c230 <__swc_fn_fc36583a_000064_b0d63361+0x1a0>
  40c22a:	cmp    DWORD PTR [rbx+0x58],0x40
  40c22e:	jbe    40c243 <__swc_fn_fc36583a_000064_b0d63361+0x1b3>
  40c230:	mov    rcx,r12
  40c233:	mov    rdx,rbx
  40c236:	mov    r8d,DWORD PTR [rax]
  40c239:	call   40bb40 <__swc_fn_fc36583a_000061_0a7f67d9>
  40c23e:	jmp    40c317 <__swc_fn_fc36583a_000064_b0d63361+0x287>
  40c243:	lea    rax,[rip+0x15db6]        # 422000 <__swc_data_base_fc36583a>
  40c24a:	mov    rax,QWORD PTR [rax]
  40c24d:	cmp    rax,0xffffffffffffffff
  40c251:	je     40c260 <__swc_fn_fc36583a_000064_b0d63361+0x1d0>
  40c253:	mov    eax,eax
  40c255:	mov    edi,eax
  40c257:	xor    eax,eax
  40c259:	call   407000 <pthread_getspecific@plt>
  40c25e:	jmp    40c262 <__swc_fn_fc36583a_000064_b0d63361+0x1d2>
  40c260:	xor    eax,eax
  40c262:	test   rax,rax
  40c265:	jne    40c274 <__swc_fn_fc36583a_000064_b0d63361+0x1e4>
  40c267:	call   40b1e0 <__swc_fn_fc36583a_000031_90860ff2>
  40c26c:	mov    rcx,rax
  40c26f:	call   410500 <__swc_fn_fc36583a_000128_41c3251c>
  40c274:	test   rax,rax
  40c277:	je     40c284 <__swc_fn_fc36583a_000064_b0d63361+0x1f4>
  40c279:	cmp    QWORD PTR [rax],r12
  40c27c:	jne    40c284 <__swc_fn_fc36583a_000064_b0d63361+0x1f4>
  40c27e:	cmp    DWORD PTR [rax+0x20],0x0
  40c282:	je     40c28f <__swc_fn_fc36583a_000064_b0d63361+0x1ff>
  40c284:	mov    rcx,r12
  40c287:	mov    rdx,rax
  40c28a:	call   40e430 <__swc_fn_fc36583a_000041_414cc921>
  40c28f:	test   rax,rax
  40c292:	jne    40c29e <__swc_fn_fc36583a_000064_b0d63361+0x20e>
  40c294:	mov    QWORD PTR [rbx+0x40],0x0
  40c29c:	jmp    40c317 <__swc_fn_fc36583a_000064_b0d63361+0x287>
  40c29e:	lea    r8,[rsp+0xc]
  40c2a3:	mov    ecx,DWORD PTR [rsp+0x8]
  40c2a7:	mov    DWORD PTR [rsp+0xc],ecx
  40c2ab:	mov    ecx,DWORD PTR [r8]
  40c2ae:	lea    rcx,[rcx+rcx*4]
  40c2b2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40c2b7:	test   rcx,rcx
  40c2ba:	je     40c2f3 <__swc_fn_fc36583a_000064_b0d63361+0x263>
  40c2bc:	mov    rdx,QWORD PTR [rcx]
  40c2bf:	test   rdx,rdx
  40c2c2:	je     40c2d0 <__swc_fn_fc36583a_000064_b0d63361+0x240>
  40c2c4:	mov    r9,QWORD PTR [rdx]
  40c2c7:	mov    QWORD PTR [rcx],r9
  40c2ca:	add    DWORD PTR [rcx+0x28],0x1
  40c2ce:	jmp    40c2ee <__swc_fn_fc36583a_000064_b0d63361+0x25e>
  40c2d0:	mov    rdx,QWORD PTR [rcx+0x18]
  40c2d4:	cmp    QWORD PTR [rcx+0x20],rdx
  40c2d8:	jae    40c2ec <__swc_fn_fc36583a_000064_b0d63361+0x25c>
  40c2da:	mov    rdx,QWORD PTR [rcx+0x20]
  40c2de:	mov    r9d,DWORD PTR [rcx+0x2c]
  40c2e2:	add    QWORD PTR [rcx+0x20],r9
  40c2e6:	add    DWORD PTR [rcx+0x28],0x1
  40c2ea:	jmp    40c2ee <__swc_fn_fc36583a_000064_b0d63361+0x25e>
  40c2ec:	xor    edx,edx
  40c2ee:	test   rdx,rdx
  40c2f1:	jne    40c304 <__swc_fn_fc36583a_000064_b0d63361+0x274>
  40c2f3:	mov    rcx,r12
  40c2f6:	mov    rdx,rax
  40c2f9:	mov    r8d,DWORD PTR [r8]
  40c2fc:	call   40e5a0 <__swc_fn_fc36583a_000050_ab8077df>
  40c301:	mov    rdx,rax
  40c304:	test   rdx,rdx
  40c307:	jne    40c313 <__swc_fn_fc36583a_000064_b0d63361+0x283>
  40c309:	mov    QWORD PTR [rbx+0x40],0x0
  40c311:	jmp    40c317 <__swc_fn_fc36583a_000064_b0d63361+0x287>
  40c313:	mov    QWORD PTR [rbx+0x40],rdx
  40c317:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40c31d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40c323:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40c329:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40c32f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40c335:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40c33b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40c341:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40c34a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40c353:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40c35c:	add    rsp,0xb8
  40c363:	pop    rsi
  40c364:	pop    rdi
  40c365:	pop    r12
  40c367:	pop    rbx
  40c368:	ret
  40c369:	add    BYTE PTR [rax],al
  40c36b:	add    BYTE PTR [rax],al
  40c36d:	add    BYTE PTR [rax],al
	...

000000000040c370 <__swc_fn_fc36583a_000067_94a51053>:
  40c370:	ret
	...

000000000040c380 <__swc_fn_fc36583a_000070_3181d86c>:
  40c380:	push   r12
  40c382:	push   r13
  40c384:	push   r14
  40c386:	push   rdi
  40c387:	push   rsi
  40c388:	sub    rsp,0x1a0
  40c38f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40c398:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40c3a1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40c3aa:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40c3b3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40c3bc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40c3c5:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40c3ce:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40c3d7:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40c3e0:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40c3e9:	mov    r12,rdx
  40c3ec:	mov    r13,rcx
  40c3ef:	mov    rax,QWORD PTR [r12+0x48]
  40c3f4:	mov    ecx,DWORD PTR [r12+0x58]
  40c3f9:	lea    rdx,[rax-0x1]
  40c3fd:	cmp    rdx,0x10000
  40c404:	jae    40c4fe <__swc_fn_fc36583a_000070_3181d86c+0x17e>
  40c40a:	cmp    rax,0x8
  40c40e:	ja     40c415 <__swc_fn_fc36583a_000070_3181d86c+0x95>
  40c410:	xor    r14d,r14d
  40c413:	jmp    40c467 <__swc_fn_fc36583a_000070_3181d86c+0xe7>
  40c415:	cmp    rax,0x80
  40c41c:	ja     40c428 <__swc_fn_fc36583a_000070_3181d86c+0xa8>
  40c41e:	lea    r14,[rax+0xf]
  40c422:	shr    r14,0x4
  40c426:	jmp    40c467 <__swc_fn_fc36583a_000070_3181d86c+0xe7>
  40c428:	cmp    rax,0x10000
  40c42f:	jbe    40c439 <__swc_fn_fc36583a_000070_3181d86c+0xb9>
  40c431:	mov    r14d,0xffffffff
  40c437:	jmp    40c467 <__swc_fn_fc36583a_000070_3181d86c+0xe7>
  40c439:	xor    eax,eax
  40c43b:	lzcnt  rax,rdx
  40c440:	mov    r8d,0x3f
  40c446:	sub    r8d,eax
  40c449:	lea    eax,[r8-0x2]
  40c44d:	shrx   rax,rdx,rax
  40c452:	and    eax,0x3
  40c455:	lea    edx,[r8-0x7]
  40c459:	lea    edx,[rdx*4+0x0]
  40c460:	lea    edx,[rdx+0x9]
  40c463:	lea    r14d,[rdx+rax*1]
  40c467:	cmp    ecx,0x8
  40c46a:	jbe    40c483 <__swc_fn_fc36583a_000070_3181d86c+0x103>
  40c46c:	cmp    ecx,0x10
  40c46f:	jne    40c4fe <__swc_fn_fc36583a_000070_3181d86c+0x17e>
  40c475:	test   r14d,r14d
  40c478:	mov    eax,0x1
  40c47d:	cmove  r14d,eax
  40c481:	jmp    40c48a <__swc_fn_fc36583a_000070_3181d86c+0x10a>
  40c483:	lea    eax,[rcx-0x1]
  40c486:	test   eax,ecx
  40c488:	jne    40c4fe <__swc_fn_fc36583a_000070_3181d86c+0x17e>
  40c48a:	lea    rax,[rip+0x15b6f]        # 422000 <__swc_data_base_fc36583a>
  40c491:	mov    rax,QWORD PTR [rax]
  40c494:	cmp    rax,0xffffffffffffffff
  40c498:	je     40c4a7 <__swc_fn_fc36583a_000070_3181d86c+0x127>
  40c49a:	mov    eax,eax
  40c49c:	mov    edi,eax
  40c49e:	xor    eax,eax
  40c4a0:	call   407000 <pthread_getspecific@plt>
  40c4a5:	jmp    40c4a9 <__swc_fn_fc36583a_000070_3181d86c+0x129>
  40c4a7:	xor    eax,eax
  40c4a9:	test   rax,rax
  40c4ac:	je     40c4fe <__swc_fn_fc36583a_000070_3181d86c+0x17e>
  40c4ae:	cmp    QWORD PTR [rax],r13
  40c4b1:	jne    40c4fe <__swc_fn_fc36583a_000070_3181d86c+0x17e>
  40c4b3:	lea    rcx,[r14+r14*4]
  40c4b7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40c4bc:	test   rax,rax
  40c4bf:	je     40c4fe <__swc_fn_fc36583a_000070_3181d86c+0x17e>
  40c4c1:	mov    rcx,QWORD PTR [rax]
  40c4c4:	test   rcx,rcx
  40c4c7:	je     40c4d5 <__swc_fn_fc36583a_000070_3181d86c+0x155>
  40c4c9:	mov    rdx,QWORD PTR [rcx]
  40c4cc:	mov    QWORD PTR [rax],rdx
  40c4cf:	add    DWORD PTR [rax+0x28],0x1
  40c4d3:	jmp    40c4f2 <__swc_fn_fc36583a_000070_3181d86c+0x172>
  40c4d5:	mov    rcx,QWORD PTR [rax+0x18]
  40c4d9:	cmp    QWORD PTR [rax+0x20],rcx
  40c4dd:	jae    40c4f0 <__swc_fn_fc36583a_000070_3181d86c+0x170>
  40c4df:	mov    rcx,QWORD PTR [rax+0x20]
  40c4e3:	mov    edx,DWORD PTR [rax+0x2c]
  40c4e6:	add    QWORD PTR [rax+0x20],rdx
  40c4ea:	add    DWORD PTR [rax+0x28],0x1
  40c4ee:	jmp    40c4f2 <__swc_fn_fc36583a_000070_3181d86c+0x172>
  40c4f0:	xor    ecx,ecx
  40c4f2:	test   rcx,rcx
  40c4f5:	je     40c4fe <__swc_fn_fc36583a_000070_3181d86c+0x17e>
  40c4f7:	mov    QWORD PTR [r12+0x40],rcx
  40c4fc:	jmp    40c509 <__swc_fn_fc36583a_000070_3181d86c+0x189>
  40c4fe:	mov    rcx,r13
  40c501:	mov    rdx,r12
  40c504:	call   40f020 <__swc_fn_fc36583a_000071_0d1ef36f>
  40c509:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40c512:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40c51b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40c524:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40c52d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40c536:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40c53f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40c548:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40c551:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40c55a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40c563:	add    rsp,0x1a0
  40c56a:	pop    rsi
  40c56b:	pop    rdi
  40c56c:	pop    r14
  40c56e:	pop    r13
  40c570:	pop    r12
  40c572:	ret
	...

000000000040c580 <__swc_fn_fc36583a_000073_c6c71bf7>:
  40c580:	push   r12
  40c582:	push   r13
  40c584:	push   r14
  40c586:	push   r15
  40c588:	push   rdi
  40c589:	push   rsi
  40c58a:	sub    rsp,0x188
  40c591:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40c59a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40c5a3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40c5ac:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40c5b5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40c5be:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40c5c7:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40c5d0:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40c5d9:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40c5e2:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40c5eb:	mov    r12,rdx
  40c5ee:	mov    r13,rcx
  40c5f1:	mov    r14,QWORD PTR [r12+0x40]
  40c5f6:	lea    rax,[rip+0x17a73]        # 424070 <__swc_bss_base_fc36583a+0x30>
  40c5fd:	mov    rcx,r14
  40c600:	sub    rcx,QWORD PTR [rax+0x8]
  40c604:	mov    rax,QWORD PTR [rip+0x17a75]        # 424080 <__swc_bss_base_fc36583a+0x40>
  40c60b:	cmp    rcx,rax
  40c60e:	jae    40c63a <__swc_fn_fc36583a_000073_c6c71bf7+0xba>
  40c610:	mov    rax,r14
  40c613:	and    rax,0xffffffffffc00000
  40c61a:	mov    rcx,r14
  40c61d:	shr    rcx,0x10
  40c621:	and    ecx,0x3f
  40c624:	mov    edx,DWORD PTR [rax+0x28]
  40c627:	shrx   ecx,ecx,edx
  40c62c:	shl    rcx,0x4
  40c630:	lea    r15,[rax+rcx*8+0x80]
  40c638:	jmp    40c645 <__swc_fn_fc36583a_000073_c6c71bf7+0xc5>
  40c63a:	mov    rcx,r14
  40c63d:	call   40b110 <__swc_fn_fc36583a_000022_3a2e2048>
  40c642:	mov    r15,rax
  40c645:	test   r15,r15
  40c648:	je     40c6ef <__swc_fn_fc36583a_000073_c6c71bf7+0x16f>
  40c64e:	lea    rax,[rip+0x159ab]        # 422000 <__swc_data_base_fc36583a>
  40c655:	mov    rax,QWORD PTR [rax]
  40c658:	cmp    rax,0xffffffffffffffff
  40c65c:	je     40c66b <__swc_fn_fc36583a_000073_c6c71bf7+0xeb>
  40c65e:	mov    eax,eax
  40c660:	mov    edi,eax
  40c662:	xor    eax,eax
  40c664:	call   407000 <pthread_getspecific@plt>
  40c669:	jmp    40c66d <__swc_fn_fc36583a_000073_c6c71bf7+0xed>
  40c66b:	xor    eax,eax
  40c66d:	mov    rcx,QWORD PTR [r15+0x40]
  40c671:	cmp    rcx,rax
  40c674:	jne    40c6d4 <__swc_fn_fc36583a_000073_c6c71bf7+0x154>
  40c676:	test   rax,rax
  40c679:	je     40c6ef <__swc_fn_fc36583a_000073_c6c71bf7+0x16f>
  40c67b:	mov    ecx,DWORD PTR [r15+0x6c]
  40c67f:	test   ecx,ecx
  40c681:	je     40c6a1 <__swc_fn_fc36583a_000073_c6c71bf7+0x121>
  40c683:	mov    rcx,r13
  40c686:	mov    rdx,rax
  40c689:	mov    r8,r15
  40c68c:	mov    QWORD PTR [rsp+0xd8],rax
  40c694:	call   40e530 <__swc_fn_fc36583a_000047_bc5ec610>
  40c699:	mov    rax,QWORD PTR [rsp+0xd8]
  40c6a1:	mov    rcx,QWORD PTR [r15]
  40c6a4:	mov    QWORD PTR [r14],rcx
  40c6a7:	mov    QWORD PTR [r15],r14
  40c6aa:	sub    DWORD PTR [r15+0x28],0x1
  40c6af:	jne    40c6e4 <__swc_fn_fc36583a_000073_c6c71bf7+0x164>
  40c6b1:	movzx  ecx,BYTE PTR [r15+0x39]
  40c6b6:	lea    rcx,[rcx+rcx*4]
  40c6ba:	lea    rcx,[rax+rcx*8+0x28]
  40c6bf:	cmp    QWORD PTR [rcx],r15
  40c6c2:	je     40c6e4 <__swc_fn_fc36583a_000073_c6c71bf7+0x164>
  40c6c4:	mov    rcx,r13
  40c6c7:	mov    rdx,rax
  40c6ca:	mov    r8,r15
  40c6cd:	call   407d80 <__swc_fn_fc36583a_000051_f7021588>
  40c6d2:	jmp    40c6e4 <__swc_fn_fc36583a_000073_c6c71bf7+0x164>
  40c6d4:	test   rcx,rcx
  40c6d7:	je     40c6ef <__swc_fn_fc36583a_000073_c6c71bf7+0x16f>
  40c6d9:	mov    rcx,r15
  40c6dc:	mov    rdx,r14
  40c6df:	call   40ad50 <__swc_fn_fc36583a_000010_395bb04b>
  40c6e4:	mov    QWORD PTR [r12+0x40],0x0
  40c6ed:	jmp    40c6fa <__swc_fn_fc36583a_000073_c6c71bf7+0x17a>
  40c6ef:	mov    rcx,r13
  40c6f2:	mov    rdx,r12
  40c6f5:	call   40f040 <__swc_fn_fc36583a_000074_518516c2>
  40c6fa:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40c703:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40c70c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40c715:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40c71e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40c727:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40c730:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40c739:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40c742:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40c74b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40c754:	add    rsp,0x188
  40c75b:	pop    rsi
  40c75c:	pop    rdi
  40c75d:	pop    r15
  40c75f:	pop    r14
  40c761:	pop    r13
  40c763:	pop    r12
  40c765:	ret
	...

000000000040c770 <__swc_fn_fc36583a_000076_9f0c6acf>:
  40c770:	sub    rsp,0x8
  40c774:	mov    rax,rdx
  40c777:	mov    rdx,QWORD PTR [rax+0x40]
  40c77b:	mov    r8,rax
  40c77e:	call   40c370 <__swc_fn_fc36583a_000067_94a51053>
  40c783:	add    rsp,0x8
  40c787:	ret
	...

000000000040c790 <__swc_fn_fc36583a_000079_34776ded>:
  40c790:	push   rsi
  40c791:	push   rdi
  40c792:	sub    rsp,0x8
  40c796:	cmp    rcx,0xffffffffffffffef
  40c79a:	ja     40c7c0 <__swc_fn_fc36583a_000079_34776ded+0x30>
  40c79c:	xor    esi,esi
  40c79e:	lea    rax,[rcx+0x100f]
  40c7a5:	and    rax,0xfffffffffffff000
  40c7ac:	lea    rcx,[rcx+0x10]
  40c7b0:	cmp    rcx,0xfffffffffffff000
  40c7b7:	cmovbe rsi,rax
  40c7bb:	test   rsi,rsi
  40c7be:	jne    40c7c9 <__swc_fn_fc36583a_000079_34776ded+0x39>
  40c7c0:	xor    eax,eax
  40c7c2:	add    rsp,0x8
  40c7c6:	pop    rdi
  40c7c7:	pop    rsi
  40c7c8:	ret
  40c7c9:	mov    rcx,rsi
  40c7cc:	call   40ce20 <__swc_fn_fc36583a_000109_8d425bd3>
  40c7d1:	mov    rdi,rax
  40c7d4:	test   rax,rax
  40c7d7:	jne    40c7e2 <__swc_fn_fc36583a_000079_34776ded+0x52>
  40c7d9:	xor    eax,eax
  40c7db:	add    rsp,0x8
  40c7df:	pop    rdi
  40c7e0:	pop    rsi
  40c7e1:	ret
  40c7e2:	mov    rcx,rdi
  40c7e5:	mov    rdx,rsi
  40c7e8:	call   409260 <__swc_fn_fc36583a_000111_b25e3a45>
  40c7ed:	test   al,al
  40c7ef:	jne    40c805 <__swc_fn_fc36583a_000079_34776ded+0x75>
  40c7f1:	mov    rcx,rdi
  40c7f4:	mov    rdx,rsi
  40c7f7:	call   4101a0 <__swc_fn_fc36583a_000113_49b378a9>
  40c7fc:	xor    eax,eax
  40c7fe:	add    rsp,0x8
  40c802:	pop    rdi
  40c803:	pop    rsi
  40c804:	ret
  40c805:	mov    QWORD PTR [rdi],rsi
  40c808:	mov    QWORD PTR [rdi+0x8],0x0
  40c810:	lea    rax,[rdi+0x10]
  40c814:	add    rsp,0x8
  40c818:	pop    rdi
  40c819:	pop    rsi
  40c81a:	ret
  40c81b:	add    BYTE PTR [rax],al
  40c81d:	add    BYTE PTR [rax],al
	...

000000000040c820 <__swc_fn_fc36583a_000082_754dcd57>:
  40c820:	sub    rsp,0x8
  40c824:	cmp    BYTE PTR [rcx+0x2c],0x10
  40c828:	jne    40c833 <__swc_fn_fc36583a_000082_754dcd57+0x13>
  40c82a:	test   DWORD PTR [rcx+0x28],0x80
  40c831:	je     40c83b <__swc_fn_fc36583a_000082_754dcd57+0x1b>
  40c833:	mov    rax,rcx
  40c836:	add    rsp,0x8
  40c83a:	ret
  40c83b:	mov    rcx,QWORD PTR [rcx+0x40]
  40c83f:	call   40c820 <__swc_fn_fc36583a_000082_754dcd57>
  40c844:	add    rsp,0x8
  40c848:	ret
	...

000000000040c860 <__swc_fn_fc36583a_000085_1edf7c76>:
  40c860:	push   rsi
  40c861:	push   rdi
  40c862:	push   r12
  40c864:	push   r13
  40c866:	sub    rsp,0x8
  40c86a:	mov    rsi,rdx
  40c86d:	mov    rdi,rcx
  40c870:	xor    r8d,r8d
  40c873:	call   4085a0 <__swc_fn_fc36583a_000090_a2d50c23>
  40c878:	test   al,al
  40c87a:	je     40c88c <__swc_fn_fc36583a_000085_1edf7c76+0x2c>
  40c87c:	mov    eax,0x1
  40c881:	add    rsp,0x8
  40c885:	pop    r13
  40c887:	pop    r12
  40c889:	pop    rdi
  40c88a:	pop    rsi
  40c88b:	ret
  40c88c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40c891:	je     40c8a0 <__swc_fn_fc36583a_000085_1edf7c76+0x40>
  40c893:	xor    eax,eax
  40c895:	add    rsp,0x8
  40c899:	pop    r13
  40c89b:	pop    r12
  40c89d:	pop    rdi
  40c89e:	pop    rsi
  40c89f:	ret
  40c8a0:	mov    r12,QWORD PTR [rsi+0x98]
  40c8a7:	mov    rax,QWORD PTR [rsi+0xa0]
  40c8ae:	mov    rsi,rax
  40c8b1:	xor    r13d,r13d
  40c8b4:	test   rsi,rsi
  40c8b7:	je     40c914 <__swc_fn_fc36583a_000085_1edf7c76+0xb4>
  40c8b9:	cs nop WORD PTR [rax+rax*1+0x0]
  40c8c3:	cs nop WORD PTR [rax+rax*1+0x0]
  40c8cd:	nop    DWORD PTR [rax]
  40c8d0:	lea    rax,[r13*8+0x0]
  40c8d8:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40c8dd:	mov    rcx,rax
  40c8e0:	call   40c820 <__swc_fn_fc36583a_000082_754dcd57>
  40c8e5:	cmp    BYTE PTR [rax+0x2c],0xe
  40c8e9:	jne    40c90a <__swc_fn_fc36583a_000085_1edf7c76+0xaa>
  40c8eb:	mov    rcx,rdi
  40c8ee:	mov    rdx,rax
  40c8f1:	call   40c860 <__swc_fn_fc36583a_000085_1edf7c76>
  40c8f6:	test   al,al
  40c8f8:	je     40c90a <__swc_fn_fc36583a_000085_1edf7c76+0xaa>
  40c8fa:	mov    eax,0x1
  40c8ff:	add    rsp,0x8
  40c903:	pop    r13
  40c905:	pop    r12
  40c907:	pop    rdi
  40c908:	pop    rsi
  40c909:	ret
  40c90a:	add    r13,0x1
  40c90e:	sub    rsi,0x1
  40c912:	jne    40c8d0 <__swc_fn_fc36583a_000085_1edf7c76+0x70>
  40c914:	xor    eax,eax
  40c916:	add    rsp,0x8
  40c91a:	pop    r13
  40c91c:	pop    r12
  40c91e:	pop    rdi
  40c91f:	pop    rsi
  40c920:	ret
	...

000000000040c930 <__swc_fn_fc36583a_000088_fcb34f6a>:
  40c930:	sub    rsp,0x18
  40c934:	vxorps xmm0,xmm0,xmm0
  40c938:	vmovdqu XMMWORD PTR [rsp],xmm0
  40c93d:	call   40f250 <__swc_fn_fc36583a_000089_386582f3>
  40c942:	add    rsp,0x18
  40c946:	ret
	...

000000000040c950 <__swc_fn_fc36583a_000091_3d2f5a0d>:
  40c950:	sub    rsp,0x8
  40c954:	mov    rcx,QWORD PTR [rip+0x1a3e5]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40c95b:	test   rcx,rcx
  40c95e:	jne    40c970 <__swc_fn_fc36583a_000091_3d2f5a0d+0x20>
  40c960:	call   40a1d0 <__swc_fn_fc36583a_000165_cf398896>
  40c965:	lea    rcx,[rax+0x1]
  40c969:	mov    QWORD PTR [rip+0x1a3d0],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40c970:	dec    rcx
  40c973:	call   411fc0 <__swc_fn_fc36583a_000167_fce60b2b>
  40c978:	mov    rax,QWORD PTR [rax+0xc0]
  40c97f:	and    eax,0x1
  40c982:	setne  al
  40c985:	add    rsp,0x8
  40c989:	ret
	...

000000000040c9a0 <__swc_fn_fc36583a_000094_14db3cf9>:
  40c9a0:	push   rbx
  40c9a1:	push   rsi
  40c9a2:	push   rdi
  40c9a3:	push   r12
  40c9a5:	sub    rsp,0x28
  40c9a9:	mov    rbx,rcx
  40c9ac:	call   408900 <__swc_fn_fc36583a_000093_f8c16535>
  40c9b1:	mov    rcx,QWORD PTR [rip+0x1a388]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40c9b8:	test   rcx,rcx
  40c9bb:	jne    40c9cd <__swc_fn_fc36583a_000094_14db3cf9+0x2d>
  40c9bd:	call   40a1d0 <__swc_fn_fc36583a_000165_cf398896>
  40c9c2:	lea    rcx,[rax+0x1]
  40c9c6:	mov    QWORD PTR [rip+0x1a373],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40c9cd:	dec    rcx
  40c9d0:	call   411fc0 <__swc_fn_fc36583a_000167_fce60b2b>
  40c9d5:	mov    rsi,rax
  40c9d8:	lea    rcx,[rsp+0x8]
  40c9dd:	call   40f690 <__swc_fn_fc36583a_000092_8252f8c0>
  40c9e2:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40c9e9:	mov    r12,QWORD PTR [rsi+0xbe8]
  40c9f0:	lea    rcx,[rsi+0x10]
  40c9f4:	call   40d980 <__swc_fn_fc36583a_000157_232ffa22>
  40c9f9:	mov    rcx,rsi
  40c9fc:	call   40f800 <__swc_fn_fc36583a_000101_eab3874f>
  40ca01:	vxorps xmm0,xmm0,xmm0
  40ca05:	xor    eax,eax
  40ca07:	cs nop WORD PTR [rax+rax*1+0x0]
  40ca11:	cs nop WORD PTR [rax+rax*1+0x0]
  40ca1b:	nop    DWORD PTR [rax+rax*1+0x0]
  40ca20:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40ca25:	add    rax,0x10
  40ca29:	cmp    rax,0xbf0
  40ca30:	jne    40ca20 <__swc_fn_fc36583a_000094_14db3cf9+0x80>
  40ca32:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ca38:	vmovups XMMWORD PTR [rsi],xmm0
  40ca3c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ca42:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40ca4a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40ca51:	mov    QWORD PTR [rsi+0xbe8],r12
  40ca58:	mov    rcx,QWORD PTR [rip+0x1a2e1]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40ca5f:	test   rcx,rcx
  40ca62:	jne    40ca74 <__swc_fn_fc36583a_000094_14db3cf9+0xd4>
  40ca64:	call   40a1d0 <__swc_fn_fc36583a_000165_cf398896>
  40ca69:	lea    rcx,[rax+0x1]
  40ca6d:	mov    QWORD PTR [rip+0x1a2cc],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40ca74:	dec    rcx
  40ca77:	call   411fc0 <__swc_fn_fc36583a_000167_fce60b2b>
  40ca7c:	mov    rsi,rax
  40ca7f:	mov    QWORD PTR [rsi+0xc0],rbx
  40ca86:	and    ebx,0x1
  40ca89:	jne    40ca8d <__swc_fn_fc36583a_000094_14db3cf9+0xed>
  40ca8b:	xor    eax,eax
  40ca8d:	test   rbx,rbx
  40ca90:	sete   al
  40ca93:	xor    cl,cl
  40ca95:	xor    dl,dl
  40ca97:	xor    r8b,r8b
  40ca9a:	xor    r9b,r9b
  40ca9d:	xor    r10b,r10b
  40caa0:	mov    r11,rax
  40caa3:	call   40f050 <__swc_fn_fc36583a_000077_8b8614a7>
  40caa8:	lea    rbx,[rsp+0x18]
  40caad:	mov    rcx,rbx
  40cab0:	call   40f690 <__swc_fn_fc36583a_000092_8252f8c0>
  40cab5:	lea    rcx,[rsi+0x10]
  40cab9:	mov    edx,0x400000
  40cabe:	mov    r8,rbx
  40cac1:	call   409f10 <__swc_fn_fc36583a_000159_d8afac28>
  40cac6:	lea    rcx,[rsi+0x68]
  40caca:	mov    edx,0x4000
  40cacf:	mov    r8,rbx
  40cad2:	call   409f10 <__swc_fn_fc36583a_000159_d8afac28>
  40cad7:	add    rsp,0x28
  40cadb:	pop    r12
  40cadd:	pop    rdi
  40cade:	pop    rsi
  40cadf:	pop    rbx
  40cae0:	ret
	...

000000000040caf0 <__swc_fn_fc36583a_000097_4c97e0db>:
  40caf0:	push   rbx
  40caf1:	push   rsi
  40caf2:	sub    rsp,0x18
  40caf6:	mov    rbx,rcx
  40caf9:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40cafe:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40cb04:	mov    rsi,QWORD PTR [rbx+0x70]
  40cb08:	lea    rcx,[rcx+0x18]
  40cb0c:	call   40d980 <__swc_fn_fc36583a_000157_232ffa22>
  40cb11:	lea    rcx,[rsp+0x8]
  40cb16:	mov    rdx,rbx
  40cb19:	mov    r8d,0x78
  40cb1f:	call   408960 <__swc_fn_fc36583a_000096_ad982b35>
  40cb24:	mov    rax,rsi
  40cb27:	add    rsp,0x18
  40cb2b:	pop    rsi
  40cb2c:	pop    rbx
  40cb2d:	ret
	...

000000000040cb30 <__swc_fn_fc36583a_000100_3ed08774>:
  40cb30:	push   rsi
  40cb31:	push   rdi
  40cb32:	sub    rsp,0x8
  40cb36:	cmp    QWORD PTR [rcx],0x0
  40cb3a:	jne    40cb43 <__swc_fn_fc36583a_000100_3ed08774+0x13>
  40cb3c:	add    rsp,0x8
  40cb40:	pop    rdi
  40cb41:	pop    rsi
  40cb42:	ret
  40cb43:	mov    rsi,QWORD PTR [rcx]
  40cb46:	mov    rax,QWORD PTR [rcx+0x8]
  40cb4a:	test   rax,rax
  40cb4d:	je     40cb63 <__swc_fn_fc36583a_000100_3ed08774+0x33>
  40cb4f:	test   DWORD PTR [rax+0x28],0x400000
  40cb56:	je     40cb63 <__swc_fn_fc36583a_000100_3ed08774+0x33>
  40cb58:	mov    rcx,QWORD PTR [rax+0x30]
  40cb5c:	test   rcx,rcx
  40cb5f:	cmovne rax,rcx
  40cb63:	lea    rdx,[rip+0x6666]        # 4131d0 <__swc_rdata_base_fc36583a+0xc0>
  40cb6a:	lea    rcx,[rip+0x6747]        # 4132b8 <__swc_rdata_base_fc36583a+0x1a8>
  40cb71:	mov    r8,rax
  40cb74:	xor    r9d,r9d
  40cb77:	xor    al,al
  40cb79:	mov    r10,rax
  40cb7c:	xor    r11d,r11d
  40cb7f:	call   40c930 <__swc_fn_fc36583a_000088_fcb34f6a>
  40cb84:	test   rax,rax
  40cb87:	je     40cb97 <__swc_fn_fc36583a_000100_3ed08774+0x67>
  40cb89:	mov    rdi,QWORD PTR [rax+0x48]
  40cb8d:	test   rdi,rdi
  40cb90:	je     40cb97 <__swc_fn_fc36583a_000100_3ed08774+0x67>
  40cb92:	mov    rcx,rsi
  40cb95:	call   rdi
  40cb97:	add    rsp,0x8
  40cb9b:	pop    rdi
  40cb9c:	pop    rsi
  40cb9d:	ret
	...

000000000040cba0 <__swc_fn_fc36583a_000103_67100064>:
  40cba0:	push   rbx
  40cba1:	push   rsi
  40cba2:	push   rdi
  40cba3:	sub    rsp,0x20
  40cba7:	mov    rbx,rdx
  40cbaa:	mov    rsi,rcx
  40cbad:	mov    rcx,QWORD PTR [rip+0x1a18c]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40cbb4:	test   rcx,rcx
  40cbb7:	jne    40cbc9 <__swc_fn_fc36583a_000103_67100064+0x29>
  40cbb9:	call   40a1d0 <__swc_fn_fc36583a_000165_cf398896>
  40cbbe:	lea    rcx,[rax+0x1]
  40cbc2:	mov    QWORD PTR [rip+0x1a177],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40cbc9:	dec    rcx
  40cbcc:	call   411fc0 <__swc_fn_fc36583a_000167_fce60b2b>
  40cbd1:	mov    rdi,rax
  40cbd4:	mov    rax,QWORD PTR [rdi+0xbd0]
  40cbdb:	xor    ecx,ecx
  40cbdd:	test   rax,rax
  40cbe0:	je     40cbe5 <__swc_fn_fc36583a_000103_67100064+0x45>
  40cbe2:	mov    rcx,QWORD PTR [rax]
  40cbe5:	call   40a300 <__swc_fn_fc36583a_000174_176517f9>
  40cbea:	lea    rax,[rsp+0x8]
  40cbef:	lea    rcx,[rdi+0x9c8]
  40cbf6:	mov    QWORD PTR [rsp+0x8],rcx
  40cbfb:	mov    QWORD PTR [rax+0x8],0x40
  40cc03:	xor    ecx,ecx
  40cc05:	mov    rdx,rax
  40cc08:	call   4102e0 <__swc_fn_fc36583a_000119_9175a56a>
  40cc0d:	mov    DWORD PTR [rdi+0xbc8],eax
  40cc13:	mov    rdi,QWORD PTR [rdi+0x990]
  40cc1a:	test   rdi,rdi
  40cc1d:	je     40cc27 <__swc_fn_fc36583a_000103_67100064+0x87>
  40cc1f:	mov    rcx,rsi
  40cc22:	mov    rdx,rbx
  40cc25:	call   rdi
  40cc27:	call   40c950 <__swc_fn_fc36583a_000091_3d2f5a0d>
  40cc2c:	test   al,al
  40cc2e:	je     40cc3e <__swc_fn_fc36583a_000103_67100064+0x9e>
  40cc30:	mov    rcx,rsi
  40cc33:	mov    rdx,rbx
  40cc36:	xor    r8d,r8d
  40cc39:	call   409400 <__swc_fn_fc36583a_000120_ea68f292>
  40cc3e:	mov    rcx,rsi
  40cc41:	mov    rdx,rbx
  40cc44:	call   408a80 <__swc_fn_fc36583a_000102_e9fdc18e>
  40cc49:	call   40d1d0 <__swc_fn_fc36583a_000118_7f430081>
  40cc4e:	add    rsp,0x20
  40cc52:	pop    rdi
  40cc53:	pop    rsi
  40cc54:	pop    rbx
  40cc55:	ret
	...

000000000040cc60 <__swc_fn_fc36583a_000106_ed4b1681>:
  40cc60:	test   r8,r8
  40cc63:	jne    40cc68 <__swc_fn_fc36583a_000106_ed4b1681+0x8>
  40cc65:	xor    eax,eax
  40cc67:	ret
  40cc68:	xor    eax,eax
  40cc6a:	nop    WORD PTR [rax+rax*1+0x0]
  40cc70:	mov    r9,r8
  40cc73:	sub    r9,rax
  40cc76:	cmp    r9,0x10
  40cc7a:	jb     40ccc4 <__swc_fn_fc36583a_000106_ed4b1681+0x64>
  40cc7c:	lea    r9,[rcx+rax*1]
  40cc80:	lea    r10,[rdx+rax*1]
  40cc84:	vmovups xmm0,XMMWORD PTR [r10]
  40cc89:	vmovups xmm1,XMMWORD PTR [r9]
  40cc8e:	vpcmpeqb xmm0,xmm1,xmm0
  40cc92:	vpmovmskb r9d,xmm0
  40cc96:	cmp    r9d,0xffff
  40cc9d:	je     40ccbe <__swc_fn_fc36583a_000106_ed4b1681+0x5e>
  40cc9f:	not    r9d
  40cca2:	xor    r8d,r8d
  40cca5:	movzx  r9d,r9w
  40cca9:	tzcnt  r8d,r9d
  40ccae:	add    rax,r8
  40ccb1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40ccb5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40ccb9:	sub    ecx,eax
  40ccbb:	mov    eax,ecx
  40ccbd:	ret
  40ccbe:	lea    rax,[rax+0x10]
  40ccc2:	jmp    40cc70 <__swc_fn_fc36583a_000106_ed4b1681+0x10>
  40ccc4:	cmp    r9,0x8
  40ccc8:	jb     40cd3b <__swc_fn_fc36583a_000106_ed4b1681+0xdb>
  40ccca:	lea    r9,[rcx+rax*1]
  40ccce:	lea    r10,[rdx+rax*1]
  40ccd2:	mov    r9,QWORD PTR [r9]
  40ccd5:	xor    r9,QWORD PTR [r10]
  40ccd8:	test   r9,r9
  40ccdb:	je     40ccf9 <__swc_fn_fc36583a_000106_ed4b1681+0x99>
  40ccdd:	xor    r8d,r8d
  40cce0:	tzcnt  r8,r9
  40cce5:	shr    r8,0x3
  40cce9:	add    rax,r8
  40ccec:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40ccf0:	movzx  eax,BYTE PTR [rdx+rax*1]
  40ccf4:	sub    ecx,eax
  40ccf6:	mov    eax,ecx
  40ccf8:	ret
  40ccf9:	lea    rax,[rax+0x8]
  40ccfd:	cmp    rax,r8
  40cd00:	jne    40cd05 <__swc_fn_fc36583a_000106_ed4b1681+0xa5>
  40cd02:	xor    eax,eax
  40cd04:	ret
  40cd05:	lea    rax,[r8-0x8]
  40cd09:	lea    r8,[rcx+rax*1]
  40cd0d:	lea    r9,[rdx+rax*1]
  40cd11:	mov    r8,QWORD PTR [r8]
  40cd14:	xor    r8,QWORD PTR [r9]
  40cd17:	test   r8,r8
  40cd1a:	je     40cd38 <__swc_fn_fc36583a_000106_ed4b1681+0xd8>
  40cd1c:	xor    r9d,r9d
  40cd1f:	tzcnt  r9,r8
  40cd24:	shr    r9,0x3
  40cd28:	add    rax,r9
  40cd2b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cd2f:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cd33:	sub    ecx,eax
  40cd35:	mov    eax,ecx
  40cd37:	ret
  40cd38:	xor    eax,eax
  40cd3a:	ret
  40cd3b:	cmp    r9,0x4
  40cd3f:	jb     40cdb2 <__swc_fn_fc36583a_000106_ed4b1681+0x152>
  40cd41:	lea    r9,[rcx+rax*1]
  40cd45:	lea    r10,[rdx+rax*1]
  40cd49:	mov    r9d,DWORD PTR [r9]
  40cd4c:	xor    r9d,DWORD PTR [r10]
  40cd4f:	test   r9d,r9d
  40cd52:	je     40cd70 <__swc_fn_fc36583a_000106_ed4b1681+0x110>
  40cd54:	xor    r8d,r8d
  40cd57:	tzcnt  r8,r9
  40cd5c:	shr    r8,0x3
  40cd60:	add    rax,r8
  40cd63:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cd67:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cd6b:	sub    ecx,eax
  40cd6d:	mov    eax,ecx
  40cd6f:	ret
  40cd70:	lea    rax,[rax+0x4]
  40cd74:	cmp    rax,r8
  40cd77:	jne    40cd7c <__swc_fn_fc36583a_000106_ed4b1681+0x11c>
  40cd79:	xor    eax,eax
  40cd7b:	ret
  40cd7c:	lea    rax,[r8-0x4]
  40cd80:	lea    r8,[rcx+rax*1]
  40cd84:	lea    r9,[rdx+rax*1]
  40cd88:	mov    r8d,DWORD PTR [r8]
  40cd8b:	xor    r8d,DWORD PTR [r9]
  40cd8e:	test   r8d,r8d
  40cd91:	je     40cdaf <__swc_fn_fc36583a_000106_ed4b1681+0x14f>
  40cd93:	xor    r9d,r9d
  40cd96:	tzcnt  r9,r8
  40cd9b:	shr    r9,0x3
  40cd9f:	add    rax,r9
  40cda2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cda6:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cdaa:	sub    ecx,eax
  40cdac:	mov    eax,ecx
  40cdae:	ret
  40cdaf:	xor    eax,eax
  40cdb1:	ret
  40cdb2:	cmp    r9,0x2
  40cdb6:	jb     40ce09 <__swc_fn_fc36583a_000106_ed4b1681+0x1a9>
  40cdb8:	lea    r9,[rcx+rax*1]
  40cdbc:	lea    r10,[rdx+rax*1]
  40cdc0:	mov    r9w,WORD PTR [r9]
  40cdc4:	xor    r9w,WORD PTR [r10]
  40cdc8:	test   r9w,r9w
  40cdcc:	je     40cdee <__swc_fn_fc36583a_000106_ed4b1681+0x18e>
  40cdce:	xor    r8d,r8d
  40cdd1:	movzx  r9d,r9w
  40cdd5:	tzcnt  r8,r9
  40cdda:	shr    r8,0x3
  40cdde:	add    rax,r8
  40cde1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cde5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cde9:	sub    ecx,eax
  40cdeb:	mov    eax,ecx
  40cded:	ret
  40cdee:	lea    rax,[rax+0x2]
  40cdf2:	cmp    rax,r8
  40cdf5:	jne    40cdfa <__swc_fn_fc36583a_000106_ed4b1681+0x19a>
  40cdf7:	xor    eax,eax
  40cdf9:	ret
  40cdfa:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40ce00:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40ce06:	sub    eax,ecx
  40ce08:	ret
  40ce09:	test   r9,r9
  40ce0c:	je     40ce1b <__swc_fn_fc36583a_000106_ed4b1681+0x1bb>
  40ce0e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40ce12:	movzx  eax,BYTE PTR [rdx+rax*1]
  40ce16:	sub    ecx,eax
  40ce18:	mov    eax,ecx
  40ce1a:	ret
  40ce1b:	xor    eax,eax
  40ce1d:	ret
	...

000000000040ce20 <__swc_fn_fc36583a_000109_8d425bd3>:
  40ce20:	push   r12
  40ce22:	push   r13
  40ce24:	push   r14
  40ce26:	push   rdi
  40ce27:	push   rsi
  40ce28:	push   r15
  40ce2a:	sub    rsp,0xd8
  40ce31:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40ce37:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40ce3d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40ce43:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40ce49:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40ce4f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40ce58:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40ce61:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40ce6a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40ce73:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40ce7c:	mov    r12,rcx
  40ce7f:	test   rcx,rcx
  40ce82:	je     40ce9e <__swc_fn_fc36583a_000109_8d425bd3+0x7e>
  40ce84:	mov    eax,r12d
  40ce87:	and    eax,0xfff
  40ce8d:	setne  al
  40ce90:	cmp    r12,0xffffffffffffefff
  40ce97:	seta   cl
  40ce9a:	or     al,cl
  40ce9c:	je     40cea5 <__swc_fn_fc36583a_000109_8d425bd3+0x85>
  40ce9e:	xor    eax,eax
  40cea0:	jmp    40cf3b <__swc_fn_fc36583a_000109_8d425bd3+0x11b>
  40cea5:	call   409120 <__swc_fn_fc36583a_000108_84af7666>
  40ceaa:	mov    r13,rax
  40cead:	test   rax,rax
  40ceb0:	jne    40ceb9 <__swc_fn_fc36583a_000109_8d425bd3+0x99>
  40ceb2:	xor    eax,eax
  40ceb4:	jmp    40cf3b <__swc_fn_fc36583a_000109_8d425bd3+0x11b>
  40ceb9:	lea    r14,[r12+0x1000]
  40cec1:	xor    edi,edi
  40cec3:	mov    rsi,r14
  40cec6:	xor    edx,edx
  40cec8:	mov    ecx,0x22
  40cecd:	mov    eax,0xffffffff
  40ced2:	movsxd r8,eax
  40ced5:	xor    r9d,r9d
  40ced8:	xor    eax,eax
  40ceda:	call   4070c0 <mmap@plt>
  40cedf:	mov    r15,rax
  40cee2:	cmp    rax,0xffffffffffffffff
  40cee6:	jne    40ceec <__swc_fn_fc36583a_000109_8d425bd3+0xcc>
  40cee8:	xor    eax,eax
  40ceea:	jmp    40cf3b <__swc_fn_fc36583a_000109_8d425bd3+0x11b>
  40ceec:	mov    rdi,r15
  40ceef:	mov    esi,0x1000
  40cef4:	mov    edx,0x3
  40cef9:	xor    eax,eax
  40cefb:	call   407030 <mprotect@plt>
  40cf00:	test   eax,eax
  40cf02:	je     40cf15 <__swc_fn_fc36583a_000109_8d425bd3+0xf5>
  40cf04:	mov    rdi,r15
  40cf07:	mov    rsi,r14
  40cf0a:	xor    eax,eax
  40cf0c:	call   407020 <munmap@plt>
  40cf11:	xor    eax,eax
  40cf13:	jmp    40cf3b <__swc_fn_fc36583a_000109_8d425bd3+0x11b>
  40cf15:	mov    QWORD PTR [r15+0x8],r12
  40cf19:	mov    rcx,r13
  40cf1c:	call   40d570 <__swc_fn_fc36583a_000133_4b2af8da>
  40cf21:	mov    rax,QWORD PTR [r13+0x8]
  40cf25:	mov    QWORD PTR [r15],rax
  40cf28:	mov    QWORD PTR [r13+0x8],r15
  40cf2c:	mov    rcx,r13
  40cf2f:	call   410680 <__swc_fn_fc36583a_000134_29412410>
  40cf34:	lea    rax,[r15+0x1000]
  40cf3b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40cf41:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40cf47:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40cf4d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40cf53:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40cf59:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40cf62:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40cf6b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40cf74:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40cf7d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40cf86:	add    rsp,0xd8
  40cf8d:	pop    r15
  40cf8f:	pop    rsi
  40cf90:	pop    rdi
  40cf91:	pop    r14
  40cf93:	pop    r13
  40cf95:	pop    r12
  40cf97:	ret
	...

000000000040cfa0 <__swc_fn_fc36583a_000112_759e9ceb>:
  40cfa0:	push   rbx
  40cfa1:	push   r12
  40cfa3:	push   rdi
  40cfa4:	push   rsi
  40cfa5:	sub    rsp,0xa8
  40cfac:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cfb2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cfb8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cfbe:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cfc4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cfca:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cfd0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cfd6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cfdc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cfe5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cfee:	mov    rbx,rdx
  40cff1:	mov    r12,rcx
  40cff4:	mov    rdi,rcx
  40cff7:	mov    rsi,rdx
  40cffa:	xor    edx,edx
  40cffc:	xor    eax,eax
  40cffe:	call   407030 <mprotect@plt>
  40d003:	test   eax,eax
  40d005:	jne    40d029 <__swc_fn_fc36583a_000112_759e9ceb+0x89>
  40d007:	mov    rcx,r12
  40d00a:	mov    rdx,rbx
  40d00d:	xor    al,al
  40d00f:	mov    r8,rax
  40d012:	call   410110 <__swc_fn_fc36583a_000110_a808fe76>
  40d017:	mov    rdi,r12
  40d01a:	mov    rsi,rbx
  40d01d:	mov    edx,0x4
  40d022:	xor    eax,eax
  40d024:	call   4070e0 <madvise@plt>
  40d029:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d02f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d035:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d03b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d041:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d047:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d04d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d053:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d059:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d062:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d06b:	add    rsp,0xa8
  40d072:	pop    rsi
  40d073:	pop    rdi
  40d074:	pop    r12
  40d076:	pop    rbx
  40d077:	ret
	...

000000000040d080 <__swc_fn_fc36583a_000115_1ba33335>:
  40d080:	push   rsi
  40d081:	push   rdi
  40d082:	push   r12
  40d084:	push   r13
  40d086:	push   r14
  40d088:	sub    rsp,0xe0
  40d08f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40d095:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40d09b:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40d0a1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40d0a7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40d0ad:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40d0b6:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40d0bf:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40d0c8:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40d0d1:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40d0da:	mov    rsi,rdx
  40d0dd:	mov    rdi,rcx
  40d0e0:	call   409120 <__swc_fn_fc36583a_000108_84af7666>
  40d0e5:	mov    r12,rax
  40d0e8:	test   rax,rax
  40d0eb:	jne    40d0f2 <__swc_fn_fc36583a_000115_1ba33335+0x72>
  40d0ed:	jmp    40d166 <__swc_fn_fc36583a_000115_1ba33335+0xe6>
  40d0f2:	mov    rcx,r12
  40d0f5:	call   40d570 <__swc_fn_fc36583a_000133_4b2af8da>
  40d0fa:	lea    r13,[r12+0x8]
  40d0ff:	mov    rax,QWORD PTR [r13+0x0]
  40d103:	test   rax,rax
  40d106:	je     40d15e <__swc_fn_fc36583a_000115_1ba33335+0xde>
  40d108:	nop    DWORD PTR [rax+rax*1+0x0]
  40d110:	lea    rcx,[rax+0x1000]
  40d117:	cmp    rcx,rdi
  40d11a:	jne    40d152 <__swc_fn_fc36583a_000115_1ba33335+0xd2>
  40d11c:	cmp    QWORD PTR [rax+0x8],rsi
  40d120:	je     40d12c <__swc_fn_fc36583a_000115_1ba33335+0xac>
  40d122:	mov    rcx,r12
  40d125:	call   410680 <__swc_fn_fc36583a_000134_29412410>
  40d12a:	jmp    40d166 <__swc_fn_fc36583a_000115_1ba33335+0xe6>
  40d12c:	mov    r14,QWORD PTR [rax]
  40d12f:	mov    rdi,rax
  40d132:	lea    rsi,[rsi+0x1000]
  40d139:	xor    eax,eax
  40d13b:	call   407020 <munmap@plt>
  40d140:	test   eax,eax
  40d142:	jne    40d148 <__swc_fn_fc36583a_000115_1ba33335+0xc8>
  40d144:	mov    QWORD PTR [r13+0x0],r14
  40d148:	mov    rcx,r12
  40d14b:	call   410680 <__swc_fn_fc36583a_000134_29412410>
  40d150:	jmp    40d166 <__swc_fn_fc36583a_000115_1ba33335+0xe6>
  40d152:	mov    r13,rax
  40d155:	mov    rax,QWORD PTR [r13+0x0]
  40d159:	test   rax,rax
  40d15c:	jne    40d110 <__swc_fn_fc36583a_000115_1ba33335+0x90>
  40d15e:	mov    rcx,r12
  40d161:	call   410680 <__swc_fn_fc36583a_000134_29412410>
  40d166:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40d16c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40d172:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40d178:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40d17e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40d184:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40d18d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40d196:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40d19f:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40d1a8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40d1b1:	add    rsp,0xe0
  40d1b8:	pop    r14
  40d1ba:	pop    r13
  40d1bc:	pop    r12
  40d1be:	pop    rdi
  40d1bf:	pop    rsi
  40d1c0:	ret
	...

000000000040d1d0 <__swc_fn_fc36583a_000118_7f430081>:
  40d1d0:	push   rdi
  40d1d1:	push   rsi
  40d1d2:	sub    rsp,0xa8
  40d1d9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d1df:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d1e5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d1eb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d1f1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d1f7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d1fd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d203:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d209:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d212:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d21b:	mov    rdi,0xfffffffffffffd66
  40d222:	xor    eax,eax
  40d224:	call   407040 <exit@plt>
  40d229:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d22f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d235:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d23b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d241:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d247:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d24d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d253:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d259:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d262:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d26b:	add    rsp,0xa8
  40d272:	pop    rsi
  40d273:	pop    rdi
  40d274:	ret
	...

000000000040d280 <__swc_fn_fc36583a_000121_12b4ed22>:
  40d280:	push   rbx
  40d281:	push   rsi
  40d282:	push   rdi
  40d283:	sub    rsp,0x30
  40d287:	mov    rbx,rdx
  40d28a:	mov    esi,ecx
  40d28c:	test   ecx,ecx
  40d28e:	je     40d363 <__swc_fn_fc36583a_000121_12b4ed22+0xe3>
  40d294:	mov    rcx,rsi
  40d297:	shl    rcx,0x4
  40d29b:	call   40c790 <__swc_fn_fc36583a_000079_34776ded>
  40d2a0:	test   rax,rax
  40d2a3:	je     40d352 <__swc_fn_fc36583a_000121_12b4ed22+0xd2>
  40d2a9:	mov    rcx,rsi
  40d2ac:	xor    edx,edx
  40d2ae:	test   rsi,rsi
  40d2b1:	jbe    40d332 <__swc_fn_fc36583a_000121_12b4ed22+0xb2>
  40d2b7:	nop    WORD PTR [rax+rax*1+0x0]
  40d2c0:	mov    r8d,edx
  40d2c3:	mov    r9,QWORD PTR [rbx+r8*8]
  40d2c7:	add    r8,r8
  40d2ca:	lea    r8,[rax+r8*8]
  40d2ce:	xor    r10d,r10d
  40d2d1:	test   r9,r9
  40d2d4:	je     40d310 <__swc_fn_fc36583a_000121_12b4ed22+0x90>
  40d2d6:	mov    r11,r9
  40d2d9:	mov    dil,BYTE PTR [r11]
  40d2dc:	test   dil,dil
  40d2df:	je     40d310 <__swc_fn_fc36583a_000121_12b4ed22+0x90>
  40d2e1:	cs nop WORD PTR [rax+rax*1+0x0]
  40d2eb:	cs nop WORD PTR [rax+rax*1+0x0]
  40d2f5:	cs nop WORD PTR [rax+rax*1+0x0]
  40d2ff:	nop
  40d300:	add    r11,0x1
  40d304:	add    r10,0x1
  40d308:	mov    dil,BYTE PTR [r11]
  40d30b:	test   dil,dil
  40d30e:	jne    40d300 <__swc_fn_fc36583a_000121_12b4ed22+0x80>
  40d310:	mov    QWORD PTR [rsp+0x18],r9
  40d315:	mov    QWORD PTR [rsp+0x20],r10
  40d31a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40d320:	vmovups XMMWORD PTR [r8],xmm0
  40d325:	add    rdx,0x1
  40d329:	cmp    rdx,rcx
  40d32c:	jb     40d2c0 <__swc_fn_fc36583a_000121_12b4ed22+0x40>
  40d332:	lea    rcx,[rip+0x19a17]        # 426d50 <__swc_bss_base_fc36583a+0x2d10>
  40d339:	mov    QWORD PTR [rsp+0x8],rax
  40d33e:	mov    esi,esi
  40d340:	mov    QWORD PTR [rsp+0x10],rsi
  40d345:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40d34b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d350:	jmp    40d363 <__swc_fn_fc36583a_000121_12b4ed22+0xe3>
  40d352:	lea    rcx,[rip+0x61c7]        # 413520 <__swc_rdata_base_fc36583a+0x410>
  40d359:	call   4101c0 <__swc_fn_fc36583a_000116_035d76a1>
  40d35e:	call   40d1d0 <__swc_fn_fc36583a_000118_7f430081>
  40d363:	add    rsp,0x30
  40d367:	pop    rdi
  40d368:	pop    rsi
  40d369:	pop    rbx
  40d36a:	ret
  40d36b:	add    BYTE PTR [rax],al
  40d36d:	add    BYTE PTR [rax],al
	...

000000000040d370 <__swc_fn_fc36583a_000124_667fbf24>:
  40d370:	push   rdi
  40d371:	push   rsi
  40d372:	sub    rsp,0xa8
  40d379:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d37f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d385:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d38b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d391:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d397:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d39d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d3a3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d3a9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d3b2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d3bb:	mov    edi,ecx
  40d3bd:	xor    eax,eax
  40d3bf:	call   4070f0 <pthread_key_delete@plt>
  40d3c4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d3ca:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d3d0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d3d6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d3dc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d3e2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d3e8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d3ee:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d3f4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d3fd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d406:	add    rsp,0xa8
  40d40d:	pop    rsi
  40d40e:	pop    rdi
  40d40f:	ret

000000000040d410 <__swc_fn_fc36583a_000127_8dffa290>:
  40d410:	push   rdi
  40d411:	push   rsi
  40d412:	sub    rsp,0xa8
  40d419:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d41f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d425:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d42b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d431:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d437:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d43d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d443:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d449:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d452:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d45b:	test   rcx,rcx
  40d45e:	je     40d46f <__swc_fn_fc36583a_000127_8dffa290+0x5f>
  40d460:	lea    rax,[rcx-0x1]
  40d464:	mov    eax,eax
  40d466:	mov    edi,eax
  40d468:	xor    eax,eax
  40d46a:	call   4070f0 <pthread_key_delete@plt>
  40d46f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d475:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d47b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d481:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d487:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d48d:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d493:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d499:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d49f:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d4a8:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d4b1:	add    rsp,0xa8
  40d4b8:	pop    rsi
  40d4b9:	pop    rdi
  40d4ba:	ret
  40d4bb:	add    BYTE PTR [rax],al
  40d4bd:	add    BYTE PTR [rax],al
	...

000000000040d4c0 <__swc_fn_fc36583a_000130_c1196dfb>:
  40d4c0:	push   rsi
  40d4c1:	push   rdi
  40d4c2:	sub    rsp,0xa8
  40d4c9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d4cf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d4d5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d4db:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d4e1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d4e7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d4ed:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d4f3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d4f9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d502:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d50b:	xor    eax,eax
  40d50d:	call   407100 <gettid@plt>
  40d512:	movsxd rax,eax
  40d515:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d51b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d521:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d527:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d52d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d533:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d539:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d53f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d545:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d54e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d557:	add    rsp,0xa8
  40d55e:	pop    rdi
  40d55f:	pop    rsi
  40d560:	ret
	...

000000000040d570 <__swc_fn_fc36583a_000133_4b2af8da>:
  40d570:	push   rbx
  40d571:	push   rdi
  40d572:	push   rsi
  40d573:	sub    rsp,0xc0
  40d57a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40d580:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40d586:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40d58c:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40d592:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40d598:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40d59e:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40d5a4:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40d5ad:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40d5b6:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40d5bf:	mov    rbx,rcx
  40d5c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40d5cc:	nop    DWORD PTR [rax+0x0]
  40d5d0:	mov    edx,0x80000000
  40d5d5:	xor    eax,eax
  40d5d7:	lock cmpxchg DWORD PTR [rbx],edx
  40d5db:	test   eax,eax
  40d5dd:	je     40d614 <__swc_fn_fc36583a_000133_4b2af8da+0xa4>
  40d5df:	mov    eax,DWORD PTR [rbx]
  40d5e1:	lea    rcx,[rsp+0x14]
  40d5e6:	mov    DWORD PTR [rsp+0x14],eax
  40d5ea:	test   eax,eax
  40d5ec:	je     40d5d0 <__swc_fn_fc36583a_000133_4b2af8da+0x60>
  40d5ee:	mov    QWORD PTR [rsp],0x0
  40d5f6:	mov    edi,0xca
  40d5fb:	mov    rsi,rbx
  40d5fe:	mov    edx,0x80
  40d603:	mov    ecx,DWORD PTR [rcx]
  40d605:	xor    r8d,r8d
  40d608:	xor    r9d,r9d
  40d60b:	xor    eax,eax
  40d60d:	call   407070 <syscall@plt>
  40d612:	jmp    40d5d0 <__swc_fn_fc36583a_000133_4b2af8da+0x60>
  40d614:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40d61a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40d620:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40d626:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40d62c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40d632:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40d638:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40d63e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40d647:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40d650:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40d659:	add    rsp,0xc0
  40d660:	pop    rsi
  40d661:	pop    rdi
  40d662:	pop    rbx
  40d663:	ret
	...

000000000040d670 <__swc_fn_fc36583a_000136_3e875c27>:
  40d670:	sub    rsp,0x8
  40d674:	call   410680 <__swc_fn_fc36583a_000134_29412410>
  40d679:	add    rsp,0x8
  40d67d:	ret
	...

000000000040d680 <__swc_fn_fc36583a_000139_7c02fe26>:
  40d680:	push   rdi
  40d681:	push   rsi
  40d682:	sub    rsp,0xa8
  40d689:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d68f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d695:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d69b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d6a1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d6a7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d6ad:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d6b3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d6b9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d6c2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d6cb:	mov    edi,0x28
  40d6d0:	xor    eax,eax
  40d6d2:	call   4070d0 <malloc@plt>
  40d6d7:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d6dd:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d6e3:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d6e9:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d6ef:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d6f5:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d6fb:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d701:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d707:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d710:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d719:	add    rsp,0xa8
  40d720:	pop    rsi
  40d721:	pop    rdi
  40d722:	ret
	...

000000000040d730 <__swc_fn_fc36583a_000142_56e56812>:
  40d730:	mov    QWORD PTR [r8],0x0
  40d737:	cmp    rdx,0x10
  40d73b:	jae    40d740 <__swc_fn_fc36583a_000142_56e56812+0x10>
  40d73d:	xor    eax,eax
  40d73f:	ret
  40d740:	mov    eax,DWORD PTR [rcx]
  40d742:	cmp    eax,0x42445753
  40d748:	jne    40d752 <__swc_fn_fc36583a_000142_56e56812+0x22>
  40d74a:	mov    eax,DWORD PTR [rcx+0x4]
  40d74d:	cmp    eax,0x1
  40d750:	je     40d755 <__swc_fn_fc36583a_000142_56e56812+0x25>
  40d752:	xor    eax,eax
  40d754:	ret
  40d755:	mov    QWORD PTR [r8],rdx
  40d758:	mov    rax,rcx
  40d75b:	ret
  40d75c:	add    BYTE PTR [rax],al
	...

000000000040d760 <__swc_fn_fc36583a_000145_863755b5>:
  40d760:	push   rbx
  40d761:	sub    rsp,0xe0
  40d768:	lea    rbx,[rsp+0x8]
  40d76d:	vxorps xmm0,xmm0,xmm0
  40d771:	vmovups XMMWORD PTR [rbx],xmm0
  40d775:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d77a:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d77f:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d784:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d789:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  40d78e:	mov    DWORD PTR [rbx+0x60],0x0
  40d795:	mov    r8,rbx
  40d798:	mov    rdx,rcx
  40d79b:	nop    DWORD PTR [rax+rax*1+0x0]
  40d7a0:	mov    r9,rdx
  40d7a3:	movabs rdx,0x6666666666666667
  40d7ad:	mov    rax,r9
  40d7b0:	imul   rdx
  40d7b3:	sar    rdx,0x2
  40d7b7:	mov    r10,rdx
  40d7ba:	shr    rdx,0x3f
  40d7be:	add    r10,rdx
  40d7c1:	mov    rdx,r10
  40d7c4:	imul   r11,r10,0xa
  40d7c8:	sub    r9,r11
  40d7cb:	mov    r11,QWORD PTR [rip+0x5d6e]        # 413540 <__swc_rdata_base_fc36583a+0x430>
  40d7d2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40d7d7:	mov    BYTE PTR [r8],r9b
  40d7da:	lea    r9,[r8+0x1]
  40d7de:	mov    r8,r9
  40d7e1:	test   r10,r10
  40d7e4:	jne    40d7a0 <__swc_fn_fc36583a_000145_863755b5+0x40>
  40d7e6:	test   rcx,rcx
  40d7e9:	jge    40d7f3 <__swc_fn_fc36583a_000145_863755b5+0x93>
  40d7eb:	mov    BYTE PTR [r9],0x2d
  40d7ef:	add    r8,0x1
  40d7f3:	mov    BYTE PTR [r8],0x0
  40d7f7:	sub    r8,0x1
  40d7fb:	mov    rax,rbx
  40d7fe:	cmp    rax,r8
  40d801:	jae    40d826 <__swc_fn_fc36583a_000145_863755b5+0xc6>
  40d803:	cs nop WORD PTR [rax+rax*1+0x0]
  40d80d:	nop    DWORD PTR [rax]
  40d810:	mov    cl,BYTE PTR [r8]
  40d813:	mov    dl,BYTE PTR [rax]
  40d815:	mov    BYTE PTR [r8],dl
  40d818:	sub    r8,0x1
  40d81c:	mov    BYTE PTR [rax],cl
  40d81e:	inc    rax
  40d821:	cmp    rax,r8
  40d824:	jb     40d810 <__swc_fn_fc36583a_000145_863755b5+0xb0>
  40d826:	xor    eax,eax
  40d828:	test   rbx,rbx
  40d82b:	je     40d84e <__swc_fn_fc36583a_000145_863755b5+0xee>
  40d82d:	mov    rcx,rbx
  40d830:	mov    dl,BYTE PTR [rcx]
  40d832:	test   dl,dl
  40d834:	je     40d84e <__swc_fn_fc36583a_000145_863755b5+0xee>
  40d836:	cs nop WORD PTR [rax+rax*1+0x0]
  40d840:	add    rcx,0x1
  40d844:	add    rax,0x1
  40d848:	mov    dl,BYTE PTR [rcx]
  40d84a:	test   dl,dl
  40d84c:	jne    40d840 <__swc_fn_fc36583a_000145_863755b5+0xe0>
  40d84e:	mov    QWORD PTR [rbx+0xa8],rbx
  40d855:	mov    QWORD PTR [rbx+0xb0],rax
  40d85c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d864:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d86c:	lea    rcx,[rbx+0xb8]
  40d873:	call   4101c0 <__swc_fn_fc36583a_000116_035d76a1>
  40d878:	add    rsp,0xe0
  40d87f:	pop    rbx
  40d880:	ret
	...

000000000040d890 <__swc_fn_fc36583a_000148_9e4bc402>:
  40d890:	vxorps xmm0,xmm0,xmm0
  40d894:	vmovups XMMWORD PTR [rcx],xmm0
  40d898:	mov    QWORD PTR [rcx+0x10],0x0
  40d8a0:	ret
	...

000000000040d8b0 <__swc_fn_fc36583a_000151_9e4bc402>:
  40d8b0:	vxorps xmm0,xmm0,xmm0
  40d8b4:	vmovups XMMWORD PTR [rcx],xmm0
  40d8b8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d8bd:	vxorps xmm0,xmm0,xmm0
  40d8c1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d8c6:	vmovups xmm0,XMMWORD PTR [rip+0x5d6a]        # 413638 <__swc_rdata_base_fc36583a+0x528>
  40d8ce:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d8d3:	vxorps xmm0,xmm0,xmm0
  40d8d7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d8dc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d8e1:	mov    QWORD PTR [rcx+0x60],0x0
  40d8e9:	ret
  40d8ea:	add    BYTE PTR [rax],al
  40d8ec:	add    BYTE PTR [rax],al
	...

000000000040d8f0 <__swc_fn_fc36583a_000154_9e4bc402>:
  40d8f0:	vxorps xmm0,xmm0,xmm0
  40d8f4:	vmovups XMMWORD PTR [rcx],xmm0
  40d8f8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d8fd:	vxorps xmm0,xmm0,xmm0
  40d901:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d906:	vmovups xmm0,XMMWORD PTR [rip+0x5e52]        # 413760 <__swc_rdata_base_fc36583a+0x650>
  40d90e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d913:	vxorps xmm0,xmm0,xmm0
  40d917:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d91c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d921:	vxorps xmm0,xmm0,xmm0
  40d925:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40d92a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40d92f:	vxorps xmm0,xmm0,xmm0
  40d933:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40d93b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40d943:	vxorps xmm0,xmm0,xmm0
  40d947:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40d94f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40d957:	vxorps xmm0,xmm0,xmm0
  40d95b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40d963:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40d96b:	mov    QWORD PTR [rcx+0xe0],0x0
  40d976:	ret
	...

000000000040d980 <__swc_fn_fc36583a_000157_232ffa22>:
  40d980:	push   rbx
  40d981:	mov    rbx,rcx
  40d984:	call   411c50 <__swc_fn_fc36583a_000158_b43b2f96>
  40d989:	mov    rax,QWORD PTR [rbx+0x10]
  40d98d:	test   rax,rax
  40d990:	je     40d9a1 <__swc_fn_fc36583a_000157_232ffa22+0x21>
  40d992:	mov    rcx,rbx
  40d995:	mov    rdx,rax
  40d998:	mov    r8,QWORD PTR [rbx+0x18]
  40d99c:	call   409ec0 <__swc_fn_fc36583a_000156_2745c4a5>
  40d9a1:	vxorps xmm0,xmm0,xmm0
  40d9a5:	vmovups XMMWORD PTR [rbx],xmm0
  40d9a9:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d9ae:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d9b3:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d9b8:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d9bd:	mov    QWORD PTR [rbx+0x50],0x0
  40d9c5:	pop    rbx
  40d9c6:	ret
	...

000000000040d9e0 <__swc_fn_fc36583a_000160_01cbb887>:
  40d9e0:	sub    rsp,0x10
  40d9e4:	mov    eax,r8d
  40d9e7:	mov    r8d,r9d
  40d9ea:	test   r9d,r9d
  40d9ed:	jne    40da06 <__swc_fn_fc36583a_000160_01cbb887+0x26>
  40d9ef:	vmovups xmm0,XMMWORD PTR [rip+0x5e21]        # 413818 <__swc_rdata_base_fc36583a+0x708>
  40d9f7:	vmovups XMMWORD PTR [r10],xmm0
  40d9fc:	mov    eax,0x1
  40da01:	add    rsp,0x10
  40da05:	ret
  40da06:	mov    r9,r8
  40da09:	cmp    r8,rax
  40da0c:	jb     40da13 <__swc_fn_fc36583a_000160_01cbb887+0x33>
  40da0e:	cmp    r9,rdx
  40da11:	jb     40da1a <__swc_fn_fc36583a_000160_01cbb887+0x3a>
  40da13:	xor    eax,eax
  40da15:	add    rsp,0x10
  40da19:	ret
  40da1a:	xor    eax,eax
  40da1c:	lea    r8,[r9+rax*1]
  40da20:	cmp    r8,rdx
  40da23:	jae    40da53 <__swc_fn_fc36583a_000160_01cbb887+0x73>
  40da25:	cs nop WORD PTR [rax+rax*1+0x0]
  40da2f:	cs nop WORD PTR [rax+rax*1+0x0]
  40da39:	nop    DWORD PTR [rax+0x0]
  40da40:	cmp    BYTE PTR [rcx+r8*1],0x0
  40da45:	je     40da53 <__swc_fn_fc36583a_000160_01cbb887+0x73>
  40da47:	inc    rax
  40da4a:	lea    r8,[r9+rax*1]
  40da4e:	cmp    r8,rdx
  40da51:	jb     40da40 <__swc_fn_fc36583a_000160_01cbb887+0x60>
  40da53:	cmp    r8,rdx
  40da56:	jne    40da5f <__swc_fn_fc36583a_000160_01cbb887+0x7f>
  40da58:	xor    eax,eax
  40da5a:	add    rsp,0x10
  40da5e:	ret
  40da5f:	add    rcx,r9
  40da62:	mov    QWORD PTR [rsp],rcx
  40da66:	mov    QWORD PTR [rsp+0x8],rax
  40da6b:	vmovups xmm0,XMMWORD PTR [rsp]
  40da70:	vmovups XMMWORD PTR [r10],xmm0
  40da75:	mov    eax,0x1
  40da7a:	add    rsp,0x10
  40da7e:	ret
	...

000000000040da80 <__swc_fn_fc36583a_000163_8e41797b>:
  40da80:	push   rbp
  40da81:	push   rbx
  40da82:	push   rsi
  40da83:	push   rdi
  40da84:	push   r12
  40da86:	push   r13
  40da88:	push   r14
  40da8a:	push   r15
  40da8c:	sub    rsp,0x10
  40da90:	mov    rbp,rsp
  40da93:	vmovups XMMWORD PTR [rsp],xmm6
  40da98:	sub    rsp,0x50
  40da9c:	mov    rbx,rsp
  40da9f:	mov    rsi,r8
  40daa2:	mov    QWORD PTR [rsp+0x30],r8
  40daa7:	mov    rdi,rcx
  40daaa:	mov    QWORD PTR [rsp+0x38],rcx
  40daaf:	mov    r12,rdx
  40dab2:	xor    r13b,r13b
  40dab5:	mov    r14,QWORD PTR [rdi+0x8]
  40dab9:	mov    QWORD PTR [rsp+0x40],r14
  40dabe:	xor    r15d,r15d
  40dac1:	test   r14,r14
  40dac4:	jbe    40dd1e <__swc_fn_fc36583a_000163_8e41797b+0x29e>
  40daca:	mov    r14,QWORD PTR [rdi]
  40dacd:	mov    rax,QWORD PTR [rsp+0x40]
  40dad2:	mov    QWORD PTR [rsp+0x48],r14
  40dad7:	vmovups xmm6,XMMWORD PTR [rip+0x5959]        # 413438 <__swc_rdata_base_fc36583a+0x328>
  40dadf:	nop
  40dae0:	cmp    QWORD PTR [r14+r15*8],0x0
  40dae5:	jne    40daef <__swc_fn_fc36583a_000163_8e41797b+0x6f>
  40dae7:	mov    r14,rax
  40daea:	jmp    40dcfe <__swc_fn_fc36583a_000163_8e41797b+0x27e>
  40daef:	mov    rcx,QWORD PTR [rdi]
  40daf2:	mov    rdx,QWORD PTR [rcx+r15*8]
  40daf6:	mov    rdi,rbx
  40daf9:	mov    rcx,rdi
  40dafc:	sub    rsp,0x8
  40db00:	mov    r14,rax
  40db03:	call   409f40 <__swc_fn_fc36583a_000162_60216e69>
  40db08:	add    rsp,0x8
  40db0c:	mov    al,BYTE PTR [rbx]
  40db0e:	test   al,al
  40db10:	je     40dcfe <__swc_fn_fc36583a_000163_8e41797b+0x27e>
  40db16:	mov    al,BYTE PTR [rbx+0x1]
  40db19:	test   al,al
  40db1b:	jne    40db26 <__swc_fn_fc36583a_000163_8e41797b+0xa6>
  40db1d:	test   sil,sil
  40db20:	je     40dcfe <__swc_fn_fc36583a_000163_8e41797b+0x27e>
  40db26:	test   r13b,r13b
  40db29:	jne    40dbe7 <__swc_fn_fc36583a_000163_8e41797b+0x167>
  40db2f:	test   r12,r12
  40db32:	je     40dbe7 <__swc_fn_fc36583a_000163_8e41797b+0x167>
  40db38:	mov    al,BYTE PTR [rbx+0x1]
  40db3b:	test   al,al
  40db3d:	je     40dcfe <__swc_fn_fc36583a_000163_8e41797b+0x27e>
  40db43:	mov    eax,DWORD PTR [rbx+0x28]
  40db46:	cmp    DWORD PTR [r12+0x20],eax
  40db4b:	jne    40dcfe <__swc_fn_fc36583a_000163_8e41797b+0x27e>
  40db51:	mov    rax,QWORD PTR [r12]
  40db55:	mov    rcx,QWORD PTR [r12+0x8]
  40db5a:	cmp    QWORD PTR [rbx+0x20],rcx
  40db5e:	jne    40dcfe <__swc_fn_fc36583a_000163_8e41797b+0x27e>
  40db64:	mov    cl,0x1
  40db66:	test   rax,rax
  40db69:	je     40dbd2 <__swc_fn_fc36583a_000163_8e41797b+0x152>
  40db6f:	mov    rdx,QWORD PTR [rbx+0x20]
  40db73:	xor    r8d,r8d
  40db76:	test   rdx,rdx
  40db79:	jbe    40dbd2 <__swc_fn_fc36583a_000163_8e41797b+0x152>
  40db7b:	mov    r9,QWORD PTR [rbx+0x18]
  40db7f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40db84:	cs nop WORD PTR [rax+rax*1+0x0]
  40db8e:	xchg   ax,ax
  40db90:	mov    r10b,BYTE PTR [rax+r8*1]
  40db94:	cmp    BYTE PTR [r9+r8*1],r10b
  40db98:	je     40dbc9 <__swc_fn_fc36583a_000163_8e41797b+0x149>
  40db9a:	vmovq  r10,xmm0
  40db9f:	cmp    BYTE PTR [r10+r8*1],0x5c
  40dba4:	jne    40dbad <__swc_fn_fc36583a_000163_8e41797b+0x12d>
  40dba6:	cmp    BYTE PTR [rax+r8*1],0x2f
  40dbab:	je     40dbc9 <__swc_fn_fc36583a_000163_8e41797b+0x149>
  40dbad:	vmovq  r10,xmm0
  40dbb2:	cmp    BYTE PTR [r10+r8*1],0x2f
  40dbb7:	jne    40dbc0 <__swc_fn_fc36583a_000163_8e41797b+0x140>
  40dbb9:	cmp    BYTE PTR [rax+r8*1],0x5c
  40dbbe:	je     40dbc9 <__swc_fn_fc36583a_000163_8e41797b+0x149>
  40dbc0:	xor    eax,eax
  40dbc2:	movzx  eax,al
  40dbc5:	mov    cl,al
  40dbc7:	jmp    40dbd2 <__swc_fn_fc36583a_000163_8e41797b+0x152>
  40dbc9:	add    r8,0x1
  40dbcd:	cmp    r8,rdx
  40dbd0:	jb     40db90 <__swc_fn_fc36583a_000163_8e41797b+0x110>
  40dbd2:	test   cl,cl
  40dbd4:	je     40dcfe <__swc_fn_fc36583a_000163_8e41797b+0x27e>
  40dbda:	mov    eax,0x1
  40dbdf:	mov    r13b,al
  40dbe2:	jmp    40dcfe <__swc_fn_fc36583a_000163_8e41797b+0x27e>
  40dbe7:	mov    r13b,0x1
  40dbea:	sub    rsp,0x20
  40dbee:	mov    rax,rsp
  40dbf1:	lea    rcx,[rdi+0x8]
  40dbf5:	mov    QWORD PTR [rax],rcx
  40dbf8:	lea    rsi,[rip+0x5711]        # 413310 <__swc_rdata_base_fc36583a+0x200>
  40dbff:	mov    QWORD PTR [rax+0x8],rsi
  40dc03:	mov    QWORD PTR [rax+0x10],rsp
  40dc07:	mov    QWORD PTR [rax+0x18],0x1
  40dc0f:	lea    rcx,[rsp+0x10]
  40dc14:	sub    rsp,0x8
  40dc18:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  40dc1d:	add    rsp,0x8
  40dc21:	add    rsp,0x20
  40dc25:	mov    al,BYTE PTR [rbx+0x1]
  40dc28:	test   al,al
  40dc2a:	je     40dcc7 <__swc_fn_fc36583a_000163_8e41797b+0x247>
  40dc30:	lea    rax,[rip+0x5c81]        # 4138b8 <__swc_rdata_base_fc36583a+0x7a8>
  40dc37:	sub    rsp,0x20
  40dc3b:	mov    rcx,rsp
  40dc3e:	mov    QWORD PTR [rcx],rax
  40dc41:	mov    QWORD PTR [rcx+0x8],rsi
  40dc45:	mov    QWORD PTR [rcx+0x10],rsp
  40dc49:	mov    QWORD PTR [rcx+0x18],0x1
  40dc51:	lea    rcx,[rsp+0x10]
  40dc56:	sub    rsp,0x8
  40dc5a:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  40dc5f:	add    rsp,0x8
  40dc63:	add    rsp,0x20
  40dc67:	mov    eax,DWORD PTR [rbx+0x28]
  40dc6a:	sub    rsp,0x60
  40dc6e:	mov    rcx,rsp
  40dc71:	lea    rdx,[rdi+0x18]
  40dc75:	mov    QWORD PTR [rcx+0x18],rdx
  40dc79:	mov    QWORD PTR [rcx+0x20],rsi
  40dc7d:	vmovups XMMWORD PTR [rcx],xmm6
  40dc81:	mov    QWORD PTR [rcx+0x28],rsp
  40dc85:	mov    QWORD PTR [rcx+0x30],rsi
  40dc89:	mov    DWORD PTR [rcx+0x10],eax
  40dc8c:	lea    rax,[rsp+0x10]
  40dc91:	mov    QWORD PTR [rcx+0x38],rax
  40dc95:	lea    rax,[rip+0x5734]        # 4133d0 <__swc_rdata_base_fc36583a+0x2c0>
  40dc9c:	mov    QWORD PTR [rcx+0x40],rax
  40dca0:	lea    rax,[rsp+0x18]
  40dca5:	mov    QWORD PTR [rcx+0x48],rax
  40dca9:	mov    QWORD PTR [rcx+0x50],0x3
  40dcb1:	lea    rcx,[rsp+0x48]
  40dcb6:	sub    rsp,0x8
  40dcba:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  40dcbf:	add    rsp,0x8
  40dcc3:	add    rsp,0x60
  40dcc7:	lea    rax,[rip+0x569a]        # 413368 <__swc_rdata_base_fc36583a+0x258>
  40dcce:	sub    rsp,0x20
  40dcd2:	mov    rcx,rsp
  40dcd5:	mov    QWORD PTR [rcx],rax
  40dcd8:	mov    QWORD PTR [rcx+0x8],rsi
  40dcdc:	mov    QWORD PTR [rcx+0x10],rsp
  40dce0:	mov    QWORD PTR [rcx+0x18],0x1
  40dce8:	lea    rcx,[rsp+0x10]
  40dced:	sub    rsp,0x8
  40dcf1:	call   410a40 <__swc_fn_fc36583a_000146_43f4fdca>
  40dcf6:	add    rsp,0x8
  40dcfa:	add    rsp,0x20
  40dcfe:	add    r15,0x1
  40dd02:	cmp    r15,r14
  40dd05:	jae    40dd1e <__swc_fn_fc36583a_000163_8e41797b+0x29e>
  40dd07:	mov    rsi,QWORD PTR [rsp+0x30]
  40dd0c:	mov    rdi,QWORD PTR [rsp+0x38]
  40dd11:	mov    rax,r14
  40dd14:	mov    r14,QWORD PTR [rsp+0x48]
  40dd19:	jmp    40dae0 <__swc_fn_fc36583a_000163_8e41797b+0x60>
  40dd1e:	add    rsp,0x50
  40dd22:	vmovups xmm6,XMMWORD PTR [rsp]
  40dd27:	add    rsp,0x10
  40dd2b:	pop    r15
  40dd2d:	pop    r14
  40dd2f:	pop    r13
  40dd31:	pop    r12
  40dd33:	pop    rdi
  40dd34:	pop    rsi
  40dd35:	pop    rbx
  40dd36:	pop    rbp
  40dd37:	ret
	...

000000000040dd40 <__swc_fn_fc36583a_000166_f6173642>:
  40dd40:	sub    rsp,0x8
  40dd44:	call   410450 <__swc_fn_fc36583a_000125_ce762363>
  40dd49:	add    rsp,0x8
  40dd4d:	ret
	...

000000000040dd50 <__swc_fn_fc36583a_000169_4579a84c>:
  40dd50:	push   rsi
  40dd51:	sub    rsp,0x30
  40dd55:	lea    rsi,[rip+0x19044]        # 426da0 <__swc_bss_base_fc36583a+0x2d60>
  40dd5c:	mov    rax,QWORD PTR [rsi]
  40dd5f:	test   rax,rax
  40dd62:	je     40dd6a <__swc_fn_fc36583a_000169_4579a84c+0x1a>
  40dd64:	add    rsp,0x30
  40dd68:	pop    rsi
  40dd69:	ret
  40dd6a:	mov    ecx,0x2
  40dd6f:	mov    edx,0x8020
  40dd74:	call   40fac0 <__swc_fn_fc36583a_000107_4796e893>
  40dd79:	test   rax,rax
  40dd7c:	jne    40dd8d <__swc_fn_fc36583a_000169_4579a84c+0x3d>
  40dd7e:	mov    QWORD PTR [rsp+0x18],rax
  40dd83:	call   40d1d0 <__swc_fn_fc36583a_000118_7f430081>
  40dd88:	mov    rax,QWORD PTR [rsp+0x18]
  40dd8d:	mov    rcx,rax
  40dd90:	xchg   QWORD PTR [rsi],rcx
  40dd93:	add    rsp,0x30
  40dd97:	pop    rsi
  40dd98:	ret
  40dd99:	add    BYTE PTR [rax],al
  40dd9b:	add    BYTE PTR [rax],al
  40dd9d:	add    BYTE PTR [rax],al
	...

000000000040dda0 <__swc_fn_fc36583a_000172_97fbc432>:
  40dda0:	push   rsi
  40dda1:	test   r8,r8
  40dda4:	jne    40dda8 <__swc_fn_fc36583a_000172_97fbc432+0x8>
  40dda6:	pop    rsi
  40dda7:	ret
  40dda8:	lea    rax,[rcx+0x18]
  40ddac:	mov    r10,QWORD PTR [rax]
  40ddaf:	lea    r11,[r10+0x1]
  40ddb3:	mov    QWORD PTR [rax],r11
  40ddb6:	mov    r11,rdx
  40ddb9:	not    rdx
  40ddbc:	lea    rsi,[r8-0x1]
  40ddc0:	cmp    rsi,rdx
  40ddc3:	ja     40dde3 <__swc_fn_fc36583a_000172_97fbc432+0x43>
  40ddc5:	lea    rdx,[r11+r8*1]
  40ddc9:	dec    rdx
  40ddcc:	shr    rdx,0x6
  40ddd0:	mov    r8,r11
  40ddd3:	shr    r8,0x6
  40ddd7:	mov    rsi,rdx
  40ddda:	sub    rsi,r8
  40dddd:	cmp    rsi,0x8
  40dde1:	jb     40ddf9 <__swc_fn_fc36583a_000172_97fbc432+0x59>
  40dde3:	lea    rcx,[rcx+0x10]
  40dde7:	mov    rdx,QWORD PTR [rcx]
  40ddea:	add    rdx,r9
  40dded:	mov    QWORD PTR [rcx],rdx
  40ddf0:	lea    rcx,[r10+0x2]
  40ddf4:	mov    QWORD PTR [rax],rcx
  40ddf7:	pop    rsi
  40ddf8:	ret
  40ddf9:	shr    r11,0x6
  40ddfd:	nop    DWORD PTR [rax]
  40de00:	cmp    r11,rdx
  40de03:	ja     40de43 <__swc_fn_fc36583a_000172_97fbc432+0xa3>
  40de05:	jmp    40de16 <__swc_fn_fc36583a_000172_97fbc432+0x76>
  40de07:	nop    WORD PTR [rax+rax*1+0x0]
  40de10:	add    r11,0x1
  40de14:	jmp    40de00 <__swc_fn_fc36583a_000172_97fbc432+0x60>
  40de16:	mov    r8,r11
  40de19:	shr    r8,0xc
  40de1d:	mov    rsi,r11
  40de20:	xor    rsi,r8
  40de23:	mov    r8,r11
  40de26:	shr    r8,0x18
  40de2a:	xor    rsi,r8
  40de2d:	and    esi,0xfff
  40de33:	lea    r8,[rcx+rsi*8+0x20]
  40de38:	mov    rsi,QWORD PTR [r8]
  40de3b:	add    rsi,r9
  40de3e:	mov    QWORD PTR [r8],rsi
  40de41:	jmp    40de10 <__swc_fn_fc36583a_000172_97fbc432+0x70>
  40de43:	lea    rcx,[r10+0x2]
  40de47:	mov    QWORD PTR [rax],rcx
  40de4a:	pop    rsi
  40de4b:	ret
  40de4c:	add    BYTE PTR [rax],al
	...

000000000040de50 <__swc_fn_fc36583a_000175_2744b483>:
  40de50:	push   rbx
  40de51:	sub    rsp,0x70
  40de55:	cmp    rcx,0xffffffffffffffef
  40de59:	jbe    40de63 <__swc_fn_fc36583a_000175_2744b483+0x13>
  40de5b:	xor    eax,eax
  40de5d:	add    rsp,0x70
  40de61:	pop    rbx
  40de62:	ret
  40de63:	vxorps xmm0,xmm0,xmm0
  40de67:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40de6d:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40de73:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40de79:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40de7f:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40de85:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40de8b:	lea    rax,[rcx+0x10]
  40de8f:	mov    QWORD PTR [rsp+0x50],rax
  40de94:	mov    DWORD PTR [rsp+0x60],0x10
  40de9c:	mov    rcx,QWORD PTR [rip+0x18e9d]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40dea3:	test   rcx,rcx
  40dea6:	jne    40deb8 <__swc_fn_fc36583a_000175_2744b483+0x68>
  40dea8:	call   40a1d0 <__swc_fn_fc36583a_000165_cf398896>
  40dead:	lea    rcx,[rax+0x1]
  40deb1:	mov    QWORD PTR [rip+0x18e88],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40deb8:	dec    rcx
  40debb:	call   411fc0 <__swc_fn_fc36583a_000167_fce60b2b>
  40dec0:	mov    rcx,QWORD PTR [rax]
  40dec3:	lea    rdx,[rsp+0x8]
  40dec8:	mov    rbx,QWORD PTR [rax+0x8]
  40decc:	mov    rbx,QWORD PTR [rbx+0x8]
  40ded0:	call   rbx
  40ded2:	mov    rax,QWORD PTR [rsp+0x48]
  40ded7:	test   rax,rax
  40deda:	jne    40dee4 <__swc_fn_fc36583a_000175_2744b483+0x94>
  40dedc:	xor    eax,eax
  40dede:	add    rsp,0x70
  40dee2:	pop    rbx
  40dee3:	ret
  40dee4:	mov    rcx,QWORD PTR [rsp+0x50]
  40dee9:	mov    QWORD PTR [rax],rcx
  40deec:	mov    QWORD PTR [rax+0x8],0x0
  40def4:	lea    rax,[rax+0x10]
  40def8:	add    rsp,0x70
  40defc:	pop    rbx
  40defd:	ret
	...

000000000040df00 <__swc_fn_fc36583a_000002_884bb5c0>:
  40df00:	sub    rsp,0x8
  40df04:	call   40ce20 <__swc_fn_fc36583a_000109_8d425bd3>
  40df09:	mov    rcx,rax
  40df0c:	test   rax,rax
  40df0f:	je     40df36 <__swc_fn_fc36583a_000002_884bb5c0+0x36>
  40df11:	lea    rdx,[rip+0x16128]        # 424040 <__swc_bss_base_fc36583a>
  40df18:	mov    r8,QWORD PTR [rip+0x16121]        # 424040 <__swc_bss_base_fc36583a>
  40df1f:	nop
  40df20:	lea    r9,[r8+0x1]
  40df24:	mov    rax,r8
  40df27:	lock cmpxchg QWORD PTR [rdx],r9
  40df2c:	cmp    rax,r8
  40df2f:	je     40df36 <__swc_fn_fc36583a_000002_884bb5c0+0x36>
  40df31:	mov    r8,rax
  40df34:	jmp    40df20 <__swc_fn_fc36583a_000002_884bb5c0+0x20>
  40df36:	mov    rax,rcx
  40df39:	add    rsp,0x8
  40df3d:	ret
	...

000000000040df40 <__swc_fn_fc36583a_000005_b2240b56>:
  40df40:	mov    r8d,edx
  40df43:	xor    eax,eax
  40df45:	tzcnt  eax,edx
  40df49:	shrx   r9d,edx,eax
  40df4e:	mov    DWORD PTR [rcx+0x2c],edx
  40df51:	xor    eax,eax
  40df53:	tzcnt  eax,edx
  40df57:	mov    BYTE PTR [rcx+0x38],al
  40df5a:	mov    eax,0xffffffff
  40df5f:	xor    edx,edx
  40df61:	div    r8d
  40df64:	mov    DWORD PTR [rcx+0x34],eax
  40df67:	mov    eax,r9d
  40df6a:	mov    edx,r9d
  40df6d:	imul   edx,r9d
  40df71:	mov    r8d,0x2
  40df77:	sub    r8d,edx
  40df7a:	imul   eax,r8d
  40df7e:	mov    edx,r9d
  40df81:	imul   edx,eax
  40df84:	mov    r8d,0x2
  40df8a:	sub    r8d,edx
  40df8d:	imul   eax,r8d
  40df91:	mov    edx,r9d
  40df94:	imul   edx,eax
  40df97:	mov    r8d,0x2
  40df9d:	sub    r8d,edx
  40dfa0:	imul   eax,r8d
  40dfa4:	mov    edx,r9d
  40dfa7:	imul   edx,eax
  40dfaa:	mov    r8d,0x2
  40dfb0:	sub    r8d,edx
  40dfb3:	imul   eax,r8d
  40dfb7:	imul   r9d,eax
  40dfbb:	mov    edx,0x2
  40dfc0:	sub    edx,r9d
  40dfc3:	imul   eax,edx
  40dfc6:	mov    DWORD PTR [rcx+0x30],eax
  40dfc9:	ret
  40dfca:	add    BYTE PTR [rax],al
  40dfcc:	add    BYTE PTR [rax],al
	...

000000000040dfd0 <__swc_fn_fc36583a_000008_4e857afc>:
  40dfd0:	xor    eax,eax
  40dfd2:	mov    DWORD PTR [rcx+0x68],eax
  40dfd5:	ret
	...

000000000040dfe0 <__swc_fn_fc36583a_000011_6493fbbc>:
  40dfe0:	mov    eax,DWORD PTR [rcx+0x28]
  40dfe3:	shlx   eax,edx,eax
  40dfe8:	shl    rax,0x10
  40dfec:	lea    rdx,[rcx+rax*1]
  40dff0:	lea    rax,[rcx+0x3000]
  40dff7:	cmp    rdx,rax
  40dffa:	cmovae rax,rdx
  40dffe:	ret
	...

000000000040e000 <__swc_fn_fc36583a_000014_afb279e2>:
  40e000:	push   rsi
  40e001:	push   rdi
  40e002:	push   r12
  40e004:	push   r13
  40e006:	push   r14
  40e008:	mov    rsi,rdx
  40e00b:	mov    rdi,rcx
  40e00e:	rex mov dl,BYTE PTR [rsi+0x3a]
  40e012:	mov    ecx,DWORD PTR [rdi+0x28]
  40e015:	shr    dl,cl
  40e017:	mov    r12d,0x1
  40e01d:	mov    ecx,edx
  40e01f:	shl    r12,cl
  40e022:	mov    r13d,DWORD PTR [rsi+0x3c]
  40e026:	rex mov BYTE PTR [rsi+0x3b],0x0
  40e02b:	mov    QWORD PTR [rsi+0x40],0x0
  40e033:	mov    QWORD PTR [rsi],0x0
  40e03a:	mov    rax,QWORD PTR [rsi+0x10]
  40e03e:	mov    QWORD PTR [rsi+0x20],rax
  40e042:	lea    r14,[rip+0x15fff]        # 424048 <__swc_bss_base_fc36583a+0x8>
  40e049:	mov    rax,QWORD PTR [r14]
  40e04c:	shr    rax,0x2
  40e050:	mov    rcx,rax
  40e053:	cmp    rax,0x800000
  40e05a:	mov    eax,0x800000
  40e05f:	cmovb  rcx,rax
  40e063:	lea    r8,[rip+0x15fee]        # 424058 <__swc_bss_base_fc36583a+0x18>
  40e06a:	mov    rax,QWORD PTR [r8]
  40e06d:	mov    r9,rax
  40e070:	lea    r10,[r9+r13*1]
  40e074:	cmp    r10,rcx
  40e077:	ja     40e09b <__swc_fn_fc36583a_000014_afb279e2+0x9b>
  40e079:	mov    rax,r9
  40e07c:	lock cmpxchg QWORD PTR [r8],r10
  40e081:	cmp    rax,r9
  40e084:	je     40e08b <__swc_fn_fc36583a_000014_afb279e2+0x8b>
  40e086:	mov    r9,rax
  40e089:	jmp    40e070 <__swc_fn_fc36583a_000014_afb279e2+0x70>
  40e08b:	mov    rcx,rdi
  40e08e:	mov    rdx,r12
  40e091:	call   40af50 <__swc_fn_fc36583a_000016_4b207b58>
  40e096:	jmp    40e11d <__swc_fn_fc36583a_000014_afb279e2+0x11d>
  40e09b:	mov    rcx,rdi
  40e09e:	movzx  edx,dl
  40e0a1:	call   40dfe0 <__swc_fn_fc36583a_000011_6493fbbc>
  40e0a6:	test   r13,r13
  40e0a9:	je     40e116 <__swc_fn_fc36583a_000014_afb279e2+0x116>
  40e0af:	mov    rcx,rax
  40e0b2:	mov    rdx,r13
  40e0b5:	call   40cfa0 <__swc_fn_fc36583a_000112_759e9ceb>
  40e0ba:	mov    rcx,QWORD PTR [rip+0x15f87]        # 424048 <__swc_bss_base_fc36583a+0x8>
  40e0c1:	cs nop WORD PTR [rax+rax*1+0x0]
  40e0cb:	nop    DWORD PTR [rax+rax*1+0x0]
  40e0d0:	mov    rdx,rcx
  40e0d3:	sub    rdx,r13
  40e0d6:	mov    rax,rcx
  40e0d9:	lock cmpxchg QWORD PTR [r14],rdx
  40e0de:	cmp    rax,rcx
  40e0e1:	je     40e0e8 <__swc_fn_fc36583a_000014_afb279e2+0xe8>
  40e0e3:	mov    rcx,rax
  40e0e6:	jmp    40e0d0 <__swc_fn_fc36583a_000014_afb279e2+0xd0>
  40e0e8:	lea    rcx,[rip+0x15f71]        # 424060 <__swc_bss_base_fc36583a+0x20>
  40e0ef:	mov    rdx,QWORD PTR [rip+0x15f6a]        # 424060 <__swc_bss_base_fc36583a+0x20>
  40e0f6:	cs nop WORD PTR [rax+rax*1+0x0]
  40e100:	lea    r8,[rdx+0x1]
  40e104:	mov    rax,rdx
  40e107:	lock cmpxchg QWORD PTR [rcx],r8
  40e10c:	cmp    rax,rdx
  40e10f:	je     40e116 <__swc_fn_fc36583a_000014_afb279e2+0x116>
  40e111:	mov    rdx,rax
  40e114:	jmp    40e100 <__swc_fn_fc36583a_000014_afb279e2+0x100>
  40e116:	mov    DWORD PTR [rsi+0x3c],0x0
  40e11d:	mov    rcx,rdi
  40e120:	mov    rdx,r12
  40e123:	call   407600 <__swc_fn_fc36583a_000018_7d1e8a10>
  40e128:	pop    r14
  40e12a:	pop    r13
  40e12c:	pop    r12
  40e12e:	pop    rdi
  40e12f:	pop    rsi
  40e130:	ret
	...

000000000040e140 <__swc_fn_fc36583a_000017_4df2d1a0>:
  40e140:	mov    r8,QWORD PTR [rcx+0x48]
  40e144:	test   r8,rdx
  40e147:	je     40e178 <__swc_fn_fc36583a_000017_4df2d1a0+0x38>
  40e149:	nop    DWORD PTR [rax+0x0]
  40e150:	mov    rax,rdx
  40e153:	not    rax
  40e156:	mov    r9,r8
  40e159:	and    r9,rax
  40e15c:	mov    rax,r8
  40e15f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40e165:	cmp    rax,r8
  40e168:	jne    40e170 <__swc_fn_fc36583a_000017_4df2d1a0+0x30>
  40e16a:	mov    eax,0x1
  40e16f:	ret
  40e170:	mov    r8,rax
  40e173:	test   rax,rdx
  40e176:	jne    40e150 <__swc_fn_fc36583a_000017_4df2d1a0+0x10>
  40e178:	xor    eax,eax
  40e17a:	ret
  40e17b:	add    BYTE PTR [rax],al
  40e17d:	add    BYTE PTR [rax],al
	...

000000000040e180 <__swc_fn_fc36583a_000020_a66e8b97>:
  40e180:	push   rsi
  40e181:	push   rdi
  40e182:	push   r12
  40e184:	push   r13
  40e186:	sub    rsp,0x8
  40e18a:	mov    rsi,rdx
  40e18d:	mov    rdi,rcx
  40e190:	lea    r12,[rip+0x16059]        # 4241f0 <__swc_bss_base_fc36583a+0x1b0>
  40e197:	mov    rcx,r12
  40e19a:	call   4098c0 <__swc_fn_fc36583a_000135_e3032dc2>
  40e19f:	xor    eax,eax
  40e1a1:	mov    rcx,QWORD PTR [rip+0x16050]        # 4241f8 <__swc_bss_base_fc36583a+0x1b8>
  40e1a8:	mov    r13,rcx
  40e1ab:	test   r13,r13
  40e1ae:	je     40e1fb <__swc_fn_fc36583a_000020_a66e8b97+0x7b>
  40e1b0:	mov    rcx,QWORD PTR [r13+0x10]
  40e1b4:	cmp    DWORD PTR [r13+0x28],esi
  40e1b8:	jne    40e1f0 <__swc_fn_fc36583a_000020_a66e8b97+0x70>
  40e1ba:	test   rax,rax
  40e1bd:	jne    40e1c8 <__swc_fn_fc36583a_000020_a66e8b97+0x48>
  40e1bf:	mov    QWORD PTR [rip+0x16032],rcx        # 4241f8 <__swc_bss_base_fc36583a+0x1b8>
  40e1c6:	jmp    40e1cc <__swc_fn_fc36583a_000020_a66e8b97+0x4c>
  40e1c8:	mov    QWORD PTR [rax+0x10],rcx
  40e1cc:	vxorps xmm0,xmm0,xmm0
  40e1d0:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40e1d6:	mov    QWORD PTR [r13+0x8],rdi
  40e1da:	mov    rcx,r12
  40e1dd:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  40e1e2:	mov    rax,r13
  40e1e5:	add    rsp,0x8
  40e1e9:	pop    r13
  40e1eb:	pop    r12
  40e1ed:	pop    rdi
  40e1ee:	pop    rsi
  40e1ef:	ret
  40e1f0:	mov    rax,r13
  40e1f3:	mov    r13,rcx
  40e1f6:	test   rcx,rcx
  40e1f9:	jne    40e1b0 <__swc_fn_fc36583a_000020_a66e8b97+0x30>
  40e1fb:	mov    ecx,esi
  40e1fd:	call   40af80 <__swc_fn_fc36583a_000019_2cc1532c>
  40e202:	mov    rsi,rax
  40e205:	test   rax,rax
  40e208:	jne    40e21f <__swc_fn_fc36583a_000020_a66e8b97+0x9f>
  40e20a:	mov    rcx,r12
  40e20d:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  40e212:	xor    eax,eax
  40e214:	add    rsp,0x8
  40e218:	pop    r13
  40e21a:	pop    r12
  40e21c:	pop    rdi
  40e21d:	pop    rsi
  40e21e:	ret
  40e21f:	mov    QWORD PTR [rsi+0x8],rdi
  40e223:	mov    rcx,r12
  40e226:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  40e22b:	mov    rax,rsi
  40e22e:	add    rsp,0x8
  40e232:	pop    r13
  40e234:	pop    r12
  40e236:	pop    rdi
  40e237:	pop    rsi
  40e238:	ret
  40e239:	add    BYTE PTR [rax],al
  40e23b:	add    BYTE PTR [rax],al
  40e23d:	add    BYTE PTR [rax],al
	...

000000000040e240 <__swc_fn_fc36583a_000023_4aca8b9e>:
  40e240:	vxorps xmm0,xmm0,xmm0
  40e244:	xor    eax,eax
  40e246:	cs nop WORD PTR [rax+rax*1+0x0]
  40e250:	cs nop WORD PTR [rax+rax*1+0x0]
  40e25a:	nop    WORD PTR [rax+rax*1+0x0]
  40e260:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40e265:	add    rax,0x10
  40e269:	cmp    rax,0x2b00
  40e270:	jne    40e260 <__swc_fn_fc36583a_000023_4aca8b9e+0x20>
  40e272:	ret
	...

000000000040e280 <__swc_fn_fc36583a_000026_4aca8b9e>:
  40e280:	vxorps xmm0,xmm0,xmm0
  40e284:	vmovups XMMWORD PTR [rcx],xmm0
  40e288:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e28d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e292:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e297:	ret
	...

000000000040e2a0 <__swc_fn_fc36583a_000029_4aca8b9e>:
  40e2a0:	vxorps xmm0,xmm0,xmm0
  40e2a4:	vmovups XMMWORD PTR [rcx],xmm0
  40e2a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e2ad:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e2b2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e2b7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40e2bc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40e2c1:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40e2c6:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40e2cb:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40e2d3:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40e2db:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40e2e3:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40e2eb:	mov    QWORD PTR [rcx+0xc0],0x0
  40e2f6:	ret
	...

000000000040e300 <__swc_fn_fc36583a_000032_84881cd8>:
  40e300:	push   rsi
  40e301:	push   rdi
  40e302:	sub    rsp,0x8
  40e306:	mov    rsi,rcx
  40e309:	lea    rdi,[rip+0x13cf0]        # 422000 <__swc_data_base_fc36583a>
  40e310:	mov    rax,QWORD PTR [rdi]
  40e313:	cmp    rax,0xffffffffffffffff
  40e317:	je     40e31e <__swc_fn_fc36583a_000032_84881cd8+0x1e>
  40e319:	mov    rdi,rax
  40e31c:	jmp    40e34b <__swc_fn_fc36583a_000032_84881cd8+0x4b>
  40e31e:	call   4095a0 <__swc_fn_fc36583a_000123_9d2cbd72>
  40e323:	mov    rcx,rax
  40e326:	cmp    rax,0xffffffffffffffff
  40e32a:	je     40e35c <__swc_fn_fc36583a_000032_84881cd8+0x5c>
  40e32c:	mov    rax,0xffffffffffffffff
  40e333:	lock cmpxchg QWORD PTR [rdi],rcx
  40e338:	cmp    rax,0xffffffffffffffff
  40e33c:	je     40e348 <__swc_fn_fc36583a_000032_84881cd8+0x48>
  40e33e:	mov    rdi,rax
  40e341:	call   40d370 <__swc_fn_fc36583a_000124_667fbf24>
  40e346:	jmp    40e34b <__swc_fn_fc36583a_000032_84881cd8+0x4b>
  40e348:	mov    rdi,rcx
  40e34b:	cmp    rdi,0xffffffffffffffff
  40e34f:	je     40e35c <__swc_fn_fc36583a_000032_84881cd8+0x5c>
  40e351:	mov    rcx,rdi
  40e354:	mov    rdx,rsi
  40e357:	call   410450 <__swc_fn_fc36583a_000125_ce762363>
  40e35c:	add    rsp,0x8
  40e360:	pop    rdi
  40e361:	pop    rsi
  40e362:	ret
	...

000000000040e370 <__swc_fn_fc36583a_000035_95622a2b>:
  40e370:	sub    rsp,0x38
  40e374:	mov    rax,rdx
  40e377:	test   dl,dl
  40e379:	jne    40e391 <__swc_fn_fc36583a_000035_95622a2b+0x21>
  40e37b:	mov    rax,r8
  40e37e:	test   r8b,r8b
  40e381:	cmove  eax,r9d
  40e385:	test   al,al
  40e387:	cmove  eax,r10d
  40e38b:	test   al,al
  40e38d:	cmove  eax,r11d
  40e391:	test   al,al
  40e393:	jne    40e39a <__swc_fn_fc36583a_000035_95622a2b+0x2a>
  40e395:	add    rsp,0x38
  40e399:	ret
  40e39a:	lea    rcx,[rip+0x4d6f]        # 413110 <__swc_rdata_base_fc36583a>
  40e3a1:	vmovups xmm0,XMMWORD PTR [rip+0x4d77]        # 413120 <__swc_rdata_base_fc36583a+0x10>
  40e3a9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e3af:	vmovups xmm0,XMMWORD PTR [rip+0x4d79]        # 413130 <__swc_rdata_base_fc36583a+0x20>
  40e3b7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e3bd:	vmovups xmm0,XMMWORD PTR [rip+0x4d7b]        # 413140 <__swc_rdata_base_fc36583a+0x30>
  40e3c5:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e3cb:	lea    rdx,[rsp+0x8]
  40e3d0:	call   40cba0 <__swc_fn_fc36583a_000103_67100064>
  40e3d5:	jmp    40e395 <__swc_fn_fc36583a_000035_95622a2b+0x25>
	...

000000000040e3e0 <__swc_fn_fc36583a_000038_788ceb38>:
  40e3e0:	sub    rsp,0x8
  40e3e4:	mov    eax,0x1000
  40e3e9:	test   eax,eax
  40e3eb:	mov    r8d,0x8
  40e3f1:	cmove  eax,r8d
  40e3f5:	dec    rax
  40e3f8:	mov    r8,0xffffffffffffffff
  40e3ff:	sub    r8,rax
  40e402:	cmp    rdx,r8
  40e405:	ja     40e415 <__swc_fn_fc36583a_000038_788ceb38+0x35>
  40e407:	add    rdx,rax
  40e40a:	not    rax
  40e40d:	mov    r8,rdx
  40e410:	and    r8,rax
  40e413:	jne    40e41c <__swc_fn_fc36583a_000038_788ceb38+0x3c>
  40e415:	xor    eax,eax
  40e417:	add    rsp,0x8
  40e41b:	ret
  40e41c:	mov    rdx,r8
  40e41f:	call   40b2a0 <__swc_fn_fc36583a_000037_b4982903>
  40e424:	add    rsp,0x8
  40e428:	ret
  40e429:	add    BYTE PTR [rax],al
  40e42b:	add    BYTE PTR [rax],al
  40e42d:	add    BYTE PTR [rax],al
	...

000000000040e430 <__swc_fn_fc36583a_000041_414cc921>:
  40e430:	push   rsi
  40e431:	push   rdi
  40e432:	sub    rsp,0x8
  40e436:	mov    rsi,rdx
  40e439:	mov    rdi,rcx
  40e43c:	test   rdx,rdx
  40e43f:	je     40e45b <__swc_fn_fc36583a_000041_414cc921+0x2b>
  40e441:	xor    ecx,ecx
  40e443:	call   407720 <__swc_fn_fc36583a_000033_7ca1566d>
  40e448:	mov    rax,QWORD PTR [rsi]
  40e44b:	test   rax,rax
  40e44e:	je     40e45b <__swc_fn_fc36583a_000041_414cc921+0x2b>
  40e450:	mov    rcx,rax
  40e453:	mov    rdx,rsi
  40e456:	call   407840 <__swc_fn_fc36583a_000042_bab03645>
  40e45b:	mov    rcx,rdi
  40e45e:	call   40b300 <__swc_fn_fc36583a_000040_6895916d>
  40e463:	mov    rsi,rax
  40e466:	test   rax,rax
  40e469:	jne    40e474 <__swc_fn_fc36583a_000041_414cc921+0x44>
  40e46b:	xor    eax,eax
  40e46d:	add    rsp,0x8
  40e471:	pop    rdi
  40e472:	pop    rsi
  40e473:	ret
  40e474:	mov    rcx,rsi
  40e477:	call   407720 <__swc_fn_fc36583a_000033_7ca1566d>
  40e47c:	mov    rax,rsi
  40e47f:	add    rsp,0x8
  40e483:	pop    rdi
  40e484:	pop    rsi
  40e485:	ret
	...

000000000040e490 <__swc_fn_fc36583a_000044_9c2ade9b>:
  40e490:	movzx  eax,BYTE PTR [r8+0x39]
  40e495:	lea    rax,[rax+rax*4]
  40e499:	lea    rax,[rdx+rax*8+0x28]
  40e49e:	mov    ecx,DWORD PTR [r8+0x6c]
  40e4a2:	test   ecx,ecx
  40e4a4:	je     40e4dd <__swc_fn_fc36583a_000044_9c2ade9b+0x4d>
  40e4a6:	mov    rcx,QWORD PTR [r8+0x50]
  40e4aa:	test   rcx,rcx
  40e4ad:	je     40e4b9 <__swc_fn_fc36583a_000044_9c2ade9b+0x29>
  40e4af:	mov    rax,QWORD PTR [r8+0x48]
  40e4b3:	mov    QWORD PTR [rcx+0x48],rax
  40e4b7:	jmp    40e4c1 <__swc_fn_fc36583a_000044_9c2ade9b+0x31>
  40e4b9:	mov    rcx,QWORD PTR [r8+0x48]
  40e4bd:	mov    QWORD PTR [rax+0x18],rcx
  40e4c1:	mov    rax,QWORD PTR [r8+0x48]
  40e4c5:	test   rax,rax
  40e4c8:	je     40e4d2 <__swc_fn_fc36583a_000044_9c2ade9b+0x42>
  40e4ca:	mov    rcx,QWORD PTR [r8+0x50]
  40e4ce:	mov    QWORD PTR [rax+0x50],rcx
  40e4d2:	vxorps xmm0,xmm0,xmm0
  40e4d6:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e4dc:	ret
  40e4dd:	mov    rcx,QWORD PTR [r8+0x50]
  40e4e1:	test   rcx,rcx
  40e4e4:	je     40e4f0 <__swc_fn_fc36583a_000044_9c2ade9b+0x60>
  40e4e6:	mov    rdx,QWORD PTR [r8+0x48]
  40e4ea:	mov    QWORD PTR [rcx+0x48],rdx
  40e4ee:	jmp    40e4f8 <__swc_fn_fc36583a_000044_9c2ade9b+0x68>
  40e4f0:	mov    rcx,QWORD PTR [r8+0x48]
  40e4f4:	mov    QWORD PTR [rax+0x8],rcx
  40e4f8:	mov    rcx,QWORD PTR [r8+0x48]
  40e4fc:	test   rcx,rcx
  40e4ff:	je     40e50b <__swc_fn_fc36583a_000044_9c2ade9b+0x7b>
  40e501:	mov    rdx,QWORD PTR [r8+0x50]
  40e505:	mov    QWORD PTR [rcx+0x50],rdx
  40e509:	jmp    40e513 <__swc_fn_fc36583a_000044_9c2ade9b+0x83>
  40e50b:	mov    rcx,QWORD PTR [r8+0x50]
  40e50f:	mov    QWORD PTR [rax+0x10],rcx
  40e513:	cmp    QWORD PTR [rax],r8
  40e516:	jne    40e51f <__swc_fn_fc36583a_000044_9c2ade9b+0x8f>
  40e518:	mov    QWORD PTR [rax],0x0
  40e51f:	vxorps xmm0,xmm0,xmm0
  40e523:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e529:	ret
  40e52a:	add    BYTE PTR [rax],al
  40e52c:	add    BYTE PTR [rax],al
	...

000000000040e530 <__swc_fn_fc36583a_000047_bc5ec610>:
  40e530:	sub    rsp,0x8
  40e534:	mov    r9,r8
  40e537:	mov    r10,rdx
  40e53a:	call   40e490 <__swc_fn_fc36583a_000044_9c2ade9b>
  40e53f:	mov    DWORD PTR [r9+0x6c],0x0
  40e547:	movzx  eax,BYTE PTR [r9+0x39]
  40e54c:	lea    rax,[rax+rax*4]
  40e550:	lea    rax,[r10+rax*8+0x28]
  40e555:	mov    rcx,QWORD PTR [rax+0x10]
  40e559:	mov    QWORD PTR [r9+0x50],rcx
  40e55d:	mov    QWORD PTR [r9+0x48],0x0
  40e565:	mov    rcx,QWORD PTR [rax+0x10]
  40e569:	test   rcx,rcx
  40e56c:	je     40e574 <__swc_fn_fc36583a_000047_bc5ec610+0x44>
  40e56e:	mov    QWORD PTR [rcx+0x48],r9
  40e572:	jmp    40e578 <__swc_fn_fc36583a_000047_bc5ec610+0x48>
  40e574:	mov    QWORD PTR [rax+0x8],r9
  40e578:	mov    QWORD PTR [rax+0x10],r9
  40e57c:	add    rsp,0x8
  40e580:	ret
	...

000000000040e5a0 <__swc_fn_fc36583a_000050_ab8077df>:
  40e5a0:	push   rsi
  40e5a1:	push   rdi
  40e5a2:	push   r12
  40e5a4:	push   r13
  40e5a6:	push   r14
  40e5a8:	push   r15
  40e5aa:	sub    rsp,0x1f8
  40e5b1:	mov    esi,r8d
  40e5b4:	mov    QWORD PTR [rsp+0x1e8],rsi
  40e5bc:	mov    rdi,rcx
  40e5bf:	mov    r12,rdx
  40e5c2:	lea    r13,[rsi+rsi*4]
  40e5c6:	lea    r13,[rdx+r13*8+0x28]
  40e5cb:	call   407ca0 <__swc_fn_fc36583a_000048_c877e9d2>
  40e5d0:	add    DWORD PTR [r12+0x24],0x1
  40e5d6:	test   BYTE PTR [r12+0x24],0x3f
  40e5dc:	jne    40e5e6 <__swc_fn_fc36583a_000050_ab8077df+0x46>
  40e5de:	mov    rcx,rdi
  40e5e1:	call   40b480 <__swc_fn_fc36583a_000049_2ff013cc>
  40e5e6:	mov    rax,QWORD PTR [r13+0x8]
  40e5ea:	mov    r14,rax
  40e5ed:	nop    DWORD PTR [rax]
  40e5f0:	test   r14,r14
  40e5f3:	jne    40e602 <__swc_fn_fc36583a_000050_ab8077df+0x62>
  40e5f5:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40e5fd:	jmp    40e709 <__swc_fn_fc36583a_000050_ab8077df+0x169>
  40e602:	mov    r15,QWORD PTR [r14+0x48]
  40e606:	mov    rcx,r14
  40e609:	call   4073f0 <__swc_fn_fc36583a_000009_d7e2bb25>
  40e60e:	mov    rax,QWORD PTR [r14]
  40e611:	test   rax,rax
  40e614:	je     40e626 <__swc_fn_fc36583a_000050_ab8077df+0x86>
  40e616:	mov    rcx,QWORD PTR [rax]
  40e619:	mov    QWORD PTR [r14],rcx
  40e61c:	add    DWORD PTR [r14+0x28],0x1
  40e621:	mov    rsi,rax
  40e624:	jmp    40e645 <__swc_fn_fc36583a_000050_ab8077df+0xa5>
  40e626:	mov    rax,QWORD PTR [r14+0x18]
  40e62a:	cmp    QWORD PTR [r14+0x20],rax
  40e62e:	jae    40e643 <__swc_fn_fc36583a_000050_ab8077df+0xa3>
  40e630:	mov    rsi,QWORD PTR [r14+0x20]
  40e634:	mov    eax,DWORD PTR [r14+0x2c]
  40e638:	add    QWORD PTR [r14+0x20],rax
  40e63c:	add    DWORD PTR [r14+0x28],0x1
  40e641:	jmp    40e645 <__swc_fn_fc36583a_000050_ab8077df+0xa5>
  40e643:	xor    esi,esi
  40e645:	test   rsi,rsi
  40e648:	jne    40e68d <__swc_fn_fc36583a_000050_ab8077df+0xed>
  40e64a:	mov    rcx,r14
  40e64d:	call   407320 <__swc_fn_fc36583a_000006_a23dca5f>
  40e652:	test   al,al
  40e654:	je     40e68d <__swc_fn_fc36583a_000050_ab8077df+0xed>
  40e656:	mov    rax,QWORD PTR [r14]
  40e659:	test   rax,rax
  40e65c:	je     40e66b <__swc_fn_fc36583a_000050_ab8077df+0xcb>
  40e65e:	mov    rcx,QWORD PTR [rax]
  40e661:	mov    QWORD PTR [r14],rcx
  40e664:	add    DWORD PTR [r14+0x28],0x1
  40e669:	jmp    40e68a <__swc_fn_fc36583a_000050_ab8077df+0xea>
  40e66b:	mov    rax,QWORD PTR [r14+0x18]
  40e66f:	cmp    QWORD PTR [r14+0x20],rax
  40e673:	jae    40e688 <__swc_fn_fc36583a_000050_ab8077df+0xe8>
  40e675:	mov    rax,QWORD PTR [r14+0x20]
  40e679:	mov    ecx,DWORD PTR [r14+0x2c]
  40e67d:	add    QWORD PTR [r14+0x20],rcx
  40e681:	add    DWORD PTR [r14+0x28],0x1
  40e686:	jmp    40e68a <__swc_fn_fc36583a_000050_ab8077df+0xea>
  40e688:	xor    eax,eax
  40e68a:	mov    rsi,rax
  40e68d:	test   rsi,rsi
  40e690:	jne    40e6e3 <__swc_fn_fc36583a_000050_ab8077df+0x143>
  40e692:	mov    rcx,rdi
  40e695:	mov    rdx,r12
  40e698:	mov    r8,r14
  40e69b:	call   40b3e0 <__swc_fn_fc36583a_000046_88f44774>
  40e6a0:	test   al,al
  40e6a2:	jne    40e6e3 <__swc_fn_fc36583a_000050_ab8077df+0x143>
  40e6a4:	mov    rcx,r14
  40e6a7:	call   4073f0 <__swc_fn_fc36583a_000009_d7e2bb25>
  40e6ac:	mov    rax,QWORD PTR [r14]
  40e6af:	test   rax,rax
  40e6b2:	je     40e6c1 <__swc_fn_fc36583a_000050_ab8077df+0x121>
  40e6b4:	mov    rcx,QWORD PTR [rax]
  40e6b7:	mov    QWORD PTR [r14],rcx
  40e6ba:	add    DWORD PTR [r14+0x28],0x1
  40e6bf:	jmp    40e6e0 <__swc_fn_fc36583a_000050_ab8077df+0x140>
  40e6c1:	mov    rax,QWORD PTR [r14+0x18]
  40e6c5:	cmp    QWORD PTR [r14+0x20],rax
  40e6c9:	jae    40e6de <__swc_fn_fc36583a_000050_ab8077df+0x13e>
  40e6cb:	mov    rax,QWORD PTR [r14+0x20]
  40e6cf:	mov    ecx,DWORD PTR [r14+0x2c]
  40e6d3:	add    QWORD PTR [r14+0x20],rcx
  40e6d7:	add    DWORD PTR [r14+0x28],0x1
  40e6dc:	jmp    40e6e0 <__swc_fn_fc36583a_000050_ab8077df+0x140>
  40e6de:	xor    eax,eax
  40e6e0:	mov    rsi,rax
  40e6e3:	test   rsi,rsi
  40e6e6:	je     40e701 <__swc_fn_fc36583a_000050_ab8077df+0x161>
  40e6e8:	mov    QWORD PTR [r13+0x0],r14
  40e6ec:	mov    rax,rsi
  40e6ef:	add    rsp,0x1f8
  40e6f6:	pop    r15
  40e6f8:	pop    r14
  40e6fa:	pop    r13
  40e6fc:	pop    r12
  40e6fe:	pop    rdi
  40e6ff:	pop    rsi
  40e700:	ret
  40e701:	mov    r14,r15
  40e704:	jmp    40e5f0 <__swc_fn_fc36583a_000050_ab8077df+0x50>
  40e709:	cs nop WORD PTR [rax+rax*1+0x0]
  40e713:	cs nop WORD PTR [rax+rax*1+0x0]
  40e71d:	nop    DWORD PTR [rax]
  40e720:	mov    rcx,rdi
  40e723:	mov    rdx,r12
  40e726:	mov    r8d,esi
  40e729:	call   4079e0 <__swc_fn_fc36583a_000045_1fe0f4e2>
  40e72e:	mov    r14,rax
  40e731:	test   rax,rax
  40e734:	jne    40e74a <__swc_fn_fc36583a_000050_ab8077df+0x1aa>
  40e736:	xor    eax,eax
  40e738:	add    rsp,0x1f8
  40e73f:	pop    r15
  40e741:	pop    r14
  40e743:	pop    r13
  40e745:	pop    r12
  40e747:	pop    rdi
  40e748:	pop    rsi
  40e749:	ret
  40e74a:	mov    QWORD PTR [r13+0x0],r14
  40e74e:	mov    rax,QWORD PTR [r14]
  40e751:	test   rax,rax
  40e754:	je     40e766 <__swc_fn_fc36583a_000050_ab8077df+0x1c6>
  40e756:	mov    rcx,QWORD PTR [rax]
  40e759:	mov    QWORD PTR [r14],rcx
  40e75c:	add    DWORD PTR [r14+0x28],0x1
  40e761:	mov    r15,rax
  40e764:	jmp    40e786 <__swc_fn_fc36583a_000050_ab8077df+0x1e6>
  40e766:	mov    rax,QWORD PTR [r14+0x18]
  40e76a:	cmp    QWORD PTR [r14+0x20],rax
  40e76e:	jae    40e783 <__swc_fn_fc36583a_000050_ab8077df+0x1e3>
  40e770:	mov    r15,QWORD PTR [r14+0x20]
  40e774:	mov    eax,DWORD PTR [r14+0x2c]
  40e778:	add    QWORD PTR [r14+0x20],rax
  40e77c:	add    DWORD PTR [r14+0x28],0x1
  40e781:	jmp    40e786 <__swc_fn_fc36583a_000050_ab8077df+0x1e6>
  40e783:	xor    r15d,r15d
  40e786:	test   r15,r15
  40e789:	jne    40e7ce <__swc_fn_fc36583a_000050_ab8077df+0x22e>
  40e78b:	mov    rcx,r14
  40e78e:	call   407320 <__swc_fn_fc36583a_000006_a23dca5f>
  40e793:	test   al,al
  40e795:	je     40e7ce <__swc_fn_fc36583a_000050_ab8077df+0x22e>
  40e797:	mov    rax,QWORD PTR [r14]
  40e79a:	test   rax,rax
  40e79d:	je     40e7ac <__swc_fn_fc36583a_000050_ab8077df+0x20c>
  40e79f:	mov    rcx,QWORD PTR [rax]
  40e7a2:	mov    QWORD PTR [r14],rcx
  40e7a5:	add    DWORD PTR [r14+0x28],0x1
  40e7aa:	jmp    40e7cb <__swc_fn_fc36583a_000050_ab8077df+0x22b>
  40e7ac:	mov    rax,QWORD PTR [r14+0x18]
  40e7b0:	cmp    QWORD PTR [r14+0x20],rax
  40e7b4:	jae    40e7c9 <__swc_fn_fc36583a_000050_ab8077df+0x229>
  40e7b6:	mov    rax,QWORD PTR [r14+0x20]
  40e7ba:	mov    ecx,DWORD PTR [r14+0x2c]
  40e7be:	add    QWORD PTR [r14+0x20],rcx
  40e7c2:	add    DWORD PTR [r14+0x28],0x1
  40e7c7:	jmp    40e7cb <__swc_fn_fc36583a_000050_ab8077df+0x22b>
  40e7c9:	xor    eax,eax
  40e7cb:	mov    r15,rax
  40e7ce:	test   r15,r15
  40e7d1:	je     40e720 <__swc_fn_fc36583a_000050_ab8077df+0x180>
  40e7d7:	mov    rax,r15
  40e7da:	add    rsp,0x1f8
  40e7e1:	pop    r15
  40e7e3:	pop    r14
  40e7e5:	pop    r13
  40e7e7:	pop    r12
  40e7e9:	pop    rdi
  40e7ea:	pop    rsi
  40e7eb:	ret
  40e7ec:	add    BYTE PTR [rax],al
	...

000000000040e7f0 <__swc_fn_fc36583a_000053_82546d94>:
  40e7f0:	push   rsi
  40e7f1:	push   rdi
  40e7f2:	push   r12
  40e7f4:	mov    rsi,rdx
  40e7f7:	mov    rax,rdx
  40e7fa:	shr    rax,0xc
  40e7fe:	movabs rdx,0x9e3779b97f4a7c15
  40e808:	imul   rax,rdx
  40e80c:	shr    rax,0x20
  40e810:	lea    rax,[rax*8+0x0]
  40e818:	shr    rax,0x20
  40e81c:	lea    rax,[rax*8+0x0]
  40e824:	lea    rax,[rcx+rax*8+0x40]
  40e829:	xor    edx,edx
  40e82b:	test   dl,dl
  40e82d:	lea    rdi,[rcx+0x8]
  40e831:	cmove  rdi,rax
  40e835:	xor    edx,edx
  40e837:	test   dl,dl
  40e839:	lea    r12,[rcx+0x30]
  40e83d:	lea    rax,[rax+0x8]
  40e841:	cmove  r12,rax
  40e845:	mov    rcx,rdi
  40e848:	call   4098c0 <__swc_fn_fc36583a_000135_e3032dc2>
  40e84d:	mov    QWORD PTR [rsi+0x30],0x0
  40e855:	mov    rax,QWORD PTR [r12]
  40e859:	mov    QWORD PTR [rsi+0x38],rax
  40e85d:	test   rax,rax
  40e860:	je     40e86a <__swc_fn_fc36583a_000053_82546d94+0x7a>
  40e862:	mov    rax,QWORD PTR [rsi+0x38]
  40e866:	mov    QWORD PTR [rax+0x30],rsi
  40e86a:	mov    QWORD PTR [r12],rsi
  40e86e:	mov    rcx,rdi
  40e871:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  40e876:	pop    r12
  40e878:	pop    rdi
  40e879:	pop    rsi
  40e87a:	ret
  40e87b:	add    BYTE PTR [rax],al
  40e87d:	add    BYTE PTR [rax],al
	...

000000000040e880 <__swc_fn_fc36583a_000056_38b21f11>:
  40e880:	lea    rax,[rdx+rdx*4]
  40e884:	lea    rax,[rcx+rax*8+0x268]
  40e88c:	mov    rdx,QWORD PTR [rax+0x10]
  40e890:	sub    QWORD PTR [rcx+0x2a68],rdx
  40e897:	sub    QWORD PTR [rcx+0x2a70],0x1
  40e89f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40e8a6:	lea    rdx,[rdx+rdx*4]
  40e8aa:	lea    rdx,[rcx+rdx*8+0x268]
  40e8b2:	vmovups xmm0,XMMWORD PTR [rdx]
  40e8b6:	vmovups XMMWORD PTR [rax],xmm0
  40e8ba:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40e8bf:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e8c4:	mov    rcx,QWORD PTR [rdx+0x20]
  40e8c8:	mov    QWORD PTR [rax+0x20],rcx
  40e8cc:	ret
  40e8cd:	add    BYTE PTR [rax],al
	...

000000000040e8d0 <__swc_fn_fc36583a_000059_3ca3ac64>:
  40e8d0:	push   rsi
  40e8d1:	push   rdi
  40e8d2:	push   r12
  40e8d4:	push   r13
  40e8d6:	sub    rsp,0x8
  40e8da:	mov    rsi,r8
  40e8dd:	mov    rdi,rcx
  40e8e0:	mov    r12,rdx
  40e8e3:	xor    r13d,r13d
  40e8e6:	cs nop WORD PTR [rax+rax*1+0x0]
  40e8f0:	mov    eax,DWORD PTR [r12+0x730]
  40e8f8:	cmp    r13d,eax
  40e8fb:	jae    40e961 <__swc_fn_fc36583a_000059_3ca3ac64+0x91>
  40e8fd:	lea    rax,[r13+r13*4+0x0]
  40e902:	lea    rax,[r12+rax*8+0x738]
  40e90a:	mov    rdx,QWORD PTR [rax]
  40e90d:	mov    r8,QWORD PTR [rax+0x8]
  40e911:	mov    r9,QWORD PTR [rax+0x10]
  40e915:	cmp    QWORD PTR [rax+0x20],rsi
  40e919:	jb     40e920 <__swc_fn_fc36583a_000059_3ca3ac64+0x50>
  40e91b:	inc    r13d
  40e91e:	jmp    40e8f0 <__swc_fn_fc36583a_000059_3ca3ac64+0x20>
  40e920:	sub    DWORD PTR [r12+0x730],0x1
  40e929:	mov    ecx,DWORD PTR [r12+0x730]
  40e931:	lea    rcx,[rcx+rcx*4]
  40e935:	lea    rcx,[r12+rcx*8+0x738]
  40e93d:	vmovups xmm0,XMMWORD PTR [rcx]
  40e941:	vmovups XMMWORD PTR [rax],xmm0
  40e945:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40e94a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e94f:	mov    rcx,QWORD PTR [rcx+0x20]
  40e953:	mov    QWORD PTR [rax+0x20],rcx
  40e957:	mov    rcx,rdi
  40e95a:	call   407750 <__swc_fn_fc36583a_000039_40d1e569>
  40e95f:	jmp    40e8f0 <__swc_fn_fc36583a_000059_3ca3ac64+0x20>
  40e961:	add    rsp,0x8
  40e965:	pop    r13
  40e967:	pop    r12
  40e969:	pop    rdi
  40e96a:	pop    rsi
  40e96b:	ret
  40e96c:	add    BYTE PTR [rax],al
	...

000000000040e970 <__swc_fn_fc36583a_000062_7e482c5f>:
  40e970:	push   rsi
  40e971:	push   rdi
  40e972:	push   r12
  40e974:	push   r13
  40e976:	push   r14
  40e978:	mov    rsi,rcx
  40e97b:	mov    rdi,rdx
  40e97e:	mov    r12,QWORD PTR [rdi]
  40e981:	mov    r13,QWORD PTR [rdi+0x18]
  40e985:	mov    rax,r12
  40e988:	add    rax,QWORD PTR [rdi+0x8]
  40e98c:	sub    rax,r13
  40e98f:	cmp    r8,rax
  40e992:	jbe    40e99d <__swc_fn_fc36583a_000062_7e482c5f+0x2d>
  40e994:	pop    r14
  40e996:	pop    r13
  40e998:	pop    r12
  40e99a:	pop    rdi
  40e99b:	pop    rsi
  40e99c:	ret
  40e99d:	lea    rax,[r13+r8*1+0x0]
  40e9a2:	sub    rax,r12
  40e9a5:	mov    ecx,0x1000
  40e9aa:	test   ecx,ecx
  40e9ac:	mov    edx,0x8
  40e9b1:	cmove  ecx,edx
  40e9b4:	dec    rcx
  40e9b7:	mov    rdx,0xffffffffffffffff
  40e9be:	sub    rdx,rcx
  40e9c1:	cmp    rax,rdx
  40e9c4:	jbe    40e9cb <__swc_fn_fc36583a_000062_7e482c5f+0x5b>
  40e9c6:	xor    r14d,r14d
  40e9c9:	jmp    40e9d6 <__swc_fn_fc36583a_000062_7e482c5f+0x66>
  40e9cb:	add    rax,rcx
  40e9ce:	andn   rax,rcx,rax
  40e9d3:	mov    r14,rax
  40e9d6:	mov    rax,QWORD PTR [rdi+0x10]
  40e9da:	cmp    r14,rax
  40e9dd:	ja     40e9e8 <__swc_fn_fc36583a_000062_7e482c5f+0x78>
  40e9df:	pop    r14
  40e9e1:	pop    r13
  40e9e3:	pop    r12
  40e9e5:	pop    rdi
  40e9e6:	pop    rsi
  40e9e7:	ret
  40e9e8:	mov    rax,r12
  40e9eb:	add    rax,QWORD PTR [rdi+0x10]
  40e9ef:	mov    rdx,r14
  40e9f2:	sub    rdx,QWORD PTR [rdi+0x10]
  40e9f6:	mov    rcx,rax
  40e9f9:	call   4072a0 <__swc_fn_fc36583a_000003_7ab4792e>
  40e9fe:	test   al,al
  40ea00:	jne    40ea0b <__swc_fn_fc36583a_000062_7e482c5f+0x9b>
  40ea02:	pop    r14
  40ea04:	pop    r13
  40ea06:	pop    r12
  40ea08:	pop    rdi
  40ea09:	pop    rsi
  40ea0a:	ret
  40ea0b:	add    r12,r14
  40ea0e:	sub    r12,r13
  40ea11:	mov    rcx,r12
  40ea14:	sub    rcx,QWORD PTR [rdi+0x28]
  40ea18:	mov    rdx,QWORD PTR [rsi+0x250]
  40ea1f:	nop
  40ea20:	lea    r8,[rdx+rcx*1]
  40ea24:	mov    rax,rdx
  40ea27:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40ea30:	cmp    rax,rdx
  40ea33:	je     40ea3a <__swc_fn_fc36583a_000062_7e482c5f+0xca>
  40ea35:	mov    rdx,rax
  40ea38:	jmp    40ea20 <__swc_fn_fc36583a_000062_7e482c5f+0xb0>
  40ea3a:	mov    QWORD PTR [rdi+0x10],r14
  40ea3e:	mov    QWORD PTR [rdi+0x28],r12
  40ea42:	pop    r14
  40ea44:	pop    r13
  40ea46:	pop    r12
  40ea48:	pop    rdi
  40ea49:	pop    rsi
  40ea4a:	ret
  40ea4b:	add    BYTE PTR [rax],al
  40ea4d:	add    BYTE PTR [rax],al
	...

000000000040ea50 <__swc_fn_fc36583a_000065_f9f4b610>:
  40ea50:	push   rbx
  40ea51:	push   rsi
  40ea52:	push   rdi
  40ea53:	push   r12
  40ea55:	push   r13
  40ea57:	sub    rsp,0xe0
  40ea5e:	mov    rbx,rdx
  40ea61:	mov    rsi,rcx
  40ea64:	cmp    DWORD PTR [rbx+0x58],0x0
  40ea68:	je     40ea8c <__swc_fn_fc36583a_000065_f9f4b610+0x3c>
  40ea6a:	mov    eax,DWORD PTR [rbx+0x58]
  40ea6d:	sub    eax,0x1
  40ea70:	test   DWORD PTR [rbx+0x58],eax
  40ea73:	je     40ea8c <__swc_fn_fc36583a_000065_f9f4b610+0x3c>
  40ea75:	mov    QWORD PTR [rbx+0x40],0x0
  40ea7d:	add    rsp,0xe0
  40ea84:	pop    r13
  40ea86:	pop    r12
  40ea88:	pop    rdi
  40ea89:	pop    rsi
  40ea8a:	pop    rbx
  40ea8b:	ret
  40ea8c:	mov    rax,QWORD PTR [rbx+0x40]
  40ea90:	test   rax,rax
  40ea93:	jne    40eaaf <__swc_fn_fc36583a_000065_f9f4b610+0x5f>
  40ea95:	mov    rcx,rsi
  40ea98:	mov    rdx,rbx
  40ea9b:	call   40c090 <__swc_fn_fc36583a_000064_b0d63361>
  40eaa0:	add    rsp,0xe0
  40eaa7:	pop    r13
  40eaa9:	pop    r12
  40eaab:	pop    rdi
  40eaac:	pop    rsi
  40eaad:	pop    rbx
  40eaae:	ret
  40eaaf:	cmp    QWORD PTR [rbx+0x48],0x0
  40eab4:	jne    40ead0 <__swc_fn_fc36583a_000065_f9f4b610+0x80>
  40eab6:	mov    rcx,rsi
  40eab9:	mov    rdx,rbx
  40eabc:	call   407f90 <__swc_fn_fc36583a_000066_254b71af>
  40eac1:	add    rsp,0xe0
  40eac8:	pop    r13
  40eaca:	pop    r12
  40eacc:	pop    rdi
  40eacd:	pop    rsi
  40eace:	pop    rbx
  40eacf:	ret
  40ead0:	mov    rdi,QWORD PTR [rbx+0x40]
  40ead4:	lea    rax,[rip+0x15595]        # 424070 <__swc_bss_base_fc36583a+0x30>
  40eadb:	mov    rcx,rdi
  40eade:	sub    rcx,QWORD PTR [rax+0x8]
  40eae2:	mov    rax,QWORD PTR [rip+0x15597]        # 424080 <__swc_bss_base_fc36583a+0x40>
  40eae9:	cmp    rcx,rax
  40eaec:	jae    40eb18 <__swc_fn_fc36583a_000065_f9f4b610+0xc8>
  40eaee:	mov    rax,rdi
  40eaf1:	and    rax,0xffffffffffc00000
  40eaf8:	mov    rcx,rdi
  40eafb:	shr    rcx,0x10
  40eaff:	and    ecx,0x3f
  40eb02:	mov    edx,DWORD PTR [rax+0x28]
  40eb05:	shrx   ecx,ecx,edx
  40eb0a:	shl    rcx,0x4
  40eb0e:	lea    r12,[rax+rcx*8+0x80]
  40eb16:	jmp    40eb23 <__swc_fn_fc36583a_000065_f9f4b610+0xd3>
  40eb18:	mov    rcx,rdi
  40eb1b:	call   40b110 <__swc_fn_fc36583a_000022_3a2e2048>
  40eb20:	mov    r12,rax
  40eb23:	test   r12,r12
  40eb26:	je     40eb35 <__swc_fn_fc36583a_000065_f9f4b610+0xe5>
  40eb28:	mov    eax,DWORD PTR [r12+0x2c]
  40eb2d:	mov    r9d,eax
  40eb30:	mov    r13,rax
  40eb33:	jmp    40ebb4 <__swc_fn_fc36583a_000065_f9f4b610+0x164>
  40eb35:	mov    rcx,rsi
  40eb38:	mov    rdx,rdi
  40eb3b:	call   40b720 <__swc_fn_fc36583a_000052_c7484fb0>
  40eb40:	mov    rcx,QWORD PTR [rax+0x28]
  40eb44:	mov    r9,rcx
  40eb47:	mov    rdx,QWORD PTR [rax+0x20]
  40eb4b:	mov    r13,rdx
  40eb4e:	cmp    QWORD PTR [rbx+0x48],rcx
  40eb52:	jbe    40eb8b <__swc_fn_fc36583a_000065_f9f4b610+0x13b>
  40eb54:	mov    ecx,DWORD PTR [rax+0x48]
  40eb57:	cmp    DWORD PTR [rbx+0x58],ecx
  40eb5a:	ja     40eb8b <__swc_fn_fc36583a_000065_f9f4b610+0x13b>
  40eb5c:	mov    rcx,rsi
  40eb5f:	mov    rdx,rax
  40eb62:	mov    r8,QWORD PTR [rbx+0x48]
  40eb66:	mov    QWORD PTR [rsp+0xc8],r9
  40eb6e:	mov    QWORD PTR [rsp+0xd0],rax
  40eb76:	call   40e970 <__swc_fn_fc36583a_000062_7e482c5f>
  40eb7b:	mov    r9,QWORD PTR [rsp+0xc8]
  40eb83:	mov    rax,QWORD PTR [rsp+0xd0]
  40eb8b:	mov    rcx,QWORD PTR [rax+0x28]
  40eb8f:	cmp    QWORD PTR [rbx+0x48],rcx
  40eb93:	ja     40ebb4 <__swc_fn_fc36583a_000065_f9f4b610+0x164>
  40eb95:	mov    ecx,DWORD PTR [rax+0x48]
  40eb98:	cmp    DWORD PTR [rbx+0x58],ecx
  40eb9b:	ja     40ebb4 <__swc_fn_fc36583a_000065_f9f4b610+0x164>
  40eb9d:	mov    rcx,QWORD PTR [rbx+0x48]
  40eba1:	mov    QWORD PTR [rax+0x20],rcx
  40eba5:	add    rsp,0xe0
  40ebac:	pop    r13
  40ebae:	pop    r12
  40ebb0:	pop    rdi
  40ebb1:	pop    rsi
  40ebb2:	pop    rbx
  40ebb3:	ret
  40ebb4:	test   r12,r12
  40ebb7:	je     40ebe9 <__swc_fn_fc36583a_000065_f9f4b610+0x199>
  40ebb9:	cmp    QWORD PTR [rbx+0x48],r9
  40ebbd:	ja     40ebe9 <__swc_fn_fc36583a_000065_f9f4b610+0x199>
  40ebbf:	cmp    DWORD PTR [rbx+0x58],0x40
  40ebc3:	ja     40ebe9 <__swc_fn_fc36583a_000065_f9f4b610+0x199>
  40ebc5:	cmp    DWORD PTR [rbx+0x58],0x0
  40ebc9:	je     40ebd6 <__swc_fn_fc36583a_000065_f9f4b610+0x186>
  40ebcb:	mov    ecx,DWORD PTR [rbx+0x58]
  40ebce:	dec    rcx
  40ebd1:	test   rdi,rcx
  40ebd4:	jne    40ebe9 <__swc_fn_fc36583a_000065_f9f4b610+0x199>
  40ebd6:	mov    QWORD PTR [rbx+0x40],rdi
  40ebda:	add    rsp,0xe0
  40ebe1:	pop    r13
  40ebe3:	pop    r12
  40ebe5:	pop    rdi
  40ebe6:	pop    rsi
  40ebe7:	pop    rbx
  40ebe8:	ret
  40ebe9:	vmovups xmm0,XMMWORD PTR [rbx]
  40ebed:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ebf3:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40ebf8:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40ebfe:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40ec03:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40ec09:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40ec0e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40ec14:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40ec19:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40ec1f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40ec24:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40ec2a:	mov    QWORD PTR [rsp+0x48],0x0
  40ec33:	mov    rcx,rsi
  40ec36:	lea    rdx,[rsp+0x8]
  40ec3b:	call   40c090 <__swc_fn_fc36583a_000064_b0d63361>
  40ec40:	mov    rax,QWORD PTR [rsp+0x48]
  40ec45:	test   rax,rax
  40ec48:	jne    40ec61 <__swc_fn_fc36583a_000065_f9f4b610+0x211>
  40ec4a:	mov    QWORD PTR [rbx+0x40],0x0
  40ec52:	add    rsp,0xe0
  40ec59:	pop    r13
  40ec5b:	pop    r12
  40ec5d:	pop    rdi
  40ec5e:	pop    rsi
  40ec5f:	pop    rbx
  40ec60:	ret
  40ec61:	mov    rax,QWORD PTR [rbx+0x48]
  40ec65:	cmp    r13,rax
  40ec68:	cmovbe rax,r13
  40ec6c:	mov    rcx,QWORD PTR [rsp+0x48]
  40ec71:	mov    rdx,rdi
  40ec74:	mov    r8,rax
  40ec77:	call   409100 <__swc_fn_fc36583a_000105_6fd80914>
  40ec7c:	vmovups xmm0,XMMWORD PTR [rbx]
  40ec80:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40ec86:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40ec8b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40ec91:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40ec96:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40ec9f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40eca4:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40ecad:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40ecb2:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40ecbb:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40ecc0:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40ecc9:	mov    QWORD PTR [rsp+0xa8],rdi
  40ecd1:	mov    rcx,rsi
  40ecd4:	lea    rdx,[rsp+0x68]
  40ecd9:	call   407f90 <__swc_fn_fc36583a_000066_254b71af>
  40ecde:	mov    rax,QWORD PTR [rsp+0x48]
  40ece3:	mov    QWORD PTR [rbx+0x40],rax
  40ece7:	add    rsp,0xe0
  40ecee:	pop    r13
  40ecf0:	pop    r12
  40ecf2:	pop    rdi
  40ecf3:	pop    rsi
  40ecf4:	pop    rbx
  40ecf5:	ret
	...

000000000040ed00 <__swc_fn_fc36583a_000068_7d4c42bf>:
  40ed00:	push   r12
  40ed02:	push   rdi
  40ed03:	push   rsi
  40ed04:	push   r13
  40ed06:	push   r14
  40ed08:	sub    rsp,0x190
  40ed0f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40ed18:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40ed21:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40ed2a:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40ed33:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40ed3c:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40ed45:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40ed4e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40ed57:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40ed60:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40ed69:	mov    r12,rcx
  40ed6c:	lea    rax,[rip+0x1328d]        # 422000 <__swc_data_base_fc36583a>
  40ed73:	mov    rax,QWORD PTR [rax]
  40ed76:	cmp    rax,0xffffffffffffffff
  40ed7a:	je     40ed89 <__swc_fn_fc36583a_000068_7d4c42bf+0x89>
  40ed7c:	mov    eax,eax
  40ed7e:	mov    edi,eax
  40ed80:	xor    eax,eax
  40ed82:	call   407000 <pthread_getspecific@plt>
  40ed87:	jmp    40ed8b <__swc_fn_fc36583a_000068_7d4c42bf+0x8b>
  40ed89:	xor    eax,eax
  40ed8b:	test   rax,rax
  40ed8e:	jne    40ed9d <__swc_fn_fc36583a_000068_7d4c42bf+0x9d>
  40ed90:	call   40b1e0 <__swc_fn_fc36583a_000031_90860ff2>
  40ed95:	mov    rcx,rax
  40ed98:	call   410500 <__swc_fn_fc36583a_000128_41c3251c>
  40ed9d:	test   rax,rax
  40eda0:	je     40edc6 <__swc_fn_fc36583a_000068_7d4c42bf+0xc6>
  40eda2:	cmp    QWORD PTR [rax],r12
  40eda5:	jne    40edc6 <__swc_fn_fc36583a_000068_7d4c42bf+0xc6>
  40eda7:	xor    ecx,ecx
  40eda9:	mov    QWORD PTR [rsp+0xc8],rax
  40edb1:	call   407720 <__swc_fn_fc36583a_000033_7ca1566d>
  40edb6:	mov    rdx,QWORD PTR [rsp+0xc8]
  40edbe:	mov    rcx,r12
  40edc1:	call   407840 <__swc_fn_fc36583a_000042_bab03645>
  40edc6:	lea    rsi,[r12+0x10]
  40edcb:	mov    rcx,rsi
  40edce:	call   4098c0 <__swc_fn_fc36583a_000135_e3032dc2>
  40edd3:	mov    rdi,QWORD PTR [r12+0x20]
  40edd8:	test   rdi,rdi
  40eddb:	je     40ee1e <__swc_fn_fc36583a_000068_7d4c42bf+0x11e>
  40eddd:	nop    DWORD PTR [rax]
  40ede0:	mov    rcx,r12
  40ede3:	mov    rdx,rdi
  40ede6:	call   40b3a0 <__swc_fn_fc36583a_000043_957e4917>
  40edeb:	mov    rcx,r12
  40edee:	mov    rdx,rdi
  40edf1:	mov    r8,0xffffffffffffffff
  40edf8:	call   40e8d0 <__swc_fn_fc36583a_000059_3ca3ac64>
  40edfd:	mov    rcx,r12
  40ee00:	mov    rdx,rdi
  40ee03:	mov    r8d,0x9b8
  40ee09:	mov    r9d,0x9b8
  40ee0f:	call   407750 <__swc_fn_fc36583a_000039_40d1e569>
  40ee14:	mov    rdi,QWORD PTR [r12+0x20]
  40ee19:	test   rdi,rdi
  40ee1c:	jne    40ede0 <__swc_fn_fc36583a_000068_7d4c42bf+0xe0>
  40ee1e:	xor    eax,eax
  40ee20:	xchg   QWORD PTR [r12+0x2a80],rax
  40ee28:	test   rax,rax
  40ee2b:	je     40ee51 <__swc_fn_fc36583a_000068_7d4c42bf+0x151>
  40ee2d:	cs nop WORD PTR [rax+rax*1+0x0]
  40ee37:	nop    WORD PTR [rax+rax*1+0x0]
  40ee40:	mov    rcx,rax
  40ee43:	mov    rax,QWORD PTR [rax+0x78]
  40ee47:	xor    edx,edx
  40ee49:	xchg   DWORD PTR [rcx+0x70],edx
  40ee4c:	test   rax,rax
  40ee4f:	jne    40ee40 <__swc_fn_fc36583a_000068_7d4c42bf+0x140>
  40ee51:	mov    rax,QWORD PTR [r12+0x18]
  40ee56:	mov    rdi,rax
  40ee59:	test   rdi,rdi
  40ee5c:	je     40eef1 <__swc_fn_fc36583a_000068_7d4c42bf+0x1f1>
  40ee62:	cs nop WORD PTR [rax+rax*1+0x0]
  40ee6c:	nop    DWORD PTR [rax+0x0]
  40ee70:	mov    rax,QWORD PTR [rdi+0x10]
  40ee74:	mov    r8d,DWORD PTR [rdi+0x2c]
  40ee78:	xor    r9d,r9d
  40ee7b:	test   r8,r8
  40ee7e:	jbe    40eedd <__swc_fn_fc36583a_000068_7d4c42bf+0x1dd>
  40ee80:	mov    ecx,r9d
  40ee83:	shl    rcx,0x4
  40ee87:	lea    rdx,[rdi+rcx*8+0x80]
  40ee8f:	cmp    BYTE PTR [rdx+0x3b],0x0
  40ee93:	je     40eed4 <__swc_fn_fc36583a_000068_7d4c42bf+0x1d4>
  40ee95:	mov    DWORD PTR [rdx+0x28],0x0
  40ee9c:	mov    rcx,rdi
  40ee9f:	mov    QWORD PTR [rsp+0xd0],rax
  40eea7:	mov    QWORD PTR [rsp+0xd8],r8
  40eeaf:	mov    QWORD PTR [rsp+0xe0],r9
  40eeb7:	call   40e000 <__swc_fn_fc36583a_000014_afb279e2>
  40eebc:	mov    rax,QWORD PTR [rsp+0xd0]
  40eec4:	mov    r8,QWORD PTR [rsp+0xd8]
  40eecc:	mov    r9,QWORD PTR [rsp+0xe0]
  40eed4:	add    r9,0x1
  40eed8:	cmp    r9,r8
  40eedb:	jb     40ee80 <__swc_fn_fc36583a_000068_7d4c42bf+0x180>
  40eedd:	mov    rcx,rdi
  40eee0:	mov    rdi,rax
  40eee3:	call   407630 <__swc_fn_fc36583a_000021_491ac000>
  40eee8:	test   rdi,rdi
  40eeeb:	jne    40ee70 <__swc_fn_fc36583a_000068_7d4c42bf+0x170>
  40eef1:	mov    QWORD PTR [r12+0x18],0x0
  40eefa:	mov    QWORD PTR [r12+0x28],0x0
  40ef03:	mov    rcx,rsi
  40ef06:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  40ef0b:	mov    esi,0x8
  40ef10:	xor    edi,edi
  40ef12:	test   rsi,rsi
  40ef15:	je     40ef72 <__swc_fn_fc36583a_000068_7d4c42bf+0x272>
  40ef1b:	nop    DWORD PTR [rax+rax*1+0x0]
  40ef20:	lea    r13,[rdi*8+0x0]
  40ef28:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40ef2d:	test   r14,r14
  40ef30:	je     40ef68 <__swc_fn_fc36583a_000068_7d4c42bf+0x268>
  40ef32:	cs nop WORD PTR [rax+rax*1+0x0]
  40ef3c:	nop    DWORD PTR [rax+0x0]
  40ef40:	mov    rcx,r12
  40ef43:	mov    rdx,r14
  40ef46:	call   407df0 <__swc_fn_fc36583a_000054_ae20ea33>
  40ef4b:	mov    rcx,r12
  40ef4e:	mov    rdx,QWORD PTR [r14]
  40ef51:	mov    r8,QWORD PTR [r14+0x8]
  40ef55:	mov    r9,QWORD PTR [r14+0x10]
  40ef59:	call   407750 <__swc_fn_fc36583a_000039_40d1e569>
  40ef5e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40ef63:	test   r14,r14
  40ef66:	jne    40ef40 <__swc_fn_fc36583a_000068_7d4c42bf+0x240>
  40ef68:	add    rdi,0x1
  40ef6c:	sub    rsi,0x1
  40ef70:	jne    40ef20 <__swc_fn_fc36583a_000068_7d4c42bf+0x220>
  40ef72:	mov    rcx,r12
  40ef75:	call   407ec0 <__swc_fn_fc36583a_000060_e6407a0a>
  40ef7a:	lea    rcx,[r12+0x250]
  40ef82:	mov    rdx,QWORD PTR [rcx]
  40ef85:	mov    r8,QWORD PTR [r12+0x250]
  40ef8d:	nop    DWORD PTR [rax]
  40ef90:	mov    r9,r8
  40ef93:	sub    r9,rdx
  40ef96:	mov    rax,r8
  40ef99:	lock cmpxchg QWORD PTR [rcx],r9
  40ef9e:	cmp    rax,r8
  40efa1:	je     40efa8 <__swc_fn_fc36583a_000068_7d4c42bf+0x2a8>
  40efa3:	mov    r8,rax
  40efa6:	jmp    40ef90 <__swc_fn_fc36583a_000068_7d4c42bf+0x290>
  40efa8:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40efb1:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40efba:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40efc3:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40efcc:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40efd5:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40efde:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40efe7:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40eff0:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40eff9:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40f002:	add    rsp,0x190
  40f009:	pop    r14
  40f00b:	pop    r13
  40f00d:	pop    rsi
  40f00e:	pop    rdi
  40f00f:	pop    r12
  40f011:	ret
	...

000000000040f020 <__swc_fn_fc36583a_000071_0d1ef36f>:
  40f020:	sub    rsp,0x8
  40f024:	mov    QWORD PTR [rdx+0x40],0x0
  40f02c:	call   40c090 <__swc_fn_fc36583a_000064_b0d63361>
  40f031:	add    rsp,0x8
  40f035:	ret
	...

000000000040f040 <__swc_fn_fc36583a_000074_518516c2>:
  40f040:	sub    rsp,0x8
  40f044:	call   407f90 <__swc_fn_fc36583a_000066_254b71af>
  40f049:	add    rsp,0x8
  40f04d:	ret
	...

000000000040f050 <__swc_fn_fc36583a_000077_8b8614a7>:
  40f050:	push   rbx
  40f051:	push   rsi
  40f052:	push   rdi
  40f053:	push   r12
  40f055:	push   r13
  40f057:	push   r14
  40f059:	push   r15
  40f05b:	sub    rsp,0x20
  40f05f:	mov    rbx,r11
  40f062:	mov    rsi,rcx
  40f065:	mov    rdi,rdx
  40f068:	mov    r12,r8
  40f06b:	mov    r13,r9
  40f06e:	mov    r14,r10
  40f071:	mov    rcx,QWORD PTR [rip+0x17cc8]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40f078:	test   rcx,rcx
  40f07b:	jne    40f08d <__swc_fn_fc36583a_000077_8b8614a7+0x3d>
  40f07d:	call   40a1d0 <__swc_fn_fc36583a_000165_cf398896>
  40f082:	lea    rcx,[rax+0x1]
  40f086:	mov    QWORD PTR [rip+0x17cb3],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40f08d:	dec    rcx
  40f090:	call   411fc0 <__swc_fn_fc36583a_000167_fce60b2b>
  40f095:	mov    r15,rax
  40f098:	lea    r11,[rip+0x151a1]        # 424240 <__swc_bss_base_fc36583a+0x200>
  40f09f:	mov    rcx,r11
  40f0a2:	call   407740 <__swc_fn_fc36583a_000036_8d895ba1>
  40f0a7:	test   al,al
  40f0a9:	jne    40f0ba <__swc_fn_fc36583a_000077_8b8614a7+0x6a>
  40f0ab:	mov    rcx,r11
  40f0ae:	call   40b240 <__swc_fn_fc36583a_000034_25f19556>
  40f0b3:	lea    r11,[rip+0x15186]        # 424240 <__swc_bss_base_fc36583a+0x200>
  40f0ba:	mov    rcx,r11
  40f0bd:	mov    rdx,rsi
  40f0c0:	mov    r8,rdi
  40f0c3:	mov    r9,r12
  40f0c6:	mov    r10,r13
  40f0c9:	mov    rsi,r11
  40f0cc:	mov    r11,r14
  40f0cf:	call   40e370 <__swc_fn_fc36583a_000035_95622a2b>
  40f0d4:	test   bl,bl
  40f0d6:	je     40f0fd <__swc_fn_fc36583a_000077_8b8614a7+0xad>
  40f0d8:	mov    QWORD PTR [rsp+0x8],rsi
  40f0dd:	lea    rax,[rip+0x406c]        # 413150 <__swc_rdata_base_fc36583a+0x40>
  40f0e4:	mov    QWORD PTR [rsp+0x10],rax
  40f0e9:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f0ef:	vmovups XMMWORD PTR [r15],xmm0
  40f0f4:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40f0fd:	mov    rax,rsi
  40f100:	add    rsp,0x20
  40f104:	pop    r15
  40f106:	pop    r14
  40f108:	pop    r13
  40f10a:	pop    r12
  40f10c:	pop    rdi
  40f10d:	pop    rsi
  40f10e:	pop    rbx
  40f10f:	ret

000000000040f110 <__swc_fn_fc36583a_000080_c1514492>:
  40f110:	sub    rsp,0x8
  40f114:	mov    rax,rcx
  40f117:	test   rcx,rcx
  40f11a:	jne    40f121 <__swc_fn_fc36583a_000080_c1514492+0x11>
  40f11c:	add    rsp,0x8
  40f120:	ret
  40f121:	lea    rcx,[rax-0x10]
  40f125:	mov    rax,QWORD PTR [rax-0x10]
  40f129:	mov    rdx,rax
  40f12c:	call   4101a0 <__swc_fn_fc36583a_000113_49b378a9>
  40f131:	add    rsp,0x8
  40f135:	ret
	...

000000000040f140 <__swc_fn_fc36583a_000083_31b501f2>:
  40f140:	sub    rsp,0x8
  40f144:	xor    r11d,r11d
  40f147:	call   408250 <__swc_fn_fc36583a_000084_ddf2b8a1>
  40f14c:	add    rsp,0x8
  40f150:	ret
	...

000000000040f160 <__swc_fn_fc36583a_000086_c45095aa>:
  40f160:	push   rsi
  40f161:	push   rdi
  40f162:	push   r12
  40f164:	push   r13
  40f166:	push   r14
  40f168:	push   r15
  40f16a:	sub    rsp,0x68
  40f16e:	mov    rsi,r9
  40f171:	mov    rdi,rcx
  40f174:	mov    r12,rdx
  40f177:	mov    r13,r8
  40f17a:	cmp    r8,r9
  40f17d:	jne    40f1a5 <__swc_fn_fc36583a_000086_c45095aa+0x45>
  40f17f:	mov    rcx,rdi
  40f182:	mov    rdx,r12
  40f185:	xor    r8d,r8d
  40f188:	call   4085a0 <__swc_fn_fc36583a_000090_a2d50c23>
  40f18d:	test   al,al
  40f18f:	je     40f1a5 <__swc_fn_fc36583a_000086_c45095aa+0x45>
  40f191:	mov    eax,0x1
  40f196:	add    rsp,0x68
  40f19a:	pop    r15
  40f19c:	pop    r14
  40f19e:	pop    r13
  40f1a0:	pop    r12
  40f1a2:	pop    rdi
  40f1a3:	pop    rsi
  40f1a4:	ret
  40f1a5:	cmp    BYTE PTR [r12+0x2c],0xe
  40f1ab:	je     40f1be <__swc_fn_fc36583a_000086_c45095aa+0x5e>
  40f1ad:	xor    eax,eax
  40f1af:	add    rsp,0x68
  40f1b3:	pop    r15
  40f1b5:	pop    r14
  40f1b7:	pop    r13
  40f1b9:	pop    r12
  40f1bb:	pop    rdi
  40f1bc:	pop    rsi
  40f1bd:	ret
  40f1be:	mov    r14,QWORD PTR [r12+0x98]
  40f1c6:	mov    rax,QWORD PTR [r12+0xa0]
  40f1ce:	mov    r12,rax
  40f1d1:	xor    r15d,r15d
  40f1d4:	test   r12,r12
  40f1d7:	je     40f23f <__swc_fn_fc36583a_000086_c45095aa+0xdf>
  40f1d9:	nop    DWORD PTR [rax+0x0]
  40f1e0:	mov    QWORD PTR [rsp+0x58],r12
  40f1e5:	lea    r12,[r15*8+0x0]
  40f1ed:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40f1f2:	mov    rcx,rax
  40f1f5:	call   40c820 <__swc_fn_fc36583a_000082_754dcd57>
  40f1fa:	cmp    BYTE PTR [rax+0x2c],0xe
  40f1fe:	jne    40f230 <__swc_fn_fc36583a_000086_c45095aa+0xd0>
  40f200:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40f205:	lea    r8,[r13+rcx*1+0x0]
  40f20a:	mov    rcx,rdi
  40f20d:	mov    rdx,rax
  40f210:	mov    r9,rsi
  40f213:	call   40f160 <__swc_fn_fc36583a_000086_c45095aa>
  40f218:	test   al,al
  40f21a:	je     40f230 <__swc_fn_fc36583a_000086_c45095aa+0xd0>
  40f21c:	mov    eax,0x1
  40f221:	add    rsp,0x68
  40f225:	pop    r15
  40f227:	pop    r14
  40f229:	pop    r13
  40f22b:	pop    r12
  40f22d:	pop    rdi
  40f22e:	pop    rsi
  40f22f:	ret
  40f230:	add    r15,0x1
  40f234:	mov    r12,QWORD PTR [rsp+0x58]
  40f239:	sub    r12,0x1
  40f23d:	jne    40f1e0 <__swc_fn_fc36583a_000086_c45095aa+0x80>
  40f23f:	xor    eax,eax
  40f241:	add    rsp,0x68
  40f245:	pop    r15
  40f247:	pop    r14
  40f249:	pop    r13
  40f24b:	pop    r12
  40f24d:	pop    rdi
  40f24e:	pop    rsi
  40f24f:	ret

000000000040f250 <__swc_fn_fc36583a_000089_386582f3>:
  40f250:	push   rbp
  40f251:	push   rbx
  40f252:	push   rsi
  40f253:	push   rdi
  40f254:	push   r12
  40f256:	push   r13
  40f258:	push   r14
  40f25a:	push   r15
  40f25c:	sub    rsp,0x38
  40f260:	mov    rbp,rsp
  40f263:	mov    rbx,r11
  40f266:	mov    rsi,rdx
  40f269:	mov    rdi,r8
  40f26c:	mov    r12,r9
  40f26f:	mov    QWORD PTR [rsp+0x18],r9
  40f274:	mov    r13,r10
  40f277:	movzx  r14d,BYTE PTR [rbp+0x80]
  40f27f:	movzx  r15d,BYTE PTR [rbp+0x88]
  40f287:	test   r11,r11
  40f28a:	je     40f290 <__swc_fn_fc36583a_000089_386582f3+0x40>
  40f28c:	xor    eax,eax
  40f28e:	mov    BYTE PTR [rbx],al
  40f290:	test   r12,r12
  40f293:	je     40f29e <__swc_fn_fc36583a_000089_386582f3+0x4e>
  40f295:	mov    QWORD PTR [r12+0x8],0x0
  40f29e:	test   rcx,rcx
  40f2a1:	je     40f2a8 <__swc_fn_fc36583a_000089_386582f3+0x58>
  40f2a3:	test   rsi,rsi
  40f2a6:	jne    40f2bb <__swc_fn_fc36583a_000089_386582f3+0x6b>
  40f2a8:	xor    eax,eax
  40f2aa:	add    rsp,0x38
  40f2ae:	pop    r15
  40f2b0:	pop    r14
  40f2b2:	pop    r13
  40f2b4:	pop    r12
  40f2b6:	pop    rdi
  40f2b7:	pop    rsi
  40f2b8:	pop    rbx
  40f2b9:	pop    rbp
  40f2ba:	ret
  40f2bb:	call   40c820 <__swc_fn_fc36583a_000082_754dcd57>
  40f2c0:	mov    r12,rax
  40f2c3:	mov    al,r15b
  40f2c6:	test   r15b,r15b
  40f2c9:	jne    40f2d9 <__swc_fn_fc36583a_000089_386582f3+0x89>
  40f2cb:	mov    eax,DWORD PTR [r12+0x28]
  40f2d0:	and    eax,0x10000
  40f2d6:	setne  al
  40f2d9:	lea    r15,[rsp+0x8]
  40f2de:	mov    QWORD PTR [rsp+0x20],r15
  40f2e3:	rex mov BYTE PTR [rsp+0x8],al
  40f2e8:	test   DWORD PTR [rsi+0x28],0x400000
  40f2ef:	je     40f327 <__swc_fn_fc36583a_000089_386582f3+0xd7>
  40f2f1:	test   rsi,rsi
  40f2f4:	je     40f314 <__swc_fn_fc36583a_000089_386582f3+0xc4>
  40f2f6:	mov    rax,QWORD PTR [rsi+0x38]
  40f2fa:	cmp    QWORD PTR [rax+0x10],rsi
  40f2fe:	jne    40f314 <__swc_fn_fc36583a_000089_386582f3+0xc4>
  40f300:	rex mov al,BYTE PTR [rsp+0x8]
  40f305:	test   al,al
  40f307:	sete   al
  40f30a:	test   r14b,r14b
  40f30d:	sete   cl
  40f310:	test   al,cl
  40f312:	je     40f327 <__swc_fn_fc36583a_000089_386582f3+0xd7>
  40f314:	xor    eax,eax
  40f316:	add    rsp,0x38
  40f31a:	pop    r15
  40f31c:	pop    r14
  40f31e:	pop    r13
  40f320:	pop    r12
  40f322:	pop    rdi
  40f323:	pop    rsi
  40f324:	pop    rbx
  40f325:	pop    rbp
  40f326:	ret
  40f327:	mov    r15,r12
  40f32a:	test   r14b,r14b
  40f32d:	jne    40f344 <__swc_fn_fc36583a_000089_386582f3+0xf4>
  40f32f:	cmp    BYTE PTR [r12+0x2c],0x6
  40f335:	jne    40f344 <__swc_fn_fc36583a_000089_386582f3+0xf4>
  40f337:	mov    rcx,QWORD PTR [r12+0x40]
  40f33c:	call   40c820 <__swc_fn_fc36583a_000082_754dcd57>
  40f341:	mov    r15,rax
  40f344:	test   r14b,r14b
  40f347:	je     40f34d <__swc_fn_fc36583a_000089_386582f3+0xfd>
  40f349:	mov    r15,QWORD PTR [r15+0x30]
  40f34d:	mov    rcx,rsi
  40f350:	call   40c820 <__swc_fn_fc36583a_000082_754dcd57>
  40f355:	mov    rsi,rax
  40f358:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f35d:	je     40f394 <__swc_fn_fc36583a_000089_386582f3+0x144>
  40f35f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f364:	je     40f394 <__swc_fn_fc36583a_000089_386582f3+0x144>
  40f366:	mov    eax,DWORD PTR [rsi+0x28]
  40f369:	and    eax,0x10000
  40f36f:	je     40f394 <__swc_fn_fc36583a_000089_386582f3+0x144>
  40f371:	rex mov al,BYTE PTR [rsp+0x8]
  40f376:	test   al,al
  40f378:	jne    40f38d <__swc_fn_fc36583a_000089_386582f3+0x13d>
  40f37a:	xor    eax,eax
  40f37c:	add    rsp,0x38
  40f380:	pop    r15
  40f382:	pop    r14
  40f384:	pop    r13
  40f386:	pop    r12
  40f388:	pop    rdi
  40f389:	pop    rsi
  40f38a:	pop    rbx
  40f38b:	pop    rbp
  40f38c:	ret
  40f38d:	mov    rax,QWORD PTR [rsi+0x30]
  40f391:	mov    rsi,rax
  40f394:	mov    r14b,r13b
  40f397:	test   rbx,rbx
  40f39a:	je     40f3d0 <__swc_fn_fc36583a_000089_386582f3+0x180>
  40f39c:	cmp    BYTE PTR [r12+0x2c],0x6
  40f3a2:	jne    40f3d0 <__swc_fn_fc36583a_000089_386582f3+0x180>
  40f3a4:	lea    rdx,[rip+0x3dd5]        # 413180 <__swc_rdata_base_fc36583a+0x70>
  40f3ab:	mov    rcx,rsi
  40f3ae:	xor    r8d,r8d
  40f3b1:	call   4085a0 <__swc_fn_fc36583a_000090_a2d50c23>
  40f3b6:	test   al,al
  40f3b8:	je     40f3d0 <__swc_fn_fc36583a_000089_386582f3+0x180>
  40f3ba:	mov    BYTE PTR [rbx],0x1
  40f3bd:	xor    eax,eax
  40f3bf:	add    rsp,0x38
  40f3c3:	pop    r15
  40f3c5:	pop    r14
  40f3c7:	pop    r13
  40f3c9:	pop    r12
  40f3cb:	pop    rdi
  40f3cc:	pop    rsi
  40f3cd:	pop    rbx
  40f3ce:	pop    rbp
  40f3cf:	ret
  40f3d0:	test   rdi,rdi
  40f3d3:	jne    40f3ed <__swc_fn_fc36583a_000089_386582f3+0x19d>
  40f3d5:	test   r13b,r13b
  40f3d8:	jne    40f3ed <__swc_fn_fc36583a_000089_386582f3+0x19d>
  40f3da:	xor    eax,eax
  40f3dc:	add    rsp,0x38
  40f3e0:	pop    r15
  40f3e2:	pop    r14
  40f3e4:	pop    r13
  40f3e6:	pop    r12
  40f3e8:	pop    rdi
  40f3e9:	pop    rsi
  40f3ea:	pop    rbx
  40f3eb:	pop    rbp
  40f3ec:	ret
  40f3ed:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f3f2:	jne    40f4a8 <__swc_fn_fc36583a_000089_386582f3+0x258>
  40f3f8:	mov    rcx,r15
  40f3fb:	mov    rdx,rsi
  40f3fe:	xor    r8d,r8d
  40f401:	call   4085a0 <__swc_fn_fc36583a_000090_a2d50c23>
  40f406:	test   al,al
  40f408:	jne    40f4a8 <__swc_fn_fc36583a_000089_386582f3+0x258>
  40f40e:	test   DWORD PTR [rsi+0x28],0x10000
  40f415:	je     40f433 <__swc_fn_fc36583a_000089_386582f3+0x1e3>
  40f417:	rex mov al,BYTE PTR [rsp+0x8]
  40f41c:	test   al,al
  40f41e:	jne    40f433 <__swc_fn_fc36583a_000089_386582f3+0x1e3>
  40f420:	xor    eax,eax
  40f422:	add    rsp,0x38
  40f426:	pop    r15
  40f428:	pop    r14
  40f42a:	pop    r13
  40f42c:	pop    r12
  40f42e:	pop    rdi
  40f42f:	pop    rsi
  40f430:	pop    rbx
  40f431:	pop    rbp
  40f432:	ret
  40f433:	test   rdi,rdi
  40f436:	jne    40f44b <__swc_fn_fc36583a_000089_386582f3+0x1fb>
  40f438:	xor    eax,eax
  40f43a:	add    rsp,0x38
  40f43e:	pop    r15
  40f440:	pop    r14
  40f442:	pop    r13
  40f444:	pop    r12
  40f446:	pop    rdi
  40f447:	pop    rsi
  40f448:	pop    rbx
  40f449:	pop    rbp
  40f44a:	ret
  40f44b:	mov    rcx,QWORD PTR [rsi+0x40]
  40f44f:	call   40c820 <__swc_fn_fc36583a_000082_754dcd57>
  40f454:	mov    rsi,rax
  40f457:	mov    rax,QWORD PTR [rdi]
  40f45a:	mov    rdi,rax
  40f45d:	test   rax,rax
  40f460:	jne    40f4a3 <__swc_fn_fc36583a_000089_386582f3+0x253>
  40f462:	test   rbx,rbx
  40f465:	je     40f4a3 <__swc_fn_fc36583a_000089_386582f3+0x253>
  40f467:	mov    rcx,r15
  40f46a:	mov    rdx,rsi
  40f46d:	xor    r8d,r8d
  40f470:	call   4085a0 <__swc_fn_fc36583a_000090_a2d50c23>
  40f475:	mov    rcx,rax
  40f478:	test   al,al
  40f47a:	jne    40f49c <__swc_fn_fc36583a_000089_386582f3+0x24c>
  40f47c:	mov    rcx,r15
  40f47f:	mov    rdx,rsi
  40f482:	call   40c860 <__swc_fn_fc36583a_000085_1edf7c76>
  40f487:	mov    rcx,rax
  40f48a:	test   al,al
  40f48c:	jne    40f49c <__swc_fn_fc36583a_000089_386582f3+0x24c>
  40f48e:	mov    rcx,rsi
  40f491:	mov    rdx,r15
  40f494:	call   40c860 <__swc_fn_fc36583a_000085_1edf7c76>
  40f499:	mov    rcx,rax
  40f49c:	test   cl,cl
  40f49e:	setne  al
  40f4a1:	mov    BYTE PTR [rbx],al
  40f4a3:	xor    eax,eax
  40f4a5:	mov    r14b,al
  40f4a8:	test   rdi,rdi
  40f4ab:	jne    40f4c5 <__swc_fn_fc36583a_000089_386582f3+0x275>
  40f4ad:	test   r14b,r14b
  40f4b0:	jne    40f4c5 <__swc_fn_fc36583a_000089_386582f3+0x275>
  40f4b2:	xor    eax,eax
  40f4b4:	add    rsp,0x38
  40f4b8:	pop    r15
  40f4ba:	pop    r14
  40f4bc:	pop    r13
  40f4be:	pop    r12
  40f4c0:	pop    rdi
  40f4c1:	pop    rsi
  40f4c2:	pop    rbx
  40f4c3:	pop    rbp
  40f4c4:	ret
  40f4c5:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f4ca:	je     40f4d6 <__swc_fn_fc36583a_000089_386582f3+0x286>
  40f4cc:	mov    r12,QWORD PTR [rsp+0x18]
  40f4d1:	jmp    40f55e <__swc_fn_fc36583a_000089_386582f3+0x30e>
  40f4d6:	mov    r12,QWORD PTR [rsp+0x18]
  40f4db:	test   r12,r12
  40f4de:	jne    40f4f2 <__swc_fn_fc36583a_000089_386582f3+0x2a2>
  40f4e0:	mov    rcx,r15
  40f4e3:	mov    rdx,rsi
  40f4e6:	xor    r8d,r8d
  40f4e9:	call   4085a0 <__swc_fn_fc36583a_000090_a2d50c23>
  40f4ee:	test   al,al
  40f4f0:	jne    40f55e <__swc_fn_fc36583a_000089_386582f3+0x30e>
  40f4f2:	test   DWORD PTR [rsi+0x28],0x10000
  40f4f9:	je     40f517 <__swc_fn_fc36583a_000089_386582f3+0x2c7>
  40f4fb:	rex mov al,BYTE PTR [rsp+0x8]
  40f500:	test   al,al
  40f502:	jne    40f517 <__swc_fn_fc36583a_000089_386582f3+0x2c7>
  40f504:	xor    eax,eax
  40f506:	add    rsp,0x38
  40f50a:	pop    r15
  40f50c:	pop    r14
  40f50e:	pop    r13
  40f510:	pop    r12
  40f512:	pop    rdi
  40f513:	pop    rsi
  40f514:	pop    rbx
  40f515:	pop    rbp
  40f516:	ret
  40f517:	test   rdi,rdi
  40f51a:	jne    40f52f <__swc_fn_fc36583a_000089_386582f3+0x2df>
  40f51c:	xor    eax,eax
  40f51e:	add    rsp,0x38
  40f522:	pop    r15
  40f524:	pop    r14
  40f526:	pop    r13
  40f528:	pop    r12
  40f52a:	pop    rdi
  40f52b:	pop    rsi
  40f52c:	pop    rbx
  40f52d:	pop    rbp
  40f52e:	ret
  40f52f:	cmp    QWORD PTR [rdi+0x8],0x0
  40f534:	jne    40f549 <__swc_fn_fc36583a_000089_386582f3+0x2f9>
  40f536:	xor    eax,eax
  40f538:	add    rsp,0x38
  40f53c:	pop    r15
  40f53e:	pop    r14
  40f540:	pop    r13
  40f542:	pop    r12
  40f544:	pop    rdi
  40f545:	pop    rsi
  40f546:	pop    rbx
  40f547:	pop    rbp
  40f548:	ret
  40f549:	mov    rax,QWORD PTR [rdi+0x8]
  40f54d:	mov    rax,QWORD PTR [rax]
  40f550:	mov    rsi,rax
  40f553:	mov    rdi,QWORD PTR [rdi]
  40f556:	mov    eax,0x1
  40f55b:	mov    r14b,al
  40f55e:	test   rdi,rdi
  40f561:	mov    rbx,QWORD PTR [rsp+0x20]
  40f566:	jne    40f5b0 <__swc_fn_fc36583a_000089_386582f3+0x360>
  40f568:	test   r14b,r14b
  40f56b:	je     40f59d <__swc_fn_fc36583a_000089_386582f3+0x34d>
  40f56d:	test   r12,r12
  40f570:	je     40f59d <__swc_fn_fc36583a_000089_386582f3+0x34d>
  40f572:	mov    rcx,r15
  40f575:	mov    rdx,rsi
  40f578:	xor    r8d,r8d
  40f57b:	mov    r9,r12
  40f57e:	mov    rbx,QWORD PTR [rsp+0x20]
  40f583:	movzx  r10d,BYTE PTR [rbx]
  40f587:	call   40f140 <__swc_fn_fc36583a_000083_31b501f2>
  40f58c:	add    rsp,0x38
  40f590:	pop    r15
  40f592:	pop    r14
  40f594:	pop    r13
  40f596:	pop    r12
  40f598:	pop    rdi
  40f599:	pop    rsi
  40f59a:	pop    rbx
  40f59b:	pop    rbp
  40f59c:	ret
  40f59d:	xor    eax,eax
  40f59f:	add    rsp,0x38
  40f5a3:	pop    r15
  40f5a5:	pop    r14
  40f5a7:	pop    r13
  40f5a9:	pop    r12
  40f5ab:	pop    rdi
  40f5ac:	pop    rsi
  40f5ad:	pop    rbx
  40f5ae:	pop    rbp
  40f5af:	ret
  40f5b0:	mov    r13,rsi
  40f5b3:	mov    QWORD PTR [rsp+0x28],rdi
  40f5b8:	cmp    BYTE PTR [r15+0x2c],0xe
  40f5bd:	sete   al
  40f5c0:	mov    r14b,al
  40f5c3:	jne    40f5d7 <__swc_fn_fc36583a_000089_386582f3+0x387>
  40f5c5:	mov    rcx,rsi
  40f5c8:	mov    rdx,r15
  40f5cb:	call   40c860 <__swc_fn_fc36583a_000085_1edf7c76>
  40f5d0:	mov    r14b,al
  40f5d3:	test   al,al
  40f5d5:	jne    40f60c <__swc_fn_fc36583a_000089_386582f3+0x3bc>
  40f5d7:	cmp    BYTE PTR [r15+0x2c],0x12
  40f5dc:	je     40f60c <__swc_fn_fc36583a_000089_386582f3+0x3bc>
  40f5de:	mov    rcx,r15
  40f5e1:	mov    rdx,rsi
  40f5e4:	mov    r8,rdi
  40f5e7:	mov    r9,r12
  40f5ea:	mov    rax,rbx
  40f5ed:	movzx  r10d,BYTE PTR [rax]
  40f5f1:	call   40f140 <__swc_fn_fc36583a_000083_31b501f2>
  40f5f6:	test   rax,rax
  40f5f9:	je     40f60c <__swc_fn_fc36583a_000089_386582f3+0x3bc>
  40f5fb:	add    rsp,0x38
  40f5ff:	pop    r15
  40f601:	pop    r14
  40f603:	pop    r13
  40f605:	pop    r12
  40f607:	pop    rdi
  40f608:	pop    rsi
  40f609:	pop    rbx
  40f60a:	pop    rbp
  40f60b:	ret
  40f60c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40f611:	jne    40f630 <__swc_fn_fc36583a_000089_386582f3+0x3e0>
  40f613:	mov    rax,QWORD PTR [rsi+0xd8]
  40f61a:	test   rax,rax
  40f61d:	je     40f630 <__swc_fn_fc36583a_000089_386582f3+0x3e0>
  40f61f:	add    rdi,QWORD PTR [rax+0x8]
  40f623:	mov    rax,QWORD PTR [rdi]
  40f626:	sub    rdi,QWORD PTR [rax+0x8]
  40f62a:	mov    rax,QWORD PTR [rax]
  40f62d:	mov    rsi,rax
  40f630:	test   r14b,r14b
  40f633:	je     40f65f <__swc_fn_fc36583a_000089_386582f3+0x40f>
  40f635:	mov    rcx,r15
  40f638:	mov    rdx,rsi
  40f63b:	mov    r8,rdi
  40f63e:	mov    r9,r13
  40f641:	mov    r14,QWORD PTR [rsp+0x28]
  40f646:	mov    r10,r14
  40f649:	call   408480 <__swc_fn_fc36583a_000087_ea575bb3>
  40f64e:	add    rsp,0x38
  40f652:	pop    r15
  40f654:	pop    r14
  40f656:	pop    r13
  40f658:	pop    r12
  40f65a:	pop    rdi
  40f65b:	pop    rsi
  40f65c:	pop    rbx
  40f65d:	pop    rbp
  40f65e:	ret
  40f65f:	mov    rcx,r15
  40f662:	mov    rdx,rsi
  40f665:	mov    r8,rdi
  40f668:	mov    r9,r12
  40f66b:	movzx  r10d,BYTE PTR [rbx]
  40f66f:	call   40f140 <__swc_fn_fc36583a_000083_31b501f2>
  40f674:	add    rsp,0x38
  40f678:	pop    r15
  40f67a:	pop    r14
  40f67c:	pop    r13
  40f67e:	pop    r12
  40f680:	pop    rdi
  40f681:	pop    rsi
  40f682:	pop    rbx
  40f683:	pop    rbp
  40f684:	ret
	...

000000000040f690 <__swc_fn_fc36583a_000092_8252f8c0>:
  40f690:	push   rbx
  40f691:	push   rsi
  40f692:	sub    rsp,0x18
  40f696:	mov    rbx,rcx
  40f699:	mov    rcx,QWORD PTR [rip+0x176a0]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40f6a0:	test   rcx,rcx
  40f6a3:	jne    40f6b5 <__swc_fn_fc36583a_000092_8252f8c0+0x25>
  40f6a5:	call   40a1d0 <__swc_fn_fc36583a_000165_cf398896>
  40f6aa:	lea    rcx,[rax+0x1]
  40f6ae:	mov    QWORD PTR [rip+0x1768b],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40f6b5:	dec    rcx
  40f6b8:	call   411fc0 <__swc_fn_fc36583a_000167_fce60b2b>
  40f6bd:	mov    rsi,rax
  40f6c0:	mov    rax,QWORD PTR [rsi+0x8]
  40f6c4:	test   rax,rax
  40f6c7:	jne    40f717 <__swc_fn_fc36583a_000092_8252f8c0+0x87>
  40f6c9:	call   40c950 <__swc_fn_fc36583a_000091_3d2f5a0d>
  40f6ce:	test   al,al
  40f6d0:	jne    40f717 <__swc_fn_fc36583a_000092_8252f8c0+0x87>
  40f6d2:	lea    rdx,[rip+0x14b67]        # 424240 <__swc_bss_base_fc36583a+0x200>
  40f6d9:	mov    rcx,rdx
  40f6dc:	call   407740 <__swc_fn_fc36583a_000036_8d895ba1>
  40f6e1:	test   al,al
  40f6e3:	jne    40f6f4 <__swc_fn_fc36583a_000092_8252f8c0+0x64>
  40f6e5:	mov    rcx,rdx
  40f6e8:	call   40b240 <__swc_fn_fc36583a_000034_25f19556>
  40f6ed:	lea    rdx,[rip+0x14b4c]        # 424240 <__swc_bss_base_fc36583a+0x200>
  40f6f4:	mov    QWORD PTR [rsp+0x8],rdx
  40f6f9:	lea    rax,[rip+0x3a50]        # 413150 <__swc_rdata_base_fc36583a+0x40>
  40f700:	mov    QWORD PTR [rsp+0x10],rax
  40f705:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f70b:	vmovups XMMWORD PTR [rsi],xmm0
  40f70f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40f717:	vmovups xmm0,XMMWORD PTR [rsi]
  40f71b:	vmovups XMMWORD PTR [rbx],xmm0
  40f71f:	mov    rax,rbx
  40f722:	add    rsp,0x18
  40f726:	pop    rsi
  40f727:	pop    rbx
  40f728:	ret
  40f729:	add    BYTE PTR [rax],al
  40f72b:	add    BYTE PTR [rax],al
  40f72d:	add    BYTE PTR [rax],al
	...

000000000040f730 <__swc_fn_fc36583a_000095_337e587a>:
  40f730:	sub    rsp,0x8
  40f734:	call   409360 <__swc_fn_fc36583a_000117_86a7fb9e>
  40f739:	add    rsp,0x8
  40f73d:	ret
	...

000000000040f740 <__swc_fn_fc36583a_000098_00f01091>:
  40f740:	push   rbx
  40f741:	push   rsi
  40f742:	sub    rsp,0x28
  40f746:	mov    rbx,rcx
  40f749:	xor    esi,esi
  40f74b:	jmp    40f760 <__swc_fn_fc36583a_000098_00f01091+0x20>
  40f74d:	nop    DWORD PTR [rax]
  40f750:	mov    QWORD PTR [rbx+0x28],rsi
  40f754:	mov    rsi,rbx
  40f757:	mov    rbx,rax
  40f75a:	nop    WORD PTR [rax+rax*1+0x0]
  40f760:	test   rbx,rbx
  40f763:	je     40f7c3 <__swc_fn_fc36583a_000098_00f01091+0x83>
  40f765:	mov    rcx,rbx
  40f768:	mov    edx,0x1
  40f76d:	call   408200 <__swc_fn_fc36583a_000078_a120bd2b>
  40f772:	cmp    rax,0x1
  40f776:	jne    40f7c3 <__swc_fn_fc36583a_000098_00f01091+0x83>
  40f778:	mov    r10,QWORD PTR [rbx+0x18]
  40f77c:	mov    rcx,r10
  40f77f:	mov    edx,0x1
  40f784:	call   408200 <__swc_fn_fc36583a_000078_a120bd2b>
  40f789:	cmp    rax,0x1
  40f78d:	jne    40f79c <__swc_fn_fc36583a_000098_00f01091+0x5c>
  40f78f:	mov    rcx,r10
  40f792:	call   40caf0 <__swc_fn_fc36583a_000097_4c97e0db>
  40f797:	test   rax,rax
  40f79a:	jne    40f750 <__swc_fn_fc36583a_000098_00f01091+0x10>
  40f79c:	mov    rax,QWORD PTR [rbx+0x20]
  40f7a0:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40f7a5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f7ab:	lea    rcx,[rsp+0x8]
  40f7b0:	mov    rdx,rbx
  40f7b3:	mov    r8d,0x30
  40f7b9:	mov    rbx,rax
  40f7bc:	call   408960 <__swc_fn_fc36583a_000096_ad982b35>
  40f7c1:	jmp    40f760 <__swc_fn_fc36583a_000098_00f01091+0x20>
  40f7c3:	test   rsi,rsi
  40f7c6:	jne    40f7cf <__swc_fn_fc36583a_000098_00f01091+0x8f>
  40f7c8:	add    rsp,0x28
  40f7cc:	pop    rsi
  40f7cd:	pop    rbx
  40f7ce:	ret
  40f7cf:	mov    rax,rsi
  40f7d2:	mov    rsi,QWORD PTR [rsi+0x28]
  40f7d6:	mov    rbx,QWORD PTR [rax+0x20]
  40f7da:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40f7df:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f7e5:	lea    rcx,[rsp+0x18]
  40f7ea:	mov    rdx,rax
  40f7ed:	mov    r8d,0x30
  40f7f3:	call   408960 <__swc_fn_fc36583a_000096_ad982b35>
  40f7f8:	jmp    40f760 <__swc_fn_fc36583a_000098_00f01091+0x20>
  40f7fd:	add    BYTE PTR [rax],al
	...

000000000040f800 <__swc_fn_fc36583a_000101_eab3874f>:
  40f800:	push   rbx
  40f801:	push   rsi
  40f802:	push   rdi
  40f803:	push   r12
  40f805:	push   r13
  40f807:	sub    rsp,0x20
  40f80b:	mov    rbx,rcx
  40f80e:	lea    rsi,[rcx+0x6f8]
  40f815:	mov    edi,0x4
  40f81a:	mov    r12,rsi
  40f81d:	test   rdi,rdi
  40f820:	je     40f86a <__swc_fn_fc36583a_000101_eab3874f+0x6a>
  40f822:	cs nop WORD PTR [rax+rax*1+0x0]
  40f82c:	nop    DWORD PTR [rax+0x0]
  40f830:	mov    rcx,QWORD PTR [r12+0x10]
  40f835:	mov    QWORD PTR [r12+0x10],0x0
  40f83e:	vxorps xmm0,xmm0,xmm0
  40f842:	vmovups XMMWORD PTR [r12],xmm0
  40f848:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40f84f:	mov    DWORD PTR [r12+0x20],0x0
  40f858:	call   4089c0 <__swc_fn_fc36583a_000099_b4c6da83>
  40f85d:	add    r12,0x90
  40f864:	sub    rdi,0x1
  40f868:	jne    40f830 <__swc_fn_fc36583a_000101_eab3874f+0x30>
  40f86a:	mov    rax,QWORD PTR [rbx+0x938]
  40f871:	mov    rdi,rax
  40f874:	test   rdi,rdi
  40f877:	je     40f8d1 <__swc_fn_fc36583a_000101_eab3874f+0xd1>
  40f879:	nop    DWORD PTR [rax+0x0]
  40f880:	mov    r12d,0x10
  40f886:	lea    r13,[rdi+0x18]
  40f88a:	test   r12,r12
  40f88d:	je     40f8c6 <__swc_fn_fc36583a_000101_eab3874f+0xc6>
  40f88f:	nop
  40f890:	mov    rcx,QWORD PTR [r13+0x10]
  40f894:	mov    QWORD PTR [r13+0x10],0x0
  40f89c:	vxorps xmm0,xmm0,xmm0
  40f8a0:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40f8a6:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40f8ac:	mov    DWORD PTR [r13+0x20],0x0
  40f8b4:	call   4089c0 <__swc_fn_fc36583a_000099_b4c6da83>
  40f8b9:	add    r13,0x90
  40f8c0:	sub    r12,0x1
  40f8c4:	jne    40f890 <__swc_fn_fc36583a_000101_eab3874f+0x90>
  40f8c6:	mov    rax,QWORD PTR [rdi]
  40f8c9:	mov    rdi,rax
  40f8cc:	test   rax,rax
  40f8cf:	jne    40f880 <__swc_fn_fc36583a_000101_eab3874f+0x80>
  40f8d1:	vxorps xmm0,xmm0,xmm0
  40f8d5:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40f8dd:	mov    DWORD PTR [rbx+0x9b0],0x0
  40f8e7:	mov    DWORD PTR [rbx+0x9a8],0x0
  40f8f1:	mov    edi,0x4
  40f8f6:	mov    r12,rsi
  40f8f9:	lea    rsi,[rsi+0x38]
  40f8fd:	test   rdi,rdi
  40f900:	je     40f92c <__swc_fn_fc36583a_000101_eab3874f+0x12c>
  40f902:	cs nop WORD PTR [rax+rax*1+0x0]
  40f90c:	nop    DWORD PTR [rax+0x0]
  40f910:	mov    rcx,rsi
  40f913:	call   40d980 <__swc_fn_fc36583a_000157_232ffa22>
  40f918:	add    rsi,0x90
  40f91f:	add    r12,0x90
  40f926:	sub    rdi,0x1
  40f92a:	jne    40f910 <__swc_fn_fc36583a_000101_eab3874f+0x110>
  40f92c:	mov    rax,QWORD PTR [rbx+0x938]
  40f933:	mov    rdi,rax
  40f936:	mov    QWORD PTR [rbx+0x938],0x0
  40f941:	test   rdi,rdi
  40f944:	je     40f9b5 <__swc_fn_fc36583a_000101_eab3874f+0x1b5>
  40f94a:	nop    WORD PTR [rax+rax*1+0x0]
  40f950:	mov    esi,0x10
  40f955:	lea    r12,[rdi+0x18]
  40f959:	lea    r13,[rdi+0x50]
  40f95d:	test   rsi,rsi
  40f960:	je     40f98c <__swc_fn_fc36583a_000101_eab3874f+0x18c>
  40f962:	cs nop WORD PTR [rax+rax*1+0x0]
  40f96c:	nop    DWORD PTR [rax+0x0]
  40f970:	mov    rcx,r13
  40f973:	call   40d980 <__swc_fn_fc36583a_000157_232ffa22>
  40f978:	add    r13,0x90
  40f97f:	add    r12,0x90
  40f986:	sub    rsi,0x1
  40f98a:	jne    40f970 <__swc_fn_fc36583a_000101_eab3874f+0x170>
  40f98c:	mov    rax,QWORD PTR [rdi]
  40f98f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40f994:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f99a:	lea    rcx,[rsp+0x8]
  40f99f:	mov    rdx,rdi
  40f9a2:	mov    r8d,0x918
  40f9a8:	mov    rdi,rax
  40f9ab:	call   408960 <__swc_fn_fc36583a_000096_ad982b35>
  40f9b0:	test   rdi,rdi
  40f9b3:	jne    40f950 <__swc_fn_fc36583a_000101_eab3874f+0x150>
  40f9b5:	lea    rcx,[rbx+0x68]
  40f9b9:	call   40d980 <__swc_fn_fc36583a_000157_232ffa22>
  40f9be:	add    rsp,0x20
  40f9c2:	pop    r13
  40f9c4:	pop    r12
  40f9c6:	pop    rdi
  40f9c7:	pop    rsi
  40f9c8:	pop    rbx
  40f9c9:	ret
  40f9ca:	add    BYTE PTR [rax],al
  40f9cc:	add    BYTE PTR [rax],al
	...

000000000040f9d0 <__swc_fn_fc36583a_000104_5589fdbd>:
  40f9d0:	xor    eax,eax
  40f9d2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f9dc:	nop    DWORD PTR [rax+0x0]
  40f9e0:	mov    r9,r8
  40f9e3:	sub    r9,rax
  40f9e6:	cmp    r9,0x40
  40f9ea:	jb     40fa28 <__swc_fn_fc36583a_000104_5589fdbd+0x58>
  40f9ec:	lea    r9,[rcx+rax*1]
  40f9f0:	lea    r10,[rdx+rax*1]
  40f9f4:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40f9fa:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40fa00:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40fa06:	vmovups xmm3,XMMWORD PTR [r10]
  40fa0b:	vmovups XMMWORD PTR [r9],xmm3
  40fa10:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40fa16:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40fa1c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40fa22:	lea    rax,[rax+0x40]
  40fa26:	jmp    40f9e0 <__swc_fn_fc36583a_000104_5589fdbd+0x10>
  40fa28:	nop    DWORD PTR [rax+rax*1+0x0]
  40fa30:	mov    r9,r8
  40fa33:	sub    r9,rax
  40fa36:	cmp    r9,0x10
  40fa3a:	jb     40fa54 <__swc_fn_fc36583a_000104_5589fdbd+0x84>
  40fa3c:	lea    r9,[rdx+rax*1]
  40fa40:	lea    r10,[rcx+rax*1]
  40fa44:	vmovups xmm0,XMMWORD PTR [r9]
  40fa49:	vmovups XMMWORD PTR [r10],xmm0
  40fa4e:	lea    rax,[rax+0x10]
  40fa52:	jmp    40fa30 <__swc_fn_fc36583a_000104_5589fdbd+0x60>
  40fa54:	cs nop WORD PTR [rax+rax*1+0x0]
  40fa5e:	xchg   ax,ax
  40fa60:	mov    r9,r8
  40fa63:	sub    r9,rax
  40fa66:	cmp    r9,0x8
  40fa6a:	jb     40fa7d <__swc_fn_fc36583a_000104_5589fdbd+0xad>
  40fa6c:	lea    r9,[rcx+rax*1]
  40fa70:	mov    r10,QWORD PTR [rdx+rax*1]
  40fa74:	mov    QWORD PTR [r9],r10
  40fa77:	lea    rax,[rax+0x8]
  40fa7b:	jmp    40fa60 <__swc_fn_fc36583a_000104_5589fdbd+0x90>
  40fa7d:	cmp    rax,r8
  40fa80:	jae    40faa0 <__swc_fn_fc36583a_000104_5589fdbd+0xd0>
  40fa82:	cs nop WORD PTR [rax+rax*1+0x0]
  40fa8c:	nop    DWORD PTR [rax+0x0]
  40fa90:	mov    r9b,BYTE PTR [rdx+rax*1]
  40fa94:	mov    BYTE PTR [rcx+rax*1],r9b
  40fa98:	inc    rax
  40fa9b:	cmp    rax,r8
  40fa9e:	jb     40fa90 <__swc_fn_fc36583a_000104_5589fdbd+0xc0>
  40faa0:	ret
	...

000000000040fac0 <__swc_fn_fc36583a_000107_4796e893>:
  40fac0:	push   rbx
  40fac1:	push   r12
  40fac3:	push   rdi
  40fac4:	push   rsi
  40fac5:	push   r13
  40fac7:	push   r14
  40fac9:	push   r15
  40facb:	sub    rsp,0x170
  40fad2:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40fadb:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40fae4:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40faed:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40faf6:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40faff:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40fb08:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40fb11:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40fb1a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40fb23:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40fb2c:	mov    ebx,edx
  40fb2e:	mov    QWORD PTR [rsp+0xa8],rbx
  40fb36:	mov    r12d,ecx
  40fb39:	test   edx,edx
  40fb3b:	jne    40fb52 <__swc_fn_fc36583a_000107_4796e893+0x92>
  40fb3d:	xor    eax,eax
  40fb3f:	add    rsp,0x170
  40fb46:	pop    r15
  40fb48:	pop    r14
  40fb4a:	pop    r13
  40fb4c:	pop    rsi
  40fb4d:	pop    rdi
  40fb4e:	pop    r12
  40fb50:	pop    rbx
  40fb51:	ret
  40fb52:	lea    rdi,[rip+0x3957]        # 4134b0 <__swc_rdata_base_fc36583a+0x3a0>
  40fb59:	mov    esi,0x90000
  40fb5e:	xor    eax,eax
  40fb60:	call   407090 <open@plt>
  40fb65:	mov    r13,rax
  40fb68:	mov    QWORD PTR [rsp+0xb0],rax
  40fb70:	test   eax,eax
  40fb72:	jge    40fb7b <__swc_fn_fc36583a_000107_4796e893+0xbb>
  40fb74:	xor    eax,eax
  40fb76:	jmp    410096 <__swc_fn_fc36583a_000107_4796e893+0x5d6>
  40fb7b:	nop    DWORD PTR [rax+rax*1+0x0]
  40fb80:	movsxd rdi,r13d
  40fb83:	mov    esi,0x2
  40fb88:	xor    eax,eax
  40fb8a:	call   407110 <flock@plt>
  40fb8f:	test   eax,eax
  40fb91:	je     40fbb0 <__swc_fn_fc36583a_000107_4796e893+0xf0>
  40fb93:	xor    eax,eax
  40fb95:	call   407120 <__errno_location@plt>
  40fb9a:	cmp    DWORD PTR [rax],0x4
  40fb9d:	je     40fb80 <__swc_fn_fc36583a_000107_4796e893+0xc0>
  40fb9f:	movsxd rdi,r13d
  40fba2:	xor    eax,eax
  40fba4:	call   4070b0 <close@plt>
  40fba9:	xor    eax,eax
  40fbab:	jmp    410096 <__swc_fn_fc36583a_000107_4796e893+0x5d6>
  40fbb0:	lea    r14,[rsp+0x8]
  40fbb5:	mov    QWORD PTR [rsp+0xb8],r14
  40fbbd:	vxorps xmm0,xmm0,xmm0
  40fbc1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40fbc7:	mov    QWORD PTR [rsp+0x18],0x0
  40fbd0:	mov    WORD PTR [rsp+0x20],0x0
  40fbd7:	mov    DWORD PTR [r14],0x67617753
  40fbde:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40fbe6:	xor    eax,eax
  40fbe8:	call   407010 <getpid@plt>
  40fbed:	mov    ecx,eax
  40fbef:	mov    eax,0x1c
  40fbf4:	shrx   eax,ecx,eax
  40fbf9:	and    eax,0xf
  40fbfc:	mov    rdx,QWORD PTR [rip+0x38cd]        # 4134d0 <__swc_rdata_base_fc36583a+0x3c0>
  40fc03:	mov    al,BYTE PTR [rdx+rax*1]
  40fc06:	rex mov BYTE PTR [rsp+0x10],al
  40fc0b:	mov    eax,0x1c
  40fc10:	shrx   eax,r12d,eax
  40fc15:	and    eax,0xf
  40fc18:	mov    al,BYTE PTR [rdx+rax*1]
  40fc1b:	rex mov BYTE PTR [rsp+0x19],al
  40fc20:	mov    eax,0x18
  40fc25:	shrx   eax,ecx,eax
  40fc2a:	and    eax,0xf
  40fc2d:	mov    al,BYTE PTR [rdx+rax*1]
  40fc30:	rex mov BYTE PTR [rsp+0x11],al
  40fc35:	mov    eax,0x18
  40fc3a:	shrx   eax,r12d,eax
  40fc3f:	and    eax,0xf
  40fc42:	mov    al,BYTE PTR [rdx+rax*1]
  40fc45:	rex mov BYTE PTR [rsp+0x1a],al
  40fc4a:	mov    eax,0x14
  40fc4f:	shrx   eax,ecx,eax
  40fc54:	and    eax,0xf
  40fc57:	mov    al,BYTE PTR [rdx+rax*1]
  40fc5a:	rex mov BYTE PTR [rsp+0x12],al
  40fc5f:	mov    eax,0x14
  40fc64:	shrx   eax,r12d,eax
  40fc69:	and    eax,0xf
  40fc6c:	mov    al,BYTE PTR [rdx+rax*1]
  40fc6f:	rex mov BYTE PTR [rsp+0x1b],al
  40fc74:	mov    eax,0x10
  40fc79:	shrx   eax,ecx,eax
  40fc7e:	and    eax,0xf
  40fc81:	mov    al,BYTE PTR [rdx+rax*1]
  40fc84:	rex mov BYTE PTR [rsp+0x13],al
  40fc89:	mov    eax,0x10
  40fc8e:	shrx   eax,r12d,eax
  40fc93:	and    eax,0xf
  40fc96:	mov    al,BYTE PTR [rdx+rax*1]
  40fc99:	rex mov BYTE PTR [rsp+0x1c],al
  40fc9e:	mov    eax,0xc
  40fca3:	shrx   eax,ecx,eax
  40fca8:	and    eax,0xf
  40fcab:	mov    al,BYTE PTR [rdx+rax*1]
  40fcae:	rex mov BYTE PTR [rsp+0x14],al
  40fcb3:	mov    eax,0xc
  40fcb8:	shrx   eax,r12d,eax
  40fcbd:	and    eax,0xf
  40fcc0:	mov    al,BYTE PTR [rdx+rax*1]
  40fcc3:	rex mov BYTE PTR [rsp+0x1d],al
  40fcc8:	mov    eax,0x8
  40fccd:	shrx   eax,ecx,eax
  40fcd2:	and    eax,0xf
  40fcd5:	mov    al,BYTE PTR [rdx+rax*1]
  40fcd8:	rex mov BYTE PTR [rsp+0x15],al
  40fcdd:	mov    eax,0x8
  40fce2:	shrx   eax,r12d,eax
  40fce7:	and    eax,0xf
  40fcea:	mov    al,BYTE PTR [rdx+rax*1]
  40fced:	rex mov BYTE PTR [rsp+0x1e],al
  40fcf2:	mov    eax,0x4
  40fcf7:	shrx   eax,ecx,eax
  40fcfc:	and    eax,0xf
  40fcff:	mov    al,BYTE PTR [rdx+rax*1]
  40fd02:	rex mov BYTE PTR [rsp+0x16],al
  40fd07:	mov    eax,0x4
  40fd0c:	shrx   eax,r12d,eax
  40fd11:	and    eax,0xf
  40fd14:	mov    al,BYTE PTR [rdx+rax*1]
  40fd17:	rex mov BYTE PTR [rsp+0x1f],al
  40fd1c:	xor    eax,eax
  40fd1e:	shrx   eax,ecx,eax
  40fd23:	and    eax,0xf
  40fd26:	mov    al,BYTE PTR [rdx+rax*1]
  40fd29:	rex mov BYTE PTR [rsp+0x17],al
  40fd2e:	xor    eax,eax
  40fd30:	shrx   eax,r12d,eax
  40fd35:	and    eax,0xf
  40fd38:	mov    al,BYTE PTR [rdx+rax*1]
  40fd3b:	rex mov BYTE PTR [rsp+0x20],al
  40fd40:	mov    BYTE PTR [r14+0x10],0x2e
  40fd45:	lea    r12,[rsp+0x22]
  40fd4a:	vxorps xmm0,xmm0,xmm0
  40fd4e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40fd54:	mov    DWORD PTR [r12],0x6d656d2f
  40fd5c:	mov    WORD PTR [r12+0x4],0x6466
  40fd64:	mov    BYTE PTR [r12+0x6],0x3a
  40fd6a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40fd70:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40fd76:	mov    rax,QWORD PTR [rsp+0x18]
  40fd7b:	mov    QWORD PTR [rsp+0x39],rax
  40fd80:	rex mov al,BYTE PTR [rsp+0x20]
  40fd85:	rex mov BYTE PTR [rsp+0x41],al
  40fd8a:	mov    DWORD PTR [r12+0x20],0x65642820
  40fd93:	mov    DWORD PTR [r12+0x24],0x6574656c
  40fd9c:	mov    WORD PTR [r12+0x28],0x2964
  40fda4:	lea    rdi,[rip+0x3710]        # 4134bb <__swc_rdata_base_fc36583a+0x3ab>
  40fdab:	xor    eax,eax
  40fdad:	call   407130 <opendir@plt>
  40fdb2:	mov    r15,rax
  40fdb5:	test   rax,rax
  40fdb8:	jne    40fdcb <__swc_fn_fc36583a_000107_4796e893+0x30b>
  40fdba:	movsxd rdi,r13d
  40fdbd:	xor    eax,eax
  40fdbf:	call   4070b0 <close@plt>
  40fdc4:	xor    eax,eax
  40fdc6:	jmp    410096 <__swc_fn_fc36583a_000107_4796e893+0x5d6>
  40fdcb:	mov    rdi,r15
  40fdce:	xor    eax,eax
  40fdd0:	call   407140 <dirfd@plt>
  40fdd5:	lea    r14,[rsp+0x54]
  40fdda:	mov    DWORD PTR [rsp+0x54],eax
  40fdde:	lea    rbx,[rsp+0x58]
  40fde3:	cs nop WORD PTR [rax+rax*1+0x0]
  40fded:	cs nop WORD PTR [rax+rax*1+0x0]
  40fdf7:	nop    WORD PTR [rax+rax*1+0x0]
  40fe00:	mov    rdi,r15
  40fe03:	xor    eax,eax
  40fe05:	call   407150 <readdir@plt>
  40fe0a:	test   rax,rax
  40fe0d:	jne    40fe24 <__swc_fn_fc36583a_000107_4796e893+0x364>
  40fe0f:	mov    r12,QWORD PTR [rsp+0xa8]
  40fe17:	mov    r13,QWORD PTR [rsp+0xb0]
  40fe1f:	jmp    40ffba <__swc_fn_fc36583a_000107_4796e893+0x4fa>
  40fe24:	vxorps xmm0,xmm0,xmm0
  40fe28:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40fe2e:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40fe34:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40fe3a:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40fe43:	lea    r13,[rax+0x13]
  40fe47:	mov    rax,r14
  40fe4a:	movsxd rdi,DWORD PTR [rax]
  40fe4d:	mov    rsi,r13
  40fe50:	mov    rdx,rbx
  40fe53:	mov    ecx,0x40
  40fe58:	xor    eax,eax
  40fe5a:	call   407160 <readlinkat@plt>
  40fe5f:	cmp    rax,0x2a
  40fe63:	jne    40fe00 <__swc_fn_fc36583a_000107_4796e893+0x340>
  40fe65:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40fe6b:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40fe71:	vptest xmm0,xmm0
  40fe76:	jne    40fea6 <__swc_fn_fc36583a_000107_4796e893+0x3e6>
  40fe78:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40fe7e:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40fe84:	vptest xmm0,xmm0
  40fe89:	jne    40fea6 <__swc_fn_fc36583a_000107_4796e893+0x3e6>
  40fe8b:	mov    rcx,QWORD PTR [rsp+0x42]
  40fe90:	cmp    QWORD PTR [rsp+0x78],rcx
  40fe95:	jne    40fea6 <__swc_fn_fc36583a_000107_4796e893+0x3e6>
  40fe97:	mov    cx,WORD PTR [rsp+0x4a]
  40fe9c:	cmp    WORD PTR [rsp+0x80],cx
  40fea4:	je     40fed4 <__swc_fn_fc36583a_000107_4796e893+0x414>
  40fea6:	mov    rax,rbx
  40fea9:	mov    rcx,r12
  40feac:	nop    DWORD PTR [rax+0x0]
  40feb0:	movzx  edx,BYTE PTR [rax]
  40feb3:	movzx  r8d,BYTE PTR [rcx]
  40feb7:	cmp    rdx,r8
  40feba:	jne    40fec6 <__swc_fn_fc36583a_000107_4796e893+0x406>
  40febc:	add    rax,0x1
  40fec0:	add    rcx,0x1
  40fec4:	jmp    40feb0 <__swc_fn_fc36583a_000107_4796e893+0x3f0>
  40fec6:	mov    rax,rdx
  40fec9:	sub    rax,r8
  40fecc:	test   eax,eax
  40fece:	jne    40fe00 <__swc_fn_fc36583a_000107_4796e893+0x340>
  40fed4:	movsxd rdi,DWORD PTR [r14]
  40fed7:	mov    rsi,r13
  40feda:	mov    edx,0x80002
  40fedf:	xor    eax,eax
  40fee1:	call   407170 <openat@plt>
  40fee6:	lea    rbx,[rsp+0x98]
  40feee:	mov    DWORD PTR [rsp+0x98],eax
  40fef5:	test   eax,eax
  40fef7:	mov    r13,QWORD PTR [rsp+0xb0]
  40feff:	jge    40ff24 <__swc_fn_fc36583a_000107_4796e893+0x464>
  40ff01:	mov    rdi,r15
  40ff04:	xor    eax,eax
  40ff06:	call   407180 <closedir@plt>
  40ff0b:	mov    r13,QWORD PTR [rsp+0xb0]
  40ff13:	movsxd rdi,r13d
  40ff16:	xor    eax,eax
  40ff18:	call   4070b0 <close@plt>
  40ff1d:	xor    eax,eax
  40ff1f:	jmp    410096 <__swc_fn_fc36583a_000107_4796e893+0x5d6>
  40ff24:	mov    rax,rbx
  40ff27:	movsxd rdi,DWORD PTR [rax]
  40ff2a:	xor    esi,esi
  40ff2c:	mov    edx,0x2
  40ff31:	xor    eax,eax
  40ff33:	call   4070a0 <lseek@plt>
  40ff38:	mov    r12,QWORD PTR [rsp+0xa8]
  40ff40:	cmp    rax,r12
  40ff43:	je     40ff6a <__swc_fn_fc36583a_000107_4796e893+0x4aa>
  40ff45:	movsxd rdi,DWORD PTR [rbx]
  40ff48:	xor    eax,eax
  40ff4a:	call   4070b0 <close@plt>
  40ff4f:	mov    rdi,r15
  40ff52:	xor    eax,eax
  40ff54:	call   407180 <closedir@plt>
  40ff59:	movsxd rdi,r13d
  40ff5c:	xor    eax,eax
  40ff5e:	call   4070b0 <close@plt>
  40ff63:	xor    eax,eax
  40ff65:	jmp    410096 <__swc_fn_fc36583a_000107_4796e893+0x5d6>
  40ff6a:	xor    edi,edi
  40ff6c:	mov    rsi,r12
  40ff6f:	mov    edx,0x3
  40ff74:	mov    ecx,0x1
  40ff79:	mov    rax,rbx
  40ff7c:	movsxd r8,DWORD PTR [rax]
  40ff7f:	xor    r9d,r9d
  40ff82:	xor    eax,eax
  40ff84:	call   4070c0 <mmap@plt>
  40ff89:	xor    r12d,r12d
  40ff8c:	cmp    rax,0xffffffffffffffff
  40ff90:	cmovne r12,rax
  40ff94:	movsxd rdi,DWORD PTR [rbx]
  40ff97:	xor    eax,eax
  40ff99:	call   4070b0 <close@plt>
  40ff9e:	mov    rdi,r15
  40ffa1:	xor    eax,eax
  40ffa3:	call   407180 <closedir@plt>
  40ffa8:	movsxd rdi,r13d
  40ffab:	xor    eax,eax
  40ffad:	call   4070b0 <close@plt>
  40ffb2:	mov    rax,r12
  40ffb5:	jmp    410096 <__swc_fn_fc36583a_000107_4796e893+0x5d6>
  40ffba:	mov    r14,QWORD PTR [rsp+0xb8]
  40ffc2:	mov    rdi,r14
  40ffc5:	mov    esi,0x1
  40ffca:	xor    eax,eax
  40ffcc:	call   407190 <memfd_create@plt>
  40ffd1:	lea    rbx,[rsp+0x9c]
  40ffd9:	mov    DWORD PTR [rsp+0x9c],eax
  40ffe0:	test   eax,eax
  40ffe2:	jge    40ffff <__swc_fn_fc36583a_000107_4796e893+0x53f>
  40ffe4:	mov    rdi,r15
  40ffe7:	xor    eax,eax
  40ffe9:	call   407180 <closedir@plt>
  40ffee:	movsxd rdi,r13d
  40fff1:	xor    eax,eax
  40fff3:	call   4070b0 <close@plt>
  40fff8:	xor    eax,eax
  40fffa:	jmp    410096 <__swc_fn_fc36583a_000107_4796e893+0x5d6>
  40ffff:	mov    rax,rbx
  410002:	movsxd rdi,DWORD PTR [rax]
  410005:	mov    rsi,r12
  410008:	xor    eax,eax
  41000a:	call   4071a0 <ftruncate@plt>
  41000f:	test   eax,eax
  410011:	je     410035 <__swc_fn_fc36583a_000107_4796e893+0x575>
  410013:	movsxd rdi,DWORD PTR [rbx]
  410016:	xor    eax,eax
  410018:	call   4070b0 <close@plt>
  41001d:	mov    rdi,r15
  410020:	xor    eax,eax
  410022:	call   407180 <closedir@plt>
  410027:	movsxd rdi,r13d
  41002a:	xor    eax,eax
  41002c:	call   4070b0 <close@plt>
  410031:	xor    eax,eax
  410033:	jmp    410096 <__swc_fn_fc36583a_000107_4796e893+0x5d6>
  410035:	xor    edi,edi
  410037:	mov    rsi,r12
  41003a:	mov    edx,0x3
  41003f:	mov    ecx,0x1
  410044:	mov    rax,rbx
  410047:	movsxd r8,DWORD PTR [rax]
  41004a:	xor    r9d,r9d
  41004d:	xor    eax,eax
  41004f:	call   4070c0 <mmap@plt>
  410054:	mov    r12,rax
  410057:	cmp    rax,0xffffffffffffffff
  41005b:	jne    41007f <__swc_fn_fc36583a_000107_4796e893+0x5bf>
  41005d:	movsxd rdi,DWORD PTR [rbx]
  410060:	xor    eax,eax
  410062:	call   4070b0 <close@plt>
  410067:	mov    rdi,r15
  41006a:	xor    eax,eax
  41006c:	call   407180 <closedir@plt>
  410071:	movsxd rdi,r13d
  410074:	xor    eax,eax
  410076:	call   4070b0 <close@plt>
  41007b:	xor    eax,eax
  41007d:	jmp    410096 <__swc_fn_fc36583a_000107_4796e893+0x5d6>
  41007f:	mov    rdi,r15
  410082:	xor    eax,eax
  410084:	call   407180 <closedir@plt>
  410089:	movsxd rdi,r13d
  41008c:	xor    eax,eax
  41008e:	call   4070b0 <close@plt>
  410093:	mov    rax,r12
  410096:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  41009f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  4100a8:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  4100b1:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  4100ba:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  4100c3:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  4100cc:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  4100d5:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  4100de:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  4100e7:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  4100f0:	add    rsp,0x170
  4100f7:	pop    r15
  4100f9:	pop    r14
  4100fb:	pop    r13
  4100fd:	pop    rsi
  4100fe:	pop    rdi
  4100ff:	pop    r12
  410101:	pop    rbx
  410102:	ret
	...

0000000000410110 <__swc_fn_fc36583a_000110_a808fe76>:
  410110:	push   rsi
  410111:	push   rdi
  410112:	push   r12
  410114:	push   r13
  410116:	sub    rsp,0x8
  41011a:	mov    rsi,r8
  41011d:	mov    rdi,rcx
  410120:	mov    r12,rdx
  410123:	call   409120 <__swc_fn_fc36583a_000108_84af7666>
  410128:	mov    r13,rax
  41012b:	test   rax,rax
  41012e:	jne    41013b <__swc_fn_fc36583a_000110_a808fe76+0x2b>
  410130:	add    rsp,0x8
  410134:	pop    r13
  410136:	pop    r12
  410138:	pop    rdi
  410139:	pop    rsi
  41013a:	ret
  41013b:	mov    rcx,r13
  41013e:	call   40d570 <__swc_fn_fc36583a_000133_4b2af8da>
  410143:	mov    rax,QWORD PTR [r13+0x8]
  410147:	test   rax,rax
  41014a:	je     410189 <__swc_fn_fc36583a_000110_a808fe76+0x79>
  41014c:	nop    DWORD PTR [rax+0x0]
  410150:	lea    rcx,[rax+0x1000]
  410157:	cmp    rdi,rcx
  41015a:	jne    410181 <__swc_fn_fc36583a_000110_a808fe76+0x71>
  41015c:	cmp    r12,0x1000
  410163:	jb     410181 <__swc_fn_fc36583a_000110_a808fe76+0x71>
  410165:	test   sil,sil
  410168:	setne  cl
  41016b:	mov    BYTE PTR [rax+0x10],cl
  41016e:	mov    rcx,r13
  410171:	call   410680 <__swc_fn_fc36583a_000134_29412410>
  410176:	add    rsp,0x8
  41017a:	pop    r13
  41017c:	pop    r12
  41017e:	pop    rdi
  41017f:	pop    rsi
  410180:	ret
  410181:	mov    rax,QWORD PTR [rax]
  410184:	test   rax,rax
  410187:	jne    410150 <__swc_fn_fc36583a_000110_a808fe76+0x40>
  410189:	mov    rcx,r13
  41018c:	call   410680 <__swc_fn_fc36583a_000134_29412410>
  410191:	add    rsp,0x8
  410195:	pop    r13
  410197:	pop    r12
  410199:	pop    rdi
  41019a:	pop    rsi
  41019b:	ret
  41019c:	add    BYTE PTR [rax],al
	...

00000000004101a0 <__swc_fn_fc36583a_000113_49b378a9>:
  4101a0:	sub    rsp,0x8
  4101a4:	test   rcx,rcx
  4101a7:	jne    4101ae <__swc_fn_fc36583a_000113_49b378a9+0xe>
  4101a9:	add    rsp,0x8
  4101ad:	ret
  4101ae:	call   40d080 <__swc_fn_fc36583a_000115_1ba33335>
  4101b3:	add    rsp,0x8
  4101b7:	ret
	...

00000000004101c0 <__swc_fn_fc36583a_000116_035d76a1>:
  4101c0:	push   r12
  4101c2:	push   r13
  4101c4:	push   r14
  4101c6:	push   rdi
  4101c7:	push   rsi
  4101c8:	sub    rsp,0xc0
  4101cf:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4101d5:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4101db:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4101e1:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4101e7:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4101ed:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4101f3:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4101f9:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  410202:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  41020b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  410214:	mov    r12,QWORD PTR [rcx]
  410217:	test   r12,r12
  41021a:	jne    41022c <__swc_fn_fc36583a_000116_035d76a1+0x6c>
  41021c:	add    rsp,0xc0
  410223:	pop    rsi
  410224:	pop    rdi
  410225:	pop    r14
  410227:	pop    r13
  410229:	pop    r12
  41022b:	ret
  41022c:	xor    r13d,r13d
  41022f:	mov    r14,QWORD PTR [rcx+0x8]
  410233:	cs nop WORD PTR [rax+rax*1+0x0]
  41023d:	nop    DWORD PTR [rax]
  410240:	cmp    r13,r14
  410243:	jae    41027e <__swc_fn_fc36583a_000116_035d76a1+0xbe>
  410245:	lea    rax,[r12+r13*1]
  410249:	mov    rcx,r14
  41024c:	sub    rcx,r13
  41024f:	mov    edi,0x1
  410254:	mov    rsi,rax
  410257:	mov    rdx,rcx
  41025a:	xor    eax,eax
  41025c:	call   4071b0 <write@plt>
  410261:	test   rax,rax
  410264:	jle    41026b <__swc_fn_fc36583a_000116_035d76a1+0xab>
  410266:	add    r13,rax
  410269:	jmp    410240 <__swc_fn_fc36583a_000116_035d76a1+0x80>
  41026b:	test   rax,rax
  41026e:	je     41027c <__swc_fn_fc36583a_000116_035d76a1+0xbc>
  410270:	xor    eax,eax
  410272:	call   407120 <__errno_location@plt>
  410277:	cmp    DWORD PTR [rax],0x4
  41027a:	je     410240 <__swc_fn_fc36583a_000116_035d76a1+0x80>
  41027c:	jmp    41027e <__swc_fn_fc36583a_000116_035d76a1+0xbe>
  41027e:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410284:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  41028a:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410290:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  410296:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  41029c:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4102a2:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4102a8:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4102b1:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4102ba:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4102c3:	add    rsp,0xc0
  4102ca:	pop    rsi
  4102cb:	pop    rdi
  4102cc:	pop    r14
  4102ce:	pop    r13
  4102d0:	pop    r12
  4102d2:	ret
	...

00000000004102e0 <__swc_fn_fc36583a_000119_9175a56a>:
  4102e0:	push   rbx
  4102e1:	push   r12
  4102e3:	push   rdi
  4102e4:	push   rsi
  4102e5:	sub    rsp,0x4a8
  4102ec:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  4102f5:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  4102fe:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  410307:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  410310:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  410319:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  410322:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  41032b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  410334:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  41033d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  410346:	mov    rbx,rdx
  410349:	mov    r12d,ecx
  41034c:	vxorps xmm0,xmm0,xmm0
  410350:	xor    eax,eax
  410352:	cs nop WORD PTR [rax+rax*1+0x0]
  41035c:	nop    DWORD PTR [rax+0x0]
  410360:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  410366:	add    rax,0x10
  41036a:	cmp    rax,0x400
  410371:	jne    410360 <__swc_fn_fc36583a_000119_9175a56a+0x80>
  410373:	lea    rdi,[rsp+0x8]
  410378:	mov    esi,0x80
  41037d:	xor    eax,eax
  41037f:	call   4071c0 <backtrace@plt>
  410384:	test   eax,eax
  410386:	jle    410395 <__swc_fn_fc36583a_000119_9175a56a+0xb5>
  410388:	movsxd rax,eax
  41038b:	lea    rcx,[r12+0x1]
  410390:	cmp    rcx,rax
  410393:	jb     410399 <__swc_fn_fc36583a_000119_9175a56a+0xb9>
  410395:	xor    eax,eax
  410397:	jmp    4103ca <__swc_fn_fc36583a_000119_9175a56a+0xea>
  410399:	mov    rcx,QWORD PTR [rbx+0x8]
  41039d:	sub    rax,r12
  4103a0:	lea    rsi,[rax-0x1]
  4103a4:	cmp    rcx,rsi
  4103a7:	cmovbe rsi,rcx
  4103ab:	lea    eax,[r12+0x1]
  4103b0:	lea    rax,[rsp+rax*8+0x8]
  4103b5:	mov    rcx,QWORD PTR [rbx]
  4103b8:	mov    rdx,rax
  4103bb:	lea    r8,[rsi*8+0x0]
  4103c3:	call   409100 <__swc_fn_fc36583a_000105_6fd80914>
  4103c8:	mov    eax,esi
  4103ca:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  4103d3:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  4103dc:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  4103e5:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  4103ee:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  4103f7:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  410400:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  410409:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  410412:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  41041b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  410424:	add    rsp,0x4a8
  41042b:	pop    rsi
  41042c:	pop    rdi
  41042d:	pop    r12
  41042f:	pop    rbx
  410430:	ret
	...

0000000000410440 <__swc_fn_fc36583a_000122_e09461fd>:
  410440:	mov    QWORD PTR [rcx],0x0
  410447:	ret
	...

0000000000410450 <__swc_fn_fc36583a_000125_ce762363>:
  410450:	push   rdi
  410451:	push   rsi
  410452:	sub    rsp,0xa8
  410459:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41045f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410465:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41046b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410471:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410477:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41047d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410483:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410489:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410492:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41049b:	mov    edi,ecx
  41049d:	mov    rsi,rdx
  4104a0:	xor    eax,eax
  4104a2:	call   407060 <pthread_setspecific@plt>
  4104a7:	test   eax,eax
  4104a9:	sete   al
  4104ac:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4104b2:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4104b8:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4104be:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4104c4:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4104ca:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4104d0:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4104d6:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4104dc:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4104e5:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4104ee:	add    rsp,0xa8
  4104f5:	pop    rsi
  4104f6:	pop    rdi
  4104f7:	ret
	...

0000000000410500 <__swc_fn_fc36583a_000128_41c3251c>:
  410500:	push   rdi
  410501:	push   rsi
  410502:	sub    rsp,0xa8
  410509:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41050f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410515:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41051b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410521:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410527:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41052d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410533:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410539:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410542:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41054b:	test   rcx,rcx
  41054e:	je     410561 <__swc_fn_fc36583a_000128_41c3251c+0x61>
  410550:	lea    rax,[rcx-0x1]
  410554:	mov    eax,eax
  410556:	mov    edi,eax
  410558:	xor    eax,eax
  41055a:	call   407000 <pthread_getspecific@plt>
  41055f:	jmp    410563 <__swc_fn_fc36583a_000128_41c3251c+0x63>
  410561:	xor    eax,eax
  410563:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410569:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  41056f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410575:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41057b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410581:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410587:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41058d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410593:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41059c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4105a5:	add    rsp,0xa8
  4105ac:	pop    rsi
  4105ad:	pop    rdi
  4105ae:	ret
	...

00000000004105b0 <__swc_fn_fc36583a_000131_944f555b>:
  4105b0:	push   rdi
  4105b1:	push   rsi
  4105b2:	sub    rsp,0xb8
  4105b9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4105bf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4105c5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4105cb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4105d1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4105d7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4105dd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4105e3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4105ec:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4105f5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4105fe:	vxorps xmm0,xmm0,xmm0
  410602:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410608:	mov    edi,0x1
  41060d:	lea    rsi,[rsp+0x8]
  410612:	xor    eax,eax
  410614:	call   4071d0 <clock_gettime@plt>
  410619:	mov    rax,QWORD PTR [rsp+0x8]
  41061e:	imul   rax,rax,0x3b9aca00
  410625:	add    rax,QWORD PTR [rsp+0x10]
  41062a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410630:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  410636:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  41063c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  410642:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410648:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  41064e:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  410654:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  41065d:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  410666:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  41066f:	add    rsp,0xb8
  410676:	pop    rsi
  410677:	pop    rdi
  410678:	ret
  410679:	add    BYTE PTR [rax],al
  41067b:	add    BYTE PTR [rax],al
  41067d:	add    BYTE PTR [rax],al
	...

0000000000410680 <__swc_fn_fc36583a_000134_29412410>:
  410680:	sub    rsp,0x8
  410684:	xor    eax,eax
  410686:	mov    DWORD PTR [rcx],eax
  410688:	mov    edx,0x7fffffff
  41068d:	call   409800 <__swc_fn_fc36583a_000132_f908e7f9>
  410692:	add    rsp,0x8
  410696:	ret
	...

00000000004106a0 <__swc_fn_fc36583a_000137_a4ba10ed>:
  4106a0:	push   rdi
  4106a1:	push   rsi
  4106a2:	sub    rsp,0xb8
  4106a9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4106af:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4106b5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4106bb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4106c1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4106c7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4106cd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4106d3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4106dc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4106e5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4106ee:	mov    edi,0x1
  4106f3:	xor    eax,eax
  4106f5:	call   4071e0 <__x86_get_cpuid_feature_leaf@plt>
  4106fa:	mov    eax,DWORD PTR [rax+0x14]
  4106fd:	and    eax,0x20
  410700:	setne  al
  410703:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410709:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  41070f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410715:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41071b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410721:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  410727:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41072d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  410736:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  41073f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410748:	add    rsp,0xb8
  41074f:	pop    rsi
  410750:	pop    rdi
  410751:	ret
	...

0000000000410760 <__swc_fn_fc36583a_000140_c6b99a56>:
  410760:	push   rsi
  410761:	push   rdi
  410762:	push   r12
  410764:	push   r13
  410766:	push   r14
  410768:	push   r15
  41076a:	cmp    rdx,0x40
  41076e:	jae    41077d <__swc_fn_fc36583a_000140_c6b99a56+0x1d>
  410770:	xor    eax,eax
  410772:	pop    r15
  410774:	pop    r14
  410776:	pop    r13
  410778:	pop    r12
  41077a:	pop    rdi
  41077b:	pop    rsi
  41077c:	ret
  41077d:	cmp    BYTE PTR [rcx],0x7f
  410780:	jne    4107c4 <__swc_fn_fc36583a_000140_c6b99a56+0x64>
  410782:	movzx  eax,BYTE PTR [rcx+0x1]
  410786:	cmp    eax,0x45
  410789:	setne  al
  41078c:	jne    4107c0 <__swc_fn_fc36583a_000140_c6b99a56+0x60>
  41078e:	movzx  eax,BYTE PTR [rcx+0x2]
  410792:	cmp    eax,0x4c
  410795:	setne  al
  410798:	jne    4107c0 <__swc_fn_fc36583a_000140_c6b99a56+0x60>
  41079a:	movzx  eax,BYTE PTR [rcx+0x3]
  41079e:	cmp    eax,0x46
  4107a1:	setne  al
  4107a4:	jne    4107c0 <__swc_fn_fc36583a_000140_c6b99a56+0x60>
  4107a6:	cmp    BYTE PTR [rcx+0x4],0x2
  4107aa:	setne  al
  4107ad:	jne    4107c0 <__swc_fn_fc36583a_000140_c6b99a56+0x60>
  4107af:	cmp    BYTE PTR [rcx+0x5],0x1
  4107b3:	setne  al
  4107b6:	jne    4107c0 <__swc_fn_fc36583a_000140_c6b99a56+0x60>
  4107b8:	cmp    WORD PTR [rcx+0x12],0x3e
  4107bd:	setne  al
  4107c0:	test   al,al
  4107c2:	je     4107d1 <__swc_fn_fc36583a_000140_c6b99a56+0x71>
  4107c4:	xor    eax,eax
  4107c6:	pop    r15
  4107c8:	pop    r14
  4107ca:	pop    r13
  4107cc:	pop    r12
  4107ce:	pop    rdi
  4107cf:	pop    rsi
  4107d0:	ret
  4107d1:	cmp    WORD PTR [rcx+0x3a],0x40
  4107d6:	jne    4107f1 <__swc_fn_fc36583a_000140_c6b99a56+0x91>
  4107d8:	cmp    WORD PTR [rcx+0x3c],0x0
  4107dd:	sete   al
  4107e0:	je     4107ed <__swc_fn_fc36583a_000140_c6b99a56+0x8d>
  4107e2:	mov    ax,WORD PTR [rcx+0x3c]
  4107e6:	cmp    WORD PTR [rcx+0x3e],ax
  4107ea:	setae  al
  4107ed:	test   al,al
  4107ef:	je     4107fe <__swc_fn_fc36583a_000140_c6b99a56+0x9e>
  4107f1:	xor    eax,eax
  4107f3:	pop    r15
  4107f5:	pop    r14
  4107f7:	pop    r13
  4107f9:	pop    r12
  4107fb:	pop    rdi
  4107fc:	pop    rsi
  4107fd:	ret
  4107fe:	movzx  eax,WORD PTR [rcx+0x3c]
  410802:	shl    rax,0x6
  410806:	cmp    rax,rdx
  410809:	ja     410817 <__swc_fn_fc36583a_000140_c6b99a56+0xb7>
  41080b:	mov    r9,rdx
  41080e:	sub    r9,rax
  410811:	cmp    QWORD PTR [rcx+0x28],r9
  410815:	jbe    410824 <__swc_fn_fc36583a_000140_c6b99a56+0xc4>
  410817:	xor    eax,eax
  410819:	pop    r15
  41081b:	pop    r14
  41081d:	pop    r13
  41081f:	pop    r12
  410821:	pop    rdi
  410822:	pop    rsi
  410823:	ret
  410824:	mov    rax,QWORD PTR [rcx+0x28]
  410828:	add    rax,rcx
  41082b:	movzx  r9d,WORD PTR [rcx+0x3e]
  410830:	lea    r9,[r9*8+0x0]
  410838:	lea    r10,[rax+r9*8]
  41083c:	cmp    QWORD PTR [r10+0x20],rdx
  410840:	ja     410862 <__swc_fn_fc36583a_000140_c6b99a56+0x102>
  410842:	mov    r11,rdx
  410845:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  41084a:	cmp    QWORD PTR [r10+0x18],r11
  41084e:	seta   r9b
  410852:	ja     41085d <__swc_fn_fc36583a_000140_c6b99a56+0xfd>
  410854:	cmp    QWORD PTR [r10+0x20],0x9
  410859:	setb   r9b
  41085d:	test   r9b,r9b
  410860:	je     41086f <__swc_fn_fc36583a_000140_c6b99a56+0x10f>
  410862:	xor    eax,eax
  410864:	pop    r15
  410866:	pop    r14
  410868:	pop    r13
  41086a:	pop    r12
  41086c:	pop    rdi
  41086d:	pop    rsi
  41086e:	ret
  41086f:	movzx  r9d,WORD PTR [rcx+0x3c]
  410874:	xor    r11d,r11d
  410877:	test   r9,r9
  41087a:	jbe    410975 <__swc_fn_fc36583a_000140_c6b99a56+0x215>
  410880:	mov    rsi,QWORD PTR [r10+0x20]
  410884:	sub    rsi,0x9
  410888:	cs nop WORD PTR [rax+rax*1+0x0]
  410892:	cs nop WORD PTR [rax+rax*1+0x0]
  41089c:	nop    DWORD PTR [rax+0x0]
  4108a0:	movzx  edi,r11w
  4108a4:	lea    rdi,[rdi*8+0x0]
  4108ac:	lea    r12,[rax+rdi*8]
  4108b0:	rex mov edi,DWORD PTR [rax+rdi*8]
  4108b4:	cmp    rdi,rsi
  4108b7:	ja     410968 <__swc_fn_fc36583a_000140_c6b99a56+0x208>
  4108bd:	mov    r13,QWORD PTR [r10+0x18]
  4108c1:	add    r13,rdi
  4108c4:	lea    rdi,[rcx+r13*1]
  4108c8:	lea    r13,[rip+0x2c61]        # 413530 <__swc_rdata_base_fc36583a+0x420>
  4108cf:	movabs r14,0x676264676177732e
  4108d9:	cmp    QWORD PTR [rdi],r14
  4108dc:	jne    4108e5 <__swc_fn_fc36583a_000140_c6b99a56+0x185>
  4108de:	rex cmp BYTE PTR [rdi+0x8],0x0
  4108e3:	je     410912 <__swc_fn_fc36583a_000140_c6b99a56+0x1b2>
  4108e5:	cs nop WORD PTR [rax+rax*1+0x0]
  4108ef:	nop
  4108f0:	movzx  r14d,BYTE PTR [rdi]
  4108f4:	movzx  r15d,BYTE PTR [r13+0x0]
  4108f9:	cmp    r14,r15
  4108fc:	jne    410908 <__swc_fn_fc36583a_000140_c6b99a56+0x1a8>
  4108fe:	add    rdi,0x1
  410902:	add    r13,0x1
  410906:	jmp    4108f0 <__swc_fn_fc36583a_000140_c6b99a56+0x190>
  410908:	mov    rdi,r14
  41090b:	sub    rdi,r15
  41090e:	test   edi,edi
  410910:	jne    410968 <__swc_fn_fc36583a_000140_c6b99a56+0x208>
  410912:	cmp    DWORD PTR [r12+0x4],0x1
  410918:	jne    410940 <__swc_fn_fc36583a_000140_c6b99a56+0x1e0>
  41091a:	cmp    QWORD PTR [r12+0x20],0x10
  410920:	setb   al
  410923:	jb     41093c <__swc_fn_fc36583a_000140_c6b99a56+0x1dc>
  410925:	cmp    QWORD PTR [r12+0x20],rdx
  41092a:	seta   al
  41092d:	ja     41093c <__swc_fn_fc36583a_000140_c6b99a56+0x1dc>
  41092f:	sub    rdx,QWORD PTR [r12+0x20]
  410934:	cmp    QWORD PTR [r12+0x18],rdx
  410939:	seta   al
  41093c:	test   al,al
  41093e:	je     41094d <__swc_fn_fc36583a_000140_c6b99a56+0x1ed>
  410940:	xor    eax,eax
  410942:	pop    r15
  410944:	pop    r14
  410946:	pop    r13
  410948:	pop    r12
  41094a:	pop    rdi
  41094b:	pop    rsi
  41094c:	ret
  41094d:	mov    rax,QWORD PTR [r12+0x20]
  410952:	mov    QWORD PTR [r8],rax
  410955:	mov    rax,QWORD PTR [r12+0x18]
  41095a:	add    rax,rcx
  41095d:	pop    r15
  41095f:	pop    r14
  410961:	pop    r13
  410963:	pop    r12
  410965:	pop    rdi
  410966:	pop    rsi
  410967:	ret
  410968:	add    r11,0x1
  41096c:	cmp    r11,r9
  41096f:	jb     4108a0 <__swc_fn_fc36583a_000140_c6b99a56+0x140>
  410975:	xor    eax,eax
  410977:	pop    r15
  410979:	pop    r14
  41097b:	pop    r13
  41097d:	pop    r12
  41097f:	pop    rdi
  410980:	pop    rsi
  410981:	ret
	...

0000000000410990 <__swc_fn_fc36583a_000143_81c0d993>:
  410990:	push   rdi
  410991:	push   rsi
  410992:	sub    rsp,0xa8
  410999:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41099f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4109a5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4109ab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4109b1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4109b7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4109bd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4109c3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4109c9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4109d2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4109db:	mov    rdi,rcx
  4109de:	xor    eax,eax
  4109e0:	call   4071f0 <free@plt>
  4109e5:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4109eb:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4109f1:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4109f7:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4109fd:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410a03:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410a09:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410a0f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410a15:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410a1e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410a27:	add    rsp,0xa8
  410a2e:	pop    rsi
  410a2f:	pop    rdi
  410a30:	ret
	...

0000000000410a40 <__swc_fn_fc36583a_000146_43f4fdca>:
  410a40:	push   rbx
  410a41:	push   rsi
  410a42:	push   rdi
  410a43:	push   r12
  410a45:	push   r13
  410a47:	push   r15
  410a49:	sub    rsp,0x4e8
  410a50:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  410a59:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  410a62:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  410a6b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  410a74:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  410a7d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  410a86:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  410a8f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  410a98:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  410aa1:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  410aaa:	mov    rbx,QWORD PTR [rcx]
  410aad:	mov    rcx,QWORD PTR [rcx+0x8]
  410ab1:	mov    rsi,rcx
  410ab4:	xor    edi,edi
  410ab6:	vmovsd xmm6,QWORD PTR [rip+0x2ad2]        # 413590 <__swc_rdata_base_fc36583a+0x480>
  410abe:	vmovsd xmm7,QWORD PTR [rip+0x2ad3]        # 413599 <__swc_rdata_base_fc36583a+0x489>
  410ac6:	vmovsd xmm8,QWORD PTR [rip+0x2ad4]        # 4135a2 <__swc_rdata_base_fc36583a+0x492>
  410ace:	vmovsd xmm9,QWORD PTR [rip+0x2ad5]        # 4135ab <__swc_rdata_base_fc36583a+0x49b>
  410ad6:	vmovsd xmm10,QWORD PTR [rip+0x2ad6]        # 4135b4 <__swc_rdata_base_fc36583a+0x4a4>
  410ade:	vmovups xmm11,xmm6
  410ae2:	vmovsd QWORD PTR [rsp+0x418],xmm7
  410aeb:	vmovsd QWORD PTR [rsp+0x420],xmm8
  410af4:	vmovsd QWORD PTR [rsp+0x428],xmm9
  410afd:	vmovsd QWORD PTR [rsp+0x430],xmm10
  410b06:	vmovsd xmm15,QWORD PTR [rip+0x2aaf]        # 4135bd <__swc_rdata_base_fc36583a+0x4ad>
  410b0e:	vmovups xmm14,xmm15
  410b13:	vmovups xmm0,xmm9
  410b18:	vmovsd QWORD PTR [rsp+0x438],xmm15
  410b21:	vmovups xmm13,xmm8
  410b26:	vmovsd QWORD PTR [rsp+0x440],xmm15
  410b2f:	test   rsi,rsi
  410b32:	je     411b63 <__swc_fn_fc36583a_000146_43f4fdca+0x1123>
  410b38:	cs nop WORD PTR [rax+rax*1+0x0]
  410b42:	cs nop WORD PTR [rax+rax*1+0x0]
  410b4c:	nop    DWORD PTR [rax+0x0]
  410b50:	lea    rcx,[rdi+rdi*1]
  410b54:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  410b59:	vpshufd xmm3,xmm2,0xee
  410b5e:	vmovq  rcx,xmm3
  410b63:	test   rcx,rcx
  410b66:	je     410b7c <__swc_fn_fc36583a_000146_43f4fdca+0x13c>
  410b68:	test   DWORD PTR [rcx+0x28],0x400000
  410b6f:	je     410b7c <__swc_fn_fc36583a_000146_43f4fdca+0x13c>
  410b71:	mov    rdx,QWORD PTR [rcx+0x30]
  410b75:	test   rdx,rdx
  410b78:	cmovne rcx,rdx
  410b7c:	test   DWORD PTR [rcx+0x28],0x1000
  410b83:	je     410ba4 <__swc_fn_fc36583a_000146_43f4fdca+0x164>
  410b85:	mov    rdx,QWORD PTR [rcx+0x40]
  410b89:	mov    rcx,rdx
  410b8c:	vmovq  r8,xmm2
  410b91:	mov    r8,QWORD PTR [r8]
  410b94:	mov    QWORD PTR [rsp+0x60],r8
  410b99:	mov    QWORD PTR [rsp+0x68],rdx
  410b9e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  410ba4:	test   BYTE PTR [rcx+0x28],0x1
  410ba8:	jne    410bb0 <__swc_fn_fc36583a_000146_43f4fdca+0x170>
  410baa:	vmovups xmm12,xmm0
  410bae:	jmp    410bca <__swc_fn_fc36583a_000146_43f4fdca+0x18a>
  410bb0:	vmovq  rax,xmm2
  410bb5:	mov    rax,QWORD PTR [rax]
  410bb8:	lea    rcx,[rax+0x10]
  410bbc:	vmovups xmm12,xmm0
  410bc0:	call   4101c0 <__swc_fn_fc36583a_000116_035d76a1>
  410bc5:	jmp    411b45 <__swc_fn_fc36583a_000146_43f4fdca+0x1105>
  410bca:	test   DWORD PTR [rcx+0x28],0x400
  410bd1:	je     410c32 <__swc_fn_fc36583a_000146_43f4fdca+0x1f2>
  410bd3:	vmovq  rax,xmm2
  410bd8:	mov    rax,QWORD PTR [rax]
  410bdb:	xor    ecx,ecx
  410bdd:	test   rax,rax
  410be0:	je     410c10 <__swc_fn_fc36583a_000146_43f4fdca+0x1d0>
  410be2:	mov    rdx,rax
  410be5:	mov    r8b,BYTE PTR [rdx]
  410be8:	test   r8b,r8b
  410beb:	je     410c10 <__swc_fn_fc36583a_000146_43f4fdca+0x1d0>
  410bed:	cs nop WORD PTR [rax+rax*1+0x0]
  410bf7:	nop    WORD PTR [rax+rax*1+0x0]
  410c00:	add    rdx,0x1
  410c04:	add    rcx,0x1
  410c08:	mov    r8b,BYTE PTR [rdx]
  410c0b:	test   r8b,r8b
  410c0e:	jne    410c00 <__swc_fn_fc36583a_000146_43f4fdca+0x1c0>
  410c10:	mov    QWORD PTR [rsp+0x88],rax
  410c18:	mov    QWORD PTR [rsp+0x90],rcx
  410c20:	lea    rcx,[rsp+0x88]
  410c28:	call   4101c0 <__swc_fn_fc36583a_000116_035d76a1>
  410c2d:	jmp    411b45 <__swc_fn_fc36583a_000146_43f4fdca+0x1105>
  410c32:	cmp    BYTE PTR [rcx+0x2c],0x6
  410c36:	jne    410c4d <__swc_fn_fc36583a_000146_43f4fdca+0x20d>
  410c38:	vmovq  rax,xmm2
  410c3d:	mov    rax,QWORD PTR [rax]
  410c40:	mov    rcx,rax
  410c43:	call   409cd0 <__swc_fn_fc36583a_000144_72996a5b>
  410c48:	jmp    411b45 <__swc_fn_fc36583a_000146_43f4fdca+0x1105>
  410c4d:	cmp    BYTE PTR [rcx+0x2c],0x1
  410c51:	jne    411b39 <__swc_fn_fc36583a_000146_43f4fdca+0x10f9>
  410c57:	vmovq  rdx,xmm2
  410c5c:	mov    cl,BYTE PTR [rcx+0x40]
  410c5f:	cmp    cl,0x7
  410c62:	jb     410ca5 <__swc_fn_fc36583a_000146_43f4fdca+0x265>
  410c64:	je     410d18 <__swc_fn_fc36583a_000146_43f4fdca+0x2d8>
  410c6a:	cmp    cl,0x8
  410c6d:	je     410d24 <__swc_fn_fc36583a_000146_43f4fdca+0x2e4>
  410c73:	cmp    cl,0x9
  410c76:	je     410d3d <__swc_fn_fc36583a_000146_43f4fdca+0x2fd>
  410c7c:	cmp    cl,0xa
  410c7f:	je     411424 <__swc_fn_fc36583a_000146_43f4fdca+0x9e4>
  410c85:	cmp    cl,0xb
  410c88:	je     411b0b <__swc_fn_fc36583a_000146_43f4fdca+0x10cb>
  410c8e:	cmp    cl,0xc
  410c91:	je     410d31 <__swc_fn_fc36583a_000146_43f4fdca+0x2f1>
  410c97:	cmp    cl,0xd
  410c9a:	je     411b01 <__swc_fn_fc36583a_000146_43f4fdca+0x10c1>
  410ca0:	jmp    411b2b <__swc_fn_fc36583a_000146_43f4fdca+0x10eb>
  410ca5:	cmp    cl,0x1
  410ca8:	je     410cc8 <__swc_fn_fc36583a_000146_43f4fdca+0x288>
  410caa:	cmp    cl,0x2
  410cad:	je     410cd6 <__swc_fn_fc36583a_000146_43f4fdca+0x296>
  410caf:	cmp    cl,0x3
  410cb2:	je     410ce4 <__swc_fn_fc36583a_000146_43f4fdca+0x2a4>
  410cb4:	cmp    cl,0x4
  410cb7:	je     410cf1 <__swc_fn_fc36583a_000146_43f4fdca+0x2b1>
  410cb9:	cmp    cl,0x5
  410cbc:	je     410cfe <__swc_fn_fc36583a_000146_43f4fdca+0x2be>
  410cbe:	cmp    cl,0x6
  410cc1:	je     410d0b <__swc_fn_fc36583a_000146_43f4fdca+0x2cb>
  410cc3:	jmp    411b2b <__swc_fn_fc36583a_000146_43f4fdca+0x10eb>
  410cc8:	movsx  rcx,BYTE PTR [rdx]
  410ccc:	call   40d760 <__swc_fn_fc36583a_000145_863755b5>
  410cd1:	jmp    411b45 <__swc_fn_fc36583a_000146_43f4fdca+0x1105>
  410cd6:	movsx  rcx,WORD PTR [rdx]
  410cda:	call   40d760 <__swc_fn_fc36583a_000145_863755b5>
  410cdf:	jmp    411b45 <__swc_fn_fc36583a_000146_43f4fdca+0x1105>
  410ce4:	movsxd rcx,DWORD PTR [rdx]
  410ce7:	call   40d760 <__swc_fn_fc36583a_000145_863755b5>
  410cec:	jmp    411b45 <__swc_fn_fc36583a_000146_43f4fdca+0x1105>
  410cf1:	mov    rcx,QWORD PTR [rdx]
  410cf4:	call   40d760 <__swc_fn_fc36583a_000145_863755b5>
  410cf9:	jmp    411b45 <__swc_fn_fc36583a_000146_43f4fdca+0x1105>
  410cfe:	movzx  ecx,BYTE PTR [rdx]
  410d01:	call   409cd0 <__swc_fn_fc36583a_000144_72996a5b>
  410d06:	jmp    411b45 <__swc_fn_fc36583a_000146_43f4fdca+0x1105>
  410d0b:	movzx  ecx,WORD PTR [rdx]
  410d0e:	call   409cd0 <__swc_fn_fc36583a_000144_72996a5b>
  410d13:	jmp    411b45 <__swc_fn_fc36583a_000146_43f4fdca+0x1105>
  410d18:	mov    ecx,DWORD PTR [rdx]
  410d1a:	call   409cd0 <__swc_fn_fc36583a_000144_72996a5b>
  410d1f:	jmp    411b45 <__swc_fn_fc36583a_000146_43f4fdca+0x1105>
  410d24:	mov    rcx,QWORD PTR [rdx]
  410d27:	call   409cd0 <__swc_fn_fc36583a_000144_72996a5b>
  410d2c:	jmp    411b45 <__swc_fn_fc36583a_000146_43f4fdca+0x1105>
  410d31:	mov    ecx,DWORD PTR [rdx]
  410d33:	call   409cd0 <__swc_fn_fc36583a_000144_72996a5b>
  410d38:	jmp    411b45 <__swc_fn_fc36583a_000146_43f4fdca+0x1105>
  410d3d:	lea    rcx,[rsp+0xa8]
  410d45:	vxorps xmm0,xmm0,xmm0
  410d49:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  410d52:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  410d5b:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  410d64:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  410d6d:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  410d76:	vmovups XMMWORD PTR [rsp+0xf8],xmm0
  410d7f:	mov    DWORD PTR [rsp+0x108],0x0
  410d8a:	vxorpd xmm0,xmm0,xmm0
  410d8e:	vmovss xmm1,DWORD PTR [rdx]
  410d92:	vcvtss2sd xmm0,xmm0,xmm1
  410d96:	vmovsd xmm1,xmm1,xmm0
  410d9a:	vcomisd xmm0,xmm0
  410d9e:	setne  dl
  410da1:	movzx  edx,dl
  410da4:	setp   r8b
  410da8:	movzx  r8d,r8b
  410dac:	or     edx,r8d
  410daf:	test   dl,dl
  410db1:	je     410dbe <__swc_fn_fc36583a_000146_43f4fdca+0x37e>
  410db3:	mov    DWORD PTR [rcx],0x6e616e
  410db9:	jmp    4113b8 <__swc_fn_fc36583a_000146_43f4fdca+0x978>
  410dbe:	vcomisd xmm1,xmm6
  410dc2:	ja     410dca <__swc_fn_fc36583a_000146_43f4fdca+0x38a>
  410dc4:	vcomisd xmm7,xmm1
  410dc8:	jbe    410dee <__swc_fn_fc36583a_000146_43f4fdca+0x3ae>
  410dca:	vxorpd xmm0,xmm0,xmm0
  410dce:	vcomisd xmm0,xmm1
  410dd2:	jbe    410de3 <__swc_fn_fc36583a_000146_43f4fdca+0x3a3>
  410dd4:	mov    DWORD PTR [rcx],0x666e692d
  410dda:	mov    BYTE PTR [rcx+0x4],0x0
  410dde:	jmp    4113b8 <__swc_fn_fc36583a_000146_43f4fdca+0x978>
  410de3:	mov    DWORD PTR [rcx],0x666e69
  410de9:	jmp    4113b8 <__swc_fn_fc36583a_000146_43f4fdca+0x978>
  410dee:	vcomisd xmm1,xmm8
  410df3:	jae    410dff <__swc_fn_fc36583a_000146_43f4fdca+0x3bf>
  410df5:	vcomisd xmm9,xmm1
  410df9:	jbe    41117e <__swc_fn_fc36583a_000146_43f4fdca+0x73e>
  410dff:	vmovups xmm0,xmm1
  410e03:	vxorpd xmm2,xmm2,xmm2
  410e07:	vcomisd xmm2,xmm1
  410e0b:	jbe    410e1b <__swc_fn_fc36583a_000146_43f4fdca+0x3db>
  410e0d:	vmovsd xmm1,xmm1,xmm0
  410e11:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x2737]        # 413550 <__swc_rdata_base_fc36583a+0x440>
  410e19:	jmp    410e1f <__swc_fn_fc36583a_000146_43f4fdca+0x3df>
  410e1b:	vmovsd xmm1,xmm1,xmm0
  410e1f:	xor    r8d,r8d
  410e22:	vcomisd xmm1,xmm15
  410e27:	jb     410e50 <__swc_fn_fc36583a_000146_43f4fdca+0x410>
  410e29:	cs nop WORD PTR [rax+rax*1+0x0]
  410e33:	cs nop WORD PTR [rax+rax*1+0x0]
  410e3d:	nop    DWORD PTR [rax]
  410e40:	vdivsd xmm1,xmm1,xmm15
  410e45:	add    r8,0x1
  410e49:	vcomisd xmm1,xmm15
  410e4e:	jae    410e40 <__swc_fn_fc36583a_000146_43f4fdca+0x400>
  410e50:	mov    r9,rcx
  410e53:	vxorpd xmm2,xmm2,xmm2
  410e57:	vcomisd xmm2,xmm0
  410e5b:	jbe    410e64 <__swc_fn_fc36583a_000146_43f4fdca+0x424>
  410e5d:	mov    BYTE PTR [rcx],0x2d
  410e60:	lea    r9,[rcx+0x1]
  410e64:	vcvttsd2si rdx,xmm1
  410e69:	mov    r10b,dl
  410e6c:	add    r10b,0x30
  410e70:	mov    BYTE PTR [r9],r10b
  410e73:	vxorpd xmm0,xmm0,xmm0
  410e77:	movzx  edx,dl
  410e7a:	vcvtsi2sd xmm0,xmm0,rdx
  410e7f:	vsubsd xmm0,xmm1,xmm0
  410e83:	vmulsd xmm1,xmm0,xmm15
  410e88:	mov    BYTE PTR [r9+0x1],0x2e
  410e8d:	vcvttsd2si rdx,xmm1
  410e92:	mov    r10b,dl
  410e95:	add    r10b,0x30
  410e99:	mov    BYTE PTR [r9+0x2],r10b
  410e9d:	vxorpd xmm0,xmm0,xmm0
  410ea1:	movzx  edx,dl
  410ea4:	vcvtsi2sd xmm0,xmm0,rdx
  410ea9:	vsubsd xmm0,xmm1,xmm0
  410ead:	vmulsd xmm1,xmm0,xmm15
  410eb2:	vcvttsd2si rdx,xmm1
  410eb7:	mov    r10b,dl
  410eba:	add    r10b,0x30
  410ebe:	mov    BYTE PTR [r9+0x3],r10b
  410ec2:	vxorpd xmm0,xmm0,xmm0
  410ec6:	movzx  edx,dl
  410ec9:	vcvtsi2sd xmm0,xmm0,rdx
  410ece:	vsubsd xmm0,xmm1,xmm0
  410ed2:	vmulsd xmm1,xmm0,xmm15
  410ed7:	vcvttsd2si rdx,xmm1
  410edc:	mov    r10b,dl
  410edf:	add    r10b,0x30
  410ee3:	mov    BYTE PTR [r9+0x4],r10b
  410ee7:	vxorpd xmm0,xmm0,xmm0
  410eeb:	movzx  edx,dl
  410eee:	vcvtsi2sd xmm0,xmm0,rdx
  410ef3:	vsubsd xmm0,xmm1,xmm0
  410ef7:	vmulsd xmm1,xmm0,xmm15
  410efc:	vcvttsd2si rdx,xmm1
  410f01:	mov    r10b,dl
  410f04:	add    r10b,0x30
  410f08:	mov    BYTE PTR [r9+0x5],r10b
  410f0c:	vxorpd xmm0,xmm0,xmm0
  410f10:	movzx  edx,dl
  410f13:	vcvtsi2sd xmm0,xmm0,rdx
  410f18:	vsubsd xmm0,xmm1,xmm0
  410f1c:	vmulsd xmm1,xmm0,xmm15
  410f21:	vcvttsd2si rdx,xmm1
  410f26:	mov    r10b,dl
  410f29:	add    r10b,0x30
  410f2d:	mov    BYTE PTR [r9+0x6],r10b
  410f31:	vxorpd xmm0,xmm0,xmm0
  410f35:	movzx  edx,dl
  410f38:	vcvtsi2sd xmm0,xmm0,rdx
  410f3d:	vsubsd xmm0,xmm1,xmm0
  410f41:	vmulsd xmm1,xmm0,xmm15
  410f46:	vcvttsd2si rdx,xmm1
  410f4b:	mov    r10b,dl
  410f4e:	add    r10b,0x30
  410f52:	mov    BYTE PTR [r9+0x7],r10b
  410f56:	vxorpd xmm0,xmm0,xmm0
  410f5a:	movzx  edx,dl
  410f5d:	vcvtsi2sd xmm0,xmm0,rdx
  410f62:	vsubsd xmm0,xmm1,xmm0
  410f66:	vmulsd xmm1,xmm0,xmm15
  410f6b:	vcvttsd2si rdx,xmm1
  410f70:	mov    r10b,dl
  410f73:	add    r10b,0x30
  410f77:	mov    BYTE PTR [r9+0x8],r10b
  410f7b:	vxorpd xmm0,xmm0,xmm0
  410f7f:	movzx  edx,dl
  410f82:	vcvtsi2sd xmm0,xmm0,rdx
  410f87:	vsubsd xmm0,xmm1,xmm0
  410f8b:	vmulsd xmm1,xmm0,xmm15
  410f90:	vcvttsd2si rdx,xmm1
  410f95:	mov    r10b,dl
  410f98:	add    r10b,0x30
  410f9c:	mov    BYTE PTR [r9+0x9],r10b
  410fa0:	vxorpd xmm0,xmm0,xmm0
  410fa4:	movzx  edx,dl
  410fa7:	vcvtsi2sd xmm0,xmm0,rdx
  410fac:	vsubsd xmm0,xmm1,xmm0
  410fb0:	vmulsd xmm1,xmm0,xmm15
  410fb5:	vcvttsd2si rdx,xmm1
  410fba:	mov    r10b,dl
  410fbd:	add    r10b,0x30
  410fc1:	mov    BYTE PTR [r9+0xa],r10b
  410fc5:	vxorpd xmm0,xmm0,xmm0
  410fc9:	movzx  edx,dl
  410fcc:	vcvtsi2sd xmm0,xmm0,rdx
  410fd1:	vsubsd xmm0,xmm1,xmm0
  410fd5:	vmulsd xmm1,xmm0,xmm15
  410fda:	vcvttsd2si rdx,xmm1
  410fdf:	mov    r10b,dl
  410fe2:	add    r10b,0x30
  410fe6:	mov    BYTE PTR [r9+0xb],r10b
  410fea:	lea    r10,[r9+0x4]
  410fee:	vxorpd xmm0,xmm0,xmm0
  410ff2:	movzx  edx,dl
  410ff5:	vcvtsi2sd xmm0,xmm0,rdx
  410ffa:	vsubsd xmm0,xmm1,xmm0
  410ffe:	vmulsd xmm1,xmm0,xmm15
  411003:	vcvttsd2si rdx,xmm1
  411008:	mov    r11b,dl
  41100b:	add    r11b,0x30
  41100f:	mov    BYTE PTR [r9+0xc],r11b
  411013:	vxorpd xmm0,xmm0,xmm0
  411017:	movzx  edx,dl
  41101a:	vcvtsi2sd xmm0,xmm0,rdx
  41101f:	vsubsd xmm0,xmm1,xmm0
  411023:	vmulsd xmm1,xmm0,xmm15
  411028:	vcvttsd2si rdx,xmm1
  41102d:	mov    r11b,dl
  411030:	add    r11b,0x30
  411034:	mov    BYTE PTR [r9+0xd],r11b
  411038:	lea    r10,[r10+0x2]
  41103c:	vxorpd xmm0,xmm0,xmm0
  411040:	movzx  edx,dl
  411043:	vcvtsi2sd xmm0,xmm0,rdx
  411048:	vsubsd xmm0,xmm1,xmm0
  41104c:	vmulsd xmm1,xmm0,xmm15
  411051:	vcvttsd2si rdx,xmm1
  411056:	mov    r11b,dl
  411059:	add    r11b,0x30
  41105d:	mov    BYTE PTR [r9+0xe],r11b
  411061:	vxorpd xmm0,xmm0,xmm0
  411065:	movzx  edx,dl
  411068:	vcvtsi2sd xmm0,xmm0,rdx
  41106d:	vsubsd xmm0,xmm1,xmm0
  411071:	vmulsd xmm1,xmm0,xmm15
  411076:	vcvttsd2si rdx,xmm1
  41107b:	mov    r11b,dl
  41107e:	add    r11b,0x30
  411082:	mov    BYTE PTR [r9+0xf],r11b
  411086:	lea    r10,[r10+0x2]
  41108a:	lea    r10,[r10+0x2]
  41108e:	lea    r10,[r10+0x2]
  411092:	lea    r10,[r10+0x2]
  411096:	lea    r10,[r10+0x2]
  41109a:	vxorpd xmm0,xmm0,xmm0
  41109e:	movzx  edx,dl
  4110a1:	vcvtsi2sd xmm0,xmm0,rdx
  4110a6:	vsubsd xmm0,xmm1,xmm0
  4110aa:	vmulsd xmm1,xmm0,xmm15
  4110af:	vcvttsd2si rdx,xmm1
  4110b4:	mov    r11b,dl
  4110b7:	add    r11b,0x30
  4110bb:	mov    BYTE PTR [r9+0x10],r11b
  4110bf:	vxorpd xmm0,xmm0,xmm0
  4110c3:	movzx  edx,dl
  4110c6:	vcvtsi2sd xmm0,xmm0,rdx
  4110cb:	vsubsd xmm0,xmm1,xmm0
  4110cf:	vmulsd xmm1,xmm0,xmm15
  4110d4:	vcvttsd2si rdx,xmm1
  4110d9:	add    dl,0x30
  4110dc:	mov    BYTE PTR [r9+0x11],dl
  4110e0:	mov    BYTE PTR [r10+0x2],0x65
  4110e5:	lea    r9,[r10+0x3]
  4110e9:	test   r8,r8
  4110ec:	jl     4110f5 <__swc_fn_fc36583a_000146_43f4fdca+0x6b5>
  4110ee:	mov    BYTE PTR [r9],0x2b
  4110f2:	inc    r9
  4110f5:	mov    r10,r9
  4110f8:	mov    rdx,r8
  4110fb:	nop    DWORD PTR [rax+rax*1+0x0]
  411100:	mov    r11,rdx
  411103:	movabs rdx,0x6666666666666667
  41110d:	mov    rax,r11
  411110:	imul   rdx
  411113:	sar    rdx,0x2
  411117:	mov    r12,rdx
  41111a:	shr    rdx,0x3f
  41111e:	add    r12,rdx
  411121:	mov    rdx,r12
  411124:	imul   r13,r12,0xa
  411128:	sub    r11,r13
  41112b:	mov    r13,QWORD PTR [rip+0x240e]        # 413540 <__swc_rdata_base_fc36583a+0x430>
  411132:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411137:	mov    BYTE PTR [r10],r11b
  41113a:	lea    r11,[r10+0x1]
  41113e:	mov    r10,r11
  411141:	test   r12,r12
  411144:	jne    411100 <__swc_fn_fc36583a_000146_43f4fdca+0x6c0>
  411146:	test   r8,r8
  411149:	jge    411153 <__swc_fn_fc36583a_000146_43f4fdca+0x713>
  41114b:	mov    BYTE PTR [r11],0x2d
  41114f:	lea    r10,[r11+0x1]
  411153:	mov    BYTE PTR [r10],0x0
  411157:	sub    r10,0x1
  41115b:	nop    DWORD PTR [rax+rax*1+0x0]
  411160:	cmp    r9,r10
  411163:	jae    4113b8 <__swc_fn_fc36583a_000146_43f4fdca+0x978>
  411169:	mov    al,BYTE PTR [r10]
  41116c:	mov    dl,BYTE PTR [r9]
  41116f:	mov    BYTE PTR [r10],dl
  411172:	sub    r10,0x1
  411176:	mov    BYTE PTR [r9],al
  411179:	inc    r9
  41117c:	jmp    411160 <__swc_fn_fc36583a_000146_43f4fdca+0x720>
  41117e:	vcvttsd2si rdx,xmm1
  411183:	mov    r8,rdx
  411186:	vxorpd xmm0,xmm0,xmm0
  41118a:	vcvtsi2sd xmm0,xmm0,rdx
  41118f:	vsubsd xmm0,xmm1,xmm0
  411193:	mov    r9d,0x8
  411199:	vxorpd xmm2,xmm2,xmm2
  41119d:	vcomisd xmm2,xmm0
  4111a1:	jbe    4111ab <__swc_fn_fc36583a_000146_43f4fdca+0x76b>
  4111a3:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x23a5]        # 413550 <__swc_rdata_base_fc36583a+0x440>
  4111ab:	test   r9d,r9d
  4111ae:	je     4111ba <__swc_fn_fc36583a_000146_43f4fdca+0x77a>
  4111b0:	vmulsd xmm0,xmm0,xmm14
  4111b5:	dec    r9d
  4111b8:	jne    4111b0 <__swc_fn_fc36583a_000146_43f4fdca+0x770>
  4111ba:	vcvttsd2si r9,xmm0
  4111bf:	mov    r10,r9
  4111c2:	vxorpd xmm2,xmm2,xmm2
  4111c6:	vcvtsi2sd xmm2,xmm2,r9
  4111cb:	vsubsd xmm0,xmm0,xmm2
  4111cf:	vcomisd xmm0,xmm10
  4111d4:	lea    r9,[r9+0x1]
  4111d8:	cmova  r10,r9
  4111dc:	cmp    r10,0x5f5e100
  4111e3:	jne    4111fc <__swc_fn_fc36583a_000146_43f4fdca+0x7bc>
  4111e5:	lea    r8,[rdx-0x1]
  4111e9:	vxorpd xmm0,xmm0,xmm0
  4111ed:	vcomisd xmm0,xmm1
  4111f1:	lea    rdx,[rdx+0x1]
  4111f5:	cmovbe r8,rdx
  4111f9:	xor    r10d,r10d
  4111fc:	mov    r9,rcx
  4111ff:	test   r8,r8
  411202:	jne    411222 <__swc_fn_fc36583a_000146_43f4fdca+0x7e2>
  411204:	vxorpd xmm0,xmm0,xmm0
  411208:	vcomisd xmm0,xmm1
  41120c:	jbe    411215 <__swc_fn_fc36583a_000146_43f4fdca+0x7d5>
  41120e:	mov    BYTE PTR [rcx],0x2d
  411211:	lea    r9,[rcx+0x1]
  411215:	mov    BYTE PTR [r9],0x30
  411219:	add    r9,0x1
  41121d:	jmp    4112bb <__swc_fn_fc36583a_000146_43f4fdca+0x87b>
  411222:	mov    r9,rcx
  411225:	mov    rdx,r8
  411228:	nop    DWORD PTR [rax+rax*1+0x0]
  411230:	mov    r11,rdx
  411233:	movabs rdx,0x6666666666666667
  41123d:	mov    r15,rax
  411240:	mov    rax,r11
  411243:	imul   rdx
  411246:	mov    r12,rdx
  411249:	mov    rax,r15
  41124c:	sar    r12,0x2
  411250:	mov    rdx,r12
  411253:	shr    rdx,0x3f
  411257:	add    r12,rdx
  41125a:	mov    rdx,r12
  41125d:	imul   r13,r12,0xa
  411261:	sub    r11,r13
  411264:	mov    r13,QWORD PTR [rip+0x22d5]        # 413540 <__swc_rdata_base_fc36583a+0x430>
  41126b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411270:	mov    BYTE PTR [r9],r11b
  411273:	lea    r11,[r9+0x1]
  411277:	mov    r9,r11
  41127a:	test   r12,r12
  41127d:	jne    411230 <__swc_fn_fc36583a_000146_43f4fdca+0x7f0>
  41127f:	test   r8,r8
  411282:	jge    41128c <__swc_fn_fc36583a_000146_43f4fdca+0x84c>
  411284:	mov    BYTE PTR [r11],0x2d
  411288:	lea    r9,[r11+0x1]
  41128c:	mov    rdx,r9
  41128f:	mov    BYTE PTR [r9],0x0
  411293:	sub    r9,0x1
  411297:	mov    r8,rcx
  41129a:	cmp    r8,r9
  41129d:	jae    4112b8 <__swc_fn_fc36583a_000146_43f4fdca+0x878>
  41129f:	nop
  4112a0:	mov    r11b,BYTE PTR [r9]
  4112a3:	mov    r12b,BYTE PTR [r8]
  4112a6:	mov    BYTE PTR [r9],r12b
  4112a9:	sub    r9,0x1
  4112ad:	mov    BYTE PTR [r8],r11b
  4112b0:	inc    r8
  4112b3:	cmp    r8,r9
  4112b6:	jb     4112a0 <__swc_fn_fc36583a_000146_43f4fdca+0x860>
  4112b8:	mov    r9,rdx
  4112bb:	mov    BYTE PTR [r9],0x2e
  4112bf:	add    r9,0x1
  4112c3:	xor    r8d,r8d
  4112c6:	test   r10,r10
  4112c9:	je     41130f <__swc_fn_fc36583a_000146_43f4fdca+0x8cf>
  4112cb:	mov    r11d,0x989680
  4112d1:	cmp    r10,r11
  4112d4:	jge    41130f <__swc_fn_fc36583a_000146_43f4fdca+0x8cf>
  4112d6:	cs nop WORD PTR [rax+rax*1+0x0]
  4112e0:	inc    r8d
  4112e3:	movabs rdx,0x6666666666666667
  4112ed:	mov    r15,rax
  4112f0:	mov    rax,r11
  4112f3:	imul   rdx
  4112f6:	mov    r11,rdx
  4112f9:	mov    rax,r15
  4112fc:	sar    r11,0x2
  411300:	mov    rdx,r11
  411303:	shr    rdx,0x3f
  411307:	add    r11,rdx
  41130a:	cmp    r10,r11
  41130d:	jl     4112e0 <__swc_fn_fc36583a_000146_43f4fdca+0x8a0>
  41130f:	test   r8d,r8d
  411312:	je     41132d <__swc_fn_fc36583a_000146_43f4fdca+0x8ed>
  411314:	cs nop WORD PTR [rax+rax*1+0x0]
  41131e:	xchg   ax,ax
  411320:	mov    BYTE PTR [r9],0x30
  411324:	add    r9,0x1
  411328:	dec    r8d
  41132b:	jne    411320 <__swc_fn_fc36583a_000146_43f4fdca+0x8e0>
  41132d:	mov    r8,r9
  411330:	mov    rdx,r10
  411333:	cs nop WORD PTR [rax+rax*1+0x0]
  41133d:	nop    DWORD PTR [rax]
  411340:	mov    r11,rdx
  411343:	movabs rdx,0x6666666666666667
  41134d:	mov    rax,r11
  411350:	imul   rdx
  411353:	sar    rdx,0x2
  411357:	mov    r12,rdx
  41135a:	shr    rdx,0x3f
  41135e:	add    r12,rdx
  411361:	mov    rdx,r12
  411364:	imul   r13,r12,0xa
  411368:	sub    r11,r13
  41136b:	mov    r13,QWORD PTR [rip+0x21ce]        # 413540 <__swc_rdata_base_fc36583a+0x430>
  411372:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411377:	mov    BYTE PTR [r8],r11b
  41137a:	lea    r11,[r8+0x1]
  41137e:	mov    r8,r11
  411381:	test   r12,r12
  411384:	jne    411340 <__swc_fn_fc36583a_000146_43f4fdca+0x900>
  411386:	test   r10,r10
  411389:	jge    411393 <__swc_fn_fc36583a_000146_43f4fdca+0x953>
  41138b:	mov    BYTE PTR [r11],0x2d
  41138f:	lea    r8,[r11+0x1]
  411393:	mov    BYTE PTR [r8],0x0
  411397:	sub    r8,0x1
  41139b:	cmp    r9,r8
  41139e:	jae    4113b8 <__swc_fn_fc36583a_000146_43f4fdca+0x978>
  4113a0:	mov    al,BYTE PTR [r8]
  4113a3:	mov    dl,BYTE PTR [r9]
  4113a6:	mov    BYTE PTR [r8],dl
  4113a9:	sub    r8,0x1
  4113ad:	mov    BYTE PTR [r9],al
  4113b0:	inc    r9
  4113b3:	cmp    r9,r8
  4113b6:	jb     4113a0 <__swc_fn_fc36583a_000146_43f4fdca+0x960>
  4113b8:	xor    eax,eax
  4113ba:	test   rcx,rcx
  4113bd:	je     4113f0 <__swc_fn_fc36583a_000146_43f4fdca+0x9b0>
  4113bf:	mov    rdx,rcx
  4113c2:	mov    r8b,BYTE PTR [rdx]
  4113c5:	test   r8b,r8b
  4113c8:	je     4113f0 <__swc_fn_fc36583a_000146_43f4fdca+0x9b0>
  4113ca:	cs nop WORD PTR [rax+rax*1+0x0]
  4113d4:	cs nop WORD PTR [rax+rax*1+0x0]
  4113de:	xchg   ax,ax
  4113e0:	add    rdx,0x1
  4113e4:	add    rax,0x1
  4113e8:	mov    r8b,BYTE PTR [rdx]
  4113eb:	test   r8b,r8b
  4113ee:	jne    4113e0 <__swc_fn_fc36583a_000146_43f4fdca+0x9a0>
  4113f0:	mov    QWORD PTR [rsp+0x240],rcx
  4113f8:	mov    QWORD PTR [rsp+0x248],rax
  411400:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  411409:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  411412:	lea    rcx,[rsp+0x250]
  41141a:	call   4101c0 <__swc_fn_fc36583a_000116_035d76a1>
  41141f:	jmp    411b45 <__swc_fn_fc36583a_000146_43f4fdca+0x1105>
  411424:	lea    rcx,[rsp+0x260]
  41142c:	vxorps xmm0,xmm0,xmm0
  411430:	vmovups XMMWORD PTR [rsp+0x260],xmm0
  411439:	vmovups XMMWORD PTR [rsp+0x270],xmm0
  411442:	vmovups XMMWORD PTR [rsp+0x280],xmm0
  41144b:	vmovups XMMWORD PTR [rsp+0x290],xmm0
  411454:	vmovups XMMWORD PTR [rsp+0x2a0],xmm0
  41145d:	vmovups XMMWORD PTR [rsp+0x2b0],xmm0
  411466:	mov    DWORD PTR [rsp+0x2c0],0x0
  411471:	vmovsd xmm0,QWORD PTR [rdx]
  411475:	vcomisd xmm0,xmm0
  411479:	setne  dl
  41147c:	movzx  edx,dl
  41147f:	setp   r8b
  411483:	movzx  r8d,r8b
  411487:	or     edx,r8d
  41148a:	test   dl,dl
  41148c:	je     411499 <__swc_fn_fc36583a_000146_43f4fdca+0xa59>
  41148e:	mov    DWORD PTR [rcx],0x6e616e
  411494:	jmp    411aa8 <__swc_fn_fc36583a_000146_43f4fdca+0x1068>
  411499:	vcomisd xmm0,xmm11
  41149e:	ja     4114af <__swc_fn_fc36583a_000146_43f4fdca+0xa6f>
  4114a0:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  4114a9:	vcomisd xmm6,xmm0
  4114ad:	jbe    4114d3 <__swc_fn_fc36583a_000146_43f4fdca+0xa93>
  4114af:	vxorpd xmm1,xmm1,xmm1
  4114b3:	vcomisd xmm1,xmm0
  4114b7:	jbe    4114c8 <__swc_fn_fc36583a_000146_43f4fdca+0xa88>
  4114b9:	mov    DWORD PTR [rcx],0x666e692d
  4114bf:	mov    BYTE PTR [rcx+0x4],0x0
  4114c3:	jmp    411aa8 <__swc_fn_fc36583a_000146_43f4fdca+0x1068>
  4114c8:	mov    DWORD PTR [rcx],0x666e69
  4114ce:	jmp    411aa8 <__swc_fn_fc36583a_000146_43f4fdca+0x1068>
  4114d3:	vcomisd xmm0,xmm13
  4114d8:	jae    4114e4 <__swc_fn_fc36583a_000146_43f4fdca+0xaa4>
  4114da:	vcomisd xmm12,xmm0
  4114de:	jbe    41184e <__swc_fn_fc36583a_000146_43f4fdca+0xe0e>
  4114e4:	vmovups xmm1,xmm0
  4114e8:	vxorpd xmm2,xmm2,xmm2
  4114ec:	vcomisd xmm2,xmm0
  4114f0:	jbe    411500 <__swc_fn_fc36583a_000146_43f4fdca+0xac0>
  4114f2:	vmovsd xmm0,xmm0,xmm1
  4114f6:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x2052]        # 413550 <__swc_rdata_base_fc36583a+0x440>
  4114fe:	jmp    411504 <__swc_fn_fc36583a_000146_43f4fdca+0xac4>
  411500:	vmovsd xmm0,xmm0,xmm1
  411504:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  41150d:	xor    r8d,r8d
  411510:	vcomisd xmm0,xmm6
  411514:	jb     41152e <__swc_fn_fc36583a_000146_43f4fdca+0xaee>
  411516:	cs nop WORD PTR [rax+rax*1+0x0]
  411520:	vdivsd xmm0,xmm0,xmm6
  411524:	add    r8,0x1
  411528:	vcomisd xmm0,xmm6
  41152c:	jae    411520 <__swc_fn_fc36583a_000146_43f4fdca+0xae0>
  41152e:	mov    r9,rcx
  411531:	vxorpd xmm2,xmm2,xmm2
  411535:	vcomisd xmm2,xmm1
  411539:	jbe    411542 <__swc_fn_fc36583a_000146_43f4fdca+0xb02>
  41153b:	mov    BYTE PTR [rcx],0x2d
  41153e:	lea    r9,[rcx+0x1]
  411542:	vcvttsd2si rdx,xmm0
  411547:	mov    r10b,dl
  41154a:	add    r10b,0x30
  41154e:	mov    BYTE PTR [r9],r10b
  411551:	vxorpd xmm1,xmm1,xmm1
  411555:	movzx  edx,dl
  411558:	vcvtsi2sd xmm1,xmm1,rdx
  41155d:	vsubsd xmm0,xmm0,xmm1
  411561:	vmulsd xmm0,xmm0,xmm6
  411565:	mov    BYTE PTR [r9+0x1],0x2e
  41156a:	vcvttsd2si rdx,xmm0
  41156f:	mov    r10b,dl
  411572:	add    r10b,0x30
  411576:	mov    BYTE PTR [r9+0x2],r10b
  41157a:	vxorpd xmm1,xmm1,xmm1
  41157e:	movzx  edx,dl
  411581:	vcvtsi2sd xmm1,xmm1,rdx
  411586:	vsubsd xmm0,xmm0,xmm1
  41158a:	vmulsd xmm0,xmm0,xmm6
  41158e:	vcvttsd2si rdx,xmm0
  411593:	mov    r10b,dl
  411596:	add    r10b,0x30
  41159a:	mov    BYTE PTR [r9+0x3],r10b
  41159e:	vxorpd xmm1,xmm1,xmm1
  4115a2:	movzx  edx,dl
  4115a5:	vcvtsi2sd xmm1,xmm1,rdx
  4115aa:	vsubsd xmm0,xmm0,xmm1
  4115ae:	vmulsd xmm0,xmm0,xmm6
  4115b2:	vcvttsd2si rdx,xmm0
  4115b7:	mov    r10b,dl
  4115ba:	add    r10b,0x30
  4115be:	mov    BYTE PTR [r9+0x4],r10b
  4115c2:	vxorpd xmm1,xmm1,xmm1
  4115c6:	movzx  edx,dl
  4115c9:	vcvtsi2sd xmm1,xmm1,rdx
  4115ce:	vsubsd xmm0,xmm0,xmm1
  4115d2:	vmulsd xmm0,xmm0,xmm6
  4115d6:	vcvttsd2si rdx,xmm0
  4115db:	mov    r10b,dl
  4115de:	add    r10b,0x30
  4115e2:	mov    BYTE PTR [r9+0x5],r10b
  4115e6:	vxorpd xmm1,xmm1,xmm1
  4115ea:	movzx  edx,dl
  4115ed:	vcvtsi2sd xmm1,xmm1,rdx
  4115f2:	vsubsd xmm0,xmm0,xmm1
  4115f6:	vmulsd xmm0,xmm0,xmm6
  4115fa:	vcvttsd2si rdx,xmm0
  4115ff:	mov    r10b,dl
  411602:	add    r10b,0x30
  411606:	mov    BYTE PTR [r9+0x6],r10b
  41160a:	vxorpd xmm1,xmm1,xmm1
  41160e:	movzx  edx,dl
  411611:	vcvtsi2sd xmm1,xmm1,rdx
  411616:	vsubsd xmm0,xmm0,xmm1
  41161a:	vmulsd xmm0,xmm0,xmm6
  41161e:	vcvttsd2si rdx,xmm0
  411623:	mov    r10b,dl
  411626:	add    r10b,0x30
  41162a:	mov    BYTE PTR [r9+0x7],r10b
  41162e:	vxorpd xmm1,xmm1,xmm1
  411632:	movzx  edx,dl
  411635:	vcvtsi2sd xmm1,xmm1,rdx
  41163a:	vsubsd xmm0,xmm0,xmm1
  41163e:	vmulsd xmm0,xmm0,xmm6
  411642:	vcvttsd2si rdx,xmm0
  411647:	mov    r10b,dl
  41164a:	add    r10b,0x30
  41164e:	mov    BYTE PTR [r9+0x8],r10b
  411652:	vxorpd xmm1,xmm1,xmm1
  411656:	movzx  edx,dl
  411659:	vcvtsi2sd xmm1,xmm1,rdx
  41165e:	vsubsd xmm0,xmm0,xmm1
  411662:	vmulsd xmm0,xmm0,xmm6
  411666:	vcvttsd2si rdx,xmm0
  41166b:	mov    r10b,dl
  41166e:	add    r10b,0x30
  411672:	mov    BYTE PTR [r9+0x9],r10b
  411676:	vxorpd xmm1,xmm1,xmm1
  41167a:	movzx  edx,dl
  41167d:	vcvtsi2sd xmm1,xmm1,rdx
  411682:	vsubsd xmm0,xmm0,xmm1
  411686:	vmulsd xmm0,xmm0,xmm6
  41168a:	vcvttsd2si rdx,xmm0
  41168f:	mov    r10b,dl
  411692:	add    r10b,0x30
  411696:	mov    BYTE PTR [r9+0xa],r10b
  41169a:	vxorpd xmm1,xmm1,xmm1
  41169e:	movzx  edx,dl
  4116a1:	vcvtsi2sd xmm1,xmm1,rdx
  4116a6:	vsubsd xmm0,xmm0,xmm1
  4116aa:	vmulsd xmm0,xmm0,xmm6
  4116ae:	vcvttsd2si rdx,xmm0
  4116b3:	mov    r10b,dl
  4116b6:	add    r10b,0x30
  4116ba:	mov    BYTE PTR [r9+0xb],r10b
  4116be:	lea    r10,[r9+0x4]
  4116c2:	vxorpd xmm1,xmm1,xmm1
  4116c6:	movzx  edx,dl
  4116c9:	vcvtsi2sd xmm1,xmm1,rdx
  4116ce:	vsubsd xmm0,xmm0,xmm1
  4116d2:	vmulsd xmm0,xmm0,xmm6
  4116d6:	vcvttsd2si rdx,xmm0
  4116db:	mov    r11b,dl
  4116de:	add    r11b,0x30
  4116e2:	mov    BYTE PTR [r9+0xc],r11b
  4116e6:	vxorpd xmm1,xmm1,xmm1
  4116ea:	movzx  edx,dl
  4116ed:	vcvtsi2sd xmm1,xmm1,rdx
  4116f2:	vsubsd xmm0,xmm0,xmm1
  4116f6:	vmulsd xmm0,xmm0,xmm6
  4116fa:	vcvttsd2si rdx,xmm0
  4116ff:	mov    r11b,dl
  411702:	add    r11b,0x30
  411706:	mov    BYTE PTR [r9+0xd],r11b
  41170a:	lea    r10,[r10+0x2]
  41170e:	vxorpd xmm1,xmm1,xmm1
  411712:	movzx  edx,dl
  411715:	vcvtsi2sd xmm1,xmm1,rdx
  41171a:	vsubsd xmm0,xmm0,xmm1
  41171e:	vmulsd xmm0,xmm0,xmm6
  411722:	vcvttsd2si rdx,xmm0
  411727:	mov    r11b,dl
  41172a:	add    r11b,0x30
  41172e:	mov    BYTE PTR [r9+0xe],r11b
  411732:	vxorpd xmm1,xmm1,xmm1
  411736:	movzx  edx,dl
  411739:	vcvtsi2sd xmm1,xmm1,rdx
  41173e:	vsubsd xmm0,xmm0,xmm1
  411742:	vmulsd xmm0,xmm0,xmm6
  411746:	vcvttsd2si rdx,xmm0
  41174b:	mov    r11b,dl
  41174e:	add    r11b,0x30
  411752:	mov    BYTE PTR [r9+0xf],r11b
  411756:	lea    r10,[r10+0x2]
  41175a:	lea    r10,[r10+0x2]
  41175e:	lea    r10,[r10+0x2]
  411762:	lea    r10,[r10+0x2]
  411766:	lea    r10,[r10+0x2]
  41176a:	vxorpd xmm1,xmm1,xmm1
  41176e:	movzx  edx,dl
  411771:	vcvtsi2sd xmm1,xmm1,rdx
  411776:	vsubsd xmm0,xmm0,xmm1
  41177a:	vmulsd xmm0,xmm0,xmm6
  41177e:	vcvttsd2si rdx,xmm0
  411783:	mov    r11b,dl
  411786:	add    r11b,0x30
  41178a:	mov    BYTE PTR [r9+0x10],r11b
  41178e:	vxorpd xmm1,xmm1,xmm1
  411792:	movzx  edx,dl
  411795:	vcvtsi2sd xmm1,xmm1,rdx
  41179a:	vsubsd xmm0,xmm0,xmm1
  41179e:	vmulsd xmm0,xmm0,xmm6
  4117a2:	vcvttsd2si rdx,xmm0
  4117a7:	add    dl,0x30
  4117aa:	mov    BYTE PTR [r9+0x11],dl
  4117ae:	mov    BYTE PTR [r10+0x2],0x65
  4117b3:	lea    r9,[r10+0x3]
  4117b7:	test   r8,r8
  4117ba:	jl     4117c3 <__swc_fn_fc36583a_000146_43f4fdca+0xd83>
  4117bc:	mov    BYTE PTR [r9],0x2b
  4117c0:	inc    r9
  4117c3:	mov    r10,r9
  4117c6:	mov    rdx,r8
  4117c9:	nop    DWORD PTR [rax+0x0]
  4117d0:	mov    r11,rdx
  4117d3:	movabs rdx,0x6666666666666667
  4117dd:	mov    rax,r11
  4117e0:	imul   rdx
  4117e3:	sar    rdx,0x2
  4117e7:	mov    r12,rdx
  4117ea:	shr    rdx,0x3f
  4117ee:	add    r12,rdx
  4117f1:	mov    rdx,r12
  4117f4:	imul   r13,r12,0xa
  4117f8:	sub    r11,r13
  4117fb:	mov    r13,QWORD PTR [rip+0x1d3e]        # 413540 <__swc_rdata_base_fc36583a+0x430>
  411802:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411807:	mov    BYTE PTR [r10],r11b
  41180a:	lea    r11,[r10+0x1]
  41180e:	mov    r10,r11
  411811:	test   r12,r12
  411814:	jne    4117d0 <__swc_fn_fc36583a_000146_43f4fdca+0xd90>
  411816:	test   r8,r8
  411819:	jge    411823 <__swc_fn_fc36583a_000146_43f4fdca+0xde3>
  41181b:	mov    BYTE PTR [r11],0x2d
  41181f:	lea    r10,[r11+0x1]
  411823:	mov    BYTE PTR [r10],0x0
  411827:	sub    r10,0x1
  41182b:	nop    DWORD PTR [rax+rax*1+0x0]
  411830:	cmp    r9,r10
  411833:	jae    411aa8 <__swc_fn_fc36583a_000146_43f4fdca+0x1068>
  411839:	mov    al,BYTE PTR [r10]
  41183c:	mov    dl,BYTE PTR [r9]
  41183f:	mov    BYTE PTR [r10],dl
  411842:	sub    r10,0x1
  411846:	mov    BYTE PTR [r9],al
  411849:	inc    r9
  41184c:	jmp    411830 <__swc_fn_fc36583a_000146_43f4fdca+0xdf0>
  41184e:	vcvttsd2si rdx,xmm0
  411853:	mov    r8,rdx
  411856:	vxorpd xmm1,xmm1,xmm1
  41185a:	vcvtsi2sd xmm1,xmm1,rdx
  41185f:	vsubsd xmm1,xmm0,xmm1
  411863:	mov    r9d,0x8
  411869:	vxorpd xmm2,xmm2,xmm2
  41186d:	vcomisd xmm2,xmm1
  411871:	ja     41187e <__swc_fn_fc36583a_000146_43f4fdca+0xe3e>
  411873:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41187c:	jmp    41188f <__swc_fn_fc36583a_000146_43f4fdca+0xe4f>
  41187e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1cca]        # 413550 <__swc_rdata_base_fc36583a+0x440>
  411886:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41188f:	test   r9d,r9d
  411892:	je     4118a9 <__swc_fn_fc36583a_000146_43f4fdca+0xe69>
  411894:	cs nop WORD PTR [rax+rax*1+0x0]
  41189e:	xchg   ax,ax
  4118a0:	vmulsd xmm1,xmm1,xmm6
  4118a4:	dec    r9d
  4118a7:	jne    4118a0 <__swc_fn_fc36583a_000146_43f4fdca+0xe60>
  4118a9:	vcvttsd2si r9,xmm1
  4118ae:	mov    r10,r9
  4118b1:	vxorpd xmm2,xmm2,xmm2
  4118b5:	vcvtsi2sd xmm2,xmm2,r9
  4118ba:	vsubsd xmm1,xmm1,xmm2
  4118be:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  4118c7:	vcomisd xmm1,xmm6
  4118cb:	lea    r9,[r9+0x1]
  4118cf:	cmova  r10,r9
  4118d3:	cmp    r10,0x5f5e100
  4118da:	jne    4118f3 <__swc_fn_fc36583a_000146_43f4fdca+0xeb3>
  4118dc:	lea    r8,[rdx-0x1]
  4118e0:	vxorpd xmm1,xmm1,xmm1
  4118e4:	vcomisd xmm1,xmm0
  4118e8:	lea    rdx,[rdx+0x1]
  4118ec:	cmovbe r8,rdx
  4118f0:	xor    r10d,r10d
  4118f3:	mov    r9,rcx
  4118f6:	test   r8,r8
  4118f9:	jne    411919 <__swc_fn_fc36583a_000146_43f4fdca+0xed9>
  4118fb:	vxorpd xmm1,xmm1,xmm1
  4118ff:	vcomisd xmm1,xmm0
  411903:	jbe    41190c <__swc_fn_fc36583a_000146_43f4fdca+0xecc>
  411905:	mov    BYTE PTR [rcx],0x2d
  411908:	lea    r9,[rcx+0x1]
  41190c:	mov    BYTE PTR [r9],0x30
  411910:	add    r9,0x1
  411914:	jmp    4119ab <__swc_fn_fc36583a_000146_43f4fdca+0xf6b>
  411919:	mov    r9,rcx
  41191c:	mov    rdx,r8
  41191f:	nop
  411920:	mov    r11,rdx
  411923:	movabs rdx,0x6666666666666667
  41192d:	mov    r15,rax
  411930:	mov    rax,r11
  411933:	imul   rdx
  411936:	mov    r12,rdx
  411939:	mov    rax,r15
  41193c:	sar    r12,0x2
  411940:	mov    rdx,r12
  411943:	shr    rdx,0x3f
  411947:	add    r12,rdx
  41194a:	mov    rdx,r12
  41194d:	imul   r13,r12,0xa
  411951:	sub    r11,r13
  411954:	mov    r13,QWORD PTR [rip+0x1be5]        # 413540 <__swc_rdata_base_fc36583a+0x430>
  41195b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411960:	mov    BYTE PTR [r9],r11b
  411963:	lea    r11,[r9+0x1]
  411967:	mov    r9,r11
  41196a:	test   r12,r12
  41196d:	jne    411920 <__swc_fn_fc36583a_000146_43f4fdca+0xee0>
  41196f:	test   r8,r8
  411972:	jge    41197c <__swc_fn_fc36583a_000146_43f4fdca+0xf3c>
  411974:	mov    BYTE PTR [r11],0x2d
  411978:	lea    r9,[r11+0x1]
  41197c:	mov    rdx,r9
  41197f:	mov    BYTE PTR [r9],0x0
  411983:	sub    r9,0x1
  411987:	mov    r8,rcx
  41198a:	cmp    r8,r9
  41198d:	jae    4119a8 <__swc_fn_fc36583a_000146_43f4fdca+0xf68>
  41198f:	nop
  411990:	mov    r11b,BYTE PTR [r9]
  411993:	mov    r12b,BYTE PTR [r8]
  411996:	mov    BYTE PTR [r9],r12b
  411999:	sub    r9,0x1
  41199d:	mov    BYTE PTR [r8],r11b
  4119a0:	inc    r8
  4119a3:	cmp    r8,r9
  4119a6:	jb     411990 <__swc_fn_fc36583a_000146_43f4fdca+0xf50>
  4119a8:	mov    r9,rdx
  4119ab:	mov    BYTE PTR [r9],0x2e
  4119af:	add    r9,0x1
  4119b3:	xor    r8d,r8d
  4119b6:	test   r10,r10
  4119b9:	je     4119ff <__swc_fn_fc36583a_000146_43f4fdca+0xfbf>
  4119bb:	mov    r11d,0x989680
  4119c1:	cmp    r10,r11
  4119c4:	jge    4119ff <__swc_fn_fc36583a_000146_43f4fdca+0xfbf>
  4119c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4119d0:	inc    r8d
  4119d3:	movabs rdx,0x6666666666666667
  4119dd:	mov    r15,rax
  4119e0:	mov    rax,r11
  4119e3:	imul   rdx
  4119e6:	mov    r11,rdx
  4119e9:	mov    rax,r15
  4119ec:	sar    r11,0x2
  4119f0:	mov    rdx,r11
  4119f3:	shr    rdx,0x3f
  4119f7:	add    r11,rdx
  4119fa:	cmp    r10,r11
  4119fd:	jl     4119d0 <__swc_fn_fc36583a_000146_43f4fdca+0xf90>
  4119ff:	test   r8d,r8d
  411a02:	je     411a1d <__swc_fn_fc36583a_000146_43f4fdca+0xfdd>
  411a04:	cs nop WORD PTR [rax+rax*1+0x0]
  411a0e:	xchg   ax,ax
  411a10:	mov    BYTE PTR [r9],0x30
  411a14:	add    r9,0x1
  411a18:	dec    r8d
  411a1b:	jne    411a10 <__swc_fn_fc36583a_000146_43f4fdca+0xfd0>
  411a1d:	mov    r8,r9
  411a20:	mov    rdx,r10
  411a23:	cs nop WORD PTR [rax+rax*1+0x0]
  411a2d:	nop    DWORD PTR [rax]
  411a30:	mov    r11,rdx
  411a33:	movabs rdx,0x6666666666666667
  411a3d:	mov    rax,r11
  411a40:	imul   rdx
  411a43:	sar    rdx,0x2
  411a47:	mov    r12,rdx
  411a4a:	shr    rdx,0x3f
  411a4e:	add    r12,rdx
  411a51:	mov    rdx,r12
  411a54:	imul   r13,r12,0xa
  411a58:	sub    r11,r13
  411a5b:	mov    r13,QWORD PTR [rip+0x1ade]        # 413540 <__swc_rdata_base_fc36583a+0x430>
  411a62:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411a67:	mov    BYTE PTR [r8],r11b
  411a6a:	lea    r11,[r8+0x1]
  411a6e:	mov    r8,r11
  411a71:	test   r12,r12
  411a74:	jne    411a30 <__swc_fn_fc36583a_000146_43f4fdca+0xff0>
  411a76:	test   r10,r10
  411a79:	jge    411a83 <__swc_fn_fc36583a_000146_43f4fdca+0x1043>
  411a7b:	mov    BYTE PTR [r11],0x2d
  411a7f:	lea    r8,[r11+0x1]
  411a83:	mov    BYTE PTR [r8],0x0
  411a87:	sub    r8,0x1
  411a8b:	cmp    r9,r8
  411a8e:	jae    411aa8 <__swc_fn_fc36583a_000146_43f4fdca+0x1068>
  411a90:	mov    al,BYTE PTR [r8]
  411a93:	mov    dl,BYTE PTR [r9]
  411a96:	mov    BYTE PTR [r8],dl
  411a99:	sub    r8,0x1
  411a9d:	mov    BYTE PTR [r9],al
  411aa0:	inc    r9
  411aa3:	cmp    r9,r8
  411aa6:	jb     411a90 <__swc_fn_fc36583a_000146_43f4fdca+0x1050>
  411aa8:	xor    eax,eax
  411aaa:	test   rcx,rcx
  411aad:	je     411ad0 <__swc_fn_fc36583a_000146_43f4fdca+0x1090>
  411aaf:	mov    rdx,rcx
  411ab2:	mov    r8b,BYTE PTR [rdx]
  411ab5:	test   r8b,r8b
  411ab8:	je     411ad0 <__swc_fn_fc36583a_000146_43f4fdca+0x1090>
  411aba:	nop    WORD PTR [rax+rax*1+0x0]
  411ac0:	add    rdx,0x1
  411ac4:	add    rax,0x1
  411ac8:	mov    r8b,BYTE PTR [rdx]
  411acb:	test   r8b,r8b
  411ace:	jne    411ac0 <__swc_fn_fc36583a_000146_43f4fdca+0x1080>
  411ad0:	mov    QWORD PTR [rsp+0x3f8],rcx
  411ad8:	mov    QWORD PTR [rsp+0x400],rax
  411ae0:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  411ae9:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  411af2:	lea    rcx,[rsp+0x408]
  411afa:	call   4101c0 <__swc_fn_fc36583a_000116_035d76a1>
  411aff:	jmp    411b45 <__swc_fn_fc36583a_000146_43f4fdca+0x1105>
  411b01:	mov    rcx,rdx
  411b04:	call   4101c0 <__swc_fn_fc36583a_000116_035d76a1>
  411b09:	jmp    411b45 <__swc_fn_fc36583a_000146_43f4fdca+0x1105>
  411b0b:	mov    al,BYTE PTR [rdx]
  411b0d:	test   al,al
  411b0f:	je     411b1a <__swc_fn_fc36583a_000146_43f4fdca+0x10da>
  411b11:	lea    rax,[rip+0x1a48]        # 413560 <__swc_rdata_base_fc36583a+0x450>
  411b18:	jmp    411b21 <__swc_fn_fc36583a_000146_43f4fdca+0x10e1>
  411b1a:	lea    rax,[rip+0x1a4f]        # 413570 <__swc_rdata_base_fc36583a+0x460>
  411b21:	mov    rcx,rax
  411b24:	call   4101c0 <__swc_fn_fc36583a_000116_035d76a1>
  411b29:	jmp    411b45 <__swc_fn_fc36583a_000146_43f4fdca+0x1105>
  411b2b:	lea    rcx,[rip+0x1a4e]        # 413580 <__swc_rdata_base_fc36583a+0x470>
  411b32:	call   4101c0 <__swc_fn_fc36583a_000116_035d76a1>
  411b37:	jmp    411b45 <__swc_fn_fc36583a_000146_43f4fdca+0x1105>
  411b39:	lea    rcx,[rip+0x1a40]        # 413580 <__swc_rdata_base_fc36583a+0x470>
  411b40:	call   4101c0 <__swc_fn_fc36583a_000116_035d76a1>
  411b45:	add    rdi,0x1
  411b49:	sub    rsi,0x1
  411b4d:	vmovups xmm0,xmm12
  411b52:	vmovsd xmm6,QWORD PTR [rip+0x1a36]        # 413590 <__swc_rdata_base_fc36583a+0x480>
  411b5a:	test   rsi,rsi
  411b5d:	jne    410b50 <__swc_fn_fc36583a_000146_43f4fdca+0x110>
  411b63:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  411b6c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  411b75:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  411b7e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411b87:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411b90:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411b99:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411ba2:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  411bab:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411bb4:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  411bbd:	add    rsp,0x4e8
  411bc4:	pop    r15
  411bc6:	pop    r13
  411bc8:	pop    r12
  411bca:	pop    rdi
  411bcb:	pop    rsi
  411bcc:	pop    rbx
  411bcd:	ret
	...

0000000000411bd0 <__swc_fn_fc36583a_000149_9e4bc402>:
  411bd0:	vxorps xmm0,xmm0,xmm0
  411bd4:	vmovups XMMWORD PTR [rcx],xmm0
  411bd8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411bdd:	ret
	...

0000000000411be0 <__swc_fn_fc36583a_000152_9e4bc402>:
  411be0:	vxorps xmm0,xmm0,xmm0
  411be4:	vmovups XMMWORD PTR [rcx],xmm0
  411be8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411bed:	vxorps xmm0,xmm0,xmm0
  411bf1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411bf6:	vmovups xmm0,XMMWORD PTR [rip+0x1aa2]        # 4136a0 <__swc_rdata_base_fc36583a+0x590>
  411bfe:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411c03:	vxorps xmm0,xmm0,xmm0
  411c07:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411c0c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411c11:	vxorps xmm0,xmm0,xmm0
  411c15:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  411c1a:	mov    QWORD PTR [rcx+0x70],0x0
  411c22:	ret
	...

0000000000411c30 <__swc_fn_fc36583a_000155_9e4bc402>:
  411c30:	vxorps xmm0,xmm0,xmm0
  411c34:	vmovups XMMWORD PTR [rcx],xmm0
  411c38:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411c3d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411c42:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411c47:	ret
	...

0000000000411c50 <__swc_fn_fc36583a_000158_b43b2f96>:
  411c50:	push   rsi
  411c51:	push   rdi
  411c52:	sub    rsp,0x8
  411c56:	mov    rsi,rcx
  411c59:	mov    rdi,QWORD PTR [rsi+0x50]
  411c5d:	test   rdi,rdi
  411c60:	je     411c67 <__swc_fn_fc36583a_000158_b43b2f96+0x17>
  411c62:	mov    rcx,rsi
  411c65:	call   rdi
  411c67:	mov    QWORD PTR [rsi+0x20],0x0
  411c6f:	mov    rax,QWORD PTR [rsi+0x30]
  411c73:	test   rax,rax
  411c76:	je     411ca4 <__swc_fn_fc36583a_000158_b43b2f96+0x54>
  411c78:	nop    DWORD PTR [rax+rax*1+0x0]
  411c80:	mov    rdi,QWORD PTR [rax+0x8]
  411c84:	mov    rcx,rsi
  411c87:	mov    rdx,QWORD PTR [rax+0x10]
  411c8b:	mov    rax,QWORD PTR [rax+0x18]
  411c8f:	mov    r8,rax
  411c92:	call   409ec0 <__swc_fn_fc36583a_000156_2745c4a5>
  411c97:	mov    QWORD PTR [rsi+0x30],rdi
  411c9b:	mov    rax,QWORD PTR [rsi+0x30]
  411c9f:	test   rax,rax
  411ca2:	jne    411c80 <__swc_fn_fc36583a_000158_b43b2f96+0x30>
  411ca4:	mov    QWORD PTR [rsi+0x38],0x0
  411cac:	add    rsp,0x8
  411cb0:	pop    rdi
  411cb1:	pop    rsi
  411cb2:	ret
	...

0000000000411cc0 <__swc_fn_fc36583a_000161_b5a9d657>:
  411cc0:	push   rbx
  411cc1:	push   rsi
  411cc2:	push   rdi
  411cc3:	push   r12
  411cc5:	sub    rsp,0x188
  411ccc:	mov    rbx,rcx
  411ccf:	lea    rsi,[rip+0x150ba]        # 426d90 <__swc_bss_base_fc36583a+0x2d50>
  411cd6:	mov    rcx,rsi
  411cd9:	call   4098c0 <__swc_fn_fc36583a_000135_e3032dc2>
  411cde:	mov    rax,QWORD PTR [rip+0x150b3]        # 426d98 <__swc_bss_base_fc36583a+0x2d58>
  411ce5:	mov    rdi,rax
  411ce8:	test   rdi,rdi
  411ceb:	je     411d19 <__swc_fn_fc36583a_000161_b5a9d657+0x59>
  411ced:	nop    DWORD PTR [rax]
  411cf0:	cmp    QWORD PTR [rdi+0x8],rbx
  411cf4:	jne    411d0e <__swc_fn_fc36583a_000161_b5a9d657+0x4e>
  411cf6:	mov    rcx,rsi
  411cf9:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  411cfe:	mov    rax,rdi
  411d01:	add    rsp,0x188
  411d08:	pop    r12
  411d0a:	pop    rdi
  411d0b:	pop    rsi
  411d0c:	pop    rbx
  411d0d:	ret
  411d0e:	mov    rax,QWORD PTR [rdi]
  411d11:	mov    rdi,rax
  411d14:	test   rax,rax
  411d17:	jne    411cf0 <__swc_fn_fc36583a_000161_b5a9d657+0x30>
  411d19:	call   40d680 <__swc_fn_fc36583a_000139_7c02fe26>
  411d1e:	mov    rdi,rax
  411d21:	test   rax,rax
  411d24:	jne    411d3d <__swc_fn_fc36583a_000161_b5a9d657+0x7d>
  411d26:	mov    rcx,rsi
  411d29:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  411d2e:	xor    eax,eax
  411d30:	add    rsp,0x188
  411d37:	pop    r12
  411d39:	pop    rdi
  411d3a:	pop    rsi
  411d3b:	pop    rbx
  411d3c:	ret
  411d3d:	lea    rax,[rsp+0x18]
  411d42:	mov    QWORD PTR [rax+0x10],0x0
  411d4a:	mov    QWORD PTR [rax+0x18],0x0
  411d52:	mov    DWORD PTR [rax+0x20],0x0
  411d59:	mov    BYTE PTR [rax+0x24],0x0
  411d5d:	mov    rax,QWORD PTR [rip+0x15034]        # 426d98 <__swc_bss_base_fc36583a+0x2d58>
  411d64:	mov    QWORD PTR [rsp+0x18],rax
  411d69:	mov    QWORD PTR [rsp+0x20],rbx
  411d6e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411d74:	vmovups XMMWORD PTR [rdi],xmm0
  411d78:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  411d7e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  411d83:	mov    rax,QWORD PTR [rsp+0x38]
  411d88:	mov    QWORD PTR [rdi+0x20],rax
  411d8c:	mov    QWORD PTR [rip+0x15005],rdi        # 426d98 <__swc_bss_base_fc36583a+0x2d58>
  411d93:	lea    rax,[rsp+0x40]
  411d98:	mov    QWORD PTR [rax],0x0
  411d9f:	mov    rcx,rbx
  411da2:	mov    rdx,rax
  411da5:	call   4099a0 <__swc_fn_fc36583a_000141_2ce79e3b>
  411daa:	mov    rbx,rax
  411dad:	test   rax,rax
  411db0:	jne    411dca <__swc_fn_fc36583a_000161_b5a9d657+0x10a>
  411db2:	mov    rcx,rsi
  411db5:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  411dba:	mov    rax,rdi
  411dbd:	add    rsp,0x188
  411dc4:	pop    r12
  411dc6:	pop    rdi
  411dc7:	pop    rsi
  411dc8:	pop    rbx
  411dc9:	ret
  411dca:	lea    r12,[rsp+0x50]
  411dcf:	mov    QWORD PTR [r12],0x0
  411dd7:	mov    rcx,rbx
  411dda:	mov    rdx,QWORD PTR [rsp+0x40]
  411ddf:	mov    r8,r12
  411de2:	call   40d730 <__swc_fn_fc36583a_000142_56e56812>
  411de7:	test   rax,rax
  411dea:	jne    411e04 <__swc_fn_fc36583a_000161_b5a9d657+0x144>
  411dec:	mov    rcx,rsi
  411def:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  411df4:	mov    rax,rdi
  411df7:	add    rsp,0x188
  411dfe:	pop    r12
  411e00:	pop    rdi
  411e01:	pop    rsi
  411e02:	pop    rbx
  411e03:	ret
  411e04:	cmp    QWORD PTR [r12],0x10
  411e09:	jb     411f0c <__swc_fn_fc36583a_000161_b5a9d657+0x24c>
  411e0f:	mov    ecx,DWORD PTR [rax]
  411e11:	cmp    ecx,0x42445753
  411e17:	jne    411f0c <__swc_fn_fc36583a_000161_b5a9d657+0x24c>
  411e1d:	mov    ecx,DWORD PTR [rax+0x4]
  411e20:	cmp    ecx,0x1
  411e23:	jne    411f0c <__swc_fn_fc36583a_000161_b5a9d657+0x24c>
  411e29:	mov    ecx,DWORD PTR [rax+0x8]
  411e2c:	mov    edx,DWORD PTR [rax+0xc]
  411e2f:	imul   r8,rcx,0x14
  411e33:	mov    r9,QWORD PTR [rsp+0x50]
  411e38:	sub    r9,0x10
  411e3c:	cmp    r8,r9
  411e3f:	ja     411f0c <__swc_fn_fc36583a_000161_b5a9d657+0x24c>
  411e45:	lea    r8,[r8+0x10]
  411e49:	cmp    rdx,r8
  411e4c:	jb     411f0c <__swc_fn_fc36583a_000161_b5a9d657+0x24c>
  411e52:	mov    r8,QWORD PTR [rsp+0x50]
  411e57:	cmp    rdx,r8
  411e5a:	ja     411f0c <__swc_fn_fc36583a_000161_b5a9d657+0x24c>
  411e60:	xor    r8d,r8d
  411e63:	test   rcx,rcx
  411e66:	jbe    411f32 <__swc_fn_fc36583a_000161_b5a9d657+0x272>
  411e6c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  411e72:	cs nop WORD PTR [rax+rax*1+0x0]
  411e7c:	nop    DWORD PTR [rax+0x0]
  411e80:	imul   r9,r8,0x14
  411e84:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  411e89:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  411e8e:	add    r10,r11
  411e91:	movabs r11,0x100000000
  411e9b:	cmp    r10,r11
  411e9e:	ja     411f0c <__swc_fn_fc36583a_000161_b5a9d657+0x24c>
  411ea0:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  411ea5:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  411eaa:	test   r10d,r10d
  411ead:	setne  r11b
  411eb1:	je     411ecb <__swc_fn_fc36583a_000161_b5a9d657+0x20b>
  411eb3:	cmp    r10d,edx
  411eb6:	setb   r11b
  411eba:	jb     411ecb <__swc_fn_fc36583a_000161_b5a9d657+0x20b>
  411ebc:	vmovq  r11,xmm1
  411ec1:	cmp    r10,r11
  411ec4:	setae  r10b
  411ec8:	mov    r11b,r10b
  411ecb:	mov    r10,r11
  411ece:	test   r11b,r11b
  411ed1:	jne    411ef8 <__swc_fn_fc36583a_000161_b5a9d657+0x238>
  411ed3:	test   r9d,r9d
  411ed6:	setne  r10b
  411eda:	je     411ef8 <__swc_fn_fc36583a_000161_b5a9d657+0x238>
  411edc:	cmp    r9d,edx
  411edf:	setb   r10b
  411ee3:	jb     411ef8 <__swc_fn_fc36583a_000161_b5a9d657+0x238>
  411ee5:	vmovq  r10,xmm1
  411eea:	cmp    r9,r10
  411eed:	setae  r9b
  411ef1:	movzx  r9d,r9b
  411ef5:	mov    r10b,r9b
  411ef8:	test   r10b,r10b
  411efb:	jne    411f0c <__swc_fn_fc36583a_000161_b5a9d657+0x24c>
  411efd:	add    r8,0x1
  411f01:	cmp    r8,rcx
  411f04:	jb     411e80 <__swc_fn_fc36583a_000161_b5a9d657+0x1c0>
  411f0a:	jmp    411f32 <__swc_fn_fc36583a_000161_b5a9d657+0x272>
  411f0c:	xor    ecx,ecx
  411f0e:	cmp    rax,rbx
  411f11:	cmovne rcx,rax
  411f15:	call   410990 <__swc_fn_fc36583a_000143_81c0d993>
  411f1a:	mov    rcx,rsi
  411f1d:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  411f22:	mov    rax,rdi
  411f25:	add    rsp,0x188
  411f2c:	pop    r12
  411f2e:	pop    rdi
  411f2f:	pop    rsi
  411f30:	pop    rbx
  411f31:	ret
  411f32:	mov    QWORD PTR [rdi+0x10],rax
  411f36:	mov    rcx,QWORD PTR [rsp+0x50]
  411f3b:	mov    QWORD PTR [rdi+0x18],rcx
  411f3f:	mov    eax,DWORD PTR [rax+0x8]
  411f42:	mov    DWORD PTR [rdi+0x20],eax
  411f45:	rex mov BYTE PTR [rdi+0x24],0x1
  411f4a:	mov    rcx,rsi
  411f4d:	call   40d670 <__swc_fn_fc36583a_000136_3e875c27>
  411f52:	mov    rax,rdi
  411f55:	add    rsp,0x188
  411f5c:	pop    r12
  411f5e:	pop    rdi
  411f5f:	pop    rsi
  411f60:	pop    rbx
  411f61:	ret
	...

0000000000411f70 <__swc_fn_fc36583a_000164_1962e12a>:
  411f70:	push   rsi
  411f71:	push   rdi
  411f72:	push   r12
  411f74:	mov    rsi,rdx
  411f77:	mov    rdi,rcx
  411f7a:	mov    rcx,QWORD PTR [rip+0x14dbf]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  411f81:	test   rcx,rcx
  411f84:	jne    411f96 <__swc_fn_fc36583a_000164_1962e12a+0x26>
  411f86:	call   40a1d0 <__swc_fn_fc36583a_000165_cf398896>
  411f8b:	lea    rcx,[rax+0x1]
  411f8f:	mov    QWORD PTR [rip+0x14daa],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  411f96:	dec    rcx
  411f99:	call   411fc0 <__swc_fn_fc36583a_000167_fce60b2b>
  411f9e:	mov    r12,QWORD PTR [rax+0xbe0]
  411fa5:	test   r12,r12
  411fa8:	setne  al
  411fab:	je     411fb6 <__swc_fn_fc36583a_000164_1962e12a+0x46>
  411fad:	mov    rcx,rdi
  411fb0:	mov    rdx,rsi
  411fb3:	call   r12
  411fb6:	pop    r12
  411fb8:	pop    rdi
  411fb9:	pop    rsi
  411fba:	ret
  411fbb:	add    BYTE PTR [rax],al
  411fbd:	add    BYTE PTR [rax],al
	...

0000000000411fc0 <__swc_fn_fc36583a_000167_fce60b2b>:
  411fc0:	push   r12
  411fc2:	push   rdi
  411fc3:	push   rsi
  411fc4:	sub    rsp,0xd0
  411fcb:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  411fd1:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  411fd7:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  411fdd:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  411fe3:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  411fe9:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  411fef:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  411ff8:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  412001:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  41200a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  412013:	mov    r12,rcx
  412016:	mov    edi,ecx
  412018:	xor    eax,eax
  41201a:	call   407000 <pthread_getspecific@plt>
  41201f:	test   rax,rax
  412022:	je     412026 <__swc_fn_fc36583a_000167_fce60b2b+0x66>
  412024:	jmp    41202e <__swc_fn_fc36583a_000167_fce60b2b+0x6e>
  412026:	mov    rcx,r12
  412029:	call   40a230 <__swc_fn_fc36583a_000168_92b7d63c>
  41202e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  412034:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  41203a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  412040:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  412046:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  41204c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  412052:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  41205b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  412064:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  41206d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  412076:	add    rsp,0xd0
  41207d:	pop    rsi
  41207e:	pop    rdi
  41207f:	pop    r12
  412081:	ret
	...

0000000000412090 <__swc_fn_fc36583a_000170_fa3003e2>:
  412090:	push   rsi
  412091:	sub    rsp,0x30
  412095:	lea    rsi,[rip+0x14d0c]        # 426da8 <__swc_bss_base_fc36583a+0x2d68>
  41209c:	mov    rax,QWORD PTR [rsi]
  41209f:	test   rax,rax
  4120a2:	je     4120aa <__swc_fn_fc36583a_000170_fa3003e2+0x1a>
  4120a4:	add    rsp,0x30
  4120a8:	pop    rsi
  4120a9:	ret
  4120aa:	mov    ecx,0x3
  4120af:	mov    edx,0x10
  4120b4:	call   40fac0 <__swc_fn_fc36583a_000107_4796e893>
  4120b9:	test   rax,rax
  4120bc:	jne    4120cd <__swc_fn_fc36583a_000170_fa3003e2+0x3d>
  4120be:	mov    QWORD PTR [rsp+0x18],rax
  4120c3:	call   40d1d0 <__swc_fn_fc36583a_000118_7f430081>
  4120c8:	mov    rax,QWORD PTR [rsp+0x18]
  4120cd:	mov    rcx,rax
  4120d0:	xchg   QWORD PTR [rsi],rcx
  4120d3:	add    rsp,0x30
  4120d7:	pop    rsi
  4120d8:	ret
  4120d9:	add    BYTE PTR [rax],al
  4120db:	add    BYTE PTR [rax],al
  4120dd:	add    BYTE PTR [rax],al
	...

00000000004120e0 <__swc_fn_fc36583a_000173_f69b1f05>:
  4120e0:	push   rsi
  4120e1:	push   rdi
  4120e2:	sub    rsp,0x8
  4120e6:	mov    rsi,rdx
  4120e9:	mov    rdi,rcx
  4120ec:	mov    rax,QWORD PTR [rsi+0x8]
  4120f0:	test   rax,rax
  4120f3:	je     4120fd <__swc_fn_fc36583a_000173_f69b1f05+0x1d>
  4120f5:	mov    rcx,QWORD PTR [rsi]
  4120f8:	mov    QWORD PTR [rax],rcx
  4120fb:	jmp    412104 <__swc_fn_fc36583a_000173_f69b1f05+0x24>
  4120fd:	mov    rax,QWORD PTR [rsi]
  412100:	mov    QWORD PTR [rdi+0x8],rax
  412104:	mov    rax,QWORD PTR [rsi]
  412107:	test   rax,rax
  41210a:	je     412114 <__swc_fn_fc36583a_000173_f69b1f05+0x34>
  41210c:	mov    rcx,QWORD PTR [rsi+0x8]
  412110:	mov    QWORD PTR [rax+0x8],rcx
  412114:	mov    rcx,rdi
  412117:	mov    rdx,QWORD PTR [rsi+0x10]
  41211b:	mov    r8,QWORD PTR [rsi+0x18]
  41211f:	mov    r9,0xffffffffffffffff
  412126:	call   40dda0 <__swc_fn_fc36583a_000172_97fbc432>
  41212b:	mov    QWORD PTR [rsi+0x18],0x0
  412133:	mov    rax,QWORD PTR [rdi+0x8]
  412137:	test   rax,rax
  41213a:	jne    41214c <__swc_fn_fc36583a_000173_f69b1f05+0x6c>
  41213c:	call   412090 <__swc_fn_fc36583a_000170_fa3003e2>
  412141:	xor    ecx,ecx
  412143:	mov    QWORD PTR [rax+0x8],rcx
  412147:	xor    ecx,ecx
  412149:	mov    QWORD PTR [rax],rcx
  41214c:	add    rsp,0x8
  412150:	pop    rdi
  412151:	pop    rsi
  412152:	ret
	...

0000000000412160 <__swc_fn_fc36583a_000176_1ca87929>:
  412160:	push   rdi
  412161:	push   rsi
  412162:	sub    rsp,0xb8
  412169:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41216f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  412175:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41217b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  412181:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  412187:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41218d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  412193:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41219c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4121a5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4121ae:	vxorps xmm0,xmm0,xmm0
  4121b2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4121b8:	mov    edi,0x1
  4121bd:	lea    rsi,[rsp+0x8]
  4121c2:	xor    eax,eax
  4121c4:	call   4071d0 <clock_gettime@plt>
  4121c9:	vxorpd xmm0,xmm0,xmm0
  4121cd:	mov    rax,QWORD PTR [rsp+0x8]
  4121d2:	vcvtsi2sd xmm0,xmm0,rax
  4121d7:	vxorpd xmm1,xmm1,xmm1
  4121db:	mov    rax,QWORD PTR [rsp+0x10]
  4121e0:	vcvtsi2sd xmm1,xmm1,rax
  4121e5:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x171b]        # 413908 <__swc_rdata_base_fc36583a+0x7f8>
  4121ed:	vaddsd xmm0,xmm0,xmm1
  4121f1:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4121f7:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4121fd:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  412203:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  412209:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  41220f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  412215:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41221b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  412224:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  41222d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  412236:	add    rsp,0xb8
  41223d:	pop    rsi
  41223e:	pop    rdi
  41223f:	ret
