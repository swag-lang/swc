
/workspace/prompt2-20261115/batch7-placement-micro/new/nbody/nbody:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <clock_gettime@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <clock_gettime@GLIBC_2.17>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <pthread_getspecific@plt>:
  407010:	jmp    QWORD PTR [rip+0xc002]        # 413018 <pthread_getspecific@GLIBC_2.34>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <mmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xbffa]        # 413020 <mmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xbff2]        # 413028 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <munmap@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfea]        # 413030 <munmap@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <madvise@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfe2]        # 413038 <madvise@GLIBC_2.2.5>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <exit@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfda]        # 413040 <exit@GLIBC_2.2.5>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <pthread_key_delete@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfd2]        # 413048 <pthread_key_delete@GLIBC_2.34>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <gettid@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfca]        # 413050 <gettid@GLIBC_2.30>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <syscall@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfc2]        # 413058 <syscall@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <malloc@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfba]        # 413060 <malloc@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <open@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfb2]        # 413068 <open@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <flock@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfaa]        # 413070 <flock@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <__errno_location@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbfa2]        # 413078 <__errno_location@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <close@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf9a]        # 413080 <close@GLIBC_2.2.5>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <getpid@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf92]        # 413088 <getpid@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <opendir@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf8a]        # 413090 <opendir@GLIBC_2.2.5>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <dirfd@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf82]        # 413098 <dirfd@GLIBC_2.2.5>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <readdir@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf7a]        # 4130a0 <readdir@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <readlinkat@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf72]        # 4130a8 <readlinkat@GLIBC_2.4>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <openat@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf6a]        # 4130b0 <openat@GLIBC_2.4>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <closedir@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf62]        # 4130b8 <closedir@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <lseek@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <lseek@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <memfd_create@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <memfd_create@GLIBC_2.27>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <ftruncate@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <ftruncate@GLIBC_2.2.5>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <write@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <write@GLIBC_2.2.5>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <backtrace@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <backtrace@GLIBC_2.2.5>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <pthread_setspecific@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <pthread_setspecific@GLIBC_2.34>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <__x86_get_cpuid_feature_leaf@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <free@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <free@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <pthread_key_create@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <pthread_key_create@GLIBC_2.34>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <dladdr@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <dladdr@GLIBC_2.34>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_6b1cf01f_000176_718d7b54+0x890>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   4099a0 <__swc_fn_6b1cf01f_000123_540bf7e8>
  40724e:	xor    ecx,ecx
  407250:	call   4090c0 <__swc_fn_6b1cf01f_000096_4f209617>
  407255:	call   40a560 <__swc_fn_6b1cf01f_000001_0ce64436>
  40725a:	call   40cd70 <__swc_fn_6b1cf01f_000097_65137b72>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_6b1cf01f_000000_1ca87929>:
  407270:	push   rdi
  407271:	push   rsi
  407272:	sub    rsp,0xb8
  407279:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40727f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  407285:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40728b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  407291:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  407297:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40729d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4072a3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4072ac:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4072b5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4072be:	vxorps xmm0,xmm0,xmm0
  4072c2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4072c8:	mov    edi,0x1
  4072cd:	lea    rsi,[rsp+0x8]
  4072d2:	xor    eax,eax
  4072d4:	call   407000 <clock_gettime@plt>
  4072d9:	vxorpd xmm0,xmm0,xmm0
  4072dd:	mov    rax,QWORD PTR [rsp+0x8]
  4072e2:	vcvtsi2sd xmm0,xmm0,rax
  4072e7:	vxorpd xmm1,xmm1,xmm1
  4072eb:	mov    rax,QWORD PTR [rsp+0x10]
  4072f0:	vcvtsi2sd xmm1,xmm1,rax
  4072f5:	vdivsd xmm1,xmm1,QWORD PTR [rip+0xbe13]        # 413110 <__swc_rdata_base_6b1cf01f>
  4072fd:	vaddsd xmm0,xmm0,xmm1
  407301:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  407307:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40730d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  407313:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  407319:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40731f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  407325:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40732b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  407334:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40733d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  407346:	add    rsp,0xb8
  40734d:	pop    rsi
  40734e:	pop    rdi
  40734f:	ret
	...

0000000000407360 <__swc_fn_6b1cf01f_000003_9ee35b18>:
  407360:	vxorps xmm0,xmm0,xmm0
  407364:	xor    eax,eax
  407366:	cs nop WORD PTR [rax+rax*1+0x0]
  407370:	cs nop WORD PTR [rax+rax*1+0x0]
  40737a:	nop    WORD PTR [rax+rax*1+0x0]
  407380:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  407385:	add    rax,0x10
  407389:	cmp    rax,0x2080
  407390:	jne    407380 <__swc_fn_6b1cf01f_000003_9ee35b18+0x20>
  407392:	ret
	...

00000000004073a0 <__swc_fn_6b1cf01f_000006_d64b2baa>:
  4073a0:	push   rsi
  4073a1:	push   rdi
  4073a2:	push   r12
  4073a4:	push   r13
  4073a6:	push   r14
  4073a8:	mov    rsi,rcx
  4073ab:	mov    edi,r10d
  4073ae:	mov    r12,rcx
  4073b1:	mov    r13,r9
  4073b4:	mov    ecx,DWORD PTR [rdx+0x28]
  4073b7:	shlx   r14d,r8d,ecx
  4073bc:	mov    rcx,rdx
  4073bf:	mov    edx,r8d
  4073c2:	call   40b620 <__swc_fn_6b1cf01f_000013_9dea5065>
  4073c7:	mov    rcx,rax
  4073ca:	mov    eax,DWORD PTR [r12+0x3c]
  4073cf:	xor    edx,edx
  4073d1:	div    rdi
  4073d4:	vxorps xmm0,xmm0,xmm0
  4073d8:	vmovdqu XMMWORD PTR [rsi],xmm0
  4073dc:	mov    QWORD PTR [r12+0x60],0x0
  4073e5:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  4073ea:	mov    QWORD PTR [r12+0x10],rcx
  4073ef:	imul   rax,rdi
  4073f3:	lea    rdx,[rcx+rax*1]
  4073f7:	mov    QWORD PTR [r12+0x18],rdx
  4073fc:	mov    QWORD PTR [r12+0x20],rcx
  407401:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  407406:	mov    DWORD PTR [r12+0x28],0x0
  40740f:	mov    DWORD PTR [r12+0x68],0x0
  407418:	mov    BYTE PTR [r12+0x39],r13b
  40741d:	mov    BYTE PTR [r12+0x3a],r14b
  407422:	mov    BYTE PTR [r12+0x3b],0x1
  407428:	mov    DWORD PTR [r12+0x6c],0x0
  407431:	mov    rcx,r12
  407434:	mov    edx,edi
  407436:	call   40b580 <__swc_fn_6b1cf01f_000007_065ed5b1>
  40743b:	pop    r14
  40743d:	pop    r13
  40743f:	pop    r12
  407441:	pop    rdi
  407442:	pop    rsi
  407443:	ret
	...

0000000000407450 <__swc_fn_6b1cf01f_000009_c3647f66>:
  407450:	mov    r8d,0x1
  407456:	xor    eax,eax
  407458:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40745e:	test   eax,eax
  407460:	jne    407450 <__swc_fn_6b1cf01f_000009_c3647f66>
  407462:	ret
	...

0000000000407470 <__swc_fn_6b1cf01f_000012_524c1f23>:
  407470:	lea    r8,[rcx+0x60]
  407474:	mov    rax,QWORD PTR [r8]
  407477:	mov    r9,rax
  40747a:	nop    WORD PTR [rax+rax*1+0x0]
  407480:	mov    QWORD PTR [rdx],r9
  407483:	mov    rax,r9
  407486:	lock cmpxchg QWORD PTR [r8],rdx
  40748b:	cmp    rax,r9
  40748e:	jne    4074f7 <__swc_fn_6b1cf01f_000012_524c1f23+0x87>
  407490:	mov    eax,DWORD PTR [rcx+0x6c]
  407493:	test   eax,eax
  407495:	je     4074f6 <__swc_fn_6b1cf01f_000012_524c1f23+0x86>
  407497:	lea    rdx,[rcx+0x70]
  40749b:	mov    r9d,0x1
  4074a1:	xor    eax,eax
  4074a3:	lock cmpxchg DWORD PTR [rdx],r9d
  4074a8:	test   eax,eax
  4074aa:	jne    4074f6 <__swc_fn_6b1cf01f_000012_524c1f23+0x86>
  4074ac:	mov    rax,rcx
  4074af:	and    rax,0xffffffffffc00000
  4074b6:	mov    rax,QWORD PTR [rax+0x8]
  4074ba:	test   rax,rax
  4074bd:	jne    4074c5 <__swc_fn_6b1cf01f_000012_524c1f23+0x55>
  4074bf:	xor    eax,eax
  4074c1:	xchg   DWORD PTR [rdx],eax
  4074c3:	jmp    4074f6 <__swc_fn_6b1cf01f_000012_524c1f23+0x86>
  4074c5:	lea    rdx,[rax+0x2a80]
  4074cc:	mov    rax,QWORD PTR [rdx]
  4074cf:	mov    r8,rax
  4074d2:	cs nop WORD PTR [rax+rax*1+0x0]
  4074dc:	nop    DWORD PTR [rax+0x0]
  4074e0:	mov    QWORD PTR [rcx+0x78],r8
  4074e4:	mov    rax,r8
  4074e7:	lock cmpxchg QWORD PTR [rdx],rcx
  4074ec:	cmp    rax,r8
  4074ef:	je     4074f6 <__swc_fn_6b1cf01f_000012_524c1f23+0x86>
  4074f1:	mov    r8,rax
  4074f4:	jmp    4074e0 <__swc_fn_6b1cf01f_000012_524c1f23+0x70>
  4074f6:	ret
  4074f7:	mov    r9,rax
  4074fa:	jmp    407480 <__swc_fn_6b1cf01f_000012_524c1f23+0x10>
	...

0000000000407500 <__swc_fn_6b1cf01f_000015_efc44797>:
  407500:	push   rsi
  407501:	push   rdi
  407502:	push   r12
  407504:	push   r13
  407506:	push   r14
  407508:	push   r15
  40750a:	push   rbx
  40750b:	sub    rsp,0x30
  40750f:	mov    QWORD PTR [rsp+0x18],r8
  407514:	mov    rsi,rcx
  407517:	mov    rdi,rdx
  40751a:	mov    rdx,QWORD PTR [rsi+0x40]
  40751e:	xchg   ax,ax
  407520:	mov    rax,rdx
  407523:	not    rax
  407526:	and    rax,QWORD PTR [rsi+0x20]
  40752a:	test   rax,rax
  40752d:	jne    407541 <__swc_fn_6b1cf01f_000015_efc44797+0x41>
  40752f:	xor    eax,eax
  407531:	add    rsp,0x30
  407535:	pop    rbx
  407536:	pop    r15
  407538:	pop    r14
  40753a:	pop    r13
  40753c:	pop    r12
  40753e:	pop    rdi
  40753f:	pop    rsi
  407540:	ret
  407541:	xor    ecx,ecx
  407543:	tzcnt  rcx,rax
  407548:	lea    r12,[rsp+0x8]
  40754d:	mov    DWORD PTR [rsp+0x8],ecx
  407551:	mov    r13d,0x1
  407557:	shl    r13,cl
  40755a:	mov    rcx,rdx
  40755d:	or     rcx,r13
  407560:	mov    rax,rdx
  407563:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  407569:	cmp    rax,rdx
  40756c:	je     407573 <__swc_fn_6b1cf01f_000015_efc44797+0x73>
  40756e:	mov    rdx,rax
  407571:	jmp    407520 <__swc_fn_6b1cf01f_000015_efc44797+0x20>
  407573:	mov    eax,DWORD PTR [r12]
  407577:	shl    rax,0x4
  40757b:	lea    r14,[rsi+rax*8+0x80]
  407583:	mov    rcx,rsi
  407586:	mov    rax,r12
  407589:	mov    edx,DWORD PTR [rax]
  40758b:	call   40b620 <__swc_fn_6b1cf01f_000013_9dea5065>
  407590:	mov    r15,rax
  407593:	mov    rcx,rsi
  407596:	mov    rdx,r13
  407599:	call   40b780 <__swc_fn_6b1cf01f_000019_fd2b165c>
  40759e:	test   al,al
  4075a0:	je     4075d8 <__swc_fn_6b1cf01f_000015_efc44797+0xd8>
  4075a2:	mov    ecx,DWORD PTR [r14+0x3c]
  4075a6:	lea    rdx,[rip+0x1caab]        # 424058 <__swc_bss_base_6b1cf01f+0x18>
  4075ad:	mov    r8,QWORD PTR [rip+0x1caa4]        # 424058 <__swc_bss_base_6b1cf01f+0x18>
  4075b4:	cs nop WORD PTR [rax+rax*1+0x0]
  4075be:	xchg   ax,ax
  4075c0:	mov    r9,r8
  4075c3:	sub    r9,rcx
  4075c6:	mov    rax,r8
  4075c9:	lock cmpxchg QWORD PTR [rdx],r9
  4075ce:	cmp    rax,r8
  4075d1:	je     407639 <__swc_fn_6b1cf01f_000015_efc44797+0x139>
  4075d3:	mov    r8,rax
  4075d6:	jmp    4075c0 <__swc_fn_6b1cf01f_000015_efc44797+0xc0>
  4075d8:	mov    rcx,rsi
  4075db:	mov    rax,r12
  4075de:	mov    edx,DWORD PTR [rax]
  4075e0:	call   40f900 <__swc_fn_6b1cf01f_000014_9afb7cfb>
  4075e5:	mov    rcx,r15
  4075e8:	and    rcx,0xffffffffffff0000
  4075ef:	lea    rcx,[rcx+0x10000]
  4075f6:	mov    rbx,rax
  4075f9:	cmp    rax,rcx
  4075fc:	cmova  rbx,rcx
  407600:	mov    rax,rbx
  407603:	sub    rax,r15
  407606:	mov    rcx,r15
  407609:	mov    rdx,rax
  40760c:	call   40f750 <__swc_fn_6b1cf01f_000005_f7acedb0>
  407611:	test   al,al
  407613:	jne    407632 <__swc_fn_6b1cf01f_000015_efc44797+0x132>
  407615:	mov    rcx,rsi
  407618:	mov    rdx,r13
  40761b:	call   40fab0 <__swc_fn_6b1cf01f_000020_c8f5f27c>
  407620:	xor    eax,eax
  407622:	add    rsp,0x30
  407626:	pop    rbx
  407627:	pop    r15
  407629:	pop    r14
  40762b:	pop    r13
  40762d:	pop    r12
  40762f:	pop    rdi
  407630:	pop    rsi
  407631:	ret
  407632:	sub    rbx,r15
  407635:	mov    DWORD PTR [r14+0x3c],ebx
  407639:	mov    rcx,r14
  40763c:	mov    rdx,rsi
  40763f:	mov    r8d,DWORD PTR [r12]
  407643:	mov    r9d,edi
  407646:	mov    rbx,QWORD PTR [rsp+0x18]
  40764b:	mov    r10d,ebx
  40764e:	call   4073a0 <__swc_fn_6b1cf01f_000006_d64b2baa>
  407653:	mov    rax,r14
  407656:	add    rsp,0x30
  40765a:	pop    rbx
  40765b:	pop    r15
  40765d:	pop    r14
  40765f:	pop    r13
  407661:	pop    r12
  407663:	pop    rdi
  407664:	pop    rsi
  407665:	ret
	...

0000000000407670 <__swc_fn_6b1cf01f_000018_de02dbdf>:
  407670:	mov    r8,QWORD PTR [rcx+0x48]
  407674:	cs nop WORD PTR [rax+rax*1+0x0]
  40767e:	xchg   ax,ax
  407680:	mov    r9,r8
  407683:	or     r9,rdx
  407686:	mov    rax,r8
  407689:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40768f:	cmp    rax,r8
  407692:	jne    407695 <__swc_fn_6b1cf01f_000018_de02dbdf+0x25>
  407694:	ret
  407695:	mov    r8,rax
  407698:	jmp    407680 <__swc_fn_6b1cf01f_000018_de02dbdf+0x10>
  40769a:	add    BYTE PTR [rax],al
  40769c:	add    BYTE PTR [rax],al
	...

00000000004076a0 <__swc_fn_6b1cf01f_000021_2d0fcd2c>:
  4076a0:	push   rsi
  4076a1:	push   rdi
  4076a2:	push   r12
  4076a4:	mov    rsi,rcx
  4076a7:	xor    edi,edi
  4076a9:	lea    r12,[rip+0x1c9b8]        # 424068 <__swc_bss_base_6b1cf01f+0x28>
  4076b0:	mov    eax,DWORD PTR [r12]
  4076b4:	xor    ecx,ecx
  4076b6:	test   rax,rax
  4076b9:	jbe    4076f4 <__swc_fn_6b1cf01f_000021_2d0fcd2c+0x54>
  4076bb:	nop    DWORD PTR [rax+rax*1+0x0]
  4076c0:	lea    rdx,[rip+0x1c9a9]        # 424070 <__swc_bss_base_6b1cf01f+0x30>
  4076c7:	mov    r8d,ecx
  4076ca:	lea    r8,[r8+r8*2]
  4076ce:	lea    r8,[rdx+r8*8]
  4076d2:	mov    rdx,QWORD PTR [r8+0x10]
  4076d6:	add    rdx,0x400000
  4076dd:	cmp    rdx,0x40000000
  4076e4:	ja     4076eb <__swc_fn_6b1cf01f_000021_2d0fcd2c+0x4b>
  4076e6:	mov    rdi,r8
  4076e9:	jmp    4076f4 <__swc_fn_6b1cf01f_000021_2d0fcd2c+0x54>
  4076eb:	add    rcx,0x1
  4076ef:	cmp    rcx,rax
  4076f2:	jb     4076c0 <__swc_fn_6b1cf01f_000021_2d0fcd2c+0x20>
  4076f4:	test   rdi,rdi
  4076f7:	jne    407783 <__swc_fn_6b1cf01f_000021_2d0fcd2c+0xe3>
  4076fd:	cmp    DWORD PTR [r12],0x10
  407702:	jae    40776b <__swc_fn_6b1cf01f_000021_2d0fcd2c+0xcb>
  407704:	mov    ecx,0x40400000
  407709:	call   40b540 <__swc_fn_6b1cf01f_000004_81d2e1e9>
  40770e:	test   rax,rax
  407711:	je     40776b <__swc_fn_6b1cf01f_000021_2d0fcd2c+0xcb>
  407713:	lea    rcx,[rip+0x1c956]        # 424070 <__swc_bss_base_6b1cf01f+0x30>
  40771a:	mov    edx,DWORD PTR [r12]
  40771e:	lea    rdx,[rdx+rdx*2]
  407722:	lea    rdx,[rcx+rdx*8]
  407726:	mov    QWORD PTR [rdx],rax
  407729:	lea    rax,[rax+0x3fffff]
  407730:	and    rax,0xffffffffffc00000
  407737:	mov    QWORD PTR [rdx+0x8],rax
  40773b:	mov    QWORD PTR [rdx+0x10],0x0
  407743:	mov    edx,DWORD PTR [rip+0x1c91f]        # 424068 <__swc_bss_base_6b1cf01f+0x28>
  407749:	nop    DWORD PTR [rax+0x0]
  407750:	lea    r9d,[rdx+0x1]
  407754:	mov    rax,rdx
  407757:	lock cmpxchg DWORD PTR [r12],r9d
  40775d:	mov    r8d,eax
  407760:	cmp    eax,edx
  407762:	je     407772 <__swc_fn_6b1cf01f_000021_2d0fcd2c+0xd2>
  407764:	mov    rdx,r8
  407767:	jmp    407750 <__swc_fn_6b1cf01f_000021_2d0fcd2c+0xb0>
  407769:	jmp    407772 <__swc_fn_6b1cf01f_000021_2d0fcd2c+0xd2>
  40776b:	xor    eax,eax
  40776d:	pop    r12
  40776f:	pop    rdi
  407770:	pop    rsi
  407771:	ret
  407772:	mov    eax,DWORD PTR [rip+0x1c8f0]        # 424068 <__swc_bss_base_6b1cf01f+0x28>
  407778:	sub    eax,0x1
  40777b:	lea    rdi,[rax+rax*2]
  40777f:	lea    rdi,[rcx+rdi*8]
  407783:	mov    r12,QWORD PTR [rdi+0x8]
  407787:	add    r12,QWORD PTR [rdi+0x10]
  40778b:	mov    rcx,r12
  40778e:	mov    edx,0x3000
  407793:	call   40f750 <__swc_fn_6b1cf01f_000005_f7acedb0>
  407798:	test   al,al
  40779a:	jne    4077a3 <__swc_fn_6b1cf01f_000021_2d0fcd2c+0x103>
  40779c:	xor    eax,eax
  40779e:	pop    r12
  4077a0:	pop    rdi
  4077a1:	pop    rsi
  4077a2:	ret
  4077a3:	vxorps xmm0,xmm0,xmm0
  4077a7:	xor    eax,eax
  4077a9:	cs nop WORD PTR [rax+rax*1+0x0]
  4077b3:	cs nop WORD PTR [rax+rax*1+0x0]
  4077bd:	nop    DWORD PTR [rax]
  4077c0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  4077c6:	add    rax,0x10
  4077ca:	cmp    rax,0x3000
  4077d1:	jne    4077c0 <__swc_fn_6b1cf01f_000021_2d0fcd2c+0x120>
  4077d3:	mov    DWORD PTR [r12+0x28],esi
  4077d8:	mov    eax,0x40
  4077dd:	mov    ecx,esi
  4077df:	shr    eax,cl
  4077e1:	mov    DWORD PTR [r12+0x2c],eax
  4077e6:	cmp    DWORD PTR [r12+0x2c],0x40
  4077ec:	jb     4077f7 <__swc_fn_6b1cf01f_000021_2d0fcd2c+0x157>
  4077ee:	mov    rax,0xffffffffffffffff
  4077f5:	jmp    407807 <__swc_fn_6b1cf01f_000021_2d0fcd2c+0x167>
  4077f7:	mov    eax,0x1
  4077fc:	mov    ecx,DWORD PTR [r12+0x2c]
  407801:	shl    rax,cl
  407804:	dec    rax
  407807:	mov    QWORD PTR [r12+0x20],rax
  40780c:	mov    DWORD PTR [r12],0x4e540001
  407814:	mov    DWORD PTR [r12+0x4],0x53474d45
  40781d:	add    QWORD PTR [rdi+0x10],0x400000
  407825:	mov    rax,r12
  407828:	pop    r12
  40782a:	pop    rdi
  40782b:	pop    rsi
  40782c:	ret
  40782d:	add    BYTE PTR [rax],al
	...

0000000000407830 <__swc_fn_6b1cf01f_000024_bcdc5519>:
  407830:	mov    eax,0x1
  407835:	mov    edx,DWORD PTR [rip+0x1c82d]        # 424068 <__swc_bss_base_6b1cf01f+0x28>
  40783b:	cmp    eax,edx
  40783d:	jae    40788b <__swc_fn_6b1cf01f_000024_bcdc5519+0x5b>
  40783f:	nop
  407840:	lea    r8,[rip+0x1c829]        # 424070 <__swc_bss_base_6b1cf01f+0x30>
  407847:	lea    r9,[rax+rax*2]
  40784b:	lea    r9,[r8+r9*8]
  40784f:	mov    r8,rcx
  407852:	sub    r8,QWORD PTR [r9+0x8]
  407856:	mov    r9,QWORD PTR [r9+0x10]
  40785a:	cmp    r8,r9
  40785d:	jae    407885 <__swc_fn_6b1cf01f_000024_bcdc5519+0x55>
  40785f:	mov    rax,rcx
  407862:	and    rax,0xffffffffffc00000
  407869:	shr    rcx,0x10
  40786d:	and    ecx,0x3f
  407870:	mov    edx,DWORD PTR [rax+0x28]
  407873:	shrx   ecx,ecx,edx
  407878:	shl    rcx,0x4
  40787c:	lea    rax,[rax+rcx*8+0x80]
  407884:	ret
  407885:	inc    eax
  407887:	cmp    eax,edx
  407889:	jb     407840 <__swc_fn_6b1cf01f_000024_bcdc5519+0x10>
  40788b:	xor    eax,eax
  40788d:	ret
	...

0000000000407890 <__swc_fn_6b1cf01f_000027_9798fb47>:
  407890:	vxorps xmm0,xmm0,xmm0
  407894:	vmovups XMMWORD PTR [rcx],xmm0
  407898:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40789d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4078a2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4078a7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  4078ac:	mov    QWORD PTR [rcx+0x50],0x0
  4078b4:	ret
	...

00000000004078c0 <__swc_fn_6b1cf01f_000030_9798fb47>:
  4078c0:	vxorps xmm0,xmm0,xmm0
  4078c4:	xor    eax,eax
  4078c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078d0:	cs nop WORD PTR [rax+rax*1+0x0]
  4078da:	nop    WORD PTR [rax+rax*1+0x0]
  4078e0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  4078e5:	add    rax,0x10
  4078e9:	cmp    rax,0x9b0
  4078f0:	jne    4078e0 <__swc_fn_6b1cf01f_000030_9798fb47+0x20>
  4078f2:	mov    QWORD PTR [rcx+0x9b0],0x0
  4078fd:	ret
	...

0000000000407900 <__swc_fn_6b1cf01f_000033_cd1a4e8c>:
  407900:	push   rsi
  407901:	push   rdi
  407902:	sub    rsp,0x8
  407906:	lea    rsi,[rip+0x1a6fb]        # 422008 <__swc_data_base_6b1cf01f+0x8>
  40790d:	mov    rax,QWORD PTR [rsi]
  407910:	mov    ecx,0xffffffff
  407915:	cmp    rax,rcx
  407918:	je     407921 <__swc_fn_6b1cf01f_000033_cd1a4e8c+0x21>
  40791a:	add    rsp,0x8
  40791e:	pop    rdi
  40791f:	pop    rsi
  407920:	ret
  407921:	mov    rcx,QWORD PTR [rip+0xb6e8]        # 413010 <__swc_fn_6b1cf01f_000176_718d7b54+0x8a0>
  407928:	call   411af0 <__swc_fn_6b1cf01f_000128_4a82cdf6>
  40792d:	mov    rcx,rax
  407930:	mov    eax,0xffffffff
  407935:	lock cmpxchg QWORD PTR [rsi],rcx
  40793a:	mov    rdi,rax
  40793d:	mov    eax,0xffffffff
  407942:	cmp    rdi,rax
  407945:	je     407956 <__swc_fn_6b1cf01f_000033_cd1a4e8c+0x56>
  407947:	call   409b30 <__swc_fn_6b1cf01f_000129_a611b8c4>
  40794c:	mov    rax,rdi
  40794f:	add    rsp,0x8
  407953:	pop    rdi
  407954:	pop    rsi
  407955:	ret
  407956:	mov    rax,rcx
  407959:	add    rsp,0x8
  40795d:	pop    rdi
  40795e:	pop    rsi
  40795f:	ret

0000000000407960 <__swc_fn_6b1cf01f_000036_14f56618>:
  407960:	sub    rsp,0x8
  407964:	vxorps xmm0,xmm0,xmm0
  407968:	xor    eax,eax
  40796a:	cs nop WORD PTR [rax+rax*1+0x0]
  407974:	cs nop WORD PTR [rax+rax*1+0x0]
  40797e:	xchg   ax,ax
  407980:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  407985:	add    rax,0x10
  407989:	cmp    rax,0x2b00
  407990:	jne    407980 <__swc_fn_6b1cf01f_000036_14f56618+0x20>
  407992:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40799c:	xor    al,al
  40799e:	mov    rdx,rax
  4079a1:	xor    al,al
  4079a3:	mov    r8,rax
  4079a6:	xor    al,al
  4079a8:	mov    r9,rax
  4079ab:	xor    al,al
  4079ad:	mov    r10,rax
  4079b0:	xor    al,al
  4079b2:	mov    r11,rax
  4079b5:	call   40b9b0 <__swc_fn_6b1cf01f_000037_03f1bf9a>
  4079ba:	add    rsp,0x8
  4079be:	ret
	...

00000000004079c0 <__swc_fn_6b1cf01f_000039_c90d80c1>:
  4079c0:	push   rsi
  4079c1:	push   rdi
  4079c2:	push   r12
  4079c4:	mov    rsi,r8
  4079c7:	mov    rdi,rdx
  4079ca:	mov    rcx,rdx
  4079cd:	call   40b540 <__swc_fn_6b1cf01f_000004_81d2e1e9>
  4079d2:	mov    r12,rax
  4079d5:	test   rax,rax
  4079d8:	jne    4079e1 <__swc_fn_6b1cf01f_000039_c90d80c1+0x21>
  4079da:	xor    eax,eax
  4079dc:	pop    r12
  4079de:	pop    rdi
  4079df:	pop    rsi
  4079e0:	ret
  4079e1:	mov    rcx,r12
  4079e4:	mov    rdx,rsi
  4079e7:	call   40f750 <__swc_fn_6b1cf01f_000005_f7acedb0>
  4079ec:	test   al,al
  4079ee:	jne    407a02 <__swc_fn_6b1cf01f_000039_c90d80c1+0x42>
  4079f0:	mov    rcx,r12
  4079f3:	mov    rdx,rdi
  4079f6:	call   40d7b0 <__swc_fn_6b1cf01f_000115_ed2d8fed>
  4079fb:	xor    eax,eax
  4079fd:	pop    r12
  4079ff:	pop    rdi
  407a00:	pop    rsi
  407a01:	ret
  407a02:	mov    rax,r12
  407a05:	pop    r12
  407a07:	pop    rdi
  407a08:	pop    rsi
  407a09:	ret
	...

0000000000407a20 <__swc_fn_6b1cf01f_000042_a78ae66b>:
  407a20:	push   rsi
  407a21:	push   rdi
  407a22:	push   r12
  407a24:	mov    rsi,rcx
  407a27:	mov    edx,0x9b8
  407a2c:	call   40ba20 <__swc_fn_6b1cf01f_000040_facd3e17>
  407a31:	mov    rdi,rax
  407a34:	test   rax,rax
  407a37:	jne    407a40 <__swc_fn_6b1cf01f_000042_a78ae66b+0x20>
  407a39:	xor    eax,eax
  407a3b:	pop    r12
  407a3d:	pop    rdi
  407a3e:	pop    rsi
  407a3f:	ret
  407a40:	vxorps xmm0,xmm0,xmm0
  407a44:	xor    eax,eax
  407a46:	cs nop WORD PTR [rax+rax*1+0x0]
  407a50:	cs nop WORD PTR [rax+rax*1+0x0]
  407a5a:	nop    WORD PTR [rax+rax*1+0x0]
  407a60:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  407a65:	add    rax,0x10
  407a69:	cmp    rax,0x9b0
  407a70:	jne    407a60 <__swc_fn_6b1cf01f_000042_a78ae66b+0x40>
  407a72:	mov    QWORD PTR [rdi+0x9b0],0x0
  407a7d:	mov    QWORD PTR [rdi],rsi
  407a80:	call   409be0 <__swc_fn_6b1cf01f_000132_a9c1c700>
  407a85:	mov    QWORD PTR [rdi+0x18],rax
  407a89:	lea    r12,[rsi+0x10]
  407a8d:	mov    rcx,r12
  407a90:	call   411d40 <__swc_fn_6b1cf01f_000137_86bb0f90>
  407a95:	mov    rax,QWORD PTR [rsi+0x20]
  407a99:	mov    QWORD PTR [rdi+0x8],rax
  407a9d:	mov    rax,QWORD PTR [rsi+0x20]
  407aa1:	test   rax,rax
  407aa4:	je     407aaa <__swc_fn_6b1cf01f_000042_a78ae66b+0x8a>
  407aa6:	mov    QWORD PTR [rax+0x10],rdi
  407aaa:	mov    QWORD PTR [rsi+0x20],rdi
  407aae:	mov    rcx,r12
  407ab1:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  407ab6:	mov    rax,rdi
  407ab9:	pop    r12
  407abb:	pop    rdi
  407abc:	pop    rsi
  407abd:	ret
	...

0000000000407ac0 <__swc_fn_6b1cf01f_000045_6e7a8d58>:
  407ac0:	mov    rax,QWORD PTR [rdx+0x10]
  407ac4:	test   rax,rax
  407ac7:	je     407ad3 <__swc_fn_6b1cf01f_000045_6e7a8d58+0x13>
  407ac9:	mov    rcx,QWORD PTR [rdx+0x8]
  407acd:	mov    QWORD PTR [rax+0x8],rcx
  407ad1:	jmp    407adb <__swc_fn_6b1cf01f_000045_6e7a8d58+0x1b>
  407ad3:	mov    rax,QWORD PTR [rdx+0x8]
  407ad7:	mov    QWORD PTR [rcx+0x20],rax
  407adb:	mov    rax,QWORD PTR [rdx+0x8]
  407adf:	test   rax,rax
  407ae2:	je     407aec <__swc_fn_6b1cf01f_000045_6e7a8d58+0x2c>
  407ae4:	mov    rcx,QWORD PTR [rdx+0x10]
  407ae8:	mov    QWORD PTR [rax+0x10],rcx
  407aec:	vxorps xmm0,xmm0,xmm0
  407af0:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  407af5:	ret
	...

0000000000407b00 <__swc_fn_6b1cf01f_000048_129b9bf4>:
  407b00:	sub    rsp,0x8
  407b04:	mov    r9,r8
  407b07:	mov    r10,rdx
  407b0a:	call   40bad0 <__swc_fn_6b1cf01f_000046_137687bb>
  407b0f:	mov    eax,0x1
  407b14:	xchg   DWORD PTR [r9+0x6c],eax
  407b18:	mov    rax,QWORD PTR [r9+0x60]
  407b1c:	test   rax,rax
  407b1f:	je     407b63 <__swc_fn_6b1cf01f_000048_129b9bf4+0x63>
  407b21:	xor    eax,eax
  407b23:	xchg   DWORD PTR [r9+0x6c],eax
  407b27:	movzx  eax,BYTE PTR [r9+0x39]
  407b2c:	lea    rax,[rax+rax*4]
  407b30:	lea    rax,[r10+rax*8+0x28]
  407b35:	mov    QWORD PTR [r9+0x50],0x0
  407b3d:	mov    rcx,QWORD PTR [rax+0x8]
  407b41:	mov    QWORD PTR [r9+0x48],rcx
  407b45:	mov    rcx,QWORD PTR [rax+0x8]
  407b49:	test   rcx,rcx
  407b4c:	je     407b54 <__swc_fn_6b1cf01f_000048_129b9bf4+0x54>
  407b4e:	mov    QWORD PTR [rcx+0x50],r9
  407b52:	jmp    407b58 <__swc_fn_6b1cf01f_000048_129b9bf4+0x58>
  407b54:	mov    QWORD PTR [rax+0x10],r9
  407b58:	mov    QWORD PTR [rax+0x8],r9
  407b5c:	xor    eax,eax
  407b5e:	add    rsp,0x8
  407b62:	ret
  407b63:	movzx  eax,BYTE PTR [r9+0x39]
  407b68:	lea    rax,[rax+rax*4]
  407b6c:	lea    rax,[r10+rax*8+0x28]
  407b71:	mov    QWORD PTR [r9+0x50],0x0
  407b79:	mov    rcx,QWORD PTR [rax+0x18]
  407b7d:	mov    QWORD PTR [r9+0x48],rcx
  407b81:	mov    rcx,QWORD PTR [rax+0x18]
  407b85:	test   rcx,rcx
  407b88:	je     407b8e <__swc_fn_6b1cf01f_000048_129b9bf4+0x8e>
  407b8a:	mov    QWORD PTR [rcx+0x50],r9
  407b8e:	mov    QWORD PTR [rax+0x18],r9
  407b92:	mov    eax,0x1
  407b97:	add    rsp,0x8
  407b9b:	ret
  407b9c:	add    BYTE PTR [rax],al
	...

0000000000407ba0 <__swc_fn_6b1cf01f_000051_3af34d7f>:
  407ba0:	push   r12
  407ba2:	push   r13
  407ba4:	push   rdi
  407ba5:	push   rsi
  407ba6:	push   r14
  407ba8:	push   r15
  407baa:	sub    rsp,0x178
  407bb1:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  407bba:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  407bc3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  407bcc:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  407bd5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  407bde:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  407be7:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  407bf0:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  407bf9:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  407c02:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  407c0b:	mov    r12,rcx
  407c0e:	lea    rax,[rip+0x1c5eb]        # 424200 <__swc_bss_base_6b1cf01f+0x1c0>
  407c15:	mov    rcx,QWORD PTR [rax]
  407c18:	mov    r13,rcx
  407c1b:	test   rcx,rcx
  407c1e:	jne    407c2e <__swc_fn_6b1cf01f_000051_3af34d7f+0x8e>
  407c20:	mov    r13d,0x1dcd6500
  407c26:	mov    ecx,0x1dcd6500
  407c2b:	xchg   QWORD PTR [rax],rcx
  407c2e:	lea    rax,[rip+0x1a3cb]        # 422000 <__swc_data_base_6b1cf01f>
  407c35:	mov    rax,QWORD PTR [rax]
  407c38:	cmp    rax,0xffffffffffffffff
  407c3c:	je     407c4b <__swc_fn_6b1cf01f_000051_3af34d7f+0xab>
  407c3e:	mov    eax,eax
  407c40:	mov    edi,eax
  407c42:	xor    eax,eax
  407c44:	call   407010 <pthread_getspecific@plt>
  407c49:	jmp    407c4d <__swc_fn_6b1cf01f_000051_3af34d7f+0xad>
  407c4b:	xor    eax,eax
  407c4d:	test   rax,rax
  407c50:	jne    407c5f <__swc_fn_6b1cf01f_000051_3af34d7f+0xbf>
  407c52:	call   407900 <__swc_fn_6b1cf01f_000033_cd1a4e8c>
  407c57:	mov    rcx,rax
  407c5a:	call   40db00 <__swc_fn_6b1cf01f_000130_5f757033>
  407c5f:	test   rax,rax
  407c62:	je     407c74 <__swc_fn_6b1cf01f_000051_3af34d7f+0xd4>
  407c64:	cmp    QWORD PTR [rax],r12
  407c67:	jne    407c74 <__swc_fn_6b1cf01f_000051_3af34d7f+0xd4>
  407c69:	cmp    DWORD PTR [rax+0x20],0x0
  407c6d:	jne    407c74 <__swc_fn_6b1cf01f_000051_3af34d7f+0xd4>
  407c6f:	mov    rsi,rax
  407c72:	jmp    407c76 <__swc_fn_6b1cf01f_000051_3af34d7f+0xd6>
  407c74:	xor    esi,esi
  407c76:	lea    rdi,[r12+0x2a88]
  407c7e:	mov    r14,QWORD PTR [rdi]
  407c81:	test   r14,r14
  407c84:	jne    407cd3 <__swc_fn_6b1cf01f_000051_3af34d7f+0x133>
  407c86:	lea    rax,[rip+0x1c3cb]        # 424058 <__swc_bss_base_6b1cf01f+0x18>
  407c8d:	mov    rax,QWORD PTR [rax]
  407c90:	test   rax,rax
  407c93:	setne  al
  407c96:	jne    407cba <__swc_fn_6b1cf01f_000051_3af34d7f+0x11a>
  407c98:	mov    rax,QWORD PTR [r12+0x2a70]
  407ca0:	test   rax,rax
  407ca3:	setne  al
  407ca6:	jne    407cba <__swc_fn_6b1cf01f_000051_3af34d7f+0x11a>
  407ca8:	test   rsi,rsi
  407cab:	setne  al
  407cae:	je     407cba <__swc_fn_6b1cf01f_000051_3af34d7f+0x11a>
  407cb0:	cmp    DWORD PTR [rsi+0x730],0x0
  407cb7:	setne  al
  407cba:	test   al,al
  407cbc:	je     407cce <__swc_fn_6b1cf01f_000051_3af34d7f+0x12e>
  407cbe:	call   40dbb0 <__swc_fn_6b1cf01f_000133_07d76562>
  407cc3:	lea    rcx,[rax+r13*1]
  407cc7:	xor    eax,eax
  407cc9:	lock cmpxchg QWORD PTR [rdi],rcx
  407cce:	jmp    407dd3 <__swc_fn_6b1cf01f_000051_3af34d7f+0x233>
  407cd3:	call   40dbb0 <__swc_fn_6b1cf01f_000133_07d76562>
  407cd8:	mov    r15,rax
  407cdb:	cmp    rax,r14
  407cde:	jb     407cef <__swc_fn_6b1cf01f_000051_3af34d7f+0x14f>
  407ce0:	xor    ecx,ecx
  407ce2:	mov    rax,r14
  407ce5:	lock cmpxchg QWORD PTR [rdi],rcx
  407cea:	cmp    rax,r14
  407ced:	je     407cf4 <__swc_fn_6b1cf01f_000051_3af34d7f+0x154>
  407cef:	jmp    407dd3 <__swc_fn_6b1cf01f_000051_3af34d7f+0x233>
  407cf4:	test   rsi,rsi
  407cf7:	je     407d12 <__swc_fn_6b1cf01f_000051_3af34d7f+0x172>
  407cf9:	cmp    r15,r13
  407cfc:	jb     407d12 <__swc_fn_6b1cf01f_000051_3af34d7f+0x172>
  407cfe:	mov    rax,r15
  407d01:	sub    rax,r13
  407d04:	mov    rcx,r12
  407d07:	mov    rdx,rsi
  407d0a:	mov    r8,rax
  407d0d:	call   40bf10 <__swc_fn_6b1cf01f_000061_dea90857>
  407d12:	lea    rsi,[r12+0x10]
  407d17:	mov    rcx,rsi
  407d1a:	call   411d40 <__swc_fn_6b1cf01f_000137_86bb0f90>
  407d1f:	mov    rax,QWORD PTR [r12+0x18]
  407d24:	mov    rdi,rax
  407d27:	test   rdi,rdi
  407d2a:	je     407d54 <__swc_fn_6b1cf01f_000051_3af34d7f+0x1b4>
  407d2c:	cs nop WORD PTR [rax+rax*1+0x0]
  407d36:	cs nop WORD PTR [rax+rax*1+0x0]
  407d40:	mov    rcx,rdi
  407d43:	call   40f920 <__swc_fn_6b1cf01f_000017_adca76cf>
  407d48:	mov    rax,QWORD PTR [rdi+0x10]
  407d4c:	mov    rdi,rax
  407d4f:	test   rax,rax
  407d52:	jne    407d40 <__swc_fn_6b1cf01f_000051_3af34d7f+0x1a0>
  407d54:	mov    rcx,rsi
  407d57:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  407d5c:	mov    rcx,r12
  407d5f:	call   411d40 <__swc_fn_6b1cf01f_000137_86bb0f90>
  407d64:	xor    esi,esi
  407d66:	cs nop WORD PTR [rax+rax*1+0x0]
  407d70:	mov    rax,QWORD PTR [r12+0x2a70]
  407d78:	cmp    rsi,rax
  407d7b:	jae    407dcb <__swc_fn_6b1cf01f_000051_3af34d7f+0x22b>
  407d7d:	lea    rax,[rsi+rsi*4]
  407d81:	lea    rax,[r12+rax*8+0x268]
  407d89:	mov    r8,QWORD PTR [rax]
  407d8c:	mov    r9,QWORD PTR [rax+0x8]
  407d90:	mov    r10,QWORD PTR [rax+0x10]
  407d94:	mov    rax,QWORD PTR [rax+0x20]
  407d98:	cmp    rax,r15
  407d9b:	jae    407da8 <__swc_fn_6b1cf01f_000051_3af34d7f+0x208>
  407d9d:	mov    rcx,r15
  407da0:	sub    rcx,rax
  407da3:	cmp    rcx,r13
  407da6:	jae    407dad <__swc_fn_6b1cf01f_000051_3af34d7f+0x20d>
  407da8:	inc    rsi
  407dab:	jmp    407d70 <__swc_fn_6b1cf01f_000051_3af34d7f+0x1d0>
  407dad:	mov    rcx,r12
  407db0:	mov    rdx,rsi
  407db3:	call   40bec0 <__swc_fn_6b1cf01f_000058_15c28ca7>
  407db8:	mov    rcx,r12
  407dbb:	mov    rdx,r8
  407dbe:	mov    r8,r9
  407dc1:	mov    r9,r10
  407dc4:	call   40fc00 <__swc_fn_6b1cf01f_000041_d3c2ab54>
  407dc9:	jmp    407d70 <__swc_fn_6b1cf01f_000051_3af34d7f+0x1d0>
  407dcb:	mov    rcx,r12
  407dce:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  407dd3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  407ddc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  407de5:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  407dee:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  407df7:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  407e00:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  407e09:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  407e12:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  407e1b:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  407e24:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  407e2d:	add    rsp,0x178
  407e34:	pop    r15
  407e36:	pop    r14
  407e38:	pop    rsi
  407e39:	pop    rdi
  407e3a:	pop    r13
  407e3c:	pop    r12
  407e3e:	ret
	...

0000000000407e40 <__swc_fn_6b1cf01f_000054_df0696cd>:
  407e40:	lea    rax,[rdx-0x58]
  407e44:	ret
	...

0000000000407e50 <__swc_fn_6b1cf01f_000057_2ca0cb05>:
  407e50:	push   rsi
  407e51:	push   rdi
  407e52:	push   r12
  407e54:	push   r13
  407e56:	sub    rsp,0x68
  407e5a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  407e60:	mov    rsi,r9
  407e63:	mov    rdi,rcx
  407e66:	mov    r12,rdx
  407e69:	mov    r13,r8
  407e6c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  407e74:	jne    407e83 <__swc_fn_6b1cf01f_000057_2ca0cb05+0x33>
  407e76:	xor    eax,eax
  407e78:	add    rsp,0x68
  407e7c:	pop    r13
  407e7e:	pop    r12
  407e80:	pop    rdi
  407e81:	pop    rsi
  407e82:	ret
  407e83:	mov    rcx,rdi
  407e86:	call   411d40 <__swc_fn_6b1cf01f_000137_86bb0f90>
  407e8b:	movabs rax,0x7fffffffffffffff
  407e95:	cmp    r12,rax
  407e98:	mov    rax,0xffffffffffffffff
  407e9f:	lea    rcx,[r12+r12*1]
  407ea3:	cmovbe rax,rcx
  407ea7:	mov    rcx,QWORD PTR [rdi+0x2a70]
  407eae:	mov    rdx,rcx
  407eb1:	sub    rax,r12
  407eb4:	inc    rax
  407eb7:	xor    r8d,r8d
  407eba:	test   rcx,rcx
  407ebd:	jbe    407ee8 <__swc_fn_6b1cf01f_000057_2ca0cb05+0x98>
  407ebf:	nop
  407ec0:	lea    r9,[r8+r8*4]
  407ec4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  407ecc:	sub    r9,r12
  407ecf:	cmp    r9,rax
  407ed2:	jae    407edf <__swc_fn_6b1cf01f_000057_2ca0cb05+0x8f>
  407ed4:	mov    rdx,r8
  407ed7:	mov    rax,r9
  407eda:	test   r9,r9
  407edd:	je     407ee8 <__swc_fn_6b1cf01f_000057_2ca0cb05+0x98>
  407edf:	add    r8,0x1
  407ee3:	cmp    r8,rcx
  407ee6:	jb     407ec0 <__swc_fn_6b1cf01f_000057_2ca0cb05+0x70>
  407ee8:	mov    rax,QWORD PTR [rdi+0x2a70]
  407eef:	cmp    rdx,rax
  407ef2:	jne    407f0f <__swc_fn_6b1cf01f_000057_2ca0cb05+0xbf>
  407ef4:	mov    rcx,rdi
  407ef7:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  407efc:	xor    eax,eax
  407efe:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  407f04:	add    rsp,0x68
  407f08:	pop    r13
  407f0a:	pop    r12
  407f0c:	pop    rdi
  407f0d:	pop    rsi
  407f0e:	ret
  407f0f:	lea    rax,[rdx+rdx*4]
  407f13:	lea    rax,[rdi+rax*8+0x268]
  407f1b:	vmovups xmm6,XMMWORD PTR [rax]
  407f1f:	mov    r8,QWORD PTR [rax+0x10]
  407f23:	mov    rcx,rdi
  407f26:	call   40bec0 <__swc_fn_6b1cf01f_000058_15c28ca7>
  407f2b:	vpshufd xmm0,xmm6,0xee
  407f30:	vmovsd QWORD PTR [r13+0x0],xmm0
  407f36:	mov    QWORD PTR [rsi],r8
  407f39:	mov    rcx,rdi
  407f3c:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  407f41:	vmovq  rax,xmm6
  407f46:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  407f4c:	add    rsp,0x68
  407f50:	pop    r13
  407f52:	pop    r12
  407f54:	pop    rdi
  407f55:	pop    rsi
  407f56:	ret
	...

0000000000407f60 <__swc_fn_6b1cf01f_000060_b304235a>:
  407f60:	push   r12
  407f62:	push   r13
  407f64:	push   r14
  407f66:	push   r15
  407f68:	push   rdi
  407f69:	push   rsi
  407f6a:	sub    rsp,0x148
  407f71:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  407f7a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  407f83:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  407f8c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  407f95:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  407f9e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  407fa7:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  407fb0:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  407fb9:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  407fc2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  407fcb:	mov    r12,r9
  407fce:	mov    r13,rcx
  407fd1:	mov    r14,rdx
  407fd4:	mov    r15,r8
  407fd7:	test   rdx,rdx
  407fda:	jne    407fee <__swc_fn_6b1cf01f_000060_b304235a+0x8e>
  407fdc:	add    rsp,0x148
  407fe3:	pop    rsi
  407fe4:	pop    rdi
  407fe5:	pop    r15
  407fe7:	pop    r14
  407fe9:	pop    r13
  407feb:	pop    r12
  407fed:	ret
  407fee:	cmp    r12,0x200000
  407ff5:	ja     408087 <__swc_fn_6b1cf01f_000060_b304235a+0x127>
  407ffb:	lea    rax,[rip+0x19ffe]        # 422000 <__swc_data_base_6b1cf01f>
  408002:	mov    rax,QWORD PTR [rax]
  408005:	cmp    rax,0xffffffffffffffff
  408009:	je     408018 <__swc_fn_6b1cf01f_000060_b304235a+0xb8>
  40800b:	mov    eax,eax
  40800d:	mov    edi,eax
  40800f:	xor    eax,eax
  408011:	call   407010 <pthread_getspecific@plt>
  408016:	jmp    40801a <__swc_fn_6b1cf01f_000060_b304235a+0xba>
  408018:	xor    eax,eax
  40801a:	test   rax,rax
  40801d:	je     408024 <__swc_fn_6b1cf01f_000060_b304235a+0xc4>
  40801f:	mov    rsi,rax
  408022:	jmp    408034 <__swc_fn_6b1cf01f_000060_b304235a+0xd4>
  408024:	call   407900 <__swc_fn_6b1cf01f_000033_cd1a4e8c>
  408029:	mov    rcx,rax
  40802c:	call   40db00 <__swc_fn_6b1cf01f_000130_5f757033>
  408031:	mov    rsi,rax
  408034:	test   rsi,rsi
  408037:	je     408087 <__swc_fn_6b1cf01f_000060_b304235a+0x127>
  408039:	cmp    QWORD PTR [rsi],r13
  40803c:	jne    408087 <__swc_fn_6b1cf01f_000060_b304235a+0x127>
  40803e:	cmp    DWORD PTR [rsi+0x20],0x0
  408042:	jne    408087 <__swc_fn_6b1cf01f_000060_b304235a+0x127>
  408044:	cmp    DWORD PTR [rsi+0x730],0x10
  40804b:	jae    408087 <__swc_fn_6b1cf01f_000060_b304235a+0x127>
  40804d:	mov    eax,DWORD PTR [rsi+0x730]
  408053:	lea    rdi,[rax+rax*4]
  408057:	lea    rdi,[rsi+rdi*8+0x738]
  40805f:	mov    QWORD PTR [rdi],r14
  408062:	mov    QWORD PTR [rdi+0x8],r15
  408066:	mov    QWORD PTR [rdi+0x10],r12
  40806a:	mov    QWORD PTR [rdi+0x18],0x0
  408072:	call   40dbb0 <__swc_fn_6b1cf01f_000133_07d76562>
  408077:	mov    QWORD PTR [rdi+0x20],rax
  40807b:	add    DWORD PTR [rsi+0x730],0x1
  408082:	jmp    4081e6 <__swc_fn_6b1cf01f_000060_b304235a+0x286>
  408087:	mov    rcx,r13
  40808a:	call   410330 <__swc_fn_6b1cf01f_000059_ad030a10>
  40808f:	mov    rsi,rax
  408092:	cmp    r12,rax
  408095:	jbe    4080ca <__swc_fn_6b1cf01f_000060_b304235a+0x16a>
  408097:	cmp    r12,0x10000000
  40809e:	seta   al
  4080a1:	ja     4080b0 <__swc_fn_6b1cf01f_000060_b304235a+0x150>
  4080a3:	mov    rax,QWORD PTR [r13+0x2a70]
  4080aa:	test   rax,rax
  4080ad:	setne  al
  4080b0:	test   al,al
  4080b2:	je     4080ca <__swc_fn_6b1cf01f_000060_b304235a+0x16a>
  4080b4:	mov    rcx,r13
  4080b7:	mov    rdx,r14
  4080ba:	mov    r8,r15
  4080bd:	mov    r9,r12
  4080c0:	call   40fc00 <__swc_fn_6b1cf01f_000041_d3c2ab54>
  4080c5:	jmp    4081e6 <__swc_fn_6b1cf01f_000060_b304235a+0x286>
  4080ca:	call   40dbb0 <__swc_fn_6b1cf01f_000133_07d76562>
  4080cf:	mov    rdi,rax
  4080d2:	mov    rcx,r13
  4080d5:	call   411d40 <__swc_fn_6b1cf01f_000137_86bb0f90>
  4080da:	cmp    QWORD PTR [r13+0x2a70],0x0
  4080e2:	je     40819a <__swc_fn_6b1cf01f_000060_b304235a+0x23a>
  4080e8:	nop    DWORD PTR [rax+rax*1+0x0]
  4080f0:	cmp    QWORD PTR [r13+0x2a70],0x100
  4080fb:	jae    408110 <__swc_fn_6b1cf01f_000060_b304235a+0x1b0>
  4080fd:	mov    rax,QWORD PTR [r13+0x2a68]
  408104:	add    rax,r12
  408107:	cmp    rax,rsi
  40810a:	jbe    40819a <__swc_fn_6b1cf01f_000060_b304235a+0x23a>
  408110:	xor    eax,eax
  408112:	mov    rcx,QWORD PTR [r13+0x2a70]
  408119:	mov    edx,0x1
  40811e:	cmp    rcx,0x1
  408122:	jbe    408159 <__swc_fn_6b1cf01f_000060_b304235a+0x1f9>
  408124:	cs nop WORD PTR [rax+rax*1+0x0]
  40812e:	xchg   ax,ax
  408130:	lea    r8,[rdx+rdx*4]
  408134:	lea    r8,[r13+r8*8+0x268]
  40813c:	lea    r9,[rax+rax*4]
  408140:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  408148:	cmp    QWORD PTR [r8+0x18],r9
  40814c:	cmovb  rax,rdx
  408150:	add    rdx,0x1
  408154:	cmp    rdx,rcx
  408157:	jb     408130 <__swc_fn_6b1cf01f_000060_b304235a+0x1d0>
  408159:	lea    rcx,[rax+rax*4]
  40815d:	lea    rcx,[r13+rcx*8+0x268]
  408165:	mov    r8,QWORD PTR [rcx]
  408168:	mov    r9,QWORD PTR [rcx+0x8]
  40816c:	mov    r10,QWORD PTR [rcx+0x10]
  408170:	mov    rcx,r13
  408173:	mov    rdx,rax
  408176:	call   40bec0 <__swc_fn_6b1cf01f_000058_15c28ca7>
  40817b:	mov    rcx,r13
  40817e:	mov    rdx,r8
  408181:	mov    r8,r9
  408184:	mov    r9,r10
  408187:	call   40fc00 <__swc_fn_6b1cf01f_000041_d3c2ab54>
  40818c:	cmp    QWORD PTR [r13+0x2a70],0x0
  408194:	jne    4080f0 <__swc_fn_6b1cf01f_000060_b304235a+0x190>
  40819a:	add    QWORD PTR [r13+0x2a78],0x1
  4081a2:	mov    rax,QWORD PTR [r13+0x2a70]
  4081a9:	lea    rax,[rax+rax*4]
  4081ad:	lea    rax,[r13+rax*8+0x268]
  4081b5:	mov    QWORD PTR [rax],r14
  4081b8:	mov    QWORD PTR [rax+0x8],r15
  4081bc:	mov    QWORD PTR [rax+0x10],r12
  4081c0:	mov    rcx,QWORD PTR [r13+0x2a78]
  4081c7:	mov    QWORD PTR [rax+0x18],rcx
  4081cb:	mov    QWORD PTR [rax+0x20],rdi
  4081cf:	add    QWORD PTR [r13+0x2a68],r12
  4081d6:	add    QWORD PTR [r13+0x2a70],0x1
  4081de:	mov    rcx,r13
  4081e1:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  4081e6:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  4081ef:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  4081f8:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  408201:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40820a:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  408213:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40821c:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  408225:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40822e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  408237:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  408240:	add    rsp,0x148
  408247:	pop    rsi
  408248:	pop    rdi
  408249:	pop    r15
  40824b:	pop    r14
  40824d:	pop    r13
  40824f:	pop    r12
  408251:	ret
	...

0000000000408260 <__swc_fn_6b1cf01f_000063_d9ee99ea>:
  408260:	push   rbx
  408261:	push   r12
  408263:	push   r13
  408265:	push   r14
  408267:	push   r15
  408269:	push   rdi
  40826a:	push   rsi
  40826b:	sub    rsp,0xf0
  408272:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  408278:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40827e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  408284:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40828a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  408293:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40829c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  4082a5:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  4082ae:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  4082b7:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  4082c0:	mov    eax,r8d
  4082c3:	mov    rbx,rcx
  4082c6:	mov    r12,rdx
  4082c9:	mov    QWORD PTR [rsp+0x18],rdx
  4082ce:	mov    ecx,DWORD PTR [r12+0x58]
  4082d3:	mov    r13d,ecx
  4082d6:	cmp    ecx,0x10
  4082d9:	mov    ecx,0x10
  4082de:	cmovb  r13d,ecx
  4082e2:	test   r13d,r13d
  4082e5:	mov    rcx,r13
  4082e8:	mov    edx,0x8
  4082ed:	cmove  ecx,edx
  4082f0:	dec    rcx
  4082f3:	mov    rdx,0xffffffffffffffff
  4082fa:	sub    rdx,rcx
  4082fd:	xor    r14d,r14d
  408300:	mov    r8,rcx
  408303:	not    r8
  408306:	lea    rcx,[rcx+0x58]
  40830a:	and    rcx,r8
  40830d:	cmp    rdx,0x58
  408311:	cmovae r14,rcx
  408315:	cmp    eax,0xffffffff
  408318:	jne    408321 <__swc_fn_6b1cf01f_000063_d9ee99ea+0xc1>
  40831a:	mov    r15,QWORD PTR [r12+0x48]
  40831f:	jmp    408353 <__swc_fn_6b1cf01f_000063_d9ee99ea+0xf3>
  408321:	test   eax,eax
  408323:	jne    40832c <__swc_fn_6b1cf01f_000063_d9ee99ea+0xcc>
  408325:	mov    eax,0x8
  40832a:	jmp    408350 <__swc_fn_6b1cf01f_000063_d9ee99ea+0xf0>
  40832c:	cmp    eax,0x8
  40832f:	ja     408337 <__swc_fn_6b1cf01f_000063_d9ee99ea+0xd7>
  408331:	shl    rax,0x4
  408335:	jmp    408350 <__swc_fn_6b1cf01f_000063_d9ee99ea+0xf0>
  408337:	lea    eax,[rax-0x9]
  40833a:	mov    ecx,eax
  40833c:	shr    ecx,0x2
  40833f:	and    eax,0x3
  408342:	lea    ecx,[rcx+0x7]
  408345:	lea    ecx,[rcx-0x2]
  408348:	lea    eax,[rax+0x5]
  40834b:	shlx   rax,rax,rcx
  408350:	mov    r15,rax
  408353:	lea    rax,[r14+r13*1]
  408357:	mov    rcx,0xffffffffffffffff
  40835e:	sub    rcx,rax
  408361:	cmp    r15,rcx
  408364:	jbe    408374 <__swc_fn_6b1cf01f_000063_d9ee99ea+0x114>
  408366:	mov    QWORD PTR [r12+0x40],0x0
  40836f:	jmp    408746 <__swc_fn_6b1cf01f_000063_d9ee99ea+0x4e6>
  408374:	mov    QWORD PTR [rsp+0x20],r13
  408379:	lea    r13,[rsp+0x8]
  40837e:	add    rax,r15
  408381:	mov    ecx,0x1000
  408386:	test   ecx,ecx
  408388:	mov    edx,0x8
  40838d:	cmove  ecx,edx
  408390:	dec    rcx
  408393:	mov    rdx,0xffffffffffffffff
  40839a:	sub    rdx,rcx
  40839d:	cmp    rax,rdx
  4083a0:	jbe    4083ac <__swc_fn_6b1cf01f_000063_d9ee99ea+0x14c>
  4083a2:	mov    QWORD PTR [r13+0x0],0x0
  4083aa:	jmp    4083b9 <__swc_fn_6b1cf01f_000063_d9ee99ea+0x159>
  4083ac:	add    rax,rcx
  4083af:	andn   rax,rcx,rax
  4083b4:	mov    QWORD PTR [rsp+0x8],rax
  4083b9:	cmp    QWORD PTR [r13+0x0],0x0
  4083be:	jne    4083ce <__swc_fn_6b1cf01f_000063_d9ee99ea+0x16e>
  4083c0:	mov    QWORD PTR [r12+0x40],0x0
  4083c9:	jmp    408746 <__swc_fn_6b1cf01f_000063_d9ee99ea+0x4e6>
  4083ce:	mov    QWORD PTR [rsp+0x30],r15
  4083d3:	xor    r15d,r15d
  4083d6:	mov    QWORD PTR [rsp+0x38],0x0
  4083df:	lea    r12,[rsp+0x10]
  4083e4:	mov    QWORD PTR [rsp+0x28],r14
  4083e9:	mov    r14,QWORD PTR [rsp+0x8]
  4083ee:	mov    QWORD PTR [rsp+0x10],r14
  4083f3:	cmp    r14,0x10000
  4083fa:	ja     408401 <__swc_fn_6b1cf01f_000063_d9ee99ea+0x1a1>
  4083fc:	mov    rax,r14
  4083ff:	jmp    408452 <__swc_fn_6b1cf01f_000063_d9ee99ea+0x1f2>
  408401:	xor    eax,eax
  408403:	lea    rcx,[r14-0x1]
  408407:	lzcnt  rax,rcx
  40840c:	mov    ecx,0x3f
  408411:	sub    rcx,rax
  408414:	mov    eax,0x1
  408419:	lea    rcx,[rcx-0x3]
  40841d:	shl    rax,cl
  408420:	mov    rcx,rax
  408423:	cmp    rax,0x1000
  40842a:	mov    eax,0x1000
  40842f:	cmovb  rcx,rax
  408433:	mov    rdx,0xffffffffffffffff
  40843a:	sub    rdx,rcx
  40843d:	mov    rax,r14
  408440:	lea    r8,[r14+rcx*1-0x1]
  408445:	neg    rcx
  408448:	and    r8,rcx
  40844b:	cmp    r14,rdx
  40844e:	cmovbe rax,r8
  408452:	mov    QWORD PTR [rsp+0x8],rax
  408457:	lea    rax,[rip+0x19ba2]        # 422000 <__swc_data_base_6b1cf01f>
  40845e:	mov    rax,QWORD PTR [rax]
  408461:	cmp    rax,0xffffffffffffffff
  408465:	je     408474 <__swc_fn_6b1cf01f_000063_d9ee99ea+0x214>
  408467:	mov    eax,eax
  408469:	mov    edi,eax
  40846b:	xor    eax,eax
  40846d:	call   407010 <pthread_getspecific@plt>
  408472:	jmp    408476 <__swc_fn_6b1cf01f_000063_d9ee99ea+0x216>
  408474:	xor    eax,eax
  408476:	test   rax,rax
  408479:	jne    408488 <__swc_fn_6b1cf01f_000063_d9ee99ea+0x228>
  40847b:	call   407900 <__swc_fn_6b1cf01f_000033_cd1a4e8c>
  408480:	mov    rcx,rax
  408483:	call   40db00 <__swc_fn_6b1cf01f_000130_5f757033>
  408488:	test   rax,rax
  40848b:	je     40857c <__swc_fn_6b1cf01f_000063_d9ee99ea+0x31c>
  408491:	cmp    QWORD PTR [rax],rbx
  408494:	jne    40857c <__swc_fn_6b1cf01f_000063_d9ee99ea+0x31c>
  40849a:	cmp    DWORD PTR [rax+0x20],0x0
  40849e:	jne    40857c <__swc_fn_6b1cf01f_000063_d9ee99ea+0x31c>
  4084a4:	mov    rcx,QWORD PTR [rsp+0x8]
  4084a9:	movabs rdx,0x7fffffffffffffff
  4084b3:	cmp    rcx,rdx
  4084b6:	mov    rdx,0xffffffffffffffff
  4084bd:	lea    r8,[rcx+rcx*1]
  4084c1:	cmovbe rdx,r8
  4084c5:	mov    r8d,DWORD PTR [rax+0x730]
  4084cc:	mov    r9d,r8d
  4084cf:	sub    rdx,rcx
  4084d2:	inc    rdx
  4084d5:	xor    r10d,r10d
  4084d8:	test   r8,r8
  4084db:	jbe    40850b <__swc_fn_6b1cf01f_000063_d9ee99ea+0x2ab>
  4084dd:	nop    DWORD PTR [rax]
  4084e0:	mov    r11d,r10d
  4084e3:	lea    r11,[r11+r11*4]
  4084e7:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  4084ef:	sub    r11,rcx
  4084f2:	cmp    r11,rdx
  4084f5:	jae    408502 <__swc_fn_6b1cf01f_000063_d9ee99ea+0x2a2>
  4084f7:	mov    r9d,r10d
  4084fa:	mov    rdx,r11
  4084fd:	test   r11,r11
  408500:	je     40850b <__swc_fn_6b1cf01f_000063_d9ee99ea+0x2ab>
  408502:	add    r10,0x1
  408506:	cmp    r10,r8
  408509:	jb     4084e0 <__swc_fn_6b1cf01f_000063_d9ee99ea+0x280>
  40850b:	mov    ecx,DWORD PTR [rax+0x730]
  408511:	cmp    r9d,ecx
  408514:	jne    40851a <__swc_fn_6b1cf01f_000063_d9ee99ea+0x2ba>
  408516:	xor    eax,eax
  408518:	jmp    408579 <__swc_fn_6b1cf01f_000063_d9ee99ea+0x319>
  40851a:	lea    rcx,[r9+r9*4]
  40851e:	lea    rcx,[rax+rcx*8+0x738]
  408526:	vmovups xmm0,XMMWORD PTR [rcx]
  40852a:	mov    rdx,QWORD PTR [rcx+0x10]
  40852e:	sub    DWORD PTR [rax+0x730],0x1
  408535:	mov    r8d,DWORD PTR [rax+0x730]
  40853c:	lea    r8,[r8+r8*4]
  408540:	lea    r8,[rax+r8*8+0x738]
  408548:	vmovups xmm1,XMMWORD PTR [r8]
  40854d:	vmovups XMMWORD PTR [rcx],xmm1
  408551:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  408557:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40855c:	mov    rax,QWORD PTR [r8+0x20]
  408560:	mov    QWORD PTR [rcx+0x20],rax
  408564:	vpshufd xmm1,xmm0,0xee
  408569:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40856f:	mov    QWORD PTR [rsp+0x10],rdx
  408574:	vmovq  rax,xmm0
  408579:	mov    r15,rax
  40857c:	test   r15,r15
  40857f:	jne    408597 <__swc_fn_6b1cf01f_000063_d9ee99ea+0x337>
  408581:	mov    rcx,rbx
  408584:	mov    rdx,QWORD PTR [rsp+0x8]
  408589:	mov    r8,r13
  40858c:	mov    r9,r12
  40858f:	call   407e50 <__swc_fn_6b1cf01f_000057_2ca0cb05>
  408594:	mov    r15,rax
  408597:	test   r15,r15
  40859a:	je     4085db <__swc_fn_6b1cf01f_000063_d9ee99ea+0x37b>
  40859c:	cmp    QWORD PTR [r12],r14
  4085a0:	jae    4085db <__swc_fn_6b1cf01f_000063_d9ee99ea+0x37b>
  4085a2:	mov    rax,r15
  4085a5:	add    rax,QWORD PTR [r12]
  4085a9:	mov    rdx,r14
  4085ac:	sub    rdx,QWORD PTR [r12]
  4085b0:	mov    rcx,rax
  4085b3:	call   40f750 <__swc_fn_6b1cf01f_000005_f7acedb0>
  4085b8:	test   al,al
  4085ba:	je     4085c3 <__swc_fn_6b1cf01f_000063_d9ee99ea+0x363>
  4085bc:	mov    QWORD PTR [rsp+0x10],r14
  4085c1:	jmp    4085db <__swc_fn_6b1cf01f_000063_d9ee99ea+0x37b>
  4085c3:	mov    rcx,rbx
  4085c6:	mov    rdx,r15
  4085c9:	mov    r8,QWORD PTR [rsp+0x8]
  4085ce:	mov    r9,QWORD PTR [rsp+0x10]
  4085d3:	call   407f60 <__swc_fn_6b1cf01f_000060_b304235a>
  4085d8:	xor    r15d,r15d
  4085db:	test   r15,r15
  4085de:	jne    40865a <__swc_fn_6b1cf01f_000063_d9ee99ea+0x3fa>
  4085e0:	cmp    r14,0x10000
  4085e7:	ja     4085ee <__swc_fn_6b1cf01f_000063_d9ee99ea+0x38e>
  4085e9:	mov    rax,r14
  4085ec:	jmp    40863f <__swc_fn_6b1cf01f_000063_d9ee99ea+0x3df>
  4085ee:	xor    eax,eax
  4085f0:	lea    rcx,[r14-0x1]
  4085f4:	lzcnt  rax,rcx
  4085f9:	mov    ecx,0x3f
  4085fe:	sub    rcx,rax
  408601:	mov    eax,0x1
  408606:	lea    rcx,[rcx-0x3]
  40860a:	shl    rax,cl
  40860d:	mov    rcx,rax
  408610:	cmp    rax,0x1000
  408617:	mov    eax,0x1000
  40861c:	cmovb  rcx,rax
  408620:	mov    rdx,0xffffffffffffffff
  408627:	sub    rdx,rcx
  40862a:	mov    rax,r14
  40862d:	lea    r8,[r14+rcx*1-0x1]
  408632:	neg    rcx
  408635:	and    r8,rcx
  408638:	cmp    r14,rdx
  40863b:	cmovbe rax,r8
  40863f:	mov    QWORD PTR [rsp+0x8],rax
  408644:	mov    QWORD PTR [rsp+0x10],r14
  408649:	mov    rcx,rbx
  40864c:	mov    rdx,rax
  40864f:	mov    r8,r14
  408652:	call   4079c0 <__swc_fn_6b1cf01f_000039_c90d80c1>
  408657:	mov    r15,rax
  40865a:	test   r15,r15
  40865d:	jne    40866b <__swc_fn_6b1cf01f_000063_d9ee99ea+0x40b>
  40865f:	mov    r13,QWORD PTR [rsp+0x20]
  408664:	mov    rsi,QWORD PTR [rsp+0x38]
  408669:	jmp    4086a7 <__swc_fn_6b1cf01f_000063_d9ee99ea+0x447>
  40866b:	mov    rax,r15
  40866e:	add    rax,QWORD PTR [rsp+0x28]
  408673:	mov    r13,QWORD PTR [rsp+0x20]
  408678:	test   r13d,r13d
  40867b:	mov    rcx,r13
  40867e:	mov    edx,0x8
  408683:	cmove  ecx,edx
  408686:	dec    rcx
  408689:	mov    rdx,0xffffffffffffffff
  408690:	sub    rdx,rcx
  408693:	cmp    rax,rdx
  408696:	jbe    40869c <__swc_fn_6b1cf01f_000063_d9ee99ea+0x43c>
  408698:	xor    eax,eax
  40869a:	jmp    4086a4 <__swc_fn_6b1cf01f_000063_d9ee99ea+0x444>
  40869c:	add    rax,rcx
  40869f:	andn   rax,rcx,rax
  4086a4:	mov    rsi,rax
  4086a7:	mov    rax,QWORD PTR [rsp+0x8]
  4086ac:	test   r15,r15
  4086af:	je     4086b8 <__swc_fn_6b1cf01f_000063_d9ee99ea+0x458>
  4086b1:	mov    rdi,QWORD PTR [rsp+0x18]
  4086b6:	jmp    4086ca <__swc_fn_6b1cf01f_000063_d9ee99ea+0x46a>
  4086b8:	mov    rdi,QWORD PTR [rsp+0x18]
  4086bd:	mov    QWORD PTR [rdi+0x40],0x0
  4086c5:	jmp    408746 <__swc_fn_6b1cf01f_000063_d9ee99ea+0x4e6>
  4086ca:	lea    rdx,[rsi-0x58]
  4086ce:	mov    QWORD PTR [rsi-0x58],r15
  4086d2:	mov    QWORD PTR [rsi-0x50],rax
  4086d6:	mov    rax,QWORD PTR [rsp+0x10]
  4086db:	mov    QWORD PTR [rsi-0x48],rax
  4086df:	mov    QWORD PTR [rsi-0x40],rsi
  4086e3:	mov    rax,QWORD PTR [rdi+0x48]
  4086e7:	mov    QWORD PTR [rsi-0x38],rax
  4086eb:	mov    rax,QWORD PTR [rsp+0x30]
  4086f0:	mov    QWORD PTR [rsi-0x30],rax
  4086f4:	mov    DWORD PTR [rsi-0x10],r13d
  4086f8:	mov    QWORD PTR [rsi-0x28],0x0
  408700:	mov    QWORD PTR [rsi-0x20],0x0
  408708:	add    r15,QWORD PTR [r12]
  40870c:	sub    r15,rsi
  40870f:	mov    QWORD PTR [rsi-0x30],r15
  408713:	mov    rcx,QWORD PTR [rbx+0x250]
  40871a:	nop    WORD PTR [rax+rax*1+0x0]
  408720:	lea    r8,[rcx+r15*1]
  408724:	mov    rax,rcx
  408727:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  408730:	cmp    rax,rcx
  408733:	je     40873a <__swc_fn_6b1cf01f_000063_d9ee99ea+0x4da>
  408735:	mov    rcx,rax
  408738:	jmp    408720 <__swc_fn_6b1cf01f_000063_d9ee99ea+0x4c0>
  40873a:	mov    rcx,rbx
  40873d:	call   40be30 <__swc_fn_6b1cf01f_000055_7e1dbcb0>
  408742:	mov    QWORD PTR [rdi+0x40],rsi
  408746:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40874c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  408752:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  408758:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40875e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  408767:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  408770:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  408779:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  408782:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40878b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  408794:	add    rsp,0xf0
  40879b:	pop    rsi
  40879c:	pop    rdi
  40879d:	pop    r15
  40879f:	pop    r14
  4087a1:	pop    r13
  4087a3:	pop    r12
  4087a5:	pop    rbx
  4087a6:	ret
	...

00000000004087b0 <__swc_fn_6b1cf01f_000066_f3aa21af>:
  4087b0:	push   rbx
  4087b1:	push   r12
  4087b3:	push   rdi
  4087b4:	push   rsi
  4087b5:	sub    rsp,0xb8
  4087bc:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4087c2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4087c8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4087ce:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4087d4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4087da:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4087e0:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4087e6:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4087ef:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4087f8:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  408801:	mov    rbx,rdx
  408804:	mov    r12,rcx
  408807:	cmp    DWORD PTR [rbx+0x58],0x0
  40880b:	je     408825 <__swc_fn_6b1cf01f_000066_f3aa21af+0x75>
  40880d:	mov    eax,DWORD PTR [rbx+0x58]
  408810:	sub    eax,0x1
  408813:	test   DWORD PTR [rbx+0x58],eax
  408816:	je     408825 <__swc_fn_6b1cf01f_000066_f3aa21af+0x75>
  408818:	mov    QWORD PTR [rbx+0x40],0x0
  408820:	jmp    408a37 <__swc_fn_6b1cf01f_000066_f3aa21af+0x287>
  408825:	cmp    QWORD PTR [rbx+0x48],0x0
  40882a:	jne    408839 <__swc_fn_6b1cf01f_000066_f3aa21af+0x89>
  40882c:	mov    QWORD PTR [rbx+0x40],0x0
  408834:	jmp    408a37 <__swc_fn_6b1cf01f_000066_f3aa21af+0x287>
  408839:	lea    rax,[rsp+0x8]
  40883e:	mov    rcx,QWORD PTR [rbx+0x48]
  408842:	cmp    rcx,0x8
  408846:	ja     408850 <__swc_fn_6b1cf01f_000066_f3aa21af+0xa0>
  408848:	mov    DWORD PTR [rax],0x0
  40884e:	jmp    4088ab <__swc_fn_6b1cf01f_000066_f3aa21af+0xfb>
  408850:	cmp    rcx,0x80
  408857:	ja     408867 <__swc_fn_6b1cf01f_000066_f3aa21af+0xb7>
  408859:	lea    rcx,[rcx+0xf]
  40885d:	shr    rcx,0x4
  408861:	mov    DWORD PTR [rsp+0x8],ecx
  408865:	jmp    4088ab <__swc_fn_6b1cf01f_000066_f3aa21af+0xfb>
  408867:	cmp    rcx,0x10000
  40886e:	jbe    408878 <__swc_fn_6b1cf01f_000066_f3aa21af+0xc8>
  408870:	mov    DWORD PTR [rax],0xffffffff
  408876:	jmp    4088ab <__swc_fn_6b1cf01f_000066_f3aa21af+0xfb>
  408878:	dec    rcx
  40887b:	xor    edx,edx
  40887d:	lzcnt  rdx,rcx
  408882:	mov    r8d,0x3f
  408888:	sub    r8d,edx
  40888b:	lea    edx,[r8-0x2]
  40888f:	shrx   rcx,rcx,rdx
  408894:	and    ecx,0x3
  408897:	lea    edx,[r8-0x7]
  40889b:	lea    edx,[rdx*4+0x0]
  4088a2:	lea    edx,[rdx+0x9]
  4088a5:	add    edx,ecx
  4088a7:	mov    DWORD PTR [rsp+0x8],edx
  4088ab:	cmp    DWORD PTR [rax],0x0
  4088ae:	jne    4088be <__swc_fn_6b1cf01f_000066_f3aa21af+0x10e>
  4088b0:	cmp    DWORD PTR [rbx+0x58],0x8
  4088b4:	jbe    4088be <__swc_fn_6b1cf01f_000066_f3aa21af+0x10e>
  4088b6:	mov    DWORD PTR [rsp+0x8],0x1
  4088be:	cmp    DWORD PTR [rbx+0x58],0x10
  4088c2:	jbe    408941 <__swc_fn_6b1cf01f_000066_f3aa21af+0x191>
  4088c8:	cmp    DWORD PTR [rbx+0x58],0x40
  4088cc:	ja     408941 <__swc_fn_6b1cf01f_000066_f3aa21af+0x191>
  4088ce:	cmp    DWORD PTR [rax],0xffffffff
  4088d1:	je     408941 <__swc_fn_6b1cf01f_000066_f3aa21af+0x191>
  4088d3:	mov    ecx,DWORD PTR [rsp+0x8]
  4088d7:	mov    edx,DWORD PTR [rbx+0x58]
  4088da:	dec    rdx
  4088dd:	cmp    ecx,0x2d
  4088e0:	jae    408938 <__swc_fn_6b1cf01f_000066_f3aa21af+0x188>
  4088e2:	cs nop WORD PTR [rax+rax*1+0x0]
  4088ec:	nop    DWORD PTR [rax+0x0]
  4088f0:	mov    r8d,ecx
  4088f3:	test   ecx,ecx
  4088f5:	jne    4088ff <__swc_fn_6b1cf01f_000066_f3aa21af+0x14f>
  4088f7:	mov    r8d,0x8
  4088fd:	jmp    40892b <__swc_fn_6b1cf01f_000066_f3aa21af+0x17b>
  4088ff:	cmp    r8d,0x8
  408903:	ja     40890b <__swc_fn_6b1cf01f_000066_f3aa21af+0x15b>
  408905:	shl    r8,0x4
  408909:	jmp    40892b <__swc_fn_6b1cf01f_000066_f3aa21af+0x17b>
  40890b:	lea    r8d,[r8-0x9]
  40890f:	mov    r9d,r8d
  408912:	shr    r9d,0x2
  408916:	and    r8d,0x3
  40891a:	lea    r9d,[r9+0x7]
  40891e:	lea    r9d,[r9-0x2]
  408922:	lea    r8d,[r8+0x5]
  408926:	shlx   r8,r8,r9
  40892b:	test   r8,rdx
  40892e:	je     40893d <__swc_fn_6b1cf01f_000066_f3aa21af+0x18d>
  408930:	add    ecx,0x1
  408933:	cmp    ecx,0x2d
  408936:	jb     4088f0 <__swc_fn_6b1cf01f_000066_f3aa21af+0x140>
  408938:	mov    ecx,0xffffffff
  40893d:	mov    DWORD PTR [rsp+0x8],ecx
  408941:	mov    ecx,DWORD PTR [rsp+0x8]
  408945:	cmp    ecx,0xffffffff
  408948:	je     408950 <__swc_fn_6b1cf01f_000066_f3aa21af+0x1a0>
  40894a:	cmp    DWORD PTR [rbx+0x58],0x40
  40894e:	jbe    408963 <__swc_fn_6b1cf01f_000066_f3aa21af+0x1b3>
  408950:	mov    rcx,r12
  408953:	mov    rdx,rbx
  408956:	mov    r8d,DWORD PTR [rax]
  408959:	call   408260 <__swc_fn_6b1cf01f_000063_d9ee99ea>
  40895e:	jmp    408a37 <__swc_fn_6b1cf01f_000066_f3aa21af+0x287>
  408963:	lea    rax,[rip+0x19696]        # 422000 <__swc_data_base_6b1cf01f>
  40896a:	mov    rax,QWORD PTR [rax]
  40896d:	cmp    rax,0xffffffffffffffff
  408971:	je     408980 <__swc_fn_6b1cf01f_000066_f3aa21af+0x1d0>
  408973:	mov    eax,eax
  408975:	mov    edi,eax
  408977:	xor    eax,eax
  408979:	call   407010 <pthread_getspecific@plt>
  40897e:	jmp    408982 <__swc_fn_6b1cf01f_000066_f3aa21af+0x1d2>
  408980:	xor    eax,eax
  408982:	test   rax,rax
  408985:	jne    408994 <__swc_fn_6b1cf01f_000066_f3aa21af+0x1e4>
  408987:	call   407900 <__swc_fn_6b1cf01f_000033_cd1a4e8c>
  40898c:	mov    rcx,rax
  40898f:	call   40db00 <__swc_fn_6b1cf01f_000130_5f757033>
  408994:	test   rax,rax
  408997:	je     4089a4 <__swc_fn_6b1cf01f_000066_f3aa21af+0x1f4>
  408999:	cmp    QWORD PTR [rax],r12
  40899c:	jne    4089a4 <__swc_fn_6b1cf01f_000066_f3aa21af+0x1f4>
  40899e:	cmp    DWORD PTR [rax+0x20],0x0
  4089a2:	je     4089af <__swc_fn_6b1cf01f_000066_f3aa21af+0x1ff>
  4089a4:	mov    rcx,r12
  4089a7:	mov    rdx,rax
  4089aa:	call   40ba70 <__swc_fn_6b1cf01f_000043_d8bd27c3>
  4089af:	test   rax,rax
  4089b2:	jne    4089be <__swc_fn_6b1cf01f_000066_f3aa21af+0x20e>
  4089b4:	mov    QWORD PTR [rbx+0x40],0x0
  4089bc:	jmp    408a37 <__swc_fn_6b1cf01f_000066_f3aa21af+0x287>
  4089be:	lea    r8,[rsp+0xc]
  4089c3:	mov    ecx,DWORD PTR [rsp+0x8]
  4089c7:	mov    DWORD PTR [rsp+0xc],ecx
  4089cb:	mov    ecx,DWORD PTR [r8]
  4089ce:	lea    rcx,[rcx+rcx*4]
  4089d2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  4089d7:	test   rcx,rcx
  4089da:	je     408a13 <__swc_fn_6b1cf01f_000066_f3aa21af+0x263>
  4089dc:	mov    rdx,QWORD PTR [rcx]
  4089df:	test   rdx,rdx
  4089e2:	je     4089f0 <__swc_fn_6b1cf01f_000066_f3aa21af+0x240>
  4089e4:	mov    r9,QWORD PTR [rdx]
  4089e7:	mov    QWORD PTR [rcx],r9
  4089ea:	add    DWORD PTR [rcx+0x28],0x1
  4089ee:	jmp    408a0e <__swc_fn_6b1cf01f_000066_f3aa21af+0x25e>
  4089f0:	mov    rdx,QWORD PTR [rcx+0x18]
  4089f4:	cmp    QWORD PTR [rcx+0x20],rdx
  4089f8:	jae    408a0c <__swc_fn_6b1cf01f_000066_f3aa21af+0x25c>
  4089fa:	mov    rdx,QWORD PTR [rcx+0x20]
  4089fe:	mov    r9d,DWORD PTR [rcx+0x2c]
  408a02:	add    QWORD PTR [rcx+0x20],r9
  408a06:	add    DWORD PTR [rcx+0x28],0x1
  408a0a:	jmp    408a0e <__swc_fn_6b1cf01f_000066_f3aa21af+0x25e>
  408a0c:	xor    edx,edx
  408a0e:	test   rdx,rdx
  408a11:	jne    408a24 <__swc_fn_6b1cf01f_000066_f3aa21af+0x274>
  408a13:	mov    rcx,r12
  408a16:	mov    rdx,rax
  408a19:	mov    r8d,DWORD PTR [r8]
  408a1c:	call   40bbe0 <__swc_fn_6b1cf01f_000052_faa92dcc>
  408a21:	mov    rdx,rax
  408a24:	test   rdx,rdx
  408a27:	jne    408a33 <__swc_fn_6b1cf01f_000066_f3aa21af+0x283>
  408a29:	mov    QWORD PTR [rbx+0x40],0x0
  408a31:	jmp    408a37 <__swc_fn_6b1cf01f_000066_f3aa21af+0x287>
  408a33:	mov    QWORD PTR [rbx+0x40],rdx
  408a37:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  408a3d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  408a43:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  408a49:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  408a4f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  408a55:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  408a5b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  408a61:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  408a6a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  408a73:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  408a7c:	add    rsp,0xb8
  408a83:	pop    rsi
  408a84:	pop    rdi
  408a85:	pop    r12
  408a87:	pop    rbx
  408a88:	ret
  408a89:	add    BYTE PTR [rax],al
  408a8b:	add    BYTE PTR [rax],al
  408a8d:	add    BYTE PTR [rax],al
	...

0000000000408a90 <__swc_fn_6b1cf01f_000069_b3d7b28e>:
  408a90:	ret
	...

0000000000408aa0 <__swc_fn_6b1cf01f_000072_042643a3>:
  408aa0:	push   r12
  408aa2:	push   r13
  408aa4:	push   r14
  408aa6:	push   rdi
  408aa7:	push   rsi
  408aa8:	sub    rsp,0x1a0
  408aaf:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  408ab8:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  408ac1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  408aca:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  408ad3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  408adc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  408ae5:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  408aee:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  408af7:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  408b00:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  408b09:	mov    r12,rdx
  408b0c:	mov    r13,rcx
  408b0f:	mov    rax,QWORD PTR [r12+0x48]
  408b14:	mov    ecx,DWORD PTR [r12+0x58]
  408b19:	lea    rdx,[rax-0x1]
  408b1d:	cmp    rdx,0x10000
  408b24:	jae    408c1e <__swc_fn_6b1cf01f_000072_042643a3+0x17e>
  408b2a:	cmp    rax,0x8
  408b2e:	ja     408b35 <__swc_fn_6b1cf01f_000072_042643a3+0x95>
  408b30:	xor    r14d,r14d
  408b33:	jmp    408b87 <__swc_fn_6b1cf01f_000072_042643a3+0xe7>
  408b35:	cmp    rax,0x80
  408b3c:	ja     408b48 <__swc_fn_6b1cf01f_000072_042643a3+0xa8>
  408b3e:	lea    r14,[rax+0xf]
  408b42:	shr    r14,0x4
  408b46:	jmp    408b87 <__swc_fn_6b1cf01f_000072_042643a3+0xe7>
  408b48:	cmp    rax,0x10000
  408b4f:	jbe    408b59 <__swc_fn_6b1cf01f_000072_042643a3+0xb9>
  408b51:	mov    r14d,0xffffffff
  408b57:	jmp    408b87 <__swc_fn_6b1cf01f_000072_042643a3+0xe7>
  408b59:	xor    eax,eax
  408b5b:	lzcnt  rax,rdx
  408b60:	mov    r8d,0x3f
  408b66:	sub    r8d,eax
  408b69:	lea    eax,[r8-0x2]
  408b6d:	shrx   rax,rdx,rax
  408b72:	and    eax,0x3
  408b75:	lea    edx,[r8-0x7]
  408b79:	lea    edx,[rdx*4+0x0]
  408b80:	lea    edx,[rdx+0x9]
  408b83:	lea    r14d,[rdx+rax*1]
  408b87:	cmp    ecx,0x8
  408b8a:	jbe    408ba3 <__swc_fn_6b1cf01f_000072_042643a3+0x103>
  408b8c:	cmp    ecx,0x10
  408b8f:	jne    408c1e <__swc_fn_6b1cf01f_000072_042643a3+0x17e>
  408b95:	test   r14d,r14d
  408b98:	mov    eax,0x1
  408b9d:	cmove  r14d,eax
  408ba1:	jmp    408baa <__swc_fn_6b1cf01f_000072_042643a3+0x10a>
  408ba3:	lea    eax,[rcx-0x1]
  408ba6:	test   eax,ecx
  408ba8:	jne    408c1e <__swc_fn_6b1cf01f_000072_042643a3+0x17e>
  408baa:	lea    rax,[rip+0x1944f]        # 422000 <__swc_data_base_6b1cf01f>
  408bb1:	mov    rax,QWORD PTR [rax]
  408bb4:	cmp    rax,0xffffffffffffffff
  408bb8:	je     408bc7 <__swc_fn_6b1cf01f_000072_042643a3+0x127>
  408bba:	mov    eax,eax
  408bbc:	mov    edi,eax
  408bbe:	xor    eax,eax
  408bc0:	call   407010 <pthread_getspecific@plt>
  408bc5:	jmp    408bc9 <__swc_fn_6b1cf01f_000072_042643a3+0x129>
  408bc7:	xor    eax,eax
  408bc9:	test   rax,rax
  408bcc:	je     408c1e <__swc_fn_6b1cf01f_000072_042643a3+0x17e>
  408bce:	cmp    QWORD PTR [rax],r13
  408bd1:	jne    408c1e <__swc_fn_6b1cf01f_000072_042643a3+0x17e>
  408bd3:	lea    rcx,[r14+r14*4]
  408bd7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  408bdc:	test   rax,rax
  408bdf:	je     408c1e <__swc_fn_6b1cf01f_000072_042643a3+0x17e>
  408be1:	mov    rcx,QWORD PTR [rax]
  408be4:	test   rcx,rcx
  408be7:	je     408bf5 <__swc_fn_6b1cf01f_000072_042643a3+0x155>
  408be9:	mov    rdx,QWORD PTR [rcx]
  408bec:	mov    QWORD PTR [rax],rdx
  408bef:	add    DWORD PTR [rax+0x28],0x1
  408bf3:	jmp    408c12 <__swc_fn_6b1cf01f_000072_042643a3+0x172>
  408bf5:	mov    rcx,QWORD PTR [rax+0x18]
  408bf9:	cmp    QWORD PTR [rax+0x20],rcx
  408bfd:	jae    408c10 <__swc_fn_6b1cf01f_000072_042643a3+0x170>
  408bff:	mov    rcx,QWORD PTR [rax+0x20]
  408c03:	mov    edx,DWORD PTR [rax+0x2c]
  408c06:	add    QWORD PTR [rax+0x20],rdx
  408c0a:	add    DWORD PTR [rax+0x28],0x1
  408c0e:	jmp    408c12 <__swc_fn_6b1cf01f_000072_042643a3+0x172>
  408c10:	xor    ecx,ecx
  408c12:	test   rcx,rcx
  408c15:	je     408c1e <__swc_fn_6b1cf01f_000072_042643a3+0x17e>
  408c17:	mov    QWORD PTR [r12+0x40],rcx
  408c1c:	jmp    408c29 <__swc_fn_6b1cf01f_000072_042643a3+0x189>
  408c1e:	mov    rcx,r13
  408c21:	mov    rdx,r12
  408c24:	call   40c660 <__swc_fn_6b1cf01f_000073_64d36d78>
  408c29:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  408c32:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  408c3b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  408c44:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  408c4d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  408c56:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  408c5f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  408c68:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  408c71:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  408c7a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  408c83:	add    rsp,0x1a0
  408c8a:	pop    rsi
  408c8b:	pop    rdi
  408c8c:	pop    r14
  408c8e:	pop    r13
  408c90:	pop    r12
  408c92:	ret
	...

0000000000408ca0 <__swc_fn_6b1cf01f_000075_7b195156>:
  408ca0:	push   r12
  408ca2:	push   r13
  408ca4:	push   r14
  408ca6:	push   r15
  408ca8:	push   rdi
  408ca9:	push   rsi
  408caa:	sub    rsp,0x188
  408cb1:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  408cba:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  408cc3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  408ccc:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  408cd5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  408cde:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  408ce7:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  408cf0:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  408cf9:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  408d02:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  408d0b:	mov    r12,rdx
  408d0e:	mov    r13,rcx
  408d11:	mov    r14,QWORD PTR [r12+0x40]
  408d16:	lea    rax,[rip+0x1b353]        # 424070 <__swc_bss_base_6b1cf01f+0x30>
  408d1d:	mov    rcx,r14
  408d20:	sub    rcx,QWORD PTR [rax+0x8]
  408d24:	mov    rax,QWORD PTR [rip+0x1b355]        # 424080 <__swc_bss_base_6b1cf01f+0x40>
  408d2b:	cmp    rcx,rax
  408d2e:	jae    408d5a <__swc_fn_6b1cf01f_000075_7b195156+0xba>
  408d30:	mov    rax,r14
  408d33:	and    rax,0xffffffffffc00000
  408d3a:	mov    rcx,r14
  408d3d:	shr    rcx,0x10
  408d41:	and    ecx,0x3f
  408d44:	mov    edx,DWORD PTR [rax+0x28]
  408d47:	shrx   ecx,ecx,edx
  408d4c:	shl    rcx,0x4
  408d50:	lea    r15,[rax+rcx*8+0x80]
  408d58:	jmp    408d65 <__swc_fn_6b1cf01f_000075_7b195156+0xc5>
  408d5a:	mov    rcx,r14
  408d5d:	call   407830 <__swc_fn_6b1cf01f_000024_bcdc5519>
  408d62:	mov    r15,rax
  408d65:	test   r15,r15
  408d68:	je     408e0f <__swc_fn_6b1cf01f_000075_7b195156+0x16f>
  408d6e:	lea    rax,[rip+0x1928b]        # 422000 <__swc_data_base_6b1cf01f>
  408d75:	mov    rax,QWORD PTR [rax]
  408d78:	cmp    rax,0xffffffffffffffff
  408d7c:	je     408d8b <__swc_fn_6b1cf01f_000075_7b195156+0xeb>
  408d7e:	mov    eax,eax
  408d80:	mov    edi,eax
  408d82:	xor    eax,eax
  408d84:	call   407010 <pthread_getspecific@plt>
  408d89:	jmp    408d8d <__swc_fn_6b1cf01f_000075_7b195156+0xed>
  408d8b:	xor    eax,eax
  408d8d:	mov    rcx,QWORD PTR [r15+0x40]
  408d91:	cmp    rcx,rax
  408d94:	jne    408df4 <__swc_fn_6b1cf01f_000075_7b195156+0x154>
  408d96:	test   rax,rax
  408d99:	je     408e0f <__swc_fn_6b1cf01f_000075_7b195156+0x16f>
  408d9b:	mov    ecx,DWORD PTR [r15+0x6c]
  408d9f:	test   ecx,ecx
  408da1:	je     408dc1 <__swc_fn_6b1cf01f_000075_7b195156+0x121>
  408da3:	mov    rcx,r13
  408da6:	mov    rdx,rax
  408da9:	mov    r8,r15
  408dac:	mov    QWORD PTR [rsp+0xd8],rax
  408db4:	call   40bb70 <__swc_fn_6b1cf01f_000049_e072b516>
  408db9:	mov    rax,QWORD PTR [rsp+0xd8]
  408dc1:	mov    rcx,QWORD PTR [r15]
  408dc4:	mov    QWORD PTR [r14],rcx
  408dc7:	mov    QWORD PTR [r15],r14
  408dca:	sub    DWORD PTR [r15+0x28],0x1
  408dcf:	jne    408e04 <__swc_fn_6b1cf01f_000075_7b195156+0x164>
  408dd1:	movzx  ecx,BYTE PTR [r15+0x39]
  408dd6:	lea    rcx,[rcx+rcx*4]
  408dda:	lea    rcx,[rax+rcx*8+0x28]
  408ddf:	cmp    QWORD PTR [rcx],r15
  408de2:	je     408e04 <__swc_fn_6b1cf01f_000075_7b195156+0x164>
  408de4:	mov    rcx,r13
  408de7:	mov    rdx,rax
  408dea:	mov    r8,r15
  408ded:	call   410220 <__swc_fn_6b1cf01f_000053_2e3450f7>
  408df2:	jmp    408e04 <__swc_fn_6b1cf01f_000075_7b195156+0x164>
  408df4:	test   rcx,rcx
  408df7:	je     408e0f <__swc_fn_6b1cf01f_000075_7b195156+0x16f>
  408df9:	mov    rcx,r15
  408dfc:	mov    rdx,r14
  408dff:	call   407470 <__swc_fn_6b1cf01f_000012_524c1f23>
  408e04:	mov    QWORD PTR [r12+0x40],0x0
  408e0d:	jmp    408e1a <__swc_fn_6b1cf01f_000075_7b195156+0x17a>
  408e0f:	mov    rcx,r13
  408e12:	mov    rdx,r12
  408e15:	call   40c680 <__swc_fn_6b1cf01f_000076_1966ae2e>
  408e1a:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  408e23:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  408e2c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  408e35:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  408e3e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  408e47:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  408e50:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  408e59:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  408e62:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  408e6b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  408e74:	add    rsp,0x188
  408e7b:	pop    rsi
  408e7c:	pop    rdi
  408e7d:	pop    r15
  408e7f:	pop    r14
  408e81:	pop    r13
  408e83:	pop    r12
  408e85:	ret
	...

0000000000408e90 <__swc_fn_6b1cf01f_000078_d2cd17e2>:
  408e90:	sub    rsp,0x8
  408e94:	mov    rax,rdx
  408e97:	mov    rdx,QWORD PTR [rax+0x40]
  408e9b:	mov    r8,rax
  408e9e:	call   408a90 <__swc_fn_6b1cf01f_000069_b3d7b28e>
  408ea3:	add    rsp,0x8
  408ea7:	ret
	...

0000000000408eb0 <__swc_fn_6b1cf01f_000081_4a10c7e7>:
  408eb0:	push   rsi
  408eb1:	push   rdi
  408eb2:	sub    rsp,0x8
  408eb6:	cmp    rcx,0xffffffffffffffef
  408eba:	ja     408ee0 <__swc_fn_6b1cf01f_000081_4a10c7e7+0x30>
  408ebc:	xor    esi,esi
  408ebe:	lea    rax,[rcx+0x100f]
  408ec5:	and    rax,0xfffffffffffff000
  408ecc:	lea    rcx,[rcx+0x10]
  408ed0:	cmp    rcx,0xfffffffffffff000
  408ed7:	cmovbe rsi,rax
  408edb:	test   rsi,rsi
  408ede:	jne    408ee9 <__swc_fn_6b1cf01f_000081_4a10c7e7+0x39>
  408ee0:	xor    eax,eax
  408ee2:	add    rsp,0x8
  408ee6:	pop    rdi
  408ee7:	pop    rsi
  408ee8:	ret
  408ee9:	mov    rcx,rsi
  408eec:	call   409540 <__swc_fn_6b1cf01f_000111_6b799b8d>
  408ef1:	mov    rdi,rax
  408ef4:	test   rax,rax
  408ef7:	jne    408f02 <__swc_fn_6b1cf01f_000081_4a10c7e7+0x52>
  408ef9:	xor    eax,eax
  408efb:	add    rsp,0x8
  408eff:	pop    rdi
  408f00:	pop    rsi
  408f01:	ret
  408f02:	mov    rcx,rdi
  408f05:	mov    rdx,rsi
  408f08:	call   4116e0 <__swc_fn_6b1cf01f_000113_36905703>
  408f0d:	test   al,al
  408f0f:	jne    408f25 <__swc_fn_6b1cf01f_000081_4a10c7e7+0x75>
  408f11:	mov    rcx,rdi
  408f14:	mov    rdx,rsi
  408f17:	call   40d7b0 <__swc_fn_6b1cf01f_000115_ed2d8fed>
  408f1c:	xor    eax,eax
  408f1e:	add    rsp,0x8
  408f22:	pop    rdi
  408f23:	pop    rsi
  408f24:	ret
  408f25:	mov    QWORD PTR [rdi],rsi
  408f28:	mov    QWORD PTR [rdi+0x8],0x0
  408f30:	lea    rax,[rdi+0x10]
  408f34:	add    rsp,0x8
  408f38:	pop    rdi
  408f39:	pop    rsi
  408f3a:	ret
  408f3b:	add    BYTE PTR [rax],al
  408f3d:	add    BYTE PTR [rax],al
	...

0000000000408f40 <__swc_fn_6b1cf01f_000084_3953ef98>:
  408f40:	sub    rsp,0x8
  408f44:	cmp    BYTE PTR [rcx+0x2c],0x10
  408f48:	jne    408f53 <__swc_fn_6b1cf01f_000084_3953ef98+0x13>
  408f4a:	test   DWORD PTR [rcx+0x28],0x80
  408f51:	je     408f5b <__swc_fn_6b1cf01f_000084_3953ef98+0x1b>
  408f53:	mov    rax,rcx
  408f56:	add    rsp,0x8
  408f5a:	ret
  408f5b:	mov    rcx,QWORD PTR [rcx+0x40]
  408f5f:	call   408f40 <__swc_fn_6b1cf01f_000084_3953ef98>
  408f64:	add    rsp,0x8
  408f68:	ret
	...

0000000000408f80 <__swc_fn_6b1cf01f_000087_d182c4dc>:
  408f80:	push   rsi
  408f81:	push   rdi
  408f82:	push   r12
  408f84:	push   r13
  408f86:	sub    rsp,0x8
  408f8a:	mov    rsi,rdx
  408f8d:	mov    rdi,rcx
  408f90:	xor    r8d,r8d
  408f93:	call   410a40 <__swc_fn_6b1cf01f_000092_63c1827b>
  408f98:	test   al,al
  408f9a:	je     408fac <__swc_fn_6b1cf01f_000087_d182c4dc+0x2c>
  408f9c:	mov    eax,0x1
  408fa1:	add    rsp,0x8
  408fa5:	pop    r13
  408fa7:	pop    r12
  408fa9:	pop    rdi
  408faa:	pop    rsi
  408fab:	ret
  408fac:	rex cmp BYTE PTR [rsi+0x2c],0xe
  408fb1:	je     408fc0 <__swc_fn_6b1cf01f_000087_d182c4dc+0x40>
  408fb3:	xor    eax,eax
  408fb5:	add    rsp,0x8
  408fb9:	pop    r13
  408fbb:	pop    r12
  408fbd:	pop    rdi
  408fbe:	pop    rsi
  408fbf:	ret
  408fc0:	mov    r12,QWORD PTR [rsi+0x98]
  408fc7:	mov    rax,QWORD PTR [rsi+0xa0]
  408fce:	mov    rsi,rax
  408fd1:	xor    r13d,r13d
  408fd4:	test   rsi,rsi
  408fd7:	je     409034 <__swc_fn_6b1cf01f_000087_d182c4dc+0xb4>
  408fd9:	cs nop WORD PTR [rax+rax*1+0x0]
  408fe3:	cs nop WORD PTR [rax+rax*1+0x0]
  408fed:	nop    DWORD PTR [rax]
  408ff0:	lea    rax,[r13*8+0x0]
  408ff8:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  408ffd:	mov    rcx,rax
  409000:	call   408f40 <__swc_fn_6b1cf01f_000084_3953ef98>
  409005:	cmp    BYTE PTR [rax+0x2c],0xe
  409009:	jne    40902a <__swc_fn_6b1cf01f_000087_d182c4dc+0xaa>
  40900b:	mov    rcx,rdi
  40900e:	mov    rdx,rax
  409011:	call   408f80 <__swc_fn_6b1cf01f_000087_d182c4dc>
  409016:	test   al,al
  409018:	je     40902a <__swc_fn_6b1cf01f_000087_d182c4dc+0xaa>
  40901a:	mov    eax,0x1
  40901f:	add    rsp,0x8
  409023:	pop    r13
  409025:	pop    r12
  409027:	pop    rdi
  409028:	pop    rsi
  409029:	ret
  40902a:	add    r13,0x1
  40902e:	sub    rsi,0x1
  409032:	jne    408ff0 <__swc_fn_6b1cf01f_000087_d182c4dc+0x70>
  409034:	xor    eax,eax
  409036:	add    rsp,0x8
  40903a:	pop    r13
  40903c:	pop    r12
  40903e:	pop    rdi
  40903f:	pop    rsi
  409040:	ret
	...

0000000000409050 <__swc_fn_6b1cf01f_000090_14c65203>:
  409050:	sub    rsp,0x18
  409054:	vxorps xmm0,xmm0,xmm0
  409058:	vmovdqu XMMWORD PTR [rsp],xmm0
  40905d:	call   40c890 <__swc_fn_6b1cf01f_000091_c2567a3b>
  409062:	add    rsp,0x18
  409066:	ret
	...

0000000000409070 <__swc_fn_6b1cf01f_000093_ad13d15c>:
  409070:	sub    rsp,0x8
  409074:	mov    rcx,QWORD PTR [rip+0x1dcc5]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40907b:	test   rcx,rcx
  40907e:	jne    409090 <__swc_fn_6b1cf01f_000093_ad13d15c+0x20>
  409080:	call   412640 <__swc_fn_6b1cf01f_000167_994c8876>
  409085:	lea    rcx,[rax+0x1]
  409089:	mov    QWORD PTR [rip+0x1dcb0],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  409090:	dec    rcx
  409093:	call   40f580 <__swc_fn_6b1cf01f_000169_360af05d>
  409098:	mov    rax,QWORD PTR [rax+0xc0]
  40909f:	and    eax,0x1
  4090a2:	setne  al
  4090a5:	add    rsp,0x8
  4090a9:	ret
	...

00000000004090c0 <__swc_fn_6b1cf01f_000096_4f209617>:
  4090c0:	push   rbx
  4090c1:	push   rsi
  4090c2:	push   rdi
  4090c3:	push   r12
  4090c5:	sub    rsp,0x28
  4090c9:	mov    rbx,rcx
  4090cc:	call   410da0 <__swc_fn_6b1cf01f_000095_4185993f>
  4090d1:	mov    rcx,QWORD PTR [rip+0x1dc68]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  4090d8:	test   rcx,rcx
  4090db:	jne    4090ed <__swc_fn_6b1cf01f_000096_4f209617+0x2d>
  4090dd:	call   412640 <__swc_fn_6b1cf01f_000167_994c8876>
  4090e2:	lea    rcx,[rax+0x1]
  4090e6:	mov    QWORD PTR [rip+0x1dc53],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  4090ed:	dec    rcx
  4090f0:	call   40f580 <__swc_fn_6b1cf01f_000169_360af05d>
  4090f5:	mov    rsi,rax
  4090f8:	lea    rcx,[rsp+0x8]
  4090fd:	call   40ccd0 <__swc_fn_6b1cf01f_000094_93bfe675>
  409102:	mov    rdi,QWORD PTR [rsi+0x9c0]
  409109:	mov    r12,QWORD PTR [rsi+0xbe8]
  409110:	lea    rcx,[rsi+0x10]
  409114:	call   40a090 <__swc_fn_6b1cf01f_000159_13ead2ff>
  409119:	mov    rcx,rsi
  40911c:	call   40ce40 <__swc_fn_6b1cf01f_000103_5a85fcf5>
  409121:	vxorps xmm0,xmm0,xmm0
  409125:	xor    eax,eax
  409127:	cs nop WORD PTR [rax+rax*1+0x0]
  409131:	cs nop WORD PTR [rax+rax*1+0x0]
  40913b:	nop    DWORD PTR [rax+rax*1+0x0]
  409140:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  409145:	add    rax,0x10
  409149:	cmp    rax,0xbf0
  409150:	jne    409140 <__swc_fn_6b1cf01f_000096_4f209617+0x80>
  409152:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409158:	vmovups XMMWORD PTR [rsi],xmm0
  40915c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409162:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40916a:	mov    QWORD PTR [rsi+0x9c0],rdi
  409171:	mov    QWORD PTR [rsi+0xbe8],r12
  409178:	mov    rcx,QWORD PTR [rip+0x1dbc1]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40917f:	test   rcx,rcx
  409182:	jne    409194 <__swc_fn_6b1cf01f_000096_4f209617+0xd4>
  409184:	call   412640 <__swc_fn_6b1cf01f_000167_994c8876>
  409189:	lea    rcx,[rax+0x1]
  40918d:	mov    QWORD PTR [rip+0x1dbac],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  409194:	dec    rcx
  409197:	call   40f580 <__swc_fn_6b1cf01f_000169_360af05d>
  40919c:	mov    rsi,rax
  40919f:	mov    QWORD PTR [rsi+0xc0],rbx
  4091a6:	and    ebx,0x1
  4091a9:	jne    4091ad <__swc_fn_6b1cf01f_000096_4f209617+0xed>
  4091ab:	xor    eax,eax
  4091ad:	test   rbx,rbx
  4091b0:	sete   al
  4091b3:	xor    cl,cl
  4091b5:	xor    dl,dl
  4091b7:	xor    r8b,r8b
  4091ba:	xor    r9b,r9b
  4091bd:	xor    r10b,r10b
  4091c0:	mov    r11,rax
  4091c3:	call   40c690 <__swc_fn_6b1cf01f_000079_5cc7acfc>
  4091c8:	lea    rbx,[rsp+0x18]
  4091cd:	mov    rcx,rbx
  4091d0:	call   40ccd0 <__swc_fn_6b1cf01f_000094_93bfe675>
  4091d5:	lea    rcx,[rsi+0x10]
  4091d9:	mov    edx,0x400000
  4091de:	mov    r8,rbx
  4091e1:	call   412380 <__swc_fn_6b1cf01f_000161_8a3d304f>
  4091e6:	lea    rcx,[rsi+0x68]
  4091ea:	mov    edx,0x4000
  4091ef:	mov    r8,rbx
  4091f2:	call   412380 <__swc_fn_6b1cf01f_000161_8a3d304f>
  4091f7:	add    rsp,0x28
  4091fb:	pop    r12
  4091fd:	pop    rdi
  4091fe:	pop    rsi
  4091ff:	pop    rbx
  409200:	ret
	...

0000000000409210 <__swc_fn_6b1cf01f_000099_d0b19c14>:
  409210:	push   rbx
  409211:	push   rsi
  409212:	sub    rsp,0x18
  409216:	mov    rbx,rcx
  409219:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40921e:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409224:	mov    rsi,QWORD PTR [rbx+0x70]
  409228:	lea    rcx,[rcx+0x18]
  40922c:	call   40a090 <__swc_fn_6b1cf01f_000159_13ead2ff>
  409231:	lea    rcx,[rsp+0x8]
  409236:	mov    rdx,rbx
  409239:	mov    r8d,0x78
  40923f:	call   410e00 <__swc_fn_6b1cf01f_000098_d4bdcaa4>
  409244:	mov    rax,rsi
  409247:	add    rsp,0x18
  40924b:	pop    rsi
  40924c:	pop    rbx
  40924d:	ret
	...

0000000000409250 <__swc_fn_6b1cf01f_000102_3c3b96fb>:
  409250:	push   rsi
  409251:	push   rdi
  409252:	sub    rsp,0x8
  409256:	cmp    QWORD PTR [rcx],0x0
  40925a:	jne    409263 <__swc_fn_6b1cf01f_000102_3c3b96fb+0x13>
  40925c:	add    rsp,0x8
  409260:	pop    rdi
  409261:	pop    rsi
  409262:	ret
  409263:	mov    rsi,QWORD PTR [rcx]
  409266:	mov    rax,QWORD PTR [rcx+0x8]
  40926a:	test   rax,rax
  40926d:	je     409283 <__swc_fn_6b1cf01f_000102_3c3b96fb+0x33>
  40926f:	test   DWORD PTR [rax+0x28],0x400000
  409276:	je     409283 <__swc_fn_6b1cf01f_000102_3c3b96fb+0x33>
  409278:	mov    rcx,QWORD PTR [rax+0x30]
  40927c:	test   rcx,rcx
  40927f:	cmovne rax,rcx
  409283:	lea    rdx,[rip+0xa1c6]        # 413450 <__swc_rdata_base_6b1cf01f+0x340>
  40928a:	lea    rcx,[rip+0xa2a7]        # 413538 <__swc_rdata_base_6b1cf01f+0x428>
  409291:	mov    r8,rax
  409294:	xor    r9d,r9d
  409297:	xor    al,al
  409299:	mov    r10,rax
  40929c:	xor    r11d,r11d
  40929f:	call   409050 <__swc_fn_6b1cf01f_000090_14c65203>
  4092a4:	test   rax,rax
  4092a7:	je     4092b7 <__swc_fn_6b1cf01f_000102_3c3b96fb+0x67>
  4092a9:	mov    rdi,QWORD PTR [rax+0x48]
  4092ad:	test   rdi,rdi
  4092b0:	je     4092b7 <__swc_fn_6b1cf01f_000102_3c3b96fb+0x67>
  4092b2:	mov    rcx,rsi
  4092b5:	call   rdi
  4092b7:	add    rsp,0x8
  4092bb:	pop    rdi
  4092bc:	pop    rsi
  4092bd:	ret
	...

00000000004092c0 <__swc_fn_6b1cf01f_000105_90faaa26>:
  4092c0:	push   rbx
  4092c1:	push   rsi
  4092c2:	push   rdi
  4092c3:	sub    rsp,0x20
  4092c7:	mov    rbx,rdx
  4092ca:	mov    rsi,rcx
  4092cd:	mov    rcx,QWORD PTR [rip+0x1da6c]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  4092d4:	test   rcx,rcx
  4092d7:	jne    4092e9 <__swc_fn_6b1cf01f_000105_90faaa26+0x29>
  4092d9:	call   412640 <__swc_fn_6b1cf01f_000167_994c8876>
  4092de:	lea    rcx,[rax+0x1]
  4092e2:	mov    QWORD PTR [rip+0x1da57],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  4092e9:	dec    rcx
  4092ec:	call   40f580 <__swc_fn_6b1cf01f_000169_360af05d>
  4092f1:	mov    rdi,rax
  4092f4:	mov    rax,QWORD PTR [rdi+0xbd0]
  4092fb:	xor    ecx,ecx
  4092fd:	test   rax,rax
  409300:	je     409305 <__swc_fn_6b1cf01f_000105_90faaa26+0x45>
  409302:	mov    rcx,QWORD PTR [rax]
  409305:	call   412770 <__swc_fn_6b1cf01f_000176_718d7b54>
  40930a:	lea    rax,[rsp+0x8]
  40930f:	lea    rcx,[rdi+0x9c8]
  409316:	mov    QWORD PTR [rsp+0x8],rcx
  40931b:	mov    QWORD PTR [rax+0x8],0x40
  409323:	xor    ecx,ecx
  409325:	mov    rdx,rax
  409328:	call   40d8e0 <__swc_fn_6b1cf01f_000121_4f256d58>
  40932d:	mov    DWORD PTR [rdi+0xbc8],eax
  409333:	mov    rdi,QWORD PTR [rdi+0x990]
  40933a:	test   rdi,rdi
  40933d:	je     409347 <__swc_fn_6b1cf01f_000105_90faaa26+0x87>
  40933f:	mov    rcx,rsi
  409342:	mov    rdx,rbx
  409345:	call   rdi
  409347:	call   409070 <__swc_fn_6b1cf01f_000093_ad13d15c>
  40934c:	test   al,al
  40934e:	je     40935e <__swc_fn_6b1cf01f_000105_90faaa26+0x9e>
  409350:	mov    rcx,rsi
  409353:	mov    rdx,rbx
  409356:	xor    r8d,r8d
  409359:	call   411880 <__swc_fn_6b1cf01f_000122_83db7238>
  40935e:	mov    rcx,rsi
  409361:	mov    rdx,rbx
  409364:	call   410f00 <__swc_fn_6b1cf01f_000104_ffe51047>
  409369:	call   4098f0 <__swc_fn_6b1cf01f_000120_be2e2f68>
  40936e:	add    rsp,0x20
  409372:	pop    rdi
  409373:	pop    rsi
  409374:	pop    rbx
  409375:	ret
	...

0000000000409380 <__swc_fn_6b1cf01f_000108_3dc01326>:
  409380:	test   r8,r8
  409383:	jne    409388 <__swc_fn_6b1cf01f_000108_3dc01326+0x8>
  409385:	xor    eax,eax
  409387:	ret
  409388:	xor    eax,eax
  40938a:	nop    WORD PTR [rax+rax*1+0x0]
  409390:	mov    r9,r8
  409393:	sub    r9,rax
  409396:	cmp    r9,0x10
  40939a:	jb     4093e4 <__swc_fn_6b1cf01f_000108_3dc01326+0x64>
  40939c:	lea    r9,[rcx+rax*1]
  4093a0:	lea    r10,[rdx+rax*1]
  4093a4:	vmovups xmm0,XMMWORD PTR [r10]
  4093a9:	vmovups xmm1,XMMWORD PTR [r9]
  4093ae:	vpcmpeqb xmm0,xmm1,xmm0
  4093b2:	vpmovmskb r9d,xmm0
  4093b6:	cmp    r9d,0xffff
  4093bd:	je     4093de <__swc_fn_6b1cf01f_000108_3dc01326+0x5e>
  4093bf:	not    r9d
  4093c2:	xor    r8d,r8d
  4093c5:	movzx  r9d,r9w
  4093c9:	tzcnt  r8d,r9d
  4093ce:	add    rax,r8
  4093d1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  4093d5:	movzx  eax,BYTE PTR [rdx+rax*1]
  4093d9:	sub    ecx,eax
  4093db:	mov    eax,ecx
  4093dd:	ret
  4093de:	lea    rax,[rax+0x10]
  4093e2:	jmp    409390 <__swc_fn_6b1cf01f_000108_3dc01326+0x10>
  4093e4:	cmp    r9,0x8
  4093e8:	jb     40945b <__swc_fn_6b1cf01f_000108_3dc01326+0xdb>
  4093ea:	lea    r9,[rcx+rax*1]
  4093ee:	lea    r10,[rdx+rax*1]
  4093f2:	mov    r9,QWORD PTR [r9]
  4093f5:	xor    r9,QWORD PTR [r10]
  4093f8:	test   r9,r9
  4093fb:	je     409419 <__swc_fn_6b1cf01f_000108_3dc01326+0x99>
  4093fd:	xor    r8d,r8d
  409400:	tzcnt  r8,r9
  409405:	shr    r8,0x3
  409409:	add    rax,r8
  40940c:	movzx  ecx,BYTE PTR [rcx+rax*1]
  409410:	movzx  eax,BYTE PTR [rdx+rax*1]
  409414:	sub    ecx,eax
  409416:	mov    eax,ecx
  409418:	ret
  409419:	lea    rax,[rax+0x8]
  40941d:	cmp    rax,r8
  409420:	jne    409425 <__swc_fn_6b1cf01f_000108_3dc01326+0xa5>
  409422:	xor    eax,eax
  409424:	ret
  409425:	lea    rax,[r8-0x8]
  409429:	lea    r8,[rcx+rax*1]
  40942d:	lea    r9,[rdx+rax*1]
  409431:	mov    r8,QWORD PTR [r8]
  409434:	xor    r8,QWORD PTR [r9]
  409437:	test   r8,r8
  40943a:	je     409458 <__swc_fn_6b1cf01f_000108_3dc01326+0xd8>
  40943c:	xor    r9d,r9d
  40943f:	tzcnt  r9,r8
  409444:	shr    r9,0x3
  409448:	add    rax,r9
  40944b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40944f:	movzx  eax,BYTE PTR [rdx+rax*1]
  409453:	sub    ecx,eax
  409455:	mov    eax,ecx
  409457:	ret
  409458:	xor    eax,eax
  40945a:	ret
  40945b:	cmp    r9,0x4
  40945f:	jb     4094d2 <__swc_fn_6b1cf01f_000108_3dc01326+0x152>
  409461:	lea    r9,[rcx+rax*1]
  409465:	lea    r10,[rdx+rax*1]
  409469:	mov    r9d,DWORD PTR [r9]
  40946c:	xor    r9d,DWORD PTR [r10]
  40946f:	test   r9d,r9d
  409472:	je     409490 <__swc_fn_6b1cf01f_000108_3dc01326+0x110>
  409474:	xor    r8d,r8d
  409477:	tzcnt  r8,r9
  40947c:	shr    r8,0x3
  409480:	add    rax,r8
  409483:	movzx  ecx,BYTE PTR [rcx+rax*1]
  409487:	movzx  eax,BYTE PTR [rdx+rax*1]
  40948b:	sub    ecx,eax
  40948d:	mov    eax,ecx
  40948f:	ret
  409490:	lea    rax,[rax+0x4]
  409494:	cmp    rax,r8
  409497:	jne    40949c <__swc_fn_6b1cf01f_000108_3dc01326+0x11c>
  409499:	xor    eax,eax
  40949b:	ret
  40949c:	lea    rax,[r8-0x4]
  4094a0:	lea    r8,[rcx+rax*1]
  4094a4:	lea    r9,[rdx+rax*1]
  4094a8:	mov    r8d,DWORD PTR [r8]
  4094ab:	xor    r8d,DWORD PTR [r9]
  4094ae:	test   r8d,r8d
  4094b1:	je     4094cf <__swc_fn_6b1cf01f_000108_3dc01326+0x14f>
  4094b3:	xor    r9d,r9d
  4094b6:	tzcnt  r9,r8
  4094bb:	shr    r9,0x3
  4094bf:	add    rax,r9
  4094c2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  4094c6:	movzx  eax,BYTE PTR [rdx+rax*1]
  4094ca:	sub    ecx,eax
  4094cc:	mov    eax,ecx
  4094ce:	ret
  4094cf:	xor    eax,eax
  4094d1:	ret
  4094d2:	cmp    r9,0x2
  4094d6:	jb     409529 <__swc_fn_6b1cf01f_000108_3dc01326+0x1a9>
  4094d8:	lea    r9,[rcx+rax*1]
  4094dc:	lea    r10,[rdx+rax*1]
  4094e0:	mov    r9w,WORD PTR [r9]
  4094e4:	xor    r9w,WORD PTR [r10]
  4094e8:	test   r9w,r9w
  4094ec:	je     40950e <__swc_fn_6b1cf01f_000108_3dc01326+0x18e>
  4094ee:	xor    r8d,r8d
  4094f1:	movzx  r9d,r9w
  4094f5:	tzcnt  r8,r9
  4094fa:	shr    r8,0x3
  4094fe:	add    rax,r8
  409501:	movzx  ecx,BYTE PTR [rcx+rax*1]
  409505:	movzx  eax,BYTE PTR [rdx+rax*1]
  409509:	sub    ecx,eax
  40950b:	mov    eax,ecx
  40950d:	ret
  40950e:	lea    rax,[rax+0x2]
  409512:	cmp    rax,r8
  409515:	jne    40951a <__swc_fn_6b1cf01f_000108_3dc01326+0x19a>
  409517:	xor    eax,eax
  409519:	ret
  40951a:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  409520:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  409526:	sub    eax,ecx
  409528:	ret
  409529:	test   r9,r9
  40952c:	je     40953b <__swc_fn_6b1cf01f_000108_3dc01326+0x1bb>
  40952e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  409532:	movzx  eax,BYTE PTR [rdx+rax*1]
  409536:	sub    ecx,eax
  409538:	mov    eax,ecx
  40953a:	ret
  40953b:	xor    eax,eax
  40953d:	ret
	...

0000000000409540 <__swc_fn_6b1cf01f_000111_6b799b8d>:
  409540:	push   r12
  409542:	push   r13
  409544:	push   r14
  409546:	push   rdi
  409547:	push   rsi
  409548:	push   r15
  40954a:	sub    rsp,0xd8
  409551:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409557:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40955d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  409563:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  409569:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40956f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  409578:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  409581:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40958a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  409593:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40959c:	mov    r12,rcx
  40959f:	test   rcx,rcx
  4095a2:	je     4095be <__swc_fn_6b1cf01f_000111_6b799b8d+0x7e>
  4095a4:	mov    eax,r12d
  4095a7:	and    eax,0xfff
  4095ad:	setne  al
  4095b0:	cmp    r12,0xffffffffffffefff
  4095b7:	seta   cl
  4095ba:	or     al,cl
  4095bc:	je     4095c5 <__swc_fn_6b1cf01f_000111_6b799b8d+0x85>
  4095be:	xor    eax,eax
  4095c0:	jmp    40965b <__swc_fn_6b1cf01f_000111_6b799b8d+0x11b>
  4095c5:	call   4115a0 <__swc_fn_6b1cf01f_000110_126150d1>
  4095ca:	mov    r13,rax
  4095cd:	test   rax,rax
  4095d0:	jne    4095d9 <__swc_fn_6b1cf01f_000111_6b799b8d+0x99>
  4095d2:	xor    eax,eax
  4095d4:	jmp    40965b <__swc_fn_6b1cf01f_000111_6b799b8d+0x11b>
  4095d9:	lea    r14,[r12+0x1000]
  4095e1:	xor    edi,edi
  4095e3:	mov    rsi,r14
  4095e6:	xor    edx,edx
  4095e8:	mov    ecx,0x22
  4095ed:	mov    eax,0xffffffff
  4095f2:	movsxd r8,eax
  4095f5:	xor    r9d,r9d
  4095f8:	xor    eax,eax
  4095fa:	call   407020 <mmap@plt>
  4095ff:	mov    r15,rax
  409602:	cmp    rax,0xffffffffffffffff
  409606:	jne    40960c <__swc_fn_6b1cf01f_000111_6b799b8d+0xcc>
  409608:	xor    eax,eax
  40960a:	jmp    40965b <__swc_fn_6b1cf01f_000111_6b799b8d+0x11b>
  40960c:	mov    rdi,r15
  40960f:	mov    esi,0x1000
  409614:	mov    edx,0x3
  409619:	xor    eax,eax
  40961b:	call   407030 <mprotect@plt>
  409620:	test   eax,eax
  409622:	je     409635 <__swc_fn_6b1cf01f_000111_6b799b8d+0xf5>
  409624:	mov    rdi,r15
  409627:	mov    rsi,r14
  40962a:	xor    eax,eax
  40962c:	call   407040 <munmap@plt>
  409631:	xor    eax,eax
  409633:	jmp    40965b <__swc_fn_6b1cf01f_000111_6b799b8d+0x11b>
  409635:	mov    QWORD PTR [r15+0x8],r12
  409639:	mov    rcx,r13
  40963c:	call   409c90 <__swc_fn_6b1cf01f_000135_8c07c14b>
  409641:	mov    rax,QWORD PTR [r13+0x8]
  409645:	mov    QWORD PTR [r15],rax
  409648:	mov    QWORD PTR [r13+0x8],r15
  40964c:	mov    rcx,r13
  40964f:	call   40dc80 <__swc_fn_6b1cf01f_000136_715e84ff>
  409654:	lea    rax,[r15+0x1000]
  40965b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  409661:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  409667:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40966d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  409673:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  409679:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409682:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40968b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409694:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40969d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  4096a6:	add    rsp,0xd8
  4096ad:	pop    r15
  4096af:	pop    rsi
  4096b0:	pop    rdi
  4096b1:	pop    r14
  4096b3:	pop    r13
  4096b5:	pop    r12
  4096b7:	ret
	...

00000000004096c0 <__swc_fn_6b1cf01f_000114_e9fc0224>:
  4096c0:	push   rbx
  4096c1:	push   r12
  4096c3:	push   rdi
  4096c4:	push   rsi
  4096c5:	sub    rsp,0xa8
  4096cc:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4096d2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4096d8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4096de:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4096e4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4096ea:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4096f0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4096f6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4096fc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409705:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40970e:	mov    rbx,rdx
  409711:	mov    r12,rcx
  409714:	mov    rdi,rcx
  409717:	mov    rsi,rdx
  40971a:	xor    edx,edx
  40971c:	xor    eax,eax
  40971e:	call   407030 <mprotect@plt>
  409723:	test   eax,eax
  409725:	jne    409749 <__swc_fn_6b1cf01f_000114_e9fc0224+0x89>
  409727:	mov    rcx,r12
  40972a:	mov    rdx,rbx
  40972d:	xor    al,al
  40972f:	mov    r8,rax
  409732:	call   40d720 <__swc_fn_6b1cf01f_000112_5f48311c>
  409737:	mov    rdi,r12
  40973a:	mov    rsi,rbx
  40973d:	mov    edx,0x4
  409742:	xor    eax,eax
  409744:	call   407050 <madvise@plt>
  409749:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40974f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409755:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40975b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409761:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409767:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40976d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409773:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409779:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409782:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40978b:	add    rsp,0xa8
  409792:	pop    rsi
  409793:	pop    rdi
  409794:	pop    r12
  409796:	pop    rbx
  409797:	ret
	...

00000000004097a0 <__swc_fn_6b1cf01f_000117_d3318640>:
  4097a0:	push   rsi
  4097a1:	push   rdi
  4097a2:	push   r12
  4097a4:	push   r13
  4097a6:	push   r14
  4097a8:	sub    rsp,0xe0
  4097af:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  4097b5:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  4097bb:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  4097c1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  4097c7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  4097cd:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  4097d6:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  4097df:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  4097e8:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  4097f1:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  4097fa:	mov    rsi,rdx
  4097fd:	mov    rdi,rcx
  409800:	call   4115a0 <__swc_fn_6b1cf01f_000110_126150d1>
  409805:	mov    r12,rax
  409808:	test   rax,rax
  40980b:	jne    409812 <__swc_fn_6b1cf01f_000117_d3318640+0x72>
  40980d:	jmp    409886 <__swc_fn_6b1cf01f_000117_d3318640+0xe6>
  409812:	mov    rcx,r12
  409815:	call   409c90 <__swc_fn_6b1cf01f_000135_8c07c14b>
  40981a:	lea    r13,[r12+0x8]
  40981f:	mov    rax,QWORD PTR [r13+0x0]
  409823:	test   rax,rax
  409826:	je     40987e <__swc_fn_6b1cf01f_000117_d3318640+0xde>
  409828:	nop    DWORD PTR [rax+rax*1+0x0]
  409830:	lea    rcx,[rax+0x1000]
  409837:	cmp    rcx,rdi
  40983a:	jne    409872 <__swc_fn_6b1cf01f_000117_d3318640+0xd2>
  40983c:	cmp    QWORD PTR [rax+0x8],rsi
  409840:	je     40984c <__swc_fn_6b1cf01f_000117_d3318640+0xac>
  409842:	mov    rcx,r12
  409845:	call   40dc80 <__swc_fn_6b1cf01f_000136_715e84ff>
  40984a:	jmp    409886 <__swc_fn_6b1cf01f_000117_d3318640+0xe6>
  40984c:	mov    r14,QWORD PTR [rax]
  40984f:	mov    rdi,rax
  409852:	lea    rsi,[rsi+0x1000]
  409859:	xor    eax,eax
  40985b:	call   407040 <munmap@plt>
  409860:	test   eax,eax
  409862:	jne    409868 <__swc_fn_6b1cf01f_000117_d3318640+0xc8>
  409864:	mov    QWORD PTR [r13+0x0],r14
  409868:	mov    rcx,r12
  40986b:	call   40dc80 <__swc_fn_6b1cf01f_000136_715e84ff>
  409870:	jmp    409886 <__swc_fn_6b1cf01f_000117_d3318640+0xe6>
  409872:	mov    r13,rax
  409875:	mov    rax,QWORD PTR [r13+0x0]
  409879:	test   rax,rax
  40987c:	jne    409830 <__swc_fn_6b1cf01f_000117_d3318640+0x90>
  40987e:	mov    rcx,r12
  409881:	call   40dc80 <__swc_fn_6b1cf01f_000136_715e84ff>
  409886:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40988c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  409892:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  409898:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40989e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  4098a4:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  4098ad:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  4098b6:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  4098bf:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  4098c8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  4098d1:	add    rsp,0xe0
  4098d8:	pop    r14
  4098da:	pop    r13
  4098dc:	pop    r12
  4098de:	pop    rdi
  4098df:	pop    rsi
  4098e0:	ret
	...

00000000004098f0 <__swc_fn_6b1cf01f_000120_be2e2f68>:
  4098f0:	push   rdi
  4098f1:	push   rsi
  4098f2:	sub    rsp,0xa8
  4098f9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4098ff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409905:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40990b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409911:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409917:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40991d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409923:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409929:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409932:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40993b:	mov    rdi,0xfffffffffffffd66
  409942:	xor    eax,eax
  409944:	call   407060 <exit@plt>
  409949:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40994f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409955:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40995b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409961:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409967:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40996d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409973:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409979:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409982:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40998b:	add    rsp,0xa8
  409992:	pop    rsi
  409993:	pop    rdi
  409994:	ret
	...

00000000004099a0 <__swc_fn_6b1cf01f_000123_540bf7e8>:
  4099a0:	push   rbx
  4099a1:	push   rsi
  4099a2:	push   rdi
  4099a3:	sub    rsp,0x30
  4099a7:	mov    rbx,rdx
  4099aa:	mov    esi,ecx
  4099ac:	test   ecx,ecx
  4099ae:	je     409a83 <__swc_fn_6b1cf01f_000123_540bf7e8+0xe3>
  4099b4:	mov    rcx,rsi
  4099b7:	shl    rcx,0x4
  4099bb:	call   408eb0 <__swc_fn_6b1cf01f_000081_4a10c7e7>
  4099c0:	test   rax,rax
  4099c3:	je     409a72 <__swc_fn_6b1cf01f_000123_540bf7e8+0xd2>
  4099c9:	mov    rcx,rsi
  4099cc:	xor    edx,edx
  4099ce:	test   rsi,rsi
  4099d1:	jbe    409a52 <__swc_fn_6b1cf01f_000123_540bf7e8+0xb2>
  4099d7:	nop    WORD PTR [rax+rax*1+0x0]
  4099e0:	mov    r8d,edx
  4099e3:	mov    r9,QWORD PTR [rbx+r8*8]
  4099e7:	add    r8,r8
  4099ea:	lea    r8,[rax+r8*8]
  4099ee:	xor    r10d,r10d
  4099f1:	test   r9,r9
  4099f4:	je     409a30 <__swc_fn_6b1cf01f_000123_540bf7e8+0x90>
  4099f6:	mov    r11,r9
  4099f9:	mov    dil,BYTE PTR [r11]
  4099fc:	test   dil,dil
  4099ff:	je     409a30 <__swc_fn_6b1cf01f_000123_540bf7e8+0x90>
  409a01:	cs nop WORD PTR [rax+rax*1+0x0]
  409a0b:	cs nop WORD PTR [rax+rax*1+0x0]
  409a15:	cs nop WORD PTR [rax+rax*1+0x0]
  409a1f:	nop
  409a20:	add    r11,0x1
  409a24:	add    r10,0x1
  409a28:	mov    dil,BYTE PTR [r11]
  409a2b:	test   dil,dil
  409a2e:	jne    409a20 <__swc_fn_6b1cf01f_000123_540bf7e8+0x80>
  409a30:	mov    QWORD PTR [rsp+0x18],r9
  409a35:	mov    QWORD PTR [rsp+0x20],r10
  409a3a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409a40:	vmovups XMMWORD PTR [r8],xmm0
  409a45:	add    rdx,0x1
  409a49:	cmp    rdx,rcx
  409a4c:	jb     4099e0 <__swc_fn_6b1cf01f_000123_540bf7e8+0x40>
  409a52:	lea    rcx,[rip+0x1d2f7]        # 426d50 <__swc_bss_base_6b1cf01f+0x2d10>
  409a59:	mov    QWORD PTR [rsp+0x8],rax
  409a5e:	mov    esi,esi
  409a60:	mov    QWORD PTR [rsp+0x10],rsi
  409a65:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409a6b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409a70:	jmp    409a83 <__swc_fn_6b1cf01f_000123_540bf7e8+0xe3>
  409a72:	lea    rcx,[rip+0x9ccf]        # 413748 <__swc_rdata_base_6b1cf01f+0x638>
  409a79:	call   40d7d0 <__swc_fn_6b1cf01f_000118_2648f149>
  409a7e:	call   4098f0 <__swc_fn_6b1cf01f_000120_be2e2f68>
  409a83:	add    rsp,0x30
  409a87:	pop    rdi
  409a88:	pop    rsi
  409a89:	pop    rbx
  409a8a:	ret
  409a8b:	add    BYTE PTR [rax],al
  409a8d:	add    BYTE PTR [rax],al
	...

0000000000409a90 <__swc_fn_6b1cf01f_000126_a481cb88>:
  409a90:	push   rdi
  409a91:	push   rsi
  409a92:	sub    rsp,0xa8
  409a99:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409a9f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409aa5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409aab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409ab1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409ab7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409abd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409ac3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409ac9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409ad2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409adb:	mov    edi,ecx
  409add:	xor    eax,eax
  409adf:	call   407070 <pthread_key_delete@plt>
  409ae4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409aea:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409af0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409af6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409afc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409b02:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409b08:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409b0e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409b14:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409b1d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409b26:	add    rsp,0xa8
  409b2d:	pop    rsi
  409b2e:	pop    rdi
  409b2f:	ret

0000000000409b30 <__swc_fn_6b1cf01f_000129_a611b8c4>:
  409b30:	push   rdi
  409b31:	push   rsi
  409b32:	sub    rsp,0xa8
  409b39:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409b3f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409b45:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409b4b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409b51:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409b57:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409b5d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409b63:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409b69:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409b72:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409b7b:	test   rcx,rcx
  409b7e:	je     409b8f <__swc_fn_6b1cf01f_000129_a611b8c4+0x5f>
  409b80:	lea    rax,[rcx-0x1]
  409b84:	mov    eax,eax
  409b86:	mov    edi,eax
  409b88:	xor    eax,eax
  409b8a:	call   407070 <pthread_key_delete@plt>
  409b8f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409b95:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409b9b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409ba1:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409ba7:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409bad:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409bb3:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409bb9:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409bbf:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409bc8:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409bd1:	add    rsp,0xa8
  409bd8:	pop    rsi
  409bd9:	pop    rdi
  409bda:	ret
  409bdb:	add    BYTE PTR [rax],al
  409bdd:	add    BYTE PTR [rax],al
	...

0000000000409be0 <__swc_fn_6b1cf01f_000132_a9c1c700>:
  409be0:	push   rsi
  409be1:	push   rdi
  409be2:	sub    rsp,0xa8
  409be9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409bef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409bf5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409bfb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409c01:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409c07:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409c0d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409c13:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409c19:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409c22:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409c2b:	xor    eax,eax
  409c2d:	call   407080 <gettid@plt>
  409c32:	movsxd rax,eax
  409c35:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409c3b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409c41:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409c47:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409c4d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409c53:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409c59:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409c5f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409c65:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409c6e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409c77:	add    rsp,0xa8
  409c7e:	pop    rdi
  409c7f:	pop    rsi
  409c80:	ret
	...

0000000000409c90 <__swc_fn_6b1cf01f_000135_8c07c14b>:
  409c90:	push   rbx
  409c91:	push   rdi
  409c92:	push   rsi
  409c93:	sub    rsp,0xc0
  409c9a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409ca0:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409ca6:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409cac:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409cb2:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409cb8:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409cbe:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409cc4:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409ccd:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409cd6:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409cdf:	mov    rbx,rcx
  409ce2:	cs nop WORD PTR [rax+rax*1+0x0]
  409cec:	nop    DWORD PTR [rax+0x0]
  409cf0:	mov    edx,0x80000000
  409cf5:	xor    eax,eax
  409cf7:	lock cmpxchg DWORD PTR [rbx],edx
  409cfb:	test   eax,eax
  409cfd:	je     409d34 <__swc_fn_6b1cf01f_000135_8c07c14b+0xa4>
  409cff:	mov    eax,DWORD PTR [rbx]
  409d01:	lea    rcx,[rsp+0x14]
  409d06:	mov    DWORD PTR [rsp+0x14],eax
  409d0a:	test   eax,eax
  409d0c:	je     409cf0 <__swc_fn_6b1cf01f_000135_8c07c14b+0x60>
  409d0e:	mov    QWORD PTR [rsp],0x0
  409d16:	mov    edi,0xca
  409d1b:	mov    rsi,rbx
  409d1e:	mov    edx,0x80
  409d23:	mov    ecx,DWORD PTR [rcx]
  409d25:	xor    r8d,r8d
  409d28:	xor    r9d,r9d
  409d2b:	xor    eax,eax
  409d2d:	call   407090 <syscall@plt>
  409d32:	jmp    409cf0 <__swc_fn_6b1cf01f_000135_8c07c14b+0x60>
  409d34:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409d3a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409d40:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409d46:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409d4c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409d52:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409d58:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409d5e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409d67:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409d70:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409d79:	add    rsp,0xc0
  409d80:	pop    rsi
  409d81:	pop    rdi
  409d82:	pop    rbx
  409d83:	ret
	...

0000000000409d90 <__swc_fn_6b1cf01f_000138_055b38a4>:
  409d90:	sub    rsp,0x8
  409d94:	call   40dc80 <__swc_fn_6b1cf01f_000136_715e84ff>
  409d99:	add    rsp,0x8
  409d9d:	ret
	...

0000000000409da0 <__swc_fn_6b1cf01f_000141_d299b428>:
  409da0:	push   rdi
  409da1:	push   rsi
  409da2:	sub    rsp,0xa8
  409da9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409daf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409db5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409dbb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409dc1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409dc7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409dcd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409dd3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409dd9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409de2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409deb:	mov    edi,0x28
  409df0:	xor    eax,eax
  409df2:	call   4070a0 <malloc@plt>
  409df7:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409dfd:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409e03:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409e09:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409e0f:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409e15:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409e1b:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409e21:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409e27:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409e30:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409e39:	add    rsp,0xa8
  409e40:	pop    rsi
  409e41:	pop    rdi
  409e42:	ret
	...

0000000000409e50 <__swc_fn_6b1cf01f_000144_162f363d>:
  409e50:	mov    QWORD PTR [r8],0x0
  409e57:	cmp    rdx,0x10
  409e5b:	jae    409e60 <__swc_fn_6b1cf01f_000144_162f363d+0x10>
  409e5d:	xor    eax,eax
  409e5f:	ret
  409e60:	mov    eax,DWORD PTR [rcx]
  409e62:	cmp    eax,0x42445753
  409e68:	jne    409e72 <__swc_fn_6b1cf01f_000144_162f363d+0x22>
  409e6a:	mov    eax,DWORD PTR [rcx+0x4]
  409e6d:	cmp    eax,0x1
  409e70:	je     409e75 <__swc_fn_6b1cf01f_000144_162f363d+0x25>
  409e72:	xor    eax,eax
  409e74:	ret
  409e75:	mov    QWORD PTR [r8],rdx
  409e78:	mov    rax,rcx
  409e7b:	ret
  409e7c:	add    BYTE PTR [rax],al
	...

0000000000409e80 <__swc_fn_6b1cf01f_000147_2eb804cc>:
  409e80:	push   rbx
  409e81:	sub    rsp,0xe0
  409e88:	lea    rbx,[rsp+0x8]
  409e8d:	vxorps xmm0,xmm0,xmm0
  409e91:	vmovups YMMWORD PTR [rbx],ymm0
  409e95:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  409e9a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  409e9f:	vzeroupper
  409ea2:	mov    DWORD PTR [rbx+0x60],0x0
  409ea9:	mov    r8,rbx
  409eac:	mov    rdx,rcx
  409eaf:	nop
  409eb0:	mov    r9,rdx
  409eb3:	movabs rdx,0x6666666666666667
  409ebd:	mov    rax,r9
  409ec0:	imul   rdx
  409ec3:	sar    rdx,0x2
  409ec7:	mov    r10,rdx
  409eca:	shr    rdx,0x3f
  409ece:	add    r10,rdx
  409ed1:	mov    rdx,r10
  409ed4:	imul   r11,r10,0xa
  409ed8:	sub    r9,r11
  409edb:	mov    r11,QWORD PTR [rip+0x9886]        # 413768 <__swc_rdata_base_6b1cf01f+0x658>
  409ee2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  409ee7:	mov    BYTE PTR [r8],r9b
  409eea:	lea    r9,[r8+0x1]
  409eee:	mov    r8,r9
  409ef1:	test   r10,r10
  409ef4:	jne    409eb0 <__swc_fn_6b1cf01f_000147_2eb804cc+0x30>
  409ef6:	test   rcx,rcx
  409ef9:	jge    409f03 <__swc_fn_6b1cf01f_000147_2eb804cc+0x83>
  409efb:	mov    BYTE PTR [r9],0x2d
  409eff:	add    r8,0x1
  409f03:	mov    BYTE PTR [r8],0x0
  409f07:	sub    r8,0x1
  409f0b:	mov    rax,rbx
  409f0e:	cmp    rax,r8
  409f11:	jae    409f36 <__swc_fn_6b1cf01f_000147_2eb804cc+0xb6>
  409f13:	cs nop WORD PTR [rax+rax*1+0x0]
  409f1d:	nop    DWORD PTR [rax]
  409f20:	mov    cl,BYTE PTR [r8]
  409f23:	mov    dl,BYTE PTR [rax]
  409f25:	mov    BYTE PTR [r8],dl
  409f28:	sub    r8,0x1
  409f2c:	mov    BYTE PTR [rax],cl
  409f2e:	inc    rax
  409f31:	cmp    rax,r8
  409f34:	jb     409f20 <__swc_fn_6b1cf01f_000147_2eb804cc+0xa0>
  409f36:	xor    eax,eax
  409f38:	test   rbx,rbx
  409f3b:	je     409f5e <__swc_fn_6b1cf01f_000147_2eb804cc+0xde>
  409f3d:	mov    rcx,rbx
  409f40:	mov    dl,BYTE PTR [rcx]
  409f42:	test   dl,dl
  409f44:	je     409f5e <__swc_fn_6b1cf01f_000147_2eb804cc+0xde>
  409f46:	cs nop WORD PTR [rax+rax*1+0x0]
  409f50:	add    rcx,0x1
  409f54:	add    rax,0x1
  409f58:	mov    dl,BYTE PTR [rcx]
  409f5a:	test   dl,dl
  409f5c:	jne    409f50 <__swc_fn_6b1cf01f_000147_2eb804cc+0xd0>
  409f5e:	mov    QWORD PTR [rbx+0xa8],rbx
  409f65:	mov    QWORD PTR [rbx+0xb0],rax
  409f6c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  409f74:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  409f7c:	lea    rcx,[rbx+0xb8]
  409f83:	call   40d7d0 <__swc_fn_6b1cf01f_000118_2648f149>
  409f88:	add    rsp,0xe0
  409f8f:	pop    rbx
  409f90:	ret
	...

0000000000409fa0 <__swc_fn_6b1cf01f_000150_86f1d437>:
  409fa0:	vxorps xmm0,xmm0,xmm0
  409fa4:	vmovups XMMWORD PTR [rcx],xmm0
  409fa8:	mov    QWORD PTR [rcx+0x10],0x0
  409fb0:	ret
	...

0000000000409fc0 <__swc_fn_6b1cf01f_000153_86f1d437>:
  409fc0:	vxorps xmm0,xmm0,xmm0
  409fc4:	vmovups XMMWORD PTR [rcx],xmm0
  409fc8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409fcd:	vxorps xmm0,xmm0,xmm0
  409fd1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409fd6:	vmovups xmm0,XMMWORD PTR [rip+0x9862]        # 413840 <__swc_rdata_base_6b1cf01f+0x730>
  409fde:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409fe3:	vxorps xmm0,xmm0,xmm0
  409fe7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  409fec:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  409ff1:	mov    QWORD PTR [rcx+0x60],0x0
  409ff9:	ret
  409ffa:	add    BYTE PTR [rax],al
  409ffc:	add    BYTE PTR [rax],al
	...

000000000040a000 <__swc_fn_6b1cf01f_000156_86f1d437>:
  40a000:	vxorps xmm0,xmm0,xmm0
  40a004:	vmovups XMMWORD PTR [rcx],xmm0
  40a008:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a00d:	vxorps xmm0,xmm0,xmm0
  40a011:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a016:	vmovups xmm0,XMMWORD PTR [rip+0x994a]        # 413968 <__swc_rdata_base_6b1cf01f+0x858>
  40a01e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a023:	vxorps xmm0,xmm0,xmm0
  40a027:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40a02c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40a031:	vxorps xmm0,xmm0,xmm0
  40a035:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40a03a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40a03f:	vxorps xmm0,xmm0,xmm0
  40a043:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40a04b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40a053:	vxorps xmm0,xmm0,xmm0
  40a057:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40a05f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40a067:	vxorps xmm0,xmm0,xmm0
  40a06b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40a073:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40a07b:	mov    QWORD PTR [rcx+0xe0],0x0
  40a086:	ret
	...

000000000040a090 <__swc_fn_6b1cf01f_000159_13ead2ff>:
  40a090:	push   rbx
  40a091:	mov    rbx,rcx
  40a094:	call   40f210 <__swc_fn_6b1cf01f_000160_e36363a8>
  40a099:	mov    rax,QWORD PTR [rbx+0x10]
  40a09d:	test   rax,rax
  40a0a0:	je     40a0b1 <__swc_fn_6b1cf01f_000159_13ead2ff+0x21>
  40a0a2:	mov    rcx,rbx
  40a0a5:	mov    rdx,rax
  40a0a8:	mov    r8,QWORD PTR [rbx+0x18]
  40a0ac:	call   412330 <__swc_fn_6b1cf01f_000158_47b270e1>
  40a0b1:	vxorps xmm0,xmm0,xmm0
  40a0b5:	vmovups XMMWORD PTR [rbx],xmm0
  40a0b9:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a0be:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a0c3:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40a0c8:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40a0cd:	mov    QWORD PTR [rbx+0x50],0x0
  40a0d5:	pop    rbx
  40a0d6:	ret
	...

000000000040a0e0 <__swc_fn_6b1cf01f_000162_72795826>:
  40a0e0:	sub    rsp,0x10
  40a0e4:	mov    eax,r8d
  40a0e7:	mov    r8d,r9d
  40a0ea:	test   r9d,r9d
  40a0ed:	jne    40a106 <__swc_fn_6b1cf01f_000162_72795826+0x26>
  40a0ef:	vmovups xmm0,XMMWORD PTR [rip+0x9929]        # 413a20 <__swc_rdata_base_6b1cf01f+0x910>
  40a0f7:	vmovups XMMWORD PTR [r10],xmm0
  40a0fc:	mov    eax,0x1
  40a101:	add    rsp,0x10
  40a105:	ret
  40a106:	mov    r9,r8
  40a109:	cmp    r8,rax
  40a10c:	jb     40a113 <__swc_fn_6b1cf01f_000162_72795826+0x33>
  40a10e:	cmp    r9,rdx
  40a111:	jb     40a11a <__swc_fn_6b1cf01f_000162_72795826+0x3a>
  40a113:	xor    eax,eax
  40a115:	add    rsp,0x10
  40a119:	ret
  40a11a:	xor    eax,eax
  40a11c:	lea    r8,[r9+rax*1]
  40a120:	cmp    r8,rdx
  40a123:	jae    40a153 <__swc_fn_6b1cf01f_000162_72795826+0x73>
  40a125:	cs nop WORD PTR [rax+rax*1+0x0]
  40a12f:	cs nop WORD PTR [rax+rax*1+0x0]
  40a139:	nop    DWORD PTR [rax+0x0]
  40a140:	cmp    BYTE PTR [rcx+r8*1],0x0
  40a145:	je     40a153 <__swc_fn_6b1cf01f_000162_72795826+0x73>
  40a147:	inc    rax
  40a14a:	lea    r8,[r9+rax*1]
  40a14e:	cmp    r8,rdx
  40a151:	jb     40a140 <__swc_fn_6b1cf01f_000162_72795826+0x60>
  40a153:	cmp    r8,rdx
  40a156:	jne    40a15f <__swc_fn_6b1cf01f_000162_72795826+0x7f>
  40a158:	xor    eax,eax
  40a15a:	add    rsp,0x10
  40a15e:	ret
  40a15f:	add    rcx,r9
  40a162:	mov    QWORD PTR [rsp],rcx
  40a166:	mov    QWORD PTR [rsp+0x8],rax
  40a16b:	vmovups xmm0,XMMWORD PTR [rsp]
  40a170:	vmovups XMMWORD PTR [r10],xmm0
  40a175:	mov    eax,0x1
  40a17a:	add    rsp,0x10
  40a17e:	ret
	...

000000000040a180 <__swc_fn_6b1cf01f_000165_bcc835b8>:
  40a180:	push   rbp
  40a181:	push   rbx
  40a182:	push   rsi
  40a183:	push   rdi
  40a184:	push   r12
  40a186:	push   r13
  40a188:	push   r14
  40a18a:	push   r15
  40a18c:	sub    rsp,0x10
  40a190:	mov    rbp,rsp
  40a193:	vmovups XMMWORD PTR [rsp],xmm6
  40a198:	sub    rsp,0x50
  40a19c:	mov    rbx,rsp
  40a19f:	mov    rsi,r8
  40a1a2:	mov    QWORD PTR [rsp+0x30],r8
  40a1a7:	mov    rdi,rcx
  40a1aa:	mov    QWORD PTR [rsp+0x38],rcx
  40a1af:	mov    r12,rdx
  40a1b2:	xor    r13b,r13b
  40a1b5:	mov    r14,QWORD PTR [rdi+0x8]
  40a1b9:	mov    QWORD PTR [rsp+0x40],r14
  40a1be:	xor    r15d,r15d
  40a1c1:	test   r14,r14
  40a1c4:	jbe    40a41e <__swc_fn_6b1cf01f_000165_bcc835b8+0x29e>
  40a1ca:	mov    r14,QWORD PTR [rdi]
  40a1cd:	mov    rax,QWORD PTR [rsp+0x40]
  40a1d2:	mov    QWORD PTR [rsp+0x48],r14
  40a1d7:	vmovups xmm6,XMMWORD PTR [rip+0x9481]        # 413660 <__swc_rdata_base_6b1cf01f+0x550>
  40a1df:	nop
  40a1e0:	cmp    QWORD PTR [r14+r15*8],0x0
  40a1e5:	jne    40a1ef <__swc_fn_6b1cf01f_000165_bcc835b8+0x6f>
  40a1e7:	mov    r14,rax
  40a1ea:	jmp    40a3fe <__swc_fn_6b1cf01f_000165_bcc835b8+0x27e>
  40a1ef:	mov    rcx,QWORD PTR [rdi]
  40a1f2:	mov    rdx,QWORD PTR [rcx+r15*8]
  40a1f6:	mov    rdi,rbx
  40a1f9:	mov    rcx,rdi
  40a1fc:	sub    rsp,0x8
  40a200:	mov    r14,rax
  40a203:	call   4123b0 <__swc_fn_6b1cf01f_000164_cc119975>
  40a208:	add    rsp,0x8
  40a20c:	mov    al,BYTE PTR [rbx]
  40a20e:	test   al,al
  40a210:	je     40a3fe <__swc_fn_6b1cf01f_000165_bcc835b8+0x27e>
  40a216:	mov    al,BYTE PTR [rbx+0x1]
  40a219:	test   al,al
  40a21b:	jne    40a226 <__swc_fn_6b1cf01f_000165_bcc835b8+0xa6>
  40a21d:	test   sil,sil
  40a220:	je     40a3fe <__swc_fn_6b1cf01f_000165_bcc835b8+0x27e>
  40a226:	test   r13b,r13b
  40a229:	jne    40a2e7 <__swc_fn_6b1cf01f_000165_bcc835b8+0x167>
  40a22f:	test   r12,r12
  40a232:	je     40a2e7 <__swc_fn_6b1cf01f_000165_bcc835b8+0x167>
  40a238:	mov    al,BYTE PTR [rbx+0x1]
  40a23b:	test   al,al
  40a23d:	je     40a3fe <__swc_fn_6b1cf01f_000165_bcc835b8+0x27e>
  40a243:	mov    eax,DWORD PTR [rbx+0x28]
  40a246:	cmp    DWORD PTR [r12+0x20],eax
  40a24b:	jne    40a3fe <__swc_fn_6b1cf01f_000165_bcc835b8+0x27e>
  40a251:	mov    rax,QWORD PTR [r12]
  40a255:	mov    rcx,QWORD PTR [r12+0x8]
  40a25a:	cmp    QWORD PTR [rbx+0x20],rcx
  40a25e:	jne    40a3fe <__swc_fn_6b1cf01f_000165_bcc835b8+0x27e>
  40a264:	mov    cl,0x1
  40a266:	test   rax,rax
  40a269:	je     40a2d2 <__swc_fn_6b1cf01f_000165_bcc835b8+0x152>
  40a26f:	mov    rdx,QWORD PTR [rbx+0x20]
  40a273:	xor    r8d,r8d
  40a276:	test   rdx,rdx
  40a279:	jbe    40a2d2 <__swc_fn_6b1cf01f_000165_bcc835b8+0x152>
  40a27b:	mov    r9,QWORD PTR [rbx+0x18]
  40a27f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40a284:	cs nop WORD PTR [rax+rax*1+0x0]
  40a28e:	xchg   ax,ax
  40a290:	mov    r10b,BYTE PTR [rax+r8*1]
  40a294:	cmp    BYTE PTR [r9+r8*1],r10b
  40a298:	je     40a2c9 <__swc_fn_6b1cf01f_000165_bcc835b8+0x149>
  40a29a:	vmovq  r10,xmm0
  40a29f:	cmp    BYTE PTR [r10+r8*1],0x5c
  40a2a4:	jne    40a2ad <__swc_fn_6b1cf01f_000165_bcc835b8+0x12d>
  40a2a6:	cmp    BYTE PTR [rax+r8*1],0x2f
  40a2ab:	je     40a2c9 <__swc_fn_6b1cf01f_000165_bcc835b8+0x149>
  40a2ad:	vmovq  r10,xmm0
  40a2b2:	cmp    BYTE PTR [r10+r8*1],0x2f
  40a2b7:	jne    40a2c0 <__swc_fn_6b1cf01f_000165_bcc835b8+0x140>
  40a2b9:	cmp    BYTE PTR [rax+r8*1],0x5c
  40a2be:	je     40a2c9 <__swc_fn_6b1cf01f_000165_bcc835b8+0x149>
  40a2c0:	xor    eax,eax
  40a2c2:	movzx  eax,al
  40a2c5:	mov    cl,al
  40a2c7:	jmp    40a2d2 <__swc_fn_6b1cf01f_000165_bcc835b8+0x152>
  40a2c9:	add    r8,0x1
  40a2cd:	cmp    r8,rdx
  40a2d0:	jb     40a290 <__swc_fn_6b1cf01f_000165_bcc835b8+0x110>
  40a2d2:	test   cl,cl
  40a2d4:	je     40a3fe <__swc_fn_6b1cf01f_000165_bcc835b8+0x27e>
  40a2da:	mov    eax,0x1
  40a2df:	mov    r13b,al
  40a2e2:	jmp    40a3fe <__swc_fn_6b1cf01f_000165_bcc835b8+0x27e>
  40a2e7:	mov    r13b,0x1
  40a2ea:	sub    rsp,0x20
  40a2ee:	mov    rax,rsp
  40a2f1:	lea    rcx,[rdi+0x8]
  40a2f5:	mov    QWORD PTR [rax],rcx
  40a2f8:	lea    rsi,[rip+0x8f61]        # 413260 <__swc_rdata_base_6b1cf01f+0x150>
  40a2ff:	mov    QWORD PTR [rax+0x8],rsi
  40a303:	mov    QWORD PTR [rax+0x10],rsp
  40a307:	mov    QWORD PTR [rax+0x18],0x1
  40a30f:	lea    rcx,[rsp+0x10]
  40a314:	sub    rsp,0x8
  40a318:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  40a31d:	add    rsp,0x8
  40a321:	add    rsp,0x20
  40a325:	mov    al,BYTE PTR [rbx+0x1]
  40a328:	test   al,al
  40a32a:	je     40a3c7 <__swc_fn_6b1cf01f_000165_bcc835b8+0x247>
  40a330:	lea    rax,[rip+0x9789]        # 413ac0 <__swc_rdata_base_6b1cf01f+0x9b0>
  40a337:	sub    rsp,0x20
  40a33b:	mov    rcx,rsp
  40a33e:	mov    QWORD PTR [rcx],rax
  40a341:	mov    QWORD PTR [rcx+0x8],rsi
  40a345:	mov    QWORD PTR [rcx+0x10],rsp
  40a349:	mov    QWORD PTR [rcx+0x18],0x1
  40a351:	lea    rcx,[rsp+0x10]
  40a356:	sub    rsp,0x8
  40a35a:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  40a35f:	add    rsp,0x8
  40a363:	add    rsp,0x20
  40a367:	mov    eax,DWORD PTR [rbx+0x28]
  40a36a:	sub    rsp,0x60
  40a36e:	mov    rcx,rsp
  40a371:	lea    rdx,[rdi+0x18]
  40a375:	mov    QWORD PTR [rcx+0x18],rdx
  40a379:	mov    QWORD PTR [rcx+0x20],rsi
  40a37d:	vmovups XMMWORD PTR [rcx],xmm6
  40a381:	mov    QWORD PTR [rcx+0x28],rsp
  40a385:	mov    QWORD PTR [rcx+0x30],rsi
  40a389:	mov    DWORD PTR [rcx+0x10],eax
  40a38c:	lea    rax,[rsp+0x10]
  40a391:	mov    QWORD PTR [rcx+0x38],rax
  40a395:	lea    rax,[rip+0x925c]        # 4135f8 <__swc_rdata_base_6b1cf01f+0x4e8>
  40a39c:	mov    QWORD PTR [rcx+0x40],rax
  40a3a0:	lea    rax,[rsp+0x18]
  40a3a5:	mov    QWORD PTR [rcx+0x48],rax
  40a3a9:	mov    QWORD PTR [rcx+0x50],0x3
  40a3b1:	lea    rcx,[rsp+0x48]
  40a3b6:	sub    rsp,0x8
  40a3ba:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  40a3bf:	add    rsp,0x8
  40a3c3:	add    rsp,0x60
  40a3c7:	lea    rax,[rip+0x8e82]        # 413250 <__swc_rdata_base_6b1cf01f+0x140>
  40a3ce:	sub    rsp,0x20
  40a3d2:	mov    rcx,rsp
  40a3d5:	mov    QWORD PTR [rcx],rax
  40a3d8:	mov    QWORD PTR [rcx+0x8],rsi
  40a3dc:	mov    QWORD PTR [rcx+0x10],rsp
  40a3e0:	mov    QWORD PTR [rcx+0x18],0x1
  40a3e8:	lea    rcx,[rsp+0x10]
  40a3ed:	sub    rsp,0x8
  40a3f1:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  40a3f6:	add    rsp,0x8
  40a3fa:	add    rsp,0x20
  40a3fe:	add    r15,0x1
  40a402:	cmp    r15,r14
  40a405:	jae    40a41e <__swc_fn_6b1cf01f_000165_bcc835b8+0x29e>
  40a407:	mov    rsi,QWORD PTR [rsp+0x30]
  40a40c:	mov    rdi,QWORD PTR [rsp+0x38]
  40a411:	mov    rax,r14
  40a414:	mov    r14,QWORD PTR [rsp+0x48]
  40a419:	jmp    40a1e0 <__swc_fn_6b1cf01f_000165_bcc835b8+0x60>
  40a41e:	add    rsp,0x50
  40a422:	vmovups xmm6,XMMWORD PTR [rsp]
  40a427:	add    rsp,0x10
  40a42b:	pop    r15
  40a42d:	pop    r14
  40a42f:	pop    r13
  40a431:	pop    r12
  40a433:	pop    rdi
  40a434:	pop    rsi
  40a435:	pop    rbx
  40a436:	pop    rbp
  40a437:	ret
	...

000000000040a440 <__swc_fn_6b1cf01f_000168_646fdf20>:
  40a440:	sub    rsp,0x8
  40a444:	call   40da50 <__swc_fn_6b1cf01f_000127_4bbe3f14>
  40a449:	add    rsp,0x8
  40a44d:	ret
	...

000000000040a450 <__swc_fn_6b1cf01f_000171_1e0ea8cf>:
  40a450:	push   rsi
  40a451:	sub    rsp,0x30
  40a455:	lea    rsi,[rip+0x1c944]        # 426da0 <__swc_bss_base_6b1cf01f+0x2d60>
  40a45c:	mov    rax,QWORD PTR [rsi]
  40a45f:	test   rax,rax
  40a462:	je     40a46a <__swc_fn_6b1cf01f_000171_1e0ea8cf+0x1a>
  40a464:	add    rsp,0x30
  40a468:	pop    rsi
  40a469:	ret
  40a46a:	mov    ecx,0x2
  40a46f:	mov    edx,0x8020
  40a474:	call   40d0f0 <__swc_fn_6b1cf01f_000109_6814119b>
  40a479:	test   rax,rax
  40a47c:	jne    40a48d <__swc_fn_6b1cf01f_000171_1e0ea8cf+0x3d>
  40a47e:	mov    QWORD PTR [rsp+0x18],rax
  40a483:	call   4098f0 <__swc_fn_6b1cf01f_000120_be2e2f68>
  40a488:	mov    rax,QWORD PTR [rsp+0x18]
  40a48d:	mov    rcx,rax
  40a490:	xchg   QWORD PTR [rsi],rcx
  40a493:	add    rsp,0x30
  40a497:	pop    rsi
  40a498:	ret
  40a499:	add    BYTE PTR [rax],al
  40a49b:	add    BYTE PTR [rax],al
  40a49d:	add    BYTE PTR [rax],al
	...

000000000040a4a0 <__swc_fn_6b1cf01f_000174_4de704de>:
  40a4a0:	push   rsi
  40a4a1:	test   r8,r8
  40a4a4:	jne    40a4a8 <__swc_fn_6b1cf01f_000174_4de704de+0x8>
  40a4a6:	pop    rsi
  40a4a7:	ret
  40a4a8:	lea    rax,[rcx+0x18]
  40a4ac:	mov    r10,QWORD PTR [rax]
  40a4af:	lea    r11,[r10+0x1]
  40a4b3:	mov    QWORD PTR [rax],r11
  40a4b6:	mov    r11,rdx
  40a4b9:	not    rdx
  40a4bc:	lea    rsi,[r8-0x1]
  40a4c0:	cmp    rsi,rdx
  40a4c3:	ja     40a4e3 <__swc_fn_6b1cf01f_000174_4de704de+0x43>
  40a4c5:	lea    rdx,[r11+r8*1]
  40a4c9:	dec    rdx
  40a4cc:	shr    rdx,0x6
  40a4d0:	mov    r8,r11
  40a4d3:	shr    r8,0x6
  40a4d7:	mov    rsi,rdx
  40a4da:	sub    rsi,r8
  40a4dd:	cmp    rsi,0x8
  40a4e1:	jb     40a4f9 <__swc_fn_6b1cf01f_000174_4de704de+0x59>
  40a4e3:	lea    rcx,[rcx+0x10]
  40a4e7:	mov    rdx,QWORD PTR [rcx]
  40a4ea:	add    rdx,r9
  40a4ed:	mov    QWORD PTR [rcx],rdx
  40a4f0:	lea    rcx,[r10+0x2]
  40a4f4:	mov    QWORD PTR [rax],rcx
  40a4f7:	pop    rsi
  40a4f8:	ret
  40a4f9:	shr    r11,0x6
  40a4fd:	nop    DWORD PTR [rax]
  40a500:	cmp    r11,rdx
  40a503:	ja     40a543 <__swc_fn_6b1cf01f_000174_4de704de+0xa3>
  40a505:	jmp    40a516 <__swc_fn_6b1cf01f_000174_4de704de+0x76>
  40a507:	nop    WORD PTR [rax+rax*1+0x0]
  40a510:	add    r11,0x1
  40a514:	jmp    40a500 <__swc_fn_6b1cf01f_000174_4de704de+0x60>
  40a516:	mov    r8,r11
  40a519:	shr    r8,0xc
  40a51d:	mov    rsi,r11
  40a520:	xor    rsi,r8
  40a523:	mov    r8,r11
  40a526:	shr    r8,0x18
  40a52a:	xor    rsi,r8
  40a52d:	and    esi,0xfff
  40a533:	lea    r8,[rcx+rsi*8+0x20]
  40a538:	mov    rsi,QWORD PTR [r8]
  40a53b:	add    rsi,r9
  40a53e:	mov    QWORD PTR [r8],rsi
  40a541:	jmp    40a510 <__swc_fn_6b1cf01f_000174_4de704de+0x70>
  40a543:	lea    rcx,[r10+0x2]
  40a547:	mov    QWORD PTR [rax],rcx
  40a54a:	pop    rsi
  40a54b:	ret
	...

000000000040a560 <__swc_fn_6b1cf01f_000001_0ce64436>:
  40a560:	push   rbp
  40a561:	push   rbx
  40a562:	push   rsi
  40a563:	sub    rsp,0xa8
  40a56a:	mov    rbp,rsp
  40a56d:	vmovups XMMWORD PTR [rsp],xmm6
  40a572:	vmovups XMMWORD PTR [rsp+0x10],xmm7
  40a578:	vmovups XMMWORD PTR [rsp+0x20],xmm8
  40a57e:	vmovups XMMWORD PTR [rsp+0x30],xmm9
  40a584:	vmovups XMMWORD PTR [rsp+0x40],xmm10
  40a58a:	vmovups XMMWORD PTR [rsp+0x50],xmm11
  40a590:	vmovups XMMWORD PTR [rsp+0x60],xmm12
  40a596:	vmovups XMMWORD PTR [rsp+0x70],xmm13
  40a59c:	vmovups XMMWORD PTR [rsp+0x80],xmm14
  40a5a5:	vmovups XMMWORD PTR [rsp+0x90],xmm15
  40a5ae:	sub    rsp,0x510
  40a5b5:	mov    rbx,rsp
  40a5b8:	lea    rax,[rip+0x8b61]        # 413120 <__swc_rdata_base_6b1cf01f+0x10>
  40a5bf:	xor    ecx,ecx
  40a5c1:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5cb:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5d5:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5df:	nop
  40a5e0:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  40a5e5:	vmovdqu XMMWORD PTR [rbx+rcx*1],xmm0
  40a5ea:	add    rcx,0x10
  40a5ee:	cmp    rcx,0x110
  40a5f5:	jne    40a5e0 <__swc_fn_6b1cf01f_000001_0ce64436+0x80>
  40a5f7:	mov    DWORD PTR [rbx+0x110],0x531799ac
  40a601:	mov    DWORD PTR [rbx+0x114],0x3f60a8f3
  40a60b:	sub    rsp,0x8
  40a60f:	call   407270 <__swc_fn_6b1cf01f_000000_1ca87929>
  40a614:	add    rsp,0x8
  40a618:	vmovsd QWORD PTR [rsp+0x2d0],xmm0
  40a621:	vxorpd xmm0,xmm0,xmm0
  40a625:	vmovups xmm2,xmm0
  40a629:	mov    rax,rbx
  40a62c:	vmovsd xmm3,QWORD PTR [rbx+0x18]
  40a631:	vmovsd xmm4,QWORD PTR [rbx+0x30]
  40a636:	vmulsd xmm3,xmm3,xmm4
  40a63a:	vaddsd xmm1,xmm0,xmm3
  40a63e:	vmovsd xmm3,QWORD PTR [rbx+0x20]
  40a643:	vfmadd231sd xmm2,xmm3,xmm4
  40a648:	vmovsd xmm3,QWORD PTR [rbx+0x28]
  40a64d:	vfmadd231sd xmm0,xmm3,xmm4
  40a652:	add    rax,0x38
  40a656:	vmovsd xmm3,QWORD PTR [rax+0x18]
  40a65b:	vmovsd xmm4,QWORD PTR [rax+0x30]
  40a660:	vfmadd231sd xmm1,xmm3,xmm4
  40a665:	vmovsd xmm3,QWORD PTR [rax+0x20]
  40a66a:	vfmadd231sd xmm2,xmm3,xmm4
  40a66f:	vmovsd xmm3,QWORD PTR [rax+0x28]
  40a674:	vfmadd231sd xmm0,xmm3,xmm4
  40a679:	vmovsd xmm3,QWORD PTR [rax+0x50]
  40a67e:	vmovsd xmm4,QWORD PTR [rax+0x68]
  40a683:	vfmadd231sd xmm1,xmm3,xmm4
  40a688:	vmovsd xmm3,QWORD PTR [rax+0x58]
  40a68d:	vfmadd231sd xmm2,xmm3,xmm4
  40a692:	vmovsd xmm3,QWORD PTR [rax+0x60]
  40a697:	vfmadd231sd xmm0,xmm3,xmm4
  40a69c:	vmovsd xmm3,QWORD PTR [rax+0x88]
  40a6a4:	vmovsd xmm4,QWORD PTR [rax+0xa0]
  40a6ac:	vfmadd231sd xmm1,xmm3,xmm4
  40a6b1:	vmovsd xmm3,QWORD PTR [rax+0x90]
  40a6b9:	vfmadd231sd xmm2,xmm3,xmm4
  40a6be:	vmovsd xmm3,QWORD PTR [rax+0x98]
  40a6c6:	vfmadd231sd xmm0,xmm3,xmm4
  40a6cb:	vmovsd xmm3,QWORD PTR [rax+0xc0]
  40a6d3:	vmovsd xmm4,QWORD PTR [rax+0xd8]
  40a6db:	vfmadd231sd xmm1,xmm3,xmm4
  40a6e0:	vmovsd xmm3,QWORD PTR [rax+0xc8]
  40a6e8:	vfmadd231sd xmm2,xmm3,xmm4
  40a6ed:	vmovsd xmm3,QWORD PTR [rax+0xd0]
  40a6f5:	vfmadd231sd xmm0,xmm3,xmm4
  40a6fa:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x8b3e]        # 413240 <__swc_rdata_base_6b1cf01f+0x130>
  40a702:	vmovsd xmm3,QWORD PTR [rip+0x8c4e]        # 413358 <__swc_rdata_base_6b1cf01f+0x248>
  40a70a:	vdivsd xmm1,xmm1,xmm3
  40a70e:	vmovsd QWORD PTR [rbx+0x18],xmm1
  40a713:	vxorpd xmm2,xmm2,XMMWORD PTR [rip+0x8b25]        # 413240 <__swc_rdata_base_6b1cf01f+0x130>
  40a71b:	vdivsd xmm1,xmm2,xmm3
  40a71f:	vmovsd QWORD PTR [rbx+0x20],xmm1
  40a724:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x8b14]        # 413240 <__swc_rdata_base_6b1cf01f+0x130>
  40a72c:	vdivsd xmm0,xmm0,xmm3
  40a730:	vmovsd QWORD PTR [rbx+0x28],xmm0
  40a735:	xor    eax,eax
  40a737:	vmovsd xmm0,QWORD PTR [rip+0x8c22]        # 413361 <__swc_rdata_base_6b1cf01f+0x251>
  40a73f:	vpshufd xmm1,xmm0,0x44
  40a744:	vmovups XMMWORD PTR [rsp+0x2e0],xmm1
  40a74d:	vpunpcklqdq xmm2,xmm0,xmm0
  40a751:	vmovups XMMWORD PTR [rsp+0x2f0],xmm2
  40a75a:	vmovdqu xmm3,XMMWORD PTR [rsp]
  40a75f:	vmovdqu xmm4,XMMWORD PTR [rsp+0x18]
  40a765:	vmovdqu xmm5,XMMWORD PTR [rsp+0x38]
  40a76b:	vmovups XMMWORD PTR [rsp+0x320],xmm5
  40a774:	vmovdqu xmm7,XMMWORD PTR [rsp+0x50]
  40a77a:	vmovdqu xmm8,XMMWORD PTR [rsp+0x70]
  40a780:	vmovups XMMWORD PTR [rsp+0x340],xmm8
  40a789:	vmovdqu xmm9,XMMWORD PTR [rsp+0x88]
  40a792:	vmovdqu xmm10,XMMWORD PTR [rsp+0xa8]
  40a79b:	vmovups XMMWORD PTR [rsp+0x350],xmm10
  40a7a4:	vmovdqu xmm11,XMMWORD PTR [rsp+0xc0]
  40a7ad:	vmovdqu xmm12,XMMWORD PTR [rsp+0xe0]
  40a7b6:	vmovups XMMWORD PTR [rsp+0x360],xmm11
  40a7bf:	vmovups XMMWORD PTR [rsp+0x370],xmm12
  40a7c8:	vmovdqu xmm13,XMMWORD PTR [rsp+0xf8]
  40a7d1:	mov    rcx,QWORD PTR [rsp+0x68]
  40a7d6:	mov    rdx,QWORD PTR [rsp+0x30]
  40a7db:	mov    r8,QWORD PTR [rsp+0xa0]
  40a7e3:	mov    r9,QWORD PTR [rsp+0xd8]
  40a7eb:	mov    r10,QWORD PTR [rsp+0x110]
  40a7f3:	jmp    40a854 <__swc_fn_6b1cf01f_000001_0ce64436+0x2f4>
  40a7f5:	cs nop WORD PTR [rax+rax*1+0x0]
  40a7ff:	cs nop WORD PTR [rax+rax*1+0x0]
  40a809:	nop    DWORD PTR [rax+0x0]
  40a810:	vmovups xmm2,XMMWORD PTR [rsp+0x2f0]
  40a819:	vmovups xmm4,XMMWORD PTR [rsp+0x310]
  40a822:	vmovups xmm5,XMMWORD PTR [rsp+0x320]
  40a82b:	vmovups xmm10,xmm13
  40a830:	vmovups XMMWORD PTR [rsp+0x360],xmm7
  40a839:	vmovups xmm12,xmm11
  40a83e:	vmovups xmm13,xmm3
  40a842:	vmovups xmm3,XMMWORD PTR [rsp+0x300]
  40a84b:	vmovups xmm7,XMMWORD PTR [rsp+0x330]
  40a854:	vsubpd xmm14,xmm3,xmm5
  40a858:	vpsrldq xmm6,xmm14,0x8
  40a85e:	vmovsd xmm15,QWORD PTR [rbx+0x10]
  40a863:	vmovsd QWORD PTR [rsp+0x390],xmm15
  40a86c:	vmovsd xmm0,QWORD PTR [rbx+0x48]
  40a871:	vmovq  rsi,xmm0
  40a876:	vsubsd xmm5,xmm15,xmm0
  40a87a:	vmulsd xmm0,xmm14,xmm14
  40a87f:	vfmadd231sd xmm0,xmm6,xmm6
  40a884:	vfmadd231sd xmm0,xmm5,xmm5
  40a889:	vsubpd xmm6,xmm3,xmm8
  40a88e:	vmulsd xmm8,xmm6,xmm6
  40a892:	vmovups XMMWORD PTR [rsp+0x380],xmm13
  40a89b:	vpsrldq xmm13,xmm6,0x8
  40a8a0:	vfmadd231sd xmm8,xmm13,xmm13
  40a8a5:	vmovsd xmm13,QWORD PTR [rbx+0x80]
  40a8ad:	vmovsd QWORD PTR [rsp+0x3a0],xmm13
  40a8b6:	vsubsd xmm1,xmm15,xmm13
  40a8bb:	vfmadd231sd xmm8,xmm1,xmm1
  40a8c0:	vpunpcklqdq xmm0,xmm0,xmm8
  40a8c5:	vsqrtpd xmm8,xmm0
  40a8c9:	vmulpd xmm0,xmm0,xmm8
  40a8ce:	vdivpd xmm0,xmm2,xmm0
  40a8d2:	vpshufd xmm8,xmm0,0x44
  40a8d7:	vmovq  xmm13,rcx
  40a8dc:	vpshufd xmm13,xmm13,0x44
  40a8e2:	vmulpd xmm11,xmm14,xmm13
  40a8e7:	vmovups XMMWORD PTR [rsp+0x3b0],xmm13
  40a8f0:	vmovq  xmm13,rcx
  40a8f5:	vfnmadd231pd xmm4,xmm11,xmm8
  40a8fa:	vmulsd xmm11,xmm5,xmm13
  40a8ff:	vfnmadd213sd xmm11,xmm0,QWORD PTR [rbx+0x28]
  40a905:	vmovq  xmm13,rdx
  40a90a:	vpshufd xmm13,xmm13,0x44
  40a910:	vmulpd xmm14,xmm14,xmm13
  40a915:	vmulpd xmm8,xmm14,xmm8
  40a91a:	vmovq  xmm14,rdx
  40a91f:	vaddpd xmm7,xmm7,xmm8
  40a924:	vmovups XMMWORD PTR [rsp+0x3d0],xmm7
  40a92d:	vmulsd xmm5,xmm5,xmm14
  40a932:	vfmadd213sd xmm5,xmm0,QWORD PTR [rbx+0x60]
  40a938:	vmovsd QWORD PTR [rsp+0x3e0],xmm5
  40a941:	vmulpd xmm8,xmm6,xmm13
  40a946:	vpsrldq xmm0,xmm0,0x8
  40a94b:	vpshufd xmm5,xmm0,0x44
  40a950:	vmulpd xmm8,xmm8,xmm5
  40a954:	vmovq  xmm2,r8
  40a959:	vpshufd xmm2,xmm2,0x44
  40a95e:	vmulpd xmm6,xmm6,xmm2
  40a962:	vfnmadd231pd xmm4,xmm6,xmm5
  40a967:	vmovq  xmm5,r8
  40a96c:	vmulsd xmm6,xmm1,xmm5
  40a970:	vfnmadd213sd xmm6,xmm0,xmm11
  40a975:	vaddpd xmm8,xmm9,xmm8
  40a97a:	vmovups XMMWORD PTR [rsp+0x410],xmm8
  40a983:	vmulsd xmm1,xmm1,xmm14
  40a988:	vmulsd xmm0,xmm1,xmm0
  40a98c:	vaddsd xmm0,xmm0,QWORD PTR [rbx+0x98]
  40a994:	vmovsd QWORD PTR [rsp+0x420],xmm0
  40a99d:	vsubpd xmm1,xmm3,xmm10
  40a9a2:	vmulpd xmm9,xmm1,xmm13
  40a9a7:	vpsrldq xmm0,xmm1,0x8
  40a9ac:	vmovsd xmm11,QWORD PTR [rbx+0xb8]
  40a9b4:	vmovsd QWORD PTR [rsp+0x428],xmm11
  40a9bd:	vsubsd xmm5,xmm15,xmm11
  40a9c2:	vmulsd xmm8,xmm1,xmm1
  40a9c6:	vfmadd213sd xmm0,xmm0,xmm8
  40a9cb:	vfmadd231sd xmm0,xmm5,xmm5
  40a9d0:	vsubpd xmm8,xmm3,xmm12
  40a9d5:	vmulsd xmm12,xmm8,xmm8
  40a9da:	vpsrldq xmm7,xmm8,0x8
  40a9e0:	vmulsd xmm7,xmm7,xmm7
  40a9e4:	vaddsd xmm7,xmm12,xmm7
  40a9e8:	vmovsd xmm12,QWORD PTR [rbx+0xf0]
  40a9f0:	vmovq  r11,xmm12
  40a9f5:	vsubsd xmm11,xmm15,xmm12
  40a9fa:	vfmadd231sd xmm7,xmm11,xmm11
  40a9ff:	vpunpcklqdq xmm0,xmm0,xmm7
  40aa03:	vsqrtpd xmm7,xmm0
  40aa07:	vmulpd xmm0,xmm0,xmm7
  40aa0b:	vmovups xmm15,XMMWORD PTR [rsp+0x2f0]
  40aa14:	vdivpd xmm0,xmm15,xmm0
  40aa18:	vpshufd xmm7,xmm0,0x44
  40aa1d:	vmulpd xmm9,xmm9,xmm7
  40aa21:	vmovq  xmm12,r9
  40aa26:	vpshufd xmm12,xmm12,0x44
  40aa2c:	vmulpd xmm1,xmm1,xmm12
  40aa31:	vfnmadd213pd xmm1,xmm7,xmm4
  40aa36:	vmovq  xmm7,r9
  40aa3b:	vmovsd QWORD PTR [rsp+0x450],xmm7
  40aa44:	vmulsd xmm4,xmm5,xmm7
  40aa48:	vfnmadd231sd xmm6,xmm4,xmm0
  40aa4d:	vaddpd xmm9,xmm9,XMMWORD PTR [rsp+0x360]
  40aa56:	vmulsd xmm4,xmm5,xmm14
  40aa5b:	vmovsd xmm5,QWORD PTR [rbx+0xd0]
  40aa63:	vfmadd231sd xmm5,xmm4,xmm0
  40aa68:	vmovsd QWORD PTR [rsp+0x458],xmm5
  40aa71:	vmulpd xmm4,xmm8,xmm13
  40aa76:	vpsrldq xmm0,xmm0,0x8
  40aa7b:	vpshufd xmm13,xmm0,0x44
  40aa80:	vmulpd xmm4,xmm4,xmm13
  40aa85:	vmovq  xmm5,r10
  40aa8a:	vpshufd xmm5,xmm5,0x44
  40aa8f:	vmovups XMMWORD PTR [rsp+0x460],xmm5
  40aa98:	vmulpd xmm8,xmm8,xmm5
  40aa9c:	vmulpd xmm8,xmm8,xmm13
  40aaa1:	vmovups xmm13,xmm4
  40aaa5:	vsubpd xmm4,xmm1,xmm8
  40aaaa:	vfmadd231pd xmm3,xmm4,XMMWORD PTR [rsp+0x2e0]
  40aab4:	vmovq  xmm8,r10
  40aab9:	vmovups XMMWORD PTR [rsp+0x300],xmm3
  40aac2:	vmovsd QWORD PTR [rsp+0x470],xmm8
  40aacb:	vaddpd xmm3,xmm13,XMMWORD PTR [rsp+0x380]
  40aad4:	vmovups XMMWORD PTR [rsp+0x480],xmm3
  40aadd:	vmulsd xmm13,xmm11,xmm8
  40aae2:	vfnmadd231sd xmm6,xmm13,xmm0
  40aae7:	vmovsd QWORD PTR [rbx+0x28],xmm6
  40aaec:	vmulsd xmm11,xmm11,xmm14
  40aaf1:	vmulsd xmm0,xmm11,xmm0
  40aaf5:	vaddsd xmm0,xmm0,QWORD PTR [rbx+0x108]
  40aafd:	vmovups xmm13,XMMWORD PTR [rsp+0x320]
  40ab06:	vmovsd QWORD PTR [rsp+0x498],xmm0
  40ab0f:	vsubpd xmm14,xmm13,XMMWORD PTR [rsp+0x340]
  40ab18:	vmovups XMMWORD PTR [rsp+0x310],xmm4
  40ab21:	vmulpd xmm4,xmm14,xmm2
  40ab25:	vmovups xmm6,XMMWORD PTR [rsp+0x3b0]
  40ab2e:	vmovups XMMWORD PTR [rsp+0x3f0],xmm2
  40ab37:	vmulpd xmm2,xmm14,xmm6
  40ab3b:	vpsrldq xmm8,xmm14,0x8
  40ab41:	vmovq  xmm0,rsi
  40ab46:	vsubsd xmm1,xmm0,QWORD PTR [rsp+0x3a0]
  40ab4f:	vmulsd xmm3,xmm14,xmm14
  40ab54:	vfmadd231sd xmm3,xmm8,xmm8
  40ab59:	vfmadd231sd xmm3,xmm1,xmm1
  40ab5e:	vsubpd xmm8,xmm13,xmm10
  40ab63:	vmulsd xmm14,xmm8,xmm8
  40ab68:	vpsrldq xmm10,xmm8,0x8
  40ab6e:	vmulsd xmm10,xmm10,xmm10
  40ab73:	vaddsd xmm10,xmm14,xmm10
  40ab78:	vsubsd xmm11,xmm0,QWORD PTR [rsp+0x428]
  40ab81:	vfmadd231sd xmm10,xmm11,xmm11
  40ab86:	vpunpcklqdq xmm3,xmm3,xmm10
  40ab8b:	vsqrtpd xmm10,xmm3
  40ab8f:	vmulpd xmm3,xmm3,xmm10
  40ab94:	vdivpd xmm3,xmm15,xmm3
  40ab98:	vpshufd xmm10,xmm3,0x44
  40ab9d:	vfnmadd213pd xmm4,xmm10,XMMWORD PTR [rsp+0x3d0]
  40aba7:	vmulpd xmm2,xmm2,xmm10
  40abac:	vaddpd xmm2,xmm2,XMMWORD PTR [rsp+0x410]
  40abb5:	vmovq  xmm10,r8
  40abba:	vmovups XMMWORD PTR [rsp+0x4a0],xmm2
  40abc3:	vmulsd xmm14,xmm1,xmm10
  40abc8:	vmovsd xmm10,QWORD PTR [rsp+0x3e0]
  40abd1:	vfnmadd231sd xmm10,xmm14,xmm3
  40abd6:	vmovq  xmm14,rcx
  40abdb:	vmulsd xmm1,xmm1,xmm14
  40abe0:	vfmadd213sd xmm1,xmm3,QWORD PTR [rsp+0x420]
  40abea:	vmovsd QWORD PTR [rsp+0x4b0],xmm1
  40abf3:	vmulpd xmm2,xmm8,xmm12
  40abf8:	vmulpd xmm8,xmm8,xmm6
  40abfc:	vpsrldq xmm3,xmm3,0x8
  40ac01:	vpshufd xmm1,xmm3,0x44
  40ac06:	vfnmadd213pd xmm2,xmm1,xmm4
  40ac0b:	vfmadd213pd xmm1,xmm8,xmm9
  40ac10:	vmulsd xmm4,xmm11,xmm7
  40ac14:	vfnmadd213sd xmm4,xmm3,xmm10
  40ac19:	vmulsd xmm8,xmm11,xmm14
  40ac1e:	vmulsd xmm3,xmm8,xmm3
  40ac22:	vaddsd xmm3,xmm3,QWORD PTR [rsp+0x458]
  40ac2b:	vmovsd QWORD PTR [rsp+0x4b8],xmm3
  40ac34:	vsubpd xmm9,xmm13,XMMWORD PTR [rsp+0x370]
  40ac3d:	vmulpd xmm10,xmm9,xmm5
  40ac41:	vmulpd xmm6,xmm9,xmm6
  40ac45:	vpsrldq xmm7,xmm9,0x8
  40ac4b:	vmovq  xmm11,r11
  40ac50:	vsubsd xmm5,xmm0,xmm11
  40ac55:	vmulsd xmm0,xmm9,xmm9
  40ac5a:	vfmadd231sd xmm0,xmm7,xmm7
  40ac5f:	vfmadd231sd xmm0,xmm5,xmm5
  40ac64:	vmovups xmm9,XMMWORD PTR [rsp+0x340]
  40ac6d:	vsubpd xmm11,xmm9,XMMWORD PTR [rsp+0x350]
  40ac76:	vmulsd xmm7,xmm11,xmm11
  40ac7b:	vpsrldq xmm8,xmm11,0x8
  40ac81:	vfmadd231sd xmm7,xmm8,xmm8
  40ac86:	vmovsd xmm8,QWORD PTR [rsp+0x3a0]
  40ac8f:	vsubsd xmm3,xmm8,QWORD PTR [rsp+0x428]
  40ac98:	vfmadd231sd xmm7,xmm3,xmm3
  40ac9d:	vpunpcklqdq xmm0,xmm0,xmm7
  40aca1:	vsqrtpd xmm7,xmm0
  40aca5:	vmulpd xmm0,xmm0,xmm7
  40aca9:	vdivpd xmm0,xmm15,xmm0
  40acad:	vpshufd xmm9,xmm0,0x44
  40acb2:	vmulpd xmm7,xmm10,xmm9
  40acb7:	vmovsd xmm15,QWORD PTR [rsp+0x450]
  40acc0:	vsubpd xmm7,xmm2,xmm7
  40acc4:	vmovups xmm2,XMMWORD PTR [rsp+0x2e0]
  40accd:	vfmadd231pd xmm13,xmm7,xmm2
  40acd2:	vmovups XMMWORD PTR [rsp+0x320],xmm13
  40acdb:	vmulpd xmm6,xmm6,xmm9
  40ace0:	vaddpd xmm6,xmm6,XMMWORD PTR [rsp+0x480]
  40ace9:	vmovsd xmm10,QWORD PTR [rsp+0x470]
  40acf2:	vmulsd xmm9,xmm5,xmm10
  40acf7:	vfnmadd231sd xmm4,xmm9,xmm0
  40acfc:	vmovsd QWORD PTR [rbx+0x60],xmm4
  40ad01:	vmulsd xmm5,xmm5,xmm14
  40ad06:	vfmadd213sd xmm5,xmm0,QWORD PTR [rsp+0x498]
  40ad10:	vmulpd xmm9,xmm11,xmm12
  40ad15:	vmovups xmm14,XMMWORD PTR [rsp+0x3f0]
  40ad1e:	vmulpd xmm11,xmm11,xmm14
  40ad23:	vpsrldq xmm0,xmm0,0x8
  40ad28:	vpshufd xmm13,xmm0,0x44
  40ad2d:	vmovups XMMWORD PTR [rsp+0x330],xmm7
  40ad36:	vmovups xmm7,XMMWORD PTR [rsp+0x4a0]
  40ad3f:	vfnmadd231pd xmm7,xmm9,xmm13
  40ad44:	vfmadd231pd xmm1,xmm11,xmm13
  40ad49:	vmovups XMMWORD PTR [rsp+0x4d0],xmm1
  40ad52:	vmulsd xmm9,xmm3,xmm15
  40ad57:	vmovsd xmm11,QWORD PTR [rsp+0x4b0]
  40ad60:	vfnmadd231sd xmm11,xmm9,xmm0
  40ad65:	vmovq  xmm13,r8
  40ad6a:	vmulsd xmm3,xmm3,xmm13
  40ad6f:	vmulsd xmm0,xmm3,xmm0
  40ad73:	vaddsd xmm0,xmm0,QWORD PTR [rsp+0x4b8]
  40ad7c:	vmovups xmm9,XMMWORD PTR [rsp+0x340]
  40ad85:	vmovups xmm3,XMMWORD PTR [rsp+0x370]
  40ad8e:	vmovsd QWORD PTR [rsp+0x4e0],xmm0
  40ad97:	vsubpd xmm4,xmm9,xmm3
  40ad9b:	vmulpd xmm15,xmm4,XMMWORD PTR [rsp+0x460]
  40ada4:	vmulpd xmm14,xmm4,xmm14
  40ada9:	vpsrldq xmm0,xmm4,0x8
  40adae:	vmovq  xmm9,r11
  40adb3:	vsubsd xmm1,xmm8,xmm9
  40adb8:	vmulsd xmm4,xmm4,xmm4
  40adbc:	vfmadd213sd xmm0,xmm0,xmm4
  40adc1:	vfmadd231sd xmm0,xmm1,xmm1
  40adc6:	vmovups xmm4,XMMWORD PTR [rsp+0x350]
  40adcf:	vsubpd xmm8,xmm4,xmm3
  40add3:	vmovups XMMWORD PTR [rsp+0x4f0],xmm8
  40addc:	vmulsd xmm3,xmm8,xmm8
  40ade1:	vpsrldq xmm4,xmm8,0x8
  40ade7:	vfmadd231sd xmm3,xmm4,xmm4
  40adec:	vmovsd xmm4,QWORD PTR [rsp+0x428]
  40adf5:	vmovups XMMWORD PTR [rsp+0x440],xmm12
  40adfe:	vsubsd xmm12,xmm4,xmm9
  40ae03:	vmovsd QWORD PTR [rsp+0x500],xmm12
  40ae0c:	vfmadd231sd xmm3,xmm12,xmm12
  40ae11:	vpunpcklqdq xmm0,xmm0,xmm3
  40ae15:	vsqrtpd xmm3,xmm0
  40ae19:	vmulpd xmm0,xmm0,xmm3
  40ae1d:	vmovups xmm4,XMMWORD PTR [rsp+0x2f0]
  40ae26:	vdivpd xmm0,xmm4,xmm0
  40ae2a:	vpshufd xmm3,xmm0,0x44
  40ae2f:	vmulpd xmm15,xmm15,xmm3
  40ae33:	vmovups xmm8,XMMWORD PTR [rsp+0x340]
  40ae3c:	vmovups xmm4,xmm9
  40ae41:	vmovups xmm12,XMMWORD PTR [rsp+0x460]
  40ae4a:	vsubpd xmm9,xmm7,xmm15
  40ae4f:	vfmadd231pd xmm8,xmm9,xmm2
  40ae54:	vmovups XMMWORD PTR [rsp+0x340],xmm8
  40ae5d:	vfmadd213pd xmm3,xmm14,xmm6
  40ae62:	vmulsd xmm6,xmm1,xmm10
  40ae67:	vfnmadd213sd xmm6,xmm0,xmm11
  40ae6c:	vmovsd QWORD PTR [rbx+0x98],xmm6
  40ae74:	vmulsd xmm1,xmm1,xmm13
  40ae79:	vfmadd213sd xmm1,xmm0,xmm5
  40ae7e:	vmovups xmm5,XMMWORD PTR [rsp+0x4f0]
  40ae87:	vmulpd xmm7,xmm5,xmm12
  40ae8c:	vmulpd xmm5,xmm5,XMMWORD PTR [rsp+0x440]
  40ae95:	vpsrldq xmm0,xmm0,0x8
  40ae9a:	vpshufd xmm11,xmm0,0x44
  40ae9f:	vfnmadd213pd xmm7,xmm11,XMMWORD PTR [rsp+0x4d0]
  40aea9:	vmovups xmm13,XMMWORD PTR [rsp+0x350]
  40aeb2:	vfmadd231pd xmm13,xmm7,xmm2
  40aeb7:	vmovups XMMWORD PTR [rsp+0x350],xmm13
  40aec0:	vmulpd xmm5,xmm5,xmm11
  40aec5:	vmovups xmm11,XMMWORD PTR [rsp+0x370]
  40aece:	vmovsd xmm12,QWORD PTR [rsp+0x3a0]
  40aed7:	vaddpd xmm3,xmm3,xmm5
  40aedb:	vfmadd231pd xmm11,xmm3,xmm2
  40aee0:	vmovsd xmm5,QWORD PTR [rsp+0x500]
  40aee9:	vmovups XMMWORD PTR [rsp+0x370],xmm11
  40aef2:	vmulsd xmm10,xmm5,xmm10
  40aef7:	vfnmadd213sd xmm10,xmm0,QWORD PTR [rsp+0x4e0]
  40af01:	vmovsd QWORD PTR [rbx+0xd0],xmm10
  40af09:	vmulsd xmm5,xmm5,QWORD PTR [rsp+0x450]
  40af12:	vfmadd213sd xmm0,xmm5,xmm1
  40af17:	vmovsd QWORD PTR [rbx+0x108],xmm0
  40af1f:	vmovsd xmm5,QWORD PTR [rip+0x843a]        # 413361 <__swc_rdata_base_6b1cf01f+0x251>
  40af27:	vmovsd xmm1,QWORD PTR [rbx+0x28]
  40af2c:	vfmadd213sd xmm1,xmm5,QWORD PTR [rsp+0x390]
  40af36:	vmovsd QWORD PTR [rbx+0x10],xmm1
  40af3b:	vmovsd xmm1,QWORD PTR [rbx+0x60]
  40af40:	vmovq  xmm14,rsi
  40af45:	vfmadd213sd xmm1,xmm5,xmm14
  40af4a:	vmovsd QWORD PTR [rbx+0x48],xmm1
  40af4f:	vmulsd xmm1,xmm6,xmm5
  40af53:	vaddsd xmm1,xmm12,xmm1
  40af57:	vmovsd QWORD PTR [rbx+0x80],xmm1
  40af5f:	vmulsd xmm1,xmm10,xmm5
  40af63:	vaddsd xmm1,xmm1,QWORD PTR [rsp+0x428]
  40af6c:	vmovsd QWORD PTR [rbx+0xb8],xmm1
  40af74:	vfmadd213sd xmm0,xmm5,xmm4
  40af79:	vmovsd QWORD PTR [rbx+0xf0],xmm0
  40af81:	add    rax,0x1
  40af85:	cmp    rax,0x7a120
  40af8c:	jl     40a810 <__swc_fn_6b1cf01f_000001_0ce64436+0x2b0>
  40af92:	vmovdqu XMMWORD PTR [rsp+0xa8],xmm13
  40af9b:	vmovdqu XMMWORD PTR [rsp+0xc0],xmm7
  40afa4:	vmovdqu XMMWORD PTR [rsp+0xe0],xmm11
  40afad:	vmovdqu XMMWORD PTR [rsp+0xf8],xmm3
  40afb6:	vmovups xmm3,XMMWORD PTR [rsp+0x300]
  40afbf:	vmovdqu XMMWORD PTR [rsp],xmm3
  40afc4:	vmovups xmm4,XMMWORD PTR [rsp+0x310]
  40afcd:	vmovdqu XMMWORD PTR [rsp+0x18],xmm4
  40afd3:	vmovups xmm13,XMMWORD PTR [rsp+0x320]
  40afdc:	vmovdqu XMMWORD PTR [rsp+0x38],xmm13
  40afe2:	vmovups xmm7,XMMWORD PTR [rsp+0x330]
  40afeb:	vmovdqu XMMWORD PTR [rsp+0x50],xmm7
  40aff1:	vmovdqu XMMWORD PTR [rsp+0x70],xmm8
  40aff7:	vmovdqu XMMWORD PTR [rsp+0x88],xmm9
  40b000:	mov    QWORD PTR [rbx+0x258],0x5
  40b00b:	vxorpd xmm0,xmm0,xmm0
  40b00f:	vmovsd xmm1,QWORD PTR [rip+0x8353]        # 41336a <__swc_rdata_base_6b1cf01f+0x25a>
  40b017:	vmovsd xmm3,QWORD PTR [rbx+0x30]
  40b01c:	vmulsd xmm2,xmm1,xmm3
  40b020:	vmovsd xmm4,QWORD PTR [rbx+0x18]
  40b025:	vmulsd xmm4,xmm4,xmm4
  40b029:	vmovsd xmm5,QWORD PTR [rbx+0x20]
  40b02e:	vfmadd231sd xmm4,xmm5,xmm5
  40b033:	vmovsd xmm5,QWORD PTR [rbx+0x28]
  40b038:	vfmadd231sd xmm4,xmm5,xmm5
  40b03d:	vfmadd231sd xmm0,xmm2,xmm4
  40b042:	vmovsd xmm2,QWORD PTR [rbx]
  40b046:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x38]
  40b04b:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  40b050:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x40]
  40b055:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  40b05a:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x48]
  40b05f:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x68]
  40b064:	vmulsd xmm2,xmm2,xmm2
  40b068:	vfmadd231sd xmm2,xmm4,xmm4
  40b06d:	vfmadd231sd xmm2,xmm5,xmm5
  40b072:	vsqrtsd xmm2,xmm2,xmm2
  40b076:	vdivsd xmm2,xmm9,xmm2
  40b07a:	vsubsd xmm0,xmm0,xmm2
  40b07e:	vmovsd xmm2,QWORD PTR [rbx]
  40b082:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x70]
  40b087:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  40b08c:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x78]
  40b091:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  40b096:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x80]
  40b09e:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xa0]
  40b0a6:	vmulsd xmm2,xmm2,xmm2
  40b0aa:	vfmadd231sd xmm2,xmm4,xmm4
  40b0af:	vfmadd231sd xmm2,xmm5,xmm5
  40b0b4:	vsqrtsd xmm2,xmm2,xmm2
  40b0b8:	vdivsd xmm2,xmm9,xmm2
  40b0bc:	vsubsd xmm0,xmm0,xmm2
  40b0c0:	vmovsd xmm2,QWORD PTR [rbx]
  40b0c4:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  40b0cc:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  40b0d1:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  40b0d9:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  40b0de:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  40b0e6:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  40b0ee:	vmulsd xmm2,xmm2,xmm2
  40b0f2:	vfmadd231sd xmm2,xmm4,xmm4
  40b0f7:	vfmadd231sd xmm2,xmm5,xmm5
  40b0fc:	vsqrtsd xmm2,xmm2,xmm2
  40b100:	vdivsd xmm2,xmm9,xmm2
  40b104:	vsubsd xmm0,xmm0,xmm2
  40b108:	vmovsd xmm2,QWORD PTR [rbx]
  40b10c:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xe0]
  40b114:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  40b119:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xe8]
  40b121:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  40b126:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xf0]
  40b12e:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x110]
  40b136:	vmulsd xmm2,xmm2,xmm2
  40b13a:	vfmadd231sd xmm2,xmm4,xmm4
  40b13f:	vfmadd231sd xmm2,xmm5,xmm5
  40b144:	vsqrtsd xmm2,xmm2,xmm2
  40b148:	vdivsd xmm2,xmm9,xmm2
  40b14c:	vsubsd xmm0,xmm0,xmm2
  40b150:	vmovsd xmm3,QWORD PTR [rbx+0x68]
  40b155:	vmulsd xmm2,xmm1,xmm3
  40b159:	vmovsd xmm4,QWORD PTR [rbx+0x50]
  40b15e:	vmulsd xmm4,xmm4,xmm4
  40b162:	vmovsd xmm5,QWORD PTR [rbx+0x58]
  40b167:	vfmadd231sd xmm4,xmm5,xmm5
  40b16c:	vmovsd xmm5,QWORD PTR [rbx+0x60]
  40b171:	vfmadd231sd xmm4,xmm5,xmm5
  40b176:	vfmadd231sd xmm0,xmm2,xmm4
  40b17b:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  40b180:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x70]
  40b185:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  40b18a:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x78]
  40b18f:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  40b194:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x80]
  40b19c:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xa0]
  40b1a4:	vmulsd xmm2,xmm2,xmm2
  40b1a8:	vfmadd231sd xmm2,xmm4,xmm4
  40b1ad:	vfmadd231sd xmm2,xmm5,xmm5
  40b1b2:	vsqrtsd xmm2,xmm2,xmm2
  40b1b6:	vdivsd xmm2,xmm9,xmm2
  40b1ba:	vsubsd xmm0,xmm0,xmm2
  40b1be:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  40b1c3:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  40b1cb:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  40b1d0:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  40b1d8:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  40b1dd:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  40b1e5:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  40b1ed:	vmulsd xmm2,xmm2,xmm2
  40b1f1:	vfmadd231sd xmm2,xmm4,xmm4
  40b1f6:	vfmadd231sd xmm2,xmm5,xmm5
  40b1fb:	vsqrtsd xmm2,xmm2,xmm2
  40b1ff:	vdivsd xmm2,xmm9,xmm2
  40b203:	vsubsd xmm0,xmm0,xmm2
  40b207:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  40b20c:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xe0]
  40b214:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  40b219:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xe8]
  40b221:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  40b226:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xf0]
  40b22e:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x110]
  40b236:	vmulsd xmm2,xmm2,xmm2
  40b23a:	vfmadd231sd xmm2,xmm4,xmm4
  40b23f:	vfmadd231sd xmm2,xmm5,xmm5
  40b244:	vsqrtsd xmm2,xmm2,xmm2
  40b248:	vdivsd xmm2,xmm9,xmm2
  40b24c:	vsubsd xmm0,xmm0,xmm2
  40b250:	vmovsd xmm3,QWORD PTR [rbx+0xa0]
  40b258:	vmulsd xmm2,xmm1,xmm3
  40b25c:	vmovsd xmm4,QWORD PTR [rbx+0x88]
  40b264:	vmulsd xmm4,xmm4,xmm4
  40b268:	vmovsd xmm5,QWORD PTR [rbx+0x90]
  40b270:	vfmadd231sd xmm4,xmm5,xmm5
  40b275:	vmovsd xmm5,QWORD PTR [rbx+0x98]
  40b27d:	vfmadd231sd xmm4,xmm5,xmm5
  40b282:	vfmadd231sd xmm0,xmm2,xmm4
  40b287:	vmovsd xmm2,QWORD PTR [rbx+0x70]
  40b28c:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  40b294:	vmovsd xmm4,QWORD PTR [rbx+0x78]
  40b299:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  40b2a1:	vmovsd xmm5,QWORD PTR [rbx+0x80]
  40b2a9:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  40b2b1:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  40b2b9:	vmulsd xmm2,xmm2,xmm2
  40b2bd:	vfmadd231sd xmm2,xmm4,xmm4
  40b2c2:	vfmadd231sd xmm2,xmm5,xmm5
  40b2c7:	vsqrtsd xmm2,xmm2,xmm2
  40b2cb:	vdivsd xmm2,xmm9,xmm2
  40b2cf:	vsubsd xmm0,xmm0,xmm2
  40b2d3:	vmovsd xmm2,QWORD PTR [rbx+0x70]
  40b2d8:	vmovsd xmm6,QWORD PTR [rbx+0xe0]
  40b2e0:	vsubsd xmm2,xmm2,xmm6
  40b2e4:	vmovsd xmm4,QWORD PTR [rbx+0x78]
  40b2e9:	vmovsd xmm7,QWORD PTR [rbx+0xe8]
  40b2f1:	vsubsd xmm4,xmm4,xmm7
  40b2f5:	vmovsd xmm5,QWORD PTR [rbx+0x80]
  40b2fd:	vmovsd xmm8,QWORD PTR [rbx+0xf0]
  40b305:	vsubsd xmm5,xmm5,xmm8
  40b30a:	vmovsd xmm10,QWORD PTR [rbx+0x110]
  40b312:	vmulsd xmm9,xmm3,xmm10
  40b317:	vmulsd xmm2,xmm2,xmm2
  40b31b:	vfmadd231sd xmm2,xmm4,xmm4
  40b320:	vfmadd231sd xmm2,xmm5,xmm5
  40b325:	vsqrtsd xmm2,xmm2,xmm2
  40b329:	vdivsd xmm2,xmm9,xmm2
  40b32d:	vsubsd xmm0,xmm0,xmm2
  40b331:	vmovsd xmm3,QWORD PTR [rbx+0xd8]
  40b339:	vmulsd xmm2,xmm1,xmm3
  40b33d:	vmovsd xmm4,QWORD PTR [rbx+0xc0]
  40b345:	vmulsd xmm4,xmm4,xmm4
  40b349:	vmovsd xmm5,QWORD PTR [rbx+0xc8]
  40b351:	vfmadd231sd xmm4,xmm5,xmm5
  40b356:	vmovsd xmm5,QWORD PTR [rbx+0xd0]
  40b35e:	vfmadd231sd xmm4,xmm5,xmm5
  40b363:	vfmadd231sd xmm0,xmm2,xmm4
  40b368:	vmovsd xmm2,QWORD PTR [rbx+0xa8]
  40b370:	vsubsd xmm2,xmm2,xmm6
  40b374:	vmovsd xmm4,QWORD PTR [rbx+0xb0]
  40b37c:	vsubsd xmm4,xmm4,xmm7
  40b380:	vmovsd xmm5,QWORD PTR [rbx+0xb8]
  40b388:	vsubsd xmm5,xmm5,xmm8
  40b38d:	vmulsd xmm9,xmm3,xmm10
  40b392:	vmulsd xmm2,xmm2,xmm2
  40b396:	vfmadd231sd xmm2,xmm4,xmm4
  40b39b:	vfmadd231sd xmm2,xmm5,xmm5
  40b3a0:	vsqrtsd xmm2,xmm2,xmm2
  40b3a4:	vdivsd xmm2,xmm9,xmm2
  40b3a8:	vsubsd xmm0,xmm0,xmm2
  40b3ac:	vmulsd xmm2,xmm10,xmm1
  40b3b0:	vmovsd xmm4,QWORD PTR [rbx+0xf8]
  40b3b8:	vmulsd xmm4,xmm4,xmm4
  40b3bc:	vmovsd xmm5,QWORD PTR [rbx+0x100]
  40b3c4:	vfmadd231sd xmm4,xmm5,xmm5
  40b3c9:	vmovsd xmm5,QWORD PTR [rbx+0x108]
  40b3d1:	vfmadd231sd xmm4,xmm5,xmm5
  40b3d6:	vfmadd231sd xmm0,xmm2,xmm4
  40b3db:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x7e5d]        # 413240 <__swc_rdata_base_6b1cf01f+0x130>
  40b3e3:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x7f88]        # 413373 <__swc_rdata_base_6b1cf01f+0x263>
  40b3eb:	vroundsd xmm0,xmm0,xmm0,0x1
  40b3f1:	vmovsd xmm1,QWORD PTR [rip+0x7f83]        # 41337c <__swc_rdata_base_6b1cf01f+0x26c>
  40b3f9:	vcomisd xmm0,xmm1
  40b3fd:	jb     40b417 <__swc_fn_6b1cf01f_000001_0ce64436+0xeb7>
  40b3ff:	vsubsd xmm0,xmm0,xmm1
  40b403:	vcvttsd2si rsi,xmm0
  40b408:	movabs rax,0x8000000000000000
  40b412:	xor    rsi,rax
  40b415:	jmp    40b41c <__swc_fn_6b1cf01f_000001_0ce64436+0xebc>
  40b417:	vcvttsd2si rsi,xmm0
  40b41c:	sub    rsp,0x8
  40b420:	call   407270 <__swc_fn_6b1cf01f_000000_1ca87929>
  40b425:	add    rsp,0x8
  40b429:	vsubsd xmm0,xmm0,QWORD PTR [rsp+0x2d0]
  40b432:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x7f4b]        # 413385 <__swc_rdata_base_6b1cf01f+0x275>
  40b43a:	lea    rax,[rip+0x7e0f]        # 413250 <__swc_rdata_base_6b1cf01f+0x140>
  40b441:	sub    rsp,0x90
  40b448:	mov    rcx,rsp
  40b44b:	vmovups xmm1,XMMWORD PTR [rip+0x7ee5]        # 413338 <__swc_rdata_base_6b1cf01f+0x228>
  40b453:	vmovups XMMWORD PTR [rcx],xmm1
  40b457:	mov    QWORD PTR [rcx+0x30],rsp
  40b45b:	lea    rdx,[rip+0x7dfe]        # 413260 <__swc_rdata_base_6b1cf01f+0x150>
  40b462:	mov    QWORD PTR [rcx+0x38],rdx
  40b466:	mov    QWORD PTR [rcx+0x10],rsi
  40b46a:	lea    r8,[rsp+0x10]
  40b46f:	mov    QWORD PTR [rcx+0x40],r8
  40b473:	lea    r8,[rip+0x7e2e]        # 4132a8 <__swc_rdata_base_6b1cf01f+0x198>
  40b47a:	mov    QWORD PTR [rcx+0x48],r8
  40b47e:	vmovups xmm1,XMMWORD PTR [rip+0x7ec2]        # 413348 <__swc_rdata_base_6b1cf01f+0x238>
  40b486:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40b48b:	lea    r8,[rsp+0x18]
  40b490:	mov    QWORD PTR [rcx+0x50],r8
  40b494:	mov    QWORD PTR [rcx+0x58],rdx
  40b498:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40b49d:	lea    r8,[rcx+0x28]
  40b4a1:	mov    QWORD PTR [rcx+0x60],r8
  40b4a5:	lea    r8,[rip+0x7e44]        # 4132f0 <__swc_rdata_base_6b1cf01f+0x1e0>
  40b4ac:	mov    QWORD PTR [rcx+0x68],r8
  40b4b0:	mov    QWORD PTR [rcx+0x70],rax
  40b4b4:	mov    QWORD PTR [rcx+0x78],rdx
  40b4b8:	lea    rax,[rcx+0x30]
  40b4bc:	mov    QWORD PTR [rcx+0x80],rax
  40b4c3:	mov    QWORD PTR [rcx+0x88],0x5
  40b4ce:	lea    rcx,[rcx+0x80]
  40b4d5:	sub    rsp,0x8
  40b4d9:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  40b4de:	add    rsp,0x5a8
  40b4e5:	vmovups xmm6,XMMWORD PTR [rsp]
  40b4ea:	vmovups xmm7,XMMWORD PTR [rsp+0x10]
  40b4f0:	vmovups xmm8,XMMWORD PTR [rsp+0x20]
  40b4f6:	vmovups xmm9,XMMWORD PTR [rsp+0x30]
  40b4fc:	vmovups xmm10,XMMWORD PTR [rsp+0x40]
  40b502:	vmovups xmm11,XMMWORD PTR [rsp+0x50]
  40b508:	vmovups xmm12,XMMWORD PTR [rsp+0x60]
  40b50e:	vmovups xmm13,XMMWORD PTR [rsp+0x70]
  40b514:	vmovups xmm14,XMMWORD PTR [rsp+0x80]
  40b51d:	vmovups xmm15,XMMWORD PTR [rsp+0x90]
  40b526:	add    rsp,0xa8
  40b52d:	pop    rsi
  40b52e:	pop    rbx
  40b52f:	pop    rbp
  40b530:	ret
	...

000000000040b540 <__swc_fn_6b1cf01f_000004_81d2e1e9>:
  40b540:	sub    rsp,0x8
  40b544:	call   409540 <__swc_fn_6b1cf01f_000111_6b799b8d>
  40b549:	mov    rcx,rax
  40b54c:	test   rax,rax
  40b54f:	je     40b576 <__swc_fn_6b1cf01f_000004_81d2e1e9+0x36>
  40b551:	lea    rdx,[rip+0x18ae8]        # 424040 <__swc_bss_base_6b1cf01f>
  40b558:	mov    r8,QWORD PTR [rip+0x18ae1]        # 424040 <__swc_bss_base_6b1cf01f>
  40b55f:	nop
  40b560:	lea    r9,[r8+0x1]
  40b564:	mov    rax,r8
  40b567:	lock cmpxchg QWORD PTR [rdx],r9
  40b56c:	cmp    rax,r8
  40b56f:	je     40b576 <__swc_fn_6b1cf01f_000004_81d2e1e9+0x36>
  40b571:	mov    r8,rax
  40b574:	jmp    40b560 <__swc_fn_6b1cf01f_000004_81d2e1e9+0x20>
  40b576:	mov    rax,rcx
  40b579:	add    rsp,0x8
  40b57d:	ret
	...

000000000040b580 <__swc_fn_6b1cf01f_000007_065ed5b1>:
  40b580:	mov    r8d,edx
  40b583:	xor    eax,eax
  40b585:	tzcnt  eax,edx
  40b589:	shrx   r9d,edx,eax
  40b58e:	mov    DWORD PTR [rcx+0x2c],edx
  40b591:	xor    eax,eax
  40b593:	tzcnt  eax,edx
  40b597:	mov    BYTE PTR [rcx+0x38],al
  40b59a:	mov    eax,0xffffffff
  40b59f:	xor    edx,edx
  40b5a1:	div    r8d
  40b5a4:	mov    DWORD PTR [rcx+0x34],eax
  40b5a7:	mov    eax,r9d
  40b5aa:	mov    edx,r9d
  40b5ad:	imul   edx,r9d
  40b5b1:	mov    r8d,0x2
  40b5b7:	sub    r8d,edx
  40b5ba:	imul   eax,r8d
  40b5be:	mov    edx,r9d
  40b5c1:	imul   edx,eax
  40b5c4:	mov    r8d,0x2
  40b5ca:	sub    r8d,edx
  40b5cd:	imul   eax,r8d
  40b5d1:	mov    edx,r9d
  40b5d4:	imul   edx,eax
  40b5d7:	mov    r8d,0x2
  40b5dd:	sub    r8d,edx
  40b5e0:	imul   eax,r8d
  40b5e4:	mov    edx,r9d
  40b5e7:	imul   edx,eax
  40b5ea:	mov    r8d,0x2
  40b5f0:	sub    r8d,edx
  40b5f3:	imul   eax,r8d
  40b5f7:	imul   r9d,eax
  40b5fb:	mov    edx,0x2
  40b600:	sub    edx,r9d
  40b603:	imul   eax,edx
  40b606:	mov    DWORD PTR [rcx+0x30],eax
  40b609:	ret
  40b60a:	add    BYTE PTR [rax],al
  40b60c:	add    BYTE PTR [rax],al
	...

000000000040b610 <__swc_fn_6b1cf01f_000010_861b8b62>:
  40b610:	xor    eax,eax
  40b612:	mov    DWORD PTR [rcx+0x68],eax
  40b615:	ret
	...

000000000040b620 <__swc_fn_6b1cf01f_000013_9dea5065>:
  40b620:	mov    eax,DWORD PTR [rcx+0x28]
  40b623:	shlx   eax,edx,eax
  40b628:	shl    rax,0x10
  40b62c:	lea    rdx,[rcx+rax*1]
  40b630:	lea    rax,[rcx+0x3000]
  40b637:	cmp    rdx,rax
  40b63a:	cmovae rax,rdx
  40b63e:	ret
	...

000000000040b640 <__swc_fn_6b1cf01f_000016_283e2b5e>:
  40b640:	push   rsi
  40b641:	push   rdi
  40b642:	push   r12
  40b644:	push   r13
  40b646:	push   r14
  40b648:	mov    rsi,rdx
  40b64b:	mov    rdi,rcx
  40b64e:	rex mov dl,BYTE PTR [rsi+0x3a]
  40b652:	mov    ecx,DWORD PTR [rdi+0x28]
  40b655:	shr    dl,cl
  40b657:	mov    r12d,0x1
  40b65d:	mov    ecx,edx
  40b65f:	shl    r12,cl
  40b662:	mov    r13d,DWORD PTR [rsi+0x3c]
  40b666:	rex mov BYTE PTR [rsi+0x3b],0x0
  40b66b:	mov    QWORD PTR [rsi+0x40],0x0
  40b673:	mov    QWORD PTR [rsi],0x0
  40b67a:	mov    rax,QWORD PTR [rsi+0x10]
  40b67e:	mov    QWORD PTR [rsi+0x20],rax
  40b682:	lea    r14,[rip+0x189bf]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  40b689:	mov    rax,QWORD PTR [r14]
  40b68c:	shr    rax,0x2
  40b690:	mov    rcx,rax
  40b693:	cmp    rax,0x800000
  40b69a:	mov    eax,0x800000
  40b69f:	cmovb  rcx,rax
  40b6a3:	lea    r8,[rip+0x189ae]        # 424058 <__swc_bss_base_6b1cf01f+0x18>
  40b6aa:	mov    rax,QWORD PTR [r8]
  40b6ad:	mov    r9,rax
  40b6b0:	lea    r10,[r9+r13*1]
  40b6b4:	cmp    r10,rcx
  40b6b7:	ja     40b6db <__swc_fn_6b1cf01f_000016_283e2b5e+0x9b>
  40b6b9:	mov    rax,r9
  40b6bc:	lock cmpxchg QWORD PTR [r8],r10
  40b6c1:	cmp    rax,r9
  40b6c4:	je     40b6cb <__swc_fn_6b1cf01f_000016_283e2b5e+0x8b>
  40b6c6:	mov    r9,rax
  40b6c9:	jmp    40b6b0 <__swc_fn_6b1cf01f_000016_283e2b5e+0x70>
  40b6cb:	mov    rcx,rdi
  40b6ce:	mov    rdx,r12
  40b6d1:	call   407670 <__swc_fn_6b1cf01f_000018_de02dbdf>
  40b6d6:	jmp    40b75d <__swc_fn_6b1cf01f_000016_283e2b5e+0x11d>
  40b6db:	mov    rcx,rdi
  40b6de:	movzx  edx,dl
  40b6e1:	call   40b620 <__swc_fn_6b1cf01f_000013_9dea5065>
  40b6e6:	test   r13,r13
  40b6e9:	je     40b756 <__swc_fn_6b1cf01f_000016_283e2b5e+0x116>
  40b6ef:	mov    rcx,rax
  40b6f2:	mov    rdx,r13
  40b6f5:	call   4096c0 <__swc_fn_6b1cf01f_000114_e9fc0224>
  40b6fa:	mov    rcx,QWORD PTR [rip+0x18947]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  40b701:	cs nop WORD PTR [rax+rax*1+0x0]
  40b70b:	nop    DWORD PTR [rax+rax*1+0x0]
  40b710:	mov    rdx,rcx
  40b713:	sub    rdx,r13
  40b716:	mov    rax,rcx
  40b719:	lock cmpxchg QWORD PTR [r14],rdx
  40b71e:	cmp    rax,rcx
  40b721:	je     40b728 <__swc_fn_6b1cf01f_000016_283e2b5e+0xe8>
  40b723:	mov    rcx,rax
  40b726:	jmp    40b710 <__swc_fn_6b1cf01f_000016_283e2b5e+0xd0>
  40b728:	lea    rcx,[rip+0x18931]        # 424060 <__swc_bss_base_6b1cf01f+0x20>
  40b72f:	mov    rdx,QWORD PTR [rip+0x1892a]        # 424060 <__swc_bss_base_6b1cf01f+0x20>
  40b736:	cs nop WORD PTR [rax+rax*1+0x0]
  40b740:	lea    r8,[rdx+0x1]
  40b744:	mov    rax,rdx
  40b747:	lock cmpxchg QWORD PTR [rcx],r8
  40b74c:	cmp    rax,rdx
  40b74f:	je     40b756 <__swc_fn_6b1cf01f_000016_283e2b5e+0x116>
  40b751:	mov    rdx,rax
  40b754:	jmp    40b740 <__swc_fn_6b1cf01f_000016_283e2b5e+0x100>
  40b756:	mov    DWORD PTR [rsi+0x3c],0x0
  40b75d:	mov    rcx,rdi
  40b760:	mov    rdx,r12
  40b763:	call   40fab0 <__swc_fn_6b1cf01f_000020_c8f5f27c>
  40b768:	pop    r14
  40b76a:	pop    r13
  40b76c:	pop    r12
  40b76e:	pop    rdi
  40b76f:	pop    rsi
  40b770:	ret
	...

000000000040b780 <__swc_fn_6b1cf01f_000019_fd2b165c>:
  40b780:	mov    r8,QWORD PTR [rcx+0x48]
  40b784:	test   r8,rdx
  40b787:	je     40b7b8 <__swc_fn_6b1cf01f_000019_fd2b165c+0x38>
  40b789:	nop    DWORD PTR [rax+0x0]
  40b790:	mov    rax,rdx
  40b793:	not    rax
  40b796:	mov    r9,r8
  40b799:	and    r9,rax
  40b79c:	mov    rax,r8
  40b79f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40b7a5:	cmp    rax,r8
  40b7a8:	jne    40b7b0 <__swc_fn_6b1cf01f_000019_fd2b165c+0x30>
  40b7aa:	mov    eax,0x1
  40b7af:	ret
  40b7b0:	mov    r8,rax
  40b7b3:	test   rax,rdx
  40b7b6:	jne    40b790 <__swc_fn_6b1cf01f_000019_fd2b165c+0x10>
  40b7b8:	xor    eax,eax
  40b7ba:	ret
  40b7bb:	add    BYTE PTR [rax],al
  40b7bd:	add    BYTE PTR [rax],al
	...

000000000040b7c0 <__swc_fn_6b1cf01f_000022_2685aade>:
  40b7c0:	push   rsi
  40b7c1:	push   rdi
  40b7c2:	push   r12
  40b7c4:	push   r13
  40b7c6:	sub    rsp,0x8
  40b7ca:	mov    rsi,rdx
  40b7cd:	mov    rdi,rcx
  40b7d0:	lea    r12,[rip+0x18a19]        # 4241f0 <__swc_bss_base_6b1cf01f+0x1b0>
  40b7d7:	mov    rcx,r12
  40b7da:	call   411d40 <__swc_fn_6b1cf01f_000137_86bb0f90>
  40b7df:	xor    eax,eax
  40b7e1:	mov    rcx,QWORD PTR [rip+0x18a10]        # 4241f8 <__swc_bss_base_6b1cf01f+0x1b8>
  40b7e8:	mov    r13,rcx
  40b7eb:	test   r13,r13
  40b7ee:	je     40b83b <__swc_fn_6b1cf01f_000022_2685aade+0x7b>
  40b7f0:	mov    rcx,QWORD PTR [r13+0x10]
  40b7f4:	cmp    DWORD PTR [r13+0x28],esi
  40b7f8:	jne    40b830 <__swc_fn_6b1cf01f_000022_2685aade+0x70>
  40b7fa:	test   rax,rax
  40b7fd:	jne    40b808 <__swc_fn_6b1cf01f_000022_2685aade+0x48>
  40b7ff:	mov    QWORD PTR [rip+0x189f2],rcx        # 4241f8 <__swc_bss_base_6b1cf01f+0x1b8>
  40b806:	jmp    40b80c <__swc_fn_6b1cf01f_000022_2685aade+0x4c>
  40b808:	mov    QWORD PTR [rax+0x10],rcx
  40b80c:	vxorps xmm0,xmm0,xmm0
  40b810:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40b816:	mov    QWORD PTR [r13+0x8],rdi
  40b81a:	mov    rcx,r12
  40b81d:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  40b822:	mov    rax,r13
  40b825:	add    rsp,0x8
  40b829:	pop    r13
  40b82b:	pop    r12
  40b82d:	pop    rdi
  40b82e:	pop    rsi
  40b82f:	ret
  40b830:	mov    rax,r13
  40b833:	mov    r13,rcx
  40b836:	test   rcx,rcx
  40b839:	jne    40b7f0 <__swc_fn_6b1cf01f_000022_2685aade+0x30>
  40b83b:	mov    ecx,esi
  40b83d:	call   4076a0 <__swc_fn_6b1cf01f_000021_2d0fcd2c>
  40b842:	mov    rsi,rax
  40b845:	test   rax,rax
  40b848:	jne    40b85f <__swc_fn_6b1cf01f_000022_2685aade+0x9f>
  40b84a:	mov    rcx,r12
  40b84d:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  40b852:	xor    eax,eax
  40b854:	add    rsp,0x8
  40b858:	pop    r13
  40b85a:	pop    r12
  40b85c:	pop    rdi
  40b85d:	pop    rsi
  40b85e:	ret
  40b85f:	mov    QWORD PTR [rsi+0x8],rdi
  40b863:	mov    rcx,r12
  40b866:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  40b86b:	mov    rax,rsi
  40b86e:	add    rsp,0x8
  40b872:	pop    r13
  40b874:	pop    r12
  40b876:	pop    rdi
  40b877:	pop    rsi
  40b878:	ret
  40b879:	add    BYTE PTR [rax],al
  40b87b:	add    BYTE PTR [rax],al
  40b87d:	add    BYTE PTR [rax],al
	...

000000000040b880 <__swc_fn_6b1cf01f_000025_9798fb47>:
  40b880:	vxorps xmm0,xmm0,xmm0
  40b884:	xor    eax,eax
  40b886:	cs nop WORD PTR [rax+rax*1+0x0]
  40b890:	cs nop WORD PTR [rax+rax*1+0x0]
  40b89a:	nop    WORD PTR [rax+rax*1+0x0]
  40b8a0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40b8a5:	add    rax,0x10
  40b8a9:	cmp    rax,0x2b00
  40b8b0:	jne    40b8a0 <__swc_fn_6b1cf01f_000025_9798fb47+0x20>
  40b8b2:	ret
	...

000000000040b8c0 <__swc_fn_6b1cf01f_000028_9798fb47>:
  40b8c0:	vxorps xmm0,xmm0,xmm0
  40b8c4:	vmovups XMMWORD PTR [rcx],xmm0
  40b8c8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b8cd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b8d2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b8d7:	ret
	...

000000000040b8e0 <__swc_fn_6b1cf01f_000031_9798fb47>:
  40b8e0:	vxorps xmm0,xmm0,xmm0
  40b8e4:	vmovups XMMWORD PTR [rcx],xmm0
  40b8e8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b8ed:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b8f2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b8f7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40b8fc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40b901:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40b906:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40b90b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40b913:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40b91b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40b923:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40b92b:	mov    QWORD PTR [rcx+0xc0],0x0
  40b936:	ret
	...

000000000040b940 <__swc_fn_6b1cf01f_000034_92d9bbff>:
  40b940:	push   rsi
  40b941:	push   rdi
  40b942:	sub    rsp,0x8
  40b946:	mov    rsi,rcx
  40b949:	lea    rdi,[rip+0x166b0]        # 422000 <__swc_data_base_6b1cf01f>
  40b950:	mov    rax,QWORD PTR [rdi]
  40b953:	cmp    rax,0xffffffffffffffff
  40b957:	je     40b95e <__swc_fn_6b1cf01f_000034_92d9bbff+0x1e>
  40b959:	mov    rdi,rax
  40b95c:	jmp    40b98b <__swc_fn_6b1cf01f_000034_92d9bbff+0x4b>
  40b95e:	call   411a20 <__swc_fn_6b1cf01f_000125_58f0f391>
  40b963:	mov    rcx,rax
  40b966:	cmp    rax,0xffffffffffffffff
  40b96a:	je     40b99c <__swc_fn_6b1cf01f_000034_92d9bbff+0x5c>
  40b96c:	mov    rax,0xffffffffffffffff
  40b973:	lock cmpxchg QWORD PTR [rdi],rcx
  40b978:	cmp    rax,0xffffffffffffffff
  40b97c:	je     40b988 <__swc_fn_6b1cf01f_000034_92d9bbff+0x48>
  40b97e:	mov    rdi,rax
  40b981:	call   409a90 <__swc_fn_6b1cf01f_000126_a481cb88>
  40b986:	jmp    40b98b <__swc_fn_6b1cf01f_000034_92d9bbff+0x4b>
  40b988:	mov    rdi,rcx
  40b98b:	cmp    rdi,0xffffffffffffffff
  40b98f:	je     40b99c <__swc_fn_6b1cf01f_000034_92d9bbff+0x5c>
  40b991:	mov    rcx,rdi
  40b994:	mov    rdx,rsi
  40b997:	call   40da50 <__swc_fn_6b1cf01f_000127_4bbe3f14>
  40b99c:	add    rsp,0x8
  40b9a0:	pop    rdi
  40b9a1:	pop    rsi
  40b9a2:	ret
	...

000000000040b9b0 <__swc_fn_6b1cf01f_000037_03f1bf9a>:
  40b9b0:	sub    rsp,0x38
  40b9b4:	mov    rax,rdx
  40b9b7:	test   dl,dl
  40b9b9:	jne    40b9d1 <__swc_fn_6b1cf01f_000037_03f1bf9a+0x21>
  40b9bb:	mov    rax,r8
  40b9be:	test   r8b,r8b
  40b9c1:	cmove  eax,r9d
  40b9c5:	test   al,al
  40b9c7:	cmove  eax,r10d
  40b9cb:	test   al,al
  40b9cd:	cmove  eax,r11d
  40b9d1:	test   al,al
  40b9d3:	jne    40b9da <__swc_fn_6b1cf01f_000037_03f1bf9a+0x2a>
  40b9d5:	add    rsp,0x38
  40b9d9:	ret
  40b9da:	lea    rcx,[rip+0x79af]        # 413390 <__swc_rdata_base_6b1cf01f+0x280>
  40b9e1:	vmovups xmm0,XMMWORD PTR [rip+0x79b7]        # 4133a0 <__swc_rdata_base_6b1cf01f+0x290>
  40b9e9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40b9ef:	vmovups xmm0,XMMWORD PTR [rip+0x79b9]        # 4133b0 <__swc_rdata_base_6b1cf01f+0x2a0>
  40b9f7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40b9fd:	vmovups xmm0,XMMWORD PTR [rip+0x79bb]        # 4133c0 <__swc_rdata_base_6b1cf01f+0x2b0>
  40ba05:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40ba0b:	lea    rdx,[rsp+0x8]
  40ba10:	call   4092c0 <__swc_fn_6b1cf01f_000105_90faaa26>
  40ba15:	jmp    40b9d5 <__swc_fn_6b1cf01f_000037_03f1bf9a+0x25>
	...

000000000040ba20 <__swc_fn_6b1cf01f_000040_facd3e17>:
  40ba20:	sub    rsp,0x8
  40ba24:	mov    eax,0x1000
  40ba29:	test   eax,eax
  40ba2b:	mov    r8d,0x8
  40ba31:	cmove  eax,r8d
  40ba35:	dec    rax
  40ba38:	mov    r8,0xffffffffffffffff
  40ba3f:	sub    r8,rax
  40ba42:	cmp    rdx,r8
  40ba45:	ja     40ba55 <__swc_fn_6b1cf01f_000040_facd3e17+0x35>
  40ba47:	add    rdx,rax
  40ba4a:	not    rax
  40ba4d:	mov    r8,rdx
  40ba50:	and    r8,rax
  40ba53:	jne    40ba5c <__swc_fn_6b1cf01f_000040_facd3e17+0x3c>
  40ba55:	xor    eax,eax
  40ba57:	add    rsp,0x8
  40ba5b:	ret
  40ba5c:	mov    rdx,r8
  40ba5f:	call   4079c0 <__swc_fn_6b1cf01f_000039_c90d80c1>
  40ba64:	add    rsp,0x8
  40ba68:	ret
  40ba69:	add    BYTE PTR [rax],al
  40ba6b:	add    BYTE PTR [rax],al
  40ba6d:	add    BYTE PTR [rax],al
	...

000000000040ba70 <__swc_fn_6b1cf01f_000043_d8bd27c3>:
  40ba70:	push   rsi
  40ba71:	push   rdi
  40ba72:	sub    rsp,0x8
  40ba76:	mov    rsi,rdx
  40ba79:	mov    rdi,rcx
  40ba7c:	test   rdx,rdx
  40ba7f:	je     40ba9b <__swc_fn_6b1cf01f_000043_d8bd27c3+0x2b>
  40ba81:	xor    ecx,ecx
  40ba83:	call   40fbd0 <__swc_fn_6b1cf01f_000035_28d0e998>
  40ba88:	mov    rax,QWORD PTR [rsi]
  40ba8b:	test   rax,rax
  40ba8e:	je     40ba9b <__swc_fn_6b1cf01f_000043_d8bd27c3+0x2b>
  40ba90:	mov    rcx,rax
  40ba93:	mov    rdx,rsi
  40ba96:	call   40fce0 <__swc_fn_6b1cf01f_000044_b30433d0>
  40ba9b:	mov    rcx,rdi
  40ba9e:	call   407a20 <__swc_fn_6b1cf01f_000042_a78ae66b>
  40baa3:	mov    rsi,rax
  40baa6:	test   rax,rax
  40baa9:	jne    40bab4 <__swc_fn_6b1cf01f_000043_d8bd27c3+0x44>
  40baab:	xor    eax,eax
  40baad:	add    rsp,0x8
  40bab1:	pop    rdi
  40bab2:	pop    rsi
  40bab3:	ret
  40bab4:	mov    rcx,rsi
  40bab7:	call   40fbd0 <__swc_fn_6b1cf01f_000035_28d0e998>
  40babc:	mov    rax,rsi
  40babf:	add    rsp,0x8
  40bac3:	pop    rdi
  40bac4:	pop    rsi
  40bac5:	ret
	...

000000000040bad0 <__swc_fn_6b1cf01f_000046_137687bb>:
  40bad0:	movzx  eax,BYTE PTR [r8+0x39]
  40bad5:	lea    rax,[rax+rax*4]
  40bad9:	lea    rax,[rdx+rax*8+0x28]
  40bade:	mov    ecx,DWORD PTR [r8+0x6c]
  40bae2:	test   ecx,ecx
  40bae4:	je     40bb1d <__swc_fn_6b1cf01f_000046_137687bb+0x4d>
  40bae6:	mov    rcx,QWORD PTR [r8+0x50]
  40baea:	test   rcx,rcx
  40baed:	je     40baf9 <__swc_fn_6b1cf01f_000046_137687bb+0x29>
  40baef:	mov    rax,QWORD PTR [r8+0x48]
  40baf3:	mov    QWORD PTR [rcx+0x48],rax
  40baf7:	jmp    40bb01 <__swc_fn_6b1cf01f_000046_137687bb+0x31>
  40baf9:	mov    rcx,QWORD PTR [r8+0x48]
  40bafd:	mov    QWORD PTR [rax+0x18],rcx
  40bb01:	mov    rax,QWORD PTR [r8+0x48]
  40bb05:	test   rax,rax
  40bb08:	je     40bb12 <__swc_fn_6b1cf01f_000046_137687bb+0x42>
  40bb0a:	mov    rcx,QWORD PTR [r8+0x50]
  40bb0e:	mov    QWORD PTR [rax+0x50],rcx
  40bb12:	vxorps xmm0,xmm0,xmm0
  40bb16:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40bb1c:	ret
  40bb1d:	mov    rcx,QWORD PTR [r8+0x50]
  40bb21:	test   rcx,rcx
  40bb24:	je     40bb30 <__swc_fn_6b1cf01f_000046_137687bb+0x60>
  40bb26:	mov    rdx,QWORD PTR [r8+0x48]
  40bb2a:	mov    QWORD PTR [rcx+0x48],rdx
  40bb2e:	jmp    40bb38 <__swc_fn_6b1cf01f_000046_137687bb+0x68>
  40bb30:	mov    rcx,QWORD PTR [r8+0x48]
  40bb34:	mov    QWORD PTR [rax+0x8],rcx
  40bb38:	mov    rcx,QWORD PTR [r8+0x48]
  40bb3c:	test   rcx,rcx
  40bb3f:	je     40bb4b <__swc_fn_6b1cf01f_000046_137687bb+0x7b>
  40bb41:	mov    rdx,QWORD PTR [r8+0x50]
  40bb45:	mov    QWORD PTR [rcx+0x50],rdx
  40bb49:	jmp    40bb53 <__swc_fn_6b1cf01f_000046_137687bb+0x83>
  40bb4b:	mov    rcx,QWORD PTR [r8+0x50]
  40bb4f:	mov    QWORD PTR [rax+0x10],rcx
  40bb53:	cmp    QWORD PTR [rax],r8
  40bb56:	jne    40bb5f <__swc_fn_6b1cf01f_000046_137687bb+0x8f>
  40bb58:	mov    QWORD PTR [rax],0x0
  40bb5f:	vxorps xmm0,xmm0,xmm0
  40bb63:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40bb69:	ret
  40bb6a:	add    BYTE PTR [rax],al
  40bb6c:	add    BYTE PTR [rax],al
	...

000000000040bb70 <__swc_fn_6b1cf01f_000049_e072b516>:
  40bb70:	sub    rsp,0x8
  40bb74:	mov    r9,r8
  40bb77:	mov    r10,rdx
  40bb7a:	call   40bad0 <__swc_fn_6b1cf01f_000046_137687bb>
  40bb7f:	mov    DWORD PTR [r9+0x6c],0x0
  40bb87:	movzx  eax,BYTE PTR [r9+0x39]
  40bb8c:	lea    rax,[rax+rax*4]
  40bb90:	lea    rax,[r10+rax*8+0x28]
  40bb95:	mov    rcx,QWORD PTR [rax+0x10]
  40bb99:	mov    QWORD PTR [r9+0x50],rcx
  40bb9d:	mov    QWORD PTR [r9+0x48],0x0
  40bba5:	mov    rcx,QWORD PTR [rax+0x10]
  40bba9:	test   rcx,rcx
  40bbac:	je     40bbb4 <__swc_fn_6b1cf01f_000049_e072b516+0x44>
  40bbae:	mov    QWORD PTR [rcx+0x48],r9
  40bbb2:	jmp    40bbb8 <__swc_fn_6b1cf01f_000049_e072b516+0x48>
  40bbb4:	mov    QWORD PTR [rax+0x8],r9
  40bbb8:	mov    QWORD PTR [rax+0x10],r9
  40bbbc:	add    rsp,0x8
  40bbc0:	ret
	...

000000000040bbe0 <__swc_fn_6b1cf01f_000052_faa92dcc>:
  40bbe0:	push   rsi
  40bbe1:	push   rdi
  40bbe2:	push   r12
  40bbe4:	push   r13
  40bbe6:	push   r14
  40bbe8:	push   r15
  40bbea:	sub    rsp,0x1f8
  40bbf1:	mov    esi,r8d
  40bbf4:	mov    QWORD PTR [rsp+0x1e8],rsi
  40bbfc:	mov    rdi,rcx
  40bbff:	mov    r12,rdx
  40bc02:	lea    r13,[rsi+rsi*4]
  40bc06:	lea    r13,[rdx+r13*8+0x28]
  40bc0b:	call   410140 <__swc_fn_6b1cf01f_000050_d846b172>
  40bc10:	add    DWORD PTR [r12+0x24],0x1
  40bc16:	test   BYTE PTR [r12+0x24],0x3f
  40bc1c:	jne    40bc26 <__swc_fn_6b1cf01f_000052_faa92dcc+0x46>
  40bc1e:	mov    rcx,rdi
  40bc21:	call   407ba0 <__swc_fn_6b1cf01f_000051_3af34d7f>
  40bc26:	mov    rax,QWORD PTR [r13+0x8]
  40bc2a:	mov    r14,rax
  40bc2d:	nop    DWORD PTR [rax]
  40bc30:	test   r14,r14
  40bc33:	jne    40bc42 <__swc_fn_6b1cf01f_000052_faa92dcc+0x62>
  40bc35:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40bc3d:	jmp    40bd49 <__swc_fn_6b1cf01f_000052_faa92dcc+0x169>
  40bc42:	mov    r15,QWORD PTR [r14+0x48]
  40bc46:	mov    rcx,r14
  40bc49:	call   40f8a0 <__swc_fn_6b1cf01f_000011_e4b0ddfc>
  40bc4e:	mov    rax,QWORD PTR [r14]
  40bc51:	test   rax,rax
  40bc54:	je     40bc66 <__swc_fn_6b1cf01f_000052_faa92dcc+0x86>
  40bc56:	mov    rcx,QWORD PTR [rax]
  40bc59:	mov    QWORD PTR [r14],rcx
  40bc5c:	add    DWORD PTR [r14+0x28],0x1
  40bc61:	mov    rsi,rax
  40bc64:	jmp    40bc85 <__swc_fn_6b1cf01f_000052_faa92dcc+0xa5>
  40bc66:	mov    rax,QWORD PTR [r14+0x18]
  40bc6a:	cmp    QWORD PTR [r14+0x20],rax
  40bc6e:	jae    40bc83 <__swc_fn_6b1cf01f_000052_faa92dcc+0xa3>
  40bc70:	mov    rsi,QWORD PTR [r14+0x20]
  40bc74:	mov    eax,DWORD PTR [r14+0x2c]
  40bc78:	add    QWORD PTR [r14+0x20],rax
  40bc7c:	add    DWORD PTR [r14+0x28],0x1
  40bc81:	jmp    40bc85 <__swc_fn_6b1cf01f_000052_faa92dcc+0xa5>
  40bc83:	xor    esi,esi
  40bc85:	test   rsi,rsi
  40bc88:	jne    40bccd <__swc_fn_6b1cf01f_000052_faa92dcc+0xed>
  40bc8a:	mov    rcx,r14
  40bc8d:	call   40f7d0 <__swc_fn_6b1cf01f_000008_24a20786>
  40bc92:	test   al,al
  40bc94:	je     40bccd <__swc_fn_6b1cf01f_000052_faa92dcc+0xed>
  40bc96:	mov    rax,QWORD PTR [r14]
  40bc99:	test   rax,rax
  40bc9c:	je     40bcab <__swc_fn_6b1cf01f_000052_faa92dcc+0xcb>
  40bc9e:	mov    rcx,QWORD PTR [rax]
  40bca1:	mov    QWORD PTR [r14],rcx
  40bca4:	add    DWORD PTR [r14+0x28],0x1
  40bca9:	jmp    40bcca <__swc_fn_6b1cf01f_000052_faa92dcc+0xea>
  40bcab:	mov    rax,QWORD PTR [r14+0x18]
  40bcaf:	cmp    QWORD PTR [r14+0x20],rax
  40bcb3:	jae    40bcc8 <__swc_fn_6b1cf01f_000052_faa92dcc+0xe8>
  40bcb5:	mov    rax,QWORD PTR [r14+0x20]
  40bcb9:	mov    ecx,DWORD PTR [r14+0x2c]
  40bcbd:	add    QWORD PTR [r14+0x20],rcx
  40bcc1:	add    DWORD PTR [r14+0x28],0x1
  40bcc6:	jmp    40bcca <__swc_fn_6b1cf01f_000052_faa92dcc+0xea>
  40bcc8:	xor    eax,eax
  40bcca:	mov    rsi,rax
  40bccd:	test   rsi,rsi
  40bcd0:	jne    40bd23 <__swc_fn_6b1cf01f_000052_faa92dcc+0x143>
  40bcd2:	mov    rcx,rdi
  40bcd5:	mov    rdx,r12
  40bcd8:	mov    r8,r14
  40bcdb:	call   407b00 <__swc_fn_6b1cf01f_000048_129b9bf4>
  40bce0:	test   al,al
  40bce2:	jne    40bd23 <__swc_fn_6b1cf01f_000052_faa92dcc+0x143>
  40bce4:	mov    rcx,r14
  40bce7:	call   40f8a0 <__swc_fn_6b1cf01f_000011_e4b0ddfc>
  40bcec:	mov    rax,QWORD PTR [r14]
  40bcef:	test   rax,rax
  40bcf2:	je     40bd01 <__swc_fn_6b1cf01f_000052_faa92dcc+0x121>
  40bcf4:	mov    rcx,QWORD PTR [rax]
  40bcf7:	mov    QWORD PTR [r14],rcx
  40bcfa:	add    DWORD PTR [r14+0x28],0x1
  40bcff:	jmp    40bd20 <__swc_fn_6b1cf01f_000052_faa92dcc+0x140>
  40bd01:	mov    rax,QWORD PTR [r14+0x18]
  40bd05:	cmp    QWORD PTR [r14+0x20],rax
  40bd09:	jae    40bd1e <__swc_fn_6b1cf01f_000052_faa92dcc+0x13e>
  40bd0b:	mov    rax,QWORD PTR [r14+0x20]
  40bd0f:	mov    ecx,DWORD PTR [r14+0x2c]
  40bd13:	add    QWORD PTR [r14+0x20],rcx
  40bd17:	add    DWORD PTR [r14+0x28],0x1
  40bd1c:	jmp    40bd20 <__swc_fn_6b1cf01f_000052_faa92dcc+0x140>
  40bd1e:	xor    eax,eax
  40bd20:	mov    rsi,rax
  40bd23:	test   rsi,rsi
  40bd26:	je     40bd41 <__swc_fn_6b1cf01f_000052_faa92dcc+0x161>
  40bd28:	mov    QWORD PTR [r13+0x0],r14
  40bd2c:	mov    rax,rsi
  40bd2f:	add    rsp,0x1f8
  40bd36:	pop    r15
  40bd38:	pop    r14
  40bd3a:	pop    r13
  40bd3c:	pop    r12
  40bd3e:	pop    rdi
  40bd3f:	pop    rsi
  40bd40:	ret
  40bd41:	mov    r14,r15
  40bd44:	jmp    40bc30 <__swc_fn_6b1cf01f_000052_faa92dcc+0x50>
  40bd49:	cs nop WORD PTR [rax+rax*1+0x0]
  40bd53:	cs nop WORD PTR [rax+rax*1+0x0]
  40bd5d:	nop    DWORD PTR [rax]
  40bd60:	mov    rcx,rdi
  40bd63:	mov    rdx,r12
  40bd66:	mov    r8d,esi
  40bd69:	call   40fe80 <__swc_fn_6b1cf01f_000047_ad48ec88>
  40bd6e:	mov    r14,rax
  40bd71:	test   rax,rax
  40bd74:	jne    40bd8a <__swc_fn_6b1cf01f_000052_faa92dcc+0x1aa>
  40bd76:	xor    eax,eax
  40bd78:	add    rsp,0x1f8
  40bd7f:	pop    r15
  40bd81:	pop    r14
  40bd83:	pop    r13
  40bd85:	pop    r12
  40bd87:	pop    rdi
  40bd88:	pop    rsi
  40bd89:	ret
  40bd8a:	mov    QWORD PTR [r13+0x0],r14
  40bd8e:	mov    rax,QWORD PTR [r14]
  40bd91:	test   rax,rax
  40bd94:	je     40bda6 <__swc_fn_6b1cf01f_000052_faa92dcc+0x1c6>
  40bd96:	mov    rcx,QWORD PTR [rax]
  40bd99:	mov    QWORD PTR [r14],rcx
  40bd9c:	add    DWORD PTR [r14+0x28],0x1
  40bda1:	mov    r15,rax
  40bda4:	jmp    40bdc6 <__swc_fn_6b1cf01f_000052_faa92dcc+0x1e6>
  40bda6:	mov    rax,QWORD PTR [r14+0x18]
  40bdaa:	cmp    QWORD PTR [r14+0x20],rax
  40bdae:	jae    40bdc3 <__swc_fn_6b1cf01f_000052_faa92dcc+0x1e3>
  40bdb0:	mov    r15,QWORD PTR [r14+0x20]
  40bdb4:	mov    eax,DWORD PTR [r14+0x2c]
  40bdb8:	add    QWORD PTR [r14+0x20],rax
  40bdbc:	add    DWORD PTR [r14+0x28],0x1
  40bdc1:	jmp    40bdc6 <__swc_fn_6b1cf01f_000052_faa92dcc+0x1e6>
  40bdc3:	xor    r15d,r15d
  40bdc6:	test   r15,r15
  40bdc9:	jne    40be0e <__swc_fn_6b1cf01f_000052_faa92dcc+0x22e>
  40bdcb:	mov    rcx,r14
  40bdce:	call   40f7d0 <__swc_fn_6b1cf01f_000008_24a20786>
  40bdd3:	test   al,al
  40bdd5:	je     40be0e <__swc_fn_6b1cf01f_000052_faa92dcc+0x22e>
  40bdd7:	mov    rax,QWORD PTR [r14]
  40bdda:	test   rax,rax
  40bddd:	je     40bdec <__swc_fn_6b1cf01f_000052_faa92dcc+0x20c>
  40bddf:	mov    rcx,QWORD PTR [rax]
  40bde2:	mov    QWORD PTR [r14],rcx
  40bde5:	add    DWORD PTR [r14+0x28],0x1
  40bdea:	jmp    40be0b <__swc_fn_6b1cf01f_000052_faa92dcc+0x22b>
  40bdec:	mov    rax,QWORD PTR [r14+0x18]
  40bdf0:	cmp    QWORD PTR [r14+0x20],rax
  40bdf4:	jae    40be09 <__swc_fn_6b1cf01f_000052_faa92dcc+0x229>
  40bdf6:	mov    rax,QWORD PTR [r14+0x20]
  40bdfa:	mov    ecx,DWORD PTR [r14+0x2c]
  40bdfe:	add    QWORD PTR [r14+0x20],rcx
  40be02:	add    DWORD PTR [r14+0x28],0x1
  40be07:	jmp    40be0b <__swc_fn_6b1cf01f_000052_faa92dcc+0x22b>
  40be09:	xor    eax,eax
  40be0b:	mov    r15,rax
  40be0e:	test   r15,r15
  40be11:	je     40bd60 <__swc_fn_6b1cf01f_000052_faa92dcc+0x180>
  40be17:	mov    rax,r15
  40be1a:	add    rsp,0x1f8
  40be21:	pop    r15
  40be23:	pop    r14
  40be25:	pop    r13
  40be27:	pop    r12
  40be29:	pop    rdi
  40be2a:	pop    rsi
  40be2b:	ret
  40be2c:	add    BYTE PTR [rax],al
	...

000000000040be30 <__swc_fn_6b1cf01f_000055_7e1dbcb0>:
  40be30:	push   rsi
  40be31:	push   rdi
  40be32:	push   r12
  40be34:	mov    rsi,rdx
  40be37:	mov    rax,rdx
  40be3a:	shr    rax,0xc
  40be3e:	movabs rdx,0x9e3779b97f4a7c15
  40be48:	imul   rax,rdx
  40be4c:	shr    rax,0x20
  40be50:	lea    rax,[rax*8+0x0]
  40be58:	shr    rax,0x20
  40be5c:	lea    rax,[rax*8+0x0]
  40be64:	lea    rax,[rcx+rax*8+0x40]
  40be69:	xor    edx,edx
  40be6b:	test   dl,dl
  40be6d:	lea    rdi,[rcx+0x8]
  40be71:	cmove  rdi,rax
  40be75:	xor    edx,edx
  40be77:	test   dl,dl
  40be79:	lea    r12,[rcx+0x30]
  40be7d:	lea    rax,[rax+0x8]
  40be81:	cmove  r12,rax
  40be85:	mov    rcx,rdi
  40be88:	call   411d40 <__swc_fn_6b1cf01f_000137_86bb0f90>
  40be8d:	mov    QWORD PTR [rsi+0x30],0x0
  40be95:	mov    rax,QWORD PTR [r12]
  40be99:	mov    QWORD PTR [rsi+0x38],rax
  40be9d:	test   rax,rax
  40bea0:	je     40beaa <__swc_fn_6b1cf01f_000055_7e1dbcb0+0x7a>
  40bea2:	mov    rax,QWORD PTR [rsi+0x38]
  40bea6:	mov    QWORD PTR [rax+0x30],rsi
  40beaa:	mov    QWORD PTR [r12],rsi
  40beae:	mov    rcx,rdi
  40beb1:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  40beb6:	pop    r12
  40beb8:	pop    rdi
  40beb9:	pop    rsi
  40beba:	ret
  40bebb:	add    BYTE PTR [rax],al
  40bebd:	add    BYTE PTR [rax],al
	...

000000000040bec0 <__swc_fn_6b1cf01f_000058_15c28ca7>:
  40bec0:	lea    rax,[rdx+rdx*4]
  40bec4:	lea    rax,[rcx+rax*8+0x268]
  40becc:	mov    rdx,QWORD PTR [rax+0x10]
  40bed0:	sub    QWORD PTR [rcx+0x2a68],rdx
  40bed7:	sub    QWORD PTR [rcx+0x2a70],0x1
  40bedf:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40bee6:	lea    rdx,[rdx+rdx*4]
  40beea:	lea    rdx,[rcx+rdx*8+0x268]
  40bef2:	vmovups xmm0,XMMWORD PTR [rdx]
  40bef6:	vmovups XMMWORD PTR [rax],xmm0
  40befa:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40beff:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40bf04:	mov    rcx,QWORD PTR [rdx+0x20]
  40bf08:	mov    QWORD PTR [rax+0x20],rcx
  40bf0c:	ret
  40bf0d:	add    BYTE PTR [rax],al
	...

000000000040bf10 <__swc_fn_6b1cf01f_000061_dea90857>:
  40bf10:	push   rsi
  40bf11:	push   rdi
  40bf12:	push   r12
  40bf14:	push   r13
  40bf16:	sub    rsp,0x8
  40bf1a:	mov    rsi,r8
  40bf1d:	mov    rdi,rcx
  40bf20:	mov    r12,rdx
  40bf23:	xor    r13d,r13d
  40bf26:	cs nop WORD PTR [rax+rax*1+0x0]
  40bf30:	mov    eax,DWORD PTR [r12+0x730]
  40bf38:	cmp    r13d,eax
  40bf3b:	jae    40bfa1 <__swc_fn_6b1cf01f_000061_dea90857+0x91>
  40bf3d:	lea    rax,[r13+r13*4+0x0]
  40bf42:	lea    rax,[r12+rax*8+0x738]
  40bf4a:	mov    rdx,QWORD PTR [rax]
  40bf4d:	mov    r8,QWORD PTR [rax+0x8]
  40bf51:	mov    r9,QWORD PTR [rax+0x10]
  40bf55:	cmp    QWORD PTR [rax+0x20],rsi
  40bf59:	jb     40bf60 <__swc_fn_6b1cf01f_000061_dea90857+0x50>
  40bf5b:	inc    r13d
  40bf5e:	jmp    40bf30 <__swc_fn_6b1cf01f_000061_dea90857+0x20>
  40bf60:	sub    DWORD PTR [r12+0x730],0x1
  40bf69:	mov    ecx,DWORD PTR [r12+0x730]
  40bf71:	lea    rcx,[rcx+rcx*4]
  40bf75:	lea    rcx,[r12+rcx*8+0x738]
  40bf7d:	vmovups xmm0,XMMWORD PTR [rcx]
  40bf81:	vmovups XMMWORD PTR [rax],xmm0
  40bf85:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40bf8a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40bf8f:	mov    rcx,QWORD PTR [rcx+0x20]
  40bf93:	mov    QWORD PTR [rax+0x20],rcx
  40bf97:	mov    rcx,rdi
  40bf9a:	call   40fc00 <__swc_fn_6b1cf01f_000041_d3c2ab54>
  40bf9f:	jmp    40bf30 <__swc_fn_6b1cf01f_000061_dea90857+0x20>
  40bfa1:	add    rsp,0x8
  40bfa5:	pop    r13
  40bfa7:	pop    r12
  40bfa9:	pop    rdi
  40bfaa:	pop    rsi
  40bfab:	ret
  40bfac:	add    BYTE PTR [rax],al
	...

000000000040bfb0 <__swc_fn_6b1cf01f_000064_de167e8d>:
  40bfb0:	push   rsi
  40bfb1:	push   rdi
  40bfb2:	push   r12
  40bfb4:	push   r13
  40bfb6:	push   r14
  40bfb8:	mov    rsi,rcx
  40bfbb:	mov    rdi,rdx
  40bfbe:	mov    r12,QWORD PTR [rdi]
  40bfc1:	mov    r13,QWORD PTR [rdi+0x18]
  40bfc5:	mov    rax,r12
  40bfc8:	add    rax,QWORD PTR [rdi+0x8]
  40bfcc:	sub    rax,r13
  40bfcf:	cmp    r8,rax
  40bfd2:	jbe    40bfdd <__swc_fn_6b1cf01f_000064_de167e8d+0x2d>
  40bfd4:	pop    r14
  40bfd6:	pop    r13
  40bfd8:	pop    r12
  40bfda:	pop    rdi
  40bfdb:	pop    rsi
  40bfdc:	ret
  40bfdd:	lea    rax,[r13+r8*1+0x0]
  40bfe2:	sub    rax,r12
  40bfe5:	mov    ecx,0x1000
  40bfea:	test   ecx,ecx
  40bfec:	mov    edx,0x8
  40bff1:	cmove  ecx,edx
  40bff4:	dec    rcx
  40bff7:	mov    rdx,0xffffffffffffffff
  40bffe:	sub    rdx,rcx
  40c001:	cmp    rax,rdx
  40c004:	jbe    40c00b <__swc_fn_6b1cf01f_000064_de167e8d+0x5b>
  40c006:	xor    r14d,r14d
  40c009:	jmp    40c016 <__swc_fn_6b1cf01f_000064_de167e8d+0x66>
  40c00b:	add    rax,rcx
  40c00e:	andn   rax,rcx,rax
  40c013:	mov    r14,rax
  40c016:	mov    rax,QWORD PTR [rdi+0x10]
  40c01a:	cmp    r14,rax
  40c01d:	ja     40c028 <__swc_fn_6b1cf01f_000064_de167e8d+0x78>
  40c01f:	pop    r14
  40c021:	pop    r13
  40c023:	pop    r12
  40c025:	pop    rdi
  40c026:	pop    rsi
  40c027:	ret
  40c028:	mov    rax,r12
  40c02b:	add    rax,QWORD PTR [rdi+0x10]
  40c02f:	mov    rdx,r14
  40c032:	sub    rdx,QWORD PTR [rdi+0x10]
  40c036:	mov    rcx,rax
  40c039:	call   40f750 <__swc_fn_6b1cf01f_000005_f7acedb0>
  40c03e:	test   al,al
  40c040:	jne    40c04b <__swc_fn_6b1cf01f_000064_de167e8d+0x9b>
  40c042:	pop    r14
  40c044:	pop    r13
  40c046:	pop    r12
  40c048:	pop    rdi
  40c049:	pop    rsi
  40c04a:	ret
  40c04b:	add    r12,r14
  40c04e:	sub    r12,r13
  40c051:	mov    rcx,r12
  40c054:	sub    rcx,QWORD PTR [rdi+0x28]
  40c058:	mov    rdx,QWORD PTR [rsi+0x250]
  40c05f:	nop
  40c060:	lea    r8,[rdx+rcx*1]
  40c064:	mov    rax,rdx
  40c067:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40c070:	cmp    rax,rdx
  40c073:	je     40c07a <__swc_fn_6b1cf01f_000064_de167e8d+0xca>
  40c075:	mov    rdx,rax
  40c078:	jmp    40c060 <__swc_fn_6b1cf01f_000064_de167e8d+0xb0>
  40c07a:	mov    QWORD PTR [rdi+0x10],r14
  40c07e:	mov    QWORD PTR [rdi+0x28],r12
  40c082:	pop    r14
  40c084:	pop    r13
  40c086:	pop    r12
  40c088:	pop    rdi
  40c089:	pop    rsi
  40c08a:	ret
  40c08b:	add    BYTE PTR [rax],al
  40c08d:	add    BYTE PTR [rax],al
	...

000000000040c090 <__swc_fn_6b1cf01f_000067_7130736e>:
  40c090:	push   rbx
  40c091:	push   rsi
  40c092:	push   rdi
  40c093:	push   r12
  40c095:	push   r13
  40c097:	sub    rsp,0xe0
  40c09e:	mov    rbx,rdx
  40c0a1:	mov    rsi,rcx
  40c0a4:	cmp    DWORD PTR [rbx+0x58],0x0
  40c0a8:	je     40c0cc <__swc_fn_6b1cf01f_000067_7130736e+0x3c>
  40c0aa:	mov    eax,DWORD PTR [rbx+0x58]
  40c0ad:	sub    eax,0x1
  40c0b0:	test   DWORD PTR [rbx+0x58],eax
  40c0b3:	je     40c0cc <__swc_fn_6b1cf01f_000067_7130736e+0x3c>
  40c0b5:	mov    QWORD PTR [rbx+0x40],0x0
  40c0bd:	add    rsp,0xe0
  40c0c4:	pop    r13
  40c0c6:	pop    r12
  40c0c8:	pop    rdi
  40c0c9:	pop    rsi
  40c0ca:	pop    rbx
  40c0cb:	ret
  40c0cc:	mov    rax,QWORD PTR [rbx+0x40]
  40c0d0:	test   rax,rax
  40c0d3:	jne    40c0ef <__swc_fn_6b1cf01f_000067_7130736e+0x5f>
  40c0d5:	mov    rcx,rsi
  40c0d8:	mov    rdx,rbx
  40c0db:	call   4087b0 <__swc_fn_6b1cf01f_000066_f3aa21af>
  40c0e0:	add    rsp,0xe0
  40c0e7:	pop    r13
  40c0e9:	pop    r12
  40c0eb:	pop    rdi
  40c0ec:	pop    rsi
  40c0ed:	pop    rbx
  40c0ee:	ret
  40c0ef:	cmp    QWORD PTR [rbx+0x48],0x0
  40c0f4:	jne    40c110 <__swc_fn_6b1cf01f_000067_7130736e+0x80>
  40c0f6:	mov    rcx,rsi
  40c0f9:	mov    rdx,rbx
  40c0fc:	call   410430 <__swc_fn_6b1cf01f_000068_97813b89>
  40c101:	add    rsp,0xe0
  40c108:	pop    r13
  40c10a:	pop    r12
  40c10c:	pop    rdi
  40c10d:	pop    rsi
  40c10e:	pop    rbx
  40c10f:	ret
  40c110:	mov    rdi,QWORD PTR [rbx+0x40]
  40c114:	lea    rax,[rip+0x17f55]        # 424070 <__swc_bss_base_6b1cf01f+0x30>
  40c11b:	mov    rcx,rdi
  40c11e:	sub    rcx,QWORD PTR [rax+0x8]
  40c122:	mov    rax,QWORD PTR [rip+0x17f57]        # 424080 <__swc_bss_base_6b1cf01f+0x40>
  40c129:	cmp    rcx,rax
  40c12c:	jae    40c158 <__swc_fn_6b1cf01f_000067_7130736e+0xc8>
  40c12e:	mov    rax,rdi
  40c131:	and    rax,0xffffffffffc00000
  40c138:	mov    rcx,rdi
  40c13b:	shr    rcx,0x10
  40c13f:	and    ecx,0x3f
  40c142:	mov    edx,DWORD PTR [rax+0x28]
  40c145:	shrx   ecx,ecx,edx
  40c14a:	shl    rcx,0x4
  40c14e:	lea    r12,[rax+rcx*8+0x80]
  40c156:	jmp    40c163 <__swc_fn_6b1cf01f_000067_7130736e+0xd3>
  40c158:	mov    rcx,rdi
  40c15b:	call   407830 <__swc_fn_6b1cf01f_000024_bcdc5519>
  40c160:	mov    r12,rax
  40c163:	test   r12,r12
  40c166:	je     40c175 <__swc_fn_6b1cf01f_000067_7130736e+0xe5>
  40c168:	mov    eax,DWORD PTR [r12+0x2c]
  40c16d:	mov    r9d,eax
  40c170:	mov    r13,rax
  40c173:	jmp    40c1f4 <__swc_fn_6b1cf01f_000067_7130736e+0x164>
  40c175:	mov    rcx,rsi
  40c178:	mov    rdx,rdi
  40c17b:	call   407e40 <__swc_fn_6b1cf01f_000054_df0696cd>
  40c180:	mov    rcx,QWORD PTR [rax+0x28]
  40c184:	mov    r9,rcx
  40c187:	mov    rdx,QWORD PTR [rax+0x20]
  40c18b:	mov    r13,rdx
  40c18e:	cmp    QWORD PTR [rbx+0x48],rcx
  40c192:	jbe    40c1cb <__swc_fn_6b1cf01f_000067_7130736e+0x13b>
  40c194:	mov    ecx,DWORD PTR [rax+0x48]
  40c197:	cmp    DWORD PTR [rbx+0x58],ecx
  40c19a:	ja     40c1cb <__swc_fn_6b1cf01f_000067_7130736e+0x13b>
  40c19c:	mov    rcx,rsi
  40c19f:	mov    rdx,rax
  40c1a2:	mov    r8,QWORD PTR [rbx+0x48]
  40c1a6:	mov    QWORD PTR [rsp+0xc8],r9
  40c1ae:	mov    QWORD PTR [rsp+0xd0],rax
  40c1b6:	call   40bfb0 <__swc_fn_6b1cf01f_000064_de167e8d>
  40c1bb:	mov    r9,QWORD PTR [rsp+0xc8]
  40c1c3:	mov    rax,QWORD PTR [rsp+0xd0]
  40c1cb:	mov    rcx,QWORD PTR [rax+0x28]
  40c1cf:	cmp    QWORD PTR [rbx+0x48],rcx
  40c1d3:	ja     40c1f4 <__swc_fn_6b1cf01f_000067_7130736e+0x164>
  40c1d5:	mov    ecx,DWORD PTR [rax+0x48]
  40c1d8:	cmp    DWORD PTR [rbx+0x58],ecx
  40c1db:	ja     40c1f4 <__swc_fn_6b1cf01f_000067_7130736e+0x164>
  40c1dd:	mov    rcx,QWORD PTR [rbx+0x48]
  40c1e1:	mov    QWORD PTR [rax+0x20],rcx
  40c1e5:	add    rsp,0xe0
  40c1ec:	pop    r13
  40c1ee:	pop    r12
  40c1f0:	pop    rdi
  40c1f1:	pop    rsi
  40c1f2:	pop    rbx
  40c1f3:	ret
  40c1f4:	test   r12,r12
  40c1f7:	je     40c229 <__swc_fn_6b1cf01f_000067_7130736e+0x199>
  40c1f9:	cmp    QWORD PTR [rbx+0x48],r9
  40c1fd:	ja     40c229 <__swc_fn_6b1cf01f_000067_7130736e+0x199>
  40c1ff:	cmp    DWORD PTR [rbx+0x58],0x40
  40c203:	ja     40c229 <__swc_fn_6b1cf01f_000067_7130736e+0x199>
  40c205:	cmp    DWORD PTR [rbx+0x58],0x0
  40c209:	je     40c216 <__swc_fn_6b1cf01f_000067_7130736e+0x186>
  40c20b:	mov    ecx,DWORD PTR [rbx+0x58]
  40c20e:	dec    rcx
  40c211:	test   rdi,rcx
  40c214:	jne    40c229 <__swc_fn_6b1cf01f_000067_7130736e+0x199>
  40c216:	mov    QWORD PTR [rbx+0x40],rdi
  40c21a:	add    rsp,0xe0
  40c221:	pop    r13
  40c223:	pop    r12
  40c225:	pop    rdi
  40c226:	pop    rsi
  40c227:	pop    rbx
  40c228:	ret
  40c229:	vmovups xmm0,XMMWORD PTR [rbx]
  40c22d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c233:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40c238:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40c23e:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40c243:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40c249:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40c24e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40c254:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40c259:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40c25f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40c264:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40c26a:	mov    QWORD PTR [rsp+0x48],0x0
  40c273:	mov    rcx,rsi
  40c276:	lea    rdx,[rsp+0x8]
  40c27b:	call   4087b0 <__swc_fn_6b1cf01f_000066_f3aa21af>
  40c280:	mov    rax,QWORD PTR [rsp+0x48]
  40c285:	test   rax,rax
  40c288:	jne    40c2a1 <__swc_fn_6b1cf01f_000067_7130736e+0x211>
  40c28a:	mov    QWORD PTR [rbx+0x40],0x0
  40c292:	add    rsp,0xe0
  40c299:	pop    r13
  40c29b:	pop    r12
  40c29d:	pop    rdi
  40c29e:	pop    rsi
  40c29f:	pop    rbx
  40c2a0:	ret
  40c2a1:	mov    rax,QWORD PTR [rbx+0x48]
  40c2a5:	cmp    r13,rax
  40c2a8:	cmovbe rax,r13
  40c2ac:	mov    rcx,QWORD PTR [rsp+0x48]
  40c2b1:	mov    rdx,rdi
  40c2b4:	mov    r8,rax
  40c2b7:	call   411580 <__swc_fn_6b1cf01f_000107_7c204aac>
  40c2bc:	vmovups xmm0,XMMWORD PTR [rbx]
  40c2c0:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40c2c6:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40c2cb:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40c2d1:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40c2d6:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40c2df:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40c2e4:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40c2ed:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40c2f2:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40c2fb:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40c300:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40c309:	mov    QWORD PTR [rsp+0xa8],rdi
  40c311:	mov    rcx,rsi
  40c314:	lea    rdx,[rsp+0x68]
  40c319:	call   410430 <__swc_fn_6b1cf01f_000068_97813b89>
  40c31e:	mov    rax,QWORD PTR [rsp+0x48]
  40c323:	mov    QWORD PTR [rbx+0x40],rax
  40c327:	add    rsp,0xe0
  40c32e:	pop    r13
  40c330:	pop    r12
  40c332:	pop    rdi
  40c333:	pop    rsi
  40c334:	pop    rbx
  40c335:	ret
	...

000000000040c340 <__swc_fn_6b1cf01f_000070_61e60aab>:
  40c340:	push   r12
  40c342:	push   rdi
  40c343:	push   rsi
  40c344:	push   r13
  40c346:	push   r14
  40c348:	sub    rsp,0x190
  40c34f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40c358:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40c361:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40c36a:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40c373:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40c37c:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40c385:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40c38e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40c397:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40c3a0:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40c3a9:	mov    r12,rcx
  40c3ac:	lea    rax,[rip+0x15c4d]        # 422000 <__swc_data_base_6b1cf01f>
  40c3b3:	mov    rax,QWORD PTR [rax]
  40c3b6:	cmp    rax,0xffffffffffffffff
  40c3ba:	je     40c3c9 <__swc_fn_6b1cf01f_000070_61e60aab+0x89>
  40c3bc:	mov    eax,eax
  40c3be:	mov    edi,eax
  40c3c0:	xor    eax,eax
  40c3c2:	call   407010 <pthread_getspecific@plt>
  40c3c7:	jmp    40c3cb <__swc_fn_6b1cf01f_000070_61e60aab+0x8b>
  40c3c9:	xor    eax,eax
  40c3cb:	test   rax,rax
  40c3ce:	jne    40c3dd <__swc_fn_6b1cf01f_000070_61e60aab+0x9d>
  40c3d0:	call   407900 <__swc_fn_6b1cf01f_000033_cd1a4e8c>
  40c3d5:	mov    rcx,rax
  40c3d8:	call   40db00 <__swc_fn_6b1cf01f_000130_5f757033>
  40c3dd:	test   rax,rax
  40c3e0:	je     40c406 <__swc_fn_6b1cf01f_000070_61e60aab+0xc6>
  40c3e2:	cmp    QWORD PTR [rax],r12
  40c3e5:	jne    40c406 <__swc_fn_6b1cf01f_000070_61e60aab+0xc6>
  40c3e7:	xor    ecx,ecx
  40c3e9:	mov    QWORD PTR [rsp+0xc8],rax
  40c3f1:	call   40fbd0 <__swc_fn_6b1cf01f_000035_28d0e998>
  40c3f6:	mov    rdx,QWORD PTR [rsp+0xc8]
  40c3fe:	mov    rcx,r12
  40c401:	call   40fce0 <__swc_fn_6b1cf01f_000044_b30433d0>
  40c406:	lea    rsi,[r12+0x10]
  40c40b:	mov    rcx,rsi
  40c40e:	call   411d40 <__swc_fn_6b1cf01f_000137_86bb0f90>
  40c413:	mov    rdi,QWORD PTR [r12+0x20]
  40c418:	test   rdi,rdi
  40c41b:	je     40c45e <__swc_fn_6b1cf01f_000070_61e60aab+0x11e>
  40c41d:	nop    DWORD PTR [rax]
  40c420:	mov    rcx,r12
  40c423:	mov    rdx,rdi
  40c426:	call   407ac0 <__swc_fn_6b1cf01f_000045_6e7a8d58>
  40c42b:	mov    rcx,r12
  40c42e:	mov    rdx,rdi
  40c431:	mov    r8,0xffffffffffffffff
  40c438:	call   40bf10 <__swc_fn_6b1cf01f_000061_dea90857>
  40c43d:	mov    rcx,r12
  40c440:	mov    rdx,rdi
  40c443:	mov    r8d,0x9b8
  40c449:	mov    r9d,0x9b8
  40c44f:	call   40fc00 <__swc_fn_6b1cf01f_000041_d3c2ab54>
  40c454:	mov    rdi,QWORD PTR [r12+0x20]
  40c459:	test   rdi,rdi
  40c45c:	jne    40c420 <__swc_fn_6b1cf01f_000070_61e60aab+0xe0>
  40c45e:	xor    eax,eax
  40c460:	xchg   QWORD PTR [r12+0x2a80],rax
  40c468:	test   rax,rax
  40c46b:	je     40c491 <__swc_fn_6b1cf01f_000070_61e60aab+0x151>
  40c46d:	cs nop WORD PTR [rax+rax*1+0x0]
  40c477:	nop    WORD PTR [rax+rax*1+0x0]
  40c480:	mov    rcx,rax
  40c483:	mov    rax,QWORD PTR [rax+0x78]
  40c487:	xor    edx,edx
  40c489:	xchg   DWORD PTR [rcx+0x70],edx
  40c48c:	test   rax,rax
  40c48f:	jne    40c480 <__swc_fn_6b1cf01f_000070_61e60aab+0x140>
  40c491:	mov    rax,QWORD PTR [r12+0x18]
  40c496:	mov    rdi,rax
  40c499:	test   rdi,rdi
  40c49c:	je     40c531 <__swc_fn_6b1cf01f_000070_61e60aab+0x1f1>
  40c4a2:	cs nop WORD PTR [rax+rax*1+0x0]
  40c4ac:	nop    DWORD PTR [rax+0x0]
  40c4b0:	mov    rax,QWORD PTR [rdi+0x10]
  40c4b4:	mov    r8d,DWORD PTR [rdi+0x2c]
  40c4b8:	xor    r9d,r9d
  40c4bb:	test   r8,r8
  40c4be:	jbe    40c51d <__swc_fn_6b1cf01f_000070_61e60aab+0x1dd>
  40c4c0:	mov    ecx,r9d
  40c4c3:	shl    rcx,0x4
  40c4c7:	lea    rdx,[rdi+rcx*8+0x80]
  40c4cf:	cmp    BYTE PTR [rdx+0x3b],0x0
  40c4d3:	je     40c514 <__swc_fn_6b1cf01f_000070_61e60aab+0x1d4>
  40c4d5:	mov    DWORD PTR [rdx+0x28],0x0
  40c4dc:	mov    rcx,rdi
  40c4df:	mov    QWORD PTR [rsp+0xd0],rax
  40c4e7:	mov    QWORD PTR [rsp+0xd8],r8
  40c4ef:	mov    QWORD PTR [rsp+0xe0],r9
  40c4f7:	call   40b640 <__swc_fn_6b1cf01f_000016_283e2b5e>
  40c4fc:	mov    rax,QWORD PTR [rsp+0xd0]
  40c504:	mov    r8,QWORD PTR [rsp+0xd8]
  40c50c:	mov    r9,QWORD PTR [rsp+0xe0]
  40c514:	add    r9,0x1
  40c518:	cmp    r9,r8
  40c51b:	jb     40c4c0 <__swc_fn_6b1cf01f_000070_61e60aab+0x180>
  40c51d:	mov    rcx,rdi
  40c520:	mov    rdi,rax
  40c523:	call   40fae0 <__swc_fn_6b1cf01f_000023_aa910677>
  40c528:	test   rdi,rdi
  40c52b:	jne    40c4b0 <__swc_fn_6b1cf01f_000070_61e60aab+0x170>
  40c531:	mov    QWORD PTR [r12+0x18],0x0
  40c53a:	mov    QWORD PTR [r12+0x28],0x0
  40c543:	mov    rcx,rsi
  40c546:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  40c54b:	mov    esi,0x8
  40c550:	xor    edi,edi
  40c552:	test   rsi,rsi
  40c555:	je     40c5b2 <__swc_fn_6b1cf01f_000070_61e60aab+0x272>
  40c55b:	nop    DWORD PTR [rax+rax*1+0x0]
  40c560:	lea    r13,[rdi*8+0x0]
  40c568:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40c56d:	test   r14,r14
  40c570:	je     40c5a8 <__swc_fn_6b1cf01f_000070_61e60aab+0x268>
  40c572:	cs nop WORD PTR [rax+rax*1+0x0]
  40c57c:	nop    DWORD PTR [rax+0x0]
  40c580:	mov    rcx,r12
  40c583:	mov    rdx,r14
  40c586:	call   410290 <__swc_fn_6b1cf01f_000056_1bb23e77>
  40c58b:	mov    rcx,r12
  40c58e:	mov    rdx,QWORD PTR [r14]
  40c591:	mov    r8,QWORD PTR [r14+0x8]
  40c595:	mov    r9,QWORD PTR [r14+0x10]
  40c599:	call   40fc00 <__swc_fn_6b1cf01f_000041_d3c2ab54>
  40c59e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40c5a3:	test   r14,r14
  40c5a6:	jne    40c580 <__swc_fn_6b1cf01f_000070_61e60aab+0x240>
  40c5a8:	add    rdi,0x1
  40c5ac:	sub    rsi,0x1
  40c5b0:	jne    40c560 <__swc_fn_6b1cf01f_000070_61e60aab+0x220>
  40c5b2:	mov    rcx,r12
  40c5b5:	call   410360 <__swc_fn_6b1cf01f_000062_ffcd96eb>
  40c5ba:	lea    rcx,[r12+0x250]
  40c5c2:	mov    rdx,QWORD PTR [rcx]
  40c5c5:	mov    r8,QWORD PTR [r12+0x250]
  40c5cd:	nop    DWORD PTR [rax]
  40c5d0:	mov    r9,r8
  40c5d3:	sub    r9,rdx
  40c5d6:	mov    rax,r8
  40c5d9:	lock cmpxchg QWORD PTR [rcx],r9
  40c5de:	cmp    rax,r8
  40c5e1:	je     40c5e8 <__swc_fn_6b1cf01f_000070_61e60aab+0x2a8>
  40c5e3:	mov    r8,rax
  40c5e6:	jmp    40c5d0 <__swc_fn_6b1cf01f_000070_61e60aab+0x290>
  40c5e8:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40c5f1:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40c5fa:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40c603:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40c60c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40c615:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40c61e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40c627:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40c630:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40c639:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40c642:	add    rsp,0x190
  40c649:	pop    r14
  40c64b:	pop    r13
  40c64d:	pop    rsi
  40c64e:	pop    rdi
  40c64f:	pop    r12
  40c651:	ret
	...

000000000040c660 <__swc_fn_6b1cf01f_000073_64d36d78>:
  40c660:	sub    rsp,0x8
  40c664:	mov    QWORD PTR [rdx+0x40],0x0
  40c66c:	call   4087b0 <__swc_fn_6b1cf01f_000066_f3aa21af>
  40c671:	add    rsp,0x8
  40c675:	ret
	...

000000000040c680 <__swc_fn_6b1cf01f_000076_1966ae2e>:
  40c680:	sub    rsp,0x8
  40c684:	call   410430 <__swc_fn_6b1cf01f_000068_97813b89>
  40c689:	add    rsp,0x8
  40c68d:	ret
	...

000000000040c690 <__swc_fn_6b1cf01f_000079_5cc7acfc>:
  40c690:	push   rbx
  40c691:	push   rsi
  40c692:	push   rdi
  40c693:	push   r12
  40c695:	push   r13
  40c697:	push   r14
  40c699:	push   r15
  40c69b:	sub    rsp,0x20
  40c69f:	mov    rbx,r11
  40c6a2:	mov    rsi,rcx
  40c6a5:	mov    rdi,rdx
  40c6a8:	mov    r12,r8
  40c6ab:	mov    r13,r9
  40c6ae:	mov    r14,r10
  40c6b1:	mov    rcx,QWORD PTR [rip+0x1a688]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40c6b8:	test   rcx,rcx
  40c6bb:	jne    40c6cd <__swc_fn_6b1cf01f_000079_5cc7acfc+0x3d>
  40c6bd:	call   412640 <__swc_fn_6b1cf01f_000167_994c8876>
  40c6c2:	lea    rcx,[rax+0x1]
  40c6c6:	mov    QWORD PTR [rip+0x1a673],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40c6cd:	dec    rcx
  40c6d0:	call   40f580 <__swc_fn_6b1cf01f_000169_360af05d>
  40c6d5:	mov    r15,rax
  40c6d8:	lea    r11,[rip+0x17b61]        # 424240 <__swc_bss_base_6b1cf01f+0x200>
  40c6df:	mov    rcx,r11
  40c6e2:	call   40fbf0 <__swc_fn_6b1cf01f_000038_eb6108f2>
  40c6e7:	test   al,al
  40c6e9:	jne    40c6fa <__swc_fn_6b1cf01f_000079_5cc7acfc+0x6a>
  40c6eb:	mov    rcx,r11
  40c6ee:	call   407960 <__swc_fn_6b1cf01f_000036_14f56618>
  40c6f3:	lea    r11,[rip+0x17b46]        # 424240 <__swc_bss_base_6b1cf01f+0x200>
  40c6fa:	mov    rcx,r11
  40c6fd:	mov    rdx,rsi
  40c700:	mov    r8,rdi
  40c703:	mov    r9,r12
  40c706:	mov    r10,r13
  40c709:	mov    rsi,r11
  40c70c:	mov    r11,r14
  40c70f:	call   40b9b0 <__swc_fn_6b1cf01f_000037_03f1bf9a>
  40c714:	test   bl,bl
  40c716:	je     40c73d <__swc_fn_6b1cf01f_000079_5cc7acfc+0xad>
  40c718:	mov    QWORD PTR [rsp+0x8],rsi
  40c71d:	lea    rax,[rip+0x6cac]        # 4133d0 <__swc_rdata_base_6b1cf01f+0x2c0>
  40c724:	mov    QWORD PTR [rsp+0x10],rax
  40c729:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c72f:	vmovups XMMWORD PTR [r15],xmm0
  40c734:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40c73d:	mov    rax,rsi
  40c740:	add    rsp,0x20
  40c744:	pop    r15
  40c746:	pop    r14
  40c748:	pop    r13
  40c74a:	pop    r12
  40c74c:	pop    rdi
  40c74d:	pop    rsi
  40c74e:	pop    rbx
  40c74f:	ret

000000000040c750 <__swc_fn_6b1cf01f_000082_cf82995a>:
  40c750:	sub    rsp,0x8
  40c754:	mov    rax,rcx
  40c757:	test   rcx,rcx
  40c75a:	jne    40c761 <__swc_fn_6b1cf01f_000082_cf82995a+0x11>
  40c75c:	add    rsp,0x8
  40c760:	ret
  40c761:	lea    rcx,[rax-0x10]
  40c765:	mov    rax,QWORD PTR [rax-0x10]
  40c769:	mov    rdx,rax
  40c76c:	call   40d7b0 <__swc_fn_6b1cf01f_000115_ed2d8fed>
  40c771:	add    rsp,0x8
  40c775:	ret
	...

000000000040c780 <__swc_fn_6b1cf01f_000085_ef55f6e4>:
  40c780:	sub    rsp,0x8
  40c784:	xor    r11d,r11d
  40c787:	call   4106f0 <__swc_fn_6b1cf01f_000086_0d280354>
  40c78c:	add    rsp,0x8
  40c790:	ret
	...

000000000040c7a0 <__swc_fn_6b1cf01f_000088_23214800>:
  40c7a0:	push   rsi
  40c7a1:	push   rdi
  40c7a2:	push   r12
  40c7a4:	push   r13
  40c7a6:	push   r14
  40c7a8:	push   r15
  40c7aa:	sub    rsp,0x68
  40c7ae:	mov    rsi,r9
  40c7b1:	mov    rdi,rcx
  40c7b4:	mov    r12,rdx
  40c7b7:	mov    r13,r8
  40c7ba:	cmp    r8,r9
  40c7bd:	jne    40c7e5 <__swc_fn_6b1cf01f_000088_23214800+0x45>
  40c7bf:	mov    rcx,rdi
  40c7c2:	mov    rdx,r12
  40c7c5:	xor    r8d,r8d
  40c7c8:	call   410a40 <__swc_fn_6b1cf01f_000092_63c1827b>
  40c7cd:	test   al,al
  40c7cf:	je     40c7e5 <__swc_fn_6b1cf01f_000088_23214800+0x45>
  40c7d1:	mov    eax,0x1
  40c7d6:	add    rsp,0x68
  40c7da:	pop    r15
  40c7dc:	pop    r14
  40c7de:	pop    r13
  40c7e0:	pop    r12
  40c7e2:	pop    rdi
  40c7e3:	pop    rsi
  40c7e4:	ret
  40c7e5:	cmp    BYTE PTR [r12+0x2c],0xe
  40c7eb:	je     40c7fe <__swc_fn_6b1cf01f_000088_23214800+0x5e>
  40c7ed:	xor    eax,eax
  40c7ef:	add    rsp,0x68
  40c7f3:	pop    r15
  40c7f5:	pop    r14
  40c7f7:	pop    r13
  40c7f9:	pop    r12
  40c7fb:	pop    rdi
  40c7fc:	pop    rsi
  40c7fd:	ret
  40c7fe:	mov    r14,QWORD PTR [r12+0x98]
  40c806:	mov    rax,QWORD PTR [r12+0xa0]
  40c80e:	mov    r12,rax
  40c811:	xor    r15d,r15d
  40c814:	test   r12,r12
  40c817:	je     40c87f <__swc_fn_6b1cf01f_000088_23214800+0xdf>
  40c819:	nop    DWORD PTR [rax+0x0]
  40c820:	mov    QWORD PTR [rsp+0x58],r12
  40c825:	lea    r12,[r15*8+0x0]
  40c82d:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40c832:	mov    rcx,rax
  40c835:	call   408f40 <__swc_fn_6b1cf01f_000084_3953ef98>
  40c83a:	cmp    BYTE PTR [rax+0x2c],0xe
  40c83e:	jne    40c870 <__swc_fn_6b1cf01f_000088_23214800+0xd0>
  40c840:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40c845:	lea    r8,[r13+rcx*1+0x0]
  40c84a:	mov    rcx,rdi
  40c84d:	mov    rdx,rax
  40c850:	mov    r9,rsi
  40c853:	call   40c7a0 <__swc_fn_6b1cf01f_000088_23214800>
  40c858:	test   al,al
  40c85a:	je     40c870 <__swc_fn_6b1cf01f_000088_23214800+0xd0>
  40c85c:	mov    eax,0x1
  40c861:	add    rsp,0x68
  40c865:	pop    r15
  40c867:	pop    r14
  40c869:	pop    r13
  40c86b:	pop    r12
  40c86d:	pop    rdi
  40c86e:	pop    rsi
  40c86f:	ret
  40c870:	add    r15,0x1
  40c874:	mov    r12,QWORD PTR [rsp+0x58]
  40c879:	sub    r12,0x1
  40c87d:	jne    40c820 <__swc_fn_6b1cf01f_000088_23214800+0x80>
  40c87f:	xor    eax,eax
  40c881:	add    rsp,0x68
  40c885:	pop    r15
  40c887:	pop    r14
  40c889:	pop    r13
  40c88b:	pop    r12
  40c88d:	pop    rdi
  40c88e:	pop    rsi
  40c88f:	ret

000000000040c890 <__swc_fn_6b1cf01f_000091_c2567a3b>:
  40c890:	push   rbp
  40c891:	push   rbx
  40c892:	push   rsi
  40c893:	push   rdi
  40c894:	push   r12
  40c896:	push   r13
  40c898:	push   r14
  40c89a:	push   r15
  40c89c:	sub    rsp,0x38
  40c8a0:	mov    rbp,rsp
  40c8a3:	mov    rbx,r11
  40c8a6:	mov    rsi,rdx
  40c8a9:	mov    rdi,r8
  40c8ac:	mov    r12,r9
  40c8af:	mov    QWORD PTR [rsp+0x18],r9
  40c8b4:	mov    r13,r10
  40c8b7:	movzx  r14d,BYTE PTR [rbp+0x80]
  40c8bf:	movzx  r15d,BYTE PTR [rbp+0x88]
  40c8c7:	test   r11,r11
  40c8ca:	je     40c8d0 <__swc_fn_6b1cf01f_000091_c2567a3b+0x40>
  40c8cc:	xor    eax,eax
  40c8ce:	mov    BYTE PTR [rbx],al
  40c8d0:	test   r12,r12
  40c8d3:	je     40c8de <__swc_fn_6b1cf01f_000091_c2567a3b+0x4e>
  40c8d5:	mov    QWORD PTR [r12+0x8],0x0
  40c8de:	test   rcx,rcx
  40c8e1:	je     40c8e8 <__swc_fn_6b1cf01f_000091_c2567a3b+0x58>
  40c8e3:	test   rsi,rsi
  40c8e6:	jne    40c8fb <__swc_fn_6b1cf01f_000091_c2567a3b+0x6b>
  40c8e8:	xor    eax,eax
  40c8ea:	add    rsp,0x38
  40c8ee:	pop    r15
  40c8f0:	pop    r14
  40c8f2:	pop    r13
  40c8f4:	pop    r12
  40c8f6:	pop    rdi
  40c8f7:	pop    rsi
  40c8f8:	pop    rbx
  40c8f9:	pop    rbp
  40c8fa:	ret
  40c8fb:	call   408f40 <__swc_fn_6b1cf01f_000084_3953ef98>
  40c900:	mov    r12,rax
  40c903:	mov    al,r15b
  40c906:	test   r15b,r15b
  40c909:	jne    40c919 <__swc_fn_6b1cf01f_000091_c2567a3b+0x89>
  40c90b:	mov    eax,DWORD PTR [r12+0x28]
  40c910:	and    eax,0x10000
  40c916:	setne  al
  40c919:	lea    r15,[rsp+0x8]
  40c91e:	mov    QWORD PTR [rsp+0x20],r15
  40c923:	rex mov BYTE PTR [rsp+0x8],al
  40c928:	test   DWORD PTR [rsi+0x28],0x400000
  40c92f:	je     40c967 <__swc_fn_6b1cf01f_000091_c2567a3b+0xd7>
  40c931:	test   rsi,rsi
  40c934:	je     40c954 <__swc_fn_6b1cf01f_000091_c2567a3b+0xc4>
  40c936:	mov    rax,QWORD PTR [rsi+0x38]
  40c93a:	cmp    QWORD PTR [rax+0x10],rsi
  40c93e:	jne    40c954 <__swc_fn_6b1cf01f_000091_c2567a3b+0xc4>
  40c940:	rex mov al,BYTE PTR [rsp+0x8]
  40c945:	test   al,al
  40c947:	sete   al
  40c94a:	test   r14b,r14b
  40c94d:	sete   cl
  40c950:	test   al,cl
  40c952:	je     40c967 <__swc_fn_6b1cf01f_000091_c2567a3b+0xd7>
  40c954:	xor    eax,eax
  40c956:	add    rsp,0x38
  40c95a:	pop    r15
  40c95c:	pop    r14
  40c95e:	pop    r13
  40c960:	pop    r12
  40c962:	pop    rdi
  40c963:	pop    rsi
  40c964:	pop    rbx
  40c965:	pop    rbp
  40c966:	ret
  40c967:	mov    r15,r12
  40c96a:	test   r14b,r14b
  40c96d:	jne    40c984 <__swc_fn_6b1cf01f_000091_c2567a3b+0xf4>
  40c96f:	cmp    BYTE PTR [r12+0x2c],0x6
  40c975:	jne    40c984 <__swc_fn_6b1cf01f_000091_c2567a3b+0xf4>
  40c977:	mov    rcx,QWORD PTR [r12+0x40]
  40c97c:	call   408f40 <__swc_fn_6b1cf01f_000084_3953ef98>
  40c981:	mov    r15,rax
  40c984:	test   r14b,r14b
  40c987:	je     40c98d <__swc_fn_6b1cf01f_000091_c2567a3b+0xfd>
  40c989:	mov    r15,QWORD PTR [r15+0x30]
  40c98d:	mov    rcx,rsi
  40c990:	call   408f40 <__swc_fn_6b1cf01f_000084_3953ef98>
  40c995:	mov    rsi,rax
  40c998:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40c99d:	je     40c9d4 <__swc_fn_6b1cf01f_000091_c2567a3b+0x144>
  40c99f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40c9a4:	je     40c9d4 <__swc_fn_6b1cf01f_000091_c2567a3b+0x144>
  40c9a6:	mov    eax,DWORD PTR [rsi+0x28]
  40c9a9:	and    eax,0x10000
  40c9af:	je     40c9d4 <__swc_fn_6b1cf01f_000091_c2567a3b+0x144>
  40c9b1:	rex mov al,BYTE PTR [rsp+0x8]
  40c9b6:	test   al,al
  40c9b8:	jne    40c9cd <__swc_fn_6b1cf01f_000091_c2567a3b+0x13d>
  40c9ba:	xor    eax,eax
  40c9bc:	add    rsp,0x38
  40c9c0:	pop    r15
  40c9c2:	pop    r14
  40c9c4:	pop    r13
  40c9c6:	pop    r12
  40c9c8:	pop    rdi
  40c9c9:	pop    rsi
  40c9ca:	pop    rbx
  40c9cb:	pop    rbp
  40c9cc:	ret
  40c9cd:	mov    rax,QWORD PTR [rsi+0x30]
  40c9d1:	mov    rsi,rax
  40c9d4:	mov    r14b,r13b
  40c9d7:	test   rbx,rbx
  40c9da:	je     40ca10 <__swc_fn_6b1cf01f_000091_c2567a3b+0x180>
  40c9dc:	cmp    BYTE PTR [r12+0x2c],0x6
  40c9e2:	jne    40ca10 <__swc_fn_6b1cf01f_000091_c2567a3b+0x180>
  40c9e4:	lea    rdx,[rip+0x6a15]        # 413400 <__swc_rdata_base_6b1cf01f+0x2f0>
  40c9eb:	mov    rcx,rsi
  40c9ee:	xor    r8d,r8d
  40c9f1:	call   410a40 <__swc_fn_6b1cf01f_000092_63c1827b>
  40c9f6:	test   al,al
  40c9f8:	je     40ca10 <__swc_fn_6b1cf01f_000091_c2567a3b+0x180>
  40c9fa:	mov    BYTE PTR [rbx],0x1
  40c9fd:	xor    eax,eax
  40c9ff:	add    rsp,0x38
  40ca03:	pop    r15
  40ca05:	pop    r14
  40ca07:	pop    r13
  40ca09:	pop    r12
  40ca0b:	pop    rdi
  40ca0c:	pop    rsi
  40ca0d:	pop    rbx
  40ca0e:	pop    rbp
  40ca0f:	ret
  40ca10:	test   rdi,rdi
  40ca13:	jne    40ca2d <__swc_fn_6b1cf01f_000091_c2567a3b+0x19d>
  40ca15:	test   r13b,r13b
  40ca18:	jne    40ca2d <__swc_fn_6b1cf01f_000091_c2567a3b+0x19d>
  40ca1a:	xor    eax,eax
  40ca1c:	add    rsp,0x38
  40ca20:	pop    r15
  40ca22:	pop    r14
  40ca24:	pop    r13
  40ca26:	pop    r12
  40ca28:	pop    rdi
  40ca29:	pop    rsi
  40ca2a:	pop    rbx
  40ca2b:	pop    rbp
  40ca2c:	ret
  40ca2d:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40ca32:	jne    40cae8 <__swc_fn_6b1cf01f_000091_c2567a3b+0x258>
  40ca38:	mov    rcx,r15
  40ca3b:	mov    rdx,rsi
  40ca3e:	xor    r8d,r8d
  40ca41:	call   410a40 <__swc_fn_6b1cf01f_000092_63c1827b>
  40ca46:	test   al,al
  40ca48:	jne    40cae8 <__swc_fn_6b1cf01f_000091_c2567a3b+0x258>
  40ca4e:	test   DWORD PTR [rsi+0x28],0x10000
  40ca55:	je     40ca73 <__swc_fn_6b1cf01f_000091_c2567a3b+0x1e3>
  40ca57:	rex mov al,BYTE PTR [rsp+0x8]
  40ca5c:	test   al,al
  40ca5e:	jne    40ca73 <__swc_fn_6b1cf01f_000091_c2567a3b+0x1e3>
  40ca60:	xor    eax,eax
  40ca62:	add    rsp,0x38
  40ca66:	pop    r15
  40ca68:	pop    r14
  40ca6a:	pop    r13
  40ca6c:	pop    r12
  40ca6e:	pop    rdi
  40ca6f:	pop    rsi
  40ca70:	pop    rbx
  40ca71:	pop    rbp
  40ca72:	ret
  40ca73:	test   rdi,rdi
  40ca76:	jne    40ca8b <__swc_fn_6b1cf01f_000091_c2567a3b+0x1fb>
  40ca78:	xor    eax,eax
  40ca7a:	add    rsp,0x38
  40ca7e:	pop    r15
  40ca80:	pop    r14
  40ca82:	pop    r13
  40ca84:	pop    r12
  40ca86:	pop    rdi
  40ca87:	pop    rsi
  40ca88:	pop    rbx
  40ca89:	pop    rbp
  40ca8a:	ret
  40ca8b:	mov    rcx,QWORD PTR [rsi+0x40]
  40ca8f:	call   408f40 <__swc_fn_6b1cf01f_000084_3953ef98>
  40ca94:	mov    rsi,rax
  40ca97:	mov    rax,QWORD PTR [rdi]
  40ca9a:	mov    rdi,rax
  40ca9d:	test   rax,rax
  40caa0:	jne    40cae3 <__swc_fn_6b1cf01f_000091_c2567a3b+0x253>
  40caa2:	test   rbx,rbx
  40caa5:	je     40cae3 <__swc_fn_6b1cf01f_000091_c2567a3b+0x253>
  40caa7:	mov    rcx,r15
  40caaa:	mov    rdx,rsi
  40caad:	xor    r8d,r8d
  40cab0:	call   410a40 <__swc_fn_6b1cf01f_000092_63c1827b>
  40cab5:	mov    rcx,rax
  40cab8:	test   al,al
  40caba:	jne    40cadc <__swc_fn_6b1cf01f_000091_c2567a3b+0x24c>
  40cabc:	mov    rcx,r15
  40cabf:	mov    rdx,rsi
  40cac2:	call   408f80 <__swc_fn_6b1cf01f_000087_d182c4dc>
  40cac7:	mov    rcx,rax
  40caca:	test   al,al
  40cacc:	jne    40cadc <__swc_fn_6b1cf01f_000091_c2567a3b+0x24c>
  40cace:	mov    rcx,rsi
  40cad1:	mov    rdx,r15
  40cad4:	call   408f80 <__swc_fn_6b1cf01f_000087_d182c4dc>
  40cad9:	mov    rcx,rax
  40cadc:	test   cl,cl
  40cade:	setne  al
  40cae1:	mov    BYTE PTR [rbx],al
  40cae3:	xor    eax,eax
  40cae5:	mov    r14b,al
  40cae8:	test   rdi,rdi
  40caeb:	jne    40cb05 <__swc_fn_6b1cf01f_000091_c2567a3b+0x275>
  40caed:	test   r14b,r14b
  40caf0:	jne    40cb05 <__swc_fn_6b1cf01f_000091_c2567a3b+0x275>
  40caf2:	xor    eax,eax
  40caf4:	add    rsp,0x38
  40caf8:	pop    r15
  40cafa:	pop    r14
  40cafc:	pop    r13
  40cafe:	pop    r12
  40cb00:	pop    rdi
  40cb01:	pop    rsi
  40cb02:	pop    rbx
  40cb03:	pop    rbp
  40cb04:	ret
  40cb05:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40cb0a:	je     40cb16 <__swc_fn_6b1cf01f_000091_c2567a3b+0x286>
  40cb0c:	mov    r12,QWORD PTR [rsp+0x18]
  40cb11:	jmp    40cb9e <__swc_fn_6b1cf01f_000091_c2567a3b+0x30e>
  40cb16:	mov    r12,QWORD PTR [rsp+0x18]
  40cb1b:	test   r12,r12
  40cb1e:	jne    40cb32 <__swc_fn_6b1cf01f_000091_c2567a3b+0x2a2>
  40cb20:	mov    rcx,r15
  40cb23:	mov    rdx,rsi
  40cb26:	xor    r8d,r8d
  40cb29:	call   410a40 <__swc_fn_6b1cf01f_000092_63c1827b>
  40cb2e:	test   al,al
  40cb30:	jne    40cb9e <__swc_fn_6b1cf01f_000091_c2567a3b+0x30e>
  40cb32:	test   DWORD PTR [rsi+0x28],0x10000
  40cb39:	je     40cb57 <__swc_fn_6b1cf01f_000091_c2567a3b+0x2c7>
  40cb3b:	rex mov al,BYTE PTR [rsp+0x8]
  40cb40:	test   al,al
  40cb42:	jne    40cb57 <__swc_fn_6b1cf01f_000091_c2567a3b+0x2c7>
  40cb44:	xor    eax,eax
  40cb46:	add    rsp,0x38
  40cb4a:	pop    r15
  40cb4c:	pop    r14
  40cb4e:	pop    r13
  40cb50:	pop    r12
  40cb52:	pop    rdi
  40cb53:	pop    rsi
  40cb54:	pop    rbx
  40cb55:	pop    rbp
  40cb56:	ret
  40cb57:	test   rdi,rdi
  40cb5a:	jne    40cb6f <__swc_fn_6b1cf01f_000091_c2567a3b+0x2df>
  40cb5c:	xor    eax,eax
  40cb5e:	add    rsp,0x38
  40cb62:	pop    r15
  40cb64:	pop    r14
  40cb66:	pop    r13
  40cb68:	pop    r12
  40cb6a:	pop    rdi
  40cb6b:	pop    rsi
  40cb6c:	pop    rbx
  40cb6d:	pop    rbp
  40cb6e:	ret
  40cb6f:	cmp    QWORD PTR [rdi+0x8],0x0
  40cb74:	jne    40cb89 <__swc_fn_6b1cf01f_000091_c2567a3b+0x2f9>
  40cb76:	xor    eax,eax
  40cb78:	add    rsp,0x38
  40cb7c:	pop    r15
  40cb7e:	pop    r14
  40cb80:	pop    r13
  40cb82:	pop    r12
  40cb84:	pop    rdi
  40cb85:	pop    rsi
  40cb86:	pop    rbx
  40cb87:	pop    rbp
  40cb88:	ret
  40cb89:	mov    rax,QWORD PTR [rdi+0x8]
  40cb8d:	mov    rax,QWORD PTR [rax]
  40cb90:	mov    rsi,rax
  40cb93:	mov    rdi,QWORD PTR [rdi]
  40cb96:	mov    eax,0x1
  40cb9b:	mov    r14b,al
  40cb9e:	test   rdi,rdi
  40cba1:	mov    rbx,QWORD PTR [rsp+0x20]
  40cba6:	jne    40cbf0 <__swc_fn_6b1cf01f_000091_c2567a3b+0x360>
  40cba8:	test   r14b,r14b
  40cbab:	je     40cbdd <__swc_fn_6b1cf01f_000091_c2567a3b+0x34d>
  40cbad:	test   r12,r12
  40cbb0:	je     40cbdd <__swc_fn_6b1cf01f_000091_c2567a3b+0x34d>
  40cbb2:	mov    rcx,r15
  40cbb5:	mov    rdx,rsi
  40cbb8:	xor    r8d,r8d
  40cbbb:	mov    r9,r12
  40cbbe:	mov    rbx,QWORD PTR [rsp+0x20]
  40cbc3:	movzx  r10d,BYTE PTR [rbx]
  40cbc7:	call   40c780 <__swc_fn_6b1cf01f_000085_ef55f6e4>
  40cbcc:	add    rsp,0x38
  40cbd0:	pop    r15
  40cbd2:	pop    r14
  40cbd4:	pop    r13
  40cbd6:	pop    r12
  40cbd8:	pop    rdi
  40cbd9:	pop    rsi
  40cbda:	pop    rbx
  40cbdb:	pop    rbp
  40cbdc:	ret
  40cbdd:	xor    eax,eax
  40cbdf:	add    rsp,0x38
  40cbe3:	pop    r15
  40cbe5:	pop    r14
  40cbe7:	pop    r13
  40cbe9:	pop    r12
  40cbeb:	pop    rdi
  40cbec:	pop    rsi
  40cbed:	pop    rbx
  40cbee:	pop    rbp
  40cbef:	ret
  40cbf0:	mov    r13,rsi
  40cbf3:	mov    QWORD PTR [rsp+0x28],rdi
  40cbf8:	cmp    BYTE PTR [r15+0x2c],0xe
  40cbfd:	sete   al
  40cc00:	mov    r14b,al
  40cc03:	jne    40cc17 <__swc_fn_6b1cf01f_000091_c2567a3b+0x387>
  40cc05:	mov    rcx,rsi
  40cc08:	mov    rdx,r15
  40cc0b:	call   408f80 <__swc_fn_6b1cf01f_000087_d182c4dc>
  40cc10:	mov    r14b,al
  40cc13:	test   al,al
  40cc15:	jne    40cc4c <__swc_fn_6b1cf01f_000091_c2567a3b+0x3bc>
  40cc17:	cmp    BYTE PTR [r15+0x2c],0x12
  40cc1c:	je     40cc4c <__swc_fn_6b1cf01f_000091_c2567a3b+0x3bc>
  40cc1e:	mov    rcx,r15
  40cc21:	mov    rdx,rsi
  40cc24:	mov    r8,rdi
  40cc27:	mov    r9,r12
  40cc2a:	mov    rax,rbx
  40cc2d:	movzx  r10d,BYTE PTR [rax]
  40cc31:	call   40c780 <__swc_fn_6b1cf01f_000085_ef55f6e4>
  40cc36:	test   rax,rax
  40cc39:	je     40cc4c <__swc_fn_6b1cf01f_000091_c2567a3b+0x3bc>
  40cc3b:	add    rsp,0x38
  40cc3f:	pop    r15
  40cc41:	pop    r14
  40cc43:	pop    r13
  40cc45:	pop    r12
  40cc47:	pop    rdi
  40cc48:	pop    rsi
  40cc49:	pop    rbx
  40cc4a:	pop    rbp
  40cc4b:	ret
  40cc4c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40cc51:	jne    40cc70 <__swc_fn_6b1cf01f_000091_c2567a3b+0x3e0>
  40cc53:	mov    rax,QWORD PTR [rsi+0xd8]
  40cc5a:	test   rax,rax
  40cc5d:	je     40cc70 <__swc_fn_6b1cf01f_000091_c2567a3b+0x3e0>
  40cc5f:	add    rdi,QWORD PTR [rax+0x8]
  40cc63:	mov    rax,QWORD PTR [rdi]
  40cc66:	sub    rdi,QWORD PTR [rax+0x8]
  40cc6a:	mov    rax,QWORD PTR [rax]
  40cc6d:	mov    rsi,rax
  40cc70:	test   r14b,r14b
  40cc73:	je     40cc9f <__swc_fn_6b1cf01f_000091_c2567a3b+0x40f>
  40cc75:	mov    rcx,r15
  40cc78:	mov    rdx,rsi
  40cc7b:	mov    r8,rdi
  40cc7e:	mov    r9,r13
  40cc81:	mov    r14,QWORD PTR [rsp+0x28]
  40cc86:	mov    r10,r14
  40cc89:	call   410920 <__swc_fn_6b1cf01f_000089_c1c9085b>
  40cc8e:	add    rsp,0x38
  40cc92:	pop    r15
  40cc94:	pop    r14
  40cc96:	pop    r13
  40cc98:	pop    r12
  40cc9a:	pop    rdi
  40cc9b:	pop    rsi
  40cc9c:	pop    rbx
  40cc9d:	pop    rbp
  40cc9e:	ret
  40cc9f:	mov    rcx,r15
  40cca2:	mov    rdx,rsi
  40cca5:	mov    r8,rdi
  40cca8:	mov    r9,r12
  40ccab:	movzx  r10d,BYTE PTR [rbx]
  40ccaf:	call   40c780 <__swc_fn_6b1cf01f_000085_ef55f6e4>
  40ccb4:	add    rsp,0x38
  40ccb8:	pop    r15
  40ccba:	pop    r14
  40ccbc:	pop    r13
  40ccbe:	pop    r12
  40ccc0:	pop    rdi
  40ccc1:	pop    rsi
  40ccc2:	pop    rbx
  40ccc3:	pop    rbp
  40ccc4:	ret
	...

000000000040ccd0 <__swc_fn_6b1cf01f_000094_93bfe675>:
  40ccd0:	push   rbx
  40ccd1:	push   rsi
  40ccd2:	sub    rsp,0x18
  40ccd6:	mov    rbx,rcx
  40ccd9:	mov    rcx,QWORD PTR [rip+0x1a060]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40cce0:	test   rcx,rcx
  40cce3:	jne    40ccf5 <__swc_fn_6b1cf01f_000094_93bfe675+0x25>
  40cce5:	call   412640 <__swc_fn_6b1cf01f_000167_994c8876>
  40ccea:	lea    rcx,[rax+0x1]
  40ccee:	mov    QWORD PTR [rip+0x1a04b],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40ccf5:	dec    rcx
  40ccf8:	call   40f580 <__swc_fn_6b1cf01f_000169_360af05d>
  40ccfd:	mov    rsi,rax
  40cd00:	mov    rax,QWORD PTR [rsi+0x8]
  40cd04:	test   rax,rax
  40cd07:	jne    40cd57 <__swc_fn_6b1cf01f_000094_93bfe675+0x87>
  40cd09:	call   409070 <__swc_fn_6b1cf01f_000093_ad13d15c>
  40cd0e:	test   al,al
  40cd10:	jne    40cd57 <__swc_fn_6b1cf01f_000094_93bfe675+0x87>
  40cd12:	lea    rdx,[rip+0x17527]        # 424240 <__swc_bss_base_6b1cf01f+0x200>
  40cd19:	mov    rcx,rdx
  40cd1c:	call   40fbf0 <__swc_fn_6b1cf01f_000038_eb6108f2>
  40cd21:	test   al,al
  40cd23:	jne    40cd34 <__swc_fn_6b1cf01f_000094_93bfe675+0x64>
  40cd25:	mov    rcx,rdx
  40cd28:	call   407960 <__swc_fn_6b1cf01f_000036_14f56618>
  40cd2d:	lea    rdx,[rip+0x1750c]        # 424240 <__swc_bss_base_6b1cf01f+0x200>
  40cd34:	mov    QWORD PTR [rsp+0x8],rdx
  40cd39:	lea    rax,[rip+0x6690]        # 4133d0 <__swc_rdata_base_6b1cf01f+0x2c0>
  40cd40:	mov    QWORD PTR [rsp+0x10],rax
  40cd45:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40cd4b:	vmovups XMMWORD PTR [rsi],xmm0
  40cd4f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40cd57:	vmovups xmm0,XMMWORD PTR [rsi]
  40cd5b:	vmovups XMMWORD PTR [rbx],xmm0
  40cd5f:	mov    rax,rbx
  40cd62:	add    rsp,0x18
  40cd66:	pop    rsi
  40cd67:	pop    rbx
  40cd68:	ret
  40cd69:	add    BYTE PTR [rax],al
  40cd6b:	add    BYTE PTR [rax],al
  40cd6d:	add    BYTE PTR [rax],al
	...

000000000040cd70 <__swc_fn_6b1cf01f_000097_65137b72>:
  40cd70:	sub    rsp,0x8
  40cd74:	call   4117e0 <__swc_fn_6b1cf01f_000119_0a5fa85a>
  40cd79:	add    rsp,0x8
  40cd7d:	ret
	...

000000000040cd80 <__swc_fn_6b1cf01f_000100_e34f54dc>:
  40cd80:	push   rbx
  40cd81:	push   rsi
  40cd82:	sub    rsp,0x28
  40cd86:	mov    rbx,rcx
  40cd89:	xor    esi,esi
  40cd8b:	jmp    40cda0 <__swc_fn_6b1cf01f_000100_e34f54dc+0x20>
  40cd8d:	nop    DWORD PTR [rax]
  40cd90:	mov    QWORD PTR [rbx+0x28],rsi
  40cd94:	mov    rsi,rbx
  40cd97:	mov    rbx,rax
  40cd9a:	nop    WORD PTR [rax+rax*1+0x0]
  40cda0:	test   rbx,rbx
  40cda3:	je     40ce03 <__swc_fn_6b1cf01f_000100_e34f54dc+0x83>
  40cda5:	mov    rcx,rbx
  40cda8:	mov    edx,0x1
  40cdad:	call   4106a0 <__swc_fn_6b1cf01f_000080_63a67586>
  40cdb2:	cmp    rax,0x1
  40cdb6:	jne    40ce03 <__swc_fn_6b1cf01f_000100_e34f54dc+0x83>
  40cdb8:	mov    r10,QWORD PTR [rbx+0x18]
  40cdbc:	mov    rcx,r10
  40cdbf:	mov    edx,0x1
  40cdc4:	call   4106a0 <__swc_fn_6b1cf01f_000080_63a67586>
  40cdc9:	cmp    rax,0x1
  40cdcd:	jne    40cddc <__swc_fn_6b1cf01f_000100_e34f54dc+0x5c>
  40cdcf:	mov    rcx,r10
  40cdd2:	call   409210 <__swc_fn_6b1cf01f_000099_d0b19c14>
  40cdd7:	test   rax,rax
  40cdda:	jne    40cd90 <__swc_fn_6b1cf01f_000100_e34f54dc+0x10>
  40cddc:	mov    rax,QWORD PTR [rbx+0x20]
  40cde0:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40cde5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40cdeb:	lea    rcx,[rsp+0x8]
  40cdf0:	mov    rdx,rbx
  40cdf3:	mov    r8d,0x30
  40cdf9:	mov    rbx,rax
  40cdfc:	call   410e00 <__swc_fn_6b1cf01f_000098_d4bdcaa4>
  40ce01:	jmp    40cda0 <__swc_fn_6b1cf01f_000100_e34f54dc+0x20>
  40ce03:	test   rsi,rsi
  40ce06:	jne    40ce0f <__swc_fn_6b1cf01f_000100_e34f54dc+0x8f>
  40ce08:	add    rsp,0x28
  40ce0c:	pop    rsi
  40ce0d:	pop    rbx
  40ce0e:	ret
  40ce0f:	mov    rax,rsi
  40ce12:	mov    rsi,QWORD PTR [rsi+0x28]
  40ce16:	mov    rbx,QWORD PTR [rax+0x20]
  40ce1a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40ce1f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40ce25:	lea    rcx,[rsp+0x18]
  40ce2a:	mov    rdx,rax
  40ce2d:	mov    r8d,0x30
  40ce33:	call   410e00 <__swc_fn_6b1cf01f_000098_d4bdcaa4>
  40ce38:	jmp    40cda0 <__swc_fn_6b1cf01f_000100_e34f54dc+0x20>
  40ce3d:	add    BYTE PTR [rax],al
	...

000000000040ce40 <__swc_fn_6b1cf01f_000103_5a85fcf5>:
  40ce40:	push   rbx
  40ce41:	push   rsi
  40ce42:	push   rdi
  40ce43:	push   r12
  40ce45:	push   r13
  40ce47:	sub    rsp,0x20
  40ce4b:	mov    rbx,rcx
  40ce4e:	lea    rsi,[rcx+0x6f8]
  40ce55:	mov    edi,0x4
  40ce5a:	mov    r12,rsi
  40ce5d:	test   rdi,rdi
  40ce60:	je     40ceaa <__swc_fn_6b1cf01f_000103_5a85fcf5+0x6a>
  40ce62:	cs nop WORD PTR [rax+rax*1+0x0]
  40ce6c:	nop    DWORD PTR [rax+0x0]
  40ce70:	mov    rcx,QWORD PTR [r12+0x10]
  40ce75:	mov    QWORD PTR [r12+0x10],0x0
  40ce7e:	vxorps xmm0,xmm0,xmm0
  40ce82:	vmovups XMMWORD PTR [r12],xmm0
  40ce88:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40ce8f:	mov    DWORD PTR [r12+0x20],0x0
  40ce98:	call   410e50 <__swc_fn_6b1cf01f_000101_2fdd2c61>
  40ce9d:	add    r12,0x90
  40cea4:	sub    rdi,0x1
  40cea8:	jne    40ce70 <__swc_fn_6b1cf01f_000103_5a85fcf5+0x30>
  40ceaa:	mov    rax,QWORD PTR [rbx+0x938]
  40ceb1:	mov    rdi,rax
  40ceb4:	test   rdi,rdi
  40ceb7:	je     40cf11 <__swc_fn_6b1cf01f_000103_5a85fcf5+0xd1>
  40ceb9:	nop    DWORD PTR [rax+0x0]
  40cec0:	mov    r12d,0x10
  40cec6:	lea    r13,[rdi+0x18]
  40ceca:	test   r12,r12
  40cecd:	je     40cf06 <__swc_fn_6b1cf01f_000103_5a85fcf5+0xc6>
  40cecf:	nop
  40ced0:	mov    rcx,QWORD PTR [r13+0x10]
  40ced4:	mov    QWORD PTR [r13+0x10],0x0
  40cedc:	vxorps xmm0,xmm0,xmm0
  40cee0:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40cee6:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40ceec:	mov    DWORD PTR [r13+0x20],0x0
  40cef4:	call   410e50 <__swc_fn_6b1cf01f_000101_2fdd2c61>
  40cef9:	add    r13,0x90
  40cf00:	sub    r12,0x1
  40cf04:	jne    40ced0 <__swc_fn_6b1cf01f_000103_5a85fcf5+0x90>
  40cf06:	mov    rax,QWORD PTR [rdi]
  40cf09:	mov    rdi,rax
  40cf0c:	test   rax,rax
  40cf0f:	jne    40cec0 <__swc_fn_6b1cf01f_000103_5a85fcf5+0x80>
  40cf11:	vxorps xmm0,xmm0,xmm0
  40cf15:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40cf1d:	mov    DWORD PTR [rbx+0x9b0],0x0
  40cf27:	mov    DWORD PTR [rbx+0x9a8],0x0
  40cf31:	mov    edi,0x4
  40cf36:	mov    r12,rsi
  40cf39:	lea    rsi,[rsi+0x38]
  40cf3d:	test   rdi,rdi
  40cf40:	je     40cf6c <__swc_fn_6b1cf01f_000103_5a85fcf5+0x12c>
  40cf42:	cs nop WORD PTR [rax+rax*1+0x0]
  40cf4c:	nop    DWORD PTR [rax+0x0]
  40cf50:	mov    rcx,rsi
  40cf53:	call   40a090 <__swc_fn_6b1cf01f_000159_13ead2ff>
  40cf58:	add    rsi,0x90
  40cf5f:	add    r12,0x90
  40cf66:	sub    rdi,0x1
  40cf6a:	jne    40cf50 <__swc_fn_6b1cf01f_000103_5a85fcf5+0x110>
  40cf6c:	mov    rax,QWORD PTR [rbx+0x938]
  40cf73:	mov    rdi,rax
  40cf76:	mov    QWORD PTR [rbx+0x938],0x0
  40cf81:	test   rdi,rdi
  40cf84:	je     40cff5 <__swc_fn_6b1cf01f_000103_5a85fcf5+0x1b5>
  40cf8a:	nop    WORD PTR [rax+rax*1+0x0]
  40cf90:	mov    esi,0x10
  40cf95:	lea    r12,[rdi+0x18]
  40cf99:	lea    r13,[rdi+0x50]
  40cf9d:	test   rsi,rsi
  40cfa0:	je     40cfcc <__swc_fn_6b1cf01f_000103_5a85fcf5+0x18c>
  40cfa2:	cs nop WORD PTR [rax+rax*1+0x0]
  40cfac:	nop    DWORD PTR [rax+0x0]
  40cfb0:	mov    rcx,r13
  40cfb3:	call   40a090 <__swc_fn_6b1cf01f_000159_13ead2ff>
  40cfb8:	add    r13,0x90
  40cfbf:	add    r12,0x90
  40cfc6:	sub    rsi,0x1
  40cfca:	jne    40cfb0 <__swc_fn_6b1cf01f_000103_5a85fcf5+0x170>
  40cfcc:	mov    rax,QWORD PTR [rdi]
  40cfcf:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40cfd4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40cfda:	lea    rcx,[rsp+0x8]
  40cfdf:	mov    rdx,rdi
  40cfe2:	mov    r8d,0x918
  40cfe8:	mov    rdi,rax
  40cfeb:	call   410e00 <__swc_fn_6b1cf01f_000098_d4bdcaa4>
  40cff0:	test   rdi,rdi
  40cff3:	jne    40cf90 <__swc_fn_6b1cf01f_000103_5a85fcf5+0x150>
  40cff5:	lea    rcx,[rbx+0x68]
  40cff9:	call   40a090 <__swc_fn_6b1cf01f_000159_13ead2ff>
  40cffe:	add    rsp,0x20
  40d002:	pop    r13
  40d004:	pop    r12
  40d006:	pop    rdi
  40d007:	pop    rsi
  40d008:	pop    rbx
  40d009:	ret
  40d00a:	add    BYTE PTR [rax],al
  40d00c:	add    BYTE PTR [rax],al
	...

000000000040d010 <__swc_fn_6b1cf01f_000106_c51c3158>:
  40d010:	xor    eax,eax
  40d012:	cs nop WORD PTR [rax+rax*1+0x0]
  40d01c:	nop    DWORD PTR [rax+0x0]
  40d020:	mov    r9,r8
  40d023:	sub    r9,rax
  40d026:	cmp    r9,0x40
  40d02a:	jb     40d068 <__swc_fn_6b1cf01f_000106_c51c3158+0x58>
  40d02c:	lea    r9,[rcx+rax*1]
  40d030:	lea    r10,[rdx+rax*1]
  40d034:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40d03a:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40d040:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40d046:	vmovups xmm3,XMMWORD PTR [r10]
  40d04b:	vmovups XMMWORD PTR [r9],xmm3
  40d050:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40d056:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40d05c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40d062:	lea    rax,[rax+0x40]
  40d066:	jmp    40d020 <__swc_fn_6b1cf01f_000106_c51c3158+0x10>
  40d068:	nop    DWORD PTR [rax+rax*1+0x0]
  40d070:	mov    r9,r8
  40d073:	sub    r9,rax
  40d076:	cmp    r9,0x10
  40d07a:	jb     40d094 <__swc_fn_6b1cf01f_000106_c51c3158+0x84>
  40d07c:	lea    r9,[rdx+rax*1]
  40d080:	lea    r10,[rcx+rax*1]
  40d084:	vmovups xmm0,XMMWORD PTR [r9]
  40d089:	vmovups XMMWORD PTR [r10],xmm0
  40d08e:	lea    rax,[rax+0x10]
  40d092:	jmp    40d070 <__swc_fn_6b1cf01f_000106_c51c3158+0x60>
  40d094:	cs nop WORD PTR [rax+rax*1+0x0]
  40d09e:	xchg   ax,ax
  40d0a0:	mov    r9,r8
  40d0a3:	sub    r9,rax
  40d0a6:	cmp    r9,0x8
  40d0aa:	jb     40d0bd <__swc_fn_6b1cf01f_000106_c51c3158+0xad>
  40d0ac:	lea    r9,[rcx+rax*1]
  40d0b0:	mov    r10,QWORD PTR [rdx+rax*1]
  40d0b4:	mov    QWORD PTR [r9],r10
  40d0b7:	lea    rax,[rax+0x8]
  40d0bb:	jmp    40d0a0 <__swc_fn_6b1cf01f_000106_c51c3158+0x90>
  40d0bd:	cmp    rax,r8
  40d0c0:	jae    40d0e0 <__swc_fn_6b1cf01f_000106_c51c3158+0xd0>
  40d0c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40d0cc:	nop    DWORD PTR [rax+0x0]
  40d0d0:	mov    r9b,BYTE PTR [rdx+rax*1]
  40d0d4:	mov    BYTE PTR [rcx+rax*1],r9b
  40d0d8:	inc    rax
  40d0db:	cmp    rax,r8
  40d0de:	jb     40d0d0 <__swc_fn_6b1cf01f_000106_c51c3158+0xc0>
  40d0e0:	ret
	...

000000000040d0f0 <__swc_fn_6b1cf01f_000109_6814119b>:
  40d0f0:	push   rbx
  40d0f1:	push   r12
  40d0f3:	push   rdi
  40d0f4:	push   rsi
  40d0f5:	push   r13
  40d0f7:	push   r14
  40d0f9:	push   r15
  40d0fb:	sub    rsp,0x170
  40d102:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40d10b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40d114:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40d11d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40d126:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40d12f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40d138:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40d141:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40d14a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40d153:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40d15c:	mov    ebx,edx
  40d15e:	mov    QWORD PTR [rsp+0xa8],rbx
  40d166:	mov    r12d,ecx
  40d169:	test   edx,edx
  40d16b:	jne    40d182 <__swc_fn_6b1cf01f_000109_6814119b+0x92>
  40d16d:	xor    eax,eax
  40d16f:	add    rsp,0x170
  40d176:	pop    r15
  40d178:	pop    r14
  40d17a:	pop    r13
  40d17c:	pop    rsi
  40d17d:	pop    rdi
  40d17e:	pop    r12
  40d180:	pop    rbx
  40d181:	ret
  40d182:	lea    rdi,[rip+0x654f]        # 4136d8 <__swc_rdata_base_6b1cf01f+0x5c8>
  40d189:	mov    esi,0x90000
  40d18e:	xor    eax,eax
  40d190:	call   4070b0 <open@plt>
  40d195:	mov    r13,rax
  40d198:	mov    QWORD PTR [rsp+0xb0],rax
  40d1a0:	test   eax,eax
  40d1a2:	jge    40d1ab <__swc_fn_6b1cf01f_000109_6814119b+0xbb>
  40d1a4:	xor    eax,eax
  40d1a6:	jmp    40d6a6 <__swc_fn_6b1cf01f_000109_6814119b+0x5b6>
  40d1ab:	nop    DWORD PTR [rax+rax*1+0x0]
  40d1b0:	movsxd rdi,r13d
  40d1b3:	mov    esi,0x2
  40d1b8:	xor    eax,eax
  40d1ba:	call   4070c0 <flock@plt>
  40d1bf:	test   eax,eax
  40d1c1:	je     40d1e0 <__swc_fn_6b1cf01f_000109_6814119b+0xf0>
  40d1c3:	xor    eax,eax
  40d1c5:	call   4070d0 <__errno_location@plt>
  40d1ca:	cmp    DWORD PTR [rax],0x4
  40d1cd:	je     40d1b0 <__swc_fn_6b1cf01f_000109_6814119b+0xc0>
  40d1cf:	movsxd rdi,r13d
  40d1d2:	xor    eax,eax
  40d1d4:	call   4070e0 <close@plt>
  40d1d9:	xor    eax,eax
  40d1db:	jmp    40d6a6 <__swc_fn_6b1cf01f_000109_6814119b+0x5b6>
  40d1e0:	lea    r14,[rsp+0x8]
  40d1e5:	mov    QWORD PTR [rsp+0xb8],r14
  40d1ed:	vxorps xmm0,xmm0,xmm0
  40d1f1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40d1f7:	mov    QWORD PTR [rsp+0x18],0x0
  40d200:	mov    WORD PTR [rsp+0x20],0x0
  40d207:	mov    DWORD PTR [r14],0x67617753
  40d20e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40d216:	xor    eax,eax
  40d218:	call   4070f0 <getpid@plt>
  40d21d:	mov    ecx,eax
  40d21f:	mov    eax,0x1c
  40d224:	shrx   eax,ecx,eax
  40d229:	and    eax,0xf
  40d22c:	mov    rdx,QWORD PTR [rip+0x64c5]        # 4136f8 <__swc_rdata_base_6b1cf01f+0x5e8>
  40d233:	mov    al,BYTE PTR [rdx+rax*1]
  40d236:	rex mov BYTE PTR [rsp+0x10],al
  40d23b:	mov    eax,0x1c
  40d240:	shrx   eax,r12d,eax
  40d245:	and    eax,0xf
  40d248:	mov    al,BYTE PTR [rdx+rax*1]
  40d24b:	rex mov BYTE PTR [rsp+0x19],al
  40d250:	mov    eax,0x18
  40d255:	shrx   eax,ecx,eax
  40d25a:	and    eax,0xf
  40d25d:	mov    al,BYTE PTR [rdx+rax*1]
  40d260:	rex mov BYTE PTR [rsp+0x11],al
  40d265:	mov    eax,0x18
  40d26a:	shrx   eax,r12d,eax
  40d26f:	and    eax,0xf
  40d272:	mov    al,BYTE PTR [rdx+rax*1]
  40d275:	rex mov BYTE PTR [rsp+0x1a],al
  40d27a:	mov    eax,0x14
  40d27f:	shrx   eax,ecx,eax
  40d284:	and    eax,0xf
  40d287:	mov    al,BYTE PTR [rdx+rax*1]
  40d28a:	rex mov BYTE PTR [rsp+0x12],al
  40d28f:	mov    eax,0x14
  40d294:	shrx   eax,r12d,eax
  40d299:	and    eax,0xf
  40d29c:	mov    al,BYTE PTR [rdx+rax*1]
  40d29f:	rex mov BYTE PTR [rsp+0x1b],al
  40d2a4:	mov    eax,0x10
  40d2a9:	shrx   eax,ecx,eax
  40d2ae:	and    eax,0xf
  40d2b1:	mov    al,BYTE PTR [rdx+rax*1]
  40d2b4:	rex mov BYTE PTR [rsp+0x13],al
  40d2b9:	mov    eax,0x10
  40d2be:	shrx   eax,r12d,eax
  40d2c3:	and    eax,0xf
  40d2c6:	mov    al,BYTE PTR [rdx+rax*1]
  40d2c9:	rex mov BYTE PTR [rsp+0x1c],al
  40d2ce:	mov    eax,0xc
  40d2d3:	shrx   eax,ecx,eax
  40d2d8:	and    eax,0xf
  40d2db:	mov    al,BYTE PTR [rdx+rax*1]
  40d2de:	rex mov BYTE PTR [rsp+0x14],al
  40d2e3:	mov    eax,0xc
  40d2e8:	shrx   eax,r12d,eax
  40d2ed:	and    eax,0xf
  40d2f0:	mov    al,BYTE PTR [rdx+rax*1]
  40d2f3:	rex mov BYTE PTR [rsp+0x1d],al
  40d2f8:	mov    eax,0x8
  40d2fd:	shrx   eax,ecx,eax
  40d302:	and    eax,0xf
  40d305:	mov    al,BYTE PTR [rdx+rax*1]
  40d308:	rex mov BYTE PTR [rsp+0x15],al
  40d30d:	mov    eax,0x8
  40d312:	shrx   eax,r12d,eax
  40d317:	and    eax,0xf
  40d31a:	mov    al,BYTE PTR [rdx+rax*1]
  40d31d:	rex mov BYTE PTR [rsp+0x1e],al
  40d322:	mov    eax,0x4
  40d327:	shrx   eax,ecx,eax
  40d32c:	and    eax,0xf
  40d32f:	mov    al,BYTE PTR [rdx+rax*1]
  40d332:	rex mov BYTE PTR [rsp+0x16],al
  40d337:	mov    eax,0x4
  40d33c:	shrx   eax,r12d,eax
  40d341:	and    eax,0xf
  40d344:	mov    al,BYTE PTR [rdx+rax*1]
  40d347:	rex mov BYTE PTR [rsp+0x1f],al
  40d34c:	xor    eax,eax
  40d34e:	shrx   eax,ecx,eax
  40d353:	and    eax,0xf
  40d356:	mov    al,BYTE PTR [rdx+rax*1]
  40d359:	rex mov BYTE PTR [rsp+0x17],al
  40d35e:	xor    eax,eax
  40d360:	shrx   eax,r12d,eax
  40d365:	and    eax,0xf
  40d368:	mov    al,BYTE PTR [rdx+rax*1]
  40d36b:	rex mov BYTE PTR [rsp+0x20],al
  40d370:	mov    BYTE PTR [r14+0x10],0x2e
  40d375:	lea    r12,[rsp+0x22]
  40d37a:	vxorps xmm0,xmm0,xmm0
  40d37e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40d384:	mov    DWORD PTR [r12],0x6d656d2f
  40d38c:	mov    WORD PTR [r12+0x4],0x6466
  40d394:	mov    BYTE PTR [r12+0x6],0x3a
  40d39a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40d3a0:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40d3a6:	mov    rax,QWORD PTR [rsp+0x18]
  40d3ab:	mov    QWORD PTR [rsp+0x39],rax
  40d3b0:	rex mov al,BYTE PTR [rsp+0x20]
  40d3b5:	rex mov BYTE PTR [rsp+0x41],al
  40d3ba:	mov    DWORD PTR [r12+0x20],0x65642820
  40d3c3:	mov    DWORD PTR [r12+0x24],0x6574656c
  40d3cc:	mov    WORD PTR [r12+0x28],0x2964
  40d3d4:	lea    rdi,[rip+0x6308]        # 4136e3 <__swc_rdata_base_6b1cf01f+0x5d3>
  40d3db:	xor    eax,eax
  40d3dd:	call   407100 <opendir@plt>
  40d3e2:	mov    r15,rax
  40d3e5:	test   rax,rax
  40d3e8:	jne    40d3fb <__swc_fn_6b1cf01f_000109_6814119b+0x30b>
  40d3ea:	movsxd rdi,r13d
  40d3ed:	xor    eax,eax
  40d3ef:	call   4070e0 <close@plt>
  40d3f4:	xor    eax,eax
  40d3f6:	jmp    40d6a6 <__swc_fn_6b1cf01f_000109_6814119b+0x5b6>
  40d3fb:	mov    rdi,r15
  40d3fe:	xor    eax,eax
  40d400:	call   407110 <dirfd@plt>
  40d405:	lea    r14,[rsp+0x54]
  40d40a:	mov    DWORD PTR [rsp+0x54],eax
  40d40e:	lea    rbx,[rsp+0x58]
  40d413:	cs nop WORD PTR [rax+rax*1+0x0]
  40d41d:	nop    DWORD PTR [rax]
  40d420:	mov    rdi,r15
  40d423:	xor    eax,eax
  40d425:	call   407120 <readdir@plt>
  40d42a:	test   rax,rax
  40d42d:	jne    40d444 <__swc_fn_6b1cf01f_000109_6814119b+0x354>
  40d42f:	mov    r12,QWORD PTR [rsp+0xa8]
  40d437:	mov    r13,QWORD PTR [rsp+0xb0]
  40d43f:	jmp    40d5ca <__swc_fn_6b1cf01f_000109_6814119b+0x4da>
  40d444:	vxorps xmm0,xmm0,xmm0
  40d448:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  40d44e:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  40d454:	vzeroupper
  40d457:	lea    r13,[rax+0x13]
  40d45b:	mov    rax,r14
  40d45e:	movsxd rdi,DWORD PTR [rax]
  40d461:	mov    rsi,r13
  40d464:	mov    rdx,rbx
  40d467:	mov    ecx,0x40
  40d46c:	xor    eax,eax
  40d46e:	call   407130 <readlinkat@plt>
  40d473:	cmp    rax,0x2a
  40d477:	jne    40d420 <__swc_fn_6b1cf01f_000109_6814119b+0x330>
  40d479:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40d47f:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40d485:	vptest xmm0,xmm0
  40d48a:	jne    40d4ba <__swc_fn_6b1cf01f_000109_6814119b+0x3ca>
  40d48c:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40d492:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40d498:	vptest xmm0,xmm0
  40d49d:	jne    40d4ba <__swc_fn_6b1cf01f_000109_6814119b+0x3ca>
  40d49f:	mov    rcx,QWORD PTR [rsp+0x42]
  40d4a4:	cmp    QWORD PTR [rsp+0x78],rcx
  40d4a9:	jne    40d4ba <__swc_fn_6b1cf01f_000109_6814119b+0x3ca>
  40d4ab:	mov    cx,WORD PTR [rsp+0x4a]
  40d4b0:	cmp    WORD PTR [rsp+0x80],cx
  40d4b8:	je     40d4e4 <__swc_fn_6b1cf01f_000109_6814119b+0x3f4>
  40d4ba:	mov    rax,rbx
  40d4bd:	mov    rcx,r12
  40d4c0:	movzx  edx,BYTE PTR [rax]
  40d4c3:	movzx  r8d,BYTE PTR [rcx]
  40d4c7:	cmp    rdx,r8
  40d4ca:	jne    40d4d6 <__swc_fn_6b1cf01f_000109_6814119b+0x3e6>
  40d4cc:	add    rax,0x1
  40d4d0:	add    rcx,0x1
  40d4d4:	jmp    40d4c0 <__swc_fn_6b1cf01f_000109_6814119b+0x3d0>
  40d4d6:	mov    rax,rdx
  40d4d9:	sub    rax,r8
  40d4dc:	test   eax,eax
  40d4de:	jne    40d420 <__swc_fn_6b1cf01f_000109_6814119b+0x330>
  40d4e4:	movsxd rdi,DWORD PTR [r14]
  40d4e7:	mov    rsi,r13
  40d4ea:	mov    edx,0x80002
  40d4ef:	xor    eax,eax
  40d4f1:	call   407140 <openat@plt>
  40d4f6:	lea    rbx,[rsp+0x98]
  40d4fe:	mov    DWORD PTR [rsp+0x98],eax
  40d505:	test   eax,eax
  40d507:	mov    r13,QWORD PTR [rsp+0xb0]
  40d50f:	jge    40d534 <__swc_fn_6b1cf01f_000109_6814119b+0x444>
  40d511:	mov    rdi,r15
  40d514:	xor    eax,eax
  40d516:	call   407150 <closedir@plt>
  40d51b:	mov    r13,QWORD PTR [rsp+0xb0]
  40d523:	movsxd rdi,r13d
  40d526:	xor    eax,eax
  40d528:	call   4070e0 <close@plt>
  40d52d:	xor    eax,eax
  40d52f:	jmp    40d6a6 <__swc_fn_6b1cf01f_000109_6814119b+0x5b6>
  40d534:	mov    rax,rbx
  40d537:	movsxd rdi,DWORD PTR [rax]
  40d53a:	xor    esi,esi
  40d53c:	mov    edx,0x2
  40d541:	xor    eax,eax
  40d543:	call   407160 <lseek@plt>
  40d548:	mov    r12,QWORD PTR [rsp+0xa8]
  40d550:	cmp    rax,r12
  40d553:	je     40d57a <__swc_fn_6b1cf01f_000109_6814119b+0x48a>
  40d555:	movsxd rdi,DWORD PTR [rbx]
  40d558:	xor    eax,eax
  40d55a:	call   4070e0 <close@plt>
  40d55f:	mov    rdi,r15
  40d562:	xor    eax,eax
  40d564:	call   407150 <closedir@plt>
  40d569:	movsxd rdi,r13d
  40d56c:	xor    eax,eax
  40d56e:	call   4070e0 <close@plt>
  40d573:	xor    eax,eax
  40d575:	jmp    40d6a6 <__swc_fn_6b1cf01f_000109_6814119b+0x5b6>
  40d57a:	xor    edi,edi
  40d57c:	mov    rsi,r12
  40d57f:	mov    edx,0x3
  40d584:	mov    ecx,0x1
  40d589:	mov    rax,rbx
  40d58c:	movsxd r8,DWORD PTR [rax]
  40d58f:	xor    r9d,r9d
  40d592:	xor    eax,eax
  40d594:	call   407020 <mmap@plt>
  40d599:	xor    r12d,r12d
  40d59c:	cmp    rax,0xffffffffffffffff
  40d5a0:	cmovne r12,rax
  40d5a4:	movsxd rdi,DWORD PTR [rbx]
  40d5a7:	xor    eax,eax
  40d5a9:	call   4070e0 <close@plt>
  40d5ae:	mov    rdi,r15
  40d5b1:	xor    eax,eax
  40d5b3:	call   407150 <closedir@plt>
  40d5b8:	movsxd rdi,r13d
  40d5bb:	xor    eax,eax
  40d5bd:	call   4070e0 <close@plt>
  40d5c2:	mov    rax,r12
  40d5c5:	jmp    40d6a6 <__swc_fn_6b1cf01f_000109_6814119b+0x5b6>
  40d5ca:	mov    r14,QWORD PTR [rsp+0xb8]
  40d5d2:	mov    rdi,r14
  40d5d5:	mov    esi,0x1
  40d5da:	xor    eax,eax
  40d5dc:	call   407170 <memfd_create@plt>
  40d5e1:	lea    rbx,[rsp+0x9c]
  40d5e9:	mov    DWORD PTR [rsp+0x9c],eax
  40d5f0:	test   eax,eax
  40d5f2:	jge    40d60f <__swc_fn_6b1cf01f_000109_6814119b+0x51f>
  40d5f4:	mov    rdi,r15
  40d5f7:	xor    eax,eax
  40d5f9:	call   407150 <closedir@plt>
  40d5fe:	movsxd rdi,r13d
  40d601:	xor    eax,eax
  40d603:	call   4070e0 <close@plt>
  40d608:	xor    eax,eax
  40d60a:	jmp    40d6a6 <__swc_fn_6b1cf01f_000109_6814119b+0x5b6>
  40d60f:	mov    rax,rbx
  40d612:	movsxd rdi,DWORD PTR [rax]
  40d615:	mov    rsi,r12
  40d618:	xor    eax,eax
  40d61a:	call   407180 <ftruncate@plt>
  40d61f:	test   eax,eax
  40d621:	je     40d645 <__swc_fn_6b1cf01f_000109_6814119b+0x555>
  40d623:	movsxd rdi,DWORD PTR [rbx]
  40d626:	xor    eax,eax
  40d628:	call   4070e0 <close@plt>
  40d62d:	mov    rdi,r15
  40d630:	xor    eax,eax
  40d632:	call   407150 <closedir@plt>
  40d637:	movsxd rdi,r13d
  40d63a:	xor    eax,eax
  40d63c:	call   4070e0 <close@plt>
  40d641:	xor    eax,eax
  40d643:	jmp    40d6a6 <__swc_fn_6b1cf01f_000109_6814119b+0x5b6>
  40d645:	xor    edi,edi
  40d647:	mov    rsi,r12
  40d64a:	mov    edx,0x3
  40d64f:	mov    ecx,0x1
  40d654:	mov    rax,rbx
  40d657:	movsxd r8,DWORD PTR [rax]
  40d65a:	xor    r9d,r9d
  40d65d:	xor    eax,eax
  40d65f:	call   407020 <mmap@plt>
  40d664:	mov    r12,rax
  40d667:	cmp    rax,0xffffffffffffffff
  40d66b:	jne    40d68f <__swc_fn_6b1cf01f_000109_6814119b+0x59f>
  40d66d:	movsxd rdi,DWORD PTR [rbx]
  40d670:	xor    eax,eax
  40d672:	call   4070e0 <close@plt>
  40d677:	mov    rdi,r15
  40d67a:	xor    eax,eax
  40d67c:	call   407150 <closedir@plt>
  40d681:	movsxd rdi,r13d
  40d684:	xor    eax,eax
  40d686:	call   4070e0 <close@plt>
  40d68b:	xor    eax,eax
  40d68d:	jmp    40d6a6 <__swc_fn_6b1cf01f_000109_6814119b+0x5b6>
  40d68f:	mov    rdi,r15
  40d692:	xor    eax,eax
  40d694:	call   407150 <closedir@plt>
  40d699:	movsxd rdi,r13d
  40d69c:	xor    eax,eax
  40d69e:	call   4070e0 <close@plt>
  40d6a3:	mov    rax,r12
  40d6a6:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40d6af:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40d6b8:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40d6c1:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40d6ca:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  40d6d3:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40d6dc:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  40d6e5:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40d6ee:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  40d6f7:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  40d700:	add    rsp,0x170
  40d707:	pop    r15
  40d709:	pop    r14
  40d70b:	pop    r13
  40d70d:	pop    rsi
  40d70e:	pop    rdi
  40d70f:	pop    r12
  40d711:	pop    rbx
  40d712:	ret
	...

000000000040d720 <__swc_fn_6b1cf01f_000112_5f48311c>:
  40d720:	push   rsi
  40d721:	push   rdi
  40d722:	push   r12
  40d724:	push   r13
  40d726:	sub    rsp,0x8
  40d72a:	mov    rsi,r8
  40d72d:	mov    rdi,rcx
  40d730:	mov    r12,rdx
  40d733:	call   4115a0 <__swc_fn_6b1cf01f_000110_126150d1>
  40d738:	mov    r13,rax
  40d73b:	test   rax,rax
  40d73e:	jne    40d74b <__swc_fn_6b1cf01f_000112_5f48311c+0x2b>
  40d740:	add    rsp,0x8
  40d744:	pop    r13
  40d746:	pop    r12
  40d748:	pop    rdi
  40d749:	pop    rsi
  40d74a:	ret
  40d74b:	mov    rcx,r13
  40d74e:	call   409c90 <__swc_fn_6b1cf01f_000135_8c07c14b>
  40d753:	mov    rax,QWORD PTR [r13+0x8]
  40d757:	test   rax,rax
  40d75a:	je     40d799 <__swc_fn_6b1cf01f_000112_5f48311c+0x79>
  40d75c:	nop    DWORD PTR [rax+0x0]
  40d760:	lea    rcx,[rax+0x1000]
  40d767:	cmp    rdi,rcx
  40d76a:	jne    40d791 <__swc_fn_6b1cf01f_000112_5f48311c+0x71>
  40d76c:	cmp    r12,0x1000
  40d773:	jb     40d791 <__swc_fn_6b1cf01f_000112_5f48311c+0x71>
  40d775:	test   sil,sil
  40d778:	setne  cl
  40d77b:	mov    BYTE PTR [rax+0x10],cl
  40d77e:	mov    rcx,r13
  40d781:	call   40dc80 <__swc_fn_6b1cf01f_000136_715e84ff>
  40d786:	add    rsp,0x8
  40d78a:	pop    r13
  40d78c:	pop    r12
  40d78e:	pop    rdi
  40d78f:	pop    rsi
  40d790:	ret
  40d791:	mov    rax,QWORD PTR [rax]
  40d794:	test   rax,rax
  40d797:	jne    40d760 <__swc_fn_6b1cf01f_000112_5f48311c+0x40>
  40d799:	mov    rcx,r13
  40d79c:	call   40dc80 <__swc_fn_6b1cf01f_000136_715e84ff>
  40d7a1:	add    rsp,0x8
  40d7a5:	pop    r13
  40d7a7:	pop    r12
  40d7a9:	pop    rdi
  40d7aa:	pop    rsi
  40d7ab:	ret
  40d7ac:	add    BYTE PTR [rax],al
	...

000000000040d7b0 <__swc_fn_6b1cf01f_000115_ed2d8fed>:
  40d7b0:	sub    rsp,0x8
  40d7b4:	test   rcx,rcx
  40d7b7:	jne    40d7be <__swc_fn_6b1cf01f_000115_ed2d8fed+0xe>
  40d7b9:	add    rsp,0x8
  40d7bd:	ret
  40d7be:	call   4097a0 <__swc_fn_6b1cf01f_000117_d3318640>
  40d7c3:	add    rsp,0x8
  40d7c7:	ret
	...

000000000040d7d0 <__swc_fn_6b1cf01f_000118_2648f149>:
  40d7d0:	push   r12
  40d7d2:	push   r13
  40d7d4:	push   r14
  40d7d6:	push   rdi
  40d7d7:	push   rsi
  40d7d8:	sub    rsp,0xc0
  40d7df:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40d7e5:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40d7eb:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40d7f1:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40d7f7:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40d7fd:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40d803:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40d809:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40d812:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40d81b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40d824:	mov    r12,QWORD PTR [rcx]
  40d827:	test   r12,r12
  40d82a:	jne    40d83c <__swc_fn_6b1cf01f_000118_2648f149+0x6c>
  40d82c:	add    rsp,0xc0
  40d833:	pop    rsi
  40d834:	pop    rdi
  40d835:	pop    r14
  40d837:	pop    r13
  40d839:	pop    r12
  40d83b:	ret
  40d83c:	xor    r13d,r13d
  40d83f:	mov    r14,QWORD PTR [rcx+0x8]
  40d843:	cs nop WORD PTR [rax+rax*1+0x0]
  40d84d:	nop    DWORD PTR [rax]
  40d850:	cmp    r13,r14
  40d853:	jae    40d88b <__swc_fn_6b1cf01f_000118_2648f149+0xbb>
  40d855:	lea    rax,[r12+r13*1]
  40d859:	mov    rcx,r14
  40d85c:	sub    rcx,r13
  40d85f:	mov    edi,0x1
  40d864:	mov    rsi,rax
  40d867:	mov    rdx,rcx
  40d86a:	xor    eax,eax
  40d86c:	call   407190 <write@plt>
  40d871:	test   rax,rax
  40d874:	jle    40d87b <__swc_fn_6b1cf01f_000118_2648f149+0xab>
  40d876:	add    r13,rax
  40d879:	jmp    40d850 <__swc_fn_6b1cf01f_000118_2648f149+0x80>
  40d87b:	je     40d889 <__swc_fn_6b1cf01f_000118_2648f149+0xb9>
  40d87d:	xor    eax,eax
  40d87f:	call   4070d0 <__errno_location@plt>
  40d884:	cmp    DWORD PTR [rax],0x4
  40d887:	je     40d850 <__swc_fn_6b1cf01f_000118_2648f149+0x80>
  40d889:	jmp    40d88b <__swc_fn_6b1cf01f_000118_2648f149+0xbb>
  40d88b:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40d891:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40d897:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40d89d:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40d8a3:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40d8a9:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40d8af:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40d8b5:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40d8be:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40d8c7:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40d8d0:	add    rsp,0xc0
  40d8d7:	pop    rsi
  40d8d8:	pop    rdi
  40d8d9:	pop    r14
  40d8db:	pop    r13
  40d8dd:	pop    r12
  40d8df:	ret

000000000040d8e0 <__swc_fn_6b1cf01f_000121_4f256d58>:
  40d8e0:	push   rbx
  40d8e1:	push   r12
  40d8e3:	push   rdi
  40d8e4:	push   rsi
  40d8e5:	sub    rsp,0x4a8
  40d8ec:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  40d8f5:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  40d8fe:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  40d907:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  40d910:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  40d919:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  40d922:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  40d92b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  40d934:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  40d93d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  40d946:	mov    rbx,rdx
  40d949:	mov    r12d,ecx
  40d94c:	vxorps xmm0,xmm0,xmm0
  40d950:	xor    eax,eax
  40d952:	cs nop WORD PTR [rax+rax*1+0x0]
  40d95c:	nop    DWORD PTR [rax+0x0]
  40d960:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  40d966:	add    rax,0x10
  40d96a:	cmp    rax,0x400
  40d971:	jne    40d960 <__swc_fn_6b1cf01f_000121_4f256d58+0x80>
  40d973:	lea    rdi,[rsp+0x8]
  40d978:	mov    esi,0x80
  40d97d:	xor    eax,eax
  40d97f:	call   4071a0 <backtrace@plt>
  40d984:	test   eax,eax
  40d986:	jle    40d995 <__swc_fn_6b1cf01f_000121_4f256d58+0xb5>
  40d988:	movsxd rax,eax
  40d98b:	lea    rcx,[r12+0x1]
  40d990:	cmp    rcx,rax
  40d993:	jb     40d999 <__swc_fn_6b1cf01f_000121_4f256d58+0xb9>
  40d995:	xor    eax,eax
  40d997:	jmp    40d9ca <__swc_fn_6b1cf01f_000121_4f256d58+0xea>
  40d999:	mov    rcx,QWORD PTR [rbx+0x8]
  40d99d:	sub    rax,r12
  40d9a0:	lea    rsi,[rax-0x1]
  40d9a4:	cmp    rcx,rsi
  40d9a7:	cmovbe rsi,rcx
  40d9ab:	lea    eax,[r12+0x1]
  40d9b0:	lea    rax,[rsp+rax*8+0x8]
  40d9b5:	mov    rcx,QWORD PTR [rbx]
  40d9b8:	mov    rdx,rax
  40d9bb:	lea    r8,[rsi*8+0x0]
  40d9c3:	call   411580 <__swc_fn_6b1cf01f_000107_7c204aac>
  40d9c8:	mov    eax,esi
  40d9ca:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  40d9d3:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  40d9dc:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  40d9e5:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  40d9ee:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  40d9f7:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  40da00:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  40da09:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  40da12:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  40da1b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  40da24:	add    rsp,0x4a8
  40da2b:	pop    rsi
  40da2c:	pop    rdi
  40da2d:	pop    r12
  40da2f:	pop    rbx
  40da30:	ret
	...

000000000040da40 <__swc_fn_6b1cf01f_000124_fcd5a289>:
  40da40:	mov    QWORD PTR [rcx],0x0
  40da47:	ret
	...

000000000040da50 <__swc_fn_6b1cf01f_000127_4bbe3f14>:
  40da50:	push   rdi
  40da51:	push   rsi
  40da52:	sub    rsp,0xa8
  40da59:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40da5f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40da65:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40da6b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40da71:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40da77:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40da7d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40da83:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40da89:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40da92:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40da9b:	mov    edi,ecx
  40da9d:	mov    rsi,rdx
  40daa0:	xor    eax,eax
  40daa2:	call   4071b0 <pthread_setspecific@plt>
  40daa7:	test   eax,eax
  40daa9:	sete   al
  40daac:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40dab2:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40dab8:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40dabe:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40dac4:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40daca:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40dad0:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40dad6:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40dadc:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40dae5:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40daee:	add    rsp,0xa8
  40daf5:	pop    rsi
  40daf6:	pop    rdi
  40daf7:	ret
	...

000000000040db00 <__swc_fn_6b1cf01f_000130_5f757033>:
  40db00:	push   rdi
  40db01:	push   rsi
  40db02:	sub    rsp,0xa8
  40db09:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40db0f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40db15:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40db1b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40db21:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40db27:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40db2d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40db33:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40db39:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40db42:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40db4b:	test   rcx,rcx
  40db4e:	je     40db61 <__swc_fn_6b1cf01f_000130_5f757033+0x61>
  40db50:	lea    rax,[rcx-0x1]
  40db54:	mov    eax,eax
  40db56:	mov    edi,eax
  40db58:	xor    eax,eax
  40db5a:	call   407010 <pthread_getspecific@plt>
  40db5f:	jmp    40db63 <__swc_fn_6b1cf01f_000130_5f757033+0x63>
  40db61:	xor    eax,eax
  40db63:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40db69:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40db6f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40db75:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40db7b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40db81:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40db87:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40db8d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40db93:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40db9c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40dba5:	add    rsp,0xa8
  40dbac:	pop    rsi
  40dbad:	pop    rdi
  40dbae:	ret
	...

000000000040dbb0 <__swc_fn_6b1cf01f_000133_07d76562>:
  40dbb0:	push   rdi
  40dbb1:	push   rsi
  40dbb2:	sub    rsp,0xb8
  40dbb9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40dbbf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40dbc5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40dbcb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40dbd1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40dbd7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40dbdd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40dbe3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40dbec:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40dbf5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40dbfe:	vxorps xmm0,xmm0,xmm0
  40dc02:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dc08:	mov    edi,0x1
  40dc0d:	lea    rsi,[rsp+0x8]
  40dc12:	xor    eax,eax
  40dc14:	call   407000 <clock_gettime@plt>
  40dc19:	mov    rax,QWORD PTR [rsp+0x8]
  40dc1e:	imul   rax,rax,0x3b9aca00
  40dc25:	add    rax,QWORD PTR [rsp+0x10]
  40dc2a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40dc30:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40dc36:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40dc3c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40dc42:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40dc48:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40dc4e:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40dc54:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40dc5d:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40dc66:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40dc6f:	add    rsp,0xb8
  40dc76:	pop    rsi
  40dc77:	pop    rdi
  40dc78:	ret
  40dc79:	add    BYTE PTR [rax],al
  40dc7b:	add    BYTE PTR [rax],al
  40dc7d:	add    BYTE PTR [rax],al
	...

000000000040dc80 <__swc_fn_6b1cf01f_000136_715e84ff>:
  40dc80:	sub    rsp,0x8
  40dc84:	xor    eax,eax
  40dc86:	mov    DWORD PTR [rcx],eax
  40dc88:	mov    edx,0x7fffffff
  40dc8d:	call   411c80 <__swc_fn_6b1cf01f_000134_865f5106>
  40dc92:	add    rsp,0x8
  40dc96:	ret
	...

000000000040dca0 <__swc_fn_6b1cf01f_000139_519fdf94>:
  40dca0:	push   rdi
  40dca1:	push   rsi
  40dca2:	sub    rsp,0xb8
  40dca9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40dcaf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40dcb5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40dcbb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40dcc1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40dcc7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40dccd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40dcd3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40dcdc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40dce5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40dcee:	mov    edi,0x1
  40dcf3:	xor    eax,eax
  40dcf5:	call   4071c0 <__x86_get_cpuid_feature_leaf@plt>
  40dcfa:	mov    eax,DWORD PTR [rax+0x14]
  40dcfd:	and    eax,0x20
  40dd00:	setne  al
  40dd03:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40dd09:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40dd0f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40dd15:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40dd1b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40dd21:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40dd27:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40dd2d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40dd36:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40dd3f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40dd48:	add    rsp,0xb8
  40dd4f:	pop    rsi
  40dd50:	pop    rdi
  40dd51:	ret
	...

000000000040dd60 <__swc_fn_6b1cf01f_000142_d5d4d43f>:
  40dd60:	push   rsi
  40dd61:	push   rdi
  40dd62:	push   r12
  40dd64:	push   r13
  40dd66:	push   r14
  40dd68:	push   r15
  40dd6a:	cmp    rdx,0x40
  40dd6e:	jae    40dd7d <__swc_fn_6b1cf01f_000142_d5d4d43f+0x1d>
  40dd70:	xor    eax,eax
  40dd72:	pop    r15
  40dd74:	pop    r14
  40dd76:	pop    r13
  40dd78:	pop    r12
  40dd7a:	pop    rdi
  40dd7b:	pop    rsi
  40dd7c:	ret
  40dd7d:	cmp    BYTE PTR [rcx],0x7f
  40dd80:	jne    40ddc4 <__swc_fn_6b1cf01f_000142_d5d4d43f+0x64>
  40dd82:	movzx  eax,BYTE PTR [rcx+0x1]
  40dd86:	cmp    eax,0x45
  40dd89:	setne  al
  40dd8c:	jne    40ddc0 <__swc_fn_6b1cf01f_000142_d5d4d43f+0x60>
  40dd8e:	movzx  eax,BYTE PTR [rcx+0x2]
  40dd92:	cmp    eax,0x4c
  40dd95:	setne  al
  40dd98:	jne    40ddc0 <__swc_fn_6b1cf01f_000142_d5d4d43f+0x60>
  40dd9a:	movzx  eax,BYTE PTR [rcx+0x3]
  40dd9e:	cmp    eax,0x46
  40dda1:	setne  al
  40dda4:	jne    40ddc0 <__swc_fn_6b1cf01f_000142_d5d4d43f+0x60>
  40dda6:	cmp    BYTE PTR [rcx+0x4],0x2
  40ddaa:	setne  al
  40ddad:	jne    40ddc0 <__swc_fn_6b1cf01f_000142_d5d4d43f+0x60>
  40ddaf:	cmp    BYTE PTR [rcx+0x5],0x1
  40ddb3:	setne  al
  40ddb6:	jne    40ddc0 <__swc_fn_6b1cf01f_000142_d5d4d43f+0x60>
  40ddb8:	cmp    WORD PTR [rcx+0x12],0x3e
  40ddbd:	setne  al
  40ddc0:	test   al,al
  40ddc2:	je     40ddd1 <__swc_fn_6b1cf01f_000142_d5d4d43f+0x71>
  40ddc4:	xor    eax,eax
  40ddc6:	pop    r15
  40ddc8:	pop    r14
  40ddca:	pop    r13
  40ddcc:	pop    r12
  40ddce:	pop    rdi
  40ddcf:	pop    rsi
  40ddd0:	ret
  40ddd1:	cmp    WORD PTR [rcx+0x3a],0x40
  40ddd6:	jne    40ddf1 <__swc_fn_6b1cf01f_000142_d5d4d43f+0x91>
  40ddd8:	cmp    WORD PTR [rcx+0x3c],0x0
  40dddd:	sete   al
  40dde0:	je     40dded <__swc_fn_6b1cf01f_000142_d5d4d43f+0x8d>
  40dde2:	mov    ax,WORD PTR [rcx+0x3c]
  40dde6:	cmp    WORD PTR [rcx+0x3e],ax
  40ddea:	setae  al
  40dded:	test   al,al
  40ddef:	je     40ddfe <__swc_fn_6b1cf01f_000142_d5d4d43f+0x9e>
  40ddf1:	xor    eax,eax
  40ddf3:	pop    r15
  40ddf5:	pop    r14
  40ddf7:	pop    r13
  40ddf9:	pop    r12
  40ddfb:	pop    rdi
  40ddfc:	pop    rsi
  40ddfd:	ret
  40ddfe:	movzx  eax,WORD PTR [rcx+0x3c]
  40de02:	shl    rax,0x6
  40de06:	cmp    rax,rdx
  40de09:	ja     40de17 <__swc_fn_6b1cf01f_000142_d5d4d43f+0xb7>
  40de0b:	mov    r9,rdx
  40de0e:	sub    r9,rax
  40de11:	cmp    QWORD PTR [rcx+0x28],r9
  40de15:	jbe    40de24 <__swc_fn_6b1cf01f_000142_d5d4d43f+0xc4>
  40de17:	xor    eax,eax
  40de19:	pop    r15
  40de1b:	pop    r14
  40de1d:	pop    r13
  40de1f:	pop    r12
  40de21:	pop    rdi
  40de22:	pop    rsi
  40de23:	ret
  40de24:	mov    rax,QWORD PTR [rcx+0x28]
  40de28:	add    rax,rcx
  40de2b:	movzx  r9d,WORD PTR [rcx+0x3e]
  40de30:	lea    r9,[r9*8+0x0]
  40de38:	lea    r10,[rax+r9*8]
  40de3c:	cmp    QWORD PTR [r10+0x20],rdx
  40de40:	ja     40de62 <__swc_fn_6b1cf01f_000142_d5d4d43f+0x102>
  40de42:	mov    r11,rdx
  40de45:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  40de4a:	cmp    QWORD PTR [r10+0x18],r11
  40de4e:	seta   r9b
  40de52:	ja     40de5d <__swc_fn_6b1cf01f_000142_d5d4d43f+0xfd>
  40de54:	cmp    QWORD PTR [r10+0x20],0x9
  40de59:	setb   r9b
  40de5d:	test   r9b,r9b
  40de60:	je     40de6f <__swc_fn_6b1cf01f_000142_d5d4d43f+0x10f>
  40de62:	xor    eax,eax
  40de64:	pop    r15
  40de66:	pop    r14
  40de68:	pop    r13
  40de6a:	pop    r12
  40de6c:	pop    rdi
  40de6d:	pop    rsi
  40de6e:	ret
  40de6f:	movzx  r9d,WORD PTR [rcx+0x3c]
  40de74:	xor    r11d,r11d
  40de77:	test   r9,r9
  40de7a:	jbe    40df75 <__swc_fn_6b1cf01f_000142_d5d4d43f+0x215>
  40de80:	mov    rsi,QWORD PTR [r10+0x20]
  40de84:	sub    rsi,0x9
  40de88:	cs nop WORD PTR [rax+rax*1+0x0]
  40de92:	cs nop WORD PTR [rax+rax*1+0x0]
  40de9c:	nop    DWORD PTR [rax+0x0]
  40dea0:	movzx  edi,r11w
  40dea4:	lea    rdi,[rdi*8+0x0]
  40deac:	lea    r12,[rax+rdi*8]
  40deb0:	rex mov edi,DWORD PTR [rax+rdi*8]
  40deb4:	cmp    rdi,rsi
  40deb7:	ja     40df68 <__swc_fn_6b1cf01f_000142_d5d4d43f+0x208>
  40debd:	mov    r13,QWORD PTR [r10+0x18]
  40dec1:	add    r13,rdi
  40dec4:	lea    rdi,[rcx+r13*1]
  40dec8:	lea    r13,[rip+0x5889]        # 413758 <__swc_rdata_base_6b1cf01f+0x648>
  40decf:	movabs r14,0x676264676177732e
  40ded9:	cmp    QWORD PTR [rdi],r14
  40dedc:	jne    40dee5 <__swc_fn_6b1cf01f_000142_d5d4d43f+0x185>
  40dede:	rex cmp BYTE PTR [rdi+0x8],0x0
  40dee3:	je     40df12 <__swc_fn_6b1cf01f_000142_d5d4d43f+0x1b2>
  40dee5:	cs nop WORD PTR [rax+rax*1+0x0]
  40deef:	nop
  40def0:	movzx  r14d,BYTE PTR [rdi]
  40def4:	movzx  r15d,BYTE PTR [r13+0x0]
  40def9:	cmp    r14,r15
  40defc:	jne    40df08 <__swc_fn_6b1cf01f_000142_d5d4d43f+0x1a8>
  40defe:	add    rdi,0x1
  40df02:	add    r13,0x1
  40df06:	jmp    40def0 <__swc_fn_6b1cf01f_000142_d5d4d43f+0x190>
  40df08:	mov    rdi,r14
  40df0b:	sub    rdi,r15
  40df0e:	test   edi,edi
  40df10:	jne    40df68 <__swc_fn_6b1cf01f_000142_d5d4d43f+0x208>
  40df12:	cmp    DWORD PTR [r12+0x4],0x1
  40df18:	jne    40df40 <__swc_fn_6b1cf01f_000142_d5d4d43f+0x1e0>
  40df1a:	cmp    QWORD PTR [r12+0x20],0x10
  40df20:	setb   al
  40df23:	jb     40df3c <__swc_fn_6b1cf01f_000142_d5d4d43f+0x1dc>
  40df25:	cmp    QWORD PTR [r12+0x20],rdx
  40df2a:	seta   al
  40df2d:	ja     40df3c <__swc_fn_6b1cf01f_000142_d5d4d43f+0x1dc>
  40df2f:	sub    rdx,QWORD PTR [r12+0x20]
  40df34:	cmp    QWORD PTR [r12+0x18],rdx
  40df39:	seta   al
  40df3c:	test   al,al
  40df3e:	je     40df4d <__swc_fn_6b1cf01f_000142_d5d4d43f+0x1ed>
  40df40:	xor    eax,eax
  40df42:	pop    r15
  40df44:	pop    r14
  40df46:	pop    r13
  40df48:	pop    r12
  40df4a:	pop    rdi
  40df4b:	pop    rsi
  40df4c:	ret
  40df4d:	mov    rax,QWORD PTR [r12+0x20]
  40df52:	mov    QWORD PTR [r8],rax
  40df55:	mov    rax,QWORD PTR [r12+0x18]
  40df5a:	add    rax,rcx
  40df5d:	pop    r15
  40df5f:	pop    r14
  40df61:	pop    r13
  40df63:	pop    r12
  40df65:	pop    rdi
  40df66:	pop    rsi
  40df67:	ret
  40df68:	add    r11,0x1
  40df6c:	cmp    r11,r9
  40df6f:	jb     40dea0 <__swc_fn_6b1cf01f_000142_d5d4d43f+0x140>
  40df75:	xor    eax,eax
  40df77:	pop    r15
  40df79:	pop    r14
  40df7b:	pop    r13
  40df7d:	pop    r12
  40df7f:	pop    rdi
  40df80:	pop    rsi
  40df81:	ret
	...

000000000040df90 <__swc_fn_6b1cf01f_000145_d7edc04f>:
  40df90:	push   rdi
  40df91:	push   rsi
  40df92:	sub    rsp,0xa8
  40df99:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40df9f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40dfa5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40dfab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40dfb1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40dfb7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40dfbd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40dfc3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40dfc9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40dfd2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40dfdb:	mov    rdi,rcx
  40dfde:	xor    eax,eax
  40dfe0:	call   4071d0 <free@plt>
  40dfe5:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40dfeb:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40dff1:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40dff7:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40dffd:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e003:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e009:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e00f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e015:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e01e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e027:	add    rsp,0xa8
  40e02e:	pop    rsi
  40e02f:	pop    rdi
  40e030:	ret
	...

000000000040e040 <__swc_fn_6b1cf01f_000148_6203dca2>:
  40e040:	push   rbx
  40e041:	push   rsi
  40e042:	push   rdi
  40e043:	push   r12
  40e045:	push   r13
  40e047:	push   r15
  40e049:	sub    rsp,0x4e8
  40e050:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  40e059:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  40e062:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  40e06b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  40e074:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  40e07d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  40e086:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  40e08f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  40e098:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  40e0a1:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  40e0aa:	mov    rbx,QWORD PTR [rcx]
  40e0ad:	mov    rcx,QWORD PTR [rcx+0x8]
  40e0b1:	mov    rsi,rcx
  40e0b4:	xor    edi,edi
  40e0b6:	vmovsd xmm6,QWORD PTR [rip+0x56ea]        # 4137a8 <__swc_rdata_base_6b1cf01f+0x698>
  40e0be:	vmovsd xmm7,QWORD PTR [rip+0x56eb]        # 4137b1 <__swc_rdata_base_6b1cf01f+0x6a1>
  40e0c6:	vmovsd xmm8,QWORD PTR [rip+0x52ae]        # 41337c <__swc_rdata_base_6b1cf01f+0x26c>
  40e0ce:	vmovsd xmm9,QWORD PTR [rip+0x56e4]        # 4137ba <__swc_rdata_base_6b1cf01f+0x6aa>
  40e0d6:	vmovsd xmm10,QWORD PTR [rip+0x528c]        # 41336a <__swc_rdata_base_6b1cf01f+0x25a>
  40e0de:	vmovups xmm11,xmm6
  40e0e2:	vmovsd QWORD PTR [rsp+0x418],xmm7
  40e0eb:	vmovsd QWORD PTR [rsp+0x420],xmm8
  40e0f4:	vmovsd QWORD PTR [rsp+0x428],xmm9
  40e0fd:	vmovsd QWORD PTR [rsp+0x430],xmm10
  40e106:	vmovsd xmm15,QWORD PTR [rip+0x56b5]        # 4137c3 <__swc_rdata_base_6b1cf01f+0x6b3>
  40e10e:	vmovups xmm14,xmm15
  40e113:	vmovups xmm0,xmm9
  40e118:	vmovsd QWORD PTR [rsp+0x438],xmm15
  40e121:	vmovups xmm13,xmm8
  40e126:	vmovsd QWORD PTR [rsp+0x440],xmm15
  40e12f:	test   rsi,rsi
  40e132:	je     40f123 <__swc_fn_6b1cf01f_000148_6203dca2+0x10e3>
  40e138:	cs nop WORD PTR [rax+rax*1+0x0]
  40e142:	cs nop WORD PTR [rax+rax*1+0x0]
  40e14c:	nop    DWORD PTR [rax+0x0]
  40e150:	lea    rcx,[rdi+rdi*1]
  40e154:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  40e159:	vpshufd xmm3,xmm2,0xee
  40e15e:	vmovq  rcx,xmm3
  40e163:	test   rcx,rcx
  40e166:	je     40e17c <__swc_fn_6b1cf01f_000148_6203dca2+0x13c>
  40e168:	test   DWORD PTR [rcx+0x28],0x400000
  40e16f:	je     40e17c <__swc_fn_6b1cf01f_000148_6203dca2+0x13c>
  40e171:	mov    rdx,QWORD PTR [rcx+0x30]
  40e175:	test   rdx,rdx
  40e178:	cmovne rcx,rdx
  40e17c:	test   DWORD PTR [rcx+0x28],0x1000
  40e183:	je     40e1a4 <__swc_fn_6b1cf01f_000148_6203dca2+0x164>
  40e185:	mov    rdx,QWORD PTR [rcx+0x40]
  40e189:	mov    rcx,rdx
  40e18c:	vmovq  r8,xmm2
  40e191:	mov    r8,QWORD PTR [r8]
  40e194:	mov    QWORD PTR [rsp+0x60],r8
  40e199:	mov    QWORD PTR [rsp+0x68],rdx
  40e19e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  40e1a4:	test   BYTE PTR [rcx+0x28],0x1
  40e1a8:	jne    40e1b0 <__swc_fn_6b1cf01f_000148_6203dca2+0x170>
  40e1aa:	vmovups xmm12,xmm0
  40e1ae:	jmp    40e1ca <__swc_fn_6b1cf01f_000148_6203dca2+0x18a>
  40e1b0:	vmovq  rax,xmm2
  40e1b5:	mov    rax,QWORD PTR [rax]
  40e1b8:	lea    rcx,[rax+0x10]
  40e1bc:	vmovups xmm12,xmm0
  40e1c0:	call   40d7d0 <__swc_fn_6b1cf01f_000118_2648f149>
  40e1c5:	jmp    40f105 <__swc_fn_6b1cf01f_000148_6203dca2+0x10c5>
  40e1ca:	test   DWORD PTR [rcx+0x28],0x400
  40e1d1:	je     40e232 <__swc_fn_6b1cf01f_000148_6203dca2+0x1f2>
  40e1d3:	vmovq  rax,xmm2
  40e1d8:	mov    rax,QWORD PTR [rax]
  40e1db:	xor    ecx,ecx
  40e1dd:	test   rax,rax
  40e1e0:	je     40e210 <__swc_fn_6b1cf01f_000148_6203dca2+0x1d0>
  40e1e2:	mov    rdx,rax
  40e1e5:	mov    r8b,BYTE PTR [rdx]
  40e1e8:	test   r8b,r8b
  40e1eb:	je     40e210 <__swc_fn_6b1cf01f_000148_6203dca2+0x1d0>
  40e1ed:	cs nop WORD PTR [rax+rax*1+0x0]
  40e1f7:	nop    WORD PTR [rax+rax*1+0x0]
  40e200:	add    rdx,0x1
  40e204:	add    rcx,0x1
  40e208:	mov    r8b,BYTE PTR [rdx]
  40e20b:	test   r8b,r8b
  40e20e:	jne    40e200 <__swc_fn_6b1cf01f_000148_6203dca2+0x1c0>
  40e210:	mov    QWORD PTR [rsp+0x88],rax
  40e218:	mov    QWORD PTR [rsp+0x90],rcx
  40e220:	lea    rcx,[rsp+0x88]
  40e228:	call   40d7d0 <__swc_fn_6b1cf01f_000118_2648f149>
  40e22d:	jmp    40f105 <__swc_fn_6b1cf01f_000148_6203dca2+0x10c5>
  40e232:	cmp    BYTE PTR [rcx+0x2c],0x6
  40e236:	jne    40e24d <__swc_fn_6b1cf01f_000148_6203dca2+0x20d>
  40e238:	vmovq  rax,xmm2
  40e23d:	mov    rax,QWORD PTR [rax]
  40e240:	mov    rcx,rax
  40e243:	call   412150 <__swc_fn_6b1cf01f_000146_43c96957>
  40e248:	jmp    40f105 <__swc_fn_6b1cf01f_000148_6203dca2+0x10c5>
  40e24d:	cmp    BYTE PTR [rcx+0x2c],0x1
  40e251:	jne    40f0f9 <__swc_fn_6b1cf01f_000148_6203dca2+0x10b9>
  40e257:	vmovq  rdx,xmm2
  40e25c:	mov    cl,BYTE PTR [rcx+0x40]
  40e25f:	cmp    cl,0x7
  40e262:	jb     40e2a5 <__swc_fn_6b1cf01f_000148_6203dca2+0x265>
  40e264:	je     40e318 <__swc_fn_6b1cf01f_000148_6203dca2+0x2d8>
  40e26a:	cmp    cl,0x8
  40e26d:	je     40e324 <__swc_fn_6b1cf01f_000148_6203dca2+0x2e4>
  40e273:	cmp    cl,0x9
  40e276:	je     40e33d <__swc_fn_6b1cf01f_000148_6203dca2+0x2fd>
  40e27c:	cmp    cl,0xa
  40e27f:	je     40ea04 <__swc_fn_6b1cf01f_000148_6203dca2+0x9c4>
  40e285:	cmp    cl,0xb
  40e288:	je     40f0cb <__swc_fn_6b1cf01f_000148_6203dca2+0x108b>
  40e28e:	cmp    cl,0xc
  40e291:	je     40e331 <__swc_fn_6b1cf01f_000148_6203dca2+0x2f1>
  40e297:	cmp    cl,0xd
  40e29a:	je     40f0c1 <__swc_fn_6b1cf01f_000148_6203dca2+0x1081>
  40e2a0:	jmp    40f0eb <__swc_fn_6b1cf01f_000148_6203dca2+0x10ab>
  40e2a5:	cmp    cl,0x1
  40e2a8:	je     40e2c8 <__swc_fn_6b1cf01f_000148_6203dca2+0x288>
  40e2aa:	cmp    cl,0x2
  40e2ad:	je     40e2d6 <__swc_fn_6b1cf01f_000148_6203dca2+0x296>
  40e2af:	cmp    cl,0x3
  40e2b2:	je     40e2e4 <__swc_fn_6b1cf01f_000148_6203dca2+0x2a4>
  40e2b4:	cmp    cl,0x4
  40e2b7:	je     40e2f1 <__swc_fn_6b1cf01f_000148_6203dca2+0x2b1>
  40e2b9:	cmp    cl,0x5
  40e2bc:	je     40e2fe <__swc_fn_6b1cf01f_000148_6203dca2+0x2be>
  40e2be:	cmp    cl,0x6
  40e2c1:	je     40e30b <__swc_fn_6b1cf01f_000148_6203dca2+0x2cb>
  40e2c3:	jmp    40f0eb <__swc_fn_6b1cf01f_000148_6203dca2+0x10ab>
  40e2c8:	movsx  rcx,BYTE PTR [rdx]
  40e2cc:	call   409e80 <__swc_fn_6b1cf01f_000147_2eb804cc>
  40e2d1:	jmp    40f105 <__swc_fn_6b1cf01f_000148_6203dca2+0x10c5>
  40e2d6:	movsx  rcx,WORD PTR [rdx]
  40e2da:	call   409e80 <__swc_fn_6b1cf01f_000147_2eb804cc>
  40e2df:	jmp    40f105 <__swc_fn_6b1cf01f_000148_6203dca2+0x10c5>
  40e2e4:	movsxd rcx,DWORD PTR [rdx]
  40e2e7:	call   409e80 <__swc_fn_6b1cf01f_000147_2eb804cc>
  40e2ec:	jmp    40f105 <__swc_fn_6b1cf01f_000148_6203dca2+0x10c5>
  40e2f1:	mov    rcx,QWORD PTR [rdx]
  40e2f4:	call   409e80 <__swc_fn_6b1cf01f_000147_2eb804cc>
  40e2f9:	jmp    40f105 <__swc_fn_6b1cf01f_000148_6203dca2+0x10c5>
  40e2fe:	movzx  ecx,BYTE PTR [rdx]
  40e301:	call   412150 <__swc_fn_6b1cf01f_000146_43c96957>
  40e306:	jmp    40f105 <__swc_fn_6b1cf01f_000148_6203dca2+0x10c5>
  40e30b:	movzx  ecx,WORD PTR [rdx]
  40e30e:	call   412150 <__swc_fn_6b1cf01f_000146_43c96957>
  40e313:	jmp    40f105 <__swc_fn_6b1cf01f_000148_6203dca2+0x10c5>
  40e318:	mov    ecx,DWORD PTR [rdx]
  40e31a:	call   412150 <__swc_fn_6b1cf01f_000146_43c96957>
  40e31f:	jmp    40f105 <__swc_fn_6b1cf01f_000148_6203dca2+0x10c5>
  40e324:	mov    rcx,QWORD PTR [rdx]
  40e327:	call   412150 <__swc_fn_6b1cf01f_000146_43c96957>
  40e32c:	jmp    40f105 <__swc_fn_6b1cf01f_000148_6203dca2+0x10c5>
  40e331:	mov    ecx,DWORD PTR [rdx]
  40e333:	call   412150 <__swc_fn_6b1cf01f_000146_43c96957>
  40e338:	jmp    40f105 <__swc_fn_6b1cf01f_000148_6203dca2+0x10c5>
  40e33d:	lea    rcx,[rsp+0xa8]
  40e345:	vxorps xmm0,xmm0,xmm0
  40e349:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  40e352:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  40e35b:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  40e364:	vzeroupper
  40e367:	mov    DWORD PTR [rsp+0x108],0x0
  40e372:	vxorpd xmm0,xmm0,xmm0
  40e376:	vmovss xmm1,DWORD PTR [rdx]
  40e37a:	vcvtss2sd xmm0,xmm0,xmm1
  40e37e:	vmovsd xmm1,xmm1,xmm0
  40e382:	vcomisd xmm0,xmm0
  40e386:	setne  dl
  40e389:	movzx  edx,dl
  40e38c:	setp   r8b
  40e390:	movzx  r8d,r8b
  40e394:	or     edx,r8d
  40e397:	test   dl,dl
  40e399:	je     40e3a6 <__swc_fn_6b1cf01f_000148_6203dca2+0x366>
  40e39b:	mov    DWORD PTR [rcx],0x6e616e
  40e3a1:	jmp    40e998 <__swc_fn_6b1cf01f_000148_6203dca2+0x958>
  40e3a6:	vcomisd xmm1,xmm6
  40e3aa:	ja     40e3b2 <__swc_fn_6b1cf01f_000148_6203dca2+0x372>
  40e3ac:	vcomisd xmm7,xmm1
  40e3b0:	jbe    40e3d6 <__swc_fn_6b1cf01f_000148_6203dca2+0x396>
  40e3b2:	vxorpd xmm0,xmm0,xmm0
  40e3b6:	vcomisd xmm0,xmm1
  40e3ba:	jbe    40e3cb <__swc_fn_6b1cf01f_000148_6203dca2+0x38b>
  40e3bc:	mov    DWORD PTR [rcx],0x666e692d
  40e3c2:	mov    BYTE PTR [rcx+0x4],0x0
  40e3c6:	jmp    40e998 <__swc_fn_6b1cf01f_000148_6203dca2+0x958>
  40e3cb:	mov    DWORD PTR [rcx],0x666e69
  40e3d1:	jmp    40e998 <__swc_fn_6b1cf01f_000148_6203dca2+0x958>
  40e3d6:	vcomisd xmm1,xmm8
  40e3db:	jae    40e3e7 <__swc_fn_6b1cf01f_000148_6203dca2+0x3a7>
  40e3dd:	vcomisd xmm9,xmm1
  40e3e1:	jbe    40e75e <__swc_fn_6b1cf01f_000148_6203dca2+0x71e>
  40e3e7:	vmovups xmm0,xmm1
  40e3eb:	vxorpd xmm2,xmm2,xmm2
  40e3ef:	vcomisd xmm2,xmm1
  40e3f3:	jbe    40e403 <__swc_fn_6b1cf01f_000148_6203dca2+0x3c3>
  40e3f5:	vmovsd xmm1,xmm1,xmm0
  40e3f9:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x4e3f]        # 413240 <__swc_rdata_base_6b1cf01f+0x130>
  40e401:	jmp    40e407 <__swc_fn_6b1cf01f_000148_6203dca2+0x3c7>
  40e403:	vmovsd xmm1,xmm1,xmm0
  40e407:	xor    r8d,r8d
  40e40a:	vcomisd xmm1,xmm15
  40e40f:	jb     40e430 <__swc_fn_6b1cf01f_000148_6203dca2+0x3f0>
  40e411:	cs nop WORD PTR [rax+rax*1+0x0]
  40e41b:	nop    DWORD PTR [rax+rax*1+0x0]
  40e420:	vdivsd xmm1,xmm1,xmm15
  40e425:	add    r8,0x1
  40e429:	vcomisd xmm1,xmm15
  40e42e:	jae    40e420 <__swc_fn_6b1cf01f_000148_6203dca2+0x3e0>
  40e430:	mov    r9,rcx
  40e433:	vxorpd xmm2,xmm2,xmm2
  40e437:	vcomisd xmm2,xmm0
  40e43b:	jbe    40e444 <__swc_fn_6b1cf01f_000148_6203dca2+0x404>
  40e43d:	mov    BYTE PTR [rcx],0x2d
  40e440:	lea    r9,[rcx+0x1]
  40e444:	vcvttsd2si rdx,xmm1
  40e449:	mov    r10b,dl
  40e44c:	add    r10b,0x30
  40e450:	mov    BYTE PTR [r9],r10b
  40e453:	vxorpd xmm0,xmm0,xmm0
  40e457:	movzx  edx,dl
  40e45a:	vcvtsi2sd xmm0,xmm0,rdx
  40e45f:	vsubsd xmm0,xmm1,xmm0
  40e463:	vmulsd xmm1,xmm0,xmm15
  40e468:	mov    BYTE PTR [r9+0x1],0x2e
  40e46d:	vcvttsd2si rdx,xmm1
  40e472:	mov    r10b,dl
  40e475:	add    r10b,0x30
  40e479:	mov    BYTE PTR [r9+0x2],r10b
  40e47d:	vxorpd xmm0,xmm0,xmm0
  40e481:	movzx  edx,dl
  40e484:	vcvtsi2sd xmm0,xmm0,rdx
  40e489:	vsubsd xmm0,xmm1,xmm0
  40e48d:	vmulsd xmm1,xmm0,xmm15
  40e492:	vcvttsd2si rdx,xmm1
  40e497:	mov    r10b,dl
  40e49a:	add    r10b,0x30
  40e49e:	mov    BYTE PTR [r9+0x3],r10b
  40e4a2:	vxorpd xmm0,xmm0,xmm0
  40e4a6:	movzx  edx,dl
  40e4a9:	vcvtsi2sd xmm0,xmm0,rdx
  40e4ae:	vsubsd xmm0,xmm1,xmm0
  40e4b2:	vmulsd xmm1,xmm0,xmm15
  40e4b7:	vcvttsd2si rdx,xmm1
  40e4bc:	mov    r10b,dl
  40e4bf:	add    r10b,0x30
  40e4c3:	mov    BYTE PTR [r9+0x4],r10b
  40e4c7:	vxorpd xmm0,xmm0,xmm0
  40e4cb:	movzx  edx,dl
  40e4ce:	vcvtsi2sd xmm0,xmm0,rdx
  40e4d3:	vsubsd xmm0,xmm1,xmm0
  40e4d7:	vmulsd xmm1,xmm0,xmm15
  40e4dc:	vcvttsd2si rdx,xmm1
  40e4e1:	mov    r10b,dl
  40e4e4:	add    r10b,0x30
  40e4e8:	mov    BYTE PTR [r9+0x5],r10b
  40e4ec:	vxorpd xmm0,xmm0,xmm0
  40e4f0:	movzx  edx,dl
  40e4f3:	vcvtsi2sd xmm0,xmm0,rdx
  40e4f8:	vsubsd xmm0,xmm1,xmm0
  40e4fc:	vmulsd xmm1,xmm0,xmm15
  40e501:	vcvttsd2si rdx,xmm1
  40e506:	mov    r10b,dl
  40e509:	add    r10b,0x30
  40e50d:	mov    BYTE PTR [r9+0x6],r10b
  40e511:	vxorpd xmm0,xmm0,xmm0
  40e515:	movzx  edx,dl
  40e518:	vcvtsi2sd xmm0,xmm0,rdx
  40e51d:	vsubsd xmm0,xmm1,xmm0
  40e521:	vmulsd xmm1,xmm0,xmm15
  40e526:	vcvttsd2si rdx,xmm1
  40e52b:	mov    r10b,dl
  40e52e:	add    r10b,0x30
  40e532:	mov    BYTE PTR [r9+0x7],r10b
  40e536:	vxorpd xmm0,xmm0,xmm0
  40e53a:	movzx  edx,dl
  40e53d:	vcvtsi2sd xmm0,xmm0,rdx
  40e542:	vsubsd xmm0,xmm1,xmm0
  40e546:	vmulsd xmm1,xmm0,xmm15
  40e54b:	vcvttsd2si rdx,xmm1
  40e550:	mov    r10b,dl
  40e553:	add    r10b,0x30
  40e557:	mov    BYTE PTR [r9+0x8],r10b
  40e55b:	vxorpd xmm0,xmm0,xmm0
  40e55f:	movzx  edx,dl
  40e562:	vcvtsi2sd xmm0,xmm0,rdx
  40e567:	vsubsd xmm0,xmm1,xmm0
  40e56b:	vmulsd xmm1,xmm0,xmm15
  40e570:	vcvttsd2si rdx,xmm1
  40e575:	mov    r10b,dl
  40e578:	add    r10b,0x30
  40e57c:	mov    BYTE PTR [r9+0x9],r10b
  40e580:	vxorpd xmm0,xmm0,xmm0
  40e584:	movzx  edx,dl
  40e587:	vcvtsi2sd xmm0,xmm0,rdx
  40e58c:	vsubsd xmm0,xmm1,xmm0
  40e590:	vmulsd xmm1,xmm0,xmm15
  40e595:	vcvttsd2si rdx,xmm1
  40e59a:	mov    r10b,dl
  40e59d:	add    r10b,0x30
  40e5a1:	mov    BYTE PTR [r9+0xa],r10b
  40e5a5:	vxorpd xmm0,xmm0,xmm0
  40e5a9:	movzx  edx,dl
  40e5ac:	vcvtsi2sd xmm0,xmm0,rdx
  40e5b1:	vsubsd xmm0,xmm1,xmm0
  40e5b5:	vmulsd xmm1,xmm0,xmm15
  40e5ba:	vcvttsd2si rdx,xmm1
  40e5bf:	mov    r10b,dl
  40e5c2:	add    r10b,0x30
  40e5c6:	mov    BYTE PTR [r9+0xb],r10b
  40e5ca:	lea    r10,[r9+0x4]
  40e5ce:	vxorpd xmm0,xmm0,xmm0
  40e5d2:	movzx  edx,dl
  40e5d5:	vcvtsi2sd xmm0,xmm0,rdx
  40e5da:	vsubsd xmm0,xmm1,xmm0
  40e5de:	vmulsd xmm1,xmm0,xmm15
  40e5e3:	vcvttsd2si rdx,xmm1
  40e5e8:	mov    r11b,dl
  40e5eb:	add    r11b,0x30
  40e5ef:	mov    BYTE PTR [r9+0xc],r11b
  40e5f3:	vxorpd xmm0,xmm0,xmm0
  40e5f7:	movzx  edx,dl
  40e5fa:	vcvtsi2sd xmm0,xmm0,rdx
  40e5ff:	vsubsd xmm0,xmm1,xmm0
  40e603:	vmulsd xmm1,xmm0,xmm15
  40e608:	vcvttsd2si rdx,xmm1
  40e60d:	mov    r11b,dl
  40e610:	add    r11b,0x30
  40e614:	mov    BYTE PTR [r9+0xd],r11b
  40e618:	lea    r10,[r10+0x2]
  40e61c:	vxorpd xmm0,xmm0,xmm0
  40e620:	movzx  edx,dl
  40e623:	vcvtsi2sd xmm0,xmm0,rdx
  40e628:	vsubsd xmm0,xmm1,xmm0
  40e62c:	vmulsd xmm1,xmm0,xmm15
  40e631:	vcvttsd2si rdx,xmm1
  40e636:	mov    r11b,dl
  40e639:	add    r11b,0x30
  40e63d:	mov    BYTE PTR [r9+0xe],r11b
  40e641:	vxorpd xmm0,xmm0,xmm0
  40e645:	movzx  edx,dl
  40e648:	vcvtsi2sd xmm0,xmm0,rdx
  40e64d:	vsubsd xmm0,xmm1,xmm0
  40e651:	vmulsd xmm1,xmm0,xmm15
  40e656:	vcvttsd2si rdx,xmm1
  40e65b:	mov    r11b,dl
  40e65e:	add    r11b,0x30
  40e662:	mov    BYTE PTR [r9+0xf],r11b
  40e666:	lea    r10,[r10+0x2]
  40e66a:	lea    r10,[r10+0x2]
  40e66e:	lea    r10,[r10+0x2]
  40e672:	lea    r10,[r10+0x2]
  40e676:	lea    r10,[r10+0x2]
  40e67a:	vxorpd xmm0,xmm0,xmm0
  40e67e:	movzx  edx,dl
  40e681:	vcvtsi2sd xmm0,xmm0,rdx
  40e686:	vsubsd xmm0,xmm1,xmm0
  40e68a:	vmulsd xmm1,xmm0,xmm15
  40e68f:	vcvttsd2si rdx,xmm1
  40e694:	mov    r11b,dl
  40e697:	add    r11b,0x30
  40e69b:	mov    BYTE PTR [r9+0x10],r11b
  40e69f:	vxorpd xmm0,xmm0,xmm0
  40e6a3:	movzx  edx,dl
  40e6a6:	vcvtsi2sd xmm0,xmm0,rdx
  40e6ab:	vsubsd xmm0,xmm1,xmm0
  40e6af:	vmulsd xmm1,xmm0,xmm15
  40e6b4:	vcvttsd2si rdx,xmm1
  40e6b9:	add    dl,0x30
  40e6bc:	mov    BYTE PTR [r9+0x11],dl
  40e6c0:	mov    BYTE PTR [r10+0x2],0x65
  40e6c5:	lea    r9,[r10+0x3]
  40e6c9:	test   r8,r8
  40e6cc:	jl     40e6d5 <__swc_fn_6b1cf01f_000148_6203dca2+0x695>
  40e6ce:	mov    BYTE PTR [r9],0x2b
  40e6d2:	inc    r9
  40e6d5:	mov    r10,r9
  40e6d8:	mov    rdx,r8
  40e6db:	nop    DWORD PTR [rax+rax*1+0x0]
  40e6e0:	mov    r11,rdx
  40e6e3:	movabs rdx,0x6666666666666667
  40e6ed:	mov    rax,r11
  40e6f0:	imul   rdx
  40e6f3:	sar    rdx,0x2
  40e6f7:	mov    r12,rdx
  40e6fa:	shr    rdx,0x3f
  40e6fe:	add    r12,rdx
  40e701:	mov    rdx,r12
  40e704:	imul   r13,r12,0xa
  40e708:	sub    r11,r13
  40e70b:	mov    r13,QWORD PTR [rip+0x5056]        # 413768 <__swc_rdata_base_6b1cf01f+0x658>
  40e712:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40e717:	mov    BYTE PTR [r10],r11b
  40e71a:	lea    r11,[r10+0x1]
  40e71e:	mov    r10,r11
  40e721:	test   r12,r12
  40e724:	jne    40e6e0 <__swc_fn_6b1cf01f_000148_6203dca2+0x6a0>
  40e726:	test   r8,r8
  40e729:	jge    40e733 <__swc_fn_6b1cf01f_000148_6203dca2+0x6f3>
  40e72b:	mov    BYTE PTR [r11],0x2d
  40e72f:	lea    r10,[r11+0x1]
  40e733:	mov    BYTE PTR [r10],0x0
  40e737:	sub    r10,0x1
  40e73b:	nop    DWORD PTR [rax+rax*1+0x0]
  40e740:	cmp    r9,r10
  40e743:	jae    40e998 <__swc_fn_6b1cf01f_000148_6203dca2+0x958>
  40e749:	mov    al,BYTE PTR [r10]
  40e74c:	mov    dl,BYTE PTR [r9]
  40e74f:	mov    BYTE PTR [r10],dl
  40e752:	sub    r10,0x1
  40e756:	mov    BYTE PTR [r9],al
  40e759:	inc    r9
  40e75c:	jmp    40e740 <__swc_fn_6b1cf01f_000148_6203dca2+0x700>
  40e75e:	vcvttsd2si rdx,xmm1
  40e763:	mov    r8,rdx
  40e766:	vxorpd xmm0,xmm0,xmm0
  40e76a:	vcvtsi2sd xmm0,xmm0,rdx
  40e76f:	vsubsd xmm0,xmm1,xmm0
  40e773:	mov    r9d,0x8
  40e779:	vxorpd xmm2,xmm2,xmm2
  40e77d:	vcomisd xmm2,xmm0
  40e781:	jbe    40e78b <__swc_fn_6b1cf01f_000148_6203dca2+0x74b>
  40e783:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x4ab5]        # 413240 <__swc_rdata_base_6b1cf01f+0x130>
  40e78b:	test   r9d,r9d
  40e78e:	je     40e79a <__swc_fn_6b1cf01f_000148_6203dca2+0x75a>
  40e790:	vmulsd xmm0,xmm0,xmm14
  40e795:	dec    r9d
  40e798:	jne    40e790 <__swc_fn_6b1cf01f_000148_6203dca2+0x750>
  40e79a:	vcvttsd2si r9,xmm0
  40e79f:	mov    r10,r9
  40e7a2:	vxorpd xmm2,xmm2,xmm2
  40e7a6:	vcvtsi2sd xmm2,xmm2,r9
  40e7ab:	vsubsd xmm0,xmm0,xmm2
  40e7af:	vcomisd xmm0,xmm10
  40e7b4:	lea    r9,[r9+0x1]
  40e7b8:	cmova  r10,r9
  40e7bc:	cmp    r10,0x5f5e100
  40e7c3:	jne    40e7dc <__swc_fn_6b1cf01f_000148_6203dca2+0x79c>
  40e7c5:	lea    r8,[rdx-0x1]
  40e7c9:	vxorpd xmm0,xmm0,xmm0
  40e7cd:	vcomisd xmm0,xmm1
  40e7d1:	lea    rdx,[rdx+0x1]
  40e7d5:	cmovbe r8,rdx
  40e7d9:	xor    r10d,r10d
  40e7dc:	mov    r9,rcx
  40e7df:	test   r8,r8
  40e7e2:	jne    40e802 <__swc_fn_6b1cf01f_000148_6203dca2+0x7c2>
  40e7e4:	vxorpd xmm0,xmm0,xmm0
  40e7e8:	vcomisd xmm0,xmm1
  40e7ec:	jbe    40e7f5 <__swc_fn_6b1cf01f_000148_6203dca2+0x7b5>
  40e7ee:	mov    BYTE PTR [rcx],0x2d
  40e7f1:	lea    r9,[rcx+0x1]
  40e7f5:	mov    BYTE PTR [r9],0x30
  40e7f9:	add    r9,0x1
  40e7fd:	jmp    40e89b <__swc_fn_6b1cf01f_000148_6203dca2+0x85b>
  40e802:	mov    r9,rcx
  40e805:	mov    rdx,r8
  40e808:	nop    DWORD PTR [rax+rax*1+0x0]
  40e810:	mov    r11,rdx
  40e813:	movabs rdx,0x6666666666666667
  40e81d:	mov    r15,rax
  40e820:	mov    rax,r11
  40e823:	imul   rdx
  40e826:	mov    r12,rdx
  40e829:	mov    rax,r15
  40e82c:	sar    r12,0x2
  40e830:	mov    rdx,r12
  40e833:	shr    rdx,0x3f
  40e837:	add    r12,rdx
  40e83a:	mov    rdx,r12
  40e83d:	imul   r13,r12,0xa
  40e841:	sub    r11,r13
  40e844:	mov    r13,QWORD PTR [rip+0x4f1d]        # 413768 <__swc_rdata_base_6b1cf01f+0x658>
  40e84b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40e850:	mov    BYTE PTR [r9],r11b
  40e853:	lea    r11,[r9+0x1]
  40e857:	mov    r9,r11
  40e85a:	test   r12,r12
  40e85d:	jne    40e810 <__swc_fn_6b1cf01f_000148_6203dca2+0x7d0>
  40e85f:	test   r8,r8
  40e862:	jge    40e86c <__swc_fn_6b1cf01f_000148_6203dca2+0x82c>
  40e864:	mov    BYTE PTR [r11],0x2d
  40e868:	lea    r9,[r11+0x1]
  40e86c:	mov    rdx,r9
  40e86f:	mov    BYTE PTR [r9],0x0
  40e873:	sub    r9,0x1
  40e877:	mov    r8,rcx
  40e87a:	cmp    r8,r9
  40e87d:	jae    40e898 <__swc_fn_6b1cf01f_000148_6203dca2+0x858>
  40e87f:	nop
  40e880:	mov    r11b,BYTE PTR [r9]
  40e883:	mov    r12b,BYTE PTR [r8]
  40e886:	mov    BYTE PTR [r9],r12b
  40e889:	sub    r9,0x1
  40e88d:	mov    BYTE PTR [r8],r11b
  40e890:	inc    r8
  40e893:	cmp    r8,r9
  40e896:	jb     40e880 <__swc_fn_6b1cf01f_000148_6203dca2+0x840>
  40e898:	mov    r9,rdx
  40e89b:	mov    BYTE PTR [r9],0x2e
  40e89f:	add    r9,0x1
  40e8a3:	xor    r8d,r8d
  40e8a6:	test   r10,r10
  40e8a9:	je     40e8ef <__swc_fn_6b1cf01f_000148_6203dca2+0x8af>
  40e8ab:	mov    r11d,0x989680
  40e8b1:	cmp    r10,r11
  40e8b4:	jge    40e8ef <__swc_fn_6b1cf01f_000148_6203dca2+0x8af>
  40e8b6:	cs nop WORD PTR [rax+rax*1+0x0]
  40e8c0:	inc    r8d
  40e8c3:	movabs rdx,0x6666666666666667
  40e8cd:	mov    r15,rax
  40e8d0:	mov    rax,r11
  40e8d3:	imul   rdx
  40e8d6:	mov    r11,rdx
  40e8d9:	mov    rax,r15
  40e8dc:	sar    r11,0x2
  40e8e0:	mov    rdx,r11
  40e8e3:	shr    rdx,0x3f
  40e8e7:	add    r11,rdx
  40e8ea:	cmp    r10,r11
  40e8ed:	jl     40e8c0 <__swc_fn_6b1cf01f_000148_6203dca2+0x880>
  40e8ef:	test   r8d,r8d
  40e8f2:	je     40e90d <__swc_fn_6b1cf01f_000148_6203dca2+0x8cd>
  40e8f4:	cs nop WORD PTR [rax+rax*1+0x0]
  40e8fe:	xchg   ax,ax
  40e900:	mov    BYTE PTR [r9],0x30
  40e904:	add    r9,0x1
  40e908:	dec    r8d
  40e90b:	jne    40e900 <__swc_fn_6b1cf01f_000148_6203dca2+0x8c0>
  40e90d:	mov    r8,r9
  40e910:	mov    rdx,r10
  40e913:	cs nop WORD PTR [rax+rax*1+0x0]
  40e91d:	nop    DWORD PTR [rax]
  40e920:	mov    r11,rdx
  40e923:	movabs rdx,0x6666666666666667
  40e92d:	mov    rax,r11
  40e930:	imul   rdx
  40e933:	sar    rdx,0x2
  40e937:	mov    r12,rdx
  40e93a:	shr    rdx,0x3f
  40e93e:	add    r12,rdx
  40e941:	mov    rdx,r12
  40e944:	imul   r13,r12,0xa
  40e948:	sub    r11,r13
  40e94b:	mov    r13,QWORD PTR [rip+0x4e16]        # 413768 <__swc_rdata_base_6b1cf01f+0x658>
  40e952:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40e957:	mov    BYTE PTR [r8],r11b
  40e95a:	lea    r11,[r8+0x1]
  40e95e:	mov    r8,r11
  40e961:	test   r12,r12
  40e964:	jne    40e920 <__swc_fn_6b1cf01f_000148_6203dca2+0x8e0>
  40e966:	test   r10,r10
  40e969:	jge    40e973 <__swc_fn_6b1cf01f_000148_6203dca2+0x933>
  40e96b:	mov    BYTE PTR [r11],0x2d
  40e96f:	lea    r8,[r11+0x1]
  40e973:	mov    BYTE PTR [r8],0x0
  40e977:	sub    r8,0x1
  40e97b:	cmp    r9,r8
  40e97e:	jae    40e998 <__swc_fn_6b1cf01f_000148_6203dca2+0x958>
  40e980:	mov    al,BYTE PTR [r8]
  40e983:	mov    dl,BYTE PTR [r9]
  40e986:	mov    BYTE PTR [r8],dl
  40e989:	sub    r8,0x1
  40e98d:	mov    BYTE PTR [r9],al
  40e990:	inc    r9
  40e993:	cmp    r9,r8
  40e996:	jb     40e980 <__swc_fn_6b1cf01f_000148_6203dca2+0x940>
  40e998:	xor    eax,eax
  40e99a:	test   rcx,rcx
  40e99d:	je     40e9d0 <__swc_fn_6b1cf01f_000148_6203dca2+0x990>
  40e99f:	mov    rdx,rcx
  40e9a2:	mov    r8b,BYTE PTR [rdx]
  40e9a5:	test   r8b,r8b
  40e9a8:	je     40e9d0 <__swc_fn_6b1cf01f_000148_6203dca2+0x990>
  40e9aa:	cs nop WORD PTR [rax+rax*1+0x0]
  40e9b4:	cs nop WORD PTR [rax+rax*1+0x0]
  40e9be:	xchg   ax,ax
  40e9c0:	add    rdx,0x1
  40e9c4:	add    rax,0x1
  40e9c8:	mov    r8b,BYTE PTR [rdx]
  40e9cb:	test   r8b,r8b
  40e9ce:	jne    40e9c0 <__swc_fn_6b1cf01f_000148_6203dca2+0x980>
  40e9d0:	mov    QWORD PTR [rsp+0x240],rcx
  40e9d8:	mov    QWORD PTR [rsp+0x248],rax
  40e9e0:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  40e9e9:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  40e9f2:	lea    rcx,[rsp+0x250]
  40e9fa:	call   40d7d0 <__swc_fn_6b1cf01f_000118_2648f149>
  40e9ff:	jmp    40f105 <__swc_fn_6b1cf01f_000148_6203dca2+0x10c5>
  40ea04:	lea    rcx,[rsp+0x260]
  40ea0c:	vxorps xmm0,xmm0,xmm0
  40ea10:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  40ea19:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  40ea22:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  40ea2b:	vzeroupper
  40ea2e:	mov    DWORD PTR [rsp+0x2c0],0x0
  40ea39:	vmovsd xmm0,QWORD PTR [rdx]
  40ea3d:	vcomisd xmm0,xmm0
  40ea41:	setne  dl
  40ea44:	movzx  edx,dl
  40ea47:	setp   r8b
  40ea4b:	movzx  r8d,r8b
  40ea4f:	or     edx,r8d
  40ea52:	test   dl,dl
  40ea54:	je     40ea61 <__swc_fn_6b1cf01f_000148_6203dca2+0xa21>
  40ea56:	mov    DWORD PTR [rcx],0x6e616e
  40ea5c:	jmp    40f068 <__swc_fn_6b1cf01f_000148_6203dca2+0x1028>
  40ea61:	vcomisd xmm0,xmm11
  40ea66:	ja     40ea77 <__swc_fn_6b1cf01f_000148_6203dca2+0xa37>
  40ea68:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  40ea71:	vcomisd xmm6,xmm0
  40ea75:	jbe    40ea9b <__swc_fn_6b1cf01f_000148_6203dca2+0xa5b>
  40ea77:	vxorpd xmm1,xmm1,xmm1
  40ea7b:	vcomisd xmm1,xmm0
  40ea7f:	jbe    40ea90 <__swc_fn_6b1cf01f_000148_6203dca2+0xa50>
  40ea81:	mov    DWORD PTR [rcx],0x666e692d
  40ea87:	mov    BYTE PTR [rcx+0x4],0x0
  40ea8b:	jmp    40f068 <__swc_fn_6b1cf01f_000148_6203dca2+0x1028>
  40ea90:	mov    DWORD PTR [rcx],0x666e69
  40ea96:	jmp    40f068 <__swc_fn_6b1cf01f_000148_6203dca2+0x1028>
  40ea9b:	vcomisd xmm0,xmm13
  40eaa0:	jae    40eaac <__swc_fn_6b1cf01f_000148_6203dca2+0xa6c>
  40eaa2:	vcomisd xmm12,xmm0
  40eaa6:	jbe    40ee0e <__swc_fn_6b1cf01f_000148_6203dca2+0xdce>
  40eaac:	vmovups xmm1,xmm0
  40eab0:	vxorpd xmm2,xmm2,xmm2
  40eab4:	vcomisd xmm2,xmm0
  40eab8:	jbe    40eac8 <__swc_fn_6b1cf01f_000148_6203dca2+0xa88>
  40eaba:	vmovsd xmm0,xmm0,xmm1
  40eabe:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x477a]        # 413240 <__swc_rdata_base_6b1cf01f+0x130>
  40eac6:	jmp    40eacc <__swc_fn_6b1cf01f_000148_6203dca2+0xa8c>
  40eac8:	vmovsd xmm0,xmm0,xmm1
  40eacc:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  40ead5:	xor    r8d,r8d
  40ead8:	vcomisd xmm0,xmm6
  40eadc:	jb     40eaee <__swc_fn_6b1cf01f_000148_6203dca2+0xaae>
  40eade:	xchg   ax,ax
  40eae0:	vdivsd xmm0,xmm0,xmm6
  40eae4:	add    r8,0x1
  40eae8:	vcomisd xmm0,xmm6
  40eaec:	jae    40eae0 <__swc_fn_6b1cf01f_000148_6203dca2+0xaa0>
  40eaee:	mov    r9,rcx
  40eaf1:	vxorpd xmm2,xmm2,xmm2
  40eaf5:	vcomisd xmm2,xmm1
  40eaf9:	jbe    40eb02 <__swc_fn_6b1cf01f_000148_6203dca2+0xac2>
  40eafb:	mov    BYTE PTR [rcx],0x2d
  40eafe:	lea    r9,[rcx+0x1]
  40eb02:	vcvttsd2si rdx,xmm0
  40eb07:	mov    r10b,dl
  40eb0a:	add    r10b,0x30
  40eb0e:	mov    BYTE PTR [r9],r10b
  40eb11:	vxorpd xmm1,xmm1,xmm1
  40eb15:	movzx  edx,dl
  40eb18:	vcvtsi2sd xmm1,xmm1,rdx
  40eb1d:	vsubsd xmm0,xmm0,xmm1
  40eb21:	vmulsd xmm0,xmm0,xmm6
  40eb25:	mov    BYTE PTR [r9+0x1],0x2e
  40eb2a:	vcvttsd2si rdx,xmm0
  40eb2f:	mov    r10b,dl
  40eb32:	add    r10b,0x30
  40eb36:	mov    BYTE PTR [r9+0x2],r10b
  40eb3a:	vxorpd xmm1,xmm1,xmm1
  40eb3e:	movzx  edx,dl
  40eb41:	vcvtsi2sd xmm1,xmm1,rdx
  40eb46:	vsubsd xmm0,xmm0,xmm1
  40eb4a:	vmulsd xmm0,xmm0,xmm6
  40eb4e:	vcvttsd2si rdx,xmm0
  40eb53:	mov    r10b,dl
  40eb56:	add    r10b,0x30
  40eb5a:	mov    BYTE PTR [r9+0x3],r10b
  40eb5e:	vxorpd xmm1,xmm1,xmm1
  40eb62:	movzx  edx,dl
  40eb65:	vcvtsi2sd xmm1,xmm1,rdx
  40eb6a:	vsubsd xmm0,xmm0,xmm1
  40eb6e:	vmulsd xmm0,xmm0,xmm6
  40eb72:	vcvttsd2si rdx,xmm0
  40eb77:	mov    r10b,dl
  40eb7a:	add    r10b,0x30
  40eb7e:	mov    BYTE PTR [r9+0x4],r10b
  40eb82:	vxorpd xmm1,xmm1,xmm1
  40eb86:	movzx  edx,dl
  40eb89:	vcvtsi2sd xmm1,xmm1,rdx
  40eb8e:	vsubsd xmm0,xmm0,xmm1
  40eb92:	vmulsd xmm0,xmm0,xmm6
  40eb96:	vcvttsd2si rdx,xmm0
  40eb9b:	mov    r10b,dl
  40eb9e:	add    r10b,0x30
  40eba2:	mov    BYTE PTR [r9+0x5],r10b
  40eba6:	vxorpd xmm1,xmm1,xmm1
  40ebaa:	movzx  edx,dl
  40ebad:	vcvtsi2sd xmm1,xmm1,rdx
  40ebb2:	vsubsd xmm0,xmm0,xmm1
  40ebb6:	vmulsd xmm0,xmm0,xmm6
  40ebba:	vcvttsd2si rdx,xmm0
  40ebbf:	mov    r10b,dl
  40ebc2:	add    r10b,0x30
  40ebc6:	mov    BYTE PTR [r9+0x6],r10b
  40ebca:	vxorpd xmm1,xmm1,xmm1
  40ebce:	movzx  edx,dl
  40ebd1:	vcvtsi2sd xmm1,xmm1,rdx
  40ebd6:	vsubsd xmm0,xmm0,xmm1
  40ebda:	vmulsd xmm0,xmm0,xmm6
  40ebde:	vcvttsd2si rdx,xmm0
  40ebe3:	mov    r10b,dl
  40ebe6:	add    r10b,0x30
  40ebea:	mov    BYTE PTR [r9+0x7],r10b
  40ebee:	vxorpd xmm1,xmm1,xmm1
  40ebf2:	movzx  edx,dl
  40ebf5:	vcvtsi2sd xmm1,xmm1,rdx
  40ebfa:	vsubsd xmm0,xmm0,xmm1
  40ebfe:	vmulsd xmm0,xmm0,xmm6
  40ec02:	vcvttsd2si rdx,xmm0
  40ec07:	mov    r10b,dl
  40ec0a:	add    r10b,0x30
  40ec0e:	mov    BYTE PTR [r9+0x8],r10b
  40ec12:	vxorpd xmm1,xmm1,xmm1
  40ec16:	movzx  edx,dl
  40ec19:	vcvtsi2sd xmm1,xmm1,rdx
  40ec1e:	vsubsd xmm0,xmm0,xmm1
  40ec22:	vmulsd xmm0,xmm0,xmm6
  40ec26:	vcvttsd2si rdx,xmm0
  40ec2b:	mov    r10b,dl
  40ec2e:	add    r10b,0x30
  40ec32:	mov    BYTE PTR [r9+0x9],r10b
  40ec36:	vxorpd xmm1,xmm1,xmm1
  40ec3a:	movzx  edx,dl
  40ec3d:	vcvtsi2sd xmm1,xmm1,rdx
  40ec42:	vsubsd xmm0,xmm0,xmm1
  40ec46:	vmulsd xmm0,xmm0,xmm6
  40ec4a:	vcvttsd2si rdx,xmm0
  40ec4f:	mov    r10b,dl
  40ec52:	add    r10b,0x30
  40ec56:	mov    BYTE PTR [r9+0xa],r10b
  40ec5a:	vxorpd xmm1,xmm1,xmm1
  40ec5e:	movzx  edx,dl
  40ec61:	vcvtsi2sd xmm1,xmm1,rdx
  40ec66:	vsubsd xmm0,xmm0,xmm1
  40ec6a:	vmulsd xmm0,xmm0,xmm6
  40ec6e:	vcvttsd2si rdx,xmm0
  40ec73:	mov    r10b,dl
  40ec76:	add    r10b,0x30
  40ec7a:	mov    BYTE PTR [r9+0xb],r10b
  40ec7e:	lea    r10,[r9+0x4]
  40ec82:	vxorpd xmm1,xmm1,xmm1
  40ec86:	movzx  edx,dl
  40ec89:	vcvtsi2sd xmm1,xmm1,rdx
  40ec8e:	vsubsd xmm0,xmm0,xmm1
  40ec92:	vmulsd xmm0,xmm0,xmm6
  40ec96:	vcvttsd2si rdx,xmm0
  40ec9b:	mov    r11b,dl
  40ec9e:	add    r11b,0x30
  40eca2:	mov    BYTE PTR [r9+0xc],r11b
  40eca6:	vxorpd xmm1,xmm1,xmm1
  40ecaa:	movzx  edx,dl
  40ecad:	vcvtsi2sd xmm1,xmm1,rdx
  40ecb2:	vsubsd xmm0,xmm0,xmm1
  40ecb6:	vmulsd xmm0,xmm0,xmm6
  40ecba:	vcvttsd2si rdx,xmm0
  40ecbf:	mov    r11b,dl
  40ecc2:	add    r11b,0x30
  40ecc6:	mov    BYTE PTR [r9+0xd],r11b
  40ecca:	lea    r10,[r10+0x2]
  40ecce:	vxorpd xmm1,xmm1,xmm1
  40ecd2:	movzx  edx,dl
  40ecd5:	vcvtsi2sd xmm1,xmm1,rdx
  40ecda:	vsubsd xmm0,xmm0,xmm1
  40ecde:	vmulsd xmm0,xmm0,xmm6
  40ece2:	vcvttsd2si rdx,xmm0
  40ece7:	mov    r11b,dl
  40ecea:	add    r11b,0x30
  40ecee:	mov    BYTE PTR [r9+0xe],r11b
  40ecf2:	vxorpd xmm1,xmm1,xmm1
  40ecf6:	movzx  edx,dl
  40ecf9:	vcvtsi2sd xmm1,xmm1,rdx
  40ecfe:	vsubsd xmm0,xmm0,xmm1
  40ed02:	vmulsd xmm0,xmm0,xmm6
  40ed06:	vcvttsd2si rdx,xmm0
  40ed0b:	mov    r11b,dl
  40ed0e:	add    r11b,0x30
  40ed12:	mov    BYTE PTR [r9+0xf],r11b
  40ed16:	lea    r10,[r10+0x2]
  40ed1a:	lea    r10,[r10+0x2]
  40ed1e:	lea    r10,[r10+0x2]
  40ed22:	lea    r10,[r10+0x2]
  40ed26:	lea    r10,[r10+0x2]
  40ed2a:	vxorpd xmm1,xmm1,xmm1
  40ed2e:	movzx  edx,dl
  40ed31:	vcvtsi2sd xmm1,xmm1,rdx
  40ed36:	vsubsd xmm0,xmm0,xmm1
  40ed3a:	vmulsd xmm0,xmm0,xmm6
  40ed3e:	vcvttsd2si rdx,xmm0
  40ed43:	mov    r11b,dl
  40ed46:	add    r11b,0x30
  40ed4a:	mov    BYTE PTR [r9+0x10],r11b
  40ed4e:	vxorpd xmm1,xmm1,xmm1
  40ed52:	movzx  edx,dl
  40ed55:	vcvtsi2sd xmm1,xmm1,rdx
  40ed5a:	vsubsd xmm0,xmm0,xmm1
  40ed5e:	vmulsd xmm0,xmm0,xmm6
  40ed62:	vcvttsd2si rdx,xmm0
  40ed67:	add    dl,0x30
  40ed6a:	mov    BYTE PTR [r9+0x11],dl
  40ed6e:	mov    BYTE PTR [r10+0x2],0x65
  40ed73:	lea    r9,[r10+0x3]
  40ed77:	test   r8,r8
  40ed7a:	jl     40ed83 <__swc_fn_6b1cf01f_000148_6203dca2+0xd43>
  40ed7c:	mov    BYTE PTR [r9],0x2b
  40ed80:	inc    r9
  40ed83:	mov    r10,r9
  40ed86:	mov    rdx,r8
  40ed89:	nop    DWORD PTR [rax+0x0]
  40ed90:	mov    r11,rdx
  40ed93:	movabs rdx,0x6666666666666667
  40ed9d:	mov    rax,r11
  40eda0:	imul   rdx
  40eda3:	sar    rdx,0x2
  40eda7:	mov    r12,rdx
  40edaa:	shr    rdx,0x3f
  40edae:	add    r12,rdx
  40edb1:	mov    rdx,r12
  40edb4:	imul   r13,r12,0xa
  40edb8:	sub    r11,r13
  40edbb:	mov    r13,QWORD PTR [rip+0x49a6]        # 413768 <__swc_rdata_base_6b1cf01f+0x658>
  40edc2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40edc7:	mov    BYTE PTR [r10],r11b
  40edca:	lea    r11,[r10+0x1]
  40edce:	mov    r10,r11
  40edd1:	test   r12,r12
  40edd4:	jne    40ed90 <__swc_fn_6b1cf01f_000148_6203dca2+0xd50>
  40edd6:	test   r8,r8
  40edd9:	jge    40ede3 <__swc_fn_6b1cf01f_000148_6203dca2+0xda3>
  40eddb:	mov    BYTE PTR [r11],0x2d
  40eddf:	lea    r10,[r11+0x1]
  40ede3:	mov    BYTE PTR [r10],0x0
  40ede7:	sub    r10,0x1
  40edeb:	nop    DWORD PTR [rax+rax*1+0x0]
  40edf0:	cmp    r9,r10
  40edf3:	jae    40f068 <__swc_fn_6b1cf01f_000148_6203dca2+0x1028>
  40edf9:	mov    al,BYTE PTR [r10]
  40edfc:	mov    dl,BYTE PTR [r9]
  40edff:	mov    BYTE PTR [r10],dl
  40ee02:	sub    r10,0x1
  40ee06:	mov    BYTE PTR [r9],al
  40ee09:	inc    r9
  40ee0c:	jmp    40edf0 <__swc_fn_6b1cf01f_000148_6203dca2+0xdb0>
  40ee0e:	vcvttsd2si rdx,xmm0
  40ee13:	mov    r8,rdx
  40ee16:	vxorpd xmm1,xmm1,xmm1
  40ee1a:	vcvtsi2sd xmm1,xmm1,rdx
  40ee1f:	vsubsd xmm1,xmm0,xmm1
  40ee23:	mov    r9d,0x8
  40ee29:	vxorpd xmm2,xmm2,xmm2
  40ee2d:	vcomisd xmm2,xmm1
  40ee31:	ja     40ee3e <__swc_fn_6b1cf01f_000148_6203dca2+0xdfe>
  40ee33:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40ee3c:	jmp    40ee4f <__swc_fn_6b1cf01f_000148_6203dca2+0xe0f>
  40ee3e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x43fa]        # 413240 <__swc_rdata_base_6b1cf01f+0x130>
  40ee46:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40ee4f:	test   r9d,r9d
  40ee52:	je     40ee69 <__swc_fn_6b1cf01f_000148_6203dca2+0xe29>
  40ee54:	cs nop WORD PTR [rax+rax*1+0x0]
  40ee5e:	xchg   ax,ax
  40ee60:	vmulsd xmm1,xmm1,xmm6
  40ee64:	dec    r9d
  40ee67:	jne    40ee60 <__swc_fn_6b1cf01f_000148_6203dca2+0xe20>
  40ee69:	vcvttsd2si r9,xmm1
  40ee6e:	mov    r10,r9
  40ee71:	vxorpd xmm2,xmm2,xmm2
  40ee75:	vcvtsi2sd xmm2,xmm2,r9
  40ee7a:	vsubsd xmm1,xmm1,xmm2
  40ee7e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  40ee87:	vcomisd xmm1,xmm6
  40ee8b:	lea    r9,[r9+0x1]
  40ee8f:	cmova  r10,r9
  40ee93:	cmp    r10,0x5f5e100
  40ee9a:	jne    40eeb3 <__swc_fn_6b1cf01f_000148_6203dca2+0xe73>
  40ee9c:	lea    r8,[rdx-0x1]
  40eea0:	vxorpd xmm1,xmm1,xmm1
  40eea4:	vcomisd xmm1,xmm0
  40eea8:	lea    rdx,[rdx+0x1]
  40eeac:	cmovbe r8,rdx
  40eeb0:	xor    r10d,r10d
  40eeb3:	mov    r9,rcx
  40eeb6:	test   r8,r8
  40eeb9:	jne    40eed9 <__swc_fn_6b1cf01f_000148_6203dca2+0xe99>
  40eebb:	vxorpd xmm1,xmm1,xmm1
  40eebf:	vcomisd xmm1,xmm0
  40eec3:	jbe    40eecc <__swc_fn_6b1cf01f_000148_6203dca2+0xe8c>
  40eec5:	mov    BYTE PTR [rcx],0x2d
  40eec8:	lea    r9,[rcx+0x1]
  40eecc:	mov    BYTE PTR [r9],0x30
  40eed0:	add    r9,0x1
  40eed4:	jmp    40ef6b <__swc_fn_6b1cf01f_000148_6203dca2+0xf2b>
  40eed9:	mov    r9,rcx
  40eedc:	mov    rdx,r8
  40eedf:	nop
  40eee0:	mov    r11,rdx
  40eee3:	movabs rdx,0x6666666666666667
  40eeed:	mov    r15,rax
  40eef0:	mov    rax,r11
  40eef3:	imul   rdx
  40eef6:	mov    r12,rdx
  40eef9:	mov    rax,r15
  40eefc:	sar    r12,0x2
  40ef00:	mov    rdx,r12
  40ef03:	shr    rdx,0x3f
  40ef07:	add    r12,rdx
  40ef0a:	mov    rdx,r12
  40ef0d:	imul   r13,r12,0xa
  40ef11:	sub    r11,r13
  40ef14:	mov    r13,QWORD PTR [rip+0x484d]        # 413768 <__swc_rdata_base_6b1cf01f+0x658>
  40ef1b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40ef20:	mov    BYTE PTR [r9],r11b
  40ef23:	lea    r11,[r9+0x1]
  40ef27:	mov    r9,r11
  40ef2a:	test   r12,r12
  40ef2d:	jne    40eee0 <__swc_fn_6b1cf01f_000148_6203dca2+0xea0>
  40ef2f:	test   r8,r8
  40ef32:	jge    40ef3c <__swc_fn_6b1cf01f_000148_6203dca2+0xefc>
  40ef34:	mov    BYTE PTR [r11],0x2d
  40ef38:	lea    r9,[r11+0x1]
  40ef3c:	mov    rdx,r9
  40ef3f:	mov    BYTE PTR [r9],0x0
  40ef43:	sub    r9,0x1
  40ef47:	mov    r8,rcx
  40ef4a:	cmp    r8,r9
  40ef4d:	jae    40ef68 <__swc_fn_6b1cf01f_000148_6203dca2+0xf28>
  40ef4f:	nop
  40ef50:	mov    r11b,BYTE PTR [r9]
  40ef53:	mov    r12b,BYTE PTR [r8]
  40ef56:	mov    BYTE PTR [r9],r12b
  40ef59:	sub    r9,0x1
  40ef5d:	mov    BYTE PTR [r8],r11b
  40ef60:	inc    r8
  40ef63:	cmp    r8,r9
  40ef66:	jb     40ef50 <__swc_fn_6b1cf01f_000148_6203dca2+0xf10>
  40ef68:	mov    r9,rdx
  40ef6b:	mov    BYTE PTR [r9],0x2e
  40ef6f:	add    r9,0x1
  40ef73:	xor    r8d,r8d
  40ef76:	test   r10,r10
  40ef79:	je     40efbf <__swc_fn_6b1cf01f_000148_6203dca2+0xf7f>
  40ef7b:	mov    r11d,0x989680
  40ef81:	cmp    r10,r11
  40ef84:	jge    40efbf <__swc_fn_6b1cf01f_000148_6203dca2+0xf7f>
  40ef86:	cs nop WORD PTR [rax+rax*1+0x0]
  40ef90:	inc    r8d
  40ef93:	movabs rdx,0x6666666666666667
  40ef9d:	mov    r15,rax
  40efa0:	mov    rax,r11
  40efa3:	imul   rdx
  40efa6:	mov    r11,rdx
  40efa9:	mov    rax,r15
  40efac:	sar    r11,0x2
  40efb0:	mov    rdx,r11
  40efb3:	shr    rdx,0x3f
  40efb7:	add    r11,rdx
  40efba:	cmp    r10,r11
  40efbd:	jl     40ef90 <__swc_fn_6b1cf01f_000148_6203dca2+0xf50>
  40efbf:	test   r8d,r8d
  40efc2:	je     40efdd <__swc_fn_6b1cf01f_000148_6203dca2+0xf9d>
  40efc4:	cs nop WORD PTR [rax+rax*1+0x0]
  40efce:	xchg   ax,ax
  40efd0:	mov    BYTE PTR [r9],0x30
  40efd4:	add    r9,0x1
  40efd8:	dec    r8d
  40efdb:	jne    40efd0 <__swc_fn_6b1cf01f_000148_6203dca2+0xf90>
  40efdd:	mov    r8,r9
  40efe0:	mov    rdx,r10
  40efe3:	cs nop WORD PTR [rax+rax*1+0x0]
  40efed:	nop    DWORD PTR [rax]
  40eff0:	mov    r11,rdx
  40eff3:	movabs rdx,0x6666666666666667
  40effd:	mov    rax,r11
  40f000:	imul   rdx
  40f003:	sar    rdx,0x2
  40f007:	mov    r12,rdx
  40f00a:	shr    rdx,0x3f
  40f00e:	add    r12,rdx
  40f011:	mov    rdx,r12
  40f014:	imul   r13,r12,0xa
  40f018:	sub    r11,r13
  40f01b:	mov    r13,QWORD PTR [rip+0x4746]        # 413768 <__swc_rdata_base_6b1cf01f+0x658>
  40f022:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40f027:	mov    BYTE PTR [r8],r11b
  40f02a:	lea    r11,[r8+0x1]
  40f02e:	mov    r8,r11
  40f031:	test   r12,r12
  40f034:	jne    40eff0 <__swc_fn_6b1cf01f_000148_6203dca2+0xfb0>
  40f036:	test   r10,r10
  40f039:	jge    40f043 <__swc_fn_6b1cf01f_000148_6203dca2+0x1003>
  40f03b:	mov    BYTE PTR [r11],0x2d
  40f03f:	lea    r8,[r11+0x1]
  40f043:	mov    BYTE PTR [r8],0x0
  40f047:	sub    r8,0x1
  40f04b:	cmp    r9,r8
  40f04e:	jae    40f068 <__swc_fn_6b1cf01f_000148_6203dca2+0x1028>
  40f050:	mov    al,BYTE PTR [r8]
  40f053:	mov    dl,BYTE PTR [r9]
  40f056:	mov    BYTE PTR [r8],dl
  40f059:	sub    r8,0x1
  40f05d:	mov    BYTE PTR [r9],al
  40f060:	inc    r9
  40f063:	cmp    r9,r8
  40f066:	jb     40f050 <__swc_fn_6b1cf01f_000148_6203dca2+0x1010>
  40f068:	xor    eax,eax
  40f06a:	test   rcx,rcx
  40f06d:	je     40f090 <__swc_fn_6b1cf01f_000148_6203dca2+0x1050>
  40f06f:	mov    rdx,rcx
  40f072:	mov    r8b,BYTE PTR [rdx]
  40f075:	test   r8b,r8b
  40f078:	je     40f090 <__swc_fn_6b1cf01f_000148_6203dca2+0x1050>
  40f07a:	nop    WORD PTR [rax+rax*1+0x0]
  40f080:	add    rdx,0x1
  40f084:	add    rax,0x1
  40f088:	mov    r8b,BYTE PTR [rdx]
  40f08b:	test   r8b,r8b
  40f08e:	jne    40f080 <__swc_fn_6b1cf01f_000148_6203dca2+0x1040>
  40f090:	mov    QWORD PTR [rsp+0x3f8],rcx
  40f098:	mov    QWORD PTR [rsp+0x400],rax
  40f0a0:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  40f0a9:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  40f0b2:	lea    rcx,[rsp+0x408]
  40f0ba:	call   40d7d0 <__swc_fn_6b1cf01f_000118_2648f149>
  40f0bf:	jmp    40f105 <__swc_fn_6b1cf01f_000148_6203dca2+0x10c5>
  40f0c1:	mov    rcx,rdx
  40f0c4:	call   40d7d0 <__swc_fn_6b1cf01f_000118_2648f149>
  40f0c9:	jmp    40f105 <__swc_fn_6b1cf01f_000148_6203dca2+0x10c5>
  40f0cb:	mov    al,BYTE PTR [rdx]
  40f0cd:	test   al,al
  40f0cf:	je     40f0da <__swc_fn_6b1cf01f_000148_6203dca2+0x109a>
  40f0d1:	lea    rax,[rip+0x46a0]        # 413778 <__swc_rdata_base_6b1cf01f+0x668>
  40f0d8:	jmp    40f0e1 <__swc_fn_6b1cf01f_000148_6203dca2+0x10a1>
  40f0da:	lea    rax,[rip+0x46a7]        # 413788 <__swc_rdata_base_6b1cf01f+0x678>
  40f0e1:	mov    rcx,rax
  40f0e4:	call   40d7d0 <__swc_fn_6b1cf01f_000118_2648f149>
  40f0e9:	jmp    40f105 <__swc_fn_6b1cf01f_000148_6203dca2+0x10c5>
  40f0eb:	lea    rcx,[rip+0x46a6]        # 413798 <__swc_rdata_base_6b1cf01f+0x688>
  40f0f2:	call   40d7d0 <__swc_fn_6b1cf01f_000118_2648f149>
  40f0f7:	jmp    40f105 <__swc_fn_6b1cf01f_000148_6203dca2+0x10c5>
  40f0f9:	lea    rcx,[rip+0x4698]        # 413798 <__swc_rdata_base_6b1cf01f+0x688>
  40f100:	call   40d7d0 <__swc_fn_6b1cf01f_000118_2648f149>
  40f105:	add    rdi,0x1
  40f109:	sub    rsi,0x1
  40f10d:	vmovups xmm0,xmm12
  40f112:	vmovsd xmm6,QWORD PTR [rip+0x468e]        # 4137a8 <__swc_rdata_base_6b1cf01f+0x698>
  40f11a:	test   rsi,rsi
  40f11d:	jne    40e150 <__swc_fn_6b1cf01f_000148_6203dca2+0x110>
  40f123:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  40f12c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  40f135:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  40f13e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  40f147:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  40f150:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  40f159:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  40f162:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  40f16b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  40f174:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  40f17d:	add    rsp,0x4e8
  40f184:	pop    r15
  40f186:	pop    r13
  40f188:	pop    r12
  40f18a:	pop    rdi
  40f18b:	pop    rsi
  40f18c:	pop    rbx
  40f18d:	ret
	...

000000000040f190 <__swc_fn_6b1cf01f_000151_86f1d437>:
  40f190:	vxorps xmm0,xmm0,xmm0
  40f194:	vmovups XMMWORD PTR [rcx],xmm0
  40f198:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f19d:	ret
	...

000000000040f1a0 <__swc_fn_6b1cf01f_000154_86f1d437>:
  40f1a0:	vxorps xmm0,xmm0,xmm0
  40f1a4:	vmovups XMMWORD PTR [rcx],xmm0
  40f1a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f1ad:	vxorps xmm0,xmm0,xmm0
  40f1b1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40f1b6:	vmovups xmm0,XMMWORD PTR [rip+0x46ea]        # 4138a8 <__swc_rdata_base_6b1cf01f+0x798>
  40f1be:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40f1c3:	vxorps xmm0,xmm0,xmm0
  40f1c7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40f1cc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40f1d1:	vxorps xmm0,xmm0,xmm0
  40f1d5:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40f1da:	mov    QWORD PTR [rcx+0x70],0x0
  40f1e2:	ret
	...

000000000040f1f0 <__swc_fn_6b1cf01f_000157_86f1d437>:
  40f1f0:	vxorps xmm0,xmm0,xmm0
  40f1f4:	vmovups XMMWORD PTR [rcx],xmm0
  40f1f8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f1fd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40f202:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40f207:	ret
	...

000000000040f210 <__swc_fn_6b1cf01f_000160_e36363a8>:
  40f210:	push   rsi
  40f211:	push   rdi
  40f212:	sub    rsp,0x8
  40f216:	mov    rsi,rcx
  40f219:	mov    rdi,QWORD PTR [rsi+0x50]
  40f21d:	test   rdi,rdi
  40f220:	je     40f227 <__swc_fn_6b1cf01f_000160_e36363a8+0x17>
  40f222:	mov    rcx,rsi
  40f225:	call   rdi
  40f227:	mov    QWORD PTR [rsi+0x20],0x0
  40f22f:	mov    rax,QWORD PTR [rsi+0x30]
  40f233:	test   rax,rax
  40f236:	je     40f264 <__swc_fn_6b1cf01f_000160_e36363a8+0x54>
  40f238:	nop    DWORD PTR [rax+rax*1+0x0]
  40f240:	mov    rdi,QWORD PTR [rax+0x8]
  40f244:	mov    rcx,rsi
  40f247:	mov    rdx,QWORD PTR [rax+0x10]
  40f24b:	mov    rax,QWORD PTR [rax+0x18]
  40f24f:	mov    r8,rax
  40f252:	call   412330 <__swc_fn_6b1cf01f_000158_47b270e1>
  40f257:	mov    QWORD PTR [rsi+0x30],rdi
  40f25b:	mov    rax,QWORD PTR [rsi+0x30]
  40f25f:	test   rax,rax
  40f262:	jne    40f240 <__swc_fn_6b1cf01f_000160_e36363a8+0x30>
  40f264:	mov    QWORD PTR [rsi+0x38],0x0
  40f26c:	add    rsp,0x8
  40f270:	pop    rdi
  40f271:	pop    rsi
  40f272:	ret
	...

000000000040f280 <__swc_fn_6b1cf01f_000163_016ee66a>:
  40f280:	push   rbx
  40f281:	push   rsi
  40f282:	push   rdi
  40f283:	push   r12
  40f285:	sub    rsp,0x188
  40f28c:	mov    rbx,rcx
  40f28f:	lea    rsi,[rip+0x17afa]        # 426d90 <__swc_bss_base_6b1cf01f+0x2d50>
  40f296:	mov    rcx,rsi
  40f299:	call   411d40 <__swc_fn_6b1cf01f_000137_86bb0f90>
  40f29e:	mov    rax,QWORD PTR [rip+0x17af3]        # 426d98 <__swc_bss_base_6b1cf01f+0x2d58>
  40f2a5:	mov    rdi,rax
  40f2a8:	test   rdi,rdi
  40f2ab:	je     40f2d9 <__swc_fn_6b1cf01f_000163_016ee66a+0x59>
  40f2ad:	nop    DWORD PTR [rax]
  40f2b0:	cmp    QWORD PTR [rdi+0x8],rbx
  40f2b4:	jne    40f2ce <__swc_fn_6b1cf01f_000163_016ee66a+0x4e>
  40f2b6:	mov    rcx,rsi
  40f2b9:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  40f2be:	mov    rax,rdi
  40f2c1:	add    rsp,0x188
  40f2c8:	pop    r12
  40f2ca:	pop    rdi
  40f2cb:	pop    rsi
  40f2cc:	pop    rbx
  40f2cd:	ret
  40f2ce:	mov    rax,QWORD PTR [rdi]
  40f2d1:	mov    rdi,rax
  40f2d4:	test   rax,rax
  40f2d7:	jne    40f2b0 <__swc_fn_6b1cf01f_000163_016ee66a+0x30>
  40f2d9:	call   409da0 <__swc_fn_6b1cf01f_000141_d299b428>
  40f2de:	mov    rdi,rax
  40f2e1:	test   rax,rax
  40f2e4:	jne    40f2fd <__swc_fn_6b1cf01f_000163_016ee66a+0x7d>
  40f2e6:	mov    rcx,rsi
  40f2e9:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  40f2ee:	xor    eax,eax
  40f2f0:	add    rsp,0x188
  40f2f7:	pop    r12
  40f2f9:	pop    rdi
  40f2fa:	pop    rsi
  40f2fb:	pop    rbx
  40f2fc:	ret
  40f2fd:	lea    rax,[rsp+0x18]
  40f302:	mov    QWORD PTR [rax+0x10],0x0
  40f30a:	mov    QWORD PTR [rax+0x18],0x0
  40f312:	mov    DWORD PTR [rax+0x20],0x0
  40f319:	mov    BYTE PTR [rax+0x24],0x0
  40f31d:	mov    rax,QWORD PTR [rip+0x17a74]        # 426d98 <__swc_bss_base_6b1cf01f+0x2d58>
  40f324:	mov    QWORD PTR [rsp+0x18],rax
  40f329:	mov    QWORD PTR [rsp+0x20],rbx
  40f32e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40f334:	vmovups XMMWORD PTR [rdi],xmm0
  40f338:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40f33e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  40f343:	mov    rax,QWORD PTR [rsp+0x38]
  40f348:	mov    QWORD PTR [rdi+0x20],rax
  40f34c:	mov    QWORD PTR [rip+0x17a45],rdi        # 426d98 <__swc_bss_base_6b1cf01f+0x2d58>
  40f353:	lea    rax,[rsp+0x40]
  40f358:	mov    QWORD PTR [rax],0x0
  40f35f:	mov    rcx,rbx
  40f362:	mov    rdx,rax
  40f365:	call   411e20 <__swc_fn_6b1cf01f_000143_1534de9a>
  40f36a:	mov    rbx,rax
  40f36d:	test   rax,rax
  40f370:	jne    40f38a <__swc_fn_6b1cf01f_000163_016ee66a+0x10a>
  40f372:	mov    rcx,rsi
  40f375:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  40f37a:	mov    rax,rdi
  40f37d:	add    rsp,0x188
  40f384:	pop    r12
  40f386:	pop    rdi
  40f387:	pop    rsi
  40f388:	pop    rbx
  40f389:	ret
  40f38a:	lea    r12,[rsp+0x50]
  40f38f:	mov    QWORD PTR [r12],0x0
  40f397:	mov    rcx,rbx
  40f39a:	mov    rdx,QWORD PTR [rsp+0x40]
  40f39f:	mov    r8,r12
  40f3a2:	call   409e50 <__swc_fn_6b1cf01f_000144_162f363d>
  40f3a7:	test   rax,rax
  40f3aa:	jne    40f3c4 <__swc_fn_6b1cf01f_000163_016ee66a+0x144>
  40f3ac:	mov    rcx,rsi
  40f3af:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  40f3b4:	mov    rax,rdi
  40f3b7:	add    rsp,0x188
  40f3be:	pop    r12
  40f3c0:	pop    rdi
  40f3c1:	pop    rsi
  40f3c2:	pop    rbx
  40f3c3:	ret
  40f3c4:	cmp    QWORD PTR [r12],0x10
  40f3c9:	jb     40f4cc <__swc_fn_6b1cf01f_000163_016ee66a+0x24c>
  40f3cf:	mov    ecx,DWORD PTR [rax]
  40f3d1:	cmp    ecx,0x42445753
  40f3d7:	jne    40f4cc <__swc_fn_6b1cf01f_000163_016ee66a+0x24c>
  40f3dd:	mov    ecx,DWORD PTR [rax+0x4]
  40f3e0:	cmp    ecx,0x1
  40f3e3:	jne    40f4cc <__swc_fn_6b1cf01f_000163_016ee66a+0x24c>
  40f3e9:	mov    ecx,DWORD PTR [rax+0x8]
  40f3ec:	mov    edx,DWORD PTR [rax+0xc]
  40f3ef:	imul   r8,rcx,0x14
  40f3f3:	mov    r9,QWORD PTR [rsp+0x50]
  40f3f8:	sub    r9,0x10
  40f3fc:	cmp    r8,r9
  40f3ff:	ja     40f4cc <__swc_fn_6b1cf01f_000163_016ee66a+0x24c>
  40f405:	lea    r8,[r8+0x10]
  40f409:	cmp    rdx,r8
  40f40c:	jb     40f4cc <__swc_fn_6b1cf01f_000163_016ee66a+0x24c>
  40f412:	mov    r8,QWORD PTR [rsp+0x50]
  40f417:	cmp    rdx,r8
  40f41a:	ja     40f4cc <__swc_fn_6b1cf01f_000163_016ee66a+0x24c>
  40f420:	xor    r8d,r8d
  40f423:	test   rcx,rcx
  40f426:	jbe    40f4f2 <__swc_fn_6b1cf01f_000163_016ee66a+0x272>
  40f42c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  40f432:	cs nop WORD PTR [rax+rax*1+0x0]
  40f43c:	nop    DWORD PTR [rax+0x0]
  40f440:	imul   r9,r8,0x14
  40f444:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  40f449:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  40f44e:	add    r10,r11
  40f451:	movabs r11,0x100000000
  40f45b:	cmp    r10,r11
  40f45e:	ja     40f4cc <__swc_fn_6b1cf01f_000163_016ee66a+0x24c>
  40f460:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  40f465:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  40f46a:	test   r10d,r10d
  40f46d:	setne  r11b
  40f471:	je     40f48b <__swc_fn_6b1cf01f_000163_016ee66a+0x20b>
  40f473:	cmp    r10d,edx
  40f476:	setb   r11b
  40f47a:	jb     40f48b <__swc_fn_6b1cf01f_000163_016ee66a+0x20b>
  40f47c:	vmovq  r11,xmm1
  40f481:	cmp    r10,r11
  40f484:	setae  r10b
  40f488:	mov    r11b,r10b
  40f48b:	mov    r10,r11
  40f48e:	test   r11b,r11b
  40f491:	jne    40f4b8 <__swc_fn_6b1cf01f_000163_016ee66a+0x238>
  40f493:	test   r9d,r9d
  40f496:	setne  r10b
  40f49a:	je     40f4b8 <__swc_fn_6b1cf01f_000163_016ee66a+0x238>
  40f49c:	cmp    r9d,edx
  40f49f:	setb   r10b
  40f4a3:	jb     40f4b8 <__swc_fn_6b1cf01f_000163_016ee66a+0x238>
  40f4a5:	vmovq  r10,xmm1
  40f4aa:	cmp    r9,r10
  40f4ad:	setae  r9b
  40f4b1:	movzx  r9d,r9b
  40f4b5:	mov    r10b,r9b
  40f4b8:	test   r10b,r10b
  40f4bb:	jne    40f4cc <__swc_fn_6b1cf01f_000163_016ee66a+0x24c>
  40f4bd:	add    r8,0x1
  40f4c1:	cmp    r8,rcx
  40f4c4:	jb     40f440 <__swc_fn_6b1cf01f_000163_016ee66a+0x1c0>
  40f4ca:	jmp    40f4f2 <__swc_fn_6b1cf01f_000163_016ee66a+0x272>
  40f4cc:	xor    ecx,ecx
  40f4ce:	cmp    rax,rbx
  40f4d1:	cmovne rcx,rax
  40f4d5:	call   40df90 <__swc_fn_6b1cf01f_000145_d7edc04f>
  40f4da:	mov    rcx,rsi
  40f4dd:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  40f4e2:	mov    rax,rdi
  40f4e5:	add    rsp,0x188
  40f4ec:	pop    r12
  40f4ee:	pop    rdi
  40f4ef:	pop    rsi
  40f4f0:	pop    rbx
  40f4f1:	ret
  40f4f2:	mov    QWORD PTR [rdi+0x10],rax
  40f4f6:	mov    rcx,QWORD PTR [rsp+0x50]
  40f4fb:	mov    QWORD PTR [rdi+0x18],rcx
  40f4ff:	mov    eax,DWORD PTR [rax+0x8]
  40f502:	mov    DWORD PTR [rdi+0x20],eax
  40f505:	rex mov BYTE PTR [rdi+0x24],0x1
  40f50a:	mov    rcx,rsi
  40f50d:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  40f512:	mov    rax,rdi
  40f515:	add    rsp,0x188
  40f51c:	pop    r12
  40f51e:	pop    rdi
  40f51f:	pop    rsi
  40f520:	pop    rbx
  40f521:	ret
	...

000000000040f530 <__swc_fn_6b1cf01f_000166_3459066f>:
  40f530:	push   rsi
  40f531:	push   rdi
  40f532:	push   r12
  40f534:	mov    rsi,rdx
  40f537:	mov    rdi,rcx
  40f53a:	mov    rcx,QWORD PTR [rip+0x177ff]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40f541:	test   rcx,rcx
  40f544:	jne    40f556 <__swc_fn_6b1cf01f_000166_3459066f+0x26>
  40f546:	call   412640 <__swc_fn_6b1cf01f_000167_994c8876>
  40f54b:	lea    rcx,[rax+0x1]
  40f54f:	mov    QWORD PTR [rip+0x177ea],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40f556:	dec    rcx
  40f559:	call   40f580 <__swc_fn_6b1cf01f_000169_360af05d>
  40f55e:	mov    r12,QWORD PTR [rax+0xbe0]
  40f565:	test   r12,r12
  40f568:	setne  al
  40f56b:	je     40f576 <__swc_fn_6b1cf01f_000166_3459066f+0x46>
  40f56d:	mov    rcx,rdi
  40f570:	mov    rdx,rsi
  40f573:	call   r12
  40f576:	pop    r12
  40f578:	pop    rdi
  40f579:	pop    rsi
  40f57a:	ret
  40f57b:	add    BYTE PTR [rax],al
  40f57d:	add    BYTE PTR [rax],al
	...

000000000040f580 <__swc_fn_6b1cf01f_000169_360af05d>:
  40f580:	push   r12
  40f582:	push   rdi
  40f583:	push   rsi
  40f584:	sub    rsp,0xd0
  40f58b:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40f591:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40f597:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40f59d:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40f5a3:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40f5a9:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40f5af:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40f5b8:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40f5c1:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40f5ca:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40f5d3:	mov    r12,rcx
  40f5d6:	mov    edi,ecx
  40f5d8:	xor    eax,eax
  40f5da:	call   407010 <pthread_getspecific@plt>
  40f5df:	test   rax,rax
  40f5e2:	je     40f5e6 <__swc_fn_6b1cf01f_000169_360af05d+0x66>
  40f5e4:	jmp    40f5ee <__swc_fn_6b1cf01f_000169_360af05d+0x6e>
  40f5e6:	mov    rcx,r12
  40f5e9:	call   4126a0 <__swc_fn_6b1cf01f_000170_cbeff767>
  40f5ee:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40f5f4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40f5fa:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40f600:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40f606:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40f60c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40f612:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40f61b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40f624:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40f62d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40f636:	add    rsp,0xd0
  40f63d:	pop    rsi
  40f63e:	pop    rdi
  40f63f:	pop    r12
  40f641:	ret
	...

000000000040f650 <__swc_fn_6b1cf01f_000172_5eac0ab4>:
  40f650:	push   rsi
  40f651:	sub    rsp,0x30
  40f655:	lea    rsi,[rip+0x1774c]        # 426da8 <__swc_bss_base_6b1cf01f+0x2d68>
  40f65c:	mov    rax,QWORD PTR [rsi]
  40f65f:	test   rax,rax
  40f662:	je     40f66a <__swc_fn_6b1cf01f_000172_5eac0ab4+0x1a>
  40f664:	add    rsp,0x30
  40f668:	pop    rsi
  40f669:	ret
  40f66a:	mov    ecx,0x3
  40f66f:	mov    edx,0x10
  40f674:	call   40d0f0 <__swc_fn_6b1cf01f_000109_6814119b>
  40f679:	test   rax,rax
  40f67c:	jne    40f68d <__swc_fn_6b1cf01f_000172_5eac0ab4+0x3d>
  40f67e:	mov    QWORD PTR [rsp+0x18],rax
  40f683:	call   4098f0 <__swc_fn_6b1cf01f_000120_be2e2f68>
  40f688:	mov    rax,QWORD PTR [rsp+0x18]
  40f68d:	mov    rcx,rax
  40f690:	xchg   QWORD PTR [rsi],rcx
  40f693:	add    rsp,0x30
  40f697:	pop    rsi
  40f698:	ret
  40f699:	add    BYTE PTR [rax],al
  40f69b:	add    BYTE PTR [rax],al
  40f69d:	add    BYTE PTR [rax],al
	...

000000000040f6a0 <__swc_fn_6b1cf01f_000175_cf4ffedd>:
  40f6a0:	push   rsi
  40f6a1:	push   rdi
  40f6a2:	sub    rsp,0x8
  40f6a6:	mov    rsi,rdx
  40f6a9:	mov    rdi,rcx
  40f6ac:	mov    rax,QWORD PTR [rsi+0x8]
  40f6b0:	test   rax,rax
  40f6b3:	je     40f6bd <__swc_fn_6b1cf01f_000175_cf4ffedd+0x1d>
  40f6b5:	mov    rcx,QWORD PTR [rsi]
  40f6b8:	mov    QWORD PTR [rax],rcx
  40f6bb:	jmp    40f6c4 <__swc_fn_6b1cf01f_000175_cf4ffedd+0x24>
  40f6bd:	mov    rax,QWORD PTR [rsi]
  40f6c0:	mov    QWORD PTR [rdi+0x8],rax
  40f6c4:	mov    rax,QWORD PTR [rsi]
  40f6c7:	test   rax,rax
  40f6ca:	je     40f6d4 <__swc_fn_6b1cf01f_000175_cf4ffedd+0x34>
  40f6cc:	mov    rcx,QWORD PTR [rsi+0x8]
  40f6d0:	mov    QWORD PTR [rax+0x8],rcx
  40f6d4:	mov    rcx,rdi
  40f6d7:	mov    rdx,QWORD PTR [rsi+0x10]
  40f6db:	mov    r8,QWORD PTR [rsi+0x18]
  40f6df:	mov    r9,0xffffffffffffffff
  40f6e6:	call   40a4a0 <__swc_fn_6b1cf01f_000174_4de704de>
  40f6eb:	mov    QWORD PTR [rsi+0x18],0x0
  40f6f3:	mov    rax,QWORD PTR [rdi+0x8]
  40f6f7:	test   rax,rax
  40f6fa:	jne    40f70c <__swc_fn_6b1cf01f_000175_cf4ffedd+0x6c>
  40f6fc:	call   40f650 <__swc_fn_6b1cf01f_000172_5eac0ab4>
  40f701:	xor    ecx,ecx
  40f703:	mov    QWORD PTR [rax+0x8],rcx
  40f707:	xor    ecx,ecx
  40f709:	mov    QWORD PTR [rax],rcx
  40f70c:	add    rsp,0x8
  40f710:	pop    rdi
  40f711:	pop    rsi
  40f712:	ret
	...

000000000040f720 <__swc_fn_6b1cf01f_000002_9ee35b18>:
  40f720:	vxorps xmm0,xmm0,xmm0
  40f724:	vmovups XMMWORD PTR [rcx],xmm0
  40f728:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f72d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40f732:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40f737:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40f73c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40f741:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40f746:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40f74b:	ret
  40f74c:	add    BYTE PTR [rax],al
	...

000000000040f750 <__swc_fn_6b1cf01f_000005_f7acedb0>:
  40f750:	push   rsi
  40f751:	mov    rsi,rdx
  40f754:	test   rdx,rdx
  40f757:	jne    40f760 <__swc_fn_6b1cf01f_000005_f7acedb0+0x10>
  40f759:	mov    eax,0x1
  40f75e:	pop    rsi
  40f75f:	ret
  40f760:	mov    rdx,rsi
  40f763:	call   4116e0 <__swc_fn_6b1cf01f_000113_36905703>
  40f768:	test   al,al
  40f76a:	jne    40f770 <__swc_fn_6b1cf01f_000005_f7acedb0+0x20>
  40f76c:	xor    eax,eax
  40f76e:	pop    rsi
  40f76f:	ret
  40f770:	lea    rcx,[rip+0x148d1]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  40f777:	mov    rdx,QWORD PTR [rip+0x148ca]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  40f77e:	xchg   ax,ax
  40f780:	lea    r8,[rdx+rsi*1]
  40f784:	mov    rax,rdx
  40f787:	lock cmpxchg QWORD PTR [rcx],r8
  40f78c:	cmp    rax,rdx
  40f78f:	je     40f796 <__swc_fn_6b1cf01f_000005_f7acedb0+0x46>
  40f791:	mov    rdx,rax
  40f794:	jmp    40f780 <__swc_fn_6b1cf01f_000005_f7acedb0+0x30>
  40f796:	lea    rcx,[rip+0x148b3]        # 424050 <__swc_bss_base_6b1cf01f+0x10>
  40f79d:	mov    rdx,QWORD PTR [rip+0x148ac]        # 424050 <__swc_bss_base_6b1cf01f+0x10>
  40f7a4:	cs nop WORD PTR [rax+rax*1+0x0]
  40f7ae:	xchg   ax,ax
  40f7b0:	lea    r8,[rdx+0x1]
  40f7b4:	mov    rax,rdx
  40f7b7:	lock cmpxchg QWORD PTR [rcx],r8
  40f7bc:	cmp    rax,rdx
  40f7bf:	je     40f7c6 <__swc_fn_6b1cf01f_000005_f7acedb0+0x76>
  40f7c1:	mov    rdx,rax
  40f7c4:	jmp    40f7b0 <__swc_fn_6b1cf01f_000005_f7acedb0+0x60>
  40f7c6:	mov    eax,0x1
  40f7cb:	pop    rsi
  40f7cc:	ret
  40f7cd:	add    BYTE PTR [rax],al
	...

000000000040f7d0 <__swc_fn_6b1cf01f_000008_24a20786>:
  40f7d0:	push   rbx
  40f7d1:	push   rsi
  40f7d2:	push   rdi
  40f7d3:	push   r12
  40f7d5:	sub    rsp,0x18
  40f7d9:	mov    rbx,rcx
  40f7dc:	mov    rsi,rcx
  40f7df:	and    rsi,0xffffffffffc00000
  40f7e6:	movzx  eax,BYTE PTR [rbx+0x3a]
  40f7ea:	mov    ecx,DWORD PTR [rsi+0x28]
  40f7ed:	shrx   eax,eax,ecx
  40f7f2:	lea    rdi,[rsp+0x8]
  40f7f7:	mov    DWORD PTR [rsp+0x8],eax
  40f7fb:	mov    rcx,rsi
  40f7fe:	mov    rax,rdi
  40f801:	mov    edx,DWORD PTR [rax]
  40f803:	call   40b620 <__swc_fn_6b1cf01f_000013_9dea5065>
  40f808:	mov    r12,rax
  40f80b:	mov    rcx,rsi
  40f80e:	mov    edx,DWORD PTR [rdi]
  40f810:	call   40f900 <__swc_fn_6b1cf01f_000014_9afb7cfb>
  40f815:	mov    rcx,r12
  40f818:	mov    edx,DWORD PTR [rbx+0x3c]
  40f81b:	add    rcx,rdx
  40f81e:	cmp    rcx,rax
  40f821:	jb     40f82f <__swc_fn_6b1cf01f_000008_24a20786+0x5f>
  40f823:	xor    eax,eax
  40f825:	add    rsp,0x18
  40f829:	pop    r12
  40f82b:	pop    rdi
  40f82c:	pop    rsi
  40f82d:	pop    rbx
  40f82e:	ret
  40f82f:	mov    rdx,QWORD PTR [rbx+0x20]
  40f833:	mov    r8d,DWORD PTR [rbx+0x2c]
  40f837:	add    rdx,r8
  40f83a:	lea    rsi,[rdx+0xffff]
  40f841:	and    rsi,0xffffffffffff0000
  40f848:	cmp    rax,rsi
  40f84b:	cmovbe rsi,rax
  40f84f:	mov    rax,rsi
  40f852:	sub    rax,rcx
  40f855:	mov    rdx,rax
  40f858:	call   40f750 <__swc_fn_6b1cf01f_000005_f7acedb0>
  40f85d:	test   al,al
  40f85f:	jne    40f86d <__swc_fn_6b1cf01f_000008_24a20786+0x9d>
  40f861:	xor    eax,eax
  40f863:	add    rsp,0x18
  40f867:	pop    r12
  40f869:	pop    rdi
  40f86a:	pop    rsi
  40f86b:	pop    rbx
  40f86c:	ret
  40f86d:	sub    rsi,r12
  40f870:	mov    DWORD PTR [rbx+0x3c],esi
  40f873:	mov    ecx,DWORD PTR [rbx+0x2c]
  40f876:	mov    rax,rsi
  40f879:	xor    edx,edx
  40f87b:	div    rcx
  40f87e:	imul   rax,rcx
  40f882:	add    r12,rax
  40f885:	mov    QWORD PTR [rbx+0x18],r12
  40f889:	mov    eax,0x1
  40f88e:	add    rsp,0x18
  40f892:	pop    r12
  40f894:	pop    rdi
  40f895:	pop    rsi
  40f896:	pop    rbx
  40f897:	ret
	...

000000000040f8a0 <__swc_fn_6b1cf01f_000011_e4b0ddfc>:
  40f8a0:	sub    rsp,0x8
  40f8a4:	mov    rdx,rcx
  40f8a7:	lea    r9,[rcx+0x60]
  40f8ab:	mov    rax,QWORD PTR [r9]
  40f8ae:	test   rax,rax
  40f8b1:	jne    40f8b8 <__swc_fn_6b1cf01f_000011_e4b0ddfc+0x18>
  40f8b3:	add    rsp,0x8
  40f8b7:	ret
  40f8b8:	mov    rcx,rdx
  40f8bb:	call   407450 <__swc_fn_6b1cf01f_000009_c3647f66>
  40f8c0:	xor    eax,eax
  40f8c2:	xchg   QWORD PTR [r9],rax
  40f8c5:	mov    r8,rax
  40f8c8:	mov    rcx,rdx
  40f8cb:	call   40b610 <__swc_fn_6b1cf01f_000010_861b8b62>
  40f8d0:	xor    eax,eax
  40f8d2:	test   r8,r8
  40f8d5:	je     40f8f6 <__swc_fn_6b1cf01f_000011_e4b0ddfc+0x56>
  40f8d7:	nop    WORD PTR [rax+rax*1+0x0]
  40f8e0:	mov    rcx,QWORD PTR [r8]
  40f8e3:	mov    r9,QWORD PTR [rdx]
  40f8e6:	mov    QWORD PTR [r8],r9
  40f8e9:	mov    QWORD PTR [rdx],r8
  40f8ec:	mov    r8,rcx
  40f8ef:	inc    eax
  40f8f1:	test   rcx,rcx
  40f8f4:	jne    40f8e0 <__swc_fn_6b1cf01f_000011_e4b0ddfc+0x40>
  40f8f6:	sub    DWORD PTR [rdx+0x28],eax
  40f8f9:	add    rsp,0x8
  40f8fd:	ret
	...

000000000040f900 <__swc_fn_6b1cf01f_000014_9afb7cfb>:
  40f900:	lea    eax,[rdx+0x1]
  40f903:	mov    edx,DWORD PTR [rcx+0x28]
  40f906:	shlx   eax,eax,edx
  40f90b:	shl    rax,0x10
  40f90f:	add    rax,rcx
  40f912:	ret
	...

000000000040f920 <__swc_fn_6b1cf01f_000017_adca76cf>:
  40f920:	push   rbx
  40f921:	push   rsi
  40f922:	push   rdi
  40f923:	push   r12
  40f925:	push   r13
  40f927:	push   r14
  40f929:	push   r15
  40f92b:	sub    rsp,0x30
  40f92f:	mov    rbx,rcx
  40f932:	lea    rsi,[rcx+0x48]
  40f936:	mov    QWORD PTR [rsp+0x18],rsi
  40f93b:	mov    rax,QWORD PTR [rsi]
  40f93e:	mov    rdi,rax
  40f941:	lea    r12,[rsp+0x8]
  40f946:	lea    r13,[rcx+0x40]
  40f94a:	nop    WORD PTR [rax+rax*1+0x0]
  40f950:	test   rdi,rdi
  40f953:	je     40fa93 <__swc_fn_6b1cf01f_000017_adca76cf+0x173>
  40f959:	xor    eax,eax
  40f95b:	tzcnt  rax,rdi
  40f960:	mov    DWORD PTR [rsp+0x8],eax
  40f964:	mov    r14d,0x1
  40f96a:	mov    ecx,eax
  40f96c:	shl    r14,cl
  40f96f:	andn   rdi,r14,rdi
  40f974:	mov    rcx,QWORD PTR [r13+0x0]
  40f978:	test   rcx,r14
  40f97b:	jne    40f950 <__swc_fn_6b1cf01f_000017_adca76cf+0x30>
  40f97d:	mov    rdx,rcx
  40f980:	or     rdx,r14
  40f983:	mov    rax,rcx
  40f986:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  40f98c:	cmp    rax,rcx
  40f98f:	je     40f999 <__swc_fn_6b1cf01f_000017_adca76cf+0x79>
  40f991:	mov    rax,QWORD PTR [rsi]
  40f994:	mov    rdi,rax
  40f997:	jmp    40f950 <__swc_fn_6b1cf01f_000017_adca76cf+0x30>
  40f999:	mov    rcx,rbx
  40f99c:	mov    rdx,r14
  40f99f:	call   40b780 <__swc_fn_6b1cf01f_000019_fd2b165c>
  40f9a4:	test   al,al
  40f9a6:	je     40fa7e <__swc_fn_6b1cf01f_000017_adca76cf+0x15e>
  40f9ac:	mov    eax,DWORD PTR [r12]
  40f9b0:	shl    rax,0x4
  40f9b4:	lea    r15,[rbx+rax*8+0x80]
  40f9bc:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  40f9c4:	lea    rcx,[rip+0x1468d]        # 424058 <__swc_bss_base_6b1cf01f+0x18>
  40f9cb:	mov    rdx,QWORD PTR [rip+0x14686]        # 424058 <__swc_bss_base_6b1cf01f+0x18>
  40f9d2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f9dc:	nop    DWORD PTR [rax+0x0]
  40f9e0:	mov    r8,rdx
  40f9e3:	sub    r8,rsi
  40f9e6:	mov    rax,rdx
  40f9e9:	lock cmpxchg QWORD PTR [rcx],r8
  40f9ee:	cmp    rax,rdx
  40f9f1:	je     40f9f8 <__swc_fn_6b1cf01f_000017_adca76cf+0xd8>
  40f9f3:	mov    rdx,rax
  40f9f6:	jmp    40f9e0 <__swc_fn_6b1cf01f_000017_adca76cf+0xc0>
  40f9f8:	mov    rcx,rbx
  40f9fb:	mov    rax,r12
  40f9fe:	mov    edx,DWORD PTR [rax]
  40fa00:	call   40b620 <__swc_fn_6b1cf01f_000013_9dea5065>
  40fa05:	test   rsi,rsi
  40fa08:	je     40fa76 <__swc_fn_6b1cf01f_000017_adca76cf+0x156>
  40fa0e:	mov    rcx,rax
  40fa11:	mov    rdx,rsi
  40fa14:	call   4096c0 <__swc_fn_6b1cf01f_000114_e9fc0224>
  40fa19:	lea    rcx,[rip+0x14628]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  40fa20:	mov    rdx,QWORD PTR [rip+0x14621]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  40fa27:	nop    WORD PTR [rax+rax*1+0x0]
  40fa30:	mov    r8,rdx
  40fa33:	sub    r8,rsi
  40fa36:	mov    rax,rdx
  40fa39:	lock cmpxchg QWORD PTR [rcx],r8
  40fa3e:	cmp    rax,rdx
  40fa41:	je     40fa48 <__swc_fn_6b1cf01f_000017_adca76cf+0x128>
  40fa43:	mov    rdx,rax
  40fa46:	jmp    40fa30 <__swc_fn_6b1cf01f_000017_adca76cf+0x110>
  40fa48:	lea    rcx,[rip+0x14611]        # 424060 <__swc_bss_base_6b1cf01f+0x20>
  40fa4f:	mov    rdx,QWORD PTR [rip+0x1460a]        # 424060 <__swc_bss_base_6b1cf01f+0x20>
  40fa56:	cs nop WORD PTR [rax+rax*1+0x0]
  40fa60:	lea    r8,[rdx+0x1]
  40fa64:	mov    rax,rdx
  40fa67:	lock cmpxchg QWORD PTR [rcx],r8
  40fa6c:	cmp    rax,rdx
  40fa6f:	je     40fa76 <__swc_fn_6b1cf01f_000017_adca76cf+0x156>
  40fa71:	mov    rdx,rax
  40fa74:	jmp    40fa60 <__swc_fn_6b1cf01f_000017_adca76cf+0x140>
  40fa76:	mov    DWORD PTR [r15+0x3c],0x0
  40fa7e:	mov    rcx,rbx
  40fa81:	mov    rdx,r14
  40fa84:	call   40fab0 <__swc_fn_6b1cf01f_000020_c8f5f27c>
  40fa89:	mov    rsi,QWORD PTR [rsp+0x18]
  40fa8e:	jmp    40f950 <__swc_fn_6b1cf01f_000017_adca76cf+0x30>
  40fa93:	add    rsp,0x30
  40fa97:	pop    r15
  40fa99:	pop    r14
  40fa9b:	pop    r13
  40fa9d:	pop    r12
  40fa9f:	pop    rdi
  40faa0:	pop    rsi
  40faa1:	pop    rbx
  40faa2:	ret
	...

000000000040fab0 <__swc_fn_6b1cf01f_000020_c8f5f27c>:
  40fab0:	mov    r8,QWORD PTR [rcx+0x40]
  40fab4:	cs nop WORD PTR [rax+rax*1+0x0]
  40fabe:	xchg   ax,ax
  40fac0:	mov    rax,rdx
  40fac3:	not    rax
  40fac6:	mov    r9,r8
  40fac9:	and    r9,rax
  40facc:	mov    rax,r8
  40facf:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  40fad5:	cmp    rax,r8
  40fad8:	jne    40fadb <__swc_fn_6b1cf01f_000020_c8f5f27c+0x2b>
  40fada:	ret
  40fadb:	mov    r8,rax
  40fade:	jmp    40fac0 <__swc_fn_6b1cf01f_000020_c8f5f27c+0x10>

000000000040fae0 <__swc_fn_6b1cf01f_000023_aa910677>:
  40fae0:	push   rsi
  40fae1:	push   rdi
  40fae2:	sub    rsp,0x8
  40fae6:	mov    rsi,rcx
  40fae9:	call   40f920 <__swc_fn_6b1cf01f_000017_adca76cf>
  40faee:	lea    rdi,[rip+0x146fb]        # 4241f0 <__swc_bss_base_6b1cf01f+0x1b0>
  40faf5:	mov    rcx,rdi
  40faf8:	call   411d40 <__swc_fn_6b1cf01f_000137_86bb0f90>
  40fafd:	mov    QWORD PTR [rsi+0x8],0x0
  40fb05:	mov    QWORD PTR [rsi+0x18],0x0
  40fb0d:	mov    rax,QWORD PTR [rip+0x146e4]        # 4241f8 <__swc_bss_base_6b1cf01f+0x1b8>
  40fb14:	mov    QWORD PTR [rsi+0x10],rax
  40fb18:	mov    QWORD PTR [rip+0x146d9],rsi        # 4241f8 <__swc_bss_base_6b1cf01f+0x1b8>
  40fb1f:	mov    rcx,rdi
  40fb22:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  40fb27:	add    rsp,0x8
  40fb2b:	pop    rdi
  40fb2c:	pop    rsi
  40fb2d:	ret
	...

000000000040fb30 <__swc_fn_6b1cf01f_000026_9798fb47>:
  40fb30:	vxorps xmm0,xmm0,xmm0
  40fb34:	vmovups XMMWORD PTR [rcx],xmm0
  40fb38:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40fb3d:	mov    QWORD PTR [rcx+0x20],0x0
  40fb45:	ret
	...

000000000040fb50 <__swc_fn_6b1cf01f_000029_9798fb47>:
  40fb50:	vxorps xmm0,xmm0,xmm0
  40fb54:	vmovups XMMWORD PTR [rcx],xmm0
  40fb58:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40fb5d:	mov    QWORD PTR [rcx+0x20],0x0
  40fb65:	ret
	...

000000000040fb70 <__swc_fn_6b1cf01f_000032_9128bcf9>:
  40fb70:	push   r12
  40fb72:	mov    r12,rdi
  40fb75:	test   rdi,rdi
  40fb78:	jne    40fb7d <__swc_fn_6b1cf01f_000032_9128bcf9+0xd>
  40fb7a:	pop    r12
  40fb7c:	ret
  40fb7d:	lea    rax,[rip+0x1247c]        # 422000 <__swc_data_base_6b1cf01f>
  40fb84:	mov    rax,QWORD PTR [rax]
  40fb87:	cmp    rax,0xffffffffffffffff
  40fb8b:	je     40fb9a <__swc_fn_6b1cf01f_000032_9128bcf9+0x2a>
  40fb8d:	mov    eax,eax
  40fb8f:	mov    edi,eax
  40fb91:	xor    eax,eax
  40fb93:	call   407010 <pthread_getspecific@plt>
  40fb98:	jmp    40fb9c <__swc_fn_6b1cf01f_000032_9128bcf9+0x2c>
  40fb9a:	xor    eax,eax
  40fb9c:	cmp    rax,r12
  40fb9f:	jne    40fba8 <__swc_fn_6b1cf01f_000032_9128bcf9+0x38>
  40fba1:	xor    ecx,ecx
  40fba3:	call   40b940 <__swc_fn_6b1cf01f_000034_92d9bbff>
  40fba8:	mov    rdx,QWORD PTR [r12]
  40fbac:	test   rdx,rdx
  40fbaf:	je     40fbc8 <__swc_fn_6b1cf01f_000032_9128bcf9+0x58>
  40fbb1:	mov    rcx,rdx
  40fbb4:	call   40fbf0 <__swc_fn_6b1cf01f_000038_eb6108f2>
  40fbb9:	test   al,al
  40fbbb:	je     40fbc8 <__swc_fn_6b1cf01f_000032_9128bcf9+0x58>
  40fbbd:	mov    rcx,rdx
  40fbc0:	mov    rdx,r12
  40fbc3:	call   40fce0 <__swc_fn_6b1cf01f_000044_b30433d0>
  40fbc8:	pop    r12
  40fbca:	ret
  40fbcb:	add    BYTE PTR [rax],al
  40fbcd:	add    BYTE PTR [rax],al
	...

000000000040fbd0 <__swc_fn_6b1cf01f_000035_28d0e998>:
  40fbd0:	push   rsi
  40fbd1:	mov    rsi,rcx
  40fbd4:	call   407900 <__swc_fn_6b1cf01f_000033_cd1a4e8c>
  40fbd9:	mov    rcx,rax
  40fbdc:	mov    rdx,rsi
  40fbdf:	call   411bc0 <__swc_fn_6b1cf01f_000131_ae5891af>
  40fbe4:	mov    rcx,rsi
  40fbe7:	call   40b940 <__swc_fn_6b1cf01f_000034_92d9bbff>
  40fbec:	pop    rsi
  40fbed:	ret
	...

000000000040fbf0 <__swc_fn_6b1cf01f_000038_eb6108f2>:
  40fbf0:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40fbfa:	sete   al
  40fbfd:	ret
	...

000000000040fc00 <__swc_fn_6b1cf01f_000041_d3c2ab54>:
  40fc00:	push   rsi
  40fc01:	test   rdx,rdx
  40fc04:	jne    40fc08 <__swc_fn_6b1cf01f_000041_d3c2ab54+0x8>
  40fc06:	pop    rsi
  40fc07:	ret
  40fc08:	mov    rax,r8
  40fc0b:	mov    ecx,0x1000
  40fc10:	test   ecx,ecx
  40fc12:	mov    r10d,0x8
  40fc18:	cmove  ecx,r10d
  40fc1c:	dec    rcx
  40fc1f:	mov    r10,0xffffffffffffffff
  40fc26:	sub    r10,rcx
  40fc29:	cmp    r8,r10
  40fc2c:	jbe    40fc32 <__swc_fn_6b1cf01f_000041_d3c2ab54+0x32>
  40fc2e:	xor    eax,eax
  40fc30:	jmp    40fc3a <__swc_fn_6b1cf01f_000041_d3c2ab54+0x3a>
  40fc32:	add    rax,rcx
  40fc35:	andn   rax,rcx,rax
  40fc3a:	mov    ecx,0x1000
  40fc3f:	test   ecx,ecx
  40fc41:	mov    r8d,0x8
  40fc47:	cmove  ecx,r8d
  40fc4b:	dec    rcx
  40fc4e:	mov    r8,0xffffffffffffffff
  40fc55:	sub    r8,rcx
  40fc58:	cmp    r9,r8
  40fc5b:	jbe    40fc61 <__swc_fn_6b1cf01f_000041_d3c2ab54+0x61>
  40fc5d:	xor    esi,esi
  40fc5f:	jmp    40fc6c <__swc_fn_6b1cf01f_000041_d3c2ab54+0x6c>
  40fc61:	add    r9,rcx
  40fc64:	andn   r9,rcx,r9
  40fc69:	mov    rsi,r9
  40fc6c:	mov    rcx,rdx
  40fc6f:	mov    rdx,rax
  40fc72:	mov    r8,rsi
  40fc75:	call   4117c0 <__swc_fn_6b1cf01f_000116_5208f471>
  40fc7a:	lea    rcx,[rip+0x143c7]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  40fc81:	mov    rdx,QWORD PTR [rip+0x143c0]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  40fc88:	nop    DWORD PTR [rax+rax*1+0x0]
  40fc90:	mov    r8,rdx
  40fc93:	sub    r8,rsi
  40fc96:	mov    rax,rdx
  40fc99:	lock cmpxchg QWORD PTR [rcx],r8
  40fc9e:	cmp    rax,rdx
  40fca1:	je     40fca8 <__swc_fn_6b1cf01f_000041_d3c2ab54+0xa8>
  40fca3:	mov    rdx,rax
  40fca6:	jmp    40fc90 <__swc_fn_6b1cf01f_000041_d3c2ab54+0x90>
  40fca8:	lea    rcx,[rip+0x143b1]        # 424060 <__swc_bss_base_6b1cf01f+0x20>
  40fcaf:	mov    rdx,QWORD PTR [rip+0x143aa]        # 424060 <__swc_bss_base_6b1cf01f+0x20>
  40fcb6:	cs nop WORD PTR [rax+rax*1+0x0]
  40fcc0:	lea    r8,[rdx+0x1]
  40fcc4:	mov    rax,rdx
  40fcc7:	lock cmpxchg QWORD PTR [rcx],r8
  40fccc:	cmp    rax,rdx
  40fccf:	je     40fcd6 <__swc_fn_6b1cf01f_000041_d3c2ab54+0xd6>
  40fcd1:	mov    rdx,rax
  40fcd4:	jmp    40fcc0 <__swc_fn_6b1cf01f_000041_d3c2ab54+0xc0>
  40fcd6:	pop    rsi
  40fcd7:	ret
	...

000000000040fce0 <__swc_fn_6b1cf01f_000044_b30433d0>:
  40fce0:	push   rbx
  40fce1:	push   rsi
  40fce2:	push   rdi
  40fce3:	push   r12
  40fce5:	push   r13
  40fce7:	push   r14
  40fce9:	push   r15
  40fceb:	sub    rsp,0x30
  40fcef:	mov    rbx,rdx
  40fcf2:	mov    QWORD PTR [rsp+0x18],rdx
  40fcf7:	mov    rsi,rcx
  40fcfa:	mov    eax,0x1
  40fcff:	xchg   DWORD PTR [rbx+0x20],eax
  40fd02:	test   eax,eax
  40fd04:	je     40fd16 <__swc_fn_6b1cf01f_000044_b30433d0+0x36>
  40fd06:	add    rsp,0x30
  40fd0a:	pop    r15
  40fd0c:	pop    r14
  40fd0e:	pop    r13
  40fd10:	pop    r12
  40fd12:	pop    rdi
  40fd13:	pop    rsi
  40fd14:	pop    rbx
  40fd15:	ret
  40fd16:	mov    rcx,rsi
  40fd19:	mov    rdx,rbx
  40fd1c:	mov    r8,0xffffffffffffffff
  40fd23:	call   40bf10 <__swc_fn_6b1cf01f_000061_dea90857>
  40fd28:	lea    rdi,[rsi+0x10]
  40fd2c:	mov    QWORD PTR [rsp+0x20],rdi
  40fd31:	mov    rcx,rdi
  40fd34:	call   411d40 <__swc_fn_6b1cf01f_000137_86bb0f90>
  40fd39:	xor    r12d,r12d
  40fd3c:	cs nop WORD PTR [rax+rax*1+0x0]
  40fd46:	cs nop WORD PTR [rax+rax*1+0x0]
  40fd50:	mov    eax,r12d
  40fd53:	lea    r13,[rax+rax*4]
  40fd57:	lea    r13,[rbx+r13*8+0x28]
  40fd5c:	mov    rax,QWORD PTR [r13+0x8]
  40fd60:	mov    QWORD PTR [rsp+0x8],rax
  40fd65:	mov    rax,QWORD PTR [r13+0x18]
  40fd69:	mov    QWORD PTR [rsp+0x10],rax
  40fd6e:	mov    r14d,0x2
  40fd74:	xor    r15d,r15d
  40fd77:	test   r14,r14
  40fd7a:	je     40fdf7 <__swc_fn_6b1cf01f_000044_b30433d0+0x117>
  40fd80:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  40fd85:	mov    rdi,rax
  40fd88:	test   rdi,rdi
  40fd8b:	je     40fde9 <__swc_fn_6b1cf01f_000044_b30433d0+0x109>
  40fd8d:	nop    DWORD PTR [rax]
  40fd90:	mov    rbx,QWORD PTR [rdi+0x48]
  40fd94:	mov    DWORD PTR [rdi+0x6c],0x0
  40fd9b:	mov    rcx,rdi
  40fd9e:	call   40f8a0 <__swc_fn_6b1cf01f_000011_e4b0ddfc>
  40fda3:	cmp    DWORD PTR [rdi+0x28],0x0
  40fda7:	jne    40fdc0 <__swc_fn_6b1cf01f_000044_b30433d0+0xe0>
  40fda9:	mov    rax,rdi
  40fdac:	and    rax,0xffffffffffc00000
  40fdb3:	mov    rcx,rax
  40fdb6:	mov    rdx,rdi
  40fdb9:	call   40b640 <__swc_fn_6b1cf01f_000016_283e2b5e>
  40fdbe:	jmp    40fde1 <__swc_fn_6b1cf01f_000044_b30433d0+0x101>
  40fdc0:	mov    QWORD PTR [rdi+0x40],0x0
  40fdc8:	rex mov BYTE PTR [rdi+0x3b],0x2
  40fdcd:	mov    QWORD PTR [rdi+0x50],0x0
  40fdd5:	mov    rax,QWORD PTR [rsi+0x28]
  40fdd9:	mov    QWORD PTR [rdi+0x48],rax
  40fddd:	mov    QWORD PTR [rsi+0x28],rdi
  40fde1:	mov    rdi,rbx
  40fde4:	test   rbx,rbx
  40fde7:	jne    40fd90 <__swc_fn_6b1cf01f_000044_b30433d0+0xb0>
  40fde9:	add    r15,0x1
  40fded:	sub    r14,0x1
  40fdf1:	jne    40fd80 <__swc_fn_6b1cf01f_000044_b30433d0+0xa0>
  40fdf7:	vxorps xmm0,xmm0,xmm0
  40fdfb:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  40fe01:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40fe07:	mov    QWORD PTR [r13+0x20],0x0
  40fe0f:	add    r12,0x1
  40fe13:	cmp    r12,0x2d
  40fe17:	mov    rbx,QWORD PTR [rsp+0x18]
  40fe1c:	jb     40fd50 <__swc_fn_6b1cf01f_000044_b30433d0+0x70>
  40fe22:	mov    rcx,rsi
  40fe25:	mov    rbx,QWORD PTR [rsp+0x18]
  40fe2a:	mov    rdx,rbx
  40fe2d:	mov    rdi,QWORD PTR [rsp+0x20]
  40fe32:	call   407ac0 <__swc_fn_6b1cf01f_000045_6e7a8d58>
  40fe37:	mov    rcx,rdi
  40fe3a:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  40fe3f:	mov    rcx,rsi
  40fe42:	mov    rdx,rbx
  40fe45:	mov    r8d,0x9b8
  40fe4b:	mov    r9d,0x9b8
  40fe51:	call   40fc00 <__swc_fn_6b1cf01f_000041_d3c2ab54>
  40fe56:	add    rsp,0x30
  40fe5a:	pop    r15
  40fe5c:	pop    r14
  40fe5e:	pop    r13
  40fe60:	pop    r12
  40fe62:	pop    rdi
  40fe63:	pop    rsi
  40fe64:	pop    rbx
  40fe65:	ret
	...

000000000040fe80 <__swc_fn_6b1cf01f_000047_ad48ec88>:
  40fe80:	push   rbx
  40fe81:	push   rsi
  40fe82:	push   rdi
  40fe83:	push   r12
  40fe85:	push   r13
  40fe87:	push   r14
  40fe89:	push   r15
  40fe8b:	sub    rsp,0x30
  40fe8f:	mov    ebx,r8d
  40fe92:	mov    rsi,rcx
  40fe95:	mov    rdi,rdx
  40fe98:	test   r8d,r8d
  40fe9b:	jne    40fea4 <__swc_fn_6b1cf01f_000047_ad48ec88+0x24>
  40fe9d:	mov    eax,0x8
  40fea2:	jmp    40fecb <__swc_fn_6b1cf01f_000047_ad48ec88+0x4b>
  40fea4:	cmp    ebx,0x8
  40fea7:	ja     40feb2 <__swc_fn_6b1cf01f_000047_ad48ec88+0x32>
  40fea9:	mov    rax,rbx
  40feac:	shl    rax,0x4
  40feb0:	jmp    40fecb <__swc_fn_6b1cf01f_000047_ad48ec88+0x4b>
  40feb2:	lea    eax,[rbx-0x9]
  40feb5:	mov    ecx,eax
  40feb7:	shr    ecx,0x2
  40feba:	and    eax,0x3
  40febd:	lea    ecx,[rcx+0x7]
  40fec0:	lea    ecx,[rcx-0x2]
  40fec3:	lea    eax,[rax+0x5]
  40fec6:	shlx   rax,rax,rcx
  40fecb:	lea    r12,[rsp+0x8]
  40fed0:	mov    DWORD PTR [rsp+0x8],eax
  40fed4:	lea    r13,[rsp+0xc]
  40fed9:	mov    QWORD PTR [rsp+0x18],r13
  40fede:	xor    eax,eax
  40fee0:	cmp    ebx,0x21
  40fee3:	setae  al
  40fee6:	lea    eax,[rax+rax*2]
  40fee9:	mov    DWORD PTR [rsp+0xc],eax
  40feed:	lea    r14,[rsi+0x10]
  40fef1:	mov    rcx,r14
  40fef4:	call   411d40 <__swc_fn_6b1cf01f_000137_86bb0f90>
  40fef9:	xor    eax,eax
  40fefb:	mov    rcx,QWORD PTR [rsi+0x28]
  40feff:	mov    r15,rcx
  40ff02:	test   r15,r15
  40ff05:	je     40ffb6 <__swc_fn_6b1cf01f_000047_ad48ec88+0x136>
  40ff0b:	cs nop WORD PTR [rax+rax*1+0x0]
  40ff15:	cs nop WORD PTR [rax+rax*1+0x0]
  40ff1f:	nop
  40ff20:	mov    rcx,QWORD PTR [r15+0x48]
  40ff24:	movzx  edx,BYTE PTR [r15+0x39]
  40ff29:	cmp    edx,ebx
  40ff2b:	jne    40ffa7 <__swc_fn_6b1cf01f_000047_ad48ec88+0x127>
  40ff2d:	test   rax,rax
  40ff30:	jne    40ff38 <__swc_fn_6b1cf01f_000047_ad48ec88+0xb8>
  40ff32:	mov    QWORD PTR [rsi+0x28],rcx
  40ff36:	jmp    40ff3c <__swc_fn_6b1cf01f_000047_ad48ec88+0xbc>
  40ff38:	mov    QWORD PTR [rax+0x48],rcx
  40ff3c:	vxorps xmm0,xmm0,xmm0
  40ff40:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  40ff46:	mov    BYTE PTR [r15+0x3b],0x1
  40ff4b:	mov    QWORD PTR [r15+0x40],rdi
  40ff4f:	mov    rcx,r15
  40ff52:	call   40f8a0 <__swc_fn_6b1cf01f_000011_e4b0ddfc>
  40ff57:	movzx  eax,BYTE PTR [r15+0x39]
  40ff5c:	lea    rax,[rax+rax*4]
  40ff60:	lea    rax,[rdi+rax*8+0x28]
  40ff65:	mov    rcx,QWORD PTR [rax+0x10]
  40ff69:	mov    QWORD PTR [r15+0x50],rcx
  40ff6d:	mov    QWORD PTR [r15+0x48],0x0
  40ff75:	mov    rcx,QWORD PTR [rax+0x10]
  40ff79:	test   rcx,rcx
  40ff7c:	je     40ff84 <__swc_fn_6b1cf01f_000047_ad48ec88+0x104>
  40ff7e:	mov    QWORD PTR [rcx+0x48],r15
  40ff82:	jmp    40ff88 <__swc_fn_6b1cf01f_000047_ad48ec88+0x108>
  40ff84:	mov    QWORD PTR [rax+0x8],r15
  40ff88:	mov    QWORD PTR [rax+0x10],r15
  40ff8c:	mov    rcx,r14
  40ff8f:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  40ff94:	mov    rax,r15
  40ff97:	add    rsp,0x30
  40ff9b:	pop    r15
  40ff9d:	pop    r14
  40ff9f:	pop    r13
  40ffa1:	pop    r12
  40ffa3:	pop    rdi
  40ffa4:	pop    rsi
  40ffa5:	pop    rbx
  40ffa6:	ret
  40ffa7:	mov    rax,r15
  40ffaa:	mov    r15,rcx
  40ffad:	test   rcx,rcx
  40ffb0:	jne    40ff20 <__swc_fn_6b1cf01f_000047_ad48ec88+0xa0>
  40ffb6:	mov    rax,QWORD PTR [rsi+0x18]
  40ffba:	mov    r15,rax
  40ffbd:	test   r15,r15
  40ffc0:	je     410056 <__swc_fn_6b1cf01f_000047_ad48ec88+0x1d6>
  40ffc6:	cs nop WORD PTR [rax+rax*1+0x0]
  40ffd0:	mov    eax,DWORD PTR [rsp+0xc]
  40ffd4:	cmp    DWORD PTR [r15+0x28],eax
  40ffd8:	jne    410046 <__swc_fn_6b1cf01f_000047_ad48ec88+0x1c6>
  40ffda:	mov    rcx,r15
  40ffdd:	mov    edx,ebx
  40ffdf:	mov    rax,r12
  40ffe2:	mov    r8d,DWORD PTR [rax]
  40ffe5:	call   407500 <__swc_fn_6b1cf01f_000015_efc44797>
  40ffea:	mov    r13,rax
  40ffed:	test   rax,rax
  40fff0:	je     410046 <__swc_fn_6b1cf01f_000047_ad48ec88+0x1c6>
  40fff2:	mov    QWORD PTR [r13+0x40],rdi
  40fff6:	movzx  eax,BYTE PTR [r13+0x39]
  40fffb:	lea    rax,[rax+rax*4]
  40ffff:	lea    rax,[rdi+rax*8+0x28]
  410004:	mov    rcx,QWORD PTR [rax+0x10]
  410008:	mov    QWORD PTR [r13+0x50],rcx
  41000c:	mov    QWORD PTR [r13+0x48],0x0
  410014:	mov    rcx,QWORD PTR [rax+0x10]
  410018:	test   rcx,rcx
  41001b:	je     410023 <__swc_fn_6b1cf01f_000047_ad48ec88+0x1a3>
  41001d:	mov    QWORD PTR [rcx+0x48],r13
  410021:	jmp    410027 <__swc_fn_6b1cf01f_000047_ad48ec88+0x1a7>
  410023:	mov    QWORD PTR [rax+0x8],r13
  410027:	mov    QWORD PTR [rax+0x10],r13
  41002b:	mov    rcx,r14
  41002e:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  410033:	mov    rax,r13
  410036:	add    rsp,0x30
  41003a:	pop    r15
  41003c:	pop    r14
  41003e:	pop    r13
  410040:	pop    r12
  410042:	pop    rdi
  410043:	pop    rsi
  410044:	pop    rbx
  410045:	ret
  410046:	mov    rax,QWORD PTR [r15+0x10]
  41004a:	mov    r15,rax
  41004d:	test   rax,rax
  410050:	jne    40ffd0 <__swc_fn_6b1cf01f_000047_ad48ec88+0x150>
  410056:	mov    rcx,rsi
  410059:	mov    r13,QWORD PTR [rsp+0x18]
  41005e:	mov    edx,DWORD PTR [r13+0x0]
  410062:	call   40b7c0 <__swc_fn_6b1cf01f_000022_2685aade>
  410067:	mov    r13,rax
  41006a:	test   rax,rax
  41006d:	jne    410089 <__swc_fn_6b1cf01f_000047_ad48ec88+0x209>
  41006f:	mov    rcx,r14
  410072:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  410077:	xor    eax,eax
  410079:	add    rsp,0x30
  41007d:	pop    r15
  41007f:	pop    r14
  410081:	pop    r13
  410083:	pop    r12
  410085:	pop    rdi
  410086:	pop    rsi
  410087:	pop    rbx
  410088:	ret
  410089:	mov    rcx,r13
  41008c:	mov    edx,ebx
  41008e:	mov    r8d,DWORD PTR [r12]
  410092:	call   407500 <__swc_fn_6b1cf01f_000015_efc44797>
  410097:	mov    rbx,rax
  41009a:	test   rax,rax
  41009d:	jne    4100c1 <__swc_fn_6b1cf01f_000047_ad48ec88+0x241>
  41009f:	mov    rcx,r13
  4100a2:	call   40fae0 <__swc_fn_6b1cf01f_000023_aa910677>
  4100a7:	mov    rcx,r14
  4100aa:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  4100af:	xor    eax,eax
  4100b1:	add    rsp,0x30
  4100b5:	pop    r15
  4100b7:	pop    r14
  4100b9:	pop    r13
  4100bb:	pop    r12
  4100bd:	pop    rdi
  4100be:	pop    rsi
  4100bf:	pop    rbx
  4100c0:	ret
  4100c1:	mov    rax,QWORD PTR [rsi+0x18]
  4100c5:	mov    QWORD PTR [r13+0x10],rax
  4100c9:	mov    rax,QWORD PTR [rsi+0x18]
  4100cd:	test   rax,rax
  4100d0:	je     4100d6 <__swc_fn_6b1cf01f_000047_ad48ec88+0x256>
  4100d2:	mov    QWORD PTR [rax+0x18],r13
  4100d6:	mov    QWORD PTR [rsi+0x18],r13
  4100da:	mov    QWORD PTR [rbx+0x40],rdi
  4100de:	movzx  eax,BYTE PTR [rbx+0x39]
  4100e2:	lea    rax,[rax+rax*4]
  4100e6:	lea    rax,[rdi+rax*8+0x28]
  4100eb:	mov    rcx,QWORD PTR [rax+0x10]
  4100ef:	mov    QWORD PTR [rbx+0x50],rcx
  4100f3:	mov    QWORD PTR [rbx+0x48],0x0
  4100fb:	mov    rcx,QWORD PTR [rax+0x10]
  4100ff:	test   rcx,rcx
  410102:	je     41010a <__swc_fn_6b1cf01f_000047_ad48ec88+0x28a>
  410104:	mov    QWORD PTR [rcx+0x48],rbx
  410108:	jmp    41010e <__swc_fn_6b1cf01f_000047_ad48ec88+0x28e>
  41010a:	mov    QWORD PTR [rax+0x8],rbx
  41010e:	mov    QWORD PTR [rax+0x10],rbx
  410112:	mov    rcx,r14
  410115:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  41011a:	mov    rax,rbx
  41011d:	add    rsp,0x30
  410121:	pop    r15
  410123:	pop    r14
  410125:	pop    r13
  410127:	pop    r12
  410129:	pop    rdi
  41012a:	pop    rsi
  41012b:	pop    rbx
  41012c:	ret
	...

0000000000410140 <__swc_fn_6b1cf01f_000050_d846b172>:
  410140:	push   rsi
  410141:	push   rdi
  410142:	push   r12
  410144:	mov    rsi,rdx
  410147:	mov    rdi,rcx
  41014a:	lea    rax,[rcx+0x2a80]
  410151:	mov    rcx,QWORD PTR [rax]
  410154:	test   rcx,rcx
  410157:	jne    41015e <__swc_fn_6b1cf01f_000050_d846b172+0x1e>
  410159:	pop    r12
  41015b:	pop    rdi
  41015c:	pop    rsi
  41015d:	ret
  41015e:	xor    ecx,ecx
  410160:	xchg   QWORD PTR [rax],rcx
  410163:	mov    r12,rcx
  410166:	cs nop WORD PTR [rax+rax*1+0x0]
  410170:	cs nop WORD PTR [rax+rax*1+0x0]
  41017a:	nop    WORD PTR [rax+rax*1+0x0]
  410180:	test   r12,r12
  410183:	je     41021a <__swc_fn_6b1cf01f_000050_d846b172+0xda>
  410189:	mov    r8,r12
  41018c:	mov    r12,QWORD PTR [r12+0x78]
  410191:	lea    rcx,[r8+0x70]
  410195:	xor    eax,eax
  410197:	xchg   DWORD PTR [r8+0x70],eax
  41019b:	cmp    QWORD PTR [r8+0x40],rsi
  41019f:	jne    4101b6 <__swc_fn_6b1cf01f_000050_d846b172+0x76>
  4101a1:	mov    eax,DWORD PTR [r8+0x6c]
  4101a5:	test   eax,eax
  4101a7:	je     410180 <__swc_fn_6b1cf01f_000050_d846b172+0x40>
  4101a9:	mov    rcx,rdi
  4101ac:	mov    rdx,rsi
  4101af:	call   40bb70 <__swc_fn_6b1cf01f_000049_e072b516>
  4101b4:	jmp    410180 <__swc_fn_6b1cf01f_000050_d846b172+0x40>
  4101b6:	mov    rax,QWORD PTR [r8+0x40]
  4101ba:	test   rax,rax
  4101bd:	je     410180 <__swc_fn_6b1cf01f_000050_d846b172+0x40>
  4101bf:	mov    eax,DWORD PTR [r8+0x6c]
  4101c3:	test   eax,eax
  4101c5:	je     410180 <__swc_fn_6b1cf01f_000050_d846b172+0x40>
  4101c7:	mov    r9d,0x1
  4101cd:	xor    eax,eax
  4101cf:	lock cmpxchg DWORD PTR [rcx],r9d
  4101d4:	test   eax,eax
  4101d6:	jne    410180 <__swc_fn_6b1cf01f_000050_d846b172+0x40>
  4101d8:	mov    rax,r8
  4101db:	and    rax,0xffffffffffc00000
  4101e2:	mov    rax,QWORD PTR [rax+0x8]
  4101e6:	test   rax,rax
  4101e9:	jne    4101f1 <__swc_fn_6b1cf01f_000050_d846b172+0xb1>
  4101eb:	xor    eax,eax
  4101ed:	xchg   DWORD PTR [rcx],eax
  4101ef:	jmp    410180 <__swc_fn_6b1cf01f_000050_d846b172+0x40>
  4101f1:	lea    rcx,[rax+0x2a80]
  4101f8:	mov    rax,QWORD PTR [rcx]
  4101fb:	mov    rdx,rax
  4101fe:	xchg   ax,ax
  410200:	mov    QWORD PTR [r8+0x78],rdx
  410204:	mov    rax,rdx
  410207:	lock cmpxchg QWORD PTR [rcx],r8
  41020c:	cmp    rax,rdx
  41020f:	je     410180 <__swc_fn_6b1cf01f_000050_d846b172+0x40>
  410215:	mov    rdx,rax
  410218:	jmp    410200 <__swc_fn_6b1cf01f_000050_d846b172+0xc0>
  41021a:	pop    r12
  41021c:	pop    rdi
  41021d:	pop    rsi
  41021e:	ret
	...

0000000000410220 <__swc_fn_6b1cf01f_000053_2e3450f7>:
  410220:	sub    rsp,0x8
  410224:	mov    r9,r8
  410227:	movzx  eax,BYTE PTR [r9+0x39]
  41022c:	lea    rax,[rax+rax*4]
  410230:	lea    rax,[rdx+rax*8+0x28]
  410235:	cmp    QWORD PTR [rax],r9
  410238:	je     410240 <__swc_fn_6b1cf01f_000053_2e3450f7+0x20>
  41023a:	cmp    QWORD PTR [rax+0x20],r9
  41023e:	jne    410245 <__swc_fn_6b1cf01f_000053_2e3450f7+0x25>
  410240:	add    rsp,0x8
  410244:	ret
  410245:	cmp    QWORD PTR [rax+0x20],0x0
  41024a:	je     410257 <__swc_fn_6b1cf01f_000053_2e3450f7+0x37>
  41024c:	mov    r8,QWORD PTR [rax+0x20]
  410250:	cmp    DWORD PTR [r8+0x28],0x0
  410255:	je     410260 <__swc_fn_6b1cf01f_000053_2e3450f7+0x40>
  410257:	mov    QWORD PTR [rax+0x20],r9
  41025b:	add    rsp,0x8
  41025f:	ret
  410260:	mov    r8,r9
  410263:	call   40bad0 <__swc_fn_6b1cf01f_000046_137687bb>
  410268:	mov    rax,r9
  41026b:	and    rax,0xffffffffffc00000
  410272:	mov    rcx,rax
  410275:	mov    rdx,r9
  410278:	call   40b640 <__swc_fn_6b1cf01f_000016_283e2b5e>
  41027d:	add    rsp,0x8
  410281:	ret
	...

0000000000410290 <__swc_fn_6b1cf01f_000056_1bb23e77>:
  410290:	push   rsi
  410291:	push   rdi
  410292:	push   r12
  410294:	mov    rsi,rdx
  410297:	mov    rax,rdx
  41029a:	shr    rax,0xc
  41029e:	movabs rdx,0x9e3779b97f4a7c15
  4102a8:	imul   rax,rdx
  4102ac:	shr    rax,0x20
  4102b0:	lea    rax,[rax*8+0x0]
  4102b8:	shr    rax,0x20
  4102bc:	lea    rax,[rax*8+0x0]
  4102c4:	lea    rax,[rcx+rax*8+0x40]
  4102c9:	xor    edx,edx
  4102cb:	test   dl,dl
  4102cd:	lea    rdi,[rcx+0x8]
  4102d1:	cmove  rdi,rax
  4102d5:	xor    edx,edx
  4102d7:	test   dl,dl
  4102d9:	lea    r12,[rcx+0x30]
  4102dd:	lea    rax,[rax+0x8]
  4102e1:	cmove  r12,rax
  4102e5:	mov    rcx,rdi
  4102e8:	call   411d40 <__swc_fn_6b1cf01f_000137_86bb0f90>
  4102ed:	mov    rax,QWORD PTR [rsi+0x30]
  4102f1:	test   rax,rax
  4102f4:	jne    410300 <__swc_fn_6b1cf01f_000056_1bb23e77+0x70>
  4102f6:	mov    rax,QWORD PTR [rsi+0x38]
  4102fa:	mov    QWORD PTR [r12],rax
  4102fe:	jmp    410308 <__swc_fn_6b1cf01f_000056_1bb23e77+0x78>
  410300:	mov    rcx,QWORD PTR [rsi+0x38]
  410304:	mov    QWORD PTR [rax+0x38],rcx
  410308:	mov    rax,QWORD PTR [rsi+0x38]
  41030c:	test   rax,rax
  41030f:	je     410319 <__swc_fn_6b1cf01f_000056_1bb23e77+0x89>
  410311:	mov    rcx,QWORD PTR [rsi+0x30]
  410315:	mov    QWORD PTR [rax+0x30],rcx
  410319:	vxorps xmm0,xmm0,xmm0
  41031d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  410322:	mov    rcx,rdi
  410325:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  41032a:	pop    r12
  41032c:	pop    rdi
  41032d:	pop    rsi
  41032e:	ret
	...

0000000000410330 <__swc_fn_6b1cf01f_000059_ad030a10>:
  410330:	mov    rax,QWORD PTR [rcx+0x250]
  410337:	mov    rcx,rax
  41033a:	cmp    rax,0x1000000
  410341:	mov    eax,0x1000000
  410346:	cmovb  rcx,rax
  41034a:	mov    rax,rcx
  41034d:	cmp    rcx,0x10000000
  410354:	mov    ecx,0x10000000
  410359:	cmova  rax,rcx
  41035d:	ret
	...

0000000000410360 <__swc_fn_6b1cf01f_000062_ffcd96eb>:
  410360:	push   rsi
  410361:	push   rdi
  410362:	push   r12
  410364:	mov    rsi,rcx
  410367:	mov    rdi,QWORD PTR [rsi+0x2a70]
  41036e:	xor    r12d,r12d
  410371:	test   rdi,rdi
  410374:	jbe    4103ab <__swc_fn_6b1cf01f_000062_ffcd96eb+0x4b>
  410376:	cs nop WORD PTR [rax+rax*1+0x0]
  410380:	lea    rax,[r12+r12*4]
  410384:	lea    rax,[rsi+rax*8+0x268]
  41038c:	mov    rcx,rsi
  41038f:	mov    rdx,QWORD PTR [rax]
  410392:	mov    r8,QWORD PTR [rax+0x8]
  410396:	mov    rax,QWORD PTR [rax+0x10]
  41039a:	mov    r9,rax
  41039d:	call   40fc00 <__swc_fn_6b1cf01f_000041_d3c2ab54>
  4103a2:	add    r12,0x1
  4103a6:	cmp    r12,rdi
  4103a9:	jb     410380 <__swc_fn_6b1cf01f_000062_ffcd96eb+0x20>
  4103ab:	vxorps xmm0,xmm0,xmm0
  4103af:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  4103b7:	pop    r12
  4103b9:	pop    rdi
  4103ba:	pop    rsi
  4103bb:	ret
  4103bc:	add    BYTE PTR [rax],al
	...

00000000004103c0 <__swc_fn_6b1cf01f_000065_8c7d044b>:
  4103c0:	push   rsi
  4103c1:	push   rdi
  4103c2:	sub    rsp,0x8
  4103c6:	mov    rsi,rcx
  4103c9:	call   407e40 <__swc_fn_6b1cf01f_000054_df0696cd>
  4103ce:	mov    rdi,rax
  4103d1:	mov    rcx,rsi
  4103d4:	mov    rdx,rax
  4103d7:	call   410290 <__swc_fn_6b1cf01f_000056_1bb23e77>
  4103dc:	mov    rcx,QWORD PTR [rdi+0x28]
  4103e0:	mov    rdx,QWORD PTR [rsi+0x250]
  4103e7:	nop    WORD PTR [rax+rax*1+0x0]
  4103f0:	mov    r8,rdx
  4103f3:	sub    r8,rcx
  4103f6:	mov    rax,rdx
  4103f9:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  410402:	cmp    rax,rdx
  410405:	je     41040c <__swc_fn_6b1cf01f_000065_8c7d044b+0x4c>
  410407:	mov    rdx,rax
  41040a:	jmp    4103f0 <__swc_fn_6b1cf01f_000065_8c7d044b+0x30>
  41040c:	mov    rcx,rsi
  41040f:	mov    rdx,QWORD PTR [rdi]
  410412:	mov    r8,QWORD PTR [rdi+0x8]
  410416:	mov    r9,QWORD PTR [rdi+0x10]
  41041a:	call   407f60 <__swc_fn_6b1cf01f_000060_b304235a>
  41041f:	mov    rcx,rsi
  410422:	call   407ba0 <__swc_fn_6b1cf01f_000051_3af34d7f>
  410427:	add    rsp,0x8
  41042b:	pop    rdi
  41042c:	pop    rsi
  41042d:	ret
	...

0000000000410430 <__swc_fn_6b1cf01f_000068_97813b89>:
  410430:	push   r12
  410432:	push   r13
  410434:	push   r14
  410436:	push   rdi
  410437:	push   rsi
  410438:	sub    rsp,0x1b0
  41043f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  410448:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  410451:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  41045a:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  410463:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  41046c:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  410475:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  41047e:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  410487:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  410490:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  410499:	mov    r8,rdx
  41049c:	mov    r12,rcx
  41049f:	mov    r13,QWORD PTR [r8+0x40]
  4104a3:	test   r13,r13
  4104a6:	jne    4104b8 <__swc_fn_6b1cf01f_000068_97813b89+0x88>
  4104a8:	add    rsp,0x1b0
  4104af:	pop    rsi
  4104b0:	pop    rdi
  4104b1:	pop    r14
  4104b3:	pop    r13
  4104b5:	pop    r12
  4104b7:	ret
  4104b8:	mov    QWORD PTR [r8+0x40],0x0
  4104c0:	lea    rax,[rip+0x13ba9]        # 424070 <__swc_bss_base_6b1cf01f+0x30>
  4104c7:	mov    rcx,r13
  4104ca:	sub    rcx,QWORD PTR [rax+0x8]
  4104ce:	mov    rax,QWORD PTR [rip+0x13bab]        # 424080 <__swc_bss_base_6b1cf01f+0x40>
  4104d5:	cmp    rcx,rax
  4104d8:	jae    410504 <__swc_fn_6b1cf01f_000068_97813b89+0xd4>
  4104da:	mov    rax,r13
  4104dd:	and    rax,0xffffffffffc00000
  4104e4:	mov    rcx,r13
  4104e7:	shr    rcx,0x10
  4104eb:	and    ecx,0x3f
  4104ee:	mov    edx,DWORD PTR [rax+0x28]
  4104f1:	shrx   ecx,ecx,edx
  4104f6:	shl    rcx,0x4
  4104fa:	lea    r14,[rax+rcx*8+0x80]
  410502:	jmp    41051f <__swc_fn_6b1cf01f_000068_97813b89+0xef>
  410504:	mov    rcx,r13
  410507:	mov    QWORD PTR [rsp+0xf8],r8
  41050f:	call   407830 <__swc_fn_6b1cf01f_000024_bcdc5519>
  410514:	mov    r8,QWORD PTR [rsp+0xf8]
  41051c:	mov    r14,rax
  41051f:	test   r14,r14
  410522:	jne    410534 <__swc_fn_6b1cf01f_000068_97813b89+0x104>
  410524:	mov    rcx,r12
  410527:	mov    rdx,r13
  41052a:	call   4103c0 <__swc_fn_6b1cf01f_000065_8c7d044b>
  41052f:	jmp    4105c2 <__swc_fn_6b1cf01f_000068_97813b89+0x192>
  410534:	lea    rax,[rip+0x11ac5]        # 422000 <__swc_data_base_6b1cf01f>
  41053b:	mov    rax,QWORD PTR [rax]
  41053e:	cmp    rax,0xffffffffffffffff
  410542:	je     410551 <__swc_fn_6b1cf01f_000068_97813b89+0x121>
  410544:	mov    eax,eax
  410546:	mov    edi,eax
  410548:	xor    eax,eax
  41054a:	call   407010 <pthread_getspecific@plt>
  41054f:	jmp    410553 <__swc_fn_6b1cf01f_000068_97813b89+0x123>
  410551:	xor    eax,eax
  410553:	test   rax,rax
  410556:	jne    410565 <__swc_fn_6b1cf01f_000068_97813b89+0x135>
  410558:	call   407900 <__swc_fn_6b1cf01f_000033_cd1a4e8c>
  41055d:	mov    rcx,rax
  410560:	call   40db00 <__swc_fn_6b1cf01f_000130_5f757033>
  410565:	test   rax,rax
  410568:	je     4105b7 <__swc_fn_6b1cf01f_000068_97813b89+0x187>
  41056a:	cmp    QWORD PTR [r14+0x40],rax
  41056e:	jne    4105b7 <__swc_fn_6b1cf01f_000068_97813b89+0x187>
  410570:	mov    ecx,DWORD PTR [r14+0x6c]
  410574:	test   ecx,ecx
  410576:	je     410596 <__swc_fn_6b1cf01f_000068_97813b89+0x166>
  410578:	mov    rcx,r12
  41057b:	mov    rdx,rax
  41057e:	mov    r8,r14
  410581:	mov    QWORD PTR [rsp+0x100],rax
  410589:	call   40bb70 <__swc_fn_6b1cf01f_000049_e072b516>
  41058e:	mov    rax,QWORD PTR [rsp+0x100]
  410596:	mov    rcx,QWORD PTR [r14]
  410599:	mov    QWORD PTR [r13+0x0],rcx
  41059d:	mov    QWORD PTR [r14],r13
  4105a0:	sub    DWORD PTR [r14+0x28],0x1
  4105a5:	jne    4105c2 <__swc_fn_6b1cf01f_000068_97813b89+0x192>
  4105a7:	mov    rcx,r12
  4105aa:	mov    rdx,rax
  4105ad:	mov    r8,r14
  4105b0:	call   410220 <__swc_fn_6b1cf01f_000053_2e3450f7>
  4105b5:	jmp    4105c2 <__swc_fn_6b1cf01f_000068_97813b89+0x192>
  4105b7:	mov    rcx,r14
  4105ba:	mov    rdx,r13
  4105bd:	call   407470 <__swc_fn_6b1cf01f_000012_524c1f23>
  4105c2:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  4105cb:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  4105d4:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  4105dd:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  4105e6:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  4105ef:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  4105f8:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  410601:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  41060a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  410613:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  41061c:	add    rsp,0x1b0
  410623:	pop    rsi
  410624:	pop    rdi
  410625:	pop    r14
  410627:	pop    r13
  410629:	pop    r12
  41062b:	ret
  41062c:	add    BYTE PTR [rax],al
	...

0000000000410630 <__swc_fn_6b1cf01f_000071_9c99bf04>:
  410630:	push   rsi
  410631:	mov    rsi,rcx
  410634:	call   40fbf0 <__swc_fn_6b1cf01f_000038_eb6108f2>
  410639:	test   al,al
  41063b:	jne    41063f <__swc_fn_6b1cf01f_000071_9c99bf04+0xf>
  41063d:	pop    rsi
  41063e:	ret
  41063f:	lea    rax,[rip+0x13bfa]        # 424240 <__swc_bss_base_6b1cf01f+0x200>
  410646:	cmp    rsi,rax
  410649:	jne    41064d <__swc_fn_6b1cf01f_000071_9c99bf04+0x1d>
  41064b:	pop    rsi
  41064c:	ret
  41064d:	mov    rcx,rsi
  410650:	call   411d40 <__swc_fn_6b1cf01f_000137_86bb0f90>
  410655:	mov    rcx,rsi
  410658:	call   40c340 <__swc_fn_6b1cf01f_000070_61e60aab>
  41065d:	mov    rcx,rsi
  410660:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  410665:	pop    rsi
  410666:	ret
	...

0000000000410670 <__swc_fn_6b1cf01f_000074_15bd096c>:
  410670:	sub    rsp,0x8
  410674:	call   40c090 <__swc_fn_6b1cf01f_000067_7130736e>
  410679:	add    rsp,0x8
  41067d:	ret
	...

0000000000410680 <__swc_fn_6b1cf01f_000077_a5fd3362>:
  410680:	push   rsi
  410681:	mov    rsi,rdx
  410684:	call   40c340 <__swc_fn_6b1cf01f_000070_61e60aab>
  410689:	mov    QWORD PTR [rsi+0x40],0x0
  410691:	pop    rsi
  410692:	ret
	...

00000000004106a0 <__swc_fn_6b1cf01f_000080_63a67586>:
  4106a0:	mov    r8,rcx
  4106a3:	mov    rcx,QWORD PTR [rcx]
  4106a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4106b0:	mov    r9,rcx
  4106b3:	sub    r9,rdx
  4106b6:	mov    rax,rcx
  4106b9:	lock cmpxchg QWORD PTR [r8],r9
  4106be:	cmp    rax,rcx
  4106c1:	je     4106c8 <__swc_fn_6b1cf01f_000080_63a67586+0x28>
  4106c3:	mov    rcx,rax
  4106c6:	jmp    4106b0 <__swc_fn_6b1cf01f_000080_63a67586+0x10>
  4106c8:	mov    rax,rcx
  4106cb:	ret
  4106cc:	add    BYTE PTR [rax],al
	...

00000000004106d0 <__swc_fn_6b1cf01f_000083_c618ff58>:
  4106d0:	vxorps xmm0,xmm0,xmm0
  4106d4:	vmovups XMMWORD PTR [rcx],xmm0
  4106d8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4106dd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4106e2:	ret
	...

00000000004106f0 <__swc_fn_6b1cf01f_000086_0d280354>:
  4106f0:	push   rsi
  4106f1:	push   rdi
  4106f2:	push   r12
  4106f4:	push   r13
  4106f6:	push   r15
  4106f8:	push   r14
  4106fa:	push   rbx
  4106fb:	sub    rsp,0x60
  4106ff:	mov    QWORD PTR [rsp+0x28],r11
  410704:	mov    rsi,rcx
  410707:	mov    rdi,rdx
  41070a:	mov    QWORD PTR [rsp+0x30],rdx
  41070f:	mov    r12,r8
  410712:	mov    r13,r9
  410715:	mov    QWORD PTR [rsp+0x38],r10
  41071a:	xor    r8d,r8d
  41071d:	call   410a40 <__swc_fn_6b1cf01f_000092_63c1827b>
  410722:	test   al,al
  410724:	je     410739 <__swc_fn_6b1cf01f_000086_0d280354+0x49>
  410726:	mov    rax,r12
  410729:	add    rsp,0x60
  41072d:	pop    rbx
  41072e:	pop    r14
  410730:	pop    r15
  410732:	pop    r13
  410734:	pop    r12
  410736:	pop    rdi
  410737:	pop    rsi
  410738:	ret
  410739:	rex cmp BYTE PTR [rdi+0x2c],0xe
  41073e:	je     410752 <__swc_fn_6b1cf01f_000086_0d280354+0x62>
  410740:	xor    eax,eax
  410742:	add    rsp,0x60
  410746:	pop    rbx
  410747:	pop    r14
  410749:	pop    r15
  41074b:	pop    r13
  41074d:	pop    r12
  41074f:	pop    rdi
  410750:	pop    rsi
  410751:	ret
  410752:	mov    r15,rdi
  410755:	mov    QWORD PTR [rsp+0x40],rdi
  41075a:	rex cmp BYTE PTR [rsi+0x2c],0x12
  41075f:	jne    4107cf <__swc_fn_6b1cf01f_000086_0d280354+0xdf>
  410761:	mov    r14,QWORD PTR [r15+0xb8]
  410768:	mov    rax,QWORD PTR [r15+0xc0]
  41076f:	mov    r15,rax
  410772:	xor    edi,edi
  410774:	test   r15,r15
  410777:	je     4107cf <__swc_fn_6b1cf01f_000086_0d280354+0xdf>
  410779:	nop    DWORD PTR [rax+0x0]
  410780:	lea    rbx,[rdi*8+0x0]
  410788:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  41078d:	mov    rcx,rax
  410790:	mov    rdx,rsi
  410793:	xor    r8d,r8d
  410796:	call   410a40 <__swc_fn_6b1cf01f_000092_63c1827b>
  41079b:	test   al,al
  41079d:	je     4107c5 <__swc_fn_6b1cf01f_000086_0d280354+0xd5>
  41079f:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  4107a4:	test   rax,rax
  4107a7:	je     4107c5 <__swc_fn_6b1cf01f_000086_0d280354+0xd5>
  4107a9:	test   r13,r13
  4107ac:	je     4107b2 <__swc_fn_6b1cf01f_000086_0d280354+0xc2>
  4107ae:	mov    QWORD PTR [r13+0x8],rax
  4107b2:	mov    rax,r12
  4107b5:	add    rsp,0x60
  4107b9:	pop    rbx
  4107ba:	pop    r14
  4107bc:	pop    r15
  4107be:	pop    r13
  4107c0:	pop    r12
  4107c2:	pop    rdi
  4107c3:	pop    rsi
  4107c4:	ret
  4107c5:	add    rdi,0x1
  4107c9:	sub    r15,0x1
  4107cd:	jne    410780 <__swc_fn_6b1cf01f_000086_0d280354+0x90>
  4107cf:	test   r12,r12
  4107d2:	jne    4107e6 <__swc_fn_6b1cf01f_000086_0d280354+0xf6>
  4107d4:	xor    eax,eax
  4107d6:	add    rsp,0x60
  4107da:	pop    rbx
  4107db:	pop    r14
  4107dd:	pop    r15
  4107df:	pop    r13
  4107e1:	pop    r12
  4107e3:	pop    rdi
  4107e4:	pop    rsi
  4107e5:	ret
  4107e6:	mov    rbx,QWORD PTR [rsp+0x28]
  4107eb:	mov    rdi,QWORD PTR [rsp+0x30]
  4107f0:	mov    rax,rbx
  4107f3:	test   rax,rax
  4107f6:	je     410826 <__swc_fn_6b1cf01f_000086_0d280354+0x136>
  4107f8:	nop    DWORD PTR [rax+rax*1+0x0]
  410800:	cmp    QWORD PTR [rax+0x8],r12
  410804:	jne    41081d <__swc_fn_6b1cf01f_000086_0d280354+0x12d>
  410806:	cmp    QWORD PTR [rax],rdi
  410809:	jne    41081d <__swc_fn_6b1cf01f_000086_0d280354+0x12d>
  41080b:	xor    eax,eax
  41080d:	add    rsp,0x60
  410811:	pop    rbx
  410812:	pop    r14
  410814:	pop    r15
  410816:	pop    r13
  410818:	pop    r12
  41081a:	pop    rdi
  41081b:	pop    rsi
  41081c:	ret
  41081d:	mov    rax,QWORD PTR [rax+0x10]
  410821:	test   rax,rax
  410824:	jne    410800 <__swc_fn_6b1cf01f_000086_0d280354+0x110>
  410826:	lea    r14,[rsp+0x8]
  41082b:	mov    QWORD PTR [rsp+0x48],r14
  410830:	mov    QWORD PTR [rsp+0x8],rdi
  410835:	mov    QWORD PTR [rsp+0x10],r12
  41083a:	mov    QWORD PTR [rsp+0x18],rbx
  41083f:	mov    r15,QWORD PTR [rsp+0x40]
  410844:	mov    rbx,QWORD PTR [r15+0x98]
  41084b:	mov    rax,QWORD PTR [r15+0xa0]
  410852:	mov    rdi,rax
  410855:	mov    r15,QWORD PTR [rsp+0x38]
  41085a:	xor    r14d,r14d
  41085d:	test   rdi,rdi
  410860:	je     41090a <__swc_fn_6b1cf01f_000086_0d280354+0x21a>
  410866:	cs nop WORD PTR [rax+rax*1+0x0]
  410870:	mov    QWORD PTR [rsp+0x50],rdi
  410875:	lea    rdi,[r14*8+0x0]
  41087d:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  410882:	mov    rcx,rax
  410885:	call   408f40 <__swc_fn_6b1cf01f_000084_3953ef98>
  41088a:	test   DWORD PTR [rax+0x28],0x10000
  410891:	je     410898 <__swc_fn_6b1cf01f_000086_0d280354+0x1a8>
  410893:	test   r15b,r15b
  410896:	je     4108f1 <__swc_fn_6b1cf01f_000086_0d280354+0x201>
  410898:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  41089c:	lea    rdi,[r12+rcx*1]
  4108a0:	cmp    BYTE PTR [rax+0x2c],0x6
  4108a4:	jne    4108b8 <__swc_fn_6b1cf01f_000086_0d280354+0x1c8>
  4108a6:	mov    rax,QWORD PTR [rax+0x40]
  4108aa:	mov    rcx,rax
  4108ad:	call   408f40 <__swc_fn_6b1cf01f_000084_3953ef98>
  4108b2:	mov    rcx,QWORD PTR [rdi]
  4108b5:	mov    rdi,rcx
  4108b8:	test   rdi,rdi
  4108bb:	je     4108f1 <__swc_fn_6b1cf01f_000086_0d280354+0x201>
  4108bd:	mov    rcx,rsi
  4108c0:	mov    rdx,rax
  4108c3:	mov    r8,rdi
  4108c6:	mov    r9,r13
  4108c9:	mov    al,r15b
  4108cc:	mov    r10,rax
  4108cf:	mov    rdi,QWORD PTR [rsp+0x48]
  4108d4:	mov    r11,rdi
  4108d7:	call   4106f0 <__swc_fn_6b1cf01f_000086_0d280354>
  4108dc:	test   rax,rax
  4108df:	je     4108f1 <__swc_fn_6b1cf01f_000086_0d280354+0x201>
  4108e1:	add    rsp,0x60
  4108e5:	pop    rbx
  4108e6:	pop    r14
  4108e8:	pop    r15
  4108ea:	pop    r13
  4108ec:	pop    r12
  4108ee:	pop    rdi
  4108ef:	pop    rsi
  4108f0:	ret
  4108f1:	add    r14,0x1
  4108f5:	mov    rax,QWORD PTR [rsp+0x50]
  4108fa:	sub    rax,0x1
  4108fe:	mov    rdi,rax
  410901:	test   rax,rax
  410904:	jne    410870 <__swc_fn_6b1cf01f_000086_0d280354+0x180>
  41090a:	xor    eax,eax
  41090c:	add    rsp,0x60
  410910:	pop    rbx
  410911:	pop    r14
  410913:	pop    r15
  410915:	pop    r13
  410917:	pop    r12
  410919:	pop    rdi
  41091a:	pop    rsi
  41091b:	ret
  41091c:	add    BYTE PTR [rax],al
	...

0000000000410920 <__swc_fn_6b1cf01f_000089_c1c9085b>:
  410920:	push   rsi
  410921:	push   rdi
  410922:	push   r12
  410924:	push   r13
  410926:	push   r14
  410928:	push   r15
  41092a:	sub    rsp,0x78
  41092e:	mov    rsi,r10
  410931:	mov    QWORD PTR [rsp+0x68],r10
  410936:	mov    rdi,rcx
  410939:	mov    r12,rdx
  41093c:	mov    r13,r8
  41093f:	mov    r14,r9
  410942:	xor    r8d,r8d
  410945:	call   410a40 <__swc_fn_6b1cf01f_000092_63c1827b>
  41094a:	test   al,al
  41094c:	je     410975 <__swc_fn_6b1cf01f_000089_c1c9085b+0x55>
  41094e:	mov    rcx,r14
  410951:	mov    rdx,r12
  410954:	mov    r8,r13
  410957:	mov    r9,rsi
  41095a:	call   40c7a0 <__swc_fn_6b1cf01f_000088_23214800>
  41095f:	test   al,al
  410961:	je     410975 <__swc_fn_6b1cf01f_000089_c1c9085b+0x55>
  410963:	mov    rax,r13
  410966:	add    rsp,0x78
  41096a:	pop    r15
  41096c:	pop    r14
  41096e:	pop    r13
  410970:	pop    r12
  410972:	pop    rdi
  410973:	pop    rsi
  410974:	ret
  410975:	cmp    BYTE PTR [r12+0x2c],0xe
  41097b:	je     41098e <__swc_fn_6b1cf01f_000089_c1c9085b+0x6e>
  41097d:	xor    eax,eax
  41097f:	add    rsp,0x78
  410983:	pop    r15
  410985:	pop    r14
  410987:	pop    r13
  410989:	pop    r12
  41098b:	pop    rdi
  41098c:	pop    rsi
  41098d:	ret
  41098e:	mov    r15,QWORD PTR [r12+0x98]
  410996:	mov    rax,QWORD PTR [r12+0xa0]
  41099e:	mov    r12,rax
  4109a1:	xor    esi,esi
  4109a3:	test   r12,r12
  4109a6:	je     410a19 <__swc_fn_6b1cf01f_000089_c1c9085b+0xf9>
  4109a8:	nop    DWORD PTR [rax+rax*1+0x0]
  4109b0:	mov    QWORD PTR [rsp+0x70],r12
  4109b5:	lea    r12,[rsi*8+0x0]
  4109bd:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  4109c2:	mov    rcx,rax
  4109c5:	call   408f40 <__swc_fn_6b1cf01f_000084_3953ef98>
  4109ca:	cmp    BYTE PTR [rax+0x2c],0xe
  4109ce:	jne    410a04 <__swc_fn_6b1cf01f_000089_c1c9085b+0xe4>
  4109d0:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  4109d5:	lea    r8,[r13+rcx*1+0x0]
  4109da:	mov    rcx,rdi
  4109dd:	mov    rdx,rax
  4109e0:	mov    r9,r14
  4109e3:	mov    r12,QWORD PTR [rsp+0x68]
  4109e8:	mov    r10,r12
  4109eb:	call   410920 <__swc_fn_6b1cf01f_000089_c1c9085b>
  4109f0:	test   rax,rax
  4109f3:	je     410a04 <__swc_fn_6b1cf01f_000089_c1c9085b+0xe4>
  4109f5:	add    rsp,0x78
  4109f9:	pop    r15
  4109fb:	pop    r14
  4109fd:	pop    r13
  4109ff:	pop    r12
  410a01:	pop    rdi
  410a02:	pop    rsi
  410a03:	ret
  410a04:	add    rsi,0x1
  410a08:	mov    rax,QWORD PTR [rsp+0x70]
  410a0d:	sub    rax,0x1
  410a11:	mov    r12,rax
  410a14:	test   rax,rax
  410a17:	jne    4109b0 <__swc_fn_6b1cf01f_000089_c1c9085b+0x90>
  410a19:	xor    eax,eax
  410a1b:	add    rsp,0x78
  410a1f:	pop    r15
  410a21:	pop    r14
  410a23:	pop    r13
  410a25:	pop    r12
  410a27:	pop    rdi
  410a28:	pop    rsi
  410a29:	ret
	...

0000000000410a40 <__swc_fn_6b1cf01f_000092_63c1827b>:
  410a40:	push   rbx
  410a41:	push   rsi
  410a42:	push   rdi
  410a43:	push   r12
  410a45:	push   r13
  410a47:	push   r14
  410a49:	push   r15
  410a4b:	sub    rsp,0x120
  410a52:	mov    rbx,r8
  410a55:	mov    rsi,rdx
  410a58:	test   rcx,rcx
  410a5b:	jne    410a7a <__swc_fn_6b1cf01f_000092_63c1827b+0x3a>
  410a5d:	test   rsi,rsi
  410a60:	jne    410a7a <__swc_fn_6b1cf01f_000092_63c1827b+0x3a>
  410a62:	mov    eax,0x1
  410a67:	add    rsp,0x120
  410a6e:	pop    r15
  410a70:	pop    r14
  410a72:	pop    r13
  410a74:	pop    r12
  410a76:	pop    rdi
  410a77:	pop    rsi
  410a78:	pop    rbx
  410a79:	ret
  410a7a:	test   rcx,rcx
  410a7d:	je     410a84 <__swc_fn_6b1cf01f_000092_63c1827b+0x44>
  410a7f:	test   rsi,rsi
  410a82:	jne    410a99 <__swc_fn_6b1cf01f_000092_63c1827b+0x59>
  410a84:	xor    eax,eax
  410a86:	add    rsp,0x120
  410a8d:	pop    r15
  410a8f:	pop    r14
  410a91:	pop    r13
  410a93:	pop    r12
  410a95:	pop    rdi
  410a96:	pop    rsi
  410a97:	pop    rbx
  410a98:	ret
  410a99:	call   408f40 <__swc_fn_6b1cf01f_000084_3953ef98>
  410a9e:	mov    rdi,rax
  410aa1:	mov    rcx,rsi
  410aa4:	call   408f40 <__swc_fn_6b1cf01f_000084_3953ef98>
  410aa9:	test   bl,0x1
  410aac:	je     410aea <__swc_fn_6b1cf01f_000092_63c1827b+0xaa>
  410aae:	rex cmp BYTE PTR [rdi+0x2c],0x6
  410ab3:	jne    410aea <__swc_fn_6b1cf01f_000092_63c1827b+0xaa>
  410ab5:	mov    ecx,DWORD PTR [rdi+0x28]
  410ab8:	test   ecx,0x1000
  410abe:	je     410aea <__swc_fn_6b1cf01f_000092_63c1827b+0xaa>
  410ac0:	test   ecx,0x10000
  410ac6:	je     410aea <__swc_fn_6b1cf01f_000092_63c1827b+0xaa>
  410ac8:	mov    rcx,QWORD PTR [rdi+0x40]
  410acc:	mov    rdx,rax
  410acf:	mov    r8d,ebx
  410ad2:	call   410a40 <__swc_fn_6b1cf01f_000092_63c1827b>
  410ad7:	add    rsp,0x120
  410ade:	pop    r15
  410ae0:	pop    r14
  410ae2:	pop    r13
  410ae4:	pop    r12
  410ae6:	pop    rdi
  410ae7:	pop    rsi
  410ae8:	pop    rbx
  410ae9:	ret
  410aea:	mov    cl,BYTE PTR [rax+0x2c]
  410aed:	rex cmp BYTE PTR [rdi+0x2c],cl
  410af1:	jne    410afb <__swc_fn_6b1cf01f_000092_63c1827b+0xbb>
  410af3:	mov    ecx,DWORD PTR [rax+0x20]
  410af6:	cmp    DWORD PTR [rdi+0x20],ecx
  410af9:	je     410b10 <__swc_fn_6b1cf01f_000092_63c1827b+0xd0>
  410afb:	xor    eax,eax
  410afd:	add    rsp,0x120
  410b04:	pop    r15
  410b06:	pop    r14
  410b08:	pop    r13
  410b0a:	pop    r12
  410b0c:	pop    rdi
  410b0d:	pop    rsi
  410b0e:	pop    rbx
  410b0f:	ret
  410b10:	mov    ecx,DWORD PTR [rdi+0x28]
  410b13:	and    ecx,0xffb5ffff
  410b19:	mov    edx,DWORD PTR [rax+0x28]
  410b1c:	and    edx,0xffb5ffff
  410b22:	cmp    ecx,edx
  410b24:	je     410b3b <__swc_fn_6b1cf01f_000092_63c1827b+0xfb>
  410b26:	xor    eax,eax
  410b28:	add    rsp,0x120
  410b2f:	pop    r15
  410b31:	pop    r14
  410b33:	pop    r13
  410b35:	pop    r12
  410b37:	pop    rdi
  410b38:	pop    rsi
  410b39:	pop    rbx
  410b3a:	ret
  410b3b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  410b40:	jne    410b95 <__swc_fn_6b1cf01f_000092_63c1827b+0x155>
  410b42:	mov    cl,BYTE PTR [rax+0x40]
  410b45:	rex cmp BYTE PTR [rdi+0x40],cl
  410b49:	je     410b60 <__swc_fn_6b1cf01f_000092_63c1827b+0x120>
  410b4b:	xor    eax,eax
  410b4d:	add    rsp,0x120
  410b54:	pop    r15
  410b56:	pop    r14
  410b58:	pop    r13
  410b5a:	pop    r12
  410b5c:	pop    rdi
  410b5d:	pop    rsi
  410b5e:	pop    rbx
  410b5f:	ret
  410b60:	rex cmp BYTE PTR [rdi+0x40],0xd
  410b65:	je     410b7d <__swc_fn_6b1cf01f_000092_63c1827b+0x13d>
  410b67:	rex cmp BYTE PTR [rdi+0x40],0xf
  410b6c:	sete   cl
  410b6f:	je     410b79 <__swc_fn_6b1cf01f_000092_63c1827b+0x139>
  410b71:	rex cmp BYTE PTR [rdi+0x40],0xe
  410b76:	sete   cl
  410b79:	test   cl,cl
  410b7b:	je     410b95 <__swc_fn_6b1cf01f_000092_63c1827b+0x155>
  410b7d:	mov    eax,0x1
  410b82:	add    rsp,0x120
  410b89:	pop    r15
  410b8b:	pop    r14
  410b8d:	pop    r13
  410b8f:	pop    r12
  410b91:	pop    rdi
  410b92:	pop    rsi
  410b93:	pop    rbx
  410b94:	ret
  410b95:	test   DWORD PTR [rdi+0x28],0x200200
  410b9c:	je     410d4f <__swc_fn_6b1cf01f_000092_63c1827b+0x30f>
  410ba2:	mov    rsi,QWORD PTR [rdi+0x88]
  410ba9:	mov    rdi,QWORD PTR [rdi+0x90]
  410bb0:	mov    r12,QWORD PTR [rax+0x88]
  410bb7:	mov    rax,QWORD PTR [rax+0x90]
  410bbe:	cmp    rdi,rax
  410bc1:	je     410bd8 <__swc_fn_6b1cf01f_000092_63c1827b+0x198>
  410bc3:	xor    eax,eax
  410bc5:	add    rsp,0x120
  410bcc:	pop    r15
  410bce:	pop    r14
  410bd0:	pop    r13
  410bd2:	pop    r12
  410bd4:	pop    rdi
  410bd5:	pop    rsi
  410bd6:	pop    rbx
  410bd7:	ret
  410bd8:	test   rsi,rsi
  410bdb:	je     410be2 <__swc_fn_6b1cf01f_000092_63c1827b+0x1a2>
  410bdd:	test   r12,r12
  410be0:	jne    410bfa <__swc_fn_6b1cf01f_000092_63c1827b+0x1ba>
  410be2:	mov    eax,0x1
  410be7:	add    rsp,0x120
  410bee:	pop    r15
  410bf0:	pop    r14
  410bf2:	pop    r13
  410bf4:	pop    r12
  410bf6:	pop    rdi
  410bf7:	pop    rsi
  410bf8:	pop    rbx
  410bf9:	ret
  410bfa:	xor    r13d,r13d
  410bfd:	test   rdi,rdi
  410c00:	jbe    410d37 <__swc_fn_6b1cf01f_000092_63c1827b+0x2f7>
  410c06:	lea    r14,[rsp+0x78]
  410c0b:	lea    r15,[rsp+0xb8]
  410c13:	cs nop WORD PTR [rax+rax*1+0x0]
  410c1d:	cs nop WORD PTR [rax+rax*1+0x0]
  410c27:	nop    WORD PTR [rax+rax*1+0x0]
  410c30:	lea    rax,[r13*8+0x0]
  410c38:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  410c3d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  410c43:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  410c49:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  410c52:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  410c58:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  410c61:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  410c67:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  410c70:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  410c76:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  410c7f:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  410c86:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  410c8f:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  410c96:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  410c9f:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  410ca6:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  410caf:	xor    al,al
  410cb1:	rex test BYTE PTR [rsp+0xb0],0x1
  410cba:	je     410cc1 <__swc_fn_6b1cf01f_000092_63c1827b+0x281>
  410cbc:	mov    eax,0x1
  410cc1:	rex test BYTE PTR [rsp+0xf0],0x1
  410cca:	je     410cd1 <__swc_fn_6b1cf01f_000092_63c1827b+0x291>
  410ccc:	mov    eax,0x1
  410cd1:	test   al,al
  410cd3:	jne    410cf9 <__swc_fn_6b1cf01f_000092_63c1827b+0x2b9>
  410cd5:	mov    rcx,r14
  410cd8:	mov    rdx,r15
  410cdb:	call   412250 <__swc_fn_6b1cf01f_000149_6fb05988>
  410ce0:	test   al,al
  410ce2:	jne    410cf9 <__swc_fn_6b1cf01f_000092_63c1827b+0x2b9>
  410ce4:	xor    eax,eax
  410ce6:	add    rsp,0x120
  410ced:	pop    r15
  410cef:	pop    r14
  410cf1:	pop    r13
  410cf3:	pop    r12
  410cf5:	pop    rdi
  410cf6:	pop    rsi
  410cf7:	pop    rbx
  410cf8:	ret
  410cf9:	mov    rcx,QWORD PTR [rsp+0x88]
  410d01:	mov    rdx,QWORD PTR [rsp+0xc8]
  410d09:	mov    r8d,ebx
  410d0c:	call   410a40 <__swc_fn_6b1cf01f_000092_63c1827b>
  410d11:	test   al,al
  410d13:	jne    410d2a <__swc_fn_6b1cf01f_000092_63c1827b+0x2ea>
  410d15:	xor    eax,eax
  410d17:	add    rsp,0x120
  410d1e:	pop    r15
  410d20:	pop    r14
  410d22:	pop    r13
  410d24:	pop    r12
  410d26:	pop    rdi
  410d27:	pop    rsi
  410d28:	pop    rbx
  410d29:	ret
  410d2a:	add    r13,0x1
  410d2e:	cmp    r13,rdi
  410d31:	jb     410c30 <__swc_fn_6b1cf01f_000092_63c1827b+0x1f0>
  410d37:	mov    eax,0x1
  410d3c:	add    rsp,0x120
  410d43:	pop    r15
  410d45:	pop    r14
  410d47:	pop    r13
  410d49:	pop    r12
  410d4b:	pop    rdi
  410d4c:	pop    rsi
  410d4d:	pop    rbx
  410d4e:	ret
  410d4f:	test   bl,0x2
  410d52:	je     410d74 <__swc_fn_6b1cf01f_000092_63c1827b+0x334>
  410d54:	lea    rcx,[rdi+0x10]
  410d58:	lea    rdx,[rax+0x10]
  410d5c:	call   412250 <__swc_fn_6b1cf01f_000149_6fb05988>
  410d61:	add    rsp,0x120
  410d68:	pop    r15
  410d6a:	pop    r14
  410d6c:	pop    r13
  410d6e:	pop    r12
  410d70:	pop    rdi
  410d71:	pop    rsi
  410d72:	pop    rbx
  410d73:	ret
  410d74:	mov    rcx,rdi
  410d77:	mov    rdx,rax
  410d7a:	call   412250 <__swc_fn_6b1cf01f_000149_6fb05988>
  410d7f:	add    rsp,0x120
  410d86:	pop    r15
  410d88:	pop    r14
  410d8a:	pop    r13
  410d8c:	pop    r12
  410d8e:	pop    rdi
  410d8f:	pop    rsi
  410d90:	pop    rbx
  410d91:	ret
	...

0000000000410da0 <__swc_fn_6b1cf01f_000095_4185993f>:
  410da0:	push   rbx
  410da1:	mov    rbx,rcx
  410da4:	call   409070 <__swc_fn_6b1cf01f_000093_ad13d15c>
  410da9:	movzx  r11d,al
  410dad:	mov    r8b,r11b
  410db0:	test   r8b,r8b
  410db3:	jne    410dcd <__swc_fn_6b1cf01f_000095_4185993f+0x2d>
  410db5:	mov    r11d,0x1
  410dbb:	mov    r10,rbx
  410dbe:	mov    r9,r11
  410dc1:	and    r10,r11
  410dc4:	test   r10,r10
  410dc7:	setne  dl
  410dca:	mov    r8b,dl
  410dcd:	mov    r10b,r8b
  410dd0:	test   r10b,r10b
  410dd3:	je     410dd7 <__swc_fn_6b1cf01f_000095_4185993f+0x37>
  410dd5:	pop    rbx
  410dd6:	ret
  410dd7:	call   40dca0 <__swc_fn_6b1cf01f_000139_519fdf94>
  410ddc:	movzx  r10d,al
  410de0:	test   r10b,r10b
  410de3:	je     410de7 <__swc_fn_6b1cf01f_000095_4185993f+0x47>
  410de5:	pop    rbx
  410de6:	ret
  410de7:	lea    r10,[rip+0x2652]        # 413440 <__swc_rdata_base_6b1cf01f+0x330>
  410dee:	mov    rax,r10
  410df1:	mov    rcx,rax
  410df4:	call   40d7d0 <__swc_fn_6b1cf01f_000118_2648f149>
  410df9:	call   4098f0 <__swc_fn_6b1cf01f_000120_be2e2f68>
  410dfe:	pop    rbx
  410dff:	ret

0000000000410e00 <__swc_fn_6b1cf01f_000098_d4bdcaa4>:
  410e00:	push   rbx
  410e01:	sub    rsp,0x70
  410e05:	vxorps xmm0,xmm0,xmm0
  410e09:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  410e0f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  410e15:	vzeroupper
  410e18:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  410e1e:	mov    QWORD PTR [rsp+0x48],rdx
  410e23:	mov    rax,r8
  410e26:	cmp    r8,0x1
  410e2a:	mov    edx,0x1
  410e2f:	cmovb  rax,rdx
  410e33:	mov    QWORD PTR [rsp+0x50],rax
  410e38:	mov    rbx,QWORD PTR [rcx+0x8]
  410e3c:	mov    rbx,QWORD PTR [rbx+0x18]
  410e40:	mov    rcx,QWORD PTR [rcx]
  410e43:	lea    rdx,[rsp+0x8]
  410e48:	call   rbx
  410e4a:	add    rsp,0x70
  410e4e:	pop    rbx
  410e4f:	ret

0000000000410e50 <__swc_fn_6b1cf01f_000101_2fdd2c61>:
  410e50:	push   rbx
  410e51:	push   rsi
  410e52:	push   rdi
  410e53:	sub    rsp,0x30
  410e57:	mov    rbx,rcx
  410e5a:	test   rcx,rcx
  410e5d:	je     410e72 <__swc_fn_6b1cf01f_000101_2fdd2c61+0x22>
  410e5f:	mov    rcx,rbx
  410e62:	mov    edx,0x1
  410e67:	call   4106a0 <__swc_fn_6b1cf01f_000080_63a67586>
  410e6c:	cmp    rax,0x1
  410e70:	je     410e7a <__swc_fn_6b1cf01f_000101_2fdd2c61+0x2a>
  410e72:	add    rsp,0x30
  410e76:	pop    rdi
  410e77:	pop    rsi
  410e78:	pop    rbx
  410e79:	ret
  410e7a:	lea    rsi,[rsp+0x8]
  410e7f:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  410e84:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410e8a:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  410e8f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  410e95:	mov    rax,QWORD PTR [rsp+0x20]
  410e9a:	test   rax,rax
  410e9d:	je     410eb3 <__swc_fn_6b1cf01f_000101_2fdd2c61+0x63>
  410e9f:	test   DWORD PTR [rax+0x28],0x400000
  410ea6:	je     410eb3 <__swc_fn_6b1cf01f_000101_2fdd2c61+0x63>
  410ea8:	mov    rcx,QWORD PTR [rax+0x30]
  410eac:	test   rcx,rcx
  410eaf:	cmovne rax,rcx
  410eb3:	mov    edi,DWORD PTR [rax+0x20]
  410eb6:	lea    rcx,[rsp+0x18]
  410ebb:	call   409250 <__swc_fn_6b1cf01f_000102_3c3b96fb>
  410ec0:	mov    rcx,rsi
  410ec3:	mov    rdx,QWORD PTR [rsp+0x18]
  410ec8:	mov    r8,rdi
  410ecb:	call   410e00 <__swc_fn_6b1cf01f_000098_d4bdcaa4>
  410ed0:	mov    rcx,QWORD PTR [rbx+0x28]
  410ed4:	call   40cd80 <__swc_fn_6b1cf01f_000100_e34f54dc>
  410ed9:	mov    rcx,rsi
  410edc:	mov    rdx,rbx
  410edf:	mov    r8d,0x30
  410ee5:	call   410e00 <__swc_fn_6b1cf01f_000098_d4bdcaa4>
  410eea:	add    rsp,0x30
  410eee:	pop    rdi
  410eef:	pop    rsi
  410ef0:	pop    rbx
  410ef1:	ret
	...

0000000000410f00 <__swc_fn_6b1cf01f_000104_ffe51047>:
  410f00:	push   rbp
  410f01:	push   rbx
  410f02:	push   rsi
  410f03:	push   rdi
  410f04:	push   r12
  410f06:	push   r13
  410f08:	push   r14
  410f0a:	push   r15
  410f0c:	sub    rsp,0x500
  410f13:	mov    rbp,rsp
  410f16:	mov    rbx,rsp
  410f19:	mov    rsi,rdx
  410f1c:	mov    rdi,rcx
  410f1f:	mov    rcx,QWORD PTR [rip+0x15e1a]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  410f26:	test   rcx,rcx
  410f29:	jne    410f43 <__swc_fn_6b1cf01f_000104_ffe51047+0x43>
  410f2b:	sub    rsp,0x8
  410f2f:	call   412640 <__swc_fn_6b1cf01f_000167_994c8876>
  410f34:	add    rsp,0x8
  410f38:	lea    rcx,[rax+0x1]
  410f3c:	mov    QWORD PTR [rip+0x15dfd],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  410f43:	dec    rcx
  410f46:	sub    rsp,0x8
  410f4a:	call   40f580 <__swc_fn_6b1cf01f_000169_360af05d>
  410f4f:	add    rsp,0x8
  410f53:	mov    r12,rax
  410f56:	mov    QWORD PTR [rsp+0x4f0],rax
  410f5e:	lea    rax,[rip+0x261b]        # 413580 <__swc_rdata_base_6b1cf01f+0x470>
  410f65:	sub    rsp,0x20
  410f69:	mov    rcx,rsp
  410f6c:	mov    QWORD PTR [rcx],rax
  410f6f:	lea    r13,[rip+0x22ea]        # 413260 <__swc_rdata_base_6b1cf01f+0x150>
  410f76:	mov    QWORD PTR [rcx+0x8],r13
  410f7a:	mov    QWORD PTR [rcx+0x10],rsp
  410f7e:	mov    QWORD PTR [rcx+0x18],0x1
  410f86:	lea    rcx,[rsp+0x10]
  410f8b:	sub    rsp,0x8
  410f8f:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  410f94:	add    rsp,0x8
  410f98:	add    rsp,0x20
  410f9c:	lea    rax,[rip+0x25ed]        # 413590 <__swc_rdata_base_6b1cf01f+0x480>
  410fa3:	sub    rsp,0x20
  410fa7:	mov    rcx,rsp
  410faa:	mov    QWORD PTR [rcx],rax
  410fad:	mov    QWORD PTR [rcx+0x8],r13
  410fb1:	mov    QWORD PTR [rcx+0x10],rsp
  410fb5:	mov    QWORD PTR [rcx+0x18],0x1
  410fbd:	lea    rcx,[rsp+0x10]
  410fc2:	sub    rsp,0x8
  410fc6:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  410fcb:	add    rsp,0x8
  410fcf:	add    rsp,0x20
  410fd3:	lea    r14,[rip+0x2276]        # 413250 <__swc_rdata_base_6b1cf01f+0x140>
  410fda:	sub    rsp,0x50
  410fde:	mov    rax,rsp
  410fe1:	vmovups xmm0,XMMWORD PTR [rip+0x26df]        # 4136c8 <__swc_rdata_base_6b1cf01f+0x5b8>
  410fe9:	vmovups XMMWORD PTR [rax],xmm0
  410fed:	mov    QWORD PTR [rax+0x10],rsp
  410ff1:	mov    QWORD PTR [rax+0x18],r13
  410ff5:	mov    QWORD PTR [rax+0x20],rdi
  410ff9:	lea    rdi,[rip+0x25a0]        # 4135a0 <__swc_rdata_base_6b1cf01f+0x490>
  411000:	mov    QWORD PTR [rax+0x28],rdi
  411004:	mov    QWORD PTR [rax+0x30],r14
  411008:	mov    QWORD PTR [rax+0x38],r13
  41100c:	lea    rcx,[rsp+0x10]
  411011:	mov    QWORD PTR [rax+0x40],rcx
  411015:	mov    QWORD PTR [rax+0x48],0x3
  41101d:	lea    rcx,[rsp+0x40]
  411022:	sub    rsp,0x8
  411026:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  41102b:	add    rsp,0x8
  41102f:	add    rsp,0x50
  411033:	lea    rax,[rip+0x25ae]        # 4135e8 <__swc_rdata_base_6b1cf01f+0x4d8>
  41103a:	sub    rsp,0x20
  41103e:	mov    rcx,rsp
  411041:	mov    QWORD PTR [rcx],rax
  411044:	mov    QWORD PTR [rcx+0x8],r13
  411048:	mov    QWORD PTR [rcx+0x10],rsp
  41104c:	mov    QWORD PTR [rcx+0x18],0x1
  411054:	lea    rcx,[rsp+0x10]
  411059:	sub    rsp,0x8
  41105d:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  411062:	add    rsp,0x8
  411066:	add    rsp,0x20
  41106a:	mov    eax,DWORD PTR [rsi+0x20]
  41106d:	mov    ecx,DWORD PTR [rsi+0x24]
  411070:	sub    rsp,0xa0
  411077:	mov    rdx,rsp
  41107a:	mov    QWORD PTR [rdx+0x30],rsi
  41107e:	mov    QWORD PTR [rdx+0x38],rdi
  411082:	vmovups xmm0,XMMWORD PTR [rip+0x25d6]        # 413660 <__swc_rdata_base_6b1cf01f+0x550>
  41108a:	vmovups XMMWORD PTR [rdx],xmm0
  41108e:	mov    QWORD PTR [rdx+0x40],rsp
  411092:	mov    QWORD PTR [rdx+0x48],r13
  411096:	mov    DWORD PTR [rdx+0x10],eax
  411099:	lea    rax,[rsp+0x10]
  41109e:	mov    QWORD PTR [rdx+0x50],rax
  4110a2:	lea    rax,[rip+0x254f]        # 4135f8 <__swc_rdata_base_6b1cf01f+0x4e8>
  4110a9:	mov    QWORD PTR [rdx+0x58],rax
  4110ad:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  4110b2:	lea    r8,[rsp+0x18]
  4110b7:	mov    QWORD PTR [rdx+0x60],r8
  4110bb:	mov    QWORD PTR [rdx+0x68],r13
  4110bf:	mov    DWORD PTR [rdx+0x28],ecx
  4110c2:	lea    rcx,[rdx+0x28]
  4110c6:	mov    QWORD PTR [rdx+0x70],rcx
  4110ca:	mov    QWORD PTR [rdx+0x78],rax
  4110ce:	mov    QWORD PTR [rdx+0x80],r14
  4110d5:	mov    QWORD PTR [rdx+0x88],r13
  4110dc:	lea    rax,[rdx+0x30]
  4110e0:	mov    QWORD PTR [rdx+0x90],rax
  4110e7:	mov    QWORD PTR [rdx+0x98],0x6
  4110f2:	lea    rcx,[rdx+0x90]
  4110f9:	sub    rsp,0x8
  4110fd:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  411102:	add    rsp,0x8
  411106:	add    rsp,0xa0
  41110d:	sub    rsp,0x20
  411111:	mov    rax,rsp
  411114:	mov    QWORD PTR [rax],r14
  411117:	mov    QWORD PTR [rax+0x8],r13
  41111b:	mov    QWORD PTR [rax+0x10],rsp
  41111f:	mov    QWORD PTR [rax+0x18],0x1
  411127:	lea    rcx,[rsp+0x10]
  41112c:	sub    rsp,0x8
  411130:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  411135:	add    rsp,0x8
  411139:	add    rsp,0x20
  41113d:	mov    eax,DWORD PTR [r12+0x9ac]
  411145:	test   eax,eax
  411147:	je     411380 <__swc_fn_6b1cf01f_000104_ffe51047+0x480>
  41114d:	lea    rax,[rip+0x24ec]        # 413640 <__swc_rdata_base_6b1cf01f+0x530>
  411154:	sub    rsp,0x20
  411158:	mov    rcx,rsp
  41115b:	mov    QWORD PTR [rcx],rax
  41115e:	mov    QWORD PTR [rcx+0x8],r13
  411162:	mov    QWORD PTR [rcx+0x10],rsp
  411166:	mov    QWORD PTR [rcx+0x18],0x1
  41116e:	lea    rcx,[rsp+0x10]
  411173:	sub    rsp,0x8
  411177:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  41117c:	add    rsp,0x8
  411180:	add    rsp,0x20
  411184:	mov    eax,DWORD PTR [r12+0x9ac]
  41118c:	dec    eax
  41118e:	mov    esi,eax
  411190:	test   esi,esi
  411192:	jl     411350 <__swc_fn_6b1cf01f_000104_ffe51047+0x450>
  411198:	jmp    4111a4 <__swc_fn_6b1cf01f_000104_ffe51047+0x2a4>
  41119a:	nop    WORD PTR [rax+rax*1+0x0]
  4111a0:	dec    esi
  4111a2:	jmp    411190 <__swc_fn_6b1cf01f_000104_ffe51047+0x290>
  4111a4:	lea    rax,[rip+0x24a5]        # 413650 <__swc_rdata_base_6b1cf01f+0x540>
  4111ab:	sub    rsp,0x20
  4111af:	mov    rcx,rsp
  4111b2:	mov    QWORD PTR [rcx],rax
  4111b5:	mov    QWORD PTR [rcx+0x8],r13
  4111b9:	mov    QWORD PTR [rcx+0x10],rsp
  4111bd:	mov    QWORD PTR [rcx+0x18],0x1
  4111c5:	lea    rcx,[rsp+0x10]
  4111ca:	sub    rsp,0x8
  4111ce:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  4111d3:	add    rsp,0x8
  4111d7:	add    rsp,0x20
  4111db:	movsxd rax,esi
  4111de:	imul   r15,rax,0x30
  4111e2:	add    r15,r12
  4111e5:	add    r15,0xf8
  4111ec:	sub    rsp,0x20
  4111f0:	mov    rax,rsp
  4111f3:	mov    QWORD PTR [rax],r15
  4111f6:	mov    QWORD PTR [rax+0x8],rdi
  4111fa:	mov    QWORD PTR [rax+0x10],rsp
  4111fe:	mov    QWORD PTR [rax+0x18],0x1
  411206:	lea    rcx,[rsp+0x10]
  41120b:	sub    rsp,0x8
  41120f:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  411214:	add    rsp,0x8
  411218:	add    rsp,0x20
  41121c:	mov    QWORD PTR [rsp+0x4f8],rsi
  411224:	lea    rsi,[rip+0x2435]        # 413660 <__swc_rdata_base_6b1cf01f+0x550>
  41122b:	sub    rsp,0x20
  41122f:	mov    rax,rsp
  411232:	mov    QWORD PTR [rax],rsi
  411235:	mov    QWORD PTR [rax+0x8],r13
  411239:	mov    QWORD PTR [rax+0x10],rsp
  41123d:	mov    QWORD PTR [rax+0x18],0x1
  411245:	lea    rcx,[rsp+0x10]
  41124a:	sub    rsp,0x8
  41124e:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  411253:	add    rsp,0x8
  411257:	add    rsp,0x20
  41125b:	sub    rsp,0x30
  41125f:	mov    rax,rsp
  411262:	mov    ecx,DWORD PTR [r15+0x20]
  411266:	mov    QWORD PTR [rax],rcx
  411269:	mov    QWORD PTR [rax+0x8],rsp
  41126d:	lea    rdi,[rip+0x23fc]        # 413670 <__swc_rdata_base_6b1cf01f+0x560>
  411274:	mov    QWORD PTR [rax+0x10],rdi
  411278:	lea    rcx,[rsp+0x8]
  41127d:	mov    QWORD PTR [rax+0x18],rcx
  411281:	mov    QWORD PTR [rax+0x20],0x1
  411289:	lea    rcx,[rsp+0x18]
  41128e:	sub    rsp,0x8
  411292:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  411297:	add    rsp,0x8
  41129b:	add    rsp,0x30
  41129f:	sub    rsp,0x20
  4112a3:	mov    rax,rsp
  4112a6:	mov    QWORD PTR [rax],rsi
  4112a9:	mov    QWORD PTR [rax+0x8],r13
  4112ad:	mov    QWORD PTR [rax+0x10],rsp
  4112b1:	mov    QWORD PTR [rax+0x18],0x1
  4112b9:	lea    rcx,[rsp+0x10]
  4112be:	sub    rsp,0x8
  4112c2:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  4112c7:	add    rsp,0x8
  4112cb:	add    rsp,0x20
  4112cf:	sub    rsp,0x30
  4112d3:	mov    rax,rsp
  4112d6:	mov    ecx,DWORD PTR [r15+0x24]
  4112da:	mov    QWORD PTR [rax],rcx
  4112dd:	mov    QWORD PTR [rax+0x8],rsp
  4112e1:	mov    QWORD PTR [rax+0x10],rdi
  4112e5:	lea    rcx,[rsp+0x8]
  4112ea:	mov    QWORD PTR [rax+0x18],rcx
  4112ee:	mov    QWORD PTR [rax+0x20],0x1
  4112f6:	lea    rcx,[rsp+0x18]
  4112fb:	sub    rsp,0x8
  4112ff:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  411304:	add    rsp,0x8
  411308:	add    rsp,0x30
  41130c:	sub    rsp,0x20
  411310:	mov    rax,rsp
  411313:	mov    QWORD PTR [rax],r14
  411316:	mov    QWORD PTR [rax+0x8],r13
  41131a:	mov    QWORD PTR [rax+0x10],rsp
  41131e:	mov    QWORD PTR [rax+0x18],0x1
  411326:	lea    rcx,[rsp+0x10]
  41132b:	sub    rsp,0x8
  41132f:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  411334:	add    rsp,0x8
  411338:	add    rsp,0x20
  41133c:	lea    rdi,[rip+0x225d]        # 4135a0 <__swc_rdata_base_6b1cf01f+0x490>
  411343:	mov    rsi,QWORD PTR [rsp+0x4f8]
  41134b:	jmp    4111a0 <__swc_fn_6b1cf01f_000104_ffe51047+0x2a0>
  411350:	sub    rsp,0x20
  411354:	mov    rax,rsp
  411357:	mov    QWORD PTR [rax],r14
  41135a:	mov    QWORD PTR [rax+0x8],r13
  41135e:	mov    QWORD PTR [rax+0x10],rsp
  411362:	mov    QWORD PTR [rax+0x18],0x1
  41136a:	lea    rcx,[rsp+0x10]
  41136f:	sub    rsp,0x8
  411373:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  411378:	add    rsp,0x8
  41137c:	add    rsp,0x20
  411380:	lea    rax,[rbx+0x28]
  411384:	mov    rcx,rax
  411387:	mov    QWORD PTR [rbx+0x28],0x0
  41138f:	mov    QWORD PTR [rbx+0x30],0x0
  411397:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  41139c:	add    rcx,0x10
  4113a0:	mov    edx,0x1f
  4113a5:	cs nop WORD PTR [rax+rax*1+0x0]
  4113af:	nop
  4113b0:	vmovups XMMWORD PTR [rcx],xmm0
  4113b4:	add    rcx,0x10
  4113b8:	sub    rdx,0x1
  4113bc:	jne    4113b0 <__swc_fn_6b1cf01f_000104_ffe51047+0x4b0>
  4113be:	lea    rsi,[rbx+0x228]
  4113c5:	xor    ecx,ecx
  4113c7:	cs nop WORD PTR [rax+rax*1+0x0]
  4113d1:	cs nop WORD PTR [rax+rax*1+0x0]
  4113db:	nop    DWORD PTR [rax+rax*1+0x0]
  4113e0:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  4113e5:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  4113ea:	add    rcx,0x10
  4113ee:	cmp    rcx,0x200
  4113f5:	jne    4113e0 <__swc_fn_6b1cf01f_000104_ffe51047+0x4e0>
  4113f7:	mov    eax,DWORD PTR [r12+0xbc8]
  4113ff:	lea    rcx,[r12+0x9c8]
  411407:	mov    QWORD PTR [rbx+0x428],rcx
  41140e:	mov    QWORD PTR [rbx+0x430],rax
  411415:	lea    rdi,[rbx+0x438]
  41141c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  411424:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  41142c:	mov    eax,DWORD PTR [r12+0xbc8]
  411434:	test   eax,eax
  411436:	jne    411483 <__swc_fn_6b1cf01f_000104_ffe51047+0x583>
  411438:	lea    rax,[rbx+0x448]
  41143f:	mov    QWORD PTR [rbx+0x448],rsi
  411446:	mov    QWORD PTR [rax+0x8],0x40
  41144e:	mov    ecx,0x1
  411453:	mov    rdx,rax
  411456:	sub    rsp,0x8
  41145a:	call   40d8e0 <__swc_fn_6b1cf01f_000121_4f256d58>
  41145f:	add    rsp,0x8
  411463:	mov    QWORD PTR [rbx+0x460],rsi
  41146a:	mov    ecx,eax
  41146c:	mov    QWORD PTR [rbx+0x468],rcx
  411473:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  41147b:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  411483:	mov    rsi,QWORD PTR [rbx+0x438]
  41148a:	mov    rax,QWORD PTR [rbx+0x440]
  411491:	mov    r15,rax
  411494:	xor    r12d,r12d
  411497:	test   r15,r15
  41149a:	je     411550 <__swc_fn_6b1cf01f_000104_ffe51047+0x650>
  4114a0:	mov    rax,QWORD PTR [rsi+r12*8]
  4114a4:	test   rax,rax
  4114a7:	je     4114c6 <__swc_fn_6b1cf01f_000104_ffe51047+0x5c6>
  4114a9:	lea    rcx,[rbx+0x4b8]
  4114b0:	mov    rdx,rax
  4114b3:	sub    rsp,0x8
  4114b7:	call   4123b0 <__swc_fn_6b1cf01f_000164_cc119975>
  4114bc:	add    rsp,0x8
  4114c0:	mov    al,BYTE PTR [rax]
  4114c2:	test   al,al
  4114c4:	jne    4114d2 <__swc_fn_6b1cf01f_000104_ffe51047+0x5d2>
  4114c6:	add    r12,0x1
  4114ca:	sub    r15,0x1
  4114ce:	jne    4114a0 <__swc_fn_6b1cf01f_000104_ffe51047+0x5a0>
  4114d0:	jmp    411550 <__swc_fn_6b1cf01f_000104_ffe51047+0x650>
  4114d2:	lea    rax,[rip+0x21df]        # 4136b8 <__swc_rdata_base_6b1cf01f+0x5a8>
  4114d9:	sub    rsp,0x20
  4114dd:	mov    rcx,rsp
  4114e0:	mov    QWORD PTR [rcx],rax
  4114e3:	mov    QWORD PTR [rcx+0x8],r13
  4114e7:	mov    QWORD PTR [rcx+0x10],rsp
  4114eb:	mov    QWORD PTR [rcx+0x18],0x1
  4114f3:	lea    rcx,[rsp+0x10]
  4114f8:	sub    rsp,0x8
  4114fc:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  411501:	add    rsp,0x8
  411505:	add    rsp,0x20
  411509:	mov    rcx,rdi
  41150c:	xor    edx,edx
  41150e:	mov    al,0x1
  411510:	mov    r8,rax
  411513:	sub    rsp,0x8
  411517:	call   40a180 <__swc_fn_6b1cf01f_000165_bcc835b8>
  41151c:	add    rsp,0x8
  411520:	sub    rsp,0x20
  411524:	mov    rax,rsp
  411527:	mov    QWORD PTR [rax],r14
  41152a:	mov    QWORD PTR [rax+0x8],r13
  41152e:	mov    QWORD PTR [rax+0x10],rsp
  411532:	mov    QWORD PTR [rax+0x18],0x1
  41153a:	lea    rcx,[rsp+0x10]
  41153f:	sub    rsp,0x8
  411543:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  411548:	add    rsp,0x8
  41154c:	add    rsp,0x20
  411550:	mov    r12,QWORD PTR [rsp+0x4f0]
  411558:	mov    DWORD PTR [r12+0xbc8],0x0
  411564:	add    rsp,0x500
  41156b:	pop    r15
  41156d:	pop    r14
  41156f:	pop    r13
  411571:	pop    r12
  411573:	pop    rdi
  411574:	pop    rsi
  411575:	pop    rbx
  411576:	pop    rbp
  411577:	ret
	...

0000000000411580 <__swc_fn_6b1cf01f_000107_7c204aac>:
  411580:	sub    rsp,0x8
  411584:	test   r8,r8
  411587:	je     41158e <__swc_fn_6b1cf01f_000107_7c204aac+0xe>
  411589:	call   40d010 <__swc_fn_6b1cf01f_000106_c51c3158>
  41158e:	add    rsp,0x8
  411592:	ret
	...

00000000004115a0 <__swc_fn_6b1cf01f_000110_126150d1>:
  4115a0:	push   rsi
  4115a1:	push   rdi
  4115a2:	push   r12
  4115a4:	push   r13
  4115a6:	sub    rsp,0xd8
  4115ad:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  4115b3:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  4115b9:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  4115bf:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  4115c5:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  4115cb:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  4115d4:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  4115dd:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  4115e6:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  4115ef:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  4115f8:	xor    eax,eax
  4115fa:	call   4070f0 <getpid@plt>
  4115ff:	mov    rsi,rax
  411602:	lea    rdi,[rip+0x1573f]        # 426d48 <__swc_bss_base_6b1cf01f+0x2d08>
  411609:	mov    r12,QWORD PTR [rdi]
  41160c:	test   r12,r12
  41160f:	je     41161d <__swc_fn_6b1cf01f_000110_126150d1+0x7d>
  411611:	cmp    DWORD PTR [r12+0x10],esi
  411616:	jne    41161d <__swc_fn_6b1cf01f_000110_126150d1+0x7d>
  411618:	mov    rax,r12
  41161b:	jmp    411680 <__swc_fn_6b1cf01f_000110_126150d1+0xe0>
  41161d:	mov    ecx,0x4
  411622:	mov    edx,0x18
  411627:	call   40d0f0 <__swc_fn_6b1cf01f_000109_6814119b>
  41162c:	mov    rcx,rax
  41162f:	test   rax,rax
  411632:	jne    411638 <__swc_fn_6b1cf01f_000110_126150d1+0x98>
  411634:	xor    eax,eax
  411636:	jmp    411680 <__swc_fn_6b1cf01f_000110_126150d1+0xe0>
  411638:	mov    DWORD PTR [rcx+0x10],esi
  41163b:	mov    rax,r12
  41163e:	lock cmpxchg QWORD PTR [rdi],rcx
  411643:	mov    r13,rax
  411646:	cmp    rax,r12
  411649:	je     41165f <__swc_fn_6b1cf01f_000110_126150d1+0xbf>
  41164b:	mov    rdi,rcx
  41164e:	mov    esi,0x18
  411653:	xor    eax,eax
  411655:	call   407040 <munmap@plt>
  41165a:	mov    rax,r13
  41165d:	jmp    411680 <__swc_fn_6b1cf01f_000110_126150d1+0xe0>
  41165f:	test   r12,r12
  411662:	je     41167d <__swc_fn_6b1cf01f_000110_126150d1+0xdd>
  411664:	mov    rdi,r12
  411667:	mov    esi,0x18
  41166c:	xor    eax,eax
  41166e:	mov    QWORD PTR [rsp+0x28],rcx
  411673:	call   407040 <munmap@plt>
  411678:	mov    rcx,QWORD PTR [rsp+0x28]
  41167d:	mov    rax,rcx
  411680:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  411686:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  41168c:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  411692:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  411698:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  41169e:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  4116a7:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  4116b0:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  4116b9:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  4116c2:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  4116cb:	add    rsp,0xd8
  4116d2:	pop    r13
  4116d4:	pop    r12
  4116d6:	pop    rdi
  4116d7:	pop    rsi
  4116d8:	ret
  4116d9:	add    BYTE PTR [rax],al
  4116db:	add    BYTE PTR [rax],al
  4116dd:	add    BYTE PTR [rax],al
	...

00000000004116e0 <__swc_fn_6b1cf01f_000113_36905703>:
  4116e0:	push   rbx
  4116e1:	push   r12
  4116e3:	push   rdi
  4116e4:	push   rsi
  4116e5:	sub    rsp,0xa8
  4116ec:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4116f2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4116f8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4116fe:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411704:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  41170a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  411710:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411716:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  41171c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411725:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41172e:	mov    rbx,rdx
  411731:	mov    r12,rcx
  411734:	mov    rdi,rcx
  411737:	mov    rsi,rdx
  41173a:	mov    edx,0x3
  41173f:	xor    eax,eax
  411741:	call   407030 <mprotect@plt>
  411746:	test   eax,eax
  411748:	je     41174e <__swc_fn_6b1cf01f_000113_36905703+0x6e>
  41174a:	xor    eax,eax
  41174c:	jmp    411763 <__swc_fn_6b1cf01f_000113_36905703+0x83>
  41174e:	mov    rcx,r12
  411751:	mov    rdx,rbx
  411754:	mov    al,0x1
  411756:	mov    r8,rax
  411759:	call   40d720 <__swc_fn_6b1cf01f_000112_5f48311c>
  41175e:	mov    eax,0x1
  411763:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  411769:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  41176f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411775:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41177b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411781:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411787:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41178d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411793:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41179c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4117a5:	add    rsp,0xa8
  4117ac:	pop    rsi
  4117ad:	pop    rdi
  4117ae:	pop    r12
  4117b0:	pop    rbx
  4117b1:	ret
	...

00000000004117c0 <__swc_fn_6b1cf01f_000116_5208f471>:
  4117c0:	sub    rsp,0x8
  4117c4:	test   rcx,rcx
  4117c7:	jne    4117ce <__swc_fn_6b1cf01f_000116_5208f471+0xe>
  4117c9:	add    rsp,0x8
  4117cd:	ret
  4117ce:	call   4097a0 <__swc_fn_6b1cf01f_000117_d3318640>
  4117d3:	add    rsp,0x8
  4117d7:	ret
	...

00000000004117e0 <__swc_fn_6b1cf01f_000119_0a5fa85a>:
  4117e0:	push   rdi
  4117e1:	push   rsi
  4117e2:	sub    rsp,0xa8
  4117e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4117ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4117f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4117fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411801:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411807:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41180d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411813:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411819:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411822:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41182b:	xor    edi,edi
  41182d:	xor    eax,eax
  41182f:	call   407060 <exit@plt>
  411834:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41183a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411840:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411846:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41184c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411852:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411858:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41185e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411864:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41186d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411876:	add    rsp,0xa8
  41187d:	pop    rsi
  41187e:	pop    rdi
  41187f:	ret

0000000000411880 <__swc_fn_6b1cf01f_000122_83db7238>:
  411880:	push   rbx
  411881:	push   rsi
  411882:	push   rdi
  411883:	push   r12
  411885:	sub    rsp,0x18
  411889:	mov    rbx,r8
  41188c:	mov    rsi,rcx
  41188f:	mov    rdi,rdx
  411892:	mov    rcx,QWORD PTR [rip+0x154a7]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  411899:	test   rcx,rcx
  41189c:	jne    4118ae <__swc_fn_6b1cf01f_000122_83db7238+0x2e>
  41189e:	call   412640 <__swc_fn_6b1cf01f_000167_994c8876>
  4118a3:	lea    rcx,[rax+0x1]
  4118a7:	mov    QWORD PTR [rip+0x15492],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  4118ae:	dec    rcx
  4118b1:	call   40f580 <__swc_fn_6b1cf01f_000169_360af05d>
  4118b6:	mov    r12,rax
  4118b9:	cmp    ebx,0x3
  4118bc:	jne    4118cf <__swc_fn_6b1cf01f_000122_83db7238+0x4f>
  4118be:	mov    rax,QWORD PTR [r12+0xbd0]
  4118c6:	test   rax,rax
  4118c9:	jne    411a0c <__swc_fn_6b1cf01f_000122_83db7238+0x18c>
  4118cf:	cmp    ebx,0x5
  4118d2:	jne    4118f6 <__swc_fn_6b1cf01f_000122_83db7238+0x76>
  4118d4:	call   409070 <__swc_fn_6b1cf01f_000093_ad13d15c>
  4118d9:	test   al,al
  4118db:	jne    4118f6 <__swc_fn_6b1cf01f_000122_83db7238+0x76>
  4118dd:	mov    rcx,rsi
  4118e0:	mov    rdx,rdi
  4118e3:	call   40f530 <__swc_fn_6b1cf01f_000166_3459066f>
  4118e8:	test   al,al
  4118ea:	je     4118f6 <__swc_fn_6b1cf01f_000122_83db7238+0x76>
  4118ec:	add    rsp,0x18
  4118f0:	pop    r12
  4118f2:	pop    rdi
  4118f3:	pop    rsi
  4118f4:	pop    rbx
  4118f5:	ret
  4118f6:	call   409070 <__swc_fn_6b1cf01f_000093_ad13d15c>
  4118fb:	test   al,al
  4118fd:	jne    41196f <__swc_fn_6b1cf01f_000122_83db7238+0xef>
  4118ff:	vmovups xmm0,XMMWORD PTR [rsi]
  411903:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  411909:	mov    rax,QWORD PTR [rsp+0x8]
  41190e:	test   rax,rax
  411911:	jne    411962 <__swc_fn_6b1cf01f_000122_83db7238+0xe2>
  411913:	cmp    ebx,0x3
  411916:	je     411924 <__swc_fn_6b1cf01f_000122_83db7238+0xa4>
  411918:	cmp    ebx,0x4
  41191b:	je     411934 <__swc_fn_6b1cf01f_000122_83db7238+0xb4>
  41191d:	cmp    ebx,0x5
  411920:	je     411944 <__swc_fn_6b1cf01f_000122_83db7238+0xc4>
  411922:	jmp    411954 <__swc_fn_6b1cf01f_000122_83db7238+0xd4>
  411924:	vmovups xmm0,XMMWORD PTR [rip+0x1ddc]        # 413708 <__swc_rdata_base_6b1cf01f+0x5f8>
  41192c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  411932:	jmp    411962 <__swc_fn_6b1cf01f_000122_83db7238+0xe2>
  411934:	vmovups xmm0,XMMWORD PTR [rip+0x1ddc]        # 413718 <__swc_rdata_base_6b1cf01f+0x608>
  41193c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  411942:	jmp    411962 <__swc_fn_6b1cf01f_000122_83db7238+0xe2>
  411944:	vmovups xmm0,XMMWORD PTR [rip+0x1ddc]        # 413728 <__swc_rdata_base_6b1cf01f+0x618>
  41194c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  411952:	jmp    411962 <__swc_fn_6b1cf01f_000122_83db7238+0xe2>
  411954:	vmovups xmm0,XMMWORD PTR [rip+0x1ddc]        # 413738 <__swc_rdata_base_6b1cf01f+0x628>
  41195c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  411962:	lea    rcx,[rsp+0x8]
  411967:	mov    rdx,rdi
  41196a:	call   4092c0 <__swc_fn_6b1cf01f_000105_90faaa26>
  41196f:	vmovups xmm0,XMMWORD PTR [rdi]
  411973:	vmovups XMMWORD PTR [r12+0x940],xmm0
  41197d:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  411982:	vmovups XMMWORD PTR [r12+0x950],xmm0
  41198c:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  411991:	vmovups XMMWORD PTR [r12+0x960],xmm0
  41199b:	lea    rax,[r12+0x940]
  4119a3:	mov    QWORD PTR [r12+0x970],rax
  4119ab:	mov    rax,QWORD PTR [rsi]
  4119ae:	mov    QWORD PTR [r12+0x978],rax
  4119b6:	mov    rax,QWORD PTR [rsi+0x8]
  4119ba:	mov    QWORD PTR [r12+0x980],rax
  4119c2:	movsxd rax,ebx
  4119c5:	mov    QWORD PTR [r12+0x988],rax
  4119cd:	cmp    ebx,0x5
  4119d0:	je     4119d9 <__swc_fn_6b1cf01f_000122_83db7238+0x159>
  4119d2:	xor    ecx,ecx
  4119d4:	call   412770 <__swc_fn_6b1cf01f_000176_718d7b54>
  4119d9:	mov    rbx,QWORD PTR [r12+0xbe8]
  4119e1:	test   rbx,rbx
  4119e4:	je     4119f5 <__swc_fn_6b1cf01f_000122_83db7238+0x175>
  4119e6:	mov    rcx,r12
  4119e9:	call   rbx
  4119eb:	add    rsp,0x18
  4119ef:	pop    r12
  4119f1:	pop    rdi
  4119f2:	pop    rsi
  4119f3:	pop    rbx
  4119f4:	ret
  4119f5:	mov    rcx,rsi
  4119f8:	call   40d7d0 <__swc_fn_6b1cf01f_000118_2648f149>
  4119fd:	call   4098f0 <__swc_fn_6b1cf01f_000120_be2e2f68>
  411a02:	add    rsp,0x18
  411a06:	pop    r12
  411a08:	pop    rdi
  411a09:	pop    rsi
  411a0a:	pop    rbx
  411a0b:	ret
  411a0c:	mov    rcx,rsi
  411a0f:	mov    rdx,rdi
  411a12:	call   4092c0 <__swc_fn_6b1cf01f_000105_90faaa26>
  411a17:	jmp    4118cf <__swc_fn_6b1cf01f_000122_83db7238+0x4f>
  411a1c:	add    BYTE PTR [rax],al
	...

0000000000411a20 <__swc_fn_6b1cf01f_000125_58f0f391>:
  411a20:	push   rdi
  411a21:	push   rsi
  411a22:	sub    rsp,0xb8
  411a29:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  411a2f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  411a35:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  411a3b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  411a41:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  411a47:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  411a4d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  411a53:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  411a5c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  411a65:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  411a6e:	mov    DWORD PTR [rsp+0x8],0x0
  411a76:	lea    rdi,[rsp+0x8]
  411a7b:	xor    esi,esi
  411a7d:	xor    eax,eax
  411a7f:	call   4071e0 <pthread_key_create@plt>
  411a84:	test   eax,eax
  411a86:	jne    411a8e <__swc_fn_6b1cf01f_000125_58f0f391+0x6e>
  411a88:	mov    eax,DWORD PTR [rsp+0x8]
  411a8c:	jmp    411a95 <__swc_fn_6b1cf01f_000125_58f0f391+0x75>
  411a8e:	mov    rax,0xffffffffffffffff
  411a95:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  411a9b:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  411aa1:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  411aa7:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  411aad:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  411ab3:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  411ab9:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  411abf:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  411ac8:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  411ad1:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  411ada:	add    rsp,0xb8
  411ae1:	pop    rsi
  411ae2:	pop    rdi
  411ae3:	ret
	...

0000000000411af0 <__swc_fn_6b1cf01f_000128_4a82cdf6>:
  411af0:	push   rdi
  411af1:	push   rsi
  411af2:	sub    rsp,0xb8
  411af9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  411aff:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  411b05:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  411b0b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  411b11:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  411b17:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  411b1d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  411b23:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  411b2c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  411b35:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  411b3e:	mov    DWORD PTR [rsp+0x8],0x0
  411b46:	lea    rdi,[rsp+0x8]
  411b4b:	mov    rsi,rcx
  411b4e:	xor    eax,eax
  411b50:	call   4071e0 <pthread_key_create@plt>
  411b55:	test   eax,eax
  411b57:	jne    411b62 <__swc_fn_6b1cf01f_000128_4a82cdf6+0x72>
  411b59:	mov    eax,DWORD PTR [rsp+0x8]
  411b5d:	inc    rax
  411b60:	jmp    411b64 <__swc_fn_6b1cf01f_000128_4a82cdf6+0x74>
  411b62:	xor    eax,eax
  411b64:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  411b6a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  411b70:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  411b76:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  411b7c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  411b82:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  411b88:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  411b8e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  411b97:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  411ba0:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  411ba9:	add    rsp,0xb8
  411bb0:	pop    rsi
  411bb1:	pop    rdi
  411bb2:	ret
	...

0000000000411bc0 <__swc_fn_6b1cf01f_000131_ae5891af>:
  411bc0:	push   rdi
  411bc1:	push   rsi
  411bc2:	sub    rsp,0xa8
  411bc9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  411bcf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411bd5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  411bdb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411be1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411be7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  411bed:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411bf3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411bf9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411c02:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  411c0b:	test   rcx,rcx
  411c0e:	setne  al
  411c11:	je     411c2a <__swc_fn_6b1cf01f_000131_ae5891af+0x6a>
  411c13:	lea    rax,[rcx-0x1]
  411c17:	mov    eax,eax
  411c19:	mov    edi,eax
  411c1b:	mov    rsi,rdx
  411c1e:	xor    eax,eax
  411c20:	call   4071b0 <pthread_setspecific@plt>
  411c25:	test   eax,eax
  411c27:	sete   al
  411c2a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  411c30:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411c36:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411c3c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411c42:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411c48:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411c4e:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411c54:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411c5a:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411c63:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411c6c:	add    rsp,0xa8
  411c73:	pop    rsi
  411c74:	pop    rdi
  411c75:	ret
	...

0000000000411c80 <__swc_fn_6b1cf01f_000134_865f5106>:
  411c80:	push   rdi
  411c81:	push   rsi
  411c82:	sub    rsp,0xa8
  411c89:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  411c8f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411c95:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  411c9b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411ca1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411ca7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  411cad:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411cb3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411cb9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411cc2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  411ccb:	mov    rax,rdx
  411cce:	mov    QWORD PTR [rsp],0x0
  411cd6:	mov    edi,0xca
  411cdb:	mov    rsi,rcx
  411cde:	mov    edx,0x81
  411ce3:	mov    eax,eax
  411ce5:	mov    ecx,eax
  411ce7:	xor    r8d,r8d
  411cea:	xor    r9d,r9d
  411ced:	xor    eax,eax
  411cef:	call   407090 <syscall@plt>
  411cf4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  411cfa:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411d00:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411d06:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411d0c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411d12:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411d18:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411d1e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411d24:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411d2d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411d36:	add    rsp,0xa8
  411d3d:	pop    rsi
  411d3e:	pop    rdi
  411d3f:	ret

0000000000411d40 <__swc_fn_6b1cf01f_000137_86bb0f90>:
  411d40:	sub    rsp,0x8
  411d44:	call   409c90 <__swc_fn_6b1cf01f_000135_8c07c14b>
  411d49:	add    rsp,0x8
  411d4d:	ret
	...

0000000000411d50 <__swc_fn_6b1cf01f_000140_be4c2719>:
  411d50:	push   rdi
  411d51:	push   rsi
  411d52:	sub    rsp,0xc8
  411d59:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  411d5f:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  411d65:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  411d6b:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  411d71:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  411d77:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  411d7d:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  411d86:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  411d8f:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  411d98:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  411da1:	vxorps xmm0,xmm0,xmm0
  411da5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  411dab:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  411db1:	mov    rdi,rcx
  411db4:	lea    rsi,[rsp+0x8]
  411db9:	xor    eax,eax
  411dbb:	call   4071f0 <dladdr@plt>
  411dc0:	xor    ecx,ecx
  411dc2:	test   eax,eax
  411dc4:	je     411dcb <__swc_fn_6b1cf01f_000140_be4c2719+0x7b>
  411dc6:	mov    rcx,QWORD PTR [rsp+0x10]
  411dcb:	mov    rax,rcx
  411dce:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  411dd4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  411dda:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  411de0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  411de6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  411dec:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  411df2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  411dfb:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  411e04:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  411e0d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  411e16:	add    rsp,0xc8
  411e1d:	pop    rsi
  411e1e:	pop    rdi
  411e1f:	ret

0000000000411e20 <__swc_fn_6b1cf01f_000143_1534de9a>:
  411e20:	push   rbx
  411e21:	push   r12
  411e23:	push   r13
  411e25:	push   rdi
  411e26:	push   rsi
  411e27:	push   r14
  411e29:	push   r15
  411e2b:	sub    rsp,0x150
  411e32:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  411e3b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  411e44:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  411e4d:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  411e56:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  411e5f:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  411e68:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  411e71:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  411e7a:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  411e83:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  411e8c:	mov    rbx,rdx
  411e8f:	mov    QWORD PTR [rsp+0x98],rdx
  411e97:	mov    r12,rcx
  411e9a:	mov    QWORD PTR [rsp+0xa0],rcx
  411ea2:	mov    QWORD PTR [rbx],0x0
  411ea9:	lea    r13,[rip+0x14ed0]        # 426d80 <__swc_bss_base_6b1cf01f+0x2d40>
  411eb0:	mov    rcx,r13
  411eb3:	call   411d40 <__swc_fn_6b1cf01f_000137_86bb0f90>
  411eb8:	mov    rax,QWORD PTR [rip+0x14ec9]        # 426d88 <__swc_bss_base_6b1cf01f+0x2d48>
  411ebf:	test   rax,rax
  411ec2:	je     411ef9 <__swc_fn_6b1cf01f_000143_1534de9a+0xd9>
  411ec4:	cs nop WORD PTR [rax+rax*1+0x0]
  411ece:	xchg   ax,ax
  411ed0:	cmp    QWORD PTR [rax+0x8],r12
  411ed4:	jne    411ef1 <__swc_fn_6b1cf01f_000143_1534de9a+0xd1>
  411ed6:	mov    rcx,QWORD PTR [rax+0x18]
  411eda:	mov    QWORD PTR [rbx],rcx
  411edd:	mov    rbx,QWORD PTR [rax+0x10]
  411ee1:	mov    rcx,r13
  411ee4:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  411ee9:	mov    rax,rbx
  411eec:	jmp    4120db <__swc_fn_6b1cf01f_000143_1534de9a+0x2bb>
  411ef1:	mov    rax,QWORD PTR [rax]
  411ef4:	test   rax,rax
  411ef7:	jne    411ed0 <__swc_fn_6b1cf01f_000143_1534de9a+0xb0>
  411ef9:	vxorps xmm0,xmm0,xmm0
  411efd:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  411f03:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  411f09:	mov    rdi,r12
  411f0c:	lea    rsi,[rsp+0x10]
  411f11:	xor    eax,eax
  411f13:	call   4071f0 <dladdr@plt>
  411f18:	test   eax,eax
  411f1a:	sete   al
  411f1d:	je     411f2a <__swc_fn_6b1cf01f_000143_1534de9a+0x10a>
  411f1f:	mov    rax,QWORD PTR [rsp+0x10]
  411f24:	test   rax,rax
  411f27:	sete   al
  411f2a:	test   al,al
  411f2c:	je     411f3d <__swc_fn_6b1cf01f_000143_1534de9a+0x11d>
  411f2e:	mov    rcx,r13
  411f31:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  411f36:	xor    eax,eax
  411f38:	jmp    4120db <__swc_fn_6b1cf01f_000143_1534de9a+0x2bb>
  411f3d:	mov    rdi,QWORD PTR [rsp+0x10]
  411f42:	mov    esi,0x80000
  411f47:	xor    eax,eax
  411f49:	call   4070b0 <open@plt>
  411f4e:	lea    r14,[rsp+0x30]
  411f53:	mov    DWORD PTR [rsp+0x30],eax
  411f57:	cmp    DWORD PTR [r14],0x0
  411f5b:	jge    411f6c <__swc_fn_6b1cf01f_000143_1534de9a+0x14c>
  411f5d:	mov    rcx,r13
  411f60:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  411f65:	xor    eax,eax
  411f67:	jmp    4120db <__swc_fn_6b1cf01f_000143_1534de9a+0x2bb>
  411f6c:	mov    rax,r14
  411f6f:	movsxd rdi,DWORD PTR [rax]
  411f72:	xor    esi,esi
  411f74:	mov    edx,0x2
  411f79:	xor    eax,eax
  411f7b:	call   407160 <lseek@plt>
  411f80:	mov    r15,rax
  411f83:	test   rax,rax
  411f86:	jg     411fa1 <__swc_fn_6b1cf01f_000143_1534de9a+0x181>
  411f88:	movsxd rdi,DWORD PTR [r14]
  411f8b:	xor    eax,eax
  411f8d:	call   4070e0 <close@plt>
  411f92:	mov    rcx,r13
  411f95:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  411f9a:	xor    eax,eax
  411f9c:	jmp    4120db <__swc_fn_6b1cf01f_000143_1534de9a+0x2bb>
  411fa1:	xor    edi,edi
  411fa3:	mov    rsi,r15
  411fa6:	mov    edx,0x1
  411fab:	mov    ecx,0x2
  411fb0:	mov    rax,r14
  411fb3:	movsxd r8,DWORD PTR [rax]
  411fb6:	xor    r9d,r9d
  411fb9:	xor    eax,eax
  411fbb:	call   407020 <mmap@plt>
  411fc0:	mov    rbx,rax
  411fc3:	test   rax,rax
  411fc6:	sete   al
  411fc9:	cmp    rbx,0xffffffffffffffff
  411fcd:	sete   cl
  411fd0:	or     al,cl
  411fd2:	je     411fed <__swc_fn_6b1cf01f_000143_1534de9a+0x1cd>
  411fd4:	movsxd rdi,DWORD PTR [r14]
  411fd7:	xor    eax,eax
  411fd9:	call   4070e0 <close@plt>
  411fde:	mov    rcx,r13
  411fe1:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  411fe6:	xor    eax,eax
  411fe8:	jmp    4120db <__swc_fn_6b1cf01f_000143_1534de9a+0x2bb>
  411fed:	lea    rax,[rsp+0x50]
  411ff2:	mov    QWORD PTR [rax],0x0
  411ff9:	mov    rcx,rbx
  411ffc:	mov    rdx,r15
  411fff:	mov    r8,rax
  412002:	call   40dd60 <__swc_fn_6b1cf01f_000142_d5d4d43f>
  412007:	mov    r12,rax
  41200a:	test   rax,rax
  41200d:	jne    412035 <__swc_fn_6b1cf01f_000143_1534de9a+0x215>
  41200f:	mov    rdi,rbx
  412012:	mov    rsi,r15
  412015:	xor    eax,eax
  412017:	call   407040 <munmap@plt>
  41201c:	movsxd rdi,DWORD PTR [r14]
  41201f:	xor    eax,eax
  412021:	call   4070e0 <close@plt>
  412026:	mov    rcx,r13
  412029:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  41202e:	xor    eax,eax
  412030:	jmp    4120db <__swc_fn_6b1cf01f_000143_1534de9a+0x2bb>
  412035:	mov    edi,0x20
  41203a:	xor    eax,eax
  41203c:	call   4070a0 <malloc@plt>
  412041:	test   rax,rax
  412044:	jne    412069 <__swc_fn_6b1cf01f_000143_1534de9a+0x249>
  412046:	mov    rdi,rbx
  412049:	mov    rsi,r15
  41204c:	xor    eax,eax
  41204e:	call   407040 <munmap@plt>
  412053:	movsxd rdi,DWORD PTR [r14]
  412056:	xor    eax,eax
  412058:	call   4070e0 <close@plt>
  41205d:	mov    rcx,r13
  412060:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  412065:	xor    eax,eax
  412067:	jmp    4120db <__swc_fn_6b1cf01f_000143_1534de9a+0x2bb>
  412069:	mov    rcx,QWORD PTR [rip+0x14d18]        # 426d88 <__swc_bss_base_6b1cf01f+0x2d48>
  412070:	mov    QWORD PTR [rsp+0x70],rcx
  412075:	mov    rcx,QWORD PTR [rsp+0xa0]
  41207d:	mov    QWORD PTR [rsp+0x78],rcx
  412082:	mov    QWORD PTR [rsp+0x80],r12
  41208a:	mov    rcx,QWORD PTR [rsp+0x50]
  41208f:	mov    QWORD PTR [rsp+0x88],rcx
  412097:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  41209d:	vmovups XMMWORD PTR [rax],xmm0
  4120a1:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  4120aa:	vmovups XMMWORD PTR [rax+0x10],xmm0
  4120af:	mov    QWORD PTR [rip+0x14cd2],rax        # 426d88 <__swc_bss_base_6b1cf01f+0x2d48>
  4120b6:	mov    rax,QWORD PTR [rsp+0x50]
  4120bb:	mov    rbx,QWORD PTR [rsp+0x98]
  4120c3:	mov    QWORD PTR [rbx],rax
  4120c6:	movsxd rdi,DWORD PTR [r14]
  4120c9:	xor    eax,eax
  4120cb:	call   4070e0 <close@plt>
  4120d0:	mov    rcx,r13
  4120d3:	call   409d90 <__swc_fn_6b1cf01f_000138_055b38a4>
  4120d8:	mov    rax,r12
  4120db:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  4120e4:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  4120ed:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  4120f6:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  4120ff:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  412108:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  412111:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  41211a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  412123:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  41212c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  412135:	add    rsp,0x150
  41213c:	pop    r15
  41213e:	pop    r14
  412140:	pop    rsi
  412141:	pop    rdi
  412142:	pop    r13
  412144:	pop    r12
  412146:	pop    rbx
  412147:	ret
	...

0000000000412150 <__swc_fn_6b1cf01f_000146_43c96957>:
  412150:	push   rbx
  412151:	sub    rsp,0xe0
  412158:	lea    rbx,[rsp+0x8]
  41215d:	vxorps xmm0,xmm0,xmm0
  412161:	vmovups YMMWORD PTR [rbx],ymm0
  412165:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  41216a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  41216f:	vzeroupper
  412172:	mov    DWORD PTR [rbx+0x60],0x0
  412179:	mov    r8,rbx
  41217c:	nop    DWORD PTR [rax+0x0]
  412180:	mov    r9,rcx
  412183:	movabs rcx,0xcccccccccccccccd
  41218d:	mov    rax,r9
  412190:	mul    rcx
  412193:	mov    r10,rdx
  412196:	shr    r10,0x3
  41219a:	mov    rcx,r10
  41219d:	imul   rdx,r10,0xa
  4121a1:	sub    r9,rdx
  4121a4:	mov    rdx,QWORD PTR [rip+0x15bd]        # 413768 <__swc_rdata_base_6b1cf01f+0x658>
  4121ab:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  4121b0:	mov    BYTE PTR [r8],dl
  4121b3:	lea    rdx,[r8+0x1]
  4121b7:	mov    r8,rdx
  4121ba:	test   r10,r10
  4121bd:	jne    412180 <__swc_fn_6b1cf01f_000146_43c96957+0x30>
  4121bf:	mov    BYTE PTR [rdx],0x0
  4121c2:	sub    r8,0x1
  4121c6:	mov    rax,rbx
  4121c9:	cmp    rax,r8
  4121cc:	jae    4121e6 <__swc_fn_6b1cf01f_000146_43c96957+0x96>
  4121ce:	xchg   ax,ax
  4121d0:	mov    cl,BYTE PTR [r8]
  4121d3:	mov    dl,BYTE PTR [rax]
  4121d5:	mov    BYTE PTR [r8],dl
  4121d8:	sub    r8,0x1
  4121dc:	mov    BYTE PTR [rax],cl
  4121de:	inc    rax
  4121e1:	cmp    rax,r8
  4121e4:	jb     4121d0 <__swc_fn_6b1cf01f_000146_43c96957+0x80>
  4121e6:	xor    eax,eax
  4121e8:	test   rbx,rbx
  4121eb:	je     41220e <__swc_fn_6b1cf01f_000146_43c96957+0xbe>
  4121ed:	mov    rcx,rbx
  4121f0:	mov    dl,BYTE PTR [rcx]
  4121f2:	test   dl,dl
  4121f4:	je     41220e <__swc_fn_6b1cf01f_000146_43c96957+0xbe>
  4121f6:	cs nop WORD PTR [rax+rax*1+0x0]
  412200:	add    rcx,0x1
  412204:	add    rax,0x1
  412208:	mov    dl,BYTE PTR [rcx]
  41220a:	test   dl,dl
  41220c:	jne    412200 <__swc_fn_6b1cf01f_000146_43c96957+0xb0>
  41220e:	mov    QWORD PTR [rbx+0xa8],rbx
  412215:	mov    QWORD PTR [rbx+0xb0],rax
  41221c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  412224:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  41222c:	lea    rcx,[rbx+0xb8]
  412233:	call   40d7d0 <__swc_fn_6b1cf01f_000118_2648f149>
  412238:	add    rsp,0xe0
  41223f:	pop    rbx
  412240:	ret
	...

0000000000412250 <__swc_fn_6b1cf01f_000149_6fb05988>:
  412250:	sub    rsp,0x8
  412254:	mov    rax,QWORD PTR [rcx+0x8]
  412258:	mov    r8,QWORD PTR [rdx+0x8]
  41225c:	cmp    rax,r8
  41225f:	je     412268 <__swc_fn_6b1cf01f_000149_6fb05988+0x18>
  412261:	xor    eax,eax
  412263:	add    rsp,0x8
  412267:	ret
  412268:	test   rax,rax
  41226b:	jne    41227c <__swc_fn_6b1cf01f_000149_6fb05988+0x2c>
  41226d:	test   r8,r8
  412270:	jne    41227c <__swc_fn_6b1cf01f_000149_6fb05988+0x2c>
  412272:	mov    eax,0x1
  412277:	add    rsp,0x8
  41227b:	ret
  41227c:	mov    rcx,QWORD PTR [rcx]
  41227f:	mov    rdx,QWORD PTR [rdx]
  412282:	test   rcx,rcx
  412285:	sete   r8b
  412289:	test   rdx,rdx
  41228c:	sete   r9b
  412290:	or     r8b,r9b
  412293:	je     4122a0 <__swc_fn_6b1cf01f_000149_6fb05988+0x50>
  412295:	cmp    rcx,rdx
  412298:	sete   al
  41229b:	add    rsp,0x8
  41229f:	ret
  4122a0:	cmp    rcx,rdx
  4122a3:	jne    4122af <__swc_fn_6b1cf01f_000149_6fb05988+0x5f>
  4122a5:	mov    eax,0x1
  4122aa:	add    rsp,0x8
  4122ae:	ret
  4122af:	mov    r8,rax
  4122b2:	call   409380 <__swc_fn_6b1cf01f_000108_3dc01326>
  4122b7:	test   eax,eax
  4122b9:	sete   al
  4122bc:	add    rsp,0x8
  4122c0:	ret
	...

00000000004122d0 <__swc_fn_6b1cf01f_000152_86f1d437>:
  4122d0:	vxorps xmm0,xmm0,xmm0
  4122d4:	vmovups XMMWORD PTR [rcx],xmm0
  4122d8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4122dd:	vxorps xmm0,xmm0,xmm0
  4122e1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4122e6:	vmovups xmm0,XMMWORD PTR [rip+0x1512]        # 413800 <__swc_rdata_base_6b1cf01f+0x6f0>
  4122ee:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4122f3:	ret
	...

0000000000412300 <__swc_fn_6b1cf01f_000155_86f1d437>:
  412300:	vxorps xmm0,xmm0,xmm0
  412304:	vmovups XMMWORD PTR [rcx],xmm0
  412308:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41230d:	vxorps xmm0,xmm0,xmm0
  412311:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  412316:	vmovups xmm0,XMMWORD PTR [rip+0x1602]        # 413920 <__swc_rdata_base_6b1cf01f+0x810>
  41231e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  412323:	mov    QWORD PTR [rcx+0x40],0x0
  41232b:	ret
  41232c:	add    BYTE PTR [rax],al
	...

0000000000412330 <__swc_fn_6b1cf01f_000158_47b270e1>:
  412330:	push   rbx
  412331:	sub    rsp,0x70
  412335:	mov    rax,QWORD PTR [rcx]
  412338:	mov    rbx,QWORD PTR [rcx+0x8]
  41233c:	vxorps xmm0,xmm0,xmm0
  412340:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  412346:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  41234c:	vzeroupper
  41234f:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  412355:	mov    QWORD PTR [rsp+0x48],rdx
  41235a:	mov    QWORD PTR [rsp+0x50],r8
  41235f:	mov    rcx,rax
  412362:	lea    rdx,[rsp+0x8]
  412367:	mov    rbx,QWORD PTR [rbx+0x18]
  41236b:	call   rbx
  41236d:	add    rsp,0x70
  412371:	pop    rbx
  412372:	ret
	...

0000000000412380 <__swc_fn_6b1cf01f_000161_8a3d304f>:
  412380:	push   rbx
  412381:	push   rsi
  412382:	push   rdi
  412383:	mov    rbx,r8
  412386:	mov    rsi,rcx
  412389:	mov    rdi,rdx
  41238c:	call   40a090 <__swc_fn_6b1cf01f_000159_13ead2ff>
  412391:	vmovups xmm0,XMMWORD PTR [rbx]
  412395:	vmovups XMMWORD PTR [rsi],xmm0
  412399:	mov    QWORD PTR [rsi+0x18],rdi
  41239d:	pop    rdi
  41239e:	pop    rsi
  41239f:	pop    rbx
  4123a0:	ret
	...

00000000004123b0 <__swc_fn_6b1cf01f_000164_cc119975>:
  4123b0:	push   rbx
  4123b1:	push   rsi
  4123b2:	push   rdi
  4123b3:	push   r12
  4123b5:	push   r13
  4123b7:	sub    rsp,0x50
  4123bb:	mov    rbx,rcx
  4123be:	mov    rsi,rdx
  4123c1:	vmovups xmm0,XMMWORD PTR [rip+0x1667]        # 413a30 <__swc_rdata_base_6b1cf01f+0x920>
  4123c9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4123cf:	vmovups xmm0,XMMWORD PTR [rip+0x1669]        # 413a40 <__swc_rdata_base_6b1cf01f+0x930>
  4123d7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4123dd:	vxorps xmm0,xmm0,xmm0
  4123e1:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  4123e7:	mov    rcx,rdx
  4123ea:	call   411d50 <__swc_fn_6b1cf01f_000140_be4c2719>
  4123ef:	mov    rdi,rax
  4123f2:	test   rax,rax
  4123f5:	jne    412426 <__swc_fn_6b1cf01f_000164_cc119975+0x76>
  4123f7:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4123fd:	vmovups XMMWORD PTR [rbx],xmm0
  412401:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  412407:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  41240c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  412412:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  412417:	mov    rax,rbx
  41241a:	add    rsp,0x50
  41241e:	pop    r13
  412420:	pop    r12
  412422:	pop    rdi
  412423:	pop    rsi
  412424:	pop    rbx
  412425:	ret
  412426:	mov    rcx,rdi
  412429:	call   40f280 <__swc_fn_6b1cf01f_000163_016ee66a>
  41242e:	mov    r11,rax
  412431:	test   rax,rax
  412434:	je     41243e <__swc_fn_6b1cf01f_000164_cc119975+0x8e>
  412436:	mov    al,BYTE PTR [r11+0x24]
  41243a:	test   al,al
  41243c:	jne    41246d <__swc_fn_6b1cf01f_000164_cc119975+0xbd>
  41243e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  412444:	vmovups XMMWORD PTR [rbx],xmm0
  412448:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  41244e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  412453:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  412459:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  41245e:	mov    rax,rbx
  412461:	add    rsp,0x50
  412465:	pop    r13
  412467:	pop    r12
  412469:	pop    rdi
  41246a:	pop    rsi
  41246b:	pop    rbx
  41246c:	ret
  41246d:	sub    rsi,rdi
  412470:	mov    eax,0xffffffff
  412475:	cmp    rsi,rax
  412478:	jbe    4124a9 <__swc_fn_6b1cf01f_000164_cc119975+0xf9>
  41247a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  412480:	vmovups XMMWORD PTR [rbx],xmm0
  412484:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  41248a:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  41248f:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  412495:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  41249a:	mov    rax,rbx
  41249d:	add    rsp,0x50
  4124a1:	pop    r13
  4124a3:	pop    r12
  4124a5:	pop    rdi
  4124a6:	pop    rsi
  4124a7:	pop    rbx
  4124a8:	ret
  4124a9:	mov    rdi,QWORD PTR [r11+0x10]
  4124ad:	mov    eax,DWORD PTR [r11+0x20]
  4124b1:	xor    ecx,ecx
  4124b3:	test   rax,rax
  4124b6:	jbe    412608 <__swc_fn_6b1cf01f_000164_cc119975+0x258>
  4124bc:	nop    DWORD PTR [rax+0x0]
  4124c0:	mov    edx,ecx
  4124c2:	imul   r12,rdx,0x14
  4124c6:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  4124cb:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  4124d0:	mov    r9d,esi
  4124d3:	cmp    r9,rdx
  4124d6:	jb     4125fb <__swc_fn_6b1cf01f_000164_cc119975+0x24b>
  4124dc:	add    rdx,r8
  4124df:	mov    r8d,esi
  4124e2:	cmp    r8,rdx
  4124e5:	jae    4125fb <__swc_fn_6b1cf01f_000164_cc119975+0x24b>
  4124eb:	lea    rsi,[rsp+0x38]
  4124f0:	mov    eax,DWORD PTR [rdi+0xc]
  4124f3:	mov    DWORD PTR [rsp+0x38],eax
  4124f7:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  4124fc:	mov    rcx,rdi
  4124ff:	mov    rdx,QWORD PTR [r11+0x18]
  412503:	mov    r8,rsi
  412506:	mov    r8d,DWORD PTR [r8]
  412509:	mov    r9,rax
  41250c:	lea    r10,[rsp+0x10]
  412511:	call   40a0e0 <__swc_fn_6b1cf01f_000162_72795826>
  412516:	test   al,al
  412518:	jne    41254b <__swc_fn_6b1cf01f_000164_cc119975+0x19b>
  41251a:	vmovups xmm0,XMMWORD PTR [rip+0x153e]        # 413a60 <__swc_rdata_base_6b1cf01f+0x950>
  412522:	vmovups XMMWORD PTR [rbx],xmm0
  412526:	vmovups xmm0,XMMWORD PTR [rip+0x1542]        # 413a70 <__swc_rdata_base_6b1cf01f+0x960>
  41252e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  412533:	vxorps xmm0,xmm0,xmm0
  412537:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  41253c:	mov    rax,rbx
  41253f:	add    rsp,0x50
  412543:	pop    r13
  412545:	pop    r12
  412547:	pop    rdi
  412548:	pop    rsi
  412549:	pop    rbx
  41254a:	ret
  41254b:	lea    r13,[rsp+0x3c]
  412550:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  412555:	mov    DWORD PTR [rsp+0x3c],eax
  412559:	test   eax,eax
  41255b:	je     4125ac <__swc_fn_6b1cf01f_000164_cc119975+0x1fc>
  41255d:	mov    rcx,rdi
  412560:	mov    rdx,QWORD PTR [r11+0x18]
  412564:	mov    r8d,DWORD PTR [rsi]
  412567:	mov    rax,r13
  41256a:	mov    r9d,DWORD PTR [rax]
  41256d:	lea    r10,[rsp+0x20]
  412572:	call   40a0e0 <__swc_fn_6b1cf01f_000162_72795826>
  412577:	test   al,al
  412579:	jne    4125ac <__swc_fn_6b1cf01f_000164_cc119975+0x1fc>
  41257b:	vmovups xmm0,XMMWORD PTR [rip+0x150d]        # 413a90 <__swc_rdata_base_6b1cf01f+0x980>
  412583:	vmovups XMMWORD PTR [rbx],xmm0
  412587:	vmovups xmm0,XMMWORD PTR [rip+0x1511]        # 413aa0 <__swc_rdata_base_6b1cf01f+0x990>
  41258f:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  412594:	vxorps xmm0,xmm0,xmm0
  412598:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  41259d:	mov    rax,rbx
  4125a0:	add    rsp,0x50
  4125a4:	pop    r13
  4125a6:	pop    r12
  4125a8:	pop    rdi
  4125a9:	pop    rsi
  4125aa:	pop    rbx
  4125ab:	ret
  4125ac:	mov    eax,0x1
  4125b1:	rex mov BYTE PTR [rsp+0x8],al
  4125b6:	cmp    DWORD PTR [r13+0x0],0x0
  4125bb:	je     4125cc <__swc_fn_6b1cf01f_000164_cc119975+0x21c>
  4125bd:	rex mov BYTE PTR [rsp+0x9],0x1
  4125c3:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  4125c8:	mov    DWORD PTR [rsp+0x30],eax
  4125cc:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4125d2:	vmovups XMMWORD PTR [rbx],xmm0
  4125d6:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  4125dc:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  4125e1:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  4125e7:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  4125ec:	mov    rax,rbx
  4125ef:	add    rsp,0x50
  4125f3:	pop    r13
  4125f5:	pop    r12
  4125f7:	pop    rdi
  4125f8:	pop    rsi
  4125f9:	pop    rbx
  4125fa:	ret
  4125fb:	add    rcx,0x1
  4125ff:	cmp    rcx,rax
  412602:	jb     4124c0 <__swc_fn_6b1cf01f_000164_cc119975+0x110>
  412608:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  41260e:	vmovups XMMWORD PTR [rbx],xmm0
  412612:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  412618:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  41261d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  412623:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  412628:	mov    rax,rbx
  41262b:	add    rsp,0x50
  41262f:	pop    r13
  412631:	pop    r12
  412633:	pop    rdi
  412634:	pop    rsi
  412635:	pop    rbx
  412636:	ret
	...

0000000000412640 <__swc_fn_6b1cf01f_000167_994c8876>:
  412640:	sub    rsp,0x48
  412644:	call   411a20 <__swc_fn_6b1cf01f_000125_58f0f391>
  412649:	cmp    rax,0xffffffffffffffff
  41264d:	je     412654 <__swc_fn_6b1cf01f_000167_994c8876+0x14>
  41264f:	add    rsp,0x48
  412653:	ret
  412654:	lea    rcx,[rip+0x1475]        # 413ad0 <__swc_rdata_base_6b1cf01f+0x9c0>
  41265b:	vmovups xmm0,XMMWORD PTR [rip+0x147d]        # 413ae0 <__swc_rdata_base_6b1cf01f+0x9d0>
  412663:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  412669:	vmovups xmm0,XMMWORD PTR [rip+0x147f]        # 413af0 <__swc_rdata_base_6b1cf01f+0x9e0>
  412671:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  412677:	vmovups xmm0,XMMWORD PTR [rip+0x1481]        # 413b00 <__swc_rdata_base_6b1cf01f+0x9f0>
  41267f:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  412685:	lea    rdx,[rsp+0x8]
  41268a:	mov    QWORD PTR [rsp+0x38],rax
  41268f:	call   4092c0 <__swc_fn_6b1cf01f_000105_90faaa26>
  412694:	mov    rax,QWORD PTR [rsp+0x38]
  412699:	jmp    41264f <__swc_fn_6b1cf01f_000167_994c8876+0xf>
  41269b:	add    BYTE PTR [rax],al
  41269d:	add    BYTE PTR [rax],al
	...

00000000004126a0 <__swc_fn_6b1cf01f_000170_cbeff767>:
  4126a0:	push   rbx
  4126a1:	push   rsi
  4126a2:	sub    rsp,0x28
  4126a6:	mov    rbx,rcx
  4126a9:	mov    DWORD PTR [rsp+0x8],0xbf0
  4126b1:	mov    ecx,0xbf0
  4126b6:	call   408eb0 <__swc_fn_6b1cf01f_000081_4a10c7e7>
  4126bb:	mov    rsi,rax
  4126be:	test   rax,rax
  4126c1:	jne    4126cc <__swc_fn_6b1cf01f_000170_cbeff767+0x2c>
  4126c3:	xor    eax,eax
  4126c5:	add    rsp,0x28
  4126c9:	pop    rsi
  4126ca:	pop    rbx
  4126cb:	ret
  4126cc:	vxorps xmm0,xmm0,xmm0
  4126d0:	xor    eax,eax
  4126d2:	cs nop WORD PTR [rax+rax*1+0x0]
  4126dc:	nop    DWORD PTR [rax+0x0]
  4126e0:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  4126e5:	add    rax,0x10
  4126e9:	cmp    rax,0xbf0
  4126f0:	jne    4126e0 <__swc_fn_6b1cf01f_000170_cbeff767+0x40>
  4126f2:	lea    rax,[rbx+0x1]
  4126f6:	mov    QWORD PTR [rsi+0x9c0],rax
  4126fd:	mov    rcx,rbx
  412700:	mov    rdx,rsi
  412703:	call   40a440 <__swc_fn_6b1cf01f_000168_646fdf20>
  412708:	test   al,al
  41270a:	jne    41271d <__swc_fn_6b1cf01f_000170_cbeff767+0x7d>
  41270c:	mov    rcx,rsi
  41270f:	call   40c750 <__swc_fn_6b1cf01f_000082_cf82995a>
  412714:	xor    eax,eax
  412716:	add    rsp,0x28
  41271a:	pop    rsi
  41271b:	pop    rbx
  41271c:	ret
  41271d:	lea    rcx,[rsp+0x18]
  412722:	call   40ccd0 <__swc_fn_6b1cf01f_000094_93bfe675>
  412727:	mov    rax,rsi
  41272a:	add    rsp,0x28
  41272e:	pop    rsi
  41272f:	pop    rbx
  412730:	ret
	...

0000000000412740 <__swc_fn_6b1cf01f_000173_e09f8b62>:
  412740:	xor    eax,eax
  412742:	mov    edx,0x1
  412747:	lock cmpxchg QWORD PTR [rcx],rdx
  41274c:	test   rax,rax
  41274f:	jne    412752 <__swc_fn_6b1cf01f_000173_e09f8b62+0x12>
  412751:	ret
  412752:	cs nop WORD PTR [rax+rax*1+0x0]
  41275c:	nop    DWORD PTR [rax+0x0]
  412760:	mov    rax,QWORD PTR [rcx]
  412763:	test   rax,rax
  412766:	je     412740 <__swc_fn_6b1cf01f_000173_e09f8b62>
  412768:	jmp    412760 <__swc_fn_6b1cf01f_000173_e09f8b62+0x20>
  41276a:	add    BYTE PTR [rax],al
  41276c:	add    BYTE PTR [rax],al
	...

0000000000412770 <__swc_fn_6b1cf01f_000176_718d7b54>:
  412770:	push   rsi
  412771:	push   rdi
  412772:	sub    rsp,0x38
  412776:	mov    rsi,rcx
  412779:	call   40a450 <__swc_fn_6b1cf01f_000171_1e0ea8cf>
  41277e:	mov    rdi,rax
  412781:	call   409be0 <__swc_fn_6b1cf01f_000132_a9c1c700>
  412786:	mov    r8,rax
  412789:	mov    rcx,rdi
  41278c:	call   412740 <__swc_fn_6b1cf01f_000173_e09f8b62>
  412791:	mov    rax,QWORD PTR [rdi+0x8]
  412795:	test   rax,rax
  412798:	je     4127d5 <__swc_fn_6b1cf01f_000176_718d7b54+0x65>
  41279a:	nop    WORD PTR [rax+rax*1+0x0]
  4127a0:	cmp    rax,rsi
  4127a3:	je     4127d5 <__swc_fn_6b1cf01f_000176_718d7b54+0x65>
  4127a5:	mov    r9,QWORD PTR [rax]
  4127a8:	cmp    QWORD PTR [rax+0x20],r8
  4127ac:	jne    4127cd <__swc_fn_6b1cf01f_000176_718d7b54+0x5d>
  4127ae:	mov    rcx,rdi
  4127b1:	mov    rdx,rax
  4127b4:	mov    QWORD PTR [rsp+0x28],r8
  4127b9:	mov    QWORD PTR [rsp+0x30],r9
  4127be:	call   40f6a0 <__swc_fn_6b1cf01f_000175_cf4ffedd>
  4127c3:	mov    r8,QWORD PTR [rsp+0x28]
  4127c8:	mov    r9,QWORD PTR [rsp+0x30]
  4127cd:	mov    rax,r9
  4127d0:	test   r9,r9
  4127d3:	jne    4127a0 <__swc_fn_6b1cf01f_000176_718d7b54+0x30>
  4127d5:	xor    eax,eax
  4127d7:	mov    QWORD PTR [rdi],rax
  4127da:	add    rsp,0x38
  4127de:	pop    rdi
  4127df:	pop    rsi
  4127e0:	ret
