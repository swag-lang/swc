
/workspace/prompt2-20261115/batch5-final-micro/base/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

0000000000411a40 <__swc_fn_4fa09e82_000146_140c84e9>:
  411a40:	push   rbx
  411a41:	sub    rsp,0xe0
  411a48:	lea    rbx,[rsp+0x8]
  411a4d:	vxorps xmm0,xmm0,xmm0
  411a51:	vmovups XMMWORD PTR [rbx],xmm0
  411a55:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  411a5a:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  411a5f:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  411a64:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  411a69:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  411a6e:	mov    DWORD PTR [rbx+0x60],0x0
  411a75:	mov    r8,rbx
  411a78:	mov    rdx,rcx
  411a7b:	nop    DWORD PTR [rax+rax*1+0x0]
  411a80:	mov    r9,rdx
  411a83:	movabs rdx,0x6666666666666667
  411a8d:	mov    rax,r9
  411a90:	imul   rdx
  411a93:	sar    rdx,0x2
  411a97:	mov    r10,rdx
  411a9a:	shr    rdx,0x3f
  411a9e:	add    r10,rdx
  411aa1:	mov    rdx,r10
  411aa4:	imul   r11,r10,0xa
  411aa8:	sub    r9,r11
  411aab:	mov    r11,QWORD PTR [rip+0x1a8e]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  411ab2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  411ab7:	mov    BYTE PTR [r8],r9b
  411aba:	lea    r9,[r8+0x1]
  411abe:	mov    r8,r9
  411ac1:	test   r10,r10
  411ac4:	jne    411a80 <__swc_fn_4fa09e82_000146_140c84e9+0x40>
  411ac6:	test   rcx,rcx
  411ac9:	jge    411ad3 <__swc_fn_4fa09e82_000146_140c84e9+0x93>
  411acb:	mov    BYTE PTR [r9],0x2d
  411acf:	add    r8,0x1
  411ad3:	mov    BYTE PTR [r8],0x0
  411ad7:	sub    r8,0x1
  411adb:	mov    rax,rbx
  411ade:	cmp    rax,r8
  411ae1:	jae    411b06 <__swc_fn_4fa09e82_000146_140c84e9+0xc6>
  411ae3:	cs nop WORD PTR [rax+rax*1+0x0]
  411aed:	nop    DWORD PTR [rax]
  411af0:	mov    cl,BYTE PTR [r8]
  411af3:	mov    dl,BYTE PTR [rax]
  411af5:	mov    BYTE PTR [r8],dl
  411af8:	sub    r8,0x1
  411afc:	mov    BYTE PTR [rax],cl
  411afe:	inc    rax
  411b01:	cmp    rax,r8
  411b04:	jb     411af0 <__swc_fn_4fa09e82_000146_140c84e9+0xb0>
  411b06:	xor    eax,eax
  411b08:	test   rbx,rbx
  411b0b:	je     411b2e <__swc_fn_4fa09e82_000146_140c84e9+0xee>
  411b0d:	mov    rcx,rbx
  411b10:	mov    dl,BYTE PTR [rcx]
  411b12:	test   dl,dl
  411b14:	je     411b2e <__swc_fn_4fa09e82_000146_140c84e9+0xee>
  411b16:	cs nop WORD PTR [rax+rax*1+0x0]
  411b20:	add    rcx,0x1
  411b24:	add    rax,0x1
  411b28:	mov    dl,BYTE PTR [rcx]
  411b2a:	test   dl,dl
  411b2c:	jne    411b20 <__swc_fn_4fa09e82_000146_140c84e9+0xe0>
  411b2e:	mov    QWORD PTR [rbx+0xa8],rbx
  411b35:	mov    QWORD PTR [rbx+0xb0],rax
  411b3c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  411b44:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  411b4c:	lea    rcx,[rbx+0xb8]
  411b53:	call   4098c0 <__swc_fn_4fa09e82_000117_18ca1307>
  411b58:	add    rsp,0xe0
  411b5f:	pop    rbx
  411b60:	ret
