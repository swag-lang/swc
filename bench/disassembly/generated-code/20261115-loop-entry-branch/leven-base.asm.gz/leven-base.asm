
/workspace/prompt2-20261115/batch7-placement-micro/base/leven/leven:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <getpid@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <getpid@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <munmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <munmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <exit@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <exit@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <pthread_key_create@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <pthread_key_create@GLIBC_2.34>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_setspecific@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <pthread_setspecific@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <syscall@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <syscall@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dladdr@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <dladdr@GLIBC_2.34>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <open@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <open@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <lseek@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <lseek@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <close@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <close@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <mmap@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <mmap@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <malloc@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <malloc@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <madvise@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf9a]        # 413080 <madvise@GLIBC_2.2.5>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <pthread_key_delete@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf92]        # 413088 <pthread_key_delete@GLIBC_2.34>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <gettid@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf8a]        # 413090 <gettid@GLIBC_2.30>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <flock@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf82]        # 413098 <flock@GLIBC_2.2.5>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <__errno_location@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf7a]        # 4130a0 <__errno_location@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <opendir@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf72]        # 4130a8 <opendir@GLIBC_2.2.5>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <dirfd@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf6a]        # 4130b0 <dirfd@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <readdir@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf62]        # 4130b8 <readdir@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <readlinkat@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <readlinkat@GLIBC_2.4>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <openat@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <openat@GLIBC_2.4>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <closedir@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <closedir@GLIBC_2.2.5>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <memfd_create@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <memfd_create@GLIBC_2.27>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <ftruncate@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <ftruncate@GLIBC_2.2.5>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <write@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <write@GLIBC_2.2.5>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <backtrace@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <backtrace@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <clock_gettime@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <clock_gettime@GLIBC_2.17>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <__x86_get_cpuid_feature_leaf@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <free@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <free@GLIBC_2.2.5>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_fc36583a_000176_1ca87929+0xf80>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40d240 <__swc_fn_fc36583a_000121_1c5e75b6>
  40724e:	xor    ecx,ecx
  407250:	call   40c960 <__swc_fn_fc36583a_000094_383a814c>
  407255:	call   40a360 <__swc_fn_fc36583a_000177_aa67484d>
  40725a:	call   40f6d0 <__swc_fn_fc36583a_000095_8cc4b392>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_fc36583a_000000_0e26756e>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_fc36583a_000003_81215399>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_fc36583a_000003_81215399+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   409240 <__swc_fn_fc36583a_000111_f9e19033>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_fc36583a_000003_81215399+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1cd81]        # 424048 <__swc_bss_base_fc36583a+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1cd7a]        # 424048 <__swc_bss_base_fc36583a+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_fc36583a_000003_81215399+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_fc36583a_000003_81215399+0x30>
  4072e6:	lea    rcx,[rip+0x1cd63]        # 424050 <__swc_bss_base_fc36583a+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1cd5c]        # 424050 <__swc_bss_base_fc36583a+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_fc36583a_000003_81215399+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_fc36583a_000003_81215399+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_fc36583a_000006_7b253ae1>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40df80 <__swc_fn_fc36583a_000011_71c91685>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_fc36583a_000012_be38a1a2>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_fc36583a_000006_7b253ae1+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_fc36583a_000003_81215399>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_fc36583a_000006_7b253ae1+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_fc36583a_000009_4c3ebf16>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_fc36583a_000009_4c3ebf16+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40acf0 <__swc_fn_fc36583a_000007_a7bfb091>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40df70 <__swc_fn_fc36583a_000008_b2f73e0d>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_fc36583a_000009_4c3ebf16+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_fc36583a_000009_4c3ebf16+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_fc36583a_000012_be38a1a2>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_fc36583a_000015_96cb1311>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_fc36583a_000015_96cb1311+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_fc36583a_000015_96cb1311+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_fc36583a_000015_96cb1311+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_fc36583a_000015_96cb1311+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40e0e0 <__swc_fn_fc36583a_000017_f003fc47>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_fc36583a_000015_96cb1311+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1cb3d]        # 424058 <__swc_bss_base_fc36583a+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1cb36]        # 424058 <__swc_bss_base_fc36583a+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_fc36583a_000015_96cb1311+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_fc36583a_000015_96cb1311+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40df80 <__swc_fn_fc36583a_000011_71c91685>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_fc36583a_000015_96cb1311+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   40cf60 <__swc_fn_fc36583a_000112_2f7f9346>
  407569:	lea    rcx,[rip+0x1cad8]        # 424048 <__swc_bss_base_fc36583a+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1cad1]        # 424048 <__swc_bss_base_fc36583a+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_fc36583a_000015_96cb1311+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_fc36583a_000015_96cb1311+0x110>
  407598:	lea    rcx,[rip+0x1cac1]        # 424060 <__swc_bss_base_fc36583a+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1caba]        # 424060 <__swc_bss_base_fc36583a+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_fc36583a_000015_96cb1311+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_fc36583a_000015_96cb1311+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_fc36583a_000018_77ece227>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_fc36583a_000015_96cb1311+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_fc36583a_000018_77ece227>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_fc36583a_000018_77ece227+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_fc36583a_000018_77ece227+0x10>

0000000000407630 <__swc_fn_fc36583a_000021_9cf87641>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_fc36583a_000015_96cb1311>
  40763e:	lea    rdi,[rip+0x1cbab]        # 4241f0 <__swc_bss_base_fc36583a+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   4098a0 <__swc_fn_fc36583a_000135_db32cc57>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1cb94]        # 4241f8 <__swc_bss_base_fc36583a+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1cb89],rsi        # 4241f8 <__swc_bss_base_fc36583a+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_fc36583a_000024_e876734d>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_fc36583a_000027_e876734d>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_fc36583a_000030_650caec0>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_fc36583a_000030_650caec0+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1a92c]        # 422000 <__swc_data_base_fc36583a>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_fc36583a_000030_650caec0+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_fc36583a_000030_650caec0+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_fc36583a_000030_650caec0+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40e2a0 <__swc_fn_fc36583a_000032_f1940e30>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_fc36583a_000030_650caec0+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_fc36583a_000036_290a131c>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_fc36583a_000030_650caec0+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_fc36583a_000042_0573444d>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_fc36583a_000033_d15eb4ea>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40b1a0 <__swc_fn_fc36583a_000031_3c3e930e>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   409720 <__swc_fn_fc36583a_000129_bc477461>
  407734:	mov    rcx,rsi
  407737:	call   40e2a0 <__swc_fn_fc36583a_000032_f1940e30>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_fc36583a_000036_290a131c>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_fc36583a_000039_9ae4348f>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_fc36583a_000039_9ae4348f+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_fc36583a_000039_9ae4348f+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_fc36583a_000039_9ae4348f+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_fc36583a_000039_9ae4348f+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_fc36583a_000039_9ae4348f+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   409320 <__swc_fn_fc36583a_000114_cc486df9>
  4077ca:	lea    rcx,[rip+0x1c877]        # 424048 <__swc_bss_base_fc36583a+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1c870]        # 424048 <__swc_bss_base_fc36583a+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_fc36583a_000039_9ae4348f+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_fc36583a_000039_9ae4348f+0x90>
  4077f8:	lea    rcx,[rip+0x1c861]        # 424060 <__swc_bss_base_fc36583a+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1c85a]        # 424060 <__swc_bss_base_fc36583a+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_fc36583a_000039_9ae4348f+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_fc36583a_000039_9ae4348f+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_fc36583a_000042_0573444d>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_fc36583a_000042_0573444d+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40e870 <__swc_fn_fc36583a_000059_ee6a254c>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   4098a0 <__swc_fn_fc36583a_000135_db32cc57>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_fc36583a_000042_0573444d+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_fc36583a_000042_0573444d+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_fc36583a_000009_4c3ebf16>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_fc36583a_000042_0573444d+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40dfa0 <__swc_fn_fc36583a_000014_be17798c>
  40791e:	jmp    407941 <__swc_fn_fc36583a_000042_0573444d+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_fc36583a_000042_0573444d+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_fc36583a_000042_0573444d+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_fc36583a_000042_0573444d+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40b360 <__swc_fn_fc36583a_000043_47ff6d9b>
  407997:	mov    rcx,rdi
  40799a:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_fc36583a_000039_9ae4348f>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_fc36583a_000045_bb688d37>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_fc36583a_000045_bb688d37+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_fc36583a_000045_bb688d37+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_fc36583a_000045_bb688d37+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_fc36583a_000045_bb688d37+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   4098a0 <__swc_fn_fc36583a_000135_db32cc57>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_fc36583a_000045_bb688d37+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_fc36583a_000045_bb688d37+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_fc36583a_000045_bb688d37+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_fc36583a_000045_bb688d37+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_fc36583a_000009_4c3ebf16>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_fc36583a_000045_bb688d37+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_fc36583a_000045_bb688d37+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_fc36583a_000045_bb688d37+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_fc36583a_000045_bb688d37+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_fc36583a_000045_bb688d37+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40ada0 <__swc_fn_fc36583a_000013_7b85dbab>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_fc36583a_000045_bb688d37+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_fc36583a_000045_bb688d37+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_fc36583a_000045_bb688d37+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_fc36583a_000045_bb688d37+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40e120 <__swc_fn_fc36583a_000020_4285d9c5>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_fc36583a_000045_bb688d37+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40ada0 <__swc_fn_fc36583a_000013_7b85dbab>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_fc36583a_000045_bb688d37+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_fc36583a_000021_9cf87641>
  407c07:	mov    rcx,r14
  407c0a:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_fc36583a_000045_bb688d37+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_fc36583a_000045_bb688d37+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_fc36583a_000045_bb688d37+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_fc36583a_000048_8e68f77b>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_fc36583a_000048_8e68f77b+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_fc36583a_000048_8e68f77b+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_fc36583a_000048_8e68f77b+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_fc36583a_000048_8e68f77b+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40e4d0 <__swc_fn_fc36583a_000047_e7fd8d42>
  407d14:	jmp    407ce0 <__swc_fn_fc36583a_000048_8e68f77b+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_fc36583a_000048_8e68f77b+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_fc36583a_000048_8e68f77b+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_fc36583a_000048_8e68f77b+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_fc36583a_000048_8e68f77b+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_fc36583a_000048_8e68f77b+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_fc36583a_000048_8e68f77b+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_fc36583a_000048_8e68f77b+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_fc36583a_000051_27d2a35f>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_fc36583a_000051_27d2a35f+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_fc36583a_000051_27d2a35f+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_fc36583a_000051_27d2a35f+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_fc36583a_000051_27d2a35f+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40e430 <__swc_fn_fc36583a_000044_fe6bbfdb>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40dfa0 <__swc_fn_fc36583a_000014_be17798c>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_fc36583a_000054_e8e85c01>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   4098a0 <__swc_fn_fc36583a_000135_db32cc57>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_fc36583a_000054_e8e85c01+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_fc36583a_000054_e8e85c01+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_fc36583a_000054_e8e85c01+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_fc36583a_000057_01c75a1d>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_fc36583a_000060_6818d0d1>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_fc36583a_000060_6818d0d1+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_fc36583a_000039_9ae4348f>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_fc36583a_000060_6818d0d1+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_fc36583a_000063_db6d2425>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40b6e0 <__swc_fn_fc36583a_000052_92b016ae>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_fc36583a_000054_e8e85c01>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_fc36583a_000063_db6d2425+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_fc36583a_000063_db6d2425+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40b800 <__swc_fn_fc36583a_000058_01964a17>
  407f7f:	mov    rcx,rsi
  407f82:	call   40b440 <__swc_fn_fc36583a_000049_f6a485a2>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_fc36583a_000066_918d3875>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_fc36583a_000066_918d3875+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1c049]        # 424070 <__swc_bss_base_fc36583a+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1c04b]        # 424080 <__swc_bss_base_fc36583a+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_fc36583a_000066_918d3875+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_fc36583a_000066_918d3875+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40b0d0 <__swc_fn_fc36583a_000022_53fc00d2>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_fc36583a_000066_918d3875+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_fc36583a_000063_db6d2425>
  40808f:	jmp    408122 <__swc_fn_fc36583a_000066_918d3875+0x192>
  408094:	lea    rax,[rip+0x19f65]        # 422000 <__swc_data_base_fc36583a>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_fc36583a_000066_918d3875+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_fc36583a_000066_918d3875+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_fc36583a_000066_918d3875+0x135>
  4080b8:	call   40b1a0 <__swc_fn_fc36583a_000031_3c3e930e>
  4080bd:	mov    rcx,rax
  4080c0:	call   410460 <__swc_fn_fc36583a_000128_8d8a7dd2>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_fc36583a_000066_918d3875+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_fc36583a_000066_918d3875+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_fc36583a_000066_918d3875+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40e4d0 <__swc_fn_fc36583a_000047_e7fd8d42>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_fc36583a_000066_918d3875+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_fc36583a_000051_27d2a35f>
  408115:	jmp    408122 <__swc_fn_fc36583a_000066_918d3875+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40ad10 <__swc_fn_fc36583a_000010_0569f799>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_fc36583a_000069_34b04ef2>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_fc36583a_000036_290a131c>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_fc36583a_000069_34b04ef2+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1c09a]        # 424240 <__swc_bss_base_fc36583a+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_fc36583a_000069_34b04ef2+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   4098a0 <__swc_fn_fc36583a_000135_db32cc57>
  4081b5:	mov    rcx,rsi
  4081b8:	call   40eca0 <__swc_fn_fc36583a_000068_f501e74b>
  4081bd:	mov    rcx,rsi
  4081c0:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_fc36583a_000072_bf7b5562>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40e9f0 <__swc_fn_fc36583a_000065_0b20477c>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_fc36583a_000075_41334281>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   40eca0 <__swc_fn_fc36583a_000068_f501e74b>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_fc36583a_000078_140918ec>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_fc36583a_000078_140918ec+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_fc36583a_000078_140918ec+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_fc36583a_000081_f4f506c7>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_fc36583a_000084_5ed30bd6>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_fc36583a_000090_14cf59b2>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_fc36583a_000084_5ed30bd6+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_fc36583a_000084_5ed30bd6+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_fc36583a_000084_5ed30bd6+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_fc36583a_000084_5ed30bd6+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_fc36583a_000090_14cf59b2>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_fc36583a_000084_5ed30bd6+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_fc36583a_000084_5ed30bd6+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_fc36583a_000084_5ed30bd6+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_fc36583a_000084_5ed30bd6+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_fc36583a_000084_5ed30bd6+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_fc36583a_000084_5ed30bd6+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_fc36583a_000084_5ed30bd6+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_fc36583a_000084_5ed30bd6+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_fc36583a_000084_5ed30bd6+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_fc36583a_000084_5ed30bd6+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40c7e0 <__swc_fn_fc36583a_000082_ff7d1455>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_fc36583a_000084_5ed30bd6+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_fc36583a_000084_5ed30bd6+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_fc36583a_000084_5ed30bd6+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40c7e0 <__swc_fn_fc36583a_000082_ff7d1455>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_fc36583a_000084_5ed30bd6+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_fc36583a_000084_5ed30bd6>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_fc36583a_000084_5ed30bd6+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_fc36583a_000084_5ed30bd6+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_fc36583a_000087_693f118e>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_fc36583a_000090_14cf59b2>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_fc36583a_000087_693f118e+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   40f100 <__swc_fn_fc36583a_000086_d9243de4>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_fc36583a_000087_693f118e+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_fc36583a_000087_693f118e+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_fc36583a_000087_693f118e+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40c7e0 <__swc_fn_fc36583a_000082_ff7d1455>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_fc36583a_000087_693f118e+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_fc36583a_000087_693f118e>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_fc36583a_000087_693f118e+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_fc36583a_000087_693f118e+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_fc36583a_000090_14cf59b2>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_fc36583a_000090_14cf59b2+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_fc36583a_000090_14cf59b2+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_fc36583a_000090_14cf59b2+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_fc36583a_000090_14cf59b2+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40c7e0 <__swc_fn_fc36583a_000082_ff7d1455>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40c7e0 <__swc_fn_fc36583a_000082_ff7d1455>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_fc36583a_000090_14cf59b2+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_fc36583a_000090_14cf59b2+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_fc36583a_000090_14cf59b2+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_fc36583a_000090_14cf59b2+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_fc36583a_000090_14cf59b2>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_fc36583a_000090_14cf59b2+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_fc36583a_000090_14cf59b2+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_fc36583a_000090_14cf59b2+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_fc36583a_000090_14cf59b2+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_fc36583a_000090_14cf59b2+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_fc36583a_000090_14cf59b2+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_fc36583a_000090_14cf59b2+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_fc36583a_000090_14cf59b2+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_fc36583a_000090_14cf59b2+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_fc36583a_000090_14cf59b2+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_fc36583a_000090_14cf59b2+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_fc36583a_000090_14cf59b2+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_fc36583a_000090_14cf59b2+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_fc36583a_000090_14cf59b2+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_fc36583a_000090_14cf59b2+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_fc36583a_000090_14cf59b2+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   409db0 <__swc_fn_fc36583a_000147_e7bfe29e>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_fc36583a_000090_14cf59b2+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_fc36583a_000090_14cf59b2>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_fc36583a_000090_14cf59b2+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_fc36583a_000090_14cf59b2+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_fc36583a_000090_14cf59b2+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   409db0 <__swc_fn_fc36583a_000147_e7bfe29e>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   409db0 <__swc_fn_fc36583a_000147_e7bfe29e>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_fc36583a_000093_0c97fc6c>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40c910 <__swc_fn_fc36583a_000091_f21926ed>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_fc36583a_000093_0c97fc6c+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_fc36583a_000093_0c97fc6c+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   410600 <__swc_fn_fc36583a_000137_2d595cc7>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_fc36583a_000093_0c97fc6c+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0xa872]        # 4131c0 <__swc_rdata_base_fc36583a+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   410130 <__swc_fn_fc36583a_000116_3f5cfdef>
  408959:	call   40d190 <__swc_fn_fc36583a_000118_591530fe>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_fc36583a_000096_a4baaa40>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40896f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  408975:	vzeroupper
  408978:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40897e:	mov    QWORD PTR [rsp+0x48],rdx
  408983:	mov    rax,r8
  408986:	cmp    r8,0x1
  40898a:	mov    edx,0x1
  40898f:	cmovb  rax,rdx
  408993:	mov    QWORD PTR [rsp+0x50],rax
  408998:	mov    rbx,QWORD PTR [rcx+0x8]
  40899c:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a0:	mov    rcx,QWORD PTR [rcx]
  4089a3:	lea    rdx,[rsp+0x8]
  4089a8:	call   rbx
  4089aa:	add    rsp,0x70
  4089ae:	pop    rbx
  4089af:	ret

00000000004089b0 <__swc_fn_fc36583a_000099_5232b57d>:
  4089b0:	push   rbx
  4089b1:	push   rsi
  4089b2:	push   rdi
  4089b3:	sub    rsp,0x30
  4089b7:	mov    rbx,rcx
  4089ba:	test   rcx,rcx
  4089bd:	je     4089d2 <__swc_fn_fc36583a_000099_5232b57d+0x22>
  4089bf:	mov    rcx,rbx
  4089c2:	mov    edx,0x1
  4089c7:	call   408200 <__swc_fn_fc36583a_000078_140918ec>
  4089cc:	cmp    rax,0x1
  4089d0:	je     4089da <__swc_fn_fc36583a_000099_5232b57d+0x2a>
  4089d2:	add    rsp,0x30
  4089d6:	pop    rdi
  4089d7:	pop    rsi
  4089d8:	pop    rbx
  4089d9:	ret
  4089da:	lea    rsi,[rsp+0x8]
  4089df:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089e4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089ea:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  4089ef:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4089f5:	mov    rax,QWORD PTR [rsp+0x20]
  4089fa:	test   rax,rax
  4089fd:	je     408a13 <__swc_fn_fc36583a_000099_5232b57d+0x63>
  4089ff:	test   DWORD PTR [rax+0x28],0x400000
  408a06:	je     408a13 <__swc_fn_fc36583a_000099_5232b57d+0x63>
  408a08:	mov    rcx,QWORD PTR [rax+0x30]
  408a0c:	test   rcx,rcx
  408a0f:	cmovne rax,rcx
  408a13:	mov    edi,DWORD PTR [rax+0x20]
  408a16:	lea    rcx,[rsp+0x18]
  408a1b:	call   40caf0 <__swc_fn_fc36583a_000100_5714513e>
  408a20:	mov    rcx,rsi
  408a23:	mov    rdx,QWORD PTR [rsp+0x18]
  408a28:	mov    r8,rdi
  408a2b:	call   408960 <__swc_fn_fc36583a_000096_a4baaa40>
  408a30:	mov    rcx,QWORD PTR [rbx+0x28]
  408a34:	call   40f6e0 <__swc_fn_fc36583a_000098_f82a1ed3>
  408a39:	mov    rcx,rsi
  408a3c:	mov    rdx,rbx
  408a3f:	mov    r8d,0x30
  408a45:	call   408960 <__swc_fn_fc36583a_000096_a4baaa40>
  408a4a:	add    rsp,0x30
  408a4e:	pop    rdi
  408a4f:	pop    rsi
  408a50:	pop    rbx
  408a51:	ret
	...

0000000000408a60 <__swc_fn_fc36583a_000102_14986ec5>:
  408a60:	push   rbp
  408a61:	push   rbx
  408a62:	push   rsi
  408a63:	push   rdi
  408a64:	push   r12
  408a66:	push   r13
  408a68:	push   r14
  408a6a:	push   r15
  408a6c:	sub    rsp,0x500
  408a73:	mov    rbp,rsp
  408a76:	mov    rbx,rsp
  408a79:	mov    rsi,rdx
  408a7c:	mov    rdi,rcx
  408a7f:	mov    rcx,QWORD PTR [rip+0x1e2ba]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  408a86:	test   rcx,rcx
  408a89:	jne    408aa3 <__swc_fn_fc36583a_000102_14986ec5+0x43>
  408a8b:	sub    rsp,0x8
  408a8f:	call   40a1a0 <__swc_fn_fc36583a_000165_56054fe7>
  408a94:	add    rsp,0x8
  408a98:	lea    rcx,[rax+0x1]
  408a9c:	mov    QWORD PTR [rip+0x1e29d],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  408aa3:	dec    rcx
  408aa6:	sub    rsp,0x8
  408aaa:	call   411ee0 <__swc_fn_fc36583a_000167_39c041ad>
  408aaf:	add    rsp,0x8
  408ab3:	mov    r12,rax
  408ab6:	mov    QWORD PTR [rsp+0x4f0],rax
  408abe:	lea    rax,[rip+0xa83b]        # 413300 <__swc_rdata_base_fc36583a+0x1f0>
  408ac5:	sub    rsp,0x20
  408ac9:	mov    rcx,rsp
  408acc:	mov    QWORD PTR [rcx],rax
  408acf:	lea    r13,[rip+0xa83a]        # 413310 <__swc_rdata_base_fc36583a+0x200>
  408ad6:	mov    QWORD PTR [rcx+0x8],r13
  408ada:	mov    QWORD PTR [rcx+0x10],rsp
  408ade:	mov    QWORD PTR [rcx+0x18],0x1
  408ae6:	lea    rcx,[rsp+0x10]
  408aeb:	sub    rsp,0x8
  408aef:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  408af4:	add    rsp,0x8
  408af8:	add    rsp,0x20
  408afc:	lea    rax,[rip+0xa855]        # 413358 <__swc_rdata_base_fc36583a+0x248>
  408b03:	sub    rsp,0x20
  408b07:	mov    rcx,rsp
  408b0a:	mov    QWORD PTR [rcx],rax
  408b0d:	mov    QWORD PTR [rcx+0x8],r13
  408b11:	mov    QWORD PTR [rcx+0x10],rsp
  408b15:	mov    QWORD PTR [rcx+0x18],0x1
  408b1d:	lea    rcx,[rsp+0x10]
  408b22:	sub    rsp,0x8
  408b26:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  408b2b:	add    rsp,0x8
  408b2f:	add    rsp,0x20
  408b33:	lea    r14,[rip+0xa82e]        # 413368 <__swc_rdata_base_fc36583a+0x258>
  408b3a:	sub    rsp,0x50
  408b3e:	mov    rax,rsp
  408b41:	vmovups xmm0,XMMWORD PTR [rip+0xa957]        # 4134a0 <__swc_rdata_base_fc36583a+0x390>
  408b49:	vmovups XMMWORD PTR [rax],xmm0
  408b4d:	mov    QWORD PTR [rax+0x10],rsp
  408b51:	mov    QWORD PTR [rax+0x18],r13
  408b55:	mov    QWORD PTR [rax+0x20],rdi
  408b59:	lea    rdi,[rip+0xa818]        # 413378 <__swc_rdata_base_fc36583a+0x268>
  408b60:	mov    QWORD PTR [rax+0x28],rdi
  408b64:	mov    QWORD PTR [rax+0x30],r14
  408b68:	mov    QWORD PTR [rax+0x38],r13
  408b6c:	lea    rcx,[rsp+0x10]
  408b71:	mov    QWORD PTR [rax+0x40],rcx
  408b75:	mov    QWORD PTR [rax+0x48],0x3
  408b7d:	lea    rcx,[rsp+0x40]
  408b82:	sub    rsp,0x8
  408b86:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  408b8b:	add    rsp,0x8
  408b8f:	add    rsp,0x50
  408b93:	lea    rax,[rip+0xa826]        # 4133c0 <__swc_rdata_base_fc36583a+0x2b0>
  408b9a:	sub    rsp,0x20
  408b9e:	mov    rcx,rsp
  408ba1:	mov    QWORD PTR [rcx],rax
  408ba4:	mov    QWORD PTR [rcx+0x8],r13
  408ba8:	mov    QWORD PTR [rcx+0x10],rsp
  408bac:	mov    QWORD PTR [rcx+0x18],0x1
  408bb4:	lea    rcx,[rsp+0x10]
  408bb9:	sub    rsp,0x8
  408bbd:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  408bc2:	add    rsp,0x8
  408bc6:	add    rsp,0x20
  408bca:	mov    eax,DWORD PTR [rsi+0x20]
  408bcd:	mov    ecx,DWORD PTR [rsi+0x24]
  408bd0:	sub    rsp,0xa0
  408bd7:	mov    rdx,rsp
  408bda:	mov    QWORD PTR [rdx+0x30],rsi
  408bde:	mov    QWORD PTR [rdx+0x38],rdi
  408be2:	vmovups xmm0,XMMWORD PTR [rip+0xa84e]        # 413438 <__swc_rdata_base_fc36583a+0x328>
  408bea:	vmovups XMMWORD PTR [rdx],xmm0
  408bee:	mov    QWORD PTR [rdx+0x40],rsp
  408bf2:	mov    QWORD PTR [rdx+0x48],r13
  408bf6:	mov    DWORD PTR [rdx+0x10],eax
  408bf9:	lea    rax,[rsp+0x10]
  408bfe:	mov    QWORD PTR [rdx+0x50],rax
  408c02:	lea    rax,[rip+0xa7c7]        # 4133d0 <__swc_rdata_base_fc36583a+0x2c0>
  408c09:	mov    QWORD PTR [rdx+0x58],rax
  408c0d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c12:	lea    r8,[rsp+0x18]
  408c17:	mov    QWORD PTR [rdx+0x60],r8
  408c1b:	mov    QWORD PTR [rdx+0x68],r13
  408c1f:	mov    DWORD PTR [rdx+0x28],ecx
  408c22:	lea    rcx,[rdx+0x28]
  408c26:	mov    QWORD PTR [rdx+0x70],rcx
  408c2a:	mov    QWORD PTR [rdx+0x78],rax
  408c2e:	mov    QWORD PTR [rdx+0x80],r14
  408c35:	mov    QWORD PTR [rdx+0x88],r13
  408c3c:	lea    rax,[rdx+0x30]
  408c40:	mov    QWORD PTR [rdx+0x90],rax
  408c47:	mov    QWORD PTR [rdx+0x98],0x6
  408c52:	lea    rcx,[rdx+0x90]
  408c59:	sub    rsp,0x8
  408c5d:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  408c62:	add    rsp,0x8
  408c66:	add    rsp,0xa0
  408c6d:	sub    rsp,0x20
  408c71:	mov    rax,rsp
  408c74:	mov    QWORD PTR [rax],r14
  408c77:	mov    QWORD PTR [rax+0x8],r13
  408c7b:	mov    QWORD PTR [rax+0x10],rsp
  408c7f:	mov    QWORD PTR [rax+0x18],0x1
  408c87:	lea    rcx,[rsp+0x10]
  408c8c:	sub    rsp,0x8
  408c90:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  408c95:	add    rsp,0x8
  408c99:	add    rsp,0x20
  408c9d:	mov    eax,DWORD PTR [r12+0x9ac]
  408ca5:	test   eax,eax
  408ca7:	je     408ee0 <__swc_fn_fc36583a_000102_14986ec5+0x480>
  408cad:	lea    rax,[rip+0xa764]        # 413418 <__swc_rdata_base_fc36583a+0x308>
  408cb4:	sub    rsp,0x20
  408cb8:	mov    rcx,rsp
  408cbb:	mov    QWORD PTR [rcx],rax
  408cbe:	mov    QWORD PTR [rcx+0x8],r13
  408cc2:	mov    QWORD PTR [rcx+0x10],rsp
  408cc6:	mov    QWORD PTR [rcx+0x18],0x1
  408cce:	lea    rcx,[rsp+0x10]
  408cd3:	sub    rsp,0x8
  408cd7:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  408cdc:	add    rsp,0x8
  408ce0:	add    rsp,0x20
  408ce4:	mov    eax,DWORD PTR [r12+0x9ac]
  408cec:	dec    eax
  408cee:	mov    esi,eax
  408cf0:	test   esi,esi
  408cf2:	jl     408eb0 <__swc_fn_fc36583a_000102_14986ec5+0x450>
  408cf8:	jmp    408d04 <__swc_fn_fc36583a_000102_14986ec5+0x2a4>
  408cfa:	nop    WORD PTR [rax+rax*1+0x0]
  408d00:	dec    esi
  408d02:	jmp    408cf0 <__swc_fn_fc36583a_000102_14986ec5+0x290>
  408d04:	lea    rax,[rip+0xa71d]        # 413428 <__swc_rdata_base_fc36583a+0x318>
  408d0b:	sub    rsp,0x20
  408d0f:	mov    rcx,rsp
  408d12:	mov    QWORD PTR [rcx],rax
  408d15:	mov    QWORD PTR [rcx+0x8],r13
  408d19:	mov    QWORD PTR [rcx+0x10],rsp
  408d1d:	mov    QWORD PTR [rcx+0x18],0x1
  408d25:	lea    rcx,[rsp+0x10]
  408d2a:	sub    rsp,0x8
  408d2e:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  408d33:	add    rsp,0x8
  408d37:	add    rsp,0x20
  408d3b:	movsxd rax,esi
  408d3e:	imul   r15,rax,0x30
  408d42:	add    r15,r12
  408d45:	add    r15,0xf8
  408d4c:	sub    rsp,0x20
  408d50:	mov    rax,rsp
  408d53:	mov    QWORD PTR [rax],r15
  408d56:	mov    QWORD PTR [rax+0x8],rdi
  408d5a:	mov    QWORD PTR [rax+0x10],rsp
  408d5e:	mov    QWORD PTR [rax+0x18],0x1
  408d66:	lea    rcx,[rsp+0x10]
  408d6b:	sub    rsp,0x8
  408d6f:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  408d74:	add    rsp,0x8
  408d78:	add    rsp,0x20
  408d7c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408d84:	lea    rsi,[rip+0xa6ad]        # 413438 <__swc_rdata_base_fc36583a+0x328>
  408d8b:	sub    rsp,0x20
  408d8f:	mov    rax,rsp
  408d92:	mov    QWORD PTR [rax],rsi
  408d95:	mov    QWORD PTR [rax+0x8],r13
  408d99:	mov    QWORD PTR [rax+0x10],rsp
  408d9d:	mov    QWORD PTR [rax+0x18],0x1
  408da5:	lea    rcx,[rsp+0x10]
  408daa:	sub    rsp,0x8
  408dae:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  408db3:	add    rsp,0x8
  408db7:	add    rsp,0x20
  408dbb:	sub    rsp,0x30
  408dbf:	mov    rax,rsp
  408dc2:	mov    ecx,DWORD PTR [r15+0x20]
  408dc6:	mov    QWORD PTR [rax],rcx
  408dc9:	mov    QWORD PTR [rax+0x8],rsp
  408dcd:	lea    rdi,[rip+0xa674]        # 413448 <__swc_rdata_base_fc36583a+0x338>
  408dd4:	mov    QWORD PTR [rax+0x10],rdi
  408dd8:	lea    rcx,[rsp+0x8]
  408ddd:	mov    QWORD PTR [rax+0x18],rcx
  408de1:	mov    QWORD PTR [rax+0x20],0x1
  408de9:	lea    rcx,[rsp+0x18]
  408dee:	sub    rsp,0x8
  408df2:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  408df7:	add    rsp,0x8
  408dfb:	add    rsp,0x30
  408dff:	sub    rsp,0x20
  408e03:	mov    rax,rsp
  408e06:	mov    QWORD PTR [rax],rsi
  408e09:	mov    QWORD PTR [rax+0x8],r13
  408e0d:	mov    QWORD PTR [rax+0x10],rsp
  408e11:	mov    QWORD PTR [rax+0x18],0x1
  408e19:	lea    rcx,[rsp+0x10]
  408e1e:	sub    rsp,0x8
  408e22:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  408e27:	add    rsp,0x8
  408e2b:	add    rsp,0x20
  408e2f:	sub    rsp,0x30
  408e33:	mov    rax,rsp
  408e36:	mov    ecx,DWORD PTR [r15+0x24]
  408e3a:	mov    QWORD PTR [rax],rcx
  408e3d:	mov    QWORD PTR [rax+0x8],rsp
  408e41:	mov    QWORD PTR [rax+0x10],rdi
  408e45:	lea    rcx,[rsp+0x8]
  408e4a:	mov    QWORD PTR [rax+0x18],rcx
  408e4e:	mov    QWORD PTR [rax+0x20],0x1
  408e56:	lea    rcx,[rsp+0x18]
  408e5b:	sub    rsp,0x8
  408e5f:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  408e64:	add    rsp,0x8
  408e68:	add    rsp,0x30
  408e6c:	sub    rsp,0x20
  408e70:	mov    rax,rsp
  408e73:	mov    QWORD PTR [rax],r14
  408e76:	mov    QWORD PTR [rax+0x8],r13
  408e7a:	mov    QWORD PTR [rax+0x10],rsp
  408e7e:	mov    QWORD PTR [rax+0x18],0x1
  408e86:	lea    rcx,[rsp+0x10]
  408e8b:	sub    rsp,0x8
  408e8f:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  408e94:	add    rsp,0x8
  408e98:	add    rsp,0x20
  408e9c:	lea    rdi,[rip+0xa4d5]        # 413378 <__swc_rdata_base_fc36583a+0x268>
  408ea3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408eab:	jmp    408d00 <__swc_fn_fc36583a_000102_14986ec5+0x2a0>
  408eb0:	sub    rsp,0x20
  408eb4:	mov    rax,rsp
  408eb7:	mov    QWORD PTR [rax],r14
  408eba:	mov    QWORD PTR [rax+0x8],r13
  408ebe:	mov    QWORD PTR [rax+0x10],rsp
  408ec2:	mov    QWORD PTR [rax+0x18],0x1
  408eca:	lea    rcx,[rsp+0x10]
  408ecf:	sub    rsp,0x8
  408ed3:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  408ed8:	add    rsp,0x8
  408edc:	add    rsp,0x20
  408ee0:	lea    rax,[rbx+0x28]
  408ee4:	mov    rcx,rax
  408ee7:	mov    QWORD PTR [rbx+0x28],0x0
  408eef:	mov    QWORD PTR [rbx+0x30],0x0
  408ef7:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408efc:	add    rcx,0x10
  408f00:	mov    edx,0x1f
  408f05:	cs nop WORD PTR [rax+rax*1+0x0]
  408f0f:	nop
  408f10:	vmovups XMMWORD PTR [rcx],xmm0
  408f14:	add    rcx,0x10
  408f18:	sub    rdx,0x1
  408f1c:	jne    408f10 <__swc_fn_fc36583a_000102_14986ec5+0x4b0>
  408f1e:	lea    rsi,[rbx+0x228]
  408f25:	xor    ecx,ecx
  408f27:	cs nop WORD PTR [rax+rax*1+0x0]
  408f31:	cs nop WORD PTR [rax+rax*1+0x0]
  408f3b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f40:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f45:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f4a:	add    rcx,0x10
  408f4e:	cmp    rcx,0x200
  408f55:	jne    408f40 <__swc_fn_fc36583a_000102_14986ec5+0x4e0>
  408f57:	mov    eax,DWORD PTR [r12+0xbc8]
  408f5f:	lea    rcx,[r12+0x9c8]
  408f67:	mov    QWORD PTR [rbx+0x428],rcx
  408f6e:	mov    QWORD PTR [rbx+0x430],rax
  408f75:	lea    rdi,[rbx+0x438]
  408f7c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408f84:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408f8c:	mov    eax,DWORD PTR [r12+0xbc8]
  408f94:	test   eax,eax
  408f96:	jne    408fe3 <__swc_fn_fc36583a_000102_14986ec5+0x583>
  408f98:	lea    rax,[rbx+0x448]
  408f9f:	mov    QWORD PTR [rbx+0x448],rsi
  408fa6:	mov    QWORD PTR [rax+0x8],0x40
  408fae:	mov    ecx,0x1
  408fb3:	mov    rdx,rax
  408fb6:	sub    rsp,0x8
  408fba:	call   410240 <__swc_fn_fc36583a_000119_2d9caf16>
  408fbf:	add    rsp,0x8
  408fc3:	mov    QWORD PTR [rbx+0x460],rsi
  408fca:	mov    ecx,eax
  408fcc:	mov    QWORD PTR [rbx+0x468],rcx
  408fd3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408fdb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fe3:	mov    rsi,QWORD PTR [rbx+0x438]
  408fea:	mov    rax,QWORD PTR [rbx+0x440]
  408ff1:	mov    r15,rax
  408ff4:	xor    r12d,r12d
  408ff7:	test   r15,r15
  408ffa:	je     4090b0 <__swc_fn_fc36583a_000102_14986ec5+0x650>
  409000:	mov    rax,QWORD PTR [rsi+r12*8]
  409004:	test   rax,rax
  409007:	je     409026 <__swc_fn_fc36583a_000102_14986ec5+0x5c6>
  409009:	lea    rcx,[rbx+0x4b8]
  409010:	mov    rdx,rax
  409013:	sub    rsp,0x8
  409017:	call   409f10 <__swc_fn_fc36583a_000162_61e293bf>
  40901c:	add    rsp,0x8
  409020:	mov    al,BYTE PTR [rax]
  409022:	test   al,al
  409024:	jne    409032 <__swc_fn_fc36583a_000102_14986ec5+0x5d2>
  409026:	add    r12,0x1
  40902a:	sub    r15,0x1
  40902e:	jne    409000 <__swc_fn_fc36583a_000102_14986ec5+0x5a0>
  409030:	jmp    4090b0 <__swc_fn_fc36583a_000102_14986ec5+0x650>
  409032:	lea    rax,[rip+0xa457]        # 413490 <__swc_rdata_base_fc36583a+0x380>
  409039:	sub    rsp,0x20
  40903d:	mov    rcx,rsp
  409040:	mov    QWORD PTR [rcx],rax
  409043:	mov    QWORD PTR [rcx+0x8],r13
  409047:	mov    QWORD PTR [rcx+0x10],rsp
  40904b:	mov    QWORD PTR [rcx+0x18],0x1
  409053:	lea    rcx,[rsp+0x10]
  409058:	sub    rsp,0x8
  40905c:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  409061:	add    rsp,0x8
  409065:	add    rsp,0x20
  409069:	mov    rcx,rdi
  40906c:	xor    edx,edx
  40906e:	mov    al,0x1
  409070:	mov    r8,rax
  409073:	sub    rsp,0x8
  409077:	call   40da20 <__swc_fn_fc36583a_000163_3a7aae74>
  40907c:	add    rsp,0x8
  409080:	sub    rsp,0x20
  409084:	mov    rax,rsp
  409087:	mov    QWORD PTR [rax],r14
  40908a:	mov    QWORD PTR [rax+0x8],r13
  40908e:	mov    QWORD PTR [rax+0x10],rsp
  409092:	mov    QWORD PTR [rax+0x18],0x1
  40909a:	lea    rcx,[rsp+0x10]
  40909f:	sub    rsp,0x8
  4090a3:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  4090a8:	add    rsp,0x8
  4090ac:	add    rsp,0x20
  4090b0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090b8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090c4:	add    rsp,0x500
  4090cb:	pop    r15
  4090cd:	pop    r14
  4090cf:	pop    r13
  4090d1:	pop    r12
  4090d3:	pop    rdi
  4090d4:	pop    rsi
  4090d5:	pop    rbx
  4090d6:	pop    rbp
  4090d7:	ret
	...

00000000004090e0 <__swc_fn_fc36583a_000105_83487ba1>:
  4090e0:	sub    rsp,0x8
  4090e4:	test   r8,r8
  4090e7:	je     4090ee <__swc_fn_fc36583a_000105_83487ba1+0xe>
  4090e9:	call   40f970 <__swc_fn_fc36583a_000104_04d1a8be>
  4090ee:	add    rsp,0x8
  4090f2:	ret
	...

0000000000409100 <__swc_fn_fc36583a_000108_b8f4bd15>:
  409100:	push   rsi
  409101:	push   rdi
  409102:	push   r12
  409104:	push   r13
  409106:	sub    rsp,0xd8
  40910d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409113:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  409119:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40911f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  409125:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40912b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  409134:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40913d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  409146:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40914f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  409158:	xor    eax,eax
  40915a:	call   407010 <getpid@plt>
  40915f:	mov    rsi,rax
  409162:	lea    rdi,[rip+0x1dbdf]        # 426d48 <__swc_bss_base_fc36583a+0x2d08>
  409169:	mov    r12,QWORD PTR [rdi]
  40916c:	test   r12,r12
  40916f:	je     40917d <__swc_fn_fc36583a_000108_b8f4bd15+0x7d>
  409171:	cmp    DWORD PTR [r12+0x10],esi
  409176:	jne    40917d <__swc_fn_fc36583a_000108_b8f4bd15+0x7d>
  409178:	mov    rax,r12
  40917b:	jmp    4091e0 <__swc_fn_fc36583a_000108_b8f4bd15+0xe0>
  40917d:	mov    ecx,0x4
  409182:	mov    edx,0x18
  409187:	call   40fa50 <__swc_fn_fc36583a_000107_c8d4a68e>
  40918c:	mov    rcx,rax
  40918f:	test   rax,rax
  409192:	jne    409198 <__swc_fn_fc36583a_000108_b8f4bd15+0x98>
  409194:	xor    eax,eax
  409196:	jmp    4091e0 <__swc_fn_fc36583a_000108_b8f4bd15+0xe0>
  409198:	mov    DWORD PTR [rcx+0x10],esi
  40919b:	mov    rax,r12
  40919e:	lock cmpxchg QWORD PTR [rdi],rcx
  4091a3:	mov    r13,rax
  4091a6:	cmp    rax,r12
  4091a9:	je     4091bf <__swc_fn_fc36583a_000108_b8f4bd15+0xbf>
  4091ab:	mov    rdi,rcx
  4091ae:	mov    esi,0x18
  4091b3:	xor    eax,eax
  4091b5:	call   407020 <munmap@plt>
  4091ba:	mov    rax,r13
  4091bd:	jmp    4091e0 <__swc_fn_fc36583a_000108_b8f4bd15+0xe0>
  4091bf:	test   r12,r12
  4091c2:	je     4091dd <__swc_fn_fc36583a_000108_b8f4bd15+0xdd>
  4091c4:	mov    rdi,r12
  4091c7:	mov    esi,0x18
  4091cc:	xor    eax,eax
  4091ce:	mov    QWORD PTR [rsp+0x28],rcx
  4091d3:	call   407020 <munmap@plt>
  4091d8:	mov    rcx,QWORD PTR [rsp+0x28]
  4091dd:	mov    rax,rcx
  4091e0:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  4091e6:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  4091ec:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  4091f2:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  4091f8:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  4091fe:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409207:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  409210:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409219:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  409222:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40922b:	add    rsp,0xd8
  409232:	pop    r13
  409234:	pop    r12
  409236:	pop    rdi
  409237:	pop    rsi
  409238:	ret
  409239:	add    BYTE PTR [rax],al
  40923b:	add    BYTE PTR [rax],al
  40923d:	add    BYTE PTR [rax],al
	...

0000000000409240 <__swc_fn_fc36583a_000111_f9e19033>:
  409240:	push   rbx
  409241:	push   r12
  409243:	push   rdi
  409244:	push   rsi
  409245:	sub    rsp,0xa8
  40924c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409252:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409258:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40925e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409264:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40926a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409270:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409276:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40927c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409285:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40928e:	mov    rbx,rdx
  409291:	mov    r12,rcx
  409294:	mov    rdi,rcx
  409297:	mov    rsi,rdx
  40929a:	mov    edx,0x3
  40929f:	xor    eax,eax
  4092a1:	call   407030 <mprotect@plt>
  4092a6:	test   eax,eax
  4092a8:	je     4092ae <__swc_fn_fc36583a_000111_f9e19033+0x6e>
  4092aa:	xor    eax,eax
  4092ac:	jmp    4092c3 <__swc_fn_fc36583a_000111_f9e19033+0x83>
  4092ae:	mov    rcx,r12
  4092b1:	mov    rdx,rbx
  4092b4:	mov    al,0x1
  4092b6:	mov    r8,rax
  4092b9:	call   410080 <__swc_fn_fc36583a_000110_918d5a21>
  4092be:	mov    eax,0x1
  4092c3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4092c9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4092cf:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4092d5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4092db:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4092e1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4092e7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4092ed:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4092f3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4092fc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409305:	add    rsp,0xa8
  40930c:	pop    rsi
  40930d:	pop    rdi
  40930e:	pop    r12
  409310:	pop    rbx
  409311:	ret
	...

0000000000409320 <__swc_fn_fc36583a_000114_cc486df9>:
  409320:	sub    rsp,0x8
  409324:	test   rcx,rcx
  409327:	jne    40932e <__swc_fn_fc36583a_000114_cc486df9+0xe>
  409329:	add    rsp,0x8
  40932d:	ret
  40932e:	call   40d040 <__swc_fn_fc36583a_000115_3f6af4b1>
  409333:	add    rsp,0x8
  409337:	ret
	...

0000000000409340 <__swc_fn_fc36583a_000117_5aba1420>:
  409340:	push   rdi
  409341:	push   rsi
  409342:	sub    rsp,0xa8
  409349:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40934f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409355:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40935b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409361:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409367:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40936d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409373:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409379:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409382:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40938b:	xor    edi,edi
  40938d:	xor    eax,eax
  40938f:	call   407040 <exit@plt>
  409394:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40939a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4093a0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4093a6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4093ac:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4093b2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4093b8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4093be:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4093c4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4093cd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4093d6:	add    rsp,0xa8
  4093dd:	pop    rsi
  4093de:	pop    rdi
  4093df:	ret

00000000004093e0 <__swc_fn_fc36583a_000120_1e032ef6>:
  4093e0:	push   rbx
  4093e1:	push   rsi
  4093e2:	push   rdi
  4093e3:	push   r12
  4093e5:	sub    rsp,0x18
  4093e9:	mov    rbx,r8
  4093ec:	mov    rsi,rcx
  4093ef:	mov    rdi,rdx
  4093f2:	mov    rcx,QWORD PTR [rip+0x1d947]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  4093f9:	test   rcx,rcx
  4093fc:	jne    40940e <__swc_fn_fc36583a_000120_1e032ef6+0x2e>
  4093fe:	call   40a1a0 <__swc_fn_fc36583a_000165_56054fe7>
  409403:	lea    rcx,[rax+0x1]
  409407:	mov    QWORD PTR [rip+0x1d932],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40940e:	dec    rcx
  409411:	call   411ee0 <__swc_fn_fc36583a_000167_39c041ad>
  409416:	mov    r12,rax
  409419:	cmp    ebx,0x3
  40941c:	jne    40942f <__swc_fn_fc36583a_000120_1e032ef6+0x4f>
  40941e:	mov    rax,QWORD PTR [r12+0xbd0]
  409426:	test   rax,rax
  409429:	jne    40956c <__swc_fn_fc36583a_000120_1e032ef6+0x18c>
  40942f:	cmp    ebx,0x5
  409432:	jne    409456 <__swc_fn_fc36583a_000120_1e032ef6+0x76>
  409434:	call   40c910 <__swc_fn_fc36583a_000091_f21926ed>
  409439:	test   al,al
  40943b:	jne    409456 <__swc_fn_fc36583a_000120_1e032ef6+0x76>
  40943d:	mov    rcx,rsi
  409440:	mov    rdx,rdi
  409443:	call   411e90 <__swc_fn_fc36583a_000164_d25850aa>
  409448:	test   al,al
  40944a:	je     409456 <__swc_fn_fc36583a_000120_1e032ef6+0x76>
  40944c:	add    rsp,0x18
  409450:	pop    r12
  409452:	pop    rdi
  409453:	pop    rsi
  409454:	pop    rbx
  409455:	ret
  409456:	call   40c910 <__swc_fn_fc36583a_000091_f21926ed>
  40945b:	test   al,al
  40945d:	jne    4094cf <__swc_fn_fc36583a_000120_1e032ef6+0xef>
  40945f:	vmovups xmm0,XMMWORD PTR [rsi]
  409463:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409469:	mov    rax,QWORD PTR [rsp+0x8]
  40946e:	test   rax,rax
  409471:	jne    4094c2 <__swc_fn_fc36583a_000120_1e032ef6+0xe2>
  409473:	cmp    ebx,0x3
  409476:	je     409484 <__swc_fn_fc36583a_000120_1e032ef6+0xa4>
  409478:	cmp    ebx,0x4
  40947b:	je     409494 <__swc_fn_fc36583a_000120_1e032ef6+0xb4>
  40947d:	cmp    ebx,0x5
  409480:	je     4094a4 <__swc_fn_fc36583a_000120_1e032ef6+0xc4>
  409482:	jmp    4094b4 <__swc_fn_fc36583a_000120_1e032ef6+0xd4>
  409484:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 4134e0 <__swc_rdata_base_fc36583a+0x3d0>
  40948c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409492:	jmp    4094c2 <__swc_fn_fc36583a_000120_1e032ef6+0xe2>
  409494:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 4134f0 <__swc_rdata_base_fc36583a+0x3e0>
  40949c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094a2:	jmp    4094c2 <__swc_fn_fc36583a_000120_1e032ef6+0xe2>
  4094a4:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 413500 <__swc_rdata_base_fc36583a+0x3f0>
  4094ac:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094b2:	jmp    4094c2 <__swc_fn_fc36583a_000120_1e032ef6+0xe2>
  4094b4:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 413510 <__swc_rdata_base_fc36583a+0x400>
  4094bc:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094c2:	lea    rcx,[rsp+0x8]
  4094c7:	mov    rdx,rdi
  4094ca:	call   40cb60 <__swc_fn_fc36583a_000103_0d4cc079>
  4094cf:	vmovups xmm0,XMMWORD PTR [rdi]
  4094d3:	vmovups XMMWORD PTR [r12+0x940],xmm0
  4094dd:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  4094e2:	vmovups XMMWORD PTR [r12+0x950],xmm0
  4094ec:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  4094f1:	vmovups XMMWORD PTR [r12+0x960],xmm0
  4094fb:	lea    rax,[r12+0x940]
  409503:	mov    QWORD PTR [r12+0x970],rax
  40950b:	mov    rax,QWORD PTR [rsi]
  40950e:	mov    QWORD PTR [r12+0x978],rax
  409516:	mov    rax,QWORD PTR [rsi+0x8]
  40951a:	mov    QWORD PTR [r12+0x980],rax
  409522:	movsxd rax,ebx
  409525:	mov    QWORD PTR [r12+0x988],rax
  40952d:	cmp    ebx,0x5
  409530:	je     409539 <__swc_fn_fc36583a_000120_1e032ef6+0x159>
  409532:	xor    ecx,ecx
  409534:	call   40a2d0 <__swc_fn_fc36583a_000174_02e645b4>
  409539:	mov    rbx,QWORD PTR [r12+0xbe8]
  409541:	test   rbx,rbx
  409544:	je     409555 <__swc_fn_fc36583a_000120_1e032ef6+0x175>
  409546:	mov    rcx,r12
  409549:	call   rbx
  40954b:	add    rsp,0x18
  40954f:	pop    r12
  409551:	pop    rdi
  409552:	pop    rsi
  409553:	pop    rbx
  409554:	ret
  409555:	mov    rcx,rsi
  409558:	call   410130 <__swc_fn_fc36583a_000116_3f5cfdef>
  40955d:	call   40d190 <__swc_fn_fc36583a_000118_591530fe>
  409562:	add    rsp,0x18
  409566:	pop    r12
  409568:	pop    rdi
  409569:	pop    rsi
  40956a:	pop    rbx
  40956b:	ret
  40956c:	mov    rcx,rsi
  40956f:	mov    rdx,rdi
  409572:	call   40cb60 <__swc_fn_fc36583a_000103_0d4cc079>
  409577:	jmp    40942f <__swc_fn_fc36583a_000120_1e032ef6+0x4f>
  40957c:	add    BYTE PTR [rax],al
	...

0000000000409580 <__swc_fn_fc36583a_000123_e4107ade>:
  409580:	push   rdi
  409581:	push   rsi
  409582:	sub    rsp,0xb8
  409589:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40958f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409595:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40959b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4095a1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4095a7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4095ad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4095b3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4095bc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4095c5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4095ce:	mov    DWORD PTR [rsp+0x8],0x0
  4095d6:	lea    rdi,[rsp+0x8]
  4095db:	xor    esi,esi
  4095dd:	xor    eax,eax
  4095df:	call   407050 <pthread_key_create@plt>
  4095e4:	test   eax,eax
  4095e6:	jne    4095ee <__swc_fn_fc36583a_000123_e4107ade+0x6e>
  4095e8:	mov    eax,DWORD PTR [rsp+0x8]
  4095ec:	jmp    4095f5 <__swc_fn_fc36583a_000123_e4107ade+0x75>
  4095ee:	mov    rax,0xffffffffffffffff
  4095f5:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4095fb:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409601:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409607:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40960d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409613:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409619:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40961f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409628:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409631:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40963a:	add    rsp,0xb8
  409641:	pop    rsi
  409642:	pop    rdi
  409643:	ret
	...

0000000000409650 <__swc_fn_fc36583a_000126_9e9697c7>:
  409650:	push   rdi
  409651:	push   rsi
  409652:	sub    rsp,0xb8
  409659:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40965f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409665:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40966b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409671:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409677:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40967d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409683:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40968c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409695:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40969e:	mov    DWORD PTR [rsp+0x8],0x0
  4096a6:	lea    rdi,[rsp+0x8]
  4096ab:	mov    rsi,rcx
  4096ae:	xor    eax,eax
  4096b0:	call   407050 <pthread_key_create@plt>
  4096b5:	test   eax,eax
  4096b7:	jne    4096c2 <__swc_fn_fc36583a_000126_9e9697c7+0x72>
  4096b9:	mov    eax,DWORD PTR [rsp+0x8]
  4096bd:	inc    rax
  4096c0:	jmp    4096c4 <__swc_fn_fc36583a_000126_9e9697c7+0x74>
  4096c2:	xor    eax,eax
  4096c4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4096ca:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4096d0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4096d6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4096dc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4096e2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4096e8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4096ee:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4096f7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409700:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409709:	add    rsp,0xb8
  409710:	pop    rsi
  409711:	pop    rdi
  409712:	ret
	...

0000000000409720 <__swc_fn_fc36583a_000129_bc477461>:
  409720:	push   rdi
  409721:	push   rsi
  409722:	sub    rsp,0xa8
  409729:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40972f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409735:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40973b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409741:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409747:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40974d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409753:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409759:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409762:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40976b:	test   rcx,rcx
  40976e:	setne  al
  409771:	je     40978a <__swc_fn_fc36583a_000129_bc477461+0x6a>
  409773:	lea    rax,[rcx-0x1]
  409777:	mov    eax,eax
  409779:	mov    edi,eax
  40977b:	mov    rsi,rdx
  40977e:	xor    eax,eax
  409780:	call   407060 <pthread_setspecific@plt>
  409785:	test   eax,eax
  409787:	sete   al
  40978a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409790:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409796:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40979c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4097a2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4097a8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4097ae:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4097b4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4097ba:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4097c3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4097cc:	add    rsp,0xa8
  4097d3:	pop    rsi
  4097d4:	pop    rdi
  4097d5:	ret
	...

00000000004097e0 <__swc_fn_fc36583a_000132_51cc49e7>:
  4097e0:	push   rdi
  4097e1:	push   rsi
  4097e2:	sub    rsp,0xa8
  4097e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4097ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4097f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4097fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409801:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409807:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40980d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409813:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409819:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409822:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40982b:	mov    rax,rdx
  40982e:	mov    QWORD PTR [rsp],0x0
  409836:	mov    edi,0xca
  40983b:	mov    rsi,rcx
  40983e:	mov    edx,0x81
  409843:	mov    eax,eax
  409845:	mov    ecx,eax
  409847:	xor    r8d,r8d
  40984a:	xor    r9d,r9d
  40984d:	xor    eax,eax
  40984f:	call   407070 <syscall@plt>
  409854:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40985a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409860:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409866:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40986c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409872:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409878:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40987e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409884:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40988d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409896:	add    rsp,0xa8
  40989d:	pop    rsi
  40989e:	pop    rdi
  40989f:	ret

00000000004098a0 <__swc_fn_fc36583a_000135_db32cc57>:
  4098a0:	sub    rsp,0x8
  4098a4:	call   40d530 <__swc_fn_fc36583a_000133_807fd51d>
  4098a9:	add    rsp,0x8
  4098ad:	ret
	...

00000000004098b0 <__swc_fn_fc36583a_000138_22d6573c>:
  4098b0:	push   rdi
  4098b1:	push   rsi
  4098b2:	sub    rsp,0xc8
  4098b9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4098bf:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4098c5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4098cb:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4098d1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4098d7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4098dd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  4098e6:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  4098ef:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  4098f8:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  409901:	vxorps xmm0,xmm0,xmm0
  409905:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40990b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409911:	mov    rdi,rcx
  409914:	lea    rsi,[rsp+0x8]
  409919:	xor    eax,eax
  40991b:	call   407080 <dladdr@plt>
  409920:	xor    ecx,ecx
  409922:	test   eax,eax
  409924:	je     40992b <__swc_fn_fc36583a_000138_22d6573c+0x7b>
  409926:	mov    rcx,QWORD PTR [rsp+0x10]
  40992b:	mov    rax,rcx
  40992e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  409934:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40993a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  409940:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  409946:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40994c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  409952:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40995b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  409964:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40996d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  409976:	add    rsp,0xc8
  40997d:	pop    rsi
  40997e:	pop    rdi
  40997f:	ret

0000000000409980 <__swc_fn_fc36583a_000141_5e493395>:
  409980:	push   rbx
  409981:	push   r12
  409983:	push   r13
  409985:	push   rdi
  409986:	push   rsi
  409987:	push   r14
  409989:	push   r15
  40998b:	sub    rsp,0x150
  409992:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40999b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  4099a4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  4099ad:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  4099b6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  4099bf:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4099c8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4099d1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4099da:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  4099e3:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  4099ec:	mov    rbx,rdx
  4099ef:	mov    QWORD PTR [rsp+0x98],rdx
  4099f7:	mov    r12,rcx
  4099fa:	mov    QWORD PTR [rsp+0xa0],rcx
  409a02:	mov    QWORD PTR [rbx],0x0
  409a09:	lea    r13,[rip+0x1d370]        # 426d80 <__swc_bss_base_fc36583a+0x2d40>
  409a10:	mov    rcx,r13
  409a13:	call   4098a0 <__swc_fn_fc36583a_000135_db32cc57>
  409a18:	mov    rax,QWORD PTR [rip+0x1d369]        # 426d88 <__swc_bss_base_fc36583a+0x2d48>
  409a1f:	test   rax,rax
  409a22:	je     409a59 <__swc_fn_fc36583a_000141_5e493395+0xd9>
  409a24:	cs nop WORD PTR [rax+rax*1+0x0]
  409a2e:	xchg   ax,ax
  409a30:	cmp    QWORD PTR [rax+0x8],r12
  409a34:	jne    409a51 <__swc_fn_fc36583a_000141_5e493395+0xd1>
  409a36:	mov    rcx,QWORD PTR [rax+0x18]
  409a3a:	mov    QWORD PTR [rbx],rcx
  409a3d:	mov    rbx,QWORD PTR [rax+0x10]
  409a41:	mov    rcx,r13
  409a44:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  409a49:	mov    rax,rbx
  409a4c:	jmp    409c3b <__swc_fn_fc36583a_000141_5e493395+0x2bb>
  409a51:	mov    rax,QWORD PTR [rax]
  409a54:	test   rax,rax
  409a57:	jne    409a30 <__swc_fn_fc36583a_000141_5e493395+0xb0>
  409a59:	vxorps xmm0,xmm0,xmm0
  409a5d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  409a63:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  409a69:	mov    rdi,r12
  409a6c:	lea    rsi,[rsp+0x10]
  409a71:	xor    eax,eax
  409a73:	call   407080 <dladdr@plt>
  409a78:	test   eax,eax
  409a7a:	sete   al
  409a7d:	je     409a8a <__swc_fn_fc36583a_000141_5e493395+0x10a>
  409a7f:	mov    rax,QWORD PTR [rsp+0x10]
  409a84:	test   rax,rax
  409a87:	sete   al
  409a8a:	test   al,al
  409a8c:	je     409a9d <__swc_fn_fc36583a_000141_5e493395+0x11d>
  409a8e:	mov    rcx,r13
  409a91:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  409a96:	xor    eax,eax
  409a98:	jmp    409c3b <__swc_fn_fc36583a_000141_5e493395+0x2bb>
  409a9d:	mov    rdi,QWORD PTR [rsp+0x10]
  409aa2:	mov    esi,0x80000
  409aa7:	xor    eax,eax
  409aa9:	call   407090 <open@plt>
  409aae:	lea    r14,[rsp+0x30]
  409ab3:	mov    DWORD PTR [rsp+0x30],eax
  409ab7:	cmp    DWORD PTR [r14],0x0
  409abb:	jge    409acc <__swc_fn_fc36583a_000141_5e493395+0x14c>
  409abd:	mov    rcx,r13
  409ac0:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  409ac5:	xor    eax,eax
  409ac7:	jmp    409c3b <__swc_fn_fc36583a_000141_5e493395+0x2bb>
  409acc:	mov    rax,r14
  409acf:	movsxd rdi,DWORD PTR [rax]
  409ad2:	xor    esi,esi
  409ad4:	mov    edx,0x2
  409ad9:	xor    eax,eax
  409adb:	call   4070a0 <lseek@plt>
  409ae0:	mov    r15,rax
  409ae3:	test   rax,rax
  409ae6:	jg     409b01 <__swc_fn_fc36583a_000141_5e493395+0x181>
  409ae8:	movsxd rdi,DWORD PTR [r14]
  409aeb:	xor    eax,eax
  409aed:	call   4070b0 <close@plt>
  409af2:	mov    rcx,r13
  409af5:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  409afa:	xor    eax,eax
  409afc:	jmp    409c3b <__swc_fn_fc36583a_000141_5e493395+0x2bb>
  409b01:	xor    edi,edi
  409b03:	mov    rsi,r15
  409b06:	mov    edx,0x1
  409b0b:	mov    ecx,0x2
  409b10:	mov    rax,r14
  409b13:	movsxd r8,DWORD PTR [rax]
  409b16:	xor    r9d,r9d
  409b19:	xor    eax,eax
  409b1b:	call   4070c0 <mmap@plt>
  409b20:	mov    rbx,rax
  409b23:	test   rax,rax
  409b26:	sete   al
  409b29:	cmp    rbx,0xffffffffffffffff
  409b2d:	sete   cl
  409b30:	or     al,cl
  409b32:	je     409b4d <__swc_fn_fc36583a_000141_5e493395+0x1cd>
  409b34:	movsxd rdi,DWORD PTR [r14]
  409b37:	xor    eax,eax
  409b39:	call   4070b0 <close@plt>
  409b3e:	mov    rcx,r13
  409b41:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  409b46:	xor    eax,eax
  409b48:	jmp    409c3b <__swc_fn_fc36583a_000141_5e493395+0x2bb>
  409b4d:	lea    rax,[rsp+0x50]
  409b52:	mov    QWORD PTR [rax],0x0
  409b59:	mov    rcx,rbx
  409b5c:	mov    rdx,r15
  409b5f:	mov    r8,rax
  409b62:	call   4106c0 <__swc_fn_fc36583a_000140_55003b6d>
  409b67:	mov    r12,rax
  409b6a:	test   rax,rax
  409b6d:	jne    409b95 <__swc_fn_fc36583a_000141_5e493395+0x215>
  409b6f:	mov    rdi,rbx
  409b72:	mov    rsi,r15
  409b75:	xor    eax,eax
  409b77:	call   407020 <munmap@plt>
  409b7c:	movsxd rdi,DWORD PTR [r14]
  409b7f:	xor    eax,eax
  409b81:	call   4070b0 <close@plt>
  409b86:	mov    rcx,r13
  409b89:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  409b8e:	xor    eax,eax
  409b90:	jmp    409c3b <__swc_fn_fc36583a_000141_5e493395+0x2bb>
  409b95:	mov    edi,0x20
  409b9a:	xor    eax,eax
  409b9c:	call   4070d0 <malloc@plt>
  409ba1:	test   rax,rax
  409ba4:	jne    409bc9 <__swc_fn_fc36583a_000141_5e493395+0x249>
  409ba6:	mov    rdi,rbx
  409ba9:	mov    rsi,r15
  409bac:	xor    eax,eax
  409bae:	call   407020 <munmap@plt>
  409bb3:	movsxd rdi,DWORD PTR [r14]
  409bb6:	xor    eax,eax
  409bb8:	call   4070b0 <close@plt>
  409bbd:	mov    rcx,r13
  409bc0:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  409bc5:	xor    eax,eax
  409bc7:	jmp    409c3b <__swc_fn_fc36583a_000141_5e493395+0x2bb>
  409bc9:	mov    rcx,QWORD PTR [rip+0x1d1b8]        # 426d88 <__swc_bss_base_fc36583a+0x2d48>
  409bd0:	mov    QWORD PTR [rsp+0x70],rcx
  409bd5:	mov    rcx,QWORD PTR [rsp+0xa0]
  409bdd:	mov    QWORD PTR [rsp+0x78],rcx
  409be2:	mov    QWORD PTR [rsp+0x80],r12
  409bea:	mov    rcx,QWORD PTR [rsp+0x50]
  409bef:	mov    QWORD PTR [rsp+0x88],rcx
  409bf7:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  409bfd:	vmovups XMMWORD PTR [rax],xmm0
  409c01:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  409c0a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  409c0f:	mov    QWORD PTR [rip+0x1d172],rax        # 426d88 <__swc_bss_base_fc36583a+0x2d48>
  409c16:	mov    rax,QWORD PTR [rsp+0x50]
  409c1b:	mov    rbx,QWORD PTR [rsp+0x98]
  409c23:	mov    QWORD PTR [rbx],rax
  409c26:	movsxd rdi,DWORD PTR [r14]
  409c29:	xor    eax,eax
  409c2b:	call   4070b0 <close@plt>
  409c30:	mov    rcx,r13
  409c33:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  409c38:	mov    rax,r12
  409c3b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  409c44:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  409c4d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  409c56:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  409c5f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  409c68:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  409c71:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  409c7a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  409c83:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  409c8c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  409c95:	add    rsp,0x150
  409c9c:	pop    r15
  409c9e:	pop    r14
  409ca0:	pop    rsi
  409ca1:	pop    rdi
  409ca2:	pop    r13
  409ca4:	pop    r12
  409ca6:	pop    rbx
  409ca7:	ret
	...

0000000000409cb0 <__swc_fn_fc36583a_000144_c3e86ca0>:
  409cb0:	push   rbx
  409cb1:	sub    rsp,0xe0
  409cb8:	lea    rbx,[rsp+0x8]
  409cbd:	vxorps xmm0,xmm0,xmm0
  409cc1:	vmovups YMMWORD PTR [rbx],ymm0
  409cc5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  409cca:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  409ccf:	vzeroupper
  409cd2:	mov    DWORD PTR [rbx+0x60],0x0
  409cd9:	mov    r8,rbx
  409cdc:	nop    DWORD PTR [rax+0x0]
  409ce0:	mov    r9,rcx
  409ce3:	movabs rcx,0xcccccccccccccccd
  409ced:	mov    rax,r9
  409cf0:	mul    rcx
  409cf3:	mov    r10,rdx
  409cf6:	shr    r10,0x3
  409cfa:	mov    rcx,r10
  409cfd:	imul   rdx,r10,0xa
  409d01:	sub    r9,rdx
  409d04:	mov    rdx,QWORD PTR [rip+0x9835]        # 413540 <__swc_rdata_base_fc36583a+0x430>
  409d0b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  409d10:	mov    BYTE PTR [r8],dl
  409d13:	lea    rdx,[r8+0x1]
  409d17:	mov    r8,rdx
  409d1a:	test   r10,r10
  409d1d:	jne    409ce0 <__swc_fn_fc36583a_000144_c3e86ca0+0x30>
  409d1f:	mov    BYTE PTR [rdx],0x0
  409d22:	sub    r8,0x1
  409d26:	mov    rax,rbx
  409d29:	cmp    rax,r8
  409d2c:	jae    409d46 <__swc_fn_fc36583a_000144_c3e86ca0+0x96>
  409d2e:	xchg   ax,ax
  409d30:	mov    cl,BYTE PTR [r8]
  409d33:	mov    dl,BYTE PTR [rax]
  409d35:	mov    BYTE PTR [r8],dl
  409d38:	sub    r8,0x1
  409d3c:	mov    BYTE PTR [rax],cl
  409d3e:	inc    rax
  409d41:	cmp    rax,r8
  409d44:	jb     409d30 <__swc_fn_fc36583a_000144_c3e86ca0+0x80>
  409d46:	xor    eax,eax
  409d48:	test   rbx,rbx
  409d4b:	je     409d6e <__swc_fn_fc36583a_000144_c3e86ca0+0xbe>
  409d4d:	mov    rcx,rbx
  409d50:	mov    dl,BYTE PTR [rcx]
  409d52:	test   dl,dl
  409d54:	je     409d6e <__swc_fn_fc36583a_000144_c3e86ca0+0xbe>
  409d56:	cs nop WORD PTR [rax+rax*1+0x0]
  409d60:	add    rcx,0x1
  409d64:	add    rax,0x1
  409d68:	mov    dl,BYTE PTR [rcx]
  409d6a:	test   dl,dl
  409d6c:	jne    409d60 <__swc_fn_fc36583a_000144_c3e86ca0+0xb0>
  409d6e:	mov    QWORD PTR [rbx+0xa8],rbx
  409d75:	mov    QWORD PTR [rbx+0xb0],rax
  409d7c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  409d84:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  409d8c:	lea    rcx,[rbx+0xb8]
  409d93:	call   410130 <__swc_fn_fc36583a_000116_3f5cfdef>
  409d98:	add    rsp,0xe0
  409d9f:	pop    rbx
  409da0:	ret
	...

0000000000409db0 <__swc_fn_fc36583a_000147_e7bfe29e>:
  409db0:	sub    rsp,0x8
  409db4:	mov    rax,QWORD PTR [rcx+0x8]
  409db8:	mov    r8,QWORD PTR [rdx+0x8]
  409dbc:	cmp    rax,r8
  409dbf:	je     409dc8 <__swc_fn_fc36583a_000147_e7bfe29e+0x18>
  409dc1:	xor    eax,eax
  409dc3:	add    rsp,0x8
  409dc7:	ret
  409dc8:	test   rax,rax
  409dcb:	jne    409ddc <__swc_fn_fc36583a_000147_e7bfe29e+0x2c>
  409dcd:	test   r8,r8
  409dd0:	jne    409ddc <__swc_fn_fc36583a_000147_e7bfe29e+0x2c>
  409dd2:	mov    eax,0x1
  409dd7:	add    rsp,0x8
  409ddb:	ret
  409ddc:	mov    rcx,QWORD PTR [rcx]
  409ddf:	mov    rdx,QWORD PTR [rdx]
  409de2:	test   rcx,rcx
  409de5:	sete   r8b
  409de9:	test   rdx,rdx
  409dec:	sete   r9b
  409df0:	or     r8b,r9b
  409df3:	je     409e00 <__swc_fn_fc36583a_000147_e7bfe29e+0x50>
  409df5:	cmp    rcx,rdx
  409df8:	sete   al
  409dfb:	add    rsp,0x8
  409dff:	ret
  409e00:	cmp    rcx,rdx
  409e03:	jne    409e0f <__swc_fn_fc36583a_000147_e7bfe29e+0x5f>
  409e05:	mov    eax,0x1
  409e0a:	add    rsp,0x8
  409e0e:	ret
  409e0f:	mov    r8,rax
  409e12:	call   40cc20 <__swc_fn_fc36583a_000106_aba05410>
  409e17:	test   eax,eax
  409e19:	sete   al
  409e1c:	add    rsp,0x8
  409e20:	ret
	...

0000000000409e30 <__swc_fn_fc36583a_000150_365b4daf>:
  409e30:	vxorps xmm0,xmm0,xmm0
  409e34:	vmovups XMMWORD PTR [rcx],xmm0
  409e38:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e3d:	vxorps xmm0,xmm0,xmm0
  409e41:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e46:	vmovups xmm0,XMMWORD PTR [rip+0x97aa]        # 4135f8 <__swc_rdata_base_fc36583a+0x4e8>
  409e4e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e53:	ret
	...

0000000000409e60 <__swc_fn_fc36583a_000153_365b4daf>:
  409e60:	vxorps xmm0,xmm0,xmm0
  409e64:	vmovups XMMWORD PTR [rcx],xmm0
  409e68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e6d:	vxorps xmm0,xmm0,xmm0
  409e71:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e76:	vmovups xmm0,XMMWORD PTR [rip+0x989a]        # 413718 <__swc_rdata_base_fc36583a+0x608>
  409e7e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e83:	mov    QWORD PTR [rcx+0x40],0x0
  409e8b:	ret
  409e8c:	add    BYTE PTR [rax],al
	...

0000000000409e90 <__swc_fn_fc36583a_000156_9e2052d6>:
  409e90:	push   rbx
  409e91:	sub    rsp,0x70
  409e95:	mov    rax,QWORD PTR [rcx]
  409e98:	mov    rbx,QWORD PTR [rcx+0x8]
  409e9c:	vxorps xmm0,xmm0,xmm0
  409ea0:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  409ea6:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  409eac:	vzeroupper
  409eaf:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  409eb5:	mov    QWORD PTR [rsp+0x48],rdx
  409eba:	mov    QWORD PTR [rsp+0x50],r8
  409ebf:	mov    rcx,rax
  409ec2:	lea    rdx,[rsp+0x8]
  409ec7:	mov    rbx,QWORD PTR [rbx+0x18]
  409ecb:	call   rbx
  409ecd:	add    rsp,0x70
  409ed1:	pop    rbx
  409ed2:	ret
	...

0000000000409ee0 <__swc_fn_fc36583a_000159_6861d596>:
  409ee0:	push   rbx
  409ee1:	push   rsi
  409ee2:	push   rdi
  409ee3:	mov    rbx,r8
  409ee6:	mov    rsi,rcx
  409ee9:	mov    rdi,rdx
  409eec:	call   40d930 <__swc_fn_fc36583a_000157_3495a3ca>
  409ef1:	vmovups xmm0,XMMWORD PTR [rbx]
  409ef5:	vmovups XMMWORD PTR [rsi],xmm0
  409ef9:	mov    QWORD PTR [rsi+0x18],rdi
  409efd:	pop    rdi
  409efe:	pop    rsi
  409eff:	pop    rbx
  409f00:	ret
	...

0000000000409f10 <__swc_fn_fc36583a_000162_61e293bf>:
  409f10:	push   rbx
  409f11:	push   rsi
  409f12:	push   rdi
  409f13:	push   r12
  409f15:	push   r13
  409f17:	sub    rsp,0x50
  409f1b:	mov    rbx,rcx
  409f1e:	mov    rsi,rdx
  409f21:	vmovups xmm0,XMMWORD PTR [rip+0x98ff]        # 413828 <__swc_rdata_base_fc36583a+0x718>
  409f29:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409f2f:	vmovups xmm0,XMMWORD PTR [rip+0x9901]        # 413838 <__swc_rdata_base_fc36583a+0x728>
  409f37:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409f3d:	vxorps xmm0,xmm0,xmm0
  409f41:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409f47:	mov    rcx,rdx
  409f4a:	call   4098b0 <__swc_fn_fc36583a_000138_22d6573c>
  409f4f:	mov    rdi,rax
  409f52:	test   rax,rax
  409f55:	jne    409f86 <__swc_fn_fc36583a_000162_61e293bf+0x76>
  409f57:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409f5d:	vmovups XMMWORD PTR [rbx],xmm0
  409f61:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409f67:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409f6c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409f72:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409f77:	mov    rax,rbx
  409f7a:	add    rsp,0x50
  409f7e:	pop    r13
  409f80:	pop    r12
  409f82:	pop    rdi
  409f83:	pop    rsi
  409f84:	pop    rbx
  409f85:	ret
  409f86:	mov    rcx,rdi
  409f89:	call   411be0 <__swc_fn_fc36583a_000161_b553c03d>
  409f8e:	mov    r11,rax
  409f91:	test   rax,rax
  409f94:	je     409f9e <__swc_fn_fc36583a_000162_61e293bf+0x8e>
  409f96:	mov    al,BYTE PTR [r11+0x24]
  409f9a:	test   al,al
  409f9c:	jne    409fcd <__swc_fn_fc36583a_000162_61e293bf+0xbd>
  409f9e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fa4:	vmovups XMMWORD PTR [rbx],xmm0
  409fa8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fae:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fb3:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fb9:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fbe:	mov    rax,rbx
  409fc1:	add    rsp,0x50
  409fc5:	pop    r13
  409fc7:	pop    r12
  409fc9:	pop    rdi
  409fca:	pop    rsi
  409fcb:	pop    rbx
  409fcc:	ret
  409fcd:	sub    rsi,rdi
  409fd0:	mov    eax,0xffffffff
  409fd5:	cmp    rsi,rax
  409fd8:	jbe    40a009 <__swc_fn_fc36583a_000162_61e293bf+0xf9>
  409fda:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fe0:	vmovups XMMWORD PTR [rbx],xmm0
  409fe4:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fea:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fef:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409ff5:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409ffa:	mov    rax,rbx
  409ffd:	add    rsp,0x50
  40a001:	pop    r13
  40a003:	pop    r12
  40a005:	pop    rdi
  40a006:	pop    rsi
  40a007:	pop    rbx
  40a008:	ret
  40a009:	mov    rdi,QWORD PTR [r11+0x10]
  40a00d:	mov    eax,DWORD PTR [r11+0x20]
  40a011:	xor    ecx,ecx
  40a013:	test   rax,rax
  40a016:	jbe    40a168 <__swc_fn_fc36583a_000162_61e293bf+0x258>
  40a01c:	nop    DWORD PTR [rax+0x0]
  40a020:	mov    edx,ecx
  40a022:	imul   r12,rdx,0x14
  40a026:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40a02b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40a030:	mov    r9d,esi
  40a033:	cmp    r9,rdx
  40a036:	jb     40a15b <__swc_fn_fc36583a_000162_61e293bf+0x24b>
  40a03c:	add    rdx,r8
  40a03f:	mov    r8d,esi
  40a042:	cmp    r8,rdx
  40a045:	jae    40a15b <__swc_fn_fc36583a_000162_61e293bf+0x24b>
  40a04b:	lea    rsi,[rsp+0x38]
  40a050:	mov    eax,DWORD PTR [rdi+0xc]
  40a053:	mov    DWORD PTR [rsp+0x38],eax
  40a057:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40a05c:	mov    rcx,rdi
  40a05f:	mov    rdx,QWORD PTR [r11+0x18]
  40a063:	mov    r8,rsi
  40a066:	mov    r8d,DWORD PTR [r8]
  40a069:	mov    r9,rax
  40a06c:	lea    r10,[rsp+0x10]
  40a071:	call   40d980 <__swc_fn_fc36583a_000160_dfca9093>
  40a076:	test   al,al
  40a078:	jne    40a0ab <__swc_fn_fc36583a_000162_61e293bf+0x19b>
  40a07a:	vmovups xmm0,XMMWORD PTR [rip+0x97d6]        # 413858 <__swc_rdata_base_fc36583a+0x748>
  40a082:	vmovups XMMWORD PTR [rbx],xmm0
  40a086:	vmovups xmm0,XMMWORD PTR [rip+0x97da]        # 413868 <__swc_rdata_base_fc36583a+0x758>
  40a08e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a093:	vxorps xmm0,xmm0,xmm0
  40a097:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a09c:	mov    rax,rbx
  40a09f:	add    rsp,0x50
  40a0a3:	pop    r13
  40a0a5:	pop    r12
  40a0a7:	pop    rdi
  40a0a8:	pop    rsi
  40a0a9:	pop    rbx
  40a0aa:	ret
  40a0ab:	lea    r13,[rsp+0x3c]
  40a0b0:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40a0b5:	mov    DWORD PTR [rsp+0x3c],eax
  40a0b9:	test   eax,eax
  40a0bb:	je     40a10c <__swc_fn_fc36583a_000162_61e293bf+0x1fc>
  40a0bd:	mov    rcx,rdi
  40a0c0:	mov    rdx,QWORD PTR [r11+0x18]
  40a0c4:	mov    r8d,DWORD PTR [rsi]
  40a0c7:	mov    rax,r13
  40a0ca:	mov    r9d,DWORD PTR [rax]
  40a0cd:	lea    r10,[rsp+0x20]
  40a0d2:	call   40d980 <__swc_fn_fc36583a_000160_dfca9093>
  40a0d7:	test   al,al
  40a0d9:	jne    40a10c <__swc_fn_fc36583a_000162_61e293bf+0x1fc>
  40a0db:	vmovups xmm0,XMMWORD PTR [rip+0x97a5]        # 413888 <__swc_rdata_base_fc36583a+0x778>
  40a0e3:	vmovups XMMWORD PTR [rbx],xmm0
  40a0e7:	vmovups xmm0,XMMWORD PTR [rip+0x97a9]        # 413898 <__swc_rdata_base_fc36583a+0x788>
  40a0ef:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a0f4:	vxorps xmm0,xmm0,xmm0
  40a0f8:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a0fd:	mov    rax,rbx
  40a100:	add    rsp,0x50
  40a104:	pop    r13
  40a106:	pop    r12
  40a108:	pop    rdi
  40a109:	pop    rsi
  40a10a:	pop    rbx
  40a10b:	ret
  40a10c:	mov    eax,0x1
  40a111:	rex mov BYTE PTR [rsp+0x8],al
  40a116:	cmp    DWORD PTR [r13+0x0],0x0
  40a11b:	je     40a12c <__swc_fn_fc36583a_000162_61e293bf+0x21c>
  40a11d:	rex mov BYTE PTR [rsp+0x9],0x1
  40a123:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40a128:	mov    DWORD PTR [rsp+0x30],eax
  40a12c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a132:	vmovups XMMWORD PTR [rbx],xmm0
  40a136:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a13c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a141:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a147:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a14c:	mov    rax,rbx
  40a14f:	add    rsp,0x50
  40a153:	pop    r13
  40a155:	pop    r12
  40a157:	pop    rdi
  40a158:	pop    rsi
  40a159:	pop    rbx
  40a15a:	ret
  40a15b:	add    rcx,0x1
  40a15f:	cmp    rcx,rax
  40a162:	jb     40a020 <__swc_fn_fc36583a_000162_61e293bf+0x110>
  40a168:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a16e:	vmovups XMMWORD PTR [rbx],xmm0
  40a172:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a178:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a17d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a183:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a188:	mov    rax,rbx
  40a18b:	add    rsp,0x50
  40a18f:	pop    r13
  40a191:	pop    r12
  40a193:	pop    rdi
  40a194:	pop    rsi
  40a195:	pop    rbx
  40a196:	ret
	...

000000000040a1a0 <__swc_fn_fc36583a_000165_56054fe7>:
  40a1a0:	sub    rsp,0x48
  40a1a4:	call   409580 <__swc_fn_fc36583a_000123_e4107ade>
  40a1a9:	cmp    rax,0xffffffffffffffff
  40a1ad:	je     40a1b4 <__swc_fn_fc36583a_000165_56054fe7+0x14>
  40a1af:	add    rsp,0x48
  40a1b3:	ret
  40a1b4:	lea    rcx,[rip+0x970d]        # 4138c8 <__swc_rdata_base_fc36583a+0x7b8>
  40a1bb:	vmovups xmm0,XMMWORD PTR [rip+0x9715]        # 4138d8 <__swc_rdata_base_fc36583a+0x7c8>
  40a1c3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a1c9:	vmovups xmm0,XMMWORD PTR [rip+0x9717]        # 4138e8 <__swc_rdata_base_fc36583a+0x7d8>
  40a1d1:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a1d7:	vmovups xmm0,XMMWORD PTR [rip+0x9719]        # 4138f8 <__swc_rdata_base_fc36583a+0x7e8>
  40a1df:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a1e5:	lea    rdx,[rsp+0x8]
  40a1ea:	mov    QWORD PTR [rsp+0x38],rax
  40a1ef:	call   40cb60 <__swc_fn_fc36583a_000103_0d4cc079>
  40a1f4:	mov    rax,QWORD PTR [rsp+0x38]
  40a1f9:	jmp    40a1af <__swc_fn_fc36583a_000165_56054fe7+0xf>
  40a1fb:	add    BYTE PTR [rax],al
  40a1fd:	add    BYTE PTR [rax],al
	...

000000000040a200 <__swc_fn_fc36583a_000168_0ad81c51>:
  40a200:	push   rbx
  40a201:	push   rsi
  40a202:	sub    rsp,0x28
  40a206:	mov    rbx,rcx
  40a209:	mov    DWORD PTR [rsp+0x8],0xbf0
  40a211:	mov    ecx,0xbf0
  40a216:	call   40c750 <__swc_fn_fc36583a_000079_633af784>
  40a21b:	mov    rsi,rax
  40a21e:	test   rax,rax
  40a221:	jne    40a22c <__swc_fn_fc36583a_000168_0ad81c51+0x2c>
  40a223:	xor    eax,eax
  40a225:	add    rsp,0x28
  40a229:	pop    rsi
  40a22a:	pop    rbx
  40a22b:	ret
  40a22c:	vxorps xmm0,xmm0,xmm0
  40a230:	xor    eax,eax
  40a232:	cs nop WORD PTR [rax+rax*1+0x0]
  40a23c:	nop    DWORD PTR [rax+0x0]
  40a240:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40a245:	add    rax,0x10
  40a249:	cmp    rax,0xbf0
  40a250:	jne    40a240 <__swc_fn_fc36583a_000168_0ad81c51+0x40>
  40a252:	lea    rax,[rbx+0x1]
  40a256:	mov    QWORD PTR [rsi+0x9c0],rax
  40a25d:	mov    rcx,rbx
  40a260:	mov    rdx,rsi
  40a263:	call   40dce0 <__swc_fn_fc36583a_000166_c370e18e>
  40a268:	test   al,al
  40a26a:	jne    40a27d <__swc_fn_fc36583a_000168_0ad81c51+0x7d>
  40a26c:	mov    rcx,rsi
  40a26f:	call   40f0b0 <__swc_fn_fc36583a_000080_207908fe>
  40a274:	xor    eax,eax
  40a276:	add    rsp,0x28
  40a27a:	pop    rsi
  40a27b:	pop    rbx
  40a27c:	ret
  40a27d:	lea    rcx,[rsp+0x18]
  40a282:	call   40f630 <__swc_fn_fc36583a_000092_809deff5>
  40a287:	mov    rax,rsi
  40a28a:	add    rsp,0x28
  40a28e:	pop    rsi
  40a28f:	pop    rbx
  40a290:	ret
	...

000000000040a2a0 <__swc_fn_fc36583a_000171_8c19aea5>:
  40a2a0:	xor    eax,eax
  40a2a2:	mov    edx,0x1
  40a2a7:	lock cmpxchg QWORD PTR [rcx],rdx
  40a2ac:	test   rax,rax
  40a2af:	jne    40a2b2 <__swc_fn_fc36583a_000171_8c19aea5+0x12>
  40a2b1:	ret
  40a2b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2bc:	nop    DWORD PTR [rax+0x0]
  40a2c0:	mov    rax,QWORD PTR [rcx]
  40a2c3:	test   rax,rax
  40a2c6:	je     40a2a0 <__swc_fn_fc36583a_000171_8c19aea5>
  40a2c8:	jmp    40a2c0 <__swc_fn_fc36583a_000171_8c19aea5+0x20>
  40a2ca:	add    BYTE PTR [rax],al
  40a2cc:	add    BYTE PTR [rax],al
	...

000000000040a2d0 <__swc_fn_fc36583a_000174_02e645b4>:
  40a2d0:	push   rsi
  40a2d1:	push   rdi
  40a2d2:	sub    rsp,0x38
  40a2d6:	mov    rsi,rcx
  40a2d9:	call   40dcf0 <__swc_fn_fc36583a_000169_4694b8ad>
  40a2de:	mov    rdi,rax
  40a2e1:	call   40d480 <__swc_fn_fc36583a_000130_375c7357>
  40a2e6:	mov    r8,rax
  40a2e9:	mov    rcx,rdi
  40a2ec:	call   40a2a0 <__swc_fn_fc36583a_000171_8c19aea5>
  40a2f1:	mov    rax,QWORD PTR [rdi+0x8]
  40a2f5:	test   rax,rax
  40a2f8:	je     40a335 <__swc_fn_fc36583a_000174_02e645b4+0x65>
  40a2fa:	nop    WORD PTR [rax+rax*1+0x0]
  40a300:	cmp    rax,rsi
  40a303:	je     40a335 <__swc_fn_fc36583a_000174_02e645b4+0x65>
  40a305:	mov    r9,QWORD PTR [rax]
  40a308:	cmp    QWORD PTR [rax+0x20],r8
  40a30c:	jne    40a32d <__swc_fn_fc36583a_000174_02e645b4+0x5d>
  40a30e:	mov    rcx,rdi
  40a311:	mov    rdx,rax
  40a314:	mov    QWORD PTR [rsp+0x28],r8
  40a319:	mov    QWORD PTR [rsp+0x30],r9
  40a31e:	call   412000 <__swc_fn_fc36583a_000173_e17a224b>
  40a323:	mov    r8,QWORD PTR [rsp+0x28]
  40a328:	mov    r9,QWORD PTR [rsp+0x30]
  40a32d:	mov    rax,r9
  40a330:	test   r9,r9
  40a333:	jne    40a300 <__swc_fn_fc36583a_000174_02e645b4+0x30>
  40a335:	xor    eax,eax
  40a337:	mov    QWORD PTR [rdi],rax
  40a33a:	add    rsp,0x38
  40a33e:	pop    rdi
  40a33f:	pop    rsi
  40a340:	ret
	...

000000000040a360 <__swc_fn_fc36583a_000177_aa67484d>:
  40a360:	push   rbp
  40a361:	push   rbx
  40a362:	push   r15
  40a364:	push   rsi
  40a365:	push   rdi
  40a366:	push   r12
  40a368:	push   r14
  40a36a:	push   r13
  40a36c:	sub    rsp,0x10
  40a370:	mov    rbp,rsp
  40a373:	vmovups XMMWORD PTR [rsp],xmm6
  40a378:	sub    rsp,0x610
  40a37f:	mov    rbx,rsp
  40a382:	mov    ecx,0x17700
  40a387:	sub    rsp,0x8
  40a38b:	call   40ddf0 <__swc_fn_fc36583a_000175_2744b483>
  40a390:	add    rsp,0x8
  40a394:	mov    QWORD PTR [rip+0x1ca15],rax        # 426db0 <__swc_bss_base_fc36583a+0x2d70>
  40a39b:	mov    ecx,0xbb80
  40a3a0:	sub    rsp,0x8
  40a3a4:	call   40ddf0 <__swc_fn_fc36583a_000175_2744b483>
  40a3a9:	add    rsp,0x8
  40a3ad:	mov    QWORD PTR [rip+0x1ca04],rax        # 426db8 <__swc_bss_base_fc36583a+0x2d78>
  40a3b4:	mov    ecx,0xbb80
  40a3b9:	sub    rsp,0x8
  40a3bd:	call   40ddf0 <__swc_fn_fc36583a_000175_2744b483>
  40a3c2:	add    rsp,0x8
  40a3c6:	mov    QWORD PTR [rip+0x1c9f3],rax        # 426dc0 <__swc_bss_base_fc36583a+0x2d80>
  40a3cd:	xor    ecx,ecx
  40a3cf:	xor    r8d,r8d
  40a3d2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a3dc:	cs nop WORD PTR [rax+rax*1+0x0]
  40a3e6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a3f0:	lea    r9,[r8+0x1]
  40a3f4:	mov    r10,r9
  40a3f7:	movabs rdx,0x2492492492492493
  40a401:	mov    r15,rax
  40a404:	mov    rax,r8
  40a407:	mul    rdx
  40a40a:	mov    r11,rdx
  40a40d:	mov    rax,r15
  40a410:	mov    rdx,r8
  40a413:	sub    rdx,r11
  40a416:	shr    rdx,1
  40a419:	add    rdx,r11
  40a41c:	shr    rdx,0x2
  40a420:	imul   r11,rdx,0x7
  40a424:	mov    rdx,r8
  40a427:	sub    rdx,r11
  40a42a:	lea    r11,[rdx+0x4]
  40a42e:	mov    rdx,QWORD PTR [rip+0x1c983]        # 426db8 <__swc_bss_base_fc36583a+0x2d78>
  40a435:	mov    QWORD PTR [rdx+r8*8],rcx
  40a439:	mov    rdx,QWORD PTR [rip+0x1c980]        # 426dc0 <__swc_bss_base_fc36583a+0x2d80>
  40a440:	mov    QWORD PTR [rdx+r8*8],r11
  40a444:	xor    r8d,r8d
  40a447:	test   r11,r11
  40a44a:	jbe    40a4b4 <__swc_fn_fc36583a_000177_aa67484d+0x154>
  40a450:	xor    esi,esi
  40a452:	mov    rdi,QWORD PTR [rip+0x1c957]        # 426db0 <__swc_bss_base_fc36583a+0x2d70>
  40a459:	cs nop WORD PTR [rax+rax*1+0x0]
  40a463:	cs nop WORD PTR [rax+rax*1+0x0]
  40a46d:	nop    DWORD PTR [rax]
  40a470:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40a47a:	mov    r15,rax
  40a47d:	mov    rax,r10
  40a480:	mul    rdx
  40a483:	mov    r12,rdx
  40a486:	mov    rax,r15
  40a489:	shr    r12,0x3
  40a48d:	imul   r12,r12,0x1a
  40a491:	sub    r10,r12
  40a494:	lea    r10,[r10+0x61]
  40a498:	mov    BYTE PTR [rdi+rcx*1],r10b
  40a49c:	inc    rcx
  40a49f:	shr    rdx,0x3
  40a4a3:	lea    r10,[rdx+rsi*1]
  40a4a7:	add    r8,0x1
  40a4ab:	add    rsi,0x7
  40a4af:	cmp    r8,r11
  40a4b2:	jb     40a470 <__swc_fn_fc36583a_000177_aa67484d+0x110>
  40a4b4:	mov    r8,r9
  40a4b7:	cmp    r9,0x1770
  40a4be:	jb     40a3f0 <__swc_fn_fc36583a_000177_aa67484d+0x90>
  40a4c4:	mov    ecx,0x500
  40a4c9:	sub    rsp,0x8
  40a4cd:	call   40ddf0 <__swc_fn_fc36583a_000175_2744b483>
  40a4d2:	add    rsp,0x8
  40a4d6:	mov    QWORD PTR [rip+0x1c8eb],rax        # 426dc8 <__swc_bss_base_fc36583a+0x2d88>
  40a4dd:	mov    ecx,0x140
  40a4e2:	sub    rsp,0x8
  40a4e6:	call   40ddf0 <__swc_fn_fc36583a_000175_2744b483>
  40a4eb:	add    rsp,0x8
  40a4ef:	mov    QWORD PTR [rip+0x1c8da],rax        # 426dd0 <__swc_bss_base_fc36583a+0x2d90>
  40a4f6:	mov    ecx,0x140
  40a4fb:	sub    rsp,0x8
  40a4ff:	call   40ddf0 <__swc_fn_fc36583a_000175_2744b483>
  40a504:	add    rsp,0x8
  40a508:	mov    QWORD PTR [rip+0x1c8c9],rax        # 426dd8 <__swc_bss_base_fc36583a+0x2d98>
  40a50f:	xor    ecx,ecx
  40a511:	xor    r8d,r8d
  40a514:	lea    r9,[rbx+0x68]
  40a518:	vxorps xmm0,xmm0,xmm0
  40a51c:	cs nop WORD PTR [rax+rax*1+0x0]
  40a526:	cs nop WORD PTR [rax+rax*1+0x0]
  40a530:	vmovups XMMWORD PTR [rbx+0x68],xmm0
  40a535:	vmovups XMMWORD PTR [rbx+0x78],xmm0
  40a53a:	mov    r10,QWORD PTR [rip+0x17acf]        # 422010 <__swc_data_base_fc36583a+0x10>
  40a541:	imul   r10,r10,0x41a7
  40a548:	movabs rdx,0x200000005
  40a552:	mov    r15,rax
  40a555:	mov    rax,r10
  40a558:	mul    rdx
  40a55b:	mov    r11,rdx
  40a55e:	mov    rdx,r10
  40a561:	sub    rdx,r11
  40a564:	shr    rdx,1
  40a567:	add    rdx,r11
  40a56a:	shr    rdx,0x1e
  40a56e:	imul   r11,rdx,0x7fffffff
  40a575:	sub    r10,r11
  40a578:	mov    QWORD PTR [rip+0x17a91],r10        # 422010 <__swc_data_base_fc36583a+0x10>
  40a57f:	movabs rdx,0xaec33e1f671529a5
  40a589:	mov    rax,r10
  40a58c:	mul    rdx
  40a58f:	mov    rax,r15
  40a592:	shr    rdx,0xc
  40a596:	imul   rdx,rdx,0x1770
  40a59d:	sub    r10,rdx
  40a5a0:	mov    rdx,QWORD PTR [rip+0x1c819]        # 426dc0 <__swc_bss_base_fc36583a+0x2d80>
  40a5a7:	mov    rdx,QWORD PTR [rdx+r10*8]
  40a5ab:	mov    r11,rdx
  40a5ae:	xor    esi,esi
  40a5b0:	test   rdx,rdx
  40a5b3:	jbe    40a5e8 <__swc_fn_fc36583a_000177_aa67484d+0x288>
  40a5b5:	mov    rdi,QWORD PTR [rip+0x1c7fc]        # 426db8 <__swc_bss_base_fc36583a+0x2d78>
  40a5bc:	mov    r12,QWORD PTR [rip+0x1c7ed]        # 426db0 <__swc_bss_base_fc36583a+0x2d70>
  40a5c3:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5cd:	nop    DWORD PTR [rax]
  40a5d0:	mov    r13,QWORD PTR [rdi+r10*8]
  40a5d4:	add    r13,rsi
  40a5d7:	mov    r13b,BYTE PTR [r12+r13*1]
  40a5db:	mov    BYTE PTR [r9+rsi*1],r13b
  40a5df:	add    rsi,0x1
  40a5e3:	cmp    rsi,rdx
  40a5e6:	jb     40a5d0 <__swc_fn_fc36583a_000177_aa67484d+0x270>
  40a5e8:	xor    r10d,r10d
  40a5eb:	nop    DWORD PTR [rax+rax*1+0x0]
  40a5f0:	mov    rsi,QWORD PTR [rip+0x17a19]        # 422010 <__swc_data_base_fc36583a+0x10>
  40a5f7:	imul   rsi,rsi,0x41a7
  40a5fe:	movabs r12,0x200000005
  40a608:	mov    r14,rax
  40a60b:	mov    rax,rsi
  40a60e:	mul    r12
  40a611:	mov    r12,rsi
  40a614:	sub    r12,rdx
  40a617:	shr    r12,1
  40a61a:	add    r12,rdx
  40a61d:	shr    r12,0x1e
  40a621:	imul   rdi,r12,0x7fffffff
  40a628:	sub    rsi,rdi
  40a62b:	mov    QWORD PTR [rip+0x179de],rsi        # 422010 <__swc_data_base_fc36583a+0x10>
  40a632:	mov    rax,rsi
  40a635:	xor    edx,edx
  40a637:	div    r11
  40a63a:	mov    rax,rdx
  40a63d:	mov    r12,rax
  40a640:	imul   rsi,rsi,0x41a7
  40a647:	movabs rdx,0x200000005
  40a651:	mov    r15,r14
  40a654:	mov    rax,rsi
  40a657:	mul    rdx
  40a65a:	mov    rdi,rdx
  40a65d:	mov    rdx,rsi
  40a660:	sub    rdx,rdi
  40a663:	shr    rdx,1
  40a666:	add    rdx,rdi
  40a669:	shr    rdx,0x1e
  40a66d:	imul   rdi,rdx,0x7fffffff
  40a674:	sub    rsi,rdi
  40a677:	mov    QWORD PTR [rip+0x17992],rsi        # 422010 <__swc_data_base_fc36583a+0x10>
  40a67e:	movabs rdx,0xaaaaaaaaaaaaaaab
  40a688:	mov    rax,rsi
  40a68b:	mul    rdx
  40a68e:	shr    rdx,1
  40a691:	lea    rdx,[rdx+rdx*2]
  40a695:	mov    r13,rsi
  40a698:	sub    r13,rdx
  40a69b:	imul   rsi,rsi,0x41a7
  40a6a2:	movabs rdx,0x200000005
  40a6ac:	mov    rax,rsi
  40a6af:	mul    rdx
  40a6b2:	mov    rdi,rdx
  40a6b5:	mov    rdx,rsi
  40a6b8:	sub    rdx,rdi
  40a6bb:	shr    rdx,1
  40a6be:	add    rdx,rdi
  40a6c1:	shr    rdx,0x1e
  40a6c5:	imul   rdi,rdx,0x7fffffff
  40a6cc:	sub    rsi,rdi
  40a6cf:	mov    QWORD PTR [rip+0x1793a],rsi        # 422010 <__swc_data_base_fc36583a+0x10>
  40a6d6:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40a6e0:	mov    rax,rsi
  40a6e3:	mul    rdx
  40a6e6:	mov    rax,r15
  40a6e9:	shr    rdx,0x3
  40a6ed:	imul   rdx,rdx,0x1a
  40a6f1:	sub    rsi,rdx
  40a6f4:	lea    rdx,[rsi+0x61]
  40a6f8:	test   r13,r13
  40a6fb:	jne    40a706 <__swc_fn_fc36583a_000177_aa67484d+0x3a6>
  40a6fd:	mov    BYTE PTR [r9+r12*1],dl
  40a701:	jmp    40a779 <__swc_fn_fc36583a_000177_aa67484d+0x419>
  40a706:	cmp    r13,0x1
  40a70a:	jne    40a73a <__swc_fn_fc36583a_000177_aa67484d+0x3da>
  40a70c:	cmp    r11,0x2
  40a710:	jbe    40a779 <__swc_fn_fc36583a_000177_aa67484d+0x419>
  40a716:	lea    rdx,[r12+0x1]
  40a71b:	cmp    rdx,r11
  40a71e:	jae    40a734 <__swc_fn_fc36583a_000177_aa67484d+0x3d4>
  40a720:	mov    sil,BYTE PTR [r9+r12*1+0x1]
  40a725:	mov    BYTE PTR [r9+r12*1],sil
  40a729:	mov    r12,rdx
  40a72c:	inc    rdx
  40a72f:	cmp    rdx,r11
  40a732:	jb     40a720 <__swc_fn_fc36583a_000177_aa67484d+0x3c0>
  40a734:	sub    r11,0x1
  40a738:	jmp    40a779 <__swc_fn_fc36583a_000177_aa67484d+0x419>
  40a73a:	mov    rsi,r11
  40a73d:	cmp    rsi,r12
  40a740:	jbe    40a771 <__swc_fn_fc36583a_000177_aa67484d+0x411>
  40a742:	cs nop WORD PTR [rax+rax*1+0x0]
  40a74c:	cs nop WORD PTR [rax+rax*1+0x0]
  40a756:	cs nop WORD PTR [rax+rax*1+0x0]
  40a760:	mov    dil,BYTE PTR [r9+rsi*1-0x1]
  40a765:	mov    BYTE PTR [r9+rsi*1],dil
  40a769:	dec    rsi
  40a76c:	cmp    rsi,r12
  40a76f:	ja     40a760 <__swc_fn_fc36583a_000177_aa67484d+0x400>
  40a771:	mov    BYTE PTR [r9+r12*1],dl
  40a775:	add    r11,0x1
  40a779:	add    r10,0x1
  40a77d:	cmp    r10,0x2
  40a781:	jb     40a5f0 <__swc_fn_fc36583a_000177_aa67484d+0x290>
  40a787:	mov    rdx,QWORD PTR [rip+0x1c642]        # 426dd0 <__swc_bss_base_fc36583a+0x2d90>
  40a78e:	mov    QWORD PTR [rdx+r8*8],rcx
  40a792:	mov    rdx,QWORD PTR [rip+0x1c63f]        # 426dd8 <__swc_bss_base_fc36583a+0x2d98>
  40a799:	mov    QWORD PTR [rdx+r8*8],r11
  40a79d:	xor    edx,edx
  40a79f:	test   r11,r11
  40a7a2:	jbe    40a7d4 <__swc_fn_fc36583a_000177_aa67484d+0x474>
  40a7a4:	mov    r10,QWORD PTR [rip+0x1c61d]        # 426dc8 <__swc_bss_base_fc36583a+0x2d88>
  40a7ab:	cs nop WORD PTR [rax+rax*1+0x0]
  40a7b5:	cs nop WORD PTR [rax+rax*1+0x0]
  40a7bf:	nop
  40a7c0:	mov    sil,BYTE PTR [r9+rdx*1]
  40a7c4:	mov    BYTE PTR [r10+rcx*1],sil
  40a7c8:	inc    rcx
  40a7cb:	add    rdx,0x1
  40a7cf:	cmp    rdx,r11
  40a7d2:	jb     40a7c0 <__swc_fn_fc36583a_000177_aa67484d+0x460>
  40a7d4:	add    r8,0x1
  40a7d8:	cmp    r8,0x28
  40a7dc:	jb     40a530 <__swc_fn_fc36583a_000177_aa67484d+0x1d0>
  40a7e2:	sub    rsp,0x8
  40a7e6:	call   412080 <__swc_fn_fc36583a_000176_1ca87929>
  40a7eb:	add    rsp,0x8
  40a7ef:	vmovups xmm6,xmm0
  40a7f3:	lea    rax,[rbx+0xf8]
  40a7fa:	vxorps xmm0,xmm0,xmm0
  40a7fe:	xor    ecx,ecx
  40a800:	vmovdqu XMMWORD PTR [rax+rcx*1],xmm0
  40a805:	add    rcx,0x10
  40a809:	cmp    rcx,0x200
  40a810:	jne    40a800 <__swc_fn_fc36583a_000177_aa67484d+0x4a0>
  40a812:	lea    rcx,[rbx+0x2f8]
  40a819:	vxorps xmm0,xmm0,xmm0
  40a81d:	xor    edx,edx
  40a81f:	nop
  40a820:	vmovdqu XMMWORD PTR [rcx+rdx*1],xmm0
  40a825:	add    rdx,0x10
  40a829:	cmp    rdx,0x200
  40a830:	jne    40a820 <__swc_fn_fc36583a_000177_aa67484d+0x4c0>
  40a832:	xor    edx,edx
  40a834:	mov    r8,QWORD PTR [rip+0x1c595]        # 426dd0 <__swc_bss_base_fc36583a+0x2d90>
  40a83b:	mov    QWORD PTR [rsp+0x5b0],r8
  40a843:	mov    r9,QWORD PTR [rip+0x1c58e]        # 426dd8 <__swc_bss_base_fc36583a+0x2d98>
  40a84a:	mov    QWORD PTR [rsp+0x5b8],r9
  40a852:	mov    r10,QWORD PTR [rip+0x1c55f]        # 426db8 <__swc_bss_base_fc36583a+0x2d78>
  40a859:	mov    QWORD PTR [rsp+0x5a0],0x0
  40a865:	mov    QWORD PTR [rsp+0x5c0],r10
  40a86d:	mov    r11,QWORD PTR [rip+0x1c54c]        # 426dc0 <__swc_bss_base_fc36583a+0x2d80>
  40a874:	mov    QWORD PTR [rsp+0x5c8],r11
  40a87c:	jmp    40a8b8 <__swc_fn_fc36583a_000177_aa67484d+0x558>
  40a87e:	cs nop WORD PTR [rax+rax*1+0x0]
  40a888:	nop    DWORD PTR [rax+rax*1+0x0]
  40a890:	mov    QWORD PTR [rsp+0x5a0],rsi
  40a898:	mov    r8,QWORD PTR [rsp+0x5b0]
  40a8a0:	mov    r9,QWORD PTR [rsp+0x5b8]
  40a8a8:	mov    r10,QWORD PTR [rsp+0x5c0]
  40a8b0:	mov    r11,QWORD PTR [rsp+0x5c8]
  40a8b8:	mov    rdi,QWORD PTR [r8+rdx*8]
  40a8bc:	mov    QWORD PTR [rsp+0x5d0],rdi
  40a8c4:	mov    r12,QWORD PTR [r9+rdx*8]
  40a8c8:	mov    QWORD PTR [rsp+0x5d8],r12
  40a8d0:	mov    r13d,0x40000000
  40a8d6:	mov    r14,0xffffffffffffffff
  40a8dd:	xor    r15d,r15d
  40a8e0:	mov    QWORD PTR [rsp+0x5a8],rdx
  40a8e8:	vmovq  xmm3,r13
  40a8ed:	vmovq  xmm4,r14
  40a8f2:	vmovq  xmm5,r15
  40a8f7:	jmp    40a922 <__swc_fn_fc36583a_000177_aa67484d+0x5c2>
  40a8f9:	nop    DWORD PTR [rax+0x0]
  40a900:	mov    r10,QWORD PTR [rsp+0x5c0]
  40a908:	mov    r11,QWORD PTR [rsp+0x5c8]
  40a910:	mov    rdi,QWORD PTR [rsp+0x5d0]
  40a918:	vmovq  xmm3,r13
  40a91d:	vmovq  xmm4,r14
  40a922:	mov    r8,QWORD PTR [r10+r15*8]
  40a926:	mov    QWORD PTR [rsp+0x5f8],r8
  40a92e:	mov    r9,QWORD PTR [r11+r15*8]
  40a932:	mov    rdx,r9
  40a935:	sub    rdx,r12
  40a938:	mov    rsi,r12
  40a93b:	sub    rsi,r9
  40a93e:	cmovbe rsi,rdx
  40a942:	cmp    rsi,0x3
  40a946:	jbe    40a957 <__swc_fn_fc36583a_000177_aa67484d+0x5f7>
  40a948:	vmovq  r13,xmm3
  40a94d:	vmovq  r14,xmm4
  40a952:	jmp    40aacb <__swc_fn_fc36583a_000177_aa67484d+0x76b>
  40a957:	lea    rdx,[r9+0x1]
  40a95b:	xor    esi,esi
  40a95d:	test   rdx,rdx
  40a960:	jbe    40a97d <__swc_fn_fc36583a_000177_aa67484d+0x61d>
  40a962:	cs nop WORD PTR [rax+rax*1+0x0]
  40a96c:	nop    DWORD PTR [rax+0x0]
  40a970:	mov    QWORD PTR [rax+rsi*8],rsi
  40a974:	add    rsi,0x1
  40a978:	cmp    rsi,rdx
  40a97b:	jb     40a970 <__swc_fn_fc36583a_000177_aa67484d+0x610>
  40a97d:	xor    esi,esi
  40a97f:	test   r12,r12
  40a982:	jbe    40aaad <__swc_fn_fc36583a_000177_aa67484d+0x74d>
  40a988:	mov    r10,QWORD PTR [rip+0x1c439]        # 426dc8 <__swc_bss_base_fc36583a+0x2d88>
  40a98f:	add    r10,rdi
  40a992:	vmovsd xmm0,QWORD PTR [rsp+0x5d8]
  40a99b:	vmovsd xmm1,QWORD PTR [rsp+0x5f8]
  40a9a4:	vmovq  xmm2,r10
  40a9a9:	nop    DWORD PTR [rax+0x0]
  40a9b0:	lea    r11,[rsi+0x1]
  40a9b4:	mov    QWORD PTR [rbx+0x2f8],r11
  40a9bb:	mov    sil,BYTE PTR [r10+rsi*1]
  40a9bf:	xor    edi,edi
  40a9c1:	test   r9,r9
  40a9c4:	jbe    40aa16 <__swc_fn_fc36583a_000177_aa67484d+0x6b6>
  40a9c6:	mov    r14,QWORD PTR [rip+0x1c3e3]        # 426db0 <__swc_bss_base_fc36583a+0x2d70>
  40a9cd:	add    r14,r8
  40a9d0:	mov    r15,QWORD PTR [rbx+0xf8]
  40a9d7:	mov    r13,r11
  40a9da:	nop    WORD PTR [rax+rax*1+0x0]
  40a9e0:	xor    r8d,r8d
  40a9e3:	cmp    BYTE PTR [r14+rdi*1],sil
  40a9e7:	setne  r8b
  40a9eb:	add    r8,r15
  40a9ee:	mov    r15,QWORD PTR [rax+rdi*8+0x8]
  40a9f3:	lea    r10,[r15+0x1]
  40a9f7:	cmp    r10,r8
  40a9fa:	cmovb  r8,r10
  40a9fe:	inc    r13
  40aa01:	cmp    r13,r8
  40aa04:	cmovae r13,r8
  40aa08:	mov    QWORD PTR [rcx+rdi*8+0x8],r13
  40aa0d:	add    rdi,0x1
  40aa11:	cmp    rdi,r9
  40aa14:	jb     40a9e0 <__swc_fn_fc36583a_000177_aa67484d+0x680>
  40aa16:	xor    r8d,r8d
  40aa19:	test   rdx,rdx
  40aa1c:	jbe    40aa91 <__swc_fn_fc36583a_000177_aa67484d+0x731>
  40aa22:	cmp    rdx,0x4
  40aa26:	jb     40aa80 <__swc_fn_fc36583a_000177_aa67484d+0x720>
  40aa28:	lea    r10,[rdx-0x3]
  40aa2c:	nop    DWORD PTR [rax+0x0]
  40aa30:	mov    rsi,QWORD PTR [rcx+r8*8]
  40aa34:	mov    QWORD PTR [rax+r8*8],rsi
  40aa38:	mov    rsi,QWORD PTR [rcx+r8*8+0x8]
  40aa3d:	mov    QWORD PTR [rax+r8*8+0x8],rsi
  40aa42:	mov    rsi,QWORD PTR [rcx+r8*8+0x10]
  40aa47:	mov    QWORD PTR [rax+r8*8+0x10],rsi
  40aa4c:	mov    rsi,QWORD PTR [rcx+r8*8+0x18]
  40aa51:	mov    QWORD PTR [rax+r8*8+0x18],rsi
  40aa56:	add    r8,0x4
  40aa5a:	cmp    r8,r10
  40aa5d:	jb     40aa30 <__swc_fn_fc36583a_000177_aa67484d+0x6d0>
  40aa5f:	cmp    r8,rdx
  40aa62:	jae    40aa91 <__swc_fn_fc36583a_000177_aa67484d+0x731>
  40aa64:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa6e:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa78:	nop    DWORD PTR [rax+rax*1+0x0]
  40aa80:	mov    rsi,QWORD PTR [rcx+r8*8]
  40aa84:	mov    QWORD PTR [rax+r8*8],rsi
  40aa88:	add    r8,0x1
  40aa8c:	cmp    r8,rdx
  40aa8f:	jb     40aa80 <__swc_fn_fc36583a_000177_aa67484d+0x720>
  40aa91:	mov    rsi,r11
  40aa94:	vmovq  r12,xmm0
  40aa99:	cmp    r11,r12
  40aa9c:	jae    40aaad <__swc_fn_fc36583a_000177_aa67484d+0x74d>
  40aa9e:	vmovq  r8,xmm1
  40aaa3:	vmovq  r10,xmm2
  40aaa8:	jmp    40a9b0 <__swc_fn_fc36583a_000177_aa67484d+0x650>
  40aaad:	mov    rdx,QWORD PTR [rax+r9*8]
  40aab1:	vmovq  r13,xmm3
  40aab6:	cmp    rdx,r13
  40aab9:	cmovb  r13,rdx
  40aabd:	vmovq  r14,xmm4
  40aac2:	vmovq  r15,xmm5
  40aac7:	cmovb  r14,r15
  40aacb:	add    r15,0x1
  40aacf:	vmovq  xmm5,r15
  40aad4:	cmp    r15,0x1770
  40aadb:	jb     40a900 <__swc_fn_fc36583a_000177_aa67484d+0x5a0>
  40aae1:	imul   r13,r13,0x1f
  40aae5:	add    r13,r14
  40aae8:	mov    rsi,QWORD PTR [rsp+0x5a0]
  40aaf0:	add    rsi,r13
  40aaf3:	mov    rdx,QWORD PTR [rsp+0x5a8]
  40aafb:	add    rdx,0x1
  40aaff:	cmp    rdx,0x28
  40ab03:	jb     40a890 <__swc_fn_fc36583a_000177_aa67484d+0x530>
  40ab09:	sub    rsp,0x8
  40ab0d:	call   412080 <__swc_fn_fc36583a_000176_1ca87929>
  40ab12:	add    rsp,0x8
  40ab16:	vsubsd xmm0,xmm0,xmm6
  40ab1a:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x8ea6]        # 4139c8 <__swc_rdata_base_fc36583a+0x8b8>
  40ab22:	lea    rax,[rip+0x883f]        # 413368 <__swc_rdata_base_fc36583a+0x258>
  40ab29:	sub    rsp,0x90
  40ab30:	mov    rcx,rsp
  40ab33:	vmovups xmm1,XMMWORD PTR [rip+0x8e6d]        # 4139a8 <__swc_rdata_base_fc36583a+0x898>
  40ab3b:	vmovups XMMWORD PTR [rcx],xmm1
  40ab3f:	mov    QWORD PTR [rcx+0x30],rsp
  40ab43:	lea    rdx,[rip+0x87c6]        # 413310 <__swc_rdata_base_fc36583a+0x200>
  40ab4a:	mov    QWORD PTR [rcx+0x38],rdx
  40ab4e:	mov    QWORD PTR [rcx+0x10],rsi
  40ab52:	lea    r8,[rsp+0x10]
  40ab57:	mov    QWORD PTR [rcx+0x40],r8
  40ab5b:	lea    r8,[rip+0x8db6]        # 413918 <__swc_rdata_base_fc36583a+0x808>
  40ab62:	mov    QWORD PTR [rcx+0x48],r8
  40ab66:	vmovups xmm1,XMMWORD PTR [rip+0x8e4a]        # 4139b8 <__swc_rdata_base_fc36583a+0x8a8>
  40ab6e:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40ab73:	lea    r8,[rsp+0x18]
  40ab78:	mov    QWORD PTR [rcx+0x50],r8
  40ab7c:	mov    QWORD PTR [rcx+0x58],rdx
  40ab80:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40ab85:	lea    r8,[rcx+0x28]
  40ab89:	mov    QWORD PTR [rcx+0x60],r8
  40ab8d:	lea    r8,[rip+0x8dcc]        # 413960 <__swc_rdata_base_fc36583a+0x850>
  40ab94:	mov    QWORD PTR [rcx+0x68],r8
  40ab98:	mov    QWORD PTR [rcx+0x70],rax
  40ab9c:	mov    QWORD PTR [rcx+0x78],rdx
  40aba0:	lea    rax,[rcx+0x30]
  40aba4:	mov    QWORD PTR [rcx+0x80],rax
  40abab:	mov    QWORD PTR [rcx+0x88],0x5
  40abb6:	lea    rcx,[rcx+0x80]
  40abbd:	sub    rsp,0x8
  40abc1:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  40abc6:	add    rsp,0x6a8
  40abcd:	vmovups xmm6,XMMWORD PTR [rsp]
  40abd2:	add    rsp,0x10
  40abd6:	pop    r13
  40abd8:	pop    r14
  40abda:	pop    r12
  40abdc:	pop    rdi
  40abdd:	pop    rsi
  40abde:	pop    r15
  40abe0:	pop    rbx
  40abe1:	pop    rbp
  40abe2:	ret
	...

000000000040ac00 <__swc_fn_fc36583a_000001_0e26756e>:
  40ac00:	vxorps xmm0,xmm0,xmm0
  40ac04:	xor    eax,eax
  40ac06:	cs nop WORD PTR [rax+rax*1+0x0]
  40ac10:	cs nop WORD PTR [rax+rax*1+0x0]
  40ac1a:	nop    WORD PTR [rax+rax*1+0x0]
  40ac20:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40ac25:	add    rax,0x10
  40ac29:	cmp    rax,0x2080
  40ac30:	jne    40ac20 <__swc_fn_fc36583a_000001_0e26756e+0x20>
  40ac32:	ret
	...

000000000040ac40 <__swc_fn_fc36583a_000004_3deb8b54>:
  40ac40:	push   rsi
  40ac41:	push   rdi
  40ac42:	push   r12
  40ac44:	push   r13
  40ac46:	push   r14
  40ac48:	mov    rsi,rcx
  40ac4b:	mov    edi,r10d
  40ac4e:	mov    r12,rcx
  40ac51:	mov    r13,r9
  40ac54:	mov    ecx,DWORD PTR [rdx+0x28]
  40ac57:	shlx   r14d,r8d,ecx
  40ac5c:	mov    rcx,rdx
  40ac5f:	mov    edx,r8d
  40ac62:	call   40df80 <__swc_fn_fc36583a_000011_71c91685>
  40ac67:	mov    rcx,rax
  40ac6a:	mov    eax,DWORD PTR [r12+0x3c]
  40ac6f:	xor    edx,edx
  40ac71:	div    rdi
  40ac74:	vxorps xmm0,xmm0,xmm0
  40ac78:	vmovdqu XMMWORD PTR [rsi],xmm0
  40ac7c:	mov    QWORD PTR [r12+0x60],0x0
  40ac85:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40ac8a:	mov    QWORD PTR [r12+0x10],rcx
  40ac8f:	imul   rax,rdi
  40ac93:	lea    rdx,[rcx+rax*1]
  40ac97:	mov    QWORD PTR [r12+0x18],rdx
  40ac9c:	mov    QWORD PTR [r12+0x20],rcx
  40aca1:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40aca6:	mov    DWORD PTR [r12+0x28],0x0
  40acaf:	mov    DWORD PTR [r12+0x68],0x0
  40acb8:	mov    BYTE PTR [r12+0x39],r13b
  40acbd:	mov    BYTE PTR [r12+0x3a],r14b
  40acc2:	mov    BYTE PTR [r12+0x3b],0x1
  40acc8:	mov    DWORD PTR [r12+0x6c],0x0
  40acd1:	mov    rcx,r12
  40acd4:	mov    edx,edi
  40acd6:	call   40dee0 <__swc_fn_fc36583a_000005_6a556171>
  40acdb:	pop    r14
  40acdd:	pop    r13
  40acdf:	pop    r12
  40ace1:	pop    rdi
  40ace2:	pop    rsi
  40ace3:	ret
	...

000000000040acf0 <__swc_fn_fc36583a_000007_a7bfb091>:
  40acf0:	mov    r8d,0x1
  40acf6:	xor    eax,eax
  40acf8:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40acfe:	test   eax,eax
  40ad00:	jne    40acf0 <__swc_fn_fc36583a_000007_a7bfb091>
  40ad02:	ret
	...

000000000040ad10 <__swc_fn_fc36583a_000010_0569f799>:
  40ad10:	lea    r8,[rcx+0x60]
  40ad14:	mov    rax,QWORD PTR [r8]
  40ad17:	mov    r9,rax
  40ad1a:	nop    WORD PTR [rax+rax*1+0x0]
  40ad20:	mov    QWORD PTR [rdx],r9
  40ad23:	mov    rax,r9
  40ad26:	lock cmpxchg QWORD PTR [r8],rdx
  40ad2b:	cmp    rax,r9
  40ad2e:	jne    40ad97 <__swc_fn_fc36583a_000010_0569f799+0x87>
  40ad30:	mov    eax,DWORD PTR [rcx+0x6c]
  40ad33:	test   eax,eax
  40ad35:	je     40ad96 <__swc_fn_fc36583a_000010_0569f799+0x86>
  40ad37:	lea    rdx,[rcx+0x70]
  40ad3b:	mov    r9d,0x1
  40ad41:	xor    eax,eax
  40ad43:	lock cmpxchg DWORD PTR [rdx],r9d
  40ad48:	test   eax,eax
  40ad4a:	jne    40ad96 <__swc_fn_fc36583a_000010_0569f799+0x86>
  40ad4c:	mov    rax,rcx
  40ad4f:	and    rax,0xffffffffffc00000
  40ad56:	mov    rax,QWORD PTR [rax+0x8]
  40ad5a:	test   rax,rax
  40ad5d:	jne    40ad65 <__swc_fn_fc36583a_000010_0569f799+0x55>
  40ad5f:	xor    eax,eax
  40ad61:	xchg   DWORD PTR [rdx],eax
  40ad63:	jmp    40ad96 <__swc_fn_fc36583a_000010_0569f799+0x86>
  40ad65:	lea    rdx,[rax+0x2a80]
  40ad6c:	mov    rax,QWORD PTR [rdx]
  40ad6f:	mov    r8,rax
  40ad72:	cs nop WORD PTR [rax+rax*1+0x0]
  40ad7c:	nop    DWORD PTR [rax+0x0]
  40ad80:	mov    QWORD PTR [rcx+0x78],r8
  40ad84:	mov    rax,r8
  40ad87:	lock cmpxchg QWORD PTR [rdx],rcx
  40ad8c:	cmp    rax,r8
  40ad8f:	je     40ad96 <__swc_fn_fc36583a_000010_0569f799+0x86>
  40ad91:	mov    r8,rax
  40ad94:	jmp    40ad80 <__swc_fn_fc36583a_000010_0569f799+0x70>
  40ad96:	ret
  40ad97:	mov    r9,rax
  40ad9a:	jmp    40ad20 <__swc_fn_fc36583a_000010_0569f799+0x10>
	...

000000000040ada0 <__swc_fn_fc36583a_000013_7b85dbab>:
  40ada0:	push   rsi
  40ada1:	push   rdi
  40ada2:	push   r12
  40ada4:	push   r13
  40ada6:	push   r14
  40ada8:	push   r15
  40adaa:	push   rbx
  40adab:	sub    rsp,0x30
  40adaf:	mov    QWORD PTR [rsp+0x18],r8
  40adb4:	mov    rsi,rcx
  40adb7:	mov    rdi,rdx
  40adba:	mov    rdx,QWORD PTR [rsi+0x40]
  40adbe:	xchg   ax,ax
  40adc0:	mov    rax,rdx
  40adc3:	not    rax
  40adc6:	and    rax,QWORD PTR [rsi+0x20]
  40adca:	test   rax,rax
  40adcd:	jne    40ade1 <__swc_fn_fc36583a_000013_7b85dbab+0x41>
  40adcf:	xor    eax,eax
  40add1:	add    rsp,0x30
  40add5:	pop    rbx
  40add6:	pop    r15
  40add8:	pop    r14
  40adda:	pop    r13
  40addc:	pop    r12
  40adde:	pop    rdi
  40addf:	pop    rsi
  40ade0:	ret
  40ade1:	xor    ecx,ecx
  40ade3:	tzcnt  rcx,rax
  40ade8:	lea    r12,[rsp+0x8]
  40aded:	mov    DWORD PTR [rsp+0x8],ecx
  40adf1:	mov    r13d,0x1
  40adf7:	shl    r13,cl
  40adfa:	mov    rcx,rdx
  40adfd:	or     rcx,r13
  40ae00:	mov    rax,rdx
  40ae03:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40ae09:	cmp    rax,rdx
  40ae0c:	je     40ae13 <__swc_fn_fc36583a_000013_7b85dbab+0x73>
  40ae0e:	mov    rdx,rax
  40ae11:	jmp    40adc0 <__swc_fn_fc36583a_000013_7b85dbab+0x20>
  40ae13:	mov    eax,DWORD PTR [r12]
  40ae17:	shl    rax,0x4
  40ae1b:	lea    r14,[rsi+rax*8+0x80]
  40ae23:	mov    rcx,rsi
  40ae26:	mov    rax,r12
  40ae29:	mov    edx,DWORD PTR [rax]
  40ae2b:	call   40df80 <__swc_fn_fc36583a_000011_71c91685>
  40ae30:	mov    r15,rax
  40ae33:	mov    rcx,rsi
  40ae36:	mov    rdx,r13
  40ae39:	call   40e0e0 <__swc_fn_fc36583a_000017_f003fc47>
  40ae3e:	test   al,al
  40ae40:	je     40ae78 <__swc_fn_fc36583a_000013_7b85dbab+0xd8>
  40ae42:	mov    ecx,DWORD PTR [r14+0x3c]
  40ae46:	lea    rdx,[rip+0x1920b]        # 424058 <__swc_bss_base_fc36583a+0x18>
  40ae4d:	mov    r8,QWORD PTR [rip+0x19204]        # 424058 <__swc_bss_base_fc36583a+0x18>
  40ae54:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae5e:	xchg   ax,ax
  40ae60:	mov    r9,r8
  40ae63:	sub    r9,rcx
  40ae66:	mov    rax,r8
  40ae69:	lock cmpxchg QWORD PTR [rdx],r9
  40ae6e:	cmp    rax,r8
  40ae71:	je     40aed9 <__swc_fn_fc36583a_000013_7b85dbab+0x139>
  40ae73:	mov    r8,rax
  40ae76:	jmp    40ae60 <__swc_fn_fc36583a_000013_7b85dbab+0xc0>
  40ae78:	mov    rcx,rsi
  40ae7b:	mov    rax,r12
  40ae7e:	mov    edx,DWORD PTR [rax]
  40ae80:	call   407450 <__swc_fn_fc36583a_000012_be38a1a2>
  40ae85:	mov    rcx,r15
  40ae88:	and    rcx,0xffffffffffff0000
  40ae8f:	lea    rcx,[rcx+0x10000]
  40ae96:	mov    rbx,rax
  40ae99:	cmp    rax,rcx
  40ae9c:	cmova  rbx,rcx
  40aea0:	mov    rax,rbx
  40aea3:	sub    rax,r15
  40aea6:	mov    rcx,r15
  40aea9:	mov    rdx,rax
  40aeac:	call   4072a0 <__swc_fn_fc36583a_000003_81215399>
  40aeb1:	test   al,al
  40aeb3:	jne    40aed2 <__swc_fn_fc36583a_000013_7b85dbab+0x132>
  40aeb5:	mov    rcx,rsi
  40aeb8:	mov    rdx,r13
  40aebb:	call   407600 <__swc_fn_fc36583a_000018_77ece227>
  40aec0:	xor    eax,eax
  40aec2:	add    rsp,0x30
  40aec6:	pop    rbx
  40aec7:	pop    r15
  40aec9:	pop    r14
  40aecb:	pop    r13
  40aecd:	pop    r12
  40aecf:	pop    rdi
  40aed0:	pop    rsi
  40aed1:	ret
  40aed2:	sub    rbx,r15
  40aed5:	mov    DWORD PTR [r14+0x3c],ebx
  40aed9:	mov    rcx,r14
  40aedc:	mov    rdx,rsi
  40aedf:	mov    r8d,DWORD PTR [r12]
  40aee3:	mov    r9d,edi
  40aee6:	mov    rbx,QWORD PTR [rsp+0x18]
  40aeeb:	mov    r10d,ebx
  40aeee:	call   40ac40 <__swc_fn_fc36583a_000004_3deb8b54>
  40aef3:	mov    rax,r14
  40aef6:	add    rsp,0x30
  40aefa:	pop    rbx
  40aefb:	pop    r15
  40aefd:	pop    r14
  40aeff:	pop    r13
  40af01:	pop    r12
  40af03:	pop    rdi
  40af04:	pop    rsi
  40af05:	ret
	...

000000000040af10 <__swc_fn_fc36583a_000016_a0b588d0>:
  40af10:	mov    r8,QWORD PTR [rcx+0x48]
  40af14:	cs nop WORD PTR [rax+rax*1+0x0]
  40af1e:	xchg   ax,ax
  40af20:	mov    r9,r8
  40af23:	or     r9,rdx
  40af26:	mov    rax,r8
  40af29:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40af2f:	cmp    rax,r8
  40af32:	jne    40af35 <__swc_fn_fc36583a_000016_a0b588d0+0x25>
  40af34:	ret
  40af35:	mov    r8,rax
  40af38:	jmp    40af20 <__swc_fn_fc36583a_000016_a0b588d0+0x10>
  40af3a:	add    BYTE PTR [rax],al
  40af3c:	add    BYTE PTR [rax],al
	...

000000000040af40 <__swc_fn_fc36583a_000019_447bb610>:
  40af40:	push   rsi
  40af41:	push   rdi
  40af42:	push   r12
  40af44:	mov    rsi,rcx
  40af47:	xor    edi,edi
  40af49:	lea    r12,[rip+0x19118]        # 424068 <__swc_bss_base_fc36583a+0x28>
  40af50:	mov    eax,DWORD PTR [r12]
  40af54:	xor    ecx,ecx
  40af56:	test   rax,rax
  40af59:	jbe    40af94 <__swc_fn_fc36583a_000019_447bb610+0x54>
  40af5b:	nop    DWORD PTR [rax+rax*1+0x0]
  40af60:	lea    rdx,[rip+0x19109]        # 424070 <__swc_bss_base_fc36583a+0x30>
  40af67:	mov    r8d,ecx
  40af6a:	lea    r8,[r8+r8*2]
  40af6e:	lea    r8,[rdx+r8*8]
  40af72:	mov    rdx,QWORD PTR [r8+0x10]
  40af76:	add    rdx,0x400000
  40af7d:	cmp    rdx,0x40000000
  40af84:	ja     40af8b <__swc_fn_fc36583a_000019_447bb610+0x4b>
  40af86:	mov    rdi,r8
  40af89:	jmp    40af94 <__swc_fn_fc36583a_000019_447bb610+0x54>
  40af8b:	add    rcx,0x1
  40af8f:	cmp    rcx,rax
  40af92:	jb     40af60 <__swc_fn_fc36583a_000019_447bb610+0x20>
  40af94:	test   rdi,rdi
  40af97:	jne    40b023 <__swc_fn_fc36583a_000019_447bb610+0xe3>
  40af9d:	cmp    DWORD PTR [r12],0x10
  40afa2:	jae    40b00b <__swc_fn_fc36583a_000019_447bb610+0xcb>
  40afa4:	mov    ecx,0x40400000
  40afa9:	call   40dea0 <__swc_fn_fc36583a_000002_102336c4>
  40afae:	test   rax,rax
  40afb1:	je     40b00b <__swc_fn_fc36583a_000019_447bb610+0xcb>
  40afb3:	lea    rcx,[rip+0x190b6]        # 424070 <__swc_bss_base_fc36583a+0x30>
  40afba:	mov    edx,DWORD PTR [r12]
  40afbe:	lea    rdx,[rdx+rdx*2]
  40afc2:	lea    rdx,[rcx+rdx*8]
  40afc6:	mov    QWORD PTR [rdx],rax
  40afc9:	lea    rax,[rax+0x3fffff]
  40afd0:	and    rax,0xffffffffffc00000
  40afd7:	mov    QWORD PTR [rdx+0x8],rax
  40afdb:	mov    QWORD PTR [rdx+0x10],0x0
  40afe3:	mov    edx,DWORD PTR [rip+0x1907f]        # 424068 <__swc_bss_base_fc36583a+0x28>
  40afe9:	nop    DWORD PTR [rax+0x0]
  40aff0:	lea    r9d,[rdx+0x1]
  40aff4:	mov    rax,rdx
  40aff7:	lock cmpxchg DWORD PTR [r12],r9d
  40affd:	mov    r8d,eax
  40b000:	cmp    eax,edx
  40b002:	je     40b012 <__swc_fn_fc36583a_000019_447bb610+0xd2>
  40b004:	mov    rdx,r8
  40b007:	jmp    40aff0 <__swc_fn_fc36583a_000019_447bb610+0xb0>
  40b009:	jmp    40b012 <__swc_fn_fc36583a_000019_447bb610+0xd2>
  40b00b:	xor    eax,eax
  40b00d:	pop    r12
  40b00f:	pop    rdi
  40b010:	pop    rsi
  40b011:	ret
  40b012:	mov    eax,DWORD PTR [rip+0x19050]        # 424068 <__swc_bss_base_fc36583a+0x28>
  40b018:	sub    eax,0x1
  40b01b:	lea    rdi,[rax+rax*2]
  40b01f:	lea    rdi,[rcx+rdi*8]
  40b023:	mov    r12,QWORD PTR [rdi+0x8]
  40b027:	add    r12,QWORD PTR [rdi+0x10]
  40b02b:	mov    rcx,r12
  40b02e:	mov    edx,0x3000
  40b033:	call   4072a0 <__swc_fn_fc36583a_000003_81215399>
  40b038:	test   al,al
  40b03a:	jne    40b043 <__swc_fn_fc36583a_000019_447bb610+0x103>
  40b03c:	xor    eax,eax
  40b03e:	pop    r12
  40b040:	pop    rdi
  40b041:	pop    rsi
  40b042:	ret
  40b043:	vxorps xmm0,xmm0,xmm0
  40b047:	xor    eax,eax
  40b049:	cs nop WORD PTR [rax+rax*1+0x0]
  40b053:	cs nop WORD PTR [rax+rax*1+0x0]
  40b05d:	nop    DWORD PTR [rax]
  40b060:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40b066:	add    rax,0x10
  40b06a:	cmp    rax,0x3000
  40b071:	jne    40b060 <__swc_fn_fc36583a_000019_447bb610+0x120>
  40b073:	mov    DWORD PTR [r12+0x28],esi
  40b078:	mov    eax,0x40
  40b07d:	mov    ecx,esi
  40b07f:	shr    eax,cl
  40b081:	mov    DWORD PTR [r12+0x2c],eax
  40b086:	cmp    DWORD PTR [r12+0x2c],0x40
  40b08c:	jb     40b097 <__swc_fn_fc36583a_000019_447bb610+0x157>
  40b08e:	mov    rax,0xffffffffffffffff
  40b095:	jmp    40b0a7 <__swc_fn_fc36583a_000019_447bb610+0x167>
  40b097:	mov    eax,0x1
  40b09c:	mov    ecx,DWORD PTR [r12+0x2c]
  40b0a1:	shl    rax,cl
  40b0a4:	dec    rax
  40b0a7:	mov    QWORD PTR [r12+0x20],rax
  40b0ac:	mov    DWORD PTR [r12],0x4e540001
  40b0b4:	mov    DWORD PTR [r12+0x4],0x53474d45
  40b0bd:	add    QWORD PTR [rdi+0x10],0x400000
  40b0c5:	mov    rax,r12
  40b0c8:	pop    r12
  40b0ca:	pop    rdi
  40b0cb:	pop    rsi
  40b0cc:	ret
  40b0cd:	add    BYTE PTR [rax],al
	...

000000000040b0d0 <__swc_fn_fc36583a_000022_53fc00d2>:
  40b0d0:	mov    eax,0x1
  40b0d5:	mov    edx,DWORD PTR [rip+0x18f8d]        # 424068 <__swc_bss_base_fc36583a+0x28>
  40b0db:	cmp    eax,edx
  40b0dd:	jae    40b12b <__swc_fn_fc36583a_000022_53fc00d2+0x5b>
  40b0df:	nop
  40b0e0:	lea    r8,[rip+0x18f89]        # 424070 <__swc_bss_base_fc36583a+0x30>
  40b0e7:	lea    r9,[rax+rax*2]
  40b0eb:	lea    r9,[r8+r9*8]
  40b0ef:	mov    r8,rcx
  40b0f2:	sub    r8,QWORD PTR [r9+0x8]
  40b0f6:	mov    r9,QWORD PTR [r9+0x10]
  40b0fa:	cmp    r8,r9
  40b0fd:	jae    40b125 <__swc_fn_fc36583a_000022_53fc00d2+0x55>
  40b0ff:	mov    rax,rcx
  40b102:	and    rax,0xffffffffffc00000
  40b109:	shr    rcx,0x10
  40b10d:	and    ecx,0x3f
  40b110:	mov    edx,DWORD PTR [rax+0x28]
  40b113:	shrx   ecx,ecx,edx
  40b118:	shl    rcx,0x4
  40b11c:	lea    rax,[rax+rcx*8+0x80]
  40b124:	ret
  40b125:	inc    eax
  40b127:	cmp    eax,edx
  40b129:	jb     40b0e0 <__swc_fn_fc36583a_000022_53fc00d2+0x10>
  40b12b:	xor    eax,eax
  40b12d:	ret
	...

000000000040b130 <__swc_fn_fc36583a_000025_e876734d>:
  40b130:	vxorps xmm0,xmm0,xmm0
  40b134:	vmovups XMMWORD PTR [rcx],xmm0
  40b138:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b13d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b142:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b147:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40b14c:	mov    QWORD PTR [rcx+0x50],0x0
  40b154:	ret
	...

000000000040b160 <__swc_fn_fc36583a_000028_e876734d>:
  40b160:	vxorps xmm0,xmm0,xmm0
  40b164:	xor    eax,eax
  40b166:	cs nop WORD PTR [rax+rax*1+0x0]
  40b170:	cs nop WORD PTR [rax+rax*1+0x0]
  40b17a:	nop    WORD PTR [rax+rax*1+0x0]
  40b180:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40b185:	add    rax,0x10
  40b189:	cmp    rax,0x9b0
  40b190:	jne    40b180 <__swc_fn_fc36583a_000028_e876734d+0x20>
  40b192:	mov    QWORD PTR [rcx+0x9b0],0x0
  40b19d:	ret
	...

000000000040b1a0 <__swc_fn_fc36583a_000031_3c3e930e>:
  40b1a0:	push   rsi
  40b1a1:	push   rdi
  40b1a2:	sub    rsp,0x8
  40b1a6:	lea    rsi,[rip+0x16e5b]        # 422008 <__swc_data_base_fc36583a+0x8>
  40b1ad:	mov    rax,QWORD PTR [rsi]
  40b1b0:	mov    ecx,0xffffffff
  40b1b5:	cmp    rax,rcx
  40b1b8:	je     40b1c1 <__swc_fn_fc36583a_000031_3c3e930e+0x21>
  40b1ba:	add    rsp,0x8
  40b1be:	pop    rdi
  40b1bf:	pop    rsi
  40b1c0:	ret
  40b1c1:	mov    rcx,QWORD PTR [rip+0x7eb0]        # 413078 <__swc_fn_fc36583a_000176_1ca87929+0xff8>
  40b1c8:	call   409650 <__swc_fn_fc36583a_000126_9e9697c7>
  40b1cd:	mov    rcx,rax
  40b1d0:	mov    eax,0xffffffff
  40b1d5:	lock cmpxchg QWORD PTR [rsi],rcx
  40b1da:	mov    rdi,rax
  40b1dd:	mov    eax,0xffffffff
  40b1e2:	cmp    rdi,rax
  40b1e5:	je     40b1f6 <__swc_fn_fc36583a_000031_3c3e930e+0x56>
  40b1e7:	call   40d3d0 <__swc_fn_fc36583a_000127_f163135d>
  40b1ec:	mov    rax,rdi
  40b1ef:	add    rsp,0x8
  40b1f3:	pop    rdi
  40b1f4:	pop    rsi
  40b1f5:	ret
  40b1f6:	mov    rax,rcx
  40b1f9:	add    rsp,0x8
  40b1fd:	pop    rdi
  40b1fe:	pop    rsi
  40b1ff:	ret

000000000040b200 <__swc_fn_fc36583a_000034_cf5ba7bd>:
  40b200:	sub    rsp,0x8
  40b204:	vxorps xmm0,xmm0,xmm0
  40b208:	xor    eax,eax
  40b20a:	cs nop WORD PTR [rax+rax*1+0x0]
  40b214:	cs nop WORD PTR [rax+rax*1+0x0]
  40b21e:	xchg   ax,ax
  40b220:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40b225:	add    rax,0x10
  40b229:	cmp    rax,0x2b00
  40b230:	jne    40b220 <__swc_fn_fc36583a_000034_cf5ba7bd+0x20>
  40b232:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40b23c:	xor    al,al
  40b23e:	mov    rdx,rax
  40b241:	xor    al,al
  40b243:	mov    r8,rax
  40b246:	xor    al,al
  40b248:	mov    r9,rax
  40b24b:	xor    al,al
  40b24d:	mov    r10,rax
  40b250:	xor    al,al
  40b252:	mov    r11,rax
  40b255:	call   40e310 <__swc_fn_fc36583a_000035_ab2e8c35>
  40b25a:	add    rsp,0x8
  40b25e:	ret
	...

000000000040b260 <__swc_fn_fc36583a_000037_1e381f55>:
  40b260:	push   rsi
  40b261:	push   rdi
  40b262:	push   r12
  40b264:	mov    rsi,r8
  40b267:	mov    rdi,rdx
  40b26a:	mov    rcx,rdx
  40b26d:	call   40dea0 <__swc_fn_fc36583a_000002_102336c4>
  40b272:	mov    r12,rax
  40b275:	test   rax,rax
  40b278:	jne    40b281 <__swc_fn_fc36583a_000037_1e381f55+0x21>
  40b27a:	xor    eax,eax
  40b27c:	pop    r12
  40b27e:	pop    rdi
  40b27f:	pop    rsi
  40b280:	ret
  40b281:	mov    rcx,r12
  40b284:	mov    rdx,rsi
  40b287:	call   4072a0 <__swc_fn_fc36583a_000003_81215399>
  40b28c:	test   al,al
  40b28e:	jne    40b2a2 <__swc_fn_fc36583a_000037_1e381f55+0x42>
  40b290:	mov    rcx,r12
  40b293:	mov    rdx,rdi
  40b296:	call   410110 <__swc_fn_fc36583a_000113_4e83a03a>
  40b29b:	xor    eax,eax
  40b29d:	pop    r12
  40b29f:	pop    rdi
  40b2a0:	pop    rsi
  40b2a1:	ret
  40b2a2:	mov    rax,r12
  40b2a5:	pop    r12
  40b2a7:	pop    rdi
  40b2a8:	pop    rsi
  40b2a9:	ret
	...

000000000040b2c0 <__swc_fn_fc36583a_000040_8029566e>:
  40b2c0:	push   rsi
  40b2c1:	push   rdi
  40b2c2:	push   r12
  40b2c4:	mov    rsi,rcx
  40b2c7:	mov    edx,0x9b8
  40b2cc:	call   40e380 <__swc_fn_fc36583a_000038_292d55e5>
  40b2d1:	mov    rdi,rax
  40b2d4:	test   rax,rax
  40b2d7:	jne    40b2e0 <__swc_fn_fc36583a_000040_8029566e+0x20>
  40b2d9:	xor    eax,eax
  40b2db:	pop    r12
  40b2dd:	pop    rdi
  40b2de:	pop    rsi
  40b2df:	ret
  40b2e0:	vxorps xmm0,xmm0,xmm0
  40b2e4:	xor    eax,eax
  40b2e6:	cs nop WORD PTR [rax+rax*1+0x0]
  40b2f0:	cs nop WORD PTR [rax+rax*1+0x0]
  40b2fa:	nop    WORD PTR [rax+rax*1+0x0]
  40b300:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40b305:	add    rax,0x10
  40b309:	cmp    rax,0x9b0
  40b310:	jne    40b300 <__swc_fn_fc36583a_000040_8029566e+0x40>
  40b312:	mov    QWORD PTR [rdi+0x9b0],0x0
  40b31d:	mov    QWORD PTR [rdi],rsi
  40b320:	call   40d480 <__swc_fn_fc36583a_000130_375c7357>
  40b325:	mov    QWORD PTR [rdi+0x18],rax
  40b329:	lea    r12,[rsi+0x10]
  40b32d:	mov    rcx,r12
  40b330:	call   4098a0 <__swc_fn_fc36583a_000135_db32cc57>
  40b335:	mov    rax,QWORD PTR [rsi+0x20]
  40b339:	mov    QWORD PTR [rdi+0x8],rax
  40b33d:	mov    rax,QWORD PTR [rsi+0x20]
  40b341:	test   rax,rax
  40b344:	je     40b34a <__swc_fn_fc36583a_000040_8029566e+0x8a>
  40b346:	mov    QWORD PTR [rax+0x10],rdi
  40b34a:	mov    QWORD PTR [rsi+0x20],rdi
  40b34e:	mov    rcx,r12
  40b351:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  40b356:	mov    rax,rdi
  40b359:	pop    r12
  40b35b:	pop    rdi
  40b35c:	pop    rsi
  40b35d:	ret
	...

000000000040b360 <__swc_fn_fc36583a_000043_47ff6d9b>:
  40b360:	mov    rax,QWORD PTR [rdx+0x10]
  40b364:	test   rax,rax
  40b367:	je     40b373 <__swc_fn_fc36583a_000043_47ff6d9b+0x13>
  40b369:	mov    rcx,QWORD PTR [rdx+0x8]
  40b36d:	mov    QWORD PTR [rax+0x8],rcx
  40b371:	jmp    40b37b <__swc_fn_fc36583a_000043_47ff6d9b+0x1b>
  40b373:	mov    rax,QWORD PTR [rdx+0x8]
  40b377:	mov    QWORD PTR [rcx+0x20],rax
  40b37b:	mov    rax,QWORD PTR [rdx+0x8]
  40b37f:	test   rax,rax
  40b382:	je     40b38c <__swc_fn_fc36583a_000043_47ff6d9b+0x2c>
  40b384:	mov    rcx,QWORD PTR [rdx+0x10]
  40b388:	mov    QWORD PTR [rax+0x10],rcx
  40b38c:	vxorps xmm0,xmm0,xmm0
  40b390:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40b395:	ret
	...

000000000040b3a0 <__swc_fn_fc36583a_000046_b28a6ee7>:
  40b3a0:	sub    rsp,0x8
  40b3a4:	mov    r9,r8
  40b3a7:	mov    r10,rdx
  40b3aa:	call   40e430 <__swc_fn_fc36583a_000044_fe6bbfdb>
  40b3af:	mov    eax,0x1
  40b3b4:	xchg   DWORD PTR [r9+0x6c],eax
  40b3b8:	mov    rax,QWORD PTR [r9+0x60]
  40b3bc:	test   rax,rax
  40b3bf:	je     40b403 <__swc_fn_fc36583a_000046_b28a6ee7+0x63>
  40b3c1:	xor    eax,eax
  40b3c3:	xchg   DWORD PTR [r9+0x6c],eax
  40b3c7:	movzx  eax,BYTE PTR [r9+0x39]
  40b3cc:	lea    rax,[rax+rax*4]
  40b3d0:	lea    rax,[r10+rax*8+0x28]
  40b3d5:	mov    QWORD PTR [r9+0x50],0x0
  40b3dd:	mov    rcx,QWORD PTR [rax+0x8]
  40b3e1:	mov    QWORD PTR [r9+0x48],rcx
  40b3e5:	mov    rcx,QWORD PTR [rax+0x8]
  40b3e9:	test   rcx,rcx
  40b3ec:	je     40b3f4 <__swc_fn_fc36583a_000046_b28a6ee7+0x54>
  40b3ee:	mov    QWORD PTR [rcx+0x50],r9
  40b3f2:	jmp    40b3f8 <__swc_fn_fc36583a_000046_b28a6ee7+0x58>
  40b3f4:	mov    QWORD PTR [rax+0x10],r9
  40b3f8:	mov    QWORD PTR [rax+0x8],r9
  40b3fc:	xor    eax,eax
  40b3fe:	add    rsp,0x8
  40b402:	ret
  40b403:	movzx  eax,BYTE PTR [r9+0x39]
  40b408:	lea    rax,[rax+rax*4]
  40b40c:	lea    rax,[r10+rax*8+0x28]
  40b411:	mov    QWORD PTR [r9+0x50],0x0
  40b419:	mov    rcx,QWORD PTR [rax+0x18]
  40b41d:	mov    QWORD PTR [r9+0x48],rcx
  40b421:	mov    rcx,QWORD PTR [rax+0x18]
  40b425:	test   rcx,rcx
  40b428:	je     40b42e <__swc_fn_fc36583a_000046_b28a6ee7+0x8e>
  40b42a:	mov    QWORD PTR [rcx+0x50],r9
  40b42e:	mov    QWORD PTR [rax+0x18],r9
  40b432:	mov    eax,0x1
  40b437:	add    rsp,0x8
  40b43b:	ret
  40b43c:	add    BYTE PTR [rax],al
	...

000000000040b440 <__swc_fn_fc36583a_000049_f6a485a2>:
  40b440:	push   r12
  40b442:	push   r13
  40b444:	push   rdi
  40b445:	push   rsi
  40b446:	push   r14
  40b448:	push   r15
  40b44a:	sub    rsp,0x178
  40b451:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40b45a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40b463:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40b46c:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40b475:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40b47e:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40b487:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40b490:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40b499:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40b4a2:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40b4ab:	mov    r12,rcx
  40b4ae:	lea    rax,[rip+0x18d4b]        # 424200 <__swc_bss_base_fc36583a+0x1c0>
  40b4b5:	mov    rcx,QWORD PTR [rax]
  40b4b8:	mov    r13,rcx
  40b4bb:	test   rcx,rcx
  40b4be:	jne    40b4ce <__swc_fn_fc36583a_000049_f6a485a2+0x8e>
  40b4c0:	mov    r13d,0x1dcd6500
  40b4c6:	mov    ecx,0x1dcd6500
  40b4cb:	xchg   QWORD PTR [rax],rcx
  40b4ce:	lea    rax,[rip+0x16b2b]        # 422000 <__swc_data_base_fc36583a>
  40b4d5:	mov    rax,QWORD PTR [rax]
  40b4d8:	cmp    rax,0xffffffffffffffff
  40b4dc:	je     40b4eb <__swc_fn_fc36583a_000049_f6a485a2+0xab>
  40b4de:	mov    eax,eax
  40b4e0:	mov    edi,eax
  40b4e2:	xor    eax,eax
  40b4e4:	call   407000 <pthread_getspecific@plt>
  40b4e9:	jmp    40b4ed <__swc_fn_fc36583a_000049_f6a485a2+0xad>
  40b4eb:	xor    eax,eax
  40b4ed:	test   rax,rax
  40b4f0:	jne    40b4ff <__swc_fn_fc36583a_000049_f6a485a2+0xbf>
  40b4f2:	call   40b1a0 <__swc_fn_fc36583a_000031_3c3e930e>
  40b4f7:	mov    rcx,rax
  40b4fa:	call   410460 <__swc_fn_fc36583a_000128_8d8a7dd2>
  40b4ff:	test   rax,rax
  40b502:	je     40b514 <__swc_fn_fc36583a_000049_f6a485a2+0xd4>
  40b504:	cmp    QWORD PTR [rax],r12
  40b507:	jne    40b514 <__swc_fn_fc36583a_000049_f6a485a2+0xd4>
  40b509:	cmp    DWORD PTR [rax+0x20],0x0
  40b50d:	jne    40b514 <__swc_fn_fc36583a_000049_f6a485a2+0xd4>
  40b50f:	mov    rsi,rax
  40b512:	jmp    40b516 <__swc_fn_fc36583a_000049_f6a485a2+0xd6>
  40b514:	xor    esi,esi
  40b516:	lea    rdi,[r12+0x2a88]
  40b51e:	mov    r14,QWORD PTR [rdi]
  40b521:	test   r14,r14
  40b524:	jne    40b573 <__swc_fn_fc36583a_000049_f6a485a2+0x133>
  40b526:	lea    rax,[rip+0x18b2b]        # 424058 <__swc_bss_base_fc36583a+0x18>
  40b52d:	mov    rax,QWORD PTR [rax]
  40b530:	test   rax,rax
  40b533:	setne  al
  40b536:	jne    40b55a <__swc_fn_fc36583a_000049_f6a485a2+0x11a>
  40b538:	mov    rax,QWORD PTR [r12+0x2a70]
  40b540:	test   rax,rax
  40b543:	setne  al
  40b546:	jne    40b55a <__swc_fn_fc36583a_000049_f6a485a2+0x11a>
  40b548:	test   rsi,rsi
  40b54b:	setne  al
  40b54e:	je     40b55a <__swc_fn_fc36583a_000049_f6a485a2+0x11a>
  40b550:	cmp    DWORD PTR [rsi+0x730],0x0
  40b557:	setne  al
  40b55a:	test   al,al
  40b55c:	je     40b56e <__swc_fn_fc36583a_000049_f6a485a2+0x12e>
  40b55e:	call   410510 <__swc_fn_fc36583a_000131_91db8856>
  40b563:	lea    rcx,[rax+r13*1]
  40b567:	xor    eax,eax
  40b569:	lock cmpxchg QWORD PTR [rdi],rcx
  40b56e:	jmp    40b673 <__swc_fn_fc36583a_000049_f6a485a2+0x233>
  40b573:	call   410510 <__swc_fn_fc36583a_000131_91db8856>
  40b578:	mov    r15,rax
  40b57b:	cmp    rax,r14
  40b57e:	jb     40b58f <__swc_fn_fc36583a_000049_f6a485a2+0x14f>
  40b580:	xor    ecx,ecx
  40b582:	mov    rax,r14
  40b585:	lock cmpxchg QWORD PTR [rdi],rcx
  40b58a:	cmp    rax,r14
  40b58d:	je     40b594 <__swc_fn_fc36583a_000049_f6a485a2+0x154>
  40b58f:	jmp    40b673 <__swc_fn_fc36583a_000049_f6a485a2+0x233>
  40b594:	test   rsi,rsi
  40b597:	je     40b5b2 <__swc_fn_fc36583a_000049_f6a485a2+0x172>
  40b599:	cmp    r15,r13
  40b59c:	jb     40b5b2 <__swc_fn_fc36583a_000049_f6a485a2+0x172>
  40b59e:	mov    rax,r15
  40b5a1:	sub    rax,r13
  40b5a4:	mov    rcx,r12
  40b5a7:	mov    rdx,rsi
  40b5aa:	mov    r8,rax
  40b5ad:	call   40e870 <__swc_fn_fc36583a_000059_ee6a254c>
  40b5b2:	lea    rsi,[r12+0x10]
  40b5b7:	mov    rcx,rsi
  40b5ba:	call   4098a0 <__swc_fn_fc36583a_000135_db32cc57>
  40b5bf:	mov    rax,QWORD PTR [r12+0x18]
  40b5c4:	mov    rdi,rax
  40b5c7:	test   rdi,rdi
  40b5ca:	je     40b5f4 <__swc_fn_fc36583a_000049_f6a485a2+0x1b4>
  40b5cc:	cs nop WORD PTR [rax+rax*1+0x0]
  40b5d6:	cs nop WORD PTR [rax+rax*1+0x0]
  40b5e0:	mov    rcx,rdi
  40b5e3:	call   407470 <__swc_fn_fc36583a_000015_96cb1311>
  40b5e8:	mov    rax,QWORD PTR [rdi+0x10]
  40b5ec:	mov    rdi,rax
  40b5ef:	test   rax,rax
  40b5f2:	jne    40b5e0 <__swc_fn_fc36583a_000049_f6a485a2+0x1a0>
  40b5f4:	mov    rcx,rsi
  40b5f7:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  40b5fc:	mov    rcx,r12
  40b5ff:	call   4098a0 <__swc_fn_fc36583a_000135_db32cc57>
  40b604:	xor    esi,esi
  40b606:	cs nop WORD PTR [rax+rax*1+0x0]
  40b610:	mov    rax,QWORD PTR [r12+0x2a70]
  40b618:	cmp    rsi,rax
  40b61b:	jae    40b66b <__swc_fn_fc36583a_000049_f6a485a2+0x22b>
  40b61d:	lea    rax,[rsi+rsi*4]
  40b621:	lea    rax,[r12+rax*8+0x268]
  40b629:	mov    r8,QWORD PTR [rax]
  40b62c:	mov    r9,QWORD PTR [rax+0x8]
  40b630:	mov    r10,QWORD PTR [rax+0x10]
  40b634:	mov    rax,QWORD PTR [rax+0x20]
  40b638:	cmp    rax,r15
  40b63b:	jae    40b648 <__swc_fn_fc36583a_000049_f6a485a2+0x208>
  40b63d:	mov    rcx,r15
  40b640:	sub    rcx,rax
  40b643:	cmp    rcx,r13
  40b646:	jae    40b64d <__swc_fn_fc36583a_000049_f6a485a2+0x20d>
  40b648:	inc    rsi
  40b64b:	jmp    40b610 <__swc_fn_fc36583a_000049_f6a485a2+0x1d0>
  40b64d:	mov    rcx,r12
  40b650:	mov    rdx,rsi
  40b653:	call   40e820 <__swc_fn_fc36583a_000056_87dc216f>
  40b658:	mov    rcx,r12
  40b65b:	mov    rdx,r8
  40b65e:	mov    r8,r9
  40b661:	mov    r9,r10
  40b664:	call   407750 <__swc_fn_fc36583a_000039_9ae4348f>
  40b669:	jmp    40b610 <__swc_fn_fc36583a_000049_f6a485a2+0x1d0>
  40b66b:	mov    rcx,r12
  40b66e:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  40b673:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40b67c:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40b685:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40b68e:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40b697:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40b6a0:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40b6a9:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40b6b2:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40b6bb:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40b6c4:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40b6cd:	add    rsp,0x178
  40b6d4:	pop    r15
  40b6d6:	pop    r14
  40b6d8:	pop    rsi
  40b6d9:	pop    rdi
  40b6da:	pop    r13
  40b6dc:	pop    r12
  40b6de:	ret
	...

000000000040b6e0 <__swc_fn_fc36583a_000052_92b016ae>:
  40b6e0:	lea    rax,[rdx-0x58]
  40b6e4:	ret
	...

000000000040b6f0 <__swc_fn_fc36583a_000055_ddf32775>:
  40b6f0:	push   rsi
  40b6f1:	push   rdi
  40b6f2:	push   r12
  40b6f4:	push   r13
  40b6f6:	sub    rsp,0x68
  40b6fa:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40b700:	mov    rsi,r9
  40b703:	mov    rdi,rcx
  40b706:	mov    r12,rdx
  40b709:	mov    r13,r8
  40b70c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40b714:	jne    40b723 <__swc_fn_fc36583a_000055_ddf32775+0x33>
  40b716:	xor    eax,eax
  40b718:	add    rsp,0x68
  40b71c:	pop    r13
  40b71e:	pop    r12
  40b720:	pop    rdi
  40b721:	pop    rsi
  40b722:	ret
  40b723:	mov    rcx,rdi
  40b726:	call   4098a0 <__swc_fn_fc36583a_000135_db32cc57>
  40b72b:	movabs rax,0x7fffffffffffffff
  40b735:	cmp    r12,rax
  40b738:	mov    rax,0xffffffffffffffff
  40b73f:	lea    rcx,[r12+r12*1]
  40b743:	cmovbe rax,rcx
  40b747:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40b74e:	mov    rdx,rcx
  40b751:	sub    rax,r12
  40b754:	inc    rax
  40b757:	xor    r8d,r8d
  40b75a:	test   rcx,rcx
  40b75d:	jbe    40b788 <__swc_fn_fc36583a_000055_ddf32775+0x98>
  40b75f:	nop
  40b760:	lea    r9,[r8+r8*4]
  40b764:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40b76c:	sub    r9,r12
  40b76f:	cmp    r9,rax
  40b772:	jae    40b77f <__swc_fn_fc36583a_000055_ddf32775+0x8f>
  40b774:	mov    rdx,r8
  40b777:	mov    rax,r9
  40b77a:	test   r9,r9
  40b77d:	je     40b788 <__swc_fn_fc36583a_000055_ddf32775+0x98>
  40b77f:	add    r8,0x1
  40b783:	cmp    r8,rcx
  40b786:	jb     40b760 <__swc_fn_fc36583a_000055_ddf32775+0x70>
  40b788:	mov    rax,QWORD PTR [rdi+0x2a70]
  40b78f:	cmp    rdx,rax
  40b792:	jne    40b7af <__swc_fn_fc36583a_000055_ddf32775+0xbf>
  40b794:	mov    rcx,rdi
  40b797:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  40b79c:	xor    eax,eax
  40b79e:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b7a4:	add    rsp,0x68
  40b7a8:	pop    r13
  40b7aa:	pop    r12
  40b7ac:	pop    rdi
  40b7ad:	pop    rsi
  40b7ae:	ret
  40b7af:	lea    rax,[rdx+rdx*4]
  40b7b3:	lea    rax,[rdi+rax*8+0x268]
  40b7bb:	vmovups xmm6,XMMWORD PTR [rax]
  40b7bf:	mov    r8,QWORD PTR [rax+0x10]
  40b7c3:	mov    rcx,rdi
  40b7c6:	call   40e820 <__swc_fn_fc36583a_000056_87dc216f>
  40b7cb:	vpshufd xmm0,xmm6,0xee
  40b7d0:	vmovsd QWORD PTR [r13+0x0],xmm0
  40b7d6:	mov    QWORD PTR [rsi],r8
  40b7d9:	mov    rcx,rdi
  40b7dc:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  40b7e1:	vmovq  rax,xmm6
  40b7e6:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b7ec:	add    rsp,0x68
  40b7f0:	pop    r13
  40b7f2:	pop    r12
  40b7f4:	pop    rdi
  40b7f5:	pop    rsi
  40b7f6:	ret
	...

000000000040b800 <__swc_fn_fc36583a_000058_01964a17>:
  40b800:	push   r12
  40b802:	push   r13
  40b804:	push   r14
  40b806:	push   r15
  40b808:	push   rdi
  40b809:	push   rsi
  40b80a:	sub    rsp,0x148
  40b811:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40b81a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40b823:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40b82c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40b835:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40b83e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40b847:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40b850:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40b859:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40b862:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40b86b:	mov    r12,r9
  40b86e:	mov    r13,rcx
  40b871:	mov    r14,rdx
  40b874:	mov    r15,r8
  40b877:	test   rdx,rdx
  40b87a:	jne    40b88e <__swc_fn_fc36583a_000058_01964a17+0x8e>
  40b87c:	add    rsp,0x148
  40b883:	pop    rsi
  40b884:	pop    rdi
  40b885:	pop    r15
  40b887:	pop    r14
  40b889:	pop    r13
  40b88b:	pop    r12
  40b88d:	ret
  40b88e:	cmp    r12,0x200000
  40b895:	ja     40b927 <__swc_fn_fc36583a_000058_01964a17+0x127>
  40b89b:	lea    rax,[rip+0x1675e]        # 422000 <__swc_data_base_fc36583a>
  40b8a2:	mov    rax,QWORD PTR [rax]
  40b8a5:	cmp    rax,0xffffffffffffffff
  40b8a9:	je     40b8b8 <__swc_fn_fc36583a_000058_01964a17+0xb8>
  40b8ab:	mov    eax,eax
  40b8ad:	mov    edi,eax
  40b8af:	xor    eax,eax
  40b8b1:	call   407000 <pthread_getspecific@plt>
  40b8b6:	jmp    40b8ba <__swc_fn_fc36583a_000058_01964a17+0xba>
  40b8b8:	xor    eax,eax
  40b8ba:	test   rax,rax
  40b8bd:	je     40b8c4 <__swc_fn_fc36583a_000058_01964a17+0xc4>
  40b8bf:	mov    rsi,rax
  40b8c2:	jmp    40b8d4 <__swc_fn_fc36583a_000058_01964a17+0xd4>
  40b8c4:	call   40b1a0 <__swc_fn_fc36583a_000031_3c3e930e>
  40b8c9:	mov    rcx,rax
  40b8cc:	call   410460 <__swc_fn_fc36583a_000128_8d8a7dd2>
  40b8d1:	mov    rsi,rax
  40b8d4:	test   rsi,rsi
  40b8d7:	je     40b927 <__swc_fn_fc36583a_000058_01964a17+0x127>
  40b8d9:	cmp    QWORD PTR [rsi],r13
  40b8dc:	jne    40b927 <__swc_fn_fc36583a_000058_01964a17+0x127>
  40b8de:	cmp    DWORD PTR [rsi+0x20],0x0
  40b8e2:	jne    40b927 <__swc_fn_fc36583a_000058_01964a17+0x127>
  40b8e4:	cmp    DWORD PTR [rsi+0x730],0x10
  40b8eb:	jae    40b927 <__swc_fn_fc36583a_000058_01964a17+0x127>
  40b8ed:	mov    eax,DWORD PTR [rsi+0x730]
  40b8f3:	lea    rdi,[rax+rax*4]
  40b8f7:	lea    rdi,[rsi+rdi*8+0x738]
  40b8ff:	mov    QWORD PTR [rdi],r14
  40b902:	mov    QWORD PTR [rdi+0x8],r15
  40b906:	mov    QWORD PTR [rdi+0x10],r12
  40b90a:	mov    QWORD PTR [rdi+0x18],0x0
  40b912:	call   410510 <__swc_fn_fc36583a_000131_91db8856>
  40b917:	mov    QWORD PTR [rdi+0x20],rax
  40b91b:	add    DWORD PTR [rsi+0x730],0x1
  40b922:	jmp    40ba86 <__swc_fn_fc36583a_000058_01964a17+0x286>
  40b927:	mov    rcx,r13
  40b92a:	call   407e90 <__swc_fn_fc36583a_000057_01c75a1d>
  40b92f:	mov    rsi,rax
  40b932:	cmp    r12,rax
  40b935:	jbe    40b96a <__swc_fn_fc36583a_000058_01964a17+0x16a>
  40b937:	cmp    r12,0x10000000
  40b93e:	seta   al
  40b941:	ja     40b950 <__swc_fn_fc36583a_000058_01964a17+0x150>
  40b943:	mov    rax,QWORD PTR [r13+0x2a70]
  40b94a:	test   rax,rax
  40b94d:	setne  al
  40b950:	test   al,al
  40b952:	je     40b96a <__swc_fn_fc36583a_000058_01964a17+0x16a>
  40b954:	mov    rcx,r13
  40b957:	mov    rdx,r14
  40b95a:	mov    r8,r15
  40b95d:	mov    r9,r12
  40b960:	call   407750 <__swc_fn_fc36583a_000039_9ae4348f>
  40b965:	jmp    40ba86 <__swc_fn_fc36583a_000058_01964a17+0x286>
  40b96a:	call   410510 <__swc_fn_fc36583a_000131_91db8856>
  40b96f:	mov    rdi,rax
  40b972:	mov    rcx,r13
  40b975:	call   4098a0 <__swc_fn_fc36583a_000135_db32cc57>
  40b97a:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b982:	je     40ba3a <__swc_fn_fc36583a_000058_01964a17+0x23a>
  40b988:	nop    DWORD PTR [rax+rax*1+0x0]
  40b990:	cmp    QWORD PTR [r13+0x2a70],0x100
  40b99b:	jae    40b9b0 <__swc_fn_fc36583a_000058_01964a17+0x1b0>
  40b99d:	mov    rax,QWORD PTR [r13+0x2a68]
  40b9a4:	add    rax,r12
  40b9a7:	cmp    rax,rsi
  40b9aa:	jbe    40ba3a <__swc_fn_fc36583a_000058_01964a17+0x23a>
  40b9b0:	xor    eax,eax
  40b9b2:	mov    rcx,QWORD PTR [r13+0x2a70]
  40b9b9:	mov    edx,0x1
  40b9be:	cmp    rcx,0x1
  40b9c2:	jbe    40b9f9 <__swc_fn_fc36583a_000058_01964a17+0x1f9>
  40b9c4:	cs nop WORD PTR [rax+rax*1+0x0]
  40b9ce:	xchg   ax,ax
  40b9d0:	lea    r8,[rdx+rdx*4]
  40b9d4:	lea    r8,[r13+r8*8+0x268]
  40b9dc:	lea    r9,[rax+rax*4]
  40b9e0:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40b9e8:	cmp    QWORD PTR [r8+0x18],r9
  40b9ec:	cmovb  rax,rdx
  40b9f0:	add    rdx,0x1
  40b9f4:	cmp    rdx,rcx
  40b9f7:	jb     40b9d0 <__swc_fn_fc36583a_000058_01964a17+0x1d0>
  40b9f9:	lea    rcx,[rax+rax*4]
  40b9fd:	lea    rcx,[r13+rcx*8+0x268]
  40ba05:	mov    r8,QWORD PTR [rcx]
  40ba08:	mov    r9,QWORD PTR [rcx+0x8]
  40ba0c:	mov    r10,QWORD PTR [rcx+0x10]
  40ba10:	mov    rcx,r13
  40ba13:	mov    rdx,rax
  40ba16:	call   40e820 <__swc_fn_fc36583a_000056_87dc216f>
  40ba1b:	mov    rcx,r13
  40ba1e:	mov    rdx,r8
  40ba21:	mov    r8,r9
  40ba24:	mov    r9,r10
  40ba27:	call   407750 <__swc_fn_fc36583a_000039_9ae4348f>
  40ba2c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40ba34:	jne    40b990 <__swc_fn_fc36583a_000058_01964a17+0x190>
  40ba3a:	add    QWORD PTR [r13+0x2a78],0x1
  40ba42:	mov    rax,QWORD PTR [r13+0x2a70]
  40ba49:	lea    rax,[rax+rax*4]
  40ba4d:	lea    rax,[r13+rax*8+0x268]
  40ba55:	mov    QWORD PTR [rax],r14
  40ba58:	mov    QWORD PTR [rax+0x8],r15
  40ba5c:	mov    QWORD PTR [rax+0x10],r12
  40ba60:	mov    rcx,QWORD PTR [r13+0x2a78]
  40ba67:	mov    QWORD PTR [rax+0x18],rcx
  40ba6b:	mov    QWORD PTR [rax+0x20],rdi
  40ba6f:	add    QWORD PTR [r13+0x2a68],r12
  40ba76:	add    QWORD PTR [r13+0x2a70],0x1
  40ba7e:	mov    rcx,r13
  40ba81:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  40ba86:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40ba8f:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40ba98:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40baa1:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40baaa:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40bab3:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40babc:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40bac5:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40bace:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40bad7:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40bae0:	add    rsp,0x148
  40bae7:	pop    rsi
  40bae8:	pop    rdi
  40bae9:	pop    r15
  40baeb:	pop    r14
  40baed:	pop    r13
  40baef:	pop    r12
  40baf1:	ret
	...

000000000040bb00 <__swc_fn_fc36583a_000061_73a9baa2>:
  40bb00:	push   rbx
  40bb01:	push   r12
  40bb03:	push   r13
  40bb05:	push   r14
  40bb07:	push   r15
  40bb09:	push   rdi
  40bb0a:	push   rsi
  40bb0b:	sub    rsp,0xf0
  40bb12:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40bb18:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40bb1e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40bb24:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40bb2a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40bb33:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40bb3c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40bb45:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40bb4e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40bb57:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40bb60:	mov    eax,r8d
  40bb63:	mov    rbx,rcx
  40bb66:	mov    r12,rdx
  40bb69:	mov    QWORD PTR [rsp+0x18],rdx
  40bb6e:	mov    ecx,DWORD PTR [r12+0x58]
  40bb73:	mov    r13d,ecx
  40bb76:	cmp    ecx,0x10
  40bb79:	mov    ecx,0x10
  40bb7e:	cmovb  r13d,ecx
  40bb82:	test   r13d,r13d
  40bb85:	mov    rcx,r13
  40bb88:	mov    edx,0x8
  40bb8d:	cmove  ecx,edx
  40bb90:	dec    rcx
  40bb93:	mov    rdx,0xffffffffffffffff
  40bb9a:	sub    rdx,rcx
  40bb9d:	xor    r14d,r14d
  40bba0:	mov    r8,rcx
  40bba3:	not    r8
  40bba6:	lea    rcx,[rcx+0x58]
  40bbaa:	and    rcx,r8
  40bbad:	cmp    rdx,0x58
  40bbb1:	cmovae r14,rcx
  40bbb5:	cmp    eax,0xffffffff
  40bbb8:	jne    40bbc1 <__swc_fn_fc36583a_000061_73a9baa2+0xc1>
  40bbba:	mov    r15,QWORD PTR [r12+0x48]
  40bbbf:	jmp    40bbf3 <__swc_fn_fc36583a_000061_73a9baa2+0xf3>
  40bbc1:	test   eax,eax
  40bbc3:	jne    40bbcc <__swc_fn_fc36583a_000061_73a9baa2+0xcc>
  40bbc5:	mov    eax,0x8
  40bbca:	jmp    40bbf0 <__swc_fn_fc36583a_000061_73a9baa2+0xf0>
  40bbcc:	cmp    eax,0x8
  40bbcf:	ja     40bbd7 <__swc_fn_fc36583a_000061_73a9baa2+0xd7>
  40bbd1:	shl    rax,0x4
  40bbd5:	jmp    40bbf0 <__swc_fn_fc36583a_000061_73a9baa2+0xf0>
  40bbd7:	lea    eax,[rax-0x9]
  40bbda:	mov    ecx,eax
  40bbdc:	shr    ecx,0x2
  40bbdf:	and    eax,0x3
  40bbe2:	lea    ecx,[rcx+0x7]
  40bbe5:	lea    ecx,[rcx-0x2]
  40bbe8:	lea    eax,[rax+0x5]
  40bbeb:	shlx   rax,rax,rcx
  40bbf0:	mov    r15,rax
  40bbf3:	lea    rax,[r14+r13*1]
  40bbf7:	mov    rcx,0xffffffffffffffff
  40bbfe:	sub    rcx,rax
  40bc01:	cmp    r15,rcx
  40bc04:	jbe    40bc14 <__swc_fn_fc36583a_000061_73a9baa2+0x114>
  40bc06:	mov    QWORD PTR [r12+0x40],0x0
  40bc0f:	jmp    40bfe6 <__swc_fn_fc36583a_000061_73a9baa2+0x4e6>
  40bc14:	mov    QWORD PTR [rsp+0x20],r13
  40bc19:	lea    r13,[rsp+0x8]
  40bc1e:	add    rax,r15
  40bc21:	mov    ecx,0x1000
  40bc26:	test   ecx,ecx
  40bc28:	mov    edx,0x8
  40bc2d:	cmove  ecx,edx
  40bc30:	dec    rcx
  40bc33:	mov    rdx,0xffffffffffffffff
  40bc3a:	sub    rdx,rcx
  40bc3d:	cmp    rax,rdx
  40bc40:	jbe    40bc4c <__swc_fn_fc36583a_000061_73a9baa2+0x14c>
  40bc42:	mov    QWORD PTR [r13+0x0],0x0
  40bc4a:	jmp    40bc59 <__swc_fn_fc36583a_000061_73a9baa2+0x159>
  40bc4c:	add    rax,rcx
  40bc4f:	andn   rax,rcx,rax
  40bc54:	mov    QWORD PTR [rsp+0x8],rax
  40bc59:	cmp    QWORD PTR [r13+0x0],0x0
  40bc5e:	jne    40bc6e <__swc_fn_fc36583a_000061_73a9baa2+0x16e>
  40bc60:	mov    QWORD PTR [r12+0x40],0x0
  40bc69:	jmp    40bfe6 <__swc_fn_fc36583a_000061_73a9baa2+0x4e6>
  40bc6e:	mov    QWORD PTR [rsp+0x30],r15
  40bc73:	xor    r15d,r15d
  40bc76:	mov    QWORD PTR [rsp+0x38],0x0
  40bc7f:	lea    r12,[rsp+0x10]
  40bc84:	mov    QWORD PTR [rsp+0x28],r14
  40bc89:	mov    r14,QWORD PTR [rsp+0x8]
  40bc8e:	mov    QWORD PTR [rsp+0x10],r14
  40bc93:	cmp    r14,0x10000
  40bc9a:	ja     40bca1 <__swc_fn_fc36583a_000061_73a9baa2+0x1a1>
  40bc9c:	mov    rax,r14
  40bc9f:	jmp    40bcf2 <__swc_fn_fc36583a_000061_73a9baa2+0x1f2>
  40bca1:	xor    eax,eax
  40bca3:	lea    rcx,[r14-0x1]
  40bca7:	lzcnt  rax,rcx
  40bcac:	mov    ecx,0x3f
  40bcb1:	sub    rcx,rax
  40bcb4:	mov    eax,0x1
  40bcb9:	lea    rcx,[rcx-0x3]
  40bcbd:	shl    rax,cl
  40bcc0:	mov    rcx,rax
  40bcc3:	cmp    rax,0x1000
  40bcca:	mov    eax,0x1000
  40bccf:	cmovb  rcx,rax
  40bcd3:	mov    rdx,0xffffffffffffffff
  40bcda:	sub    rdx,rcx
  40bcdd:	mov    rax,r14
  40bce0:	lea    r8,[r14+rcx*1-0x1]
  40bce5:	neg    rcx
  40bce8:	and    r8,rcx
  40bceb:	cmp    r14,rdx
  40bcee:	cmovbe rax,r8
  40bcf2:	mov    QWORD PTR [rsp+0x8],rax
  40bcf7:	lea    rax,[rip+0x16302]        # 422000 <__swc_data_base_fc36583a>
  40bcfe:	mov    rax,QWORD PTR [rax]
  40bd01:	cmp    rax,0xffffffffffffffff
  40bd05:	je     40bd14 <__swc_fn_fc36583a_000061_73a9baa2+0x214>
  40bd07:	mov    eax,eax
  40bd09:	mov    edi,eax
  40bd0b:	xor    eax,eax
  40bd0d:	call   407000 <pthread_getspecific@plt>
  40bd12:	jmp    40bd16 <__swc_fn_fc36583a_000061_73a9baa2+0x216>
  40bd14:	xor    eax,eax
  40bd16:	test   rax,rax
  40bd19:	jne    40bd28 <__swc_fn_fc36583a_000061_73a9baa2+0x228>
  40bd1b:	call   40b1a0 <__swc_fn_fc36583a_000031_3c3e930e>
  40bd20:	mov    rcx,rax
  40bd23:	call   410460 <__swc_fn_fc36583a_000128_8d8a7dd2>
  40bd28:	test   rax,rax
  40bd2b:	je     40be1c <__swc_fn_fc36583a_000061_73a9baa2+0x31c>
  40bd31:	cmp    QWORD PTR [rax],rbx
  40bd34:	jne    40be1c <__swc_fn_fc36583a_000061_73a9baa2+0x31c>
  40bd3a:	cmp    DWORD PTR [rax+0x20],0x0
  40bd3e:	jne    40be1c <__swc_fn_fc36583a_000061_73a9baa2+0x31c>
  40bd44:	mov    rcx,QWORD PTR [rsp+0x8]
  40bd49:	movabs rdx,0x7fffffffffffffff
  40bd53:	cmp    rcx,rdx
  40bd56:	mov    rdx,0xffffffffffffffff
  40bd5d:	lea    r8,[rcx+rcx*1]
  40bd61:	cmovbe rdx,r8
  40bd65:	mov    r8d,DWORD PTR [rax+0x730]
  40bd6c:	mov    r9d,r8d
  40bd6f:	sub    rdx,rcx
  40bd72:	inc    rdx
  40bd75:	xor    r10d,r10d
  40bd78:	test   r8,r8
  40bd7b:	jbe    40bdab <__swc_fn_fc36583a_000061_73a9baa2+0x2ab>
  40bd7d:	nop    DWORD PTR [rax]
  40bd80:	mov    r11d,r10d
  40bd83:	lea    r11,[r11+r11*4]
  40bd87:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40bd8f:	sub    r11,rcx
  40bd92:	cmp    r11,rdx
  40bd95:	jae    40bda2 <__swc_fn_fc36583a_000061_73a9baa2+0x2a2>
  40bd97:	mov    r9d,r10d
  40bd9a:	mov    rdx,r11
  40bd9d:	test   r11,r11
  40bda0:	je     40bdab <__swc_fn_fc36583a_000061_73a9baa2+0x2ab>
  40bda2:	add    r10,0x1
  40bda6:	cmp    r10,r8
  40bda9:	jb     40bd80 <__swc_fn_fc36583a_000061_73a9baa2+0x280>
  40bdab:	mov    ecx,DWORD PTR [rax+0x730]
  40bdb1:	cmp    r9d,ecx
  40bdb4:	jne    40bdba <__swc_fn_fc36583a_000061_73a9baa2+0x2ba>
  40bdb6:	xor    eax,eax
  40bdb8:	jmp    40be19 <__swc_fn_fc36583a_000061_73a9baa2+0x319>
  40bdba:	lea    rcx,[r9+r9*4]
  40bdbe:	lea    rcx,[rax+rcx*8+0x738]
  40bdc6:	vmovups xmm0,XMMWORD PTR [rcx]
  40bdca:	mov    rdx,QWORD PTR [rcx+0x10]
  40bdce:	sub    DWORD PTR [rax+0x730],0x1
  40bdd5:	mov    r8d,DWORD PTR [rax+0x730]
  40bddc:	lea    r8,[r8+r8*4]
  40bde0:	lea    r8,[rax+r8*8+0x738]
  40bde8:	vmovups xmm1,XMMWORD PTR [r8]
  40bded:	vmovups XMMWORD PTR [rcx],xmm1
  40bdf1:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40bdf7:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40bdfc:	mov    rax,QWORD PTR [r8+0x20]
  40be00:	mov    QWORD PTR [rcx+0x20],rax
  40be04:	vpshufd xmm1,xmm0,0xee
  40be09:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40be0f:	mov    QWORD PTR [rsp+0x10],rdx
  40be14:	vmovq  rax,xmm0
  40be19:	mov    r15,rax
  40be1c:	test   r15,r15
  40be1f:	jne    40be37 <__swc_fn_fc36583a_000061_73a9baa2+0x337>
  40be21:	mov    rcx,rbx
  40be24:	mov    rdx,QWORD PTR [rsp+0x8]
  40be29:	mov    r8,r13
  40be2c:	mov    r9,r12
  40be2f:	call   40b6f0 <__swc_fn_fc36583a_000055_ddf32775>
  40be34:	mov    r15,rax
  40be37:	test   r15,r15
  40be3a:	je     40be7b <__swc_fn_fc36583a_000061_73a9baa2+0x37b>
  40be3c:	cmp    QWORD PTR [r12],r14
  40be40:	jae    40be7b <__swc_fn_fc36583a_000061_73a9baa2+0x37b>
  40be42:	mov    rax,r15
  40be45:	add    rax,QWORD PTR [r12]
  40be49:	mov    rdx,r14
  40be4c:	sub    rdx,QWORD PTR [r12]
  40be50:	mov    rcx,rax
  40be53:	call   4072a0 <__swc_fn_fc36583a_000003_81215399>
  40be58:	test   al,al
  40be5a:	je     40be63 <__swc_fn_fc36583a_000061_73a9baa2+0x363>
  40be5c:	mov    QWORD PTR [rsp+0x10],r14
  40be61:	jmp    40be7b <__swc_fn_fc36583a_000061_73a9baa2+0x37b>
  40be63:	mov    rcx,rbx
  40be66:	mov    rdx,r15
  40be69:	mov    r8,QWORD PTR [rsp+0x8]
  40be6e:	mov    r9,QWORD PTR [rsp+0x10]
  40be73:	call   40b800 <__swc_fn_fc36583a_000058_01964a17>
  40be78:	xor    r15d,r15d
  40be7b:	test   r15,r15
  40be7e:	jne    40befa <__swc_fn_fc36583a_000061_73a9baa2+0x3fa>
  40be80:	cmp    r14,0x10000
  40be87:	ja     40be8e <__swc_fn_fc36583a_000061_73a9baa2+0x38e>
  40be89:	mov    rax,r14
  40be8c:	jmp    40bedf <__swc_fn_fc36583a_000061_73a9baa2+0x3df>
  40be8e:	xor    eax,eax
  40be90:	lea    rcx,[r14-0x1]
  40be94:	lzcnt  rax,rcx
  40be99:	mov    ecx,0x3f
  40be9e:	sub    rcx,rax
  40bea1:	mov    eax,0x1
  40bea6:	lea    rcx,[rcx-0x3]
  40beaa:	shl    rax,cl
  40bead:	mov    rcx,rax
  40beb0:	cmp    rax,0x1000
  40beb7:	mov    eax,0x1000
  40bebc:	cmovb  rcx,rax
  40bec0:	mov    rdx,0xffffffffffffffff
  40bec7:	sub    rdx,rcx
  40beca:	mov    rax,r14
  40becd:	lea    r8,[r14+rcx*1-0x1]
  40bed2:	neg    rcx
  40bed5:	and    r8,rcx
  40bed8:	cmp    r14,rdx
  40bedb:	cmovbe rax,r8
  40bedf:	mov    QWORD PTR [rsp+0x8],rax
  40bee4:	mov    QWORD PTR [rsp+0x10],r14
  40bee9:	mov    rcx,rbx
  40beec:	mov    rdx,rax
  40beef:	mov    r8,r14
  40bef2:	call   40b260 <__swc_fn_fc36583a_000037_1e381f55>
  40bef7:	mov    r15,rax
  40befa:	test   r15,r15
  40befd:	jne    40bf0b <__swc_fn_fc36583a_000061_73a9baa2+0x40b>
  40beff:	mov    r13,QWORD PTR [rsp+0x20]
  40bf04:	mov    rsi,QWORD PTR [rsp+0x38]
  40bf09:	jmp    40bf47 <__swc_fn_fc36583a_000061_73a9baa2+0x447>
  40bf0b:	mov    rax,r15
  40bf0e:	add    rax,QWORD PTR [rsp+0x28]
  40bf13:	mov    r13,QWORD PTR [rsp+0x20]
  40bf18:	test   r13d,r13d
  40bf1b:	mov    rcx,r13
  40bf1e:	mov    edx,0x8
  40bf23:	cmove  ecx,edx
  40bf26:	dec    rcx
  40bf29:	mov    rdx,0xffffffffffffffff
  40bf30:	sub    rdx,rcx
  40bf33:	cmp    rax,rdx
  40bf36:	jbe    40bf3c <__swc_fn_fc36583a_000061_73a9baa2+0x43c>
  40bf38:	xor    eax,eax
  40bf3a:	jmp    40bf44 <__swc_fn_fc36583a_000061_73a9baa2+0x444>
  40bf3c:	add    rax,rcx
  40bf3f:	andn   rax,rcx,rax
  40bf44:	mov    rsi,rax
  40bf47:	mov    rax,QWORD PTR [rsp+0x8]
  40bf4c:	test   r15,r15
  40bf4f:	je     40bf58 <__swc_fn_fc36583a_000061_73a9baa2+0x458>
  40bf51:	mov    rdi,QWORD PTR [rsp+0x18]
  40bf56:	jmp    40bf6a <__swc_fn_fc36583a_000061_73a9baa2+0x46a>
  40bf58:	mov    rdi,QWORD PTR [rsp+0x18]
  40bf5d:	mov    QWORD PTR [rdi+0x40],0x0
  40bf65:	jmp    40bfe6 <__swc_fn_fc36583a_000061_73a9baa2+0x4e6>
  40bf6a:	lea    rdx,[rsi-0x58]
  40bf6e:	mov    QWORD PTR [rsi-0x58],r15
  40bf72:	mov    QWORD PTR [rsi-0x50],rax
  40bf76:	mov    rax,QWORD PTR [rsp+0x10]
  40bf7b:	mov    QWORD PTR [rsi-0x48],rax
  40bf7f:	mov    QWORD PTR [rsi-0x40],rsi
  40bf83:	mov    rax,QWORD PTR [rdi+0x48]
  40bf87:	mov    QWORD PTR [rsi-0x38],rax
  40bf8b:	mov    rax,QWORD PTR [rsp+0x30]
  40bf90:	mov    QWORD PTR [rsi-0x30],rax
  40bf94:	mov    DWORD PTR [rsi-0x10],r13d
  40bf98:	mov    QWORD PTR [rsi-0x28],0x0
  40bfa0:	mov    QWORD PTR [rsi-0x20],0x0
  40bfa8:	add    r15,QWORD PTR [r12]
  40bfac:	sub    r15,rsi
  40bfaf:	mov    QWORD PTR [rsi-0x30],r15
  40bfb3:	mov    rcx,QWORD PTR [rbx+0x250]
  40bfba:	nop    WORD PTR [rax+rax*1+0x0]
  40bfc0:	lea    r8,[rcx+r15*1]
  40bfc4:	mov    rax,rcx
  40bfc7:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40bfd0:	cmp    rax,rcx
  40bfd3:	je     40bfda <__swc_fn_fc36583a_000061_73a9baa2+0x4da>
  40bfd5:	mov    rcx,rax
  40bfd8:	jmp    40bfc0 <__swc_fn_fc36583a_000061_73a9baa2+0x4c0>
  40bfda:	mov    rcx,rbx
  40bfdd:	call   40e790 <__swc_fn_fc36583a_000053_9aa81fa7>
  40bfe2:	mov    QWORD PTR [rdi+0x40],rsi
  40bfe6:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40bfec:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40bff2:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40bff8:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40bffe:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40c007:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40c010:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40c019:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40c022:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40c02b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40c034:	add    rsp,0xf0
  40c03b:	pop    rsi
  40c03c:	pop    rdi
  40c03d:	pop    r15
  40c03f:	pop    r14
  40c041:	pop    r13
  40c043:	pop    r12
  40c045:	pop    rbx
  40c046:	ret
	...

000000000040c050 <__swc_fn_fc36583a_000064_20100e91>:
  40c050:	push   rbx
  40c051:	push   r12
  40c053:	push   rdi
  40c054:	push   rsi
  40c055:	sub    rsp,0xb8
  40c05c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40c062:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40c068:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40c06e:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40c074:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40c07a:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40c080:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40c086:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40c08f:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40c098:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40c0a1:	mov    rbx,rdx
  40c0a4:	mov    r12,rcx
  40c0a7:	cmp    DWORD PTR [rbx+0x58],0x0
  40c0ab:	je     40c0c5 <__swc_fn_fc36583a_000064_20100e91+0x75>
  40c0ad:	mov    eax,DWORD PTR [rbx+0x58]
  40c0b0:	sub    eax,0x1
  40c0b3:	test   DWORD PTR [rbx+0x58],eax
  40c0b6:	je     40c0c5 <__swc_fn_fc36583a_000064_20100e91+0x75>
  40c0b8:	mov    QWORD PTR [rbx+0x40],0x0
  40c0c0:	jmp    40c2d7 <__swc_fn_fc36583a_000064_20100e91+0x287>
  40c0c5:	cmp    QWORD PTR [rbx+0x48],0x0
  40c0ca:	jne    40c0d9 <__swc_fn_fc36583a_000064_20100e91+0x89>
  40c0cc:	mov    QWORD PTR [rbx+0x40],0x0
  40c0d4:	jmp    40c2d7 <__swc_fn_fc36583a_000064_20100e91+0x287>
  40c0d9:	lea    rax,[rsp+0x8]
  40c0de:	mov    rcx,QWORD PTR [rbx+0x48]
  40c0e2:	cmp    rcx,0x8
  40c0e6:	ja     40c0f0 <__swc_fn_fc36583a_000064_20100e91+0xa0>
  40c0e8:	mov    DWORD PTR [rax],0x0
  40c0ee:	jmp    40c14b <__swc_fn_fc36583a_000064_20100e91+0xfb>
  40c0f0:	cmp    rcx,0x80
  40c0f7:	ja     40c107 <__swc_fn_fc36583a_000064_20100e91+0xb7>
  40c0f9:	lea    rcx,[rcx+0xf]
  40c0fd:	shr    rcx,0x4
  40c101:	mov    DWORD PTR [rsp+0x8],ecx
  40c105:	jmp    40c14b <__swc_fn_fc36583a_000064_20100e91+0xfb>
  40c107:	cmp    rcx,0x10000
  40c10e:	jbe    40c118 <__swc_fn_fc36583a_000064_20100e91+0xc8>
  40c110:	mov    DWORD PTR [rax],0xffffffff
  40c116:	jmp    40c14b <__swc_fn_fc36583a_000064_20100e91+0xfb>
  40c118:	dec    rcx
  40c11b:	xor    edx,edx
  40c11d:	lzcnt  rdx,rcx
  40c122:	mov    r8d,0x3f
  40c128:	sub    r8d,edx
  40c12b:	lea    edx,[r8-0x2]
  40c12f:	shrx   rcx,rcx,rdx
  40c134:	and    ecx,0x3
  40c137:	lea    edx,[r8-0x7]
  40c13b:	lea    edx,[rdx*4+0x0]
  40c142:	lea    edx,[rdx+0x9]
  40c145:	add    edx,ecx
  40c147:	mov    DWORD PTR [rsp+0x8],edx
  40c14b:	cmp    DWORD PTR [rax],0x0
  40c14e:	jne    40c15e <__swc_fn_fc36583a_000064_20100e91+0x10e>
  40c150:	cmp    DWORD PTR [rbx+0x58],0x8
  40c154:	jbe    40c15e <__swc_fn_fc36583a_000064_20100e91+0x10e>
  40c156:	mov    DWORD PTR [rsp+0x8],0x1
  40c15e:	cmp    DWORD PTR [rbx+0x58],0x10
  40c162:	jbe    40c1e1 <__swc_fn_fc36583a_000064_20100e91+0x191>
  40c168:	cmp    DWORD PTR [rbx+0x58],0x40
  40c16c:	ja     40c1e1 <__swc_fn_fc36583a_000064_20100e91+0x191>
  40c16e:	cmp    DWORD PTR [rax],0xffffffff
  40c171:	je     40c1e1 <__swc_fn_fc36583a_000064_20100e91+0x191>
  40c173:	mov    ecx,DWORD PTR [rsp+0x8]
  40c177:	mov    edx,DWORD PTR [rbx+0x58]
  40c17a:	dec    rdx
  40c17d:	cmp    ecx,0x2d
  40c180:	jae    40c1d8 <__swc_fn_fc36583a_000064_20100e91+0x188>
  40c182:	cs nop WORD PTR [rax+rax*1+0x0]
  40c18c:	nop    DWORD PTR [rax+0x0]
  40c190:	mov    r8d,ecx
  40c193:	test   ecx,ecx
  40c195:	jne    40c19f <__swc_fn_fc36583a_000064_20100e91+0x14f>
  40c197:	mov    r8d,0x8
  40c19d:	jmp    40c1cb <__swc_fn_fc36583a_000064_20100e91+0x17b>
  40c19f:	cmp    r8d,0x8
  40c1a3:	ja     40c1ab <__swc_fn_fc36583a_000064_20100e91+0x15b>
  40c1a5:	shl    r8,0x4
  40c1a9:	jmp    40c1cb <__swc_fn_fc36583a_000064_20100e91+0x17b>
  40c1ab:	lea    r8d,[r8-0x9]
  40c1af:	mov    r9d,r8d
  40c1b2:	shr    r9d,0x2
  40c1b6:	and    r8d,0x3
  40c1ba:	lea    r9d,[r9+0x7]
  40c1be:	lea    r9d,[r9-0x2]
  40c1c2:	lea    r8d,[r8+0x5]
  40c1c6:	shlx   r8,r8,r9
  40c1cb:	test   r8,rdx
  40c1ce:	je     40c1dd <__swc_fn_fc36583a_000064_20100e91+0x18d>
  40c1d0:	add    ecx,0x1
  40c1d3:	cmp    ecx,0x2d
  40c1d6:	jb     40c190 <__swc_fn_fc36583a_000064_20100e91+0x140>
  40c1d8:	mov    ecx,0xffffffff
  40c1dd:	mov    DWORD PTR [rsp+0x8],ecx
  40c1e1:	mov    ecx,DWORD PTR [rsp+0x8]
  40c1e5:	cmp    ecx,0xffffffff
  40c1e8:	je     40c1f0 <__swc_fn_fc36583a_000064_20100e91+0x1a0>
  40c1ea:	cmp    DWORD PTR [rbx+0x58],0x40
  40c1ee:	jbe    40c203 <__swc_fn_fc36583a_000064_20100e91+0x1b3>
  40c1f0:	mov    rcx,r12
  40c1f3:	mov    rdx,rbx
  40c1f6:	mov    r8d,DWORD PTR [rax]
  40c1f9:	call   40bb00 <__swc_fn_fc36583a_000061_73a9baa2>
  40c1fe:	jmp    40c2d7 <__swc_fn_fc36583a_000064_20100e91+0x287>
  40c203:	lea    rax,[rip+0x15df6]        # 422000 <__swc_data_base_fc36583a>
  40c20a:	mov    rax,QWORD PTR [rax]
  40c20d:	cmp    rax,0xffffffffffffffff
  40c211:	je     40c220 <__swc_fn_fc36583a_000064_20100e91+0x1d0>
  40c213:	mov    eax,eax
  40c215:	mov    edi,eax
  40c217:	xor    eax,eax
  40c219:	call   407000 <pthread_getspecific@plt>
  40c21e:	jmp    40c222 <__swc_fn_fc36583a_000064_20100e91+0x1d2>
  40c220:	xor    eax,eax
  40c222:	test   rax,rax
  40c225:	jne    40c234 <__swc_fn_fc36583a_000064_20100e91+0x1e4>
  40c227:	call   40b1a0 <__swc_fn_fc36583a_000031_3c3e930e>
  40c22c:	mov    rcx,rax
  40c22f:	call   410460 <__swc_fn_fc36583a_000128_8d8a7dd2>
  40c234:	test   rax,rax
  40c237:	je     40c244 <__swc_fn_fc36583a_000064_20100e91+0x1f4>
  40c239:	cmp    QWORD PTR [rax],r12
  40c23c:	jne    40c244 <__swc_fn_fc36583a_000064_20100e91+0x1f4>
  40c23e:	cmp    DWORD PTR [rax+0x20],0x0
  40c242:	je     40c24f <__swc_fn_fc36583a_000064_20100e91+0x1ff>
  40c244:	mov    rcx,r12
  40c247:	mov    rdx,rax
  40c24a:	call   40e3d0 <__swc_fn_fc36583a_000041_41400651>
  40c24f:	test   rax,rax
  40c252:	jne    40c25e <__swc_fn_fc36583a_000064_20100e91+0x20e>
  40c254:	mov    QWORD PTR [rbx+0x40],0x0
  40c25c:	jmp    40c2d7 <__swc_fn_fc36583a_000064_20100e91+0x287>
  40c25e:	lea    r8,[rsp+0xc]
  40c263:	mov    ecx,DWORD PTR [rsp+0x8]
  40c267:	mov    DWORD PTR [rsp+0xc],ecx
  40c26b:	mov    ecx,DWORD PTR [r8]
  40c26e:	lea    rcx,[rcx+rcx*4]
  40c272:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40c277:	test   rcx,rcx
  40c27a:	je     40c2b3 <__swc_fn_fc36583a_000064_20100e91+0x263>
  40c27c:	mov    rdx,QWORD PTR [rcx]
  40c27f:	test   rdx,rdx
  40c282:	je     40c290 <__swc_fn_fc36583a_000064_20100e91+0x240>
  40c284:	mov    r9,QWORD PTR [rdx]
  40c287:	mov    QWORD PTR [rcx],r9
  40c28a:	add    DWORD PTR [rcx+0x28],0x1
  40c28e:	jmp    40c2ae <__swc_fn_fc36583a_000064_20100e91+0x25e>
  40c290:	mov    rdx,QWORD PTR [rcx+0x18]
  40c294:	cmp    QWORD PTR [rcx+0x20],rdx
  40c298:	jae    40c2ac <__swc_fn_fc36583a_000064_20100e91+0x25c>
  40c29a:	mov    rdx,QWORD PTR [rcx+0x20]
  40c29e:	mov    r9d,DWORD PTR [rcx+0x2c]
  40c2a2:	add    QWORD PTR [rcx+0x20],r9
  40c2a6:	add    DWORD PTR [rcx+0x28],0x1
  40c2aa:	jmp    40c2ae <__swc_fn_fc36583a_000064_20100e91+0x25e>
  40c2ac:	xor    edx,edx
  40c2ae:	test   rdx,rdx
  40c2b1:	jne    40c2c4 <__swc_fn_fc36583a_000064_20100e91+0x274>
  40c2b3:	mov    rcx,r12
  40c2b6:	mov    rdx,rax
  40c2b9:	mov    r8d,DWORD PTR [r8]
  40c2bc:	call   40e540 <__swc_fn_fc36583a_000050_5e919db9>
  40c2c1:	mov    rdx,rax
  40c2c4:	test   rdx,rdx
  40c2c7:	jne    40c2d3 <__swc_fn_fc36583a_000064_20100e91+0x283>
  40c2c9:	mov    QWORD PTR [rbx+0x40],0x0
  40c2d1:	jmp    40c2d7 <__swc_fn_fc36583a_000064_20100e91+0x287>
  40c2d3:	mov    QWORD PTR [rbx+0x40],rdx
  40c2d7:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40c2dd:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40c2e3:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40c2e9:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40c2ef:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40c2f5:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40c2fb:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40c301:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40c30a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40c313:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40c31c:	add    rsp,0xb8
  40c323:	pop    rsi
  40c324:	pop    rdi
  40c325:	pop    r12
  40c327:	pop    rbx
  40c328:	ret
  40c329:	add    BYTE PTR [rax],al
  40c32b:	add    BYTE PTR [rax],al
  40c32d:	add    BYTE PTR [rax],al
	...

000000000040c330 <__swc_fn_fc36583a_000067_0145abfc>:
  40c330:	ret
	...

000000000040c340 <__swc_fn_fc36583a_000070_357c932c>:
  40c340:	push   r12
  40c342:	push   r13
  40c344:	push   r14
  40c346:	push   rdi
  40c347:	push   rsi
  40c348:	sub    rsp,0x1a0
  40c34f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40c358:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40c361:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40c36a:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40c373:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40c37c:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40c385:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40c38e:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40c397:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40c3a0:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40c3a9:	mov    r12,rdx
  40c3ac:	mov    r13,rcx
  40c3af:	mov    rax,QWORD PTR [r12+0x48]
  40c3b4:	mov    ecx,DWORD PTR [r12+0x58]
  40c3b9:	lea    rdx,[rax-0x1]
  40c3bd:	cmp    rdx,0x10000
  40c3c4:	jae    40c4be <__swc_fn_fc36583a_000070_357c932c+0x17e>
  40c3ca:	cmp    rax,0x8
  40c3ce:	ja     40c3d5 <__swc_fn_fc36583a_000070_357c932c+0x95>
  40c3d0:	xor    r14d,r14d
  40c3d3:	jmp    40c427 <__swc_fn_fc36583a_000070_357c932c+0xe7>
  40c3d5:	cmp    rax,0x80
  40c3dc:	ja     40c3e8 <__swc_fn_fc36583a_000070_357c932c+0xa8>
  40c3de:	lea    r14,[rax+0xf]
  40c3e2:	shr    r14,0x4
  40c3e6:	jmp    40c427 <__swc_fn_fc36583a_000070_357c932c+0xe7>
  40c3e8:	cmp    rax,0x10000
  40c3ef:	jbe    40c3f9 <__swc_fn_fc36583a_000070_357c932c+0xb9>
  40c3f1:	mov    r14d,0xffffffff
  40c3f7:	jmp    40c427 <__swc_fn_fc36583a_000070_357c932c+0xe7>
  40c3f9:	xor    eax,eax
  40c3fb:	lzcnt  rax,rdx
  40c400:	mov    r8d,0x3f
  40c406:	sub    r8d,eax
  40c409:	lea    eax,[r8-0x2]
  40c40d:	shrx   rax,rdx,rax
  40c412:	and    eax,0x3
  40c415:	lea    edx,[r8-0x7]
  40c419:	lea    edx,[rdx*4+0x0]
  40c420:	lea    edx,[rdx+0x9]
  40c423:	lea    r14d,[rdx+rax*1]
  40c427:	cmp    ecx,0x8
  40c42a:	jbe    40c443 <__swc_fn_fc36583a_000070_357c932c+0x103>
  40c42c:	cmp    ecx,0x10
  40c42f:	jne    40c4be <__swc_fn_fc36583a_000070_357c932c+0x17e>
  40c435:	test   r14d,r14d
  40c438:	mov    eax,0x1
  40c43d:	cmove  r14d,eax
  40c441:	jmp    40c44a <__swc_fn_fc36583a_000070_357c932c+0x10a>
  40c443:	lea    eax,[rcx-0x1]
  40c446:	test   eax,ecx
  40c448:	jne    40c4be <__swc_fn_fc36583a_000070_357c932c+0x17e>
  40c44a:	lea    rax,[rip+0x15baf]        # 422000 <__swc_data_base_fc36583a>
  40c451:	mov    rax,QWORD PTR [rax]
  40c454:	cmp    rax,0xffffffffffffffff
  40c458:	je     40c467 <__swc_fn_fc36583a_000070_357c932c+0x127>
  40c45a:	mov    eax,eax
  40c45c:	mov    edi,eax
  40c45e:	xor    eax,eax
  40c460:	call   407000 <pthread_getspecific@plt>
  40c465:	jmp    40c469 <__swc_fn_fc36583a_000070_357c932c+0x129>
  40c467:	xor    eax,eax
  40c469:	test   rax,rax
  40c46c:	je     40c4be <__swc_fn_fc36583a_000070_357c932c+0x17e>
  40c46e:	cmp    QWORD PTR [rax],r13
  40c471:	jne    40c4be <__swc_fn_fc36583a_000070_357c932c+0x17e>
  40c473:	lea    rcx,[r14+r14*4]
  40c477:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40c47c:	test   rax,rax
  40c47f:	je     40c4be <__swc_fn_fc36583a_000070_357c932c+0x17e>
  40c481:	mov    rcx,QWORD PTR [rax]
  40c484:	test   rcx,rcx
  40c487:	je     40c495 <__swc_fn_fc36583a_000070_357c932c+0x155>
  40c489:	mov    rdx,QWORD PTR [rcx]
  40c48c:	mov    QWORD PTR [rax],rdx
  40c48f:	add    DWORD PTR [rax+0x28],0x1
  40c493:	jmp    40c4b2 <__swc_fn_fc36583a_000070_357c932c+0x172>
  40c495:	mov    rcx,QWORD PTR [rax+0x18]
  40c499:	cmp    QWORD PTR [rax+0x20],rcx
  40c49d:	jae    40c4b0 <__swc_fn_fc36583a_000070_357c932c+0x170>
  40c49f:	mov    rcx,QWORD PTR [rax+0x20]
  40c4a3:	mov    edx,DWORD PTR [rax+0x2c]
  40c4a6:	add    QWORD PTR [rax+0x20],rdx
  40c4aa:	add    DWORD PTR [rax+0x28],0x1
  40c4ae:	jmp    40c4b2 <__swc_fn_fc36583a_000070_357c932c+0x172>
  40c4b0:	xor    ecx,ecx
  40c4b2:	test   rcx,rcx
  40c4b5:	je     40c4be <__swc_fn_fc36583a_000070_357c932c+0x17e>
  40c4b7:	mov    QWORD PTR [r12+0x40],rcx
  40c4bc:	jmp    40c4c9 <__swc_fn_fc36583a_000070_357c932c+0x189>
  40c4be:	mov    rcx,r13
  40c4c1:	mov    rdx,r12
  40c4c4:	call   40efc0 <__swc_fn_fc36583a_000071_1e1e3bf8>
  40c4c9:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40c4d2:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40c4db:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40c4e4:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40c4ed:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40c4f6:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40c4ff:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40c508:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40c511:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40c51a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40c523:	add    rsp,0x1a0
  40c52a:	pop    rsi
  40c52b:	pop    rdi
  40c52c:	pop    r14
  40c52e:	pop    r13
  40c530:	pop    r12
  40c532:	ret
	...

000000000040c540 <__swc_fn_fc36583a_000073_cdd57f51>:
  40c540:	push   r12
  40c542:	push   r13
  40c544:	push   r14
  40c546:	push   r15
  40c548:	push   rdi
  40c549:	push   rsi
  40c54a:	sub    rsp,0x188
  40c551:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40c55a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40c563:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40c56c:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40c575:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40c57e:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40c587:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40c590:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40c599:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40c5a2:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40c5ab:	mov    r12,rdx
  40c5ae:	mov    r13,rcx
  40c5b1:	mov    r14,QWORD PTR [r12+0x40]
  40c5b6:	lea    rax,[rip+0x17ab3]        # 424070 <__swc_bss_base_fc36583a+0x30>
  40c5bd:	mov    rcx,r14
  40c5c0:	sub    rcx,QWORD PTR [rax+0x8]
  40c5c4:	mov    rax,QWORD PTR [rip+0x17ab5]        # 424080 <__swc_bss_base_fc36583a+0x40>
  40c5cb:	cmp    rcx,rax
  40c5ce:	jae    40c5fa <__swc_fn_fc36583a_000073_cdd57f51+0xba>
  40c5d0:	mov    rax,r14
  40c5d3:	and    rax,0xffffffffffc00000
  40c5da:	mov    rcx,r14
  40c5dd:	shr    rcx,0x10
  40c5e1:	and    ecx,0x3f
  40c5e4:	mov    edx,DWORD PTR [rax+0x28]
  40c5e7:	shrx   ecx,ecx,edx
  40c5ec:	shl    rcx,0x4
  40c5f0:	lea    r15,[rax+rcx*8+0x80]
  40c5f8:	jmp    40c605 <__swc_fn_fc36583a_000073_cdd57f51+0xc5>
  40c5fa:	mov    rcx,r14
  40c5fd:	call   40b0d0 <__swc_fn_fc36583a_000022_53fc00d2>
  40c602:	mov    r15,rax
  40c605:	test   r15,r15
  40c608:	je     40c6af <__swc_fn_fc36583a_000073_cdd57f51+0x16f>
  40c60e:	lea    rax,[rip+0x159eb]        # 422000 <__swc_data_base_fc36583a>
  40c615:	mov    rax,QWORD PTR [rax]
  40c618:	cmp    rax,0xffffffffffffffff
  40c61c:	je     40c62b <__swc_fn_fc36583a_000073_cdd57f51+0xeb>
  40c61e:	mov    eax,eax
  40c620:	mov    edi,eax
  40c622:	xor    eax,eax
  40c624:	call   407000 <pthread_getspecific@plt>
  40c629:	jmp    40c62d <__swc_fn_fc36583a_000073_cdd57f51+0xed>
  40c62b:	xor    eax,eax
  40c62d:	mov    rcx,QWORD PTR [r15+0x40]
  40c631:	cmp    rcx,rax
  40c634:	jne    40c694 <__swc_fn_fc36583a_000073_cdd57f51+0x154>
  40c636:	test   rax,rax
  40c639:	je     40c6af <__swc_fn_fc36583a_000073_cdd57f51+0x16f>
  40c63b:	mov    ecx,DWORD PTR [r15+0x6c]
  40c63f:	test   ecx,ecx
  40c641:	je     40c661 <__swc_fn_fc36583a_000073_cdd57f51+0x121>
  40c643:	mov    rcx,r13
  40c646:	mov    rdx,rax
  40c649:	mov    r8,r15
  40c64c:	mov    QWORD PTR [rsp+0xd8],rax
  40c654:	call   40e4d0 <__swc_fn_fc36583a_000047_e7fd8d42>
  40c659:	mov    rax,QWORD PTR [rsp+0xd8]
  40c661:	mov    rcx,QWORD PTR [r15]
  40c664:	mov    QWORD PTR [r14],rcx
  40c667:	mov    QWORD PTR [r15],r14
  40c66a:	sub    DWORD PTR [r15+0x28],0x1
  40c66f:	jne    40c6a4 <__swc_fn_fc36583a_000073_cdd57f51+0x164>
  40c671:	movzx  ecx,BYTE PTR [r15+0x39]
  40c676:	lea    rcx,[rcx+rcx*4]
  40c67a:	lea    rcx,[rax+rcx*8+0x28]
  40c67f:	cmp    QWORD PTR [rcx],r15
  40c682:	je     40c6a4 <__swc_fn_fc36583a_000073_cdd57f51+0x164>
  40c684:	mov    rcx,r13
  40c687:	mov    rdx,rax
  40c68a:	mov    r8,r15
  40c68d:	call   407d80 <__swc_fn_fc36583a_000051_27d2a35f>
  40c692:	jmp    40c6a4 <__swc_fn_fc36583a_000073_cdd57f51+0x164>
  40c694:	test   rcx,rcx
  40c697:	je     40c6af <__swc_fn_fc36583a_000073_cdd57f51+0x16f>
  40c699:	mov    rcx,r15
  40c69c:	mov    rdx,r14
  40c69f:	call   40ad10 <__swc_fn_fc36583a_000010_0569f799>
  40c6a4:	mov    QWORD PTR [r12+0x40],0x0
  40c6ad:	jmp    40c6ba <__swc_fn_fc36583a_000073_cdd57f51+0x17a>
  40c6af:	mov    rcx,r13
  40c6b2:	mov    rdx,r12
  40c6b5:	call   40efe0 <__swc_fn_fc36583a_000074_30b8696a>
  40c6ba:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40c6c3:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40c6cc:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40c6d5:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40c6de:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40c6e7:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40c6f0:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40c6f9:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40c702:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40c70b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40c714:	add    rsp,0x188
  40c71b:	pop    rsi
  40c71c:	pop    rdi
  40c71d:	pop    r15
  40c71f:	pop    r14
  40c721:	pop    r13
  40c723:	pop    r12
  40c725:	ret
	...

000000000040c730 <__swc_fn_fc36583a_000076_c3ad0fb4>:
  40c730:	sub    rsp,0x8
  40c734:	mov    rax,rdx
  40c737:	mov    rdx,QWORD PTR [rax+0x40]
  40c73b:	mov    r8,rax
  40c73e:	call   40c330 <__swc_fn_fc36583a_000067_0145abfc>
  40c743:	add    rsp,0x8
  40c747:	ret
	...

000000000040c750 <__swc_fn_fc36583a_000079_633af784>:
  40c750:	push   rsi
  40c751:	push   rdi
  40c752:	sub    rsp,0x8
  40c756:	cmp    rcx,0xffffffffffffffef
  40c75a:	ja     40c780 <__swc_fn_fc36583a_000079_633af784+0x30>
  40c75c:	xor    esi,esi
  40c75e:	lea    rax,[rcx+0x100f]
  40c765:	and    rax,0xfffffffffffff000
  40c76c:	lea    rcx,[rcx+0x10]
  40c770:	cmp    rcx,0xfffffffffffff000
  40c777:	cmovbe rsi,rax
  40c77b:	test   rsi,rsi
  40c77e:	jne    40c789 <__swc_fn_fc36583a_000079_633af784+0x39>
  40c780:	xor    eax,eax
  40c782:	add    rsp,0x8
  40c786:	pop    rdi
  40c787:	pop    rsi
  40c788:	ret
  40c789:	mov    rcx,rsi
  40c78c:	call   40cde0 <__swc_fn_fc36583a_000109_9f5af8ae>
  40c791:	mov    rdi,rax
  40c794:	test   rax,rax
  40c797:	jne    40c7a2 <__swc_fn_fc36583a_000079_633af784+0x52>
  40c799:	xor    eax,eax
  40c79b:	add    rsp,0x8
  40c79f:	pop    rdi
  40c7a0:	pop    rsi
  40c7a1:	ret
  40c7a2:	mov    rcx,rdi
  40c7a5:	mov    rdx,rsi
  40c7a8:	call   409240 <__swc_fn_fc36583a_000111_f9e19033>
  40c7ad:	test   al,al
  40c7af:	jne    40c7c5 <__swc_fn_fc36583a_000079_633af784+0x75>
  40c7b1:	mov    rcx,rdi
  40c7b4:	mov    rdx,rsi
  40c7b7:	call   410110 <__swc_fn_fc36583a_000113_4e83a03a>
  40c7bc:	xor    eax,eax
  40c7be:	add    rsp,0x8
  40c7c2:	pop    rdi
  40c7c3:	pop    rsi
  40c7c4:	ret
  40c7c5:	mov    QWORD PTR [rdi],rsi
  40c7c8:	mov    QWORD PTR [rdi+0x8],0x0
  40c7d0:	lea    rax,[rdi+0x10]
  40c7d4:	add    rsp,0x8
  40c7d8:	pop    rdi
  40c7d9:	pop    rsi
  40c7da:	ret
  40c7db:	add    BYTE PTR [rax],al
  40c7dd:	add    BYTE PTR [rax],al
	...

000000000040c7e0 <__swc_fn_fc36583a_000082_ff7d1455>:
  40c7e0:	sub    rsp,0x8
  40c7e4:	cmp    BYTE PTR [rcx+0x2c],0x10
  40c7e8:	jne    40c7f3 <__swc_fn_fc36583a_000082_ff7d1455+0x13>
  40c7ea:	test   DWORD PTR [rcx+0x28],0x80
  40c7f1:	je     40c7fb <__swc_fn_fc36583a_000082_ff7d1455+0x1b>
  40c7f3:	mov    rax,rcx
  40c7f6:	add    rsp,0x8
  40c7fa:	ret
  40c7fb:	mov    rcx,QWORD PTR [rcx+0x40]
  40c7ff:	call   40c7e0 <__swc_fn_fc36583a_000082_ff7d1455>
  40c804:	add    rsp,0x8
  40c808:	ret
	...

000000000040c820 <__swc_fn_fc36583a_000085_e24ecd12>:
  40c820:	push   rsi
  40c821:	push   rdi
  40c822:	push   r12
  40c824:	push   r13
  40c826:	sub    rsp,0x8
  40c82a:	mov    rsi,rdx
  40c82d:	mov    rdi,rcx
  40c830:	xor    r8d,r8d
  40c833:	call   4085a0 <__swc_fn_fc36583a_000090_14cf59b2>
  40c838:	test   al,al
  40c83a:	je     40c84c <__swc_fn_fc36583a_000085_e24ecd12+0x2c>
  40c83c:	mov    eax,0x1
  40c841:	add    rsp,0x8
  40c845:	pop    r13
  40c847:	pop    r12
  40c849:	pop    rdi
  40c84a:	pop    rsi
  40c84b:	ret
  40c84c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40c851:	je     40c860 <__swc_fn_fc36583a_000085_e24ecd12+0x40>
  40c853:	xor    eax,eax
  40c855:	add    rsp,0x8
  40c859:	pop    r13
  40c85b:	pop    r12
  40c85d:	pop    rdi
  40c85e:	pop    rsi
  40c85f:	ret
  40c860:	mov    r12,QWORD PTR [rsi+0x98]
  40c867:	mov    rax,QWORD PTR [rsi+0xa0]
  40c86e:	mov    rsi,rax
  40c871:	xor    r13d,r13d
  40c874:	test   rsi,rsi
  40c877:	je     40c8d4 <__swc_fn_fc36583a_000085_e24ecd12+0xb4>
  40c879:	cs nop WORD PTR [rax+rax*1+0x0]
  40c883:	cs nop WORD PTR [rax+rax*1+0x0]
  40c88d:	nop    DWORD PTR [rax]
  40c890:	lea    rax,[r13*8+0x0]
  40c898:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40c89d:	mov    rcx,rax
  40c8a0:	call   40c7e0 <__swc_fn_fc36583a_000082_ff7d1455>
  40c8a5:	cmp    BYTE PTR [rax+0x2c],0xe
  40c8a9:	jne    40c8ca <__swc_fn_fc36583a_000085_e24ecd12+0xaa>
  40c8ab:	mov    rcx,rdi
  40c8ae:	mov    rdx,rax
  40c8b1:	call   40c820 <__swc_fn_fc36583a_000085_e24ecd12>
  40c8b6:	test   al,al
  40c8b8:	je     40c8ca <__swc_fn_fc36583a_000085_e24ecd12+0xaa>
  40c8ba:	mov    eax,0x1
  40c8bf:	add    rsp,0x8
  40c8c3:	pop    r13
  40c8c5:	pop    r12
  40c8c7:	pop    rdi
  40c8c8:	pop    rsi
  40c8c9:	ret
  40c8ca:	add    r13,0x1
  40c8ce:	sub    rsi,0x1
  40c8d2:	jne    40c890 <__swc_fn_fc36583a_000085_e24ecd12+0x70>
  40c8d4:	xor    eax,eax
  40c8d6:	add    rsp,0x8
  40c8da:	pop    r13
  40c8dc:	pop    r12
  40c8de:	pop    rdi
  40c8df:	pop    rsi
  40c8e0:	ret
	...

000000000040c8f0 <__swc_fn_fc36583a_000088_ab2f35d8>:
  40c8f0:	sub    rsp,0x18
  40c8f4:	vxorps xmm0,xmm0,xmm0
  40c8f8:	vmovdqu XMMWORD PTR [rsp],xmm0
  40c8fd:	call   40f1f0 <__swc_fn_fc36583a_000089_3c530920>
  40c902:	add    rsp,0x18
  40c906:	ret
	...

000000000040c910 <__swc_fn_fc36583a_000091_f21926ed>:
  40c910:	sub    rsp,0x8
  40c914:	mov    rcx,QWORD PTR [rip+0x1a425]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40c91b:	test   rcx,rcx
  40c91e:	jne    40c930 <__swc_fn_fc36583a_000091_f21926ed+0x20>
  40c920:	call   40a1a0 <__swc_fn_fc36583a_000165_56054fe7>
  40c925:	lea    rcx,[rax+0x1]
  40c929:	mov    QWORD PTR [rip+0x1a410],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40c930:	dec    rcx
  40c933:	call   411ee0 <__swc_fn_fc36583a_000167_39c041ad>
  40c938:	mov    rax,QWORD PTR [rax+0xc0]
  40c93f:	and    eax,0x1
  40c942:	setne  al
  40c945:	add    rsp,0x8
  40c949:	ret
	...

000000000040c960 <__swc_fn_fc36583a_000094_383a814c>:
  40c960:	push   rbx
  40c961:	push   rsi
  40c962:	push   rdi
  40c963:	push   r12
  40c965:	sub    rsp,0x28
  40c969:	mov    rbx,rcx
  40c96c:	call   408900 <__swc_fn_fc36583a_000093_0c97fc6c>
  40c971:	mov    rcx,QWORD PTR [rip+0x1a3c8]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40c978:	test   rcx,rcx
  40c97b:	jne    40c98d <__swc_fn_fc36583a_000094_383a814c+0x2d>
  40c97d:	call   40a1a0 <__swc_fn_fc36583a_000165_56054fe7>
  40c982:	lea    rcx,[rax+0x1]
  40c986:	mov    QWORD PTR [rip+0x1a3b3],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40c98d:	dec    rcx
  40c990:	call   411ee0 <__swc_fn_fc36583a_000167_39c041ad>
  40c995:	mov    rsi,rax
  40c998:	lea    rcx,[rsp+0x8]
  40c99d:	call   40f630 <__swc_fn_fc36583a_000092_809deff5>
  40c9a2:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40c9a9:	mov    r12,QWORD PTR [rsi+0xbe8]
  40c9b0:	lea    rcx,[rsi+0x10]
  40c9b4:	call   40d930 <__swc_fn_fc36583a_000157_3495a3ca>
  40c9b9:	mov    rcx,rsi
  40c9bc:	call   40f7a0 <__swc_fn_fc36583a_000101_afcb7774>
  40c9c1:	vxorps xmm0,xmm0,xmm0
  40c9c5:	xor    eax,eax
  40c9c7:	cs nop WORD PTR [rax+rax*1+0x0]
  40c9d1:	cs nop WORD PTR [rax+rax*1+0x0]
  40c9db:	nop    DWORD PTR [rax+rax*1+0x0]
  40c9e0:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40c9e5:	add    rax,0x10
  40c9e9:	cmp    rax,0xbf0
  40c9f0:	jne    40c9e0 <__swc_fn_fc36583a_000094_383a814c+0x80>
  40c9f2:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c9f8:	vmovups XMMWORD PTR [rsi],xmm0
  40c9fc:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ca02:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40ca0a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40ca11:	mov    QWORD PTR [rsi+0xbe8],r12
  40ca18:	mov    rcx,QWORD PTR [rip+0x1a321]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40ca1f:	test   rcx,rcx
  40ca22:	jne    40ca34 <__swc_fn_fc36583a_000094_383a814c+0xd4>
  40ca24:	call   40a1a0 <__swc_fn_fc36583a_000165_56054fe7>
  40ca29:	lea    rcx,[rax+0x1]
  40ca2d:	mov    QWORD PTR [rip+0x1a30c],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40ca34:	dec    rcx
  40ca37:	call   411ee0 <__swc_fn_fc36583a_000167_39c041ad>
  40ca3c:	mov    rsi,rax
  40ca3f:	mov    QWORD PTR [rsi+0xc0],rbx
  40ca46:	and    ebx,0x1
  40ca49:	jne    40ca4d <__swc_fn_fc36583a_000094_383a814c+0xed>
  40ca4b:	xor    eax,eax
  40ca4d:	test   rbx,rbx
  40ca50:	sete   al
  40ca53:	xor    cl,cl
  40ca55:	xor    dl,dl
  40ca57:	xor    r8b,r8b
  40ca5a:	xor    r9b,r9b
  40ca5d:	xor    r10b,r10b
  40ca60:	mov    r11,rax
  40ca63:	call   40eff0 <__swc_fn_fc36583a_000077_948ef603>
  40ca68:	lea    rbx,[rsp+0x18]
  40ca6d:	mov    rcx,rbx
  40ca70:	call   40f630 <__swc_fn_fc36583a_000092_809deff5>
  40ca75:	lea    rcx,[rsi+0x10]
  40ca79:	mov    edx,0x400000
  40ca7e:	mov    r8,rbx
  40ca81:	call   409ee0 <__swc_fn_fc36583a_000159_6861d596>
  40ca86:	lea    rcx,[rsi+0x68]
  40ca8a:	mov    edx,0x4000
  40ca8f:	mov    r8,rbx
  40ca92:	call   409ee0 <__swc_fn_fc36583a_000159_6861d596>
  40ca97:	add    rsp,0x28
  40ca9b:	pop    r12
  40ca9d:	pop    rdi
  40ca9e:	pop    rsi
  40ca9f:	pop    rbx
  40caa0:	ret
	...

000000000040cab0 <__swc_fn_fc36583a_000097_96d6739a>:
  40cab0:	push   rbx
  40cab1:	push   rsi
  40cab2:	sub    rsp,0x18
  40cab6:	mov    rbx,rcx
  40cab9:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40cabe:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40cac4:	mov    rsi,QWORD PTR [rbx+0x70]
  40cac8:	lea    rcx,[rcx+0x18]
  40cacc:	call   40d930 <__swc_fn_fc36583a_000157_3495a3ca>
  40cad1:	lea    rcx,[rsp+0x8]
  40cad6:	mov    rdx,rbx
  40cad9:	mov    r8d,0x78
  40cadf:	call   408960 <__swc_fn_fc36583a_000096_a4baaa40>
  40cae4:	mov    rax,rsi
  40cae7:	add    rsp,0x18
  40caeb:	pop    rsi
  40caec:	pop    rbx
  40caed:	ret
	...

000000000040caf0 <__swc_fn_fc36583a_000100_5714513e>:
  40caf0:	push   rsi
  40caf1:	push   rdi
  40caf2:	sub    rsp,0x8
  40caf6:	cmp    QWORD PTR [rcx],0x0
  40cafa:	jne    40cb03 <__swc_fn_fc36583a_000100_5714513e+0x13>
  40cafc:	add    rsp,0x8
  40cb00:	pop    rdi
  40cb01:	pop    rsi
  40cb02:	ret
  40cb03:	mov    rsi,QWORD PTR [rcx]
  40cb06:	mov    rax,QWORD PTR [rcx+0x8]
  40cb0a:	test   rax,rax
  40cb0d:	je     40cb23 <__swc_fn_fc36583a_000100_5714513e+0x33>
  40cb0f:	test   DWORD PTR [rax+0x28],0x400000
  40cb16:	je     40cb23 <__swc_fn_fc36583a_000100_5714513e+0x33>
  40cb18:	mov    rcx,QWORD PTR [rax+0x30]
  40cb1c:	test   rcx,rcx
  40cb1f:	cmovne rax,rcx
  40cb23:	lea    rdx,[rip+0x66a6]        # 4131d0 <__swc_rdata_base_fc36583a+0xc0>
  40cb2a:	lea    rcx,[rip+0x6787]        # 4132b8 <__swc_rdata_base_fc36583a+0x1a8>
  40cb31:	mov    r8,rax
  40cb34:	xor    r9d,r9d
  40cb37:	xor    al,al
  40cb39:	mov    r10,rax
  40cb3c:	xor    r11d,r11d
  40cb3f:	call   40c8f0 <__swc_fn_fc36583a_000088_ab2f35d8>
  40cb44:	test   rax,rax
  40cb47:	je     40cb57 <__swc_fn_fc36583a_000100_5714513e+0x67>
  40cb49:	mov    rdi,QWORD PTR [rax+0x48]
  40cb4d:	test   rdi,rdi
  40cb50:	je     40cb57 <__swc_fn_fc36583a_000100_5714513e+0x67>
  40cb52:	mov    rcx,rsi
  40cb55:	call   rdi
  40cb57:	add    rsp,0x8
  40cb5b:	pop    rdi
  40cb5c:	pop    rsi
  40cb5d:	ret
	...

000000000040cb60 <__swc_fn_fc36583a_000103_0d4cc079>:
  40cb60:	push   rbx
  40cb61:	push   rsi
  40cb62:	push   rdi
  40cb63:	sub    rsp,0x20
  40cb67:	mov    rbx,rdx
  40cb6a:	mov    rsi,rcx
  40cb6d:	mov    rcx,QWORD PTR [rip+0x1a1cc]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40cb74:	test   rcx,rcx
  40cb77:	jne    40cb89 <__swc_fn_fc36583a_000103_0d4cc079+0x29>
  40cb79:	call   40a1a0 <__swc_fn_fc36583a_000165_56054fe7>
  40cb7e:	lea    rcx,[rax+0x1]
  40cb82:	mov    QWORD PTR [rip+0x1a1b7],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40cb89:	dec    rcx
  40cb8c:	call   411ee0 <__swc_fn_fc36583a_000167_39c041ad>
  40cb91:	mov    rdi,rax
  40cb94:	mov    rax,QWORD PTR [rdi+0xbd0]
  40cb9b:	xor    ecx,ecx
  40cb9d:	test   rax,rax
  40cba0:	je     40cba5 <__swc_fn_fc36583a_000103_0d4cc079+0x45>
  40cba2:	mov    rcx,QWORD PTR [rax]
  40cba5:	call   40a2d0 <__swc_fn_fc36583a_000174_02e645b4>
  40cbaa:	lea    rax,[rsp+0x8]
  40cbaf:	lea    rcx,[rdi+0x9c8]
  40cbb6:	mov    QWORD PTR [rsp+0x8],rcx
  40cbbb:	mov    QWORD PTR [rax+0x8],0x40
  40cbc3:	xor    ecx,ecx
  40cbc5:	mov    rdx,rax
  40cbc8:	call   410240 <__swc_fn_fc36583a_000119_2d9caf16>
  40cbcd:	mov    DWORD PTR [rdi+0xbc8],eax
  40cbd3:	mov    rdi,QWORD PTR [rdi+0x990]
  40cbda:	test   rdi,rdi
  40cbdd:	je     40cbe7 <__swc_fn_fc36583a_000103_0d4cc079+0x87>
  40cbdf:	mov    rcx,rsi
  40cbe2:	mov    rdx,rbx
  40cbe5:	call   rdi
  40cbe7:	call   40c910 <__swc_fn_fc36583a_000091_f21926ed>
  40cbec:	test   al,al
  40cbee:	je     40cbfe <__swc_fn_fc36583a_000103_0d4cc079+0x9e>
  40cbf0:	mov    rcx,rsi
  40cbf3:	mov    rdx,rbx
  40cbf6:	xor    r8d,r8d
  40cbf9:	call   4093e0 <__swc_fn_fc36583a_000120_1e032ef6>
  40cbfe:	mov    rcx,rsi
  40cc01:	mov    rdx,rbx
  40cc04:	call   408a60 <__swc_fn_fc36583a_000102_14986ec5>
  40cc09:	call   40d190 <__swc_fn_fc36583a_000118_591530fe>
  40cc0e:	add    rsp,0x20
  40cc12:	pop    rdi
  40cc13:	pop    rsi
  40cc14:	pop    rbx
  40cc15:	ret
	...

000000000040cc20 <__swc_fn_fc36583a_000106_aba05410>:
  40cc20:	test   r8,r8
  40cc23:	jne    40cc28 <__swc_fn_fc36583a_000106_aba05410+0x8>
  40cc25:	xor    eax,eax
  40cc27:	ret
  40cc28:	xor    eax,eax
  40cc2a:	nop    WORD PTR [rax+rax*1+0x0]
  40cc30:	mov    r9,r8
  40cc33:	sub    r9,rax
  40cc36:	cmp    r9,0x10
  40cc3a:	jb     40cc84 <__swc_fn_fc36583a_000106_aba05410+0x64>
  40cc3c:	lea    r9,[rcx+rax*1]
  40cc40:	lea    r10,[rdx+rax*1]
  40cc44:	vmovups xmm0,XMMWORD PTR [r10]
  40cc49:	vmovups xmm1,XMMWORD PTR [r9]
  40cc4e:	vpcmpeqb xmm0,xmm1,xmm0
  40cc52:	vpmovmskb r9d,xmm0
  40cc56:	cmp    r9d,0xffff
  40cc5d:	je     40cc7e <__swc_fn_fc36583a_000106_aba05410+0x5e>
  40cc5f:	not    r9d
  40cc62:	xor    r8d,r8d
  40cc65:	movzx  r9d,r9w
  40cc69:	tzcnt  r8d,r9d
  40cc6e:	add    rax,r8
  40cc71:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cc75:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cc79:	sub    ecx,eax
  40cc7b:	mov    eax,ecx
  40cc7d:	ret
  40cc7e:	lea    rax,[rax+0x10]
  40cc82:	jmp    40cc30 <__swc_fn_fc36583a_000106_aba05410+0x10>
  40cc84:	cmp    r9,0x8
  40cc88:	jb     40ccfb <__swc_fn_fc36583a_000106_aba05410+0xdb>
  40cc8a:	lea    r9,[rcx+rax*1]
  40cc8e:	lea    r10,[rdx+rax*1]
  40cc92:	mov    r9,QWORD PTR [r9]
  40cc95:	xor    r9,QWORD PTR [r10]
  40cc98:	test   r9,r9
  40cc9b:	je     40ccb9 <__swc_fn_fc36583a_000106_aba05410+0x99>
  40cc9d:	xor    r8d,r8d
  40cca0:	tzcnt  r8,r9
  40cca5:	shr    r8,0x3
  40cca9:	add    rax,r8
  40ccac:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40ccb0:	movzx  eax,BYTE PTR [rdx+rax*1]
  40ccb4:	sub    ecx,eax
  40ccb6:	mov    eax,ecx
  40ccb8:	ret
  40ccb9:	lea    rax,[rax+0x8]
  40ccbd:	cmp    rax,r8
  40ccc0:	jne    40ccc5 <__swc_fn_fc36583a_000106_aba05410+0xa5>
  40ccc2:	xor    eax,eax
  40ccc4:	ret
  40ccc5:	lea    rax,[r8-0x8]
  40ccc9:	lea    r8,[rcx+rax*1]
  40cccd:	lea    r9,[rdx+rax*1]
  40ccd1:	mov    r8,QWORD PTR [r8]
  40ccd4:	xor    r8,QWORD PTR [r9]
  40ccd7:	test   r8,r8
  40ccda:	je     40ccf8 <__swc_fn_fc36583a_000106_aba05410+0xd8>
  40ccdc:	xor    r9d,r9d
  40ccdf:	tzcnt  r9,r8
  40cce4:	shr    r9,0x3
  40cce8:	add    rax,r9
  40cceb:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40ccef:	movzx  eax,BYTE PTR [rdx+rax*1]
  40ccf3:	sub    ecx,eax
  40ccf5:	mov    eax,ecx
  40ccf7:	ret
  40ccf8:	xor    eax,eax
  40ccfa:	ret
  40ccfb:	cmp    r9,0x4
  40ccff:	jb     40cd72 <__swc_fn_fc36583a_000106_aba05410+0x152>
  40cd01:	lea    r9,[rcx+rax*1]
  40cd05:	lea    r10,[rdx+rax*1]
  40cd09:	mov    r9d,DWORD PTR [r9]
  40cd0c:	xor    r9d,DWORD PTR [r10]
  40cd0f:	test   r9d,r9d
  40cd12:	je     40cd30 <__swc_fn_fc36583a_000106_aba05410+0x110>
  40cd14:	xor    r8d,r8d
  40cd17:	tzcnt  r8,r9
  40cd1c:	shr    r8,0x3
  40cd20:	add    rax,r8
  40cd23:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cd27:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cd2b:	sub    ecx,eax
  40cd2d:	mov    eax,ecx
  40cd2f:	ret
  40cd30:	lea    rax,[rax+0x4]
  40cd34:	cmp    rax,r8
  40cd37:	jne    40cd3c <__swc_fn_fc36583a_000106_aba05410+0x11c>
  40cd39:	xor    eax,eax
  40cd3b:	ret
  40cd3c:	lea    rax,[r8-0x4]
  40cd40:	lea    r8,[rcx+rax*1]
  40cd44:	lea    r9,[rdx+rax*1]
  40cd48:	mov    r8d,DWORD PTR [r8]
  40cd4b:	xor    r8d,DWORD PTR [r9]
  40cd4e:	test   r8d,r8d
  40cd51:	je     40cd6f <__swc_fn_fc36583a_000106_aba05410+0x14f>
  40cd53:	xor    r9d,r9d
  40cd56:	tzcnt  r9,r8
  40cd5b:	shr    r9,0x3
  40cd5f:	add    rax,r9
  40cd62:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cd66:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cd6a:	sub    ecx,eax
  40cd6c:	mov    eax,ecx
  40cd6e:	ret
  40cd6f:	xor    eax,eax
  40cd71:	ret
  40cd72:	cmp    r9,0x2
  40cd76:	jb     40cdc9 <__swc_fn_fc36583a_000106_aba05410+0x1a9>
  40cd78:	lea    r9,[rcx+rax*1]
  40cd7c:	lea    r10,[rdx+rax*1]
  40cd80:	mov    r9w,WORD PTR [r9]
  40cd84:	xor    r9w,WORD PTR [r10]
  40cd88:	test   r9w,r9w
  40cd8c:	je     40cdae <__swc_fn_fc36583a_000106_aba05410+0x18e>
  40cd8e:	xor    r8d,r8d
  40cd91:	movzx  r9d,r9w
  40cd95:	tzcnt  r8,r9
  40cd9a:	shr    r8,0x3
  40cd9e:	add    rax,r8
  40cda1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cda5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cda9:	sub    ecx,eax
  40cdab:	mov    eax,ecx
  40cdad:	ret
  40cdae:	lea    rax,[rax+0x2]
  40cdb2:	cmp    rax,r8
  40cdb5:	jne    40cdba <__swc_fn_fc36583a_000106_aba05410+0x19a>
  40cdb7:	xor    eax,eax
  40cdb9:	ret
  40cdba:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40cdc0:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40cdc6:	sub    eax,ecx
  40cdc8:	ret
  40cdc9:	test   r9,r9
  40cdcc:	je     40cddb <__swc_fn_fc36583a_000106_aba05410+0x1bb>
  40cdce:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40cdd2:	movzx  eax,BYTE PTR [rdx+rax*1]
  40cdd6:	sub    ecx,eax
  40cdd8:	mov    eax,ecx
  40cdda:	ret
  40cddb:	xor    eax,eax
  40cddd:	ret
	...

000000000040cde0 <__swc_fn_fc36583a_000109_9f5af8ae>:
  40cde0:	push   r12
  40cde2:	push   r13
  40cde4:	push   r14
  40cde6:	push   rdi
  40cde7:	push   rsi
  40cde8:	push   r15
  40cdea:	sub    rsp,0xd8
  40cdf1:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40cdf7:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40cdfd:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40ce03:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40ce09:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40ce0f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40ce18:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40ce21:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40ce2a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40ce33:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40ce3c:	mov    r12,rcx
  40ce3f:	test   rcx,rcx
  40ce42:	je     40ce5e <__swc_fn_fc36583a_000109_9f5af8ae+0x7e>
  40ce44:	mov    eax,r12d
  40ce47:	and    eax,0xfff
  40ce4d:	setne  al
  40ce50:	cmp    r12,0xffffffffffffefff
  40ce57:	seta   cl
  40ce5a:	or     al,cl
  40ce5c:	je     40ce65 <__swc_fn_fc36583a_000109_9f5af8ae+0x85>
  40ce5e:	xor    eax,eax
  40ce60:	jmp    40cefb <__swc_fn_fc36583a_000109_9f5af8ae+0x11b>
  40ce65:	call   409100 <__swc_fn_fc36583a_000108_b8f4bd15>
  40ce6a:	mov    r13,rax
  40ce6d:	test   rax,rax
  40ce70:	jne    40ce79 <__swc_fn_fc36583a_000109_9f5af8ae+0x99>
  40ce72:	xor    eax,eax
  40ce74:	jmp    40cefb <__swc_fn_fc36583a_000109_9f5af8ae+0x11b>
  40ce79:	lea    r14,[r12+0x1000]
  40ce81:	xor    edi,edi
  40ce83:	mov    rsi,r14
  40ce86:	xor    edx,edx
  40ce88:	mov    ecx,0x22
  40ce8d:	mov    eax,0xffffffff
  40ce92:	movsxd r8,eax
  40ce95:	xor    r9d,r9d
  40ce98:	xor    eax,eax
  40ce9a:	call   4070c0 <mmap@plt>
  40ce9f:	mov    r15,rax
  40cea2:	cmp    rax,0xffffffffffffffff
  40cea6:	jne    40ceac <__swc_fn_fc36583a_000109_9f5af8ae+0xcc>
  40cea8:	xor    eax,eax
  40ceaa:	jmp    40cefb <__swc_fn_fc36583a_000109_9f5af8ae+0x11b>
  40ceac:	mov    rdi,r15
  40ceaf:	mov    esi,0x1000
  40ceb4:	mov    edx,0x3
  40ceb9:	xor    eax,eax
  40cebb:	call   407030 <mprotect@plt>
  40cec0:	test   eax,eax
  40cec2:	je     40ced5 <__swc_fn_fc36583a_000109_9f5af8ae+0xf5>
  40cec4:	mov    rdi,r15
  40cec7:	mov    rsi,r14
  40ceca:	xor    eax,eax
  40cecc:	call   407020 <munmap@plt>
  40ced1:	xor    eax,eax
  40ced3:	jmp    40cefb <__swc_fn_fc36583a_000109_9f5af8ae+0x11b>
  40ced5:	mov    QWORD PTR [r15+0x8],r12
  40ced9:	mov    rcx,r13
  40cedc:	call   40d530 <__swc_fn_fc36583a_000133_807fd51d>
  40cee1:	mov    rax,QWORD PTR [r13+0x8]
  40cee5:	mov    QWORD PTR [r15],rax
  40cee8:	mov    QWORD PTR [r13+0x8],r15
  40ceec:	mov    rcx,r13
  40ceef:	call   4105e0 <__swc_fn_fc36583a_000134_10472836>
  40cef4:	lea    rax,[r15+0x1000]
  40cefb:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40cf01:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40cf07:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40cf0d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40cf13:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40cf19:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40cf22:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40cf2b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40cf34:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40cf3d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40cf46:	add    rsp,0xd8
  40cf4d:	pop    r15
  40cf4f:	pop    rsi
  40cf50:	pop    rdi
  40cf51:	pop    r14
  40cf53:	pop    r13
  40cf55:	pop    r12
  40cf57:	ret
	...

000000000040cf60 <__swc_fn_fc36583a_000112_2f7f9346>:
  40cf60:	push   rbx
  40cf61:	push   r12
  40cf63:	push   rdi
  40cf64:	push   rsi
  40cf65:	sub    rsp,0xa8
  40cf6c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cf72:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cf78:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cf7e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cf84:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cf8a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cf90:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cf96:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cf9c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cfa5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cfae:	mov    rbx,rdx
  40cfb1:	mov    r12,rcx
  40cfb4:	mov    rdi,rcx
  40cfb7:	mov    rsi,rdx
  40cfba:	xor    edx,edx
  40cfbc:	xor    eax,eax
  40cfbe:	call   407030 <mprotect@plt>
  40cfc3:	test   eax,eax
  40cfc5:	jne    40cfe9 <__swc_fn_fc36583a_000112_2f7f9346+0x89>
  40cfc7:	mov    rcx,r12
  40cfca:	mov    rdx,rbx
  40cfcd:	xor    al,al
  40cfcf:	mov    r8,rax
  40cfd2:	call   410080 <__swc_fn_fc36583a_000110_918d5a21>
  40cfd7:	mov    rdi,r12
  40cfda:	mov    rsi,rbx
  40cfdd:	mov    edx,0x4
  40cfe2:	xor    eax,eax
  40cfe4:	call   4070e0 <madvise@plt>
  40cfe9:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cfef:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cff5:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cffb:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d001:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d007:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d00d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d013:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d019:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d022:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d02b:	add    rsp,0xa8
  40d032:	pop    rsi
  40d033:	pop    rdi
  40d034:	pop    r12
  40d036:	pop    rbx
  40d037:	ret
	...

000000000040d040 <__swc_fn_fc36583a_000115_3f6af4b1>:
  40d040:	push   rsi
  40d041:	push   rdi
  40d042:	push   r12
  40d044:	push   r13
  40d046:	push   r14
  40d048:	sub    rsp,0xe0
  40d04f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40d055:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40d05b:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40d061:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40d067:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40d06d:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40d076:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40d07f:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40d088:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40d091:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40d09a:	mov    rsi,rdx
  40d09d:	mov    rdi,rcx
  40d0a0:	call   409100 <__swc_fn_fc36583a_000108_b8f4bd15>
  40d0a5:	mov    r12,rax
  40d0a8:	test   rax,rax
  40d0ab:	jne    40d0b2 <__swc_fn_fc36583a_000115_3f6af4b1+0x72>
  40d0ad:	jmp    40d126 <__swc_fn_fc36583a_000115_3f6af4b1+0xe6>
  40d0b2:	mov    rcx,r12
  40d0b5:	call   40d530 <__swc_fn_fc36583a_000133_807fd51d>
  40d0ba:	lea    r13,[r12+0x8]
  40d0bf:	mov    rax,QWORD PTR [r13+0x0]
  40d0c3:	test   rax,rax
  40d0c6:	je     40d11e <__swc_fn_fc36583a_000115_3f6af4b1+0xde>
  40d0c8:	nop    DWORD PTR [rax+rax*1+0x0]
  40d0d0:	lea    rcx,[rax+0x1000]
  40d0d7:	cmp    rcx,rdi
  40d0da:	jne    40d112 <__swc_fn_fc36583a_000115_3f6af4b1+0xd2>
  40d0dc:	cmp    QWORD PTR [rax+0x8],rsi
  40d0e0:	je     40d0ec <__swc_fn_fc36583a_000115_3f6af4b1+0xac>
  40d0e2:	mov    rcx,r12
  40d0e5:	call   4105e0 <__swc_fn_fc36583a_000134_10472836>
  40d0ea:	jmp    40d126 <__swc_fn_fc36583a_000115_3f6af4b1+0xe6>
  40d0ec:	mov    r14,QWORD PTR [rax]
  40d0ef:	mov    rdi,rax
  40d0f2:	lea    rsi,[rsi+0x1000]
  40d0f9:	xor    eax,eax
  40d0fb:	call   407020 <munmap@plt>
  40d100:	test   eax,eax
  40d102:	jne    40d108 <__swc_fn_fc36583a_000115_3f6af4b1+0xc8>
  40d104:	mov    QWORD PTR [r13+0x0],r14
  40d108:	mov    rcx,r12
  40d10b:	call   4105e0 <__swc_fn_fc36583a_000134_10472836>
  40d110:	jmp    40d126 <__swc_fn_fc36583a_000115_3f6af4b1+0xe6>
  40d112:	mov    r13,rax
  40d115:	mov    rax,QWORD PTR [r13+0x0]
  40d119:	test   rax,rax
  40d11c:	jne    40d0d0 <__swc_fn_fc36583a_000115_3f6af4b1+0x90>
  40d11e:	mov    rcx,r12
  40d121:	call   4105e0 <__swc_fn_fc36583a_000134_10472836>
  40d126:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40d12c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40d132:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40d138:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40d13e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40d144:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40d14d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40d156:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40d15f:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40d168:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40d171:	add    rsp,0xe0
  40d178:	pop    r14
  40d17a:	pop    r13
  40d17c:	pop    r12
  40d17e:	pop    rdi
  40d17f:	pop    rsi
  40d180:	ret
	...

000000000040d190 <__swc_fn_fc36583a_000118_591530fe>:
  40d190:	push   rdi
  40d191:	push   rsi
  40d192:	sub    rsp,0xa8
  40d199:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d19f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d1a5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d1ab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d1b1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d1b7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d1bd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d1c3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d1c9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d1d2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d1db:	mov    rdi,0xfffffffffffffd66
  40d1e2:	xor    eax,eax
  40d1e4:	call   407040 <exit@plt>
  40d1e9:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d1ef:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d1f5:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d1fb:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d201:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d207:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d20d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d213:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d219:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d222:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d22b:	add    rsp,0xa8
  40d232:	pop    rsi
  40d233:	pop    rdi
  40d234:	ret
	...

000000000040d240 <__swc_fn_fc36583a_000121_1c5e75b6>:
  40d240:	push   rbx
  40d241:	push   rsi
  40d242:	push   rdi
  40d243:	sub    rsp,0x30
  40d247:	mov    rbx,rdx
  40d24a:	mov    esi,ecx
  40d24c:	test   ecx,ecx
  40d24e:	je     40d323 <__swc_fn_fc36583a_000121_1c5e75b6+0xe3>
  40d254:	mov    rcx,rsi
  40d257:	shl    rcx,0x4
  40d25b:	call   40c750 <__swc_fn_fc36583a_000079_633af784>
  40d260:	test   rax,rax
  40d263:	je     40d312 <__swc_fn_fc36583a_000121_1c5e75b6+0xd2>
  40d269:	mov    rcx,rsi
  40d26c:	xor    edx,edx
  40d26e:	test   rsi,rsi
  40d271:	jbe    40d2f2 <__swc_fn_fc36583a_000121_1c5e75b6+0xb2>
  40d277:	nop    WORD PTR [rax+rax*1+0x0]
  40d280:	mov    r8d,edx
  40d283:	mov    r9,QWORD PTR [rbx+r8*8]
  40d287:	add    r8,r8
  40d28a:	lea    r8,[rax+r8*8]
  40d28e:	xor    r10d,r10d
  40d291:	test   r9,r9
  40d294:	je     40d2d0 <__swc_fn_fc36583a_000121_1c5e75b6+0x90>
  40d296:	mov    r11,r9
  40d299:	mov    dil,BYTE PTR [r11]
  40d29c:	test   dil,dil
  40d29f:	je     40d2d0 <__swc_fn_fc36583a_000121_1c5e75b6+0x90>
  40d2a1:	cs nop WORD PTR [rax+rax*1+0x0]
  40d2ab:	cs nop WORD PTR [rax+rax*1+0x0]
  40d2b5:	cs nop WORD PTR [rax+rax*1+0x0]
  40d2bf:	nop
  40d2c0:	add    r11,0x1
  40d2c4:	add    r10,0x1
  40d2c8:	mov    dil,BYTE PTR [r11]
  40d2cb:	test   dil,dil
  40d2ce:	jne    40d2c0 <__swc_fn_fc36583a_000121_1c5e75b6+0x80>
  40d2d0:	mov    QWORD PTR [rsp+0x18],r9
  40d2d5:	mov    QWORD PTR [rsp+0x20],r10
  40d2da:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40d2e0:	vmovups XMMWORD PTR [r8],xmm0
  40d2e5:	add    rdx,0x1
  40d2e9:	cmp    rdx,rcx
  40d2ec:	jb     40d280 <__swc_fn_fc36583a_000121_1c5e75b6+0x40>
  40d2f2:	lea    rcx,[rip+0x19a57]        # 426d50 <__swc_bss_base_fc36583a+0x2d10>
  40d2f9:	mov    QWORD PTR [rsp+0x8],rax
  40d2fe:	mov    esi,esi
  40d300:	mov    QWORD PTR [rsp+0x10],rsi
  40d305:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40d30b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d310:	jmp    40d323 <__swc_fn_fc36583a_000121_1c5e75b6+0xe3>
  40d312:	lea    rcx,[rip+0x6207]        # 413520 <__swc_rdata_base_fc36583a+0x410>
  40d319:	call   410130 <__swc_fn_fc36583a_000116_3f5cfdef>
  40d31e:	call   40d190 <__swc_fn_fc36583a_000118_591530fe>
  40d323:	add    rsp,0x30
  40d327:	pop    rdi
  40d328:	pop    rsi
  40d329:	pop    rbx
  40d32a:	ret
  40d32b:	add    BYTE PTR [rax],al
  40d32d:	add    BYTE PTR [rax],al
	...

000000000040d330 <__swc_fn_fc36583a_000124_37eaf452>:
  40d330:	push   rdi
  40d331:	push   rsi
  40d332:	sub    rsp,0xa8
  40d339:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d33f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d345:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d34b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d351:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d357:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d35d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d363:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d369:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d372:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d37b:	mov    edi,ecx
  40d37d:	xor    eax,eax
  40d37f:	call   4070f0 <pthread_key_delete@plt>
  40d384:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d38a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d390:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d396:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d39c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d3a2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d3a8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d3ae:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d3b4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d3bd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d3c6:	add    rsp,0xa8
  40d3cd:	pop    rsi
  40d3ce:	pop    rdi
  40d3cf:	ret

000000000040d3d0 <__swc_fn_fc36583a_000127_f163135d>:
  40d3d0:	push   rdi
  40d3d1:	push   rsi
  40d3d2:	sub    rsp,0xa8
  40d3d9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d3df:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d3e5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d3eb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d3f1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d3f7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d3fd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d403:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d409:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d412:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d41b:	test   rcx,rcx
  40d41e:	je     40d42f <__swc_fn_fc36583a_000127_f163135d+0x5f>
  40d420:	lea    rax,[rcx-0x1]
  40d424:	mov    eax,eax
  40d426:	mov    edi,eax
  40d428:	xor    eax,eax
  40d42a:	call   4070f0 <pthread_key_delete@plt>
  40d42f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d435:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d43b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d441:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d447:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d44d:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d453:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d459:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d45f:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d468:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d471:	add    rsp,0xa8
  40d478:	pop    rsi
  40d479:	pop    rdi
  40d47a:	ret
  40d47b:	add    BYTE PTR [rax],al
  40d47d:	add    BYTE PTR [rax],al
	...

000000000040d480 <__swc_fn_fc36583a_000130_375c7357>:
  40d480:	push   rsi
  40d481:	push   rdi
  40d482:	sub    rsp,0xa8
  40d489:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d48f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d495:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d49b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d4a1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d4a7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d4ad:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d4b3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d4b9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d4c2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d4cb:	xor    eax,eax
  40d4cd:	call   407100 <gettid@plt>
  40d4d2:	movsxd rax,eax
  40d4d5:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d4db:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d4e1:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d4e7:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d4ed:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d4f3:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d4f9:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d4ff:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d505:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d50e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d517:	add    rsp,0xa8
  40d51e:	pop    rdi
  40d51f:	pop    rsi
  40d520:	ret
	...

000000000040d530 <__swc_fn_fc36583a_000133_807fd51d>:
  40d530:	push   rbx
  40d531:	push   rdi
  40d532:	push   rsi
  40d533:	sub    rsp,0xc0
  40d53a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40d540:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40d546:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40d54c:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40d552:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40d558:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40d55e:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40d564:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40d56d:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40d576:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40d57f:	mov    rbx,rcx
  40d582:	cs nop WORD PTR [rax+rax*1+0x0]
  40d58c:	nop    DWORD PTR [rax+0x0]
  40d590:	mov    edx,0x80000000
  40d595:	xor    eax,eax
  40d597:	lock cmpxchg DWORD PTR [rbx],edx
  40d59b:	test   eax,eax
  40d59d:	je     40d5d4 <__swc_fn_fc36583a_000133_807fd51d+0xa4>
  40d59f:	mov    eax,DWORD PTR [rbx]
  40d5a1:	lea    rcx,[rsp+0x14]
  40d5a6:	mov    DWORD PTR [rsp+0x14],eax
  40d5aa:	test   eax,eax
  40d5ac:	je     40d590 <__swc_fn_fc36583a_000133_807fd51d+0x60>
  40d5ae:	mov    QWORD PTR [rsp],0x0
  40d5b6:	mov    edi,0xca
  40d5bb:	mov    rsi,rbx
  40d5be:	mov    edx,0x80
  40d5c3:	mov    ecx,DWORD PTR [rcx]
  40d5c5:	xor    r8d,r8d
  40d5c8:	xor    r9d,r9d
  40d5cb:	xor    eax,eax
  40d5cd:	call   407070 <syscall@plt>
  40d5d2:	jmp    40d590 <__swc_fn_fc36583a_000133_807fd51d+0x60>
  40d5d4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40d5da:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40d5e0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40d5e6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40d5ec:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40d5f2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40d5f8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40d5fe:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40d607:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40d610:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40d619:	add    rsp,0xc0
  40d620:	pop    rsi
  40d621:	pop    rdi
  40d622:	pop    rbx
  40d623:	ret
	...

000000000040d630 <__swc_fn_fc36583a_000136_d579ef75>:
  40d630:	sub    rsp,0x8
  40d634:	call   4105e0 <__swc_fn_fc36583a_000134_10472836>
  40d639:	add    rsp,0x8
  40d63d:	ret
	...

000000000040d640 <__swc_fn_fc36583a_000139_e4a7a8b1>:
  40d640:	push   rdi
  40d641:	push   rsi
  40d642:	sub    rsp,0xa8
  40d649:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d64f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d655:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d65b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d661:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d667:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d66d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d673:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d679:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d682:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d68b:	mov    edi,0x28
  40d690:	xor    eax,eax
  40d692:	call   4070d0 <malloc@plt>
  40d697:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d69d:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d6a3:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d6a9:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d6af:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d6b5:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d6bb:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d6c1:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d6c7:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d6d0:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d6d9:	add    rsp,0xa8
  40d6e0:	pop    rsi
  40d6e1:	pop    rdi
  40d6e2:	ret
	...

000000000040d6f0 <__swc_fn_fc36583a_000142_89a6ef72>:
  40d6f0:	mov    QWORD PTR [r8],0x0
  40d6f7:	cmp    rdx,0x10
  40d6fb:	jae    40d700 <__swc_fn_fc36583a_000142_89a6ef72+0x10>
  40d6fd:	xor    eax,eax
  40d6ff:	ret
  40d700:	mov    eax,DWORD PTR [rcx]
  40d702:	cmp    eax,0x42445753
  40d708:	jne    40d712 <__swc_fn_fc36583a_000142_89a6ef72+0x22>
  40d70a:	mov    eax,DWORD PTR [rcx+0x4]
  40d70d:	cmp    eax,0x1
  40d710:	je     40d715 <__swc_fn_fc36583a_000142_89a6ef72+0x25>
  40d712:	xor    eax,eax
  40d714:	ret
  40d715:	mov    QWORD PTR [r8],rdx
  40d718:	mov    rax,rcx
  40d71b:	ret
  40d71c:	add    BYTE PTR [rax],al
	...

000000000040d720 <__swc_fn_fc36583a_000145_32a1d6a2>:
  40d720:	push   rbx
  40d721:	sub    rsp,0xe0
  40d728:	lea    rbx,[rsp+0x8]
  40d72d:	vxorps xmm0,xmm0,xmm0
  40d731:	vmovups YMMWORD PTR [rbx],ymm0
  40d735:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40d73a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40d73f:	vzeroupper
  40d742:	mov    DWORD PTR [rbx+0x60],0x0
  40d749:	mov    r8,rbx
  40d74c:	mov    rdx,rcx
  40d74f:	nop
  40d750:	mov    r9,rdx
  40d753:	movabs rdx,0x6666666666666667
  40d75d:	mov    rax,r9
  40d760:	imul   rdx
  40d763:	sar    rdx,0x2
  40d767:	mov    r10,rdx
  40d76a:	shr    rdx,0x3f
  40d76e:	add    r10,rdx
  40d771:	mov    rdx,r10
  40d774:	imul   r11,r10,0xa
  40d778:	sub    r9,r11
  40d77b:	mov    r11,QWORD PTR [rip+0x5dbe]        # 413540 <__swc_rdata_base_fc36583a+0x430>
  40d782:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40d787:	mov    BYTE PTR [r8],r9b
  40d78a:	lea    r9,[r8+0x1]
  40d78e:	mov    r8,r9
  40d791:	test   r10,r10
  40d794:	jne    40d750 <__swc_fn_fc36583a_000145_32a1d6a2+0x30>
  40d796:	test   rcx,rcx
  40d799:	jge    40d7a3 <__swc_fn_fc36583a_000145_32a1d6a2+0x83>
  40d79b:	mov    BYTE PTR [r9],0x2d
  40d79f:	add    r8,0x1
  40d7a3:	mov    BYTE PTR [r8],0x0
  40d7a7:	sub    r8,0x1
  40d7ab:	mov    rax,rbx
  40d7ae:	cmp    rax,r8
  40d7b1:	jae    40d7d6 <__swc_fn_fc36583a_000145_32a1d6a2+0xb6>
  40d7b3:	cs nop WORD PTR [rax+rax*1+0x0]
  40d7bd:	nop    DWORD PTR [rax]
  40d7c0:	mov    cl,BYTE PTR [r8]
  40d7c3:	mov    dl,BYTE PTR [rax]
  40d7c5:	mov    BYTE PTR [r8],dl
  40d7c8:	sub    r8,0x1
  40d7cc:	mov    BYTE PTR [rax],cl
  40d7ce:	inc    rax
  40d7d1:	cmp    rax,r8
  40d7d4:	jb     40d7c0 <__swc_fn_fc36583a_000145_32a1d6a2+0xa0>
  40d7d6:	xor    eax,eax
  40d7d8:	test   rbx,rbx
  40d7db:	je     40d7fe <__swc_fn_fc36583a_000145_32a1d6a2+0xde>
  40d7dd:	mov    rcx,rbx
  40d7e0:	mov    dl,BYTE PTR [rcx]
  40d7e2:	test   dl,dl
  40d7e4:	je     40d7fe <__swc_fn_fc36583a_000145_32a1d6a2+0xde>
  40d7e6:	cs nop WORD PTR [rax+rax*1+0x0]
  40d7f0:	add    rcx,0x1
  40d7f4:	add    rax,0x1
  40d7f8:	mov    dl,BYTE PTR [rcx]
  40d7fa:	test   dl,dl
  40d7fc:	jne    40d7f0 <__swc_fn_fc36583a_000145_32a1d6a2+0xd0>
  40d7fe:	mov    QWORD PTR [rbx+0xa8],rbx
  40d805:	mov    QWORD PTR [rbx+0xb0],rax
  40d80c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d814:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d81c:	lea    rcx,[rbx+0xb8]
  40d823:	call   410130 <__swc_fn_fc36583a_000116_3f5cfdef>
  40d828:	add    rsp,0xe0
  40d82f:	pop    rbx
  40d830:	ret
	...

000000000040d840 <__swc_fn_fc36583a_000148_365b4daf>:
  40d840:	vxorps xmm0,xmm0,xmm0
  40d844:	vmovups XMMWORD PTR [rcx],xmm0
  40d848:	mov    QWORD PTR [rcx+0x10],0x0
  40d850:	ret
	...

000000000040d860 <__swc_fn_fc36583a_000151_365b4daf>:
  40d860:	vxorps xmm0,xmm0,xmm0
  40d864:	vmovups XMMWORD PTR [rcx],xmm0
  40d868:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d86d:	vxorps xmm0,xmm0,xmm0
  40d871:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d876:	vmovups xmm0,XMMWORD PTR [rip+0x5dba]        # 413638 <__swc_rdata_base_fc36583a+0x528>
  40d87e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d883:	vxorps xmm0,xmm0,xmm0
  40d887:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d88c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d891:	mov    QWORD PTR [rcx+0x60],0x0
  40d899:	ret
  40d89a:	add    BYTE PTR [rax],al
  40d89c:	add    BYTE PTR [rax],al
	...

000000000040d8a0 <__swc_fn_fc36583a_000154_365b4daf>:
  40d8a0:	vxorps xmm0,xmm0,xmm0
  40d8a4:	vmovups XMMWORD PTR [rcx],xmm0
  40d8a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d8ad:	vxorps xmm0,xmm0,xmm0
  40d8b1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d8b6:	vmovups xmm0,XMMWORD PTR [rip+0x5ea2]        # 413760 <__swc_rdata_base_fc36583a+0x650>
  40d8be:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d8c3:	vxorps xmm0,xmm0,xmm0
  40d8c7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d8cc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d8d1:	vxorps xmm0,xmm0,xmm0
  40d8d5:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40d8da:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40d8df:	vxorps xmm0,xmm0,xmm0
  40d8e3:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40d8eb:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40d8f3:	vxorps xmm0,xmm0,xmm0
  40d8f7:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40d8ff:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40d907:	vxorps xmm0,xmm0,xmm0
  40d90b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40d913:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40d91b:	mov    QWORD PTR [rcx+0xe0],0x0
  40d926:	ret
	...

000000000040d930 <__swc_fn_fc36583a_000157_3495a3ca>:
  40d930:	push   rbx
  40d931:	mov    rbx,rcx
  40d934:	call   411b70 <__swc_fn_fc36583a_000158_31e09513>
  40d939:	mov    rax,QWORD PTR [rbx+0x10]
  40d93d:	test   rax,rax
  40d940:	je     40d951 <__swc_fn_fc36583a_000157_3495a3ca+0x21>
  40d942:	mov    rcx,rbx
  40d945:	mov    rdx,rax
  40d948:	mov    r8,QWORD PTR [rbx+0x18]
  40d94c:	call   409e90 <__swc_fn_fc36583a_000156_9e2052d6>
  40d951:	vxorps xmm0,xmm0,xmm0
  40d955:	vmovups XMMWORD PTR [rbx],xmm0
  40d959:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d95e:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d963:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d968:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d96d:	mov    QWORD PTR [rbx+0x50],0x0
  40d975:	pop    rbx
  40d976:	ret
	...

000000000040d980 <__swc_fn_fc36583a_000160_dfca9093>:
  40d980:	sub    rsp,0x10
  40d984:	mov    eax,r8d
  40d987:	mov    r8d,r9d
  40d98a:	test   r9d,r9d
  40d98d:	jne    40d9a6 <__swc_fn_fc36583a_000160_dfca9093+0x26>
  40d98f:	vmovups xmm0,XMMWORD PTR [rip+0x5e81]        # 413818 <__swc_rdata_base_fc36583a+0x708>
  40d997:	vmovups XMMWORD PTR [r10],xmm0
  40d99c:	mov    eax,0x1
  40d9a1:	add    rsp,0x10
  40d9a5:	ret
  40d9a6:	mov    r9,r8
  40d9a9:	cmp    r8,rax
  40d9ac:	jb     40d9b3 <__swc_fn_fc36583a_000160_dfca9093+0x33>
  40d9ae:	cmp    r9,rdx
  40d9b1:	jb     40d9ba <__swc_fn_fc36583a_000160_dfca9093+0x3a>
  40d9b3:	xor    eax,eax
  40d9b5:	add    rsp,0x10
  40d9b9:	ret
  40d9ba:	xor    eax,eax
  40d9bc:	lea    r8,[r9+rax*1]
  40d9c0:	cmp    r8,rdx
  40d9c3:	jae    40d9f3 <__swc_fn_fc36583a_000160_dfca9093+0x73>
  40d9c5:	cs nop WORD PTR [rax+rax*1+0x0]
  40d9cf:	cs nop WORD PTR [rax+rax*1+0x0]
  40d9d9:	nop    DWORD PTR [rax+0x0]
  40d9e0:	cmp    BYTE PTR [rcx+r8*1],0x0
  40d9e5:	je     40d9f3 <__swc_fn_fc36583a_000160_dfca9093+0x73>
  40d9e7:	inc    rax
  40d9ea:	lea    r8,[r9+rax*1]
  40d9ee:	cmp    r8,rdx
  40d9f1:	jb     40d9e0 <__swc_fn_fc36583a_000160_dfca9093+0x60>
  40d9f3:	cmp    r8,rdx
  40d9f6:	jne    40d9ff <__swc_fn_fc36583a_000160_dfca9093+0x7f>
  40d9f8:	xor    eax,eax
  40d9fa:	add    rsp,0x10
  40d9fe:	ret
  40d9ff:	add    rcx,r9
  40da02:	mov    QWORD PTR [rsp],rcx
  40da06:	mov    QWORD PTR [rsp+0x8],rax
  40da0b:	vmovups xmm0,XMMWORD PTR [rsp]
  40da10:	vmovups XMMWORD PTR [r10],xmm0
  40da15:	mov    eax,0x1
  40da1a:	add    rsp,0x10
  40da1e:	ret
	...

000000000040da20 <__swc_fn_fc36583a_000163_3a7aae74>:
  40da20:	push   rbp
  40da21:	push   rbx
  40da22:	push   rsi
  40da23:	push   rdi
  40da24:	push   r12
  40da26:	push   r13
  40da28:	push   r14
  40da2a:	push   r15
  40da2c:	sub    rsp,0x10
  40da30:	mov    rbp,rsp
  40da33:	vmovups XMMWORD PTR [rsp],xmm6
  40da38:	sub    rsp,0x50
  40da3c:	mov    rbx,rsp
  40da3f:	mov    rsi,r8
  40da42:	mov    QWORD PTR [rsp+0x30],r8
  40da47:	mov    rdi,rcx
  40da4a:	mov    QWORD PTR [rsp+0x38],rcx
  40da4f:	mov    r12,rdx
  40da52:	xor    r13b,r13b
  40da55:	mov    r14,QWORD PTR [rdi+0x8]
  40da59:	mov    QWORD PTR [rsp+0x40],r14
  40da5e:	xor    r15d,r15d
  40da61:	test   r14,r14
  40da64:	jbe    40dcbe <__swc_fn_fc36583a_000163_3a7aae74+0x29e>
  40da6a:	mov    r14,QWORD PTR [rdi]
  40da6d:	mov    rax,QWORD PTR [rsp+0x40]
  40da72:	mov    QWORD PTR [rsp+0x48],r14
  40da77:	vmovups xmm6,XMMWORD PTR [rip+0x59b9]        # 413438 <__swc_rdata_base_fc36583a+0x328>
  40da7f:	nop
  40da80:	cmp    QWORD PTR [r14+r15*8],0x0
  40da85:	jne    40da8f <__swc_fn_fc36583a_000163_3a7aae74+0x6f>
  40da87:	mov    r14,rax
  40da8a:	jmp    40dc9e <__swc_fn_fc36583a_000163_3a7aae74+0x27e>
  40da8f:	mov    rcx,QWORD PTR [rdi]
  40da92:	mov    rdx,QWORD PTR [rcx+r15*8]
  40da96:	mov    rdi,rbx
  40da99:	mov    rcx,rdi
  40da9c:	sub    rsp,0x8
  40daa0:	mov    r14,rax
  40daa3:	call   409f10 <__swc_fn_fc36583a_000162_61e293bf>
  40daa8:	add    rsp,0x8
  40daac:	mov    al,BYTE PTR [rbx]
  40daae:	test   al,al
  40dab0:	je     40dc9e <__swc_fn_fc36583a_000163_3a7aae74+0x27e>
  40dab6:	mov    al,BYTE PTR [rbx+0x1]
  40dab9:	test   al,al
  40dabb:	jne    40dac6 <__swc_fn_fc36583a_000163_3a7aae74+0xa6>
  40dabd:	test   sil,sil
  40dac0:	je     40dc9e <__swc_fn_fc36583a_000163_3a7aae74+0x27e>
  40dac6:	test   r13b,r13b
  40dac9:	jne    40db87 <__swc_fn_fc36583a_000163_3a7aae74+0x167>
  40dacf:	test   r12,r12
  40dad2:	je     40db87 <__swc_fn_fc36583a_000163_3a7aae74+0x167>
  40dad8:	mov    al,BYTE PTR [rbx+0x1]
  40dadb:	test   al,al
  40dadd:	je     40dc9e <__swc_fn_fc36583a_000163_3a7aae74+0x27e>
  40dae3:	mov    eax,DWORD PTR [rbx+0x28]
  40dae6:	cmp    DWORD PTR [r12+0x20],eax
  40daeb:	jne    40dc9e <__swc_fn_fc36583a_000163_3a7aae74+0x27e>
  40daf1:	mov    rax,QWORD PTR [r12]
  40daf5:	mov    rcx,QWORD PTR [r12+0x8]
  40dafa:	cmp    QWORD PTR [rbx+0x20],rcx
  40dafe:	jne    40dc9e <__swc_fn_fc36583a_000163_3a7aae74+0x27e>
  40db04:	mov    cl,0x1
  40db06:	test   rax,rax
  40db09:	je     40db72 <__swc_fn_fc36583a_000163_3a7aae74+0x152>
  40db0f:	mov    rdx,QWORD PTR [rbx+0x20]
  40db13:	xor    r8d,r8d
  40db16:	test   rdx,rdx
  40db19:	jbe    40db72 <__swc_fn_fc36583a_000163_3a7aae74+0x152>
  40db1b:	mov    r9,QWORD PTR [rbx+0x18]
  40db1f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40db24:	cs nop WORD PTR [rax+rax*1+0x0]
  40db2e:	xchg   ax,ax
  40db30:	mov    r10b,BYTE PTR [rax+r8*1]
  40db34:	cmp    BYTE PTR [r9+r8*1],r10b
  40db38:	je     40db69 <__swc_fn_fc36583a_000163_3a7aae74+0x149>
  40db3a:	vmovq  r10,xmm0
  40db3f:	cmp    BYTE PTR [r10+r8*1],0x5c
  40db44:	jne    40db4d <__swc_fn_fc36583a_000163_3a7aae74+0x12d>
  40db46:	cmp    BYTE PTR [rax+r8*1],0x2f
  40db4b:	je     40db69 <__swc_fn_fc36583a_000163_3a7aae74+0x149>
  40db4d:	vmovq  r10,xmm0
  40db52:	cmp    BYTE PTR [r10+r8*1],0x2f
  40db57:	jne    40db60 <__swc_fn_fc36583a_000163_3a7aae74+0x140>
  40db59:	cmp    BYTE PTR [rax+r8*1],0x5c
  40db5e:	je     40db69 <__swc_fn_fc36583a_000163_3a7aae74+0x149>
  40db60:	xor    eax,eax
  40db62:	movzx  eax,al
  40db65:	mov    cl,al
  40db67:	jmp    40db72 <__swc_fn_fc36583a_000163_3a7aae74+0x152>
  40db69:	add    r8,0x1
  40db6d:	cmp    r8,rdx
  40db70:	jb     40db30 <__swc_fn_fc36583a_000163_3a7aae74+0x110>
  40db72:	test   cl,cl
  40db74:	je     40dc9e <__swc_fn_fc36583a_000163_3a7aae74+0x27e>
  40db7a:	mov    eax,0x1
  40db7f:	mov    r13b,al
  40db82:	jmp    40dc9e <__swc_fn_fc36583a_000163_3a7aae74+0x27e>
  40db87:	mov    r13b,0x1
  40db8a:	sub    rsp,0x20
  40db8e:	mov    rax,rsp
  40db91:	lea    rcx,[rdi+0x8]
  40db95:	mov    QWORD PTR [rax],rcx
  40db98:	lea    rsi,[rip+0x5771]        # 413310 <__swc_rdata_base_fc36583a+0x200>
  40db9f:	mov    QWORD PTR [rax+0x8],rsi
  40dba3:	mov    QWORD PTR [rax+0x10],rsp
  40dba7:	mov    QWORD PTR [rax+0x18],0x1
  40dbaf:	lea    rcx,[rsp+0x10]
  40dbb4:	sub    rsp,0x8
  40dbb8:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  40dbbd:	add    rsp,0x8
  40dbc1:	add    rsp,0x20
  40dbc5:	mov    al,BYTE PTR [rbx+0x1]
  40dbc8:	test   al,al
  40dbca:	je     40dc67 <__swc_fn_fc36583a_000163_3a7aae74+0x247>
  40dbd0:	lea    rax,[rip+0x5ce1]        # 4138b8 <__swc_rdata_base_fc36583a+0x7a8>
  40dbd7:	sub    rsp,0x20
  40dbdb:	mov    rcx,rsp
  40dbde:	mov    QWORD PTR [rcx],rax
  40dbe1:	mov    QWORD PTR [rcx+0x8],rsi
  40dbe5:	mov    QWORD PTR [rcx+0x10],rsp
  40dbe9:	mov    QWORD PTR [rcx+0x18],0x1
  40dbf1:	lea    rcx,[rsp+0x10]
  40dbf6:	sub    rsp,0x8
  40dbfa:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  40dbff:	add    rsp,0x8
  40dc03:	add    rsp,0x20
  40dc07:	mov    eax,DWORD PTR [rbx+0x28]
  40dc0a:	sub    rsp,0x60
  40dc0e:	mov    rcx,rsp
  40dc11:	lea    rdx,[rdi+0x18]
  40dc15:	mov    QWORD PTR [rcx+0x18],rdx
  40dc19:	mov    QWORD PTR [rcx+0x20],rsi
  40dc1d:	vmovups XMMWORD PTR [rcx],xmm6
  40dc21:	mov    QWORD PTR [rcx+0x28],rsp
  40dc25:	mov    QWORD PTR [rcx+0x30],rsi
  40dc29:	mov    DWORD PTR [rcx+0x10],eax
  40dc2c:	lea    rax,[rsp+0x10]
  40dc31:	mov    QWORD PTR [rcx+0x38],rax
  40dc35:	lea    rax,[rip+0x5794]        # 4133d0 <__swc_rdata_base_fc36583a+0x2c0>
  40dc3c:	mov    QWORD PTR [rcx+0x40],rax
  40dc40:	lea    rax,[rsp+0x18]
  40dc45:	mov    QWORD PTR [rcx+0x48],rax
  40dc49:	mov    QWORD PTR [rcx+0x50],0x3
  40dc51:	lea    rcx,[rsp+0x48]
  40dc56:	sub    rsp,0x8
  40dc5a:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  40dc5f:	add    rsp,0x8
  40dc63:	add    rsp,0x60
  40dc67:	lea    rax,[rip+0x56fa]        # 413368 <__swc_rdata_base_fc36583a+0x258>
  40dc6e:	sub    rsp,0x20
  40dc72:	mov    rcx,rsp
  40dc75:	mov    QWORD PTR [rcx],rax
  40dc78:	mov    QWORD PTR [rcx+0x8],rsi
  40dc7c:	mov    QWORD PTR [rcx+0x10],rsp
  40dc80:	mov    QWORD PTR [rcx+0x18],0x1
  40dc88:	lea    rcx,[rsp+0x10]
  40dc8d:	sub    rsp,0x8
  40dc91:	call   4109a0 <__swc_fn_fc36583a_000146_d2097256>
  40dc96:	add    rsp,0x8
  40dc9a:	add    rsp,0x20
  40dc9e:	add    r15,0x1
  40dca2:	cmp    r15,r14
  40dca5:	jae    40dcbe <__swc_fn_fc36583a_000163_3a7aae74+0x29e>
  40dca7:	mov    rsi,QWORD PTR [rsp+0x30]
  40dcac:	mov    rdi,QWORD PTR [rsp+0x38]
  40dcb1:	mov    rax,r14
  40dcb4:	mov    r14,QWORD PTR [rsp+0x48]
  40dcb9:	jmp    40da80 <__swc_fn_fc36583a_000163_3a7aae74+0x60>
  40dcbe:	add    rsp,0x50
  40dcc2:	vmovups xmm6,XMMWORD PTR [rsp]
  40dcc7:	add    rsp,0x10
  40dccb:	pop    r15
  40dccd:	pop    r14
  40dccf:	pop    r13
  40dcd1:	pop    r12
  40dcd3:	pop    rdi
  40dcd4:	pop    rsi
  40dcd5:	pop    rbx
  40dcd6:	pop    rbp
  40dcd7:	ret
	...

000000000040dce0 <__swc_fn_fc36583a_000166_c370e18e>:
  40dce0:	sub    rsp,0x8
  40dce4:	call   4103b0 <__swc_fn_fc36583a_000125_7a81492f>
  40dce9:	add    rsp,0x8
  40dced:	ret
	...

000000000040dcf0 <__swc_fn_fc36583a_000169_4694b8ad>:
  40dcf0:	push   rsi
  40dcf1:	sub    rsp,0x30
  40dcf5:	lea    rsi,[rip+0x190a4]        # 426da0 <__swc_bss_base_fc36583a+0x2d60>
  40dcfc:	mov    rax,QWORD PTR [rsi]
  40dcff:	test   rax,rax
  40dd02:	je     40dd0a <__swc_fn_fc36583a_000169_4694b8ad+0x1a>
  40dd04:	add    rsp,0x30
  40dd08:	pop    rsi
  40dd09:	ret
  40dd0a:	mov    ecx,0x2
  40dd0f:	mov    edx,0x8020
  40dd14:	call   40fa50 <__swc_fn_fc36583a_000107_c8d4a68e>
  40dd19:	test   rax,rax
  40dd1c:	jne    40dd2d <__swc_fn_fc36583a_000169_4694b8ad+0x3d>
  40dd1e:	mov    QWORD PTR [rsp+0x18],rax
  40dd23:	call   40d190 <__swc_fn_fc36583a_000118_591530fe>
  40dd28:	mov    rax,QWORD PTR [rsp+0x18]
  40dd2d:	mov    rcx,rax
  40dd30:	xchg   QWORD PTR [rsi],rcx
  40dd33:	add    rsp,0x30
  40dd37:	pop    rsi
  40dd38:	ret
  40dd39:	add    BYTE PTR [rax],al
  40dd3b:	add    BYTE PTR [rax],al
  40dd3d:	add    BYTE PTR [rax],al
	...

000000000040dd40 <__swc_fn_fc36583a_000172_1751ecdd>:
  40dd40:	push   rsi
  40dd41:	test   r8,r8
  40dd44:	jne    40dd48 <__swc_fn_fc36583a_000172_1751ecdd+0x8>
  40dd46:	pop    rsi
  40dd47:	ret
  40dd48:	lea    rax,[rcx+0x18]
  40dd4c:	mov    r10,QWORD PTR [rax]
  40dd4f:	lea    r11,[r10+0x1]
  40dd53:	mov    QWORD PTR [rax],r11
  40dd56:	mov    r11,rdx
  40dd59:	not    rdx
  40dd5c:	lea    rsi,[r8-0x1]
  40dd60:	cmp    rsi,rdx
  40dd63:	ja     40dd83 <__swc_fn_fc36583a_000172_1751ecdd+0x43>
  40dd65:	lea    rdx,[r11+r8*1]
  40dd69:	dec    rdx
  40dd6c:	shr    rdx,0x6
  40dd70:	mov    r8,r11
  40dd73:	shr    r8,0x6
  40dd77:	mov    rsi,rdx
  40dd7a:	sub    rsi,r8
  40dd7d:	cmp    rsi,0x8
  40dd81:	jb     40dd99 <__swc_fn_fc36583a_000172_1751ecdd+0x59>
  40dd83:	lea    rcx,[rcx+0x10]
  40dd87:	mov    rdx,QWORD PTR [rcx]
  40dd8a:	add    rdx,r9
  40dd8d:	mov    QWORD PTR [rcx],rdx
  40dd90:	lea    rcx,[r10+0x2]
  40dd94:	mov    QWORD PTR [rax],rcx
  40dd97:	pop    rsi
  40dd98:	ret
  40dd99:	shr    r11,0x6
  40dd9d:	nop    DWORD PTR [rax]
  40dda0:	cmp    r11,rdx
  40dda3:	ja     40dde3 <__swc_fn_fc36583a_000172_1751ecdd+0xa3>
  40dda5:	jmp    40ddb6 <__swc_fn_fc36583a_000172_1751ecdd+0x76>
  40dda7:	nop    WORD PTR [rax+rax*1+0x0]
  40ddb0:	add    r11,0x1
  40ddb4:	jmp    40dda0 <__swc_fn_fc36583a_000172_1751ecdd+0x60>
  40ddb6:	mov    r8,r11
  40ddb9:	shr    r8,0xc
  40ddbd:	mov    rsi,r11
  40ddc0:	xor    rsi,r8
  40ddc3:	mov    r8,r11
  40ddc6:	shr    r8,0x18
  40ddca:	xor    rsi,r8
  40ddcd:	and    esi,0xfff
  40ddd3:	lea    r8,[rcx+rsi*8+0x20]
  40ddd8:	mov    rsi,QWORD PTR [r8]
  40dddb:	add    rsi,r9
  40ddde:	mov    QWORD PTR [r8],rsi
  40dde1:	jmp    40ddb0 <__swc_fn_fc36583a_000172_1751ecdd+0x70>
  40dde3:	lea    rcx,[r10+0x2]
  40dde7:	mov    QWORD PTR [rax],rcx
  40ddea:	pop    rsi
  40ddeb:	ret
  40ddec:	add    BYTE PTR [rax],al
	...

000000000040ddf0 <__swc_fn_fc36583a_000175_2744b483>:
  40ddf0:	push   rbx
  40ddf1:	sub    rsp,0x70
  40ddf5:	cmp    rcx,0xffffffffffffffef
  40ddf9:	jbe    40de03 <__swc_fn_fc36583a_000175_2744b483+0x13>
  40ddfb:	xor    eax,eax
  40ddfd:	add    rsp,0x70
  40de01:	pop    rbx
  40de02:	ret
  40de03:	vxorps xmm0,xmm0,xmm0
  40de07:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40de0d:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40de13:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  40de19:	vzeroupper
  40de1c:	lea    rax,[rcx+0x10]
  40de20:	mov    QWORD PTR [rsp+0x50],rax
  40de25:	mov    DWORD PTR [rsp+0x60],0x10
  40de2d:	mov    rcx,QWORD PTR [rip+0x18f0c]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40de34:	test   rcx,rcx
  40de37:	jne    40de49 <__swc_fn_fc36583a_000175_2744b483+0x59>
  40de39:	call   40a1a0 <__swc_fn_fc36583a_000165_56054fe7>
  40de3e:	lea    rcx,[rax+0x1]
  40de42:	mov    QWORD PTR [rip+0x18ef7],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40de49:	dec    rcx
  40de4c:	call   411ee0 <__swc_fn_fc36583a_000167_39c041ad>
  40de51:	mov    rcx,QWORD PTR [rax]
  40de54:	lea    rdx,[rsp+0x8]
  40de59:	mov    rbx,QWORD PTR [rax+0x8]
  40de5d:	mov    rbx,QWORD PTR [rbx+0x8]
  40de61:	call   rbx
  40de63:	mov    rax,QWORD PTR [rsp+0x48]
  40de68:	test   rax,rax
  40de6b:	jne    40de75 <__swc_fn_fc36583a_000175_2744b483+0x85>
  40de6d:	xor    eax,eax
  40de6f:	add    rsp,0x70
  40de73:	pop    rbx
  40de74:	ret
  40de75:	mov    rcx,QWORD PTR [rsp+0x50]
  40de7a:	mov    QWORD PTR [rax],rcx
  40de7d:	mov    QWORD PTR [rax+0x8],0x0
  40de85:	lea    rax,[rax+0x10]
  40de89:	add    rsp,0x70
  40de8d:	pop    rbx
  40de8e:	ret
	...

000000000040dea0 <__swc_fn_fc36583a_000002_102336c4>:
  40dea0:	sub    rsp,0x8
  40dea4:	call   40cde0 <__swc_fn_fc36583a_000109_9f5af8ae>
  40dea9:	mov    rcx,rax
  40deac:	test   rax,rax
  40deaf:	je     40ded6 <__swc_fn_fc36583a_000002_102336c4+0x36>
  40deb1:	lea    rdx,[rip+0x16188]        # 424040 <__swc_bss_base_fc36583a>
  40deb8:	mov    r8,QWORD PTR [rip+0x16181]        # 424040 <__swc_bss_base_fc36583a>
  40debf:	nop
  40dec0:	lea    r9,[r8+0x1]
  40dec4:	mov    rax,r8
  40dec7:	lock cmpxchg QWORD PTR [rdx],r9
  40decc:	cmp    rax,r8
  40decf:	je     40ded6 <__swc_fn_fc36583a_000002_102336c4+0x36>
  40ded1:	mov    r8,rax
  40ded4:	jmp    40dec0 <__swc_fn_fc36583a_000002_102336c4+0x20>
  40ded6:	mov    rax,rcx
  40ded9:	add    rsp,0x8
  40dedd:	ret
	...

000000000040dee0 <__swc_fn_fc36583a_000005_6a556171>:
  40dee0:	mov    r8d,edx
  40dee3:	xor    eax,eax
  40dee5:	tzcnt  eax,edx
  40dee9:	shrx   r9d,edx,eax
  40deee:	mov    DWORD PTR [rcx+0x2c],edx
  40def1:	xor    eax,eax
  40def3:	tzcnt  eax,edx
  40def7:	mov    BYTE PTR [rcx+0x38],al
  40defa:	mov    eax,0xffffffff
  40deff:	xor    edx,edx
  40df01:	div    r8d
  40df04:	mov    DWORD PTR [rcx+0x34],eax
  40df07:	mov    eax,r9d
  40df0a:	mov    edx,r9d
  40df0d:	imul   edx,r9d
  40df11:	mov    r8d,0x2
  40df17:	sub    r8d,edx
  40df1a:	imul   eax,r8d
  40df1e:	mov    edx,r9d
  40df21:	imul   edx,eax
  40df24:	mov    r8d,0x2
  40df2a:	sub    r8d,edx
  40df2d:	imul   eax,r8d
  40df31:	mov    edx,r9d
  40df34:	imul   edx,eax
  40df37:	mov    r8d,0x2
  40df3d:	sub    r8d,edx
  40df40:	imul   eax,r8d
  40df44:	mov    edx,r9d
  40df47:	imul   edx,eax
  40df4a:	mov    r8d,0x2
  40df50:	sub    r8d,edx
  40df53:	imul   eax,r8d
  40df57:	imul   r9d,eax
  40df5b:	mov    edx,0x2
  40df60:	sub    edx,r9d
  40df63:	imul   eax,edx
  40df66:	mov    DWORD PTR [rcx+0x30],eax
  40df69:	ret
  40df6a:	add    BYTE PTR [rax],al
  40df6c:	add    BYTE PTR [rax],al
	...

000000000040df70 <__swc_fn_fc36583a_000008_b2f73e0d>:
  40df70:	xor    eax,eax
  40df72:	mov    DWORD PTR [rcx+0x68],eax
  40df75:	ret
	...

000000000040df80 <__swc_fn_fc36583a_000011_71c91685>:
  40df80:	mov    eax,DWORD PTR [rcx+0x28]
  40df83:	shlx   eax,edx,eax
  40df88:	shl    rax,0x10
  40df8c:	lea    rdx,[rcx+rax*1]
  40df90:	lea    rax,[rcx+0x3000]
  40df97:	cmp    rdx,rax
  40df9a:	cmovae rax,rdx
  40df9e:	ret
	...

000000000040dfa0 <__swc_fn_fc36583a_000014_be17798c>:
  40dfa0:	push   rsi
  40dfa1:	push   rdi
  40dfa2:	push   r12
  40dfa4:	push   r13
  40dfa6:	push   r14
  40dfa8:	mov    rsi,rdx
  40dfab:	mov    rdi,rcx
  40dfae:	rex mov dl,BYTE PTR [rsi+0x3a]
  40dfb2:	mov    ecx,DWORD PTR [rdi+0x28]
  40dfb5:	shr    dl,cl
  40dfb7:	mov    r12d,0x1
  40dfbd:	mov    ecx,edx
  40dfbf:	shl    r12,cl
  40dfc2:	mov    r13d,DWORD PTR [rsi+0x3c]
  40dfc6:	rex mov BYTE PTR [rsi+0x3b],0x0
  40dfcb:	mov    QWORD PTR [rsi+0x40],0x0
  40dfd3:	mov    QWORD PTR [rsi],0x0
  40dfda:	mov    rax,QWORD PTR [rsi+0x10]
  40dfde:	mov    QWORD PTR [rsi+0x20],rax
  40dfe2:	lea    r14,[rip+0x1605f]        # 424048 <__swc_bss_base_fc36583a+0x8>
  40dfe9:	mov    rax,QWORD PTR [r14]
  40dfec:	shr    rax,0x2
  40dff0:	mov    rcx,rax
  40dff3:	cmp    rax,0x800000
  40dffa:	mov    eax,0x800000
  40dfff:	cmovb  rcx,rax
  40e003:	lea    r8,[rip+0x1604e]        # 424058 <__swc_bss_base_fc36583a+0x18>
  40e00a:	mov    rax,QWORD PTR [r8]
  40e00d:	mov    r9,rax
  40e010:	lea    r10,[r9+r13*1]
  40e014:	cmp    r10,rcx
  40e017:	ja     40e03b <__swc_fn_fc36583a_000014_be17798c+0x9b>
  40e019:	mov    rax,r9
  40e01c:	lock cmpxchg QWORD PTR [r8],r10
  40e021:	cmp    rax,r9
  40e024:	je     40e02b <__swc_fn_fc36583a_000014_be17798c+0x8b>
  40e026:	mov    r9,rax
  40e029:	jmp    40e010 <__swc_fn_fc36583a_000014_be17798c+0x70>
  40e02b:	mov    rcx,rdi
  40e02e:	mov    rdx,r12
  40e031:	call   40af10 <__swc_fn_fc36583a_000016_a0b588d0>
  40e036:	jmp    40e0bd <__swc_fn_fc36583a_000014_be17798c+0x11d>
  40e03b:	mov    rcx,rdi
  40e03e:	movzx  edx,dl
  40e041:	call   40df80 <__swc_fn_fc36583a_000011_71c91685>
  40e046:	test   r13,r13
  40e049:	je     40e0b6 <__swc_fn_fc36583a_000014_be17798c+0x116>
  40e04f:	mov    rcx,rax
  40e052:	mov    rdx,r13
  40e055:	call   40cf60 <__swc_fn_fc36583a_000112_2f7f9346>
  40e05a:	mov    rcx,QWORD PTR [rip+0x15fe7]        # 424048 <__swc_bss_base_fc36583a+0x8>
  40e061:	cs nop WORD PTR [rax+rax*1+0x0]
  40e06b:	nop    DWORD PTR [rax+rax*1+0x0]
  40e070:	mov    rdx,rcx
  40e073:	sub    rdx,r13
  40e076:	mov    rax,rcx
  40e079:	lock cmpxchg QWORD PTR [r14],rdx
  40e07e:	cmp    rax,rcx
  40e081:	je     40e088 <__swc_fn_fc36583a_000014_be17798c+0xe8>
  40e083:	mov    rcx,rax
  40e086:	jmp    40e070 <__swc_fn_fc36583a_000014_be17798c+0xd0>
  40e088:	lea    rcx,[rip+0x15fd1]        # 424060 <__swc_bss_base_fc36583a+0x20>
  40e08f:	mov    rdx,QWORD PTR [rip+0x15fca]        # 424060 <__swc_bss_base_fc36583a+0x20>
  40e096:	cs nop WORD PTR [rax+rax*1+0x0]
  40e0a0:	lea    r8,[rdx+0x1]
  40e0a4:	mov    rax,rdx
  40e0a7:	lock cmpxchg QWORD PTR [rcx],r8
  40e0ac:	cmp    rax,rdx
  40e0af:	je     40e0b6 <__swc_fn_fc36583a_000014_be17798c+0x116>
  40e0b1:	mov    rdx,rax
  40e0b4:	jmp    40e0a0 <__swc_fn_fc36583a_000014_be17798c+0x100>
  40e0b6:	mov    DWORD PTR [rsi+0x3c],0x0
  40e0bd:	mov    rcx,rdi
  40e0c0:	mov    rdx,r12
  40e0c3:	call   407600 <__swc_fn_fc36583a_000018_77ece227>
  40e0c8:	pop    r14
  40e0ca:	pop    r13
  40e0cc:	pop    r12
  40e0ce:	pop    rdi
  40e0cf:	pop    rsi
  40e0d0:	ret
	...

000000000040e0e0 <__swc_fn_fc36583a_000017_f003fc47>:
  40e0e0:	mov    r8,QWORD PTR [rcx+0x48]
  40e0e4:	test   r8,rdx
  40e0e7:	je     40e118 <__swc_fn_fc36583a_000017_f003fc47+0x38>
  40e0e9:	nop    DWORD PTR [rax+0x0]
  40e0f0:	mov    rax,rdx
  40e0f3:	not    rax
  40e0f6:	mov    r9,r8
  40e0f9:	and    r9,rax
  40e0fc:	mov    rax,r8
  40e0ff:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40e105:	cmp    rax,r8
  40e108:	jne    40e110 <__swc_fn_fc36583a_000017_f003fc47+0x30>
  40e10a:	mov    eax,0x1
  40e10f:	ret
  40e110:	mov    r8,rax
  40e113:	test   rax,rdx
  40e116:	jne    40e0f0 <__swc_fn_fc36583a_000017_f003fc47+0x10>
  40e118:	xor    eax,eax
  40e11a:	ret
  40e11b:	add    BYTE PTR [rax],al
  40e11d:	add    BYTE PTR [rax],al
	...

000000000040e120 <__swc_fn_fc36583a_000020_4285d9c5>:
  40e120:	push   rsi
  40e121:	push   rdi
  40e122:	push   r12
  40e124:	push   r13
  40e126:	sub    rsp,0x8
  40e12a:	mov    rsi,rdx
  40e12d:	mov    rdi,rcx
  40e130:	lea    r12,[rip+0x160b9]        # 4241f0 <__swc_bss_base_fc36583a+0x1b0>
  40e137:	mov    rcx,r12
  40e13a:	call   4098a0 <__swc_fn_fc36583a_000135_db32cc57>
  40e13f:	xor    eax,eax
  40e141:	mov    rcx,QWORD PTR [rip+0x160b0]        # 4241f8 <__swc_bss_base_fc36583a+0x1b8>
  40e148:	mov    r13,rcx
  40e14b:	test   r13,r13
  40e14e:	je     40e19b <__swc_fn_fc36583a_000020_4285d9c5+0x7b>
  40e150:	mov    rcx,QWORD PTR [r13+0x10]
  40e154:	cmp    DWORD PTR [r13+0x28],esi
  40e158:	jne    40e190 <__swc_fn_fc36583a_000020_4285d9c5+0x70>
  40e15a:	test   rax,rax
  40e15d:	jne    40e168 <__swc_fn_fc36583a_000020_4285d9c5+0x48>
  40e15f:	mov    QWORD PTR [rip+0x16092],rcx        # 4241f8 <__swc_bss_base_fc36583a+0x1b8>
  40e166:	jmp    40e16c <__swc_fn_fc36583a_000020_4285d9c5+0x4c>
  40e168:	mov    QWORD PTR [rax+0x10],rcx
  40e16c:	vxorps xmm0,xmm0,xmm0
  40e170:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40e176:	mov    QWORD PTR [r13+0x8],rdi
  40e17a:	mov    rcx,r12
  40e17d:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  40e182:	mov    rax,r13
  40e185:	add    rsp,0x8
  40e189:	pop    r13
  40e18b:	pop    r12
  40e18d:	pop    rdi
  40e18e:	pop    rsi
  40e18f:	ret
  40e190:	mov    rax,r13
  40e193:	mov    r13,rcx
  40e196:	test   rcx,rcx
  40e199:	jne    40e150 <__swc_fn_fc36583a_000020_4285d9c5+0x30>
  40e19b:	mov    ecx,esi
  40e19d:	call   40af40 <__swc_fn_fc36583a_000019_447bb610>
  40e1a2:	mov    rsi,rax
  40e1a5:	test   rax,rax
  40e1a8:	jne    40e1bf <__swc_fn_fc36583a_000020_4285d9c5+0x9f>
  40e1aa:	mov    rcx,r12
  40e1ad:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  40e1b2:	xor    eax,eax
  40e1b4:	add    rsp,0x8
  40e1b8:	pop    r13
  40e1ba:	pop    r12
  40e1bc:	pop    rdi
  40e1bd:	pop    rsi
  40e1be:	ret
  40e1bf:	mov    QWORD PTR [rsi+0x8],rdi
  40e1c3:	mov    rcx,r12
  40e1c6:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  40e1cb:	mov    rax,rsi
  40e1ce:	add    rsp,0x8
  40e1d2:	pop    r13
  40e1d4:	pop    r12
  40e1d6:	pop    rdi
  40e1d7:	pop    rsi
  40e1d8:	ret
  40e1d9:	add    BYTE PTR [rax],al
  40e1db:	add    BYTE PTR [rax],al
  40e1dd:	add    BYTE PTR [rax],al
	...

000000000040e1e0 <__swc_fn_fc36583a_000023_e876734d>:
  40e1e0:	vxorps xmm0,xmm0,xmm0
  40e1e4:	xor    eax,eax
  40e1e6:	cs nop WORD PTR [rax+rax*1+0x0]
  40e1f0:	cs nop WORD PTR [rax+rax*1+0x0]
  40e1fa:	nop    WORD PTR [rax+rax*1+0x0]
  40e200:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40e205:	add    rax,0x10
  40e209:	cmp    rax,0x2b00
  40e210:	jne    40e200 <__swc_fn_fc36583a_000023_e876734d+0x20>
  40e212:	ret
	...

000000000040e220 <__swc_fn_fc36583a_000026_e876734d>:
  40e220:	vxorps xmm0,xmm0,xmm0
  40e224:	vmovups XMMWORD PTR [rcx],xmm0
  40e228:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e22d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e232:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e237:	ret
	...

000000000040e240 <__swc_fn_fc36583a_000029_e876734d>:
  40e240:	vxorps xmm0,xmm0,xmm0
  40e244:	vmovups XMMWORD PTR [rcx],xmm0
  40e248:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e24d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e252:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e257:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40e25c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40e261:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40e266:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40e26b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40e273:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40e27b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40e283:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40e28b:	mov    QWORD PTR [rcx+0xc0],0x0
  40e296:	ret
	...

000000000040e2a0 <__swc_fn_fc36583a_000032_f1940e30>:
  40e2a0:	push   rsi
  40e2a1:	push   rdi
  40e2a2:	sub    rsp,0x8
  40e2a6:	mov    rsi,rcx
  40e2a9:	lea    rdi,[rip+0x13d50]        # 422000 <__swc_data_base_fc36583a>
  40e2b0:	mov    rax,QWORD PTR [rdi]
  40e2b3:	cmp    rax,0xffffffffffffffff
  40e2b7:	je     40e2be <__swc_fn_fc36583a_000032_f1940e30+0x1e>
  40e2b9:	mov    rdi,rax
  40e2bc:	jmp    40e2eb <__swc_fn_fc36583a_000032_f1940e30+0x4b>
  40e2be:	call   409580 <__swc_fn_fc36583a_000123_e4107ade>
  40e2c3:	mov    rcx,rax
  40e2c6:	cmp    rax,0xffffffffffffffff
  40e2ca:	je     40e2fc <__swc_fn_fc36583a_000032_f1940e30+0x5c>
  40e2cc:	mov    rax,0xffffffffffffffff
  40e2d3:	lock cmpxchg QWORD PTR [rdi],rcx
  40e2d8:	cmp    rax,0xffffffffffffffff
  40e2dc:	je     40e2e8 <__swc_fn_fc36583a_000032_f1940e30+0x48>
  40e2de:	mov    rdi,rax
  40e2e1:	call   40d330 <__swc_fn_fc36583a_000124_37eaf452>
  40e2e6:	jmp    40e2eb <__swc_fn_fc36583a_000032_f1940e30+0x4b>
  40e2e8:	mov    rdi,rcx
  40e2eb:	cmp    rdi,0xffffffffffffffff
  40e2ef:	je     40e2fc <__swc_fn_fc36583a_000032_f1940e30+0x5c>
  40e2f1:	mov    rcx,rdi
  40e2f4:	mov    rdx,rsi
  40e2f7:	call   4103b0 <__swc_fn_fc36583a_000125_7a81492f>
  40e2fc:	add    rsp,0x8
  40e300:	pop    rdi
  40e301:	pop    rsi
  40e302:	ret
	...

000000000040e310 <__swc_fn_fc36583a_000035_ab2e8c35>:
  40e310:	sub    rsp,0x38
  40e314:	mov    rax,rdx
  40e317:	test   dl,dl
  40e319:	jne    40e331 <__swc_fn_fc36583a_000035_ab2e8c35+0x21>
  40e31b:	mov    rax,r8
  40e31e:	test   r8b,r8b
  40e321:	cmove  eax,r9d
  40e325:	test   al,al
  40e327:	cmove  eax,r10d
  40e32b:	test   al,al
  40e32d:	cmove  eax,r11d
  40e331:	test   al,al
  40e333:	jne    40e33a <__swc_fn_fc36583a_000035_ab2e8c35+0x2a>
  40e335:	add    rsp,0x38
  40e339:	ret
  40e33a:	lea    rcx,[rip+0x4dcf]        # 413110 <__swc_rdata_base_fc36583a>
  40e341:	vmovups xmm0,XMMWORD PTR [rip+0x4dd7]        # 413120 <__swc_rdata_base_fc36583a+0x10>
  40e349:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e34f:	vmovups xmm0,XMMWORD PTR [rip+0x4dd9]        # 413130 <__swc_rdata_base_fc36583a+0x20>
  40e357:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e35d:	vmovups xmm0,XMMWORD PTR [rip+0x4ddb]        # 413140 <__swc_rdata_base_fc36583a+0x30>
  40e365:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e36b:	lea    rdx,[rsp+0x8]
  40e370:	call   40cb60 <__swc_fn_fc36583a_000103_0d4cc079>
  40e375:	jmp    40e335 <__swc_fn_fc36583a_000035_ab2e8c35+0x25>
	...

000000000040e380 <__swc_fn_fc36583a_000038_292d55e5>:
  40e380:	sub    rsp,0x8
  40e384:	mov    eax,0x1000
  40e389:	test   eax,eax
  40e38b:	mov    r8d,0x8
  40e391:	cmove  eax,r8d
  40e395:	dec    rax
  40e398:	mov    r8,0xffffffffffffffff
  40e39f:	sub    r8,rax
  40e3a2:	cmp    rdx,r8
  40e3a5:	ja     40e3b5 <__swc_fn_fc36583a_000038_292d55e5+0x35>
  40e3a7:	add    rdx,rax
  40e3aa:	not    rax
  40e3ad:	mov    r8,rdx
  40e3b0:	and    r8,rax
  40e3b3:	jne    40e3bc <__swc_fn_fc36583a_000038_292d55e5+0x3c>
  40e3b5:	xor    eax,eax
  40e3b7:	add    rsp,0x8
  40e3bb:	ret
  40e3bc:	mov    rdx,r8
  40e3bf:	call   40b260 <__swc_fn_fc36583a_000037_1e381f55>
  40e3c4:	add    rsp,0x8
  40e3c8:	ret
  40e3c9:	add    BYTE PTR [rax],al
  40e3cb:	add    BYTE PTR [rax],al
  40e3cd:	add    BYTE PTR [rax],al
	...

000000000040e3d0 <__swc_fn_fc36583a_000041_41400651>:
  40e3d0:	push   rsi
  40e3d1:	push   rdi
  40e3d2:	sub    rsp,0x8
  40e3d6:	mov    rsi,rdx
  40e3d9:	mov    rdi,rcx
  40e3dc:	test   rdx,rdx
  40e3df:	je     40e3fb <__swc_fn_fc36583a_000041_41400651+0x2b>
  40e3e1:	xor    ecx,ecx
  40e3e3:	call   407720 <__swc_fn_fc36583a_000033_d15eb4ea>
  40e3e8:	mov    rax,QWORD PTR [rsi]
  40e3eb:	test   rax,rax
  40e3ee:	je     40e3fb <__swc_fn_fc36583a_000041_41400651+0x2b>
  40e3f0:	mov    rcx,rax
  40e3f3:	mov    rdx,rsi
  40e3f6:	call   407840 <__swc_fn_fc36583a_000042_0573444d>
  40e3fb:	mov    rcx,rdi
  40e3fe:	call   40b2c0 <__swc_fn_fc36583a_000040_8029566e>
  40e403:	mov    rsi,rax
  40e406:	test   rax,rax
  40e409:	jne    40e414 <__swc_fn_fc36583a_000041_41400651+0x44>
  40e40b:	xor    eax,eax
  40e40d:	add    rsp,0x8
  40e411:	pop    rdi
  40e412:	pop    rsi
  40e413:	ret
  40e414:	mov    rcx,rsi
  40e417:	call   407720 <__swc_fn_fc36583a_000033_d15eb4ea>
  40e41c:	mov    rax,rsi
  40e41f:	add    rsp,0x8
  40e423:	pop    rdi
  40e424:	pop    rsi
  40e425:	ret
	...

000000000040e430 <__swc_fn_fc36583a_000044_fe6bbfdb>:
  40e430:	movzx  eax,BYTE PTR [r8+0x39]
  40e435:	lea    rax,[rax+rax*4]
  40e439:	lea    rax,[rdx+rax*8+0x28]
  40e43e:	mov    ecx,DWORD PTR [r8+0x6c]
  40e442:	test   ecx,ecx
  40e444:	je     40e47d <__swc_fn_fc36583a_000044_fe6bbfdb+0x4d>
  40e446:	mov    rcx,QWORD PTR [r8+0x50]
  40e44a:	test   rcx,rcx
  40e44d:	je     40e459 <__swc_fn_fc36583a_000044_fe6bbfdb+0x29>
  40e44f:	mov    rax,QWORD PTR [r8+0x48]
  40e453:	mov    QWORD PTR [rcx+0x48],rax
  40e457:	jmp    40e461 <__swc_fn_fc36583a_000044_fe6bbfdb+0x31>
  40e459:	mov    rcx,QWORD PTR [r8+0x48]
  40e45d:	mov    QWORD PTR [rax+0x18],rcx
  40e461:	mov    rax,QWORD PTR [r8+0x48]
  40e465:	test   rax,rax
  40e468:	je     40e472 <__swc_fn_fc36583a_000044_fe6bbfdb+0x42>
  40e46a:	mov    rcx,QWORD PTR [r8+0x50]
  40e46e:	mov    QWORD PTR [rax+0x50],rcx
  40e472:	vxorps xmm0,xmm0,xmm0
  40e476:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e47c:	ret
  40e47d:	mov    rcx,QWORD PTR [r8+0x50]
  40e481:	test   rcx,rcx
  40e484:	je     40e490 <__swc_fn_fc36583a_000044_fe6bbfdb+0x60>
  40e486:	mov    rdx,QWORD PTR [r8+0x48]
  40e48a:	mov    QWORD PTR [rcx+0x48],rdx
  40e48e:	jmp    40e498 <__swc_fn_fc36583a_000044_fe6bbfdb+0x68>
  40e490:	mov    rcx,QWORD PTR [r8+0x48]
  40e494:	mov    QWORD PTR [rax+0x8],rcx
  40e498:	mov    rcx,QWORD PTR [r8+0x48]
  40e49c:	test   rcx,rcx
  40e49f:	je     40e4ab <__swc_fn_fc36583a_000044_fe6bbfdb+0x7b>
  40e4a1:	mov    rdx,QWORD PTR [r8+0x50]
  40e4a5:	mov    QWORD PTR [rcx+0x50],rdx
  40e4a9:	jmp    40e4b3 <__swc_fn_fc36583a_000044_fe6bbfdb+0x83>
  40e4ab:	mov    rcx,QWORD PTR [r8+0x50]
  40e4af:	mov    QWORD PTR [rax+0x10],rcx
  40e4b3:	cmp    QWORD PTR [rax],r8
  40e4b6:	jne    40e4bf <__swc_fn_fc36583a_000044_fe6bbfdb+0x8f>
  40e4b8:	mov    QWORD PTR [rax],0x0
  40e4bf:	vxorps xmm0,xmm0,xmm0
  40e4c3:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e4c9:	ret
  40e4ca:	add    BYTE PTR [rax],al
  40e4cc:	add    BYTE PTR [rax],al
	...

000000000040e4d0 <__swc_fn_fc36583a_000047_e7fd8d42>:
  40e4d0:	sub    rsp,0x8
  40e4d4:	mov    r9,r8
  40e4d7:	mov    r10,rdx
  40e4da:	call   40e430 <__swc_fn_fc36583a_000044_fe6bbfdb>
  40e4df:	mov    DWORD PTR [r9+0x6c],0x0
  40e4e7:	movzx  eax,BYTE PTR [r9+0x39]
  40e4ec:	lea    rax,[rax+rax*4]
  40e4f0:	lea    rax,[r10+rax*8+0x28]
  40e4f5:	mov    rcx,QWORD PTR [rax+0x10]
  40e4f9:	mov    QWORD PTR [r9+0x50],rcx
  40e4fd:	mov    QWORD PTR [r9+0x48],0x0
  40e505:	mov    rcx,QWORD PTR [rax+0x10]
  40e509:	test   rcx,rcx
  40e50c:	je     40e514 <__swc_fn_fc36583a_000047_e7fd8d42+0x44>
  40e50e:	mov    QWORD PTR [rcx+0x48],r9
  40e512:	jmp    40e518 <__swc_fn_fc36583a_000047_e7fd8d42+0x48>
  40e514:	mov    QWORD PTR [rax+0x8],r9
  40e518:	mov    QWORD PTR [rax+0x10],r9
  40e51c:	add    rsp,0x8
  40e520:	ret
	...

000000000040e540 <__swc_fn_fc36583a_000050_5e919db9>:
  40e540:	push   rsi
  40e541:	push   rdi
  40e542:	push   r12
  40e544:	push   r13
  40e546:	push   r14
  40e548:	push   r15
  40e54a:	sub    rsp,0x1f8
  40e551:	mov    esi,r8d
  40e554:	mov    QWORD PTR [rsp+0x1e8],rsi
  40e55c:	mov    rdi,rcx
  40e55f:	mov    r12,rdx
  40e562:	lea    r13,[rsi+rsi*4]
  40e566:	lea    r13,[rdx+r13*8+0x28]
  40e56b:	call   407ca0 <__swc_fn_fc36583a_000048_8e68f77b>
  40e570:	add    DWORD PTR [r12+0x24],0x1
  40e576:	test   BYTE PTR [r12+0x24],0x3f
  40e57c:	jne    40e586 <__swc_fn_fc36583a_000050_5e919db9+0x46>
  40e57e:	mov    rcx,rdi
  40e581:	call   40b440 <__swc_fn_fc36583a_000049_f6a485a2>
  40e586:	mov    rax,QWORD PTR [r13+0x8]
  40e58a:	mov    r14,rax
  40e58d:	nop    DWORD PTR [rax]
  40e590:	test   r14,r14
  40e593:	jne    40e5a2 <__swc_fn_fc36583a_000050_5e919db9+0x62>
  40e595:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40e59d:	jmp    40e6a9 <__swc_fn_fc36583a_000050_5e919db9+0x169>
  40e5a2:	mov    r15,QWORD PTR [r14+0x48]
  40e5a6:	mov    rcx,r14
  40e5a9:	call   4073f0 <__swc_fn_fc36583a_000009_4c3ebf16>
  40e5ae:	mov    rax,QWORD PTR [r14]
  40e5b1:	test   rax,rax
  40e5b4:	je     40e5c6 <__swc_fn_fc36583a_000050_5e919db9+0x86>
  40e5b6:	mov    rcx,QWORD PTR [rax]
  40e5b9:	mov    QWORD PTR [r14],rcx
  40e5bc:	add    DWORD PTR [r14+0x28],0x1
  40e5c1:	mov    rsi,rax
  40e5c4:	jmp    40e5e5 <__swc_fn_fc36583a_000050_5e919db9+0xa5>
  40e5c6:	mov    rax,QWORD PTR [r14+0x18]
  40e5ca:	cmp    QWORD PTR [r14+0x20],rax
  40e5ce:	jae    40e5e3 <__swc_fn_fc36583a_000050_5e919db9+0xa3>
  40e5d0:	mov    rsi,QWORD PTR [r14+0x20]
  40e5d4:	mov    eax,DWORD PTR [r14+0x2c]
  40e5d8:	add    QWORD PTR [r14+0x20],rax
  40e5dc:	add    DWORD PTR [r14+0x28],0x1
  40e5e1:	jmp    40e5e5 <__swc_fn_fc36583a_000050_5e919db9+0xa5>
  40e5e3:	xor    esi,esi
  40e5e5:	test   rsi,rsi
  40e5e8:	jne    40e62d <__swc_fn_fc36583a_000050_5e919db9+0xed>
  40e5ea:	mov    rcx,r14
  40e5ed:	call   407320 <__swc_fn_fc36583a_000006_7b253ae1>
  40e5f2:	test   al,al
  40e5f4:	je     40e62d <__swc_fn_fc36583a_000050_5e919db9+0xed>
  40e5f6:	mov    rax,QWORD PTR [r14]
  40e5f9:	test   rax,rax
  40e5fc:	je     40e60b <__swc_fn_fc36583a_000050_5e919db9+0xcb>
  40e5fe:	mov    rcx,QWORD PTR [rax]
  40e601:	mov    QWORD PTR [r14],rcx
  40e604:	add    DWORD PTR [r14+0x28],0x1
  40e609:	jmp    40e62a <__swc_fn_fc36583a_000050_5e919db9+0xea>
  40e60b:	mov    rax,QWORD PTR [r14+0x18]
  40e60f:	cmp    QWORD PTR [r14+0x20],rax
  40e613:	jae    40e628 <__swc_fn_fc36583a_000050_5e919db9+0xe8>
  40e615:	mov    rax,QWORD PTR [r14+0x20]
  40e619:	mov    ecx,DWORD PTR [r14+0x2c]
  40e61d:	add    QWORD PTR [r14+0x20],rcx
  40e621:	add    DWORD PTR [r14+0x28],0x1
  40e626:	jmp    40e62a <__swc_fn_fc36583a_000050_5e919db9+0xea>
  40e628:	xor    eax,eax
  40e62a:	mov    rsi,rax
  40e62d:	test   rsi,rsi
  40e630:	jne    40e683 <__swc_fn_fc36583a_000050_5e919db9+0x143>
  40e632:	mov    rcx,rdi
  40e635:	mov    rdx,r12
  40e638:	mov    r8,r14
  40e63b:	call   40b3a0 <__swc_fn_fc36583a_000046_b28a6ee7>
  40e640:	test   al,al
  40e642:	jne    40e683 <__swc_fn_fc36583a_000050_5e919db9+0x143>
  40e644:	mov    rcx,r14
  40e647:	call   4073f0 <__swc_fn_fc36583a_000009_4c3ebf16>
  40e64c:	mov    rax,QWORD PTR [r14]
  40e64f:	test   rax,rax
  40e652:	je     40e661 <__swc_fn_fc36583a_000050_5e919db9+0x121>
  40e654:	mov    rcx,QWORD PTR [rax]
  40e657:	mov    QWORD PTR [r14],rcx
  40e65a:	add    DWORD PTR [r14+0x28],0x1
  40e65f:	jmp    40e680 <__swc_fn_fc36583a_000050_5e919db9+0x140>
  40e661:	mov    rax,QWORD PTR [r14+0x18]
  40e665:	cmp    QWORD PTR [r14+0x20],rax
  40e669:	jae    40e67e <__swc_fn_fc36583a_000050_5e919db9+0x13e>
  40e66b:	mov    rax,QWORD PTR [r14+0x20]
  40e66f:	mov    ecx,DWORD PTR [r14+0x2c]
  40e673:	add    QWORD PTR [r14+0x20],rcx
  40e677:	add    DWORD PTR [r14+0x28],0x1
  40e67c:	jmp    40e680 <__swc_fn_fc36583a_000050_5e919db9+0x140>
  40e67e:	xor    eax,eax
  40e680:	mov    rsi,rax
  40e683:	test   rsi,rsi
  40e686:	je     40e6a1 <__swc_fn_fc36583a_000050_5e919db9+0x161>
  40e688:	mov    QWORD PTR [r13+0x0],r14
  40e68c:	mov    rax,rsi
  40e68f:	add    rsp,0x1f8
  40e696:	pop    r15
  40e698:	pop    r14
  40e69a:	pop    r13
  40e69c:	pop    r12
  40e69e:	pop    rdi
  40e69f:	pop    rsi
  40e6a0:	ret
  40e6a1:	mov    r14,r15
  40e6a4:	jmp    40e590 <__swc_fn_fc36583a_000050_5e919db9+0x50>
  40e6a9:	cs nop WORD PTR [rax+rax*1+0x0]
  40e6b3:	cs nop WORD PTR [rax+rax*1+0x0]
  40e6bd:	nop    DWORD PTR [rax]
  40e6c0:	mov    rcx,rdi
  40e6c3:	mov    rdx,r12
  40e6c6:	mov    r8d,esi
  40e6c9:	call   4079e0 <__swc_fn_fc36583a_000045_bb688d37>
  40e6ce:	mov    r14,rax
  40e6d1:	test   rax,rax
  40e6d4:	jne    40e6ea <__swc_fn_fc36583a_000050_5e919db9+0x1aa>
  40e6d6:	xor    eax,eax
  40e6d8:	add    rsp,0x1f8
  40e6df:	pop    r15
  40e6e1:	pop    r14
  40e6e3:	pop    r13
  40e6e5:	pop    r12
  40e6e7:	pop    rdi
  40e6e8:	pop    rsi
  40e6e9:	ret
  40e6ea:	mov    QWORD PTR [r13+0x0],r14
  40e6ee:	mov    rax,QWORD PTR [r14]
  40e6f1:	test   rax,rax
  40e6f4:	je     40e706 <__swc_fn_fc36583a_000050_5e919db9+0x1c6>
  40e6f6:	mov    rcx,QWORD PTR [rax]
  40e6f9:	mov    QWORD PTR [r14],rcx
  40e6fc:	add    DWORD PTR [r14+0x28],0x1
  40e701:	mov    r15,rax
  40e704:	jmp    40e726 <__swc_fn_fc36583a_000050_5e919db9+0x1e6>
  40e706:	mov    rax,QWORD PTR [r14+0x18]
  40e70a:	cmp    QWORD PTR [r14+0x20],rax
  40e70e:	jae    40e723 <__swc_fn_fc36583a_000050_5e919db9+0x1e3>
  40e710:	mov    r15,QWORD PTR [r14+0x20]
  40e714:	mov    eax,DWORD PTR [r14+0x2c]
  40e718:	add    QWORD PTR [r14+0x20],rax
  40e71c:	add    DWORD PTR [r14+0x28],0x1
  40e721:	jmp    40e726 <__swc_fn_fc36583a_000050_5e919db9+0x1e6>
  40e723:	xor    r15d,r15d
  40e726:	test   r15,r15
  40e729:	jne    40e76e <__swc_fn_fc36583a_000050_5e919db9+0x22e>
  40e72b:	mov    rcx,r14
  40e72e:	call   407320 <__swc_fn_fc36583a_000006_7b253ae1>
  40e733:	test   al,al
  40e735:	je     40e76e <__swc_fn_fc36583a_000050_5e919db9+0x22e>
  40e737:	mov    rax,QWORD PTR [r14]
  40e73a:	test   rax,rax
  40e73d:	je     40e74c <__swc_fn_fc36583a_000050_5e919db9+0x20c>
  40e73f:	mov    rcx,QWORD PTR [rax]
  40e742:	mov    QWORD PTR [r14],rcx
  40e745:	add    DWORD PTR [r14+0x28],0x1
  40e74a:	jmp    40e76b <__swc_fn_fc36583a_000050_5e919db9+0x22b>
  40e74c:	mov    rax,QWORD PTR [r14+0x18]
  40e750:	cmp    QWORD PTR [r14+0x20],rax
  40e754:	jae    40e769 <__swc_fn_fc36583a_000050_5e919db9+0x229>
  40e756:	mov    rax,QWORD PTR [r14+0x20]
  40e75a:	mov    ecx,DWORD PTR [r14+0x2c]
  40e75e:	add    QWORD PTR [r14+0x20],rcx
  40e762:	add    DWORD PTR [r14+0x28],0x1
  40e767:	jmp    40e76b <__swc_fn_fc36583a_000050_5e919db9+0x22b>
  40e769:	xor    eax,eax
  40e76b:	mov    r15,rax
  40e76e:	test   r15,r15
  40e771:	je     40e6c0 <__swc_fn_fc36583a_000050_5e919db9+0x180>
  40e777:	mov    rax,r15
  40e77a:	add    rsp,0x1f8
  40e781:	pop    r15
  40e783:	pop    r14
  40e785:	pop    r13
  40e787:	pop    r12
  40e789:	pop    rdi
  40e78a:	pop    rsi
  40e78b:	ret
  40e78c:	add    BYTE PTR [rax],al
	...

000000000040e790 <__swc_fn_fc36583a_000053_9aa81fa7>:
  40e790:	push   rsi
  40e791:	push   rdi
  40e792:	push   r12
  40e794:	mov    rsi,rdx
  40e797:	mov    rax,rdx
  40e79a:	shr    rax,0xc
  40e79e:	movabs rdx,0x9e3779b97f4a7c15
  40e7a8:	imul   rax,rdx
  40e7ac:	shr    rax,0x20
  40e7b0:	lea    rax,[rax*8+0x0]
  40e7b8:	shr    rax,0x20
  40e7bc:	lea    rax,[rax*8+0x0]
  40e7c4:	lea    rax,[rcx+rax*8+0x40]
  40e7c9:	xor    edx,edx
  40e7cb:	test   dl,dl
  40e7cd:	lea    rdi,[rcx+0x8]
  40e7d1:	cmove  rdi,rax
  40e7d5:	xor    edx,edx
  40e7d7:	test   dl,dl
  40e7d9:	lea    r12,[rcx+0x30]
  40e7dd:	lea    rax,[rax+0x8]
  40e7e1:	cmove  r12,rax
  40e7e5:	mov    rcx,rdi
  40e7e8:	call   4098a0 <__swc_fn_fc36583a_000135_db32cc57>
  40e7ed:	mov    QWORD PTR [rsi+0x30],0x0
  40e7f5:	mov    rax,QWORD PTR [r12]
  40e7f9:	mov    QWORD PTR [rsi+0x38],rax
  40e7fd:	test   rax,rax
  40e800:	je     40e80a <__swc_fn_fc36583a_000053_9aa81fa7+0x7a>
  40e802:	mov    rax,QWORD PTR [rsi+0x38]
  40e806:	mov    QWORD PTR [rax+0x30],rsi
  40e80a:	mov    QWORD PTR [r12],rsi
  40e80e:	mov    rcx,rdi
  40e811:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  40e816:	pop    r12
  40e818:	pop    rdi
  40e819:	pop    rsi
  40e81a:	ret
  40e81b:	add    BYTE PTR [rax],al
  40e81d:	add    BYTE PTR [rax],al
	...

000000000040e820 <__swc_fn_fc36583a_000056_87dc216f>:
  40e820:	lea    rax,[rdx+rdx*4]
  40e824:	lea    rax,[rcx+rax*8+0x268]
  40e82c:	mov    rdx,QWORD PTR [rax+0x10]
  40e830:	sub    QWORD PTR [rcx+0x2a68],rdx
  40e837:	sub    QWORD PTR [rcx+0x2a70],0x1
  40e83f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40e846:	lea    rdx,[rdx+rdx*4]
  40e84a:	lea    rdx,[rcx+rdx*8+0x268]
  40e852:	vmovups xmm0,XMMWORD PTR [rdx]
  40e856:	vmovups XMMWORD PTR [rax],xmm0
  40e85a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40e85f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e864:	mov    rcx,QWORD PTR [rdx+0x20]
  40e868:	mov    QWORD PTR [rax+0x20],rcx
  40e86c:	ret
  40e86d:	add    BYTE PTR [rax],al
	...

000000000040e870 <__swc_fn_fc36583a_000059_ee6a254c>:
  40e870:	push   rsi
  40e871:	push   rdi
  40e872:	push   r12
  40e874:	push   r13
  40e876:	sub    rsp,0x8
  40e87a:	mov    rsi,r8
  40e87d:	mov    rdi,rcx
  40e880:	mov    r12,rdx
  40e883:	xor    r13d,r13d
  40e886:	cs nop WORD PTR [rax+rax*1+0x0]
  40e890:	mov    eax,DWORD PTR [r12+0x730]
  40e898:	cmp    r13d,eax
  40e89b:	jae    40e901 <__swc_fn_fc36583a_000059_ee6a254c+0x91>
  40e89d:	lea    rax,[r13+r13*4+0x0]
  40e8a2:	lea    rax,[r12+rax*8+0x738]
  40e8aa:	mov    rdx,QWORD PTR [rax]
  40e8ad:	mov    r8,QWORD PTR [rax+0x8]
  40e8b1:	mov    r9,QWORD PTR [rax+0x10]
  40e8b5:	cmp    QWORD PTR [rax+0x20],rsi
  40e8b9:	jb     40e8c0 <__swc_fn_fc36583a_000059_ee6a254c+0x50>
  40e8bb:	inc    r13d
  40e8be:	jmp    40e890 <__swc_fn_fc36583a_000059_ee6a254c+0x20>
  40e8c0:	sub    DWORD PTR [r12+0x730],0x1
  40e8c9:	mov    ecx,DWORD PTR [r12+0x730]
  40e8d1:	lea    rcx,[rcx+rcx*4]
  40e8d5:	lea    rcx,[r12+rcx*8+0x738]
  40e8dd:	vmovups xmm0,XMMWORD PTR [rcx]
  40e8e1:	vmovups XMMWORD PTR [rax],xmm0
  40e8e5:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40e8ea:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e8ef:	mov    rcx,QWORD PTR [rcx+0x20]
  40e8f3:	mov    QWORD PTR [rax+0x20],rcx
  40e8f7:	mov    rcx,rdi
  40e8fa:	call   407750 <__swc_fn_fc36583a_000039_9ae4348f>
  40e8ff:	jmp    40e890 <__swc_fn_fc36583a_000059_ee6a254c+0x20>
  40e901:	add    rsp,0x8
  40e905:	pop    r13
  40e907:	pop    r12
  40e909:	pop    rdi
  40e90a:	pop    rsi
  40e90b:	ret
  40e90c:	add    BYTE PTR [rax],al
	...

000000000040e910 <__swc_fn_fc36583a_000062_0a65f1d5>:
  40e910:	push   rsi
  40e911:	push   rdi
  40e912:	push   r12
  40e914:	push   r13
  40e916:	push   r14
  40e918:	mov    rsi,rcx
  40e91b:	mov    rdi,rdx
  40e91e:	mov    r12,QWORD PTR [rdi]
  40e921:	mov    r13,QWORD PTR [rdi+0x18]
  40e925:	mov    rax,r12
  40e928:	add    rax,QWORD PTR [rdi+0x8]
  40e92c:	sub    rax,r13
  40e92f:	cmp    r8,rax
  40e932:	jbe    40e93d <__swc_fn_fc36583a_000062_0a65f1d5+0x2d>
  40e934:	pop    r14
  40e936:	pop    r13
  40e938:	pop    r12
  40e93a:	pop    rdi
  40e93b:	pop    rsi
  40e93c:	ret
  40e93d:	lea    rax,[r13+r8*1+0x0]
  40e942:	sub    rax,r12
  40e945:	mov    ecx,0x1000
  40e94a:	test   ecx,ecx
  40e94c:	mov    edx,0x8
  40e951:	cmove  ecx,edx
  40e954:	dec    rcx
  40e957:	mov    rdx,0xffffffffffffffff
  40e95e:	sub    rdx,rcx
  40e961:	cmp    rax,rdx
  40e964:	jbe    40e96b <__swc_fn_fc36583a_000062_0a65f1d5+0x5b>
  40e966:	xor    r14d,r14d
  40e969:	jmp    40e976 <__swc_fn_fc36583a_000062_0a65f1d5+0x66>
  40e96b:	add    rax,rcx
  40e96e:	andn   rax,rcx,rax
  40e973:	mov    r14,rax
  40e976:	mov    rax,QWORD PTR [rdi+0x10]
  40e97a:	cmp    r14,rax
  40e97d:	ja     40e988 <__swc_fn_fc36583a_000062_0a65f1d5+0x78>
  40e97f:	pop    r14
  40e981:	pop    r13
  40e983:	pop    r12
  40e985:	pop    rdi
  40e986:	pop    rsi
  40e987:	ret
  40e988:	mov    rax,r12
  40e98b:	add    rax,QWORD PTR [rdi+0x10]
  40e98f:	mov    rdx,r14
  40e992:	sub    rdx,QWORD PTR [rdi+0x10]
  40e996:	mov    rcx,rax
  40e999:	call   4072a0 <__swc_fn_fc36583a_000003_81215399>
  40e99e:	test   al,al
  40e9a0:	jne    40e9ab <__swc_fn_fc36583a_000062_0a65f1d5+0x9b>
  40e9a2:	pop    r14
  40e9a4:	pop    r13
  40e9a6:	pop    r12
  40e9a8:	pop    rdi
  40e9a9:	pop    rsi
  40e9aa:	ret
  40e9ab:	add    r12,r14
  40e9ae:	sub    r12,r13
  40e9b1:	mov    rcx,r12
  40e9b4:	sub    rcx,QWORD PTR [rdi+0x28]
  40e9b8:	mov    rdx,QWORD PTR [rsi+0x250]
  40e9bf:	nop
  40e9c0:	lea    r8,[rdx+rcx*1]
  40e9c4:	mov    rax,rdx
  40e9c7:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40e9d0:	cmp    rax,rdx
  40e9d3:	je     40e9da <__swc_fn_fc36583a_000062_0a65f1d5+0xca>
  40e9d5:	mov    rdx,rax
  40e9d8:	jmp    40e9c0 <__swc_fn_fc36583a_000062_0a65f1d5+0xb0>
  40e9da:	mov    QWORD PTR [rdi+0x10],r14
  40e9de:	mov    QWORD PTR [rdi+0x28],r12
  40e9e2:	pop    r14
  40e9e4:	pop    r13
  40e9e6:	pop    r12
  40e9e8:	pop    rdi
  40e9e9:	pop    rsi
  40e9ea:	ret
  40e9eb:	add    BYTE PTR [rax],al
  40e9ed:	add    BYTE PTR [rax],al
	...

000000000040e9f0 <__swc_fn_fc36583a_000065_0b20477c>:
  40e9f0:	push   rbx
  40e9f1:	push   rsi
  40e9f2:	push   rdi
  40e9f3:	push   r12
  40e9f5:	push   r13
  40e9f7:	sub    rsp,0xe0
  40e9fe:	mov    rbx,rdx
  40ea01:	mov    rsi,rcx
  40ea04:	cmp    DWORD PTR [rbx+0x58],0x0
  40ea08:	je     40ea2c <__swc_fn_fc36583a_000065_0b20477c+0x3c>
  40ea0a:	mov    eax,DWORD PTR [rbx+0x58]
  40ea0d:	sub    eax,0x1
  40ea10:	test   DWORD PTR [rbx+0x58],eax
  40ea13:	je     40ea2c <__swc_fn_fc36583a_000065_0b20477c+0x3c>
  40ea15:	mov    QWORD PTR [rbx+0x40],0x0
  40ea1d:	add    rsp,0xe0
  40ea24:	pop    r13
  40ea26:	pop    r12
  40ea28:	pop    rdi
  40ea29:	pop    rsi
  40ea2a:	pop    rbx
  40ea2b:	ret
  40ea2c:	mov    rax,QWORD PTR [rbx+0x40]
  40ea30:	test   rax,rax
  40ea33:	jne    40ea4f <__swc_fn_fc36583a_000065_0b20477c+0x5f>
  40ea35:	mov    rcx,rsi
  40ea38:	mov    rdx,rbx
  40ea3b:	call   40c050 <__swc_fn_fc36583a_000064_20100e91>
  40ea40:	add    rsp,0xe0
  40ea47:	pop    r13
  40ea49:	pop    r12
  40ea4b:	pop    rdi
  40ea4c:	pop    rsi
  40ea4d:	pop    rbx
  40ea4e:	ret
  40ea4f:	cmp    QWORD PTR [rbx+0x48],0x0
  40ea54:	jne    40ea70 <__swc_fn_fc36583a_000065_0b20477c+0x80>
  40ea56:	mov    rcx,rsi
  40ea59:	mov    rdx,rbx
  40ea5c:	call   407f90 <__swc_fn_fc36583a_000066_918d3875>
  40ea61:	add    rsp,0xe0
  40ea68:	pop    r13
  40ea6a:	pop    r12
  40ea6c:	pop    rdi
  40ea6d:	pop    rsi
  40ea6e:	pop    rbx
  40ea6f:	ret
  40ea70:	mov    rdi,QWORD PTR [rbx+0x40]
  40ea74:	lea    rax,[rip+0x155f5]        # 424070 <__swc_bss_base_fc36583a+0x30>
  40ea7b:	mov    rcx,rdi
  40ea7e:	sub    rcx,QWORD PTR [rax+0x8]
  40ea82:	mov    rax,QWORD PTR [rip+0x155f7]        # 424080 <__swc_bss_base_fc36583a+0x40>
  40ea89:	cmp    rcx,rax
  40ea8c:	jae    40eab8 <__swc_fn_fc36583a_000065_0b20477c+0xc8>
  40ea8e:	mov    rax,rdi
  40ea91:	and    rax,0xffffffffffc00000
  40ea98:	mov    rcx,rdi
  40ea9b:	shr    rcx,0x10
  40ea9f:	and    ecx,0x3f
  40eaa2:	mov    edx,DWORD PTR [rax+0x28]
  40eaa5:	shrx   ecx,ecx,edx
  40eaaa:	shl    rcx,0x4
  40eaae:	lea    r12,[rax+rcx*8+0x80]
  40eab6:	jmp    40eac3 <__swc_fn_fc36583a_000065_0b20477c+0xd3>
  40eab8:	mov    rcx,rdi
  40eabb:	call   40b0d0 <__swc_fn_fc36583a_000022_53fc00d2>
  40eac0:	mov    r12,rax
  40eac3:	test   r12,r12
  40eac6:	je     40ead5 <__swc_fn_fc36583a_000065_0b20477c+0xe5>
  40eac8:	mov    eax,DWORD PTR [r12+0x2c]
  40eacd:	mov    r9d,eax
  40ead0:	mov    r13,rax
  40ead3:	jmp    40eb54 <__swc_fn_fc36583a_000065_0b20477c+0x164>
  40ead5:	mov    rcx,rsi
  40ead8:	mov    rdx,rdi
  40eadb:	call   40b6e0 <__swc_fn_fc36583a_000052_92b016ae>
  40eae0:	mov    rcx,QWORD PTR [rax+0x28]
  40eae4:	mov    r9,rcx
  40eae7:	mov    rdx,QWORD PTR [rax+0x20]
  40eaeb:	mov    r13,rdx
  40eaee:	cmp    QWORD PTR [rbx+0x48],rcx
  40eaf2:	jbe    40eb2b <__swc_fn_fc36583a_000065_0b20477c+0x13b>
  40eaf4:	mov    ecx,DWORD PTR [rax+0x48]
  40eaf7:	cmp    DWORD PTR [rbx+0x58],ecx
  40eafa:	ja     40eb2b <__swc_fn_fc36583a_000065_0b20477c+0x13b>
  40eafc:	mov    rcx,rsi
  40eaff:	mov    rdx,rax
  40eb02:	mov    r8,QWORD PTR [rbx+0x48]
  40eb06:	mov    QWORD PTR [rsp+0xc8],r9
  40eb0e:	mov    QWORD PTR [rsp+0xd0],rax
  40eb16:	call   40e910 <__swc_fn_fc36583a_000062_0a65f1d5>
  40eb1b:	mov    r9,QWORD PTR [rsp+0xc8]
  40eb23:	mov    rax,QWORD PTR [rsp+0xd0]
  40eb2b:	mov    rcx,QWORD PTR [rax+0x28]
  40eb2f:	cmp    QWORD PTR [rbx+0x48],rcx
  40eb33:	ja     40eb54 <__swc_fn_fc36583a_000065_0b20477c+0x164>
  40eb35:	mov    ecx,DWORD PTR [rax+0x48]
  40eb38:	cmp    DWORD PTR [rbx+0x58],ecx
  40eb3b:	ja     40eb54 <__swc_fn_fc36583a_000065_0b20477c+0x164>
  40eb3d:	mov    rcx,QWORD PTR [rbx+0x48]
  40eb41:	mov    QWORD PTR [rax+0x20],rcx
  40eb45:	add    rsp,0xe0
  40eb4c:	pop    r13
  40eb4e:	pop    r12
  40eb50:	pop    rdi
  40eb51:	pop    rsi
  40eb52:	pop    rbx
  40eb53:	ret
  40eb54:	test   r12,r12
  40eb57:	je     40eb89 <__swc_fn_fc36583a_000065_0b20477c+0x199>
  40eb59:	cmp    QWORD PTR [rbx+0x48],r9
  40eb5d:	ja     40eb89 <__swc_fn_fc36583a_000065_0b20477c+0x199>
  40eb5f:	cmp    DWORD PTR [rbx+0x58],0x40
  40eb63:	ja     40eb89 <__swc_fn_fc36583a_000065_0b20477c+0x199>
  40eb65:	cmp    DWORD PTR [rbx+0x58],0x0
  40eb69:	je     40eb76 <__swc_fn_fc36583a_000065_0b20477c+0x186>
  40eb6b:	mov    ecx,DWORD PTR [rbx+0x58]
  40eb6e:	dec    rcx
  40eb71:	test   rdi,rcx
  40eb74:	jne    40eb89 <__swc_fn_fc36583a_000065_0b20477c+0x199>
  40eb76:	mov    QWORD PTR [rbx+0x40],rdi
  40eb7a:	add    rsp,0xe0
  40eb81:	pop    r13
  40eb83:	pop    r12
  40eb85:	pop    rdi
  40eb86:	pop    rsi
  40eb87:	pop    rbx
  40eb88:	ret
  40eb89:	vmovups xmm0,XMMWORD PTR [rbx]
  40eb8d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40eb93:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40eb98:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40eb9e:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40eba3:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40eba9:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40ebae:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40ebb4:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40ebb9:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40ebbf:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40ebc4:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40ebca:	mov    QWORD PTR [rsp+0x48],0x0
  40ebd3:	mov    rcx,rsi
  40ebd6:	lea    rdx,[rsp+0x8]
  40ebdb:	call   40c050 <__swc_fn_fc36583a_000064_20100e91>
  40ebe0:	mov    rax,QWORD PTR [rsp+0x48]
  40ebe5:	test   rax,rax
  40ebe8:	jne    40ec01 <__swc_fn_fc36583a_000065_0b20477c+0x211>
  40ebea:	mov    QWORD PTR [rbx+0x40],0x0
  40ebf2:	add    rsp,0xe0
  40ebf9:	pop    r13
  40ebfb:	pop    r12
  40ebfd:	pop    rdi
  40ebfe:	pop    rsi
  40ebff:	pop    rbx
  40ec00:	ret
  40ec01:	mov    rax,QWORD PTR [rbx+0x48]
  40ec05:	cmp    r13,rax
  40ec08:	cmovbe rax,r13
  40ec0c:	mov    rcx,QWORD PTR [rsp+0x48]
  40ec11:	mov    rdx,rdi
  40ec14:	mov    r8,rax
  40ec17:	call   4090e0 <__swc_fn_fc36583a_000105_83487ba1>
  40ec1c:	vmovups xmm0,XMMWORD PTR [rbx]
  40ec20:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40ec26:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40ec2b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40ec31:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40ec36:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40ec3f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40ec44:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40ec4d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40ec52:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40ec5b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40ec60:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40ec69:	mov    QWORD PTR [rsp+0xa8],rdi
  40ec71:	mov    rcx,rsi
  40ec74:	lea    rdx,[rsp+0x68]
  40ec79:	call   407f90 <__swc_fn_fc36583a_000066_918d3875>
  40ec7e:	mov    rax,QWORD PTR [rsp+0x48]
  40ec83:	mov    QWORD PTR [rbx+0x40],rax
  40ec87:	add    rsp,0xe0
  40ec8e:	pop    r13
  40ec90:	pop    r12
  40ec92:	pop    rdi
  40ec93:	pop    rsi
  40ec94:	pop    rbx
  40ec95:	ret
	...

000000000040eca0 <__swc_fn_fc36583a_000068_f501e74b>:
  40eca0:	push   r12
  40eca2:	push   rdi
  40eca3:	push   rsi
  40eca4:	push   r13
  40eca6:	push   r14
  40eca8:	sub    rsp,0x190
  40ecaf:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40ecb8:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40ecc1:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40ecca:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40ecd3:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40ecdc:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40ece5:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40ecee:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40ecf7:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40ed00:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40ed09:	mov    r12,rcx
  40ed0c:	lea    rax,[rip+0x132ed]        # 422000 <__swc_data_base_fc36583a>
  40ed13:	mov    rax,QWORD PTR [rax]
  40ed16:	cmp    rax,0xffffffffffffffff
  40ed1a:	je     40ed29 <__swc_fn_fc36583a_000068_f501e74b+0x89>
  40ed1c:	mov    eax,eax
  40ed1e:	mov    edi,eax
  40ed20:	xor    eax,eax
  40ed22:	call   407000 <pthread_getspecific@plt>
  40ed27:	jmp    40ed2b <__swc_fn_fc36583a_000068_f501e74b+0x8b>
  40ed29:	xor    eax,eax
  40ed2b:	test   rax,rax
  40ed2e:	jne    40ed3d <__swc_fn_fc36583a_000068_f501e74b+0x9d>
  40ed30:	call   40b1a0 <__swc_fn_fc36583a_000031_3c3e930e>
  40ed35:	mov    rcx,rax
  40ed38:	call   410460 <__swc_fn_fc36583a_000128_8d8a7dd2>
  40ed3d:	test   rax,rax
  40ed40:	je     40ed66 <__swc_fn_fc36583a_000068_f501e74b+0xc6>
  40ed42:	cmp    QWORD PTR [rax],r12
  40ed45:	jne    40ed66 <__swc_fn_fc36583a_000068_f501e74b+0xc6>
  40ed47:	xor    ecx,ecx
  40ed49:	mov    QWORD PTR [rsp+0xc8],rax
  40ed51:	call   407720 <__swc_fn_fc36583a_000033_d15eb4ea>
  40ed56:	mov    rdx,QWORD PTR [rsp+0xc8]
  40ed5e:	mov    rcx,r12
  40ed61:	call   407840 <__swc_fn_fc36583a_000042_0573444d>
  40ed66:	lea    rsi,[r12+0x10]
  40ed6b:	mov    rcx,rsi
  40ed6e:	call   4098a0 <__swc_fn_fc36583a_000135_db32cc57>
  40ed73:	mov    rdi,QWORD PTR [r12+0x20]
  40ed78:	test   rdi,rdi
  40ed7b:	je     40edbe <__swc_fn_fc36583a_000068_f501e74b+0x11e>
  40ed7d:	nop    DWORD PTR [rax]
  40ed80:	mov    rcx,r12
  40ed83:	mov    rdx,rdi
  40ed86:	call   40b360 <__swc_fn_fc36583a_000043_47ff6d9b>
  40ed8b:	mov    rcx,r12
  40ed8e:	mov    rdx,rdi
  40ed91:	mov    r8,0xffffffffffffffff
  40ed98:	call   40e870 <__swc_fn_fc36583a_000059_ee6a254c>
  40ed9d:	mov    rcx,r12
  40eda0:	mov    rdx,rdi
  40eda3:	mov    r8d,0x9b8
  40eda9:	mov    r9d,0x9b8
  40edaf:	call   407750 <__swc_fn_fc36583a_000039_9ae4348f>
  40edb4:	mov    rdi,QWORD PTR [r12+0x20]
  40edb9:	test   rdi,rdi
  40edbc:	jne    40ed80 <__swc_fn_fc36583a_000068_f501e74b+0xe0>
  40edbe:	xor    eax,eax
  40edc0:	xchg   QWORD PTR [r12+0x2a80],rax
  40edc8:	test   rax,rax
  40edcb:	je     40edf1 <__swc_fn_fc36583a_000068_f501e74b+0x151>
  40edcd:	cs nop WORD PTR [rax+rax*1+0x0]
  40edd7:	nop    WORD PTR [rax+rax*1+0x0]
  40ede0:	mov    rcx,rax
  40ede3:	mov    rax,QWORD PTR [rax+0x78]
  40ede7:	xor    edx,edx
  40ede9:	xchg   DWORD PTR [rcx+0x70],edx
  40edec:	test   rax,rax
  40edef:	jne    40ede0 <__swc_fn_fc36583a_000068_f501e74b+0x140>
  40edf1:	mov    rax,QWORD PTR [r12+0x18]
  40edf6:	mov    rdi,rax
  40edf9:	test   rdi,rdi
  40edfc:	je     40ee91 <__swc_fn_fc36583a_000068_f501e74b+0x1f1>
  40ee02:	cs nop WORD PTR [rax+rax*1+0x0]
  40ee0c:	nop    DWORD PTR [rax+0x0]
  40ee10:	mov    rax,QWORD PTR [rdi+0x10]
  40ee14:	mov    r8d,DWORD PTR [rdi+0x2c]
  40ee18:	xor    r9d,r9d
  40ee1b:	test   r8,r8
  40ee1e:	jbe    40ee7d <__swc_fn_fc36583a_000068_f501e74b+0x1dd>
  40ee20:	mov    ecx,r9d
  40ee23:	shl    rcx,0x4
  40ee27:	lea    rdx,[rdi+rcx*8+0x80]
  40ee2f:	cmp    BYTE PTR [rdx+0x3b],0x0
  40ee33:	je     40ee74 <__swc_fn_fc36583a_000068_f501e74b+0x1d4>
  40ee35:	mov    DWORD PTR [rdx+0x28],0x0
  40ee3c:	mov    rcx,rdi
  40ee3f:	mov    QWORD PTR [rsp+0xd0],rax
  40ee47:	mov    QWORD PTR [rsp+0xd8],r8
  40ee4f:	mov    QWORD PTR [rsp+0xe0],r9
  40ee57:	call   40dfa0 <__swc_fn_fc36583a_000014_be17798c>
  40ee5c:	mov    rax,QWORD PTR [rsp+0xd0]
  40ee64:	mov    r8,QWORD PTR [rsp+0xd8]
  40ee6c:	mov    r9,QWORD PTR [rsp+0xe0]
  40ee74:	add    r9,0x1
  40ee78:	cmp    r9,r8
  40ee7b:	jb     40ee20 <__swc_fn_fc36583a_000068_f501e74b+0x180>
  40ee7d:	mov    rcx,rdi
  40ee80:	mov    rdi,rax
  40ee83:	call   407630 <__swc_fn_fc36583a_000021_9cf87641>
  40ee88:	test   rdi,rdi
  40ee8b:	jne    40ee10 <__swc_fn_fc36583a_000068_f501e74b+0x170>
  40ee91:	mov    QWORD PTR [r12+0x18],0x0
  40ee9a:	mov    QWORD PTR [r12+0x28],0x0
  40eea3:	mov    rcx,rsi
  40eea6:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  40eeab:	mov    esi,0x8
  40eeb0:	xor    edi,edi
  40eeb2:	test   rsi,rsi
  40eeb5:	je     40ef12 <__swc_fn_fc36583a_000068_f501e74b+0x272>
  40eebb:	nop    DWORD PTR [rax+rax*1+0x0]
  40eec0:	lea    r13,[rdi*8+0x0]
  40eec8:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40eecd:	test   r14,r14
  40eed0:	je     40ef08 <__swc_fn_fc36583a_000068_f501e74b+0x268>
  40eed2:	cs nop WORD PTR [rax+rax*1+0x0]
  40eedc:	nop    DWORD PTR [rax+0x0]
  40eee0:	mov    rcx,r12
  40eee3:	mov    rdx,r14
  40eee6:	call   407df0 <__swc_fn_fc36583a_000054_e8e85c01>
  40eeeb:	mov    rcx,r12
  40eeee:	mov    rdx,QWORD PTR [r14]
  40eef1:	mov    r8,QWORD PTR [r14+0x8]
  40eef5:	mov    r9,QWORD PTR [r14+0x10]
  40eef9:	call   407750 <__swc_fn_fc36583a_000039_9ae4348f>
  40eefe:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40ef03:	test   r14,r14
  40ef06:	jne    40eee0 <__swc_fn_fc36583a_000068_f501e74b+0x240>
  40ef08:	add    rdi,0x1
  40ef0c:	sub    rsi,0x1
  40ef10:	jne    40eec0 <__swc_fn_fc36583a_000068_f501e74b+0x220>
  40ef12:	mov    rcx,r12
  40ef15:	call   407ec0 <__swc_fn_fc36583a_000060_6818d0d1>
  40ef1a:	lea    rcx,[r12+0x250]
  40ef22:	mov    rdx,QWORD PTR [rcx]
  40ef25:	mov    r8,QWORD PTR [r12+0x250]
  40ef2d:	nop    DWORD PTR [rax]
  40ef30:	mov    r9,r8
  40ef33:	sub    r9,rdx
  40ef36:	mov    rax,r8
  40ef39:	lock cmpxchg QWORD PTR [rcx],r9
  40ef3e:	cmp    rax,r8
  40ef41:	je     40ef48 <__swc_fn_fc36583a_000068_f501e74b+0x2a8>
  40ef43:	mov    r8,rax
  40ef46:	jmp    40ef30 <__swc_fn_fc36583a_000068_f501e74b+0x290>
  40ef48:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40ef51:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40ef5a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40ef63:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40ef6c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40ef75:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40ef7e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40ef87:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40ef90:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40ef99:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40efa2:	add    rsp,0x190
  40efa9:	pop    r14
  40efab:	pop    r13
  40efad:	pop    rsi
  40efae:	pop    rdi
  40efaf:	pop    r12
  40efb1:	ret
	...

000000000040efc0 <__swc_fn_fc36583a_000071_1e1e3bf8>:
  40efc0:	sub    rsp,0x8
  40efc4:	mov    QWORD PTR [rdx+0x40],0x0
  40efcc:	call   40c050 <__swc_fn_fc36583a_000064_20100e91>
  40efd1:	add    rsp,0x8
  40efd5:	ret
	...

000000000040efe0 <__swc_fn_fc36583a_000074_30b8696a>:
  40efe0:	sub    rsp,0x8
  40efe4:	call   407f90 <__swc_fn_fc36583a_000066_918d3875>
  40efe9:	add    rsp,0x8
  40efed:	ret
	...

000000000040eff0 <__swc_fn_fc36583a_000077_948ef603>:
  40eff0:	push   rbx
  40eff1:	push   rsi
  40eff2:	push   rdi
  40eff3:	push   r12
  40eff5:	push   r13
  40eff7:	push   r14
  40eff9:	push   r15
  40effb:	sub    rsp,0x20
  40efff:	mov    rbx,r11
  40f002:	mov    rsi,rcx
  40f005:	mov    rdi,rdx
  40f008:	mov    r12,r8
  40f00b:	mov    r13,r9
  40f00e:	mov    r14,r10
  40f011:	mov    rcx,QWORD PTR [rip+0x17d28]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40f018:	test   rcx,rcx
  40f01b:	jne    40f02d <__swc_fn_fc36583a_000077_948ef603+0x3d>
  40f01d:	call   40a1a0 <__swc_fn_fc36583a_000165_56054fe7>
  40f022:	lea    rcx,[rax+0x1]
  40f026:	mov    QWORD PTR [rip+0x17d13],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40f02d:	dec    rcx
  40f030:	call   411ee0 <__swc_fn_fc36583a_000167_39c041ad>
  40f035:	mov    r15,rax
  40f038:	lea    r11,[rip+0x15201]        # 424240 <__swc_bss_base_fc36583a+0x200>
  40f03f:	mov    rcx,r11
  40f042:	call   407740 <__swc_fn_fc36583a_000036_290a131c>
  40f047:	test   al,al
  40f049:	jne    40f05a <__swc_fn_fc36583a_000077_948ef603+0x6a>
  40f04b:	mov    rcx,r11
  40f04e:	call   40b200 <__swc_fn_fc36583a_000034_cf5ba7bd>
  40f053:	lea    r11,[rip+0x151e6]        # 424240 <__swc_bss_base_fc36583a+0x200>
  40f05a:	mov    rcx,r11
  40f05d:	mov    rdx,rsi
  40f060:	mov    r8,rdi
  40f063:	mov    r9,r12
  40f066:	mov    r10,r13
  40f069:	mov    rsi,r11
  40f06c:	mov    r11,r14
  40f06f:	call   40e310 <__swc_fn_fc36583a_000035_ab2e8c35>
  40f074:	test   bl,bl
  40f076:	je     40f09d <__swc_fn_fc36583a_000077_948ef603+0xad>
  40f078:	mov    QWORD PTR [rsp+0x8],rsi
  40f07d:	lea    rax,[rip+0x40cc]        # 413150 <__swc_rdata_base_fc36583a+0x40>
  40f084:	mov    QWORD PTR [rsp+0x10],rax
  40f089:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f08f:	vmovups XMMWORD PTR [r15],xmm0
  40f094:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40f09d:	mov    rax,rsi
  40f0a0:	add    rsp,0x20
  40f0a4:	pop    r15
  40f0a6:	pop    r14
  40f0a8:	pop    r13
  40f0aa:	pop    r12
  40f0ac:	pop    rdi
  40f0ad:	pop    rsi
  40f0ae:	pop    rbx
  40f0af:	ret

000000000040f0b0 <__swc_fn_fc36583a_000080_207908fe>:
  40f0b0:	sub    rsp,0x8
  40f0b4:	mov    rax,rcx
  40f0b7:	test   rcx,rcx
  40f0ba:	jne    40f0c1 <__swc_fn_fc36583a_000080_207908fe+0x11>
  40f0bc:	add    rsp,0x8
  40f0c0:	ret
  40f0c1:	lea    rcx,[rax-0x10]
  40f0c5:	mov    rax,QWORD PTR [rax-0x10]
  40f0c9:	mov    rdx,rax
  40f0cc:	call   410110 <__swc_fn_fc36583a_000113_4e83a03a>
  40f0d1:	add    rsp,0x8
  40f0d5:	ret
	...

000000000040f0e0 <__swc_fn_fc36583a_000083_f2d93dad>:
  40f0e0:	sub    rsp,0x8
  40f0e4:	xor    r11d,r11d
  40f0e7:	call   408250 <__swc_fn_fc36583a_000084_5ed30bd6>
  40f0ec:	add    rsp,0x8
  40f0f0:	ret
	...

000000000040f100 <__swc_fn_fc36583a_000086_d9243de4>:
  40f100:	push   rsi
  40f101:	push   rdi
  40f102:	push   r12
  40f104:	push   r13
  40f106:	push   r14
  40f108:	push   r15
  40f10a:	sub    rsp,0x68
  40f10e:	mov    rsi,r9
  40f111:	mov    rdi,rcx
  40f114:	mov    r12,rdx
  40f117:	mov    r13,r8
  40f11a:	cmp    r8,r9
  40f11d:	jne    40f145 <__swc_fn_fc36583a_000086_d9243de4+0x45>
  40f11f:	mov    rcx,rdi
  40f122:	mov    rdx,r12
  40f125:	xor    r8d,r8d
  40f128:	call   4085a0 <__swc_fn_fc36583a_000090_14cf59b2>
  40f12d:	test   al,al
  40f12f:	je     40f145 <__swc_fn_fc36583a_000086_d9243de4+0x45>
  40f131:	mov    eax,0x1
  40f136:	add    rsp,0x68
  40f13a:	pop    r15
  40f13c:	pop    r14
  40f13e:	pop    r13
  40f140:	pop    r12
  40f142:	pop    rdi
  40f143:	pop    rsi
  40f144:	ret
  40f145:	cmp    BYTE PTR [r12+0x2c],0xe
  40f14b:	je     40f15e <__swc_fn_fc36583a_000086_d9243de4+0x5e>
  40f14d:	xor    eax,eax
  40f14f:	add    rsp,0x68
  40f153:	pop    r15
  40f155:	pop    r14
  40f157:	pop    r13
  40f159:	pop    r12
  40f15b:	pop    rdi
  40f15c:	pop    rsi
  40f15d:	ret
  40f15e:	mov    r14,QWORD PTR [r12+0x98]
  40f166:	mov    rax,QWORD PTR [r12+0xa0]
  40f16e:	mov    r12,rax
  40f171:	xor    r15d,r15d
  40f174:	test   r12,r12
  40f177:	je     40f1df <__swc_fn_fc36583a_000086_d9243de4+0xdf>
  40f179:	nop    DWORD PTR [rax+0x0]
  40f180:	mov    QWORD PTR [rsp+0x58],r12
  40f185:	lea    r12,[r15*8+0x0]
  40f18d:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40f192:	mov    rcx,rax
  40f195:	call   40c7e0 <__swc_fn_fc36583a_000082_ff7d1455>
  40f19a:	cmp    BYTE PTR [rax+0x2c],0xe
  40f19e:	jne    40f1d0 <__swc_fn_fc36583a_000086_d9243de4+0xd0>
  40f1a0:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40f1a5:	lea    r8,[r13+rcx*1+0x0]
  40f1aa:	mov    rcx,rdi
  40f1ad:	mov    rdx,rax
  40f1b0:	mov    r9,rsi
  40f1b3:	call   40f100 <__swc_fn_fc36583a_000086_d9243de4>
  40f1b8:	test   al,al
  40f1ba:	je     40f1d0 <__swc_fn_fc36583a_000086_d9243de4+0xd0>
  40f1bc:	mov    eax,0x1
  40f1c1:	add    rsp,0x68
  40f1c5:	pop    r15
  40f1c7:	pop    r14
  40f1c9:	pop    r13
  40f1cb:	pop    r12
  40f1cd:	pop    rdi
  40f1ce:	pop    rsi
  40f1cf:	ret
  40f1d0:	add    r15,0x1
  40f1d4:	mov    r12,QWORD PTR [rsp+0x58]
  40f1d9:	sub    r12,0x1
  40f1dd:	jne    40f180 <__swc_fn_fc36583a_000086_d9243de4+0x80>
  40f1df:	xor    eax,eax
  40f1e1:	add    rsp,0x68
  40f1e5:	pop    r15
  40f1e7:	pop    r14
  40f1e9:	pop    r13
  40f1eb:	pop    r12
  40f1ed:	pop    rdi
  40f1ee:	pop    rsi
  40f1ef:	ret

000000000040f1f0 <__swc_fn_fc36583a_000089_3c530920>:
  40f1f0:	push   rbp
  40f1f1:	push   rbx
  40f1f2:	push   rsi
  40f1f3:	push   rdi
  40f1f4:	push   r12
  40f1f6:	push   r13
  40f1f8:	push   r14
  40f1fa:	push   r15
  40f1fc:	sub    rsp,0x38
  40f200:	mov    rbp,rsp
  40f203:	mov    rbx,r11
  40f206:	mov    rsi,rdx
  40f209:	mov    rdi,r8
  40f20c:	mov    r12,r9
  40f20f:	mov    QWORD PTR [rsp+0x18],r9
  40f214:	mov    r13,r10
  40f217:	movzx  r14d,BYTE PTR [rbp+0x80]
  40f21f:	movzx  r15d,BYTE PTR [rbp+0x88]
  40f227:	test   r11,r11
  40f22a:	je     40f230 <__swc_fn_fc36583a_000089_3c530920+0x40>
  40f22c:	xor    eax,eax
  40f22e:	mov    BYTE PTR [rbx],al
  40f230:	test   r12,r12
  40f233:	je     40f23e <__swc_fn_fc36583a_000089_3c530920+0x4e>
  40f235:	mov    QWORD PTR [r12+0x8],0x0
  40f23e:	test   rcx,rcx
  40f241:	je     40f248 <__swc_fn_fc36583a_000089_3c530920+0x58>
  40f243:	test   rsi,rsi
  40f246:	jne    40f25b <__swc_fn_fc36583a_000089_3c530920+0x6b>
  40f248:	xor    eax,eax
  40f24a:	add    rsp,0x38
  40f24e:	pop    r15
  40f250:	pop    r14
  40f252:	pop    r13
  40f254:	pop    r12
  40f256:	pop    rdi
  40f257:	pop    rsi
  40f258:	pop    rbx
  40f259:	pop    rbp
  40f25a:	ret
  40f25b:	call   40c7e0 <__swc_fn_fc36583a_000082_ff7d1455>
  40f260:	mov    r12,rax
  40f263:	mov    al,r15b
  40f266:	test   r15b,r15b
  40f269:	jne    40f279 <__swc_fn_fc36583a_000089_3c530920+0x89>
  40f26b:	mov    eax,DWORD PTR [r12+0x28]
  40f270:	and    eax,0x10000
  40f276:	setne  al
  40f279:	lea    r15,[rsp+0x8]
  40f27e:	mov    QWORD PTR [rsp+0x20],r15
  40f283:	rex mov BYTE PTR [rsp+0x8],al
  40f288:	test   DWORD PTR [rsi+0x28],0x400000
  40f28f:	je     40f2c7 <__swc_fn_fc36583a_000089_3c530920+0xd7>
  40f291:	test   rsi,rsi
  40f294:	je     40f2b4 <__swc_fn_fc36583a_000089_3c530920+0xc4>
  40f296:	mov    rax,QWORD PTR [rsi+0x38]
  40f29a:	cmp    QWORD PTR [rax+0x10],rsi
  40f29e:	jne    40f2b4 <__swc_fn_fc36583a_000089_3c530920+0xc4>
  40f2a0:	rex mov al,BYTE PTR [rsp+0x8]
  40f2a5:	test   al,al
  40f2a7:	sete   al
  40f2aa:	test   r14b,r14b
  40f2ad:	sete   cl
  40f2b0:	test   al,cl
  40f2b2:	je     40f2c7 <__swc_fn_fc36583a_000089_3c530920+0xd7>
  40f2b4:	xor    eax,eax
  40f2b6:	add    rsp,0x38
  40f2ba:	pop    r15
  40f2bc:	pop    r14
  40f2be:	pop    r13
  40f2c0:	pop    r12
  40f2c2:	pop    rdi
  40f2c3:	pop    rsi
  40f2c4:	pop    rbx
  40f2c5:	pop    rbp
  40f2c6:	ret
  40f2c7:	mov    r15,r12
  40f2ca:	test   r14b,r14b
  40f2cd:	jne    40f2e4 <__swc_fn_fc36583a_000089_3c530920+0xf4>
  40f2cf:	cmp    BYTE PTR [r12+0x2c],0x6
  40f2d5:	jne    40f2e4 <__swc_fn_fc36583a_000089_3c530920+0xf4>
  40f2d7:	mov    rcx,QWORD PTR [r12+0x40]
  40f2dc:	call   40c7e0 <__swc_fn_fc36583a_000082_ff7d1455>
  40f2e1:	mov    r15,rax
  40f2e4:	test   r14b,r14b
  40f2e7:	je     40f2ed <__swc_fn_fc36583a_000089_3c530920+0xfd>
  40f2e9:	mov    r15,QWORD PTR [r15+0x30]
  40f2ed:	mov    rcx,rsi
  40f2f0:	call   40c7e0 <__swc_fn_fc36583a_000082_ff7d1455>
  40f2f5:	mov    rsi,rax
  40f2f8:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f2fd:	je     40f334 <__swc_fn_fc36583a_000089_3c530920+0x144>
  40f2ff:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f304:	je     40f334 <__swc_fn_fc36583a_000089_3c530920+0x144>
  40f306:	mov    eax,DWORD PTR [rsi+0x28]
  40f309:	and    eax,0x10000
  40f30f:	je     40f334 <__swc_fn_fc36583a_000089_3c530920+0x144>
  40f311:	rex mov al,BYTE PTR [rsp+0x8]
  40f316:	test   al,al
  40f318:	jne    40f32d <__swc_fn_fc36583a_000089_3c530920+0x13d>
  40f31a:	xor    eax,eax
  40f31c:	add    rsp,0x38
  40f320:	pop    r15
  40f322:	pop    r14
  40f324:	pop    r13
  40f326:	pop    r12
  40f328:	pop    rdi
  40f329:	pop    rsi
  40f32a:	pop    rbx
  40f32b:	pop    rbp
  40f32c:	ret
  40f32d:	mov    rax,QWORD PTR [rsi+0x30]
  40f331:	mov    rsi,rax
  40f334:	mov    r14b,r13b
  40f337:	test   rbx,rbx
  40f33a:	je     40f370 <__swc_fn_fc36583a_000089_3c530920+0x180>
  40f33c:	cmp    BYTE PTR [r12+0x2c],0x6
  40f342:	jne    40f370 <__swc_fn_fc36583a_000089_3c530920+0x180>
  40f344:	lea    rdx,[rip+0x3e35]        # 413180 <__swc_rdata_base_fc36583a+0x70>
  40f34b:	mov    rcx,rsi
  40f34e:	xor    r8d,r8d
  40f351:	call   4085a0 <__swc_fn_fc36583a_000090_14cf59b2>
  40f356:	test   al,al
  40f358:	je     40f370 <__swc_fn_fc36583a_000089_3c530920+0x180>
  40f35a:	mov    BYTE PTR [rbx],0x1
  40f35d:	xor    eax,eax
  40f35f:	add    rsp,0x38
  40f363:	pop    r15
  40f365:	pop    r14
  40f367:	pop    r13
  40f369:	pop    r12
  40f36b:	pop    rdi
  40f36c:	pop    rsi
  40f36d:	pop    rbx
  40f36e:	pop    rbp
  40f36f:	ret
  40f370:	test   rdi,rdi
  40f373:	jne    40f38d <__swc_fn_fc36583a_000089_3c530920+0x19d>
  40f375:	test   r13b,r13b
  40f378:	jne    40f38d <__swc_fn_fc36583a_000089_3c530920+0x19d>
  40f37a:	xor    eax,eax
  40f37c:	add    rsp,0x38
  40f380:	pop    r15
  40f382:	pop    r14
  40f384:	pop    r13
  40f386:	pop    r12
  40f388:	pop    rdi
  40f389:	pop    rsi
  40f38a:	pop    rbx
  40f38b:	pop    rbp
  40f38c:	ret
  40f38d:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f392:	jne    40f448 <__swc_fn_fc36583a_000089_3c530920+0x258>
  40f398:	mov    rcx,r15
  40f39b:	mov    rdx,rsi
  40f39e:	xor    r8d,r8d
  40f3a1:	call   4085a0 <__swc_fn_fc36583a_000090_14cf59b2>
  40f3a6:	test   al,al
  40f3a8:	jne    40f448 <__swc_fn_fc36583a_000089_3c530920+0x258>
  40f3ae:	test   DWORD PTR [rsi+0x28],0x10000
  40f3b5:	je     40f3d3 <__swc_fn_fc36583a_000089_3c530920+0x1e3>
  40f3b7:	rex mov al,BYTE PTR [rsp+0x8]
  40f3bc:	test   al,al
  40f3be:	jne    40f3d3 <__swc_fn_fc36583a_000089_3c530920+0x1e3>
  40f3c0:	xor    eax,eax
  40f3c2:	add    rsp,0x38
  40f3c6:	pop    r15
  40f3c8:	pop    r14
  40f3ca:	pop    r13
  40f3cc:	pop    r12
  40f3ce:	pop    rdi
  40f3cf:	pop    rsi
  40f3d0:	pop    rbx
  40f3d1:	pop    rbp
  40f3d2:	ret
  40f3d3:	test   rdi,rdi
  40f3d6:	jne    40f3eb <__swc_fn_fc36583a_000089_3c530920+0x1fb>
  40f3d8:	xor    eax,eax
  40f3da:	add    rsp,0x38
  40f3de:	pop    r15
  40f3e0:	pop    r14
  40f3e2:	pop    r13
  40f3e4:	pop    r12
  40f3e6:	pop    rdi
  40f3e7:	pop    rsi
  40f3e8:	pop    rbx
  40f3e9:	pop    rbp
  40f3ea:	ret
  40f3eb:	mov    rcx,QWORD PTR [rsi+0x40]
  40f3ef:	call   40c7e0 <__swc_fn_fc36583a_000082_ff7d1455>
  40f3f4:	mov    rsi,rax
  40f3f7:	mov    rax,QWORD PTR [rdi]
  40f3fa:	mov    rdi,rax
  40f3fd:	test   rax,rax
  40f400:	jne    40f443 <__swc_fn_fc36583a_000089_3c530920+0x253>
  40f402:	test   rbx,rbx
  40f405:	je     40f443 <__swc_fn_fc36583a_000089_3c530920+0x253>
  40f407:	mov    rcx,r15
  40f40a:	mov    rdx,rsi
  40f40d:	xor    r8d,r8d
  40f410:	call   4085a0 <__swc_fn_fc36583a_000090_14cf59b2>
  40f415:	mov    rcx,rax
  40f418:	test   al,al
  40f41a:	jne    40f43c <__swc_fn_fc36583a_000089_3c530920+0x24c>
  40f41c:	mov    rcx,r15
  40f41f:	mov    rdx,rsi
  40f422:	call   40c820 <__swc_fn_fc36583a_000085_e24ecd12>
  40f427:	mov    rcx,rax
  40f42a:	test   al,al
  40f42c:	jne    40f43c <__swc_fn_fc36583a_000089_3c530920+0x24c>
  40f42e:	mov    rcx,rsi
  40f431:	mov    rdx,r15
  40f434:	call   40c820 <__swc_fn_fc36583a_000085_e24ecd12>
  40f439:	mov    rcx,rax
  40f43c:	test   cl,cl
  40f43e:	setne  al
  40f441:	mov    BYTE PTR [rbx],al
  40f443:	xor    eax,eax
  40f445:	mov    r14b,al
  40f448:	test   rdi,rdi
  40f44b:	jne    40f465 <__swc_fn_fc36583a_000089_3c530920+0x275>
  40f44d:	test   r14b,r14b
  40f450:	jne    40f465 <__swc_fn_fc36583a_000089_3c530920+0x275>
  40f452:	xor    eax,eax
  40f454:	add    rsp,0x38
  40f458:	pop    r15
  40f45a:	pop    r14
  40f45c:	pop    r13
  40f45e:	pop    r12
  40f460:	pop    rdi
  40f461:	pop    rsi
  40f462:	pop    rbx
  40f463:	pop    rbp
  40f464:	ret
  40f465:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f46a:	je     40f476 <__swc_fn_fc36583a_000089_3c530920+0x286>
  40f46c:	mov    r12,QWORD PTR [rsp+0x18]
  40f471:	jmp    40f4fe <__swc_fn_fc36583a_000089_3c530920+0x30e>
  40f476:	mov    r12,QWORD PTR [rsp+0x18]
  40f47b:	test   r12,r12
  40f47e:	jne    40f492 <__swc_fn_fc36583a_000089_3c530920+0x2a2>
  40f480:	mov    rcx,r15
  40f483:	mov    rdx,rsi
  40f486:	xor    r8d,r8d
  40f489:	call   4085a0 <__swc_fn_fc36583a_000090_14cf59b2>
  40f48e:	test   al,al
  40f490:	jne    40f4fe <__swc_fn_fc36583a_000089_3c530920+0x30e>
  40f492:	test   DWORD PTR [rsi+0x28],0x10000
  40f499:	je     40f4b7 <__swc_fn_fc36583a_000089_3c530920+0x2c7>
  40f49b:	rex mov al,BYTE PTR [rsp+0x8]
  40f4a0:	test   al,al
  40f4a2:	jne    40f4b7 <__swc_fn_fc36583a_000089_3c530920+0x2c7>
  40f4a4:	xor    eax,eax
  40f4a6:	add    rsp,0x38
  40f4aa:	pop    r15
  40f4ac:	pop    r14
  40f4ae:	pop    r13
  40f4b0:	pop    r12
  40f4b2:	pop    rdi
  40f4b3:	pop    rsi
  40f4b4:	pop    rbx
  40f4b5:	pop    rbp
  40f4b6:	ret
  40f4b7:	test   rdi,rdi
  40f4ba:	jne    40f4cf <__swc_fn_fc36583a_000089_3c530920+0x2df>
  40f4bc:	xor    eax,eax
  40f4be:	add    rsp,0x38
  40f4c2:	pop    r15
  40f4c4:	pop    r14
  40f4c6:	pop    r13
  40f4c8:	pop    r12
  40f4ca:	pop    rdi
  40f4cb:	pop    rsi
  40f4cc:	pop    rbx
  40f4cd:	pop    rbp
  40f4ce:	ret
  40f4cf:	cmp    QWORD PTR [rdi+0x8],0x0
  40f4d4:	jne    40f4e9 <__swc_fn_fc36583a_000089_3c530920+0x2f9>
  40f4d6:	xor    eax,eax
  40f4d8:	add    rsp,0x38
  40f4dc:	pop    r15
  40f4de:	pop    r14
  40f4e0:	pop    r13
  40f4e2:	pop    r12
  40f4e4:	pop    rdi
  40f4e5:	pop    rsi
  40f4e6:	pop    rbx
  40f4e7:	pop    rbp
  40f4e8:	ret
  40f4e9:	mov    rax,QWORD PTR [rdi+0x8]
  40f4ed:	mov    rax,QWORD PTR [rax]
  40f4f0:	mov    rsi,rax
  40f4f3:	mov    rdi,QWORD PTR [rdi]
  40f4f6:	mov    eax,0x1
  40f4fb:	mov    r14b,al
  40f4fe:	test   rdi,rdi
  40f501:	mov    rbx,QWORD PTR [rsp+0x20]
  40f506:	jne    40f550 <__swc_fn_fc36583a_000089_3c530920+0x360>
  40f508:	test   r14b,r14b
  40f50b:	je     40f53d <__swc_fn_fc36583a_000089_3c530920+0x34d>
  40f50d:	test   r12,r12
  40f510:	je     40f53d <__swc_fn_fc36583a_000089_3c530920+0x34d>
  40f512:	mov    rcx,r15
  40f515:	mov    rdx,rsi
  40f518:	xor    r8d,r8d
  40f51b:	mov    r9,r12
  40f51e:	mov    rbx,QWORD PTR [rsp+0x20]
  40f523:	movzx  r10d,BYTE PTR [rbx]
  40f527:	call   40f0e0 <__swc_fn_fc36583a_000083_f2d93dad>
  40f52c:	add    rsp,0x38
  40f530:	pop    r15
  40f532:	pop    r14
  40f534:	pop    r13
  40f536:	pop    r12
  40f538:	pop    rdi
  40f539:	pop    rsi
  40f53a:	pop    rbx
  40f53b:	pop    rbp
  40f53c:	ret
  40f53d:	xor    eax,eax
  40f53f:	add    rsp,0x38
  40f543:	pop    r15
  40f545:	pop    r14
  40f547:	pop    r13
  40f549:	pop    r12
  40f54b:	pop    rdi
  40f54c:	pop    rsi
  40f54d:	pop    rbx
  40f54e:	pop    rbp
  40f54f:	ret
  40f550:	mov    r13,rsi
  40f553:	mov    QWORD PTR [rsp+0x28],rdi
  40f558:	cmp    BYTE PTR [r15+0x2c],0xe
  40f55d:	sete   al
  40f560:	mov    r14b,al
  40f563:	jne    40f577 <__swc_fn_fc36583a_000089_3c530920+0x387>
  40f565:	mov    rcx,rsi
  40f568:	mov    rdx,r15
  40f56b:	call   40c820 <__swc_fn_fc36583a_000085_e24ecd12>
  40f570:	mov    r14b,al
  40f573:	test   al,al
  40f575:	jne    40f5ac <__swc_fn_fc36583a_000089_3c530920+0x3bc>
  40f577:	cmp    BYTE PTR [r15+0x2c],0x12
  40f57c:	je     40f5ac <__swc_fn_fc36583a_000089_3c530920+0x3bc>
  40f57e:	mov    rcx,r15
  40f581:	mov    rdx,rsi
  40f584:	mov    r8,rdi
  40f587:	mov    r9,r12
  40f58a:	mov    rax,rbx
  40f58d:	movzx  r10d,BYTE PTR [rax]
  40f591:	call   40f0e0 <__swc_fn_fc36583a_000083_f2d93dad>
  40f596:	test   rax,rax
  40f599:	je     40f5ac <__swc_fn_fc36583a_000089_3c530920+0x3bc>
  40f59b:	add    rsp,0x38
  40f59f:	pop    r15
  40f5a1:	pop    r14
  40f5a3:	pop    r13
  40f5a5:	pop    r12
  40f5a7:	pop    rdi
  40f5a8:	pop    rsi
  40f5a9:	pop    rbx
  40f5aa:	pop    rbp
  40f5ab:	ret
  40f5ac:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40f5b1:	jne    40f5d0 <__swc_fn_fc36583a_000089_3c530920+0x3e0>
  40f5b3:	mov    rax,QWORD PTR [rsi+0xd8]
  40f5ba:	test   rax,rax
  40f5bd:	je     40f5d0 <__swc_fn_fc36583a_000089_3c530920+0x3e0>
  40f5bf:	add    rdi,QWORD PTR [rax+0x8]
  40f5c3:	mov    rax,QWORD PTR [rdi]
  40f5c6:	sub    rdi,QWORD PTR [rax+0x8]
  40f5ca:	mov    rax,QWORD PTR [rax]
  40f5cd:	mov    rsi,rax
  40f5d0:	test   r14b,r14b
  40f5d3:	je     40f5ff <__swc_fn_fc36583a_000089_3c530920+0x40f>
  40f5d5:	mov    rcx,r15
  40f5d8:	mov    rdx,rsi
  40f5db:	mov    r8,rdi
  40f5de:	mov    r9,r13
  40f5e1:	mov    r14,QWORD PTR [rsp+0x28]
  40f5e6:	mov    r10,r14
  40f5e9:	call   408480 <__swc_fn_fc36583a_000087_693f118e>
  40f5ee:	add    rsp,0x38
  40f5f2:	pop    r15
  40f5f4:	pop    r14
  40f5f6:	pop    r13
  40f5f8:	pop    r12
  40f5fa:	pop    rdi
  40f5fb:	pop    rsi
  40f5fc:	pop    rbx
  40f5fd:	pop    rbp
  40f5fe:	ret
  40f5ff:	mov    rcx,r15
  40f602:	mov    rdx,rsi
  40f605:	mov    r8,rdi
  40f608:	mov    r9,r12
  40f60b:	movzx  r10d,BYTE PTR [rbx]
  40f60f:	call   40f0e0 <__swc_fn_fc36583a_000083_f2d93dad>
  40f614:	add    rsp,0x38
  40f618:	pop    r15
  40f61a:	pop    r14
  40f61c:	pop    r13
  40f61e:	pop    r12
  40f620:	pop    rdi
  40f621:	pop    rsi
  40f622:	pop    rbx
  40f623:	pop    rbp
  40f624:	ret
	...

000000000040f630 <__swc_fn_fc36583a_000092_809deff5>:
  40f630:	push   rbx
  40f631:	push   rsi
  40f632:	sub    rsp,0x18
  40f636:	mov    rbx,rcx
  40f639:	mov    rcx,QWORD PTR [rip+0x17700]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40f640:	test   rcx,rcx
  40f643:	jne    40f655 <__swc_fn_fc36583a_000092_809deff5+0x25>
  40f645:	call   40a1a0 <__swc_fn_fc36583a_000165_56054fe7>
  40f64a:	lea    rcx,[rax+0x1]
  40f64e:	mov    QWORD PTR [rip+0x176eb],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  40f655:	dec    rcx
  40f658:	call   411ee0 <__swc_fn_fc36583a_000167_39c041ad>
  40f65d:	mov    rsi,rax
  40f660:	mov    rax,QWORD PTR [rsi+0x8]
  40f664:	test   rax,rax
  40f667:	jne    40f6b7 <__swc_fn_fc36583a_000092_809deff5+0x87>
  40f669:	call   40c910 <__swc_fn_fc36583a_000091_f21926ed>
  40f66e:	test   al,al
  40f670:	jne    40f6b7 <__swc_fn_fc36583a_000092_809deff5+0x87>
  40f672:	lea    rdx,[rip+0x14bc7]        # 424240 <__swc_bss_base_fc36583a+0x200>
  40f679:	mov    rcx,rdx
  40f67c:	call   407740 <__swc_fn_fc36583a_000036_290a131c>
  40f681:	test   al,al
  40f683:	jne    40f694 <__swc_fn_fc36583a_000092_809deff5+0x64>
  40f685:	mov    rcx,rdx
  40f688:	call   40b200 <__swc_fn_fc36583a_000034_cf5ba7bd>
  40f68d:	lea    rdx,[rip+0x14bac]        # 424240 <__swc_bss_base_fc36583a+0x200>
  40f694:	mov    QWORD PTR [rsp+0x8],rdx
  40f699:	lea    rax,[rip+0x3ab0]        # 413150 <__swc_rdata_base_fc36583a+0x40>
  40f6a0:	mov    QWORD PTR [rsp+0x10],rax
  40f6a5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f6ab:	vmovups XMMWORD PTR [rsi],xmm0
  40f6af:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40f6b7:	vmovups xmm0,XMMWORD PTR [rsi]
  40f6bb:	vmovups XMMWORD PTR [rbx],xmm0
  40f6bf:	mov    rax,rbx
  40f6c2:	add    rsp,0x18
  40f6c6:	pop    rsi
  40f6c7:	pop    rbx
  40f6c8:	ret
  40f6c9:	add    BYTE PTR [rax],al
  40f6cb:	add    BYTE PTR [rax],al
  40f6cd:	add    BYTE PTR [rax],al
	...

000000000040f6d0 <__swc_fn_fc36583a_000095_8cc4b392>:
  40f6d0:	sub    rsp,0x8
  40f6d4:	call   409340 <__swc_fn_fc36583a_000117_5aba1420>
  40f6d9:	add    rsp,0x8
  40f6dd:	ret
	...

000000000040f6e0 <__swc_fn_fc36583a_000098_f82a1ed3>:
  40f6e0:	push   rbx
  40f6e1:	push   rsi
  40f6e2:	sub    rsp,0x28
  40f6e6:	mov    rbx,rcx
  40f6e9:	xor    esi,esi
  40f6eb:	jmp    40f700 <__swc_fn_fc36583a_000098_f82a1ed3+0x20>
  40f6ed:	nop    DWORD PTR [rax]
  40f6f0:	mov    QWORD PTR [rbx+0x28],rsi
  40f6f4:	mov    rsi,rbx
  40f6f7:	mov    rbx,rax
  40f6fa:	nop    WORD PTR [rax+rax*1+0x0]
  40f700:	test   rbx,rbx
  40f703:	je     40f763 <__swc_fn_fc36583a_000098_f82a1ed3+0x83>
  40f705:	mov    rcx,rbx
  40f708:	mov    edx,0x1
  40f70d:	call   408200 <__swc_fn_fc36583a_000078_140918ec>
  40f712:	cmp    rax,0x1
  40f716:	jne    40f763 <__swc_fn_fc36583a_000098_f82a1ed3+0x83>
  40f718:	mov    r10,QWORD PTR [rbx+0x18]
  40f71c:	mov    rcx,r10
  40f71f:	mov    edx,0x1
  40f724:	call   408200 <__swc_fn_fc36583a_000078_140918ec>
  40f729:	cmp    rax,0x1
  40f72d:	jne    40f73c <__swc_fn_fc36583a_000098_f82a1ed3+0x5c>
  40f72f:	mov    rcx,r10
  40f732:	call   40cab0 <__swc_fn_fc36583a_000097_96d6739a>
  40f737:	test   rax,rax
  40f73a:	jne    40f6f0 <__swc_fn_fc36583a_000098_f82a1ed3+0x10>
  40f73c:	mov    rax,QWORD PTR [rbx+0x20]
  40f740:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40f745:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f74b:	lea    rcx,[rsp+0x8]
  40f750:	mov    rdx,rbx
  40f753:	mov    r8d,0x30
  40f759:	mov    rbx,rax
  40f75c:	call   408960 <__swc_fn_fc36583a_000096_a4baaa40>
  40f761:	jmp    40f700 <__swc_fn_fc36583a_000098_f82a1ed3+0x20>
  40f763:	test   rsi,rsi
  40f766:	jne    40f76f <__swc_fn_fc36583a_000098_f82a1ed3+0x8f>
  40f768:	add    rsp,0x28
  40f76c:	pop    rsi
  40f76d:	pop    rbx
  40f76e:	ret
  40f76f:	mov    rax,rsi
  40f772:	mov    rsi,QWORD PTR [rsi+0x28]
  40f776:	mov    rbx,QWORD PTR [rax+0x20]
  40f77a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40f77f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f785:	lea    rcx,[rsp+0x18]
  40f78a:	mov    rdx,rax
  40f78d:	mov    r8d,0x30
  40f793:	call   408960 <__swc_fn_fc36583a_000096_a4baaa40>
  40f798:	jmp    40f700 <__swc_fn_fc36583a_000098_f82a1ed3+0x20>
  40f79d:	add    BYTE PTR [rax],al
	...

000000000040f7a0 <__swc_fn_fc36583a_000101_afcb7774>:
  40f7a0:	push   rbx
  40f7a1:	push   rsi
  40f7a2:	push   rdi
  40f7a3:	push   r12
  40f7a5:	push   r13
  40f7a7:	sub    rsp,0x20
  40f7ab:	mov    rbx,rcx
  40f7ae:	lea    rsi,[rcx+0x6f8]
  40f7b5:	mov    edi,0x4
  40f7ba:	mov    r12,rsi
  40f7bd:	test   rdi,rdi
  40f7c0:	je     40f80a <__swc_fn_fc36583a_000101_afcb7774+0x6a>
  40f7c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f7cc:	nop    DWORD PTR [rax+0x0]
  40f7d0:	mov    rcx,QWORD PTR [r12+0x10]
  40f7d5:	mov    QWORD PTR [r12+0x10],0x0
  40f7de:	vxorps xmm0,xmm0,xmm0
  40f7e2:	vmovups XMMWORD PTR [r12],xmm0
  40f7e8:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40f7ef:	mov    DWORD PTR [r12+0x20],0x0
  40f7f8:	call   4089b0 <__swc_fn_fc36583a_000099_5232b57d>
  40f7fd:	add    r12,0x90
  40f804:	sub    rdi,0x1
  40f808:	jne    40f7d0 <__swc_fn_fc36583a_000101_afcb7774+0x30>
  40f80a:	mov    rax,QWORD PTR [rbx+0x938]
  40f811:	mov    rdi,rax
  40f814:	test   rdi,rdi
  40f817:	je     40f871 <__swc_fn_fc36583a_000101_afcb7774+0xd1>
  40f819:	nop    DWORD PTR [rax+0x0]
  40f820:	mov    r12d,0x10
  40f826:	lea    r13,[rdi+0x18]
  40f82a:	test   r12,r12
  40f82d:	je     40f866 <__swc_fn_fc36583a_000101_afcb7774+0xc6>
  40f82f:	nop
  40f830:	mov    rcx,QWORD PTR [r13+0x10]
  40f834:	mov    QWORD PTR [r13+0x10],0x0
  40f83c:	vxorps xmm0,xmm0,xmm0
  40f840:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40f846:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40f84c:	mov    DWORD PTR [r13+0x20],0x0
  40f854:	call   4089b0 <__swc_fn_fc36583a_000099_5232b57d>
  40f859:	add    r13,0x90
  40f860:	sub    r12,0x1
  40f864:	jne    40f830 <__swc_fn_fc36583a_000101_afcb7774+0x90>
  40f866:	mov    rax,QWORD PTR [rdi]
  40f869:	mov    rdi,rax
  40f86c:	test   rax,rax
  40f86f:	jne    40f820 <__swc_fn_fc36583a_000101_afcb7774+0x80>
  40f871:	vxorps xmm0,xmm0,xmm0
  40f875:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40f87d:	mov    DWORD PTR [rbx+0x9b0],0x0
  40f887:	mov    DWORD PTR [rbx+0x9a8],0x0
  40f891:	mov    edi,0x4
  40f896:	mov    r12,rsi
  40f899:	lea    rsi,[rsi+0x38]
  40f89d:	test   rdi,rdi
  40f8a0:	je     40f8cc <__swc_fn_fc36583a_000101_afcb7774+0x12c>
  40f8a2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f8ac:	nop    DWORD PTR [rax+0x0]
  40f8b0:	mov    rcx,rsi
  40f8b3:	call   40d930 <__swc_fn_fc36583a_000157_3495a3ca>
  40f8b8:	add    rsi,0x90
  40f8bf:	add    r12,0x90
  40f8c6:	sub    rdi,0x1
  40f8ca:	jne    40f8b0 <__swc_fn_fc36583a_000101_afcb7774+0x110>
  40f8cc:	mov    rax,QWORD PTR [rbx+0x938]
  40f8d3:	mov    rdi,rax
  40f8d6:	mov    QWORD PTR [rbx+0x938],0x0
  40f8e1:	test   rdi,rdi
  40f8e4:	je     40f955 <__swc_fn_fc36583a_000101_afcb7774+0x1b5>
  40f8ea:	nop    WORD PTR [rax+rax*1+0x0]
  40f8f0:	mov    esi,0x10
  40f8f5:	lea    r12,[rdi+0x18]
  40f8f9:	lea    r13,[rdi+0x50]
  40f8fd:	test   rsi,rsi
  40f900:	je     40f92c <__swc_fn_fc36583a_000101_afcb7774+0x18c>
  40f902:	cs nop WORD PTR [rax+rax*1+0x0]
  40f90c:	nop    DWORD PTR [rax+0x0]
  40f910:	mov    rcx,r13
  40f913:	call   40d930 <__swc_fn_fc36583a_000157_3495a3ca>
  40f918:	add    r13,0x90
  40f91f:	add    r12,0x90
  40f926:	sub    rsi,0x1
  40f92a:	jne    40f910 <__swc_fn_fc36583a_000101_afcb7774+0x170>
  40f92c:	mov    rax,QWORD PTR [rdi]
  40f92f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40f934:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f93a:	lea    rcx,[rsp+0x8]
  40f93f:	mov    rdx,rdi
  40f942:	mov    r8d,0x918
  40f948:	mov    rdi,rax
  40f94b:	call   408960 <__swc_fn_fc36583a_000096_a4baaa40>
  40f950:	test   rdi,rdi
  40f953:	jne    40f8f0 <__swc_fn_fc36583a_000101_afcb7774+0x150>
  40f955:	lea    rcx,[rbx+0x68]
  40f959:	call   40d930 <__swc_fn_fc36583a_000157_3495a3ca>
  40f95e:	add    rsp,0x20
  40f962:	pop    r13
  40f964:	pop    r12
  40f966:	pop    rdi
  40f967:	pop    rsi
  40f968:	pop    rbx
  40f969:	ret
  40f96a:	add    BYTE PTR [rax],al
  40f96c:	add    BYTE PTR [rax],al
	...

000000000040f970 <__swc_fn_fc36583a_000104_04d1a8be>:
  40f970:	xor    eax,eax
  40f972:	cs nop WORD PTR [rax+rax*1+0x0]
  40f97c:	nop    DWORD PTR [rax+0x0]
  40f980:	mov    r9,r8
  40f983:	sub    r9,rax
  40f986:	cmp    r9,0x40
  40f98a:	jb     40f9c8 <__swc_fn_fc36583a_000104_04d1a8be+0x58>
  40f98c:	lea    r9,[rcx+rax*1]
  40f990:	lea    r10,[rdx+rax*1]
  40f994:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40f99a:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40f9a0:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40f9a6:	vmovups xmm3,XMMWORD PTR [r10]
  40f9ab:	vmovups XMMWORD PTR [r9],xmm3
  40f9b0:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40f9b6:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40f9bc:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40f9c2:	lea    rax,[rax+0x40]
  40f9c6:	jmp    40f980 <__swc_fn_fc36583a_000104_04d1a8be+0x10>
  40f9c8:	nop    DWORD PTR [rax+rax*1+0x0]
  40f9d0:	mov    r9,r8
  40f9d3:	sub    r9,rax
  40f9d6:	cmp    r9,0x10
  40f9da:	jb     40f9f4 <__swc_fn_fc36583a_000104_04d1a8be+0x84>
  40f9dc:	lea    r9,[rdx+rax*1]
  40f9e0:	lea    r10,[rcx+rax*1]
  40f9e4:	vmovups xmm0,XMMWORD PTR [r9]
  40f9e9:	vmovups XMMWORD PTR [r10],xmm0
  40f9ee:	lea    rax,[rax+0x10]
  40f9f2:	jmp    40f9d0 <__swc_fn_fc36583a_000104_04d1a8be+0x60>
  40f9f4:	cs nop WORD PTR [rax+rax*1+0x0]
  40f9fe:	xchg   ax,ax
  40fa00:	mov    r9,r8
  40fa03:	sub    r9,rax
  40fa06:	cmp    r9,0x8
  40fa0a:	jb     40fa1d <__swc_fn_fc36583a_000104_04d1a8be+0xad>
  40fa0c:	lea    r9,[rcx+rax*1]
  40fa10:	mov    r10,QWORD PTR [rdx+rax*1]
  40fa14:	mov    QWORD PTR [r9],r10
  40fa17:	lea    rax,[rax+0x8]
  40fa1b:	jmp    40fa00 <__swc_fn_fc36583a_000104_04d1a8be+0x90>
  40fa1d:	cmp    rax,r8
  40fa20:	jae    40fa40 <__swc_fn_fc36583a_000104_04d1a8be+0xd0>
  40fa22:	cs nop WORD PTR [rax+rax*1+0x0]
  40fa2c:	nop    DWORD PTR [rax+0x0]
  40fa30:	mov    r9b,BYTE PTR [rdx+rax*1]
  40fa34:	mov    BYTE PTR [rcx+rax*1],r9b
  40fa38:	inc    rax
  40fa3b:	cmp    rax,r8
  40fa3e:	jb     40fa30 <__swc_fn_fc36583a_000104_04d1a8be+0xc0>
  40fa40:	ret
	...

000000000040fa50 <__swc_fn_fc36583a_000107_c8d4a68e>:
  40fa50:	push   rbx
  40fa51:	push   r12
  40fa53:	push   rdi
  40fa54:	push   rsi
  40fa55:	push   r13
  40fa57:	push   r14
  40fa59:	push   r15
  40fa5b:	sub    rsp,0x170
  40fa62:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40fa6b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40fa74:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40fa7d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40fa86:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40fa8f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40fa98:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40faa1:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40faaa:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40fab3:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40fabc:	mov    ebx,edx
  40fabe:	mov    QWORD PTR [rsp+0xa8],rbx
  40fac6:	mov    r12d,ecx
  40fac9:	test   edx,edx
  40facb:	jne    40fae2 <__swc_fn_fc36583a_000107_c8d4a68e+0x92>
  40facd:	xor    eax,eax
  40facf:	add    rsp,0x170
  40fad6:	pop    r15
  40fad8:	pop    r14
  40fada:	pop    r13
  40fadc:	pop    rsi
  40fadd:	pop    rdi
  40fade:	pop    r12
  40fae0:	pop    rbx
  40fae1:	ret
  40fae2:	lea    rdi,[rip+0x39c7]        # 4134b0 <__swc_rdata_base_fc36583a+0x3a0>
  40fae9:	mov    esi,0x90000
  40faee:	xor    eax,eax
  40faf0:	call   407090 <open@plt>
  40faf5:	mov    r13,rax
  40faf8:	mov    QWORD PTR [rsp+0xb0],rax
  40fb00:	test   eax,eax
  40fb02:	jge    40fb0b <__swc_fn_fc36583a_000107_c8d4a68e+0xbb>
  40fb04:	xor    eax,eax
  40fb06:	jmp    410006 <__swc_fn_fc36583a_000107_c8d4a68e+0x5b6>
  40fb0b:	nop    DWORD PTR [rax+rax*1+0x0]
  40fb10:	movsxd rdi,r13d
  40fb13:	mov    esi,0x2
  40fb18:	xor    eax,eax
  40fb1a:	call   407110 <flock@plt>
  40fb1f:	test   eax,eax
  40fb21:	je     40fb40 <__swc_fn_fc36583a_000107_c8d4a68e+0xf0>
  40fb23:	xor    eax,eax
  40fb25:	call   407120 <__errno_location@plt>
  40fb2a:	cmp    DWORD PTR [rax],0x4
  40fb2d:	je     40fb10 <__swc_fn_fc36583a_000107_c8d4a68e+0xc0>
  40fb2f:	movsxd rdi,r13d
  40fb32:	xor    eax,eax
  40fb34:	call   4070b0 <close@plt>
  40fb39:	xor    eax,eax
  40fb3b:	jmp    410006 <__swc_fn_fc36583a_000107_c8d4a68e+0x5b6>
  40fb40:	lea    r14,[rsp+0x8]
  40fb45:	mov    QWORD PTR [rsp+0xb8],r14
  40fb4d:	vxorps xmm0,xmm0,xmm0
  40fb51:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40fb57:	mov    QWORD PTR [rsp+0x18],0x0
  40fb60:	mov    WORD PTR [rsp+0x20],0x0
  40fb67:	mov    DWORD PTR [r14],0x67617753
  40fb6e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40fb76:	xor    eax,eax
  40fb78:	call   407010 <getpid@plt>
  40fb7d:	mov    ecx,eax
  40fb7f:	mov    eax,0x1c
  40fb84:	shrx   eax,ecx,eax
  40fb89:	and    eax,0xf
  40fb8c:	mov    rdx,QWORD PTR [rip+0x393d]        # 4134d0 <__swc_rdata_base_fc36583a+0x3c0>
  40fb93:	mov    al,BYTE PTR [rdx+rax*1]
  40fb96:	rex mov BYTE PTR [rsp+0x10],al
  40fb9b:	mov    eax,0x1c
  40fba0:	shrx   eax,r12d,eax
  40fba5:	and    eax,0xf
  40fba8:	mov    al,BYTE PTR [rdx+rax*1]
  40fbab:	rex mov BYTE PTR [rsp+0x19],al
  40fbb0:	mov    eax,0x18
  40fbb5:	shrx   eax,ecx,eax
  40fbba:	and    eax,0xf
  40fbbd:	mov    al,BYTE PTR [rdx+rax*1]
  40fbc0:	rex mov BYTE PTR [rsp+0x11],al
  40fbc5:	mov    eax,0x18
  40fbca:	shrx   eax,r12d,eax
  40fbcf:	and    eax,0xf
  40fbd2:	mov    al,BYTE PTR [rdx+rax*1]
  40fbd5:	rex mov BYTE PTR [rsp+0x1a],al
  40fbda:	mov    eax,0x14
  40fbdf:	shrx   eax,ecx,eax
  40fbe4:	and    eax,0xf
  40fbe7:	mov    al,BYTE PTR [rdx+rax*1]
  40fbea:	rex mov BYTE PTR [rsp+0x12],al
  40fbef:	mov    eax,0x14
  40fbf4:	shrx   eax,r12d,eax
  40fbf9:	and    eax,0xf
  40fbfc:	mov    al,BYTE PTR [rdx+rax*1]
  40fbff:	rex mov BYTE PTR [rsp+0x1b],al
  40fc04:	mov    eax,0x10
  40fc09:	shrx   eax,ecx,eax
  40fc0e:	and    eax,0xf
  40fc11:	mov    al,BYTE PTR [rdx+rax*1]
  40fc14:	rex mov BYTE PTR [rsp+0x13],al
  40fc19:	mov    eax,0x10
  40fc1e:	shrx   eax,r12d,eax
  40fc23:	and    eax,0xf
  40fc26:	mov    al,BYTE PTR [rdx+rax*1]
  40fc29:	rex mov BYTE PTR [rsp+0x1c],al
  40fc2e:	mov    eax,0xc
  40fc33:	shrx   eax,ecx,eax
  40fc38:	and    eax,0xf
  40fc3b:	mov    al,BYTE PTR [rdx+rax*1]
  40fc3e:	rex mov BYTE PTR [rsp+0x14],al
  40fc43:	mov    eax,0xc
  40fc48:	shrx   eax,r12d,eax
  40fc4d:	and    eax,0xf
  40fc50:	mov    al,BYTE PTR [rdx+rax*1]
  40fc53:	rex mov BYTE PTR [rsp+0x1d],al
  40fc58:	mov    eax,0x8
  40fc5d:	shrx   eax,ecx,eax
  40fc62:	and    eax,0xf
  40fc65:	mov    al,BYTE PTR [rdx+rax*1]
  40fc68:	rex mov BYTE PTR [rsp+0x15],al
  40fc6d:	mov    eax,0x8
  40fc72:	shrx   eax,r12d,eax
  40fc77:	and    eax,0xf
  40fc7a:	mov    al,BYTE PTR [rdx+rax*1]
  40fc7d:	rex mov BYTE PTR [rsp+0x1e],al
  40fc82:	mov    eax,0x4
  40fc87:	shrx   eax,ecx,eax
  40fc8c:	and    eax,0xf
  40fc8f:	mov    al,BYTE PTR [rdx+rax*1]
  40fc92:	rex mov BYTE PTR [rsp+0x16],al
  40fc97:	mov    eax,0x4
  40fc9c:	shrx   eax,r12d,eax
  40fca1:	and    eax,0xf
  40fca4:	mov    al,BYTE PTR [rdx+rax*1]
  40fca7:	rex mov BYTE PTR [rsp+0x1f],al
  40fcac:	xor    eax,eax
  40fcae:	shrx   eax,ecx,eax
  40fcb3:	and    eax,0xf
  40fcb6:	mov    al,BYTE PTR [rdx+rax*1]
  40fcb9:	rex mov BYTE PTR [rsp+0x17],al
  40fcbe:	xor    eax,eax
  40fcc0:	shrx   eax,r12d,eax
  40fcc5:	and    eax,0xf
  40fcc8:	mov    al,BYTE PTR [rdx+rax*1]
  40fccb:	rex mov BYTE PTR [rsp+0x20],al
  40fcd0:	mov    BYTE PTR [r14+0x10],0x2e
  40fcd5:	lea    r12,[rsp+0x22]
  40fcda:	vxorps xmm0,xmm0,xmm0
  40fcde:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40fce4:	mov    DWORD PTR [r12],0x6d656d2f
  40fcec:	mov    WORD PTR [r12+0x4],0x6466
  40fcf4:	mov    BYTE PTR [r12+0x6],0x3a
  40fcfa:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40fd00:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40fd06:	mov    rax,QWORD PTR [rsp+0x18]
  40fd0b:	mov    QWORD PTR [rsp+0x39],rax
  40fd10:	rex mov al,BYTE PTR [rsp+0x20]
  40fd15:	rex mov BYTE PTR [rsp+0x41],al
  40fd1a:	mov    DWORD PTR [r12+0x20],0x65642820
  40fd23:	mov    DWORD PTR [r12+0x24],0x6574656c
  40fd2c:	mov    WORD PTR [r12+0x28],0x2964
  40fd34:	lea    rdi,[rip+0x3780]        # 4134bb <__swc_rdata_base_fc36583a+0x3ab>
  40fd3b:	xor    eax,eax
  40fd3d:	call   407130 <opendir@plt>
  40fd42:	mov    r15,rax
  40fd45:	test   rax,rax
  40fd48:	jne    40fd5b <__swc_fn_fc36583a_000107_c8d4a68e+0x30b>
  40fd4a:	movsxd rdi,r13d
  40fd4d:	xor    eax,eax
  40fd4f:	call   4070b0 <close@plt>
  40fd54:	xor    eax,eax
  40fd56:	jmp    410006 <__swc_fn_fc36583a_000107_c8d4a68e+0x5b6>
  40fd5b:	mov    rdi,r15
  40fd5e:	xor    eax,eax
  40fd60:	call   407140 <dirfd@plt>
  40fd65:	lea    r14,[rsp+0x54]
  40fd6a:	mov    DWORD PTR [rsp+0x54],eax
  40fd6e:	lea    rbx,[rsp+0x58]
  40fd73:	cs nop WORD PTR [rax+rax*1+0x0]
  40fd7d:	nop    DWORD PTR [rax]
  40fd80:	mov    rdi,r15
  40fd83:	xor    eax,eax
  40fd85:	call   407150 <readdir@plt>
  40fd8a:	test   rax,rax
  40fd8d:	jne    40fda4 <__swc_fn_fc36583a_000107_c8d4a68e+0x354>
  40fd8f:	mov    r12,QWORD PTR [rsp+0xa8]
  40fd97:	mov    r13,QWORD PTR [rsp+0xb0]
  40fd9f:	jmp    40ff2a <__swc_fn_fc36583a_000107_c8d4a68e+0x4da>
  40fda4:	vxorps xmm0,xmm0,xmm0
  40fda8:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  40fdae:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  40fdb4:	vzeroupper
  40fdb7:	lea    r13,[rax+0x13]
  40fdbb:	mov    rax,r14
  40fdbe:	movsxd rdi,DWORD PTR [rax]
  40fdc1:	mov    rsi,r13
  40fdc4:	mov    rdx,rbx
  40fdc7:	mov    ecx,0x40
  40fdcc:	xor    eax,eax
  40fdce:	call   407160 <readlinkat@plt>
  40fdd3:	cmp    rax,0x2a
  40fdd7:	jne    40fd80 <__swc_fn_fc36583a_000107_c8d4a68e+0x330>
  40fdd9:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40fddf:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40fde5:	vptest xmm0,xmm0
  40fdea:	jne    40fe1a <__swc_fn_fc36583a_000107_c8d4a68e+0x3ca>
  40fdec:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40fdf2:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40fdf8:	vptest xmm0,xmm0
  40fdfd:	jne    40fe1a <__swc_fn_fc36583a_000107_c8d4a68e+0x3ca>
  40fdff:	mov    rcx,QWORD PTR [rsp+0x42]
  40fe04:	cmp    QWORD PTR [rsp+0x78],rcx
  40fe09:	jne    40fe1a <__swc_fn_fc36583a_000107_c8d4a68e+0x3ca>
  40fe0b:	mov    cx,WORD PTR [rsp+0x4a]
  40fe10:	cmp    WORD PTR [rsp+0x80],cx
  40fe18:	je     40fe44 <__swc_fn_fc36583a_000107_c8d4a68e+0x3f4>
  40fe1a:	mov    rax,rbx
  40fe1d:	mov    rcx,r12
  40fe20:	movzx  edx,BYTE PTR [rax]
  40fe23:	movzx  r8d,BYTE PTR [rcx]
  40fe27:	cmp    rdx,r8
  40fe2a:	jne    40fe36 <__swc_fn_fc36583a_000107_c8d4a68e+0x3e6>
  40fe2c:	add    rax,0x1
  40fe30:	add    rcx,0x1
  40fe34:	jmp    40fe20 <__swc_fn_fc36583a_000107_c8d4a68e+0x3d0>
  40fe36:	mov    rax,rdx
  40fe39:	sub    rax,r8
  40fe3c:	test   eax,eax
  40fe3e:	jne    40fd80 <__swc_fn_fc36583a_000107_c8d4a68e+0x330>
  40fe44:	movsxd rdi,DWORD PTR [r14]
  40fe47:	mov    rsi,r13
  40fe4a:	mov    edx,0x80002
  40fe4f:	xor    eax,eax
  40fe51:	call   407170 <openat@plt>
  40fe56:	lea    rbx,[rsp+0x98]
  40fe5e:	mov    DWORD PTR [rsp+0x98],eax
  40fe65:	test   eax,eax
  40fe67:	mov    r13,QWORD PTR [rsp+0xb0]
  40fe6f:	jge    40fe94 <__swc_fn_fc36583a_000107_c8d4a68e+0x444>
  40fe71:	mov    rdi,r15
  40fe74:	xor    eax,eax
  40fe76:	call   407180 <closedir@plt>
  40fe7b:	mov    r13,QWORD PTR [rsp+0xb0]
  40fe83:	movsxd rdi,r13d
  40fe86:	xor    eax,eax
  40fe88:	call   4070b0 <close@plt>
  40fe8d:	xor    eax,eax
  40fe8f:	jmp    410006 <__swc_fn_fc36583a_000107_c8d4a68e+0x5b6>
  40fe94:	mov    rax,rbx
  40fe97:	movsxd rdi,DWORD PTR [rax]
  40fe9a:	xor    esi,esi
  40fe9c:	mov    edx,0x2
  40fea1:	xor    eax,eax
  40fea3:	call   4070a0 <lseek@plt>
  40fea8:	mov    r12,QWORD PTR [rsp+0xa8]
  40feb0:	cmp    rax,r12
  40feb3:	je     40feda <__swc_fn_fc36583a_000107_c8d4a68e+0x48a>
  40feb5:	movsxd rdi,DWORD PTR [rbx]
  40feb8:	xor    eax,eax
  40feba:	call   4070b0 <close@plt>
  40febf:	mov    rdi,r15
  40fec2:	xor    eax,eax
  40fec4:	call   407180 <closedir@plt>
  40fec9:	movsxd rdi,r13d
  40fecc:	xor    eax,eax
  40fece:	call   4070b0 <close@plt>
  40fed3:	xor    eax,eax
  40fed5:	jmp    410006 <__swc_fn_fc36583a_000107_c8d4a68e+0x5b6>
  40feda:	xor    edi,edi
  40fedc:	mov    rsi,r12
  40fedf:	mov    edx,0x3
  40fee4:	mov    ecx,0x1
  40fee9:	mov    rax,rbx
  40feec:	movsxd r8,DWORD PTR [rax]
  40feef:	xor    r9d,r9d
  40fef2:	xor    eax,eax
  40fef4:	call   4070c0 <mmap@plt>
  40fef9:	xor    r12d,r12d
  40fefc:	cmp    rax,0xffffffffffffffff
  40ff00:	cmovne r12,rax
  40ff04:	movsxd rdi,DWORD PTR [rbx]
  40ff07:	xor    eax,eax
  40ff09:	call   4070b0 <close@plt>
  40ff0e:	mov    rdi,r15
  40ff11:	xor    eax,eax
  40ff13:	call   407180 <closedir@plt>
  40ff18:	movsxd rdi,r13d
  40ff1b:	xor    eax,eax
  40ff1d:	call   4070b0 <close@plt>
  40ff22:	mov    rax,r12
  40ff25:	jmp    410006 <__swc_fn_fc36583a_000107_c8d4a68e+0x5b6>
  40ff2a:	mov    r14,QWORD PTR [rsp+0xb8]
  40ff32:	mov    rdi,r14
  40ff35:	mov    esi,0x1
  40ff3a:	xor    eax,eax
  40ff3c:	call   407190 <memfd_create@plt>
  40ff41:	lea    rbx,[rsp+0x9c]
  40ff49:	mov    DWORD PTR [rsp+0x9c],eax
  40ff50:	test   eax,eax
  40ff52:	jge    40ff6f <__swc_fn_fc36583a_000107_c8d4a68e+0x51f>
  40ff54:	mov    rdi,r15
  40ff57:	xor    eax,eax
  40ff59:	call   407180 <closedir@plt>
  40ff5e:	movsxd rdi,r13d
  40ff61:	xor    eax,eax
  40ff63:	call   4070b0 <close@plt>
  40ff68:	xor    eax,eax
  40ff6a:	jmp    410006 <__swc_fn_fc36583a_000107_c8d4a68e+0x5b6>
  40ff6f:	mov    rax,rbx
  40ff72:	movsxd rdi,DWORD PTR [rax]
  40ff75:	mov    rsi,r12
  40ff78:	xor    eax,eax
  40ff7a:	call   4071a0 <ftruncate@plt>
  40ff7f:	test   eax,eax
  40ff81:	je     40ffa5 <__swc_fn_fc36583a_000107_c8d4a68e+0x555>
  40ff83:	movsxd rdi,DWORD PTR [rbx]
  40ff86:	xor    eax,eax
  40ff88:	call   4070b0 <close@plt>
  40ff8d:	mov    rdi,r15
  40ff90:	xor    eax,eax
  40ff92:	call   407180 <closedir@plt>
  40ff97:	movsxd rdi,r13d
  40ff9a:	xor    eax,eax
  40ff9c:	call   4070b0 <close@plt>
  40ffa1:	xor    eax,eax
  40ffa3:	jmp    410006 <__swc_fn_fc36583a_000107_c8d4a68e+0x5b6>
  40ffa5:	xor    edi,edi
  40ffa7:	mov    rsi,r12
  40ffaa:	mov    edx,0x3
  40ffaf:	mov    ecx,0x1
  40ffb4:	mov    rax,rbx
  40ffb7:	movsxd r8,DWORD PTR [rax]
  40ffba:	xor    r9d,r9d
  40ffbd:	xor    eax,eax
  40ffbf:	call   4070c0 <mmap@plt>
  40ffc4:	mov    r12,rax
  40ffc7:	cmp    rax,0xffffffffffffffff
  40ffcb:	jne    40ffef <__swc_fn_fc36583a_000107_c8d4a68e+0x59f>
  40ffcd:	movsxd rdi,DWORD PTR [rbx]
  40ffd0:	xor    eax,eax
  40ffd2:	call   4070b0 <close@plt>
  40ffd7:	mov    rdi,r15
  40ffda:	xor    eax,eax
  40ffdc:	call   407180 <closedir@plt>
  40ffe1:	movsxd rdi,r13d
  40ffe4:	xor    eax,eax
  40ffe6:	call   4070b0 <close@plt>
  40ffeb:	xor    eax,eax
  40ffed:	jmp    410006 <__swc_fn_fc36583a_000107_c8d4a68e+0x5b6>
  40ffef:	mov    rdi,r15
  40fff2:	xor    eax,eax
  40fff4:	call   407180 <closedir@plt>
  40fff9:	movsxd rdi,r13d
  40fffc:	xor    eax,eax
  40fffe:	call   4070b0 <close@plt>
  410003:	mov    rax,r12
  410006:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  41000f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  410018:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  410021:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  41002a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  410033:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  41003c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  410045:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  41004e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  410057:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  410060:	add    rsp,0x170
  410067:	pop    r15
  410069:	pop    r14
  41006b:	pop    r13
  41006d:	pop    rsi
  41006e:	pop    rdi
  41006f:	pop    r12
  410071:	pop    rbx
  410072:	ret
	...

0000000000410080 <__swc_fn_fc36583a_000110_918d5a21>:
  410080:	push   rsi
  410081:	push   rdi
  410082:	push   r12
  410084:	push   r13
  410086:	sub    rsp,0x8
  41008a:	mov    rsi,r8
  41008d:	mov    rdi,rcx
  410090:	mov    r12,rdx
  410093:	call   409100 <__swc_fn_fc36583a_000108_b8f4bd15>
  410098:	mov    r13,rax
  41009b:	test   rax,rax
  41009e:	jne    4100ab <__swc_fn_fc36583a_000110_918d5a21+0x2b>
  4100a0:	add    rsp,0x8
  4100a4:	pop    r13
  4100a6:	pop    r12
  4100a8:	pop    rdi
  4100a9:	pop    rsi
  4100aa:	ret
  4100ab:	mov    rcx,r13
  4100ae:	call   40d530 <__swc_fn_fc36583a_000133_807fd51d>
  4100b3:	mov    rax,QWORD PTR [r13+0x8]
  4100b7:	test   rax,rax
  4100ba:	je     4100f9 <__swc_fn_fc36583a_000110_918d5a21+0x79>
  4100bc:	nop    DWORD PTR [rax+0x0]
  4100c0:	lea    rcx,[rax+0x1000]
  4100c7:	cmp    rdi,rcx
  4100ca:	jne    4100f1 <__swc_fn_fc36583a_000110_918d5a21+0x71>
  4100cc:	cmp    r12,0x1000
  4100d3:	jb     4100f1 <__swc_fn_fc36583a_000110_918d5a21+0x71>
  4100d5:	test   sil,sil
  4100d8:	setne  cl
  4100db:	mov    BYTE PTR [rax+0x10],cl
  4100de:	mov    rcx,r13
  4100e1:	call   4105e0 <__swc_fn_fc36583a_000134_10472836>
  4100e6:	add    rsp,0x8
  4100ea:	pop    r13
  4100ec:	pop    r12
  4100ee:	pop    rdi
  4100ef:	pop    rsi
  4100f0:	ret
  4100f1:	mov    rax,QWORD PTR [rax]
  4100f4:	test   rax,rax
  4100f7:	jne    4100c0 <__swc_fn_fc36583a_000110_918d5a21+0x40>
  4100f9:	mov    rcx,r13
  4100fc:	call   4105e0 <__swc_fn_fc36583a_000134_10472836>
  410101:	add    rsp,0x8
  410105:	pop    r13
  410107:	pop    r12
  410109:	pop    rdi
  41010a:	pop    rsi
  41010b:	ret
  41010c:	add    BYTE PTR [rax],al
	...

0000000000410110 <__swc_fn_fc36583a_000113_4e83a03a>:
  410110:	sub    rsp,0x8
  410114:	test   rcx,rcx
  410117:	jne    41011e <__swc_fn_fc36583a_000113_4e83a03a+0xe>
  410119:	add    rsp,0x8
  41011d:	ret
  41011e:	call   40d040 <__swc_fn_fc36583a_000115_3f6af4b1>
  410123:	add    rsp,0x8
  410127:	ret
	...

0000000000410130 <__swc_fn_fc36583a_000116_3f5cfdef>:
  410130:	push   r12
  410132:	push   r13
  410134:	push   r14
  410136:	push   rdi
  410137:	push   rsi
  410138:	sub    rsp,0xc0
  41013f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  410145:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  41014b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  410151:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410157:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  41015d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  410163:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410169:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  410172:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  41017b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  410184:	mov    r12,QWORD PTR [rcx]
  410187:	test   r12,r12
  41018a:	jne    41019c <__swc_fn_fc36583a_000116_3f5cfdef+0x6c>
  41018c:	add    rsp,0xc0
  410193:	pop    rsi
  410194:	pop    rdi
  410195:	pop    r14
  410197:	pop    r13
  410199:	pop    r12
  41019b:	ret
  41019c:	xor    r13d,r13d
  41019f:	mov    r14,QWORD PTR [rcx+0x8]
  4101a3:	cs nop WORD PTR [rax+rax*1+0x0]
  4101ad:	nop    DWORD PTR [rax]
  4101b0:	cmp    r13,r14
  4101b3:	jae    4101eb <__swc_fn_fc36583a_000116_3f5cfdef+0xbb>
  4101b5:	lea    rax,[r12+r13*1]
  4101b9:	mov    rcx,r14
  4101bc:	sub    rcx,r13
  4101bf:	mov    edi,0x1
  4101c4:	mov    rsi,rax
  4101c7:	mov    rdx,rcx
  4101ca:	xor    eax,eax
  4101cc:	call   4071b0 <write@plt>
  4101d1:	test   rax,rax
  4101d4:	jle    4101db <__swc_fn_fc36583a_000116_3f5cfdef+0xab>
  4101d6:	add    r13,rax
  4101d9:	jmp    4101b0 <__swc_fn_fc36583a_000116_3f5cfdef+0x80>
  4101db:	je     4101e9 <__swc_fn_fc36583a_000116_3f5cfdef+0xb9>
  4101dd:	xor    eax,eax
  4101df:	call   407120 <__errno_location@plt>
  4101e4:	cmp    DWORD PTR [rax],0x4
  4101e7:	je     4101b0 <__swc_fn_fc36583a_000116_3f5cfdef+0x80>
  4101e9:	jmp    4101eb <__swc_fn_fc36583a_000116_3f5cfdef+0xbb>
  4101eb:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4101f1:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4101f7:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4101fd:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  410203:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410209:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  41020f:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  410215:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  41021e:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  410227:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410230:	add    rsp,0xc0
  410237:	pop    rsi
  410238:	pop    rdi
  410239:	pop    r14
  41023b:	pop    r13
  41023d:	pop    r12
  41023f:	ret

0000000000410240 <__swc_fn_fc36583a_000119_2d9caf16>:
  410240:	push   rbx
  410241:	push   r12
  410243:	push   rdi
  410244:	push   rsi
  410245:	sub    rsp,0x4a8
  41024c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  410255:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  41025e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  410267:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  410270:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  410279:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  410282:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  41028b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  410294:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  41029d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  4102a6:	mov    rbx,rdx
  4102a9:	mov    r12d,ecx
  4102ac:	vxorps xmm0,xmm0,xmm0
  4102b0:	xor    eax,eax
  4102b2:	cs nop WORD PTR [rax+rax*1+0x0]
  4102bc:	nop    DWORD PTR [rax+0x0]
  4102c0:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  4102c6:	add    rax,0x10
  4102ca:	cmp    rax,0x400
  4102d1:	jne    4102c0 <__swc_fn_fc36583a_000119_2d9caf16+0x80>
  4102d3:	lea    rdi,[rsp+0x8]
  4102d8:	mov    esi,0x80
  4102dd:	xor    eax,eax
  4102df:	call   4071c0 <backtrace@plt>
  4102e4:	test   eax,eax
  4102e6:	jle    4102f5 <__swc_fn_fc36583a_000119_2d9caf16+0xb5>
  4102e8:	movsxd rax,eax
  4102eb:	lea    rcx,[r12+0x1]
  4102f0:	cmp    rcx,rax
  4102f3:	jb     4102f9 <__swc_fn_fc36583a_000119_2d9caf16+0xb9>
  4102f5:	xor    eax,eax
  4102f7:	jmp    41032a <__swc_fn_fc36583a_000119_2d9caf16+0xea>
  4102f9:	mov    rcx,QWORD PTR [rbx+0x8]
  4102fd:	sub    rax,r12
  410300:	lea    rsi,[rax-0x1]
  410304:	cmp    rcx,rsi
  410307:	cmovbe rsi,rcx
  41030b:	lea    eax,[r12+0x1]
  410310:	lea    rax,[rsp+rax*8+0x8]
  410315:	mov    rcx,QWORD PTR [rbx]
  410318:	mov    rdx,rax
  41031b:	lea    r8,[rsi*8+0x0]
  410323:	call   4090e0 <__swc_fn_fc36583a_000105_83487ba1>
  410328:	mov    eax,esi
  41032a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  410333:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  41033c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  410345:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  41034e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  410357:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  410360:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  410369:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  410372:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  41037b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  410384:	add    rsp,0x4a8
  41038b:	pop    rsi
  41038c:	pop    rdi
  41038d:	pop    r12
  41038f:	pop    rbx
  410390:	ret
	...

00000000004103a0 <__swc_fn_fc36583a_000122_66e5d2a9>:
  4103a0:	mov    QWORD PTR [rcx],0x0
  4103a7:	ret
	...

00000000004103b0 <__swc_fn_fc36583a_000125_7a81492f>:
  4103b0:	push   rdi
  4103b1:	push   rsi
  4103b2:	sub    rsp,0xa8
  4103b9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4103bf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4103c5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4103cb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4103d1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4103d7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4103dd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4103e3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4103e9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4103f2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4103fb:	mov    edi,ecx
  4103fd:	mov    rsi,rdx
  410400:	xor    eax,eax
  410402:	call   407060 <pthread_setspecific@plt>
  410407:	test   eax,eax
  410409:	sete   al
  41040c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410412:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410418:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41041e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410424:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  41042a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410430:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410436:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  41043c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410445:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41044e:	add    rsp,0xa8
  410455:	pop    rsi
  410456:	pop    rdi
  410457:	ret
	...

0000000000410460 <__swc_fn_fc36583a_000128_8d8a7dd2>:
  410460:	push   rdi
  410461:	push   rsi
  410462:	sub    rsp,0xa8
  410469:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41046f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410475:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41047b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410481:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410487:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41048d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410493:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410499:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4104a2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4104ab:	test   rcx,rcx
  4104ae:	je     4104c1 <__swc_fn_fc36583a_000128_8d8a7dd2+0x61>
  4104b0:	lea    rax,[rcx-0x1]
  4104b4:	mov    eax,eax
  4104b6:	mov    edi,eax
  4104b8:	xor    eax,eax
  4104ba:	call   407000 <pthread_getspecific@plt>
  4104bf:	jmp    4104c3 <__swc_fn_fc36583a_000128_8d8a7dd2+0x63>
  4104c1:	xor    eax,eax
  4104c3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4104c9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4104cf:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4104d5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4104db:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4104e1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4104e7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4104ed:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4104f3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4104fc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410505:	add    rsp,0xa8
  41050c:	pop    rsi
  41050d:	pop    rdi
  41050e:	ret
	...

0000000000410510 <__swc_fn_fc36583a_000131_91db8856>:
  410510:	push   rdi
  410511:	push   rsi
  410512:	sub    rsp,0xb8
  410519:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41051f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410525:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41052b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410531:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410537:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41053d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410543:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41054c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410555:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41055e:	vxorps xmm0,xmm0,xmm0
  410562:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410568:	mov    edi,0x1
  41056d:	lea    rsi,[rsp+0x8]
  410572:	xor    eax,eax
  410574:	call   4071d0 <clock_gettime@plt>
  410579:	mov    rax,QWORD PTR [rsp+0x8]
  41057e:	imul   rax,rax,0x3b9aca00
  410585:	add    rax,QWORD PTR [rsp+0x10]
  41058a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410590:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  410596:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  41059c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4105a2:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4105a8:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4105ae:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4105b4:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4105bd:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4105c6:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4105cf:	add    rsp,0xb8
  4105d6:	pop    rsi
  4105d7:	pop    rdi
  4105d8:	ret
  4105d9:	add    BYTE PTR [rax],al
  4105db:	add    BYTE PTR [rax],al
  4105dd:	add    BYTE PTR [rax],al
	...

00000000004105e0 <__swc_fn_fc36583a_000134_10472836>:
  4105e0:	sub    rsp,0x8
  4105e4:	xor    eax,eax
  4105e6:	mov    DWORD PTR [rcx],eax
  4105e8:	mov    edx,0x7fffffff
  4105ed:	call   4097e0 <__swc_fn_fc36583a_000132_51cc49e7>
  4105f2:	add    rsp,0x8
  4105f6:	ret
	...

0000000000410600 <__swc_fn_fc36583a_000137_2d595cc7>:
  410600:	push   rdi
  410601:	push   rsi
  410602:	sub    rsp,0xb8
  410609:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41060f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410615:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41061b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410621:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410627:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41062d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410633:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41063c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410645:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41064e:	mov    edi,0x1
  410653:	xor    eax,eax
  410655:	call   4071e0 <__x86_get_cpuid_feature_leaf@plt>
  41065a:	mov    eax,DWORD PTR [rax+0x14]
  41065d:	and    eax,0x20
  410660:	setne  al
  410663:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410669:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  41066f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410675:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41067b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410681:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  410687:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41068d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  410696:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  41069f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4106a8:	add    rsp,0xb8
  4106af:	pop    rsi
  4106b0:	pop    rdi
  4106b1:	ret
	...

00000000004106c0 <__swc_fn_fc36583a_000140_55003b6d>:
  4106c0:	push   rsi
  4106c1:	push   rdi
  4106c2:	push   r12
  4106c4:	push   r13
  4106c6:	push   r14
  4106c8:	push   r15
  4106ca:	cmp    rdx,0x40
  4106ce:	jae    4106dd <__swc_fn_fc36583a_000140_55003b6d+0x1d>
  4106d0:	xor    eax,eax
  4106d2:	pop    r15
  4106d4:	pop    r14
  4106d6:	pop    r13
  4106d8:	pop    r12
  4106da:	pop    rdi
  4106db:	pop    rsi
  4106dc:	ret
  4106dd:	cmp    BYTE PTR [rcx],0x7f
  4106e0:	jne    410724 <__swc_fn_fc36583a_000140_55003b6d+0x64>
  4106e2:	movzx  eax,BYTE PTR [rcx+0x1]
  4106e6:	cmp    eax,0x45
  4106e9:	setne  al
  4106ec:	jne    410720 <__swc_fn_fc36583a_000140_55003b6d+0x60>
  4106ee:	movzx  eax,BYTE PTR [rcx+0x2]
  4106f2:	cmp    eax,0x4c
  4106f5:	setne  al
  4106f8:	jne    410720 <__swc_fn_fc36583a_000140_55003b6d+0x60>
  4106fa:	movzx  eax,BYTE PTR [rcx+0x3]
  4106fe:	cmp    eax,0x46
  410701:	setne  al
  410704:	jne    410720 <__swc_fn_fc36583a_000140_55003b6d+0x60>
  410706:	cmp    BYTE PTR [rcx+0x4],0x2
  41070a:	setne  al
  41070d:	jne    410720 <__swc_fn_fc36583a_000140_55003b6d+0x60>
  41070f:	cmp    BYTE PTR [rcx+0x5],0x1
  410713:	setne  al
  410716:	jne    410720 <__swc_fn_fc36583a_000140_55003b6d+0x60>
  410718:	cmp    WORD PTR [rcx+0x12],0x3e
  41071d:	setne  al
  410720:	test   al,al
  410722:	je     410731 <__swc_fn_fc36583a_000140_55003b6d+0x71>
  410724:	xor    eax,eax
  410726:	pop    r15
  410728:	pop    r14
  41072a:	pop    r13
  41072c:	pop    r12
  41072e:	pop    rdi
  41072f:	pop    rsi
  410730:	ret
  410731:	cmp    WORD PTR [rcx+0x3a],0x40
  410736:	jne    410751 <__swc_fn_fc36583a_000140_55003b6d+0x91>
  410738:	cmp    WORD PTR [rcx+0x3c],0x0
  41073d:	sete   al
  410740:	je     41074d <__swc_fn_fc36583a_000140_55003b6d+0x8d>
  410742:	mov    ax,WORD PTR [rcx+0x3c]
  410746:	cmp    WORD PTR [rcx+0x3e],ax
  41074a:	setae  al
  41074d:	test   al,al
  41074f:	je     41075e <__swc_fn_fc36583a_000140_55003b6d+0x9e>
  410751:	xor    eax,eax
  410753:	pop    r15
  410755:	pop    r14
  410757:	pop    r13
  410759:	pop    r12
  41075b:	pop    rdi
  41075c:	pop    rsi
  41075d:	ret
  41075e:	movzx  eax,WORD PTR [rcx+0x3c]
  410762:	shl    rax,0x6
  410766:	cmp    rax,rdx
  410769:	ja     410777 <__swc_fn_fc36583a_000140_55003b6d+0xb7>
  41076b:	mov    r9,rdx
  41076e:	sub    r9,rax
  410771:	cmp    QWORD PTR [rcx+0x28],r9
  410775:	jbe    410784 <__swc_fn_fc36583a_000140_55003b6d+0xc4>
  410777:	xor    eax,eax
  410779:	pop    r15
  41077b:	pop    r14
  41077d:	pop    r13
  41077f:	pop    r12
  410781:	pop    rdi
  410782:	pop    rsi
  410783:	ret
  410784:	mov    rax,QWORD PTR [rcx+0x28]
  410788:	add    rax,rcx
  41078b:	movzx  r9d,WORD PTR [rcx+0x3e]
  410790:	lea    r9,[r9*8+0x0]
  410798:	lea    r10,[rax+r9*8]
  41079c:	cmp    QWORD PTR [r10+0x20],rdx
  4107a0:	ja     4107c2 <__swc_fn_fc36583a_000140_55003b6d+0x102>
  4107a2:	mov    r11,rdx
  4107a5:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  4107aa:	cmp    QWORD PTR [r10+0x18],r11
  4107ae:	seta   r9b
  4107b2:	ja     4107bd <__swc_fn_fc36583a_000140_55003b6d+0xfd>
  4107b4:	cmp    QWORD PTR [r10+0x20],0x9
  4107b9:	setb   r9b
  4107bd:	test   r9b,r9b
  4107c0:	je     4107cf <__swc_fn_fc36583a_000140_55003b6d+0x10f>
  4107c2:	xor    eax,eax
  4107c4:	pop    r15
  4107c6:	pop    r14
  4107c8:	pop    r13
  4107ca:	pop    r12
  4107cc:	pop    rdi
  4107cd:	pop    rsi
  4107ce:	ret
  4107cf:	movzx  r9d,WORD PTR [rcx+0x3c]
  4107d4:	xor    r11d,r11d
  4107d7:	test   r9,r9
  4107da:	jbe    4108d5 <__swc_fn_fc36583a_000140_55003b6d+0x215>
  4107e0:	mov    rsi,QWORD PTR [r10+0x20]
  4107e4:	sub    rsi,0x9
  4107e8:	cs nop WORD PTR [rax+rax*1+0x0]
  4107f2:	cs nop WORD PTR [rax+rax*1+0x0]
  4107fc:	nop    DWORD PTR [rax+0x0]
  410800:	movzx  edi,r11w
  410804:	lea    rdi,[rdi*8+0x0]
  41080c:	lea    r12,[rax+rdi*8]
  410810:	rex mov edi,DWORD PTR [rax+rdi*8]
  410814:	cmp    rdi,rsi
  410817:	ja     4108c8 <__swc_fn_fc36583a_000140_55003b6d+0x208>
  41081d:	mov    r13,QWORD PTR [r10+0x18]
  410821:	add    r13,rdi
  410824:	lea    rdi,[rcx+r13*1]
  410828:	lea    r13,[rip+0x2d01]        # 413530 <__swc_rdata_base_fc36583a+0x420>
  41082f:	movabs r14,0x676264676177732e
  410839:	cmp    QWORD PTR [rdi],r14
  41083c:	jne    410845 <__swc_fn_fc36583a_000140_55003b6d+0x185>
  41083e:	rex cmp BYTE PTR [rdi+0x8],0x0
  410843:	je     410872 <__swc_fn_fc36583a_000140_55003b6d+0x1b2>
  410845:	cs nop WORD PTR [rax+rax*1+0x0]
  41084f:	nop
  410850:	movzx  r14d,BYTE PTR [rdi]
  410854:	movzx  r15d,BYTE PTR [r13+0x0]
  410859:	cmp    r14,r15
  41085c:	jne    410868 <__swc_fn_fc36583a_000140_55003b6d+0x1a8>
  41085e:	add    rdi,0x1
  410862:	add    r13,0x1
  410866:	jmp    410850 <__swc_fn_fc36583a_000140_55003b6d+0x190>
  410868:	mov    rdi,r14
  41086b:	sub    rdi,r15
  41086e:	test   edi,edi
  410870:	jne    4108c8 <__swc_fn_fc36583a_000140_55003b6d+0x208>
  410872:	cmp    DWORD PTR [r12+0x4],0x1
  410878:	jne    4108a0 <__swc_fn_fc36583a_000140_55003b6d+0x1e0>
  41087a:	cmp    QWORD PTR [r12+0x20],0x10
  410880:	setb   al
  410883:	jb     41089c <__swc_fn_fc36583a_000140_55003b6d+0x1dc>
  410885:	cmp    QWORD PTR [r12+0x20],rdx
  41088a:	seta   al
  41088d:	ja     41089c <__swc_fn_fc36583a_000140_55003b6d+0x1dc>
  41088f:	sub    rdx,QWORD PTR [r12+0x20]
  410894:	cmp    QWORD PTR [r12+0x18],rdx
  410899:	seta   al
  41089c:	test   al,al
  41089e:	je     4108ad <__swc_fn_fc36583a_000140_55003b6d+0x1ed>
  4108a0:	xor    eax,eax
  4108a2:	pop    r15
  4108a4:	pop    r14
  4108a6:	pop    r13
  4108a8:	pop    r12
  4108aa:	pop    rdi
  4108ab:	pop    rsi
  4108ac:	ret
  4108ad:	mov    rax,QWORD PTR [r12+0x20]
  4108b2:	mov    QWORD PTR [r8],rax
  4108b5:	mov    rax,QWORD PTR [r12+0x18]
  4108ba:	add    rax,rcx
  4108bd:	pop    r15
  4108bf:	pop    r14
  4108c1:	pop    r13
  4108c3:	pop    r12
  4108c5:	pop    rdi
  4108c6:	pop    rsi
  4108c7:	ret
  4108c8:	add    r11,0x1
  4108cc:	cmp    r11,r9
  4108cf:	jb     410800 <__swc_fn_fc36583a_000140_55003b6d+0x140>
  4108d5:	xor    eax,eax
  4108d7:	pop    r15
  4108d9:	pop    r14
  4108db:	pop    r13
  4108dd:	pop    r12
  4108df:	pop    rdi
  4108e0:	pop    rsi
  4108e1:	ret
	...

00000000004108f0 <__swc_fn_fc36583a_000143_b7ad855f>:
  4108f0:	push   rdi
  4108f1:	push   rsi
  4108f2:	sub    rsp,0xa8
  4108f9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4108ff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410905:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41090b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410911:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410917:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41091d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410923:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410929:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410932:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41093b:	mov    rdi,rcx
  41093e:	xor    eax,eax
  410940:	call   4071f0 <free@plt>
  410945:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41094b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410951:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410957:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41095d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410963:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410969:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41096f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410975:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41097e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410987:	add    rsp,0xa8
  41098e:	pop    rsi
  41098f:	pop    rdi
  410990:	ret
	...

00000000004109a0 <__swc_fn_fc36583a_000146_d2097256>:
  4109a0:	push   rbx
  4109a1:	push   rsi
  4109a2:	push   rdi
  4109a3:	push   r12
  4109a5:	push   r13
  4109a7:	push   r15
  4109a9:	sub    rsp,0x4e8
  4109b0:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  4109b9:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  4109c2:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  4109cb:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  4109d4:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  4109dd:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  4109e6:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  4109ef:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  4109f8:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  410a01:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  410a0a:	mov    rbx,QWORD PTR [rcx]
  410a0d:	mov    rcx,QWORD PTR [rcx+0x8]
  410a11:	mov    rsi,rcx
  410a14:	xor    edi,edi
  410a16:	vmovsd xmm6,QWORD PTR [rip+0x2b72]        # 413590 <__swc_rdata_base_fc36583a+0x480>
  410a1e:	vmovsd xmm7,QWORD PTR [rip+0x2b73]        # 413599 <__swc_rdata_base_fc36583a+0x489>
  410a26:	vmovsd xmm8,QWORD PTR [rip+0x2b74]        # 4135a2 <__swc_rdata_base_fc36583a+0x492>
  410a2e:	vmovsd xmm9,QWORD PTR [rip+0x2b75]        # 4135ab <__swc_rdata_base_fc36583a+0x49b>
  410a36:	vmovsd xmm10,QWORD PTR [rip+0x2b76]        # 4135b4 <__swc_rdata_base_fc36583a+0x4a4>
  410a3e:	vmovups xmm11,xmm6
  410a42:	vmovsd QWORD PTR [rsp+0x418],xmm7
  410a4b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  410a54:	vmovsd QWORD PTR [rsp+0x428],xmm9
  410a5d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  410a66:	vmovsd xmm15,QWORD PTR [rip+0x2b4f]        # 4135bd <__swc_rdata_base_fc36583a+0x4ad>
  410a6e:	vmovups xmm14,xmm15
  410a73:	vmovups xmm0,xmm9
  410a78:	vmovsd QWORD PTR [rsp+0x438],xmm15
  410a81:	vmovups xmm13,xmm8
  410a86:	vmovsd QWORD PTR [rsp+0x440],xmm15
  410a8f:	test   rsi,rsi
  410a92:	je     411a83 <__swc_fn_fc36583a_000146_d2097256+0x10e3>
  410a98:	cs nop WORD PTR [rax+rax*1+0x0]
  410aa2:	cs nop WORD PTR [rax+rax*1+0x0]
  410aac:	nop    DWORD PTR [rax+0x0]
  410ab0:	lea    rcx,[rdi+rdi*1]
  410ab4:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  410ab9:	vpshufd xmm3,xmm2,0xee
  410abe:	vmovq  rcx,xmm3
  410ac3:	test   rcx,rcx
  410ac6:	je     410adc <__swc_fn_fc36583a_000146_d2097256+0x13c>
  410ac8:	test   DWORD PTR [rcx+0x28],0x400000
  410acf:	je     410adc <__swc_fn_fc36583a_000146_d2097256+0x13c>
  410ad1:	mov    rdx,QWORD PTR [rcx+0x30]
  410ad5:	test   rdx,rdx
  410ad8:	cmovne rcx,rdx
  410adc:	test   DWORD PTR [rcx+0x28],0x1000
  410ae3:	je     410b04 <__swc_fn_fc36583a_000146_d2097256+0x164>
  410ae5:	mov    rdx,QWORD PTR [rcx+0x40]
  410ae9:	mov    rcx,rdx
  410aec:	vmovq  r8,xmm2
  410af1:	mov    r8,QWORD PTR [r8]
  410af4:	mov    QWORD PTR [rsp+0x60],r8
  410af9:	mov    QWORD PTR [rsp+0x68],rdx
  410afe:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  410b04:	test   BYTE PTR [rcx+0x28],0x1
  410b08:	jne    410b10 <__swc_fn_fc36583a_000146_d2097256+0x170>
  410b0a:	vmovups xmm12,xmm0
  410b0e:	jmp    410b2a <__swc_fn_fc36583a_000146_d2097256+0x18a>
  410b10:	vmovq  rax,xmm2
  410b15:	mov    rax,QWORD PTR [rax]
  410b18:	lea    rcx,[rax+0x10]
  410b1c:	vmovups xmm12,xmm0
  410b20:	call   410130 <__swc_fn_fc36583a_000116_3f5cfdef>
  410b25:	jmp    411a65 <__swc_fn_fc36583a_000146_d2097256+0x10c5>
  410b2a:	test   DWORD PTR [rcx+0x28],0x400
  410b31:	je     410b92 <__swc_fn_fc36583a_000146_d2097256+0x1f2>
  410b33:	vmovq  rax,xmm2
  410b38:	mov    rax,QWORD PTR [rax]
  410b3b:	xor    ecx,ecx
  410b3d:	test   rax,rax
  410b40:	je     410b70 <__swc_fn_fc36583a_000146_d2097256+0x1d0>
  410b42:	mov    rdx,rax
  410b45:	mov    r8b,BYTE PTR [rdx]
  410b48:	test   r8b,r8b
  410b4b:	je     410b70 <__swc_fn_fc36583a_000146_d2097256+0x1d0>
  410b4d:	cs nop WORD PTR [rax+rax*1+0x0]
  410b57:	nop    WORD PTR [rax+rax*1+0x0]
  410b60:	add    rdx,0x1
  410b64:	add    rcx,0x1
  410b68:	mov    r8b,BYTE PTR [rdx]
  410b6b:	test   r8b,r8b
  410b6e:	jne    410b60 <__swc_fn_fc36583a_000146_d2097256+0x1c0>
  410b70:	mov    QWORD PTR [rsp+0x88],rax
  410b78:	mov    QWORD PTR [rsp+0x90],rcx
  410b80:	lea    rcx,[rsp+0x88]
  410b88:	call   410130 <__swc_fn_fc36583a_000116_3f5cfdef>
  410b8d:	jmp    411a65 <__swc_fn_fc36583a_000146_d2097256+0x10c5>
  410b92:	cmp    BYTE PTR [rcx+0x2c],0x6
  410b96:	jne    410bad <__swc_fn_fc36583a_000146_d2097256+0x20d>
  410b98:	vmovq  rax,xmm2
  410b9d:	mov    rax,QWORD PTR [rax]
  410ba0:	mov    rcx,rax
  410ba3:	call   409cb0 <__swc_fn_fc36583a_000144_c3e86ca0>
  410ba8:	jmp    411a65 <__swc_fn_fc36583a_000146_d2097256+0x10c5>
  410bad:	cmp    BYTE PTR [rcx+0x2c],0x1
  410bb1:	jne    411a59 <__swc_fn_fc36583a_000146_d2097256+0x10b9>
  410bb7:	vmovq  rdx,xmm2
  410bbc:	mov    cl,BYTE PTR [rcx+0x40]
  410bbf:	cmp    cl,0x7
  410bc2:	jb     410c05 <__swc_fn_fc36583a_000146_d2097256+0x265>
  410bc4:	je     410c78 <__swc_fn_fc36583a_000146_d2097256+0x2d8>
  410bca:	cmp    cl,0x8
  410bcd:	je     410c84 <__swc_fn_fc36583a_000146_d2097256+0x2e4>
  410bd3:	cmp    cl,0x9
  410bd6:	je     410c9d <__swc_fn_fc36583a_000146_d2097256+0x2fd>
  410bdc:	cmp    cl,0xa
  410bdf:	je     411364 <__swc_fn_fc36583a_000146_d2097256+0x9c4>
  410be5:	cmp    cl,0xb
  410be8:	je     411a2b <__swc_fn_fc36583a_000146_d2097256+0x108b>
  410bee:	cmp    cl,0xc
  410bf1:	je     410c91 <__swc_fn_fc36583a_000146_d2097256+0x2f1>
  410bf7:	cmp    cl,0xd
  410bfa:	je     411a21 <__swc_fn_fc36583a_000146_d2097256+0x1081>
  410c00:	jmp    411a4b <__swc_fn_fc36583a_000146_d2097256+0x10ab>
  410c05:	cmp    cl,0x1
  410c08:	je     410c28 <__swc_fn_fc36583a_000146_d2097256+0x288>
  410c0a:	cmp    cl,0x2
  410c0d:	je     410c36 <__swc_fn_fc36583a_000146_d2097256+0x296>
  410c0f:	cmp    cl,0x3
  410c12:	je     410c44 <__swc_fn_fc36583a_000146_d2097256+0x2a4>
  410c14:	cmp    cl,0x4
  410c17:	je     410c51 <__swc_fn_fc36583a_000146_d2097256+0x2b1>
  410c19:	cmp    cl,0x5
  410c1c:	je     410c5e <__swc_fn_fc36583a_000146_d2097256+0x2be>
  410c1e:	cmp    cl,0x6
  410c21:	je     410c6b <__swc_fn_fc36583a_000146_d2097256+0x2cb>
  410c23:	jmp    411a4b <__swc_fn_fc36583a_000146_d2097256+0x10ab>
  410c28:	movsx  rcx,BYTE PTR [rdx]
  410c2c:	call   40d720 <__swc_fn_fc36583a_000145_32a1d6a2>
  410c31:	jmp    411a65 <__swc_fn_fc36583a_000146_d2097256+0x10c5>
  410c36:	movsx  rcx,WORD PTR [rdx]
  410c3a:	call   40d720 <__swc_fn_fc36583a_000145_32a1d6a2>
  410c3f:	jmp    411a65 <__swc_fn_fc36583a_000146_d2097256+0x10c5>
  410c44:	movsxd rcx,DWORD PTR [rdx]
  410c47:	call   40d720 <__swc_fn_fc36583a_000145_32a1d6a2>
  410c4c:	jmp    411a65 <__swc_fn_fc36583a_000146_d2097256+0x10c5>
  410c51:	mov    rcx,QWORD PTR [rdx]
  410c54:	call   40d720 <__swc_fn_fc36583a_000145_32a1d6a2>
  410c59:	jmp    411a65 <__swc_fn_fc36583a_000146_d2097256+0x10c5>
  410c5e:	movzx  ecx,BYTE PTR [rdx]
  410c61:	call   409cb0 <__swc_fn_fc36583a_000144_c3e86ca0>
  410c66:	jmp    411a65 <__swc_fn_fc36583a_000146_d2097256+0x10c5>
  410c6b:	movzx  ecx,WORD PTR [rdx]
  410c6e:	call   409cb0 <__swc_fn_fc36583a_000144_c3e86ca0>
  410c73:	jmp    411a65 <__swc_fn_fc36583a_000146_d2097256+0x10c5>
  410c78:	mov    ecx,DWORD PTR [rdx]
  410c7a:	call   409cb0 <__swc_fn_fc36583a_000144_c3e86ca0>
  410c7f:	jmp    411a65 <__swc_fn_fc36583a_000146_d2097256+0x10c5>
  410c84:	mov    rcx,QWORD PTR [rdx]
  410c87:	call   409cb0 <__swc_fn_fc36583a_000144_c3e86ca0>
  410c8c:	jmp    411a65 <__swc_fn_fc36583a_000146_d2097256+0x10c5>
  410c91:	mov    ecx,DWORD PTR [rdx]
  410c93:	call   409cb0 <__swc_fn_fc36583a_000144_c3e86ca0>
  410c98:	jmp    411a65 <__swc_fn_fc36583a_000146_d2097256+0x10c5>
  410c9d:	lea    rcx,[rsp+0xa8]
  410ca5:	vxorps xmm0,xmm0,xmm0
  410ca9:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  410cb2:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  410cbb:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  410cc4:	vzeroupper
  410cc7:	mov    DWORD PTR [rsp+0x108],0x0
  410cd2:	vxorpd xmm0,xmm0,xmm0
  410cd6:	vmovss xmm1,DWORD PTR [rdx]
  410cda:	vcvtss2sd xmm0,xmm0,xmm1
  410cde:	vmovsd xmm1,xmm1,xmm0
  410ce2:	vcomisd xmm0,xmm0
  410ce6:	setne  dl
  410ce9:	movzx  edx,dl
  410cec:	setp   r8b
  410cf0:	movzx  r8d,r8b
  410cf4:	or     edx,r8d
  410cf7:	test   dl,dl
  410cf9:	je     410d06 <__swc_fn_fc36583a_000146_d2097256+0x366>
  410cfb:	mov    DWORD PTR [rcx],0x6e616e
  410d01:	jmp    4112f8 <__swc_fn_fc36583a_000146_d2097256+0x958>
  410d06:	vcomisd xmm1,xmm6
  410d0a:	ja     410d12 <__swc_fn_fc36583a_000146_d2097256+0x372>
  410d0c:	vcomisd xmm7,xmm1
  410d10:	jbe    410d36 <__swc_fn_fc36583a_000146_d2097256+0x396>
  410d12:	vxorpd xmm0,xmm0,xmm0
  410d16:	vcomisd xmm0,xmm1
  410d1a:	jbe    410d2b <__swc_fn_fc36583a_000146_d2097256+0x38b>
  410d1c:	mov    DWORD PTR [rcx],0x666e692d
  410d22:	mov    BYTE PTR [rcx+0x4],0x0
  410d26:	jmp    4112f8 <__swc_fn_fc36583a_000146_d2097256+0x958>
  410d2b:	mov    DWORD PTR [rcx],0x666e69
  410d31:	jmp    4112f8 <__swc_fn_fc36583a_000146_d2097256+0x958>
  410d36:	vcomisd xmm1,xmm8
  410d3b:	jae    410d47 <__swc_fn_fc36583a_000146_d2097256+0x3a7>
  410d3d:	vcomisd xmm9,xmm1
  410d41:	jbe    4110be <__swc_fn_fc36583a_000146_d2097256+0x71e>
  410d47:	vmovups xmm0,xmm1
  410d4b:	vxorpd xmm2,xmm2,xmm2
  410d4f:	vcomisd xmm2,xmm1
  410d53:	jbe    410d63 <__swc_fn_fc36583a_000146_d2097256+0x3c3>
  410d55:	vmovsd xmm1,xmm1,xmm0
  410d59:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x27ef]        # 413550 <__swc_rdata_base_fc36583a+0x440>
  410d61:	jmp    410d67 <__swc_fn_fc36583a_000146_d2097256+0x3c7>
  410d63:	vmovsd xmm1,xmm1,xmm0
  410d67:	xor    r8d,r8d
  410d6a:	vcomisd xmm1,xmm15
  410d6f:	jb     410d90 <__swc_fn_fc36583a_000146_d2097256+0x3f0>
  410d71:	cs nop WORD PTR [rax+rax*1+0x0]
  410d7b:	nop    DWORD PTR [rax+rax*1+0x0]
  410d80:	vdivsd xmm1,xmm1,xmm15
  410d85:	add    r8,0x1
  410d89:	vcomisd xmm1,xmm15
  410d8e:	jae    410d80 <__swc_fn_fc36583a_000146_d2097256+0x3e0>
  410d90:	mov    r9,rcx
  410d93:	vxorpd xmm2,xmm2,xmm2
  410d97:	vcomisd xmm2,xmm0
  410d9b:	jbe    410da4 <__swc_fn_fc36583a_000146_d2097256+0x404>
  410d9d:	mov    BYTE PTR [rcx],0x2d
  410da0:	lea    r9,[rcx+0x1]
  410da4:	vcvttsd2si rdx,xmm1
  410da9:	mov    r10b,dl
  410dac:	add    r10b,0x30
  410db0:	mov    BYTE PTR [r9],r10b
  410db3:	vxorpd xmm0,xmm0,xmm0
  410db7:	movzx  edx,dl
  410dba:	vcvtsi2sd xmm0,xmm0,rdx
  410dbf:	vsubsd xmm0,xmm1,xmm0
  410dc3:	vmulsd xmm1,xmm0,xmm15
  410dc8:	mov    BYTE PTR [r9+0x1],0x2e
  410dcd:	vcvttsd2si rdx,xmm1
  410dd2:	mov    r10b,dl
  410dd5:	add    r10b,0x30
  410dd9:	mov    BYTE PTR [r9+0x2],r10b
  410ddd:	vxorpd xmm0,xmm0,xmm0
  410de1:	movzx  edx,dl
  410de4:	vcvtsi2sd xmm0,xmm0,rdx
  410de9:	vsubsd xmm0,xmm1,xmm0
  410ded:	vmulsd xmm1,xmm0,xmm15
  410df2:	vcvttsd2si rdx,xmm1
  410df7:	mov    r10b,dl
  410dfa:	add    r10b,0x30
  410dfe:	mov    BYTE PTR [r9+0x3],r10b
  410e02:	vxorpd xmm0,xmm0,xmm0
  410e06:	movzx  edx,dl
  410e09:	vcvtsi2sd xmm0,xmm0,rdx
  410e0e:	vsubsd xmm0,xmm1,xmm0
  410e12:	vmulsd xmm1,xmm0,xmm15
  410e17:	vcvttsd2si rdx,xmm1
  410e1c:	mov    r10b,dl
  410e1f:	add    r10b,0x30
  410e23:	mov    BYTE PTR [r9+0x4],r10b
  410e27:	vxorpd xmm0,xmm0,xmm0
  410e2b:	movzx  edx,dl
  410e2e:	vcvtsi2sd xmm0,xmm0,rdx
  410e33:	vsubsd xmm0,xmm1,xmm0
  410e37:	vmulsd xmm1,xmm0,xmm15
  410e3c:	vcvttsd2si rdx,xmm1
  410e41:	mov    r10b,dl
  410e44:	add    r10b,0x30
  410e48:	mov    BYTE PTR [r9+0x5],r10b
  410e4c:	vxorpd xmm0,xmm0,xmm0
  410e50:	movzx  edx,dl
  410e53:	vcvtsi2sd xmm0,xmm0,rdx
  410e58:	vsubsd xmm0,xmm1,xmm0
  410e5c:	vmulsd xmm1,xmm0,xmm15
  410e61:	vcvttsd2si rdx,xmm1
  410e66:	mov    r10b,dl
  410e69:	add    r10b,0x30
  410e6d:	mov    BYTE PTR [r9+0x6],r10b
  410e71:	vxorpd xmm0,xmm0,xmm0
  410e75:	movzx  edx,dl
  410e78:	vcvtsi2sd xmm0,xmm0,rdx
  410e7d:	vsubsd xmm0,xmm1,xmm0
  410e81:	vmulsd xmm1,xmm0,xmm15
  410e86:	vcvttsd2si rdx,xmm1
  410e8b:	mov    r10b,dl
  410e8e:	add    r10b,0x30
  410e92:	mov    BYTE PTR [r9+0x7],r10b
  410e96:	vxorpd xmm0,xmm0,xmm0
  410e9a:	movzx  edx,dl
  410e9d:	vcvtsi2sd xmm0,xmm0,rdx
  410ea2:	vsubsd xmm0,xmm1,xmm0
  410ea6:	vmulsd xmm1,xmm0,xmm15
  410eab:	vcvttsd2si rdx,xmm1
  410eb0:	mov    r10b,dl
  410eb3:	add    r10b,0x30
  410eb7:	mov    BYTE PTR [r9+0x8],r10b
  410ebb:	vxorpd xmm0,xmm0,xmm0
  410ebf:	movzx  edx,dl
  410ec2:	vcvtsi2sd xmm0,xmm0,rdx
  410ec7:	vsubsd xmm0,xmm1,xmm0
  410ecb:	vmulsd xmm1,xmm0,xmm15
  410ed0:	vcvttsd2si rdx,xmm1
  410ed5:	mov    r10b,dl
  410ed8:	add    r10b,0x30
  410edc:	mov    BYTE PTR [r9+0x9],r10b
  410ee0:	vxorpd xmm0,xmm0,xmm0
  410ee4:	movzx  edx,dl
  410ee7:	vcvtsi2sd xmm0,xmm0,rdx
  410eec:	vsubsd xmm0,xmm1,xmm0
  410ef0:	vmulsd xmm1,xmm0,xmm15
  410ef5:	vcvttsd2si rdx,xmm1
  410efa:	mov    r10b,dl
  410efd:	add    r10b,0x30
  410f01:	mov    BYTE PTR [r9+0xa],r10b
  410f05:	vxorpd xmm0,xmm0,xmm0
  410f09:	movzx  edx,dl
  410f0c:	vcvtsi2sd xmm0,xmm0,rdx
  410f11:	vsubsd xmm0,xmm1,xmm0
  410f15:	vmulsd xmm1,xmm0,xmm15
  410f1a:	vcvttsd2si rdx,xmm1
  410f1f:	mov    r10b,dl
  410f22:	add    r10b,0x30
  410f26:	mov    BYTE PTR [r9+0xb],r10b
  410f2a:	lea    r10,[r9+0x4]
  410f2e:	vxorpd xmm0,xmm0,xmm0
  410f32:	movzx  edx,dl
  410f35:	vcvtsi2sd xmm0,xmm0,rdx
  410f3a:	vsubsd xmm0,xmm1,xmm0
  410f3e:	vmulsd xmm1,xmm0,xmm15
  410f43:	vcvttsd2si rdx,xmm1
  410f48:	mov    r11b,dl
  410f4b:	add    r11b,0x30
  410f4f:	mov    BYTE PTR [r9+0xc],r11b
  410f53:	vxorpd xmm0,xmm0,xmm0
  410f57:	movzx  edx,dl
  410f5a:	vcvtsi2sd xmm0,xmm0,rdx
  410f5f:	vsubsd xmm0,xmm1,xmm0
  410f63:	vmulsd xmm1,xmm0,xmm15
  410f68:	vcvttsd2si rdx,xmm1
  410f6d:	mov    r11b,dl
  410f70:	add    r11b,0x30
  410f74:	mov    BYTE PTR [r9+0xd],r11b
  410f78:	lea    r10,[r10+0x2]
  410f7c:	vxorpd xmm0,xmm0,xmm0
  410f80:	movzx  edx,dl
  410f83:	vcvtsi2sd xmm0,xmm0,rdx
  410f88:	vsubsd xmm0,xmm1,xmm0
  410f8c:	vmulsd xmm1,xmm0,xmm15
  410f91:	vcvttsd2si rdx,xmm1
  410f96:	mov    r11b,dl
  410f99:	add    r11b,0x30
  410f9d:	mov    BYTE PTR [r9+0xe],r11b
  410fa1:	vxorpd xmm0,xmm0,xmm0
  410fa5:	movzx  edx,dl
  410fa8:	vcvtsi2sd xmm0,xmm0,rdx
  410fad:	vsubsd xmm0,xmm1,xmm0
  410fb1:	vmulsd xmm1,xmm0,xmm15
  410fb6:	vcvttsd2si rdx,xmm1
  410fbb:	mov    r11b,dl
  410fbe:	add    r11b,0x30
  410fc2:	mov    BYTE PTR [r9+0xf],r11b
  410fc6:	lea    r10,[r10+0x2]
  410fca:	lea    r10,[r10+0x2]
  410fce:	lea    r10,[r10+0x2]
  410fd2:	lea    r10,[r10+0x2]
  410fd6:	lea    r10,[r10+0x2]
  410fda:	vxorpd xmm0,xmm0,xmm0
  410fde:	movzx  edx,dl
  410fe1:	vcvtsi2sd xmm0,xmm0,rdx
  410fe6:	vsubsd xmm0,xmm1,xmm0
  410fea:	vmulsd xmm1,xmm0,xmm15
  410fef:	vcvttsd2si rdx,xmm1
  410ff4:	mov    r11b,dl
  410ff7:	add    r11b,0x30
  410ffb:	mov    BYTE PTR [r9+0x10],r11b
  410fff:	vxorpd xmm0,xmm0,xmm0
  411003:	movzx  edx,dl
  411006:	vcvtsi2sd xmm0,xmm0,rdx
  41100b:	vsubsd xmm0,xmm1,xmm0
  41100f:	vmulsd xmm1,xmm0,xmm15
  411014:	vcvttsd2si rdx,xmm1
  411019:	add    dl,0x30
  41101c:	mov    BYTE PTR [r9+0x11],dl
  411020:	mov    BYTE PTR [r10+0x2],0x65
  411025:	lea    r9,[r10+0x3]
  411029:	test   r8,r8
  41102c:	jl     411035 <__swc_fn_fc36583a_000146_d2097256+0x695>
  41102e:	mov    BYTE PTR [r9],0x2b
  411032:	inc    r9
  411035:	mov    r10,r9
  411038:	mov    rdx,r8
  41103b:	nop    DWORD PTR [rax+rax*1+0x0]
  411040:	mov    r11,rdx
  411043:	movabs rdx,0x6666666666666667
  41104d:	mov    rax,r11
  411050:	imul   rdx
  411053:	sar    rdx,0x2
  411057:	mov    r12,rdx
  41105a:	shr    rdx,0x3f
  41105e:	add    r12,rdx
  411061:	mov    rdx,r12
  411064:	imul   r13,r12,0xa
  411068:	sub    r11,r13
  41106b:	mov    r13,QWORD PTR [rip+0x24ce]        # 413540 <__swc_rdata_base_fc36583a+0x430>
  411072:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411077:	mov    BYTE PTR [r10],r11b
  41107a:	lea    r11,[r10+0x1]
  41107e:	mov    r10,r11
  411081:	test   r12,r12
  411084:	jne    411040 <__swc_fn_fc36583a_000146_d2097256+0x6a0>
  411086:	test   r8,r8
  411089:	jge    411093 <__swc_fn_fc36583a_000146_d2097256+0x6f3>
  41108b:	mov    BYTE PTR [r11],0x2d
  41108f:	lea    r10,[r11+0x1]
  411093:	mov    BYTE PTR [r10],0x0
  411097:	sub    r10,0x1
  41109b:	nop    DWORD PTR [rax+rax*1+0x0]
  4110a0:	cmp    r9,r10
  4110a3:	jae    4112f8 <__swc_fn_fc36583a_000146_d2097256+0x958>
  4110a9:	mov    al,BYTE PTR [r10]
  4110ac:	mov    dl,BYTE PTR [r9]
  4110af:	mov    BYTE PTR [r10],dl
  4110b2:	sub    r10,0x1
  4110b6:	mov    BYTE PTR [r9],al
  4110b9:	inc    r9
  4110bc:	jmp    4110a0 <__swc_fn_fc36583a_000146_d2097256+0x700>
  4110be:	vcvttsd2si rdx,xmm1
  4110c3:	mov    r8,rdx
  4110c6:	vxorpd xmm0,xmm0,xmm0
  4110ca:	vcvtsi2sd xmm0,xmm0,rdx
  4110cf:	vsubsd xmm0,xmm1,xmm0
  4110d3:	mov    r9d,0x8
  4110d9:	vxorpd xmm2,xmm2,xmm2
  4110dd:	vcomisd xmm2,xmm0
  4110e1:	jbe    4110eb <__swc_fn_fc36583a_000146_d2097256+0x74b>
  4110e3:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x2465]        # 413550 <__swc_rdata_base_fc36583a+0x440>
  4110eb:	test   r9d,r9d
  4110ee:	je     4110fa <__swc_fn_fc36583a_000146_d2097256+0x75a>
  4110f0:	vmulsd xmm0,xmm0,xmm14
  4110f5:	dec    r9d
  4110f8:	jne    4110f0 <__swc_fn_fc36583a_000146_d2097256+0x750>
  4110fa:	vcvttsd2si r9,xmm0
  4110ff:	mov    r10,r9
  411102:	vxorpd xmm2,xmm2,xmm2
  411106:	vcvtsi2sd xmm2,xmm2,r9
  41110b:	vsubsd xmm0,xmm0,xmm2
  41110f:	vcomisd xmm0,xmm10
  411114:	lea    r9,[r9+0x1]
  411118:	cmova  r10,r9
  41111c:	cmp    r10,0x5f5e100
  411123:	jne    41113c <__swc_fn_fc36583a_000146_d2097256+0x79c>
  411125:	lea    r8,[rdx-0x1]
  411129:	vxorpd xmm0,xmm0,xmm0
  41112d:	vcomisd xmm0,xmm1
  411131:	lea    rdx,[rdx+0x1]
  411135:	cmovbe r8,rdx
  411139:	xor    r10d,r10d
  41113c:	mov    r9,rcx
  41113f:	test   r8,r8
  411142:	jne    411162 <__swc_fn_fc36583a_000146_d2097256+0x7c2>
  411144:	vxorpd xmm0,xmm0,xmm0
  411148:	vcomisd xmm0,xmm1
  41114c:	jbe    411155 <__swc_fn_fc36583a_000146_d2097256+0x7b5>
  41114e:	mov    BYTE PTR [rcx],0x2d
  411151:	lea    r9,[rcx+0x1]
  411155:	mov    BYTE PTR [r9],0x30
  411159:	add    r9,0x1
  41115d:	jmp    4111fb <__swc_fn_fc36583a_000146_d2097256+0x85b>
  411162:	mov    r9,rcx
  411165:	mov    rdx,r8
  411168:	nop    DWORD PTR [rax+rax*1+0x0]
  411170:	mov    r11,rdx
  411173:	movabs rdx,0x6666666666666667
  41117d:	mov    r15,rax
  411180:	mov    rax,r11
  411183:	imul   rdx
  411186:	mov    r12,rdx
  411189:	mov    rax,r15
  41118c:	sar    r12,0x2
  411190:	mov    rdx,r12
  411193:	shr    rdx,0x3f
  411197:	add    r12,rdx
  41119a:	mov    rdx,r12
  41119d:	imul   r13,r12,0xa
  4111a1:	sub    r11,r13
  4111a4:	mov    r13,QWORD PTR [rip+0x2395]        # 413540 <__swc_rdata_base_fc36583a+0x430>
  4111ab:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4111b0:	mov    BYTE PTR [r9],r11b
  4111b3:	lea    r11,[r9+0x1]
  4111b7:	mov    r9,r11
  4111ba:	test   r12,r12
  4111bd:	jne    411170 <__swc_fn_fc36583a_000146_d2097256+0x7d0>
  4111bf:	test   r8,r8
  4111c2:	jge    4111cc <__swc_fn_fc36583a_000146_d2097256+0x82c>
  4111c4:	mov    BYTE PTR [r11],0x2d
  4111c8:	lea    r9,[r11+0x1]
  4111cc:	mov    rdx,r9
  4111cf:	mov    BYTE PTR [r9],0x0
  4111d3:	sub    r9,0x1
  4111d7:	mov    r8,rcx
  4111da:	cmp    r8,r9
  4111dd:	jae    4111f8 <__swc_fn_fc36583a_000146_d2097256+0x858>
  4111df:	nop
  4111e0:	mov    r11b,BYTE PTR [r9]
  4111e3:	mov    r12b,BYTE PTR [r8]
  4111e6:	mov    BYTE PTR [r9],r12b
  4111e9:	sub    r9,0x1
  4111ed:	mov    BYTE PTR [r8],r11b
  4111f0:	inc    r8
  4111f3:	cmp    r8,r9
  4111f6:	jb     4111e0 <__swc_fn_fc36583a_000146_d2097256+0x840>
  4111f8:	mov    r9,rdx
  4111fb:	mov    BYTE PTR [r9],0x2e
  4111ff:	add    r9,0x1
  411203:	xor    r8d,r8d
  411206:	test   r10,r10
  411209:	je     41124f <__swc_fn_fc36583a_000146_d2097256+0x8af>
  41120b:	mov    r11d,0x989680
  411211:	cmp    r10,r11
  411214:	jge    41124f <__swc_fn_fc36583a_000146_d2097256+0x8af>
  411216:	cs nop WORD PTR [rax+rax*1+0x0]
  411220:	inc    r8d
  411223:	movabs rdx,0x6666666666666667
  41122d:	mov    r15,rax
  411230:	mov    rax,r11
  411233:	imul   rdx
  411236:	mov    r11,rdx
  411239:	mov    rax,r15
  41123c:	sar    r11,0x2
  411240:	mov    rdx,r11
  411243:	shr    rdx,0x3f
  411247:	add    r11,rdx
  41124a:	cmp    r10,r11
  41124d:	jl     411220 <__swc_fn_fc36583a_000146_d2097256+0x880>
  41124f:	test   r8d,r8d
  411252:	je     41126d <__swc_fn_fc36583a_000146_d2097256+0x8cd>
  411254:	cs nop WORD PTR [rax+rax*1+0x0]
  41125e:	xchg   ax,ax
  411260:	mov    BYTE PTR [r9],0x30
  411264:	add    r9,0x1
  411268:	dec    r8d
  41126b:	jne    411260 <__swc_fn_fc36583a_000146_d2097256+0x8c0>
  41126d:	mov    r8,r9
  411270:	mov    rdx,r10
  411273:	cs nop WORD PTR [rax+rax*1+0x0]
  41127d:	nop    DWORD PTR [rax]
  411280:	mov    r11,rdx
  411283:	movabs rdx,0x6666666666666667
  41128d:	mov    rax,r11
  411290:	imul   rdx
  411293:	sar    rdx,0x2
  411297:	mov    r12,rdx
  41129a:	shr    rdx,0x3f
  41129e:	add    r12,rdx
  4112a1:	mov    rdx,r12
  4112a4:	imul   r13,r12,0xa
  4112a8:	sub    r11,r13
  4112ab:	mov    r13,QWORD PTR [rip+0x228e]        # 413540 <__swc_rdata_base_fc36583a+0x430>
  4112b2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4112b7:	mov    BYTE PTR [r8],r11b
  4112ba:	lea    r11,[r8+0x1]
  4112be:	mov    r8,r11
  4112c1:	test   r12,r12
  4112c4:	jne    411280 <__swc_fn_fc36583a_000146_d2097256+0x8e0>
  4112c6:	test   r10,r10
  4112c9:	jge    4112d3 <__swc_fn_fc36583a_000146_d2097256+0x933>
  4112cb:	mov    BYTE PTR [r11],0x2d
  4112cf:	lea    r8,[r11+0x1]
  4112d3:	mov    BYTE PTR [r8],0x0
  4112d7:	sub    r8,0x1
  4112db:	cmp    r9,r8
  4112de:	jae    4112f8 <__swc_fn_fc36583a_000146_d2097256+0x958>
  4112e0:	mov    al,BYTE PTR [r8]
  4112e3:	mov    dl,BYTE PTR [r9]
  4112e6:	mov    BYTE PTR [r8],dl
  4112e9:	sub    r8,0x1
  4112ed:	mov    BYTE PTR [r9],al
  4112f0:	inc    r9
  4112f3:	cmp    r9,r8
  4112f6:	jb     4112e0 <__swc_fn_fc36583a_000146_d2097256+0x940>
  4112f8:	xor    eax,eax
  4112fa:	test   rcx,rcx
  4112fd:	je     411330 <__swc_fn_fc36583a_000146_d2097256+0x990>
  4112ff:	mov    rdx,rcx
  411302:	mov    r8b,BYTE PTR [rdx]
  411305:	test   r8b,r8b
  411308:	je     411330 <__swc_fn_fc36583a_000146_d2097256+0x990>
  41130a:	cs nop WORD PTR [rax+rax*1+0x0]
  411314:	cs nop WORD PTR [rax+rax*1+0x0]
  41131e:	xchg   ax,ax
  411320:	add    rdx,0x1
  411324:	add    rax,0x1
  411328:	mov    r8b,BYTE PTR [rdx]
  41132b:	test   r8b,r8b
  41132e:	jne    411320 <__swc_fn_fc36583a_000146_d2097256+0x980>
  411330:	mov    QWORD PTR [rsp+0x240],rcx
  411338:	mov    QWORD PTR [rsp+0x248],rax
  411340:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  411349:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  411352:	lea    rcx,[rsp+0x250]
  41135a:	call   410130 <__swc_fn_fc36583a_000116_3f5cfdef>
  41135f:	jmp    411a65 <__swc_fn_fc36583a_000146_d2097256+0x10c5>
  411364:	lea    rcx,[rsp+0x260]
  41136c:	vxorps xmm0,xmm0,xmm0
  411370:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  411379:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  411382:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  41138b:	vzeroupper
  41138e:	mov    DWORD PTR [rsp+0x2c0],0x0
  411399:	vmovsd xmm0,QWORD PTR [rdx]
  41139d:	vcomisd xmm0,xmm0
  4113a1:	setne  dl
  4113a4:	movzx  edx,dl
  4113a7:	setp   r8b
  4113ab:	movzx  r8d,r8b
  4113af:	or     edx,r8d
  4113b2:	test   dl,dl
  4113b4:	je     4113c1 <__swc_fn_fc36583a_000146_d2097256+0xa21>
  4113b6:	mov    DWORD PTR [rcx],0x6e616e
  4113bc:	jmp    4119c8 <__swc_fn_fc36583a_000146_d2097256+0x1028>
  4113c1:	vcomisd xmm0,xmm11
  4113c6:	ja     4113d7 <__swc_fn_fc36583a_000146_d2097256+0xa37>
  4113c8:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  4113d1:	vcomisd xmm6,xmm0
  4113d5:	jbe    4113fb <__swc_fn_fc36583a_000146_d2097256+0xa5b>
  4113d7:	vxorpd xmm1,xmm1,xmm1
  4113db:	vcomisd xmm1,xmm0
  4113df:	jbe    4113f0 <__swc_fn_fc36583a_000146_d2097256+0xa50>
  4113e1:	mov    DWORD PTR [rcx],0x666e692d
  4113e7:	mov    BYTE PTR [rcx+0x4],0x0
  4113eb:	jmp    4119c8 <__swc_fn_fc36583a_000146_d2097256+0x1028>
  4113f0:	mov    DWORD PTR [rcx],0x666e69
  4113f6:	jmp    4119c8 <__swc_fn_fc36583a_000146_d2097256+0x1028>
  4113fb:	vcomisd xmm0,xmm13
  411400:	jae    41140c <__swc_fn_fc36583a_000146_d2097256+0xa6c>
  411402:	vcomisd xmm12,xmm0
  411406:	jbe    41176e <__swc_fn_fc36583a_000146_d2097256+0xdce>
  41140c:	vmovups xmm1,xmm0
  411410:	vxorpd xmm2,xmm2,xmm2
  411414:	vcomisd xmm2,xmm0
  411418:	jbe    411428 <__swc_fn_fc36583a_000146_d2097256+0xa88>
  41141a:	vmovsd xmm0,xmm0,xmm1
  41141e:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x212a]        # 413550 <__swc_rdata_base_fc36583a+0x440>
  411426:	jmp    41142c <__swc_fn_fc36583a_000146_d2097256+0xa8c>
  411428:	vmovsd xmm0,xmm0,xmm1
  41142c:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  411435:	xor    r8d,r8d
  411438:	vcomisd xmm0,xmm6
  41143c:	jb     41144e <__swc_fn_fc36583a_000146_d2097256+0xaae>
  41143e:	xchg   ax,ax
  411440:	vdivsd xmm0,xmm0,xmm6
  411444:	add    r8,0x1
  411448:	vcomisd xmm0,xmm6
  41144c:	jae    411440 <__swc_fn_fc36583a_000146_d2097256+0xaa0>
  41144e:	mov    r9,rcx
  411451:	vxorpd xmm2,xmm2,xmm2
  411455:	vcomisd xmm2,xmm1
  411459:	jbe    411462 <__swc_fn_fc36583a_000146_d2097256+0xac2>
  41145b:	mov    BYTE PTR [rcx],0x2d
  41145e:	lea    r9,[rcx+0x1]
  411462:	vcvttsd2si rdx,xmm0
  411467:	mov    r10b,dl
  41146a:	add    r10b,0x30
  41146e:	mov    BYTE PTR [r9],r10b
  411471:	vxorpd xmm1,xmm1,xmm1
  411475:	movzx  edx,dl
  411478:	vcvtsi2sd xmm1,xmm1,rdx
  41147d:	vsubsd xmm0,xmm0,xmm1
  411481:	vmulsd xmm0,xmm0,xmm6
  411485:	mov    BYTE PTR [r9+0x1],0x2e
  41148a:	vcvttsd2si rdx,xmm0
  41148f:	mov    r10b,dl
  411492:	add    r10b,0x30
  411496:	mov    BYTE PTR [r9+0x2],r10b
  41149a:	vxorpd xmm1,xmm1,xmm1
  41149e:	movzx  edx,dl
  4114a1:	vcvtsi2sd xmm1,xmm1,rdx
  4114a6:	vsubsd xmm0,xmm0,xmm1
  4114aa:	vmulsd xmm0,xmm0,xmm6
  4114ae:	vcvttsd2si rdx,xmm0
  4114b3:	mov    r10b,dl
  4114b6:	add    r10b,0x30
  4114ba:	mov    BYTE PTR [r9+0x3],r10b
  4114be:	vxorpd xmm1,xmm1,xmm1
  4114c2:	movzx  edx,dl
  4114c5:	vcvtsi2sd xmm1,xmm1,rdx
  4114ca:	vsubsd xmm0,xmm0,xmm1
  4114ce:	vmulsd xmm0,xmm0,xmm6
  4114d2:	vcvttsd2si rdx,xmm0
  4114d7:	mov    r10b,dl
  4114da:	add    r10b,0x30
  4114de:	mov    BYTE PTR [r9+0x4],r10b
  4114e2:	vxorpd xmm1,xmm1,xmm1
  4114e6:	movzx  edx,dl
  4114e9:	vcvtsi2sd xmm1,xmm1,rdx
  4114ee:	vsubsd xmm0,xmm0,xmm1
  4114f2:	vmulsd xmm0,xmm0,xmm6
  4114f6:	vcvttsd2si rdx,xmm0
  4114fb:	mov    r10b,dl
  4114fe:	add    r10b,0x30
  411502:	mov    BYTE PTR [r9+0x5],r10b
  411506:	vxorpd xmm1,xmm1,xmm1
  41150a:	movzx  edx,dl
  41150d:	vcvtsi2sd xmm1,xmm1,rdx
  411512:	vsubsd xmm0,xmm0,xmm1
  411516:	vmulsd xmm0,xmm0,xmm6
  41151a:	vcvttsd2si rdx,xmm0
  41151f:	mov    r10b,dl
  411522:	add    r10b,0x30
  411526:	mov    BYTE PTR [r9+0x6],r10b
  41152a:	vxorpd xmm1,xmm1,xmm1
  41152e:	movzx  edx,dl
  411531:	vcvtsi2sd xmm1,xmm1,rdx
  411536:	vsubsd xmm0,xmm0,xmm1
  41153a:	vmulsd xmm0,xmm0,xmm6
  41153e:	vcvttsd2si rdx,xmm0
  411543:	mov    r10b,dl
  411546:	add    r10b,0x30
  41154a:	mov    BYTE PTR [r9+0x7],r10b
  41154e:	vxorpd xmm1,xmm1,xmm1
  411552:	movzx  edx,dl
  411555:	vcvtsi2sd xmm1,xmm1,rdx
  41155a:	vsubsd xmm0,xmm0,xmm1
  41155e:	vmulsd xmm0,xmm0,xmm6
  411562:	vcvttsd2si rdx,xmm0
  411567:	mov    r10b,dl
  41156a:	add    r10b,0x30
  41156e:	mov    BYTE PTR [r9+0x8],r10b
  411572:	vxorpd xmm1,xmm1,xmm1
  411576:	movzx  edx,dl
  411579:	vcvtsi2sd xmm1,xmm1,rdx
  41157e:	vsubsd xmm0,xmm0,xmm1
  411582:	vmulsd xmm0,xmm0,xmm6
  411586:	vcvttsd2si rdx,xmm0
  41158b:	mov    r10b,dl
  41158e:	add    r10b,0x30
  411592:	mov    BYTE PTR [r9+0x9],r10b
  411596:	vxorpd xmm1,xmm1,xmm1
  41159a:	movzx  edx,dl
  41159d:	vcvtsi2sd xmm1,xmm1,rdx
  4115a2:	vsubsd xmm0,xmm0,xmm1
  4115a6:	vmulsd xmm0,xmm0,xmm6
  4115aa:	vcvttsd2si rdx,xmm0
  4115af:	mov    r10b,dl
  4115b2:	add    r10b,0x30
  4115b6:	mov    BYTE PTR [r9+0xa],r10b
  4115ba:	vxorpd xmm1,xmm1,xmm1
  4115be:	movzx  edx,dl
  4115c1:	vcvtsi2sd xmm1,xmm1,rdx
  4115c6:	vsubsd xmm0,xmm0,xmm1
  4115ca:	vmulsd xmm0,xmm0,xmm6
  4115ce:	vcvttsd2si rdx,xmm0
  4115d3:	mov    r10b,dl
  4115d6:	add    r10b,0x30
  4115da:	mov    BYTE PTR [r9+0xb],r10b
  4115de:	lea    r10,[r9+0x4]
  4115e2:	vxorpd xmm1,xmm1,xmm1
  4115e6:	movzx  edx,dl
  4115e9:	vcvtsi2sd xmm1,xmm1,rdx
  4115ee:	vsubsd xmm0,xmm0,xmm1
  4115f2:	vmulsd xmm0,xmm0,xmm6
  4115f6:	vcvttsd2si rdx,xmm0
  4115fb:	mov    r11b,dl
  4115fe:	add    r11b,0x30
  411602:	mov    BYTE PTR [r9+0xc],r11b
  411606:	vxorpd xmm1,xmm1,xmm1
  41160a:	movzx  edx,dl
  41160d:	vcvtsi2sd xmm1,xmm1,rdx
  411612:	vsubsd xmm0,xmm0,xmm1
  411616:	vmulsd xmm0,xmm0,xmm6
  41161a:	vcvttsd2si rdx,xmm0
  41161f:	mov    r11b,dl
  411622:	add    r11b,0x30
  411626:	mov    BYTE PTR [r9+0xd],r11b
  41162a:	lea    r10,[r10+0x2]
  41162e:	vxorpd xmm1,xmm1,xmm1
  411632:	movzx  edx,dl
  411635:	vcvtsi2sd xmm1,xmm1,rdx
  41163a:	vsubsd xmm0,xmm0,xmm1
  41163e:	vmulsd xmm0,xmm0,xmm6
  411642:	vcvttsd2si rdx,xmm0
  411647:	mov    r11b,dl
  41164a:	add    r11b,0x30
  41164e:	mov    BYTE PTR [r9+0xe],r11b
  411652:	vxorpd xmm1,xmm1,xmm1
  411656:	movzx  edx,dl
  411659:	vcvtsi2sd xmm1,xmm1,rdx
  41165e:	vsubsd xmm0,xmm0,xmm1
  411662:	vmulsd xmm0,xmm0,xmm6
  411666:	vcvttsd2si rdx,xmm0
  41166b:	mov    r11b,dl
  41166e:	add    r11b,0x30
  411672:	mov    BYTE PTR [r9+0xf],r11b
  411676:	lea    r10,[r10+0x2]
  41167a:	lea    r10,[r10+0x2]
  41167e:	lea    r10,[r10+0x2]
  411682:	lea    r10,[r10+0x2]
  411686:	lea    r10,[r10+0x2]
  41168a:	vxorpd xmm1,xmm1,xmm1
  41168e:	movzx  edx,dl
  411691:	vcvtsi2sd xmm1,xmm1,rdx
  411696:	vsubsd xmm0,xmm0,xmm1
  41169a:	vmulsd xmm0,xmm0,xmm6
  41169e:	vcvttsd2si rdx,xmm0
  4116a3:	mov    r11b,dl
  4116a6:	add    r11b,0x30
  4116aa:	mov    BYTE PTR [r9+0x10],r11b
  4116ae:	vxorpd xmm1,xmm1,xmm1
  4116b2:	movzx  edx,dl
  4116b5:	vcvtsi2sd xmm1,xmm1,rdx
  4116ba:	vsubsd xmm0,xmm0,xmm1
  4116be:	vmulsd xmm0,xmm0,xmm6
  4116c2:	vcvttsd2si rdx,xmm0
  4116c7:	add    dl,0x30
  4116ca:	mov    BYTE PTR [r9+0x11],dl
  4116ce:	mov    BYTE PTR [r10+0x2],0x65
  4116d3:	lea    r9,[r10+0x3]
  4116d7:	test   r8,r8
  4116da:	jl     4116e3 <__swc_fn_fc36583a_000146_d2097256+0xd43>
  4116dc:	mov    BYTE PTR [r9],0x2b
  4116e0:	inc    r9
  4116e3:	mov    r10,r9
  4116e6:	mov    rdx,r8
  4116e9:	nop    DWORD PTR [rax+0x0]
  4116f0:	mov    r11,rdx
  4116f3:	movabs rdx,0x6666666666666667
  4116fd:	mov    rax,r11
  411700:	imul   rdx
  411703:	sar    rdx,0x2
  411707:	mov    r12,rdx
  41170a:	shr    rdx,0x3f
  41170e:	add    r12,rdx
  411711:	mov    rdx,r12
  411714:	imul   r13,r12,0xa
  411718:	sub    r11,r13
  41171b:	mov    r13,QWORD PTR [rip+0x1e1e]        # 413540 <__swc_rdata_base_fc36583a+0x430>
  411722:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411727:	mov    BYTE PTR [r10],r11b
  41172a:	lea    r11,[r10+0x1]
  41172e:	mov    r10,r11
  411731:	test   r12,r12
  411734:	jne    4116f0 <__swc_fn_fc36583a_000146_d2097256+0xd50>
  411736:	test   r8,r8
  411739:	jge    411743 <__swc_fn_fc36583a_000146_d2097256+0xda3>
  41173b:	mov    BYTE PTR [r11],0x2d
  41173f:	lea    r10,[r11+0x1]
  411743:	mov    BYTE PTR [r10],0x0
  411747:	sub    r10,0x1
  41174b:	nop    DWORD PTR [rax+rax*1+0x0]
  411750:	cmp    r9,r10
  411753:	jae    4119c8 <__swc_fn_fc36583a_000146_d2097256+0x1028>
  411759:	mov    al,BYTE PTR [r10]
  41175c:	mov    dl,BYTE PTR [r9]
  41175f:	mov    BYTE PTR [r10],dl
  411762:	sub    r10,0x1
  411766:	mov    BYTE PTR [r9],al
  411769:	inc    r9
  41176c:	jmp    411750 <__swc_fn_fc36583a_000146_d2097256+0xdb0>
  41176e:	vcvttsd2si rdx,xmm0
  411773:	mov    r8,rdx
  411776:	vxorpd xmm1,xmm1,xmm1
  41177a:	vcvtsi2sd xmm1,xmm1,rdx
  41177f:	vsubsd xmm1,xmm0,xmm1
  411783:	mov    r9d,0x8
  411789:	vxorpd xmm2,xmm2,xmm2
  41178d:	vcomisd xmm2,xmm1
  411791:	ja     41179e <__swc_fn_fc36583a_000146_d2097256+0xdfe>
  411793:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41179c:	jmp    4117af <__swc_fn_fc36583a_000146_d2097256+0xe0f>
  41179e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1daa]        # 413550 <__swc_rdata_base_fc36583a+0x440>
  4117a6:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  4117af:	test   r9d,r9d
  4117b2:	je     4117c9 <__swc_fn_fc36583a_000146_d2097256+0xe29>
  4117b4:	cs nop WORD PTR [rax+rax*1+0x0]
  4117be:	xchg   ax,ax
  4117c0:	vmulsd xmm1,xmm1,xmm6
  4117c4:	dec    r9d
  4117c7:	jne    4117c0 <__swc_fn_fc36583a_000146_d2097256+0xe20>
  4117c9:	vcvttsd2si r9,xmm1
  4117ce:	mov    r10,r9
  4117d1:	vxorpd xmm2,xmm2,xmm2
  4117d5:	vcvtsi2sd xmm2,xmm2,r9
  4117da:	vsubsd xmm1,xmm1,xmm2
  4117de:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  4117e7:	vcomisd xmm1,xmm6
  4117eb:	lea    r9,[r9+0x1]
  4117ef:	cmova  r10,r9
  4117f3:	cmp    r10,0x5f5e100
  4117fa:	jne    411813 <__swc_fn_fc36583a_000146_d2097256+0xe73>
  4117fc:	lea    r8,[rdx-0x1]
  411800:	vxorpd xmm1,xmm1,xmm1
  411804:	vcomisd xmm1,xmm0
  411808:	lea    rdx,[rdx+0x1]
  41180c:	cmovbe r8,rdx
  411810:	xor    r10d,r10d
  411813:	mov    r9,rcx
  411816:	test   r8,r8
  411819:	jne    411839 <__swc_fn_fc36583a_000146_d2097256+0xe99>
  41181b:	vxorpd xmm1,xmm1,xmm1
  41181f:	vcomisd xmm1,xmm0
  411823:	jbe    41182c <__swc_fn_fc36583a_000146_d2097256+0xe8c>
  411825:	mov    BYTE PTR [rcx],0x2d
  411828:	lea    r9,[rcx+0x1]
  41182c:	mov    BYTE PTR [r9],0x30
  411830:	add    r9,0x1
  411834:	jmp    4118cb <__swc_fn_fc36583a_000146_d2097256+0xf2b>
  411839:	mov    r9,rcx
  41183c:	mov    rdx,r8
  41183f:	nop
  411840:	mov    r11,rdx
  411843:	movabs rdx,0x6666666666666667
  41184d:	mov    r15,rax
  411850:	mov    rax,r11
  411853:	imul   rdx
  411856:	mov    r12,rdx
  411859:	mov    rax,r15
  41185c:	sar    r12,0x2
  411860:	mov    rdx,r12
  411863:	shr    rdx,0x3f
  411867:	add    r12,rdx
  41186a:	mov    rdx,r12
  41186d:	imul   r13,r12,0xa
  411871:	sub    r11,r13
  411874:	mov    r13,QWORD PTR [rip+0x1cc5]        # 413540 <__swc_rdata_base_fc36583a+0x430>
  41187b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411880:	mov    BYTE PTR [r9],r11b
  411883:	lea    r11,[r9+0x1]
  411887:	mov    r9,r11
  41188a:	test   r12,r12
  41188d:	jne    411840 <__swc_fn_fc36583a_000146_d2097256+0xea0>
  41188f:	test   r8,r8
  411892:	jge    41189c <__swc_fn_fc36583a_000146_d2097256+0xefc>
  411894:	mov    BYTE PTR [r11],0x2d
  411898:	lea    r9,[r11+0x1]
  41189c:	mov    rdx,r9
  41189f:	mov    BYTE PTR [r9],0x0
  4118a3:	sub    r9,0x1
  4118a7:	mov    r8,rcx
  4118aa:	cmp    r8,r9
  4118ad:	jae    4118c8 <__swc_fn_fc36583a_000146_d2097256+0xf28>
  4118af:	nop
  4118b0:	mov    r11b,BYTE PTR [r9]
  4118b3:	mov    r12b,BYTE PTR [r8]
  4118b6:	mov    BYTE PTR [r9],r12b
  4118b9:	sub    r9,0x1
  4118bd:	mov    BYTE PTR [r8],r11b
  4118c0:	inc    r8
  4118c3:	cmp    r8,r9
  4118c6:	jb     4118b0 <__swc_fn_fc36583a_000146_d2097256+0xf10>
  4118c8:	mov    r9,rdx
  4118cb:	mov    BYTE PTR [r9],0x2e
  4118cf:	add    r9,0x1
  4118d3:	xor    r8d,r8d
  4118d6:	test   r10,r10
  4118d9:	je     41191f <__swc_fn_fc36583a_000146_d2097256+0xf7f>
  4118db:	mov    r11d,0x989680
  4118e1:	cmp    r10,r11
  4118e4:	jge    41191f <__swc_fn_fc36583a_000146_d2097256+0xf7f>
  4118e6:	cs nop WORD PTR [rax+rax*1+0x0]
  4118f0:	inc    r8d
  4118f3:	movabs rdx,0x6666666666666667
  4118fd:	mov    r15,rax
  411900:	mov    rax,r11
  411903:	imul   rdx
  411906:	mov    r11,rdx
  411909:	mov    rax,r15
  41190c:	sar    r11,0x2
  411910:	mov    rdx,r11
  411913:	shr    rdx,0x3f
  411917:	add    r11,rdx
  41191a:	cmp    r10,r11
  41191d:	jl     4118f0 <__swc_fn_fc36583a_000146_d2097256+0xf50>
  41191f:	test   r8d,r8d
  411922:	je     41193d <__swc_fn_fc36583a_000146_d2097256+0xf9d>
  411924:	cs nop WORD PTR [rax+rax*1+0x0]
  41192e:	xchg   ax,ax
  411930:	mov    BYTE PTR [r9],0x30
  411934:	add    r9,0x1
  411938:	dec    r8d
  41193b:	jne    411930 <__swc_fn_fc36583a_000146_d2097256+0xf90>
  41193d:	mov    r8,r9
  411940:	mov    rdx,r10
  411943:	cs nop WORD PTR [rax+rax*1+0x0]
  41194d:	nop    DWORD PTR [rax]
  411950:	mov    r11,rdx
  411953:	movabs rdx,0x6666666666666667
  41195d:	mov    rax,r11
  411960:	imul   rdx
  411963:	sar    rdx,0x2
  411967:	mov    r12,rdx
  41196a:	shr    rdx,0x3f
  41196e:	add    r12,rdx
  411971:	mov    rdx,r12
  411974:	imul   r13,r12,0xa
  411978:	sub    r11,r13
  41197b:	mov    r13,QWORD PTR [rip+0x1bbe]        # 413540 <__swc_rdata_base_fc36583a+0x430>
  411982:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411987:	mov    BYTE PTR [r8],r11b
  41198a:	lea    r11,[r8+0x1]
  41198e:	mov    r8,r11
  411991:	test   r12,r12
  411994:	jne    411950 <__swc_fn_fc36583a_000146_d2097256+0xfb0>
  411996:	test   r10,r10
  411999:	jge    4119a3 <__swc_fn_fc36583a_000146_d2097256+0x1003>
  41199b:	mov    BYTE PTR [r11],0x2d
  41199f:	lea    r8,[r11+0x1]
  4119a3:	mov    BYTE PTR [r8],0x0
  4119a7:	sub    r8,0x1
  4119ab:	cmp    r9,r8
  4119ae:	jae    4119c8 <__swc_fn_fc36583a_000146_d2097256+0x1028>
  4119b0:	mov    al,BYTE PTR [r8]
  4119b3:	mov    dl,BYTE PTR [r9]
  4119b6:	mov    BYTE PTR [r8],dl
  4119b9:	sub    r8,0x1
  4119bd:	mov    BYTE PTR [r9],al
  4119c0:	inc    r9
  4119c3:	cmp    r9,r8
  4119c6:	jb     4119b0 <__swc_fn_fc36583a_000146_d2097256+0x1010>
  4119c8:	xor    eax,eax
  4119ca:	test   rcx,rcx
  4119cd:	je     4119f0 <__swc_fn_fc36583a_000146_d2097256+0x1050>
  4119cf:	mov    rdx,rcx
  4119d2:	mov    r8b,BYTE PTR [rdx]
  4119d5:	test   r8b,r8b
  4119d8:	je     4119f0 <__swc_fn_fc36583a_000146_d2097256+0x1050>
  4119da:	nop    WORD PTR [rax+rax*1+0x0]
  4119e0:	add    rdx,0x1
  4119e4:	add    rax,0x1
  4119e8:	mov    r8b,BYTE PTR [rdx]
  4119eb:	test   r8b,r8b
  4119ee:	jne    4119e0 <__swc_fn_fc36583a_000146_d2097256+0x1040>
  4119f0:	mov    QWORD PTR [rsp+0x3f8],rcx
  4119f8:	mov    QWORD PTR [rsp+0x400],rax
  411a00:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  411a09:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  411a12:	lea    rcx,[rsp+0x408]
  411a1a:	call   410130 <__swc_fn_fc36583a_000116_3f5cfdef>
  411a1f:	jmp    411a65 <__swc_fn_fc36583a_000146_d2097256+0x10c5>
  411a21:	mov    rcx,rdx
  411a24:	call   410130 <__swc_fn_fc36583a_000116_3f5cfdef>
  411a29:	jmp    411a65 <__swc_fn_fc36583a_000146_d2097256+0x10c5>
  411a2b:	mov    al,BYTE PTR [rdx]
  411a2d:	test   al,al
  411a2f:	je     411a3a <__swc_fn_fc36583a_000146_d2097256+0x109a>
  411a31:	lea    rax,[rip+0x1b28]        # 413560 <__swc_rdata_base_fc36583a+0x450>
  411a38:	jmp    411a41 <__swc_fn_fc36583a_000146_d2097256+0x10a1>
  411a3a:	lea    rax,[rip+0x1b2f]        # 413570 <__swc_rdata_base_fc36583a+0x460>
  411a41:	mov    rcx,rax
  411a44:	call   410130 <__swc_fn_fc36583a_000116_3f5cfdef>
  411a49:	jmp    411a65 <__swc_fn_fc36583a_000146_d2097256+0x10c5>
  411a4b:	lea    rcx,[rip+0x1b2e]        # 413580 <__swc_rdata_base_fc36583a+0x470>
  411a52:	call   410130 <__swc_fn_fc36583a_000116_3f5cfdef>
  411a57:	jmp    411a65 <__swc_fn_fc36583a_000146_d2097256+0x10c5>
  411a59:	lea    rcx,[rip+0x1b20]        # 413580 <__swc_rdata_base_fc36583a+0x470>
  411a60:	call   410130 <__swc_fn_fc36583a_000116_3f5cfdef>
  411a65:	add    rdi,0x1
  411a69:	sub    rsi,0x1
  411a6d:	vmovups xmm0,xmm12
  411a72:	vmovsd xmm6,QWORD PTR [rip+0x1b16]        # 413590 <__swc_rdata_base_fc36583a+0x480>
  411a7a:	test   rsi,rsi
  411a7d:	jne    410ab0 <__swc_fn_fc36583a_000146_d2097256+0x110>
  411a83:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  411a8c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  411a95:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  411a9e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411aa7:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411ab0:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411ab9:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411ac2:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  411acb:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411ad4:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  411add:	add    rsp,0x4e8
  411ae4:	pop    r15
  411ae6:	pop    r13
  411ae8:	pop    r12
  411aea:	pop    rdi
  411aeb:	pop    rsi
  411aec:	pop    rbx
  411aed:	ret
	...

0000000000411af0 <__swc_fn_fc36583a_000149_365b4daf>:
  411af0:	vxorps xmm0,xmm0,xmm0
  411af4:	vmovups XMMWORD PTR [rcx],xmm0
  411af8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411afd:	ret
	...

0000000000411b00 <__swc_fn_fc36583a_000152_365b4daf>:
  411b00:	vxorps xmm0,xmm0,xmm0
  411b04:	vmovups XMMWORD PTR [rcx],xmm0
  411b08:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411b0d:	vxorps xmm0,xmm0,xmm0
  411b11:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411b16:	vmovups xmm0,XMMWORD PTR [rip+0x1b82]        # 4136a0 <__swc_rdata_base_fc36583a+0x590>
  411b1e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411b23:	vxorps xmm0,xmm0,xmm0
  411b27:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411b2c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411b31:	vxorps xmm0,xmm0,xmm0
  411b35:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  411b3a:	mov    QWORD PTR [rcx+0x70],0x0
  411b42:	ret
	...

0000000000411b50 <__swc_fn_fc36583a_000155_365b4daf>:
  411b50:	vxorps xmm0,xmm0,xmm0
  411b54:	vmovups XMMWORD PTR [rcx],xmm0
  411b58:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411b5d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411b62:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411b67:	ret
	...

0000000000411b70 <__swc_fn_fc36583a_000158_31e09513>:
  411b70:	push   rsi
  411b71:	push   rdi
  411b72:	sub    rsp,0x8
  411b76:	mov    rsi,rcx
  411b79:	mov    rdi,QWORD PTR [rsi+0x50]
  411b7d:	test   rdi,rdi
  411b80:	je     411b87 <__swc_fn_fc36583a_000158_31e09513+0x17>
  411b82:	mov    rcx,rsi
  411b85:	call   rdi
  411b87:	mov    QWORD PTR [rsi+0x20],0x0
  411b8f:	mov    rax,QWORD PTR [rsi+0x30]
  411b93:	test   rax,rax
  411b96:	je     411bc4 <__swc_fn_fc36583a_000158_31e09513+0x54>
  411b98:	nop    DWORD PTR [rax+rax*1+0x0]
  411ba0:	mov    rdi,QWORD PTR [rax+0x8]
  411ba4:	mov    rcx,rsi
  411ba7:	mov    rdx,QWORD PTR [rax+0x10]
  411bab:	mov    rax,QWORD PTR [rax+0x18]
  411baf:	mov    r8,rax
  411bb2:	call   409e90 <__swc_fn_fc36583a_000156_9e2052d6>
  411bb7:	mov    QWORD PTR [rsi+0x30],rdi
  411bbb:	mov    rax,QWORD PTR [rsi+0x30]
  411bbf:	test   rax,rax
  411bc2:	jne    411ba0 <__swc_fn_fc36583a_000158_31e09513+0x30>
  411bc4:	mov    QWORD PTR [rsi+0x38],0x0
  411bcc:	add    rsp,0x8
  411bd0:	pop    rdi
  411bd1:	pop    rsi
  411bd2:	ret
	...

0000000000411be0 <__swc_fn_fc36583a_000161_b553c03d>:
  411be0:	push   rbx
  411be1:	push   rsi
  411be2:	push   rdi
  411be3:	push   r12
  411be5:	sub    rsp,0x188
  411bec:	mov    rbx,rcx
  411bef:	lea    rsi,[rip+0x1519a]        # 426d90 <__swc_bss_base_fc36583a+0x2d50>
  411bf6:	mov    rcx,rsi
  411bf9:	call   4098a0 <__swc_fn_fc36583a_000135_db32cc57>
  411bfe:	mov    rax,QWORD PTR [rip+0x15193]        # 426d98 <__swc_bss_base_fc36583a+0x2d58>
  411c05:	mov    rdi,rax
  411c08:	test   rdi,rdi
  411c0b:	je     411c39 <__swc_fn_fc36583a_000161_b553c03d+0x59>
  411c0d:	nop    DWORD PTR [rax]
  411c10:	cmp    QWORD PTR [rdi+0x8],rbx
  411c14:	jne    411c2e <__swc_fn_fc36583a_000161_b553c03d+0x4e>
  411c16:	mov    rcx,rsi
  411c19:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  411c1e:	mov    rax,rdi
  411c21:	add    rsp,0x188
  411c28:	pop    r12
  411c2a:	pop    rdi
  411c2b:	pop    rsi
  411c2c:	pop    rbx
  411c2d:	ret
  411c2e:	mov    rax,QWORD PTR [rdi]
  411c31:	mov    rdi,rax
  411c34:	test   rax,rax
  411c37:	jne    411c10 <__swc_fn_fc36583a_000161_b553c03d+0x30>
  411c39:	call   40d640 <__swc_fn_fc36583a_000139_e4a7a8b1>
  411c3e:	mov    rdi,rax
  411c41:	test   rax,rax
  411c44:	jne    411c5d <__swc_fn_fc36583a_000161_b553c03d+0x7d>
  411c46:	mov    rcx,rsi
  411c49:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  411c4e:	xor    eax,eax
  411c50:	add    rsp,0x188
  411c57:	pop    r12
  411c59:	pop    rdi
  411c5a:	pop    rsi
  411c5b:	pop    rbx
  411c5c:	ret
  411c5d:	lea    rax,[rsp+0x18]
  411c62:	mov    QWORD PTR [rax+0x10],0x0
  411c6a:	mov    QWORD PTR [rax+0x18],0x0
  411c72:	mov    DWORD PTR [rax+0x20],0x0
  411c79:	mov    BYTE PTR [rax+0x24],0x0
  411c7d:	mov    rax,QWORD PTR [rip+0x15114]        # 426d98 <__swc_bss_base_fc36583a+0x2d58>
  411c84:	mov    QWORD PTR [rsp+0x18],rax
  411c89:	mov    QWORD PTR [rsp+0x20],rbx
  411c8e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411c94:	vmovups XMMWORD PTR [rdi],xmm0
  411c98:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  411c9e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  411ca3:	mov    rax,QWORD PTR [rsp+0x38]
  411ca8:	mov    QWORD PTR [rdi+0x20],rax
  411cac:	mov    QWORD PTR [rip+0x150e5],rdi        # 426d98 <__swc_bss_base_fc36583a+0x2d58>
  411cb3:	lea    rax,[rsp+0x40]
  411cb8:	mov    QWORD PTR [rax],0x0
  411cbf:	mov    rcx,rbx
  411cc2:	mov    rdx,rax
  411cc5:	call   409980 <__swc_fn_fc36583a_000141_5e493395>
  411cca:	mov    rbx,rax
  411ccd:	test   rax,rax
  411cd0:	jne    411cea <__swc_fn_fc36583a_000161_b553c03d+0x10a>
  411cd2:	mov    rcx,rsi
  411cd5:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  411cda:	mov    rax,rdi
  411cdd:	add    rsp,0x188
  411ce4:	pop    r12
  411ce6:	pop    rdi
  411ce7:	pop    rsi
  411ce8:	pop    rbx
  411ce9:	ret
  411cea:	lea    r12,[rsp+0x50]
  411cef:	mov    QWORD PTR [r12],0x0
  411cf7:	mov    rcx,rbx
  411cfa:	mov    rdx,QWORD PTR [rsp+0x40]
  411cff:	mov    r8,r12
  411d02:	call   40d6f0 <__swc_fn_fc36583a_000142_89a6ef72>
  411d07:	test   rax,rax
  411d0a:	jne    411d24 <__swc_fn_fc36583a_000161_b553c03d+0x144>
  411d0c:	mov    rcx,rsi
  411d0f:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  411d14:	mov    rax,rdi
  411d17:	add    rsp,0x188
  411d1e:	pop    r12
  411d20:	pop    rdi
  411d21:	pop    rsi
  411d22:	pop    rbx
  411d23:	ret
  411d24:	cmp    QWORD PTR [r12],0x10
  411d29:	jb     411e2c <__swc_fn_fc36583a_000161_b553c03d+0x24c>
  411d2f:	mov    ecx,DWORD PTR [rax]
  411d31:	cmp    ecx,0x42445753
  411d37:	jne    411e2c <__swc_fn_fc36583a_000161_b553c03d+0x24c>
  411d3d:	mov    ecx,DWORD PTR [rax+0x4]
  411d40:	cmp    ecx,0x1
  411d43:	jne    411e2c <__swc_fn_fc36583a_000161_b553c03d+0x24c>
  411d49:	mov    ecx,DWORD PTR [rax+0x8]
  411d4c:	mov    edx,DWORD PTR [rax+0xc]
  411d4f:	imul   r8,rcx,0x14
  411d53:	mov    r9,QWORD PTR [rsp+0x50]
  411d58:	sub    r9,0x10
  411d5c:	cmp    r8,r9
  411d5f:	ja     411e2c <__swc_fn_fc36583a_000161_b553c03d+0x24c>
  411d65:	lea    r8,[r8+0x10]
  411d69:	cmp    rdx,r8
  411d6c:	jb     411e2c <__swc_fn_fc36583a_000161_b553c03d+0x24c>
  411d72:	mov    r8,QWORD PTR [rsp+0x50]
  411d77:	cmp    rdx,r8
  411d7a:	ja     411e2c <__swc_fn_fc36583a_000161_b553c03d+0x24c>
  411d80:	xor    r8d,r8d
  411d83:	test   rcx,rcx
  411d86:	jbe    411e52 <__swc_fn_fc36583a_000161_b553c03d+0x272>
  411d8c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  411d92:	cs nop WORD PTR [rax+rax*1+0x0]
  411d9c:	nop    DWORD PTR [rax+0x0]
  411da0:	imul   r9,r8,0x14
  411da4:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  411da9:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  411dae:	add    r10,r11
  411db1:	movabs r11,0x100000000
  411dbb:	cmp    r10,r11
  411dbe:	ja     411e2c <__swc_fn_fc36583a_000161_b553c03d+0x24c>
  411dc0:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  411dc5:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  411dca:	test   r10d,r10d
  411dcd:	setne  r11b
  411dd1:	je     411deb <__swc_fn_fc36583a_000161_b553c03d+0x20b>
  411dd3:	cmp    r10d,edx
  411dd6:	setb   r11b
  411dda:	jb     411deb <__swc_fn_fc36583a_000161_b553c03d+0x20b>
  411ddc:	vmovq  r11,xmm1
  411de1:	cmp    r10,r11
  411de4:	setae  r10b
  411de8:	mov    r11b,r10b
  411deb:	mov    r10,r11
  411dee:	test   r11b,r11b
  411df1:	jne    411e18 <__swc_fn_fc36583a_000161_b553c03d+0x238>
  411df3:	test   r9d,r9d
  411df6:	setne  r10b
  411dfa:	je     411e18 <__swc_fn_fc36583a_000161_b553c03d+0x238>
  411dfc:	cmp    r9d,edx
  411dff:	setb   r10b
  411e03:	jb     411e18 <__swc_fn_fc36583a_000161_b553c03d+0x238>
  411e05:	vmovq  r10,xmm1
  411e0a:	cmp    r9,r10
  411e0d:	setae  r9b
  411e11:	movzx  r9d,r9b
  411e15:	mov    r10b,r9b
  411e18:	test   r10b,r10b
  411e1b:	jne    411e2c <__swc_fn_fc36583a_000161_b553c03d+0x24c>
  411e1d:	add    r8,0x1
  411e21:	cmp    r8,rcx
  411e24:	jb     411da0 <__swc_fn_fc36583a_000161_b553c03d+0x1c0>
  411e2a:	jmp    411e52 <__swc_fn_fc36583a_000161_b553c03d+0x272>
  411e2c:	xor    ecx,ecx
  411e2e:	cmp    rax,rbx
  411e31:	cmovne rcx,rax
  411e35:	call   4108f0 <__swc_fn_fc36583a_000143_b7ad855f>
  411e3a:	mov    rcx,rsi
  411e3d:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  411e42:	mov    rax,rdi
  411e45:	add    rsp,0x188
  411e4c:	pop    r12
  411e4e:	pop    rdi
  411e4f:	pop    rsi
  411e50:	pop    rbx
  411e51:	ret
  411e52:	mov    QWORD PTR [rdi+0x10],rax
  411e56:	mov    rcx,QWORD PTR [rsp+0x50]
  411e5b:	mov    QWORD PTR [rdi+0x18],rcx
  411e5f:	mov    eax,DWORD PTR [rax+0x8]
  411e62:	mov    DWORD PTR [rdi+0x20],eax
  411e65:	rex mov BYTE PTR [rdi+0x24],0x1
  411e6a:	mov    rcx,rsi
  411e6d:	call   40d630 <__swc_fn_fc36583a_000136_d579ef75>
  411e72:	mov    rax,rdi
  411e75:	add    rsp,0x188
  411e7c:	pop    r12
  411e7e:	pop    rdi
  411e7f:	pop    rsi
  411e80:	pop    rbx
  411e81:	ret
	...

0000000000411e90 <__swc_fn_fc36583a_000164_d25850aa>:
  411e90:	push   rsi
  411e91:	push   rdi
  411e92:	push   r12
  411e94:	mov    rsi,rdx
  411e97:	mov    rdi,rcx
  411e9a:	mov    rcx,QWORD PTR [rip+0x14e9f]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  411ea1:	test   rcx,rcx
  411ea4:	jne    411eb6 <__swc_fn_fc36583a_000164_d25850aa+0x26>
  411ea6:	call   40a1a0 <__swc_fn_fc36583a_000165_56054fe7>
  411eab:	lea    rcx,[rax+0x1]
  411eaf:	mov    QWORD PTR [rip+0x14e8a],rcx        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  411eb6:	dec    rcx
  411eb9:	call   411ee0 <__swc_fn_fc36583a_000167_39c041ad>
  411ebe:	mov    r12,QWORD PTR [rax+0xbe0]
  411ec5:	test   r12,r12
  411ec8:	setne  al
  411ecb:	je     411ed6 <__swc_fn_fc36583a_000164_d25850aa+0x46>
  411ecd:	mov    rcx,rdi
  411ed0:	mov    rdx,rsi
  411ed3:	call   r12
  411ed6:	pop    r12
  411ed8:	pop    rdi
  411ed9:	pop    rsi
  411eda:	ret
  411edb:	add    BYTE PTR [rax],al
  411edd:	add    BYTE PTR [rax],al
	...

0000000000411ee0 <__swc_fn_fc36583a_000167_39c041ad>:
  411ee0:	push   r12
  411ee2:	push   rdi
  411ee3:	push   rsi
  411ee4:	sub    rsp,0xd0
  411eeb:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  411ef1:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  411ef7:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  411efd:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  411f03:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  411f09:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  411f0f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  411f18:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  411f21:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  411f2a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  411f33:	mov    r12,rcx
  411f36:	mov    edi,ecx
  411f38:	xor    eax,eax
  411f3a:	call   407000 <pthread_getspecific@plt>
  411f3f:	test   rax,rax
  411f42:	je     411f46 <__swc_fn_fc36583a_000167_39c041ad+0x66>
  411f44:	jmp    411f4e <__swc_fn_fc36583a_000167_39c041ad+0x6e>
  411f46:	mov    rcx,r12
  411f49:	call   40a200 <__swc_fn_fc36583a_000168_0ad81c51>
  411f4e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  411f54:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  411f5a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  411f60:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  411f66:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  411f6c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  411f72:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  411f7b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  411f84:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  411f8d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  411f96:	add    rsp,0xd0
  411f9d:	pop    rsi
  411f9e:	pop    rdi
  411f9f:	pop    r12
  411fa1:	ret
	...

0000000000411fb0 <__swc_fn_fc36583a_000170_4dbacba0>:
  411fb0:	push   rsi
  411fb1:	sub    rsp,0x30
  411fb5:	lea    rsi,[rip+0x14dec]        # 426da8 <__swc_bss_base_fc36583a+0x2d68>
  411fbc:	mov    rax,QWORD PTR [rsi]
  411fbf:	test   rax,rax
  411fc2:	je     411fca <__swc_fn_fc36583a_000170_4dbacba0+0x1a>
  411fc4:	add    rsp,0x30
  411fc8:	pop    rsi
  411fc9:	ret
  411fca:	mov    ecx,0x3
  411fcf:	mov    edx,0x10
  411fd4:	call   40fa50 <__swc_fn_fc36583a_000107_c8d4a68e>
  411fd9:	test   rax,rax
  411fdc:	jne    411fed <__swc_fn_fc36583a_000170_4dbacba0+0x3d>
  411fde:	mov    QWORD PTR [rsp+0x18],rax
  411fe3:	call   40d190 <__swc_fn_fc36583a_000118_591530fe>
  411fe8:	mov    rax,QWORD PTR [rsp+0x18]
  411fed:	mov    rcx,rax
  411ff0:	xchg   QWORD PTR [rsi],rcx
  411ff3:	add    rsp,0x30
  411ff7:	pop    rsi
  411ff8:	ret
  411ff9:	add    BYTE PTR [rax],al
  411ffb:	add    BYTE PTR [rax],al
  411ffd:	add    BYTE PTR [rax],al
	...

0000000000412000 <__swc_fn_fc36583a_000173_e17a224b>:
  412000:	push   rsi
  412001:	push   rdi
  412002:	sub    rsp,0x8
  412006:	mov    rsi,rdx
  412009:	mov    rdi,rcx
  41200c:	mov    rax,QWORD PTR [rsi+0x8]
  412010:	test   rax,rax
  412013:	je     41201d <__swc_fn_fc36583a_000173_e17a224b+0x1d>
  412015:	mov    rcx,QWORD PTR [rsi]
  412018:	mov    QWORD PTR [rax],rcx
  41201b:	jmp    412024 <__swc_fn_fc36583a_000173_e17a224b+0x24>
  41201d:	mov    rax,QWORD PTR [rsi]
  412020:	mov    QWORD PTR [rdi+0x8],rax
  412024:	mov    rax,QWORD PTR [rsi]
  412027:	test   rax,rax
  41202a:	je     412034 <__swc_fn_fc36583a_000173_e17a224b+0x34>
  41202c:	mov    rcx,QWORD PTR [rsi+0x8]
  412030:	mov    QWORD PTR [rax+0x8],rcx
  412034:	mov    rcx,rdi
  412037:	mov    rdx,QWORD PTR [rsi+0x10]
  41203b:	mov    r8,QWORD PTR [rsi+0x18]
  41203f:	mov    r9,0xffffffffffffffff
  412046:	call   40dd40 <__swc_fn_fc36583a_000172_1751ecdd>
  41204b:	mov    QWORD PTR [rsi+0x18],0x0
  412053:	mov    rax,QWORD PTR [rdi+0x8]
  412057:	test   rax,rax
  41205a:	jne    41206c <__swc_fn_fc36583a_000173_e17a224b+0x6c>
  41205c:	call   411fb0 <__swc_fn_fc36583a_000170_4dbacba0>
  412061:	xor    ecx,ecx
  412063:	mov    QWORD PTR [rax+0x8],rcx
  412067:	xor    ecx,ecx
  412069:	mov    QWORD PTR [rax],rcx
  41206c:	add    rsp,0x8
  412070:	pop    rdi
  412071:	pop    rsi
  412072:	ret
	...

0000000000412080 <__swc_fn_fc36583a_000176_1ca87929>:
  412080:	push   rdi
  412081:	push   rsi
  412082:	sub    rsp,0xb8
  412089:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41208f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  412095:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41209b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4120a1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4120a7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4120ad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4120b3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4120bc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4120c5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4120ce:	vxorps xmm0,xmm0,xmm0
  4120d2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4120d8:	mov    edi,0x1
  4120dd:	lea    rsi,[rsp+0x8]
  4120e2:	xor    eax,eax
  4120e4:	call   4071d0 <clock_gettime@plt>
  4120e9:	vxorpd xmm0,xmm0,xmm0
  4120ed:	mov    rax,QWORD PTR [rsp+0x8]
  4120f2:	vcvtsi2sd xmm0,xmm0,rax
  4120f7:	vxorpd xmm1,xmm1,xmm1
  4120fb:	mov    rax,QWORD PTR [rsp+0x10]
  412100:	vcvtsi2sd xmm1,xmm1,rax
  412105:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x17fb]        # 413908 <__swc_rdata_base_fc36583a+0x7f8>
  41210d:	vaddsd xmm0,xmm0,xmm1
  412111:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  412117:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  41211d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  412123:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  412129:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  41212f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  412135:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41213b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  412144:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  41214d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  412156:	add    rsp,0xb8
  41215d:	pop    rsi
  41215e:	pop    rdi
  41215f:	ret
