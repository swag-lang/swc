Generated field kit archive.
