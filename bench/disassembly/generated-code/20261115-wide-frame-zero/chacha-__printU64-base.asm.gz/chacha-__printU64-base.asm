
/workspace/prompt2-20261115/batch5-final-micro/base/chacha/chacha:     file format elf64-x86-64


Disassembly of section .text:

0000000000409cd0 <__swc_fn_3464c816_000144_34d6a3dc>:
  409cd0:	push   rbx
  409cd1:	sub    rsp,0xe0
  409cd8:	lea    rbx,[rsp+0x8]
  409cdd:	vxorps xmm0,xmm0,xmm0
  409ce1:	vmovups XMMWORD PTR [rbx],xmm0
  409ce5:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409cea:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409cef:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  409cf4:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  409cf9:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  409cfe:	mov    DWORD PTR [rbx+0x60],0x0
  409d05:	mov    r8,rbx
  409d08:	nop    DWORD PTR [rax+rax*1+0x0]
  409d10:	mov    r9,rcx
  409d13:	movabs rcx,0xcccccccccccccccd
  409d1d:	mov    rax,r9
  409d20:	mul    rcx
  409d23:	mov    r10,rdx
  409d26:	shr    r10,0x3
  409d2a:	mov    rcx,r10
  409d2d:	imul   rdx,r10,0xa
  409d31:	sub    r9,rdx
  409d34:	mov    rdx,QWORD PTR [rip+0x9805]        # 413540 <__swc_rdata_base_3464c816+0x430>
  409d3b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  409d40:	mov    BYTE PTR [r8],dl
  409d43:	lea    rdx,[r8+0x1]
  409d47:	mov    r8,rdx
  409d4a:	test   r10,r10
  409d4d:	jne    409d10 <__swc_fn_3464c816_000144_34d6a3dc+0x40>
  409d4f:	mov    BYTE PTR [rdx],0x0
  409d52:	sub    r8,0x1
  409d56:	mov    rax,rbx
  409d59:	cmp    rax,r8
  409d5c:	jae    409d76 <__swc_fn_3464c816_000144_34d6a3dc+0xa6>
  409d5e:	xchg   ax,ax
  409d60:	mov    cl,BYTE PTR [r8]
  409d63:	mov    dl,BYTE PTR [rax]
  409d65:	mov    BYTE PTR [r8],dl
  409d68:	sub    r8,0x1
  409d6c:	mov    BYTE PTR [rax],cl
  409d6e:	inc    rax
  409d71:	cmp    rax,r8
  409d74:	jb     409d60 <__swc_fn_3464c816_000144_34d6a3dc+0x90>
  409d76:	xor    eax,eax
  409d78:	test   rbx,rbx
  409d7b:	je     409d9e <__swc_fn_3464c816_000144_34d6a3dc+0xce>
  409d7d:	mov    rcx,rbx
  409d80:	mov    dl,BYTE PTR [rcx]
  409d82:	test   dl,dl
  409d84:	je     409d9e <__swc_fn_3464c816_000144_34d6a3dc+0xce>
  409d86:	cs nop WORD PTR [rax+rax*1+0x0]
  409d90:	add    rcx,0x1
  409d94:	add    rax,0x1
  409d98:	mov    dl,BYTE PTR [rcx]
  409d9a:	test   dl,dl
  409d9c:	jne    409d90 <__swc_fn_3464c816_000144_34d6a3dc+0xc0>
  409d9e:	mov    QWORD PTR [rbx+0xa8],rbx
  409da5:	mov    QWORD PTR [rbx+0xb0],rax
  409dac:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  409db4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  409dbc:	lea    rcx,[rbx+0xb8]
  409dc3:	call   410100 <__swc_fn_3464c816_000116_18ca1307>
  409dc8:	add    rsp,0xe0
  409dcf:	pop    rbx
  409dd0:	ret
