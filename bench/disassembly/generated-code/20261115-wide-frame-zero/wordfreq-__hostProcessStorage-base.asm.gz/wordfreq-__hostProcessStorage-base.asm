
/workspace/prompt2-20261115/batch5-final-micro/base/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

00000000004091c0 <__swc_fn_4fa09e82_000108_4f8da17c>:
  4091c0:	push   rbx
  4091c1:	push   r12
  4091c3:	push   rdi
  4091c4:	push   rsi
  4091c5:	push   r13
  4091c7:	push   r14
  4091c9:	push   r15
  4091cb:	sub    rsp,0x170
  4091d2:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  4091db:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  4091e4:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  4091ed:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  4091f6:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  4091ff:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  409208:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  409211:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40921a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  409223:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40922c:	mov    ebx,edx
  40922e:	mov    QWORD PTR [rsp+0xa8],rbx
  409236:	mov    r12d,ecx
  409239:	test   edx,edx
  40923b:	jne    409252 <__swc_fn_4fa09e82_000108_4f8da17c+0x92>
  40923d:	xor    eax,eax
  40923f:	add    rsp,0x170
  409246:	pop    r15
  409248:	pop    r14
  40924a:	pop    r13
  40924c:	pop    rsi
  40924d:	pop    rdi
  40924e:	pop    r12
  409250:	pop    rbx
  409251:	ret
  409252:	lea    rdi,[rip+0xa257]        # 4134b0 <__swc_rdata_base_4fa09e82+0x3a0>
  409259:	mov    esi,0x90000
  40925e:	xor    eax,eax
  409260:	call   407010 <open@plt>
  409265:	mov    r13,rax
  409268:	mov    QWORD PTR [rsp+0xb0],rax
  409270:	test   eax,eax
  409272:	jge    40927b <__swc_fn_4fa09e82_000108_4f8da17c+0xbb>
  409274:	xor    eax,eax
  409276:	jmp    409796 <__swc_fn_4fa09e82_000108_4f8da17c+0x5d6>
  40927b:	nop    DWORD PTR [rax+rax*1+0x0]
  409280:	movsxd rdi,r13d
  409283:	mov    esi,0x2
  409288:	xor    eax,eax
  40928a:	call   407020 <flock@plt>
  40928f:	test   eax,eax
  409291:	je     4092b0 <__swc_fn_4fa09e82_000108_4f8da17c+0xf0>
  409293:	xor    eax,eax
  409295:	call   407030 <__errno_location@plt>
  40929a:	cmp    DWORD PTR [rax],0x4
  40929d:	je     409280 <__swc_fn_4fa09e82_000108_4f8da17c+0xc0>
  40929f:	movsxd rdi,r13d
  4092a2:	xor    eax,eax
  4092a4:	call   407040 <close@plt>
  4092a9:	xor    eax,eax
  4092ab:	jmp    409796 <__swc_fn_4fa09e82_000108_4f8da17c+0x5d6>
  4092b0:	lea    r14,[rsp+0x8]
  4092b5:	mov    QWORD PTR [rsp+0xb8],r14
  4092bd:	vxorps xmm0,xmm0,xmm0
  4092c1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4092c7:	mov    QWORD PTR [rsp+0x18],0x0
  4092d0:	mov    WORD PTR [rsp+0x20],0x0
  4092d7:	mov    DWORD PTR [r14],0x67617753
  4092de:	mov    DWORD PTR [r14+0x4],0x2e74522e
  4092e6:	xor    eax,eax
  4092e8:	call   407050 <getpid@plt>
  4092ed:	mov    ecx,eax
  4092ef:	mov    eax,0x1c
  4092f4:	shrx   eax,ecx,eax
  4092f9:	and    eax,0xf
  4092fc:	mov    rdx,QWORD PTR [rip+0xa1cd]        # 4134d0 <__swc_rdata_base_4fa09e82+0x3c0>
  409303:	mov    al,BYTE PTR [rdx+rax*1]
  409306:	rex mov BYTE PTR [rsp+0x10],al
  40930b:	mov    eax,0x1c
  409310:	shrx   eax,r12d,eax
  409315:	and    eax,0xf
  409318:	mov    al,BYTE PTR [rdx+rax*1]
  40931b:	rex mov BYTE PTR [rsp+0x19],al
  409320:	mov    eax,0x18
  409325:	shrx   eax,ecx,eax
  40932a:	and    eax,0xf
  40932d:	mov    al,BYTE PTR [rdx+rax*1]
  409330:	rex mov BYTE PTR [rsp+0x11],al
  409335:	mov    eax,0x18
  40933a:	shrx   eax,r12d,eax
  40933f:	and    eax,0xf
  409342:	mov    al,BYTE PTR [rdx+rax*1]
  409345:	rex mov BYTE PTR [rsp+0x1a],al
  40934a:	mov    eax,0x14
  40934f:	shrx   eax,ecx,eax
  409354:	and    eax,0xf
  409357:	mov    al,BYTE PTR [rdx+rax*1]
  40935a:	rex mov BYTE PTR [rsp+0x12],al
  40935f:	mov    eax,0x14
  409364:	shrx   eax,r12d,eax
  409369:	and    eax,0xf
  40936c:	mov    al,BYTE PTR [rdx+rax*1]
  40936f:	rex mov BYTE PTR [rsp+0x1b],al
  409374:	mov    eax,0x10
  409379:	shrx   eax,ecx,eax
  40937e:	and    eax,0xf
  409381:	mov    al,BYTE PTR [rdx+rax*1]
  409384:	rex mov BYTE PTR [rsp+0x13],al
  409389:	mov    eax,0x10
  40938e:	shrx   eax,r12d,eax
  409393:	and    eax,0xf
  409396:	mov    al,BYTE PTR [rdx+rax*1]
  409399:	rex mov BYTE PTR [rsp+0x1c],al
  40939e:	mov    eax,0xc
  4093a3:	shrx   eax,ecx,eax
  4093a8:	and    eax,0xf
  4093ab:	mov    al,BYTE PTR [rdx+rax*1]
  4093ae:	rex mov BYTE PTR [rsp+0x14],al
  4093b3:	mov    eax,0xc
  4093b8:	shrx   eax,r12d,eax
  4093bd:	and    eax,0xf
  4093c0:	mov    al,BYTE PTR [rdx+rax*1]
  4093c3:	rex mov BYTE PTR [rsp+0x1d],al
  4093c8:	mov    eax,0x8
  4093cd:	shrx   eax,ecx,eax
  4093d2:	and    eax,0xf
  4093d5:	mov    al,BYTE PTR [rdx+rax*1]
  4093d8:	rex mov BYTE PTR [rsp+0x15],al
  4093dd:	mov    eax,0x8
  4093e2:	shrx   eax,r12d,eax
  4093e7:	and    eax,0xf
  4093ea:	mov    al,BYTE PTR [rdx+rax*1]
  4093ed:	rex mov BYTE PTR [rsp+0x1e],al
  4093f2:	mov    eax,0x4
  4093f7:	shrx   eax,ecx,eax
  4093fc:	and    eax,0xf
  4093ff:	mov    al,BYTE PTR [rdx+rax*1]
  409402:	rex mov BYTE PTR [rsp+0x16],al
  409407:	mov    eax,0x4
  40940c:	shrx   eax,r12d,eax
  409411:	and    eax,0xf
  409414:	mov    al,BYTE PTR [rdx+rax*1]
  409417:	rex mov BYTE PTR [rsp+0x1f],al
  40941c:	xor    eax,eax
  40941e:	shrx   eax,ecx,eax
  409423:	and    eax,0xf
  409426:	mov    al,BYTE PTR [rdx+rax*1]
  409429:	rex mov BYTE PTR [rsp+0x17],al
  40942e:	xor    eax,eax
  409430:	shrx   eax,r12d,eax
  409435:	and    eax,0xf
  409438:	mov    al,BYTE PTR [rdx+rax*1]
  40943b:	rex mov BYTE PTR [rsp+0x20],al
  409440:	mov    BYTE PTR [r14+0x10],0x2e
  409445:	lea    r12,[rsp+0x22]
  40944a:	vxorps xmm0,xmm0,xmm0
  40944e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  409454:	mov    DWORD PTR [r12],0x6d656d2f
  40945c:	mov    WORD PTR [r12+0x4],0x6466
  409464:	mov    BYTE PTR [r12+0x6],0x3a
  40946a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409470:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  409476:	mov    rax,QWORD PTR [rsp+0x18]
  40947b:	mov    QWORD PTR [rsp+0x39],rax
  409480:	rex mov al,BYTE PTR [rsp+0x20]
  409485:	rex mov BYTE PTR [rsp+0x41],al
  40948a:	mov    DWORD PTR [r12+0x20],0x65642820
  409493:	mov    DWORD PTR [r12+0x24],0x6574656c
  40949c:	mov    WORD PTR [r12+0x28],0x2964
  4094a4:	lea    rdi,[rip+0xa010]        # 4134bb <__swc_rdata_base_4fa09e82+0x3ab>
  4094ab:	xor    eax,eax
  4094ad:	call   407060 <opendir@plt>
  4094b2:	mov    r15,rax
  4094b5:	test   rax,rax
  4094b8:	jne    4094cb <__swc_fn_4fa09e82_000108_4f8da17c+0x30b>
  4094ba:	movsxd rdi,r13d
  4094bd:	xor    eax,eax
  4094bf:	call   407040 <close@plt>
  4094c4:	xor    eax,eax
  4094c6:	jmp    409796 <__swc_fn_4fa09e82_000108_4f8da17c+0x5d6>
  4094cb:	mov    rdi,r15
  4094ce:	xor    eax,eax
  4094d0:	call   407070 <dirfd@plt>
  4094d5:	lea    r14,[rsp+0x54]
  4094da:	mov    DWORD PTR [rsp+0x54],eax
  4094de:	lea    rbx,[rsp+0x58]
  4094e3:	cs nop WORD PTR [rax+rax*1+0x0]
  4094ed:	cs nop WORD PTR [rax+rax*1+0x0]
  4094f7:	nop    WORD PTR [rax+rax*1+0x0]
  409500:	mov    rdi,r15
  409503:	xor    eax,eax
  409505:	call   407080 <readdir@plt>
  40950a:	test   rax,rax
  40950d:	jne    409524 <__swc_fn_4fa09e82_000108_4f8da17c+0x364>
  40950f:	mov    r12,QWORD PTR [rsp+0xa8]
  409517:	mov    r13,QWORD PTR [rsp+0xb0]
  40951f:	jmp    4096ba <__swc_fn_4fa09e82_000108_4f8da17c+0x4fa>
  409524:	vxorps xmm0,xmm0,xmm0
  409528:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40952e:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  409534:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40953a:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  409543:	lea    r13,[rax+0x13]
  409547:	mov    rax,r14
  40954a:	movsxd rdi,DWORD PTR [rax]
  40954d:	mov    rsi,r13
  409550:	mov    rdx,rbx
  409553:	mov    ecx,0x40
  409558:	xor    eax,eax
  40955a:	call   407090 <readlinkat@plt>
  40955f:	cmp    rax,0x2a
  409563:	jne    409500 <__swc_fn_4fa09e82_000108_4f8da17c+0x340>
  409565:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40956b:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  409571:	vptest xmm0,xmm0
  409576:	jne    4095a6 <__swc_fn_4fa09e82_000108_4f8da17c+0x3e6>
  409578:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40957e:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  409584:	vptest xmm0,xmm0
  409589:	jne    4095a6 <__swc_fn_4fa09e82_000108_4f8da17c+0x3e6>
  40958b:	mov    rcx,QWORD PTR [rsp+0x42]
  409590:	cmp    QWORD PTR [rsp+0x78],rcx
  409595:	jne    4095a6 <__swc_fn_4fa09e82_000108_4f8da17c+0x3e6>
  409597:	mov    cx,WORD PTR [rsp+0x4a]
  40959c:	cmp    WORD PTR [rsp+0x80],cx
  4095a4:	je     4095d4 <__swc_fn_4fa09e82_000108_4f8da17c+0x414>
  4095a6:	mov    rax,rbx
  4095a9:	mov    rcx,r12
  4095ac:	nop    DWORD PTR [rax+0x0]
  4095b0:	movzx  edx,BYTE PTR [rax]
  4095b3:	movzx  r8d,BYTE PTR [rcx]
  4095b7:	cmp    rdx,r8
  4095ba:	jne    4095c6 <__swc_fn_4fa09e82_000108_4f8da17c+0x406>
  4095bc:	add    rax,0x1
  4095c0:	add    rcx,0x1
  4095c4:	jmp    4095b0 <__swc_fn_4fa09e82_000108_4f8da17c+0x3f0>
  4095c6:	mov    rax,rdx
  4095c9:	sub    rax,r8
  4095cc:	test   eax,eax
  4095ce:	jne    409500 <__swc_fn_4fa09e82_000108_4f8da17c+0x340>
  4095d4:	movsxd rdi,DWORD PTR [r14]
  4095d7:	mov    rsi,r13
  4095da:	mov    edx,0x80002
  4095df:	xor    eax,eax
  4095e1:	call   4070a0 <openat@plt>
  4095e6:	lea    rbx,[rsp+0x98]
  4095ee:	mov    DWORD PTR [rsp+0x98],eax
  4095f5:	test   eax,eax
  4095f7:	mov    r13,QWORD PTR [rsp+0xb0]
  4095ff:	jge    409624 <__swc_fn_4fa09e82_000108_4f8da17c+0x464>
  409601:	mov    rdi,r15
  409604:	xor    eax,eax
  409606:	call   4070b0 <closedir@plt>
  40960b:	mov    r13,QWORD PTR [rsp+0xb0]
  409613:	movsxd rdi,r13d
  409616:	xor    eax,eax
  409618:	call   407040 <close@plt>
  40961d:	xor    eax,eax
  40961f:	jmp    409796 <__swc_fn_4fa09e82_000108_4f8da17c+0x5d6>
  409624:	mov    rax,rbx
  409627:	movsxd rdi,DWORD PTR [rax]
  40962a:	xor    esi,esi
  40962c:	mov    edx,0x2
  409631:	xor    eax,eax
  409633:	call   4070c0 <lseek@plt>
  409638:	mov    r12,QWORD PTR [rsp+0xa8]
  409640:	cmp    rax,r12
  409643:	je     40966a <__swc_fn_4fa09e82_000108_4f8da17c+0x4aa>
  409645:	movsxd rdi,DWORD PTR [rbx]
  409648:	xor    eax,eax
  40964a:	call   407040 <close@plt>
  40964f:	mov    rdi,r15
  409652:	xor    eax,eax
  409654:	call   4070b0 <closedir@plt>
  409659:	movsxd rdi,r13d
  40965c:	xor    eax,eax
  40965e:	call   407040 <close@plt>
  409663:	xor    eax,eax
  409665:	jmp    409796 <__swc_fn_4fa09e82_000108_4f8da17c+0x5d6>
  40966a:	xor    edi,edi
  40966c:	mov    rsi,r12
  40966f:	mov    edx,0x3
  409674:	mov    ecx,0x1
  409679:	mov    rax,rbx
  40967c:	movsxd r8,DWORD PTR [rax]
  40967f:	xor    r9d,r9d
  409682:	xor    eax,eax
  409684:	call   4070d0 <mmap@plt>
  409689:	xor    r12d,r12d
  40968c:	cmp    rax,0xffffffffffffffff
  409690:	cmovne r12,rax
  409694:	movsxd rdi,DWORD PTR [rbx]
  409697:	xor    eax,eax
  409699:	call   407040 <close@plt>
  40969e:	mov    rdi,r15
  4096a1:	xor    eax,eax
  4096a3:	call   4070b0 <closedir@plt>
  4096a8:	movsxd rdi,r13d
  4096ab:	xor    eax,eax
  4096ad:	call   407040 <close@plt>
  4096b2:	mov    rax,r12
  4096b5:	jmp    409796 <__swc_fn_4fa09e82_000108_4f8da17c+0x5d6>
  4096ba:	mov    r14,QWORD PTR [rsp+0xb8]
  4096c2:	mov    rdi,r14
  4096c5:	mov    esi,0x1
  4096ca:	xor    eax,eax
  4096cc:	call   4070e0 <memfd_create@plt>
  4096d1:	lea    rbx,[rsp+0x9c]
  4096d9:	mov    DWORD PTR [rsp+0x9c],eax
  4096e0:	test   eax,eax
  4096e2:	jge    4096ff <__swc_fn_4fa09e82_000108_4f8da17c+0x53f>
  4096e4:	mov    rdi,r15
  4096e7:	xor    eax,eax
  4096e9:	call   4070b0 <closedir@plt>
  4096ee:	movsxd rdi,r13d
  4096f1:	xor    eax,eax
  4096f3:	call   407040 <close@plt>
  4096f8:	xor    eax,eax
  4096fa:	jmp    409796 <__swc_fn_4fa09e82_000108_4f8da17c+0x5d6>
  4096ff:	mov    rax,rbx
  409702:	movsxd rdi,DWORD PTR [rax]
  409705:	mov    rsi,r12
  409708:	xor    eax,eax
  40970a:	call   4070f0 <ftruncate@plt>
  40970f:	test   eax,eax
  409711:	je     409735 <__swc_fn_4fa09e82_000108_4f8da17c+0x575>
  409713:	movsxd rdi,DWORD PTR [rbx]
  409716:	xor    eax,eax
  409718:	call   407040 <close@plt>
  40971d:	mov    rdi,r15
  409720:	xor    eax,eax
  409722:	call   4070b0 <closedir@plt>
  409727:	movsxd rdi,r13d
  40972a:	xor    eax,eax
  40972c:	call   407040 <close@plt>
  409731:	xor    eax,eax
  409733:	jmp    409796 <__swc_fn_4fa09e82_000108_4f8da17c+0x5d6>
  409735:	xor    edi,edi
  409737:	mov    rsi,r12
  40973a:	mov    edx,0x3
  40973f:	mov    ecx,0x1
  409744:	mov    rax,rbx
  409747:	movsxd r8,DWORD PTR [rax]
  40974a:	xor    r9d,r9d
  40974d:	xor    eax,eax
  40974f:	call   4070d0 <mmap@plt>
  409754:	mov    r12,rax
  409757:	cmp    rax,0xffffffffffffffff
  40975b:	jne    40977f <__swc_fn_4fa09e82_000108_4f8da17c+0x5bf>
  40975d:	movsxd rdi,DWORD PTR [rbx]
  409760:	xor    eax,eax
  409762:	call   407040 <close@plt>
  409767:	mov    rdi,r15
  40976a:	xor    eax,eax
  40976c:	call   4070b0 <closedir@plt>
  409771:	movsxd rdi,r13d
  409774:	xor    eax,eax
  409776:	call   407040 <close@plt>
  40977b:	xor    eax,eax
  40977d:	jmp    409796 <__swc_fn_4fa09e82_000108_4f8da17c+0x5d6>
  40977f:	mov    rdi,r15
  409782:	xor    eax,eax
  409784:	call   4070b0 <closedir@plt>
  409789:	movsxd rdi,r13d
  40978c:	xor    eax,eax
  40978e:	call   407040 <close@plt>
  409793:	mov    rax,r12
  409796:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40979f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  4097a8:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  4097b1:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  4097ba:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  4097c3:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  4097cc:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  4097d5:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  4097de:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  4097e7:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  4097f0:	add    rsp,0x170
  4097f7:	pop    r15
  4097f9:	pop    r14
  4097fb:	pop    r13
  4097fd:	pop    rsi
  4097fe:	pop    rdi
  4097ff:	pop    r12
  409801:	pop    rbx
  409802:	ret
