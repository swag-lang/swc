
/workspace/prompt2-20261115/batch5-final-micro/new/chacha/chacha:     file format elf64-x86-64


Disassembly of section .text:

000000000040a450 <__swc_fn_3464c816_000147_43c96957>:
  40a450:	push   rbx
  40a451:	sub    rsp,0xe0
  40a458:	lea    rbx,[rsp+0x8]
  40a45d:	vxorps xmm0,xmm0,xmm0
  40a461:	vmovups YMMWORD PTR [rbx],ymm0
  40a465:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40a46a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40a46f:	vzeroupper
  40a472:	mov    DWORD PTR [rbx+0x60],0x0
  40a479:	mov    r8,rbx
  40a47c:	nop    DWORD PTR [rax+0x0]
  40a480:	mov    r9,rcx
  40a483:	movabs rcx,0xcccccccccccccccd
  40a48d:	mov    rax,r9
  40a490:	mul    rcx
  40a493:	mov    r10,rdx
  40a496:	shr    r10,0x3
  40a49a:	mov    rcx,r10
  40a49d:	imul   rdx,r10,0xa
  40a4a1:	sub    r9,rdx
  40a4a4:	mov    rdx,QWORD PTR [rip+0x9195]        # 413640 <__swc_rdata_base_3464c816+0x530>
  40a4ab:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  40a4b0:	mov    BYTE PTR [r8],dl
  40a4b3:	lea    rdx,[r8+0x1]
  40a4b7:	mov    r8,rdx
  40a4ba:	test   r10,r10
  40a4bd:	jne    40a480 <__swc_fn_3464c816_000147_43c96957+0x30>
  40a4bf:	mov    BYTE PTR [rdx],0x0
  40a4c2:	sub    r8,0x1
  40a4c6:	mov    rax,rbx
  40a4c9:	cmp    rax,r8
  40a4cc:	jae    40a4e6 <__swc_fn_3464c816_000147_43c96957+0x96>
  40a4ce:	xchg   ax,ax
  40a4d0:	mov    cl,BYTE PTR [r8]
  40a4d3:	mov    dl,BYTE PTR [rax]
  40a4d5:	mov    BYTE PTR [r8],dl
  40a4d8:	sub    r8,0x1
  40a4dc:	mov    BYTE PTR [rax],cl
  40a4de:	inc    rax
  40a4e1:	cmp    rax,r8
  40a4e4:	jb     40a4d0 <__swc_fn_3464c816_000147_43c96957+0x80>
  40a4e6:	xor    eax,eax
  40a4e8:	test   rbx,rbx
  40a4eb:	je     40a50e <__swc_fn_3464c816_000147_43c96957+0xbe>
  40a4ed:	mov    rcx,rbx
  40a4f0:	mov    dl,BYTE PTR [rcx]
  40a4f2:	test   dl,dl
  40a4f4:	je     40a50e <__swc_fn_3464c816_000147_43c96957+0xbe>
  40a4f6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a500:	add    rcx,0x1
  40a504:	add    rax,0x1
  40a508:	mov    dl,BYTE PTR [rcx]
  40a50a:	test   dl,dl
  40a50c:	jne    40a500 <__swc_fn_3464c816_000147_43c96957+0xb0>
  40a50e:	mov    QWORD PTR [rbx+0xa8],rbx
  40a515:	mov    QWORD PTR [rbx+0xb0],rax
  40a51c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40a524:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40a52c:	lea    rcx,[rbx+0xb8]
  40a533:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  40a538:	add    rsp,0xe0
  40a53f:	pop    rbx
  40a540:	ret
