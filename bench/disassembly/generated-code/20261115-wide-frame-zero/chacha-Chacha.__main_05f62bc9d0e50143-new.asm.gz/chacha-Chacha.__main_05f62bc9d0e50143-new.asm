
/workspace/prompt2-20261115/batch5-final-micro/new/chacha/chacha:     file format elf64-x86-64


Disassembly of section .text:

0000000000407280 <__swc_fn_3464c816_000000_7f24d040>:
  407280:	push   rbp
  407281:	push   rbx
  407282:	push   rsi
  407283:	push   rdi
  407284:	push   r12
  407286:	push   r13
  407288:	push   r15
  40728a:	push   r14
  40728c:	sub    rsp,0x50
  407290:	mov    rbp,rsp
  407293:	vmovups XMMWORD PTR [rsp],xmm6
  407298:	vmovups XMMWORD PTR [rsp+0x10],xmm7
  40729e:	vmovups XMMWORD PTR [rsp+0x20],xmm8
  4072a4:	vmovups XMMWORD PTR [rsp+0x30],xmm9
  4072aa:	vmovups XMMWORD PTR [rsp+0x40],xmm10
  4072b0:	sub    rsp,0x70
  4072b4:	mov    rbx,rsp
  4072b7:	mov    ecx,0x1000000
  4072bc:	sub    rsp,0x8
  4072c0:	call   40ab00 <__swc_fn_3464c816_000001_2744b483>
  4072c5:	add    rsp,0x8
  4072c9:	mov    rsi,rax
  4072cc:	mov    QWORD PTR [rsp+0x50],rax
  4072d1:	xor    ecx,ecx
  4072d3:	cs nop WORD PTR [rax+rax*1+0x0]
  4072dd:	cs nop WORD PTR [rax+rax*1+0x0]
  4072e7:	nop    WORD PTR [rax+rax*1+0x0]
  4072f0:	mov    r8,QWORD PTR [rip+0x1ad09]        # 422000 <__swc_data_base_3464c816>
  4072f7:	imul   r8,r8,0x41a7
  4072fe:	movabs rdx,0x200000005
  407308:	mov    r11,rax
  40730b:	mov    rax,r8
  40730e:	mul    rdx
  407311:	mov    r9,rdx
  407314:	mov    rdx,r8
  407317:	sub    rdx,r9
  40731a:	shr    rdx,1
  40731d:	add    rdx,r9
  407320:	shr    rdx,0x1e
  407324:	imul   r9,rdx,0x7fffffff
  40732b:	sub    r8,r9
  40732e:	mov    QWORD PTR [rip+0x1accb],r8        # 422000 <__swc_data_base_3464c816>
  407335:	mov    DWORD PTR [rsi+rcx*4],r8d
  407339:	add    rcx,0x1
  40733d:	mov    r8,QWORD PTR [rip+0x1acbc]        # 422000 <__swc_data_base_3464c816>
  407344:	imul   r8,r8,0x41a7
  40734b:	movabs rdx,0x200000005
  407355:	mov    rax,r8
  407358:	mul    rdx
  40735b:	mov    r9,rdx
  40735e:	mov    rax,r11
  407361:	mov    rdx,r8
  407364:	sub    rdx,r9
  407367:	shr    rdx,1
  40736a:	add    rdx,r9
  40736d:	shr    rdx,0x1e
  407371:	imul   rdx,rdx,0x7fffffff
  407378:	sub    r8,rdx
  40737b:	mov    QWORD PTR [rip+0x1ac7e],r8        # 422000 <__swc_data_base_3464c816>
  407382:	mov    DWORD PTR [rsi+rcx*4],r8d
  407386:	add    rcx,0x1
  40738a:	cmp    rcx,0x400000
  407391:	jb     4072f0 <__swc_fn_3464c816_000000_7f24d040+0x70>
  407397:	mov    rcx,QWORD PTR [rip+0x1ac62]        # 422000 <__swc_data_base_3464c816>
  40739e:	imul   rcx,rcx,0x41a7
  4073a5:	movabs rdx,0x200000005
  4073af:	mov    rax,rcx
  4073b2:	mul    rdx
  4073b5:	mov    r8,rdx
  4073b8:	mov    rdx,rcx
  4073bb:	sub    rdx,r8
  4073be:	shr    rdx,1
  4073c1:	add    rdx,r8
  4073c4:	shr    rdx,0x1e
  4073c8:	imul   r8,rdx,0x7fffffff
  4073cf:	mov    rdi,rcx
  4073d2:	sub    rdi,r8
  4073d5:	mov    QWORD PTR [rip+0x1ac24],rdi        # 422000 <__swc_data_base_3464c816>
  4073dc:	imul   rcx,rdi,0x41a7
  4073e3:	movabs rdx,0x200000005
  4073ed:	mov    rax,rcx
  4073f0:	mul    rdx
  4073f3:	mov    r8,rdx
  4073f6:	mov    rdx,rcx
  4073f9:	sub    rdx,r8
  4073fc:	shr    rdx,1
  4073ff:	add    rdx,r8
  407402:	shr    rdx,0x1e
  407406:	imul   rdx,rdx,0x7fffffff
  40740d:	mov    r12,rcx
  407410:	sub    r12,rdx
  407413:	mov    QWORD PTR [rip+0x1abe6],r12        # 422000 <__swc_data_base_3464c816>
  40741a:	imul   rcx,r12,0x41a7
  407421:	movabs rdx,0x200000005
  40742b:	mov    rax,rcx
  40742e:	mul    rdx
  407431:	mov    r8,rdx
  407434:	mov    rdx,rcx
  407437:	sub    rdx,r8
  40743a:	shr    rdx,1
  40743d:	add    rdx,r8
  407440:	shr    rdx,0x1e
  407444:	imul   rdx,rdx,0x7fffffff
  40744b:	mov    r13,rcx
  40744e:	sub    r13,rdx
  407451:	mov    QWORD PTR [rip+0x1aba8],r13        # 422000 <__swc_data_base_3464c816>
  407458:	imul   rcx,r13,0x41a7
  40745f:	movabs rdx,0x200000005
  407469:	mov    rax,rcx
  40746c:	mul    rdx
  40746f:	mov    r8,rdx
  407472:	mov    rdx,rcx
  407475:	sub    rdx,r8
  407478:	shr    rdx,1
  40747b:	add    rdx,r8
  40747e:	shr    rdx,0x1e
  407482:	imul   rdx,rdx,0x7fffffff
  407489:	mov    r14,rcx
  40748c:	sub    r14,rdx
  40748f:	mov    QWORD PTR [rip+0x1ab6a],r14        # 422000 <__swc_data_base_3464c816>
  407496:	imul   rcx,r14,0x41a7
  40749d:	movabs rdx,0x200000005
  4074a7:	mov    rax,rcx
  4074aa:	mul    rdx
  4074ad:	mov    r8,rdx
  4074b0:	mov    rdx,rcx
  4074b3:	sub    rdx,r8
  4074b6:	shr    rdx,1
  4074b9:	add    rdx,r8
  4074bc:	shr    rdx,0x1e
  4074c0:	imul   rdx,rdx,0x7fffffff
  4074c7:	mov    r15,rcx
  4074ca:	sub    r15,rdx
  4074cd:	mov    QWORD PTR [rip+0x1ab2c],r15        # 422000 <__swc_data_base_3464c816>
  4074d4:	imul   rcx,r15,0x41a7
  4074db:	movabs rdx,0x200000005
  4074e5:	mov    rax,rcx
  4074e8:	mul    rdx
  4074eb:	mov    r8,rdx
  4074ee:	mov    rdx,rcx
  4074f1:	sub    rdx,r8
  4074f4:	shr    rdx,1
  4074f7:	add    rdx,r8
  4074fa:	shr    rdx,0x1e
  4074fe:	imul   rdx,rdx,0x7fffffff
  407505:	mov    rsi,rcx
  407508:	sub    rsi,rdx
  40750b:	mov    QWORD PTR [rip+0x1aaee],rsi        # 422000 <__swc_data_base_3464c816>
  407512:	imul   rcx,rsi,0x41a7
  407519:	movabs rdx,0x200000005
  407523:	mov    rax,rcx
  407526:	mul    rdx
  407529:	mov    r8,rdx
  40752c:	mov    rdx,rcx
  40752f:	sub    rdx,r8
  407532:	shr    rdx,1
  407535:	add    rdx,r8
  407538:	shr    rdx,0x1e
  40753c:	imul   rdx,rdx,0x7fffffff
  407543:	mov    QWORD PTR [rsp+0x58],rsi
  407548:	mov    rsi,rcx
  40754b:	sub    rsi,rdx
  40754e:	mov    QWORD PTR [rip+0x1aaab],rsi        # 422000 <__swc_data_base_3464c816>
  407555:	imul   rcx,rsi,0x41a7
  40755c:	movabs rdx,0x200000005
  407566:	mov    rax,rcx
  407569:	mul    rdx
  40756c:	mov    r8,rdx
  40756f:	mov    rdx,rcx
  407572:	sub    rdx,r8
  407575:	shr    rdx,1
  407578:	add    rdx,r8
  40757b:	shr    rdx,0x1e
  40757f:	imul   rdx,rdx,0x7fffffff
  407586:	mov    QWORD PTR [rsp+0x60],rsi
  40758b:	mov    rsi,rcx
  40758e:	sub    rsi,rdx
  407591:	mov    QWORD PTR [rip+0x1aa68],rsi        # 422000 <__swc_data_base_3464c816>
  407598:	mov    QWORD PTR [rbx],0x0
  40759f:	mov    rcx,QWORD PTR [rip+0x1aa5a]        # 422000 <__swc_data_base_3464c816>
  4075a6:	imul   rcx,rcx,0x41a7
  4075ad:	movabs rdx,0x200000005
  4075b7:	mov    rax,rcx
  4075ba:	mul    rdx
  4075bd:	mov    r8,rdx
  4075c0:	mov    rdx,rcx
  4075c3:	sub    rdx,r8
  4075c6:	shr    rdx,1
  4075c9:	add    rdx,r8
  4075cc:	shr    rdx,0x1e
  4075d0:	imul   r8,rdx,0x7fffffff
  4075d7:	mov    QWORD PTR [rsp+0x68],rsi
  4075dc:	mov    rsi,rcx
  4075df:	sub    rsi,r8
  4075e2:	mov    QWORD PTR [rip+0x1aa17],rsi        # 422000 <__swc_data_base_3464c816>
  4075e9:	mov    DWORD PTR [rbx],esi
  4075eb:	mov    rcx,QWORD PTR [rip+0x1aa0e]        # 422000 <__swc_data_base_3464c816>
  4075f2:	imul   rcx,rcx,0x41a7
  4075f9:	movabs rdx,0x200000005
  407603:	mov    rax,rcx
  407606:	mul    rdx
  407609:	mov    r8,rdx
  40760c:	mov    rdx,rcx
  40760f:	sub    rdx,r8
  407612:	shr    rdx,1
  407615:	add    rdx,r8
  407618:	shr    rdx,0x1e
  40761c:	imul   r8,rdx,0x7fffffff
  407623:	mov    rsi,rcx
  407626:	sub    rsi,r8
  407629:	mov    QWORD PTR [rip+0x1a9d0],rsi        # 422000 <__swc_data_base_3464c816>
  407630:	mov    DWORD PTR [rbx+0x4],esi
  407633:	mov    rcx,QWORD PTR [rip+0x1a9c6]        # 422000 <__swc_data_base_3464c816>
  40763a:	imul   rcx,rcx,0x41a7
  407641:	movabs rdx,0x200000005
  40764b:	mov    rax,rcx
  40764e:	mul    rdx
  407651:	mov    r8,rdx
  407654:	mov    rdx,rcx
  407657:	sub    rdx,r8
  40765a:	shr    rdx,1
  40765d:	add    rdx,r8
  407660:	shr    rdx,0x1e
  407664:	imul   r8,rdx,0x7fffffff
  40766b:	mov    rsi,rcx
  40766e:	sub    rsi,r8
  407671:	mov    QWORD PTR [rip+0x1a988],rsi        # 422000 <__swc_data_base_3464c816>
  407678:	sub    rsp,0x8
  40767c:	call   40dda0 <__swc_fn_3464c816_000002_1ca87929>
  407681:	add    rsp,0x8
  407685:	vmovups xmm6,xmm0
  407689:	lea    rax,[rbx+0xc]
  40768d:	vxorps xmm0,xmm0,xmm0
  407691:	vmovups YMMWORD PTR [rbx+0xc],ymm0
  407696:	vmovups YMMWORD PTR [rbx+0x2c],ymm0
  40769b:	vzeroupper
  40769e:	mov    DWORD PTR [rax],0x61707865
  4076a4:	mov    DWORD PTR [rax+0x4],0x3320646e
  4076ab:	mov    DWORD PTR [rax+0x8],0x79622d32
  4076b2:	mov    DWORD PTR [rax+0xc],0x6b206574
  4076b9:	mov    DWORD PTR [rbx+0x1c],edi
  4076bc:	mov    DWORD PTR [rbx+0x20],r12d
  4076c0:	mov    DWORD PTR [rbx+0x24],r13d
  4076c4:	mov    DWORD PTR [rbx+0x28],r14d
  4076c8:	mov    DWORD PTR [rbx+0x2c],r15d
  4076cc:	mov    rax,QWORD PTR [rsp+0x58]
  4076d1:	mov    DWORD PTR [rbx+0x30],eax
  4076d4:	mov    rax,QWORD PTR [rsp+0x60]
  4076d9:	mov    DWORD PTR [rbx+0x34],eax
  4076dc:	mov    rax,QWORD PTR [rsp+0x68]
  4076e1:	mov    DWORD PTR [rbx+0x38],eax
  4076e4:	mov    eax,DWORD PTR [rbx]
  4076e6:	mov    DWORD PTR [rbx+0x40],eax
  4076e9:	mov    eax,DWORD PTR [rbx+0x4]
  4076ec:	mov    DWORD PTR [rbx+0x44],eax
  4076ef:	mov    DWORD PTR [rbx+0x48],esi
  4076f2:	xor    eax,eax
  4076f4:	mov    ecx,0x1
  4076f9:	vmovups xmm0,XMMWORD PTR [rip+0xbb1f]        # 413220 <__swc_rdata_base_3464c816+0x110>
  407701:	mov    rsi,QWORD PTR [rsp+0x50]
  407706:	vmovups xmm1,XMMWORD PTR [rip+0xbb22]        # 413230 <__swc_rdata_base_3464c816+0x120>
  40770e:	cmp    rax,0x400000
  407715:	jae    40787b <__swc_fn_3464c816_000000_7f24d040+0x5fb>
  40771b:	nop    DWORD PTR [rax+rax*1+0x0]
  407720:	mov    DWORD PTR [rbx+0x3c],ecx
  407723:	vmovups xmm3,XMMWORD PTR [rbx+0xc]
  407728:	vmovups xmm4,XMMWORD PTR [rbx+0x1c]
  40772d:	vmovups xmm5,XMMWORD PTR [rbx+0x2c]
  407732:	vmovups xmm2,XMMWORD PTR [rbx+0x3c]
  407737:	xor    edx,edx
  407739:	nop    DWORD PTR [rax+0x0]
  407740:	vpaddd xmm3,xmm3,xmm4
  407744:	vpxor  xmm2,xmm2,xmm3
  407748:	vpshufb xmm2,xmm2,xmm0
  40774d:	vpaddd xmm5,xmm5,xmm2
  407751:	vpxor  xmm4,xmm4,xmm5
  407755:	vpslld xmm7,xmm4,0xc
  40775a:	vpsrld xmm4,xmm4,0x14
  40775f:	vpor   xmm4,xmm7,xmm4
  407763:	vpaddd xmm3,xmm3,xmm4
  407767:	vpshufd xmm7,xmm3,0x39
  40776c:	vpshufd xmm2,xmm2,0x39
  407771:	vpxor  xmm2,xmm2,xmm7
  407775:	vpshufb xmm2,xmm2,xmm1
  40777a:	vpshufd xmm5,xmm5,0x39
  40777f:	vpaddd xmm5,xmm5,xmm2
  407783:	vpshufd xmm4,xmm4,0x39
  407788:	vpxor  xmm4,xmm4,xmm5
  40778c:	vpslld xmm7,xmm4,0x7
  407791:	vpsrld xmm4,xmm4,0x19
  407796:	vpor   xmm4,xmm7,xmm4
  40779a:	vpaddd xmm3,xmm3,xmm4
  40779e:	vpshufd xmm2,xmm2,0x4e
  4077a3:	vpxor  xmm2,xmm2,xmm3
  4077a7:	vpshufb xmm2,xmm2,xmm0
  4077ac:	vpshufd xmm5,xmm5,0x39
  4077b1:	vpaddd xmm5,xmm5,xmm2
  4077b5:	vpxor  xmm4,xmm4,xmm5
  4077b9:	vpslld xmm7,xmm4,0xc
  4077be:	vpsrld xmm4,xmm4,0x14
  4077c3:	vpor   xmm4,xmm7,xmm4
  4077c7:	vpaddd xmm3,xmm3,xmm4
  4077cb:	vpshufd xmm2,xmm2,0x93
  4077d0:	vpshufd xmm7,xmm3,0x93
  4077d5:	vpxor  xmm2,xmm2,xmm7
  4077d9:	vpshufb xmm2,xmm2,xmm1
  4077de:	vpshufd xmm5,xmm5,0x93
  4077e3:	vpaddd xmm5,xmm5,xmm2
  4077e7:	vpshufd xmm4,xmm4,0x93
  4077ec:	vpxor  xmm4,xmm4,xmm5
  4077f0:	vpslld xmm7,xmm4,0x7
  4077f5:	vpsrld xmm4,xmm4,0x19
  4077fa:	vpor   xmm4,xmm7,xmm4
  4077fe:	vpshufd xmm5,xmm5,0x93
  407803:	vpshufd xmm2,xmm2,0x4e
  407808:	add    rdx,0x1
  40780c:	cmp    rdx,0xa
  407810:	jb     407740 <__swc_fn_3464c816_000000_7f24d040+0x4c0>
  407816:	lea    rdx,[rsi+rax*4]
  40781a:	vpaddd xmm3,xmm3,XMMWORD PTR [rsp+0xc]
  407820:	vpxor  xmm3,xmm3,XMMWORD PTR [rsi+rax*4]
  407825:	vpaddd xmm4,xmm4,XMMWORD PTR [rsp+0x1c]
  40782b:	vpxor  xmm4,xmm4,XMMWORD PTR [rsi+rax*4+0x10]
  407831:	vpaddd xmm5,xmm5,XMMWORD PTR [rsp+0x2c]
  407837:	vpxor  xmm5,xmm5,XMMWORD PTR [rsi+rax*4+0x20]
  40783d:	vpaddd xmm7,xmm2,XMMWORD PTR [rsp+0x3c]
  407843:	vpxor  xmm7,xmm7,XMMWORD PTR [rsi+rax*4+0x30]
  407849:	vmovdqu XMMWORD PTR [rdx],xmm3
  40784d:	vmovdqu XMMWORD PTR [rdx+0x10],xmm4
  407852:	vmovdqu XMMWORD PTR [rdx+0x20],xmm5
  407857:	vmovdqu XMMWORD PTR [rdx+0x30],xmm7
  40785c:	vpshufd xmm2,xmm2,0x3
  407861:	vmovd  edx,xmm2
  407865:	add    edx,DWORD PTR [rbx+0x48]
  407868:	lea    rax,[rax+0x10]
  40786c:	inc    ecx
  40786e:	cmp    rax,0x400000
  407875:	jb     407720 <__swc_fn_3464c816_000000_7f24d040+0x4a0>
  40787b:	xor    edi,edi
  40787d:	xor    eax,eax
  40787f:	vxorps xmm0,xmm0,xmm0
  407883:	mov    ecx,0x1
  407888:	vpinsrd xmm0,xmm0,ecx,0x1
  40788e:	mov    ecx,0x2
  407893:	vpinsrd xmm0,xmm0,ecx,0x2
  407899:	mov    ecx,0x3
  40789e:	vpinsrd xmm0,xmm0,ecx,0x3
  4078a4:	vmovss xmm1,DWORD PTR [rip+0xb994]        # 413240 <__swc_rdata_base_3464c816+0x130>
  4078ac:	vpshufd xmm1,xmm1,0x0
  4078b1:	vpaddd xmm2,xmm0,xmm1
  4078b5:	vmovss xmm1,DWORD PTR [rip+0xb98c]        # 413249 <__swc_rdata_base_3464c816+0x139>
  4078bd:	vpshufd xmm1,xmm1,0x0
  4078c2:	vxorps xmm3,xmm3,xmm3
  4078c6:	vxorps xmm4,xmm4,xmm4
  4078ca:	nop    WORD PTR [rax+rax*1+0x0]
  4078d0:	vpaddd xmm5,xmm0,XMMWORD PTR [rsi+rax*4]
  4078d5:	vpxor  xmm3,xmm3,xmm5
  4078d9:	vpaddd xmm5,xmm2,XMMWORD PTR [rsi+rax*4+0x10]
  4078df:	vpxor  xmm4,xmm4,xmm5
  4078e3:	vpaddd xmm2,xmm2,xmm1
  4078e7:	vpaddd xmm0,xmm0,xmm1
  4078eb:	add    rax,0x8
  4078ef:	cmp    rax,0x3ffff9
  4078f6:	jb     4078d0 <__swc_fn_3464c816_000000_7f24d040+0x650>
  4078f8:	vpxor  xmm3,xmm3,xmm4
  4078fc:	vpshufd xmm5,xmm3,0x4e
  407901:	vpxor  xmm3,xmm3,xmm5
  407905:	vpshufd xmm5,xmm3,0xb1
  40790a:	vpxor  xmm3,xmm3,xmm5
  40790e:	vmovd  eax,xmm3
  407912:	xor    rdi,rax
  407915:	sub    rsp,0x8
  407919:	call   40dda0 <__swc_fn_3464c816_000002_1ca87929>
  40791e:	add    rsp,0x8
  407922:	vsubsd xmm0,xmm0,xmm6
  407926:	vmulsd xmm0,xmm0,QWORD PTR [rip+0xb924]        # 413252 <__swc_rdata_base_3464c816+0x142>
  40792e:	lea    rax,[rip+0xb7db]        # 413110 <__swc_rdata_base_3464c816>
  407935:	sub    rsp,0x90
  40793c:	mov    rcx,rsp
  40793f:	vmovups xmm1,XMMWORD PTR [rip+0xb8b1]        # 4131f8 <__swc_rdata_base_3464c816+0xe8>
  407947:	vmovups XMMWORD PTR [rcx],xmm1
  40794b:	mov    QWORD PTR [rcx+0x30],rsp
  40794f:	lea    rdx,[rip+0xb7ca]        # 413120 <__swc_rdata_base_3464c816+0x10>
  407956:	mov    QWORD PTR [rcx+0x38],rdx
  40795a:	mov    QWORD PTR [rcx+0x10],rdi
  40795e:	lea    r8,[rsp+0x10]
  407963:	mov    QWORD PTR [rcx+0x40],r8
  407967:	lea    r8,[rip+0xb7fa]        # 413168 <__swc_rdata_base_3464c816+0x58>
  40796e:	mov    QWORD PTR [rcx+0x48],r8
  407972:	vmovups xmm1,XMMWORD PTR [rip+0xb88e]        # 413208 <__swc_rdata_base_3464c816+0xf8>
  40797a:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40797f:	lea    r8,[rsp+0x18]
  407984:	mov    QWORD PTR [rcx+0x50],r8
  407988:	mov    QWORD PTR [rcx+0x58],rdx
  40798c:	vmovsd QWORD PTR [rcx+0x28],xmm0
  407991:	lea    r8,[rcx+0x28]
  407995:	mov    QWORD PTR [rcx+0x60],r8
  407999:	lea    r8,[rip+0xb810]        # 4131b0 <__swc_rdata_base_3464c816+0xa0>
  4079a0:	mov    QWORD PTR [rcx+0x68],r8
  4079a4:	mov    QWORD PTR [rcx+0x70],rax
  4079a8:	mov    QWORD PTR [rcx+0x78],rdx
  4079ac:	lea    rax,[rcx+0x30]
  4079b0:	mov    QWORD PTR [rcx+0x80],rax
  4079b7:	mov    QWORD PTR [rcx+0x88],0x5
  4079c2:	lea    rcx,[rcx+0x80]
  4079c9:	sub    rsp,0x8
  4079cd:	call   410980 <__swc_fn_3464c816_000149_6203dca2>
  4079d2:	add    rsp,0x108
  4079d9:	vmovups xmm6,XMMWORD PTR [rsp]
  4079de:	vmovups xmm7,XMMWORD PTR [rsp+0x10]
  4079e4:	vmovups xmm8,XMMWORD PTR [rsp+0x20]
  4079ea:	vmovups xmm9,XMMWORD PTR [rsp+0x30]
  4079f0:	vmovups xmm10,XMMWORD PTR [rsp+0x40]
  4079f6:	add    rsp,0x50
  4079fa:	pop    r14
  4079fc:	pop    r15
  4079fe:	pop    r13
  407a00:	pop    r12
  407a02:	pop    rdi
  407a03:	pop    rsi
  407a04:	pop    rbx
  407a05:	pop    rbp
  407a06:	ret
