Archive preview through the text viewer.
