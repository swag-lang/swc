
/workspace/prompt2-20261115/batch5-final-micro/new/chacha/chacha:     file format elf64-x86-64


Disassembly of section .text:

0000000000409100 <__swc_fn_3464c816_000099_d4bdcaa4>:
  409100:	push   rbx
  409101:	sub    rsp,0x70
  409105:	vxorps xmm0,xmm0,xmm0
  409109:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40910f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  409115:	vzeroupper
  409118:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40911e:	mov    QWORD PTR [rsp+0x48],rdx
  409123:	mov    rax,r8
  409126:	cmp    r8,0x1
  40912a:	mov    edx,0x1
  40912f:	cmovb  rax,rdx
  409133:	mov    QWORD PTR [rsp+0x50],rax
  409138:	mov    rbx,QWORD PTR [rcx+0x8]
  40913c:	mov    rbx,QWORD PTR [rbx+0x18]
  409140:	mov    rcx,QWORD PTR [rcx]
  409143:	lea    rdx,[rsp+0x8]
  409148:	call   rbx
  40914a:	add    rsp,0x70
  40914e:	pop    rbx
  40914f:	ret
