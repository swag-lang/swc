int sample() { return 42; }
