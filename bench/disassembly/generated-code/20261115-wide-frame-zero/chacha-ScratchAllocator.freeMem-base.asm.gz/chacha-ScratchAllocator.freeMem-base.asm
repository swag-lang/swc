
/workspace/prompt2-20261115/batch5-final-micro/base/chacha/chacha:     file format elf64-x86-64


Disassembly of section .text:

0000000000409ec0 <__swc_fn_3464c816_000156_65b5512b>:
  409ec0:	push   rbx
  409ec1:	sub    rsp,0x70
  409ec5:	mov    rax,QWORD PTR [rcx]
  409ec8:	mov    rbx,QWORD PTR [rcx+0x8]
  409ecc:	vxorps xmm0,xmm0,xmm0
  409ed0:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409ed6:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409edc:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409ee2:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  409ee8:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  409eee:	mov    QWORD PTR [rsp+0x48],rdx
  409ef3:	mov    QWORD PTR [rsp+0x50],r8
  409ef8:	mov    rcx,rax
  409efb:	lea    rdx,[rsp+0x8]
  409f00:	mov    rbx,QWORD PTR [rbx+0x18]
  409f04:	call   rbx
  409f06:	add    rsp,0x70
  409f0a:	pop    rbx
  409f0b:	ret
