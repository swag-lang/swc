
/workspace/prompt2-20261115/batch9-audited-micro/base/fannkuch/fannkuch:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xb002]        # 412008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <getpid@plt>:
  407010:	jmp    QWORD PTR [rip+0xaffa]        # 412010 <getpid@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <munmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xaff2]        # 412018 <munmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xafea]        # 412020 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <exit@plt>:
  407040:	jmp    QWORD PTR [rip+0xafe2]        # 412028 <exit@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <pthread_key_create@plt>:
  407050:	jmp    QWORD PTR [rip+0xafda]        # 412030 <pthread_key_create@GLIBC_2.34>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_setspecific@plt>:
  407060:	jmp    QWORD PTR [rip+0xafd2]        # 412038 <pthread_setspecific@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <syscall@plt>:
  407070:	jmp    QWORD PTR [rip+0xafca]        # 412040 <syscall@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dladdr@plt>:
  407080:	jmp    QWORD PTR [rip+0xafc2]        # 412048 <dladdr@GLIBC_2.34>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <open@plt>:
  407090:	jmp    QWORD PTR [rip+0xafba]        # 412050 <open@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <lseek@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xafb2]        # 412058 <lseek@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <close@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xafaa]        # 412060 <close@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <mmap@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xafa2]        # 412068 <mmap@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <malloc@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xaf9a]        # 412070 <malloc@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <clock_gettime@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xaf92]        # 412078 <clock_gettime@GLIBC_2.17>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <madvise@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xaf92]        # 412088 <madvise@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <pthread_key_delete@plt>:
  407100:	jmp    QWORD PTR [rip+0xaf8a]        # 412090 <pthread_key_delete@GLIBC_2.34>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <gettid@plt>:
  407110:	jmp    QWORD PTR [rip+0xaf82]        # 412098 <gettid@GLIBC_2.30>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <flock@plt>:
  407120:	jmp    QWORD PTR [rip+0xaf7a]        # 4120a0 <flock@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <__errno_location@plt>:
  407130:	jmp    QWORD PTR [rip+0xaf72]        # 4120a8 <__errno_location@GLIBC_2.2.5>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <opendir@plt>:
  407140:	jmp    QWORD PTR [rip+0xaf6a]        # 4120b0 <opendir@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <dirfd@plt>:
  407150:	jmp    QWORD PTR [rip+0xaf62]        # 4120b8 <dirfd@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <readdir@plt>:
  407160:	jmp    QWORD PTR [rip+0xaf5a]        # 4120c0 <readdir@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <readlinkat@plt>:
  407170:	jmp    QWORD PTR [rip+0xaf52]        # 4120c8 <readlinkat@GLIBC_2.4>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <openat@plt>:
  407180:	jmp    QWORD PTR [rip+0xaf4a]        # 4120d0 <openat@GLIBC_2.4>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <closedir@plt>:
  407190:	jmp    QWORD PTR [rip+0xaf42]        # 4120d8 <closedir@GLIBC_2.2.5>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <memfd_create@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xaf3a]        # 4120e0 <memfd_create@GLIBC_2.27>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <ftruncate@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xaf32]        # 4120e8 <ftruncate@GLIBC_2.2.5>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <write@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xaf2a]        # 4120f0 <write@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <backtrace@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xaf22]        # 4120f8 <backtrace@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <__x86_get_cpuid_feature_leaf@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xaf1a]        # 412100 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <free@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xaf12]        # 412108 <free@GLIBC_2.2.5>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xaddf]        # 412000 <__swc_fn_585f006d_000176_5d3d19bd+0x3c0>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40ca80 <__swc_fn_585f006d_000121_71a5b1cd>
  40724e:	xor    ecx,ecx
  407250:	call   40c1a0 <__swc_fn_585f006d_000094_335e9a12>
  407255:	call   40d6e0 <__swc_fn_585f006d_000178_8d3f617b>
  40725a:	call   40f290 <__swc_fn_585f006d_000095_a3245f7e>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_585f006d_000000_29b04951>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_585f006d_000003_644dadb7>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_585f006d_000003_644dadb7+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   409240 <__swc_fn_585f006d_000111_e724f834>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_585f006d_000003_644dadb7+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1bd81]        # 423048 <__swc_bss_base_585f006d+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1bd7a]        # 423048 <__swc_bss_base_585f006d+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_585f006d_000003_644dadb7+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_585f006d_000003_644dadb7+0x30>
  4072e6:	lea    rcx,[rip+0x1bd63]        # 423050 <__swc_bss_base_585f006d+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1bd5c]        # 423050 <__swc_bss_base_585f006d+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_585f006d_000003_644dadb7+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_585f006d_000003_644dadb7+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_585f006d_000006_12cb36a2>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40db40 <__swc_fn_585f006d_000011_e75d466d>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_585f006d_000012_39679ef8>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_585f006d_000006_12cb36a2+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_585f006d_000003_644dadb7>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_585f006d_000006_12cb36a2+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_585f006d_000009_2417e911>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_585f006d_000009_2417e911+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40a530 <__swc_fn_585f006d_000007_635028f3>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40db30 <__swc_fn_585f006d_000008_578f1784>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_585f006d_000009_2417e911+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_585f006d_000009_2417e911+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_585f006d_000012_39679ef8>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_585f006d_000015_aa8c841a>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_585f006d_000015_aa8c841a+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_585f006d_000015_aa8c841a+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_585f006d_000015_aa8c841a+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_585f006d_000015_aa8c841a+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40dca0 <__swc_fn_585f006d_000017_e238d24c>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_585f006d_000015_aa8c841a+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1bb3d]        # 423058 <__swc_bss_base_585f006d+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1bb36]        # 423058 <__swc_bss_base_585f006d+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_585f006d_000015_aa8c841a+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_585f006d_000015_aa8c841a+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40db40 <__swc_fn_585f006d_000011_e75d466d>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_585f006d_000015_aa8c841a+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   40c7a0 <__swc_fn_585f006d_000112_cb2656be>
  407569:	lea    rcx,[rip+0x1bad8]        # 423048 <__swc_bss_base_585f006d+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1bad1]        # 423048 <__swc_bss_base_585f006d+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_585f006d_000015_aa8c841a+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_585f006d_000015_aa8c841a+0x110>
  407598:	lea    rcx,[rip+0x1bac1]        # 423060 <__swc_bss_base_585f006d+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1baba]        # 423060 <__swc_bss_base_585f006d+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_585f006d_000015_aa8c841a+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_585f006d_000015_aa8c841a+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_585f006d_000018_e2e8e4b0>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_585f006d_000015_aa8c841a+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_585f006d_000018_e2e8e4b0>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_585f006d_000018_e2e8e4b0+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_585f006d_000018_e2e8e4b0+0x10>

0000000000407630 <__swc_fn_585f006d_000021_fe13ecad>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_585f006d_000015_aa8c841a>
  40763e:	lea    rdi,[rip+0x1bbab]        # 4231f0 <__swc_bss_base_585f006d+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   4098a0 <__swc_fn_585f006d_000135_1fec60ac>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1bb94]        # 4231f8 <__swc_bss_base_585f006d+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1bb89],rsi        # 4231f8 <__swc_bss_base_585f006d+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_585f006d_000024_7e9350e1>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_585f006d_000027_7e9350e1>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_585f006d_000030_686c93a8>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_585f006d_000030_686c93a8+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1992c]        # 421000 <__swc_data_base_585f006d>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_585f006d_000030_686c93a8+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_585f006d_000030_686c93a8+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_585f006d_000030_686c93a8+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40de60 <__swc_fn_585f006d_000032_8c89735c>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_585f006d_000030_686c93a8+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_585f006d_000036_62160bb3>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_585f006d_000030_686c93a8+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_585f006d_000042_70d5ab54>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_585f006d_000033_7d7574b6>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40a9e0 <__swc_fn_585f006d_000031_ed8d61a9>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   409720 <__swc_fn_585f006d_000129_0672cd48>
  407734:	mov    rcx,rsi
  407737:	call   40de60 <__swc_fn_585f006d_000032_8c89735c>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_585f006d_000036_62160bb3>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_585f006d_000039_05a50673>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_585f006d_000039_05a50673+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_585f006d_000039_05a50673+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_585f006d_000039_05a50673+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_585f006d_000039_05a50673+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_585f006d_000039_05a50673+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   409320 <__swc_fn_585f006d_000114_0575f585>
  4077ca:	lea    rcx,[rip+0x1b877]        # 423048 <__swc_bss_base_585f006d+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1b870]        # 423048 <__swc_bss_base_585f006d+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_585f006d_000039_05a50673+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_585f006d_000039_05a50673+0x90>
  4077f8:	lea    rcx,[rip+0x1b861]        # 423060 <__swc_bss_base_585f006d+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1b85a]        # 423060 <__swc_bss_base_585f006d+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_585f006d_000039_05a50673+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_585f006d_000039_05a50673+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_585f006d_000042_70d5ab54>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_585f006d_000042_70d5ab54+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40e430 <__swc_fn_585f006d_000059_c8e1ff6b>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   4098a0 <__swc_fn_585f006d_000135_1fec60ac>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_585f006d_000042_70d5ab54+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_585f006d_000042_70d5ab54+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_585f006d_000009_2417e911>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_585f006d_000042_70d5ab54+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40db60 <__swc_fn_585f006d_000014_1acdaf22>
  40791e:	jmp    407941 <__swc_fn_585f006d_000042_70d5ab54+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_585f006d_000042_70d5ab54+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_585f006d_000042_70d5ab54+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_585f006d_000042_70d5ab54+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40aba0 <__swc_fn_585f006d_000043_3755033a>
  407997:	mov    rcx,rdi
  40799a:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_585f006d_000039_05a50673>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_585f006d_000045_06cec934>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_585f006d_000045_06cec934+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_585f006d_000045_06cec934+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_585f006d_000045_06cec934+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_585f006d_000045_06cec934+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   4098a0 <__swc_fn_585f006d_000135_1fec60ac>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_585f006d_000045_06cec934+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_585f006d_000045_06cec934+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_585f006d_000045_06cec934+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_585f006d_000045_06cec934+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_585f006d_000009_2417e911>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_585f006d_000045_06cec934+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_585f006d_000045_06cec934+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_585f006d_000045_06cec934+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_585f006d_000045_06cec934+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_585f006d_000045_06cec934+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40a5e0 <__swc_fn_585f006d_000013_d15d37c6>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_585f006d_000045_06cec934+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_585f006d_000045_06cec934+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_585f006d_000045_06cec934+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_585f006d_000045_06cec934+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40dce0 <__swc_fn_585f006d_000020_4135c89a>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_585f006d_000045_06cec934+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40a5e0 <__swc_fn_585f006d_000013_d15d37c6>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_585f006d_000045_06cec934+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_585f006d_000021_fe13ecad>
  407c07:	mov    rcx,r14
  407c0a:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_585f006d_000045_06cec934+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_585f006d_000045_06cec934+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_585f006d_000045_06cec934+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_585f006d_000048_18a95c9b>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_585f006d_000048_18a95c9b+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_585f006d_000048_18a95c9b+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_585f006d_000048_18a95c9b+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_585f006d_000048_18a95c9b+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40e090 <__swc_fn_585f006d_000047_3d3eceb4>
  407d14:	jmp    407ce0 <__swc_fn_585f006d_000048_18a95c9b+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_585f006d_000048_18a95c9b+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_585f006d_000048_18a95c9b+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_585f006d_000048_18a95c9b+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_585f006d_000048_18a95c9b+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_585f006d_000048_18a95c9b+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_585f006d_000048_18a95c9b+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_585f006d_000048_18a95c9b+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_585f006d_000051_5b91e689>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_585f006d_000051_5b91e689+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_585f006d_000051_5b91e689+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_585f006d_000051_5b91e689+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_585f006d_000051_5b91e689+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40dff0 <__swc_fn_585f006d_000044_cac7f504>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40db60 <__swc_fn_585f006d_000014_1acdaf22>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_585f006d_000054_1dfec8f6>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   4098a0 <__swc_fn_585f006d_000135_1fec60ac>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_585f006d_000054_1dfec8f6+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_585f006d_000054_1dfec8f6+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_585f006d_000054_1dfec8f6+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_585f006d_000057_8be0372b>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_585f006d_000060_9d59636e>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_585f006d_000060_9d59636e+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_585f006d_000039_05a50673>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_585f006d_000060_9d59636e+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_585f006d_000063_3509a564>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40af20 <__swc_fn_585f006d_000052_26c6c1c4>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_585f006d_000054_1dfec8f6>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_585f006d_000063_3509a564+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_585f006d_000063_3509a564+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40b040 <__swc_fn_585f006d_000058_033ce1da>
  407f7f:	mov    rcx,rsi
  407f82:	call   40ac80 <__swc_fn_585f006d_000049_781177b4>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_585f006d_000066_77c6e829>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_585f006d_000066_77c6e829+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1b049]        # 423070 <__swc_bss_base_585f006d+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1b04b]        # 423080 <__swc_bss_base_585f006d+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_585f006d_000066_77c6e829+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_585f006d_000066_77c6e829+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40a910 <__swc_fn_585f006d_000022_77c2d682>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_585f006d_000066_77c6e829+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_585f006d_000063_3509a564>
  40808f:	jmp    408122 <__swc_fn_585f006d_000066_77c6e829+0x192>
  408094:	lea    rax,[rip+0x18f65]        # 421000 <__swc_data_base_585f006d>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_585f006d_000066_77c6e829+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_585f006d_000066_77c6e829+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_585f006d_000066_77c6e829+0x135>
  4080b8:	call   40a9e0 <__swc_fn_585f006d_000031_ed8d61a9>
  4080bd:	mov    rcx,rax
  4080c0:	call   410020 <__swc_fn_585f006d_000128_9c45d2d7>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_585f006d_000066_77c6e829+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_585f006d_000066_77c6e829+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_585f006d_000066_77c6e829+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40e090 <__swc_fn_585f006d_000047_3d3eceb4>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_585f006d_000066_77c6e829+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_585f006d_000051_5b91e689>
  408115:	jmp    408122 <__swc_fn_585f006d_000066_77c6e829+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40a550 <__swc_fn_585f006d_000010_186cd0c2>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_585f006d_000069_165b6301>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_585f006d_000036_62160bb3>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_585f006d_000069_165b6301+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1b09a]        # 423240 <__swc_bss_base_585f006d+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_585f006d_000069_165b6301+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   4098a0 <__swc_fn_585f006d_000135_1fec60ac>
  4081b5:	mov    rcx,rsi
  4081b8:	call   40e860 <__swc_fn_585f006d_000068_557d6092>
  4081bd:	mov    rcx,rsi
  4081c0:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_585f006d_000072_b2caea81>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40e5b0 <__swc_fn_585f006d_000065_cd9dd53e>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_585f006d_000075_104c4b5d>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   40e860 <__swc_fn_585f006d_000068_557d6092>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_585f006d_000078_5a70c27a>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_585f006d_000078_5a70c27a+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_585f006d_000078_5a70c27a+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_585f006d_000081_85585149>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_585f006d_000084_746bf146>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_585f006d_000090_9a1d717d>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_585f006d_000084_746bf146+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_585f006d_000084_746bf146+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_585f006d_000084_746bf146+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_585f006d_000084_746bf146+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_585f006d_000090_9a1d717d>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_585f006d_000084_746bf146+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_585f006d_000084_746bf146+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_585f006d_000084_746bf146+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_585f006d_000084_746bf146+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_585f006d_000084_746bf146+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_585f006d_000084_746bf146+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_585f006d_000084_746bf146+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_585f006d_000084_746bf146+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_585f006d_000084_746bf146+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_585f006d_000084_746bf146+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40c020 <__swc_fn_585f006d_000082_9f4f5092>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_585f006d_000084_746bf146+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_585f006d_000084_746bf146+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_585f006d_000084_746bf146+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40c020 <__swc_fn_585f006d_000082_9f4f5092>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_585f006d_000084_746bf146+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_585f006d_000084_746bf146>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_585f006d_000084_746bf146+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_585f006d_000084_746bf146+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_585f006d_000087_1fb4fcfe>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_585f006d_000090_9a1d717d>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_585f006d_000087_1fb4fcfe+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   40ecc0 <__swc_fn_585f006d_000086_ac8c6565>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_585f006d_000087_1fb4fcfe+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_585f006d_000087_1fb4fcfe+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_585f006d_000087_1fb4fcfe+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40c020 <__swc_fn_585f006d_000082_9f4f5092>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_585f006d_000087_1fb4fcfe+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_585f006d_000087_1fb4fcfe>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_585f006d_000087_1fb4fcfe+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_585f006d_000087_1fb4fcfe+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_585f006d_000090_9a1d717d>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_585f006d_000090_9a1d717d+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_585f006d_000090_9a1d717d+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_585f006d_000090_9a1d717d+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_585f006d_000090_9a1d717d+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40c020 <__swc_fn_585f006d_000082_9f4f5092>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40c020 <__swc_fn_585f006d_000082_9f4f5092>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_585f006d_000090_9a1d717d+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_585f006d_000090_9a1d717d+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_585f006d_000090_9a1d717d+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_585f006d_000090_9a1d717d+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_585f006d_000090_9a1d717d>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_585f006d_000090_9a1d717d+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_585f006d_000090_9a1d717d+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_585f006d_000090_9a1d717d+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_585f006d_000090_9a1d717d+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_585f006d_000090_9a1d717d+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_585f006d_000090_9a1d717d+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_585f006d_000090_9a1d717d+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_585f006d_000090_9a1d717d+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_585f006d_000090_9a1d717d+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_585f006d_000090_9a1d717d+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_585f006d_000090_9a1d717d+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_585f006d_000090_9a1d717d+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_585f006d_000090_9a1d717d+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_585f006d_000090_9a1d717d+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_585f006d_000090_9a1d717d+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_585f006d_000090_9a1d717d+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   409db0 <__swc_fn_585f006d_000147_c9c6528e>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_585f006d_000090_9a1d717d+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_585f006d_000090_9a1d717d>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_585f006d_000090_9a1d717d+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_585f006d_000090_9a1d717d+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_585f006d_000090_9a1d717d+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   409db0 <__swc_fn_585f006d_000147_c9c6528e>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   409db0 <__swc_fn_585f006d_000147_c9c6528e>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_585f006d_000093_344f5089>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40c150 <__swc_fn_585f006d_000091_e6773530>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_585f006d_000093_344f5089+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_585f006d_000093_344f5089+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   4101c0 <__swc_fn_585f006d_000137_899a611e>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_585f006d_000093_344f5089+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0x9872]        # 4121c0 <__swc_rdata_base_585f006d+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   40fcf0 <__swc_fn_585f006d_000116_3499f7d6>
  408959:	call   40c9d0 <__swc_fn_585f006d_000118_2b35b5e0>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_585f006d_000096_f879630a>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40896f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  408975:	vzeroupper
  408978:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40897e:	mov    QWORD PTR [rsp+0x48],rdx
  408983:	mov    rax,r8
  408986:	cmp    r8,0x1
  40898a:	mov    edx,0x1
  40898f:	cmovb  rax,rdx
  408993:	mov    QWORD PTR [rsp+0x50],rax
  408998:	mov    rbx,QWORD PTR [rcx+0x8]
  40899c:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a0:	mov    rcx,QWORD PTR [rcx]
  4089a3:	lea    rdx,[rsp+0x8]
  4089a8:	call   rbx
  4089aa:	add    rsp,0x70
  4089ae:	pop    rbx
  4089af:	ret

00000000004089b0 <__swc_fn_585f006d_000099_6e0faaee>:
  4089b0:	push   rbx
  4089b1:	push   rsi
  4089b2:	push   rdi
  4089b3:	sub    rsp,0x30
  4089b7:	mov    rbx,rcx
  4089ba:	test   rcx,rcx
  4089bd:	je     4089d2 <__swc_fn_585f006d_000099_6e0faaee+0x22>
  4089bf:	mov    rcx,rbx
  4089c2:	mov    edx,0x1
  4089c7:	call   408200 <__swc_fn_585f006d_000078_5a70c27a>
  4089cc:	cmp    rax,0x1
  4089d0:	je     4089da <__swc_fn_585f006d_000099_6e0faaee+0x2a>
  4089d2:	add    rsp,0x30
  4089d6:	pop    rdi
  4089d7:	pop    rsi
  4089d8:	pop    rbx
  4089d9:	ret
  4089da:	lea    rsi,[rsp+0x8]
  4089df:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089e4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089ea:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  4089ef:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4089f5:	mov    rax,QWORD PTR [rsp+0x20]
  4089fa:	test   rax,rax
  4089fd:	je     408a13 <__swc_fn_585f006d_000099_6e0faaee+0x63>
  4089ff:	test   DWORD PTR [rax+0x28],0x400000
  408a06:	je     408a13 <__swc_fn_585f006d_000099_6e0faaee+0x63>
  408a08:	mov    rcx,QWORD PTR [rax+0x30]
  408a0c:	test   rcx,rcx
  408a0f:	cmovne rax,rcx
  408a13:	mov    edi,DWORD PTR [rax+0x20]
  408a16:	lea    rcx,[rsp+0x18]
  408a1b:	call   40c330 <__swc_fn_585f006d_000100_2ef16a3e>
  408a20:	mov    rcx,rsi
  408a23:	mov    rdx,QWORD PTR [rsp+0x18]
  408a28:	mov    r8,rdi
  408a2b:	call   408960 <__swc_fn_585f006d_000096_f879630a>
  408a30:	mov    rcx,QWORD PTR [rbx+0x28]
  408a34:	call   40f2a0 <__swc_fn_585f006d_000098_d9d80f1a>
  408a39:	mov    rcx,rsi
  408a3c:	mov    rdx,rbx
  408a3f:	mov    r8d,0x30
  408a45:	call   408960 <__swc_fn_585f006d_000096_f879630a>
  408a4a:	add    rsp,0x30
  408a4e:	pop    rdi
  408a4f:	pop    rsi
  408a50:	pop    rbx
  408a51:	ret
	...

0000000000408a60 <__swc_fn_585f006d_000102_29a1093a>:
  408a60:	push   rbp
  408a61:	push   rbx
  408a62:	push   rsi
  408a63:	push   rdi
  408a64:	push   r12
  408a66:	push   r13
  408a68:	push   r14
  408a6a:	push   r15
  408a6c:	sub    rsp,0x500
  408a73:	mov    rbp,rsp
  408a76:	mov    rbx,rsp
  408a79:	mov    rsi,rdx
  408a7c:	mov    rdi,rcx
  408a7f:	mov    rcx,QWORD PTR [rip+0x1d2ba]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  408a86:	test   rcx,rcx
  408a89:	jne    408aa3 <__swc_fn_585f006d_000102_29a1093a+0x43>
  408a8b:	sub    rsp,0x8
  408a8f:	call   40a1a0 <__swc_fn_585f006d_000165_e09accff>
  408a94:	add    rsp,0x8
  408a98:	lea    rcx,[rax+0x1]
  408a9c:	mov    QWORD PTR [rip+0x1d29d],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  408aa3:	dec    rcx
  408aa6:	sub    rsp,0x8
  408aaa:	call   411aa0 <__swc_fn_585f006d_000167_3130645d>
  408aaf:	add    rsp,0x8
  408ab3:	mov    r12,rax
  408ab6:	mov    QWORD PTR [rsp+0x4f0],rax
  408abe:	lea    rax,[rip+0x983b]        # 412300 <__swc_rdata_base_585f006d+0x1f0>
  408ac5:	sub    rsp,0x20
  408ac9:	mov    rcx,rsp
  408acc:	mov    QWORD PTR [rcx],rax
  408acf:	lea    r13,[rip+0x983a]        # 412310 <__swc_rdata_base_585f006d+0x200>
  408ad6:	mov    QWORD PTR [rcx+0x8],r13
  408ada:	mov    QWORD PTR [rcx+0x10],rsp
  408ade:	mov    QWORD PTR [rcx+0x18],0x1
  408ae6:	lea    rcx,[rsp+0x10]
  408aeb:	sub    rsp,0x8
  408aef:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  408af4:	add    rsp,0x8
  408af8:	add    rsp,0x20
  408afc:	lea    rax,[rip+0x9855]        # 412358 <__swc_rdata_base_585f006d+0x248>
  408b03:	sub    rsp,0x20
  408b07:	mov    rcx,rsp
  408b0a:	mov    QWORD PTR [rcx],rax
  408b0d:	mov    QWORD PTR [rcx+0x8],r13
  408b11:	mov    QWORD PTR [rcx+0x10],rsp
  408b15:	mov    QWORD PTR [rcx+0x18],0x1
  408b1d:	lea    rcx,[rsp+0x10]
  408b22:	sub    rsp,0x8
  408b26:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  408b2b:	add    rsp,0x8
  408b2f:	add    rsp,0x20
  408b33:	lea    r14,[rip+0x982e]        # 412368 <__swc_rdata_base_585f006d+0x258>
  408b3a:	sub    rsp,0x50
  408b3e:	mov    rax,rsp
  408b41:	vmovups xmm0,XMMWORD PTR [rip+0x9957]        # 4124a0 <__swc_rdata_base_585f006d+0x390>
  408b49:	vmovups XMMWORD PTR [rax],xmm0
  408b4d:	mov    QWORD PTR [rax+0x10],rsp
  408b51:	mov    QWORD PTR [rax+0x18],r13
  408b55:	mov    QWORD PTR [rax+0x20],rdi
  408b59:	lea    rdi,[rip+0x9818]        # 412378 <__swc_rdata_base_585f006d+0x268>
  408b60:	mov    QWORD PTR [rax+0x28],rdi
  408b64:	mov    QWORD PTR [rax+0x30],r14
  408b68:	mov    QWORD PTR [rax+0x38],r13
  408b6c:	lea    rcx,[rsp+0x10]
  408b71:	mov    QWORD PTR [rax+0x40],rcx
  408b75:	mov    QWORD PTR [rax+0x48],0x3
  408b7d:	lea    rcx,[rsp+0x40]
  408b82:	sub    rsp,0x8
  408b86:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  408b8b:	add    rsp,0x8
  408b8f:	add    rsp,0x50
  408b93:	lea    rax,[rip+0x9826]        # 4123c0 <__swc_rdata_base_585f006d+0x2b0>
  408b9a:	sub    rsp,0x20
  408b9e:	mov    rcx,rsp
  408ba1:	mov    QWORD PTR [rcx],rax
  408ba4:	mov    QWORD PTR [rcx+0x8],r13
  408ba8:	mov    QWORD PTR [rcx+0x10],rsp
  408bac:	mov    QWORD PTR [rcx+0x18],0x1
  408bb4:	lea    rcx,[rsp+0x10]
  408bb9:	sub    rsp,0x8
  408bbd:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  408bc2:	add    rsp,0x8
  408bc6:	add    rsp,0x20
  408bca:	mov    eax,DWORD PTR [rsi+0x20]
  408bcd:	mov    ecx,DWORD PTR [rsi+0x24]
  408bd0:	sub    rsp,0xa0
  408bd7:	mov    rdx,rsp
  408bda:	mov    QWORD PTR [rdx+0x30],rsi
  408bde:	mov    QWORD PTR [rdx+0x38],rdi
  408be2:	vmovups xmm0,XMMWORD PTR [rip+0x984e]        # 412438 <__swc_rdata_base_585f006d+0x328>
  408bea:	vmovups XMMWORD PTR [rdx],xmm0
  408bee:	mov    QWORD PTR [rdx+0x40],rsp
  408bf2:	mov    QWORD PTR [rdx+0x48],r13
  408bf6:	mov    DWORD PTR [rdx+0x10],eax
  408bf9:	lea    rax,[rsp+0x10]
  408bfe:	mov    QWORD PTR [rdx+0x50],rax
  408c02:	lea    rax,[rip+0x97c7]        # 4123d0 <__swc_rdata_base_585f006d+0x2c0>
  408c09:	mov    QWORD PTR [rdx+0x58],rax
  408c0d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c12:	lea    r8,[rsp+0x18]
  408c17:	mov    QWORD PTR [rdx+0x60],r8
  408c1b:	mov    QWORD PTR [rdx+0x68],r13
  408c1f:	mov    DWORD PTR [rdx+0x28],ecx
  408c22:	lea    rcx,[rdx+0x28]
  408c26:	mov    QWORD PTR [rdx+0x70],rcx
  408c2a:	mov    QWORD PTR [rdx+0x78],rax
  408c2e:	mov    QWORD PTR [rdx+0x80],r14
  408c35:	mov    QWORD PTR [rdx+0x88],r13
  408c3c:	lea    rax,[rdx+0x30]
  408c40:	mov    QWORD PTR [rdx+0x90],rax
  408c47:	mov    QWORD PTR [rdx+0x98],0x6
  408c52:	lea    rcx,[rdx+0x90]
  408c59:	sub    rsp,0x8
  408c5d:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  408c62:	add    rsp,0x8
  408c66:	add    rsp,0xa0
  408c6d:	sub    rsp,0x20
  408c71:	mov    rax,rsp
  408c74:	mov    QWORD PTR [rax],r14
  408c77:	mov    QWORD PTR [rax+0x8],r13
  408c7b:	mov    QWORD PTR [rax+0x10],rsp
  408c7f:	mov    QWORD PTR [rax+0x18],0x1
  408c87:	lea    rcx,[rsp+0x10]
  408c8c:	sub    rsp,0x8
  408c90:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  408c95:	add    rsp,0x8
  408c99:	add    rsp,0x20
  408c9d:	mov    eax,DWORD PTR [r12+0x9ac]
  408ca5:	test   eax,eax
  408ca7:	je     408ee0 <__swc_fn_585f006d_000102_29a1093a+0x480>
  408cad:	lea    rax,[rip+0x9764]        # 412418 <__swc_rdata_base_585f006d+0x308>
  408cb4:	sub    rsp,0x20
  408cb8:	mov    rcx,rsp
  408cbb:	mov    QWORD PTR [rcx],rax
  408cbe:	mov    QWORD PTR [rcx+0x8],r13
  408cc2:	mov    QWORD PTR [rcx+0x10],rsp
  408cc6:	mov    QWORD PTR [rcx+0x18],0x1
  408cce:	lea    rcx,[rsp+0x10]
  408cd3:	sub    rsp,0x8
  408cd7:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  408cdc:	add    rsp,0x8
  408ce0:	add    rsp,0x20
  408ce4:	mov    eax,DWORD PTR [r12+0x9ac]
  408cec:	dec    eax
  408cee:	mov    esi,eax
  408cf0:	test   esi,esi
  408cf2:	jl     408eb0 <__swc_fn_585f006d_000102_29a1093a+0x450>
  408cf8:	jmp    408d04 <__swc_fn_585f006d_000102_29a1093a+0x2a4>
  408cfa:	nop    WORD PTR [rax+rax*1+0x0]
  408d00:	dec    esi
  408d02:	jmp    408cf0 <__swc_fn_585f006d_000102_29a1093a+0x290>
  408d04:	lea    rax,[rip+0x971d]        # 412428 <__swc_rdata_base_585f006d+0x318>
  408d0b:	sub    rsp,0x20
  408d0f:	mov    rcx,rsp
  408d12:	mov    QWORD PTR [rcx],rax
  408d15:	mov    QWORD PTR [rcx+0x8],r13
  408d19:	mov    QWORD PTR [rcx+0x10],rsp
  408d1d:	mov    QWORD PTR [rcx+0x18],0x1
  408d25:	lea    rcx,[rsp+0x10]
  408d2a:	sub    rsp,0x8
  408d2e:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  408d33:	add    rsp,0x8
  408d37:	add    rsp,0x20
  408d3b:	movsxd rax,esi
  408d3e:	imul   r15,rax,0x30
  408d42:	add    r15,r12
  408d45:	add    r15,0xf8
  408d4c:	sub    rsp,0x20
  408d50:	mov    rax,rsp
  408d53:	mov    QWORD PTR [rax],r15
  408d56:	mov    QWORD PTR [rax+0x8],rdi
  408d5a:	mov    QWORD PTR [rax+0x10],rsp
  408d5e:	mov    QWORD PTR [rax+0x18],0x1
  408d66:	lea    rcx,[rsp+0x10]
  408d6b:	sub    rsp,0x8
  408d6f:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  408d74:	add    rsp,0x8
  408d78:	add    rsp,0x20
  408d7c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408d84:	lea    rsi,[rip+0x96ad]        # 412438 <__swc_rdata_base_585f006d+0x328>
  408d8b:	sub    rsp,0x20
  408d8f:	mov    rax,rsp
  408d92:	mov    QWORD PTR [rax],rsi
  408d95:	mov    QWORD PTR [rax+0x8],r13
  408d99:	mov    QWORD PTR [rax+0x10],rsp
  408d9d:	mov    QWORD PTR [rax+0x18],0x1
  408da5:	lea    rcx,[rsp+0x10]
  408daa:	sub    rsp,0x8
  408dae:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  408db3:	add    rsp,0x8
  408db7:	add    rsp,0x20
  408dbb:	sub    rsp,0x30
  408dbf:	mov    rax,rsp
  408dc2:	mov    ecx,DWORD PTR [r15+0x20]
  408dc6:	mov    QWORD PTR [rax],rcx
  408dc9:	mov    QWORD PTR [rax+0x8],rsp
  408dcd:	lea    rdi,[rip+0x9674]        # 412448 <__swc_rdata_base_585f006d+0x338>
  408dd4:	mov    QWORD PTR [rax+0x10],rdi
  408dd8:	lea    rcx,[rsp+0x8]
  408ddd:	mov    QWORD PTR [rax+0x18],rcx
  408de1:	mov    QWORD PTR [rax+0x20],0x1
  408de9:	lea    rcx,[rsp+0x18]
  408dee:	sub    rsp,0x8
  408df2:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  408df7:	add    rsp,0x8
  408dfb:	add    rsp,0x30
  408dff:	sub    rsp,0x20
  408e03:	mov    rax,rsp
  408e06:	mov    QWORD PTR [rax],rsi
  408e09:	mov    QWORD PTR [rax+0x8],r13
  408e0d:	mov    QWORD PTR [rax+0x10],rsp
  408e11:	mov    QWORD PTR [rax+0x18],0x1
  408e19:	lea    rcx,[rsp+0x10]
  408e1e:	sub    rsp,0x8
  408e22:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  408e27:	add    rsp,0x8
  408e2b:	add    rsp,0x20
  408e2f:	sub    rsp,0x30
  408e33:	mov    rax,rsp
  408e36:	mov    ecx,DWORD PTR [r15+0x24]
  408e3a:	mov    QWORD PTR [rax],rcx
  408e3d:	mov    QWORD PTR [rax+0x8],rsp
  408e41:	mov    QWORD PTR [rax+0x10],rdi
  408e45:	lea    rcx,[rsp+0x8]
  408e4a:	mov    QWORD PTR [rax+0x18],rcx
  408e4e:	mov    QWORD PTR [rax+0x20],0x1
  408e56:	lea    rcx,[rsp+0x18]
  408e5b:	sub    rsp,0x8
  408e5f:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  408e64:	add    rsp,0x8
  408e68:	add    rsp,0x30
  408e6c:	sub    rsp,0x20
  408e70:	mov    rax,rsp
  408e73:	mov    QWORD PTR [rax],r14
  408e76:	mov    QWORD PTR [rax+0x8],r13
  408e7a:	mov    QWORD PTR [rax+0x10],rsp
  408e7e:	mov    QWORD PTR [rax+0x18],0x1
  408e86:	lea    rcx,[rsp+0x10]
  408e8b:	sub    rsp,0x8
  408e8f:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  408e94:	add    rsp,0x8
  408e98:	add    rsp,0x20
  408e9c:	lea    rdi,[rip+0x94d5]        # 412378 <__swc_rdata_base_585f006d+0x268>
  408ea3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408eab:	jmp    408d00 <__swc_fn_585f006d_000102_29a1093a+0x2a0>
  408eb0:	sub    rsp,0x20
  408eb4:	mov    rax,rsp
  408eb7:	mov    QWORD PTR [rax],r14
  408eba:	mov    QWORD PTR [rax+0x8],r13
  408ebe:	mov    QWORD PTR [rax+0x10],rsp
  408ec2:	mov    QWORD PTR [rax+0x18],0x1
  408eca:	lea    rcx,[rsp+0x10]
  408ecf:	sub    rsp,0x8
  408ed3:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  408ed8:	add    rsp,0x8
  408edc:	add    rsp,0x20
  408ee0:	lea    rax,[rbx+0x28]
  408ee4:	mov    rcx,rax
  408ee7:	mov    QWORD PTR [rbx+0x28],0x0
  408eef:	mov    QWORD PTR [rbx+0x30],0x0
  408ef7:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408efc:	add    rcx,0x10
  408f00:	mov    edx,0x1f
  408f05:	cs nop WORD PTR [rax+rax*1+0x0]
  408f0f:	nop
  408f10:	vmovups XMMWORD PTR [rcx],xmm0
  408f14:	add    rcx,0x10
  408f18:	sub    rdx,0x1
  408f1c:	jne    408f10 <__swc_fn_585f006d_000102_29a1093a+0x4b0>
  408f1e:	lea    rsi,[rbx+0x228]
  408f25:	xor    ecx,ecx
  408f27:	cs nop WORD PTR [rax+rax*1+0x0]
  408f31:	cs nop WORD PTR [rax+rax*1+0x0]
  408f3b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f40:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f45:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f4a:	add    rcx,0x10
  408f4e:	cmp    rcx,0x200
  408f55:	jne    408f40 <__swc_fn_585f006d_000102_29a1093a+0x4e0>
  408f57:	mov    eax,DWORD PTR [r12+0xbc8]
  408f5f:	lea    rcx,[r12+0x9c8]
  408f67:	mov    QWORD PTR [rbx+0x428],rcx
  408f6e:	mov    QWORD PTR [rbx+0x430],rax
  408f75:	lea    rdi,[rbx+0x438]
  408f7c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408f84:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408f8c:	mov    eax,DWORD PTR [r12+0xbc8]
  408f94:	test   eax,eax
  408f96:	jne    408fe3 <__swc_fn_585f006d_000102_29a1093a+0x583>
  408f98:	lea    rax,[rbx+0x448]
  408f9f:	mov    QWORD PTR [rbx+0x448],rsi
  408fa6:	mov    QWORD PTR [rax+0x8],0x40
  408fae:	mov    ecx,0x1
  408fb3:	mov    rdx,rax
  408fb6:	sub    rsp,0x8
  408fba:	call   40fe00 <__swc_fn_585f006d_000119_18cd3882>
  408fbf:	add    rsp,0x8
  408fc3:	mov    QWORD PTR [rbx+0x460],rsi
  408fca:	mov    ecx,eax
  408fcc:	mov    QWORD PTR [rbx+0x468],rcx
  408fd3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408fdb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fe3:	mov    rsi,QWORD PTR [rbx+0x438]
  408fea:	mov    rax,QWORD PTR [rbx+0x440]
  408ff1:	mov    r15,rax
  408ff4:	xor    r12d,r12d
  408ff7:	test   r15,r15
  408ffa:	je     4090b0 <__swc_fn_585f006d_000102_29a1093a+0x650>
  409000:	mov    rax,QWORD PTR [rsi+r12*8]
  409004:	test   rax,rax
  409007:	je     409026 <__swc_fn_585f006d_000102_29a1093a+0x5c6>
  409009:	lea    rcx,[rbx+0x4b8]
  409010:	mov    rdx,rax
  409013:	sub    rsp,0x8
  409017:	call   409f10 <__swc_fn_585f006d_000162_edb9cf73>
  40901c:	add    rsp,0x8
  409020:	mov    al,BYTE PTR [rax]
  409022:	test   al,al
  409024:	jne    409032 <__swc_fn_585f006d_000102_29a1093a+0x5d2>
  409026:	add    r12,0x1
  40902a:	sub    r15,0x1
  40902e:	jne    409000 <__swc_fn_585f006d_000102_29a1093a+0x5a0>
  409030:	jmp    4090b0 <__swc_fn_585f006d_000102_29a1093a+0x650>
  409032:	lea    rax,[rip+0x9457]        # 412490 <__swc_rdata_base_585f006d+0x380>
  409039:	sub    rsp,0x20
  40903d:	mov    rcx,rsp
  409040:	mov    QWORD PTR [rcx],rax
  409043:	mov    QWORD PTR [rcx+0x8],r13
  409047:	mov    QWORD PTR [rcx+0x10],rsp
  40904b:	mov    QWORD PTR [rcx+0x18],0x1
  409053:	lea    rcx,[rsp+0x10]
  409058:	sub    rsp,0x8
  40905c:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  409061:	add    rsp,0x8
  409065:	add    rsp,0x20
  409069:	mov    rcx,rdi
  40906c:	xor    edx,edx
  40906e:	mov    al,0x1
  409070:	mov    r8,rax
  409073:	sub    rsp,0x8
  409077:	call   40d260 <__swc_fn_585f006d_000163_5fbed98a>
  40907c:	add    rsp,0x8
  409080:	sub    rsp,0x20
  409084:	mov    rax,rsp
  409087:	mov    QWORD PTR [rax],r14
  40908a:	mov    QWORD PTR [rax+0x8],r13
  40908e:	mov    QWORD PTR [rax+0x10],rsp
  409092:	mov    QWORD PTR [rax+0x18],0x1
  40909a:	lea    rcx,[rsp+0x10]
  40909f:	sub    rsp,0x8
  4090a3:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  4090a8:	add    rsp,0x8
  4090ac:	add    rsp,0x20
  4090b0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090b8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090c4:	add    rsp,0x500
  4090cb:	pop    r15
  4090cd:	pop    r14
  4090cf:	pop    r13
  4090d1:	pop    r12
  4090d3:	pop    rdi
  4090d4:	pop    rsi
  4090d5:	pop    rbx
  4090d6:	pop    rbp
  4090d7:	ret
	...

00000000004090e0 <__swc_fn_585f006d_000105_b7aef7c0>:
  4090e0:	sub    rsp,0x8
  4090e4:	test   r8,r8
  4090e7:	je     4090ee <__swc_fn_585f006d_000105_b7aef7c0+0xe>
  4090e9:	call   40f530 <__swc_fn_585f006d_000104_baf871f8>
  4090ee:	add    rsp,0x8
  4090f2:	ret
	...

0000000000409100 <__swc_fn_585f006d_000108_32416b9e>:
  409100:	push   rsi
  409101:	push   rdi
  409102:	push   r12
  409104:	push   r13
  409106:	sub    rsp,0xd8
  40910d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409113:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  409119:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40911f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  409125:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40912b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  409134:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40913d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  409146:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40914f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  409158:	xor    eax,eax
  40915a:	call   407010 <getpid@plt>
  40915f:	mov    rsi,rax
  409162:	lea    rdi,[rip+0x1cbdf]        # 425d48 <__swc_bss_base_585f006d+0x2d08>
  409169:	mov    r12,QWORD PTR [rdi]
  40916c:	test   r12,r12
  40916f:	je     40917d <__swc_fn_585f006d_000108_32416b9e+0x7d>
  409171:	cmp    DWORD PTR [r12+0x10],esi
  409176:	jne    40917d <__swc_fn_585f006d_000108_32416b9e+0x7d>
  409178:	mov    rax,r12
  40917b:	jmp    4091e0 <__swc_fn_585f006d_000108_32416b9e+0xe0>
  40917d:	mov    ecx,0x4
  409182:	mov    edx,0x18
  409187:	call   40f610 <__swc_fn_585f006d_000107_ff529476>
  40918c:	mov    rcx,rax
  40918f:	test   rax,rax
  409192:	jne    409198 <__swc_fn_585f006d_000108_32416b9e+0x98>
  409194:	xor    eax,eax
  409196:	jmp    4091e0 <__swc_fn_585f006d_000108_32416b9e+0xe0>
  409198:	mov    DWORD PTR [rcx+0x10],esi
  40919b:	mov    rax,r12
  40919e:	lock cmpxchg QWORD PTR [rdi],rcx
  4091a3:	mov    r13,rax
  4091a6:	cmp    rax,r12
  4091a9:	je     4091bf <__swc_fn_585f006d_000108_32416b9e+0xbf>
  4091ab:	mov    rdi,rcx
  4091ae:	mov    esi,0x18
  4091b3:	xor    eax,eax
  4091b5:	call   407020 <munmap@plt>
  4091ba:	mov    rax,r13
  4091bd:	jmp    4091e0 <__swc_fn_585f006d_000108_32416b9e+0xe0>
  4091bf:	test   r12,r12
  4091c2:	je     4091dd <__swc_fn_585f006d_000108_32416b9e+0xdd>
  4091c4:	mov    rdi,r12
  4091c7:	mov    esi,0x18
  4091cc:	xor    eax,eax
  4091ce:	mov    QWORD PTR [rsp+0x28],rcx
  4091d3:	call   407020 <munmap@plt>
  4091d8:	mov    rcx,QWORD PTR [rsp+0x28]
  4091dd:	mov    rax,rcx
  4091e0:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  4091e6:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  4091ec:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  4091f2:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  4091f8:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  4091fe:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409207:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  409210:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409219:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  409222:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40922b:	add    rsp,0xd8
  409232:	pop    r13
  409234:	pop    r12
  409236:	pop    rdi
  409237:	pop    rsi
  409238:	ret
  409239:	add    BYTE PTR [rax],al
  40923b:	add    BYTE PTR [rax],al
  40923d:	add    BYTE PTR [rax],al
	...

0000000000409240 <__swc_fn_585f006d_000111_e724f834>:
  409240:	push   rbx
  409241:	push   r12
  409243:	push   rdi
  409244:	push   rsi
  409245:	sub    rsp,0xa8
  40924c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409252:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409258:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40925e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409264:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40926a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409270:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409276:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40927c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409285:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40928e:	mov    rbx,rdx
  409291:	mov    r12,rcx
  409294:	mov    rdi,rcx
  409297:	mov    rsi,rdx
  40929a:	mov    edx,0x3
  40929f:	xor    eax,eax
  4092a1:	call   407030 <mprotect@plt>
  4092a6:	test   eax,eax
  4092a8:	je     4092ae <__swc_fn_585f006d_000111_e724f834+0x6e>
  4092aa:	xor    eax,eax
  4092ac:	jmp    4092c3 <__swc_fn_585f006d_000111_e724f834+0x83>
  4092ae:	mov    rcx,r12
  4092b1:	mov    rdx,rbx
  4092b4:	mov    al,0x1
  4092b6:	mov    r8,rax
  4092b9:	call   40fc40 <__swc_fn_585f006d_000110_e606239a>
  4092be:	mov    eax,0x1
  4092c3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4092c9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4092cf:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4092d5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4092db:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4092e1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4092e7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4092ed:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4092f3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4092fc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409305:	add    rsp,0xa8
  40930c:	pop    rsi
  40930d:	pop    rdi
  40930e:	pop    r12
  409310:	pop    rbx
  409311:	ret
	...

0000000000409320 <__swc_fn_585f006d_000114_0575f585>:
  409320:	sub    rsp,0x8
  409324:	test   rcx,rcx
  409327:	jne    40932e <__swc_fn_585f006d_000114_0575f585+0xe>
  409329:	add    rsp,0x8
  40932d:	ret
  40932e:	call   40c880 <__swc_fn_585f006d_000115_259b5d5a>
  409333:	add    rsp,0x8
  409337:	ret
	...

0000000000409340 <__swc_fn_585f006d_000117_76ff2f0a>:
  409340:	push   rdi
  409341:	push   rsi
  409342:	sub    rsp,0xa8
  409349:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40934f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409355:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40935b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409361:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409367:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40936d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409373:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409379:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409382:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40938b:	xor    edi,edi
  40938d:	xor    eax,eax
  40938f:	call   407040 <exit@plt>
  409394:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40939a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4093a0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4093a6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4093ac:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4093b2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4093b8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4093be:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4093c4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4093cd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4093d6:	add    rsp,0xa8
  4093dd:	pop    rsi
  4093de:	pop    rdi
  4093df:	ret

00000000004093e0 <__swc_fn_585f006d_000120_1601f378>:
  4093e0:	push   rbx
  4093e1:	push   rsi
  4093e2:	push   rdi
  4093e3:	push   r12
  4093e5:	sub    rsp,0x18
  4093e9:	mov    rbx,r8
  4093ec:	mov    rsi,rcx
  4093ef:	mov    rdi,rdx
  4093f2:	mov    rcx,QWORD PTR [rip+0x1c947]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  4093f9:	test   rcx,rcx
  4093fc:	jne    40940e <__swc_fn_585f006d_000120_1601f378+0x2e>
  4093fe:	call   40a1a0 <__swc_fn_585f006d_000165_e09accff>
  409403:	lea    rcx,[rax+0x1]
  409407:	mov    QWORD PTR [rip+0x1c932],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40940e:	dec    rcx
  409411:	call   411aa0 <__swc_fn_585f006d_000167_3130645d>
  409416:	mov    r12,rax
  409419:	cmp    ebx,0x3
  40941c:	jne    40942f <__swc_fn_585f006d_000120_1601f378+0x4f>
  40941e:	mov    rax,QWORD PTR [r12+0xbd0]
  409426:	test   rax,rax
  409429:	jne    40956c <__swc_fn_585f006d_000120_1601f378+0x18c>
  40942f:	cmp    ebx,0x5
  409432:	jne    409456 <__swc_fn_585f006d_000120_1601f378+0x76>
  409434:	call   40c150 <__swc_fn_585f006d_000091_e6773530>
  409439:	test   al,al
  40943b:	jne    409456 <__swc_fn_585f006d_000120_1601f378+0x76>
  40943d:	mov    rcx,rsi
  409440:	mov    rdx,rdi
  409443:	call   411a50 <__swc_fn_585f006d_000164_15b66a30>
  409448:	test   al,al
  40944a:	je     409456 <__swc_fn_585f006d_000120_1601f378+0x76>
  40944c:	add    rsp,0x18
  409450:	pop    r12
  409452:	pop    rdi
  409453:	pop    rsi
  409454:	pop    rbx
  409455:	ret
  409456:	call   40c150 <__swc_fn_585f006d_000091_e6773530>
  40945b:	test   al,al
  40945d:	jne    4094cf <__swc_fn_585f006d_000120_1601f378+0xef>
  40945f:	vmovups xmm0,XMMWORD PTR [rsi]
  409463:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409469:	mov    rax,QWORD PTR [rsp+0x8]
  40946e:	test   rax,rax
  409471:	jne    4094c2 <__swc_fn_585f006d_000120_1601f378+0xe2>
  409473:	cmp    ebx,0x3
  409476:	je     409484 <__swc_fn_585f006d_000120_1601f378+0xa4>
  409478:	cmp    ebx,0x4
  40947b:	je     409494 <__swc_fn_585f006d_000120_1601f378+0xb4>
  40947d:	cmp    ebx,0x5
  409480:	je     4094a4 <__swc_fn_585f006d_000120_1601f378+0xc4>
  409482:	jmp    4094b4 <__swc_fn_585f006d_000120_1601f378+0xd4>
  409484:	vmovups xmm0,XMMWORD PTR [rip+0x9054]        # 4124e0 <__swc_rdata_base_585f006d+0x3d0>
  40948c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409492:	jmp    4094c2 <__swc_fn_585f006d_000120_1601f378+0xe2>
  409494:	vmovups xmm0,XMMWORD PTR [rip+0x9054]        # 4124f0 <__swc_rdata_base_585f006d+0x3e0>
  40949c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094a2:	jmp    4094c2 <__swc_fn_585f006d_000120_1601f378+0xe2>
  4094a4:	vmovups xmm0,XMMWORD PTR [rip+0x9054]        # 412500 <__swc_rdata_base_585f006d+0x3f0>
  4094ac:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094b2:	jmp    4094c2 <__swc_fn_585f006d_000120_1601f378+0xe2>
  4094b4:	vmovups xmm0,XMMWORD PTR [rip+0x9054]        # 412510 <__swc_rdata_base_585f006d+0x400>
  4094bc:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094c2:	lea    rcx,[rsp+0x8]
  4094c7:	mov    rdx,rdi
  4094ca:	call   40c3a0 <__swc_fn_585f006d_000103_2ed36338>
  4094cf:	vmovups xmm0,XMMWORD PTR [rdi]
  4094d3:	vmovups XMMWORD PTR [r12+0x940],xmm0
  4094dd:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  4094e2:	vmovups XMMWORD PTR [r12+0x950],xmm0
  4094ec:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  4094f1:	vmovups XMMWORD PTR [r12+0x960],xmm0
  4094fb:	lea    rax,[r12+0x940]
  409503:	mov    QWORD PTR [r12+0x970],rax
  40950b:	mov    rax,QWORD PTR [rsi]
  40950e:	mov    QWORD PTR [r12+0x978],rax
  409516:	mov    rax,QWORD PTR [rsi+0x8]
  40951a:	mov    QWORD PTR [r12+0x980],rax
  409522:	movsxd rax,ebx
  409525:	mov    QWORD PTR [r12+0x988],rax
  40952d:	cmp    ebx,0x5
  409530:	je     409539 <__swc_fn_585f006d_000120_1601f378+0x159>
  409532:	xor    ecx,ecx
  409534:	call   40a2d0 <__swc_fn_585f006d_000174_738eec22>
  409539:	mov    rbx,QWORD PTR [r12+0xbe8]
  409541:	test   rbx,rbx
  409544:	je     409555 <__swc_fn_585f006d_000120_1601f378+0x175>
  409546:	mov    rcx,r12
  409549:	call   rbx
  40954b:	add    rsp,0x18
  40954f:	pop    r12
  409551:	pop    rdi
  409552:	pop    rsi
  409553:	pop    rbx
  409554:	ret
  409555:	mov    rcx,rsi
  409558:	call   40fcf0 <__swc_fn_585f006d_000116_3499f7d6>
  40955d:	call   40c9d0 <__swc_fn_585f006d_000118_2b35b5e0>
  409562:	add    rsp,0x18
  409566:	pop    r12
  409568:	pop    rdi
  409569:	pop    rsi
  40956a:	pop    rbx
  40956b:	ret
  40956c:	mov    rcx,rsi
  40956f:	mov    rdx,rdi
  409572:	call   40c3a0 <__swc_fn_585f006d_000103_2ed36338>
  409577:	jmp    40942f <__swc_fn_585f006d_000120_1601f378+0x4f>
  40957c:	add    BYTE PTR [rax],al
	...

0000000000409580 <__swc_fn_585f006d_000123_e9227a3e>:
  409580:	push   rdi
  409581:	push   rsi
  409582:	sub    rsp,0xb8
  409589:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40958f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409595:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40959b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4095a1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4095a7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4095ad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4095b3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4095bc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4095c5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4095ce:	mov    DWORD PTR [rsp+0x8],0x0
  4095d6:	lea    rdi,[rsp+0x8]
  4095db:	xor    esi,esi
  4095dd:	xor    eax,eax
  4095df:	call   407050 <pthread_key_create@plt>
  4095e4:	test   eax,eax
  4095e6:	jne    4095ee <__swc_fn_585f006d_000123_e9227a3e+0x6e>
  4095e8:	mov    eax,DWORD PTR [rsp+0x8]
  4095ec:	jmp    4095f5 <__swc_fn_585f006d_000123_e9227a3e+0x75>
  4095ee:	mov    rax,0xffffffffffffffff
  4095f5:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4095fb:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409601:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409607:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40960d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409613:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409619:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40961f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409628:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409631:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40963a:	add    rsp,0xb8
  409641:	pop    rsi
  409642:	pop    rdi
  409643:	ret
	...

0000000000409650 <__swc_fn_585f006d_000126_5fb20c72>:
  409650:	push   rdi
  409651:	push   rsi
  409652:	sub    rsp,0xb8
  409659:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40965f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409665:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40966b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409671:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409677:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40967d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409683:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40968c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409695:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40969e:	mov    DWORD PTR [rsp+0x8],0x0
  4096a6:	lea    rdi,[rsp+0x8]
  4096ab:	mov    rsi,rcx
  4096ae:	xor    eax,eax
  4096b0:	call   407050 <pthread_key_create@plt>
  4096b5:	test   eax,eax
  4096b7:	jne    4096c2 <__swc_fn_585f006d_000126_5fb20c72+0x72>
  4096b9:	mov    eax,DWORD PTR [rsp+0x8]
  4096bd:	inc    rax
  4096c0:	jmp    4096c4 <__swc_fn_585f006d_000126_5fb20c72+0x74>
  4096c2:	xor    eax,eax
  4096c4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4096ca:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4096d0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4096d6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4096dc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4096e2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4096e8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4096ee:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4096f7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409700:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409709:	add    rsp,0xb8
  409710:	pop    rsi
  409711:	pop    rdi
  409712:	ret
	...

0000000000409720 <__swc_fn_585f006d_000129_0672cd48>:
  409720:	push   rdi
  409721:	push   rsi
  409722:	sub    rsp,0xa8
  409729:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40972f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409735:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40973b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409741:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409747:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40974d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409753:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409759:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409762:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40976b:	test   rcx,rcx
  40976e:	setne  al
  409771:	je     40978a <__swc_fn_585f006d_000129_0672cd48+0x6a>
  409773:	lea    rax,[rcx-0x1]
  409777:	mov    eax,eax
  409779:	mov    edi,eax
  40977b:	mov    rsi,rdx
  40977e:	xor    eax,eax
  409780:	call   407060 <pthread_setspecific@plt>
  409785:	test   eax,eax
  409787:	sete   al
  40978a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409790:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409796:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40979c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4097a2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4097a8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4097ae:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4097b4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4097ba:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4097c3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4097cc:	add    rsp,0xa8
  4097d3:	pop    rsi
  4097d4:	pop    rdi
  4097d5:	ret
	...

00000000004097e0 <__swc_fn_585f006d_000132_2b60f756>:
  4097e0:	push   rdi
  4097e1:	push   rsi
  4097e2:	sub    rsp,0xa8
  4097e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4097ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4097f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4097fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409801:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409807:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40980d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409813:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409819:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409822:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40982b:	mov    rax,rdx
  40982e:	mov    QWORD PTR [rsp],0x0
  409836:	mov    edi,0xca
  40983b:	mov    rsi,rcx
  40983e:	mov    edx,0x81
  409843:	mov    eax,eax
  409845:	mov    ecx,eax
  409847:	xor    r8d,r8d
  40984a:	xor    r9d,r9d
  40984d:	xor    eax,eax
  40984f:	call   407070 <syscall@plt>
  409854:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40985a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409860:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409866:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40986c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409872:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409878:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40987e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409884:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40988d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409896:	add    rsp,0xa8
  40989d:	pop    rsi
  40989e:	pop    rdi
  40989f:	ret

00000000004098a0 <__swc_fn_585f006d_000135_1fec60ac>:
  4098a0:	sub    rsp,0x8
  4098a4:	call   40cd70 <__swc_fn_585f006d_000133_c6de0049>
  4098a9:	add    rsp,0x8
  4098ad:	ret
	...

00000000004098b0 <__swc_fn_585f006d_000138_2214b637>:
  4098b0:	push   rdi
  4098b1:	push   rsi
  4098b2:	sub    rsp,0xc8
  4098b9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4098bf:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4098c5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4098cb:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4098d1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4098d7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4098dd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  4098e6:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  4098ef:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  4098f8:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  409901:	vxorps xmm0,xmm0,xmm0
  409905:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40990b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409911:	mov    rdi,rcx
  409914:	lea    rsi,[rsp+0x8]
  409919:	xor    eax,eax
  40991b:	call   407080 <dladdr@plt>
  409920:	xor    ecx,ecx
  409922:	test   eax,eax
  409924:	je     40992b <__swc_fn_585f006d_000138_2214b637+0x7b>
  409926:	mov    rcx,QWORD PTR [rsp+0x10]
  40992b:	mov    rax,rcx
  40992e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  409934:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40993a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  409940:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  409946:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40994c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  409952:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40995b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  409964:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40996d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  409976:	add    rsp,0xc8
  40997d:	pop    rsi
  40997e:	pop    rdi
  40997f:	ret

0000000000409980 <__swc_fn_585f006d_000141_376d5f6d>:
  409980:	push   rbx
  409981:	push   r12
  409983:	push   r13
  409985:	push   rdi
  409986:	push   rsi
  409987:	push   r14
  409989:	push   r15
  40998b:	sub    rsp,0x150
  409992:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40999b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  4099a4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  4099ad:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  4099b6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  4099bf:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4099c8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4099d1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4099da:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  4099e3:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  4099ec:	mov    rbx,rdx
  4099ef:	mov    QWORD PTR [rsp+0x98],rdx
  4099f7:	mov    r12,rcx
  4099fa:	mov    QWORD PTR [rsp+0xa0],rcx
  409a02:	mov    QWORD PTR [rbx],0x0
  409a09:	lea    r13,[rip+0x1c370]        # 425d80 <__swc_bss_base_585f006d+0x2d40>
  409a10:	mov    rcx,r13
  409a13:	call   4098a0 <__swc_fn_585f006d_000135_1fec60ac>
  409a18:	mov    rax,QWORD PTR [rip+0x1c369]        # 425d88 <__swc_bss_base_585f006d+0x2d48>
  409a1f:	test   rax,rax
  409a22:	je     409a59 <__swc_fn_585f006d_000141_376d5f6d+0xd9>
  409a24:	cs nop WORD PTR [rax+rax*1+0x0]
  409a2e:	xchg   ax,ax
  409a30:	cmp    QWORD PTR [rax+0x8],r12
  409a34:	jne    409a51 <__swc_fn_585f006d_000141_376d5f6d+0xd1>
  409a36:	mov    rcx,QWORD PTR [rax+0x18]
  409a3a:	mov    QWORD PTR [rbx],rcx
  409a3d:	mov    rbx,QWORD PTR [rax+0x10]
  409a41:	mov    rcx,r13
  409a44:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  409a49:	mov    rax,rbx
  409a4c:	jmp    409c3b <__swc_fn_585f006d_000141_376d5f6d+0x2bb>
  409a51:	mov    rax,QWORD PTR [rax]
  409a54:	test   rax,rax
  409a57:	jne    409a30 <__swc_fn_585f006d_000141_376d5f6d+0xb0>
  409a59:	vxorps xmm0,xmm0,xmm0
  409a5d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  409a63:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  409a69:	mov    rdi,r12
  409a6c:	lea    rsi,[rsp+0x10]
  409a71:	xor    eax,eax
  409a73:	call   407080 <dladdr@plt>
  409a78:	test   eax,eax
  409a7a:	sete   al
  409a7d:	je     409a8a <__swc_fn_585f006d_000141_376d5f6d+0x10a>
  409a7f:	mov    rax,QWORD PTR [rsp+0x10]
  409a84:	test   rax,rax
  409a87:	sete   al
  409a8a:	test   al,al
  409a8c:	je     409a9d <__swc_fn_585f006d_000141_376d5f6d+0x11d>
  409a8e:	mov    rcx,r13
  409a91:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  409a96:	xor    eax,eax
  409a98:	jmp    409c3b <__swc_fn_585f006d_000141_376d5f6d+0x2bb>
  409a9d:	mov    rdi,QWORD PTR [rsp+0x10]
  409aa2:	mov    esi,0x80000
  409aa7:	xor    eax,eax
  409aa9:	call   407090 <open@plt>
  409aae:	lea    r14,[rsp+0x30]
  409ab3:	mov    DWORD PTR [rsp+0x30],eax
  409ab7:	cmp    DWORD PTR [r14],0x0
  409abb:	jge    409acc <__swc_fn_585f006d_000141_376d5f6d+0x14c>
  409abd:	mov    rcx,r13
  409ac0:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  409ac5:	xor    eax,eax
  409ac7:	jmp    409c3b <__swc_fn_585f006d_000141_376d5f6d+0x2bb>
  409acc:	mov    rax,r14
  409acf:	movsxd rdi,DWORD PTR [rax]
  409ad2:	xor    esi,esi
  409ad4:	mov    edx,0x2
  409ad9:	xor    eax,eax
  409adb:	call   4070a0 <lseek@plt>
  409ae0:	mov    r15,rax
  409ae3:	test   rax,rax
  409ae6:	jg     409b01 <__swc_fn_585f006d_000141_376d5f6d+0x181>
  409ae8:	movsxd rdi,DWORD PTR [r14]
  409aeb:	xor    eax,eax
  409aed:	call   4070b0 <close@plt>
  409af2:	mov    rcx,r13
  409af5:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  409afa:	xor    eax,eax
  409afc:	jmp    409c3b <__swc_fn_585f006d_000141_376d5f6d+0x2bb>
  409b01:	xor    edi,edi
  409b03:	mov    rsi,r15
  409b06:	mov    edx,0x1
  409b0b:	mov    ecx,0x2
  409b10:	mov    rax,r14
  409b13:	movsxd r8,DWORD PTR [rax]
  409b16:	xor    r9d,r9d
  409b19:	xor    eax,eax
  409b1b:	call   4070c0 <mmap@plt>
  409b20:	mov    rbx,rax
  409b23:	test   rax,rax
  409b26:	sete   al
  409b29:	cmp    rbx,0xffffffffffffffff
  409b2d:	sete   cl
  409b30:	or     al,cl
  409b32:	je     409b4d <__swc_fn_585f006d_000141_376d5f6d+0x1cd>
  409b34:	movsxd rdi,DWORD PTR [r14]
  409b37:	xor    eax,eax
  409b39:	call   4070b0 <close@plt>
  409b3e:	mov    rcx,r13
  409b41:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  409b46:	xor    eax,eax
  409b48:	jmp    409c3b <__swc_fn_585f006d_000141_376d5f6d+0x2bb>
  409b4d:	lea    rax,[rsp+0x50]
  409b52:	mov    QWORD PTR [rax],0x0
  409b59:	mov    rcx,rbx
  409b5c:	mov    rdx,r15
  409b5f:	mov    r8,rax
  409b62:	call   410280 <__swc_fn_585f006d_000140_81b740ca>
  409b67:	mov    r12,rax
  409b6a:	test   rax,rax
  409b6d:	jne    409b95 <__swc_fn_585f006d_000141_376d5f6d+0x215>
  409b6f:	mov    rdi,rbx
  409b72:	mov    rsi,r15
  409b75:	xor    eax,eax
  409b77:	call   407020 <munmap@plt>
  409b7c:	movsxd rdi,DWORD PTR [r14]
  409b7f:	xor    eax,eax
  409b81:	call   4070b0 <close@plt>
  409b86:	mov    rcx,r13
  409b89:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  409b8e:	xor    eax,eax
  409b90:	jmp    409c3b <__swc_fn_585f006d_000141_376d5f6d+0x2bb>
  409b95:	mov    edi,0x20
  409b9a:	xor    eax,eax
  409b9c:	call   4070d0 <malloc@plt>
  409ba1:	test   rax,rax
  409ba4:	jne    409bc9 <__swc_fn_585f006d_000141_376d5f6d+0x249>
  409ba6:	mov    rdi,rbx
  409ba9:	mov    rsi,r15
  409bac:	xor    eax,eax
  409bae:	call   407020 <munmap@plt>
  409bb3:	movsxd rdi,DWORD PTR [r14]
  409bb6:	xor    eax,eax
  409bb8:	call   4070b0 <close@plt>
  409bbd:	mov    rcx,r13
  409bc0:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  409bc5:	xor    eax,eax
  409bc7:	jmp    409c3b <__swc_fn_585f006d_000141_376d5f6d+0x2bb>
  409bc9:	mov    rcx,QWORD PTR [rip+0x1c1b8]        # 425d88 <__swc_bss_base_585f006d+0x2d48>
  409bd0:	mov    QWORD PTR [rsp+0x70],rcx
  409bd5:	mov    rcx,QWORD PTR [rsp+0xa0]
  409bdd:	mov    QWORD PTR [rsp+0x78],rcx
  409be2:	mov    QWORD PTR [rsp+0x80],r12
  409bea:	mov    rcx,QWORD PTR [rsp+0x50]
  409bef:	mov    QWORD PTR [rsp+0x88],rcx
  409bf7:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  409bfd:	vmovups XMMWORD PTR [rax],xmm0
  409c01:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  409c0a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  409c0f:	mov    QWORD PTR [rip+0x1c172],rax        # 425d88 <__swc_bss_base_585f006d+0x2d48>
  409c16:	mov    rax,QWORD PTR [rsp+0x50]
  409c1b:	mov    rbx,QWORD PTR [rsp+0x98]
  409c23:	mov    QWORD PTR [rbx],rax
  409c26:	movsxd rdi,DWORD PTR [r14]
  409c29:	xor    eax,eax
  409c2b:	call   4070b0 <close@plt>
  409c30:	mov    rcx,r13
  409c33:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  409c38:	mov    rax,r12
  409c3b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  409c44:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  409c4d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  409c56:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  409c5f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  409c68:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  409c71:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  409c7a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  409c83:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  409c8c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  409c95:	add    rsp,0x150
  409c9c:	pop    r15
  409c9e:	pop    r14
  409ca0:	pop    rsi
  409ca1:	pop    rdi
  409ca2:	pop    r13
  409ca4:	pop    r12
  409ca6:	pop    rbx
  409ca7:	ret
	...

0000000000409cb0 <__swc_fn_585f006d_000144_364559f5>:
  409cb0:	push   rbx
  409cb1:	sub    rsp,0xe0
  409cb8:	lea    rbx,[rsp+0x8]
  409cbd:	vxorps xmm0,xmm0,xmm0
  409cc1:	vmovups YMMWORD PTR [rbx],ymm0
  409cc5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  409cca:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  409ccf:	vzeroupper
  409cd2:	mov    DWORD PTR [rbx+0x60],0x0
  409cd9:	mov    r8,rbx
  409cdc:	nop    DWORD PTR [rax+0x0]
  409ce0:	mov    r9,rcx
  409ce3:	movabs rcx,0xcccccccccccccccd
  409ced:	mov    rax,r9
  409cf0:	mul    rcx
  409cf3:	mov    r10,rdx
  409cf6:	shr    r10,0x3
  409cfa:	mov    rcx,r10
  409cfd:	imul   rdx,r10,0xa
  409d01:	sub    r9,rdx
  409d04:	mov    rdx,QWORD PTR [rip+0x8835]        # 412540 <__swc_rdata_base_585f006d+0x430>
  409d0b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  409d10:	mov    BYTE PTR [r8],dl
  409d13:	lea    rdx,[r8+0x1]
  409d17:	mov    r8,rdx
  409d1a:	test   r10,r10
  409d1d:	jne    409ce0 <__swc_fn_585f006d_000144_364559f5+0x30>
  409d1f:	mov    BYTE PTR [rdx],0x0
  409d22:	sub    r8,0x1
  409d26:	mov    rax,rbx
  409d29:	cmp    rax,r8
  409d2c:	jae    409d46 <__swc_fn_585f006d_000144_364559f5+0x96>
  409d2e:	xchg   ax,ax
  409d30:	mov    cl,BYTE PTR [r8]
  409d33:	mov    dl,BYTE PTR [rax]
  409d35:	mov    BYTE PTR [r8],dl
  409d38:	sub    r8,0x1
  409d3c:	mov    BYTE PTR [rax],cl
  409d3e:	inc    rax
  409d41:	cmp    rax,r8
  409d44:	jb     409d30 <__swc_fn_585f006d_000144_364559f5+0x80>
  409d46:	xor    eax,eax
  409d48:	test   rbx,rbx
  409d4b:	je     409d6e <__swc_fn_585f006d_000144_364559f5+0xbe>
  409d4d:	mov    rcx,rbx
  409d50:	mov    dl,BYTE PTR [rcx]
  409d52:	test   dl,dl
  409d54:	je     409d6e <__swc_fn_585f006d_000144_364559f5+0xbe>
  409d56:	cs nop WORD PTR [rax+rax*1+0x0]
  409d60:	add    rcx,0x1
  409d64:	add    rax,0x1
  409d68:	mov    dl,BYTE PTR [rcx]
  409d6a:	test   dl,dl
  409d6c:	jne    409d60 <__swc_fn_585f006d_000144_364559f5+0xb0>
  409d6e:	mov    QWORD PTR [rbx+0xa8],rbx
  409d75:	mov    QWORD PTR [rbx+0xb0],rax
  409d7c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  409d84:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  409d8c:	lea    rcx,[rbx+0xb8]
  409d93:	call   40fcf0 <__swc_fn_585f006d_000116_3499f7d6>
  409d98:	add    rsp,0xe0
  409d9f:	pop    rbx
  409da0:	ret
	...

0000000000409db0 <__swc_fn_585f006d_000147_c9c6528e>:
  409db0:	sub    rsp,0x8
  409db4:	mov    rax,QWORD PTR [rcx+0x8]
  409db8:	mov    r8,QWORD PTR [rdx+0x8]
  409dbc:	cmp    rax,r8
  409dbf:	je     409dc8 <__swc_fn_585f006d_000147_c9c6528e+0x18>
  409dc1:	xor    eax,eax
  409dc3:	add    rsp,0x8
  409dc7:	ret
  409dc8:	test   rax,rax
  409dcb:	jne    409ddc <__swc_fn_585f006d_000147_c9c6528e+0x2c>
  409dcd:	test   r8,r8
  409dd0:	jne    409ddc <__swc_fn_585f006d_000147_c9c6528e+0x2c>
  409dd2:	mov    eax,0x1
  409dd7:	add    rsp,0x8
  409ddb:	ret
  409ddc:	mov    rcx,QWORD PTR [rcx]
  409ddf:	mov    rdx,QWORD PTR [rdx]
  409de2:	test   rcx,rcx
  409de5:	sete   r8b
  409de9:	test   rdx,rdx
  409dec:	sete   r9b
  409df0:	or     r8b,r9b
  409df3:	je     409e00 <__swc_fn_585f006d_000147_c9c6528e+0x50>
  409df5:	cmp    rcx,rdx
  409df8:	sete   al
  409dfb:	add    rsp,0x8
  409dff:	ret
  409e00:	cmp    rcx,rdx
  409e03:	jne    409e0f <__swc_fn_585f006d_000147_c9c6528e+0x5f>
  409e05:	mov    eax,0x1
  409e0a:	add    rsp,0x8
  409e0e:	ret
  409e0f:	mov    r8,rax
  409e12:	call   40c460 <__swc_fn_585f006d_000106_77a5d54a>
  409e17:	test   eax,eax
  409e19:	sete   al
  409e1c:	add    rsp,0x8
  409e20:	ret
	...

0000000000409e30 <__swc_fn_585f006d_000150_33e5e24f>:
  409e30:	vxorps xmm0,xmm0,xmm0
  409e34:	vmovups XMMWORD PTR [rcx],xmm0
  409e38:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e3d:	vxorps xmm0,xmm0,xmm0
  409e41:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e46:	vmovups xmm0,XMMWORD PTR [rip+0x87aa]        # 4125f8 <__swc_rdata_base_585f006d+0x4e8>
  409e4e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e53:	ret
	...

0000000000409e60 <__swc_fn_585f006d_000153_33e5e24f>:
  409e60:	vxorps xmm0,xmm0,xmm0
  409e64:	vmovups XMMWORD PTR [rcx],xmm0
  409e68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e6d:	vxorps xmm0,xmm0,xmm0
  409e71:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e76:	vmovups xmm0,XMMWORD PTR [rip+0x889a]        # 412718 <__swc_rdata_base_585f006d+0x608>
  409e7e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e83:	mov    QWORD PTR [rcx+0x40],0x0
  409e8b:	ret
  409e8c:	add    BYTE PTR [rax],al
	...

0000000000409e90 <__swc_fn_585f006d_000156_312df05a>:
  409e90:	push   rbx
  409e91:	sub    rsp,0x70
  409e95:	mov    rax,QWORD PTR [rcx]
  409e98:	mov    rbx,QWORD PTR [rcx+0x8]
  409e9c:	vxorps xmm0,xmm0,xmm0
  409ea0:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  409ea6:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  409eac:	vzeroupper
  409eaf:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  409eb5:	mov    QWORD PTR [rsp+0x48],rdx
  409eba:	mov    QWORD PTR [rsp+0x50],r8
  409ebf:	mov    rcx,rax
  409ec2:	lea    rdx,[rsp+0x8]
  409ec7:	mov    rbx,QWORD PTR [rbx+0x18]
  409ecb:	call   rbx
  409ecd:	add    rsp,0x70
  409ed1:	pop    rbx
  409ed2:	ret
	...

0000000000409ee0 <__swc_fn_585f006d_000159_9d602c76>:
  409ee0:	push   rbx
  409ee1:	push   rsi
  409ee2:	push   rdi
  409ee3:	mov    rbx,r8
  409ee6:	mov    rsi,rcx
  409ee9:	mov    rdi,rdx
  409eec:	call   40d170 <__swc_fn_585f006d_000157_5c8b11d8>
  409ef1:	vmovups xmm0,XMMWORD PTR [rbx]
  409ef5:	vmovups XMMWORD PTR [rsi],xmm0
  409ef9:	mov    QWORD PTR [rsi+0x18],rdi
  409efd:	pop    rdi
  409efe:	pop    rsi
  409eff:	pop    rbx
  409f00:	ret
	...

0000000000409f10 <__swc_fn_585f006d_000162_edb9cf73>:
  409f10:	push   rbx
  409f11:	push   rsi
  409f12:	push   rdi
  409f13:	push   r12
  409f15:	push   r13
  409f17:	sub    rsp,0x50
  409f1b:	mov    rbx,rcx
  409f1e:	mov    rsi,rdx
  409f21:	vmovups xmm0,XMMWORD PTR [rip+0x88ff]        # 412828 <__swc_rdata_base_585f006d+0x718>
  409f29:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409f2f:	vmovups xmm0,XMMWORD PTR [rip+0x8901]        # 412838 <__swc_rdata_base_585f006d+0x728>
  409f37:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409f3d:	vxorps xmm0,xmm0,xmm0
  409f41:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409f47:	mov    rcx,rdx
  409f4a:	call   4098b0 <__swc_fn_585f006d_000138_2214b637>
  409f4f:	mov    rdi,rax
  409f52:	test   rax,rax
  409f55:	jne    409f86 <__swc_fn_585f006d_000162_edb9cf73+0x76>
  409f57:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409f5d:	vmovups XMMWORD PTR [rbx],xmm0
  409f61:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409f67:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409f6c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409f72:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409f77:	mov    rax,rbx
  409f7a:	add    rsp,0x50
  409f7e:	pop    r13
  409f80:	pop    r12
  409f82:	pop    rdi
  409f83:	pop    rsi
  409f84:	pop    rbx
  409f85:	ret
  409f86:	mov    rcx,rdi
  409f89:	call   4117a0 <__swc_fn_585f006d_000161_9e36e814>
  409f8e:	mov    r11,rax
  409f91:	test   rax,rax
  409f94:	je     409f9e <__swc_fn_585f006d_000162_edb9cf73+0x8e>
  409f96:	mov    al,BYTE PTR [r11+0x24]
  409f9a:	test   al,al
  409f9c:	jne    409fcd <__swc_fn_585f006d_000162_edb9cf73+0xbd>
  409f9e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fa4:	vmovups XMMWORD PTR [rbx],xmm0
  409fa8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fae:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fb3:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fb9:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fbe:	mov    rax,rbx
  409fc1:	add    rsp,0x50
  409fc5:	pop    r13
  409fc7:	pop    r12
  409fc9:	pop    rdi
  409fca:	pop    rsi
  409fcb:	pop    rbx
  409fcc:	ret
  409fcd:	sub    rsi,rdi
  409fd0:	mov    eax,0xffffffff
  409fd5:	cmp    rsi,rax
  409fd8:	jbe    40a009 <__swc_fn_585f006d_000162_edb9cf73+0xf9>
  409fda:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fe0:	vmovups XMMWORD PTR [rbx],xmm0
  409fe4:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fea:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fef:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409ff5:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409ffa:	mov    rax,rbx
  409ffd:	add    rsp,0x50
  40a001:	pop    r13
  40a003:	pop    r12
  40a005:	pop    rdi
  40a006:	pop    rsi
  40a007:	pop    rbx
  40a008:	ret
  40a009:	mov    rdi,QWORD PTR [r11+0x10]
  40a00d:	mov    eax,DWORD PTR [r11+0x20]
  40a011:	xor    ecx,ecx
  40a013:	test   rax,rax
  40a016:	jbe    40a168 <__swc_fn_585f006d_000162_edb9cf73+0x258>
  40a01c:	nop    DWORD PTR [rax+0x0]
  40a020:	mov    edx,ecx
  40a022:	imul   r12,rdx,0x14
  40a026:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40a02b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40a030:	mov    r9d,esi
  40a033:	cmp    r9,rdx
  40a036:	jb     40a15b <__swc_fn_585f006d_000162_edb9cf73+0x24b>
  40a03c:	add    rdx,r8
  40a03f:	mov    r8d,esi
  40a042:	cmp    r8,rdx
  40a045:	jae    40a15b <__swc_fn_585f006d_000162_edb9cf73+0x24b>
  40a04b:	lea    rsi,[rsp+0x38]
  40a050:	mov    eax,DWORD PTR [rdi+0xc]
  40a053:	mov    DWORD PTR [rsp+0x38],eax
  40a057:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40a05c:	mov    rcx,rdi
  40a05f:	mov    rdx,QWORD PTR [r11+0x18]
  40a063:	mov    r8,rsi
  40a066:	mov    r8d,DWORD PTR [r8]
  40a069:	mov    r9,rax
  40a06c:	lea    r10,[rsp+0x10]
  40a071:	call   40d1c0 <__swc_fn_585f006d_000160_e25d06b9>
  40a076:	test   al,al
  40a078:	jne    40a0ab <__swc_fn_585f006d_000162_edb9cf73+0x19b>
  40a07a:	vmovups xmm0,XMMWORD PTR [rip+0x87d6]        # 412858 <__swc_rdata_base_585f006d+0x748>
  40a082:	vmovups XMMWORD PTR [rbx],xmm0
  40a086:	vmovups xmm0,XMMWORD PTR [rip+0x87da]        # 412868 <__swc_rdata_base_585f006d+0x758>
  40a08e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a093:	vxorps xmm0,xmm0,xmm0
  40a097:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a09c:	mov    rax,rbx
  40a09f:	add    rsp,0x50
  40a0a3:	pop    r13
  40a0a5:	pop    r12
  40a0a7:	pop    rdi
  40a0a8:	pop    rsi
  40a0a9:	pop    rbx
  40a0aa:	ret
  40a0ab:	lea    r13,[rsp+0x3c]
  40a0b0:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40a0b5:	mov    DWORD PTR [rsp+0x3c],eax
  40a0b9:	test   eax,eax
  40a0bb:	je     40a10c <__swc_fn_585f006d_000162_edb9cf73+0x1fc>
  40a0bd:	mov    rcx,rdi
  40a0c0:	mov    rdx,QWORD PTR [r11+0x18]
  40a0c4:	mov    r8d,DWORD PTR [rsi]
  40a0c7:	mov    rax,r13
  40a0ca:	mov    r9d,DWORD PTR [rax]
  40a0cd:	lea    r10,[rsp+0x20]
  40a0d2:	call   40d1c0 <__swc_fn_585f006d_000160_e25d06b9>
  40a0d7:	test   al,al
  40a0d9:	jne    40a10c <__swc_fn_585f006d_000162_edb9cf73+0x1fc>
  40a0db:	vmovups xmm0,XMMWORD PTR [rip+0x87a5]        # 412888 <__swc_rdata_base_585f006d+0x778>
  40a0e3:	vmovups XMMWORD PTR [rbx],xmm0
  40a0e7:	vmovups xmm0,XMMWORD PTR [rip+0x87a9]        # 412898 <__swc_rdata_base_585f006d+0x788>
  40a0ef:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a0f4:	vxorps xmm0,xmm0,xmm0
  40a0f8:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a0fd:	mov    rax,rbx
  40a100:	add    rsp,0x50
  40a104:	pop    r13
  40a106:	pop    r12
  40a108:	pop    rdi
  40a109:	pop    rsi
  40a10a:	pop    rbx
  40a10b:	ret
  40a10c:	mov    eax,0x1
  40a111:	rex mov BYTE PTR [rsp+0x8],al
  40a116:	cmp    DWORD PTR [r13+0x0],0x0
  40a11b:	je     40a12c <__swc_fn_585f006d_000162_edb9cf73+0x21c>
  40a11d:	rex mov BYTE PTR [rsp+0x9],0x1
  40a123:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40a128:	mov    DWORD PTR [rsp+0x30],eax
  40a12c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a132:	vmovups XMMWORD PTR [rbx],xmm0
  40a136:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a13c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a141:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a147:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a14c:	mov    rax,rbx
  40a14f:	add    rsp,0x50
  40a153:	pop    r13
  40a155:	pop    r12
  40a157:	pop    rdi
  40a158:	pop    rsi
  40a159:	pop    rbx
  40a15a:	ret
  40a15b:	add    rcx,0x1
  40a15f:	cmp    rcx,rax
  40a162:	jb     40a020 <__swc_fn_585f006d_000162_edb9cf73+0x110>
  40a168:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a16e:	vmovups XMMWORD PTR [rbx],xmm0
  40a172:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a178:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a17d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a183:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a188:	mov    rax,rbx
  40a18b:	add    rsp,0x50
  40a18f:	pop    r13
  40a191:	pop    r12
  40a193:	pop    rdi
  40a194:	pop    rsi
  40a195:	pop    rbx
  40a196:	ret
	...

000000000040a1a0 <__swc_fn_585f006d_000165_e09accff>:
  40a1a0:	sub    rsp,0x48
  40a1a4:	call   409580 <__swc_fn_585f006d_000123_e9227a3e>
  40a1a9:	cmp    rax,0xffffffffffffffff
  40a1ad:	je     40a1b4 <__swc_fn_585f006d_000165_e09accff+0x14>
  40a1af:	add    rsp,0x48
  40a1b3:	ret
  40a1b4:	lea    rcx,[rip+0x870d]        # 4128c8 <__swc_rdata_base_585f006d+0x7b8>
  40a1bb:	vmovups xmm0,XMMWORD PTR [rip+0x8715]        # 4128d8 <__swc_rdata_base_585f006d+0x7c8>
  40a1c3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a1c9:	vmovups xmm0,XMMWORD PTR [rip+0x8717]        # 4128e8 <__swc_rdata_base_585f006d+0x7d8>
  40a1d1:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a1d7:	vmovups xmm0,XMMWORD PTR [rip+0x8719]        # 4128f8 <__swc_rdata_base_585f006d+0x7e8>
  40a1df:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a1e5:	lea    rdx,[rsp+0x8]
  40a1ea:	mov    QWORD PTR [rsp+0x38],rax
  40a1ef:	call   40c3a0 <__swc_fn_585f006d_000103_2ed36338>
  40a1f4:	mov    rax,QWORD PTR [rsp+0x38]
  40a1f9:	jmp    40a1af <__swc_fn_585f006d_000165_e09accff+0xf>
  40a1fb:	add    BYTE PTR [rax],al
  40a1fd:	add    BYTE PTR [rax],al
	...

000000000040a200 <__swc_fn_585f006d_000168_0ff0458f>:
  40a200:	push   rbx
  40a201:	push   rsi
  40a202:	sub    rsp,0x28
  40a206:	mov    rbx,rcx
  40a209:	mov    DWORD PTR [rsp+0x8],0xbf0
  40a211:	mov    ecx,0xbf0
  40a216:	call   40bf90 <__swc_fn_585f006d_000079_29fad089>
  40a21b:	mov    rsi,rax
  40a21e:	test   rax,rax
  40a221:	jne    40a22c <__swc_fn_585f006d_000168_0ff0458f+0x2c>
  40a223:	xor    eax,eax
  40a225:	add    rsp,0x28
  40a229:	pop    rsi
  40a22a:	pop    rbx
  40a22b:	ret
  40a22c:	vxorps xmm0,xmm0,xmm0
  40a230:	xor    eax,eax
  40a232:	cs nop WORD PTR [rax+rax*1+0x0]
  40a23c:	nop    DWORD PTR [rax+0x0]
  40a240:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40a245:	add    rax,0x10
  40a249:	cmp    rax,0xbf0
  40a250:	jne    40a240 <__swc_fn_585f006d_000168_0ff0458f+0x40>
  40a252:	lea    rax,[rbx+0x1]
  40a256:	mov    QWORD PTR [rsi+0x9c0],rax
  40a25d:	mov    rcx,rbx
  40a260:	mov    rdx,rsi
  40a263:	call   40d520 <__swc_fn_585f006d_000166_31ca4f53>
  40a268:	test   al,al
  40a26a:	jne    40a27d <__swc_fn_585f006d_000168_0ff0458f+0x7d>
  40a26c:	mov    rcx,rsi
  40a26f:	call   40ec70 <__swc_fn_585f006d_000080_851c599a>
  40a274:	xor    eax,eax
  40a276:	add    rsp,0x28
  40a27a:	pop    rsi
  40a27b:	pop    rbx
  40a27c:	ret
  40a27d:	lea    rcx,[rsp+0x18]
  40a282:	call   40f1f0 <__swc_fn_585f006d_000092_17e20532>
  40a287:	mov    rax,rsi
  40a28a:	add    rsp,0x28
  40a28e:	pop    rsi
  40a28f:	pop    rbx
  40a290:	ret
	...

000000000040a2a0 <__swc_fn_585f006d_000171_06b64c88>:
  40a2a0:	xor    eax,eax
  40a2a2:	mov    edx,0x1
  40a2a7:	lock cmpxchg QWORD PTR [rcx],rdx
  40a2ac:	test   rax,rax
  40a2af:	jne    40a2b2 <__swc_fn_585f006d_000171_06b64c88+0x12>
  40a2b1:	ret
  40a2b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2bc:	nop    DWORD PTR [rax+0x0]
  40a2c0:	mov    rax,QWORD PTR [rcx]
  40a2c3:	test   rax,rax
  40a2c6:	je     40a2a0 <__swc_fn_585f006d_000171_06b64c88>
  40a2c8:	jmp    40a2c0 <__swc_fn_585f006d_000171_06b64c88+0x20>
  40a2ca:	add    BYTE PTR [rax],al
  40a2cc:	add    BYTE PTR [rax],al
	...

000000000040a2d0 <__swc_fn_585f006d_000174_738eec22>:
  40a2d0:	push   rsi
  40a2d1:	push   rdi
  40a2d2:	sub    rsp,0x38
  40a2d6:	mov    rsi,rcx
  40a2d9:	call   40d530 <__swc_fn_585f006d_000169_aabbfb4c>
  40a2de:	mov    rdi,rax
  40a2e1:	call   40ccc0 <__swc_fn_585f006d_000130_d2d78689>
  40a2e6:	mov    r8,rax
  40a2e9:	mov    rcx,rdi
  40a2ec:	call   40a2a0 <__swc_fn_585f006d_000171_06b64c88>
  40a2f1:	mov    rax,QWORD PTR [rdi+0x8]
  40a2f5:	test   rax,rax
  40a2f8:	je     40a335 <__swc_fn_585f006d_000174_738eec22+0x65>
  40a2fa:	nop    WORD PTR [rax+rax*1+0x0]
  40a300:	cmp    rax,rsi
  40a303:	je     40a335 <__swc_fn_585f006d_000174_738eec22+0x65>
  40a305:	mov    r9,QWORD PTR [rax]
  40a308:	cmp    QWORD PTR [rax+0x20],r8
  40a30c:	jne    40a32d <__swc_fn_585f006d_000174_738eec22+0x5d>
  40a30e:	mov    rcx,rdi
  40a311:	mov    rdx,rax
  40a314:	mov    QWORD PTR [rsp+0x28],r8
  40a319:	mov    QWORD PTR [rsp+0x30],r9
  40a31e:	call   411bc0 <__swc_fn_585f006d_000173_156cb9fe>
  40a323:	mov    r8,QWORD PTR [rsp+0x28]
  40a328:	mov    r9,QWORD PTR [rsp+0x30]
  40a32d:	mov    rax,r9
  40a330:	test   r9,r9
  40a333:	jne    40a300 <__swc_fn_585f006d_000174_738eec22+0x30>
  40a335:	xor    eax,eax
  40a337:	mov    QWORD PTR [rdi],rax
  40a33a:	add    rsp,0x38
  40a33e:	pop    rdi
  40a33f:	pop    rsi
  40a340:	ret
	...

000000000040a350 <__swc_fn_585f006d_000177_1ca87929>:
  40a350:	push   rdi
  40a351:	push   rsi
  40a352:	sub    rsp,0xb8
  40a359:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40a35f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40a365:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40a36b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40a371:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40a377:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40a37d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40a383:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40a38c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40a395:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40a39e:	vxorps xmm0,xmm0,xmm0
  40a3a2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a3a8:	mov    edi,0x1
  40a3ad:	lea    rsi,[rsp+0x8]
  40a3b2:	xor    eax,eax
  40a3b4:	call   4070e0 <clock_gettime@plt>
  40a3b9:	vxorpd xmm0,xmm0,xmm0
  40a3bd:	mov    rax,QWORD PTR [rsp+0x8]
  40a3c2:	vcvtsi2sd xmm0,xmm0,rax
  40a3c7:	vxorpd xmm1,xmm1,xmm1
  40a3cb:	mov    rax,QWORD PTR [rsp+0x10]
  40a3d0:	vcvtsi2sd xmm1,xmm1,rax
  40a3d5:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x852b]        # 412908 <__swc_rdata_base_585f006d+0x7f8>
  40a3dd:	vaddsd xmm0,xmm0,xmm1
  40a3e1:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40a3e7:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40a3ed:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40a3f3:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40a3f9:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40a3ff:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40a405:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40a40b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40a414:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40a41d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40a426:	add    rsp,0xb8
  40a42d:	pop    rsi
  40a42e:	pop    rdi
  40a42f:	ret
	...

000000000040a440 <__swc_fn_585f006d_000001_29b04951>:
  40a440:	vxorps xmm0,xmm0,xmm0
  40a444:	xor    eax,eax
  40a446:	cs nop WORD PTR [rax+rax*1+0x0]
  40a450:	cs nop WORD PTR [rax+rax*1+0x0]
  40a45a:	nop    WORD PTR [rax+rax*1+0x0]
  40a460:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a465:	add    rax,0x10
  40a469:	cmp    rax,0x2080
  40a470:	jne    40a460 <__swc_fn_585f006d_000001_29b04951+0x20>
  40a472:	ret
	...

000000000040a480 <__swc_fn_585f006d_000004_2fa5c690>:
  40a480:	push   rsi
  40a481:	push   rdi
  40a482:	push   r12
  40a484:	push   r13
  40a486:	push   r14
  40a488:	mov    rsi,rcx
  40a48b:	mov    edi,r10d
  40a48e:	mov    r12,rcx
  40a491:	mov    r13,r9
  40a494:	mov    ecx,DWORD PTR [rdx+0x28]
  40a497:	shlx   r14d,r8d,ecx
  40a49c:	mov    rcx,rdx
  40a49f:	mov    edx,r8d
  40a4a2:	call   40db40 <__swc_fn_585f006d_000011_e75d466d>
  40a4a7:	mov    rcx,rax
  40a4aa:	mov    eax,DWORD PTR [r12+0x3c]
  40a4af:	xor    edx,edx
  40a4b1:	div    rdi
  40a4b4:	vxorps xmm0,xmm0,xmm0
  40a4b8:	vmovdqu XMMWORD PTR [rsi],xmm0
  40a4bc:	mov    QWORD PTR [r12+0x60],0x0
  40a4c5:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40a4ca:	mov    QWORD PTR [r12+0x10],rcx
  40a4cf:	imul   rax,rdi
  40a4d3:	lea    rdx,[rcx+rax*1]
  40a4d7:	mov    QWORD PTR [r12+0x18],rdx
  40a4dc:	mov    QWORD PTR [r12+0x20],rcx
  40a4e1:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40a4e6:	mov    DWORD PTR [r12+0x28],0x0
  40a4ef:	mov    DWORD PTR [r12+0x68],0x0
  40a4f8:	mov    BYTE PTR [r12+0x39],r13b
  40a4fd:	mov    BYTE PTR [r12+0x3a],r14b
  40a502:	mov    BYTE PTR [r12+0x3b],0x1
  40a508:	mov    DWORD PTR [r12+0x6c],0x0
  40a511:	mov    rcx,r12
  40a514:	mov    edx,edi
  40a516:	call   40daa0 <__swc_fn_585f006d_000005_bcc5b80b>
  40a51b:	pop    r14
  40a51d:	pop    r13
  40a51f:	pop    r12
  40a521:	pop    rdi
  40a522:	pop    rsi
  40a523:	ret
	...

000000000040a530 <__swc_fn_585f006d_000007_635028f3>:
  40a530:	mov    r8d,0x1
  40a536:	xor    eax,eax
  40a538:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40a53e:	test   eax,eax
  40a540:	jne    40a530 <__swc_fn_585f006d_000007_635028f3>
  40a542:	ret
	...

000000000040a550 <__swc_fn_585f006d_000010_186cd0c2>:
  40a550:	lea    r8,[rcx+0x60]
  40a554:	mov    rax,QWORD PTR [r8]
  40a557:	mov    r9,rax
  40a55a:	nop    WORD PTR [rax+rax*1+0x0]
  40a560:	mov    QWORD PTR [rdx],r9
  40a563:	mov    rax,r9
  40a566:	lock cmpxchg QWORD PTR [r8],rdx
  40a56b:	cmp    rax,r9
  40a56e:	jne    40a5d7 <__swc_fn_585f006d_000010_186cd0c2+0x87>
  40a570:	mov    eax,DWORD PTR [rcx+0x6c]
  40a573:	test   eax,eax
  40a575:	je     40a5d6 <__swc_fn_585f006d_000010_186cd0c2+0x86>
  40a577:	lea    rdx,[rcx+0x70]
  40a57b:	mov    r9d,0x1
  40a581:	xor    eax,eax
  40a583:	lock cmpxchg DWORD PTR [rdx],r9d
  40a588:	test   eax,eax
  40a58a:	jne    40a5d6 <__swc_fn_585f006d_000010_186cd0c2+0x86>
  40a58c:	mov    rax,rcx
  40a58f:	and    rax,0xffffffffffc00000
  40a596:	mov    rax,QWORD PTR [rax+0x8]
  40a59a:	test   rax,rax
  40a59d:	jne    40a5a5 <__swc_fn_585f006d_000010_186cd0c2+0x55>
  40a59f:	xor    eax,eax
  40a5a1:	xchg   DWORD PTR [rdx],eax
  40a5a3:	jmp    40a5d6 <__swc_fn_585f006d_000010_186cd0c2+0x86>
  40a5a5:	lea    rdx,[rax+0x2a80]
  40a5ac:	mov    rax,QWORD PTR [rdx]
  40a5af:	mov    r8,rax
  40a5b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5bc:	nop    DWORD PTR [rax+0x0]
  40a5c0:	mov    QWORD PTR [rcx+0x78],r8
  40a5c4:	mov    rax,r8
  40a5c7:	lock cmpxchg QWORD PTR [rdx],rcx
  40a5cc:	cmp    rax,r8
  40a5cf:	je     40a5d6 <__swc_fn_585f006d_000010_186cd0c2+0x86>
  40a5d1:	mov    r8,rax
  40a5d4:	jmp    40a5c0 <__swc_fn_585f006d_000010_186cd0c2+0x70>
  40a5d6:	ret
  40a5d7:	mov    r9,rax
  40a5da:	jmp    40a560 <__swc_fn_585f006d_000010_186cd0c2+0x10>
	...

000000000040a5e0 <__swc_fn_585f006d_000013_d15d37c6>:
  40a5e0:	push   rsi
  40a5e1:	push   rdi
  40a5e2:	push   r12
  40a5e4:	push   r13
  40a5e6:	push   r14
  40a5e8:	push   r15
  40a5ea:	push   rbx
  40a5eb:	sub    rsp,0x30
  40a5ef:	mov    QWORD PTR [rsp+0x18],r8
  40a5f4:	mov    rsi,rcx
  40a5f7:	mov    rdi,rdx
  40a5fa:	mov    rdx,QWORD PTR [rsi+0x40]
  40a5fe:	xchg   ax,ax
  40a600:	mov    rax,rdx
  40a603:	not    rax
  40a606:	and    rax,QWORD PTR [rsi+0x20]
  40a60a:	test   rax,rax
  40a60d:	jne    40a621 <__swc_fn_585f006d_000013_d15d37c6+0x41>
  40a60f:	xor    eax,eax
  40a611:	add    rsp,0x30
  40a615:	pop    rbx
  40a616:	pop    r15
  40a618:	pop    r14
  40a61a:	pop    r13
  40a61c:	pop    r12
  40a61e:	pop    rdi
  40a61f:	pop    rsi
  40a620:	ret
  40a621:	xor    ecx,ecx
  40a623:	tzcnt  rcx,rax
  40a628:	lea    r12,[rsp+0x8]
  40a62d:	mov    DWORD PTR [rsp+0x8],ecx
  40a631:	mov    r13d,0x1
  40a637:	shl    r13,cl
  40a63a:	mov    rcx,rdx
  40a63d:	or     rcx,r13
  40a640:	mov    rax,rdx
  40a643:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40a649:	cmp    rax,rdx
  40a64c:	je     40a653 <__swc_fn_585f006d_000013_d15d37c6+0x73>
  40a64e:	mov    rdx,rax
  40a651:	jmp    40a600 <__swc_fn_585f006d_000013_d15d37c6+0x20>
  40a653:	mov    eax,DWORD PTR [r12]
  40a657:	shl    rax,0x4
  40a65b:	lea    r14,[rsi+rax*8+0x80]
  40a663:	mov    rcx,rsi
  40a666:	mov    rax,r12
  40a669:	mov    edx,DWORD PTR [rax]
  40a66b:	call   40db40 <__swc_fn_585f006d_000011_e75d466d>
  40a670:	mov    r15,rax
  40a673:	mov    rcx,rsi
  40a676:	mov    rdx,r13
  40a679:	call   40dca0 <__swc_fn_585f006d_000017_e238d24c>
  40a67e:	test   al,al
  40a680:	je     40a6b8 <__swc_fn_585f006d_000013_d15d37c6+0xd8>
  40a682:	mov    ecx,DWORD PTR [r14+0x3c]
  40a686:	lea    rdx,[rip+0x189cb]        # 423058 <__swc_bss_base_585f006d+0x18>
  40a68d:	mov    r8,QWORD PTR [rip+0x189c4]        # 423058 <__swc_bss_base_585f006d+0x18>
  40a694:	cs nop WORD PTR [rax+rax*1+0x0]
  40a69e:	xchg   ax,ax
  40a6a0:	mov    r9,r8
  40a6a3:	sub    r9,rcx
  40a6a6:	mov    rax,r8
  40a6a9:	lock cmpxchg QWORD PTR [rdx],r9
  40a6ae:	cmp    rax,r8
  40a6b1:	je     40a719 <__swc_fn_585f006d_000013_d15d37c6+0x139>
  40a6b3:	mov    r8,rax
  40a6b6:	jmp    40a6a0 <__swc_fn_585f006d_000013_d15d37c6+0xc0>
  40a6b8:	mov    rcx,rsi
  40a6bb:	mov    rax,r12
  40a6be:	mov    edx,DWORD PTR [rax]
  40a6c0:	call   407450 <__swc_fn_585f006d_000012_39679ef8>
  40a6c5:	mov    rcx,r15
  40a6c8:	and    rcx,0xffffffffffff0000
  40a6cf:	lea    rcx,[rcx+0x10000]
  40a6d6:	mov    rbx,rax
  40a6d9:	cmp    rax,rcx
  40a6dc:	cmova  rbx,rcx
  40a6e0:	mov    rax,rbx
  40a6e3:	sub    rax,r15
  40a6e6:	mov    rcx,r15
  40a6e9:	mov    rdx,rax
  40a6ec:	call   4072a0 <__swc_fn_585f006d_000003_644dadb7>
  40a6f1:	test   al,al
  40a6f3:	jne    40a712 <__swc_fn_585f006d_000013_d15d37c6+0x132>
  40a6f5:	mov    rcx,rsi
  40a6f8:	mov    rdx,r13
  40a6fb:	call   407600 <__swc_fn_585f006d_000018_e2e8e4b0>
  40a700:	xor    eax,eax
  40a702:	add    rsp,0x30
  40a706:	pop    rbx
  40a707:	pop    r15
  40a709:	pop    r14
  40a70b:	pop    r13
  40a70d:	pop    r12
  40a70f:	pop    rdi
  40a710:	pop    rsi
  40a711:	ret
  40a712:	sub    rbx,r15
  40a715:	mov    DWORD PTR [r14+0x3c],ebx
  40a719:	mov    rcx,r14
  40a71c:	mov    rdx,rsi
  40a71f:	mov    r8d,DWORD PTR [r12]
  40a723:	mov    r9d,edi
  40a726:	mov    rbx,QWORD PTR [rsp+0x18]
  40a72b:	mov    r10d,ebx
  40a72e:	call   40a480 <__swc_fn_585f006d_000004_2fa5c690>
  40a733:	mov    rax,r14
  40a736:	add    rsp,0x30
  40a73a:	pop    rbx
  40a73b:	pop    r15
  40a73d:	pop    r14
  40a73f:	pop    r13
  40a741:	pop    r12
  40a743:	pop    rdi
  40a744:	pop    rsi
  40a745:	ret
	...

000000000040a750 <__swc_fn_585f006d_000016_89da4d6e>:
  40a750:	mov    r8,QWORD PTR [rcx+0x48]
  40a754:	cs nop WORD PTR [rax+rax*1+0x0]
  40a75e:	xchg   ax,ax
  40a760:	mov    r9,r8
  40a763:	or     r9,rdx
  40a766:	mov    rax,r8
  40a769:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40a76f:	cmp    rax,r8
  40a772:	jne    40a775 <__swc_fn_585f006d_000016_89da4d6e+0x25>
  40a774:	ret
  40a775:	mov    r8,rax
  40a778:	jmp    40a760 <__swc_fn_585f006d_000016_89da4d6e+0x10>
  40a77a:	add    BYTE PTR [rax],al
  40a77c:	add    BYTE PTR [rax],al
	...

000000000040a780 <__swc_fn_585f006d_000019_60e50998>:
  40a780:	push   rsi
  40a781:	push   rdi
  40a782:	push   r12
  40a784:	mov    rsi,rcx
  40a787:	xor    edi,edi
  40a789:	lea    r12,[rip+0x188d8]        # 423068 <__swc_bss_base_585f006d+0x28>
  40a790:	mov    eax,DWORD PTR [r12]
  40a794:	xor    ecx,ecx
  40a796:	test   rax,rax
  40a799:	jbe    40a7d4 <__swc_fn_585f006d_000019_60e50998+0x54>
  40a79b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a7a0:	lea    rdx,[rip+0x188c9]        # 423070 <__swc_bss_base_585f006d+0x30>
  40a7a7:	mov    r8d,ecx
  40a7aa:	lea    r8,[r8+r8*2]
  40a7ae:	lea    r8,[rdx+r8*8]
  40a7b2:	mov    rdx,QWORD PTR [r8+0x10]
  40a7b6:	add    rdx,0x400000
  40a7bd:	cmp    rdx,0x40000000
  40a7c4:	ja     40a7cb <__swc_fn_585f006d_000019_60e50998+0x4b>
  40a7c6:	mov    rdi,r8
  40a7c9:	jmp    40a7d4 <__swc_fn_585f006d_000019_60e50998+0x54>
  40a7cb:	add    rcx,0x1
  40a7cf:	cmp    rcx,rax
  40a7d2:	jb     40a7a0 <__swc_fn_585f006d_000019_60e50998+0x20>
  40a7d4:	test   rdi,rdi
  40a7d7:	jne    40a863 <__swc_fn_585f006d_000019_60e50998+0xe3>
  40a7dd:	cmp    DWORD PTR [r12],0x10
  40a7e2:	jae    40a84b <__swc_fn_585f006d_000019_60e50998+0xcb>
  40a7e4:	mov    ecx,0x40400000
  40a7e9:	call   40da60 <__swc_fn_585f006d_000002_390d5093>
  40a7ee:	test   rax,rax
  40a7f1:	je     40a84b <__swc_fn_585f006d_000019_60e50998+0xcb>
  40a7f3:	lea    rcx,[rip+0x18876]        # 423070 <__swc_bss_base_585f006d+0x30>
  40a7fa:	mov    edx,DWORD PTR [r12]
  40a7fe:	lea    rdx,[rdx+rdx*2]
  40a802:	lea    rdx,[rcx+rdx*8]
  40a806:	mov    QWORD PTR [rdx],rax
  40a809:	lea    rax,[rax+0x3fffff]
  40a810:	and    rax,0xffffffffffc00000
  40a817:	mov    QWORD PTR [rdx+0x8],rax
  40a81b:	mov    QWORD PTR [rdx+0x10],0x0
  40a823:	mov    edx,DWORD PTR [rip+0x1883f]        # 423068 <__swc_bss_base_585f006d+0x28>
  40a829:	nop    DWORD PTR [rax+0x0]
  40a830:	lea    r9d,[rdx+0x1]
  40a834:	mov    rax,rdx
  40a837:	lock cmpxchg DWORD PTR [r12],r9d
  40a83d:	mov    r8d,eax
  40a840:	cmp    eax,edx
  40a842:	je     40a852 <__swc_fn_585f006d_000019_60e50998+0xd2>
  40a844:	mov    rdx,r8
  40a847:	jmp    40a830 <__swc_fn_585f006d_000019_60e50998+0xb0>
  40a849:	jmp    40a852 <__swc_fn_585f006d_000019_60e50998+0xd2>
  40a84b:	xor    eax,eax
  40a84d:	pop    r12
  40a84f:	pop    rdi
  40a850:	pop    rsi
  40a851:	ret
  40a852:	mov    eax,DWORD PTR [rip+0x18810]        # 423068 <__swc_bss_base_585f006d+0x28>
  40a858:	sub    eax,0x1
  40a85b:	lea    rdi,[rax+rax*2]
  40a85f:	lea    rdi,[rcx+rdi*8]
  40a863:	mov    r12,QWORD PTR [rdi+0x8]
  40a867:	add    r12,QWORD PTR [rdi+0x10]
  40a86b:	mov    rcx,r12
  40a86e:	mov    edx,0x3000
  40a873:	call   4072a0 <__swc_fn_585f006d_000003_644dadb7>
  40a878:	test   al,al
  40a87a:	jne    40a883 <__swc_fn_585f006d_000019_60e50998+0x103>
  40a87c:	xor    eax,eax
  40a87e:	pop    r12
  40a880:	pop    rdi
  40a881:	pop    rsi
  40a882:	ret
  40a883:	vxorps xmm0,xmm0,xmm0
  40a887:	xor    eax,eax
  40a889:	cs nop WORD PTR [rax+rax*1+0x0]
  40a893:	cs nop WORD PTR [rax+rax*1+0x0]
  40a89d:	nop    DWORD PTR [rax]
  40a8a0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40a8a6:	add    rax,0x10
  40a8aa:	cmp    rax,0x3000
  40a8b1:	jne    40a8a0 <__swc_fn_585f006d_000019_60e50998+0x120>
  40a8b3:	mov    DWORD PTR [r12+0x28],esi
  40a8b8:	mov    eax,0x40
  40a8bd:	mov    ecx,esi
  40a8bf:	shr    eax,cl
  40a8c1:	mov    DWORD PTR [r12+0x2c],eax
  40a8c6:	cmp    DWORD PTR [r12+0x2c],0x40
  40a8cc:	jb     40a8d7 <__swc_fn_585f006d_000019_60e50998+0x157>
  40a8ce:	mov    rax,0xffffffffffffffff
  40a8d5:	jmp    40a8e7 <__swc_fn_585f006d_000019_60e50998+0x167>
  40a8d7:	mov    eax,0x1
  40a8dc:	mov    ecx,DWORD PTR [r12+0x2c]
  40a8e1:	shl    rax,cl
  40a8e4:	dec    rax
  40a8e7:	mov    QWORD PTR [r12+0x20],rax
  40a8ec:	mov    DWORD PTR [r12],0x4e540001
  40a8f4:	mov    DWORD PTR [r12+0x4],0x53474d45
  40a8fd:	add    QWORD PTR [rdi+0x10],0x400000
  40a905:	mov    rax,r12
  40a908:	pop    r12
  40a90a:	pop    rdi
  40a90b:	pop    rsi
  40a90c:	ret
  40a90d:	add    BYTE PTR [rax],al
	...

000000000040a910 <__swc_fn_585f006d_000022_77c2d682>:
  40a910:	mov    eax,0x1
  40a915:	mov    edx,DWORD PTR [rip+0x1874d]        # 423068 <__swc_bss_base_585f006d+0x28>
  40a91b:	cmp    eax,edx
  40a91d:	jae    40a96b <__swc_fn_585f006d_000022_77c2d682+0x5b>
  40a91f:	nop
  40a920:	lea    r8,[rip+0x18749]        # 423070 <__swc_bss_base_585f006d+0x30>
  40a927:	lea    r9,[rax+rax*2]
  40a92b:	lea    r9,[r8+r9*8]
  40a92f:	mov    r8,rcx
  40a932:	sub    r8,QWORD PTR [r9+0x8]
  40a936:	mov    r9,QWORD PTR [r9+0x10]
  40a93a:	cmp    r8,r9
  40a93d:	jae    40a965 <__swc_fn_585f006d_000022_77c2d682+0x55>
  40a93f:	mov    rax,rcx
  40a942:	and    rax,0xffffffffffc00000
  40a949:	shr    rcx,0x10
  40a94d:	and    ecx,0x3f
  40a950:	mov    edx,DWORD PTR [rax+0x28]
  40a953:	shrx   ecx,ecx,edx
  40a958:	shl    rcx,0x4
  40a95c:	lea    rax,[rax+rcx*8+0x80]
  40a964:	ret
  40a965:	inc    eax
  40a967:	cmp    eax,edx
  40a969:	jb     40a920 <__swc_fn_585f006d_000022_77c2d682+0x10>
  40a96b:	xor    eax,eax
  40a96d:	ret
	...

000000000040a970 <__swc_fn_585f006d_000025_7e9350e1>:
  40a970:	vxorps xmm0,xmm0,xmm0
  40a974:	vmovups XMMWORD PTR [rcx],xmm0
  40a978:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a97d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a982:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a987:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40a98c:	mov    QWORD PTR [rcx+0x50],0x0
  40a994:	ret
	...

000000000040a9a0 <__swc_fn_585f006d_000028_7e9350e1>:
  40a9a0:	vxorps xmm0,xmm0,xmm0
  40a9a4:	xor    eax,eax
  40a9a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9b0:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9ba:	nop    WORD PTR [rax+rax*1+0x0]
  40a9c0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a9c5:	add    rax,0x10
  40a9c9:	cmp    rax,0x9b0
  40a9d0:	jne    40a9c0 <__swc_fn_585f006d_000028_7e9350e1+0x20>
  40a9d2:	mov    QWORD PTR [rcx+0x9b0],0x0
  40a9dd:	ret
	...

000000000040a9e0 <__swc_fn_585f006d_000031_ed8d61a9>:
  40a9e0:	push   rsi
  40a9e1:	push   rdi
  40a9e2:	sub    rsp,0x8
  40a9e6:	lea    rsi,[rip+0x1661b]        # 421008 <__swc_data_base_585f006d+0x8>
  40a9ed:	mov    rax,QWORD PTR [rsi]
  40a9f0:	mov    ecx,0xffffffff
  40a9f5:	cmp    rax,rcx
  40a9f8:	je     40aa01 <__swc_fn_585f006d_000031_ed8d61a9+0x21>
  40a9fa:	add    rsp,0x8
  40a9fe:	pop    rdi
  40a9ff:	pop    rsi
  40aa00:	ret
  40aa01:	mov    rcx,QWORD PTR [rip+0x7678]        # 412080 <__swc_fn_585f006d_000176_5d3d19bd+0x440>
  40aa08:	call   409650 <__swc_fn_585f006d_000126_5fb20c72>
  40aa0d:	mov    rcx,rax
  40aa10:	mov    eax,0xffffffff
  40aa15:	lock cmpxchg QWORD PTR [rsi],rcx
  40aa1a:	mov    rdi,rax
  40aa1d:	mov    eax,0xffffffff
  40aa22:	cmp    rdi,rax
  40aa25:	je     40aa36 <__swc_fn_585f006d_000031_ed8d61a9+0x56>
  40aa27:	call   40cc10 <__swc_fn_585f006d_000127_75f8ab5c>
  40aa2c:	mov    rax,rdi
  40aa2f:	add    rsp,0x8
  40aa33:	pop    rdi
  40aa34:	pop    rsi
  40aa35:	ret
  40aa36:	mov    rax,rcx
  40aa39:	add    rsp,0x8
  40aa3d:	pop    rdi
  40aa3e:	pop    rsi
  40aa3f:	ret

000000000040aa40 <__swc_fn_585f006d_000034_c72914a2>:
  40aa40:	sub    rsp,0x8
  40aa44:	vxorps xmm0,xmm0,xmm0
  40aa48:	xor    eax,eax
  40aa4a:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa54:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa5e:	xchg   ax,ax
  40aa60:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40aa65:	add    rax,0x10
  40aa69:	cmp    rax,0x2b00
  40aa70:	jne    40aa60 <__swc_fn_585f006d_000034_c72914a2+0x20>
  40aa72:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40aa7c:	xor    al,al
  40aa7e:	mov    rdx,rax
  40aa81:	xor    al,al
  40aa83:	mov    r8,rax
  40aa86:	xor    al,al
  40aa88:	mov    r9,rax
  40aa8b:	xor    al,al
  40aa8d:	mov    r10,rax
  40aa90:	xor    al,al
  40aa92:	mov    r11,rax
  40aa95:	call   40ded0 <__swc_fn_585f006d_000035_6105596e>
  40aa9a:	add    rsp,0x8
  40aa9e:	ret
	...

000000000040aaa0 <__swc_fn_585f006d_000037_92e867c2>:
  40aaa0:	push   rsi
  40aaa1:	push   rdi
  40aaa2:	push   r12
  40aaa4:	mov    rsi,r8
  40aaa7:	mov    rdi,rdx
  40aaaa:	mov    rcx,rdx
  40aaad:	call   40da60 <__swc_fn_585f006d_000002_390d5093>
  40aab2:	mov    r12,rax
  40aab5:	test   rax,rax
  40aab8:	jne    40aac1 <__swc_fn_585f006d_000037_92e867c2+0x21>
  40aaba:	xor    eax,eax
  40aabc:	pop    r12
  40aabe:	pop    rdi
  40aabf:	pop    rsi
  40aac0:	ret
  40aac1:	mov    rcx,r12
  40aac4:	mov    rdx,rsi
  40aac7:	call   4072a0 <__swc_fn_585f006d_000003_644dadb7>
  40aacc:	test   al,al
  40aace:	jne    40aae2 <__swc_fn_585f006d_000037_92e867c2+0x42>
  40aad0:	mov    rcx,r12
  40aad3:	mov    rdx,rdi
  40aad6:	call   40fcd0 <__swc_fn_585f006d_000113_25e345b1>
  40aadb:	xor    eax,eax
  40aadd:	pop    r12
  40aadf:	pop    rdi
  40aae0:	pop    rsi
  40aae1:	ret
  40aae2:	mov    rax,r12
  40aae5:	pop    r12
  40aae7:	pop    rdi
  40aae8:	pop    rsi
  40aae9:	ret
	...

000000000040ab00 <__swc_fn_585f006d_000040_7a225310>:
  40ab00:	push   rsi
  40ab01:	push   rdi
  40ab02:	push   r12
  40ab04:	mov    rsi,rcx
  40ab07:	mov    edx,0x9b8
  40ab0c:	call   40df40 <__swc_fn_585f006d_000038_c7591393>
  40ab11:	mov    rdi,rax
  40ab14:	test   rax,rax
  40ab17:	jne    40ab20 <__swc_fn_585f006d_000040_7a225310+0x20>
  40ab19:	xor    eax,eax
  40ab1b:	pop    r12
  40ab1d:	pop    rdi
  40ab1e:	pop    rsi
  40ab1f:	ret
  40ab20:	vxorps xmm0,xmm0,xmm0
  40ab24:	xor    eax,eax
  40ab26:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab30:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab3a:	nop    WORD PTR [rax+rax*1+0x0]
  40ab40:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40ab45:	add    rax,0x10
  40ab49:	cmp    rax,0x9b0
  40ab50:	jne    40ab40 <__swc_fn_585f006d_000040_7a225310+0x40>
  40ab52:	mov    QWORD PTR [rdi+0x9b0],0x0
  40ab5d:	mov    QWORD PTR [rdi],rsi
  40ab60:	call   40ccc0 <__swc_fn_585f006d_000130_d2d78689>
  40ab65:	mov    QWORD PTR [rdi+0x18],rax
  40ab69:	lea    r12,[rsi+0x10]
  40ab6d:	mov    rcx,r12
  40ab70:	call   4098a0 <__swc_fn_585f006d_000135_1fec60ac>
  40ab75:	mov    rax,QWORD PTR [rsi+0x20]
  40ab79:	mov    QWORD PTR [rdi+0x8],rax
  40ab7d:	mov    rax,QWORD PTR [rsi+0x20]
  40ab81:	test   rax,rax
  40ab84:	je     40ab8a <__swc_fn_585f006d_000040_7a225310+0x8a>
  40ab86:	mov    QWORD PTR [rax+0x10],rdi
  40ab8a:	mov    QWORD PTR [rsi+0x20],rdi
  40ab8e:	mov    rcx,r12
  40ab91:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  40ab96:	mov    rax,rdi
  40ab99:	pop    r12
  40ab9b:	pop    rdi
  40ab9c:	pop    rsi
  40ab9d:	ret
	...

000000000040aba0 <__swc_fn_585f006d_000043_3755033a>:
  40aba0:	mov    rax,QWORD PTR [rdx+0x10]
  40aba4:	test   rax,rax
  40aba7:	je     40abb3 <__swc_fn_585f006d_000043_3755033a+0x13>
  40aba9:	mov    rcx,QWORD PTR [rdx+0x8]
  40abad:	mov    QWORD PTR [rax+0x8],rcx
  40abb1:	jmp    40abbb <__swc_fn_585f006d_000043_3755033a+0x1b>
  40abb3:	mov    rax,QWORD PTR [rdx+0x8]
  40abb7:	mov    QWORD PTR [rcx+0x20],rax
  40abbb:	mov    rax,QWORD PTR [rdx+0x8]
  40abbf:	test   rax,rax
  40abc2:	je     40abcc <__swc_fn_585f006d_000043_3755033a+0x2c>
  40abc4:	mov    rcx,QWORD PTR [rdx+0x10]
  40abc8:	mov    QWORD PTR [rax+0x10],rcx
  40abcc:	vxorps xmm0,xmm0,xmm0
  40abd0:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40abd5:	ret
	...

000000000040abe0 <__swc_fn_585f006d_000046_49300800>:
  40abe0:	sub    rsp,0x8
  40abe4:	mov    r9,r8
  40abe7:	mov    r10,rdx
  40abea:	call   40dff0 <__swc_fn_585f006d_000044_cac7f504>
  40abef:	mov    eax,0x1
  40abf4:	xchg   DWORD PTR [r9+0x6c],eax
  40abf8:	mov    rax,QWORD PTR [r9+0x60]
  40abfc:	test   rax,rax
  40abff:	je     40ac43 <__swc_fn_585f006d_000046_49300800+0x63>
  40ac01:	xor    eax,eax
  40ac03:	xchg   DWORD PTR [r9+0x6c],eax
  40ac07:	movzx  eax,BYTE PTR [r9+0x39]
  40ac0c:	lea    rax,[rax+rax*4]
  40ac10:	lea    rax,[r10+rax*8+0x28]
  40ac15:	mov    QWORD PTR [r9+0x50],0x0
  40ac1d:	mov    rcx,QWORD PTR [rax+0x8]
  40ac21:	mov    QWORD PTR [r9+0x48],rcx
  40ac25:	mov    rcx,QWORD PTR [rax+0x8]
  40ac29:	test   rcx,rcx
  40ac2c:	je     40ac34 <__swc_fn_585f006d_000046_49300800+0x54>
  40ac2e:	mov    QWORD PTR [rcx+0x50],r9
  40ac32:	jmp    40ac38 <__swc_fn_585f006d_000046_49300800+0x58>
  40ac34:	mov    QWORD PTR [rax+0x10],r9
  40ac38:	mov    QWORD PTR [rax+0x8],r9
  40ac3c:	xor    eax,eax
  40ac3e:	add    rsp,0x8
  40ac42:	ret
  40ac43:	movzx  eax,BYTE PTR [r9+0x39]
  40ac48:	lea    rax,[rax+rax*4]
  40ac4c:	lea    rax,[r10+rax*8+0x28]
  40ac51:	mov    QWORD PTR [r9+0x50],0x0
  40ac59:	mov    rcx,QWORD PTR [rax+0x18]
  40ac5d:	mov    QWORD PTR [r9+0x48],rcx
  40ac61:	mov    rcx,QWORD PTR [rax+0x18]
  40ac65:	test   rcx,rcx
  40ac68:	je     40ac6e <__swc_fn_585f006d_000046_49300800+0x8e>
  40ac6a:	mov    QWORD PTR [rcx+0x50],r9
  40ac6e:	mov    QWORD PTR [rax+0x18],r9
  40ac72:	mov    eax,0x1
  40ac77:	add    rsp,0x8
  40ac7b:	ret
  40ac7c:	add    BYTE PTR [rax],al
	...

000000000040ac80 <__swc_fn_585f006d_000049_781177b4>:
  40ac80:	push   r12
  40ac82:	push   r13
  40ac84:	push   rdi
  40ac85:	push   rsi
  40ac86:	push   r14
  40ac88:	push   r15
  40ac8a:	sub    rsp,0x178
  40ac91:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40ac9a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40aca3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40acac:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40acb5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40acbe:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40acc7:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40acd0:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40acd9:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40ace2:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40aceb:	mov    r12,rcx
  40acee:	lea    rax,[rip+0x1850b]        # 423200 <__swc_bss_base_585f006d+0x1c0>
  40acf5:	mov    rcx,QWORD PTR [rax]
  40acf8:	mov    r13,rcx
  40acfb:	test   rcx,rcx
  40acfe:	jne    40ad0e <__swc_fn_585f006d_000049_781177b4+0x8e>
  40ad00:	mov    r13d,0x1dcd6500
  40ad06:	mov    ecx,0x1dcd6500
  40ad0b:	xchg   QWORD PTR [rax],rcx
  40ad0e:	lea    rax,[rip+0x162eb]        # 421000 <__swc_data_base_585f006d>
  40ad15:	mov    rax,QWORD PTR [rax]
  40ad18:	cmp    rax,0xffffffffffffffff
  40ad1c:	je     40ad2b <__swc_fn_585f006d_000049_781177b4+0xab>
  40ad1e:	mov    eax,eax
  40ad20:	mov    edi,eax
  40ad22:	xor    eax,eax
  40ad24:	call   407000 <pthread_getspecific@plt>
  40ad29:	jmp    40ad2d <__swc_fn_585f006d_000049_781177b4+0xad>
  40ad2b:	xor    eax,eax
  40ad2d:	test   rax,rax
  40ad30:	jne    40ad3f <__swc_fn_585f006d_000049_781177b4+0xbf>
  40ad32:	call   40a9e0 <__swc_fn_585f006d_000031_ed8d61a9>
  40ad37:	mov    rcx,rax
  40ad3a:	call   410020 <__swc_fn_585f006d_000128_9c45d2d7>
  40ad3f:	test   rax,rax
  40ad42:	je     40ad54 <__swc_fn_585f006d_000049_781177b4+0xd4>
  40ad44:	cmp    QWORD PTR [rax],r12
  40ad47:	jne    40ad54 <__swc_fn_585f006d_000049_781177b4+0xd4>
  40ad49:	cmp    DWORD PTR [rax+0x20],0x0
  40ad4d:	jne    40ad54 <__swc_fn_585f006d_000049_781177b4+0xd4>
  40ad4f:	mov    rsi,rax
  40ad52:	jmp    40ad56 <__swc_fn_585f006d_000049_781177b4+0xd6>
  40ad54:	xor    esi,esi
  40ad56:	lea    rdi,[r12+0x2a88]
  40ad5e:	mov    r14,QWORD PTR [rdi]
  40ad61:	test   r14,r14
  40ad64:	jne    40adb3 <__swc_fn_585f006d_000049_781177b4+0x133>
  40ad66:	lea    rax,[rip+0x182eb]        # 423058 <__swc_bss_base_585f006d+0x18>
  40ad6d:	mov    rax,QWORD PTR [rax]
  40ad70:	test   rax,rax
  40ad73:	setne  al
  40ad76:	jne    40ad9a <__swc_fn_585f006d_000049_781177b4+0x11a>
  40ad78:	mov    rax,QWORD PTR [r12+0x2a70]
  40ad80:	test   rax,rax
  40ad83:	setne  al
  40ad86:	jne    40ad9a <__swc_fn_585f006d_000049_781177b4+0x11a>
  40ad88:	test   rsi,rsi
  40ad8b:	setne  al
  40ad8e:	je     40ad9a <__swc_fn_585f006d_000049_781177b4+0x11a>
  40ad90:	cmp    DWORD PTR [rsi+0x730],0x0
  40ad97:	setne  al
  40ad9a:	test   al,al
  40ad9c:	je     40adae <__swc_fn_585f006d_000049_781177b4+0x12e>
  40ad9e:	call   4100d0 <__swc_fn_585f006d_000131_dc04d759>
  40ada3:	lea    rcx,[rax+r13*1]
  40ada7:	xor    eax,eax
  40ada9:	lock cmpxchg QWORD PTR [rdi],rcx
  40adae:	jmp    40aeb3 <__swc_fn_585f006d_000049_781177b4+0x233>
  40adb3:	call   4100d0 <__swc_fn_585f006d_000131_dc04d759>
  40adb8:	mov    r15,rax
  40adbb:	cmp    rax,r14
  40adbe:	jb     40adcf <__swc_fn_585f006d_000049_781177b4+0x14f>
  40adc0:	xor    ecx,ecx
  40adc2:	mov    rax,r14
  40adc5:	lock cmpxchg QWORD PTR [rdi],rcx
  40adca:	cmp    rax,r14
  40adcd:	je     40add4 <__swc_fn_585f006d_000049_781177b4+0x154>
  40adcf:	jmp    40aeb3 <__swc_fn_585f006d_000049_781177b4+0x233>
  40add4:	test   rsi,rsi
  40add7:	je     40adf2 <__swc_fn_585f006d_000049_781177b4+0x172>
  40add9:	cmp    r15,r13
  40addc:	jb     40adf2 <__swc_fn_585f006d_000049_781177b4+0x172>
  40adde:	mov    rax,r15
  40ade1:	sub    rax,r13
  40ade4:	mov    rcx,r12
  40ade7:	mov    rdx,rsi
  40adea:	mov    r8,rax
  40aded:	call   40e430 <__swc_fn_585f006d_000059_c8e1ff6b>
  40adf2:	lea    rsi,[r12+0x10]
  40adf7:	mov    rcx,rsi
  40adfa:	call   4098a0 <__swc_fn_585f006d_000135_1fec60ac>
  40adff:	mov    rax,QWORD PTR [r12+0x18]
  40ae04:	mov    rdi,rax
  40ae07:	test   rdi,rdi
  40ae0a:	je     40ae34 <__swc_fn_585f006d_000049_781177b4+0x1b4>
  40ae0c:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae16:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae20:	mov    rcx,rdi
  40ae23:	call   407470 <__swc_fn_585f006d_000015_aa8c841a>
  40ae28:	mov    rax,QWORD PTR [rdi+0x10]
  40ae2c:	mov    rdi,rax
  40ae2f:	test   rax,rax
  40ae32:	jne    40ae20 <__swc_fn_585f006d_000049_781177b4+0x1a0>
  40ae34:	mov    rcx,rsi
  40ae37:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  40ae3c:	mov    rcx,r12
  40ae3f:	call   4098a0 <__swc_fn_585f006d_000135_1fec60ac>
  40ae44:	xor    esi,esi
  40ae46:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae50:	mov    rax,QWORD PTR [r12+0x2a70]
  40ae58:	cmp    rsi,rax
  40ae5b:	jae    40aeab <__swc_fn_585f006d_000049_781177b4+0x22b>
  40ae5d:	lea    rax,[rsi+rsi*4]
  40ae61:	lea    rax,[r12+rax*8+0x268]
  40ae69:	mov    r8,QWORD PTR [rax]
  40ae6c:	mov    r9,QWORD PTR [rax+0x8]
  40ae70:	mov    r10,QWORD PTR [rax+0x10]
  40ae74:	mov    rax,QWORD PTR [rax+0x20]
  40ae78:	cmp    rax,r15
  40ae7b:	jae    40ae88 <__swc_fn_585f006d_000049_781177b4+0x208>
  40ae7d:	mov    rcx,r15
  40ae80:	sub    rcx,rax
  40ae83:	cmp    rcx,r13
  40ae86:	jae    40ae8d <__swc_fn_585f006d_000049_781177b4+0x20d>
  40ae88:	inc    rsi
  40ae8b:	jmp    40ae50 <__swc_fn_585f006d_000049_781177b4+0x1d0>
  40ae8d:	mov    rcx,r12
  40ae90:	mov    rdx,rsi
  40ae93:	call   40e3e0 <__swc_fn_585f006d_000056_cfedf3f4>
  40ae98:	mov    rcx,r12
  40ae9b:	mov    rdx,r8
  40ae9e:	mov    r8,r9
  40aea1:	mov    r9,r10
  40aea4:	call   407750 <__swc_fn_585f006d_000039_05a50673>
  40aea9:	jmp    40ae50 <__swc_fn_585f006d_000049_781177b4+0x1d0>
  40aeab:	mov    rcx,r12
  40aeae:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  40aeb3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40aebc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40aec5:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40aece:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40aed7:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40aee0:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40aee9:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40aef2:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40aefb:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40af04:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40af0d:	add    rsp,0x178
  40af14:	pop    r15
  40af16:	pop    r14
  40af18:	pop    rsi
  40af19:	pop    rdi
  40af1a:	pop    r13
  40af1c:	pop    r12
  40af1e:	ret
	...

000000000040af20 <__swc_fn_585f006d_000052_26c6c1c4>:
  40af20:	lea    rax,[rdx-0x58]
  40af24:	ret
	...

000000000040af30 <__swc_fn_585f006d_000055_da36318f>:
  40af30:	push   rsi
  40af31:	push   rdi
  40af32:	push   r12
  40af34:	push   r13
  40af36:	sub    rsp,0x68
  40af3a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40af40:	mov    rsi,r9
  40af43:	mov    rdi,rcx
  40af46:	mov    r12,rdx
  40af49:	mov    r13,r8
  40af4c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40af54:	jne    40af63 <__swc_fn_585f006d_000055_da36318f+0x33>
  40af56:	xor    eax,eax
  40af58:	add    rsp,0x68
  40af5c:	pop    r13
  40af5e:	pop    r12
  40af60:	pop    rdi
  40af61:	pop    rsi
  40af62:	ret
  40af63:	mov    rcx,rdi
  40af66:	call   4098a0 <__swc_fn_585f006d_000135_1fec60ac>
  40af6b:	movabs rax,0x7fffffffffffffff
  40af75:	cmp    r12,rax
  40af78:	mov    rax,0xffffffffffffffff
  40af7f:	lea    rcx,[r12+r12*1]
  40af83:	cmovbe rax,rcx
  40af87:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40af8e:	mov    rdx,rcx
  40af91:	sub    rax,r12
  40af94:	inc    rax
  40af97:	xor    r8d,r8d
  40af9a:	test   rcx,rcx
  40af9d:	jbe    40afc8 <__swc_fn_585f006d_000055_da36318f+0x98>
  40af9f:	nop
  40afa0:	lea    r9,[r8+r8*4]
  40afa4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40afac:	sub    r9,r12
  40afaf:	cmp    r9,rax
  40afb2:	jae    40afbf <__swc_fn_585f006d_000055_da36318f+0x8f>
  40afb4:	mov    rdx,r8
  40afb7:	mov    rax,r9
  40afba:	test   r9,r9
  40afbd:	je     40afc8 <__swc_fn_585f006d_000055_da36318f+0x98>
  40afbf:	add    r8,0x1
  40afc3:	cmp    r8,rcx
  40afc6:	jb     40afa0 <__swc_fn_585f006d_000055_da36318f+0x70>
  40afc8:	mov    rax,QWORD PTR [rdi+0x2a70]
  40afcf:	cmp    rdx,rax
  40afd2:	jne    40afef <__swc_fn_585f006d_000055_da36318f+0xbf>
  40afd4:	mov    rcx,rdi
  40afd7:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  40afdc:	xor    eax,eax
  40afde:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40afe4:	add    rsp,0x68
  40afe8:	pop    r13
  40afea:	pop    r12
  40afec:	pop    rdi
  40afed:	pop    rsi
  40afee:	ret
  40afef:	lea    rax,[rdx+rdx*4]
  40aff3:	lea    rax,[rdi+rax*8+0x268]
  40affb:	vmovups xmm6,XMMWORD PTR [rax]
  40afff:	mov    r8,QWORD PTR [rax+0x10]
  40b003:	mov    rcx,rdi
  40b006:	call   40e3e0 <__swc_fn_585f006d_000056_cfedf3f4>
  40b00b:	vpshufd xmm0,xmm6,0xee
  40b010:	vmovsd QWORD PTR [r13+0x0],xmm0
  40b016:	mov    QWORD PTR [rsi],r8
  40b019:	mov    rcx,rdi
  40b01c:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  40b021:	vmovq  rax,xmm6
  40b026:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b02c:	add    rsp,0x68
  40b030:	pop    r13
  40b032:	pop    r12
  40b034:	pop    rdi
  40b035:	pop    rsi
  40b036:	ret
	...

000000000040b040 <__swc_fn_585f006d_000058_033ce1da>:
  40b040:	push   r12
  40b042:	push   r13
  40b044:	push   r14
  40b046:	push   r15
  40b048:	push   rdi
  40b049:	push   rsi
  40b04a:	sub    rsp,0x148
  40b051:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40b05a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40b063:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40b06c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40b075:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40b07e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40b087:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40b090:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40b099:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40b0a2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40b0ab:	mov    r12,r9
  40b0ae:	mov    r13,rcx
  40b0b1:	mov    r14,rdx
  40b0b4:	mov    r15,r8
  40b0b7:	test   rdx,rdx
  40b0ba:	jne    40b0ce <__swc_fn_585f006d_000058_033ce1da+0x8e>
  40b0bc:	add    rsp,0x148
  40b0c3:	pop    rsi
  40b0c4:	pop    rdi
  40b0c5:	pop    r15
  40b0c7:	pop    r14
  40b0c9:	pop    r13
  40b0cb:	pop    r12
  40b0cd:	ret
  40b0ce:	cmp    r12,0x200000
  40b0d5:	ja     40b167 <__swc_fn_585f006d_000058_033ce1da+0x127>
  40b0db:	lea    rax,[rip+0x15f1e]        # 421000 <__swc_data_base_585f006d>
  40b0e2:	mov    rax,QWORD PTR [rax]
  40b0e5:	cmp    rax,0xffffffffffffffff
  40b0e9:	je     40b0f8 <__swc_fn_585f006d_000058_033ce1da+0xb8>
  40b0eb:	mov    eax,eax
  40b0ed:	mov    edi,eax
  40b0ef:	xor    eax,eax
  40b0f1:	call   407000 <pthread_getspecific@plt>
  40b0f6:	jmp    40b0fa <__swc_fn_585f006d_000058_033ce1da+0xba>
  40b0f8:	xor    eax,eax
  40b0fa:	test   rax,rax
  40b0fd:	je     40b104 <__swc_fn_585f006d_000058_033ce1da+0xc4>
  40b0ff:	mov    rsi,rax
  40b102:	jmp    40b114 <__swc_fn_585f006d_000058_033ce1da+0xd4>
  40b104:	call   40a9e0 <__swc_fn_585f006d_000031_ed8d61a9>
  40b109:	mov    rcx,rax
  40b10c:	call   410020 <__swc_fn_585f006d_000128_9c45d2d7>
  40b111:	mov    rsi,rax
  40b114:	test   rsi,rsi
  40b117:	je     40b167 <__swc_fn_585f006d_000058_033ce1da+0x127>
  40b119:	cmp    QWORD PTR [rsi],r13
  40b11c:	jne    40b167 <__swc_fn_585f006d_000058_033ce1da+0x127>
  40b11e:	cmp    DWORD PTR [rsi+0x20],0x0
  40b122:	jne    40b167 <__swc_fn_585f006d_000058_033ce1da+0x127>
  40b124:	cmp    DWORD PTR [rsi+0x730],0x10
  40b12b:	jae    40b167 <__swc_fn_585f006d_000058_033ce1da+0x127>
  40b12d:	mov    eax,DWORD PTR [rsi+0x730]
  40b133:	lea    rdi,[rax+rax*4]
  40b137:	lea    rdi,[rsi+rdi*8+0x738]
  40b13f:	mov    QWORD PTR [rdi],r14
  40b142:	mov    QWORD PTR [rdi+0x8],r15
  40b146:	mov    QWORD PTR [rdi+0x10],r12
  40b14a:	mov    QWORD PTR [rdi+0x18],0x0
  40b152:	call   4100d0 <__swc_fn_585f006d_000131_dc04d759>
  40b157:	mov    QWORD PTR [rdi+0x20],rax
  40b15b:	add    DWORD PTR [rsi+0x730],0x1
  40b162:	jmp    40b2c6 <__swc_fn_585f006d_000058_033ce1da+0x286>
  40b167:	mov    rcx,r13
  40b16a:	call   407e90 <__swc_fn_585f006d_000057_8be0372b>
  40b16f:	mov    rsi,rax
  40b172:	cmp    r12,rax
  40b175:	jbe    40b1aa <__swc_fn_585f006d_000058_033ce1da+0x16a>
  40b177:	cmp    r12,0x10000000
  40b17e:	seta   al
  40b181:	ja     40b190 <__swc_fn_585f006d_000058_033ce1da+0x150>
  40b183:	mov    rax,QWORD PTR [r13+0x2a70]
  40b18a:	test   rax,rax
  40b18d:	setne  al
  40b190:	test   al,al
  40b192:	je     40b1aa <__swc_fn_585f006d_000058_033ce1da+0x16a>
  40b194:	mov    rcx,r13
  40b197:	mov    rdx,r14
  40b19a:	mov    r8,r15
  40b19d:	mov    r9,r12
  40b1a0:	call   407750 <__swc_fn_585f006d_000039_05a50673>
  40b1a5:	jmp    40b2c6 <__swc_fn_585f006d_000058_033ce1da+0x286>
  40b1aa:	call   4100d0 <__swc_fn_585f006d_000131_dc04d759>
  40b1af:	mov    rdi,rax
  40b1b2:	mov    rcx,r13
  40b1b5:	call   4098a0 <__swc_fn_585f006d_000135_1fec60ac>
  40b1ba:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b1c2:	je     40b27a <__swc_fn_585f006d_000058_033ce1da+0x23a>
  40b1c8:	nop    DWORD PTR [rax+rax*1+0x0]
  40b1d0:	cmp    QWORD PTR [r13+0x2a70],0x100
  40b1db:	jae    40b1f0 <__swc_fn_585f006d_000058_033ce1da+0x1b0>
  40b1dd:	mov    rax,QWORD PTR [r13+0x2a68]
  40b1e4:	add    rax,r12
  40b1e7:	cmp    rax,rsi
  40b1ea:	jbe    40b27a <__swc_fn_585f006d_000058_033ce1da+0x23a>
  40b1f0:	xor    eax,eax
  40b1f2:	mov    rcx,QWORD PTR [r13+0x2a70]
  40b1f9:	mov    edx,0x1
  40b1fe:	cmp    rcx,0x1
  40b202:	jbe    40b239 <__swc_fn_585f006d_000058_033ce1da+0x1f9>
  40b204:	cs nop WORD PTR [rax+rax*1+0x0]
  40b20e:	xchg   ax,ax
  40b210:	lea    r8,[rdx+rdx*4]
  40b214:	lea    r8,[r13+r8*8+0x268]
  40b21c:	lea    r9,[rax+rax*4]
  40b220:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40b228:	cmp    QWORD PTR [r8+0x18],r9
  40b22c:	cmovb  rax,rdx
  40b230:	add    rdx,0x1
  40b234:	cmp    rdx,rcx
  40b237:	jb     40b210 <__swc_fn_585f006d_000058_033ce1da+0x1d0>
  40b239:	lea    rcx,[rax+rax*4]
  40b23d:	lea    rcx,[r13+rcx*8+0x268]
  40b245:	mov    r8,QWORD PTR [rcx]
  40b248:	mov    r9,QWORD PTR [rcx+0x8]
  40b24c:	mov    r10,QWORD PTR [rcx+0x10]
  40b250:	mov    rcx,r13
  40b253:	mov    rdx,rax
  40b256:	call   40e3e0 <__swc_fn_585f006d_000056_cfedf3f4>
  40b25b:	mov    rcx,r13
  40b25e:	mov    rdx,r8
  40b261:	mov    r8,r9
  40b264:	mov    r9,r10
  40b267:	call   407750 <__swc_fn_585f006d_000039_05a50673>
  40b26c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b274:	jne    40b1d0 <__swc_fn_585f006d_000058_033ce1da+0x190>
  40b27a:	add    QWORD PTR [r13+0x2a78],0x1
  40b282:	mov    rax,QWORD PTR [r13+0x2a70]
  40b289:	lea    rax,[rax+rax*4]
  40b28d:	lea    rax,[r13+rax*8+0x268]
  40b295:	mov    QWORD PTR [rax],r14
  40b298:	mov    QWORD PTR [rax+0x8],r15
  40b29c:	mov    QWORD PTR [rax+0x10],r12
  40b2a0:	mov    rcx,QWORD PTR [r13+0x2a78]
  40b2a7:	mov    QWORD PTR [rax+0x18],rcx
  40b2ab:	mov    QWORD PTR [rax+0x20],rdi
  40b2af:	add    QWORD PTR [r13+0x2a68],r12
  40b2b6:	add    QWORD PTR [r13+0x2a70],0x1
  40b2be:	mov    rcx,r13
  40b2c1:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  40b2c6:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40b2cf:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40b2d8:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40b2e1:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40b2ea:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40b2f3:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40b2fc:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40b305:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40b30e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40b317:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40b320:	add    rsp,0x148
  40b327:	pop    rsi
  40b328:	pop    rdi
  40b329:	pop    r15
  40b32b:	pop    r14
  40b32d:	pop    r13
  40b32f:	pop    r12
  40b331:	ret
	...

000000000040b340 <__swc_fn_585f006d_000061_1badc238>:
  40b340:	push   rbx
  40b341:	push   r12
  40b343:	push   r13
  40b345:	push   r14
  40b347:	push   r15
  40b349:	push   rdi
  40b34a:	push   rsi
  40b34b:	sub    rsp,0xf0
  40b352:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40b358:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40b35e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40b364:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40b36a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40b373:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40b37c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40b385:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40b38e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40b397:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40b3a0:	mov    eax,r8d
  40b3a3:	mov    rbx,rcx
  40b3a6:	mov    r12,rdx
  40b3a9:	mov    QWORD PTR [rsp+0x18],rdx
  40b3ae:	mov    ecx,DWORD PTR [r12+0x58]
  40b3b3:	mov    r13d,ecx
  40b3b6:	cmp    ecx,0x10
  40b3b9:	mov    ecx,0x10
  40b3be:	cmovb  r13d,ecx
  40b3c2:	test   r13d,r13d
  40b3c5:	mov    rcx,r13
  40b3c8:	mov    edx,0x8
  40b3cd:	cmove  ecx,edx
  40b3d0:	dec    rcx
  40b3d3:	mov    rdx,0xffffffffffffffff
  40b3da:	sub    rdx,rcx
  40b3dd:	xor    r14d,r14d
  40b3e0:	mov    r8,rcx
  40b3e3:	not    r8
  40b3e6:	lea    rcx,[rcx+0x58]
  40b3ea:	and    rcx,r8
  40b3ed:	cmp    rdx,0x58
  40b3f1:	cmovae r14,rcx
  40b3f5:	cmp    eax,0xffffffff
  40b3f8:	jne    40b401 <__swc_fn_585f006d_000061_1badc238+0xc1>
  40b3fa:	mov    r15,QWORD PTR [r12+0x48]
  40b3ff:	jmp    40b433 <__swc_fn_585f006d_000061_1badc238+0xf3>
  40b401:	test   eax,eax
  40b403:	jne    40b40c <__swc_fn_585f006d_000061_1badc238+0xcc>
  40b405:	mov    eax,0x8
  40b40a:	jmp    40b430 <__swc_fn_585f006d_000061_1badc238+0xf0>
  40b40c:	cmp    eax,0x8
  40b40f:	ja     40b417 <__swc_fn_585f006d_000061_1badc238+0xd7>
  40b411:	shl    rax,0x4
  40b415:	jmp    40b430 <__swc_fn_585f006d_000061_1badc238+0xf0>
  40b417:	lea    eax,[rax-0x9]
  40b41a:	mov    ecx,eax
  40b41c:	shr    ecx,0x2
  40b41f:	and    eax,0x3
  40b422:	lea    ecx,[rcx+0x7]
  40b425:	lea    ecx,[rcx-0x2]
  40b428:	lea    eax,[rax+0x5]
  40b42b:	shlx   rax,rax,rcx
  40b430:	mov    r15,rax
  40b433:	lea    rax,[r14+r13*1]
  40b437:	mov    rcx,0xffffffffffffffff
  40b43e:	sub    rcx,rax
  40b441:	cmp    r15,rcx
  40b444:	jbe    40b454 <__swc_fn_585f006d_000061_1badc238+0x114>
  40b446:	mov    QWORD PTR [r12+0x40],0x0
  40b44f:	jmp    40b826 <__swc_fn_585f006d_000061_1badc238+0x4e6>
  40b454:	mov    QWORD PTR [rsp+0x20],r13
  40b459:	lea    r13,[rsp+0x8]
  40b45e:	add    rax,r15
  40b461:	mov    ecx,0x1000
  40b466:	test   ecx,ecx
  40b468:	mov    edx,0x8
  40b46d:	cmove  ecx,edx
  40b470:	dec    rcx
  40b473:	mov    rdx,0xffffffffffffffff
  40b47a:	sub    rdx,rcx
  40b47d:	cmp    rax,rdx
  40b480:	jbe    40b48c <__swc_fn_585f006d_000061_1badc238+0x14c>
  40b482:	mov    QWORD PTR [r13+0x0],0x0
  40b48a:	jmp    40b499 <__swc_fn_585f006d_000061_1badc238+0x159>
  40b48c:	add    rax,rcx
  40b48f:	andn   rax,rcx,rax
  40b494:	mov    QWORD PTR [rsp+0x8],rax
  40b499:	cmp    QWORD PTR [r13+0x0],0x0
  40b49e:	jne    40b4ae <__swc_fn_585f006d_000061_1badc238+0x16e>
  40b4a0:	mov    QWORD PTR [r12+0x40],0x0
  40b4a9:	jmp    40b826 <__swc_fn_585f006d_000061_1badc238+0x4e6>
  40b4ae:	mov    QWORD PTR [rsp+0x30],r15
  40b4b3:	xor    r15d,r15d
  40b4b6:	mov    QWORD PTR [rsp+0x38],0x0
  40b4bf:	lea    r12,[rsp+0x10]
  40b4c4:	mov    QWORD PTR [rsp+0x28],r14
  40b4c9:	mov    r14,QWORD PTR [rsp+0x8]
  40b4ce:	mov    QWORD PTR [rsp+0x10],r14
  40b4d3:	cmp    r14,0x10000
  40b4da:	ja     40b4e1 <__swc_fn_585f006d_000061_1badc238+0x1a1>
  40b4dc:	mov    rax,r14
  40b4df:	jmp    40b532 <__swc_fn_585f006d_000061_1badc238+0x1f2>
  40b4e1:	xor    eax,eax
  40b4e3:	lea    rcx,[r14-0x1]
  40b4e7:	lzcnt  rax,rcx
  40b4ec:	mov    ecx,0x3f
  40b4f1:	sub    rcx,rax
  40b4f4:	mov    eax,0x1
  40b4f9:	lea    rcx,[rcx-0x3]
  40b4fd:	shl    rax,cl
  40b500:	mov    rcx,rax
  40b503:	cmp    rax,0x1000
  40b50a:	mov    eax,0x1000
  40b50f:	cmovb  rcx,rax
  40b513:	mov    rdx,0xffffffffffffffff
  40b51a:	sub    rdx,rcx
  40b51d:	mov    rax,r14
  40b520:	lea    r8,[r14+rcx*1-0x1]
  40b525:	neg    rcx
  40b528:	and    r8,rcx
  40b52b:	cmp    r14,rdx
  40b52e:	cmovbe rax,r8
  40b532:	mov    QWORD PTR [rsp+0x8],rax
  40b537:	lea    rax,[rip+0x15ac2]        # 421000 <__swc_data_base_585f006d>
  40b53e:	mov    rax,QWORD PTR [rax]
  40b541:	cmp    rax,0xffffffffffffffff
  40b545:	je     40b554 <__swc_fn_585f006d_000061_1badc238+0x214>
  40b547:	mov    eax,eax
  40b549:	mov    edi,eax
  40b54b:	xor    eax,eax
  40b54d:	call   407000 <pthread_getspecific@plt>
  40b552:	jmp    40b556 <__swc_fn_585f006d_000061_1badc238+0x216>
  40b554:	xor    eax,eax
  40b556:	test   rax,rax
  40b559:	jne    40b568 <__swc_fn_585f006d_000061_1badc238+0x228>
  40b55b:	call   40a9e0 <__swc_fn_585f006d_000031_ed8d61a9>
  40b560:	mov    rcx,rax
  40b563:	call   410020 <__swc_fn_585f006d_000128_9c45d2d7>
  40b568:	test   rax,rax
  40b56b:	je     40b65c <__swc_fn_585f006d_000061_1badc238+0x31c>
  40b571:	cmp    QWORD PTR [rax],rbx
  40b574:	jne    40b65c <__swc_fn_585f006d_000061_1badc238+0x31c>
  40b57a:	cmp    DWORD PTR [rax+0x20],0x0
  40b57e:	jne    40b65c <__swc_fn_585f006d_000061_1badc238+0x31c>
  40b584:	mov    rcx,QWORD PTR [rsp+0x8]
  40b589:	movabs rdx,0x7fffffffffffffff
  40b593:	cmp    rcx,rdx
  40b596:	mov    rdx,0xffffffffffffffff
  40b59d:	lea    r8,[rcx+rcx*1]
  40b5a1:	cmovbe rdx,r8
  40b5a5:	mov    r8d,DWORD PTR [rax+0x730]
  40b5ac:	mov    r9d,r8d
  40b5af:	sub    rdx,rcx
  40b5b2:	inc    rdx
  40b5b5:	xor    r10d,r10d
  40b5b8:	test   r8,r8
  40b5bb:	jbe    40b5eb <__swc_fn_585f006d_000061_1badc238+0x2ab>
  40b5bd:	nop    DWORD PTR [rax]
  40b5c0:	mov    r11d,r10d
  40b5c3:	lea    r11,[r11+r11*4]
  40b5c7:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40b5cf:	sub    r11,rcx
  40b5d2:	cmp    r11,rdx
  40b5d5:	jae    40b5e2 <__swc_fn_585f006d_000061_1badc238+0x2a2>
  40b5d7:	mov    r9d,r10d
  40b5da:	mov    rdx,r11
  40b5dd:	test   r11,r11
  40b5e0:	je     40b5eb <__swc_fn_585f006d_000061_1badc238+0x2ab>
  40b5e2:	add    r10,0x1
  40b5e6:	cmp    r10,r8
  40b5e9:	jb     40b5c0 <__swc_fn_585f006d_000061_1badc238+0x280>
  40b5eb:	mov    ecx,DWORD PTR [rax+0x730]
  40b5f1:	cmp    r9d,ecx
  40b5f4:	jne    40b5fa <__swc_fn_585f006d_000061_1badc238+0x2ba>
  40b5f6:	xor    eax,eax
  40b5f8:	jmp    40b659 <__swc_fn_585f006d_000061_1badc238+0x319>
  40b5fa:	lea    rcx,[r9+r9*4]
  40b5fe:	lea    rcx,[rax+rcx*8+0x738]
  40b606:	vmovups xmm0,XMMWORD PTR [rcx]
  40b60a:	mov    rdx,QWORD PTR [rcx+0x10]
  40b60e:	sub    DWORD PTR [rax+0x730],0x1
  40b615:	mov    r8d,DWORD PTR [rax+0x730]
  40b61c:	lea    r8,[r8+r8*4]
  40b620:	lea    r8,[rax+r8*8+0x738]
  40b628:	vmovups xmm1,XMMWORD PTR [r8]
  40b62d:	vmovups XMMWORD PTR [rcx],xmm1
  40b631:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40b637:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40b63c:	mov    rax,QWORD PTR [r8+0x20]
  40b640:	mov    QWORD PTR [rcx+0x20],rax
  40b644:	vpshufd xmm1,xmm0,0xee
  40b649:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40b64f:	mov    QWORD PTR [rsp+0x10],rdx
  40b654:	vmovq  rax,xmm0
  40b659:	mov    r15,rax
  40b65c:	test   r15,r15
  40b65f:	jne    40b677 <__swc_fn_585f006d_000061_1badc238+0x337>
  40b661:	mov    rcx,rbx
  40b664:	mov    rdx,QWORD PTR [rsp+0x8]
  40b669:	mov    r8,r13
  40b66c:	mov    r9,r12
  40b66f:	call   40af30 <__swc_fn_585f006d_000055_da36318f>
  40b674:	mov    r15,rax
  40b677:	test   r15,r15
  40b67a:	je     40b6bb <__swc_fn_585f006d_000061_1badc238+0x37b>
  40b67c:	cmp    QWORD PTR [r12],r14
  40b680:	jae    40b6bb <__swc_fn_585f006d_000061_1badc238+0x37b>
  40b682:	mov    rax,r15
  40b685:	add    rax,QWORD PTR [r12]
  40b689:	mov    rdx,r14
  40b68c:	sub    rdx,QWORD PTR [r12]
  40b690:	mov    rcx,rax
  40b693:	call   4072a0 <__swc_fn_585f006d_000003_644dadb7>
  40b698:	test   al,al
  40b69a:	je     40b6a3 <__swc_fn_585f006d_000061_1badc238+0x363>
  40b69c:	mov    QWORD PTR [rsp+0x10],r14
  40b6a1:	jmp    40b6bb <__swc_fn_585f006d_000061_1badc238+0x37b>
  40b6a3:	mov    rcx,rbx
  40b6a6:	mov    rdx,r15
  40b6a9:	mov    r8,QWORD PTR [rsp+0x8]
  40b6ae:	mov    r9,QWORD PTR [rsp+0x10]
  40b6b3:	call   40b040 <__swc_fn_585f006d_000058_033ce1da>
  40b6b8:	xor    r15d,r15d
  40b6bb:	test   r15,r15
  40b6be:	jne    40b73a <__swc_fn_585f006d_000061_1badc238+0x3fa>
  40b6c0:	cmp    r14,0x10000
  40b6c7:	ja     40b6ce <__swc_fn_585f006d_000061_1badc238+0x38e>
  40b6c9:	mov    rax,r14
  40b6cc:	jmp    40b71f <__swc_fn_585f006d_000061_1badc238+0x3df>
  40b6ce:	xor    eax,eax
  40b6d0:	lea    rcx,[r14-0x1]
  40b6d4:	lzcnt  rax,rcx
  40b6d9:	mov    ecx,0x3f
  40b6de:	sub    rcx,rax
  40b6e1:	mov    eax,0x1
  40b6e6:	lea    rcx,[rcx-0x3]
  40b6ea:	shl    rax,cl
  40b6ed:	mov    rcx,rax
  40b6f0:	cmp    rax,0x1000
  40b6f7:	mov    eax,0x1000
  40b6fc:	cmovb  rcx,rax
  40b700:	mov    rdx,0xffffffffffffffff
  40b707:	sub    rdx,rcx
  40b70a:	mov    rax,r14
  40b70d:	lea    r8,[r14+rcx*1-0x1]
  40b712:	neg    rcx
  40b715:	and    r8,rcx
  40b718:	cmp    r14,rdx
  40b71b:	cmovbe rax,r8
  40b71f:	mov    QWORD PTR [rsp+0x8],rax
  40b724:	mov    QWORD PTR [rsp+0x10],r14
  40b729:	mov    rcx,rbx
  40b72c:	mov    rdx,rax
  40b72f:	mov    r8,r14
  40b732:	call   40aaa0 <__swc_fn_585f006d_000037_92e867c2>
  40b737:	mov    r15,rax
  40b73a:	test   r15,r15
  40b73d:	jne    40b74b <__swc_fn_585f006d_000061_1badc238+0x40b>
  40b73f:	mov    r13,QWORD PTR [rsp+0x20]
  40b744:	mov    rsi,QWORD PTR [rsp+0x38]
  40b749:	jmp    40b787 <__swc_fn_585f006d_000061_1badc238+0x447>
  40b74b:	mov    rax,r15
  40b74e:	add    rax,QWORD PTR [rsp+0x28]
  40b753:	mov    r13,QWORD PTR [rsp+0x20]
  40b758:	test   r13d,r13d
  40b75b:	mov    rcx,r13
  40b75e:	mov    edx,0x8
  40b763:	cmove  ecx,edx
  40b766:	dec    rcx
  40b769:	mov    rdx,0xffffffffffffffff
  40b770:	sub    rdx,rcx
  40b773:	cmp    rax,rdx
  40b776:	jbe    40b77c <__swc_fn_585f006d_000061_1badc238+0x43c>
  40b778:	xor    eax,eax
  40b77a:	jmp    40b784 <__swc_fn_585f006d_000061_1badc238+0x444>
  40b77c:	add    rax,rcx
  40b77f:	andn   rax,rcx,rax
  40b784:	mov    rsi,rax
  40b787:	mov    rax,QWORD PTR [rsp+0x8]
  40b78c:	test   r15,r15
  40b78f:	je     40b798 <__swc_fn_585f006d_000061_1badc238+0x458>
  40b791:	mov    rdi,QWORD PTR [rsp+0x18]
  40b796:	jmp    40b7aa <__swc_fn_585f006d_000061_1badc238+0x46a>
  40b798:	mov    rdi,QWORD PTR [rsp+0x18]
  40b79d:	mov    QWORD PTR [rdi+0x40],0x0
  40b7a5:	jmp    40b826 <__swc_fn_585f006d_000061_1badc238+0x4e6>
  40b7aa:	lea    rdx,[rsi-0x58]
  40b7ae:	mov    QWORD PTR [rsi-0x58],r15
  40b7b2:	mov    QWORD PTR [rsi-0x50],rax
  40b7b6:	mov    rax,QWORD PTR [rsp+0x10]
  40b7bb:	mov    QWORD PTR [rsi-0x48],rax
  40b7bf:	mov    QWORD PTR [rsi-0x40],rsi
  40b7c3:	mov    rax,QWORD PTR [rdi+0x48]
  40b7c7:	mov    QWORD PTR [rsi-0x38],rax
  40b7cb:	mov    rax,QWORD PTR [rsp+0x30]
  40b7d0:	mov    QWORD PTR [rsi-0x30],rax
  40b7d4:	mov    DWORD PTR [rsi-0x10],r13d
  40b7d8:	mov    QWORD PTR [rsi-0x28],0x0
  40b7e0:	mov    QWORD PTR [rsi-0x20],0x0
  40b7e8:	add    r15,QWORD PTR [r12]
  40b7ec:	sub    r15,rsi
  40b7ef:	mov    QWORD PTR [rsi-0x30],r15
  40b7f3:	mov    rcx,QWORD PTR [rbx+0x250]
  40b7fa:	nop    WORD PTR [rax+rax*1+0x0]
  40b800:	lea    r8,[rcx+r15*1]
  40b804:	mov    rax,rcx
  40b807:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40b810:	cmp    rax,rcx
  40b813:	je     40b81a <__swc_fn_585f006d_000061_1badc238+0x4da>
  40b815:	mov    rcx,rax
  40b818:	jmp    40b800 <__swc_fn_585f006d_000061_1badc238+0x4c0>
  40b81a:	mov    rcx,rbx
  40b81d:	call   40e350 <__swc_fn_585f006d_000053_a8a124d6>
  40b822:	mov    QWORD PTR [rdi+0x40],rsi
  40b826:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40b82c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40b832:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40b838:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40b83e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40b847:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40b850:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40b859:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40b862:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40b86b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40b874:	add    rsp,0xf0
  40b87b:	pop    rsi
  40b87c:	pop    rdi
  40b87d:	pop    r15
  40b87f:	pop    r14
  40b881:	pop    r13
  40b883:	pop    r12
  40b885:	pop    rbx
  40b886:	ret
	...

000000000040b890 <__swc_fn_585f006d_000064_6905bec4>:
  40b890:	push   rbx
  40b891:	push   r12
  40b893:	push   rdi
  40b894:	push   rsi
  40b895:	sub    rsp,0xb8
  40b89c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40b8a2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40b8a8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40b8ae:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40b8b4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40b8ba:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40b8c0:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40b8c6:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40b8cf:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40b8d8:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40b8e1:	mov    rbx,rdx
  40b8e4:	mov    r12,rcx
  40b8e7:	cmp    DWORD PTR [rbx+0x58],0x0
  40b8eb:	je     40b905 <__swc_fn_585f006d_000064_6905bec4+0x75>
  40b8ed:	mov    eax,DWORD PTR [rbx+0x58]
  40b8f0:	sub    eax,0x1
  40b8f3:	test   DWORD PTR [rbx+0x58],eax
  40b8f6:	je     40b905 <__swc_fn_585f006d_000064_6905bec4+0x75>
  40b8f8:	mov    QWORD PTR [rbx+0x40],0x0
  40b900:	jmp    40bb17 <__swc_fn_585f006d_000064_6905bec4+0x287>
  40b905:	cmp    QWORD PTR [rbx+0x48],0x0
  40b90a:	jne    40b919 <__swc_fn_585f006d_000064_6905bec4+0x89>
  40b90c:	mov    QWORD PTR [rbx+0x40],0x0
  40b914:	jmp    40bb17 <__swc_fn_585f006d_000064_6905bec4+0x287>
  40b919:	lea    rax,[rsp+0x8]
  40b91e:	mov    rcx,QWORD PTR [rbx+0x48]
  40b922:	cmp    rcx,0x8
  40b926:	ja     40b930 <__swc_fn_585f006d_000064_6905bec4+0xa0>
  40b928:	mov    DWORD PTR [rax],0x0
  40b92e:	jmp    40b98b <__swc_fn_585f006d_000064_6905bec4+0xfb>
  40b930:	cmp    rcx,0x80
  40b937:	ja     40b947 <__swc_fn_585f006d_000064_6905bec4+0xb7>
  40b939:	lea    rcx,[rcx+0xf]
  40b93d:	shr    rcx,0x4
  40b941:	mov    DWORD PTR [rsp+0x8],ecx
  40b945:	jmp    40b98b <__swc_fn_585f006d_000064_6905bec4+0xfb>
  40b947:	cmp    rcx,0x10000
  40b94e:	jbe    40b958 <__swc_fn_585f006d_000064_6905bec4+0xc8>
  40b950:	mov    DWORD PTR [rax],0xffffffff
  40b956:	jmp    40b98b <__swc_fn_585f006d_000064_6905bec4+0xfb>
  40b958:	dec    rcx
  40b95b:	xor    edx,edx
  40b95d:	lzcnt  rdx,rcx
  40b962:	mov    r8d,0x3f
  40b968:	sub    r8d,edx
  40b96b:	lea    edx,[r8-0x2]
  40b96f:	shrx   rcx,rcx,rdx
  40b974:	and    ecx,0x3
  40b977:	lea    edx,[r8-0x7]
  40b97b:	lea    edx,[rdx*4+0x0]
  40b982:	lea    edx,[rdx+0x9]
  40b985:	add    edx,ecx
  40b987:	mov    DWORD PTR [rsp+0x8],edx
  40b98b:	cmp    DWORD PTR [rax],0x0
  40b98e:	jne    40b99e <__swc_fn_585f006d_000064_6905bec4+0x10e>
  40b990:	cmp    DWORD PTR [rbx+0x58],0x8
  40b994:	jbe    40b99e <__swc_fn_585f006d_000064_6905bec4+0x10e>
  40b996:	mov    DWORD PTR [rsp+0x8],0x1
  40b99e:	cmp    DWORD PTR [rbx+0x58],0x10
  40b9a2:	jbe    40ba21 <__swc_fn_585f006d_000064_6905bec4+0x191>
  40b9a8:	cmp    DWORD PTR [rbx+0x58],0x40
  40b9ac:	ja     40ba21 <__swc_fn_585f006d_000064_6905bec4+0x191>
  40b9ae:	cmp    DWORD PTR [rax],0xffffffff
  40b9b1:	je     40ba21 <__swc_fn_585f006d_000064_6905bec4+0x191>
  40b9b3:	mov    ecx,DWORD PTR [rsp+0x8]
  40b9b7:	mov    edx,DWORD PTR [rbx+0x58]
  40b9ba:	dec    rdx
  40b9bd:	cmp    ecx,0x2d
  40b9c0:	jae    40ba18 <__swc_fn_585f006d_000064_6905bec4+0x188>
  40b9c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40b9cc:	nop    DWORD PTR [rax+0x0]
  40b9d0:	mov    r8d,ecx
  40b9d3:	test   ecx,ecx
  40b9d5:	jne    40b9df <__swc_fn_585f006d_000064_6905bec4+0x14f>
  40b9d7:	mov    r8d,0x8
  40b9dd:	jmp    40ba0b <__swc_fn_585f006d_000064_6905bec4+0x17b>
  40b9df:	cmp    r8d,0x8
  40b9e3:	ja     40b9eb <__swc_fn_585f006d_000064_6905bec4+0x15b>
  40b9e5:	shl    r8,0x4
  40b9e9:	jmp    40ba0b <__swc_fn_585f006d_000064_6905bec4+0x17b>
  40b9eb:	lea    r8d,[r8-0x9]
  40b9ef:	mov    r9d,r8d
  40b9f2:	shr    r9d,0x2
  40b9f6:	and    r8d,0x3
  40b9fa:	lea    r9d,[r9+0x7]
  40b9fe:	lea    r9d,[r9-0x2]
  40ba02:	lea    r8d,[r8+0x5]
  40ba06:	shlx   r8,r8,r9
  40ba0b:	test   r8,rdx
  40ba0e:	je     40ba1d <__swc_fn_585f006d_000064_6905bec4+0x18d>
  40ba10:	add    ecx,0x1
  40ba13:	cmp    ecx,0x2d
  40ba16:	jb     40b9d0 <__swc_fn_585f006d_000064_6905bec4+0x140>
  40ba18:	mov    ecx,0xffffffff
  40ba1d:	mov    DWORD PTR [rsp+0x8],ecx
  40ba21:	mov    ecx,DWORD PTR [rsp+0x8]
  40ba25:	cmp    ecx,0xffffffff
  40ba28:	je     40ba30 <__swc_fn_585f006d_000064_6905bec4+0x1a0>
  40ba2a:	cmp    DWORD PTR [rbx+0x58],0x40
  40ba2e:	jbe    40ba43 <__swc_fn_585f006d_000064_6905bec4+0x1b3>
  40ba30:	mov    rcx,r12
  40ba33:	mov    rdx,rbx
  40ba36:	mov    r8d,DWORD PTR [rax]
  40ba39:	call   40b340 <__swc_fn_585f006d_000061_1badc238>
  40ba3e:	jmp    40bb17 <__swc_fn_585f006d_000064_6905bec4+0x287>
  40ba43:	lea    rax,[rip+0x155b6]        # 421000 <__swc_data_base_585f006d>
  40ba4a:	mov    rax,QWORD PTR [rax]
  40ba4d:	cmp    rax,0xffffffffffffffff
  40ba51:	je     40ba60 <__swc_fn_585f006d_000064_6905bec4+0x1d0>
  40ba53:	mov    eax,eax
  40ba55:	mov    edi,eax
  40ba57:	xor    eax,eax
  40ba59:	call   407000 <pthread_getspecific@plt>
  40ba5e:	jmp    40ba62 <__swc_fn_585f006d_000064_6905bec4+0x1d2>
  40ba60:	xor    eax,eax
  40ba62:	test   rax,rax
  40ba65:	jne    40ba74 <__swc_fn_585f006d_000064_6905bec4+0x1e4>
  40ba67:	call   40a9e0 <__swc_fn_585f006d_000031_ed8d61a9>
  40ba6c:	mov    rcx,rax
  40ba6f:	call   410020 <__swc_fn_585f006d_000128_9c45d2d7>
  40ba74:	test   rax,rax
  40ba77:	je     40ba84 <__swc_fn_585f006d_000064_6905bec4+0x1f4>
  40ba79:	cmp    QWORD PTR [rax],r12
  40ba7c:	jne    40ba84 <__swc_fn_585f006d_000064_6905bec4+0x1f4>
  40ba7e:	cmp    DWORD PTR [rax+0x20],0x0
  40ba82:	je     40ba8f <__swc_fn_585f006d_000064_6905bec4+0x1ff>
  40ba84:	mov    rcx,r12
  40ba87:	mov    rdx,rax
  40ba8a:	call   40df90 <__swc_fn_585f006d_000041_ed1cda78>
  40ba8f:	test   rax,rax
  40ba92:	jne    40ba9e <__swc_fn_585f006d_000064_6905bec4+0x20e>
  40ba94:	mov    QWORD PTR [rbx+0x40],0x0
  40ba9c:	jmp    40bb17 <__swc_fn_585f006d_000064_6905bec4+0x287>
  40ba9e:	lea    r8,[rsp+0xc]
  40baa3:	mov    ecx,DWORD PTR [rsp+0x8]
  40baa7:	mov    DWORD PTR [rsp+0xc],ecx
  40baab:	mov    ecx,DWORD PTR [r8]
  40baae:	lea    rcx,[rcx+rcx*4]
  40bab2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40bab7:	test   rcx,rcx
  40baba:	je     40baf3 <__swc_fn_585f006d_000064_6905bec4+0x263>
  40babc:	mov    rdx,QWORD PTR [rcx]
  40babf:	test   rdx,rdx
  40bac2:	je     40bad0 <__swc_fn_585f006d_000064_6905bec4+0x240>
  40bac4:	mov    r9,QWORD PTR [rdx]
  40bac7:	mov    QWORD PTR [rcx],r9
  40baca:	add    DWORD PTR [rcx+0x28],0x1
  40bace:	jmp    40baee <__swc_fn_585f006d_000064_6905bec4+0x25e>
  40bad0:	mov    rdx,QWORD PTR [rcx+0x18]
  40bad4:	cmp    QWORD PTR [rcx+0x20],rdx
  40bad8:	jae    40baec <__swc_fn_585f006d_000064_6905bec4+0x25c>
  40bada:	mov    rdx,QWORD PTR [rcx+0x20]
  40bade:	mov    r9d,DWORD PTR [rcx+0x2c]
  40bae2:	add    QWORD PTR [rcx+0x20],r9
  40bae6:	add    DWORD PTR [rcx+0x28],0x1
  40baea:	jmp    40baee <__swc_fn_585f006d_000064_6905bec4+0x25e>
  40baec:	xor    edx,edx
  40baee:	test   rdx,rdx
  40baf1:	jne    40bb04 <__swc_fn_585f006d_000064_6905bec4+0x274>
  40baf3:	mov    rcx,r12
  40baf6:	mov    rdx,rax
  40baf9:	mov    r8d,DWORD PTR [r8]
  40bafc:	call   40e100 <__swc_fn_585f006d_000050_e33921d7>
  40bb01:	mov    rdx,rax
  40bb04:	test   rdx,rdx
  40bb07:	jne    40bb13 <__swc_fn_585f006d_000064_6905bec4+0x283>
  40bb09:	mov    QWORD PTR [rbx+0x40],0x0
  40bb11:	jmp    40bb17 <__swc_fn_585f006d_000064_6905bec4+0x287>
  40bb13:	mov    QWORD PTR [rbx+0x40],rdx
  40bb17:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40bb1d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40bb23:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40bb29:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40bb2f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40bb35:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40bb3b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40bb41:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40bb4a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40bb53:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40bb5c:	add    rsp,0xb8
  40bb63:	pop    rsi
  40bb64:	pop    rdi
  40bb65:	pop    r12
  40bb67:	pop    rbx
  40bb68:	ret
  40bb69:	add    BYTE PTR [rax],al
  40bb6b:	add    BYTE PTR [rax],al
  40bb6d:	add    BYTE PTR [rax],al
	...

000000000040bb70 <__swc_fn_585f006d_000067_381f5b88>:
  40bb70:	ret
	...

000000000040bb80 <__swc_fn_585f006d_000070_2cd83140>:
  40bb80:	push   r12
  40bb82:	push   r13
  40bb84:	push   r14
  40bb86:	push   rdi
  40bb87:	push   rsi
  40bb88:	sub    rsp,0x1a0
  40bb8f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40bb98:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40bba1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40bbaa:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40bbb3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40bbbc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40bbc5:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40bbce:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40bbd7:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40bbe0:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40bbe9:	mov    r12,rdx
  40bbec:	mov    r13,rcx
  40bbef:	mov    rax,QWORD PTR [r12+0x48]
  40bbf4:	mov    ecx,DWORD PTR [r12+0x58]
  40bbf9:	lea    rdx,[rax-0x1]
  40bbfd:	cmp    rdx,0x10000
  40bc04:	jae    40bcfe <__swc_fn_585f006d_000070_2cd83140+0x17e>
  40bc0a:	cmp    rax,0x8
  40bc0e:	ja     40bc15 <__swc_fn_585f006d_000070_2cd83140+0x95>
  40bc10:	xor    r14d,r14d
  40bc13:	jmp    40bc67 <__swc_fn_585f006d_000070_2cd83140+0xe7>
  40bc15:	cmp    rax,0x80
  40bc1c:	ja     40bc28 <__swc_fn_585f006d_000070_2cd83140+0xa8>
  40bc1e:	lea    r14,[rax+0xf]
  40bc22:	shr    r14,0x4
  40bc26:	jmp    40bc67 <__swc_fn_585f006d_000070_2cd83140+0xe7>
  40bc28:	cmp    rax,0x10000
  40bc2f:	jbe    40bc39 <__swc_fn_585f006d_000070_2cd83140+0xb9>
  40bc31:	mov    r14d,0xffffffff
  40bc37:	jmp    40bc67 <__swc_fn_585f006d_000070_2cd83140+0xe7>
  40bc39:	xor    eax,eax
  40bc3b:	lzcnt  rax,rdx
  40bc40:	mov    r8d,0x3f
  40bc46:	sub    r8d,eax
  40bc49:	lea    eax,[r8-0x2]
  40bc4d:	shrx   rax,rdx,rax
  40bc52:	and    eax,0x3
  40bc55:	lea    edx,[r8-0x7]
  40bc59:	lea    edx,[rdx*4+0x0]
  40bc60:	lea    edx,[rdx+0x9]
  40bc63:	lea    r14d,[rdx+rax*1]
  40bc67:	cmp    ecx,0x8
  40bc6a:	jbe    40bc83 <__swc_fn_585f006d_000070_2cd83140+0x103>
  40bc6c:	cmp    ecx,0x10
  40bc6f:	jne    40bcfe <__swc_fn_585f006d_000070_2cd83140+0x17e>
  40bc75:	test   r14d,r14d
  40bc78:	mov    eax,0x1
  40bc7d:	cmove  r14d,eax
  40bc81:	jmp    40bc8a <__swc_fn_585f006d_000070_2cd83140+0x10a>
  40bc83:	lea    eax,[rcx-0x1]
  40bc86:	test   eax,ecx
  40bc88:	jne    40bcfe <__swc_fn_585f006d_000070_2cd83140+0x17e>
  40bc8a:	lea    rax,[rip+0x1536f]        # 421000 <__swc_data_base_585f006d>
  40bc91:	mov    rax,QWORD PTR [rax]
  40bc94:	cmp    rax,0xffffffffffffffff
  40bc98:	je     40bca7 <__swc_fn_585f006d_000070_2cd83140+0x127>
  40bc9a:	mov    eax,eax
  40bc9c:	mov    edi,eax
  40bc9e:	xor    eax,eax
  40bca0:	call   407000 <pthread_getspecific@plt>
  40bca5:	jmp    40bca9 <__swc_fn_585f006d_000070_2cd83140+0x129>
  40bca7:	xor    eax,eax
  40bca9:	test   rax,rax
  40bcac:	je     40bcfe <__swc_fn_585f006d_000070_2cd83140+0x17e>
  40bcae:	cmp    QWORD PTR [rax],r13
  40bcb1:	jne    40bcfe <__swc_fn_585f006d_000070_2cd83140+0x17e>
  40bcb3:	lea    rcx,[r14+r14*4]
  40bcb7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40bcbc:	test   rax,rax
  40bcbf:	je     40bcfe <__swc_fn_585f006d_000070_2cd83140+0x17e>
  40bcc1:	mov    rcx,QWORD PTR [rax]
  40bcc4:	test   rcx,rcx
  40bcc7:	je     40bcd5 <__swc_fn_585f006d_000070_2cd83140+0x155>
  40bcc9:	mov    rdx,QWORD PTR [rcx]
  40bccc:	mov    QWORD PTR [rax],rdx
  40bccf:	add    DWORD PTR [rax+0x28],0x1
  40bcd3:	jmp    40bcf2 <__swc_fn_585f006d_000070_2cd83140+0x172>
  40bcd5:	mov    rcx,QWORD PTR [rax+0x18]
  40bcd9:	cmp    QWORD PTR [rax+0x20],rcx
  40bcdd:	jae    40bcf0 <__swc_fn_585f006d_000070_2cd83140+0x170>
  40bcdf:	mov    rcx,QWORD PTR [rax+0x20]
  40bce3:	mov    edx,DWORD PTR [rax+0x2c]
  40bce6:	add    QWORD PTR [rax+0x20],rdx
  40bcea:	add    DWORD PTR [rax+0x28],0x1
  40bcee:	jmp    40bcf2 <__swc_fn_585f006d_000070_2cd83140+0x172>
  40bcf0:	xor    ecx,ecx
  40bcf2:	test   rcx,rcx
  40bcf5:	je     40bcfe <__swc_fn_585f006d_000070_2cd83140+0x17e>
  40bcf7:	mov    QWORD PTR [r12+0x40],rcx
  40bcfc:	jmp    40bd09 <__swc_fn_585f006d_000070_2cd83140+0x189>
  40bcfe:	mov    rcx,r13
  40bd01:	mov    rdx,r12
  40bd04:	call   40eb80 <__swc_fn_585f006d_000071_7e144e9b>
  40bd09:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40bd12:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40bd1b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40bd24:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40bd2d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40bd36:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40bd3f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40bd48:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40bd51:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40bd5a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40bd63:	add    rsp,0x1a0
  40bd6a:	pop    rsi
  40bd6b:	pop    rdi
  40bd6c:	pop    r14
  40bd6e:	pop    r13
  40bd70:	pop    r12
  40bd72:	ret
	...

000000000040bd80 <__swc_fn_585f006d_000073_c77adf75>:
  40bd80:	push   r12
  40bd82:	push   r13
  40bd84:	push   r14
  40bd86:	push   r15
  40bd88:	push   rdi
  40bd89:	push   rsi
  40bd8a:	sub    rsp,0x188
  40bd91:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40bd9a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40bda3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40bdac:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40bdb5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40bdbe:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40bdc7:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40bdd0:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40bdd9:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40bde2:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40bdeb:	mov    r12,rdx
  40bdee:	mov    r13,rcx
  40bdf1:	mov    r14,QWORD PTR [r12+0x40]
  40bdf6:	lea    rax,[rip+0x17273]        # 423070 <__swc_bss_base_585f006d+0x30>
  40bdfd:	mov    rcx,r14
  40be00:	sub    rcx,QWORD PTR [rax+0x8]
  40be04:	mov    rax,QWORD PTR [rip+0x17275]        # 423080 <__swc_bss_base_585f006d+0x40>
  40be0b:	cmp    rcx,rax
  40be0e:	jae    40be3a <__swc_fn_585f006d_000073_c77adf75+0xba>
  40be10:	mov    rax,r14
  40be13:	and    rax,0xffffffffffc00000
  40be1a:	mov    rcx,r14
  40be1d:	shr    rcx,0x10
  40be21:	and    ecx,0x3f
  40be24:	mov    edx,DWORD PTR [rax+0x28]
  40be27:	shrx   ecx,ecx,edx
  40be2c:	shl    rcx,0x4
  40be30:	lea    r15,[rax+rcx*8+0x80]
  40be38:	jmp    40be45 <__swc_fn_585f006d_000073_c77adf75+0xc5>
  40be3a:	mov    rcx,r14
  40be3d:	call   40a910 <__swc_fn_585f006d_000022_77c2d682>
  40be42:	mov    r15,rax
  40be45:	test   r15,r15
  40be48:	je     40beef <__swc_fn_585f006d_000073_c77adf75+0x16f>
  40be4e:	lea    rax,[rip+0x151ab]        # 421000 <__swc_data_base_585f006d>
  40be55:	mov    rax,QWORD PTR [rax]
  40be58:	cmp    rax,0xffffffffffffffff
  40be5c:	je     40be6b <__swc_fn_585f006d_000073_c77adf75+0xeb>
  40be5e:	mov    eax,eax
  40be60:	mov    edi,eax
  40be62:	xor    eax,eax
  40be64:	call   407000 <pthread_getspecific@plt>
  40be69:	jmp    40be6d <__swc_fn_585f006d_000073_c77adf75+0xed>
  40be6b:	xor    eax,eax
  40be6d:	mov    rcx,QWORD PTR [r15+0x40]
  40be71:	cmp    rcx,rax
  40be74:	jne    40bed4 <__swc_fn_585f006d_000073_c77adf75+0x154>
  40be76:	test   rax,rax
  40be79:	je     40beef <__swc_fn_585f006d_000073_c77adf75+0x16f>
  40be7b:	mov    ecx,DWORD PTR [r15+0x6c]
  40be7f:	test   ecx,ecx
  40be81:	je     40bea1 <__swc_fn_585f006d_000073_c77adf75+0x121>
  40be83:	mov    rcx,r13
  40be86:	mov    rdx,rax
  40be89:	mov    r8,r15
  40be8c:	mov    QWORD PTR [rsp+0xd8],rax
  40be94:	call   40e090 <__swc_fn_585f006d_000047_3d3eceb4>
  40be99:	mov    rax,QWORD PTR [rsp+0xd8]
  40bea1:	mov    rcx,QWORD PTR [r15]
  40bea4:	mov    QWORD PTR [r14],rcx
  40bea7:	mov    QWORD PTR [r15],r14
  40beaa:	sub    DWORD PTR [r15+0x28],0x1
  40beaf:	jne    40bee4 <__swc_fn_585f006d_000073_c77adf75+0x164>
  40beb1:	movzx  ecx,BYTE PTR [r15+0x39]
  40beb6:	lea    rcx,[rcx+rcx*4]
  40beba:	lea    rcx,[rax+rcx*8+0x28]
  40bebf:	cmp    QWORD PTR [rcx],r15
  40bec2:	je     40bee4 <__swc_fn_585f006d_000073_c77adf75+0x164>
  40bec4:	mov    rcx,r13
  40bec7:	mov    rdx,rax
  40beca:	mov    r8,r15
  40becd:	call   407d80 <__swc_fn_585f006d_000051_5b91e689>
  40bed2:	jmp    40bee4 <__swc_fn_585f006d_000073_c77adf75+0x164>
  40bed4:	test   rcx,rcx
  40bed7:	je     40beef <__swc_fn_585f006d_000073_c77adf75+0x16f>
  40bed9:	mov    rcx,r15
  40bedc:	mov    rdx,r14
  40bedf:	call   40a550 <__swc_fn_585f006d_000010_186cd0c2>
  40bee4:	mov    QWORD PTR [r12+0x40],0x0
  40beed:	jmp    40befa <__swc_fn_585f006d_000073_c77adf75+0x17a>
  40beef:	mov    rcx,r13
  40bef2:	mov    rdx,r12
  40bef5:	call   40eba0 <__swc_fn_585f006d_000074_9eaf4878>
  40befa:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40bf03:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40bf0c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40bf15:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40bf1e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40bf27:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40bf30:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40bf39:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40bf42:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40bf4b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40bf54:	add    rsp,0x188
  40bf5b:	pop    rsi
  40bf5c:	pop    rdi
  40bf5d:	pop    r15
  40bf5f:	pop    r14
  40bf61:	pop    r13
  40bf63:	pop    r12
  40bf65:	ret
	...

000000000040bf70 <__swc_fn_585f006d_000076_d8e626b0>:
  40bf70:	sub    rsp,0x8
  40bf74:	mov    rax,rdx
  40bf77:	mov    rdx,QWORD PTR [rax+0x40]
  40bf7b:	mov    r8,rax
  40bf7e:	call   40bb70 <__swc_fn_585f006d_000067_381f5b88>
  40bf83:	add    rsp,0x8
  40bf87:	ret
	...

000000000040bf90 <__swc_fn_585f006d_000079_29fad089>:
  40bf90:	push   rsi
  40bf91:	push   rdi
  40bf92:	sub    rsp,0x8
  40bf96:	cmp    rcx,0xffffffffffffffef
  40bf9a:	ja     40bfc0 <__swc_fn_585f006d_000079_29fad089+0x30>
  40bf9c:	xor    esi,esi
  40bf9e:	lea    rax,[rcx+0x100f]
  40bfa5:	and    rax,0xfffffffffffff000
  40bfac:	lea    rcx,[rcx+0x10]
  40bfb0:	cmp    rcx,0xfffffffffffff000
  40bfb7:	cmovbe rsi,rax
  40bfbb:	test   rsi,rsi
  40bfbe:	jne    40bfc9 <__swc_fn_585f006d_000079_29fad089+0x39>
  40bfc0:	xor    eax,eax
  40bfc2:	add    rsp,0x8
  40bfc6:	pop    rdi
  40bfc7:	pop    rsi
  40bfc8:	ret
  40bfc9:	mov    rcx,rsi
  40bfcc:	call   40c620 <__swc_fn_585f006d_000109_aa570b2b>
  40bfd1:	mov    rdi,rax
  40bfd4:	test   rax,rax
  40bfd7:	jne    40bfe2 <__swc_fn_585f006d_000079_29fad089+0x52>
  40bfd9:	xor    eax,eax
  40bfdb:	add    rsp,0x8
  40bfdf:	pop    rdi
  40bfe0:	pop    rsi
  40bfe1:	ret
  40bfe2:	mov    rcx,rdi
  40bfe5:	mov    rdx,rsi
  40bfe8:	call   409240 <__swc_fn_585f006d_000111_e724f834>
  40bfed:	test   al,al
  40bfef:	jne    40c005 <__swc_fn_585f006d_000079_29fad089+0x75>
  40bff1:	mov    rcx,rdi
  40bff4:	mov    rdx,rsi
  40bff7:	call   40fcd0 <__swc_fn_585f006d_000113_25e345b1>
  40bffc:	xor    eax,eax
  40bffe:	add    rsp,0x8
  40c002:	pop    rdi
  40c003:	pop    rsi
  40c004:	ret
  40c005:	mov    QWORD PTR [rdi],rsi
  40c008:	mov    QWORD PTR [rdi+0x8],0x0
  40c010:	lea    rax,[rdi+0x10]
  40c014:	add    rsp,0x8
  40c018:	pop    rdi
  40c019:	pop    rsi
  40c01a:	ret
  40c01b:	add    BYTE PTR [rax],al
  40c01d:	add    BYTE PTR [rax],al
	...

000000000040c020 <__swc_fn_585f006d_000082_9f4f5092>:
  40c020:	sub    rsp,0x8
  40c024:	cmp    BYTE PTR [rcx+0x2c],0x10
  40c028:	jne    40c033 <__swc_fn_585f006d_000082_9f4f5092+0x13>
  40c02a:	test   DWORD PTR [rcx+0x28],0x80
  40c031:	je     40c03b <__swc_fn_585f006d_000082_9f4f5092+0x1b>
  40c033:	mov    rax,rcx
  40c036:	add    rsp,0x8
  40c03a:	ret
  40c03b:	mov    rcx,QWORD PTR [rcx+0x40]
  40c03f:	call   40c020 <__swc_fn_585f006d_000082_9f4f5092>
  40c044:	add    rsp,0x8
  40c048:	ret
	...

000000000040c060 <__swc_fn_585f006d_000085_88128f21>:
  40c060:	push   rsi
  40c061:	push   rdi
  40c062:	push   r12
  40c064:	push   r13
  40c066:	sub    rsp,0x8
  40c06a:	mov    rsi,rdx
  40c06d:	mov    rdi,rcx
  40c070:	xor    r8d,r8d
  40c073:	call   4085a0 <__swc_fn_585f006d_000090_9a1d717d>
  40c078:	test   al,al
  40c07a:	je     40c08c <__swc_fn_585f006d_000085_88128f21+0x2c>
  40c07c:	mov    eax,0x1
  40c081:	add    rsp,0x8
  40c085:	pop    r13
  40c087:	pop    r12
  40c089:	pop    rdi
  40c08a:	pop    rsi
  40c08b:	ret
  40c08c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40c091:	je     40c0a0 <__swc_fn_585f006d_000085_88128f21+0x40>
  40c093:	xor    eax,eax
  40c095:	add    rsp,0x8
  40c099:	pop    r13
  40c09b:	pop    r12
  40c09d:	pop    rdi
  40c09e:	pop    rsi
  40c09f:	ret
  40c0a0:	mov    r12,QWORD PTR [rsi+0x98]
  40c0a7:	mov    rax,QWORD PTR [rsi+0xa0]
  40c0ae:	mov    rsi,rax
  40c0b1:	xor    r13d,r13d
  40c0b4:	test   rsi,rsi
  40c0b7:	je     40c114 <__swc_fn_585f006d_000085_88128f21+0xb4>
  40c0b9:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0c3:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0cd:	nop    DWORD PTR [rax]
  40c0d0:	lea    rax,[r13*8+0x0]
  40c0d8:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40c0dd:	mov    rcx,rax
  40c0e0:	call   40c020 <__swc_fn_585f006d_000082_9f4f5092>
  40c0e5:	cmp    BYTE PTR [rax+0x2c],0xe
  40c0e9:	jne    40c10a <__swc_fn_585f006d_000085_88128f21+0xaa>
  40c0eb:	mov    rcx,rdi
  40c0ee:	mov    rdx,rax
  40c0f1:	call   40c060 <__swc_fn_585f006d_000085_88128f21>
  40c0f6:	test   al,al
  40c0f8:	je     40c10a <__swc_fn_585f006d_000085_88128f21+0xaa>
  40c0fa:	mov    eax,0x1
  40c0ff:	add    rsp,0x8
  40c103:	pop    r13
  40c105:	pop    r12
  40c107:	pop    rdi
  40c108:	pop    rsi
  40c109:	ret
  40c10a:	add    r13,0x1
  40c10e:	sub    rsi,0x1
  40c112:	jne    40c0d0 <__swc_fn_585f006d_000085_88128f21+0x70>
  40c114:	xor    eax,eax
  40c116:	add    rsp,0x8
  40c11a:	pop    r13
  40c11c:	pop    r12
  40c11e:	pop    rdi
  40c11f:	pop    rsi
  40c120:	ret
	...

000000000040c130 <__swc_fn_585f006d_000088_17711411>:
  40c130:	sub    rsp,0x18
  40c134:	vxorps xmm0,xmm0,xmm0
  40c138:	vmovdqu XMMWORD PTR [rsp],xmm0
  40c13d:	call   40edb0 <__swc_fn_585f006d_000089_157b05de>
  40c142:	add    rsp,0x18
  40c146:	ret
	...

000000000040c150 <__swc_fn_585f006d_000091_e6773530>:
  40c150:	sub    rsp,0x8
  40c154:	mov    rcx,QWORD PTR [rip+0x19be5]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40c15b:	test   rcx,rcx
  40c15e:	jne    40c170 <__swc_fn_585f006d_000091_e6773530+0x20>
  40c160:	call   40a1a0 <__swc_fn_585f006d_000165_e09accff>
  40c165:	lea    rcx,[rax+0x1]
  40c169:	mov    QWORD PTR [rip+0x19bd0],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40c170:	dec    rcx
  40c173:	call   411aa0 <__swc_fn_585f006d_000167_3130645d>
  40c178:	mov    rax,QWORD PTR [rax+0xc0]
  40c17f:	and    eax,0x1
  40c182:	setne  al
  40c185:	add    rsp,0x8
  40c189:	ret
	...

000000000040c1a0 <__swc_fn_585f006d_000094_335e9a12>:
  40c1a0:	push   rbx
  40c1a1:	push   rsi
  40c1a2:	push   rdi
  40c1a3:	push   r12
  40c1a5:	sub    rsp,0x28
  40c1a9:	mov    rbx,rcx
  40c1ac:	call   408900 <__swc_fn_585f006d_000093_344f5089>
  40c1b1:	mov    rcx,QWORD PTR [rip+0x19b88]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40c1b8:	test   rcx,rcx
  40c1bb:	jne    40c1cd <__swc_fn_585f006d_000094_335e9a12+0x2d>
  40c1bd:	call   40a1a0 <__swc_fn_585f006d_000165_e09accff>
  40c1c2:	lea    rcx,[rax+0x1]
  40c1c6:	mov    QWORD PTR [rip+0x19b73],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40c1cd:	dec    rcx
  40c1d0:	call   411aa0 <__swc_fn_585f006d_000167_3130645d>
  40c1d5:	mov    rsi,rax
  40c1d8:	lea    rcx,[rsp+0x8]
  40c1dd:	call   40f1f0 <__swc_fn_585f006d_000092_17e20532>
  40c1e2:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40c1e9:	mov    r12,QWORD PTR [rsi+0xbe8]
  40c1f0:	lea    rcx,[rsi+0x10]
  40c1f4:	call   40d170 <__swc_fn_585f006d_000157_5c8b11d8>
  40c1f9:	mov    rcx,rsi
  40c1fc:	call   40f360 <__swc_fn_585f006d_000101_295ddd7c>
  40c201:	vxorps xmm0,xmm0,xmm0
  40c205:	xor    eax,eax
  40c207:	cs nop WORD PTR [rax+rax*1+0x0]
  40c211:	cs nop WORD PTR [rax+rax*1+0x0]
  40c21b:	nop    DWORD PTR [rax+rax*1+0x0]
  40c220:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40c225:	add    rax,0x10
  40c229:	cmp    rax,0xbf0
  40c230:	jne    40c220 <__swc_fn_585f006d_000094_335e9a12+0x80>
  40c232:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c238:	vmovups XMMWORD PTR [rsi],xmm0
  40c23c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c242:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40c24a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40c251:	mov    QWORD PTR [rsi+0xbe8],r12
  40c258:	mov    rcx,QWORD PTR [rip+0x19ae1]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40c25f:	test   rcx,rcx
  40c262:	jne    40c274 <__swc_fn_585f006d_000094_335e9a12+0xd4>
  40c264:	call   40a1a0 <__swc_fn_585f006d_000165_e09accff>
  40c269:	lea    rcx,[rax+0x1]
  40c26d:	mov    QWORD PTR [rip+0x19acc],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40c274:	dec    rcx
  40c277:	call   411aa0 <__swc_fn_585f006d_000167_3130645d>
  40c27c:	mov    rsi,rax
  40c27f:	mov    QWORD PTR [rsi+0xc0],rbx
  40c286:	and    ebx,0x1
  40c289:	jne    40c28d <__swc_fn_585f006d_000094_335e9a12+0xed>
  40c28b:	xor    eax,eax
  40c28d:	test   rbx,rbx
  40c290:	sete   al
  40c293:	xor    cl,cl
  40c295:	xor    dl,dl
  40c297:	xor    r8b,r8b
  40c29a:	xor    r9b,r9b
  40c29d:	xor    r10b,r10b
  40c2a0:	mov    r11,rax
  40c2a3:	call   40ebb0 <__swc_fn_585f006d_000077_e793b5e1>
  40c2a8:	lea    rbx,[rsp+0x18]
  40c2ad:	mov    rcx,rbx
  40c2b0:	call   40f1f0 <__swc_fn_585f006d_000092_17e20532>
  40c2b5:	lea    rcx,[rsi+0x10]
  40c2b9:	mov    edx,0x400000
  40c2be:	mov    r8,rbx
  40c2c1:	call   409ee0 <__swc_fn_585f006d_000159_9d602c76>
  40c2c6:	lea    rcx,[rsi+0x68]
  40c2ca:	mov    edx,0x4000
  40c2cf:	mov    r8,rbx
  40c2d2:	call   409ee0 <__swc_fn_585f006d_000159_9d602c76>
  40c2d7:	add    rsp,0x28
  40c2db:	pop    r12
  40c2dd:	pop    rdi
  40c2de:	pop    rsi
  40c2df:	pop    rbx
  40c2e0:	ret
	...

000000000040c2f0 <__swc_fn_585f006d_000097_8b4a07e9>:
  40c2f0:	push   rbx
  40c2f1:	push   rsi
  40c2f2:	sub    rsp,0x18
  40c2f6:	mov    rbx,rcx
  40c2f9:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40c2fe:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c304:	mov    rsi,QWORD PTR [rbx+0x70]
  40c308:	lea    rcx,[rcx+0x18]
  40c30c:	call   40d170 <__swc_fn_585f006d_000157_5c8b11d8>
  40c311:	lea    rcx,[rsp+0x8]
  40c316:	mov    rdx,rbx
  40c319:	mov    r8d,0x78
  40c31f:	call   408960 <__swc_fn_585f006d_000096_f879630a>
  40c324:	mov    rax,rsi
  40c327:	add    rsp,0x18
  40c32b:	pop    rsi
  40c32c:	pop    rbx
  40c32d:	ret
	...

000000000040c330 <__swc_fn_585f006d_000100_2ef16a3e>:
  40c330:	push   rsi
  40c331:	push   rdi
  40c332:	sub    rsp,0x8
  40c336:	cmp    QWORD PTR [rcx],0x0
  40c33a:	jne    40c343 <__swc_fn_585f006d_000100_2ef16a3e+0x13>
  40c33c:	add    rsp,0x8
  40c340:	pop    rdi
  40c341:	pop    rsi
  40c342:	ret
  40c343:	mov    rsi,QWORD PTR [rcx]
  40c346:	mov    rax,QWORD PTR [rcx+0x8]
  40c34a:	test   rax,rax
  40c34d:	je     40c363 <__swc_fn_585f006d_000100_2ef16a3e+0x33>
  40c34f:	test   DWORD PTR [rax+0x28],0x400000
  40c356:	je     40c363 <__swc_fn_585f006d_000100_2ef16a3e+0x33>
  40c358:	mov    rcx,QWORD PTR [rax+0x30]
  40c35c:	test   rcx,rcx
  40c35f:	cmovne rax,rcx
  40c363:	lea    rdx,[rip+0x5e66]        # 4121d0 <__swc_rdata_base_585f006d+0xc0>
  40c36a:	lea    rcx,[rip+0x5f47]        # 4122b8 <__swc_rdata_base_585f006d+0x1a8>
  40c371:	mov    r8,rax
  40c374:	xor    r9d,r9d
  40c377:	xor    al,al
  40c379:	mov    r10,rax
  40c37c:	xor    r11d,r11d
  40c37f:	call   40c130 <__swc_fn_585f006d_000088_17711411>
  40c384:	test   rax,rax
  40c387:	je     40c397 <__swc_fn_585f006d_000100_2ef16a3e+0x67>
  40c389:	mov    rdi,QWORD PTR [rax+0x48]
  40c38d:	test   rdi,rdi
  40c390:	je     40c397 <__swc_fn_585f006d_000100_2ef16a3e+0x67>
  40c392:	mov    rcx,rsi
  40c395:	call   rdi
  40c397:	add    rsp,0x8
  40c39b:	pop    rdi
  40c39c:	pop    rsi
  40c39d:	ret
	...

000000000040c3a0 <__swc_fn_585f006d_000103_2ed36338>:
  40c3a0:	push   rbx
  40c3a1:	push   rsi
  40c3a2:	push   rdi
  40c3a3:	sub    rsp,0x20
  40c3a7:	mov    rbx,rdx
  40c3aa:	mov    rsi,rcx
  40c3ad:	mov    rcx,QWORD PTR [rip+0x1998c]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40c3b4:	test   rcx,rcx
  40c3b7:	jne    40c3c9 <__swc_fn_585f006d_000103_2ed36338+0x29>
  40c3b9:	call   40a1a0 <__swc_fn_585f006d_000165_e09accff>
  40c3be:	lea    rcx,[rax+0x1]
  40c3c2:	mov    QWORD PTR [rip+0x19977],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40c3c9:	dec    rcx
  40c3cc:	call   411aa0 <__swc_fn_585f006d_000167_3130645d>
  40c3d1:	mov    rdi,rax
  40c3d4:	mov    rax,QWORD PTR [rdi+0xbd0]
  40c3db:	xor    ecx,ecx
  40c3dd:	test   rax,rax
  40c3e0:	je     40c3e5 <__swc_fn_585f006d_000103_2ed36338+0x45>
  40c3e2:	mov    rcx,QWORD PTR [rax]
  40c3e5:	call   40a2d0 <__swc_fn_585f006d_000174_738eec22>
  40c3ea:	lea    rax,[rsp+0x8]
  40c3ef:	lea    rcx,[rdi+0x9c8]
  40c3f6:	mov    QWORD PTR [rsp+0x8],rcx
  40c3fb:	mov    QWORD PTR [rax+0x8],0x40
  40c403:	xor    ecx,ecx
  40c405:	mov    rdx,rax
  40c408:	call   40fe00 <__swc_fn_585f006d_000119_18cd3882>
  40c40d:	mov    DWORD PTR [rdi+0xbc8],eax
  40c413:	mov    rdi,QWORD PTR [rdi+0x990]
  40c41a:	test   rdi,rdi
  40c41d:	je     40c427 <__swc_fn_585f006d_000103_2ed36338+0x87>
  40c41f:	mov    rcx,rsi
  40c422:	mov    rdx,rbx
  40c425:	call   rdi
  40c427:	call   40c150 <__swc_fn_585f006d_000091_e6773530>
  40c42c:	test   al,al
  40c42e:	je     40c43e <__swc_fn_585f006d_000103_2ed36338+0x9e>
  40c430:	mov    rcx,rsi
  40c433:	mov    rdx,rbx
  40c436:	xor    r8d,r8d
  40c439:	call   4093e0 <__swc_fn_585f006d_000120_1601f378>
  40c43e:	mov    rcx,rsi
  40c441:	mov    rdx,rbx
  40c444:	call   408a60 <__swc_fn_585f006d_000102_29a1093a>
  40c449:	call   40c9d0 <__swc_fn_585f006d_000118_2b35b5e0>
  40c44e:	add    rsp,0x20
  40c452:	pop    rdi
  40c453:	pop    rsi
  40c454:	pop    rbx
  40c455:	ret
	...

000000000040c460 <__swc_fn_585f006d_000106_77a5d54a>:
  40c460:	test   r8,r8
  40c463:	jne    40c468 <__swc_fn_585f006d_000106_77a5d54a+0x8>
  40c465:	xor    eax,eax
  40c467:	ret
  40c468:	xor    eax,eax
  40c46a:	nop    WORD PTR [rax+rax*1+0x0]
  40c470:	mov    r9,r8
  40c473:	sub    r9,rax
  40c476:	cmp    r9,0x10
  40c47a:	jb     40c4c4 <__swc_fn_585f006d_000106_77a5d54a+0x64>
  40c47c:	lea    r9,[rcx+rax*1]
  40c480:	lea    r10,[rdx+rax*1]
  40c484:	vmovups xmm0,XMMWORD PTR [r10]
  40c489:	vmovups xmm1,XMMWORD PTR [r9]
  40c48e:	vpcmpeqb xmm0,xmm1,xmm0
  40c492:	vpmovmskb r9d,xmm0
  40c496:	cmp    r9d,0xffff
  40c49d:	je     40c4be <__swc_fn_585f006d_000106_77a5d54a+0x5e>
  40c49f:	not    r9d
  40c4a2:	xor    r8d,r8d
  40c4a5:	movzx  r9d,r9w
  40c4a9:	tzcnt  r8d,r9d
  40c4ae:	add    rax,r8
  40c4b1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4b5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4b9:	sub    ecx,eax
  40c4bb:	mov    eax,ecx
  40c4bd:	ret
  40c4be:	lea    rax,[rax+0x10]
  40c4c2:	jmp    40c470 <__swc_fn_585f006d_000106_77a5d54a+0x10>
  40c4c4:	cmp    r9,0x8
  40c4c8:	jb     40c53b <__swc_fn_585f006d_000106_77a5d54a+0xdb>
  40c4ca:	lea    r9,[rcx+rax*1]
  40c4ce:	lea    r10,[rdx+rax*1]
  40c4d2:	mov    r9,QWORD PTR [r9]
  40c4d5:	xor    r9,QWORD PTR [r10]
  40c4d8:	test   r9,r9
  40c4db:	je     40c4f9 <__swc_fn_585f006d_000106_77a5d54a+0x99>
  40c4dd:	xor    r8d,r8d
  40c4e0:	tzcnt  r8,r9
  40c4e5:	shr    r8,0x3
  40c4e9:	add    rax,r8
  40c4ec:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4f0:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4f4:	sub    ecx,eax
  40c4f6:	mov    eax,ecx
  40c4f8:	ret
  40c4f9:	lea    rax,[rax+0x8]
  40c4fd:	cmp    rax,r8
  40c500:	jne    40c505 <__swc_fn_585f006d_000106_77a5d54a+0xa5>
  40c502:	xor    eax,eax
  40c504:	ret
  40c505:	lea    rax,[r8-0x8]
  40c509:	lea    r8,[rcx+rax*1]
  40c50d:	lea    r9,[rdx+rax*1]
  40c511:	mov    r8,QWORD PTR [r8]
  40c514:	xor    r8,QWORD PTR [r9]
  40c517:	test   r8,r8
  40c51a:	je     40c538 <__swc_fn_585f006d_000106_77a5d54a+0xd8>
  40c51c:	xor    r9d,r9d
  40c51f:	tzcnt  r9,r8
  40c524:	shr    r9,0x3
  40c528:	add    rax,r9
  40c52b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c52f:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c533:	sub    ecx,eax
  40c535:	mov    eax,ecx
  40c537:	ret
  40c538:	xor    eax,eax
  40c53a:	ret
  40c53b:	cmp    r9,0x4
  40c53f:	jb     40c5b2 <__swc_fn_585f006d_000106_77a5d54a+0x152>
  40c541:	lea    r9,[rcx+rax*1]
  40c545:	lea    r10,[rdx+rax*1]
  40c549:	mov    r9d,DWORD PTR [r9]
  40c54c:	xor    r9d,DWORD PTR [r10]
  40c54f:	test   r9d,r9d
  40c552:	je     40c570 <__swc_fn_585f006d_000106_77a5d54a+0x110>
  40c554:	xor    r8d,r8d
  40c557:	tzcnt  r8,r9
  40c55c:	shr    r8,0x3
  40c560:	add    rax,r8
  40c563:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c567:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c56b:	sub    ecx,eax
  40c56d:	mov    eax,ecx
  40c56f:	ret
  40c570:	lea    rax,[rax+0x4]
  40c574:	cmp    rax,r8
  40c577:	jne    40c57c <__swc_fn_585f006d_000106_77a5d54a+0x11c>
  40c579:	xor    eax,eax
  40c57b:	ret
  40c57c:	lea    rax,[r8-0x4]
  40c580:	lea    r8,[rcx+rax*1]
  40c584:	lea    r9,[rdx+rax*1]
  40c588:	mov    r8d,DWORD PTR [r8]
  40c58b:	xor    r8d,DWORD PTR [r9]
  40c58e:	test   r8d,r8d
  40c591:	je     40c5af <__swc_fn_585f006d_000106_77a5d54a+0x14f>
  40c593:	xor    r9d,r9d
  40c596:	tzcnt  r9,r8
  40c59b:	shr    r9,0x3
  40c59f:	add    rax,r9
  40c5a2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c5a6:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c5aa:	sub    ecx,eax
  40c5ac:	mov    eax,ecx
  40c5ae:	ret
  40c5af:	xor    eax,eax
  40c5b1:	ret
  40c5b2:	cmp    r9,0x2
  40c5b6:	jb     40c609 <__swc_fn_585f006d_000106_77a5d54a+0x1a9>
  40c5b8:	lea    r9,[rcx+rax*1]
  40c5bc:	lea    r10,[rdx+rax*1]
  40c5c0:	mov    r9w,WORD PTR [r9]
  40c5c4:	xor    r9w,WORD PTR [r10]
  40c5c8:	test   r9w,r9w
  40c5cc:	je     40c5ee <__swc_fn_585f006d_000106_77a5d54a+0x18e>
  40c5ce:	xor    r8d,r8d
  40c5d1:	movzx  r9d,r9w
  40c5d5:	tzcnt  r8,r9
  40c5da:	shr    r8,0x3
  40c5de:	add    rax,r8
  40c5e1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c5e5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c5e9:	sub    ecx,eax
  40c5eb:	mov    eax,ecx
  40c5ed:	ret
  40c5ee:	lea    rax,[rax+0x2]
  40c5f2:	cmp    rax,r8
  40c5f5:	jne    40c5fa <__swc_fn_585f006d_000106_77a5d54a+0x19a>
  40c5f7:	xor    eax,eax
  40c5f9:	ret
  40c5fa:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40c600:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40c606:	sub    eax,ecx
  40c608:	ret
  40c609:	test   r9,r9
  40c60c:	je     40c61b <__swc_fn_585f006d_000106_77a5d54a+0x1bb>
  40c60e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c612:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c616:	sub    ecx,eax
  40c618:	mov    eax,ecx
  40c61a:	ret
  40c61b:	xor    eax,eax
  40c61d:	ret
	...

000000000040c620 <__swc_fn_585f006d_000109_aa570b2b>:
  40c620:	push   r12
  40c622:	push   r13
  40c624:	push   r14
  40c626:	push   rdi
  40c627:	push   rsi
  40c628:	push   r15
  40c62a:	sub    rsp,0xd8
  40c631:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c637:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c63d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c643:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c649:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c64f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c658:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c661:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c66a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c673:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c67c:	mov    r12,rcx
  40c67f:	test   rcx,rcx
  40c682:	je     40c69e <__swc_fn_585f006d_000109_aa570b2b+0x7e>
  40c684:	mov    eax,r12d
  40c687:	and    eax,0xfff
  40c68d:	setne  al
  40c690:	cmp    r12,0xffffffffffffefff
  40c697:	seta   cl
  40c69a:	or     al,cl
  40c69c:	je     40c6a5 <__swc_fn_585f006d_000109_aa570b2b+0x85>
  40c69e:	xor    eax,eax
  40c6a0:	jmp    40c73b <__swc_fn_585f006d_000109_aa570b2b+0x11b>
  40c6a5:	call   409100 <__swc_fn_585f006d_000108_32416b9e>
  40c6aa:	mov    r13,rax
  40c6ad:	test   rax,rax
  40c6b0:	jne    40c6b9 <__swc_fn_585f006d_000109_aa570b2b+0x99>
  40c6b2:	xor    eax,eax
  40c6b4:	jmp    40c73b <__swc_fn_585f006d_000109_aa570b2b+0x11b>
  40c6b9:	lea    r14,[r12+0x1000]
  40c6c1:	xor    edi,edi
  40c6c3:	mov    rsi,r14
  40c6c6:	xor    edx,edx
  40c6c8:	mov    ecx,0x22
  40c6cd:	mov    eax,0xffffffff
  40c6d2:	movsxd r8,eax
  40c6d5:	xor    r9d,r9d
  40c6d8:	xor    eax,eax
  40c6da:	call   4070c0 <mmap@plt>
  40c6df:	mov    r15,rax
  40c6e2:	cmp    rax,0xffffffffffffffff
  40c6e6:	jne    40c6ec <__swc_fn_585f006d_000109_aa570b2b+0xcc>
  40c6e8:	xor    eax,eax
  40c6ea:	jmp    40c73b <__swc_fn_585f006d_000109_aa570b2b+0x11b>
  40c6ec:	mov    rdi,r15
  40c6ef:	mov    esi,0x1000
  40c6f4:	mov    edx,0x3
  40c6f9:	xor    eax,eax
  40c6fb:	call   407030 <mprotect@plt>
  40c700:	test   eax,eax
  40c702:	je     40c715 <__swc_fn_585f006d_000109_aa570b2b+0xf5>
  40c704:	mov    rdi,r15
  40c707:	mov    rsi,r14
  40c70a:	xor    eax,eax
  40c70c:	call   407020 <munmap@plt>
  40c711:	xor    eax,eax
  40c713:	jmp    40c73b <__swc_fn_585f006d_000109_aa570b2b+0x11b>
  40c715:	mov    QWORD PTR [r15+0x8],r12
  40c719:	mov    rcx,r13
  40c71c:	call   40cd70 <__swc_fn_585f006d_000133_c6de0049>
  40c721:	mov    rax,QWORD PTR [r13+0x8]
  40c725:	mov    QWORD PTR [r15],rax
  40c728:	mov    QWORD PTR [r13+0x8],r15
  40c72c:	mov    rcx,r13
  40c72f:	call   4101a0 <__swc_fn_585f006d_000134_5696c87e>
  40c734:	lea    rax,[r15+0x1000]
  40c73b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c741:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c747:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c74d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c753:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c759:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c762:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c76b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c774:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c77d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c786:	add    rsp,0xd8
  40c78d:	pop    r15
  40c78f:	pop    rsi
  40c790:	pop    rdi
  40c791:	pop    r14
  40c793:	pop    r13
  40c795:	pop    r12
  40c797:	ret
	...

000000000040c7a0 <__swc_fn_585f006d_000112_cb2656be>:
  40c7a0:	push   rbx
  40c7a1:	push   r12
  40c7a3:	push   rdi
  40c7a4:	push   rsi
  40c7a5:	sub    rsp,0xa8
  40c7ac:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c7b2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c7b8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c7be:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c7c4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c7ca:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c7d0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40c7d6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40c7dc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40c7e5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40c7ee:	mov    rbx,rdx
  40c7f1:	mov    r12,rcx
  40c7f4:	mov    rdi,rcx
  40c7f7:	mov    rsi,rdx
  40c7fa:	xor    edx,edx
  40c7fc:	xor    eax,eax
  40c7fe:	call   407030 <mprotect@plt>
  40c803:	test   eax,eax
  40c805:	jne    40c829 <__swc_fn_585f006d_000112_cb2656be+0x89>
  40c807:	mov    rcx,r12
  40c80a:	mov    rdx,rbx
  40c80d:	xor    al,al
  40c80f:	mov    r8,rax
  40c812:	call   40fc40 <__swc_fn_585f006d_000110_e606239a>
  40c817:	mov    rdi,r12
  40c81a:	mov    rsi,rbx
  40c81d:	mov    edx,0x4
  40c822:	xor    eax,eax
  40c824:	call   4070f0 <madvise@plt>
  40c829:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40c82f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40c835:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40c83b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40c841:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40c847:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40c84d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40c853:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40c859:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40c862:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40c86b:	add    rsp,0xa8
  40c872:	pop    rsi
  40c873:	pop    rdi
  40c874:	pop    r12
  40c876:	pop    rbx
  40c877:	ret
	...

000000000040c880 <__swc_fn_585f006d_000115_259b5d5a>:
  40c880:	push   rsi
  40c881:	push   rdi
  40c882:	push   r12
  40c884:	push   r13
  40c886:	push   r14
  40c888:	sub    rsp,0xe0
  40c88f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c895:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c89b:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c8a1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c8a7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c8ad:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c8b6:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c8bf:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c8c8:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c8d1:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c8da:	mov    rsi,rdx
  40c8dd:	mov    rdi,rcx
  40c8e0:	call   409100 <__swc_fn_585f006d_000108_32416b9e>
  40c8e5:	mov    r12,rax
  40c8e8:	test   rax,rax
  40c8eb:	jne    40c8f2 <__swc_fn_585f006d_000115_259b5d5a+0x72>
  40c8ed:	jmp    40c966 <__swc_fn_585f006d_000115_259b5d5a+0xe6>
  40c8f2:	mov    rcx,r12
  40c8f5:	call   40cd70 <__swc_fn_585f006d_000133_c6de0049>
  40c8fa:	lea    r13,[r12+0x8]
  40c8ff:	mov    rax,QWORD PTR [r13+0x0]
  40c903:	test   rax,rax
  40c906:	je     40c95e <__swc_fn_585f006d_000115_259b5d5a+0xde>
  40c908:	nop    DWORD PTR [rax+rax*1+0x0]
  40c910:	lea    rcx,[rax+0x1000]
  40c917:	cmp    rcx,rdi
  40c91a:	jne    40c952 <__swc_fn_585f006d_000115_259b5d5a+0xd2>
  40c91c:	cmp    QWORD PTR [rax+0x8],rsi
  40c920:	je     40c92c <__swc_fn_585f006d_000115_259b5d5a+0xac>
  40c922:	mov    rcx,r12
  40c925:	call   4101a0 <__swc_fn_585f006d_000134_5696c87e>
  40c92a:	jmp    40c966 <__swc_fn_585f006d_000115_259b5d5a+0xe6>
  40c92c:	mov    r14,QWORD PTR [rax]
  40c92f:	mov    rdi,rax
  40c932:	lea    rsi,[rsi+0x1000]
  40c939:	xor    eax,eax
  40c93b:	call   407020 <munmap@plt>
  40c940:	test   eax,eax
  40c942:	jne    40c948 <__swc_fn_585f006d_000115_259b5d5a+0xc8>
  40c944:	mov    QWORD PTR [r13+0x0],r14
  40c948:	mov    rcx,r12
  40c94b:	call   4101a0 <__swc_fn_585f006d_000134_5696c87e>
  40c950:	jmp    40c966 <__swc_fn_585f006d_000115_259b5d5a+0xe6>
  40c952:	mov    r13,rax
  40c955:	mov    rax,QWORD PTR [r13+0x0]
  40c959:	test   rax,rax
  40c95c:	jne    40c910 <__swc_fn_585f006d_000115_259b5d5a+0x90>
  40c95e:	mov    rcx,r12
  40c961:	call   4101a0 <__swc_fn_585f006d_000134_5696c87e>
  40c966:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c96c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c972:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c978:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c97e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c984:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c98d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c996:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c99f:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c9a8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c9b1:	add    rsp,0xe0
  40c9b8:	pop    r14
  40c9ba:	pop    r13
  40c9bc:	pop    r12
  40c9be:	pop    rdi
  40c9bf:	pop    rsi
  40c9c0:	ret
	...

000000000040c9d0 <__swc_fn_585f006d_000118_2b35b5e0>:
  40c9d0:	push   rdi
  40c9d1:	push   rsi
  40c9d2:	sub    rsp,0xa8
  40c9d9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c9df:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c9e5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c9eb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c9f1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c9f7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c9fd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ca03:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ca09:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ca12:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ca1b:	mov    rdi,0xfffffffffffffd66
  40ca22:	xor    eax,eax
  40ca24:	call   407040 <exit@plt>
  40ca29:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ca2f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ca35:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ca3b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ca41:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ca47:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ca4d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ca53:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ca59:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ca62:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ca6b:	add    rsp,0xa8
  40ca72:	pop    rsi
  40ca73:	pop    rdi
  40ca74:	ret
	...

000000000040ca80 <__swc_fn_585f006d_000121_71a5b1cd>:
  40ca80:	push   rbx
  40ca81:	push   rsi
  40ca82:	push   rdi
  40ca83:	sub    rsp,0x30
  40ca87:	mov    rbx,rdx
  40ca8a:	mov    esi,ecx
  40ca8c:	test   ecx,ecx
  40ca8e:	je     40cb63 <__swc_fn_585f006d_000121_71a5b1cd+0xe3>
  40ca94:	mov    rcx,rsi
  40ca97:	shl    rcx,0x4
  40ca9b:	call   40bf90 <__swc_fn_585f006d_000079_29fad089>
  40caa0:	test   rax,rax
  40caa3:	je     40cb52 <__swc_fn_585f006d_000121_71a5b1cd+0xd2>
  40caa9:	mov    rcx,rsi
  40caac:	xor    edx,edx
  40caae:	test   rsi,rsi
  40cab1:	jbe    40cb32 <__swc_fn_585f006d_000121_71a5b1cd+0xb2>
  40cab7:	nop    WORD PTR [rax+rax*1+0x0]
  40cac0:	mov    r8d,edx
  40cac3:	mov    r9,QWORD PTR [rbx+r8*8]
  40cac7:	add    r8,r8
  40caca:	lea    r8,[rax+r8*8]
  40cace:	xor    r10d,r10d
  40cad1:	test   r9,r9
  40cad4:	je     40cb10 <__swc_fn_585f006d_000121_71a5b1cd+0x90>
  40cad6:	mov    r11,r9
  40cad9:	mov    dil,BYTE PTR [r11]
  40cadc:	test   dil,dil
  40cadf:	je     40cb10 <__swc_fn_585f006d_000121_71a5b1cd+0x90>
  40cae1:	cs nop WORD PTR [rax+rax*1+0x0]
  40caeb:	cs nop WORD PTR [rax+rax*1+0x0]
  40caf5:	cs nop WORD PTR [rax+rax*1+0x0]
  40caff:	nop
  40cb00:	add    r11,0x1
  40cb04:	add    r10,0x1
  40cb08:	mov    dil,BYTE PTR [r11]
  40cb0b:	test   dil,dil
  40cb0e:	jne    40cb00 <__swc_fn_585f006d_000121_71a5b1cd+0x80>
  40cb10:	mov    QWORD PTR [rsp+0x18],r9
  40cb15:	mov    QWORD PTR [rsp+0x20],r10
  40cb1a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40cb20:	vmovups XMMWORD PTR [r8],xmm0
  40cb25:	add    rdx,0x1
  40cb29:	cmp    rdx,rcx
  40cb2c:	jb     40cac0 <__swc_fn_585f006d_000121_71a5b1cd+0x40>
  40cb32:	lea    rcx,[rip+0x19217]        # 425d50 <__swc_bss_base_585f006d+0x2d10>
  40cb39:	mov    QWORD PTR [rsp+0x8],rax
  40cb3e:	mov    esi,esi
  40cb40:	mov    QWORD PTR [rsp+0x10],rsi
  40cb45:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40cb4b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40cb50:	jmp    40cb63 <__swc_fn_585f006d_000121_71a5b1cd+0xe3>
  40cb52:	lea    rcx,[rip+0x59c7]        # 412520 <__swc_rdata_base_585f006d+0x410>
  40cb59:	call   40fcf0 <__swc_fn_585f006d_000116_3499f7d6>
  40cb5e:	call   40c9d0 <__swc_fn_585f006d_000118_2b35b5e0>
  40cb63:	add    rsp,0x30
  40cb67:	pop    rdi
  40cb68:	pop    rsi
  40cb69:	pop    rbx
  40cb6a:	ret
  40cb6b:	add    BYTE PTR [rax],al
  40cb6d:	add    BYTE PTR [rax],al
	...

000000000040cb70 <__swc_fn_585f006d_000124_df97aa0a>:
  40cb70:	push   rdi
  40cb71:	push   rsi
  40cb72:	sub    rsp,0xa8
  40cb79:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cb7f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cb85:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cb8b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cb91:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cb97:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cb9d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cba3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cba9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cbb2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cbbb:	mov    edi,ecx
  40cbbd:	xor    eax,eax
  40cbbf:	call   407100 <pthread_key_delete@plt>
  40cbc4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cbca:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cbd0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cbd6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cbdc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cbe2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cbe8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cbee:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cbf4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cbfd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cc06:	add    rsp,0xa8
  40cc0d:	pop    rsi
  40cc0e:	pop    rdi
  40cc0f:	ret

000000000040cc10 <__swc_fn_585f006d_000127_75f8ab5c>:
  40cc10:	push   rdi
  40cc11:	push   rsi
  40cc12:	sub    rsp,0xa8
  40cc19:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cc1f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cc25:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cc2b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cc31:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cc37:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cc3d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cc43:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cc49:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cc52:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cc5b:	test   rcx,rcx
  40cc5e:	je     40cc6f <__swc_fn_585f006d_000127_75f8ab5c+0x5f>
  40cc60:	lea    rax,[rcx-0x1]
  40cc64:	mov    eax,eax
  40cc66:	mov    edi,eax
  40cc68:	xor    eax,eax
  40cc6a:	call   407100 <pthread_key_delete@plt>
  40cc6f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cc75:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cc7b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cc81:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cc87:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cc8d:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cc93:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cc99:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cc9f:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cca8:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ccb1:	add    rsp,0xa8
  40ccb8:	pop    rsi
  40ccb9:	pop    rdi
  40ccba:	ret
  40ccbb:	add    BYTE PTR [rax],al
  40ccbd:	add    BYTE PTR [rax],al
	...

000000000040ccc0 <__swc_fn_585f006d_000130_d2d78689>:
  40ccc0:	push   rsi
  40ccc1:	push   rdi
  40ccc2:	sub    rsp,0xa8
  40ccc9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cccf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ccd5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ccdb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cce1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cce7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cced:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ccf3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ccf9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cd02:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cd0b:	xor    eax,eax
  40cd0d:	call   407110 <gettid@plt>
  40cd12:	movsxd rax,eax
  40cd15:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cd1b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cd21:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cd27:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cd2d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cd33:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cd39:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cd3f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cd45:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cd4e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cd57:	add    rsp,0xa8
  40cd5e:	pop    rdi
  40cd5f:	pop    rsi
  40cd60:	ret
	...

000000000040cd70 <__swc_fn_585f006d_000133_c6de0049>:
  40cd70:	push   rbx
  40cd71:	push   rdi
  40cd72:	push   rsi
  40cd73:	sub    rsp,0xc0
  40cd7a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40cd80:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40cd86:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40cd8c:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40cd92:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40cd98:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40cd9e:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40cda4:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40cdad:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40cdb6:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40cdbf:	mov    rbx,rcx
  40cdc2:	cs nop WORD PTR [rax+rax*1+0x0]
  40cdcc:	nop    DWORD PTR [rax+0x0]
  40cdd0:	mov    edx,0x80000000
  40cdd5:	xor    eax,eax
  40cdd7:	lock cmpxchg DWORD PTR [rbx],edx
  40cddb:	test   eax,eax
  40cddd:	je     40ce14 <__swc_fn_585f006d_000133_c6de0049+0xa4>
  40cddf:	mov    eax,DWORD PTR [rbx]
  40cde1:	lea    rcx,[rsp+0x14]
  40cde6:	mov    DWORD PTR [rsp+0x14],eax
  40cdea:	test   eax,eax
  40cdec:	je     40cdd0 <__swc_fn_585f006d_000133_c6de0049+0x60>
  40cdee:	mov    QWORD PTR [rsp],0x0
  40cdf6:	mov    edi,0xca
  40cdfb:	mov    rsi,rbx
  40cdfe:	mov    edx,0x80
  40ce03:	mov    ecx,DWORD PTR [rcx]
  40ce05:	xor    r8d,r8d
  40ce08:	xor    r9d,r9d
  40ce0b:	xor    eax,eax
  40ce0d:	call   407070 <syscall@plt>
  40ce12:	jmp    40cdd0 <__swc_fn_585f006d_000133_c6de0049+0x60>
  40ce14:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ce1a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40ce20:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40ce26:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ce2c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ce32:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ce38:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ce3e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ce47:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ce50:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ce59:	add    rsp,0xc0
  40ce60:	pop    rsi
  40ce61:	pop    rdi
  40ce62:	pop    rbx
  40ce63:	ret
	...

000000000040ce70 <__swc_fn_585f006d_000136_5589b4a1>:
  40ce70:	sub    rsp,0x8
  40ce74:	call   4101a0 <__swc_fn_585f006d_000134_5696c87e>
  40ce79:	add    rsp,0x8
  40ce7d:	ret
	...

000000000040ce80 <__swc_fn_585f006d_000139_20e2e2c7>:
  40ce80:	push   rdi
  40ce81:	push   rsi
  40ce82:	sub    rsp,0xa8
  40ce89:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ce8f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ce95:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ce9b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cea1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cea7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cead:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ceb3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ceb9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cec2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cecb:	mov    edi,0x28
  40ced0:	xor    eax,eax
  40ced2:	call   4070d0 <malloc@plt>
  40ced7:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cedd:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cee3:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cee9:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ceef:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cef5:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cefb:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cf01:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cf07:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cf10:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cf19:	add    rsp,0xa8
  40cf20:	pop    rsi
  40cf21:	pop    rdi
  40cf22:	ret
	...

000000000040cf30 <__swc_fn_585f006d_000142_e0543f36>:
  40cf30:	mov    QWORD PTR [r8],0x0
  40cf37:	cmp    rdx,0x10
  40cf3b:	jae    40cf40 <__swc_fn_585f006d_000142_e0543f36+0x10>
  40cf3d:	xor    eax,eax
  40cf3f:	ret
  40cf40:	mov    eax,DWORD PTR [rcx]
  40cf42:	cmp    eax,0x42445753
  40cf48:	jne    40cf52 <__swc_fn_585f006d_000142_e0543f36+0x22>
  40cf4a:	mov    eax,DWORD PTR [rcx+0x4]
  40cf4d:	cmp    eax,0x1
  40cf50:	je     40cf55 <__swc_fn_585f006d_000142_e0543f36+0x25>
  40cf52:	xor    eax,eax
  40cf54:	ret
  40cf55:	mov    QWORD PTR [r8],rdx
  40cf58:	mov    rax,rcx
  40cf5b:	ret
  40cf5c:	add    BYTE PTR [rax],al
	...

000000000040cf60 <__swc_fn_585f006d_000145_071b4f4c>:
  40cf60:	push   rbx
  40cf61:	sub    rsp,0xe0
  40cf68:	lea    rbx,[rsp+0x8]
  40cf6d:	vxorps xmm0,xmm0,xmm0
  40cf71:	vmovups YMMWORD PTR [rbx],ymm0
  40cf75:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40cf7a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40cf7f:	vzeroupper
  40cf82:	mov    DWORD PTR [rbx+0x60],0x0
  40cf89:	mov    r8,rbx
  40cf8c:	mov    rdx,rcx
  40cf8f:	nop
  40cf90:	mov    r9,rdx
  40cf93:	movabs rdx,0x6666666666666667
  40cf9d:	mov    rax,r9
  40cfa0:	imul   rdx
  40cfa3:	sar    rdx,0x2
  40cfa7:	mov    r10,rdx
  40cfaa:	shr    rdx,0x3f
  40cfae:	add    r10,rdx
  40cfb1:	mov    rdx,r10
  40cfb4:	imul   r11,r10,0xa
  40cfb8:	sub    r9,r11
  40cfbb:	mov    r11,QWORD PTR [rip+0x557e]        # 412540 <__swc_rdata_base_585f006d+0x430>
  40cfc2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40cfc7:	mov    BYTE PTR [r8],r9b
  40cfca:	lea    r9,[r8+0x1]
  40cfce:	mov    r8,r9
  40cfd1:	test   r10,r10
  40cfd4:	jne    40cf90 <__swc_fn_585f006d_000145_071b4f4c+0x30>
  40cfd6:	test   rcx,rcx
  40cfd9:	jge    40cfe3 <__swc_fn_585f006d_000145_071b4f4c+0x83>
  40cfdb:	mov    BYTE PTR [r9],0x2d
  40cfdf:	add    r8,0x1
  40cfe3:	mov    BYTE PTR [r8],0x0
  40cfe7:	sub    r8,0x1
  40cfeb:	mov    rax,rbx
  40cfee:	cmp    rax,r8
  40cff1:	jae    40d016 <__swc_fn_585f006d_000145_071b4f4c+0xb6>
  40cff3:	cs nop WORD PTR [rax+rax*1+0x0]
  40cffd:	nop    DWORD PTR [rax]
  40d000:	mov    cl,BYTE PTR [r8]
  40d003:	mov    dl,BYTE PTR [rax]
  40d005:	mov    BYTE PTR [r8],dl
  40d008:	sub    r8,0x1
  40d00c:	mov    BYTE PTR [rax],cl
  40d00e:	inc    rax
  40d011:	cmp    rax,r8
  40d014:	jb     40d000 <__swc_fn_585f006d_000145_071b4f4c+0xa0>
  40d016:	xor    eax,eax
  40d018:	test   rbx,rbx
  40d01b:	je     40d03e <__swc_fn_585f006d_000145_071b4f4c+0xde>
  40d01d:	mov    rcx,rbx
  40d020:	mov    dl,BYTE PTR [rcx]
  40d022:	test   dl,dl
  40d024:	je     40d03e <__swc_fn_585f006d_000145_071b4f4c+0xde>
  40d026:	cs nop WORD PTR [rax+rax*1+0x0]
  40d030:	add    rcx,0x1
  40d034:	add    rax,0x1
  40d038:	mov    dl,BYTE PTR [rcx]
  40d03a:	test   dl,dl
  40d03c:	jne    40d030 <__swc_fn_585f006d_000145_071b4f4c+0xd0>
  40d03e:	mov    QWORD PTR [rbx+0xa8],rbx
  40d045:	mov    QWORD PTR [rbx+0xb0],rax
  40d04c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d054:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d05c:	lea    rcx,[rbx+0xb8]
  40d063:	call   40fcf0 <__swc_fn_585f006d_000116_3499f7d6>
  40d068:	add    rsp,0xe0
  40d06f:	pop    rbx
  40d070:	ret
	...

000000000040d080 <__swc_fn_585f006d_000148_33e5e24f>:
  40d080:	vxorps xmm0,xmm0,xmm0
  40d084:	vmovups XMMWORD PTR [rcx],xmm0
  40d088:	mov    QWORD PTR [rcx+0x10],0x0
  40d090:	ret
	...

000000000040d0a0 <__swc_fn_585f006d_000151_33e5e24f>:
  40d0a0:	vxorps xmm0,xmm0,xmm0
  40d0a4:	vmovups XMMWORD PTR [rcx],xmm0
  40d0a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d0ad:	vxorps xmm0,xmm0,xmm0
  40d0b1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d0b6:	vmovups xmm0,XMMWORD PTR [rip+0x557a]        # 412638 <__swc_rdata_base_585f006d+0x528>
  40d0be:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d0c3:	vxorps xmm0,xmm0,xmm0
  40d0c7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d0cc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d0d1:	mov    QWORD PTR [rcx+0x60],0x0
  40d0d9:	ret
  40d0da:	add    BYTE PTR [rax],al
  40d0dc:	add    BYTE PTR [rax],al
	...

000000000040d0e0 <__swc_fn_585f006d_000154_33e5e24f>:
  40d0e0:	vxorps xmm0,xmm0,xmm0
  40d0e4:	vmovups XMMWORD PTR [rcx],xmm0
  40d0e8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d0ed:	vxorps xmm0,xmm0,xmm0
  40d0f1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d0f6:	vmovups xmm0,XMMWORD PTR [rip+0x5662]        # 412760 <__swc_rdata_base_585f006d+0x650>
  40d0fe:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d103:	vxorps xmm0,xmm0,xmm0
  40d107:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d10c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d111:	vxorps xmm0,xmm0,xmm0
  40d115:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40d11a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40d11f:	vxorps xmm0,xmm0,xmm0
  40d123:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40d12b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40d133:	vxorps xmm0,xmm0,xmm0
  40d137:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40d13f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40d147:	vxorps xmm0,xmm0,xmm0
  40d14b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40d153:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40d15b:	mov    QWORD PTR [rcx+0xe0],0x0
  40d166:	ret
	...

000000000040d170 <__swc_fn_585f006d_000157_5c8b11d8>:
  40d170:	push   rbx
  40d171:	mov    rbx,rcx
  40d174:	call   411730 <__swc_fn_585f006d_000158_6741c23b>
  40d179:	mov    rax,QWORD PTR [rbx+0x10]
  40d17d:	test   rax,rax
  40d180:	je     40d191 <__swc_fn_585f006d_000157_5c8b11d8+0x21>
  40d182:	mov    rcx,rbx
  40d185:	mov    rdx,rax
  40d188:	mov    r8,QWORD PTR [rbx+0x18]
  40d18c:	call   409e90 <__swc_fn_585f006d_000156_312df05a>
  40d191:	vxorps xmm0,xmm0,xmm0
  40d195:	vmovups XMMWORD PTR [rbx],xmm0
  40d199:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d19e:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d1a3:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d1a8:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d1ad:	mov    QWORD PTR [rbx+0x50],0x0
  40d1b5:	pop    rbx
  40d1b6:	ret
	...

000000000040d1c0 <__swc_fn_585f006d_000160_e25d06b9>:
  40d1c0:	sub    rsp,0x10
  40d1c4:	mov    eax,r8d
  40d1c7:	mov    r8d,r9d
  40d1ca:	test   r9d,r9d
  40d1cd:	jne    40d1e6 <__swc_fn_585f006d_000160_e25d06b9+0x26>
  40d1cf:	vmovups xmm0,XMMWORD PTR [rip+0x5641]        # 412818 <__swc_rdata_base_585f006d+0x708>
  40d1d7:	vmovups XMMWORD PTR [r10],xmm0
  40d1dc:	mov    eax,0x1
  40d1e1:	add    rsp,0x10
  40d1e5:	ret
  40d1e6:	mov    r9,r8
  40d1e9:	cmp    r8,rax
  40d1ec:	jb     40d1f3 <__swc_fn_585f006d_000160_e25d06b9+0x33>
  40d1ee:	cmp    r9,rdx
  40d1f1:	jb     40d1fa <__swc_fn_585f006d_000160_e25d06b9+0x3a>
  40d1f3:	xor    eax,eax
  40d1f5:	add    rsp,0x10
  40d1f9:	ret
  40d1fa:	xor    eax,eax
  40d1fc:	lea    r8,[r9+rax*1]
  40d200:	cmp    r8,rdx
  40d203:	jae    40d233 <__swc_fn_585f006d_000160_e25d06b9+0x73>
  40d205:	cs nop WORD PTR [rax+rax*1+0x0]
  40d20f:	cs nop WORD PTR [rax+rax*1+0x0]
  40d219:	nop    DWORD PTR [rax+0x0]
  40d220:	cmp    BYTE PTR [rcx+r8*1],0x0
  40d225:	je     40d233 <__swc_fn_585f006d_000160_e25d06b9+0x73>
  40d227:	inc    rax
  40d22a:	lea    r8,[r9+rax*1]
  40d22e:	cmp    r8,rdx
  40d231:	jb     40d220 <__swc_fn_585f006d_000160_e25d06b9+0x60>
  40d233:	cmp    r8,rdx
  40d236:	jne    40d23f <__swc_fn_585f006d_000160_e25d06b9+0x7f>
  40d238:	xor    eax,eax
  40d23a:	add    rsp,0x10
  40d23e:	ret
  40d23f:	add    rcx,r9
  40d242:	mov    QWORD PTR [rsp],rcx
  40d246:	mov    QWORD PTR [rsp+0x8],rax
  40d24b:	vmovups xmm0,XMMWORD PTR [rsp]
  40d250:	vmovups XMMWORD PTR [r10],xmm0
  40d255:	mov    eax,0x1
  40d25a:	add    rsp,0x10
  40d25e:	ret
	...

000000000040d260 <__swc_fn_585f006d_000163_5fbed98a>:
  40d260:	push   rbp
  40d261:	push   rbx
  40d262:	push   rsi
  40d263:	push   rdi
  40d264:	push   r12
  40d266:	push   r13
  40d268:	push   r14
  40d26a:	push   r15
  40d26c:	sub    rsp,0x10
  40d270:	mov    rbp,rsp
  40d273:	vmovups XMMWORD PTR [rsp],xmm6
  40d278:	sub    rsp,0x50
  40d27c:	mov    rbx,rsp
  40d27f:	mov    rsi,r8
  40d282:	mov    QWORD PTR [rsp+0x30],r8
  40d287:	mov    rdi,rcx
  40d28a:	mov    QWORD PTR [rsp+0x38],rcx
  40d28f:	mov    r12,rdx
  40d292:	xor    r13b,r13b
  40d295:	mov    r14,QWORD PTR [rdi+0x8]
  40d299:	mov    QWORD PTR [rsp+0x40],r14
  40d29e:	xor    r15d,r15d
  40d2a1:	test   r14,r14
  40d2a4:	jbe    40d4fe <__swc_fn_585f006d_000163_5fbed98a+0x29e>
  40d2aa:	mov    r14,QWORD PTR [rdi]
  40d2ad:	mov    rax,QWORD PTR [rsp+0x40]
  40d2b2:	mov    QWORD PTR [rsp+0x48],r14
  40d2b7:	vmovups xmm6,XMMWORD PTR [rip+0x5179]        # 412438 <__swc_rdata_base_585f006d+0x328>
  40d2bf:	nop
  40d2c0:	cmp    QWORD PTR [r14+r15*8],0x0
  40d2c5:	jne    40d2cf <__swc_fn_585f006d_000163_5fbed98a+0x6f>
  40d2c7:	mov    r14,rax
  40d2ca:	jmp    40d4de <__swc_fn_585f006d_000163_5fbed98a+0x27e>
  40d2cf:	mov    rcx,QWORD PTR [rdi]
  40d2d2:	mov    rdx,QWORD PTR [rcx+r15*8]
  40d2d6:	mov    rdi,rbx
  40d2d9:	mov    rcx,rdi
  40d2dc:	sub    rsp,0x8
  40d2e0:	mov    r14,rax
  40d2e3:	call   409f10 <__swc_fn_585f006d_000162_edb9cf73>
  40d2e8:	add    rsp,0x8
  40d2ec:	mov    al,BYTE PTR [rbx]
  40d2ee:	test   al,al
  40d2f0:	je     40d4de <__swc_fn_585f006d_000163_5fbed98a+0x27e>
  40d2f6:	mov    al,BYTE PTR [rbx+0x1]
  40d2f9:	test   al,al
  40d2fb:	jne    40d306 <__swc_fn_585f006d_000163_5fbed98a+0xa6>
  40d2fd:	test   sil,sil
  40d300:	je     40d4de <__swc_fn_585f006d_000163_5fbed98a+0x27e>
  40d306:	test   r13b,r13b
  40d309:	jne    40d3c7 <__swc_fn_585f006d_000163_5fbed98a+0x167>
  40d30f:	test   r12,r12
  40d312:	je     40d3c7 <__swc_fn_585f006d_000163_5fbed98a+0x167>
  40d318:	mov    al,BYTE PTR [rbx+0x1]
  40d31b:	test   al,al
  40d31d:	je     40d4de <__swc_fn_585f006d_000163_5fbed98a+0x27e>
  40d323:	mov    eax,DWORD PTR [rbx+0x28]
  40d326:	cmp    DWORD PTR [r12+0x20],eax
  40d32b:	jne    40d4de <__swc_fn_585f006d_000163_5fbed98a+0x27e>
  40d331:	mov    rax,QWORD PTR [r12]
  40d335:	mov    rcx,QWORD PTR [r12+0x8]
  40d33a:	cmp    QWORD PTR [rbx+0x20],rcx
  40d33e:	jne    40d4de <__swc_fn_585f006d_000163_5fbed98a+0x27e>
  40d344:	mov    cl,0x1
  40d346:	test   rax,rax
  40d349:	je     40d3b2 <__swc_fn_585f006d_000163_5fbed98a+0x152>
  40d34f:	mov    rdx,QWORD PTR [rbx+0x20]
  40d353:	xor    r8d,r8d
  40d356:	test   rdx,rdx
  40d359:	jbe    40d3b2 <__swc_fn_585f006d_000163_5fbed98a+0x152>
  40d35b:	mov    r9,QWORD PTR [rbx+0x18]
  40d35f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40d364:	cs nop WORD PTR [rax+rax*1+0x0]
  40d36e:	xchg   ax,ax
  40d370:	mov    r10b,BYTE PTR [rax+r8*1]
  40d374:	cmp    BYTE PTR [r9+r8*1],r10b
  40d378:	je     40d3a9 <__swc_fn_585f006d_000163_5fbed98a+0x149>
  40d37a:	vmovq  r10,xmm0
  40d37f:	cmp    BYTE PTR [r10+r8*1],0x5c
  40d384:	jne    40d38d <__swc_fn_585f006d_000163_5fbed98a+0x12d>
  40d386:	cmp    BYTE PTR [rax+r8*1],0x2f
  40d38b:	je     40d3a9 <__swc_fn_585f006d_000163_5fbed98a+0x149>
  40d38d:	vmovq  r10,xmm0
  40d392:	cmp    BYTE PTR [r10+r8*1],0x2f
  40d397:	jne    40d3a0 <__swc_fn_585f006d_000163_5fbed98a+0x140>
  40d399:	cmp    BYTE PTR [rax+r8*1],0x5c
  40d39e:	je     40d3a9 <__swc_fn_585f006d_000163_5fbed98a+0x149>
  40d3a0:	xor    eax,eax
  40d3a2:	movzx  eax,al
  40d3a5:	mov    cl,al
  40d3a7:	jmp    40d3b2 <__swc_fn_585f006d_000163_5fbed98a+0x152>
  40d3a9:	add    r8,0x1
  40d3ad:	cmp    r8,rdx
  40d3b0:	jb     40d370 <__swc_fn_585f006d_000163_5fbed98a+0x110>
  40d3b2:	test   cl,cl
  40d3b4:	je     40d4de <__swc_fn_585f006d_000163_5fbed98a+0x27e>
  40d3ba:	mov    eax,0x1
  40d3bf:	mov    r13b,al
  40d3c2:	jmp    40d4de <__swc_fn_585f006d_000163_5fbed98a+0x27e>
  40d3c7:	mov    r13b,0x1
  40d3ca:	sub    rsp,0x20
  40d3ce:	mov    rax,rsp
  40d3d1:	lea    rcx,[rdi+0x8]
  40d3d5:	mov    QWORD PTR [rax],rcx
  40d3d8:	lea    rsi,[rip+0x4f31]        # 412310 <__swc_rdata_base_585f006d+0x200>
  40d3df:	mov    QWORD PTR [rax+0x8],rsi
  40d3e3:	mov    QWORD PTR [rax+0x10],rsp
  40d3e7:	mov    QWORD PTR [rax+0x18],0x1
  40d3ef:	lea    rcx,[rsp+0x10]
  40d3f4:	sub    rsp,0x8
  40d3f8:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  40d3fd:	add    rsp,0x8
  40d401:	add    rsp,0x20
  40d405:	mov    al,BYTE PTR [rbx+0x1]
  40d408:	test   al,al
  40d40a:	je     40d4a7 <__swc_fn_585f006d_000163_5fbed98a+0x247>
  40d410:	lea    rax,[rip+0x54a1]        # 4128b8 <__swc_rdata_base_585f006d+0x7a8>
  40d417:	sub    rsp,0x20
  40d41b:	mov    rcx,rsp
  40d41e:	mov    QWORD PTR [rcx],rax
  40d421:	mov    QWORD PTR [rcx+0x8],rsi
  40d425:	mov    QWORD PTR [rcx+0x10],rsp
  40d429:	mov    QWORD PTR [rcx+0x18],0x1
  40d431:	lea    rcx,[rsp+0x10]
  40d436:	sub    rsp,0x8
  40d43a:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  40d43f:	add    rsp,0x8
  40d443:	add    rsp,0x20
  40d447:	mov    eax,DWORD PTR [rbx+0x28]
  40d44a:	sub    rsp,0x60
  40d44e:	mov    rcx,rsp
  40d451:	lea    rdx,[rdi+0x18]
  40d455:	mov    QWORD PTR [rcx+0x18],rdx
  40d459:	mov    QWORD PTR [rcx+0x20],rsi
  40d45d:	vmovups XMMWORD PTR [rcx],xmm6
  40d461:	mov    QWORD PTR [rcx+0x28],rsp
  40d465:	mov    QWORD PTR [rcx+0x30],rsi
  40d469:	mov    DWORD PTR [rcx+0x10],eax
  40d46c:	lea    rax,[rsp+0x10]
  40d471:	mov    QWORD PTR [rcx+0x38],rax
  40d475:	lea    rax,[rip+0x4f54]        # 4123d0 <__swc_rdata_base_585f006d+0x2c0>
  40d47c:	mov    QWORD PTR [rcx+0x40],rax
  40d480:	lea    rax,[rsp+0x18]
  40d485:	mov    QWORD PTR [rcx+0x48],rax
  40d489:	mov    QWORD PTR [rcx+0x50],0x3
  40d491:	lea    rcx,[rsp+0x48]
  40d496:	sub    rsp,0x8
  40d49a:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  40d49f:	add    rsp,0x8
  40d4a3:	add    rsp,0x60
  40d4a7:	lea    rax,[rip+0x4eba]        # 412368 <__swc_rdata_base_585f006d+0x258>
  40d4ae:	sub    rsp,0x20
  40d4b2:	mov    rcx,rsp
  40d4b5:	mov    QWORD PTR [rcx],rax
  40d4b8:	mov    QWORD PTR [rcx+0x8],rsi
  40d4bc:	mov    QWORD PTR [rcx+0x10],rsp
  40d4c0:	mov    QWORD PTR [rcx+0x18],0x1
  40d4c8:	lea    rcx,[rsp+0x10]
  40d4cd:	sub    rsp,0x8
  40d4d1:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  40d4d6:	add    rsp,0x8
  40d4da:	add    rsp,0x20
  40d4de:	add    r15,0x1
  40d4e2:	cmp    r15,r14
  40d4e5:	jae    40d4fe <__swc_fn_585f006d_000163_5fbed98a+0x29e>
  40d4e7:	mov    rsi,QWORD PTR [rsp+0x30]
  40d4ec:	mov    rdi,QWORD PTR [rsp+0x38]
  40d4f1:	mov    rax,r14
  40d4f4:	mov    r14,QWORD PTR [rsp+0x48]
  40d4f9:	jmp    40d2c0 <__swc_fn_585f006d_000163_5fbed98a+0x60>
  40d4fe:	add    rsp,0x50
  40d502:	vmovups xmm6,XMMWORD PTR [rsp]
  40d507:	add    rsp,0x10
  40d50b:	pop    r15
  40d50d:	pop    r14
  40d50f:	pop    r13
  40d511:	pop    r12
  40d513:	pop    rdi
  40d514:	pop    rsi
  40d515:	pop    rbx
  40d516:	pop    rbp
  40d517:	ret
	...

000000000040d520 <__swc_fn_585f006d_000166_31ca4f53>:
  40d520:	sub    rsp,0x8
  40d524:	call   40ff70 <__swc_fn_585f006d_000125_e19c72b3>
  40d529:	add    rsp,0x8
  40d52d:	ret
	...

000000000040d530 <__swc_fn_585f006d_000169_aabbfb4c>:
  40d530:	push   rsi
  40d531:	sub    rsp,0x30
  40d535:	lea    rsi,[rip+0x18864]        # 425da0 <__swc_bss_base_585f006d+0x2d60>
  40d53c:	mov    rax,QWORD PTR [rsi]
  40d53f:	test   rax,rax
  40d542:	je     40d54a <__swc_fn_585f006d_000169_aabbfb4c+0x1a>
  40d544:	add    rsp,0x30
  40d548:	pop    rsi
  40d549:	ret
  40d54a:	mov    ecx,0x2
  40d54f:	mov    edx,0x8020
  40d554:	call   40f610 <__swc_fn_585f006d_000107_ff529476>
  40d559:	test   rax,rax
  40d55c:	jne    40d56d <__swc_fn_585f006d_000169_aabbfb4c+0x3d>
  40d55e:	mov    QWORD PTR [rsp+0x18],rax
  40d563:	call   40c9d0 <__swc_fn_585f006d_000118_2b35b5e0>
  40d568:	mov    rax,QWORD PTR [rsp+0x18]
  40d56d:	mov    rcx,rax
  40d570:	xchg   QWORD PTR [rsi],rcx
  40d573:	add    rsp,0x30
  40d577:	pop    rsi
  40d578:	ret
  40d579:	add    BYTE PTR [rax],al
  40d57b:	add    BYTE PTR [rax],al
  40d57d:	add    BYTE PTR [rax],al
	...

000000000040d580 <__swc_fn_585f006d_000172_9a88b1d5>:
  40d580:	push   rsi
  40d581:	test   r8,r8
  40d584:	jne    40d588 <__swc_fn_585f006d_000172_9a88b1d5+0x8>
  40d586:	pop    rsi
  40d587:	ret
  40d588:	lea    rax,[rcx+0x18]
  40d58c:	mov    r10,QWORD PTR [rax]
  40d58f:	lea    r11,[r10+0x1]
  40d593:	mov    QWORD PTR [rax],r11
  40d596:	mov    r11,rdx
  40d599:	not    rdx
  40d59c:	lea    rsi,[r8-0x1]
  40d5a0:	cmp    rsi,rdx
  40d5a3:	ja     40d5c3 <__swc_fn_585f006d_000172_9a88b1d5+0x43>
  40d5a5:	lea    rdx,[r11+r8*1]
  40d5a9:	dec    rdx
  40d5ac:	shr    rdx,0x6
  40d5b0:	mov    r8,r11
  40d5b3:	shr    r8,0x6
  40d5b7:	mov    rsi,rdx
  40d5ba:	sub    rsi,r8
  40d5bd:	cmp    rsi,0x8
  40d5c1:	jb     40d5d9 <__swc_fn_585f006d_000172_9a88b1d5+0x59>
  40d5c3:	lea    rcx,[rcx+0x10]
  40d5c7:	mov    rdx,QWORD PTR [rcx]
  40d5ca:	add    rdx,r9
  40d5cd:	mov    QWORD PTR [rcx],rdx
  40d5d0:	lea    rcx,[r10+0x2]
  40d5d4:	mov    QWORD PTR [rax],rcx
  40d5d7:	pop    rsi
  40d5d8:	ret
  40d5d9:	shr    r11,0x6
  40d5dd:	nop    DWORD PTR [rax]
  40d5e0:	cmp    r11,rdx
  40d5e3:	ja     40d623 <__swc_fn_585f006d_000172_9a88b1d5+0xa3>
  40d5e5:	jmp    40d5f6 <__swc_fn_585f006d_000172_9a88b1d5+0x76>
  40d5e7:	nop    WORD PTR [rax+rax*1+0x0]
  40d5f0:	add    r11,0x1
  40d5f4:	jmp    40d5e0 <__swc_fn_585f006d_000172_9a88b1d5+0x60>
  40d5f6:	mov    r8,r11
  40d5f9:	shr    r8,0xc
  40d5fd:	mov    rsi,r11
  40d600:	xor    rsi,r8
  40d603:	mov    r8,r11
  40d606:	shr    r8,0x18
  40d60a:	xor    rsi,r8
  40d60d:	and    esi,0xfff
  40d613:	lea    r8,[rcx+rsi*8+0x20]
  40d618:	mov    rsi,QWORD PTR [r8]
  40d61b:	add    rsi,r9
  40d61e:	mov    QWORD PTR [r8],rsi
  40d621:	jmp    40d5f0 <__swc_fn_585f006d_000172_9a88b1d5+0x70>
  40d623:	lea    rcx,[r10+0x2]
  40d627:	mov    QWORD PTR [rax],rcx
  40d62a:	pop    rsi
  40d62b:	ret
  40d62c:	add    BYTE PTR [rax],al
	...

000000000040d630 <__swc_fn_585f006d_000175_2744b483>:
  40d630:	push   rbx
  40d631:	sub    rsp,0x70
  40d635:	cmp    rcx,0xffffffffffffffef
  40d639:	jbe    40d643 <__swc_fn_585f006d_000175_2744b483+0x13>
  40d63b:	xor    eax,eax
  40d63d:	add    rsp,0x70
  40d641:	pop    rbx
  40d642:	ret
  40d643:	vxorps xmm0,xmm0,xmm0
  40d647:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40d64d:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40d653:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  40d659:	vzeroupper
  40d65c:	lea    rax,[rcx+0x10]
  40d660:	mov    QWORD PTR [rsp+0x50],rax
  40d665:	mov    DWORD PTR [rsp+0x60],0x10
  40d66d:	mov    rcx,QWORD PTR [rip+0x186cc]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40d674:	test   rcx,rcx
  40d677:	jne    40d689 <__swc_fn_585f006d_000175_2744b483+0x59>
  40d679:	call   40a1a0 <__swc_fn_585f006d_000165_e09accff>
  40d67e:	lea    rcx,[rax+0x1]
  40d682:	mov    QWORD PTR [rip+0x186b7],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40d689:	dec    rcx
  40d68c:	call   411aa0 <__swc_fn_585f006d_000167_3130645d>
  40d691:	mov    rcx,QWORD PTR [rax]
  40d694:	lea    rdx,[rsp+0x8]
  40d699:	mov    rbx,QWORD PTR [rax+0x8]
  40d69d:	mov    rbx,QWORD PTR [rbx+0x8]
  40d6a1:	call   rbx
  40d6a3:	mov    rax,QWORD PTR [rsp+0x48]
  40d6a8:	test   rax,rax
  40d6ab:	jne    40d6b5 <__swc_fn_585f006d_000175_2744b483+0x85>
  40d6ad:	xor    eax,eax
  40d6af:	add    rsp,0x70
  40d6b3:	pop    rbx
  40d6b4:	ret
  40d6b5:	mov    rcx,QWORD PTR [rsp+0x50]
  40d6ba:	mov    QWORD PTR [rax],rcx
  40d6bd:	mov    QWORD PTR [rax+0x8],0x0
  40d6c5:	lea    rax,[rax+0x10]
  40d6c9:	add    rsp,0x70
  40d6cd:	pop    rbx
  40d6ce:	ret
	...

000000000040d6e0 <__swc_fn_585f006d_000178_8d3f617b>:
  40d6e0:	push   rbp
  40d6e1:	push   rsi
  40d6e2:	push   rdi
  40d6e3:	push   r12
  40d6e5:	push   r13
  40d6e7:	push   r14
  40d6e9:	sub    rsp,0x10
  40d6ed:	mov    rbp,rsp
  40d6f0:	vmovups XMMWORD PTR [rsp],xmm6
  40d6f5:	sub    rsp,0xc0
  40d6fc:	mov    ecx,0x48
  40d701:	sub    rsp,0x8
  40d705:	call   40d630 <__swc_fn_585f006d_000175_2744b483>
  40d70a:	add    rsp,0x8
  40d70e:	mov    rsi,rax
  40d711:	mov    ecx,0x48
  40d716:	sub    rsp,0x8
  40d71a:	call   40d630 <__swc_fn_585f006d_000175_2744b483>
  40d71f:	add    rsp,0x8
  40d723:	mov    rdi,rax
  40d726:	mov    ecx,0x48
  40d72b:	sub    rsp,0x8
  40d72f:	call   40d630 <__swc_fn_585f006d_000175_2744b483>
  40d734:	add    rsp,0x8
  40d738:	mov    r12,rax
  40d73b:	sub    rsp,0x8
  40d73f:	call   40a350 <__swc_fn_585f006d_000177_1ca87929>
  40d744:	add    rsp,0x8
  40d748:	vmovups xmm6,xmm0
  40d74c:	mov    QWORD PTR [rdi],0x0
  40d753:	mov    QWORD PTR [rdi+0x8],0x1
  40d75b:	mov    QWORD PTR [rdi+0x10],0x2
  40d763:	mov    QWORD PTR [rdi+0x18],0x3
  40d76b:	mov    QWORD PTR [rdi+0x20],0x4
  40d773:	mov    QWORD PTR [rdi+0x28],0x5
  40d77b:	mov    QWORD PTR [rdi+0x30],0x6
  40d783:	mov    QWORD PTR [rdi+0x38],0x7
  40d78b:	mov    QWORD PTR [rdi+0x40],0x8
  40d793:	xor    eax,eax
  40d795:	xor    ecx,ecx
  40d797:	xor    edx,edx
  40d799:	mov    r8d,0x9
  40d79f:	nop
  40d7a0:	cmp    r8,0x1
  40d7a4:	je     40d7be <__swc_fn_585f006d_000178_8d3f617b+0xde>
  40d7a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40d7b0:	mov    QWORD PTR [r12+r8*8-0x8],r8
  40d7b5:	dec    r8
  40d7b8:	cmp    r8,0x1
  40d7bc:	jne    40d7b0 <__swc_fn_585f006d_000178_8d3f617b+0xd0>
  40d7be:	mov    r9,QWORD PTR [rdi]
  40d7c1:	mov    QWORD PTR [rsi],r9
  40d7c4:	mov    r10,QWORD PTR [rdi+0x8]
  40d7c8:	mov    QWORD PTR [rsi+0x8],r10
  40d7cc:	mov    r10,QWORD PTR [rdi+0x10]
  40d7d0:	mov    QWORD PTR [rsi+0x10],r10
  40d7d4:	mov    r10,QWORD PTR [rdi+0x18]
  40d7d8:	mov    QWORD PTR [rsi+0x18],r10
  40d7dc:	mov    r10,QWORD PTR [rdi+0x20]
  40d7e0:	mov    QWORD PTR [rsi+0x20],r10
  40d7e4:	mov    r10,QWORD PTR [rdi+0x28]
  40d7e8:	mov    QWORD PTR [rsi+0x28],r10
  40d7ec:	mov    r10,QWORD PTR [rdi+0x30]
  40d7f0:	mov    QWORD PTR [rsi+0x30],r10
  40d7f4:	mov    r10,QWORD PTR [rdi+0x38]
  40d7f8:	mov    QWORD PTR [rsi+0x38],r10
  40d7fc:	mov    r10,QWORD PTR [rdi+0x40]
  40d800:	mov    QWORD PTR [rsi+0x40],r10
  40d804:	xor    r10d,r10d
  40d807:	test   r9,r9
  40d80a:	je     40d8ba <__swc_fn_585f006d_000178_8d3f617b+0x1da>
  40d810:	jle    40d8ab <__swc_fn_585f006d_000178_8d3f617b+0x1cb>
  40d816:	mov    r14,QWORD PTR [rsi+r9*8]
  40d81a:	mov    QWORD PTR [rsi],r14
  40d81d:	mov    QWORD PTR [rsi+r9*8],r9
  40d821:	dec    r9
  40d824:	cmp    r9,0x1
  40d828:	jle    40d8ab <__swc_fn_585f006d_000178_8d3f617b+0x1cb>
  40d82e:	mov    r13,QWORD PTR [rsi+0x8]
  40d832:	mov    r14,QWORD PTR [rsi+r9*8]
  40d836:	mov    QWORD PTR [rsi+0x8],r14
  40d83a:	mov    QWORD PTR [rsi+r9*8],r13
  40d83e:	dec    r9
  40d841:	cmp    r9,0x2
  40d845:	jle    40d8ab <__swc_fn_585f006d_000178_8d3f617b+0x1cb>
  40d847:	mov    r13,QWORD PTR [rsi+0x10]
  40d84b:	mov    r14,QWORD PTR [rsi+r9*8]
  40d84f:	mov    QWORD PTR [rsi+0x10],r14
  40d853:	mov    QWORD PTR [rsi+r9*8],r13
  40d857:	dec    r9
  40d85a:	cmp    r9,0x3
  40d85e:	jle    40d8ab <__swc_fn_585f006d_000178_8d3f617b+0x1cb>
  40d860:	mov    r13,QWORD PTR [rsi+0x18]
  40d864:	mov    r14,QWORD PTR [rsi+r9*8]
  40d868:	mov    QWORD PTR [rsi+0x18],r14
  40d86c:	mov    QWORD PTR [rsi+r9*8],r13
  40d870:	dec    r9
  40d873:	cmp    r9,0x4
  40d877:	jle    40d8ab <__swc_fn_585f006d_000178_8d3f617b+0x1cb>
  40d879:	mov    r11d,0x4
  40d87f:	jmp    40d890 <__swc_fn_585f006d_000178_8d3f617b+0x1b0>
  40d881:	cmp    r11,r9
  40d884:	jge    40d8ab <__swc_fn_585f006d_000178_8d3f617b+0x1cb>
  40d886:	cs nop WORD PTR [rax+rax*1+0x0]
  40d890:	mov    r13,QWORD PTR [rsi+r11*8]
  40d894:	mov    r14,QWORD PTR [rsi+r9*8]
  40d898:	mov    QWORD PTR [rsi+r11*8],r14
  40d89c:	mov    QWORD PTR [rsi+r9*8],r13
  40d8a0:	inc    r11
  40d8a3:	dec    r9
  40d8a6:	cmp    r11,r9
  40d8a9:	jl     40d890 <__swc_fn_585f006d_000178_8d3f617b+0x1b0>
  40d8ab:	inc    r10
  40d8ae:	mov    r9,QWORD PTR [rsi]
  40d8b1:	test   r9,r9
  40d8b4:	jne    40d810 <__swc_fn_585f006d_000178_8d3f617b+0x130>
  40d8ba:	cmp    r10,rcx
  40d8bd:	cmovg  rcx,r10
  40d8c1:	test   dl,0x1
  40d8c4:	jne    40d8cb <__swc_fn_585f006d_000178_8d3f617b+0x1eb>
  40d8c6:	add    rax,r10
  40d8c9:	jmp    40d8ce <__swc_fn_585f006d_000178_8d3f617b+0x1ee>
  40d8cb:	sub    rax,r10
  40d8ce:	xchg   ax,ax
  40d8d0:	cmp    r8,0x9
  40d8d4:	je     40d92b <__swc_fn_585f006d_000178_8d3f617b+0x24b>
  40d8d6:	mov    r10,QWORD PTR [rdi]
  40d8d9:	xor    r11d,r11d
  40d8dc:	test   r8,r8
  40d8df:	jle    40d912 <__swc_fn_585f006d_000178_8d3f617b+0x232>
  40d8e1:	cs nop WORD PTR [rax+rax*1+0x0]
  40d8eb:	cs nop WORD PTR [rax+rax*1+0x0]
  40d8f5:	cs nop WORD PTR [rax+rax*1+0x0]
  40d8ff:	nop
  40d900:	mov    r13,QWORD PTR [rdi+r11*8+0x8]
  40d905:	mov    QWORD PTR [rdi+r11*8],r13
  40d909:	add    r11,0x1
  40d90d:	cmp    r11,r8
  40d910:	jl     40d900 <__swc_fn_585f006d_000178_8d3f617b+0x220>
  40d912:	mov    QWORD PTR [rdi+r8*8],r10
  40d916:	dec    QWORD PTR [r12+r8*8]
  40d91a:	je     40d91e <__swc_fn_585f006d_000178_8d3f617b+0x23e>
  40d91c:	jns    40d923 <__swc_fn_585f006d_000178_8d3f617b+0x243>
  40d91e:	inc    r8
  40d921:	jmp    40d8d0 <__swc_fn_585f006d_000178_8d3f617b+0x1f0>
  40d923:	inc    rdx
  40d926:	jmp    40d7a0 <__swc_fn_585f006d_000178_8d3f617b+0xc0>
  40d92b:	imul   r13,rax,0x3e8
  40d932:	add    r13,rcx
  40d935:	sub    rsp,0x8
  40d939:	call   40a350 <__swc_fn_585f006d_000177_1ca87929>
  40d93e:	add    rsp,0x8
  40d942:	vsubsd xmm0,xmm0,xmm6
  40d946:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x507a]        # 4129c8 <__swc_rdata_base_585f006d+0x8b8>
  40d94e:	lea    rax,[rip+0x4a13]        # 412368 <__swc_rdata_base_585f006d+0x258>
  40d955:	sub    rsp,0x90
  40d95c:	mov    rcx,rsp
  40d95f:	vmovups xmm1,XMMWORD PTR [rip+0x5041]        # 4129a8 <__swc_rdata_base_585f006d+0x898>
  40d967:	vmovups XMMWORD PTR [rcx],xmm1
  40d96b:	mov    QWORD PTR [rcx+0x30],rsp
  40d96f:	lea    rdx,[rip+0x499a]        # 412310 <__swc_rdata_base_585f006d+0x200>
  40d976:	mov    QWORD PTR [rcx+0x38],rdx
  40d97a:	mov    QWORD PTR [rcx+0x10],r13
  40d97e:	lea    r8,[rsp+0x10]
  40d983:	mov    QWORD PTR [rcx+0x40],r8
  40d987:	lea    r8,[rip+0x4f8a]        # 412918 <__swc_rdata_base_585f006d+0x808>
  40d98e:	mov    QWORD PTR [rcx+0x48],r8
  40d992:	vmovups xmm1,XMMWORD PTR [rip+0x501e]        # 4129b8 <__swc_rdata_base_585f006d+0x8a8>
  40d99a:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40d99f:	lea    r8,[rsp+0x18]
  40d9a4:	mov    QWORD PTR [rcx+0x50],r8
  40d9a8:	mov    QWORD PTR [rcx+0x58],rdx
  40d9ac:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40d9b1:	lea    r8,[rcx+0x28]
  40d9b5:	mov    QWORD PTR [rcx+0x60],r8
  40d9b9:	lea    r8,[rip+0x4fa0]        # 412960 <__swc_rdata_base_585f006d+0x850>
  40d9c0:	mov    QWORD PTR [rcx+0x68],r8
  40d9c4:	mov    QWORD PTR [rcx+0x70],rax
  40d9c8:	mov    QWORD PTR [rcx+0x78],rdx
  40d9cc:	lea    rax,[rcx+0x30]
  40d9d0:	mov    QWORD PTR [rcx+0x80],rax
  40d9d7:	mov    QWORD PTR [rcx+0x88],0x5
  40d9e2:	lea    rcx,[rcx+0x80]
  40d9e9:	sub    rsp,0x8
  40d9ed:	call   410560 <__swc_fn_585f006d_000146_e9d46966>
  40d9f2:	add    rsp,0x8
  40d9f6:	add    rsp,0x90
  40d9fd:	mov    rcx,r12
  40da00:	sub    rsp,0x8
  40da04:	call   411c40 <__swc_fn_585f006d_000176_5d3d19bd>
  40da09:	add    rsp,0x8
  40da0d:	mov    rcx,rdi
  40da10:	sub    rsp,0x8
  40da14:	call   411c40 <__swc_fn_585f006d_000176_5d3d19bd>
  40da19:	add    rsp,0x8
  40da1d:	mov    rcx,rsi
  40da20:	sub    rsp,0x8
  40da24:	call   411c40 <__swc_fn_585f006d_000176_5d3d19bd>
  40da29:	add    rsp,0xc8
  40da30:	vmovups xmm6,XMMWORD PTR [rsp]
  40da35:	add    rsp,0x10
  40da39:	pop    r14
  40da3b:	pop    r13
  40da3d:	pop    r12
  40da3f:	pop    rdi
  40da40:	pop    rsi
  40da41:	pop    rbp
  40da42:	ret
	...

000000000040da60 <__swc_fn_585f006d_000002_390d5093>:
  40da60:	sub    rsp,0x8
  40da64:	call   40c620 <__swc_fn_585f006d_000109_aa570b2b>
  40da69:	mov    rcx,rax
  40da6c:	test   rax,rax
  40da6f:	je     40da96 <__swc_fn_585f006d_000002_390d5093+0x36>
  40da71:	lea    rdx,[rip+0x155c8]        # 423040 <__swc_bss_base_585f006d>
  40da78:	mov    r8,QWORD PTR [rip+0x155c1]        # 423040 <__swc_bss_base_585f006d>
  40da7f:	nop
  40da80:	lea    r9,[r8+0x1]
  40da84:	mov    rax,r8
  40da87:	lock cmpxchg QWORD PTR [rdx],r9
  40da8c:	cmp    rax,r8
  40da8f:	je     40da96 <__swc_fn_585f006d_000002_390d5093+0x36>
  40da91:	mov    r8,rax
  40da94:	jmp    40da80 <__swc_fn_585f006d_000002_390d5093+0x20>
  40da96:	mov    rax,rcx
  40da99:	add    rsp,0x8
  40da9d:	ret
	...

000000000040daa0 <__swc_fn_585f006d_000005_bcc5b80b>:
  40daa0:	mov    r8d,edx
  40daa3:	xor    eax,eax
  40daa5:	tzcnt  eax,edx
  40daa9:	shrx   r9d,edx,eax
  40daae:	mov    DWORD PTR [rcx+0x2c],edx
  40dab1:	xor    eax,eax
  40dab3:	tzcnt  eax,edx
  40dab7:	mov    BYTE PTR [rcx+0x38],al
  40daba:	mov    eax,0xffffffff
  40dabf:	xor    edx,edx
  40dac1:	div    r8d
  40dac4:	mov    DWORD PTR [rcx+0x34],eax
  40dac7:	mov    eax,r9d
  40daca:	mov    edx,r9d
  40dacd:	imul   edx,r9d
  40dad1:	mov    r8d,0x2
  40dad7:	sub    r8d,edx
  40dada:	imul   eax,r8d
  40dade:	mov    edx,r9d
  40dae1:	imul   edx,eax
  40dae4:	mov    r8d,0x2
  40daea:	sub    r8d,edx
  40daed:	imul   eax,r8d
  40daf1:	mov    edx,r9d
  40daf4:	imul   edx,eax
  40daf7:	mov    r8d,0x2
  40dafd:	sub    r8d,edx
  40db00:	imul   eax,r8d
  40db04:	mov    edx,r9d
  40db07:	imul   edx,eax
  40db0a:	mov    r8d,0x2
  40db10:	sub    r8d,edx
  40db13:	imul   eax,r8d
  40db17:	imul   r9d,eax
  40db1b:	mov    edx,0x2
  40db20:	sub    edx,r9d
  40db23:	imul   eax,edx
  40db26:	mov    DWORD PTR [rcx+0x30],eax
  40db29:	ret
  40db2a:	add    BYTE PTR [rax],al
  40db2c:	add    BYTE PTR [rax],al
	...

000000000040db30 <__swc_fn_585f006d_000008_578f1784>:
  40db30:	xor    eax,eax
  40db32:	mov    DWORD PTR [rcx+0x68],eax
  40db35:	ret
	...

000000000040db40 <__swc_fn_585f006d_000011_e75d466d>:
  40db40:	mov    eax,DWORD PTR [rcx+0x28]
  40db43:	shlx   eax,edx,eax
  40db48:	shl    rax,0x10
  40db4c:	lea    rdx,[rcx+rax*1]
  40db50:	lea    rax,[rcx+0x3000]
  40db57:	cmp    rdx,rax
  40db5a:	cmovae rax,rdx
  40db5e:	ret
	...

000000000040db60 <__swc_fn_585f006d_000014_1acdaf22>:
  40db60:	push   rsi
  40db61:	push   rdi
  40db62:	push   r12
  40db64:	push   r13
  40db66:	push   r14
  40db68:	mov    rsi,rdx
  40db6b:	mov    rdi,rcx
  40db6e:	rex mov dl,BYTE PTR [rsi+0x3a]
  40db72:	mov    ecx,DWORD PTR [rdi+0x28]
  40db75:	shr    dl,cl
  40db77:	mov    r12d,0x1
  40db7d:	mov    ecx,edx
  40db7f:	shl    r12,cl
  40db82:	mov    r13d,DWORD PTR [rsi+0x3c]
  40db86:	rex mov BYTE PTR [rsi+0x3b],0x0
  40db8b:	mov    QWORD PTR [rsi+0x40],0x0
  40db93:	mov    QWORD PTR [rsi],0x0
  40db9a:	mov    rax,QWORD PTR [rsi+0x10]
  40db9e:	mov    QWORD PTR [rsi+0x20],rax
  40dba2:	lea    r14,[rip+0x1549f]        # 423048 <__swc_bss_base_585f006d+0x8>
  40dba9:	mov    rax,QWORD PTR [r14]
  40dbac:	shr    rax,0x2
  40dbb0:	mov    rcx,rax
  40dbb3:	cmp    rax,0x800000
  40dbba:	mov    eax,0x800000
  40dbbf:	cmovb  rcx,rax
  40dbc3:	lea    r8,[rip+0x1548e]        # 423058 <__swc_bss_base_585f006d+0x18>
  40dbca:	mov    rax,QWORD PTR [r8]
  40dbcd:	mov    r9,rax
  40dbd0:	lea    r10,[r9+r13*1]
  40dbd4:	cmp    r10,rcx
  40dbd7:	ja     40dbfb <__swc_fn_585f006d_000014_1acdaf22+0x9b>
  40dbd9:	mov    rax,r9
  40dbdc:	lock cmpxchg QWORD PTR [r8],r10
  40dbe1:	cmp    rax,r9
  40dbe4:	je     40dbeb <__swc_fn_585f006d_000014_1acdaf22+0x8b>
  40dbe6:	mov    r9,rax
  40dbe9:	jmp    40dbd0 <__swc_fn_585f006d_000014_1acdaf22+0x70>
  40dbeb:	mov    rcx,rdi
  40dbee:	mov    rdx,r12
  40dbf1:	call   40a750 <__swc_fn_585f006d_000016_89da4d6e>
  40dbf6:	jmp    40dc7d <__swc_fn_585f006d_000014_1acdaf22+0x11d>
  40dbfb:	mov    rcx,rdi
  40dbfe:	movzx  edx,dl
  40dc01:	call   40db40 <__swc_fn_585f006d_000011_e75d466d>
  40dc06:	test   r13,r13
  40dc09:	je     40dc76 <__swc_fn_585f006d_000014_1acdaf22+0x116>
  40dc0f:	mov    rcx,rax
  40dc12:	mov    rdx,r13
  40dc15:	call   40c7a0 <__swc_fn_585f006d_000112_cb2656be>
  40dc1a:	mov    rcx,QWORD PTR [rip+0x15427]        # 423048 <__swc_bss_base_585f006d+0x8>
  40dc21:	cs nop WORD PTR [rax+rax*1+0x0]
  40dc2b:	nop    DWORD PTR [rax+rax*1+0x0]
  40dc30:	mov    rdx,rcx
  40dc33:	sub    rdx,r13
  40dc36:	mov    rax,rcx
  40dc39:	lock cmpxchg QWORD PTR [r14],rdx
  40dc3e:	cmp    rax,rcx
  40dc41:	je     40dc48 <__swc_fn_585f006d_000014_1acdaf22+0xe8>
  40dc43:	mov    rcx,rax
  40dc46:	jmp    40dc30 <__swc_fn_585f006d_000014_1acdaf22+0xd0>
  40dc48:	lea    rcx,[rip+0x15411]        # 423060 <__swc_bss_base_585f006d+0x20>
  40dc4f:	mov    rdx,QWORD PTR [rip+0x1540a]        # 423060 <__swc_bss_base_585f006d+0x20>
  40dc56:	cs nop WORD PTR [rax+rax*1+0x0]
  40dc60:	lea    r8,[rdx+0x1]
  40dc64:	mov    rax,rdx
  40dc67:	lock cmpxchg QWORD PTR [rcx],r8
  40dc6c:	cmp    rax,rdx
  40dc6f:	je     40dc76 <__swc_fn_585f006d_000014_1acdaf22+0x116>
  40dc71:	mov    rdx,rax
  40dc74:	jmp    40dc60 <__swc_fn_585f006d_000014_1acdaf22+0x100>
  40dc76:	mov    DWORD PTR [rsi+0x3c],0x0
  40dc7d:	mov    rcx,rdi
  40dc80:	mov    rdx,r12
  40dc83:	call   407600 <__swc_fn_585f006d_000018_e2e8e4b0>
  40dc88:	pop    r14
  40dc8a:	pop    r13
  40dc8c:	pop    r12
  40dc8e:	pop    rdi
  40dc8f:	pop    rsi
  40dc90:	ret
	...

000000000040dca0 <__swc_fn_585f006d_000017_e238d24c>:
  40dca0:	mov    r8,QWORD PTR [rcx+0x48]
  40dca4:	test   r8,rdx
  40dca7:	je     40dcd8 <__swc_fn_585f006d_000017_e238d24c+0x38>
  40dca9:	nop    DWORD PTR [rax+0x0]
  40dcb0:	mov    rax,rdx
  40dcb3:	not    rax
  40dcb6:	mov    r9,r8
  40dcb9:	and    r9,rax
  40dcbc:	mov    rax,r8
  40dcbf:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40dcc5:	cmp    rax,r8
  40dcc8:	jne    40dcd0 <__swc_fn_585f006d_000017_e238d24c+0x30>
  40dcca:	mov    eax,0x1
  40dccf:	ret
  40dcd0:	mov    r8,rax
  40dcd3:	test   rax,rdx
  40dcd6:	jne    40dcb0 <__swc_fn_585f006d_000017_e238d24c+0x10>
  40dcd8:	xor    eax,eax
  40dcda:	ret
  40dcdb:	add    BYTE PTR [rax],al
  40dcdd:	add    BYTE PTR [rax],al
	...

000000000040dce0 <__swc_fn_585f006d_000020_4135c89a>:
  40dce0:	push   rsi
  40dce1:	push   rdi
  40dce2:	push   r12
  40dce4:	push   r13
  40dce6:	sub    rsp,0x8
  40dcea:	mov    rsi,rdx
  40dced:	mov    rdi,rcx
  40dcf0:	lea    r12,[rip+0x154f9]        # 4231f0 <__swc_bss_base_585f006d+0x1b0>
  40dcf7:	mov    rcx,r12
  40dcfa:	call   4098a0 <__swc_fn_585f006d_000135_1fec60ac>
  40dcff:	xor    eax,eax
  40dd01:	mov    rcx,QWORD PTR [rip+0x154f0]        # 4231f8 <__swc_bss_base_585f006d+0x1b8>
  40dd08:	mov    r13,rcx
  40dd0b:	test   r13,r13
  40dd0e:	je     40dd5b <__swc_fn_585f006d_000020_4135c89a+0x7b>
  40dd10:	mov    rcx,QWORD PTR [r13+0x10]
  40dd14:	cmp    DWORD PTR [r13+0x28],esi
  40dd18:	jne    40dd50 <__swc_fn_585f006d_000020_4135c89a+0x70>
  40dd1a:	test   rax,rax
  40dd1d:	jne    40dd28 <__swc_fn_585f006d_000020_4135c89a+0x48>
  40dd1f:	mov    QWORD PTR [rip+0x154d2],rcx        # 4231f8 <__swc_bss_base_585f006d+0x1b8>
  40dd26:	jmp    40dd2c <__swc_fn_585f006d_000020_4135c89a+0x4c>
  40dd28:	mov    QWORD PTR [rax+0x10],rcx
  40dd2c:	vxorps xmm0,xmm0,xmm0
  40dd30:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40dd36:	mov    QWORD PTR [r13+0x8],rdi
  40dd3a:	mov    rcx,r12
  40dd3d:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  40dd42:	mov    rax,r13
  40dd45:	add    rsp,0x8
  40dd49:	pop    r13
  40dd4b:	pop    r12
  40dd4d:	pop    rdi
  40dd4e:	pop    rsi
  40dd4f:	ret
  40dd50:	mov    rax,r13
  40dd53:	mov    r13,rcx
  40dd56:	test   rcx,rcx
  40dd59:	jne    40dd10 <__swc_fn_585f006d_000020_4135c89a+0x30>
  40dd5b:	mov    ecx,esi
  40dd5d:	call   40a780 <__swc_fn_585f006d_000019_60e50998>
  40dd62:	mov    rsi,rax
  40dd65:	test   rax,rax
  40dd68:	jne    40dd7f <__swc_fn_585f006d_000020_4135c89a+0x9f>
  40dd6a:	mov    rcx,r12
  40dd6d:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  40dd72:	xor    eax,eax
  40dd74:	add    rsp,0x8
  40dd78:	pop    r13
  40dd7a:	pop    r12
  40dd7c:	pop    rdi
  40dd7d:	pop    rsi
  40dd7e:	ret
  40dd7f:	mov    QWORD PTR [rsi+0x8],rdi
  40dd83:	mov    rcx,r12
  40dd86:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  40dd8b:	mov    rax,rsi
  40dd8e:	add    rsp,0x8
  40dd92:	pop    r13
  40dd94:	pop    r12
  40dd96:	pop    rdi
  40dd97:	pop    rsi
  40dd98:	ret
  40dd99:	add    BYTE PTR [rax],al
  40dd9b:	add    BYTE PTR [rax],al
  40dd9d:	add    BYTE PTR [rax],al
	...

000000000040dda0 <__swc_fn_585f006d_000023_7e9350e1>:
  40dda0:	vxorps xmm0,xmm0,xmm0
  40dda4:	xor    eax,eax
  40dda6:	cs nop WORD PTR [rax+rax*1+0x0]
  40ddb0:	cs nop WORD PTR [rax+rax*1+0x0]
  40ddba:	nop    WORD PTR [rax+rax*1+0x0]
  40ddc0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40ddc5:	add    rax,0x10
  40ddc9:	cmp    rax,0x2b00
  40ddd0:	jne    40ddc0 <__swc_fn_585f006d_000023_7e9350e1+0x20>
  40ddd2:	ret
	...

000000000040dde0 <__swc_fn_585f006d_000026_7e9350e1>:
  40dde0:	vxorps xmm0,xmm0,xmm0
  40dde4:	vmovups XMMWORD PTR [rcx],xmm0
  40dde8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40dded:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40ddf2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40ddf7:	ret
	...

000000000040de00 <__swc_fn_585f006d_000029_7e9350e1>:
  40de00:	vxorps xmm0,xmm0,xmm0
  40de04:	vmovups XMMWORD PTR [rcx],xmm0
  40de08:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40de0d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40de12:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40de17:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40de1c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40de21:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40de26:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40de2b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40de33:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40de3b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40de43:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40de4b:	mov    QWORD PTR [rcx+0xc0],0x0
  40de56:	ret
	...

000000000040de60 <__swc_fn_585f006d_000032_8c89735c>:
  40de60:	push   rsi
  40de61:	push   rdi
  40de62:	sub    rsp,0x8
  40de66:	mov    rsi,rcx
  40de69:	lea    rdi,[rip+0x13190]        # 421000 <__swc_data_base_585f006d>
  40de70:	mov    rax,QWORD PTR [rdi]
  40de73:	cmp    rax,0xffffffffffffffff
  40de77:	je     40de7e <__swc_fn_585f006d_000032_8c89735c+0x1e>
  40de79:	mov    rdi,rax
  40de7c:	jmp    40deab <__swc_fn_585f006d_000032_8c89735c+0x4b>
  40de7e:	call   409580 <__swc_fn_585f006d_000123_e9227a3e>
  40de83:	mov    rcx,rax
  40de86:	cmp    rax,0xffffffffffffffff
  40de8a:	je     40debc <__swc_fn_585f006d_000032_8c89735c+0x5c>
  40de8c:	mov    rax,0xffffffffffffffff
  40de93:	lock cmpxchg QWORD PTR [rdi],rcx
  40de98:	cmp    rax,0xffffffffffffffff
  40de9c:	je     40dea8 <__swc_fn_585f006d_000032_8c89735c+0x48>
  40de9e:	mov    rdi,rax
  40dea1:	call   40cb70 <__swc_fn_585f006d_000124_df97aa0a>
  40dea6:	jmp    40deab <__swc_fn_585f006d_000032_8c89735c+0x4b>
  40dea8:	mov    rdi,rcx
  40deab:	cmp    rdi,0xffffffffffffffff
  40deaf:	je     40debc <__swc_fn_585f006d_000032_8c89735c+0x5c>
  40deb1:	mov    rcx,rdi
  40deb4:	mov    rdx,rsi
  40deb7:	call   40ff70 <__swc_fn_585f006d_000125_e19c72b3>
  40debc:	add    rsp,0x8
  40dec0:	pop    rdi
  40dec1:	pop    rsi
  40dec2:	ret
	...

000000000040ded0 <__swc_fn_585f006d_000035_6105596e>:
  40ded0:	sub    rsp,0x38
  40ded4:	mov    rax,rdx
  40ded7:	test   dl,dl
  40ded9:	jne    40def1 <__swc_fn_585f006d_000035_6105596e+0x21>
  40dedb:	mov    rax,r8
  40dede:	test   r8b,r8b
  40dee1:	cmove  eax,r9d
  40dee5:	test   al,al
  40dee7:	cmove  eax,r10d
  40deeb:	test   al,al
  40deed:	cmove  eax,r11d
  40def1:	test   al,al
  40def3:	jne    40defa <__swc_fn_585f006d_000035_6105596e+0x2a>
  40def5:	add    rsp,0x38
  40def9:	ret
  40defa:	lea    rcx,[rip+0x420f]        # 412110 <__swc_rdata_base_585f006d>
  40df01:	vmovups xmm0,XMMWORD PTR [rip+0x4217]        # 412120 <__swc_rdata_base_585f006d+0x10>
  40df09:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40df0f:	vmovups xmm0,XMMWORD PTR [rip+0x4219]        # 412130 <__swc_rdata_base_585f006d+0x20>
  40df17:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40df1d:	vmovups xmm0,XMMWORD PTR [rip+0x421b]        # 412140 <__swc_rdata_base_585f006d+0x30>
  40df25:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40df2b:	lea    rdx,[rsp+0x8]
  40df30:	call   40c3a0 <__swc_fn_585f006d_000103_2ed36338>
  40df35:	jmp    40def5 <__swc_fn_585f006d_000035_6105596e+0x25>
	...

000000000040df40 <__swc_fn_585f006d_000038_c7591393>:
  40df40:	sub    rsp,0x8
  40df44:	mov    eax,0x1000
  40df49:	test   eax,eax
  40df4b:	mov    r8d,0x8
  40df51:	cmove  eax,r8d
  40df55:	dec    rax
  40df58:	mov    r8,0xffffffffffffffff
  40df5f:	sub    r8,rax
  40df62:	cmp    rdx,r8
  40df65:	ja     40df75 <__swc_fn_585f006d_000038_c7591393+0x35>
  40df67:	add    rdx,rax
  40df6a:	not    rax
  40df6d:	mov    r8,rdx
  40df70:	and    r8,rax
  40df73:	jne    40df7c <__swc_fn_585f006d_000038_c7591393+0x3c>
  40df75:	xor    eax,eax
  40df77:	add    rsp,0x8
  40df7b:	ret
  40df7c:	mov    rdx,r8
  40df7f:	call   40aaa0 <__swc_fn_585f006d_000037_92e867c2>
  40df84:	add    rsp,0x8
  40df88:	ret
  40df89:	add    BYTE PTR [rax],al
  40df8b:	add    BYTE PTR [rax],al
  40df8d:	add    BYTE PTR [rax],al
	...

000000000040df90 <__swc_fn_585f006d_000041_ed1cda78>:
  40df90:	push   rsi
  40df91:	push   rdi
  40df92:	sub    rsp,0x8
  40df96:	mov    rsi,rdx
  40df99:	mov    rdi,rcx
  40df9c:	test   rdx,rdx
  40df9f:	je     40dfbb <__swc_fn_585f006d_000041_ed1cda78+0x2b>
  40dfa1:	xor    ecx,ecx
  40dfa3:	call   407720 <__swc_fn_585f006d_000033_7d7574b6>
  40dfa8:	mov    rax,QWORD PTR [rsi]
  40dfab:	test   rax,rax
  40dfae:	je     40dfbb <__swc_fn_585f006d_000041_ed1cda78+0x2b>
  40dfb0:	mov    rcx,rax
  40dfb3:	mov    rdx,rsi
  40dfb6:	call   407840 <__swc_fn_585f006d_000042_70d5ab54>
  40dfbb:	mov    rcx,rdi
  40dfbe:	call   40ab00 <__swc_fn_585f006d_000040_7a225310>
  40dfc3:	mov    rsi,rax
  40dfc6:	test   rax,rax
  40dfc9:	jne    40dfd4 <__swc_fn_585f006d_000041_ed1cda78+0x44>
  40dfcb:	xor    eax,eax
  40dfcd:	add    rsp,0x8
  40dfd1:	pop    rdi
  40dfd2:	pop    rsi
  40dfd3:	ret
  40dfd4:	mov    rcx,rsi
  40dfd7:	call   407720 <__swc_fn_585f006d_000033_7d7574b6>
  40dfdc:	mov    rax,rsi
  40dfdf:	add    rsp,0x8
  40dfe3:	pop    rdi
  40dfe4:	pop    rsi
  40dfe5:	ret
	...

000000000040dff0 <__swc_fn_585f006d_000044_cac7f504>:
  40dff0:	movzx  eax,BYTE PTR [r8+0x39]
  40dff5:	lea    rax,[rax+rax*4]
  40dff9:	lea    rax,[rdx+rax*8+0x28]
  40dffe:	mov    ecx,DWORD PTR [r8+0x6c]
  40e002:	test   ecx,ecx
  40e004:	je     40e03d <__swc_fn_585f006d_000044_cac7f504+0x4d>
  40e006:	mov    rcx,QWORD PTR [r8+0x50]
  40e00a:	test   rcx,rcx
  40e00d:	je     40e019 <__swc_fn_585f006d_000044_cac7f504+0x29>
  40e00f:	mov    rax,QWORD PTR [r8+0x48]
  40e013:	mov    QWORD PTR [rcx+0x48],rax
  40e017:	jmp    40e021 <__swc_fn_585f006d_000044_cac7f504+0x31>
  40e019:	mov    rcx,QWORD PTR [r8+0x48]
  40e01d:	mov    QWORD PTR [rax+0x18],rcx
  40e021:	mov    rax,QWORD PTR [r8+0x48]
  40e025:	test   rax,rax
  40e028:	je     40e032 <__swc_fn_585f006d_000044_cac7f504+0x42>
  40e02a:	mov    rcx,QWORD PTR [r8+0x50]
  40e02e:	mov    QWORD PTR [rax+0x50],rcx
  40e032:	vxorps xmm0,xmm0,xmm0
  40e036:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e03c:	ret
  40e03d:	mov    rcx,QWORD PTR [r8+0x50]
  40e041:	test   rcx,rcx
  40e044:	je     40e050 <__swc_fn_585f006d_000044_cac7f504+0x60>
  40e046:	mov    rdx,QWORD PTR [r8+0x48]
  40e04a:	mov    QWORD PTR [rcx+0x48],rdx
  40e04e:	jmp    40e058 <__swc_fn_585f006d_000044_cac7f504+0x68>
  40e050:	mov    rcx,QWORD PTR [r8+0x48]
  40e054:	mov    QWORD PTR [rax+0x8],rcx
  40e058:	mov    rcx,QWORD PTR [r8+0x48]
  40e05c:	test   rcx,rcx
  40e05f:	je     40e06b <__swc_fn_585f006d_000044_cac7f504+0x7b>
  40e061:	mov    rdx,QWORD PTR [r8+0x50]
  40e065:	mov    QWORD PTR [rcx+0x50],rdx
  40e069:	jmp    40e073 <__swc_fn_585f006d_000044_cac7f504+0x83>
  40e06b:	mov    rcx,QWORD PTR [r8+0x50]
  40e06f:	mov    QWORD PTR [rax+0x10],rcx
  40e073:	cmp    QWORD PTR [rax],r8
  40e076:	jne    40e07f <__swc_fn_585f006d_000044_cac7f504+0x8f>
  40e078:	mov    QWORD PTR [rax],0x0
  40e07f:	vxorps xmm0,xmm0,xmm0
  40e083:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e089:	ret
  40e08a:	add    BYTE PTR [rax],al
  40e08c:	add    BYTE PTR [rax],al
	...

000000000040e090 <__swc_fn_585f006d_000047_3d3eceb4>:
  40e090:	sub    rsp,0x8
  40e094:	mov    r9,r8
  40e097:	mov    r10,rdx
  40e09a:	call   40dff0 <__swc_fn_585f006d_000044_cac7f504>
  40e09f:	mov    DWORD PTR [r9+0x6c],0x0
  40e0a7:	movzx  eax,BYTE PTR [r9+0x39]
  40e0ac:	lea    rax,[rax+rax*4]
  40e0b0:	lea    rax,[r10+rax*8+0x28]
  40e0b5:	mov    rcx,QWORD PTR [rax+0x10]
  40e0b9:	mov    QWORD PTR [r9+0x50],rcx
  40e0bd:	mov    QWORD PTR [r9+0x48],0x0
  40e0c5:	mov    rcx,QWORD PTR [rax+0x10]
  40e0c9:	test   rcx,rcx
  40e0cc:	je     40e0d4 <__swc_fn_585f006d_000047_3d3eceb4+0x44>
  40e0ce:	mov    QWORD PTR [rcx+0x48],r9
  40e0d2:	jmp    40e0d8 <__swc_fn_585f006d_000047_3d3eceb4+0x48>
  40e0d4:	mov    QWORD PTR [rax+0x8],r9
  40e0d8:	mov    QWORD PTR [rax+0x10],r9
  40e0dc:	add    rsp,0x8
  40e0e0:	ret
	...

000000000040e100 <__swc_fn_585f006d_000050_e33921d7>:
  40e100:	push   rsi
  40e101:	push   rdi
  40e102:	push   r12
  40e104:	push   r13
  40e106:	push   r14
  40e108:	push   r15
  40e10a:	sub    rsp,0x1f8
  40e111:	mov    esi,r8d
  40e114:	mov    QWORD PTR [rsp+0x1e8],rsi
  40e11c:	mov    rdi,rcx
  40e11f:	mov    r12,rdx
  40e122:	lea    r13,[rsi+rsi*4]
  40e126:	lea    r13,[rdx+r13*8+0x28]
  40e12b:	call   407ca0 <__swc_fn_585f006d_000048_18a95c9b>
  40e130:	add    DWORD PTR [r12+0x24],0x1
  40e136:	test   BYTE PTR [r12+0x24],0x3f
  40e13c:	jne    40e146 <__swc_fn_585f006d_000050_e33921d7+0x46>
  40e13e:	mov    rcx,rdi
  40e141:	call   40ac80 <__swc_fn_585f006d_000049_781177b4>
  40e146:	mov    rax,QWORD PTR [r13+0x8]
  40e14a:	mov    r14,rax
  40e14d:	nop    DWORD PTR [rax]
  40e150:	test   r14,r14
  40e153:	jne    40e162 <__swc_fn_585f006d_000050_e33921d7+0x62>
  40e155:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40e15d:	jmp    40e269 <__swc_fn_585f006d_000050_e33921d7+0x169>
  40e162:	mov    r15,QWORD PTR [r14+0x48]
  40e166:	mov    rcx,r14
  40e169:	call   4073f0 <__swc_fn_585f006d_000009_2417e911>
  40e16e:	mov    rax,QWORD PTR [r14]
  40e171:	test   rax,rax
  40e174:	je     40e186 <__swc_fn_585f006d_000050_e33921d7+0x86>
  40e176:	mov    rcx,QWORD PTR [rax]
  40e179:	mov    QWORD PTR [r14],rcx
  40e17c:	add    DWORD PTR [r14+0x28],0x1
  40e181:	mov    rsi,rax
  40e184:	jmp    40e1a5 <__swc_fn_585f006d_000050_e33921d7+0xa5>
  40e186:	mov    rax,QWORD PTR [r14+0x18]
  40e18a:	cmp    QWORD PTR [r14+0x20],rax
  40e18e:	jae    40e1a3 <__swc_fn_585f006d_000050_e33921d7+0xa3>
  40e190:	mov    rsi,QWORD PTR [r14+0x20]
  40e194:	mov    eax,DWORD PTR [r14+0x2c]
  40e198:	add    QWORD PTR [r14+0x20],rax
  40e19c:	add    DWORD PTR [r14+0x28],0x1
  40e1a1:	jmp    40e1a5 <__swc_fn_585f006d_000050_e33921d7+0xa5>
  40e1a3:	xor    esi,esi
  40e1a5:	test   rsi,rsi
  40e1a8:	jne    40e1ed <__swc_fn_585f006d_000050_e33921d7+0xed>
  40e1aa:	mov    rcx,r14
  40e1ad:	call   407320 <__swc_fn_585f006d_000006_12cb36a2>
  40e1b2:	test   al,al
  40e1b4:	je     40e1ed <__swc_fn_585f006d_000050_e33921d7+0xed>
  40e1b6:	mov    rax,QWORD PTR [r14]
  40e1b9:	test   rax,rax
  40e1bc:	je     40e1cb <__swc_fn_585f006d_000050_e33921d7+0xcb>
  40e1be:	mov    rcx,QWORD PTR [rax]
  40e1c1:	mov    QWORD PTR [r14],rcx
  40e1c4:	add    DWORD PTR [r14+0x28],0x1
  40e1c9:	jmp    40e1ea <__swc_fn_585f006d_000050_e33921d7+0xea>
  40e1cb:	mov    rax,QWORD PTR [r14+0x18]
  40e1cf:	cmp    QWORD PTR [r14+0x20],rax
  40e1d3:	jae    40e1e8 <__swc_fn_585f006d_000050_e33921d7+0xe8>
  40e1d5:	mov    rax,QWORD PTR [r14+0x20]
  40e1d9:	mov    ecx,DWORD PTR [r14+0x2c]
  40e1dd:	add    QWORD PTR [r14+0x20],rcx
  40e1e1:	add    DWORD PTR [r14+0x28],0x1
  40e1e6:	jmp    40e1ea <__swc_fn_585f006d_000050_e33921d7+0xea>
  40e1e8:	xor    eax,eax
  40e1ea:	mov    rsi,rax
  40e1ed:	test   rsi,rsi
  40e1f0:	jne    40e243 <__swc_fn_585f006d_000050_e33921d7+0x143>
  40e1f2:	mov    rcx,rdi
  40e1f5:	mov    rdx,r12
  40e1f8:	mov    r8,r14
  40e1fb:	call   40abe0 <__swc_fn_585f006d_000046_49300800>
  40e200:	test   al,al
  40e202:	jne    40e243 <__swc_fn_585f006d_000050_e33921d7+0x143>
  40e204:	mov    rcx,r14
  40e207:	call   4073f0 <__swc_fn_585f006d_000009_2417e911>
  40e20c:	mov    rax,QWORD PTR [r14]
  40e20f:	test   rax,rax
  40e212:	je     40e221 <__swc_fn_585f006d_000050_e33921d7+0x121>
  40e214:	mov    rcx,QWORD PTR [rax]
  40e217:	mov    QWORD PTR [r14],rcx
  40e21a:	add    DWORD PTR [r14+0x28],0x1
  40e21f:	jmp    40e240 <__swc_fn_585f006d_000050_e33921d7+0x140>
  40e221:	mov    rax,QWORD PTR [r14+0x18]
  40e225:	cmp    QWORD PTR [r14+0x20],rax
  40e229:	jae    40e23e <__swc_fn_585f006d_000050_e33921d7+0x13e>
  40e22b:	mov    rax,QWORD PTR [r14+0x20]
  40e22f:	mov    ecx,DWORD PTR [r14+0x2c]
  40e233:	add    QWORD PTR [r14+0x20],rcx
  40e237:	add    DWORD PTR [r14+0x28],0x1
  40e23c:	jmp    40e240 <__swc_fn_585f006d_000050_e33921d7+0x140>
  40e23e:	xor    eax,eax
  40e240:	mov    rsi,rax
  40e243:	test   rsi,rsi
  40e246:	je     40e261 <__swc_fn_585f006d_000050_e33921d7+0x161>
  40e248:	mov    QWORD PTR [r13+0x0],r14
  40e24c:	mov    rax,rsi
  40e24f:	add    rsp,0x1f8
  40e256:	pop    r15
  40e258:	pop    r14
  40e25a:	pop    r13
  40e25c:	pop    r12
  40e25e:	pop    rdi
  40e25f:	pop    rsi
  40e260:	ret
  40e261:	mov    r14,r15
  40e264:	jmp    40e150 <__swc_fn_585f006d_000050_e33921d7+0x50>
  40e269:	cs nop WORD PTR [rax+rax*1+0x0]
  40e273:	cs nop WORD PTR [rax+rax*1+0x0]
  40e27d:	nop    DWORD PTR [rax]
  40e280:	mov    rcx,rdi
  40e283:	mov    rdx,r12
  40e286:	mov    r8d,esi
  40e289:	call   4079e0 <__swc_fn_585f006d_000045_06cec934>
  40e28e:	mov    r14,rax
  40e291:	test   rax,rax
  40e294:	jne    40e2aa <__swc_fn_585f006d_000050_e33921d7+0x1aa>
  40e296:	xor    eax,eax
  40e298:	add    rsp,0x1f8
  40e29f:	pop    r15
  40e2a1:	pop    r14
  40e2a3:	pop    r13
  40e2a5:	pop    r12
  40e2a7:	pop    rdi
  40e2a8:	pop    rsi
  40e2a9:	ret
  40e2aa:	mov    QWORD PTR [r13+0x0],r14
  40e2ae:	mov    rax,QWORD PTR [r14]
  40e2b1:	test   rax,rax
  40e2b4:	je     40e2c6 <__swc_fn_585f006d_000050_e33921d7+0x1c6>
  40e2b6:	mov    rcx,QWORD PTR [rax]
  40e2b9:	mov    QWORD PTR [r14],rcx
  40e2bc:	add    DWORD PTR [r14+0x28],0x1
  40e2c1:	mov    r15,rax
  40e2c4:	jmp    40e2e6 <__swc_fn_585f006d_000050_e33921d7+0x1e6>
  40e2c6:	mov    rax,QWORD PTR [r14+0x18]
  40e2ca:	cmp    QWORD PTR [r14+0x20],rax
  40e2ce:	jae    40e2e3 <__swc_fn_585f006d_000050_e33921d7+0x1e3>
  40e2d0:	mov    r15,QWORD PTR [r14+0x20]
  40e2d4:	mov    eax,DWORD PTR [r14+0x2c]
  40e2d8:	add    QWORD PTR [r14+0x20],rax
  40e2dc:	add    DWORD PTR [r14+0x28],0x1
  40e2e1:	jmp    40e2e6 <__swc_fn_585f006d_000050_e33921d7+0x1e6>
  40e2e3:	xor    r15d,r15d
  40e2e6:	test   r15,r15
  40e2e9:	jne    40e32e <__swc_fn_585f006d_000050_e33921d7+0x22e>
  40e2eb:	mov    rcx,r14
  40e2ee:	call   407320 <__swc_fn_585f006d_000006_12cb36a2>
  40e2f3:	test   al,al
  40e2f5:	je     40e32e <__swc_fn_585f006d_000050_e33921d7+0x22e>
  40e2f7:	mov    rax,QWORD PTR [r14]
  40e2fa:	test   rax,rax
  40e2fd:	je     40e30c <__swc_fn_585f006d_000050_e33921d7+0x20c>
  40e2ff:	mov    rcx,QWORD PTR [rax]
  40e302:	mov    QWORD PTR [r14],rcx
  40e305:	add    DWORD PTR [r14+0x28],0x1
  40e30a:	jmp    40e32b <__swc_fn_585f006d_000050_e33921d7+0x22b>
  40e30c:	mov    rax,QWORD PTR [r14+0x18]
  40e310:	cmp    QWORD PTR [r14+0x20],rax
  40e314:	jae    40e329 <__swc_fn_585f006d_000050_e33921d7+0x229>
  40e316:	mov    rax,QWORD PTR [r14+0x20]
  40e31a:	mov    ecx,DWORD PTR [r14+0x2c]
  40e31e:	add    QWORD PTR [r14+0x20],rcx
  40e322:	add    DWORD PTR [r14+0x28],0x1
  40e327:	jmp    40e32b <__swc_fn_585f006d_000050_e33921d7+0x22b>
  40e329:	xor    eax,eax
  40e32b:	mov    r15,rax
  40e32e:	test   r15,r15
  40e331:	je     40e280 <__swc_fn_585f006d_000050_e33921d7+0x180>
  40e337:	mov    rax,r15
  40e33a:	add    rsp,0x1f8
  40e341:	pop    r15
  40e343:	pop    r14
  40e345:	pop    r13
  40e347:	pop    r12
  40e349:	pop    rdi
  40e34a:	pop    rsi
  40e34b:	ret
  40e34c:	add    BYTE PTR [rax],al
	...

000000000040e350 <__swc_fn_585f006d_000053_a8a124d6>:
  40e350:	push   rsi
  40e351:	push   rdi
  40e352:	push   r12
  40e354:	mov    rsi,rdx
  40e357:	mov    rax,rdx
  40e35a:	shr    rax,0xc
  40e35e:	movabs rdx,0x9e3779b97f4a7c15
  40e368:	imul   rax,rdx
  40e36c:	shr    rax,0x20
  40e370:	lea    rax,[rax*8+0x0]
  40e378:	shr    rax,0x20
  40e37c:	lea    rax,[rax*8+0x0]
  40e384:	lea    rax,[rcx+rax*8+0x40]
  40e389:	xor    edx,edx
  40e38b:	test   dl,dl
  40e38d:	lea    rdi,[rcx+0x8]
  40e391:	cmove  rdi,rax
  40e395:	xor    edx,edx
  40e397:	test   dl,dl
  40e399:	lea    r12,[rcx+0x30]
  40e39d:	lea    rax,[rax+0x8]
  40e3a1:	cmove  r12,rax
  40e3a5:	mov    rcx,rdi
  40e3a8:	call   4098a0 <__swc_fn_585f006d_000135_1fec60ac>
  40e3ad:	mov    QWORD PTR [rsi+0x30],0x0
  40e3b5:	mov    rax,QWORD PTR [r12]
  40e3b9:	mov    QWORD PTR [rsi+0x38],rax
  40e3bd:	test   rax,rax
  40e3c0:	je     40e3ca <__swc_fn_585f006d_000053_a8a124d6+0x7a>
  40e3c2:	mov    rax,QWORD PTR [rsi+0x38]
  40e3c6:	mov    QWORD PTR [rax+0x30],rsi
  40e3ca:	mov    QWORD PTR [r12],rsi
  40e3ce:	mov    rcx,rdi
  40e3d1:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  40e3d6:	pop    r12
  40e3d8:	pop    rdi
  40e3d9:	pop    rsi
  40e3da:	ret
  40e3db:	add    BYTE PTR [rax],al
  40e3dd:	add    BYTE PTR [rax],al
	...

000000000040e3e0 <__swc_fn_585f006d_000056_cfedf3f4>:
  40e3e0:	lea    rax,[rdx+rdx*4]
  40e3e4:	lea    rax,[rcx+rax*8+0x268]
  40e3ec:	mov    rdx,QWORD PTR [rax+0x10]
  40e3f0:	sub    QWORD PTR [rcx+0x2a68],rdx
  40e3f7:	sub    QWORD PTR [rcx+0x2a70],0x1
  40e3ff:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40e406:	lea    rdx,[rdx+rdx*4]
  40e40a:	lea    rdx,[rcx+rdx*8+0x268]
  40e412:	vmovups xmm0,XMMWORD PTR [rdx]
  40e416:	vmovups XMMWORD PTR [rax],xmm0
  40e41a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40e41f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e424:	mov    rcx,QWORD PTR [rdx+0x20]
  40e428:	mov    QWORD PTR [rax+0x20],rcx
  40e42c:	ret
  40e42d:	add    BYTE PTR [rax],al
	...

000000000040e430 <__swc_fn_585f006d_000059_c8e1ff6b>:
  40e430:	push   rsi
  40e431:	push   rdi
  40e432:	push   r12
  40e434:	push   r13
  40e436:	sub    rsp,0x8
  40e43a:	mov    rsi,r8
  40e43d:	mov    rdi,rcx
  40e440:	mov    r12,rdx
  40e443:	xor    r13d,r13d
  40e446:	cs nop WORD PTR [rax+rax*1+0x0]
  40e450:	mov    eax,DWORD PTR [r12+0x730]
  40e458:	cmp    r13d,eax
  40e45b:	jae    40e4c1 <__swc_fn_585f006d_000059_c8e1ff6b+0x91>
  40e45d:	lea    rax,[r13+r13*4+0x0]
  40e462:	lea    rax,[r12+rax*8+0x738]
  40e46a:	mov    rdx,QWORD PTR [rax]
  40e46d:	mov    r8,QWORD PTR [rax+0x8]
  40e471:	mov    r9,QWORD PTR [rax+0x10]
  40e475:	cmp    QWORD PTR [rax+0x20],rsi
  40e479:	jb     40e480 <__swc_fn_585f006d_000059_c8e1ff6b+0x50>
  40e47b:	inc    r13d
  40e47e:	jmp    40e450 <__swc_fn_585f006d_000059_c8e1ff6b+0x20>
  40e480:	sub    DWORD PTR [r12+0x730],0x1
  40e489:	mov    ecx,DWORD PTR [r12+0x730]
  40e491:	lea    rcx,[rcx+rcx*4]
  40e495:	lea    rcx,[r12+rcx*8+0x738]
  40e49d:	vmovups xmm0,XMMWORD PTR [rcx]
  40e4a1:	vmovups XMMWORD PTR [rax],xmm0
  40e4a5:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40e4aa:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e4af:	mov    rcx,QWORD PTR [rcx+0x20]
  40e4b3:	mov    QWORD PTR [rax+0x20],rcx
  40e4b7:	mov    rcx,rdi
  40e4ba:	call   407750 <__swc_fn_585f006d_000039_05a50673>
  40e4bf:	jmp    40e450 <__swc_fn_585f006d_000059_c8e1ff6b+0x20>
  40e4c1:	add    rsp,0x8
  40e4c5:	pop    r13
  40e4c7:	pop    r12
  40e4c9:	pop    rdi
  40e4ca:	pop    rsi
  40e4cb:	ret
  40e4cc:	add    BYTE PTR [rax],al
	...

000000000040e4d0 <__swc_fn_585f006d_000062_baa48dba>:
  40e4d0:	push   rsi
  40e4d1:	push   rdi
  40e4d2:	push   r12
  40e4d4:	push   r13
  40e4d6:	push   r14
  40e4d8:	mov    rsi,rcx
  40e4db:	mov    rdi,rdx
  40e4de:	mov    r12,QWORD PTR [rdi]
  40e4e1:	mov    r13,QWORD PTR [rdi+0x18]
  40e4e5:	mov    rax,r12
  40e4e8:	add    rax,QWORD PTR [rdi+0x8]
  40e4ec:	sub    rax,r13
  40e4ef:	cmp    r8,rax
  40e4f2:	jbe    40e4fd <__swc_fn_585f006d_000062_baa48dba+0x2d>
  40e4f4:	pop    r14
  40e4f6:	pop    r13
  40e4f8:	pop    r12
  40e4fa:	pop    rdi
  40e4fb:	pop    rsi
  40e4fc:	ret
  40e4fd:	lea    rax,[r13+r8*1+0x0]
  40e502:	sub    rax,r12
  40e505:	mov    ecx,0x1000
  40e50a:	test   ecx,ecx
  40e50c:	mov    edx,0x8
  40e511:	cmove  ecx,edx
  40e514:	dec    rcx
  40e517:	mov    rdx,0xffffffffffffffff
  40e51e:	sub    rdx,rcx
  40e521:	cmp    rax,rdx
  40e524:	jbe    40e52b <__swc_fn_585f006d_000062_baa48dba+0x5b>
  40e526:	xor    r14d,r14d
  40e529:	jmp    40e536 <__swc_fn_585f006d_000062_baa48dba+0x66>
  40e52b:	add    rax,rcx
  40e52e:	andn   rax,rcx,rax
  40e533:	mov    r14,rax
  40e536:	mov    rax,QWORD PTR [rdi+0x10]
  40e53a:	cmp    r14,rax
  40e53d:	ja     40e548 <__swc_fn_585f006d_000062_baa48dba+0x78>
  40e53f:	pop    r14
  40e541:	pop    r13
  40e543:	pop    r12
  40e545:	pop    rdi
  40e546:	pop    rsi
  40e547:	ret
  40e548:	mov    rax,r12
  40e54b:	add    rax,QWORD PTR [rdi+0x10]
  40e54f:	mov    rdx,r14
  40e552:	sub    rdx,QWORD PTR [rdi+0x10]
  40e556:	mov    rcx,rax
  40e559:	call   4072a0 <__swc_fn_585f006d_000003_644dadb7>
  40e55e:	test   al,al
  40e560:	jne    40e56b <__swc_fn_585f006d_000062_baa48dba+0x9b>
  40e562:	pop    r14
  40e564:	pop    r13
  40e566:	pop    r12
  40e568:	pop    rdi
  40e569:	pop    rsi
  40e56a:	ret
  40e56b:	add    r12,r14
  40e56e:	sub    r12,r13
  40e571:	mov    rcx,r12
  40e574:	sub    rcx,QWORD PTR [rdi+0x28]
  40e578:	mov    rdx,QWORD PTR [rsi+0x250]
  40e57f:	nop
  40e580:	lea    r8,[rdx+rcx*1]
  40e584:	mov    rax,rdx
  40e587:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40e590:	cmp    rax,rdx
  40e593:	je     40e59a <__swc_fn_585f006d_000062_baa48dba+0xca>
  40e595:	mov    rdx,rax
  40e598:	jmp    40e580 <__swc_fn_585f006d_000062_baa48dba+0xb0>
  40e59a:	mov    QWORD PTR [rdi+0x10],r14
  40e59e:	mov    QWORD PTR [rdi+0x28],r12
  40e5a2:	pop    r14
  40e5a4:	pop    r13
  40e5a6:	pop    r12
  40e5a8:	pop    rdi
  40e5a9:	pop    rsi
  40e5aa:	ret
  40e5ab:	add    BYTE PTR [rax],al
  40e5ad:	add    BYTE PTR [rax],al
	...

000000000040e5b0 <__swc_fn_585f006d_000065_cd9dd53e>:
  40e5b0:	push   rbx
  40e5b1:	push   rsi
  40e5b2:	push   rdi
  40e5b3:	push   r12
  40e5b5:	push   r13
  40e5b7:	sub    rsp,0xe0
  40e5be:	mov    rbx,rdx
  40e5c1:	mov    rsi,rcx
  40e5c4:	cmp    DWORD PTR [rbx+0x58],0x0
  40e5c8:	je     40e5ec <__swc_fn_585f006d_000065_cd9dd53e+0x3c>
  40e5ca:	mov    eax,DWORD PTR [rbx+0x58]
  40e5cd:	sub    eax,0x1
  40e5d0:	test   DWORD PTR [rbx+0x58],eax
  40e5d3:	je     40e5ec <__swc_fn_585f006d_000065_cd9dd53e+0x3c>
  40e5d5:	mov    QWORD PTR [rbx+0x40],0x0
  40e5dd:	add    rsp,0xe0
  40e5e4:	pop    r13
  40e5e6:	pop    r12
  40e5e8:	pop    rdi
  40e5e9:	pop    rsi
  40e5ea:	pop    rbx
  40e5eb:	ret
  40e5ec:	mov    rax,QWORD PTR [rbx+0x40]
  40e5f0:	test   rax,rax
  40e5f3:	jne    40e60f <__swc_fn_585f006d_000065_cd9dd53e+0x5f>
  40e5f5:	mov    rcx,rsi
  40e5f8:	mov    rdx,rbx
  40e5fb:	call   40b890 <__swc_fn_585f006d_000064_6905bec4>
  40e600:	add    rsp,0xe0
  40e607:	pop    r13
  40e609:	pop    r12
  40e60b:	pop    rdi
  40e60c:	pop    rsi
  40e60d:	pop    rbx
  40e60e:	ret
  40e60f:	cmp    QWORD PTR [rbx+0x48],0x0
  40e614:	jne    40e630 <__swc_fn_585f006d_000065_cd9dd53e+0x80>
  40e616:	mov    rcx,rsi
  40e619:	mov    rdx,rbx
  40e61c:	call   407f90 <__swc_fn_585f006d_000066_77c6e829>
  40e621:	add    rsp,0xe0
  40e628:	pop    r13
  40e62a:	pop    r12
  40e62c:	pop    rdi
  40e62d:	pop    rsi
  40e62e:	pop    rbx
  40e62f:	ret
  40e630:	mov    rdi,QWORD PTR [rbx+0x40]
  40e634:	lea    rax,[rip+0x14a35]        # 423070 <__swc_bss_base_585f006d+0x30>
  40e63b:	mov    rcx,rdi
  40e63e:	sub    rcx,QWORD PTR [rax+0x8]
  40e642:	mov    rax,QWORD PTR [rip+0x14a37]        # 423080 <__swc_bss_base_585f006d+0x40>
  40e649:	cmp    rcx,rax
  40e64c:	jae    40e678 <__swc_fn_585f006d_000065_cd9dd53e+0xc8>
  40e64e:	mov    rax,rdi
  40e651:	and    rax,0xffffffffffc00000
  40e658:	mov    rcx,rdi
  40e65b:	shr    rcx,0x10
  40e65f:	and    ecx,0x3f
  40e662:	mov    edx,DWORD PTR [rax+0x28]
  40e665:	shrx   ecx,ecx,edx
  40e66a:	shl    rcx,0x4
  40e66e:	lea    r12,[rax+rcx*8+0x80]
  40e676:	jmp    40e683 <__swc_fn_585f006d_000065_cd9dd53e+0xd3>
  40e678:	mov    rcx,rdi
  40e67b:	call   40a910 <__swc_fn_585f006d_000022_77c2d682>
  40e680:	mov    r12,rax
  40e683:	test   r12,r12
  40e686:	je     40e695 <__swc_fn_585f006d_000065_cd9dd53e+0xe5>
  40e688:	mov    eax,DWORD PTR [r12+0x2c]
  40e68d:	mov    r9d,eax
  40e690:	mov    r13,rax
  40e693:	jmp    40e714 <__swc_fn_585f006d_000065_cd9dd53e+0x164>
  40e695:	mov    rcx,rsi
  40e698:	mov    rdx,rdi
  40e69b:	call   40af20 <__swc_fn_585f006d_000052_26c6c1c4>
  40e6a0:	mov    rcx,QWORD PTR [rax+0x28]
  40e6a4:	mov    r9,rcx
  40e6a7:	mov    rdx,QWORD PTR [rax+0x20]
  40e6ab:	mov    r13,rdx
  40e6ae:	cmp    QWORD PTR [rbx+0x48],rcx
  40e6b2:	jbe    40e6eb <__swc_fn_585f006d_000065_cd9dd53e+0x13b>
  40e6b4:	mov    ecx,DWORD PTR [rax+0x48]
  40e6b7:	cmp    DWORD PTR [rbx+0x58],ecx
  40e6ba:	ja     40e6eb <__swc_fn_585f006d_000065_cd9dd53e+0x13b>
  40e6bc:	mov    rcx,rsi
  40e6bf:	mov    rdx,rax
  40e6c2:	mov    r8,QWORD PTR [rbx+0x48]
  40e6c6:	mov    QWORD PTR [rsp+0xc8],r9
  40e6ce:	mov    QWORD PTR [rsp+0xd0],rax
  40e6d6:	call   40e4d0 <__swc_fn_585f006d_000062_baa48dba>
  40e6db:	mov    r9,QWORD PTR [rsp+0xc8]
  40e6e3:	mov    rax,QWORD PTR [rsp+0xd0]
  40e6eb:	mov    rcx,QWORD PTR [rax+0x28]
  40e6ef:	cmp    QWORD PTR [rbx+0x48],rcx
  40e6f3:	ja     40e714 <__swc_fn_585f006d_000065_cd9dd53e+0x164>
  40e6f5:	mov    ecx,DWORD PTR [rax+0x48]
  40e6f8:	cmp    DWORD PTR [rbx+0x58],ecx
  40e6fb:	ja     40e714 <__swc_fn_585f006d_000065_cd9dd53e+0x164>
  40e6fd:	mov    rcx,QWORD PTR [rbx+0x48]
  40e701:	mov    QWORD PTR [rax+0x20],rcx
  40e705:	add    rsp,0xe0
  40e70c:	pop    r13
  40e70e:	pop    r12
  40e710:	pop    rdi
  40e711:	pop    rsi
  40e712:	pop    rbx
  40e713:	ret
  40e714:	test   r12,r12
  40e717:	je     40e749 <__swc_fn_585f006d_000065_cd9dd53e+0x199>
  40e719:	cmp    QWORD PTR [rbx+0x48],r9
  40e71d:	ja     40e749 <__swc_fn_585f006d_000065_cd9dd53e+0x199>
  40e71f:	cmp    DWORD PTR [rbx+0x58],0x40
  40e723:	ja     40e749 <__swc_fn_585f006d_000065_cd9dd53e+0x199>
  40e725:	cmp    DWORD PTR [rbx+0x58],0x0
  40e729:	je     40e736 <__swc_fn_585f006d_000065_cd9dd53e+0x186>
  40e72b:	mov    ecx,DWORD PTR [rbx+0x58]
  40e72e:	dec    rcx
  40e731:	test   rdi,rcx
  40e734:	jne    40e749 <__swc_fn_585f006d_000065_cd9dd53e+0x199>
  40e736:	mov    QWORD PTR [rbx+0x40],rdi
  40e73a:	add    rsp,0xe0
  40e741:	pop    r13
  40e743:	pop    r12
  40e745:	pop    rdi
  40e746:	pop    rsi
  40e747:	pop    rbx
  40e748:	ret
  40e749:	vmovups xmm0,XMMWORD PTR [rbx]
  40e74d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e753:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40e758:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e75e:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40e763:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e769:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40e76e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40e774:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40e779:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40e77f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40e784:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40e78a:	mov    QWORD PTR [rsp+0x48],0x0
  40e793:	mov    rcx,rsi
  40e796:	lea    rdx,[rsp+0x8]
  40e79b:	call   40b890 <__swc_fn_585f006d_000064_6905bec4>
  40e7a0:	mov    rax,QWORD PTR [rsp+0x48]
  40e7a5:	test   rax,rax
  40e7a8:	jne    40e7c1 <__swc_fn_585f006d_000065_cd9dd53e+0x211>
  40e7aa:	mov    QWORD PTR [rbx+0x40],0x0
  40e7b2:	add    rsp,0xe0
  40e7b9:	pop    r13
  40e7bb:	pop    r12
  40e7bd:	pop    rdi
  40e7be:	pop    rsi
  40e7bf:	pop    rbx
  40e7c0:	ret
  40e7c1:	mov    rax,QWORD PTR [rbx+0x48]
  40e7c5:	cmp    r13,rax
  40e7c8:	cmovbe rax,r13
  40e7cc:	mov    rcx,QWORD PTR [rsp+0x48]
  40e7d1:	mov    rdx,rdi
  40e7d4:	mov    r8,rax
  40e7d7:	call   4090e0 <__swc_fn_585f006d_000105_b7aef7c0>
  40e7dc:	vmovups xmm0,XMMWORD PTR [rbx]
  40e7e0:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40e7e6:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40e7eb:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40e7f1:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40e7f6:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40e7ff:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40e804:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40e80d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40e812:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40e81b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40e820:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40e829:	mov    QWORD PTR [rsp+0xa8],rdi
  40e831:	mov    rcx,rsi
  40e834:	lea    rdx,[rsp+0x68]
  40e839:	call   407f90 <__swc_fn_585f006d_000066_77c6e829>
  40e83e:	mov    rax,QWORD PTR [rsp+0x48]
  40e843:	mov    QWORD PTR [rbx+0x40],rax
  40e847:	add    rsp,0xe0
  40e84e:	pop    r13
  40e850:	pop    r12
  40e852:	pop    rdi
  40e853:	pop    rsi
  40e854:	pop    rbx
  40e855:	ret
	...

000000000040e860 <__swc_fn_585f006d_000068_557d6092>:
  40e860:	push   r12
  40e862:	push   rdi
  40e863:	push   rsi
  40e864:	push   r13
  40e866:	push   r14
  40e868:	sub    rsp,0x190
  40e86f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40e878:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40e881:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40e88a:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40e893:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40e89c:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40e8a5:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40e8ae:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40e8b7:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40e8c0:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40e8c9:	mov    r12,rcx
  40e8cc:	lea    rax,[rip+0x1272d]        # 421000 <__swc_data_base_585f006d>
  40e8d3:	mov    rax,QWORD PTR [rax]
  40e8d6:	cmp    rax,0xffffffffffffffff
  40e8da:	je     40e8e9 <__swc_fn_585f006d_000068_557d6092+0x89>
  40e8dc:	mov    eax,eax
  40e8de:	mov    edi,eax
  40e8e0:	xor    eax,eax
  40e8e2:	call   407000 <pthread_getspecific@plt>
  40e8e7:	jmp    40e8eb <__swc_fn_585f006d_000068_557d6092+0x8b>
  40e8e9:	xor    eax,eax
  40e8eb:	test   rax,rax
  40e8ee:	jne    40e8fd <__swc_fn_585f006d_000068_557d6092+0x9d>
  40e8f0:	call   40a9e0 <__swc_fn_585f006d_000031_ed8d61a9>
  40e8f5:	mov    rcx,rax
  40e8f8:	call   410020 <__swc_fn_585f006d_000128_9c45d2d7>
  40e8fd:	test   rax,rax
  40e900:	je     40e926 <__swc_fn_585f006d_000068_557d6092+0xc6>
  40e902:	cmp    QWORD PTR [rax],r12
  40e905:	jne    40e926 <__swc_fn_585f006d_000068_557d6092+0xc6>
  40e907:	xor    ecx,ecx
  40e909:	mov    QWORD PTR [rsp+0xc8],rax
  40e911:	call   407720 <__swc_fn_585f006d_000033_7d7574b6>
  40e916:	mov    rdx,QWORD PTR [rsp+0xc8]
  40e91e:	mov    rcx,r12
  40e921:	call   407840 <__swc_fn_585f006d_000042_70d5ab54>
  40e926:	lea    rsi,[r12+0x10]
  40e92b:	mov    rcx,rsi
  40e92e:	call   4098a0 <__swc_fn_585f006d_000135_1fec60ac>
  40e933:	mov    rdi,QWORD PTR [r12+0x20]
  40e938:	test   rdi,rdi
  40e93b:	je     40e97e <__swc_fn_585f006d_000068_557d6092+0x11e>
  40e93d:	nop    DWORD PTR [rax]
  40e940:	mov    rcx,r12
  40e943:	mov    rdx,rdi
  40e946:	call   40aba0 <__swc_fn_585f006d_000043_3755033a>
  40e94b:	mov    rcx,r12
  40e94e:	mov    rdx,rdi
  40e951:	mov    r8,0xffffffffffffffff
  40e958:	call   40e430 <__swc_fn_585f006d_000059_c8e1ff6b>
  40e95d:	mov    rcx,r12
  40e960:	mov    rdx,rdi
  40e963:	mov    r8d,0x9b8
  40e969:	mov    r9d,0x9b8
  40e96f:	call   407750 <__swc_fn_585f006d_000039_05a50673>
  40e974:	mov    rdi,QWORD PTR [r12+0x20]
  40e979:	test   rdi,rdi
  40e97c:	jne    40e940 <__swc_fn_585f006d_000068_557d6092+0xe0>
  40e97e:	xor    eax,eax
  40e980:	xchg   QWORD PTR [r12+0x2a80],rax
  40e988:	test   rax,rax
  40e98b:	je     40e9b1 <__swc_fn_585f006d_000068_557d6092+0x151>
  40e98d:	cs nop WORD PTR [rax+rax*1+0x0]
  40e997:	nop    WORD PTR [rax+rax*1+0x0]
  40e9a0:	mov    rcx,rax
  40e9a3:	mov    rax,QWORD PTR [rax+0x78]
  40e9a7:	xor    edx,edx
  40e9a9:	xchg   DWORD PTR [rcx+0x70],edx
  40e9ac:	test   rax,rax
  40e9af:	jne    40e9a0 <__swc_fn_585f006d_000068_557d6092+0x140>
  40e9b1:	mov    rax,QWORD PTR [r12+0x18]
  40e9b6:	mov    rdi,rax
  40e9b9:	test   rdi,rdi
  40e9bc:	je     40ea51 <__swc_fn_585f006d_000068_557d6092+0x1f1>
  40e9c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40e9cc:	nop    DWORD PTR [rax+0x0]
  40e9d0:	mov    rax,QWORD PTR [rdi+0x10]
  40e9d4:	mov    r8d,DWORD PTR [rdi+0x2c]
  40e9d8:	xor    r9d,r9d
  40e9db:	test   r8,r8
  40e9de:	jbe    40ea3d <__swc_fn_585f006d_000068_557d6092+0x1dd>
  40e9e0:	mov    ecx,r9d
  40e9e3:	shl    rcx,0x4
  40e9e7:	lea    rdx,[rdi+rcx*8+0x80]
  40e9ef:	cmp    BYTE PTR [rdx+0x3b],0x0
  40e9f3:	je     40ea34 <__swc_fn_585f006d_000068_557d6092+0x1d4>
  40e9f5:	mov    DWORD PTR [rdx+0x28],0x0
  40e9fc:	mov    rcx,rdi
  40e9ff:	mov    QWORD PTR [rsp+0xd0],rax
  40ea07:	mov    QWORD PTR [rsp+0xd8],r8
  40ea0f:	mov    QWORD PTR [rsp+0xe0],r9
  40ea17:	call   40db60 <__swc_fn_585f006d_000014_1acdaf22>
  40ea1c:	mov    rax,QWORD PTR [rsp+0xd0]
  40ea24:	mov    r8,QWORD PTR [rsp+0xd8]
  40ea2c:	mov    r9,QWORD PTR [rsp+0xe0]
  40ea34:	add    r9,0x1
  40ea38:	cmp    r9,r8
  40ea3b:	jb     40e9e0 <__swc_fn_585f006d_000068_557d6092+0x180>
  40ea3d:	mov    rcx,rdi
  40ea40:	mov    rdi,rax
  40ea43:	call   407630 <__swc_fn_585f006d_000021_fe13ecad>
  40ea48:	test   rdi,rdi
  40ea4b:	jne    40e9d0 <__swc_fn_585f006d_000068_557d6092+0x170>
  40ea51:	mov    QWORD PTR [r12+0x18],0x0
  40ea5a:	mov    QWORD PTR [r12+0x28],0x0
  40ea63:	mov    rcx,rsi
  40ea66:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  40ea6b:	mov    esi,0x8
  40ea70:	xor    edi,edi
  40ea72:	test   rsi,rsi
  40ea75:	je     40ead2 <__swc_fn_585f006d_000068_557d6092+0x272>
  40ea7b:	nop    DWORD PTR [rax+rax*1+0x0]
  40ea80:	lea    r13,[rdi*8+0x0]
  40ea88:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40ea8d:	test   r14,r14
  40ea90:	je     40eac8 <__swc_fn_585f006d_000068_557d6092+0x268>
  40ea92:	cs nop WORD PTR [rax+rax*1+0x0]
  40ea9c:	nop    DWORD PTR [rax+0x0]
  40eaa0:	mov    rcx,r12
  40eaa3:	mov    rdx,r14
  40eaa6:	call   407df0 <__swc_fn_585f006d_000054_1dfec8f6>
  40eaab:	mov    rcx,r12
  40eaae:	mov    rdx,QWORD PTR [r14]
  40eab1:	mov    r8,QWORD PTR [r14+0x8]
  40eab5:	mov    r9,QWORD PTR [r14+0x10]
  40eab9:	call   407750 <__swc_fn_585f006d_000039_05a50673>
  40eabe:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40eac3:	test   r14,r14
  40eac6:	jne    40eaa0 <__swc_fn_585f006d_000068_557d6092+0x240>
  40eac8:	add    rdi,0x1
  40eacc:	sub    rsi,0x1
  40ead0:	jne    40ea80 <__swc_fn_585f006d_000068_557d6092+0x220>
  40ead2:	mov    rcx,r12
  40ead5:	call   407ec0 <__swc_fn_585f006d_000060_9d59636e>
  40eada:	lea    rcx,[r12+0x250]
  40eae2:	mov    rdx,QWORD PTR [rcx]
  40eae5:	mov    r8,QWORD PTR [r12+0x250]
  40eaed:	nop    DWORD PTR [rax]
  40eaf0:	mov    r9,r8
  40eaf3:	sub    r9,rdx
  40eaf6:	mov    rax,r8
  40eaf9:	lock cmpxchg QWORD PTR [rcx],r9
  40eafe:	cmp    rax,r8
  40eb01:	je     40eb08 <__swc_fn_585f006d_000068_557d6092+0x2a8>
  40eb03:	mov    r8,rax
  40eb06:	jmp    40eaf0 <__swc_fn_585f006d_000068_557d6092+0x290>
  40eb08:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40eb11:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40eb1a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40eb23:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40eb2c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40eb35:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40eb3e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40eb47:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40eb50:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40eb59:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40eb62:	add    rsp,0x190
  40eb69:	pop    r14
  40eb6b:	pop    r13
  40eb6d:	pop    rsi
  40eb6e:	pop    rdi
  40eb6f:	pop    r12
  40eb71:	ret
	...

000000000040eb80 <__swc_fn_585f006d_000071_7e144e9b>:
  40eb80:	sub    rsp,0x8
  40eb84:	mov    QWORD PTR [rdx+0x40],0x0
  40eb8c:	call   40b890 <__swc_fn_585f006d_000064_6905bec4>
  40eb91:	add    rsp,0x8
  40eb95:	ret
	...

000000000040eba0 <__swc_fn_585f006d_000074_9eaf4878>:
  40eba0:	sub    rsp,0x8
  40eba4:	call   407f90 <__swc_fn_585f006d_000066_77c6e829>
  40eba9:	add    rsp,0x8
  40ebad:	ret
	...

000000000040ebb0 <__swc_fn_585f006d_000077_e793b5e1>:
  40ebb0:	push   rbx
  40ebb1:	push   rsi
  40ebb2:	push   rdi
  40ebb3:	push   r12
  40ebb5:	push   r13
  40ebb7:	push   r14
  40ebb9:	push   r15
  40ebbb:	sub    rsp,0x20
  40ebbf:	mov    rbx,r11
  40ebc2:	mov    rsi,rcx
  40ebc5:	mov    rdi,rdx
  40ebc8:	mov    r12,r8
  40ebcb:	mov    r13,r9
  40ebce:	mov    r14,r10
  40ebd1:	mov    rcx,QWORD PTR [rip+0x17168]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40ebd8:	test   rcx,rcx
  40ebdb:	jne    40ebed <__swc_fn_585f006d_000077_e793b5e1+0x3d>
  40ebdd:	call   40a1a0 <__swc_fn_585f006d_000165_e09accff>
  40ebe2:	lea    rcx,[rax+0x1]
  40ebe6:	mov    QWORD PTR [rip+0x17153],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40ebed:	dec    rcx
  40ebf0:	call   411aa0 <__swc_fn_585f006d_000167_3130645d>
  40ebf5:	mov    r15,rax
  40ebf8:	lea    r11,[rip+0x14641]        # 423240 <__swc_bss_base_585f006d+0x200>
  40ebff:	mov    rcx,r11
  40ec02:	call   407740 <__swc_fn_585f006d_000036_62160bb3>
  40ec07:	test   al,al
  40ec09:	jne    40ec1a <__swc_fn_585f006d_000077_e793b5e1+0x6a>
  40ec0b:	mov    rcx,r11
  40ec0e:	call   40aa40 <__swc_fn_585f006d_000034_c72914a2>
  40ec13:	lea    r11,[rip+0x14626]        # 423240 <__swc_bss_base_585f006d+0x200>
  40ec1a:	mov    rcx,r11
  40ec1d:	mov    rdx,rsi
  40ec20:	mov    r8,rdi
  40ec23:	mov    r9,r12
  40ec26:	mov    r10,r13
  40ec29:	mov    rsi,r11
  40ec2c:	mov    r11,r14
  40ec2f:	call   40ded0 <__swc_fn_585f006d_000035_6105596e>
  40ec34:	test   bl,bl
  40ec36:	je     40ec5d <__swc_fn_585f006d_000077_e793b5e1+0xad>
  40ec38:	mov    QWORD PTR [rsp+0x8],rsi
  40ec3d:	lea    rax,[rip+0x350c]        # 412150 <__swc_rdata_base_585f006d+0x40>
  40ec44:	mov    QWORD PTR [rsp+0x10],rax
  40ec49:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ec4f:	vmovups XMMWORD PTR [r15],xmm0
  40ec54:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40ec5d:	mov    rax,rsi
  40ec60:	add    rsp,0x20
  40ec64:	pop    r15
  40ec66:	pop    r14
  40ec68:	pop    r13
  40ec6a:	pop    r12
  40ec6c:	pop    rdi
  40ec6d:	pop    rsi
  40ec6e:	pop    rbx
  40ec6f:	ret

000000000040ec70 <__swc_fn_585f006d_000080_851c599a>:
  40ec70:	sub    rsp,0x8
  40ec74:	mov    rax,rcx
  40ec77:	test   rcx,rcx
  40ec7a:	jne    40ec81 <__swc_fn_585f006d_000080_851c599a+0x11>
  40ec7c:	add    rsp,0x8
  40ec80:	ret
  40ec81:	lea    rcx,[rax-0x10]
  40ec85:	mov    rax,QWORD PTR [rax-0x10]
  40ec89:	mov    rdx,rax
  40ec8c:	call   40fcd0 <__swc_fn_585f006d_000113_25e345b1>
  40ec91:	add    rsp,0x8
  40ec95:	ret
	...

000000000040eca0 <__swc_fn_585f006d_000083_fb84e43e>:
  40eca0:	sub    rsp,0x8
  40eca4:	xor    r11d,r11d
  40eca7:	call   408250 <__swc_fn_585f006d_000084_746bf146>
  40ecac:	add    rsp,0x8
  40ecb0:	ret
	...

000000000040ecc0 <__swc_fn_585f006d_000086_ac8c6565>:
  40ecc0:	push   rsi
  40ecc1:	push   rdi
  40ecc2:	push   r12
  40ecc4:	push   r13
  40ecc6:	push   r14
  40ecc8:	push   r15
  40ecca:	sub    rsp,0x68
  40ecce:	mov    rsi,r9
  40ecd1:	mov    rdi,rcx
  40ecd4:	mov    r12,rdx
  40ecd7:	mov    r13,r8
  40ecda:	cmp    r8,r9
  40ecdd:	jne    40ed05 <__swc_fn_585f006d_000086_ac8c6565+0x45>
  40ecdf:	mov    rcx,rdi
  40ece2:	mov    rdx,r12
  40ece5:	xor    r8d,r8d
  40ece8:	call   4085a0 <__swc_fn_585f006d_000090_9a1d717d>
  40eced:	test   al,al
  40ecef:	je     40ed05 <__swc_fn_585f006d_000086_ac8c6565+0x45>
  40ecf1:	mov    eax,0x1
  40ecf6:	add    rsp,0x68
  40ecfa:	pop    r15
  40ecfc:	pop    r14
  40ecfe:	pop    r13
  40ed00:	pop    r12
  40ed02:	pop    rdi
  40ed03:	pop    rsi
  40ed04:	ret
  40ed05:	cmp    BYTE PTR [r12+0x2c],0xe
  40ed0b:	je     40ed1e <__swc_fn_585f006d_000086_ac8c6565+0x5e>
  40ed0d:	xor    eax,eax
  40ed0f:	add    rsp,0x68
  40ed13:	pop    r15
  40ed15:	pop    r14
  40ed17:	pop    r13
  40ed19:	pop    r12
  40ed1b:	pop    rdi
  40ed1c:	pop    rsi
  40ed1d:	ret
  40ed1e:	mov    r14,QWORD PTR [r12+0x98]
  40ed26:	mov    rax,QWORD PTR [r12+0xa0]
  40ed2e:	mov    r12,rax
  40ed31:	xor    r15d,r15d
  40ed34:	test   r12,r12
  40ed37:	je     40ed9f <__swc_fn_585f006d_000086_ac8c6565+0xdf>
  40ed39:	nop    DWORD PTR [rax+0x0]
  40ed40:	mov    QWORD PTR [rsp+0x58],r12
  40ed45:	lea    r12,[r15*8+0x0]
  40ed4d:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40ed52:	mov    rcx,rax
  40ed55:	call   40c020 <__swc_fn_585f006d_000082_9f4f5092>
  40ed5a:	cmp    BYTE PTR [rax+0x2c],0xe
  40ed5e:	jne    40ed90 <__swc_fn_585f006d_000086_ac8c6565+0xd0>
  40ed60:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40ed65:	lea    r8,[r13+rcx*1+0x0]
  40ed6a:	mov    rcx,rdi
  40ed6d:	mov    rdx,rax
  40ed70:	mov    r9,rsi
  40ed73:	call   40ecc0 <__swc_fn_585f006d_000086_ac8c6565>
  40ed78:	test   al,al
  40ed7a:	je     40ed90 <__swc_fn_585f006d_000086_ac8c6565+0xd0>
  40ed7c:	mov    eax,0x1
  40ed81:	add    rsp,0x68
  40ed85:	pop    r15
  40ed87:	pop    r14
  40ed89:	pop    r13
  40ed8b:	pop    r12
  40ed8d:	pop    rdi
  40ed8e:	pop    rsi
  40ed8f:	ret
  40ed90:	add    r15,0x1
  40ed94:	mov    r12,QWORD PTR [rsp+0x58]
  40ed99:	sub    r12,0x1
  40ed9d:	jne    40ed40 <__swc_fn_585f006d_000086_ac8c6565+0x80>
  40ed9f:	xor    eax,eax
  40eda1:	add    rsp,0x68
  40eda5:	pop    r15
  40eda7:	pop    r14
  40eda9:	pop    r13
  40edab:	pop    r12
  40edad:	pop    rdi
  40edae:	pop    rsi
  40edaf:	ret

000000000040edb0 <__swc_fn_585f006d_000089_157b05de>:
  40edb0:	push   rbp
  40edb1:	push   rbx
  40edb2:	push   rsi
  40edb3:	push   rdi
  40edb4:	push   r12
  40edb6:	push   r13
  40edb8:	push   r14
  40edba:	push   r15
  40edbc:	sub    rsp,0x38
  40edc0:	mov    rbp,rsp
  40edc3:	mov    rbx,r11
  40edc6:	mov    rsi,rdx
  40edc9:	mov    rdi,r8
  40edcc:	mov    r12,r9
  40edcf:	mov    QWORD PTR [rsp+0x18],r9
  40edd4:	mov    r13,r10
  40edd7:	movzx  r14d,BYTE PTR [rbp+0x80]
  40eddf:	movzx  r15d,BYTE PTR [rbp+0x88]
  40ede7:	test   r11,r11
  40edea:	je     40edf0 <__swc_fn_585f006d_000089_157b05de+0x40>
  40edec:	xor    eax,eax
  40edee:	mov    BYTE PTR [rbx],al
  40edf0:	test   r12,r12
  40edf3:	je     40edfe <__swc_fn_585f006d_000089_157b05de+0x4e>
  40edf5:	mov    QWORD PTR [r12+0x8],0x0
  40edfe:	test   rcx,rcx
  40ee01:	je     40ee08 <__swc_fn_585f006d_000089_157b05de+0x58>
  40ee03:	test   rsi,rsi
  40ee06:	jne    40ee1b <__swc_fn_585f006d_000089_157b05de+0x6b>
  40ee08:	xor    eax,eax
  40ee0a:	add    rsp,0x38
  40ee0e:	pop    r15
  40ee10:	pop    r14
  40ee12:	pop    r13
  40ee14:	pop    r12
  40ee16:	pop    rdi
  40ee17:	pop    rsi
  40ee18:	pop    rbx
  40ee19:	pop    rbp
  40ee1a:	ret
  40ee1b:	call   40c020 <__swc_fn_585f006d_000082_9f4f5092>
  40ee20:	mov    r12,rax
  40ee23:	mov    al,r15b
  40ee26:	test   r15b,r15b
  40ee29:	jne    40ee39 <__swc_fn_585f006d_000089_157b05de+0x89>
  40ee2b:	mov    eax,DWORD PTR [r12+0x28]
  40ee30:	and    eax,0x10000
  40ee36:	setne  al
  40ee39:	lea    r15,[rsp+0x8]
  40ee3e:	mov    QWORD PTR [rsp+0x20],r15
  40ee43:	rex mov BYTE PTR [rsp+0x8],al
  40ee48:	test   DWORD PTR [rsi+0x28],0x400000
  40ee4f:	je     40ee87 <__swc_fn_585f006d_000089_157b05de+0xd7>
  40ee51:	test   rsi,rsi
  40ee54:	je     40ee74 <__swc_fn_585f006d_000089_157b05de+0xc4>
  40ee56:	mov    rax,QWORD PTR [rsi+0x38]
  40ee5a:	cmp    QWORD PTR [rax+0x10],rsi
  40ee5e:	jne    40ee74 <__swc_fn_585f006d_000089_157b05de+0xc4>
  40ee60:	rex mov al,BYTE PTR [rsp+0x8]
  40ee65:	test   al,al
  40ee67:	sete   al
  40ee6a:	test   r14b,r14b
  40ee6d:	sete   cl
  40ee70:	test   al,cl
  40ee72:	je     40ee87 <__swc_fn_585f006d_000089_157b05de+0xd7>
  40ee74:	xor    eax,eax
  40ee76:	add    rsp,0x38
  40ee7a:	pop    r15
  40ee7c:	pop    r14
  40ee7e:	pop    r13
  40ee80:	pop    r12
  40ee82:	pop    rdi
  40ee83:	pop    rsi
  40ee84:	pop    rbx
  40ee85:	pop    rbp
  40ee86:	ret
  40ee87:	mov    r15,r12
  40ee8a:	test   r14b,r14b
  40ee8d:	jne    40eea4 <__swc_fn_585f006d_000089_157b05de+0xf4>
  40ee8f:	cmp    BYTE PTR [r12+0x2c],0x6
  40ee95:	jne    40eea4 <__swc_fn_585f006d_000089_157b05de+0xf4>
  40ee97:	mov    rcx,QWORD PTR [r12+0x40]
  40ee9c:	call   40c020 <__swc_fn_585f006d_000082_9f4f5092>
  40eea1:	mov    r15,rax
  40eea4:	test   r14b,r14b
  40eea7:	je     40eead <__swc_fn_585f006d_000089_157b05de+0xfd>
  40eea9:	mov    r15,QWORD PTR [r15+0x30]
  40eead:	mov    rcx,rsi
  40eeb0:	call   40c020 <__swc_fn_585f006d_000082_9f4f5092>
  40eeb5:	mov    rsi,rax
  40eeb8:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40eebd:	je     40eef4 <__swc_fn_585f006d_000089_157b05de+0x144>
  40eebf:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40eec4:	je     40eef4 <__swc_fn_585f006d_000089_157b05de+0x144>
  40eec6:	mov    eax,DWORD PTR [rsi+0x28]
  40eec9:	and    eax,0x10000
  40eecf:	je     40eef4 <__swc_fn_585f006d_000089_157b05de+0x144>
  40eed1:	rex mov al,BYTE PTR [rsp+0x8]
  40eed6:	test   al,al
  40eed8:	jne    40eeed <__swc_fn_585f006d_000089_157b05de+0x13d>
  40eeda:	xor    eax,eax
  40eedc:	add    rsp,0x38
  40eee0:	pop    r15
  40eee2:	pop    r14
  40eee4:	pop    r13
  40eee6:	pop    r12
  40eee8:	pop    rdi
  40eee9:	pop    rsi
  40eeea:	pop    rbx
  40eeeb:	pop    rbp
  40eeec:	ret
  40eeed:	mov    rax,QWORD PTR [rsi+0x30]
  40eef1:	mov    rsi,rax
  40eef4:	mov    r14b,r13b
  40eef7:	test   rbx,rbx
  40eefa:	je     40ef30 <__swc_fn_585f006d_000089_157b05de+0x180>
  40eefc:	cmp    BYTE PTR [r12+0x2c],0x6
  40ef02:	jne    40ef30 <__swc_fn_585f006d_000089_157b05de+0x180>
  40ef04:	lea    rdx,[rip+0x3275]        # 412180 <__swc_rdata_base_585f006d+0x70>
  40ef0b:	mov    rcx,rsi
  40ef0e:	xor    r8d,r8d
  40ef11:	call   4085a0 <__swc_fn_585f006d_000090_9a1d717d>
  40ef16:	test   al,al
  40ef18:	je     40ef30 <__swc_fn_585f006d_000089_157b05de+0x180>
  40ef1a:	mov    BYTE PTR [rbx],0x1
  40ef1d:	xor    eax,eax
  40ef1f:	add    rsp,0x38
  40ef23:	pop    r15
  40ef25:	pop    r14
  40ef27:	pop    r13
  40ef29:	pop    r12
  40ef2b:	pop    rdi
  40ef2c:	pop    rsi
  40ef2d:	pop    rbx
  40ef2e:	pop    rbp
  40ef2f:	ret
  40ef30:	test   rdi,rdi
  40ef33:	jne    40ef4d <__swc_fn_585f006d_000089_157b05de+0x19d>
  40ef35:	test   r13b,r13b
  40ef38:	jne    40ef4d <__swc_fn_585f006d_000089_157b05de+0x19d>
  40ef3a:	xor    eax,eax
  40ef3c:	add    rsp,0x38
  40ef40:	pop    r15
  40ef42:	pop    r14
  40ef44:	pop    r13
  40ef46:	pop    r12
  40ef48:	pop    rdi
  40ef49:	pop    rsi
  40ef4a:	pop    rbx
  40ef4b:	pop    rbp
  40ef4c:	ret
  40ef4d:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40ef52:	jne    40f008 <__swc_fn_585f006d_000089_157b05de+0x258>
  40ef58:	mov    rcx,r15
  40ef5b:	mov    rdx,rsi
  40ef5e:	xor    r8d,r8d
  40ef61:	call   4085a0 <__swc_fn_585f006d_000090_9a1d717d>
  40ef66:	test   al,al
  40ef68:	jne    40f008 <__swc_fn_585f006d_000089_157b05de+0x258>
  40ef6e:	test   DWORD PTR [rsi+0x28],0x10000
  40ef75:	je     40ef93 <__swc_fn_585f006d_000089_157b05de+0x1e3>
  40ef77:	rex mov al,BYTE PTR [rsp+0x8]
  40ef7c:	test   al,al
  40ef7e:	jne    40ef93 <__swc_fn_585f006d_000089_157b05de+0x1e3>
  40ef80:	xor    eax,eax
  40ef82:	add    rsp,0x38
  40ef86:	pop    r15
  40ef88:	pop    r14
  40ef8a:	pop    r13
  40ef8c:	pop    r12
  40ef8e:	pop    rdi
  40ef8f:	pop    rsi
  40ef90:	pop    rbx
  40ef91:	pop    rbp
  40ef92:	ret
  40ef93:	test   rdi,rdi
  40ef96:	jne    40efab <__swc_fn_585f006d_000089_157b05de+0x1fb>
  40ef98:	xor    eax,eax
  40ef9a:	add    rsp,0x38
  40ef9e:	pop    r15
  40efa0:	pop    r14
  40efa2:	pop    r13
  40efa4:	pop    r12
  40efa6:	pop    rdi
  40efa7:	pop    rsi
  40efa8:	pop    rbx
  40efa9:	pop    rbp
  40efaa:	ret
  40efab:	mov    rcx,QWORD PTR [rsi+0x40]
  40efaf:	call   40c020 <__swc_fn_585f006d_000082_9f4f5092>
  40efb4:	mov    rsi,rax
  40efb7:	mov    rax,QWORD PTR [rdi]
  40efba:	mov    rdi,rax
  40efbd:	test   rax,rax
  40efc0:	jne    40f003 <__swc_fn_585f006d_000089_157b05de+0x253>
  40efc2:	test   rbx,rbx
  40efc5:	je     40f003 <__swc_fn_585f006d_000089_157b05de+0x253>
  40efc7:	mov    rcx,r15
  40efca:	mov    rdx,rsi
  40efcd:	xor    r8d,r8d
  40efd0:	call   4085a0 <__swc_fn_585f006d_000090_9a1d717d>
  40efd5:	mov    rcx,rax
  40efd8:	test   al,al
  40efda:	jne    40effc <__swc_fn_585f006d_000089_157b05de+0x24c>
  40efdc:	mov    rcx,r15
  40efdf:	mov    rdx,rsi
  40efe2:	call   40c060 <__swc_fn_585f006d_000085_88128f21>
  40efe7:	mov    rcx,rax
  40efea:	test   al,al
  40efec:	jne    40effc <__swc_fn_585f006d_000089_157b05de+0x24c>
  40efee:	mov    rcx,rsi
  40eff1:	mov    rdx,r15
  40eff4:	call   40c060 <__swc_fn_585f006d_000085_88128f21>
  40eff9:	mov    rcx,rax
  40effc:	test   cl,cl
  40effe:	setne  al
  40f001:	mov    BYTE PTR [rbx],al
  40f003:	xor    eax,eax
  40f005:	mov    r14b,al
  40f008:	test   rdi,rdi
  40f00b:	jne    40f025 <__swc_fn_585f006d_000089_157b05de+0x275>
  40f00d:	test   r14b,r14b
  40f010:	jne    40f025 <__swc_fn_585f006d_000089_157b05de+0x275>
  40f012:	xor    eax,eax
  40f014:	add    rsp,0x38
  40f018:	pop    r15
  40f01a:	pop    r14
  40f01c:	pop    r13
  40f01e:	pop    r12
  40f020:	pop    rdi
  40f021:	pop    rsi
  40f022:	pop    rbx
  40f023:	pop    rbp
  40f024:	ret
  40f025:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f02a:	je     40f036 <__swc_fn_585f006d_000089_157b05de+0x286>
  40f02c:	mov    r12,QWORD PTR [rsp+0x18]
  40f031:	jmp    40f0be <__swc_fn_585f006d_000089_157b05de+0x30e>
  40f036:	mov    r12,QWORD PTR [rsp+0x18]
  40f03b:	test   r12,r12
  40f03e:	jne    40f052 <__swc_fn_585f006d_000089_157b05de+0x2a2>
  40f040:	mov    rcx,r15
  40f043:	mov    rdx,rsi
  40f046:	xor    r8d,r8d
  40f049:	call   4085a0 <__swc_fn_585f006d_000090_9a1d717d>
  40f04e:	test   al,al
  40f050:	jne    40f0be <__swc_fn_585f006d_000089_157b05de+0x30e>
  40f052:	test   DWORD PTR [rsi+0x28],0x10000
  40f059:	je     40f077 <__swc_fn_585f006d_000089_157b05de+0x2c7>
  40f05b:	rex mov al,BYTE PTR [rsp+0x8]
  40f060:	test   al,al
  40f062:	jne    40f077 <__swc_fn_585f006d_000089_157b05de+0x2c7>
  40f064:	xor    eax,eax
  40f066:	add    rsp,0x38
  40f06a:	pop    r15
  40f06c:	pop    r14
  40f06e:	pop    r13
  40f070:	pop    r12
  40f072:	pop    rdi
  40f073:	pop    rsi
  40f074:	pop    rbx
  40f075:	pop    rbp
  40f076:	ret
  40f077:	test   rdi,rdi
  40f07a:	jne    40f08f <__swc_fn_585f006d_000089_157b05de+0x2df>
  40f07c:	xor    eax,eax
  40f07e:	add    rsp,0x38
  40f082:	pop    r15
  40f084:	pop    r14
  40f086:	pop    r13
  40f088:	pop    r12
  40f08a:	pop    rdi
  40f08b:	pop    rsi
  40f08c:	pop    rbx
  40f08d:	pop    rbp
  40f08e:	ret
  40f08f:	cmp    QWORD PTR [rdi+0x8],0x0
  40f094:	jne    40f0a9 <__swc_fn_585f006d_000089_157b05de+0x2f9>
  40f096:	xor    eax,eax
  40f098:	add    rsp,0x38
  40f09c:	pop    r15
  40f09e:	pop    r14
  40f0a0:	pop    r13
  40f0a2:	pop    r12
  40f0a4:	pop    rdi
  40f0a5:	pop    rsi
  40f0a6:	pop    rbx
  40f0a7:	pop    rbp
  40f0a8:	ret
  40f0a9:	mov    rax,QWORD PTR [rdi+0x8]
  40f0ad:	mov    rax,QWORD PTR [rax]
  40f0b0:	mov    rsi,rax
  40f0b3:	mov    rdi,QWORD PTR [rdi]
  40f0b6:	mov    eax,0x1
  40f0bb:	mov    r14b,al
  40f0be:	test   rdi,rdi
  40f0c1:	mov    rbx,QWORD PTR [rsp+0x20]
  40f0c6:	jne    40f110 <__swc_fn_585f006d_000089_157b05de+0x360>
  40f0c8:	test   r14b,r14b
  40f0cb:	je     40f0fd <__swc_fn_585f006d_000089_157b05de+0x34d>
  40f0cd:	test   r12,r12
  40f0d0:	je     40f0fd <__swc_fn_585f006d_000089_157b05de+0x34d>
  40f0d2:	mov    rcx,r15
  40f0d5:	mov    rdx,rsi
  40f0d8:	xor    r8d,r8d
  40f0db:	mov    r9,r12
  40f0de:	mov    rbx,QWORD PTR [rsp+0x20]
  40f0e3:	movzx  r10d,BYTE PTR [rbx]
  40f0e7:	call   40eca0 <__swc_fn_585f006d_000083_fb84e43e>
  40f0ec:	add    rsp,0x38
  40f0f0:	pop    r15
  40f0f2:	pop    r14
  40f0f4:	pop    r13
  40f0f6:	pop    r12
  40f0f8:	pop    rdi
  40f0f9:	pop    rsi
  40f0fa:	pop    rbx
  40f0fb:	pop    rbp
  40f0fc:	ret
  40f0fd:	xor    eax,eax
  40f0ff:	add    rsp,0x38
  40f103:	pop    r15
  40f105:	pop    r14
  40f107:	pop    r13
  40f109:	pop    r12
  40f10b:	pop    rdi
  40f10c:	pop    rsi
  40f10d:	pop    rbx
  40f10e:	pop    rbp
  40f10f:	ret
  40f110:	mov    r13,rsi
  40f113:	mov    QWORD PTR [rsp+0x28],rdi
  40f118:	cmp    BYTE PTR [r15+0x2c],0xe
  40f11d:	sete   al
  40f120:	mov    r14b,al
  40f123:	jne    40f137 <__swc_fn_585f006d_000089_157b05de+0x387>
  40f125:	mov    rcx,rsi
  40f128:	mov    rdx,r15
  40f12b:	call   40c060 <__swc_fn_585f006d_000085_88128f21>
  40f130:	mov    r14b,al
  40f133:	test   al,al
  40f135:	jne    40f16c <__swc_fn_585f006d_000089_157b05de+0x3bc>
  40f137:	cmp    BYTE PTR [r15+0x2c],0x12
  40f13c:	je     40f16c <__swc_fn_585f006d_000089_157b05de+0x3bc>
  40f13e:	mov    rcx,r15
  40f141:	mov    rdx,rsi
  40f144:	mov    r8,rdi
  40f147:	mov    r9,r12
  40f14a:	mov    rax,rbx
  40f14d:	movzx  r10d,BYTE PTR [rax]
  40f151:	call   40eca0 <__swc_fn_585f006d_000083_fb84e43e>
  40f156:	test   rax,rax
  40f159:	je     40f16c <__swc_fn_585f006d_000089_157b05de+0x3bc>
  40f15b:	add    rsp,0x38
  40f15f:	pop    r15
  40f161:	pop    r14
  40f163:	pop    r13
  40f165:	pop    r12
  40f167:	pop    rdi
  40f168:	pop    rsi
  40f169:	pop    rbx
  40f16a:	pop    rbp
  40f16b:	ret
  40f16c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40f171:	jne    40f190 <__swc_fn_585f006d_000089_157b05de+0x3e0>
  40f173:	mov    rax,QWORD PTR [rsi+0xd8]
  40f17a:	test   rax,rax
  40f17d:	je     40f190 <__swc_fn_585f006d_000089_157b05de+0x3e0>
  40f17f:	add    rdi,QWORD PTR [rax+0x8]
  40f183:	mov    rax,QWORD PTR [rdi]
  40f186:	sub    rdi,QWORD PTR [rax+0x8]
  40f18a:	mov    rax,QWORD PTR [rax]
  40f18d:	mov    rsi,rax
  40f190:	test   r14b,r14b
  40f193:	je     40f1bf <__swc_fn_585f006d_000089_157b05de+0x40f>
  40f195:	mov    rcx,r15
  40f198:	mov    rdx,rsi
  40f19b:	mov    r8,rdi
  40f19e:	mov    r9,r13
  40f1a1:	mov    r14,QWORD PTR [rsp+0x28]
  40f1a6:	mov    r10,r14
  40f1a9:	call   408480 <__swc_fn_585f006d_000087_1fb4fcfe>
  40f1ae:	add    rsp,0x38
  40f1b2:	pop    r15
  40f1b4:	pop    r14
  40f1b6:	pop    r13
  40f1b8:	pop    r12
  40f1ba:	pop    rdi
  40f1bb:	pop    rsi
  40f1bc:	pop    rbx
  40f1bd:	pop    rbp
  40f1be:	ret
  40f1bf:	mov    rcx,r15
  40f1c2:	mov    rdx,rsi
  40f1c5:	mov    r8,rdi
  40f1c8:	mov    r9,r12
  40f1cb:	movzx  r10d,BYTE PTR [rbx]
  40f1cf:	call   40eca0 <__swc_fn_585f006d_000083_fb84e43e>
  40f1d4:	add    rsp,0x38
  40f1d8:	pop    r15
  40f1da:	pop    r14
  40f1dc:	pop    r13
  40f1de:	pop    r12
  40f1e0:	pop    rdi
  40f1e1:	pop    rsi
  40f1e2:	pop    rbx
  40f1e3:	pop    rbp
  40f1e4:	ret
	...

000000000040f1f0 <__swc_fn_585f006d_000092_17e20532>:
  40f1f0:	push   rbx
  40f1f1:	push   rsi
  40f1f2:	sub    rsp,0x18
  40f1f6:	mov    rbx,rcx
  40f1f9:	mov    rcx,QWORD PTR [rip+0x16b40]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40f200:	test   rcx,rcx
  40f203:	jne    40f215 <__swc_fn_585f006d_000092_17e20532+0x25>
  40f205:	call   40a1a0 <__swc_fn_585f006d_000165_e09accff>
  40f20a:	lea    rcx,[rax+0x1]
  40f20e:	mov    QWORD PTR [rip+0x16b2b],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40f215:	dec    rcx
  40f218:	call   411aa0 <__swc_fn_585f006d_000167_3130645d>
  40f21d:	mov    rsi,rax
  40f220:	mov    rax,QWORD PTR [rsi+0x8]
  40f224:	test   rax,rax
  40f227:	jne    40f277 <__swc_fn_585f006d_000092_17e20532+0x87>
  40f229:	call   40c150 <__swc_fn_585f006d_000091_e6773530>
  40f22e:	test   al,al
  40f230:	jne    40f277 <__swc_fn_585f006d_000092_17e20532+0x87>
  40f232:	lea    rdx,[rip+0x14007]        # 423240 <__swc_bss_base_585f006d+0x200>
  40f239:	mov    rcx,rdx
  40f23c:	call   407740 <__swc_fn_585f006d_000036_62160bb3>
  40f241:	test   al,al
  40f243:	jne    40f254 <__swc_fn_585f006d_000092_17e20532+0x64>
  40f245:	mov    rcx,rdx
  40f248:	call   40aa40 <__swc_fn_585f006d_000034_c72914a2>
  40f24d:	lea    rdx,[rip+0x13fec]        # 423240 <__swc_bss_base_585f006d+0x200>
  40f254:	mov    QWORD PTR [rsp+0x8],rdx
  40f259:	lea    rax,[rip+0x2ef0]        # 412150 <__swc_rdata_base_585f006d+0x40>
  40f260:	mov    QWORD PTR [rsp+0x10],rax
  40f265:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f26b:	vmovups XMMWORD PTR [rsi],xmm0
  40f26f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40f277:	vmovups xmm0,XMMWORD PTR [rsi]
  40f27b:	vmovups XMMWORD PTR [rbx],xmm0
  40f27f:	mov    rax,rbx
  40f282:	add    rsp,0x18
  40f286:	pop    rsi
  40f287:	pop    rbx
  40f288:	ret
  40f289:	add    BYTE PTR [rax],al
  40f28b:	add    BYTE PTR [rax],al
  40f28d:	add    BYTE PTR [rax],al
	...

000000000040f290 <__swc_fn_585f006d_000095_a3245f7e>:
  40f290:	sub    rsp,0x8
  40f294:	call   409340 <__swc_fn_585f006d_000117_76ff2f0a>
  40f299:	add    rsp,0x8
  40f29d:	ret
	...

000000000040f2a0 <__swc_fn_585f006d_000098_d9d80f1a>:
  40f2a0:	push   rbx
  40f2a1:	push   rsi
  40f2a2:	sub    rsp,0x28
  40f2a6:	mov    rbx,rcx
  40f2a9:	xor    esi,esi
  40f2ab:	jmp    40f2c0 <__swc_fn_585f006d_000098_d9d80f1a+0x20>
  40f2ad:	nop    DWORD PTR [rax]
  40f2b0:	mov    QWORD PTR [rbx+0x28],rsi
  40f2b4:	mov    rsi,rbx
  40f2b7:	mov    rbx,rax
  40f2ba:	nop    WORD PTR [rax+rax*1+0x0]
  40f2c0:	test   rbx,rbx
  40f2c3:	je     40f323 <__swc_fn_585f006d_000098_d9d80f1a+0x83>
  40f2c5:	mov    rcx,rbx
  40f2c8:	mov    edx,0x1
  40f2cd:	call   408200 <__swc_fn_585f006d_000078_5a70c27a>
  40f2d2:	cmp    rax,0x1
  40f2d6:	jne    40f323 <__swc_fn_585f006d_000098_d9d80f1a+0x83>
  40f2d8:	mov    r10,QWORD PTR [rbx+0x18]
  40f2dc:	mov    rcx,r10
  40f2df:	mov    edx,0x1
  40f2e4:	call   408200 <__swc_fn_585f006d_000078_5a70c27a>
  40f2e9:	cmp    rax,0x1
  40f2ed:	jne    40f2fc <__swc_fn_585f006d_000098_d9d80f1a+0x5c>
  40f2ef:	mov    rcx,r10
  40f2f2:	call   40c2f0 <__swc_fn_585f006d_000097_8b4a07e9>
  40f2f7:	test   rax,rax
  40f2fa:	jne    40f2b0 <__swc_fn_585f006d_000098_d9d80f1a+0x10>
  40f2fc:	mov    rax,QWORD PTR [rbx+0x20]
  40f300:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40f305:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f30b:	lea    rcx,[rsp+0x8]
  40f310:	mov    rdx,rbx
  40f313:	mov    r8d,0x30
  40f319:	mov    rbx,rax
  40f31c:	call   408960 <__swc_fn_585f006d_000096_f879630a>
  40f321:	jmp    40f2c0 <__swc_fn_585f006d_000098_d9d80f1a+0x20>
  40f323:	test   rsi,rsi
  40f326:	jne    40f32f <__swc_fn_585f006d_000098_d9d80f1a+0x8f>
  40f328:	add    rsp,0x28
  40f32c:	pop    rsi
  40f32d:	pop    rbx
  40f32e:	ret
  40f32f:	mov    rax,rsi
  40f332:	mov    rsi,QWORD PTR [rsi+0x28]
  40f336:	mov    rbx,QWORD PTR [rax+0x20]
  40f33a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40f33f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f345:	lea    rcx,[rsp+0x18]
  40f34a:	mov    rdx,rax
  40f34d:	mov    r8d,0x30
  40f353:	call   408960 <__swc_fn_585f006d_000096_f879630a>
  40f358:	jmp    40f2c0 <__swc_fn_585f006d_000098_d9d80f1a+0x20>
  40f35d:	add    BYTE PTR [rax],al
	...

000000000040f360 <__swc_fn_585f006d_000101_295ddd7c>:
  40f360:	push   rbx
  40f361:	push   rsi
  40f362:	push   rdi
  40f363:	push   r12
  40f365:	push   r13
  40f367:	sub    rsp,0x20
  40f36b:	mov    rbx,rcx
  40f36e:	lea    rsi,[rcx+0x6f8]
  40f375:	mov    edi,0x4
  40f37a:	mov    r12,rsi
  40f37d:	test   rdi,rdi
  40f380:	je     40f3ca <__swc_fn_585f006d_000101_295ddd7c+0x6a>
  40f382:	cs nop WORD PTR [rax+rax*1+0x0]
  40f38c:	nop    DWORD PTR [rax+0x0]
  40f390:	mov    rcx,QWORD PTR [r12+0x10]
  40f395:	mov    QWORD PTR [r12+0x10],0x0
  40f39e:	vxorps xmm0,xmm0,xmm0
  40f3a2:	vmovups XMMWORD PTR [r12],xmm0
  40f3a8:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40f3af:	mov    DWORD PTR [r12+0x20],0x0
  40f3b8:	call   4089b0 <__swc_fn_585f006d_000099_6e0faaee>
  40f3bd:	add    r12,0x90
  40f3c4:	sub    rdi,0x1
  40f3c8:	jne    40f390 <__swc_fn_585f006d_000101_295ddd7c+0x30>
  40f3ca:	mov    rax,QWORD PTR [rbx+0x938]
  40f3d1:	mov    rdi,rax
  40f3d4:	test   rdi,rdi
  40f3d7:	je     40f431 <__swc_fn_585f006d_000101_295ddd7c+0xd1>
  40f3d9:	nop    DWORD PTR [rax+0x0]
  40f3e0:	mov    r12d,0x10
  40f3e6:	lea    r13,[rdi+0x18]
  40f3ea:	test   r12,r12
  40f3ed:	je     40f426 <__swc_fn_585f006d_000101_295ddd7c+0xc6>
  40f3ef:	nop
  40f3f0:	mov    rcx,QWORD PTR [r13+0x10]
  40f3f4:	mov    QWORD PTR [r13+0x10],0x0
  40f3fc:	vxorps xmm0,xmm0,xmm0
  40f400:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40f406:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40f40c:	mov    DWORD PTR [r13+0x20],0x0
  40f414:	call   4089b0 <__swc_fn_585f006d_000099_6e0faaee>
  40f419:	add    r13,0x90
  40f420:	sub    r12,0x1
  40f424:	jne    40f3f0 <__swc_fn_585f006d_000101_295ddd7c+0x90>
  40f426:	mov    rax,QWORD PTR [rdi]
  40f429:	mov    rdi,rax
  40f42c:	test   rax,rax
  40f42f:	jne    40f3e0 <__swc_fn_585f006d_000101_295ddd7c+0x80>
  40f431:	vxorps xmm0,xmm0,xmm0
  40f435:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40f43d:	mov    DWORD PTR [rbx+0x9b0],0x0
  40f447:	mov    DWORD PTR [rbx+0x9a8],0x0
  40f451:	mov    edi,0x4
  40f456:	mov    r12,rsi
  40f459:	lea    rsi,[rsi+0x38]
  40f45d:	test   rdi,rdi
  40f460:	je     40f48c <__swc_fn_585f006d_000101_295ddd7c+0x12c>
  40f462:	cs nop WORD PTR [rax+rax*1+0x0]
  40f46c:	nop    DWORD PTR [rax+0x0]
  40f470:	mov    rcx,rsi
  40f473:	call   40d170 <__swc_fn_585f006d_000157_5c8b11d8>
  40f478:	add    rsi,0x90
  40f47f:	add    r12,0x90
  40f486:	sub    rdi,0x1
  40f48a:	jne    40f470 <__swc_fn_585f006d_000101_295ddd7c+0x110>
  40f48c:	mov    rax,QWORD PTR [rbx+0x938]
  40f493:	mov    rdi,rax
  40f496:	mov    QWORD PTR [rbx+0x938],0x0
  40f4a1:	test   rdi,rdi
  40f4a4:	je     40f515 <__swc_fn_585f006d_000101_295ddd7c+0x1b5>
  40f4aa:	nop    WORD PTR [rax+rax*1+0x0]
  40f4b0:	mov    esi,0x10
  40f4b5:	lea    r12,[rdi+0x18]
  40f4b9:	lea    r13,[rdi+0x50]
  40f4bd:	test   rsi,rsi
  40f4c0:	je     40f4ec <__swc_fn_585f006d_000101_295ddd7c+0x18c>
  40f4c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f4cc:	nop    DWORD PTR [rax+0x0]
  40f4d0:	mov    rcx,r13
  40f4d3:	call   40d170 <__swc_fn_585f006d_000157_5c8b11d8>
  40f4d8:	add    r13,0x90
  40f4df:	add    r12,0x90
  40f4e6:	sub    rsi,0x1
  40f4ea:	jne    40f4d0 <__swc_fn_585f006d_000101_295ddd7c+0x170>
  40f4ec:	mov    rax,QWORD PTR [rdi]
  40f4ef:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40f4f4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f4fa:	lea    rcx,[rsp+0x8]
  40f4ff:	mov    rdx,rdi
  40f502:	mov    r8d,0x918
  40f508:	mov    rdi,rax
  40f50b:	call   408960 <__swc_fn_585f006d_000096_f879630a>
  40f510:	test   rdi,rdi
  40f513:	jne    40f4b0 <__swc_fn_585f006d_000101_295ddd7c+0x150>
  40f515:	lea    rcx,[rbx+0x68]
  40f519:	call   40d170 <__swc_fn_585f006d_000157_5c8b11d8>
  40f51e:	add    rsp,0x20
  40f522:	pop    r13
  40f524:	pop    r12
  40f526:	pop    rdi
  40f527:	pop    rsi
  40f528:	pop    rbx
  40f529:	ret
  40f52a:	add    BYTE PTR [rax],al
  40f52c:	add    BYTE PTR [rax],al
	...

000000000040f530 <__swc_fn_585f006d_000104_baf871f8>:
  40f530:	xor    eax,eax
  40f532:	cs nop WORD PTR [rax+rax*1+0x0]
  40f53c:	nop    DWORD PTR [rax+0x0]
  40f540:	mov    r9,r8
  40f543:	sub    r9,rax
  40f546:	cmp    r9,0x40
  40f54a:	jb     40f588 <__swc_fn_585f006d_000104_baf871f8+0x58>
  40f54c:	lea    r9,[rcx+rax*1]
  40f550:	lea    r10,[rdx+rax*1]
  40f554:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40f55a:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40f560:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40f566:	vmovups xmm3,XMMWORD PTR [r10]
  40f56b:	vmovups XMMWORD PTR [r9],xmm3
  40f570:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40f576:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40f57c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40f582:	lea    rax,[rax+0x40]
  40f586:	jmp    40f540 <__swc_fn_585f006d_000104_baf871f8+0x10>
  40f588:	nop    DWORD PTR [rax+rax*1+0x0]
  40f590:	mov    r9,r8
  40f593:	sub    r9,rax
  40f596:	cmp    r9,0x10
  40f59a:	jb     40f5b4 <__swc_fn_585f006d_000104_baf871f8+0x84>
  40f59c:	lea    r9,[rdx+rax*1]
  40f5a0:	lea    r10,[rcx+rax*1]
  40f5a4:	vmovups xmm0,XMMWORD PTR [r9]
  40f5a9:	vmovups XMMWORD PTR [r10],xmm0
  40f5ae:	lea    rax,[rax+0x10]
  40f5b2:	jmp    40f590 <__swc_fn_585f006d_000104_baf871f8+0x60>
  40f5b4:	cs nop WORD PTR [rax+rax*1+0x0]
  40f5be:	xchg   ax,ax
  40f5c0:	mov    r9,r8
  40f5c3:	sub    r9,rax
  40f5c6:	cmp    r9,0x8
  40f5ca:	jb     40f5dd <__swc_fn_585f006d_000104_baf871f8+0xad>
  40f5cc:	lea    r9,[rcx+rax*1]
  40f5d0:	mov    r10,QWORD PTR [rdx+rax*1]
  40f5d4:	mov    QWORD PTR [r9],r10
  40f5d7:	lea    rax,[rax+0x8]
  40f5db:	jmp    40f5c0 <__swc_fn_585f006d_000104_baf871f8+0x90>
  40f5dd:	cmp    rax,r8
  40f5e0:	jae    40f600 <__swc_fn_585f006d_000104_baf871f8+0xd0>
  40f5e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f5ec:	nop    DWORD PTR [rax+0x0]
  40f5f0:	mov    r9b,BYTE PTR [rdx+rax*1]
  40f5f4:	mov    BYTE PTR [rcx+rax*1],r9b
  40f5f8:	inc    rax
  40f5fb:	cmp    rax,r8
  40f5fe:	jb     40f5f0 <__swc_fn_585f006d_000104_baf871f8+0xc0>
  40f600:	ret
	...

000000000040f610 <__swc_fn_585f006d_000107_ff529476>:
  40f610:	push   rbx
  40f611:	push   r12
  40f613:	push   rdi
  40f614:	push   rsi
  40f615:	push   r13
  40f617:	push   r14
  40f619:	push   r15
  40f61b:	sub    rsp,0x170
  40f622:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40f62b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40f634:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40f63d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40f646:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40f64f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40f658:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40f661:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40f66a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40f673:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40f67c:	mov    ebx,edx
  40f67e:	mov    QWORD PTR [rsp+0xa8],rbx
  40f686:	mov    r12d,ecx
  40f689:	test   edx,edx
  40f68b:	jne    40f6a2 <__swc_fn_585f006d_000107_ff529476+0x92>
  40f68d:	xor    eax,eax
  40f68f:	add    rsp,0x170
  40f696:	pop    r15
  40f698:	pop    r14
  40f69a:	pop    r13
  40f69c:	pop    rsi
  40f69d:	pop    rdi
  40f69e:	pop    r12
  40f6a0:	pop    rbx
  40f6a1:	ret
  40f6a2:	lea    rdi,[rip+0x2e07]        # 4124b0 <__swc_rdata_base_585f006d+0x3a0>
  40f6a9:	mov    esi,0x90000
  40f6ae:	xor    eax,eax
  40f6b0:	call   407090 <open@plt>
  40f6b5:	mov    r13,rax
  40f6b8:	mov    QWORD PTR [rsp+0xb0],rax
  40f6c0:	test   eax,eax
  40f6c2:	jge    40f6cb <__swc_fn_585f006d_000107_ff529476+0xbb>
  40f6c4:	xor    eax,eax
  40f6c6:	jmp    40fbc6 <__swc_fn_585f006d_000107_ff529476+0x5b6>
  40f6cb:	nop    DWORD PTR [rax+rax*1+0x0]
  40f6d0:	movsxd rdi,r13d
  40f6d3:	mov    esi,0x2
  40f6d8:	xor    eax,eax
  40f6da:	call   407120 <flock@plt>
  40f6df:	test   eax,eax
  40f6e1:	je     40f700 <__swc_fn_585f006d_000107_ff529476+0xf0>
  40f6e3:	xor    eax,eax
  40f6e5:	call   407130 <__errno_location@plt>
  40f6ea:	cmp    DWORD PTR [rax],0x4
  40f6ed:	je     40f6d0 <__swc_fn_585f006d_000107_ff529476+0xc0>
  40f6ef:	movsxd rdi,r13d
  40f6f2:	xor    eax,eax
  40f6f4:	call   4070b0 <close@plt>
  40f6f9:	xor    eax,eax
  40f6fb:	jmp    40fbc6 <__swc_fn_585f006d_000107_ff529476+0x5b6>
  40f700:	lea    r14,[rsp+0x8]
  40f705:	mov    QWORD PTR [rsp+0xb8],r14
  40f70d:	vxorps xmm0,xmm0,xmm0
  40f711:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f717:	mov    QWORD PTR [rsp+0x18],0x0
  40f720:	mov    WORD PTR [rsp+0x20],0x0
  40f727:	mov    DWORD PTR [r14],0x67617753
  40f72e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40f736:	xor    eax,eax
  40f738:	call   407010 <getpid@plt>
  40f73d:	mov    ecx,eax
  40f73f:	mov    eax,0x1c
  40f744:	shrx   eax,ecx,eax
  40f749:	and    eax,0xf
  40f74c:	mov    rdx,QWORD PTR [rip+0x2d7d]        # 4124d0 <__swc_rdata_base_585f006d+0x3c0>
  40f753:	mov    al,BYTE PTR [rdx+rax*1]
  40f756:	rex mov BYTE PTR [rsp+0x10],al
  40f75b:	mov    eax,0x1c
  40f760:	shrx   eax,r12d,eax
  40f765:	and    eax,0xf
  40f768:	mov    al,BYTE PTR [rdx+rax*1]
  40f76b:	rex mov BYTE PTR [rsp+0x19],al
  40f770:	mov    eax,0x18
  40f775:	shrx   eax,ecx,eax
  40f77a:	and    eax,0xf
  40f77d:	mov    al,BYTE PTR [rdx+rax*1]
  40f780:	rex mov BYTE PTR [rsp+0x11],al
  40f785:	mov    eax,0x18
  40f78a:	shrx   eax,r12d,eax
  40f78f:	and    eax,0xf
  40f792:	mov    al,BYTE PTR [rdx+rax*1]
  40f795:	rex mov BYTE PTR [rsp+0x1a],al
  40f79a:	mov    eax,0x14
  40f79f:	shrx   eax,ecx,eax
  40f7a4:	and    eax,0xf
  40f7a7:	mov    al,BYTE PTR [rdx+rax*1]
  40f7aa:	rex mov BYTE PTR [rsp+0x12],al
  40f7af:	mov    eax,0x14
  40f7b4:	shrx   eax,r12d,eax
  40f7b9:	and    eax,0xf
  40f7bc:	mov    al,BYTE PTR [rdx+rax*1]
  40f7bf:	rex mov BYTE PTR [rsp+0x1b],al
  40f7c4:	mov    eax,0x10
  40f7c9:	shrx   eax,ecx,eax
  40f7ce:	and    eax,0xf
  40f7d1:	mov    al,BYTE PTR [rdx+rax*1]
  40f7d4:	rex mov BYTE PTR [rsp+0x13],al
  40f7d9:	mov    eax,0x10
  40f7de:	shrx   eax,r12d,eax
  40f7e3:	and    eax,0xf
  40f7e6:	mov    al,BYTE PTR [rdx+rax*1]
  40f7e9:	rex mov BYTE PTR [rsp+0x1c],al
  40f7ee:	mov    eax,0xc
  40f7f3:	shrx   eax,ecx,eax
  40f7f8:	and    eax,0xf
  40f7fb:	mov    al,BYTE PTR [rdx+rax*1]
  40f7fe:	rex mov BYTE PTR [rsp+0x14],al
  40f803:	mov    eax,0xc
  40f808:	shrx   eax,r12d,eax
  40f80d:	and    eax,0xf
  40f810:	mov    al,BYTE PTR [rdx+rax*1]
  40f813:	rex mov BYTE PTR [rsp+0x1d],al
  40f818:	mov    eax,0x8
  40f81d:	shrx   eax,ecx,eax
  40f822:	and    eax,0xf
  40f825:	mov    al,BYTE PTR [rdx+rax*1]
  40f828:	rex mov BYTE PTR [rsp+0x15],al
  40f82d:	mov    eax,0x8
  40f832:	shrx   eax,r12d,eax
  40f837:	and    eax,0xf
  40f83a:	mov    al,BYTE PTR [rdx+rax*1]
  40f83d:	rex mov BYTE PTR [rsp+0x1e],al
  40f842:	mov    eax,0x4
  40f847:	shrx   eax,ecx,eax
  40f84c:	and    eax,0xf
  40f84f:	mov    al,BYTE PTR [rdx+rax*1]
  40f852:	rex mov BYTE PTR [rsp+0x16],al
  40f857:	mov    eax,0x4
  40f85c:	shrx   eax,r12d,eax
  40f861:	and    eax,0xf
  40f864:	mov    al,BYTE PTR [rdx+rax*1]
  40f867:	rex mov BYTE PTR [rsp+0x1f],al
  40f86c:	xor    eax,eax
  40f86e:	shrx   eax,ecx,eax
  40f873:	and    eax,0xf
  40f876:	mov    al,BYTE PTR [rdx+rax*1]
  40f879:	rex mov BYTE PTR [rsp+0x17],al
  40f87e:	xor    eax,eax
  40f880:	shrx   eax,r12d,eax
  40f885:	and    eax,0xf
  40f888:	mov    al,BYTE PTR [rdx+rax*1]
  40f88b:	rex mov BYTE PTR [rsp+0x20],al
  40f890:	mov    BYTE PTR [r14+0x10],0x2e
  40f895:	lea    r12,[rsp+0x22]
  40f89a:	vxorps xmm0,xmm0,xmm0
  40f89e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40f8a4:	mov    DWORD PTR [r12],0x6d656d2f
  40f8ac:	mov    WORD PTR [r12+0x4],0x6466
  40f8b4:	mov    BYTE PTR [r12+0x6],0x3a
  40f8ba:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f8c0:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40f8c6:	mov    rax,QWORD PTR [rsp+0x18]
  40f8cb:	mov    QWORD PTR [rsp+0x39],rax
  40f8d0:	rex mov al,BYTE PTR [rsp+0x20]
  40f8d5:	rex mov BYTE PTR [rsp+0x41],al
  40f8da:	mov    DWORD PTR [r12+0x20],0x65642820
  40f8e3:	mov    DWORD PTR [r12+0x24],0x6574656c
  40f8ec:	mov    WORD PTR [r12+0x28],0x2964
  40f8f4:	lea    rdi,[rip+0x2bc0]        # 4124bb <__swc_rdata_base_585f006d+0x3ab>
  40f8fb:	xor    eax,eax
  40f8fd:	call   407140 <opendir@plt>
  40f902:	mov    r15,rax
  40f905:	test   rax,rax
  40f908:	jne    40f91b <__swc_fn_585f006d_000107_ff529476+0x30b>
  40f90a:	movsxd rdi,r13d
  40f90d:	xor    eax,eax
  40f90f:	call   4070b0 <close@plt>
  40f914:	xor    eax,eax
  40f916:	jmp    40fbc6 <__swc_fn_585f006d_000107_ff529476+0x5b6>
  40f91b:	mov    rdi,r15
  40f91e:	xor    eax,eax
  40f920:	call   407150 <dirfd@plt>
  40f925:	lea    r14,[rsp+0x54]
  40f92a:	mov    DWORD PTR [rsp+0x54],eax
  40f92e:	lea    rbx,[rsp+0x58]
  40f933:	cs nop WORD PTR [rax+rax*1+0x0]
  40f93d:	nop    DWORD PTR [rax]
  40f940:	mov    rdi,r15
  40f943:	xor    eax,eax
  40f945:	call   407160 <readdir@plt>
  40f94a:	test   rax,rax
  40f94d:	jne    40f964 <__swc_fn_585f006d_000107_ff529476+0x354>
  40f94f:	mov    r12,QWORD PTR [rsp+0xa8]
  40f957:	mov    r13,QWORD PTR [rsp+0xb0]
  40f95f:	jmp    40faea <__swc_fn_585f006d_000107_ff529476+0x4da>
  40f964:	vxorps xmm0,xmm0,xmm0
  40f968:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  40f96e:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  40f974:	vzeroupper
  40f977:	lea    r13,[rax+0x13]
  40f97b:	mov    rax,r14
  40f97e:	movsxd rdi,DWORD PTR [rax]
  40f981:	mov    rsi,r13
  40f984:	mov    rdx,rbx
  40f987:	mov    ecx,0x40
  40f98c:	xor    eax,eax
  40f98e:	call   407170 <readlinkat@plt>
  40f993:	cmp    rax,0x2a
  40f997:	jne    40f940 <__swc_fn_585f006d_000107_ff529476+0x330>
  40f999:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40f99f:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40f9a5:	vptest xmm0,xmm0
  40f9aa:	jne    40f9da <__swc_fn_585f006d_000107_ff529476+0x3ca>
  40f9ac:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40f9b2:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40f9b8:	vptest xmm0,xmm0
  40f9bd:	jne    40f9da <__swc_fn_585f006d_000107_ff529476+0x3ca>
  40f9bf:	mov    rcx,QWORD PTR [rsp+0x42]
  40f9c4:	cmp    QWORD PTR [rsp+0x78],rcx
  40f9c9:	jne    40f9da <__swc_fn_585f006d_000107_ff529476+0x3ca>
  40f9cb:	mov    cx,WORD PTR [rsp+0x4a]
  40f9d0:	cmp    WORD PTR [rsp+0x80],cx
  40f9d8:	je     40fa04 <__swc_fn_585f006d_000107_ff529476+0x3f4>
  40f9da:	mov    rax,rbx
  40f9dd:	mov    rcx,r12
  40f9e0:	movzx  edx,BYTE PTR [rax]
  40f9e3:	movzx  r8d,BYTE PTR [rcx]
  40f9e7:	cmp    rdx,r8
  40f9ea:	jne    40f9f6 <__swc_fn_585f006d_000107_ff529476+0x3e6>
  40f9ec:	add    rax,0x1
  40f9f0:	add    rcx,0x1
  40f9f4:	jmp    40f9e0 <__swc_fn_585f006d_000107_ff529476+0x3d0>
  40f9f6:	mov    rax,rdx
  40f9f9:	sub    rax,r8
  40f9fc:	test   eax,eax
  40f9fe:	jne    40f940 <__swc_fn_585f006d_000107_ff529476+0x330>
  40fa04:	movsxd rdi,DWORD PTR [r14]
  40fa07:	mov    rsi,r13
  40fa0a:	mov    edx,0x80002
  40fa0f:	xor    eax,eax
  40fa11:	call   407180 <openat@plt>
  40fa16:	lea    rbx,[rsp+0x98]
  40fa1e:	mov    DWORD PTR [rsp+0x98],eax
  40fa25:	test   eax,eax
  40fa27:	mov    r13,QWORD PTR [rsp+0xb0]
  40fa2f:	jge    40fa54 <__swc_fn_585f006d_000107_ff529476+0x444>
  40fa31:	mov    rdi,r15
  40fa34:	xor    eax,eax
  40fa36:	call   407190 <closedir@plt>
  40fa3b:	mov    r13,QWORD PTR [rsp+0xb0]
  40fa43:	movsxd rdi,r13d
  40fa46:	xor    eax,eax
  40fa48:	call   4070b0 <close@plt>
  40fa4d:	xor    eax,eax
  40fa4f:	jmp    40fbc6 <__swc_fn_585f006d_000107_ff529476+0x5b6>
  40fa54:	mov    rax,rbx
  40fa57:	movsxd rdi,DWORD PTR [rax]
  40fa5a:	xor    esi,esi
  40fa5c:	mov    edx,0x2
  40fa61:	xor    eax,eax
  40fa63:	call   4070a0 <lseek@plt>
  40fa68:	mov    r12,QWORD PTR [rsp+0xa8]
  40fa70:	cmp    rax,r12
  40fa73:	je     40fa9a <__swc_fn_585f006d_000107_ff529476+0x48a>
  40fa75:	movsxd rdi,DWORD PTR [rbx]
  40fa78:	xor    eax,eax
  40fa7a:	call   4070b0 <close@plt>
  40fa7f:	mov    rdi,r15
  40fa82:	xor    eax,eax
  40fa84:	call   407190 <closedir@plt>
  40fa89:	movsxd rdi,r13d
  40fa8c:	xor    eax,eax
  40fa8e:	call   4070b0 <close@plt>
  40fa93:	xor    eax,eax
  40fa95:	jmp    40fbc6 <__swc_fn_585f006d_000107_ff529476+0x5b6>
  40fa9a:	xor    edi,edi
  40fa9c:	mov    rsi,r12
  40fa9f:	mov    edx,0x3
  40faa4:	mov    ecx,0x1
  40faa9:	mov    rax,rbx
  40faac:	movsxd r8,DWORD PTR [rax]
  40faaf:	xor    r9d,r9d
  40fab2:	xor    eax,eax
  40fab4:	call   4070c0 <mmap@plt>
  40fab9:	xor    r12d,r12d
  40fabc:	cmp    rax,0xffffffffffffffff
  40fac0:	cmovne r12,rax
  40fac4:	movsxd rdi,DWORD PTR [rbx]
  40fac7:	xor    eax,eax
  40fac9:	call   4070b0 <close@plt>
  40face:	mov    rdi,r15
  40fad1:	xor    eax,eax
  40fad3:	call   407190 <closedir@plt>
  40fad8:	movsxd rdi,r13d
  40fadb:	xor    eax,eax
  40fadd:	call   4070b0 <close@plt>
  40fae2:	mov    rax,r12
  40fae5:	jmp    40fbc6 <__swc_fn_585f006d_000107_ff529476+0x5b6>
  40faea:	mov    r14,QWORD PTR [rsp+0xb8]
  40faf2:	mov    rdi,r14
  40faf5:	mov    esi,0x1
  40fafa:	xor    eax,eax
  40fafc:	call   4071a0 <memfd_create@plt>
  40fb01:	lea    rbx,[rsp+0x9c]
  40fb09:	mov    DWORD PTR [rsp+0x9c],eax
  40fb10:	test   eax,eax
  40fb12:	jge    40fb2f <__swc_fn_585f006d_000107_ff529476+0x51f>
  40fb14:	mov    rdi,r15
  40fb17:	xor    eax,eax
  40fb19:	call   407190 <closedir@plt>
  40fb1e:	movsxd rdi,r13d
  40fb21:	xor    eax,eax
  40fb23:	call   4070b0 <close@plt>
  40fb28:	xor    eax,eax
  40fb2a:	jmp    40fbc6 <__swc_fn_585f006d_000107_ff529476+0x5b6>
  40fb2f:	mov    rax,rbx
  40fb32:	movsxd rdi,DWORD PTR [rax]
  40fb35:	mov    rsi,r12
  40fb38:	xor    eax,eax
  40fb3a:	call   4071b0 <ftruncate@plt>
  40fb3f:	test   eax,eax
  40fb41:	je     40fb65 <__swc_fn_585f006d_000107_ff529476+0x555>
  40fb43:	movsxd rdi,DWORD PTR [rbx]
  40fb46:	xor    eax,eax
  40fb48:	call   4070b0 <close@plt>
  40fb4d:	mov    rdi,r15
  40fb50:	xor    eax,eax
  40fb52:	call   407190 <closedir@plt>
  40fb57:	movsxd rdi,r13d
  40fb5a:	xor    eax,eax
  40fb5c:	call   4070b0 <close@plt>
  40fb61:	xor    eax,eax
  40fb63:	jmp    40fbc6 <__swc_fn_585f006d_000107_ff529476+0x5b6>
  40fb65:	xor    edi,edi
  40fb67:	mov    rsi,r12
  40fb6a:	mov    edx,0x3
  40fb6f:	mov    ecx,0x1
  40fb74:	mov    rax,rbx
  40fb77:	movsxd r8,DWORD PTR [rax]
  40fb7a:	xor    r9d,r9d
  40fb7d:	xor    eax,eax
  40fb7f:	call   4070c0 <mmap@plt>
  40fb84:	mov    r12,rax
  40fb87:	cmp    rax,0xffffffffffffffff
  40fb8b:	jne    40fbaf <__swc_fn_585f006d_000107_ff529476+0x59f>
  40fb8d:	movsxd rdi,DWORD PTR [rbx]
  40fb90:	xor    eax,eax
  40fb92:	call   4070b0 <close@plt>
  40fb97:	mov    rdi,r15
  40fb9a:	xor    eax,eax
  40fb9c:	call   407190 <closedir@plt>
  40fba1:	movsxd rdi,r13d
  40fba4:	xor    eax,eax
  40fba6:	call   4070b0 <close@plt>
  40fbab:	xor    eax,eax
  40fbad:	jmp    40fbc6 <__swc_fn_585f006d_000107_ff529476+0x5b6>
  40fbaf:	mov    rdi,r15
  40fbb2:	xor    eax,eax
  40fbb4:	call   407190 <closedir@plt>
  40fbb9:	movsxd rdi,r13d
  40fbbc:	xor    eax,eax
  40fbbe:	call   4070b0 <close@plt>
  40fbc3:	mov    rax,r12
  40fbc6:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40fbcf:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40fbd8:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40fbe1:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40fbea:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  40fbf3:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40fbfc:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  40fc05:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40fc0e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  40fc17:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  40fc20:	add    rsp,0x170
  40fc27:	pop    r15
  40fc29:	pop    r14
  40fc2b:	pop    r13
  40fc2d:	pop    rsi
  40fc2e:	pop    rdi
  40fc2f:	pop    r12
  40fc31:	pop    rbx
  40fc32:	ret
	...

000000000040fc40 <__swc_fn_585f006d_000110_e606239a>:
  40fc40:	push   rsi
  40fc41:	push   rdi
  40fc42:	push   r12
  40fc44:	push   r13
  40fc46:	sub    rsp,0x8
  40fc4a:	mov    rsi,r8
  40fc4d:	mov    rdi,rcx
  40fc50:	mov    r12,rdx
  40fc53:	call   409100 <__swc_fn_585f006d_000108_32416b9e>
  40fc58:	mov    r13,rax
  40fc5b:	test   rax,rax
  40fc5e:	jne    40fc6b <__swc_fn_585f006d_000110_e606239a+0x2b>
  40fc60:	add    rsp,0x8
  40fc64:	pop    r13
  40fc66:	pop    r12
  40fc68:	pop    rdi
  40fc69:	pop    rsi
  40fc6a:	ret
  40fc6b:	mov    rcx,r13
  40fc6e:	call   40cd70 <__swc_fn_585f006d_000133_c6de0049>
  40fc73:	mov    rax,QWORD PTR [r13+0x8]
  40fc77:	test   rax,rax
  40fc7a:	je     40fcb9 <__swc_fn_585f006d_000110_e606239a+0x79>
  40fc7c:	nop    DWORD PTR [rax+0x0]
  40fc80:	lea    rcx,[rax+0x1000]
  40fc87:	cmp    rdi,rcx
  40fc8a:	jne    40fcb1 <__swc_fn_585f006d_000110_e606239a+0x71>
  40fc8c:	cmp    r12,0x1000
  40fc93:	jb     40fcb1 <__swc_fn_585f006d_000110_e606239a+0x71>
  40fc95:	test   sil,sil
  40fc98:	setne  cl
  40fc9b:	mov    BYTE PTR [rax+0x10],cl
  40fc9e:	mov    rcx,r13
  40fca1:	call   4101a0 <__swc_fn_585f006d_000134_5696c87e>
  40fca6:	add    rsp,0x8
  40fcaa:	pop    r13
  40fcac:	pop    r12
  40fcae:	pop    rdi
  40fcaf:	pop    rsi
  40fcb0:	ret
  40fcb1:	mov    rax,QWORD PTR [rax]
  40fcb4:	test   rax,rax
  40fcb7:	jne    40fc80 <__swc_fn_585f006d_000110_e606239a+0x40>
  40fcb9:	mov    rcx,r13
  40fcbc:	call   4101a0 <__swc_fn_585f006d_000134_5696c87e>
  40fcc1:	add    rsp,0x8
  40fcc5:	pop    r13
  40fcc7:	pop    r12
  40fcc9:	pop    rdi
  40fcca:	pop    rsi
  40fccb:	ret
  40fccc:	add    BYTE PTR [rax],al
	...

000000000040fcd0 <__swc_fn_585f006d_000113_25e345b1>:
  40fcd0:	sub    rsp,0x8
  40fcd4:	test   rcx,rcx
  40fcd7:	jne    40fcde <__swc_fn_585f006d_000113_25e345b1+0xe>
  40fcd9:	add    rsp,0x8
  40fcdd:	ret
  40fcde:	call   40c880 <__swc_fn_585f006d_000115_259b5d5a>
  40fce3:	add    rsp,0x8
  40fce7:	ret
	...

000000000040fcf0 <__swc_fn_585f006d_000116_3499f7d6>:
  40fcf0:	push   r12
  40fcf2:	push   r13
  40fcf4:	push   r14
  40fcf6:	push   rdi
  40fcf7:	push   rsi
  40fcf8:	sub    rsp,0xc0
  40fcff:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40fd05:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40fd0b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40fd11:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40fd17:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40fd1d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40fd23:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40fd29:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40fd32:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40fd3b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40fd44:	mov    r12,QWORD PTR [rcx]
  40fd47:	test   r12,r12
  40fd4a:	jne    40fd5c <__swc_fn_585f006d_000116_3499f7d6+0x6c>
  40fd4c:	add    rsp,0xc0
  40fd53:	pop    rsi
  40fd54:	pop    rdi
  40fd55:	pop    r14
  40fd57:	pop    r13
  40fd59:	pop    r12
  40fd5b:	ret
  40fd5c:	xor    r13d,r13d
  40fd5f:	mov    r14,QWORD PTR [rcx+0x8]
  40fd63:	cs nop WORD PTR [rax+rax*1+0x0]
  40fd6d:	nop    DWORD PTR [rax]
  40fd70:	cmp    r13,r14
  40fd73:	jae    40fdab <__swc_fn_585f006d_000116_3499f7d6+0xbb>
  40fd75:	lea    rax,[r12+r13*1]
  40fd79:	mov    rcx,r14
  40fd7c:	sub    rcx,r13
  40fd7f:	mov    edi,0x1
  40fd84:	mov    rsi,rax
  40fd87:	mov    rdx,rcx
  40fd8a:	xor    eax,eax
  40fd8c:	call   4071c0 <write@plt>
  40fd91:	test   rax,rax
  40fd94:	jle    40fd9b <__swc_fn_585f006d_000116_3499f7d6+0xab>
  40fd96:	add    r13,rax
  40fd99:	jmp    40fd70 <__swc_fn_585f006d_000116_3499f7d6+0x80>
  40fd9b:	je     40fda9 <__swc_fn_585f006d_000116_3499f7d6+0xb9>
  40fd9d:	xor    eax,eax
  40fd9f:	call   407130 <__errno_location@plt>
  40fda4:	cmp    DWORD PTR [rax],0x4
  40fda7:	je     40fd70 <__swc_fn_585f006d_000116_3499f7d6+0x80>
  40fda9:	jmp    40fdab <__swc_fn_585f006d_000116_3499f7d6+0xbb>
  40fdab:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40fdb1:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40fdb7:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40fdbd:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40fdc3:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40fdc9:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40fdcf:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40fdd5:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40fdde:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40fde7:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40fdf0:	add    rsp,0xc0
  40fdf7:	pop    rsi
  40fdf8:	pop    rdi
  40fdf9:	pop    r14
  40fdfb:	pop    r13
  40fdfd:	pop    r12
  40fdff:	ret

000000000040fe00 <__swc_fn_585f006d_000119_18cd3882>:
  40fe00:	push   rbx
  40fe01:	push   r12
  40fe03:	push   rdi
  40fe04:	push   rsi
  40fe05:	sub    rsp,0x4a8
  40fe0c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  40fe15:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  40fe1e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  40fe27:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  40fe30:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  40fe39:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  40fe42:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  40fe4b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  40fe54:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  40fe5d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  40fe66:	mov    rbx,rdx
  40fe69:	mov    r12d,ecx
  40fe6c:	vxorps xmm0,xmm0,xmm0
  40fe70:	xor    eax,eax
  40fe72:	cs nop WORD PTR [rax+rax*1+0x0]
  40fe7c:	nop    DWORD PTR [rax+0x0]
  40fe80:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  40fe86:	add    rax,0x10
  40fe8a:	cmp    rax,0x400
  40fe91:	jne    40fe80 <__swc_fn_585f006d_000119_18cd3882+0x80>
  40fe93:	lea    rdi,[rsp+0x8]
  40fe98:	mov    esi,0x80
  40fe9d:	xor    eax,eax
  40fe9f:	call   4071d0 <backtrace@plt>
  40fea4:	test   eax,eax
  40fea6:	jle    40feb5 <__swc_fn_585f006d_000119_18cd3882+0xb5>
  40fea8:	movsxd rax,eax
  40feab:	lea    rcx,[r12+0x1]
  40feb0:	cmp    rcx,rax
  40feb3:	jb     40feb9 <__swc_fn_585f006d_000119_18cd3882+0xb9>
  40feb5:	xor    eax,eax
  40feb7:	jmp    40feea <__swc_fn_585f006d_000119_18cd3882+0xea>
  40feb9:	mov    rcx,QWORD PTR [rbx+0x8]
  40febd:	sub    rax,r12
  40fec0:	lea    rsi,[rax-0x1]
  40fec4:	cmp    rcx,rsi
  40fec7:	cmovbe rsi,rcx
  40fecb:	lea    eax,[r12+0x1]
  40fed0:	lea    rax,[rsp+rax*8+0x8]
  40fed5:	mov    rcx,QWORD PTR [rbx]
  40fed8:	mov    rdx,rax
  40fedb:	lea    r8,[rsi*8+0x0]
  40fee3:	call   4090e0 <__swc_fn_585f006d_000105_b7aef7c0>
  40fee8:	mov    eax,esi
  40feea:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  40fef3:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  40fefc:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  40ff05:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  40ff0e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  40ff17:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  40ff20:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  40ff29:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  40ff32:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  40ff3b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  40ff44:	add    rsp,0x4a8
  40ff4b:	pop    rsi
  40ff4c:	pop    rdi
  40ff4d:	pop    r12
  40ff4f:	pop    rbx
  40ff50:	ret
	...

000000000040ff60 <__swc_fn_585f006d_000122_c37da69c>:
  40ff60:	mov    QWORD PTR [rcx],0x0
  40ff67:	ret
	...

000000000040ff70 <__swc_fn_585f006d_000125_e19c72b3>:
  40ff70:	push   rdi
  40ff71:	push   rsi
  40ff72:	sub    rsp,0xa8
  40ff79:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ff7f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ff85:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ff8b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40ff91:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40ff97:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40ff9d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ffa3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ffa9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ffb2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ffbb:	mov    edi,ecx
  40ffbd:	mov    rsi,rdx
  40ffc0:	xor    eax,eax
  40ffc2:	call   407060 <pthread_setspecific@plt>
  40ffc7:	test   eax,eax
  40ffc9:	sete   al
  40ffcc:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ffd2:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ffd8:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ffde:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ffe4:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ffea:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40fff0:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40fff6:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40fffc:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410005:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41000e:	add    rsp,0xa8
  410015:	pop    rsi
  410016:	pop    rdi
  410017:	ret
	...

0000000000410020 <__swc_fn_585f006d_000128_9c45d2d7>:
  410020:	push   rdi
  410021:	push   rsi
  410022:	sub    rsp,0xa8
  410029:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41002f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410035:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41003b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410041:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410047:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41004d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410053:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410059:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410062:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41006b:	test   rcx,rcx
  41006e:	je     410081 <__swc_fn_585f006d_000128_9c45d2d7+0x61>
  410070:	lea    rax,[rcx-0x1]
  410074:	mov    eax,eax
  410076:	mov    edi,eax
  410078:	xor    eax,eax
  41007a:	call   407000 <pthread_getspecific@plt>
  41007f:	jmp    410083 <__swc_fn_585f006d_000128_9c45d2d7+0x63>
  410081:	xor    eax,eax
  410083:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410089:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  41008f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410095:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41009b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4100a1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4100a7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4100ad:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4100b3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4100bc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4100c5:	add    rsp,0xa8
  4100cc:	pop    rsi
  4100cd:	pop    rdi
  4100ce:	ret
	...

00000000004100d0 <__swc_fn_585f006d_000131_dc04d759>:
  4100d0:	push   rdi
  4100d1:	push   rsi
  4100d2:	sub    rsp,0xb8
  4100d9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4100df:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4100e5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4100eb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4100f1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4100f7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4100fd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410103:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41010c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410115:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41011e:	vxorps xmm0,xmm0,xmm0
  410122:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410128:	mov    edi,0x1
  41012d:	lea    rsi,[rsp+0x8]
  410132:	xor    eax,eax
  410134:	call   4070e0 <clock_gettime@plt>
  410139:	mov    rax,QWORD PTR [rsp+0x8]
  41013e:	imul   rax,rax,0x3b9aca00
  410145:	add    rax,QWORD PTR [rsp+0x10]
  41014a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410150:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  410156:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  41015c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  410162:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410168:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  41016e:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  410174:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  41017d:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  410186:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  41018f:	add    rsp,0xb8
  410196:	pop    rsi
  410197:	pop    rdi
  410198:	ret
  410199:	add    BYTE PTR [rax],al
  41019b:	add    BYTE PTR [rax],al
  41019d:	add    BYTE PTR [rax],al
	...

00000000004101a0 <__swc_fn_585f006d_000134_5696c87e>:
  4101a0:	sub    rsp,0x8
  4101a4:	xor    eax,eax
  4101a6:	mov    DWORD PTR [rcx],eax
  4101a8:	mov    edx,0x7fffffff
  4101ad:	call   4097e0 <__swc_fn_585f006d_000132_2b60f756>
  4101b2:	add    rsp,0x8
  4101b6:	ret
	...

00000000004101c0 <__swc_fn_585f006d_000137_899a611e>:
  4101c0:	push   rdi
  4101c1:	push   rsi
  4101c2:	sub    rsp,0xb8
  4101c9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4101cf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4101d5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4101db:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4101e1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4101e7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4101ed:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4101f3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4101fc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410205:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41020e:	mov    edi,0x1
  410213:	xor    eax,eax
  410215:	call   4071e0 <__x86_get_cpuid_feature_leaf@plt>
  41021a:	mov    eax,DWORD PTR [rax+0x14]
  41021d:	and    eax,0x20
  410220:	setne  al
  410223:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410229:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  41022f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410235:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41023b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410241:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  410247:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41024d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  410256:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  41025f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410268:	add    rsp,0xb8
  41026f:	pop    rsi
  410270:	pop    rdi
  410271:	ret
	...

0000000000410280 <__swc_fn_585f006d_000140_81b740ca>:
  410280:	push   rsi
  410281:	push   rdi
  410282:	push   r12
  410284:	push   r13
  410286:	push   r14
  410288:	push   r15
  41028a:	cmp    rdx,0x40
  41028e:	jae    41029d <__swc_fn_585f006d_000140_81b740ca+0x1d>
  410290:	xor    eax,eax
  410292:	pop    r15
  410294:	pop    r14
  410296:	pop    r13
  410298:	pop    r12
  41029a:	pop    rdi
  41029b:	pop    rsi
  41029c:	ret
  41029d:	cmp    BYTE PTR [rcx],0x7f
  4102a0:	jne    4102e4 <__swc_fn_585f006d_000140_81b740ca+0x64>
  4102a2:	movzx  eax,BYTE PTR [rcx+0x1]
  4102a6:	cmp    eax,0x45
  4102a9:	setne  al
  4102ac:	jne    4102e0 <__swc_fn_585f006d_000140_81b740ca+0x60>
  4102ae:	movzx  eax,BYTE PTR [rcx+0x2]
  4102b2:	cmp    eax,0x4c
  4102b5:	setne  al
  4102b8:	jne    4102e0 <__swc_fn_585f006d_000140_81b740ca+0x60>
  4102ba:	movzx  eax,BYTE PTR [rcx+0x3]
  4102be:	cmp    eax,0x46
  4102c1:	setne  al
  4102c4:	jne    4102e0 <__swc_fn_585f006d_000140_81b740ca+0x60>
  4102c6:	cmp    BYTE PTR [rcx+0x4],0x2
  4102ca:	setne  al
  4102cd:	jne    4102e0 <__swc_fn_585f006d_000140_81b740ca+0x60>
  4102cf:	cmp    BYTE PTR [rcx+0x5],0x1
  4102d3:	setne  al
  4102d6:	jne    4102e0 <__swc_fn_585f006d_000140_81b740ca+0x60>
  4102d8:	cmp    WORD PTR [rcx+0x12],0x3e
  4102dd:	setne  al
  4102e0:	test   al,al
  4102e2:	je     4102f1 <__swc_fn_585f006d_000140_81b740ca+0x71>
  4102e4:	xor    eax,eax
  4102e6:	pop    r15
  4102e8:	pop    r14
  4102ea:	pop    r13
  4102ec:	pop    r12
  4102ee:	pop    rdi
  4102ef:	pop    rsi
  4102f0:	ret
  4102f1:	cmp    WORD PTR [rcx+0x3a],0x40
  4102f6:	jne    410311 <__swc_fn_585f006d_000140_81b740ca+0x91>
  4102f8:	cmp    WORD PTR [rcx+0x3c],0x0
  4102fd:	sete   al
  410300:	je     41030d <__swc_fn_585f006d_000140_81b740ca+0x8d>
  410302:	mov    ax,WORD PTR [rcx+0x3c]
  410306:	cmp    WORD PTR [rcx+0x3e],ax
  41030a:	setae  al
  41030d:	test   al,al
  41030f:	je     41031e <__swc_fn_585f006d_000140_81b740ca+0x9e>
  410311:	xor    eax,eax
  410313:	pop    r15
  410315:	pop    r14
  410317:	pop    r13
  410319:	pop    r12
  41031b:	pop    rdi
  41031c:	pop    rsi
  41031d:	ret
  41031e:	movzx  eax,WORD PTR [rcx+0x3c]
  410322:	shl    rax,0x6
  410326:	cmp    rax,rdx
  410329:	ja     410337 <__swc_fn_585f006d_000140_81b740ca+0xb7>
  41032b:	mov    r9,rdx
  41032e:	sub    r9,rax
  410331:	cmp    QWORD PTR [rcx+0x28],r9
  410335:	jbe    410344 <__swc_fn_585f006d_000140_81b740ca+0xc4>
  410337:	xor    eax,eax
  410339:	pop    r15
  41033b:	pop    r14
  41033d:	pop    r13
  41033f:	pop    r12
  410341:	pop    rdi
  410342:	pop    rsi
  410343:	ret
  410344:	mov    rax,QWORD PTR [rcx+0x28]
  410348:	add    rax,rcx
  41034b:	movzx  r9d,WORD PTR [rcx+0x3e]
  410350:	lea    r9,[r9*8+0x0]
  410358:	lea    r10,[rax+r9*8]
  41035c:	cmp    QWORD PTR [r10+0x20],rdx
  410360:	ja     410382 <__swc_fn_585f006d_000140_81b740ca+0x102>
  410362:	mov    r11,rdx
  410365:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  41036a:	cmp    QWORD PTR [r10+0x18],r11
  41036e:	seta   r9b
  410372:	ja     41037d <__swc_fn_585f006d_000140_81b740ca+0xfd>
  410374:	cmp    QWORD PTR [r10+0x20],0x9
  410379:	setb   r9b
  41037d:	test   r9b,r9b
  410380:	je     41038f <__swc_fn_585f006d_000140_81b740ca+0x10f>
  410382:	xor    eax,eax
  410384:	pop    r15
  410386:	pop    r14
  410388:	pop    r13
  41038a:	pop    r12
  41038c:	pop    rdi
  41038d:	pop    rsi
  41038e:	ret
  41038f:	movzx  r9d,WORD PTR [rcx+0x3c]
  410394:	xor    r11d,r11d
  410397:	test   r9,r9
  41039a:	jbe    410495 <__swc_fn_585f006d_000140_81b740ca+0x215>
  4103a0:	mov    rsi,QWORD PTR [r10+0x20]
  4103a4:	sub    rsi,0x9
  4103a8:	cs nop WORD PTR [rax+rax*1+0x0]
  4103b2:	cs nop WORD PTR [rax+rax*1+0x0]
  4103bc:	nop    DWORD PTR [rax+0x0]
  4103c0:	movzx  edi,r11w
  4103c4:	lea    rdi,[rdi*8+0x0]
  4103cc:	lea    r12,[rax+rdi*8]
  4103d0:	rex mov edi,DWORD PTR [rax+rdi*8]
  4103d4:	cmp    rdi,rsi
  4103d7:	ja     410488 <__swc_fn_585f006d_000140_81b740ca+0x208>
  4103dd:	mov    r13,QWORD PTR [r10+0x18]
  4103e1:	add    r13,rdi
  4103e4:	lea    rdi,[rcx+r13*1]
  4103e8:	lea    r13,[rip+0x2141]        # 412530 <__swc_rdata_base_585f006d+0x420>
  4103ef:	movabs r14,0x676264676177732e
  4103f9:	cmp    QWORD PTR [rdi],r14
  4103fc:	jne    410405 <__swc_fn_585f006d_000140_81b740ca+0x185>
  4103fe:	rex cmp BYTE PTR [rdi+0x8],0x0
  410403:	je     410432 <__swc_fn_585f006d_000140_81b740ca+0x1b2>
  410405:	cs nop WORD PTR [rax+rax*1+0x0]
  41040f:	nop
  410410:	movzx  r14d,BYTE PTR [rdi]
  410414:	movzx  r15d,BYTE PTR [r13+0x0]
  410419:	cmp    r14,r15
  41041c:	jne    410428 <__swc_fn_585f006d_000140_81b740ca+0x1a8>
  41041e:	add    rdi,0x1
  410422:	add    r13,0x1
  410426:	jmp    410410 <__swc_fn_585f006d_000140_81b740ca+0x190>
  410428:	mov    rdi,r14
  41042b:	sub    rdi,r15
  41042e:	test   edi,edi
  410430:	jne    410488 <__swc_fn_585f006d_000140_81b740ca+0x208>
  410432:	cmp    DWORD PTR [r12+0x4],0x1
  410438:	jne    410460 <__swc_fn_585f006d_000140_81b740ca+0x1e0>
  41043a:	cmp    QWORD PTR [r12+0x20],0x10
  410440:	setb   al
  410443:	jb     41045c <__swc_fn_585f006d_000140_81b740ca+0x1dc>
  410445:	cmp    QWORD PTR [r12+0x20],rdx
  41044a:	seta   al
  41044d:	ja     41045c <__swc_fn_585f006d_000140_81b740ca+0x1dc>
  41044f:	sub    rdx,QWORD PTR [r12+0x20]
  410454:	cmp    QWORD PTR [r12+0x18],rdx
  410459:	seta   al
  41045c:	test   al,al
  41045e:	je     41046d <__swc_fn_585f006d_000140_81b740ca+0x1ed>
  410460:	xor    eax,eax
  410462:	pop    r15
  410464:	pop    r14
  410466:	pop    r13
  410468:	pop    r12
  41046a:	pop    rdi
  41046b:	pop    rsi
  41046c:	ret
  41046d:	mov    rax,QWORD PTR [r12+0x20]
  410472:	mov    QWORD PTR [r8],rax
  410475:	mov    rax,QWORD PTR [r12+0x18]
  41047a:	add    rax,rcx
  41047d:	pop    r15
  41047f:	pop    r14
  410481:	pop    r13
  410483:	pop    r12
  410485:	pop    rdi
  410486:	pop    rsi
  410487:	ret
  410488:	add    r11,0x1
  41048c:	cmp    r11,r9
  41048f:	jb     4103c0 <__swc_fn_585f006d_000140_81b740ca+0x140>
  410495:	xor    eax,eax
  410497:	pop    r15
  410499:	pop    r14
  41049b:	pop    r13
  41049d:	pop    r12
  41049f:	pop    rdi
  4104a0:	pop    rsi
  4104a1:	ret
	...

00000000004104b0 <__swc_fn_585f006d_000143_afffe963>:
  4104b0:	push   rdi
  4104b1:	push   rsi
  4104b2:	sub    rsp,0xa8
  4104b9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4104bf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4104c5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4104cb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4104d1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4104d7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4104dd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4104e3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4104e9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4104f2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4104fb:	mov    rdi,rcx
  4104fe:	xor    eax,eax
  410500:	call   4071f0 <free@plt>
  410505:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41050b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410511:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410517:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41051d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410523:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410529:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41052f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410535:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41053e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410547:	add    rsp,0xa8
  41054e:	pop    rsi
  41054f:	pop    rdi
  410550:	ret
	...

0000000000410560 <__swc_fn_585f006d_000146_e9d46966>:
  410560:	push   rbx
  410561:	push   rsi
  410562:	push   rdi
  410563:	push   r12
  410565:	push   r13
  410567:	push   r15
  410569:	sub    rsp,0x4e8
  410570:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  410579:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  410582:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  41058b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  410594:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  41059d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  4105a6:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  4105af:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  4105b8:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  4105c1:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  4105ca:	mov    rbx,QWORD PTR [rcx]
  4105cd:	mov    rcx,QWORD PTR [rcx+0x8]
  4105d1:	mov    rsi,rcx
  4105d4:	xor    edi,edi
  4105d6:	vmovsd xmm6,QWORD PTR [rip+0x1fb2]        # 412590 <__swc_rdata_base_585f006d+0x480>
  4105de:	vmovsd xmm7,QWORD PTR [rip+0x1fb3]        # 412599 <__swc_rdata_base_585f006d+0x489>
  4105e6:	vmovsd xmm8,QWORD PTR [rip+0x1fb4]        # 4125a2 <__swc_rdata_base_585f006d+0x492>
  4105ee:	vmovsd xmm9,QWORD PTR [rip+0x1fb5]        # 4125ab <__swc_rdata_base_585f006d+0x49b>
  4105f6:	vmovsd xmm10,QWORD PTR [rip+0x1fb6]        # 4125b4 <__swc_rdata_base_585f006d+0x4a4>
  4105fe:	vmovups xmm11,xmm6
  410602:	vmovsd QWORD PTR [rsp+0x418],xmm7
  41060b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  410614:	vmovsd QWORD PTR [rsp+0x428],xmm9
  41061d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  410626:	vmovsd xmm15,QWORD PTR [rip+0x1f8f]        # 4125bd <__swc_rdata_base_585f006d+0x4ad>
  41062e:	vmovups xmm14,xmm15
  410633:	vmovups xmm0,xmm9
  410638:	vmovsd QWORD PTR [rsp+0x438],xmm15
  410641:	vmovups xmm13,xmm8
  410646:	vmovsd QWORD PTR [rsp+0x440],xmm15
  41064f:	test   rsi,rsi
  410652:	je     411643 <__swc_fn_585f006d_000146_e9d46966+0x10e3>
  410658:	cs nop WORD PTR [rax+rax*1+0x0]
  410662:	cs nop WORD PTR [rax+rax*1+0x0]
  41066c:	nop    DWORD PTR [rax+0x0]
  410670:	lea    rcx,[rdi+rdi*1]
  410674:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  410679:	vpshufd xmm3,xmm2,0xee
  41067e:	vmovq  rcx,xmm3
  410683:	test   rcx,rcx
  410686:	je     41069c <__swc_fn_585f006d_000146_e9d46966+0x13c>
  410688:	test   DWORD PTR [rcx+0x28],0x400000
  41068f:	je     41069c <__swc_fn_585f006d_000146_e9d46966+0x13c>
  410691:	mov    rdx,QWORD PTR [rcx+0x30]
  410695:	test   rdx,rdx
  410698:	cmovne rcx,rdx
  41069c:	test   DWORD PTR [rcx+0x28],0x1000
  4106a3:	je     4106c4 <__swc_fn_585f006d_000146_e9d46966+0x164>
  4106a5:	mov    rdx,QWORD PTR [rcx+0x40]
  4106a9:	mov    rcx,rdx
  4106ac:	vmovq  r8,xmm2
  4106b1:	mov    r8,QWORD PTR [r8]
  4106b4:	mov    QWORD PTR [rsp+0x60],r8
  4106b9:	mov    QWORD PTR [rsp+0x68],rdx
  4106be:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  4106c4:	test   BYTE PTR [rcx+0x28],0x1
  4106c8:	jne    4106d0 <__swc_fn_585f006d_000146_e9d46966+0x170>
  4106ca:	vmovups xmm12,xmm0
  4106ce:	jmp    4106ea <__swc_fn_585f006d_000146_e9d46966+0x18a>
  4106d0:	vmovq  rax,xmm2
  4106d5:	mov    rax,QWORD PTR [rax]
  4106d8:	lea    rcx,[rax+0x10]
  4106dc:	vmovups xmm12,xmm0
  4106e0:	call   40fcf0 <__swc_fn_585f006d_000116_3499f7d6>
  4106e5:	jmp    411625 <__swc_fn_585f006d_000146_e9d46966+0x10c5>
  4106ea:	test   DWORD PTR [rcx+0x28],0x400
  4106f1:	je     410752 <__swc_fn_585f006d_000146_e9d46966+0x1f2>
  4106f3:	vmovq  rax,xmm2
  4106f8:	mov    rax,QWORD PTR [rax]
  4106fb:	xor    ecx,ecx
  4106fd:	test   rax,rax
  410700:	je     410730 <__swc_fn_585f006d_000146_e9d46966+0x1d0>
  410702:	mov    rdx,rax
  410705:	mov    r8b,BYTE PTR [rdx]
  410708:	test   r8b,r8b
  41070b:	je     410730 <__swc_fn_585f006d_000146_e9d46966+0x1d0>
  41070d:	cs nop WORD PTR [rax+rax*1+0x0]
  410717:	nop    WORD PTR [rax+rax*1+0x0]
  410720:	add    rdx,0x1
  410724:	add    rcx,0x1
  410728:	mov    r8b,BYTE PTR [rdx]
  41072b:	test   r8b,r8b
  41072e:	jne    410720 <__swc_fn_585f006d_000146_e9d46966+0x1c0>
  410730:	mov    QWORD PTR [rsp+0x88],rax
  410738:	mov    QWORD PTR [rsp+0x90],rcx
  410740:	lea    rcx,[rsp+0x88]
  410748:	call   40fcf0 <__swc_fn_585f006d_000116_3499f7d6>
  41074d:	jmp    411625 <__swc_fn_585f006d_000146_e9d46966+0x10c5>
  410752:	cmp    BYTE PTR [rcx+0x2c],0x6
  410756:	jne    41076d <__swc_fn_585f006d_000146_e9d46966+0x20d>
  410758:	vmovq  rax,xmm2
  41075d:	mov    rax,QWORD PTR [rax]
  410760:	mov    rcx,rax
  410763:	call   409cb0 <__swc_fn_585f006d_000144_364559f5>
  410768:	jmp    411625 <__swc_fn_585f006d_000146_e9d46966+0x10c5>
  41076d:	cmp    BYTE PTR [rcx+0x2c],0x1
  410771:	jne    411619 <__swc_fn_585f006d_000146_e9d46966+0x10b9>
  410777:	vmovq  rdx,xmm2
  41077c:	mov    cl,BYTE PTR [rcx+0x40]
  41077f:	cmp    cl,0x7
  410782:	jb     4107c5 <__swc_fn_585f006d_000146_e9d46966+0x265>
  410784:	je     410838 <__swc_fn_585f006d_000146_e9d46966+0x2d8>
  41078a:	cmp    cl,0x8
  41078d:	je     410844 <__swc_fn_585f006d_000146_e9d46966+0x2e4>
  410793:	cmp    cl,0x9
  410796:	je     41085d <__swc_fn_585f006d_000146_e9d46966+0x2fd>
  41079c:	cmp    cl,0xa
  41079f:	je     410f24 <__swc_fn_585f006d_000146_e9d46966+0x9c4>
  4107a5:	cmp    cl,0xb
  4107a8:	je     4115eb <__swc_fn_585f006d_000146_e9d46966+0x108b>
  4107ae:	cmp    cl,0xc
  4107b1:	je     410851 <__swc_fn_585f006d_000146_e9d46966+0x2f1>
  4107b7:	cmp    cl,0xd
  4107ba:	je     4115e1 <__swc_fn_585f006d_000146_e9d46966+0x1081>
  4107c0:	jmp    41160b <__swc_fn_585f006d_000146_e9d46966+0x10ab>
  4107c5:	cmp    cl,0x1
  4107c8:	je     4107e8 <__swc_fn_585f006d_000146_e9d46966+0x288>
  4107ca:	cmp    cl,0x2
  4107cd:	je     4107f6 <__swc_fn_585f006d_000146_e9d46966+0x296>
  4107cf:	cmp    cl,0x3
  4107d2:	je     410804 <__swc_fn_585f006d_000146_e9d46966+0x2a4>
  4107d4:	cmp    cl,0x4
  4107d7:	je     410811 <__swc_fn_585f006d_000146_e9d46966+0x2b1>
  4107d9:	cmp    cl,0x5
  4107dc:	je     41081e <__swc_fn_585f006d_000146_e9d46966+0x2be>
  4107de:	cmp    cl,0x6
  4107e1:	je     41082b <__swc_fn_585f006d_000146_e9d46966+0x2cb>
  4107e3:	jmp    41160b <__swc_fn_585f006d_000146_e9d46966+0x10ab>
  4107e8:	movsx  rcx,BYTE PTR [rdx]
  4107ec:	call   40cf60 <__swc_fn_585f006d_000145_071b4f4c>
  4107f1:	jmp    411625 <__swc_fn_585f006d_000146_e9d46966+0x10c5>
  4107f6:	movsx  rcx,WORD PTR [rdx]
  4107fa:	call   40cf60 <__swc_fn_585f006d_000145_071b4f4c>
  4107ff:	jmp    411625 <__swc_fn_585f006d_000146_e9d46966+0x10c5>
  410804:	movsxd rcx,DWORD PTR [rdx]
  410807:	call   40cf60 <__swc_fn_585f006d_000145_071b4f4c>
  41080c:	jmp    411625 <__swc_fn_585f006d_000146_e9d46966+0x10c5>
  410811:	mov    rcx,QWORD PTR [rdx]
  410814:	call   40cf60 <__swc_fn_585f006d_000145_071b4f4c>
  410819:	jmp    411625 <__swc_fn_585f006d_000146_e9d46966+0x10c5>
  41081e:	movzx  ecx,BYTE PTR [rdx]
  410821:	call   409cb0 <__swc_fn_585f006d_000144_364559f5>
  410826:	jmp    411625 <__swc_fn_585f006d_000146_e9d46966+0x10c5>
  41082b:	movzx  ecx,WORD PTR [rdx]
  41082e:	call   409cb0 <__swc_fn_585f006d_000144_364559f5>
  410833:	jmp    411625 <__swc_fn_585f006d_000146_e9d46966+0x10c5>
  410838:	mov    ecx,DWORD PTR [rdx]
  41083a:	call   409cb0 <__swc_fn_585f006d_000144_364559f5>
  41083f:	jmp    411625 <__swc_fn_585f006d_000146_e9d46966+0x10c5>
  410844:	mov    rcx,QWORD PTR [rdx]
  410847:	call   409cb0 <__swc_fn_585f006d_000144_364559f5>
  41084c:	jmp    411625 <__swc_fn_585f006d_000146_e9d46966+0x10c5>
  410851:	mov    ecx,DWORD PTR [rdx]
  410853:	call   409cb0 <__swc_fn_585f006d_000144_364559f5>
  410858:	jmp    411625 <__swc_fn_585f006d_000146_e9d46966+0x10c5>
  41085d:	lea    rcx,[rsp+0xa8]
  410865:	vxorps xmm0,xmm0,xmm0
  410869:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  410872:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  41087b:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  410884:	vzeroupper
  410887:	mov    DWORD PTR [rsp+0x108],0x0
  410892:	vxorpd xmm0,xmm0,xmm0
  410896:	vmovss xmm1,DWORD PTR [rdx]
  41089a:	vcvtss2sd xmm0,xmm0,xmm1
  41089e:	vmovsd xmm1,xmm1,xmm0
  4108a2:	vcomisd xmm0,xmm0
  4108a6:	setne  dl
  4108a9:	movzx  edx,dl
  4108ac:	setp   r8b
  4108b0:	movzx  r8d,r8b
  4108b4:	or     edx,r8d
  4108b7:	test   dl,dl
  4108b9:	je     4108c6 <__swc_fn_585f006d_000146_e9d46966+0x366>
  4108bb:	mov    DWORD PTR [rcx],0x6e616e
  4108c1:	jmp    410eb8 <__swc_fn_585f006d_000146_e9d46966+0x958>
  4108c6:	vcomisd xmm1,xmm6
  4108ca:	ja     4108d2 <__swc_fn_585f006d_000146_e9d46966+0x372>
  4108cc:	vcomisd xmm7,xmm1
  4108d0:	jbe    4108f6 <__swc_fn_585f006d_000146_e9d46966+0x396>
  4108d2:	vxorpd xmm0,xmm0,xmm0
  4108d6:	vcomisd xmm0,xmm1
  4108da:	jbe    4108eb <__swc_fn_585f006d_000146_e9d46966+0x38b>
  4108dc:	mov    DWORD PTR [rcx],0x666e692d
  4108e2:	mov    BYTE PTR [rcx+0x4],0x0
  4108e6:	jmp    410eb8 <__swc_fn_585f006d_000146_e9d46966+0x958>
  4108eb:	mov    DWORD PTR [rcx],0x666e69
  4108f1:	jmp    410eb8 <__swc_fn_585f006d_000146_e9d46966+0x958>
  4108f6:	vcomisd xmm1,xmm8
  4108fb:	jae    410907 <__swc_fn_585f006d_000146_e9d46966+0x3a7>
  4108fd:	vcomisd xmm9,xmm1
  410901:	jbe    410c7e <__swc_fn_585f006d_000146_e9d46966+0x71e>
  410907:	vmovups xmm0,xmm1
  41090b:	vxorpd xmm2,xmm2,xmm2
  41090f:	vcomisd xmm2,xmm1
  410913:	jbe    410923 <__swc_fn_585f006d_000146_e9d46966+0x3c3>
  410915:	vmovsd xmm1,xmm1,xmm0
  410919:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1c2f]        # 412550 <__swc_rdata_base_585f006d+0x440>
  410921:	jmp    410927 <__swc_fn_585f006d_000146_e9d46966+0x3c7>
  410923:	vmovsd xmm1,xmm1,xmm0
  410927:	xor    r8d,r8d
  41092a:	vcomisd xmm1,xmm15
  41092f:	jb     410950 <__swc_fn_585f006d_000146_e9d46966+0x3f0>
  410931:	cs nop WORD PTR [rax+rax*1+0x0]
  41093b:	nop    DWORD PTR [rax+rax*1+0x0]
  410940:	vdivsd xmm1,xmm1,xmm15
  410945:	add    r8,0x1
  410949:	vcomisd xmm1,xmm15
  41094e:	jae    410940 <__swc_fn_585f006d_000146_e9d46966+0x3e0>
  410950:	mov    r9,rcx
  410953:	vxorpd xmm2,xmm2,xmm2
  410957:	vcomisd xmm2,xmm0
  41095b:	jbe    410964 <__swc_fn_585f006d_000146_e9d46966+0x404>
  41095d:	mov    BYTE PTR [rcx],0x2d
  410960:	lea    r9,[rcx+0x1]
  410964:	vcvttsd2si rdx,xmm1
  410969:	mov    r10b,dl
  41096c:	add    r10b,0x30
  410970:	mov    BYTE PTR [r9],r10b
  410973:	vxorpd xmm0,xmm0,xmm0
  410977:	movzx  edx,dl
  41097a:	vcvtsi2sd xmm0,xmm0,rdx
  41097f:	vsubsd xmm0,xmm1,xmm0
  410983:	vmulsd xmm1,xmm0,xmm15
  410988:	mov    BYTE PTR [r9+0x1],0x2e
  41098d:	vcvttsd2si rdx,xmm1
  410992:	mov    r10b,dl
  410995:	add    r10b,0x30
  410999:	mov    BYTE PTR [r9+0x2],r10b
  41099d:	vxorpd xmm0,xmm0,xmm0
  4109a1:	movzx  edx,dl
  4109a4:	vcvtsi2sd xmm0,xmm0,rdx
  4109a9:	vsubsd xmm0,xmm1,xmm0
  4109ad:	vmulsd xmm1,xmm0,xmm15
  4109b2:	vcvttsd2si rdx,xmm1
  4109b7:	mov    r10b,dl
  4109ba:	add    r10b,0x30
  4109be:	mov    BYTE PTR [r9+0x3],r10b
  4109c2:	vxorpd xmm0,xmm0,xmm0
  4109c6:	movzx  edx,dl
  4109c9:	vcvtsi2sd xmm0,xmm0,rdx
  4109ce:	vsubsd xmm0,xmm1,xmm0
  4109d2:	vmulsd xmm1,xmm0,xmm15
  4109d7:	vcvttsd2si rdx,xmm1
  4109dc:	mov    r10b,dl
  4109df:	add    r10b,0x30
  4109e3:	mov    BYTE PTR [r9+0x4],r10b
  4109e7:	vxorpd xmm0,xmm0,xmm0
  4109eb:	movzx  edx,dl
  4109ee:	vcvtsi2sd xmm0,xmm0,rdx
  4109f3:	vsubsd xmm0,xmm1,xmm0
  4109f7:	vmulsd xmm1,xmm0,xmm15
  4109fc:	vcvttsd2si rdx,xmm1
  410a01:	mov    r10b,dl
  410a04:	add    r10b,0x30
  410a08:	mov    BYTE PTR [r9+0x5],r10b
  410a0c:	vxorpd xmm0,xmm0,xmm0
  410a10:	movzx  edx,dl
  410a13:	vcvtsi2sd xmm0,xmm0,rdx
  410a18:	vsubsd xmm0,xmm1,xmm0
  410a1c:	vmulsd xmm1,xmm0,xmm15
  410a21:	vcvttsd2si rdx,xmm1
  410a26:	mov    r10b,dl
  410a29:	add    r10b,0x30
  410a2d:	mov    BYTE PTR [r9+0x6],r10b
  410a31:	vxorpd xmm0,xmm0,xmm0
  410a35:	movzx  edx,dl
  410a38:	vcvtsi2sd xmm0,xmm0,rdx
  410a3d:	vsubsd xmm0,xmm1,xmm0
  410a41:	vmulsd xmm1,xmm0,xmm15
  410a46:	vcvttsd2si rdx,xmm1
  410a4b:	mov    r10b,dl
  410a4e:	add    r10b,0x30
  410a52:	mov    BYTE PTR [r9+0x7],r10b
  410a56:	vxorpd xmm0,xmm0,xmm0
  410a5a:	movzx  edx,dl
  410a5d:	vcvtsi2sd xmm0,xmm0,rdx
  410a62:	vsubsd xmm0,xmm1,xmm0
  410a66:	vmulsd xmm1,xmm0,xmm15
  410a6b:	vcvttsd2si rdx,xmm1
  410a70:	mov    r10b,dl
  410a73:	add    r10b,0x30
  410a77:	mov    BYTE PTR [r9+0x8],r10b
  410a7b:	vxorpd xmm0,xmm0,xmm0
  410a7f:	movzx  edx,dl
  410a82:	vcvtsi2sd xmm0,xmm0,rdx
  410a87:	vsubsd xmm0,xmm1,xmm0
  410a8b:	vmulsd xmm1,xmm0,xmm15
  410a90:	vcvttsd2si rdx,xmm1
  410a95:	mov    r10b,dl
  410a98:	add    r10b,0x30
  410a9c:	mov    BYTE PTR [r9+0x9],r10b
  410aa0:	vxorpd xmm0,xmm0,xmm0
  410aa4:	movzx  edx,dl
  410aa7:	vcvtsi2sd xmm0,xmm0,rdx
  410aac:	vsubsd xmm0,xmm1,xmm0
  410ab0:	vmulsd xmm1,xmm0,xmm15
  410ab5:	vcvttsd2si rdx,xmm1
  410aba:	mov    r10b,dl
  410abd:	add    r10b,0x30
  410ac1:	mov    BYTE PTR [r9+0xa],r10b
  410ac5:	vxorpd xmm0,xmm0,xmm0
  410ac9:	movzx  edx,dl
  410acc:	vcvtsi2sd xmm0,xmm0,rdx
  410ad1:	vsubsd xmm0,xmm1,xmm0
  410ad5:	vmulsd xmm1,xmm0,xmm15
  410ada:	vcvttsd2si rdx,xmm1
  410adf:	mov    r10b,dl
  410ae2:	add    r10b,0x30
  410ae6:	mov    BYTE PTR [r9+0xb],r10b
  410aea:	lea    r10,[r9+0x4]
  410aee:	vxorpd xmm0,xmm0,xmm0
  410af2:	movzx  edx,dl
  410af5:	vcvtsi2sd xmm0,xmm0,rdx
  410afa:	vsubsd xmm0,xmm1,xmm0
  410afe:	vmulsd xmm1,xmm0,xmm15
  410b03:	vcvttsd2si rdx,xmm1
  410b08:	mov    r11b,dl
  410b0b:	add    r11b,0x30
  410b0f:	mov    BYTE PTR [r9+0xc],r11b
  410b13:	vxorpd xmm0,xmm0,xmm0
  410b17:	movzx  edx,dl
  410b1a:	vcvtsi2sd xmm0,xmm0,rdx
  410b1f:	vsubsd xmm0,xmm1,xmm0
  410b23:	vmulsd xmm1,xmm0,xmm15
  410b28:	vcvttsd2si rdx,xmm1
  410b2d:	mov    r11b,dl
  410b30:	add    r11b,0x30
  410b34:	mov    BYTE PTR [r9+0xd],r11b
  410b38:	lea    r10,[r10+0x2]
  410b3c:	vxorpd xmm0,xmm0,xmm0
  410b40:	movzx  edx,dl
  410b43:	vcvtsi2sd xmm0,xmm0,rdx
  410b48:	vsubsd xmm0,xmm1,xmm0
  410b4c:	vmulsd xmm1,xmm0,xmm15
  410b51:	vcvttsd2si rdx,xmm1
  410b56:	mov    r11b,dl
  410b59:	add    r11b,0x30
  410b5d:	mov    BYTE PTR [r9+0xe],r11b
  410b61:	vxorpd xmm0,xmm0,xmm0
  410b65:	movzx  edx,dl
  410b68:	vcvtsi2sd xmm0,xmm0,rdx
  410b6d:	vsubsd xmm0,xmm1,xmm0
  410b71:	vmulsd xmm1,xmm0,xmm15
  410b76:	vcvttsd2si rdx,xmm1
  410b7b:	mov    r11b,dl
  410b7e:	add    r11b,0x30
  410b82:	mov    BYTE PTR [r9+0xf],r11b
  410b86:	lea    r10,[r10+0x2]
  410b8a:	lea    r10,[r10+0x2]
  410b8e:	lea    r10,[r10+0x2]
  410b92:	lea    r10,[r10+0x2]
  410b96:	lea    r10,[r10+0x2]
  410b9a:	vxorpd xmm0,xmm0,xmm0
  410b9e:	movzx  edx,dl
  410ba1:	vcvtsi2sd xmm0,xmm0,rdx
  410ba6:	vsubsd xmm0,xmm1,xmm0
  410baa:	vmulsd xmm1,xmm0,xmm15
  410baf:	vcvttsd2si rdx,xmm1
  410bb4:	mov    r11b,dl
  410bb7:	add    r11b,0x30
  410bbb:	mov    BYTE PTR [r9+0x10],r11b
  410bbf:	vxorpd xmm0,xmm0,xmm0
  410bc3:	movzx  edx,dl
  410bc6:	vcvtsi2sd xmm0,xmm0,rdx
  410bcb:	vsubsd xmm0,xmm1,xmm0
  410bcf:	vmulsd xmm1,xmm0,xmm15
  410bd4:	vcvttsd2si rdx,xmm1
  410bd9:	add    dl,0x30
  410bdc:	mov    BYTE PTR [r9+0x11],dl
  410be0:	mov    BYTE PTR [r10+0x2],0x65
  410be5:	lea    r9,[r10+0x3]
  410be9:	test   r8,r8
  410bec:	jl     410bf5 <__swc_fn_585f006d_000146_e9d46966+0x695>
  410bee:	mov    BYTE PTR [r9],0x2b
  410bf2:	inc    r9
  410bf5:	mov    r10,r9
  410bf8:	mov    rdx,r8
  410bfb:	nop    DWORD PTR [rax+rax*1+0x0]
  410c00:	mov    r11,rdx
  410c03:	movabs rdx,0x6666666666666667
  410c0d:	mov    rax,r11
  410c10:	imul   rdx
  410c13:	sar    rdx,0x2
  410c17:	mov    r12,rdx
  410c1a:	shr    rdx,0x3f
  410c1e:	add    r12,rdx
  410c21:	mov    rdx,r12
  410c24:	imul   r13,r12,0xa
  410c28:	sub    r11,r13
  410c2b:	mov    r13,QWORD PTR [rip+0x190e]        # 412540 <__swc_rdata_base_585f006d+0x430>
  410c32:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410c37:	mov    BYTE PTR [r10],r11b
  410c3a:	lea    r11,[r10+0x1]
  410c3e:	mov    r10,r11
  410c41:	test   r12,r12
  410c44:	jne    410c00 <__swc_fn_585f006d_000146_e9d46966+0x6a0>
  410c46:	test   r8,r8
  410c49:	jge    410c53 <__swc_fn_585f006d_000146_e9d46966+0x6f3>
  410c4b:	mov    BYTE PTR [r11],0x2d
  410c4f:	lea    r10,[r11+0x1]
  410c53:	mov    BYTE PTR [r10],0x0
  410c57:	sub    r10,0x1
  410c5b:	nop    DWORD PTR [rax+rax*1+0x0]
  410c60:	cmp    r9,r10
  410c63:	jae    410eb8 <__swc_fn_585f006d_000146_e9d46966+0x958>
  410c69:	mov    al,BYTE PTR [r10]
  410c6c:	mov    dl,BYTE PTR [r9]
  410c6f:	mov    BYTE PTR [r10],dl
  410c72:	sub    r10,0x1
  410c76:	mov    BYTE PTR [r9],al
  410c79:	inc    r9
  410c7c:	jmp    410c60 <__swc_fn_585f006d_000146_e9d46966+0x700>
  410c7e:	vcvttsd2si rdx,xmm1
  410c83:	mov    r8,rdx
  410c86:	vxorpd xmm0,xmm0,xmm0
  410c8a:	vcvtsi2sd xmm0,xmm0,rdx
  410c8f:	vsubsd xmm0,xmm1,xmm0
  410c93:	mov    r9d,0x8
  410c99:	vxorpd xmm2,xmm2,xmm2
  410c9d:	vcomisd xmm2,xmm0
  410ca1:	jbe    410cab <__swc_fn_585f006d_000146_e9d46966+0x74b>
  410ca3:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x18a5]        # 412550 <__swc_rdata_base_585f006d+0x440>
  410cab:	test   r9d,r9d
  410cae:	je     410cba <__swc_fn_585f006d_000146_e9d46966+0x75a>
  410cb0:	vmulsd xmm0,xmm0,xmm14
  410cb5:	dec    r9d
  410cb8:	jne    410cb0 <__swc_fn_585f006d_000146_e9d46966+0x750>
  410cba:	vcvttsd2si r9,xmm0
  410cbf:	mov    r10,r9
  410cc2:	vxorpd xmm2,xmm2,xmm2
  410cc6:	vcvtsi2sd xmm2,xmm2,r9
  410ccb:	vsubsd xmm0,xmm0,xmm2
  410ccf:	vcomisd xmm0,xmm10
  410cd4:	lea    r9,[r9+0x1]
  410cd8:	cmova  r10,r9
  410cdc:	cmp    r10,0x5f5e100
  410ce3:	jne    410cfc <__swc_fn_585f006d_000146_e9d46966+0x79c>
  410ce5:	lea    r8,[rdx-0x1]
  410ce9:	vxorpd xmm0,xmm0,xmm0
  410ced:	vcomisd xmm0,xmm1
  410cf1:	lea    rdx,[rdx+0x1]
  410cf5:	cmovbe r8,rdx
  410cf9:	xor    r10d,r10d
  410cfc:	mov    r9,rcx
  410cff:	test   r8,r8
  410d02:	jne    410d22 <__swc_fn_585f006d_000146_e9d46966+0x7c2>
  410d04:	vxorpd xmm0,xmm0,xmm0
  410d08:	vcomisd xmm0,xmm1
  410d0c:	jbe    410d15 <__swc_fn_585f006d_000146_e9d46966+0x7b5>
  410d0e:	mov    BYTE PTR [rcx],0x2d
  410d11:	lea    r9,[rcx+0x1]
  410d15:	mov    BYTE PTR [r9],0x30
  410d19:	add    r9,0x1
  410d1d:	jmp    410dbb <__swc_fn_585f006d_000146_e9d46966+0x85b>
  410d22:	mov    r9,rcx
  410d25:	mov    rdx,r8
  410d28:	nop    DWORD PTR [rax+rax*1+0x0]
  410d30:	mov    r11,rdx
  410d33:	movabs rdx,0x6666666666666667
  410d3d:	mov    r15,rax
  410d40:	mov    rax,r11
  410d43:	imul   rdx
  410d46:	mov    r12,rdx
  410d49:	mov    rax,r15
  410d4c:	sar    r12,0x2
  410d50:	mov    rdx,r12
  410d53:	shr    rdx,0x3f
  410d57:	add    r12,rdx
  410d5a:	mov    rdx,r12
  410d5d:	imul   r13,r12,0xa
  410d61:	sub    r11,r13
  410d64:	mov    r13,QWORD PTR [rip+0x17d5]        # 412540 <__swc_rdata_base_585f006d+0x430>
  410d6b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410d70:	mov    BYTE PTR [r9],r11b
  410d73:	lea    r11,[r9+0x1]
  410d77:	mov    r9,r11
  410d7a:	test   r12,r12
  410d7d:	jne    410d30 <__swc_fn_585f006d_000146_e9d46966+0x7d0>
  410d7f:	test   r8,r8
  410d82:	jge    410d8c <__swc_fn_585f006d_000146_e9d46966+0x82c>
  410d84:	mov    BYTE PTR [r11],0x2d
  410d88:	lea    r9,[r11+0x1]
  410d8c:	mov    rdx,r9
  410d8f:	mov    BYTE PTR [r9],0x0
  410d93:	sub    r9,0x1
  410d97:	mov    r8,rcx
  410d9a:	cmp    r8,r9
  410d9d:	jae    410db8 <__swc_fn_585f006d_000146_e9d46966+0x858>
  410d9f:	nop
  410da0:	mov    r11b,BYTE PTR [r9]
  410da3:	mov    r12b,BYTE PTR [r8]
  410da6:	mov    BYTE PTR [r9],r12b
  410da9:	sub    r9,0x1
  410dad:	mov    BYTE PTR [r8],r11b
  410db0:	inc    r8
  410db3:	cmp    r8,r9
  410db6:	jb     410da0 <__swc_fn_585f006d_000146_e9d46966+0x840>
  410db8:	mov    r9,rdx
  410dbb:	mov    BYTE PTR [r9],0x2e
  410dbf:	add    r9,0x1
  410dc3:	xor    r8d,r8d
  410dc6:	test   r10,r10
  410dc9:	je     410e0f <__swc_fn_585f006d_000146_e9d46966+0x8af>
  410dcb:	mov    r11d,0x989680
  410dd1:	cmp    r10,r11
  410dd4:	jge    410e0f <__swc_fn_585f006d_000146_e9d46966+0x8af>
  410dd6:	cs nop WORD PTR [rax+rax*1+0x0]
  410de0:	inc    r8d
  410de3:	movabs rdx,0x6666666666666667
  410ded:	mov    r15,rax
  410df0:	mov    rax,r11
  410df3:	imul   rdx
  410df6:	mov    r11,rdx
  410df9:	mov    rax,r15
  410dfc:	sar    r11,0x2
  410e00:	mov    rdx,r11
  410e03:	shr    rdx,0x3f
  410e07:	add    r11,rdx
  410e0a:	cmp    r10,r11
  410e0d:	jl     410de0 <__swc_fn_585f006d_000146_e9d46966+0x880>
  410e0f:	test   r8d,r8d
  410e12:	je     410e2d <__swc_fn_585f006d_000146_e9d46966+0x8cd>
  410e14:	cs nop WORD PTR [rax+rax*1+0x0]
  410e1e:	xchg   ax,ax
  410e20:	mov    BYTE PTR [r9],0x30
  410e24:	add    r9,0x1
  410e28:	dec    r8d
  410e2b:	jne    410e20 <__swc_fn_585f006d_000146_e9d46966+0x8c0>
  410e2d:	mov    r8,r9
  410e30:	mov    rdx,r10
  410e33:	cs nop WORD PTR [rax+rax*1+0x0]
  410e3d:	nop    DWORD PTR [rax]
  410e40:	mov    r11,rdx
  410e43:	movabs rdx,0x6666666666666667
  410e4d:	mov    rax,r11
  410e50:	imul   rdx
  410e53:	sar    rdx,0x2
  410e57:	mov    r12,rdx
  410e5a:	shr    rdx,0x3f
  410e5e:	add    r12,rdx
  410e61:	mov    rdx,r12
  410e64:	imul   r13,r12,0xa
  410e68:	sub    r11,r13
  410e6b:	mov    r13,QWORD PTR [rip+0x16ce]        # 412540 <__swc_rdata_base_585f006d+0x430>
  410e72:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410e77:	mov    BYTE PTR [r8],r11b
  410e7a:	lea    r11,[r8+0x1]
  410e7e:	mov    r8,r11
  410e81:	test   r12,r12
  410e84:	jne    410e40 <__swc_fn_585f006d_000146_e9d46966+0x8e0>
  410e86:	test   r10,r10
  410e89:	jge    410e93 <__swc_fn_585f006d_000146_e9d46966+0x933>
  410e8b:	mov    BYTE PTR [r11],0x2d
  410e8f:	lea    r8,[r11+0x1]
  410e93:	mov    BYTE PTR [r8],0x0
  410e97:	sub    r8,0x1
  410e9b:	cmp    r9,r8
  410e9e:	jae    410eb8 <__swc_fn_585f006d_000146_e9d46966+0x958>
  410ea0:	mov    al,BYTE PTR [r8]
  410ea3:	mov    dl,BYTE PTR [r9]
  410ea6:	mov    BYTE PTR [r8],dl
  410ea9:	sub    r8,0x1
  410ead:	mov    BYTE PTR [r9],al
  410eb0:	inc    r9
  410eb3:	cmp    r9,r8
  410eb6:	jb     410ea0 <__swc_fn_585f006d_000146_e9d46966+0x940>
  410eb8:	xor    eax,eax
  410eba:	test   rcx,rcx
  410ebd:	je     410ef0 <__swc_fn_585f006d_000146_e9d46966+0x990>
  410ebf:	mov    rdx,rcx
  410ec2:	mov    r8b,BYTE PTR [rdx]
  410ec5:	test   r8b,r8b
  410ec8:	je     410ef0 <__swc_fn_585f006d_000146_e9d46966+0x990>
  410eca:	cs nop WORD PTR [rax+rax*1+0x0]
  410ed4:	cs nop WORD PTR [rax+rax*1+0x0]
  410ede:	xchg   ax,ax
  410ee0:	add    rdx,0x1
  410ee4:	add    rax,0x1
  410ee8:	mov    r8b,BYTE PTR [rdx]
  410eeb:	test   r8b,r8b
  410eee:	jne    410ee0 <__swc_fn_585f006d_000146_e9d46966+0x980>
  410ef0:	mov    QWORD PTR [rsp+0x240],rcx
  410ef8:	mov    QWORD PTR [rsp+0x248],rax
  410f00:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  410f09:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  410f12:	lea    rcx,[rsp+0x250]
  410f1a:	call   40fcf0 <__swc_fn_585f006d_000116_3499f7d6>
  410f1f:	jmp    411625 <__swc_fn_585f006d_000146_e9d46966+0x10c5>
  410f24:	lea    rcx,[rsp+0x260]
  410f2c:	vxorps xmm0,xmm0,xmm0
  410f30:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  410f39:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  410f42:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  410f4b:	vzeroupper
  410f4e:	mov    DWORD PTR [rsp+0x2c0],0x0
  410f59:	vmovsd xmm0,QWORD PTR [rdx]
  410f5d:	vcomisd xmm0,xmm0
  410f61:	setne  dl
  410f64:	movzx  edx,dl
  410f67:	setp   r8b
  410f6b:	movzx  r8d,r8b
  410f6f:	or     edx,r8d
  410f72:	test   dl,dl
  410f74:	je     410f81 <__swc_fn_585f006d_000146_e9d46966+0xa21>
  410f76:	mov    DWORD PTR [rcx],0x6e616e
  410f7c:	jmp    411588 <__swc_fn_585f006d_000146_e9d46966+0x1028>
  410f81:	vcomisd xmm0,xmm11
  410f86:	ja     410f97 <__swc_fn_585f006d_000146_e9d46966+0xa37>
  410f88:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  410f91:	vcomisd xmm6,xmm0
  410f95:	jbe    410fbb <__swc_fn_585f006d_000146_e9d46966+0xa5b>
  410f97:	vxorpd xmm1,xmm1,xmm1
  410f9b:	vcomisd xmm1,xmm0
  410f9f:	jbe    410fb0 <__swc_fn_585f006d_000146_e9d46966+0xa50>
  410fa1:	mov    DWORD PTR [rcx],0x666e692d
  410fa7:	mov    BYTE PTR [rcx+0x4],0x0
  410fab:	jmp    411588 <__swc_fn_585f006d_000146_e9d46966+0x1028>
  410fb0:	mov    DWORD PTR [rcx],0x666e69
  410fb6:	jmp    411588 <__swc_fn_585f006d_000146_e9d46966+0x1028>
  410fbb:	vcomisd xmm0,xmm13
  410fc0:	jae    410fcc <__swc_fn_585f006d_000146_e9d46966+0xa6c>
  410fc2:	vcomisd xmm12,xmm0
  410fc6:	jbe    41132e <__swc_fn_585f006d_000146_e9d46966+0xdce>
  410fcc:	vmovups xmm1,xmm0
  410fd0:	vxorpd xmm2,xmm2,xmm2
  410fd4:	vcomisd xmm2,xmm0
  410fd8:	jbe    410fe8 <__swc_fn_585f006d_000146_e9d46966+0xa88>
  410fda:	vmovsd xmm0,xmm0,xmm1
  410fde:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x156a]        # 412550 <__swc_rdata_base_585f006d+0x440>
  410fe6:	jmp    410fec <__swc_fn_585f006d_000146_e9d46966+0xa8c>
  410fe8:	vmovsd xmm0,xmm0,xmm1
  410fec:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  410ff5:	xor    r8d,r8d
  410ff8:	vcomisd xmm0,xmm6
  410ffc:	jb     41100e <__swc_fn_585f006d_000146_e9d46966+0xaae>
  410ffe:	xchg   ax,ax
  411000:	vdivsd xmm0,xmm0,xmm6
  411004:	add    r8,0x1
  411008:	vcomisd xmm0,xmm6
  41100c:	jae    411000 <__swc_fn_585f006d_000146_e9d46966+0xaa0>
  41100e:	mov    r9,rcx
  411011:	vxorpd xmm2,xmm2,xmm2
  411015:	vcomisd xmm2,xmm1
  411019:	jbe    411022 <__swc_fn_585f006d_000146_e9d46966+0xac2>
  41101b:	mov    BYTE PTR [rcx],0x2d
  41101e:	lea    r9,[rcx+0x1]
  411022:	vcvttsd2si rdx,xmm0
  411027:	mov    r10b,dl
  41102a:	add    r10b,0x30
  41102e:	mov    BYTE PTR [r9],r10b
  411031:	vxorpd xmm1,xmm1,xmm1
  411035:	movzx  edx,dl
  411038:	vcvtsi2sd xmm1,xmm1,rdx
  41103d:	vsubsd xmm0,xmm0,xmm1
  411041:	vmulsd xmm0,xmm0,xmm6
  411045:	mov    BYTE PTR [r9+0x1],0x2e
  41104a:	vcvttsd2si rdx,xmm0
  41104f:	mov    r10b,dl
  411052:	add    r10b,0x30
  411056:	mov    BYTE PTR [r9+0x2],r10b
  41105a:	vxorpd xmm1,xmm1,xmm1
  41105e:	movzx  edx,dl
  411061:	vcvtsi2sd xmm1,xmm1,rdx
  411066:	vsubsd xmm0,xmm0,xmm1
  41106a:	vmulsd xmm0,xmm0,xmm6
  41106e:	vcvttsd2si rdx,xmm0
  411073:	mov    r10b,dl
  411076:	add    r10b,0x30
  41107a:	mov    BYTE PTR [r9+0x3],r10b
  41107e:	vxorpd xmm1,xmm1,xmm1
  411082:	movzx  edx,dl
  411085:	vcvtsi2sd xmm1,xmm1,rdx
  41108a:	vsubsd xmm0,xmm0,xmm1
  41108e:	vmulsd xmm0,xmm0,xmm6
  411092:	vcvttsd2si rdx,xmm0
  411097:	mov    r10b,dl
  41109a:	add    r10b,0x30
  41109e:	mov    BYTE PTR [r9+0x4],r10b
  4110a2:	vxorpd xmm1,xmm1,xmm1
  4110a6:	movzx  edx,dl
  4110a9:	vcvtsi2sd xmm1,xmm1,rdx
  4110ae:	vsubsd xmm0,xmm0,xmm1
  4110b2:	vmulsd xmm0,xmm0,xmm6
  4110b6:	vcvttsd2si rdx,xmm0
  4110bb:	mov    r10b,dl
  4110be:	add    r10b,0x30
  4110c2:	mov    BYTE PTR [r9+0x5],r10b
  4110c6:	vxorpd xmm1,xmm1,xmm1
  4110ca:	movzx  edx,dl
  4110cd:	vcvtsi2sd xmm1,xmm1,rdx
  4110d2:	vsubsd xmm0,xmm0,xmm1
  4110d6:	vmulsd xmm0,xmm0,xmm6
  4110da:	vcvttsd2si rdx,xmm0
  4110df:	mov    r10b,dl
  4110e2:	add    r10b,0x30
  4110e6:	mov    BYTE PTR [r9+0x6],r10b
  4110ea:	vxorpd xmm1,xmm1,xmm1
  4110ee:	movzx  edx,dl
  4110f1:	vcvtsi2sd xmm1,xmm1,rdx
  4110f6:	vsubsd xmm0,xmm0,xmm1
  4110fa:	vmulsd xmm0,xmm0,xmm6
  4110fe:	vcvttsd2si rdx,xmm0
  411103:	mov    r10b,dl
  411106:	add    r10b,0x30
  41110a:	mov    BYTE PTR [r9+0x7],r10b
  41110e:	vxorpd xmm1,xmm1,xmm1
  411112:	movzx  edx,dl
  411115:	vcvtsi2sd xmm1,xmm1,rdx
  41111a:	vsubsd xmm0,xmm0,xmm1
  41111e:	vmulsd xmm0,xmm0,xmm6
  411122:	vcvttsd2si rdx,xmm0
  411127:	mov    r10b,dl
  41112a:	add    r10b,0x30
  41112e:	mov    BYTE PTR [r9+0x8],r10b
  411132:	vxorpd xmm1,xmm1,xmm1
  411136:	movzx  edx,dl
  411139:	vcvtsi2sd xmm1,xmm1,rdx
  41113e:	vsubsd xmm0,xmm0,xmm1
  411142:	vmulsd xmm0,xmm0,xmm6
  411146:	vcvttsd2si rdx,xmm0
  41114b:	mov    r10b,dl
  41114e:	add    r10b,0x30
  411152:	mov    BYTE PTR [r9+0x9],r10b
  411156:	vxorpd xmm1,xmm1,xmm1
  41115a:	movzx  edx,dl
  41115d:	vcvtsi2sd xmm1,xmm1,rdx
  411162:	vsubsd xmm0,xmm0,xmm1
  411166:	vmulsd xmm0,xmm0,xmm6
  41116a:	vcvttsd2si rdx,xmm0
  41116f:	mov    r10b,dl
  411172:	add    r10b,0x30
  411176:	mov    BYTE PTR [r9+0xa],r10b
  41117a:	vxorpd xmm1,xmm1,xmm1
  41117e:	movzx  edx,dl
  411181:	vcvtsi2sd xmm1,xmm1,rdx
  411186:	vsubsd xmm0,xmm0,xmm1
  41118a:	vmulsd xmm0,xmm0,xmm6
  41118e:	vcvttsd2si rdx,xmm0
  411193:	mov    r10b,dl
  411196:	add    r10b,0x30
  41119a:	mov    BYTE PTR [r9+0xb],r10b
  41119e:	lea    r10,[r9+0x4]
  4111a2:	vxorpd xmm1,xmm1,xmm1
  4111a6:	movzx  edx,dl
  4111a9:	vcvtsi2sd xmm1,xmm1,rdx
  4111ae:	vsubsd xmm0,xmm0,xmm1
  4111b2:	vmulsd xmm0,xmm0,xmm6
  4111b6:	vcvttsd2si rdx,xmm0
  4111bb:	mov    r11b,dl
  4111be:	add    r11b,0x30
  4111c2:	mov    BYTE PTR [r9+0xc],r11b
  4111c6:	vxorpd xmm1,xmm1,xmm1
  4111ca:	movzx  edx,dl
  4111cd:	vcvtsi2sd xmm1,xmm1,rdx
  4111d2:	vsubsd xmm0,xmm0,xmm1
  4111d6:	vmulsd xmm0,xmm0,xmm6
  4111da:	vcvttsd2si rdx,xmm0
  4111df:	mov    r11b,dl
  4111e2:	add    r11b,0x30
  4111e6:	mov    BYTE PTR [r9+0xd],r11b
  4111ea:	lea    r10,[r10+0x2]
  4111ee:	vxorpd xmm1,xmm1,xmm1
  4111f2:	movzx  edx,dl
  4111f5:	vcvtsi2sd xmm1,xmm1,rdx
  4111fa:	vsubsd xmm0,xmm0,xmm1
  4111fe:	vmulsd xmm0,xmm0,xmm6
  411202:	vcvttsd2si rdx,xmm0
  411207:	mov    r11b,dl
  41120a:	add    r11b,0x30
  41120e:	mov    BYTE PTR [r9+0xe],r11b
  411212:	vxorpd xmm1,xmm1,xmm1
  411216:	movzx  edx,dl
  411219:	vcvtsi2sd xmm1,xmm1,rdx
  41121e:	vsubsd xmm0,xmm0,xmm1
  411222:	vmulsd xmm0,xmm0,xmm6
  411226:	vcvttsd2si rdx,xmm0
  41122b:	mov    r11b,dl
  41122e:	add    r11b,0x30
  411232:	mov    BYTE PTR [r9+0xf],r11b
  411236:	lea    r10,[r10+0x2]
  41123a:	lea    r10,[r10+0x2]
  41123e:	lea    r10,[r10+0x2]
  411242:	lea    r10,[r10+0x2]
  411246:	lea    r10,[r10+0x2]
  41124a:	vxorpd xmm1,xmm1,xmm1
  41124e:	movzx  edx,dl
  411251:	vcvtsi2sd xmm1,xmm1,rdx
  411256:	vsubsd xmm0,xmm0,xmm1
  41125a:	vmulsd xmm0,xmm0,xmm6
  41125e:	vcvttsd2si rdx,xmm0
  411263:	mov    r11b,dl
  411266:	add    r11b,0x30
  41126a:	mov    BYTE PTR [r9+0x10],r11b
  41126e:	vxorpd xmm1,xmm1,xmm1
  411272:	movzx  edx,dl
  411275:	vcvtsi2sd xmm1,xmm1,rdx
  41127a:	vsubsd xmm0,xmm0,xmm1
  41127e:	vmulsd xmm0,xmm0,xmm6
  411282:	vcvttsd2si rdx,xmm0
  411287:	add    dl,0x30
  41128a:	mov    BYTE PTR [r9+0x11],dl
  41128e:	mov    BYTE PTR [r10+0x2],0x65
  411293:	lea    r9,[r10+0x3]
  411297:	test   r8,r8
  41129a:	jl     4112a3 <__swc_fn_585f006d_000146_e9d46966+0xd43>
  41129c:	mov    BYTE PTR [r9],0x2b
  4112a0:	inc    r9
  4112a3:	mov    r10,r9
  4112a6:	mov    rdx,r8
  4112a9:	nop    DWORD PTR [rax+0x0]
  4112b0:	mov    r11,rdx
  4112b3:	movabs rdx,0x6666666666666667
  4112bd:	mov    rax,r11
  4112c0:	imul   rdx
  4112c3:	sar    rdx,0x2
  4112c7:	mov    r12,rdx
  4112ca:	shr    rdx,0x3f
  4112ce:	add    r12,rdx
  4112d1:	mov    rdx,r12
  4112d4:	imul   r13,r12,0xa
  4112d8:	sub    r11,r13
  4112db:	mov    r13,QWORD PTR [rip+0x125e]        # 412540 <__swc_rdata_base_585f006d+0x430>
  4112e2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4112e7:	mov    BYTE PTR [r10],r11b
  4112ea:	lea    r11,[r10+0x1]
  4112ee:	mov    r10,r11
  4112f1:	test   r12,r12
  4112f4:	jne    4112b0 <__swc_fn_585f006d_000146_e9d46966+0xd50>
  4112f6:	test   r8,r8
  4112f9:	jge    411303 <__swc_fn_585f006d_000146_e9d46966+0xda3>
  4112fb:	mov    BYTE PTR [r11],0x2d
  4112ff:	lea    r10,[r11+0x1]
  411303:	mov    BYTE PTR [r10],0x0
  411307:	sub    r10,0x1
  41130b:	nop    DWORD PTR [rax+rax*1+0x0]
  411310:	cmp    r9,r10
  411313:	jae    411588 <__swc_fn_585f006d_000146_e9d46966+0x1028>
  411319:	mov    al,BYTE PTR [r10]
  41131c:	mov    dl,BYTE PTR [r9]
  41131f:	mov    BYTE PTR [r10],dl
  411322:	sub    r10,0x1
  411326:	mov    BYTE PTR [r9],al
  411329:	inc    r9
  41132c:	jmp    411310 <__swc_fn_585f006d_000146_e9d46966+0xdb0>
  41132e:	vcvttsd2si rdx,xmm0
  411333:	mov    r8,rdx
  411336:	vxorpd xmm1,xmm1,xmm1
  41133a:	vcvtsi2sd xmm1,xmm1,rdx
  41133f:	vsubsd xmm1,xmm0,xmm1
  411343:	mov    r9d,0x8
  411349:	vxorpd xmm2,xmm2,xmm2
  41134d:	vcomisd xmm2,xmm1
  411351:	ja     41135e <__swc_fn_585f006d_000146_e9d46966+0xdfe>
  411353:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41135c:	jmp    41136f <__swc_fn_585f006d_000146_e9d46966+0xe0f>
  41135e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x11ea]        # 412550 <__swc_rdata_base_585f006d+0x440>
  411366:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41136f:	test   r9d,r9d
  411372:	je     411389 <__swc_fn_585f006d_000146_e9d46966+0xe29>
  411374:	cs nop WORD PTR [rax+rax*1+0x0]
  41137e:	xchg   ax,ax
  411380:	vmulsd xmm1,xmm1,xmm6
  411384:	dec    r9d
  411387:	jne    411380 <__swc_fn_585f006d_000146_e9d46966+0xe20>
  411389:	vcvttsd2si r9,xmm1
  41138e:	mov    r10,r9
  411391:	vxorpd xmm2,xmm2,xmm2
  411395:	vcvtsi2sd xmm2,xmm2,r9
  41139a:	vsubsd xmm1,xmm1,xmm2
  41139e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  4113a7:	vcomisd xmm1,xmm6
  4113ab:	lea    r9,[r9+0x1]
  4113af:	cmova  r10,r9
  4113b3:	cmp    r10,0x5f5e100
  4113ba:	jne    4113d3 <__swc_fn_585f006d_000146_e9d46966+0xe73>
  4113bc:	lea    r8,[rdx-0x1]
  4113c0:	vxorpd xmm1,xmm1,xmm1
  4113c4:	vcomisd xmm1,xmm0
  4113c8:	lea    rdx,[rdx+0x1]
  4113cc:	cmovbe r8,rdx
  4113d0:	xor    r10d,r10d
  4113d3:	mov    r9,rcx
  4113d6:	test   r8,r8
  4113d9:	jne    4113f9 <__swc_fn_585f006d_000146_e9d46966+0xe99>
  4113db:	vxorpd xmm1,xmm1,xmm1
  4113df:	vcomisd xmm1,xmm0
  4113e3:	jbe    4113ec <__swc_fn_585f006d_000146_e9d46966+0xe8c>
  4113e5:	mov    BYTE PTR [rcx],0x2d
  4113e8:	lea    r9,[rcx+0x1]
  4113ec:	mov    BYTE PTR [r9],0x30
  4113f0:	add    r9,0x1
  4113f4:	jmp    41148b <__swc_fn_585f006d_000146_e9d46966+0xf2b>
  4113f9:	mov    r9,rcx
  4113fc:	mov    rdx,r8
  4113ff:	nop
  411400:	mov    r11,rdx
  411403:	movabs rdx,0x6666666666666667
  41140d:	mov    r15,rax
  411410:	mov    rax,r11
  411413:	imul   rdx
  411416:	mov    r12,rdx
  411419:	mov    rax,r15
  41141c:	sar    r12,0x2
  411420:	mov    rdx,r12
  411423:	shr    rdx,0x3f
  411427:	add    r12,rdx
  41142a:	mov    rdx,r12
  41142d:	imul   r13,r12,0xa
  411431:	sub    r11,r13
  411434:	mov    r13,QWORD PTR [rip+0x1105]        # 412540 <__swc_rdata_base_585f006d+0x430>
  41143b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411440:	mov    BYTE PTR [r9],r11b
  411443:	lea    r11,[r9+0x1]
  411447:	mov    r9,r11
  41144a:	test   r12,r12
  41144d:	jne    411400 <__swc_fn_585f006d_000146_e9d46966+0xea0>
  41144f:	test   r8,r8
  411452:	jge    41145c <__swc_fn_585f006d_000146_e9d46966+0xefc>
  411454:	mov    BYTE PTR [r11],0x2d
  411458:	lea    r9,[r11+0x1]
  41145c:	mov    rdx,r9
  41145f:	mov    BYTE PTR [r9],0x0
  411463:	sub    r9,0x1
  411467:	mov    r8,rcx
  41146a:	cmp    r8,r9
  41146d:	jae    411488 <__swc_fn_585f006d_000146_e9d46966+0xf28>
  41146f:	nop
  411470:	mov    r11b,BYTE PTR [r9]
  411473:	mov    r12b,BYTE PTR [r8]
  411476:	mov    BYTE PTR [r9],r12b
  411479:	sub    r9,0x1
  41147d:	mov    BYTE PTR [r8],r11b
  411480:	inc    r8
  411483:	cmp    r8,r9
  411486:	jb     411470 <__swc_fn_585f006d_000146_e9d46966+0xf10>
  411488:	mov    r9,rdx
  41148b:	mov    BYTE PTR [r9],0x2e
  41148f:	add    r9,0x1
  411493:	xor    r8d,r8d
  411496:	test   r10,r10
  411499:	je     4114df <__swc_fn_585f006d_000146_e9d46966+0xf7f>
  41149b:	mov    r11d,0x989680
  4114a1:	cmp    r10,r11
  4114a4:	jge    4114df <__swc_fn_585f006d_000146_e9d46966+0xf7f>
  4114a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4114b0:	inc    r8d
  4114b3:	movabs rdx,0x6666666666666667
  4114bd:	mov    r15,rax
  4114c0:	mov    rax,r11
  4114c3:	imul   rdx
  4114c6:	mov    r11,rdx
  4114c9:	mov    rax,r15
  4114cc:	sar    r11,0x2
  4114d0:	mov    rdx,r11
  4114d3:	shr    rdx,0x3f
  4114d7:	add    r11,rdx
  4114da:	cmp    r10,r11
  4114dd:	jl     4114b0 <__swc_fn_585f006d_000146_e9d46966+0xf50>
  4114df:	test   r8d,r8d
  4114e2:	je     4114fd <__swc_fn_585f006d_000146_e9d46966+0xf9d>
  4114e4:	cs nop WORD PTR [rax+rax*1+0x0]
  4114ee:	xchg   ax,ax
  4114f0:	mov    BYTE PTR [r9],0x30
  4114f4:	add    r9,0x1
  4114f8:	dec    r8d
  4114fb:	jne    4114f0 <__swc_fn_585f006d_000146_e9d46966+0xf90>
  4114fd:	mov    r8,r9
  411500:	mov    rdx,r10
  411503:	cs nop WORD PTR [rax+rax*1+0x0]
  41150d:	nop    DWORD PTR [rax]
  411510:	mov    r11,rdx
  411513:	movabs rdx,0x6666666666666667
  41151d:	mov    rax,r11
  411520:	imul   rdx
  411523:	sar    rdx,0x2
  411527:	mov    r12,rdx
  41152a:	shr    rdx,0x3f
  41152e:	add    r12,rdx
  411531:	mov    rdx,r12
  411534:	imul   r13,r12,0xa
  411538:	sub    r11,r13
  41153b:	mov    r13,QWORD PTR [rip+0xffe]        # 412540 <__swc_rdata_base_585f006d+0x430>
  411542:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411547:	mov    BYTE PTR [r8],r11b
  41154a:	lea    r11,[r8+0x1]
  41154e:	mov    r8,r11
  411551:	test   r12,r12
  411554:	jne    411510 <__swc_fn_585f006d_000146_e9d46966+0xfb0>
  411556:	test   r10,r10
  411559:	jge    411563 <__swc_fn_585f006d_000146_e9d46966+0x1003>
  41155b:	mov    BYTE PTR [r11],0x2d
  41155f:	lea    r8,[r11+0x1]
  411563:	mov    BYTE PTR [r8],0x0
  411567:	sub    r8,0x1
  41156b:	cmp    r9,r8
  41156e:	jae    411588 <__swc_fn_585f006d_000146_e9d46966+0x1028>
  411570:	mov    al,BYTE PTR [r8]
  411573:	mov    dl,BYTE PTR [r9]
  411576:	mov    BYTE PTR [r8],dl
  411579:	sub    r8,0x1
  41157d:	mov    BYTE PTR [r9],al
  411580:	inc    r9
  411583:	cmp    r9,r8
  411586:	jb     411570 <__swc_fn_585f006d_000146_e9d46966+0x1010>
  411588:	xor    eax,eax
  41158a:	test   rcx,rcx
  41158d:	je     4115b0 <__swc_fn_585f006d_000146_e9d46966+0x1050>
  41158f:	mov    rdx,rcx
  411592:	mov    r8b,BYTE PTR [rdx]
  411595:	test   r8b,r8b
  411598:	je     4115b0 <__swc_fn_585f006d_000146_e9d46966+0x1050>
  41159a:	nop    WORD PTR [rax+rax*1+0x0]
  4115a0:	add    rdx,0x1
  4115a4:	add    rax,0x1
  4115a8:	mov    r8b,BYTE PTR [rdx]
  4115ab:	test   r8b,r8b
  4115ae:	jne    4115a0 <__swc_fn_585f006d_000146_e9d46966+0x1040>
  4115b0:	mov    QWORD PTR [rsp+0x3f8],rcx
  4115b8:	mov    QWORD PTR [rsp+0x400],rax
  4115c0:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  4115c9:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  4115d2:	lea    rcx,[rsp+0x408]
  4115da:	call   40fcf0 <__swc_fn_585f006d_000116_3499f7d6>
  4115df:	jmp    411625 <__swc_fn_585f006d_000146_e9d46966+0x10c5>
  4115e1:	mov    rcx,rdx
  4115e4:	call   40fcf0 <__swc_fn_585f006d_000116_3499f7d6>
  4115e9:	jmp    411625 <__swc_fn_585f006d_000146_e9d46966+0x10c5>
  4115eb:	mov    al,BYTE PTR [rdx]
  4115ed:	test   al,al
  4115ef:	je     4115fa <__swc_fn_585f006d_000146_e9d46966+0x109a>
  4115f1:	lea    rax,[rip+0xf68]        # 412560 <__swc_rdata_base_585f006d+0x450>
  4115f8:	jmp    411601 <__swc_fn_585f006d_000146_e9d46966+0x10a1>
  4115fa:	lea    rax,[rip+0xf6f]        # 412570 <__swc_rdata_base_585f006d+0x460>
  411601:	mov    rcx,rax
  411604:	call   40fcf0 <__swc_fn_585f006d_000116_3499f7d6>
  411609:	jmp    411625 <__swc_fn_585f006d_000146_e9d46966+0x10c5>
  41160b:	lea    rcx,[rip+0xf6e]        # 412580 <__swc_rdata_base_585f006d+0x470>
  411612:	call   40fcf0 <__swc_fn_585f006d_000116_3499f7d6>
  411617:	jmp    411625 <__swc_fn_585f006d_000146_e9d46966+0x10c5>
  411619:	lea    rcx,[rip+0xf60]        # 412580 <__swc_rdata_base_585f006d+0x470>
  411620:	call   40fcf0 <__swc_fn_585f006d_000116_3499f7d6>
  411625:	add    rdi,0x1
  411629:	sub    rsi,0x1
  41162d:	vmovups xmm0,xmm12
  411632:	vmovsd xmm6,QWORD PTR [rip+0xf56]        # 412590 <__swc_rdata_base_585f006d+0x480>
  41163a:	test   rsi,rsi
  41163d:	jne    410670 <__swc_fn_585f006d_000146_e9d46966+0x110>
  411643:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  41164c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  411655:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  41165e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411667:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411670:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411679:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411682:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  41168b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411694:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  41169d:	add    rsp,0x4e8
  4116a4:	pop    r15
  4116a6:	pop    r13
  4116a8:	pop    r12
  4116aa:	pop    rdi
  4116ab:	pop    rsi
  4116ac:	pop    rbx
  4116ad:	ret
	...

00000000004116b0 <__swc_fn_585f006d_000149_33e5e24f>:
  4116b0:	vxorps xmm0,xmm0,xmm0
  4116b4:	vmovups XMMWORD PTR [rcx],xmm0
  4116b8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4116bd:	ret
	...

00000000004116c0 <__swc_fn_585f006d_000152_33e5e24f>:
  4116c0:	vxorps xmm0,xmm0,xmm0
  4116c4:	vmovups XMMWORD PTR [rcx],xmm0
  4116c8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4116cd:	vxorps xmm0,xmm0,xmm0
  4116d1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4116d6:	vmovups xmm0,XMMWORD PTR [rip+0xfc2]        # 4126a0 <__swc_rdata_base_585f006d+0x590>
  4116de:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4116e3:	vxorps xmm0,xmm0,xmm0
  4116e7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  4116ec:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  4116f1:	vxorps xmm0,xmm0,xmm0
  4116f5:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  4116fa:	mov    QWORD PTR [rcx+0x70],0x0
  411702:	ret
	...

0000000000411710 <__swc_fn_585f006d_000155_33e5e24f>:
  411710:	vxorps xmm0,xmm0,xmm0
  411714:	vmovups XMMWORD PTR [rcx],xmm0
  411718:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41171d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411722:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411727:	ret
	...

0000000000411730 <__swc_fn_585f006d_000158_6741c23b>:
  411730:	push   rsi
  411731:	push   rdi
  411732:	sub    rsp,0x8
  411736:	mov    rsi,rcx
  411739:	mov    rdi,QWORD PTR [rsi+0x50]
  41173d:	test   rdi,rdi
  411740:	je     411747 <__swc_fn_585f006d_000158_6741c23b+0x17>
  411742:	mov    rcx,rsi
  411745:	call   rdi
  411747:	mov    QWORD PTR [rsi+0x20],0x0
  41174f:	mov    rax,QWORD PTR [rsi+0x30]
  411753:	test   rax,rax
  411756:	je     411784 <__swc_fn_585f006d_000158_6741c23b+0x54>
  411758:	nop    DWORD PTR [rax+rax*1+0x0]
  411760:	mov    rdi,QWORD PTR [rax+0x8]
  411764:	mov    rcx,rsi
  411767:	mov    rdx,QWORD PTR [rax+0x10]
  41176b:	mov    rax,QWORD PTR [rax+0x18]
  41176f:	mov    r8,rax
  411772:	call   409e90 <__swc_fn_585f006d_000156_312df05a>
  411777:	mov    QWORD PTR [rsi+0x30],rdi
  41177b:	mov    rax,QWORD PTR [rsi+0x30]
  41177f:	test   rax,rax
  411782:	jne    411760 <__swc_fn_585f006d_000158_6741c23b+0x30>
  411784:	mov    QWORD PTR [rsi+0x38],0x0
  41178c:	add    rsp,0x8
  411790:	pop    rdi
  411791:	pop    rsi
  411792:	ret
	...

00000000004117a0 <__swc_fn_585f006d_000161_9e36e814>:
  4117a0:	push   rbx
  4117a1:	push   rsi
  4117a2:	push   rdi
  4117a3:	push   r12
  4117a5:	sub    rsp,0x188
  4117ac:	mov    rbx,rcx
  4117af:	lea    rsi,[rip+0x145da]        # 425d90 <__swc_bss_base_585f006d+0x2d50>
  4117b6:	mov    rcx,rsi
  4117b9:	call   4098a0 <__swc_fn_585f006d_000135_1fec60ac>
  4117be:	mov    rax,QWORD PTR [rip+0x145d3]        # 425d98 <__swc_bss_base_585f006d+0x2d58>
  4117c5:	mov    rdi,rax
  4117c8:	test   rdi,rdi
  4117cb:	je     4117f9 <__swc_fn_585f006d_000161_9e36e814+0x59>
  4117cd:	nop    DWORD PTR [rax]
  4117d0:	cmp    QWORD PTR [rdi+0x8],rbx
  4117d4:	jne    4117ee <__swc_fn_585f006d_000161_9e36e814+0x4e>
  4117d6:	mov    rcx,rsi
  4117d9:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  4117de:	mov    rax,rdi
  4117e1:	add    rsp,0x188
  4117e8:	pop    r12
  4117ea:	pop    rdi
  4117eb:	pop    rsi
  4117ec:	pop    rbx
  4117ed:	ret
  4117ee:	mov    rax,QWORD PTR [rdi]
  4117f1:	mov    rdi,rax
  4117f4:	test   rax,rax
  4117f7:	jne    4117d0 <__swc_fn_585f006d_000161_9e36e814+0x30>
  4117f9:	call   40ce80 <__swc_fn_585f006d_000139_20e2e2c7>
  4117fe:	mov    rdi,rax
  411801:	test   rax,rax
  411804:	jne    41181d <__swc_fn_585f006d_000161_9e36e814+0x7d>
  411806:	mov    rcx,rsi
  411809:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  41180e:	xor    eax,eax
  411810:	add    rsp,0x188
  411817:	pop    r12
  411819:	pop    rdi
  41181a:	pop    rsi
  41181b:	pop    rbx
  41181c:	ret
  41181d:	lea    rax,[rsp+0x18]
  411822:	mov    QWORD PTR [rax+0x10],0x0
  41182a:	mov    QWORD PTR [rax+0x18],0x0
  411832:	mov    DWORD PTR [rax+0x20],0x0
  411839:	mov    BYTE PTR [rax+0x24],0x0
  41183d:	mov    rax,QWORD PTR [rip+0x14554]        # 425d98 <__swc_bss_base_585f006d+0x2d58>
  411844:	mov    QWORD PTR [rsp+0x18],rax
  411849:	mov    QWORD PTR [rsp+0x20],rbx
  41184e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411854:	vmovups XMMWORD PTR [rdi],xmm0
  411858:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  41185e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  411863:	mov    rax,QWORD PTR [rsp+0x38]
  411868:	mov    QWORD PTR [rdi+0x20],rax
  41186c:	mov    QWORD PTR [rip+0x14525],rdi        # 425d98 <__swc_bss_base_585f006d+0x2d58>
  411873:	lea    rax,[rsp+0x40]
  411878:	mov    QWORD PTR [rax],0x0
  41187f:	mov    rcx,rbx
  411882:	mov    rdx,rax
  411885:	call   409980 <__swc_fn_585f006d_000141_376d5f6d>
  41188a:	mov    rbx,rax
  41188d:	test   rax,rax
  411890:	jne    4118aa <__swc_fn_585f006d_000161_9e36e814+0x10a>
  411892:	mov    rcx,rsi
  411895:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  41189a:	mov    rax,rdi
  41189d:	add    rsp,0x188
  4118a4:	pop    r12
  4118a6:	pop    rdi
  4118a7:	pop    rsi
  4118a8:	pop    rbx
  4118a9:	ret
  4118aa:	lea    r12,[rsp+0x50]
  4118af:	mov    QWORD PTR [r12],0x0
  4118b7:	mov    rcx,rbx
  4118ba:	mov    rdx,QWORD PTR [rsp+0x40]
  4118bf:	mov    r8,r12
  4118c2:	call   40cf30 <__swc_fn_585f006d_000142_e0543f36>
  4118c7:	test   rax,rax
  4118ca:	jne    4118e4 <__swc_fn_585f006d_000161_9e36e814+0x144>
  4118cc:	mov    rcx,rsi
  4118cf:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  4118d4:	mov    rax,rdi
  4118d7:	add    rsp,0x188
  4118de:	pop    r12
  4118e0:	pop    rdi
  4118e1:	pop    rsi
  4118e2:	pop    rbx
  4118e3:	ret
  4118e4:	cmp    QWORD PTR [r12],0x10
  4118e9:	jb     4119ec <__swc_fn_585f006d_000161_9e36e814+0x24c>
  4118ef:	mov    ecx,DWORD PTR [rax]
  4118f1:	cmp    ecx,0x42445753
  4118f7:	jne    4119ec <__swc_fn_585f006d_000161_9e36e814+0x24c>
  4118fd:	mov    ecx,DWORD PTR [rax+0x4]
  411900:	cmp    ecx,0x1
  411903:	jne    4119ec <__swc_fn_585f006d_000161_9e36e814+0x24c>
  411909:	mov    ecx,DWORD PTR [rax+0x8]
  41190c:	mov    edx,DWORD PTR [rax+0xc]
  41190f:	imul   r8,rcx,0x14
  411913:	mov    r9,QWORD PTR [rsp+0x50]
  411918:	sub    r9,0x10
  41191c:	cmp    r8,r9
  41191f:	ja     4119ec <__swc_fn_585f006d_000161_9e36e814+0x24c>
  411925:	lea    r8,[r8+0x10]
  411929:	cmp    rdx,r8
  41192c:	jb     4119ec <__swc_fn_585f006d_000161_9e36e814+0x24c>
  411932:	mov    r8,QWORD PTR [rsp+0x50]
  411937:	cmp    rdx,r8
  41193a:	ja     4119ec <__swc_fn_585f006d_000161_9e36e814+0x24c>
  411940:	xor    r8d,r8d
  411943:	test   rcx,rcx
  411946:	jbe    411a12 <__swc_fn_585f006d_000161_9e36e814+0x272>
  41194c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  411952:	cs nop WORD PTR [rax+rax*1+0x0]
  41195c:	nop    DWORD PTR [rax+0x0]
  411960:	imul   r9,r8,0x14
  411964:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  411969:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  41196e:	add    r10,r11
  411971:	movabs r11,0x100000000
  41197b:	cmp    r10,r11
  41197e:	ja     4119ec <__swc_fn_585f006d_000161_9e36e814+0x24c>
  411980:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  411985:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  41198a:	test   r10d,r10d
  41198d:	setne  r11b
  411991:	je     4119ab <__swc_fn_585f006d_000161_9e36e814+0x20b>
  411993:	cmp    r10d,edx
  411996:	setb   r11b
  41199a:	jb     4119ab <__swc_fn_585f006d_000161_9e36e814+0x20b>
  41199c:	vmovq  r11,xmm1
  4119a1:	cmp    r10,r11
  4119a4:	setae  r10b
  4119a8:	mov    r11b,r10b
  4119ab:	mov    r10,r11
  4119ae:	test   r11b,r11b
  4119b1:	jne    4119d8 <__swc_fn_585f006d_000161_9e36e814+0x238>
  4119b3:	test   r9d,r9d
  4119b6:	setne  r10b
  4119ba:	je     4119d8 <__swc_fn_585f006d_000161_9e36e814+0x238>
  4119bc:	cmp    r9d,edx
  4119bf:	setb   r10b
  4119c3:	jb     4119d8 <__swc_fn_585f006d_000161_9e36e814+0x238>
  4119c5:	vmovq  r10,xmm1
  4119ca:	cmp    r9,r10
  4119cd:	setae  r9b
  4119d1:	movzx  r9d,r9b
  4119d5:	mov    r10b,r9b
  4119d8:	test   r10b,r10b
  4119db:	jne    4119ec <__swc_fn_585f006d_000161_9e36e814+0x24c>
  4119dd:	add    r8,0x1
  4119e1:	cmp    r8,rcx
  4119e4:	jb     411960 <__swc_fn_585f006d_000161_9e36e814+0x1c0>
  4119ea:	jmp    411a12 <__swc_fn_585f006d_000161_9e36e814+0x272>
  4119ec:	xor    ecx,ecx
  4119ee:	cmp    rax,rbx
  4119f1:	cmovne rcx,rax
  4119f5:	call   4104b0 <__swc_fn_585f006d_000143_afffe963>
  4119fa:	mov    rcx,rsi
  4119fd:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  411a02:	mov    rax,rdi
  411a05:	add    rsp,0x188
  411a0c:	pop    r12
  411a0e:	pop    rdi
  411a0f:	pop    rsi
  411a10:	pop    rbx
  411a11:	ret
  411a12:	mov    QWORD PTR [rdi+0x10],rax
  411a16:	mov    rcx,QWORD PTR [rsp+0x50]
  411a1b:	mov    QWORD PTR [rdi+0x18],rcx
  411a1f:	mov    eax,DWORD PTR [rax+0x8]
  411a22:	mov    DWORD PTR [rdi+0x20],eax
  411a25:	rex mov BYTE PTR [rdi+0x24],0x1
  411a2a:	mov    rcx,rsi
  411a2d:	call   40ce70 <__swc_fn_585f006d_000136_5589b4a1>
  411a32:	mov    rax,rdi
  411a35:	add    rsp,0x188
  411a3c:	pop    r12
  411a3e:	pop    rdi
  411a3f:	pop    rsi
  411a40:	pop    rbx
  411a41:	ret
	...

0000000000411a50 <__swc_fn_585f006d_000164_15b66a30>:
  411a50:	push   rsi
  411a51:	push   rdi
  411a52:	push   r12
  411a54:	mov    rsi,rdx
  411a57:	mov    rdi,rcx
  411a5a:	mov    rcx,QWORD PTR [rip+0x142df]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  411a61:	test   rcx,rcx
  411a64:	jne    411a76 <__swc_fn_585f006d_000164_15b66a30+0x26>
  411a66:	call   40a1a0 <__swc_fn_585f006d_000165_e09accff>
  411a6b:	lea    rcx,[rax+0x1]
  411a6f:	mov    QWORD PTR [rip+0x142ca],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  411a76:	dec    rcx
  411a79:	call   411aa0 <__swc_fn_585f006d_000167_3130645d>
  411a7e:	mov    r12,QWORD PTR [rax+0xbe0]
  411a85:	test   r12,r12
  411a88:	setne  al
  411a8b:	je     411a96 <__swc_fn_585f006d_000164_15b66a30+0x46>
  411a8d:	mov    rcx,rdi
  411a90:	mov    rdx,rsi
  411a93:	call   r12
  411a96:	pop    r12
  411a98:	pop    rdi
  411a99:	pop    rsi
  411a9a:	ret
  411a9b:	add    BYTE PTR [rax],al
  411a9d:	add    BYTE PTR [rax],al
	...

0000000000411aa0 <__swc_fn_585f006d_000167_3130645d>:
  411aa0:	push   r12
  411aa2:	push   rdi
  411aa3:	push   rsi
  411aa4:	sub    rsp,0xd0
  411aab:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  411ab1:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  411ab7:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  411abd:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  411ac3:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  411ac9:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  411acf:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  411ad8:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  411ae1:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  411aea:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  411af3:	mov    r12,rcx
  411af6:	mov    edi,ecx
  411af8:	xor    eax,eax
  411afa:	call   407000 <pthread_getspecific@plt>
  411aff:	test   rax,rax
  411b02:	je     411b06 <__swc_fn_585f006d_000167_3130645d+0x66>
  411b04:	jmp    411b0e <__swc_fn_585f006d_000167_3130645d+0x6e>
  411b06:	mov    rcx,r12
  411b09:	call   40a200 <__swc_fn_585f006d_000168_0ff0458f>
  411b0e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  411b14:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  411b1a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  411b20:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  411b26:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  411b2c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  411b32:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  411b3b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  411b44:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  411b4d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  411b56:	add    rsp,0xd0
  411b5d:	pop    rsi
  411b5e:	pop    rdi
  411b5f:	pop    r12
  411b61:	ret
	...

0000000000411b70 <__swc_fn_585f006d_000170_8b7c1b80>:
  411b70:	push   rsi
  411b71:	sub    rsp,0x30
  411b75:	lea    rsi,[rip+0x1422c]        # 425da8 <__swc_bss_base_585f006d+0x2d68>
  411b7c:	mov    rax,QWORD PTR [rsi]
  411b7f:	test   rax,rax
  411b82:	je     411b8a <__swc_fn_585f006d_000170_8b7c1b80+0x1a>
  411b84:	add    rsp,0x30
  411b88:	pop    rsi
  411b89:	ret
  411b8a:	mov    ecx,0x3
  411b8f:	mov    edx,0x10
  411b94:	call   40f610 <__swc_fn_585f006d_000107_ff529476>
  411b99:	test   rax,rax
  411b9c:	jne    411bad <__swc_fn_585f006d_000170_8b7c1b80+0x3d>
  411b9e:	mov    QWORD PTR [rsp+0x18],rax
  411ba3:	call   40c9d0 <__swc_fn_585f006d_000118_2b35b5e0>
  411ba8:	mov    rax,QWORD PTR [rsp+0x18]
  411bad:	mov    rcx,rax
  411bb0:	xchg   QWORD PTR [rsi],rcx
  411bb3:	add    rsp,0x30
  411bb7:	pop    rsi
  411bb8:	ret
  411bb9:	add    BYTE PTR [rax],al
  411bbb:	add    BYTE PTR [rax],al
  411bbd:	add    BYTE PTR [rax],al
	...

0000000000411bc0 <__swc_fn_585f006d_000173_156cb9fe>:
  411bc0:	push   rsi
  411bc1:	push   rdi
  411bc2:	sub    rsp,0x8
  411bc6:	mov    rsi,rdx
  411bc9:	mov    rdi,rcx
  411bcc:	mov    rax,QWORD PTR [rsi+0x8]
  411bd0:	test   rax,rax
  411bd3:	je     411bdd <__swc_fn_585f006d_000173_156cb9fe+0x1d>
  411bd5:	mov    rcx,QWORD PTR [rsi]
  411bd8:	mov    QWORD PTR [rax],rcx
  411bdb:	jmp    411be4 <__swc_fn_585f006d_000173_156cb9fe+0x24>
  411bdd:	mov    rax,QWORD PTR [rsi]
  411be0:	mov    QWORD PTR [rdi+0x8],rax
  411be4:	mov    rax,QWORD PTR [rsi]
  411be7:	test   rax,rax
  411bea:	je     411bf4 <__swc_fn_585f006d_000173_156cb9fe+0x34>
  411bec:	mov    rcx,QWORD PTR [rsi+0x8]
  411bf0:	mov    QWORD PTR [rax+0x8],rcx
  411bf4:	mov    rcx,rdi
  411bf7:	mov    rdx,QWORD PTR [rsi+0x10]
  411bfb:	mov    r8,QWORD PTR [rsi+0x18]
  411bff:	mov    r9,0xffffffffffffffff
  411c06:	call   40d580 <__swc_fn_585f006d_000172_9a88b1d5>
  411c0b:	mov    QWORD PTR [rsi+0x18],0x0
  411c13:	mov    rax,QWORD PTR [rdi+0x8]
  411c17:	test   rax,rax
  411c1a:	jne    411c2c <__swc_fn_585f006d_000173_156cb9fe+0x6c>
  411c1c:	call   411b70 <__swc_fn_585f006d_000170_8b7c1b80>
  411c21:	xor    ecx,ecx
  411c23:	mov    QWORD PTR [rax+0x8],rcx
  411c27:	xor    ecx,ecx
  411c29:	mov    QWORD PTR [rax],rcx
  411c2c:	add    rsp,0x8
  411c30:	pop    rdi
  411c31:	pop    rsi
  411c32:	ret
	...

0000000000411c40 <__swc_fn_585f006d_000176_5d3d19bd>:
  411c40:	push   rbx
  411c41:	sub    rsp,0x70
  411c45:	test   rcx,rcx
  411c48:	jne    411c50 <__swc_fn_585f006d_000176_5d3d19bd+0x10>
  411c4a:	add    rsp,0x70
  411c4e:	pop    rbx
  411c4f:	ret
  411c50:	vxorps xmm0,xmm0,xmm0
  411c54:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  411c5a:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  411c60:	vzeroupper
  411c63:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  411c69:	lea    rax,[rcx-0x10]
  411c6d:	mov    QWORD PTR [rsp+0x48],rax
  411c72:	mov    rax,QWORD PTR [rcx-0x10]
  411c76:	mov    QWORD PTR [rsp+0x50],rax
  411c7b:	mov    rcx,QWORD PTR [rip+0x140be]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  411c82:	test   rcx,rcx
  411c85:	jne    411c97 <__swc_fn_585f006d_000176_5d3d19bd+0x57>
  411c87:	call   40a1a0 <__swc_fn_585f006d_000165_e09accff>
  411c8c:	lea    rcx,[rax+0x1]
  411c90:	mov    QWORD PTR [rip+0x140a9],rcx        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  411c97:	dec    rcx
  411c9a:	call   411aa0 <__swc_fn_585f006d_000167_3130645d>
  411c9f:	mov    rcx,QWORD PTR [rax]
  411ca2:	lea    rdx,[rsp+0x8]
  411ca7:	mov    rbx,QWORD PTR [rax+0x8]
  411cab:	mov    rbx,QWORD PTR [rbx+0x18]
  411caf:	call   rbx
  411cb1:	add    rsp,0x70
  411cb5:	pop    rbx
  411cb6:	ret
