
/workspace/prompt2-20261115/batch9-audited-micro/base/nbody/nbody:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <getpid@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <getpid@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <munmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <munmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <exit@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <exit@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <pthread_key_create@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <pthread_key_create@GLIBC_2.34>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_setspecific@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <pthread_setspecific@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <syscall@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <syscall@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dladdr@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <dladdr@GLIBC_2.34>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <open@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <open@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <lseek@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <lseek@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <close@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <close@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <mmap@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <mmap@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <malloc@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <malloc@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <madvise@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf9a]        # 413080 <madvise@GLIBC_2.2.5>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <pthread_key_delete@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf92]        # 413088 <pthread_key_delete@GLIBC_2.34>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <gettid@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf8a]        # 413090 <gettid@GLIBC_2.30>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <clock_gettime@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf82]        # 413098 <clock_gettime@GLIBC_2.17>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <flock@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf7a]        # 4130a0 <flock@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <__errno_location@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf72]        # 4130a8 <__errno_location@GLIBC_2.2.5>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <opendir@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf6a]        # 4130b0 <opendir@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <dirfd@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf62]        # 4130b8 <dirfd@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <readdir@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <readdir@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <readlinkat@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <readlinkat@GLIBC_2.4>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <openat@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <openat@GLIBC_2.4>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <closedir@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <closedir@GLIBC_2.2.5>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <memfd_create@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <memfd_create@GLIBC_2.27>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <ftruncate@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <ftruncate@GLIBC_2.2.5>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <write@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <write@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <backtrace@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <backtrace@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <__x86_get_cpuid_feature_leaf@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <free@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <free@GLIBC_2.2.5>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_6b1cf01f_000176_0ce64436+0x17e0>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40c9a0 <__swc_fn_6b1cf01f_000121_71a5b1cd>
  40724e:	xor    ecx,ecx
  407250:	call   40c0c0 <__swc_fn_6b1cf01f_000094_335e9a12>
  407255:	call   411820 <__swc_fn_6b1cf01f_000176_0ce64436>
  40725a:	call   40ee70 <__swc_fn_6b1cf01f_000095_a3245f7e>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_6b1cf01f_000000_29b04951>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_6b1cf01f_000003_644dadb7>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_6b1cf01f_000003_644dadb7+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   409240 <__swc_fn_6b1cf01f_000111_e724f834>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_6b1cf01f_000003_644dadb7+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1cd81]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1cd7a]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_6b1cf01f_000003_644dadb7+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_6b1cf01f_000003_644dadb7+0x30>
  4072e6:	lea    rcx,[rip+0x1cd63]        # 424050 <__swc_bss_base_6b1cf01f+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1cd5c]        # 424050 <__swc_bss_base_6b1cf01f+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_6b1cf01f_000003_644dadb7+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_6b1cf01f_000003_644dadb7+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_6b1cf01f_000006_12cb36a2>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40d720 <__swc_fn_6b1cf01f_000011_e75d466d>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_6b1cf01f_000012_39679ef8>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_6b1cf01f_000006_12cb36a2+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_6b1cf01f_000003_644dadb7>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_6b1cf01f_000006_12cb36a2+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_6b1cf01f_000009_2417e911>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_6b1cf01f_000009_2417e911+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40a450 <__swc_fn_6b1cf01f_000007_635028f3>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40d710 <__swc_fn_6b1cf01f_000008_578f1784>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_6b1cf01f_000009_2417e911+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_6b1cf01f_000009_2417e911+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_6b1cf01f_000012_39679ef8>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_6b1cf01f_000015_aa8c841a>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_6b1cf01f_000015_aa8c841a+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_6b1cf01f_000015_aa8c841a+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_6b1cf01f_000015_aa8c841a+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_6b1cf01f_000015_aa8c841a+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40d880 <__swc_fn_6b1cf01f_000017_e238d24c>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_6b1cf01f_000015_aa8c841a+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1cb3d]        # 424058 <__swc_bss_base_6b1cf01f+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1cb36]        # 424058 <__swc_bss_base_6b1cf01f+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_6b1cf01f_000015_aa8c841a+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_6b1cf01f_000015_aa8c841a+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40d720 <__swc_fn_6b1cf01f_000011_e75d466d>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_6b1cf01f_000015_aa8c841a+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   40c6c0 <__swc_fn_6b1cf01f_000112_cb2656be>
  407569:	lea    rcx,[rip+0x1cad8]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1cad1]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_6b1cf01f_000015_aa8c841a+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_6b1cf01f_000015_aa8c841a+0x110>
  407598:	lea    rcx,[rip+0x1cac1]        # 424060 <__swc_bss_base_6b1cf01f+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1caba]        # 424060 <__swc_bss_base_6b1cf01f+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_6b1cf01f_000015_aa8c841a+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_6b1cf01f_000015_aa8c841a+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_6b1cf01f_000018_e2e8e4b0>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_6b1cf01f_000015_aa8c841a+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_6b1cf01f_000018_e2e8e4b0>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_6b1cf01f_000018_e2e8e4b0+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_6b1cf01f_000018_e2e8e4b0+0x10>

0000000000407630 <__swc_fn_6b1cf01f_000021_fe13ecad>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_6b1cf01f_000015_aa8c841a>
  40763e:	lea    rdi,[rip+0x1cbab]        # 4241f0 <__swc_bss_base_6b1cf01f+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   4098a0 <__swc_fn_6b1cf01f_000135_1fec60ac>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1cb94]        # 4241f8 <__swc_bss_base_6b1cf01f+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1cb89],rsi        # 4241f8 <__swc_bss_base_6b1cf01f+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_6b1cf01f_000024_7e9350e1>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_6b1cf01f_000027_7e9350e1>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_6b1cf01f_000030_686c93a8>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_6b1cf01f_000030_686c93a8+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1a92c]        # 422000 <__swc_data_base_6b1cf01f>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_6b1cf01f_000030_686c93a8+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_6b1cf01f_000030_686c93a8+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_6b1cf01f_000030_686c93a8+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40da40 <__swc_fn_6b1cf01f_000032_8c89735c>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_6b1cf01f_000030_686c93a8+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_6b1cf01f_000036_62160bb3>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_6b1cf01f_000030_686c93a8+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_6b1cf01f_000042_70d5ab54>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_6b1cf01f_000033_7d7574b6>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40a900 <__swc_fn_6b1cf01f_000031_ed8d61a9>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   409720 <__swc_fn_6b1cf01f_000129_0672cd48>
  407734:	mov    rcx,rsi
  407737:	call   40da40 <__swc_fn_6b1cf01f_000032_8c89735c>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_6b1cf01f_000036_62160bb3>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_6b1cf01f_000039_05a50673>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_6b1cf01f_000039_05a50673+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_6b1cf01f_000039_05a50673+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_6b1cf01f_000039_05a50673+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_6b1cf01f_000039_05a50673+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_6b1cf01f_000039_05a50673+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   409320 <__swc_fn_6b1cf01f_000114_0575f585>
  4077ca:	lea    rcx,[rip+0x1c877]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1c870]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_6b1cf01f_000039_05a50673+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_6b1cf01f_000039_05a50673+0x90>
  4077f8:	lea    rcx,[rip+0x1c861]        # 424060 <__swc_bss_base_6b1cf01f+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1c85a]        # 424060 <__swc_bss_base_6b1cf01f+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_6b1cf01f_000039_05a50673+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_6b1cf01f_000039_05a50673+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_6b1cf01f_000042_70d5ab54>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_6b1cf01f_000042_70d5ab54+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40e010 <__swc_fn_6b1cf01f_000059_c8e1ff6b>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   4098a0 <__swc_fn_6b1cf01f_000135_1fec60ac>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_6b1cf01f_000042_70d5ab54+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_6b1cf01f_000042_70d5ab54+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_6b1cf01f_000009_2417e911>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_6b1cf01f_000042_70d5ab54+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40d740 <__swc_fn_6b1cf01f_000014_1acdaf22>
  40791e:	jmp    407941 <__swc_fn_6b1cf01f_000042_70d5ab54+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_6b1cf01f_000042_70d5ab54+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_6b1cf01f_000042_70d5ab54+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_6b1cf01f_000042_70d5ab54+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40aac0 <__swc_fn_6b1cf01f_000043_3755033a>
  407997:	mov    rcx,rdi
  40799a:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_6b1cf01f_000039_05a50673>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_6b1cf01f_000045_06cec934>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_6b1cf01f_000045_06cec934+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_6b1cf01f_000045_06cec934+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_6b1cf01f_000045_06cec934+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_6b1cf01f_000045_06cec934+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   4098a0 <__swc_fn_6b1cf01f_000135_1fec60ac>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_6b1cf01f_000045_06cec934+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_6b1cf01f_000045_06cec934+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_6b1cf01f_000045_06cec934+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_6b1cf01f_000045_06cec934+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_6b1cf01f_000009_2417e911>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_6b1cf01f_000045_06cec934+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_6b1cf01f_000045_06cec934+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_6b1cf01f_000045_06cec934+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_6b1cf01f_000045_06cec934+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_6b1cf01f_000045_06cec934+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40a500 <__swc_fn_6b1cf01f_000013_d15d37c6>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_6b1cf01f_000045_06cec934+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_6b1cf01f_000045_06cec934+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_6b1cf01f_000045_06cec934+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_6b1cf01f_000045_06cec934+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40d8c0 <__swc_fn_6b1cf01f_000020_4135c89a>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_6b1cf01f_000045_06cec934+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40a500 <__swc_fn_6b1cf01f_000013_d15d37c6>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_6b1cf01f_000045_06cec934+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_6b1cf01f_000021_fe13ecad>
  407c07:	mov    rcx,r14
  407c0a:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_6b1cf01f_000045_06cec934+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_6b1cf01f_000045_06cec934+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_6b1cf01f_000045_06cec934+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_6b1cf01f_000048_18a95c9b>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_6b1cf01f_000048_18a95c9b+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_6b1cf01f_000048_18a95c9b+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_6b1cf01f_000048_18a95c9b+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_6b1cf01f_000048_18a95c9b+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40dc70 <__swc_fn_6b1cf01f_000047_3d3eceb4>
  407d14:	jmp    407ce0 <__swc_fn_6b1cf01f_000048_18a95c9b+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_6b1cf01f_000048_18a95c9b+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_6b1cf01f_000048_18a95c9b+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_6b1cf01f_000048_18a95c9b+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_6b1cf01f_000048_18a95c9b+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_6b1cf01f_000048_18a95c9b+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_6b1cf01f_000048_18a95c9b+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_6b1cf01f_000048_18a95c9b+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_6b1cf01f_000051_5b91e689>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_6b1cf01f_000051_5b91e689+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_6b1cf01f_000051_5b91e689+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_6b1cf01f_000051_5b91e689+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_6b1cf01f_000051_5b91e689+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40dbd0 <__swc_fn_6b1cf01f_000044_cac7f504>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40d740 <__swc_fn_6b1cf01f_000014_1acdaf22>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_6b1cf01f_000054_1dfec8f6>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   4098a0 <__swc_fn_6b1cf01f_000135_1fec60ac>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_6b1cf01f_000054_1dfec8f6+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_6b1cf01f_000054_1dfec8f6+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_6b1cf01f_000054_1dfec8f6+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_6b1cf01f_000057_8be0372b>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_6b1cf01f_000060_9d59636e>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_6b1cf01f_000060_9d59636e+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_6b1cf01f_000039_05a50673>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_6b1cf01f_000060_9d59636e+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_6b1cf01f_000063_3509a564>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40ae40 <__swc_fn_6b1cf01f_000052_26c6c1c4>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_6b1cf01f_000054_1dfec8f6>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_6b1cf01f_000063_3509a564+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_6b1cf01f_000063_3509a564+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40af60 <__swc_fn_6b1cf01f_000058_033ce1da>
  407f7f:	mov    rcx,rsi
  407f82:	call   40aba0 <__swc_fn_6b1cf01f_000049_781177b4>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_6b1cf01f_000066_77c6e829>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_6b1cf01f_000066_77c6e829+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1c049]        # 424070 <__swc_bss_base_6b1cf01f+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1c04b]        # 424080 <__swc_bss_base_6b1cf01f+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_6b1cf01f_000066_77c6e829+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_6b1cf01f_000066_77c6e829+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40a830 <__swc_fn_6b1cf01f_000022_77c2d682>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_6b1cf01f_000066_77c6e829+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_6b1cf01f_000063_3509a564>
  40808f:	jmp    408122 <__swc_fn_6b1cf01f_000066_77c6e829+0x192>
  408094:	lea    rax,[rip+0x19f65]        # 422000 <__swc_data_base_6b1cf01f>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_6b1cf01f_000066_77c6e829+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_6b1cf01f_000066_77c6e829+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_6b1cf01f_000066_77c6e829+0x135>
  4080b8:	call   40a900 <__swc_fn_6b1cf01f_000031_ed8d61a9>
  4080bd:	mov    rcx,rax
  4080c0:	call   40fc00 <__swc_fn_6b1cf01f_000128_9c45d2d7>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_6b1cf01f_000066_77c6e829+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_6b1cf01f_000066_77c6e829+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_6b1cf01f_000066_77c6e829+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40dc70 <__swc_fn_6b1cf01f_000047_3d3eceb4>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_6b1cf01f_000066_77c6e829+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_6b1cf01f_000051_5b91e689>
  408115:	jmp    408122 <__swc_fn_6b1cf01f_000066_77c6e829+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40a470 <__swc_fn_6b1cf01f_000010_186cd0c2>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_6b1cf01f_000069_165b6301>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_6b1cf01f_000036_62160bb3>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_6b1cf01f_000069_165b6301+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1c09a]        # 424240 <__swc_bss_base_6b1cf01f+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_6b1cf01f_000069_165b6301+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   4098a0 <__swc_fn_6b1cf01f_000135_1fec60ac>
  4081b5:	mov    rcx,rsi
  4081b8:	call   40e440 <__swc_fn_6b1cf01f_000068_557d6092>
  4081bd:	mov    rcx,rsi
  4081c0:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_6b1cf01f_000072_b2caea81>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40e190 <__swc_fn_6b1cf01f_000065_cd9dd53e>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_6b1cf01f_000075_104c4b5d>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   40e440 <__swc_fn_6b1cf01f_000068_557d6092>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_6b1cf01f_000078_5a70c27a>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_6b1cf01f_000078_5a70c27a+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_6b1cf01f_000078_5a70c27a+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_6b1cf01f_000081_85585149>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_6b1cf01f_000084_746bf146>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_6b1cf01f_000090_9a1d717d>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_6b1cf01f_000084_746bf146+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_6b1cf01f_000084_746bf146+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_6b1cf01f_000084_746bf146+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_6b1cf01f_000084_746bf146+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_6b1cf01f_000090_9a1d717d>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_6b1cf01f_000084_746bf146+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_6b1cf01f_000084_746bf146+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_6b1cf01f_000084_746bf146+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_6b1cf01f_000084_746bf146+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_6b1cf01f_000084_746bf146+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_6b1cf01f_000084_746bf146+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_6b1cf01f_000084_746bf146+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_6b1cf01f_000084_746bf146+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_6b1cf01f_000084_746bf146+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_6b1cf01f_000084_746bf146+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40bf40 <__swc_fn_6b1cf01f_000082_9f4f5092>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_6b1cf01f_000084_746bf146+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_6b1cf01f_000084_746bf146+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_6b1cf01f_000084_746bf146+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40bf40 <__swc_fn_6b1cf01f_000082_9f4f5092>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_6b1cf01f_000084_746bf146+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_6b1cf01f_000084_746bf146>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_6b1cf01f_000084_746bf146+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_6b1cf01f_000084_746bf146+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_6b1cf01f_000087_1fb4fcfe>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_6b1cf01f_000090_9a1d717d>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_6b1cf01f_000087_1fb4fcfe+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   40e8a0 <__swc_fn_6b1cf01f_000086_ac8c6565>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_6b1cf01f_000087_1fb4fcfe+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_6b1cf01f_000087_1fb4fcfe+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_6b1cf01f_000087_1fb4fcfe+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40bf40 <__swc_fn_6b1cf01f_000082_9f4f5092>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_6b1cf01f_000087_1fb4fcfe+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_6b1cf01f_000087_1fb4fcfe>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_6b1cf01f_000087_1fb4fcfe+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_6b1cf01f_000087_1fb4fcfe+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_6b1cf01f_000090_9a1d717d>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_6b1cf01f_000090_9a1d717d+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_6b1cf01f_000090_9a1d717d+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_6b1cf01f_000090_9a1d717d+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_6b1cf01f_000090_9a1d717d+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40bf40 <__swc_fn_6b1cf01f_000082_9f4f5092>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40bf40 <__swc_fn_6b1cf01f_000082_9f4f5092>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_6b1cf01f_000090_9a1d717d+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_6b1cf01f_000090_9a1d717d+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_6b1cf01f_000090_9a1d717d+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_6b1cf01f_000090_9a1d717d+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_6b1cf01f_000090_9a1d717d>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_6b1cf01f_000090_9a1d717d+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_6b1cf01f_000090_9a1d717d+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_6b1cf01f_000090_9a1d717d+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_6b1cf01f_000090_9a1d717d+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_6b1cf01f_000090_9a1d717d+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_6b1cf01f_000090_9a1d717d+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_6b1cf01f_000090_9a1d717d+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_6b1cf01f_000090_9a1d717d+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_6b1cf01f_000090_9a1d717d+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_6b1cf01f_000090_9a1d717d+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_6b1cf01f_000090_9a1d717d+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_6b1cf01f_000090_9a1d717d+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_6b1cf01f_000090_9a1d717d+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_6b1cf01f_000090_9a1d717d+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_6b1cf01f_000090_9a1d717d+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_6b1cf01f_000090_9a1d717d+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   409db0 <__swc_fn_6b1cf01f_000147_c9c6528e>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_6b1cf01f_000090_9a1d717d+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_6b1cf01f_000090_9a1d717d>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_6b1cf01f_000090_9a1d717d+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_6b1cf01f_000090_9a1d717d+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_6b1cf01f_000090_9a1d717d+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   409db0 <__swc_fn_6b1cf01f_000147_c9c6528e>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   409db0 <__swc_fn_6b1cf01f_000147_c9c6528e>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_6b1cf01f_000093_344f5089>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40c070 <__swc_fn_6b1cf01f_000091_e6773530>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_6b1cf01f_000093_344f5089+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_6b1cf01f_000093_344f5089+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   40fda0 <__swc_fn_6b1cf01f_000137_899a611e>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_6b1cf01f_000093_344f5089+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0xa872]        # 4131c0 <__swc_rdata_base_6b1cf01f+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   40f8d0 <__swc_fn_6b1cf01f_000116_3499f7d6>
  408959:	call   40c8f0 <__swc_fn_6b1cf01f_000118_2b35b5e0>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_6b1cf01f_000096_f879630a>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40896f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  408975:	vzeroupper
  408978:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40897e:	mov    QWORD PTR [rsp+0x48],rdx
  408983:	mov    rax,r8
  408986:	cmp    r8,0x1
  40898a:	mov    edx,0x1
  40898f:	cmovb  rax,rdx
  408993:	mov    QWORD PTR [rsp+0x50],rax
  408998:	mov    rbx,QWORD PTR [rcx+0x8]
  40899c:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a0:	mov    rcx,QWORD PTR [rcx]
  4089a3:	lea    rdx,[rsp+0x8]
  4089a8:	call   rbx
  4089aa:	add    rsp,0x70
  4089ae:	pop    rbx
  4089af:	ret

00000000004089b0 <__swc_fn_6b1cf01f_000099_6e0faaee>:
  4089b0:	push   rbx
  4089b1:	push   rsi
  4089b2:	push   rdi
  4089b3:	sub    rsp,0x30
  4089b7:	mov    rbx,rcx
  4089ba:	test   rcx,rcx
  4089bd:	je     4089d2 <__swc_fn_6b1cf01f_000099_6e0faaee+0x22>
  4089bf:	mov    rcx,rbx
  4089c2:	mov    edx,0x1
  4089c7:	call   408200 <__swc_fn_6b1cf01f_000078_5a70c27a>
  4089cc:	cmp    rax,0x1
  4089d0:	je     4089da <__swc_fn_6b1cf01f_000099_6e0faaee+0x2a>
  4089d2:	add    rsp,0x30
  4089d6:	pop    rdi
  4089d7:	pop    rsi
  4089d8:	pop    rbx
  4089d9:	ret
  4089da:	lea    rsi,[rsp+0x8]
  4089df:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089e4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089ea:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  4089ef:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4089f5:	mov    rax,QWORD PTR [rsp+0x20]
  4089fa:	test   rax,rax
  4089fd:	je     408a13 <__swc_fn_6b1cf01f_000099_6e0faaee+0x63>
  4089ff:	test   DWORD PTR [rax+0x28],0x400000
  408a06:	je     408a13 <__swc_fn_6b1cf01f_000099_6e0faaee+0x63>
  408a08:	mov    rcx,QWORD PTR [rax+0x30]
  408a0c:	test   rcx,rcx
  408a0f:	cmovne rax,rcx
  408a13:	mov    edi,DWORD PTR [rax+0x20]
  408a16:	lea    rcx,[rsp+0x18]
  408a1b:	call   40c250 <__swc_fn_6b1cf01f_000100_2ef16a3e>
  408a20:	mov    rcx,rsi
  408a23:	mov    rdx,QWORD PTR [rsp+0x18]
  408a28:	mov    r8,rdi
  408a2b:	call   408960 <__swc_fn_6b1cf01f_000096_f879630a>
  408a30:	mov    rcx,QWORD PTR [rbx+0x28]
  408a34:	call   40ee80 <__swc_fn_6b1cf01f_000098_d9d80f1a>
  408a39:	mov    rcx,rsi
  408a3c:	mov    rdx,rbx
  408a3f:	mov    r8d,0x30
  408a45:	call   408960 <__swc_fn_6b1cf01f_000096_f879630a>
  408a4a:	add    rsp,0x30
  408a4e:	pop    rdi
  408a4f:	pop    rsi
  408a50:	pop    rbx
  408a51:	ret
	...

0000000000408a60 <__swc_fn_6b1cf01f_000102_29a1093a>:
  408a60:	push   rbp
  408a61:	push   rbx
  408a62:	push   rsi
  408a63:	push   rdi
  408a64:	push   r12
  408a66:	push   r13
  408a68:	push   r14
  408a6a:	push   r15
  408a6c:	sub    rsp,0x500
  408a73:	mov    rbp,rsp
  408a76:	mov    rbx,rsp
  408a79:	mov    rsi,rdx
  408a7c:	mov    rdi,rcx
  408a7f:	mov    rcx,QWORD PTR [rip+0x1e2ba]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  408a86:	test   rcx,rcx
  408a89:	jne    408aa3 <__swc_fn_6b1cf01f_000102_29a1093a+0x43>
  408a8b:	sub    rsp,0x8
  408a8f:	call   40a1a0 <__swc_fn_6b1cf01f_000165_e09accff>
  408a94:	add    rsp,0x8
  408a98:	lea    rcx,[rax+0x1]
  408a9c:	mov    QWORD PTR [rip+0x1e29d],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  408aa3:	dec    rcx
  408aa6:	sub    rsp,0x8
  408aaa:	call   411680 <__swc_fn_6b1cf01f_000167_3130645d>
  408aaf:	add    rsp,0x8
  408ab3:	mov    r12,rax
  408ab6:	mov    QWORD PTR [rsp+0x4f0],rax
  408abe:	lea    rax,[rip+0xa83b]        # 413300 <__swc_rdata_base_6b1cf01f+0x1f0>
  408ac5:	sub    rsp,0x20
  408ac9:	mov    rcx,rsp
  408acc:	mov    QWORD PTR [rcx],rax
  408acf:	lea    r13,[rip+0xa83a]        # 413310 <__swc_rdata_base_6b1cf01f+0x200>
  408ad6:	mov    QWORD PTR [rcx+0x8],r13
  408ada:	mov    QWORD PTR [rcx+0x10],rsp
  408ade:	mov    QWORD PTR [rcx+0x18],0x1
  408ae6:	lea    rcx,[rsp+0x10]
  408aeb:	sub    rsp,0x8
  408aef:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  408af4:	add    rsp,0x8
  408af8:	add    rsp,0x20
  408afc:	lea    rax,[rip+0xa855]        # 413358 <__swc_rdata_base_6b1cf01f+0x248>
  408b03:	sub    rsp,0x20
  408b07:	mov    rcx,rsp
  408b0a:	mov    QWORD PTR [rcx],rax
  408b0d:	mov    QWORD PTR [rcx+0x8],r13
  408b11:	mov    QWORD PTR [rcx+0x10],rsp
  408b15:	mov    QWORD PTR [rcx+0x18],0x1
  408b1d:	lea    rcx,[rsp+0x10]
  408b22:	sub    rsp,0x8
  408b26:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  408b2b:	add    rsp,0x8
  408b2f:	add    rsp,0x20
  408b33:	lea    r14,[rip+0xa82e]        # 413368 <__swc_rdata_base_6b1cf01f+0x258>
  408b3a:	sub    rsp,0x50
  408b3e:	mov    rax,rsp
  408b41:	vmovups xmm0,XMMWORD PTR [rip+0xa957]        # 4134a0 <__swc_rdata_base_6b1cf01f+0x390>
  408b49:	vmovups XMMWORD PTR [rax],xmm0
  408b4d:	mov    QWORD PTR [rax+0x10],rsp
  408b51:	mov    QWORD PTR [rax+0x18],r13
  408b55:	mov    QWORD PTR [rax+0x20],rdi
  408b59:	lea    rdi,[rip+0xa818]        # 413378 <__swc_rdata_base_6b1cf01f+0x268>
  408b60:	mov    QWORD PTR [rax+0x28],rdi
  408b64:	mov    QWORD PTR [rax+0x30],r14
  408b68:	mov    QWORD PTR [rax+0x38],r13
  408b6c:	lea    rcx,[rsp+0x10]
  408b71:	mov    QWORD PTR [rax+0x40],rcx
  408b75:	mov    QWORD PTR [rax+0x48],0x3
  408b7d:	lea    rcx,[rsp+0x40]
  408b82:	sub    rsp,0x8
  408b86:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  408b8b:	add    rsp,0x8
  408b8f:	add    rsp,0x50
  408b93:	lea    rax,[rip+0xa826]        # 4133c0 <__swc_rdata_base_6b1cf01f+0x2b0>
  408b9a:	sub    rsp,0x20
  408b9e:	mov    rcx,rsp
  408ba1:	mov    QWORD PTR [rcx],rax
  408ba4:	mov    QWORD PTR [rcx+0x8],r13
  408ba8:	mov    QWORD PTR [rcx+0x10],rsp
  408bac:	mov    QWORD PTR [rcx+0x18],0x1
  408bb4:	lea    rcx,[rsp+0x10]
  408bb9:	sub    rsp,0x8
  408bbd:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  408bc2:	add    rsp,0x8
  408bc6:	add    rsp,0x20
  408bca:	mov    eax,DWORD PTR [rsi+0x20]
  408bcd:	mov    ecx,DWORD PTR [rsi+0x24]
  408bd0:	sub    rsp,0xa0
  408bd7:	mov    rdx,rsp
  408bda:	mov    QWORD PTR [rdx+0x30],rsi
  408bde:	mov    QWORD PTR [rdx+0x38],rdi
  408be2:	vmovups xmm0,XMMWORD PTR [rip+0xa84e]        # 413438 <__swc_rdata_base_6b1cf01f+0x328>
  408bea:	vmovups XMMWORD PTR [rdx],xmm0
  408bee:	mov    QWORD PTR [rdx+0x40],rsp
  408bf2:	mov    QWORD PTR [rdx+0x48],r13
  408bf6:	mov    DWORD PTR [rdx+0x10],eax
  408bf9:	lea    rax,[rsp+0x10]
  408bfe:	mov    QWORD PTR [rdx+0x50],rax
  408c02:	lea    rax,[rip+0xa7c7]        # 4133d0 <__swc_rdata_base_6b1cf01f+0x2c0>
  408c09:	mov    QWORD PTR [rdx+0x58],rax
  408c0d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c12:	lea    r8,[rsp+0x18]
  408c17:	mov    QWORD PTR [rdx+0x60],r8
  408c1b:	mov    QWORD PTR [rdx+0x68],r13
  408c1f:	mov    DWORD PTR [rdx+0x28],ecx
  408c22:	lea    rcx,[rdx+0x28]
  408c26:	mov    QWORD PTR [rdx+0x70],rcx
  408c2a:	mov    QWORD PTR [rdx+0x78],rax
  408c2e:	mov    QWORD PTR [rdx+0x80],r14
  408c35:	mov    QWORD PTR [rdx+0x88],r13
  408c3c:	lea    rax,[rdx+0x30]
  408c40:	mov    QWORD PTR [rdx+0x90],rax
  408c47:	mov    QWORD PTR [rdx+0x98],0x6
  408c52:	lea    rcx,[rdx+0x90]
  408c59:	sub    rsp,0x8
  408c5d:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  408c62:	add    rsp,0x8
  408c66:	add    rsp,0xa0
  408c6d:	sub    rsp,0x20
  408c71:	mov    rax,rsp
  408c74:	mov    QWORD PTR [rax],r14
  408c77:	mov    QWORD PTR [rax+0x8],r13
  408c7b:	mov    QWORD PTR [rax+0x10],rsp
  408c7f:	mov    QWORD PTR [rax+0x18],0x1
  408c87:	lea    rcx,[rsp+0x10]
  408c8c:	sub    rsp,0x8
  408c90:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  408c95:	add    rsp,0x8
  408c99:	add    rsp,0x20
  408c9d:	mov    eax,DWORD PTR [r12+0x9ac]
  408ca5:	test   eax,eax
  408ca7:	je     408ee0 <__swc_fn_6b1cf01f_000102_29a1093a+0x480>
  408cad:	lea    rax,[rip+0xa764]        # 413418 <__swc_rdata_base_6b1cf01f+0x308>
  408cb4:	sub    rsp,0x20
  408cb8:	mov    rcx,rsp
  408cbb:	mov    QWORD PTR [rcx],rax
  408cbe:	mov    QWORD PTR [rcx+0x8],r13
  408cc2:	mov    QWORD PTR [rcx+0x10],rsp
  408cc6:	mov    QWORD PTR [rcx+0x18],0x1
  408cce:	lea    rcx,[rsp+0x10]
  408cd3:	sub    rsp,0x8
  408cd7:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  408cdc:	add    rsp,0x8
  408ce0:	add    rsp,0x20
  408ce4:	mov    eax,DWORD PTR [r12+0x9ac]
  408cec:	dec    eax
  408cee:	mov    esi,eax
  408cf0:	test   esi,esi
  408cf2:	jl     408eb0 <__swc_fn_6b1cf01f_000102_29a1093a+0x450>
  408cf8:	jmp    408d04 <__swc_fn_6b1cf01f_000102_29a1093a+0x2a4>
  408cfa:	nop    WORD PTR [rax+rax*1+0x0]
  408d00:	dec    esi
  408d02:	jmp    408cf0 <__swc_fn_6b1cf01f_000102_29a1093a+0x290>
  408d04:	lea    rax,[rip+0xa71d]        # 413428 <__swc_rdata_base_6b1cf01f+0x318>
  408d0b:	sub    rsp,0x20
  408d0f:	mov    rcx,rsp
  408d12:	mov    QWORD PTR [rcx],rax
  408d15:	mov    QWORD PTR [rcx+0x8],r13
  408d19:	mov    QWORD PTR [rcx+0x10],rsp
  408d1d:	mov    QWORD PTR [rcx+0x18],0x1
  408d25:	lea    rcx,[rsp+0x10]
  408d2a:	sub    rsp,0x8
  408d2e:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  408d33:	add    rsp,0x8
  408d37:	add    rsp,0x20
  408d3b:	movsxd rax,esi
  408d3e:	imul   r15,rax,0x30
  408d42:	add    r15,r12
  408d45:	add    r15,0xf8
  408d4c:	sub    rsp,0x20
  408d50:	mov    rax,rsp
  408d53:	mov    QWORD PTR [rax],r15
  408d56:	mov    QWORD PTR [rax+0x8],rdi
  408d5a:	mov    QWORD PTR [rax+0x10],rsp
  408d5e:	mov    QWORD PTR [rax+0x18],0x1
  408d66:	lea    rcx,[rsp+0x10]
  408d6b:	sub    rsp,0x8
  408d6f:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  408d74:	add    rsp,0x8
  408d78:	add    rsp,0x20
  408d7c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408d84:	lea    rsi,[rip+0xa6ad]        # 413438 <__swc_rdata_base_6b1cf01f+0x328>
  408d8b:	sub    rsp,0x20
  408d8f:	mov    rax,rsp
  408d92:	mov    QWORD PTR [rax],rsi
  408d95:	mov    QWORD PTR [rax+0x8],r13
  408d99:	mov    QWORD PTR [rax+0x10],rsp
  408d9d:	mov    QWORD PTR [rax+0x18],0x1
  408da5:	lea    rcx,[rsp+0x10]
  408daa:	sub    rsp,0x8
  408dae:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  408db3:	add    rsp,0x8
  408db7:	add    rsp,0x20
  408dbb:	sub    rsp,0x30
  408dbf:	mov    rax,rsp
  408dc2:	mov    ecx,DWORD PTR [r15+0x20]
  408dc6:	mov    QWORD PTR [rax],rcx
  408dc9:	mov    QWORD PTR [rax+0x8],rsp
  408dcd:	lea    rdi,[rip+0xa674]        # 413448 <__swc_rdata_base_6b1cf01f+0x338>
  408dd4:	mov    QWORD PTR [rax+0x10],rdi
  408dd8:	lea    rcx,[rsp+0x8]
  408ddd:	mov    QWORD PTR [rax+0x18],rcx
  408de1:	mov    QWORD PTR [rax+0x20],0x1
  408de9:	lea    rcx,[rsp+0x18]
  408dee:	sub    rsp,0x8
  408df2:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  408df7:	add    rsp,0x8
  408dfb:	add    rsp,0x30
  408dff:	sub    rsp,0x20
  408e03:	mov    rax,rsp
  408e06:	mov    QWORD PTR [rax],rsi
  408e09:	mov    QWORD PTR [rax+0x8],r13
  408e0d:	mov    QWORD PTR [rax+0x10],rsp
  408e11:	mov    QWORD PTR [rax+0x18],0x1
  408e19:	lea    rcx,[rsp+0x10]
  408e1e:	sub    rsp,0x8
  408e22:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  408e27:	add    rsp,0x8
  408e2b:	add    rsp,0x20
  408e2f:	sub    rsp,0x30
  408e33:	mov    rax,rsp
  408e36:	mov    ecx,DWORD PTR [r15+0x24]
  408e3a:	mov    QWORD PTR [rax],rcx
  408e3d:	mov    QWORD PTR [rax+0x8],rsp
  408e41:	mov    QWORD PTR [rax+0x10],rdi
  408e45:	lea    rcx,[rsp+0x8]
  408e4a:	mov    QWORD PTR [rax+0x18],rcx
  408e4e:	mov    QWORD PTR [rax+0x20],0x1
  408e56:	lea    rcx,[rsp+0x18]
  408e5b:	sub    rsp,0x8
  408e5f:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  408e64:	add    rsp,0x8
  408e68:	add    rsp,0x30
  408e6c:	sub    rsp,0x20
  408e70:	mov    rax,rsp
  408e73:	mov    QWORD PTR [rax],r14
  408e76:	mov    QWORD PTR [rax+0x8],r13
  408e7a:	mov    QWORD PTR [rax+0x10],rsp
  408e7e:	mov    QWORD PTR [rax+0x18],0x1
  408e86:	lea    rcx,[rsp+0x10]
  408e8b:	sub    rsp,0x8
  408e8f:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  408e94:	add    rsp,0x8
  408e98:	add    rsp,0x20
  408e9c:	lea    rdi,[rip+0xa4d5]        # 413378 <__swc_rdata_base_6b1cf01f+0x268>
  408ea3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408eab:	jmp    408d00 <__swc_fn_6b1cf01f_000102_29a1093a+0x2a0>
  408eb0:	sub    rsp,0x20
  408eb4:	mov    rax,rsp
  408eb7:	mov    QWORD PTR [rax],r14
  408eba:	mov    QWORD PTR [rax+0x8],r13
  408ebe:	mov    QWORD PTR [rax+0x10],rsp
  408ec2:	mov    QWORD PTR [rax+0x18],0x1
  408eca:	lea    rcx,[rsp+0x10]
  408ecf:	sub    rsp,0x8
  408ed3:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  408ed8:	add    rsp,0x8
  408edc:	add    rsp,0x20
  408ee0:	lea    rax,[rbx+0x28]
  408ee4:	mov    rcx,rax
  408ee7:	mov    QWORD PTR [rbx+0x28],0x0
  408eef:	mov    QWORD PTR [rbx+0x30],0x0
  408ef7:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408efc:	add    rcx,0x10
  408f00:	mov    edx,0x1f
  408f05:	cs nop WORD PTR [rax+rax*1+0x0]
  408f0f:	nop
  408f10:	vmovups XMMWORD PTR [rcx],xmm0
  408f14:	add    rcx,0x10
  408f18:	sub    rdx,0x1
  408f1c:	jne    408f10 <__swc_fn_6b1cf01f_000102_29a1093a+0x4b0>
  408f1e:	lea    rsi,[rbx+0x228]
  408f25:	xor    ecx,ecx
  408f27:	cs nop WORD PTR [rax+rax*1+0x0]
  408f31:	cs nop WORD PTR [rax+rax*1+0x0]
  408f3b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f40:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f45:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f4a:	add    rcx,0x10
  408f4e:	cmp    rcx,0x200
  408f55:	jne    408f40 <__swc_fn_6b1cf01f_000102_29a1093a+0x4e0>
  408f57:	mov    eax,DWORD PTR [r12+0xbc8]
  408f5f:	lea    rcx,[r12+0x9c8]
  408f67:	mov    QWORD PTR [rbx+0x428],rcx
  408f6e:	mov    QWORD PTR [rbx+0x430],rax
  408f75:	lea    rdi,[rbx+0x438]
  408f7c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408f84:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408f8c:	mov    eax,DWORD PTR [r12+0xbc8]
  408f94:	test   eax,eax
  408f96:	jne    408fe3 <__swc_fn_6b1cf01f_000102_29a1093a+0x583>
  408f98:	lea    rax,[rbx+0x448]
  408f9f:	mov    QWORD PTR [rbx+0x448],rsi
  408fa6:	mov    QWORD PTR [rax+0x8],0x40
  408fae:	mov    ecx,0x1
  408fb3:	mov    rdx,rax
  408fb6:	sub    rsp,0x8
  408fba:	call   40f9e0 <__swc_fn_6b1cf01f_000119_18cd3882>
  408fbf:	add    rsp,0x8
  408fc3:	mov    QWORD PTR [rbx+0x460],rsi
  408fca:	mov    ecx,eax
  408fcc:	mov    QWORD PTR [rbx+0x468],rcx
  408fd3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408fdb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fe3:	mov    rsi,QWORD PTR [rbx+0x438]
  408fea:	mov    rax,QWORD PTR [rbx+0x440]
  408ff1:	mov    r15,rax
  408ff4:	xor    r12d,r12d
  408ff7:	test   r15,r15
  408ffa:	je     4090b0 <__swc_fn_6b1cf01f_000102_29a1093a+0x650>
  409000:	mov    rax,QWORD PTR [rsi+r12*8]
  409004:	test   rax,rax
  409007:	je     409026 <__swc_fn_6b1cf01f_000102_29a1093a+0x5c6>
  409009:	lea    rcx,[rbx+0x4b8]
  409010:	mov    rdx,rax
  409013:	sub    rsp,0x8
  409017:	call   409f10 <__swc_fn_6b1cf01f_000162_edb9cf73>
  40901c:	add    rsp,0x8
  409020:	mov    al,BYTE PTR [rax]
  409022:	test   al,al
  409024:	jne    409032 <__swc_fn_6b1cf01f_000102_29a1093a+0x5d2>
  409026:	add    r12,0x1
  40902a:	sub    r15,0x1
  40902e:	jne    409000 <__swc_fn_6b1cf01f_000102_29a1093a+0x5a0>
  409030:	jmp    4090b0 <__swc_fn_6b1cf01f_000102_29a1093a+0x650>
  409032:	lea    rax,[rip+0xa457]        # 413490 <__swc_rdata_base_6b1cf01f+0x380>
  409039:	sub    rsp,0x20
  40903d:	mov    rcx,rsp
  409040:	mov    QWORD PTR [rcx],rax
  409043:	mov    QWORD PTR [rcx+0x8],r13
  409047:	mov    QWORD PTR [rcx+0x10],rsp
  40904b:	mov    QWORD PTR [rcx+0x18],0x1
  409053:	lea    rcx,[rsp+0x10]
  409058:	sub    rsp,0x8
  40905c:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  409061:	add    rsp,0x8
  409065:	add    rsp,0x20
  409069:	mov    rcx,rdi
  40906c:	xor    edx,edx
  40906e:	mov    al,0x1
  409070:	mov    r8,rax
  409073:	sub    rsp,0x8
  409077:	call   40d180 <__swc_fn_6b1cf01f_000163_5fbed98a>
  40907c:	add    rsp,0x8
  409080:	sub    rsp,0x20
  409084:	mov    rax,rsp
  409087:	mov    QWORD PTR [rax],r14
  40908a:	mov    QWORD PTR [rax+0x8],r13
  40908e:	mov    QWORD PTR [rax+0x10],rsp
  409092:	mov    QWORD PTR [rax+0x18],0x1
  40909a:	lea    rcx,[rsp+0x10]
  40909f:	sub    rsp,0x8
  4090a3:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  4090a8:	add    rsp,0x8
  4090ac:	add    rsp,0x20
  4090b0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090b8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090c4:	add    rsp,0x500
  4090cb:	pop    r15
  4090cd:	pop    r14
  4090cf:	pop    r13
  4090d1:	pop    r12
  4090d3:	pop    rdi
  4090d4:	pop    rsi
  4090d5:	pop    rbx
  4090d6:	pop    rbp
  4090d7:	ret
	...

00000000004090e0 <__swc_fn_6b1cf01f_000105_b7aef7c0>:
  4090e0:	sub    rsp,0x8
  4090e4:	test   r8,r8
  4090e7:	je     4090ee <__swc_fn_6b1cf01f_000105_b7aef7c0+0xe>
  4090e9:	call   40f110 <__swc_fn_6b1cf01f_000104_baf871f8>
  4090ee:	add    rsp,0x8
  4090f2:	ret
	...

0000000000409100 <__swc_fn_6b1cf01f_000108_32416b9e>:
  409100:	push   rsi
  409101:	push   rdi
  409102:	push   r12
  409104:	push   r13
  409106:	sub    rsp,0xd8
  40910d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409113:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  409119:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40911f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  409125:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40912b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  409134:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40913d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  409146:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40914f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  409158:	xor    eax,eax
  40915a:	call   407010 <getpid@plt>
  40915f:	mov    rsi,rax
  409162:	lea    rdi,[rip+0x1dbdf]        # 426d48 <__swc_bss_base_6b1cf01f+0x2d08>
  409169:	mov    r12,QWORD PTR [rdi]
  40916c:	test   r12,r12
  40916f:	je     40917d <__swc_fn_6b1cf01f_000108_32416b9e+0x7d>
  409171:	cmp    DWORD PTR [r12+0x10],esi
  409176:	jne    40917d <__swc_fn_6b1cf01f_000108_32416b9e+0x7d>
  409178:	mov    rax,r12
  40917b:	jmp    4091e0 <__swc_fn_6b1cf01f_000108_32416b9e+0xe0>
  40917d:	mov    ecx,0x4
  409182:	mov    edx,0x18
  409187:	call   40f1f0 <__swc_fn_6b1cf01f_000107_ff529476>
  40918c:	mov    rcx,rax
  40918f:	test   rax,rax
  409192:	jne    409198 <__swc_fn_6b1cf01f_000108_32416b9e+0x98>
  409194:	xor    eax,eax
  409196:	jmp    4091e0 <__swc_fn_6b1cf01f_000108_32416b9e+0xe0>
  409198:	mov    DWORD PTR [rcx+0x10],esi
  40919b:	mov    rax,r12
  40919e:	lock cmpxchg QWORD PTR [rdi],rcx
  4091a3:	mov    r13,rax
  4091a6:	cmp    rax,r12
  4091a9:	je     4091bf <__swc_fn_6b1cf01f_000108_32416b9e+0xbf>
  4091ab:	mov    rdi,rcx
  4091ae:	mov    esi,0x18
  4091b3:	xor    eax,eax
  4091b5:	call   407020 <munmap@plt>
  4091ba:	mov    rax,r13
  4091bd:	jmp    4091e0 <__swc_fn_6b1cf01f_000108_32416b9e+0xe0>
  4091bf:	test   r12,r12
  4091c2:	je     4091dd <__swc_fn_6b1cf01f_000108_32416b9e+0xdd>
  4091c4:	mov    rdi,r12
  4091c7:	mov    esi,0x18
  4091cc:	xor    eax,eax
  4091ce:	mov    QWORD PTR [rsp+0x28],rcx
  4091d3:	call   407020 <munmap@plt>
  4091d8:	mov    rcx,QWORD PTR [rsp+0x28]
  4091dd:	mov    rax,rcx
  4091e0:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  4091e6:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  4091ec:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  4091f2:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  4091f8:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  4091fe:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409207:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  409210:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409219:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  409222:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40922b:	add    rsp,0xd8
  409232:	pop    r13
  409234:	pop    r12
  409236:	pop    rdi
  409237:	pop    rsi
  409238:	ret
  409239:	add    BYTE PTR [rax],al
  40923b:	add    BYTE PTR [rax],al
  40923d:	add    BYTE PTR [rax],al
	...

0000000000409240 <__swc_fn_6b1cf01f_000111_e724f834>:
  409240:	push   rbx
  409241:	push   r12
  409243:	push   rdi
  409244:	push   rsi
  409245:	sub    rsp,0xa8
  40924c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409252:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409258:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40925e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409264:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40926a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409270:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409276:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40927c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409285:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40928e:	mov    rbx,rdx
  409291:	mov    r12,rcx
  409294:	mov    rdi,rcx
  409297:	mov    rsi,rdx
  40929a:	mov    edx,0x3
  40929f:	xor    eax,eax
  4092a1:	call   407030 <mprotect@plt>
  4092a6:	test   eax,eax
  4092a8:	je     4092ae <__swc_fn_6b1cf01f_000111_e724f834+0x6e>
  4092aa:	xor    eax,eax
  4092ac:	jmp    4092c3 <__swc_fn_6b1cf01f_000111_e724f834+0x83>
  4092ae:	mov    rcx,r12
  4092b1:	mov    rdx,rbx
  4092b4:	mov    al,0x1
  4092b6:	mov    r8,rax
  4092b9:	call   40f820 <__swc_fn_6b1cf01f_000110_e606239a>
  4092be:	mov    eax,0x1
  4092c3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4092c9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4092cf:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4092d5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4092db:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4092e1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4092e7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4092ed:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4092f3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4092fc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409305:	add    rsp,0xa8
  40930c:	pop    rsi
  40930d:	pop    rdi
  40930e:	pop    r12
  409310:	pop    rbx
  409311:	ret
	...

0000000000409320 <__swc_fn_6b1cf01f_000114_0575f585>:
  409320:	sub    rsp,0x8
  409324:	test   rcx,rcx
  409327:	jne    40932e <__swc_fn_6b1cf01f_000114_0575f585+0xe>
  409329:	add    rsp,0x8
  40932d:	ret
  40932e:	call   40c7a0 <__swc_fn_6b1cf01f_000115_259b5d5a>
  409333:	add    rsp,0x8
  409337:	ret
	...

0000000000409340 <__swc_fn_6b1cf01f_000117_76ff2f0a>:
  409340:	push   rdi
  409341:	push   rsi
  409342:	sub    rsp,0xa8
  409349:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40934f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409355:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40935b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409361:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409367:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40936d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409373:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409379:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409382:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40938b:	xor    edi,edi
  40938d:	xor    eax,eax
  40938f:	call   407040 <exit@plt>
  409394:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40939a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4093a0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4093a6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4093ac:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4093b2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4093b8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4093be:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4093c4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4093cd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4093d6:	add    rsp,0xa8
  4093dd:	pop    rsi
  4093de:	pop    rdi
  4093df:	ret

00000000004093e0 <__swc_fn_6b1cf01f_000120_1601f378>:
  4093e0:	push   rbx
  4093e1:	push   rsi
  4093e2:	push   rdi
  4093e3:	push   r12
  4093e5:	sub    rsp,0x18
  4093e9:	mov    rbx,r8
  4093ec:	mov    rsi,rcx
  4093ef:	mov    rdi,rdx
  4093f2:	mov    rcx,QWORD PTR [rip+0x1d947]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  4093f9:	test   rcx,rcx
  4093fc:	jne    40940e <__swc_fn_6b1cf01f_000120_1601f378+0x2e>
  4093fe:	call   40a1a0 <__swc_fn_6b1cf01f_000165_e09accff>
  409403:	lea    rcx,[rax+0x1]
  409407:	mov    QWORD PTR [rip+0x1d932],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40940e:	dec    rcx
  409411:	call   411680 <__swc_fn_6b1cf01f_000167_3130645d>
  409416:	mov    r12,rax
  409419:	cmp    ebx,0x3
  40941c:	jne    40942f <__swc_fn_6b1cf01f_000120_1601f378+0x4f>
  40941e:	mov    rax,QWORD PTR [r12+0xbd0]
  409426:	test   rax,rax
  409429:	jne    40956c <__swc_fn_6b1cf01f_000120_1601f378+0x18c>
  40942f:	cmp    ebx,0x5
  409432:	jne    409456 <__swc_fn_6b1cf01f_000120_1601f378+0x76>
  409434:	call   40c070 <__swc_fn_6b1cf01f_000091_e6773530>
  409439:	test   al,al
  40943b:	jne    409456 <__swc_fn_6b1cf01f_000120_1601f378+0x76>
  40943d:	mov    rcx,rsi
  409440:	mov    rdx,rdi
  409443:	call   411630 <__swc_fn_6b1cf01f_000164_15b66a30>
  409448:	test   al,al
  40944a:	je     409456 <__swc_fn_6b1cf01f_000120_1601f378+0x76>
  40944c:	add    rsp,0x18
  409450:	pop    r12
  409452:	pop    rdi
  409453:	pop    rsi
  409454:	pop    rbx
  409455:	ret
  409456:	call   40c070 <__swc_fn_6b1cf01f_000091_e6773530>
  40945b:	test   al,al
  40945d:	jne    4094cf <__swc_fn_6b1cf01f_000120_1601f378+0xef>
  40945f:	vmovups xmm0,XMMWORD PTR [rsi]
  409463:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409469:	mov    rax,QWORD PTR [rsp+0x8]
  40946e:	test   rax,rax
  409471:	jne    4094c2 <__swc_fn_6b1cf01f_000120_1601f378+0xe2>
  409473:	cmp    ebx,0x3
  409476:	je     409484 <__swc_fn_6b1cf01f_000120_1601f378+0xa4>
  409478:	cmp    ebx,0x4
  40947b:	je     409494 <__swc_fn_6b1cf01f_000120_1601f378+0xb4>
  40947d:	cmp    ebx,0x5
  409480:	je     4094a4 <__swc_fn_6b1cf01f_000120_1601f378+0xc4>
  409482:	jmp    4094b4 <__swc_fn_6b1cf01f_000120_1601f378+0xd4>
  409484:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 4134e0 <__swc_rdata_base_6b1cf01f+0x3d0>
  40948c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409492:	jmp    4094c2 <__swc_fn_6b1cf01f_000120_1601f378+0xe2>
  409494:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 4134f0 <__swc_rdata_base_6b1cf01f+0x3e0>
  40949c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094a2:	jmp    4094c2 <__swc_fn_6b1cf01f_000120_1601f378+0xe2>
  4094a4:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 413500 <__swc_rdata_base_6b1cf01f+0x3f0>
  4094ac:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094b2:	jmp    4094c2 <__swc_fn_6b1cf01f_000120_1601f378+0xe2>
  4094b4:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 413510 <__swc_rdata_base_6b1cf01f+0x400>
  4094bc:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094c2:	lea    rcx,[rsp+0x8]
  4094c7:	mov    rdx,rdi
  4094ca:	call   40c2c0 <__swc_fn_6b1cf01f_000103_2ed36338>
  4094cf:	vmovups xmm0,XMMWORD PTR [rdi]
  4094d3:	vmovups XMMWORD PTR [r12+0x940],xmm0
  4094dd:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  4094e2:	vmovups XMMWORD PTR [r12+0x950],xmm0
  4094ec:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  4094f1:	vmovups XMMWORD PTR [r12+0x960],xmm0
  4094fb:	lea    rax,[r12+0x940]
  409503:	mov    QWORD PTR [r12+0x970],rax
  40950b:	mov    rax,QWORD PTR [rsi]
  40950e:	mov    QWORD PTR [r12+0x978],rax
  409516:	mov    rax,QWORD PTR [rsi+0x8]
  40951a:	mov    QWORD PTR [r12+0x980],rax
  409522:	movsxd rax,ebx
  409525:	mov    QWORD PTR [r12+0x988],rax
  40952d:	cmp    ebx,0x5
  409530:	je     409539 <__swc_fn_6b1cf01f_000120_1601f378+0x159>
  409532:	xor    ecx,ecx
  409534:	call   40a2d0 <__swc_fn_6b1cf01f_000174_738eec22>
  409539:	mov    rbx,QWORD PTR [r12+0xbe8]
  409541:	test   rbx,rbx
  409544:	je     409555 <__swc_fn_6b1cf01f_000120_1601f378+0x175>
  409546:	mov    rcx,r12
  409549:	call   rbx
  40954b:	add    rsp,0x18
  40954f:	pop    r12
  409551:	pop    rdi
  409552:	pop    rsi
  409553:	pop    rbx
  409554:	ret
  409555:	mov    rcx,rsi
  409558:	call   40f8d0 <__swc_fn_6b1cf01f_000116_3499f7d6>
  40955d:	call   40c8f0 <__swc_fn_6b1cf01f_000118_2b35b5e0>
  409562:	add    rsp,0x18
  409566:	pop    r12
  409568:	pop    rdi
  409569:	pop    rsi
  40956a:	pop    rbx
  40956b:	ret
  40956c:	mov    rcx,rsi
  40956f:	mov    rdx,rdi
  409572:	call   40c2c0 <__swc_fn_6b1cf01f_000103_2ed36338>
  409577:	jmp    40942f <__swc_fn_6b1cf01f_000120_1601f378+0x4f>
  40957c:	add    BYTE PTR [rax],al
	...

0000000000409580 <__swc_fn_6b1cf01f_000123_e9227a3e>:
  409580:	push   rdi
  409581:	push   rsi
  409582:	sub    rsp,0xb8
  409589:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40958f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409595:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40959b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4095a1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4095a7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4095ad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4095b3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4095bc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4095c5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4095ce:	mov    DWORD PTR [rsp+0x8],0x0
  4095d6:	lea    rdi,[rsp+0x8]
  4095db:	xor    esi,esi
  4095dd:	xor    eax,eax
  4095df:	call   407050 <pthread_key_create@plt>
  4095e4:	test   eax,eax
  4095e6:	jne    4095ee <__swc_fn_6b1cf01f_000123_e9227a3e+0x6e>
  4095e8:	mov    eax,DWORD PTR [rsp+0x8]
  4095ec:	jmp    4095f5 <__swc_fn_6b1cf01f_000123_e9227a3e+0x75>
  4095ee:	mov    rax,0xffffffffffffffff
  4095f5:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4095fb:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409601:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409607:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40960d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409613:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409619:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40961f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409628:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409631:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40963a:	add    rsp,0xb8
  409641:	pop    rsi
  409642:	pop    rdi
  409643:	ret
	...

0000000000409650 <__swc_fn_6b1cf01f_000126_5fb20c72>:
  409650:	push   rdi
  409651:	push   rsi
  409652:	sub    rsp,0xb8
  409659:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40965f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409665:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40966b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409671:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409677:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40967d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409683:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40968c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409695:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40969e:	mov    DWORD PTR [rsp+0x8],0x0
  4096a6:	lea    rdi,[rsp+0x8]
  4096ab:	mov    rsi,rcx
  4096ae:	xor    eax,eax
  4096b0:	call   407050 <pthread_key_create@plt>
  4096b5:	test   eax,eax
  4096b7:	jne    4096c2 <__swc_fn_6b1cf01f_000126_5fb20c72+0x72>
  4096b9:	mov    eax,DWORD PTR [rsp+0x8]
  4096bd:	inc    rax
  4096c0:	jmp    4096c4 <__swc_fn_6b1cf01f_000126_5fb20c72+0x74>
  4096c2:	xor    eax,eax
  4096c4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4096ca:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4096d0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4096d6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4096dc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4096e2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4096e8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4096ee:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4096f7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409700:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409709:	add    rsp,0xb8
  409710:	pop    rsi
  409711:	pop    rdi
  409712:	ret
	...

0000000000409720 <__swc_fn_6b1cf01f_000129_0672cd48>:
  409720:	push   rdi
  409721:	push   rsi
  409722:	sub    rsp,0xa8
  409729:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40972f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409735:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40973b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409741:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409747:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40974d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409753:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409759:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409762:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40976b:	test   rcx,rcx
  40976e:	setne  al
  409771:	je     40978a <__swc_fn_6b1cf01f_000129_0672cd48+0x6a>
  409773:	lea    rax,[rcx-0x1]
  409777:	mov    eax,eax
  409779:	mov    edi,eax
  40977b:	mov    rsi,rdx
  40977e:	xor    eax,eax
  409780:	call   407060 <pthread_setspecific@plt>
  409785:	test   eax,eax
  409787:	sete   al
  40978a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409790:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409796:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40979c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4097a2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4097a8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4097ae:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4097b4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4097ba:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4097c3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4097cc:	add    rsp,0xa8
  4097d3:	pop    rsi
  4097d4:	pop    rdi
  4097d5:	ret
	...

00000000004097e0 <__swc_fn_6b1cf01f_000132_2b60f756>:
  4097e0:	push   rdi
  4097e1:	push   rsi
  4097e2:	sub    rsp,0xa8
  4097e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4097ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4097f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4097fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409801:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409807:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40980d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409813:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409819:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409822:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40982b:	mov    rax,rdx
  40982e:	mov    QWORD PTR [rsp],0x0
  409836:	mov    edi,0xca
  40983b:	mov    rsi,rcx
  40983e:	mov    edx,0x81
  409843:	mov    eax,eax
  409845:	mov    ecx,eax
  409847:	xor    r8d,r8d
  40984a:	xor    r9d,r9d
  40984d:	xor    eax,eax
  40984f:	call   407070 <syscall@plt>
  409854:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40985a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409860:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409866:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40986c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409872:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409878:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40987e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409884:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40988d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409896:	add    rsp,0xa8
  40989d:	pop    rsi
  40989e:	pop    rdi
  40989f:	ret

00000000004098a0 <__swc_fn_6b1cf01f_000135_1fec60ac>:
  4098a0:	sub    rsp,0x8
  4098a4:	call   40cc90 <__swc_fn_6b1cf01f_000133_c6de0049>
  4098a9:	add    rsp,0x8
  4098ad:	ret
	...

00000000004098b0 <__swc_fn_6b1cf01f_000138_2214b637>:
  4098b0:	push   rdi
  4098b1:	push   rsi
  4098b2:	sub    rsp,0xc8
  4098b9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4098bf:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4098c5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4098cb:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4098d1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4098d7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4098dd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  4098e6:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  4098ef:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  4098f8:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  409901:	vxorps xmm0,xmm0,xmm0
  409905:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40990b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409911:	mov    rdi,rcx
  409914:	lea    rsi,[rsp+0x8]
  409919:	xor    eax,eax
  40991b:	call   407080 <dladdr@plt>
  409920:	xor    ecx,ecx
  409922:	test   eax,eax
  409924:	je     40992b <__swc_fn_6b1cf01f_000138_2214b637+0x7b>
  409926:	mov    rcx,QWORD PTR [rsp+0x10]
  40992b:	mov    rax,rcx
  40992e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  409934:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40993a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  409940:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  409946:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40994c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  409952:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40995b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  409964:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40996d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  409976:	add    rsp,0xc8
  40997d:	pop    rsi
  40997e:	pop    rdi
  40997f:	ret

0000000000409980 <__swc_fn_6b1cf01f_000141_376d5f6d>:
  409980:	push   rbx
  409981:	push   r12
  409983:	push   r13
  409985:	push   rdi
  409986:	push   rsi
  409987:	push   r14
  409989:	push   r15
  40998b:	sub    rsp,0x150
  409992:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40999b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  4099a4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  4099ad:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  4099b6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  4099bf:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4099c8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4099d1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4099da:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  4099e3:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  4099ec:	mov    rbx,rdx
  4099ef:	mov    QWORD PTR [rsp+0x98],rdx
  4099f7:	mov    r12,rcx
  4099fa:	mov    QWORD PTR [rsp+0xa0],rcx
  409a02:	mov    QWORD PTR [rbx],0x0
  409a09:	lea    r13,[rip+0x1d370]        # 426d80 <__swc_bss_base_6b1cf01f+0x2d40>
  409a10:	mov    rcx,r13
  409a13:	call   4098a0 <__swc_fn_6b1cf01f_000135_1fec60ac>
  409a18:	mov    rax,QWORD PTR [rip+0x1d369]        # 426d88 <__swc_bss_base_6b1cf01f+0x2d48>
  409a1f:	test   rax,rax
  409a22:	je     409a59 <__swc_fn_6b1cf01f_000141_376d5f6d+0xd9>
  409a24:	cs nop WORD PTR [rax+rax*1+0x0]
  409a2e:	xchg   ax,ax
  409a30:	cmp    QWORD PTR [rax+0x8],r12
  409a34:	jne    409a51 <__swc_fn_6b1cf01f_000141_376d5f6d+0xd1>
  409a36:	mov    rcx,QWORD PTR [rax+0x18]
  409a3a:	mov    QWORD PTR [rbx],rcx
  409a3d:	mov    rbx,QWORD PTR [rax+0x10]
  409a41:	mov    rcx,r13
  409a44:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  409a49:	mov    rax,rbx
  409a4c:	jmp    409c3b <__swc_fn_6b1cf01f_000141_376d5f6d+0x2bb>
  409a51:	mov    rax,QWORD PTR [rax]
  409a54:	test   rax,rax
  409a57:	jne    409a30 <__swc_fn_6b1cf01f_000141_376d5f6d+0xb0>
  409a59:	vxorps xmm0,xmm0,xmm0
  409a5d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  409a63:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  409a69:	mov    rdi,r12
  409a6c:	lea    rsi,[rsp+0x10]
  409a71:	xor    eax,eax
  409a73:	call   407080 <dladdr@plt>
  409a78:	test   eax,eax
  409a7a:	sete   al
  409a7d:	je     409a8a <__swc_fn_6b1cf01f_000141_376d5f6d+0x10a>
  409a7f:	mov    rax,QWORD PTR [rsp+0x10]
  409a84:	test   rax,rax
  409a87:	sete   al
  409a8a:	test   al,al
  409a8c:	je     409a9d <__swc_fn_6b1cf01f_000141_376d5f6d+0x11d>
  409a8e:	mov    rcx,r13
  409a91:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  409a96:	xor    eax,eax
  409a98:	jmp    409c3b <__swc_fn_6b1cf01f_000141_376d5f6d+0x2bb>
  409a9d:	mov    rdi,QWORD PTR [rsp+0x10]
  409aa2:	mov    esi,0x80000
  409aa7:	xor    eax,eax
  409aa9:	call   407090 <open@plt>
  409aae:	lea    r14,[rsp+0x30]
  409ab3:	mov    DWORD PTR [rsp+0x30],eax
  409ab7:	cmp    DWORD PTR [r14],0x0
  409abb:	jge    409acc <__swc_fn_6b1cf01f_000141_376d5f6d+0x14c>
  409abd:	mov    rcx,r13
  409ac0:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  409ac5:	xor    eax,eax
  409ac7:	jmp    409c3b <__swc_fn_6b1cf01f_000141_376d5f6d+0x2bb>
  409acc:	mov    rax,r14
  409acf:	movsxd rdi,DWORD PTR [rax]
  409ad2:	xor    esi,esi
  409ad4:	mov    edx,0x2
  409ad9:	xor    eax,eax
  409adb:	call   4070a0 <lseek@plt>
  409ae0:	mov    r15,rax
  409ae3:	test   rax,rax
  409ae6:	jg     409b01 <__swc_fn_6b1cf01f_000141_376d5f6d+0x181>
  409ae8:	movsxd rdi,DWORD PTR [r14]
  409aeb:	xor    eax,eax
  409aed:	call   4070b0 <close@plt>
  409af2:	mov    rcx,r13
  409af5:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  409afa:	xor    eax,eax
  409afc:	jmp    409c3b <__swc_fn_6b1cf01f_000141_376d5f6d+0x2bb>
  409b01:	xor    edi,edi
  409b03:	mov    rsi,r15
  409b06:	mov    edx,0x1
  409b0b:	mov    ecx,0x2
  409b10:	mov    rax,r14
  409b13:	movsxd r8,DWORD PTR [rax]
  409b16:	xor    r9d,r9d
  409b19:	xor    eax,eax
  409b1b:	call   4070c0 <mmap@plt>
  409b20:	mov    rbx,rax
  409b23:	test   rax,rax
  409b26:	sete   al
  409b29:	cmp    rbx,0xffffffffffffffff
  409b2d:	sete   cl
  409b30:	or     al,cl
  409b32:	je     409b4d <__swc_fn_6b1cf01f_000141_376d5f6d+0x1cd>
  409b34:	movsxd rdi,DWORD PTR [r14]
  409b37:	xor    eax,eax
  409b39:	call   4070b0 <close@plt>
  409b3e:	mov    rcx,r13
  409b41:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  409b46:	xor    eax,eax
  409b48:	jmp    409c3b <__swc_fn_6b1cf01f_000141_376d5f6d+0x2bb>
  409b4d:	lea    rax,[rsp+0x50]
  409b52:	mov    QWORD PTR [rax],0x0
  409b59:	mov    rcx,rbx
  409b5c:	mov    rdx,r15
  409b5f:	mov    r8,rax
  409b62:	call   40fe60 <__swc_fn_6b1cf01f_000140_81b740ca>
  409b67:	mov    r12,rax
  409b6a:	test   rax,rax
  409b6d:	jne    409b95 <__swc_fn_6b1cf01f_000141_376d5f6d+0x215>
  409b6f:	mov    rdi,rbx
  409b72:	mov    rsi,r15
  409b75:	xor    eax,eax
  409b77:	call   407020 <munmap@plt>
  409b7c:	movsxd rdi,DWORD PTR [r14]
  409b7f:	xor    eax,eax
  409b81:	call   4070b0 <close@plt>
  409b86:	mov    rcx,r13
  409b89:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  409b8e:	xor    eax,eax
  409b90:	jmp    409c3b <__swc_fn_6b1cf01f_000141_376d5f6d+0x2bb>
  409b95:	mov    edi,0x20
  409b9a:	xor    eax,eax
  409b9c:	call   4070d0 <malloc@plt>
  409ba1:	test   rax,rax
  409ba4:	jne    409bc9 <__swc_fn_6b1cf01f_000141_376d5f6d+0x249>
  409ba6:	mov    rdi,rbx
  409ba9:	mov    rsi,r15
  409bac:	xor    eax,eax
  409bae:	call   407020 <munmap@plt>
  409bb3:	movsxd rdi,DWORD PTR [r14]
  409bb6:	xor    eax,eax
  409bb8:	call   4070b0 <close@plt>
  409bbd:	mov    rcx,r13
  409bc0:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  409bc5:	xor    eax,eax
  409bc7:	jmp    409c3b <__swc_fn_6b1cf01f_000141_376d5f6d+0x2bb>
  409bc9:	mov    rcx,QWORD PTR [rip+0x1d1b8]        # 426d88 <__swc_bss_base_6b1cf01f+0x2d48>
  409bd0:	mov    QWORD PTR [rsp+0x70],rcx
  409bd5:	mov    rcx,QWORD PTR [rsp+0xa0]
  409bdd:	mov    QWORD PTR [rsp+0x78],rcx
  409be2:	mov    QWORD PTR [rsp+0x80],r12
  409bea:	mov    rcx,QWORD PTR [rsp+0x50]
  409bef:	mov    QWORD PTR [rsp+0x88],rcx
  409bf7:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  409bfd:	vmovups XMMWORD PTR [rax],xmm0
  409c01:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  409c0a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  409c0f:	mov    QWORD PTR [rip+0x1d172],rax        # 426d88 <__swc_bss_base_6b1cf01f+0x2d48>
  409c16:	mov    rax,QWORD PTR [rsp+0x50]
  409c1b:	mov    rbx,QWORD PTR [rsp+0x98]
  409c23:	mov    QWORD PTR [rbx],rax
  409c26:	movsxd rdi,DWORD PTR [r14]
  409c29:	xor    eax,eax
  409c2b:	call   4070b0 <close@plt>
  409c30:	mov    rcx,r13
  409c33:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  409c38:	mov    rax,r12
  409c3b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  409c44:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  409c4d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  409c56:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  409c5f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  409c68:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  409c71:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  409c7a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  409c83:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  409c8c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  409c95:	add    rsp,0x150
  409c9c:	pop    r15
  409c9e:	pop    r14
  409ca0:	pop    rsi
  409ca1:	pop    rdi
  409ca2:	pop    r13
  409ca4:	pop    r12
  409ca6:	pop    rbx
  409ca7:	ret
	...

0000000000409cb0 <__swc_fn_6b1cf01f_000144_364559f5>:
  409cb0:	push   rbx
  409cb1:	sub    rsp,0xe0
  409cb8:	lea    rbx,[rsp+0x8]
  409cbd:	vxorps xmm0,xmm0,xmm0
  409cc1:	vmovups YMMWORD PTR [rbx],ymm0
  409cc5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  409cca:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  409ccf:	vzeroupper
  409cd2:	mov    DWORD PTR [rbx+0x60],0x0
  409cd9:	mov    r8,rbx
  409cdc:	nop    DWORD PTR [rax+0x0]
  409ce0:	mov    r9,rcx
  409ce3:	movabs rcx,0xcccccccccccccccd
  409ced:	mov    rax,r9
  409cf0:	mul    rcx
  409cf3:	mov    r10,rdx
  409cf6:	shr    r10,0x3
  409cfa:	mov    rcx,r10
  409cfd:	imul   rdx,r10,0xa
  409d01:	sub    r9,rdx
  409d04:	mov    rdx,QWORD PTR [rip+0x9835]        # 413540 <__swc_rdata_base_6b1cf01f+0x430>
  409d0b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  409d10:	mov    BYTE PTR [r8],dl
  409d13:	lea    rdx,[r8+0x1]
  409d17:	mov    r8,rdx
  409d1a:	test   r10,r10
  409d1d:	jne    409ce0 <__swc_fn_6b1cf01f_000144_364559f5+0x30>
  409d1f:	mov    BYTE PTR [rdx],0x0
  409d22:	sub    r8,0x1
  409d26:	mov    rax,rbx
  409d29:	cmp    rax,r8
  409d2c:	jae    409d46 <__swc_fn_6b1cf01f_000144_364559f5+0x96>
  409d2e:	xchg   ax,ax
  409d30:	mov    cl,BYTE PTR [r8]
  409d33:	mov    dl,BYTE PTR [rax]
  409d35:	mov    BYTE PTR [r8],dl
  409d38:	sub    r8,0x1
  409d3c:	mov    BYTE PTR [rax],cl
  409d3e:	inc    rax
  409d41:	cmp    rax,r8
  409d44:	jb     409d30 <__swc_fn_6b1cf01f_000144_364559f5+0x80>
  409d46:	xor    eax,eax
  409d48:	test   rbx,rbx
  409d4b:	je     409d6e <__swc_fn_6b1cf01f_000144_364559f5+0xbe>
  409d4d:	mov    rcx,rbx
  409d50:	mov    dl,BYTE PTR [rcx]
  409d52:	test   dl,dl
  409d54:	je     409d6e <__swc_fn_6b1cf01f_000144_364559f5+0xbe>
  409d56:	cs nop WORD PTR [rax+rax*1+0x0]
  409d60:	add    rcx,0x1
  409d64:	add    rax,0x1
  409d68:	mov    dl,BYTE PTR [rcx]
  409d6a:	test   dl,dl
  409d6c:	jne    409d60 <__swc_fn_6b1cf01f_000144_364559f5+0xb0>
  409d6e:	mov    QWORD PTR [rbx+0xa8],rbx
  409d75:	mov    QWORD PTR [rbx+0xb0],rax
  409d7c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  409d84:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  409d8c:	lea    rcx,[rbx+0xb8]
  409d93:	call   40f8d0 <__swc_fn_6b1cf01f_000116_3499f7d6>
  409d98:	add    rsp,0xe0
  409d9f:	pop    rbx
  409da0:	ret
	...

0000000000409db0 <__swc_fn_6b1cf01f_000147_c9c6528e>:
  409db0:	sub    rsp,0x8
  409db4:	mov    rax,QWORD PTR [rcx+0x8]
  409db8:	mov    r8,QWORD PTR [rdx+0x8]
  409dbc:	cmp    rax,r8
  409dbf:	je     409dc8 <__swc_fn_6b1cf01f_000147_c9c6528e+0x18>
  409dc1:	xor    eax,eax
  409dc3:	add    rsp,0x8
  409dc7:	ret
  409dc8:	test   rax,rax
  409dcb:	jne    409ddc <__swc_fn_6b1cf01f_000147_c9c6528e+0x2c>
  409dcd:	test   r8,r8
  409dd0:	jne    409ddc <__swc_fn_6b1cf01f_000147_c9c6528e+0x2c>
  409dd2:	mov    eax,0x1
  409dd7:	add    rsp,0x8
  409ddb:	ret
  409ddc:	mov    rcx,QWORD PTR [rcx]
  409ddf:	mov    rdx,QWORD PTR [rdx]
  409de2:	test   rcx,rcx
  409de5:	sete   r8b
  409de9:	test   rdx,rdx
  409dec:	sete   r9b
  409df0:	or     r8b,r9b
  409df3:	je     409e00 <__swc_fn_6b1cf01f_000147_c9c6528e+0x50>
  409df5:	cmp    rcx,rdx
  409df8:	sete   al
  409dfb:	add    rsp,0x8
  409dff:	ret
  409e00:	cmp    rcx,rdx
  409e03:	jne    409e0f <__swc_fn_6b1cf01f_000147_c9c6528e+0x5f>
  409e05:	mov    eax,0x1
  409e0a:	add    rsp,0x8
  409e0e:	ret
  409e0f:	mov    r8,rax
  409e12:	call   40c380 <__swc_fn_6b1cf01f_000106_77a5d54a>
  409e17:	test   eax,eax
  409e19:	sete   al
  409e1c:	add    rsp,0x8
  409e20:	ret
	...

0000000000409e30 <__swc_fn_6b1cf01f_000150_33e5e24f>:
  409e30:	vxorps xmm0,xmm0,xmm0
  409e34:	vmovups XMMWORD PTR [rcx],xmm0
  409e38:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e3d:	vxorps xmm0,xmm0,xmm0
  409e41:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e46:	vmovups xmm0,XMMWORD PTR [rip+0x97aa]        # 4135f8 <__swc_rdata_base_6b1cf01f+0x4e8>
  409e4e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e53:	ret
	...

0000000000409e60 <__swc_fn_6b1cf01f_000153_33e5e24f>:
  409e60:	vxorps xmm0,xmm0,xmm0
  409e64:	vmovups XMMWORD PTR [rcx],xmm0
  409e68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e6d:	vxorps xmm0,xmm0,xmm0
  409e71:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e76:	vmovups xmm0,XMMWORD PTR [rip+0x989a]        # 413718 <__swc_rdata_base_6b1cf01f+0x608>
  409e7e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e83:	mov    QWORD PTR [rcx+0x40],0x0
  409e8b:	ret
  409e8c:	add    BYTE PTR [rax],al
	...

0000000000409e90 <__swc_fn_6b1cf01f_000156_312df05a>:
  409e90:	push   rbx
  409e91:	sub    rsp,0x70
  409e95:	mov    rax,QWORD PTR [rcx]
  409e98:	mov    rbx,QWORD PTR [rcx+0x8]
  409e9c:	vxorps xmm0,xmm0,xmm0
  409ea0:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  409ea6:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  409eac:	vzeroupper
  409eaf:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  409eb5:	mov    QWORD PTR [rsp+0x48],rdx
  409eba:	mov    QWORD PTR [rsp+0x50],r8
  409ebf:	mov    rcx,rax
  409ec2:	lea    rdx,[rsp+0x8]
  409ec7:	mov    rbx,QWORD PTR [rbx+0x18]
  409ecb:	call   rbx
  409ecd:	add    rsp,0x70
  409ed1:	pop    rbx
  409ed2:	ret
	...

0000000000409ee0 <__swc_fn_6b1cf01f_000159_9d602c76>:
  409ee0:	push   rbx
  409ee1:	push   rsi
  409ee2:	push   rdi
  409ee3:	mov    rbx,r8
  409ee6:	mov    rsi,rcx
  409ee9:	mov    rdi,rdx
  409eec:	call   40d090 <__swc_fn_6b1cf01f_000157_5c8b11d8>
  409ef1:	vmovups xmm0,XMMWORD PTR [rbx]
  409ef5:	vmovups XMMWORD PTR [rsi],xmm0
  409ef9:	mov    QWORD PTR [rsi+0x18],rdi
  409efd:	pop    rdi
  409efe:	pop    rsi
  409eff:	pop    rbx
  409f00:	ret
	...

0000000000409f10 <__swc_fn_6b1cf01f_000162_edb9cf73>:
  409f10:	push   rbx
  409f11:	push   rsi
  409f12:	push   rdi
  409f13:	push   r12
  409f15:	push   r13
  409f17:	sub    rsp,0x50
  409f1b:	mov    rbx,rcx
  409f1e:	mov    rsi,rdx
  409f21:	vmovups xmm0,XMMWORD PTR [rip+0x98ff]        # 413828 <__swc_rdata_base_6b1cf01f+0x718>
  409f29:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409f2f:	vmovups xmm0,XMMWORD PTR [rip+0x9901]        # 413838 <__swc_rdata_base_6b1cf01f+0x728>
  409f37:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409f3d:	vxorps xmm0,xmm0,xmm0
  409f41:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409f47:	mov    rcx,rdx
  409f4a:	call   4098b0 <__swc_fn_6b1cf01f_000138_2214b637>
  409f4f:	mov    rdi,rax
  409f52:	test   rax,rax
  409f55:	jne    409f86 <__swc_fn_6b1cf01f_000162_edb9cf73+0x76>
  409f57:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409f5d:	vmovups XMMWORD PTR [rbx],xmm0
  409f61:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409f67:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409f6c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409f72:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409f77:	mov    rax,rbx
  409f7a:	add    rsp,0x50
  409f7e:	pop    r13
  409f80:	pop    r12
  409f82:	pop    rdi
  409f83:	pop    rsi
  409f84:	pop    rbx
  409f85:	ret
  409f86:	mov    rcx,rdi
  409f89:	call   411380 <__swc_fn_6b1cf01f_000161_9e36e814>
  409f8e:	mov    r11,rax
  409f91:	test   rax,rax
  409f94:	je     409f9e <__swc_fn_6b1cf01f_000162_edb9cf73+0x8e>
  409f96:	mov    al,BYTE PTR [r11+0x24]
  409f9a:	test   al,al
  409f9c:	jne    409fcd <__swc_fn_6b1cf01f_000162_edb9cf73+0xbd>
  409f9e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fa4:	vmovups XMMWORD PTR [rbx],xmm0
  409fa8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fae:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fb3:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fb9:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fbe:	mov    rax,rbx
  409fc1:	add    rsp,0x50
  409fc5:	pop    r13
  409fc7:	pop    r12
  409fc9:	pop    rdi
  409fca:	pop    rsi
  409fcb:	pop    rbx
  409fcc:	ret
  409fcd:	sub    rsi,rdi
  409fd0:	mov    eax,0xffffffff
  409fd5:	cmp    rsi,rax
  409fd8:	jbe    40a009 <__swc_fn_6b1cf01f_000162_edb9cf73+0xf9>
  409fda:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fe0:	vmovups XMMWORD PTR [rbx],xmm0
  409fe4:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fea:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fef:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409ff5:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409ffa:	mov    rax,rbx
  409ffd:	add    rsp,0x50
  40a001:	pop    r13
  40a003:	pop    r12
  40a005:	pop    rdi
  40a006:	pop    rsi
  40a007:	pop    rbx
  40a008:	ret
  40a009:	mov    rdi,QWORD PTR [r11+0x10]
  40a00d:	mov    eax,DWORD PTR [r11+0x20]
  40a011:	xor    ecx,ecx
  40a013:	test   rax,rax
  40a016:	jbe    40a168 <__swc_fn_6b1cf01f_000162_edb9cf73+0x258>
  40a01c:	nop    DWORD PTR [rax+0x0]
  40a020:	mov    edx,ecx
  40a022:	imul   r12,rdx,0x14
  40a026:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40a02b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40a030:	mov    r9d,esi
  40a033:	cmp    r9,rdx
  40a036:	jb     40a15b <__swc_fn_6b1cf01f_000162_edb9cf73+0x24b>
  40a03c:	add    rdx,r8
  40a03f:	mov    r8d,esi
  40a042:	cmp    r8,rdx
  40a045:	jae    40a15b <__swc_fn_6b1cf01f_000162_edb9cf73+0x24b>
  40a04b:	lea    rsi,[rsp+0x38]
  40a050:	mov    eax,DWORD PTR [rdi+0xc]
  40a053:	mov    DWORD PTR [rsp+0x38],eax
  40a057:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40a05c:	mov    rcx,rdi
  40a05f:	mov    rdx,QWORD PTR [r11+0x18]
  40a063:	mov    r8,rsi
  40a066:	mov    r8d,DWORD PTR [r8]
  40a069:	mov    r9,rax
  40a06c:	lea    r10,[rsp+0x10]
  40a071:	call   40d0e0 <__swc_fn_6b1cf01f_000160_e25d06b9>
  40a076:	test   al,al
  40a078:	jne    40a0ab <__swc_fn_6b1cf01f_000162_edb9cf73+0x19b>
  40a07a:	vmovups xmm0,XMMWORD PTR [rip+0x97d6]        # 413858 <__swc_rdata_base_6b1cf01f+0x748>
  40a082:	vmovups XMMWORD PTR [rbx],xmm0
  40a086:	vmovups xmm0,XMMWORD PTR [rip+0x97da]        # 413868 <__swc_rdata_base_6b1cf01f+0x758>
  40a08e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a093:	vxorps xmm0,xmm0,xmm0
  40a097:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a09c:	mov    rax,rbx
  40a09f:	add    rsp,0x50
  40a0a3:	pop    r13
  40a0a5:	pop    r12
  40a0a7:	pop    rdi
  40a0a8:	pop    rsi
  40a0a9:	pop    rbx
  40a0aa:	ret
  40a0ab:	lea    r13,[rsp+0x3c]
  40a0b0:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40a0b5:	mov    DWORD PTR [rsp+0x3c],eax
  40a0b9:	test   eax,eax
  40a0bb:	je     40a10c <__swc_fn_6b1cf01f_000162_edb9cf73+0x1fc>
  40a0bd:	mov    rcx,rdi
  40a0c0:	mov    rdx,QWORD PTR [r11+0x18]
  40a0c4:	mov    r8d,DWORD PTR [rsi]
  40a0c7:	mov    rax,r13
  40a0ca:	mov    r9d,DWORD PTR [rax]
  40a0cd:	lea    r10,[rsp+0x20]
  40a0d2:	call   40d0e0 <__swc_fn_6b1cf01f_000160_e25d06b9>
  40a0d7:	test   al,al
  40a0d9:	jne    40a10c <__swc_fn_6b1cf01f_000162_edb9cf73+0x1fc>
  40a0db:	vmovups xmm0,XMMWORD PTR [rip+0x97a5]        # 413888 <__swc_rdata_base_6b1cf01f+0x778>
  40a0e3:	vmovups XMMWORD PTR [rbx],xmm0
  40a0e7:	vmovups xmm0,XMMWORD PTR [rip+0x97a9]        # 413898 <__swc_rdata_base_6b1cf01f+0x788>
  40a0ef:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a0f4:	vxorps xmm0,xmm0,xmm0
  40a0f8:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a0fd:	mov    rax,rbx
  40a100:	add    rsp,0x50
  40a104:	pop    r13
  40a106:	pop    r12
  40a108:	pop    rdi
  40a109:	pop    rsi
  40a10a:	pop    rbx
  40a10b:	ret
  40a10c:	mov    eax,0x1
  40a111:	rex mov BYTE PTR [rsp+0x8],al
  40a116:	cmp    DWORD PTR [r13+0x0],0x0
  40a11b:	je     40a12c <__swc_fn_6b1cf01f_000162_edb9cf73+0x21c>
  40a11d:	rex mov BYTE PTR [rsp+0x9],0x1
  40a123:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40a128:	mov    DWORD PTR [rsp+0x30],eax
  40a12c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a132:	vmovups XMMWORD PTR [rbx],xmm0
  40a136:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a13c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a141:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a147:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a14c:	mov    rax,rbx
  40a14f:	add    rsp,0x50
  40a153:	pop    r13
  40a155:	pop    r12
  40a157:	pop    rdi
  40a158:	pop    rsi
  40a159:	pop    rbx
  40a15a:	ret
  40a15b:	add    rcx,0x1
  40a15f:	cmp    rcx,rax
  40a162:	jb     40a020 <__swc_fn_6b1cf01f_000162_edb9cf73+0x110>
  40a168:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a16e:	vmovups XMMWORD PTR [rbx],xmm0
  40a172:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a178:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a17d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a183:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a188:	mov    rax,rbx
  40a18b:	add    rsp,0x50
  40a18f:	pop    r13
  40a191:	pop    r12
  40a193:	pop    rdi
  40a194:	pop    rsi
  40a195:	pop    rbx
  40a196:	ret
	...

000000000040a1a0 <__swc_fn_6b1cf01f_000165_e09accff>:
  40a1a0:	sub    rsp,0x48
  40a1a4:	call   409580 <__swc_fn_6b1cf01f_000123_e9227a3e>
  40a1a9:	cmp    rax,0xffffffffffffffff
  40a1ad:	je     40a1b4 <__swc_fn_6b1cf01f_000165_e09accff+0x14>
  40a1af:	add    rsp,0x48
  40a1b3:	ret
  40a1b4:	lea    rcx,[rip+0x970d]        # 4138c8 <__swc_rdata_base_6b1cf01f+0x7b8>
  40a1bb:	vmovups xmm0,XMMWORD PTR [rip+0x9715]        # 4138d8 <__swc_rdata_base_6b1cf01f+0x7c8>
  40a1c3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a1c9:	vmovups xmm0,XMMWORD PTR [rip+0x9717]        # 4138e8 <__swc_rdata_base_6b1cf01f+0x7d8>
  40a1d1:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a1d7:	vmovups xmm0,XMMWORD PTR [rip+0x9719]        # 4138f8 <__swc_rdata_base_6b1cf01f+0x7e8>
  40a1df:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a1e5:	lea    rdx,[rsp+0x8]
  40a1ea:	mov    QWORD PTR [rsp+0x38],rax
  40a1ef:	call   40c2c0 <__swc_fn_6b1cf01f_000103_2ed36338>
  40a1f4:	mov    rax,QWORD PTR [rsp+0x38]
  40a1f9:	jmp    40a1af <__swc_fn_6b1cf01f_000165_e09accff+0xf>
  40a1fb:	add    BYTE PTR [rax],al
  40a1fd:	add    BYTE PTR [rax],al
	...

000000000040a200 <__swc_fn_6b1cf01f_000168_0ff0458f>:
  40a200:	push   rbx
  40a201:	push   rsi
  40a202:	sub    rsp,0x28
  40a206:	mov    rbx,rcx
  40a209:	mov    DWORD PTR [rsp+0x8],0xbf0
  40a211:	mov    ecx,0xbf0
  40a216:	call   40beb0 <__swc_fn_6b1cf01f_000079_29fad089>
  40a21b:	mov    rsi,rax
  40a21e:	test   rax,rax
  40a221:	jne    40a22c <__swc_fn_6b1cf01f_000168_0ff0458f+0x2c>
  40a223:	xor    eax,eax
  40a225:	add    rsp,0x28
  40a229:	pop    rsi
  40a22a:	pop    rbx
  40a22b:	ret
  40a22c:	vxorps xmm0,xmm0,xmm0
  40a230:	xor    eax,eax
  40a232:	cs nop WORD PTR [rax+rax*1+0x0]
  40a23c:	nop    DWORD PTR [rax+0x0]
  40a240:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40a245:	add    rax,0x10
  40a249:	cmp    rax,0xbf0
  40a250:	jne    40a240 <__swc_fn_6b1cf01f_000168_0ff0458f+0x40>
  40a252:	lea    rax,[rbx+0x1]
  40a256:	mov    QWORD PTR [rsi+0x9c0],rax
  40a25d:	mov    rcx,rbx
  40a260:	mov    rdx,rsi
  40a263:	call   40d440 <__swc_fn_6b1cf01f_000166_31ca4f53>
  40a268:	test   al,al
  40a26a:	jne    40a27d <__swc_fn_6b1cf01f_000168_0ff0458f+0x7d>
  40a26c:	mov    rcx,rsi
  40a26f:	call   40e850 <__swc_fn_6b1cf01f_000080_851c599a>
  40a274:	xor    eax,eax
  40a276:	add    rsp,0x28
  40a27a:	pop    rsi
  40a27b:	pop    rbx
  40a27c:	ret
  40a27d:	lea    rcx,[rsp+0x18]
  40a282:	call   40edd0 <__swc_fn_6b1cf01f_000092_17e20532>
  40a287:	mov    rax,rsi
  40a28a:	add    rsp,0x28
  40a28e:	pop    rsi
  40a28f:	pop    rbx
  40a290:	ret
	...

000000000040a2a0 <__swc_fn_6b1cf01f_000171_06b64c88>:
  40a2a0:	xor    eax,eax
  40a2a2:	mov    edx,0x1
  40a2a7:	lock cmpxchg QWORD PTR [rcx],rdx
  40a2ac:	test   rax,rax
  40a2af:	jne    40a2b2 <__swc_fn_6b1cf01f_000171_06b64c88+0x12>
  40a2b1:	ret
  40a2b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2bc:	nop    DWORD PTR [rax+0x0]
  40a2c0:	mov    rax,QWORD PTR [rcx]
  40a2c3:	test   rax,rax
  40a2c6:	je     40a2a0 <__swc_fn_6b1cf01f_000171_06b64c88>
  40a2c8:	jmp    40a2c0 <__swc_fn_6b1cf01f_000171_06b64c88+0x20>
  40a2ca:	add    BYTE PTR [rax],al
  40a2cc:	add    BYTE PTR [rax],al
	...

000000000040a2d0 <__swc_fn_6b1cf01f_000174_738eec22>:
  40a2d0:	push   rsi
  40a2d1:	push   rdi
  40a2d2:	sub    rsp,0x38
  40a2d6:	mov    rsi,rcx
  40a2d9:	call   40d450 <__swc_fn_6b1cf01f_000169_aabbfb4c>
  40a2de:	mov    rdi,rax
  40a2e1:	call   40cbe0 <__swc_fn_6b1cf01f_000130_d2d78689>
  40a2e6:	mov    r8,rax
  40a2e9:	mov    rcx,rdi
  40a2ec:	call   40a2a0 <__swc_fn_6b1cf01f_000171_06b64c88>
  40a2f1:	mov    rax,QWORD PTR [rdi+0x8]
  40a2f5:	test   rax,rax
  40a2f8:	je     40a335 <__swc_fn_6b1cf01f_000174_738eec22+0x65>
  40a2fa:	nop    WORD PTR [rax+rax*1+0x0]
  40a300:	cmp    rax,rsi
  40a303:	je     40a335 <__swc_fn_6b1cf01f_000174_738eec22+0x65>
  40a305:	mov    r9,QWORD PTR [rax]
  40a308:	cmp    QWORD PTR [rax+0x20],r8
  40a30c:	jne    40a32d <__swc_fn_6b1cf01f_000174_738eec22+0x5d>
  40a30e:	mov    rcx,rdi
  40a311:	mov    rdx,rax
  40a314:	mov    QWORD PTR [rsp+0x28],r8
  40a319:	mov    QWORD PTR [rsp+0x30],r9
  40a31e:	call   4117a0 <__swc_fn_6b1cf01f_000173_156cb9fe>
  40a323:	mov    r8,QWORD PTR [rsp+0x28]
  40a328:	mov    r9,QWORD PTR [rsp+0x30]
  40a32d:	mov    rax,r9
  40a330:	test   r9,r9
  40a333:	jne    40a300 <__swc_fn_6b1cf01f_000174_738eec22+0x30>
  40a335:	xor    eax,eax
  40a337:	mov    QWORD PTR [rdi],rax
  40a33a:	add    rsp,0x38
  40a33e:	pop    rdi
  40a33f:	pop    rsi
  40a340:	ret
	...

000000000040a360 <__swc_fn_6b1cf01f_000001_29b04951>:
  40a360:	vxorps xmm0,xmm0,xmm0
  40a364:	xor    eax,eax
  40a366:	cs nop WORD PTR [rax+rax*1+0x0]
  40a370:	cs nop WORD PTR [rax+rax*1+0x0]
  40a37a:	nop    WORD PTR [rax+rax*1+0x0]
  40a380:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a385:	add    rax,0x10
  40a389:	cmp    rax,0x2080
  40a390:	jne    40a380 <__swc_fn_6b1cf01f_000001_29b04951+0x20>
  40a392:	ret
	...

000000000040a3a0 <__swc_fn_6b1cf01f_000004_2fa5c690>:
  40a3a0:	push   rsi
  40a3a1:	push   rdi
  40a3a2:	push   r12
  40a3a4:	push   r13
  40a3a6:	push   r14
  40a3a8:	mov    rsi,rcx
  40a3ab:	mov    edi,r10d
  40a3ae:	mov    r12,rcx
  40a3b1:	mov    r13,r9
  40a3b4:	mov    ecx,DWORD PTR [rdx+0x28]
  40a3b7:	shlx   r14d,r8d,ecx
  40a3bc:	mov    rcx,rdx
  40a3bf:	mov    edx,r8d
  40a3c2:	call   40d720 <__swc_fn_6b1cf01f_000011_e75d466d>
  40a3c7:	mov    rcx,rax
  40a3ca:	mov    eax,DWORD PTR [r12+0x3c]
  40a3cf:	xor    edx,edx
  40a3d1:	div    rdi
  40a3d4:	vxorps xmm0,xmm0,xmm0
  40a3d8:	vmovdqu XMMWORD PTR [rsi],xmm0
  40a3dc:	mov    QWORD PTR [r12+0x60],0x0
  40a3e5:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40a3ea:	mov    QWORD PTR [r12+0x10],rcx
  40a3ef:	imul   rax,rdi
  40a3f3:	lea    rdx,[rcx+rax*1]
  40a3f7:	mov    QWORD PTR [r12+0x18],rdx
  40a3fc:	mov    QWORD PTR [r12+0x20],rcx
  40a401:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40a406:	mov    DWORD PTR [r12+0x28],0x0
  40a40f:	mov    DWORD PTR [r12+0x68],0x0
  40a418:	mov    BYTE PTR [r12+0x39],r13b
  40a41d:	mov    BYTE PTR [r12+0x3a],r14b
  40a422:	mov    BYTE PTR [r12+0x3b],0x1
  40a428:	mov    DWORD PTR [r12+0x6c],0x0
  40a431:	mov    rcx,r12
  40a434:	mov    edx,edi
  40a436:	call   40d680 <__swc_fn_6b1cf01f_000005_bcc5b80b>
  40a43b:	pop    r14
  40a43d:	pop    r13
  40a43f:	pop    r12
  40a441:	pop    rdi
  40a442:	pop    rsi
  40a443:	ret
	...

000000000040a450 <__swc_fn_6b1cf01f_000007_635028f3>:
  40a450:	mov    r8d,0x1
  40a456:	xor    eax,eax
  40a458:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40a45e:	test   eax,eax
  40a460:	jne    40a450 <__swc_fn_6b1cf01f_000007_635028f3>
  40a462:	ret
	...

000000000040a470 <__swc_fn_6b1cf01f_000010_186cd0c2>:
  40a470:	lea    r8,[rcx+0x60]
  40a474:	mov    rax,QWORD PTR [r8]
  40a477:	mov    r9,rax
  40a47a:	nop    WORD PTR [rax+rax*1+0x0]
  40a480:	mov    QWORD PTR [rdx],r9
  40a483:	mov    rax,r9
  40a486:	lock cmpxchg QWORD PTR [r8],rdx
  40a48b:	cmp    rax,r9
  40a48e:	jne    40a4f7 <__swc_fn_6b1cf01f_000010_186cd0c2+0x87>
  40a490:	mov    eax,DWORD PTR [rcx+0x6c]
  40a493:	test   eax,eax
  40a495:	je     40a4f6 <__swc_fn_6b1cf01f_000010_186cd0c2+0x86>
  40a497:	lea    rdx,[rcx+0x70]
  40a49b:	mov    r9d,0x1
  40a4a1:	xor    eax,eax
  40a4a3:	lock cmpxchg DWORD PTR [rdx],r9d
  40a4a8:	test   eax,eax
  40a4aa:	jne    40a4f6 <__swc_fn_6b1cf01f_000010_186cd0c2+0x86>
  40a4ac:	mov    rax,rcx
  40a4af:	and    rax,0xffffffffffc00000
  40a4b6:	mov    rax,QWORD PTR [rax+0x8]
  40a4ba:	test   rax,rax
  40a4bd:	jne    40a4c5 <__swc_fn_6b1cf01f_000010_186cd0c2+0x55>
  40a4bf:	xor    eax,eax
  40a4c1:	xchg   DWORD PTR [rdx],eax
  40a4c3:	jmp    40a4f6 <__swc_fn_6b1cf01f_000010_186cd0c2+0x86>
  40a4c5:	lea    rdx,[rax+0x2a80]
  40a4cc:	mov    rax,QWORD PTR [rdx]
  40a4cf:	mov    r8,rax
  40a4d2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a4dc:	nop    DWORD PTR [rax+0x0]
  40a4e0:	mov    QWORD PTR [rcx+0x78],r8
  40a4e4:	mov    rax,r8
  40a4e7:	lock cmpxchg QWORD PTR [rdx],rcx
  40a4ec:	cmp    rax,r8
  40a4ef:	je     40a4f6 <__swc_fn_6b1cf01f_000010_186cd0c2+0x86>
  40a4f1:	mov    r8,rax
  40a4f4:	jmp    40a4e0 <__swc_fn_6b1cf01f_000010_186cd0c2+0x70>
  40a4f6:	ret
  40a4f7:	mov    r9,rax
  40a4fa:	jmp    40a480 <__swc_fn_6b1cf01f_000010_186cd0c2+0x10>
	...

000000000040a500 <__swc_fn_6b1cf01f_000013_d15d37c6>:
  40a500:	push   rsi
  40a501:	push   rdi
  40a502:	push   r12
  40a504:	push   r13
  40a506:	push   r14
  40a508:	push   r15
  40a50a:	push   rbx
  40a50b:	sub    rsp,0x30
  40a50f:	mov    QWORD PTR [rsp+0x18],r8
  40a514:	mov    rsi,rcx
  40a517:	mov    rdi,rdx
  40a51a:	mov    rdx,QWORD PTR [rsi+0x40]
  40a51e:	xchg   ax,ax
  40a520:	mov    rax,rdx
  40a523:	not    rax
  40a526:	and    rax,QWORD PTR [rsi+0x20]
  40a52a:	test   rax,rax
  40a52d:	jne    40a541 <__swc_fn_6b1cf01f_000013_d15d37c6+0x41>
  40a52f:	xor    eax,eax
  40a531:	add    rsp,0x30
  40a535:	pop    rbx
  40a536:	pop    r15
  40a538:	pop    r14
  40a53a:	pop    r13
  40a53c:	pop    r12
  40a53e:	pop    rdi
  40a53f:	pop    rsi
  40a540:	ret
  40a541:	xor    ecx,ecx
  40a543:	tzcnt  rcx,rax
  40a548:	lea    r12,[rsp+0x8]
  40a54d:	mov    DWORD PTR [rsp+0x8],ecx
  40a551:	mov    r13d,0x1
  40a557:	shl    r13,cl
  40a55a:	mov    rcx,rdx
  40a55d:	or     rcx,r13
  40a560:	mov    rax,rdx
  40a563:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40a569:	cmp    rax,rdx
  40a56c:	je     40a573 <__swc_fn_6b1cf01f_000013_d15d37c6+0x73>
  40a56e:	mov    rdx,rax
  40a571:	jmp    40a520 <__swc_fn_6b1cf01f_000013_d15d37c6+0x20>
  40a573:	mov    eax,DWORD PTR [r12]
  40a577:	shl    rax,0x4
  40a57b:	lea    r14,[rsi+rax*8+0x80]
  40a583:	mov    rcx,rsi
  40a586:	mov    rax,r12
  40a589:	mov    edx,DWORD PTR [rax]
  40a58b:	call   40d720 <__swc_fn_6b1cf01f_000011_e75d466d>
  40a590:	mov    r15,rax
  40a593:	mov    rcx,rsi
  40a596:	mov    rdx,r13
  40a599:	call   40d880 <__swc_fn_6b1cf01f_000017_e238d24c>
  40a59e:	test   al,al
  40a5a0:	je     40a5d8 <__swc_fn_6b1cf01f_000013_d15d37c6+0xd8>
  40a5a2:	mov    ecx,DWORD PTR [r14+0x3c]
  40a5a6:	lea    rdx,[rip+0x19aab]        # 424058 <__swc_bss_base_6b1cf01f+0x18>
  40a5ad:	mov    r8,QWORD PTR [rip+0x19aa4]        # 424058 <__swc_bss_base_6b1cf01f+0x18>
  40a5b4:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5be:	xchg   ax,ax
  40a5c0:	mov    r9,r8
  40a5c3:	sub    r9,rcx
  40a5c6:	mov    rax,r8
  40a5c9:	lock cmpxchg QWORD PTR [rdx],r9
  40a5ce:	cmp    rax,r8
  40a5d1:	je     40a639 <__swc_fn_6b1cf01f_000013_d15d37c6+0x139>
  40a5d3:	mov    r8,rax
  40a5d6:	jmp    40a5c0 <__swc_fn_6b1cf01f_000013_d15d37c6+0xc0>
  40a5d8:	mov    rcx,rsi
  40a5db:	mov    rax,r12
  40a5de:	mov    edx,DWORD PTR [rax]
  40a5e0:	call   407450 <__swc_fn_6b1cf01f_000012_39679ef8>
  40a5e5:	mov    rcx,r15
  40a5e8:	and    rcx,0xffffffffffff0000
  40a5ef:	lea    rcx,[rcx+0x10000]
  40a5f6:	mov    rbx,rax
  40a5f9:	cmp    rax,rcx
  40a5fc:	cmova  rbx,rcx
  40a600:	mov    rax,rbx
  40a603:	sub    rax,r15
  40a606:	mov    rcx,r15
  40a609:	mov    rdx,rax
  40a60c:	call   4072a0 <__swc_fn_6b1cf01f_000003_644dadb7>
  40a611:	test   al,al
  40a613:	jne    40a632 <__swc_fn_6b1cf01f_000013_d15d37c6+0x132>
  40a615:	mov    rcx,rsi
  40a618:	mov    rdx,r13
  40a61b:	call   407600 <__swc_fn_6b1cf01f_000018_e2e8e4b0>
  40a620:	xor    eax,eax
  40a622:	add    rsp,0x30
  40a626:	pop    rbx
  40a627:	pop    r15
  40a629:	pop    r14
  40a62b:	pop    r13
  40a62d:	pop    r12
  40a62f:	pop    rdi
  40a630:	pop    rsi
  40a631:	ret
  40a632:	sub    rbx,r15
  40a635:	mov    DWORD PTR [r14+0x3c],ebx
  40a639:	mov    rcx,r14
  40a63c:	mov    rdx,rsi
  40a63f:	mov    r8d,DWORD PTR [r12]
  40a643:	mov    r9d,edi
  40a646:	mov    rbx,QWORD PTR [rsp+0x18]
  40a64b:	mov    r10d,ebx
  40a64e:	call   40a3a0 <__swc_fn_6b1cf01f_000004_2fa5c690>
  40a653:	mov    rax,r14
  40a656:	add    rsp,0x30
  40a65a:	pop    rbx
  40a65b:	pop    r15
  40a65d:	pop    r14
  40a65f:	pop    r13
  40a661:	pop    r12
  40a663:	pop    rdi
  40a664:	pop    rsi
  40a665:	ret
	...

000000000040a670 <__swc_fn_6b1cf01f_000016_89da4d6e>:
  40a670:	mov    r8,QWORD PTR [rcx+0x48]
  40a674:	cs nop WORD PTR [rax+rax*1+0x0]
  40a67e:	xchg   ax,ax
  40a680:	mov    r9,r8
  40a683:	or     r9,rdx
  40a686:	mov    rax,r8
  40a689:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40a68f:	cmp    rax,r8
  40a692:	jne    40a695 <__swc_fn_6b1cf01f_000016_89da4d6e+0x25>
  40a694:	ret
  40a695:	mov    r8,rax
  40a698:	jmp    40a680 <__swc_fn_6b1cf01f_000016_89da4d6e+0x10>
  40a69a:	add    BYTE PTR [rax],al
  40a69c:	add    BYTE PTR [rax],al
	...

000000000040a6a0 <__swc_fn_6b1cf01f_000019_60e50998>:
  40a6a0:	push   rsi
  40a6a1:	push   rdi
  40a6a2:	push   r12
  40a6a4:	mov    rsi,rcx
  40a6a7:	xor    edi,edi
  40a6a9:	lea    r12,[rip+0x199b8]        # 424068 <__swc_bss_base_6b1cf01f+0x28>
  40a6b0:	mov    eax,DWORD PTR [r12]
  40a6b4:	xor    ecx,ecx
  40a6b6:	test   rax,rax
  40a6b9:	jbe    40a6f4 <__swc_fn_6b1cf01f_000019_60e50998+0x54>
  40a6bb:	nop    DWORD PTR [rax+rax*1+0x0]
  40a6c0:	lea    rdx,[rip+0x199a9]        # 424070 <__swc_bss_base_6b1cf01f+0x30>
  40a6c7:	mov    r8d,ecx
  40a6ca:	lea    r8,[r8+r8*2]
  40a6ce:	lea    r8,[rdx+r8*8]
  40a6d2:	mov    rdx,QWORD PTR [r8+0x10]
  40a6d6:	add    rdx,0x400000
  40a6dd:	cmp    rdx,0x40000000
  40a6e4:	ja     40a6eb <__swc_fn_6b1cf01f_000019_60e50998+0x4b>
  40a6e6:	mov    rdi,r8
  40a6e9:	jmp    40a6f4 <__swc_fn_6b1cf01f_000019_60e50998+0x54>
  40a6eb:	add    rcx,0x1
  40a6ef:	cmp    rcx,rax
  40a6f2:	jb     40a6c0 <__swc_fn_6b1cf01f_000019_60e50998+0x20>
  40a6f4:	test   rdi,rdi
  40a6f7:	jne    40a783 <__swc_fn_6b1cf01f_000019_60e50998+0xe3>
  40a6fd:	cmp    DWORD PTR [r12],0x10
  40a702:	jae    40a76b <__swc_fn_6b1cf01f_000019_60e50998+0xcb>
  40a704:	mov    ecx,0x40400000
  40a709:	call   40d640 <__swc_fn_6b1cf01f_000002_390d5093>
  40a70e:	test   rax,rax
  40a711:	je     40a76b <__swc_fn_6b1cf01f_000019_60e50998+0xcb>
  40a713:	lea    rcx,[rip+0x19956]        # 424070 <__swc_bss_base_6b1cf01f+0x30>
  40a71a:	mov    edx,DWORD PTR [r12]
  40a71e:	lea    rdx,[rdx+rdx*2]
  40a722:	lea    rdx,[rcx+rdx*8]
  40a726:	mov    QWORD PTR [rdx],rax
  40a729:	lea    rax,[rax+0x3fffff]
  40a730:	and    rax,0xffffffffffc00000
  40a737:	mov    QWORD PTR [rdx+0x8],rax
  40a73b:	mov    QWORD PTR [rdx+0x10],0x0
  40a743:	mov    edx,DWORD PTR [rip+0x1991f]        # 424068 <__swc_bss_base_6b1cf01f+0x28>
  40a749:	nop    DWORD PTR [rax+0x0]
  40a750:	lea    r9d,[rdx+0x1]
  40a754:	mov    rax,rdx
  40a757:	lock cmpxchg DWORD PTR [r12],r9d
  40a75d:	mov    r8d,eax
  40a760:	cmp    eax,edx
  40a762:	je     40a772 <__swc_fn_6b1cf01f_000019_60e50998+0xd2>
  40a764:	mov    rdx,r8
  40a767:	jmp    40a750 <__swc_fn_6b1cf01f_000019_60e50998+0xb0>
  40a769:	jmp    40a772 <__swc_fn_6b1cf01f_000019_60e50998+0xd2>
  40a76b:	xor    eax,eax
  40a76d:	pop    r12
  40a76f:	pop    rdi
  40a770:	pop    rsi
  40a771:	ret
  40a772:	mov    eax,DWORD PTR [rip+0x198f0]        # 424068 <__swc_bss_base_6b1cf01f+0x28>
  40a778:	sub    eax,0x1
  40a77b:	lea    rdi,[rax+rax*2]
  40a77f:	lea    rdi,[rcx+rdi*8]
  40a783:	mov    r12,QWORD PTR [rdi+0x8]
  40a787:	add    r12,QWORD PTR [rdi+0x10]
  40a78b:	mov    rcx,r12
  40a78e:	mov    edx,0x3000
  40a793:	call   4072a0 <__swc_fn_6b1cf01f_000003_644dadb7>
  40a798:	test   al,al
  40a79a:	jne    40a7a3 <__swc_fn_6b1cf01f_000019_60e50998+0x103>
  40a79c:	xor    eax,eax
  40a79e:	pop    r12
  40a7a0:	pop    rdi
  40a7a1:	pop    rsi
  40a7a2:	ret
  40a7a3:	vxorps xmm0,xmm0,xmm0
  40a7a7:	xor    eax,eax
  40a7a9:	cs nop WORD PTR [rax+rax*1+0x0]
  40a7b3:	cs nop WORD PTR [rax+rax*1+0x0]
  40a7bd:	nop    DWORD PTR [rax]
  40a7c0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40a7c6:	add    rax,0x10
  40a7ca:	cmp    rax,0x3000
  40a7d1:	jne    40a7c0 <__swc_fn_6b1cf01f_000019_60e50998+0x120>
  40a7d3:	mov    DWORD PTR [r12+0x28],esi
  40a7d8:	mov    eax,0x40
  40a7dd:	mov    ecx,esi
  40a7df:	shr    eax,cl
  40a7e1:	mov    DWORD PTR [r12+0x2c],eax
  40a7e6:	cmp    DWORD PTR [r12+0x2c],0x40
  40a7ec:	jb     40a7f7 <__swc_fn_6b1cf01f_000019_60e50998+0x157>
  40a7ee:	mov    rax,0xffffffffffffffff
  40a7f5:	jmp    40a807 <__swc_fn_6b1cf01f_000019_60e50998+0x167>
  40a7f7:	mov    eax,0x1
  40a7fc:	mov    ecx,DWORD PTR [r12+0x2c]
  40a801:	shl    rax,cl
  40a804:	dec    rax
  40a807:	mov    QWORD PTR [r12+0x20],rax
  40a80c:	mov    DWORD PTR [r12],0x4e540001
  40a814:	mov    DWORD PTR [r12+0x4],0x53474d45
  40a81d:	add    QWORD PTR [rdi+0x10],0x400000
  40a825:	mov    rax,r12
  40a828:	pop    r12
  40a82a:	pop    rdi
  40a82b:	pop    rsi
  40a82c:	ret
  40a82d:	add    BYTE PTR [rax],al
	...

000000000040a830 <__swc_fn_6b1cf01f_000022_77c2d682>:
  40a830:	mov    eax,0x1
  40a835:	mov    edx,DWORD PTR [rip+0x1982d]        # 424068 <__swc_bss_base_6b1cf01f+0x28>
  40a83b:	cmp    eax,edx
  40a83d:	jae    40a88b <__swc_fn_6b1cf01f_000022_77c2d682+0x5b>
  40a83f:	nop
  40a840:	lea    r8,[rip+0x19829]        # 424070 <__swc_bss_base_6b1cf01f+0x30>
  40a847:	lea    r9,[rax+rax*2]
  40a84b:	lea    r9,[r8+r9*8]
  40a84f:	mov    r8,rcx
  40a852:	sub    r8,QWORD PTR [r9+0x8]
  40a856:	mov    r9,QWORD PTR [r9+0x10]
  40a85a:	cmp    r8,r9
  40a85d:	jae    40a885 <__swc_fn_6b1cf01f_000022_77c2d682+0x55>
  40a85f:	mov    rax,rcx
  40a862:	and    rax,0xffffffffffc00000
  40a869:	shr    rcx,0x10
  40a86d:	and    ecx,0x3f
  40a870:	mov    edx,DWORD PTR [rax+0x28]
  40a873:	shrx   ecx,ecx,edx
  40a878:	shl    rcx,0x4
  40a87c:	lea    rax,[rax+rcx*8+0x80]
  40a884:	ret
  40a885:	inc    eax
  40a887:	cmp    eax,edx
  40a889:	jb     40a840 <__swc_fn_6b1cf01f_000022_77c2d682+0x10>
  40a88b:	xor    eax,eax
  40a88d:	ret
	...

000000000040a890 <__swc_fn_6b1cf01f_000025_7e9350e1>:
  40a890:	vxorps xmm0,xmm0,xmm0
  40a894:	vmovups XMMWORD PTR [rcx],xmm0
  40a898:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a89d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a8a2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a8a7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40a8ac:	mov    QWORD PTR [rcx+0x50],0x0
  40a8b4:	ret
	...

000000000040a8c0 <__swc_fn_6b1cf01f_000028_7e9350e1>:
  40a8c0:	vxorps xmm0,xmm0,xmm0
  40a8c4:	xor    eax,eax
  40a8c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a8d0:	cs nop WORD PTR [rax+rax*1+0x0]
  40a8da:	nop    WORD PTR [rax+rax*1+0x0]
  40a8e0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a8e5:	add    rax,0x10
  40a8e9:	cmp    rax,0x9b0
  40a8f0:	jne    40a8e0 <__swc_fn_6b1cf01f_000028_7e9350e1+0x20>
  40a8f2:	mov    QWORD PTR [rcx+0x9b0],0x0
  40a8fd:	ret
	...

000000000040a900 <__swc_fn_6b1cf01f_000031_ed8d61a9>:
  40a900:	push   rsi
  40a901:	push   rdi
  40a902:	sub    rsp,0x8
  40a906:	lea    rsi,[rip+0x176fb]        # 422008 <__swc_data_base_6b1cf01f+0x8>
  40a90d:	mov    rax,QWORD PTR [rsi]
  40a910:	mov    ecx,0xffffffff
  40a915:	cmp    rax,rcx
  40a918:	je     40a921 <__swc_fn_6b1cf01f_000031_ed8d61a9+0x21>
  40a91a:	add    rsp,0x8
  40a91e:	pop    rdi
  40a91f:	pop    rsi
  40a920:	ret
  40a921:	mov    rcx,QWORD PTR [rip+0x8750]        # 413078 <__swc_fn_6b1cf01f_000176_0ce64436+0x1858>
  40a928:	call   409650 <__swc_fn_6b1cf01f_000126_5fb20c72>
  40a92d:	mov    rcx,rax
  40a930:	mov    eax,0xffffffff
  40a935:	lock cmpxchg QWORD PTR [rsi],rcx
  40a93a:	mov    rdi,rax
  40a93d:	mov    eax,0xffffffff
  40a942:	cmp    rdi,rax
  40a945:	je     40a956 <__swc_fn_6b1cf01f_000031_ed8d61a9+0x56>
  40a947:	call   40cb30 <__swc_fn_6b1cf01f_000127_75f8ab5c>
  40a94c:	mov    rax,rdi
  40a94f:	add    rsp,0x8
  40a953:	pop    rdi
  40a954:	pop    rsi
  40a955:	ret
  40a956:	mov    rax,rcx
  40a959:	add    rsp,0x8
  40a95d:	pop    rdi
  40a95e:	pop    rsi
  40a95f:	ret

000000000040a960 <__swc_fn_6b1cf01f_000034_c72914a2>:
  40a960:	sub    rsp,0x8
  40a964:	vxorps xmm0,xmm0,xmm0
  40a968:	xor    eax,eax
  40a96a:	cs nop WORD PTR [rax+rax*1+0x0]
  40a974:	cs nop WORD PTR [rax+rax*1+0x0]
  40a97e:	xchg   ax,ax
  40a980:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a985:	add    rax,0x10
  40a989:	cmp    rax,0x2b00
  40a990:	jne    40a980 <__swc_fn_6b1cf01f_000034_c72914a2+0x20>
  40a992:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40a99c:	xor    al,al
  40a99e:	mov    rdx,rax
  40a9a1:	xor    al,al
  40a9a3:	mov    r8,rax
  40a9a6:	xor    al,al
  40a9a8:	mov    r9,rax
  40a9ab:	xor    al,al
  40a9ad:	mov    r10,rax
  40a9b0:	xor    al,al
  40a9b2:	mov    r11,rax
  40a9b5:	call   40dab0 <__swc_fn_6b1cf01f_000035_6105596e>
  40a9ba:	add    rsp,0x8
  40a9be:	ret
	...

000000000040a9c0 <__swc_fn_6b1cf01f_000037_92e867c2>:
  40a9c0:	push   rsi
  40a9c1:	push   rdi
  40a9c2:	push   r12
  40a9c4:	mov    rsi,r8
  40a9c7:	mov    rdi,rdx
  40a9ca:	mov    rcx,rdx
  40a9cd:	call   40d640 <__swc_fn_6b1cf01f_000002_390d5093>
  40a9d2:	mov    r12,rax
  40a9d5:	test   rax,rax
  40a9d8:	jne    40a9e1 <__swc_fn_6b1cf01f_000037_92e867c2+0x21>
  40a9da:	xor    eax,eax
  40a9dc:	pop    r12
  40a9de:	pop    rdi
  40a9df:	pop    rsi
  40a9e0:	ret
  40a9e1:	mov    rcx,r12
  40a9e4:	mov    rdx,rsi
  40a9e7:	call   4072a0 <__swc_fn_6b1cf01f_000003_644dadb7>
  40a9ec:	test   al,al
  40a9ee:	jne    40aa02 <__swc_fn_6b1cf01f_000037_92e867c2+0x42>
  40a9f0:	mov    rcx,r12
  40a9f3:	mov    rdx,rdi
  40a9f6:	call   40f8b0 <__swc_fn_6b1cf01f_000113_25e345b1>
  40a9fb:	xor    eax,eax
  40a9fd:	pop    r12
  40a9ff:	pop    rdi
  40aa00:	pop    rsi
  40aa01:	ret
  40aa02:	mov    rax,r12
  40aa05:	pop    r12
  40aa07:	pop    rdi
  40aa08:	pop    rsi
  40aa09:	ret
	...

000000000040aa20 <__swc_fn_6b1cf01f_000040_7a225310>:
  40aa20:	push   rsi
  40aa21:	push   rdi
  40aa22:	push   r12
  40aa24:	mov    rsi,rcx
  40aa27:	mov    edx,0x9b8
  40aa2c:	call   40db20 <__swc_fn_6b1cf01f_000038_c7591393>
  40aa31:	mov    rdi,rax
  40aa34:	test   rax,rax
  40aa37:	jne    40aa40 <__swc_fn_6b1cf01f_000040_7a225310+0x20>
  40aa39:	xor    eax,eax
  40aa3b:	pop    r12
  40aa3d:	pop    rdi
  40aa3e:	pop    rsi
  40aa3f:	ret
  40aa40:	vxorps xmm0,xmm0,xmm0
  40aa44:	xor    eax,eax
  40aa46:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa50:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa5a:	nop    WORD PTR [rax+rax*1+0x0]
  40aa60:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40aa65:	add    rax,0x10
  40aa69:	cmp    rax,0x9b0
  40aa70:	jne    40aa60 <__swc_fn_6b1cf01f_000040_7a225310+0x40>
  40aa72:	mov    QWORD PTR [rdi+0x9b0],0x0
  40aa7d:	mov    QWORD PTR [rdi],rsi
  40aa80:	call   40cbe0 <__swc_fn_6b1cf01f_000130_d2d78689>
  40aa85:	mov    QWORD PTR [rdi+0x18],rax
  40aa89:	lea    r12,[rsi+0x10]
  40aa8d:	mov    rcx,r12
  40aa90:	call   4098a0 <__swc_fn_6b1cf01f_000135_1fec60ac>
  40aa95:	mov    rax,QWORD PTR [rsi+0x20]
  40aa99:	mov    QWORD PTR [rdi+0x8],rax
  40aa9d:	mov    rax,QWORD PTR [rsi+0x20]
  40aaa1:	test   rax,rax
  40aaa4:	je     40aaaa <__swc_fn_6b1cf01f_000040_7a225310+0x8a>
  40aaa6:	mov    QWORD PTR [rax+0x10],rdi
  40aaaa:	mov    QWORD PTR [rsi+0x20],rdi
  40aaae:	mov    rcx,r12
  40aab1:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  40aab6:	mov    rax,rdi
  40aab9:	pop    r12
  40aabb:	pop    rdi
  40aabc:	pop    rsi
  40aabd:	ret
	...

000000000040aac0 <__swc_fn_6b1cf01f_000043_3755033a>:
  40aac0:	mov    rax,QWORD PTR [rdx+0x10]
  40aac4:	test   rax,rax
  40aac7:	je     40aad3 <__swc_fn_6b1cf01f_000043_3755033a+0x13>
  40aac9:	mov    rcx,QWORD PTR [rdx+0x8]
  40aacd:	mov    QWORD PTR [rax+0x8],rcx
  40aad1:	jmp    40aadb <__swc_fn_6b1cf01f_000043_3755033a+0x1b>
  40aad3:	mov    rax,QWORD PTR [rdx+0x8]
  40aad7:	mov    QWORD PTR [rcx+0x20],rax
  40aadb:	mov    rax,QWORD PTR [rdx+0x8]
  40aadf:	test   rax,rax
  40aae2:	je     40aaec <__swc_fn_6b1cf01f_000043_3755033a+0x2c>
  40aae4:	mov    rcx,QWORD PTR [rdx+0x10]
  40aae8:	mov    QWORD PTR [rax+0x10],rcx
  40aaec:	vxorps xmm0,xmm0,xmm0
  40aaf0:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40aaf5:	ret
	...

000000000040ab00 <__swc_fn_6b1cf01f_000046_49300800>:
  40ab00:	sub    rsp,0x8
  40ab04:	mov    r9,r8
  40ab07:	mov    r10,rdx
  40ab0a:	call   40dbd0 <__swc_fn_6b1cf01f_000044_cac7f504>
  40ab0f:	mov    eax,0x1
  40ab14:	xchg   DWORD PTR [r9+0x6c],eax
  40ab18:	mov    rax,QWORD PTR [r9+0x60]
  40ab1c:	test   rax,rax
  40ab1f:	je     40ab63 <__swc_fn_6b1cf01f_000046_49300800+0x63>
  40ab21:	xor    eax,eax
  40ab23:	xchg   DWORD PTR [r9+0x6c],eax
  40ab27:	movzx  eax,BYTE PTR [r9+0x39]
  40ab2c:	lea    rax,[rax+rax*4]
  40ab30:	lea    rax,[r10+rax*8+0x28]
  40ab35:	mov    QWORD PTR [r9+0x50],0x0
  40ab3d:	mov    rcx,QWORD PTR [rax+0x8]
  40ab41:	mov    QWORD PTR [r9+0x48],rcx
  40ab45:	mov    rcx,QWORD PTR [rax+0x8]
  40ab49:	test   rcx,rcx
  40ab4c:	je     40ab54 <__swc_fn_6b1cf01f_000046_49300800+0x54>
  40ab4e:	mov    QWORD PTR [rcx+0x50],r9
  40ab52:	jmp    40ab58 <__swc_fn_6b1cf01f_000046_49300800+0x58>
  40ab54:	mov    QWORD PTR [rax+0x10],r9
  40ab58:	mov    QWORD PTR [rax+0x8],r9
  40ab5c:	xor    eax,eax
  40ab5e:	add    rsp,0x8
  40ab62:	ret
  40ab63:	movzx  eax,BYTE PTR [r9+0x39]
  40ab68:	lea    rax,[rax+rax*4]
  40ab6c:	lea    rax,[r10+rax*8+0x28]
  40ab71:	mov    QWORD PTR [r9+0x50],0x0
  40ab79:	mov    rcx,QWORD PTR [rax+0x18]
  40ab7d:	mov    QWORD PTR [r9+0x48],rcx
  40ab81:	mov    rcx,QWORD PTR [rax+0x18]
  40ab85:	test   rcx,rcx
  40ab88:	je     40ab8e <__swc_fn_6b1cf01f_000046_49300800+0x8e>
  40ab8a:	mov    QWORD PTR [rcx+0x50],r9
  40ab8e:	mov    QWORD PTR [rax+0x18],r9
  40ab92:	mov    eax,0x1
  40ab97:	add    rsp,0x8
  40ab9b:	ret
  40ab9c:	add    BYTE PTR [rax],al
	...

000000000040aba0 <__swc_fn_6b1cf01f_000049_781177b4>:
  40aba0:	push   r12
  40aba2:	push   r13
  40aba4:	push   rdi
  40aba5:	push   rsi
  40aba6:	push   r14
  40aba8:	push   r15
  40abaa:	sub    rsp,0x178
  40abb1:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40abba:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40abc3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40abcc:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40abd5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40abde:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40abe7:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40abf0:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40abf9:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40ac02:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40ac0b:	mov    r12,rcx
  40ac0e:	lea    rax,[rip+0x195eb]        # 424200 <__swc_bss_base_6b1cf01f+0x1c0>
  40ac15:	mov    rcx,QWORD PTR [rax]
  40ac18:	mov    r13,rcx
  40ac1b:	test   rcx,rcx
  40ac1e:	jne    40ac2e <__swc_fn_6b1cf01f_000049_781177b4+0x8e>
  40ac20:	mov    r13d,0x1dcd6500
  40ac26:	mov    ecx,0x1dcd6500
  40ac2b:	xchg   QWORD PTR [rax],rcx
  40ac2e:	lea    rax,[rip+0x173cb]        # 422000 <__swc_data_base_6b1cf01f>
  40ac35:	mov    rax,QWORD PTR [rax]
  40ac38:	cmp    rax,0xffffffffffffffff
  40ac3c:	je     40ac4b <__swc_fn_6b1cf01f_000049_781177b4+0xab>
  40ac3e:	mov    eax,eax
  40ac40:	mov    edi,eax
  40ac42:	xor    eax,eax
  40ac44:	call   407000 <pthread_getspecific@plt>
  40ac49:	jmp    40ac4d <__swc_fn_6b1cf01f_000049_781177b4+0xad>
  40ac4b:	xor    eax,eax
  40ac4d:	test   rax,rax
  40ac50:	jne    40ac5f <__swc_fn_6b1cf01f_000049_781177b4+0xbf>
  40ac52:	call   40a900 <__swc_fn_6b1cf01f_000031_ed8d61a9>
  40ac57:	mov    rcx,rax
  40ac5a:	call   40fc00 <__swc_fn_6b1cf01f_000128_9c45d2d7>
  40ac5f:	test   rax,rax
  40ac62:	je     40ac74 <__swc_fn_6b1cf01f_000049_781177b4+0xd4>
  40ac64:	cmp    QWORD PTR [rax],r12
  40ac67:	jne    40ac74 <__swc_fn_6b1cf01f_000049_781177b4+0xd4>
  40ac69:	cmp    DWORD PTR [rax+0x20],0x0
  40ac6d:	jne    40ac74 <__swc_fn_6b1cf01f_000049_781177b4+0xd4>
  40ac6f:	mov    rsi,rax
  40ac72:	jmp    40ac76 <__swc_fn_6b1cf01f_000049_781177b4+0xd6>
  40ac74:	xor    esi,esi
  40ac76:	lea    rdi,[r12+0x2a88]
  40ac7e:	mov    r14,QWORD PTR [rdi]
  40ac81:	test   r14,r14
  40ac84:	jne    40acd3 <__swc_fn_6b1cf01f_000049_781177b4+0x133>
  40ac86:	lea    rax,[rip+0x193cb]        # 424058 <__swc_bss_base_6b1cf01f+0x18>
  40ac8d:	mov    rax,QWORD PTR [rax]
  40ac90:	test   rax,rax
  40ac93:	setne  al
  40ac96:	jne    40acba <__swc_fn_6b1cf01f_000049_781177b4+0x11a>
  40ac98:	mov    rax,QWORD PTR [r12+0x2a70]
  40aca0:	test   rax,rax
  40aca3:	setne  al
  40aca6:	jne    40acba <__swc_fn_6b1cf01f_000049_781177b4+0x11a>
  40aca8:	test   rsi,rsi
  40acab:	setne  al
  40acae:	je     40acba <__swc_fn_6b1cf01f_000049_781177b4+0x11a>
  40acb0:	cmp    DWORD PTR [rsi+0x730],0x0
  40acb7:	setne  al
  40acba:	test   al,al
  40acbc:	je     40acce <__swc_fn_6b1cf01f_000049_781177b4+0x12e>
  40acbe:	call   40fcb0 <__swc_fn_6b1cf01f_000131_dc04d759>
  40acc3:	lea    rcx,[rax+r13*1]
  40acc7:	xor    eax,eax
  40acc9:	lock cmpxchg QWORD PTR [rdi],rcx
  40acce:	jmp    40add3 <__swc_fn_6b1cf01f_000049_781177b4+0x233>
  40acd3:	call   40fcb0 <__swc_fn_6b1cf01f_000131_dc04d759>
  40acd8:	mov    r15,rax
  40acdb:	cmp    rax,r14
  40acde:	jb     40acef <__swc_fn_6b1cf01f_000049_781177b4+0x14f>
  40ace0:	xor    ecx,ecx
  40ace2:	mov    rax,r14
  40ace5:	lock cmpxchg QWORD PTR [rdi],rcx
  40acea:	cmp    rax,r14
  40aced:	je     40acf4 <__swc_fn_6b1cf01f_000049_781177b4+0x154>
  40acef:	jmp    40add3 <__swc_fn_6b1cf01f_000049_781177b4+0x233>
  40acf4:	test   rsi,rsi
  40acf7:	je     40ad12 <__swc_fn_6b1cf01f_000049_781177b4+0x172>
  40acf9:	cmp    r15,r13
  40acfc:	jb     40ad12 <__swc_fn_6b1cf01f_000049_781177b4+0x172>
  40acfe:	mov    rax,r15
  40ad01:	sub    rax,r13
  40ad04:	mov    rcx,r12
  40ad07:	mov    rdx,rsi
  40ad0a:	mov    r8,rax
  40ad0d:	call   40e010 <__swc_fn_6b1cf01f_000059_c8e1ff6b>
  40ad12:	lea    rsi,[r12+0x10]
  40ad17:	mov    rcx,rsi
  40ad1a:	call   4098a0 <__swc_fn_6b1cf01f_000135_1fec60ac>
  40ad1f:	mov    rax,QWORD PTR [r12+0x18]
  40ad24:	mov    rdi,rax
  40ad27:	test   rdi,rdi
  40ad2a:	je     40ad54 <__swc_fn_6b1cf01f_000049_781177b4+0x1b4>
  40ad2c:	cs nop WORD PTR [rax+rax*1+0x0]
  40ad36:	cs nop WORD PTR [rax+rax*1+0x0]
  40ad40:	mov    rcx,rdi
  40ad43:	call   407470 <__swc_fn_6b1cf01f_000015_aa8c841a>
  40ad48:	mov    rax,QWORD PTR [rdi+0x10]
  40ad4c:	mov    rdi,rax
  40ad4f:	test   rax,rax
  40ad52:	jne    40ad40 <__swc_fn_6b1cf01f_000049_781177b4+0x1a0>
  40ad54:	mov    rcx,rsi
  40ad57:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  40ad5c:	mov    rcx,r12
  40ad5f:	call   4098a0 <__swc_fn_6b1cf01f_000135_1fec60ac>
  40ad64:	xor    esi,esi
  40ad66:	cs nop WORD PTR [rax+rax*1+0x0]
  40ad70:	mov    rax,QWORD PTR [r12+0x2a70]
  40ad78:	cmp    rsi,rax
  40ad7b:	jae    40adcb <__swc_fn_6b1cf01f_000049_781177b4+0x22b>
  40ad7d:	lea    rax,[rsi+rsi*4]
  40ad81:	lea    rax,[r12+rax*8+0x268]
  40ad89:	mov    r8,QWORD PTR [rax]
  40ad8c:	mov    r9,QWORD PTR [rax+0x8]
  40ad90:	mov    r10,QWORD PTR [rax+0x10]
  40ad94:	mov    rax,QWORD PTR [rax+0x20]
  40ad98:	cmp    rax,r15
  40ad9b:	jae    40ada8 <__swc_fn_6b1cf01f_000049_781177b4+0x208>
  40ad9d:	mov    rcx,r15
  40ada0:	sub    rcx,rax
  40ada3:	cmp    rcx,r13
  40ada6:	jae    40adad <__swc_fn_6b1cf01f_000049_781177b4+0x20d>
  40ada8:	inc    rsi
  40adab:	jmp    40ad70 <__swc_fn_6b1cf01f_000049_781177b4+0x1d0>
  40adad:	mov    rcx,r12
  40adb0:	mov    rdx,rsi
  40adb3:	call   40dfc0 <__swc_fn_6b1cf01f_000056_cfedf3f4>
  40adb8:	mov    rcx,r12
  40adbb:	mov    rdx,r8
  40adbe:	mov    r8,r9
  40adc1:	mov    r9,r10
  40adc4:	call   407750 <__swc_fn_6b1cf01f_000039_05a50673>
  40adc9:	jmp    40ad70 <__swc_fn_6b1cf01f_000049_781177b4+0x1d0>
  40adcb:	mov    rcx,r12
  40adce:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  40add3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40addc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40ade5:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40adee:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40adf7:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40ae00:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40ae09:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40ae12:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40ae1b:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40ae24:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40ae2d:	add    rsp,0x178
  40ae34:	pop    r15
  40ae36:	pop    r14
  40ae38:	pop    rsi
  40ae39:	pop    rdi
  40ae3a:	pop    r13
  40ae3c:	pop    r12
  40ae3e:	ret
	...

000000000040ae40 <__swc_fn_6b1cf01f_000052_26c6c1c4>:
  40ae40:	lea    rax,[rdx-0x58]
  40ae44:	ret
	...

000000000040ae50 <__swc_fn_6b1cf01f_000055_da36318f>:
  40ae50:	push   rsi
  40ae51:	push   rdi
  40ae52:	push   r12
  40ae54:	push   r13
  40ae56:	sub    rsp,0x68
  40ae5a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40ae60:	mov    rsi,r9
  40ae63:	mov    rdi,rcx
  40ae66:	mov    r12,rdx
  40ae69:	mov    r13,r8
  40ae6c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40ae74:	jne    40ae83 <__swc_fn_6b1cf01f_000055_da36318f+0x33>
  40ae76:	xor    eax,eax
  40ae78:	add    rsp,0x68
  40ae7c:	pop    r13
  40ae7e:	pop    r12
  40ae80:	pop    rdi
  40ae81:	pop    rsi
  40ae82:	ret
  40ae83:	mov    rcx,rdi
  40ae86:	call   4098a0 <__swc_fn_6b1cf01f_000135_1fec60ac>
  40ae8b:	movabs rax,0x7fffffffffffffff
  40ae95:	cmp    r12,rax
  40ae98:	mov    rax,0xffffffffffffffff
  40ae9f:	lea    rcx,[r12+r12*1]
  40aea3:	cmovbe rax,rcx
  40aea7:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40aeae:	mov    rdx,rcx
  40aeb1:	sub    rax,r12
  40aeb4:	inc    rax
  40aeb7:	xor    r8d,r8d
  40aeba:	test   rcx,rcx
  40aebd:	jbe    40aee8 <__swc_fn_6b1cf01f_000055_da36318f+0x98>
  40aebf:	nop
  40aec0:	lea    r9,[r8+r8*4]
  40aec4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40aecc:	sub    r9,r12
  40aecf:	cmp    r9,rax
  40aed2:	jae    40aedf <__swc_fn_6b1cf01f_000055_da36318f+0x8f>
  40aed4:	mov    rdx,r8
  40aed7:	mov    rax,r9
  40aeda:	test   r9,r9
  40aedd:	je     40aee8 <__swc_fn_6b1cf01f_000055_da36318f+0x98>
  40aedf:	add    r8,0x1
  40aee3:	cmp    r8,rcx
  40aee6:	jb     40aec0 <__swc_fn_6b1cf01f_000055_da36318f+0x70>
  40aee8:	mov    rax,QWORD PTR [rdi+0x2a70]
  40aeef:	cmp    rdx,rax
  40aef2:	jne    40af0f <__swc_fn_6b1cf01f_000055_da36318f+0xbf>
  40aef4:	mov    rcx,rdi
  40aef7:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  40aefc:	xor    eax,eax
  40aefe:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40af04:	add    rsp,0x68
  40af08:	pop    r13
  40af0a:	pop    r12
  40af0c:	pop    rdi
  40af0d:	pop    rsi
  40af0e:	ret
  40af0f:	lea    rax,[rdx+rdx*4]
  40af13:	lea    rax,[rdi+rax*8+0x268]
  40af1b:	vmovups xmm6,XMMWORD PTR [rax]
  40af1f:	mov    r8,QWORD PTR [rax+0x10]
  40af23:	mov    rcx,rdi
  40af26:	call   40dfc0 <__swc_fn_6b1cf01f_000056_cfedf3f4>
  40af2b:	vpshufd xmm0,xmm6,0xee
  40af30:	vmovsd QWORD PTR [r13+0x0],xmm0
  40af36:	mov    QWORD PTR [rsi],r8
  40af39:	mov    rcx,rdi
  40af3c:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  40af41:	vmovq  rax,xmm6
  40af46:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40af4c:	add    rsp,0x68
  40af50:	pop    r13
  40af52:	pop    r12
  40af54:	pop    rdi
  40af55:	pop    rsi
  40af56:	ret
	...

000000000040af60 <__swc_fn_6b1cf01f_000058_033ce1da>:
  40af60:	push   r12
  40af62:	push   r13
  40af64:	push   r14
  40af66:	push   r15
  40af68:	push   rdi
  40af69:	push   rsi
  40af6a:	sub    rsp,0x148
  40af71:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40af7a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40af83:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40af8c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40af95:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40af9e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40afa7:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40afb0:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40afb9:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40afc2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40afcb:	mov    r12,r9
  40afce:	mov    r13,rcx
  40afd1:	mov    r14,rdx
  40afd4:	mov    r15,r8
  40afd7:	test   rdx,rdx
  40afda:	jne    40afee <__swc_fn_6b1cf01f_000058_033ce1da+0x8e>
  40afdc:	add    rsp,0x148
  40afe3:	pop    rsi
  40afe4:	pop    rdi
  40afe5:	pop    r15
  40afe7:	pop    r14
  40afe9:	pop    r13
  40afeb:	pop    r12
  40afed:	ret
  40afee:	cmp    r12,0x200000
  40aff5:	ja     40b087 <__swc_fn_6b1cf01f_000058_033ce1da+0x127>
  40affb:	lea    rax,[rip+0x16ffe]        # 422000 <__swc_data_base_6b1cf01f>
  40b002:	mov    rax,QWORD PTR [rax]
  40b005:	cmp    rax,0xffffffffffffffff
  40b009:	je     40b018 <__swc_fn_6b1cf01f_000058_033ce1da+0xb8>
  40b00b:	mov    eax,eax
  40b00d:	mov    edi,eax
  40b00f:	xor    eax,eax
  40b011:	call   407000 <pthread_getspecific@plt>
  40b016:	jmp    40b01a <__swc_fn_6b1cf01f_000058_033ce1da+0xba>
  40b018:	xor    eax,eax
  40b01a:	test   rax,rax
  40b01d:	je     40b024 <__swc_fn_6b1cf01f_000058_033ce1da+0xc4>
  40b01f:	mov    rsi,rax
  40b022:	jmp    40b034 <__swc_fn_6b1cf01f_000058_033ce1da+0xd4>
  40b024:	call   40a900 <__swc_fn_6b1cf01f_000031_ed8d61a9>
  40b029:	mov    rcx,rax
  40b02c:	call   40fc00 <__swc_fn_6b1cf01f_000128_9c45d2d7>
  40b031:	mov    rsi,rax
  40b034:	test   rsi,rsi
  40b037:	je     40b087 <__swc_fn_6b1cf01f_000058_033ce1da+0x127>
  40b039:	cmp    QWORD PTR [rsi],r13
  40b03c:	jne    40b087 <__swc_fn_6b1cf01f_000058_033ce1da+0x127>
  40b03e:	cmp    DWORD PTR [rsi+0x20],0x0
  40b042:	jne    40b087 <__swc_fn_6b1cf01f_000058_033ce1da+0x127>
  40b044:	cmp    DWORD PTR [rsi+0x730],0x10
  40b04b:	jae    40b087 <__swc_fn_6b1cf01f_000058_033ce1da+0x127>
  40b04d:	mov    eax,DWORD PTR [rsi+0x730]
  40b053:	lea    rdi,[rax+rax*4]
  40b057:	lea    rdi,[rsi+rdi*8+0x738]
  40b05f:	mov    QWORD PTR [rdi],r14
  40b062:	mov    QWORD PTR [rdi+0x8],r15
  40b066:	mov    QWORD PTR [rdi+0x10],r12
  40b06a:	mov    QWORD PTR [rdi+0x18],0x0
  40b072:	call   40fcb0 <__swc_fn_6b1cf01f_000131_dc04d759>
  40b077:	mov    QWORD PTR [rdi+0x20],rax
  40b07b:	add    DWORD PTR [rsi+0x730],0x1
  40b082:	jmp    40b1e6 <__swc_fn_6b1cf01f_000058_033ce1da+0x286>
  40b087:	mov    rcx,r13
  40b08a:	call   407e90 <__swc_fn_6b1cf01f_000057_8be0372b>
  40b08f:	mov    rsi,rax
  40b092:	cmp    r12,rax
  40b095:	jbe    40b0ca <__swc_fn_6b1cf01f_000058_033ce1da+0x16a>
  40b097:	cmp    r12,0x10000000
  40b09e:	seta   al
  40b0a1:	ja     40b0b0 <__swc_fn_6b1cf01f_000058_033ce1da+0x150>
  40b0a3:	mov    rax,QWORD PTR [r13+0x2a70]
  40b0aa:	test   rax,rax
  40b0ad:	setne  al
  40b0b0:	test   al,al
  40b0b2:	je     40b0ca <__swc_fn_6b1cf01f_000058_033ce1da+0x16a>
  40b0b4:	mov    rcx,r13
  40b0b7:	mov    rdx,r14
  40b0ba:	mov    r8,r15
  40b0bd:	mov    r9,r12
  40b0c0:	call   407750 <__swc_fn_6b1cf01f_000039_05a50673>
  40b0c5:	jmp    40b1e6 <__swc_fn_6b1cf01f_000058_033ce1da+0x286>
  40b0ca:	call   40fcb0 <__swc_fn_6b1cf01f_000131_dc04d759>
  40b0cf:	mov    rdi,rax
  40b0d2:	mov    rcx,r13
  40b0d5:	call   4098a0 <__swc_fn_6b1cf01f_000135_1fec60ac>
  40b0da:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b0e2:	je     40b19a <__swc_fn_6b1cf01f_000058_033ce1da+0x23a>
  40b0e8:	nop    DWORD PTR [rax+rax*1+0x0]
  40b0f0:	cmp    QWORD PTR [r13+0x2a70],0x100
  40b0fb:	jae    40b110 <__swc_fn_6b1cf01f_000058_033ce1da+0x1b0>
  40b0fd:	mov    rax,QWORD PTR [r13+0x2a68]
  40b104:	add    rax,r12
  40b107:	cmp    rax,rsi
  40b10a:	jbe    40b19a <__swc_fn_6b1cf01f_000058_033ce1da+0x23a>
  40b110:	xor    eax,eax
  40b112:	mov    rcx,QWORD PTR [r13+0x2a70]
  40b119:	mov    edx,0x1
  40b11e:	cmp    rcx,0x1
  40b122:	jbe    40b159 <__swc_fn_6b1cf01f_000058_033ce1da+0x1f9>
  40b124:	cs nop WORD PTR [rax+rax*1+0x0]
  40b12e:	xchg   ax,ax
  40b130:	lea    r8,[rdx+rdx*4]
  40b134:	lea    r8,[r13+r8*8+0x268]
  40b13c:	lea    r9,[rax+rax*4]
  40b140:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40b148:	cmp    QWORD PTR [r8+0x18],r9
  40b14c:	cmovb  rax,rdx
  40b150:	add    rdx,0x1
  40b154:	cmp    rdx,rcx
  40b157:	jb     40b130 <__swc_fn_6b1cf01f_000058_033ce1da+0x1d0>
  40b159:	lea    rcx,[rax+rax*4]
  40b15d:	lea    rcx,[r13+rcx*8+0x268]
  40b165:	mov    r8,QWORD PTR [rcx]
  40b168:	mov    r9,QWORD PTR [rcx+0x8]
  40b16c:	mov    r10,QWORD PTR [rcx+0x10]
  40b170:	mov    rcx,r13
  40b173:	mov    rdx,rax
  40b176:	call   40dfc0 <__swc_fn_6b1cf01f_000056_cfedf3f4>
  40b17b:	mov    rcx,r13
  40b17e:	mov    rdx,r8
  40b181:	mov    r8,r9
  40b184:	mov    r9,r10
  40b187:	call   407750 <__swc_fn_6b1cf01f_000039_05a50673>
  40b18c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b194:	jne    40b0f0 <__swc_fn_6b1cf01f_000058_033ce1da+0x190>
  40b19a:	add    QWORD PTR [r13+0x2a78],0x1
  40b1a2:	mov    rax,QWORD PTR [r13+0x2a70]
  40b1a9:	lea    rax,[rax+rax*4]
  40b1ad:	lea    rax,[r13+rax*8+0x268]
  40b1b5:	mov    QWORD PTR [rax],r14
  40b1b8:	mov    QWORD PTR [rax+0x8],r15
  40b1bc:	mov    QWORD PTR [rax+0x10],r12
  40b1c0:	mov    rcx,QWORD PTR [r13+0x2a78]
  40b1c7:	mov    QWORD PTR [rax+0x18],rcx
  40b1cb:	mov    QWORD PTR [rax+0x20],rdi
  40b1cf:	add    QWORD PTR [r13+0x2a68],r12
  40b1d6:	add    QWORD PTR [r13+0x2a70],0x1
  40b1de:	mov    rcx,r13
  40b1e1:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  40b1e6:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40b1ef:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40b1f8:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40b201:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40b20a:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40b213:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40b21c:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40b225:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40b22e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40b237:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40b240:	add    rsp,0x148
  40b247:	pop    rsi
  40b248:	pop    rdi
  40b249:	pop    r15
  40b24b:	pop    r14
  40b24d:	pop    r13
  40b24f:	pop    r12
  40b251:	ret
	...

000000000040b260 <__swc_fn_6b1cf01f_000061_1badc238>:
  40b260:	push   rbx
  40b261:	push   r12
  40b263:	push   r13
  40b265:	push   r14
  40b267:	push   r15
  40b269:	push   rdi
  40b26a:	push   rsi
  40b26b:	sub    rsp,0xf0
  40b272:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40b278:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40b27e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40b284:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40b28a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40b293:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40b29c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40b2a5:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40b2ae:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40b2b7:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40b2c0:	mov    eax,r8d
  40b2c3:	mov    rbx,rcx
  40b2c6:	mov    r12,rdx
  40b2c9:	mov    QWORD PTR [rsp+0x18],rdx
  40b2ce:	mov    ecx,DWORD PTR [r12+0x58]
  40b2d3:	mov    r13d,ecx
  40b2d6:	cmp    ecx,0x10
  40b2d9:	mov    ecx,0x10
  40b2de:	cmovb  r13d,ecx
  40b2e2:	test   r13d,r13d
  40b2e5:	mov    rcx,r13
  40b2e8:	mov    edx,0x8
  40b2ed:	cmove  ecx,edx
  40b2f0:	dec    rcx
  40b2f3:	mov    rdx,0xffffffffffffffff
  40b2fa:	sub    rdx,rcx
  40b2fd:	xor    r14d,r14d
  40b300:	mov    r8,rcx
  40b303:	not    r8
  40b306:	lea    rcx,[rcx+0x58]
  40b30a:	and    rcx,r8
  40b30d:	cmp    rdx,0x58
  40b311:	cmovae r14,rcx
  40b315:	cmp    eax,0xffffffff
  40b318:	jne    40b321 <__swc_fn_6b1cf01f_000061_1badc238+0xc1>
  40b31a:	mov    r15,QWORD PTR [r12+0x48]
  40b31f:	jmp    40b353 <__swc_fn_6b1cf01f_000061_1badc238+0xf3>
  40b321:	test   eax,eax
  40b323:	jne    40b32c <__swc_fn_6b1cf01f_000061_1badc238+0xcc>
  40b325:	mov    eax,0x8
  40b32a:	jmp    40b350 <__swc_fn_6b1cf01f_000061_1badc238+0xf0>
  40b32c:	cmp    eax,0x8
  40b32f:	ja     40b337 <__swc_fn_6b1cf01f_000061_1badc238+0xd7>
  40b331:	shl    rax,0x4
  40b335:	jmp    40b350 <__swc_fn_6b1cf01f_000061_1badc238+0xf0>
  40b337:	lea    eax,[rax-0x9]
  40b33a:	mov    ecx,eax
  40b33c:	shr    ecx,0x2
  40b33f:	and    eax,0x3
  40b342:	lea    ecx,[rcx+0x7]
  40b345:	lea    ecx,[rcx-0x2]
  40b348:	lea    eax,[rax+0x5]
  40b34b:	shlx   rax,rax,rcx
  40b350:	mov    r15,rax
  40b353:	lea    rax,[r14+r13*1]
  40b357:	mov    rcx,0xffffffffffffffff
  40b35e:	sub    rcx,rax
  40b361:	cmp    r15,rcx
  40b364:	jbe    40b374 <__swc_fn_6b1cf01f_000061_1badc238+0x114>
  40b366:	mov    QWORD PTR [r12+0x40],0x0
  40b36f:	jmp    40b746 <__swc_fn_6b1cf01f_000061_1badc238+0x4e6>
  40b374:	mov    QWORD PTR [rsp+0x20],r13
  40b379:	lea    r13,[rsp+0x8]
  40b37e:	add    rax,r15
  40b381:	mov    ecx,0x1000
  40b386:	test   ecx,ecx
  40b388:	mov    edx,0x8
  40b38d:	cmove  ecx,edx
  40b390:	dec    rcx
  40b393:	mov    rdx,0xffffffffffffffff
  40b39a:	sub    rdx,rcx
  40b39d:	cmp    rax,rdx
  40b3a0:	jbe    40b3ac <__swc_fn_6b1cf01f_000061_1badc238+0x14c>
  40b3a2:	mov    QWORD PTR [r13+0x0],0x0
  40b3aa:	jmp    40b3b9 <__swc_fn_6b1cf01f_000061_1badc238+0x159>
  40b3ac:	add    rax,rcx
  40b3af:	andn   rax,rcx,rax
  40b3b4:	mov    QWORD PTR [rsp+0x8],rax
  40b3b9:	cmp    QWORD PTR [r13+0x0],0x0
  40b3be:	jne    40b3ce <__swc_fn_6b1cf01f_000061_1badc238+0x16e>
  40b3c0:	mov    QWORD PTR [r12+0x40],0x0
  40b3c9:	jmp    40b746 <__swc_fn_6b1cf01f_000061_1badc238+0x4e6>
  40b3ce:	mov    QWORD PTR [rsp+0x30],r15
  40b3d3:	xor    r15d,r15d
  40b3d6:	mov    QWORD PTR [rsp+0x38],0x0
  40b3df:	lea    r12,[rsp+0x10]
  40b3e4:	mov    QWORD PTR [rsp+0x28],r14
  40b3e9:	mov    r14,QWORD PTR [rsp+0x8]
  40b3ee:	mov    QWORD PTR [rsp+0x10],r14
  40b3f3:	cmp    r14,0x10000
  40b3fa:	ja     40b401 <__swc_fn_6b1cf01f_000061_1badc238+0x1a1>
  40b3fc:	mov    rax,r14
  40b3ff:	jmp    40b452 <__swc_fn_6b1cf01f_000061_1badc238+0x1f2>
  40b401:	xor    eax,eax
  40b403:	lea    rcx,[r14-0x1]
  40b407:	lzcnt  rax,rcx
  40b40c:	mov    ecx,0x3f
  40b411:	sub    rcx,rax
  40b414:	mov    eax,0x1
  40b419:	lea    rcx,[rcx-0x3]
  40b41d:	shl    rax,cl
  40b420:	mov    rcx,rax
  40b423:	cmp    rax,0x1000
  40b42a:	mov    eax,0x1000
  40b42f:	cmovb  rcx,rax
  40b433:	mov    rdx,0xffffffffffffffff
  40b43a:	sub    rdx,rcx
  40b43d:	mov    rax,r14
  40b440:	lea    r8,[r14+rcx*1-0x1]
  40b445:	neg    rcx
  40b448:	and    r8,rcx
  40b44b:	cmp    r14,rdx
  40b44e:	cmovbe rax,r8
  40b452:	mov    QWORD PTR [rsp+0x8],rax
  40b457:	lea    rax,[rip+0x16ba2]        # 422000 <__swc_data_base_6b1cf01f>
  40b45e:	mov    rax,QWORD PTR [rax]
  40b461:	cmp    rax,0xffffffffffffffff
  40b465:	je     40b474 <__swc_fn_6b1cf01f_000061_1badc238+0x214>
  40b467:	mov    eax,eax
  40b469:	mov    edi,eax
  40b46b:	xor    eax,eax
  40b46d:	call   407000 <pthread_getspecific@plt>
  40b472:	jmp    40b476 <__swc_fn_6b1cf01f_000061_1badc238+0x216>
  40b474:	xor    eax,eax
  40b476:	test   rax,rax
  40b479:	jne    40b488 <__swc_fn_6b1cf01f_000061_1badc238+0x228>
  40b47b:	call   40a900 <__swc_fn_6b1cf01f_000031_ed8d61a9>
  40b480:	mov    rcx,rax
  40b483:	call   40fc00 <__swc_fn_6b1cf01f_000128_9c45d2d7>
  40b488:	test   rax,rax
  40b48b:	je     40b57c <__swc_fn_6b1cf01f_000061_1badc238+0x31c>
  40b491:	cmp    QWORD PTR [rax],rbx
  40b494:	jne    40b57c <__swc_fn_6b1cf01f_000061_1badc238+0x31c>
  40b49a:	cmp    DWORD PTR [rax+0x20],0x0
  40b49e:	jne    40b57c <__swc_fn_6b1cf01f_000061_1badc238+0x31c>
  40b4a4:	mov    rcx,QWORD PTR [rsp+0x8]
  40b4a9:	movabs rdx,0x7fffffffffffffff
  40b4b3:	cmp    rcx,rdx
  40b4b6:	mov    rdx,0xffffffffffffffff
  40b4bd:	lea    r8,[rcx+rcx*1]
  40b4c1:	cmovbe rdx,r8
  40b4c5:	mov    r8d,DWORD PTR [rax+0x730]
  40b4cc:	mov    r9d,r8d
  40b4cf:	sub    rdx,rcx
  40b4d2:	inc    rdx
  40b4d5:	xor    r10d,r10d
  40b4d8:	test   r8,r8
  40b4db:	jbe    40b50b <__swc_fn_6b1cf01f_000061_1badc238+0x2ab>
  40b4dd:	nop    DWORD PTR [rax]
  40b4e0:	mov    r11d,r10d
  40b4e3:	lea    r11,[r11+r11*4]
  40b4e7:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40b4ef:	sub    r11,rcx
  40b4f2:	cmp    r11,rdx
  40b4f5:	jae    40b502 <__swc_fn_6b1cf01f_000061_1badc238+0x2a2>
  40b4f7:	mov    r9d,r10d
  40b4fa:	mov    rdx,r11
  40b4fd:	test   r11,r11
  40b500:	je     40b50b <__swc_fn_6b1cf01f_000061_1badc238+0x2ab>
  40b502:	add    r10,0x1
  40b506:	cmp    r10,r8
  40b509:	jb     40b4e0 <__swc_fn_6b1cf01f_000061_1badc238+0x280>
  40b50b:	mov    ecx,DWORD PTR [rax+0x730]
  40b511:	cmp    r9d,ecx
  40b514:	jne    40b51a <__swc_fn_6b1cf01f_000061_1badc238+0x2ba>
  40b516:	xor    eax,eax
  40b518:	jmp    40b579 <__swc_fn_6b1cf01f_000061_1badc238+0x319>
  40b51a:	lea    rcx,[r9+r9*4]
  40b51e:	lea    rcx,[rax+rcx*8+0x738]
  40b526:	vmovups xmm0,XMMWORD PTR [rcx]
  40b52a:	mov    rdx,QWORD PTR [rcx+0x10]
  40b52e:	sub    DWORD PTR [rax+0x730],0x1
  40b535:	mov    r8d,DWORD PTR [rax+0x730]
  40b53c:	lea    r8,[r8+r8*4]
  40b540:	lea    r8,[rax+r8*8+0x738]
  40b548:	vmovups xmm1,XMMWORD PTR [r8]
  40b54d:	vmovups XMMWORD PTR [rcx],xmm1
  40b551:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40b557:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40b55c:	mov    rax,QWORD PTR [r8+0x20]
  40b560:	mov    QWORD PTR [rcx+0x20],rax
  40b564:	vpshufd xmm1,xmm0,0xee
  40b569:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40b56f:	mov    QWORD PTR [rsp+0x10],rdx
  40b574:	vmovq  rax,xmm0
  40b579:	mov    r15,rax
  40b57c:	test   r15,r15
  40b57f:	jne    40b597 <__swc_fn_6b1cf01f_000061_1badc238+0x337>
  40b581:	mov    rcx,rbx
  40b584:	mov    rdx,QWORD PTR [rsp+0x8]
  40b589:	mov    r8,r13
  40b58c:	mov    r9,r12
  40b58f:	call   40ae50 <__swc_fn_6b1cf01f_000055_da36318f>
  40b594:	mov    r15,rax
  40b597:	test   r15,r15
  40b59a:	je     40b5db <__swc_fn_6b1cf01f_000061_1badc238+0x37b>
  40b59c:	cmp    QWORD PTR [r12],r14
  40b5a0:	jae    40b5db <__swc_fn_6b1cf01f_000061_1badc238+0x37b>
  40b5a2:	mov    rax,r15
  40b5a5:	add    rax,QWORD PTR [r12]
  40b5a9:	mov    rdx,r14
  40b5ac:	sub    rdx,QWORD PTR [r12]
  40b5b0:	mov    rcx,rax
  40b5b3:	call   4072a0 <__swc_fn_6b1cf01f_000003_644dadb7>
  40b5b8:	test   al,al
  40b5ba:	je     40b5c3 <__swc_fn_6b1cf01f_000061_1badc238+0x363>
  40b5bc:	mov    QWORD PTR [rsp+0x10],r14
  40b5c1:	jmp    40b5db <__swc_fn_6b1cf01f_000061_1badc238+0x37b>
  40b5c3:	mov    rcx,rbx
  40b5c6:	mov    rdx,r15
  40b5c9:	mov    r8,QWORD PTR [rsp+0x8]
  40b5ce:	mov    r9,QWORD PTR [rsp+0x10]
  40b5d3:	call   40af60 <__swc_fn_6b1cf01f_000058_033ce1da>
  40b5d8:	xor    r15d,r15d
  40b5db:	test   r15,r15
  40b5de:	jne    40b65a <__swc_fn_6b1cf01f_000061_1badc238+0x3fa>
  40b5e0:	cmp    r14,0x10000
  40b5e7:	ja     40b5ee <__swc_fn_6b1cf01f_000061_1badc238+0x38e>
  40b5e9:	mov    rax,r14
  40b5ec:	jmp    40b63f <__swc_fn_6b1cf01f_000061_1badc238+0x3df>
  40b5ee:	xor    eax,eax
  40b5f0:	lea    rcx,[r14-0x1]
  40b5f4:	lzcnt  rax,rcx
  40b5f9:	mov    ecx,0x3f
  40b5fe:	sub    rcx,rax
  40b601:	mov    eax,0x1
  40b606:	lea    rcx,[rcx-0x3]
  40b60a:	shl    rax,cl
  40b60d:	mov    rcx,rax
  40b610:	cmp    rax,0x1000
  40b617:	mov    eax,0x1000
  40b61c:	cmovb  rcx,rax
  40b620:	mov    rdx,0xffffffffffffffff
  40b627:	sub    rdx,rcx
  40b62a:	mov    rax,r14
  40b62d:	lea    r8,[r14+rcx*1-0x1]
  40b632:	neg    rcx
  40b635:	and    r8,rcx
  40b638:	cmp    r14,rdx
  40b63b:	cmovbe rax,r8
  40b63f:	mov    QWORD PTR [rsp+0x8],rax
  40b644:	mov    QWORD PTR [rsp+0x10],r14
  40b649:	mov    rcx,rbx
  40b64c:	mov    rdx,rax
  40b64f:	mov    r8,r14
  40b652:	call   40a9c0 <__swc_fn_6b1cf01f_000037_92e867c2>
  40b657:	mov    r15,rax
  40b65a:	test   r15,r15
  40b65d:	jne    40b66b <__swc_fn_6b1cf01f_000061_1badc238+0x40b>
  40b65f:	mov    r13,QWORD PTR [rsp+0x20]
  40b664:	mov    rsi,QWORD PTR [rsp+0x38]
  40b669:	jmp    40b6a7 <__swc_fn_6b1cf01f_000061_1badc238+0x447>
  40b66b:	mov    rax,r15
  40b66e:	add    rax,QWORD PTR [rsp+0x28]
  40b673:	mov    r13,QWORD PTR [rsp+0x20]
  40b678:	test   r13d,r13d
  40b67b:	mov    rcx,r13
  40b67e:	mov    edx,0x8
  40b683:	cmove  ecx,edx
  40b686:	dec    rcx
  40b689:	mov    rdx,0xffffffffffffffff
  40b690:	sub    rdx,rcx
  40b693:	cmp    rax,rdx
  40b696:	jbe    40b69c <__swc_fn_6b1cf01f_000061_1badc238+0x43c>
  40b698:	xor    eax,eax
  40b69a:	jmp    40b6a4 <__swc_fn_6b1cf01f_000061_1badc238+0x444>
  40b69c:	add    rax,rcx
  40b69f:	andn   rax,rcx,rax
  40b6a4:	mov    rsi,rax
  40b6a7:	mov    rax,QWORD PTR [rsp+0x8]
  40b6ac:	test   r15,r15
  40b6af:	je     40b6b8 <__swc_fn_6b1cf01f_000061_1badc238+0x458>
  40b6b1:	mov    rdi,QWORD PTR [rsp+0x18]
  40b6b6:	jmp    40b6ca <__swc_fn_6b1cf01f_000061_1badc238+0x46a>
  40b6b8:	mov    rdi,QWORD PTR [rsp+0x18]
  40b6bd:	mov    QWORD PTR [rdi+0x40],0x0
  40b6c5:	jmp    40b746 <__swc_fn_6b1cf01f_000061_1badc238+0x4e6>
  40b6ca:	lea    rdx,[rsi-0x58]
  40b6ce:	mov    QWORD PTR [rsi-0x58],r15
  40b6d2:	mov    QWORD PTR [rsi-0x50],rax
  40b6d6:	mov    rax,QWORD PTR [rsp+0x10]
  40b6db:	mov    QWORD PTR [rsi-0x48],rax
  40b6df:	mov    QWORD PTR [rsi-0x40],rsi
  40b6e3:	mov    rax,QWORD PTR [rdi+0x48]
  40b6e7:	mov    QWORD PTR [rsi-0x38],rax
  40b6eb:	mov    rax,QWORD PTR [rsp+0x30]
  40b6f0:	mov    QWORD PTR [rsi-0x30],rax
  40b6f4:	mov    DWORD PTR [rsi-0x10],r13d
  40b6f8:	mov    QWORD PTR [rsi-0x28],0x0
  40b700:	mov    QWORD PTR [rsi-0x20],0x0
  40b708:	add    r15,QWORD PTR [r12]
  40b70c:	sub    r15,rsi
  40b70f:	mov    QWORD PTR [rsi-0x30],r15
  40b713:	mov    rcx,QWORD PTR [rbx+0x250]
  40b71a:	nop    WORD PTR [rax+rax*1+0x0]
  40b720:	lea    r8,[rcx+r15*1]
  40b724:	mov    rax,rcx
  40b727:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40b730:	cmp    rax,rcx
  40b733:	je     40b73a <__swc_fn_6b1cf01f_000061_1badc238+0x4da>
  40b735:	mov    rcx,rax
  40b738:	jmp    40b720 <__swc_fn_6b1cf01f_000061_1badc238+0x4c0>
  40b73a:	mov    rcx,rbx
  40b73d:	call   40df30 <__swc_fn_6b1cf01f_000053_a8a124d6>
  40b742:	mov    QWORD PTR [rdi+0x40],rsi
  40b746:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40b74c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40b752:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40b758:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40b75e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40b767:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40b770:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40b779:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40b782:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40b78b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40b794:	add    rsp,0xf0
  40b79b:	pop    rsi
  40b79c:	pop    rdi
  40b79d:	pop    r15
  40b79f:	pop    r14
  40b7a1:	pop    r13
  40b7a3:	pop    r12
  40b7a5:	pop    rbx
  40b7a6:	ret
	...

000000000040b7b0 <__swc_fn_6b1cf01f_000064_6905bec4>:
  40b7b0:	push   rbx
  40b7b1:	push   r12
  40b7b3:	push   rdi
  40b7b4:	push   rsi
  40b7b5:	sub    rsp,0xb8
  40b7bc:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40b7c2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40b7c8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40b7ce:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40b7d4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40b7da:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40b7e0:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40b7e6:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40b7ef:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40b7f8:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40b801:	mov    rbx,rdx
  40b804:	mov    r12,rcx
  40b807:	cmp    DWORD PTR [rbx+0x58],0x0
  40b80b:	je     40b825 <__swc_fn_6b1cf01f_000064_6905bec4+0x75>
  40b80d:	mov    eax,DWORD PTR [rbx+0x58]
  40b810:	sub    eax,0x1
  40b813:	test   DWORD PTR [rbx+0x58],eax
  40b816:	je     40b825 <__swc_fn_6b1cf01f_000064_6905bec4+0x75>
  40b818:	mov    QWORD PTR [rbx+0x40],0x0
  40b820:	jmp    40ba37 <__swc_fn_6b1cf01f_000064_6905bec4+0x287>
  40b825:	cmp    QWORD PTR [rbx+0x48],0x0
  40b82a:	jne    40b839 <__swc_fn_6b1cf01f_000064_6905bec4+0x89>
  40b82c:	mov    QWORD PTR [rbx+0x40],0x0
  40b834:	jmp    40ba37 <__swc_fn_6b1cf01f_000064_6905bec4+0x287>
  40b839:	lea    rax,[rsp+0x8]
  40b83e:	mov    rcx,QWORD PTR [rbx+0x48]
  40b842:	cmp    rcx,0x8
  40b846:	ja     40b850 <__swc_fn_6b1cf01f_000064_6905bec4+0xa0>
  40b848:	mov    DWORD PTR [rax],0x0
  40b84e:	jmp    40b8ab <__swc_fn_6b1cf01f_000064_6905bec4+0xfb>
  40b850:	cmp    rcx,0x80
  40b857:	ja     40b867 <__swc_fn_6b1cf01f_000064_6905bec4+0xb7>
  40b859:	lea    rcx,[rcx+0xf]
  40b85d:	shr    rcx,0x4
  40b861:	mov    DWORD PTR [rsp+0x8],ecx
  40b865:	jmp    40b8ab <__swc_fn_6b1cf01f_000064_6905bec4+0xfb>
  40b867:	cmp    rcx,0x10000
  40b86e:	jbe    40b878 <__swc_fn_6b1cf01f_000064_6905bec4+0xc8>
  40b870:	mov    DWORD PTR [rax],0xffffffff
  40b876:	jmp    40b8ab <__swc_fn_6b1cf01f_000064_6905bec4+0xfb>
  40b878:	dec    rcx
  40b87b:	xor    edx,edx
  40b87d:	lzcnt  rdx,rcx
  40b882:	mov    r8d,0x3f
  40b888:	sub    r8d,edx
  40b88b:	lea    edx,[r8-0x2]
  40b88f:	shrx   rcx,rcx,rdx
  40b894:	and    ecx,0x3
  40b897:	lea    edx,[r8-0x7]
  40b89b:	lea    edx,[rdx*4+0x0]
  40b8a2:	lea    edx,[rdx+0x9]
  40b8a5:	add    edx,ecx
  40b8a7:	mov    DWORD PTR [rsp+0x8],edx
  40b8ab:	cmp    DWORD PTR [rax],0x0
  40b8ae:	jne    40b8be <__swc_fn_6b1cf01f_000064_6905bec4+0x10e>
  40b8b0:	cmp    DWORD PTR [rbx+0x58],0x8
  40b8b4:	jbe    40b8be <__swc_fn_6b1cf01f_000064_6905bec4+0x10e>
  40b8b6:	mov    DWORD PTR [rsp+0x8],0x1
  40b8be:	cmp    DWORD PTR [rbx+0x58],0x10
  40b8c2:	jbe    40b941 <__swc_fn_6b1cf01f_000064_6905bec4+0x191>
  40b8c8:	cmp    DWORD PTR [rbx+0x58],0x40
  40b8cc:	ja     40b941 <__swc_fn_6b1cf01f_000064_6905bec4+0x191>
  40b8ce:	cmp    DWORD PTR [rax],0xffffffff
  40b8d1:	je     40b941 <__swc_fn_6b1cf01f_000064_6905bec4+0x191>
  40b8d3:	mov    ecx,DWORD PTR [rsp+0x8]
  40b8d7:	mov    edx,DWORD PTR [rbx+0x58]
  40b8da:	dec    rdx
  40b8dd:	cmp    ecx,0x2d
  40b8e0:	jae    40b938 <__swc_fn_6b1cf01f_000064_6905bec4+0x188>
  40b8e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40b8ec:	nop    DWORD PTR [rax+0x0]
  40b8f0:	mov    r8d,ecx
  40b8f3:	test   ecx,ecx
  40b8f5:	jne    40b8ff <__swc_fn_6b1cf01f_000064_6905bec4+0x14f>
  40b8f7:	mov    r8d,0x8
  40b8fd:	jmp    40b92b <__swc_fn_6b1cf01f_000064_6905bec4+0x17b>
  40b8ff:	cmp    r8d,0x8
  40b903:	ja     40b90b <__swc_fn_6b1cf01f_000064_6905bec4+0x15b>
  40b905:	shl    r8,0x4
  40b909:	jmp    40b92b <__swc_fn_6b1cf01f_000064_6905bec4+0x17b>
  40b90b:	lea    r8d,[r8-0x9]
  40b90f:	mov    r9d,r8d
  40b912:	shr    r9d,0x2
  40b916:	and    r8d,0x3
  40b91a:	lea    r9d,[r9+0x7]
  40b91e:	lea    r9d,[r9-0x2]
  40b922:	lea    r8d,[r8+0x5]
  40b926:	shlx   r8,r8,r9
  40b92b:	test   r8,rdx
  40b92e:	je     40b93d <__swc_fn_6b1cf01f_000064_6905bec4+0x18d>
  40b930:	add    ecx,0x1
  40b933:	cmp    ecx,0x2d
  40b936:	jb     40b8f0 <__swc_fn_6b1cf01f_000064_6905bec4+0x140>
  40b938:	mov    ecx,0xffffffff
  40b93d:	mov    DWORD PTR [rsp+0x8],ecx
  40b941:	mov    ecx,DWORD PTR [rsp+0x8]
  40b945:	cmp    ecx,0xffffffff
  40b948:	je     40b950 <__swc_fn_6b1cf01f_000064_6905bec4+0x1a0>
  40b94a:	cmp    DWORD PTR [rbx+0x58],0x40
  40b94e:	jbe    40b963 <__swc_fn_6b1cf01f_000064_6905bec4+0x1b3>
  40b950:	mov    rcx,r12
  40b953:	mov    rdx,rbx
  40b956:	mov    r8d,DWORD PTR [rax]
  40b959:	call   40b260 <__swc_fn_6b1cf01f_000061_1badc238>
  40b95e:	jmp    40ba37 <__swc_fn_6b1cf01f_000064_6905bec4+0x287>
  40b963:	lea    rax,[rip+0x16696]        # 422000 <__swc_data_base_6b1cf01f>
  40b96a:	mov    rax,QWORD PTR [rax]
  40b96d:	cmp    rax,0xffffffffffffffff
  40b971:	je     40b980 <__swc_fn_6b1cf01f_000064_6905bec4+0x1d0>
  40b973:	mov    eax,eax
  40b975:	mov    edi,eax
  40b977:	xor    eax,eax
  40b979:	call   407000 <pthread_getspecific@plt>
  40b97e:	jmp    40b982 <__swc_fn_6b1cf01f_000064_6905bec4+0x1d2>
  40b980:	xor    eax,eax
  40b982:	test   rax,rax
  40b985:	jne    40b994 <__swc_fn_6b1cf01f_000064_6905bec4+0x1e4>
  40b987:	call   40a900 <__swc_fn_6b1cf01f_000031_ed8d61a9>
  40b98c:	mov    rcx,rax
  40b98f:	call   40fc00 <__swc_fn_6b1cf01f_000128_9c45d2d7>
  40b994:	test   rax,rax
  40b997:	je     40b9a4 <__swc_fn_6b1cf01f_000064_6905bec4+0x1f4>
  40b999:	cmp    QWORD PTR [rax],r12
  40b99c:	jne    40b9a4 <__swc_fn_6b1cf01f_000064_6905bec4+0x1f4>
  40b99e:	cmp    DWORD PTR [rax+0x20],0x0
  40b9a2:	je     40b9af <__swc_fn_6b1cf01f_000064_6905bec4+0x1ff>
  40b9a4:	mov    rcx,r12
  40b9a7:	mov    rdx,rax
  40b9aa:	call   40db70 <__swc_fn_6b1cf01f_000041_ed1cda78>
  40b9af:	test   rax,rax
  40b9b2:	jne    40b9be <__swc_fn_6b1cf01f_000064_6905bec4+0x20e>
  40b9b4:	mov    QWORD PTR [rbx+0x40],0x0
  40b9bc:	jmp    40ba37 <__swc_fn_6b1cf01f_000064_6905bec4+0x287>
  40b9be:	lea    r8,[rsp+0xc]
  40b9c3:	mov    ecx,DWORD PTR [rsp+0x8]
  40b9c7:	mov    DWORD PTR [rsp+0xc],ecx
  40b9cb:	mov    ecx,DWORD PTR [r8]
  40b9ce:	lea    rcx,[rcx+rcx*4]
  40b9d2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40b9d7:	test   rcx,rcx
  40b9da:	je     40ba13 <__swc_fn_6b1cf01f_000064_6905bec4+0x263>
  40b9dc:	mov    rdx,QWORD PTR [rcx]
  40b9df:	test   rdx,rdx
  40b9e2:	je     40b9f0 <__swc_fn_6b1cf01f_000064_6905bec4+0x240>
  40b9e4:	mov    r9,QWORD PTR [rdx]
  40b9e7:	mov    QWORD PTR [rcx],r9
  40b9ea:	add    DWORD PTR [rcx+0x28],0x1
  40b9ee:	jmp    40ba0e <__swc_fn_6b1cf01f_000064_6905bec4+0x25e>
  40b9f0:	mov    rdx,QWORD PTR [rcx+0x18]
  40b9f4:	cmp    QWORD PTR [rcx+0x20],rdx
  40b9f8:	jae    40ba0c <__swc_fn_6b1cf01f_000064_6905bec4+0x25c>
  40b9fa:	mov    rdx,QWORD PTR [rcx+0x20]
  40b9fe:	mov    r9d,DWORD PTR [rcx+0x2c]
  40ba02:	add    QWORD PTR [rcx+0x20],r9
  40ba06:	add    DWORD PTR [rcx+0x28],0x1
  40ba0a:	jmp    40ba0e <__swc_fn_6b1cf01f_000064_6905bec4+0x25e>
  40ba0c:	xor    edx,edx
  40ba0e:	test   rdx,rdx
  40ba11:	jne    40ba24 <__swc_fn_6b1cf01f_000064_6905bec4+0x274>
  40ba13:	mov    rcx,r12
  40ba16:	mov    rdx,rax
  40ba19:	mov    r8d,DWORD PTR [r8]
  40ba1c:	call   40dce0 <__swc_fn_6b1cf01f_000050_e33921d7>
  40ba21:	mov    rdx,rax
  40ba24:	test   rdx,rdx
  40ba27:	jne    40ba33 <__swc_fn_6b1cf01f_000064_6905bec4+0x283>
  40ba29:	mov    QWORD PTR [rbx+0x40],0x0
  40ba31:	jmp    40ba37 <__swc_fn_6b1cf01f_000064_6905bec4+0x287>
  40ba33:	mov    QWORD PTR [rbx+0x40],rdx
  40ba37:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ba3d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40ba43:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40ba49:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ba4f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ba55:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ba5b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ba61:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ba6a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ba73:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ba7c:	add    rsp,0xb8
  40ba83:	pop    rsi
  40ba84:	pop    rdi
  40ba85:	pop    r12
  40ba87:	pop    rbx
  40ba88:	ret
  40ba89:	add    BYTE PTR [rax],al
  40ba8b:	add    BYTE PTR [rax],al
  40ba8d:	add    BYTE PTR [rax],al
	...

000000000040ba90 <__swc_fn_6b1cf01f_000067_381f5b88>:
  40ba90:	ret
	...

000000000040baa0 <__swc_fn_6b1cf01f_000070_2cd83140>:
  40baa0:	push   r12
  40baa2:	push   r13
  40baa4:	push   r14
  40baa6:	push   rdi
  40baa7:	push   rsi
  40baa8:	sub    rsp,0x1a0
  40baaf:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40bab8:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40bac1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40baca:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40bad3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40badc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40bae5:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40baee:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40baf7:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40bb00:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40bb09:	mov    r12,rdx
  40bb0c:	mov    r13,rcx
  40bb0f:	mov    rax,QWORD PTR [r12+0x48]
  40bb14:	mov    ecx,DWORD PTR [r12+0x58]
  40bb19:	lea    rdx,[rax-0x1]
  40bb1d:	cmp    rdx,0x10000
  40bb24:	jae    40bc1e <__swc_fn_6b1cf01f_000070_2cd83140+0x17e>
  40bb2a:	cmp    rax,0x8
  40bb2e:	ja     40bb35 <__swc_fn_6b1cf01f_000070_2cd83140+0x95>
  40bb30:	xor    r14d,r14d
  40bb33:	jmp    40bb87 <__swc_fn_6b1cf01f_000070_2cd83140+0xe7>
  40bb35:	cmp    rax,0x80
  40bb3c:	ja     40bb48 <__swc_fn_6b1cf01f_000070_2cd83140+0xa8>
  40bb3e:	lea    r14,[rax+0xf]
  40bb42:	shr    r14,0x4
  40bb46:	jmp    40bb87 <__swc_fn_6b1cf01f_000070_2cd83140+0xe7>
  40bb48:	cmp    rax,0x10000
  40bb4f:	jbe    40bb59 <__swc_fn_6b1cf01f_000070_2cd83140+0xb9>
  40bb51:	mov    r14d,0xffffffff
  40bb57:	jmp    40bb87 <__swc_fn_6b1cf01f_000070_2cd83140+0xe7>
  40bb59:	xor    eax,eax
  40bb5b:	lzcnt  rax,rdx
  40bb60:	mov    r8d,0x3f
  40bb66:	sub    r8d,eax
  40bb69:	lea    eax,[r8-0x2]
  40bb6d:	shrx   rax,rdx,rax
  40bb72:	and    eax,0x3
  40bb75:	lea    edx,[r8-0x7]
  40bb79:	lea    edx,[rdx*4+0x0]
  40bb80:	lea    edx,[rdx+0x9]
  40bb83:	lea    r14d,[rdx+rax*1]
  40bb87:	cmp    ecx,0x8
  40bb8a:	jbe    40bba3 <__swc_fn_6b1cf01f_000070_2cd83140+0x103>
  40bb8c:	cmp    ecx,0x10
  40bb8f:	jne    40bc1e <__swc_fn_6b1cf01f_000070_2cd83140+0x17e>
  40bb95:	test   r14d,r14d
  40bb98:	mov    eax,0x1
  40bb9d:	cmove  r14d,eax
  40bba1:	jmp    40bbaa <__swc_fn_6b1cf01f_000070_2cd83140+0x10a>
  40bba3:	lea    eax,[rcx-0x1]
  40bba6:	test   eax,ecx
  40bba8:	jne    40bc1e <__swc_fn_6b1cf01f_000070_2cd83140+0x17e>
  40bbaa:	lea    rax,[rip+0x1644f]        # 422000 <__swc_data_base_6b1cf01f>
  40bbb1:	mov    rax,QWORD PTR [rax]
  40bbb4:	cmp    rax,0xffffffffffffffff
  40bbb8:	je     40bbc7 <__swc_fn_6b1cf01f_000070_2cd83140+0x127>
  40bbba:	mov    eax,eax
  40bbbc:	mov    edi,eax
  40bbbe:	xor    eax,eax
  40bbc0:	call   407000 <pthread_getspecific@plt>
  40bbc5:	jmp    40bbc9 <__swc_fn_6b1cf01f_000070_2cd83140+0x129>
  40bbc7:	xor    eax,eax
  40bbc9:	test   rax,rax
  40bbcc:	je     40bc1e <__swc_fn_6b1cf01f_000070_2cd83140+0x17e>
  40bbce:	cmp    QWORD PTR [rax],r13
  40bbd1:	jne    40bc1e <__swc_fn_6b1cf01f_000070_2cd83140+0x17e>
  40bbd3:	lea    rcx,[r14+r14*4]
  40bbd7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40bbdc:	test   rax,rax
  40bbdf:	je     40bc1e <__swc_fn_6b1cf01f_000070_2cd83140+0x17e>
  40bbe1:	mov    rcx,QWORD PTR [rax]
  40bbe4:	test   rcx,rcx
  40bbe7:	je     40bbf5 <__swc_fn_6b1cf01f_000070_2cd83140+0x155>
  40bbe9:	mov    rdx,QWORD PTR [rcx]
  40bbec:	mov    QWORD PTR [rax],rdx
  40bbef:	add    DWORD PTR [rax+0x28],0x1
  40bbf3:	jmp    40bc12 <__swc_fn_6b1cf01f_000070_2cd83140+0x172>
  40bbf5:	mov    rcx,QWORD PTR [rax+0x18]
  40bbf9:	cmp    QWORD PTR [rax+0x20],rcx
  40bbfd:	jae    40bc10 <__swc_fn_6b1cf01f_000070_2cd83140+0x170>
  40bbff:	mov    rcx,QWORD PTR [rax+0x20]
  40bc03:	mov    edx,DWORD PTR [rax+0x2c]
  40bc06:	add    QWORD PTR [rax+0x20],rdx
  40bc0a:	add    DWORD PTR [rax+0x28],0x1
  40bc0e:	jmp    40bc12 <__swc_fn_6b1cf01f_000070_2cd83140+0x172>
  40bc10:	xor    ecx,ecx
  40bc12:	test   rcx,rcx
  40bc15:	je     40bc1e <__swc_fn_6b1cf01f_000070_2cd83140+0x17e>
  40bc17:	mov    QWORD PTR [r12+0x40],rcx
  40bc1c:	jmp    40bc29 <__swc_fn_6b1cf01f_000070_2cd83140+0x189>
  40bc1e:	mov    rcx,r13
  40bc21:	mov    rdx,r12
  40bc24:	call   40e760 <__swc_fn_6b1cf01f_000071_7e144e9b>
  40bc29:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40bc32:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40bc3b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40bc44:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40bc4d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40bc56:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40bc5f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40bc68:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40bc71:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40bc7a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40bc83:	add    rsp,0x1a0
  40bc8a:	pop    rsi
  40bc8b:	pop    rdi
  40bc8c:	pop    r14
  40bc8e:	pop    r13
  40bc90:	pop    r12
  40bc92:	ret
	...

000000000040bca0 <__swc_fn_6b1cf01f_000073_c77adf75>:
  40bca0:	push   r12
  40bca2:	push   r13
  40bca4:	push   r14
  40bca6:	push   r15
  40bca8:	push   rdi
  40bca9:	push   rsi
  40bcaa:	sub    rsp,0x188
  40bcb1:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40bcba:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40bcc3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40bccc:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40bcd5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40bcde:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40bce7:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40bcf0:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40bcf9:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40bd02:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40bd0b:	mov    r12,rdx
  40bd0e:	mov    r13,rcx
  40bd11:	mov    r14,QWORD PTR [r12+0x40]
  40bd16:	lea    rax,[rip+0x18353]        # 424070 <__swc_bss_base_6b1cf01f+0x30>
  40bd1d:	mov    rcx,r14
  40bd20:	sub    rcx,QWORD PTR [rax+0x8]
  40bd24:	mov    rax,QWORD PTR [rip+0x18355]        # 424080 <__swc_bss_base_6b1cf01f+0x40>
  40bd2b:	cmp    rcx,rax
  40bd2e:	jae    40bd5a <__swc_fn_6b1cf01f_000073_c77adf75+0xba>
  40bd30:	mov    rax,r14
  40bd33:	and    rax,0xffffffffffc00000
  40bd3a:	mov    rcx,r14
  40bd3d:	shr    rcx,0x10
  40bd41:	and    ecx,0x3f
  40bd44:	mov    edx,DWORD PTR [rax+0x28]
  40bd47:	shrx   ecx,ecx,edx
  40bd4c:	shl    rcx,0x4
  40bd50:	lea    r15,[rax+rcx*8+0x80]
  40bd58:	jmp    40bd65 <__swc_fn_6b1cf01f_000073_c77adf75+0xc5>
  40bd5a:	mov    rcx,r14
  40bd5d:	call   40a830 <__swc_fn_6b1cf01f_000022_77c2d682>
  40bd62:	mov    r15,rax
  40bd65:	test   r15,r15
  40bd68:	je     40be0f <__swc_fn_6b1cf01f_000073_c77adf75+0x16f>
  40bd6e:	lea    rax,[rip+0x1628b]        # 422000 <__swc_data_base_6b1cf01f>
  40bd75:	mov    rax,QWORD PTR [rax]
  40bd78:	cmp    rax,0xffffffffffffffff
  40bd7c:	je     40bd8b <__swc_fn_6b1cf01f_000073_c77adf75+0xeb>
  40bd7e:	mov    eax,eax
  40bd80:	mov    edi,eax
  40bd82:	xor    eax,eax
  40bd84:	call   407000 <pthread_getspecific@plt>
  40bd89:	jmp    40bd8d <__swc_fn_6b1cf01f_000073_c77adf75+0xed>
  40bd8b:	xor    eax,eax
  40bd8d:	mov    rcx,QWORD PTR [r15+0x40]
  40bd91:	cmp    rcx,rax
  40bd94:	jne    40bdf4 <__swc_fn_6b1cf01f_000073_c77adf75+0x154>
  40bd96:	test   rax,rax
  40bd99:	je     40be0f <__swc_fn_6b1cf01f_000073_c77adf75+0x16f>
  40bd9b:	mov    ecx,DWORD PTR [r15+0x6c]
  40bd9f:	test   ecx,ecx
  40bda1:	je     40bdc1 <__swc_fn_6b1cf01f_000073_c77adf75+0x121>
  40bda3:	mov    rcx,r13
  40bda6:	mov    rdx,rax
  40bda9:	mov    r8,r15
  40bdac:	mov    QWORD PTR [rsp+0xd8],rax
  40bdb4:	call   40dc70 <__swc_fn_6b1cf01f_000047_3d3eceb4>
  40bdb9:	mov    rax,QWORD PTR [rsp+0xd8]
  40bdc1:	mov    rcx,QWORD PTR [r15]
  40bdc4:	mov    QWORD PTR [r14],rcx
  40bdc7:	mov    QWORD PTR [r15],r14
  40bdca:	sub    DWORD PTR [r15+0x28],0x1
  40bdcf:	jne    40be04 <__swc_fn_6b1cf01f_000073_c77adf75+0x164>
  40bdd1:	movzx  ecx,BYTE PTR [r15+0x39]
  40bdd6:	lea    rcx,[rcx+rcx*4]
  40bdda:	lea    rcx,[rax+rcx*8+0x28]
  40bddf:	cmp    QWORD PTR [rcx],r15
  40bde2:	je     40be04 <__swc_fn_6b1cf01f_000073_c77adf75+0x164>
  40bde4:	mov    rcx,r13
  40bde7:	mov    rdx,rax
  40bdea:	mov    r8,r15
  40bded:	call   407d80 <__swc_fn_6b1cf01f_000051_5b91e689>
  40bdf2:	jmp    40be04 <__swc_fn_6b1cf01f_000073_c77adf75+0x164>
  40bdf4:	test   rcx,rcx
  40bdf7:	je     40be0f <__swc_fn_6b1cf01f_000073_c77adf75+0x16f>
  40bdf9:	mov    rcx,r15
  40bdfc:	mov    rdx,r14
  40bdff:	call   40a470 <__swc_fn_6b1cf01f_000010_186cd0c2>
  40be04:	mov    QWORD PTR [r12+0x40],0x0
  40be0d:	jmp    40be1a <__swc_fn_6b1cf01f_000073_c77adf75+0x17a>
  40be0f:	mov    rcx,r13
  40be12:	mov    rdx,r12
  40be15:	call   40e780 <__swc_fn_6b1cf01f_000074_9eaf4878>
  40be1a:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40be23:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40be2c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40be35:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40be3e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40be47:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40be50:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40be59:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40be62:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40be6b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40be74:	add    rsp,0x188
  40be7b:	pop    rsi
  40be7c:	pop    rdi
  40be7d:	pop    r15
  40be7f:	pop    r14
  40be81:	pop    r13
  40be83:	pop    r12
  40be85:	ret
	...

000000000040be90 <__swc_fn_6b1cf01f_000076_d8e626b0>:
  40be90:	sub    rsp,0x8
  40be94:	mov    rax,rdx
  40be97:	mov    rdx,QWORD PTR [rax+0x40]
  40be9b:	mov    r8,rax
  40be9e:	call   40ba90 <__swc_fn_6b1cf01f_000067_381f5b88>
  40bea3:	add    rsp,0x8
  40bea7:	ret
	...

000000000040beb0 <__swc_fn_6b1cf01f_000079_29fad089>:
  40beb0:	push   rsi
  40beb1:	push   rdi
  40beb2:	sub    rsp,0x8
  40beb6:	cmp    rcx,0xffffffffffffffef
  40beba:	ja     40bee0 <__swc_fn_6b1cf01f_000079_29fad089+0x30>
  40bebc:	xor    esi,esi
  40bebe:	lea    rax,[rcx+0x100f]
  40bec5:	and    rax,0xfffffffffffff000
  40becc:	lea    rcx,[rcx+0x10]
  40bed0:	cmp    rcx,0xfffffffffffff000
  40bed7:	cmovbe rsi,rax
  40bedb:	test   rsi,rsi
  40bede:	jne    40bee9 <__swc_fn_6b1cf01f_000079_29fad089+0x39>
  40bee0:	xor    eax,eax
  40bee2:	add    rsp,0x8
  40bee6:	pop    rdi
  40bee7:	pop    rsi
  40bee8:	ret
  40bee9:	mov    rcx,rsi
  40beec:	call   40c540 <__swc_fn_6b1cf01f_000109_aa570b2b>
  40bef1:	mov    rdi,rax
  40bef4:	test   rax,rax
  40bef7:	jne    40bf02 <__swc_fn_6b1cf01f_000079_29fad089+0x52>
  40bef9:	xor    eax,eax
  40befb:	add    rsp,0x8
  40beff:	pop    rdi
  40bf00:	pop    rsi
  40bf01:	ret
  40bf02:	mov    rcx,rdi
  40bf05:	mov    rdx,rsi
  40bf08:	call   409240 <__swc_fn_6b1cf01f_000111_e724f834>
  40bf0d:	test   al,al
  40bf0f:	jne    40bf25 <__swc_fn_6b1cf01f_000079_29fad089+0x75>
  40bf11:	mov    rcx,rdi
  40bf14:	mov    rdx,rsi
  40bf17:	call   40f8b0 <__swc_fn_6b1cf01f_000113_25e345b1>
  40bf1c:	xor    eax,eax
  40bf1e:	add    rsp,0x8
  40bf22:	pop    rdi
  40bf23:	pop    rsi
  40bf24:	ret
  40bf25:	mov    QWORD PTR [rdi],rsi
  40bf28:	mov    QWORD PTR [rdi+0x8],0x0
  40bf30:	lea    rax,[rdi+0x10]
  40bf34:	add    rsp,0x8
  40bf38:	pop    rdi
  40bf39:	pop    rsi
  40bf3a:	ret
  40bf3b:	add    BYTE PTR [rax],al
  40bf3d:	add    BYTE PTR [rax],al
	...

000000000040bf40 <__swc_fn_6b1cf01f_000082_9f4f5092>:
  40bf40:	sub    rsp,0x8
  40bf44:	cmp    BYTE PTR [rcx+0x2c],0x10
  40bf48:	jne    40bf53 <__swc_fn_6b1cf01f_000082_9f4f5092+0x13>
  40bf4a:	test   DWORD PTR [rcx+0x28],0x80
  40bf51:	je     40bf5b <__swc_fn_6b1cf01f_000082_9f4f5092+0x1b>
  40bf53:	mov    rax,rcx
  40bf56:	add    rsp,0x8
  40bf5a:	ret
  40bf5b:	mov    rcx,QWORD PTR [rcx+0x40]
  40bf5f:	call   40bf40 <__swc_fn_6b1cf01f_000082_9f4f5092>
  40bf64:	add    rsp,0x8
  40bf68:	ret
	...

000000000040bf80 <__swc_fn_6b1cf01f_000085_88128f21>:
  40bf80:	push   rsi
  40bf81:	push   rdi
  40bf82:	push   r12
  40bf84:	push   r13
  40bf86:	sub    rsp,0x8
  40bf8a:	mov    rsi,rdx
  40bf8d:	mov    rdi,rcx
  40bf90:	xor    r8d,r8d
  40bf93:	call   4085a0 <__swc_fn_6b1cf01f_000090_9a1d717d>
  40bf98:	test   al,al
  40bf9a:	je     40bfac <__swc_fn_6b1cf01f_000085_88128f21+0x2c>
  40bf9c:	mov    eax,0x1
  40bfa1:	add    rsp,0x8
  40bfa5:	pop    r13
  40bfa7:	pop    r12
  40bfa9:	pop    rdi
  40bfaa:	pop    rsi
  40bfab:	ret
  40bfac:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40bfb1:	je     40bfc0 <__swc_fn_6b1cf01f_000085_88128f21+0x40>
  40bfb3:	xor    eax,eax
  40bfb5:	add    rsp,0x8
  40bfb9:	pop    r13
  40bfbb:	pop    r12
  40bfbd:	pop    rdi
  40bfbe:	pop    rsi
  40bfbf:	ret
  40bfc0:	mov    r12,QWORD PTR [rsi+0x98]
  40bfc7:	mov    rax,QWORD PTR [rsi+0xa0]
  40bfce:	mov    rsi,rax
  40bfd1:	xor    r13d,r13d
  40bfd4:	test   rsi,rsi
  40bfd7:	je     40c034 <__swc_fn_6b1cf01f_000085_88128f21+0xb4>
  40bfd9:	cs nop WORD PTR [rax+rax*1+0x0]
  40bfe3:	cs nop WORD PTR [rax+rax*1+0x0]
  40bfed:	nop    DWORD PTR [rax]
  40bff0:	lea    rax,[r13*8+0x0]
  40bff8:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40bffd:	mov    rcx,rax
  40c000:	call   40bf40 <__swc_fn_6b1cf01f_000082_9f4f5092>
  40c005:	cmp    BYTE PTR [rax+0x2c],0xe
  40c009:	jne    40c02a <__swc_fn_6b1cf01f_000085_88128f21+0xaa>
  40c00b:	mov    rcx,rdi
  40c00e:	mov    rdx,rax
  40c011:	call   40bf80 <__swc_fn_6b1cf01f_000085_88128f21>
  40c016:	test   al,al
  40c018:	je     40c02a <__swc_fn_6b1cf01f_000085_88128f21+0xaa>
  40c01a:	mov    eax,0x1
  40c01f:	add    rsp,0x8
  40c023:	pop    r13
  40c025:	pop    r12
  40c027:	pop    rdi
  40c028:	pop    rsi
  40c029:	ret
  40c02a:	add    r13,0x1
  40c02e:	sub    rsi,0x1
  40c032:	jne    40bff0 <__swc_fn_6b1cf01f_000085_88128f21+0x70>
  40c034:	xor    eax,eax
  40c036:	add    rsp,0x8
  40c03a:	pop    r13
  40c03c:	pop    r12
  40c03e:	pop    rdi
  40c03f:	pop    rsi
  40c040:	ret
	...

000000000040c050 <__swc_fn_6b1cf01f_000088_17711411>:
  40c050:	sub    rsp,0x18
  40c054:	vxorps xmm0,xmm0,xmm0
  40c058:	vmovdqu XMMWORD PTR [rsp],xmm0
  40c05d:	call   40e990 <__swc_fn_6b1cf01f_000089_157b05de>
  40c062:	add    rsp,0x18
  40c066:	ret
	...

000000000040c070 <__swc_fn_6b1cf01f_000091_e6773530>:
  40c070:	sub    rsp,0x8
  40c074:	mov    rcx,QWORD PTR [rip+0x1acc5]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40c07b:	test   rcx,rcx
  40c07e:	jne    40c090 <__swc_fn_6b1cf01f_000091_e6773530+0x20>
  40c080:	call   40a1a0 <__swc_fn_6b1cf01f_000165_e09accff>
  40c085:	lea    rcx,[rax+0x1]
  40c089:	mov    QWORD PTR [rip+0x1acb0],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40c090:	dec    rcx
  40c093:	call   411680 <__swc_fn_6b1cf01f_000167_3130645d>
  40c098:	mov    rax,QWORD PTR [rax+0xc0]
  40c09f:	and    eax,0x1
  40c0a2:	setne  al
  40c0a5:	add    rsp,0x8
  40c0a9:	ret
	...

000000000040c0c0 <__swc_fn_6b1cf01f_000094_335e9a12>:
  40c0c0:	push   rbx
  40c0c1:	push   rsi
  40c0c2:	push   rdi
  40c0c3:	push   r12
  40c0c5:	sub    rsp,0x28
  40c0c9:	mov    rbx,rcx
  40c0cc:	call   408900 <__swc_fn_6b1cf01f_000093_344f5089>
  40c0d1:	mov    rcx,QWORD PTR [rip+0x1ac68]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40c0d8:	test   rcx,rcx
  40c0db:	jne    40c0ed <__swc_fn_6b1cf01f_000094_335e9a12+0x2d>
  40c0dd:	call   40a1a0 <__swc_fn_6b1cf01f_000165_e09accff>
  40c0e2:	lea    rcx,[rax+0x1]
  40c0e6:	mov    QWORD PTR [rip+0x1ac53],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40c0ed:	dec    rcx
  40c0f0:	call   411680 <__swc_fn_6b1cf01f_000167_3130645d>
  40c0f5:	mov    rsi,rax
  40c0f8:	lea    rcx,[rsp+0x8]
  40c0fd:	call   40edd0 <__swc_fn_6b1cf01f_000092_17e20532>
  40c102:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40c109:	mov    r12,QWORD PTR [rsi+0xbe8]
  40c110:	lea    rcx,[rsi+0x10]
  40c114:	call   40d090 <__swc_fn_6b1cf01f_000157_5c8b11d8>
  40c119:	mov    rcx,rsi
  40c11c:	call   40ef40 <__swc_fn_6b1cf01f_000101_295ddd7c>
  40c121:	vxorps xmm0,xmm0,xmm0
  40c125:	xor    eax,eax
  40c127:	cs nop WORD PTR [rax+rax*1+0x0]
  40c131:	cs nop WORD PTR [rax+rax*1+0x0]
  40c13b:	nop    DWORD PTR [rax+rax*1+0x0]
  40c140:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40c145:	add    rax,0x10
  40c149:	cmp    rax,0xbf0
  40c150:	jne    40c140 <__swc_fn_6b1cf01f_000094_335e9a12+0x80>
  40c152:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c158:	vmovups XMMWORD PTR [rsi],xmm0
  40c15c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c162:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40c16a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40c171:	mov    QWORD PTR [rsi+0xbe8],r12
  40c178:	mov    rcx,QWORD PTR [rip+0x1abc1]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40c17f:	test   rcx,rcx
  40c182:	jne    40c194 <__swc_fn_6b1cf01f_000094_335e9a12+0xd4>
  40c184:	call   40a1a0 <__swc_fn_6b1cf01f_000165_e09accff>
  40c189:	lea    rcx,[rax+0x1]
  40c18d:	mov    QWORD PTR [rip+0x1abac],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40c194:	dec    rcx
  40c197:	call   411680 <__swc_fn_6b1cf01f_000167_3130645d>
  40c19c:	mov    rsi,rax
  40c19f:	mov    QWORD PTR [rsi+0xc0],rbx
  40c1a6:	and    ebx,0x1
  40c1a9:	jne    40c1ad <__swc_fn_6b1cf01f_000094_335e9a12+0xed>
  40c1ab:	xor    eax,eax
  40c1ad:	test   rbx,rbx
  40c1b0:	sete   al
  40c1b3:	xor    cl,cl
  40c1b5:	xor    dl,dl
  40c1b7:	xor    r8b,r8b
  40c1ba:	xor    r9b,r9b
  40c1bd:	xor    r10b,r10b
  40c1c0:	mov    r11,rax
  40c1c3:	call   40e790 <__swc_fn_6b1cf01f_000077_e793b5e1>
  40c1c8:	lea    rbx,[rsp+0x18]
  40c1cd:	mov    rcx,rbx
  40c1d0:	call   40edd0 <__swc_fn_6b1cf01f_000092_17e20532>
  40c1d5:	lea    rcx,[rsi+0x10]
  40c1d9:	mov    edx,0x400000
  40c1de:	mov    r8,rbx
  40c1e1:	call   409ee0 <__swc_fn_6b1cf01f_000159_9d602c76>
  40c1e6:	lea    rcx,[rsi+0x68]
  40c1ea:	mov    edx,0x4000
  40c1ef:	mov    r8,rbx
  40c1f2:	call   409ee0 <__swc_fn_6b1cf01f_000159_9d602c76>
  40c1f7:	add    rsp,0x28
  40c1fb:	pop    r12
  40c1fd:	pop    rdi
  40c1fe:	pop    rsi
  40c1ff:	pop    rbx
  40c200:	ret
	...

000000000040c210 <__swc_fn_6b1cf01f_000097_8b4a07e9>:
  40c210:	push   rbx
  40c211:	push   rsi
  40c212:	sub    rsp,0x18
  40c216:	mov    rbx,rcx
  40c219:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40c21e:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c224:	mov    rsi,QWORD PTR [rbx+0x70]
  40c228:	lea    rcx,[rcx+0x18]
  40c22c:	call   40d090 <__swc_fn_6b1cf01f_000157_5c8b11d8>
  40c231:	lea    rcx,[rsp+0x8]
  40c236:	mov    rdx,rbx
  40c239:	mov    r8d,0x78
  40c23f:	call   408960 <__swc_fn_6b1cf01f_000096_f879630a>
  40c244:	mov    rax,rsi
  40c247:	add    rsp,0x18
  40c24b:	pop    rsi
  40c24c:	pop    rbx
  40c24d:	ret
	...

000000000040c250 <__swc_fn_6b1cf01f_000100_2ef16a3e>:
  40c250:	push   rsi
  40c251:	push   rdi
  40c252:	sub    rsp,0x8
  40c256:	cmp    QWORD PTR [rcx],0x0
  40c25a:	jne    40c263 <__swc_fn_6b1cf01f_000100_2ef16a3e+0x13>
  40c25c:	add    rsp,0x8
  40c260:	pop    rdi
  40c261:	pop    rsi
  40c262:	ret
  40c263:	mov    rsi,QWORD PTR [rcx]
  40c266:	mov    rax,QWORD PTR [rcx+0x8]
  40c26a:	test   rax,rax
  40c26d:	je     40c283 <__swc_fn_6b1cf01f_000100_2ef16a3e+0x33>
  40c26f:	test   DWORD PTR [rax+0x28],0x400000
  40c276:	je     40c283 <__swc_fn_6b1cf01f_000100_2ef16a3e+0x33>
  40c278:	mov    rcx,QWORD PTR [rax+0x30]
  40c27c:	test   rcx,rcx
  40c27f:	cmovne rax,rcx
  40c283:	lea    rdx,[rip+0x6f46]        # 4131d0 <__swc_rdata_base_6b1cf01f+0xc0>
  40c28a:	lea    rcx,[rip+0x7027]        # 4132b8 <__swc_rdata_base_6b1cf01f+0x1a8>
  40c291:	mov    r8,rax
  40c294:	xor    r9d,r9d
  40c297:	xor    al,al
  40c299:	mov    r10,rax
  40c29c:	xor    r11d,r11d
  40c29f:	call   40c050 <__swc_fn_6b1cf01f_000088_17711411>
  40c2a4:	test   rax,rax
  40c2a7:	je     40c2b7 <__swc_fn_6b1cf01f_000100_2ef16a3e+0x67>
  40c2a9:	mov    rdi,QWORD PTR [rax+0x48]
  40c2ad:	test   rdi,rdi
  40c2b0:	je     40c2b7 <__swc_fn_6b1cf01f_000100_2ef16a3e+0x67>
  40c2b2:	mov    rcx,rsi
  40c2b5:	call   rdi
  40c2b7:	add    rsp,0x8
  40c2bb:	pop    rdi
  40c2bc:	pop    rsi
  40c2bd:	ret
	...

000000000040c2c0 <__swc_fn_6b1cf01f_000103_2ed36338>:
  40c2c0:	push   rbx
  40c2c1:	push   rsi
  40c2c2:	push   rdi
  40c2c3:	sub    rsp,0x20
  40c2c7:	mov    rbx,rdx
  40c2ca:	mov    rsi,rcx
  40c2cd:	mov    rcx,QWORD PTR [rip+0x1aa6c]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40c2d4:	test   rcx,rcx
  40c2d7:	jne    40c2e9 <__swc_fn_6b1cf01f_000103_2ed36338+0x29>
  40c2d9:	call   40a1a0 <__swc_fn_6b1cf01f_000165_e09accff>
  40c2de:	lea    rcx,[rax+0x1]
  40c2e2:	mov    QWORD PTR [rip+0x1aa57],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40c2e9:	dec    rcx
  40c2ec:	call   411680 <__swc_fn_6b1cf01f_000167_3130645d>
  40c2f1:	mov    rdi,rax
  40c2f4:	mov    rax,QWORD PTR [rdi+0xbd0]
  40c2fb:	xor    ecx,ecx
  40c2fd:	test   rax,rax
  40c300:	je     40c305 <__swc_fn_6b1cf01f_000103_2ed36338+0x45>
  40c302:	mov    rcx,QWORD PTR [rax]
  40c305:	call   40a2d0 <__swc_fn_6b1cf01f_000174_738eec22>
  40c30a:	lea    rax,[rsp+0x8]
  40c30f:	lea    rcx,[rdi+0x9c8]
  40c316:	mov    QWORD PTR [rsp+0x8],rcx
  40c31b:	mov    QWORD PTR [rax+0x8],0x40
  40c323:	xor    ecx,ecx
  40c325:	mov    rdx,rax
  40c328:	call   40f9e0 <__swc_fn_6b1cf01f_000119_18cd3882>
  40c32d:	mov    DWORD PTR [rdi+0xbc8],eax
  40c333:	mov    rdi,QWORD PTR [rdi+0x990]
  40c33a:	test   rdi,rdi
  40c33d:	je     40c347 <__swc_fn_6b1cf01f_000103_2ed36338+0x87>
  40c33f:	mov    rcx,rsi
  40c342:	mov    rdx,rbx
  40c345:	call   rdi
  40c347:	call   40c070 <__swc_fn_6b1cf01f_000091_e6773530>
  40c34c:	test   al,al
  40c34e:	je     40c35e <__swc_fn_6b1cf01f_000103_2ed36338+0x9e>
  40c350:	mov    rcx,rsi
  40c353:	mov    rdx,rbx
  40c356:	xor    r8d,r8d
  40c359:	call   4093e0 <__swc_fn_6b1cf01f_000120_1601f378>
  40c35e:	mov    rcx,rsi
  40c361:	mov    rdx,rbx
  40c364:	call   408a60 <__swc_fn_6b1cf01f_000102_29a1093a>
  40c369:	call   40c8f0 <__swc_fn_6b1cf01f_000118_2b35b5e0>
  40c36e:	add    rsp,0x20
  40c372:	pop    rdi
  40c373:	pop    rsi
  40c374:	pop    rbx
  40c375:	ret
	...

000000000040c380 <__swc_fn_6b1cf01f_000106_77a5d54a>:
  40c380:	test   r8,r8
  40c383:	jne    40c388 <__swc_fn_6b1cf01f_000106_77a5d54a+0x8>
  40c385:	xor    eax,eax
  40c387:	ret
  40c388:	xor    eax,eax
  40c38a:	nop    WORD PTR [rax+rax*1+0x0]
  40c390:	mov    r9,r8
  40c393:	sub    r9,rax
  40c396:	cmp    r9,0x10
  40c39a:	jb     40c3e4 <__swc_fn_6b1cf01f_000106_77a5d54a+0x64>
  40c39c:	lea    r9,[rcx+rax*1]
  40c3a0:	lea    r10,[rdx+rax*1]
  40c3a4:	vmovups xmm0,XMMWORD PTR [r10]
  40c3a9:	vmovups xmm1,XMMWORD PTR [r9]
  40c3ae:	vpcmpeqb xmm0,xmm1,xmm0
  40c3b2:	vpmovmskb r9d,xmm0
  40c3b6:	cmp    r9d,0xffff
  40c3bd:	je     40c3de <__swc_fn_6b1cf01f_000106_77a5d54a+0x5e>
  40c3bf:	not    r9d
  40c3c2:	xor    r8d,r8d
  40c3c5:	movzx  r9d,r9w
  40c3c9:	tzcnt  r8d,r9d
  40c3ce:	add    rax,r8
  40c3d1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c3d5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c3d9:	sub    ecx,eax
  40c3db:	mov    eax,ecx
  40c3dd:	ret
  40c3de:	lea    rax,[rax+0x10]
  40c3e2:	jmp    40c390 <__swc_fn_6b1cf01f_000106_77a5d54a+0x10>
  40c3e4:	cmp    r9,0x8
  40c3e8:	jb     40c45b <__swc_fn_6b1cf01f_000106_77a5d54a+0xdb>
  40c3ea:	lea    r9,[rcx+rax*1]
  40c3ee:	lea    r10,[rdx+rax*1]
  40c3f2:	mov    r9,QWORD PTR [r9]
  40c3f5:	xor    r9,QWORD PTR [r10]
  40c3f8:	test   r9,r9
  40c3fb:	je     40c419 <__swc_fn_6b1cf01f_000106_77a5d54a+0x99>
  40c3fd:	xor    r8d,r8d
  40c400:	tzcnt  r8,r9
  40c405:	shr    r8,0x3
  40c409:	add    rax,r8
  40c40c:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c410:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c414:	sub    ecx,eax
  40c416:	mov    eax,ecx
  40c418:	ret
  40c419:	lea    rax,[rax+0x8]
  40c41d:	cmp    rax,r8
  40c420:	jne    40c425 <__swc_fn_6b1cf01f_000106_77a5d54a+0xa5>
  40c422:	xor    eax,eax
  40c424:	ret
  40c425:	lea    rax,[r8-0x8]
  40c429:	lea    r8,[rcx+rax*1]
  40c42d:	lea    r9,[rdx+rax*1]
  40c431:	mov    r8,QWORD PTR [r8]
  40c434:	xor    r8,QWORD PTR [r9]
  40c437:	test   r8,r8
  40c43a:	je     40c458 <__swc_fn_6b1cf01f_000106_77a5d54a+0xd8>
  40c43c:	xor    r9d,r9d
  40c43f:	tzcnt  r9,r8
  40c444:	shr    r9,0x3
  40c448:	add    rax,r9
  40c44b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c44f:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c453:	sub    ecx,eax
  40c455:	mov    eax,ecx
  40c457:	ret
  40c458:	xor    eax,eax
  40c45a:	ret
  40c45b:	cmp    r9,0x4
  40c45f:	jb     40c4d2 <__swc_fn_6b1cf01f_000106_77a5d54a+0x152>
  40c461:	lea    r9,[rcx+rax*1]
  40c465:	lea    r10,[rdx+rax*1]
  40c469:	mov    r9d,DWORD PTR [r9]
  40c46c:	xor    r9d,DWORD PTR [r10]
  40c46f:	test   r9d,r9d
  40c472:	je     40c490 <__swc_fn_6b1cf01f_000106_77a5d54a+0x110>
  40c474:	xor    r8d,r8d
  40c477:	tzcnt  r8,r9
  40c47c:	shr    r8,0x3
  40c480:	add    rax,r8
  40c483:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c487:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c48b:	sub    ecx,eax
  40c48d:	mov    eax,ecx
  40c48f:	ret
  40c490:	lea    rax,[rax+0x4]
  40c494:	cmp    rax,r8
  40c497:	jne    40c49c <__swc_fn_6b1cf01f_000106_77a5d54a+0x11c>
  40c499:	xor    eax,eax
  40c49b:	ret
  40c49c:	lea    rax,[r8-0x4]
  40c4a0:	lea    r8,[rcx+rax*1]
  40c4a4:	lea    r9,[rdx+rax*1]
  40c4a8:	mov    r8d,DWORD PTR [r8]
  40c4ab:	xor    r8d,DWORD PTR [r9]
  40c4ae:	test   r8d,r8d
  40c4b1:	je     40c4cf <__swc_fn_6b1cf01f_000106_77a5d54a+0x14f>
  40c4b3:	xor    r9d,r9d
  40c4b6:	tzcnt  r9,r8
  40c4bb:	shr    r9,0x3
  40c4bf:	add    rax,r9
  40c4c2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4c6:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4ca:	sub    ecx,eax
  40c4cc:	mov    eax,ecx
  40c4ce:	ret
  40c4cf:	xor    eax,eax
  40c4d1:	ret
  40c4d2:	cmp    r9,0x2
  40c4d6:	jb     40c529 <__swc_fn_6b1cf01f_000106_77a5d54a+0x1a9>
  40c4d8:	lea    r9,[rcx+rax*1]
  40c4dc:	lea    r10,[rdx+rax*1]
  40c4e0:	mov    r9w,WORD PTR [r9]
  40c4e4:	xor    r9w,WORD PTR [r10]
  40c4e8:	test   r9w,r9w
  40c4ec:	je     40c50e <__swc_fn_6b1cf01f_000106_77a5d54a+0x18e>
  40c4ee:	xor    r8d,r8d
  40c4f1:	movzx  r9d,r9w
  40c4f5:	tzcnt  r8,r9
  40c4fa:	shr    r8,0x3
  40c4fe:	add    rax,r8
  40c501:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c505:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c509:	sub    ecx,eax
  40c50b:	mov    eax,ecx
  40c50d:	ret
  40c50e:	lea    rax,[rax+0x2]
  40c512:	cmp    rax,r8
  40c515:	jne    40c51a <__swc_fn_6b1cf01f_000106_77a5d54a+0x19a>
  40c517:	xor    eax,eax
  40c519:	ret
  40c51a:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40c520:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40c526:	sub    eax,ecx
  40c528:	ret
  40c529:	test   r9,r9
  40c52c:	je     40c53b <__swc_fn_6b1cf01f_000106_77a5d54a+0x1bb>
  40c52e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c532:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c536:	sub    ecx,eax
  40c538:	mov    eax,ecx
  40c53a:	ret
  40c53b:	xor    eax,eax
  40c53d:	ret
	...

000000000040c540 <__swc_fn_6b1cf01f_000109_aa570b2b>:
  40c540:	push   r12
  40c542:	push   r13
  40c544:	push   r14
  40c546:	push   rdi
  40c547:	push   rsi
  40c548:	push   r15
  40c54a:	sub    rsp,0xd8
  40c551:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c557:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c55d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c563:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c569:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c56f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c578:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c581:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c58a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c593:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c59c:	mov    r12,rcx
  40c59f:	test   rcx,rcx
  40c5a2:	je     40c5be <__swc_fn_6b1cf01f_000109_aa570b2b+0x7e>
  40c5a4:	mov    eax,r12d
  40c5a7:	and    eax,0xfff
  40c5ad:	setne  al
  40c5b0:	cmp    r12,0xffffffffffffefff
  40c5b7:	seta   cl
  40c5ba:	or     al,cl
  40c5bc:	je     40c5c5 <__swc_fn_6b1cf01f_000109_aa570b2b+0x85>
  40c5be:	xor    eax,eax
  40c5c0:	jmp    40c65b <__swc_fn_6b1cf01f_000109_aa570b2b+0x11b>
  40c5c5:	call   409100 <__swc_fn_6b1cf01f_000108_32416b9e>
  40c5ca:	mov    r13,rax
  40c5cd:	test   rax,rax
  40c5d0:	jne    40c5d9 <__swc_fn_6b1cf01f_000109_aa570b2b+0x99>
  40c5d2:	xor    eax,eax
  40c5d4:	jmp    40c65b <__swc_fn_6b1cf01f_000109_aa570b2b+0x11b>
  40c5d9:	lea    r14,[r12+0x1000]
  40c5e1:	xor    edi,edi
  40c5e3:	mov    rsi,r14
  40c5e6:	xor    edx,edx
  40c5e8:	mov    ecx,0x22
  40c5ed:	mov    eax,0xffffffff
  40c5f2:	movsxd r8,eax
  40c5f5:	xor    r9d,r9d
  40c5f8:	xor    eax,eax
  40c5fa:	call   4070c0 <mmap@plt>
  40c5ff:	mov    r15,rax
  40c602:	cmp    rax,0xffffffffffffffff
  40c606:	jne    40c60c <__swc_fn_6b1cf01f_000109_aa570b2b+0xcc>
  40c608:	xor    eax,eax
  40c60a:	jmp    40c65b <__swc_fn_6b1cf01f_000109_aa570b2b+0x11b>
  40c60c:	mov    rdi,r15
  40c60f:	mov    esi,0x1000
  40c614:	mov    edx,0x3
  40c619:	xor    eax,eax
  40c61b:	call   407030 <mprotect@plt>
  40c620:	test   eax,eax
  40c622:	je     40c635 <__swc_fn_6b1cf01f_000109_aa570b2b+0xf5>
  40c624:	mov    rdi,r15
  40c627:	mov    rsi,r14
  40c62a:	xor    eax,eax
  40c62c:	call   407020 <munmap@plt>
  40c631:	xor    eax,eax
  40c633:	jmp    40c65b <__swc_fn_6b1cf01f_000109_aa570b2b+0x11b>
  40c635:	mov    QWORD PTR [r15+0x8],r12
  40c639:	mov    rcx,r13
  40c63c:	call   40cc90 <__swc_fn_6b1cf01f_000133_c6de0049>
  40c641:	mov    rax,QWORD PTR [r13+0x8]
  40c645:	mov    QWORD PTR [r15],rax
  40c648:	mov    QWORD PTR [r13+0x8],r15
  40c64c:	mov    rcx,r13
  40c64f:	call   40fd80 <__swc_fn_6b1cf01f_000134_5696c87e>
  40c654:	lea    rax,[r15+0x1000]
  40c65b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c661:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c667:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c66d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c673:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c679:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c682:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c68b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c694:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c69d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c6a6:	add    rsp,0xd8
  40c6ad:	pop    r15
  40c6af:	pop    rsi
  40c6b0:	pop    rdi
  40c6b1:	pop    r14
  40c6b3:	pop    r13
  40c6b5:	pop    r12
  40c6b7:	ret
	...

000000000040c6c0 <__swc_fn_6b1cf01f_000112_cb2656be>:
  40c6c0:	push   rbx
  40c6c1:	push   r12
  40c6c3:	push   rdi
  40c6c4:	push   rsi
  40c6c5:	sub    rsp,0xa8
  40c6cc:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c6d2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c6d8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c6de:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c6e4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c6ea:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c6f0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40c6f6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40c6fc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40c705:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40c70e:	mov    rbx,rdx
  40c711:	mov    r12,rcx
  40c714:	mov    rdi,rcx
  40c717:	mov    rsi,rdx
  40c71a:	xor    edx,edx
  40c71c:	xor    eax,eax
  40c71e:	call   407030 <mprotect@plt>
  40c723:	test   eax,eax
  40c725:	jne    40c749 <__swc_fn_6b1cf01f_000112_cb2656be+0x89>
  40c727:	mov    rcx,r12
  40c72a:	mov    rdx,rbx
  40c72d:	xor    al,al
  40c72f:	mov    r8,rax
  40c732:	call   40f820 <__swc_fn_6b1cf01f_000110_e606239a>
  40c737:	mov    rdi,r12
  40c73a:	mov    rsi,rbx
  40c73d:	mov    edx,0x4
  40c742:	xor    eax,eax
  40c744:	call   4070e0 <madvise@plt>
  40c749:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40c74f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40c755:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40c75b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40c761:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40c767:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40c76d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40c773:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40c779:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40c782:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40c78b:	add    rsp,0xa8
  40c792:	pop    rsi
  40c793:	pop    rdi
  40c794:	pop    r12
  40c796:	pop    rbx
  40c797:	ret
	...

000000000040c7a0 <__swc_fn_6b1cf01f_000115_259b5d5a>:
  40c7a0:	push   rsi
  40c7a1:	push   rdi
  40c7a2:	push   r12
  40c7a4:	push   r13
  40c7a6:	push   r14
  40c7a8:	sub    rsp,0xe0
  40c7af:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c7b5:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c7bb:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c7c1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c7c7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c7cd:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c7d6:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c7df:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c7e8:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c7f1:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c7fa:	mov    rsi,rdx
  40c7fd:	mov    rdi,rcx
  40c800:	call   409100 <__swc_fn_6b1cf01f_000108_32416b9e>
  40c805:	mov    r12,rax
  40c808:	test   rax,rax
  40c80b:	jne    40c812 <__swc_fn_6b1cf01f_000115_259b5d5a+0x72>
  40c80d:	jmp    40c886 <__swc_fn_6b1cf01f_000115_259b5d5a+0xe6>
  40c812:	mov    rcx,r12
  40c815:	call   40cc90 <__swc_fn_6b1cf01f_000133_c6de0049>
  40c81a:	lea    r13,[r12+0x8]
  40c81f:	mov    rax,QWORD PTR [r13+0x0]
  40c823:	test   rax,rax
  40c826:	je     40c87e <__swc_fn_6b1cf01f_000115_259b5d5a+0xde>
  40c828:	nop    DWORD PTR [rax+rax*1+0x0]
  40c830:	lea    rcx,[rax+0x1000]
  40c837:	cmp    rcx,rdi
  40c83a:	jne    40c872 <__swc_fn_6b1cf01f_000115_259b5d5a+0xd2>
  40c83c:	cmp    QWORD PTR [rax+0x8],rsi
  40c840:	je     40c84c <__swc_fn_6b1cf01f_000115_259b5d5a+0xac>
  40c842:	mov    rcx,r12
  40c845:	call   40fd80 <__swc_fn_6b1cf01f_000134_5696c87e>
  40c84a:	jmp    40c886 <__swc_fn_6b1cf01f_000115_259b5d5a+0xe6>
  40c84c:	mov    r14,QWORD PTR [rax]
  40c84f:	mov    rdi,rax
  40c852:	lea    rsi,[rsi+0x1000]
  40c859:	xor    eax,eax
  40c85b:	call   407020 <munmap@plt>
  40c860:	test   eax,eax
  40c862:	jne    40c868 <__swc_fn_6b1cf01f_000115_259b5d5a+0xc8>
  40c864:	mov    QWORD PTR [r13+0x0],r14
  40c868:	mov    rcx,r12
  40c86b:	call   40fd80 <__swc_fn_6b1cf01f_000134_5696c87e>
  40c870:	jmp    40c886 <__swc_fn_6b1cf01f_000115_259b5d5a+0xe6>
  40c872:	mov    r13,rax
  40c875:	mov    rax,QWORD PTR [r13+0x0]
  40c879:	test   rax,rax
  40c87c:	jne    40c830 <__swc_fn_6b1cf01f_000115_259b5d5a+0x90>
  40c87e:	mov    rcx,r12
  40c881:	call   40fd80 <__swc_fn_6b1cf01f_000134_5696c87e>
  40c886:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c88c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c892:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c898:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c89e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c8a4:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c8ad:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c8b6:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c8bf:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c8c8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c8d1:	add    rsp,0xe0
  40c8d8:	pop    r14
  40c8da:	pop    r13
  40c8dc:	pop    r12
  40c8de:	pop    rdi
  40c8df:	pop    rsi
  40c8e0:	ret
	...

000000000040c8f0 <__swc_fn_6b1cf01f_000118_2b35b5e0>:
  40c8f0:	push   rdi
  40c8f1:	push   rsi
  40c8f2:	sub    rsp,0xa8
  40c8f9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c8ff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c905:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c90b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c911:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c917:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c91d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40c923:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40c929:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40c932:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40c93b:	mov    rdi,0xfffffffffffffd66
  40c942:	xor    eax,eax
  40c944:	call   407040 <exit@plt>
  40c949:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40c94f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40c955:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40c95b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40c961:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40c967:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40c96d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40c973:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40c979:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40c982:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40c98b:	add    rsp,0xa8
  40c992:	pop    rsi
  40c993:	pop    rdi
  40c994:	ret
	...

000000000040c9a0 <__swc_fn_6b1cf01f_000121_71a5b1cd>:
  40c9a0:	push   rbx
  40c9a1:	push   rsi
  40c9a2:	push   rdi
  40c9a3:	sub    rsp,0x30
  40c9a7:	mov    rbx,rdx
  40c9aa:	mov    esi,ecx
  40c9ac:	test   ecx,ecx
  40c9ae:	je     40ca83 <__swc_fn_6b1cf01f_000121_71a5b1cd+0xe3>
  40c9b4:	mov    rcx,rsi
  40c9b7:	shl    rcx,0x4
  40c9bb:	call   40beb0 <__swc_fn_6b1cf01f_000079_29fad089>
  40c9c0:	test   rax,rax
  40c9c3:	je     40ca72 <__swc_fn_6b1cf01f_000121_71a5b1cd+0xd2>
  40c9c9:	mov    rcx,rsi
  40c9cc:	xor    edx,edx
  40c9ce:	test   rsi,rsi
  40c9d1:	jbe    40ca52 <__swc_fn_6b1cf01f_000121_71a5b1cd+0xb2>
  40c9d7:	nop    WORD PTR [rax+rax*1+0x0]
  40c9e0:	mov    r8d,edx
  40c9e3:	mov    r9,QWORD PTR [rbx+r8*8]
  40c9e7:	add    r8,r8
  40c9ea:	lea    r8,[rax+r8*8]
  40c9ee:	xor    r10d,r10d
  40c9f1:	test   r9,r9
  40c9f4:	je     40ca30 <__swc_fn_6b1cf01f_000121_71a5b1cd+0x90>
  40c9f6:	mov    r11,r9
  40c9f9:	mov    dil,BYTE PTR [r11]
  40c9fc:	test   dil,dil
  40c9ff:	je     40ca30 <__swc_fn_6b1cf01f_000121_71a5b1cd+0x90>
  40ca01:	cs nop WORD PTR [rax+rax*1+0x0]
  40ca0b:	cs nop WORD PTR [rax+rax*1+0x0]
  40ca15:	cs nop WORD PTR [rax+rax*1+0x0]
  40ca1f:	nop
  40ca20:	add    r11,0x1
  40ca24:	add    r10,0x1
  40ca28:	mov    dil,BYTE PTR [r11]
  40ca2b:	test   dil,dil
  40ca2e:	jne    40ca20 <__swc_fn_6b1cf01f_000121_71a5b1cd+0x80>
  40ca30:	mov    QWORD PTR [rsp+0x18],r9
  40ca35:	mov    QWORD PTR [rsp+0x20],r10
  40ca3a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40ca40:	vmovups XMMWORD PTR [r8],xmm0
  40ca45:	add    rdx,0x1
  40ca49:	cmp    rdx,rcx
  40ca4c:	jb     40c9e0 <__swc_fn_6b1cf01f_000121_71a5b1cd+0x40>
  40ca52:	lea    rcx,[rip+0x1a2f7]        # 426d50 <__swc_bss_base_6b1cf01f+0x2d10>
  40ca59:	mov    QWORD PTR [rsp+0x8],rax
  40ca5e:	mov    esi,esi
  40ca60:	mov    QWORD PTR [rsp+0x10],rsi
  40ca65:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ca6b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40ca70:	jmp    40ca83 <__swc_fn_6b1cf01f_000121_71a5b1cd+0xe3>
  40ca72:	lea    rcx,[rip+0x6aa7]        # 413520 <__swc_rdata_base_6b1cf01f+0x410>
  40ca79:	call   40f8d0 <__swc_fn_6b1cf01f_000116_3499f7d6>
  40ca7e:	call   40c8f0 <__swc_fn_6b1cf01f_000118_2b35b5e0>
  40ca83:	add    rsp,0x30
  40ca87:	pop    rdi
  40ca88:	pop    rsi
  40ca89:	pop    rbx
  40ca8a:	ret
  40ca8b:	add    BYTE PTR [rax],al
  40ca8d:	add    BYTE PTR [rax],al
	...

000000000040ca90 <__swc_fn_6b1cf01f_000124_df97aa0a>:
  40ca90:	push   rdi
  40ca91:	push   rsi
  40ca92:	sub    rsp,0xa8
  40ca99:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ca9f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40caa5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40caab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cab1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cab7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cabd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cac3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cac9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cad2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cadb:	mov    edi,ecx
  40cadd:	xor    eax,eax
  40cadf:	call   4070f0 <pthread_key_delete@plt>
  40cae4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40caea:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40caf0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40caf6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cafc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cb02:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cb08:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cb0e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cb14:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cb1d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cb26:	add    rsp,0xa8
  40cb2d:	pop    rsi
  40cb2e:	pop    rdi
  40cb2f:	ret

000000000040cb30 <__swc_fn_6b1cf01f_000127_75f8ab5c>:
  40cb30:	push   rdi
  40cb31:	push   rsi
  40cb32:	sub    rsp,0xa8
  40cb39:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cb3f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cb45:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cb4b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cb51:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cb57:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cb5d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cb63:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cb69:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cb72:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cb7b:	test   rcx,rcx
  40cb7e:	je     40cb8f <__swc_fn_6b1cf01f_000127_75f8ab5c+0x5f>
  40cb80:	lea    rax,[rcx-0x1]
  40cb84:	mov    eax,eax
  40cb86:	mov    edi,eax
  40cb88:	xor    eax,eax
  40cb8a:	call   4070f0 <pthread_key_delete@plt>
  40cb8f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cb95:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cb9b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cba1:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cba7:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cbad:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cbb3:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cbb9:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cbbf:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cbc8:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cbd1:	add    rsp,0xa8
  40cbd8:	pop    rsi
  40cbd9:	pop    rdi
  40cbda:	ret
  40cbdb:	add    BYTE PTR [rax],al
  40cbdd:	add    BYTE PTR [rax],al
	...

000000000040cbe0 <__swc_fn_6b1cf01f_000130_d2d78689>:
  40cbe0:	push   rsi
  40cbe1:	push   rdi
  40cbe2:	sub    rsp,0xa8
  40cbe9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cbef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cbf5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cbfb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cc01:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cc07:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cc0d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cc13:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cc19:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cc22:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cc2b:	xor    eax,eax
  40cc2d:	call   407100 <gettid@plt>
  40cc32:	movsxd rax,eax
  40cc35:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cc3b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cc41:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cc47:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cc4d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cc53:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cc59:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cc5f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cc65:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cc6e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cc77:	add    rsp,0xa8
  40cc7e:	pop    rdi
  40cc7f:	pop    rsi
  40cc80:	ret
	...

000000000040cc90 <__swc_fn_6b1cf01f_000133_c6de0049>:
  40cc90:	push   rbx
  40cc91:	push   rdi
  40cc92:	push   rsi
  40cc93:	sub    rsp,0xc0
  40cc9a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40cca0:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40cca6:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40ccac:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40ccb2:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40ccb8:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40ccbe:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40ccc4:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40cccd:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40ccd6:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40ccdf:	mov    rbx,rcx
  40cce2:	cs nop WORD PTR [rax+rax*1+0x0]
  40ccec:	nop    DWORD PTR [rax+0x0]
  40ccf0:	mov    edx,0x80000000
  40ccf5:	xor    eax,eax
  40ccf7:	lock cmpxchg DWORD PTR [rbx],edx
  40ccfb:	test   eax,eax
  40ccfd:	je     40cd34 <__swc_fn_6b1cf01f_000133_c6de0049+0xa4>
  40ccff:	mov    eax,DWORD PTR [rbx]
  40cd01:	lea    rcx,[rsp+0x14]
  40cd06:	mov    DWORD PTR [rsp+0x14],eax
  40cd0a:	test   eax,eax
  40cd0c:	je     40ccf0 <__swc_fn_6b1cf01f_000133_c6de0049+0x60>
  40cd0e:	mov    QWORD PTR [rsp],0x0
  40cd16:	mov    edi,0xca
  40cd1b:	mov    rsi,rbx
  40cd1e:	mov    edx,0x80
  40cd23:	mov    ecx,DWORD PTR [rcx]
  40cd25:	xor    r8d,r8d
  40cd28:	xor    r9d,r9d
  40cd2b:	xor    eax,eax
  40cd2d:	call   407070 <syscall@plt>
  40cd32:	jmp    40ccf0 <__swc_fn_6b1cf01f_000133_c6de0049+0x60>
  40cd34:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40cd3a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40cd40:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40cd46:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40cd4c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40cd52:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40cd58:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40cd5e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40cd67:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40cd70:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40cd79:	add    rsp,0xc0
  40cd80:	pop    rsi
  40cd81:	pop    rdi
  40cd82:	pop    rbx
  40cd83:	ret
	...

000000000040cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>:
  40cd90:	sub    rsp,0x8
  40cd94:	call   40fd80 <__swc_fn_6b1cf01f_000134_5696c87e>
  40cd99:	add    rsp,0x8
  40cd9d:	ret
	...

000000000040cda0 <__swc_fn_6b1cf01f_000139_20e2e2c7>:
  40cda0:	push   rdi
  40cda1:	push   rsi
  40cda2:	sub    rsp,0xa8
  40cda9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cdaf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cdb5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cdbb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cdc1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cdc7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cdcd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cdd3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cdd9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cde2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cdeb:	mov    edi,0x28
  40cdf0:	xor    eax,eax
  40cdf2:	call   4070d0 <malloc@plt>
  40cdf7:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cdfd:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ce03:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ce09:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ce0f:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ce15:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ce1b:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ce21:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ce27:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ce30:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ce39:	add    rsp,0xa8
  40ce40:	pop    rsi
  40ce41:	pop    rdi
  40ce42:	ret
	...

000000000040ce50 <__swc_fn_6b1cf01f_000142_e0543f36>:
  40ce50:	mov    QWORD PTR [r8],0x0
  40ce57:	cmp    rdx,0x10
  40ce5b:	jae    40ce60 <__swc_fn_6b1cf01f_000142_e0543f36+0x10>
  40ce5d:	xor    eax,eax
  40ce5f:	ret
  40ce60:	mov    eax,DWORD PTR [rcx]
  40ce62:	cmp    eax,0x42445753
  40ce68:	jne    40ce72 <__swc_fn_6b1cf01f_000142_e0543f36+0x22>
  40ce6a:	mov    eax,DWORD PTR [rcx+0x4]
  40ce6d:	cmp    eax,0x1
  40ce70:	je     40ce75 <__swc_fn_6b1cf01f_000142_e0543f36+0x25>
  40ce72:	xor    eax,eax
  40ce74:	ret
  40ce75:	mov    QWORD PTR [r8],rdx
  40ce78:	mov    rax,rcx
  40ce7b:	ret
  40ce7c:	add    BYTE PTR [rax],al
	...

000000000040ce80 <__swc_fn_6b1cf01f_000145_071b4f4c>:
  40ce80:	push   rbx
  40ce81:	sub    rsp,0xe0
  40ce88:	lea    rbx,[rsp+0x8]
  40ce8d:	vxorps xmm0,xmm0,xmm0
  40ce91:	vmovups YMMWORD PTR [rbx],ymm0
  40ce95:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40ce9a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40ce9f:	vzeroupper
  40cea2:	mov    DWORD PTR [rbx+0x60],0x0
  40cea9:	mov    r8,rbx
  40ceac:	mov    rdx,rcx
  40ceaf:	nop
  40ceb0:	mov    r9,rdx
  40ceb3:	movabs rdx,0x6666666666666667
  40cebd:	mov    rax,r9
  40cec0:	imul   rdx
  40cec3:	sar    rdx,0x2
  40cec7:	mov    r10,rdx
  40ceca:	shr    rdx,0x3f
  40cece:	add    r10,rdx
  40ced1:	mov    rdx,r10
  40ced4:	imul   r11,r10,0xa
  40ced8:	sub    r9,r11
  40cedb:	mov    r11,QWORD PTR [rip+0x665e]        # 413540 <__swc_rdata_base_6b1cf01f+0x430>
  40cee2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40cee7:	mov    BYTE PTR [r8],r9b
  40ceea:	lea    r9,[r8+0x1]
  40ceee:	mov    r8,r9
  40cef1:	test   r10,r10
  40cef4:	jne    40ceb0 <__swc_fn_6b1cf01f_000145_071b4f4c+0x30>
  40cef6:	test   rcx,rcx
  40cef9:	jge    40cf03 <__swc_fn_6b1cf01f_000145_071b4f4c+0x83>
  40cefb:	mov    BYTE PTR [r9],0x2d
  40ceff:	add    r8,0x1
  40cf03:	mov    BYTE PTR [r8],0x0
  40cf07:	sub    r8,0x1
  40cf0b:	mov    rax,rbx
  40cf0e:	cmp    rax,r8
  40cf11:	jae    40cf36 <__swc_fn_6b1cf01f_000145_071b4f4c+0xb6>
  40cf13:	cs nop WORD PTR [rax+rax*1+0x0]
  40cf1d:	nop    DWORD PTR [rax]
  40cf20:	mov    cl,BYTE PTR [r8]
  40cf23:	mov    dl,BYTE PTR [rax]
  40cf25:	mov    BYTE PTR [r8],dl
  40cf28:	sub    r8,0x1
  40cf2c:	mov    BYTE PTR [rax],cl
  40cf2e:	inc    rax
  40cf31:	cmp    rax,r8
  40cf34:	jb     40cf20 <__swc_fn_6b1cf01f_000145_071b4f4c+0xa0>
  40cf36:	xor    eax,eax
  40cf38:	test   rbx,rbx
  40cf3b:	je     40cf5e <__swc_fn_6b1cf01f_000145_071b4f4c+0xde>
  40cf3d:	mov    rcx,rbx
  40cf40:	mov    dl,BYTE PTR [rcx]
  40cf42:	test   dl,dl
  40cf44:	je     40cf5e <__swc_fn_6b1cf01f_000145_071b4f4c+0xde>
  40cf46:	cs nop WORD PTR [rax+rax*1+0x0]
  40cf50:	add    rcx,0x1
  40cf54:	add    rax,0x1
  40cf58:	mov    dl,BYTE PTR [rcx]
  40cf5a:	test   dl,dl
  40cf5c:	jne    40cf50 <__swc_fn_6b1cf01f_000145_071b4f4c+0xd0>
  40cf5e:	mov    QWORD PTR [rbx+0xa8],rbx
  40cf65:	mov    QWORD PTR [rbx+0xb0],rax
  40cf6c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40cf74:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40cf7c:	lea    rcx,[rbx+0xb8]
  40cf83:	call   40f8d0 <__swc_fn_6b1cf01f_000116_3499f7d6>
  40cf88:	add    rsp,0xe0
  40cf8f:	pop    rbx
  40cf90:	ret
	...

000000000040cfa0 <__swc_fn_6b1cf01f_000148_33e5e24f>:
  40cfa0:	vxorps xmm0,xmm0,xmm0
  40cfa4:	vmovups XMMWORD PTR [rcx],xmm0
  40cfa8:	mov    QWORD PTR [rcx+0x10],0x0
  40cfb0:	ret
	...

000000000040cfc0 <__swc_fn_6b1cf01f_000151_33e5e24f>:
  40cfc0:	vxorps xmm0,xmm0,xmm0
  40cfc4:	vmovups XMMWORD PTR [rcx],xmm0
  40cfc8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40cfcd:	vxorps xmm0,xmm0,xmm0
  40cfd1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40cfd6:	vmovups xmm0,XMMWORD PTR [rip+0x665a]        # 413638 <__swc_rdata_base_6b1cf01f+0x528>
  40cfde:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40cfe3:	vxorps xmm0,xmm0,xmm0
  40cfe7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40cfec:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40cff1:	mov    QWORD PTR [rcx+0x60],0x0
  40cff9:	ret
  40cffa:	add    BYTE PTR [rax],al
  40cffc:	add    BYTE PTR [rax],al
	...

000000000040d000 <__swc_fn_6b1cf01f_000154_33e5e24f>:
  40d000:	vxorps xmm0,xmm0,xmm0
  40d004:	vmovups XMMWORD PTR [rcx],xmm0
  40d008:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d00d:	vxorps xmm0,xmm0,xmm0
  40d011:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d016:	vmovups xmm0,XMMWORD PTR [rip+0x6742]        # 413760 <__swc_rdata_base_6b1cf01f+0x650>
  40d01e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d023:	vxorps xmm0,xmm0,xmm0
  40d027:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d02c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d031:	vxorps xmm0,xmm0,xmm0
  40d035:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40d03a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40d03f:	vxorps xmm0,xmm0,xmm0
  40d043:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40d04b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40d053:	vxorps xmm0,xmm0,xmm0
  40d057:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40d05f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40d067:	vxorps xmm0,xmm0,xmm0
  40d06b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40d073:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40d07b:	mov    QWORD PTR [rcx+0xe0],0x0
  40d086:	ret
	...

000000000040d090 <__swc_fn_6b1cf01f_000157_5c8b11d8>:
  40d090:	push   rbx
  40d091:	mov    rbx,rcx
  40d094:	call   411310 <__swc_fn_6b1cf01f_000158_6741c23b>
  40d099:	mov    rax,QWORD PTR [rbx+0x10]
  40d09d:	test   rax,rax
  40d0a0:	je     40d0b1 <__swc_fn_6b1cf01f_000157_5c8b11d8+0x21>
  40d0a2:	mov    rcx,rbx
  40d0a5:	mov    rdx,rax
  40d0a8:	mov    r8,QWORD PTR [rbx+0x18]
  40d0ac:	call   409e90 <__swc_fn_6b1cf01f_000156_312df05a>
  40d0b1:	vxorps xmm0,xmm0,xmm0
  40d0b5:	vmovups XMMWORD PTR [rbx],xmm0
  40d0b9:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d0be:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d0c3:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d0c8:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d0cd:	mov    QWORD PTR [rbx+0x50],0x0
  40d0d5:	pop    rbx
  40d0d6:	ret
	...

000000000040d0e0 <__swc_fn_6b1cf01f_000160_e25d06b9>:
  40d0e0:	sub    rsp,0x10
  40d0e4:	mov    eax,r8d
  40d0e7:	mov    r8d,r9d
  40d0ea:	test   r9d,r9d
  40d0ed:	jne    40d106 <__swc_fn_6b1cf01f_000160_e25d06b9+0x26>
  40d0ef:	vmovups xmm0,XMMWORD PTR [rip+0x6721]        # 413818 <__swc_rdata_base_6b1cf01f+0x708>
  40d0f7:	vmovups XMMWORD PTR [r10],xmm0
  40d0fc:	mov    eax,0x1
  40d101:	add    rsp,0x10
  40d105:	ret
  40d106:	mov    r9,r8
  40d109:	cmp    r8,rax
  40d10c:	jb     40d113 <__swc_fn_6b1cf01f_000160_e25d06b9+0x33>
  40d10e:	cmp    r9,rdx
  40d111:	jb     40d11a <__swc_fn_6b1cf01f_000160_e25d06b9+0x3a>
  40d113:	xor    eax,eax
  40d115:	add    rsp,0x10
  40d119:	ret
  40d11a:	xor    eax,eax
  40d11c:	lea    r8,[r9+rax*1]
  40d120:	cmp    r8,rdx
  40d123:	jae    40d153 <__swc_fn_6b1cf01f_000160_e25d06b9+0x73>
  40d125:	cs nop WORD PTR [rax+rax*1+0x0]
  40d12f:	cs nop WORD PTR [rax+rax*1+0x0]
  40d139:	nop    DWORD PTR [rax+0x0]
  40d140:	cmp    BYTE PTR [rcx+r8*1],0x0
  40d145:	je     40d153 <__swc_fn_6b1cf01f_000160_e25d06b9+0x73>
  40d147:	inc    rax
  40d14a:	lea    r8,[r9+rax*1]
  40d14e:	cmp    r8,rdx
  40d151:	jb     40d140 <__swc_fn_6b1cf01f_000160_e25d06b9+0x60>
  40d153:	cmp    r8,rdx
  40d156:	jne    40d15f <__swc_fn_6b1cf01f_000160_e25d06b9+0x7f>
  40d158:	xor    eax,eax
  40d15a:	add    rsp,0x10
  40d15e:	ret
  40d15f:	add    rcx,r9
  40d162:	mov    QWORD PTR [rsp],rcx
  40d166:	mov    QWORD PTR [rsp+0x8],rax
  40d16b:	vmovups xmm0,XMMWORD PTR [rsp]
  40d170:	vmovups XMMWORD PTR [r10],xmm0
  40d175:	mov    eax,0x1
  40d17a:	add    rsp,0x10
  40d17e:	ret
	...

000000000040d180 <__swc_fn_6b1cf01f_000163_5fbed98a>:
  40d180:	push   rbp
  40d181:	push   rbx
  40d182:	push   rsi
  40d183:	push   rdi
  40d184:	push   r12
  40d186:	push   r13
  40d188:	push   r14
  40d18a:	push   r15
  40d18c:	sub    rsp,0x10
  40d190:	mov    rbp,rsp
  40d193:	vmovups XMMWORD PTR [rsp],xmm6
  40d198:	sub    rsp,0x50
  40d19c:	mov    rbx,rsp
  40d19f:	mov    rsi,r8
  40d1a2:	mov    QWORD PTR [rsp+0x30],r8
  40d1a7:	mov    rdi,rcx
  40d1aa:	mov    QWORD PTR [rsp+0x38],rcx
  40d1af:	mov    r12,rdx
  40d1b2:	xor    r13b,r13b
  40d1b5:	mov    r14,QWORD PTR [rdi+0x8]
  40d1b9:	mov    QWORD PTR [rsp+0x40],r14
  40d1be:	xor    r15d,r15d
  40d1c1:	test   r14,r14
  40d1c4:	jbe    40d41e <__swc_fn_6b1cf01f_000163_5fbed98a+0x29e>
  40d1ca:	mov    r14,QWORD PTR [rdi]
  40d1cd:	mov    rax,QWORD PTR [rsp+0x40]
  40d1d2:	mov    QWORD PTR [rsp+0x48],r14
  40d1d7:	vmovups xmm6,XMMWORD PTR [rip+0x6259]        # 413438 <__swc_rdata_base_6b1cf01f+0x328>
  40d1df:	nop
  40d1e0:	cmp    QWORD PTR [r14+r15*8],0x0
  40d1e5:	jne    40d1ef <__swc_fn_6b1cf01f_000163_5fbed98a+0x6f>
  40d1e7:	mov    r14,rax
  40d1ea:	jmp    40d3fe <__swc_fn_6b1cf01f_000163_5fbed98a+0x27e>
  40d1ef:	mov    rcx,QWORD PTR [rdi]
  40d1f2:	mov    rdx,QWORD PTR [rcx+r15*8]
  40d1f6:	mov    rdi,rbx
  40d1f9:	mov    rcx,rdi
  40d1fc:	sub    rsp,0x8
  40d200:	mov    r14,rax
  40d203:	call   409f10 <__swc_fn_6b1cf01f_000162_edb9cf73>
  40d208:	add    rsp,0x8
  40d20c:	mov    al,BYTE PTR [rbx]
  40d20e:	test   al,al
  40d210:	je     40d3fe <__swc_fn_6b1cf01f_000163_5fbed98a+0x27e>
  40d216:	mov    al,BYTE PTR [rbx+0x1]
  40d219:	test   al,al
  40d21b:	jne    40d226 <__swc_fn_6b1cf01f_000163_5fbed98a+0xa6>
  40d21d:	test   sil,sil
  40d220:	je     40d3fe <__swc_fn_6b1cf01f_000163_5fbed98a+0x27e>
  40d226:	test   r13b,r13b
  40d229:	jne    40d2e7 <__swc_fn_6b1cf01f_000163_5fbed98a+0x167>
  40d22f:	test   r12,r12
  40d232:	je     40d2e7 <__swc_fn_6b1cf01f_000163_5fbed98a+0x167>
  40d238:	mov    al,BYTE PTR [rbx+0x1]
  40d23b:	test   al,al
  40d23d:	je     40d3fe <__swc_fn_6b1cf01f_000163_5fbed98a+0x27e>
  40d243:	mov    eax,DWORD PTR [rbx+0x28]
  40d246:	cmp    DWORD PTR [r12+0x20],eax
  40d24b:	jne    40d3fe <__swc_fn_6b1cf01f_000163_5fbed98a+0x27e>
  40d251:	mov    rax,QWORD PTR [r12]
  40d255:	mov    rcx,QWORD PTR [r12+0x8]
  40d25a:	cmp    QWORD PTR [rbx+0x20],rcx
  40d25e:	jne    40d3fe <__swc_fn_6b1cf01f_000163_5fbed98a+0x27e>
  40d264:	mov    cl,0x1
  40d266:	test   rax,rax
  40d269:	je     40d2d2 <__swc_fn_6b1cf01f_000163_5fbed98a+0x152>
  40d26f:	mov    rdx,QWORD PTR [rbx+0x20]
  40d273:	xor    r8d,r8d
  40d276:	test   rdx,rdx
  40d279:	jbe    40d2d2 <__swc_fn_6b1cf01f_000163_5fbed98a+0x152>
  40d27b:	mov    r9,QWORD PTR [rbx+0x18]
  40d27f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40d284:	cs nop WORD PTR [rax+rax*1+0x0]
  40d28e:	xchg   ax,ax
  40d290:	mov    r10b,BYTE PTR [rax+r8*1]
  40d294:	cmp    BYTE PTR [r9+r8*1],r10b
  40d298:	je     40d2c9 <__swc_fn_6b1cf01f_000163_5fbed98a+0x149>
  40d29a:	vmovq  r10,xmm0
  40d29f:	cmp    BYTE PTR [r10+r8*1],0x5c
  40d2a4:	jne    40d2ad <__swc_fn_6b1cf01f_000163_5fbed98a+0x12d>
  40d2a6:	cmp    BYTE PTR [rax+r8*1],0x2f
  40d2ab:	je     40d2c9 <__swc_fn_6b1cf01f_000163_5fbed98a+0x149>
  40d2ad:	vmovq  r10,xmm0
  40d2b2:	cmp    BYTE PTR [r10+r8*1],0x2f
  40d2b7:	jne    40d2c0 <__swc_fn_6b1cf01f_000163_5fbed98a+0x140>
  40d2b9:	cmp    BYTE PTR [rax+r8*1],0x5c
  40d2be:	je     40d2c9 <__swc_fn_6b1cf01f_000163_5fbed98a+0x149>
  40d2c0:	xor    eax,eax
  40d2c2:	movzx  eax,al
  40d2c5:	mov    cl,al
  40d2c7:	jmp    40d2d2 <__swc_fn_6b1cf01f_000163_5fbed98a+0x152>
  40d2c9:	add    r8,0x1
  40d2cd:	cmp    r8,rdx
  40d2d0:	jb     40d290 <__swc_fn_6b1cf01f_000163_5fbed98a+0x110>
  40d2d2:	test   cl,cl
  40d2d4:	je     40d3fe <__swc_fn_6b1cf01f_000163_5fbed98a+0x27e>
  40d2da:	mov    eax,0x1
  40d2df:	mov    r13b,al
  40d2e2:	jmp    40d3fe <__swc_fn_6b1cf01f_000163_5fbed98a+0x27e>
  40d2e7:	mov    r13b,0x1
  40d2ea:	sub    rsp,0x20
  40d2ee:	mov    rax,rsp
  40d2f1:	lea    rcx,[rdi+0x8]
  40d2f5:	mov    QWORD PTR [rax],rcx
  40d2f8:	lea    rsi,[rip+0x6011]        # 413310 <__swc_rdata_base_6b1cf01f+0x200>
  40d2ff:	mov    QWORD PTR [rax+0x8],rsi
  40d303:	mov    QWORD PTR [rax+0x10],rsp
  40d307:	mov    QWORD PTR [rax+0x18],0x1
  40d30f:	lea    rcx,[rsp+0x10]
  40d314:	sub    rsp,0x8
  40d318:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  40d31d:	add    rsp,0x8
  40d321:	add    rsp,0x20
  40d325:	mov    al,BYTE PTR [rbx+0x1]
  40d328:	test   al,al
  40d32a:	je     40d3c7 <__swc_fn_6b1cf01f_000163_5fbed98a+0x247>
  40d330:	lea    rax,[rip+0x6581]        # 4138b8 <__swc_rdata_base_6b1cf01f+0x7a8>
  40d337:	sub    rsp,0x20
  40d33b:	mov    rcx,rsp
  40d33e:	mov    QWORD PTR [rcx],rax
  40d341:	mov    QWORD PTR [rcx+0x8],rsi
  40d345:	mov    QWORD PTR [rcx+0x10],rsp
  40d349:	mov    QWORD PTR [rcx+0x18],0x1
  40d351:	lea    rcx,[rsp+0x10]
  40d356:	sub    rsp,0x8
  40d35a:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  40d35f:	add    rsp,0x8
  40d363:	add    rsp,0x20
  40d367:	mov    eax,DWORD PTR [rbx+0x28]
  40d36a:	sub    rsp,0x60
  40d36e:	mov    rcx,rsp
  40d371:	lea    rdx,[rdi+0x18]
  40d375:	mov    QWORD PTR [rcx+0x18],rdx
  40d379:	mov    QWORD PTR [rcx+0x20],rsi
  40d37d:	vmovups XMMWORD PTR [rcx],xmm6
  40d381:	mov    QWORD PTR [rcx+0x28],rsp
  40d385:	mov    QWORD PTR [rcx+0x30],rsi
  40d389:	mov    DWORD PTR [rcx+0x10],eax
  40d38c:	lea    rax,[rsp+0x10]
  40d391:	mov    QWORD PTR [rcx+0x38],rax
  40d395:	lea    rax,[rip+0x6034]        # 4133d0 <__swc_rdata_base_6b1cf01f+0x2c0>
  40d39c:	mov    QWORD PTR [rcx+0x40],rax
  40d3a0:	lea    rax,[rsp+0x18]
  40d3a5:	mov    QWORD PTR [rcx+0x48],rax
  40d3a9:	mov    QWORD PTR [rcx+0x50],0x3
  40d3b1:	lea    rcx,[rsp+0x48]
  40d3b6:	sub    rsp,0x8
  40d3ba:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  40d3bf:	add    rsp,0x8
  40d3c3:	add    rsp,0x60
  40d3c7:	lea    rax,[rip+0x5f9a]        # 413368 <__swc_rdata_base_6b1cf01f+0x258>
  40d3ce:	sub    rsp,0x20
  40d3d2:	mov    rcx,rsp
  40d3d5:	mov    QWORD PTR [rcx],rax
  40d3d8:	mov    QWORD PTR [rcx+0x8],rsi
  40d3dc:	mov    QWORD PTR [rcx+0x10],rsp
  40d3e0:	mov    QWORD PTR [rcx+0x18],0x1
  40d3e8:	lea    rcx,[rsp+0x10]
  40d3ed:	sub    rsp,0x8
  40d3f1:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  40d3f6:	add    rsp,0x8
  40d3fa:	add    rsp,0x20
  40d3fe:	add    r15,0x1
  40d402:	cmp    r15,r14
  40d405:	jae    40d41e <__swc_fn_6b1cf01f_000163_5fbed98a+0x29e>
  40d407:	mov    rsi,QWORD PTR [rsp+0x30]
  40d40c:	mov    rdi,QWORD PTR [rsp+0x38]
  40d411:	mov    rax,r14
  40d414:	mov    r14,QWORD PTR [rsp+0x48]
  40d419:	jmp    40d1e0 <__swc_fn_6b1cf01f_000163_5fbed98a+0x60>
  40d41e:	add    rsp,0x50
  40d422:	vmovups xmm6,XMMWORD PTR [rsp]
  40d427:	add    rsp,0x10
  40d42b:	pop    r15
  40d42d:	pop    r14
  40d42f:	pop    r13
  40d431:	pop    r12
  40d433:	pop    rdi
  40d434:	pop    rsi
  40d435:	pop    rbx
  40d436:	pop    rbp
  40d437:	ret
	...

000000000040d440 <__swc_fn_6b1cf01f_000166_31ca4f53>:
  40d440:	sub    rsp,0x8
  40d444:	call   40fb50 <__swc_fn_6b1cf01f_000125_e19c72b3>
  40d449:	add    rsp,0x8
  40d44d:	ret
	...

000000000040d450 <__swc_fn_6b1cf01f_000169_aabbfb4c>:
  40d450:	push   rsi
  40d451:	sub    rsp,0x30
  40d455:	lea    rsi,[rip+0x19944]        # 426da0 <__swc_bss_base_6b1cf01f+0x2d60>
  40d45c:	mov    rax,QWORD PTR [rsi]
  40d45f:	test   rax,rax
  40d462:	je     40d46a <__swc_fn_6b1cf01f_000169_aabbfb4c+0x1a>
  40d464:	add    rsp,0x30
  40d468:	pop    rsi
  40d469:	ret
  40d46a:	mov    ecx,0x2
  40d46f:	mov    edx,0x8020
  40d474:	call   40f1f0 <__swc_fn_6b1cf01f_000107_ff529476>
  40d479:	test   rax,rax
  40d47c:	jne    40d48d <__swc_fn_6b1cf01f_000169_aabbfb4c+0x3d>
  40d47e:	mov    QWORD PTR [rsp+0x18],rax
  40d483:	call   40c8f0 <__swc_fn_6b1cf01f_000118_2b35b5e0>
  40d488:	mov    rax,QWORD PTR [rsp+0x18]
  40d48d:	mov    rcx,rax
  40d490:	xchg   QWORD PTR [rsi],rcx
  40d493:	add    rsp,0x30
  40d497:	pop    rsi
  40d498:	ret
  40d499:	add    BYTE PTR [rax],al
  40d49b:	add    BYTE PTR [rax],al
  40d49d:	add    BYTE PTR [rax],al
	...

000000000040d4a0 <__swc_fn_6b1cf01f_000172_9a88b1d5>:
  40d4a0:	push   rsi
  40d4a1:	test   r8,r8
  40d4a4:	jne    40d4a8 <__swc_fn_6b1cf01f_000172_9a88b1d5+0x8>
  40d4a6:	pop    rsi
  40d4a7:	ret
  40d4a8:	lea    rax,[rcx+0x18]
  40d4ac:	mov    r10,QWORD PTR [rax]
  40d4af:	lea    r11,[r10+0x1]
  40d4b3:	mov    QWORD PTR [rax],r11
  40d4b6:	mov    r11,rdx
  40d4b9:	not    rdx
  40d4bc:	lea    rsi,[r8-0x1]
  40d4c0:	cmp    rsi,rdx
  40d4c3:	ja     40d4e3 <__swc_fn_6b1cf01f_000172_9a88b1d5+0x43>
  40d4c5:	lea    rdx,[r11+r8*1]
  40d4c9:	dec    rdx
  40d4cc:	shr    rdx,0x6
  40d4d0:	mov    r8,r11
  40d4d3:	shr    r8,0x6
  40d4d7:	mov    rsi,rdx
  40d4da:	sub    rsi,r8
  40d4dd:	cmp    rsi,0x8
  40d4e1:	jb     40d4f9 <__swc_fn_6b1cf01f_000172_9a88b1d5+0x59>
  40d4e3:	lea    rcx,[rcx+0x10]
  40d4e7:	mov    rdx,QWORD PTR [rcx]
  40d4ea:	add    rdx,r9
  40d4ed:	mov    QWORD PTR [rcx],rdx
  40d4f0:	lea    rcx,[r10+0x2]
  40d4f4:	mov    QWORD PTR [rax],rcx
  40d4f7:	pop    rsi
  40d4f8:	ret
  40d4f9:	shr    r11,0x6
  40d4fd:	nop    DWORD PTR [rax]
  40d500:	cmp    r11,rdx
  40d503:	ja     40d543 <__swc_fn_6b1cf01f_000172_9a88b1d5+0xa3>
  40d505:	jmp    40d516 <__swc_fn_6b1cf01f_000172_9a88b1d5+0x76>
  40d507:	nop    WORD PTR [rax+rax*1+0x0]
  40d510:	add    r11,0x1
  40d514:	jmp    40d500 <__swc_fn_6b1cf01f_000172_9a88b1d5+0x60>
  40d516:	mov    r8,r11
  40d519:	shr    r8,0xc
  40d51d:	mov    rsi,r11
  40d520:	xor    rsi,r8
  40d523:	mov    r8,r11
  40d526:	shr    r8,0x18
  40d52a:	xor    rsi,r8
  40d52d:	and    esi,0xfff
  40d533:	lea    r8,[rcx+rsi*8+0x20]
  40d538:	mov    rsi,QWORD PTR [r8]
  40d53b:	add    rsi,r9
  40d53e:	mov    QWORD PTR [r8],rsi
  40d541:	jmp    40d510 <__swc_fn_6b1cf01f_000172_9a88b1d5+0x70>
  40d543:	lea    rcx,[r10+0x2]
  40d547:	mov    QWORD PTR [rax],rcx
  40d54a:	pop    rsi
  40d54b:	ret
  40d54c:	add    BYTE PTR [rax],al
	...

000000000040d550 <__swc_fn_6b1cf01f_000175_1ca87929>:
  40d550:	push   rdi
  40d551:	push   rsi
  40d552:	sub    rsp,0xb8
  40d559:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40d55f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40d565:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40d56b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40d571:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40d577:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40d57d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40d583:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40d58c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40d595:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40d59e:	vxorps xmm0,xmm0,xmm0
  40d5a2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40d5a8:	mov    edi,0x1
  40d5ad:	lea    rsi,[rsp+0x8]
  40d5b2:	xor    eax,eax
  40d5b4:	call   407110 <clock_gettime@plt>
  40d5b9:	vxorpd xmm0,xmm0,xmm0
  40d5bd:	mov    rax,QWORD PTR [rsp+0x8]
  40d5c2:	vcvtsi2sd xmm0,xmm0,rax
  40d5c7:	vxorpd xmm1,xmm1,xmm1
  40d5cb:	mov    rax,QWORD PTR [rsp+0x10]
  40d5d0:	vcvtsi2sd xmm1,xmm1,rax
  40d5d5:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x632b]        # 413908 <__swc_rdata_base_6b1cf01f+0x7f8>
  40d5dd:	vaddsd xmm0,xmm0,xmm1
  40d5e1:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40d5e7:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40d5ed:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40d5f3:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40d5f9:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40d5ff:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40d605:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40d60b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40d614:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40d61d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40d626:	add    rsp,0xb8
  40d62d:	pop    rsi
  40d62e:	pop    rdi
  40d62f:	ret
	...

000000000040d640 <__swc_fn_6b1cf01f_000002_390d5093>:
  40d640:	sub    rsp,0x8
  40d644:	call   40c540 <__swc_fn_6b1cf01f_000109_aa570b2b>
  40d649:	mov    rcx,rax
  40d64c:	test   rax,rax
  40d64f:	je     40d676 <__swc_fn_6b1cf01f_000002_390d5093+0x36>
  40d651:	lea    rdx,[rip+0x169e8]        # 424040 <__swc_bss_base_6b1cf01f>
  40d658:	mov    r8,QWORD PTR [rip+0x169e1]        # 424040 <__swc_bss_base_6b1cf01f>
  40d65f:	nop
  40d660:	lea    r9,[r8+0x1]
  40d664:	mov    rax,r8
  40d667:	lock cmpxchg QWORD PTR [rdx],r9
  40d66c:	cmp    rax,r8
  40d66f:	je     40d676 <__swc_fn_6b1cf01f_000002_390d5093+0x36>
  40d671:	mov    r8,rax
  40d674:	jmp    40d660 <__swc_fn_6b1cf01f_000002_390d5093+0x20>
  40d676:	mov    rax,rcx
  40d679:	add    rsp,0x8
  40d67d:	ret
	...

000000000040d680 <__swc_fn_6b1cf01f_000005_bcc5b80b>:
  40d680:	mov    r8d,edx
  40d683:	xor    eax,eax
  40d685:	tzcnt  eax,edx
  40d689:	shrx   r9d,edx,eax
  40d68e:	mov    DWORD PTR [rcx+0x2c],edx
  40d691:	xor    eax,eax
  40d693:	tzcnt  eax,edx
  40d697:	mov    BYTE PTR [rcx+0x38],al
  40d69a:	mov    eax,0xffffffff
  40d69f:	xor    edx,edx
  40d6a1:	div    r8d
  40d6a4:	mov    DWORD PTR [rcx+0x34],eax
  40d6a7:	mov    eax,r9d
  40d6aa:	mov    edx,r9d
  40d6ad:	imul   edx,r9d
  40d6b1:	mov    r8d,0x2
  40d6b7:	sub    r8d,edx
  40d6ba:	imul   eax,r8d
  40d6be:	mov    edx,r9d
  40d6c1:	imul   edx,eax
  40d6c4:	mov    r8d,0x2
  40d6ca:	sub    r8d,edx
  40d6cd:	imul   eax,r8d
  40d6d1:	mov    edx,r9d
  40d6d4:	imul   edx,eax
  40d6d7:	mov    r8d,0x2
  40d6dd:	sub    r8d,edx
  40d6e0:	imul   eax,r8d
  40d6e4:	mov    edx,r9d
  40d6e7:	imul   edx,eax
  40d6ea:	mov    r8d,0x2
  40d6f0:	sub    r8d,edx
  40d6f3:	imul   eax,r8d
  40d6f7:	imul   r9d,eax
  40d6fb:	mov    edx,0x2
  40d700:	sub    edx,r9d
  40d703:	imul   eax,edx
  40d706:	mov    DWORD PTR [rcx+0x30],eax
  40d709:	ret
  40d70a:	add    BYTE PTR [rax],al
  40d70c:	add    BYTE PTR [rax],al
	...

000000000040d710 <__swc_fn_6b1cf01f_000008_578f1784>:
  40d710:	xor    eax,eax
  40d712:	mov    DWORD PTR [rcx+0x68],eax
  40d715:	ret
	...

000000000040d720 <__swc_fn_6b1cf01f_000011_e75d466d>:
  40d720:	mov    eax,DWORD PTR [rcx+0x28]
  40d723:	shlx   eax,edx,eax
  40d728:	shl    rax,0x10
  40d72c:	lea    rdx,[rcx+rax*1]
  40d730:	lea    rax,[rcx+0x3000]
  40d737:	cmp    rdx,rax
  40d73a:	cmovae rax,rdx
  40d73e:	ret
	...

000000000040d740 <__swc_fn_6b1cf01f_000014_1acdaf22>:
  40d740:	push   rsi
  40d741:	push   rdi
  40d742:	push   r12
  40d744:	push   r13
  40d746:	push   r14
  40d748:	mov    rsi,rdx
  40d74b:	mov    rdi,rcx
  40d74e:	rex mov dl,BYTE PTR [rsi+0x3a]
  40d752:	mov    ecx,DWORD PTR [rdi+0x28]
  40d755:	shr    dl,cl
  40d757:	mov    r12d,0x1
  40d75d:	mov    ecx,edx
  40d75f:	shl    r12,cl
  40d762:	mov    r13d,DWORD PTR [rsi+0x3c]
  40d766:	rex mov BYTE PTR [rsi+0x3b],0x0
  40d76b:	mov    QWORD PTR [rsi+0x40],0x0
  40d773:	mov    QWORD PTR [rsi],0x0
  40d77a:	mov    rax,QWORD PTR [rsi+0x10]
  40d77e:	mov    QWORD PTR [rsi+0x20],rax
  40d782:	lea    r14,[rip+0x168bf]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  40d789:	mov    rax,QWORD PTR [r14]
  40d78c:	shr    rax,0x2
  40d790:	mov    rcx,rax
  40d793:	cmp    rax,0x800000
  40d79a:	mov    eax,0x800000
  40d79f:	cmovb  rcx,rax
  40d7a3:	lea    r8,[rip+0x168ae]        # 424058 <__swc_bss_base_6b1cf01f+0x18>
  40d7aa:	mov    rax,QWORD PTR [r8]
  40d7ad:	mov    r9,rax
  40d7b0:	lea    r10,[r9+r13*1]
  40d7b4:	cmp    r10,rcx
  40d7b7:	ja     40d7db <__swc_fn_6b1cf01f_000014_1acdaf22+0x9b>
  40d7b9:	mov    rax,r9
  40d7bc:	lock cmpxchg QWORD PTR [r8],r10
  40d7c1:	cmp    rax,r9
  40d7c4:	je     40d7cb <__swc_fn_6b1cf01f_000014_1acdaf22+0x8b>
  40d7c6:	mov    r9,rax
  40d7c9:	jmp    40d7b0 <__swc_fn_6b1cf01f_000014_1acdaf22+0x70>
  40d7cb:	mov    rcx,rdi
  40d7ce:	mov    rdx,r12
  40d7d1:	call   40a670 <__swc_fn_6b1cf01f_000016_89da4d6e>
  40d7d6:	jmp    40d85d <__swc_fn_6b1cf01f_000014_1acdaf22+0x11d>
  40d7db:	mov    rcx,rdi
  40d7de:	movzx  edx,dl
  40d7e1:	call   40d720 <__swc_fn_6b1cf01f_000011_e75d466d>
  40d7e6:	test   r13,r13
  40d7e9:	je     40d856 <__swc_fn_6b1cf01f_000014_1acdaf22+0x116>
  40d7ef:	mov    rcx,rax
  40d7f2:	mov    rdx,r13
  40d7f5:	call   40c6c0 <__swc_fn_6b1cf01f_000112_cb2656be>
  40d7fa:	mov    rcx,QWORD PTR [rip+0x16847]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  40d801:	cs nop WORD PTR [rax+rax*1+0x0]
  40d80b:	nop    DWORD PTR [rax+rax*1+0x0]
  40d810:	mov    rdx,rcx
  40d813:	sub    rdx,r13
  40d816:	mov    rax,rcx
  40d819:	lock cmpxchg QWORD PTR [r14],rdx
  40d81e:	cmp    rax,rcx
  40d821:	je     40d828 <__swc_fn_6b1cf01f_000014_1acdaf22+0xe8>
  40d823:	mov    rcx,rax
  40d826:	jmp    40d810 <__swc_fn_6b1cf01f_000014_1acdaf22+0xd0>
  40d828:	lea    rcx,[rip+0x16831]        # 424060 <__swc_bss_base_6b1cf01f+0x20>
  40d82f:	mov    rdx,QWORD PTR [rip+0x1682a]        # 424060 <__swc_bss_base_6b1cf01f+0x20>
  40d836:	cs nop WORD PTR [rax+rax*1+0x0]
  40d840:	lea    r8,[rdx+0x1]
  40d844:	mov    rax,rdx
  40d847:	lock cmpxchg QWORD PTR [rcx],r8
  40d84c:	cmp    rax,rdx
  40d84f:	je     40d856 <__swc_fn_6b1cf01f_000014_1acdaf22+0x116>
  40d851:	mov    rdx,rax
  40d854:	jmp    40d840 <__swc_fn_6b1cf01f_000014_1acdaf22+0x100>
  40d856:	mov    DWORD PTR [rsi+0x3c],0x0
  40d85d:	mov    rcx,rdi
  40d860:	mov    rdx,r12
  40d863:	call   407600 <__swc_fn_6b1cf01f_000018_e2e8e4b0>
  40d868:	pop    r14
  40d86a:	pop    r13
  40d86c:	pop    r12
  40d86e:	pop    rdi
  40d86f:	pop    rsi
  40d870:	ret
	...

000000000040d880 <__swc_fn_6b1cf01f_000017_e238d24c>:
  40d880:	mov    r8,QWORD PTR [rcx+0x48]
  40d884:	test   r8,rdx
  40d887:	je     40d8b8 <__swc_fn_6b1cf01f_000017_e238d24c+0x38>
  40d889:	nop    DWORD PTR [rax+0x0]
  40d890:	mov    rax,rdx
  40d893:	not    rax
  40d896:	mov    r9,r8
  40d899:	and    r9,rax
  40d89c:	mov    rax,r8
  40d89f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40d8a5:	cmp    rax,r8
  40d8a8:	jne    40d8b0 <__swc_fn_6b1cf01f_000017_e238d24c+0x30>
  40d8aa:	mov    eax,0x1
  40d8af:	ret
  40d8b0:	mov    r8,rax
  40d8b3:	test   rax,rdx
  40d8b6:	jne    40d890 <__swc_fn_6b1cf01f_000017_e238d24c+0x10>
  40d8b8:	xor    eax,eax
  40d8ba:	ret
  40d8bb:	add    BYTE PTR [rax],al
  40d8bd:	add    BYTE PTR [rax],al
	...

000000000040d8c0 <__swc_fn_6b1cf01f_000020_4135c89a>:
  40d8c0:	push   rsi
  40d8c1:	push   rdi
  40d8c2:	push   r12
  40d8c4:	push   r13
  40d8c6:	sub    rsp,0x8
  40d8ca:	mov    rsi,rdx
  40d8cd:	mov    rdi,rcx
  40d8d0:	lea    r12,[rip+0x16919]        # 4241f0 <__swc_bss_base_6b1cf01f+0x1b0>
  40d8d7:	mov    rcx,r12
  40d8da:	call   4098a0 <__swc_fn_6b1cf01f_000135_1fec60ac>
  40d8df:	xor    eax,eax
  40d8e1:	mov    rcx,QWORD PTR [rip+0x16910]        # 4241f8 <__swc_bss_base_6b1cf01f+0x1b8>
  40d8e8:	mov    r13,rcx
  40d8eb:	test   r13,r13
  40d8ee:	je     40d93b <__swc_fn_6b1cf01f_000020_4135c89a+0x7b>
  40d8f0:	mov    rcx,QWORD PTR [r13+0x10]
  40d8f4:	cmp    DWORD PTR [r13+0x28],esi
  40d8f8:	jne    40d930 <__swc_fn_6b1cf01f_000020_4135c89a+0x70>
  40d8fa:	test   rax,rax
  40d8fd:	jne    40d908 <__swc_fn_6b1cf01f_000020_4135c89a+0x48>
  40d8ff:	mov    QWORD PTR [rip+0x168f2],rcx        # 4241f8 <__swc_bss_base_6b1cf01f+0x1b8>
  40d906:	jmp    40d90c <__swc_fn_6b1cf01f_000020_4135c89a+0x4c>
  40d908:	mov    QWORD PTR [rax+0x10],rcx
  40d90c:	vxorps xmm0,xmm0,xmm0
  40d910:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40d916:	mov    QWORD PTR [r13+0x8],rdi
  40d91a:	mov    rcx,r12
  40d91d:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  40d922:	mov    rax,r13
  40d925:	add    rsp,0x8
  40d929:	pop    r13
  40d92b:	pop    r12
  40d92d:	pop    rdi
  40d92e:	pop    rsi
  40d92f:	ret
  40d930:	mov    rax,r13
  40d933:	mov    r13,rcx
  40d936:	test   rcx,rcx
  40d939:	jne    40d8f0 <__swc_fn_6b1cf01f_000020_4135c89a+0x30>
  40d93b:	mov    ecx,esi
  40d93d:	call   40a6a0 <__swc_fn_6b1cf01f_000019_60e50998>
  40d942:	mov    rsi,rax
  40d945:	test   rax,rax
  40d948:	jne    40d95f <__swc_fn_6b1cf01f_000020_4135c89a+0x9f>
  40d94a:	mov    rcx,r12
  40d94d:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  40d952:	xor    eax,eax
  40d954:	add    rsp,0x8
  40d958:	pop    r13
  40d95a:	pop    r12
  40d95c:	pop    rdi
  40d95d:	pop    rsi
  40d95e:	ret
  40d95f:	mov    QWORD PTR [rsi+0x8],rdi
  40d963:	mov    rcx,r12
  40d966:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  40d96b:	mov    rax,rsi
  40d96e:	add    rsp,0x8
  40d972:	pop    r13
  40d974:	pop    r12
  40d976:	pop    rdi
  40d977:	pop    rsi
  40d978:	ret
  40d979:	add    BYTE PTR [rax],al
  40d97b:	add    BYTE PTR [rax],al
  40d97d:	add    BYTE PTR [rax],al
	...

000000000040d980 <__swc_fn_6b1cf01f_000023_7e9350e1>:
  40d980:	vxorps xmm0,xmm0,xmm0
  40d984:	xor    eax,eax
  40d986:	cs nop WORD PTR [rax+rax*1+0x0]
  40d990:	cs nop WORD PTR [rax+rax*1+0x0]
  40d99a:	nop    WORD PTR [rax+rax*1+0x0]
  40d9a0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40d9a5:	add    rax,0x10
  40d9a9:	cmp    rax,0x2b00
  40d9b0:	jne    40d9a0 <__swc_fn_6b1cf01f_000023_7e9350e1+0x20>
  40d9b2:	ret
	...

000000000040d9c0 <__swc_fn_6b1cf01f_000026_7e9350e1>:
  40d9c0:	vxorps xmm0,xmm0,xmm0
  40d9c4:	vmovups XMMWORD PTR [rcx],xmm0
  40d9c8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d9cd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d9d2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d9d7:	ret
	...

000000000040d9e0 <__swc_fn_6b1cf01f_000029_7e9350e1>:
  40d9e0:	vxorps xmm0,xmm0,xmm0
  40d9e4:	vmovups XMMWORD PTR [rcx],xmm0
  40d9e8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d9ed:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d9f2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d9f7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d9fc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40da01:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40da06:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40da0b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40da13:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40da1b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40da23:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40da2b:	mov    QWORD PTR [rcx+0xc0],0x0
  40da36:	ret
	...

000000000040da40 <__swc_fn_6b1cf01f_000032_8c89735c>:
  40da40:	push   rsi
  40da41:	push   rdi
  40da42:	sub    rsp,0x8
  40da46:	mov    rsi,rcx
  40da49:	lea    rdi,[rip+0x145b0]        # 422000 <__swc_data_base_6b1cf01f>
  40da50:	mov    rax,QWORD PTR [rdi]
  40da53:	cmp    rax,0xffffffffffffffff
  40da57:	je     40da5e <__swc_fn_6b1cf01f_000032_8c89735c+0x1e>
  40da59:	mov    rdi,rax
  40da5c:	jmp    40da8b <__swc_fn_6b1cf01f_000032_8c89735c+0x4b>
  40da5e:	call   409580 <__swc_fn_6b1cf01f_000123_e9227a3e>
  40da63:	mov    rcx,rax
  40da66:	cmp    rax,0xffffffffffffffff
  40da6a:	je     40da9c <__swc_fn_6b1cf01f_000032_8c89735c+0x5c>
  40da6c:	mov    rax,0xffffffffffffffff
  40da73:	lock cmpxchg QWORD PTR [rdi],rcx
  40da78:	cmp    rax,0xffffffffffffffff
  40da7c:	je     40da88 <__swc_fn_6b1cf01f_000032_8c89735c+0x48>
  40da7e:	mov    rdi,rax
  40da81:	call   40ca90 <__swc_fn_6b1cf01f_000124_df97aa0a>
  40da86:	jmp    40da8b <__swc_fn_6b1cf01f_000032_8c89735c+0x4b>
  40da88:	mov    rdi,rcx
  40da8b:	cmp    rdi,0xffffffffffffffff
  40da8f:	je     40da9c <__swc_fn_6b1cf01f_000032_8c89735c+0x5c>
  40da91:	mov    rcx,rdi
  40da94:	mov    rdx,rsi
  40da97:	call   40fb50 <__swc_fn_6b1cf01f_000125_e19c72b3>
  40da9c:	add    rsp,0x8
  40daa0:	pop    rdi
  40daa1:	pop    rsi
  40daa2:	ret
	...

000000000040dab0 <__swc_fn_6b1cf01f_000035_6105596e>:
  40dab0:	sub    rsp,0x38
  40dab4:	mov    rax,rdx
  40dab7:	test   dl,dl
  40dab9:	jne    40dad1 <__swc_fn_6b1cf01f_000035_6105596e+0x21>
  40dabb:	mov    rax,r8
  40dabe:	test   r8b,r8b
  40dac1:	cmove  eax,r9d
  40dac5:	test   al,al
  40dac7:	cmove  eax,r10d
  40dacb:	test   al,al
  40dacd:	cmove  eax,r11d
  40dad1:	test   al,al
  40dad3:	jne    40dada <__swc_fn_6b1cf01f_000035_6105596e+0x2a>
  40dad5:	add    rsp,0x38
  40dad9:	ret
  40dada:	lea    rcx,[rip+0x562f]        # 413110 <__swc_rdata_base_6b1cf01f>
  40dae1:	vmovups xmm0,XMMWORD PTR [rip+0x5637]        # 413120 <__swc_rdata_base_6b1cf01f+0x10>
  40dae9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40daef:	vmovups xmm0,XMMWORD PTR [rip+0x5639]        # 413130 <__swc_rdata_base_6b1cf01f+0x20>
  40daf7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40dafd:	vmovups xmm0,XMMWORD PTR [rip+0x563b]        # 413140 <__swc_rdata_base_6b1cf01f+0x30>
  40db05:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40db0b:	lea    rdx,[rsp+0x8]
  40db10:	call   40c2c0 <__swc_fn_6b1cf01f_000103_2ed36338>
  40db15:	jmp    40dad5 <__swc_fn_6b1cf01f_000035_6105596e+0x25>
	...

000000000040db20 <__swc_fn_6b1cf01f_000038_c7591393>:
  40db20:	sub    rsp,0x8
  40db24:	mov    eax,0x1000
  40db29:	test   eax,eax
  40db2b:	mov    r8d,0x8
  40db31:	cmove  eax,r8d
  40db35:	dec    rax
  40db38:	mov    r8,0xffffffffffffffff
  40db3f:	sub    r8,rax
  40db42:	cmp    rdx,r8
  40db45:	ja     40db55 <__swc_fn_6b1cf01f_000038_c7591393+0x35>
  40db47:	add    rdx,rax
  40db4a:	not    rax
  40db4d:	mov    r8,rdx
  40db50:	and    r8,rax
  40db53:	jne    40db5c <__swc_fn_6b1cf01f_000038_c7591393+0x3c>
  40db55:	xor    eax,eax
  40db57:	add    rsp,0x8
  40db5b:	ret
  40db5c:	mov    rdx,r8
  40db5f:	call   40a9c0 <__swc_fn_6b1cf01f_000037_92e867c2>
  40db64:	add    rsp,0x8
  40db68:	ret
  40db69:	add    BYTE PTR [rax],al
  40db6b:	add    BYTE PTR [rax],al
  40db6d:	add    BYTE PTR [rax],al
	...

000000000040db70 <__swc_fn_6b1cf01f_000041_ed1cda78>:
  40db70:	push   rsi
  40db71:	push   rdi
  40db72:	sub    rsp,0x8
  40db76:	mov    rsi,rdx
  40db79:	mov    rdi,rcx
  40db7c:	test   rdx,rdx
  40db7f:	je     40db9b <__swc_fn_6b1cf01f_000041_ed1cda78+0x2b>
  40db81:	xor    ecx,ecx
  40db83:	call   407720 <__swc_fn_6b1cf01f_000033_7d7574b6>
  40db88:	mov    rax,QWORD PTR [rsi]
  40db8b:	test   rax,rax
  40db8e:	je     40db9b <__swc_fn_6b1cf01f_000041_ed1cda78+0x2b>
  40db90:	mov    rcx,rax
  40db93:	mov    rdx,rsi
  40db96:	call   407840 <__swc_fn_6b1cf01f_000042_70d5ab54>
  40db9b:	mov    rcx,rdi
  40db9e:	call   40aa20 <__swc_fn_6b1cf01f_000040_7a225310>
  40dba3:	mov    rsi,rax
  40dba6:	test   rax,rax
  40dba9:	jne    40dbb4 <__swc_fn_6b1cf01f_000041_ed1cda78+0x44>
  40dbab:	xor    eax,eax
  40dbad:	add    rsp,0x8
  40dbb1:	pop    rdi
  40dbb2:	pop    rsi
  40dbb3:	ret
  40dbb4:	mov    rcx,rsi
  40dbb7:	call   407720 <__swc_fn_6b1cf01f_000033_7d7574b6>
  40dbbc:	mov    rax,rsi
  40dbbf:	add    rsp,0x8
  40dbc3:	pop    rdi
  40dbc4:	pop    rsi
  40dbc5:	ret
	...

000000000040dbd0 <__swc_fn_6b1cf01f_000044_cac7f504>:
  40dbd0:	movzx  eax,BYTE PTR [r8+0x39]
  40dbd5:	lea    rax,[rax+rax*4]
  40dbd9:	lea    rax,[rdx+rax*8+0x28]
  40dbde:	mov    ecx,DWORD PTR [r8+0x6c]
  40dbe2:	test   ecx,ecx
  40dbe4:	je     40dc1d <__swc_fn_6b1cf01f_000044_cac7f504+0x4d>
  40dbe6:	mov    rcx,QWORD PTR [r8+0x50]
  40dbea:	test   rcx,rcx
  40dbed:	je     40dbf9 <__swc_fn_6b1cf01f_000044_cac7f504+0x29>
  40dbef:	mov    rax,QWORD PTR [r8+0x48]
  40dbf3:	mov    QWORD PTR [rcx+0x48],rax
  40dbf7:	jmp    40dc01 <__swc_fn_6b1cf01f_000044_cac7f504+0x31>
  40dbf9:	mov    rcx,QWORD PTR [r8+0x48]
  40dbfd:	mov    QWORD PTR [rax+0x18],rcx
  40dc01:	mov    rax,QWORD PTR [r8+0x48]
  40dc05:	test   rax,rax
  40dc08:	je     40dc12 <__swc_fn_6b1cf01f_000044_cac7f504+0x42>
  40dc0a:	mov    rcx,QWORD PTR [r8+0x50]
  40dc0e:	mov    QWORD PTR [rax+0x50],rcx
  40dc12:	vxorps xmm0,xmm0,xmm0
  40dc16:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40dc1c:	ret
  40dc1d:	mov    rcx,QWORD PTR [r8+0x50]
  40dc21:	test   rcx,rcx
  40dc24:	je     40dc30 <__swc_fn_6b1cf01f_000044_cac7f504+0x60>
  40dc26:	mov    rdx,QWORD PTR [r8+0x48]
  40dc2a:	mov    QWORD PTR [rcx+0x48],rdx
  40dc2e:	jmp    40dc38 <__swc_fn_6b1cf01f_000044_cac7f504+0x68>
  40dc30:	mov    rcx,QWORD PTR [r8+0x48]
  40dc34:	mov    QWORD PTR [rax+0x8],rcx
  40dc38:	mov    rcx,QWORD PTR [r8+0x48]
  40dc3c:	test   rcx,rcx
  40dc3f:	je     40dc4b <__swc_fn_6b1cf01f_000044_cac7f504+0x7b>
  40dc41:	mov    rdx,QWORD PTR [r8+0x50]
  40dc45:	mov    QWORD PTR [rcx+0x50],rdx
  40dc49:	jmp    40dc53 <__swc_fn_6b1cf01f_000044_cac7f504+0x83>
  40dc4b:	mov    rcx,QWORD PTR [r8+0x50]
  40dc4f:	mov    QWORD PTR [rax+0x10],rcx
  40dc53:	cmp    QWORD PTR [rax],r8
  40dc56:	jne    40dc5f <__swc_fn_6b1cf01f_000044_cac7f504+0x8f>
  40dc58:	mov    QWORD PTR [rax],0x0
  40dc5f:	vxorps xmm0,xmm0,xmm0
  40dc63:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40dc69:	ret
  40dc6a:	add    BYTE PTR [rax],al
  40dc6c:	add    BYTE PTR [rax],al
	...

000000000040dc70 <__swc_fn_6b1cf01f_000047_3d3eceb4>:
  40dc70:	sub    rsp,0x8
  40dc74:	mov    r9,r8
  40dc77:	mov    r10,rdx
  40dc7a:	call   40dbd0 <__swc_fn_6b1cf01f_000044_cac7f504>
  40dc7f:	mov    DWORD PTR [r9+0x6c],0x0
  40dc87:	movzx  eax,BYTE PTR [r9+0x39]
  40dc8c:	lea    rax,[rax+rax*4]
  40dc90:	lea    rax,[r10+rax*8+0x28]
  40dc95:	mov    rcx,QWORD PTR [rax+0x10]
  40dc99:	mov    QWORD PTR [r9+0x50],rcx
  40dc9d:	mov    QWORD PTR [r9+0x48],0x0
  40dca5:	mov    rcx,QWORD PTR [rax+0x10]
  40dca9:	test   rcx,rcx
  40dcac:	je     40dcb4 <__swc_fn_6b1cf01f_000047_3d3eceb4+0x44>
  40dcae:	mov    QWORD PTR [rcx+0x48],r9
  40dcb2:	jmp    40dcb8 <__swc_fn_6b1cf01f_000047_3d3eceb4+0x48>
  40dcb4:	mov    QWORD PTR [rax+0x8],r9
  40dcb8:	mov    QWORD PTR [rax+0x10],r9
  40dcbc:	add    rsp,0x8
  40dcc0:	ret
	...

000000000040dce0 <__swc_fn_6b1cf01f_000050_e33921d7>:
  40dce0:	push   rsi
  40dce1:	push   rdi
  40dce2:	push   r12
  40dce4:	push   r13
  40dce6:	push   r14
  40dce8:	push   r15
  40dcea:	sub    rsp,0x1f8
  40dcf1:	mov    esi,r8d
  40dcf4:	mov    QWORD PTR [rsp+0x1e8],rsi
  40dcfc:	mov    rdi,rcx
  40dcff:	mov    r12,rdx
  40dd02:	lea    r13,[rsi+rsi*4]
  40dd06:	lea    r13,[rdx+r13*8+0x28]
  40dd0b:	call   407ca0 <__swc_fn_6b1cf01f_000048_18a95c9b>
  40dd10:	add    DWORD PTR [r12+0x24],0x1
  40dd16:	test   BYTE PTR [r12+0x24],0x3f
  40dd1c:	jne    40dd26 <__swc_fn_6b1cf01f_000050_e33921d7+0x46>
  40dd1e:	mov    rcx,rdi
  40dd21:	call   40aba0 <__swc_fn_6b1cf01f_000049_781177b4>
  40dd26:	mov    rax,QWORD PTR [r13+0x8]
  40dd2a:	mov    r14,rax
  40dd2d:	nop    DWORD PTR [rax]
  40dd30:	test   r14,r14
  40dd33:	jne    40dd42 <__swc_fn_6b1cf01f_000050_e33921d7+0x62>
  40dd35:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40dd3d:	jmp    40de49 <__swc_fn_6b1cf01f_000050_e33921d7+0x169>
  40dd42:	mov    r15,QWORD PTR [r14+0x48]
  40dd46:	mov    rcx,r14
  40dd49:	call   4073f0 <__swc_fn_6b1cf01f_000009_2417e911>
  40dd4e:	mov    rax,QWORD PTR [r14]
  40dd51:	test   rax,rax
  40dd54:	je     40dd66 <__swc_fn_6b1cf01f_000050_e33921d7+0x86>
  40dd56:	mov    rcx,QWORD PTR [rax]
  40dd59:	mov    QWORD PTR [r14],rcx
  40dd5c:	add    DWORD PTR [r14+0x28],0x1
  40dd61:	mov    rsi,rax
  40dd64:	jmp    40dd85 <__swc_fn_6b1cf01f_000050_e33921d7+0xa5>
  40dd66:	mov    rax,QWORD PTR [r14+0x18]
  40dd6a:	cmp    QWORD PTR [r14+0x20],rax
  40dd6e:	jae    40dd83 <__swc_fn_6b1cf01f_000050_e33921d7+0xa3>
  40dd70:	mov    rsi,QWORD PTR [r14+0x20]
  40dd74:	mov    eax,DWORD PTR [r14+0x2c]
  40dd78:	add    QWORD PTR [r14+0x20],rax
  40dd7c:	add    DWORD PTR [r14+0x28],0x1
  40dd81:	jmp    40dd85 <__swc_fn_6b1cf01f_000050_e33921d7+0xa5>
  40dd83:	xor    esi,esi
  40dd85:	test   rsi,rsi
  40dd88:	jne    40ddcd <__swc_fn_6b1cf01f_000050_e33921d7+0xed>
  40dd8a:	mov    rcx,r14
  40dd8d:	call   407320 <__swc_fn_6b1cf01f_000006_12cb36a2>
  40dd92:	test   al,al
  40dd94:	je     40ddcd <__swc_fn_6b1cf01f_000050_e33921d7+0xed>
  40dd96:	mov    rax,QWORD PTR [r14]
  40dd99:	test   rax,rax
  40dd9c:	je     40ddab <__swc_fn_6b1cf01f_000050_e33921d7+0xcb>
  40dd9e:	mov    rcx,QWORD PTR [rax]
  40dda1:	mov    QWORD PTR [r14],rcx
  40dda4:	add    DWORD PTR [r14+0x28],0x1
  40dda9:	jmp    40ddca <__swc_fn_6b1cf01f_000050_e33921d7+0xea>
  40ddab:	mov    rax,QWORD PTR [r14+0x18]
  40ddaf:	cmp    QWORD PTR [r14+0x20],rax
  40ddb3:	jae    40ddc8 <__swc_fn_6b1cf01f_000050_e33921d7+0xe8>
  40ddb5:	mov    rax,QWORD PTR [r14+0x20]
  40ddb9:	mov    ecx,DWORD PTR [r14+0x2c]
  40ddbd:	add    QWORD PTR [r14+0x20],rcx
  40ddc1:	add    DWORD PTR [r14+0x28],0x1
  40ddc6:	jmp    40ddca <__swc_fn_6b1cf01f_000050_e33921d7+0xea>
  40ddc8:	xor    eax,eax
  40ddca:	mov    rsi,rax
  40ddcd:	test   rsi,rsi
  40ddd0:	jne    40de23 <__swc_fn_6b1cf01f_000050_e33921d7+0x143>
  40ddd2:	mov    rcx,rdi
  40ddd5:	mov    rdx,r12
  40ddd8:	mov    r8,r14
  40dddb:	call   40ab00 <__swc_fn_6b1cf01f_000046_49300800>
  40dde0:	test   al,al
  40dde2:	jne    40de23 <__swc_fn_6b1cf01f_000050_e33921d7+0x143>
  40dde4:	mov    rcx,r14
  40dde7:	call   4073f0 <__swc_fn_6b1cf01f_000009_2417e911>
  40ddec:	mov    rax,QWORD PTR [r14]
  40ddef:	test   rax,rax
  40ddf2:	je     40de01 <__swc_fn_6b1cf01f_000050_e33921d7+0x121>
  40ddf4:	mov    rcx,QWORD PTR [rax]
  40ddf7:	mov    QWORD PTR [r14],rcx
  40ddfa:	add    DWORD PTR [r14+0x28],0x1
  40ddff:	jmp    40de20 <__swc_fn_6b1cf01f_000050_e33921d7+0x140>
  40de01:	mov    rax,QWORD PTR [r14+0x18]
  40de05:	cmp    QWORD PTR [r14+0x20],rax
  40de09:	jae    40de1e <__swc_fn_6b1cf01f_000050_e33921d7+0x13e>
  40de0b:	mov    rax,QWORD PTR [r14+0x20]
  40de0f:	mov    ecx,DWORD PTR [r14+0x2c]
  40de13:	add    QWORD PTR [r14+0x20],rcx
  40de17:	add    DWORD PTR [r14+0x28],0x1
  40de1c:	jmp    40de20 <__swc_fn_6b1cf01f_000050_e33921d7+0x140>
  40de1e:	xor    eax,eax
  40de20:	mov    rsi,rax
  40de23:	test   rsi,rsi
  40de26:	je     40de41 <__swc_fn_6b1cf01f_000050_e33921d7+0x161>
  40de28:	mov    QWORD PTR [r13+0x0],r14
  40de2c:	mov    rax,rsi
  40de2f:	add    rsp,0x1f8
  40de36:	pop    r15
  40de38:	pop    r14
  40de3a:	pop    r13
  40de3c:	pop    r12
  40de3e:	pop    rdi
  40de3f:	pop    rsi
  40de40:	ret
  40de41:	mov    r14,r15
  40de44:	jmp    40dd30 <__swc_fn_6b1cf01f_000050_e33921d7+0x50>
  40de49:	cs nop WORD PTR [rax+rax*1+0x0]
  40de53:	cs nop WORD PTR [rax+rax*1+0x0]
  40de5d:	nop    DWORD PTR [rax]
  40de60:	mov    rcx,rdi
  40de63:	mov    rdx,r12
  40de66:	mov    r8d,esi
  40de69:	call   4079e0 <__swc_fn_6b1cf01f_000045_06cec934>
  40de6e:	mov    r14,rax
  40de71:	test   rax,rax
  40de74:	jne    40de8a <__swc_fn_6b1cf01f_000050_e33921d7+0x1aa>
  40de76:	xor    eax,eax
  40de78:	add    rsp,0x1f8
  40de7f:	pop    r15
  40de81:	pop    r14
  40de83:	pop    r13
  40de85:	pop    r12
  40de87:	pop    rdi
  40de88:	pop    rsi
  40de89:	ret
  40de8a:	mov    QWORD PTR [r13+0x0],r14
  40de8e:	mov    rax,QWORD PTR [r14]
  40de91:	test   rax,rax
  40de94:	je     40dea6 <__swc_fn_6b1cf01f_000050_e33921d7+0x1c6>
  40de96:	mov    rcx,QWORD PTR [rax]
  40de99:	mov    QWORD PTR [r14],rcx
  40de9c:	add    DWORD PTR [r14+0x28],0x1
  40dea1:	mov    r15,rax
  40dea4:	jmp    40dec6 <__swc_fn_6b1cf01f_000050_e33921d7+0x1e6>
  40dea6:	mov    rax,QWORD PTR [r14+0x18]
  40deaa:	cmp    QWORD PTR [r14+0x20],rax
  40deae:	jae    40dec3 <__swc_fn_6b1cf01f_000050_e33921d7+0x1e3>
  40deb0:	mov    r15,QWORD PTR [r14+0x20]
  40deb4:	mov    eax,DWORD PTR [r14+0x2c]
  40deb8:	add    QWORD PTR [r14+0x20],rax
  40debc:	add    DWORD PTR [r14+0x28],0x1
  40dec1:	jmp    40dec6 <__swc_fn_6b1cf01f_000050_e33921d7+0x1e6>
  40dec3:	xor    r15d,r15d
  40dec6:	test   r15,r15
  40dec9:	jne    40df0e <__swc_fn_6b1cf01f_000050_e33921d7+0x22e>
  40decb:	mov    rcx,r14
  40dece:	call   407320 <__swc_fn_6b1cf01f_000006_12cb36a2>
  40ded3:	test   al,al
  40ded5:	je     40df0e <__swc_fn_6b1cf01f_000050_e33921d7+0x22e>
  40ded7:	mov    rax,QWORD PTR [r14]
  40deda:	test   rax,rax
  40dedd:	je     40deec <__swc_fn_6b1cf01f_000050_e33921d7+0x20c>
  40dedf:	mov    rcx,QWORD PTR [rax]
  40dee2:	mov    QWORD PTR [r14],rcx
  40dee5:	add    DWORD PTR [r14+0x28],0x1
  40deea:	jmp    40df0b <__swc_fn_6b1cf01f_000050_e33921d7+0x22b>
  40deec:	mov    rax,QWORD PTR [r14+0x18]
  40def0:	cmp    QWORD PTR [r14+0x20],rax
  40def4:	jae    40df09 <__swc_fn_6b1cf01f_000050_e33921d7+0x229>
  40def6:	mov    rax,QWORD PTR [r14+0x20]
  40defa:	mov    ecx,DWORD PTR [r14+0x2c]
  40defe:	add    QWORD PTR [r14+0x20],rcx
  40df02:	add    DWORD PTR [r14+0x28],0x1
  40df07:	jmp    40df0b <__swc_fn_6b1cf01f_000050_e33921d7+0x22b>
  40df09:	xor    eax,eax
  40df0b:	mov    r15,rax
  40df0e:	test   r15,r15
  40df11:	je     40de60 <__swc_fn_6b1cf01f_000050_e33921d7+0x180>
  40df17:	mov    rax,r15
  40df1a:	add    rsp,0x1f8
  40df21:	pop    r15
  40df23:	pop    r14
  40df25:	pop    r13
  40df27:	pop    r12
  40df29:	pop    rdi
  40df2a:	pop    rsi
  40df2b:	ret
  40df2c:	add    BYTE PTR [rax],al
	...

000000000040df30 <__swc_fn_6b1cf01f_000053_a8a124d6>:
  40df30:	push   rsi
  40df31:	push   rdi
  40df32:	push   r12
  40df34:	mov    rsi,rdx
  40df37:	mov    rax,rdx
  40df3a:	shr    rax,0xc
  40df3e:	movabs rdx,0x9e3779b97f4a7c15
  40df48:	imul   rax,rdx
  40df4c:	shr    rax,0x20
  40df50:	lea    rax,[rax*8+0x0]
  40df58:	shr    rax,0x20
  40df5c:	lea    rax,[rax*8+0x0]
  40df64:	lea    rax,[rcx+rax*8+0x40]
  40df69:	xor    edx,edx
  40df6b:	test   dl,dl
  40df6d:	lea    rdi,[rcx+0x8]
  40df71:	cmove  rdi,rax
  40df75:	xor    edx,edx
  40df77:	test   dl,dl
  40df79:	lea    r12,[rcx+0x30]
  40df7d:	lea    rax,[rax+0x8]
  40df81:	cmove  r12,rax
  40df85:	mov    rcx,rdi
  40df88:	call   4098a0 <__swc_fn_6b1cf01f_000135_1fec60ac>
  40df8d:	mov    QWORD PTR [rsi+0x30],0x0
  40df95:	mov    rax,QWORD PTR [r12]
  40df99:	mov    QWORD PTR [rsi+0x38],rax
  40df9d:	test   rax,rax
  40dfa0:	je     40dfaa <__swc_fn_6b1cf01f_000053_a8a124d6+0x7a>
  40dfa2:	mov    rax,QWORD PTR [rsi+0x38]
  40dfa6:	mov    QWORD PTR [rax+0x30],rsi
  40dfaa:	mov    QWORD PTR [r12],rsi
  40dfae:	mov    rcx,rdi
  40dfb1:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  40dfb6:	pop    r12
  40dfb8:	pop    rdi
  40dfb9:	pop    rsi
  40dfba:	ret
  40dfbb:	add    BYTE PTR [rax],al
  40dfbd:	add    BYTE PTR [rax],al
	...

000000000040dfc0 <__swc_fn_6b1cf01f_000056_cfedf3f4>:
  40dfc0:	lea    rax,[rdx+rdx*4]
  40dfc4:	lea    rax,[rcx+rax*8+0x268]
  40dfcc:	mov    rdx,QWORD PTR [rax+0x10]
  40dfd0:	sub    QWORD PTR [rcx+0x2a68],rdx
  40dfd7:	sub    QWORD PTR [rcx+0x2a70],0x1
  40dfdf:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40dfe6:	lea    rdx,[rdx+rdx*4]
  40dfea:	lea    rdx,[rcx+rdx*8+0x268]
  40dff2:	vmovups xmm0,XMMWORD PTR [rdx]
  40dff6:	vmovups XMMWORD PTR [rax],xmm0
  40dffa:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40dfff:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e004:	mov    rcx,QWORD PTR [rdx+0x20]
  40e008:	mov    QWORD PTR [rax+0x20],rcx
  40e00c:	ret
  40e00d:	add    BYTE PTR [rax],al
	...

000000000040e010 <__swc_fn_6b1cf01f_000059_c8e1ff6b>:
  40e010:	push   rsi
  40e011:	push   rdi
  40e012:	push   r12
  40e014:	push   r13
  40e016:	sub    rsp,0x8
  40e01a:	mov    rsi,r8
  40e01d:	mov    rdi,rcx
  40e020:	mov    r12,rdx
  40e023:	xor    r13d,r13d
  40e026:	cs nop WORD PTR [rax+rax*1+0x0]
  40e030:	mov    eax,DWORD PTR [r12+0x730]
  40e038:	cmp    r13d,eax
  40e03b:	jae    40e0a1 <__swc_fn_6b1cf01f_000059_c8e1ff6b+0x91>
  40e03d:	lea    rax,[r13+r13*4+0x0]
  40e042:	lea    rax,[r12+rax*8+0x738]
  40e04a:	mov    rdx,QWORD PTR [rax]
  40e04d:	mov    r8,QWORD PTR [rax+0x8]
  40e051:	mov    r9,QWORD PTR [rax+0x10]
  40e055:	cmp    QWORD PTR [rax+0x20],rsi
  40e059:	jb     40e060 <__swc_fn_6b1cf01f_000059_c8e1ff6b+0x50>
  40e05b:	inc    r13d
  40e05e:	jmp    40e030 <__swc_fn_6b1cf01f_000059_c8e1ff6b+0x20>
  40e060:	sub    DWORD PTR [r12+0x730],0x1
  40e069:	mov    ecx,DWORD PTR [r12+0x730]
  40e071:	lea    rcx,[rcx+rcx*4]
  40e075:	lea    rcx,[r12+rcx*8+0x738]
  40e07d:	vmovups xmm0,XMMWORD PTR [rcx]
  40e081:	vmovups XMMWORD PTR [rax],xmm0
  40e085:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40e08a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e08f:	mov    rcx,QWORD PTR [rcx+0x20]
  40e093:	mov    QWORD PTR [rax+0x20],rcx
  40e097:	mov    rcx,rdi
  40e09a:	call   407750 <__swc_fn_6b1cf01f_000039_05a50673>
  40e09f:	jmp    40e030 <__swc_fn_6b1cf01f_000059_c8e1ff6b+0x20>
  40e0a1:	add    rsp,0x8
  40e0a5:	pop    r13
  40e0a7:	pop    r12
  40e0a9:	pop    rdi
  40e0aa:	pop    rsi
  40e0ab:	ret
  40e0ac:	add    BYTE PTR [rax],al
	...

000000000040e0b0 <__swc_fn_6b1cf01f_000062_baa48dba>:
  40e0b0:	push   rsi
  40e0b1:	push   rdi
  40e0b2:	push   r12
  40e0b4:	push   r13
  40e0b6:	push   r14
  40e0b8:	mov    rsi,rcx
  40e0bb:	mov    rdi,rdx
  40e0be:	mov    r12,QWORD PTR [rdi]
  40e0c1:	mov    r13,QWORD PTR [rdi+0x18]
  40e0c5:	mov    rax,r12
  40e0c8:	add    rax,QWORD PTR [rdi+0x8]
  40e0cc:	sub    rax,r13
  40e0cf:	cmp    r8,rax
  40e0d2:	jbe    40e0dd <__swc_fn_6b1cf01f_000062_baa48dba+0x2d>
  40e0d4:	pop    r14
  40e0d6:	pop    r13
  40e0d8:	pop    r12
  40e0da:	pop    rdi
  40e0db:	pop    rsi
  40e0dc:	ret
  40e0dd:	lea    rax,[r13+r8*1+0x0]
  40e0e2:	sub    rax,r12
  40e0e5:	mov    ecx,0x1000
  40e0ea:	test   ecx,ecx
  40e0ec:	mov    edx,0x8
  40e0f1:	cmove  ecx,edx
  40e0f4:	dec    rcx
  40e0f7:	mov    rdx,0xffffffffffffffff
  40e0fe:	sub    rdx,rcx
  40e101:	cmp    rax,rdx
  40e104:	jbe    40e10b <__swc_fn_6b1cf01f_000062_baa48dba+0x5b>
  40e106:	xor    r14d,r14d
  40e109:	jmp    40e116 <__swc_fn_6b1cf01f_000062_baa48dba+0x66>
  40e10b:	add    rax,rcx
  40e10e:	andn   rax,rcx,rax
  40e113:	mov    r14,rax
  40e116:	mov    rax,QWORD PTR [rdi+0x10]
  40e11a:	cmp    r14,rax
  40e11d:	ja     40e128 <__swc_fn_6b1cf01f_000062_baa48dba+0x78>
  40e11f:	pop    r14
  40e121:	pop    r13
  40e123:	pop    r12
  40e125:	pop    rdi
  40e126:	pop    rsi
  40e127:	ret
  40e128:	mov    rax,r12
  40e12b:	add    rax,QWORD PTR [rdi+0x10]
  40e12f:	mov    rdx,r14
  40e132:	sub    rdx,QWORD PTR [rdi+0x10]
  40e136:	mov    rcx,rax
  40e139:	call   4072a0 <__swc_fn_6b1cf01f_000003_644dadb7>
  40e13e:	test   al,al
  40e140:	jne    40e14b <__swc_fn_6b1cf01f_000062_baa48dba+0x9b>
  40e142:	pop    r14
  40e144:	pop    r13
  40e146:	pop    r12
  40e148:	pop    rdi
  40e149:	pop    rsi
  40e14a:	ret
  40e14b:	add    r12,r14
  40e14e:	sub    r12,r13
  40e151:	mov    rcx,r12
  40e154:	sub    rcx,QWORD PTR [rdi+0x28]
  40e158:	mov    rdx,QWORD PTR [rsi+0x250]
  40e15f:	nop
  40e160:	lea    r8,[rdx+rcx*1]
  40e164:	mov    rax,rdx
  40e167:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40e170:	cmp    rax,rdx
  40e173:	je     40e17a <__swc_fn_6b1cf01f_000062_baa48dba+0xca>
  40e175:	mov    rdx,rax
  40e178:	jmp    40e160 <__swc_fn_6b1cf01f_000062_baa48dba+0xb0>
  40e17a:	mov    QWORD PTR [rdi+0x10],r14
  40e17e:	mov    QWORD PTR [rdi+0x28],r12
  40e182:	pop    r14
  40e184:	pop    r13
  40e186:	pop    r12
  40e188:	pop    rdi
  40e189:	pop    rsi
  40e18a:	ret
  40e18b:	add    BYTE PTR [rax],al
  40e18d:	add    BYTE PTR [rax],al
	...

000000000040e190 <__swc_fn_6b1cf01f_000065_cd9dd53e>:
  40e190:	push   rbx
  40e191:	push   rsi
  40e192:	push   rdi
  40e193:	push   r12
  40e195:	push   r13
  40e197:	sub    rsp,0xe0
  40e19e:	mov    rbx,rdx
  40e1a1:	mov    rsi,rcx
  40e1a4:	cmp    DWORD PTR [rbx+0x58],0x0
  40e1a8:	je     40e1cc <__swc_fn_6b1cf01f_000065_cd9dd53e+0x3c>
  40e1aa:	mov    eax,DWORD PTR [rbx+0x58]
  40e1ad:	sub    eax,0x1
  40e1b0:	test   DWORD PTR [rbx+0x58],eax
  40e1b3:	je     40e1cc <__swc_fn_6b1cf01f_000065_cd9dd53e+0x3c>
  40e1b5:	mov    QWORD PTR [rbx+0x40],0x0
  40e1bd:	add    rsp,0xe0
  40e1c4:	pop    r13
  40e1c6:	pop    r12
  40e1c8:	pop    rdi
  40e1c9:	pop    rsi
  40e1ca:	pop    rbx
  40e1cb:	ret
  40e1cc:	mov    rax,QWORD PTR [rbx+0x40]
  40e1d0:	test   rax,rax
  40e1d3:	jne    40e1ef <__swc_fn_6b1cf01f_000065_cd9dd53e+0x5f>
  40e1d5:	mov    rcx,rsi
  40e1d8:	mov    rdx,rbx
  40e1db:	call   40b7b0 <__swc_fn_6b1cf01f_000064_6905bec4>
  40e1e0:	add    rsp,0xe0
  40e1e7:	pop    r13
  40e1e9:	pop    r12
  40e1eb:	pop    rdi
  40e1ec:	pop    rsi
  40e1ed:	pop    rbx
  40e1ee:	ret
  40e1ef:	cmp    QWORD PTR [rbx+0x48],0x0
  40e1f4:	jne    40e210 <__swc_fn_6b1cf01f_000065_cd9dd53e+0x80>
  40e1f6:	mov    rcx,rsi
  40e1f9:	mov    rdx,rbx
  40e1fc:	call   407f90 <__swc_fn_6b1cf01f_000066_77c6e829>
  40e201:	add    rsp,0xe0
  40e208:	pop    r13
  40e20a:	pop    r12
  40e20c:	pop    rdi
  40e20d:	pop    rsi
  40e20e:	pop    rbx
  40e20f:	ret
  40e210:	mov    rdi,QWORD PTR [rbx+0x40]
  40e214:	lea    rax,[rip+0x15e55]        # 424070 <__swc_bss_base_6b1cf01f+0x30>
  40e21b:	mov    rcx,rdi
  40e21e:	sub    rcx,QWORD PTR [rax+0x8]
  40e222:	mov    rax,QWORD PTR [rip+0x15e57]        # 424080 <__swc_bss_base_6b1cf01f+0x40>
  40e229:	cmp    rcx,rax
  40e22c:	jae    40e258 <__swc_fn_6b1cf01f_000065_cd9dd53e+0xc8>
  40e22e:	mov    rax,rdi
  40e231:	and    rax,0xffffffffffc00000
  40e238:	mov    rcx,rdi
  40e23b:	shr    rcx,0x10
  40e23f:	and    ecx,0x3f
  40e242:	mov    edx,DWORD PTR [rax+0x28]
  40e245:	shrx   ecx,ecx,edx
  40e24a:	shl    rcx,0x4
  40e24e:	lea    r12,[rax+rcx*8+0x80]
  40e256:	jmp    40e263 <__swc_fn_6b1cf01f_000065_cd9dd53e+0xd3>
  40e258:	mov    rcx,rdi
  40e25b:	call   40a830 <__swc_fn_6b1cf01f_000022_77c2d682>
  40e260:	mov    r12,rax
  40e263:	test   r12,r12
  40e266:	je     40e275 <__swc_fn_6b1cf01f_000065_cd9dd53e+0xe5>
  40e268:	mov    eax,DWORD PTR [r12+0x2c]
  40e26d:	mov    r9d,eax
  40e270:	mov    r13,rax
  40e273:	jmp    40e2f4 <__swc_fn_6b1cf01f_000065_cd9dd53e+0x164>
  40e275:	mov    rcx,rsi
  40e278:	mov    rdx,rdi
  40e27b:	call   40ae40 <__swc_fn_6b1cf01f_000052_26c6c1c4>
  40e280:	mov    rcx,QWORD PTR [rax+0x28]
  40e284:	mov    r9,rcx
  40e287:	mov    rdx,QWORD PTR [rax+0x20]
  40e28b:	mov    r13,rdx
  40e28e:	cmp    QWORD PTR [rbx+0x48],rcx
  40e292:	jbe    40e2cb <__swc_fn_6b1cf01f_000065_cd9dd53e+0x13b>
  40e294:	mov    ecx,DWORD PTR [rax+0x48]
  40e297:	cmp    DWORD PTR [rbx+0x58],ecx
  40e29a:	ja     40e2cb <__swc_fn_6b1cf01f_000065_cd9dd53e+0x13b>
  40e29c:	mov    rcx,rsi
  40e29f:	mov    rdx,rax
  40e2a2:	mov    r8,QWORD PTR [rbx+0x48]
  40e2a6:	mov    QWORD PTR [rsp+0xc8],r9
  40e2ae:	mov    QWORD PTR [rsp+0xd0],rax
  40e2b6:	call   40e0b0 <__swc_fn_6b1cf01f_000062_baa48dba>
  40e2bb:	mov    r9,QWORD PTR [rsp+0xc8]
  40e2c3:	mov    rax,QWORD PTR [rsp+0xd0]
  40e2cb:	mov    rcx,QWORD PTR [rax+0x28]
  40e2cf:	cmp    QWORD PTR [rbx+0x48],rcx
  40e2d3:	ja     40e2f4 <__swc_fn_6b1cf01f_000065_cd9dd53e+0x164>
  40e2d5:	mov    ecx,DWORD PTR [rax+0x48]
  40e2d8:	cmp    DWORD PTR [rbx+0x58],ecx
  40e2db:	ja     40e2f4 <__swc_fn_6b1cf01f_000065_cd9dd53e+0x164>
  40e2dd:	mov    rcx,QWORD PTR [rbx+0x48]
  40e2e1:	mov    QWORD PTR [rax+0x20],rcx
  40e2e5:	add    rsp,0xe0
  40e2ec:	pop    r13
  40e2ee:	pop    r12
  40e2f0:	pop    rdi
  40e2f1:	pop    rsi
  40e2f2:	pop    rbx
  40e2f3:	ret
  40e2f4:	test   r12,r12
  40e2f7:	je     40e329 <__swc_fn_6b1cf01f_000065_cd9dd53e+0x199>
  40e2f9:	cmp    QWORD PTR [rbx+0x48],r9
  40e2fd:	ja     40e329 <__swc_fn_6b1cf01f_000065_cd9dd53e+0x199>
  40e2ff:	cmp    DWORD PTR [rbx+0x58],0x40
  40e303:	ja     40e329 <__swc_fn_6b1cf01f_000065_cd9dd53e+0x199>
  40e305:	cmp    DWORD PTR [rbx+0x58],0x0
  40e309:	je     40e316 <__swc_fn_6b1cf01f_000065_cd9dd53e+0x186>
  40e30b:	mov    ecx,DWORD PTR [rbx+0x58]
  40e30e:	dec    rcx
  40e311:	test   rdi,rcx
  40e314:	jne    40e329 <__swc_fn_6b1cf01f_000065_cd9dd53e+0x199>
  40e316:	mov    QWORD PTR [rbx+0x40],rdi
  40e31a:	add    rsp,0xe0
  40e321:	pop    r13
  40e323:	pop    r12
  40e325:	pop    rdi
  40e326:	pop    rsi
  40e327:	pop    rbx
  40e328:	ret
  40e329:	vmovups xmm0,XMMWORD PTR [rbx]
  40e32d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e333:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40e338:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e33e:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40e343:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e349:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40e34e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40e354:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40e359:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40e35f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40e364:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40e36a:	mov    QWORD PTR [rsp+0x48],0x0
  40e373:	mov    rcx,rsi
  40e376:	lea    rdx,[rsp+0x8]
  40e37b:	call   40b7b0 <__swc_fn_6b1cf01f_000064_6905bec4>
  40e380:	mov    rax,QWORD PTR [rsp+0x48]
  40e385:	test   rax,rax
  40e388:	jne    40e3a1 <__swc_fn_6b1cf01f_000065_cd9dd53e+0x211>
  40e38a:	mov    QWORD PTR [rbx+0x40],0x0
  40e392:	add    rsp,0xe0
  40e399:	pop    r13
  40e39b:	pop    r12
  40e39d:	pop    rdi
  40e39e:	pop    rsi
  40e39f:	pop    rbx
  40e3a0:	ret
  40e3a1:	mov    rax,QWORD PTR [rbx+0x48]
  40e3a5:	cmp    r13,rax
  40e3a8:	cmovbe rax,r13
  40e3ac:	mov    rcx,QWORD PTR [rsp+0x48]
  40e3b1:	mov    rdx,rdi
  40e3b4:	mov    r8,rax
  40e3b7:	call   4090e0 <__swc_fn_6b1cf01f_000105_b7aef7c0>
  40e3bc:	vmovups xmm0,XMMWORD PTR [rbx]
  40e3c0:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40e3c6:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40e3cb:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40e3d1:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40e3d6:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40e3df:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40e3e4:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40e3ed:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40e3f2:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40e3fb:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40e400:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40e409:	mov    QWORD PTR [rsp+0xa8],rdi
  40e411:	mov    rcx,rsi
  40e414:	lea    rdx,[rsp+0x68]
  40e419:	call   407f90 <__swc_fn_6b1cf01f_000066_77c6e829>
  40e41e:	mov    rax,QWORD PTR [rsp+0x48]
  40e423:	mov    QWORD PTR [rbx+0x40],rax
  40e427:	add    rsp,0xe0
  40e42e:	pop    r13
  40e430:	pop    r12
  40e432:	pop    rdi
  40e433:	pop    rsi
  40e434:	pop    rbx
  40e435:	ret
	...

000000000040e440 <__swc_fn_6b1cf01f_000068_557d6092>:
  40e440:	push   r12
  40e442:	push   rdi
  40e443:	push   rsi
  40e444:	push   r13
  40e446:	push   r14
  40e448:	sub    rsp,0x190
  40e44f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40e458:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40e461:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40e46a:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40e473:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40e47c:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40e485:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40e48e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40e497:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40e4a0:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40e4a9:	mov    r12,rcx
  40e4ac:	lea    rax,[rip+0x13b4d]        # 422000 <__swc_data_base_6b1cf01f>
  40e4b3:	mov    rax,QWORD PTR [rax]
  40e4b6:	cmp    rax,0xffffffffffffffff
  40e4ba:	je     40e4c9 <__swc_fn_6b1cf01f_000068_557d6092+0x89>
  40e4bc:	mov    eax,eax
  40e4be:	mov    edi,eax
  40e4c0:	xor    eax,eax
  40e4c2:	call   407000 <pthread_getspecific@plt>
  40e4c7:	jmp    40e4cb <__swc_fn_6b1cf01f_000068_557d6092+0x8b>
  40e4c9:	xor    eax,eax
  40e4cb:	test   rax,rax
  40e4ce:	jne    40e4dd <__swc_fn_6b1cf01f_000068_557d6092+0x9d>
  40e4d0:	call   40a900 <__swc_fn_6b1cf01f_000031_ed8d61a9>
  40e4d5:	mov    rcx,rax
  40e4d8:	call   40fc00 <__swc_fn_6b1cf01f_000128_9c45d2d7>
  40e4dd:	test   rax,rax
  40e4e0:	je     40e506 <__swc_fn_6b1cf01f_000068_557d6092+0xc6>
  40e4e2:	cmp    QWORD PTR [rax],r12
  40e4e5:	jne    40e506 <__swc_fn_6b1cf01f_000068_557d6092+0xc6>
  40e4e7:	xor    ecx,ecx
  40e4e9:	mov    QWORD PTR [rsp+0xc8],rax
  40e4f1:	call   407720 <__swc_fn_6b1cf01f_000033_7d7574b6>
  40e4f6:	mov    rdx,QWORD PTR [rsp+0xc8]
  40e4fe:	mov    rcx,r12
  40e501:	call   407840 <__swc_fn_6b1cf01f_000042_70d5ab54>
  40e506:	lea    rsi,[r12+0x10]
  40e50b:	mov    rcx,rsi
  40e50e:	call   4098a0 <__swc_fn_6b1cf01f_000135_1fec60ac>
  40e513:	mov    rdi,QWORD PTR [r12+0x20]
  40e518:	test   rdi,rdi
  40e51b:	je     40e55e <__swc_fn_6b1cf01f_000068_557d6092+0x11e>
  40e51d:	nop    DWORD PTR [rax]
  40e520:	mov    rcx,r12
  40e523:	mov    rdx,rdi
  40e526:	call   40aac0 <__swc_fn_6b1cf01f_000043_3755033a>
  40e52b:	mov    rcx,r12
  40e52e:	mov    rdx,rdi
  40e531:	mov    r8,0xffffffffffffffff
  40e538:	call   40e010 <__swc_fn_6b1cf01f_000059_c8e1ff6b>
  40e53d:	mov    rcx,r12
  40e540:	mov    rdx,rdi
  40e543:	mov    r8d,0x9b8
  40e549:	mov    r9d,0x9b8
  40e54f:	call   407750 <__swc_fn_6b1cf01f_000039_05a50673>
  40e554:	mov    rdi,QWORD PTR [r12+0x20]
  40e559:	test   rdi,rdi
  40e55c:	jne    40e520 <__swc_fn_6b1cf01f_000068_557d6092+0xe0>
  40e55e:	xor    eax,eax
  40e560:	xchg   QWORD PTR [r12+0x2a80],rax
  40e568:	test   rax,rax
  40e56b:	je     40e591 <__swc_fn_6b1cf01f_000068_557d6092+0x151>
  40e56d:	cs nop WORD PTR [rax+rax*1+0x0]
  40e577:	nop    WORD PTR [rax+rax*1+0x0]
  40e580:	mov    rcx,rax
  40e583:	mov    rax,QWORD PTR [rax+0x78]
  40e587:	xor    edx,edx
  40e589:	xchg   DWORD PTR [rcx+0x70],edx
  40e58c:	test   rax,rax
  40e58f:	jne    40e580 <__swc_fn_6b1cf01f_000068_557d6092+0x140>
  40e591:	mov    rax,QWORD PTR [r12+0x18]
  40e596:	mov    rdi,rax
  40e599:	test   rdi,rdi
  40e59c:	je     40e631 <__swc_fn_6b1cf01f_000068_557d6092+0x1f1>
  40e5a2:	cs nop WORD PTR [rax+rax*1+0x0]
  40e5ac:	nop    DWORD PTR [rax+0x0]
  40e5b0:	mov    rax,QWORD PTR [rdi+0x10]
  40e5b4:	mov    r8d,DWORD PTR [rdi+0x2c]
  40e5b8:	xor    r9d,r9d
  40e5bb:	test   r8,r8
  40e5be:	jbe    40e61d <__swc_fn_6b1cf01f_000068_557d6092+0x1dd>
  40e5c0:	mov    ecx,r9d
  40e5c3:	shl    rcx,0x4
  40e5c7:	lea    rdx,[rdi+rcx*8+0x80]
  40e5cf:	cmp    BYTE PTR [rdx+0x3b],0x0
  40e5d3:	je     40e614 <__swc_fn_6b1cf01f_000068_557d6092+0x1d4>
  40e5d5:	mov    DWORD PTR [rdx+0x28],0x0
  40e5dc:	mov    rcx,rdi
  40e5df:	mov    QWORD PTR [rsp+0xd0],rax
  40e5e7:	mov    QWORD PTR [rsp+0xd8],r8
  40e5ef:	mov    QWORD PTR [rsp+0xe0],r9
  40e5f7:	call   40d740 <__swc_fn_6b1cf01f_000014_1acdaf22>
  40e5fc:	mov    rax,QWORD PTR [rsp+0xd0]
  40e604:	mov    r8,QWORD PTR [rsp+0xd8]
  40e60c:	mov    r9,QWORD PTR [rsp+0xe0]
  40e614:	add    r9,0x1
  40e618:	cmp    r9,r8
  40e61b:	jb     40e5c0 <__swc_fn_6b1cf01f_000068_557d6092+0x180>
  40e61d:	mov    rcx,rdi
  40e620:	mov    rdi,rax
  40e623:	call   407630 <__swc_fn_6b1cf01f_000021_fe13ecad>
  40e628:	test   rdi,rdi
  40e62b:	jne    40e5b0 <__swc_fn_6b1cf01f_000068_557d6092+0x170>
  40e631:	mov    QWORD PTR [r12+0x18],0x0
  40e63a:	mov    QWORD PTR [r12+0x28],0x0
  40e643:	mov    rcx,rsi
  40e646:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  40e64b:	mov    esi,0x8
  40e650:	xor    edi,edi
  40e652:	test   rsi,rsi
  40e655:	je     40e6b2 <__swc_fn_6b1cf01f_000068_557d6092+0x272>
  40e65b:	nop    DWORD PTR [rax+rax*1+0x0]
  40e660:	lea    r13,[rdi*8+0x0]
  40e668:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40e66d:	test   r14,r14
  40e670:	je     40e6a8 <__swc_fn_6b1cf01f_000068_557d6092+0x268>
  40e672:	cs nop WORD PTR [rax+rax*1+0x0]
  40e67c:	nop    DWORD PTR [rax+0x0]
  40e680:	mov    rcx,r12
  40e683:	mov    rdx,r14
  40e686:	call   407df0 <__swc_fn_6b1cf01f_000054_1dfec8f6>
  40e68b:	mov    rcx,r12
  40e68e:	mov    rdx,QWORD PTR [r14]
  40e691:	mov    r8,QWORD PTR [r14+0x8]
  40e695:	mov    r9,QWORD PTR [r14+0x10]
  40e699:	call   407750 <__swc_fn_6b1cf01f_000039_05a50673>
  40e69e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40e6a3:	test   r14,r14
  40e6a6:	jne    40e680 <__swc_fn_6b1cf01f_000068_557d6092+0x240>
  40e6a8:	add    rdi,0x1
  40e6ac:	sub    rsi,0x1
  40e6b0:	jne    40e660 <__swc_fn_6b1cf01f_000068_557d6092+0x220>
  40e6b2:	mov    rcx,r12
  40e6b5:	call   407ec0 <__swc_fn_6b1cf01f_000060_9d59636e>
  40e6ba:	lea    rcx,[r12+0x250]
  40e6c2:	mov    rdx,QWORD PTR [rcx]
  40e6c5:	mov    r8,QWORD PTR [r12+0x250]
  40e6cd:	nop    DWORD PTR [rax]
  40e6d0:	mov    r9,r8
  40e6d3:	sub    r9,rdx
  40e6d6:	mov    rax,r8
  40e6d9:	lock cmpxchg QWORD PTR [rcx],r9
  40e6de:	cmp    rax,r8
  40e6e1:	je     40e6e8 <__swc_fn_6b1cf01f_000068_557d6092+0x2a8>
  40e6e3:	mov    r8,rax
  40e6e6:	jmp    40e6d0 <__swc_fn_6b1cf01f_000068_557d6092+0x290>
  40e6e8:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40e6f1:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40e6fa:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40e703:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40e70c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40e715:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40e71e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40e727:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40e730:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40e739:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40e742:	add    rsp,0x190
  40e749:	pop    r14
  40e74b:	pop    r13
  40e74d:	pop    rsi
  40e74e:	pop    rdi
  40e74f:	pop    r12
  40e751:	ret
	...

000000000040e760 <__swc_fn_6b1cf01f_000071_7e144e9b>:
  40e760:	sub    rsp,0x8
  40e764:	mov    QWORD PTR [rdx+0x40],0x0
  40e76c:	call   40b7b0 <__swc_fn_6b1cf01f_000064_6905bec4>
  40e771:	add    rsp,0x8
  40e775:	ret
	...

000000000040e780 <__swc_fn_6b1cf01f_000074_9eaf4878>:
  40e780:	sub    rsp,0x8
  40e784:	call   407f90 <__swc_fn_6b1cf01f_000066_77c6e829>
  40e789:	add    rsp,0x8
  40e78d:	ret
	...

000000000040e790 <__swc_fn_6b1cf01f_000077_e793b5e1>:
  40e790:	push   rbx
  40e791:	push   rsi
  40e792:	push   rdi
  40e793:	push   r12
  40e795:	push   r13
  40e797:	push   r14
  40e799:	push   r15
  40e79b:	sub    rsp,0x20
  40e79f:	mov    rbx,r11
  40e7a2:	mov    rsi,rcx
  40e7a5:	mov    rdi,rdx
  40e7a8:	mov    r12,r8
  40e7ab:	mov    r13,r9
  40e7ae:	mov    r14,r10
  40e7b1:	mov    rcx,QWORD PTR [rip+0x18588]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40e7b8:	test   rcx,rcx
  40e7bb:	jne    40e7cd <__swc_fn_6b1cf01f_000077_e793b5e1+0x3d>
  40e7bd:	call   40a1a0 <__swc_fn_6b1cf01f_000165_e09accff>
  40e7c2:	lea    rcx,[rax+0x1]
  40e7c6:	mov    QWORD PTR [rip+0x18573],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40e7cd:	dec    rcx
  40e7d0:	call   411680 <__swc_fn_6b1cf01f_000167_3130645d>
  40e7d5:	mov    r15,rax
  40e7d8:	lea    r11,[rip+0x15a61]        # 424240 <__swc_bss_base_6b1cf01f+0x200>
  40e7df:	mov    rcx,r11
  40e7e2:	call   407740 <__swc_fn_6b1cf01f_000036_62160bb3>
  40e7e7:	test   al,al
  40e7e9:	jne    40e7fa <__swc_fn_6b1cf01f_000077_e793b5e1+0x6a>
  40e7eb:	mov    rcx,r11
  40e7ee:	call   40a960 <__swc_fn_6b1cf01f_000034_c72914a2>
  40e7f3:	lea    r11,[rip+0x15a46]        # 424240 <__swc_bss_base_6b1cf01f+0x200>
  40e7fa:	mov    rcx,r11
  40e7fd:	mov    rdx,rsi
  40e800:	mov    r8,rdi
  40e803:	mov    r9,r12
  40e806:	mov    r10,r13
  40e809:	mov    rsi,r11
  40e80c:	mov    r11,r14
  40e80f:	call   40dab0 <__swc_fn_6b1cf01f_000035_6105596e>
  40e814:	test   bl,bl
  40e816:	je     40e83d <__swc_fn_6b1cf01f_000077_e793b5e1+0xad>
  40e818:	mov    QWORD PTR [rsp+0x8],rsi
  40e81d:	lea    rax,[rip+0x492c]        # 413150 <__swc_rdata_base_6b1cf01f+0x40>
  40e824:	mov    QWORD PTR [rsp+0x10],rax
  40e829:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e82f:	vmovups XMMWORD PTR [r15],xmm0
  40e834:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40e83d:	mov    rax,rsi
  40e840:	add    rsp,0x20
  40e844:	pop    r15
  40e846:	pop    r14
  40e848:	pop    r13
  40e84a:	pop    r12
  40e84c:	pop    rdi
  40e84d:	pop    rsi
  40e84e:	pop    rbx
  40e84f:	ret

000000000040e850 <__swc_fn_6b1cf01f_000080_851c599a>:
  40e850:	sub    rsp,0x8
  40e854:	mov    rax,rcx
  40e857:	test   rcx,rcx
  40e85a:	jne    40e861 <__swc_fn_6b1cf01f_000080_851c599a+0x11>
  40e85c:	add    rsp,0x8
  40e860:	ret
  40e861:	lea    rcx,[rax-0x10]
  40e865:	mov    rax,QWORD PTR [rax-0x10]
  40e869:	mov    rdx,rax
  40e86c:	call   40f8b0 <__swc_fn_6b1cf01f_000113_25e345b1>
  40e871:	add    rsp,0x8
  40e875:	ret
	...

000000000040e880 <__swc_fn_6b1cf01f_000083_fb84e43e>:
  40e880:	sub    rsp,0x8
  40e884:	xor    r11d,r11d
  40e887:	call   408250 <__swc_fn_6b1cf01f_000084_746bf146>
  40e88c:	add    rsp,0x8
  40e890:	ret
	...

000000000040e8a0 <__swc_fn_6b1cf01f_000086_ac8c6565>:
  40e8a0:	push   rsi
  40e8a1:	push   rdi
  40e8a2:	push   r12
  40e8a4:	push   r13
  40e8a6:	push   r14
  40e8a8:	push   r15
  40e8aa:	sub    rsp,0x68
  40e8ae:	mov    rsi,r9
  40e8b1:	mov    rdi,rcx
  40e8b4:	mov    r12,rdx
  40e8b7:	mov    r13,r8
  40e8ba:	cmp    r8,r9
  40e8bd:	jne    40e8e5 <__swc_fn_6b1cf01f_000086_ac8c6565+0x45>
  40e8bf:	mov    rcx,rdi
  40e8c2:	mov    rdx,r12
  40e8c5:	xor    r8d,r8d
  40e8c8:	call   4085a0 <__swc_fn_6b1cf01f_000090_9a1d717d>
  40e8cd:	test   al,al
  40e8cf:	je     40e8e5 <__swc_fn_6b1cf01f_000086_ac8c6565+0x45>
  40e8d1:	mov    eax,0x1
  40e8d6:	add    rsp,0x68
  40e8da:	pop    r15
  40e8dc:	pop    r14
  40e8de:	pop    r13
  40e8e0:	pop    r12
  40e8e2:	pop    rdi
  40e8e3:	pop    rsi
  40e8e4:	ret
  40e8e5:	cmp    BYTE PTR [r12+0x2c],0xe
  40e8eb:	je     40e8fe <__swc_fn_6b1cf01f_000086_ac8c6565+0x5e>
  40e8ed:	xor    eax,eax
  40e8ef:	add    rsp,0x68
  40e8f3:	pop    r15
  40e8f5:	pop    r14
  40e8f7:	pop    r13
  40e8f9:	pop    r12
  40e8fb:	pop    rdi
  40e8fc:	pop    rsi
  40e8fd:	ret
  40e8fe:	mov    r14,QWORD PTR [r12+0x98]
  40e906:	mov    rax,QWORD PTR [r12+0xa0]
  40e90e:	mov    r12,rax
  40e911:	xor    r15d,r15d
  40e914:	test   r12,r12
  40e917:	je     40e97f <__swc_fn_6b1cf01f_000086_ac8c6565+0xdf>
  40e919:	nop    DWORD PTR [rax+0x0]
  40e920:	mov    QWORD PTR [rsp+0x58],r12
  40e925:	lea    r12,[r15*8+0x0]
  40e92d:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40e932:	mov    rcx,rax
  40e935:	call   40bf40 <__swc_fn_6b1cf01f_000082_9f4f5092>
  40e93a:	cmp    BYTE PTR [rax+0x2c],0xe
  40e93e:	jne    40e970 <__swc_fn_6b1cf01f_000086_ac8c6565+0xd0>
  40e940:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40e945:	lea    r8,[r13+rcx*1+0x0]
  40e94a:	mov    rcx,rdi
  40e94d:	mov    rdx,rax
  40e950:	mov    r9,rsi
  40e953:	call   40e8a0 <__swc_fn_6b1cf01f_000086_ac8c6565>
  40e958:	test   al,al
  40e95a:	je     40e970 <__swc_fn_6b1cf01f_000086_ac8c6565+0xd0>
  40e95c:	mov    eax,0x1
  40e961:	add    rsp,0x68
  40e965:	pop    r15
  40e967:	pop    r14
  40e969:	pop    r13
  40e96b:	pop    r12
  40e96d:	pop    rdi
  40e96e:	pop    rsi
  40e96f:	ret
  40e970:	add    r15,0x1
  40e974:	mov    r12,QWORD PTR [rsp+0x58]
  40e979:	sub    r12,0x1
  40e97d:	jne    40e920 <__swc_fn_6b1cf01f_000086_ac8c6565+0x80>
  40e97f:	xor    eax,eax
  40e981:	add    rsp,0x68
  40e985:	pop    r15
  40e987:	pop    r14
  40e989:	pop    r13
  40e98b:	pop    r12
  40e98d:	pop    rdi
  40e98e:	pop    rsi
  40e98f:	ret

000000000040e990 <__swc_fn_6b1cf01f_000089_157b05de>:
  40e990:	push   rbp
  40e991:	push   rbx
  40e992:	push   rsi
  40e993:	push   rdi
  40e994:	push   r12
  40e996:	push   r13
  40e998:	push   r14
  40e99a:	push   r15
  40e99c:	sub    rsp,0x38
  40e9a0:	mov    rbp,rsp
  40e9a3:	mov    rbx,r11
  40e9a6:	mov    rsi,rdx
  40e9a9:	mov    rdi,r8
  40e9ac:	mov    r12,r9
  40e9af:	mov    QWORD PTR [rsp+0x18],r9
  40e9b4:	mov    r13,r10
  40e9b7:	movzx  r14d,BYTE PTR [rbp+0x80]
  40e9bf:	movzx  r15d,BYTE PTR [rbp+0x88]
  40e9c7:	test   r11,r11
  40e9ca:	je     40e9d0 <__swc_fn_6b1cf01f_000089_157b05de+0x40>
  40e9cc:	xor    eax,eax
  40e9ce:	mov    BYTE PTR [rbx],al
  40e9d0:	test   r12,r12
  40e9d3:	je     40e9de <__swc_fn_6b1cf01f_000089_157b05de+0x4e>
  40e9d5:	mov    QWORD PTR [r12+0x8],0x0
  40e9de:	test   rcx,rcx
  40e9e1:	je     40e9e8 <__swc_fn_6b1cf01f_000089_157b05de+0x58>
  40e9e3:	test   rsi,rsi
  40e9e6:	jne    40e9fb <__swc_fn_6b1cf01f_000089_157b05de+0x6b>
  40e9e8:	xor    eax,eax
  40e9ea:	add    rsp,0x38
  40e9ee:	pop    r15
  40e9f0:	pop    r14
  40e9f2:	pop    r13
  40e9f4:	pop    r12
  40e9f6:	pop    rdi
  40e9f7:	pop    rsi
  40e9f8:	pop    rbx
  40e9f9:	pop    rbp
  40e9fa:	ret
  40e9fb:	call   40bf40 <__swc_fn_6b1cf01f_000082_9f4f5092>
  40ea00:	mov    r12,rax
  40ea03:	mov    al,r15b
  40ea06:	test   r15b,r15b
  40ea09:	jne    40ea19 <__swc_fn_6b1cf01f_000089_157b05de+0x89>
  40ea0b:	mov    eax,DWORD PTR [r12+0x28]
  40ea10:	and    eax,0x10000
  40ea16:	setne  al
  40ea19:	lea    r15,[rsp+0x8]
  40ea1e:	mov    QWORD PTR [rsp+0x20],r15
  40ea23:	rex mov BYTE PTR [rsp+0x8],al
  40ea28:	test   DWORD PTR [rsi+0x28],0x400000
  40ea2f:	je     40ea67 <__swc_fn_6b1cf01f_000089_157b05de+0xd7>
  40ea31:	test   rsi,rsi
  40ea34:	je     40ea54 <__swc_fn_6b1cf01f_000089_157b05de+0xc4>
  40ea36:	mov    rax,QWORD PTR [rsi+0x38]
  40ea3a:	cmp    QWORD PTR [rax+0x10],rsi
  40ea3e:	jne    40ea54 <__swc_fn_6b1cf01f_000089_157b05de+0xc4>
  40ea40:	rex mov al,BYTE PTR [rsp+0x8]
  40ea45:	test   al,al
  40ea47:	sete   al
  40ea4a:	test   r14b,r14b
  40ea4d:	sete   cl
  40ea50:	test   al,cl
  40ea52:	je     40ea67 <__swc_fn_6b1cf01f_000089_157b05de+0xd7>
  40ea54:	xor    eax,eax
  40ea56:	add    rsp,0x38
  40ea5a:	pop    r15
  40ea5c:	pop    r14
  40ea5e:	pop    r13
  40ea60:	pop    r12
  40ea62:	pop    rdi
  40ea63:	pop    rsi
  40ea64:	pop    rbx
  40ea65:	pop    rbp
  40ea66:	ret
  40ea67:	mov    r15,r12
  40ea6a:	test   r14b,r14b
  40ea6d:	jne    40ea84 <__swc_fn_6b1cf01f_000089_157b05de+0xf4>
  40ea6f:	cmp    BYTE PTR [r12+0x2c],0x6
  40ea75:	jne    40ea84 <__swc_fn_6b1cf01f_000089_157b05de+0xf4>
  40ea77:	mov    rcx,QWORD PTR [r12+0x40]
  40ea7c:	call   40bf40 <__swc_fn_6b1cf01f_000082_9f4f5092>
  40ea81:	mov    r15,rax
  40ea84:	test   r14b,r14b
  40ea87:	je     40ea8d <__swc_fn_6b1cf01f_000089_157b05de+0xfd>
  40ea89:	mov    r15,QWORD PTR [r15+0x30]
  40ea8d:	mov    rcx,rsi
  40ea90:	call   40bf40 <__swc_fn_6b1cf01f_000082_9f4f5092>
  40ea95:	mov    rsi,rax
  40ea98:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40ea9d:	je     40ead4 <__swc_fn_6b1cf01f_000089_157b05de+0x144>
  40ea9f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40eaa4:	je     40ead4 <__swc_fn_6b1cf01f_000089_157b05de+0x144>
  40eaa6:	mov    eax,DWORD PTR [rsi+0x28]
  40eaa9:	and    eax,0x10000
  40eaaf:	je     40ead4 <__swc_fn_6b1cf01f_000089_157b05de+0x144>
  40eab1:	rex mov al,BYTE PTR [rsp+0x8]
  40eab6:	test   al,al
  40eab8:	jne    40eacd <__swc_fn_6b1cf01f_000089_157b05de+0x13d>
  40eaba:	xor    eax,eax
  40eabc:	add    rsp,0x38
  40eac0:	pop    r15
  40eac2:	pop    r14
  40eac4:	pop    r13
  40eac6:	pop    r12
  40eac8:	pop    rdi
  40eac9:	pop    rsi
  40eaca:	pop    rbx
  40eacb:	pop    rbp
  40eacc:	ret
  40eacd:	mov    rax,QWORD PTR [rsi+0x30]
  40ead1:	mov    rsi,rax
  40ead4:	mov    r14b,r13b
  40ead7:	test   rbx,rbx
  40eada:	je     40eb10 <__swc_fn_6b1cf01f_000089_157b05de+0x180>
  40eadc:	cmp    BYTE PTR [r12+0x2c],0x6
  40eae2:	jne    40eb10 <__swc_fn_6b1cf01f_000089_157b05de+0x180>
  40eae4:	lea    rdx,[rip+0x4695]        # 413180 <__swc_rdata_base_6b1cf01f+0x70>
  40eaeb:	mov    rcx,rsi
  40eaee:	xor    r8d,r8d
  40eaf1:	call   4085a0 <__swc_fn_6b1cf01f_000090_9a1d717d>
  40eaf6:	test   al,al
  40eaf8:	je     40eb10 <__swc_fn_6b1cf01f_000089_157b05de+0x180>
  40eafa:	mov    BYTE PTR [rbx],0x1
  40eafd:	xor    eax,eax
  40eaff:	add    rsp,0x38
  40eb03:	pop    r15
  40eb05:	pop    r14
  40eb07:	pop    r13
  40eb09:	pop    r12
  40eb0b:	pop    rdi
  40eb0c:	pop    rsi
  40eb0d:	pop    rbx
  40eb0e:	pop    rbp
  40eb0f:	ret
  40eb10:	test   rdi,rdi
  40eb13:	jne    40eb2d <__swc_fn_6b1cf01f_000089_157b05de+0x19d>
  40eb15:	test   r13b,r13b
  40eb18:	jne    40eb2d <__swc_fn_6b1cf01f_000089_157b05de+0x19d>
  40eb1a:	xor    eax,eax
  40eb1c:	add    rsp,0x38
  40eb20:	pop    r15
  40eb22:	pop    r14
  40eb24:	pop    r13
  40eb26:	pop    r12
  40eb28:	pop    rdi
  40eb29:	pop    rsi
  40eb2a:	pop    rbx
  40eb2b:	pop    rbp
  40eb2c:	ret
  40eb2d:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40eb32:	jne    40ebe8 <__swc_fn_6b1cf01f_000089_157b05de+0x258>
  40eb38:	mov    rcx,r15
  40eb3b:	mov    rdx,rsi
  40eb3e:	xor    r8d,r8d
  40eb41:	call   4085a0 <__swc_fn_6b1cf01f_000090_9a1d717d>
  40eb46:	test   al,al
  40eb48:	jne    40ebe8 <__swc_fn_6b1cf01f_000089_157b05de+0x258>
  40eb4e:	test   DWORD PTR [rsi+0x28],0x10000
  40eb55:	je     40eb73 <__swc_fn_6b1cf01f_000089_157b05de+0x1e3>
  40eb57:	rex mov al,BYTE PTR [rsp+0x8]
  40eb5c:	test   al,al
  40eb5e:	jne    40eb73 <__swc_fn_6b1cf01f_000089_157b05de+0x1e3>
  40eb60:	xor    eax,eax
  40eb62:	add    rsp,0x38
  40eb66:	pop    r15
  40eb68:	pop    r14
  40eb6a:	pop    r13
  40eb6c:	pop    r12
  40eb6e:	pop    rdi
  40eb6f:	pop    rsi
  40eb70:	pop    rbx
  40eb71:	pop    rbp
  40eb72:	ret
  40eb73:	test   rdi,rdi
  40eb76:	jne    40eb8b <__swc_fn_6b1cf01f_000089_157b05de+0x1fb>
  40eb78:	xor    eax,eax
  40eb7a:	add    rsp,0x38
  40eb7e:	pop    r15
  40eb80:	pop    r14
  40eb82:	pop    r13
  40eb84:	pop    r12
  40eb86:	pop    rdi
  40eb87:	pop    rsi
  40eb88:	pop    rbx
  40eb89:	pop    rbp
  40eb8a:	ret
  40eb8b:	mov    rcx,QWORD PTR [rsi+0x40]
  40eb8f:	call   40bf40 <__swc_fn_6b1cf01f_000082_9f4f5092>
  40eb94:	mov    rsi,rax
  40eb97:	mov    rax,QWORD PTR [rdi]
  40eb9a:	mov    rdi,rax
  40eb9d:	test   rax,rax
  40eba0:	jne    40ebe3 <__swc_fn_6b1cf01f_000089_157b05de+0x253>
  40eba2:	test   rbx,rbx
  40eba5:	je     40ebe3 <__swc_fn_6b1cf01f_000089_157b05de+0x253>
  40eba7:	mov    rcx,r15
  40ebaa:	mov    rdx,rsi
  40ebad:	xor    r8d,r8d
  40ebb0:	call   4085a0 <__swc_fn_6b1cf01f_000090_9a1d717d>
  40ebb5:	mov    rcx,rax
  40ebb8:	test   al,al
  40ebba:	jne    40ebdc <__swc_fn_6b1cf01f_000089_157b05de+0x24c>
  40ebbc:	mov    rcx,r15
  40ebbf:	mov    rdx,rsi
  40ebc2:	call   40bf80 <__swc_fn_6b1cf01f_000085_88128f21>
  40ebc7:	mov    rcx,rax
  40ebca:	test   al,al
  40ebcc:	jne    40ebdc <__swc_fn_6b1cf01f_000089_157b05de+0x24c>
  40ebce:	mov    rcx,rsi
  40ebd1:	mov    rdx,r15
  40ebd4:	call   40bf80 <__swc_fn_6b1cf01f_000085_88128f21>
  40ebd9:	mov    rcx,rax
  40ebdc:	test   cl,cl
  40ebde:	setne  al
  40ebe1:	mov    BYTE PTR [rbx],al
  40ebe3:	xor    eax,eax
  40ebe5:	mov    r14b,al
  40ebe8:	test   rdi,rdi
  40ebeb:	jne    40ec05 <__swc_fn_6b1cf01f_000089_157b05de+0x275>
  40ebed:	test   r14b,r14b
  40ebf0:	jne    40ec05 <__swc_fn_6b1cf01f_000089_157b05de+0x275>
  40ebf2:	xor    eax,eax
  40ebf4:	add    rsp,0x38
  40ebf8:	pop    r15
  40ebfa:	pop    r14
  40ebfc:	pop    r13
  40ebfe:	pop    r12
  40ec00:	pop    rdi
  40ec01:	pop    rsi
  40ec02:	pop    rbx
  40ec03:	pop    rbp
  40ec04:	ret
  40ec05:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40ec0a:	je     40ec16 <__swc_fn_6b1cf01f_000089_157b05de+0x286>
  40ec0c:	mov    r12,QWORD PTR [rsp+0x18]
  40ec11:	jmp    40ec9e <__swc_fn_6b1cf01f_000089_157b05de+0x30e>
  40ec16:	mov    r12,QWORD PTR [rsp+0x18]
  40ec1b:	test   r12,r12
  40ec1e:	jne    40ec32 <__swc_fn_6b1cf01f_000089_157b05de+0x2a2>
  40ec20:	mov    rcx,r15
  40ec23:	mov    rdx,rsi
  40ec26:	xor    r8d,r8d
  40ec29:	call   4085a0 <__swc_fn_6b1cf01f_000090_9a1d717d>
  40ec2e:	test   al,al
  40ec30:	jne    40ec9e <__swc_fn_6b1cf01f_000089_157b05de+0x30e>
  40ec32:	test   DWORD PTR [rsi+0x28],0x10000
  40ec39:	je     40ec57 <__swc_fn_6b1cf01f_000089_157b05de+0x2c7>
  40ec3b:	rex mov al,BYTE PTR [rsp+0x8]
  40ec40:	test   al,al
  40ec42:	jne    40ec57 <__swc_fn_6b1cf01f_000089_157b05de+0x2c7>
  40ec44:	xor    eax,eax
  40ec46:	add    rsp,0x38
  40ec4a:	pop    r15
  40ec4c:	pop    r14
  40ec4e:	pop    r13
  40ec50:	pop    r12
  40ec52:	pop    rdi
  40ec53:	pop    rsi
  40ec54:	pop    rbx
  40ec55:	pop    rbp
  40ec56:	ret
  40ec57:	test   rdi,rdi
  40ec5a:	jne    40ec6f <__swc_fn_6b1cf01f_000089_157b05de+0x2df>
  40ec5c:	xor    eax,eax
  40ec5e:	add    rsp,0x38
  40ec62:	pop    r15
  40ec64:	pop    r14
  40ec66:	pop    r13
  40ec68:	pop    r12
  40ec6a:	pop    rdi
  40ec6b:	pop    rsi
  40ec6c:	pop    rbx
  40ec6d:	pop    rbp
  40ec6e:	ret
  40ec6f:	cmp    QWORD PTR [rdi+0x8],0x0
  40ec74:	jne    40ec89 <__swc_fn_6b1cf01f_000089_157b05de+0x2f9>
  40ec76:	xor    eax,eax
  40ec78:	add    rsp,0x38
  40ec7c:	pop    r15
  40ec7e:	pop    r14
  40ec80:	pop    r13
  40ec82:	pop    r12
  40ec84:	pop    rdi
  40ec85:	pop    rsi
  40ec86:	pop    rbx
  40ec87:	pop    rbp
  40ec88:	ret
  40ec89:	mov    rax,QWORD PTR [rdi+0x8]
  40ec8d:	mov    rax,QWORD PTR [rax]
  40ec90:	mov    rsi,rax
  40ec93:	mov    rdi,QWORD PTR [rdi]
  40ec96:	mov    eax,0x1
  40ec9b:	mov    r14b,al
  40ec9e:	test   rdi,rdi
  40eca1:	mov    rbx,QWORD PTR [rsp+0x20]
  40eca6:	jne    40ecf0 <__swc_fn_6b1cf01f_000089_157b05de+0x360>
  40eca8:	test   r14b,r14b
  40ecab:	je     40ecdd <__swc_fn_6b1cf01f_000089_157b05de+0x34d>
  40ecad:	test   r12,r12
  40ecb0:	je     40ecdd <__swc_fn_6b1cf01f_000089_157b05de+0x34d>
  40ecb2:	mov    rcx,r15
  40ecb5:	mov    rdx,rsi
  40ecb8:	xor    r8d,r8d
  40ecbb:	mov    r9,r12
  40ecbe:	mov    rbx,QWORD PTR [rsp+0x20]
  40ecc3:	movzx  r10d,BYTE PTR [rbx]
  40ecc7:	call   40e880 <__swc_fn_6b1cf01f_000083_fb84e43e>
  40eccc:	add    rsp,0x38
  40ecd0:	pop    r15
  40ecd2:	pop    r14
  40ecd4:	pop    r13
  40ecd6:	pop    r12
  40ecd8:	pop    rdi
  40ecd9:	pop    rsi
  40ecda:	pop    rbx
  40ecdb:	pop    rbp
  40ecdc:	ret
  40ecdd:	xor    eax,eax
  40ecdf:	add    rsp,0x38
  40ece3:	pop    r15
  40ece5:	pop    r14
  40ece7:	pop    r13
  40ece9:	pop    r12
  40eceb:	pop    rdi
  40ecec:	pop    rsi
  40eced:	pop    rbx
  40ecee:	pop    rbp
  40ecef:	ret
  40ecf0:	mov    r13,rsi
  40ecf3:	mov    QWORD PTR [rsp+0x28],rdi
  40ecf8:	cmp    BYTE PTR [r15+0x2c],0xe
  40ecfd:	sete   al
  40ed00:	mov    r14b,al
  40ed03:	jne    40ed17 <__swc_fn_6b1cf01f_000089_157b05de+0x387>
  40ed05:	mov    rcx,rsi
  40ed08:	mov    rdx,r15
  40ed0b:	call   40bf80 <__swc_fn_6b1cf01f_000085_88128f21>
  40ed10:	mov    r14b,al
  40ed13:	test   al,al
  40ed15:	jne    40ed4c <__swc_fn_6b1cf01f_000089_157b05de+0x3bc>
  40ed17:	cmp    BYTE PTR [r15+0x2c],0x12
  40ed1c:	je     40ed4c <__swc_fn_6b1cf01f_000089_157b05de+0x3bc>
  40ed1e:	mov    rcx,r15
  40ed21:	mov    rdx,rsi
  40ed24:	mov    r8,rdi
  40ed27:	mov    r9,r12
  40ed2a:	mov    rax,rbx
  40ed2d:	movzx  r10d,BYTE PTR [rax]
  40ed31:	call   40e880 <__swc_fn_6b1cf01f_000083_fb84e43e>
  40ed36:	test   rax,rax
  40ed39:	je     40ed4c <__swc_fn_6b1cf01f_000089_157b05de+0x3bc>
  40ed3b:	add    rsp,0x38
  40ed3f:	pop    r15
  40ed41:	pop    r14
  40ed43:	pop    r13
  40ed45:	pop    r12
  40ed47:	pop    rdi
  40ed48:	pop    rsi
  40ed49:	pop    rbx
  40ed4a:	pop    rbp
  40ed4b:	ret
  40ed4c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40ed51:	jne    40ed70 <__swc_fn_6b1cf01f_000089_157b05de+0x3e0>
  40ed53:	mov    rax,QWORD PTR [rsi+0xd8]
  40ed5a:	test   rax,rax
  40ed5d:	je     40ed70 <__swc_fn_6b1cf01f_000089_157b05de+0x3e0>
  40ed5f:	add    rdi,QWORD PTR [rax+0x8]
  40ed63:	mov    rax,QWORD PTR [rdi]
  40ed66:	sub    rdi,QWORD PTR [rax+0x8]
  40ed6a:	mov    rax,QWORD PTR [rax]
  40ed6d:	mov    rsi,rax
  40ed70:	test   r14b,r14b
  40ed73:	je     40ed9f <__swc_fn_6b1cf01f_000089_157b05de+0x40f>
  40ed75:	mov    rcx,r15
  40ed78:	mov    rdx,rsi
  40ed7b:	mov    r8,rdi
  40ed7e:	mov    r9,r13
  40ed81:	mov    r14,QWORD PTR [rsp+0x28]
  40ed86:	mov    r10,r14
  40ed89:	call   408480 <__swc_fn_6b1cf01f_000087_1fb4fcfe>
  40ed8e:	add    rsp,0x38
  40ed92:	pop    r15
  40ed94:	pop    r14
  40ed96:	pop    r13
  40ed98:	pop    r12
  40ed9a:	pop    rdi
  40ed9b:	pop    rsi
  40ed9c:	pop    rbx
  40ed9d:	pop    rbp
  40ed9e:	ret
  40ed9f:	mov    rcx,r15
  40eda2:	mov    rdx,rsi
  40eda5:	mov    r8,rdi
  40eda8:	mov    r9,r12
  40edab:	movzx  r10d,BYTE PTR [rbx]
  40edaf:	call   40e880 <__swc_fn_6b1cf01f_000083_fb84e43e>
  40edb4:	add    rsp,0x38
  40edb8:	pop    r15
  40edba:	pop    r14
  40edbc:	pop    r13
  40edbe:	pop    r12
  40edc0:	pop    rdi
  40edc1:	pop    rsi
  40edc2:	pop    rbx
  40edc3:	pop    rbp
  40edc4:	ret
	...

000000000040edd0 <__swc_fn_6b1cf01f_000092_17e20532>:
  40edd0:	push   rbx
  40edd1:	push   rsi
  40edd2:	sub    rsp,0x18
  40edd6:	mov    rbx,rcx
  40edd9:	mov    rcx,QWORD PTR [rip+0x17f60]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40ede0:	test   rcx,rcx
  40ede3:	jne    40edf5 <__swc_fn_6b1cf01f_000092_17e20532+0x25>
  40ede5:	call   40a1a0 <__swc_fn_6b1cf01f_000165_e09accff>
  40edea:	lea    rcx,[rax+0x1]
  40edee:	mov    QWORD PTR [rip+0x17f4b],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40edf5:	dec    rcx
  40edf8:	call   411680 <__swc_fn_6b1cf01f_000167_3130645d>
  40edfd:	mov    rsi,rax
  40ee00:	mov    rax,QWORD PTR [rsi+0x8]
  40ee04:	test   rax,rax
  40ee07:	jne    40ee57 <__swc_fn_6b1cf01f_000092_17e20532+0x87>
  40ee09:	call   40c070 <__swc_fn_6b1cf01f_000091_e6773530>
  40ee0e:	test   al,al
  40ee10:	jne    40ee57 <__swc_fn_6b1cf01f_000092_17e20532+0x87>
  40ee12:	lea    rdx,[rip+0x15427]        # 424240 <__swc_bss_base_6b1cf01f+0x200>
  40ee19:	mov    rcx,rdx
  40ee1c:	call   407740 <__swc_fn_6b1cf01f_000036_62160bb3>
  40ee21:	test   al,al
  40ee23:	jne    40ee34 <__swc_fn_6b1cf01f_000092_17e20532+0x64>
  40ee25:	mov    rcx,rdx
  40ee28:	call   40a960 <__swc_fn_6b1cf01f_000034_c72914a2>
  40ee2d:	lea    rdx,[rip+0x1540c]        # 424240 <__swc_bss_base_6b1cf01f+0x200>
  40ee34:	mov    QWORD PTR [rsp+0x8],rdx
  40ee39:	lea    rax,[rip+0x4310]        # 413150 <__swc_rdata_base_6b1cf01f+0x40>
  40ee40:	mov    QWORD PTR [rsp+0x10],rax
  40ee45:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ee4b:	vmovups XMMWORD PTR [rsi],xmm0
  40ee4f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40ee57:	vmovups xmm0,XMMWORD PTR [rsi]
  40ee5b:	vmovups XMMWORD PTR [rbx],xmm0
  40ee5f:	mov    rax,rbx
  40ee62:	add    rsp,0x18
  40ee66:	pop    rsi
  40ee67:	pop    rbx
  40ee68:	ret
  40ee69:	add    BYTE PTR [rax],al
  40ee6b:	add    BYTE PTR [rax],al
  40ee6d:	add    BYTE PTR [rax],al
	...

000000000040ee70 <__swc_fn_6b1cf01f_000095_a3245f7e>:
  40ee70:	sub    rsp,0x8
  40ee74:	call   409340 <__swc_fn_6b1cf01f_000117_76ff2f0a>
  40ee79:	add    rsp,0x8
  40ee7d:	ret
	...

000000000040ee80 <__swc_fn_6b1cf01f_000098_d9d80f1a>:
  40ee80:	push   rbx
  40ee81:	push   rsi
  40ee82:	sub    rsp,0x28
  40ee86:	mov    rbx,rcx
  40ee89:	xor    esi,esi
  40ee8b:	jmp    40eea0 <__swc_fn_6b1cf01f_000098_d9d80f1a+0x20>
  40ee8d:	nop    DWORD PTR [rax]
  40ee90:	mov    QWORD PTR [rbx+0x28],rsi
  40ee94:	mov    rsi,rbx
  40ee97:	mov    rbx,rax
  40ee9a:	nop    WORD PTR [rax+rax*1+0x0]
  40eea0:	test   rbx,rbx
  40eea3:	je     40ef03 <__swc_fn_6b1cf01f_000098_d9d80f1a+0x83>
  40eea5:	mov    rcx,rbx
  40eea8:	mov    edx,0x1
  40eead:	call   408200 <__swc_fn_6b1cf01f_000078_5a70c27a>
  40eeb2:	cmp    rax,0x1
  40eeb6:	jne    40ef03 <__swc_fn_6b1cf01f_000098_d9d80f1a+0x83>
  40eeb8:	mov    r10,QWORD PTR [rbx+0x18]
  40eebc:	mov    rcx,r10
  40eebf:	mov    edx,0x1
  40eec4:	call   408200 <__swc_fn_6b1cf01f_000078_5a70c27a>
  40eec9:	cmp    rax,0x1
  40eecd:	jne    40eedc <__swc_fn_6b1cf01f_000098_d9d80f1a+0x5c>
  40eecf:	mov    rcx,r10
  40eed2:	call   40c210 <__swc_fn_6b1cf01f_000097_8b4a07e9>
  40eed7:	test   rax,rax
  40eeda:	jne    40ee90 <__swc_fn_6b1cf01f_000098_d9d80f1a+0x10>
  40eedc:	mov    rax,QWORD PTR [rbx+0x20]
  40eee0:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40eee5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40eeeb:	lea    rcx,[rsp+0x8]
  40eef0:	mov    rdx,rbx
  40eef3:	mov    r8d,0x30
  40eef9:	mov    rbx,rax
  40eefc:	call   408960 <__swc_fn_6b1cf01f_000096_f879630a>
  40ef01:	jmp    40eea0 <__swc_fn_6b1cf01f_000098_d9d80f1a+0x20>
  40ef03:	test   rsi,rsi
  40ef06:	jne    40ef0f <__swc_fn_6b1cf01f_000098_d9d80f1a+0x8f>
  40ef08:	add    rsp,0x28
  40ef0c:	pop    rsi
  40ef0d:	pop    rbx
  40ef0e:	ret
  40ef0f:	mov    rax,rsi
  40ef12:	mov    rsi,QWORD PTR [rsi+0x28]
  40ef16:	mov    rbx,QWORD PTR [rax+0x20]
  40ef1a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40ef1f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40ef25:	lea    rcx,[rsp+0x18]
  40ef2a:	mov    rdx,rax
  40ef2d:	mov    r8d,0x30
  40ef33:	call   408960 <__swc_fn_6b1cf01f_000096_f879630a>
  40ef38:	jmp    40eea0 <__swc_fn_6b1cf01f_000098_d9d80f1a+0x20>
  40ef3d:	add    BYTE PTR [rax],al
	...

000000000040ef40 <__swc_fn_6b1cf01f_000101_295ddd7c>:
  40ef40:	push   rbx
  40ef41:	push   rsi
  40ef42:	push   rdi
  40ef43:	push   r12
  40ef45:	push   r13
  40ef47:	sub    rsp,0x20
  40ef4b:	mov    rbx,rcx
  40ef4e:	lea    rsi,[rcx+0x6f8]
  40ef55:	mov    edi,0x4
  40ef5a:	mov    r12,rsi
  40ef5d:	test   rdi,rdi
  40ef60:	je     40efaa <__swc_fn_6b1cf01f_000101_295ddd7c+0x6a>
  40ef62:	cs nop WORD PTR [rax+rax*1+0x0]
  40ef6c:	nop    DWORD PTR [rax+0x0]
  40ef70:	mov    rcx,QWORD PTR [r12+0x10]
  40ef75:	mov    QWORD PTR [r12+0x10],0x0
  40ef7e:	vxorps xmm0,xmm0,xmm0
  40ef82:	vmovups XMMWORD PTR [r12],xmm0
  40ef88:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40ef8f:	mov    DWORD PTR [r12+0x20],0x0
  40ef98:	call   4089b0 <__swc_fn_6b1cf01f_000099_6e0faaee>
  40ef9d:	add    r12,0x90
  40efa4:	sub    rdi,0x1
  40efa8:	jne    40ef70 <__swc_fn_6b1cf01f_000101_295ddd7c+0x30>
  40efaa:	mov    rax,QWORD PTR [rbx+0x938]
  40efb1:	mov    rdi,rax
  40efb4:	test   rdi,rdi
  40efb7:	je     40f011 <__swc_fn_6b1cf01f_000101_295ddd7c+0xd1>
  40efb9:	nop    DWORD PTR [rax+0x0]
  40efc0:	mov    r12d,0x10
  40efc6:	lea    r13,[rdi+0x18]
  40efca:	test   r12,r12
  40efcd:	je     40f006 <__swc_fn_6b1cf01f_000101_295ddd7c+0xc6>
  40efcf:	nop
  40efd0:	mov    rcx,QWORD PTR [r13+0x10]
  40efd4:	mov    QWORD PTR [r13+0x10],0x0
  40efdc:	vxorps xmm0,xmm0,xmm0
  40efe0:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40efe6:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40efec:	mov    DWORD PTR [r13+0x20],0x0
  40eff4:	call   4089b0 <__swc_fn_6b1cf01f_000099_6e0faaee>
  40eff9:	add    r13,0x90
  40f000:	sub    r12,0x1
  40f004:	jne    40efd0 <__swc_fn_6b1cf01f_000101_295ddd7c+0x90>
  40f006:	mov    rax,QWORD PTR [rdi]
  40f009:	mov    rdi,rax
  40f00c:	test   rax,rax
  40f00f:	jne    40efc0 <__swc_fn_6b1cf01f_000101_295ddd7c+0x80>
  40f011:	vxorps xmm0,xmm0,xmm0
  40f015:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40f01d:	mov    DWORD PTR [rbx+0x9b0],0x0
  40f027:	mov    DWORD PTR [rbx+0x9a8],0x0
  40f031:	mov    edi,0x4
  40f036:	mov    r12,rsi
  40f039:	lea    rsi,[rsi+0x38]
  40f03d:	test   rdi,rdi
  40f040:	je     40f06c <__swc_fn_6b1cf01f_000101_295ddd7c+0x12c>
  40f042:	cs nop WORD PTR [rax+rax*1+0x0]
  40f04c:	nop    DWORD PTR [rax+0x0]
  40f050:	mov    rcx,rsi
  40f053:	call   40d090 <__swc_fn_6b1cf01f_000157_5c8b11d8>
  40f058:	add    rsi,0x90
  40f05f:	add    r12,0x90
  40f066:	sub    rdi,0x1
  40f06a:	jne    40f050 <__swc_fn_6b1cf01f_000101_295ddd7c+0x110>
  40f06c:	mov    rax,QWORD PTR [rbx+0x938]
  40f073:	mov    rdi,rax
  40f076:	mov    QWORD PTR [rbx+0x938],0x0
  40f081:	test   rdi,rdi
  40f084:	je     40f0f5 <__swc_fn_6b1cf01f_000101_295ddd7c+0x1b5>
  40f08a:	nop    WORD PTR [rax+rax*1+0x0]
  40f090:	mov    esi,0x10
  40f095:	lea    r12,[rdi+0x18]
  40f099:	lea    r13,[rdi+0x50]
  40f09d:	test   rsi,rsi
  40f0a0:	je     40f0cc <__swc_fn_6b1cf01f_000101_295ddd7c+0x18c>
  40f0a2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f0ac:	nop    DWORD PTR [rax+0x0]
  40f0b0:	mov    rcx,r13
  40f0b3:	call   40d090 <__swc_fn_6b1cf01f_000157_5c8b11d8>
  40f0b8:	add    r13,0x90
  40f0bf:	add    r12,0x90
  40f0c6:	sub    rsi,0x1
  40f0ca:	jne    40f0b0 <__swc_fn_6b1cf01f_000101_295ddd7c+0x170>
  40f0cc:	mov    rax,QWORD PTR [rdi]
  40f0cf:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40f0d4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f0da:	lea    rcx,[rsp+0x8]
  40f0df:	mov    rdx,rdi
  40f0e2:	mov    r8d,0x918
  40f0e8:	mov    rdi,rax
  40f0eb:	call   408960 <__swc_fn_6b1cf01f_000096_f879630a>
  40f0f0:	test   rdi,rdi
  40f0f3:	jne    40f090 <__swc_fn_6b1cf01f_000101_295ddd7c+0x150>
  40f0f5:	lea    rcx,[rbx+0x68]
  40f0f9:	call   40d090 <__swc_fn_6b1cf01f_000157_5c8b11d8>
  40f0fe:	add    rsp,0x20
  40f102:	pop    r13
  40f104:	pop    r12
  40f106:	pop    rdi
  40f107:	pop    rsi
  40f108:	pop    rbx
  40f109:	ret
  40f10a:	add    BYTE PTR [rax],al
  40f10c:	add    BYTE PTR [rax],al
	...

000000000040f110 <__swc_fn_6b1cf01f_000104_baf871f8>:
  40f110:	xor    eax,eax
  40f112:	cs nop WORD PTR [rax+rax*1+0x0]
  40f11c:	nop    DWORD PTR [rax+0x0]
  40f120:	mov    r9,r8
  40f123:	sub    r9,rax
  40f126:	cmp    r9,0x40
  40f12a:	jb     40f168 <__swc_fn_6b1cf01f_000104_baf871f8+0x58>
  40f12c:	lea    r9,[rcx+rax*1]
  40f130:	lea    r10,[rdx+rax*1]
  40f134:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40f13a:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40f140:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40f146:	vmovups xmm3,XMMWORD PTR [r10]
  40f14b:	vmovups XMMWORD PTR [r9],xmm3
  40f150:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40f156:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40f15c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40f162:	lea    rax,[rax+0x40]
  40f166:	jmp    40f120 <__swc_fn_6b1cf01f_000104_baf871f8+0x10>
  40f168:	nop    DWORD PTR [rax+rax*1+0x0]
  40f170:	mov    r9,r8
  40f173:	sub    r9,rax
  40f176:	cmp    r9,0x10
  40f17a:	jb     40f194 <__swc_fn_6b1cf01f_000104_baf871f8+0x84>
  40f17c:	lea    r9,[rdx+rax*1]
  40f180:	lea    r10,[rcx+rax*1]
  40f184:	vmovups xmm0,XMMWORD PTR [r9]
  40f189:	vmovups XMMWORD PTR [r10],xmm0
  40f18e:	lea    rax,[rax+0x10]
  40f192:	jmp    40f170 <__swc_fn_6b1cf01f_000104_baf871f8+0x60>
  40f194:	cs nop WORD PTR [rax+rax*1+0x0]
  40f19e:	xchg   ax,ax
  40f1a0:	mov    r9,r8
  40f1a3:	sub    r9,rax
  40f1a6:	cmp    r9,0x8
  40f1aa:	jb     40f1bd <__swc_fn_6b1cf01f_000104_baf871f8+0xad>
  40f1ac:	lea    r9,[rcx+rax*1]
  40f1b0:	mov    r10,QWORD PTR [rdx+rax*1]
  40f1b4:	mov    QWORD PTR [r9],r10
  40f1b7:	lea    rax,[rax+0x8]
  40f1bb:	jmp    40f1a0 <__swc_fn_6b1cf01f_000104_baf871f8+0x90>
  40f1bd:	cmp    rax,r8
  40f1c0:	jae    40f1e0 <__swc_fn_6b1cf01f_000104_baf871f8+0xd0>
  40f1c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f1cc:	nop    DWORD PTR [rax+0x0]
  40f1d0:	mov    r9b,BYTE PTR [rdx+rax*1]
  40f1d4:	mov    BYTE PTR [rcx+rax*1],r9b
  40f1d8:	inc    rax
  40f1db:	cmp    rax,r8
  40f1de:	jb     40f1d0 <__swc_fn_6b1cf01f_000104_baf871f8+0xc0>
  40f1e0:	ret
	...

000000000040f1f0 <__swc_fn_6b1cf01f_000107_ff529476>:
  40f1f0:	push   rbx
  40f1f1:	push   r12
  40f1f3:	push   rdi
  40f1f4:	push   rsi
  40f1f5:	push   r13
  40f1f7:	push   r14
  40f1f9:	push   r15
  40f1fb:	sub    rsp,0x170
  40f202:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40f20b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40f214:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40f21d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40f226:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40f22f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40f238:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40f241:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40f24a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40f253:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40f25c:	mov    ebx,edx
  40f25e:	mov    QWORD PTR [rsp+0xa8],rbx
  40f266:	mov    r12d,ecx
  40f269:	test   edx,edx
  40f26b:	jne    40f282 <__swc_fn_6b1cf01f_000107_ff529476+0x92>
  40f26d:	xor    eax,eax
  40f26f:	add    rsp,0x170
  40f276:	pop    r15
  40f278:	pop    r14
  40f27a:	pop    r13
  40f27c:	pop    rsi
  40f27d:	pop    rdi
  40f27e:	pop    r12
  40f280:	pop    rbx
  40f281:	ret
  40f282:	lea    rdi,[rip+0x4227]        # 4134b0 <__swc_rdata_base_6b1cf01f+0x3a0>
  40f289:	mov    esi,0x90000
  40f28e:	xor    eax,eax
  40f290:	call   407090 <open@plt>
  40f295:	mov    r13,rax
  40f298:	mov    QWORD PTR [rsp+0xb0],rax
  40f2a0:	test   eax,eax
  40f2a2:	jge    40f2ab <__swc_fn_6b1cf01f_000107_ff529476+0xbb>
  40f2a4:	xor    eax,eax
  40f2a6:	jmp    40f7a6 <__swc_fn_6b1cf01f_000107_ff529476+0x5b6>
  40f2ab:	nop    DWORD PTR [rax+rax*1+0x0]
  40f2b0:	movsxd rdi,r13d
  40f2b3:	mov    esi,0x2
  40f2b8:	xor    eax,eax
  40f2ba:	call   407120 <flock@plt>
  40f2bf:	test   eax,eax
  40f2c1:	je     40f2e0 <__swc_fn_6b1cf01f_000107_ff529476+0xf0>
  40f2c3:	xor    eax,eax
  40f2c5:	call   407130 <__errno_location@plt>
  40f2ca:	cmp    DWORD PTR [rax],0x4
  40f2cd:	je     40f2b0 <__swc_fn_6b1cf01f_000107_ff529476+0xc0>
  40f2cf:	movsxd rdi,r13d
  40f2d2:	xor    eax,eax
  40f2d4:	call   4070b0 <close@plt>
  40f2d9:	xor    eax,eax
  40f2db:	jmp    40f7a6 <__swc_fn_6b1cf01f_000107_ff529476+0x5b6>
  40f2e0:	lea    r14,[rsp+0x8]
  40f2e5:	mov    QWORD PTR [rsp+0xb8],r14
  40f2ed:	vxorps xmm0,xmm0,xmm0
  40f2f1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f2f7:	mov    QWORD PTR [rsp+0x18],0x0
  40f300:	mov    WORD PTR [rsp+0x20],0x0
  40f307:	mov    DWORD PTR [r14],0x67617753
  40f30e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40f316:	xor    eax,eax
  40f318:	call   407010 <getpid@plt>
  40f31d:	mov    ecx,eax
  40f31f:	mov    eax,0x1c
  40f324:	shrx   eax,ecx,eax
  40f329:	and    eax,0xf
  40f32c:	mov    rdx,QWORD PTR [rip+0x419d]        # 4134d0 <__swc_rdata_base_6b1cf01f+0x3c0>
  40f333:	mov    al,BYTE PTR [rdx+rax*1]
  40f336:	rex mov BYTE PTR [rsp+0x10],al
  40f33b:	mov    eax,0x1c
  40f340:	shrx   eax,r12d,eax
  40f345:	and    eax,0xf
  40f348:	mov    al,BYTE PTR [rdx+rax*1]
  40f34b:	rex mov BYTE PTR [rsp+0x19],al
  40f350:	mov    eax,0x18
  40f355:	shrx   eax,ecx,eax
  40f35a:	and    eax,0xf
  40f35d:	mov    al,BYTE PTR [rdx+rax*1]
  40f360:	rex mov BYTE PTR [rsp+0x11],al
  40f365:	mov    eax,0x18
  40f36a:	shrx   eax,r12d,eax
  40f36f:	and    eax,0xf
  40f372:	mov    al,BYTE PTR [rdx+rax*1]
  40f375:	rex mov BYTE PTR [rsp+0x1a],al
  40f37a:	mov    eax,0x14
  40f37f:	shrx   eax,ecx,eax
  40f384:	and    eax,0xf
  40f387:	mov    al,BYTE PTR [rdx+rax*1]
  40f38a:	rex mov BYTE PTR [rsp+0x12],al
  40f38f:	mov    eax,0x14
  40f394:	shrx   eax,r12d,eax
  40f399:	and    eax,0xf
  40f39c:	mov    al,BYTE PTR [rdx+rax*1]
  40f39f:	rex mov BYTE PTR [rsp+0x1b],al
  40f3a4:	mov    eax,0x10
  40f3a9:	shrx   eax,ecx,eax
  40f3ae:	and    eax,0xf
  40f3b1:	mov    al,BYTE PTR [rdx+rax*1]
  40f3b4:	rex mov BYTE PTR [rsp+0x13],al
  40f3b9:	mov    eax,0x10
  40f3be:	shrx   eax,r12d,eax
  40f3c3:	and    eax,0xf
  40f3c6:	mov    al,BYTE PTR [rdx+rax*1]
  40f3c9:	rex mov BYTE PTR [rsp+0x1c],al
  40f3ce:	mov    eax,0xc
  40f3d3:	shrx   eax,ecx,eax
  40f3d8:	and    eax,0xf
  40f3db:	mov    al,BYTE PTR [rdx+rax*1]
  40f3de:	rex mov BYTE PTR [rsp+0x14],al
  40f3e3:	mov    eax,0xc
  40f3e8:	shrx   eax,r12d,eax
  40f3ed:	and    eax,0xf
  40f3f0:	mov    al,BYTE PTR [rdx+rax*1]
  40f3f3:	rex mov BYTE PTR [rsp+0x1d],al
  40f3f8:	mov    eax,0x8
  40f3fd:	shrx   eax,ecx,eax
  40f402:	and    eax,0xf
  40f405:	mov    al,BYTE PTR [rdx+rax*1]
  40f408:	rex mov BYTE PTR [rsp+0x15],al
  40f40d:	mov    eax,0x8
  40f412:	shrx   eax,r12d,eax
  40f417:	and    eax,0xf
  40f41a:	mov    al,BYTE PTR [rdx+rax*1]
  40f41d:	rex mov BYTE PTR [rsp+0x1e],al
  40f422:	mov    eax,0x4
  40f427:	shrx   eax,ecx,eax
  40f42c:	and    eax,0xf
  40f42f:	mov    al,BYTE PTR [rdx+rax*1]
  40f432:	rex mov BYTE PTR [rsp+0x16],al
  40f437:	mov    eax,0x4
  40f43c:	shrx   eax,r12d,eax
  40f441:	and    eax,0xf
  40f444:	mov    al,BYTE PTR [rdx+rax*1]
  40f447:	rex mov BYTE PTR [rsp+0x1f],al
  40f44c:	xor    eax,eax
  40f44e:	shrx   eax,ecx,eax
  40f453:	and    eax,0xf
  40f456:	mov    al,BYTE PTR [rdx+rax*1]
  40f459:	rex mov BYTE PTR [rsp+0x17],al
  40f45e:	xor    eax,eax
  40f460:	shrx   eax,r12d,eax
  40f465:	and    eax,0xf
  40f468:	mov    al,BYTE PTR [rdx+rax*1]
  40f46b:	rex mov BYTE PTR [rsp+0x20],al
  40f470:	mov    BYTE PTR [r14+0x10],0x2e
  40f475:	lea    r12,[rsp+0x22]
  40f47a:	vxorps xmm0,xmm0,xmm0
  40f47e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40f484:	mov    DWORD PTR [r12],0x6d656d2f
  40f48c:	mov    WORD PTR [r12+0x4],0x6466
  40f494:	mov    BYTE PTR [r12+0x6],0x3a
  40f49a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f4a0:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40f4a6:	mov    rax,QWORD PTR [rsp+0x18]
  40f4ab:	mov    QWORD PTR [rsp+0x39],rax
  40f4b0:	rex mov al,BYTE PTR [rsp+0x20]
  40f4b5:	rex mov BYTE PTR [rsp+0x41],al
  40f4ba:	mov    DWORD PTR [r12+0x20],0x65642820
  40f4c3:	mov    DWORD PTR [r12+0x24],0x6574656c
  40f4cc:	mov    WORD PTR [r12+0x28],0x2964
  40f4d4:	lea    rdi,[rip+0x3fe0]        # 4134bb <__swc_rdata_base_6b1cf01f+0x3ab>
  40f4db:	xor    eax,eax
  40f4dd:	call   407140 <opendir@plt>
  40f4e2:	mov    r15,rax
  40f4e5:	test   rax,rax
  40f4e8:	jne    40f4fb <__swc_fn_6b1cf01f_000107_ff529476+0x30b>
  40f4ea:	movsxd rdi,r13d
  40f4ed:	xor    eax,eax
  40f4ef:	call   4070b0 <close@plt>
  40f4f4:	xor    eax,eax
  40f4f6:	jmp    40f7a6 <__swc_fn_6b1cf01f_000107_ff529476+0x5b6>
  40f4fb:	mov    rdi,r15
  40f4fe:	xor    eax,eax
  40f500:	call   407150 <dirfd@plt>
  40f505:	lea    r14,[rsp+0x54]
  40f50a:	mov    DWORD PTR [rsp+0x54],eax
  40f50e:	lea    rbx,[rsp+0x58]
  40f513:	cs nop WORD PTR [rax+rax*1+0x0]
  40f51d:	nop    DWORD PTR [rax]
  40f520:	mov    rdi,r15
  40f523:	xor    eax,eax
  40f525:	call   407160 <readdir@plt>
  40f52a:	test   rax,rax
  40f52d:	jne    40f544 <__swc_fn_6b1cf01f_000107_ff529476+0x354>
  40f52f:	mov    r12,QWORD PTR [rsp+0xa8]
  40f537:	mov    r13,QWORD PTR [rsp+0xb0]
  40f53f:	jmp    40f6ca <__swc_fn_6b1cf01f_000107_ff529476+0x4da>
  40f544:	vxorps xmm0,xmm0,xmm0
  40f548:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  40f54e:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  40f554:	vzeroupper
  40f557:	lea    r13,[rax+0x13]
  40f55b:	mov    rax,r14
  40f55e:	movsxd rdi,DWORD PTR [rax]
  40f561:	mov    rsi,r13
  40f564:	mov    rdx,rbx
  40f567:	mov    ecx,0x40
  40f56c:	xor    eax,eax
  40f56e:	call   407170 <readlinkat@plt>
  40f573:	cmp    rax,0x2a
  40f577:	jne    40f520 <__swc_fn_6b1cf01f_000107_ff529476+0x330>
  40f579:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40f57f:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40f585:	vptest xmm0,xmm0
  40f58a:	jne    40f5ba <__swc_fn_6b1cf01f_000107_ff529476+0x3ca>
  40f58c:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40f592:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40f598:	vptest xmm0,xmm0
  40f59d:	jne    40f5ba <__swc_fn_6b1cf01f_000107_ff529476+0x3ca>
  40f59f:	mov    rcx,QWORD PTR [rsp+0x42]
  40f5a4:	cmp    QWORD PTR [rsp+0x78],rcx
  40f5a9:	jne    40f5ba <__swc_fn_6b1cf01f_000107_ff529476+0x3ca>
  40f5ab:	mov    cx,WORD PTR [rsp+0x4a]
  40f5b0:	cmp    WORD PTR [rsp+0x80],cx
  40f5b8:	je     40f5e4 <__swc_fn_6b1cf01f_000107_ff529476+0x3f4>
  40f5ba:	mov    rax,rbx
  40f5bd:	mov    rcx,r12
  40f5c0:	movzx  edx,BYTE PTR [rax]
  40f5c3:	movzx  r8d,BYTE PTR [rcx]
  40f5c7:	cmp    rdx,r8
  40f5ca:	jne    40f5d6 <__swc_fn_6b1cf01f_000107_ff529476+0x3e6>
  40f5cc:	add    rax,0x1
  40f5d0:	add    rcx,0x1
  40f5d4:	jmp    40f5c0 <__swc_fn_6b1cf01f_000107_ff529476+0x3d0>
  40f5d6:	mov    rax,rdx
  40f5d9:	sub    rax,r8
  40f5dc:	test   eax,eax
  40f5de:	jne    40f520 <__swc_fn_6b1cf01f_000107_ff529476+0x330>
  40f5e4:	movsxd rdi,DWORD PTR [r14]
  40f5e7:	mov    rsi,r13
  40f5ea:	mov    edx,0x80002
  40f5ef:	xor    eax,eax
  40f5f1:	call   407180 <openat@plt>
  40f5f6:	lea    rbx,[rsp+0x98]
  40f5fe:	mov    DWORD PTR [rsp+0x98],eax
  40f605:	test   eax,eax
  40f607:	mov    r13,QWORD PTR [rsp+0xb0]
  40f60f:	jge    40f634 <__swc_fn_6b1cf01f_000107_ff529476+0x444>
  40f611:	mov    rdi,r15
  40f614:	xor    eax,eax
  40f616:	call   407190 <closedir@plt>
  40f61b:	mov    r13,QWORD PTR [rsp+0xb0]
  40f623:	movsxd rdi,r13d
  40f626:	xor    eax,eax
  40f628:	call   4070b0 <close@plt>
  40f62d:	xor    eax,eax
  40f62f:	jmp    40f7a6 <__swc_fn_6b1cf01f_000107_ff529476+0x5b6>
  40f634:	mov    rax,rbx
  40f637:	movsxd rdi,DWORD PTR [rax]
  40f63a:	xor    esi,esi
  40f63c:	mov    edx,0x2
  40f641:	xor    eax,eax
  40f643:	call   4070a0 <lseek@plt>
  40f648:	mov    r12,QWORD PTR [rsp+0xa8]
  40f650:	cmp    rax,r12
  40f653:	je     40f67a <__swc_fn_6b1cf01f_000107_ff529476+0x48a>
  40f655:	movsxd rdi,DWORD PTR [rbx]
  40f658:	xor    eax,eax
  40f65a:	call   4070b0 <close@plt>
  40f65f:	mov    rdi,r15
  40f662:	xor    eax,eax
  40f664:	call   407190 <closedir@plt>
  40f669:	movsxd rdi,r13d
  40f66c:	xor    eax,eax
  40f66e:	call   4070b0 <close@plt>
  40f673:	xor    eax,eax
  40f675:	jmp    40f7a6 <__swc_fn_6b1cf01f_000107_ff529476+0x5b6>
  40f67a:	xor    edi,edi
  40f67c:	mov    rsi,r12
  40f67f:	mov    edx,0x3
  40f684:	mov    ecx,0x1
  40f689:	mov    rax,rbx
  40f68c:	movsxd r8,DWORD PTR [rax]
  40f68f:	xor    r9d,r9d
  40f692:	xor    eax,eax
  40f694:	call   4070c0 <mmap@plt>
  40f699:	xor    r12d,r12d
  40f69c:	cmp    rax,0xffffffffffffffff
  40f6a0:	cmovne r12,rax
  40f6a4:	movsxd rdi,DWORD PTR [rbx]
  40f6a7:	xor    eax,eax
  40f6a9:	call   4070b0 <close@plt>
  40f6ae:	mov    rdi,r15
  40f6b1:	xor    eax,eax
  40f6b3:	call   407190 <closedir@plt>
  40f6b8:	movsxd rdi,r13d
  40f6bb:	xor    eax,eax
  40f6bd:	call   4070b0 <close@plt>
  40f6c2:	mov    rax,r12
  40f6c5:	jmp    40f7a6 <__swc_fn_6b1cf01f_000107_ff529476+0x5b6>
  40f6ca:	mov    r14,QWORD PTR [rsp+0xb8]
  40f6d2:	mov    rdi,r14
  40f6d5:	mov    esi,0x1
  40f6da:	xor    eax,eax
  40f6dc:	call   4071a0 <memfd_create@plt>
  40f6e1:	lea    rbx,[rsp+0x9c]
  40f6e9:	mov    DWORD PTR [rsp+0x9c],eax
  40f6f0:	test   eax,eax
  40f6f2:	jge    40f70f <__swc_fn_6b1cf01f_000107_ff529476+0x51f>
  40f6f4:	mov    rdi,r15
  40f6f7:	xor    eax,eax
  40f6f9:	call   407190 <closedir@plt>
  40f6fe:	movsxd rdi,r13d
  40f701:	xor    eax,eax
  40f703:	call   4070b0 <close@plt>
  40f708:	xor    eax,eax
  40f70a:	jmp    40f7a6 <__swc_fn_6b1cf01f_000107_ff529476+0x5b6>
  40f70f:	mov    rax,rbx
  40f712:	movsxd rdi,DWORD PTR [rax]
  40f715:	mov    rsi,r12
  40f718:	xor    eax,eax
  40f71a:	call   4071b0 <ftruncate@plt>
  40f71f:	test   eax,eax
  40f721:	je     40f745 <__swc_fn_6b1cf01f_000107_ff529476+0x555>
  40f723:	movsxd rdi,DWORD PTR [rbx]
  40f726:	xor    eax,eax
  40f728:	call   4070b0 <close@plt>
  40f72d:	mov    rdi,r15
  40f730:	xor    eax,eax
  40f732:	call   407190 <closedir@plt>
  40f737:	movsxd rdi,r13d
  40f73a:	xor    eax,eax
  40f73c:	call   4070b0 <close@plt>
  40f741:	xor    eax,eax
  40f743:	jmp    40f7a6 <__swc_fn_6b1cf01f_000107_ff529476+0x5b6>
  40f745:	xor    edi,edi
  40f747:	mov    rsi,r12
  40f74a:	mov    edx,0x3
  40f74f:	mov    ecx,0x1
  40f754:	mov    rax,rbx
  40f757:	movsxd r8,DWORD PTR [rax]
  40f75a:	xor    r9d,r9d
  40f75d:	xor    eax,eax
  40f75f:	call   4070c0 <mmap@plt>
  40f764:	mov    r12,rax
  40f767:	cmp    rax,0xffffffffffffffff
  40f76b:	jne    40f78f <__swc_fn_6b1cf01f_000107_ff529476+0x59f>
  40f76d:	movsxd rdi,DWORD PTR [rbx]
  40f770:	xor    eax,eax
  40f772:	call   4070b0 <close@plt>
  40f777:	mov    rdi,r15
  40f77a:	xor    eax,eax
  40f77c:	call   407190 <closedir@plt>
  40f781:	movsxd rdi,r13d
  40f784:	xor    eax,eax
  40f786:	call   4070b0 <close@plt>
  40f78b:	xor    eax,eax
  40f78d:	jmp    40f7a6 <__swc_fn_6b1cf01f_000107_ff529476+0x5b6>
  40f78f:	mov    rdi,r15
  40f792:	xor    eax,eax
  40f794:	call   407190 <closedir@plt>
  40f799:	movsxd rdi,r13d
  40f79c:	xor    eax,eax
  40f79e:	call   4070b0 <close@plt>
  40f7a3:	mov    rax,r12
  40f7a6:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40f7af:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40f7b8:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40f7c1:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40f7ca:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  40f7d3:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40f7dc:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  40f7e5:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40f7ee:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  40f7f7:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  40f800:	add    rsp,0x170
  40f807:	pop    r15
  40f809:	pop    r14
  40f80b:	pop    r13
  40f80d:	pop    rsi
  40f80e:	pop    rdi
  40f80f:	pop    r12
  40f811:	pop    rbx
  40f812:	ret
	...

000000000040f820 <__swc_fn_6b1cf01f_000110_e606239a>:
  40f820:	push   rsi
  40f821:	push   rdi
  40f822:	push   r12
  40f824:	push   r13
  40f826:	sub    rsp,0x8
  40f82a:	mov    rsi,r8
  40f82d:	mov    rdi,rcx
  40f830:	mov    r12,rdx
  40f833:	call   409100 <__swc_fn_6b1cf01f_000108_32416b9e>
  40f838:	mov    r13,rax
  40f83b:	test   rax,rax
  40f83e:	jne    40f84b <__swc_fn_6b1cf01f_000110_e606239a+0x2b>
  40f840:	add    rsp,0x8
  40f844:	pop    r13
  40f846:	pop    r12
  40f848:	pop    rdi
  40f849:	pop    rsi
  40f84a:	ret
  40f84b:	mov    rcx,r13
  40f84e:	call   40cc90 <__swc_fn_6b1cf01f_000133_c6de0049>
  40f853:	mov    rax,QWORD PTR [r13+0x8]
  40f857:	test   rax,rax
  40f85a:	je     40f899 <__swc_fn_6b1cf01f_000110_e606239a+0x79>
  40f85c:	nop    DWORD PTR [rax+0x0]
  40f860:	lea    rcx,[rax+0x1000]
  40f867:	cmp    rdi,rcx
  40f86a:	jne    40f891 <__swc_fn_6b1cf01f_000110_e606239a+0x71>
  40f86c:	cmp    r12,0x1000
  40f873:	jb     40f891 <__swc_fn_6b1cf01f_000110_e606239a+0x71>
  40f875:	test   sil,sil
  40f878:	setne  cl
  40f87b:	mov    BYTE PTR [rax+0x10],cl
  40f87e:	mov    rcx,r13
  40f881:	call   40fd80 <__swc_fn_6b1cf01f_000134_5696c87e>
  40f886:	add    rsp,0x8
  40f88a:	pop    r13
  40f88c:	pop    r12
  40f88e:	pop    rdi
  40f88f:	pop    rsi
  40f890:	ret
  40f891:	mov    rax,QWORD PTR [rax]
  40f894:	test   rax,rax
  40f897:	jne    40f860 <__swc_fn_6b1cf01f_000110_e606239a+0x40>
  40f899:	mov    rcx,r13
  40f89c:	call   40fd80 <__swc_fn_6b1cf01f_000134_5696c87e>
  40f8a1:	add    rsp,0x8
  40f8a5:	pop    r13
  40f8a7:	pop    r12
  40f8a9:	pop    rdi
  40f8aa:	pop    rsi
  40f8ab:	ret
  40f8ac:	add    BYTE PTR [rax],al
	...

000000000040f8b0 <__swc_fn_6b1cf01f_000113_25e345b1>:
  40f8b0:	sub    rsp,0x8
  40f8b4:	test   rcx,rcx
  40f8b7:	jne    40f8be <__swc_fn_6b1cf01f_000113_25e345b1+0xe>
  40f8b9:	add    rsp,0x8
  40f8bd:	ret
  40f8be:	call   40c7a0 <__swc_fn_6b1cf01f_000115_259b5d5a>
  40f8c3:	add    rsp,0x8
  40f8c7:	ret
	...

000000000040f8d0 <__swc_fn_6b1cf01f_000116_3499f7d6>:
  40f8d0:	push   r12
  40f8d2:	push   r13
  40f8d4:	push   r14
  40f8d6:	push   rdi
  40f8d7:	push   rsi
  40f8d8:	sub    rsp,0xc0
  40f8df:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40f8e5:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40f8eb:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40f8f1:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40f8f7:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40f8fd:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40f903:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40f909:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40f912:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40f91b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40f924:	mov    r12,QWORD PTR [rcx]
  40f927:	test   r12,r12
  40f92a:	jne    40f93c <__swc_fn_6b1cf01f_000116_3499f7d6+0x6c>
  40f92c:	add    rsp,0xc0
  40f933:	pop    rsi
  40f934:	pop    rdi
  40f935:	pop    r14
  40f937:	pop    r13
  40f939:	pop    r12
  40f93b:	ret
  40f93c:	xor    r13d,r13d
  40f93f:	mov    r14,QWORD PTR [rcx+0x8]
  40f943:	cs nop WORD PTR [rax+rax*1+0x0]
  40f94d:	nop    DWORD PTR [rax]
  40f950:	cmp    r13,r14
  40f953:	jae    40f98b <__swc_fn_6b1cf01f_000116_3499f7d6+0xbb>
  40f955:	lea    rax,[r12+r13*1]
  40f959:	mov    rcx,r14
  40f95c:	sub    rcx,r13
  40f95f:	mov    edi,0x1
  40f964:	mov    rsi,rax
  40f967:	mov    rdx,rcx
  40f96a:	xor    eax,eax
  40f96c:	call   4071c0 <write@plt>
  40f971:	test   rax,rax
  40f974:	jle    40f97b <__swc_fn_6b1cf01f_000116_3499f7d6+0xab>
  40f976:	add    r13,rax
  40f979:	jmp    40f950 <__swc_fn_6b1cf01f_000116_3499f7d6+0x80>
  40f97b:	je     40f989 <__swc_fn_6b1cf01f_000116_3499f7d6+0xb9>
  40f97d:	xor    eax,eax
  40f97f:	call   407130 <__errno_location@plt>
  40f984:	cmp    DWORD PTR [rax],0x4
  40f987:	je     40f950 <__swc_fn_6b1cf01f_000116_3499f7d6+0x80>
  40f989:	jmp    40f98b <__swc_fn_6b1cf01f_000116_3499f7d6+0xbb>
  40f98b:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40f991:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40f997:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40f99d:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40f9a3:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40f9a9:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40f9af:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40f9b5:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40f9be:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40f9c7:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40f9d0:	add    rsp,0xc0
  40f9d7:	pop    rsi
  40f9d8:	pop    rdi
  40f9d9:	pop    r14
  40f9db:	pop    r13
  40f9dd:	pop    r12
  40f9df:	ret

000000000040f9e0 <__swc_fn_6b1cf01f_000119_18cd3882>:
  40f9e0:	push   rbx
  40f9e1:	push   r12
  40f9e3:	push   rdi
  40f9e4:	push   rsi
  40f9e5:	sub    rsp,0x4a8
  40f9ec:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  40f9f5:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  40f9fe:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  40fa07:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  40fa10:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  40fa19:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  40fa22:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  40fa2b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  40fa34:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  40fa3d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  40fa46:	mov    rbx,rdx
  40fa49:	mov    r12d,ecx
  40fa4c:	vxorps xmm0,xmm0,xmm0
  40fa50:	xor    eax,eax
  40fa52:	cs nop WORD PTR [rax+rax*1+0x0]
  40fa5c:	nop    DWORD PTR [rax+0x0]
  40fa60:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  40fa66:	add    rax,0x10
  40fa6a:	cmp    rax,0x400
  40fa71:	jne    40fa60 <__swc_fn_6b1cf01f_000119_18cd3882+0x80>
  40fa73:	lea    rdi,[rsp+0x8]
  40fa78:	mov    esi,0x80
  40fa7d:	xor    eax,eax
  40fa7f:	call   4071d0 <backtrace@plt>
  40fa84:	test   eax,eax
  40fa86:	jle    40fa95 <__swc_fn_6b1cf01f_000119_18cd3882+0xb5>
  40fa88:	movsxd rax,eax
  40fa8b:	lea    rcx,[r12+0x1]
  40fa90:	cmp    rcx,rax
  40fa93:	jb     40fa99 <__swc_fn_6b1cf01f_000119_18cd3882+0xb9>
  40fa95:	xor    eax,eax
  40fa97:	jmp    40faca <__swc_fn_6b1cf01f_000119_18cd3882+0xea>
  40fa99:	mov    rcx,QWORD PTR [rbx+0x8]
  40fa9d:	sub    rax,r12
  40faa0:	lea    rsi,[rax-0x1]
  40faa4:	cmp    rcx,rsi
  40faa7:	cmovbe rsi,rcx
  40faab:	lea    eax,[r12+0x1]
  40fab0:	lea    rax,[rsp+rax*8+0x8]
  40fab5:	mov    rcx,QWORD PTR [rbx]
  40fab8:	mov    rdx,rax
  40fabb:	lea    r8,[rsi*8+0x0]
  40fac3:	call   4090e0 <__swc_fn_6b1cf01f_000105_b7aef7c0>
  40fac8:	mov    eax,esi
  40faca:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  40fad3:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  40fadc:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  40fae5:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  40faee:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  40faf7:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  40fb00:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  40fb09:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  40fb12:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  40fb1b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  40fb24:	add    rsp,0x4a8
  40fb2b:	pop    rsi
  40fb2c:	pop    rdi
  40fb2d:	pop    r12
  40fb2f:	pop    rbx
  40fb30:	ret
	...

000000000040fb40 <__swc_fn_6b1cf01f_000122_c37da69c>:
  40fb40:	mov    QWORD PTR [rcx],0x0
  40fb47:	ret
	...

000000000040fb50 <__swc_fn_6b1cf01f_000125_e19c72b3>:
  40fb50:	push   rdi
  40fb51:	push   rsi
  40fb52:	sub    rsp,0xa8
  40fb59:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40fb5f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40fb65:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40fb6b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40fb71:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40fb77:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40fb7d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40fb83:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40fb89:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40fb92:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40fb9b:	mov    edi,ecx
  40fb9d:	mov    rsi,rdx
  40fba0:	xor    eax,eax
  40fba2:	call   407060 <pthread_setspecific@plt>
  40fba7:	test   eax,eax
  40fba9:	sete   al
  40fbac:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40fbb2:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40fbb8:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40fbbe:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40fbc4:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40fbca:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40fbd0:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40fbd6:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40fbdc:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40fbe5:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40fbee:	add    rsp,0xa8
  40fbf5:	pop    rsi
  40fbf6:	pop    rdi
  40fbf7:	ret
	...

000000000040fc00 <__swc_fn_6b1cf01f_000128_9c45d2d7>:
  40fc00:	push   rdi
  40fc01:	push   rsi
  40fc02:	sub    rsp,0xa8
  40fc09:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40fc0f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40fc15:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40fc1b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40fc21:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40fc27:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40fc2d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40fc33:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40fc39:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40fc42:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40fc4b:	test   rcx,rcx
  40fc4e:	je     40fc61 <__swc_fn_6b1cf01f_000128_9c45d2d7+0x61>
  40fc50:	lea    rax,[rcx-0x1]
  40fc54:	mov    eax,eax
  40fc56:	mov    edi,eax
  40fc58:	xor    eax,eax
  40fc5a:	call   407000 <pthread_getspecific@plt>
  40fc5f:	jmp    40fc63 <__swc_fn_6b1cf01f_000128_9c45d2d7+0x63>
  40fc61:	xor    eax,eax
  40fc63:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40fc69:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40fc6f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40fc75:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40fc7b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40fc81:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40fc87:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40fc8d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40fc93:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40fc9c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40fca5:	add    rsp,0xa8
  40fcac:	pop    rsi
  40fcad:	pop    rdi
  40fcae:	ret
	...

000000000040fcb0 <__swc_fn_6b1cf01f_000131_dc04d759>:
  40fcb0:	push   rdi
  40fcb1:	push   rsi
  40fcb2:	sub    rsp,0xb8
  40fcb9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40fcbf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40fcc5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40fccb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40fcd1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40fcd7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40fcdd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40fce3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40fcec:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40fcf5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40fcfe:	vxorps xmm0,xmm0,xmm0
  40fd02:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40fd08:	mov    edi,0x1
  40fd0d:	lea    rsi,[rsp+0x8]
  40fd12:	xor    eax,eax
  40fd14:	call   407110 <clock_gettime@plt>
  40fd19:	mov    rax,QWORD PTR [rsp+0x8]
  40fd1e:	imul   rax,rax,0x3b9aca00
  40fd25:	add    rax,QWORD PTR [rsp+0x10]
  40fd2a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40fd30:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40fd36:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40fd3c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40fd42:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40fd48:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40fd4e:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40fd54:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40fd5d:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40fd66:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40fd6f:	add    rsp,0xb8
  40fd76:	pop    rsi
  40fd77:	pop    rdi
  40fd78:	ret
  40fd79:	add    BYTE PTR [rax],al
  40fd7b:	add    BYTE PTR [rax],al
  40fd7d:	add    BYTE PTR [rax],al
	...

000000000040fd80 <__swc_fn_6b1cf01f_000134_5696c87e>:
  40fd80:	sub    rsp,0x8
  40fd84:	xor    eax,eax
  40fd86:	mov    DWORD PTR [rcx],eax
  40fd88:	mov    edx,0x7fffffff
  40fd8d:	call   4097e0 <__swc_fn_6b1cf01f_000132_2b60f756>
  40fd92:	add    rsp,0x8
  40fd96:	ret
	...

000000000040fda0 <__swc_fn_6b1cf01f_000137_899a611e>:
  40fda0:	push   rdi
  40fda1:	push   rsi
  40fda2:	sub    rsp,0xb8
  40fda9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40fdaf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40fdb5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40fdbb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40fdc1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40fdc7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40fdcd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40fdd3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40fddc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40fde5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40fdee:	mov    edi,0x1
  40fdf3:	xor    eax,eax
  40fdf5:	call   4071e0 <__x86_get_cpuid_feature_leaf@plt>
  40fdfa:	mov    eax,DWORD PTR [rax+0x14]
  40fdfd:	and    eax,0x20
  40fe00:	setne  al
  40fe03:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40fe09:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40fe0f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40fe15:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40fe1b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40fe21:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40fe27:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40fe2d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40fe36:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40fe3f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40fe48:	add    rsp,0xb8
  40fe4f:	pop    rsi
  40fe50:	pop    rdi
  40fe51:	ret
	...

000000000040fe60 <__swc_fn_6b1cf01f_000140_81b740ca>:
  40fe60:	push   rsi
  40fe61:	push   rdi
  40fe62:	push   r12
  40fe64:	push   r13
  40fe66:	push   r14
  40fe68:	push   r15
  40fe6a:	cmp    rdx,0x40
  40fe6e:	jae    40fe7d <__swc_fn_6b1cf01f_000140_81b740ca+0x1d>
  40fe70:	xor    eax,eax
  40fe72:	pop    r15
  40fe74:	pop    r14
  40fe76:	pop    r13
  40fe78:	pop    r12
  40fe7a:	pop    rdi
  40fe7b:	pop    rsi
  40fe7c:	ret
  40fe7d:	cmp    BYTE PTR [rcx],0x7f
  40fe80:	jne    40fec4 <__swc_fn_6b1cf01f_000140_81b740ca+0x64>
  40fe82:	movzx  eax,BYTE PTR [rcx+0x1]
  40fe86:	cmp    eax,0x45
  40fe89:	setne  al
  40fe8c:	jne    40fec0 <__swc_fn_6b1cf01f_000140_81b740ca+0x60>
  40fe8e:	movzx  eax,BYTE PTR [rcx+0x2]
  40fe92:	cmp    eax,0x4c
  40fe95:	setne  al
  40fe98:	jne    40fec0 <__swc_fn_6b1cf01f_000140_81b740ca+0x60>
  40fe9a:	movzx  eax,BYTE PTR [rcx+0x3]
  40fe9e:	cmp    eax,0x46
  40fea1:	setne  al
  40fea4:	jne    40fec0 <__swc_fn_6b1cf01f_000140_81b740ca+0x60>
  40fea6:	cmp    BYTE PTR [rcx+0x4],0x2
  40feaa:	setne  al
  40fead:	jne    40fec0 <__swc_fn_6b1cf01f_000140_81b740ca+0x60>
  40feaf:	cmp    BYTE PTR [rcx+0x5],0x1
  40feb3:	setne  al
  40feb6:	jne    40fec0 <__swc_fn_6b1cf01f_000140_81b740ca+0x60>
  40feb8:	cmp    WORD PTR [rcx+0x12],0x3e
  40febd:	setne  al
  40fec0:	test   al,al
  40fec2:	je     40fed1 <__swc_fn_6b1cf01f_000140_81b740ca+0x71>
  40fec4:	xor    eax,eax
  40fec6:	pop    r15
  40fec8:	pop    r14
  40feca:	pop    r13
  40fecc:	pop    r12
  40fece:	pop    rdi
  40fecf:	pop    rsi
  40fed0:	ret
  40fed1:	cmp    WORD PTR [rcx+0x3a],0x40
  40fed6:	jne    40fef1 <__swc_fn_6b1cf01f_000140_81b740ca+0x91>
  40fed8:	cmp    WORD PTR [rcx+0x3c],0x0
  40fedd:	sete   al
  40fee0:	je     40feed <__swc_fn_6b1cf01f_000140_81b740ca+0x8d>
  40fee2:	mov    ax,WORD PTR [rcx+0x3c]
  40fee6:	cmp    WORD PTR [rcx+0x3e],ax
  40feea:	setae  al
  40feed:	test   al,al
  40feef:	je     40fefe <__swc_fn_6b1cf01f_000140_81b740ca+0x9e>
  40fef1:	xor    eax,eax
  40fef3:	pop    r15
  40fef5:	pop    r14
  40fef7:	pop    r13
  40fef9:	pop    r12
  40fefb:	pop    rdi
  40fefc:	pop    rsi
  40fefd:	ret
  40fefe:	movzx  eax,WORD PTR [rcx+0x3c]
  40ff02:	shl    rax,0x6
  40ff06:	cmp    rax,rdx
  40ff09:	ja     40ff17 <__swc_fn_6b1cf01f_000140_81b740ca+0xb7>
  40ff0b:	mov    r9,rdx
  40ff0e:	sub    r9,rax
  40ff11:	cmp    QWORD PTR [rcx+0x28],r9
  40ff15:	jbe    40ff24 <__swc_fn_6b1cf01f_000140_81b740ca+0xc4>
  40ff17:	xor    eax,eax
  40ff19:	pop    r15
  40ff1b:	pop    r14
  40ff1d:	pop    r13
  40ff1f:	pop    r12
  40ff21:	pop    rdi
  40ff22:	pop    rsi
  40ff23:	ret
  40ff24:	mov    rax,QWORD PTR [rcx+0x28]
  40ff28:	add    rax,rcx
  40ff2b:	movzx  r9d,WORD PTR [rcx+0x3e]
  40ff30:	lea    r9,[r9*8+0x0]
  40ff38:	lea    r10,[rax+r9*8]
  40ff3c:	cmp    QWORD PTR [r10+0x20],rdx
  40ff40:	ja     40ff62 <__swc_fn_6b1cf01f_000140_81b740ca+0x102>
  40ff42:	mov    r11,rdx
  40ff45:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  40ff4a:	cmp    QWORD PTR [r10+0x18],r11
  40ff4e:	seta   r9b
  40ff52:	ja     40ff5d <__swc_fn_6b1cf01f_000140_81b740ca+0xfd>
  40ff54:	cmp    QWORD PTR [r10+0x20],0x9
  40ff59:	setb   r9b
  40ff5d:	test   r9b,r9b
  40ff60:	je     40ff6f <__swc_fn_6b1cf01f_000140_81b740ca+0x10f>
  40ff62:	xor    eax,eax
  40ff64:	pop    r15
  40ff66:	pop    r14
  40ff68:	pop    r13
  40ff6a:	pop    r12
  40ff6c:	pop    rdi
  40ff6d:	pop    rsi
  40ff6e:	ret
  40ff6f:	movzx  r9d,WORD PTR [rcx+0x3c]
  40ff74:	xor    r11d,r11d
  40ff77:	test   r9,r9
  40ff7a:	jbe    410075 <__swc_fn_6b1cf01f_000140_81b740ca+0x215>
  40ff80:	mov    rsi,QWORD PTR [r10+0x20]
  40ff84:	sub    rsi,0x9
  40ff88:	cs nop WORD PTR [rax+rax*1+0x0]
  40ff92:	cs nop WORD PTR [rax+rax*1+0x0]
  40ff9c:	nop    DWORD PTR [rax+0x0]
  40ffa0:	movzx  edi,r11w
  40ffa4:	lea    rdi,[rdi*8+0x0]
  40ffac:	lea    r12,[rax+rdi*8]
  40ffb0:	rex mov edi,DWORD PTR [rax+rdi*8]
  40ffb4:	cmp    rdi,rsi
  40ffb7:	ja     410068 <__swc_fn_6b1cf01f_000140_81b740ca+0x208>
  40ffbd:	mov    r13,QWORD PTR [r10+0x18]
  40ffc1:	add    r13,rdi
  40ffc4:	lea    rdi,[rcx+r13*1]
  40ffc8:	lea    r13,[rip+0x3561]        # 413530 <__swc_rdata_base_6b1cf01f+0x420>
  40ffcf:	movabs r14,0x676264676177732e
  40ffd9:	cmp    QWORD PTR [rdi],r14
  40ffdc:	jne    40ffe5 <__swc_fn_6b1cf01f_000140_81b740ca+0x185>
  40ffde:	rex cmp BYTE PTR [rdi+0x8],0x0
  40ffe3:	je     410012 <__swc_fn_6b1cf01f_000140_81b740ca+0x1b2>
  40ffe5:	cs nop WORD PTR [rax+rax*1+0x0]
  40ffef:	nop
  40fff0:	movzx  r14d,BYTE PTR [rdi]
  40fff4:	movzx  r15d,BYTE PTR [r13+0x0]
  40fff9:	cmp    r14,r15
  40fffc:	jne    410008 <__swc_fn_6b1cf01f_000140_81b740ca+0x1a8>
  40fffe:	add    rdi,0x1
  410002:	add    r13,0x1
  410006:	jmp    40fff0 <__swc_fn_6b1cf01f_000140_81b740ca+0x190>
  410008:	mov    rdi,r14
  41000b:	sub    rdi,r15
  41000e:	test   edi,edi
  410010:	jne    410068 <__swc_fn_6b1cf01f_000140_81b740ca+0x208>
  410012:	cmp    DWORD PTR [r12+0x4],0x1
  410018:	jne    410040 <__swc_fn_6b1cf01f_000140_81b740ca+0x1e0>
  41001a:	cmp    QWORD PTR [r12+0x20],0x10
  410020:	setb   al
  410023:	jb     41003c <__swc_fn_6b1cf01f_000140_81b740ca+0x1dc>
  410025:	cmp    QWORD PTR [r12+0x20],rdx
  41002a:	seta   al
  41002d:	ja     41003c <__swc_fn_6b1cf01f_000140_81b740ca+0x1dc>
  41002f:	sub    rdx,QWORD PTR [r12+0x20]
  410034:	cmp    QWORD PTR [r12+0x18],rdx
  410039:	seta   al
  41003c:	test   al,al
  41003e:	je     41004d <__swc_fn_6b1cf01f_000140_81b740ca+0x1ed>
  410040:	xor    eax,eax
  410042:	pop    r15
  410044:	pop    r14
  410046:	pop    r13
  410048:	pop    r12
  41004a:	pop    rdi
  41004b:	pop    rsi
  41004c:	ret
  41004d:	mov    rax,QWORD PTR [r12+0x20]
  410052:	mov    QWORD PTR [r8],rax
  410055:	mov    rax,QWORD PTR [r12+0x18]
  41005a:	add    rax,rcx
  41005d:	pop    r15
  41005f:	pop    r14
  410061:	pop    r13
  410063:	pop    r12
  410065:	pop    rdi
  410066:	pop    rsi
  410067:	ret
  410068:	add    r11,0x1
  41006c:	cmp    r11,r9
  41006f:	jb     40ffa0 <__swc_fn_6b1cf01f_000140_81b740ca+0x140>
  410075:	xor    eax,eax
  410077:	pop    r15
  410079:	pop    r14
  41007b:	pop    r13
  41007d:	pop    r12
  41007f:	pop    rdi
  410080:	pop    rsi
  410081:	ret
	...

0000000000410090 <__swc_fn_6b1cf01f_000143_afffe963>:
  410090:	push   rdi
  410091:	push   rsi
  410092:	sub    rsp,0xa8
  410099:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41009f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4100a5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4100ab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4100b1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4100b7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4100bd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4100c3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4100c9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4100d2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4100db:	mov    rdi,rcx
  4100de:	xor    eax,eax
  4100e0:	call   4071f0 <free@plt>
  4100e5:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4100eb:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4100f1:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4100f7:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4100fd:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410103:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410109:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41010f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410115:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41011e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410127:	add    rsp,0xa8
  41012e:	pop    rsi
  41012f:	pop    rdi
  410130:	ret
	...

0000000000410140 <__swc_fn_6b1cf01f_000146_e9d46966>:
  410140:	push   rbx
  410141:	push   rsi
  410142:	push   rdi
  410143:	push   r12
  410145:	push   r13
  410147:	push   r15
  410149:	sub    rsp,0x4e8
  410150:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  410159:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  410162:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  41016b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  410174:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  41017d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  410186:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  41018f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  410198:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  4101a1:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  4101aa:	mov    rbx,QWORD PTR [rcx]
  4101ad:	mov    rcx,QWORD PTR [rcx+0x8]
  4101b1:	mov    rsi,rcx
  4101b4:	xor    edi,edi
  4101b6:	vmovsd xmm6,QWORD PTR [rip+0x33d2]        # 413590 <__swc_rdata_base_6b1cf01f+0x480>
  4101be:	vmovsd xmm7,QWORD PTR [rip+0x33d3]        # 413599 <__swc_rdata_base_6b1cf01f+0x489>
  4101c6:	vmovsd xmm8,QWORD PTR [rip+0x33d4]        # 4135a2 <__swc_rdata_base_6b1cf01f+0x492>
  4101ce:	vmovsd xmm9,QWORD PTR [rip+0x33d5]        # 4135ab <__swc_rdata_base_6b1cf01f+0x49b>
  4101d6:	vmovsd xmm10,QWORD PTR [rip+0x33d6]        # 4135b4 <__swc_rdata_base_6b1cf01f+0x4a4>
  4101de:	vmovups xmm11,xmm6
  4101e2:	vmovsd QWORD PTR [rsp+0x418],xmm7
  4101eb:	vmovsd QWORD PTR [rsp+0x420],xmm8
  4101f4:	vmovsd QWORD PTR [rsp+0x428],xmm9
  4101fd:	vmovsd QWORD PTR [rsp+0x430],xmm10
  410206:	vmovsd xmm15,QWORD PTR [rip+0x33af]        # 4135bd <__swc_rdata_base_6b1cf01f+0x4ad>
  41020e:	vmovups xmm14,xmm15
  410213:	vmovups xmm0,xmm9
  410218:	vmovsd QWORD PTR [rsp+0x438],xmm15
  410221:	vmovups xmm13,xmm8
  410226:	vmovsd QWORD PTR [rsp+0x440],xmm15
  41022f:	test   rsi,rsi
  410232:	je     411223 <__swc_fn_6b1cf01f_000146_e9d46966+0x10e3>
  410238:	cs nop WORD PTR [rax+rax*1+0x0]
  410242:	cs nop WORD PTR [rax+rax*1+0x0]
  41024c:	nop    DWORD PTR [rax+0x0]
  410250:	lea    rcx,[rdi+rdi*1]
  410254:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  410259:	vpshufd xmm3,xmm2,0xee
  41025e:	vmovq  rcx,xmm3
  410263:	test   rcx,rcx
  410266:	je     41027c <__swc_fn_6b1cf01f_000146_e9d46966+0x13c>
  410268:	test   DWORD PTR [rcx+0x28],0x400000
  41026f:	je     41027c <__swc_fn_6b1cf01f_000146_e9d46966+0x13c>
  410271:	mov    rdx,QWORD PTR [rcx+0x30]
  410275:	test   rdx,rdx
  410278:	cmovne rcx,rdx
  41027c:	test   DWORD PTR [rcx+0x28],0x1000
  410283:	je     4102a4 <__swc_fn_6b1cf01f_000146_e9d46966+0x164>
  410285:	mov    rdx,QWORD PTR [rcx+0x40]
  410289:	mov    rcx,rdx
  41028c:	vmovq  r8,xmm2
  410291:	mov    r8,QWORD PTR [r8]
  410294:	mov    QWORD PTR [rsp+0x60],r8
  410299:	mov    QWORD PTR [rsp+0x68],rdx
  41029e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  4102a4:	test   BYTE PTR [rcx+0x28],0x1
  4102a8:	jne    4102b0 <__swc_fn_6b1cf01f_000146_e9d46966+0x170>
  4102aa:	vmovups xmm12,xmm0
  4102ae:	jmp    4102ca <__swc_fn_6b1cf01f_000146_e9d46966+0x18a>
  4102b0:	vmovq  rax,xmm2
  4102b5:	mov    rax,QWORD PTR [rax]
  4102b8:	lea    rcx,[rax+0x10]
  4102bc:	vmovups xmm12,xmm0
  4102c0:	call   40f8d0 <__swc_fn_6b1cf01f_000116_3499f7d6>
  4102c5:	jmp    411205 <__swc_fn_6b1cf01f_000146_e9d46966+0x10c5>
  4102ca:	test   DWORD PTR [rcx+0x28],0x400
  4102d1:	je     410332 <__swc_fn_6b1cf01f_000146_e9d46966+0x1f2>
  4102d3:	vmovq  rax,xmm2
  4102d8:	mov    rax,QWORD PTR [rax]
  4102db:	xor    ecx,ecx
  4102dd:	test   rax,rax
  4102e0:	je     410310 <__swc_fn_6b1cf01f_000146_e9d46966+0x1d0>
  4102e2:	mov    rdx,rax
  4102e5:	mov    r8b,BYTE PTR [rdx]
  4102e8:	test   r8b,r8b
  4102eb:	je     410310 <__swc_fn_6b1cf01f_000146_e9d46966+0x1d0>
  4102ed:	cs nop WORD PTR [rax+rax*1+0x0]
  4102f7:	nop    WORD PTR [rax+rax*1+0x0]
  410300:	add    rdx,0x1
  410304:	add    rcx,0x1
  410308:	mov    r8b,BYTE PTR [rdx]
  41030b:	test   r8b,r8b
  41030e:	jne    410300 <__swc_fn_6b1cf01f_000146_e9d46966+0x1c0>
  410310:	mov    QWORD PTR [rsp+0x88],rax
  410318:	mov    QWORD PTR [rsp+0x90],rcx
  410320:	lea    rcx,[rsp+0x88]
  410328:	call   40f8d0 <__swc_fn_6b1cf01f_000116_3499f7d6>
  41032d:	jmp    411205 <__swc_fn_6b1cf01f_000146_e9d46966+0x10c5>
  410332:	cmp    BYTE PTR [rcx+0x2c],0x6
  410336:	jne    41034d <__swc_fn_6b1cf01f_000146_e9d46966+0x20d>
  410338:	vmovq  rax,xmm2
  41033d:	mov    rax,QWORD PTR [rax]
  410340:	mov    rcx,rax
  410343:	call   409cb0 <__swc_fn_6b1cf01f_000144_364559f5>
  410348:	jmp    411205 <__swc_fn_6b1cf01f_000146_e9d46966+0x10c5>
  41034d:	cmp    BYTE PTR [rcx+0x2c],0x1
  410351:	jne    4111f9 <__swc_fn_6b1cf01f_000146_e9d46966+0x10b9>
  410357:	vmovq  rdx,xmm2
  41035c:	mov    cl,BYTE PTR [rcx+0x40]
  41035f:	cmp    cl,0x7
  410362:	jb     4103a5 <__swc_fn_6b1cf01f_000146_e9d46966+0x265>
  410364:	je     410418 <__swc_fn_6b1cf01f_000146_e9d46966+0x2d8>
  41036a:	cmp    cl,0x8
  41036d:	je     410424 <__swc_fn_6b1cf01f_000146_e9d46966+0x2e4>
  410373:	cmp    cl,0x9
  410376:	je     41043d <__swc_fn_6b1cf01f_000146_e9d46966+0x2fd>
  41037c:	cmp    cl,0xa
  41037f:	je     410b04 <__swc_fn_6b1cf01f_000146_e9d46966+0x9c4>
  410385:	cmp    cl,0xb
  410388:	je     4111cb <__swc_fn_6b1cf01f_000146_e9d46966+0x108b>
  41038e:	cmp    cl,0xc
  410391:	je     410431 <__swc_fn_6b1cf01f_000146_e9d46966+0x2f1>
  410397:	cmp    cl,0xd
  41039a:	je     4111c1 <__swc_fn_6b1cf01f_000146_e9d46966+0x1081>
  4103a0:	jmp    4111eb <__swc_fn_6b1cf01f_000146_e9d46966+0x10ab>
  4103a5:	cmp    cl,0x1
  4103a8:	je     4103c8 <__swc_fn_6b1cf01f_000146_e9d46966+0x288>
  4103aa:	cmp    cl,0x2
  4103ad:	je     4103d6 <__swc_fn_6b1cf01f_000146_e9d46966+0x296>
  4103af:	cmp    cl,0x3
  4103b2:	je     4103e4 <__swc_fn_6b1cf01f_000146_e9d46966+0x2a4>
  4103b4:	cmp    cl,0x4
  4103b7:	je     4103f1 <__swc_fn_6b1cf01f_000146_e9d46966+0x2b1>
  4103b9:	cmp    cl,0x5
  4103bc:	je     4103fe <__swc_fn_6b1cf01f_000146_e9d46966+0x2be>
  4103be:	cmp    cl,0x6
  4103c1:	je     41040b <__swc_fn_6b1cf01f_000146_e9d46966+0x2cb>
  4103c3:	jmp    4111eb <__swc_fn_6b1cf01f_000146_e9d46966+0x10ab>
  4103c8:	movsx  rcx,BYTE PTR [rdx]
  4103cc:	call   40ce80 <__swc_fn_6b1cf01f_000145_071b4f4c>
  4103d1:	jmp    411205 <__swc_fn_6b1cf01f_000146_e9d46966+0x10c5>
  4103d6:	movsx  rcx,WORD PTR [rdx]
  4103da:	call   40ce80 <__swc_fn_6b1cf01f_000145_071b4f4c>
  4103df:	jmp    411205 <__swc_fn_6b1cf01f_000146_e9d46966+0x10c5>
  4103e4:	movsxd rcx,DWORD PTR [rdx]
  4103e7:	call   40ce80 <__swc_fn_6b1cf01f_000145_071b4f4c>
  4103ec:	jmp    411205 <__swc_fn_6b1cf01f_000146_e9d46966+0x10c5>
  4103f1:	mov    rcx,QWORD PTR [rdx]
  4103f4:	call   40ce80 <__swc_fn_6b1cf01f_000145_071b4f4c>
  4103f9:	jmp    411205 <__swc_fn_6b1cf01f_000146_e9d46966+0x10c5>
  4103fe:	movzx  ecx,BYTE PTR [rdx]
  410401:	call   409cb0 <__swc_fn_6b1cf01f_000144_364559f5>
  410406:	jmp    411205 <__swc_fn_6b1cf01f_000146_e9d46966+0x10c5>
  41040b:	movzx  ecx,WORD PTR [rdx]
  41040e:	call   409cb0 <__swc_fn_6b1cf01f_000144_364559f5>
  410413:	jmp    411205 <__swc_fn_6b1cf01f_000146_e9d46966+0x10c5>
  410418:	mov    ecx,DWORD PTR [rdx]
  41041a:	call   409cb0 <__swc_fn_6b1cf01f_000144_364559f5>
  41041f:	jmp    411205 <__swc_fn_6b1cf01f_000146_e9d46966+0x10c5>
  410424:	mov    rcx,QWORD PTR [rdx]
  410427:	call   409cb0 <__swc_fn_6b1cf01f_000144_364559f5>
  41042c:	jmp    411205 <__swc_fn_6b1cf01f_000146_e9d46966+0x10c5>
  410431:	mov    ecx,DWORD PTR [rdx]
  410433:	call   409cb0 <__swc_fn_6b1cf01f_000144_364559f5>
  410438:	jmp    411205 <__swc_fn_6b1cf01f_000146_e9d46966+0x10c5>
  41043d:	lea    rcx,[rsp+0xa8]
  410445:	vxorps xmm0,xmm0,xmm0
  410449:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  410452:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  41045b:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  410464:	vzeroupper
  410467:	mov    DWORD PTR [rsp+0x108],0x0
  410472:	vxorpd xmm0,xmm0,xmm0
  410476:	vmovss xmm1,DWORD PTR [rdx]
  41047a:	vcvtss2sd xmm0,xmm0,xmm1
  41047e:	vmovsd xmm1,xmm1,xmm0
  410482:	vcomisd xmm0,xmm0
  410486:	setne  dl
  410489:	movzx  edx,dl
  41048c:	setp   r8b
  410490:	movzx  r8d,r8b
  410494:	or     edx,r8d
  410497:	test   dl,dl
  410499:	je     4104a6 <__swc_fn_6b1cf01f_000146_e9d46966+0x366>
  41049b:	mov    DWORD PTR [rcx],0x6e616e
  4104a1:	jmp    410a98 <__swc_fn_6b1cf01f_000146_e9d46966+0x958>
  4104a6:	vcomisd xmm1,xmm6
  4104aa:	ja     4104b2 <__swc_fn_6b1cf01f_000146_e9d46966+0x372>
  4104ac:	vcomisd xmm7,xmm1
  4104b0:	jbe    4104d6 <__swc_fn_6b1cf01f_000146_e9d46966+0x396>
  4104b2:	vxorpd xmm0,xmm0,xmm0
  4104b6:	vcomisd xmm0,xmm1
  4104ba:	jbe    4104cb <__swc_fn_6b1cf01f_000146_e9d46966+0x38b>
  4104bc:	mov    DWORD PTR [rcx],0x666e692d
  4104c2:	mov    BYTE PTR [rcx+0x4],0x0
  4104c6:	jmp    410a98 <__swc_fn_6b1cf01f_000146_e9d46966+0x958>
  4104cb:	mov    DWORD PTR [rcx],0x666e69
  4104d1:	jmp    410a98 <__swc_fn_6b1cf01f_000146_e9d46966+0x958>
  4104d6:	vcomisd xmm1,xmm8
  4104db:	jae    4104e7 <__swc_fn_6b1cf01f_000146_e9d46966+0x3a7>
  4104dd:	vcomisd xmm9,xmm1
  4104e1:	jbe    41085e <__swc_fn_6b1cf01f_000146_e9d46966+0x71e>
  4104e7:	vmovups xmm0,xmm1
  4104eb:	vxorpd xmm2,xmm2,xmm2
  4104ef:	vcomisd xmm2,xmm1
  4104f3:	jbe    410503 <__swc_fn_6b1cf01f_000146_e9d46966+0x3c3>
  4104f5:	vmovsd xmm1,xmm1,xmm0
  4104f9:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x304f]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  410501:	jmp    410507 <__swc_fn_6b1cf01f_000146_e9d46966+0x3c7>
  410503:	vmovsd xmm1,xmm1,xmm0
  410507:	xor    r8d,r8d
  41050a:	vcomisd xmm1,xmm15
  41050f:	jb     410530 <__swc_fn_6b1cf01f_000146_e9d46966+0x3f0>
  410511:	cs nop WORD PTR [rax+rax*1+0x0]
  41051b:	nop    DWORD PTR [rax+rax*1+0x0]
  410520:	vdivsd xmm1,xmm1,xmm15
  410525:	add    r8,0x1
  410529:	vcomisd xmm1,xmm15
  41052e:	jae    410520 <__swc_fn_6b1cf01f_000146_e9d46966+0x3e0>
  410530:	mov    r9,rcx
  410533:	vxorpd xmm2,xmm2,xmm2
  410537:	vcomisd xmm2,xmm0
  41053b:	jbe    410544 <__swc_fn_6b1cf01f_000146_e9d46966+0x404>
  41053d:	mov    BYTE PTR [rcx],0x2d
  410540:	lea    r9,[rcx+0x1]
  410544:	vcvttsd2si rdx,xmm1
  410549:	mov    r10b,dl
  41054c:	add    r10b,0x30
  410550:	mov    BYTE PTR [r9],r10b
  410553:	vxorpd xmm0,xmm0,xmm0
  410557:	movzx  edx,dl
  41055a:	vcvtsi2sd xmm0,xmm0,rdx
  41055f:	vsubsd xmm0,xmm1,xmm0
  410563:	vmulsd xmm1,xmm0,xmm15
  410568:	mov    BYTE PTR [r9+0x1],0x2e
  41056d:	vcvttsd2si rdx,xmm1
  410572:	mov    r10b,dl
  410575:	add    r10b,0x30
  410579:	mov    BYTE PTR [r9+0x2],r10b
  41057d:	vxorpd xmm0,xmm0,xmm0
  410581:	movzx  edx,dl
  410584:	vcvtsi2sd xmm0,xmm0,rdx
  410589:	vsubsd xmm0,xmm1,xmm0
  41058d:	vmulsd xmm1,xmm0,xmm15
  410592:	vcvttsd2si rdx,xmm1
  410597:	mov    r10b,dl
  41059a:	add    r10b,0x30
  41059e:	mov    BYTE PTR [r9+0x3],r10b
  4105a2:	vxorpd xmm0,xmm0,xmm0
  4105a6:	movzx  edx,dl
  4105a9:	vcvtsi2sd xmm0,xmm0,rdx
  4105ae:	vsubsd xmm0,xmm1,xmm0
  4105b2:	vmulsd xmm1,xmm0,xmm15
  4105b7:	vcvttsd2si rdx,xmm1
  4105bc:	mov    r10b,dl
  4105bf:	add    r10b,0x30
  4105c3:	mov    BYTE PTR [r9+0x4],r10b
  4105c7:	vxorpd xmm0,xmm0,xmm0
  4105cb:	movzx  edx,dl
  4105ce:	vcvtsi2sd xmm0,xmm0,rdx
  4105d3:	vsubsd xmm0,xmm1,xmm0
  4105d7:	vmulsd xmm1,xmm0,xmm15
  4105dc:	vcvttsd2si rdx,xmm1
  4105e1:	mov    r10b,dl
  4105e4:	add    r10b,0x30
  4105e8:	mov    BYTE PTR [r9+0x5],r10b
  4105ec:	vxorpd xmm0,xmm0,xmm0
  4105f0:	movzx  edx,dl
  4105f3:	vcvtsi2sd xmm0,xmm0,rdx
  4105f8:	vsubsd xmm0,xmm1,xmm0
  4105fc:	vmulsd xmm1,xmm0,xmm15
  410601:	vcvttsd2si rdx,xmm1
  410606:	mov    r10b,dl
  410609:	add    r10b,0x30
  41060d:	mov    BYTE PTR [r9+0x6],r10b
  410611:	vxorpd xmm0,xmm0,xmm0
  410615:	movzx  edx,dl
  410618:	vcvtsi2sd xmm0,xmm0,rdx
  41061d:	vsubsd xmm0,xmm1,xmm0
  410621:	vmulsd xmm1,xmm0,xmm15
  410626:	vcvttsd2si rdx,xmm1
  41062b:	mov    r10b,dl
  41062e:	add    r10b,0x30
  410632:	mov    BYTE PTR [r9+0x7],r10b
  410636:	vxorpd xmm0,xmm0,xmm0
  41063a:	movzx  edx,dl
  41063d:	vcvtsi2sd xmm0,xmm0,rdx
  410642:	vsubsd xmm0,xmm1,xmm0
  410646:	vmulsd xmm1,xmm0,xmm15
  41064b:	vcvttsd2si rdx,xmm1
  410650:	mov    r10b,dl
  410653:	add    r10b,0x30
  410657:	mov    BYTE PTR [r9+0x8],r10b
  41065b:	vxorpd xmm0,xmm0,xmm0
  41065f:	movzx  edx,dl
  410662:	vcvtsi2sd xmm0,xmm0,rdx
  410667:	vsubsd xmm0,xmm1,xmm0
  41066b:	vmulsd xmm1,xmm0,xmm15
  410670:	vcvttsd2si rdx,xmm1
  410675:	mov    r10b,dl
  410678:	add    r10b,0x30
  41067c:	mov    BYTE PTR [r9+0x9],r10b
  410680:	vxorpd xmm0,xmm0,xmm0
  410684:	movzx  edx,dl
  410687:	vcvtsi2sd xmm0,xmm0,rdx
  41068c:	vsubsd xmm0,xmm1,xmm0
  410690:	vmulsd xmm1,xmm0,xmm15
  410695:	vcvttsd2si rdx,xmm1
  41069a:	mov    r10b,dl
  41069d:	add    r10b,0x30
  4106a1:	mov    BYTE PTR [r9+0xa],r10b
  4106a5:	vxorpd xmm0,xmm0,xmm0
  4106a9:	movzx  edx,dl
  4106ac:	vcvtsi2sd xmm0,xmm0,rdx
  4106b1:	vsubsd xmm0,xmm1,xmm0
  4106b5:	vmulsd xmm1,xmm0,xmm15
  4106ba:	vcvttsd2si rdx,xmm1
  4106bf:	mov    r10b,dl
  4106c2:	add    r10b,0x30
  4106c6:	mov    BYTE PTR [r9+0xb],r10b
  4106ca:	lea    r10,[r9+0x4]
  4106ce:	vxorpd xmm0,xmm0,xmm0
  4106d2:	movzx  edx,dl
  4106d5:	vcvtsi2sd xmm0,xmm0,rdx
  4106da:	vsubsd xmm0,xmm1,xmm0
  4106de:	vmulsd xmm1,xmm0,xmm15
  4106e3:	vcvttsd2si rdx,xmm1
  4106e8:	mov    r11b,dl
  4106eb:	add    r11b,0x30
  4106ef:	mov    BYTE PTR [r9+0xc],r11b
  4106f3:	vxorpd xmm0,xmm0,xmm0
  4106f7:	movzx  edx,dl
  4106fa:	vcvtsi2sd xmm0,xmm0,rdx
  4106ff:	vsubsd xmm0,xmm1,xmm0
  410703:	vmulsd xmm1,xmm0,xmm15
  410708:	vcvttsd2si rdx,xmm1
  41070d:	mov    r11b,dl
  410710:	add    r11b,0x30
  410714:	mov    BYTE PTR [r9+0xd],r11b
  410718:	lea    r10,[r10+0x2]
  41071c:	vxorpd xmm0,xmm0,xmm0
  410720:	movzx  edx,dl
  410723:	vcvtsi2sd xmm0,xmm0,rdx
  410728:	vsubsd xmm0,xmm1,xmm0
  41072c:	vmulsd xmm1,xmm0,xmm15
  410731:	vcvttsd2si rdx,xmm1
  410736:	mov    r11b,dl
  410739:	add    r11b,0x30
  41073d:	mov    BYTE PTR [r9+0xe],r11b
  410741:	vxorpd xmm0,xmm0,xmm0
  410745:	movzx  edx,dl
  410748:	vcvtsi2sd xmm0,xmm0,rdx
  41074d:	vsubsd xmm0,xmm1,xmm0
  410751:	vmulsd xmm1,xmm0,xmm15
  410756:	vcvttsd2si rdx,xmm1
  41075b:	mov    r11b,dl
  41075e:	add    r11b,0x30
  410762:	mov    BYTE PTR [r9+0xf],r11b
  410766:	lea    r10,[r10+0x2]
  41076a:	lea    r10,[r10+0x2]
  41076e:	lea    r10,[r10+0x2]
  410772:	lea    r10,[r10+0x2]
  410776:	lea    r10,[r10+0x2]
  41077a:	vxorpd xmm0,xmm0,xmm0
  41077e:	movzx  edx,dl
  410781:	vcvtsi2sd xmm0,xmm0,rdx
  410786:	vsubsd xmm0,xmm1,xmm0
  41078a:	vmulsd xmm1,xmm0,xmm15
  41078f:	vcvttsd2si rdx,xmm1
  410794:	mov    r11b,dl
  410797:	add    r11b,0x30
  41079b:	mov    BYTE PTR [r9+0x10],r11b
  41079f:	vxorpd xmm0,xmm0,xmm0
  4107a3:	movzx  edx,dl
  4107a6:	vcvtsi2sd xmm0,xmm0,rdx
  4107ab:	vsubsd xmm0,xmm1,xmm0
  4107af:	vmulsd xmm1,xmm0,xmm15
  4107b4:	vcvttsd2si rdx,xmm1
  4107b9:	add    dl,0x30
  4107bc:	mov    BYTE PTR [r9+0x11],dl
  4107c0:	mov    BYTE PTR [r10+0x2],0x65
  4107c5:	lea    r9,[r10+0x3]
  4107c9:	test   r8,r8
  4107cc:	jl     4107d5 <__swc_fn_6b1cf01f_000146_e9d46966+0x695>
  4107ce:	mov    BYTE PTR [r9],0x2b
  4107d2:	inc    r9
  4107d5:	mov    r10,r9
  4107d8:	mov    rdx,r8
  4107db:	nop    DWORD PTR [rax+rax*1+0x0]
  4107e0:	mov    r11,rdx
  4107e3:	movabs rdx,0x6666666666666667
  4107ed:	mov    rax,r11
  4107f0:	imul   rdx
  4107f3:	sar    rdx,0x2
  4107f7:	mov    r12,rdx
  4107fa:	shr    rdx,0x3f
  4107fe:	add    r12,rdx
  410801:	mov    rdx,r12
  410804:	imul   r13,r12,0xa
  410808:	sub    r11,r13
  41080b:	mov    r13,QWORD PTR [rip+0x2d2e]        # 413540 <__swc_rdata_base_6b1cf01f+0x430>
  410812:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410817:	mov    BYTE PTR [r10],r11b
  41081a:	lea    r11,[r10+0x1]
  41081e:	mov    r10,r11
  410821:	test   r12,r12
  410824:	jne    4107e0 <__swc_fn_6b1cf01f_000146_e9d46966+0x6a0>
  410826:	test   r8,r8
  410829:	jge    410833 <__swc_fn_6b1cf01f_000146_e9d46966+0x6f3>
  41082b:	mov    BYTE PTR [r11],0x2d
  41082f:	lea    r10,[r11+0x1]
  410833:	mov    BYTE PTR [r10],0x0
  410837:	sub    r10,0x1
  41083b:	nop    DWORD PTR [rax+rax*1+0x0]
  410840:	cmp    r9,r10
  410843:	jae    410a98 <__swc_fn_6b1cf01f_000146_e9d46966+0x958>
  410849:	mov    al,BYTE PTR [r10]
  41084c:	mov    dl,BYTE PTR [r9]
  41084f:	mov    BYTE PTR [r10],dl
  410852:	sub    r10,0x1
  410856:	mov    BYTE PTR [r9],al
  410859:	inc    r9
  41085c:	jmp    410840 <__swc_fn_6b1cf01f_000146_e9d46966+0x700>
  41085e:	vcvttsd2si rdx,xmm1
  410863:	mov    r8,rdx
  410866:	vxorpd xmm0,xmm0,xmm0
  41086a:	vcvtsi2sd xmm0,xmm0,rdx
  41086f:	vsubsd xmm0,xmm1,xmm0
  410873:	mov    r9d,0x8
  410879:	vxorpd xmm2,xmm2,xmm2
  41087d:	vcomisd xmm2,xmm0
  410881:	jbe    41088b <__swc_fn_6b1cf01f_000146_e9d46966+0x74b>
  410883:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x2cc5]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  41088b:	test   r9d,r9d
  41088e:	je     41089a <__swc_fn_6b1cf01f_000146_e9d46966+0x75a>
  410890:	vmulsd xmm0,xmm0,xmm14
  410895:	dec    r9d
  410898:	jne    410890 <__swc_fn_6b1cf01f_000146_e9d46966+0x750>
  41089a:	vcvttsd2si r9,xmm0
  41089f:	mov    r10,r9
  4108a2:	vxorpd xmm2,xmm2,xmm2
  4108a6:	vcvtsi2sd xmm2,xmm2,r9
  4108ab:	vsubsd xmm0,xmm0,xmm2
  4108af:	vcomisd xmm0,xmm10
  4108b4:	lea    r9,[r9+0x1]
  4108b8:	cmova  r10,r9
  4108bc:	cmp    r10,0x5f5e100
  4108c3:	jne    4108dc <__swc_fn_6b1cf01f_000146_e9d46966+0x79c>
  4108c5:	lea    r8,[rdx-0x1]
  4108c9:	vxorpd xmm0,xmm0,xmm0
  4108cd:	vcomisd xmm0,xmm1
  4108d1:	lea    rdx,[rdx+0x1]
  4108d5:	cmovbe r8,rdx
  4108d9:	xor    r10d,r10d
  4108dc:	mov    r9,rcx
  4108df:	test   r8,r8
  4108e2:	jne    410902 <__swc_fn_6b1cf01f_000146_e9d46966+0x7c2>
  4108e4:	vxorpd xmm0,xmm0,xmm0
  4108e8:	vcomisd xmm0,xmm1
  4108ec:	jbe    4108f5 <__swc_fn_6b1cf01f_000146_e9d46966+0x7b5>
  4108ee:	mov    BYTE PTR [rcx],0x2d
  4108f1:	lea    r9,[rcx+0x1]
  4108f5:	mov    BYTE PTR [r9],0x30
  4108f9:	add    r9,0x1
  4108fd:	jmp    41099b <__swc_fn_6b1cf01f_000146_e9d46966+0x85b>
  410902:	mov    r9,rcx
  410905:	mov    rdx,r8
  410908:	nop    DWORD PTR [rax+rax*1+0x0]
  410910:	mov    r11,rdx
  410913:	movabs rdx,0x6666666666666667
  41091d:	mov    r15,rax
  410920:	mov    rax,r11
  410923:	imul   rdx
  410926:	mov    r12,rdx
  410929:	mov    rax,r15
  41092c:	sar    r12,0x2
  410930:	mov    rdx,r12
  410933:	shr    rdx,0x3f
  410937:	add    r12,rdx
  41093a:	mov    rdx,r12
  41093d:	imul   r13,r12,0xa
  410941:	sub    r11,r13
  410944:	mov    r13,QWORD PTR [rip+0x2bf5]        # 413540 <__swc_rdata_base_6b1cf01f+0x430>
  41094b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410950:	mov    BYTE PTR [r9],r11b
  410953:	lea    r11,[r9+0x1]
  410957:	mov    r9,r11
  41095a:	test   r12,r12
  41095d:	jne    410910 <__swc_fn_6b1cf01f_000146_e9d46966+0x7d0>
  41095f:	test   r8,r8
  410962:	jge    41096c <__swc_fn_6b1cf01f_000146_e9d46966+0x82c>
  410964:	mov    BYTE PTR [r11],0x2d
  410968:	lea    r9,[r11+0x1]
  41096c:	mov    rdx,r9
  41096f:	mov    BYTE PTR [r9],0x0
  410973:	sub    r9,0x1
  410977:	mov    r8,rcx
  41097a:	cmp    r8,r9
  41097d:	jae    410998 <__swc_fn_6b1cf01f_000146_e9d46966+0x858>
  41097f:	nop
  410980:	mov    r11b,BYTE PTR [r9]
  410983:	mov    r12b,BYTE PTR [r8]
  410986:	mov    BYTE PTR [r9],r12b
  410989:	sub    r9,0x1
  41098d:	mov    BYTE PTR [r8],r11b
  410990:	inc    r8
  410993:	cmp    r8,r9
  410996:	jb     410980 <__swc_fn_6b1cf01f_000146_e9d46966+0x840>
  410998:	mov    r9,rdx
  41099b:	mov    BYTE PTR [r9],0x2e
  41099f:	add    r9,0x1
  4109a3:	xor    r8d,r8d
  4109a6:	test   r10,r10
  4109a9:	je     4109ef <__swc_fn_6b1cf01f_000146_e9d46966+0x8af>
  4109ab:	mov    r11d,0x989680
  4109b1:	cmp    r10,r11
  4109b4:	jge    4109ef <__swc_fn_6b1cf01f_000146_e9d46966+0x8af>
  4109b6:	cs nop WORD PTR [rax+rax*1+0x0]
  4109c0:	inc    r8d
  4109c3:	movabs rdx,0x6666666666666667
  4109cd:	mov    r15,rax
  4109d0:	mov    rax,r11
  4109d3:	imul   rdx
  4109d6:	mov    r11,rdx
  4109d9:	mov    rax,r15
  4109dc:	sar    r11,0x2
  4109e0:	mov    rdx,r11
  4109e3:	shr    rdx,0x3f
  4109e7:	add    r11,rdx
  4109ea:	cmp    r10,r11
  4109ed:	jl     4109c0 <__swc_fn_6b1cf01f_000146_e9d46966+0x880>
  4109ef:	test   r8d,r8d
  4109f2:	je     410a0d <__swc_fn_6b1cf01f_000146_e9d46966+0x8cd>
  4109f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4109fe:	xchg   ax,ax
  410a00:	mov    BYTE PTR [r9],0x30
  410a04:	add    r9,0x1
  410a08:	dec    r8d
  410a0b:	jne    410a00 <__swc_fn_6b1cf01f_000146_e9d46966+0x8c0>
  410a0d:	mov    r8,r9
  410a10:	mov    rdx,r10
  410a13:	cs nop WORD PTR [rax+rax*1+0x0]
  410a1d:	nop    DWORD PTR [rax]
  410a20:	mov    r11,rdx
  410a23:	movabs rdx,0x6666666666666667
  410a2d:	mov    rax,r11
  410a30:	imul   rdx
  410a33:	sar    rdx,0x2
  410a37:	mov    r12,rdx
  410a3a:	shr    rdx,0x3f
  410a3e:	add    r12,rdx
  410a41:	mov    rdx,r12
  410a44:	imul   r13,r12,0xa
  410a48:	sub    r11,r13
  410a4b:	mov    r13,QWORD PTR [rip+0x2aee]        # 413540 <__swc_rdata_base_6b1cf01f+0x430>
  410a52:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410a57:	mov    BYTE PTR [r8],r11b
  410a5a:	lea    r11,[r8+0x1]
  410a5e:	mov    r8,r11
  410a61:	test   r12,r12
  410a64:	jne    410a20 <__swc_fn_6b1cf01f_000146_e9d46966+0x8e0>
  410a66:	test   r10,r10
  410a69:	jge    410a73 <__swc_fn_6b1cf01f_000146_e9d46966+0x933>
  410a6b:	mov    BYTE PTR [r11],0x2d
  410a6f:	lea    r8,[r11+0x1]
  410a73:	mov    BYTE PTR [r8],0x0
  410a77:	sub    r8,0x1
  410a7b:	cmp    r9,r8
  410a7e:	jae    410a98 <__swc_fn_6b1cf01f_000146_e9d46966+0x958>
  410a80:	mov    al,BYTE PTR [r8]
  410a83:	mov    dl,BYTE PTR [r9]
  410a86:	mov    BYTE PTR [r8],dl
  410a89:	sub    r8,0x1
  410a8d:	mov    BYTE PTR [r9],al
  410a90:	inc    r9
  410a93:	cmp    r9,r8
  410a96:	jb     410a80 <__swc_fn_6b1cf01f_000146_e9d46966+0x940>
  410a98:	xor    eax,eax
  410a9a:	test   rcx,rcx
  410a9d:	je     410ad0 <__swc_fn_6b1cf01f_000146_e9d46966+0x990>
  410a9f:	mov    rdx,rcx
  410aa2:	mov    r8b,BYTE PTR [rdx]
  410aa5:	test   r8b,r8b
  410aa8:	je     410ad0 <__swc_fn_6b1cf01f_000146_e9d46966+0x990>
  410aaa:	cs nop WORD PTR [rax+rax*1+0x0]
  410ab4:	cs nop WORD PTR [rax+rax*1+0x0]
  410abe:	xchg   ax,ax
  410ac0:	add    rdx,0x1
  410ac4:	add    rax,0x1
  410ac8:	mov    r8b,BYTE PTR [rdx]
  410acb:	test   r8b,r8b
  410ace:	jne    410ac0 <__swc_fn_6b1cf01f_000146_e9d46966+0x980>
  410ad0:	mov    QWORD PTR [rsp+0x240],rcx
  410ad8:	mov    QWORD PTR [rsp+0x248],rax
  410ae0:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  410ae9:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  410af2:	lea    rcx,[rsp+0x250]
  410afa:	call   40f8d0 <__swc_fn_6b1cf01f_000116_3499f7d6>
  410aff:	jmp    411205 <__swc_fn_6b1cf01f_000146_e9d46966+0x10c5>
  410b04:	lea    rcx,[rsp+0x260]
  410b0c:	vxorps xmm0,xmm0,xmm0
  410b10:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  410b19:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  410b22:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  410b2b:	vzeroupper
  410b2e:	mov    DWORD PTR [rsp+0x2c0],0x0
  410b39:	vmovsd xmm0,QWORD PTR [rdx]
  410b3d:	vcomisd xmm0,xmm0
  410b41:	setne  dl
  410b44:	movzx  edx,dl
  410b47:	setp   r8b
  410b4b:	movzx  r8d,r8b
  410b4f:	or     edx,r8d
  410b52:	test   dl,dl
  410b54:	je     410b61 <__swc_fn_6b1cf01f_000146_e9d46966+0xa21>
  410b56:	mov    DWORD PTR [rcx],0x6e616e
  410b5c:	jmp    411168 <__swc_fn_6b1cf01f_000146_e9d46966+0x1028>
  410b61:	vcomisd xmm0,xmm11
  410b66:	ja     410b77 <__swc_fn_6b1cf01f_000146_e9d46966+0xa37>
  410b68:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  410b71:	vcomisd xmm6,xmm0
  410b75:	jbe    410b9b <__swc_fn_6b1cf01f_000146_e9d46966+0xa5b>
  410b77:	vxorpd xmm1,xmm1,xmm1
  410b7b:	vcomisd xmm1,xmm0
  410b7f:	jbe    410b90 <__swc_fn_6b1cf01f_000146_e9d46966+0xa50>
  410b81:	mov    DWORD PTR [rcx],0x666e692d
  410b87:	mov    BYTE PTR [rcx+0x4],0x0
  410b8b:	jmp    411168 <__swc_fn_6b1cf01f_000146_e9d46966+0x1028>
  410b90:	mov    DWORD PTR [rcx],0x666e69
  410b96:	jmp    411168 <__swc_fn_6b1cf01f_000146_e9d46966+0x1028>
  410b9b:	vcomisd xmm0,xmm13
  410ba0:	jae    410bac <__swc_fn_6b1cf01f_000146_e9d46966+0xa6c>
  410ba2:	vcomisd xmm12,xmm0
  410ba6:	jbe    410f0e <__swc_fn_6b1cf01f_000146_e9d46966+0xdce>
  410bac:	vmovups xmm1,xmm0
  410bb0:	vxorpd xmm2,xmm2,xmm2
  410bb4:	vcomisd xmm2,xmm0
  410bb8:	jbe    410bc8 <__swc_fn_6b1cf01f_000146_e9d46966+0xa88>
  410bba:	vmovsd xmm0,xmm0,xmm1
  410bbe:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x298a]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  410bc6:	jmp    410bcc <__swc_fn_6b1cf01f_000146_e9d46966+0xa8c>
  410bc8:	vmovsd xmm0,xmm0,xmm1
  410bcc:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  410bd5:	xor    r8d,r8d
  410bd8:	vcomisd xmm0,xmm6
  410bdc:	jb     410bee <__swc_fn_6b1cf01f_000146_e9d46966+0xaae>
  410bde:	xchg   ax,ax
  410be0:	vdivsd xmm0,xmm0,xmm6
  410be4:	add    r8,0x1
  410be8:	vcomisd xmm0,xmm6
  410bec:	jae    410be0 <__swc_fn_6b1cf01f_000146_e9d46966+0xaa0>
  410bee:	mov    r9,rcx
  410bf1:	vxorpd xmm2,xmm2,xmm2
  410bf5:	vcomisd xmm2,xmm1
  410bf9:	jbe    410c02 <__swc_fn_6b1cf01f_000146_e9d46966+0xac2>
  410bfb:	mov    BYTE PTR [rcx],0x2d
  410bfe:	lea    r9,[rcx+0x1]
  410c02:	vcvttsd2si rdx,xmm0
  410c07:	mov    r10b,dl
  410c0a:	add    r10b,0x30
  410c0e:	mov    BYTE PTR [r9],r10b
  410c11:	vxorpd xmm1,xmm1,xmm1
  410c15:	movzx  edx,dl
  410c18:	vcvtsi2sd xmm1,xmm1,rdx
  410c1d:	vsubsd xmm0,xmm0,xmm1
  410c21:	vmulsd xmm0,xmm0,xmm6
  410c25:	mov    BYTE PTR [r9+0x1],0x2e
  410c2a:	vcvttsd2si rdx,xmm0
  410c2f:	mov    r10b,dl
  410c32:	add    r10b,0x30
  410c36:	mov    BYTE PTR [r9+0x2],r10b
  410c3a:	vxorpd xmm1,xmm1,xmm1
  410c3e:	movzx  edx,dl
  410c41:	vcvtsi2sd xmm1,xmm1,rdx
  410c46:	vsubsd xmm0,xmm0,xmm1
  410c4a:	vmulsd xmm0,xmm0,xmm6
  410c4e:	vcvttsd2si rdx,xmm0
  410c53:	mov    r10b,dl
  410c56:	add    r10b,0x30
  410c5a:	mov    BYTE PTR [r9+0x3],r10b
  410c5e:	vxorpd xmm1,xmm1,xmm1
  410c62:	movzx  edx,dl
  410c65:	vcvtsi2sd xmm1,xmm1,rdx
  410c6a:	vsubsd xmm0,xmm0,xmm1
  410c6e:	vmulsd xmm0,xmm0,xmm6
  410c72:	vcvttsd2si rdx,xmm0
  410c77:	mov    r10b,dl
  410c7a:	add    r10b,0x30
  410c7e:	mov    BYTE PTR [r9+0x4],r10b
  410c82:	vxorpd xmm1,xmm1,xmm1
  410c86:	movzx  edx,dl
  410c89:	vcvtsi2sd xmm1,xmm1,rdx
  410c8e:	vsubsd xmm0,xmm0,xmm1
  410c92:	vmulsd xmm0,xmm0,xmm6
  410c96:	vcvttsd2si rdx,xmm0
  410c9b:	mov    r10b,dl
  410c9e:	add    r10b,0x30
  410ca2:	mov    BYTE PTR [r9+0x5],r10b
  410ca6:	vxorpd xmm1,xmm1,xmm1
  410caa:	movzx  edx,dl
  410cad:	vcvtsi2sd xmm1,xmm1,rdx
  410cb2:	vsubsd xmm0,xmm0,xmm1
  410cb6:	vmulsd xmm0,xmm0,xmm6
  410cba:	vcvttsd2si rdx,xmm0
  410cbf:	mov    r10b,dl
  410cc2:	add    r10b,0x30
  410cc6:	mov    BYTE PTR [r9+0x6],r10b
  410cca:	vxorpd xmm1,xmm1,xmm1
  410cce:	movzx  edx,dl
  410cd1:	vcvtsi2sd xmm1,xmm1,rdx
  410cd6:	vsubsd xmm0,xmm0,xmm1
  410cda:	vmulsd xmm0,xmm0,xmm6
  410cde:	vcvttsd2si rdx,xmm0
  410ce3:	mov    r10b,dl
  410ce6:	add    r10b,0x30
  410cea:	mov    BYTE PTR [r9+0x7],r10b
  410cee:	vxorpd xmm1,xmm1,xmm1
  410cf2:	movzx  edx,dl
  410cf5:	vcvtsi2sd xmm1,xmm1,rdx
  410cfa:	vsubsd xmm0,xmm0,xmm1
  410cfe:	vmulsd xmm0,xmm0,xmm6
  410d02:	vcvttsd2si rdx,xmm0
  410d07:	mov    r10b,dl
  410d0a:	add    r10b,0x30
  410d0e:	mov    BYTE PTR [r9+0x8],r10b
  410d12:	vxorpd xmm1,xmm1,xmm1
  410d16:	movzx  edx,dl
  410d19:	vcvtsi2sd xmm1,xmm1,rdx
  410d1e:	vsubsd xmm0,xmm0,xmm1
  410d22:	vmulsd xmm0,xmm0,xmm6
  410d26:	vcvttsd2si rdx,xmm0
  410d2b:	mov    r10b,dl
  410d2e:	add    r10b,0x30
  410d32:	mov    BYTE PTR [r9+0x9],r10b
  410d36:	vxorpd xmm1,xmm1,xmm1
  410d3a:	movzx  edx,dl
  410d3d:	vcvtsi2sd xmm1,xmm1,rdx
  410d42:	vsubsd xmm0,xmm0,xmm1
  410d46:	vmulsd xmm0,xmm0,xmm6
  410d4a:	vcvttsd2si rdx,xmm0
  410d4f:	mov    r10b,dl
  410d52:	add    r10b,0x30
  410d56:	mov    BYTE PTR [r9+0xa],r10b
  410d5a:	vxorpd xmm1,xmm1,xmm1
  410d5e:	movzx  edx,dl
  410d61:	vcvtsi2sd xmm1,xmm1,rdx
  410d66:	vsubsd xmm0,xmm0,xmm1
  410d6a:	vmulsd xmm0,xmm0,xmm6
  410d6e:	vcvttsd2si rdx,xmm0
  410d73:	mov    r10b,dl
  410d76:	add    r10b,0x30
  410d7a:	mov    BYTE PTR [r9+0xb],r10b
  410d7e:	lea    r10,[r9+0x4]
  410d82:	vxorpd xmm1,xmm1,xmm1
  410d86:	movzx  edx,dl
  410d89:	vcvtsi2sd xmm1,xmm1,rdx
  410d8e:	vsubsd xmm0,xmm0,xmm1
  410d92:	vmulsd xmm0,xmm0,xmm6
  410d96:	vcvttsd2si rdx,xmm0
  410d9b:	mov    r11b,dl
  410d9e:	add    r11b,0x30
  410da2:	mov    BYTE PTR [r9+0xc],r11b
  410da6:	vxorpd xmm1,xmm1,xmm1
  410daa:	movzx  edx,dl
  410dad:	vcvtsi2sd xmm1,xmm1,rdx
  410db2:	vsubsd xmm0,xmm0,xmm1
  410db6:	vmulsd xmm0,xmm0,xmm6
  410dba:	vcvttsd2si rdx,xmm0
  410dbf:	mov    r11b,dl
  410dc2:	add    r11b,0x30
  410dc6:	mov    BYTE PTR [r9+0xd],r11b
  410dca:	lea    r10,[r10+0x2]
  410dce:	vxorpd xmm1,xmm1,xmm1
  410dd2:	movzx  edx,dl
  410dd5:	vcvtsi2sd xmm1,xmm1,rdx
  410dda:	vsubsd xmm0,xmm0,xmm1
  410dde:	vmulsd xmm0,xmm0,xmm6
  410de2:	vcvttsd2si rdx,xmm0
  410de7:	mov    r11b,dl
  410dea:	add    r11b,0x30
  410dee:	mov    BYTE PTR [r9+0xe],r11b
  410df2:	vxorpd xmm1,xmm1,xmm1
  410df6:	movzx  edx,dl
  410df9:	vcvtsi2sd xmm1,xmm1,rdx
  410dfe:	vsubsd xmm0,xmm0,xmm1
  410e02:	vmulsd xmm0,xmm0,xmm6
  410e06:	vcvttsd2si rdx,xmm0
  410e0b:	mov    r11b,dl
  410e0e:	add    r11b,0x30
  410e12:	mov    BYTE PTR [r9+0xf],r11b
  410e16:	lea    r10,[r10+0x2]
  410e1a:	lea    r10,[r10+0x2]
  410e1e:	lea    r10,[r10+0x2]
  410e22:	lea    r10,[r10+0x2]
  410e26:	lea    r10,[r10+0x2]
  410e2a:	vxorpd xmm1,xmm1,xmm1
  410e2e:	movzx  edx,dl
  410e31:	vcvtsi2sd xmm1,xmm1,rdx
  410e36:	vsubsd xmm0,xmm0,xmm1
  410e3a:	vmulsd xmm0,xmm0,xmm6
  410e3e:	vcvttsd2si rdx,xmm0
  410e43:	mov    r11b,dl
  410e46:	add    r11b,0x30
  410e4a:	mov    BYTE PTR [r9+0x10],r11b
  410e4e:	vxorpd xmm1,xmm1,xmm1
  410e52:	movzx  edx,dl
  410e55:	vcvtsi2sd xmm1,xmm1,rdx
  410e5a:	vsubsd xmm0,xmm0,xmm1
  410e5e:	vmulsd xmm0,xmm0,xmm6
  410e62:	vcvttsd2si rdx,xmm0
  410e67:	add    dl,0x30
  410e6a:	mov    BYTE PTR [r9+0x11],dl
  410e6e:	mov    BYTE PTR [r10+0x2],0x65
  410e73:	lea    r9,[r10+0x3]
  410e77:	test   r8,r8
  410e7a:	jl     410e83 <__swc_fn_6b1cf01f_000146_e9d46966+0xd43>
  410e7c:	mov    BYTE PTR [r9],0x2b
  410e80:	inc    r9
  410e83:	mov    r10,r9
  410e86:	mov    rdx,r8
  410e89:	nop    DWORD PTR [rax+0x0]
  410e90:	mov    r11,rdx
  410e93:	movabs rdx,0x6666666666666667
  410e9d:	mov    rax,r11
  410ea0:	imul   rdx
  410ea3:	sar    rdx,0x2
  410ea7:	mov    r12,rdx
  410eaa:	shr    rdx,0x3f
  410eae:	add    r12,rdx
  410eb1:	mov    rdx,r12
  410eb4:	imul   r13,r12,0xa
  410eb8:	sub    r11,r13
  410ebb:	mov    r13,QWORD PTR [rip+0x267e]        # 413540 <__swc_rdata_base_6b1cf01f+0x430>
  410ec2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410ec7:	mov    BYTE PTR [r10],r11b
  410eca:	lea    r11,[r10+0x1]
  410ece:	mov    r10,r11
  410ed1:	test   r12,r12
  410ed4:	jne    410e90 <__swc_fn_6b1cf01f_000146_e9d46966+0xd50>
  410ed6:	test   r8,r8
  410ed9:	jge    410ee3 <__swc_fn_6b1cf01f_000146_e9d46966+0xda3>
  410edb:	mov    BYTE PTR [r11],0x2d
  410edf:	lea    r10,[r11+0x1]
  410ee3:	mov    BYTE PTR [r10],0x0
  410ee7:	sub    r10,0x1
  410eeb:	nop    DWORD PTR [rax+rax*1+0x0]
  410ef0:	cmp    r9,r10
  410ef3:	jae    411168 <__swc_fn_6b1cf01f_000146_e9d46966+0x1028>
  410ef9:	mov    al,BYTE PTR [r10]
  410efc:	mov    dl,BYTE PTR [r9]
  410eff:	mov    BYTE PTR [r10],dl
  410f02:	sub    r10,0x1
  410f06:	mov    BYTE PTR [r9],al
  410f09:	inc    r9
  410f0c:	jmp    410ef0 <__swc_fn_6b1cf01f_000146_e9d46966+0xdb0>
  410f0e:	vcvttsd2si rdx,xmm0
  410f13:	mov    r8,rdx
  410f16:	vxorpd xmm1,xmm1,xmm1
  410f1a:	vcvtsi2sd xmm1,xmm1,rdx
  410f1f:	vsubsd xmm1,xmm0,xmm1
  410f23:	mov    r9d,0x8
  410f29:	vxorpd xmm2,xmm2,xmm2
  410f2d:	vcomisd xmm2,xmm1
  410f31:	ja     410f3e <__swc_fn_6b1cf01f_000146_e9d46966+0xdfe>
  410f33:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  410f3c:	jmp    410f4f <__swc_fn_6b1cf01f_000146_e9d46966+0xe0f>
  410f3e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x260a]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  410f46:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  410f4f:	test   r9d,r9d
  410f52:	je     410f69 <__swc_fn_6b1cf01f_000146_e9d46966+0xe29>
  410f54:	cs nop WORD PTR [rax+rax*1+0x0]
  410f5e:	xchg   ax,ax
  410f60:	vmulsd xmm1,xmm1,xmm6
  410f64:	dec    r9d
  410f67:	jne    410f60 <__swc_fn_6b1cf01f_000146_e9d46966+0xe20>
  410f69:	vcvttsd2si r9,xmm1
  410f6e:	mov    r10,r9
  410f71:	vxorpd xmm2,xmm2,xmm2
  410f75:	vcvtsi2sd xmm2,xmm2,r9
  410f7a:	vsubsd xmm1,xmm1,xmm2
  410f7e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  410f87:	vcomisd xmm1,xmm6
  410f8b:	lea    r9,[r9+0x1]
  410f8f:	cmova  r10,r9
  410f93:	cmp    r10,0x5f5e100
  410f9a:	jne    410fb3 <__swc_fn_6b1cf01f_000146_e9d46966+0xe73>
  410f9c:	lea    r8,[rdx-0x1]
  410fa0:	vxorpd xmm1,xmm1,xmm1
  410fa4:	vcomisd xmm1,xmm0
  410fa8:	lea    rdx,[rdx+0x1]
  410fac:	cmovbe r8,rdx
  410fb0:	xor    r10d,r10d
  410fb3:	mov    r9,rcx
  410fb6:	test   r8,r8
  410fb9:	jne    410fd9 <__swc_fn_6b1cf01f_000146_e9d46966+0xe99>
  410fbb:	vxorpd xmm1,xmm1,xmm1
  410fbf:	vcomisd xmm1,xmm0
  410fc3:	jbe    410fcc <__swc_fn_6b1cf01f_000146_e9d46966+0xe8c>
  410fc5:	mov    BYTE PTR [rcx],0x2d
  410fc8:	lea    r9,[rcx+0x1]
  410fcc:	mov    BYTE PTR [r9],0x30
  410fd0:	add    r9,0x1
  410fd4:	jmp    41106b <__swc_fn_6b1cf01f_000146_e9d46966+0xf2b>
  410fd9:	mov    r9,rcx
  410fdc:	mov    rdx,r8
  410fdf:	nop
  410fe0:	mov    r11,rdx
  410fe3:	movabs rdx,0x6666666666666667
  410fed:	mov    r15,rax
  410ff0:	mov    rax,r11
  410ff3:	imul   rdx
  410ff6:	mov    r12,rdx
  410ff9:	mov    rax,r15
  410ffc:	sar    r12,0x2
  411000:	mov    rdx,r12
  411003:	shr    rdx,0x3f
  411007:	add    r12,rdx
  41100a:	mov    rdx,r12
  41100d:	imul   r13,r12,0xa
  411011:	sub    r11,r13
  411014:	mov    r13,QWORD PTR [rip+0x2525]        # 413540 <__swc_rdata_base_6b1cf01f+0x430>
  41101b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411020:	mov    BYTE PTR [r9],r11b
  411023:	lea    r11,[r9+0x1]
  411027:	mov    r9,r11
  41102a:	test   r12,r12
  41102d:	jne    410fe0 <__swc_fn_6b1cf01f_000146_e9d46966+0xea0>
  41102f:	test   r8,r8
  411032:	jge    41103c <__swc_fn_6b1cf01f_000146_e9d46966+0xefc>
  411034:	mov    BYTE PTR [r11],0x2d
  411038:	lea    r9,[r11+0x1]
  41103c:	mov    rdx,r9
  41103f:	mov    BYTE PTR [r9],0x0
  411043:	sub    r9,0x1
  411047:	mov    r8,rcx
  41104a:	cmp    r8,r9
  41104d:	jae    411068 <__swc_fn_6b1cf01f_000146_e9d46966+0xf28>
  41104f:	nop
  411050:	mov    r11b,BYTE PTR [r9]
  411053:	mov    r12b,BYTE PTR [r8]
  411056:	mov    BYTE PTR [r9],r12b
  411059:	sub    r9,0x1
  41105d:	mov    BYTE PTR [r8],r11b
  411060:	inc    r8
  411063:	cmp    r8,r9
  411066:	jb     411050 <__swc_fn_6b1cf01f_000146_e9d46966+0xf10>
  411068:	mov    r9,rdx
  41106b:	mov    BYTE PTR [r9],0x2e
  41106f:	add    r9,0x1
  411073:	xor    r8d,r8d
  411076:	test   r10,r10
  411079:	je     4110bf <__swc_fn_6b1cf01f_000146_e9d46966+0xf7f>
  41107b:	mov    r11d,0x989680
  411081:	cmp    r10,r11
  411084:	jge    4110bf <__swc_fn_6b1cf01f_000146_e9d46966+0xf7f>
  411086:	cs nop WORD PTR [rax+rax*1+0x0]
  411090:	inc    r8d
  411093:	movabs rdx,0x6666666666666667
  41109d:	mov    r15,rax
  4110a0:	mov    rax,r11
  4110a3:	imul   rdx
  4110a6:	mov    r11,rdx
  4110a9:	mov    rax,r15
  4110ac:	sar    r11,0x2
  4110b0:	mov    rdx,r11
  4110b3:	shr    rdx,0x3f
  4110b7:	add    r11,rdx
  4110ba:	cmp    r10,r11
  4110bd:	jl     411090 <__swc_fn_6b1cf01f_000146_e9d46966+0xf50>
  4110bf:	test   r8d,r8d
  4110c2:	je     4110dd <__swc_fn_6b1cf01f_000146_e9d46966+0xf9d>
  4110c4:	cs nop WORD PTR [rax+rax*1+0x0]
  4110ce:	xchg   ax,ax
  4110d0:	mov    BYTE PTR [r9],0x30
  4110d4:	add    r9,0x1
  4110d8:	dec    r8d
  4110db:	jne    4110d0 <__swc_fn_6b1cf01f_000146_e9d46966+0xf90>
  4110dd:	mov    r8,r9
  4110e0:	mov    rdx,r10
  4110e3:	cs nop WORD PTR [rax+rax*1+0x0]
  4110ed:	nop    DWORD PTR [rax]
  4110f0:	mov    r11,rdx
  4110f3:	movabs rdx,0x6666666666666667
  4110fd:	mov    rax,r11
  411100:	imul   rdx
  411103:	sar    rdx,0x2
  411107:	mov    r12,rdx
  41110a:	shr    rdx,0x3f
  41110e:	add    r12,rdx
  411111:	mov    rdx,r12
  411114:	imul   r13,r12,0xa
  411118:	sub    r11,r13
  41111b:	mov    r13,QWORD PTR [rip+0x241e]        # 413540 <__swc_rdata_base_6b1cf01f+0x430>
  411122:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411127:	mov    BYTE PTR [r8],r11b
  41112a:	lea    r11,[r8+0x1]
  41112e:	mov    r8,r11
  411131:	test   r12,r12
  411134:	jne    4110f0 <__swc_fn_6b1cf01f_000146_e9d46966+0xfb0>
  411136:	test   r10,r10
  411139:	jge    411143 <__swc_fn_6b1cf01f_000146_e9d46966+0x1003>
  41113b:	mov    BYTE PTR [r11],0x2d
  41113f:	lea    r8,[r11+0x1]
  411143:	mov    BYTE PTR [r8],0x0
  411147:	sub    r8,0x1
  41114b:	cmp    r9,r8
  41114e:	jae    411168 <__swc_fn_6b1cf01f_000146_e9d46966+0x1028>
  411150:	mov    al,BYTE PTR [r8]
  411153:	mov    dl,BYTE PTR [r9]
  411156:	mov    BYTE PTR [r8],dl
  411159:	sub    r8,0x1
  41115d:	mov    BYTE PTR [r9],al
  411160:	inc    r9
  411163:	cmp    r9,r8
  411166:	jb     411150 <__swc_fn_6b1cf01f_000146_e9d46966+0x1010>
  411168:	xor    eax,eax
  41116a:	test   rcx,rcx
  41116d:	je     411190 <__swc_fn_6b1cf01f_000146_e9d46966+0x1050>
  41116f:	mov    rdx,rcx
  411172:	mov    r8b,BYTE PTR [rdx]
  411175:	test   r8b,r8b
  411178:	je     411190 <__swc_fn_6b1cf01f_000146_e9d46966+0x1050>
  41117a:	nop    WORD PTR [rax+rax*1+0x0]
  411180:	add    rdx,0x1
  411184:	add    rax,0x1
  411188:	mov    r8b,BYTE PTR [rdx]
  41118b:	test   r8b,r8b
  41118e:	jne    411180 <__swc_fn_6b1cf01f_000146_e9d46966+0x1040>
  411190:	mov    QWORD PTR [rsp+0x3f8],rcx
  411198:	mov    QWORD PTR [rsp+0x400],rax
  4111a0:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  4111a9:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  4111b2:	lea    rcx,[rsp+0x408]
  4111ba:	call   40f8d0 <__swc_fn_6b1cf01f_000116_3499f7d6>
  4111bf:	jmp    411205 <__swc_fn_6b1cf01f_000146_e9d46966+0x10c5>
  4111c1:	mov    rcx,rdx
  4111c4:	call   40f8d0 <__swc_fn_6b1cf01f_000116_3499f7d6>
  4111c9:	jmp    411205 <__swc_fn_6b1cf01f_000146_e9d46966+0x10c5>
  4111cb:	mov    al,BYTE PTR [rdx]
  4111cd:	test   al,al
  4111cf:	je     4111da <__swc_fn_6b1cf01f_000146_e9d46966+0x109a>
  4111d1:	lea    rax,[rip+0x2388]        # 413560 <__swc_rdata_base_6b1cf01f+0x450>
  4111d8:	jmp    4111e1 <__swc_fn_6b1cf01f_000146_e9d46966+0x10a1>
  4111da:	lea    rax,[rip+0x238f]        # 413570 <__swc_rdata_base_6b1cf01f+0x460>
  4111e1:	mov    rcx,rax
  4111e4:	call   40f8d0 <__swc_fn_6b1cf01f_000116_3499f7d6>
  4111e9:	jmp    411205 <__swc_fn_6b1cf01f_000146_e9d46966+0x10c5>
  4111eb:	lea    rcx,[rip+0x238e]        # 413580 <__swc_rdata_base_6b1cf01f+0x470>
  4111f2:	call   40f8d0 <__swc_fn_6b1cf01f_000116_3499f7d6>
  4111f7:	jmp    411205 <__swc_fn_6b1cf01f_000146_e9d46966+0x10c5>
  4111f9:	lea    rcx,[rip+0x2380]        # 413580 <__swc_rdata_base_6b1cf01f+0x470>
  411200:	call   40f8d0 <__swc_fn_6b1cf01f_000116_3499f7d6>
  411205:	add    rdi,0x1
  411209:	sub    rsi,0x1
  41120d:	vmovups xmm0,xmm12
  411212:	vmovsd xmm6,QWORD PTR [rip+0x2376]        # 413590 <__swc_rdata_base_6b1cf01f+0x480>
  41121a:	test   rsi,rsi
  41121d:	jne    410250 <__swc_fn_6b1cf01f_000146_e9d46966+0x110>
  411223:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  41122c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  411235:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  41123e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411247:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411250:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411259:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411262:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  41126b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411274:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  41127d:	add    rsp,0x4e8
  411284:	pop    r15
  411286:	pop    r13
  411288:	pop    r12
  41128a:	pop    rdi
  41128b:	pop    rsi
  41128c:	pop    rbx
  41128d:	ret
	...

0000000000411290 <__swc_fn_6b1cf01f_000149_33e5e24f>:
  411290:	vxorps xmm0,xmm0,xmm0
  411294:	vmovups XMMWORD PTR [rcx],xmm0
  411298:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41129d:	ret
	...

00000000004112a0 <__swc_fn_6b1cf01f_000152_33e5e24f>:
  4112a0:	vxorps xmm0,xmm0,xmm0
  4112a4:	vmovups XMMWORD PTR [rcx],xmm0
  4112a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4112ad:	vxorps xmm0,xmm0,xmm0
  4112b1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4112b6:	vmovups xmm0,XMMWORD PTR [rip+0x23e2]        # 4136a0 <__swc_rdata_base_6b1cf01f+0x590>
  4112be:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4112c3:	vxorps xmm0,xmm0,xmm0
  4112c7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  4112cc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  4112d1:	vxorps xmm0,xmm0,xmm0
  4112d5:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  4112da:	mov    QWORD PTR [rcx+0x70],0x0
  4112e2:	ret
	...

00000000004112f0 <__swc_fn_6b1cf01f_000155_33e5e24f>:
  4112f0:	vxorps xmm0,xmm0,xmm0
  4112f4:	vmovups XMMWORD PTR [rcx],xmm0
  4112f8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4112fd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411302:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411307:	ret
	...

0000000000411310 <__swc_fn_6b1cf01f_000158_6741c23b>:
  411310:	push   rsi
  411311:	push   rdi
  411312:	sub    rsp,0x8
  411316:	mov    rsi,rcx
  411319:	mov    rdi,QWORD PTR [rsi+0x50]
  41131d:	test   rdi,rdi
  411320:	je     411327 <__swc_fn_6b1cf01f_000158_6741c23b+0x17>
  411322:	mov    rcx,rsi
  411325:	call   rdi
  411327:	mov    QWORD PTR [rsi+0x20],0x0
  41132f:	mov    rax,QWORD PTR [rsi+0x30]
  411333:	test   rax,rax
  411336:	je     411364 <__swc_fn_6b1cf01f_000158_6741c23b+0x54>
  411338:	nop    DWORD PTR [rax+rax*1+0x0]
  411340:	mov    rdi,QWORD PTR [rax+0x8]
  411344:	mov    rcx,rsi
  411347:	mov    rdx,QWORD PTR [rax+0x10]
  41134b:	mov    rax,QWORD PTR [rax+0x18]
  41134f:	mov    r8,rax
  411352:	call   409e90 <__swc_fn_6b1cf01f_000156_312df05a>
  411357:	mov    QWORD PTR [rsi+0x30],rdi
  41135b:	mov    rax,QWORD PTR [rsi+0x30]
  41135f:	test   rax,rax
  411362:	jne    411340 <__swc_fn_6b1cf01f_000158_6741c23b+0x30>
  411364:	mov    QWORD PTR [rsi+0x38],0x0
  41136c:	add    rsp,0x8
  411370:	pop    rdi
  411371:	pop    rsi
  411372:	ret
	...

0000000000411380 <__swc_fn_6b1cf01f_000161_9e36e814>:
  411380:	push   rbx
  411381:	push   rsi
  411382:	push   rdi
  411383:	push   r12
  411385:	sub    rsp,0x188
  41138c:	mov    rbx,rcx
  41138f:	lea    rsi,[rip+0x159fa]        # 426d90 <__swc_bss_base_6b1cf01f+0x2d50>
  411396:	mov    rcx,rsi
  411399:	call   4098a0 <__swc_fn_6b1cf01f_000135_1fec60ac>
  41139e:	mov    rax,QWORD PTR [rip+0x159f3]        # 426d98 <__swc_bss_base_6b1cf01f+0x2d58>
  4113a5:	mov    rdi,rax
  4113a8:	test   rdi,rdi
  4113ab:	je     4113d9 <__swc_fn_6b1cf01f_000161_9e36e814+0x59>
  4113ad:	nop    DWORD PTR [rax]
  4113b0:	cmp    QWORD PTR [rdi+0x8],rbx
  4113b4:	jne    4113ce <__swc_fn_6b1cf01f_000161_9e36e814+0x4e>
  4113b6:	mov    rcx,rsi
  4113b9:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  4113be:	mov    rax,rdi
  4113c1:	add    rsp,0x188
  4113c8:	pop    r12
  4113ca:	pop    rdi
  4113cb:	pop    rsi
  4113cc:	pop    rbx
  4113cd:	ret
  4113ce:	mov    rax,QWORD PTR [rdi]
  4113d1:	mov    rdi,rax
  4113d4:	test   rax,rax
  4113d7:	jne    4113b0 <__swc_fn_6b1cf01f_000161_9e36e814+0x30>
  4113d9:	call   40cda0 <__swc_fn_6b1cf01f_000139_20e2e2c7>
  4113de:	mov    rdi,rax
  4113e1:	test   rax,rax
  4113e4:	jne    4113fd <__swc_fn_6b1cf01f_000161_9e36e814+0x7d>
  4113e6:	mov    rcx,rsi
  4113e9:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  4113ee:	xor    eax,eax
  4113f0:	add    rsp,0x188
  4113f7:	pop    r12
  4113f9:	pop    rdi
  4113fa:	pop    rsi
  4113fb:	pop    rbx
  4113fc:	ret
  4113fd:	lea    rax,[rsp+0x18]
  411402:	mov    QWORD PTR [rax+0x10],0x0
  41140a:	mov    QWORD PTR [rax+0x18],0x0
  411412:	mov    DWORD PTR [rax+0x20],0x0
  411419:	mov    BYTE PTR [rax+0x24],0x0
  41141d:	mov    rax,QWORD PTR [rip+0x15974]        # 426d98 <__swc_bss_base_6b1cf01f+0x2d58>
  411424:	mov    QWORD PTR [rsp+0x18],rax
  411429:	mov    QWORD PTR [rsp+0x20],rbx
  41142e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411434:	vmovups XMMWORD PTR [rdi],xmm0
  411438:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  41143e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  411443:	mov    rax,QWORD PTR [rsp+0x38]
  411448:	mov    QWORD PTR [rdi+0x20],rax
  41144c:	mov    QWORD PTR [rip+0x15945],rdi        # 426d98 <__swc_bss_base_6b1cf01f+0x2d58>
  411453:	lea    rax,[rsp+0x40]
  411458:	mov    QWORD PTR [rax],0x0
  41145f:	mov    rcx,rbx
  411462:	mov    rdx,rax
  411465:	call   409980 <__swc_fn_6b1cf01f_000141_376d5f6d>
  41146a:	mov    rbx,rax
  41146d:	test   rax,rax
  411470:	jne    41148a <__swc_fn_6b1cf01f_000161_9e36e814+0x10a>
  411472:	mov    rcx,rsi
  411475:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  41147a:	mov    rax,rdi
  41147d:	add    rsp,0x188
  411484:	pop    r12
  411486:	pop    rdi
  411487:	pop    rsi
  411488:	pop    rbx
  411489:	ret
  41148a:	lea    r12,[rsp+0x50]
  41148f:	mov    QWORD PTR [r12],0x0
  411497:	mov    rcx,rbx
  41149a:	mov    rdx,QWORD PTR [rsp+0x40]
  41149f:	mov    r8,r12
  4114a2:	call   40ce50 <__swc_fn_6b1cf01f_000142_e0543f36>
  4114a7:	test   rax,rax
  4114aa:	jne    4114c4 <__swc_fn_6b1cf01f_000161_9e36e814+0x144>
  4114ac:	mov    rcx,rsi
  4114af:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  4114b4:	mov    rax,rdi
  4114b7:	add    rsp,0x188
  4114be:	pop    r12
  4114c0:	pop    rdi
  4114c1:	pop    rsi
  4114c2:	pop    rbx
  4114c3:	ret
  4114c4:	cmp    QWORD PTR [r12],0x10
  4114c9:	jb     4115cc <__swc_fn_6b1cf01f_000161_9e36e814+0x24c>
  4114cf:	mov    ecx,DWORD PTR [rax]
  4114d1:	cmp    ecx,0x42445753
  4114d7:	jne    4115cc <__swc_fn_6b1cf01f_000161_9e36e814+0x24c>
  4114dd:	mov    ecx,DWORD PTR [rax+0x4]
  4114e0:	cmp    ecx,0x1
  4114e3:	jne    4115cc <__swc_fn_6b1cf01f_000161_9e36e814+0x24c>
  4114e9:	mov    ecx,DWORD PTR [rax+0x8]
  4114ec:	mov    edx,DWORD PTR [rax+0xc]
  4114ef:	imul   r8,rcx,0x14
  4114f3:	mov    r9,QWORD PTR [rsp+0x50]
  4114f8:	sub    r9,0x10
  4114fc:	cmp    r8,r9
  4114ff:	ja     4115cc <__swc_fn_6b1cf01f_000161_9e36e814+0x24c>
  411505:	lea    r8,[r8+0x10]
  411509:	cmp    rdx,r8
  41150c:	jb     4115cc <__swc_fn_6b1cf01f_000161_9e36e814+0x24c>
  411512:	mov    r8,QWORD PTR [rsp+0x50]
  411517:	cmp    rdx,r8
  41151a:	ja     4115cc <__swc_fn_6b1cf01f_000161_9e36e814+0x24c>
  411520:	xor    r8d,r8d
  411523:	test   rcx,rcx
  411526:	jbe    4115f2 <__swc_fn_6b1cf01f_000161_9e36e814+0x272>
  41152c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  411532:	cs nop WORD PTR [rax+rax*1+0x0]
  41153c:	nop    DWORD PTR [rax+0x0]
  411540:	imul   r9,r8,0x14
  411544:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  411549:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  41154e:	add    r10,r11
  411551:	movabs r11,0x100000000
  41155b:	cmp    r10,r11
  41155e:	ja     4115cc <__swc_fn_6b1cf01f_000161_9e36e814+0x24c>
  411560:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  411565:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  41156a:	test   r10d,r10d
  41156d:	setne  r11b
  411571:	je     41158b <__swc_fn_6b1cf01f_000161_9e36e814+0x20b>
  411573:	cmp    r10d,edx
  411576:	setb   r11b
  41157a:	jb     41158b <__swc_fn_6b1cf01f_000161_9e36e814+0x20b>
  41157c:	vmovq  r11,xmm1
  411581:	cmp    r10,r11
  411584:	setae  r10b
  411588:	mov    r11b,r10b
  41158b:	mov    r10,r11
  41158e:	test   r11b,r11b
  411591:	jne    4115b8 <__swc_fn_6b1cf01f_000161_9e36e814+0x238>
  411593:	test   r9d,r9d
  411596:	setne  r10b
  41159a:	je     4115b8 <__swc_fn_6b1cf01f_000161_9e36e814+0x238>
  41159c:	cmp    r9d,edx
  41159f:	setb   r10b
  4115a3:	jb     4115b8 <__swc_fn_6b1cf01f_000161_9e36e814+0x238>
  4115a5:	vmovq  r10,xmm1
  4115aa:	cmp    r9,r10
  4115ad:	setae  r9b
  4115b1:	movzx  r9d,r9b
  4115b5:	mov    r10b,r9b
  4115b8:	test   r10b,r10b
  4115bb:	jne    4115cc <__swc_fn_6b1cf01f_000161_9e36e814+0x24c>
  4115bd:	add    r8,0x1
  4115c1:	cmp    r8,rcx
  4115c4:	jb     411540 <__swc_fn_6b1cf01f_000161_9e36e814+0x1c0>
  4115ca:	jmp    4115f2 <__swc_fn_6b1cf01f_000161_9e36e814+0x272>
  4115cc:	xor    ecx,ecx
  4115ce:	cmp    rax,rbx
  4115d1:	cmovne rcx,rax
  4115d5:	call   410090 <__swc_fn_6b1cf01f_000143_afffe963>
  4115da:	mov    rcx,rsi
  4115dd:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  4115e2:	mov    rax,rdi
  4115e5:	add    rsp,0x188
  4115ec:	pop    r12
  4115ee:	pop    rdi
  4115ef:	pop    rsi
  4115f0:	pop    rbx
  4115f1:	ret
  4115f2:	mov    QWORD PTR [rdi+0x10],rax
  4115f6:	mov    rcx,QWORD PTR [rsp+0x50]
  4115fb:	mov    QWORD PTR [rdi+0x18],rcx
  4115ff:	mov    eax,DWORD PTR [rax+0x8]
  411602:	mov    DWORD PTR [rdi+0x20],eax
  411605:	rex mov BYTE PTR [rdi+0x24],0x1
  41160a:	mov    rcx,rsi
  41160d:	call   40cd90 <__swc_fn_6b1cf01f_000136_5589b4a1>
  411612:	mov    rax,rdi
  411615:	add    rsp,0x188
  41161c:	pop    r12
  41161e:	pop    rdi
  41161f:	pop    rsi
  411620:	pop    rbx
  411621:	ret
	...

0000000000411630 <__swc_fn_6b1cf01f_000164_15b66a30>:
  411630:	push   rsi
  411631:	push   rdi
  411632:	push   r12
  411634:	mov    rsi,rdx
  411637:	mov    rdi,rcx
  41163a:	mov    rcx,QWORD PTR [rip+0x156ff]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  411641:	test   rcx,rcx
  411644:	jne    411656 <__swc_fn_6b1cf01f_000164_15b66a30+0x26>
  411646:	call   40a1a0 <__swc_fn_6b1cf01f_000165_e09accff>
  41164b:	lea    rcx,[rax+0x1]
  41164f:	mov    QWORD PTR [rip+0x156ea],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  411656:	dec    rcx
  411659:	call   411680 <__swc_fn_6b1cf01f_000167_3130645d>
  41165e:	mov    r12,QWORD PTR [rax+0xbe0]
  411665:	test   r12,r12
  411668:	setne  al
  41166b:	je     411676 <__swc_fn_6b1cf01f_000164_15b66a30+0x46>
  41166d:	mov    rcx,rdi
  411670:	mov    rdx,rsi
  411673:	call   r12
  411676:	pop    r12
  411678:	pop    rdi
  411679:	pop    rsi
  41167a:	ret
  41167b:	add    BYTE PTR [rax],al
  41167d:	add    BYTE PTR [rax],al
	...

0000000000411680 <__swc_fn_6b1cf01f_000167_3130645d>:
  411680:	push   r12
  411682:	push   rdi
  411683:	push   rsi
  411684:	sub    rsp,0xd0
  41168b:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  411691:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  411697:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  41169d:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4116a3:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4116a9:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4116af:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  4116b8:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  4116c1:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  4116ca:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  4116d3:	mov    r12,rcx
  4116d6:	mov    edi,ecx
  4116d8:	xor    eax,eax
  4116da:	call   407000 <pthread_getspecific@plt>
  4116df:	test   rax,rax
  4116e2:	je     4116e6 <__swc_fn_6b1cf01f_000167_3130645d+0x66>
  4116e4:	jmp    4116ee <__swc_fn_6b1cf01f_000167_3130645d+0x6e>
  4116e6:	mov    rcx,r12
  4116e9:	call   40a200 <__swc_fn_6b1cf01f_000168_0ff0458f>
  4116ee:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  4116f4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  4116fa:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  411700:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  411706:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  41170c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  411712:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  41171b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  411724:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  41172d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  411736:	add    rsp,0xd0
  41173d:	pop    rsi
  41173e:	pop    rdi
  41173f:	pop    r12
  411741:	ret
	...

0000000000411750 <__swc_fn_6b1cf01f_000170_8b7c1b80>:
  411750:	push   rsi
  411751:	sub    rsp,0x30
  411755:	lea    rsi,[rip+0x1564c]        # 426da8 <__swc_bss_base_6b1cf01f+0x2d68>
  41175c:	mov    rax,QWORD PTR [rsi]
  41175f:	test   rax,rax
  411762:	je     41176a <__swc_fn_6b1cf01f_000170_8b7c1b80+0x1a>
  411764:	add    rsp,0x30
  411768:	pop    rsi
  411769:	ret
  41176a:	mov    ecx,0x3
  41176f:	mov    edx,0x10
  411774:	call   40f1f0 <__swc_fn_6b1cf01f_000107_ff529476>
  411779:	test   rax,rax
  41177c:	jne    41178d <__swc_fn_6b1cf01f_000170_8b7c1b80+0x3d>
  41177e:	mov    QWORD PTR [rsp+0x18],rax
  411783:	call   40c8f0 <__swc_fn_6b1cf01f_000118_2b35b5e0>
  411788:	mov    rax,QWORD PTR [rsp+0x18]
  41178d:	mov    rcx,rax
  411790:	xchg   QWORD PTR [rsi],rcx
  411793:	add    rsp,0x30
  411797:	pop    rsi
  411798:	ret
  411799:	add    BYTE PTR [rax],al
  41179b:	add    BYTE PTR [rax],al
  41179d:	add    BYTE PTR [rax],al
	...

00000000004117a0 <__swc_fn_6b1cf01f_000173_156cb9fe>:
  4117a0:	push   rsi
  4117a1:	push   rdi
  4117a2:	sub    rsp,0x8
  4117a6:	mov    rsi,rdx
  4117a9:	mov    rdi,rcx
  4117ac:	mov    rax,QWORD PTR [rsi+0x8]
  4117b0:	test   rax,rax
  4117b3:	je     4117bd <__swc_fn_6b1cf01f_000173_156cb9fe+0x1d>
  4117b5:	mov    rcx,QWORD PTR [rsi]
  4117b8:	mov    QWORD PTR [rax],rcx
  4117bb:	jmp    4117c4 <__swc_fn_6b1cf01f_000173_156cb9fe+0x24>
  4117bd:	mov    rax,QWORD PTR [rsi]
  4117c0:	mov    QWORD PTR [rdi+0x8],rax
  4117c4:	mov    rax,QWORD PTR [rsi]
  4117c7:	test   rax,rax
  4117ca:	je     4117d4 <__swc_fn_6b1cf01f_000173_156cb9fe+0x34>
  4117cc:	mov    rcx,QWORD PTR [rsi+0x8]
  4117d0:	mov    QWORD PTR [rax+0x8],rcx
  4117d4:	mov    rcx,rdi
  4117d7:	mov    rdx,QWORD PTR [rsi+0x10]
  4117db:	mov    r8,QWORD PTR [rsi+0x18]
  4117df:	mov    r9,0xffffffffffffffff
  4117e6:	call   40d4a0 <__swc_fn_6b1cf01f_000172_9a88b1d5>
  4117eb:	mov    QWORD PTR [rsi+0x18],0x0
  4117f3:	mov    rax,QWORD PTR [rdi+0x8]
  4117f7:	test   rax,rax
  4117fa:	jne    41180c <__swc_fn_6b1cf01f_000173_156cb9fe+0x6c>
  4117fc:	call   411750 <__swc_fn_6b1cf01f_000170_8b7c1b80>
  411801:	xor    ecx,ecx
  411803:	mov    QWORD PTR [rax+0x8],rcx
  411807:	xor    ecx,ecx
  411809:	mov    QWORD PTR [rax],rcx
  41180c:	add    rsp,0x8
  411810:	pop    rdi
  411811:	pop    rsi
  411812:	ret
	...

0000000000411820 <__swc_fn_6b1cf01f_000176_0ce64436>:
  411820:	push   rbp
  411821:	push   rbx
  411822:	push   rsi
  411823:	sub    rsp,0xa8
  41182a:	mov    rbp,rsp
  41182d:	vmovups XMMWORD PTR [rsp],xmm6
  411832:	vmovups XMMWORD PTR [rsp+0x10],xmm7
  411838:	vmovups XMMWORD PTR [rsp+0x20],xmm8
  41183e:	vmovups XMMWORD PTR [rsp+0x30],xmm9
  411844:	vmovups XMMWORD PTR [rsp+0x40],xmm10
  41184a:	vmovups XMMWORD PTR [rsp+0x50],xmm11
  411850:	vmovups XMMWORD PTR [rsp+0x60],xmm12
  411856:	vmovups XMMWORD PTR [rsp+0x70],xmm13
  41185c:	vmovups XMMWORD PTR [rsp+0x80],xmm14
  411865:	vmovups XMMWORD PTR [rsp+0x90],xmm15
  41186e:	sub    rsp,0x510
  411875:	mov    rbx,rsp
  411878:	lea    rax,[rip+0x2099]        # 413918 <__swc_rdata_base_6b1cf01f+0x808>
  41187f:	xor    ecx,ecx
  411881:	cs nop WORD PTR [rax+rax*1+0x0]
  41188b:	cs nop WORD PTR [rax+rax*1+0x0]
  411895:	cs nop WORD PTR [rax+rax*1+0x0]
  41189f:	nop
  4118a0:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  4118a5:	vmovdqu XMMWORD PTR [rbx+rcx*1],xmm0
  4118aa:	add    rcx,0x10
  4118ae:	cmp    rcx,0x110
  4118b5:	jne    4118a0 <__swc_fn_6b1cf01f_000176_0ce64436+0x80>
  4118b7:	mov    DWORD PTR [rbx+0x110],0x531799ac
  4118c1:	mov    DWORD PTR [rbx+0x114],0x3f60a8f3
  4118cb:	sub    rsp,0x8
  4118cf:	call   40d550 <__swc_fn_6b1cf01f_000175_1ca87929>
  4118d4:	add    rsp,0x8
  4118d8:	vmovsd QWORD PTR [rsp+0x2d0],xmm0
  4118e1:	vxorpd xmm0,xmm0,xmm0
  4118e5:	vmovups xmm2,xmm0
  4118e9:	mov    rax,rbx
  4118ec:	vmovsd xmm3,QWORD PTR [rbx+0x18]
  4118f1:	vmovsd xmm4,QWORD PTR [rbx+0x30]
  4118f6:	vmulsd xmm3,xmm3,xmm4
  4118fa:	vaddsd xmm1,xmm0,xmm3
  4118fe:	vmovsd xmm3,QWORD PTR [rbx+0x20]
  411903:	vfmadd231sd xmm2,xmm3,xmm4
  411908:	vmovsd xmm3,QWORD PTR [rbx+0x28]
  41190d:	vfmadd231sd xmm0,xmm3,xmm4
  411912:	add    rax,0x38
  411916:	vmovsd xmm3,QWORD PTR [rax+0x18]
  41191b:	vmovsd xmm4,QWORD PTR [rax+0x30]
  411920:	vfmadd231sd xmm1,xmm3,xmm4
  411925:	vmovsd xmm3,QWORD PTR [rax+0x20]
  41192a:	vfmadd231sd xmm2,xmm3,xmm4
  41192f:	vmovsd xmm3,QWORD PTR [rax+0x28]
  411934:	vfmadd231sd xmm0,xmm3,xmm4
  411939:	vmovsd xmm3,QWORD PTR [rax+0x50]
  41193e:	vmovsd xmm4,QWORD PTR [rax+0x68]
  411943:	vfmadd231sd xmm1,xmm3,xmm4
  411948:	vmovsd xmm3,QWORD PTR [rax+0x58]
  41194d:	vfmadd231sd xmm2,xmm3,xmm4
  411952:	vmovsd xmm3,QWORD PTR [rax+0x60]
  411957:	vfmadd231sd xmm0,xmm3,xmm4
  41195c:	vmovsd xmm3,QWORD PTR [rax+0x88]
  411964:	vmovsd xmm4,QWORD PTR [rax+0xa0]
  41196c:	vfmadd231sd xmm1,xmm3,xmm4
  411971:	vmovsd xmm3,QWORD PTR [rax+0x90]
  411979:	vfmadd231sd xmm2,xmm3,xmm4
  41197e:	vmovsd xmm3,QWORD PTR [rax+0x98]
  411986:	vfmadd231sd xmm0,xmm3,xmm4
  41198b:	vmovsd xmm3,QWORD PTR [rax+0xc0]
  411993:	vmovsd xmm4,QWORD PTR [rax+0xd8]
  41199b:	vfmadd231sd xmm1,xmm3,xmm4
  4119a0:	vmovsd xmm3,QWORD PTR [rax+0xc8]
  4119a8:	vfmadd231sd xmm2,xmm3,xmm4
  4119ad:	vmovsd xmm3,QWORD PTR [rax+0xd0]
  4119b5:	vfmadd231sd xmm0,xmm3,xmm4
  4119ba:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1b8e]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  4119c2:	vmovsd xmm3,QWORD PTR [rip+0x2116]        # 413ae0 <__swc_rdata_base_6b1cf01f+0x9d0>
  4119ca:	vdivsd xmm1,xmm1,xmm3
  4119ce:	vmovsd QWORD PTR [rbx+0x18],xmm1
  4119d3:	vxorpd xmm2,xmm2,XMMWORD PTR [rip+0x1b75]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  4119db:	vdivsd xmm1,xmm2,xmm3
  4119df:	vmovsd QWORD PTR [rbx+0x20],xmm1
  4119e4:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x1b64]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  4119ec:	vdivsd xmm0,xmm0,xmm3
  4119f0:	vmovsd QWORD PTR [rbx+0x28],xmm0
  4119f5:	xor    eax,eax
  4119f7:	vmovsd xmm0,QWORD PTR [rip+0x20ea]        # 413ae9 <__swc_rdata_base_6b1cf01f+0x9d9>
  4119ff:	vpshufd xmm1,xmm0,0x44
  411a04:	vmovups XMMWORD PTR [rsp+0x2e0],xmm1
  411a0d:	vpunpcklqdq xmm2,xmm0,xmm0
  411a11:	vmovups XMMWORD PTR [rsp+0x2f0],xmm2
  411a1a:	vmovdqu xmm3,XMMWORD PTR [rsp]
  411a1f:	vmovdqu xmm4,XMMWORD PTR [rsp+0x18]
  411a25:	vmovdqu xmm5,XMMWORD PTR [rsp+0x38]
  411a2b:	vmovups XMMWORD PTR [rsp+0x320],xmm5
  411a34:	vmovdqu xmm7,XMMWORD PTR [rsp+0x50]
  411a3a:	vmovdqu xmm8,XMMWORD PTR [rsp+0x70]
  411a40:	vmovups XMMWORD PTR [rsp+0x340],xmm8
  411a49:	vmovdqu xmm9,XMMWORD PTR [rsp+0x88]
  411a52:	vmovdqu xmm10,XMMWORD PTR [rsp+0xa8]
  411a5b:	vmovups XMMWORD PTR [rsp+0x350],xmm10
  411a64:	vmovdqu xmm11,XMMWORD PTR [rsp+0xc0]
  411a6d:	vmovdqu xmm12,XMMWORD PTR [rsp+0xe0]
  411a76:	vmovups XMMWORD PTR [rsp+0x360],xmm11
  411a7f:	vmovups XMMWORD PTR [rsp+0x370],xmm12
  411a88:	vmovdqu xmm13,XMMWORD PTR [rsp+0xf8]
  411a91:	mov    rcx,QWORD PTR [rsp+0x68]
  411a96:	mov    rdx,QWORD PTR [rsp+0x30]
  411a9b:	mov    r8,QWORD PTR [rsp+0xa0]
  411aa3:	mov    r9,QWORD PTR [rsp+0xd8]
  411aab:	mov    r10,QWORD PTR [rsp+0x110]
  411ab3:	jmp    411b14 <__swc_fn_6b1cf01f_000176_0ce64436+0x2f4>
  411ab5:	cs nop WORD PTR [rax+rax*1+0x0]
  411abf:	cs nop WORD PTR [rax+rax*1+0x0]
  411ac9:	nop    DWORD PTR [rax+0x0]
  411ad0:	vmovups xmm2,XMMWORD PTR [rsp+0x2f0]
  411ad9:	vmovups xmm4,XMMWORD PTR [rsp+0x310]
  411ae2:	vmovups xmm5,XMMWORD PTR [rsp+0x320]
  411aeb:	vmovups xmm10,xmm13
  411af0:	vmovups XMMWORD PTR [rsp+0x360],xmm7
  411af9:	vmovups xmm12,xmm11
  411afe:	vmovups xmm13,xmm3
  411b02:	vmovups xmm3,XMMWORD PTR [rsp+0x300]
  411b0b:	vmovups xmm7,XMMWORD PTR [rsp+0x330]
  411b14:	vsubpd xmm14,xmm3,xmm5
  411b18:	vpsrldq xmm6,xmm14,0x8
  411b1e:	vmovsd xmm15,QWORD PTR [rbx+0x10]
  411b23:	vmovsd QWORD PTR [rsp+0x390],xmm15
  411b2c:	vmovsd xmm0,QWORD PTR [rbx+0x48]
  411b31:	vmovq  rsi,xmm0
  411b36:	vsubsd xmm5,xmm15,xmm0
  411b3a:	vmulsd xmm0,xmm14,xmm14
  411b3f:	vfmadd231sd xmm0,xmm6,xmm6
  411b44:	vfmadd231sd xmm0,xmm5,xmm5
  411b49:	vsubpd xmm6,xmm3,xmm8
  411b4e:	vmulsd xmm8,xmm6,xmm6
  411b52:	vmovups XMMWORD PTR [rsp+0x380],xmm13
  411b5b:	vpsrldq xmm13,xmm6,0x8
  411b60:	vfmadd231sd xmm8,xmm13,xmm13
  411b65:	vmovsd xmm13,QWORD PTR [rbx+0x80]
  411b6d:	vmovsd QWORD PTR [rsp+0x3a0],xmm13
  411b76:	vsubsd xmm1,xmm15,xmm13
  411b7b:	vfmadd231sd xmm8,xmm1,xmm1
  411b80:	vpunpcklqdq xmm0,xmm0,xmm8
  411b85:	vsqrtpd xmm8,xmm0
  411b89:	vmulpd xmm0,xmm0,xmm8
  411b8e:	vdivpd xmm0,xmm2,xmm0
  411b92:	vpshufd xmm8,xmm0,0x44
  411b97:	vmovq  xmm13,rcx
  411b9c:	vpshufd xmm13,xmm13,0x44
  411ba2:	vmulpd xmm11,xmm14,xmm13
  411ba7:	vmovups XMMWORD PTR [rsp+0x3b0],xmm13
  411bb0:	vmovq  xmm13,rcx
  411bb5:	vfnmadd231pd xmm4,xmm11,xmm8
  411bba:	vmulsd xmm11,xmm5,xmm13
  411bbf:	vfnmadd213sd xmm11,xmm0,QWORD PTR [rbx+0x28]
  411bc5:	vmovq  xmm13,rdx
  411bca:	vpshufd xmm13,xmm13,0x44
  411bd0:	vmulpd xmm14,xmm14,xmm13
  411bd5:	vmulpd xmm8,xmm14,xmm8
  411bda:	vmovq  xmm14,rdx
  411bdf:	vaddpd xmm7,xmm7,xmm8
  411be4:	vmovups XMMWORD PTR [rsp+0x3d0],xmm7
  411bed:	vmulsd xmm5,xmm5,xmm14
  411bf2:	vfmadd213sd xmm5,xmm0,QWORD PTR [rbx+0x60]
  411bf8:	vmovsd QWORD PTR [rsp+0x3e0],xmm5
  411c01:	vmulpd xmm8,xmm6,xmm13
  411c06:	vpsrldq xmm0,xmm0,0x8
  411c0b:	vpshufd xmm5,xmm0,0x44
  411c10:	vmulpd xmm8,xmm8,xmm5
  411c14:	vmovq  xmm2,r8
  411c19:	vpshufd xmm2,xmm2,0x44
  411c1e:	vmulpd xmm6,xmm6,xmm2
  411c22:	vfnmadd231pd xmm4,xmm6,xmm5
  411c27:	vmovq  xmm5,r8
  411c2c:	vmulsd xmm6,xmm1,xmm5
  411c30:	vfnmadd213sd xmm6,xmm0,xmm11
  411c35:	vaddpd xmm8,xmm9,xmm8
  411c3a:	vmovups XMMWORD PTR [rsp+0x410],xmm8
  411c43:	vmulsd xmm1,xmm1,xmm14
  411c48:	vmulsd xmm0,xmm1,xmm0
  411c4c:	vaddsd xmm0,xmm0,QWORD PTR [rbx+0x98]
  411c54:	vmovsd QWORD PTR [rsp+0x420],xmm0
  411c5d:	vsubpd xmm1,xmm3,xmm10
  411c62:	vmulpd xmm9,xmm1,xmm13
  411c67:	vpsrldq xmm0,xmm1,0x8
  411c6c:	vmovsd xmm11,QWORD PTR [rbx+0xb8]
  411c74:	vmovsd QWORD PTR [rsp+0x428],xmm11
  411c7d:	vsubsd xmm5,xmm15,xmm11
  411c82:	vmulsd xmm8,xmm1,xmm1
  411c86:	vfmadd213sd xmm0,xmm0,xmm8
  411c8b:	vfmadd231sd xmm0,xmm5,xmm5
  411c90:	vsubpd xmm8,xmm3,xmm12
  411c95:	vmulsd xmm12,xmm8,xmm8
  411c9a:	vpsrldq xmm7,xmm8,0x8
  411ca0:	vmulsd xmm7,xmm7,xmm7
  411ca4:	vaddsd xmm7,xmm12,xmm7
  411ca8:	vmovsd xmm12,QWORD PTR [rbx+0xf0]
  411cb0:	vmovq  r11,xmm12
  411cb5:	vsubsd xmm11,xmm15,xmm12
  411cba:	vfmadd231sd xmm7,xmm11,xmm11
  411cbf:	vpunpcklqdq xmm0,xmm0,xmm7
  411cc3:	vsqrtpd xmm7,xmm0
  411cc7:	vmulpd xmm0,xmm0,xmm7
  411ccb:	vmovups xmm15,XMMWORD PTR [rsp+0x2f0]
  411cd4:	vdivpd xmm0,xmm15,xmm0
  411cd8:	vpshufd xmm7,xmm0,0x44
  411cdd:	vmulpd xmm9,xmm9,xmm7
  411ce1:	vmovq  xmm12,r9
  411ce6:	vpshufd xmm12,xmm12,0x44
  411cec:	vmulpd xmm1,xmm1,xmm12
  411cf1:	vfnmadd213pd xmm1,xmm7,xmm4
  411cf6:	vmovq  xmm7,r9
  411cfb:	vmovsd QWORD PTR [rsp+0x450],xmm7
  411d04:	vmulsd xmm4,xmm5,xmm7
  411d08:	vfnmadd231sd xmm6,xmm4,xmm0
  411d0d:	vaddpd xmm9,xmm9,XMMWORD PTR [rsp+0x360]
  411d16:	vmulsd xmm4,xmm5,xmm14
  411d1b:	vmovsd xmm5,QWORD PTR [rbx+0xd0]
  411d23:	vfmadd231sd xmm5,xmm4,xmm0
  411d28:	vmovsd QWORD PTR [rsp+0x458],xmm5
  411d31:	vmulpd xmm4,xmm8,xmm13
  411d36:	vpsrldq xmm0,xmm0,0x8
  411d3b:	vpshufd xmm13,xmm0,0x44
  411d40:	vmulpd xmm4,xmm4,xmm13
  411d45:	vmovq  xmm5,r10
  411d4a:	vpshufd xmm5,xmm5,0x44
  411d4f:	vmovups XMMWORD PTR [rsp+0x460],xmm5
  411d58:	vmulpd xmm8,xmm8,xmm5
  411d5c:	vmulpd xmm8,xmm8,xmm13
  411d61:	vmovups xmm13,xmm4
  411d65:	vsubpd xmm4,xmm1,xmm8
  411d6a:	vfmadd231pd xmm3,xmm4,XMMWORD PTR [rsp+0x2e0]
  411d74:	vmovq  xmm8,r10
  411d79:	vmovups XMMWORD PTR [rsp+0x300],xmm3
  411d82:	vmovsd QWORD PTR [rsp+0x470],xmm8
  411d8b:	vaddpd xmm3,xmm13,XMMWORD PTR [rsp+0x380]
  411d94:	vmovups XMMWORD PTR [rsp+0x480],xmm3
  411d9d:	vmulsd xmm13,xmm11,xmm8
  411da2:	vfnmadd231sd xmm6,xmm13,xmm0
  411da7:	vmovsd QWORD PTR [rbx+0x28],xmm6
  411dac:	vmulsd xmm11,xmm11,xmm14
  411db1:	vmulsd xmm0,xmm11,xmm0
  411db5:	vaddsd xmm0,xmm0,QWORD PTR [rbx+0x108]
  411dbd:	vmovups xmm13,XMMWORD PTR [rsp+0x320]
  411dc6:	vmovsd QWORD PTR [rsp+0x498],xmm0
  411dcf:	vsubpd xmm14,xmm13,XMMWORD PTR [rsp+0x340]
  411dd8:	vmovups XMMWORD PTR [rsp+0x310],xmm4
  411de1:	vmulpd xmm4,xmm14,xmm2
  411de5:	vmovups xmm6,XMMWORD PTR [rsp+0x3b0]
  411dee:	vmovups XMMWORD PTR [rsp+0x3f0],xmm2
  411df7:	vmulpd xmm2,xmm14,xmm6
  411dfb:	vpsrldq xmm8,xmm14,0x8
  411e01:	vmovq  xmm0,rsi
  411e06:	vsubsd xmm1,xmm0,QWORD PTR [rsp+0x3a0]
  411e0f:	vmulsd xmm3,xmm14,xmm14
  411e14:	vfmadd231sd xmm3,xmm8,xmm8
  411e19:	vfmadd231sd xmm3,xmm1,xmm1
  411e1e:	vsubpd xmm8,xmm13,xmm10
  411e23:	vmulsd xmm14,xmm8,xmm8
  411e28:	vpsrldq xmm10,xmm8,0x8
  411e2e:	vmulsd xmm10,xmm10,xmm10
  411e33:	vaddsd xmm10,xmm14,xmm10
  411e38:	vsubsd xmm11,xmm0,QWORD PTR [rsp+0x428]
  411e41:	vfmadd231sd xmm10,xmm11,xmm11
  411e46:	vpunpcklqdq xmm3,xmm3,xmm10
  411e4b:	vsqrtpd xmm10,xmm3
  411e4f:	vmulpd xmm3,xmm3,xmm10
  411e54:	vdivpd xmm3,xmm15,xmm3
  411e58:	vpshufd xmm10,xmm3,0x44
  411e5d:	vfnmadd213pd xmm4,xmm10,XMMWORD PTR [rsp+0x3d0]
  411e67:	vmulpd xmm2,xmm2,xmm10
  411e6c:	vaddpd xmm2,xmm2,XMMWORD PTR [rsp+0x410]
  411e75:	vmovq  xmm10,r8
  411e7a:	vmovups XMMWORD PTR [rsp+0x4a0],xmm2
  411e83:	vmulsd xmm14,xmm1,xmm10
  411e88:	vmovsd xmm10,QWORD PTR [rsp+0x3e0]
  411e91:	vfnmadd231sd xmm10,xmm14,xmm3
  411e96:	vmovq  xmm14,rcx
  411e9b:	vmulsd xmm1,xmm1,xmm14
  411ea0:	vfmadd213sd xmm1,xmm3,QWORD PTR [rsp+0x420]
  411eaa:	vmovsd QWORD PTR [rsp+0x4b0],xmm1
  411eb3:	vmulpd xmm2,xmm8,xmm12
  411eb8:	vmulpd xmm8,xmm8,xmm6
  411ebc:	vpsrldq xmm3,xmm3,0x8
  411ec1:	vpshufd xmm1,xmm3,0x44
  411ec6:	vfnmadd213pd xmm2,xmm1,xmm4
  411ecb:	vfmadd213pd xmm1,xmm8,xmm9
  411ed0:	vmulsd xmm4,xmm11,xmm7
  411ed4:	vfnmadd213sd xmm4,xmm3,xmm10
  411ed9:	vmulsd xmm8,xmm11,xmm14
  411ede:	vmulsd xmm3,xmm8,xmm3
  411ee2:	vaddsd xmm3,xmm3,QWORD PTR [rsp+0x458]
  411eeb:	vmovsd QWORD PTR [rsp+0x4b8],xmm3
  411ef4:	vsubpd xmm9,xmm13,XMMWORD PTR [rsp+0x370]
  411efd:	vmulpd xmm10,xmm9,xmm5
  411f01:	vmulpd xmm6,xmm9,xmm6
  411f05:	vpsrldq xmm7,xmm9,0x8
  411f0b:	vmovq  xmm11,r11
  411f10:	vsubsd xmm5,xmm0,xmm11
  411f15:	vmulsd xmm0,xmm9,xmm9
  411f1a:	vfmadd231sd xmm0,xmm7,xmm7
  411f1f:	vfmadd231sd xmm0,xmm5,xmm5
  411f24:	vmovups xmm9,XMMWORD PTR [rsp+0x340]
  411f2d:	vsubpd xmm11,xmm9,XMMWORD PTR [rsp+0x350]
  411f36:	vmulsd xmm7,xmm11,xmm11
  411f3b:	vpsrldq xmm8,xmm11,0x8
  411f41:	vfmadd231sd xmm7,xmm8,xmm8
  411f46:	vmovsd xmm8,QWORD PTR [rsp+0x3a0]
  411f4f:	vsubsd xmm3,xmm8,QWORD PTR [rsp+0x428]
  411f58:	vfmadd231sd xmm7,xmm3,xmm3
  411f5d:	vpunpcklqdq xmm0,xmm0,xmm7
  411f61:	vsqrtpd xmm7,xmm0
  411f65:	vmulpd xmm0,xmm0,xmm7
  411f69:	vdivpd xmm0,xmm15,xmm0
  411f6d:	vpshufd xmm9,xmm0,0x44
  411f72:	vmulpd xmm7,xmm10,xmm9
  411f77:	vmovsd xmm15,QWORD PTR [rsp+0x450]
  411f80:	vsubpd xmm7,xmm2,xmm7
  411f84:	vmovups xmm2,XMMWORD PTR [rsp+0x2e0]
  411f8d:	vfmadd231pd xmm13,xmm7,xmm2
  411f92:	vmovups XMMWORD PTR [rsp+0x320],xmm13
  411f9b:	vmulpd xmm6,xmm6,xmm9
  411fa0:	vaddpd xmm6,xmm6,XMMWORD PTR [rsp+0x480]
  411fa9:	vmovsd xmm10,QWORD PTR [rsp+0x470]
  411fb2:	vmulsd xmm9,xmm5,xmm10
  411fb7:	vfnmadd231sd xmm4,xmm9,xmm0
  411fbc:	vmovsd QWORD PTR [rbx+0x60],xmm4
  411fc1:	vmulsd xmm5,xmm5,xmm14
  411fc6:	vfmadd213sd xmm5,xmm0,QWORD PTR [rsp+0x498]
  411fd0:	vmulpd xmm9,xmm11,xmm12
  411fd5:	vmovups xmm14,XMMWORD PTR [rsp+0x3f0]
  411fde:	vmulpd xmm11,xmm11,xmm14
  411fe3:	vpsrldq xmm0,xmm0,0x8
  411fe8:	vpshufd xmm13,xmm0,0x44
  411fed:	vmovups XMMWORD PTR [rsp+0x330],xmm7
  411ff6:	vmovups xmm7,XMMWORD PTR [rsp+0x4a0]
  411fff:	vfnmadd231pd xmm7,xmm9,xmm13
  412004:	vfmadd231pd xmm1,xmm11,xmm13
  412009:	vmovups XMMWORD PTR [rsp+0x4d0],xmm1
  412012:	vmulsd xmm9,xmm3,xmm15
  412017:	vmovsd xmm11,QWORD PTR [rsp+0x4b0]
  412020:	vfnmadd231sd xmm11,xmm9,xmm0
  412025:	vmovq  xmm13,r8
  41202a:	vmulsd xmm3,xmm3,xmm13
  41202f:	vmulsd xmm0,xmm3,xmm0
  412033:	vaddsd xmm0,xmm0,QWORD PTR [rsp+0x4b8]
  41203c:	vmovups xmm9,XMMWORD PTR [rsp+0x340]
  412045:	vmovups xmm3,XMMWORD PTR [rsp+0x370]
  41204e:	vmovsd QWORD PTR [rsp+0x4e0],xmm0
  412057:	vsubpd xmm4,xmm9,xmm3
  41205b:	vmulpd xmm15,xmm4,XMMWORD PTR [rsp+0x460]
  412064:	vmulpd xmm14,xmm4,xmm14
  412069:	vpsrldq xmm0,xmm4,0x8
  41206e:	vmovq  xmm9,r11
  412073:	vsubsd xmm1,xmm8,xmm9
  412078:	vmulsd xmm4,xmm4,xmm4
  41207c:	vfmadd213sd xmm0,xmm0,xmm4
  412081:	vfmadd231sd xmm0,xmm1,xmm1
  412086:	vmovups xmm4,XMMWORD PTR [rsp+0x350]
  41208f:	vsubpd xmm8,xmm4,xmm3
  412093:	vmovups XMMWORD PTR [rsp+0x4f0],xmm8
  41209c:	vmulsd xmm3,xmm8,xmm8
  4120a1:	vpsrldq xmm4,xmm8,0x8
  4120a7:	vfmadd231sd xmm3,xmm4,xmm4
  4120ac:	vmovsd xmm4,QWORD PTR [rsp+0x428]
  4120b5:	vmovups XMMWORD PTR [rsp+0x440],xmm12
  4120be:	vsubsd xmm12,xmm4,xmm9
  4120c3:	vmovsd QWORD PTR [rsp+0x500],xmm12
  4120cc:	vfmadd231sd xmm3,xmm12,xmm12
  4120d1:	vpunpcklqdq xmm0,xmm0,xmm3
  4120d5:	vsqrtpd xmm3,xmm0
  4120d9:	vmulpd xmm0,xmm0,xmm3
  4120dd:	vmovups xmm4,XMMWORD PTR [rsp+0x2f0]
  4120e6:	vdivpd xmm0,xmm4,xmm0
  4120ea:	vpshufd xmm3,xmm0,0x44
  4120ef:	vmulpd xmm15,xmm15,xmm3
  4120f3:	vmovups xmm8,XMMWORD PTR [rsp+0x340]
  4120fc:	vmovups xmm4,xmm9
  412101:	vmovups xmm12,XMMWORD PTR [rsp+0x460]
  41210a:	vsubpd xmm9,xmm7,xmm15
  41210f:	vfmadd231pd xmm8,xmm9,xmm2
  412114:	vmovups XMMWORD PTR [rsp+0x340],xmm8
  41211d:	vfmadd213pd xmm3,xmm14,xmm6
  412122:	vmulsd xmm6,xmm1,xmm10
  412127:	vfnmadd213sd xmm6,xmm0,xmm11
  41212c:	vmovsd QWORD PTR [rbx+0x98],xmm6
  412134:	vmulsd xmm1,xmm1,xmm13
  412139:	vfmadd213sd xmm1,xmm0,xmm5
  41213e:	vmovups xmm5,XMMWORD PTR [rsp+0x4f0]
  412147:	vmulpd xmm7,xmm5,xmm12
  41214c:	vmulpd xmm5,xmm5,XMMWORD PTR [rsp+0x440]
  412155:	vpsrldq xmm0,xmm0,0x8
  41215a:	vpshufd xmm11,xmm0,0x44
  41215f:	vfnmadd213pd xmm7,xmm11,XMMWORD PTR [rsp+0x4d0]
  412169:	vmovups xmm13,XMMWORD PTR [rsp+0x350]
  412172:	vfmadd231pd xmm13,xmm7,xmm2
  412177:	vmovups XMMWORD PTR [rsp+0x350],xmm13
  412180:	vmulpd xmm5,xmm5,xmm11
  412185:	vmovups xmm11,XMMWORD PTR [rsp+0x370]
  41218e:	vmovsd xmm12,QWORD PTR [rsp+0x3a0]
  412197:	vaddpd xmm3,xmm3,xmm5
  41219b:	vfmadd231pd xmm11,xmm3,xmm2
  4121a0:	vmovsd xmm5,QWORD PTR [rsp+0x500]
  4121a9:	vmovups XMMWORD PTR [rsp+0x370],xmm11
  4121b2:	vmulsd xmm10,xmm5,xmm10
  4121b7:	vfnmadd213sd xmm10,xmm0,QWORD PTR [rsp+0x4e0]
  4121c1:	vmovsd QWORD PTR [rbx+0xd0],xmm10
  4121c9:	vmulsd xmm5,xmm5,QWORD PTR [rsp+0x450]
  4121d2:	vfmadd213sd xmm0,xmm5,xmm1
  4121d7:	vmovsd QWORD PTR [rbx+0x108],xmm0
  4121df:	vmovsd xmm5,QWORD PTR [rip+0x1902]        # 413ae9 <__swc_rdata_base_6b1cf01f+0x9d9>
  4121e7:	vmovsd xmm1,QWORD PTR [rbx+0x28]
  4121ec:	vfmadd213sd xmm1,xmm5,QWORD PTR [rsp+0x390]
  4121f6:	vmovsd QWORD PTR [rbx+0x10],xmm1
  4121fb:	vmovsd xmm1,QWORD PTR [rbx+0x60]
  412200:	vmovq  xmm14,rsi
  412205:	vfmadd213sd xmm1,xmm5,xmm14
  41220a:	vmovsd QWORD PTR [rbx+0x48],xmm1
  41220f:	vmulsd xmm1,xmm6,xmm5
  412213:	vaddsd xmm1,xmm12,xmm1
  412217:	vmovsd QWORD PTR [rbx+0x80],xmm1
  41221f:	vmulsd xmm1,xmm10,xmm5
  412223:	vaddsd xmm1,xmm1,QWORD PTR [rsp+0x428]
  41222c:	vmovsd QWORD PTR [rbx+0xb8],xmm1
  412234:	vfmadd213sd xmm0,xmm5,xmm4
  412239:	vmovsd QWORD PTR [rbx+0xf0],xmm0
  412241:	add    rax,0x1
  412245:	cmp    rax,0x7a120
  41224c:	jl     411ad0 <__swc_fn_6b1cf01f_000176_0ce64436+0x2b0>
  412252:	vmovdqu XMMWORD PTR [rsp+0xa8],xmm13
  41225b:	vmovdqu XMMWORD PTR [rsp+0xc0],xmm7
  412264:	vmovdqu XMMWORD PTR [rsp+0xe0],xmm11
  41226d:	vmovdqu XMMWORD PTR [rsp+0xf8],xmm3
  412276:	vmovups xmm3,XMMWORD PTR [rsp+0x300]
  41227f:	vmovdqu XMMWORD PTR [rsp],xmm3
  412284:	vmovups xmm4,XMMWORD PTR [rsp+0x310]
  41228d:	vmovdqu XMMWORD PTR [rsp+0x18],xmm4
  412293:	vmovups xmm13,XMMWORD PTR [rsp+0x320]
  41229c:	vmovdqu XMMWORD PTR [rsp+0x38],xmm13
  4122a2:	vmovups xmm7,XMMWORD PTR [rsp+0x330]
  4122ab:	vmovdqu XMMWORD PTR [rsp+0x50],xmm7
  4122b1:	vmovdqu XMMWORD PTR [rsp+0x70],xmm8
  4122b7:	vmovdqu XMMWORD PTR [rsp+0x88],xmm9
  4122c0:	mov    QWORD PTR [rbx+0x258],0x5
  4122cb:	vxorpd xmm0,xmm0,xmm0
  4122cf:	vmovsd xmm1,QWORD PTR [rip+0x12dd]        # 4135b4 <__swc_rdata_base_6b1cf01f+0x4a4>
  4122d7:	vmovsd xmm3,QWORD PTR [rbx+0x30]
  4122dc:	vmulsd xmm2,xmm1,xmm3
  4122e0:	vmovsd xmm4,QWORD PTR [rbx+0x18]
  4122e5:	vmulsd xmm4,xmm4,xmm4
  4122e9:	vmovsd xmm5,QWORD PTR [rbx+0x20]
  4122ee:	vfmadd231sd xmm4,xmm5,xmm5
  4122f3:	vmovsd xmm5,QWORD PTR [rbx+0x28]
  4122f8:	vfmadd231sd xmm4,xmm5,xmm5
  4122fd:	vfmadd231sd xmm0,xmm2,xmm4
  412302:	vmovsd xmm2,QWORD PTR [rbx]
  412306:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x38]
  41230b:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  412310:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x40]
  412315:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  41231a:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x48]
  41231f:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x68]
  412324:	vmulsd xmm2,xmm2,xmm2
  412328:	vfmadd231sd xmm2,xmm4,xmm4
  41232d:	vfmadd231sd xmm2,xmm5,xmm5
  412332:	vsqrtsd xmm2,xmm2,xmm2
  412336:	vdivsd xmm2,xmm9,xmm2
  41233a:	vsubsd xmm0,xmm0,xmm2
  41233e:	vmovsd xmm2,QWORD PTR [rbx]
  412342:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x70]
  412347:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  41234c:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x78]
  412351:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  412356:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x80]
  41235e:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xa0]
  412366:	vmulsd xmm2,xmm2,xmm2
  41236a:	vfmadd231sd xmm2,xmm4,xmm4
  41236f:	vfmadd231sd xmm2,xmm5,xmm5
  412374:	vsqrtsd xmm2,xmm2,xmm2
  412378:	vdivsd xmm2,xmm9,xmm2
  41237c:	vsubsd xmm0,xmm0,xmm2
  412380:	vmovsd xmm2,QWORD PTR [rbx]
  412384:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  41238c:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  412391:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  412399:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  41239e:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  4123a6:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  4123ae:	vmulsd xmm2,xmm2,xmm2
  4123b2:	vfmadd231sd xmm2,xmm4,xmm4
  4123b7:	vfmadd231sd xmm2,xmm5,xmm5
  4123bc:	vsqrtsd xmm2,xmm2,xmm2
  4123c0:	vdivsd xmm2,xmm9,xmm2
  4123c4:	vsubsd xmm0,xmm0,xmm2
  4123c8:	vmovsd xmm2,QWORD PTR [rbx]
  4123cc:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xe0]
  4123d4:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  4123d9:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xe8]
  4123e1:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  4123e6:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xf0]
  4123ee:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x110]
  4123f6:	vmulsd xmm2,xmm2,xmm2
  4123fa:	vfmadd231sd xmm2,xmm4,xmm4
  4123ff:	vfmadd231sd xmm2,xmm5,xmm5
  412404:	vsqrtsd xmm2,xmm2,xmm2
  412408:	vdivsd xmm2,xmm9,xmm2
  41240c:	vsubsd xmm0,xmm0,xmm2
  412410:	vmovsd xmm3,QWORD PTR [rbx+0x68]
  412415:	vmulsd xmm2,xmm1,xmm3
  412419:	vmovsd xmm4,QWORD PTR [rbx+0x50]
  41241e:	vmulsd xmm4,xmm4,xmm4
  412422:	vmovsd xmm5,QWORD PTR [rbx+0x58]
  412427:	vfmadd231sd xmm4,xmm5,xmm5
  41242c:	vmovsd xmm5,QWORD PTR [rbx+0x60]
  412431:	vfmadd231sd xmm4,xmm5,xmm5
  412436:	vfmadd231sd xmm0,xmm2,xmm4
  41243b:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  412440:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x70]
  412445:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  41244a:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x78]
  41244f:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  412454:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x80]
  41245c:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xa0]
  412464:	vmulsd xmm2,xmm2,xmm2
  412468:	vfmadd231sd xmm2,xmm4,xmm4
  41246d:	vfmadd231sd xmm2,xmm5,xmm5
  412472:	vsqrtsd xmm2,xmm2,xmm2
  412476:	vdivsd xmm2,xmm9,xmm2
  41247a:	vsubsd xmm0,xmm0,xmm2
  41247e:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  412483:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  41248b:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  412490:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  412498:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  41249d:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  4124a5:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  4124ad:	vmulsd xmm2,xmm2,xmm2
  4124b1:	vfmadd231sd xmm2,xmm4,xmm4
  4124b6:	vfmadd231sd xmm2,xmm5,xmm5
  4124bb:	vsqrtsd xmm2,xmm2,xmm2
  4124bf:	vdivsd xmm2,xmm9,xmm2
  4124c3:	vsubsd xmm0,xmm0,xmm2
  4124c7:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  4124cc:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xe0]
  4124d4:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  4124d9:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xe8]
  4124e1:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  4124e6:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xf0]
  4124ee:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x110]
  4124f6:	vmulsd xmm2,xmm2,xmm2
  4124fa:	vfmadd231sd xmm2,xmm4,xmm4
  4124ff:	vfmadd231sd xmm2,xmm5,xmm5
  412504:	vsqrtsd xmm2,xmm2,xmm2
  412508:	vdivsd xmm2,xmm9,xmm2
  41250c:	vsubsd xmm0,xmm0,xmm2
  412510:	vmovsd xmm3,QWORD PTR [rbx+0xa0]
  412518:	vmulsd xmm2,xmm1,xmm3
  41251c:	vmovsd xmm4,QWORD PTR [rbx+0x88]
  412524:	vmulsd xmm4,xmm4,xmm4
  412528:	vmovsd xmm5,QWORD PTR [rbx+0x90]
  412530:	vfmadd231sd xmm4,xmm5,xmm5
  412535:	vmovsd xmm5,QWORD PTR [rbx+0x98]
  41253d:	vfmadd231sd xmm4,xmm5,xmm5
  412542:	vfmadd231sd xmm0,xmm2,xmm4
  412547:	vmovsd xmm2,QWORD PTR [rbx+0x70]
  41254c:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  412554:	vmovsd xmm4,QWORD PTR [rbx+0x78]
  412559:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  412561:	vmovsd xmm5,QWORD PTR [rbx+0x80]
  412569:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  412571:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  412579:	vmulsd xmm2,xmm2,xmm2
  41257d:	vfmadd231sd xmm2,xmm4,xmm4
  412582:	vfmadd231sd xmm2,xmm5,xmm5
  412587:	vsqrtsd xmm2,xmm2,xmm2
  41258b:	vdivsd xmm2,xmm9,xmm2
  41258f:	vsubsd xmm0,xmm0,xmm2
  412593:	vmovsd xmm2,QWORD PTR [rbx+0x70]
  412598:	vmovsd xmm6,QWORD PTR [rbx+0xe0]
  4125a0:	vsubsd xmm2,xmm2,xmm6
  4125a4:	vmovsd xmm4,QWORD PTR [rbx+0x78]
  4125a9:	vmovsd xmm7,QWORD PTR [rbx+0xe8]
  4125b1:	vsubsd xmm4,xmm4,xmm7
  4125b5:	vmovsd xmm5,QWORD PTR [rbx+0x80]
  4125bd:	vmovsd xmm8,QWORD PTR [rbx+0xf0]
  4125c5:	vsubsd xmm5,xmm5,xmm8
  4125ca:	vmovsd xmm10,QWORD PTR [rbx+0x110]
  4125d2:	vmulsd xmm9,xmm3,xmm10
  4125d7:	vmulsd xmm2,xmm2,xmm2
  4125db:	vfmadd231sd xmm2,xmm4,xmm4
  4125e0:	vfmadd231sd xmm2,xmm5,xmm5
  4125e5:	vsqrtsd xmm2,xmm2,xmm2
  4125e9:	vdivsd xmm2,xmm9,xmm2
  4125ed:	vsubsd xmm0,xmm0,xmm2
  4125f1:	vmovsd xmm3,QWORD PTR [rbx+0xd8]
  4125f9:	vmulsd xmm2,xmm1,xmm3
  4125fd:	vmovsd xmm4,QWORD PTR [rbx+0xc0]
  412605:	vmulsd xmm4,xmm4,xmm4
  412609:	vmovsd xmm5,QWORD PTR [rbx+0xc8]
  412611:	vfmadd231sd xmm4,xmm5,xmm5
  412616:	vmovsd xmm5,QWORD PTR [rbx+0xd0]
  41261e:	vfmadd231sd xmm4,xmm5,xmm5
  412623:	vfmadd231sd xmm0,xmm2,xmm4
  412628:	vmovsd xmm2,QWORD PTR [rbx+0xa8]
  412630:	vsubsd xmm2,xmm2,xmm6
  412634:	vmovsd xmm4,QWORD PTR [rbx+0xb0]
  41263c:	vsubsd xmm4,xmm4,xmm7
  412640:	vmovsd xmm5,QWORD PTR [rbx+0xb8]
  412648:	vsubsd xmm5,xmm5,xmm8
  41264d:	vmulsd xmm9,xmm3,xmm10
  412652:	vmulsd xmm2,xmm2,xmm2
  412656:	vfmadd231sd xmm2,xmm4,xmm4
  41265b:	vfmadd231sd xmm2,xmm5,xmm5
  412660:	vsqrtsd xmm2,xmm2,xmm2
  412664:	vdivsd xmm2,xmm9,xmm2
  412668:	vsubsd xmm0,xmm0,xmm2
  41266c:	vmulsd xmm2,xmm10,xmm1
  412670:	vmovsd xmm4,QWORD PTR [rbx+0xf8]
  412678:	vmulsd xmm4,xmm4,xmm4
  41267c:	vmovsd xmm5,QWORD PTR [rbx+0x100]
  412684:	vfmadd231sd xmm4,xmm5,xmm5
  412689:	vmovsd xmm5,QWORD PTR [rbx+0x108]
  412691:	vfmadd231sd xmm4,xmm5,xmm5
  412696:	vfmadd231sd xmm0,xmm2,xmm4
  41269b:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0xead]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  4126a3:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x1447]        # 413af2 <__swc_rdata_base_6b1cf01f+0x9e2>
  4126ab:	vroundsd xmm0,xmm0,xmm0,0x1
  4126b1:	vmovsd xmm1,QWORD PTR [rip+0xee9]        # 4135a2 <__swc_rdata_base_6b1cf01f+0x492>
  4126b9:	vcomisd xmm0,xmm1
  4126bd:	jb     4126d7 <__swc_fn_6b1cf01f_000176_0ce64436+0xeb7>
  4126bf:	vsubsd xmm0,xmm0,xmm1
  4126c3:	vcvttsd2si rsi,xmm0
  4126c8:	movabs rax,0x8000000000000000
  4126d2:	xor    rsi,rax
  4126d5:	jmp    4126dc <__swc_fn_6b1cf01f_000176_0ce64436+0xebc>
  4126d7:	vcvttsd2si rsi,xmm0
  4126dc:	sub    rsp,0x8
  4126e0:	call   40d550 <__swc_fn_6b1cf01f_000175_1ca87929>
  4126e5:	add    rsp,0x8
  4126e9:	vsubsd xmm0,xmm0,QWORD PTR [rsp+0x2d0]
  4126f2:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x1401]        # 413afb <__swc_rdata_base_6b1cf01f+0x9eb>
  4126fa:	lea    rax,[rip+0xc67]        # 413368 <__swc_rdata_base_6b1cf01f+0x258>
  412701:	sub    rsp,0x90
  412708:	mov    rcx,rsp
  41270b:	vmovups xmm1,XMMWORD PTR [rip+0x13ad]        # 413ac0 <__swc_rdata_base_6b1cf01f+0x9b0>
  412713:	vmovups XMMWORD PTR [rcx],xmm1
  412717:	mov    QWORD PTR [rcx+0x30],rsp
  41271b:	lea    rdx,[rip+0xbee]        # 413310 <__swc_rdata_base_6b1cf01f+0x200>
  412722:	mov    QWORD PTR [rcx+0x38],rdx
  412726:	mov    QWORD PTR [rcx+0x10],rsi
  41272a:	lea    r8,[rsp+0x10]
  41272f:	mov    QWORD PTR [rcx+0x40],r8
  412733:	lea    r8,[rip+0x12f6]        # 413a30 <__swc_rdata_base_6b1cf01f+0x920>
  41273a:	mov    QWORD PTR [rcx+0x48],r8
  41273e:	vmovups xmm1,XMMWORD PTR [rip+0x138a]        # 413ad0 <__swc_rdata_base_6b1cf01f+0x9c0>
  412746:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  41274b:	lea    r8,[rsp+0x18]
  412750:	mov    QWORD PTR [rcx+0x50],r8
  412754:	mov    QWORD PTR [rcx+0x58],rdx
  412758:	vmovsd QWORD PTR [rcx+0x28],xmm0
  41275d:	lea    r8,[rcx+0x28]
  412761:	mov    QWORD PTR [rcx+0x60],r8
  412765:	lea    r8,[rip+0x130c]        # 413a78 <__swc_rdata_base_6b1cf01f+0x968>
  41276c:	mov    QWORD PTR [rcx+0x68],r8
  412770:	mov    QWORD PTR [rcx+0x70],rax
  412774:	mov    QWORD PTR [rcx+0x78],rdx
  412778:	lea    rax,[rcx+0x30]
  41277c:	mov    QWORD PTR [rcx+0x80],rax
  412783:	mov    QWORD PTR [rcx+0x88],0x5
  41278e:	lea    rcx,[rcx+0x80]
  412795:	sub    rsp,0x8
  412799:	call   410140 <__swc_fn_6b1cf01f_000146_e9d46966>
  41279e:	add    rsp,0x5a8
  4127a5:	vmovups xmm6,XMMWORD PTR [rsp]
  4127aa:	vmovups xmm7,XMMWORD PTR [rsp+0x10]
  4127b0:	vmovups xmm8,XMMWORD PTR [rsp+0x20]
  4127b6:	vmovups xmm9,XMMWORD PTR [rsp+0x30]
  4127bc:	vmovups xmm10,XMMWORD PTR [rsp+0x40]
  4127c2:	vmovups xmm11,XMMWORD PTR [rsp+0x50]
  4127c8:	vmovups xmm12,XMMWORD PTR [rsp+0x60]
  4127ce:	vmovups xmm13,XMMWORD PTR [rsp+0x70]
  4127d4:	vmovups xmm14,XMMWORD PTR [rsp+0x80]
  4127dd:	vmovups xmm15,XMMWORD PTR [rsp+0x90]
  4127e6:	add    rsp,0xa8
  4127ed:	pop    rsi
  4127ee:	pop    rbx
  4127ef:	pop    rbp
  4127f0:	ret
