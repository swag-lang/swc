
/workspace/prompt2-20261115/batch5-final-micro/base/binarytrees/binarytrees:     file format elf64-x86-64


Disassembly of section .text:

000000000040a380 <__swc_fn_7dafa2b1_000177_6e6aee58>:
  40a380:	push   rbx
  40a381:	sub    rsp,0x80
  40a388:	mov    rax,rcx
  40a38b:	mov    rcx,QWORD PTR [rax]
  40a38e:	test   rcx,rcx
  40a391:	je     40a3b0 <__swc_fn_7dafa2b1_000177_6e6aee58+0x30>
  40a393:	mov    QWORD PTR [rsp+0x68],rax
  40a398:	call   40a380 <__swc_fn_7dafa2b1_000177_6e6aee58>
  40a39d:	mov    rax,QWORD PTR [rsp+0x68]
  40a3a2:	mov    rcx,QWORD PTR [rax+0x8]
  40a3a6:	call   40a380 <__swc_fn_7dafa2b1_000177_6e6aee58>
  40a3ab:	mov    rax,QWORD PTR [rsp+0x68]
  40a3b0:	test   rax,rax
  40a3b3:	je     40a41f <__swc_fn_7dafa2b1_000177_6e6aee58+0x9f>
  40a3b5:	vxorps xmm0,xmm0,xmm0
  40a3b9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a3bf:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a3c5:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a3cb:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40a3d1:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40a3d7:	lea    rcx,[rax-0x10]
  40a3db:	mov    QWORD PTR [rsp+0x48],rcx
  40a3e0:	mov    rax,QWORD PTR [rax-0x10]
  40a3e4:	mov    QWORD PTR [rsp+0x50],rax
  40a3e9:	mov    rcx,QWORD PTR [rip+0x1b950]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40a3f0:	test   rcx,rcx
  40a3f3:	jne    40a405 <__swc_fn_7dafa2b1_000177_6e6aee58+0x85>
  40a3f5:	call   40a1d0 <__swc_fn_7dafa2b1_000165_dc0404ce>
  40a3fa:	lea    rcx,[rax+0x1]
  40a3fe:	mov    QWORD PTR [rip+0x1b93b],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40a405:	dec    rcx
  40a408:	call   4119a0 <__swc_fn_7dafa2b1_000167_3393d6f4>
  40a40d:	mov    rcx,QWORD PTR [rax]
  40a410:	lea    rdx,[rsp+0x8]
  40a415:	mov    rbx,QWORD PTR [rax+0x8]
  40a419:	mov    rbx,QWORD PTR [rbx+0x18]
  40a41d:	call   rbx
  40a41f:	add    rsp,0x80
  40a426:	pop    rbx
  40a427:	ret
