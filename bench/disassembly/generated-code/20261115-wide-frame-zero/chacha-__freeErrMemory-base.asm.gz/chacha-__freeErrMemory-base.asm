
/workspace/prompt2-20261115/batch5-final-micro/base/chacha/chacha:     file format elf64-x86-64


Disassembly of section .text:

0000000000408960 <__swc_fn_3464c816_000096_c5a6a65c>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40896f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408975:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40897b:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  408981:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  408987:	mov    QWORD PTR [rsp+0x48],rdx
  40898c:	mov    rax,r8
  40898f:	cmp    r8,0x1
  408993:	mov    edx,0x1
  408998:	cmovb  rax,rdx
  40899c:	mov    QWORD PTR [rsp+0x50],rax
  4089a1:	mov    rbx,QWORD PTR [rcx+0x8]
  4089a5:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a9:	mov    rcx,QWORD PTR [rcx]
  4089ac:	lea    rdx,[rsp+0x8]
  4089b1:	call   rbx
  4089b3:	add    rsp,0x70
  4089b7:	pop    rbx
  4089b8:	ret
