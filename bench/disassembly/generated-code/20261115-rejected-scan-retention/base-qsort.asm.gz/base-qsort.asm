
/workspace/prompt2-20261115/batch8-final-micro/base/sort/sort:     file format elf64-x86-64


Disassembly of section .text:

000000000040d6e0 <__swc_fn_ff58629f_000178_2a1d71b4>:
  40d6e0:	push   rsi
  40d6e1:	push   rdi
  40d6e2:	push   r12
  40d6e4:	mov    rsi,rcx
  40d6e7:	mov    rdi,rdx
  40d6ea:	mov    r12,r8
  40d6ed:	cs nop WORD PTR [rax+rax*1+0x0]
  40d6f7:	nop    WORD PTR [rax+rax*1+0x0]
  40d700:	mov    rax,r12
  40d703:	sub    rax,rdi
  40d706:	cmp    rax,0x10
  40d70a:	jle    40d7e9 <__swc_fn_ff58629f_000178_2a1d71b4+0x109>
  40d710:	shr    rax,1
  40d713:	lea    rcx,[rdi+rax*1]
  40d717:	mov    rax,QWORD PTR [rsi+rcx*8]
  40d71b:	mov    rdx,QWORD PTR [rsi+rdi*8]
  40d71f:	cmp    rax,rdx
  40d722:	jae    40d72f <__swc_fn_ff58629f_000178_2a1d71b4+0x4f>
  40d724:	mov    QWORD PTR [rsi+rdi*8],rax
  40d728:	mov    QWORD PTR [rsi+rcx*8],rdx
  40d72c:	mov    rdx,rax
  40d72f:	mov    rax,QWORD PTR [rsi+r12*8]
  40d733:	cmp    rax,rdx
  40d736:	jae    40d743 <__swc_fn_ff58629f_000178_2a1d71b4+0x63>
  40d738:	mov    QWORD PTR [rsi+rdi*8],rax
  40d73c:	mov    QWORD PTR [rsi+r12*8],rdx
  40d740:	mov    rax,rdx
  40d743:	mov    rdx,QWORD PTR [rsi+rcx*8]
  40d747:	cmp    rax,rdx
  40d74a:	jae    40d754 <__swc_fn_ff58629f_000178_2a1d71b4+0x74>
  40d74c:	mov    QWORD PTR [rsi+rcx*8],rax
  40d750:	mov    QWORD PTR [rsi+r12*8],rdx
  40d754:	mov    rax,QWORD PTR [rsi+rcx*8]
  40d758:	mov    r9,rdi
  40d75b:	mov    r10,r12
  40d75e:	xchg   ax,ax
  40d760:	cmp    QWORD PTR [rsi+r9*8],rax
  40d764:	jae    40d77a <__swc_fn_ff58629f_000178_2a1d71b4+0x9a>
  40d766:	cs nop WORD PTR [rax+rax*1+0x0]
  40d770:	add    r9,0x1
  40d774:	cmp    QWORD PTR [rsi+r9*8],rax
  40d778:	jb     40d770 <__swc_fn_ff58629f_000178_2a1d71b4+0x90>
  40d77a:	cmp    QWORD PTR [rsi+r10*8],rax
  40d77e:	jbe    40d78a <__swc_fn_ff58629f_000178_2a1d71b4+0xaa>
  40d780:	sub    r10,0x1
  40d784:	cmp    QWORD PTR [rsi+r10*8],rax
  40d788:	ja     40d780 <__swc_fn_ff58629f_000178_2a1d71b4+0xa0>
  40d78a:	cmp    r9,r10
  40d78d:	jg     40d7ac <__swc_fn_ff58629f_000178_2a1d71b4+0xcc>
  40d78f:	mov    rcx,QWORD PTR [rsi+r9*8]
  40d793:	mov    rdx,QWORD PTR [rsi+r10*8]
  40d797:	mov    QWORD PTR [rsi+r9*8],rdx
  40d79b:	mov    QWORD PTR [rsi+r10*8],rcx
  40d79f:	add    r9,0x1
  40d7a3:	sub    r10,0x1
  40d7a7:	cmp    r9,r10
  40d7aa:	jle    40d760 <__swc_fn_ff58629f_000178_2a1d71b4+0x80>
  40d7ac:	mov    rax,r10
  40d7af:	sub    rax,rdi
  40d7b2:	mov    rcx,r12
  40d7b5:	sub    rcx,r9
  40d7b8:	cmp    rax,rcx
  40d7bb:	jge    40d7d3 <__swc_fn_ff58629f_000178_2a1d71b4+0xf3>
  40d7bd:	mov    rcx,rsi
  40d7c0:	mov    rdx,rdi
  40d7c3:	mov    r8,r10
  40d7c6:	mov    rdi,r9
  40d7c9:	call   40d6e0 <__swc_fn_ff58629f_000178_2a1d71b4>
  40d7ce:	jmp    40d700 <__swc_fn_ff58629f_000178_2a1d71b4+0x20>
  40d7d3:	mov    rcx,rsi
  40d7d6:	mov    rdx,r9
  40d7d9:	mov    r8,r12
  40d7dc:	mov    r12,r10
  40d7df:	call   40d6e0 <__swc_fn_ff58629f_000178_2a1d71b4>
  40d7e4:	jmp    40d700 <__swc_fn_ff58629f_000178_2a1d71b4+0x20>
  40d7e9:	lea    rax,[rdi+0x1]
  40d7ed:	cmp    rax,r12
  40d7f0:	jg     40d833 <__swc_fn_ff58629f_000178_2a1d71b4+0x153>
  40d7f2:	cs nop WORD PTR [rax+rax*1+0x0]
  40d7fc:	nop    DWORD PTR [rax+0x0]
  40d800:	mov    rcx,QWORD PTR [rsi+rax*8]
  40d804:	lea    rdx,[rax-0x1]
  40d808:	cmp    rdx,rdi
  40d80b:	jl     40d826 <__swc_fn_ff58629f_000178_2a1d71b4+0x146>
  40d80d:	nop    DWORD PTR [rax]
  40d810:	mov    r8,QWORD PTR [rsi+rdx*8]
  40d814:	cmp    r8,rcx
  40d817:	jbe    40d826 <__swc_fn_ff58629f_000178_2a1d71b4+0x146>
  40d819:	mov    QWORD PTR [rsi+rdx*8+0x8],r8
  40d81e:	dec    rdx
  40d821:	cmp    rdx,rdi
  40d824:	jge    40d810 <__swc_fn_ff58629f_000178_2a1d71b4+0x130>
  40d826:	mov    QWORD PTR [rsi+rdx*8+0x8],rcx
  40d82b:	inc    rax
  40d82e:	cmp    rax,r12
  40d831:	jle    40d800 <__swc_fn_ff58629f_000178_2a1d71b4+0x120>
  40d833:	pop    r12
  40d835:	pop    rdi
  40d836:	pop    rsi
  40d837:	ret
