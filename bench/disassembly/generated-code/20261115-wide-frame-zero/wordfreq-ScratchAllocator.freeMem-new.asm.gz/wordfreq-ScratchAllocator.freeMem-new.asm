
/workspace/prompt2-20261115/batch5-final-micro/new/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

000000000040a310 <__swc_fn_4fa09e82_000162_47b270e1>:
  40a310:	push   rbx
  40a311:	sub    rsp,0x70
  40a315:	mov    rax,QWORD PTR [rcx]
  40a318:	mov    rbx,QWORD PTR [rcx+0x8]
  40a31c:	vxorps xmm0,xmm0,xmm0
  40a320:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40a326:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40a32c:	vzeroupper
  40a32f:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40a335:	mov    QWORD PTR [rsp+0x48],rdx
  40a33a:	mov    QWORD PTR [rsp+0x50],r8
  40a33f:	mov    rcx,rax
  40a342:	lea    rdx,[rsp+0x8]
  40a347:	mov    rbx,QWORD PTR [rbx+0x18]
  40a34b:	call   rbx
  40a34d:	add    rsp,0x70
  40a351:	pop    rbx
  40a352:	ret
