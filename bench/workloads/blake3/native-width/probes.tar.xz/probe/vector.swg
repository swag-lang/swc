#global private
#global #[Swag.Safety(.Overflow, false)]

alias U32x8 = #simd [8] u32

func transform(input: const [*] u32, output: [*] u32)
{
    let blocks = cast(const [*] U32x8, input)
    let results = cast([*] U32x8, output)

    var state0 = blocks[0]
    var state1 = blocks[1]
    var state2 = blocks[2]
    var state3 = blocks[3]
    var state4 = blocks[4]
    var state5 = blocks[5]
    var state6 = blocks[6]
    var state7 = blocks[7]
    var state8 = blocks[8]
    var state9 = blocks[9]
    var state10 = blocks[10]
    var state11 = blocks[11]
    var state12 = blocks[12]
    var state13 = blocks[13]
    var state14 = blocks[14]
    var state15 = blocks[15]
    var state16 = blocks[16]
    var state17 = blocks[17]
    var state18 = blocks[18]
    var state19 = blocks[19]
    var state20 = blocks[20]
    var state21 = blocks[21]
    state0 += blocks[1]
    state1 += blocks[2]
    state2 += blocks[3]
    state3 += blocks[4]
    state4 += blocks[5]
    state5 += blocks[6]
    state6 += blocks[7]
    state7 += blocks[8]
    state8 += blocks[9]
    state9 += blocks[10]
    state10 += blocks[11]
    state11 += blocks[12]
    state12 += blocks[13]
    state13 += blocks[14]
    state14 += blocks[15]
    state15 += blocks[16]
    state16 += blocks[17]
    state17 += blocks[18]
    state18 += blocks[19]
    state19 += blocks[20]
    state20 += blocks[21]
    state21 += blocks[0]
    state0 = (state0 >> 7) | (state0 << 25)
    state1 = (state1 >> 7) | (state1 << 25)
    state2 = (state2 >> 7) | (state2 << 25)
    state3 = (state3 >> 7) | (state3 << 25)
    state4 = (state4 >> 7) | (state4 << 25)
    state5 = (state5 >> 7) | (state5 << 25)
    state6 = (state6 >> 7) | (state6 << 25)
    state7 = (state7 >> 7) | (state7 << 25)
    state8 = (state8 >> 7) | (state8 << 25)
    state9 = (state9 >> 7) | (state9 << 25)
    state10 = (state10 >> 7) | (state10 << 25)
    state11 = (state11 >> 7) | (state11 << 25)
    state12 = (state12 >> 7) | (state12 << 25)
    state13 = (state13 >> 7) | (state13 << 25)
    state14 = (state14 >> 7) | (state14 << 25)
    state15 = (state15 >> 7) | (state15 << 25)
    state16 = (state16 >> 7) | (state16 << 25)
    state17 = (state17 >> 7) | (state17 << 25)
    state18 = (state18 >> 7) | (state18 << 25)
    state19 = (state19 >> 7) | (state19 << 25)
    state20 = (state20 >> 7) | (state20 << 25)
    state21 = (state21 >> 7) | (state21 << 25)
    results[0] = state0 ^ state11
    results[1] = state1 ^ state12
    results[2] = state2 ^ state13
    results[3] = state3 ^ state14
    results[4] = state4 ^ state15
    results[5] = state5 ^ state16
    results[6] = state6 ^ state17
    results[7] = state7 ^ state18
    results[8] = state8 ^ state19
    results[9] = state9 ^ state20
    results[10] = state10 ^ state21
    results[11] = state11 ^ state0
    results[12] = state12 ^ state1
    results[13] = state13 ^ state2
    results[14] = state14 ^ state3
    results[15] = state15 ^ state4
    results[16] = state16 ^ state5
    results[17] = state17 ^ state6
    results[18] = state18 ^ state7
    results[19] = state19 ^ state8
    results[20] = state20 ^ state9
    results[21] = state21 ^ state10
}

#main
{
    var input: [177] u32
    var output: [178] u32
    for index in input.count do
        input[index] = cast(u32, index) * 0x9e3779b9'u32 + 0x85ebca6b'u32

    Swag.require(#sizeof(U32x8) == 32)
    output[0] = Swag.U32.Max
    output[177] = Swag.U32.Max
    transform(&input[1], &output[1])
    Swag.require(output[0] == Swag.U32.Max and output[177] == Swag.U32.Max)
    for block in 22
    {
        for lane in 8
        {
            let other = (block + 11) % 22
            let a = input[1 + block * 8 + lane] + input[1 + (block + 1) % 22 * 8 + lane]
            let b = input[1 + other * 8 + lane] + input[1 + (other + 1) % 22 * 8 + lane]
            let result = ((a >> 7) | (a << 25)) ^ ((b >> 7) | (b << 25))
            Swag.require(output[1 + block * 8 + lane] == result)
        }
    }

    const Eight = cast(U32x8, [1'u32, 2, 3, 4, 5, 6, 7, 8])
    let words = cast([8] u32, Eight)
    for index in 8 do
        Swag.require(words[index] == cast(u32, index + 1))
}
