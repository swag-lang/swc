from pathlib import Path
import sys,struct,subprocess,re,json,collections,bisect
root=Path(sys.argv[1]);report={}
def isnop(s):return 'nop' in s or bool(re.fullmatch(r'xchg\s+ax,ax',s))
def cname(name):return re.sub(r'(__lambda_|__run_expr_)[0-9a-f]+',r'\1HASH',name)
def decode(path):
 data=path.read_bytes();shoff=struct.unpack_from('<Q',data,40)[0];num,idx=struct.unpack_from('<HH',data,60);ss=struct.unpack_from('<IIQQQQIIQQ',data,shoff+idx*64);names=data[ss[4]:ss[4]+ss[5]];functions=[]
 for k in range(num):
  sh=struct.unpack_from('<IIQQQQIIQQ',data,shoff+k*64)
  if names[sh[0]:names.index(b'\0',sh[0])]!=b'.swagdbg':continue
  blob=data[sh[4]:sh[4]+sh[5]];_,v,count,_=struct.unpack_from('<IIII',blob);assert v==1
  def txt(o):return blob[o:blob.index(b'\0',o)].decode() if o else ''
  for n in range(count):
   rva,size,fn,src,line=struct.unpack_from('<IIIII',blob,16+n*20);functions.append((0x400000+rva,size,cname(txt(fn))))
 mapping={pc:fn for pc,_,fn in functions};raw=subprocess.check_output(['objdump','-d','-Mintel','--no-show-raw-insn',str(path)],text=True);(path.parent/'all.asm').write_text(raw);ops=[]
 for line in raw.splitlines():
  m=re.match(r'\s*([0-9a-f]+):\s+(.*)',line)
  if m:ops.append((int(m[1],16),m[2]))
 addresses=[pc for pc,_ in ops];out=collections.defaultdict(list)
 for lo,size,name in functions:
  body=ops[bisect.bisect_left(addresses,lo):bisect.bisect_left(addresses,lo+size)];real=[(pc,op) for pc,op in body if not isnop(op)];indices={pc:n for n,(pc,_) in enumerate(real)};normal=[]
  for pc,op in real:
   op=op.split('#')[0].strip();op=re.sub(r'\[rip[+-]0x[0-9a-f]+\]','[rip+RELOC]',op)
   m=re.match(r'(j\w+|call)\s+([0-9a-f]+)',op)
   if m:
    target=int(m[2],16);op=m[1]+' '+('I'+str(indices[target]) if target in indices else mapping.get(target,'ADDR'))
   normal.append(op)
  loops=[];groups=[]
  for n,(pc,op) in enumerate(body):
   m=re.match(r'j\w+\s+([0-9a-f]+)',op)
   if not m:continue
   end=body[n+1][0] if n+1<len(body) else lo+size
   start=pc
   if not op.startswith('jmp') and n and re.match(r'(cmp|test|and|add|sub)\s',body[n-1][1]):start=body[n-1][0]
   groups.append(dict(offset=start-lo,end=end-lo,phase32=start%32,phase64=start%64,bad32=start//32!=(end-1)//32 or end%32==0,bad64=start//64!=(end-1)//64 or end%64==0))
   target=int(m[1],16)
   if lo<=target<=pc:
    loop=[s for a,s in body if target<=a<=pc]
    loops.append(dict(start=hex(target),end=hex(pc),instructions=len(loop),nops=sum(isnop(s) for s in loop),memory=sum('[' in s and not s.startswith(('lea','nop','cs ','data16')) for s in loop)))
  out[name].append(dict(address=hex(lo),size=size,normal=normal,instructions=len(body),nops=len(body)-len(real),loops=loops,groups=groups))
 return out
for task in ['wordfreq','csvagg','sha256','dijkstra','raytrace','leven','chacha','nbody','fannkuch','binarytrees','lz77','sort']:
 a=decode(root/'base'/task/task);b=decode(root/'new'/task/task);changes=[]
 for name in sorted(set(a)|set(b)):
  aa=sorted(a[name],key=lambda x:x['normal']);bb=sorted(b[name],key=lambda x:x['normal'])
  if len(aa)!=len(bb):changes.append(dict(name=name,note='unpaired',base=aa,new=bb));continue
  for av,bv in zip(aa,bb):
   semantic=av['normal']!=bv['normal'];loopdiff=[(x['instructions'],y['instructions'],x['memory'],y['memory']) for x,y in zip(av['loops'],bv['loops']) if (x['instructions'],x['memory'])!=(y['instructions'],y['memory'])]
   if semantic or av['nops']!=bv['nops'] or av['loops']!=bv['loops'] or av['groups']!=bv['groups']:
    changes.append(dict(name=name,semantic_change=semantic,loop_changes=loopdiff,base=av,new=bv))
 report[task]=changes
 print(task,[(v['name'],v.get('semantic_change'),v.get('loop_changes')) for v in changes if v.get('semantic_change') or v.get('loop_changes')],flush=True)
(root/'native-review.json').write_text(json.dumps(report,indent=2)+'\n')
