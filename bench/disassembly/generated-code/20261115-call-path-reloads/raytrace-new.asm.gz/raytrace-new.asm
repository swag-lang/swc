
/workspace/prompt2-20261115/batch9-audited-micro/new/raytrace/raytrace:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <clock_gettime@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <clock_gettime@GLIBC_2.17>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <pthread_getspecific@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <pthread_getspecific@GLIBC_2.34>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <open@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <open@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <flock@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <flock@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <__errno_location@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <__errno_location@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <close@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <close@GLIBC_2.2.5>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <getpid@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <getpid@GLIBC_2.2.5>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <opendir@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <opendir@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dirfd@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <dirfd@GLIBC_2.2.5>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <readdir@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <readdir@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <readlinkat@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <readlinkat@GLIBC_2.4>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <openat@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <openat@GLIBC_2.4>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <closedir@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <closedir@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <lseek@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <lseek@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <mmap@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf92]        # 413078 <mmap@GLIBC_2.2.5>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <memfd_create@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf8a]        # 413080 <memfd_create@GLIBC_2.27>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <ftruncate@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf82]        # 413088 <ftruncate@GLIBC_2.2.5>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <write@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf7a]        # 413090 <write@GLIBC_2.2.5>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <backtrace@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf72]        # 413098 <backtrace@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <pthread_setspecific@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf6a]        # 4130a0 <pthread_setspecific@GLIBC_2.34>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <__x86_get_cpuid_feature_leaf@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf62]        # 4130a8 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <free@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf5a]        # 4130b0 <free@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <munmap@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf52]        # 4130b8 <munmap@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <mprotect@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf4a]        # 4130c0 <mprotect@GLIBC_2.2.5>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <exit@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf42]        # 4130c8 <exit@GLIBC_2.2.5>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <pthread_key_create@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf3a]        # 4130d0 <pthread_key_create@GLIBC_2.34>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <syscall@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf32]        # 4130d8 <syscall@GLIBC_2.2.5>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <dladdr@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130e0 <dladdr@GLIBC_2.34>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <malloc@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf22]        # 4130e8 <malloc@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <madvise@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <madvise@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <pthread_key_delete@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <pthread_key_delete@GLIBC_2.34>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <gettid@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <gettid@GLIBC_2.30>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_0a4ed24b_000176_4de704de+0xf20>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   4115e0 <__swc_fn_0a4ed24b_000125_540bf7e8>
  40724e:	xor    ecx,ecx
  407250:	call   410d00 <__swc_fn_0a4ed24b_000098_4f209617>
  407255:	call   407360 <__swc_fn_0a4ed24b_000003_a483827c>
  40725a:	call   408e50 <__swc_fn_0a4ed24b_000099_65137b72>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_0a4ed24b_000000_1ca87929>:
  407270:	push   rdi
  407271:	push   rsi
  407272:	sub    rsp,0xb8
  407279:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40727f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  407285:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40728b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  407291:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  407297:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40729d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4072a3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4072ac:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4072b5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4072be:	vxorps xmm0,xmm0,xmm0
  4072c2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4072c8:	mov    edi,0x1
  4072cd:	lea    rsi,[rsp+0x8]
  4072d2:	xor    eax,eax
  4072d4:	call   407000 <clock_gettime@plt>
  4072d9:	vxorpd xmm0,xmm0,xmm0
  4072dd:	mov    rax,QWORD PTR [rsp+0x8]
  4072e2:	vcvtsi2sd xmm0,xmm0,rax
  4072e7:	vxorpd xmm1,xmm1,xmm1
  4072eb:	mov    rax,QWORD PTR [rsp+0x10]
  4072f0:	vcvtsi2sd xmm1,xmm1,rax
  4072f5:	vdivsd xmm1,xmm1,QWORD PTR [rip+0xbe13]        # 413110 <__swc_rdata_base_0a4ed24b>
  4072fd:	vaddsd xmm0,xmm0,xmm1
  407301:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  407307:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40730d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  407313:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  407319:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40731f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  407325:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40732b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  407334:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40733d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  407346:	add    rsp,0xb8
  40734d:	pop    rsi
  40734e:	pop    rdi
  40734f:	ret
	...

0000000000407360 <__swc_fn_0a4ed24b_000003_a483827c>:
  407360:	push   rbp
  407361:	push   rsi
  407362:	push   rdi
  407363:	push   r12
  407365:	sub    rsp,0x90
  40736c:	mov    rbp,rsp
  40736f:	vmovups XMMWORD PTR [rsp],xmm6
  407374:	vmovups XMMWORD PTR [rsp+0x10],xmm7
  40737a:	vmovups XMMWORD PTR [rsp+0x20],xmm8
  407380:	vmovups XMMWORD PTR [rsp+0x30],xmm9
  407386:	vmovups XMMWORD PTR [rsp+0x40],xmm10
  40738c:	vmovups XMMWORD PTR [rsp+0x50],xmm11
  407392:	vmovups XMMWORD PTR [rsp+0x60],xmm12
  407398:	vmovups XMMWORD PTR [rsp+0x70],xmm13
  40739e:	vmovups XMMWORD PTR [rsp+0x80],xmm14
  4073a7:	sub    rsp,0x68
  4073ab:	call   407270 <__swc_fn_0a4ed24b_000000_1ca87929>
  4073b0:	add    rsp,0x8
  4073b4:	vmovups xmm6,xmm0
  4073b8:	xor    esi,esi
  4073ba:	xor    edi,edi
  4073bc:	vmovsd xmm7,QWORD PTR [rip+0xbd99]        # 41315d <__swc_rdata_base_0a4ed24b+0x4d>
  4073c4:	vmovsd xmm8,QWORD PTR [rip+0xc01c]        # 4133e8 <__swc_rdata_base_0a4ed24b+0x2d8>
  4073cc:	vmovsd xmm9,QWORD PTR [rip+0xbd77]        # 41314b <__swc_rdata_base_0a4ed24b+0x3b>
  4073d4:	vmovsd xmm10,QWORD PTR [rip+0xc015]        # 4133f1 <__swc_rdata_base_0a4ed24b+0x2e1>
  4073dc:	vmovsd xmm11,QWORD PTR [rip+0xc016]        # 4133fa <__swc_rdata_base_0a4ed24b+0x2ea>
  4073e4:	vmovsd xmm12,QWORD PTR [rip+0xc017]        # 413403 <__swc_rdata_base_0a4ed24b+0x2f3>
  4073ec:	sub    rsp,0x8
  4073f0:	xor    r12d,r12d
  4073f3:	vxorpd xmm0,xmm0,xmm0
  4073f7:	vcvtsi2sd xmm0,xmm0,edi
  4073fb:	vaddsd xmm0,xmm0,xmm7
  4073ff:	vdivsd xmm0,xmm0,xmm11
  407404:	vaddsd xmm0,xmm0,xmm0
  407408:	vsubsd xmm13,xmm9,xmm0
  40740c:	vmulsd xmm14,xmm13,xmm13
  407411:	cs nop WORD PTR [rax+rax*1+0x0]
  40741b:	cs nop WORD PTR [rax+rax*1+0x0]
  407425:	cs nop WORD PTR [rax+rax*1+0x0]
  40742f:	nop
  407430:	vxorpd xmm0,xmm0,xmm0
  407434:	vcvtsi2sd xmm0,xmm0,r12d
  407439:	vaddsd xmm0,xmm0,xmm7
  40743d:	vdivsd xmm0,xmm0,xmm8
  407442:	vaddsd xmm0,xmm0,xmm0
  407446:	vsubsd xmm0,xmm0,xmm9
  40744b:	vmulsd xmm0,xmm0,xmm10
  407450:	vmulsd xmm1,xmm0,xmm0
  407454:	vaddsd xmm1,xmm1,xmm14
  407459:	vaddsd xmm1,xmm1,xmm9
  40745e:	vsqrtsd xmm1,xmm1,xmm1
  407462:	vdivsd xmm5,xmm9,xmm1
  407466:	vmulsd xmm3,xmm0,xmm5
  40746a:	vmulsd xmm4,xmm13,xmm5
  40746e:	vxorpd xmm0,xmm0,xmm0
  407472:	vxorpd xmm1,xmm1,xmm1
  407476:	vxorpd xmm2,xmm2,xmm2
  40747a:	xor    ecx,ecx
  40747c:	call   40ec60 <__swc_fn_0a4ed24b_000002_3634f827>
  407481:	vmovsd xmm0,QWORD PTR [rip+0x1cbbf]        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  407489:	vmulsd xmm0,xmm0,xmm12
  40748e:	vcvttsd2si rcx,xmm0
  407493:	vmovsd xmm0,QWORD PTR [rip+0x1cbb5]        # 424050 <__swc_bss_base_0a4ed24b+0x10>
  40749b:	vmulsd xmm0,xmm0,xmm12
  4074a0:	vcvttsd2si r8,xmm0
  4074a5:	vmovsd xmm0,QWORD PTR [rip+0x1cbab]        # 424058 <__swc_bss_base_0a4ed24b+0x18>
  4074ad:	vmulsd xmm0,xmm0,xmm12
  4074b2:	vcvttsd2si r10,xmm0
  4074b7:	cmp    rcx,0xff
  4074be:	mov    eax,0xff
  4074c3:	cmovg  rcx,rax
  4074c7:	cmp    r8,0xff
  4074ce:	cmovg  r8,rax
  4074d2:	cmp    r10,0xff
  4074d9:	cmovg  r10,rax
  4074dd:	lea    rcx,[rcx+r8*2]
  4074e1:	lea    rax,[r10+r10*2]
  4074e5:	add    rcx,rax
  4074e8:	add    rsi,rcx
  4074eb:	add    r12,0x1
  4074ef:	cmp    r12,0x1e0
  4074f6:	jl     407430 <__swc_fn_0a4ed24b_000003_a483827c+0xd0>
  4074fc:	add    rdi,0x1
  407500:	cmp    rdi,0x168
  407507:	jl     4073f0 <__swc_fn_0a4ed24b_000003_a483827c+0x90>
  40750d:	add    rsp,0x8
  407511:	sub    rsp,0x8
  407515:	call   407270 <__swc_fn_0a4ed24b_000000_1ca87929>
  40751a:	add    rsp,0x8
  40751e:	vsubsd xmm0,xmm0,xmm6
  407522:	vmulsd xmm0,xmm0,QWORD PTR [rip+0xbee2]        # 41340c <__swc_rdata_base_0a4ed24b+0x2fc>
  40752a:	lea    rax,[rip+0xbdaf]        # 4132e0 <__swc_rdata_base_0a4ed24b+0x1d0>
  407531:	sub    rsp,0x90
  407538:	mov    rcx,rsp
  40753b:	vmovups xmm1,XMMWORD PTR [rip+0xbe85]        # 4133c8 <__swc_rdata_base_0a4ed24b+0x2b8>
  407543:	vmovups XMMWORD PTR [rcx],xmm1
  407547:	mov    QWORD PTR [rcx+0x30],rsp
  40754b:	lea    rdx,[rip+0xbd9e]        # 4132f0 <__swc_rdata_base_0a4ed24b+0x1e0>
  407552:	mov    QWORD PTR [rcx+0x38],rdx
  407556:	mov    QWORD PTR [rcx+0x10],rsi
  40755a:	lea    r8,[rsp+0x10]
  40755f:	mov    QWORD PTR [rcx+0x40],r8
  407563:	lea    r8,[rip+0xbdce]        # 413338 <__swc_rdata_base_0a4ed24b+0x228>
  40756a:	mov    QWORD PTR [rcx+0x48],r8
  40756e:	vmovups xmm1,XMMWORD PTR [rip+0xbe62]        # 4133d8 <__swc_rdata_base_0a4ed24b+0x2c8>
  407576:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40757b:	lea    r8,[rsp+0x18]
  407580:	mov    QWORD PTR [rcx+0x50],r8
  407584:	mov    QWORD PTR [rcx+0x58],rdx
  407588:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40758d:	lea    r8,[rcx+0x28]
  407591:	mov    QWORD PTR [rcx+0x60],r8
  407595:	lea    r8,[rip+0xbde4]        # 413380 <__swc_rdata_base_0a4ed24b+0x270>
  40759c:	mov    QWORD PTR [rcx+0x68],r8
  4075a0:	mov    QWORD PTR [rcx+0x70],rax
  4075a4:	mov    QWORD PTR [rcx+0x78],rdx
  4075a8:	lea    rax,[rcx+0x30]
  4075ac:	mov    QWORD PTR [rcx+0x80],rax
  4075b3:	mov    QWORD PTR [rcx+0x88],0x5
  4075be:	lea    rcx,[rcx+0x80]
  4075c5:	sub    rsp,0x8
  4075c9:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  4075ce:	add    rsp,0xf8
  4075d5:	vmovups xmm6,XMMWORD PTR [rsp]
  4075da:	vmovups xmm7,XMMWORD PTR [rsp+0x10]
  4075e0:	vmovups xmm8,XMMWORD PTR [rsp+0x20]
  4075e6:	vmovups xmm9,XMMWORD PTR [rsp+0x30]
  4075ec:	vmovups xmm10,XMMWORD PTR [rsp+0x40]
  4075f2:	vmovups xmm11,XMMWORD PTR [rsp+0x50]
  4075f8:	vmovups xmm12,XMMWORD PTR [rsp+0x60]
  4075fe:	vmovups xmm13,XMMWORD PTR [rsp+0x70]
  407604:	vmovups xmm14,XMMWORD PTR [rsp+0x80]
  40760d:	add    rsp,0x90
  407614:	pop    r12
  407616:	pop    rdi
  407617:	pop    rsi
  407618:	pop    rbp
  407619:	ret
  40761a:	add    BYTE PTR [rax],al
  40761c:	add    BYTE PTR [rax],al
	...

0000000000407620 <__swc_fn_0a4ed24b_000006_81d2e1e9>:
  407620:	sub    rsp,0x8
  407624:	call   411180 <__swc_fn_0a4ed24b_000113_6b799b8d>
  407629:	mov    rcx,rax
  40762c:	test   rax,rax
  40762f:	je     407656 <__swc_fn_0a4ed24b_000006_81d2e1e9+0x36>
  407631:	lea    rdx,[rip+0x1ca28]        # 424060 <__swc_bss_base_0a4ed24b+0x20>
  407638:	mov    r8,QWORD PTR [rip+0x1ca21]        # 424060 <__swc_bss_base_0a4ed24b+0x20>
  40763f:	nop
  407640:	lea    r9,[r8+0x1]
  407644:	mov    rax,r8
  407647:	lock cmpxchg QWORD PTR [rdx],r9
  40764c:	cmp    rax,r8
  40764f:	je     407656 <__swc_fn_0a4ed24b_000006_81d2e1e9+0x36>
  407651:	mov    r8,rax
  407654:	jmp    407640 <__swc_fn_0a4ed24b_000006_81d2e1e9+0x20>
  407656:	mov    rax,rcx
  407659:	add    rsp,0x8
  40765d:	ret
	...

0000000000407660 <__swc_fn_0a4ed24b_000009_065ed5b1>:
  407660:	mov    r8d,edx
  407663:	xor    eax,eax
  407665:	tzcnt  eax,edx
  407669:	shrx   r9d,edx,eax
  40766e:	mov    DWORD PTR [rcx+0x2c],edx
  407671:	xor    eax,eax
  407673:	tzcnt  eax,edx
  407677:	mov    BYTE PTR [rcx+0x38],al
  40767a:	mov    eax,0xffffffff
  40767f:	xor    edx,edx
  407681:	div    r8d
  407684:	mov    DWORD PTR [rcx+0x34],eax
  407687:	mov    eax,r9d
  40768a:	mov    edx,r9d
  40768d:	imul   edx,r9d
  407691:	mov    r8d,0x2
  407697:	sub    r8d,edx
  40769a:	imul   eax,r8d
  40769e:	mov    edx,r9d
  4076a1:	imul   edx,eax
  4076a4:	mov    r8d,0x2
  4076aa:	sub    r8d,edx
  4076ad:	imul   eax,r8d
  4076b1:	mov    edx,r9d
  4076b4:	imul   edx,eax
  4076b7:	mov    r8d,0x2
  4076bd:	sub    r8d,edx
  4076c0:	imul   eax,r8d
  4076c4:	mov    edx,r9d
  4076c7:	imul   edx,eax
  4076ca:	mov    r8d,0x2
  4076d0:	sub    r8d,edx
  4076d3:	imul   eax,r8d
  4076d7:	imul   r9d,eax
  4076db:	mov    edx,0x2
  4076e0:	sub    edx,r9d
  4076e3:	imul   eax,edx
  4076e6:	mov    DWORD PTR [rcx+0x30],eax
  4076e9:	ret
  4076ea:	add    BYTE PTR [rax],al
  4076ec:	add    BYTE PTR [rax],al
	...

00000000004076f0 <__swc_fn_0a4ed24b_000012_861b8b62>:
  4076f0:	xor    eax,eax
  4076f2:	mov    DWORD PTR [rcx+0x68],eax
  4076f5:	ret
	...

0000000000407700 <__swc_fn_0a4ed24b_000015_9dea5065>:
  407700:	mov    eax,DWORD PTR [rcx+0x28]
  407703:	shlx   eax,edx,eax
  407708:	shl    rax,0x10
  40770c:	lea    rdx,[rcx+rax*1]
  407710:	lea    rax,[rcx+0x3000]
  407717:	cmp    rdx,rax
  40771a:	cmovae rax,rdx
  40771e:	ret
	...

0000000000407720 <__swc_fn_0a4ed24b_000018_283e2b5e>:
  407720:	push   rsi
  407721:	push   rdi
  407722:	push   r12
  407724:	push   r13
  407726:	push   r14
  407728:	mov    rsi,rdx
  40772b:	mov    rdi,rcx
  40772e:	rex mov dl,BYTE PTR [rsi+0x3a]
  407732:	mov    ecx,DWORD PTR [rdi+0x28]
  407735:	shr    dl,cl
  407737:	mov    r12d,0x1
  40773d:	mov    ecx,edx
  40773f:	shl    r12,cl
  407742:	mov    r13d,DWORD PTR [rsi+0x3c]
  407746:	rex mov BYTE PTR [rsi+0x3b],0x0
  40774b:	mov    QWORD PTR [rsi+0x40],0x0
  407753:	mov    QWORD PTR [rsi],0x0
  40775a:	mov    rax,QWORD PTR [rsi+0x10]
  40775e:	mov    QWORD PTR [rsi+0x20],rax
  407762:	lea    r14,[rip+0x1c8ff]        # 424068 <__swc_bss_base_0a4ed24b+0x28>
  407769:	mov    rax,QWORD PTR [r14]
  40776c:	shr    rax,0x2
  407770:	mov    rcx,rax
  407773:	cmp    rax,0x800000
  40777a:	mov    eax,0x800000
  40777f:	cmovb  rcx,rax
  407783:	lea    r8,[rip+0x1c8ee]        # 424078 <__swc_bss_base_0a4ed24b+0x38>
  40778a:	mov    rax,QWORD PTR [r8]
  40778d:	mov    r9,rax
  407790:	lea    r10,[r9+r13*1]
  407794:	cmp    r10,rcx
  407797:	ja     4077bb <__swc_fn_0a4ed24b_000018_283e2b5e+0x9b>
  407799:	mov    rax,r9
  40779c:	lock cmpxchg QWORD PTR [r8],r10
  4077a1:	cmp    rax,r9
  4077a4:	je     4077ab <__swc_fn_0a4ed24b_000018_283e2b5e+0x8b>
  4077a6:	mov    r9,rax
  4077a9:	jmp    407790 <__swc_fn_0a4ed24b_000018_283e2b5e+0x70>
  4077ab:	mov    rcx,rdi
  4077ae:	mov    rdx,r12
  4077b1:	call   40f2b0 <__swc_fn_0a4ed24b_000020_de02dbdf>
  4077b6:	jmp    40783d <__swc_fn_0a4ed24b_000018_283e2b5e+0x11d>
  4077bb:	mov    rcx,rdi
  4077be:	movzx  edx,dl
  4077c1:	call   407700 <__swc_fn_0a4ed24b_000015_9dea5065>
  4077c6:	test   r13,r13
  4077c9:	je     407836 <__swc_fn_0a4ed24b_000018_283e2b5e+0x116>
  4077cf:	mov    rcx,rax
  4077d2:	mov    rdx,r13
  4077d5:	call   411300 <__swc_fn_0a4ed24b_000116_e9fc0224>
  4077da:	mov    rcx,QWORD PTR [rip+0x1c887]        # 424068 <__swc_bss_base_0a4ed24b+0x28>
  4077e1:	cs nop WORD PTR [rax+rax*1+0x0]
  4077eb:	nop    DWORD PTR [rax+rax*1+0x0]
  4077f0:	mov    rdx,rcx
  4077f3:	sub    rdx,r13
  4077f6:	mov    rax,rcx
  4077f9:	lock cmpxchg QWORD PTR [r14],rdx
  4077fe:	cmp    rax,rcx
  407801:	je     407808 <__swc_fn_0a4ed24b_000018_283e2b5e+0xe8>
  407803:	mov    rcx,rax
  407806:	jmp    4077f0 <__swc_fn_0a4ed24b_000018_283e2b5e+0xd0>
  407808:	lea    rcx,[rip+0x1c871]        # 424080 <__swc_bss_base_0a4ed24b+0x40>
  40780f:	mov    rdx,QWORD PTR [rip+0x1c86a]        # 424080 <__swc_bss_base_0a4ed24b+0x40>
  407816:	cs nop WORD PTR [rax+rax*1+0x0]
  407820:	lea    r8,[rdx+0x1]
  407824:	mov    rax,rdx
  407827:	lock cmpxchg QWORD PTR [rcx],r8
  40782c:	cmp    rax,rdx
  40782f:	je     407836 <__swc_fn_0a4ed24b_000018_283e2b5e+0x116>
  407831:	mov    rdx,rax
  407834:	jmp    407820 <__swc_fn_0a4ed24b_000018_283e2b5e+0x100>
  407836:	mov    DWORD PTR [rsi+0x3c],0x0
  40783d:	mov    rcx,rdi
  407840:	mov    rdx,r12
  407843:	call   40bf00 <__swc_fn_0a4ed24b_000022_c8f5f27c>
  407848:	pop    r14
  40784a:	pop    r13
  40784c:	pop    r12
  40784e:	pop    rdi
  40784f:	pop    rsi
  407850:	ret
	...

0000000000407860 <__swc_fn_0a4ed24b_000021_fd2b165c>:
  407860:	mov    r8,QWORD PTR [rcx+0x48]
  407864:	test   r8,rdx
  407867:	je     407898 <__swc_fn_0a4ed24b_000021_fd2b165c+0x38>
  407869:	nop    DWORD PTR [rax+0x0]
  407870:	mov    rax,rdx
  407873:	not    rax
  407876:	mov    r9,r8
  407879:	and    r9,rax
  40787c:	mov    rax,r8
  40787f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  407885:	cmp    rax,r8
  407888:	jne    407890 <__swc_fn_0a4ed24b_000021_fd2b165c+0x30>
  40788a:	mov    eax,0x1
  40788f:	ret
  407890:	mov    r8,rax
  407893:	test   rax,rdx
  407896:	jne    407870 <__swc_fn_0a4ed24b_000021_fd2b165c+0x10>
  407898:	xor    eax,eax
  40789a:	ret
  40789b:	add    BYTE PTR [rax],al
  40789d:	add    BYTE PTR [rax],al
	...

00000000004078a0 <__swc_fn_0a4ed24b_000024_2685aade>:
  4078a0:	push   rsi
  4078a1:	push   rdi
  4078a2:	push   r12
  4078a4:	push   r13
  4078a6:	sub    rsp,0x8
  4078aa:	mov    rsi,rdx
  4078ad:	mov    rdi,rcx
  4078b0:	lea    r12,[rip+0x1c959]        # 424210 <__swc_bss_base_0a4ed24b+0x1d0>
  4078b7:	mov    rcx,r12
  4078ba:	call   40e1a0 <__swc_fn_0a4ed24b_000139_86bb0f90>
  4078bf:	xor    eax,eax
  4078c1:	mov    rcx,QWORD PTR [rip+0x1c950]        # 424218 <__swc_bss_base_0a4ed24b+0x1d8>
  4078c8:	mov    r13,rcx
  4078cb:	test   r13,r13
  4078ce:	je     40791b <__swc_fn_0a4ed24b_000024_2685aade+0x7b>
  4078d0:	mov    rcx,QWORD PTR [r13+0x10]
  4078d4:	cmp    DWORD PTR [r13+0x28],esi
  4078d8:	jne    407910 <__swc_fn_0a4ed24b_000024_2685aade+0x70>
  4078da:	test   rax,rax
  4078dd:	jne    4078e8 <__swc_fn_0a4ed24b_000024_2685aade+0x48>
  4078df:	mov    QWORD PTR [rip+0x1c932],rcx        # 424218 <__swc_bss_base_0a4ed24b+0x1d8>
  4078e6:	jmp    4078ec <__swc_fn_0a4ed24b_000024_2685aade+0x4c>
  4078e8:	mov    QWORD PTR [rax+0x10],rcx
  4078ec:	vxorps xmm0,xmm0,xmm0
  4078f0:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  4078f6:	mov    QWORD PTR [r13+0x8],rdi
  4078fa:	mov    rcx,r12
  4078fd:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  407902:	mov    rax,r13
  407905:	add    rsp,0x8
  407909:	pop    r13
  40790b:	pop    r12
  40790d:	pop    rdi
  40790e:	pop    rsi
  40790f:	ret
  407910:	mov    rax,r13
  407913:	mov    r13,rcx
  407916:	test   rcx,rcx
  407919:	jne    4078d0 <__swc_fn_0a4ed24b_000024_2685aade+0x30>
  40791b:	mov    ecx,esi
  40791d:	call   40f2e0 <__swc_fn_0a4ed24b_000023_2d0fcd2c>
  407922:	mov    rsi,rax
  407925:	test   rax,rax
  407928:	jne    40793f <__swc_fn_0a4ed24b_000024_2685aade+0x9f>
  40792a:	mov    rcx,r12
  40792d:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  407932:	xor    eax,eax
  407934:	add    rsp,0x8
  407938:	pop    r13
  40793a:	pop    r12
  40793c:	pop    rdi
  40793d:	pop    rsi
  40793e:	ret
  40793f:	mov    QWORD PTR [rsi+0x8],rdi
  407943:	mov    rcx,r12
  407946:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40794b:	mov    rax,rsi
  40794e:	add    rsp,0x8
  407952:	pop    r13
  407954:	pop    r12
  407956:	pop    rdi
  407957:	pop    rsi
  407958:	ret
  407959:	add    BYTE PTR [rax],al
  40795b:	add    BYTE PTR [rax],al
  40795d:	add    BYTE PTR [rax],al
	...

0000000000407960 <__swc_fn_0a4ed24b_000027_9798fb47>:
  407960:	vxorps xmm0,xmm0,xmm0
  407964:	xor    eax,eax
  407966:	cs nop WORD PTR [rax+rax*1+0x0]
  407970:	cs nop WORD PTR [rax+rax*1+0x0]
  40797a:	nop    WORD PTR [rax+rax*1+0x0]
  407980:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  407985:	add    rax,0x10
  407989:	cmp    rax,0x2b00
  407990:	jne    407980 <__swc_fn_0a4ed24b_000027_9798fb47+0x20>
  407992:	ret
	...

00000000004079a0 <__swc_fn_0a4ed24b_000030_9798fb47>:
  4079a0:	vxorps xmm0,xmm0,xmm0
  4079a4:	vmovups XMMWORD PTR [rcx],xmm0
  4079a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4079ad:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4079b2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4079b7:	ret
	...

00000000004079c0 <__swc_fn_0a4ed24b_000033_9798fb47>:
  4079c0:	vxorps xmm0,xmm0,xmm0
  4079c4:	vmovups XMMWORD PTR [rcx],xmm0
  4079c8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4079cd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4079d2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4079d7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  4079dc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  4079e1:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  4079e6:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  4079eb:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  4079f3:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  4079fb:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  407a03:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  407a0b:	mov    QWORD PTR [rcx+0xc0],0x0
  407a16:	ret
	...

0000000000407a20 <__swc_fn_0a4ed24b_000036_92d9bbff>:
  407a20:	push   rsi
  407a21:	push   rdi
  407a22:	sub    rsp,0x8
  407a26:	mov    rsi,rcx
  407a29:	lea    rdi,[rip+0x1a5d8]        # 422008 <__swc_data_base_0a4ed24b+0x8>
  407a30:	mov    rax,QWORD PTR [rdi]
  407a33:	cmp    rax,0xffffffffffffffff
  407a37:	je     407a3e <__swc_fn_0a4ed24b_000036_92d9bbff+0x1e>
  407a39:	mov    rdi,rax
  407a3c:	jmp    407a6b <__swc_fn_0a4ed24b_000036_92d9bbff+0x4b>
  407a3e:	call   40de80 <__swc_fn_0a4ed24b_000127_58f0f391>
  407a43:	mov    rcx,rax
  407a46:	cmp    rax,0xffffffffffffffff
  407a4a:	je     407a7c <__swc_fn_0a4ed24b_000036_92d9bbff+0x5c>
  407a4c:	mov    rax,0xffffffffffffffff
  407a53:	lock cmpxchg QWORD PTR [rdi],rcx
  407a58:	cmp    rax,0xffffffffffffffff
  407a5c:	je     407a68 <__swc_fn_0a4ed24b_000036_92d9bbff+0x48>
  407a5e:	mov    rdi,rax
  407a61:	call   4116d0 <__swc_fn_0a4ed24b_000128_a481cb88>
  407a66:	jmp    407a6b <__swc_fn_0a4ed24b_000036_92d9bbff+0x4b>
  407a68:	mov    rdi,rcx
  407a6b:	cmp    rdi,0xffffffffffffffff
  407a6f:	je     407a7c <__swc_fn_0a4ed24b_000036_92d9bbff+0x5c>
  407a71:	mov    rcx,rdi
  407a74:	mov    rdx,rsi
  407a77:	call   409b30 <__swc_fn_0a4ed24b_000129_4bbe3f14>
  407a7c:	add    rsp,0x8
  407a80:	pop    rdi
  407a81:	pop    rsi
  407a82:	ret
	...

0000000000407a90 <__swc_fn_0a4ed24b_000039_03f1bf9a>:
  407a90:	sub    rsp,0x38
  407a94:	mov    rax,rdx
  407a97:	test   dl,dl
  407a99:	jne    407ab1 <__swc_fn_0a4ed24b_000039_03f1bf9a+0x21>
  407a9b:	mov    rax,r8
  407a9e:	test   r8b,r8b
  407aa1:	cmove  eax,r9d
  407aa5:	test   al,al
  407aa7:	cmove  eax,r10d
  407aab:	test   al,al
  407aad:	cmove  eax,r11d
  407ab1:	test   al,al
  407ab3:	jne    407aba <__swc_fn_0a4ed24b_000039_03f1bf9a+0x2a>
  407ab5:	add    rsp,0x38
  407ab9:	ret
  407aba:	lea    rcx,[rip+0xb957]        # 413418 <__swc_rdata_base_0a4ed24b+0x308>
  407ac1:	vmovups xmm0,XMMWORD PTR [rip+0xb95f]        # 413428 <__swc_rdata_base_0a4ed24b+0x318>
  407ac9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  407acf:	vmovups xmm0,XMMWORD PTR [rip+0xb961]        # 413438 <__swc_rdata_base_0a4ed24b+0x328>
  407ad7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  407add:	vmovups xmm0,XMMWORD PTR [rip+0xb963]        # 413448 <__swc_rdata_base_0a4ed24b+0x338>
  407ae5:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  407aeb:	lea    rdx,[rsp+0x8]
  407af0:	call   410f00 <__swc_fn_0a4ed24b_000107_90faaa26>
  407af5:	jmp    407ab5 <__swc_fn_0a4ed24b_000039_03f1bf9a+0x25>
	...

0000000000407b00 <__swc_fn_0a4ed24b_000042_facd3e17>:
  407b00:	sub    rsp,0x8
  407b04:	mov    eax,0x1000
  407b09:	test   eax,eax
  407b0b:	mov    r8d,0x8
  407b11:	cmove  eax,r8d
  407b15:	dec    rax
  407b18:	mov    r8,0xffffffffffffffff
  407b1f:	sub    r8,rax
  407b22:	cmp    rdx,r8
  407b25:	ja     407b35 <__swc_fn_0a4ed24b_000042_facd3e17+0x35>
  407b27:	add    rdx,rax
  407b2a:	not    rax
  407b2d:	mov    r8,rdx
  407b30:	and    r8,rax
  407b33:	jne    407b3c <__swc_fn_0a4ed24b_000042_facd3e17+0x3c>
  407b35:	xor    eax,eax
  407b37:	add    rsp,0x8
  407b3b:	ret
  407b3c:	mov    rdx,r8
  407b3f:	call   40f600 <__swc_fn_0a4ed24b_000041_c90d80c1>
  407b44:	add    rsp,0x8
  407b48:	ret
  407b49:	add    BYTE PTR [rax],al
  407b4b:	add    BYTE PTR [rax],al
  407b4d:	add    BYTE PTR [rax],al
	...

0000000000407b50 <__swc_fn_0a4ed24b_000045_d8bd27c3>:
  407b50:	push   rsi
  407b51:	push   rdi
  407b52:	sub    rsp,0x8
  407b56:	mov    rsi,rdx
  407b59:	mov    rdi,rcx
  407b5c:	test   rdx,rdx
  407b5f:	je     407b7b <__swc_fn_0a4ed24b_000045_d8bd27c3+0x2b>
  407b61:	xor    ecx,ecx
  407b63:	call   40c020 <__swc_fn_0a4ed24b_000037_28d0e998>
  407b68:	mov    rax,QWORD PTR [rsi]
  407b6b:	test   rax,rax
  407b6e:	je     407b7b <__swc_fn_0a4ed24b_000045_d8bd27c3+0x2b>
  407b70:	mov    rcx,rax
  407b73:	mov    rdx,rsi
  407b76:	call   40c140 <__swc_fn_0a4ed24b_000046_b30433d0>
  407b7b:	mov    rcx,rdi
  407b7e:	call   40f660 <__swc_fn_0a4ed24b_000044_a78ae66b>
  407b83:	mov    rsi,rax
  407b86:	test   rax,rax
  407b89:	jne    407b94 <__swc_fn_0a4ed24b_000045_d8bd27c3+0x44>
  407b8b:	xor    eax,eax
  407b8d:	add    rsp,0x8
  407b91:	pop    rdi
  407b92:	pop    rsi
  407b93:	ret
  407b94:	mov    rcx,rsi
  407b97:	call   40c020 <__swc_fn_0a4ed24b_000037_28d0e998>
  407b9c:	mov    rax,rsi
  407b9f:	add    rsp,0x8
  407ba3:	pop    rdi
  407ba4:	pop    rsi
  407ba5:	ret
	...

0000000000407bb0 <__swc_fn_0a4ed24b_000048_137687bb>:
  407bb0:	movzx  eax,BYTE PTR [r8+0x39]
  407bb5:	lea    rax,[rax+rax*4]
  407bb9:	lea    rax,[rdx+rax*8+0x28]
  407bbe:	mov    ecx,DWORD PTR [r8+0x6c]
  407bc2:	test   ecx,ecx
  407bc4:	je     407bfd <__swc_fn_0a4ed24b_000048_137687bb+0x4d>
  407bc6:	mov    rcx,QWORD PTR [r8+0x50]
  407bca:	test   rcx,rcx
  407bcd:	je     407bd9 <__swc_fn_0a4ed24b_000048_137687bb+0x29>
  407bcf:	mov    rax,QWORD PTR [r8+0x48]
  407bd3:	mov    QWORD PTR [rcx+0x48],rax
  407bd7:	jmp    407be1 <__swc_fn_0a4ed24b_000048_137687bb+0x31>
  407bd9:	mov    rcx,QWORD PTR [r8+0x48]
  407bdd:	mov    QWORD PTR [rax+0x18],rcx
  407be1:	mov    rax,QWORD PTR [r8+0x48]
  407be5:	test   rax,rax
  407be8:	je     407bf2 <__swc_fn_0a4ed24b_000048_137687bb+0x42>
  407bea:	mov    rcx,QWORD PTR [r8+0x50]
  407bee:	mov    QWORD PTR [rax+0x50],rcx
  407bf2:	vxorps xmm0,xmm0,xmm0
  407bf6:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  407bfc:	ret
  407bfd:	mov    rcx,QWORD PTR [r8+0x50]
  407c01:	test   rcx,rcx
  407c04:	je     407c10 <__swc_fn_0a4ed24b_000048_137687bb+0x60>
  407c06:	mov    rdx,QWORD PTR [r8+0x48]
  407c0a:	mov    QWORD PTR [rcx+0x48],rdx
  407c0e:	jmp    407c18 <__swc_fn_0a4ed24b_000048_137687bb+0x68>
  407c10:	mov    rcx,QWORD PTR [r8+0x48]
  407c14:	mov    QWORD PTR [rax+0x8],rcx
  407c18:	mov    rcx,QWORD PTR [r8+0x48]
  407c1c:	test   rcx,rcx
  407c1f:	je     407c2b <__swc_fn_0a4ed24b_000048_137687bb+0x7b>
  407c21:	mov    rdx,QWORD PTR [r8+0x50]
  407c25:	mov    QWORD PTR [rcx+0x50],rdx
  407c29:	jmp    407c33 <__swc_fn_0a4ed24b_000048_137687bb+0x83>
  407c2b:	mov    rcx,QWORD PTR [r8+0x50]
  407c2f:	mov    QWORD PTR [rax+0x10],rcx
  407c33:	cmp    QWORD PTR [rax],r8
  407c36:	jne    407c3f <__swc_fn_0a4ed24b_000048_137687bb+0x8f>
  407c38:	mov    QWORD PTR [rax],0x0
  407c3f:	vxorps xmm0,xmm0,xmm0
  407c43:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  407c49:	ret
  407c4a:	add    BYTE PTR [rax],al
  407c4c:	add    BYTE PTR [rax],al
	...

0000000000407c50 <__swc_fn_0a4ed24b_000051_e072b516>:
  407c50:	sub    rsp,0x8
  407c54:	mov    r9,r8
  407c57:	mov    r10,rdx
  407c5a:	call   407bb0 <__swc_fn_0a4ed24b_000048_137687bb>
  407c5f:	mov    DWORD PTR [r9+0x6c],0x0
  407c67:	movzx  eax,BYTE PTR [r9+0x39]
  407c6c:	lea    rax,[rax+rax*4]
  407c70:	lea    rax,[r10+rax*8+0x28]
  407c75:	mov    rcx,QWORD PTR [rax+0x10]
  407c79:	mov    QWORD PTR [r9+0x50],rcx
  407c7d:	mov    QWORD PTR [r9+0x48],0x0
  407c85:	mov    rcx,QWORD PTR [rax+0x10]
  407c89:	test   rcx,rcx
  407c8c:	je     407c94 <__swc_fn_0a4ed24b_000051_e072b516+0x44>
  407c8e:	mov    QWORD PTR [rcx+0x48],r9
  407c92:	jmp    407c98 <__swc_fn_0a4ed24b_000051_e072b516+0x48>
  407c94:	mov    QWORD PTR [rax+0x8],r9
  407c98:	mov    QWORD PTR [rax+0x10],r9
  407c9c:	add    rsp,0x8
  407ca0:	ret
	...

0000000000407cc0 <__swc_fn_0a4ed24b_000054_faa92dcc>:
  407cc0:	push   rsi
  407cc1:	push   rdi
  407cc2:	push   r12
  407cc4:	push   r13
  407cc6:	push   r14
  407cc8:	push   r15
  407cca:	sub    rsp,0x1f8
  407cd1:	mov    esi,r8d
  407cd4:	mov    QWORD PTR [rsp+0x1e8],rsi
  407cdc:	mov    rdi,rcx
  407cdf:	mov    r12,rdx
  407ce2:	lea    r13,[rsi+rsi*4]
  407ce6:	lea    r13,[rdx+r13*8+0x28]
  407ceb:	call   40c5a0 <__swc_fn_0a4ed24b_000052_d846b172>
  407cf0:	add    DWORD PTR [r12+0x24],0x1
  407cf6:	test   BYTE PTR [r12+0x24],0x3f
  407cfc:	jne    407d06 <__swc_fn_0a4ed24b_000054_faa92dcc+0x46>
  407cfe:	mov    rcx,rdi
  407d01:	call   40f7e0 <__swc_fn_0a4ed24b_000053_3af34d7f>
  407d06:	mov    rax,QWORD PTR [r13+0x8]
  407d0a:	mov    r14,rax
  407d0d:	nop    DWORD PTR [rax]
  407d10:	test   r14,r14
  407d13:	jne    407d22 <__swc_fn_0a4ed24b_000054_faa92dcc+0x62>
  407d15:	mov    rsi,QWORD PTR [rsp+0x1e8]
  407d1d:	jmp    407e29 <__swc_fn_0a4ed24b_000054_faa92dcc+0x169>
  407d22:	mov    r15,QWORD PTR [r14+0x48]
  407d26:	mov    rcx,r14
  407d29:	call   40bcf0 <__swc_fn_0a4ed24b_000013_e4b0ddfc>
  407d2e:	mov    rax,QWORD PTR [r14]
  407d31:	test   rax,rax
  407d34:	je     407d46 <__swc_fn_0a4ed24b_000054_faa92dcc+0x86>
  407d36:	mov    rcx,QWORD PTR [rax]
  407d39:	mov    QWORD PTR [r14],rcx
  407d3c:	add    DWORD PTR [r14+0x28],0x1
  407d41:	mov    rsi,rax
  407d44:	jmp    407d65 <__swc_fn_0a4ed24b_000054_faa92dcc+0xa5>
  407d46:	mov    rax,QWORD PTR [r14+0x18]
  407d4a:	cmp    QWORD PTR [r14+0x20],rax
  407d4e:	jae    407d63 <__swc_fn_0a4ed24b_000054_faa92dcc+0xa3>
  407d50:	mov    rsi,QWORD PTR [r14+0x20]
  407d54:	mov    eax,DWORD PTR [r14+0x2c]
  407d58:	add    QWORD PTR [r14+0x20],rax
  407d5c:	add    DWORD PTR [r14+0x28],0x1
  407d61:	jmp    407d65 <__swc_fn_0a4ed24b_000054_faa92dcc+0xa5>
  407d63:	xor    esi,esi
  407d65:	test   rsi,rsi
  407d68:	jne    407dad <__swc_fn_0a4ed24b_000054_faa92dcc+0xed>
  407d6a:	mov    rcx,r14
  407d6d:	call   40bc20 <__swc_fn_0a4ed24b_000010_24a20786>
  407d72:	test   al,al
  407d74:	je     407dad <__swc_fn_0a4ed24b_000054_faa92dcc+0xed>
  407d76:	mov    rax,QWORD PTR [r14]
  407d79:	test   rax,rax
  407d7c:	je     407d8b <__swc_fn_0a4ed24b_000054_faa92dcc+0xcb>
  407d7e:	mov    rcx,QWORD PTR [rax]
  407d81:	mov    QWORD PTR [r14],rcx
  407d84:	add    DWORD PTR [r14+0x28],0x1
  407d89:	jmp    407daa <__swc_fn_0a4ed24b_000054_faa92dcc+0xea>
  407d8b:	mov    rax,QWORD PTR [r14+0x18]
  407d8f:	cmp    QWORD PTR [r14+0x20],rax
  407d93:	jae    407da8 <__swc_fn_0a4ed24b_000054_faa92dcc+0xe8>
  407d95:	mov    rax,QWORD PTR [r14+0x20]
  407d99:	mov    ecx,DWORD PTR [r14+0x2c]
  407d9d:	add    QWORD PTR [r14+0x20],rcx
  407da1:	add    DWORD PTR [r14+0x28],0x1
  407da6:	jmp    407daa <__swc_fn_0a4ed24b_000054_faa92dcc+0xea>
  407da8:	xor    eax,eax
  407daa:	mov    rsi,rax
  407dad:	test   rsi,rsi
  407db0:	jne    407e03 <__swc_fn_0a4ed24b_000054_faa92dcc+0x143>
  407db2:	mov    rcx,rdi
  407db5:	mov    rdx,r12
  407db8:	mov    r8,r14
  407dbb:	call   40f740 <__swc_fn_0a4ed24b_000050_129b9bf4>
  407dc0:	test   al,al
  407dc2:	jne    407e03 <__swc_fn_0a4ed24b_000054_faa92dcc+0x143>
  407dc4:	mov    rcx,r14
  407dc7:	call   40bcf0 <__swc_fn_0a4ed24b_000013_e4b0ddfc>
  407dcc:	mov    rax,QWORD PTR [r14]
  407dcf:	test   rax,rax
  407dd2:	je     407de1 <__swc_fn_0a4ed24b_000054_faa92dcc+0x121>
  407dd4:	mov    rcx,QWORD PTR [rax]
  407dd7:	mov    QWORD PTR [r14],rcx
  407dda:	add    DWORD PTR [r14+0x28],0x1
  407ddf:	jmp    407e00 <__swc_fn_0a4ed24b_000054_faa92dcc+0x140>
  407de1:	mov    rax,QWORD PTR [r14+0x18]
  407de5:	cmp    QWORD PTR [r14+0x20],rax
  407de9:	jae    407dfe <__swc_fn_0a4ed24b_000054_faa92dcc+0x13e>
  407deb:	mov    rax,QWORD PTR [r14+0x20]
  407def:	mov    ecx,DWORD PTR [r14+0x2c]
  407df3:	add    QWORD PTR [r14+0x20],rcx
  407df7:	add    DWORD PTR [r14+0x28],0x1
  407dfc:	jmp    407e00 <__swc_fn_0a4ed24b_000054_faa92dcc+0x140>
  407dfe:	xor    eax,eax
  407e00:	mov    rsi,rax
  407e03:	test   rsi,rsi
  407e06:	je     407e21 <__swc_fn_0a4ed24b_000054_faa92dcc+0x161>
  407e08:	mov    QWORD PTR [r13+0x0],r14
  407e0c:	mov    rax,rsi
  407e0f:	add    rsp,0x1f8
  407e16:	pop    r15
  407e18:	pop    r14
  407e1a:	pop    r13
  407e1c:	pop    r12
  407e1e:	pop    rdi
  407e1f:	pop    rsi
  407e20:	ret
  407e21:	mov    r14,r15
  407e24:	jmp    407d10 <__swc_fn_0a4ed24b_000054_faa92dcc+0x50>
  407e29:	cs nop WORD PTR [rax+rax*1+0x0]
  407e33:	cs nop WORD PTR [rax+rax*1+0x0]
  407e3d:	nop    DWORD PTR [rax]
  407e40:	mov    rcx,rdi
  407e43:	mov    rdx,r12
  407e46:	mov    r8d,esi
  407e49:	call   40c2e0 <__swc_fn_0a4ed24b_000049_ad48ec88>
  407e4e:	mov    r14,rax
  407e51:	test   rax,rax
  407e54:	jne    407e6a <__swc_fn_0a4ed24b_000054_faa92dcc+0x1aa>
  407e56:	xor    eax,eax
  407e58:	add    rsp,0x1f8
  407e5f:	pop    r15
  407e61:	pop    r14
  407e63:	pop    r13
  407e65:	pop    r12
  407e67:	pop    rdi
  407e68:	pop    rsi
  407e69:	ret
  407e6a:	mov    QWORD PTR [r13+0x0],r14
  407e6e:	mov    rax,QWORD PTR [r14]
  407e71:	test   rax,rax
  407e74:	je     407e86 <__swc_fn_0a4ed24b_000054_faa92dcc+0x1c6>
  407e76:	mov    rcx,QWORD PTR [rax]
  407e79:	mov    QWORD PTR [r14],rcx
  407e7c:	add    DWORD PTR [r14+0x28],0x1
  407e81:	mov    r15,rax
  407e84:	jmp    407ea6 <__swc_fn_0a4ed24b_000054_faa92dcc+0x1e6>
  407e86:	mov    rax,QWORD PTR [r14+0x18]
  407e8a:	cmp    QWORD PTR [r14+0x20],rax
  407e8e:	jae    407ea3 <__swc_fn_0a4ed24b_000054_faa92dcc+0x1e3>
  407e90:	mov    r15,QWORD PTR [r14+0x20]
  407e94:	mov    eax,DWORD PTR [r14+0x2c]
  407e98:	add    QWORD PTR [r14+0x20],rax
  407e9c:	add    DWORD PTR [r14+0x28],0x1
  407ea1:	jmp    407ea6 <__swc_fn_0a4ed24b_000054_faa92dcc+0x1e6>
  407ea3:	xor    r15d,r15d
  407ea6:	test   r15,r15
  407ea9:	jne    407eee <__swc_fn_0a4ed24b_000054_faa92dcc+0x22e>
  407eab:	mov    rcx,r14
  407eae:	call   40bc20 <__swc_fn_0a4ed24b_000010_24a20786>
  407eb3:	test   al,al
  407eb5:	je     407eee <__swc_fn_0a4ed24b_000054_faa92dcc+0x22e>
  407eb7:	mov    rax,QWORD PTR [r14]
  407eba:	test   rax,rax
  407ebd:	je     407ecc <__swc_fn_0a4ed24b_000054_faa92dcc+0x20c>
  407ebf:	mov    rcx,QWORD PTR [rax]
  407ec2:	mov    QWORD PTR [r14],rcx
  407ec5:	add    DWORD PTR [r14+0x28],0x1
  407eca:	jmp    407eeb <__swc_fn_0a4ed24b_000054_faa92dcc+0x22b>
  407ecc:	mov    rax,QWORD PTR [r14+0x18]
  407ed0:	cmp    QWORD PTR [r14+0x20],rax
  407ed4:	jae    407ee9 <__swc_fn_0a4ed24b_000054_faa92dcc+0x229>
  407ed6:	mov    rax,QWORD PTR [r14+0x20]
  407eda:	mov    ecx,DWORD PTR [r14+0x2c]
  407ede:	add    QWORD PTR [r14+0x20],rcx
  407ee2:	add    DWORD PTR [r14+0x28],0x1
  407ee7:	jmp    407eeb <__swc_fn_0a4ed24b_000054_faa92dcc+0x22b>
  407ee9:	xor    eax,eax
  407eeb:	mov    r15,rax
  407eee:	test   r15,r15
  407ef1:	je     407e40 <__swc_fn_0a4ed24b_000054_faa92dcc+0x180>
  407ef7:	mov    rax,r15
  407efa:	add    rsp,0x1f8
  407f01:	pop    r15
  407f03:	pop    r14
  407f05:	pop    r13
  407f07:	pop    r12
  407f09:	pop    rdi
  407f0a:	pop    rsi
  407f0b:	ret
  407f0c:	add    BYTE PTR [rax],al
	...

0000000000407f10 <__swc_fn_0a4ed24b_000057_7e1dbcb0>:
  407f10:	push   rsi
  407f11:	push   rdi
  407f12:	push   r12
  407f14:	mov    rsi,rdx
  407f17:	mov    rax,rdx
  407f1a:	shr    rax,0xc
  407f1e:	movabs rdx,0x9e3779b97f4a7c15
  407f28:	imul   rax,rdx
  407f2c:	shr    rax,0x20
  407f30:	lea    rax,[rax*8+0x0]
  407f38:	shr    rax,0x20
  407f3c:	lea    rax,[rax*8+0x0]
  407f44:	lea    rax,[rcx+rax*8+0x40]
  407f49:	xor    edx,edx
  407f4b:	test   dl,dl
  407f4d:	lea    rdi,[rcx+0x8]
  407f51:	cmove  rdi,rax
  407f55:	xor    edx,edx
  407f57:	test   dl,dl
  407f59:	lea    r12,[rcx+0x30]
  407f5d:	lea    rax,[rax+0x8]
  407f61:	cmove  r12,rax
  407f65:	mov    rcx,rdi
  407f68:	call   40e1a0 <__swc_fn_0a4ed24b_000139_86bb0f90>
  407f6d:	mov    QWORD PTR [rsi+0x30],0x0
  407f75:	mov    rax,QWORD PTR [r12]
  407f79:	mov    QWORD PTR [rsi+0x38],rax
  407f7d:	test   rax,rax
  407f80:	je     407f8a <__swc_fn_0a4ed24b_000057_7e1dbcb0+0x7a>
  407f82:	mov    rax,QWORD PTR [rsi+0x38]
  407f86:	mov    QWORD PTR [rax+0x30],rsi
  407f8a:	mov    QWORD PTR [r12],rsi
  407f8e:	mov    rcx,rdi
  407f91:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  407f96:	pop    r12
  407f98:	pop    rdi
  407f99:	pop    rsi
  407f9a:	ret
  407f9b:	add    BYTE PTR [rax],al
  407f9d:	add    BYTE PTR [rax],al
	...

0000000000407fa0 <__swc_fn_0a4ed24b_000060_15c28ca7>:
  407fa0:	lea    rax,[rdx+rdx*4]
  407fa4:	lea    rax,[rcx+rax*8+0x268]
  407fac:	mov    rdx,QWORD PTR [rax+0x10]
  407fb0:	sub    QWORD PTR [rcx+0x2a68],rdx
  407fb7:	sub    QWORD PTR [rcx+0x2a70],0x1
  407fbf:	mov    rdx,QWORD PTR [rcx+0x2a70]
  407fc6:	lea    rdx,[rdx+rdx*4]
  407fca:	lea    rdx,[rcx+rdx*8+0x268]
  407fd2:	vmovups xmm0,XMMWORD PTR [rdx]
  407fd6:	vmovups XMMWORD PTR [rax],xmm0
  407fda:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  407fdf:	vmovups XMMWORD PTR [rax+0x10],xmm0
  407fe4:	mov    rcx,QWORD PTR [rdx+0x20]
  407fe8:	mov    QWORD PTR [rax+0x20],rcx
  407fec:	ret
  407fed:	add    BYTE PTR [rax],al
	...

0000000000407ff0 <__swc_fn_0a4ed24b_000063_dea90857>:
  407ff0:	push   rsi
  407ff1:	push   rdi
  407ff2:	push   r12
  407ff4:	push   r13
  407ff6:	sub    rsp,0x8
  407ffa:	mov    rsi,r8
  407ffd:	mov    rdi,rcx
  408000:	mov    r12,rdx
  408003:	xor    r13d,r13d
  408006:	cs nop WORD PTR [rax+rax*1+0x0]
  408010:	mov    eax,DWORD PTR [r12+0x730]
  408018:	cmp    r13d,eax
  40801b:	jae    408081 <__swc_fn_0a4ed24b_000063_dea90857+0x91>
  40801d:	lea    rax,[r13+r13*4+0x0]
  408022:	lea    rax,[r12+rax*8+0x738]
  40802a:	mov    rdx,QWORD PTR [rax]
  40802d:	mov    r8,QWORD PTR [rax+0x8]
  408031:	mov    r9,QWORD PTR [rax+0x10]
  408035:	cmp    QWORD PTR [rax+0x20],rsi
  408039:	jb     408040 <__swc_fn_0a4ed24b_000063_dea90857+0x50>
  40803b:	inc    r13d
  40803e:	jmp    408010 <__swc_fn_0a4ed24b_000063_dea90857+0x20>
  408040:	sub    DWORD PTR [r12+0x730],0x1
  408049:	mov    ecx,DWORD PTR [r12+0x730]
  408051:	lea    rcx,[rcx+rcx*4]
  408055:	lea    rcx,[r12+rcx*8+0x738]
  40805d:	vmovups xmm0,XMMWORD PTR [rcx]
  408061:	vmovups XMMWORD PTR [rax],xmm0
  408065:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40806a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40806f:	mov    rcx,QWORD PTR [rcx+0x20]
  408073:	mov    QWORD PTR [rax+0x20],rcx
  408077:	mov    rcx,rdi
  40807a:	call   40c050 <__swc_fn_0a4ed24b_000043_d3c2ab54>
  40807f:	jmp    408010 <__swc_fn_0a4ed24b_000063_dea90857+0x20>
  408081:	add    rsp,0x8
  408085:	pop    r13
  408087:	pop    r12
  408089:	pop    rdi
  40808a:	pop    rsi
  40808b:	ret
  40808c:	add    BYTE PTR [rax],al
	...

0000000000408090 <__swc_fn_0a4ed24b_000066_de167e8d>:
  408090:	push   rsi
  408091:	push   rdi
  408092:	push   r12
  408094:	push   r13
  408096:	push   r14
  408098:	mov    rsi,rcx
  40809b:	mov    rdi,rdx
  40809e:	mov    r12,QWORD PTR [rdi]
  4080a1:	mov    r13,QWORD PTR [rdi+0x18]
  4080a5:	mov    rax,r12
  4080a8:	add    rax,QWORD PTR [rdi+0x8]
  4080ac:	sub    rax,r13
  4080af:	cmp    r8,rax
  4080b2:	jbe    4080bd <__swc_fn_0a4ed24b_000066_de167e8d+0x2d>
  4080b4:	pop    r14
  4080b6:	pop    r13
  4080b8:	pop    r12
  4080ba:	pop    rdi
  4080bb:	pop    rsi
  4080bc:	ret
  4080bd:	lea    rax,[r13+r8*1+0x0]
  4080c2:	sub    rax,r12
  4080c5:	mov    ecx,0x1000
  4080ca:	test   ecx,ecx
  4080cc:	mov    edx,0x8
  4080d1:	cmove  ecx,edx
  4080d4:	dec    rcx
  4080d7:	mov    rdx,0xffffffffffffffff
  4080de:	sub    rdx,rcx
  4080e1:	cmp    rax,rdx
  4080e4:	jbe    4080eb <__swc_fn_0a4ed24b_000066_de167e8d+0x5b>
  4080e6:	xor    r14d,r14d
  4080e9:	jmp    4080f6 <__swc_fn_0a4ed24b_000066_de167e8d+0x66>
  4080eb:	add    rax,rcx
  4080ee:	andn   rax,rcx,rax
  4080f3:	mov    r14,rax
  4080f6:	mov    rax,QWORD PTR [rdi+0x10]
  4080fa:	cmp    r14,rax
  4080fd:	ja     408108 <__swc_fn_0a4ed24b_000066_de167e8d+0x78>
  4080ff:	pop    r14
  408101:	pop    r13
  408103:	pop    r12
  408105:	pop    rdi
  408106:	pop    rsi
  408107:	ret
  408108:	mov    rax,r12
  40810b:	add    rax,QWORD PTR [rdi+0x10]
  40810f:	mov    rdx,r14
  408112:	sub    rdx,QWORD PTR [rdi+0x10]
  408116:	mov    rcx,rax
  408119:	call   40bba0 <__swc_fn_0a4ed24b_000007_f7acedb0>
  40811e:	test   al,al
  408120:	jne    40812b <__swc_fn_0a4ed24b_000066_de167e8d+0x9b>
  408122:	pop    r14
  408124:	pop    r13
  408126:	pop    r12
  408128:	pop    rdi
  408129:	pop    rsi
  40812a:	ret
  40812b:	add    r12,r14
  40812e:	sub    r12,r13
  408131:	mov    rcx,r12
  408134:	sub    rcx,QWORD PTR [rdi+0x28]
  408138:	mov    rdx,QWORD PTR [rsi+0x250]
  40813f:	nop
  408140:	lea    r8,[rdx+rcx*1]
  408144:	mov    rax,rdx
  408147:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  408150:	cmp    rax,rdx
  408153:	je     40815a <__swc_fn_0a4ed24b_000066_de167e8d+0xca>
  408155:	mov    rdx,rax
  408158:	jmp    408140 <__swc_fn_0a4ed24b_000066_de167e8d+0xb0>
  40815a:	mov    QWORD PTR [rdi+0x10],r14
  40815e:	mov    QWORD PTR [rdi+0x28],r12
  408162:	pop    r14
  408164:	pop    r13
  408166:	pop    r12
  408168:	pop    rdi
  408169:	pop    rsi
  40816a:	ret
  40816b:	add    BYTE PTR [rax],al
  40816d:	add    BYTE PTR [rax],al
	...

0000000000408170 <__swc_fn_0a4ed24b_000069_7130736e>:
  408170:	push   rbx
  408171:	push   rsi
  408172:	push   rdi
  408173:	push   r12
  408175:	push   r13
  408177:	sub    rsp,0xe0
  40817e:	mov    rbx,rdx
  408181:	mov    rsi,rcx
  408184:	cmp    DWORD PTR [rbx+0x58],0x0
  408188:	je     4081ac <__swc_fn_0a4ed24b_000069_7130736e+0x3c>
  40818a:	mov    eax,DWORD PTR [rbx+0x58]
  40818d:	sub    eax,0x1
  408190:	test   DWORD PTR [rbx+0x58],eax
  408193:	je     4081ac <__swc_fn_0a4ed24b_000069_7130736e+0x3c>
  408195:	mov    QWORD PTR [rbx+0x40],0x0
  40819d:	add    rsp,0xe0
  4081a4:	pop    r13
  4081a6:	pop    r12
  4081a8:	pop    rdi
  4081a9:	pop    rsi
  4081aa:	pop    rbx
  4081ab:	ret
  4081ac:	mov    rax,QWORD PTR [rbx+0x40]
  4081b0:	test   rax,rax
  4081b3:	jne    4081cf <__swc_fn_0a4ed24b_000069_7130736e+0x5f>
  4081b5:	mov    rcx,rsi
  4081b8:	mov    rdx,rbx
  4081bb:	call   4103f0 <__swc_fn_0a4ed24b_000068_f3aa21af>
  4081c0:	add    rsp,0xe0
  4081c7:	pop    r13
  4081c9:	pop    r12
  4081cb:	pop    rdi
  4081cc:	pop    rsi
  4081cd:	pop    rbx
  4081ce:	ret
  4081cf:	cmp    QWORD PTR [rbx+0x48],0x0
  4081d4:	jne    4081f0 <__swc_fn_0a4ed24b_000069_7130736e+0x80>
  4081d6:	mov    rcx,rsi
  4081d9:	mov    rdx,rbx
  4081dc:	call   40c890 <__swc_fn_0a4ed24b_000070_97813b89>
  4081e1:	add    rsp,0xe0
  4081e8:	pop    r13
  4081ea:	pop    r12
  4081ec:	pop    rdi
  4081ed:	pop    rsi
  4081ee:	pop    rbx
  4081ef:	ret
  4081f0:	mov    rdi,QWORD PTR [rbx+0x40]
  4081f4:	lea    rax,[rip+0x1be95]        # 424090 <__swc_bss_base_0a4ed24b+0x50>
  4081fb:	mov    rcx,rdi
  4081fe:	sub    rcx,QWORD PTR [rax+0x8]
  408202:	mov    rax,QWORD PTR [rip+0x1be97]        # 4240a0 <__swc_bss_base_0a4ed24b+0x60>
  408209:	cmp    rcx,rax
  40820c:	jae    408238 <__swc_fn_0a4ed24b_000069_7130736e+0xc8>
  40820e:	mov    rax,rdi
  408211:	and    rax,0xffffffffffc00000
  408218:	mov    rcx,rdi
  40821b:	shr    rcx,0x10
  40821f:	and    ecx,0x3f
  408222:	mov    edx,DWORD PTR [rax+0x28]
  408225:	shrx   ecx,ecx,edx
  40822a:	shl    rcx,0x4
  40822e:	lea    r12,[rax+rcx*8+0x80]
  408236:	jmp    408243 <__swc_fn_0a4ed24b_000069_7130736e+0xd3>
  408238:	mov    rcx,rdi
  40823b:	call   40f470 <__swc_fn_0a4ed24b_000026_bcdc5519>
  408240:	mov    r12,rax
  408243:	test   r12,r12
  408246:	je     408255 <__swc_fn_0a4ed24b_000069_7130736e+0xe5>
  408248:	mov    eax,DWORD PTR [r12+0x2c]
  40824d:	mov    r9d,eax
  408250:	mov    r13,rax
  408253:	jmp    4082d4 <__swc_fn_0a4ed24b_000069_7130736e+0x164>
  408255:	mov    rcx,rsi
  408258:	mov    rdx,rdi
  40825b:	call   40fa80 <__swc_fn_0a4ed24b_000056_df0696cd>
  408260:	mov    rcx,QWORD PTR [rax+0x28]
  408264:	mov    r9,rcx
  408267:	mov    rdx,QWORD PTR [rax+0x20]
  40826b:	mov    r13,rdx
  40826e:	cmp    QWORD PTR [rbx+0x48],rcx
  408272:	jbe    4082ab <__swc_fn_0a4ed24b_000069_7130736e+0x13b>
  408274:	mov    ecx,DWORD PTR [rax+0x48]
  408277:	cmp    DWORD PTR [rbx+0x58],ecx
  40827a:	ja     4082ab <__swc_fn_0a4ed24b_000069_7130736e+0x13b>
  40827c:	mov    rcx,rsi
  40827f:	mov    rdx,rax
  408282:	mov    r8,QWORD PTR [rbx+0x48]
  408286:	mov    QWORD PTR [rsp+0xc8],r9
  40828e:	mov    QWORD PTR [rsp+0xd0],rax
  408296:	call   408090 <__swc_fn_0a4ed24b_000066_de167e8d>
  40829b:	mov    r9,QWORD PTR [rsp+0xc8]
  4082a3:	mov    rax,QWORD PTR [rsp+0xd0]
  4082ab:	mov    rcx,QWORD PTR [rax+0x28]
  4082af:	cmp    QWORD PTR [rbx+0x48],rcx
  4082b3:	ja     4082d4 <__swc_fn_0a4ed24b_000069_7130736e+0x164>
  4082b5:	mov    ecx,DWORD PTR [rax+0x48]
  4082b8:	cmp    DWORD PTR [rbx+0x58],ecx
  4082bb:	ja     4082d4 <__swc_fn_0a4ed24b_000069_7130736e+0x164>
  4082bd:	mov    rcx,QWORD PTR [rbx+0x48]
  4082c1:	mov    QWORD PTR [rax+0x20],rcx
  4082c5:	add    rsp,0xe0
  4082cc:	pop    r13
  4082ce:	pop    r12
  4082d0:	pop    rdi
  4082d1:	pop    rsi
  4082d2:	pop    rbx
  4082d3:	ret
  4082d4:	test   r12,r12
  4082d7:	je     408309 <__swc_fn_0a4ed24b_000069_7130736e+0x199>
  4082d9:	cmp    QWORD PTR [rbx+0x48],r9
  4082dd:	ja     408309 <__swc_fn_0a4ed24b_000069_7130736e+0x199>
  4082df:	cmp    DWORD PTR [rbx+0x58],0x40
  4082e3:	ja     408309 <__swc_fn_0a4ed24b_000069_7130736e+0x199>
  4082e5:	cmp    DWORD PTR [rbx+0x58],0x0
  4082e9:	je     4082f6 <__swc_fn_0a4ed24b_000069_7130736e+0x186>
  4082eb:	mov    ecx,DWORD PTR [rbx+0x58]
  4082ee:	dec    rcx
  4082f1:	test   rdi,rcx
  4082f4:	jne    408309 <__swc_fn_0a4ed24b_000069_7130736e+0x199>
  4082f6:	mov    QWORD PTR [rbx+0x40],rdi
  4082fa:	add    rsp,0xe0
  408301:	pop    r13
  408303:	pop    r12
  408305:	pop    rdi
  408306:	pop    rsi
  408307:	pop    rbx
  408308:	ret
  408309:	vmovups xmm0,XMMWORD PTR [rbx]
  40830d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  408313:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  408318:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40831e:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  408323:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  408329:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40832e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  408334:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  408339:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40833f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  408344:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40834a:	mov    QWORD PTR [rsp+0x48],0x0
  408353:	mov    rcx,rsi
  408356:	lea    rdx,[rsp+0x8]
  40835b:	call   4103f0 <__swc_fn_0a4ed24b_000068_f3aa21af>
  408360:	mov    rax,QWORD PTR [rsp+0x48]
  408365:	test   rax,rax
  408368:	jne    408381 <__swc_fn_0a4ed24b_000069_7130736e+0x211>
  40836a:	mov    QWORD PTR [rbx+0x40],0x0
  408372:	add    rsp,0xe0
  408379:	pop    r13
  40837b:	pop    r12
  40837d:	pop    rdi
  40837e:	pop    rsi
  40837f:	pop    rbx
  408380:	ret
  408381:	mov    rax,QWORD PTR [rbx+0x48]
  408385:	cmp    r13,rax
  408388:	cmovbe rax,r13
  40838c:	mov    rcx,QWORD PTR [rsp+0x48]
  408391:	mov    rdx,rdi
  408394:	mov    r8,rax
  408397:	call   40d9e0 <__swc_fn_0a4ed24b_000109_7c204aac>
  40839c:	vmovups xmm0,XMMWORD PTR [rbx]
  4083a0:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  4083a6:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  4083ab:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4083b1:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  4083b6:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4083bf:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  4083c4:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4083cd:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  4083d2:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4083db:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  4083e0:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4083e9:	mov    QWORD PTR [rsp+0xa8],rdi
  4083f1:	mov    rcx,rsi
  4083f4:	lea    rdx,[rsp+0x68]
  4083f9:	call   40c890 <__swc_fn_0a4ed24b_000070_97813b89>
  4083fe:	mov    rax,QWORD PTR [rsp+0x48]
  408403:	mov    QWORD PTR [rbx+0x40],rax
  408407:	add    rsp,0xe0
  40840e:	pop    r13
  408410:	pop    r12
  408412:	pop    rdi
  408413:	pop    rsi
  408414:	pop    rbx
  408415:	ret
	...

0000000000408420 <__swc_fn_0a4ed24b_000072_61e60aab>:
  408420:	push   r12
  408422:	push   rdi
  408423:	push   rsi
  408424:	push   r13
  408426:	push   r14
  408428:	sub    rsp,0x190
  40842f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  408438:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  408441:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40844a:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  408453:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40845c:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  408465:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40846e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  408477:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  408480:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  408489:	mov    r12,rcx
  40848c:	lea    rax,[rip+0x19b75]        # 422008 <__swc_data_base_0a4ed24b+0x8>
  408493:	mov    rax,QWORD PTR [rax]
  408496:	cmp    rax,0xffffffffffffffff
  40849a:	je     4084a9 <__swc_fn_0a4ed24b_000072_61e60aab+0x89>
  40849c:	mov    eax,eax
  40849e:	mov    edi,eax
  4084a0:	xor    eax,eax
  4084a2:	call   407010 <pthread_getspecific@plt>
  4084a7:	jmp    4084ab <__swc_fn_0a4ed24b_000072_61e60aab+0x8b>
  4084a9:	xor    eax,eax
  4084ab:	test   rax,rax
  4084ae:	jne    4084bd <__swc_fn_0a4ed24b_000072_61e60aab+0x9d>
  4084b0:	call   40f540 <__swc_fn_0a4ed24b_000035_cd1a4e8c>
  4084b5:	mov    rcx,rax
  4084b8:	call   409be0 <__swc_fn_0a4ed24b_000132_5f757033>
  4084bd:	test   rax,rax
  4084c0:	je     4084e6 <__swc_fn_0a4ed24b_000072_61e60aab+0xc6>
  4084c2:	cmp    QWORD PTR [rax],r12
  4084c5:	jne    4084e6 <__swc_fn_0a4ed24b_000072_61e60aab+0xc6>
  4084c7:	xor    ecx,ecx
  4084c9:	mov    QWORD PTR [rsp+0xc8],rax
  4084d1:	call   40c020 <__swc_fn_0a4ed24b_000037_28d0e998>
  4084d6:	mov    rdx,QWORD PTR [rsp+0xc8]
  4084de:	mov    rcx,r12
  4084e1:	call   40c140 <__swc_fn_0a4ed24b_000046_b30433d0>
  4084e6:	lea    rsi,[r12+0x10]
  4084eb:	mov    rcx,rsi
  4084ee:	call   40e1a0 <__swc_fn_0a4ed24b_000139_86bb0f90>
  4084f3:	mov    rdi,QWORD PTR [r12+0x20]
  4084f8:	test   rdi,rdi
  4084fb:	je     40853e <__swc_fn_0a4ed24b_000072_61e60aab+0x11e>
  4084fd:	nop    DWORD PTR [rax]
  408500:	mov    rcx,r12
  408503:	mov    rdx,rdi
  408506:	call   40f700 <__swc_fn_0a4ed24b_000047_6e7a8d58>
  40850b:	mov    rcx,r12
  40850e:	mov    rdx,rdi
  408511:	mov    r8,0xffffffffffffffff
  408518:	call   407ff0 <__swc_fn_0a4ed24b_000063_dea90857>
  40851d:	mov    rcx,r12
  408520:	mov    rdx,rdi
  408523:	mov    r8d,0x9b8
  408529:	mov    r9d,0x9b8
  40852f:	call   40c050 <__swc_fn_0a4ed24b_000043_d3c2ab54>
  408534:	mov    rdi,QWORD PTR [r12+0x20]
  408539:	test   rdi,rdi
  40853c:	jne    408500 <__swc_fn_0a4ed24b_000072_61e60aab+0xe0>
  40853e:	xor    eax,eax
  408540:	xchg   QWORD PTR [r12+0x2a80],rax
  408548:	test   rax,rax
  40854b:	je     408571 <__swc_fn_0a4ed24b_000072_61e60aab+0x151>
  40854d:	cs nop WORD PTR [rax+rax*1+0x0]
  408557:	nop    WORD PTR [rax+rax*1+0x0]
  408560:	mov    rcx,rax
  408563:	mov    rax,QWORD PTR [rax+0x78]
  408567:	xor    edx,edx
  408569:	xchg   DWORD PTR [rcx+0x70],edx
  40856c:	test   rax,rax
  40856f:	jne    408560 <__swc_fn_0a4ed24b_000072_61e60aab+0x140>
  408571:	mov    rax,QWORD PTR [r12+0x18]
  408576:	mov    rdi,rax
  408579:	test   rdi,rdi
  40857c:	je     408611 <__swc_fn_0a4ed24b_000072_61e60aab+0x1f1>
  408582:	cs nop WORD PTR [rax+rax*1+0x0]
  40858c:	nop    DWORD PTR [rax+0x0]
  408590:	mov    rax,QWORD PTR [rdi+0x10]
  408594:	mov    r8d,DWORD PTR [rdi+0x2c]
  408598:	xor    r9d,r9d
  40859b:	test   r8,r8
  40859e:	jbe    4085fd <__swc_fn_0a4ed24b_000072_61e60aab+0x1dd>
  4085a0:	mov    ecx,r9d
  4085a3:	shl    rcx,0x4
  4085a7:	lea    rdx,[rdi+rcx*8+0x80]
  4085af:	cmp    BYTE PTR [rdx+0x3b],0x0
  4085b3:	je     4085f4 <__swc_fn_0a4ed24b_000072_61e60aab+0x1d4>
  4085b5:	mov    DWORD PTR [rdx+0x28],0x0
  4085bc:	mov    rcx,rdi
  4085bf:	mov    QWORD PTR [rsp+0xd0],rax
  4085c7:	mov    QWORD PTR [rsp+0xd8],r8
  4085cf:	mov    QWORD PTR [rsp+0xe0],r9
  4085d7:	call   407720 <__swc_fn_0a4ed24b_000018_283e2b5e>
  4085dc:	mov    rax,QWORD PTR [rsp+0xd0]
  4085e4:	mov    r8,QWORD PTR [rsp+0xd8]
  4085ec:	mov    r9,QWORD PTR [rsp+0xe0]
  4085f4:	add    r9,0x1
  4085f8:	cmp    r9,r8
  4085fb:	jb     4085a0 <__swc_fn_0a4ed24b_000072_61e60aab+0x180>
  4085fd:	mov    rcx,rdi
  408600:	mov    rdi,rax
  408603:	call   40bf30 <__swc_fn_0a4ed24b_000025_aa910677>
  408608:	test   rdi,rdi
  40860b:	jne    408590 <__swc_fn_0a4ed24b_000072_61e60aab+0x170>
  408611:	mov    QWORD PTR [r12+0x18],0x0
  40861a:	mov    QWORD PTR [r12+0x28],0x0
  408623:	mov    rcx,rsi
  408626:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40862b:	mov    esi,0x8
  408630:	xor    edi,edi
  408632:	test   rsi,rsi
  408635:	je     408692 <__swc_fn_0a4ed24b_000072_61e60aab+0x272>
  40863b:	nop    DWORD PTR [rax+rax*1+0x0]
  408640:	lea    r13,[rdi*8+0x0]
  408648:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40864d:	test   r14,r14
  408650:	je     408688 <__swc_fn_0a4ed24b_000072_61e60aab+0x268>
  408652:	cs nop WORD PTR [rax+rax*1+0x0]
  40865c:	nop    DWORD PTR [rax+0x0]
  408660:	mov    rcx,r12
  408663:	mov    rdx,r14
  408666:	call   40c6f0 <__swc_fn_0a4ed24b_000058_1bb23e77>
  40866b:	mov    rcx,r12
  40866e:	mov    rdx,QWORD PTR [r14]
  408671:	mov    r8,QWORD PTR [r14+0x8]
  408675:	mov    r9,QWORD PTR [r14+0x10]
  408679:	call   40c050 <__swc_fn_0a4ed24b_000043_d3c2ab54>
  40867e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  408683:	test   r14,r14
  408686:	jne    408660 <__swc_fn_0a4ed24b_000072_61e60aab+0x240>
  408688:	add    rdi,0x1
  40868c:	sub    rsi,0x1
  408690:	jne    408640 <__swc_fn_0a4ed24b_000072_61e60aab+0x220>
  408692:	mov    rcx,r12
  408695:	call   40c7c0 <__swc_fn_0a4ed24b_000064_ffcd96eb>
  40869a:	lea    rcx,[r12+0x250]
  4086a2:	mov    rdx,QWORD PTR [rcx]
  4086a5:	mov    r8,QWORD PTR [r12+0x250]
  4086ad:	nop    DWORD PTR [rax]
  4086b0:	mov    r9,r8
  4086b3:	sub    r9,rdx
  4086b6:	mov    rax,r8
  4086b9:	lock cmpxchg QWORD PTR [rcx],r9
  4086be:	cmp    rax,r8
  4086c1:	je     4086c8 <__swc_fn_0a4ed24b_000072_61e60aab+0x2a8>
  4086c3:	mov    r8,rax
  4086c6:	jmp    4086b0 <__swc_fn_0a4ed24b_000072_61e60aab+0x290>
  4086c8:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  4086d1:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  4086da:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  4086e3:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  4086ec:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  4086f5:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  4086fe:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  408707:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  408710:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  408719:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  408722:	add    rsp,0x190
  408729:	pop    r14
  40872b:	pop    r13
  40872d:	pop    rsi
  40872e:	pop    rdi
  40872f:	pop    r12
  408731:	ret
	...

0000000000408740 <__swc_fn_0a4ed24b_000075_64d36d78>:
  408740:	sub    rsp,0x8
  408744:	mov    QWORD PTR [rdx+0x40],0x0
  40874c:	call   4103f0 <__swc_fn_0a4ed24b_000068_f3aa21af>
  408751:	add    rsp,0x8
  408755:	ret
	...

0000000000408760 <__swc_fn_0a4ed24b_000078_1966ae2e>:
  408760:	sub    rsp,0x8
  408764:	call   40c890 <__swc_fn_0a4ed24b_000070_97813b89>
  408769:	add    rsp,0x8
  40876d:	ret
	...

0000000000408770 <__swc_fn_0a4ed24b_000081_5cc7acfc>:
  408770:	push   rbx
  408771:	push   rsi
  408772:	push   rdi
  408773:	push   r12
  408775:	push   r13
  408777:	push   r14
  408779:	push   r15
  40877b:	sub    rsp,0x20
  40877f:	mov    rbx,r11
  408782:	mov    rsi,rcx
  408785:	mov    rdi,rdx
  408788:	mov    r12,r8
  40878b:	mov    r13,r9
  40878e:	mov    r14,r10
  408791:	mov    rcx,QWORD PTR [rip+0x1e5a8]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  408798:	test   rcx,rcx
  40879b:	jne    4087ad <__swc_fn_0a4ed24b_000081_5cc7acfc+0x3d>
  40879d:	call   40eaa0 <__swc_fn_0a4ed24b_000169_994c8876>
  4087a2:	lea    rcx,[rax+0x1]
  4087a6:	mov    QWORD PTR [rip+0x1e593],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  4087ad:	dec    rcx
  4087b0:	call   40b660 <__swc_fn_0a4ed24b_000171_360af05d>
  4087b5:	mov    r15,rax
  4087b8:	lea    r11,[rip+0x1ba81]        # 424240 <__swc_bss_base_0a4ed24b+0x200>
  4087bf:	mov    rcx,r11
  4087c2:	call   40c040 <__swc_fn_0a4ed24b_000040_eb6108f2>
  4087c7:	test   al,al
  4087c9:	jne    4087da <__swc_fn_0a4ed24b_000081_5cc7acfc+0x6a>
  4087cb:	mov    rcx,r11
  4087ce:	call   40f5a0 <__swc_fn_0a4ed24b_000038_14f56618>
  4087d3:	lea    r11,[rip+0x1ba66]        # 424240 <__swc_bss_base_0a4ed24b+0x200>
  4087da:	mov    rcx,r11
  4087dd:	mov    rdx,rsi
  4087e0:	mov    r8,rdi
  4087e3:	mov    r9,r12
  4087e6:	mov    r10,r13
  4087e9:	mov    rsi,r11
  4087ec:	mov    r11,r14
  4087ef:	call   407a90 <__swc_fn_0a4ed24b_000039_03f1bf9a>
  4087f4:	test   bl,bl
  4087f6:	je     40881d <__swc_fn_0a4ed24b_000081_5cc7acfc+0xad>
  4087f8:	mov    QWORD PTR [rsp+0x8],rsi
  4087fd:	lea    rax,[rip+0xac54]        # 413458 <__swc_rdata_base_0a4ed24b+0x348>
  408804:	mov    QWORD PTR [rsp+0x10],rax
  408809:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40880f:	vmovups XMMWORD PTR [r15],xmm0
  408814:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40881d:	mov    rax,rsi
  408820:	add    rsp,0x20
  408824:	pop    r15
  408826:	pop    r14
  408828:	pop    r13
  40882a:	pop    r12
  40882c:	pop    rdi
  40882d:	pop    rsi
  40882e:	pop    rbx
  40882f:	ret

0000000000408830 <__swc_fn_0a4ed24b_000084_cf82995a>:
  408830:	sub    rsp,0x8
  408834:	mov    rax,rcx
  408837:	test   rcx,rcx
  40883a:	jne    408841 <__swc_fn_0a4ed24b_000084_cf82995a+0x11>
  40883c:	add    rsp,0x8
  408840:	ret
  408841:	lea    rcx,[rax-0x10]
  408845:	mov    rax,QWORD PTR [rax-0x10]
  408849:	mov    rdx,rax
  40884c:	call   409890 <__swc_fn_0a4ed24b_000117_ed2d8fed>
  408851:	add    rsp,0x8
  408855:	ret
	...

0000000000408860 <__swc_fn_0a4ed24b_000087_ef55f6e4>:
  408860:	sub    rsp,0x8
  408864:	xor    r11d,r11d
  408867:	call   40cb50 <__swc_fn_0a4ed24b_000088_0d280354>
  40886c:	add    rsp,0x8
  408870:	ret
	...

0000000000408880 <__swc_fn_0a4ed24b_000090_23214800>:
  408880:	push   rsi
  408881:	push   rdi
  408882:	push   r12
  408884:	push   r13
  408886:	push   r14
  408888:	push   r15
  40888a:	sub    rsp,0x68
  40888e:	mov    rsi,r9
  408891:	mov    rdi,rcx
  408894:	mov    r12,rdx
  408897:	mov    r13,r8
  40889a:	cmp    r8,r9
  40889d:	jne    4088c5 <__swc_fn_0a4ed24b_000090_23214800+0x45>
  40889f:	mov    rcx,rdi
  4088a2:	mov    rdx,r12
  4088a5:	xor    r8d,r8d
  4088a8:	call   40cea0 <__swc_fn_0a4ed24b_000094_63c1827b>
  4088ad:	test   al,al
  4088af:	je     4088c5 <__swc_fn_0a4ed24b_000090_23214800+0x45>
  4088b1:	mov    eax,0x1
  4088b6:	add    rsp,0x68
  4088ba:	pop    r15
  4088bc:	pop    r14
  4088be:	pop    r13
  4088c0:	pop    r12
  4088c2:	pop    rdi
  4088c3:	pop    rsi
  4088c4:	ret
  4088c5:	cmp    BYTE PTR [r12+0x2c],0xe
  4088cb:	je     4088de <__swc_fn_0a4ed24b_000090_23214800+0x5e>
  4088cd:	xor    eax,eax
  4088cf:	add    rsp,0x68
  4088d3:	pop    r15
  4088d5:	pop    r14
  4088d7:	pop    r13
  4088d9:	pop    r12
  4088db:	pop    rdi
  4088dc:	pop    rsi
  4088dd:	ret
  4088de:	mov    r14,QWORD PTR [r12+0x98]
  4088e6:	mov    rax,QWORD PTR [r12+0xa0]
  4088ee:	mov    r12,rax
  4088f1:	xor    r15d,r15d
  4088f4:	test   r12,r12
  4088f7:	je     40895f <__swc_fn_0a4ed24b_000090_23214800+0xdf>
  4088f9:	nop    DWORD PTR [rax+0x0]
  408900:	mov    QWORD PTR [rsp+0x58],r12
  408905:	lea    r12,[r15*8+0x0]
  40890d:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  408912:	mov    rcx,rax
  408915:	call   410b80 <__swc_fn_0a4ed24b_000086_3953ef98>
  40891a:	cmp    BYTE PTR [rax+0x2c],0xe
  40891e:	jne    408950 <__swc_fn_0a4ed24b_000090_23214800+0xd0>
  408920:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  408925:	lea    r8,[r13+rcx*1+0x0]
  40892a:	mov    rcx,rdi
  40892d:	mov    rdx,rax
  408930:	mov    r9,rsi
  408933:	call   408880 <__swc_fn_0a4ed24b_000090_23214800>
  408938:	test   al,al
  40893a:	je     408950 <__swc_fn_0a4ed24b_000090_23214800+0xd0>
  40893c:	mov    eax,0x1
  408941:	add    rsp,0x68
  408945:	pop    r15
  408947:	pop    r14
  408949:	pop    r13
  40894b:	pop    r12
  40894d:	pop    rdi
  40894e:	pop    rsi
  40894f:	ret
  408950:	add    r15,0x1
  408954:	mov    r12,QWORD PTR [rsp+0x58]
  408959:	sub    r12,0x1
  40895d:	jne    408900 <__swc_fn_0a4ed24b_000090_23214800+0x80>
  40895f:	xor    eax,eax
  408961:	add    rsp,0x68
  408965:	pop    r15
  408967:	pop    r14
  408969:	pop    r13
  40896b:	pop    r12
  40896d:	pop    rdi
  40896e:	pop    rsi
  40896f:	ret

0000000000408970 <__swc_fn_0a4ed24b_000093_c2567a3b>:
  408970:	push   rbp
  408971:	push   rbx
  408972:	push   rsi
  408973:	push   rdi
  408974:	push   r12
  408976:	push   r13
  408978:	push   r14
  40897a:	push   r15
  40897c:	sub    rsp,0x38
  408980:	mov    rbp,rsp
  408983:	mov    rbx,r11
  408986:	mov    rsi,rdx
  408989:	mov    rdi,r8
  40898c:	mov    r12,r9
  40898f:	mov    QWORD PTR [rsp+0x18],r9
  408994:	mov    r13,r10
  408997:	movzx  r14d,BYTE PTR [rbp+0x80]
  40899f:	movzx  r15d,BYTE PTR [rbp+0x88]
  4089a7:	test   r11,r11
  4089aa:	je     4089b0 <__swc_fn_0a4ed24b_000093_c2567a3b+0x40>
  4089ac:	xor    eax,eax
  4089ae:	mov    BYTE PTR [rbx],al
  4089b0:	test   r12,r12
  4089b3:	je     4089be <__swc_fn_0a4ed24b_000093_c2567a3b+0x4e>
  4089b5:	mov    QWORD PTR [r12+0x8],0x0
  4089be:	test   rcx,rcx
  4089c1:	je     4089c8 <__swc_fn_0a4ed24b_000093_c2567a3b+0x58>
  4089c3:	test   rsi,rsi
  4089c6:	jne    4089db <__swc_fn_0a4ed24b_000093_c2567a3b+0x6b>
  4089c8:	xor    eax,eax
  4089ca:	add    rsp,0x38
  4089ce:	pop    r15
  4089d0:	pop    r14
  4089d2:	pop    r13
  4089d4:	pop    r12
  4089d6:	pop    rdi
  4089d7:	pop    rsi
  4089d8:	pop    rbx
  4089d9:	pop    rbp
  4089da:	ret
  4089db:	call   410b80 <__swc_fn_0a4ed24b_000086_3953ef98>
  4089e0:	mov    r12,rax
  4089e3:	mov    al,r15b
  4089e6:	test   r15b,r15b
  4089e9:	jne    4089f9 <__swc_fn_0a4ed24b_000093_c2567a3b+0x89>
  4089eb:	mov    eax,DWORD PTR [r12+0x28]
  4089f0:	and    eax,0x10000
  4089f6:	setne  al
  4089f9:	lea    r15,[rsp+0x8]
  4089fe:	mov    QWORD PTR [rsp+0x20],r15
  408a03:	rex mov BYTE PTR [rsp+0x8],al
  408a08:	test   DWORD PTR [rsi+0x28],0x400000
  408a0f:	je     408a47 <__swc_fn_0a4ed24b_000093_c2567a3b+0xd7>
  408a11:	test   rsi,rsi
  408a14:	je     408a34 <__swc_fn_0a4ed24b_000093_c2567a3b+0xc4>
  408a16:	mov    rax,QWORD PTR [rsi+0x38]
  408a1a:	cmp    QWORD PTR [rax+0x10],rsi
  408a1e:	jne    408a34 <__swc_fn_0a4ed24b_000093_c2567a3b+0xc4>
  408a20:	rex mov al,BYTE PTR [rsp+0x8]
  408a25:	test   al,al
  408a27:	sete   al
  408a2a:	test   r14b,r14b
  408a2d:	sete   cl
  408a30:	test   al,cl
  408a32:	je     408a47 <__swc_fn_0a4ed24b_000093_c2567a3b+0xd7>
  408a34:	xor    eax,eax
  408a36:	add    rsp,0x38
  408a3a:	pop    r15
  408a3c:	pop    r14
  408a3e:	pop    r13
  408a40:	pop    r12
  408a42:	pop    rdi
  408a43:	pop    rsi
  408a44:	pop    rbx
  408a45:	pop    rbp
  408a46:	ret
  408a47:	mov    r15,r12
  408a4a:	test   r14b,r14b
  408a4d:	jne    408a64 <__swc_fn_0a4ed24b_000093_c2567a3b+0xf4>
  408a4f:	cmp    BYTE PTR [r12+0x2c],0x6
  408a55:	jne    408a64 <__swc_fn_0a4ed24b_000093_c2567a3b+0xf4>
  408a57:	mov    rcx,QWORD PTR [r12+0x40]
  408a5c:	call   410b80 <__swc_fn_0a4ed24b_000086_3953ef98>
  408a61:	mov    r15,rax
  408a64:	test   r14b,r14b
  408a67:	je     408a6d <__swc_fn_0a4ed24b_000093_c2567a3b+0xfd>
  408a69:	mov    r15,QWORD PTR [r15+0x30]
  408a6d:	mov    rcx,rsi
  408a70:	call   410b80 <__swc_fn_0a4ed24b_000086_3953ef98>
  408a75:	mov    rsi,rax
  408a78:	rex cmp BYTE PTR [rsi+0x2c],0x6
  408a7d:	je     408ab4 <__swc_fn_0a4ed24b_000093_c2567a3b+0x144>
  408a7f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  408a84:	je     408ab4 <__swc_fn_0a4ed24b_000093_c2567a3b+0x144>
  408a86:	mov    eax,DWORD PTR [rsi+0x28]
  408a89:	and    eax,0x10000
  408a8f:	je     408ab4 <__swc_fn_0a4ed24b_000093_c2567a3b+0x144>
  408a91:	rex mov al,BYTE PTR [rsp+0x8]
  408a96:	test   al,al
  408a98:	jne    408aad <__swc_fn_0a4ed24b_000093_c2567a3b+0x13d>
  408a9a:	xor    eax,eax
  408a9c:	add    rsp,0x38
  408aa0:	pop    r15
  408aa2:	pop    r14
  408aa4:	pop    r13
  408aa6:	pop    r12
  408aa8:	pop    rdi
  408aa9:	pop    rsi
  408aaa:	pop    rbx
  408aab:	pop    rbp
  408aac:	ret
  408aad:	mov    rax,QWORD PTR [rsi+0x30]
  408ab1:	mov    rsi,rax
  408ab4:	mov    r14b,r13b
  408ab7:	test   rbx,rbx
  408aba:	je     408af0 <__swc_fn_0a4ed24b_000093_c2567a3b+0x180>
  408abc:	cmp    BYTE PTR [r12+0x2c],0x6
  408ac2:	jne    408af0 <__swc_fn_0a4ed24b_000093_c2567a3b+0x180>
  408ac4:	lea    rdx,[rip+0xa9bd]        # 413488 <__swc_rdata_base_0a4ed24b+0x378>
  408acb:	mov    rcx,rsi
  408ace:	xor    r8d,r8d
  408ad1:	call   40cea0 <__swc_fn_0a4ed24b_000094_63c1827b>
  408ad6:	test   al,al
  408ad8:	je     408af0 <__swc_fn_0a4ed24b_000093_c2567a3b+0x180>
  408ada:	mov    BYTE PTR [rbx],0x1
  408add:	xor    eax,eax
  408adf:	add    rsp,0x38
  408ae3:	pop    r15
  408ae5:	pop    r14
  408ae7:	pop    r13
  408ae9:	pop    r12
  408aeb:	pop    rdi
  408aec:	pop    rsi
  408aed:	pop    rbx
  408aee:	pop    rbp
  408aef:	ret
  408af0:	test   rdi,rdi
  408af3:	jne    408b0d <__swc_fn_0a4ed24b_000093_c2567a3b+0x19d>
  408af5:	test   r13b,r13b
  408af8:	jne    408b0d <__swc_fn_0a4ed24b_000093_c2567a3b+0x19d>
  408afa:	xor    eax,eax
  408afc:	add    rsp,0x38
  408b00:	pop    r15
  408b02:	pop    r14
  408b04:	pop    r13
  408b06:	pop    r12
  408b08:	pop    rdi
  408b09:	pop    rsi
  408b0a:	pop    rbx
  408b0b:	pop    rbp
  408b0c:	ret
  408b0d:	rex cmp BYTE PTR [rsi+0x2c],0x6
  408b12:	jne    408bc8 <__swc_fn_0a4ed24b_000093_c2567a3b+0x258>
  408b18:	mov    rcx,r15
  408b1b:	mov    rdx,rsi
  408b1e:	xor    r8d,r8d
  408b21:	call   40cea0 <__swc_fn_0a4ed24b_000094_63c1827b>
  408b26:	test   al,al
  408b28:	jne    408bc8 <__swc_fn_0a4ed24b_000093_c2567a3b+0x258>
  408b2e:	test   DWORD PTR [rsi+0x28],0x10000
  408b35:	je     408b53 <__swc_fn_0a4ed24b_000093_c2567a3b+0x1e3>
  408b37:	rex mov al,BYTE PTR [rsp+0x8]
  408b3c:	test   al,al
  408b3e:	jne    408b53 <__swc_fn_0a4ed24b_000093_c2567a3b+0x1e3>
  408b40:	xor    eax,eax
  408b42:	add    rsp,0x38
  408b46:	pop    r15
  408b48:	pop    r14
  408b4a:	pop    r13
  408b4c:	pop    r12
  408b4e:	pop    rdi
  408b4f:	pop    rsi
  408b50:	pop    rbx
  408b51:	pop    rbp
  408b52:	ret
  408b53:	test   rdi,rdi
  408b56:	jne    408b6b <__swc_fn_0a4ed24b_000093_c2567a3b+0x1fb>
  408b58:	xor    eax,eax
  408b5a:	add    rsp,0x38
  408b5e:	pop    r15
  408b60:	pop    r14
  408b62:	pop    r13
  408b64:	pop    r12
  408b66:	pop    rdi
  408b67:	pop    rsi
  408b68:	pop    rbx
  408b69:	pop    rbp
  408b6a:	ret
  408b6b:	mov    rcx,QWORD PTR [rsi+0x40]
  408b6f:	call   410b80 <__swc_fn_0a4ed24b_000086_3953ef98>
  408b74:	mov    rsi,rax
  408b77:	mov    rax,QWORD PTR [rdi]
  408b7a:	mov    rdi,rax
  408b7d:	test   rax,rax
  408b80:	jne    408bc3 <__swc_fn_0a4ed24b_000093_c2567a3b+0x253>
  408b82:	test   rbx,rbx
  408b85:	je     408bc3 <__swc_fn_0a4ed24b_000093_c2567a3b+0x253>
  408b87:	mov    rcx,r15
  408b8a:	mov    rdx,rsi
  408b8d:	xor    r8d,r8d
  408b90:	call   40cea0 <__swc_fn_0a4ed24b_000094_63c1827b>
  408b95:	mov    rcx,rax
  408b98:	test   al,al
  408b9a:	jne    408bbc <__swc_fn_0a4ed24b_000093_c2567a3b+0x24c>
  408b9c:	mov    rcx,r15
  408b9f:	mov    rdx,rsi
  408ba2:	call   410bc0 <__swc_fn_0a4ed24b_000089_d182c4dc>
  408ba7:	mov    rcx,rax
  408baa:	test   al,al
  408bac:	jne    408bbc <__swc_fn_0a4ed24b_000093_c2567a3b+0x24c>
  408bae:	mov    rcx,rsi
  408bb1:	mov    rdx,r15
  408bb4:	call   410bc0 <__swc_fn_0a4ed24b_000089_d182c4dc>
  408bb9:	mov    rcx,rax
  408bbc:	test   cl,cl
  408bbe:	setne  al
  408bc1:	mov    BYTE PTR [rbx],al
  408bc3:	xor    eax,eax
  408bc5:	mov    r14b,al
  408bc8:	test   rdi,rdi
  408bcb:	jne    408be5 <__swc_fn_0a4ed24b_000093_c2567a3b+0x275>
  408bcd:	test   r14b,r14b
  408bd0:	jne    408be5 <__swc_fn_0a4ed24b_000093_c2567a3b+0x275>
  408bd2:	xor    eax,eax
  408bd4:	add    rsp,0x38
  408bd8:	pop    r15
  408bda:	pop    r14
  408bdc:	pop    r13
  408bde:	pop    r12
  408be0:	pop    rdi
  408be1:	pop    rsi
  408be2:	pop    rbx
  408be3:	pop    rbp
  408be4:	ret
  408be5:	rex cmp BYTE PTR [rsi+0x2c],0x12
  408bea:	je     408bf6 <__swc_fn_0a4ed24b_000093_c2567a3b+0x286>
  408bec:	mov    r12,QWORD PTR [rsp+0x18]
  408bf1:	jmp    408c7e <__swc_fn_0a4ed24b_000093_c2567a3b+0x30e>
  408bf6:	mov    r12,QWORD PTR [rsp+0x18]
  408bfb:	test   r12,r12
  408bfe:	jne    408c12 <__swc_fn_0a4ed24b_000093_c2567a3b+0x2a2>
  408c00:	mov    rcx,r15
  408c03:	mov    rdx,rsi
  408c06:	xor    r8d,r8d
  408c09:	call   40cea0 <__swc_fn_0a4ed24b_000094_63c1827b>
  408c0e:	test   al,al
  408c10:	jne    408c7e <__swc_fn_0a4ed24b_000093_c2567a3b+0x30e>
  408c12:	test   DWORD PTR [rsi+0x28],0x10000
  408c19:	je     408c37 <__swc_fn_0a4ed24b_000093_c2567a3b+0x2c7>
  408c1b:	rex mov al,BYTE PTR [rsp+0x8]
  408c20:	test   al,al
  408c22:	jne    408c37 <__swc_fn_0a4ed24b_000093_c2567a3b+0x2c7>
  408c24:	xor    eax,eax
  408c26:	add    rsp,0x38
  408c2a:	pop    r15
  408c2c:	pop    r14
  408c2e:	pop    r13
  408c30:	pop    r12
  408c32:	pop    rdi
  408c33:	pop    rsi
  408c34:	pop    rbx
  408c35:	pop    rbp
  408c36:	ret
  408c37:	test   rdi,rdi
  408c3a:	jne    408c4f <__swc_fn_0a4ed24b_000093_c2567a3b+0x2df>
  408c3c:	xor    eax,eax
  408c3e:	add    rsp,0x38
  408c42:	pop    r15
  408c44:	pop    r14
  408c46:	pop    r13
  408c48:	pop    r12
  408c4a:	pop    rdi
  408c4b:	pop    rsi
  408c4c:	pop    rbx
  408c4d:	pop    rbp
  408c4e:	ret
  408c4f:	cmp    QWORD PTR [rdi+0x8],0x0
  408c54:	jne    408c69 <__swc_fn_0a4ed24b_000093_c2567a3b+0x2f9>
  408c56:	xor    eax,eax
  408c58:	add    rsp,0x38
  408c5c:	pop    r15
  408c5e:	pop    r14
  408c60:	pop    r13
  408c62:	pop    r12
  408c64:	pop    rdi
  408c65:	pop    rsi
  408c66:	pop    rbx
  408c67:	pop    rbp
  408c68:	ret
  408c69:	mov    rax,QWORD PTR [rdi+0x8]
  408c6d:	mov    rax,QWORD PTR [rax]
  408c70:	mov    rsi,rax
  408c73:	mov    rdi,QWORD PTR [rdi]
  408c76:	mov    eax,0x1
  408c7b:	mov    r14b,al
  408c7e:	test   rdi,rdi
  408c81:	mov    rbx,QWORD PTR [rsp+0x20]
  408c86:	jne    408cd0 <__swc_fn_0a4ed24b_000093_c2567a3b+0x360>
  408c88:	test   r14b,r14b
  408c8b:	je     408cbd <__swc_fn_0a4ed24b_000093_c2567a3b+0x34d>
  408c8d:	test   r12,r12
  408c90:	je     408cbd <__swc_fn_0a4ed24b_000093_c2567a3b+0x34d>
  408c92:	mov    rcx,r15
  408c95:	mov    rdx,rsi
  408c98:	xor    r8d,r8d
  408c9b:	mov    r9,r12
  408c9e:	mov    rbx,QWORD PTR [rsp+0x20]
  408ca3:	movzx  r10d,BYTE PTR [rbx]
  408ca7:	call   408860 <__swc_fn_0a4ed24b_000087_ef55f6e4>
  408cac:	add    rsp,0x38
  408cb0:	pop    r15
  408cb2:	pop    r14
  408cb4:	pop    r13
  408cb6:	pop    r12
  408cb8:	pop    rdi
  408cb9:	pop    rsi
  408cba:	pop    rbx
  408cbb:	pop    rbp
  408cbc:	ret
  408cbd:	xor    eax,eax
  408cbf:	add    rsp,0x38
  408cc3:	pop    r15
  408cc5:	pop    r14
  408cc7:	pop    r13
  408cc9:	pop    r12
  408ccb:	pop    rdi
  408ccc:	pop    rsi
  408ccd:	pop    rbx
  408cce:	pop    rbp
  408ccf:	ret
  408cd0:	mov    r13,rsi
  408cd3:	mov    QWORD PTR [rsp+0x28],rdi
  408cd8:	cmp    BYTE PTR [r15+0x2c],0xe
  408cdd:	sete   al
  408ce0:	mov    r14b,al
  408ce3:	jne    408cf7 <__swc_fn_0a4ed24b_000093_c2567a3b+0x387>
  408ce5:	mov    rcx,rsi
  408ce8:	mov    rdx,r15
  408ceb:	call   410bc0 <__swc_fn_0a4ed24b_000089_d182c4dc>
  408cf0:	mov    r14b,al
  408cf3:	test   al,al
  408cf5:	jne    408d2c <__swc_fn_0a4ed24b_000093_c2567a3b+0x3bc>
  408cf7:	cmp    BYTE PTR [r15+0x2c],0x12
  408cfc:	je     408d2c <__swc_fn_0a4ed24b_000093_c2567a3b+0x3bc>
  408cfe:	mov    rcx,r15
  408d01:	mov    rdx,rsi
  408d04:	mov    r8,rdi
  408d07:	mov    r9,r12
  408d0a:	mov    rax,rbx
  408d0d:	movzx  r10d,BYTE PTR [rax]
  408d11:	call   408860 <__swc_fn_0a4ed24b_000087_ef55f6e4>
  408d16:	test   rax,rax
  408d19:	je     408d2c <__swc_fn_0a4ed24b_000093_c2567a3b+0x3bc>
  408d1b:	add    rsp,0x38
  408d1f:	pop    r15
  408d21:	pop    r14
  408d23:	pop    r13
  408d25:	pop    r12
  408d27:	pop    rdi
  408d28:	pop    rsi
  408d29:	pop    rbx
  408d2a:	pop    rbp
  408d2b:	ret
  408d2c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  408d31:	jne    408d50 <__swc_fn_0a4ed24b_000093_c2567a3b+0x3e0>
  408d33:	mov    rax,QWORD PTR [rsi+0xd8]
  408d3a:	test   rax,rax
  408d3d:	je     408d50 <__swc_fn_0a4ed24b_000093_c2567a3b+0x3e0>
  408d3f:	add    rdi,QWORD PTR [rax+0x8]
  408d43:	mov    rax,QWORD PTR [rdi]
  408d46:	sub    rdi,QWORD PTR [rax+0x8]
  408d4a:	mov    rax,QWORD PTR [rax]
  408d4d:	mov    rsi,rax
  408d50:	test   r14b,r14b
  408d53:	je     408d7f <__swc_fn_0a4ed24b_000093_c2567a3b+0x40f>
  408d55:	mov    rcx,r15
  408d58:	mov    rdx,rsi
  408d5b:	mov    r8,rdi
  408d5e:	mov    r9,r13
  408d61:	mov    r14,QWORD PTR [rsp+0x28]
  408d66:	mov    r10,r14
  408d69:	call   40cd80 <__swc_fn_0a4ed24b_000091_c1c9085b>
  408d6e:	add    rsp,0x38
  408d72:	pop    r15
  408d74:	pop    r14
  408d76:	pop    r13
  408d78:	pop    r12
  408d7a:	pop    rdi
  408d7b:	pop    rsi
  408d7c:	pop    rbx
  408d7d:	pop    rbp
  408d7e:	ret
  408d7f:	mov    rcx,r15
  408d82:	mov    rdx,rsi
  408d85:	mov    r8,rdi
  408d88:	mov    r9,r12
  408d8b:	movzx  r10d,BYTE PTR [rbx]
  408d8f:	call   408860 <__swc_fn_0a4ed24b_000087_ef55f6e4>
  408d94:	add    rsp,0x38
  408d98:	pop    r15
  408d9a:	pop    r14
  408d9c:	pop    r13
  408d9e:	pop    r12
  408da0:	pop    rdi
  408da1:	pop    rsi
  408da2:	pop    rbx
  408da3:	pop    rbp
  408da4:	ret
	...

0000000000408db0 <__swc_fn_0a4ed24b_000096_93bfe675>:
  408db0:	push   rbx
  408db1:	push   rsi
  408db2:	sub    rsp,0x18
  408db6:	mov    rbx,rcx
  408db9:	mov    rcx,QWORD PTR [rip+0x1df80]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  408dc0:	test   rcx,rcx
  408dc3:	jne    408dd5 <__swc_fn_0a4ed24b_000096_93bfe675+0x25>
  408dc5:	call   40eaa0 <__swc_fn_0a4ed24b_000169_994c8876>
  408dca:	lea    rcx,[rax+0x1]
  408dce:	mov    QWORD PTR [rip+0x1df6b],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  408dd5:	dec    rcx
  408dd8:	call   40b660 <__swc_fn_0a4ed24b_000171_360af05d>
  408ddd:	mov    rsi,rax
  408de0:	mov    rax,QWORD PTR [rsi+0x8]
  408de4:	test   rax,rax
  408de7:	jne    408e37 <__swc_fn_0a4ed24b_000096_93bfe675+0x87>
  408de9:	call   410cb0 <__swc_fn_0a4ed24b_000095_ad13d15c>
  408dee:	test   al,al
  408df0:	jne    408e37 <__swc_fn_0a4ed24b_000096_93bfe675+0x87>
  408df2:	lea    rdx,[rip+0x1b447]        # 424240 <__swc_bss_base_0a4ed24b+0x200>
  408df9:	mov    rcx,rdx
  408dfc:	call   40c040 <__swc_fn_0a4ed24b_000040_eb6108f2>
  408e01:	test   al,al
  408e03:	jne    408e14 <__swc_fn_0a4ed24b_000096_93bfe675+0x64>
  408e05:	mov    rcx,rdx
  408e08:	call   40f5a0 <__swc_fn_0a4ed24b_000038_14f56618>
  408e0d:	lea    rdx,[rip+0x1b42c]        # 424240 <__swc_bss_base_0a4ed24b+0x200>
  408e14:	mov    QWORD PTR [rsp+0x8],rdx
  408e19:	lea    rax,[rip+0xa638]        # 413458 <__swc_rdata_base_0a4ed24b+0x348>
  408e20:	mov    QWORD PTR [rsp+0x10],rax
  408e25:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  408e2b:	vmovups XMMWORD PTR [rsi],xmm0
  408e2f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  408e37:	vmovups xmm0,XMMWORD PTR [rsi]
  408e3b:	vmovups XMMWORD PTR [rbx],xmm0
  408e3f:	mov    rax,rbx
  408e42:	add    rsp,0x18
  408e46:	pop    rsi
  408e47:	pop    rbx
  408e48:	ret
  408e49:	add    BYTE PTR [rax],al
  408e4b:	add    BYTE PTR [rax],al
  408e4d:	add    BYTE PTR [rax],al
	...

0000000000408e50 <__swc_fn_0a4ed24b_000099_65137b72>:
  408e50:	sub    rsp,0x8
  408e54:	call   40dc40 <__swc_fn_0a4ed24b_000121_0a5fa85a>
  408e59:	add    rsp,0x8
  408e5d:	ret
	...

0000000000408e60 <__swc_fn_0a4ed24b_000102_e34f54dc>:
  408e60:	push   rbx
  408e61:	push   rsi
  408e62:	sub    rsp,0x28
  408e66:	mov    rbx,rcx
  408e69:	xor    esi,esi
  408e6b:	jmp    408e80 <__swc_fn_0a4ed24b_000102_e34f54dc+0x20>
  408e6d:	nop    DWORD PTR [rax]
  408e70:	mov    QWORD PTR [rbx+0x28],rsi
  408e74:	mov    rsi,rbx
  408e77:	mov    rbx,rax
  408e7a:	nop    WORD PTR [rax+rax*1+0x0]
  408e80:	test   rbx,rbx
  408e83:	je     408ee3 <__swc_fn_0a4ed24b_000102_e34f54dc+0x83>
  408e85:	mov    rcx,rbx
  408e88:	mov    edx,0x1
  408e8d:	call   40cb00 <__swc_fn_0a4ed24b_000082_63a67586>
  408e92:	cmp    rax,0x1
  408e96:	jne    408ee3 <__swc_fn_0a4ed24b_000102_e34f54dc+0x83>
  408e98:	mov    r10,QWORD PTR [rbx+0x18]
  408e9c:	mov    rcx,r10
  408e9f:	mov    edx,0x1
  408ea4:	call   40cb00 <__swc_fn_0a4ed24b_000082_63a67586>
  408ea9:	cmp    rax,0x1
  408ead:	jne    408ebc <__swc_fn_0a4ed24b_000102_e34f54dc+0x5c>
  408eaf:	mov    rcx,r10
  408eb2:	call   410e50 <__swc_fn_0a4ed24b_000101_d0b19c14>
  408eb7:	test   rax,rax
  408eba:	jne    408e70 <__swc_fn_0a4ed24b_000102_e34f54dc+0x10>
  408ebc:	mov    rax,QWORD PTR [rbx+0x20]
  408ec0:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  408ec5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  408ecb:	lea    rcx,[rsp+0x8]
  408ed0:	mov    rdx,rbx
  408ed3:	mov    r8d,0x30
  408ed9:	mov    rbx,rax
  408edc:	call   40d260 <__swc_fn_0a4ed24b_000100_d4bdcaa4>
  408ee1:	jmp    408e80 <__swc_fn_0a4ed24b_000102_e34f54dc+0x20>
  408ee3:	test   rsi,rsi
  408ee6:	jne    408eef <__swc_fn_0a4ed24b_000102_e34f54dc+0x8f>
  408ee8:	add    rsp,0x28
  408eec:	pop    rsi
  408eed:	pop    rbx
  408eee:	ret
  408eef:	mov    rax,rsi
  408ef2:	mov    rsi,QWORD PTR [rsi+0x28]
  408ef6:	mov    rbx,QWORD PTR [rax+0x20]
  408efa:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  408eff:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408f05:	lea    rcx,[rsp+0x18]
  408f0a:	mov    rdx,rax
  408f0d:	mov    r8d,0x30
  408f13:	call   40d260 <__swc_fn_0a4ed24b_000100_d4bdcaa4>
  408f18:	jmp    408e80 <__swc_fn_0a4ed24b_000102_e34f54dc+0x20>
  408f1d:	add    BYTE PTR [rax],al
	...

0000000000408f20 <__swc_fn_0a4ed24b_000105_5a85fcf5>:
  408f20:	push   rbx
  408f21:	push   rsi
  408f22:	push   rdi
  408f23:	push   r12
  408f25:	push   r13
  408f27:	sub    rsp,0x20
  408f2b:	mov    rbx,rcx
  408f2e:	lea    rsi,[rcx+0x6f8]
  408f35:	mov    edi,0x4
  408f3a:	mov    r12,rsi
  408f3d:	test   rdi,rdi
  408f40:	je     408f8a <__swc_fn_0a4ed24b_000105_5a85fcf5+0x6a>
  408f42:	cs nop WORD PTR [rax+rax*1+0x0]
  408f4c:	nop    DWORD PTR [rax+0x0]
  408f50:	mov    rcx,QWORD PTR [r12+0x10]
  408f55:	mov    QWORD PTR [r12+0x10],0x0
  408f5e:	vxorps xmm0,xmm0,xmm0
  408f62:	vmovups XMMWORD PTR [r12],xmm0
  408f68:	vmovups XMMWORD PTR [r12+0x28],xmm0
  408f6f:	mov    DWORD PTR [r12+0x20],0x0
  408f78:	call   40d2b0 <__swc_fn_0a4ed24b_000103_2fdd2c61>
  408f7d:	add    r12,0x90
  408f84:	sub    rdi,0x1
  408f88:	jne    408f50 <__swc_fn_0a4ed24b_000105_5a85fcf5+0x30>
  408f8a:	mov    rax,QWORD PTR [rbx+0x938]
  408f91:	mov    rdi,rax
  408f94:	test   rdi,rdi
  408f97:	je     408ff1 <__swc_fn_0a4ed24b_000105_5a85fcf5+0xd1>
  408f99:	nop    DWORD PTR [rax+0x0]
  408fa0:	mov    r12d,0x10
  408fa6:	lea    r13,[rdi+0x18]
  408faa:	test   r12,r12
  408fad:	je     408fe6 <__swc_fn_0a4ed24b_000105_5a85fcf5+0xc6>
  408faf:	nop
  408fb0:	mov    rcx,QWORD PTR [r13+0x10]
  408fb4:	mov    QWORD PTR [r13+0x10],0x0
  408fbc:	vxorps xmm0,xmm0,xmm0
  408fc0:	vmovups XMMWORD PTR [r13+0x0],xmm0
  408fc6:	vmovups XMMWORD PTR [r13+0x28],xmm0
  408fcc:	mov    DWORD PTR [r13+0x20],0x0
  408fd4:	call   40d2b0 <__swc_fn_0a4ed24b_000103_2fdd2c61>
  408fd9:	add    r13,0x90
  408fe0:	sub    r12,0x1
  408fe4:	jne    408fb0 <__swc_fn_0a4ed24b_000105_5a85fcf5+0x90>
  408fe6:	mov    rax,QWORD PTR [rdi]
  408fe9:	mov    rdi,rax
  408fec:	test   rax,rax
  408fef:	jne    408fa0 <__swc_fn_0a4ed24b_000105_5a85fcf5+0x80>
  408ff1:	vxorps xmm0,xmm0,xmm0
  408ff5:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  408ffd:	mov    DWORD PTR [rbx+0x9b0],0x0
  409007:	mov    DWORD PTR [rbx+0x9a8],0x0
  409011:	mov    edi,0x4
  409016:	mov    r12,rsi
  409019:	lea    rsi,[rsi+0x38]
  40901d:	test   rdi,rdi
  409020:	je     40904c <__swc_fn_0a4ed24b_000105_5a85fcf5+0x12c>
  409022:	cs nop WORD PTR [rax+rax*1+0x0]
  40902c:	nop    DWORD PTR [rax+0x0]
  409030:	mov    rcx,rsi
  409033:	call   411cd0 <__swc_fn_0a4ed24b_000161_13ead2ff>
  409038:	add    rsi,0x90
  40903f:	add    r12,0x90
  409046:	sub    rdi,0x1
  40904a:	jne    409030 <__swc_fn_0a4ed24b_000105_5a85fcf5+0x110>
  40904c:	mov    rax,QWORD PTR [rbx+0x938]
  409053:	mov    rdi,rax
  409056:	mov    QWORD PTR [rbx+0x938],0x0
  409061:	test   rdi,rdi
  409064:	je     4090d5 <__swc_fn_0a4ed24b_000105_5a85fcf5+0x1b5>
  40906a:	nop    WORD PTR [rax+rax*1+0x0]
  409070:	mov    esi,0x10
  409075:	lea    r12,[rdi+0x18]
  409079:	lea    r13,[rdi+0x50]
  40907d:	test   rsi,rsi
  409080:	je     4090ac <__swc_fn_0a4ed24b_000105_5a85fcf5+0x18c>
  409082:	cs nop WORD PTR [rax+rax*1+0x0]
  40908c:	nop    DWORD PTR [rax+0x0]
  409090:	mov    rcx,r13
  409093:	call   411cd0 <__swc_fn_0a4ed24b_000161_13ead2ff>
  409098:	add    r13,0x90
  40909f:	add    r12,0x90
  4090a6:	sub    rsi,0x1
  4090aa:	jne    409090 <__swc_fn_0a4ed24b_000105_5a85fcf5+0x170>
  4090ac:	mov    rax,QWORD PTR [rdi]
  4090af:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  4090b4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4090ba:	lea    rcx,[rsp+0x8]
  4090bf:	mov    rdx,rdi
  4090c2:	mov    r8d,0x918
  4090c8:	mov    rdi,rax
  4090cb:	call   40d260 <__swc_fn_0a4ed24b_000100_d4bdcaa4>
  4090d0:	test   rdi,rdi
  4090d3:	jne    409070 <__swc_fn_0a4ed24b_000105_5a85fcf5+0x150>
  4090d5:	lea    rcx,[rbx+0x68]
  4090d9:	call   411cd0 <__swc_fn_0a4ed24b_000161_13ead2ff>
  4090de:	add    rsp,0x20
  4090e2:	pop    r13
  4090e4:	pop    r12
  4090e6:	pop    rdi
  4090e7:	pop    rsi
  4090e8:	pop    rbx
  4090e9:	ret
  4090ea:	add    BYTE PTR [rax],al
  4090ec:	add    BYTE PTR [rax],al
	...

00000000004090f0 <__swc_fn_0a4ed24b_000108_c51c3158>:
  4090f0:	xor    eax,eax
  4090f2:	cs nop WORD PTR [rax+rax*1+0x0]
  4090fc:	nop    DWORD PTR [rax+0x0]
  409100:	mov    r9,r8
  409103:	sub    r9,rax
  409106:	cmp    r9,0x40
  40910a:	jb     409148 <__swc_fn_0a4ed24b_000108_c51c3158+0x58>
  40910c:	lea    r9,[rcx+rax*1]
  409110:	lea    r10,[rdx+rax*1]
  409114:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40911a:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  409120:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  409126:	vmovups xmm3,XMMWORD PTR [r10]
  40912b:	vmovups XMMWORD PTR [r9],xmm3
  409130:	vmovups XMMWORD PTR [r9+0x10],xmm0
  409136:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40913c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  409142:	lea    rax,[rax+0x40]
  409146:	jmp    409100 <__swc_fn_0a4ed24b_000108_c51c3158+0x10>
  409148:	nop    DWORD PTR [rax+rax*1+0x0]
  409150:	mov    r9,r8
  409153:	sub    r9,rax
  409156:	cmp    r9,0x10
  40915a:	jb     409174 <__swc_fn_0a4ed24b_000108_c51c3158+0x84>
  40915c:	lea    r9,[rdx+rax*1]
  409160:	lea    r10,[rcx+rax*1]
  409164:	vmovups xmm0,XMMWORD PTR [r9]
  409169:	vmovups XMMWORD PTR [r10],xmm0
  40916e:	lea    rax,[rax+0x10]
  409172:	jmp    409150 <__swc_fn_0a4ed24b_000108_c51c3158+0x60>
  409174:	cs nop WORD PTR [rax+rax*1+0x0]
  40917e:	xchg   ax,ax
  409180:	mov    r9,r8
  409183:	sub    r9,rax
  409186:	cmp    r9,0x8
  40918a:	jb     40919d <__swc_fn_0a4ed24b_000108_c51c3158+0xad>
  40918c:	lea    r9,[rcx+rax*1]
  409190:	mov    r10,QWORD PTR [rdx+rax*1]
  409194:	mov    QWORD PTR [r9],r10
  409197:	lea    rax,[rax+0x8]
  40919b:	jmp    409180 <__swc_fn_0a4ed24b_000108_c51c3158+0x90>
  40919d:	cmp    rax,r8
  4091a0:	jae    4091c0 <__swc_fn_0a4ed24b_000108_c51c3158+0xd0>
  4091a2:	cs nop WORD PTR [rax+rax*1+0x0]
  4091ac:	nop    DWORD PTR [rax+0x0]
  4091b0:	mov    r9b,BYTE PTR [rdx+rax*1]
  4091b4:	mov    BYTE PTR [rcx+rax*1],r9b
  4091b8:	inc    rax
  4091bb:	cmp    rax,r8
  4091be:	jb     4091b0 <__swc_fn_0a4ed24b_000108_c51c3158+0xc0>
  4091c0:	ret
	...

00000000004091d0 <__swc_fn_0a4ed24b_000111_6814119b>:
  4091d0:	push   rbx
  4091d1:	push   r12
  4091d3:	push   rdi
  4091d4:	push   rsi
  4091d5:	push   r13
  4091d7:	push   r14
  4091d9:	push   r15
  4091db:	sub    rsp,0x170
  4091e2:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  4091eb:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  4091f4:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  4091fd:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  409206:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40920f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  409218:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  409221:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40922a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  409233:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40923c:	mov    ebx,edx
  40923e:	mov    QWORD PTR [rsp+0xa8],rbx
  409246:	mov    r12d,ecx
  409249:	test   edx,edx
  40924b:	jne    409262 <__swc_fn_0a4ed24b_000111_6814119b+0x92>
  40924d:	xor    eax,eax
  40924f:	add    rsp,0x170
  409256:	pop    r15
  409258:	pop    r14
  40925a:	pop    r13
  40925c:	pop    rsi
  40925d:	pop    rdi
  40925e:	pop    r12
  409260:	pop    rbx
  409261:	ret
  409262:	lea    rdi,[rip+0xa4f7]        # 413760 <__swc_rdata_base_0a4ed24b+0x650>
  409269:	mov    esi,0x90000
  40926e:	xor    eax,eax
  409270:	call   407020 <open@plt>
  409275:	mov    r13,rax
  409278:	mov    QWORD PTR [rsp+0xb0],rax
  409280:	test   eax,eax
  409282:	jge    40928b <__swc_fn_0a4ed24b_000111_6814119b+0xbb>
  409284:	xor    eax,eax
  409286:	jmp    409786 <__swc_fn_0a4ed24b_000111_6814119b+0x5b6>
  40928b:	nop    DWORD PTR [rax+rax*1+0x0]
  409290:	movsxd rdi,r13d
  409293:	mov    esi,0x2
  409298:	xor    eax,eax
  40929a:	call   407030 <flock@plt>
  40929f:	test   eax,eax
  4092a1:	je     4092c0 <__swc_fn_0a4ed24b_000111_6814119b+0xf0>
  4092a3:	xor    eax,eax
  4092a5:	call   407040 <__errno_location@plt>
  4092aa:	cmp    DWORD PTR [rax],0x4
  4092ad:	je     409290 <__swc_fn_0a4ed24b_000111_6814119b+0xc0>
  4092af:	movsxd rdi,r13d
  4092b2:	xor    eax,eax
  4092b4:	call   407050 <close@plt>
  4092b9:	xor    eax,eax
  4092bb:	jmp    409786 <__swc_fn_0a4ed24b_000111_6814119b+0x5b6>
  4092c0:	lea    r14,[rsp+0x8]
  4092c5:	mov    QWORD PTR [rsp+0xb8],r14
  4092cd:	vxorps xmm0,xmm0,xmm0
  4092d1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4092d7:	mov    QWORD PTR [rsp+0x18],0x0
  4092e0:	mov    WORD PTR [rsp+0x20],0x0
  4092e7:	mov    DWORD PTR [r14],0x67617753
  4092ee:	mov    DWORD PTR [r14+0x4],0x2e74522e
  4092f6:	xor    eax,eax
  4092f8:	call   407060 <getpid@plt>
  4092fd:	mov    ecx,eax
  4092ff:	mov    eax,0x1c
  409304:	shrx   eax,ecx,eax
  409309:	and    eax,0xf
  40930c:	mov    rdx,QWORD PTR [rip+0xa46d]        # 413780 <__swc_rdata_base_0a4ed24b+0x670>
  409313:	mov    al,BYTE PTR [rdx+rax*1]
  409316:	rex mov BYTE PTR [rsp+0x10],al
  40931b:	mov    eax,0x1c
  409320:	shrx   eax,r12d,eax
  409325:	and    eax,0xf
  409328:	mov    al,BYTE PTR [rdx+rax*1]
  40932b:	rex mov BYTE PTR [rsp+0x19],al
  409330:	mov    eax,0x18
  409335:	shrx   eax,ecx,eax
  40933a:	and    eax,0xf
  40933d:	mov    al,BYTE PTR [rdx+rax*1]
  409340:	rex mov BYTE PTR [rsp+0x11],al
  409345:	mov    eax,0x18
  40934a:	shrx   eax,r12d,eax
  40934f:	and    eax,0xf
  409352:	mov    al,BYTE PTR [rdx+rax*1]
  409355:	rex mov BYTE PTR [rsp+0x1a],al
  40935a:	mov    eax,0x14
  40935f:	shrx   eax,ecx,eax
  409364:	and    eax,0xf
  409367:	mov    al,BYTE PTR [rdx+rax*1]
  40936a:	rex mov BYTE PTR [rsp+0x12],al
  40936f:	mov    eax,0x14
  409374:	shrx   eax,r12d,eax
  409379:	and    eax,0xf
  40937c:	mov    al,BYTE PTR [rdx+rax*1]
  40937f:	rex mov BYTE PTR [rsp+0x1b],al
  409384:	mov    eax,0x10
  409389:	shrx   eax,ecx,eax
  40938e:	and    eax,0xf
  409391:	mov    al,BYTE PTR [rdx+rax*1]
  409394:	rex mov BYTE PTR [rsp+0x13],al
  409399:	mov    eax,0x10
  40939e:	shrx   eax,r12d,eax
  4093a3:	and    eax,0xf
  4093a6:	mov    al,BYTE PTR [rdx+rax*1]
  4093a9:	rex mov BYTE PTR [rsp+0x1c],al
  4093ae:	mov    eax,0xc
  4093b3:	shrx   eax,ecx,eax
  4093b8:	and    eax,0xf
  4093bb:	mov    al,BYTE PTR [rdx+rax*1]
  4093be:	rex mov BYTE PTR [rsp+0x14],al
  4093c3:	mov    eax,0xc
  4093c8:	shrx   eax,r12d,eax
  4093cd:	and    eax,0xf
  4093d0:	mov    al,BYTE PTR [rdx+rax*1]
  4093d3:	rex mov BYTE PTR [rsp+0x1d],al
  4093d8:	mov    eax,0x8
  4093dd:	shrx   eax,ecx,eax
  4093e2:	and    eax,0xf
  4093e5:	mov    al,BYTE PTR [rdx+rax*1]
  4093e8:	rex mov BYTE PTR [rsp+0x15],al
  4093ed:	mov    eax,0x8
  4093f2:	shrx   eax,r12d,eax
  4093f7:	and    eax,0xf
  4093fa:	mov    al,BYTE PTR [rdx+rax*1]
  4093fd:	rex mov BYTE PTR [rsp+0x1e],al
  409402:	mov    eax,0x4
  409407:	shrx   eax,ecx,eax
  40940c:	and    eax,0xf
  40940f:	mov    al,BYTE PTR [rdx+rax*1]
  409412:	rex mov BYTE PTR [rsp+0x16],al
  409417:	mov    eax,0x4
  40941c:	shrx   eax,r12d,eax
  409421:	and    eax,0xf
  409424:	mov    al,BYTE PTR [rdx+rax*1]
  409427:	rex mov BYTE PTR [rsp+0x1f],al
  40942c:	xor    eax,eax
  40942e:	shrx   eax,ecx,eax
  409433:	and    eax,0xf
  409436:	mov    al,BYTE PTR [rdx+rax*1]
  409439:	rex mov BYTE PTR [rsp+0x17],al
  40943e:	xor    eax,eax
  409440:	shrx   eax,r12d,eax
  409445:	and    eax,0xf
  409448:	mov    al,BYTE PTR [rdx+rax*1]
  40944b:	rex mov BYTE PTR [rsp+0x20],al
  409450:	mov    BYTE PTR [r14+0x10],0x2e
  409455:	lea    r12,[rsp+0x22]
  40945a:	vxorps xmm0,xmm0,xmm0
  40945e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  409464:	mov    DWORD PTR [r12],0x6d656d2f
  40946c:	mov    WORD PTR [r12+0x4],0x6466
  409474:	mov    BYTE PTR [r12+0x6],0x3a
  40947a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409480:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  409486:	mov    rax,QWORD PTR [rsp+0x18]
  40948b:	mov    QWORD PTR [rsp+0x39],rax
  409490:	rex mov al,BYTE PTR [rsp+0x20]
  409495:	rex mov BYTE PTR [rsp+0x41],al
  40949a:	mov    DWORD PTR [r12+0x20],0x65642820
  4094a3:	mov    DWORD PTR [r12+0x24],0x6574656c
  4094ac:	mov    WORD PTR [r12+0x28],0x2964
  4094b4:	lea    rdi,[rip+0xa2b0]        # 41376b <__swc_rdata_base_0a4ed24b+0x65b>
  4094bb:	xor    eax,eax
  4094bd:	call   407070 <opendir@plt>
  4094c2:	mov    r15,rax
  4094c5:	test   rax,rax
  4094c8:	jne    4094db <__swc_fn_0a4ed24b_000111_6814119b+0x30b>
  4094ca:	movsxd rdi,r13d
  4094cd:	xor    eax,eax
  4094cf:	call   407050 <close@plt>
  4094d4:	xor    eax,eax
  4094d6:	jmp    409786 <__swc_fn_0a4ed24b_000111_6814119b+0x5b6>
  4094db:	mov    rdi,r15
  4094de:	xor    eax,eax
  4094e0:	call   407080 <dirfd@plt>
  4094e5:	lea    r14,[rsp+0x54]
  4094ea:	mov    DWORD PTR [rsp+0x54],eax
  4094ee:	lea    rbx,[rsp+0x58]
  4094f3:	cs nop WORD PTR [rax+rax*1+0x0]
  4094fd:	nop    DWORD PTR [rax]
  409500:	mov    rdi,r15
  409503:	xor    eax,eax
  409505:	call   407090 <readdir@plt>
  40950a:	test   rax,rax
  40950d:	jne    409524 <__swc_fn_0a4ed24b_000111_6814119b+0x354>
  40950f:	mov    r12,QWORD PTR [rsp+0xa8]
  409517:	mov    r13,QWORD PTR [rsp+0xb0]
  40951f:	jmp    4096aa <__swc_fn_0a4ed24b_000111_6814119b+0x4da>
  409524:	vxorps xmm0,xmm0,xmm0
  409528:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  40952e:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  409534:	vzeroupper
  409537:	lea    r13,[rax+0x13]
  40953b:	mov    rax,r14
  40953e:	movsxd rdi,DWORD PTR [rax]
  409541:	mov    rsi,r13
  409544:	mov    rdx,rbx
  409547:	mov    ecx,0x40
  40954c:	xor    eax,eax
  40954e:	call   4070a0 <readlinkat@plt>
  409553:	cmp    rax,0x2a
  409557:	jne    409500 <__swc_fn_0a4ed24b_000111_6814119b+0x330>
  409559:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40955f:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  409565:	vptest xmm0,xmm0
  40956a:	jne    40959a <__swc_fn_0a4ed24b_000111_6814119b+0x3ca>
  40956c:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  409572:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  409578:	vptest xmm0,xmm0
  40957d:	jne    40959a <__swc_fn_0a4ed24b_000111_6814119b+0x3ca>
  40957f:	mov    rcx,QWORD PTR [rsp+0x42]
  409584:	cmp    QWORD PTR [rsp+0x78],rcx
  409589:	jne    40959a <__swc_fn_0a4ed24b_000111_6814119b+0x3ca>
  40958b:	mov    cx,WORD PTR [rsp+0x4a]
  409590:	cmp    WORD PTR [rsp+0x80],cx
  409598:	je     4095c4 <__swc_fn_0a4ed24b_000111_6814119b+0x3f4>
  40959a:	mov    rax,rbx
  40959d:	mov    rcx,r12
  4095a0:	movzx  edx,BYTE PTR [rax]
  4095a3:	movzx  r8d,BYTE PTR [rcx]
  4095a7:	cmp    rdx,r8
  4095aa:	jne    4095b6 <__swc_fn_0a4ed24b_000111_6814119b+0x3e6>
  4095ac:	add    rax,0x1
  4095b0:	add    rcx,0x1
  4095b4:	jmp    4095a0 <__swc_fn_0a4ed24b_000111_6814119b+0x3d0>
  4095b6:	mov    rax,rdx
  4095b9:	sub    rax,r8
  4095bc:	test   eax,eax
  4095be:	jne    409500 <__swc_fn_0a4ed24b_000111_6814119b+0x330>
  4095c4:	movsxd rdi,DWORD PTR [r14]
  4095c7:	mov    rsi,r13
  4095ca:	mov    edx,0x80002
  4095cf:	xor    eax,eax
  4095d1:	call   4070b0 <openat@plt>
  4095d6:	lea    rbx,[rsp+0x98]
  4095de:	mov    DWORD PTR [rsp+0x98],eax
  4095e5:	test   eax,eax
  4095e7:	mov    r13,QWORD PTR [rsp+0xb0]
  4095ef:	jge    409614 <__swc_fn_0a4ed24b_000111_6814119b+0x444>
  4095f1:	mov    rdi,r15
  4095f4:	xor    eax,eax
  4095f6:	call   4070c0 <closedir@plt>
  4095fb:	mov    r13,QWORD PTR [rsp+0xb0]
  409603:	movsxd rdi,r13d
  409606:	xor    eax,eax
  409608:	call   407050 <close@plt>
  40960d:	xor    eax,eax
  40960f:	jmp    409786 <__swc_fn_0a4ed24b_000111_6814119b+0x5b6>
  409614:	mov    rax,rbx
  409617:	movsxd rdi,DWORD PTR [rax]
  40961a:	xor    esi,esi
  40961c:	mov    edx,0x2
  409621:	xor    eax,eax
  409623:	call   4070d0 <lseek@plt>
  409628:	mov    r12,QWORD PTR [rsp+0xa8]
  409630:	cmp    rax,r12
  409633:	je     40965a <__swc_fn_0a4ed24b_000111_6814119b+0x48a>
  409635:	movsxd rdi,DWORD PTR [rbx]
  409638:	xor    eax,eax
  40963a:	call   407050 <close@plt>
  40963f:	mov    rdi,r15
  409642:	xor    eax,eax
  409644:	call   4070c0 <closedir@plt>
  409649:	movsxd rdi,r13d
  40964c:	xor    eax,eax
  40964e:	call   407050 <close@plt>
  409653:	xor    eax,eax
  409655:	jmp    409786 <__swc_fn_0a4ed24b_000111_6814119b+0x5b6>
  40965a:	xor    edi,edi
  40965c:	mov    rsi,r12
  40965f:	mov    edx,0x3
  409664:	mov    ecx,0x1
  409669:	mov    rax,rbx
  40966c:	movsxd r8,DWORD PTR [rax]
  40966f:	xor    r9d,r9d
  409672:	xor    eax,eax
  409674:	call   4070e0 <mmap@plt>
  409679:	xor    r12d,r12d
  40967c:	cmp    rax,0xffffffffffffffff
  409680:	cmovne r12,rax
  409684:	movsxd rdi,DWORD PTR [rbx]
  409687:	xor    eax,eax
  409689:	call   407050 <close@plt>
  40968e:	mov    rdi,r15
  409691:	xor    eax,eax
  409693:	call   4070c0 <closedir@plt>
  409698:	movsxd rdi,r13d
  40969b:	xor    eax,eax
  40969d:	call   407050 <close@plt>
  4096a2:	mov    rax,r12
  4096a5:	jmp    409786 <__swc_fn_0a4ed24b_000111_6814119b+0x5b6>
  4096aa:	mov    r14,QWORD PTR [rsp+0xb8]
  4096b2:	mov    rdi,r14
  4096b5:	mov    esi,0x1
  4096ba:	xor    eax,eax
  4096bc:	call   4070f0 <memfd_create@plt>
  4096c1:	lea    rbx,[rsp+0x9c]
  4096c9:	mov    DWORD PTR [rsp+0x9c],eax
  4096d0:	test   eax,eax
  4096d2:	jge    4096ef <__swc_fn_0a4ed24b_000111_6814119b+0x51f>
  4096d4:	mov    rdi,r15
  4096d7:	xor    eax,eax
  4096d9:	call   4070c0 <closedir@plt>
  4096de:	movsxd rdi,r13d
  4096e1:	xor    eax,eax
  4096e3:	call   407050 <close@plt>
  4096e8:	xor    eax,eax
  4096ea:	jmp    409786 <__swc_fn_0a4ed24b_000111_6814119b+0x5b6>
  4096ef:	mov    rax,rbx
  4096f2:	movsxd rdi,DWORD PTR [rax]
  4096f5:	mov    rsi,r12
  4096f8:	xor    eax,eax
  4096fa:	call   407100 <ftruncate@plt>
  4096ff:	test   eax,eax
  409701:	je     409725 <__swc_fn_0a4ed24b_000111_6814119b+0x555>
  409703:	movsxd rdi,DWORD PTR [rbx]
  409706:	xor    eax,eax
  409708:	call   407050 <close@plt>
  40970d:	mov    rdi,r15
  409710:	xor    eax,eax
  409712:	call   4070c0 <closedir@plt>
  409717:	movsxd rdi,r13d
  40971a:	xor    eax,eax
  40971c:	call   407050 <close@plt>
  409721:	xor    eax,eax
  409723:	jmp    409786 <__swc_fn_0a4ed24b_000111_6814119b+0x5b6>
  409725:	xor    edi,edi
  409727:	mov    rsi,r12
  40972a:	mov    edx,0x3
  40972f:	mov    ecx,0x1
  409734:	mov    rax,rbx
  409737:	movsxd r8,DWORD PTR [rax]
  40973a:	xor    r9d,r9d
  40973d:	xor    eax,eax
  40973f:	call   4070e0 <mmap@plt>
  409744:	mov    r12,rax
  409747:	cmp    rax,0xffffffffffffffff
  40974b:	jne    40976f <__swc_fn_0a4ed24b_000111_6814119b+0x59f>
  40974d:	movsxd rdi,DWORD PTR [rbx]
  409750:	xor    eax,eax
  409752:	call   407050 <close@plt>
  409757:	mov    rdi,r15
  40975a:	xor    eax,eax
  40975c:	call   4070c0 <closedir@plt>
  409761:	movsxd rdi,r13d
  409764:	xor    eax,eax
  409766:	call   407050 <close@plt>
  40976b:	xor    eax,eax
  40976d:	jmp    409786 <__swc_fn_0a4ed24b_000111_6814119b+0x5b6>
  40976f:	mov    rdi,r15
  409772:	xor    eax,eax
  409774:	call   4070c0 <closedir@plt>
  409779:	movsxd rdi,r13d
  40977c:	xor    eax,eax
  40977e:	call   407050 <close@plt>
  409783:	mov    rax,r12
  409786:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40978f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  409798:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  4097a1:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  4097aa:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  4097b3:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  4097bc:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  4097c5:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  4097ce:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  4097d7:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  4097e0:	add    rsp,0x170
  4097e7:	pop    r15
  4097e9:	pop    r14
  4097eb:	pop    r13
  4097ed:	pop    rsi
  4097ee:	pop    rdi
  4097ef:	pop    r12
  4097f1:	pop    rbx
  4097f2:	ret
	...

0000000000409800 <__swc_fn_0a4ed24b_000114_5f48311c>:
  409800:	push   rsi
  409801:	push   rdi
  409802:	push   r12
  409804:	push   r13
  409806:	sub    rsp,0x8
  40980a:	mov    rsi,r8
  40980d:	mov    rdi,rcx
  409810:	mov    r12,rdx
  409813:	call   40da00 <__swc_fn_0a4ed24b_000112_126150d1>
  409818:	mov    r13,rax
  40981b:	test   rax,rax
  40981e:	jne    40982b <__swc_fn_0a4ed24b_000114_5f48311c+0x2b>
  409820:	add    rsp,0x8
  409824:	pop    r13
  409826:	pop    r12
  409828:	pop    rdi
  409829:	pop    rsi
  40982a:	ret
  40982b:	mov    rcx,r13
  40982e:	call   4118d0 <__swc_fn_0a4ed24b_000137_8c07c14b>
  409833:	mov    rax,QWORD PTR [r13+0x8]
  409837:	test   rax,rax
  40983a:	je     409879 <__swc_fn_0a4ed24b_000114_5f48311c+0x79>
  40983c:	nop    DWORD PTR [rax+0x0]
  409840:	lea    rcx,[rax+0x1000]
  409847:	cmp    rdi,rcx
  40984a:	jne    409871 <__swc_fn_0a4ed24b_000114_5f48311c+0x71>
  40984c:	cmp    r12,0x1000
  409853:	jb     409871 <__swc_fn_0a4ed24b_000114_5f48311c+0x71>
  409855:	test   sil,sil
  409858:	setne  cl
  40985b:	mov    BYTE PTR [rax+0x10],cl
  40985e:	mov    rcx,r13
  409861:	call   409d60 <__swc_fn_0a4ed24b_000138_715e84ff>
  409866:	add    rsp,0x8
  40986a:	pop    r13
  40986c:	pop    r12
  40986e:	pop    rdi
  40986f:	pop    rsi
  409870:	ret
  409871:	mov    rax,QWORD PTR [rax]
  409874:	test   rax,rax
  409877:	jne    409840 <__swc_fn_0a4ed24b_000114_5f48311c+0x40>
  409879:	mov    rcx,r13
  40987c:	call   409d60 <__swc_fn_0a4ed24b_000138_715e84ff>
  409881:	add    rsp,0x8
  409885:	pop    r13
  409887:	pop    r12
  409889:	pop    rdi
  40988a:	pop    rsi
  40988b:	ret
  40988c:	add    BYTE PTR [rax],al
	...

0000000000409890 <__swc_fn_0a4ed24b_000117_ed2d8fed>:
  409890:	sub    rsp,0x8
  409894:	test   rcx,rcx
  409897:	jne    40989e <__swc_fn_0a4ed24b_000117_ed2d8fed+0xe>
  409899:	add    rsp,0x8
  40989d:	ret
  40989e:	call   4113e0 <__swc_fn_0a4ed24b_000119_d3318640>
  4098a3:	add    rsp,0x8
  4098a7:	ret
	...

00000000004098b0 <__swc_fn_0a4ed24b_000120_2648f149>:
  4098b0:	push   r12
  4098b2:	push   r13
  4098b4:	push   r14
  4098b6:	push   rdi
  4098b7:	push   rsi
  4098b8:	sub    rsp,0xc0
  4098bf:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4098c5:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4098cb:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4098d1:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4098d7:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4098dd:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4098e3:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4098e9:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4098f2:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4098fb:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409904:	mov    r12,QWORD PTR [rcx]
  409907:	test   r12,r12
  40990a:	jne    40991c <__swc_fn_0a4ed24b_000120_2648f149+0x6c>
  40990c:	add    rsp,0xc0
  409913:	pop    rsi
  409914:	pop    rdi
  409915:	pop    r14
  409917:	pop    r13
  409919:	pop    r12
  40991b:	ret
  40991c:	xor    r13d,r13d
  40991f:	mov    r14,QWORD PTR [rcx+0x8]
  409923:	cs nop WORD PTR [rax+rax*1+0x0]
  40992d:	nop    DWORD PTR [rax]
  409930:	cmp    r13,r14
  409933:	jae    40996b <__swc_fn_0a4ed24b_000120_2648f149+0xbb>
  409935:	lea    rax,[r12+r13*1]
  409939:	mov    rcx,r14
  40993c:	sub    rcx,r13
  40993f:	mov    edi,0x1
  409944:	mov    rsi,rax
  409947:	mov    rdx,rcx
  40994a:	xor    eax,eax
  40994c:	call   407110 <write@plt>
  409951:	test   rax,rax
  409954:	jle    40995b <__swc_fn_0a4ed24b_000120_2648f149+0xab>
  409956:	add    r13,rax
  409959:	jmp    409930 <__swc_fn_0a4ed24b_000120_2648f149+0x80>
  40995b:	je     409969 <__swc_fn_0a4ed24b_000120_2648f149+0xb9>
  40995d:	xor    eax,eax
  40995f:	call   407040 <__errno_location@plt>
  409964:	cmp    DWORD PTR [rax],0x4
  409967:	je     409930 <__swc_fn_0a4ed24b_000120_2648f149+0x80>
  409969:	jmp    40996b <__swc_fn_0a4ed24b_000120_2648f149+0xbb>
  40996b:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409971:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409977:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40997d:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409983:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409989:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40998f:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409995:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40999e:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4099a7:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4099b0:	add    rsp,0xc0
  4099b7:	pop    rsi
  4099b8:	pop    rdi
  4099b9:	pop    r14
  4099bb:	pop    r13
  4099bd:	pop    r12
  4099bf:	ret

00000000004099c0 <__swc_fn_0a4ed24b_000123_4f256d58>:
  4099c0:	push   rbx
  4099c1:	push   r12
  4099c3:	push   rdi
  4099c4:	push   rsi
  4099c5:	sub    rsp,0x4a8
  4099cc:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  4099d5:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  4099de:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  4099e7:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  4099f0:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  4099f9:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  409a02:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  409a0b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  409a14:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  409a1d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  409a26:	mov    rbx,rdx
  409a29:	mov    r12d,ecx
  409a2c:	vxorps xmm0,xmm0,xmm0
  409a30:	xor    eax,eax
  409a32:	cs nop WORD PTR [rax+rax*1+0x0]
  409a3c:	nop    DWORD PTR [rax+0x0]
  409a40:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  409a46:	add    rax,0x10
  409a4a:	cmp    rax,0x400
  409a51:	jne    409a40 <__swc_fn_0a4ed24b_000123_4f256d58+0x80>
  409a53:	lea    rdi,[rsp+0x8]
  409a58:	mov    esi,0x80
  409a5d:	xor    eax,eax
  409a5f:	call   407120 <backtrace@plt>
  409a64:	test   eax,eax
  409a66:	jle    409a75 <__swc_fn_0a4ed24b_000123_4f256d58+0xb5>
  409a68:	movsxd rax,eax
  409a6b:	lea    rcx,[r12+0x1]
  409a70:	cmp    rcx,rax
  409a73:	jb     409a79 <__swc_fn_0a4ed24b_000123_4f256d58+0xb9>
  409a75:	xor    eax,eax
  409a77:	jmp    409aaa <__swc_fn_0a4ed24b_000123_4f256d58+0xea>
  409a79:	mov    rcx,QWORD PTR [rbx+0x8]
  409a7d:	sub    rax,r12
  409a80:	lea    rsi,[rax-0x1]
  409a84:	cmp    rcx,rsi
  409a87:	cmovbe rsi,rcx
  409a8b:	lea    eax,[r12+0x1]
  409a90:	lea    rax,[rsp+rax*8+0x8]
  409a95:	mov    rcx,QWORD PTR [rbx]
  409a98:	mov    rdx,rax
  409a9b:	lea    r8,[rsi*8+0x0]
  409aa3:	call   40d9e0 <__swc_fn_0a4ed24b_000109_7c204aac>
  409aa8:	mov    eax,esi
  409aaa:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  409ab3:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  409abc:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  409ac5:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  409ace:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  409ad7:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  409ae0:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  409ae9:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  409af2:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  409afb:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  409b04:	add    rsp,0x4a8
  409b0b:	pop    rsi
  409b0c:	pop    rdi
  409b0d:	pop    r12
  409b0f:	pop    rbx
  409b10:	ret
	...

0000000000409b20 <__swc_fn_0a4ed24b_000126_fcd5a289>:
  409b20:	mov    QWORD PTR [rcx],0x0
  409b27:	ret
	...

0000000000409b30 <__swc_fn_0a4ed24b_000129_4bbe3f14>:
  409b30:	push   rdi
  409b31:	push   rsi
  409b32:	sub    rsp,0xa8
  409b39:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409b3f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409b45:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409b4b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409b51:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409b57:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409b5d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409b63:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409b69:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409b72:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409b7b:	mov    edi,ecx
  409b7d:	mov    rsi,rdx
  409b80:	xor    eax,eax
  409b82:	call   407130 <pthread_setspecific@plt>
  409b87:	test   eax,eax
  409b89:	sete   al
  409b8c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409b92:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409b98:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409b9e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409ba4:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409baa:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409bb0:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409bb6:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409bbc:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409bc5:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409bce:	add    rsp,0xa8
  409bd5:	pop    rsi
  409bd6:	pop    rdi
  409bd7:	ret
	...

0000000000409be0 <__swc_fn_0a4ed24b_000132_5f757033>:
  409be0:	push   rdi
  409be1:	push   rsi
  409be2:	sub    rsp,0xa8
  409be9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409bef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409bf5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409bfb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409c01:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409c07:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409c0d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409c13:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409c19:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409c22:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409c2b:	test   rcx,rcx
  409c2e:	je     409c41 <__swc_fn_0a4ed24b_000132_5f757033+0x61>
  409c30:	lea    rax,[rcx-0x1]
  409c34:	mov    eax,eax
  409c36:	mov    edi,eax
  409c38:	xor    eax,eax
  409c3a:	call   407010 <pthread_getspecific@plt>
  409c3f:	jmp    409c43 <__swc_fn_0a4ed24b_000132_5f757033+0x63>
  409c41:	xor    eax,eax
  409c43:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409c49:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409c4f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409c55:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409c5b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409c61:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409c67:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409c6d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409c73:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409c7c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409c85:	add    rsp,0xa8
  409c8c:	pop    rsi
  409c8d:	pop    rdi
  409c8e:	ret
	...

0000000000409c90 <__swc_fn_0a4ed24b_000135_07d76562>:
  409c90:	push   rdi
  409c91:	push   rsi
  409c92:	sub    rsp,0xb8
  409c99:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409c9f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409ca5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409cab:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409cb1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409cb7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409cbd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409cc3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409ccc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409cd5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409cde:	vxorps xmm0,xmm0,xmm0
  409ce2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409ce8:	mov    edi,0x1
  409ced:	lea    rsi,[rsp+0x8]
  409cf2:	xor    eax,eax
  409cf4:	call   407000 <clock_gettime@plt>
  409cf9:	mov    rax,QWORD PTR [rsp+0x8]
  409cfe:	imul   rax,rax,0x3b9aca00
  409d05:	add    rax,QWORD PTR [rsp+0x10]
  409d0a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409d10:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409d16:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409d1c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409d22:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409d28:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409d2e:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409d34:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409d3d:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409d46:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409d4f:	add    rsp,0xb8
  409d56:	pop    rsi
  409d57:	pop    rdi
  409d58:	ret
  409d59:	add    BYTE PTR [rax],al
  409d5b:	add    BYTE PTR [rax],al
  409d5d:	add    BYTE PTR [rax],al
	...

0000000000409d60 <__swc_fn_0a4ed24b_000138_715e84ff>:
  409d60:	sub    rsp,0x8
  409d64:	xor    eax,eax
  409d66:	mov    DWORD PTR [rcx],eax
  409d68:	mov    edx,0x7fffffff
  409d6d:	call   40e0e0 <__swc_fn_0a4ed24b_000136_865f5106>
  409d72:	add    rsp,0x8
  409d76:	ret
	...

0000000000409d80 <__swc_fn_0a4ed24b_000141_519fdf94>:
  409d80:	push   rdi
  409d81:	push   rsi
  409d82:	sub    rsp,0xb8
  409d89:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409d8f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409d95:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409d9b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409da1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409da7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409dad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409db3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409dbc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409dc5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409dce:	mov    edi,0x1
  409dd3:	xor    eax,eax
  409dd5:	call   407140 <__x86_get_cpuid_feature_leaf@plt>
  409dda:	mov    eax,DWORD PTR [rax+0x14]
  409ddd:	and    eax,0x20
  409de0:	setne  al
  409de3:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409de9:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409def:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409df5:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409dfb:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409e01:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409e07:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409e0d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409e16:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409e1f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409e28:	add    rsp,0xb8
  409e2f:	pop    rsi
  409e30:	pop    rdi
  409e31:	ret
	...

0000000000409e40 <__swc_fn_0a4ed24b_000144_d5d4d43f>:
  409e40:	push   rsi
  409e41:	push   rdi
  409e42:	push   r12
  409e44:	push   r13
  409e46:	push   r14
  409e48:	push   r15
  409e4a:	cmp    rdx,0x40
  409e4e:	jae    409e5d <__swc_fn_0a4ed24b_000144_d5d4d43f+0x1d>
  409e50:	xor    eax,eax
  409e52:	pop    r15
  409e54:	pop    r14
  409e56:	pop    r13
  409e58:	pop    r12
  409e5a:	pop    rdi
  409e5b:	pop    rsi
  409e5c:	ret
  409e5d:	cmp    BYTE PTR [rcx],0x7f
  409e60:	jne    409ea4 <__swc_fn_0a4ed24b_000144_d5d4d43f+0x64>
  409e62:	movzx  eax,BYTE PTR [rcx+0x1]
  409e66:	cmp    eax,0x45
  409e69:	setne  al
  409e6c:	jne    409ea0 <__swc_fn_0a4ed24b_000144_d5d4d43f+0x60>
  409e6e:	movzx  eax,BYTE PTR [rcx+0x2]
  409e72:	cmp    eax,0x4c
  409e75:	setne  al
  409e78:	jne    409ea0 <__swc_fn_0a4ed24b_000144_d5d4d43f+0x60>
  409e7a:	movzx  eax,BYTE PTR [rcx+0x3]
  409e7e:	cmp    eax,0x46
  409e81:	setne  al
  409e84:	jne    409ea0 <__swc_fn_0a4ed24b_000144_d5d4d43f+0x60>
  409e86:	cmp    BYTE PTR [rcx+0x4],0x2
  409e8a:	setne  al
  409e8d:	jne    409ea0 <__swc_fn_0a4ed24b_000144_d5d4d43f+0x60>
  409e8f:	cmp    BYTE PTR [rcx+0x5],0x1
  409e93:	setne  al
  409e96:	jne    409ea0 <__swc_fn_0a4ed24b_000144_d5d4d43f+0x60>
  409e98:	cmp    WORD PTR [rcx+0x12],0x3e
  409e9d:	setne  al
  409ea0:	test   al,al
  409ea2:	je     409eb1 <__swc_fn_0a4ed24b_000144_d5d4d43f+0x71>
  409ea4:	xor    eax,eax
  409ea6:	pop    r15
  409ea8:	pop    r14
  409eaa:	pop    r13
  409eac:	pop    r12
  409eae:	pop    rdi
  409eaf:	pop    rsi
  409eb0:	ret
  409eb1:	cmp    WORD PTR [rcx+0x3a],0x40
  409eb6:	jne    409ed1 <__swc_fn_0a4ed24b_000144_d5d4d43f+0x91>
  409eb8:	cmp    WORD PTR [rcx+0x3c],0x0
  409ebd:	sete   al
  409ec0:	je     409ecd <__swc_fn_0a4ed24b_000144_d5d4d43f+0x8d>
  409ec2:	mov    ax,WORD PTR [rcx+0x3c]
  409ec6:	cmp    WORD PTR [rcx+0x3e],ax
  409eca:	setae  al
  409ecd:	test   al,al
  409ecf:	je     409ede <__swc_fn_0a4ed24b_000144_d5d4d43f+0x9e>
  409ed1:	xor    eax,eax
  409ed3:	pop    r15
  409ed5:	pop    r14
  409ed7:	pop    r13
  409ed9:	pop    r12
  409edb:	pop    rdi
  409edc:	pop    rsi
  409edd:	ret
  409ede:	movzx  eax,WORD PTR [rcx+0x3c]
  409ee2:	shl    rax,0x6
  409ee6:	cmp    rax,rdx
  409ee9:	ja     409ef7 <__swc_fn_0a4ed24b_000144_d5d4d43f+0xb7>
  409eeb:	mov    r9,rdx
  409eee:	sub    r9,rax
  409ef1:	cmp    QWORD PTR [rcx+0x28],r9
  409ef5:	jbe    409f04 <__swc_fn_0a4ed24b_000144_d5d4d43f+0xc4>
  409ef7:	xor    eax,eax
  409ef9:	pop    r15
  409efb:	pop    r14
  409efd:	pop    r13
  409eff:	pop    r12
  409f01:	pop    rdi
  409f02:	pop    rsi
  409f03:	ret
  409f04:	mov    rax,QWORD PTR [rcx+0x28]
  409f08:	add    rax,rcx
  409f0b:	movzx  r9d,WORD PTR [rcx+0x3e]
  409f10:	lea    r9,[r9*8+0x0]
  409f18:	lea    r10,[rax+r9*8]
  409f1c:	cmp    QWORD PTR [r10+0x20],rdx
  409f20:	ja     409f42 <__swc_fn_0a4ed24b_000144_d5d4d43f+0x102>
  409f22:	mov    r11,rdx
  409f25:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  409f2a:	cmp    QWORD PTR [r10+0x18],r11
  409f2e:	seta   r9b
  409f32:	ja     409f3d <__swc_fn_0a4ed24b_000144_d5d4d43f+0xfd>
  409f34:	cmp    QWORD PTR [r10+0x20],0x9
  409f39:	setb   r9b
  409f3d:	test   r9b,r9b
  409f40:	je     409f4f <__swc_fn_0a4ed24b_000144_d5d4d43f+0x10f>
  409f42:	xor    eax,eax
  409f44:	pop    r15
  409f46:	pop    r14
  409f48:	pop    r13
  409f4a:	pop    r12
  409f4c:	pop    rdi
  409f4d:	pop    rsi
  409f4e:	ret
  409f4f:	movzx  r9d,WORD PTR [rcx+0x3c]
  409f54:	xor    r11d,r11d
  409f57:	test   r9,r9
  409f5a:	jbe    40a055 <__swc_fn_0a4ed24b_000144_d5d4d43f+0x215>
  409f60:	mov    rsi,QWORD PTR [r10+0x20]
  409f64:	sub    rsi,0x9
  409f68:	cs nop WORD PTR [rax+rax*1+0x0]
  409f72:	cs nop WORD PTR [rax+rax*1+0x0]
  409f7c:	nop    DWORD PTR [rax+0x0]
  409f80:	movzx  edi,r11w
  409f84:	lea    rdi,[rdi*8+0x0]
  409f8c:	lea    r12,[rax+rdi*8]
  409f90:	rex mov edi,DWORD PTR [rax+rdi*8]
  409f94:	cmp    rdi,rsi
  409f97:	ja     40a048 <__swc_fn_0a4ed24b_000144_d5d4d43f+0x208>
  409f9d:	mov    r13,QWORD PTR [r10+0x18]
  409fa1:	add    r13,rdi
  409fa4:	lea    rdi,[rcx+r13*1]
  409fa8:	lea    r13,[rip+0x9831]        # 4137e0 <__swc_rdata_base_0a4ed24b+0x6d0>
  409faf:	movabs r14,0x676264676177732e
  409fb9:	cmp    QWORD PTR [rdi],r14
  409fbc:	jne    409fc5 <__swc_fn_0a4ed24b_000144_d5d4d43f+0x185>
  409fbe:	rex cmp BYTE PTR [rdi+0x8],0x0
  409fc3:	je     409ff2 <__swc_fn_0a4ed24b_000144_d5d4d43f+0x1b2>
  409fc5:	cs nop WORD PTR [rax+rax*1+0x0]
  409fcf:	nop
  409fd0:	movzx  r14d,BYTE PTR [rdi]
  409fd4:	movzx  r15d,BYTE PTR [r13+0x0]
  409fd9:	cmp    r14,r15
  409fdc:	jne    409fe8 <__swc_fn_0a4ed24b_000144_d5d4d43f+0x1a8>
  409fde:	add    rdi,0x1
  409fe2:	add    r13,0x1
  409fe6:	jmp    409fd0 <__swc_fn_0a4ed24b_000144_d5d4d43f+0x190>
  409fe8:	mov    rdi,r14
  409feb:	sub    rdi,r15
  409fee:	test   edi,edi
  409ff0:	jne    40a048 <__swc_fn_0a4ed24b_000144_d5d4d43f+0x208>
  409ff2:	cmp    DWORD PTR [r12+0x4],0x1
  409ff8:	jne    40a020 <__swc_fn_0a4ed24b_000144_d5d4d43f+0x1e0>
  409ffa:	cmp    QWORD PTR [r12+0x20],0x10
  40a000:	setb   al
  40a003:	jb     40a01c <__swc_fn_0a4ed24b_000144_d5d4d43f+0x1dc>
  40a005:	cmp    QWORD PTR [r12+0x20],rdx
  40a00a:	seta   al
  40a00d:	ja     40a01c <__swc_fn_0a4ed24b_000144_d5d4d43f+0x1dc>
  40a00f:	sub    rdx,QWORD PTR [r12+0x20]
  40a014:	cmp    QWORD PTR [r12+0x18],rdx
  40a019:	seta   al
  40a01c:	test   al,al
  40a01e:	je     40a02d <__swc_fn_0a4ed24b_000144_d5d4d43f+0x1ed>
  40a020:	xor    eax,eax
  40a022:	pop    r15
  40a024:	pop    r14
  40a026:	pop    r13
  40a028:	pop    r12
  40a02a:	pop    rdi
  40a02b:	pop    rsi
  40a02c:	ret
  40a02d:	mov    rax,QWORD PTR [r12+0x20]
  40a032:	mov    QWORD PTR [r8],rax
  40a035:	mov    rax,QWORD PTR [r12+0x18]
  40a03a:	add    rax,rcx
  40a03d:	pop    r15
  40a03f:	pop    r14
  40a041:	pop    r13
  40a043:	pop    r12
  40a045:	pop    rdi
  40a046:	pop    rsi
  40a047:	ret
  40a048:	add    r11,0x1
  40a04c:	cmp    r11,r9
  40a04f:	jb     409f80 <__swc_fn_0a4ed24b_000144_d5d4d43f+0x140>
  40a055:	xor    eax,eax
  40a057:	pop    r15
  40a059:	pop    r14
  40a05b:	pop    r13
  40a05d:	pop    r12
  40a05f:	pop    rdi
  40a060:	pop    rsi
  40a061:	ret
	...

000000000040a070 <__swc_fn_0a4ed24b_000147_d7edc04f>:
  40a070:	push   rdi
  40a071:	push   rsi
  40a072:	sub    rsp,0xa8
  40a079:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40a07f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40a085:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40a08b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40a091:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40a097:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40a09d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40a0a3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40a0a9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a0b2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a0bb:	mov    rdi,rcx
  40a0be:	xor    eax,eax
  40a0c0:	call   407150 <free@plt>
  40a0c5:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a0cb:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a0d1:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a0d7:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a0dd:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a0e3:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a0e9:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a0ef:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a0f5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a0fe:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a107:	add    rsp,0xa8
  40a10e:	pop    rsi
  40a10f:	pop    rdi
  40a110:	ret
	...

000000000040a120 <__swc_fn_0a4ed24b_000150_6203dca2>:
  40a120:	push   rbx
  40a121:	push   rsi
  40a122:	push   rdi
  40a123:	push   r12
  40a125:	push   r13
  40a127:	push   r15
  40a129:	sub    rsp,0x4e8
  40a130:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  40a139:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  40a142:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  40a14b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  40a154:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  40a15d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  40a166:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  40a16f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  40a178:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  40a181:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  40a18a:	mov    rbx,QWORD PTR [rcx]
  40a18d:	mov    rcx,QWORD PTR [rcx+0x8]
  40a191:	mov    rsi,rcx
  40a194:	xor    edi,edi
  40a196:	vmovsd xmm6,QWORD PTR [rip+0x9692]        # 413830 <__swc_rdata_base_0a4ed24b+0x720>
  40a19e:	vmovsd xmm7,QWORD PTR [rip+0x9693]        # 413839 <__swc_rdata_base_0a4ed24b+0x729>
  40a1a6:	vmovsd xmm8,QWORD PTR [rip+0x9694]        # 413842 <__swc_rdata_base_0a4ed24b+0x732>
  40a1ae:	vmovsd xmm9,QWORD PTR [rip+0x9695]        # 41384b <__swc_rdata_base_0a4ed24b+0x73b>
  40a1b6:	vmovsd xmm10,QWORD PTR [rip+0x8f9f]        # 41315d <__swc_rdata_base_0a4ed24b+0x4d>
  40a1be:	vmovups xmm11,xmm6
  40a1c2:	vmovsd QWORD PTR [rsp+0x418],xmm7
  40a1cb:	vmovsd QWORD PTR [rsp+0x420],xmm8
  40a1d4:	vmovsd QWORD PTR [rsp+0x428],xmm9
  40a1dd:	vmovsd QWORD PTR [rsp+0x430],xmm10
  40a1e6:	vmovsd xmm15,QWORD PTR [rip+0x9666]        # 413854 <__swc_rdata_base_0a4ed24b+0x744>
  40a1ee:	vmovups xmm14,xmm15
  40a1f3:	vmovups xmm0,xmm9
  40a1f8:	vmovsd QWORD PTR [rsp+0x438],xmm15
  40a201:	vmovups xmm13,xmm8
  40a206:	vmovsd QWORD PTR [rsp+0x440],xmm15
  40a20f:	test   rsi,rsi
  40a212:	je     40b203 <__swc_fn_0a4ed24b_000150_6203dca2+0x10e3>
  40a218:	cs nop WORD PTR [rax+rax*1+0x0]
  40a222:	cs nop WORD PTR [rax+rax*1+0x0]
  40a22c:	nop    DWORD PTR [rax+0x0]
  40a230:	lea    rcx,[rdi+rdi*1]
  40a234:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  40a239:	vpshufd xmm3,xmm2,0xee
  40a23e:	vmovq  rcx,xmm3
  40a243:	test   rcx,rcx
  40a246:	je     40a25c <__swc_fn_0a4ed24b_000150_6203dca2+0x13c>
  40a248:	test   DWORD PTR [rcx+0x28],0x400000
  40a24f:	je     40a25c <__swc_fn_0a4ed24b_000150_6203dca2+0x13c>
  40a251:	mov    rdx,QWORD PTR [rcx+0x30]
  40a255:	test   rdx,rdx
  40a258:	cmovne rcx,rdx
  40a25c:	test   DWORD PTR [rcx+0x28],0x1000
  40a263:	je     40a284 <__swc_fn_0a4ed24b_000150_6203dca2+0x164>
  40a265:	mov    rdx,QWORD PTR [rcx+0x40]
  40a269:	mov    rcx,rdx
  40a26c:	vmovq  r8,xmm2
  40a271:	mov    r8,QWORD PTR [r8]
  40a274:	mov    QWORD PTR [rsp+0x60],r8
  40a279:	mov    QWORD PTR [rsp+0x68],rdx
  40a27e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  40a284:	test   BYTE PTR [rcx+0x28],0x1
  40a288:	jne    40a290 <__swc_fn_0a4ed24b_000150_6203dca2+0x170>
  40a28a:	vmovups xmm12,xmm0
  40a28e:	jmp    40a2aa <__swc_fn_0a4ed24b_000150_6203dca2+0x18a>
  40a290:	vmovq  rax,xmm2
  40a295:	mov    rax,QWORD PTR [rax]
  40a298:	lea    rcx,[rax+0x10]
  40a29c:	vmovups xmm12,xmm0
  40a2a0:	call   4098b0 <__swc_fn_0a4ed24b_000120_2648f149>
  40a2a5:	jmp    40b1e5 <__swc_fn_0a4ed24b_000150_6203dca2+0x10c5>
  40a2aa:	test   DWORD PTR [rcx+0x28],0x400
  40a2b1:	je     40a312 <__swc_fn_0a4ed24b_000150_6203dca2+0x1f2>
  40a2b3:	vmovq  rax,xmm2
  40a2b8:	mov    rax,QWORD PTR [rax]
  40a2bb:	xor    ecx,ecx
  40a2bd:	test   rax,rax
  40a2c0:	je     40a2f0 <__swc_fn_0a4ed24b_000150_6203dca2+0x1d0>
  40a2c2:	mov    rdx,rax
  40a2c5:	mov    r8b,BYTE PTR [rdx]
  40a2c8:	test   r8b,r8b
  40a2cb:	je     40a2f0 <__swc_fn_0a4ed24b_000150_6203dca2+0x1d0>
  40a2cd:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2d7:	nop    WORD PTR [rax+rax*1+0x0]
  40a2e0:	add    rdx,0x1
  40a2e4:	add    rcx,0x1
  40a2e8:	mov    r8b,BYTE PTR [rdx]
  40a2eb:	test   r8b,r8b
  40a2ee:	jne    40a2e0 <__swc_fn_0a4ed24b_000150_6203dca2+0x1c0>
  40a2f0:	mov    QWORD PTR [rsp+0x88],rax
  40a2f8:	mov    QWORD PTR [rsp+0x90],rcx
  40a300:	lea    rcx,[rsp+0x88]
  40a308:	call   4098b0 <__swc_fn_0a4ed24b_000120_2648f149>
  40a30d:	jmp    40b1e5 <__swc_fn_0a4ed24b_000150_6203dca2+0x10c5>
  40a312:	cmp    BYTE PTR [rcx+0x2c],0x6
  40a316:	jne    40a32d <__swc_fn_0a4ed24b_000150_6203dca2+0x20d>
  40a318:	vmovq  rax,xmm2
  40a31d:	mov    rax,QWORD PTR [rax]
  40a320:	mov    rcx,rax
  40a323:	call   40e5b0 <__swc_fn_0a4ed24b_000148_43c96957>
  40a328:	jmp    40b1e5 <__swc_fn_0a4ed24b_000150_6203dca2+0x10c5>
  40a32d:	cmp    BYTE PTR [rcx+0x2c],0x1
  40a331:	jne    40b1d9 <__swc_fn_0a4ed24b_000150_6203dca2+0x10b9>
  40a337:	vmovq  rdx,xmm2
  40a33c:	mov    cl,BYTE PTR [rcx+0x40]
  40a33f:	cmp    cl,0x7
  40a342:	jb     40a385 <__swc_fn_0a4ed24b_000150_6203dca2+0x265>
  40a344:	je     40a3f8 <__swc_fn_0a4ed24b_000150_6203dca2+0x2d8>
  40a34a:	cmp    cl,0x8
  40a34d:	je     40a404 <__swc_fn_0a4ed24b_000150_6203dca2+0x2e4>
  40a353:	cmp    cl,0x9
  40a356:	je     40a41d <__swc_fn_0a4ed24b_000150_6203dca2+0x2fd>
  40a35c:	cmp    cl,0xa
  40a35f:	je     40aae4 <__swc_fn_0a4ed24b_000150_6203dca2+0x9c4>
  40a365:	cmp    cl,0xb
  40a368:	je     40b1ab <__swc_fn_0a4ed24b_000150_6203dca2+0x108b>
  40a36e:	cmp    cl,0xc
  40a371:	je     40a411 <__swc_fn_0a4ed24b_000150_6203dca2+0x2f1>
  40a377:	cmp    cl,0xd
  40a37a:	je     40b1a1 <__swc_fn_0a4ed24b_000150_6203dca2+0x1081>
  40a380:	jmp    40b1cb <__swc_fn_0a4ed24b_000150_6203dca2+0x10ab>
  40a385:	cmp    cl,0x1
  40a388:	je     40a3a8 <__swc_fn_0a4ed24b_000150_6203dca2+0x288>
  40a38a:	cmp    cl,0x2
  40a38d:	je     40a3b6 <__swc_fn_0a4ed24b_000150_6203dca2+0x296>
  40a38f:	cmp    cl,0x3
  40a392:	je     40a3c4 <__swc_fn_0a4ed24b_000150_6203dca2+0x2a4>
  40a394:	cmp    cl,0x4
  40a397:	je     40a3d1 <__swc_fn_0a4ed24b_000150_6203dca2+0x2b1>
  40a399:	cmp    cl,0x5
  40a39c:	je     40a3de <__swc_fn_0a4ed24b_000150_6203dca2+0x2be>
  40a39e:	cmp    cl,0x6
  40a3a1:	je     40a3eb <__swc_fn_0a4ed24b_000150_6203dca2+0x2cb>
  40a3a3:	jmp    40b1cb <__swc_fn_0a4ed24b_000150_6203dca2+0x10ab>
  40a3a8:	movsx  rcx,BYTE PTR [rdx]
  40a3ac:	call   411ac0 <__swc_fn_0a4ed24b_000149_2eb804cc>
  40a3b1:	jmp    40b1e5 <__swc_fn_0a4ed24b_000150_6203dca2+0x10c5>
  40a3b6:	movsx  rcx,WORD PTR [rdx]
  40a3ba:	call   411ac0 <__swc_fn_0a4ed24b_000149_2eb804cc>
  40a3bf:	jmp    40b1e5 <__swc_fn_0a4ed24b_000150_6203dca2+0x10c5>
  40a3c4:	movsxd rcx,DWORD PTR [rdx]
  40a3c7:	call   411ac0 <__swc_fn_0a4ed24b_000149_2eb804cc>
  40a3cc:	jmp    40b1e5 <__swc_fn_0a4ed24b_000150_6203dca2+0x10c5>
  40a3d1:	mov    rcx,QWORD PTR [rdx]
  40a3d4:	call   411ac0 <__swc_fn_0a4ed24b_000149_2eb804cc>
  40a3d9:	jmp    40b1e5 <__swc_fn_0a4ed24b_000150_6203dca2+0x10c5>
  40a3de:	movzx  ecx,BYTE PTR [rdx]
  40a3e1:	call   40e5b0 <__swc_fn_0a4ed24b_000148_43c96957>
  40a3e6:	jmp    40b1e5 <__swc_fn_0a4ed24b_000150_6203dca2+0x10c5>
  40a3eb:	movzx  ecx,WORD PTR [rdx]
  40a3ee:	call   40e5b0 <__swc_fn_0a4ed24b_000148_43c96957>
  40a3f3:	jmp    40b1e5 <__swc_fn_0a4ed24b_000150_6203dca2+0x10c5>
  40a3f8:	mov    ecx,DWORD PTR [rdx]
  40a3fa:	call   40e5b0 <__swc_fn_0a4ed24b_000148_43c96957>
  40a3ff:	jmp    40b1e5 <__swc_fn_0a4ed24b_000150_6203dca2+0x10c5>
  40a404:	mov    rcx,QWORD PTR [rdx]
  40a407:	call   40e5b0 <__swc_fn_0a4ed24b_000148_43c96957>
  40a40c:	jmp    40b1e5 <__swc_fn_0a4ed24b_000150_6203dca2+0x10c5>
  40a411:	mov    ecx,DWORD PTR [rdx]
  40a413:	call   40e5b0 <__swc_fn_0a4ed24b_000148_43c96957>
  40a418:	jmp    40b1e5 <__swc_fn_0a4ed24b_000150_6203dca2+0x10c5>
  40a41d:	lea    rcx,[rsp+0xa8]
  40a425:	vxorps xmm0,xmm0,xmm0
  40a429:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  40a432:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  40a43b:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  40a444:	vzeroupper
  40a447:	mov    DWORD PTR [rsp+0x108],0x0
  40a452:	vxorpd xmm0,xmm0,xmm0
  40a456:	vmovss xmm1,DWORD PTR [rdx]
  40a45a:	vcvtss2sd xmm0,xmm0,xmm1
  40a45e:	vmovsd xmm1,xmm1,xmm0
  40a462:	vcomisd xmm0,xmm0
  40a466:	setne  dl
  40a469:	movzx  edx,dl
  40a46c:	setp   r8b
  40a470:	movzx  r8d,r8b
  40a474:	or     edx,r8d
  40a477:	test   dl,dl
  40a479:	je     40a486 <__swc_fn_0a4ed24b_000150_6203dca2+0x366>
  40a47b:	mov    DWORD PTR [rcx],0x6e616e
  40a481:	jmp    40aa78 <__swc_fn_0a4ed24b_000150_6203dca2+0x958>
  40a486:	vcomisd xmm1,xmm6
  40a48a:	ja     40a492 <__swc_fn_0a4ed24b_000150_6203dca2+0x372>
  40a48c:	vcomisd xmm7,xmm1
  40a490:	jbe    40a4b6 <__swc_fn_0a4ed24b_000150_6203dca2+0x396>
  40a492:	vxorpd xmm0,xmm0,xmm0
  40a496:	vcomisd xmm0,xmm1
  40a49a:	jbe    40a4ab <__swc_fn_0a4ed24b_000150_6203dca2+0x38b>
  40a49c:	mov    DWORD PTR [rcx],0x666e692d
  40a4a2:	mov    BYTE PTR [rcx+0x4],0x0
  40a4a6:	jmp    40aa78 <__swc_fn_0a4ed24b_000150_6203dca2+0x958>
  40a4ab:	mov    DWORD PTR [rcx],0x666e69
  40a4b1:	jmp    40aa78 <__swc_fn_0a4ed24b_000150_6203dca2+0x958>
  40a4b6:	vcomisd xmm1,xmm8
  40a4bb:	jae    40a4c7 <__swc_fn_0a4ed24b_000150_6203dca2+0x3a7>
  40a4bd:	vcomisd xmm9,xmm1
  40a4c1:	jbe    40a83e <__swc_fn_0a4ed24b_000150_6203dca2+0x71e>
  40a4c7:	vmovups xmm0,xmm1
  40a4cb:	vxorpd xmm2,xmm2,xmm2
  40a4cf:	vcomisd xmm2,xmm1
  40a4d3:	jbe    40a4e3 <__swc_fn_0a4ed24b_000150_6203dca2+0x3c3>
  40a4d5:	vmovsd xmm1,xmm1,xmm0
  40a4d9:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x8c3f]        # 413120 <__swc_rdata_base_0a4ed24b+0x10>
  40a4e1:	jmp    40a4e7 <__swc_fn_0a4ed24b_000150_6203dca2+0x3c7>
  40a4e3:	vmovsd xmm1,xmm1,xmm0
  40a4e7:	xor    r8d,r8d
  40a4ea:	vcomisd xmm1,xmm15
  40a4ef:	jb     40a510 <__swc_fn_0a4ed24b_000150_6203dca2+0x3f0>
  40a4f1:	cs nop WORD PTR [rax+rax*1+0x0]
  40a4fb:	nop    DWORD PTR [rax+rax*1+0x0]
  40a500:	vdivsd xmm1,xmm1,xmm15
  40a505:	add    r8,0x1
  40a509:	vcomisd xmm1,xmm15
  40a50e:	jae    40a500 <__swc_fn_0a4ed24b_000150_6203dca2+0x3e0>
  40a510:	mov    r9,rcx
  40a513:	vxorpd xmm2,xmm2,xmm2
  40a517:	vcomisd xmm2,xmm0
  40a51b:	jbe    40a524 <__swc_fn_0a4ed24b_000150_6203dca2+0x404>
  40a51d:	mov    BYTE PTR [rcx],0x2d
  40a520:	lea    r9,[rcx+0x1]
  40a524:	vcvttsd2si rdx,xmm1
  40a529:	mov    r10b,dl
  40a52c:	add    r10b,0x30
  40a530:	mov    BYTE PTR [r9],r10b
  40a533:	vxorpd xmm0,xmm0,xmm0
  40a537:	movzx  edx,dl
  40a53a:	vcvtsi2sd xmm0,xmm0,rdx
  40a53f:	vsubsd xmm0,xmm1,xmm0
  40a543:	vmulsd xmm1,xmm0,xmm15
  40a548:	mov    BYTE PTR [r9+0x1],0x2e
  40a54d:	vcvttsd2si rdx,xmm1
  40a552:	mov    r10b,dl
  40a555:	add    r10b,0x30
  40a559:	mov    BYTE PTR [r9+0x2],r10b
  40a55d:	vxorpd xmm0,xmm0,xmm0
  40a561:	movzx  edx,dl
  40a564:	vcvtsi2sd xmm0,xmm0,rdx
  40a569:	vsubsd xmm0,xmm1,xmm0
  40a56d:	vmulsd xmm1,xmm0,xmm15
  40a572:	vcvttsd2si rdx,xmm1
  40a577:	mov    r10b,dl
  40a57a:	add    r10b,0x30
  40a57e:	mov    BYTE PTR [r9+0x3],r10b
  40a582:	vxorpd xmm0,xmm0,xmm0
  40a586:	movzx  edx,dl
  40a589:	vcvtsi2sd xmm0,xmm0,rdx
  40a58e:	vsubsd xmm0,xmm1,xmm0
  40a592:	vmulsd xmm1,xmm0,xmm15
  40a597:	vcvttsd2si rdx,xmm1
  40a59c:	mov    r10b,dl
  40a59f:	add    r10b,0x30
  40a5a3:	mov    BYTE PTR [r9+0x4],r10b
  40a5a7:	vxorpd xmm0,xmm0,xmm0
  40a5ab:	movzx  edx,dl
  40a5ae:	vcvtsi2sd xmm0,xmm0,rdx
  40a5b3:	vsubsd xmm0,xmm1,xmm0
  40a5b7:	vmulsd xmm1,xmm0,xmm15
  40a5bc:	vcvttsd2si rdx,xmm1
  40a5c1:	mov    r10b,dl
  40a5c4:	add    r10b,0x30
  40a5c8:	mov    BYTE PTR [r9+0x5],r10b
  40a5cc:	vxorpd xmm0,xmm0,xmm0
  40a5d0:	movzx  edx,dl
  40a5d3:	vcvtsi2sd xmm0,xmm0,rdx
  40a5d8:	vsubsd xmm0,xmm1,xmm0
  40a5dc:	vmulsd xmm1,xmm0,xmm15
  40a5e1:	vcvttsd2si rdx,xmm1
  40a5e6:	mov    r10b,dl
  40a5e9:	add    r10b,0x30
  40a5ed:	mov    BYTE PTR [r9+0x6],r10b
  40a5f1:	vxorpd xmm0,xmm0,xmm0
  40a5f5:	movzx  edx,dl
  40a5f8:	vcvtsi2sd xmm0,xmm0,rdx
  40a5fd:	vsubsd xmm0,xmm1,xmm0
  40a601:	vmulsd xmm1,xmm0,xmm15
  40a606:	vcvttsd2si rdx,xmm1
  40a60b:	mov    r10b,dl
  40a60e:	add    r10b,0x30
  40a612:	mov    BYTE PTR [r9+0x7],r10b
  40a616:	vxorpd xmm0,xmm0,xmm0
  40a61a:	movzx  edx,dl
  40a61d:	vcvtsi2sd xmm0,xmm0,rdx
  40a622:	vsubsd xmm0,xmm1,xmm0
  40a626:	vmulsd xmm1,xmm0,xmm15
  40a62b:	vcvttsd2si rdx,xmm1
  40a630:	mov    r10b,dl
  40a633:	add    r10b,0x30
  40a637:	mov    BYTE PTR [r9+0x8],r10b
  40a63b:	vxorpd xmm0,xmm0,xmm0
  40a63f:	movzx  edx,dl
  40a642:	vcvtsi2sd xmm0,xmm0,rdx
  40a647:	vsubsd xmm0,xmm1,xmm0
  40a64b:	vmulsd xmm1,xmm0,xmm15
  40a650:	vcvttsd2si rdx,xmm1
  40a655:	mov    r10b,dl
  40a658:	add    r10b,0x30
  40a65c:	mov    BYTE PTR [r9+0x9],r10b
  40a660:	vxorpd xmm0,xmm0,xmm0
  40a664:	movzx  edx,dl
  40a667:	vcvtsi2sd xmm0,xmm0,rdx
  40a66c:	vsubsd xmm0,xmm1,xmm0
  40a670:	vmulsd xmm1,xmm0,xmm15
  40a675:	vcvttsd2si rdx,xmm1
  40a67a:	mov    r10b,dl
  40a67d:	add    r10b,0x30
  40a681:	mov    BYTE PTR [r9+0xa],r10b
  40a685:	vxorpd xmm0,xmm0,xmm0
  40a689:	movzx  edx,dl
  40a68c:	vcvtsi2sd xmm0,xmm0,rdx
  40a691:	vsubsd xmm0,xmm1,xmm0
  40a695:	vmulsd xmm1,xmm0,xmm15
  40a69a:	vcvttsd2si rdx,xmm1
  40a69f:	mov    r10b,dl
  40a6a2:	add    r10b,0x30
  40a6a6:	mov    BYTE PTR [r9+0xb],r10b
  40a6aa:	lea    r10,[r9+0x4]
  40a6ae:	vxorpd xmm0,xmm0,xmm0
  40a6b2:	movzx  edx,dl
  40a6b5:	vcvtsi2sd xmm0,xmm0,rdx
  40a6ba:	vsubsd xmm0,xmm1,xmm0
  40a6be:	vmulsd xmm1,xmm0,xmm15
  40a6c3:	vcvttsd2si rdx,xmm1
  40a6c8:	mov    r11b,dl
  40a6cb:	add    r11b,0x30
  40a6cf:	mov    BYTE PTR [r9+0xc],r11b
  40a6d3:	vxorpd xmm0,xmm0,xmm0
  40a6d7:	movzx  edx,dl
  40a6da:	vcvtsi2sd xmm0,xmm0,rdx
  40a6df:	vsubsd xmm0,xmm1,xmm0
  40a6e3:	vmulsd xmm1,xmm0,xmm15
  40a6e8:	vcvttsd2si rdx,xmm1
  40a6ed:	mov    r11b,dl
  40a6f0:	add    r11b,0x30
  40a6f4:	mov    BYTE PTR [r9+0xd],r11b
  40a6f8:	lea    r10,[r10+0x2]
  40a6fc:	vxorpd xmm0,xmm0,xmm0
  40a700:	movzx  edx,dl
  40a703:	vcvtsi2sd xmm0,xmm0,rdx
  40a708:	vsubsd xmm0,xmm1,xmm0
  40a70c:	vmulsd xmm1,xmm0,xmm15
  40a711:	vcvttsd2si rdx,xmm1
  40a716:	mov    r11b,dl
  40a719:	add    r11b,0x30
  40a71d:	mov    BYTE PTR [r9+0xe],r11b
  40a721:	vxorpd xmm0,xmm0,xmm0
  40a725:	movzx  edx,dl
  40a728:	vcvtsi2sd xmm0,xmm0,rdx
  40a72d:	vsubsd xmm0,xmm1,xmm0
  40a731:	vmulsd xmm1,xmm0,xmm15
  40a736:	vcvttsd2si rdx,xmm1
  40a73b:	mov    r11b,dl
  40a73e:	add    r11b,0x30
  40a742:	mov    BYTE PTR [r9+0xf],r11b
  40a746:	lea    r10,[r10+0x2]
  40a74a:	lea    r10,[r10+0x2]
  40a74e:	lea    r10,[r10+0x2]
  40a752:	lea    r10,[r10+0x2]
  40a756:	lea    r10,[r10+0x2]
  40a75a:	vxorpd xmm0,xmm0,xmm0
  40a75e:	movzx  edx,dl
  40a761:	vcvtsi2sd xmm0,xmm0,rdx
  40a766:	vsubsd xmm0,xmm1,xmm0
  40a76a:	vmulsd xmm1,xmm0,xmm15
  40a76f:	vcvttsd2si rdx,xmm1
  40a774:	mov    r11b,dl
  40a777:	add    r11b,0x30
  40a77b:	mov    BYTE PTR [r9+0x10],r11b
  40a77f:	vxorpd xmm0,xmm0,xmm0
  40a783:	movzx  edx,dl
  40a786:	vcvtsi2sd xmm0,xmm0,rdx
  40a78b:	vsubsd xmm0,xmm1,xmm0
  40a78f:	vmulsd xmm1,xmm0,xmm15
  40a794:	vcvttsd2si rdx,xmm1
  40a799:	add    dl,0x30
  40a79c:	mov    BYTE PTR [r9+0x11],dl
  40a7a0:	mov    BYTE PTR [r10+0x2],0x65
  40a7a5:	lea    r9,[r10+0x3]
  40a7a9:	test   r8,r8
  40a7ac:	jl     40a7b5 <__swc_fn_0a4ed24b_000150_6203dca2+0x695>
  40a7ae:	mov    BYTE PTR [r9],0x2b
  40a7b2:	inc    r9
  40a7b5:	mov    r10,r9
  40a7b8:	mov    rdx,r8
  40a7bb:	nop    DWORD PTR [rax+rax*1+0x0]
  40a7c0:	mov    r11,rdx
  40a7c3:	movabs rdx,0x6666666666666667
  40a7cd:	mov    rax,r11
  40a7d0:	imul   rdx
  40a7d3:	sar    rdx,0x2
  40a7d7:	mov    r12,rdx
  40a7da:	shr    rdx,0x3f
  40a7de:	add    r12,rdx
  40a7e1:	mov    rdx,r12
  40a7e4:	imul   r13,r12,0xa
  40a7e8:	sub    r11,r13
  40a7eb:	mov    r13,QWORD PTR [rip+0x8ffe]        # 4137f0 <__swc_rdata_base_0a4ed24b+0x6e0>
  40a7f2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40a7f7:	mov    BYTE PTR [r10],r11b
  40a7fa:	lea    r11,[r10+0x1]
  40a7fe:	mov    r10,r11
  40a801:	test   r12,r12
  40a804:	jne    40a7c0 <__swc_fn_0a4ed24b_000150_6203dca2+0x6a0>
  40a806:	test   r8,r8
  40a809:	jge    40a813 <__swc_fn_0a4ed24b_000150_6203dca2+0x6f3>
  40a80b:	mov    BYTE PTR [r11],0x2d
  40a80f:	lea    r10,[r11+0x1]
  40a813:	mov    BYTE PTR [r10],0x0
  40a817:	sub    r10,0x1
  40a81b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a820:	cmp    r9,r10
  40a823:	jae    40aa78 <__swc_fn_0a4ed24b_000150_6203dca2+0x958>
  40a829:	mov    al,BYTE PTR [r10]
  40a82c:	mov    dl,BYTE PTR [r9]
  40a82f:	mov    BYTE PTR [r10],dl
  40a832:	sub    r10,0x1
  40a836:	mov    BYTE PTR [r9],al
  40a839:	inc    r9
  40a83c:	jmp    40a820 <__swc_fn_0a4ed24b_000150_6203dca2+0x700>
  40a83e:	vcvttsd2si rdx,xmm1
  40a843:	mov    r8,rdx
  40a846:	vxorpd xmm0,xmm0,xmm0
  40a84a:	vcvtsi2sd xmm0,xmm0,rdx
  40a84f:	vsubsd xmm0,xmm1,xmm0
  40a853:	mov    r9d,0x8
  40a859:	vxorpd xmm2,xmm2,xmm2
  40a85d:	vcomisd xmm2,xmm0
  40a861:	jbe    40a86b <__swc_fn_0a4ed24b_000150_6203dca2+0x74b>
  40a863:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x88b5]        # 413120 <__swc_rdata_base_0a4ed24b+0x10>
  40a86b:	test   r9d,r9d
  40a86e:	je     40a87a <__swc_fn_0a4ed24b_000150_6203dca2+0x75a>
  40a870:	vmulsd xmm0,xmm0,xmm14
  40a875:	dec    r9d
  40a878:	jne    40a870 <__swc_fn_0a4ed24b_000150_6203dca2+0x750>
  40a87a:	vcvttsd2si r9,xmm0
  40a87f:	mov    r10,r9
  40a882:	vxorpd xmm2,xmm2,xmm2
  40a886:	vcvtsi2sd xmm2,xmm2,r9
  40a88b:	vsubsd xmm0,xmm0,xmm2
  40a88f:	vcomisd xmm0,xmm10
  40a894:	lea    r9,[r9+0x1]
  40a898:	cmova  r10,r9
  40a89c:	cmp    r10,0x5f5e100
  40a8a3:	jne    40a8bc <__swc_fn_0a4ed24b_000150_6203dca2+0x79c>
  40a8a5:	lea    r8,[rdx-0x1]
  40a8a9:	vxorpd xmm0,xmm0,xmm0
  40a8ad:	vcomisd xmm0,xmm1
  40a8b1:	lea    rdx,[rdx+0x1]
  40a8b5:	cmovbe r8,rdx
  40a8b9:	xor    r10d,r10d
  40a8bc:	mov    r9,rcx
  40a8bf:	test   r8,r8
  40a8c2:	jne    40a8e2 <__swc_fn_0a4ed24b_000150_6203dca2+0x7c2>
  40a8c4:	vxorpd xmm0,xmm0,xmm0
  40a8c8:	vcomisd xmm0,xmm1
  40a8cc:	jbe    40a8d5 <__swc_fn_0a4ed24b_000150_6203dca2+0x7b5>
  40a8ce:	mov    BYTE PTR [rcx],0x2d
  40a8d1:	lea    r9,[rcx+0x1]
  40a8d5:	mov    BYTE PTR [r9],0x30
  40a8d9:	add    r9,0x1
  40a8dd:	jmp    40a97b <__swc_fn_0a4ed24b_000150_6203dca2+0x85b>
  40a8e2:	mov    r9,rcx
  40a8e5:	mov    rdx,r8
  40a8e8:	nop    DWORD PTR [rax+rax*1+0x0]
  40a8f0:	mov    r11,rdx
  40a8f3:	movabs rdx,0x6666666666666667
  40a8fd:	mov    r15,rax
  40a900:	mov    rax,r11
  40a903:	imul   rdx
  40a906:	mov    r12,rdx
  40a909:	mov    rax,r15
  40a90c:	sar    r12,0x2
  40a910:	mov    rdx,r12
  40a913:	shr    rdx,0x3f
  40a917:	add    r12,rdx
  40a91a:	mov    rdx,r12
  40a91d:	imul   r13,r12,0xa
  40a921:	sub    r11,r13
  40a924:	mov    r13,QWORD PTR [rip+0x8ec5]        # 4137f0 <__swc_rdata_base_0a4ed24b+0x6e0>
  40a92b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40a930:	mov    BYTE PTR [r9],r11b
  40a933:	lea    r11,[r9+0x1]
  40a937:	mov    r9,r11
  40a93a:	test   r12,r12
  40a93d:	jne    40a8f0 <__swc_fn_0a4ed24b_000150_6203dca2+0x7d0>
  40a93f:	test   r8,r8
  40a942:	jge    40a94c <__swc_fn_0a4ed24b_000150_6203dca2+0x82c>
  40a944:	mov    BYTE PTR [r11],0x2d
  40a948:	lea    r9,[r11+0x1]
  40a94c:	mov    rdx,r9
  40a94f:	mov    BYTE PTR [r9],0x0
  40a953:	sub    r9,0x1
  40a957:	mov    r8,rcx
  40a95a:	cmp    r8,r9
  40a95d:	jae    40a978 <__swc_fn_0a4ed24b_000150_6203dca2+0x858>
  40a95f:	nop
  40a960:	mov    r11b,BYTE PTR [r9]
  40a963:	mov    r12b,BYTE PTR [r8]
  40a966:	mov    BYTE PTR [r9],r12b
  40a969:	sub    r9,0x1
  40a96d:	mov    BYTE PTR [r8],r11b
  40a970:	inc    r8
  40a973:	cmp    r8,r9
  40a976:	jb     40a960 <__swc_fn_0a4ed24b_000150_6203dca2+0x840>
  40a978:	mov    r9,rdx
  40a97b:	mov    BYTE PTR [r9],0x2e
  40a97f:	add    r9,0x1
  40a983:	xor    r8d,r8d
  40a986:	test   r10,r10
  40a989:	je     40a9cf <__swc_fn_0a4ed24b_000150_6203dca2+0x8af>
  40a98b:	mov    r11d,0x989680
  40a991:	cmp    r10,r11
  40a994:	jge    40a9cf <__swc_fn_0a4ed24b_000150_6203dca2+0x8af>
  40a996:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9a0:	inc    r8d
  40a9a3:	movabs rdx,0x6666666666666667
  40a9ad:	mov    r15,rax
  40a9b0:	mov    rax,r11
  40a9b3:	imul   rdx
  40a9b6:	mov    r11,rdx
  40a9b9:	mov    rax,r15
  40a9bc:	sar    r11,0x2
  40a9c0:	mov    rdx,r11
  40a9c3:	shr    rdx,0x3f
  40a9c7:	add    r11,rdx
  40a9ca:	cmp    r10,r11
  40a9cd:	jl     40a9a0 <__swc_fn_0a4ed24b_000150_6203dca2+0x880>
  40a9cf:	test   r8d,r8d
  40a9d2:	je     40a9ed <__swc_fn_0a4ed24b_000150_6203dca2+0x8cd>
  40a9d4:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9de:	xchg   ax,ax
  40a9e0:	mov    BYTE PTR [r9],0x30
  40a9e4:	add    r9,0x1
  40a9e8:	dec    r8d
  40a9eb:	jne    40a9e0 <__swc_fn_0a4ed24b_000150_6203dca2+0x8c0>
  40a9ed:	mov    r8,r9
  40a9f0:	mov    rdx,r10
  40a9f3:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9fd:	nop    DWORD PTR [rax]
  40aa00:	mov    r11,rdx
  40aa03:	movabs rdx,0x6666666666666667
  40aa0d:	mov    rax,r11
  40aa10:	imul   rdx
  40aa13:	sar    rdx,0x2
  40aa17:	mov    r12,rdx
  40aa1a:	shr    rdx,0x3f
  40aa1e:	add    r12,rdx
  40aa21:	mov    rdx,r12
  40aa24:	imul   r13,r12,0xa
  40aa28:	sub    r11,r13
  40aa2b:	mov    r13,QWORD PTR [rip+0x8dbe]        # 4137f0 <__swc_rdata_base_0a4ed24b+0x6e0>
  40aa32:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40aa37:	mov    BYTE PTR [r8],r11b
  40aa3a:	lea    r11,[r8+0x1]
  40aa3e:	mov    r8,r11
  40aa41:	test   r12,r12
  40aa44:	jne    40aa00 <__swc_fn_0a4ed24b_000150_6203dca2+0x8e0>
  40aa46:	test   r10,r10
  40aa49:	jge    40aa53 <__swc_fn_0a4ed24b_000150_6203dca2+0x933>
  40aa4b:	mov    BYTE PTR [r11],0x2d
  40aa4f:	lea    r8,[r11+0x1]
  40aa53:	mov    BYTE PTR [r8],0x0
  40aa57:	sub    r8,0x1
  40aa5b:	cmp    r9,r8
  40aa5e:	jae    40aa78 <__swc_fn_0a4ed24b_000150_6203dca2+0x958>
  40aa60:	mov    al,BYTE PTR [r8]
  40aa63:	mov    dl,BYTE PTR [r9]
  40aa66:	mov    BYTE PTR [r8],dl
  40aa69:	sub    r8,0x1
  40aa6d:	mov    BYTE PTR [r9],al
  40aa70:	inc    r9
  40aa73:	cmp    r9,r8
  40aa76:	jb     40aa60 <__swc_fn_0a4ed24b_000150_6203dca2+0x940>
  40aa78:	xor    eax,eax
  40aa7a:	test   rcx,rcx
  40aa7d:	je     40aab0 <__swc_fn_0a4ed24b_000150_6203dca2+0x990>
  40aa7f:	mov    rdx,rcx
  40aa82:	mov    r8b,BYTE PTR [rdx]
  40aa85:	test   r8b,r8b
  40aa88:	je     40aab0 <__swc_fn_0a4ed24b_000150_6203dca2+0x990>
  40aa8a:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa94:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa9e:	xchg   ax,ax
  40aaa0:	add    rdx,0x1
  40aaa4:	add    rax,0x1
  40aaa8:	mov    r8b,BYTE PTR [rdx]
  40aaab:	test   r8b,r8b
  40aaae:	jne    40aaa0 <__swc_fn_0a4ed24b_000150_6203dca2+0x980>
  40aab0:	mov    QWORD PTR [rsp+0x240],rcx
  40aab8:	mov    QWORD PTR [rsp+0x248],rax
  40aac0:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  40aac9:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  40aad2:	lea    rcx,[rsp+0x250]
  40aada:	call   4098b0 <__swc_fn_0a4ed24b_000120_2648f149>
  40aadf:	jmp    40b1e5 <__swc_fn_0a4ed24b_000150_6203dca2+0x10c5>
  40aae4:	lea    rcx,[rsp+0x260]
  40aaec:	vxorps xmm0,xmm0,xmm0
  40aaf0:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  40aaf9:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  40ab02:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  40ab0b:	vzeroupper
  40ab0e:	mov    DWORD PTR [rsp+0x2c0],0x0
  40ab19:	vmovsd xmm0,QWORD PTR [rdx]
  40ab1d:	vcomisd xmm0,xmm0
  40ab21:	setne  dl
  40ab24:	movzx  edx,dl
  40ab27:	setp   r8b
  40ab2b:	movzx  r8d,r8b
  40ab2f:	or     edx,r8d
  40ab32:	test   dl,dl
  40ab34:	je     40ab41 <__swc_fn_0a4ed24b_000150_6203dca2+0xa21>
  40ab36:	mov    DWORD PTR [rcx],0x6e616e
  40ab3c:	jmp    40b148 <__swc_fn_0a4ed24b_000150_6203dca2+0x1028>
  40ab41:	vcomisd xmm0,xmm11
  40ab46:	ja     40ab57 <__swc_fn_0a4ed24b_000150_6203dca2+0xa37>
  40ab48:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  40ab51:	vcomisd xmm6,xmm0
  40ab55:	jbe    40ab7b <__swc_fn_0a4ed24b_000150_6203dca2+0xa5b>
  40ab57:	vxorpd xmm1,xmm1,xmm1
  40ab5b:	vcomisd xmm1,xmm0
  40ab5f:	jbe    40ab70 <__swc_fn_0a4ed24b_000150_6203dca2+0xa50>
  40ab61:	mov    DWORD PTR [rcx],0x666e692d
  40ab67:	mov    BYTE PTR [rcx+0x4],0x0
  40ab6b:	jmp    40b148 <__swc_fn_0a4ed24b_000150_6203dca2+0x1028>
  40ab70:	mov    DWORD PTR [rcx],0x666e69
  40ab76:	jmp    40b148 <__swc_fn_0a4ed24b_000150_6203dca2+0x1028>
  40ab7b:	vcomisd xmm0,xmm13
  40ab80:	jae    40ab8c <__swc_fn_0a4ed24b_000150_6203dca2+0xa6c>
  40ab82:	vcomisd xmm12,xmm0
  40ab86:	jbe    40aeee <__swc_fn_0a4ed24b_000150_6203dca2+0xdce>
  40ab8c:	vmovups xmm1,xmm0
  40ab90:	vxorpd xmm2,xmm2,xmm2
  40ab94:	vcomisd xmm2,xmm0
  40ab98:	jbe    40aba8 <__swc_fn_0a4ed24b_000150_6203dca2+0xa88>
  40ab9a:	vmovsd xmm0,xmm0,xmm1
  40ab9e:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x857a]        # 413120 <__swc_rdata_base_0a4ed24b+0x10>
  40aba6:	jmp    40abac <__swc_fn_0a4ed24b_000150_6203dca2+0xa8c>
  40aba8:	vmovsd xmm0,xmm0,xmm1
  40abac:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  40abb5:	xor    r8d,r8d
  40abb8:	vcomisd xmm0,xmm6
  40abbc:	jb     40abce <__swc_fn_0a4ed24b_000150_6203dca2+0xaae>
  40abbe:	xchg   ax,ax
  40abc0:	vdivsd xmm0,xmm0,xmm6
  40abc4:	add    r8,0x1
  40abc8:	vcomisd xmm0,xmm6
  40abcc:	jae    40abc0 <__swc_fn_0a4ed24b_000150_6203dca2+0xaa0>
  40abce:	mov    r9,rcx
  40abd1:	vxorpd xmm2,xmm2,xmm2
  40abd5:	vcomisd xmm2,xmm1
  40abd9:	jbe    40abe2 <__swc_fn_0a4ed24b_000150_6203dca2+0xac2>
  40abdb:	mov    BYTE PTR [rcx],0x2d
  40abde:	lea    r9,[rcx+0x1]
  40abe2:	vcvttsd2si rdx,xmm0
  40abe7:	mov    r10b,dl
  40abea:	add    r10b,0x30
  40abee:	mov    BYTE PTR [r9],r10b
  40abf1:	vxorpd xmm1,xmm1,xmm1
  40abf5:	movzx  edx,dl
  40abf8:	vcvtsi2sd xmm1,xmm1,rdx
  40abfd:	vsubsd xmm0,xmm0,xmm1
  40ac01:	vmulsd xmm0,xmm0,xmm6
  40ac05:	mov    BYTE PTR [r9+0x1],0x2e
  40ac0a:	vcvttsd2si rdx,xmm0
  40ac0f:	mov    r10b,dl
  40ac12:	add    r10b,0x30
  40ac16:	mov    BYTE PTR [r9+0x2],r10b
  40ac1a:	vxorpd xmm1,xmm1,xmm1
  40ac1e:	movzx  edx,dl
  40ac21:	vcvtsi2sd xmm1,xmm1,rdx
  40ac26:	vsubsd xmm0,xmm0,xmm1
  40ac2a:	vmulsd xmm0,xmm0,xmm6
  40ac2e:	vcvttsd2si rdx,xmm0
  40ac33:	mov    r10b,dl
  40ac36:	add    r10b,0x30
  40ac3a:	mov    BYTE PTR [r9+0x3],r10b
  40ac3e:	vxorpd xmm1,xmm1,xmm1
  40ac42:	movzx  edx,dl
  40ac45:	vcvtsi2sd xmm1,xmm1,rdx
  40ac4a:	vsubsd xmm0,xmm0,xmm1
  40ac4e:	vmulsd xmm0,xmm0,xmm6
  40ac52:	vcvttsd2si rdx,xmm0
  40ac57:	mov    r10b,dl
  40ac5a:	add    r10b,0x30
  40ac5e:	mov    BYTE PTR [r9+0x4],r10b
  40ac62:	vxorpd xmm1,xmm1,xmm1
  40ac66:	movzx  edx,dl
  40ac69:	vcvtsi2sd xmm1,xmm1,rdx
  40ac6e:	vsubsd xmm0,xmm0,xmm1
  40ac72:	vmulsd xmm0,xmm0,xmm6
  40ac76:	vcvttsd2si rdx,xmm0
  40ac7b:	mov    r10b,dl
  40ac7e:	add    r10b,0x30
  40ac82:	mov    BYTE PTR [r9+0x5],r10b
  40ac86:	vxorpd xmm1,xmm1,xmm1
  40ac8a:	movzx  edx,dl
  40ac8d:	vcvtsi2sd xmm1,xmm1,rdx
  40ac92:	vsubsd xmm0,xmm0,xmm1
  40ac96:	vmulsd xmm0,xmm0,xmm6
  40ac9a:	vcvttsd2si rdx,xmm0
  40ac9f:	mov    r10b,dl
  40aca2:	add    r10b,0x30
  40aca6:	mov    BYTE PTR [r9+0x6],r10b
  40acaa:	vxorpd xmm1,xmm1,xmm1
  40acae:	movzx  edx,dl
  40acb1:	vcvtsi2sd xmm1,xmm1,rdx
  40acb6:	vsubsd xmm0,xmm0,xmm1
  40acba:	vmulsd xmm0,xmm0,xmm6
  40acbe:	vcvttsd2si rdx,xmm0
  40acc3:	mov    r10b,dl
  40acc6:	add    r10b,0x30
  40acca:	mov    BYTE PTR [r9+0x7],r10b
  40acce:	vxorpd xmm1,xmm1,xmm1
  40acd2:	movzx  edx,dl
  40acd5:	vcvtsi2sd xmm1,xmm1,rdx
  40acda:	vsubsd xmm0,xmm0,xmm1
  40acde:	vmulsd xmm0,xmm0,xmm6
  40ace2:	vcvttsd2si rdx,xmm0
  40ace7:	mov    r10b,dl
  40acea:	add    r10b,0x30
  40acee:	mov    BYTE PTR [r9+0x8],r10b
  40acf2:	vxorpd xmm1,xmm1,xmm1
  40acf6:	movzx  edx,dl
  40acf9:	vcvtsi2sd xmm1,xmm1,rdx
  40acfe:	vsubsd xmm0,xmm0,xmm1
  40ad02:	vmulsd xmm0,xmm0,xmm6
  40ad06:	vcvttsd2si rdx,xmm0
  40ad0b:	mov    r10b,dl
  40ad0e:	add    r10b,0x30
  40ad12:	mov    BYTE PTR [r9+0x9],r10b
  40ad16:	vxorpd xmm1,xmm1,xmm1
  40ad1a:	movzx  edx,dl
  40ad1d:	vcvtsi2sd xmm1,xmm1,rdx
  40ad22:	vsubsd xmm0,xmm0,xmm1
  40ad26:	vmulsd xmm0,xmm0,xmm6
  40ad2a:	vcvttsd2si rdx,xmm0
  40ad2f:	mov    r10b,dl
  40ad32:	add    r10b,0x30
  40ad36:	mov    BYTE PTR [r9+0xa],r10b
  40ad3a:	vxorpd xmm1,xmm1,xmm1
  40ad3e:	movzx  edx,dl
  40ad41:	vcvtsi2sd xmm1,xmm1,rdx
  40ad46:	vsubsd xmm0,xmm0,xmm1
  40ad4a:	vmulsd xmm0,xmm0,xmm6
  40ad4e:	vcvttsd2si rdx,xmm0
  40ad53:	mov    r10b,dl
  40ad56:	add    r10b,0x30
  40ad5a:	mov    BYTE PTR [r9+0xb],r10b
  40ad5e:	lea    r10,[r9+0x4]
  40ad62:	vxorpd xmm1,xmm1,xmm1
  40ad66:	movzx  edx,dl
  40ad69:	vcvtsi2sd xmm1,xmm1,rdx
  40ad6e:	vsubsd xmm0,xmm0,xmm1
  40ad72:	vmulsd xmm0,xmm0,xmm6
  40ad76:	vcvttsd2si rdx,xmm0
  40ad7b:	mov    r11b,dl
  40ad7e:	add    r11b,0x30
  40ad82:	mov    BYTE PTR [r9+0xc],r11b
  40ad86:	vxorpd xmm1,xmm1,xmm1
  40ad8a:	movzx  edx,dl
  40ad8d:	vcvtsi2sd xmm1,xmm1,rdx
  40ad92:	vsubsd xmm0,xmm0,xmm1
  40ad96:	vmulsd xmm0,xmm0,xmm6
  40ad9a:	vcvttsd2si rdx,xmm0
  40ad9f:	mov    r11b,dl
  40ada2:	add    r11b,0x30
  40ada6:	mov    BYTE PTR [r9+0xd],r11b
  40adaa:	lea    r10,[r10+0x2]
  40adae:	vxorpd xmm1,xmm1,xmm1
  40adb2:	movzx  edx,dl
  40adb5:	vcvtsi2sd xmm1,xmm1,rdx
  40adba:	vsubsd xmm0,xmm0,xmm1
  40adbe:	vmulsd xmm0,xmm0,xmm6
  40adc2:	vcvttsd2si rdx,xmm0
  40adc7:	mov    r11b,dl
  40adca:	add    r11b,0x30
  40adce:	mov    BYTE PTR [r9+0xe],r11b
  40add2:	vxorpd xmm1,xmm1,xmm1
  40add6:	movzx  edx,dl
  40add9:	vcvtsi2sd xmm1,xmm1,rdx
  40adde:	vsubsd xmm0,xmm0,xmm1
  40ade2:	vmulsd xmm0,xmm0,xmm6
  40ade6:	vcvttsd2si rdx,xmm0
  40adeb:	mov    r11b,dl
  40adee:	add    r11b,0x30
  40adf2:	mov    BYTE PTR [r9+0xf],r11b
  40adf6:	lea    r10,[r10+0x2]
  40adfa:	lea    r10,[r10+0x2]
  40adfe:	lea    r10,[r10+0x2]
  40ae02:	lea    r10,[r10+0x2]
  40ae06:	lea    r10,[r10+0x2]
  40ae0a:	vxorpd xmm1,xmm1,xmm1
  40ae0e:	movzx  edx,dl
  40ae11:	vcvtsi2sd xmm1,xmm1,rdx
  40ae16:	vsubsd xmm0,xmm0,xmm1
  40ae1a:	vmulsd xmm0,xmm0,xmm6
  40ae1e:	vcvttsd2si rdx,xmm0
  40ae23:	mov    r11b,dl
  40ae26:	add    r11b,0x30
  40ae2a:	mov    BYTE PTR [r9+0x10],r11b
  40ae2e:	vxorpd xmm1,xmm1,xmm1
  40ae32:	movzx  edx,dl
  40ae35:	vcvtsi2sd xmm1,xmm1,rdx
  40ae3a:	vsubsd xmm0,xmm0,xmm1
  40ae3e:	vmulsd xmm0,xmm0,xmm6
  40ae42:	vcvttsd2si rdx,xmm0
  40ae47:	add    dl,0x30
  40ae4a:	mov    BYTE PTR [r9+0x11],dl
  40ae4e:	mov    BYTE PTR [r10+0x2],0x65
  40ae53:	lea    r9,[r10+0x3]
  40ae57:	test   r8,r8
  40ae5a:	jl     40ae63 <__swc_fn_0a4ed24b_000150_6203dca2+0xd43>
  40ae5c:	mov    BYTE PTR [r9],0x2b
  40ae60:	inc    r9
  40ae63:	mov    r10,r9
  40ae66:	mov    rdx,r8
  40ae69:	nop    DWORD PTR [rax+0x0]
  40ae70:	mov    r11,rdx
  40ae73:	movabs rdx,0x6666666666666667
  40ae7d:	mov    rax,r11
  40ae80:	imul   rdx
  40ae83:	sar    rdx,0x2
  40ae87:	mov    r12,rdx
  40ae8a:	shr    rdx,0x3f
  40ae8e:	add    r12,rdx
  40ae91:	mov    rdx,r12
  40ae94:	imul   r13,r12,0xa
  40ae98:	sub    r11,r13
  40ae9b:	mov    r13,QWORD PTR [rip+0x894e]        # 4137f0 <__swc_rdata_base_0a4ed24b+0x6e0>
  40aea2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40aea7:	mov    BYTE PTR [r10],r11b
  40aeaa:	lea    r11,[r10+0x1]
  40aeae:	mov    r10,r11
  40aeb1:	test   r12,r12
  40aeb4:	jne    40ae70 <__swc_fn_0a4ed24b_000150_6203dca2+0xd50>
  40aeb6:	test   r8,r8
  40aeb9:	jge    40aec3 <__swc_fn_0a4ed24b_000150_6203dca2+0xda3>
  40aebb:	mov    BYTE PTR [r11],0x2d
  40aebf:	lea    r10,[r11+0x1]
  40aec3:	mov    BYTE PTR [r10],0x0
  40aec7:	sub    r10,0x1
  40aecb:	nop    DWORD PTR [rax+rax*1+0x0]
  40aed0:	cmp    r9,r10
  40aed3:	jae    40b148 <__swc_fn_0a4ed24b_000150_6203dca2+0x1028>
  40aed9:	mov    al,BYTE PTR [r10]
  40aedc:	mov    dl,BYTE PTR [r9]
  40aedf:	mov    BYTE PTR [r10],dl
  40aee2:	sub    r10,0x1
  40aee6:	mov    BYTE PTR [r9],al
  40aee9:	inc    r9
  40aeec:	jmp    40aed0 <__swc_fn_0a4ed24b_000150_6203dca2+0xdb0>
  40aeee:	vcvttsd2si rdx,xmm0
  40aef3:	mov    r8,rdx
  40aef6:	vxorpd xmm1,xmm1,xmm1
  40aefa:	vcvtsi2sd xmm1,xmm1,rdx
  40aeff:	vsubsd xmm1,xmm0,xmm1
  40af03:	mov    r9d,0x8
  40af09:	vxorpd xmm2,xmm2,xmm2
  40af0d:	vcomisd xmm2,xmm1
  40af11:	ja     40af1e <__swc_fn_0a4ed24b_000150_6203dca2+0xdfe>
  40af13:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40af1c:	jmp    40af2f <__swc_fn_0a4ed24b_000150_6203dca2+0xe0f>
  40af1e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x81fa]        # 413120 <__swc_rdata_base_0a4ed24b+0x10>
  40af26:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40af2f:	test   r9d,r9d
  40af32:	je     40af49 <__swc_fn_0a4ed24b_000150_6203dca2+0xe29>
  40af34:	cs nop WORD PTR [rax+rax*1+0x0]
  40af3e:	xchg   ax,ax
  40af40:	vmulsd xmm1,xmm1,xmm6
  40af44:	dec    r9d
  40af47:	jne    40af40 <__swc_fn_0a4ed24b_000150_6203dca2+0xe20>
  40af49:	vcvttsd2si r9,xmm1
  40af4e:	mov    r10,r9
  40af51:	vxorpd xmm2,xmm2,xmm2
  40af55:	vcvtsi2sd xmm2,xmm2,r9
  40af5a:	vsubsd xmm1,xmm1,xmm2
  40af5e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  40af67:	vcomisd xmm1,xmm6
  40af6b:	lea    r9,[r9+0x1]
  40af6f:	cmova  r10,r9
  40af73:	cmp    r10,0x5f5e100
  40af7a:	jne    40af93 <__swc_fn_0a4ed24b_000150_6203dca2+0xe73>
  40af7c:	lea    r8,[rdx-0x1]
  40af80:	vxorpd xmm1,xmm1,xmm1
  40af84:	vcomisd xmm1,xmm0
  40af88:	lea    rdx,[rdx+0x1]
  40af8c:	cmovbe r8,rdx
  40af90:	xor    r10d,r10d
  40af93:	mov    r9,rcx
  40af96:	test   r8,r8
  40af99:	jne    40afb9 <__swc_fn_0a4ed24b_000150_6203dca2+0xe99>
  40af9b:	vxorpd xmm1,xmm1,xmm1
  40af9f:	vcomisd xmm1,xmm0
  40afa3:	jbe    40afac <__swc_fn_0a4ed24b_000150_6203dca2+0xe8c>
  40afa5:	mov    BYTE PTR [rcx],0x2d
  40afa8:	lea    r9,[rcx+0x1]
  40afac:	mov    BYTE PTR [r9],0x30
  40afb0:	add    r9,0x1
  40afb4:	jmp    40b04b <__swc_fn_0a4ed24b_000150_6203dca2+0xf2b>
  40afb9:	mov    r9,rcx
  40afbc:	mov    rdx,r8
  40afbf:	nop
  40afc0:	mov    r11,rdx
  40afc3:	movabs rdx,0x6666666666666667
  40afcd:	mov    r15,rax
  40afd0:	mov    rax,r11
  40afd3:	imul   rdx
  40afd6:	mov    r12,rdx
  40afd9:	mov    rax,r15
  40afdc:	sar    r12,0x2
  40afe0:	mov    rdx,r12
  40afe3:	shr    rdx,0x3f
  40afe7:	add    r12,rdx
  40afea:	mov    rdx,r12
  40afed:	imul   r13,r12,0xa
  40aff1:	sub    r11,r13
  40aff4:	mov    r13,QWORD PTR [rip+0x87f5]        # 4137f0 <__swc_rdata_base_0a4ed24b+0x6e0>
  40affb:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b000:	mov    BYTE PTR [r9],r11b
  40b003:	lea    r11,[r9+0x1]
  40b007:	mov    r9,r11
  40b00a:	test   r12,r12
  40b00d:	jne    40afc0 <__swc_fn_0a4ed24b_000150_6203dca2+0xea0>
  40b00f:	test   r8,r8
  40b012:	jge    40b01c <__swc_fn_0a4ed24b_000150_6203dca2+0xefc>
  40b014:	mov    BYTE PTR [r11],0x2d
  40b018:	lea    r9,[r11+0x1]
  40b01c:	mov    rdx,r9
  40b01f:	mov    BYTE PTR [r9],0x0
  40b023:	sub    r9,0x1
  40b027:	mov    r8,rcx
  40b02a:	cmp    r8,r9
  40b02d:	jae    40b048 <__swc_fn_0a4ed24b_000150_6203dca2+0xf28>
  40b02f:	nop
  40b030:	mov    r11b,BYTE PTR [r9]
  40b033:	mov    r12b,BYTE PTR [r8]
  40b036:	mov    BYTE PTR [r9],r12b
  40b039:	sub    r9,0x1
  40b03d:	mov    BYTE PTR [r8],r11b
  40b040:	inc    r8
  40b043:	cmp    r8,r9
  40b046:	jb     40b030 <__swc_fn_0a4ed24b_000150_6203dca2+0xf10>
  40b048:	mov    r9,rdx
  40b04b:	mov    BYTE PTR [r9],0x2e
  40b04f:	add    r9,0x1
  40b053:	xor    r8d,r8d
  40b056:	test   r10,r10
  40b059:	je     40b09f <__swc_fn_0a4ed24b_000150_6203dca2+0xf7f>
  40b05b:	mov    r11d,0x989680
  40b061:	cmp    r10,r11
  40b064:	jge    40b09f <__swc_fn_0a4ed24b_000150_6203dca2+0xf7f>
  40b066:	cs nop WORD PTR [rax+rax*1+0x0]
  40b070:	inc    r8d
  40b073:	movabs rdx,0x6666666666666667
  40b07d:	mov    r15,rax
  40b080:	mov    rax,r11
  40b083:	imul   rdx
  40b086:	mov    r11,rdx
  40b089:	mov    rax,r15
  40b08c:	sar    r11,0x2
  40b090:	mov    rdx,r11
  40b093:	shr    rdx,0x3f
  40b097:	add    r11,rdx
  40b09a:	cmp    r10,r11
  40b09d:	jl     40b070 <__swc_fn_0a4ed24b_000150_6203dca2+0xf50>
  40b09f:	test   r8d,r8d
  40b0a2:	je     40b0bd <__swc_fn_0a4ed24b_000150_6203dca2+0xf9d>
  40b0a4:	cs nop WORD PTR [rax+rax*1+0x0]
  40b0ae:	xchg   ax,ax
  40b0b0:	mov    BYTE PTR [r9],0x30
  40b0b4:	add    r9,0x1
  40b0b8:	dec    r8d
  40b0bb:	jne    40b0b0 <__swc_fn_0a4ed24b_000150_6203dca2+0xf90>
  40b0bd:	mov    r8,r9
  40b0c0:	mov    rdx,r10
  40b0c3:	cs nop WORD PTR [rax+rax*1+0x0]
  40b0cd:	nop    DWORD PTR [rax]
  40b0d0:	mov    r11,rdx
  40b0d3:	movabs rdx,0x6666666666666667
  40b0dd:	mov    rax,r11
  40b0e0:	imul   rdx
  40b0e3:	sar    rdx,0x2
  40b0e7:	mov    r12,rdx
  40b0ea:	shr    rdx,0x3f
  40b0ee:	add    r12,rdx
  40b0f1:	mov    rdx,r12
  40b0f4:	imul   r13,r12,0xa
  40b0f8:	sub    r11,r13
  40b0fb:	mov    r13,QWORD PTR [rip+0x86ee]        # 4137f0 <__swc_rdata_base_0a4ed24b+0x6e0>
  40b102:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b107:	mov    BYTE PTR [r8],r11b
  40b10a:	lea    r11,[r8+0x1]
  40b10e:	mov    r8,r11
  40b111:	test   r12,r12
  40b114:	jne    40b0d0 <__swc_fn_0a4ed24b_000150_6203dca2+0xfb0>
  40b116:	test   r10,r10
  40b119:	jge    40b123 <__swc_fn_0a4ed24b_000150_6203dca2+0x1003>
  40b11b:	mov    BYTE PTR [r11],0x2d
  40b11f:	lea    r8,[r11+0x1]
  40b123:	mov    BYTE PTR [r8],0x0
  40b127:	sub    r8,0x1
  40b12b:	cmp    r9,r8
  40b12e:	jae    40b148 <__swc_fn_0a4ed24b_000150_6203dca2+0x1028>
  40b130:	mov    al,BYTE PTR [r8]
  40b133:	mov    dl,BYTE PTR [r9]
  40b136:	mov    BYTE PTR [r8],dl
  40b139:	sub    r8,0x1
  40b13d:	mov    BYTE PTR [r9],al
  40b140:	inc    r9
  40b143:	cmp    r9,r8
  40b146:	jb     40b130 <__swc_fn_0a4ed24b_000150_6203dca2+0x1010>
  40b148:	xor    eax,eax
  40b14a:	test   rcx,rcx
  40b14d:	je     40b170 <__swc_fn_0a4ed24b_000150_6203dca2+0x1050>
  40b14f:	mov    rdx,rcx
  40b152:	mov    r8b,BYTE PTR [rdx]
  40b155:	test   r8b,r8b
  40b158:	je     40b170 <__swc_fn_0a4ed24b_000150_6203dca2+0x1050>
  40b15a:	nop    WORD PTR [rax+rax*1+0x0]
  40b160:	add    rdx,0x1
  40b164:	add    rax,0x1
  40b168:	mov    r8b,BYTE PTR [rdx]
  40b16b:	test   r8b,r8b
  40b16e:	jne    40b160 <__swc_fn_0a4ed24b_000150_6203dca2+0x1040>
  40b170:	mov    QWORD PTR [rsp+0x3f8],rcx
  40b178:	mov    QWORD PTR [rsp+0x400],rax
  40b180:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  40b189:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  40b192:	lea    rcx,[rsp+0x408]
  40b19a:	call   4098b0 <__swc_fn_0a4ed24b_000120_2648f149>
  40b19f:	jmp    40b1e5 <__swc_fn_0a4ed24b_000150_6203dca2+0x10c5>
  40b1a1:	mov    rcx,rdx
  40b1a4:	call   4098b0 <__swc_fn_0a4ed24b_000120_2648f149>
  40b1a9:	jmp    40b1e5 <__swc_fn_0a4ed24b_000150_6203dca2+0x10c5>
  40b1ab:	mov    al,BYTE PTR [rdx]
  40b1ad:	test   al,al
  40b1af:	je     40b1ba <__swc_fn_0a4ed24b_000150_6203dca2+0x109a>
  40b1b1:	lea    rax,[rip+0x8648]        # 413800 <__swc_rdata_base_0a4ed24b+0x6f0>
  40b1b8:	jmp    40b1c1 <__swc_fn_0a4ed24b_000150_6203dca2+0x10a1>
  40b1ba:	lea    rax,[rip+0x864f]        # 413810 <__swc_rdata_base_0a4ed24b+0x700>
  40b1c1:	mov    rcx,rax
  40b1c4:	call   4098b0 <__swc_fn_0a4ed24b_000120_2648f149>
  40b1c9:	jmp    40b1e5 <__swc_fn_0a4ed24b_000150_6203dca2+0x10c5>
  40b1cb:	lea    rcx,[rip+0x864e]        # 413820 <__swc_rdata_base_0a4ed24b+0x710>
  40b1d2:	call   4098b0 <__swc_fn_0a4ed24b_000120_2648f149>
  40b1d7:	jmp    40b1e5 <__swc_fn_0a4ed24b_000150_6203dca2+0x10c5>
  40b1d9:	lea    rcx,[rip+0x8640]        # 413820 <__swc_rdata_base_0a4ed24b+0x710>
  40b1e0:	call   4098b0 <__swc_fn_0a4ed24b_000120_2648f149>
  40b1e5:	add    rdi,0x1
  40b1e9:	sub    rsi,0x1
  40b1ed:	vmovups xmm0,xmm12
  40b1f2:	vmovsd xmm6,QWORD PTR [rip+0x8636]        # 413830 <__swc_rdata_base_0a4ed24b+0x720>
  40b1fa:	test   rsi,rsi
  40b1fd:	jne    40a230 <__swc_fn_0a4ed24b_000150_6203dca2+0x110>
  40b203:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  40b20c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  40b215:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  40b21e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  40b227:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  40b230:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  40b239:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  40b242:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  40b24b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  40b254:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  40b25d:	add    rsp,0x4e8
  40b264:	pop    r15
  40b266:	pop    r13
  40b268:	pop    r12
  40b26a:	pop    rdi
  40b26b:	pop    rsi
  40b26c:	pop    rbx
  40b26d:	ret
	...

000000000040b270 <__swc_fn_0a4ed24b_000153_86f1d437>:
  40b270:	vxorps xmm0,xmm0,xmm0
  40b274:	vmovups XMMWORD PTR [rcx],xmm0
  40b278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b27d:	ret
	...

000000000040b280 <__swc_fn_0a4ed24b_000156_86f1d437>:
  40b280:	vxorps xmm0,xmm0,xmm0
  40b284:	vmovups XMMWORD PTR [rcx],xmm0
  40b288:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b28d:	vxorps xmm0,xmm0,xmm0
  40b291:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b296:	vmovups xmm0,XMMWORD PTR [rip+0x869a]        # 413938 <__swc_rdata_base_0a4ed24b+0x828>
  40b29e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b2a3:	vxorps xmm0,xmm0,xmm0
  40b2a7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40b2ac:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40b2b1:	vxorps xmm0,xmm0,xmm0
  40b2b5:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40b2ba:	mov    QWORD PTR [rcx+0x70],0x0
  40b2c2:	ret
	...

000000000040b2d0 <__swc_fn_0a4ed24b_000159_86f1d437>:
  40b2d0:	vxorps xmm0,xmm0,xmm0
  40b2d4:	vmovups XMMWORD PTR [rcx],xmm0
  40b2d8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b2dd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b2e2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b2e7:	ret
	...

000000000040b2f0 <__swc_fn_0a4ed24b_000162_e36363a8>:
  40b2f0:	push   rsi
  40b2f1:	push   rdi
  40b2f2:	sub    rsp,0x8
  40b2f6:	mov    rsi,rcx
  40b2f9:	mov    rdi,QWORD PTR [rsi+0x50]
  40b2fd:	test   rdi,rdi
  40b300:	je     40b307 <__swc_fn_0a4ed24b_000162_e36363a8+0x17>
  40b302:	mov    rcx,rsi
  40b305:	call   rdi
  40b307:	mov    QWORD PTR [rsi+0x20],0x0
  40b30f:	mov    rax,QWORD PTR [rsi+0x30]
  40b313:	test   rax,rax
  40b316:	je     40b344 <__swc_fn_0a4ed24b_000162_e36363a8+0x54>
  40b318:	nop    DWORD PTR [rax+rax*1+0x0]
  40b320:	mov    rdi,QWORD PTR [rax+0x8]
  40b324:	mov    rcx,rsi
  40b327:	mov    rdx,QWORD PTR [rax+0x10]
  40b32b:	mov    rax,QWORD PTR [rax+0x18]
  40b32f:	mov    r8,rax
  40b332:	call   40e790 <__swc_fn_0a4ed24b_000160_47b270e1>
  40b337:	mov    QWORD PTR [rsi+0x30],rdi
  40b33b:	mov    rax,QWORD PTR [rsi+0x30]
  40b33f:	test   rax,rax
  40b342:	jne    40b320 <__swc_fn_0a4ed24b_000162_e36363a8+0x30>
  40b344:	mov    QWORD PTR [rsi+0x38],0x0
  40b34c:	add    rsp,0x8
  40b350:	pop    rdi
  40b351:	pop    rsi
  40b352:	ret
	...

000000000040b360 <__swc_fn_0a4ed24b_000165_016ee66a>:
  40b360:	push   rbx
  40b361:	push   rsi
  40b362:	push   rdi
  40b363:	push   r12
  40b365:	sub    rsp,0x188
  40b36c:	mov    rbx,rcx
  40b36f:	lea    rsi,[rip+0x1ba1a]        # 426d90 <__swc_bss_base_0a4ed24b+0x2d50>
  40b376:	mov    rcx,rsi
  40b379:	call   40e1a0 <__swc_fn_0a4ed24b_000139_86bb0f90>
  40b37e:	mov    rax,QWORD PTR [rip+0x1ba13]        # 426d98 <__swc_bss_base_0a4ed24b+0x2d58>
  40b385:	mov    rdi,rax
  40b388:	test   rdi,rdi
  40b38b:	je     40b3b9 <__swc_fn_0a4ed24b_000165_016ee66a+0x59>
  40b38d:	nop    DWORD PTR [rax]
  40b390:	cmp    QWORD PTR [rdi+0x8],rbx
  40b394:	jne    40b3ae <__swc_fn_0a4ed24b_000165_016ee66a+0x4e>
  40b396:	mov    rcx,rsi
  40b399:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40b39e:	mov    rax,rdi
  40b3a1:	add    rsp,0x188
  40b3a8:	pop    r12
  40b3aa:	pop    rdi
  40b3ab:	pop    rsi
  40b3ac:	pop    rbx
  40b3ad:	ret
  40b3ae:	mov    rax,QWORD PTR [rdi]
  40b3b1:	mov    rdi,rax
  40b3b4:	test   rax,rax
  40b3b7:	jne    40b390 <__swc_fn_0a4ed24b_000165_016ee66a+0x30>
  40b3b9:	call   4119e0 <__swc_fn_0a4ed24b_000143_d299b428>
  40b3be:	mov    rdi,rax
  40b3c1:	test   rax,rax
  40b3c4:	jne    40b3dd <__swc_fn_0a4ed24b_000165_016ee66a+0x7d>
  40b3c6:	mov    rcx,rsi
  40b3c9:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40b3ce:	xor    eax,eax
  40b3d0:	add    rsp,0x188
  40b3d7:	pop    r12
  40b3d9:	pop    rdi
  40b3da:	pop    rsi
  40b3db:	pop    rbx
  40b3dc:	ret
  40b3dd:	lea    rax,[rsp+0x18]
  40b3e2:	mov    QWORD PTR [rax+0x10],0x0
  40b3ea:	mov    QWORD PTR [rax+0x18],0x0
  40b3f2:	mov    DWORD PTR [rax+0x20],0x0
  40b3f9:	mov    BYTE PTR [rax+0x24],0x0
  40b3fd:	mov    rax,QWORD PTR [rip+0x1b994]        # 426d98 <__swc_bss_base_0a4ed24b+0x2d58>
  40b404:	mov    QWORD PTR [rsp+0x18],rax
  40b409:	mov    QWORD PTR [rsp+0x20],rbx
  40b40e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40b414:	vmovups XMMWORD PTR [rdi],xmm0
  40b418:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40b41e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  40b423:	mov    rax,QWORD PTR [rsp+0x38]
  40b428:	mov    QWORD PTR [rdi+0x20],rax
  40b42c:	mov    QWORD PTR [rip+0x1b965],rdi        # 426d98 <__swc_bss_base_0a4ed24b+0x2d58>
  40b433:	lea    rax,[rsp+0x40]
  40b438:	mov    QWORD PTR [rax],0x0
  40b43f:	mov    rcx,rbx
  40b442:	mov    rdx,rax
  40b445:	call   40e280 <__swc_fn_0a4ed24b_000145_1534de9a>
  40b44a:	mov    rbx,rax
  40b44d:	test   rax,rax
  40b450:	jne    40b46a <__swc_fn_0a4ed24b_000165_016ee66a+0x10a>
  40b452:	mov    rcx,rsi
  40b455:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40b45a:	mov    rax,rdi
  40b45d:	add    rsp,0x188
  40b464:	pop    r12
  40b466:	pop    rdi
  40b467:	pop    rsi
  40b468:	pop    rbx
  40b469:	ret
  40b46a:	lea    r12,[rsp+0x50]
  40b46f:	mov    QWORD PTR [r12],0x0
  40b477:	mov    rcx,rbx
  40b47a:	mov    rdx,QWORD PTR [rsp+0x40]
  40b47f:	mov    r8,r12
  40b482:	call   411a90 <__swc_fn_0a4ed24b_000146_162f363d>
  40b487:	test   rax,rax
  40b48a:	jne    40b4a4 <__swc_fn_0a4ed24b_000165_016ee66a+0x144>
  40b48c:	mov    rcx,rsi
  40b48f:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40b494:	mov    rax,rdi
  40b497:	add    rsp,0x188
  40b49e:	pop    r12
  40b4a0:	pop    rdi
  40b4a1:	pop    rsi
  40b4a2:	pop    rbx
  40b4a3:	ret
  40b4a4:	cmp    QWORD PTR [r12],0x10
  40b4a9:	jb     40b5ac <__swc_fn_0a4ed24b_000165_016ee66a+0x24c>
  40b4af:	mov    ecx,DWORD PTR [rax]
  40b4b1:	cmp    ecx,0x42445753
  40b4b7:	jne    40b5ac <__swc_fn_0a4ed24b_000165_016ee66a+0x24c>
  40b4bd:	mov    ecx,DWORD PTR [rax+0x4]
  40b4c0:	cmp    ecx,0x1
  40b4c3:	jne    40b5ac <__swc_fn_0a4ed24b_000165_016ee66a+0x24c>
  40b4c9:	mov    ecx,DWORD PTR [rax+0x8]
  40b4cc:	mov    edx,DWORD PTR [rax+0xc]
  40b4cf:	imul   r8,rcx,0x14
  40b4d3:	mov    r9,QWORD PTR [rsp+0x50]
  40b4d8:	sub    r9,0x10
  40b4dc:	cmp    r8,r9
  40b4df:	ja     40b5ac <__swc_fn_0a4ed24b_000165_016ee66a+0x24c>
  40b4e5:	lea    r8,[r8+0x10]
  40b4e9:	cmp    rdx,r8
  40b4ec:	jb     40b5ac <__swc_fn_0a4ed24b_000165_016ee66a+0x24c>
  40b4f2:	mov    r8,QWORD PTR [rsp+0x50]
  40b4f7:	cmp    rdx,r8
  40b4fa:	ja     40b5ac <__swc_fn_0a4ed24b_000165_016ee66a+0x24c>
  40b500:	xor    r8d,r8d
  40b503:	test   rcx,rcx
  40b506:	jbe    40b5d2 <__swc_fn_0a4ed24b_000165_016ee66a+0x272>
  40b50c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  40b512:	cs nop WORD PTR [rax+rax*1+0x0]
  40b51c:	nop    DWORD PTR [rax+0x0]
  40b520:	imul   r9,r8,0x14
  40b524:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  40b529:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  40b52e:	add    r10,r11
  40b531:	movabs r11,0x100000000
  40b53b:	cmp    r10,r11
  40b53e:	ja     40b5ac <__swc_fn_0a4ed24b_000165_016ee66a+0x24c>
  40b540:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  40b545:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  40b54a:	test   r10d,r10d
  40b54d:	setne  r11b
  40b551:	je     40b56b <__swc_fn_0a4ed24b_000165_016ee66a+0x20b>
  40b553:	cmp    r10d,edx
  40b556:	setb   r11b
  40b55a:	jb     40b56b <__swc_fn_0a4ed24b_000165_016ee66a+0x20b>
  40b55c:	vmovq  r11,xmm1
  40b561:	cmp    r10,r11
  40b564:	setae  r10b
  40b568:	mov    r11b,r10b
  40b56b:	mov    r10,r11
  40b56e:	test   r11b,r11b
  40b571:	jne    40b598 <__swc_fn_0a4ed24b_000165_016ee66a+0x238>
  40b573:	test   r9d,r9d
  40b576:	setne  r10b
  40b57a:	je     40b598 <__swc_fn_0a4ed24b_000165_016ee66a+0x238>
  40b57c:	cmp    r9d,edx
  40b57f:	setb   r10b
  40b583:	jb     40b598 <__swc_fn_0a4ed24b_000165_016ee66a+0x238>
  40b585:	vmovq  r10,xmm1
  40b58a:	cmp    r9,r10
  40b58d:	setae  r9b
  40b591:	movzx  r9d,r9b
  40b595:	mov    r10b,r9b
  40b598:	test   r10b,r10b
  40b59b:	jne    40b5ac <__swc_fn_0a4ed24b_000165_016ee66a+0x24c>
  40b59d:	add    r8,0x1
  40b5a1:	cmp    r8,rcx
  40b5a4:	jb     40b520 <__swc_fn_0a4ed24b_000165_016ee66a+0x1c0>
  40b5aa:	jmp    40b5d2 <__swc_fn_0a4ed24b_000165_016ee66a+0x272>
  40b5ac:	xor    ecx,ecx
  40b5ae:	cmp    rax,rbx
  40b5b1:	cmovne rcx,rax
  40b5b5:	call   40a070 <__swc_fn_0a4ed24b_000147_d7edc04f>
  40b5ba:	mov    rcx,rsi
  40b5bd:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40b5c2:	mov    rax,rdi
  40b5c5:	add    rsp,0x188
  40b5cc:	pop    r12
  40b5ce:	pop    rdi
  40b5cf:	pop    rsi
  40b5d0:	pop    rbx
  40b5d1:	ret
  40b5d2:	mov    QWORD PTR [rdi+0x10],rax
  40b5d6:	mov    rcx,QWORD PTR [rsp+0x50]
  40b5db:	mov    QWORD PTR [rdi+0x18],rcx
  40b5df:	mov    eax,DWORD PTR [rax+0x8]
  40b5e2:	mov    DWORD PTR [rdi+0x20],eax
  40b5e5:	rex mov BYTE PTR [rdi+0x24],0x1
  40b5ea:	mov    rcx,rsi
  40b5ed:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40b5f2:	mov    rax,rdi
  40b5f5:	add    rsp,0x188
  40b5fc:	pop    r12
  40b5fe:	pop    rdi
  40b5ff:	pop    rsi
  40b600:	pop    rbx
  40b601:	ret
	...

000000000040b610 <__swc_fn_0a4ed24b_000168_3459066f>:
  40b610:	push   rsi
  40b611:	push   rdi
  40b612:	push   r12
  40b614:	mov    rsi,rdx
  40b617:	mov    rdi,rcx
  40b61a:	mov    rcx,QWORD PTR [rip+0x1b71f]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40b621:	test   rcx,rcx
  40b624:	jne    40b636 <__swc_fn_0a4ed24b_000168_3459066f+0x26>
  40b626:	call   40eaa0 <__swc_fn_0a4ed24b_000169_994c8876>
  40b62b:	lea    rcx,[rax+0x1]
  40b62f:	mov    QWORD PTR [rip+0x1b70a],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40b636:	dec    rcx
  40b639:	call   40b660 <__swc_fn_0a4ed24b_000171_360af05d>
  40b63e:	mov    r12,QWORD PTR [rax+0xbe0]
  40b645:	test   r12,r12
  40b648:	setne  al
  40b64b:	je     40b656 <__swc_fn_0a4ed24b_000168_3459066f+0x46>
  40b64d:	mov    rcx,rdi
  40b650:	mov    rdx,rsi
  40b653:	call   r12
  40b656:	pop    r12
  40b658:	pop    rdi
  40b659:	pop    rsi
  40b65a:	ret
  40b65b:	add    BYTE PTR [rax],al
  40b65d:	add    BYTE PTR [rax],al
	...

000000000040b660 <__swc_fn_0a4ed24b_000171_360af05d>:
  40b660:	push   r12
  40b662:	push   rdi
  40b663:	push   rsi
  40b664:	sub    rsp,0xd0
  40b66b:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40b671:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40b677:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40b67d:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40b683:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40b689:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40b68f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40b698:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40b6a1:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40b6aa:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40b6b3:	mov    r12,rcx
  40b6b6:	mov    edi,ecx
  40b6b8:	xor    eax,eax
  40b6ba:	call   407010 <pthread_getspecific@plt>
  40b6bf:	test   rax,rax
  40b6c2:	je     40b6c6 <__swc_fn_0a4ed24b_000171_360af05d+0x66>
  40b6c4:	jmp    40b6ce <__swc_fn_0a4ed24b_000171_360af05d+0x6e>
  40b6c6:	mov    rcx,r12
  40b6c9:	call   40eb00 <__swc_fn_0a4ed24b_000172_cbeff767>
  40b6ce:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40b6d4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40b6da:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40b6e0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40b6e6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40b6ec:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40b6f2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40b6fb:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40b704:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40b70d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40b716:	add    rsp,0xd0
  40b71d:	pop    rsi
  40b71e:	pop    rdi
  40b71f:	pop    r12
  40b721:	ret
	...

000000000040b730 <__swc_fn_0a4ed24b_000174_5eac0ab4>:
  40b730:	push   rsi
  40b731:	sub    rsp,0x30
  40b735:	lea    rsi,[rip+0x1b66c]        # 426da8 <__swc_bss_base_0a4ed24b+0x2d68>
  40b73c:	mov    rax,QWORD PTR [rsi]
  40b73f:	test   rax,rax
  40b742:	je     40b74a <__swc_fn_0a4ed24b_000174_5eac0ab4+0x1a>
  40b744:	add    rsp,0x30
  40b748:	pop    rsi
  40b749:	ret
  40b74a:	mov    ecx,0x3
  40b74f:	mov    edx,0x10
  40b754:	call   4091d0 <__swc_fn_0a4ed24b_000111_6814119b>
  40b759:	test   rax,rax
  40b75c:	jne    40b76d <__swc_fn_0a4ed24b_000174_5eac0ab4+0x3d>
  40b75e:	mov    QWORD PTR [rsp+0x18],rax
  40b763:	call   411530 <__swc_fn_0a4ed24b_000122_be2e2f68>
  40b768:	mov    rax,QWORD PTR [rsp+0x18]
  40b76d:	mov    rcx,rax
  40b770:	xchg   QWORD PTR [rsi],rcx
  40b773:	add    rsp,0x30
  40b777:	pop    rsi
  40b778:	ret
  40b779:	add    BYTE PTR [rax],al
  40b77b:	add    BYTE PTR [rax],al
  40b77d:	add    BYTE PTR [rax],al
	...

000000000040b780 <__swc_fn_0a4ed24b_000177_cf4ffedd>:
  40b780:	push   rsi
  40b781:	push   rdi
  40b782:	sub    rsp,0x8
  40b786:	mov    rsi,rdx
  40b789:	mov    rdi,rcx
  40b78c:	mov    rax,QWORD PTR [rsi+0x8]
  40b790:	test   rax,rax
  40b793:	je     40b79d <__swc_fn_0a4ed24b_000177_cf4ffedd+0x1d>
  40b795:	mov    rcx,QWORD PTR [rsi]
  40b798:	mov    QWORD PTR [rax],rcx
  40b79b:	jmp    40b7a4 <__swc_fn_0a4ed24b_000177_cf4ffedd+0x24>
  40b79d:	mov    rax,QWORD PTR [rsi]
  40b7a0:	mov    QWORD PTR [rdi+0x8],rax
  40b7a4:	mov    rax,QWORD PTR [rsi]
  40b7a7:	test   rax,rax
  40b7aa:	je     40b7b4 <__swc_fn_0a4ed24b_000177_cf4ffedd+0x34>
  40b7ac:	mov    rcx,QWORD PTR [rsi+0x8]
  40b7b0:	mov    QWORD PTR [rax+0x8],rcx
  40b7b4:	mov    rcx,rdi
  40b7b7:	mov    rdx,QWORD PTR [rsi+0x10]
  40b7bb:	mov    r8,QWORD PTR [rsi+0x18]
  40b7bf:	mov    r9,0xffffffffffffffff
  40b7c6:	call   4120e0 <__swc_fn_0a4ed24b_000176_4de704de>
  40b7cb:	mov    QWORD PTR [rsi+0x18],0x0
  40b7d3:	mov    rax,QWORD PTR [rdi+0x8]
  40b7d7:	test   rax,rax
  40b7da:	jne    40b7ec <__swc_fn_0a4ed24b_000177_cf4ffedd+0x6c>
  40b7dc:	call   40b730 <__swc_fn_0a4ed24b_000174_5eac0ab4>
  40b7e1:	xor    ecx,ecx
  40b7e3:	mov    QWORD PTR [rax+0x8],rcx
  40b7e7:	xor    ecx,ecx
  40b7e9:	mov    QWORD PTR [rax],rcx
  40b7ec:	add    rsp,0x8
  40b7f0:	pop    rdi
  40b7f1:	pop    rsi
  40b7f2:	ret
	...

000000000040b800 <__swc_fn_0a4ed24b_000001_0d61c738>:
  40b800:	push   rbp
  40b801:	sub    rsp,0x108
  40b808:	mov    rbp,rsp
  40b80b:	vmovups XMMWORD PTR [rsp+0x60],xmm6
  40b811:	vmovups XMMWORD PTR [rsp+0x70],xmm7
  40b817:	vmovups XMMWORD PTR [rsp+0x80],xmm8
  40b820:	vmovups XMMWORD PTR [rsp+0x90],xmm9
  40b829:	vmovups XMMWORD PTR [rsp+0xa0],xmm10
  40b832:	vmovups XMMWORD PTR [rsp+0xb0],xmm12
  40b83b:	vmovups XMMWORD PTR [rsp+0xc0],xmm13
  40b844:	vmovups XMMWORD PTR [rsp+0xd0],xmm14
  40b84d:	vmovups XMMWORD PTR [rsp+0xe0],xmm15
  40b856:	vmovups XMMWORD PTR [rsp+0xf0],xmm11
  40b85f:	vmovups xmm6,xmm5
  40b863:	vmovups xmm7,xmm0
  40b867:	vmovups xmm0,xmm1
  40b86b:	vmovups xmm1,xmm2
  40b86f:	vmovups xmm2,xmm3
  40b873:	vmovups xmm3,xmm4
  40b877:	vmovsd QWORD PTR [rsp+0x50],xmm4
  40b87d:	vmovsd xmm4,QWORD PTR [rbp+0x118]
  40b885:	vmovsd xmm5,QWORD PTR [rip+0x78a3]        # 413130 <__swc_rdata_base_0a4ed24b+0x20>
  40b88d:	mov    eax,0xffffffff
  40b892:	vsubsd xmm8,xmm0,QWORD PTR [rip+0x789f]        # 413139 <__swc_rdata_base_0a4ed24b+0x29>
  40b89a:	vsubsd xmm9,xmm1,QWORD PTR [rip+0x78a0]        # 413142 <__swc_rdata_base_0a4ed24b+0x32>
  40b8a2:	vmulsd xmm10,xmm7,xmm2
  40b8a6:	vfmadd231sd xmm10,xmm8,xmm3
  40b8ab:	vfmadd231sd xmm10,xmm9,xmm6
  40b8b0:	vaddsd xmm10,xmm10,xmm10
  40b8b5:	vmulsd xmm12,xmm7,xmm7
  40b8b9:	vfmadd213sd xmm8,xmm8,xmm12
  40b8be:	vfmadd231sd xmm8,xmm9,xmm9
  40b8c3:	vmovsd xmm14,QWORD PTR [rip+0x7880]        # 41314b <__swc_rdata_base_0a4ed24b+0x3b>
  40b8cb:	vsubsd xmm8,xmm8,xmm14
  40b8d0:	vmulsd xmm9,xmm10,xmm10
  40b8d5:	vmovsd xmm15,QWORD PTR [rip+0x7877]        # 413154 <__swc_rdata_base_0a4ed24b+0x44>
  40b8dd:	vfnmadd213sd xmm8,xmm15,xmm9
  40b8e2:	vxorpd xmm9,xmm9,xmm9
  40b8e7:	vcomisd xmm9,xmm8
  40b8ec:	ja     40b937 <__swc_fn_0a4ed24b_000001_0d61c738+0x137>
  40b8ee:	vsqrtsd xmm9,xmm8,xmm8
  40b8f3:	vxorpd xmm10,xmm10,XMMWORD PTR [rip+0x7825]        # 413120 <__swc_rdata_base_0a4ed24b+0x10>
  40b8fb:	vsubsd xmm8,xmm10,xmm9
  40b900:	vmovsd xmm12,QWORD PTR [rip+0x7855]        # 41315d <__swc_rdata_base_0a4ed24b+0x4d>
  40b908:	vmulsd xmm8,xmm8,xmm12
  40b90d:	vmovups xmm11,xmm8
  40b912:	vcomisd xmm4,xmm8
  40b917:	jbe    40b923 <__swc_fn_0a4ed24b_000001_0d61c738+0x123>
  40b919:	vaddsd xmm8,xmm10,xmm9
  40b91e:	vmulsd xmm11,xmm8,xmm12
  40b923:	vcomisd xmm11,xmm4
  40b927:	jb     40b937 <__swc_fn_0a4ed24b_000001_0d61c738+0x137>
  40b929:	vcomisd xmm5,xmm11
  40b92e:	jbe    40b937 <__swc_fn_0a4ed24b_000001_0d61c738+0x137>
  40b930:	vmovups xmm5,xmm11
  40b935:	xor    eax,eax
  40b937:	vsubsd xmm13,xmm7,QWORD PTR [rip+0x7827]        # 413166 <__swc_rdata_base_0a4ed24b+0x56>
  40b93f:	vsubsd xmm9,xmm1,QWORD PTR [rip+0x7828]        # 41316f <__swc_rdata_base_0a4ed24b+0x5f>
  40b947:	vmulsd xmm10,xmm13,xmm2
  40b94b:	vmulsd xmm11,xmm0,xmm3
  40b94f:	vaddsd xmm10,xmm10,xmm11
  40b954:	vfmadd231sd xmm10,xmm9,xmm6
  40b959:	vaddsd xmm10,xmm10,xmm10
  40b95e:	vmulsd xmm12,xmm13,xmm13
  40b963:	vmulsd xmm13,xmm0,xmm0
  40b967:	vaddsd xmm8,xmm12,xmm13
  40b96c:	vfmadd231sd xmm8,xmm9,xmm9
  40b971:	vsubsd xmm8,xmm8,xmm14
  40b976:	vmulsd xmm9,xmm10,xmm10
  40b97b:	vfnmadd213sd xmm8,xmm15,xmm9
  40b980:	vxorpd xmm9,xmm9,xmm9
  40b985:	vcomisd xmm9,xmm8
  40b98a:	ja     40b9d6 <__swc_fn_0a4ed24b_000001_0d61c738+0x1d6>
  40b98c:	vsqrtsd xmm9,xmm8,xmm8
  40b991:	vxorpd xmm10,xmm10,XMMWORD PTR [rip+0x7787]        # 413120 <__swc_rdata_base_0a4ed24b+0x10>
  40b999:	vsubsd xmm8,xmm10,xmm9
  40b99e:	vmovsd xmm12,QWORD PTR [rip+0x77b7]        # 41315d <__swc_rdata_base_0a4ed24b+0x4d>
  40b9a6:	vmulsd xmm8,xmm8,xmm12
  40b9ab:	vmovups xmm3,xmm8
  40b9b0:	vcomisd xmm4,xmm8
  40b9b5:	jbe    40b9c1 <__swc_fn_0a4ed24b_000001_0d61c738+0x1c1>
  40b9b7:	vaddsd xmm8,xmm10,xmm9
  40b9bc:	vmulsd xmm3,xmm8,xmm12
  40b9c1:	vcomisd xmm3,xmm4
  40b9c5:	jb     40b9d6 <__swc_fn_0a4ed24b_000001_0d61c738+0x1d6>
  40b9c7:	vcomisd xmm5,xmm3
  40b9cb:	jbe    40b9d6 <__swc_fn_0a4ed24b_000001_0d61c738+0x1d6>
  40b9cd:	vmovups xmm5,xmm3
  40b9d1:	mov    eax,0x1
  40b9d6:	vsubsd xmm3,xmm7,QWORD PTR [rip+0x779a]        # 413178 <__swc_rdata_base_0a4ed24b+0x68>
  40b9de:	vsubsd xmm9,xmm1,QWORD PTR [rip+0x776e]        # 413154 <__swc_rdata_base_0a4ed24b+0x44>
  40b9e6:	vmulsd xmm10,xmm3,xmm2
  40b9ea:	vaddsd xmm10,xmm10,xmm11
  40b9ef:	vfmadd231sd xmm10,xmm9,xmm6
  40b9f4:	vaddsd xmm10,xmm10,xmm10
  40b9f9:	vmulsd xmm12,xmm3,xmm3
  40b9fd:	vaddsd xmm8,xmm12,xmm13
  40ba02:	vfmadd231sd xmm8,xmm9,xmm9
  40ba07:	vsubsd xmm8,xmm8,xmm14
  40ba0c:	vmulsd xmm9,xmm10,xmm10
  40ba11:	vfnmadd213sd xmm8,xmm15,xmm9
  40ba16:	vxorpd xmm9,xmm9,xmm9
  40ba1b:	vcomisd xmm9,xmm8
  40ba20:	ja     40ba6c <__swc_fn_0a4ed24b_000001_0d61c738+0x26c>
  40ba22:	vsqrtsd xmm9,xmm8,xmm8
  40ba27:	vxorpd xmm10,xmm10,XMMWORD PTR [rip+0x76f1]        # 413120 <__swc_rdata_base_0a4ed24b+0x10>
  40ba2f:	vsubsd xmm8,xmm10,xmm9
  40ba34:	vmovsd xmm12,QWORD PTR [rip+0x7721]        # 41315d <__swc_rdata_base_0a4ed24b+0x4d>
  40ba3c:	vmulsd xmm8,xmm8,xmm12
  40ba41:	vmovups xmm3,xmm8
  40ba46:	vcomisd xmm4,xmm8
  40ba4b:	jbe    40ba57 <__swc_fn_0a4ed24b_000001_0d61c738+0x257>
  40ba4d:	vaddsd xmm8,xmm10,xmm9
  40ba52:	vmulsd xmm3,xmm8,xmm12
  40ba57:	vcomisd xmm3,xmm4
  40ba5b:	jb     40ba6c <__swc_fn_0a4ed24b_000001_0d61c738+0x26c>
  40ba5d:	vcomisd xmm5,xmm3
  40ba61:	jbe    40ba6c <__swc_fn_0a4ed24b_000001_0d61c738+0x26c>
  40ba63:	vmovups xmm5,xmm3
  40ba67:	mov    eax,0x2
  40ba6c:	vsubsd xmm8,xmm0,QWORD PTR [rip+0x770d]        # 413181 <__swc_rdata_base_0a4ed24b+0x71>
  40ba74:	vmulsd xmm10,xmm7,xmm2
  40ba78:	vfmadd231sd xmm10,xmm8,QWORD PTR [rsp+0x50]
  40ba7f:	vfmadd231sd xmm10,xmm1,xmm6
  40ba84:	vaddsd xmm10,xmm10,xmm10
  40ba89:	vmulsd xmm12,xmm7,xmm7
  40ba8d:	vfmadd213sd xmm8,xmm8,xmm12
  40ba92:	vfmadd231sd xmm8,xmm1,xmm1
  40ba97:	vsubsd xmm8,xmm8,QWORD PTR [rip+0x76eb]        # 41318a <__swc_rdata_base_0a4ed24b+0x7a>
  40ba9f:	vmulsd xmm9,xmm10,xmm10
  40baa4:	vfnmadd213sd xmm8,xmm15,xmm9
  40baa9:	vxorpd xmm9,xmm9,xmm9
  40baae:	vcomisd xmm9,xmm8
  40bab3:	ja     40baff <__swc_fn_0a4ed24b_000001_0d61c738+0x2ff>
  40bab5:	vsqrtsd xmm9,xmm8,xmm8
  40baba:	vxorpd xmm10,xmm10,XMMWORD PTR [rip+0x765e]        # 413120 <__swc_rdata_base_0a4ed24b+0x10>
  40bac2:	vsubsd xmm8,xmm10,xmm9
  40bac7:	vmovsd xmm12,QWORD PTR [rip+0x768e]        # 41315d <__swc_rdata_base_0a4ed24b+0x4d>
  40bacf:	vmulsd xmm8,xmm8,xmm12
  40bad4:	vmovups xmm3,xmm8
  40bad9:	vcomisd xmm4,xmm8
  40bade:	jbe    40baea <__swc_fn_0a4ed24b_000001_0d61c738+0x2ea>
  40bae0:	vaddsd xmm8,xmm10,xmm9
  40bae5:	vmulsd xmm3,xmm8,xmm12
  40baea:	vcomisd xmm3,xmm4
  40baee:	jb     40baff <__swc_fn_0a4ed24b_000001_0d61c738+0x2ff>
  40baf0:	vcomisd xmm5,xmm3
  40baf4:	jbe    40baff <__swc_fn_0a4ed24b_000001_0d61c738+0x2ff>
  40baf6:	vmovups xmm5,xmm3
  40bafa:	mov    eax,0x3
  40baff:	vmovsd QWORD PTR [rip+0x18539],xmm5        # 424040 <__swc_bss_base_0a4ed24b>
  40bb07:	mov    DWORD PTR [rip+0x164f3],eax        # 422000 <__swc_data_base_0a4ed24b>
  40bb0d:	vmovups xmm6,XMMWORD PTR [rsp+0x60]
  40bb13:	vmovups xmm7,XMMWORD PTR [rsp+0x70]
  40bb19:	vmovups xmm8,XMMWORD PTR [rsp+0x80]
  40bb22:	vmovups xmm9,XMMWORD PTR [rsp+0x90]
  40bb2b:	vmovups xmm10,XMMWORD PTR [rsp+0xa0]
  40bb34:	vmovups xmm12,XMMWORD PTR [rsp+0xb0]
  40bb3d:	vmovups xmm13,XMMWORD PTR [rsp+0xc0]
  40bb46:	vmovups xmm14,XMMWORD PTR [rsp+0xd0]
  40bb4f:	vmovups xmm15,XMMWORD PTR [rsp+0xe0]
  40bb58:	vmovups xmm11,XMMWORD PTR [rsp+0xf0]
  40bb61:	add    rsp,0x108
  40bb68:	pop    rbp
  40bb69:	ret
  40bb6a:	add    BYTE PTR [rax],al
  40bb6c:	add    BYTE PTR [rax],al
	...

000000000040bb70 <__swc_fn_0a4ed24b_000004_9ee35b18>:
  40bb70:	vxorps xmm0,xmm0,xmm0
  40bb74:	vmovups XMMWORD PTR [rcx],xmm0
  40bb78:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40bb7d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40bb82:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40bb87:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40bb8c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40bb91:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40bb96:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40bb9b:	ret
  40bb9c:	add    BYTE PTR [rax],al
	...

000000000040bba0 <__swc_fn_0a4ed24b_000007_f7acedb0>:
  40bba0:	push   rsi
  40bba1:	mov    rsi,rdx
  40bba4:	test   rdx,rdx
  40bba7:	jne    40bbb0 <__swc_fn_0a4ed24b_000007_f7acedb0+0x10>
  40bba9:	mov    eax,0x1
  40bbae:	pop    rsi
  40bbaf:	ret
  40bbb0:	mov    rdx,rsi
  40bbb3:	call   40db40 <__swc_fn_0a4ed24b_000115_36905703>
  40bbb8:	test   al,al
  40bbba:	jne    40bbc0 <__swc_fn_0a4ed24b_000007_f7acedb0+0x20>
  40bbbc:	xor    eax,eax
  40bbbe:	pop    rsi
  40bbbf:	ret
  40bbc0:	lea    rcx,[rip+0x184a1]        # 424068 <__swc_bss_base_0a4ed24b+0x28>
  40bbc7:	mov    rdx,QWORD PTR [rip+0x1849a]        # 424068 <__swc_bss_base_0a4ed24b+0x28>
  40bbce:	xchg   ax,ax
  40bbd0:	lea    r8,[rdx+rsi*1]
  40bbd4:	mov    rax,rdx
  40bbd7:	lock cmpxchg QWORD PTR [rcx],r8
  40bbdc:	cmp    rax,rdx
  40bbdf:	je     40bbe6 <__swc_fn_0a4ed24b_000007_f7acedb0+0x46>
  40bbe1:	mov    rdx,rax
  40bbe4:	jmp    40bbd0 <__swc_fn_0a4ed24b_000007_f7acedb0+0x30>
  40bbe6:	lea    rcx,[rip+0x18483]        # 424070 <__swc_bss_base_0a4ed24b+0x30>
  40bbed:	mov    rdx,QWORD PTR [rip+0x1847c]        # 424070 <__swc_bss_base_0a4ed24b+0x30>
  40bbf4:	cs nop WORD PTR [rax+rax*1+0x0]
  40bbfe:	xchg   ax,ax
  40bc00:	lea    r8,[rdx+0x1]
  40bc04:	mov    rax,rdx
  40bc07:	lock cmpxchg QWORD PTR [rcx],r8
  40bc0c:	cmp    rax,rdx
  40bc0f:	je     40bc16 <__swc_fn_0a4ed24b_000007_f7acedb0+0x76>
  40bc11:	mov    rdx,rax
  40bc14:	jmp    40bc00 <__swc_fn_0a4ed24b_000007_f7acedb0+0x60>
  40bc16:	mov    eax,0x1
  40bc1b:	pop    rsi
  40bc1c:	ret
  40bc1d:	add    BYTE PTR [rax],al
	...

000000000040bc20 <__swc_fn_0a4ed24b_000010_24a20786>:
  40bc20:	push   rbx
  40bc21:	push   rsi
  40bc22:	push   rdi
  40bc23:	push   r12
  40bc25:	sub    rsp,0x18
  40bc29:	mov    rbx,rcx
  40bc2c:	mov    rsi,rcx
  40bc2f:	and    rsi,0xffffffffffc00000
  40bc36:	movzx  eax,BYTE PTR [rbx+0x3a]
  40bc3a:	mov    ecx,DWORD PTR [rsi+0x28]
  40bc3d:	shrx   eax,eax,ecx
  40bc42:	lea    rdi,[rsp+0x8]
  40bc47:	mov    DWORD PTR [rsp+0x8],eax
  40bc4b:	mov    rcx,rsi
  40bc4e:	mov    rax,rdi
  40bc51:	mov    edx,DWORD PTR [rax]
  40bc53:	call   407700 <__swc_fn_0a4ed24b_000015_9dea5065>
  40bc58:	mov    r12,rax
  40bc5b:	mov    rcx,rsi
  40bc5e:	mov    edx,DWORD PTR [rdi]
  40bc60:	call   40bd50 <__swc_fn_0a4ed24b_000016_9afb7cfb>
  40bc65:	mov    rcx,r12
  40bc68:	mov    edx,DWORD PTR [rbx+0x3c]
  40bc6b:	add    rcx,rdx
  40bc6e:	cmp    rcx,rax
  40bc71:	jb     40bc7f <__swc_fn_0a4ed24b_000010_24a20786+0x5f>
  40bc73:	xor    eax,eax
  40bc75:	add    rsp,0x18
  40bc79:	pop    r12
  40bc7b:	pop    rdi
  40bc7c:	pop    rsi
  40bc7d:	pop    rbx
  40bc7e:	ret
  40bc7f:	mov    rdx,QWORD PTR [rbx+0x20]
  40bc83:	mov    r8d,DWORD PTR [rbx+0x2c]
  40bc87:	add    rdx,r8
  40bc8a:	lea    rsi,[rdx+0xffff]
  40bc91:	and    rsi,0xffffffffffff0000
  40bc98:	cmp    rax,rsi
  40bc9b:	cmovbe rsi,rax
  40bc9f:	mov    rax,rsi
  40bca2:	sub    rax,rcx
  40bca5:	mov    rdx,rax
  40bca8:	call   40bba0 <__swc_fn_0a4ed24b_000007_f7acedb0>
  40bcad:	test   al,al
  40bcaf:	jne    40bcbd <__swc_fn_0a4ed24b_000010_24a20786+0x9d>
  40bcb1:	xor    eax,eax
  40bcb3:	add    rsp,0x18
  40bcb7:	pop    r12
  40bcb9:	pop    rdi
  40bcba:	pop    rsi
  40bcbb:	pop    rbx
  40bcbc:	ret
  40bcbd:	sub    rsi,r12
  40bcc0:	mov    DWORD PTR [rbx+0x3c],esi
  40bcc3:	mov    ecx,DWORD PTR [rbx+0x2c]
  40bcc6:	mov    rax,rsi
  40bcc9:	xor    edx,edx
  40bccb:	div    rcx
  40bcce:	imul   rax,rcx
  40bcd2:	add    r12,rax
  40bcd5:	mov    QWORD PTR [rbx+0x18],r12
  40bcd9:	mov    eax,0x1
  40bcde:	add    rsp,0x18
  40bce2:	pop    r12
  40bce4:	pop    rdi
  40bce5:	pop    rsi
  40bce6:	pop    rbx
  40bce7:	ret
	...

000000000040bcf0 <__swc_fn_0a4ed24b_000013_e4b0ddfc>:
  40bcf0:	sub    rsp,0x8
  40bcf4:	mov    rdx,rcx
  40bcf7:	lea    r9,[rcx+0x60]
  40bcfb:	mov    rax,QWORD PTR [r9]
  40bcfe:	test   rax,rax
  40bd01:	jne    40bd08 <__swc_fn_0a4ed24b_000013_e4b0ddfc+0x18>
  40bd03:	add    rsp,0x8
  40bd07:	ret
  40bd08:	mov    rcx,rdx
  40bd0b:	call   40f090 <__swc_fn_0a4ed24b_000011_c3647f66>
  40bd10:	xor    eax,eax
  40bd12:	xchg   QWORD PTR [r9],rax
  40bd15:	mov    r8,rax
  40bd18:	mov    rcx,rdx
  40bd1b:	call   4076f0 <__swc_fn_0a4ed24b_000012_861b8b62>
  40bd20:	xor    eax,eax
  40bd22:	test   r8,r8
  40bd25:	je     40bd46 <__swc_fn_0a4ed24b_000013_e4b0ddfc+0x56>
  40bd27:	nop    WORD PTR [rax+rax*1+0x0]
  40bd30:	mov    rcx,QWORD PTR [r8]
  40bd33:	mov    r9,QWORD PTR [rdx]
  40bd36:	mov    QWORD PTR [r8],r9
  40bd39:	mov    QWORD PTR [rdx],r8
  40bd3c:	mov    r8,rcx
  40bd3f:	inc    eax
  40bd41:	test   rcx,rcx
  40bd44:	jne    40bd30 <__swc_fn_0a4ed24b_000013_e4b0ddfc+0x40>
  40bd46:	sub    DWORD PTR [rdx+0x28],eax
  40bd49:	add    rsp,0x8
  40bd4d:	ret
	...

000000000040bd50 <__swc_fn_0a4ed24b_000016_9afb7cfb>:
  40bd50:	lea    eax,[rdx+0x1]
  40bd53:	mov    edx,DWORD PTR [rcx+0x28]
  40bd56:	shlx   eax,eax,edx
  40bd5b:	shl    rax,0x10
  40bd5f:	add    rax,rcx
  40bd62:	ret
	...

000000000040bd70 <__swc_fn_0a4ed24b_000019_adca76cf>:
  40bd70:	push   rbx
  40bd71:	push   rsi
  40bd72:	push   rdi
  40bd73:	push   r12
  40bd75:	push   r13
  40bd77:	push   r14
  40bd79:	push   r15
  40bd7b:	sub    rsp,0x30
  40bd7f:	mov    rbx,rcx
  40bd82:	lea    rsi,[rcx+0x48]
  40bd86:	mov    QWORD PTR [rsp+0x18],rsi
  40bd8b:	mov    rax,QWORD PTR [rsi]
  40bd8e:	mov    rdi,rax
  40bd91:	lea    r12,[rsp+0x8]
  40bd96:	lea    r13,[rcx+0x40]
  40bd9a:	nop    WORD PTR [rax+rax*1+0x0]
  40bda0:	test   rdi,rdi
  40bda3:	je     40bee3 <__swc_fn_0a4ed24b_000019_adca76cf+0x173>
  40bda9:	xor    eax,eax
  40bdab:	tzcnt  rax,rdi
  40bdb0:	mov    DWORD PTR [rsp+0x8],eax
  40bdb4:	mov    r14d,0x1
  40bdba:	mov    ecx,eax
  40bdbc:	shl    r14,cl
  40bdbf:	andn   rdi,r14,rdi
  40bdc4:	mov    rcx,QWORD PTR [r13+0x0]
  40bdc8:	test   rcx,r14
  40bdcb:	jne    40bda0 <__swc_fn_0a4ed24b_000019_adca76cf+0x30>
  40bdcd:	mov    rdx,rcx
  40bdd0:	or     rdx,r14
  40bdd3:	mov    rax,rcx
  40bdd6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  40bddc:	cmp    rax,rcx
  40bddf:	je     40bde9 <__swc_fn_0a4ed24b_000019_adca76cf+0x79>
  40bde1:	mov    rax,QWORD PTR [rsi]
  40bde4:	mov    rdi,rax
  40bde7:	jmp    40bda0 <__swc_fn_0a4ed24b_000019_adca76cf+0x30>
  40bde9:	mov    rcx,rbx
  40bdec:	mov    rdx,r14
  40bdef:	call   407860 <__swc_fn_0a4ed24b_000021_fd2b165c>
  40bdf4:	test   al,al
  40bdf6:	je     40bece <__swc_fn_0a4ed24b_000019_adca76cf+0x15e>
  40bdfc:	mov    eax,DWORD PTR [r12]
  40be00:	shl    rax,0x4
  40be04:	lea    r15,[rbx+rax*8+0x80]
  40be0c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  40be14:	lea    rcx,[rip+0x1825d]        # 424078 <__swc_bss_base_0a4ed24b+0x38>
  40be1b:	mov    rdx,QWORD PTR [rip+0x18256]        # 424078 <__swc_bss_base_0a4ed24b+0x38>
  40be22:	cs nop WORD PTR [rax+rax*1+0x0]
  40be2c:	nop    DWORD PTR [rax+0x0]
  40be30:	mov    r8,rdx
  40be33:	sub    r8,rsi
  40be36:	mov    rax,rdx
  40be39:	lock cmpxchg QWORD PTR [rcx],r8
  40be3e:	cmp    rax,rdx
  40be41:	je     40be48 <__swc_fn_0a4ed24b_000019_adca76cf+0xd8>
  40be43:	mov    rdx,rax
  40be46:	jmp    40be30 <__swc_fn_0a4ed24b_000019_adca76cf+0xc0>
  40be48:	mov    rcx,rbx
  40be4b:	mov    rax,r12
  40be4e:	mov    edx,DWORD PTR [rax]
  40be50:	call   407700 <__swc_fn_0a4ed24b_000015_9dea5065>
  40be55:	test   rsi,rsi
  40be58:	je     40bec6 <__swc_fn_0a4ed24b_000019_adca76cf+0x156>
  40be5e:	mov    rcx,rax
  40be61:	mov    rdx,rsi
  40be64:	call   411300 <__swc_fn_0a4ed24b_000116_e9fc0224>
  40be69:	lea    rcx,[rip+0x181f8]        # 424068 <__swc_bss_base_0a4ed24b+0x28>
  40be70:	mov    rdx,QWORD PTR [rip+0x181f1]        # 424068 <__swc_bss_base_0a4ed24b+0x28>
  40be77:	nop    WORD PTR [rax+rax*1+0x0]
  40be80:	mov    r8,rdx
  40be83:	sub    r8,rsi
  40be86:	mov    rax,rdx
  40be89:	lock cmpxchg QWORD PTR [rcx],r8
  40be8e:	cmp    rax,rdx
  40be91:	je     40be98 <__swc_fn_0a4ed24b_000019_adca76cf+0x128>
  40be93:	mov    rdx,rax
  40be96:	jmp    40be80 <__swc_fn_0a4ed24b_000019_adca76cf+0x110>
  40be98:	lea    rcx,[rip+0x181e1]        # 424080 <__swc_bss_base_0a4ed24b+0x40>
  40be9f:	mov    rdx,QWORD PTR [rip+0x181da]        # 424080 <__swc_bss_base_0a4ed24b+0x40>
  40bea6:	cs nop WORD PTR [rax+rax*1+0x0]
  40beb0:	lea    r8,[rdx+0x1]
  40beb4:	mov    rax,rdx
  40beb7:	lock cmpxchg QWORD PTR [rcx],r8
  40bebc:	cmp    rax,rdx
  40bebf:	je     40bec6 <__swc_fn_0a4ed24b_000019_adca76cf+0x156>
  40bec1:	mov    rdx,rax
  40bec4:	jmp    40beb0 <__swc_fn_0a4ed24b_000019_adca76cf+0x140>
  40bec6:	mov    DWORD PTR [r15+0x3c],0x0
  40bece:	mov    rcx,rbx
  40bed1:	mov    rdx,r14
  40bed4:	call   40bf00 <__swc_fn_0a4ed24b_000022_c8f5f27c>
  40bed9:	mov    rsi,QWORD PTR [rsp+0x18]
  40bede:	jmp    40bda0 <__swc_fn_0a4ed24b_000019_adca76cf+0x30>
  40bee3:	add    rsp,0x30
  40bee7:	pop    r15
  40bee9:	pop    r14
  40beeb:	pop    r13
  40beed:	pop    r12
  40beef:	pop    rdi
  40bef0:	pop    rsi
  40bef1:	pop    rbx
  40bef2:	ret
	...

000000000040bf00 <__swc_fn_0a4ed24b_000022_c8f5f27c>:
  40bf00:	mov    r8,QWORD PTR [rcx+0x40]
  40bf04:	cs nop WORD PTR [rax+rax*1+0x0]
  40bf0e:	xchg   ax,ax
  40bf10:	mov    rax,rdx
  40bf13:	not    rax
  40bf16:	mov    r9,r8
  40bf19:	and    r9,rax
  40bf1c:	mov    rax,r8
  40bf1f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  40bf25:	cmp    rax,r8
  40bf28:	jne    40bf2b <__swc_fn_0a4ed24b_000022_c8f5f27c+0x2b>
  40bf2a:	ret
  40bf2b:	mov    r8,rax
  40bf2e:	jmp    40bf10 <__swc_fn_0a4ed24b_000022_c8f5f27c+0x10>

000000000040bf30 <__swc_fn_0a4ed24b_000025_aa910677>:
  40bf30:	push   rsi
  40bf31:	push   rdi
  40bf32:	sub    rsp,0x8
  40bf36:	mov    rsi,rcx
  40bf39:	call   40bd70 <__swc_fn_0a4ed24b_000019_adca76cf>
  40bf3e:	lea    rdi,[rip+0x182cb]        # 424210 <__swc_bss_base_0a4ed24b+0x1d0>
  40bf45:	mov    rcx,rdi
  40bf48:	call   40e1a0 <__swc_fn_0a4ed24b_000139_86bb0f90>
  40bf4d:	mov    QWORD PTR [rsi+0x8],0x0
  40bf55:	mov    QWORD PTR [rsi+0x18],0x0
  40bf5d:	mov    rax,QWORD PTR [rip+0x182b4]        # 424218 <__swc_bss_base_0a4ed24b+0x1d8>
  40bf64:	mov    QWORD PTR [rsi+0x10],rax
  40bf68:	mov    QWORD PTR [rip+0x182a9],rsi        # 424218 <__swc_bss_base_0a4ed24b+0x1d8>
  40bf6f:	mov    rcx,rdi
  40bf72:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40bf77:	add    rsp,0x8
  40bf7b:	pop    rdi
  40bf7c:	pop    rsi
  40bf7d:	ret
	...

000000000040bf80 <__swc_fn_0a4ed24b_000028_9798fb47>:
  40bf80:	vxorps xmm0,xmm0,xmm0
  40bf84:	vmovups XMMWORD PTR [rcx],xmm0
  40bf88:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40bf8d:	mov    QWORD PTR [rcx+0x20],0x0
  40bf95:	ret
	...

000000000040bfa0 <__swc_fn_0a4ed24b_000031_9798fb47>:
  40bfa0:	vxorps xmm0,xmm0,xmm0
  40bfa4:	vmovups XMMWORD PTR [rcx],xmm0
  40bfa8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40bfad:	mov    QWORD PTR [rcx+0x20],0x0
  40bfb5:	ret
	...

000000000040bfc0 <__swc_fn_0a4ed24b_000034_9128bcf9>:
  40bfc0:	push   r12
  40bfc2:	mov    r12,rdi
  40bfc5:	test   rdi,rdi
  40bfc8:	jne    40bfcd <__swc_fn_0a4ed24b_000034_9128bcf9+0xd>
  40bfca:	pop    r12
  40bfcc:	ret
  40bfcd:	lea    rax,[rip+0x16034]        # 422008 <__swc_data_base_0a4ed24b+0x8>
  40bfd4:	mov    rax,QWORD PTR [rax]
  40bfd7:	cmp    rax,0xffffffffffffffff
  40bfdb:	je     40bfea <__swc_fn_0a4ed24b_000034_9128bcf9+0x2a>
  40bfdd:	mov    eax,eax
  40bfdf:	mov    edi,eax
  40bfe1:	xor    eax,eax
  40bfe3:	call   407010 <pthread_getspecific@plt>
  40bfe8:	jmp    40bfec <__swc_fn_0a4ed24b_000034_9128bcf9+0x2c>
  40bfea:	xor    eax,eax
  40bfec:	cmp    rax,r12
  40bfef:	jne    40bff8 <__swc_fn_0a4ed24b_000034_9128bcf9+0x38>
  40bff1:	xor    ecx,ecx
  40bff3:	call   407a20 <__swc_fn_0a4ed24b_000036_92d9bbff>
  40bff8:	mov    rdx,QWORD PTR [r12]
  40bffc:	test   rdx,rdx
  40bfff:	je     40c018 <__swc_fn_0a4ed24b_000034_9128bcf9+0x58>
  40c001:	mov    rcx,rdx
  40c004:	call   40c040 <__swc_fn_0a4ed24b_000040_eb6108f2>
  40c009:	test   al,al
  40c00b:	je     40c018 <__swc_fn_0a4ed24b_000034_9128bcf9+0x58>
  40c00d:	mov    rcx,rdx
  40c010:	mov    rdx,r12
  40c013:	call   40c140 <__swc_fn_0a4ed24b_000046_b30433d0>
  40c018:	pop    r12
  40c01a:	ret
  40c01b:	add    BYTE PTR [rax],al
  40c01d:	add    BYTE PTR [rax],al
	...

000000000040c020 <__swc_fn_0a4ed24b_000037_28d0e998>:
  40c020:	push   rsi
  40c021:	mov    rsi,rcx
  40c024:	call   40f540 <__swc_fn_0a4ed24b_000035_cd1a4e8c>
  40c029:	mov    rcx,rax
  40c02c:	mov    rdx,rsi
  40c02f:	call   40e020 <__swc_fn_0a4ed24b_000133_ae5891af>
  40c034:	mov    rcx,rsi
  40c037:	call   407a20 <__swc_fn_0a4ed24b_000036_92d9bbff>
  40c03c:	pop    rsi
  40c03d:	ret
	...

000000000040c040 <__swc_fn_0a4ed24b_000040_eb6108f2>:
  40c040:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40c04a:	sete   al
  40c04d:	ret
	...

000000000040c050 <__swc_fn_0a4ed24b_000043_d3c2ab54>:
  40c050:	push   rsi
  40c051:	test   rdx,rdx
  40c054:	jne    40c058 <__swc_fn_0a4ed24b_000043_d3c2ab54+0x8>
  40c056:	pop    rsi
  40c057:	ret
  40c058:	mov    rax,r8
  40c05b:	mov    ecx,0x1000
  40c060:	test   ecx,ecx
  40c062:	mov    r10d,0x8
  40c068:	cmove  ecx,r10d
  40c06c:	dec    rcx
  40c06f:	mov    r10,0xffffffffffffffff
  40c076:	sub    r10,rcx
  40c079:	cmp    r8,r10
  40c07c:	jbe    40c082 <__swc_fn_0a4ed24b_000043_d3c2ab54+0x32>
  40c07e:	xor    eax,eax
  40c080:	jmp    40c08a <__swc_fn_0a4ed24b_000043_d3c2ab54+0x3a>
  40c082:	add    rax,rcx
  40c085:	andn   rax,rcx,rax
  40c08a:	mov    ecx,0x1000
  40c08f:	test   ecx,ecx
  40c091:	mov    r8d,0x8
  40c097:	cmove  ecx,r8d
  40c09b:	dec    rcx
  40c09e:	mov    r8,0xffffffffffffffff
  40c0a5:	sub    r8,rcx
  40c0a8:	cmp    r9,r8
  40c0ab:	jbe    40c0b1 <__swc_fn_0a4ed24b_000043_d3c2ab54+0x61>
  40c0ad:	xor    esi,esi
  40c0af:	jmp    40c0bc <__swc_fn_0a4ed24b_000043_d3c2ab54+0x6c>
  40c0b1:	add    r9,rcx
  40c0b4:	andn   r9,rcx,r9
  40c0b9:	mov    rsi,r9
  40c0bc:	mov    rcx,rdx
  40c0bf:	mov    rdx,rax
  40c0c2:	mov    r8,rsi
  40c0c5:	call   40dc20 <__swc_fn_0a4ed24b_000118_5208f471>
  40c0ca:	lea    rcx,[rip+0x17f97]        # 424068 <__swc_bss_base_0a4ed24b+0x28>
  40c0d1:	mov    rdx,QWORD PTR [rip+0x17f90]        # 424068 <__swc_bss_base_0a4ed24b+0x28>
  40c0d8:	nop    DWORD PTR [rax+rax*1+0x0]
  40c0e0:	mov    r8,rdx
  40c0e3:	sub    r8,rsi
  40c0e6:	mov    rax,rdx
  40c0e9:	lock cmpxchg QWORD PTR [rcx],r8
  40c0ee:	cmp    rax,rdx
  40c0f1:	je     40c0f8 <__swc_fn_0a4ed24b_000043_d3c2ab54+0xa8>
  40c0f3:	mov    rdx,rax
  40c0f6:	jmp    40c0e0 <__swc_fn_0a4ed24b_000043_d3c2ab54+0x90>
  40c0f8:	lea    rcx,[rip+0x17f81]        # 424080 <__swc_bss_base_0a4ed24b+0x40>
  40c0ff:	mov    rdx,QWORD PTR [rip+0x17f7a]        # 424080 <__swc_bss_base_0a4ed24b+0x40>
  40c106:	cs nop WORD PTR [rax+rax*1+0x0]
  40c110:	lea    r8,[rdx+0x1]
  40c114:	mov    rax,rdx
  40c117:	lock cmpxchg QWORD PTR [rcx],r8
  40c11c:	cmp    rax,rdx
  40c11f:	je     40c126 <__swc_fn_0a4ed24b_000043_d3c2ab54+0xd6>
  40c121:	mov    rdx,rax
  40c124:	jmp    40c110 <__swc_fn_0a4ed24b_000043_d3c2ab54+0xc0>
  40c126:	pop    rsi
  40c127:	ret
	...

000000000040c140 <__swc_fn_0a4ed24b_000046_b30433d0>:
  40c140:	push   rbx
  40c141:	push   rsi
  40c142:	push   rdi
  40c143:	push   r12
  40c145:	push   r13
  40c147:	push   r14
  40c149:	push   r15
  40c14b:	sub    rsp,0x30
  40c14f:	mov    rbx,rdx
  40c152:	mov    QWORD PTR [rsp+0x18],rdx
  40c157:	mov    rsi,rcx
  40c15a:	mov    eax,0x1
  40c15f:	xchg   DWORD PTR [rbx+0x20],eax
  40c162:	test   eax,eax
  40c164:	je     40c176 <__swc_fn_0a4ed24b_000046_b30433d0+0x36>
  40c166:	add    rsp,0x30
  40c16a:	pop    r15
  40c16c:	pop    r14
  40c16e:	pop    r13
  40c170:	pop    r12
  40c172:	pop    rdi
  40c173:	pop    rsi
  40c174:	pop    rbx
  40c175:	ret
  40c176:	mov    rcx,rsi
  40c179:	mov    rdx,rbx
  40c17c:	mov    r8,0xffffffffffffffff
  40c183:	call   407ff0 <__swc_fn_0a4ed24b_000063_dea90857>
  40c188:	lea    rdi,[rsi+0x10]
  40c18c:	mov    QWORD PTR [rsp+0x20],rdi
  40c191:	mov    rcx,rdi
  40c194:	call   40e1a0 <__swc_fn_0a4ed24b_000139_86bb0f90>
  40c199:	xor    r12d,r12d
  40c19c:	cs nop WORD PTR [rax+rax*1+0x0]
  40c1a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40c1b0:	mov    eax,r12d
  40c1b3:	lea    r13,[rax+rax*4]
  40c1b7:	lea    r13,[rbx+r13*8+0x28]
  40c1bc:	mov    rax,QWORD PTR [r13+0x8]
  40c1c0:	mov    QWORD PTR [rsp+0x8],rax
  40c1c5:	mov    rax,QWORD PTR [r13+0x18]
  40c1c9:	mov    QWORD PTR [rsp+0x10],rax
  40c1ce:	mov    r14d,0x2
  40c1d4:	xor    r15d,r15d
  40c1d7:	test   r14,r14
  40c1da:	je     40c257 <__swc_fn_0a4ed24b_000046_b30433d0+0x117>
  40c1e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  40c1e5:	mov    rdi,rax
  40c1e8:	test   rdi,rdi
  40c1eb:	je     40c249 <__swc_fn_0a4ed24b_000046_b30433d0+0x109>
  40c1ed:	nop    DWORD PTR [rax]
  40c1f0:	mov    rbx,QWORD PTR [rdi+0x48]
  40c1f4:	mov    DWORD PTR [rdi+0x6c],0x0
  40c1fb:	mov    rcx,rdi
  40c1fe:	call   40bcf0 <__swc_fn_0a4ed24b_000013_e4b0ddfc>
  40c203:	cmp    DWORD PTR [rdi+0x28],0x0
  40c207:	jne    40c220 <__swc_fn_0a4ed24b_000046_b30433d0+0xe0>
  40c209:	mov    rax,rdi
  40c20c:	and    rax,0xffffffffffc00000
  40c213:	mov    rcx,rax
  40c216:	mov    rdx,rdi
  40c219:	call   407720 <__swc_fn_0a4ed24b_000018_283e2b5e>
  40c21e:	jmp    40c241 <__swc_fn_0a4ed24b_000046_b30433d0+0x101>
  40c220:	mov    QWORD PTR [rdi+0x40],0x0
  40c228:	rex mov BYTE PTR [rdi+0x3b],0x2
  40c22d:	mov    QWORD PTR [rdi+0x50],0x0
  40c235:	mov    rax,QWORD PTR [rsi+0x28]
  40c239:	mov    QWORD PTR [rdi+0x48],rax
  40c23d:	mov    QWORD PTR [rsi+0x28],rdi
  40c241:	mov    rdi,rbx
  40c244:	test   rbx,rbx
  40c247:	jne    40c1f0 <__swc_fn_0a4ed24b_000046_b30433d0+0xb0>
  40c249:	add    r15,0x1
  40c24d:	sub    r14,0x1
  40c251:	jne    40c1e0 <__swc_fn_0a4ed24b_000046_b30433d0+0xa0>
  40c257:	vxorps xmm0,xmm0,xmm0
  40c25b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  40c261:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40c267:	mov    QWORD PTR [r13+0x20],0x0
  40c26f:	add    r12,0x1
  40c273:	cmp    r12,0x2d
  40c277:	mov    rbx,QWORD PTR [rsp+0x18]
  40c27c:	jb     40c1b0 <__swc_fn_0a4ed24b_000046_b30433d0+0x70>
  40c282:	mov    rcx,rsi
  40c285:	mov    rbx,QWORD PTR [rsp+0x18]
  40c28a:	mov    rdx,rbx
  40c28d:	mov    rdi,QWORD PTR [rsp+0x20]
  40c292:	call   40f700 <__swc_fn_0a4ed24b_000047_6e7a8d58>
  40c297:	mov    rcx,rdi
  40c29a:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40c29f:	mov    rcx,rsi
  40c2a2:	mov    rdx,rbx
  40c2a5:	mov    r8d,0x9b8
  40c2ab:	mov    r9d,0x9b8
  40c2b1:	call   40c050 <__swc_fn_0a4ed24b_000043_d3c2ab54>
  40c2b6:	add    rsp,0x30
  40c2ba:	pop    r15
  40c2bc:	pop    r14
  40c2be:	pop    r13
  40c2c0:	pop    r12
  40c2c2:	pop    rdi
  40c2c3:	pop    rsi
  40c2c4:	pop    rbx
  40c2c5:	ret
	...

000000000040c2e0 <__swc_fn_0a4ed24b_000049_ad48ec88>:
  40c2e0:	push   rbx
  40c2e1:	push   rsi
  40c2e2:	push   rdi
  40c2e3:	push   r12
  40c2e5:	push   r13
  40c2e7:	push   r14
  40c2e9:	push   r15
  40c2eb:	sub    rsp,0x30
  40c2ef:	mov    ebx,r8d
  40c2f2:	mov    rsi,rcx
  40c2f5:	mov    rdi,rdx
  40c2f8:	test   r8d,r8d
  40c2fb:	jne    40c304 <__swc_fn_0a4ed24b_000049_ad48ec88+0x24>
  40c2fd:	mov    eax,0x8
  40c302:	jmp    40c32b <__swc_fn_0a4ed24b_000049_ad48ec88+0x4b>
  40c304:	cmp    ebx,0x8
  40c307:	ja     40c312 <__swc_fn_0a4ed24b_000049_ad48ec88+0x32>
  40c309:	mov    rax,rbx
  40c30c:	shl    rax,0x4
  40c310:	jmp    40c32b <__swc_fn_0a4ed24b_000049_ad48ec88+0x4b>
  40c312:	lea    eax,[rbx-0x9]
  40c315:	mov    ecx,eax
  40c317:	shr    ecx,0x2
  40c31a:	and    eax,0x3
  40c31d:	lea    ecx,[rcx+0x7]
  40c320:	lea    ecx,[rcx-0x2]
  40c323:	lea    eax,[rax+0x5]
  40c326:	shlx   rax,rax,rcx
  40c32b:	lea    r12,[rsp+0x8]
  40c330:	mov    DWORD PTR [rsp+0x8],eax
  40c334:	lea    r13,[rsp+0xc]
  40c339:	mov    QWORD PTR [rsp+0x18],r13
  40c33e:	xor    eax,eax
  40c340:	cmp    ebx,0x21
  40c343:	setae  al
  40c346:	lea    eax,[rax+rax*2]
  40c349:	mov    DWORD PTR [rsp+0xc],eax
  40c34d:	lea    r14,[rsi+0x10]
  40c351:	mov    rcx,r14
  40c354:	call   40e1a0 <__swc_fn_0a4ed24b_000139_86bb0f90>
  40c359:	xor    eax,eax
  40c35b:	mov    rcx,QWORD PTR [rsi+0x28]
  40c35f:	mov    r15,rcx
  40c362:	test   r15,r15
  40c365:	je     40c416 <__swc_fn_0a4ed24b_000049_ad48ec88+0x136>
  40c36b:	cs nop WORD PTR [rax+rax*1+0x0]
  40c375:	cs nop WORD PTR [rax+rax*1+0x0]
  40c37f:	nop
  40c380:	mov    rcx,QWORD PTR [r15+0x48]
  40c384:	movzx  edx,BYTE PTR [r15+0x39]
  40c389:	cmp    edx,ebx
  40c38b:	jne    40c407 <__swc_fn_0a4ed24b_000049_ad48ec88+0x127>
  40c38d:	test   rax,rax
  40c390:	jne    40c398 <__swc_fn_0a4ed24b_000049_ad48ec88+0xb8>
  40c392:	mov    QWORD PTR [rsi+0x28],rcx
  40c396:	jmp    40c39c <__swc_fn_0a4ed24b_000049_ad48ec88+0xbc>
  40c398:	mov    QWORD PTR [rax+0x48],rcx
  40c39c:	vxorps xmm0,xmm0,xmm0
  40c3a0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  40c3a6:	mov    BYTE PTR [r15+0x3b],0x1
  40c3ab:	mov    QWORD PTR [r15+0x40],rdi
  40c3af:	mov    rcx,r15
  40c3b2:	call   40bcf0 <__swc_fn_0a4ed24b_000013_e4b0ddfc>
  40c3b7:	movzx  eax,BYTE PTR [r15+0x39]
  40c3bc:	lea    rax,[rax+rax*4]
  40c3c0:	lea    rax,[rdi+rax*8+0x28]
  40c3c5:	mov    rcx,QWORD PTR [rax+0x10]
  40c3c9:	mov    QWORD PTR [r15+0x50],rcx
  40c3cd:	mov    QWORD PTR [r15+0x48],0x0
  40c3d5:	mov    rcx,QWORD PTR [rax+0x10]
  40c3d9:	test   rcx,rcx
  40c3dc:	je     40c3e4 <__swc_fn_0a4ed24b_000049_ad48ec88+0x104>
  40c3de:	mov    QWORD PTR [rcx+0x48],r15
  40c3e2:	jmp    40c3e8 <__swc_fn_0a4ed24b_000049_ad48ec88+0x108>
  40c3e4:	mov    QWORD PTR [rax+0x8],r15
  40c3e8:	mov    QWORD PTR [rax+0x10],r15
  40c3ec:	mov    rcx,r14
  40c3ef:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40c3f4:	mov    rax,r15
  40c3f7:	add    rsp,0x30
  40c3fb:	pop    r15
  40c3fd:	pop    r14
  40c3ff:	pop    r13
  40c401:	pop    r12
  40c403:	pop    rdi
  40c404:	pop    rsi
  40c405:	pop    rbx
  40c406:	ret
  40c407:	mov    rax,r15
  40c40a:	mov    r15,rcx
  40c40d:	test   rcx,rcx
  40c410:	jne    40c380 <__swc_fn_0a4ed24b_000049_ad48ec88+0xa0>
  40c416:	mov    rax,QWORD PTR [rsi+0x18]
  40c41a:	mov    r15,rax
  40c41d:	test   r15,r15
  40c420:	je     40c4b6 <__swc_fn_0a4ed24b_000049_ad48ec88+0x1d6>
  40c426:	cs nop WORD PTR [rax+rax*1+0x0]
  40c430:	mov    eax,DWORD PTR [rsp+0xc]
  40c434:	cmp    DWORD PTR [r15+0x28],eax
  40c438:	jne    40c4a6 <__swc_fn_0a4ed24b_000049_ad48ec88+0x1c6>
  40c43a:	mov    rcx,r15
  40c43d:	mov    edx,ebx
  40c43f:	mov    rax,r12
  40c442:	mov    r8d,DWORD PTR [rax]
  40c445:	call   40f140 <__swc_fn_0a4ed24b_000017_efc44797>
  40c44a:	mov    r13,rax
  40c44d:	test   rax,rax
  40c450:	je     40c4a6 <__swc_fn_0a4ed24b_000049_ad48ec88+0x1c6>
  40c452:	mov    QWORD PTR [r13+0x40],rdi
  40c456:	movzx  eax,BYTE PTR [r13+0x39]
  40c45b:	lea    rax,[rax+rax*4]
  40c45f:	lea    rax,[rdi+rax*8+0x28]
  40c464:	mov    rcx,QWORD PTR [rax+0x10]
  40c468:	mov    QWORD PTR [r13+0x50],rcx
  40c46c:	mov    QWORD PTR [r13+0x48],0x0
  40c474:	mov    rcx,QWORD PTR [rax+0x10]
  40c478:	test   rcx,rcx
  40c47b:	je     40c483 <__swc_fn_0a4ed24b_000049_ad48ec88+0x1a3>
  40c47d:	mov    QWORD PTR [rcx+0x48],r13
  40c481:	jmp    40c487 <__swc_fn_0a4ed24b_000049_ad48ec88+0x1a7>
  40c483:	mov    QWORD PTR [rax+0x8],r13
  40c487:	mov    QWORD PTR [rax+0x10],r13
  40c48b:	mov    rcx,r14
  40c48e:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40c493:	mov    rax,r13
  40c496:	add    rsp,0x30
  40c49a:	pop    r15
  40c49c:	pop    r14
  40c49e:	pop    r13
  40c4a0:	pop    r12
  40c4a2:	pop    rdi
  40c4a3:	pop    rsi
  40c4a4:	pop    rbx
  40c4a5:	ret
  40c4a6:	mov    rax,QWORD PTR [r15+0x10]
  40c4aa:	mov    r15,rax
  40c4ad:	test   rax,rax
  40c4b0:	jne    40c430 <__swc_fn_0a4ed24b_000049_ad48ec88+0x150>
  40c4b6:	mov    rcx,rsi
  40c4b9:	mov    r13,QWORD PTR [rsp+0x18]
  40c4be:	mov    edx,DWORD PTR [r13+0x0]
  40c4c2:	call   4078a0 <__swc_fn_0a4ed24b_000024_2685aade>
  40c4c7:	mov    r13,rax
  40c4ca:	test   rax,rax
  40c4cd:	jne    40c4e9 <__swc_fn_0a4ed24b_000049_ad48ec88+0x209>
  40c4cf:	mov    rcx,r14
  40c4d2:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40c4d7:	xor    eax,eax
  40c4d9:	add    rsp,0x30
  40c4dd:	pop    r15
  40c4df:	pop    r14
  40c4e1:	pop    r13
  40c4e3:	pop    r12
  40c4e5:	pop    rdi
  40c4e6:	pop    rsi
  40c4e7:	pop    rbx
  40c4e8:	ret
  40c4e9:	mov    rcx,r13
  40c4ec:	mov    edx,ebx
  40c4ee:	mov    r8d,DWORD PTR [r12]
  40c4f2:	call   40f140 <__swc_fn_0a4ed24b_000017_efc44797>
  40c4f7:	mov    rbx,rax
  40c4fa:	test   rax,rax
  40c4fd:	jne    40c521 <__swc_fn_0a4ed24b_000049_ad48ec88+0x241>
  40c4ff:	mov    rcx,r13
  40c502:	call   40bf30 <__swc_fn_0a4ed24b_000025_aa910677>
  40c507:	mov    rcx,r14
  40c50a:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40c50f:	xor    eax,eax
  40c511:	add    rsp,0x30
  40c515:	pop    r15
  40c517:	pop    r14
  40c519:	pop    r13
  40c51b:	pop    r12
  40c51d:	pop    rdi
  40c51e:	pop    rsi
  40c51f:	pop    rbx
  40c520:	ret
  40c521:	mov    rax,QWORD PTR [rsi+0x18]
  40c525:	mov    QWORD PTR [r13+0x10],rax
  40c529:	mov    rax,QWORD PTR [rsi+0x18]
  40c52d:	test   rax,rax
  40c530:	je     40c536 <__swc_fn_0a4ed24b_000049_ad48ec88+0x256>
  40c532:	mov    QWORD PTR [rax+0x18],r13
  40c536:	mov    QWORD PTR [rsi+0x18],r13
  40c53a:	mov    QWORD PTR [rbx+0x40],rdi
  40c53e:	movzx  eax,BYTE PTR [rbx+0x39]
  40c542:	lea    rax,[rax+rax*4]
  40c546:	lea    rax,[rdi+rax*8+0x28]
  40c54b:	mov    rcx,QWORD PTR [rax+0x10]
  40c54f:	mov    QWORD PTR [rbx+0x50],rcx
  40c553:	mov    QWORD PTR [rbx+0x48],0x0
  40c55b:	mov    rcx,QWORD PTR [rax+0x10]
  40c55f:	test   rcx,rcx
  40c562:	je     40c56a <__swc_fn_0a4ed24b_000049_ad48ec88+0x28a>
  40c564:	mov    QWORD PTR [rcx+0x48],rbx
  40c568:	jmp    40c56e <__swc_fn_0a4ed24b_000049_ad48ec88+0x28e>
  40c56a:	mov    QWORD PTR [rax+0x8],rbx
  40c56e:	mov    QWORD PTR [rax+0x10],rbx
  40c572:	mov    rcx,r14
  40c575:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40c57a:	mov    rax,rbx
  40c57d:	add    rsp,0x30
  40c581:	pop    r15
  40c583:	pop    r14
  40c585:	pop    r13
  40c587:	pop    r12
  40c589:	pop    rdi
  40c58a:	pop    rsi
  40c58b:	pop    rbx
  40c58c:	ret
	...

000000000040c5a0 <__swc_fn_0a4ed24b_000052_d846b172>:
  40c5a0:	push   rsi
  40c5a1:	push   rdi
  40c5a2:	push   r12
  40c5a4:	mov    rsi,rdx
  40c5a7:	mov    rdi,rcx
  40c5aa:	lea    rax,[rcx+0x2a80]
  40c5b1:	mov    rcx,QWORD PTR [rax]
  40c5b4:	test   rcx,rcx
  40c5b7:	jne    40c5be <__swc_fn_0a4ed24b_000052_d846b172+0x1e>
  40c5b9:	pop    r12
  40c5bb:	pop    rdi
  40c5bc:	pop    rsi
  40c5bd:	ret
  40c5be:	xor    ecx,ecx
  40c5c0:	xchg   QWORD PTR [rax],rcx
  40c5c3:	mov    r12,rcx
  40c5c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40c5d0:	cs nop WORD PTR [rax+rax*1+0x0]
  40c5da:	nop    WORD PTR [rax+rax*1+0x0]
  40c5e0:	test   r12,r12
  40c5e3:	je     40c67a <__swc_fn_0a4ed24b_000052_d846b172+0xda>
  40c5e9:	mov    r8,r12
  40c5ec:	mov    r12,QWORD PTR [r12+0x78]
  40c5f1:	lea    rcx,[r8+0x70]
  40c5f5:	xor    eax,eax
  40c5f7:	xchg   DWORD PTR [r8+0x70],eax
  40c5fb:	cmp    QWORD PTR [r8+0x40],rsi
  40c5ff:	jne    40c616 <__swc_fn_0a4ed24b_000052_d846b172+0x76>
  40c601:	mov    eax,DWORD PTR [r8+0x6c]
  40c605:	test   eax,eax
  40c607:	je     40c5e0 <__swc_fn_0a4ed24b_000052_d846b172+0x40>
  40c609:	mov    rcx,rdi
  40c60c:	mov    rdx,rsi
  40c60f:	call   407c50 <__swc_fn_0a4ed24b_000051_e072b516>
  40c614:	jmp    40c5e0 <__swc_fn_0a4ed24b_000052_d846b172+0x40>
  40c616:	mov    rax,QWORD PTR [r8+0x40]
  40c61a:	test   rax,rax
  40c61d:	je     40c5e0 <__swc_fn_0a4ed24b_000052_d846b172+0x40>
  40c61f:	mov    eax,DWORD PTR [r8+0x6c]
  40c623:	test   eax,eax
  40c625:	je     40c5e0 <__swc_fn_0a4ed24b_000052_d846b172+0x40>
  40c627:	mov    r9d,0x1
  40c62d:	xor    eax,eax
  40c62f:	lock cmpxchg DWORD PTR [rcx],r9d
  40c634:	test   eax,eax
  40c636:	jne    40c5e0 <__swc_fn_0a4ed24b_000052_d846b172+0x40>
  40c638:	mov    rax,r8
  40c63b:	and    rax,0xffffffffffc00000
  40c642:	mov    rax,QWORD PTR [rax+0x8]
  40c646:	test   rax,rax
  40c649:	jne    40c651 <__swc_fn_0a4ed24b_000052_d846b172+0xb1>
  40c64b:	xor    eax,eax
  40c64d:	xchg   DWORD PTR [rcx],eax
  40c64f:	jmp    40c5e0 <__swc_fn_0a4ed24b_000052_d846b172+0x40>
  40c651:	lea    rcx,[rax+0x2a80]
  40c658:	mov    rax,QWORD PTR [rcx]
  40c65b:	mov    rdx,rax
  40c65e:	xchg   ax,ax
  40c660:	mov    QWORD PTR [r8+0x78],rdx
  40c664:	mov    rax,rdx
  40c667:	lock cmpxchg QWORD PTR [rcx],r8
  40c66c:	cmp    rax,rdx
  40c66f:	je     40c5e0 <__swc_fn_0a4ed24b_000052_d846b172+0x40>
  40c675:	mov    rdx,rax
  40c678:	jmp    40c660 <__swc_fn_0a4ed24b_000052_d846b172+0xc0>
  40c67a:	pop    r12
  40c67c:	pop    rdi
  40c67d:	pop    rsi
  40c67e:	ret
	...

000000000040c680 <__swc_fn_0a4ed24b_000055_2e3450f7>:
  40c680:	sub    rsp,0x8
  40c684:	mov    r9,r8
  40c687:	movzx  eax,BYTE PTR [r9+0x39]
  40c68c:	lea    rax,[rax+rax*4]
  40c690:	lea    rax,[rdx+rax*8+0x28]
  40c695:	cmp    QWORD PTR [rax],r9
  40c698:	je     40c6a0 <__swc_fn_0a4ed24b_000055_2e3450f7+0x20>
  40c69a:	cmp    QWORD PTR [rax+0x20],r9
  40c69e:	jne    40c6a5 <__swc_fn_0a4ed24b_000055_2e3450f7+0x25>
  40c6a0:	add    rsp,0x8
  40c6a4:	ret
  40c6a5:	cmp    QWORD PTR [rax+0x20],0x0
  40c6aa:	je     40c6b7 <__swc_fn_0a4ed24b_000055_2e3450f7+0x37>
  40c6ac:	mov    r8,QWORD PTR [rax+0x20]
  40c6b0:	cmp    DWORD PTR [r8+0x28],0x0
  40c6b5:	je     40c6c0 <__swc_fn_0a4ed24b_000055_2e3450f7+0x40>
  40c6b7:	mov    QWORD PTR [rax+0x20],r9
  40c6bb:	add    rsp,0x8
  40c6bf:	ret
  40c6c0:	mov    r8,r9
  40c6c3:	call   407bb0 <__swc_fn_0a4ed24b_000048_137687bb>
  40c6c8:	mov    rax,r9
  40c6cb:	and    rax,0xffffffffffc00000
  40c6d2:	mov    rcx,rax
  40c6d5:	mov    rdx,r9
  40c6d8:	call   407720 <__swc_fn_0a4ed24b_000018_283e2b5e>
  40c6dd:	add    rsp,0x8
  40c6e1:	ret
	...

000000000040c6f0 <__swc_fn_0a4ed24b_000058_1bb23e77>:
  40c6f0:	push   rsi
  40c6f1:	push   rdi
  40c6f2:	push   r12
  40c6f4:	mov    rsi,rdx
  40c6f7:	mov    rax,rdx
  40c6fa:	shr    rax,0xc
  40c6fe:	movabs rdx,0x9e3779b97f4a7c15
  40c708:	imul   rax,rdx
  40c70c:	shr    rax,0x20
  40c710:	lea    rax,[rax*8+0x0]
  40c718:	shr    rax,0x20
  40c71c:	lea    rax,[rax*8+0x0]
  40c724:	lea    rax,[rcx+rax*8+0x40]
  40c729:	xor    edx,edx
  40c72b:	test   dl,dl
  40c72d:	lea    rdi,[rcx+0x8]
  40c731:	cmove  rdi,rax
  40c735:	xor    edx,edx
  40c737:	test   dl,dl
  40c739:	lea    r12,[rcx+0x30]
  40c73d:	lea    rax,[rax+0x8]
  40c741:	cmove  r12,rax
  40c745:	mov    rcx,rdi
  40c748:	call   40e1a0 <__swc_fn_0a4ed24b_000139_86bb0f90>
  40c74d:	mov    rax,QWORD PTR [rsi+0x30]
  40c751:	test   rax,rax
  40c754:	jne    40c760 <__swc_fn_0a4ed24b_000058_1bb23e77+0x70>
  40c756:	mov    rax,QWORD PTR [rsi+0x38]
  40c75a:	mov    QWORD PTR [r12],rax
  40c75e:	jmp    40c768 <__swc_fn_0a4ed24b_000058_1bb23e77+0x78>
  40c760:	mov    rcx,QWORD PTR [rsi+0x38]
  40c764:	mov    QWORD PTR [rax+0x38],rcx
  40c768:	mov    rax,QWORD PTR [rsi+0x38]
  40c76c:	test   rax,rax
  40c76f:	je     40c779 <__swc_fn_0a4ed24b_000058_1bb23e77+0x89>
  40c771:	mov    rcx,QWORD PTR [rsi+0x30]
  40c775:	mov    QWORD PTR [rax+0x30],rcx
  40c779:	vxorps xmm0,xmm0,xmm0
  40c77d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  40c782:	mov    rcx,rdi
  40c785:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40c78a:	pop    r12
  40c78c:	pop    rdi
  40c78d:	pop    rsi
  40c78e:	ret
	...

000000000040c790 <__swc_fn_0a4ed24b_000061_ad030a10>:
  40c790:	mov    rax,QWORD PTR [rcx+0x250]
  40c797:	mov    rcx,rax
  40c79a:	cmp    rax,0x1000000
  40c7a1:	mov    eax,0x1000000
  40c7a6:	cmovb  rcx,rax
  40c7aa:	mov    rax,rcx
  40c7ad:	cmp    rcx,0x10000000
  40c7b4:	mov    ecx,0x10000000
  40c7b9:	cmova  rax,rcx
  40c7bd:	ret
	...

000000000040c7c0 <__swc_fn_0a4ed24b_000064_ffcd96eb>:
  40c7c0:	push   rsi
  40c7c1:	push   rdi
  40c7c2:	push   r12
  40c7c4:	mov    rsi,rcx
  40c7c7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  40c7ce:	xor    r12d,r12d
  40c7d1:	test   rdi,rdi
  40c7d4:	jbe    40c80b <__swc_fn_0a4ed24b_000064_ffcd96eb+0x4b>
  40c7d6:	cs nop WORD PTR [rax+rax*1+0x0]
  40c7e0:	lea    rax,[r12+r12*4]
  40c7e4:	lea    rax,[rsi+rax*8+0x268]
  40c7ec:	mov    rcx,rsi
  40c7ef:	mov    rdx,QWORD PTR [rax]
  40c7f2:	mov    r8,QWORD PTR [rax+0x8]
  40c7f6:	mov    rax,QWORD PTR [rax+0x10]
  40c7fa:	mov    r9,rax
  40c7fd:	call   40c050 <__swc_fn_0a4ed24b_000043_d3c2ab54>
  40c802:	add    r12,0x1
  40c806:	cmp    r12,rdi
  40c809:	jb     40c7e0 <__swc_fn_0a4ed24b_000064_ffcd96eb+0x20>
  40c80b:	vxorps xmm0,xmm0,xmm0
  40c80f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  40c817:	pop    r12
  40c819:	pop    rdi
  40c81a:	pop    rsi
  40c81b:	ret
  40c81c:	add    BYTE PTR [rax],al
	...

000000000040c820 <__swc_fn_0a4ed24b_000067_8c7d044b>:
  40c820:	push   rsi
  40c821:	push   rdi
  40c822:	sub    rsp,0x8
  40c826:	mov    rsi,rcx
  40c829:	call   40fa80 <__swc_fn_0a4ed24b_000056_df0696cd>
  40c82e:	mov    rdi,rax
  40c831:	mov    rcx,rsi
  40c834:	mov    rdx,rax
  40c837:	call   40c6f0 <__swc_fn_0a4ed24b_000058_1bb23e77>
  40c83c:	mov    rcx,QWORD PTR [rdi+0x28]
  40c840:	mov    rdx,QWORD PTR [rsi+0x250]
  40c847:	nop    WORD PTR [rax+rax*1+0x0]
  40c850:	mov    r8,rdx
  40c853:	sub    r8,rcx
  40c856:	mov    rax,rdx
  40c859:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40c862:	cmp    rax,rdx
  40c865:	je     40c86c <__swc_fn_0a4ed24b_000067_8c7d044b+0x4c>
  40c867:	mov    rdx,rax
  40c86a:	jmp    40c850 <__swc_fn_0a4ed24b_000067_8c7d044b+0x30>
  40c86c:	mov    rcx,rsi
  40c86f:	mov    rdx,QWORD PTR [rdi]
  40c872:	mov    r8,QWORD PTR [rdi+0x8]
  40c876:	mov    r9,QWORD PTR [rdi+0x10]
  40c87a:	call   40fba0 <__swc_fn_0a4ed24b_000062_b304235a>
  40c87f:	mov    rcx,rsi
  40c882:	call   40f7e0 <__swc_fn_0a4ed24b_000053_3af34d7f>
  40c887:	add    rsp,0x8
  40c88b:	pop    rdi
  40c88c:	pop    rsi
  40c88d:	ret
	...

000000000040c890 <__swc_fn_0a4ed24b_000070_97813b89>:
  40c890:	push   r12
  40c892:	push   r13
  40c894:	push   r14
  40c896:	push   rdi
  40c897:	push   rsi
  40c898:	sub    rsp,0x1b0
  40c89f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  40c8a8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  40c8b1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  40c8ba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  40c8c3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  40c8cc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  40c8d5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  40c8de:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  40c8e7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  40c8f0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  40c8f9:	mov    r8,rdx
  40c8fc:	mov    r12,rcx
  40c8ff:	mov    r13,QWORD PTR [r8+0x40]
  40c903:	test   r13,r13
  40c906:	jne    40c918 <__swc_fn_0a4ed24b_000070_97813b89+0x88>
  40c908:	add    rsp,0x1b0
  40c90f:	pop    rsi
  40c910:	pop    rdi
  40c911:	pop    r14
  40c913:	pop    r13
  40c915:	pop    r12
  40c917:	ret
  40c918:	mov    QWORD PTR [r8+0x40],0x0
  40c920:	lea    rax,[rip+0x17769]        # 424090 <__swc_bss_base_0a4ed24b+0x50>
  40c927:	mov    rcx,r13
  40c92a:	sub    rcx,QWORD PTR [rax+0x8]
  40c92e:	mov    rax,QWORD PTR [rip+0x1776b]        # 4240a0 <__swc_bss_base_0a4ed24b+0x60>
  40c935:	cmp    rcx,rax
  40c938:	jae    40c964 <__swc_fn_0a4ed24b_000070_97813b89+0xd4>
  40c93a:	mov    rax,r13
  40c93d:	and    rax,0xffffffffffc00000
  40c944:	mov    rcx,r13
  40c947:	shr    rcx,0x10
  40c94b:	and    ecx,0x3f
  40c94e:	mov    edx,DWORD PTR [rax+0x28]
  40c951:	shrx   ecx,ecx,edx
  40c956:	shl    rcx,0x4
  40c95a:	lea    r14,[rax+rcx*8+0x80]
  40c962:	jmp    40c97f <__swc_fn_0a4ed24b_000070_97813b89+0xef>
  40c964:	mov    rcx,r13
  40c967:	mov    QWORD PTR [rsp+0xf8],r8
  40c96f:	call   40f470 <__swc_fn_0a4ed24b_000026_bcdc5519>
  40c974:	mov    r8,QWORD PTR [rsp+0xf8]
  40c97c:	mov    r14,rax
  40c97f:	test   r14,r14
  40c982:	jne    40c994 <__swc_fn_0a4ed24b_000070_97813b89+0x104>
  40c984:	mov    rcx,r12
  40c987:	mov    rdx,r13
  40c98a:	call   40c820 <__swc_fn_0a4ed24b_000067_8c7d044b>
  40c98f:	jmp    40ca22 <__swc_fn_0a4ed24b_000070_97813b89+0x192>
  40c994:	lea    rax,[rip+0x1566d]        # 422008 <__swc_data_base_0a4ed24b+0x8>
  40c99b:	mov    rax,QWORD PTR [rax]
  40c99e:	cmp    rax,0xffffffffffffffff
  40c9a2:	je     40c9b1 <__swc_fn_0a4ed24b_000070_97813b89+0x121>
  40c9a4:	mov    eax,eax
  40c9a6:	mov    edi,eax
  40c9a8:	xor    eax,eax
  40c9aa:	call   407010 <pthread_getspecific@plt>
  40c9af:	jmp    40c9b3 <__swc_fn_0a4ed24b_000070_97813b89+0x123>
  40c9b1:	xor    eax,eax
  40c9b3:	test   rax,rax
  40c9b6:	jne    40c9c5 <__swc_fn_0a4ed24b_000070_97813b89+0x135>
  40c9b8:	call   40f540 <__swc_fn_0a4ed24b_000035_cd1a4e8c>
  40c9bd:	mov    rcx,rax
  40c9c0:	call   409be0 <__swc_fn_0a4ed24b_000132_5f757033>
  40c9c5:	test   rax,rax
  40c9c8:	je     40ca17 <__swc_fn_0a4ed24b_000070_97813b89+0x187>
  40c9ca:	cmp    QWORD PTR [r14+0x40],rax
  40c9ce:	jne    40ca17 <__swc_fn_0a4ed24b_000070_97813b89+0x187>
  40c9d0:	mov    ecx,DWORD PTR [r14+0x6c]
  40c9d4:	test   ecx,ecx
  40c9d6:	je     40c9f6 <__swc_fn_0a4ed24b_000070_97813b89+0x166>
  40c9d8:	mov    rcx,r12
  40c9db:	mov    rdx,rax
  40c9de:	mov    r8,r14
  40c9e1:	mov    QWORD PTR [rsp+0x100],rax
  40c9e9:	call   407c50 <__swc_fn_0a4ed24b_000051_e072b516>
  40c9ee:	mov    rax,QWORD PTR [rsp+0x100]
  40c9f6:	mov    rcx,QWORD PTR [r14]
  40c9f9:	mov    QWORD PTR [r13+0x0],rcx
  40c9fd:	mov    QWORD PTR [r14],r13
  40ca00:	sub    DWORD PTR [r14+0x28],0x1
  40ca05:	jne    40ca22 <__swc_fn_0a4ed24b_000070_97813b89+0x192>
  40ca07:	mov    rcx,r12
  40ca0a:	mov    rdx,rax
  40ca0d:	mov    r8,r14
  40ca10:	call   40c680 <__swc_fn_0a4ed24b_000055_2e3450f7>
  40ca15:	jmp    40ca22 <__swc_fn_0a4ed24b_000070_97813b89+0x192>
  40ca17:	mov    rcx,r14
  40ca1a:	mov    rdx,r13
  40ca1d:	call   40f0b0 <__swc_fn_0a4ed24b_000014_524c1f23>
  40ca22:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40ca2b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  40ca34:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40ca3d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  40ca46:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40ca4f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  40ca58:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  40ca61:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40ca6a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  40ca73:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40ca7c:	add    rsp,0x1b0
  40ca83:	pop    rsi
  40ca84:	pop    rdi
  40ca85:	pop    r14
  40ca87:	pop    r13
  40ca89:	pop    r12
  40ca8b:	ret
  40ca8c:	add    BYTE PTR [rax],al
	...

000000000040ca90 <__swc_fn_0a4ed24b_000073_9c99bf04>:
  40ca90:	push   rsi
  40ca91:	mov    rsi,rcx
  40ca94:	call   40c040 <__swc_fn_0a4ed24b_000040_eb6108f2>
  40ca99:	test   al,al
  40ca9b:	jne    40ca9f <__swc_fn_0a4ed24b_000073_9c99bf04+0xf>
  40ca9d:	pop    rsi
  40ca9e:	ret
  40ca9f:	lea    rax,[rip+0x1779a]        # 424240 <__swc_bss_base_0a4ed24b+0x200>
  40caa6:	cmp    rsi,rax
  40caa9:	jne    40caad <__swc_fn_0a4ed24b_000073_9c99bf04+0x1d>
  40caab:	pop    rsi
  40caac:	ret
  40caad:	mov    rcx,rsi
  40cab0:	call   40e1a0 <__swc_fn_0a4ed24b_000139_86bb0f90>
  40cab5:	mov    rcx,rsi
  40cab8:	call   408420 <__swc_fn_0a4ed24b_000072_61e60aab>
  40cabd:	mov    rcx,rsi
  40cac0:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40cac5:	pop    rsi
  40cac6:	ret
	...

000000000040cad0 <__swc_fn_0a4ed24b_000076_15bd096c>:
  40cad0:	sub    rsp,0x8
  40cad4:	call   408170 <__swc_fn_0a4ed24b_000069_7130736e>
  40cad9:	add    rsp,0x8
  40cadd:	ret
	...

000000000040cae0 <__swc_fn_0a4ed24b_000079_a5fd3362>:
  40cae0:	push   rsi
  40cae1:	mov    rsi,rdx
  40cae4:	call   408420 <__swc_fn_0a4ed24b_000072_61e60aab>
  40cae9:	mov    QWORD PTR [rsi+0x40],0x0
  40caf1:	pop    rsi
  40caf2:	ret
	...

000000000040cb00 <__swc_fn_0a4ed24b_000082_63a67586>:
  40cb00:	mov    r8,rcx
  40cb03:	mov    rcx,QWORD PTR [rcx]
  40cb06:	cs nop WORD PTR [rax+rax*1+0x0]
  40cb10:	mov    r9,rcx
  40cb13:	sub    r9,rdx
  40cb16:	mov    rax,rcx
  40cb19:	lock cmpxchg QWORD PTR [r8],r9
  40cb1e:	cmp    rax,rcx
  40cb21:	je     40cb28 <__swc_fn_0a4ed24b_000082_63a67586+0x28>
  40cb23:	mov    rcx,rax
  40cb26:	jmp    40cb10 <__swc_fn_0a4ed24b_000082_63a67586+0x10>
  40cb28:	mov    rax,rcx
  40cb2b:	ret
  40cb2c:	add    BYTE PTR [rax],al
	...

000000000040cb30 <__swc_fn_0a4ed24b_000085_c618ff58>:
  40cb30:	vxorps xmm0,xmm0,xmm0
  40cb34:	vmovups XMMWORD PTR [rcx],xmm0
  40cb38:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40cb3d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40cb42:	ret
	...

000000000040cb50 <__swc_fn_0a4ed24b_000088_0d280354>:
  40cb50:	push   rsi
  40cb51:	push   rdi
  40cb52:	push   r12
  40cb54:	push   r13
  40cb56:	push   r15
  40cb58:	push   r14
  40cb5a:	push   rbx
  40cb5b:	sub    rsp,0x60
  40cb5f:	mov    QWORD PTR [rsp+0x28],r11
  40cb64:	mov    rsi,rcx
  40cb67:	mov    rdi,rdx
  40cb6a:	mov    QWORD PTR [rsp+0x30],rdx
  40cb6f:	mov    r12,r8
  40cb72:	mov    r13,r9
  40cb75:	mov    QWORD PTR [rsp+0x38],r10
  40cb7a:	xor    r8d,r8d
  40cb7d:	call   40cea0 <__swc_fn_0a4ed24b_000094_63c1827b>
  40cb82:	test   al,al
  40cb84:	je     40cb99 <__swc_fn_0a4ed24b_000088_0d280354+0x49>
  40cb86:	mov    rax,r12
  40cb89:	add    rsp,0x60
  40cb8d:	pop    rbx
  40cb8e:	pop    r14
  40cb90:	pop    r15
  40cb92:	pop    r13
  40cb94:	pop    r12
  40cb96:	pop    rdi
  40cb97:	pop    rsi
  40cb98:	ret
  40cb99:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40cb9e:	je     40cbb2 <__swc_fn_0a4ed24b_000088_0d280354+0x62>
  40cba0:	xor    eax,eax
  40cba2:	add    rsp,0x60
  40cba6:	pop    rbx
  40cba7:	pop    r14
  40cba9:	pop    r15
  40cbab:	pop    r13
  40cbad:	pop    r12
  40cbaf:	pop    rdi
  40cbb0:	pop    rsi
  40cbb1:	ret
  40cbb2:	mov    r15,rdi
  40cbb5:	mov    QWORD PTR [rsp+0x40],rdi
  40cbba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40cbbf:	jne    40cc2f <__swc_fn_0a4ed24b_000088_0d280354+0xdf>
  40cbc1:	mov    r14,QWORD PTR [r15+0xb8]
  40cbc8:	mov    rax,QWORD PTR [r15+0xc0]
  40cbcf:	mov    r15,rax
  40cbd2:	xor    edi,edi
  40cbd4:	test   r15,r15
  40cbd7:	je     40cc2f <__swc_fn_0a4ed24b_000088_0d280354+0xdf>
  40cbd9:	nop    DWORD PTR [rax+0x0]
  40cbe0:	lea    rbx,[rdi*8+0x0]
  40cbe8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  40cbed:	mov    rcx,rax
  40cbf0:	mov    rdx,rsi
  40cbf3:	xor    r8d,r8d
  40cbf6:	call   40cea0 <__swc_fn_0a4ed24b_000094_63c1827b>
  40cbfb:	test   al,al
  40cbfd:	je     40cc25 <__swc_fn_0a4ed24b_000088_0d280354+0xd5>
  40cbff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  40cc04:	test   rax,rax
  40cc07:	je     40cc25 <__swc_fn_0a4ed24b_000088_0d280354+0xd5>
  40cc09:	test   r13,r13
  40cc0c:	je     40cc12 <__swc_fn_0a4ed24b_000088_0d280354+0xc2>
  40cc0e:	mov    QWORD PTR [r13+0x8],rax
  40cc12:	mov    rax,r12
  40cc15:	add    rsp,0x60
  40cc19:	pop    rbx
  40cc1a:	pop    r14
  40cc1c:	pop    r15
  40cc1e:	pop    r13
  40cc20:	pop    r12
  40cc22:	pop    rdi
  40cc23:	pop    rsi
  40cc24:	ret
  40cc25:	add    rdi,0x1
  40cc29:	sub    r15,0x1
  40cc2d:	jne    40cbe0 <__swc_fn_0a4ed24b_000088_0d280354+0x90>
  40cc2f:	test   r12,r12
  40cc32:	jne    40cc46 <__swc_fn_0a4ed24b_000088_0d280354+0xf6>
  40cc34:	xor    eax,eax
  40cc36:	add    rsp,0x60
  40cc3a:	pop    rbx
  40cc3b:	pop    r14
  40cc3d:	pop    r15
  40cc3f:	pop    r13
  40cc41:	pop    r12
  40cc43:	pop    rdi
  40cc44:	pop    rsi
  40cc45:	ret
  40cc46:	mov    rbx,QWORD PTR [rsp+0x28]
  40cc4b:	mov    rdi,QWORD PTR [rsp+0x30]
  40cc50:	mov    rax,rbx
  40cc53:	test   rax,rax
  40cc56:	je     40cc86 <__swc_fn_0a4ed24b_000088_0d280354+0x136>
  40cc58:	nop    DWORD PTR [rax+rax*1+0x0]
  40cc60:	cmp    QWORD PTR [rax+0x8],r12
  40cc64:	jne    40cc7d <__swc_fn_0a4ed24b_000088_0d280354+0x12d>
  40cc66:	cmp    QWORD PTR [rax],rdi
  40cc69:	jne    40cc7d <__swc_fn_0a4ed24b_000088_0d280354+0x12d>
  40cc6b:	xor    eax,eax
  40cc6d:	add    rsp,0x60
  40cc71:	pop    rbx
  40cc72:	pop    r14
  40cc74:	pop    r15
  40cc76:	pop    r13
  40cc78:	pop    r12
  40cc7a:	pop    rdi
  40cc7b:	pop    rsi
  40cc7c:	ret
  40cc7d:	mov    rax,QWORD PTR [rax+0x10]
  40cc81:	test   rax,rax
  40cc84:	jne    40cc60 <__swc_fn_0a4ed24b_000088_0d280354+0x110>
  40cc86:	lea    r14,[rsp+0x8]
  40cc8b:	mov    QWORD PTR [rsp+0x48],r14
  40cc90:	mov    QWORD PTR [rsp+0x8],rdi
  40cc95:	mov    QWORD PTR [rsp+0x10],r12
  40cc9a:	mov    QWORD PTR [rsp+0x18],rbx
  40cc9f:	mov    r15,QWORD PTR [rsp+0x40]
  40cca4:	mov    rbx,QWORD PTR [r15+0x98]
  40ccab:	mov    rax,QWORD PTR [r15+0xa0]
  40ccb2:	mov    rdi,rax
  40ccb5:	mov    r15,QWORD PTR [rsp+0x38]
  40ccba:	xor    r14d,r14d
  40ccbd:	test   rdi,rdi
  40ccc0:	je     40cd6a <__swc_fn_0a4ed24b_000088_0d280354+0x21a>
  40ccc6:	cs nop WORD PTR [rax+rax*1+0x0]
  40ccd0:	mov    QWORD PTR [rsp+0x50],rdi
  40ccd5:	lea    rdi,[r14*8+0x0]
  40ccdd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  40cce2:	mov    rcx,rax
  40cce5:	call   410b80 <__swc_fn_0a4ed24b_000086_3953ef98>
  40ccea:	test   DWORD PTR [rax+0x28],0x10000
  40ccf1:	je     40ccf8 <__swc_fn_0a4ed24b_000088_0d280354+0x1a8>
  40ccf3:	test   r15b,r15b
  40ccf6:	je     40cd51 <__swc_fn_0a4ed24b_000088_0d280354+0x201>
  40ccf8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  40ccfc:	lea    rdi,[r12+rcx*1]
  40cd00:	cmp    BYTE PTR [rax+0x2c],0x6
  40cd04:	jne    40cd18 <__swc_fn_0a4ed24b_000088_0d280354+0x1c8>
  40cd06:	mov    rax,QWORD PTR [rax+0x40]
  40cd0a:	mov    rcx,rax
  40cd0d:	call   410b80 <__swc_fn_0a4ed24b_000086_3953ef98>
  40cd12:	mov    rcx,QWORD PTR [rdi]
  40cd15:	mov    rdi,rcx
  40cd18:	test   rdi,rdi
  40cd1b:	je     40cd51 <__swc_fn_0a4ed24b_000088_0d280354+0x201>
  40cd1d:	mov    rcx,rsi
  40cd20:	mov    rdx,rax
  40cd23:	mov    r8,rdi
  40cd26:	mov    r9,r13
  40cd29:	mov    al,r15b
  40cd2c:	mov    r10,rax
  40cd2f:	mov    rdi,QWORD PTR [rsp+0x48]
  40cd34:	mov    r11,rdi
  40cd37:	call   40cb50 <__swc_fn_0a4ed24b_000088_0d280354>
  40cd3c:	test   rax,rax
  40cd3f:	je     40cd51 <__swc_fn_0a4ed24b_000088_0d280354+0x201>
  40cd41:	add    rsp,0x60
  40cd45:	pop    rbx
  40cd46:	pop    r14
  40cd48:	pop    r15
  40cd4a:	pop    r13
  40cd4c:	pop    r12
  40cd4e:	pop    rdi
  40cd4f:	pop    rsi
  40cd50:	ret
  40cd51:	add    r14,0x1
  40cd55:	mov    rax,QWORD PTR [rsp+0x50]
  40cd5a:	sub    rax,0x1
  40cd5e:	mov    rdi,rax
  40cd61:	test   rax,rax
  40cd64:	jne    40ccd0 <__swc_fn_0a4ed24b_000088_0d280354+0x180>
  40cd6a:	xor    eax,eax
  40cd6c:	add    rsp,0x60
  40cd70:	pop    rbx
  40cd71:	pop    r14
  40cd73:	pop    r15
  40cd75:	pop    r13
  40cd77:	pop    r12
  40cd79:	pop    rdi
  40cd7a:	pop    rsi
  40cd7b:	ret
  40cd7c:	add    BYTE PTR [rax],al
	...

000000000040cd80 <__swc_fn_0a4ed24b_000091_c1c9085b>:
  40cd80:	push   rsi
  40cd81:	push   rdi
  40cd82:	push   r12
  40cd84:	push   r13
  40cd86:	push   r14
  40cd88:	push   r15
  40cd8a:	sub    rsp,0x78
  40cd8e:	mov    rsi,r10
  40cd91:	mov    QWORD PTR [rsp+0x68],r10
  40cd96:	mov    rdi,rcx
  40cd99:	mov    r12,rdx
  40cd9c:	mov    r13,r8
  40cd9f:	mov    r14,r9
  40cda2:	xor    r8d,r8d
  40cda5:	call   40cea0 <__swc_fn_0a4ed24b_000094_63c1827b>
  40cdaa:	test   al,al
  40cdac:	je     40cdd5 <__swc_fn_0a4ed24b_000091_c1c9085b+0x55>
  40cdae:	mov    rcx,r14
  40cdb1:	mov    rdx,r12
  40cdb4:	mov    r8,r13
  40cdb7:	mov    r9,rsi
  40cdba:	call   408880 <__swc_fn_0a4ed24b_000090_23214800>
  40cdbf:	test   al,al
  40cdc1:	je     40cdd5 <__swc_fn_0a4ed24b_000091_c1c9085b+0x55>
  40cdc3:	mov    rax,r13
  40cdc6:	add    rsp,0x78
  40cdca:	pop    r15
  40cdcc:	pop    r14
  40cdce:	pop    r13
  40cdd0:	pop    r12
  40cdd2:	pop    rdi
  40cdd3:	pop    rsi
  40cdd4:	ret
  40cdd5:	cmp    BYTE PTR [r12+0x2c],0xe
  40cddb:	je     40cdee <__swc_fn_0a4ed24b_000091_c1c9085b+0x6e>
  40cddd:	xor    eax,eax
  40cddf:	add    rsp,0x78
  40cde3:	pop    r15
  40cde5:	pop    r14
  40cde7:	pop    r13
  40cde9:	pop    r12
  40cdeb:	pop    rdi
  40cdec:	pop    rsi
  40cded:	ret
  40cdee:	mov    r15,QWORD PTR [r12+0x98]
  40cdf6:	mov    rax,QWORD PTR [r12+0xa0]
  40cdfe:	mov    r12,rax
  40ce01:	xor    esi,esi
  40ce03:	test   r12,r12
  40ce06:	je     40ce79 <__swc_fn_0a4ed24b_000091_c1c9085b+0xf9>
  40ce08:	nop    DWORD PTR [rax+rax*1+0x0]
  40ce10:	mov    QWORD PTR [rsp+0x70],r12
  40ce15:	lea    r12,[rsi*8+0x0]
  40ce1d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  40ce22:	mov    rcx,rax
  40ce25:	call   410b80 <__swc_fn_0a4ed24b_000086_3953ef98>
  40ce2a:	cmp    BYTE PTR [rax+0x2c],0xe
  40ce2e:	jne    40ce64 <__swc_fn_0a4ed24b_000091_c1c9085b+0xe4>
  40ce30:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  40ce35:	lea    r8,[r13+rcx*1+0x0]
  40ce3a:	mov    rcx,rdi
  40ce3d:	mov    rdx,rax
  40ce40:	mov    r9,r14
  40ce43:	mov    r12,QWORD PTR [rsp+0x68]
  40ce48:	mov    r10,r12
  40ce4b:	call   40cd80 <__swc_fn_0a4ed24b_000091_c1c9085b>
  40ce50:	test   rax,rax
  40ce53:	je     40ce64 <__swc_fn_0a4ed24b_000091_c1c9085b+0xe4>
  40ce55:	add    rsp,0x78
  40ce59:	pop    r15
  40ce5b:	pop    r14
  40ce5d:	pop    r13
  40ce5f:	pop    r12
  40ce61:	pop    rdi
  40ce62:	pop    rsi
  40ce63:	ret
  40ce64:	add    rsi,0x1
  40ce68:	mov    rax,QWORD PTR [rsp+0x70]
  40ce6d:	sub    rax,0x1
  40ce71:	mov    r12,rax
  40ce74:	test   rax,rax
  40ce77:	jne    40ce10 <__swc_fn_0a4ed24b_000091_c1c9085b+0x90>
  40ce79:	xor    eax,eax
  40ce7b:	add    rsp,0x78
  40ce7f:	pop    r15
  40ce81:	pop    r14
  40ce83:	pop    r13
  40ce85:	pop    r12
  40ce87:	pop    rdi
  40ce88:	pop    rsi
  40ce89:	ret
	...

000000000040cea0 <__swc_fn_0a4ed24b_000094_63c1827b>:
  40cea0:	push   rbx
  40cea1:	push   rsi
  40cea2:	push   rdi
  40cea3:	push   r12
  40cea5:	push   r13
  40cea7:	push   r14
  40cea9:	push   r15
  40ceab:	sub    rsp,0x120
  40ceb2:	mov    rbx,r8
  40ceb5:	mov    rsi,rdx
  40ceb8:	test   rcx,rcx
  40cebb:	jne    40ceda <__swc_fn_0a4ed24b_000094_63c1827b+0x3a>
  40cebd:	test   rsi,rsi
  40cec0:	jne    40ceda <__swc_fn_0a4ed24b_000094_63c1827b+0x3a>
  40cec2:	mov    eax,0x1
  40cec7:	add    rsp,0x120
  40cece:	pop    r15
  40ced0:	pop    r14
  40ced2:	pop    r13
  40ced4:	pop    r12
  40ced6:	pop    rdi
  40ced7:	pop    rsi
  40ced8:	pop    rbx
  40ced9:	ret
  40ceda:	test   rcx,rcx
  40cedd:	je     40cee4 <__swc_fn_0a4ed24b_000094_63c1827b+0x44>
  40cedf:	test   rsi,rsi
  40cee2:	jne    40cef9 <__swc_fn_0a4ed24b_000094_63c1827b+0x59>
  40cee4:	xor    eax,eax
  40cee6:	add    rsp,0x120
  40ceed:	pop    r15
  40ceef:	pop    r14
  40cef1:	pop    r13
  40cef3:	pop    r12
  40cef5:	pop    rdi
  40cef6:	pop    rsi
  40cef7:	pop    rbx
  40cef8:	ret
  40cef9:	call   410b80 <__swc_fn_0a4ed24b_000086_3953ef98>
  40cefe:	mov    rdi,rax
  40cf01:	mov    rcx,rsi
  40cf04:	call   410b80 <__swc_fn_0a4ed24b_000086_3953ef98>
  40cf09:	test   bl,0x1
  40cf0c:	je     40cf4a <__swc_fn_0a4ed24b_000094_63c1827b+0xaa>
  40cf0e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  40cf13:	jne    40cf4a <__swc_fn_0a4ed24b_000094_63c1827b+0xaa>
  40cf15:	mov    ecx,DWORD PTR [rdi+0x28]
  40cf18:	test   ecx,0x1000
  40cf1e:	je     40cf4a <__swc_fn_0a4ed24b_000094_63c1827b+0xaa>
  40cf20:	test   ecx,0x10000
  40cf26:	je     40cf4a <__swc_fn_0a4ed24b_000094_63c1827b+0xaa>
  40cf28:	mov    rcx,QWORD PTR [rdi+0x40]
  40cf2c:	mov    rdx,rax
  40cf2f:	mov    r8d,ebx
  40cf32:	call   40cea0 <__swc_fn_0a4ed24b_000094_63c1827b>
  40cf37:	add    rsp,0x120
  40cf3e:	pop    r15
  40cf40:	pop    r14
  40cf42:	pop    r13
  40cf44:	pop    r12
  40cf46:	pop    rdi
  40cf47:	pop    rsi
  40cf48:	pop    rbx
  40cf49:	ret
  40cf4a:	mov    cl,BYTE PTR [rax+0x2c]
  40cf4d:	rex cmp BYTE PTR [rdi+0x2c],cl
  40cf51:	jne    40cf5b <__swc_fn_0a4ed24b_000094_63c1827b+0xbb>
  40cf53:	mov    ecx,DWORD PTR [rax+0x20]
  40cf56:	cmp    DWORD PTR [rdi+0x20],ecx
  40cf59:	je     40cf70 <__swc_fn_0a4ed24b_000094_63c1827b+0xd0>
  40cf5b:	xor    eax,eax
  40cf5d:	add    rsp,0x120
  40cf64:	pop    r15
  40cf66:	pop    r14
  40cf68:	pop    r13
  40cf6a:	pop    r12
  40cf6c:	pop    rdi
  40cf6d:	pop    rsi
  40cf6e:	pop    rbx
  40cf6f:	ret
  40cf70:	mov    ecx,DWORD PTR [rdi+0x28]
  40cf73:	and    ecx,0xffb5ffff
  40cf79:	mov    edx,DWORD PTR [rax+0x28]
  40cf7c:	and    edx,0xffb5ffff
  40cf82:	cmp    ecx,edx
  40cf84:	je     40cf9b <__swc_fn_0a4ed24b_000094_63c1827b+0xfb>
  40cf86:	xor    eax,eax
  40cf88:	add    rsp,0x120
  40cf8f:	pop    r15
  40cf91:	pop    r14
  40cf93:	pop    r13
  40cf95:	pop    r12
  40cf97:	pop    rdi
  40cf98:	pop    rsi
  40cf99:	pop    rbx
  40cf9a:	ret
  40cf9b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  40cfa0:	jne    40cff5 <__swc_fn_0a4ed24b_000094_63c1827b+0x155>
  40cfa2:	mov    cl,BYTE PTR [rax+0x40]
  40cfa5:	rex cmp BYTE PTR [rdi+0x40],cl
  40cfa9:	je     40cfc0 <__swc_fn_0a4ed24b_000094_63c1827b+0x120>
  40cfab:	xor    eax,eax
  40cfad:	add    rsp,0x120
  40cfb4:	pop    r15
  40cfb6:	pop    r14
  40cfb8:	pop    r13
  40cfba:	pop    r12
  40cfbc:	pop    rdi
  40cfbd:	pop    rsi
  40cfbe:	pop    rbx
  40cfbf:	ret
  40cfc0:	rex cmp BYTE PTR [rdi+0x40],0xd
  40cfc5:	je     40cfdd <__swc_fn_0a4ed24b_000094_63c1827b+0x13d>
  40cfc7:	rex cmp BYTE PTR [rdi+0x40],0xf
  40cfcc:	sete   cl
  40cfcf:	je     40cfd9 <__swc_fn_0a4ed24b_000094_63c1827b+0x139>
  40cfd1:	rex cmp BYTE PTR [rdi+0x40],0xe
  40cfd6:	sete   cl
  40cfd9:	test   cl,cl
  40cfdb:	je     40cff5 <__swc_fn_0a4ed24b_000094_63c1827b+0x155>
  40cfdd:	mov    eax,0x1
  40cfe2:	add    rsp,0x120
  40cfe9:	pop    r15
  40cfeb:	pop    r14
  40cfed:	pop    r13
  40cfef:	pop    r12
  40cff1:	pop    rdi
  40cff2:	pop    rsi
  40cff3:	pop    rbx
  40cff4:	ret
  40cff5:	test   DWORD PTR [rdi+0x28],0x200200
  40cffc:	je     40d1af <__swc_fn_0a4ed24b_000094_63c1827b+0x30f>
  40d002:	mov    rsi,QWORD PTR [rdi+0x88]
  40d009:	mov    rdi,QWORD PTR [rdi+0x90]
  40d010:	mov    r12,QWORD PTR [rax+0x88]
  40d017:	mov    rax,QWORD PTR [rax+0x90]
  40d01e:	cmp    rdi,rax
  40d021:	je     40d038 <__swc_fn_0a4ed24b_000094_63c1827b+0x198>
  40d023:	xor    eax,eax
  40d025:	add    rsp,0x120
  40d02c:	pop    r15
  40d02e:	pop    r14
  40d030:	pop    r13
  40d032:	pop    r12
  40d034:	pop    rdi
  40d035:	pop    rsi
  40d036:	pop    rbx
  40d037:	ret
  40d038:	test   rsi,rsi
  40d03b:	je     40d042 <__swc_fn_0a4ed24b_000094_63c1827b+0x1a2>
  40d03d:	test   r12,r12
  40d040:	jne    40d05a <__swc_fn_0a4ed24b_000094_63c1827b+0x1ba>
  40d042:	mov    eax,0x1
  40d047:	add    rsp,0x120
  40d04e:	pop    r15
  40d050:	pop    r14
  40d052:	pop    r13
  40d054:	pop    r12
  40d056:	pop    rdi
  40d057:	pop    rsi
  40d058:	pop    rbx
  40d059:	ret
  40d05a:	xor    r13d,r13d
  40d05d:	test   rdi,rdi
  40d060:	jbe    40d197 <__swc_fn_0a4ed24b_000094_63c1827b+0x2f7>
  40d066:	lea    r14,[rsp+0x78]
  40d06b:	lea    r15,[rsp+0xb8]
  40d073:	cs nop WORD PTR [rax+rax*1+0x0]
  40d07d:	cs nop WORD PTR [rax+rax*1+0x0]
  40d087:	nop    WORD PTR [rax+rax*1+0x0]
  40d090:	lea    rax,[r13*8+0x0]
  40d098:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40d09d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40d0a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  40d0a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40d0b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  40d0b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40d0c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  40d0c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40d0d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  40d0d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40d0df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  40d0e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  40d0ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  40d0f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  40d0ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  40d106:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40d10f:	xor    al,al
  40d111:	rex test BYTE PTR [rsp+0xb0],0x1
  40d11a:	je     40d121 <__swc_fn_0a4ed24b_000094_63c1827b+0x281>
  40d11c:	mov    eax,0x1
  40d121:	rex test BYTE PTR [rsp+0xf0],0x1
  40d12a:	je     40d131 <__swc_fn_0a4ed24b_000094_63c1827b+0x291>
  40d12c:	mov    eax,0x1
  40d131:	test   al,al
  40d133:	jne    40d159 <__swc_fn_0a4ed24b_000094_63c1827b+0x2b9>
  40d135:	mov    rcx,r14
  40d138:	mov    rdx,r15
  40d13b:	call   40e6b0 <__swc_fn_0a4ed24b_000151_6fb05988>
  40d140:	test   al,al
  40d142:	jne    40d159 <__swc_fn_0a4ed24b_000094_63c1827b+0x2b9>
  40d144:	xor    eax,eax
  40d146:	add    rsp,0x120
  40d14d:	pop    r15
  40d14f:	pop    r14
  40d151:	pop    r13
  40d153:	pop    r12
  40d155:	pop    rdi
  40d156:	pop    rsi
  40d157:	pop    rbx
  40d158:	ret
  40d159:	mov    rcx,QWORD PTR [rsp+0x88]
  40d161:	mov    rdx,QWORD PTR [rsp+0xc8]
  40d169:	mov    r8d,ebx
  40d16c:	call   40cea0 <__swc_fn_0a4ed24b_000094_63c1827b>
  40d171:	test   al,al
  40d173:	jne    40d18a <__swc_fn_0a4ed24b_000094_63c1827b+0x2ea>
  40d175:	xor    eax,eax
  40d177:	add    rsp,0x120
  40d17e:	pop    r15
  40d180:	pop    r14
  40d182:	pop    r13
  40d184:	pop    r12
  40d186:	pop    rdi
  40d187:	pop    rsi
  40d188:	pop    rbx
  40d189:	ret
  40d18a:	add    r13,0x1
  40d18e:	cmp    r13,rdi
  40d191:	jb     40d090 <__swc_fn_0a4ed24b_000094_63c1827b+0x1f0>
  40d197:	mov    eax,0x1
  40d19c:	add    rsp,0x120
  40d1a3:	pop    r15
  40d1a5:	pop    r14
  40d1a7:	pop    r13
  40d1a9:	pop    r12
  40d1ab:	pop    rdi
  40d1ac:	pop    rsi
  40d1ad:	pop    rbx
  40d1ae:	ret
  40d1af:	test   bl,0x2
  40d1b2:	je     40d1d4 <__swc_fn_0a4ed24b_000094_63c1827b+0x334>
  40d1b4:	lea    rcx,[rdi+0x10]
  40d1b8:	lea    rdx,[rax+0x10]
  40d1bc:	call   40e6b0 <__swc_fn_0a4ed24b_000151_6fb05988>
  40d1c1:	add    rsp,0x120
  40d1c8:	pop    r15
  40d1ca:	pop    r14
  40d1cc:	pop    r13
  40d1ce:	pop    r12
  40d1d0:	pop    rdi
  40d1d1:	pop    rsi
  40d1d2:	pop    rbx
  40d1d3:	ret
  40d1d4:	mov    rcx,rdi
  40d1d7:	mov    rdx,rax
  40d1da:	call   40e6b0 <__swc_fn_0a4ed24b_000151_6fb05988>
  40d1df:	add    rsp,0x120
  40d1e6:	pop    r15
  40d1e8:	pop    r14
  40d1ea:	pop    r13
  40d1ec:	pop    r12
  40d1ee:	pop    rdi
  40d1ef:	pop    rsi
  40d1f0:	pop    rbx
  40d1f1:	ret
	...

000000000040d200 <__swc_fn_0a4ed24b_000097_4185993f>:
  40d200:	push   rbx
  40d201:	mov    rbx,rcx
  40d204:	call   410cb0 <__swc_fn_0a4ed24b_000095_ad13d15c>
  40d209:	movzx  r11d,al
  40d20d:	mov    r8b,r11b
  40d210:	test   r8b,r8b
  40d213:	jne    40d22d <__swc_fn_0a4ed24b_000097_4185993f+0x2d>
  40d215:	mov    r11d,0x1
  40d21b:	mov    r10,rbx
  40d21e:	mov    r9,r11
  40d221:	and    r10,r11
  40d224:	test   r10,r10
  40d227:	setne  dl
  40d22a:	mov    r8b,dl
  40d22d:	mov    r10b,r8b
  40d230:	test   r10b,r10b
  40d233:	je     40d237 <__swc_fn_0a4ed24b_000097_4185993f+0x37>
  40d235:	pop    rbx
  40d236:	ret
  40d237:	call   409d80 <__swc_fn_0a4ed24b_000141_519fdf94>
  40d23c:	movzx  r10d,al
  40d240:	test   r10b,r10b
  40d243:	je     40d247 <__swc_fn_0a4ed24b_000097_4185993f+0x47>
  40d245:	pop    rbx
  40d246:	ret
  40d247:	lea    r10,[rip+0x627a]        # 4134c8 <__swc_rdata_base_0a4ed24b+0x3b8>
  40d24e:	mov    rax,r10
  40d251:	mov    rcx,rax
  40d254:	call   4098b0 <__swc_fn_0a4ed24b_000120_2648f149>
  40d259:	call   411530 <__swc_fn_0a4ed24b_000122_be2e2f68>
  40d25e:	pop    rbx
  40d25f:	ret

000000000040d260 <__swc_fn_0a4ed24b_000100_d4bdcaa4>:
  40d260:	push   rbx
  40d261:	sub    rsp,0x70
  40d265:	vxorps xmm0,xmm0,xmm0
  40d269:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40d26f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40d275:	vzeroupper
  40d278:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40d27e:	mov    QWORD PTR [rsp+0x48],rdx
  40d283:	mov    rax,r8
  40d286:	cmp    r8,0x1
  40d28a:	mov    edx,0x1
  40d28f:	cmovb  rax,rdx
  40d293:	mov    QWORD PTR [rsp+0x50],rax
  40d298:	mov    rbx,QWORD PTR [rcx+0x8]
  40d29c:	mov    rbx,QWORD PTR [rbx+0x18]
  40d2a0:	mov    rcx,QWORD PTR [rcx]
  40d2a3:	lea    rdx,[rsp+0x8]
  40d2a8:	call   rbx
  40d2aa:	add    rsp,0x70
  40d2ae:	pop    rbx
  40d2af:	ret

000000000040d2b0 <__swc_fn_0a4ed24b_000103_2fdd2c61>:
  40d2b0:	push   rbx
  40d2b1:	push   rsi
  40d2b2:	push   rdi
  40d2b3:	sub    rsp,0x30
  40d2b7:	mov    rbx,rcx
  40d2ba:	test   rcx,rcx
  40d2bd:	je     40d2d2 <__swc_fn_0a4ed24b_000103_2fdd2c61+0x22>
  40d2bf:	mov    rcx,rbx
  40d2c2:	mov    edx,0x1
  40d2c7:	call   40cb00 <__swc_fn_0a4ed24b_000082_63a67586>
  40d2cc:	cmp    rax,0x1
  40d2d0:	je     40d2da <__swc_fn_0a4ed24b_000103_2fdd2c61+0x2a>
  40d2d2:	add    rsp,0x30
  40d2d6:	pop    rdi
  40d2d7:	pop    rsi
  40d2d8:	pop    rbx
  40d2d9:	ret
  40d2da:	lea    rsi,[rsp+0x8]
  40d2df:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40d2e4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40d2ea:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  40d2ef:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40d2f5:	mov    rax,QWORD PTR [rsp+0x20]
  40d2fa:	test   rax,rax
  40d2fd:	je     40d313 <__swc_fn_0a4ed24b_000103_2fdd2c61+0x63>
  40d2ff:	test   DWORD PTR [rax+0x28],0x400000
  40d306:	je     40d313 <__swc_fn_0a4ed24b_000103_2fdd2c61+0x63>
  40d308:	mov    rcx,QWORD PTR [rax+0x30]
  40d30c:	test   rcx,rcx
  40d30f:	cmovne rax,rcx
  40d313:	mov    edi,DWORD PTR [rax+0x20]
  40d316:	lea    rcx,[rsp+0x18]
  40d31b:	call   410e90 <__swc_fn_0a4ed24b_000104_3c3b96fb>
  40d320:	mov    rcx,rsi
  40d323:	mov    rdx,QWORD PTR [rsp+0x18]
  40d328:	mov    r8,rdi
  40d32b:	call   40d260 <__swc_fn_0a4ed24b_000100_d4bdcaa4>
  40d330:	mov    rcx,QWORD PTR [rbx+0x28]
  40d334:	call   408e60 <__swc_fn_0a4ed24b_000102_e34f54dc>
  40d339:	mov    rcx,rsi
  40d33c:	mov    rdx,rbx
  40d33f:	mov    r8d,0x30
  40d345:	call   40d260 <__swc_fn_0a4ed24b_000100_d4bdcaa4>
  40d34a:	add    rsp,0x30
  40d34e:	pop    rdi
  40d34f:	pop    rsi
  40d350:	pop    rbx
  40d351:	ret
	...

000000000040d360 <__swc_fn_0a4ed24b_000106_ffe51047>:
  40d360:	push   rbp
  40d361:	push   rbx
  40d362:	push   rsi
  40d363:	push   rdi
  40d364:	push   r12
  40d366:	push   r13
  40d368:	push   r14
  40d36a:	push   r15
  40d36c:	sub    rsp,0x500
  40d373:	mov    rbp,rsp
  40d376:	mov    rbx,rsp
  40d379:	mov    rsi,rdx
  40d37c:	mov    rdi,rcx
  40d37f:	mov    rcx,QWORD PTR [rip+0x199ba]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40d386:	test   rcx,rcx
  40d389:	jne    40d3a3 <__swc_fn_0a4ed24b_000106_ffe51047+0x43>
  40d38b:	sub    rsp,0x8
  40d38f:	call   40eaa0 <__swc_fn_0a4ed24b_000169_994c8876>
  40d394:	add    rsp,0x8
  40d398:	lea    rcx,[rax+0x1]
  40d39c:	mov    QWORD PTR [rip+0x1999d],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40d3a3:	dec    rcx
  40d3a6:	sub    rsp,0x8
  40d3aa:	call   40b660 <__swc_fn_0a4ed24b_000171_360af05d>
  40d3af:	add    rsp,0x8
  40d3b3:	mov    r12,rax
  40d3b6:	mov    QWORD PTR [rsp+0x4f0],rax
  40d3be:	lea    rax,[rip+0x6243]        # 413608 <__swc_rdata_base_0a4ed24b+0x4f8>
  40d3c5:	sub    rsp,0x20
  40d3c9:	mov    rcx,rsp
  40d3cc:	mov    QWORD PTR [rcx],rax
  40d3cf:	lea    r13,[rip+0x5f1a]        # 4132f0 <__swc_rdata_base_0a4ed24b+0x1e0>
  40d3d6:	mov    QWORD PTR [rcx+0x8],r13
  40d3da:	mov    QWORD PTR [rcx+0x10],rsp
  40d3de:	mov    QWORD PTR [rcx+0x18],0x1
  40d3e6:	lea    rcx,[rsp+0x10]
  40d3eb:	sub    rsp,0x8
  40d3ef:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  40d3f4:	add    rsp,0x8
  40d3f8:	add    rsp,0x20
  40d3fc:	lea    rax,[rip+0x6215]        # 413618 <__swc_rdata_base_0a4ed24b+0x508>
  40d403:	sub    rsp,0x20
  40d407:	mov    rcx,rsp
  40d40a:	mov    QWORD PTR [rcx],rax
  40d40d:	mov    QWORD PTR [rcx+0x8],r13
  40d411:	mov    QWORD PTR [rcx+0x10],rsp
  40d415:	mov    QWORD PTR [rcx+0x18],0x1
  40d41d:	lea    rcx,[rsp+0x10]
  40d422:	sub    rsp,0x8
  40d426:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  40d42b:	add    rsp,0x8
  40d42f:	add    rsp,0x20
  40d433:	lea    r14,[rip+0x5ea6]        # 4132e0 <__swc_rdata_base_0a4ed24b+0x1d0>
  40d43a:	sub    rsp,0x50
  40d43e:	mov    rax,rsp
  40d441:	vmovups xmm0,XMMWORD PTR [rip+0x6307]        # 413750 <__swc_rdata_base_0a4ed24b+0x640>
  40d449:	vmovups XMMWORD PTR [rax],xmm0
  40d44d:	mov    QWORD PTR [rax+0x10],rsp
  40d451:	mov    QWORD PTR [rax+0x18],r13
  40d455:	mov    QWORD PTR [rax+0x20],rdi
  40d459:	lea    rdi,[rip+0x61c8]        # 413628 <__swc_rdata_base_0a4ed24b+0x518>
  40d460:	mov    QWORD PTR [rax+0x28],rdi
  40d464:	mov    QWORD PTR [rax+0x30],r14
  40d468:	mov    QWORD PTR [rax+0x38],r13
  40d46c:	lea    rcx,[rsp+0x10]
  40d471:	mov    QWORD PTR [rax+0x40],rcx
  40d475:	mov    QWORD PTR [rax+0x48],0x3
  40d47d:	lea    rcx,[rsp+0x40]
  40d482:	sub    rsp,0x8
  40d486:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  40d48b:	add    rsp,0x8
  40d48f:	add    rsp,0x50
  40d493:	lea    rax,[rip+0x61d6]        # 413670 <__swc_rdata_base_0a4ed24b+0x560>
  40d49a:	sub    rsp,0x20
  40d49e:	mov    rcx,rsp
  40d4a1:	mov    QWORD PTR [rcx],rax
  40d4a4:	mov    QWORD PTR [rcx+0x8],r13
  40d4a8:	mov    QWORD PTR [rcx+0x10],rsp
  40d4ac:	mov    QWORD PTR [rcx+0x18],0x1
  40d4b4:	lea    rcx,[rsp+0x10]
  40d4b9:	sub    rsp,0x8
  40d4bd:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  40d4c2:	add    rsp,0x8
  40d4c6:	add    rsp,0x20
  40d4ca:	mov    eax,DWORD PTR [rsi+0x20]
  40d4cd:	mov    ecx,DWORD PTR [rsi+0x24]
  40d4d0:	sub    rsp,0xa0
  40d4d7:	mov    rdx,rsp
  40d4da:	mov    QWORD PTR [rdx+0x30],rsi
  40d4de:	mov    QWORD PTR [rdx+0x38],rdi
  40d4e2:	vmovups xmm0,XMMWORD PTR [rip+0x61fe]        # 4136e8 <__swc_rdata_base_0a4ed24b+0x5d8>
  40d4ea:	vmovups XMMWORD PTR [rdx],xmm0
  40d4ee:	mov    QWORD PTR [rdx+0x40],rsp
  40d4f2:	mov    QWORD PTR [rdx+0x48],r13
  40d4f6:	mov    DWORD PTR [rdx+0x10],eax
  40d4f9:	lea    rax,[rsp+0x10]
  40d4fe:	mov    QWORD PTR [rdx+0x50],rax
  40d502:	lea    rax,[rip+0x6177]        # 413680 <__swc_rdata_base_0a4ed24b+0x570>
  40d509:	mov    QWORD PTR [rdx+0x58],rax
  40d50d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  40d512:	lea    r8,[rsp+0x18]
  40d517:	mov    QWORD PTR [rdx+0x60],r8
  40d51b:	mov    QWORD PTR [rdx+0x68],r13
  40d51f:	mov    DWORD PTR [rdx+0x28],ecx
  40d522:	lea    rcx,[rdx+0x28]
  40d526:	mov    QWORD PTR [rdx+0x70],rcx
  40d52a:	mov    QWORD PTR [rdx+0x78],rax
  40d52e:	mov    QWORD PTR [rdx+0x80],r14
  40d535:	mov    QWORD PTR [rdx+0x88],r13
  40d53c:	lea    rax,[rdx+0x30]
  40d540:	mov    QWORD PTR [rdx+0x90],rax
  40d547:	mov    QWORD PTR [rdx+0x98],0x6
  40d552:	lea    rcx,[rdx+0x90]
  40d559:	sub    rsp,0x8
  40d55d:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  40d562:	add    rsp,0x8
  40d566:	add    rsp,0xa0
  40d56d:	sub    rsp,0x20
  40d571:	mov    rax,rsp
  40d574:	mov    QWORD PTR [rax],r14
  40d577:	mov    QWORD PTR [rax+0x8],r13
  40d57b:	mov    QWORD PTR [rax+0x10],rsp
  40d57f:	mov    QWORD PTR [rax+0x18],0x1
  40d587:	lea    rcx,[rsp+0x10]
  40d58c:	sub    rsp,0x8
  40d590:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  40d595:	add    rsp,0x8
  40d599:	add    rsp,0x20
  40d59d:	mov    eax,DWORD PTR [r12+0x9ac]
  40d5a5:	test   eax,eax
  40d5a7:	je     40d7e0 <__swc_fn_0a4ed24b_000106_ffe51047+0x480>
  40d5ad:	lea    rax,[rip+0x6114]        # 4136c8 <__swc_rdata_base_0a4ed24b+0x5b8>
  40d5b4:	sub    rsp,0x20
  40d5b8:	mov    rcx,rsp
  40d5bb:	mov    QWORD PTR [rcx],rax
  40d5be:	mov    QWORD PTR [rcx+0x8],r13
  40d5c2:	mov    QWORD PTR [rcx+0x10],rsp
  40d5c6:	mov    QWORD PTR [rcx+0x18],0x1
  40d5ce:	lea    rcx,[rsp+0x10]
  40d5d3:	sub    rsp,0x8
  40d5d7:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  40d5dc:	add    rsp,0x8
  40d5e0:	add    rsp,0x20
  40d5e4:	mov    eax,DWORD PTR [r12+0x9ac]
  40d5ec:	dec    eax
  40d5ee:	mov    esi,eax
  40d5f0:	test   esi,esi
  40d5f2:	jl     40d7b0 <__swc_fn_0a4ed24b_000106_ffe51047+0x450>
  40d5f8:	jmp    40d604 <__swc_fn_0a4ed24b_000106_ffe51047+0x2a4>
  40d5fa:	nop    WORD PTR [rax+rax*1+0x0]
  40d600:	dec    esi
  40d602:	jmp    40d5f0 <__swc_fn_0a4ed24b_000106_ffe51047+0x290>
  40d604:	lea    rax,[rip+0x60cd]        # 4136d8 <__swc_rdata_base_0a4ed24b+0x5c8>
  40d60b:	sub    rsp,0x20
  40d60f:	mov    rcx,rsp
  40d612:	mov    QWORD PTR [rcx],rax
  40d615:	mov    QWORD PTR [rcx+0x8],r13
  40d619:	mov    QWORD PTR [rcx+0x10],rsp
  40d61d:	mov    QWORD PTR [rcx+0x18],0x1
  40d625:	lea    rcx,[rsp+0x10]
  40d62a:	sub    rsp,0x8
  40d62e:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  40d633:	add    rsp,0x8
  40d637:	add    rsp,0x20
  40d63b:	movsxd rax,esi
  40d63e:	imul   r15,rax,0x30
  40d642:	add    r15,r12
  40d645:	add    r15,0xf8
  40d64c:	sub    rsp,0x20
  40d650:	mov    rax,rsp
  40d653:	mov    QWORD PTR [rax],r15
  40d656:	mov    QWORD PTR [rax+0x8],rdi
  40d65a:	mov    QWORD PTR [rax+0x10],rsp
  40d65e:	mov    QWORD PTR [rax+0x18],0x1
  40d666:	lea    rcx,[rsp+0x10]
  40d66b:	sub    rsp,0x8
  40d66f:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  40d674:	add    rsp,0x8
  40d678:	add    rsp,0x20
  40d67c:	mov    QWORD PTR [rsp+0x4f8],rsi
  40d684:	lea    rsi,[rip+0x605d]        # 4136e8 <__swc_rdata_base_0a4ed24b+0x5d8>
  40d68b:	sub    rsp,0x20
  40d68f:	mov    rax,rsp
  40d692:	mov    QWORD PTR [rax],rsi
  40d695:	mov    QWORD PTR [rax+0x8],r13
  40d699:	mov    QWORD PTR [rax+0x10],rsp
  40d69d:	mov    QWORD PTR [rax+0x18],0x1
  40d6a5:	lea    rcx,[rsp+0x10]
  40d6aa:	sub    rsp,0x8
  40d6ae:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  40d6b3:	add    rsp,0x8
  40d6b7:	add    rsp,0x20
  40d6bb:	sub    rsp,0x30
  40d6bf:	mov    rax,rsp
  40d6c2:	mov    ecx,DWORD PTR [r15+0x20]
  40d6c6:	mov    QWORD PTR [rax],rcx
  40d6c9:	mov    QWORD PTR [rax+0x8],rsp
  40d6cd:	lea    rdi,[rip+0x6024]        # 4136f8 <__swc_rdata_base_0a4ed24b+0x5e8>
  40d6d4:	mov    QWORD PTR [rax+0x10],rdi
  40d6d8:	lea    rcx,[rsp+0x8]
  40d6dd:	mov    QWORD PTR [rax+0x18],rcx
  40d6e1:	mov    QWORD PTR [rax+0x20],0x1
  40d6e9:	lea    rcx,[rsp+0x18]
  40d6ee:	sub    rsp,0x8
  40d6f2:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  40d6f7:	add    rsp,0x8
  40d6fb:	add    rsp,0x30
  40d6ff:	sub    rsp,0x20
  40d703:	mov    rax,rsp
  40d706:	mov    QWORD PTR [rax],rsi
  40d709:	mov    QWORD PTR [rax+0x8],r13
  40d70d:	mov    QWORD PTR [rax+0x10],rsp
  40d711:	mov    QWORD PTR [rax+0x18],0x1
  40d719:	lea    rcx,[rsp+0x10]
  40d71e:	sub    rsp,0x8
  40d722:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  40d727:	add    rsp,0x8
  40d72b:	add    rsp,0x20
  40d72f:	sub    rsp,0x30
  40d733:	mov    rax,rsp
  40d736:	mov    ecx,DWORD PTR [r15+0x24]
  40d73a:	mov    QWORD PTR [rax],rcx
  40d73d:	mov    QWORD PTR [rax+0x8],rsp
  40d741:	mov    QWORD PTR [rax+0x10],rdi
  40d745:	lea    rcx,[rsp+0x8]
  40d74a:	mov    QWORD PTR [rax+0x18],rcx
  40d74e:	mov    QWORD PTR [rax+0x20],0x1
  40d756:	lea    rcx,[rsp+0x18]
  40d75b:	sub    rsp,0x8
  40d75f:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  40d764:	add    rsp,0x8
  40d768:	add    rsp,0x30
  40d76c:	sub    rsp,0x20
  40d770:	mov    rax,rsp
  40d773:	mov    QWORD PTR [rax],r14
  40d776:	mov    QWORD PTR [rax+0x8],r13
  40d77a:	mov    QWORD PTR [rax+0x10],rsp
  40d77e:	mov    QWORD PTR [rax+0x18],0x1
  40d786:	lea    rcx,[rsp+0x10]
  40d78b:	sub    rsp,0x8
  40d78f:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  40d794:	add    rsp,0x8
  40d798:	add    rsp,0x20
  40d79c:	lea    rdi,[rip+0x5e85]        # 413628 <__swc_rdata_base_0a4ed24b+0x518>
  40d7a3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  40d7ab:	jmp    40d600 <__swc_fn_0a4ed24b_000106_ffe51047+0x2a0>
  40d7b0:	sub    rsp,0x20
  40d7b4:	mov    rax,rsp
  40d7b7:	mov    QWORD PTR [rax],r14
  40d7ba:	mov    QWORD PTR [rax+0x8],r13
  40d7be:	mov    QWORD PTR [rax+0x10],rsp
  40d7c2:	mov    QWORD PTR [rax+0x18],0x1
  40d7ca:	lea    rcx,[rsp+0x10]
  40d7cf:	sub    rsp,0x8
  40d7d3:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  40d7d8:	add    rsp,0x8
  40d7dc:	add    rsp,0x20
  40d7e0:	lea    rax,[rbx+0x28]
  40d7e4:	mov    rcx,rax
  40d7e7:	mov    QWORD PTR [rbx+0x28],0x0
  40d7ef:	mov    QWORD PTR [rbx+0x30],0x0
  40d7f7:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  40d7fc:	add    rcx,0x10
  40d800:	mov    edx,0x1f
  40d805:	cs nop WORD PTR [rax+rax*1+0x0]
  40d80f:	nop
  40d810:	vmovups XMMWORD PTR [rcx],xmm0
  40d814:	add    rcx,0x10
  40d818:	sub    rdx,0x1
  40d81c:	jne    40d810 <__swc_fn_0a4ed24b_000106_ffe51047+0x4b0>
  40d81e:	lea    rsi,[rbx+0x228]
  40d825:	xor    ecx,ecx
  40d827:	cs nop WORD PTR [rax+rax*1+0x0]
  40d831:	cs nop WORD PTR [rax+rax*1+0x0]
  40d83b:	nop    DWORD PTR [rax+rax*1+0x0]
  40d840:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  40d845:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  40d84a:	add    rcx,0x10
  40d84e:	cmp    rcx,0x200
  40d855:	jne    40d840 <__swc_fn_0a4ed24b_000106_ffe51047+0x4e0>
  40d857:	mov    eax,DWORD PTR [r12+0xbc8]
  40d85f:	lea    rcx,[r12+0x9c8]
  40d867:	mov    QWORD PTR [rbx+0x428],rcx
  40d86e:	mov    QWORD PTR [rbx+0x430],rax
  40d875:	lea    rdi,[rbx+0x438]
  40d87c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  40d884:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  40d88c:	mov    eax,DWORD PTR [r12+0xbc8]
  40d894:	test   eax,eax
  40d896:	jne    40d8e3 <__swc_fn_0a4ed24b_000106_ffe51047+0x583>
  40d898:	lea    rax,[rbx+0x448]
  40d89f:	mov    QWORD PTR [rbx+0x448],rsi
  40d8a6:	mov    QWORD PTR [rax+0x8],0x40
  40d8ae:	mov    ecx,0x1
  40d8b3:	mov    rdx,rax
  40d8b6:	sub    rsp,0x8
  40d8ba:	call   4099c0 <__swc_fn_0a4ed24b_000123_4f256d58>
  40d8bf:	add    rsp,0x8
  40d8c3:	mov    QWORD PTR [rbx+0x460],rsi
  40d8ca:	mov    ecx,eax
  40d8cc:	mov    QWORD PTR [rbx+0x468],rcx
  40d8d3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  40d8db:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  40d8e3:	mov    rsi,QWORD PTR [rbx+0x438]
  40d8ea:	mov    rax,QWORD PTR [rbx+0x440]
  40d8f1:	mov    r15,rax
  40d8f4:	xor    r12d,r12d
  40d8f7:	test   r15,r15
  40d8fa:	je     40d9b0 <__swc_fn_0a4ed24b_000106_ffe51047+0x650>
  40d900:	mov    rax,QWORD PTR [rsi+r12*8]
  40d904:	test   rax,rax
  40d907:	je     40d926 <__swc_fn_0a4ed24b_000106_ffe51047+0x5c6>
  40d909:	lea    rcx,[rbx+0x4b8]
  40d910:	mov    rdx,rax
  40d913:	sub    rsp,0x8
  40d917:	call   40e810 <__swc_fn_0a4ed24b_000166_cc119975>
  40d91c:	add    rsp,0x8
  40d920:	mov    al,BYTE PTR [rax]
  40d922:	test   al,al
  40d924:	jne    40d932 <__swc_fn_0a4ed24b_000106_ffe51047+0x5d2>
  40d926:	add    r12,0x1
  40d92a:	sub    r15,0x1
  40d92e:	jne    40d900 <__swc_fn_0a4ed24b_000106_ffe51047+0x5a0>
  40d930:	jmp    40d9b0 <__swc_fn_0a4ed24b_000106_ffe51047+0x650>
  40d932:	lea    rax,[rip+0x5e07]        # 413740 <__swc_rdata_base_0a4ed24b+0x630>
  40d939:	sub    rsp,0x20
  40d93d:	mov    rcx,rsp
  40d940:	mov    QWORD PTR [rcx],rax
  40d943:	mov    QWORD PTR [rcx+0x8],r13
  40d947:	mov    QWORD PTR [rcx+0x10],rsp
  40d94b:	mov    QWORD PTR [rcx+0x18],0x1
  40d953:	lea    rcx,[rsp+0x10]
  40d958:	sub    rsp,0x8
  40d95c:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  40d961:	add    rsp,0x8
  40d965:	add    rsp,0x20
  40d969:	mov    rcx,rdi
  40d96c:	xor    edx,edx
  40d96e:	mov    al,0x1
  40d970:	mov    r8,rax
  40d973:	sub    rsp,0x8
  40d977:	call   411dc0 <__swc_fn_0a4ed24b_000167_bcc835b8>
  40d97c:	add    rsp,0x8
  40d980:	sub    rsp,0x20
  40d984:	mov    rax,rsp
  40d987:	mov    QWORD PTR [rax],r14
  40d98a:	mov    QWORD PTR [rax+0x8],r13
  40d98e:	mov    QWORD PTR [rax+0x10],rsp
  40d992:	mov    QWORD PTR [rax+0x18],0x1
  40d99a:	lea    rcx,[rsp+0x10]
  40d99f:	sub    rsp,0x8
  40d9a3:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  40d9a8:	add    rsp,0x8
  40d9ac:	add    rsp,0x20
  40d9b0:	mov    r12,QWORD PTR [rsp+0x4f0]
  40d9b8:	mov    DWORD PTR [r12+0xbc8],0x0
  40d9c4:	add    rsp,0x500
  40d9cb:	pop    r15
  40d9cd:	pop    r14
  40d9cf:	pop    r13
  40d9d1:	pop    r12
  40d9d3:	pop    rdi
  40d9d4:	pop    rsi
  40d9d5:	pop    rbx
  40d9d6:	pop    rbp
  40d9d7:	ret
	...

000000000040d9e0 <__swc_fn_0a4ed24b_000109_7c204aac>:
  40d9e0:	sub    rsp,0x8
  40d9e4:	test   r8,r8
  40d9e7:	je     40d9ee <__swc_fn_0a4ed24b_000109_7c204aac+0xe>
  40d9e9:	call   4090f0 <__swc_fn_0a4ed24b_000108_c51c3158>
  40d9ee:	add    rsp,0x8
  40d9f2:	ret
	...

000000000040da00 <__swc_fn_0a4ed24b_000112_126150d1>:
  40da00:	push   rsi
  40da01:	push   rdi
  40da02:	push   r12
  40da04:	push   r13
  40da06:	sub    rsp,0xd8
  40da0d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40da13:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40da19:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40da1f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40da25:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40da2b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40da34:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40da3d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40da46:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40da4f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40da58:	xor    eax,eax
  40da5a:	call   407060 <getpid@plt>
  40da5f:	mov    rsi,rax
  40da62:	lea    rdi,[rip+0x192df]        # 426d48 <__swc_bss_base_0a4ed24b+0x2d08>
  40da69:	mov    r12,QWORD PTR [rdi]
  40da6c:	test   r12,r12
  40da6f:	je     40da7d <__swc_fn_0a4ed24b_000112_126150d1+0x7d>
  40da71:	cmp    DWORD PTR [r12+0x10],esi
  40da76:	jne    40da7d <__swc_fn_0a4ed24b_000112_126150d1+0x7d>
  40da78:	mov    rax,r12
  40da7b:	jmp    40dae0 <__swc_fn_0a4ed24b_000112_126150d1+0xe0>
  40da7d:	mov    ecx,0x4
  40da82:	mov    edx,0x18
  40da87:	call   4091d0 <__swc_fn_0a4ed24b_000111_6814119b>
  40da8c:	mov    rcx,rax
  40da8f:	test   rax,rax
  40da92:	jne    40da98 <__swc_fn_0a4ed24b_000112_126150d1+0x98>
  40da94:	xor    eax,eax
  40da96:	jmp    40dae0 <__swc_fn_0a4ed24b_000112_126150d1+0xe0>
  40da98:	mov    DWORD PTR [rcx+0x10],esi
  40da9b:	mov    rax,r12
  40da9e:	lock cmpxchg QWORD PTR [rdi],rcx
  40daa3:	mov    r13,rax
  40daa6:	cmp    rax,r12
  40daa9:	je     40dabf <__swc_fn_0a4ed24b_000112_126150d1+0xbf>
  40daab:	mov    rdi,rcx
  40daae:	mov    esi,0x18
  40dab3:	xor    eax,eax
  40dab5:	call   407160 <munmap@plt>
  40daba:	mov    rax,r13
  40dabd:	jmp    40dae0 <__swc_fn_0a4ed24b_000112_126150d1+0xe0>
  40dabf:	test   r12,r12
  40dac2:	je     40dadd <__swc_fn_0a4ed24b_000112_126150d1+0xdd>
  40dac4:	mov    rdi,r12
  40dac7:	mov    esi,0x18
  40dacc:	xor    eax,eax
  40dace:	mov    QWORD PTR [rsp+0x28],rcx
  40dad3:	call   407160 <munmap@plt>
  40dad8:	mov    rcx,QWORD PTR [rsp+0x28]
  40dadd:	mov    rax,rcx
  40dae0:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40dae6:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40daec:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40daf2:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40daf8:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40dafe:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40db07:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40db10:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40db19:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40db22:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40db2b:	add    rsp,0xd8
  40db32:	pop    r13
  40db34:	pop    r12
  40db36:	pop    rdi
  40db37:	pop    rsi
  40db38:	ret
  40db39:	add    BYTE PTR [rax],al
  40db3b:	add    BYTE PTR [rax],al
  40db3d:	add    BYTE PTR [rax],al
	...

000000000040db40 <__swc_fn_0a4ed24b_000115_36905703>:
  40db40:	push   rbx
  40db41:	push   r12
  40db43:	push   rdi
  40db44:	push   rsi
  40db45:	sub    rsp,0xa8
  40db4c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40db52:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40db58:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40db5e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40db64:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40db6a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40db70:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40db76:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40db7c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40db85:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40db8e:	mov    rbx,rdx
  40db91:	mov    r12,rcx
  40db94:	mov    rdi,rcx
  40db97:	mov    rsi,rdx
  40db9a:	mov    edx,0x3
  40db9f:	xor    eax,eax
  40dba1:	call   407170 <mprotect@plt>
  40dba6:	test   eax,eax
  40dba8:	je     40dbae <__swc_fn_0a4ed24b_000115_36905703+0x6e>
  40dbaa:	xor    eax,eax
  40dbac:	jmp    40dbc3 <__swc_fn_0a4ed24b_000115_36905703+0x83>
  40dbae:	mov    rcx,r12
  40dbb1:	mov    rdx,rbx
  40dbb4:	mov    al,0x1
  40dbb6:	mov    r8,rax
  40dbb9:	call   409800 <__swc_fn_0a4ed24b_000114_5f48311c>
  40dbbe:	mov    eax,0x1
  40dbc3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40dbc9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40dbcf:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40dbd5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40dbdb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40dbe1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40dbe7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40dbed:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40dbf3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40dbfc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40dc05:	add    rsp,0xa8
  40dc0c:	pop    rsi
  40dc0d:	pop    rdi
  40dc0e:	pop    r12
  40dc10:	pop    rbx
  40dc11:	ret
	...

000000000040dc20 <__swc_fn_0a4ed24b_000118_5208f471>:
  40dc20:	sub    rsp,0x8
  40dc24:	test   rcx,rcx
  40dc27:	jne    40dc2e <__swc_fn_0a4ed24b_000118_5208f471+0xe>
  40dc29:	add    rsp,0x8
  40dc2d:	ret
  40dc2e:	call   4113e0 <__swc_fn_0a4ed24b_000119_d3318640>
  40dc33:	add    rsp,0x8
  40dc37:	ret
	...

000000000040dc40 <__swc_fn_0a4ed24b_000121_0a5fa85a>:
  40dc40:	push   rdi
  40dc41:	push   rsi
  40dc42:	sub    rsp,0xa8
  40dc49:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40dc4f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40dc55:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40dc5b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40dc61:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40dc67:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40dc6d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40dc73:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40dc79:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40dc82:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40dc8b:	xor    edi,edi
  40dc8d:	xor    eax,eax
  40dc8f:	call   407180 <exit@plt>
  40dc94:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40dc9a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40dca0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40dca6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40dcac:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40dcb2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40dcb8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40dcbe:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40dcc4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40dccd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40dcd6:	add    rsp,0xa8
  40dcdd:	pop    rsi
  40dcde:	pop    rdi
  40dcdf:	ret

000000000040dce0 <__swc_fn_0a4ed24b_000124_83db7238>:
  40dce0:	push   rbx
  40dce1:	push   rsi
  40dce2:	push   rdi
  40dce3:	push   r12
  40dce5:	sub    rsp,0x18
  40dce9:	mov    rbx,r8
  40dcec:	mov    rsi,rcx
  40dcef:	mov    rdi,rdx
  40dcf2:	mov    rcx,QWORD PTR [rip+0x19047]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40dcf9:	test   rcx,rcx
  40dcfc:	jne    40dd0e <__swc_fn_0a4ed24b_000124_83db7238+0x2e>
  40dcfe:	call   40eaa0 <__swc_fn_0a4ed24b_000169_994c8876>
  40dd03:	lea    rcx,[rax+0x1]
  40dd07:	mov    QWORD PTR [rip+0x19032],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40dd0e:	dec    rcx
  40dd11:	call   40b660 <__swc_fn_0a4ed24b_000171_360af05d>
  40dd16:	mov    r12,rax
  40dd19:	cmp    ebx,0x3
  40dd1c:	jne    40dd2f <__swc_fn_0a4ed24b_000124_83db7238+0x4f>
  40dd1e:	mov    rax,QWORD PTR [r12+0xbd0]
  40dd26:	test   rax,rax
  40dd29:	jne    40de6c <__swc_fn_0a4ed24b_000124_83db7238+0x18c>
  40dd2f:	cmp    ebx,0x5
  40dd32:	jne    40dd56 <__swc_fn_0a4ed24b_000124_83db7238+0x76>
  40dd34:	call   410cb0 <__swc_fn_0a4ed24b_000095_ad13d15c>
  40dd39:	test   al,al
  40dd3b:	jne    40dd56 <__swc_fn_0a4ed24b_000124_83db7238+0x76>
  40dd3d:	mov    rcx,rsi
  40dd40:	mov    rdx,rdi
  40dd43:	call   40b610 <__swc_fn_0a4ed24b_000168_3459066f>
  40dd48:	test   al,al
  40dd4a:	je     40dd56 <__swc_fn_0a4ed24b_000124_83db7238+0x76>
  40dd4c:	add    rsp,0x18
  40dd50:	pop    r12
  40dd52:	pop    rdi
  40dd53:	pop    rsi
  40dd54:	pop    rbx
  40dd55:	ret
  40dd56:	call   410cb0 <__swc_fn_0a4ed24b_000095_ad13d15c>
  40dd5b:	test   al,al
  40dd5d:	jne    40ddcf <__swc_fn_0a4ed24b_000124_83db7238+0xef>
  40dd5f:	vmovups xmm0,XMMWORD PTR [rsi]
  40dd63:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dd69:	mov    rax,QWORD PTR [rsp+0x8]
  40dd6e:	test   rax,rax
  40dd71:	jne    40ddc2 <__swc_fn_0a4ed24b_000124_83db7238+0xe2>
  40dd73:	cmp    ebx,0x3
  40dd76:	je     40dd84 <__swc_fn_0a4ed24b_000124_83db7238+0xa4>
  40dd78:	cmp    ebx,0x4
  40dd7b:	je     40dd94 <__swc_fn_0a4ed24b_000124_83db7238+0xb4>
  40dd7d:	cmp    ebx,0x5
  40dd80:	je     40dda4 <__swc_fn_0a4ed24b_000124_83db7238+0xc4>
  40dd82:	jmp    40ddb4 <__swc_fn_0a4ed24b_000124_83db7238+0xd4>
  40dd84:	vmovups xmm0,XMMWORD PTR [rip+0x5a04]        # 413790 <__swc_rdata_base_0a4ed24b+0x680>
  40dd8c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dd92:	jmp    40ddc2 <__swc_fn_0a4ed24b_000124_83db7238+0xe2>
  40dd94:	vmovups xmm0,XMMWORD PTR [rip+0x5a04]        # 4137a0 <__swc_rdata_base_0a4ed24b+0x690>
  40dd9c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dda2:	jmp    40ddc2 <__swc_fn_0a4ed24b_000124_83db7238+0xe2>
  40dda4:	vmovups xmm0,XMMWORD PTR [rip+0x5a04]        # 4137b0 <__swc_rdata_base_0a4ed24b+0x6a0>
  40ddac:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ddb2:	jmp    40ddc2 <__swc_fn_0a4ed24b_000124_83db7238+0xe2>
  40ddb4:	vmovups xmm0,XMMWORD PTR [rip+0x5a04]        # 4137c0 <__swc_rdata_base_0a4ed24b+0x6b0>
  40ddbc:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ddc2:	lea    rcx,[rsp+0x8]
  40ddc7:	mov    rdx,rdi
  40ddca:	call   410f00 <__swc_fn_0a4ed24b_000107_90faaa26>
  40ddcf:	vmovups xmm0,XMMWORD PTR [rdi]
  40ddd3:	vmovups XMMWORD PTR [r12+0x940],xmm0
  40dddd:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  40dde2:	vmovups XMMWORD PTR [r12+0x950],xmm0
  40ddec:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  40ddf1:	vmovups XMMWORD PTR [r12+0x960],xmm0
  40ddfb:	lea    rax,[r12+0x940]
  40de03:	mov    QWORD PTR [r12+0x970],rax
  40de0b:	mov    rax,QWORD PTR [rsi]
  40de0e:	mov    QWORD PTR [r12+0x978],rax
  40de16:	mov    rax,QWORD PTR [rsi+0x8]
  40de1a:	mov    QWORD PTR [r12+0x980],rax
  40de22:	movsxd rax,ebx
  40de25:	mov    QWORD PTR [r12+0x988],rax
  40de2d:	cmp    ebx,0x5
  40de30:	je     40de39 <__swc_fn_0a4ed24b_000124_83db7238+0x159>
  40de32:	xor    ecx,ecx
  40de34:	call   40ebd0 <__swc_fn_0a4ed24b_000178_718d7b54>
  40de39:	mov    rbx,QWORD PTR [r12+0xbe8]
  40de41:	test   rbx,rbx
  40de44:	je     40de55 <__swc_fn_0a4ed24b_000124_83db7238+0x175>
  40de46:	mov    rcx,r12
  40de49:	call   rbx
  40de4b:	add    rsp,0x18
  40de4f:	pop    r12
  40de51:	pop    rdi
  40de52:	pop    rsi
  40de53:	pop    rbx
  40de54:	ret
  40de55:	mov    rcx,rsi
  40de58:	call   4098b0 <__swc_fn_0a4ed24b_000120_2648f149>
  40de5d:	call   411530 <__swc_fn_0a4ed24b_000122_be2e2f68>
  40de62:	add    rsp,0x18
  40de66:	pop    r12
  40de68:	pop    rdi
  40de69:	pop    rsi
  40de6a:	pop    rbx
  40de6b:	ret
  40de6c:	mov    rcx,rsi
  40de6f:	mov    rdx,rdi
  40de72:	call   410f00 <__swc_fn_0a4ed24b_000107_90faaa26>
  40de77:	jmp    40dd2f <__swc_fn_0a4ed24b_000124_83db7238+0x4f>
  40de7c:	add    BYTE PTR [rax],al
	...

000000000040de80 <__swc_fn_0a4ed24b_000127_58f0f391>:
  40de80:	push   rdi
  40de81:	push   rsi
  40de82:	sub    rsp,0xb8
  40de89:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40de8f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40de95:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40de9b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40dea1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40dea7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40dead:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40deb3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40debc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40dec5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40dece:	mov    DWORD PTR [rsp+0x8],0x0
  40ded6:	lea    rdi,[rsp+0x8]
  40dedb:	xor    esi,esi
  40dedd:	xor    eax,eax
  40dedf:	call   407190 <pthread_key_create@plt>
  40dee4:	test   eax,eax
  40dee6:	jne    40deee <__swc_fn_0a4ed24b_000127_58f0f391+0x6e>
  40dee8:	mov    eax,DWORD PTR [rsp+0x8]
  40deec:	jmp    40def5 <__swc_fn_0a4ed24b_000127_58f0f391+0x75>
  40deee:	mov    rax,0xffffffffffffffff
  40def5:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40defb:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40df01:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40df07:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40df0d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40df13:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40df19:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40df1f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40df28:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40df31:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40df3a:	add    rsp,0xb8
  40df41:	pop    rsi
  40df42:	pop    rdi
  40df43:	ret
	...

000000000040df50 <__swc_fn_0a4ed24b_000130_4a82cdf6>:
  40df50:	push   rdi
  40df51:	push   rsi
  40df52:	sub    rsp,0xb8
  40df59:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40df5f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40df65:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40df6b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40df71:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40df77:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40df7d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40df83:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40df8c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40df95:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40df9e:	mov    DWORD PTR [rsp+0x8],0x0
  40dfa6:	lea    rdi,[rsp+0x8]
  40dfab:	mov    rsi,rcx
  40dfae:	xor    eax,eax
  40dfb0:	call   407190 <pthread_key_create@plt>
  40dfb5:	test   eax,eax
  40dfb7:	jne    40dfc2 <__swc_fn_0a4ed24b_000130_4a82cdf6+0x72>
  40dfb9:	mov    eax,DWORD PTR [rsp+0x8]
  40dfbd:	inc    rax
  40dfc0:	jmp    40dfc4 <__swc_fn_0a4ed24b_000130_4a82cdf6+0x74>
  40dfc2:	xor    eax,eax
  40dfc4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40dfca:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40dfd0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40dfd6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40dfdc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40dfe2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40dfe8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40dfee:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40dff7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40e000:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40e009:	add    rsp,0xb8
  40e010:	pop    rsi
  40e011:	pop    rdi
  40e012:	ret
	...

000000000040e020 <__swc_fn_0a4ed24b_000133_ae5891af>:
  40e020:	push   rdi
  40e021:	push   rsi
  40e022:	sub    rsp,0xa8
  40e029:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e02f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e035:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e03b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e041:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e047:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e04d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e053:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e059:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e062:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e06b:	test   rcx,rcx
  40e06e:	setne  al
  40e071:	je     40e08a <__swc_fn_0a4ed24b_000133_ae5891af+0x6a>
  40e073:	lea    rax,[rcx-0x1]
  40e077:	mov    eax,eax
  40e079:	mov    edi,eax
  40e07b:	mov    rsi,rdx
  40e07e:	xor    eax,eax
  40e080:	call   407130 <pthread_setspecific@plt>
  40e085:	test   eax,eax
  40e087:	sete   al
  40e08a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e090:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e096:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e09c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e0a2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e0a8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e0ae:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e0b4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e0ba:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e0c3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e0cc:	add    rsp,0xa8
  40e0d3:	pop    rsi
  40e0d4:	pop    rdi
  40e0d5:	ret
	...

000000000040e0e0 <__swc_fn_0a4ed24b_000136_865f5106>:
  40e0e0:	push   rdi
  40e0e1:	push   rsi
  40e0e2:	sub    rsp,0xa8
  40e0e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e0ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e0f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e0fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e101:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e107:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e10d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e113:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e119:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e122:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e12b:	mov    rax,rdx
  40e12e:	mov    QWORD PTR [rsp],0x0
  40e136:	mov    edi,0xca
  40e13b:	mov    rsi,rcx
  40e13e:	mov    edx,0x81
  40e143:	mov    eax,eax
  40e145:	mov    ecx,eax
  40e147:	xor    r8d,r8d
  40e14a:	xor    r9d,r9d
  40e14d:	xor    eax,eax
  40e14f:	call   4071a0 <syscall@plt>
  40e154:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e15a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e160:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e166:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e16c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e172:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e178:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e17e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e184:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e18d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e196:	add    rsp,0xa8
  40e19d:	pop    rsi
  40e19e:	pop    rdi
  40e19f:	ret

000000000040e1a0 <__swc_fn_0a4ed24b_000139_86bb0f90>:
  40e1a0:	sub    rsp,0x8
  40e1a4:	call   4118d0 <__swc_fn_0a4ed24b_000137_8c07c14b>
  40e1a9:	add    rsp,0x8
  40e1ad:	ret
	...

000000000040e1b0 <__swc_fn_0a4ed24b_000142_be4c2719>:
  40e1b0:	push   rdi
  40e1b1:	push   rsi
  40e1b2:	sub    rsp,0xc8
  40e1b9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40e1bf:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40e1c5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40e1cb:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40e1d1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40e1d7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40e1dd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40e1e6:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40e1ef:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40e1f8:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40e201:	vxorps xmm0,xmm0,xmm0
  40e205:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e20b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e211:	mov    rdi,rcx
  40e214:	lea    rsi,[rsp+0x8]
  40e219:	xor    eax,eax
  40e21b:	call   4071b0 <dladdr@plt>
  40e220:	xor    ecx,ecx
  40e222:	test   eax,eax
  40e224:	je     40e22b <__swc_fn_0a4ed24b_000142_be4c2719+0x7b>
  40e226:	mov    rcx,QWORD PTR [rsp+0x10]
  40e22b:	mov    rax,rcx
  40e22e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40e234:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40e23a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40e240:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40e246:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40e24c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40e252:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40e25b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40e264:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40e26d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40e276:	add    rsp,0xc8
  40e27d:	pop    rsi
  40e27e:	pop    rdi
  40e27f:	ret

000000000040e280 <__swc_fn_0a4ed24b_000145_1534de9a>:
  40e280:	push   rbx
  40e281:	push   r12
  40e283:	push   r13
  40e285:	push   rdi
  40e286:	push   rsi
  40e287:	push   r14
  40e289:	push   r15
  40e28b:	sub    rsp,0x150
  40e292:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40e29b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40e2a4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40e2ad:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40e2b6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40e2bf:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40e2c8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40e2d1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40e2da:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40e2e3:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40e2ec:	mov    rbx,rdx
  40e2ef:	mov    QWORD PTR [rsp+0x98],rdx
  40e2f7:	mov    r12,rcx
  40e2fa:	mov    QWORD PTR [rsp+0xa0],rcx
  40e302:	mov    QWORD PTR [rbx],0x0
  40e309:	lea    r13,[rip+0x18a70]        # 426d80 <__swc_bss_base_0a4ed24b+0x2d40>
  40e310:	mov    rcx,r13
  40e313:	call   40e1a0 <__swc_fn_0a4ed24b_000139_86bb0f90>
  40e318:	mov    rax,QWORD PTR [rip+0x18a69]        # 426d88 <__swc_bss_base_0a4ed24b+0x2d48>
  40e31f:	test   rax,rax
  40e322:	je     40e359 <__swc_fn_0a4ed24b_000145_1534de9a+0xd9>
  40e324:	cs nop WORD PTR [rax+rax*1+0x0]
  40e32e:	xchg   ax,ax
  40e330:	cmp    QWORD PTR [rax+0x8],r12
  40e334:	jne    40e351 <__swc_fn_0a4ed24b_000145_1534de9a+0xd1>
  40e336:	mov    rcx,QWORD PTR [rax+0x18]
  40e33a:	mov    QWORD PTR [rbx],rcx
  40e33d:	mov    rbx,QWORD PTR [rax+0x10]
  40e341:	mov    rcx,r13
  40e344:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40e349:	mov    rax,rbx
  40e34c:	jmp    40e53b <__swc_fn_0a4ed24b_000145_1534de9a+0x2bb>
  40e351:	mov    rax,QWORD PTR [rax]
  40e354:	test   rax,rax
  40e357:	jne    40e330 <__swc_fn_0a4ed24b_000145_1534de9a+0xb0>
  40e359:	vxorps xmm0,xmm0,xmm0
  40e35d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  40e363:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  40e369:	mov    rdi,r12
  40e36c:	lea    rsi,[rsp+0x10]
  40e371:	xor    eax,eax
  40e373:	call   4071b0 <dladdr@plt>
  40e378:	test   eax,eax
  40e37a:	sete   al
  40e37d:	je     40e38a <__swc_fn_0a4ed24b_000145_1534de9a+0x10a>
  40e37f:	mov    rax,QWORD PTR [rsp+0x10]
  40e384:	test   rax,rax
  40e387:	sete   al
  40e38a:	test   al,al
  40e38c:	je     40e39d <__swc_fn_0a4ed24b_000145_1534de9a+0x11d>
  40e38e:	mov    rcx,r13
  40e391:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40e396:	xor    eax,eax
  40e398:	jmp    40e53b <__swc_fn_0a4ed24b_000145_1534de9a+0x2bb>
  40e39d:	mov    rdi,QWORD PTR [rsp+0x10]
  40e3a2:	mov    esi,0x80000
  40e3a7:	xor    eax,eax
  40e3a9:	call   407020 <open@plt>
  40e3ae:	lea    r14,[rsp+0x30]
  40e3b3:	mov    DWORD PTR [rsp+0x30],eax
  40e3b7:	cmp    DWORD PTR [r14],0x0
  40e3bb:	jge    40e3cc <__swc_fn_0a4ed24b_000145_1534de9a+0x14c>
  40e3bd:	mov    rcx,r13
  40e3c0:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40e3c5:	xor    eax,eax
  40e3c7:	jmp    40e53b <__swc_fn_0a4ed24b_000145_1534de9a+0x2bb>
  40e3cc:	mov    rax,r14
  40e3cf:	movsxd rdi,DWORD PTR [rax]
  40e3d2:	xor    esi,esi
  40e3d4:	mov    edx,0x2
  40e3d9:	xor    eax,eax
  40e3db:	call   4070d0 <lseek@plt>
  40e3e0:	mov    r15,rax
  40e3e3:	test   rax,rax
  40e3e6:	jg     40e401 <__swc_fn_0a4ed24b_000145_1534de9a+0x181>
  40e3e8:	movsxd rdi,DWORD PTR [r14]
  40e3eb:	xor    eax,eax
  40e3ed:	call   407050 <close@plt>
  40e3f2:	mov    rcx,r13
  40e3f5:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40e3fa:	xor    eax,eax
  40e3fc:	jmp    40e53b <__swc_fn_0a4ed24b_000145_1534de9a+0x2bb>
  40e401:	xor    edi,edi
  40e403:	mov    rsi,r15
  40e406:	mov    edx,0x1
  40e40b:	mov    ecx,0x2
  40e410:	mov    rax,r14
  40e413:	movsxd r8,DWORD PTR [rax]
  40e416:	xor    r9d,r9d
  40e419:	xor    eax,eax
  40e41b:	call   4070e0 <mmap@plt>
  40e420:	mov    rbx,rax
  40e423:	test   rax,rax
  40e426:	sete   al
  40e429:	cmp    rbx,0xffffffffffffffff
  40e42d:	sete   cl
  40e430:	or     al,cl
  40e432:	je     40e44d <__swc_fn_0a4ed24b_000145_1534de9a+0x1cd>
  40e434:	movsxd rdi,DWORD PTR [r14]
  40e437:	xor    eax,eax
  40e439:	call   407050 <close@plt>
  40e43e:	mov    rcx,r13
  40e441:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40e446:	xor    eax,eax
  40e448:	jmp    40e53b <__swc_fn_0a4ed24b_000145_1534de9a+0x2bb>
  40e44d:	lea    rax,[rsp+0x50]
  40e452:	mov    QWORD PTR [rax],0x0
  40e459:	mov    rcx,rbx
  40e45c:	mov    rdx,r15
  40e45f:	mov    r8,rax
  40e462:	call   409e40 <__swc_fn_0a4ed24b_000144_d5d4d43f>
  40e467:	mov    r12,rax
  40e46a:	test   rax,rax
  40e46d:	jne    40e495 <__swc_fn_0a4ed24b_000145_1534de9a+0x215>
  40e46f:	mov    rdi,rbx
  40e472:	mov    rsi,r15
  40e475:	xor    eax,eax
  40e477:	call   407160 <munmap@plt>
  40e47c:	movsxd rdi,DWORD PTR [r14]
  40e47f:	xor    eax,eax
  40e481:	call   407050 <close@plt>
  40e486:	mov    rcx,r13
  40e489:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40e48e:	xor    eax,eax
  40e490:	jmp    40e53b <__swc_fn_0a4ed24b_000145_1534de9a+0x2bb>
  40e495:	mov    edi,0x20
  40e49a:	xor    eax,eax
  40e49c:	call   4071c0 <malloc@plt>
  40e4a1:	test   rax,rax
  40e4a4:	jne    40e4c9 <__swc_fn_0a4ed24b_000145_1534de9a+0x249>
  40e4a6:	mov    rdi,rbx
  40e4a9:	mov    rsi,r15
  40e4ac:	xor    eax,eax
  40e4ae:	call   407160 <munmap@plt>
  40e4b3:	movsxd rdi,DWORD PTR [r14]
  40e4b6:	xor    eax,eax
  40e4b8:	call   407050 <close@plt>
  40e4bd:	mov    rcx,r13
  40e4c0:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40e4c5:	xor    eax,eax
  40e4c7:	jmp    40e53b <__swc_fn_0a4ed24b_000145_1534de9a+0x2bb>
  40e4c9:	mov    rcx,QWORD PTR [rip+0x188b8]        # 426d88 <__swc_bss_base_0a4ed24b+0x2d48>
  40e4d0:	mov    QWORD PTR [rsp+0x70],rcx
  40e4d5:	mov    rcx,QWORD PTR [rsp+0xa0]
  40e4dd:	mov    QWORD PTR [rsp+0x78],rcx
  40e4e2:	mov    QWORD PTR [rsp+0x80],r12
  40e4ea:	mov    rcx,QWORD PTR [rsp+0x50]
  40e4ef:	mov    QWORD PTR [rsp+0x88],rcx
  40e4f7:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  40e4fd:	vmovups XMMWORD PTR [rax],xmm0
  40e501:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  40e50a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e50f:	mov    QWORD PTR [rip+0x18872],rax        # 426d88 <__swc_bss_base_0a4ed24b+0x2d48>
  40e516:	mov    rax,QWORD PTR [rsp+0x50]
  40e51b:	mov    rbx,QWORD PTR [rsp+0x98]
  40e523:	mov    QWORD PTR [rbx],rax
  40e526:	movsxd rdi,DWORD PTR [r14]
  40e529:	xor    eax,eax
  40e52b:	call   407050 <close@plt>
  40e530:	mov    rcx,r13
  40e533:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40e538:	mov    rax,r12
  40e53b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40e544:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40e54d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40e556:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40e55f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40e568:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40e571:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40e57a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40e583:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40e58c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40e595:	add    rsp,0x150
  40e59c:	pop    r15
  40e59e:	pop    r14
  40e5a0:	pop    rsi
  40e5a1:	pop    rdi
  40e5a2:	pop    r13
  40e5a4:	pop    r12
  40e5a6:	pop    rbx
  40e5a7:	ret
	...

000000000040e5b0 <__swc_fn_0a4ed24b_000148_43c96957>:
  40e5b0:	push   rbx
  40e5b1:	sub    rsp,0xe0
  40e5b8:	lea    rbx,[rsp+0x8]
  40e5bd:	vxorps xmm0,xmm0,xmm0
  40e5c1:	vmovups YMMWORD PTR [rbx],ymm0
  40e5c5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40e5ca:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40e5cf:	vzeroupper
  40e5d2:	mov    DWORD PTR [rbx+0x60],0x0
  40e5d9:	mov    r8,rbx
  40e5dc:	nop    DWORD PTR [rax+0x0]
  40e5e0:	mov    r9,rcx
  40e5e3:	movabs rcx,0xcccccccccccccccd
  40e5ed:	mov    rax,r9
  40e5f0:	mul    rcx
  40e5f3:	mov    r10,rdx
  40e5f6:	shr    r10,0x3
  40e5fa:	mov    rcx,r10
  40e5fd:	imul   rdx,r10,0xa
  40e601:	sub    r9,rdx
  40e604:	mov    rdx,QWORD PTR [rip+0x51e5]        # 4137f0 <__swc_rdata_base_0a4ed24b+0x6e0>
  40e60b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  40e610:	mov    BYTE PTR [r8],dl
  40e613:	lea    rdx,[r8+0x1]
  40e617:	mov    r8,rdx
  40e61a:	test   r10,r10
  40e61d:	jne    40e5e0 <__swc_fn_0a4ed24b_000148_43c96957+0x30>
  40e61f:	mov    BYTE PTR [rdx],0x0
  40e622:	sub    r8,0x1
  40e626:	mov    rax,rbx
  40e629:	cmp    rax,r8
  40e62c:	jae    40e646 <__swc_fn_0a4ed24b_000148_43c96957+0x96>
  40e62e:	xchg   ax,ax
  40e630:	mov    cl,BYTE PTR [r8]
  40e633:	mov    dl,BYTE PTR [rax]
  40e635:	mov    BYTE PTR [r8],dl
  40e638:	sub    r8,0x1
  40e63c:	mov    BYTE PTR [rax],cl
  40e63e:	inc    rax
  40e641:	cmp    rax,r8
  40e644:	jb     40e630 <__swc_fn_0a4ed24b_000148_43c96957+0x80>
  40e646:	xor    eax,eax
  40e648:	test   rbx,rbx
  40e64b:	je     40e66e <__swc_fn_0a4ed24b_000148_43c96957+0xbe>
  40e64d:	mov    rcx,rbx
  40e650:	mov    dl,BYTE PTR [rcx]
  40e652:	test   dl,dl
  40e654:	je     40e66e <__swc_fn_0a4ed24b_000148_43c96957+0xbe>
  40e656:	cs nop WORD PTR [rax+rax*1+0x0]
  40e660:	add    rcx,0x1
  40e664:	add    rax,0x1
  40e668:	mov    dl,BYTE PTR [rcx]
  40e66a:	test   dl,dl
  40e66c:	jne    40e660 <__swc_fn_0a4ed24b_000148_43c96957+0xb0>
  40e66e:	mov    QWORD PTR [rbx+0xa8],rbx
  40e675:	mov    QWORD PTR [rbx+0xb0],rax
  40e67c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40e684:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40e68c:	lea    rcx,[rbx+0xb8]
  40e693:	call   4098b0 <__swc_fn_0a4ed24b_000120_2648f149>
  40e698:	add    rsp,0xe0
  40e69f:	pop    rbx
  40e6a0:	ret
	...

000000000040e6b0 <__swc_fn_0a4ed24b_000151_6fb05988>:
  40e6b0:	sub    rsp,0x8
  40e6b4:	mov    rax,QWORD PTR [rcx+0x8]
  40e6b8:	mov    r8,QWORD PTR [rdx+0x8]
  40e6bc:	cmp    rax,r8
  40e6bf:	je     40e6c8 <__swc_fn_0a4ed24b_000151_6fb05988+0x18>
  40e6c1:	xor    eax,eax
  40e6c3:	add    rsp,0x8
  40e6c7:	ret
  40e6c8:	test   rax,rax
  40e6cb:	jne    40e6dc <__swc_fn_0a4ed24b_000151_6fb05988+0x2c>
  40e6cd:	test   r8,r8
  40e6d0:	jne    40e6dc <__swc_fn_0a4ed24b_000151_6fb05988+0x2c>
  40e6d2:	mov    eax,0x1
  40e6d7:	add    rsp,0x8
  40e6db:	ret
  40e6dc:	mov    rcx,QWORD PTR [rcx]
  40e6df:	mov    rdx,QWORD PTR [rdx]
  40e6e2:	test   rcx,rcx
  40e6e5:	sete   r8b
  40e6e9:	test   rdx,rdx
  40e6ec:	sete   r9b
  40e6f0:	or     r8b,r9b
  40e6f3:	je     40e700 <__swc_fn_0a4ed24b_000151_6fb05988+0x50>
  40e6f5:	cmp    rcx,rdx
  40e6f8:	sete   al
  40e6fb:	add    rsp,0x8
  40e6ff:	ret
  40e700:	cmp    rcx,rdx
  40e703:	jne    40e70f <__swc_fn_0a4ed24b_000151_6fb05988+0x5f>
  40e705:	mov    eax,0x1
  40e70a:	add    rsp,0x8
  40e70e:	ret
  40e70f:	mov    r8,rax
  40e712:	call   410fc0 <__swc_fn_0a4ed24b_000110_3dc01326>
  40e717:	test   eax,eax
  40e719:	sete   al
  40e71c:	add    rsp,0x8
  40e720:	ret
	...

000000000040e730 <__swc_fn_0a4ed24b_000154_86f1d437>:
  40e730:	vxorps xmm0,xmm0,xmm0
  40e734:	vmovups XMMWORD PTR [rcx],xmm0
  40e738:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e73d:	vxorps xmm0,xmm0,xmm0
  40e741:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e746:	vmovups xmm0,XMMWORD PTR [rip+0x5142]        # 413890 <__swc_rdata_base_0a4ed24b+0x780>
  40e74e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e753:	ret
	...

000000000040e760 <__swc_fn_0a4ed24b_000157_86f1d437>:
  40e760:	vxorps xmm0,xmm0,xmm0
  40e764:	vmovups XMMWORD PTR [rcx],xmm0
  40e768:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e76d:	vxorps xmm0,xmm0,xmm0
  40e771:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e776:	vmovups xmm0,XMMWORD PTR [rip+0x5232]        # 4139b0 <__swc_rdata_base_0a4ed24b+0x8a0>
  40e77e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e783:	mov    QWORD PTR [rcx+0x40],0x0
  40e78b:	ret
  40e78c:	add    BYTE PTR [rax],al
	...

000000000040e790 <__swc_fn_0a4ed24b_000160_47b270e1>:
  40e790:	push   rbx
  40e791:	sub    rsp,0x70
  40e795:	mov    rax,QWORD PTR [rcx]
  40e798:	mov    rbx,QWORD PTR [rcx+0x8]
  40e79c:	vxorps xmm0,xmm0,xmm0
  40e7a0:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40e7a6:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40e7ac:	vzeroupper
  40e7af:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40e7b5:	mov    QWORD PTR [rsp+0x48],rdx
  40e7ba:	mov    QWORD PTR [rsp+0x50],r8
  40e7bf:	mov    rcx,rax
  40e7c2:	lea    rdx,[rsp+0x8]
  40e7c7:	mov    rbx,QWORD PTR [rbx+0x18]
  40e7cb:	call   rbx
  40e7cd:	add    rsp,0x70
  40e7d1:	pop    rbx
  40e7d2:	ret
	...

000000000040e7e0 <__swc_fn_0a4ed24b_000163_8a3d304f>:
  40e7e0:	push   rbx
  40e7e1:	push   rsi
  40e7e2:	push   rdi
  40e7e3:	mov    rbx,r8
  40e7e6:	mov    rsi,rcx
  40e7e9:	mov    rdi,rdx
  40e7ec:	call   411cd0 <__swc_fn_0a4ed24b_000161_13ead2ff>
  40e7f1:	vmovups xmm0,XMMWORD PTR [rbx]
  40e7f5:	vmovups XMMWORD PTR [rsi],xmm0
  40e7f9:	mov    QWORD PTR [rsi+0x18],rdi
  40e7fd:	pop    rdi
  40e7fe:	pop    rsi
  40e7ff:	pop    rbx
  40e800:	ret
	...

000000000040e810 <__swc_fn_0a4ed24b_000166_cc119975>:
  40e810:	push   rbx
  40e811:	push   rsi
  40e812:	push   rdi
  40e813:	push   r12
  40e815:	push   r13
  40e817:	sub    rsp,0x50
  40e81b:	mov    rbx,rcx
  40e81e:	mov    rsi,rdx
  40e821:	vmovups xmm0,XMMWORD PTR [rip+0x5297]        # 413ac0 <__swc_rdata_base_0a4ed24b+0x9b0>
  40e829:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e82f:	vmovups xmm0,XMMWORD PTR [rip+0x5299]        # 413ad0 <__swc_rdata_base_0a4ed24b+0x9c0>
  40e837:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e83d:	vxorps xmm0,xmm0,xmm0
  40e841:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e847:	mov    rcx,rdx
  40e84a:	call   40e1b0 <__swc_fn_0a4ed24b_000142_be4c2719>
  40e84f:	mov    rdi,rax
  40e852:	test   rax,rax
  40e855:	jne    40e886 <__swc_fn_0a4ed24b_000166_cc119975+0x76>
  40e857:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e85d:	vmovups XMMWORD PTR [rbx],xmm0
  40e861:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e867:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e86c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e872:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e877:	mov    rax,rbx
  40e87a:	add    rsp,0x50
  40e87e:	pop    r13
  40e880:	pop    r12
  40e882:	pop    rdi
  40e883:	pop    rsi
  40e884:	pop    rbx
  40e885:	ret
  40e886:	mov    rcx,rdi
  40e889:	call   40b360 <__swc_fn_0a4ed24b_000165_016ee66a>
  40e88e:	mov    r11,rax
  40e891:	test   rax,rax
  40e894:	je     40e89e <__swc_fn_0a4ed24b_000166_cc119975+0x8e>
  40e896:	mov    al,BYTE PTR [r11+0x24]
  40e89a:	test   al,al
  40e89c:	jne    40e8cd <__swc_fn_0a4ed24b_000166_cc119975+0xbd>
  40e89e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e8a4:	vmovups XMMWORD PTR [rbx],xmm0
  40e8a8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e8ae:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e8b3:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e8b9:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e8be:	mov    rax,rbx
  40e8c1:	add    rsp,0x50
  40e8c5:	pop    r13
  40e8c7:	pop    r12
  40e8c9:	pop    rdi
  40e8ca:	pop    rsi
  40e8cb:	pop    rbx
  40e8cc:	ret
  40e8cd:	sub    rsi,rdi
  40e8d0:	mov    eax,0xffffffff
  40e8d5:	cmp    rsi,rax
  40e8d8:	jbe    40e909 <__swc_fn_0a4ed24b_000166_cc119975+0xf9>
  40e8da:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e8e0:	vmovups XMMWORD PTR [rbx],xmm0
  40e8e4:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e8ea:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e8ef:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e8f5:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e8fa:	mov    rax,rbx
  40e8fd:	add    rsp,0x50
  40e901:	pop    r13
  40e903:	pop    r12
  40e905:	pop    rdi
  40e906:	pop    rsi
  40e907:	pop    rbx
  40e908:	ret
  40e909:	mov    rdi,QWORD PTR [r11+0x10]
  40e90d:	mov    eax,DWORD PTR [r11+0x20]
  40e911:	xor    ecx,ecx
  40e913:	test   rax,rax
  40e916:	jbe    40ea68 <__swc_fn_0a4ed24b_000166_cc119975+0x258>
  40e91c:	nop    DWORD PTR [rax+0x0]
  40e920:	mov    edx,ecx
  40e922:	imul   r12,rdx,0x14
  40e926:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40e92b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40e930:	mov    r9d,esi
  40e933:	cmp    r9,rdx
  40e936:	jb     40ea5b <__swc_fn_0a4ed24b_000166_cc119975+0x24b>
  40e93c:	add    rdx,r8
  40e93f:	mov    r8d,esi
  40e942:	cmp    r8,rdx
  40e945:	jae    40ea5b <__swc_fn_0a4ed24b_000166_cc119975+0x24b>
  40e94b:	lea    rsi,[rsp+0x38]
  40e950:	mov    eax,DWORD PTR [rdi+0xc]
  40e953:	mov    DWORD PTR [rsp+0x38],eax
  40e957:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40e95c:	mov    rcx,rdi
  40e95f:	mov    rdx,QWORD PTR [r11+0x18]
  40e963:	mov    r8,rsi
  40e966:	mov    r8d,DWORD PTR [r8]
  40e969:	mov    r9,rax
  40e96c:	lea    r10,[rsp+0x10]
  40e971:	call   411d20 <__swc_fn_0a4ed24b_000164_72795826>
  40e976:	test   al,al
  40e978:	jne    40e9ab <__swc_fn_0a4ed24b_000166_cc119975+0x19b>
  40e97a:	vmovups xmm0,XMMWORD PTR [rip+0x516e]        # 413af0 <__swc_rdata_base_0a4ed24b+0x9e0>
  40e982:	vmovups XMMWORD PTR [rbx],xmm0
  40e986:	vmovups xmm0,XMMWORD PTR [rip+0x5172]        # 413b00 <__swc_rdata_base_0a4ed24b+0x9f0>
  40e98e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e993:	vxorps xmm0,xmm0,xmm0
  40e997:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e99c:	mov    rax,rbx
  40e99f:	add    rsp,0x50
  40e9a3:	pop    r13
  40e9a5:	pop    r12
  40e9a7:	pop    rdi
  40e9a8:	pop    rsi
  40e9a9:	pop    rbx
  40e9aa:	ret
  40e9ab:	lea    r13,[rsp+0x3c]
  40e9b0:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40e9b5:	mov    DWORD PTR [rsp+0x3c],eax
  40e9b9:	test   eax,eax
  40e9bb:	je     40ea0c <__swc_fn_0a4ed24b_000166_cc119975+0x1fc>
  40e9bd:	mov    rcx,rdi
  40e9c0:	mov    rdx,QWORD PTR [r11+0x18]
  40e9c4:	mov    r8d,DWORD PTR [rsi]
  40e9c7:	mov    rax,r13
  40e9ca:	mov    r9d,DWORD PTR [rax]
  40e9cd:	lea    r10,[rsp+0x20]
  40e9d2:	call   411d20 <__swc_fn_0a4ed24b_000164_72795826>
  40e9d7:	test   al,al
  40e9d9:	jne    40ea0c <__swc_fn_0a4ed24b_000166_cc119975+0x1fc>
  40e9db:	vmovups xmm0,XMMWORD PTR [rip+0x513d]        # 413b20 <__swc_rdata_base_0a4ed24b+0xa10>
  40e9e3:	vmovups XMMWORD PTR [rbx],xmm0
  40e9e7:	vmovups xmm0,XMMWORD PTR [rip+0x5141]        # 413b30 <__swc_rdata_base_0a4ed24b+0xa20>
  40e9ef:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e9f4:	vxorps xmm0,xmm0,xmm0
  40e9f8:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e9fd:	mov    rax,rbx
  40ea00:	add    rsp,0x50
  40ea04:	pop    r13
  40ea06:	pop    r12
  40ea08:	pop    rdi
  40ea09:	pop    rsi
  40ea0a:	pop    rbx
  40ea0b:	ret
  40ea0c:	mov    eax,0x1
  40ea11:	rex mov BYTE PTR [rsp+0x8],al
  40ea16:	cmp    DWORD PTR [r13+0x0],0x0
  40ea1b:	je     40ea2c <__swc_fn_0a4ed24b_000166_cc119975+0x21c>
  40ea1d:	rex mov BYTE PTR [rsp+0x9],0x1
  40ea23:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40ea28:	mov    DWORD PTR [rsp+0x30],eax
  40ea2c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ea32:	vmovups XMMWORD PTR [rbx],xmm0
  40ea36:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40ea3c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ea41:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40ea47:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ea4c:	mov    rax,rbx
  40ea4f:	add    rsp,0x50
  40ea53:	pop    r13
  40ea55:	pop    r12
  40ea57:	pop    rdi
  40ea58:	pop    rsi
  40ea59:	pop    rbx
  40ea5a:	ret
  40ea5b:	add    rcx,0x1
  40ea5f:	cmp    rcx,rax
  40ea62:	jb     40e920 <__swc_fn_0a4ed24b_000166_cc119975+0x110>
  40ea68:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ea6e:	vmovups XMMWORD PTR [rbx],xmm0
  40ea72:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40ea78:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ea7d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40ea83:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ea88:	mov    rax,rbx
  40ea8b:	add    rsp,0x50
  40ea8f:	pop    r13
  40ea91:	pop    r12
  40ea93:	pop    rdi
  40ea94:	pop    rsi
  40ea95:	pop    rbx
  40ea96:	ret
	...

000000000040eaa0 <__swc_fn_0a4ed24b_000169_994c8876>:
  40eaa0:	sub    rsp,0x48
  40eaa4:	call   40de80 <__swc_fn_0a4ed24b_000127_58f0f391>
  40eaa9:	cmp    rax,0xffffffffffffffff
  40eaad:	je     40eab4 <__swc_fn_0a4ed24b_000169_994c8876+0x14>
  40eaaf:	add    rsp,0x48
  40eab3:	ret
  40eab4:	lea    rcx,[rip+0x50a5]        # 413b60 <__swc_rdata_base_0a4ed24b+0xa50>
  40eabb:	vmovups xmm0,XMMWORD PTR [rip+0x50ad]        # 413b70 <__swc_rdata_base_0a4ed24b+0xa60>
  40eac3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40eac9:	vmovups xmm0,XMMWORD PTR [rip+0x50af]        # 413b80 <__swc_rdata_base_0a4ed24b+0xa70>
  40ead1:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40ead7:	vmovups xmm0,XMMWORD PTR [rip+0x50b1]        # 413b90 <__swc_rdata_base_0a4ed24b+0xa80>
  40eadf:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40eae5:	lea    rdx,[rsp+0x8]
  40eaea:	mov    QWORD PTR [rsp+0x38],rax
  40eaef:	call   410f00 <__swc_fn_0a4ed24b_000107_90faaa26>
  40eaf4:	mov    rax,QWORD PTR [rsp+0x38]
  40eaf9:	jmp    40eaaf <__swc_fn_0a4ed24b_000169_994c8876+0xf>
  40eafb:	add    BYTE PTR [rax],al
  40eafd:	add    BYTE PTR [rax],al
	...

000000000040eb00 <__swc_fn_0a4ed24b_000172_cbeff767>:
  40eb00:	push   rbx
  40eb01:	push   rsi
  40eb02:	sub    rsp,0x28
  40eb06:	mov    rbx,rcx
  40eb09:	mov    DWORD PTR [rsp+0x8],0xbf0
  40eb11:	mov    ecx,0xbf0
  40eb16:	call   410af0 <__swc_fn_0a4ed24b_000083_4a10c7e7>
  40eb1b:	mov    rsi,rax
  40eb1e:	test   rax,rax
  40eb21:	jne    40eb2c <__swc_fn_0a4ed24b_000172_cbeff767+0x2c>
  40eb23:	xor    eax,eax
  40eb25:	add    rsp,0x28
  40eb29:	pop    rsi
  40eb2a:	pop    rbx
  40eb2b:	ret
  40eb2c:	vxorps xmm0,xmm0,xmm0
  40eb30:	xor    eax,eax
  40eb32:	cs nop WORD PTR [rax+rax*1+0x0]
  40eb3c:	nop    DWORD PTR [rax+0x0]
  40eb40:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40eb45:	add    rax,0x10
  40eb49:	cmp    rax,0xbf0
  40eb50:	jne    40eb40 <__swc_fn_0a4ed24b_000172_cbeff767+0x40>
  40eb52:	lea    rax,[rbx+0x1]
  40eb56:	mov    QWORD PTR [rsi+0x9c0],rax
  40eb5d:	mov    rcx,rbx
  40eb60:	mov    rdx,rsi
  40eb63:	call   412080 <__swc_fn_0a4ed24b_000170_646fdf20>
  40eb68:	test   al,al
  40eb6a:	jne    40eb7d <__swc_fn_0a4ed24b_000172_cbeff767+0x7d>
  40eb6c:	mov    rcx,rsi
  40eb6f:	call   408830 <__swc_fn_0a4ed24b_000084_cf82995a>
  40eb74:	xor    eax,eax
  40eb76:	add    rsp,0x28
  40eb7a:	pop    rsi
  40eb7b:	pop    rbx
  40eb7c:	ret
  40eb7d:	lea    rcx,[rsp+0x18]
  40eb82:	call   408db0 <__swc_fn_0a4ed24b_000096_93bfe675>
  40eb87:	mov    rax,rsi
  40eb8a:	add    rsp,0x28
  40eb8e:	pop    rsi
  40eb8f:	pop    rbx
  40eb90:	ret
	...

000000000040eba0 <__swc_fn_0a4ed24b_000175_e09f8b62>:
  40eba0:	xor    eax,eax
  40eba2:	mov    edx,0x1
  40eba7:	lock cmpxchg QWORD PTR [rcx],rdx
  40ebac:	test   rax,rax
  40ebaf:	jne    40ebb2 <__swc_fn_0a4ed24b_000175_e09f8b62+0x12>
  40ebb1:	ret
  40ebb2:	cs nop WORD PTR [rax+rax*1+0x0]
  40ebbc:	nop    DWORD PTR [rax+0x0]
  40ebc0:	mov    rax,QWORD PTR [rcx]
  40ebc3:	test   rax,rax
  40ebc6:	je     40eba0 <__swc_fn_0a4ed24b_000175_e09f8b62>
  40ebc8:	jmp    40ebc0 <__swc_fn_0a4ed24b_000175_e09f8b62+0x20>
  40ebca:	add    BYTE PTR [rax],al
  40ebcc:	add    BYTE PTR [rax],al
	...

000000000040ebd0 <__swc_fn_0a4ed24b_000178_718d7b54>:
  40ebd0:	push   rsi
  40ebd1:	push   rdi
  40ebd2:	sub    rsp,0x38
  40ebd6:	mov    rsi,rcx
  40ebd9:	call   412090 <__swc_fn_0a4ed24b_000173_1e0ea8cf>
  40ebde:	mov    rdi,rax
  40ebe1:	call   411820 <__swc_fn_0a4ed24b_000134_a9c1c700>
  40ebe6:	mov    r8,rax
  40ebe9:	mov    rcx,rdi
  40ebec:	call   40eba0 <__swc_fn_0a4ed24b_000175_e09f8b62>
  40ebf1:	mov    rax,QWORD PTR [rdi+0x8]
  40ebf5:	test   rax,rax
  40ebf8:	je     40ec35 <__swc_fn_0a4ed24b_000178_718d7b54+0x65>
  40ebfa:	nop    WORD PTR [rax+rax*1+0x0]
  40ec00:	cmp    rax,rsi
  40ec03:	je     40ec35 <__swc_fn_0a4ed24b_000178_718d7b54+0x65>
  40ec05:	mov    r9,QWORD PTR [rax]
  40ec08:	cmp    QWORD PTR [rax+0x20],r8
  40ec0c:	jne    40ec2d <__swc_fn_0a4ed24b_000178_718d7b54+0x5d>
  40ec0e:	mov    rcx,rdi
  40ec11:	mov    rdx,rax
  40ec14:	mov    QWORD PTR [rsp+0x28],r8
  40ec19:	mov    QWORD PTR [rsp+0x30],r9
  40ec1e:	call   40b780 <__swc_fn_0a4ed24b_000177_cf4ffedd>
  40ec23:	mov    r8,QWORD PTR [rsp+0x28]
  40ec28:	mov    r9,QWORD PTR [rsp+0x30]
  40ec2d:	mov    rax,r9
  40ec30:	test   r9,r9
  40ec33:	jne    40ec00 <__swc_fn_0a4ed24b_000178_718d7b54+0x30>
  40ec35:	xor    eax,eax
  40ec37:	mov    QWORD PTR [rdi],rax
  40ec3a:	add    rsp,0x38
  40ec3e:	pop    rdi
  40ec3f:	pop    rsi
  40ec40:	ret
	...

000000000040ec60 <__swc_fn_0a4ed24b_000002_3634f827>:
  40ec60:	sub    rsp,0x168
  40ec67:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40ec70:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40ec79:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40ec82:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40ec8b:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40ec94:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40ec9d:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40eca6:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40ecaf:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40ecb8:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40ecc1:	vmovups xmm6,xmm5
  40ecc5:	vmovups xmm7,xmm0
  40ecc9:	vmovups xmm8,xmm1
  40eccd:	vmovups xmm9,xmm2
  40ecd1:	vmovups xmm10,xmm3
  40ecd5:	vmovups xmm11,xmm4
  40ecd9:	vmovsd xmm0,QWORD PTR [rip+0x45b7]        # 413298 <__swc_rdata_base_0a4ed24b+0x188>
  40ece1:	vmovsd QWORD PTR [rsp],xmm0
  40ece6:	vmovups xmm0,xmm7
  40ecea:	call   40b800 <__swc_fn_0a4ed24b_000001_0d61c738>
  40ecef:	mov    eax,DWORD PTR [rip+0x1330b]        # 422000 <__swc_data_base_0a4ed24b>
  40ecf5:	test   eax,eax
  40ecf7:	jge    40ed2e <__swc_fn_0a4ed24b_000002_3634f827+0xce>
  40ecf9:	vmovsd xmm0,QWORD PTR [rip+0x45a0]        # 4132a1 <__swc_rdata_base_0a4ed24b+0x191>
  40ed01:	vmovsd QWORD PTR [rip+0x1533f],xmm0        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  40ed09:	vmovsd xmm0,QWORD PTR [rip+0x4599]        # 4132aa <__swc_rdata_base_0a4ed24b+0x19a>
  40ed11:	vmovsd QWORD PTR [rip+0x15337],xmm0        # 424050 <__swc_bss_base_0a4ed24b+0x10>
  40ed19:	vmovsd xmm0,QWORD PTR [rip+0x4592]        # 4132b3 <__swc_rdata_base_0a4ed24b+0x1a3>
  40ed21:	vmovsd QWORD PTR [rip+0x1532f],xmm0        # 424058 <__swc_bss_base_0a4ed24b+0x18>
  40ed29:	jmp    40ef20 <__swc_fn_0a4ed24b_000002_3634f827+0x2c0>
  40ed2e:	vmovsd xmm0,QWORD PTR [rip+0x1530a]        # 424040 <__swc_bss_base_0a4ed24b>
  40ed36:	movsxd rdx,eax
  40ed39:	vfmadd231sd xmm7,xmm10,xmm0
  40ed3e:	vfmadd231sd xmm8,xmm11,xmm0
  40ed43:	vfmadd231sd xmm9,xmm6,xmm0
  40ed48:	vmovsd QWORD PTR [rsp+0xb8],xmm9
  40ed51:	vmovsd xmm12,QWORD PTR [rip+0x43f2]        # 41314b <__swc_rdata_base_0a4ed24b+0x3b>
  40ed59:	lea    rax,[rip+0x4438]        # 413198 <__swc_rdata_base_0a4ed24b+0x88>
  40ed60:	vdivsd xmm0,xmm12,QWORD PTR [rax+rdx*8]
  40ed65:	lea    rax,[rip+0x444c]        # 4131b8 <__swc_rdata_base_0a4ed24b+0xa8>
  40ed6c:	vsubsd xmm1,xmm7,QWORD PTR [rax+rdx*8]
  40ed71:	vmulsd xmm13,xmm1,xmm0
  40ed75:	lea    rax,[rip+0x445c]        # 4131d8 <__swc_rdata_base_0a4ed24b+0xc8>
  40ed7c:	vsubsd xmm1,xmm8,QWORD PTR [rax+rdx*8]
  40ed81:	vmulsd xmm14,xmm1,xmm0
  40ed85:	lea    rax,[rip+0x446c]        # 4131f8 <__swc_rdata_base_0a4ed24b+0xe8>
  40ed8c:	vsubsd xmm1,xmm9,QWORD PTR [rax+rdx*8]
  40ed91:	vmulsd xmm15,xmm1,xmm0
  40ed95:	vmovsd xmm0,QWORD PTR [rip+0x451f]        # 4132bc <__swc_rdata_base_0a4ed24b+0x1ac>
  40ed9d:	vsubsd xmm3,xmm0,xmm7
  40eda1:	vsubsd xmm4,xmm0,xmm8
  40eda6:	vmovsd xmm0,QWORD PTR [rip+0x4517]        # 4132c5 <__swc_rdata_base_0a4ed24b+0x1b5>
  40edae:	vsubsd xmm5,xmm0,xmm9
  40edb3:	vmulsd xmm0,xmm3,xmm3
  40edb7:	vfmadd231sd xmm0,xmm4,xmm4
  40edbc:	vfmadd231sd xmm0,xmm5,xmm5
  40edc1:	vsqrtsd xmm0,xmm0,xmm0
  40edc5:	vdivsd xmm0,xmm12,xmm0
  40edc9:	vmulsd xmm3,xmm3,xmm0
  40edcd:	vmulsd xmm4,xmm4,xmm0
  40edd1:	vmulsd xmm5,xmm5,xmm0
  40edd5:	vmulsd xmm0,xmm13,xmm3
  40edd9:	vfmadd231sd xmm0,xmm14,xmm4
  40edde:	vmulsd xmm1,xmm15,xmm5
  40ede2:	vaddsd xmm2,xmm0,xmm1
  40ede6:	vxorpd xmm0,xmm0,xmm0
  40edea:	vcomisd xmm0,xmm2
  40edee:	jbe    40edf7 <__swc_fn_0a4ed24b_000002_3634f827+0x197>
  40edf0:	vxorpd xmm12,xmm12,xmm12
  40edf5:	jmp    40ee33 <__swc_fn_0a4ed24b_000002_3634f827+0x1d3>
  40edf7:	vmovsd xmm0,QWORD PTR [rip+0x44cf]        # 4132ce <__swc_rdata_base_0a4ed24b+0x1be>
  40edff:	vmovsd QWORD PTR [rsp],xmm0
  40ee04:	vmovups xmm0,xmm7
  40ee08:	vmovups xmm1,xmm8
  40ee0d:	vmovsd QWORD PTR [rsp+0xc0],xmm2
  40ee16:	vmovups xmm12,xmm2
  40ee1a:	vmovups xmm2,xmm9
  40ee1f:	call   40b800 <__swc_fn_0a4ed24b_000001_0d61c738>
  40ee24:	mov    eax,DWORD PTR [rip+0x131d6]        # 422000 <__swc_data_base_0a4ed24b>
  40ee2a:	test   eax,eax
  40ee2c:	jl     40ee33 <__swc_fn_0a4ed24b_000002_3634f827+0x1d3>
  40ee2e:	vxorpd xmm12,xmm12,xmm12
  40ee33:	vmulsd xmm0,xmm12,QWORD PTR [rip+0x449c]        # 4132d7 <__swc_rdata_base_0a4ed24b+0x1c7>
  40ee3b:	vaddsd xmm0,xmm0,QWORD PTR [rip+0x4470]        # 4132b3 <__swc_rdata_base_0a4ed24b+0x1a3>
  40ee43:	lea    rax,[rip+0x43ce]        # 413218 <__swc_rdata_base_0a4ed24b+0x108>
  40ee4a:	vmulsd xmm9,xmm0,QWORD PTR [rax+rdx*8]
  40ee4f:	lea    rax,[rip+0x43e2]        # 413238 <__swc_rdata_base_0a4ed24b+0x128>
  40ee56:	vmulsd xmm12,xmm0,QWORD PTR [rax+rdx*8]
  40ee5b:	lea    rax,[rip+0x43f6]        # 413258 <__swc_rdata_base_0a4ed24b+0x148>
  40ee62:	vmulsd xmm5,xmm0,QWORD PTR [rax+rdx*8]
  40ee67:	lea    rax,[rip+0x440a]        # 413278 <__swc_rdata_base_0a4ed24b+0x168>
  40ee6e:	vmovq  xmm4,QWORD PTR [rax+rdx*8]
  40ee73:	cmp    ecx,0x2
  40ee76:	jl     40ee81 <__swc_fn_0a4ed24b_000002_3634f827+0x221>
  40ee78:	vmovups xmm8,xmm5
  40ee7c:	jmp    40ef08 <__swc_fn_0a4ed24b_000002_3634f827+0x2a8>
  40ee81:	vmulsd xmm0,xmm10,xmm13
  40ee86:	vfmadd231sd xmm0,xmm11,xmm14
  40ee8b:	vfmadd231sd xmm0,xmm6,xmm15
  40ee90:	vaddsd xmm0,xmm0,xmm0
  40ee94:	vmulsd xmm1,xmm0,xmm13
  40ee99:	vsubsd xmm3,xmm10,xmm1
  40ee9d:	vmulsd xmm1,xmm0,xmm14
  40eea2:	vsubsd xmm10,xmm11,xmm1
  40eea6:	vfnmadd231sd xmm6,xmm0,xmm15
  40eeab:	vmovups xmm0,xmm7
  40eeaf:	vmovups xmm1,xmm8
  40eeb4:	vmovsd xmm2,QWORD PTR [rsp+0xb8]
  40eebd:	vmovups xmm7,xmm4
  40eec1:	vmovups xmm4,xmm10
  40eec6:	vmovups xmm8,xmm5
  40eeca:	vmovups xmm5,xmm6
  40eece:	inc    ecx
  40eed0:	call   40ec60 <__swc_fn_0a4ed24b_000002_3634f827>
  40eed5:	vmovsd xmm0,QWORD PTR [rip+0x426e]        # 41314b <__swc_rdata_base_0a4ed24b+0x3b>
  40eedd:	vsubsd xmm0,xmm0,xmm7
  40eee1:	vmulsd xmm2,xmm7,QWORD PTR [rip+0x1515f]        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  40eee9:	vfmadd213sd xmm9,xmm0,xmm2
  40eeee:	vmulsd xmm2,xmm7,QWORD PTR [rip+0x1515a]        # 424050 <__swc_bss_base_0a4ed24b+0x10>
  40eef6:	vfmadd213sd xmm12,xmm0,xmm2
  40eefb:	vmulsd xmm1,xmm7,QWORD PTR [rip+0x15155]        # 424058 <__swc_bss_base_0a4ed24b+0x18>
  40ef03:	vfmadd213sd xmm8,xmm0,xmm1
  40ef08:	vmovsd QWORD PTR [rip+0x15138],xmm9        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  40ef10:	vmovsd QWORD PTR [rip+0x15138],xmm12        # 424050 <__swc_bss_base_0a4ed24b+0x10>
  40ef18:	vmovsd QWORD PTR [rip+0x15138],xmm8        # 424058 <__swc_bss_base_0a4ed24b+0x18>
  40ef20:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40ef29:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40ef32:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40ef3b:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40ef44:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  40ef4d:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40ef56:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  40ef5f:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40ef68:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  40ef71:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  40ef7a:	add    rsp,0x168
  40ef81:	ret
	...

000000000040efa0 <__swc_fn_0a4ed24b_000005_9ee35b18>:
  40efa0:	vxorps xmm0,xmm0,xmm0
  40efa4:	xor    eax,eax
  40efa6:	cs nop WORD PTR [rax+rax*1+0x0]
  40efb0:	cs nop WORD PTR [rax+rax*1+0x0]
  40efba:	nop    WORD PTR [rax+rax*1+0x0]
  40efc0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40efc5:	add    rax,0x10
  40efc9:	cmp    rax,0x2080
  40efd0:	jne    40efc0 <__swc_fn_0a4ed24b_000005_9ee35b18+0x20>
  40efd2:	ret
	...

000000000040efe0 <__swc_fn_0a4ed24b_000008_d64b2baa>:
  40efe0:	push   rsi
  40efe1:	push   rdi
  40efe2:	push   r12
  40efe4:	push   r13
  40efe6:	push   r14
  40efe8:	mov    rsi,rcx
  40efeb:	mov    edi,r10d
  40efee:	mov    r12,rcx
  40eff1:	mov    r13,r9
  40eff4:	mov    ecx,DWORD PTR [rdx+0x28]
  40eff7:	shlx   r14d,r8d,ecx
  40effc:	mov    rcx,rdx
  40efff:	mov    edx,r8d
  40f002:	call   407700 <__swc_fn_0a4ed24b_000015_9dea5065>
  40f007:	mov    rcx,rax
  40f00a:	mov    eax,DWORD PTR [r12+0x3c]
  40f00f:	xor    edx,edx
  40f011:	div    rdi
  40f014:	vxorps xmm0,xmm0,xmm0
  40f018:	vmovdqu XMMWORD PTR [rsi],xmm0
  40f01c:	mov    QWORD PTR [r12+0x60],0x0
  40f025:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40f02a:	mov    QWORD PTR [r12+0x10],rcx
  40f02f:	imul   rax,rdi
  40f033:	lea    rdx,[rcx+rax*1]
  40f037:	mov    QWORD PTR [r12+0x18],rdx
  40f03c:	mov    QWORD PTR [r12+0x20],rcx
  40f041:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40f046:	mov    DWORD PTR [r12+0x28],0x0
  40f04f:	mov    DWORD PTR [r12+0x68],0x0
  40f058:	mov    BYTE PTR [r12+0x39],r13b
  40f05d:	mov    BYTE PTR [r12+0x3a],r14b
  40f062:	mov    BYTE PTR [r12+0x3b],0x1
  40f068:	mov    DWORD PTR [r12+0x6c],0x0
  40f071:	mov    rcx,r12
  40f074:	mov    edx,edi
  40f076:	call   407660 <__swc_fn_0a4ed24b_000009_065ed5b1>
  40f07b:	pop    r14
  40f07d:	pop    r13
  40f07f:	pop    r12
  40f081:	pop    rdi
  40f082:	pop    rsi
  40f083:	ret
	...

000000000040f090 <__swc_fn_0a4ed24b_000011_c3647f66>:
  40f090:	mov    r8d,0x1
  40f096:	xor    eax,eax
  40f098:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40f09e:	test   eax,eax
  40f0a0:	jne    40f090 <__swc_fn_0a4ed24b_000011_c3647f66>
  40f0a2:	ret
	...

000000000040f0b0 <__swc_fn_0a4ed24b_000014_524c1f23>:
  40f0b0:	lea    r8,[rcx+0x60]
  40f0b4:	mov    rax,QWORD PTR [r8]
  40f0b7:	mov    r9,rax
  40f0ba:	nop    WORD PTR [rax+rax*1+0x0]
  40f0c0:	mov    QWORD PTR [rdx],r9
  40f0c3:	mov    rax,r9
  40f0c6:	lock cmpxchg QWORD PTR [r8],rdx
  40f0cb:	cmp    rax,r9
  40f0ce:	jne    40f137 <__swc_fn_0a4ed24b_000014_524c1f23+0x87>
  40f0d0:	mov    eax,DWORD PTR [rcx+0x6c]
  40f0d3:	test   eax,eax
  40f0d5:	je     40f136 <__swc_fn_0a4ed24b_000014_524c1f23+0x86>
  40f0d7:	lea    rdx,[rcx+0x70]
  40f0db:	mov    r9d,0x1
  40f0e1:	xor    eax,eax
  40f0e3:	lock cmpxchg DWORD PTR [rdx],r9d
  40f0e8:	test   eax,eax
  40f0ea:	jne    40f136 <__swc_fn_0a4ed24b_000014_524c1f23+0x86>
  40f0ec:	mov    rax,rcx
  40f0ef:	and    rax,0xffffffffffc00000
  40f0f6:	mov    rax,QWORD PTR [rax+0x8]
  40f0fa:	test   rax,rax
  40f0fd:	jne    40f105 <__swc_fn_0a4ed24b_000014_524c1f23+0x55>
  40f0ff:	xor    eax,eax
  40f101:	xchg   DWORD PTR [rdx],eax
  40f103:	jmp    40f136 <__swc_fn_0a4ed24b_000014_524c1f23+0x86>
  40f105:	lea    rdx,[rax+0x2a80]
  40f10c:	mov    rax,QWORD PTR [rdx]
  40f10f:	mov    r8,rax
  40f112:	cs nop WORD PTR [rax+rax*1+0x0]
  40f11c:	nop    DWORD PTR [rax+0x0]
  40f120:	mov    QWORD PTR [rcx+0x78],r8
  40f124:	mov    rax,r8
  40f127:	lock cmpxchg QWORD PTR [rdx],rcx
  40f12c:	cmp    rax,r8
  40f12f:	je     40f136 <__swc_fn_0a4ed24b_000014_524c1f23+0x86>
  40f131:	mov    r8,rax
  40f134:	jmp    40f120 <__swc_fn_0a4ed24b_000014_524c1f23+0x70>
  40f136:	ret
  40f137:	mov    r9,rax
  40f13a:	jmp    40f0c0 <__swc_fn_0a4ed24b_000014_524c1f23+0x10>
	...

000000000040f140 <__swc_fn_0a4ed24b_000017_efc44797>:
  40f140:	push   rsi
  40f141:	push   rdi
  40f142:	push   r12
  40f144:	push   r13
  40f146:	push   r14
  40f148:	push   r15
  40f14a:	push   rbx
  40f14b:	sub    rsp,0x30
  40f14f:	mov    QWORD PTR [rsp+0x18],r8
  40f154:	mov    rsi,rcx
  40f157:	mov    rdi,rdx
  40f15a:	mov    rdx,QWORD PTR [rsi+0x40]
  40f15e:	xchg   ax,ax
  40f160:	mov    rax,rdx
  40f163:	not    rax
  40f166:	and    rax,QWORD PTR [rsi+0x20]
  40f16a:	test   rax,rax
  40f16d:	jne    40f181 <__swc_fn_0a4ed24b_000017_efc44797+0x41>
  40f16f:	xor    eax,eax
  40f171:	add    rsp,0x30
  40f175:	pop    rbx
  40f176:	pop    r15
  40f178:	pop    r14
  40f17a:	pop    r13
  40f17c:	pop    r12
  40f17e:	pop    rdi
  40f17f:	pop    rsi
  40f180:	ret
  40f181:	xor    ecx,ecx
  40f183:	tzcnt  rcx,rax
  40f188:	lea    r12,[rsp+0x8]
  40f18d:	mov    DWORD PTR [rsp+0x8],ecx
  40f191:	mov    r13d,0x1
  40f197:	shl    r13,cl
  40f19a:	mov    rcx,rdx
  40f19d:	or     rcx,r13
  40f1a0:	mov    rax,rdx
  40f1a3:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40f1a9:	cmp    rax,rdx
  40f1ac:	je     40f1b3 <__swc_fn_0a4ed24b_000017_efc44797+0x73>
  40f1ae:	mov    rdx,rax
  40f1b1:	jmp    40f160 <__swc_fn_0a4ed24b_000017_efc44797+0x20>
  40f1b3:	mov    eax,DWORD PTR [r12]
  40f1b7:	shl    rax,0x4
  40f1bb:	lea    r14,[rsi+rax*8+0x80]
  40f1c3:	mov    rcx,rsi
  40f1c6:	mov    rax,r12
  40f1c9:	mov    edx,DWORD PTR [rax]
  40f1cb:	call   407700 <__swc_fn_0a4ed24b_000015_9dea5065>
  40f1d0:	mov    r15,rax
  40f1d3:	mov    rcx,rsi
  40f1d6:	mov    rdx,r13
  40f1d9:	call   407860 <__swc_fn_0a4ed24b_000021_fd2b165c>
  40f1de:	test   al,al
  40f1e0:	je     40f218 <__swc_fn_0a4ed24b_000017_efc44797+0xd8>
  40f1e2:	mov    ecx,DWORD PTR [r14+0x3c]
  40f1e6:	lea    rdx,[rip+0x14e8b]        # 424078 <__swc_bss_base_0a4ed24b+0x38>
  40f1ed:	mov    r8,QWORD PTR [rip+0x14e84]        # 424078 <__swc_bss_base_0a4ed24b+0x38>
  40f1f4:	cs nop WORD PTR [rax+rax*1+0x0]
  40f1fe:	xchg   ax,ax
  40f200:	mov    r9,r8
  40f203:	sub    r9,rcx
  40f206:	mov    rax,r8
  40f209:	lock cmpxchg QWORD PTR [rdx],r9
  40f20e:	cmp    rax,r8
  40f211:	je     40f279 <__swc_fn_0a4ed24b_000017_efc44797+0x139>
  40f213:	mov    r8,rax
  40f216:	jmp    40f200 <__swc_fn_0a4ed24b_000017_efc44797+0xc0>
  40f218:	mov    rcx,rsi
  40f21b:	mov    rax,r12
  40f21e:	mov    edx,DWORD PTR [rax]
  40f220:	call   40bd50 <__swc_fn_0a4ed24b_000016_9afb7cfb>
  40f225:	mov    rcx,r15
  40f228:	and    rcx,0xffffffffffff0000
  40f22f:	lea    rcx,[rcx+0x10000]
  40f236:	mov    rbx,rax
  40f239:	cmp    rax,rcx
  40f23c:	cmova  rbx,rcx
  40f240:	mov    rax,rbx
  40f243:	sub    rax,r15
  40f246:	mov    rcx,r15
  40f249:	mov    rdx,rax
  40f24c:	call   40bba0 <__swc_fn_0a4ed24b_000007_f7acedb0>
  40f251:	test   al,al
  40f253:	jne    40f272 <__swc_fn_0a4ed24b_000017_efc44797+0x132>
  40f255:	mov    rcx,rsi
  40f258:	mov    rdx,r13
  40f25b:	call   40bf00 <__swc_fn_0a4ed24b_000022_c8f5f27c>
  40f260:	xor    eax,eax
  40f262:	add    rsp,0x30
  40f266:	pop    rbx
  40f267:	pop    r15
  40f269:	pop    r14
  40f26b:	pop    r13
  40f26d:	pop    r12
  40f26f:	pop    rdi
  40f270:	pop    rsi
  40f271:	ret
  40f272:	sub    rbx,r15
  40f275:	mov    DWORD PTR [r14+0x3c],ebx
  40f279:	mov    rcx,r14
  40f27c:	mov    rdx,rsi
  40f27f:	mov    r8d,DWORD PTR [r12]
  40f283:	mov    r9d,edi
  40f286:	mov    rbx,QWORD PTR [rsp+0x18]
  40f28b:	mov    r10d,ebx
  40f28e:	call   40efe0 <__swc_fn_0a4ed24b_000008_d64b2baa>
  40f293:	mov    rax,r14
  40f296:	add    rsp,0x30
  40f29a:	pop    rbx
  40f29b:	pop    r15
  40f29d:	pop    r14
  40f29f:	pop    r13
  40f2a1:	pop    r12
  40f2a3:	pop    rdi
  40f2a4:	pop    rsi
  40f2a5:	ret
	...

000000000040f2b0 <__swc_fn_0a4ed24b_000020_de02dbdf>:
  40f2b0:	mov    r8,QWORD PTR [rcx+0x48]
  40f2b4:	cs nop WORD PTR [rax+rax*1+0x0]
  40f2be:	xchg   ax,ax
  40f2c0:	mov    r9,r8
  40f2c3:	or     r9,rdx
  40f2c6:	mov    rax,r8
  40f2c9:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40f2cf:	cmp    rax,r8
  40f2d2:	jne    40f2d5 <__swc_fn_0a4ed24b_000020_de02dbdf+0x25>
  40f2d4:	ret
  40f2d5:	mov    r8,rax
  40f2d8:	jmp    40f2c0 <__swc_fn_0a4ed24b_000020_de02dbdf+0x10>
  40f2da:	add    BYTE PTR [rax],al
  40f2dc:	add    BYTE PTR [rax],al
	...

000000000040f2e0 <__swc_fn_0a4ed24b_000023_2d0fcd2c>:
  40f2e0:	push   rsi
  40f2e1:	push   rdi
  40f2e2:	push   r12
  40f2e4:	mov    rsi,rcx
  40f2e7:	xor    edi,edi
  40f2e9:	lea    r12,[rip+0x14d98]        # 424088 <__swc_bss_base_0a4ed24b+0x48>
  40f2f0:	mov    eax,DWORD PTR [r12]
  40f2f4:	xor    ecx,ecx
  40f2f6:	test   rax,rax
  40f2f9:	jbe    40f334 <__swc_fn_0a4ed24b_000023_2d0fcd2c+0x54>
  40f2fb:	nop    DWORD PTR [rax+rax*1+0x0]
  40f300:	lea    rdx,[rip+0x14d89]        # 424090 <__swc_bss_base_0a4ed24b+0x50>
  40f307:	mov    r8d,ecx
  40f30a:	lea    r8,[r8+r8*2]
  40f30e:	lea    r8,[rdx+r8*8]
  40f312:	mov    rdx,QWORD PTR [r8+0x10]
  40f316:	add    rdx,0x400000
  40f31d:	cmp    rdx,0x40000000
  40f324:	ja     40f32b <__swc_fn_0a4ed24b_000023_2d0fcd2c+0x4b>
  40f326:	mov    rdi,r8
  40f329:	jmp    40f334 <__swc_fn_0a4ed24b_000023_2d0fcd2c+0x54>
  40f32b:	add    rcx,0x1
  40f32f:	cmp    rcx,rax
  40f332:	jb     40f300 <__swc_fn_0a4ed24b_000023_2d0fcd2c+0x20>
  40f334:	test   rdi,rdi
  40f337:	jne    40f3c3 <__swc_fn_0a4ed24b_000023_2d0fcd2c+0xe3>
  40f33d:	cmp    DWORD PTR [r12],0x10
  40f342:	jae    40f3ab <__swc_fn_0a4ed24b_000023_2d0fcd2c+0xcb>
  40f344:	mov    ecx,0x40400000
  40f349:	call   407620 <__swc_fn_0a4ed24b_000006_81d2e1e9>
  40f34e:	test   rax,rax
  40f351:	je     40f3ab <__swc_fn_0a4ed24b_000023_2d0fcd2c+0xcb>
  40f353:	lea    rcx,[rip+0x14d36]        # 424090 <__swc_bss_base_0a4ed24b+0x50>
  40f35a:	mov    edx,DWORD PTR [r12]
  40f35e:	lea    rdx,[rdx+rdx*2]
  40f362:	lea    rdx,[rcx+rdx*8]
  40f366:	mov    QWORD PTR [rdx],rax
  40f369:	lea    rax,[rax+0x3fffff]
  40f370:	and    rax,0xffffffffffc00000
  40f377:	mov    QWORD PTR [rdx+0x8],rax
  40f37b:	mov    QWORD PTR [rdx+0x10],0x0
  40f383:	mov    edx,DWORD PTR [rip+0x14cff]        # 424088 <__swc_bss_base_0a4ed24b+0x48>
  40f389:	nop    DWORD PTR [rax+0x0]
  40f390:	lea    r9d,[rdx+0x1]
  40f394:	mov    rax,rdx
  40f397:	lock cmpxchg DWORD PTR [r12],r9d
  40f39d:	mov    r8d,eax
  40f3a0:	cmp    eax,edx
  40f3a2:	je     40f3b2 <__swc_fn_0a4ed24b_000023_2d0fcd2c+0xd2>
  40f3a4:	mov    rdx,r8
  40f3a7:	jmp    40f390 <__swc_fn_0a4ed24b_000023_2d0fcd2c+0xb0>
  40f3a9:	jmp    40f3b2 <__swc_fn_0a4ed24b_000023_2d0fcd2c+0xd2>
  40f3ab:	xor    eax,eax
  40f3ad:	pop    r12
  40f3af:	pop    rdi
  40f3b0:	pop    rsi
  40f3b1:	ret
  40f3b2:	mov    eax,DWORD PTR [rip+0x14cd0]        # 424088 <__swc_bss_base_0a4ed24b+0x48>
  40f3b8:	sub    eax,0x1
  40f3bb:	lea    rdi,[rax+rax*2]
  40f3bf:	lea    rdi,[rcx+rdi*8]
  40f3c3:	mov    r12,QWORD PTR [rdi+0x8]
  40f3c7:	add    r12,QWORD PTR [rdi+0x10]
  40f3cb:	mov    rcx,r12
  40f3ce:	mov    edx,0x3000
  40f3d3:	call   40bba0 <__swc_fn_0a4ed24b_000007_f7acedb0>
  40f3d8:	test   al,al
  40f3da:	jne    40f3e3 <__swc_fn_0a4ed24b_000023_2d0fcd2c+0x103>
  40f3dc:	xor    eax,eax
  40f3de:	pop    r12
  40f3e0:	pop    rdi
  40f3e1:	pop    rsi
  40f3e2:	ret
  40f3e3:	vxorps xmm0,xmm0,xmm0
  40f3e7:	xor    eax,eax
  40f3e9:	cs nop WORD PTR [rax+rax*1+0x0]
  40f3f3:	cs nop WORD PTR [rax+rax*1+0x0]
  40f3fd:	nop    DWORD PTR [rax]
  40f400:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40f406:	add    rax,0x10
  40f40a:	cmp    rax,0x3000
  40f411:	jne    40f400 <__swc_fn_0a4ed24b_000023_2d0fcd2c+0x120>
  40f413:	mov    DWORD PTR [r12+0x28],esi
  40f418:	mov    eax,0x40
  40f41d:	mov    ecx,esi
  40f41f:	shr    eax,cl
  40f421:	mov    DWORD PTR [r12+0x2c],eax
  40f426:	cmp    DWORD PTR [r12+0x2c],0x40
  40f42c:	jb     40f437 <__swc_fn_0a4ed24b_000023_2d0fcd2c+0x157>
  40f42e:	mov    rax,0xffffffffffffffff
  40f435:	jmp    40f447 <__swc_fn_0a4ed24b_000023_2d0fcd2c+0x167>
  40f437:	mov    eax,0x1
  40f43c:	mov    ecx,DWORD PTR [r12+0x2c]
  40f441:	shl    rax,cl
  40f444:	dec    rax
  40f447:	mov    QWORD PTR [r12+0x20],rax
  40f44c:	mov    DWORD PTR [r12],0x4e540001
  40f454:	mov    DWORD PTR [r12+0x4],0x53474d45
  40f45d:	add    QWORD PTR [rdi+0x10],0x400000
  40f465:	mov    rax,r12
  40f468:	pop    r12
  40f46a:	pop    rdi
  40f46b:	pop    rsi
  40f46c:	ret
  40f46d:	add    BYTE PTR [rax],al
	...

000000000040f470 <__swc_fn_0a4ed24b_000026_bcdc5519>:
  40f470:	mov    eax,0x1
  40f475:	mov    edx,DWORD PTR [rip+0x14c0d]        # 424088 <__swc_bss_base_0a4ed24b+0x48>
  40f47b:	cmp    eax,edx
  40f47d:	jae    40f4cb <__swc_fn_0a4ed24b_000026_bcdc5519+0x5b>
  40f47f:	nop
  40f480:	lea    r8,[rip+0x14c09]        # 424090 <__swc_bss_base_0a4ed24b+0x50>
  40f487:	lea    r9,[rax+rax*2]
  40f48b:	lea    r9,[r8+r9*8]
  40f48f:	mov    r8,rcx
  40f492:	sub    r8,QWORD PTR [r9+0x8]
  40f496:	mov    r9,QWORD PTR [r9+0x10]
  40f49a:	cmp    r8,r9
  40f49d:	jae    40f4c5 <__swc_fn_0a4ed24b_000026_bcdc5519+0x55>
  40f49f:	mov    rax,rcx
  40f4a2:	and    rax,0xffffffffffc00000
  40f4a9:	shr    rcx,0x10
  40f4ad:	and    ecx,0x3f
  40f4b0:	mov    edx,DWORD PTR [rax+0x28]
  40f4b3:	shrx   ecx,ecx,edx
  40f4b8:	shl    rcx,0x4
  40f4bc:	lea    rax,[rax+rcx*8+0x80]
  40f4c4:	ret
  40f4c5:	inc    eax
  40f4c7:	cmp    eax,edx
  40f4c9:	jb     40f480 <__swc_fn_0a4ed24b_000026_bcdc5519+0x10>
  40f4cb:	xor    eax,eax
  40f4cd:	ret
	...

000000000040f4d0 <__swc_fn_0a4ed24b_000029_9798fb47>:
  40f4d0:	vxorps xmm0,xmm0,xmm0
  40f4d4:	vmovups XMMWORD PTR [rcx],xmm0
  40f4d8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f4dd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40f4e2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40f4e7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40f4ec:	mov    QWORD PTR [rcx+0x50],0x0
  40f4f4:	ret
	...

000000000040f500 <__swc_fn_0a4ed24b_000032_9798fb47>:
  40f500:	vxorps xmm0,xmm0,xmm0
  40f504:	xor    eax,eax
  40f506:	cs nop WORD PTR [rax+rax*1+0x0]
  40f510:	cs nop WORD PTR [rax+rax*1+0x0]
  40f51a:	nop    WORD PTR [rax+rax*1+0x0]
  40f520:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40f525:	add    rax,0x10
  40f529:	cmp    rax,0x9b0
  40f530:	jne    40f520 <__swc_fn_0a4ed24b_000032_9798fb47+0x20>
  40f532:	mov    QWORD PTR [rcx+0x9b0],0x0
  40f53d:	ret
	...

000000000040f540 <__swc_fn_0a4ed24b_000035_cd1a4e8c>:
  40f540:	push   rsi
  40f541:	push   rdi
  40f542:	sub    rsp,0x8
  40f546:	lea    rsi,[rip+0x12ac3]        # 422010 <__swc_data_base_0a4ed24b+0x10>
  40f54d:	mov    rax,QWORD PTR [rsi]
  40f550:	mov    ecx,0xffffffff
  40f555:	cmp    rax,rcx
  40f558:	je     40f561 <__swc_fn_0a4ed24b_000035_cd1a4e8c+0x21>
  40f55a:	add    rsp,0x8
  40f55e:	pop    rdi
  40f55f:	pop    rsi
  40f560:	ret
  40f561:	mov    rcx,QWORD PTR [rip+0x3b88]        # 4130f0 <__swc_fn_0a4ed24b_000176_4de704de+0x1010>
  40f568:	call   40df50 <__swc_fn_0a4ed24b_000130_4a82cdf6>
  40f56d:	mov    rcx,rax
  40f570:	mov    eax,0xffffffff
  40f575:	lock cmpxchg QWORD PTR [rsi],rcx
  40f57a:	mov    rdi,rax
  40f57d:	mov    eax,0xffffffff
  40f582:	cmp    rdi,rax
  40f585:	je     40f596 <__swc_fn_0a4ed24b_000035_cd1a4e8c+0x56>
  40f587:	call   411770 <__swc_fn_0a4ed24b_000131_a611b8c4>
  40f58c:	mov    rax,rdi
  40f58f:	add    rsp,0x8
  40f593:	pop    rdi
  40f594:	pop    rsi
  40f595:	ret
  40f596:	mov    rax,rcx
  40f599:	add    rsp,0x8
  40f59d:	pop    rdi
  40f59e:	pop    rsi
  40f59f:	ret

000000000040f5a0 <__swc_fn_0a4ed24b_000038_14f56618>:
  40f5a0:	sub    rsp,0x8
  40f5a4:	vxorps xmm0,xmm0,xmm0
  40f5a8:	xor    eax,eax
  40f5aa:	cs nop WORD PTR [rax+rax*1+0x0]
  40f5b4:	cs nop WORD PTR [rax+rax*1+0x0]
  40f5be:	xchg   ax,ax
  40f5c0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40f5c5:	add    rax,0x10
  40f5c9:	cmp    rax,0x2b00
  40f5d0:	jne    40f5c0 <__swc_fn_0a4ed24b_000038_14f56618+0x20>
  40f5d2:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40f5dc:	xor    al,al
  40f5de:	mov    rdx,rax
  40f5e1:	xor    al,al
  40f5e3:	mov    r8,rax
  40f5e6:	xor    al,al
  40f5e8:	mov    r9,rax
  40f5eb:	xor    al,al
  40f5ed:	mov    r10,rax
  40f5f0:	xor    al,al
  40f5f2:	mov    r11,rax
  40f5f5:	call   407a90 <__swc_fn_0a4ed24b_000039_03f1bf9a>
  40f5fa:	add    rsp,0x8
  40f5fe:	ret
	...

000000000040f600 <__swc_fn_0a4ed24b_000041_c90d80c1>:
  40f600:	push   rsi
  40f601:	push   rdi
  40f602:	push   r12
  40f604:	mov    rsi,r8
  40f607:	mov    rdi,rdx
  40f60a:	mov    rcx,rdx
  40f60d:	call   407620 <__swc_fn_0a4ed24b_000006_81d2e1e9>
  40f612:	mov    r12,rax
  40f615:	test   rax,rax
  40f618:	jne    40f621 <__swc_fn_0a4ed24b_000041_c90d80c1+0x21>
  40f61a:	xor    eax,eax
  40f61c:	pop    r12
  40f61e:	pop    rdi
  40f61f:	pop    rsi
  40f620:	ret
  40f621:	mov    rcx,r12
  40f624:	mov    rdx,rsi
  40f627:	call   40bba0 <__swc_fn_0a4ed24b_000007_f7acedb0>
  40f62c:	test   al,al
  40f62e:	jne    40f642 <__swc_fn_0a4ed24b_000041_c90d80c1+0x42>
  40f630:	mov    rcx,r12
  40f633:	mov    rdx,rdi
  40f636:	call   409890 <__swc_fn_0a4ed24b_000117_ed2d8fed>
  40f63b:	xor    eax,eax
  40f63d:	pop    r12
  40f63f:	pop    rdi
  40f640:	pop    rsi
  40f641:	ret
  40f642:	mov    rax,r12
  40f645:	pop    r12
  40f647:	pop    rdi
  40f648:	pop    rsi
  40f649:	ret
	...

000000000040f660 <__swc_fn_0a4ed24b_000044_a78ae66b>:
  40f660:	push   rsi
  40f661:	push   rdi
  40f662:	push   r12
  40f664:	mov    rsi,rcx
  40f667:	mov    edx,0x9b8
  40f66c:	call   407b00 <__swc_fn_0a4ed24b_000042_facd3e17>
  40f671:	mov    rdi,rax
  40f674:	test   rax,rax
  40f677:	jne    40f680 <__swc_fn_0a4ed24b_000044_a78ae66b+0x20>
  40f679:	xor    eax,eax
  40f67b:	pop    r12
  40f67d:	pop    rdi
  40f67e:	pop    rsi
  40f67f:	ret
  40f680:	vxorps xmm0,xmm0,xmm0
  40f684:	xor    eax,eax
  40f686:	cs nop WORD PTR [rax+rax*1+0x0]
  40f690:	cs nop WORD PTR [rax+rax*1+0x0]
  40f69a:	nop    WORD PTR [rax+rax*1+0x0]
  40f6a0:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40f6a5:	add    rax,0x10
  40f6a9:	cmp    rax,0x9b0
  40f6b0:	jne    40f6a0 <__swc_fn_0a4ed24b_000044_a78ae66b+0x40>
  40f6b2:	mov    QWORD PTR [rdi+0x9b0],0x0
  40f6bd:	mov    QWORD PTR [rdi],rsi
  40f6c0:	call   411820 <__swc_fn_0a4ed24b_000134_a9c1c700>
  40f6c5:	mov    QWORD PTR [rdi+0x18],rax
  40f6c9:	lea    r12,[rsi+0x10]
  40f6cd:	mov    rcx,r12
  40f6d0:	call   40e1a0 <__swc_fn_0a4ed24b_000139_86bb0f90>
  40f6d5:	mov    rax,QWORD PTR [rsi+0x20]
  40f6d9:	mov    QWORD PTR [rdi+0x8],rax
  40f6dd:	mov    rax,QWORD PTR [rsi+0x20]
  40f6e1:	test   rax,rax
  40f6e4:	je     40f6ea <__swc_fn_0a4ed24b_000044_a78ae66b+0x8a>
  40f6e6:	mov    QWORD PTR [rax+0x10],rdi
  40f6ea:	mov    QWORD PTR [rsi+0x20],rdi
  40f6ee:	mov    rcx,r12
  40f6f1:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40f6f6:	mov    rax,rdi
  40f6f9:	pop    r12
  40f6fb:	pop    rdi
  40f6fc:	pop    rsi
  40f6fd:	ret
	...

000000000040f700 <__swc_fn_0a4ed24b_000047_6e7a8d58>:
  40f700:	mov    rax,QWORD PTR [rdx+0x10]
  40f704:	test   rax,rax
  40f707:	je     40f713 <__swc_fn_0a4ed24b_000047_6e7a8d58+0x13>
  40f709:	mov    rcx,QWORD PTR [rdx+0x8]
  40f70d:	mov    QWORD PTR [rax+0x8],rcx
  40f711:	jmp    40f71b <__swc_fn_0a4ed24b_000047_6e7a8d58+0x1b>
  40f713:	mov    rax,QWORD PTR [rdx+0x8]
  40f717:	mov    QWORD PTR [rcx+0x20],rax
  40f71b:	mov    rax,QWORD PTR [rdx+0x8]
  40f71f:	test   rax,rax
  40f722:	je     40f72c <__swc_fn_0a4ed24b_000047_6e7a8d58+0x2c>
  40f724:	mov    rcx,QWORD PTR [rdx+0x10]
  40f728:	mov    QWORD PTR [rax+0x10],rcx
  40f72c:	vxorps xmm0,xmm0,xmm0
  40f730:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40f735:	ret
	...

000000000040f740 <__swc_fn_0a4ed24b_000050_129b9bf4>:
  40f740:	sub    rsp,0x8
  40f744:	mov    r9,r8
  40f747:	mov    r10,rdx
  40f74a:	call   407bb0 <__swc_fn_0a4ed24b_000048_137687bb>
  40f74f:	mov    eax,0x1
  40f754:	xchg   DWORD PTR [r9+0x6c],eax
  40f758:	mov    rax,QWORD PTR [r9+0x60]
  40f75c:	test   rax,rax
  40f75f:	je     40f7a3 <__swc_fn_0a4ed24b_000050_129b9bf4+0x63>
  40f761:	xor    eax,eax
  40f763:	xchg   DWORD PTR [r9+0x6c],eax
  40f767:	movzx  eax,BYTE PTR [r9+0x39]
  40f76c:	lea    rax,[rax+rax*4]
  40f770:	lea    rax,[r10+rax*8+0x28]
  40f775:	mov    QWORD PTR [r9+0x50],0x0
  40f77d:	mov    rcx,QWORD PTR [rax+0x8]
  40f781:	mov    QWORD PTR [r9+0x48],rcx
  40f785:	mov    rcx,QWORD PTR [rax+0x8]
  40f789:	test   rcx,rcx
  40f78c:	je     40f794 <__swc_fn_0a4ed24b_000050_129b9bf4+0x54>
  40f78e:	mov    QWORD PTR [rcx+0x50],r9
  40f792:	jmp    40f798 <__swc_fn_0a4ed24b_000050_129b9bf4+0x58>
  40f794:	mov    QWORD PTR [rax+0x10],r9
  40f798:	mov    QWORD PTR [rax+0x8],r9
  40f79c:	xor    eax,eax
  40f79e:	add    rsp,0x8
  40f7a2:	ret
  40f7a3:	movzx  eax,BYTE PTR [r9+0x39]
  40f7a8:	lea    rax,[rax+rax*4]
  40f7ac:	lea    rax,[r10+rax*8+0x28]
  40f7b1:	mov    QWORD PTR [r9+0x50],0x0
  40f7b9:	mov    rcx,QWORD PTR [rax+0x18]
  40f7bd:	mov    QWORD PTR [r9+0x48],rcx
  40f7c1:	mov    rcx,QWORD PTR [rax+0x18]
  40f7c5:	test   rcx,rcx
  40f7c8:	je     40f7ce <__swc_fn_0a4ed24b_000050_129b9bf4+0x8e>
  40f7ca:	mov    QWORD PTR [rcx+0x50],r9
  40f7ce:	mov    QWORD PTR [rax+0x18],r9
  40f7d2:	mov    eax,0x1
  40f7d7:	add    rsp,0x8
  40f7db:	ret
  40f7dc:	add    BYTE PTR [rax],al
	...

000000000040f7e0 <__swc_fn_0a4ed24b_000053_3af34d7f>:
  40f7e0:	push   r12
  40f7e2:	push   r13
  40f7e4:	push   rdi
  40f7e5:	push   rsi
  40f7e6:	push   r14
  40f7e8:	push   r15
  40f7ea:	sub    rsp,0x178
  40f7f1:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40f7fa:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40f803:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40f80c:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40f815:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40f81e:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40f827:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40f830:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40f839:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40f842:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40f84b:	mov    r12,rcx
  40f84e:	lea    rax,[rip+0x149cb]        # 424220 <__swc_bss_base_0a4ed24b+0x1e0>
  40f855:	mov    rcx,QWORD PTR [rax]
  40f858:	mov    r13,rcx
  40f85b:	test   rcx,rcx
  40f85e:	jne    40f86e <__swc_fn_0a4ed24b_000053_3af34d7f+0x8e>
  40f860:	mov    r13d,0x1dcd6500
  40f866:	mov    ecx,0x1dcd6500
  40f86b:	xchg   QWORD PTR [rax],rcx
  40f86e:	lea    rax,[rip+0x12793]        # 422008 <__swc_data_base_0a4ed24b+0x8>
  40f875:	mov    rax,QWORD PTR [rax]
  40f878:	cmp    rax,0xffffffffffffffff
  40f87c:	je     40f88b <__swc_fn_0a4ed24b_000053_3af34d7f+0xab>
  40f87e:	mov    eax,eax
  40f880:	mov    edi,eax
  40f882:	xor    eax,eax
  40f884:	call   407010 <pthread_getspecific@plt>
  40f889:	jmp    40f88d <__swc_fn_0a4ed24b_000053_3af34d7f+0xad>
  40f88b:	xor    eax,eax
  40f88d:	test   rax,rax
  40f890:	jne    40f89f <__swc_fn_0a4ed24b_000053_3af34d7f+0xbf>
  40f892:	call   40f540 <__swc_fn_0a4ed24b_000035_cd1a4e8c>
  40f897:	mov    rcx,rax
  40f89a:	call   409be0 <__swc_fn_0a4ed24b_000132_5f757033>
  40f89f:	test   rax,rax
  40f8a2:	je     40f8b4 <__swc_fn_0a4ed24b_000053_3af34d7f+0xd4>
  40f8a4:	cmp    QWORD PTR [rax],r12
  40f8a7:	jne    40f8b4 <__swc_fn_0a4ed24b_000053_3af34d7f+0xd4>
  40f8a9:	cmp    DWORD PTR [rax+0x20],0x0
  40f8ad:	jne    40f8b4 <__swc_fn_0a4ed24b_000053_3af34d7f+0xd4>
  40f8af:	mov    rsi,rax
  40f8b2:	jmp    40f8b6 <__swc_fn_0a4ed24b_000053_3af34d7f+0xd6>
  40f8b4:	xor    esi,esi
  40f8b6:	lea    rdi,[r12+0x2a88]
  40f8be:	mov    r14,QWORD PTR [rdi]
  40f8c1:	test   r14,r14
  40f8c4:	jne    40f913 <__swc_fn_0a4ed24b_000053_3af34d7f+0x133>
  40f8c6:	lea    rax,[rip+0x147ab]        # 424078 <__swc_bss_base_0a4ed24b+0x38>
  40f8cd:	mov    rax,QWORD PTR [rax]
  40f8d0:	test   rax,rax
  40f8d3:	setne  al
  40f8d6:	jne    40f8fa <__swc_fn_0a4ed24b_000053_3af34d7f+0x11a>
  40f8d8:	mov    rax,QWORD PTR [r12+0x2a70]
  40f8e0:	test   rax,rax
  40f8e3:	setne  al
  40f8e6:	jne    40f8fa <__swc_fn_0a4ed24b_000053_3af34d7f+0x11a>
  40f8e8:	test   rsi,rsi
  40f8eb:	setne  al
  40f8ee:	je     40f8fa <__swc_fn_0a4ed24b_000053_3af34d7f+0x11a>
  40f8f0:	cmp    DWORD PTR [rsi+0x730],0x0
  40f8f7:	setne  al
  40f8fa:	test   al,al
  40f8fc:	je     40f90e <__swc_fn_0a4ed24b_000053_3af34d7f+0x12e>
  40f8fe:	call   409c90 <__swc_fn_0a4ed24b_000135_07d76562>
  40f903:	lea    rcx,[rax+r13*1]
  40f907:	xor    eax,eax
  40f909:	lock cmpxchg QWORD PTR [rdi],rcx
  40f90e:	jmp    40fa13 <__swc_fn_0a4ed24b_000053_3af34d7f+0x233>
  40f913:	call   409c90 <__swc_fn_0a4ed24b_000135_07d76562>
  40f918:	mov    r15,rax
  40f91b:	cmp    rax,r14
  40f91e:	jb     40f92f <__swc_fn_0a4ed24b_000053_3af34d7f+0x14f>
  40f920:	xor    ecx,ecx
  40f922:	mov    rax,r14
  40f925:	lock cmpxchg QWORD PTR [rdi],rcx
  40f92a:	cmp    rax,r14
  40f92d:	je     40f934 <__swc_fn_0a4ed24b_000053_3af34d7f+0x154>
  40f92f:	jmp    40fa13 <__swc_fn_0a4ed24b_000053_3af34d7f+0x233>
  40f934:	test   rsi,rsi
  40f937:	je     40f952 <__swc_fn_0a4ed24b_000053_3af34d7f+0x172>
  40f939:	cmp    r15,r13
  40f93c:	jb     40f952 <__swc_fn_0a4ed24b_000053_3af34d7f+0x172>
  40f93e:	mov    rax,r15
  40f941:	sub    rax,r13
  40f944:	mov    rcx,r12
  40f947:	mov    rdx,rsi
  40f94a:	mov    r8,rax
  40f94d:	call   407ff0 <__swc_fn_0a4ed24b_000063_dea90857>
  40f952:	lea    rsi,[r12+0x10]
  40f957:	mov    rcx,rsi
  40f95a:	call   40e1a0 <__swc_fn_0a4ed24b_000139_86bb0f90>
  40f95f:	mov    rax,QWORD PTR [r12+0x18]
  40f964:	mov    rdi,rax
  40f967:	test   rdi,rdi
  40f96a:	je     40f994 <__swc_fn_0a4ed24b_000053_3af34d7f+0x1b4>
  40f96c:	cs nop WORD PTR [rax+rax*1+0x0]
  40f976:	cs nop WORD PTR [rax+rax*1+0x0]
  40f980:	mov    rcx,rdi
  40f983:	call   40bd70 <__swc_fn_0a4ed24b_000019_adca76cf>
  40f988:	mov    rax,QWORD PTR [rdi+0x10]
  40f98c:	mov    rdi,rax
  40f98f:	test   rax,rax
  40f992:	jne    40f980 <__swc_fn_0a4ed24b_000053_3af34d7f+0x1a0>
  40f994:	mov    rcx,rsi
  40f997:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40f99c:	mov    rcx,r12
  40f99f:	call   40e1a0 <__swc_fn_0a4ed24b_000139_86bb0f90>
  40f9a4:	xor    esi,esi
  40f9a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40f9b0:	mov    rax,QWORD PTR [r12+0x2a70]
  40f9b8:	cmp    rsi,rax
  40f9bb:	jae    40fa0b <__swc_fn_0a4ed24b_000053_3af34d7f+0x22b>
  40f9bd:	lea    rax,[rsi+rsi*4]
  40f9c1:	lea    rax,[r12+rax*8+0x268]
  40f9c9:	mov    r8,QWORD PTR [rax]
  40f9cc:	mov    r9,QWORD PTR [rax+0x8]
  40f9d0:	mov    r10,QWORD PTR [rax+0x10]
  40f9d4:	mov    rax,QWORD PTR [rax+0x20]
  40f9d8:	cmp    rax,r15
  40f9db:	jae    40f9e8 <__swc_fn_0a4ed24b_000053_3af34d7f+0x208>
  40f9dd:	mov    rcx,r15
  40f9e0:	sub    rcx,rax
  40f9e3:	cmp    rcx,r13
  40f9e6:	jae    40f9ed <__swc_fn_0a4ed24b_000053_3af34d7f+0x20d>
  40f9e8:	inc    rsi
  40f9eb:	jmp    40f9b0 <__swc_fn_0a4ed24b_000053_3af34d7f+0x1d0>
  40f9ed:	mov    rcx,r12
  40f9f0:	mov    rdx,rsi
  40f9f3:	call   407fa0 <__swc_fn_0a4ed24b_000060_15c28ca7>
  40f9f8:	mov    rcx,r12
  40f9fb:	mov    rdx,r8
  40f9fe:	mov    r8,r9
  40fa01:	mov    r9,r10
  40fa04:	call   40c050 <__swc_fn_0a4ed24b_000043_d3c2ab54>
  40fa09:	jmp    40f9b0 <__swc_fn_0a4ed24b_000053_3af34d7f+0x1d0>
  40fa0b:	mov    rcx,r12
  40fa0e:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40fa13:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40fa1c:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40fa25:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40fa2e:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40fa37:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40fa40:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40fa49:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40fa52:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40fa5b:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40fa64:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40fa6d:	add    rsp,0x178
  40fa74:	pop    r15
  40fa76:	pop    r14
  40fa78:	pop    rsi
  40fa79:	pop    rdi
  40fa7a:	pop    r13
  40fa7c:	pop    r12
  40fa7e:	ret
	...

000000000040fa80 <__swc_fn_0a4ed24b_000056_df0696cd>:
  40fa80:	lea    rax,[rdx-0x58]
  40fa84:	ret
	...

000000000040fa90 <__swc_fn_0a4ed24b_000059_2ca0cb05>:
  40fa90:	push   rsi
  40fa91:	push   rdi
  40fa92:	push   r12
  40fa94:	push   r13
  40fa96:	sub    rsp,0x68
  40fa9a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40faa0:	mov    rsi,r9
  40faa3:	mov    rdi,rcx
  40faa6:	mov    r12,rdx
  40faa9:	mov    r13,r8
  40faac:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40fab4:	jne    40fac3 <__swc_fn_0a4ed24b_000059_2ca0cb05+0x33>
  40fab6:	xor    eax,eax
  40fab8:	add    rsp,0x68
  40fabc:	pop    r13
  40fabe:	pop    r12
  40fac0:	pop    rdi
  40fac1:	pop    rsi
  40fac2:	ret
  40fac3:	mov    rcx,rdi
  40fac6:	call   40e1a0 <__swc_fn_0a4ed24b_000139_86bb0f90>
  40facb:	movabs rax,0x7fffffffffffffff
  40fad5:	cmp    r12,rax
  40fad8:	mov    rax,0xffffffffffffffff
  40fadf:	lea    rcx,[r12+r12*1]
  40fae3:	cmovbe rax,rcx
  40fae7:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40faee:	mov    rdx,rcx
  40faf1:	sub    rax,r12
  40faf4:	inc    rax
  40faf7:	xor    r8d,r8d
  40fafa:	test   rcx,rcx
  40fafd:	jbe    40fb28 <__swc_fn_0a4ed24b_000059_2ca0cb05+0x98>
  40faff:	nop
  40fb00:	lea    r9,[r8+r8*4]
  40fb04:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40fb0c:	sub    r9,r12
  40fb0f:	cmp    r9,rax
  40fb12:	jae    40fb1f <__swc_fn_0a4ed24b_000059_2ca0cb05+0x8f>
  40fb14:	mov    rdx,r8
  40fb17:	mov    rax,r9
  40fb1a:	test   r9,r9
  40fb1d:	je     40fb28 <__swc_fn_0a4ed24b_000059_2ca0cb05+0x98>
  40fb1f:	add    r8,0x1
  40fb23:	cmp    r8,rcx
  40fb26:	jb     40fb00 <__swc_fn_0a4ed24b_000059_2ca0cb05+0x70>
  40fb28:	mov    rax,QWORD PTR [rdi+0x2a70]
  40fb2f:	cmp    rdx,rax
  40fb32:	jne    40fb4f <__swc_fn_0a4ed24b_000059_2ca0cb05+0xbf>
  40fb34:	mov    rcx,rdi
  40fb37:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40fb3c:	xor    eax,eax
  40fb3e:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40fb44:	add    rsp,0x68
  40fb48:	pop    r13
  40fb4a:	pop    r12
  40fb4c:	pop    rdi
  40fb4d:	pop    rsi
  40fb4e:	ret
  40fb4f:	lea    rax,[rdx+rdx*4]
  40fb53:	lea    rax,[rdi+rax*8+0x268]
  40fb5b:	vmovups xmm6,XMMWORD PTR [rax]
  40fb5f:	mov    r8,QWORD PTR [rax+0x10]
  40fb63:	mov    rcx,rdi
  40fb66:	call   407fa0 <__swc_fn_0a4ed24b_000060_15c28ca7>
  40fb6b:	vpshufd xmm0,xmm6,0xee
  40fb70:	vmovsd QWORD PTR [r13+0x0],xmm0
  40fb76:	mov    QWORD PTR [rsi],r8
  40fb79:	mov    rcx,rdi
  40fb7c:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40fb81:	vmovq  rax,xmm6
  40fb86:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40fb8c:	add    rsp,0x68
  40fb90:	pop    r13
  40fb92:	pop    r12
  40fb94:	pop    rdi
  40fb95:	pop    rsi
  40fb96:	ret
	...

000000000040fba0 <__swc_fn_0a4ed24b_000062_b304235a>:
  40fba0:	push   r12
  40fba2:	push   r13
  40fba4:	push   r14
  40fba6:	push   r15
  40fba8:	push   rdi
  40fba9:	push   rsi
  40fbaa:	sub    rsp,0x148
  40fbb1:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40fbba:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40fbc3:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40fbcc:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40fbd5:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40fbde:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40fbe7:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40fbf0:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40fbf9:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40fc02:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40fc0b:	mov    r12,r9
  40fc0e:	mov    r13,rcx
  40fc11:	mov    r14,rdx
  40fc14:	mov    r15,r8
  40fc17:	test   rdx,rdx
  40fc1a:	jne    40fc2e <__swc_fn_0a4ed24b_000062_b304235a+0x8e>
  40fc1c:	add    rsp,0x148
  40fc23:	pop    rsi
  40fc24:	pop    rdi
  40fc25:	pop    r15
  40fc27:	pop    r14
  40fc29:	pop    r13
  40fc2b:	pop    r12
  40fc2d:	ret
  40fc2e:	cmp    r12,0x200000
  40fc35:	ja     40fcc7 <__swc_fn_0a4ed24b_000062_b304235a+0x127>
  40fc3b:	lea    rax,[rip+0x123c6]        # 422008 <__swc_data_base_0a4ed24b+0x8>
  40fc42:	mov    rax,QWORD PTR [rax]
  40fc45:	cmp    rax,0xffffffffffffffff
  40fc49:	je     40fc58 <__swc_fn_0a4ed24b_000062_b304235a+0xb8>
  40fc4b:	mov    eax,eax
  40fc4d:	mov    edi,eax
  40fc4f:	xor    eax,eax
  40fc51:	call   407010 <pthread_getspecific@plt>
  40fc56:	jmp    40fc5a <__swc_fn_0a4ed24b_000062_b304235a+0xba>
  40fc58:	xor    eax,eax
  40fc5a:	test   rax,rax
  40fc5d:	je     40fc64 <__swc_fn_0a4ed24b_000062_b304235a+0xc4>
  40fc5f:	mov    rsi,rax
  40fc62:	jmp    40fc74 <__swc_fn_0a4ed24b_000062_b304235a+0xd4>
  40fc64:	call   40f540 <__swc_fn_0a4ed24b_000035_cd1a4e8c>
  40fc69:	mov    rcx,rax
  40fc6c:	call   409be0 <__swc_fn_0a4ed24b_000132_5f757033>
  40fc71:	mov    rsi,rax
  40fc74:	test   rsi,rsi
  40fc77:	je     40fcc7 <__swc_fn_0a4ed24b_000062_b304235a+0x127>
  40fc79:	cmp    QWORD PTR [rsi],r13
  40fc7c:	jne    40fcc7 <__swc_fn_0a4ed24b_000062_b304235a+0x127>
  40fc7e:	cmp    DWORD PTR [rsi+0x20],0x0
  40fc82:	jne    40fcc7 <__swc_fn_0a4ed24b_000062_b304235a+0x127>
  40fc84:	cmp    DWORD PTR [rsi+0x730],0x10
  40fc8b:	jae    40fcc7 <__swc_fn_0a4ed24b_000062_b304235a+0x127>
  40fc8d:	mov    eax,DWORD PTR [rsi+0x730]
  40fc93:	lea    rdi,[rax+rax*4]
  40fc97:	lea    rdi,[rsi+rdi*8+0x738]
  40fc9f:	mov    QWORD PTR [rdi],r14
  40fca2:	mov    QWORD PTR [rdi+0x8],r15
  40fca6:	mov    QWORD PTR [rdi+0x10],r12
  40fcaa:	mov    QWORD PTR [rdi+0x18],0x0
  40fcb2:	call   409c90 <__swc_fn_0a4ed24b_000135_07d76562>
  40fcb7:	mov    QWORD PTR [rdi+0x20],rax
  40fcbb:	add    DWORD PTR [rsi+0x730],0x1
  40fcc2:	jmp    40fe26 <__swc_fn_0a4ed24b_000062_b304235a+0x286>
  40fcc7:	mov    rcx,r13
  40fcca:	call   40c790 <__swc_fn_0a4ed24b_000061_ad030a10>
  40fccf:	mov    rsi,rax
  40fcd2:	cmp    r12,rax
  40fcd5:	jbe    40fd0a <__swc_fn_0a4ed24b_000062_b304235a+0x16a>
  40fcd7:	cmp    r12,0x10000000
  40fcde:	seta   al
  40fce1:	ja     40fcf0 <__swc_fn_0a4ed24b_000062_b304235a+0x150>
  40fce3:	mov    rax,QWORD PTR [r13+0x2a70]
  40fcea:	test   rax,rax
  40fced:	setne  al
  40fcf0:	test   al,al
  40fcf2:	je     40fd0a <__swc_fn_0a4ed24b_000062_b304235a+0x16a>
  40fcf4:	mov    rcx,r13
  40fcf7:	mov    rdx,r14
  40fcfa:	mov    r8,r15
  40fcfd:	mov    r9,r12
  40fd00:	call   40c050 <__swc_fn_0a4ed24b_000043_d3c2ab54>
  40fd05:	jmp    40fe26 <__swc_fn_0a4ed24b_000062_b304235a+0x286>
  40fd0a:	call   409c90 <__swc_fn_0a4ed24b_000135_07d76562>
  40fd0f:	mov    rdi,rax
  40fd12:	mov    rcx,r13
  40fd15:	call   40e1a0 <__swc_fn_0a4ed24b_000139_86bb0f90>
  40fd1a:	cmp    QWORD PTR [r13+0x2a70],0x0
  40fd22:	je     40fdda <__swc_fn_0a4ed24b_000062_b304235a+0x23a>
  40fd28:	nop    DWORD PTR [rax+rax*1+0x0]
  40fd30:	cmp    QWORD PTR [r13+0x2a70],0x100
  40fd3b:	jae    40fd50 <__swc_fn_0a4ed24b_000062_b304235a+0x1b0>
  40fd3d:	mov    rax,QWORD PTR [r13+0x2a68]
  40fd44:	add    rax,r12
  40fd47:	cmp    rax,rsi
  40fd4a:	jbe    40fdda <__swc_fn_0a4ed24b_000062_b304235a+0x23a>
  40fd50:	xor    eax,eax
  40fd52:	mov    rcx,QWORD PTR [r13+0x2a70]
  40fd59:	mov    edx,0x1
  40fd5e:	cmp    rcx,0x1
  40fd62:	jbe    40fd99 <__swc_fn_0a4ed24b_000062_b304235a+0x1f9>
  40fd64:	cs nop WORD PTR [rax+rax*1+0x0]
  40fd6e:	xchg   ax,ax
  40fd70:	lea    r8,[rdx+rdx*4]
  40fd74:	lea    r8,[r13+r8*8+0x268]
  40fd7c:	lea    r9,[rax+rax*4]
  40fd80:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40fd88:	cmp    QWORD PTR [r8+0x18],r9
  40fd8c:	cmovb  rax,rdx
  40fd90:	add    rdx,0x1
  40fd94:	cmp    rdx,rcx
  40fd97:	jb     40fd70 <__swc_fn_0a4ed24b_000062_b304235a+0x1d0>
  40fd99:	lea    rcx,[rax+rax*4]
  40fd9d:	lea    rcx,[r13+rcx*8+0x268]
  40fda5:	mov    r8,QWORD PTR [rcx]
  40fda8:	mov    r9,QWORD PTR [rcx+0x8]
  40fdac:	mov    r10,QWORD PTR [rcx+0x10]
  40fdb0:	mov    rcx,r13
  40fdb3:	mov    rdx,rax
  40fdb6:	call   407fa0 <__swc_fn_0a4ed24b_000060_15c28ca7>
  40fdbb:	mov    rcx,r13
  40fdbe:	mov    rdx,r8
  40fdc1:	mov    r8,r9
  40fdc4:	mov    r9,r10
  40fdc7:	call   40c050 <__swc_fn_0a4ed24b_000043_d3c2ab54>
  40fdcc:	cmp    QWORD PTR [r13+0x2a70],0x0
  40fdd4:	jne    40fd30 <__swc_fn_0a4ed24b_000062_b304235a+0x190>
  40fdda:	add    QWORD PTR [r13+0x2a78],0x1
  40fde2:	mov    rax,QWORD PTR [r13+0x2a70]
  40fde9:	lea    rax,[rax+rax*4]
  40fded:	lea    rax,[r13+rax*8+0x268]
  40fdf5:	mov    QWORD PTR [rax],r14
  40fdf8:	mov    QWORD PTR [rax+0x8],r15
  40fdfc:	mov    QWORD PTR [rax+0x10],r12
  40fe00:	mov    rcx,QWORD PTR [r13+0x2a78]
  40fe07:	mov    QWORD PTR [rax+0x18],rcx
  40fe0b:	mov    QWORD PTR [rax+0x20],rdi
  40fe0f:	add    QWORD PTR [r13+0x2a68],r12
  40fe16:	add    QWORD PTR [r13+0x2a70],0x1
  40fe1e:	mov    rcx,r13
  40fe21:	call   4119d0 <__swc_fn_0a4ed24b_000140_055b38a4>
  40fe26:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40fe2f:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40fe38:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40fe41:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40fe4a:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40fe53:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40fe5c:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40fe65:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40fe6e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40fe77:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40fe80:	add    rsp,0x148
  40fe87:	pop    rsi
  40fe88:	pop    rdi
  40fe89:	pop    r15
  40fe8b:	pop    r14
  40fe8d:	pop    r13
  40fe8f:	pop    r12
  40fe91:	ret
	...

000000000040fea0 <__swc_fn_0a4ed24b_000065_d9ee99ea>:
  40fea0:	push   rbx
  40fea1:	push   r12
  40fea3:	push   r13
  40fea5:	push   r14
  40fea7:	push   r15
  40fea9:	push   rdi
  40feaa:	push   rsi
  40feab:	sub    rsp,0xf0
  40feb2:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40feb8:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40febe:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40fec4:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40feca:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40fed3:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40fedc:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40fee5:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40feee:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40fef7:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40ff00:	mov    eax,r8d
  40ff03:	mov    rbx,rcx
  40ff06:	mov    r12,rdx
  40ff09:	mov    QWORD PTR [rsp+0x18],rdx
  40ff0e:	mov    ecx,DWORD PTR [r12+0x58]
  40ff13:	mov    r13d,ecx
  40ff16:	cmp    ecx,0x10
  40ff19:	mov    ecx,0x10
  40ff1e:	cmovb  r13d,ecx
  40ff22:	test   r13d,r13d
  40ff25:	mov    rcx,r13
  40ff28:	mov    edx,0x8
  40ff2d:	cmove  ecx,edx
  40ff30:	dec    rcx
  40ff33:	mov    rdx,0xffffffffffffffff
  40ff3a:	sub    rdx,rcx
  40ff3d:	xor    r14d,r14d
  40ff40:	mov    r8,rcx
  40ff43:	not    r8
  40ff46:	lea    rcx,[rcx+0x58]
  40ff4a:	and    rcx,r8
  40ff4d:	cmp    rdx,0x58
  40ff51:	cmovae r14,rcx
  40ff55:	cmp    eax,0xffffffff
  40ff58:	jne    40ff61 <__swc_fn_0a4ed24b_000065_d9ee99ea+0xc1>
  40ff5a:	mov    r15,QWORD PTR [r12+0x48]
  40ff5f:	jmp    40ff93 <__swc_fn_0a4ed24b_000065_d9ee99ea+0xf3>
  40ff61:	test   eax,eax
  40ff63:	jne    40ff6c <__swc_fn_0a4ed24b_000065_d9ee99ea+0xcc>
  40ff65:	mov    eax,0x8
  40ff6a:	jmp    40ff90 <__swc_fn_0a4ed24b_000065_d9ee99ea+0xf0>
  40ff6c:	cmp    eax,0x8
  40ff6f:	ja     40ff77 <__swc_fn_0a4ed24b_000065_d9ee99ea+0xd7>
  40ff71:	shl    rax,0x4
  40ff75:	jmp    40ff90 <__swc_fn_0a4ed24b_000065_d9ee99ea+0xf0>
  40ff77:	lea    eax,[rax-0x9]
  40ff7a:	mov    ecx,eax
  40ff7c:	shr    ecx,0x2
  40ff7f:	and    eax,0x3
  40ff82:	lea    ecx,[rcx+0x7]
  40ff85:	lea    ecx,[rcx-0x2]
  40ff88:	lea    eax,[rax+0x5]
  40ff8b:	shlx   rax,rax,rcx
  40ff90:	mov    r15,rax
  40ff93:	lea    rax,[r14+r13*1]
  40ff97:	mov    rcx,0xffffffffffffffff
  40ff9e:	sub    rcx,rax
  40ffa1:	cmp    r15,rcx
  40ffa4:	jbe    40ffb4 <__swc_fn_0a4ed24b_000065_d9ee99ea+0x114>
  40ffa6:	mov    QWORD PTR [r12+0x40],0x0
  40ffaf:	jmp    410386 <__swc_fn_0a4ed24b_000065_d9ee99ea+0x4e6>
  40ffb4:	mov    QWORD PTR [rsp+0x20],r13
  40ffb9:	lea    r13,[rsp+0x8]
  40ffbe:	add    rax,r15
  40ffc1:	mov    ecx,0x1000
  40ffc6:	test   ecx,ecx
  40ffc8:	mov    edx,0x8
  40ffcd:	cmove  ecx,edx
  40ffd0:	dec    rcx
  40ffd3:	mov    rdx,0xffffffffffffffff
  40ffda:	sub    rdx,rcx
  40ffdd:	cmp    rax,rdx
  40ffe0:	jbe    40ffec <__swc_fn_0a4ed24b_000065_d9ee99ea+0x14c>
  40ffe2:	mov    QWORD PTR [r13+0x0],0x0
  40ffea:	jmp    40fff9 <__swc_fn_0a4ed24b_000065_d9ee99ea+0x159>
  40ffec:	add    rax,rcx
  40ffef:	andn   rax,rcx,rax
  40fff4:	mov    QWORD PTR [rsp+0x8],rax
  40fff9:	cmp    QWORD PTR [r13+0x0],0x0
  40fffe:	jne    41000e <__swc_fn_0a4ed24b_000065_d9ee99ea+0x16e>
  410000:	mov    QWORD PTR [r12+0x40],0x0
  410009:	jmp    410386 <__swc_fn_0a4ed24b_000065_d9ee99ea+0x4e6>
  41000e:	mov    QWORD PTR [rsp+0x30],r15
  410013:	xor    r15d,r15d
  410016:	mov    QWORD PTR [rsp+0x38],0x0
  41001f:	lea    r12,[rsp+0x10]
  410024:	mov    QWORD PTR [rsp+0x28],r14
  410029:	mov    r14,QWORD PTR [rsp+0x8]
  41002e:	mov    QWORD PTR [rsp+0x10],r14
  410033:	cmp    r14,0x10000
  41003a:	ja     410041 <__swc_fn_0a4ed24b_000065_d9ee99ea+0x1a1>
  41003c:	mov    rax,r14
  41003f:	jmp    410092 <__swc_fn_0a4ed24b_000065_d9ee99ea+0x1f2>
  410041:	xor    eax,eax
  410043:	lea    rcx,[r14-0x1]
  410047:	lzcnt  rax,rcx
  41004c:	mov    ecx,0x3f
  410051:	sub    rcx,rax
  410054:	mov    eax,0x1
  410059:	lea    rcx,[rcx-0x3]
  41005d:	shl    rax,cl
  410060:	mov    rcx,rax
  410063:	cmp    rax,0x1000
  41006a:	mov    eax,0x1000
  41006f:	cmovb  rcx,rax
  410073:	mov    rdx,0xffffffffffffffff
  41007a:	sub    rdx,rcx
  41007d:	mov    rax,r14
  410080:	lea    r8,[r14+rcx*1-0x1]
  410085:	neg    rcx
  410088:	and    r8,rcx
  41008b:	cmp    r14,rdx
  41008e:	cmovbe rax,r8
  410092:	mov    QWORD PTR [rsp+0x8],rax
  410097:	lea    rax,[rip+0x11f6a]        # 422008 <__swc_data_base_0a4ed24b+0x8>
  41009e:	mov    rax,QWORD PTR [rax]
  4100a1:	cmp    rax,0xffffffffffffffff
  4100a5:	je     4100b4 <__swc_fn_0a4ed24b_000065_d9ee99ea+0x214>
  4100a7:	mov    eax,eax
  4100a9:	mov    edi,eax
  4100ab:	xor    eax,eax
  4100ad:	call   407010 <pthread_getspecific@plt>
  4100b2:	jmp    4100b6 <__swc_fn_0a4ed24b_000065_d9ee99ea+0x216>
  4100b4:	xor    eax,eax
  4100b6:	test   rax,rax
  4100b9:	jne    4100c8 <__swc_fn_0a4ed24b_000065_d9ee99ea+0x228>
  4100bb:	call   40f540 <__swc_fn_0a4ed24b_000035_cd1a4e8c>
  4100c0:	mov    rcx,rax
  4100c3:	call   409be0 <__swc_fn_0a4ed24b_000132_5f757033>
  4100c8:	test   rax,rax
  4100cb:	je     4101bc <__swc_fn_0a4ed24b_000065_d9ee99ea+0x31c>
  4100d1:	cmp    QWORD PTR [rax],rbx
  4100d4:	jne    4101bc <__swc_fn_0a4ed24b_000065_d9ee99ea+0x31c>
  4100da:	cmp    DWORD PTR [rax+0x20],0x0
  4100de:	jne    4101bc <__swc_fn_0a4ed24b_000065_d9ee99ea+0x31c>
  4100e4:	mov    rcx,QWORD PTR [rsp+0x8]
  4100e9:	movabs rdx,0x7fffffffffffffff
  4100f3:	cmp    rcx,rdx
  4100f6:	mov    rdx,0xffffffffffffffff
  4100fd:	lea    r8,[rcx+rcx*1]
  410101:	cmovbe rdx,r8
  410105:	mov    r8d,DWORD PTR [rax+0x730]
  41010c:	mov    r9d,r8d
  41010f:	sub    rdx,rcx
  410112:	inc    rdx
  410115:	xor    r10d,r10d
  410118:	test   r8,r8
  41011b:	jbe    41014b <__swc_fn_0a4ed24b_000065_d9ee99ea+0x2ab>
  41011d:	nop    DWORD PTR [rax]
  410120:	mov    r11d,r10d
  410123:	lea    r11,[r11+r11*4]
  410127:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  41012f:	sub    r11,rcx
  410132:	cmp    r11,rdx
  410135:	jae    410142 <__swc_fn_0a4ed24b_000065_d9ee99ea+0x2a2>
  410137:	mov    r9d,r10d
  41013a:	mov    rdx,r11
  41013d:	test   r11,r11
  410140:	je     41014b <__swc_fn_0a4ed24b_000065_d9ee99ea+0x2ab>
  410142:	add    r10,0x1
  410146:	cmp    r10,r8
  410149:	jb     410120 <__swc_fn_0a4ed24b_000065_d9ee99ea+0x280>
  41014b:	mov    ecx,DWORD PTR [rax+0x730]
  410151:	cmp    r9d,ecx
  410154:	jne    41015a <__swc_fn_0a4ed24b_000065_d9ee99ea+0x2ba>
  410156:	xor    eax,eax
  410158:	jmp    4101b9 <__swc_fn_0a4ed24b_000065_d9ee99ea+0x319>
  41015a:	lea    rcx,[r9+r9*4]
  41015e:	lea    rcx,[rax+rcx*8+0x738]
  410166:	vmovups xmm0,XMMWORD PTR [rcx]
  41016a:	mov    rdx,QWORD PTR [rcx+0x10]
  41016e:	sub    DWORD PTR [rax+0x730],0x1
  410175:	mov    r8d,DWORD PTR [rax+0x730]
  41017c:	lea    r8,[r8+r8*4]
  410180:	lea    r8,[rax+r8*8+0x738]
  410188:	vmovups xmm1,XMMWORD PTR [r8]
  41018d:	vmovups XMMWORD PTR [rcx],xmm1
  410191:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  410197:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  41019c:	mov    rax,QWORD PTR [r8+0x20]
  4101a0:	mov    QWORD PTR [rcx+0x20],rax
  4101a4:	vpshufd xmm1,xmm0,0xee
  4101a9:	vmovsd QWORD PTR [rsp+0x8],xmm1
  4101af:	mov    QWORD PTR [rsp+0x10],rdx
  4101b4:	vmovq  rax,xmm0
  4101b9:	mov    r15,rax
  4101bc:	test   r15,r15
  4101bf:	jne    4101d7 <__swc_fn_0a4ed24b_000065_d9ee99ea+0x337>
  4101c1:	mov    rcx,rbx
  4101c4:	mov    rdx,QWORD PTR [rsp+0x8]
  4101c9:	mov    r8,r13
  4101cc:	mov    r9,r12
  4101cf:	call   40fa90 <__swc_fn_0a4ed24b_000059_2ca0cb05>
  4101d4:	mov    r15,rax
  4101d7:	test   r15,r15
  4101da:	je     41021b <__swc_fn_0a4ed24b_000065_d9ee99ea+0x37b>
  4101dc:	cmp    QWORD PTR [r12],r14
  4101e0:	jae    41021b <__swc_fn_0a4ed24b_000065_d9ee99ea+0x37b>
  4101e2:	mov    rax,r15
  4101e5:	add    rax,QWORD PTR [r12]
  4101e9:	mov    rdx,r14
  4101ec:	sub    rdx,QWORD PTR [r12]
  4101f0:	mov    rcx,rax
  4101f3:	call   40bba0 <__swc_fn_0a4ed24b_000007_f7acedb0>
  4101f8:	test   al,al
  4101fa:	je     410203 <__swc_fn_0a4ed24b_000065_d9ee99ea+0x363>
  4101fc:	mov    QWORD PTR [rsp+0x10],r14
  410201:	jmp    41021b <__swc_fn_0a4ed24b_000065_d9ee99ea+0x37b>
  410203:	mov    rcx,rbx
  410206:	mov    rdx,r15
  410209:	mov    r8,QWORD PTR [rsp+0x8]
  41020e:	mov    r9,QWORD PTR [rsp+0x10]
  410213:	call   40fba0 <__swc_fn_0a4ed24b_000062_b304235a>
  410218:	xor    r15d,r15d
  41021b:	test   r15,r15
  41021e:	jne    41029a <__swc_fn_0a4ed24b_000065_d9ee99ea+0x3fa>
  410220:	cmp    r14,0x10000
  410227:	ja     41022e <__swc_fn_0a4ed24b_000065_d9ee99ea+0x38e>
  410229:	mov    rax,r14
  41022c:	jmp    41027f <__swc_fn_0a4ed24b_000065_d9ee99ea+0x3df>
  41022e:	xor    eax,eax
  410230:	lea    rcx,[r14-0x1]
  410234:	lzcnt  rax,rcx
  410239:	mov    ecx,0x3f
  41023e:	sub    rcx,rax
  410241:	mov    eax,0x1
  410246:	lea    rcx,[rcx-0x3]
  41024a:	shl    rax,cl
  41024d:	mov    rcx,rax
  410250:	cmp    rax,0x1000
  410257:	mov    eax,0x1000
  41025c:	cmovb  rcx,rax
  410260:	mov    rdx,0xffffffffffffffff
  410267:	sub    rdx,rcx
  41026a:	mov    rax,r14
  41026d:	lea    r8,[r14+rcx*1-0x1]
  410272:	neg    rcx
  410275:	and    r8,rcx
  410278:	cmp    r14,rdx
  41027b:	cmovbe rax,r8
  41027f:	mov    QWORD PTR [rsp+0x8],rax
  410284:	mov    QWORD PTR [rsp+0x10],r14
  410289:	mov    rcx,rbx
  41028c:	mov    rdx,rax
  41028f:	mov    r8,r14
  410292:	call   40f600 <__swc_fn_0a4ed24b_000041_c90d80c1>
  410297:	mov    r15,rax
  41029a:	test   r15,r15
  41029d:	jne    4102ab <__swc_fn_0a4ed24b_000065_d9ee99ea+0x40b>
  41029f:	mov    r13,QWORD PTR [rsp+0x20]
  4102a4:	mov    rsi,QWORD PTR [rsp+0x38]
  4102a9:	jmp    4102e7 <__swc_fn_0a4ed24b_000065_d9ee99ea+0x447>
  4102ab:	mov    rax,r15
  4102ae:	add    rax,QWORD PTR [rsp+0x28]
  4102b3:	mov    r13,QWORD PTR [rsp+0x20]
  4102b8:	test   r13d,r13d
  4102bb:	mov    rcx,r13
  4102be:	mov    edx,0x8
  4102c3:	cmove  ecx,edx
  4102c6:	dec    rcx
  4102c9:	mov    rdx,0xffffffffffffffff
  4102d0:	sub    rdx,rcx
  4102d3:	cmp    rax,rdx
  4102d6:	jbe    4102dc <__swc_fn_0a4ed24b_000065_d9ee99ea+0x43c>
  4102d8:	xor    eax,eax
  4102da:	jmp    4102e4 <__swc_fn_0a4ed24b_000065_d9ee99ea+0x444>
  4102dc:	add    rax,rcx
  4102df:	andn   rax,rcx,rax
  4102e4:	mov    rsi,rax
  4102e7:	mov    rax,QWORD PTR [rsp+0x8]
  4102ec:	test   r15,r15
  4102ef:	je     4102f8 <__swc_fn_0a4ed24b_000065_d9ee99ea+0x458>
  4102f1:	mov    rdi,QWORD PTR [rsp+0x18]
  4102f6:	jmp    41030a <__swc_fn_0a4ed24b_000065_d9ee99ea+0x46a>
  4102f8:	mov    rdi,QWORD PTR [rsp+0x18]
  4102fd:	mov    QWORD PTR [rdi+0x40],0x0
  410305:	jmp    410386 <__swc_fn_0a4ed24b_000065_d9ee99ea+0x4e6>
  41030a:	lea    rdx,[rsi-0x58]
  41030e:	mov    QWORD PTR [rsi-0x58],r15
  410312:	mov    QWORD PTR [rsi-0x50],rax
  410316:	mov    rax,QWORD PTR [rsp+0x10]
  41031b:	mov    QWORD PTR [rsi-0x48],rax
  41031f:	mov    QWORD PTR [rsi-0x40],rsi
  410323:	mov    rax,QWORD PTR [rdi+0x48]
  410327:	mov    QWORD PTR [rsi-0x38],rax
  41032b:	mov    rax,QWORD PTR [rsp+0x30]
  410330:	mov    QWORD PTR [rsi-0x30],rax
  410334:	mov    DWORD PTR [rsi-0x10],r13d
  410338:	mov    QWORD PTR [rsi-0x28],0x0
  410340:	mov    QWORD PTR [rsi-0x20],0x0
  410348:	add    r15,QWORD PTR [r12]
  41034c:	sub    r15,rsi
  41034f:	mov    QWORD PTR [rsi-0x30],r15
  410353:	mov    rcx,QWORD PTR [rbx+0x250]
  41035a:	nop    WORD PTR [rax+rax*1+0x0]
  410360:	lea    r8,[rcx+r15*1]
  410364:	mov    rax,rcx
  410367:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  410370:	cmp    rax,rcx
  410373:	je     41037a <__swc_fn_0a4ed24b_000065_d9ee99ea+0x4da>
  410375:	mov    rcx,rax
  410378:	jmp    410360 <__swc_fn_0a4ed24b_000065_d9ee99ea+0x4c0>
  41037a:	mov    rcx,rbx
  41037d:	call   407f10 <__swc_fn_0a4ed24b_000057_7e1dbcb0>
  410382:	mov    QWORD PTR [rdi+0x40],rsi
  410386:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  41038c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  410392:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  410398:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  41039e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  4103a7:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  4103b0:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  4103b9:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  4103c2:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  4103cb:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  4103d4:	add    rsp,0xf0
  4103db:	pop    rsi
  4103dc:	pop    rdi
  4103dd:	pop    r15
  4103df:	pop    r14
  4103e1:	pop    r13
  4103e3:	pop    r12
  4103e5:	pop    rbx
  4103e6:	ret
	...

00000000004103f0 <__swc_fn_0a4ed24b_000068_f3aa21af>:
  4103f0:	push   rbx
  4103f1:	push   r12
  4103f3:	push   rdi
  4103f4:	push   rsi
  4103f5:	sub    rsp,0xb8
  4103fc:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  410402:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410408:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41040e:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410414:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  41041a:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  410420:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410426:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41042f:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410438:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  410441:	mov    rbx,rdx
  410444:	mov    r12,rcx
  410447:	cmp    DWORD PTR [rbx+0x58],0x0
  41044b:	je     410465 <__swc_fn_0a4ed24b_000068_f3aa21af+0x75>
  41044d:	mov    eax,DWORD PTR [rbx+0x58]
  410450:	sub    eax,0x1
  410453:	test   DWORD PTR [rbx+0x58],eax
  410456:	je     410465 <__swc_fn_0a4ed24b_000068_f3aa21af+0x75>
  410458:	mov    QWORD PTR [rbx+0x40],0x0
  410460:	jmp    410677 <__swc_fn_0a4ed24b_000068_f3aa21af+0x287>
  410465:	cmp    QWORD PTR [rbx+0x48],0x0
  41046a:	jne    410479 <__swc_fn_0a4ed24b_000068_f3aa21af+0x89>
  41046c:	mov    QWORD PTR [rbx+0x40],0x0
  410474:	jmp    410677 <__swc_fn_0a4ed24b_000068_f3aa21af+0x287>
  410479:	lea    rax,[rsp+0x8]
  41047e:	mov    rcx,QWORD PTR [rbx+0x48]
  410482:	cmp    rcx,0x8
  410486:	ja     410490 <__swc_fn_0a4ed24b_000068_f3aa21af+0xa0>
  410488:	mov    DWORD PTR [rax],0x0
  41048e:	jmp    4104eb <__swc_fn_0a4ed24b_000068_f3aa21af+0xfb>
  410490:	cmp    rcx,0x80
  410497:	ja     4104a7 <__swc_fn_0a4ed24b_000068_f3aa21af+0xb7>
  410499:	lea    rcx,[rcx+0xf]
  41049d:	shr    rcx,0x4
  4104a1:	mov    DWORD PTR [rsp+0x8],ecx
  4104a5:	jmp    4104eb <__swc_fn_0a4ed24b_000068_f3aa21af+0xfb>
  4104a7:	cmp    rcx,0x10000
  4104ae:	jbe    4104b8 <__swc_fn_0a4ed24b_000068_f3aa21af+0xc8>
  4104b0:	mov    DWORD PTR [rax],0xffffffff
  4104b6:	jmp    4104eb <__swc_fn_0a4ed24b_000068_f3aa21af+0xfb>
  4104b8:	dec    rcx
  4104bb:	xor    edx,edx
  4104bd:	lzcnt  rdx,rcx
  4104c2:	mov    r8d,0x3f
  4104c8:	sub    r8d,edx
  4104cb:	lea    edx,[r8-0x2]
  4104cf:	shrx   rcx,rcx,rdx
  4104d4:	and    ecx,0x3
  4104d7:	lea    edx,[r8-0x7]
  4104db:	lea    edx,[rdx*4+0x0]
  4104e2:	lea    edx,[rdx+0x9]
  4104e5:	add    edx,ecx
  4104e7:	mov    DWORD PTR [rsp+0x8],edx
  4104eb:	cmp    DWORD PTR [rax],0x0
  4104ee:	jne    4104fe <__swc_fn_0a4ed24b_000068_f3aa21af+0x10e>
  4104f0:	cmp    DWORD PTR [rbx+0x58],0x8
  4104f4:	jbe    4104fe <__swc_fn_0a4ed24b_000068_f3aa21af+0x10e>
  4104f6:	mov    DWORD PTR [rsp+0x8],0x1
  4104fe:	cmp    DWORD PTR [rbx+0x58],0x10
  410502:	jbe    410581 <__swc_fn_0a4ed24b_000068_f3aa21af+0x191>
  410508:	cmp    DWORD PTR [rbx+0x58],0x40
  41050c:	ja     410581 <__swc_fn_0a4ed24b_000068_f3aa21af+0x191>
  41050e:	cmp    DWORD PTR [rax],0xffffffff
  410511:	je     410581 <__swc_fn_0a4ed24b_000068_f3aa21af+0x191>
  410513:	mov    ecx,DWORD PTR [rsp+0x8]
  410517:	mov    edx,DWORD PTR [rbx+0x58]
  41051a:	dec    rdx
  41051d:	cmp    ecx,0x2d
  410520:	jae    410578 <__swc_fn_0a4ed24b_000068_f3aa21af+0x188>
  410522:	cs nop WORD PTR [rax+rax*1+0x0]
  41052c:	nop    DWORD PTR [rax+0x0]
  410530:	mov    r8d,ecx
  410533:	test   ecx,ecx
  410535:	jne    41053f <__swc_fn_0a4ed24b_000068_f3aa21af+0x14f>
  410537:	mov    r8d,0x8
  41053d:	jmp    41056b <__swc_fn_0a4ed24b_000068_f3aa21af+0x17b>
  41053f:	cmp    r8d,0x8
  410543:	ja     41054b <__swc_fn_0a4ed24b_000068_f3aa21af+0x15b>
  410545:	shl    r8,0x4
  410549:	jmp    41056b <__swc_fn_0a4ed24b_000068_f3aa21af+0x17b>
  41054b:	lea    r8d,[r8-0x9]
  41054f:	mov    r9d,r8d
  410552:	shr    r9d,0x2
  410556:	and    r8d,0x3
  41055a:	lea    r9d,[r9+0x7]
  41055e:	lea    r9d,[r9-0x2]
  410562:	lea    r8d,[r8+0x5]
  410566:	shlx   r8,r8,r9
  41056b:	test   r8,rdx
  41056e:	je     41057d <__swc_fn_0a4ed24b_000068_f3aa21af+0x18d>
  410570:	add    ecx,0x1
  410573:	cmp    ecx,0x2d
  410576:	jb     410530 <__swc_fn_0a4ed24b_000068_f3aa21af+0x140>
  410578:	mov    ecx,0xffffffff
  41057d:	mov    DWORD PTR [rsp+0x8],ecx
  410581:	mov    ecx,DWORD PTR [rsp+0x8]
  410585:	cmp    ecx,0xffffffff
  410588:	je     410590 <__swc_fn_0a4ed24b_000068_f3aa21af+0x1a0>
  41058a:	cmp    DWORD PTR [rbx+0x58],0x40
  41058e:	jbe    4105a3 <__swc_fn_0a4ed24b_000068_f3aa21af+0x1b3>
  410590:	mov    rcx,r12
  410593:	mov    rdx,rbx
  410596:	mov    r8d,DWORD PTR [rax]
  410599:	call   40fea0 <__swc_fn_0a4ed24b_000065_d9ee99ea>
  41059e:	jmp    410677 <__swc_fn_0a4ed24b_000068_f3aa21af+0x287>
  4105a3:	lea    rax,[rip+0x11a5e]        # 422008 <__swc_data_base_0a4ed24b+0x8>
  4105aa:	mov    rax,QWORD PTR [rax]
  4105ad:	cmp    rax,0xffffffffffffffff
  4105b1:	je     4105c0 <__swc_fn_0a4ed24b_000068_f3aa21af+0x1d0>
  4105b3:	mov    eax,eax
  4105b5:	mov    edi,eax
  4105b7:	xor    eax,eax
  4105b9:	call   407010 <pthread_getspecific@plt>
  4105be:	jmp    4105c2 <__swc_fn_0a4ed24b_000068_f3aa21af+0x1d2>
  4105c0:	xor    eax,eax
  4105c2:	test   rax,rax
  4105c5:	jne    4105d4 <__swc_fn_0a4ed24b_000068_f3aa21af+0x1e4>
  4105c7:	call   40f540 <__swc_fn_0a4ed24b_000035_cd1a4e8c>
  4105cc:	mov    rcx,rax
  4105cf:	call   409be0 <__swc_fn_0a4ed24b_000132_5f757033>
  4105d4:	test   rax,rax
  4105d7:	je     4105e4 <__swc_fn_0a4ed24b_000068_f3aa21af+0x1f4>
  4105d9:	cmp    QWORD PTR [rax],r12
  4105dc:	jne    4105e4 <__swc_fn_0a4ed24b_000068_f3aa21af+0x1f4>
  4105de:	cmp    DWORD PTR [rax+0x20],0x0
  4105e2:	je     4105ef <__swc_fn_0a4ed24b_000068_f3aa21af+0x1ff>
  4105e4:	mov    rcx,r12
  4105e7:	mov    rdx,rax
  4105ea:	call   407b50 <__swc_fn_0a4ed24b_000045_d8bd27c3>
  4105ef:	test   rax,rax
  4105f2:	jne    4105fe <__swc_fn_0a4ed24b_000068_f3aa21af+0x20e>
  4105f4:	mov    QWORD PTR [rbx+0x40],0x0
  4105fc:	jmp    410677 <__swc_fn_0a4ed24b_000068_f3aa21af+0x287>
  4105fe:	lea    r8,[rsp+0xc]
  410603:	mov    ecx,DWORD PTR [rsp+0x8]
  410607:	mov    DWORD PTR [rsp+0xc],ecx
  41060b:	mov    ecx,DWORD PTR [r8]
  41060e:	lea    rcx,[rcx+rcx*4]
  410612:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  410617:	test   rcx,rcx
  41061a:	je     410653 <__swc_fn_0a4ed24b_000068_f3aa21af+0x263>
  41061c:	mov    rdx,QWORD PTR [rcx]
  41061f:	test   rdx,rdx
  410622:	je     410630 <__swc_fn_0a4ed24b_000068_f3aa21af+0x240>
  410624:	mov    r9,QWORD PTR [rdx]
  410627:	mov    QWORD PTR [rcx],r9
  41062a:	add    DWORD PTR [rcx+0x28],0x1
  41062e:	jmp    41064e <__swc_fn_0a4ed24b_000068_f3aa21af+0x25e>
  410630:	mov    rdx,QWORD PTR [rcx+0x18]
  410634:	cmp    QWORD PTR [rcx+0x20],rdx
  410638:	jae    41064c <__swc_fn_0a4ed24b_000068_f3aa21af+0x25c>
  41063a:	mov    rdx,QWORD PTR [rcx+0x20]
  41063e:	mov    r9d,DWORD PTR [rcx+0x2c]
  410642:	add    QWORD PTR [rcx+0x20],r9
  410646:	add    DWORD PTR [rcx+0x28],0x1
  41064a:	jmp    41064e <__swc_fn_0a4ed24b_000068_f3aa21af+0x25e>
  41064c:	xor    edx,edx
  41064e:	test   rdx,rdx
  410651:	jne    410664 <__swc_fn_0a4ed24b_000068_f3aa21af+0x274>
  410653:	mov    rcx,r12
  410656:	mov    rdx,rax
  410659:	mov    r8d,DWORD PTR [r8]
  41065c:	call   407cc0 <__swc_fn_0a4ed24b_000054_faa92dcc>
  410661:	mov    rdx,rax
  410664:	test   rdx,rdx
  410667:	jne    410673 <__swc_fn_0a4ed24b_000068_f3aa21af+0x283>
  410669:	mov    QWORD PTR [rbx+0x40],0x0
  410671:	jmp    410677 <__swc_fn_0a4ed24b_000068_f3aa21af+0x287>
  410673:	mov    QWORD PTR [rbx+0x40],rdx
  410677:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  41067d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  410683:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410689:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41068f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410695:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  41069b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4106a1:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4106aa:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4106b3:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4106bc:	add    rsp,0xb8
  4106c3:	pop    rsi
  4106c4:	pop    rdi
  4106c5:	pop    r12
  4106c7:	pop    rbx
  4106c8:	ret
  4106c9:	add    BYTE PTR [rax],al
  4106cb:	add    BYTE PTR [rax],al
  4106cd:	add    BYTE PTR [rax],al
	...

00000000004106d0 <__swc_fn_0a4ed24b_000071_b3d7b28e>:
  4106d0:	ret
	...

00000000004106e0 <__swc_fn_0a4ed24b_000074_042643a3>:
  4106e0:	push   r12
  4106e2:	push   r13
  4106e4:	push   r14
  4106e6:	push   rdi
  4106e7:	push   rsi
  4106e8:	sub    rsp,0x1a0
  4106ef:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  4106f8:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  410701:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  41070a:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  410713:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  41071c:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  410725:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  41072e:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  410737:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  410740:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  410749:	mov    r12,rdx
  41074c:	mov    r13,rcx
  41074f:	mov    rax,QWORD PTR [r12+0x48]
  410754:	mov    ecx,DWORD PTR [r12+0x58]
  410759:	lea    rdx,[rax-0x1]
  41075d:	cmp    rdx,0x10000
  410764:	jae    41085e <__swc_fn_0a4ed24b_000074_042643a3+0x17e>
  41076a:	cmp    rax,0x8
  41076e:	ja     410775 <__swc_fn_0a4ed24b_000074_042643a3+0x95>
  410770:	xor    r14d,r14d
  410773:	jmp    4107c7 <__swc_fn_0a4ed24b_000074_042643a3+0xe7>
  410775:	cmp    rax,0x80
  41077c:	ja     410788 <__swc_fn_0a4ed24b_000074_042643a3+0xa8>
  41077e:	lea    r14,[rax+0xf]
  410782:	shr    r14,0x4
  410786:	jmp    4107c7 <__swc_fn_0a4ed24b_000074_042643a3+0xe7>
  410788:	cmp    rax,0x10000
  41078f:	jbe    410799 <__swc_fn_0a4ed24b_000074_042643a3+0xb9>
  410791:	mov    r14d,0xffffffff
  410797:	jmp    4107c7 <__swc_fn_0a4ed24b_000074_042643a3+0xe7>
  410799:	xor    eax,eax
  41079b:	lzcnt  rax,rdx
  4107a0:	mov    r8d,0x3f
  4107a6:	sub    r8d,eax
  4107a9:	lea    eax,[r8-0x2]
  4107ad:	shrx   rax,rdx,rax
  4107b2:	and    eax,0x3
  4107b5:	lea    edx,[r8-0x7]
  4107b9:	lea    edx,[rdx*4+0x0]
  4107c0:	lea    edx,[rdx+0x9]
  4107c3:	lea    r14d,[rdx+rax*1]
  4107c7:	cmp    ecx,0x8
  4107ca:	jbe    4107e3 <__swc_fn_0a4ed24b_000074_042643a3+0x103>
  4107cc:	cmp    ecx,0x10
  4107cf:	jne    41085e <__swc_fn_0a4ed24b_000074_042643a3+0x17e>
  4107d5:	test   r14d,r14d
  4107d8:	mov    eax,0x1
  4107dd:	cmove  r14d,eax
  4107e1:	jmp    4107ea <__swc_fn_0a4ed24b_000074_042643a3+0x10a>
  4107e3:	lea    eax,[rcx-0x1]
  4107e6:	test   eax,ecx
  4107e8:	jne    41085e <__swc_fn_0a4ed24b_000074_042643a3+0x17e>
  4107ea:	lea    rax,[rip+0x11817]        # 422008 <__swc_data_base_0a4ed24b+0x8>
  4107f1:	mov    rax,QWORD PTR [rax]
  4107f4:	cmp    rax,0xffffffffffffffff
  4107f8:	je     410807 <__swc_fn_0a4ed24b_000074_042643a3+0x127>
  4107fa:	mov    eax,eax
  4107fc:	mov    edi,eax
  4107fe:	xor    eax,eax
  410800:	call   407010 <pthread_getspecific@plt>
  410805:	jmp    410809 <__swc_fn_0a4ed24b_000074_042643a3+0x129>
  410807:	xor    eax,eax
  410809:	test   rax,rax
  41080c:	je     41085e <__swc_fn_0a4ed24b_000074_042643a3+0x17e>
  41080e:	cmp    QWORD PTR [rax],r13
  410811:	jne    41085e <__swc_fn_0a4ed24b_000074_042643a3+0x17e>
  410813:	lea    rcx,[r14+r14*4]
  410817:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  41081c:	test   rax,rax
  41081f:	je     41085e <__swc_fn_0a4ed24b_000074_042643a3+0x17e>
  410821:	mov    rcx,QWORD PTR [rax]
  410824:	test   rcx,rcx
  410827:	je     410835 <__swc_fn_0a4ed24b_000074_042643a3+0x155>
  410829:	mov    rdx,QWORD PTR [rcx]
  41082c:	mov    QWORD PTR [rax],rdx
  41082f:	add    DWORD PTR [rax+0x28],0x1
  410833:	jmp    410852 <__swc_fn_0a4ed24b_000074_042643a3+0x172>
  410835:	mov    rcx,QWORD PTR [rax+0x18]
  410839:	cmp    QWORD PTR [rax+0x20],rcx
  41083d:	jae    410850 <__swc_fn_0a4ed24b_000074_042643a3+0x170>
  41083f:	mov    rcx,QWORD PTR [rax+0x20]
  410843:	mov    edx,DWORD PTR [rax+0x2c]
  410846:	add    QWORD PTR [rax+0x20],rdx
  41084a:	add    DWORD PTR [rax+0x28],0x1
  41084e:	jmp    410852 <__swc_fn_0a4ed24b_000074_042643a3+0x172>
  410850:	xor    ecx,ecx
  410852:	test   rcx,rcx
  410855:	je     41085e <__swc_fn_0a4ed24b_000074_042643a3+0x17e>
  410857:	mov    QWORD PTR [r12+0x40],rcx
  41085c:	jmp    410869 <__swc_fn_0a4ed24b_000074_042643a3+0x189>
  41085e:	mov    rcx,r13
  410861:	mov    rdx,r12
  410864:	call   408740 <__swc_fn_0a4ed24b_000075_64d36d78>
  410869:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  410872:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  41087b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  410884:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  41088d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  410896:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  41089f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  4108a8:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  4108b1:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  4108ba:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  4108c3:	add    rsp,0x1a0
  4108ca:	pop    rsi
  4108cb:	pop    rdi
  4108cc:	pop    r14
  4108ce:	pop    r13
  4108d0:	pop    r12
  4108d2:	ret
	...

00000000004108e0 <__swc_fn_0a4ed24b_000077_7b195156>:
  4108e0:	push   r12
  4108e2:	push   r13
  4108e4:	push   r14
  4108e6:	push   r15
  4108e8:	push   rdi
  4108e9:	push   rsi
  4108ea:	sub    rsp,0x188
  4108f1:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  4108fa:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  410903:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  41090c:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  410915:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  41091e:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  410927:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  410930:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  410939:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  410942:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  41094b:	mov    r12,rdx
  41094e:	mov    r13,rcx
  410951:	mov    r14,QWORD PTR [r12+0x40]
  410956:	lea    rax,[rip+0x13733]        # 424090 <__swc_bss_base_0a4ed24b+0x50>
  41095d:	mov    rcx,r14
  410960:	sub    rcx,QWORD PTR [rax+0x8]
  410964:	mov    rax,QWORD PTR [rip+0x13735]        # 4240a0 <__swc_bss_base_0a4ed24b+0x60>
  41096b:	cmp    rcx,rax
  41096e:	jae    41099a <__swc_fn_0a4ed24b_000077_7b195156+0xba>
  410970:	mov    rax,r14
  410973:	and    rax,0xffffffffffc00000
  41097a:	mov    rcx,r14
  41097d:	shr    rcx,0x10
  410981:	and    ecx,0x3f
  410984:	mov    edx,DWORD PTR [rax+0x28]
  410987:	shrx   ecx,ecx,edx
  41098c:	shl    rcx,0x4
  410990:	lea    r15,[rax+rcx*8+0x80]
  410998:	jmp    4109a5 <__swc_fn_0a4ed24b_000077_7b195156+0xc5>
  41099a:	mov    rcx,r14
  41099d:	call   40f470 <__swc_fn_0a4ed24b_000026_bcdc5519>
  4109a2:	mov    r15,rax
  4109a5:	test   r15,r15
  4109a8:	je     410a4f <__swc_fn_0a4ed24b_000077_7b195156+0x16f>
  4109ae:	lea    rax,[rip+0x11653]        # 422008 <__swc_data_base_0a4ed24b+0x8>
  4109b5:	mov    rax,QWORD PTR [rax]
  4109b8:	cmp    rax,0xffffffffffffffff
  4109bc:	je     4109cb <__swc_fn_0a4ed24b_000077_7b195156+0xeb>
  4109be:	mov    eax,eax
  4109c0:	mov    edi,eax
  4109c2:	xor    eax,eax
  4109c4:	call   407010 <pthread_getspecific@plt>
  4109c9:	jmp    4109cd <__swc_fn_0a4ed24b_000077_7b195156+0xed>
  4109cb:	xor    eax,eax
  4109cd:	mov    rcx,QWORD PTR [r15+0x40]
  4109d1:	cmp    rcx,rax
  4109d4:	jne    410a34 <__swc_fn_0a4ed24b_000077_7b195156+0x154>
  4109d6:	test   rax,rax
  4109d9:	je     410a4f <__swc_fn_0a4ed24b_000077_7b195156+0x16f>
  4109db:	mov    ecx,DWORD PTR [r15+0x6c]
  4109df:	test   ecx,ecx
  4109e1:	je     410a01 <__swc_fn_0a4ed24b_000077_7b195156+0x121>
  4109e3:	mov    rcx,r13
  4109e6:	mov    rdx,rax
  4109e9:	mov    r8,r15
  4109ec:	mov    QWORD PTR [rsp+0xd8],rax
  4109f4:	call   407c50 <__swc_fn_0a4ed24b_000051_e072b516>
  4109f9:	mov    rax,QWORD PTR [rsp+0xd8]
  410a01:	mov    rcx,QWORD PTR [r15]
  410a04:	mov    QWORD PTR [r14],rcx
  410a07:	mov    QWORD PTR [r15],r14
  410a0a:	sub    DWORD PTR [r15+0x28],0x1
  410a0f:	jne    410a44 <__swc_fn_0a4ed24b_000077_7b195156+0x164>
  410a11:	movzx  ecx,BYTE PTR [r15+0x39]
  410a16:	lea    rcx,[rcx+rcx*4]
  410a1a:	lea    rcx,[rax+rcx*8+0x28]
  410a1f:	cmp    QWORD PTR [rcx],r15
  410a22:	je     410a44 <__swc_fn_0a4ed24b_000077_7b195156+0x164>
  410a24:	mov    rcx,r13
  410a27:	mov    rdx,rax
  410a2a:	mov    r8,r15
  410a2d:	call   40c680 <__swc_fn_0a4ed24b_000055_2e3450f7>
  410a32:	jmp    410a44 <__swc_fn_0a4ed24b_000077_7b195156+0x164>
  410a34:	test   rcx,rcx
  410a37:	je     410a4f <__swc_fn_0a4ed24b_000077_7b195156+0x16f>
  410a39:	mov    rcx,r15
  410a3c:	mov    rdx,r14
  410a3f:	call   40f0b0 <__swc_fn_0a4ed24b_000014_524c1f23>
  410a44:	mov    QWORD PTR [r12+0x40],0x0
  410a4d:	jmp    410a5a <__swc_fn_0a4ed24b_000077_7b195156+0x17a>
  410a4f:	mov    rcx,r13
  410a52:	mov    rdx,r12
  410a55:	call   408760 <__swc_fn_0a4ed24b_000078_1966ae2e>
  410a5a:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  410a63:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  410a6c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  410a75:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  410a7e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  410a87:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  410a90:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  410a99:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  410aa2:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  410aab:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  410ab4:	add    rsp,0x188
  410abb:	pop    rsi
  410abc:	pop    rdi
  410abd:	pop    r15
  410abf:	pop    r14
  410ac1:	pop    r13
  410ac3:	pop    r12
  410ac5:	ret
	...

0000000000410ad0 <__swc_fn_0a4ed24b_000080_d2cd17e2>:
  410ad0:	sub    rsp,0x8
  410ad4:	mov    rax,rdx
  410ad7:	mov    rdx,QWORD PTR [rax+0x40]
  410adb:	mov    r8,rax
  410ade:	call   4106d0 <__swc_fn_0a4ed24b_000071_b3d7b28e>
  410ae3:	add    rsp,0x8
  410ae7:	ret
	...

0000000000410af0 <__swc_fn_0a4ed24b_000083_4a10c7e7>:
  410af0:	push   rsi
  410af1:	push   rdi
  410af2:	sub    rsp,0x8
  410af6:	cmp    rcx,0xffffffffffffffef
  410afa:	ja     410b20 <__swc_fn_0a4ed24b_000083_4a10c7e7+0x30>
  410afc:	xor    esi,esi
  410afe:	lea    rax,[rcx+0x100f]
  410b05:	and    rax,0xfffffffffffff000
  410b0c:	lea    rcx,[rcx+0x10]
  410b10:	cmp    rcx,0xfffffffffffff000
  410b17:	cmovbe rsi,rax
  410b1b:	test   rsi,rsi
  410b1e:	jne    410b29 <__swc_fn_0a4ed24b_000083_4a10c7e7+0x39>
  410b20:	xor    eax,eax
  410b22:	add    rsp,0x8
  410b26:	pop    rdi
  410b27:	pop    rsi
  410b28:	ret
  410b29:	mov    rcx,rsi
  410b2c:	call   411180 <__swc_fn_0a4ed24b_000113_6b799b8d>
  410b31:	mov    rdi,rax
  410b34:	test   rax,rax
  410b37:	jne    410b42 <__swc_fn_0a4ed24b_000083_4a10c7e7+0x52>
  410b39:	xor    eax,eax
  410b3b:	add    rsp,0x8
  410b3f:	pop    rdi
  410b40:	pop    rsi
  410b41:	ret
  410b42:	mov    rcx,rdi
  410b45:	mov    rdx,rsi
  410b48:	call   40db40 <__swc_fn_0a4ed24b_000115_36905703>
  410b4d:	test   al,al
  410b4f:	jne    410b65 <__swc_fn_0a4ed24b_000083_4a10c7e7+0x75>
  410b51:	mov    rcx,rdi
  410b54:	mov    rdx,rsi
  410b57:	call   409890 <__swc_fn_0a4ed24b_000117_ed2d8fed>
  410b5c:	xor    eax,eax
  410b5e:	add    rsp,0x8
  410b62:	pop    rdi
  410b63:	pop    rsi
  410b64:	ret
  410b65:	mov    QWORD PTR [rdi],rsi
  410b68:	mov    QWORD PTR [rdi+0x8],0x0
  410b70:	lea    rax,[rdi+0x10]
  410b74:	add    rsp,0x8
  410b78:	pop    rdi
  410b79:	pop    rsi
  410b7a:	ret
  410b7b:	add    BYTE PTR [rax],al
  410b7d:	add    BYTE PTR [rax],al
	...

0000000000410b80 <__swc_fn_0a4ed24b_000086_3953ef98>:
  410b80:	sub    rsp,0x8
  410b84:	cmp    BYTE PTR [rcx+0x2c],0x10
  410b88:	jne    410b93 <__swc_fn_0a4ed24b_000086_3953ef98+0x13>
  410b8a:	test   DWORD PTR [rcx+0x28],0x80
  410b91:	je     410b9b <__swc_fn_0a4ed24b_000086_3953ef98+0x1b>
  410b93:	mov    rax,rcx
  410b96:	add    rsp,0x8
  410b9a:	ret
  410b9b:	mov    rcx,QWORD PTR [rcx+0x40]
  410b9f:	call   410b80 <__swc_fn_0a4ed24b_000086_3953ef98>
  410ba4:	add    rsp,0x8
  410ba8:	ret
	...

0000000000410bc0 <__swc_fn_0a4ed24b_000089_d182c4dc>:
  410bc0:	push   rsi
  410bc1:	push   rdi
  410bc2:	push   r12
  410bc4:	push   r13
  410bc6:	sub    rsp,0x8
  410bca:	mov    rsi,rdx
  410bcd:	mov    rdi,rcx
  410bd0:	xor    r8d,r8d
  410bd3:	call   40cea0 <__swc_fn_0a4ed24b_000094_63c1827b>
  410bd8:	test   al,al
  410bda:	je     410bec <__swc_fn_0a4ed24b_000089_d182c4dc+0x2c>
  410bdc:	mov    eax,0x1
  410be1:	add    rsp,0x8
  410be5:	pop    r13
  410be7:	pop    r12
  410be9:	pop    rdi
  410bea:	pop    rsi
  410beb:	ret
  410bec:	rex cmp BYTE PTR [rsi+0x2c],0xe
  410bf1:	je     410c00 <__swc_fn_0a4ed24b_000089_d182c4dc+0x40>
  410bf3:	xor    eax,eax
  410bf5:	add    rsp,0x8
  410bf9:	pop    r13
  410bfb:	pop    r12
  410bfd:	pop    rdi
  410bfe:	pop    rsi
  410bff:	ret
  410c00:	mov    r12,QWORD PTR [rsi+0x98]
  410c07:	mov    rax,QWORD PTR [rsi+0xa0]
  410c0e:	mov    rsi,rax
  410c11:	xor    r13d,r13d
  410c14:	test   rsi,rsi
  410c17:	je     410c74 <__swc_fn_0a4ed24b_000089_d182c4dc+0xb4>
  410c19:	cs nop WORD PTR [rax+rax*1+0x0]
  410c23:	cs nop WORD PTR [rax+rax*1+0x0]
  410c2d:	nop    DWORD PTR [rax]
  410c30:	lea    rax,[r13*8+0x0]
  410c38:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  410c3d:	mov    rcx,rax
  410c40:	call   410b80 <__swc_fn_0a4ed24b_000086_3953ef98>
  410c45:	cmp    BYTE PTR [rax+0x2c],0xe
  410c49:	jne    410c6a <__swc_fn_0a4ed24b_000089_d182c4dc+0xaa>
  410c4b:	mov    rcx,rdi
  410c4e:	mov    rdx,rax
  410c51:	call   410bc0 <__swc_fn_0a4ed24b_000089_d182c4dc>
  410c56:	test   al,al
  410c58:	je     410c6a <__swc_fn_0a4ed24b_000089_d182c4dc+0xaa>
  410c5a:	mov    eax,0x1
  410c5f:	add    rsp,0x8
  410c63:	pop    r13
  410c65:	pop    r12
  410c67:	pop    rdi
  410c68:	pop    rsi
  410c69:	ret
  410c6a:	add    r13,0x1
  410c6e:	sub    rsi,0x1
  410c72:	jne    410c30 <__swc_fn_0a4ed24b_000089_d182c4dc+0x70>
  410c74:	xor    eax,eax
  410c76:	add    rsp,0x8
  410c7a:	pop    r13
  410c7c:	pop    r12
  410c7e:	pop    rdi
  410c7f:	pop    rsi
  410c80:	ret
	...

0000000000410c90 <__swc_fn_0a4ed24b_000092_14c65203>:
  410c90:	sub    rsp,0x18
  410c94:	vxorps xmm0,xmm0,xmm0
  410c98:	vmovdqu XMMWORD PTR [rsp],xmm0
  410c9d:	call   408970 <__swc_fn_0a4ed24b_000093_c2567a3b>
  410ca2:	add    rsp,0x18
  410ca6:	ret
	...

0000000000410cb0 <__swc_fn_0a4ed24b_000095_ad13d15c>:
  410cb0:	sub    rsp,0x8
  410cb4:	mov    rcx,QWORD PTR [rip+0x16085]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  410cbb:	test   rcx,rcx
  410cbe:	jne    410cd0 <__swc_fn_0a4ed24b_000095_ad13d15c+0x20>
  410cc0:	call   40eaa0 <__swc_fn_0a4ed24b_000169_994c8876>
  410cc5:	lea    rcx,[rax+0x1]
  410cc9:	mov    QWORD PTR [rip+0x16070],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  410cd0:	dec    rcx
  410cd3:	call   40b660 <__swc_fn_0a4ed24b_000171_360af05d>
  410cd8:	mov    rax,QWORD PTR [rax+0xc0]
  410cdf:	and    eax,0x1
  410ce2:	setne  al
  410ce5:	add    rsp,0x8
  410ce9:	ret
	...

0000000000410d00 <__swc_fn_0a4ed24b_000098_4f209617>:
  410d00:	push   rbx
  410d01:	push   rsi
  410d02:	push   rdi
  410d03:	push   r12
  410d05:	sub    rsp,0x28
  410d09:	mov    rbx,rcx
  410d0c:	call   40d200 <__swc_fn_0a4ed24b_000097_4185993f>
  410d11:	mov    rcx,QWORD PTR [rip+0x16028]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  410d18:	test   rcx,rcx
  410d1b:	jne    410d2d <__swc_fn_0a4ed24b_000098_4f209617+0x2d>
  410d1d:	call   40eaa0 <__swc_fn_0a4ed24b_000169_994c8876>
  410d22:	lea    rcx,[rax+0x1]
  410d26:	mov    QWORD PTR [rip+0x16013],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  410d2d:	dec    rcx
  410d30:	call   40b660 <__swc_fn_0a4ed24b_000171_360af05d>
  410d35:	mov    rsi,rax
  410d38:	lea    rcx,[rsp+0x8]
  410d3d:	call   408db0 <__swc_fn_0a4ed24b_000096_93bfe675>
  410d42:	mov    rdi,QWORD PTR [rsi+0x9c0]
  410d49:	mov    r12,QWORD PTR [rsi+0xbe8]
  410d50:	lea    rcx,[rsi+0x10]
  410d54:	call   411cd0 <__swc_fn_0a4ed24b_000161_13ead2ff>
  410d59:	mov    rcx,rsi
  410d5c:	call   408f20 <__swc_fn_0a4ed24b_000105_5a85fcf5>
  410d61:	vxorps xmm0,xmm0,xmm0
  410d65:	xor    eax,eax
  410d67:	cs nop WORD PTR [rax+rax*1+0x0]
  410d71:	cs nop WORD PTR [rax+rax*1+0x0]
  410d7b:	nop    DWORD PTR [rax+rax*1+0x0]
  410d80:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  410d85:	add    rax,0x10
  410d89:	cmp    rax,0xbf0
  410d90:	jne    410d80 <__swc_fn_0a4ed24b_000098_4f209617+0x80>
  410d92:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  410d98:	vmovups XMMWORD PTR [rsi],xmm0
  410d9c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  410da2:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  410daa:	mov    QWORD PTR [rsi+0x9c0],rdi
  410db1:	mov    QWORD PTR [rsi+0xbe8],r12
  410db8:	mov    rcx,QWORD PTR [rip+0x15f81]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  410dbf:	test   rcx,rcx
  410dc2:	jne    410dd4 <__swc_fn_0a4ed24b_000098_4f209617+0xd4>
  410dc4:	call   40eaa0 <__swc_fn_0a4ed24b_000169_994c8876>
  410dc9:	lea    rcx,[rax+0x1]
  410dcd:	mov    QWORD PTR [rip+0x15f6c],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  410dd4:	dec    rcx
  410dd7:	call   40b660 <__swc_fn_0a4ed24b_000171_360af05d>
  410ddc:	mov    rsi,rax
  410ddf:	mov    QWORD PTR [rsi+0xc0],rbx
  410de6:	and    ebx,0x1
  410de9:	jne    410ded <__swc_fn_0a4ed24b_000098_4f209617+0xed>
  410deb:	xor    eax,eax
  410ded:	test   rbx,rbx
  410df0:	sete   al
  410df3:	xor    cl,cl
  410df5:	xor    dl,dl
  410df7:	xor    r8b,r8b
  410dfa:	xor    r9b,r9b
  410dfd:	xor    r10b,r10b
  410e00:	mov    r11,rax
  410e03:	call   408770 <__swc_fn_0a4ed24b_000081_5cc7acfc>
  410e08:	lea    rbx,[rsp+0x18]
  410e0d:	mov    rcx,rbx
  410e10:	call   408db0 <__swc_fn_0a4ed24b_000096_93bfe675>
  410e15:	lea    rcx,[rsi+0x10]
  410e19:	mov    edx,0x400000
  410e1e:	mov    r8,rbx
  410e21:	call   40e7e0 <__swc_fn_0a4ed24b_000163_8a3d304f>
  410e26:	lea    rcx,[rsi+0x68]
  410e2a:	mov    edx,0x4000
  410e2f:	mov    r8,rbx
  410e32:	call   40e7e0 <__swc_fn_0a4ed24b_000163_8a3d304f>
  410e37:	add    rsp,0x28
  410e3b:	pop    r12
  410e3d:	pop    rdi
  410e3e:	pop    rsi
  410e3f:	pop    rbx
  410e40:	ret
	...

0000000000410e50 <__swc_fn_0a4ed24b_000101_d0b19c14>:
  410e50:	push   rbx
  410e51:	push   rsi
  410e52:	sub    rsp,0x18
  410e56:	mov    rbx,rcx
  410e59:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  410e5e:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410e64:	mov    rsi,QWORD PTR [rbx+0x70]
  410e68:	lea    rcx,[rcx+0x18]
  410e6c:	call   411cd0 <__swc_fn_0a4ed24b_000161_13ead2ff>
  410e71:	lea    rcx,[rsp+0x8]
  410e76:	mov    rdx,rbx
  410e79:	mov    r8d,0x78
  410e7f:	call   40d260 <__swc_fn_0a4ed24b_000100_d4bdcaa4>
  410e84:	mov    rax,rsi
  410e87:	add    rsp,0x18
  410e8b:	pop    rsi
  410e8c:	pop    rbx
  410e8d:	ret
	...

0000000000410e90 <__swc_fn_0a4ed24b_000104_3c3b96fb>:
  410e90:	push   rsi
  410e91:	push   rdi
  410e92:	sub    rsp,0x8
  410e96:	cmp    QWORD PTR [rcx],0x0
  410e9a:	jne    410ea3 <__swc_fn_0a4ed24b_000104_3c3b96fb+0x13>
  410e9c:	add    rsp,0x8
  410ea0:	pop    rdi
  410ea1:	pop    rsi
  410ea2:	ret
  410ea3:	mov    rsi,QWORD PTR [rcx]
  410ea6:	mov    rax,QWORD PTR [rcx+0x8]
  410eaa:	test   rax,rax
  410ead:	je     410ec3 <__swc_fn_0a4ed24b_000104_3c3b96fb+0x33>
  410eaf:	test   DWORD PTR [rax+0x28],0x400000
  410eb6:	je     410ec3 <__swc_fn_0a4ed24b_000104_3c3b96fb+0x33>
  410eb8:	mov    rcx,QWORD PTR [rax+0x30]
  410ebc:	test   rcx,rcx
  410ebf:	cmovne rax,rcx
  410ec3:	lea    rdx,[rip+0x260e]        # 4134d8 <__swc_rdata_base_0a4ed24b+0x3c8>
  410eca:	lea    rcx,[rip+0x26ef]        # 4135c0 <__swc_rdata_base_0a4ed24b+0x4b0>
  410ed1:	mov    r8,rax
  410ed4:	xor    r9d,r9d
  410ed7:	xor    al,al
  410ed9:	mov    r10,rax
  410edc:	xor    r11d,r11d
  410edf:	call   410c90 <__swc_fn_0a4ed24b_000092_14c65203>
  410ee4:	test   rax,rax
  410ee7:	je     410ef7 <__swc_fn_0a4ed24b_000104_3c3b96fb+0x67>
  410ee9:	mov    rdi,QWORD PTR [rax+0x48]
  410eed:	test   rdi,rdi
  410ef0:	je     410ef7 <__swc_fn_0a4ed24b_000104_3c3b96fb+0x67>
  410ef2:	mov    rcx,rsi
  410ef5:	call   rdi
  410ef7:	add    rsp,0x8
  410efb:	pop    rdi
  410efc:	pop    rsi
  410efd:	ret
	...

0000000000410f00 <__swc_fn_0a4ed24b_000107_90faaa26>:
  410f00:	push   rbx
  410f01:	push   rsi
  410f02:	push   rdi
  410f03:	sub    rsp,0x20
  410f07:	mov    rbx,rdx
  410f0a:	mov    rsi,rcx
  410f0d:	mov    rcx,QWORD PTR [rip+0x15e2c]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  410f14:	test   rcx,rcx
  410f17:	jne    410f29 <__swc_fn_0a4ed24b_000107_90faaa26+0x29>
  410f19:	call   40eaa0 <__swc_fn_0a4ed24b_000169_994c8876>
  410f1e:	lea    rcx,[rax+0x1]
  410f22:	mov    QWORD PTR [rip+0x15e17],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  410f29:	dec    rcx
  410f2c:	call   40b660 <__swc_fn_0a4ed24b_000171_360af05d>
  410f31:	mov    rdi,rax
  410f34:	mov    rax,QWORD PTR [rdi+0xbd0]
  410f3b:	xor    ecx,ecx
  410f3d:	test   rax,rax
  410f40:	je     410f45 <__swc_fn_0a4ed24b_000107_90faaa26+0x45>
  410f42:	mov    rcx,QWORD PTR [rax]
  410f45:	call   40ebd0 <__swc_fn_0a4ed24b_000178_718d7b54>
  410f4a:	lea    rax,[rsp+0x8]
  410f4f:	lea    rcx,[rdi+0x9c8]
  410f56:	mov    QWORD PTR [rsp+0x8],rcx
  410f5b:	mov    QWORD PTR [rax+0x8],0x40
  410f63:	xor    ecx,ecx
  410f65:	mov    rdx,rax
  410f68:	call   4099c0 <__swc_fn_0a4ed24b_000123_4f256d58>
  410f6d:	mov    DWORD PTR [rdi+0xbc8],eax
  410f73:	mov    rdi,QWORD PTR [rdi+0x990]
  410f7a:	test   rdi,rdi
  410f7d:	je     410f87 <__swc_fn_0a4ed24b_000107_90faaa26+0x87>
  410f7f:	mov    rcx,rsi
  410f82:	mov    rdx,rbx
  410f85:	call   rdi
  410f87:	call   410cb0 <__swc_fn_0a4ed24b_000095_ad13d15c>
  410f8c:	test   al,al
  410f8e:	je     410f9e <__swc_fn_0a4ed24b_000107_90faaa26+0x9e>
  410f90:	mov    rcx,rsi
  410f93:	mov    rdx,rbx
  410f96:	xor    r8d,r8d
  410f99:	call   40dce0 <__swc_fn_0a4ed24b_000124_83db7238>
  410f9e:	mov    rcx,rsi
  410fa1:	mov    rdx,rbx
  410fa4:	call   40d360 <__swc_fn_0a4ed24b_000106_ffe51047>
  410fa9:	call   411530 <__swc_fn_0a4ed24b_000122_be2e2f68>
  410fae:	add    rsp,0x20
  410fb2:	pop    rdi
  410fb3:	pop    rsi
  410fb4:	pop    rbx
  410fb5:	ret
	...

0000000000410fc0 <__swc_fn_0a4ed24b_000110_3dc01326>:
  410fc0:	test   r8,r8
  410fc3:	jne    410fc8 <__swc_fn_0a4ed24b_000110_3dc01326+0x8>
  410fc5:	xor    eax,eax
  410fc7:	ret
  410fc8:	xor    eax,eax
  410fca:	nop    WORD PTR [rax+rax*1+0x0]
  410fd0:	mov    r9,r8
  410fd3:	sub    r9,rax
  410fd6:	cmp    r9,0x10
  410fda:	jb     411024 <__swc_fn_0a4ed24b_000110_3dc01326+0x64>
  410fdc:	lea    r9,[rcx+rax*1]
  410fe0:	lea    r10,[rdx+rax*1]
  410fe4:	vmovups xmm0,XMMWORD PTR [r10]
  410fe9:	vmovups xmm1,XMMWORD PTR [r9]
  410fee:	vpcmpeqb xmm0,xmm1,xmm0
  410ff2:	vpmovmskb r9d,xmm0
  410ff6:	cmp    r9d,0xffff
  410ffd:	je     41101e <__swc_fn_0a4ed24b_000110_3dc01326+0x5e>
  410fff:	not    r9d
  411002:	xor    r8d,r8d
  411005:	movzx  r9d,r9w
  411009:	tzcnt  r8d,r9d
  41100e:	add    rax,r8
  411011:	movzx  ecx,BYTE PTR [rcx+rax*1]
  411015:	movzx  eax,BYTE PTR [rdx+rax*1]
  411019:	sub    ecx,eax
  41101b:	mov    eax,ecx
  41101d:	ret
  41101e:	lea    rax,[rax+0x10]
  411022:	jmp    410fd0 <__swc_fn_0a4ed24b_000110_3dc01326+0x10>
  411024:	cmp    r9,0x8
  411028:	jb     41109b <__swc_fn_0a4ed24b_000110_3dc01326+0xdb>
  41102a:	lea    r9,[rcx+rax*1]
  41102e:	lea    r10,[rdx+rax*1]
  411032:	mov    r9,QWORD PTR [r9]
  411035:	xor    r9,QWORD PTR [r10]
  411038:	test   r9,r9
  41103b:	je     411059 <__swc_fn_0a4ed24b_000110_3dc01326+0x99>
  41103d:	xor    r8d,r8d
  411040:	tzcnt  r8,r9
  411045:	shr    r8,0x3
  411049:	add    rax,r8
  41104c:	movzx  ecx,BYTE PTR [rcx+rax*1]
  411050:	movzx  eax,BYTE PTR [rdx+rax*1]
  411054:	sub    ecx,eax
  411056:	mov    eax,ecx
  411058:	ret
  411059:	lea    rax,[rax+0x8]
  41105d:	cmp    rax,r8
  411060:	jne    411065 <__swc_fn_0a4ed24b_000110_3dc01326+0xa5>
  411062:	xor    eax,eax
  411064:	ret
  411065:	lea    rax,[r8-0x8]
  411069:	lea    r8,[rcx+rax*1]
  41106d:	lea    r9,[rdx+rax*1]
  411071:	mov    r8,QWORD PTR [r8]
  411074:	xor    r8,QWORD PTR [r9]
  411077:	test   r8,r8
  41107a:	je     411098 <__swc_fn_0a4ed24b_000110_3dc01326+0xd8>
  41107c:	xor    r9d,r9d
  41107f:	tzcnt  r9,r8
  411084:	shr    r9,0x3
  411088:	add    rax,r9
  41108b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  41108f:	movzx  eax,BYTE PTR [rdx+rax*1]
  411093:	sub    ecx,eax
  411095:	mov    eax,ecx
  411097:	ret
  411098:	xor    eax,eax
  41109a:	ret
  41109b:	cmp    r9,0x4
  41109f:	jb     411112 <__swc_fn_0a4ed24b_000110_3dc01326+0x152>
  4110a1:	lea    r9,[rcx+rax*1]
  4110a5:	lea    r10,[rdx+rax*1]
  4110a9:	mov    r9d,DWORD PTR [r9]
  4110ac:	xor    r9d,DWORD PTR [r10]
  4110af:	test   r9d,r9d
  4110b2:	je     4110d0 <__swc_fn_0a4ed24b_000110_3dc01326+0x110>
  4110b4:	xor    r8d,r8d
  4110b7:	tzcnt  r8,r9
  4110bc:	shr    r8,0x3
  4110c0:	add    rax,r8
  4110c3:	movzx  ecx,BYTE PTR [rcx+rax*1]
  4110c7:	movzx  eax,BYTE PTR [rdx+rax*1]
  4110cb:	sub    ecx,eax
  4110cd:	mov    eax,ecx
  4110cf:	ret
  4110d0:	lea    rax,[rax+0x4]
  4110d4:	cmp    rax,r8
  4110d7:	jne    4110dc <__swc_fn_0a4ed24b_000110_3dc01326+0x11c>
  4110d9:	xor    eax,eax
  4110db:	ret
  4110dc:	lea    rax,[r8-0x4]
  4110e0:	lea    r8,[rcx+rax*1]
  4110e4:	lea    r9,[rdx+rax*1]
  4110e8:	mov    r8d,DWORD PTR [r8]
  4110eb:	xor    r8d,DWORD PTR [r9]
  4110ee:	test   r8d,r8d
  4110f1:	je     41110f <__swc_fn_0a4ed24b_000110_3dc01326+0x14f>
  4110f3:	xor    r9d,r9d
  4110f6:	tzcnt  r9,r8
  4110fb:	shr    r9,0x3
  4110ff:	add    rax,r9
  411102:	movzx  ecx,BYTE PTR [rcx+rax*1]
  411106:	movzx  eax,BYTE PTR [rdx+rax*1]
  41110a:	sub    ecx,eax
  41110c:	mov    eax,ecx
  41110e:	ret
  41110f:	xor    eax,eax
  411111:	ret
  411112:	cmp    r9,0x2
  411116:	jb     411169 <__swc_fn_0a4ed24b_000110_3dc01326+0x1a9>
  411118:	lea    r9,[rcx+rax*1]
  41111c:	lea    r10,[rdx+rax*1]
  411120:	mov    r9w,WORD PTR [r9]
  411124:	xor    r9w,WORD PTR [r10]
  411128:	test   r9w,r9w
  41112c:	je     41114e <__swc_fn_0a4ed24b_000110_3dc01326+0x18e>
  41112e:	xor    r8d,r8d
  411131:	movzx  r9d,r9w
  411135:	tzcnt  r8,r9
  41113a:	shr    r8,0x3
  41113e:	add    rax,r8
  411141:	movzx  ecx,BYTE PTR [rcx+rax*1]
  411145:	movzx  eax,BYTE PTR [rdx+rax*1]
  411149:	sub    ecx,eax
  41114b:	mov    eax,ecx
  41114d:	ret
  41114e:	lea    rax,[rax+0x2]
  411152:	cmp    rax,r8
  411155:	jne    41115a <__swc_fn_0a4ed24b_000110_3dc01326+0x19a>
  411157:	xor    eax,eax
  411159:	ret
  41115a:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  411160:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  411166:	sub    eax,ecx
  411168:	ret
  411169:	test   r9,r9
  41116c:	je     41117b <__swc_fn_0a4ed24b_000110_3dc01326+0x1bb>
  41116e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  411172:	movzx  eax,BYTE PTR [rdx+rax*1]
  411176:	sub    ecx,eax
  411178:	mov    eax,ecx
  41117a:	ret
  41117b:	xor    eax,eax
  41117d:	ret
	...

0000000000411180 <__swc_fn_0a4ed24b_000113_6b799b8d>:
  411180:	push   r12
  411182:	push   r13
  411184:	push   r14
  411186:	push   rdi
  411187:	push   rsi
  411188:	push   r15
  41118a:	sub    rsp,0xd8
  411191:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  411197:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  41119d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  4111a3:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  4111a9:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  4111af:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  4111b8:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  4111c1:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  4111ca:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  4111d3:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  4111dc:	mov    r12,rcx
  4111df:	test   rcx,rcx
  4111e2:	je     4111fe <__swc_fn_0a4ed24b_000113_6b799b8d+0x7e>
  4111e4:	mov    eax,r12d
  4111e7:	and    eax,0xfff
  4111ed:	setne  al
  4111f0:	cmp    r12,0xffffffffffffefff
  4111f7:	seta   cl
  4111fa:	or     al,cl
  4111fc:	je     411205 <__swc_fn_0a4ed24b_000113_6b799b8d+0x85>
  4111fe:	xor    eax,eax
  411200:	jmp    41129b <__swc_fn_0a4ed24b_000113_6b799b8d+0x11b>
  411205:	call   40da00 <__swc_fn_0a4ed24b_000112_126150d1>
  41120a:	mov    r13,rax
  41120d:	test   rax,rax
  411210:	jne    411219 <__swc_fn_0a4ed24b_000113_6b799b8d+0x99>
  411212:	xor    eax,eax
  411214:	jmp    41129b <__swc_fn_0a4ed24b_000113_6b799b8d+0x11b>
  411219:	lea    r14,[r12+0x1000]
  411221:	xor    edi,edi
  411223:	mov    rsi,r14
  411226:	xor    edx,edx
  411228:	mov    ecx,0x22
  41122d:	mov    eax,0xffffffff
  411232:	movsxd r8,eax
  411235:	xor    r9d,r9d
  411238:	xor    eax,eax
  41123a:	call   4070e0 <mmap@plt>
  41123f:	mov    r15,rax
  411242:	cmp    rax,0xffffffffffffffff
  411246:	jne    41124c <__swc_fn_0a4ed24b_000113_6b799b8d+0xcc>
  411248:	xor    eax,eax
  41124a:	jmp    41129b <__swc_fn_0a4ed24b_000113_6b799b8d+0x11b>
  41124c:	mov    rdi,r15
  41124f:	mov    esi,0x1000
  411254:	mov    edx,0x3
  411259:	xor    eax,eax
  41125b:	call   407170 <mprotect@plt>
  411260:	test   eax,eax
  411262:	je     411275 <__swc_fn_0a4ed24b_000113_6b799b8d+0xf5>
  411264:	mov    rdi,r15
  411267:	mov    rsi,r14
  41126a:	xor    eax,eax
  41126c:	call   407160 <munmap@plt>
  411271:	xor    eax,eax
  411273:	jmp    41129b <__swc_fn_0a4ed24b_000113_6b799b8d+0x11b>
  411275:	mov    QWORD PTR [r15+0x8],r12
  411279:	mov    rcx,r13
  41127c:	call   4118d0 <__swc_fn_0a4ed24b_000137_8c07c14b>
  411281:	mov    rax,QWORD PTR [r13+0x8]
  411285:	mov    QWORD PTR [r15],rax
  411288:	mov    QWORD PTR [r13+0x8],r15
  41128c:	mov    rcx,r13
  41128f:	call   409d60 <__swc_fn_0a4ed24b_000138_715e84ff>
  411294:	lea    rax,[r15+0x1000]
  41129b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  4112a1:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  4112a7:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  4112ad:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  4112b3:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  4112b9:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  4112c2:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  4112cb:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  4112d4:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  4112dd:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  4112e6:	add    rsp,0xd8
  4112ed:	pop    r15
  4112ef:	pop    rsi
  4112f0:	pop    rdi
  4112f1:	pop    r14
  4112f3:	pop    r13
  4112f5:	pop    r12
  4112f7:	ret
	...

0000000000411300 <__swc_fn_0a4ed24b_000116_e9fc0224>:
  411300:	push   rbx
  411301:	push   r12
  411303:	push   rdi
  411304:	push   rsi
  411305:	sub    rsp,0xa8
  41130c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  411312:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411318:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41131e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411324:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  41132a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  411330:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411336:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  41133c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411345:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41134e:	mov    rbx,rdx
  411351:	mov    r12,rcx
  411354:	mov    rdi,rcx
  411357:	mov    rsi,rdx
  41135a:	xor    edx,edx
  41135c:	xor    eax,eax
  41135e:	call   407170 <mprotect@plt>
  411363:	test   eax,eax
  411365:	jne    411389 <__swc_fn_0a4ed24b_000116_e9fc0224+0x89>
  411367:	mov    rcx,r12
  41136a:	mov    rdx,rbx
  41136d:	xor    al,al
  41136f:	mov    r8,rax
  411372:	call   409800 <__swc_fn_0a4ed24b_000114_5f48311c>
  411377:	mov    rdi,r12
  41137a:	mov    rsi,rbx
  41137d:	mov    edx,0x4
  411382:	xor    eax,eax
  411384:	call   4071d0 <madvise@plt>
  411389:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41138f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411395:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41139b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4113a1:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4113a7:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4113ad:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4113b3:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4113b9:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4113c2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4113cb:	add    rsp,0xa8
  4113d2:	pop    rsi
  4113d3:	pop    rdi
  4113d4:	pop    r12
  4113d6:	pop    rbx
  4113d7:	ret
	...

00000000004113e0 <__swc_fn_0a4ed24b_000119_d3318640>:
  4113e0:	push   rsi
  4113e1:	push   rdi
  4113e2:	push   r12
  4113e4:	push   r13
  4113e6:	push   r14
  4113e8:	sub    rsp,0xe0
  4113ef:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  4113f5:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  4113fb:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  411401:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  411407:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  41140d:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  411416:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  41141f:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  411428:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  411431:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  41143a:	mov    rsi,rdx
  41143d:	mov    rdi,rcx
  411440:	call   40da00 <__swc_fn_0a4ed24b_000112_126150d1>
  411445:	mov    r12,rax
  411448:	test   rax,rax
  41144b:	jne    411452 <__swc_fn_0a4ed24b_000119_d3318640+0x72>
  41144d:	jmp    4114c6 <__swc_fn_0a4ed24b_000119_d3318640+0xe6>
  411452:	mov    rcx,r12
  411455:	call   4118d0 <__swc_fn_0a4ed24b_000137_8c07c14b>
  41145a:	lea    r13,[r12+0x8]
  41145f:	mov    rax,QWORD PTR [r13+0x0]
  411463:	test   rax,rax
  411466:	je     4114be <__swc_fn_0a4ed24b_000119_d3318640+0xde>
  411468:	nop    DWORD PTR [rax+rax*1+0x0]
  411470:	lea    rcx,[rax+0x1000]
  411477:	cmp    rcx,rdi
  41147a:	jne    4114b2 <__swc_fn_0a4ed24b_000119_d3318640+0xd2>
  41147c:	cmp    QWORD PTR [rax+0x8],rsi
  411480:	je     41148c <__swc_fn_0a4ed24b_000119_d3318640+0xac>
  411482:	mov    rcx,r12
  411485:	call   409d60 <__swc_fn_0a4ed24b_000138_715e84ff>
  41148a:	jmp    4114c6 <__swc_fn_0a4ed24b_000119_d3318640+0xe6>
  41148c:	mov    r14,QWORD PTR [rax]
  41148f:	mov    rdi,rax
  411492:	lea    rsi,[rsi+0x1000]
  411499:	xor    eax,eax
  41149b:	call   407160 <munmap@plt>
  4114a0:	test   eax,eax
  4114a2:	jne    4114a8 <__swc_fn_0a4ed24b_000119_d3318640+0xc8>
  4114a4:	mov    QWORD PTR [r13+0x0],r14
  4114a8:	mov    rcx,r12
  4114ab:	call   409d60 <__swc_fn_0a4ed24b_000138_715e84ff>
  4114b0:	jmp    4114c6 <__swc_fn_0a4ed24b_000119_d3318640+0xe6>
  4114b2:	mov    r13,rax
  4114b5:	mov    rax,QWORD PTR [r13+0x0]
  4114b9:	test   rax,rax
  4114bc:	jne    411470 <__swc_fn_0a4ed24b_000119_d3318640+0x90>
  4114be:	mov    rcx,r12
  4114c1:	call   409d60 <__swc_fn_0a4ed24b_000138_715e84ff>
  4114c6:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  4114cc:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  4114d2:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  4114d8:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  4114de:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  4114e4:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  4114ed:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  4114f6:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  4114ff:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  411508:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  411511:	add    rsp,0xe0
  411518:	pop    r14
  41151a:	pop    r13
  41151c:	pop    r12
  41151e:	pop    rdi
  41151f:	pop    rsi
  411520:	ret
	...

0000000000411530 <__swc_fn_0a4ed24b_000122_be2e2f68>:
  411530:	push   rdi
  411531:	push   rsi
  411532:	sub    rsp,0xa8
  411539:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41153f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411545:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41154b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411551:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411557:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41155d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411563:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411569:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411572:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41157b:	mov    rdi,0xfffffffffffffd66
  411582:	xor    eax,eax
  411584:	call   407180 <exit@plt>
  411589:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41158f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411595:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41159b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4115a1:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4115a7:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4115ad:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4115b3:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4115b9:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4115c2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4115cb:	add    rsp,0xa8
  4115d2:	pop    rsi
  4115d3:	pop    rdi
  4115d4:	ret
	...

00000000004115e0 <__swc_fn_0a4ed24b_000125_540bf7e8>:
  4115e0:	push   rbx
  4115e1:	push   rsi
  4115e2:	push   rdi
  4115e3:	sub    rsp,0x30
  4115e7:	mov    rbx,rdx
  4115ea:	mov    esi,ecx
  4115ec:	test   ecx,ecx
  4115ee:	je     4116c3 <__swc_fn_0a4ed24b_000125_540bf7e8+0xe3>
  4115f4:	mov    rcx,rsi
  4115f7:	shl    rcx,0x4
  4115fb:	call   410af0 <__swc_fn_0a4ed24b_000083_4a10c7e7>
  411600:	test   rax,rax
  411603:	je     4116b2 <__swc_fn_0a4ed24b_000125_540bf7e8+0xd2>
  411609:	mov    rcx,rsi
  41160c:	xor    edx,edx
  41160e:	test   rsi,rsi
  411611:	jbe    411692 <__swc_fn_0a4ed24b_000125_540bf7e8+0xb2>
  411617:	nop    WORD PTR [rax+rax*1+0x0]
  411620:	mov    r8d,edx
  411623:	mov    r9,QWORD PTR [rbx+r8*8]
  411627:	add    r8,r8
  41162a:	lea    r8,[rax+r8*8]
  41162e:	xor    r10d,r10d
  411631:	test   r9,r9
  411634:	je     411670 <__swc_fn_0a4ed24b_000125_540bf7e8+0x90>
  411636:	mov    r11,r9
  411639:	mov    dil,BYTE PTR [r11]
  41163c:	test   dil,dil
  41163f:	je     411670 <__swc_fn_0a4ed24b_000125_540bf7e8+0x90>
  411641:	cs nop WORD PTR [rax+rax*1+0x0]
  41164b:	cs nop WORD PTR [rax+rax*1+0x0]
  411655:	cs nop WORD PTR [rax+rax*1+0x0]
  41165f:	nop
  411660:	add    r11,0x1
  411664:	add    r10,0x1
  411668:	mov    dil,BYTE PTR [r11]
  41166b:	test   dil,dil
  41166e:	jne    411660 <__swc_fn_0a4ed24b_000125_540bf7e8+0x80>
  411670:	mov    QWORD PTR [rsp+0x18],r9
  411675:	mov    QWORD PTR [rsp+0x20],r10
  41167a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411680:	vmovups XMMWORD PTR [r8],xmm0
  411685:	add    rdx,0x1
  411689:	cmp    rdx,rcx
  41168c:	jb     411620 <__swc_fn_0a4ed24b_000125_540bf7e8+0x40>
  411692:	lea    rcx,[rip+0x156b7]        # 426d50 <__swc_bss_base_0a4ed24b+0x2d10>
  411699:	mov    QWORD PTR [rsp+0x8],rax
  41169e:	mov    esi,esi
  4116a0:	mov    QWORD PTR [rsp+0x10],rsi
  4116a5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4116ab:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4116b0:	jmp    4116c3 <__swc_fn_0a4ed24b_000125_540bf7e8+0xe3>
  4116b2:	lea    rcx,[rip+0x2117]        # 4137d0 <__swc_rdata_base_0a4ed24b+0x6c0>
  4116b9:	call   4098b0 <__swc_fn_0a4ed24b_000120_2648f149>
  4116be:	call   411530 <__swc_fn_0a4ed24b_000122_be2e2f68>
  4116c3:	add    rsp,0x30
  4116c7:	pop    rdi
  4116c8:	pop    rsi
  4116c9:	pop    rbx
  4116ca:	ret
  4116cb:	add    BYTE PTR [rax],al
  4116cd:	add    BYTE PTR [rax],al
	...

00000000004116d0 <__swc_fn_0a4ed24b_000128_a481cb88>:
  4116d0:	push   rdi
  4116d1:	push   rsi
  4116d2:	sub    rsp,0xa8
  4116d9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4116df:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4116e5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4116eb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4116f1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4116f7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4116fd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411703:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411709:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411712:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41171b:	mov    edi,ecx
  41171d:	xor    eax,eax
  41171f:	call   4071e0 <pthread_key_delete@plt>
  411724:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41172a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411730:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411736:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41173c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411742:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411748:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41174e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411754:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41175d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411766:	add    rsp,0xa8
  41176d:	pop    rsi
  41176e:	pop    rdi
  41176f:	ret

0000000000411770 <__swc_fn_0a4ed24b_000131_a611b8c4>:
  411770:	push   rdi
  411771:	push   rsi
  411772:	sub    rsp,0xa8
  411779:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41177f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411785:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41178b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411791:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411797:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41179d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4117a3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4117a9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4117b2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4117bb:	test   rcx,rcx
  4117be:	je     4117cf <__swc_fn_0a4ed24b_000131_a611b8c4+0x5f>
  4117c0:	lea    rax,[rcx-0x1]
  4117c4:	mov    eax,eax
  4117c6:	mov    edi,eax
  4117c8:	xor    eax,eax
  4117ca:	call   4071e0 <pthread_key_delete@plt>
  4117cf:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4117d5:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4117db:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4117e1:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4117e7:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4117ed:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4117f3:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4117f9:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4117ff:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411808:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411811:	add    rsp,0xa8
  411818:	pop    rsi
  411819:	pop    rdi
  41181a:	ret
  41181b:	add    BYTE PTR [rax],al
  41181d:	add    BYTE PTR [rax],al
	...

0000000000411820 <__swc_fn_0a4ed24b_000134_a9c1c700>:
  411820:	push   rsi
  411821:	push   rdi
  411822:	sub    rsp,0xa8
  411829:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41182f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411835:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41183b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411841:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411847:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41184d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411853:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411859:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411862:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41186b:	xor    eax,eax
  41186d:	call   4071f0 <gettid@plt>
  411872:	movsxd rax,eax
  411875:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41187b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411881:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411887:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41188d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411893:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411899:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41189f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4118a5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4118ae:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4118b7:	add    rsp,0xa8
  4118be:	pop    rdi
  4118bf:	pop    rsi
  4118c0:	ret
	...

00000000004118d0 <__swc_fn_0a4ed24b_000137_8c07c14b>:
  4118d0:	push   rbx
  4118d1:	push   rdi
  4118d2:	push   rsi
  4118d3:	sub    rsp,0xc0
  4118da:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4118e0:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4118e6:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4118ec:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4118f2:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4118f8:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4118fe:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  411904:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41190d:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  411916:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41191f:	mov    rbx,rcx
  411922:	cs nop WORD PTR [rax+rax*1+0x0]
  41192c:	nop    DWORD PTR [rax+0x0]
  411930:	mov    edx,0x80000000
  411935:	xor    eax,eax
  411937:	lock cmpxchg DWORD PTR [rbx],edx
  41193b:	test   eax,eax
  41193d:	je     411974 <__swc_fn_0a4ed24b_000137_8c07c14b+0xa4>
  41193f:	mov    eax,DWORD PTR [rbx]
  411941:	lea    rcx,[rsp+0x14]
  411946:	mov    DWORD PTR [rsp+0x14],eax
  41194a:	test   eax,eax
  41194c:	je     411930 <__swc_fn_0a4ed24b_000137_8c07c14b+0x60>
  41194e:	mov    QWORD PTR [rsp],0x0
  411956:	mov    edi,0xca
  41195b:	mov    rsi,rbx
  41195e:	mov    edx,0x80
  411963:	mov    ecx,DWORD PTR [rcx]
  411965:	xor    r8d,r8d
  411968:	xor    r9d,r9d
  41196b:	xor    eax,eax
  41196d:	call   4071a0 <syscall@plt>
  411972:	jmp    411930 <__swc_fn_0a4ed24b_000137_8c07c14b+0x60>
  411974:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  41197a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  411980:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  411986:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41198c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  411992:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  411998:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41199e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4119a7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4119b0:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4119b9:	add    rsp,0xc0
  4119c0:	pop    rsi
  4119c1:	pop    rdi
  4119c2:	pop    rbx
  4119c3:	ret
	...

00000000004119d0 <__swc_fn_0a4ed24b_000140_055b38a4>:
  4119d0:	sub    rsp,0x8
  4119d4:	call   409d60 <__swc_fn_0a4ed24b_000138_715e84ff>
  4119d9:	add    rsp,0x8
  4119dd:	ret
	...

00000000004119e0 <__swc_fn_0a4ed24b_000143_d299b428>:
  4119e0:	push   rdi
  4119e1:	push   rsi
  4119e2:	sub    rsp,0xa8
  4119e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4119ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4119f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4119fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411a01:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411a07:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  411a0d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411a13:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411a19:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411a22:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  411a2b:	mov    edi,0x28
  411a30:	xor    eax,eax
  411a32:	call   4071c0 <malloc@plt>
  411a37:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  411a3d:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411a43:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411a49:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411a4f:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411a55:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411a5b:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411a61:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411a67:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411a70:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411a79:	add    rsp,0xa8
  411a80:	pop    rsi
  411a81:	pop    rdi
  411a82:	ret
	...

0000000000411a90 <__swc_fn_0a4ed24b_000146_162f363d>:
  411a90:	mov    QWORD PTR [r8],0x0
  411a97:	cmp    rdx,0x10
  411a9b:	jae    411aa0 <__swc_fn_0a4ed24b_000146_162f363d+0x10>
  411a9d:	xor    eax,eax
  411a9f:	ret
  411aa0:	mov    eax,DWORD PTR [rcx]
  411aa2:	cmp    eax,0x42445753
  411aa8:	jne    411ab2 <__swc_fn_0a4ed24b_000146_162f363d+0x22>
  411aaa:	mov    eax,DWORD PTR [rcx+0x4]
  411aad:	cmp    eax,0x1
  411ab0:	je     411ab5 <__swc_fn_0a4ed24b_000146_162f363d+0x25>
  411ab2:	xor    eax,eax
  411ab4:	ret
  411ab5:	mov    QWORD PTR [r8],rdx
  411ab8:	mov    rax,rcx
  411abb:	ret
  411abc:	add    BYTE PTR [rax],al
	...

0000000000411ac0 <__swc_fn_0a4ed24b_000149_2eb804cc>:
  411ac0:	push   rbx
  411ac1:	sub    rsp,0xe0
  411ac8:	lea    rbx,[rsp+0x8]
  411acd:	vxorps xmm0,xmm0,xmm0
  411ad1:	vmovups YMMWORD PTR [rbx],ymm0
  411ad5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  411ada:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  411adf:	vzeroupper
  411ae2:	mov    DWORD PTR [rbx+0x60],0x0
  411ae9:	mov    r8,rbx
  411aec:	mov    rdx,rcx
  411aef:	nop
  411af0:	mov    r9,rdx
  411af3:	movabs rdx,0x6666666666666667
  411afd:	mov    rax,r9
  411b00:	imul   rdx
  411b03:	sar    rdx,0x2
  411b07:	mov    r10,rdx
  411b0a:	shr    rdx,0x3f
  411b0e:	add    r10,rdx
  411b11:	mov    rdx,r10
  411b14:	imul   r11,r10,0xa
  411b18:	sub    r9,r11
  411b1b:	mov    r11,QWORD PTR [rip+0x1cce]        # 4137f0 <__swc_rdata_base_0a4ed24b+0x6e0>
  411b22:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  411b27:	mov    BYTE PTR [r8],r9b
  411b2a:	lea    r9,[r8+0x1]
  411b2e:	mov    r8,r9
  411b31:	test   r10,r10
  411b34:	jne    411af0 <__swc_fn_0a4ed24b_000149_2eb804cc+0x30>
  411b36:	test   rcx,rcx
  411b39:	jge    411b43 <__swc_fn_0a4ed24b_000149_2eb804cc+0x83>
  411b3b:	mov    BYTE PTR [r9],0x2d
  411b3f:	add    r8,0x1
  411b43:	mov    BYTE PTR [r8],0x0
  411b47:	sub    r8,0x1
  411b4b:	mov    rax,rbx
  411b4e:	cmp    rax,r8
  411b51:	jae    411b76 <__swc_fn_0a4ed24b_000149_2eb804cc+0xb6>
  411b53:	cs nop WORD PTR [rax+rax*1+0x0]
  411b5d:	nop    DWORD PTR [rax]
  411b60:	mov    cl,BYTE PTR [r8]
  411b63:	mov    dl,BYTE PTR [rax]
  411b65:	mov    BYTE PTR [r8],dl
  411b68:	sub    r8,0x1
  411b6c:	mov    BYTE PTR [rax],cl
  411b6e:	inc    rax
  411b71:	cmp    rax,r8
  411b74:	jb     411b60 <__swc_fn_0a4ed24b_000149_2eb804cc+0xa0>
  411b76:	xor    eax,eax
  411b78:	test   rbx,rbx
  411b7b:	je     411b9e <__swc_fn_0a4ed24b_000149_2eb804cc+0xde>
  411b7d:	mov    rcx,rbx
  411b80:	mov    dl,BYTE PTR [rcx]
  411b82:	test   dl,dl
  411b84:	je     411b9e <__swc_fn_0a4ed24b_000149_2eb804cc+0xde>
  411b86:	cs nop WORD PTR [rax+rax*1+0x0]
  411b90:	add    rcx,0x1
  411b94:	add    rax,0x1
  411b98:	mov    dl,BYTE PTR [rcx]
  411b9a:	test   dl,dl
  411b9c:	jne    411b90 <__swc_fn_0a4ed24b_000149_2eb804cc+0xd0>
  411b9e:	mov    QWORD PTR [rbx+0xa8],rbx
  411ba5:	mov    QWORD PTR [rbx+0xb0],rax
  411bac:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  411bb4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  411bbc:	lea    rcx,[rbx+0xb8]
  411bc3:	call   4098b0 <__swc_fn_0a4ed24b_000120_2648f149>
  411bc8:	add    rsp,0xe0
  411bcf:	pop    rbx
  411bd0:	ret
	...

0000000000411be0 <__swc_fn_0a4ed24b_000152_86f1d437>:
  411be0:	vxorps xmm0,xmm0,xmm0
  411be4:	vmovups XMMWORD PTR [rcx],xmm0
  411be8:	mov    QWORD PTR [rcx+0x10],0x0
  411bf0:	ret
	...

0000000000411c00 <__swc_fn_0a4ed24b_000155_86f1d437>:
  411c00:	vxorps xmm0,xmm0,xmm0
  411c04:	vmovups XMMWORD PTR [rcx],xmm0
  411c08:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411c0d:	vxorps xmm0,xmm0,xmm0
  411c11:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411c16:	vmovups xmm0,XMMWORD PTR [rip+0x1cb2]        # 4138d0 <__swc_rdata_base_0a4ed24b+0x7c0>
  411c1e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411c23:	vxorps xmm0,xmm0,xmm0
  411c27:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411c2c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411c31:	mov    QWORD PTR [rcx+0x60],0x0
  411c39:	ret
  411c3a:	add    BYTE PTR [rax],al
  411c3c:	add    BYTE PTR [rax],al
	...

0000000000411c40 <__swc_fn_0a4ed24b_000158_86f1d437>:
  411c40:	vxorps xmm0,xmm0,xmm0
  411c44:	vmovups XMMWORD PTR [rcx],xmm0
  411c48:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411c4d:	vxorps xmm0,xmm0,xmm0
  411c51:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411c56:	vmovups xmm0,XMMWORD PTR [rip+0x1d9a]        # 4139f8 <__swc_rdata_base_0a4ed24b+0x8e8>
  411c5e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411c63:	vxorps xmm0,xmm0,xmm0
  411c67:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411c6c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411c71:	vxorps xmm0,xmm0,xmm0
  411c75:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  411c7a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  411c7f:	vxorps xmm0,xmm0,xmm0
  411c83:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  411c8b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  411c93:	vxorps xmm0,xmm0,xmm0
  411c97:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  411c9f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  411ca7:	vxorps xmm0,xmm0,xmm0
  411cab:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  411cb3:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  411cbb:	mov    QWORD PTR [rcx+0xe0],0x0
  411cc6:	ret
	...

0000000000411cd0 <__swc_fn_0a4ed24b_000161_13ead2ff>:
  411cd0:	push   rbx
  411cd1:	mov    rbx,rcx
  411cd4:	call   40b2f0 <__swc_fn_0a4ed24b_000162_e36363a8>
  411cd9:	mov    rax,QWORD PTR [rbx+0x10]
  411cdd:	test   rax,rax
  411ce0:	je     411cf1 <__swc_fn_0a4ed24b_000161_13ead2ff+0x21>
  411ce2:	mov    rcx,rbx
  411ce5:	mov    rdx,rax
  411ce8:	mov    r8,QWORD PTR [rbx+0x18]
  411cec:	call   40e790 <__swc_fn_0a4ed24b_000160_47b270e1>
  411cf1:	vxorps xmm0,xmm0,xmm0
  411cf5:	vmovups XMMWORD PTR [rbx],xmm0
  411cf9:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  411cfe:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  411d03:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  411d08:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  411d0d:	mov    QWORD PTR [rbx+0x50],0x0
  411d15:	pop    rbx
  411d16:	ret
	...

0000000000411d20 <__swc_fn_0a4ed24b_000164_72795826>:
  411d20:	sub    rsp,0x10
  411d24:	mov    eax,r8d
  411d27:	mov    r8d,r9d
  411d2a:	test   r9d,r9d
  411d2d:	jne    411d46 <__swc_fn_0a4ed24b_000164_72795826+0x26>
  411d2f:	vmovups xmm0,XMMWORD PTR [rip+0x1d79]        # 413ab0 <__swc_rdata_base_0a4ed24b+0x9a0>
  411d37:	vmovups XMMWORD PTR [r10],xmm0
  411d3c:	mov    eax,0x1
  411d41:	add    rsp,0x10
  411d45:	ret
  411d46:	mov    r9,r8
  411d49:	cmp    r8,rax
  411d4c:	jb     411d53 <__swc_fn_0a4ed24b_000164_72795826+0x33>
  411d4e:	cmp    r9,rdx
  411d51:	jb     411d5a <__swc_fn_0a4ed24b_000164_72795826+0x3a>
  411d53:	xor    eax,eax
  411d55:	add    rsp,0x10
  411d59:	ret
  411d5a:	xor    eax,eax
  411d5c:	lea    r8,[r9+rax*1]
  411d60:	cmp    r8,rdx
  411d63:	jae    411d93 <__swc_fn_0a4ed24b_000164_72795826+0x73>
  411d65:	cs nop WORD PTR [rax+rax*1+0x0]
  411d6f:	cs nop WORD PTR [rax+rax*1+0x0]
  411d79:	nop    DWORD PTR [rax+0x0]
  411d80:	cmp    BYTE PTR [rcx+r8*1],0x0
  411d85:	je     411d93 <__swc_fn_0a4ed24b_000164_72795826+0x73>
  411d87:	inc    rax
  411d8a:	lea    r8,[r9+rax*1]
  411d8e:	cmp    r8,rdx
  411d91:	jb     411d80 <__swc_fn_0a4ed24b_000164_72795826+0x60>
  411d93:	cmp    r8,rdx
  411d96:	jne    411d9f <__swc_fn_0a4ed24b_000164_72795826+0x7f>
  411d98:	xor    eax,eax
  411d9a:	add    rsp,0x10
  411d9e:	ret
  411d9f:	add    rcx,r9
  411da2:	mov    QWORD PTR [rsp],rcx
  411da6:	mov    QWORD PTR [rsp+0x8],rax
  411dab:	vmovups xmm0,XMMWORD PTR [rsp]
  411db0:	vmovups XMMWORD PTR [r10],xmm0
  411db5:	mov    eax,0x1
  411dba:	add    rsp,0x10
  411dbe:	ret
	...

0000000000411dc0 <__swc_fn_0a4ed24b_000167_bcc835b8>:
  411dc0:	push   rbp
  411dc1:	push   rbx
  411dc2:	push   rsi
  411dc3:	push   rdi
  411dc4:	push   r12
  411dc6:	push   r13
  411dc8:	push   r14
  411dca:	push   r15
  411dcc:	sub    rsp,0x10
  411dd0:	mov    rbp,rsp
  411dd3:	vmovups XMMWORD PTR [rsp],xmm6
  411dd8:	sub    rsp,0x50
  411ddc:	mov    rbx,rsp
  411ddf:	mov    rsi,r8
  411de2:	mov    QWORD PTR [rsp+0x30],r8
  411de7:	mov    rdi,rcx
  411dea:	mov    QWORD PTR [rsp+0x38],rcx
  411def:	mov    r12,rdx
  411df2:	xor    r13b,r13b
  411df5:	mov    r14,QWORD PTR [rdi+0x8]
  411df9:	mov    QWORD PTR [rsp+0x40],r14
  411dfe:	xor    r15d,r15d
  411e01:	test   r14,r14
  411e04:	jbe    41205e <__swc_fn_0a4ed24b_000167_bcc835b8+0x29e>
  411e0a:	mov    r14,QWORD PTR [rdi]
  411e0d:	mov    rax,QWORD PTR [rsp+0x40]
  411e12:	mov    QWORD PTR [rsp+0x48],r14
  411e17:	vmovups xmm6,XMMWORD PTR [rip+0x18c9]        # 4136e8 <__swc_rdata_base_0a4ed24b+0x5d8>
  411e1f:	nop
  411e20:	cmp    QWORD PTR [r14+r15*8],0x0
  411e25:	jne    411e2f <__swc_fn_0a4ed24b_000167_bcc835b8+0x6f>
  411e27:	mov    r14,rax
  411e2a:	jmp    41203e <__swc_fn_0a4ed24b_000167_bcc835b8+0x27e>
  411e2f:	mov    rcx,QWORD PTR [rdi]
  411e32:	mov    rdx,QWORD PTR [rcx+r15*8]
  411e36:	mov    rdi,rbx
  411e39:	mov    rcx,rdi
  411e3c:	sub    rsp,0x8
  411e40:	mov    r14,rax
  411e43:	call   40e810 <__swc_fn_0a4ed24b_000166_cc119975>
  411e48:	add    rsp,0x8
  411e4c:	mov    al,BYTE PTR [rbx]
  411e4e:	test   al,al
  411e50:	je     41203e <__swc_fn_0a4ed24b_000167_bcc835b8+0x27e>
  411e56:	mov    al,BYTE PTR [rbx+0x1]
  411e59:	test   al,al
  411e5b:	jne    411e66 <__swc_fn_0a4ed24b_000167_bcc835b8+0xa6>
  411e5d:	test   sil,sil
  411e60:	je     41203e <__swc_fn_0a4ed24b_000167_bcc835b8+0x27e>
  411e66:	test   r13b,r13b
  411e69:	jne    411f27 <__swc_fn_0a4ed24b_000167_bcc835b8+0x167>
  411e6f:	test   r12,r12
  411e72:	je     411f27 <__swc_fn_0a4ed24b_000167_bcc835b8+0x167>
  411e78:	mov    al,BYTE PTR [rbx+0x1]
  411e7b:	test   al,al
  411e7d:	je     41203e <__swc_fn_0a4ed24b_000167_bcc835b8+0x27e>
  411e83:	mov    eax,DWORD PTR [rbx+0x28]
  411e86:	cmp    DWORD PTR [r12+0x20],eax
  411e8b:	jne    41203e <__swc_fn_0a4ed24b_000167_bcc835b8+0x27e>
  411e91:	mov    rax,QWORD PTR [r12]
  411e95:	mov    rcx,QWORD PTR [r12+0x8]
  411e9a:	cmp    QWORD PTR [rbx+0x20],rcx
  411e9e:	jne    41203e <__swc_fn_0a4ed24b_000167_bcc835b8+0x27e>
  411ea4:	mov    cl,0x1
  411ea6:	test   rax,rax
  411ea9:	je     411f12 <__swc_fn_0a4ed24b_000167_bcc835b8+0x152>
  411eaf:	mov    rdx,QWORD PTR [rbx+0x20]
  411eb3:	xor    r8d,r8d
  411eb6:	test   rdx,rdx
  411eb9:	jbe    411f12 <__swc_fn_0a4ed24b_000167_bcc835b8+0x152>
  411ebb:	mov    r9,QWORD PTR [rbx+0x18]
  411ebf:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  411ec4:	cs nop WORD PTR [rax+rax*1+0x0]
  411ece:	xchg   ax,ax
  411ed0:	mov    r10b,BYTE PTR [rax+r8*1]
  411ed4:	cmp    BYTE PTR [r9+r8*1],r10b
  411ed8:	je     411f09 <__swc_fn_0a4ed24b_000167_bcc835b8+0x149>
  411eda:	vmovq  r10,xmm0
  411edf:	cmp    BYTE PTR [r10+r8*1],0x5c
  411ee4:	jne    411eed <__swc_fn_0a4ed24b_000167_bcc835b8+0x12d>
  411ee6:	cmp    BYTE PTR [rax+r8*1],0x2f
  411eeb:	je     411f09 <__swc_fn_0a4ed24b_000167_bcc835b8+0x149>
  411eed:	vmovq  r10,xmm0
  411ef2:	cmp    BYTE PTR [r10+r8*1],0x2f
  411ef7:	jne    411f00 <__swc_fn_0a4ed24b_000167_bcc835b8+0x140>
  411ef9:	cmp    BYTE PTR [rax+r8*1],0x5c
  411efe:	je     411f09 <__swc_fn_0a4ed24b_000167_bcc835b8+0x149>
  411f00:	xor    eax,eax
  411f02:	movzx  eax,al
  411f05:	mov    cl,al
  411f07:	jmp    411f12 <__swc_fn_0a4ed24b_000167_bcc835b8+0x152>
  411f09:	add    r8,0x1
  411f0d:	cmp    r8,rdx
  411f10:	jb     411ed0 <__swc_fn_0a4ed24b_000167_bcc835b8+0x110>
  411f12:	test   cl,cl
  411f14:	je     41203e <__swc_fn_0a4ed24b_000167_bcc835b8+0x27e>
  411f1a:	mov    eax,0x1
  411f1f:	mov    r13b,al
  411f22:	jmp    41203e <__swc_fn_0a4ed24b_000167_bcc835b8+0x27e>
  411f27:	mov    r13b,0x1
  411f2a:	sub    rsp,0x20
  411f2e:	mov    rax,rsp
  411f31:	lea    rcx,[rdi+0x8]
  411f35:	mov    QWORD PTR [rax],rcx
  411f38:	lea    rsi,[rip+0x13b1]        # 4132f0 <__swc_rdata_base_0a4ed24b+0x1e0>
  411f3f:	mov    QWORD PTR [rax+0x8],rsi
  411f43:	mov    QWORD PTR [rax+0x10],rsp
  411f47:	mov    QWORD PTR [rax+0x18],0x1
  411f4f:	lea    rcx,[rsp+0x10]
  411f54:	sub    rsp,0x8
  411f58:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  411f5d:	add    rsp,0x8
  411f61:	add    rsp,0x20
  411f65:	mov    al,BYTE PTR [rbx+0x1]
  411f68:	test   al,al
  411f6a:	je     412007 <__swc_fn_0a4ed24b_000167_bcc835b8+0x247>
  411f70:	lea    rax,[rip+0x1bd9]        # 413b50 <__swc_rdata_base_0a4ed24b+0xa40>
  411f77:	sub    rsp,0x20
  411f7b:	mov    rcx,rsp
  411f7e:	mov    QWORD PTR [rcx],rax
  411f81:	mov    QWORD PTR [rcx+0x8],rsi
  411f85:	mov    QWORD PTR [rcx+0x10],rsp
  411f89:	mov    QWORD PTR [rcx+0x18],0x1
  411f91:	lea    rcx,[rsp+0x10]
  411f96:	sub    rsp,0x8
  411f9a:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  411f9f:	add    rsp,0x8
  411fa3:	add    rsp,0x20
  411fa7:	mov    eax,DWORD PTR [rbx+0x28]
  411faa:	sub    rsp,0x60
  411fae:	mov    rcx,rsp
  411fb1:	lea    rdx,[rdi+0x18]
  411fb5:	mov    QWORD PTR [rcx+0x18],rdx
  411fb9:	mov    QWORD PTR [rcx+0x20],rsi
  411fbd:	vmovups XMMWORD PTR [rcx],xmm6
  411fc1:	mov    QWORD PTR [rcx+0x28],rsp
  411fc5:	mov    QWORD PTR [rcx+0x30],rsi
  411fc9:	mov    DWORD PTR [rcx+0x10],eax
  411fcc:	lea    rax,[rsp+0x10]
  411fd1:	mov    QWORD PTR [rcx+0x38],rax
  411fd5:	lea    rax,[rip+0x16a4]        # 413680 <__swc_rdata_base_0a4ed24b+0x570>
  411fdc:	mov    QWORD PTR [rcx+0x40],rax
  411fe0:	lea    rax,[rsp+0x18]
  411fe5:	mov    QWORD PTR [rcx+0x48],rax
  411fe9:	mov    QWORD PTR [rcx+0x50],0x3
  411ff1:	lea    rcx,[rsp+0x48]
  411ff6:	sub    rsp,0x8
  411ffa:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  411fff:	add    rsp,0x8
  412003:	add    rsp,0x60
  412007:	lea    rax,[rip+0x12d2]        # 4132e0 <__swc_rdata_base_0a4ed24b+0x1d0>
  41200e:	sub    rsp,0x20
  412012:	mov    rcx,rsp
  412015:	mov    QWORD PTR [rcx],rax
  412018:	mov    QWORD PTR [rcx+0x8],rsi
  41201c:	mov    QWORD PTR [rcx+0x10],rsp
  412020:	mov    QWORD PTR [rcx+0x18],0x1
  412028:	lea    rcx,[rsp+0x10]
  41202d:	sub    rsp,0x8
  412031:	call   40a120 <__swc_fn_0a4ed24b_000150_6203dca2>
  412036:	add    rsp,0x8
  41203a:	add    rsp,0x20
  41203e:	add    r15,0x1
  412042:	cmp    r15,r14
  412045:	jae    41205e <__swc_fn_0a4ed24b_000167_bcc835b8+0x29e>
  412047:	mov    rsi,QWORD PTR [rsp+0x30]
  41204c:	mov    rdi,QWORD PTR [rsp+0x38]
  412051:	mov    rax,r14
  412054:	mov    r14,QWORD PTR [rsp+0x48]
  412059:	jmp    411e20 <__swc_fn_0a4ed24b_000167_bcc835b8+0x60>
  41205e:	add    rsp,0x50
  412062:	vmovups xmm6,XMMWORD PTR [rsp]
  412067:	add    rsp,0x10
  41206b:	pop    r15
  41206d:	pop    r14
  41206f:	pop    r13
  412071:	pop    r12
  412073:	pop    rdi
  412074:	pop    rsi
  412075:	pop    rbx
  412076:	pop    rbp
  412077:	ret
	...

0000000000412080 <__swc_fn_0a4ed24b_000170_646fdf20>:
  412080:	sub    rsp,0x8
  412084:	call   409b30 <__swc_fn_0a4ed24b_000129_4bbe3f14>
  412089:	add    rsp,0x8
  41208d:	ret
	...

0000000000412090 <__swc_fn_0a4ed24b_000173_1e0ea8cf>:
  412090:	push   rsi
  412091:	sub    rsp,0x30
  412095:	lea    rsi,[rip+0x14d04]        # 426da0 <__swc_bss_base_0a4ed24b+0x2d60>
  41209c:	mov    rax,QWORD PTR [rsi]
  41209f:	test   rax,rax
  4120a2:	je     4120aa <__swc_fn_0a4ed24b_000173_1e0ea8cf+0x1a>
  4120a4:	add    rsp,0x30
  4120a8:	pop    rsi
  4120a9:	ret
  4120aa:	mov    ecx,0x2
  4120af:	mov    edx,0x8020
  4120b4:	call   4091d0 <__swc_fn_0a4ed24b_000111_6814119b>
  4120b9:	test   rax,rax
  4120bc:	jne    4120cd <__swc_fn_0a4ed24b_000173_1e0ea8cf+0x3d>
  4120be:	mov    QWORD PTR [rsp+0x18],rax
  4120c3:	call   411530 <__swc_fn_0a4ed24b_000122_be2e2f68>
  4120c8:	mov    rax,QWORD PTR [rsp+0x18]
  4120cd:	mov    rcx,rax
  4120d0:	xchg   QWORD PTR [rsi],rcx
  4120d3:	add    rsp,0x30
  4120d7:	pop    rsi
  4120d8:	ret
  4120d9:	add    BYTE PTR [rax],al
  4120db:	add    BYTE PTR [rax],al
  4120dd:	add    BYTE PTR [rax],al
	...

00000000004120e0 <__swc_fn_0a4ed24b_000176_4de704de>:
  4120e0:	push   rsi
  4120e1:	test   r8,r8
  4120e4:	jne    4120e8 <__swc_fn_0a4ed24b_000176_4de704de+0x8>
  4120e6:	pop    rsi
  4120e7:	ret
  4120e8:	lea    rax,[rcx+0x18]
  4120ec:	mov    r10,QWORD PTR [rax]
  4120ef:	lea    r11,[r10+0x1]
  4120f3:	mov    QWORD PTR [rax],r11
  4120f6:	mov    r11,rdx
  4120f9:	not    rdx
  4120fc:	lea    rsi,[r8-0x1]
  412100:	cmp    rsi,rdx
  412103:	ja     412123 <__swc_fn_0a4ed24b_000176_4de704de+0x43>
  412105:	lea    rdx,[r11+r8*1]
  412109:	dec    rdx
  41210c:	shr    rdx,0x6
  412110:	mov    r8,r11
  412113:	shr    r8,0x6
  412117:	mov    rsi,rdx
  41211a:	sub    rsi,r8
  41211d:	cmp    rsi,0x8
  412121:	jb     412139 <__swc_fn_0a4ed24b_000176_4de704de+0x59>
  412123:	lea    rcx,[rcx+0x10]
  412127:	mov    rdx,QWORD PTR [rcx]
  41212a:	add    rdx,r9
  41212d:	mov    QWORD PTR [rcx],rdx
  412130:	lea    rcx,[r10+0x2]
  412134:	mov    QWORD PTR [rax],rcx
  412137:	pop    rsi
  412138:	ret
  412139:	shr    r11,0x6
  41213d:	nop    DWORD PTR [rax]
  412140:	cmp    r11,rdx
  412143:	ja     412183 <__swc_fn_0a4ed24b_000176_4de704de+0xa3>
  412145:	jmp    412156 <__swc_fn_0a4ed24b_000176_4de704de+0x76>
  412147:	nop    WORD PTR [rax+rax*1+0x0]
  412150:	add    r11,0x1
  412154:	jmp    412140 <__swc_fn_0a4ed24b_000176_4de704de+0x60>
  412156:	mov    r8,r11
  412159:	shr    r8,0xc
  41215d:	mov    rsi,r11
  412160:	xor    rsi,r8
  412163:	mov    r8,r11
  412166:	shr    r8,0x18
  41216a:	xor    rsi,r8
  41216d:	and    esi,0xfff
  412173:	lea    r8,[rcx+rsi*8+0x20]
  412178:	mov    rsi,QWORD PTR [r8]
  41217b:	add    rsi,r9
  41217e:	mov    QWORD PTR [r8],rsi
  412181:	jmp    412150 <__swc_fn_0a4ed24b_000176_4de704de+0x70>
  412183:	lea    rcx,[r10+0x2]
  412187:	mov    QWORD PTR [rax],rcx
  41218a:	pop    rsi
  41218b:	ret
