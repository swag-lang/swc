
/workspace/prompt2-20261115/batch7-placement-micro/base/chacha/chacha:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <getpid@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <getpid@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <munmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <munmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <exit@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <exit@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <pthread_key_create@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <pthread_key_create@GLIBC_2.34>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_setspecific@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <pthread_setspecific@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <syscall@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <syscall@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dladdr@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <dladdr@GLIBC_2.34>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <open@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <open@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <lseek@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <lseek@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <close@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <close@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <mmap@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <mmap@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <malloc@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <malloc@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <clock_gettime@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf92]        # 413078 <clock_gettime@GLIBC_2.17>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <madvise@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf92]        # 413088 <madvise@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <pthread_key_delete@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf8a]        # 413090 <pthread_key_delete@GLIBC_2.34>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <gettid@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf82]        # 413098 <gettid@GLIBC_2.30>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <flock@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf7a]        # 4130a0 <flock@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <__errno_location@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf72]        # 4130a8 <__errno_location@GLIBC_2.2.5>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <opendir@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf6a]        # 4130b0 <opendir@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <dirfd@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf62]        # 4130b8 <dirfd@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <readdir@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <readdir@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <readlinkat@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <readlinkat@GLIBC_2.4>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <openat@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <openat@GLIBC_2.4>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <closedir@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <closedir@GLIBC_2.2.5>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <memfd_create@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <memfd_create@GLIBC_2.27>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <ftruncate@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <ftruncate@GLIBC_2.2.5>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <write@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <write@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <backtrace@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <backtrace@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <__x86_get_cpuid_feature_leaf@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <free@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <free@GLIBC_2.2.5>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_3464c816_000176_2744b483+0x1040>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40ca80 <__swc_fn_3464c816_000121_1c5e75b6>
  40724e:	xor    ecx,ecx
  407250:	call   40c1a0 <__swc_fn_3464c816_000094_383a814c>
  407255:	call   40d640 <__swc_fn_3464c816_000175_7f24d040>
  40725a:	call   40f610 <__swc_fn_3464c816_000095_8cc4b392>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_3464c816_000000_0e26756e>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_3464c816_000003_81215399>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_3464c816_000003_81215399+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   409240 <__swc_fn_3464c816_000111_f9e19033>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_3464c816_000003_81215399+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1cd81]        # 424048 <__swc_bss_base_3464c816+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1cd7a]        # 424048 <__swc_bss_base_3464c816+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_3464c816_000003_81215399+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_3464c816_000003_81215399+0x30>
  4072e6:	lea    rcx,[rip+0x1cd63]        # 424050 <__swc_bss_base_3464c816+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1cd5c]        # 424050 <__swc_bss_base_3464c816+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_3464c816_000003_81215399+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_3464c816_000003_81215399+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_3464c816_000006_7b253ae1>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40dec0 <__swc_fn_3464c816_000011_71c91685>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_3464c816_000012_be38a1a2>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_3464c816_000006_7b253ae1+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_3464c816_000003_81215399>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_3464c816_000006_7b253ae1+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_3464c816_000009_4c3ebf16>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_3464c816_000009_4c3ebf16+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40a530 <__swc_fn_3464c816_000007_a7bfb091>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40deb0 <__swc_fn_3464c816_000008_b2f73e0d>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_3464c816_000009_4c3ebf16+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_3464c816_000009_4c3ebf16+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_3464c816_000012_be38a1a2>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_3464c816_000015_96cb1311>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_3464c816_000015_96cb1311+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_3464c816_000015_96cb1311+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_3464c816_000015_96cb1311+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_3464c816_000015_96cb1311+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40e020 <__swc_fn_3464c816_000017_f003fc47>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_3464c816_000015_96cb1311+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1cb3d]        # 424058 <__swc_bss_base_3464c816+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1cb36]        # 424058 <__swc_bss_base_3464c816+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_3464c816_000015_96cb1311+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_3464c816_000015_96cb1311+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40dec0 <__swc_fn_3464c816_000011_71c91685>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_3464c816_000015_96cb1311+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   40c7a0 <__swc_fn_3464c816_000112_2f7f9346>
  407569:	lea    rcx,[rip+0x1cad8]        # 424048 <__swc_bss_base_3464c816+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1cad1]        # 424048 <__swc_bss_base_3464c816+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_3464c816_000015_96cb1311+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_3464c816_000015_96cb1311+0x110>
  407598:	lea    rcx,[rip+0x1cac1]        # 424060 <__swc_bss_base_3464c816+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1caba]        # 424060 <__swc_bss_base_3464c816+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_3464c816_000015_96cb1311+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_3464c816_000015_96cb1311+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_3464c816_000018_77ece227>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_3464c816_000015_96cb1311+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_3464c816_000018_77ece227>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_3464c816_000018_77ece227+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_3464c816_000018_77ece227+0x10>

0000000000407630 <__swc_fn_3464c816_000021_9cf87641>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_3464c816_000015_96cb1311>
  40763e:	lea    rdi,[rip+0x1cbab]        # 4241f0 <__swc_bss_base_3464c816+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   4098a0 <__swc_fn_3464c816_000135_db32cc57>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1cb94]        # 4241f8 <__swc_bss_base_3464c816+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1cb89],rsi        # 4241f8 <__swc_bss_base_3464c816+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_3464c816_000024_e876734d>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_3464c816_000027_e876734d>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_3464c816_000030_650caec0>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_3464c816_000030_650caec0+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1a92c]        # 422000 <__swc_data_base_3464c816>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_3464c816_000030_650caec0+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_3464c816_000030_650caec0+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_3464c816_000030_650caec0+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40e1e0 <__swc_fn_3464c816_000032_f1940e30>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_3464c816_000030_650caec0+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_3464c816_000036_290a131c>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_3464c816_000030_650caec0+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_3464c816_000042_0573444d>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_3464c816_000033_d15eb4ea>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40a9e0 <__swc_fn_3464c816_000031_3c3e930e>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   409720 <__swc_fn_3464c816_000129_bc477461>
  407734:	mov    rcx,rsi
  407737:	call   40e1e0 <__swc_fn_3464c816_000032_f1940e30>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_3464c816_000036_290a131c>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_3464c816_000039_9ae4348f>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_3464c816_000039_9ae4348f+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_3464c816_000039_9ae4348f+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_3464c816_000039_9ae4348f+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_3464c816_000039_9ae4348f+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_3464c816_000039_9ae4348f+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   409320 <__swc_fn_3464c816_000114_cc486df9>
  4077ca:	lea    rcx,[rip+0x1c877]        # 424048 <__swc_bss_base_3464c816+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1c870]        # 424048 <__swc_bss_base_3464c816+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_3464c816_000039_9ae4348f+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_3464c816_000039_9ae4348f+0x90>
  4077f8:	lea    rcx,[rip+0x1c861]        # 424060 <__swc_bss_base_3464c816+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1c85a]        # 424060 <__swc_bss_base_3464c816+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_3464c816_000039_9ae4348f+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_3464c816_000039_9ae4348f+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_3464c816_000042_0573444d>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_3464c816_000042_0573444d+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40e7b0 <__swc_fn_3464c816_000059_ee6a254c>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   4098a0 <__swc_fn_3464c816_000135_db32cc57>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_3464c816_000042_0573444d+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_3464c816_000042_0573444d+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_3464c816_000009_4c3ebf16>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_3464c816_000042_0573444d+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40dee0 <__swc_fn_3464c816_000014_be17798c>
  40791e:	jmp    407941 <__swc_fn_3464c816_000042_0573444d+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_3464c816_000042_0573444d+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_3464c816_000042_0573444d+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_3464c816_000042_0573444d+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40aba0 <__swc_fn_3464c816_000043_47ff6d9b>
  407997:	mov    rcx,rdi
  40799a:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_3464c816_000039_9ae4348f>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_3464c816_000045_bb688d37>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_3464c816_000045_bb688d37+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_3464c816_000045_bb688d37+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_3464c816_000045_bb688d37+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_3464c816_000045_bb688d37+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   4098a0 <__swc_fn_3464c816_000135_db32cc57>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_3464c816_000045_bb688d37+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_3464c816_000045_bb688d37+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_3464c816_000045_bb688d37+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_3464c816_000045_bb688d37+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_3464c816_000009_4c3ebf16>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_3464c816_000045_bb688d37+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_3464c816_000045_bb688d37+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_3464c816_000045_bb688d37+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_3464c816_000045_bb688d37+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_3464c816_000045_bb688d37+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40a5e0 <__swc_fn_3464c816_000013_7b85dbab>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_3464c816_000045_bb688d37+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_3464c816_000045_bb688d37+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_3464c816_000045_bb688d37+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_3464c816_000045_bb688d37+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40e060 <__swc_fn_3464c816_000020_4285d9c5>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_3464c816_000045_bb688d37+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40a5e0 <__swc_fn_3464c816_000013_7b85dbab>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_3464c816_000045_bb688d37+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_3464c816_000021_9cf87641>
  407c07:	mov    rcx,r14
  407c0a:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_3464c816_000045_bb688d37+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_3464c816_000045_bb688d37+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_3464c816_000045_bb688d37+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_3464c816_000048_8e68f77b>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_3464c816_000048_8e68f77b+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_3464c816_000048_8e68f77b+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_3464c816_000048_8e68f77b+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_3464c816_000048_8e68f77b+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40e410 <__swc_fn_3464c816_000047_e7fd8d42>
  407d14:	jmp    407ce0 <__swc_fn_3464c816_000048_8e68f77b+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_3464c816_000048_8e68f77b+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_3464c816_000048_8e68f77b+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_3464c816_000048_8e68f77b+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_3464c816_000048_8e68f77b+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_3464c816_000048_8e68f77b+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_3464c816_000048_8e68f77b+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_3464c816_000048_8e68f77b+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_3464c816_000051_27d2a35f>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_3464c816_000051_27d2a35f+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_3464c816_000051_27d2a35f+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_3464c816_000051_27d2a35f+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_3464c816_000051_27d2a35f+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40e370 <__swc_fn_3464c816_000044_fe6bbfdb>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40dee0 <__swc_fn_3464c816_000014_be17798c>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_3464c816_000054_e8e85c01>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   4098a0 <__swc_fn_3464c816_000135_db32cc57>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_3464c816_000054_e8e85c01+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_3464c816_000054_e8e85c01+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_3464c816_000054_e8e85c01+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_3464c816_000057_01c75a1d>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_3464c816_000060_6818d0d1>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_3464c816_000060_6818d0d1+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_3464c816_000039_9ae4348f>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_3464c816_000060_6818d0d1+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_3464c816_000063_db6d2425>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40af20 <__swc_fn_3464c816_000052_92b016ae>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_3464c816_000054_e8e85c01>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_3464c816_000063_db6d2425+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_3464c816_000063_db6d2425+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40b040 <__swc_fn_3464c816_000058_01964a17>
  407f7f:	mov    rcx,rsi
  407f82:	call   40ac80 <__swc_fn_3464c816_000049_f6a485a2>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_3464c816_000066_918d3875>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_3464c816_000066_918d3875+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1c049]        # 424070 <__swc_bss_base_3464c816+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1c04b]        # 424080 <__swc_bss_base_3464c816+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_3464c816_000066_918d3875+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_3464c816_000066_918d3875+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40a910 <__swc_fn_3464c816_000022_53fc00d2>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_3464c816_000066_918d3875+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_3464c816_000063_db6d2425>
  40808f:	jmp    408122 <__swc_fn_3464c816_000066_918d3875+0x192>
  408094:	lea    rax,[rip+0x19f65]        # 422000 <__swc_data_base_3464c816>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_3464c816_000066_918d3875+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_3464c816_000066_918d3875+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_3464c816_000066_918d3875+0x135>
  4080b8:	call   40a9e0 <__swc_fn_3464c816_000031_3c3e930e>
  4080bd:	mov    rcx,rax
  4080c0:	call   4103a0 <__swc_fn_3464c816_000128_8d8a7dd2>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_3464c816_000066_918d3875+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_3464c816_000066_918d3875+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_3464c816_000066_918d3875+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40e410 <__swc_fn_3464c816_000047_e7fd8d42>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_3464c816_000066_918d3875+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_3464c816_000051_27d2a35f>
  408115:	jmp    408122 <__swc_fn_3464c816_000066_918d3875+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40a550 <__swc_fn_3464c816_000010_0569f799>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_3464c816_000069_34b04ef2>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_3464c816_000036_290a131c>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_3464c816_000069_34b04ef2+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1c09a]        # 424240 <__swc_bss_base_3464c816+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_3464c816_000069_34b04ef2+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   4098a0 <__swc_fn_3464c816_000135_db32cc57>
  4081b5:	mov    rcx,rsi
  4081b8:	call   40ebe0 <__swc_fn_3464c816_000068_f501e74b>
  4081bd:	mov    rcx,rsi
  4081c0:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_3464c816_000072_bf7b5562>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40e930 <__swc_fn_3464c816_000065_0b20477c>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_3464c816_000075_41334281>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   40ebe0 <__swc_fn_3464c816_000068_f501e74b>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_3464c816_000078_140918ec>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_3464c816_000078_140918ec+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_3464c816_000078_140918ec+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_3464c816_000081_f4f506c7>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_3464c816_000084_5ed30bd6>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_3464c816_000090_14cf59b2>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_3464c816_000084_5ed30bd6+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_3464c816_000084_5ed30bd6+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_3464c816_000084_5ed30bd6+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_3464c816_000084_5ed30bd6+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_3464c816_000090_14cf59b2>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_3464c816_000084_5ed30bd6+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_3464c816_000084_5ed30bd6+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_3464c816_000084_5ed30bd6+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_3464c816_000084_5ed30bd6+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_3464c816_000084_5ed30bd6+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_3464c816_000084_5ed30bd6+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_3464c816_000084_5ed30bd6+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_3464c816_000084_5ed30bd6+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_3464c816_000084_5ed30bd6+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_3464c816_000084_5ed30bd6+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40c020 <__swc_fn_3464c816_000082_ff7d1455>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_3464c816_000084_5ed30bd6+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_3464c816_000084_5ed30bd6+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_3464c816_000084_5ed30bd6+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40c020 <__swc_fn_3464c816_000082_ff7d1455>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_3464c816_000084_5ed30bd6+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_3464c816_000084_5ed30bd6>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_3464c816_000084_5ed30bd6+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_3464c816_000084_5ed30bd6+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_3464c816_000087_693f118e>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_3464c816_000090_14cf59b2>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_3464c816_000087_693f118e+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   40f040 <__swc_fn_3464c816_000086_d9243de4>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_3464c816_000087_693f118e+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_3464c816_000087_693f118e+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_3464c816_000087_693f118e+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40c020 <__swc_fn_3464c816_000082_ff7d1455>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_3464c816_000087_693f118e+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_3464c816_000087_693f118e>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_3464c816_000087_693f118e+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_3464c816_000087_693f118e+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_3464c816_000090_14cf59b2>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_3464c816_000090_14cf59b2+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_3464c816_000090_14cf59b2+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_3464c816_000090_14cf59b2+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_3464c816_000090_14cf59b2+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40c020 <__swc_fn_3464c816_000082_ff7d1455>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40c020 <__swc_fn_3464c816_000082_ff7d1455>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_3464c816_000090_14cf59b2+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_3464c816_000090_14cf59b2+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_3464c816_000090_14cf59b2+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_3464c816_000090_14cf59b2+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_3464c816_000090_14cf59b2>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_3464c816_000090_14cf59b2+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_3464c816_000090_14cf59b2+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_3464c816_000090_14cf59b2+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_3464c816_000090_14cf59b2+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_3464c816_000090_14cf59b2+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_3464c816_000090_14cf59b2+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_3464c816_000090_14cf59b2+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_3464c816_000090_14cf59b2+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_3464c816_000090_14cf59b2+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_3464c816_000090_14cf59b2+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_3464c816_000090_14cf59b2+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_3464c816_000090_14cf59b2+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_3464c816_000090_14cf59b2+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_3464c816_000090_14cf59b2+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_3464c816_000090_14cf59b2+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_3464c816_000090_14cf59b2+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   409db0 <__swc_fn_3464c816_000147_e7bfe29e>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_3464c816_000090_14cf59b2+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_3464c816_000090_14cf59b2>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_3464c816_000090_14cf59b2+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_3464c816_000090_14cf59b2+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_3464c816_000090_14cf59b2+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   409db0 <__swc_fn_3464c816_000147_e7bfe29e>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   409db0 <__swc_fn_3464c816_000147_e7bfe29e>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_3464c816_000093_0c97fc6c>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40c150 <__swc_fn_3464c816_000091_f21926ed>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_3464c816_000093_0c97fc6c+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_3464c816_000093_0c97fc6c+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   410540 <__swc_fn_3464c816_000137_2d595cc7>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_3464c816_000093_0c97fc6c+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0xa872]        # 4131c0 <__swc_rdata_base_3464c816+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   410070 <__swc_fn_3464c816_000116_3f5cfdef>
  408959:	call   40c9d0 <__swc_fn_3464c816_000118_591530fe>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_3464c816_000096_a4baaa40>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40896f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  408975:	vzeroupper
  408978:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40897e:	mov    QWORD PTR [rsp+0x48],rdx
  408983:	mov    rax,r8
  408986:	cmp    r8,0x1
  40898a:	mov    edx,0x1
  40898f:	cmovb  rax,rdx
  408993:	mov    QWORD PTR [rsp+0x50],rax
  408998:	mov    rbx,QWORD PTR [rcx+0x8]
  40899c:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a0:	mov    rcx,QWORD PTR [rcx]
  4089a3:	lea    rdx,[rsp+0x8]
  4089a8:	call   rbx
  4089aa:	add    rsp,0x70
  4089ae:	pop    rbx
  4089af:	ret

00000000004089b0 <__swc_fn_3464c816_000099_5232b57d>:
  4089b0:	push   rbx
  4089b1:	push   rsi
  4089b2:	push   rdi
  4089b3:	sub    rsp,0x30
  4089b7:	mov    rbx,rcx
  4089ba:	test   rcx,rcx
  4089bd:	je     4089d2 <__swc_fn_3464c816_000099_5232b57d+0x22>
  4089bf:	mov    rcx,rbx
  4089c2:	mov    edx,0x1
  4089c7:	call   408200 <__swc_fn_3464c816_000078_140918ec>
  4089cc:	cmp    rax,0x1
  4089d0:	je     4089da <__swc_fn_3464c816_000099_5232b57d+0x2a>
  4089d2:	add    rsp,0x30
  4089d6:	pop    rdi
  4089d7:	pop    rsi
  4089d8:	pop    rbx
  4089d9:	ret
  4089da:	lea    rsi,[rsp+0x8]
  4089df:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089e4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089ea:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  4089ef:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4089f5:	mov    rax,QWORD PTR [rsp+0x20]
  4089fa:	test   rax,rax
  4089fd:	je     408a13 <__swc_fn_3464c816_000099_5232b57d+0x63>
  4089ff:	test   DWORD PTR [rax+0x28],0x400000
  408a06:	je     408a13 <__swc_fn_3464c816_000099_5232b57d+0x63>
  408a08:	mov    rcx,QWORD PTR [rax+0x30]
  408a0c:	test   rcx,rcx
  408a0f:	cmovne rax,rcx
  408a13:	mov    edi,DWORD PTR [rax+0x20]
  408a16:	lea    rcx,[rsp+0x18]
  408a1b:	call   40c330 <__swc_fn_3464c816_000100_5714513e>
  408a20:	mov    rcx,rsi
  408a23:	mov    rdx,QWORD PTR [rsp+0x18]
  408a28:	mov    r8,rdi
  408a2b:	call   408960 <__swc_fn_3464c816_000096_a4baaa40>
  408a30:	mov    rcx,QWORD PTR [rbx+0x28]
  408a34:	call   40f620 <__swc_fn_3464c816_000098_f82a1ed3>
  408a39:	mov    rcx,rsi
  408a3c:	mov    rdx,rbx
  408a3f:	mov    r8d,0x30
  408a45:	call   408960 <__swc_fn_3464c816_000096_a4baaa40>
  408a4a:	add    rsp,0x30
  408a4e:	pop    rdi
  408a4f:	pop    rsi
  408a50:	pop    rbx
  408a51:	ret
	...

0000000000408a60 <__swc_fn_3464c816_000102_14986ec5>:
  408a60:	push   rbp
  408a61:	push   rbx
  408a62:	push   rsi
  408a63:	push   rdi
  408a64:	push   r12
  408a66:	push   r13
  408a68:	push   r14
  408a6a:	push   r15
  408a6c:	sub    rsp,0x500
  408a73:	mov    rbp,rsp
  408a76:	mov    rbx,rsp
  408a79:	mov    rsi,rdx
  408a7c:	mov    rdi,rcx
  408a7f:	mov    rcx,QWORD PTR [rip+0x1e2ba]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  408a86:	test   rcx,rcx
  408a89:	jne    408aa3 <__swc_fn_3464c816_000102_14986ec5+0x43>
  408a8b:	sub    rsp,0x8
  408a8f:	call   40a1a0 <__swc_fn_3464c816_000165_56054fe7>
  408a94:	add    rsp,0x8
  408a98:	lea    rcx,[rax+0x1]
  408a9c:	mov    QWORD PTR [rip+0x1e29d],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  408aa3:	dec    rcx
  408aa6:	sub    rsp,0x8
  408aaa:	call   411e20 <__swc_fn_3464c816_000167_39c041ad>
  408aaf:	add    rsp,0x8
  408ab3:	mov    r12,rax
  408ab6:	mov    QWORD PTR [rsp+0x4f0],rax
  408abe:	lea    rax,[rip+0xa83b]        # 413300 <__swc_rdata_base_3464c816+0x1f0>
  408ac5:	sub    rsp,0x20
  408ac9:	mov    rcx,rsp
  408acc:	mov    QWORD PTR [rcx],rax
  408acf:	lea    r13,[rip+0xa83a]        # 413310 <__swc_rdata_base_3464c816+0x200>
  408ad6:	mov    QWORD PTR [rcx+0x8],r13
  408ada:	mov    QWORD PTR [rcx+0x10],rsp
  408ade:	mov    QWORD PTR [rcx+0x18],0x1
  408ae6:	lea    rcx,[rsp+0x10]
  408aeb:	sub    rsp,0x8
  408aef:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  408af4:	add    rsp,0x8
  408af8:	add    rsp,0x20
  408afc:	lea    rax,[rip+0xa855]        # 413358 <__swc_rdata_base_3464c816+0x248>
  408b03:	sub    rsp,0x20
  408b07:	mov    rcx,rsp
  408b0a:	mov    QWORD PTR [rcx],rax
  408b0d:	mov    QWORD PTR [rcx+0x8],r13
  408b11:	mov    QWORD PTR [rcx+0x10],rsp
  408b15:	mov    QWORD PTR [rcx+0x18],0x1
  408b1d:	lea    rcx,[rsp+0x10]
  408b22:	sub    rsp,0x8
  408b26:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  408b2b:	add    rsp,0x8
  408b2f:	add    rsp,0x20
  408b33:	lea    r14,[rip+0xa82e]        # 413368 <__swc_rdata_base_3464c816+0x258>
  408b3a:	sub    rsp,0x50
  408b3e:	mov    rax,rsp
  408b41:	vmovups xmm0,XMMWORD PTR [rip+0xa957]        # 4134a0 <__swc_rdata_base_3464c816+0x390>
  408b49:	vmovups XMMWORD PTR [rax],xmm0
  408b4d:	mov    QWORD PTR [rax+0x10],rsp
  408b51:	mov    QWORD PTR [rax+0x18],r13
  408b55:	mov    QWORD PTR [rax+0x20],rdi
  408b59:	lea    rdi,[rip+0xa818]        # 413378 <__swc_rdata_base_3464c816+0x268>
  408b60:	mov    QWORD PTR [rax+0x28],rdi
  408b64:	mov    QWORD PTR [rax+0x30],r14
  408b68:	mov    QWORD PTR [rax+0x38],r13
  408b6c:	lea    rcx,[rsp+0x10]
  408b71:	mov    QWORD PTR [rax+0x40],rcx
  408b75:	mov    QWORD PTR [rax+0x48],0x3
  408b7d:	lea    rcx,[rsp+0x40]
  408b82:	sub    rsp,0x8
  408b86:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  408b8b:	add    rsp,0x8
  408b8f:	add    rsp,0x50
  408b93:	lea    rax,[rip+0xa826]        # 4133c0 <__swc_rdata_base_3464c816+0x2b0>
  408b9a:	sub    rsp,0x20
  408b9e:	mov    rcx,rsp
  408ba1:	mov    QWORD PTR [rcx],rax
  408ba4:	mov    QWORD PTR [rcx+0x8],r13
  408ba8:	mov    QWORD PTR [rcx+0x10],rsp
  408bac:	mov    QWORD PTR [rcx+0x18],0x1
  408bb4:	lea    rcx,[rsp+0x10]
  408bb9:	sub    rsp,0x8
  408bbd:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  408bc2:	add    rsp,0x8
  408bc6:	add    rsp,0x20
  408bca:	mov    eax,DWORD PTR [rsi+0x20]
  408bcd:	mov    ecx,DWORD PTR [rsi+0x24]
  408bd0:	sub    rsp,0xa0
  408bd7:	mov    rdx,rsp
  408bda:	mov    QWORD PTR [rdx+0x30],rsi
  408bde:	mov    QWORD PTR [rdx+0x38],rdi
  408be2:	vmovups xmm0,XMMWORD PTR [rip+0xa84e]        # 413438 <__swc_rdata_base_3464c816+0x328>
  408bea:	vmovups XMMWORD PTR [rdx],xmm0
  408bee:	mov    QWORD PTR [rdx+0x40],rsp
  408bf2:	mov    QWORD PTR [rdx+0x48],r13
  408bf6:	mov    DWORD PTR [rdx+0x10],eax
  408bf9:	lea    rax,[rsp+0x10]
  408bfe:	mov    QWORD PTR [rdx+0x50],rax
  408c02:	lea    rax,[rip+0xa7c7]        # 4133d0 <__swc_rdata_base_3464c816+0x2c0>
  408c09:	mov    QWORD PTR [rdx+0x58],rax
  408c0d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c12:	lea    r8,[rsp+0x18]
  408c17:	mov    QWORD PTR [rdx+0x60],r8
  408c1b:	mov    QWORD PTR [rdx+0x68],r13
  408c1f:	mov    DWORD PTR [rdx+0x28],ecx
  408c22:	lea    rcx,[rdx+0x28]
  408c26:	mov    QWORD PTR [rdx+0x70],rcx
  408c2a:	mov    QWORD PTR [rdx+0x78],rax
  408c2e:	mov    QWORD PTR [rdx+0x80],r14
  408c35:	mov    QWORD PTR [rdx+0x88],r13
  408c3c:	lea    rax,[rdx+0x30]
  408c40:	mov    QWORD PTR [rdx+0x90],rax
  408c47:	mov    QWORD PTR [rdx+0x98],0x6
  408c52:	lea    rcx,[rdx+0x90]
  408c59:	sub    rsp,0x8
  408c5d:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  408c62:	add    rsp,0x8
  408c66:	add    rsp,0xa0
  408c6d:	sub    rsp,0x20
  408c71:	mov    rax,rsp
  408c74:	mov    QWORD PTR [rax],r14
  408c77:	mov    QWORD PTR [rax+0x8],r13
  408c7b:	mov    QWORD PTR [rax+0x10],rsp
  408c7f:	mov    QWORD PTR [rax+0x18],0x1
  408c87:	lea    rcx,[rsp+0x10]
  408c8c:	sub    rsp,0x8
  408c90:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  408c95:	add    rsp,0x8
  408c99:	add    rsp,0x20
  408c9d:	mov    eax,DWORD PTR [r12+0x9ac]
  408ca5:	test   eax,eax
  408ca7:	je     408ee0 <__swc_fn_3464c816_000102_14986ec5+0x480>
  408cad:	lea    rax,[rip+0xa764]        # 413418 <__swc_rdata_base_3464c816+0x308>
  408cb4:	sub    rsp,0x20
  408cb8:	mov    rcx,rsp
  408cbb:	mov    QWORD PTR [rcx],rax
  408cbe:	mov    QWORD PTR [rcx+0x8],r13
  408cc2:	mov    QWORD PTR [rcx+0x10],rsp
  408cc6:	mov    QWORD PTR [rcx+0x18],0x1
  408cce:	lea    rcx,[rsp+0x10]
  408cd3:	sub    rsp,0x8
  408cd7:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  408cdc:	add    rsp,0x8
  408ce0:	add    rsp,0x20
  408ce4:	mov    eax,DWORD PTR [r12+0x9ac]
  408cec:	dec    eax
  408cee:	mov    esi,eax
  408cf0:	test   esi,esi
  408cf2:	jl     408eb0 <__swc_fn_3464c816_000102_14986ec5+0x450>
  408cf8:	jmp    408d04 <__swc_fn_3464c816_000102_14986ec5+0x2a4>
  408cfa:	nop    WORD PTR [rax+rax*1+0x0]
  408d00:	dec    esi
  408d02:	jmp    408cf0 <__swc_fn_3464c816_000102_14986ec5+0x290>
  408d04:	lea    rax,[rip+0xa71d]        # 413428 <__swc_rdata_base_3464c816+0x318>
  408d0b:	sub    rsp,0x20
  408d0f:	mov    rcx,rsp
  408d12:	mov    QWORD PTR [rcx],rax
  408d15:	mov    QWORD PTR [rcx+0x8],r13
  408d19:	mov    QWORD PTR [rcx+0x10],rsp
  408d1d:	mov    QWORD PTR [rcx+0x18],0x1
  408d25:	lea    rcx,[rsp+0x10]
  408d2a:	sub    rsp,0x8
  408d2e:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  408d33:	add    rsp,0x8
  408d37:	add    rsp,0x20
  408d3b:	movsxd rax,esi
  408d3e:	imul   r15,rax,0x30
  408d42:	add    r15,r12
  408d45:	add    r15,0xf8
  408d4c:	sub    rsp,0x20
  408d50:	mov    rax,rsp
  408d53:	mov    QWORD PTR [rax],r15
  408d56:	mov    QWORD PTR [rax+0x8],rdi
  408d5a:	mov    QWORD PTR [rax+0x10],rsp
  408d5e:	mov    QWORD PTR [rax+0x18],0x1
  408d66:	lea    rcx,[rsp+0x10]
  408d6b:	sub    rsp,0x8
  408d6f:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  408d74:	add    rsp,0x8
  408d78:	add    rsp,0x20
  408d7c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408d84:	lea    rsi,[rip+0xa6ad]        # 413438 <__swc_rdata_base_3464c816+0x328>
  408d8b:	sub    rsp,0x20
  408d8f:	mov    rax,rsp
  408d92:	mov    QWORD PTR [rax],rsi
  408d95:	mov    QWORD PTR [rax+0x8],r13
  408d99:	mov    QWORD PTR [rax+0x10],rsp
  408d9d:	mov    QWORD PTR [rax+0x18],0x1
  408da5:	lea    rcx,[rsp+0x10]
  408daa:	sub    rsp,0x8
  408dae:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  408db3:	add    rsp,0x8
  408db7:	add    rsp,0x20
  408dbb:	sub    rsp,0x30
  408dbf:	mov    rax,rsp
  408dc2:	mov    ecx,DWORD PTR [r15+0x20]
  408dc6:	mov    QWORD PTR [rax],rcx
  408dc9:	mov    QWORD PTR [rax+0x8],rsp
  408dcd:	lea    rdi,[rip+0xa674]        # 413448 <__swc_rdata_base_3464c816+0x338>
  408dd4:	mov    QWORD PTR [rax+0x10],rdi
  408dd8:	lea    rcx,[rsp+0x8]
  408ddd:	mov    QWORD PTR [rax+0x18],rcx
  408de1:	mov    QWORD PTR [rax+0x20],0x1
  408de9:	lea    rcx,[rsp+0x18]
  408dee:	sub    rsp,0x8
  408df2:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  408df7:	add    rsp,0x8
  408dfb:	add    rsp,0x30
  408dff:	sub    rsp,0x20
  408e03:	mov    rax,rsp
  408e06:	mov    QWORD PTR [rax],rsi
  408e09:	mov    QWORD PTR [rax+0x8],r13
  408e0d:	mov    QWORD PTR [rax+0x10],rsp
  408e11:	mov    QWORD PTR [rax+0x18],0x1
  408e19:	lea    rcx,[rsp+0x10]
  408e1e:	sub    rsp,0x8
  408e22:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  408e27:	add    rsp,0x8
  408e2b:	add    rsp,0x20
  408e2f:	sub    rsp,0x30
  408e33:	mov    rax,rsp
  408e36:	mov    ecx,DWORD PTR [r15+0x24]
  408e3a:	mov    QWORD PTR [rax],rcx
  408e3d:	mov    QWORD PTR [rax+0x8],rsp
  408e41:	mov    QWORD PTR [rax+0x10],rdi
  408e45:	lea    rcx,[rsp+0x8]
  408e4a:	mov    QWORD PTR [rax+0x18],rcx
  408e4e:	mov    QWORD PTR [rax+0x20],0x1
  408e56:	lea    rcx,[rsp+0x18]
  408e5b:	sub    rsp,0x8
  408e5f:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  408e64:	add    rsp,0x8
  408e68:	add    rsp,0x30
  408e6c:	sub    rsp,0x20
  408e70:	mov    rax,rsp
  408e73:	mov    QWORD PTR [rax],r14
  408e76:	mov    QWORD PTR [rax+0x8],r13
  408e7a:	mov    QWORD PTR [rax+0x10],rsp
  408e7e:	mov    QWORD PTR [rax+0x18],0x1
  408e86:	lea    rcx,[rsp+0x10]
  408e8b:	sub    rsp,0x8
  408e8f:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  408e94:	add    rsp,0x8
  408e98:	add    rsp,0x20
  408e9c:	lea    rdi,[rip+0xa4d5]        # 413378 <__swc_rdata_base_3464c816+0x268>
  408ea3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408eab:	jmp    408d00 <__swc_fn_3464c816_000102_14986ec5+0x2a0>
  408eb0:	sub    rsp,0x20
  408eb4:	mov    rax,rsp
  408eb7:	mov    QWORD PTR [rax],r14
  408eba:	mov    QWORD PTR [rax+0x8],r13
  408ebe:	mov    QWORD PTR [rax+0x10],rsp
  408ec2:	mov    QWORD PTR [rax+0x18],0x1
  408eca:	lea    rcx,[rsp+0x10]
  408ecf:	sub    rsp,0x8
  408ed3:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  408ed8:	add    rsp,0x8
  408edc:	add    rsp,0x20
  408ee0:	lea    rax,[rbx+0x28]
  408ee4:	mov    rcx,rax
  408ee7:	mov    QWORD PTR [rbx+0x28],0x0
  408eef:	mov    QWORD PTR [rbx+0x30],0x0
  408ef7:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408efc:	add    rcx,0x10
  408f00:	mov    edx,0x1f
  408f05:	cs nop WORD PTR [rax+rax*1+0x0]
  408f0f:	nop
  408f10:	vmovups XMMWORD PTR [rcx],xmm0
  408f14:	add    rcx,0x10
  408f18:	sub    rdx,0x1
  408f1c:	jne    408f10 <__swc_fn_3464c816_000102_14986ec5+0x4b0>
  408f1e:	lea    rsi,[rbx+0x228]
  408f25:	xor    ecx,ecx
  408f27:	cs nop WORD PTR [rax+rax*1+0x0]
  408f31:	cs nop WORD PTR [rax+rax*1+0x0]
  408f3b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f40:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f45:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f4a:	add    rcx,0x10
  408f4e:	cmp    rcx,0x200
  408f55:	jne    408f40 <__swc_fn_3464c816_000102_14986ec5+0x4e0>
  408f57:	mov    eax,DWORD PTR [r12+0xbc8]
  408f5f:	lea    rcx,[r12+0x9c8]
  408f67:	mov    QWORD PTR [rbx+0x428],rcx
  408f6e:	mov    QWORD PTR [rbx+0x430],rax
  408f75:	lea    rdi,[rbx+0x438]
  408f7c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408f84:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408f8c:	mov    eax,DWORD PTR [r12+0xbc8]
  408f94:	test   eax,eax
  408f96:	jne    408fe3 <__swc_fn_3464c816_000102_14986ec5+0x583>
  408f98:	lea    rax,[rbx+0x448]
  408f9f:	mov    QWORD PTR [rbx+0x448],rsi
  408fa6:	mov    QWORD PTR [rax+0x8],0x40
  408fae:	mov    ecx,0x1
  408fb3:	mov    rdx,rax
  408fb6:	sub    rsp,0x8
  408fba:	call   410180 <__swc_fn_3464c816_000119_2d9caf16>
  408fbf:	add    rsp,0x8
  408fc3:	mov    QWORD PTR [rbx+0x460],rsi
  408fca:	mov    ecx,eax
  408fcc:	mov    QWORD PTR [rbx+0x468],rcx
  408fd3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408fdb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fe3:	mov    rsi,QWORD PTR [rbx+0x438]
  408fea:	mov    rax,QWORD PTR [rbx+0x440]
  408ff1:	mov    r15,rax
  408ff4:	xor    r12d,r12d
  408ff7:	test   r15,r15
  408ffa:	je     4090b0 <__swc_fn_3464c816_000102_14986ec5+0x650>
  409000:	mov    rax,QWORD PTR [rsi+r12*8]
  409004:	test   rax,rax
  409007:	je     409026 <__swc_fn_3464c816_000102_14986ec5+0x5c6>
  409009:	lea    rcx,[rbx+0x4b8]
  409010:	mov    rdx,rax
  409013:	sub    rsp,0x8
  409017:	call   409f10 <__swc_fn_3464c816_000162_61e293bf>
  40901c:	add    rsp,0x8
  409020:	mov    al,BYTE PTR [rax]
  409022:	test   al,al
  409024:	jne    409032 <__swc_fn_3464c816_000102_14986ec5+0x5d2>
  409026:	add    r12,0x1
  40902a:	sub    r15,0x1
  40902e:	jne    409000 <__swc_fn_3464c816_000102_14986ec5+0x5a0>
  409030:	jmp    4090b0 <__swc_fn_3464c816_000102_14986ec5+0x650>
  409032:	lea    rax,[rip+0xa457]        # 413490 <__swc_rdata_base_3464c816+0x380>
  409039:	sub    rsp,0x20
  40903d:	mov    rcx,rsp
  409040:	mov    QWORD PTR [rcx],rax
  409043:	mov    QWORD PTR [rcx+0x8],r13
  409047:	mov    QWORD PTR [rcx+0x10],rsp
  40904b:	mov    QWORD PTR [rcx+0x18],0x1
  409053:	lea    rcx,[rsp+0x10]
  409058:	sub    rsp,0x8
  40905c:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  409061:	add    rsp,0x8
  409065:	add    rsp,0x20
  409069:	mov    rcx,rdi
  40906c:	xor    edx,edx
  40906e:	mov    al,0x1
  409070:	mov    r8,rax
  409073:	sub    rsp,0x8
  409077:	call   40d260 <__swc_fn_3464c816_000163_3a7aae74>
  40907c:	add    rsp,0x8
  409080:	sub    rsp,0x20
  409084:	mov    rax,rsp
  409087:	mov    QWORD PTR [rax],r14
  40908a:	mov    QWORD PTR [rax+0x8],r13
  40908e:	mov    QWORD PTR [rax+0x10],rsp
  409092:	mov    QWORD PTR [rax+0x18],0x1
  40909a:	lea    rcx,[rsp+0x10]
  40909f:	sub    rsp,0x8
  4090a3:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  4090a8:	add    rsp,0x8
  4090ac:	add    rsp,0x20
  4090b0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090b8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090c4:	add    rsp,0x500
  4090cb:	pop    r15
  4090cd:	pop    r14
  4090cf:	pop    r13
  4090d1:	pop    r12
  4090d3:	pop    rdi
  4090d4:	pop    rsi
  4090d5:	pop    rbx
  4090d6:	pop    rbp
  4090d7:	ret
	...

00000000004090e0 <__swc_fn_3464c816_000105_83487ba1>:
  4090e0:	sub    rsp,0x8
  4090e4:	test   r8,r8
  4090e7:	je     4090ee <__swc_fn_3464c816_000105_83487ba1+0xe>
  4090e9:	call   40f8b0 <__swc_fn_3464c816_000104_04d1a8be>
  4090ee:	add    rsp,0x8
  4090f2:	ret
	...

0000000000409100 <__swc_fn_3464c816_000108_b8f4bd15>:
  409100:	push   rsi
  409101:	push   rdi
  409102:	push   r12
  409104:	push   r13
  409106:	sub    rsp,0xd8
  40910d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409113:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  409119:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40911f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  409125:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40912b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  409134:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40913d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  409146:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40914f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  409158:	xor    eax,eax
  40915a:	call   407010 <getpid@plt>
  40915f:	mov    rsi,rax
  409162:	lea    rdi,[rip+0x1dbdf]        # 426d48 <__swc_bss_base_3464c816+0x2d08>
  409169:	mov    r12,QWORD PTR [rdi]
  40916c:	test   r12,r12
  40916f:	je     40917d <__swc_fn_3464c816_000108_b8f4bd15+0x7d>
  409171:	cmp    DWORD PTR [r12+0x10],esi
  409176:	jne    40917d <__swc_fn_3464c816_000108_b8f4bd15+0x7d>
  409178:	mov    rax,r12
  40917b:	jmp    4091e0 <__swc_fn_3464c816_000108_b8f4bd15+0xe0>
  40917d:	mov    ecx,0x4
  409182:	mov    edx,0x18
  409187:	call   40f990 <__swc_fn_3464c816_000107_c8d4a68e>
  40918c:	mov    rcx,rax
  40918f:	test   rax,rax
  409192:	jne    409198 <__swc_fn_3464c816_000108_b8f4bd15+0x98>
  409194:	xor    eax,eax
  409196:	jmp    4091e0 <__swc_fn_3464c816_000108_b8f4bd15+0xe0>
  409198:	mov    DWORD PTR [rcx+0x10],esi
  40919b:	mov    rax,r12
  40919e:	lock cmpxchg QWORD PTR [rdi],rcx
  4091a3:	mov    r13,rax
  4091a6:	cmp    rax,r12
  4091a9:	je     4091bf <__swc_fn_3464c816_000108_b8f4bd15+0xbf>
  4091ab:	mov    rdi,rcx
  4091ae:	mov    esi,0x18
  4091b3:	xor    eax,eax
  4091b5:	call   407020 <munmap@plt>
  4091ba:	mov    rax,r13
  4091bd:	jmp    4091e0 <__swc_fn_3464c816_000108_b8f4bd15+0xe0>
  4091bf:	test   r12,r12
  4091c2:	je     4091dd <__swc_fn_3464c816_000108_b8f4bd15+0xdd>
  4091c4:	mov    rdi,r12
  4091c7:	mov    esi,0x18
  4091cc:	xor    eax,eax
  4091ce:	mov    QWORD PTR [rsp+0x28],rcx
  4091d3:	call   407020 <munmap@plt>
  4091d8:	mov    rcx,QWORD PTR [rsp+0x28]
  4091dd:	mov    rax,rcx
  4091e0:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  4091e6:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  4091ec:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  4091f2:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  4091f8:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  4091fe:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409207:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  409210:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409219:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  409222:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40922b:	add    rsp,0xd8
  409232:	pop    r13
  409234:	pop    r12
  409236:	pop    rdi
  409237:	pop    rsi
  409238:	ret
  409239:	add    BYTE PTR [rax],al
  40923b:	add    BYTE PTR [rax],al
  40923d:	add    BYTE PTR [rax],al
	...

0000000000409240 <__swc_fn_3464c816_000111_f9e19033>:
  409240:	push   rbx
  409241:	push   r12
  409243:	push   rdi
  409244:	push   rsi
  409245:	sub    rsp,0xa8
  40924c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409252:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409258:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40925e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409264:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40926a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409270:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409276:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40927c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409285:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40928e:	mov    rbx,rdx
  409291:	mov    r12,rcx
  409294:	mov    rdi,rcx
  409297:	mov    rsi,rdx
  40929a:	mov    edx,0x3
  40929f:	xor    eax,eax
  4092a1:	call   407030 <mprotect@plt>
  4092a6:	test   eax,eax
  4092a8:	je     4092ae <__swc_fn_3464c816_000111_f9e19033+0x6e>
  4092aa:	xor    eax,eax
  4092ac:	jmp    4092c3 <__swc_fn_3464c816_000111_f9e19033+0x83>
  4092ae:	mov    rcx,r12
  4092b1:	mov    rdx,rbx
  4092b4:	mov    al,0x1
  4092b6:	mov    r8,rax
  4092b9:	call   40ffc0 <__swc_fn_3464c816_000110_918d5a21>
  4092be:	mov    eax,0x1
  4092c3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4092c9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4092cf:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4092d5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4092db:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4092e1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4092e7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4092ed:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4092f3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4092fc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409305:	add    rsp,0xa8
  40930c:	pop    rsi
  40930d:	pop    rdi
  40930e:	pop    r12
  409310:	pop    rbx
  409311:	ret
	...

0000000000409320 <__swc_fn_3464c816_000114_cc486df9>:
  409320:	sub    rsp,0x8
  409324:	test   rcx,rcx
  409327:	jne    40932e <__swc_fn_3464c816_000114_cc486df9+0xe>
  409329:	add    rsp,0x8
  40932d:	ret
  40932e:	call   40c880 <__swc_fn_3464c816_000115_3f6af4b1>
  409333:	add    rsp,0x8
  409337:	ret
	...

0000000000409340 <__swc_fn_3464c816_000117_5aba1420>:
  409340:	push   rdi
  409341:	push   rsi
  409342:	sub    rsp,0xa8
  409349:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40934f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409355:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40935b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409361:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409367:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40936d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409373:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409379:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409382:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40938b:	xor    edi,edi
  40938d:	xor    eax,eax
  40938f:	call   407040 <exit@plt>
  409394:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40939a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4093a0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4093a6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4093ac:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4093b2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4093b8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4093be:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4093c4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4093cd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4093d6:	add    rsp,0xa8
  4093dd:	pop    rsi
  4093de:	pop    rdi
  4093df:	ret

00000000004093e0 <__swc_fn_3464c816_000120_1e032ef6>:
  4093e0:	push   rbx
  4093e1:	push   rsi
  4093e2:	push   rdi
  4093e3:	push   r12
  4093e5:	sub    rsp,0x18
  4093e9:	mov    rbx,r8
  4093ec:	mov    rsi,rcx
  4093ef:	mov    rdi,rdx
  4093f2:	mov    rcx,QWORD PTR [rip+0x1d947]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  4093f9:	test   rcx,rcx
  4093fc:	jne    40940e <__swc_fn_3464c816_000120_1e032ef6+0x2e>
  4093fe:	call   40a1a0 <__swc_fn_3464c816_000165_56054fe7>
  409403:	lea    rcx,[rax+0x1]
  409407:	mov    QWORD PTR [rip+0x1d932],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40940e:	dec    rcx
  409411:	call   411e20 <__swc_fn_3464c816_000167_39c041ad>
  409416:	mov    r12,rax
  409419:	cmp    ebx,0x3
  40941c:	jne    40942f <__swc_fn_3464c816_000120_1e032ef6+0x4f>
  40941e:	mov    rax,QWORD PTR [r12+0xbd0]
  409426:	test   rax,rax
  409429:	jne    40956c <__swc_fn_3464c816_000120_1e032ef6+0x18c>
  40942f:	cmp    ebx,0x5
  409432:	jne    409456 <__swc_fn_3464c816_000120_1e032ef6+0x76>
  409434:	call   40c150 <__swc_fn_3464c816_000091_f21926ed>
  409439:	test   al,al
  40943b:	jne    409456 <__swc_fn_3464c816_000120_1e032ef6+0x76>
  40943d:	mov    rcx,rsi
  409440:	mov    rdx,rdi
  409443:	call   411dd0 <__swc_fn_3464c816_000164_d25850aa>
  409448:	test   al,al
  40944a:	je     409456 <__swc_fn_3464c816_000120_1e032ef6+0x76>
  40944c:	add    rsp,0x18
  409450:	pop    r12
  409452:	pop    rdi
  409453:	pop    rsi
  409454:	pop    rbx
  409455:	ret
  409456:	call   40c150 <__swc_fn_3464c816_000091_f21926ed>
  40945b:	test   al,al
  40945d:	jne    4094cf <__swc_fn_3464c816_000120_1e032ef6+0xef>
  40945f:	vmovups xmm0,XMMWORD PTR [rsi]
  409463:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409469:	mov    rax,QWORD PTR [rsp+0x8]
  40946e:	test   rax,rax
  409471:	jne    4094c2 <__swc_fn_3464c816_000120_1e032ef6+0xe2>
  409473:	cmp    ebx,0x3
  409476:	je     409484 <__swc_fn_3464c816_000120_1e032ef6+0xa4>
  409478:	cmp    ebx,0x4
  40947b:	je     409494 <__swc_fn_3464c816_000120_1e032ef6+0xb4>
  40947d:	cmp    ebx,0x5
  409480:	je     4094a4 <__swc_fn_3464c816_000120_1e032ef6+0xc4>
  409482:	jmp    4094b4 <__swc_fn_3464c816_000120_1e032ef6+0xd4>
  409484:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 4134e0 <__swc_rdata_base_3464c816+0x3d0>
  40948c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409492:	jmp    4094c2 <__swc_fn_3464c816_000120_1e032ef6+0xe2>
  409494:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 4134f0 <__swc_rdata_base_3464c816+0x3e0>
  40949c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094a2:	jmp    4094c2 <__swc_fn_3464c816_000120_1e032ef6+0xe2>
  4094a4:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 413500 <__swc_rdata_base_3464c816+0x3f0>
  4094ac:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094b2:	jmp    4094c2 <__swc_fn_3464c816_000120_1e032ef6+0xe2>
  4094b4:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 413510 <__swc_rdata_base_3464c816+0x400>
  4094bc:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094c2:	lea    rcx,[rsp+0x8]
  4094c7:	mov    rdx,rdi
  4094ca:	call   40c3a0 <__swc_fn_3464c816_000103_0d4cc079>
  4094cf:	vmovups xmm0,XMMWORD PTR [rdi]
  4094d3:	vmovups XMMWORD PTR [r12+0x940],xmm0
  4094dd:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  4094e2:	vmovups XMMWORD PTR [r12+0x950],xmm0
  4094ec:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  4094f1:	vmovups XMMWORD PTR [r12+0x960],xmm0
  4094fb:	lea    rax,[r12+0x940]
  409503:	mov    QWORD PTR [r12+0x970],rax
  40950b:	mov    rax,QWORD PTR [rsi]
  40950e:	mov    QWORD PTR [r12+0x978],rax
  409516:	mov    rax,QWORD PTR [rsi+0x8]
  40951a:	mov    QWORD PTR [r12+0x980],rax
  409522:	movsxd rax,ebx
  409525:	mov    QWORD PTR [r12+0x988],rax
  40952d:	cmp    ebx,0x5
  409530:	je     409539 <__swc_fn_3464c816_000120_1e032ef6+0x159>
  409532:	xor    ecx,ecx
  409534:	call   40a2d0 <__swc_fn_3464c816_000174_02e645b4>
  409539:	mov    rbx,QWORD PTR [r12+0xbe8]
  409541:	test   rbx,rbx
  409544:	je     409555 <__swc_fn_3464c816_000120_1e032ef6+0x175>
  409546:	mov    rcx,r12
  409549:	call   rbx
  40954b:	add    rsp,0x18
  40954f:	pop    r12
  409551:	pop    rdi
  409552:	pop    rsi
  409553:	pop    rbx
  409554:	ret
  409555:	mov    rcx,rsi
  409558:	call   410070 <__swc_fn_3464c816_000116_3f5cfdef>
  40955d:	call   40c9d0 <__swc_fn_3464c816_000118_591530fe>
  409562:	add    rsp,0x18
  409566:	pop    r12
  409568:	pop    rdi
  409569:	pop    rsi
  40956a:	pop    rbx
  40956b:	ret
  40956c:	mov    rcx,rsi
  40956f:	mov    rdx,rdi
  409572:	call   40c3a0 <__swc_fn_3464c816_000103_0d4cc079>
  409577:	jmp    40942f <__swc_fn_3464c816_000120_1e032ef6+0x4f>
  40957c:	add    BYTE PTR [rax],al
	...

0000000000409580 <__swc_fn_3464c816_000123_e4107ade>:
  409580:	push   rdi
  409581:	push   rsi
  409582:	sub    rsp,0xb8
  409589:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40958f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409595:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40959b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4095a1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4095a7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4095ad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4095b3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4095bc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4095c5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4095ce:	mov    DWORD PTR [rsp+0x8],0x0
  4095d6:	lea    rdi,[rsp+0x8]
  4095db:	xor    esi,esi
  4095dd:	xor    eax,eax
  4095df:	call   407050 <pthread_key_create@plt>
  4095e4:	test   eax,eax
  4095e6:	jne    4095ee <__swc_fn_3464c816_000123_e4107ade+0x6e>
  4095e8:	mov    eax,DWORD PTR [rsp+0x8]
  4095ec:	jmp    4095f5 <__swc_fn_3464c816_000123_e4107ade+0x75>
  4095ee:	mov    rax,0xffffffffffffffff
  4095f5:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4095fb:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409601:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409607:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40960d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409613:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409619:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40961f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409628:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409631:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40963a:	add    rsp,0xb8
  409641:	pop    rsi
  409642:	pop    rdi
  409643:	ret
	...

0000000000409650 <__swc_fn_3464c816_000126_9e9697c7>:
  409650:	push   rdi
  409651:	push   rsi
  409652:	sub    rsp,0xb8
  409659:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40965f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409665:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40966b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409671:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409677:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40967d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409683:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40968c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409695:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40969e:	mov    DWORD PTR [rsp+0x8],0x0
  4096a6:	lea    rdi,[rsp+0x8]
  4096ab:	mov    rsi,rcx
  4096ae:	xor    eax,eax
  4096b0:	call   407050 <pthread_key_create@plt>
  4096b5:	test   eax,eax
  4096b7:	jne    4096c2 <__swc_fn_3464c816_000126_9e9697c7+0x72>
  4096b9:	mov    eax,DWORD PTR [rsp+0x8]
  4096bd:	inc    rax
  4096c0:	jmp    4096c4 <__swc_fn_3464c816_000126_9e9697c7+0x74>
  4096c2:	xor    eax,eax
  4096c4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4096ca:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4096d0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4096d6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4096dc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4096e2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4096e8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4096ee:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4096f7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409700:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409709:	add    rsp,0xb8
  409710:	pop    rsi
  409711:	pop    rdi
  409712:	ret
	...

0000000000409720 <__swc_fn_3464c816_000129_bc477461>:
  409720:	push   rdi
  409721:	push   rsi
  409722:	sub    rsp,0xa8
  409729:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40972f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409735:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40973b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409741:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409747:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40974d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409753:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409759:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409762:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40976b:	test   rcx,rcx
  40976e:	setne  al
  409771:	je     40978a <__swc_fn_3464c816_000129_bc477461+0x6a>
  409773:	lea    rax,[rcx-0x1]
  409777:	mov    eax,eax
  409779:	mov    edi,eax
  40977b:	mov    rsi,rdx
  40977e:	xor    eax,eax
  409780:	call   407060 <pthread_setspecific@plt>
  409785:	test   eax,eax
  409787:	sete   al
  40978a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409790:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409796:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40979c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4097a2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4097a8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4097ae:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4097b4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4097ba:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4097c3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4097cc:	add    rsp,0xa8
  4097d3:	pop    rsi
  4097d4:	pop    rdi
  4097d5:	ret
	...

00000000004097e0 <__swc_fn_3464c816_000132_51cc49e7>:
  4097e0:	push   rdi
  4097e1:	push   rsi
  4097e2:	sub    rsp,0xa8
  4097e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4097ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4097f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4097fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409801:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409807:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40980d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409813:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409819:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409822:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40982b:	mov    rax,rdx
  40982e:	mov    QWORD PTR [rsp],0x0
  409836:	mov    edi,0xca
  40983b:	mov    rsi,rcx
  40983e:	mov    edx,0x81
  409843:	mov    eax,eax
  409845:	mov    ecx,eax
  409847:	xor    r8d,r8d
  40984a:	xor    r9d,r9d
  40984d:	xor    eax,eax
  40984f:	call   407070 <syscall@plt>
  409854:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40985a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409860:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409866:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40986c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409872:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409878:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40987e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409884:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40988d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409896:	add    rsp,0xa8
  40989d:	pop    rsi
  40989e:	pop    rdi
  40989f:	ret

00000000004098a0 <__swc_fn_3464c816_000135_db32cc57>:
  4098a0:	sub    rsp,0x8
  4098a4:	call   40cd70 <__swc_fn_3464c816_000133_807fd51d>
  4098a9:	add    rsp,0x8
  4098ad:	ret
	...

00000000004098b0 <__swc_fn_3464c816_000138_22d6573c>:
  4098b0:	push   rdi
  4098b1:	push   rsi
  4098b2:	sub    rsp,0xc8
  4098b9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4098bf:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4098c5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4098cb:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4098d1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4098d7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4098dd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  4098e6:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  4098ef:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  4098f8:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  409901:	vxorps xmm0,xmm0,xmm0
  409905:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40990b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409911:	mov    rdi,rcx
  409914:	lea    rsi,[rsp+0x8]
  409919:	xor    eax,eax
  40991b:	call   407080 <dladdr@plt>
  409920:	xor    ecx,ecx
  409922:	test   eax,eax
  409924:	je     40992b <__swc_fn_3464c816_000138_22d6573c+0x7b>
  409926:	mov    rcx,QWORD PTR [rsp+0x10]
  40992b:	mov    rax,rcx
  40992e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  409934:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40993a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  409940:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  409946:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40994c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  409952:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40995b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  409964:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40996d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  409976:	add    rsp,0xc8
  40997d:	pop    rsi
  40997e:	pop    rdi
  40997f:	ret

0000000000409980 <__swc_fn_3464c816_000141_5e493395>:
  409980:	push   rbx
  409981:	push   r12
  409983:	push   r13
  409985:	push   rdi
  409986:	push   rsi
  409987:	push   r14
  409989:	push   r15
  40998b:	sub    rsp,0x150
  409992:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40999b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  4099a4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  4099ad:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  4099b6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  4099bf:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4099c8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4099d1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4099da:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  4099e3:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  4099ec:	mov    rbx,rdx
  4099ef:	mov    QWORD PTR [rsp+0x98],rdx
  4099f7:	mov    r12,rcx
  4099fa:	mov    QWORD PTR [rsp+0xa0],rcx
  409a02:	mov    QWORD PTR [rbx],0x0
  409a09:	lea    r13,[rip+0x1d370]        # 426d80 <__swc_bss_base_3464c816+0x2d40>
  409a10:	mov    rcx,r13
  409a13:	call   4098a0 <__swc_fn_3464c816_000135_db32cc57>
  409a18:	mov    rax,QWORD PTR [rip+0x1d369]        # 426d88 <__swc_bss_base_3464c816+0x2d48>
  409a1f:	test   rax,rax
  409a22:	je     409a59 <__swc_fn_3464c816_000141_5e493395+0xd9>
  409a24:	cs nop WORD PTR [rax+rax*1+0x0]
  409a2e:	xchg   ax,ax
  409a30:	cmp    QWORD PTR [rax+0x8],r12
  409a34:	jne    409a51 <__swc_fn_3464c816_000141_5e493395+0xd1>
  409a36:	mov    rcx,QWORD PTR [rax+0x18]
  409a3a:	mov    QWORD PTR [rbx],rcx
  409a3d:	mov    rbx,QWORD PTR [rax+0x10]
  409a41:	mov    rcx,r13
  409a44:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  409a49:	mov    rax,rbx
  409a4c:	jmp    409c3b <__swc_fn_3464c816_000141_5e493395+0x2bb>
  409a51:	mov    rax,QWORD PTR [rax]
  409a54:	test   rax,rax
  409a57:	jne    409a30 <__swc_fn_3464c816_000141_5e493395+0xb0>
  409a59:	vxorps xmm0,xmm0,xmm0
  409a5d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  409a63:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  409a69:	mov    rdi,r12
  409a6c:	lea    rsi,[rsp+0x10]
  409a71:	xor    eax,eax
  409a73:	call   407080 <dladdr@plt>
  409a78:	test   eax,eax
  409a7a:	sete   al
  409a7d:	je     409a8a <__swc_fn_3464c816_000141_5e493395+0x10a>
  409a7f:	mov    rax,QWORD PTR [rsp+0x10]
  409a84:	test   rax,rax
  409a87:	sete   al
  409a8a:	test   al,al
  409a8c:	je     409a9d <__swc_fn_3464c816_000141_5e493395+0x11d>
  409a8e:	mov    rcx,r13
  409a91:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  409a96:	xor    eax,eax
  409a98:	jmp    409c3b <__swc_fn_3464c816_000141_5e493395+0x2bb>
  409a9d:	mov    rdi,QWORD PTR [rsp+0x10]
  409aa2:	mov    esi,0x80000
  409aa7:	xor    eax,eax
  409aa9:	call   407090 <open@plt>
  409aae:	lea    r14,[rsp+0x30]
  409ab3:	mov    DWORD PTR [rsp+0x30],eax
  409ab7:	cmp    DWORD PTR [r14],0x0
  409abb:	jge    409acc <__swc_fn_3464c816_000141_5e493395+0x14c>
  409abd:	mov    rcx,r13
  409ac0:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  409ac5:	xor    eax,eax
  409ac7:	jmp    409c3b <__swc_fn_3464c816_000141_5e493395+0x2bb>
  409acc:	mov    rax,r14
  409acf:	movsxd rdi,DWORD PTR [rax]
  409ad2:	xor    esi,esi
  409ad4:	mov    edx,0x2
  409ad9:	xor    eax,eax
  409adb:	call   4070a0 <lseek@plt>
  409ae0:	mov    r15,rax
  409ae3:	test   rax,rax
  409ae6:	jg     409b01 <__swc_fn_3464c816_000141_5e493395+0x181>
  409ae8:	movsxd rdi,DWORD PTR [r14]
  409aeb:	xor    eax,eax
  409aed:	call   4070b0 <close@plt>
  409af2:	mov    rcx,r13
  409af5:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  409afa:	xor    eax,eax
  409afc:	jmp    409c3b <__swc_fn_3464c816_000141_5e493395+0x2bb>
  409b01:	xor    edi,edi
  409b03:	mov    rsi,r15
  409b06:	mov    edx,0x1
  409b0b:	mov    ecx,0x2
  409b10:	mov    rax,r14
  409b13:	movsxd r8,DWORD PTR [rax]
  409b16:	xor    r9d,r9d
  409b19:	xor    eax,eax
  409b1b:	call   4070c0 <mmap@plt>
  409b20:	mov    rbx,rax
  409b23:	test   rax,rax
  409b26:	sete   al
  409b29:	cmp    rbx,0xffffffffffffffff
  409b2d:	sete   cl
  409b30:	or     al,cl
  409b32:	je     409b4d <__swc_fn_3464c816_000141_5e493395+0x1cd>
  409b34:	movsxd rdi,DWORD PTR [r14]
  409b37:	xor    eax,eax
  409b39:	call   4070b0 <close@plt>
  409b3e:	mov    rcx,r13
  409b41:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  409b46:	xor    eax,eax
  409b48:	jmp    409c3b <__swc_fn_3464c816_000141_5e493395+0x2bb>
  409b4d:	lea    rax,[rsp+0x50]
  409b52:	mov    QWORD PTR [rax],0x0
  409b59:	mov    rcx,rbx
  409b5c:	mov    rdx,r15
  409b5f:	mov    r8,rax
  409b62:	call   410600 <__swc_fn_3464c816_000140_55003b6d>
  409b67:	mov    r12,rax
  409b6a:	test   rax,rax
  409b6d:	jne    409b95 <__swc_fn_3464c816_000141_5e493395+0x215>
  409b6f:	mov    rdi,rbx
  409b72:	mov    rsi,r15
  409b75:	xor    eax,eax
  409b77:	call   407020 <munmap@plt>
  409b7c:	movsxd rdi,DWORD PTR [r14]
  409b7f:	xor    eax,eax
  409b81:	call   4070b0 <close@plt>
  409b86:	mov    rcx,r13
  409b89:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  409b8e:	xor    eax,eax
  409b90:	jmp    409c3b <__swc_fn_3464c816_000141_5e493395+0x2bb>
  409b95:	mov    edi,0x20
  409b9a:	xor    eax,eax
  409b9c:	call   4070d0 <malloc@plt>
  409ba1:	test   rax,rax
  409ba4:	jne    409bc9 <__swc_fn_3464c816_000141_5e493395+0x249>
  409ba6:	mov    rdi,rbx
  409ba9:	mov    rsi,r15
  409bac:	xor    eax,eax
  409bae:	call   407020 <munmap@plt>
  409bb3:	movsxd rdi,DWORD PTR [r14]
  409bb6:	xor    eax,eax
  409bb8:	call   4070b0 <close@plt>
  409bbd:	mov    rcx,r13
  409bc0:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  409bc5:	xor    eax,eax
  409bc7:	jmp    409c3b <__swc_fn_3464c816_000141_5e493395+0x2bb>
  409bc9:	mov    rcx,QWORD PTR [rip+0x1d1b8]        # 426d88 <__swc_bss_base_3464c816+0x2d48>
  409bd0:	mov    QWORD PTR [rsp+0x70],rcx
  409bd5:	mov    rcx,QWORD PTR [rsp+0xa0]
  409bdd:	mov    QWORD PTR [rsp+0x78],rcx
  409be2:	mov    QWORD PTR [rsp+0x80],r12
  409bea:	mov    rcx,QWORD PTR [rsp+0x50]
  409bef:	mov    QWORD PTR [rsp+0x88],rcx
  409bf7:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  409bfd:	vmovups XMMWORD PTR [rax],xmm0
  409c01:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  409c0a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  409c0f:	mov    QWORD PTR [rip+0x1d172],rax        # 426d88 <__swc_bss_base_3464c816+0x2d48>
  409c16:	mov    rax,QWORD PTR [rsp+0x50]
  409c1b:	mov    rbx,QWORD PTR [rsp+0x98]
  409c23:	mov    QWORD PTR [rbx],rax
  409c26:	movsxd rdi,DWORD PTR [r14]
  409c29:	xor    eax,eax
  409c2b:	call   4070b0 <close@plt>
  409c30:	mov    rcx,r13
  409c33:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  409c38:	mov    rax,r12
  409c3b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  409c44:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  409c4d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  409c56:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  409c5f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  409c68:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  409c71:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  409c7a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  409c83:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  409c8c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  409c95:	add    rsp,0x150
  409c9c:	pop    r15
  409c9e:	pop    r14
  409ca0:	pop    rsi
  409ca1:	pop    rdi
  409ca2:	pop    r13
  409ca4:	pop    r12
  409ca6:	pop    rbx
  409ca7:	ret
	...

0000000000409cb0 <__swc_fn_3464c816_000144_c3e86ca0>:
  409cb0:	push   rbx
  409cb1:	sub    rsp,0xe0
  409cb8:	lea    rbx,[rsp+0x8]
  409cbd:	vxorps xmm0,xmm0,xmm0
  409cc1:	vmovups YMMWORD PTR [rbx],ymm0
  409cc5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  409cca:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  409ccf:	vzeroupper
  409cd2:	mov    DWORD PTR [rbx+0x60],0x0
  409cd9:	mov    r8,rbx
  409cdc:	nop    DWORD PTR [rax+0x0]
  409ce0:	mov    r9,rcx
  409ce3:	movabs rcx,0xcccccccccccccccd
  409ced:	mov    rax,r9
  409cf0:	mul    rcx
  409cf3:	mov    r10,rdx
  409cf6:	shr    r10,0x3
  409cfa:	mov    rcx,r10
  409cfd:	imul   rdx,r10,0xa
  409d01:	sub    r9,rdx
  409d04:	mov    rdx,QWORD PTR [rip+0x9835]        # 413540 <__swc_rdata_base_3464c816+0x430>
  409d0b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  409d10:	mov    BYTE PTR [r8],dl
  409d13:	lea    rdx,[r8+0x1]
  409d17:	mov    r8,rdx
  409d1a:	test   r10,r10
  409d1d:	jne    409ce0 <__swc_fn_3464c816_000144_c3e86ca0+0x30>
  409d1f:	mov    BYTE PTR [rdx],0x0
  409d22:	sub    r8,0x1
  409d26:	mov    rax,rbx
  409d29:	cmp    rax,r8
  409d2c:	jae    409d46 <__swc_fn_3464c816_000144_c3e86ca0+0x96>
  409d2e:	xchg   ax,ax
  409d30:	mov    cl,BYTE PTR [r8]
  409d33:	mov    dl,BYTE PTR [rax]
  409d35:	mov    BYTE PTR [r8],dl
  409d38:	sub    r8,0x1
  409d3c:	mov    BYTE PTR [rax],cl
  409d3e:	inc    rax
  409d41:	cmp    rax,r8
  409d44:	jb     409d30 <__swc_fn_3464c816_000144_c3e86ca0+0x80>
  409d46:	xor    eax,eax
  409d48:	test   rbx,rbx
  409d4b:	je     409d6e <__swc_fn_3464c816_000144_c3e86ca0+0xbe>
  409d4d:	mov    rcx,rbx
  409d50:	mov    dl,BYTE PTR [rcx]
  409d52:	test   dl,dl
  409d54:	je     409d6e <__swc_fn_3464c816_000144_c3e86ca0+0xbe>
  409d56:	cs nop WORD PTR [rax+rax*1+0x0]
  409d60:	add    rcx,0x1
  409d64:	add    rax,0x1
  409d68:	mov    dl,BYTE PTR [rcx]
  409d6a:	test   dl,dl
  409d6c:	jne    409d60 <__swc_fn_3464c816_000144_c3e86ca0+0xb0>
  409d6e:	mov    QWORD PTR [rbx+0xa8],rbx
  409d75:	mov    QWORD PTR [rbx+0xb0],rax
  409d7c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  409d84:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  409d8c:	lea    rcx,[rbx+0xb8]
  409d93:	call   410070 <__swc_fn_3464c816_000116_3f5cfdef>
  409d98:	add    rsp,0xe0
  409d9f:	pop    rbx
  409da0:	ret
	...

0000000000409db0 <__swc_fn_3464c816_000147_e7bfe29e>:
  409db0:	sub    rsp,0x8
  409db4:	mov    rax,QWORD PTR [rcx+0x8]
  409db8:	mov    r8,QWORD PTR [rdx+0x8]
  409dbc:	cmp    rax,r8
  409dbf:	je     409dc8 <__swc_fn_3464c816_000147_e7bfe29e+0x18>
  409dc1:	xor    eax,eax
  409dc3:	add    rsp,0x8
  409dc7:	ret
  409dc8:	test   rax,rax
  409dcb:	jne    409ddc <__swc_fn_3464c816_000147_e7bfe29e+0x2c>
  409dcd:	test   r8,r8
  409dd0:	jne    409ddc <__swc_fn_3464c816_000147_e7bfe29e+0x2c>
  409dd2:	mov    eax,0x1
  409dd7:	add    rsp,0x8
  409ddb:	ret
  409ddc:	mov    rcx,QWORD PTR [rcx]
  409ddf:	mov    rdx,QWORD PTR [rdx]
  409de2:	test   rcx,rcx
  409de5:	sete   r8b
  409de9:	test   rdx,rdx
  409dec:	sete   r9b
  409df0:	or     r8b,r9b
  409df3:	je     409e00 <__swc_fn_3464c816_000147_e7bfe29e+0x50>
  409df5:	cmp    rcx,rdx
  409df8:	sete   al
  409dfb:	add    rsp,0x8
  409dff:	ret
  409e00:	cmp    rcx,rdx
  409e03:	jne    409e0f <__swc_fn_3464c816_000147_e7bfe29e+0x5f>
  409e05:	mov    eax,0x1
  409e0a:	add    rsp,0x8
  409e0e:	ret
  409e0f:	mov    r8,rax
  409e12:	call   40c460 <__swc_fn_3464c816_000106_aba05410>
  409e17:	test   eax,eax
  409e19:	sete   al
  409e1c:	add    rsp,0x8
  409e20:	ret
	...

0000000000409e30 <__swc_fn_3464c816_000150_365b4daf>:
  409e30:	vxorps xmm0,xmm0,xmm0
  409e34:	vmovups XMMWORD PTR [rcx],xmm0
  409e38:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e3d:	vxorps xmm0,xmm0,xmm0
  409e41:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e46:	vmovups xmm0,XMMWORD PTR [rip+0x97aa]        # 4135f8 <__swc_rdata_base_3464c816+0x4e8>
  409e4e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e53:	ret
	...

0000000000409e60 <__swc_fn_3464c816_000153_365b4daf>:
  409e60:	vxorps xmm0,xmm0,xmm0
  409e64:	vmovups XMMWORD PTR [rcx],xmm0
  409e68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e6d:	vxorps xmm0,xmm0,xmm0
  409e71:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e76:	vmovups xmm0,XMMWORD PTR [rip+0x989a]        # 413718 <__swc_rdata_base_3464c816+0x608>
  409e7e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e83:	mov    QWORD PTR [rcx+0x40],0x0
  409e8b:	ret
  409e8c:	add    BYTE PTR [rax],al
	...

0000000000409e90 <__swc_fn_3464c816_000156_9e2052d6>:
  409e90:	push   rbx
  409e91:	sub    rsp,0x70
  409e95:	mov    rax,QWORD PTR [rcx]
  409e98:	mov    rbx,QWORD PTR [rcx+0x8]
  409e9c:	vxorps xmm0,xmm0,xmm0
  409ea0:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  409ea6:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  409eac:	vzeroupper
  409eaf:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  409eb5:	mov    QWORD PTR [rsp+0x48],rdx
  409eba:	mov    QWORD PTR [rsp+0x50],r8
  409ebf:	mov    rcx,rax
  409ec2:	lea    rdx,[rsp+0x8]
  409ec7:	mov    rbx,QWORD PTR [rbx+0x18]
  409ecb:	call   rbx
  409ecd:	add    rsp,0x70
  409ed1:	pop    rbx
  409ed2:	ret
	...

0000000000409ee0 <__swc_fn_3464c816_000159_6861d596>:
  409ee0:	push   rbx
  409ee1:	push   rsi
  409ee2:	push   rdi
  409ee3:	mov    rbx,r8
  409ee6:	mov    rsi,rcx
  409ee9:	mov    rdi,rdx
  409eec:	call   40d170 <__swc_fn_3464c816_000157_3495a3ca>
  409ef1:	vmovups xmm0,XMMWORD PTR [rbx]
  409ef5:	vmovups XMMWORD PTR [rsi],xmm0
  409ef9:	mov    QWORD PTR [rsi+0x18],rdi
  409efd:	pop    rdi
  409efe:	pop    rsi
  409eff:	pop    rbx
  409f00:	ret
	...

0000000000409f10 <__swc_fn_3464c816_000162_61e293bf>:
  409f10:	push   rbx
  409f11:	push   rsi
  409f12:	push   rdi
  409f13:	push   r12
  409f15:	push   r13
  409f17:	sub    rsp,0x50
  409f1b:	mov    rbx,rcx
  409f1e:	mov    rsi,rdx
  409f21:	vmovups xmm0,XMMWORD PTR [rip+0x98ff]        # 413828 <__swc_rdata_base_3464c816+0x718>
  409f29:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409f2f:	vmovups xmm0,XMMWORD PTR [rip+0x9901]        # 413838 <__swc_rdata_base_3464c816+0x728>
  409f37:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409f3d:	vxorps xmm0,xmm0,xmm0
  409f41:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409f47:	mov    rcx,rdx
  409f4a:	call   4098b0 <__swc_fn_3464c816_000138_22d6573c>
  409f4f:	mov    rdi,rax
  409f52:	test   rax,rax
  409f55:	jne    409f86 <__swc_fn_3464c816_000162_61e293bf+0x76>
  409f57:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409f5d:	vmovups XMMWORD PTR [rbx],xmm0
  409f61:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409f67:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409f6c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409f72:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409f77:	mov    rax,rbx
  409f7a:	add    rsp,0x50
  409f7e:	pop    r13
  409f80:	pop    r12
  409f82:	pop    rdi
  409f83:	pop    rsi
  409f84:	pop    rbx
  409f85:	ret
  409f86:	mov    rcx,rdi
  409f89:	call   411b20 <__swc_fn_3464c816_000161_b553c03d>
  409f8e:	mov    r11,rax
  409f91:	test   rax,rax
  409f94:	je     409f9e <__swc_fn_3464c816_000162_61e293bf+0x8e>
  409f96:	mov    al,BYTE PTR [r11+0x24]
  409f9a:	test   al,al
  409f9c:	jne    409fcd <__swc_fn_3464c816_000162_61e293bf+0xbd>
  409f9e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fa4:	vmovups XMMWORD PTR [rbx],xmm0
  409fa8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fae:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fb3:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fb9:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fbe:	mov    rax,rbx
  409fc1:	add    rsp,0x50
  409fc5:	pop    r13
  409fc7:	pop    r12
  409fc9:	pop    rdi
  409fca:	pop    rsi
  409fcb:	pop    rbx
  409fcc:	ret
  409fcd:	sub    rsi,rdi
  409fd0:	mov    eax,0xffffffff
  409fd5:	cmp    rsi,rax
  409fd8:	jbe    40a009 <__swc_fn_3464c816_000162_61e293bf+0xf9>
  409fda:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fe0:	vmovups XMMWORD PTR [rbx],xmm0
  409fe4:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fea:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fef:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409ff5:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409ffa:	mov    rax,rbx
  409ffd:	add    rsp,0x50
  40a001:	pop    r13
  40a003:	pop    r12
  40a005:	pop    rdi
  40a006:	pop    rsi
  40a007:	pop    rbx
  40a008:	ret
  40a009:	mov    rdi,QWORD PTR [r11+0x10]
  40a00d:	mov    eax,DWORD PTR [r11+0x20]
  40a011:	xor    ecx,ecx
  40a013:	test   rax,rax
  40a016:	jbe    40a168 <__swc_fn_3464c816_000162_61e293bf+0x258>
  40a01c:	nop    DWORD PTR [rax+0x0]
  40a020:	mov    edx,ecx
  40a022:	imul   r12,rdx,0x14
  40a026:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40a02b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40a030:	mov    r9d,esi
  40a033:	cmp    r9,rdx
  40a036:	jb     40a15b <__swc_fn_3464c816_000162_61e293bf+0x24b>
  40a03c:	add    rdx,r8
  40a03f:	mov    r8d,esi
  40a042:	cmp    r8,rdx
  40a045:	jae    40a15b <__swc_fn_3464c816_000162_61e293bf+0x24b>
  40a04b:	lea    rsi,[rsp+0x38]
  40a050:	mov    eax,DWORD PTR [rdi+0xc]
  40a053:	mov    DWORD PTR [rsp+0x38],eax
  40a057:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40a05c:	mov    rcx,rdi
  40a05f:	mov    rdx,QWORD PTR [r11+0x18]
  40a063:	mov    r8,rsi
  40a066:	mov    r8d,DWORD PTR [r8]
  40a069:	mov    r9,rax
  40a06c:	lea    r10,[rsp+0x10]
  40a071:	call   40d1c0 <__swc_fn_3464c816_000160_dfca9093>
  40a076:	test   al,al
  40a078:	jne    40a0ab <__swc_fn_3464c816_000162_61e293bf+0x19b>
  40a07a:	vmovups xmm0,XMMWORD PTR [rip+0x97d6]        # 413858 <__swc_rdata_base_3464c816+0x748>
  40a082:	vmovups XMMWORD PTR [rbx],xmm0
  40a086:	vmovups xmm0,XMMWORD PTR [rip+0x97da]        # 413868 <__swc_rdata_base_3464c816+0x758>
  40a08e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a093:	vxorps xmm0,xmm0,xmm0
  40a097:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a09c:	mov    rax,rbx
  40a09f:	add    rsp,0x50
  40a0a3:	pop    r13
  40a0a5:	pop    r12
  40a0a7:	pop    rdi
  40a0a8:	pop    rsi
  40a0a9:	pop    rbx
  40a0aa:	ret
  40a0ab:	lea    r13,[rsp+0x3c]
  40a0b0:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40a0b5:	mov    DWORD PTR [rsp+0x3c],eax
  40a0b9:	test   eax,eax
  40a0bb:	je     40a10c <__swc_fn_3464c816_000162_61e293bf+0x1fc>
  40a0bd:	mov    rcx,rdi
  40a0c0:	mov    rdx,QWORD PTR [r11+0x18]
  40a0c4:	mov    r8d,DWORD PTR [rsi]
  40a0c7:	mov    rax,r13
  40a0ca:	mov    r9d,DWORD PTR [rax]
  40a0cd:	lea    r10,[rsp+0x20]
  40a0d2:	call   40d1c0 <__swc_fn_3464c816_000160_dfca9093>
  40a0d7:	test   al,al
  40a0d9:	jne    40a10c <__swc_fn_3464c816_000162_61e293bf+0x1fc>
  40a0db:	vmovups xmm0,XMMWORD PTR [rip+0x97a5]        # 413888 <__swc_rdata_base_3464c816+0x778>
  40a0e3:	vmovups XMMWORD PTR [rbx],xmm0
  40a0e7:	vmovups xmm0,XMMWORD PTR [rip+0x97a9]        # 413898 <__swc_rdata_base_3464c816+0x788>
  40a0ef:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a0f4:	vxorps xmm0,xmm0,xmm0
  40a0f8:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a0fd:	mov    rax,rbx
  40a100:	add    rsp,0x50
  40a104:	pop    r13
  40a106:	pop    r12
  40a108:	pop    rdi
  40a109:	pop    rsi
  40a10a:	pop    rbx
  40a10b:	ret
  40a10c:	mov    eax,0x1
  40a111:	rex mov BYTE PTR [rsp+0x8],al
  40a116:	cmp    DWORD PTR [r13+0x0],0x0
  40a11b:	je     40a12c <__swc_fn_3464c816_000162_61e293bf+0x21c>
  40a11d:	rex mov BYTE PTR [rsp+0x9],0x1
  40a123:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40a128:	mov    DWORD PTR [rsp+0x30],eax
  40a12c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a132:	vmovups XMMWORD PTR [rbx],xmm0
  40a136:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a13c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a141:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a147:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a14c:	mov    rax,rbx
  40a14f:	add    rsp,0x50
  40a153:	pop    r13
  40a155:	pop    r12
  40a157:	pop    rdi
  40a158:	pop    rsi
  40a159:	pop    rbx
  40a15a:	ret
  40a15b:	add    rcx,0x1
  40a15f:	cmp    rcx,rax
  40a162:	jb     40a020 <__swc_fn_3464c816_000162_61e293bf+0x110>
  40a168:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a16e:	vmovups XMMWORD PTR [rbx],xmm0
  40a172:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a178:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a17d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a183:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a188:	mov    rax,rbx
  40a18b:	add    rsp,0x50
  40a18f:	pop    r13
  40a191:	pop    r12
  40a193:	pop    rdi
  40a194:	pop    rsi
  40a195:	pop    rbx
  40a196:	ret
	...

000000000040a1a0 <__swc_fn_3464c816_000165_56054fe7>:
  40a1a0:	sub    rsp,0x48
  40a1a4:	call   409580 <__swc_fn_3464c816_000123_e4107ade>
  40a1a9:	cmp    rax,0xffffffffffffffff
  40a1ad:	je     40a1b4 <__swc_fn_3464c816_000165_56054fe7+0x14>
  40a1af:	add    rsp,0x48
  40a1b3:	ret
  40a1b4:	lea    rcx,[rip+0x970d]        # 4138c8 <__swc_rdata_base_3464c816+0x7b8>
  40a1bb:	vmovups xmm0,XMMWORD PTR [rip+0x9715]        # 4138d8 <__swc_rdata_base_3464c816+0x7c8>
  40a1c3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a1c9:	vmovups xmm0,XMMWORD PTR [rip+0x9717]        # 4138e8 <__swc_rdata_base_3464c816+0x7d8>
  40a1d1:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a1d7:	vmovups xmm0,XMMWORD PTR [rip+0x9719]        # 4138f8 <__swc_rdata_base_3464c816+0x7e8>
  40a1df:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a1e5:	lea    rdx,[rsp+0x8]
  40a1ea:	mov    QWORD PTR [rsp+0x38],rax
  40a1ef:	call   40c3a0 <__swc_fn_3464c816_000103_0d4cc079>
  40a1f4:	mov    rax,QWORD PTR [rsp+0x38]
  40a1f9:	jmp    40a1af <__swc_fn_3464c816_000165_56054fe7+0xf>
  40a1fb:	add    BYTE PTR [rax],al
  40a1fd:	add    BYTE PTR [rax],al
	...

000000000040a200 <__swc_fn_3464c816_000168_0ad81c51>:
  40a200:	push   rbx
  40a201:	push   rsi
  40a202:	sub    rsp,0x28
  40a206:	mov    rbx,rcx
  40a209:	mov    DWORD PTR [rsp+0x8],0xbf0
  40a211:	mov    ecx,0xbf0
  40a216:	call   40bf90 <__swc_fn_3464c816_000079_633af784>
  40a21b:	mov    rsi,rax
  40a21e:	test   rax,rax
  40a221:	jne    40a22c <__swc_fn_3464c816_000168_0ad81c51+0x2c>
  40a223:	xor    eax,eax
  40a225:	add    rsp,0x28
  40a229:	pop    rsi
  40a22a:	pop    rbx
  40a22b:	ret
  40a22c:	vxorps xmm0,xmm0,xmm0
  40a230:	xor    eax,eax
  40a232:	cs nop WORD PTR [rax+rax*1+0x0]
  40a23c:	nop    DWORD PTR [rax+0x0]
  40a240:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40a245:	add    rax,0x10
  40a249:	cmp    rax,0xbf0
  40a250:	jne    40a240 <__swc_fn_3464c816_000168_0ad81c51+0x40>
  40a252:	lea    rax,[rbx+0x1]
  40a256:	mov    QWORD PTR [rsi+0x9c0],rax
  40a25d:	mov    rcx,rbx
  40a260:	mov    rdx,rsi
  40a263:	call   40d520 <__swc_fn_3464c816_000166_c370e18e>
  40a268:	test   al,al
  40a26a:	jne    40a27d <__swc_fn_3464c816_000168_0ad81c51+0x7d>
  40a26c:	mov    rcx,rsi
  40a26f:	call   40eff0 <__swc_fn_3464c816_000080_207908fe>
  40a274:	xor    eax,eax
  40a276:	add    rsp,0x28
  40a27a:	pop    rsi
  40a27b:	pop    rbx
  40a27c:	ret
  40a27d:	lea    rcx,[rsp+0x18]
  40a282:	call   40f570 <__swc_fn_3464c816_000092_809deff5>
  40a287:	mov    rax,rsi
  40a28a:	add    rsp,0x28
  40a28e:	pop    rsi
  40a28f:	pop    rbx
  40a290:	ret
	...

000000000040a2a0 <__swc_fn_3464c816_000171_8c19aea5>:
  40a2a0:	xor    eax,eax
  40a2a2:	mov    edx,0x1
  40a2a7:	lock cmpxchg QWORD PTR [rcx],rdx
  40a2ac:	test   rax,rax
  40a2af:	jne    40a2b2 <__swc_fn_3464c816_000171_8c19aea5+0x12>
  40a2b1:	ret
  40a2b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2bc:	nop    DWORD PTR [rax+0x0]
  40a2c0:	mov    rax,QWORD PTR [rcx]
  40a2c3:	test   rax,rax
  40a2c6:	je     40a2a0 <__swc_fn_3464c816_000171_8c19aea5>
  40a2c8:	jmp    40a2c0 <__swc_fn_3464c816_000171_8c19aea5+0x20>
  40a2ca:	add    BYTE PTR [rax],al
  40a2cc:	add    BYTE PTR [rax],al
	...

000000000040a2d0 <__swc_fn_3464c816_000174_02e645b4>:
  40a2d0:	push   rsi
  40a2d1:	push   rdi
  40a2d2:	sub    rsp,0x38
  40a2d6:	mov    rsi,rcx
  40a2d9:	call   40d530 <__swc_fn_3464c816_000169_4694b8ad>
  40a2de:	mov    rdi,rax
  40a2e1:	call   40ccc0 <__swc_fn_3464c816_000130_375c7357>
  40a2e6:	mov    r8,rax
  40a2e9:	mov    rcx,rdi
  40a2ec:	call   40a2a0 <__swc_fn_3464c816_000171_8c19aea5>
  40a2f1:	mov    rax,QWORD PTR [rdi+0x8]
  40a2f5:	test   rax,rax
  40a2f8:	je     40a335 <__swc_fn_3464c816_000174_02e645b4+0x65>
  40a2fa:	nop    WORD PTR [rax+rax*1+0x0]
  40a300:	cmp    rax,rsi
  40a303:	je     40a335 <__swc_fn_3464c816_000174_02e645b4+0x65>
  40a305:	mov    r9,QWORD PTR [rax]
  40a308:	cmp    QWORD PTR [rax+0x20],r8
  40a30c:	jne    40a32d <__swc_fn_3464c816_000174_02e645b4+0x5d>
  40a30e:	mov    rcx,rdi
  40a311:	mov    rdx,rax
  40a314:	mov    QWORD PTR [rsp+0x28],r8
  40a319:	mov    QWORD PTR [rsp+0x30],r9
  40a31e:	call   411f40 <__swc_fn_3464c816_000173_e17a224b>
  40a323:	mov    r8,QWORD PTR [rsp+0x28]
  40a328:	mov    r9,QWORD PTR [rsp+0x30]
  40a32d:	mov    rax,r9
  40a330:	test   r9,r9
  40a333:	jne    40a300 <__swc_fn_3464c816_000174_02e645b4+0x30>
  40a335:	xor    eax,eax
  40a337:	mov    QWORD PTR [rdi],rax
  40a33a:	add    rsp,0x38
  40a33e:	pop    rdi
  40a33f:	pop    rsi
  40a340:	ret
	...

000000000040a350 <__swc_fn_3464c816_000177_1ca87929>:
  40a350:	push   rdi
  40a351:	push   rsi
  40a352:	sub    rsp,0xb8
  40a359:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40a35f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40a365:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40a36b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40a371:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40a377:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40a37d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40a383:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40a38c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40a395:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40a39e:	vxorps xmm0,xmm0,xmm0
  40a3a2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a3a8:	mov    edi,0x1
  40a3ad:	lea    rsi,[rsp+0x8]
  40a3b2:	xor    eax,eax
  40a3b4:	call   4070e0 <clock_gettime@plt>
  40a3b9:	vxorpd xmm0,xmm0,xmm0
  40a3bd:	mov    rax,QWORD PTR [rsp+0x8]
  40a3c2:	vcvtsi2sd xmm0,xmm0,rax
  40a3c7:	vxorpd xmm1,xmm1,xmm1
  40a3cb:	mov    rax,QWORD PTR [rsp+0x10]
  40a3d0:	vcvtsi2sd xmm1,xmm1,rax
  40a3d5:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x961e]        # 4139fb <__swc_rdata_base_3464c816+0x8eb>
  40a3dd:	vaddsd xmm0,xmm0,xmm1
  40a3e1:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40a3e7:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40a3ed:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40a3f3:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40a3f9:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40a3ff:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40a405:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40a40b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40a414:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40a41d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40a426:	add    rsp,0xb8
  40a42d:	pop    rsi
  40a42e:	pop    rdi
  40a42f:	ret
	...

000000000040a440 <__swc_fn_3464c816_000001_0e26756e>:
  40a440:	vxorps xmm0,xmm0,xmm0
  40a444:	xor    eax,eax
  40a446:	cs nop WORD PTR [rax+rax*1+0x0]
  40a450:	cs nop WORD PTR [rax+rax*1+0x0]
  40a45a:	nop    WORD PTR [rax+rax*1+0x0]
  40a460:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a465:	add    rax,0x10
  40a469:	cmp    rax,0x2080
  40a470:	jne    40a460 <__swc_fn_3464c816_000001_0e26756e+0x20>
  40a472:	ret
	...

000000000040a480 <__swc_fn_3464c816_000004_3deb8b54>:
  40a480:	push   rsi
  40a481:	push   rdi
  40a482:	push   r12
  40a484:	push   r13
  40a486:	push   r14
  40a488:	mov    rsi,rcx
  40a48b:	mov    edi,r10d
  40a48e:	mov    r12,rcx
  40a491:	mov    r13,r9
  40a494:	mov    ecx,DWORD PTR [rdx+0x28]
  40a497:	shlx   r14d,r8d,ecx
  40a49c:	mov    rcx,rdx
  40a49f:	mov    edx,r8d
  40a4a2:	call   40dec0 <__swc_fn_3464c816_000011_71c91685>
  40a4a7:	mov    rcx,rax
  40a4aa:	mov    eax,DWORD PTR [r12+0x3c]
  40a4af:	xor    edx,edx
  40a4b1:	div    rdi
  40a4b4:	vxorps xmm0,xmm0,xmm0
  40a4b8:	vmovdqu XMMWORD PTR [rsi],xmm0
  40a4bc:	mov    QWORD PTR [r12+0x60],0x0
  40a4c5:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40a4ca:	mov    QWORD PTR [r12+0x10],rcx
  40a4cf:	imul   rax,rdi
  40a4d3:	lea    rdx,[rcx+rax*1]
  40a4d7:	mov    QWORD PTR [r12+0x18],rdx
  40a4dc:	mov    QWORD PTR [r12+0x20],rcx
  40a4e1:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40a4e6:	mov    DWORD PTR [r12+0x28],0x0
  40a4ef:	mov    DWORD PTR [r12+0x68],0x0
  40a4f8:	mov    BYTE PTR [r12+0x39],r13b
  40a4fd:	mov    BYTE PTR [r12+0x3a],r14b
  40a502:	mov    BYTE PTR [r12+0x3b],0x1
  40a508:	mov    DWORD PTR [r12+0x6c],0x0
  40a511:	mov    rcx,r12
  40a514:	mov    edx,edi
  40a516:	call   40de20 <__swc_fn_3464c816_000005_6a556171>
  40a51b:	pop    r14
  40a51d:	pop    r13
  40a51f:	pop    r12
  40a521:	pop    rdi
  40a522:	pop    rsi
  40a523:	ret
	...

000000000040a530 <__swc_fn_3464c816_000007_a7bfb091>:
  40a530:	mov    r8d,0x1
  40a536:	xor    eax,eax
  40a538:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40a53e:	test   eax,eax
  40a540:	jne    40a530 <__swc_fn_3464c816_000007_a7bfb091>
  40a542:	ret
	...

000000000040a550 <__swc_fn_3464c816_000010_0569f799>:
  40a550:	lea    r8,[rcx+0x60]
  40a554:	mov    rax,QWORD PTR [r8]
  40a557:	mov    r9,rax
  40a55a:	nop    WORD PTR [rax+rax*1+0x0]
  40a560:	mov    QWORD PTR [rdx],r9
  40a563:	mov    rax,r9
  40a566:	lock cmpxchg QWORD PTR [r8],rdx
  40a56b:	cmp    rax,r9
  40a56e:	jne    40a5d7 <__swc_fn_3464c816_000010_0569f799+0x87>
  40a570:	mov    eax,DWORD PTR [rcx+0x6c]
  40a573:	test   eax,eax
  40a575:	je     40a5d6 <__swc_fn_3464c816_000010_0569f799+0x86>
  40a577:	lea    rdx,[rcx+0x70]
  40a57b:	mov    r9d,0x1
  40a581:	xor    eax,eax
  40a583:	lock cmpxchg DWORD PTR [rdx],r9d
  40a588:	test   eax,eax
  40a58a:	jne    40a5d6 <__swc_fn_3464c816_000010_0569f799+0x86>
  40a58c:	mov    rax,rcx
  40a58f:	and    rax,0xffffffffffc00000
  40a596:	mov    rax,QWORD PTR [rax+0x8]
  40a59a:	test   rax,rax
  40a59d:	jne    40a5a5 <__swc_fn_3464c816_000010_0569f799+0x55>
  40a59f:	xor    eax,eax
  40a5a1:	xchg   DWORD PTR [rdx],eax
  40a5a3:	jmp    40a5d6 <__swc_fn_3464c816_000010_0569f799+0x86>
  40a5a5:	lea    rdx,[rax+0x2a80]
  40a5ac:	mov    rax,QWORD PTR [rdx]
  40a5af:	mov    r8,rax
  40a5b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5bc:	nop    DWORD PTR [rax+0x0]
  40a5c0:	mov    QWORD PTR [rcx+0x78],r8
  40a5c4:	mov    rax,r8
  40a5c7:	lock cmpxchg QWORD PTR [rdx],rcx
  40a5cc:	cmp    rax,r8
  40a5cf:	je     40a5d6 <__swc_fn_3464c816_000010_0569f799+0x86>
  40a5d1:	mov    r8,rax
  40a5d4:	jmp    40a5c0 <__swc_fn_3464c816_000010_0569f799+0x70>
  40a5d6:	ret
  40a5d7:	mov    r9,rax
  40a5da:	jmp    40a560 <__swc_fn_3464c816_000010_0569f799+0x10>
	...

000000000040a5e0 <__swc_fn_3464c816_000013_7b85dbab>:
  40a5e0:	push   rsi
  40a5e1:	push   rdi
  40a5e2:	push   r12
  40a5e4:	push   r13
  40a5e6:	push   r14
  40a5e8:	push   r15
  40a5ea:	push   rbx
  40a5eb:	sub    rsp,0x30
  40a5ef:	mov    QWORD PTR [rsp+0x18],r8
  40a5f4:	mov    rsi,rcx
  40a5f7:	mov    rdi,rdx
  40a5fa:	mov    rdx,QWORD PTR [rsi+0x40]
  40a5fe:	xchg   ax,ax
  40a600:	mov    rax,rdx
  40a603:	not    rax
  40a606:	and    rax,QWORD PTR [rsi+0x20]
  40a60a:	test   rax,rax
  40a60d:	jne    40a621 <__swc_fn_3464c816_000013_7b85dbab+0x41>
  40a60f:	xor    eax,eax
  40a611:	add    rsp,0x30
  40a615:	pop    rbx
  40a616:	pop    r15
  40a618:	pop    r14
  40a61a:	pop    r13
  40a61c:	pop    r12
  40a61e:	pop    rdi
  40a61f:	pop    rsi
  40a620:	ret
  40a621:	xor    ecx,ecx
  40a623:	tzcnt  rcx,rax
  40a628:	lea    r12,[rsp+0x8]
  40a62d:	mov    DWORD PTR [rsp+0x8],ecx
  40a631:	mov    r13d,0x1
  40a637:	shl    r13,cl
  40a63a:	mov    rcx,rdx
  40a63d:	or     rcx,r13
  40a640:	mov    rax,rdx
  40a643:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40a649:	cmp    rax,rdx
  40a64c:	je     40a653 <__swc_fn_3464c816_000013_7b85dbab+0x73>
  40a64e:	mov    rdx,rax
  40a651:	jmp    40a600 <__swc_fn_3464c816_000013_7b85dbab+0x20>
  40a653:	mov    eax,DWORD PTR [r12]
  40a657:	shl    rax,0x4
  40a65b:	lea    r14,[rsi+rax*8+0x80]
  40a663:	mov    rcx,rsi
  40a666:	mov    rax,r12
  40a669:	mov    edx,DWORD PTR [rax]
  40a66b:	call   40dec0 <__swc_fn_3464c816_000011_71c91685>
  40a670:	mov    r15,rax
  40a673:	mov    rcx,rsi
  40a676:	mov    rdx,r13
  40a679:	call   40e020 <__swc_fn_3464c816_000017_f003fc47>
  40a67e:	test   al,al
  40a680:	je     40a6b8 <__swc_fn_3464c816_000013_7b85dbab+0xd8>
  40a682:	mov    ecx,DWORD PTR [r14+0x3c]
  40a686:	lea    rdx,[rip+0x199cb]        # 424058 <__swc_bss_base_3464c816+0x18>
  40a68d:	mov    r8,QWORD PTR [rip+0x199c4]        # 424058 <__swc_bss_base_3464c816+0x18>
  40a694:	cs nop WORD PTR [rax+rax*1+0x0]
  40a69e:	xchg   ax,ax
  40a6a0:	mov    r9,r8
  40a6a3:	sub    r9,rcx
  40a6a6:	mov    rax,r8
  40a6a9:	lock cmpxchg QWORD PTR [rdx],r9
  40a6ae:	cmp    rax,r8
  40a6b1:	je     40a719 <__swc_fn_3464c816_000013_7b85dbab+0x139>
  40a6b3:	mov    r8,rax
  40a6b6:	jmp    40a6a0 <__swc_fn_3464c816_000013_7b85dbab+0xc0>
  40a6b8:	mov    rcx,rsi
  40a6bb:	mov    rax,r12
  40a6be:	mov    edx,DWORD PTR [rax]
  40a6c0:	call   407450 <__swc_fn_3464c816_000012_be38a1a2>
  40a6c5:	mov    rcx,r15
  40a6c8:	and    rcx,0xffffffffffff0000
  40a6cf:	lea    rcx,[rcx+0x10000]
  40a6d6:	mov    rbx,rax
  40a6d9:	cmp    rax,rcx
  40a6dc:	cmova  rbx,rcx
  40a6e0:	mov    rax,rbx
  40a6e3:	sub    rax,r15
  40a6e6:	mov    rcx,r15
  40a6e9:	mov    rdx,rax
  40a6ec:	call   4072a0 <__swc_fn_3464c816_000003_81215399>
  40a6f1:	test   al,al
  40a6f3:	jne    40a712 <__swc_fn_3464c816_000013_7b85dbab+0x132>
  40a6f5:	mov    rcx,rsi
  40a6f8:	mov    rdx,r13
  40a6fb:	call   407600 <__swc_fn_3464c816_000018_77ece227>
  40a700:	xor    eax,eax
  40a702:	add    rsp,0x30
  40a706:	pop    rbx
  40a707:	pop    r15
  40a709:	pop    r14
  40a70b:	pop    r13
  40a70d:	pop    r12
  40a70f:	pop    rdi
  40a710:	pop    rsi
  40a711:	ret
  40a712:	sub    rbx,r15
  40a715:	mov    DWORD PTR [r14+0x3c],ebx
  40a719:	mov    rcx,r14
  40a71c:	mov    rdx,rsi
  40a71f:	mov    r8d,DWORD PTR [r12]
  40a723:	mov    r9d,edi
  40a726:	mov    rbx,QWORD PTR [rsp+0x18]
  40a72b:	mov    r10d,ebx
  40a72e:	call   40a480 <__swc_fn_3464c816_000004_3deb8b54>
  40a733:	mov    rax,r14
  40a736:	add    rsp,0x30
  40a73a:	pop    rbx
  40a73b:	pop    r15
  40a73d:	pop    r14
  40a73f:	pop    r13
  40a741:	pop    r12
  40a743:	pop    rdi
  40a744:	pop    rsi
  40a745:	ret
	...

000000000040a750 <__swc_fn_3464c816_000016_a0b588d0>:
  40a750:	mov    r8,QWORD PTR [rcx+0x48]
  40a754:	cs nop WORD PTR [rax+rax*1+0x0]
  40a75e:	xchg   ax,ax
  40a760:	mov    r9,r8
  40a763:	or     r9,rdx
  40a766:	mov    rax,r8
  40a769:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40a76f:	cmp    rax,r8
  40a772:	jne    40a775 <__swc_fn_3464c816_000016_a0b588d0+0x25>
  40a774:	ret
  40a775:	mov    r8,rax
  40a778:	jmp    40a760 <__swc_fn_3464c816_000016_a0b588d0+0x10>
  40a77a:	add    BYTE PTR [rax],al
  40a77c:	add    BYTE PTR [rax],al
	...

000000000040a780 <__swc_fn_3464c816_000019_447bb610>:
  40a780:	push   rsi
  40a781:	push   rdi
  40a782:	push   r12
  40a784:	mov    rsi,rcx
  40a787:	xor    edi,edi
  40a789:	lea    r12,[rip+0x198d8]        # 424068 <__swc_bss_base_3464c816+0x28>
  40a790:	mov    eax,DWORD PTR [r12]
  40a794:	xor    ecx,ecx
  40a796:	test   rax,rax
  40a799:	jbe    40a7d4 <__swc_fn_3464c816_000019_447bb610+0x54>
  40a79b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a7a0:	lea    rdx,[rip+0x198c9]        # 424070 <__swc_bss_base_3464c816+0x30>
  40a7a7:	mov    r8d,ecx
  40a7aa:	lea    r8,[r8+r8*2]
  40a7ae:	lea    r8,[rdx+r8*8]
  40a7b2:	mov    rdx,QWORD PTR [r8+0x10]
  40a7b6:	add    rdx,0x400000
  40a7bd:	cmp    rdx,0x40000000
  40a7c4:	ja     40a7cb <__swc_fn_3464c816_000019_447bb610+0x4b>
  40a7c6:	mov    rdi,r8
  40a7c9:	jmp    40a7d4 <__swc_fn_3464c816_000019_447bb610+0x54>
  40a7cb:	add    rcx,0x1
  40a7cf:	cmp    rcx,rax
  40a7d2:	jb     40a7a0 <__swc_fn_3464c816_000019_447bb610+0x20>
  40a7d4:	test   rdi,rdi
  40a7d7:	jne    40a863 <__swc_fn_3464c816_000019_447bb610+0xe3>
  40a7dd:	cmp    DWORD PTR [r12],0x10
  40a7e2:	jae    40a84b <__swc_fn_3464c816_000019_447bb610+0xcb>
  40a7e4:	mov    ecx,0x40400000
  40a7e9:	call   40dde0 <__swc_fn_3464c816_000002_102336c4>
  40a7ee:	test   rax,rax
  40a7f1:	je     40a84b <__swc_fn_3464c816_000019_447bb610+0xcb>
  40a7f3:	lea    rcx,[rip+0x19876]        # 424070 <__swc_bss_base_3464c816+0x30>
  40a7fa:	mov    edx,DWORD PTR [r12]
  40a7fe:	lea    rdx,[rdx+rdx*2]
  40a802:	lea    rdx,[rcx+rdx*8]
  40a806:	mov    QWORD PTR [rdx],rax
  40a809:	lea    rax,[rax+0x3fffff]
  40a810:	and    rax,0xffffffffffc00000
  40a817:	mov    QWORD PTR [rdx+0x8],rax
  40a81b:	mov    QWORD PTR [rdx+0x10],0x0
  40a823:	mov    edx,DWORD PTR [rip+0x1983f]        # 424068 <__swc_bss_base_3464c816+0x28>
  40a829:	nop    DWORD PTR [rax+0x0]
  40a830:	lea    r9d,[rdx+0x1]
  40a834:	mov    rax,rdx
  40a837:	lock cmpxchg DWORD PTR [r12],r9d
  40a83d:	mov    r8d,eax
  40a840:	cmp    eax,edx
  40a842:	je     40a852 <__swc_fn_3464c816_000019_447bb610+0xd2>
  40a844:	mov    rdx,r8
  40a847:	jmp    40a830 <__swc_fn_3464c816_000019_447bb610+0xb0>
  40a849:	jmp    40a852 <__swc_fn_3464c816_000019_447bb610+0xd2>
  40a84b:	xor    eax,eax
  40a84d:	pop    r12
  40a84f:	pop    rdi
  40a850:	pop    rsi
  40a851:	ret
  40a852:	mov    eax,DWORD PTR [rip+0x19810]        # 424068 <__swc_bss_base_3464c816+0x28>
  40a858:	sub    eax,0x1
  40a85b:	lea    rdi,[rax+rax*2]
  40a85f:	lea    rdi,[rcx+rdi*8]
  40a863:	mov    r12,QWORD PTR [rdi+0x8]
  40a867:	add    r12,QWORD PTR [rdi+0x10]
  40a86b:	mov    rcx,r12
  40a86e:	mov    edx,0x3000
  40a873:	call   4072a0 <__swc_fn_3464c816_000003_81215399>
  40a878:	test   al,al
  40a87a:	jne    40a883 <__swc_fn_3464c816_000019_447bb610+0x103>
  40a87c:	xor    eax,eax
  40a87e:	pop    r12
  40a880:	pop    rdi
  40a881:	pop    rsi
  40a882:	ret
  40a883:	vxorps xmm0,xmm0,xmm0
  40a887:	xor    eax,eax
  40a889:	cs nop WORD PTR [rax+rax*1+0x0]
  40a893:	cs nop WORD PTR [rax+rax*1+0x0]
  40a89d:	nop    DWORD PTR [rax]
  40a8a0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40a8a6:	add    rax,0x10
  40a8aa:	cmp    rax,0x3000
  40a8b1:	jne    40a8a0 <__swc_fn_3464c816_000019_447bb610+0x120>
  40a8b3:	mov    DWORD PTR [r12+0x28],esi
  40a8b8:	mov    eax,0x40
  40a8bd:	mov    ecx,esi
  40a8bf:	shr    eax,cl
  40a8c1:	mov    DWORD PTR [r12+0x2c],eax
  40a8c6:	cmp    DWORD PTR [r12+0x2c],0x40
  40a8cc:	jb     40a8d7 <__swc_fn_3464c816_000019_447bb610+0x157>
  40a8ce:	mov    rax,0xffffffffffffffff
  40a8d5:	jmp    40a8e7 <__swc_fn_3464c816_000019_447bb610+0x167>
  40a8d7:	mov    eax,0x1
  40a8dc:	mov    ecx,DWORD PTR [r12+0x2c]
  40a8e1:	shl    rax,cl
  40a8e4:	dec    rax
  40a8e7:	mov    QWORD PTR [r12+0x20],rax
  40a8ec:	mov    DWORD PTR [r12],0x4e540001
  40a8f4:	mov    DWORD PTR [r12+0x4],0x53474d45
  40a8fd:	add    QWORD PTR [rdi+0x10],0x400000
  40a905:	mov    rax,r12
  40a908:	pop    r12
  40a90a:	pop    rdi
  40a90b:	pop    rsi
  40a90c:	ret
  40a90d:	add    BYTE PTR [rax],al
	...

000000000040a910 <__swc_fn_3464c816_000022_53fc00d2>:
  40a910:	mov    eax,0x1
  40a915:	mov    edx,DWORD PTR [rip+0x1974d]        # 424068 <__swc_bss_base_3464c816+0x28>
  40a91b:	cmp    eax,edx
  40a91d:	jae    40a96b <__swc_fn_3464c816_000022_53fc00d2+0x5b>
  40a91f:	nop
  40a920:	lea    r8,[rip+0x19749]        # 424070 <__swc_bss_base_3464c816+0x30>
  40a927:	lea    r9,[rax+rax*2]
  40a92b:	lea    r9,[r8+r9*8]
  40a92f:	mov    r8,rcx
  40a932:	sub    r8,QWORD PTR [r9+0x8]
  40a936:	mov    r9,QWORD PTR [r9+0x10]
  40a93a:	cmp    r8,r9
  40a93d:	jae    40a965 <__swc_fn_3464c816_000022_53fc00d2+0x55>
  40a93f:	mov    rax,rcx
  40a942:	and    rax,0xffffffffffc00000
  40a949:	shr    rcx,0x10
  40a94d:	and    ecx,0x3f
  40a950:	mov    edx,DWORD PTR [rax+0x28]
  40a953:	shrx   ecx,ecx,edx
  40a958:	shl    rcx,0x4
  40a95c:	lea    rax,[rax+rcx*8+0x80]
  40a964:	ret
  40a965:	inc    eax
  40a967:	cmp    eax,edx
  40a969:	jb     40a920 <__swc_fn_3464c816_000022_53fc00d2+0x10>
  40a96b:	xor    eax,eax
  40a96d:	ret
	...

000000000040a970 <__swc_fn_3464c816_000025_e876734d>:
  40a970:	vxorps xmm0,xmm0,xmm0
  40a974:	vmovups XMMWORD PTR [rcx],xmm0
  40a978:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a97d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a982:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a987:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40a98c:	mov    QWORD PTR [rcx+0x50],0x0
  40a994:	ret
	...

000000000040a9a0 <__swc_fn_3464c816_000028_e876734d>:
  40a9a0:	vxorps xmm0,xmm0,xmm0
  40a9a4:	xor    eax,eax
  40a9a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9b0:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9ba:	nop    WORD PTR [rax+rax*1+0x0]
  40a9c0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a9c5:	add    rax,0x10
  40a9c9:	cmp    rax,0x9b0
  40a9d0:	jne    40a9c0 <__swc_fn_3464c816_000028_e876734d+0x20>
  40a9d2:	mov    QWORD PTR [rcx+0x9b0],0x0
  40a9dd:	ret
	...

000000000040a9e0 <__swc_fn_3464c816_000031_3c3e930e>:
  40a9e0:	push   rsi
  40a9e1:	push   rdi
  40a9e2:	sub    rsp,0x8
  40a9e6:	lea    rsi,[rip+0x1761b]        # 422008 <__swc_data_base_3464c816+0x8>
  40a9ed:	mov    rax,QWORD PTR [rsi]
  40a9f0:	mov    ecx,0xffffffff
  40a9f5:	cmp    rax,rcx
  40a9f8:	je     40aa01 <__swc_fn_3464c816_000031_3c3e930e+0x21>
  40a9fa:	add    rsp,0x8
  40a9fe:	pop    rdi
  40a9ff:	pop    rsi
  40aa00:	ret
  40aa01:	mov    rcx,QWORD PTR [rip+0x8678]        # 413080 <__swc_fn_3464c816_000176_2744b483+0x10c0>
  40aa08:	call   409650 <__swc_fn_3464c816_000126_9e9697c7>
  40aa0d:	mov    rcx,rax
  40aa10:	mov    eax,0xffffffff
  40aa15:	lock cmpxchg QWORD PTR [rsi],rcx
  40aa1a:	mov    rdi,rax
  40aa1d:	mov    eax,0xffffffff
  40aa22:	cmp    rdi,rax
  40aa25:	je     40aa36 <__swc_fn_3464c816_000031_3c3e930e+0x56>
  40aa27:	call   40cc10 <__swc_fn_3464c816_000127_f163135d>
  40aa2c:	mov    rax,rdi
  40aa2f:	add    rsp,0x8
  40aa33:	pop    rdi
  40aa34:	pop    rsi
  40aa35:	ret
  40aa36:	mov    rax,rcx
  40aa39:	add    rsp,0x8
  40aa3d:	pop    rdi
  40aa3e:	pop    rsi
  40aa3f:	ret

000000000040aa40 <__swc_fn_3464c816_000034_cf5ba7bd>:
  40aa40:	sub    rsp,0x8
  40aa44:	vxorps xmm0,xmm0,xmm0
  40aa48:	xor    eax,eax
  40aa4a:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa54:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa5e:	xchg   ax,ax
  40aa60:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40aa65:	add    rax,0x10
  40aa69:	cmp    rax,0x2b00
  40aa70:	jne    40aa60 <__swc_fn_3464c816_000034_cf5ba7bd+0x20>
  40aa72:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40aa7c:	xor    al,al
  40aa7e:	mov    rdx,rax
  40aa81:	xor    al,al
  40aa83:	mov    r8,rax
  40aa86:	xor    al,al
  40aa88:	mov    r9,rax
  40aa8b:	xor    al,al
  40aa8d:	mov    r10,rax
  40aa90:	xor    al,al
  40aa92:	mov    r11,rax
  40aa95:	call   40e250 <__swc_fn_3464c816_000035_ab2e8c35>
  40aa9a:	add    rsp,0x8
  40aa9e:	ret
	...

000000000040aaa0 <__swc_fn_3464c816_000037_1e381f55>:
  40aaa0:	push   rsi
  40aaa1:	push   rdi
  40aaa2:	push   r12
  40aaa4:	mov    rsi,r8
  40aaa7:	mov    rdi,rdx
  40aaaa:	mov    rcx,rdx
  40aaad:	call   40dde0 <__swc_fn_3464c816_000002_102336c4>
  40aab2:	mov    r12,rax
  40aab5:	test   rax,rax
  40aab8:	jne    40aac1 <__swc_fn_3464c816_000037_1e381f55+0x21>
  40aaba:	xor    eax,eax
  40aabc:	pop    r12
  40aabe:	pop    rdi
  40aabf:	pop    rsi
  40aac0:	ret
  40aac1:	mov    rcx,r12
  40aac4:	mov    rdx,rsi
  40aac7:	call   4072a0 <__swc_fn_3464c816_000003_81215399>
  40aacc:	test   al,al
  40aace:	jne    40aae2 <__swc_fn_3464c816_000037_1e381f55+0x42>
  40aad0:	mov    rcx,r12
  40aad3:	mov    rdx,rdi
  40aad6:	call   410050 <__swc_fn_3464c816_000113_4e83a03a>
  40aadb:	xor    eax,eax
  40aadd:	pop    r12
  40aadf:	pop    rdi
  40aae0:	pop    rsi
  40aae1:	ret
  40aae2:	mov    rax,r12
  40aae5:	pop    r12
  40aae7:	pop    rdi
  40aae8:	pop    rsi
  40aae9:	ret
	...

000000000040ab00 <__swc_fn_3464c816_000040_8029566e>:
  40ab00:	push   rsi
  40ab01:	push   rdi
  40ab02:	push   r12
  40ab04:	mov    rsi,rcx
  40ab07:	mov    edx,0x9b8
  40ab0c:	call   40e2c0 <__swc_fn_3464c816_000038_292d55e5>
  40ab11:	mov    rdi,rax
  40ab14:	test   rax,rax
  40ab17:	jne    40ab20 <__swc_fn_3464c816_000040_8029566e+0x20>
  40ab19:	xor    eax,eax
  40ab1b:	pop    r12
  40ab1d:	pop    rdi
  40ab1e:	pop    rsi
  40ab1f:	ret
  40ab20:	vxorps xmm0,xmm0,xmm0
  40ab24:	xor    eax,eax
  40ab26:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab30:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab3a:	nop    WORD PTR [rax+rax*1+0x0]
  40ab40:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40ab45:	add    rax,0x10
  40ab49:	cmp    rax,0x9b0
  40ab50:	jne    40ab40 <__swc_fn_3464c816_000040_8029566e+0x40>
  40ab52:	mov    QWORD PTR [rdi+0x9b0],0x0
  40ab5d:	mov    QWORD PTR [rdi],rsi
  40ab60:	call   40ccc0 <__swc_fn_3464c816_000130_375c7357>
  40ab65:	mov    QWORD PTR [rdi+0x18],rax
  40ab69:	lea    r12,[rsi+0x10]
  40ab6d:	mov    rcx,r12
  40ab70:	call   4098a0 <__swc_fn_3464c816_000135_db32cc57>
  40ab75:	mov    rax,QWORD PTR [rsi+0x20]
  40ab79:	mov    QWORD PTR [rdi+0x8],rax
  40ab7d:	mov    rax,QWORD PTR [rsi+0x20]
  40ab81:	test   rax,rax
  40ab84:	je     40ab8a <__swc_fn_3464c816_000040_8029566e+0x8a>
  40ab86:	mov    QWORD PTR [rax+0x10],rdi
  40ab8a:	mov    QWORD PTR [rsi+0x20],rdi
  40ab8e:	mov    rcx,r12
  40ab91:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  40ab96:	mov    rax,rdi
  40ab99:	pop    r12
  40ab9b:	pop    rdi
  40ab9c:	pop    rsi
  40ab9d:	ret
	...

000000000040aba0 <__swc_fn_3464c816_000043_47ff6d9b>:
  40aba0:	mov    rax,QWORD PTR [rdx+0x10]
  40aba4:	test   rax,rax
  40aba7:	je     40abb3 <__swc_fn_3464c816_000043_47ff6d9b+0x13>
  40aba9:	mov    rcx,QWORD PTR [rdx+0x8]
  40abad:	mov    QWORD PTR [rax+0x8],rcx
  40abb1:	jmp    40abbb <__swc_fn_3464c816_000043_47ff6d9b+0x1b>
  40abb3:	mov    rax,QWORD PTR [rdx+0x8]
  40abb7:	mov    QWORD PTR [rcx+0x20],rax
  40abbb:	mov    rax,QWORD PTR [rdx+0x8]
  40abbf:	test   rax,rax
  40abc2:	je     40abcc <__swc_fn_3464c816_000043_47ff6d9b+0x2c>
  40abc4:	mov    rcx,QWORD PTR [rdx+0x10]
  40abc8:	mov    QWORD PTR [rax+0x10],rcx
  40abcc:	vxorps xmm0,xmm0,xmm0
  40abd0:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40abd5:	ret
	...

000000000040abe0 <__swc_fn_3464c816_000046_b28a6ee7>:
  40abe0:	sub    rsp,0x8
  40abe4:	mov    r9,r8
  40abe7:	mov    r10,rdx
  40abea:	call   40e370 <__swc_fn_3464c816_000044_fe6bbfdb>
  40abef:	mov    eax,0x1
  40abf4:	xchg   DWORD PTR [r9+0x6c],eax
  40abf8:	mov    rax,QWORD PTR [r9+0x60]
  40abfc:	test   rax,rax
  40abff:	je     40ac43 <__swc_fn_3464c816_000046_b28a6ee7+0x63>
  40ac01:	xor    eax,eax
  40ac03:	xchg   DWORD PTR [r9+0x6c],eax
  40ac07:	movzx  eax,BYTE PTR [r9+0x39]
  40ac0c:	lea    rax,[rax+rax*4]
  40ac10:	lea    rax,[r10+rax*8+0x28]
  40ac15:	mov    QWORD PTR [r9+0x50],0x0
  40ac1d:	mov    rcx,QWORD PTR [rax+0x8]
  40ac21:	mov    QWORD PTR [r9+0x48],rcx
  40ac25:	mov    rcx,QWORD PTR [rax+0x8]
  40ac29:	test   rcx,rcx
  40ac2c:	je     40ac34 <__swc_fn_3464c816_000046_b28a6ee7+0x54>
  40ac2e:	mov    QWORD PTR [rcx+0x50],r9
  40ac32:	jmp    40ac38 <__swc_fn_3464c816_000046_b28a6ee7+0x58>
  40ac34:	mov    QWORD PTR [rax+0x10],r9
  40ac38:	mov    QWORD PTR [rax+0x8],r9
  40ac3c:	xor    eax,eax
  40ac3e:	add    rsp,0x8
  40ac42:	ret
  40ac43:	movzx  eax,BYTE PTR [r9+0x39]
  40ac48:	lea    rax,[rax+rax*4]
  40ac4c:	lea    rax,[r10+rax*8+0x28]
  40ac51:	mov    QWORD PTR [r9+0x50],0x0
  40ac59:	mov    rcx,QWORD PTR [rax+0x18]
  40ac5d:	mov    QWORD PTR [r9+0x48],rcx
  40ac61:	mov    rcx,QWORD PTR [rax+0x18]
  40ac65:	test   rcx,rcx
  40ac68:	je     40ac6e <__swc_fn_3464c816_000046_b28a6ee7+0x8e>
  40ac6a:	mov    QWORD PTR [rcx+0x50],r9
  40ac6e:	mov    QWORD PTR [rax+0x18],r9
  40ac72:	mov    eax,0x1
  40ac77:	add    rsp,0x8
  40ac7b:	ret
  40ac7c:	add    BYTE PTR [rax],al
	...

000000000040ac80 <__swc_fn_3464c816_000049_f6a485a2>:
  40ac80:	push   r12
  40ac82:	push   r13
  40ac84:	push   rdi
  40ac85:	push   rsi
  40ac86:	push   r14
  40ac88:	push   r15
  40ac8a:	sub    rsp,0x178
  40ac91:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40ac9a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40aca3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40acac:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40acb5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40acbe:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40acc7:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40acd0:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40acd9:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40ace2:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40aceb:	mov    r12,rcx
  40acee:	lea    rax,[rip+0x1950b]        # 424200 <__swc_bss_base_3464c816+0x1c0>
  40acf5:	mov    rcx,QWORD PTR [rax]
  40acf8:	mov    r13,rcx
  40acfb:	test   rcx,rcx
  40acfe:	jne    40ad0e <__swc_fn_3464c816_000049_f6a485a2+0x8e>
  40ad00:	mov    r13d,0x1dcd6500
  40ad06:	mov    ecx,0x1dcd6500
  40ad0b:	xchg   QWORD PTR [rax],rcx
  40ad0e:	lea    rax,[rip+0x172eb]        # 422000 <__swc_data_base_3464c816>
  40ad15:	mov    rax,QWORD PTR [rax]
  40ad18:	cmp    rax,0xffffffffffffffff
  40ad1c:	je     40ad2b <__swc_fn_3464c816_000049_f6a485a2+0xab>
  40ad1e:	mov    eax,eax
  40ad20:	mov    edi,eax
  40ad22:	xor    eax,eax
  40ad24:	call   407000 <pthread_getspecific@plt>
  40ad29:	jmp    40ad2d <__swc_fn_3464c816_000049_f6a485a2+0xad>
  40ad2b:	xor    eax,eax
  40ad2d:	test   rax,rax
  40ad30:	jne    40ad3f <__swc_fn_3464c816_000049_f6a485a2+0xbf>
  40ad32:	call   40a9e0 <__swc_fn_3464c816_000031_3c3e930e>
  40ad37:	mov    rcx,rax
  40ad3a:	call   4103a0 <__swc_fn_3464c816_000128_8d8a7dd2>
  40ad3f:	test   rax,rax
  40ad42:	je     40ad54 <__swc_fn_3464c816_000049_f6a485a2+0xd4>
  40ad44:	cmp    QWORD PTR [rax],r12
  40ad47:	jne    40ad54 <__swc_fn_3464c816_000049_f6a485a2+0xd4>
  40ad49:	cmp    DWORD PTR [rax+0x20],0x0
  40ad4d:	jne    40ad54 <__swc_fn_3464c816_000049_f6a485a2+0xd4>
  40ad4f:	mov    rsi,rax
  40ad52:	jmp    40ad56 <__swc_fn_3464c816_000049_f6a485a2+0xd6>
  40ad54:	xor    esi,esi
  40ad56:	lea    rdi,[r12+0x2a88]
  40ad5e:	mov    r14,QWORD PTR [rdi]
  40ad61:	test   r14,r14
  40ad64:	jne    40adb3 <__swc_fn_3464c816_000049_f6a485a2+0x133>
  40ad66:	lea    rax,[rip+0x192eb]        # 424058 <__swc_bss_base_3464c816+0x18>
  40ad6d:	mov    rax,QWORD PTR [rax]
  40ad70:	test   rax,rax
  40ad73:	setne  al
  40ad76:	jne    40ad9a <__swc_fn_3464c816_000049_f6a485a2+0x11a>
  40ad78:	mov    rax,QWORD PTR [r12+0x2a70]
  40ad80:	test   rax,rax
  40ad83:	setne  al
  40ad86:	jne    40ad9a <__swc_fn_3464c816_000049_f6a485a2+0x11a>
  40ad88:	test   rsi,rsi
  40ad8b:	setne  al
  40ad8e:	je     40ad9a <__swc_fn_3464c816_000049_f6a485a2+0x11a>
  40ad90:	cmp    DWORD PTR [rsi+0x730],0x0
  40ad97:	setne  al
  40ad9a:	test   al,al
  40ad9c:	je     40adae <__swc_fn_3464c816_000049_f6a485a2+0x12e>
  40ad9e:	call   410450 <__swc_fn_3464c816_000131_91db8856>
  40ada3:	lea    rcx,[rax+r13*1]
  40ada7:	xor    eax,eax
  40ada9:	lock cmpxchg QWORD PTR [rdi],rcx
  40adae:	jmp    40aeb3 <__swc_fn_3464c816_000049_f6a485a2+0x233>
  40adb3:	call   410450 <__swc_fn_3464c816_000131_91db8856>
  40adb8:	mov    r15,rax
  40adbb:	cmp    rax,r14
  40adbe:	jb     40adcf <__swc_fn_3464c816_000049_f6a485a2+0x14f>
  40adc0:	xor    ecx,ecx
  40adc2:	mov    rax,r14
  40adc5:	lock cmpxchg QWORD PTR [rdi],rcx
  40adca:	cmp    rax,r14
  40adcd:	je     40add4 <__swc_fn_3464c816_000049_f6a485a2+0x154>
  40adcf:	jmp    40aeb3 <__swc_fn_3464c816_000049_f6a485a2+0x233>
  40add4:	test   rsi,rsi
  40add7:	je     40adf2 <__swc_fn_3464c816_000049_f6a485a2+0x172>
  40add9:	cmp    r15,r13
  40addc:	jb     40adf2 <__swc_fn_3464c816_000049_f6a485a2+0x172>
  40adde:	mov    rax,r15
  40ade1:	sub    rax,r13
  40ade4:	mov    rcx,r12
  40ade7:	mov    rdx,rsi
  40adea:	mov    r8,rax
  40aded:	call   40e7b0 <__swc_fn_3464c816_000059_ee6a254c>
  40adf2:	lea    rsi,[r12+0x10]
  40adf7:	mov    rcx,rsi
  40adfa:	call   4098a0 <__swc_fn_3464c816_000135_db32cc57>
  40adff:	mov    rax,QWORD PTR [r12+0x18]
  40ae04:	mov    rdi,rax
  40ae07:	test   rdi,rdi
  40ae0a:	je     40ae34 <__swc_fn_3464c816_000049_f6a485a2+0x1b4>
  40ae0c:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae16:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae20:	mov    rcx,rdi
  40ae23:	call   407470 <__swc_fn_3464c816_000015_96cb1311>
  40ae28:	mov    rax,QWORD PTR [rdi+0x10]
  40ae2c:	mov    rdi,rax
  40ae2f:	test   rax,rax
  40ae32:	jne    40ae20 <__swc_fn_3464c816_000049_f6a485a2+0x1a0>
  40ae34:	mov    rcx,rsi
  40ae37:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  40ae3c:	mov    rcx,r12
  40ae3f:	call   4098a0 <__swc_fn_3464c816_000135_db32cc57>
  40ae44:	xor    esi,esi
  40ae46:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae50:	mov    rax,QWORD PTR [r12+0x2a70]
  40ae58:	cmp    rsi,rax
  40ae5b:	jae    40aeab <__swc_fn_3464c816_000049_f6a485a2+0x22b>
  40ae5d:	lea    rax,[rsi+rsi*4]
  40ae61:	lea    rax,[r12+rax*8+0x268]
  40ae69:	mov    r8,QWORD PTR [rax]
  40ae6c:	mov    r9,QWORD PTR [rax+0x8]
  40ae70:	mov    r10,QWORD PTR [rax+0x10]
  40ae74:	mov    rax,QWORD PTR [rax+0x20]
  40ae78:	cmp    rax,r15
  40ae7b:	jae    40ae88 <__swc_fn_3464c816_000049_f6a485a2+0x208>
  40ae7d:	mov    rcx,r15
  40ae80:	sub    rcx,rax
  40ae83:	cmp    rcx,r13
  40ae86:	jae    40ae8d <__swc_fn_3464c816_000049_f6a485a2+0x20d>
  40ae88:	inc    rsi
  40ae8b:	jmp    40ae50 <__swc_fn_3464c816_000049_f6a485a2+0x1d0>
  40ae8d:	mov    rcx,r12
  40ae90:	mov    rdx,rsi
  40ae93:	call   40e760 <__swc_fn_3464c816_000056_87dc216f>
  40ae98:	mov    rcx,r12
  40ae9b:	mov    rdx,r8
  40ae9e:	mov    r8,r9
  40aea1:	mov    r9,r10
  40aea4:	call   407750 <__swc_fn_3464c816_000039_9ae4348f>
  40aea9:	jmp    40ae50 <__swc_fn_3464c816_000049_f6a485a2+0x1d0>
  40aeab:	mov    rcx,r12
  40aeae:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  40aeb3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40aebc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40aec5:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40aece:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40aed7:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40aee0:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40aee9:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40aef2:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40aefb:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40af04:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40af0d:	add    rsp,0x178
  40af14:	pop    r15
  40af16:	pop    r14
  40af18:	pop    rsi
  40af19:	pop    rdi
  40af1a:	pop    r13
  40af1c:	pop    r12
  40af1e:	ret
	...

000000000040af20 <__swc_fn_3464c816_000052_92b016ae>:
  40af20:	lea    rax,[rdx-0x58]
  40af24:	ret
	...

000000000040af30 <__swc_fn_3464c816_000055_ddf32775>:
  40af30:	push   rsi
  40af31:	push   rdi
  40af32:	push   r12
  40af34:	push   r13
  40af36:	sub    rsp,0x68
  40af3a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40af40:	mov    rsi,r9
  40af43:	mov    rdi,rcx
  40af46:	mov    r12,rdx
  40af49:	mov    r13,r8
  40af4c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40af54:	jne    40af63 <__swc_fn_3464c816_000055_ddf32775+0x33>
  40af56:	xor    eax,eax
  40af58:	add    rsp,0x68
  40af5c:	pop    r13
  40af5e:	pop    r12
  40af60:	pop    rdi
  40af61:	pop    rsi
  40af62:	ret
  40af63:	mov    rcx,rdi
  40af66:	call   4098a0 <__swc_fn_3464c816_000135_db32cc57>
  40af6b:	movabs rax,0x7fffffffffffffff
  40af75:	cmp    r12,rax
  40af78:	mov    rax,0xffffffffffffffff
  40af7f:	lea    rcx,[r12+r12*1]
  40af83:	cmovbe rax,rcx
  40af87:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40af8e:	mov    rdx,rcx
  40af91:	sub    rax,r12
  40af94:	inc    rax
  40af97:	xor    r8d,r8d
  40af9a:	test   rcx,rcx
  40af9d:	jbe    40afc8 <__swc_fn_3464c816_000055_ddf32775+0x98>
  40af9f:	nop
  40afa0:	lea    r9,[r8+r8*4]
  40afa4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40afac:	sub    r9,r12
  40afaf:	cmp    r9,rax
  40afb2:	jae    40afbf <__swc_fn_3464c816_000055_ddf32775+0x8f>
  40afb4:	mov    rdx,r8
  40afb7:	mov    rax,r9
  40afba:	test   r9,r9
  40afbd:	je     40afc8 <__swc_fn_3464c816_000055_ddf32775+0x98>
  40afbf:	add    r8,0x1
  40afc3:	cmp    r8,rcx
  40afc6:	jb     40afa0 <__swc_fn_3464c816_000055_ddf32775+0x70>
  40afc8:	mov    rax,QWORD PTR [rdi+0x2a70]
  40afcf:	cmp    rdx,rax
  40afd2:	jne    40afef <__swc_fn_3464c816_000055_ddf32775+0xbf>
  40afd4:	mov    rcx,rdi
  40afd7:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  40afdc:	xor    eax,eax
  40afde:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40afe4:	add    rsp,0x68
  40afe8:	pop    r13
  40afea:	pop    r12
  40afec:	pop    rdi
  40afed:	pop    rsi
  40afee:	ret
  40afef:	lea    rax,[rdx+rdx*4]
  40aff3:	lea    rax,[rdi+rax*8+0x268]
  40affb:	vmovups xmm6,XMMWORD PTR [rax]
  40afff:	mov    r8,QWORD PTR [rax+0x10]
  40b003:	mov    rcx,rdi
  40b006:	call   40e760 <__swc_fn_3464c816_000056_87dc216f>
  40b00b:	vpshufd xmm0,xmm6,0xee
  40b010:	vmovsd QWORD PTR [r13+0x0],xmm0
  40b016:	mov    QWORD PTR [rsi],r8
  40b019:	mov    rcx,rdi
  40b01c:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  40b021:	vmovq  rax,xmm6
  40b026:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b02c:	add    rsp,0x68
  40b030:	pop    r13
  40b032:	pop    r12
  40b034:	pop    rdi
  40b035:	pop    rsi
  40b036:	ret
	...

000000000040b040 <__swc_fn_3464c816_000058_01964a17>:
  40b040:	push   r12
  40b042:	push   r13
  40b044:	push   r14
  40b046:	push   r15
  40b048:	push   rdi
  40b049:	push   rsi
  40b04a:	sub    rsp,0x148
  40b051:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40b05a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40b063:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40b06c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40b075:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40b07e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40b087:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40b090:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40b099:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40b0a2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40b0ab:	mov    r12,r9
  40b0ae:	mov    r13,rcx
  40b0b1:	mov    r14,rdx
  40b0b4:	mov    r15,r8
  40b0b7:	test   rdx,rdx
  40b0ba:	jne    40b0ce <__swc_fn_3464c816_000058_01964a17+0x8e>
  40b0bc:	add    rsp,0x148
  40b0c3:	pop    rsi
  40b0c4:	pop    rdi
  40b0c5:	pop    r15
  40b0c7:	pop    r14
  40b0c9:	pop    r13
  40b0cb:	pop    r12
  40b0cd:	ret
  40b0ce:	cmp    r12,0x200000
  40b0d5:	ja     40b167 <__swc_fn_3464c816_000058_01964a17+0x127>
  40b0db:	lea    rax,[rip+0x16f1e]        # 422000 <__swc_data_base_3464c816>
  40b0e2:	mov    rax,QWORD PTR [rax]
  40b0e5:	cmp    rax,0xffffffffffffffff
  40b0e9:	je     40b0f8 <__swc_fn_3464c816_000058_01964a17+0xb8>
  40b0eb:	mov    eax,eax
  40b0ed:	mov    edi,eax
  40b0ef:	xor    eax,eax
  40b0f1:	call   407000 <pthread_getspecific@plt>
  40b0f6:	jmp    40b0fa <__swc_fn_3464c816_000058_01964a17+0xba>
  40b0f8:	xor    eax,eax
  40b0fa:	test   rax,rax
  40b0fd:	je     40b104 <__swc_fn_3464c816_000058_01964a17+0xc4>
  40b0ff:	mov    rsi,rax
  40b102:	jmp    40b114 <__swc_fn_3464c816_000058_01964a17+0xd4>
  40b104:	call   40a9e0 <__swc_fn_3464c816_000031_3c3e930e>
  40b109:	mov    rcx,rax
  40b10c:	call   4103a0 <__swc_fn_3464c816_000128_8d8a7dd2>
  40b111:	mov    rsi,rax
  40b114:	test   rsi,rsi
  40b117:	je     40b167 <__swc_fn_3464c816_000058_01964a17+0x127>
  40b119:	cmp    QWORD PTR [rsi],r13
  40b11c:	jne    40b167 <__swc_fn_3464c816_000058_01964a17+0x127>
  40b11e:	cmp    DWORD PTR [rsi+0x20],0x0
  40b122:	jne    40b167 <__swc_fn_3464c816_000058_01964a17+0x127>
  40b124:	cmp    DWORD PTR [rsi+0x730],0x10
  40b12b:	jae    40b167 <__swc_fn_3464c816_000058_01964a17+0x127>
  40b12d:	mov    eax,DWORD PTR [rsi+0x730]
  40b133:	lea    rdi,[rax+rax*4]
  40b137:	lea    rdi,[rsi+rdi*8+0x738]
  40b13f:	mov    QWORD PTR [rdi],r14
  40b142:	mov    QWORD PTR [rdi+0x8],r15
  40b146:	mov    QWORD PTR [rdi+0x10],r12
  40b14a:	mov    QWORD PTR [rdi+0x18],0x0
  40b152:	call   410450 <__swc_fn_3464c816_000131_91db8856>
  40b157:	mov    QWORD PTR [rdi+0x20],rax
  40b15b:	add    DWORD PTR [rsi+0x730],0x1
  40b162:	jmp    40b2c6 <__swc_fn_3464c816_000058_01964a17+0x286>
  40b167:	mov    rcx,r13
  40b16a:	call   407e90 <__swc_fn_3464c816_000057_01c75a1d>
  40b16f:	mov    rsi,rax
  40b172:	cmp    r12,rax
  40b175:	jbe    40b1aa <__swc_fn_3464c816_000058_01964a17+0x16a>
  40b177:	cmp    r12,0x10000000
  40b17e:	seta   al
  40b181:	ja     40b190 <__swc_fn_3464c816_000058_01964a17+0x150>
  40b183:	mov    rax,QWORD PTR [r13+0x2a70]
  40b18a:	test   rax,rax
  40b18d:	setne  al
  40b190:	test   al,al
  40b192:	je     40b1aa <__swc_fn_3464c816_000058_01964a17+0x16a>
  40b194:	mov    rcx,r13
  40b197:	mov    rdx,r14
  40b19a:	mov    r8,r15
  40b19d:	mov    r9,r12
  40b1a0:	call   407750 <__swc_fn_3464c816_000039_9ae4348f>
  40b1a5:	jmp    40b2c6 <__swc_fn_3464c816_000058_01964a17+0x286>
  40b1aa:	call   410450 <__swc_fn_3464c816_000131_91db8856>
  40b1af:	mov    rdi,rax
  40b1b2:	mov    rcx,r13
  40b1b5:	call   4098a0 <__swc_fn_3464c816_000135_db32cc57>
  40b1ba:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b1c2:	je     40b27a <__swc_fn_3464c816_000058_01964a17+0x23a>
  40b1c8:	nop    DWORD PTR [rax+rax*1+0x0]
  40b1d0:	cmp    QWORD PTR [r13+0x2a70],0x100
  40b1db:	jae    40b1f0 <__swc_fn_3464c816_000058_01964a17+0x1b0>
  40b1dd:	mov    rax,QWORD PTR [r13+0x2a68]
  40b1e4:	add    rax,r12
  40b1e7:	cmp    rax,rsi
  40b1ea:	jbe    40b27a <__swc_fn_3464c816_000058_01964a17+0x23a>
  40b1f0:	xor    eax,eax
  40b1f2:	mov    rcx,QWORD PTR [r13+0x2a70]
  40b1f9:	mov    edx,0x1
  40b1fe:	cmp    rcx,0x1
  40b202:	jbe    40b239 <__swc_fn_3464c816_000058_01964a17+0x1f9>
  40b204:	cs nop WORD PTR [rax+rax*1+0x0]
  40b20e:	xchg   ax,ax
  40b210:	lea    r8,[rdx+rdx*4]
  40b214:	lea    r8,[r13+r8*8+0x268]
  40b21c:	lea    r9,[rax+rax*4]
  40b220:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40b228:	cmp    QWORD PTR [r8+0x18],r9
  40b22c:	cmovb  rax,rdx
  40b230:	add    rdx,0x1
  40b234:	cmp    rdx,rcx
  40b237:	jb     40b210 <__swc_fn_3464c816_000058_01964a17+0x1d0>
  40b239:	lea    rcx,[rax+rax*4]
  40b23d:	lea    rcx,[r13+rcx*8+0x268]
  40b245:	mov    r8,QWORD PTR [rcx]
  40b248:	mov    r9,QWORD PTR [rcx+0x8]
  40b24c:	mov    r10,QWORD PTR [rcx+0x10]
  40b250:	mov    rcx,r13
  40b253:	mov    rdx,rax
  40b256:	call   40e760 <__swc_fn_3464c816_000056_87dc216f>
  40b25b:	mov    rcx,r13
  40b25e:	mov    rdx,r8
  40b261:	mov    r8,r9
  40b264:	mov    r9,r10
  40b267:	call   407750 <__swc_fn_3464c816_000039_9ae4348f>
  40b26c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b274:	jne    40b1d0 <__swc_fn_3464c816_000058_01964a17+0x190>
  40b27a:	add    QWORD PTR [r13+0x2a78],0x1
  40b282:	mov    rax,QWORD PTR [r13+0x2a70]
  40b289:	lea    rax,[rax+rax*4]
  40b28d:	lea    rax,[r13+rax*8+0x268]
  40b295:	mov    QWORD PTR [rax],r14
  40b298:	mov    QWORD PTR [rax+0x8],r15
  40b29c:	mov    QWORD PTR [rax+0x10],r12
  40b2a0:	mov    rcx,QWORD PTR [r13+0x2a78]
  40b2a7:	mov    QWORD PTR [rax+0x18],rcx
  40b2ab:	mov    QWORD PTR [rax+0x20],rdi
  40b2af:	add    QWORD PTR [r13+0x2a68],r12
  40b2b6:	add    QWORD PTR [r13+0x2a70],0x1
  40b2be:	mov    rcx,r13
  40b2c1:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  40b2c6:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40b2cf:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40b2d8:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40b2e1:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40b2ea:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40b2f3:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40b2fc:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40b305:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40b30e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40b317:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40b320:	add    rsp,0x148
  40b327:	pop    rsi
  40b328:	pop    rdi
  40b329:	pop    r15
  40b32b:	pop    r14
  40b32d:	pop    r13
  40b32f:	pop    r12
  40b331:	ret
	...

000000000040b340 <__swc_fn_3464c816_000061_73a9baa2>:
  40b340:	push   rbx
  40b341:	push   r12
  40b343:	push   r13
  40b345:	push   r14
  40b347:	push   r15
  40b349:	push   rdi
  40b34a:	push   rsi
  40b34b:	sub    rsp,0xf0
  40b352:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40b358:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40b35e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40b364:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40b36a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40b373:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40b37c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40b385:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40b38e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40b397:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40b3a0:	mov    eax,r8d
  40b3a3:	mov    rbx,rcx
  40b3a6:	mov    r12,rdx
  40b3a9:	mov    QWORD PTR [rsp+0x18],rdx
  40b3ae:	mov    ecx,DWORD PTR [r12+0x58]
  40b3b3:	mov    r13d,ecx
  40b3b6:	cmp    ecx,0x10
  40b3b9:	mov    ecx,0x10
  40b3be:	cmovb  r13d,ecx
  40b3c2:	test   r13d,r13d
  40b3c5:	mov    rcx,r13
  40b3c8:	mov    edx,0x8
  40b3cd:	cmove  ecx,edx
  40b3d0:	dec    rcx
  40b3d3:	mov    rdx,0xffffffffffffffff
  40b3da:	sub    rdx,rcx
  40b3dd:	xor    r14d,r14d
  40b3e0:	mov    r8,rcx
  40b3e3:	not    r8
  40b3e6:	lea    rcx,[rcx+0x58]
  40b3ea:	and    rcx,r8
  40b3ed:	cmp    rdx,0x58
  40b3f1:	cmovae r14,rcx
  40b3f5:	cmp    eax,0xffffffff
  40b3f8:	jne    40b401 <__swc_fn_3464c816_000061_73a9baa2+0xc1>
  40b3fa:	mov    r15,QWORD PTR [r12+0x48]
  40b3ff:	jmp    40b433 <__swc_fn_3464c816_000061_73a9baa2+0xf3>
  40b401:	test   eax,eax
  40b403:	jne    40b40c <__swc_fn_3464c816_000061_73a9baa2+0xcc>
  40b405:	mov    eax,0x8
  40b40a:	jmp    40b430 <__swc_fn_3464c816_000061_73a9baa2+0xf0>
  40b40c:	cmp    eax,0x8
  40b40f:	ja     40b417 <__swc_fn_3464c816_000061_73a9baa2+0xd7>
  40b411:	shl    rax,0x4
  40b415:	jmp    40b430 <__swc_fn_3464c816_000061_73a9baa2+0xf0>
  40b417:	lea    eax,[rax-0x9]
  40b41a:	mov    ecx,eax
  40b41c:	shr    ecx,0x2
  40b41f:	and    eax,0x3
  40b422:	lea    ecx,[rcx+0x7]
  40b425:	lea    ecx,[rcx-0x2]
  40b428:	lea    eax,[rax+0x5]
  40b42b:	shlx   rax,rax,rcx
  40b430:	mov    r15,rax
  40b433:	lea    rax,[r14+r13*1]
  40b437:	mov    rcx,0xffffffffffffffff
  40b43e:	sub    rcx,rax
  40b441:	cmp    r15,rcx
  40b444:	jbe    40b454 <__swc_fn_3464c816_000061_73a9baa2+0x114>
  40b446:	mov    QWORD PTR [r12+0x40],0x0
  40b44f:	jmp    40b826 <__swc_fn_3464c816_000061_73a9baa2+0x4e6>
  40b454:	mov    QWORD PTR [rsp+0x20],r13
  40b459:	lea    r13,[rsp+0x8]
  40b45e:	add    rax,r15
  40b461:	mov    ecx,0x1000
  40b466:	test   ecx,ecx
  40b468:	mov    edx,0x8
  40b46d:	cmove  ecx,edx
  40b470:	dec    rcx
  40b473:	mov    rdx,0xffffffffffffffff
  40b47a:	sub    rdx,rcx
  40b47d:	cmp    rax,rdx
  40b480:	jbe    40b48c <__swc_fn_3464c816_000061_73a9baa2+0x14c>
  40b482:	mov    QWORD PTR [r13+0x0],0x0
  40b48a:	jmp    40b499 <__swc_fn_3464c816_000061_73a9baa2+0x159>
  40b48c:	add    rax,rcx
  40b48f:	andn   rax,rcx,rax
  40b494:	mov    QWORD PTR [rsp+0x8],rax
  40b499:	cmp    QWORD PTR [r13+0x0],0x0
  40b49e:	jne    40b4ae <__swc_fn_3464c816_000061_73a9baa2+0x16e>
  40b4a0:	mov    QWORD PTR [r12+0x40],0x0
  40b4a9:	jmp    40b826 <__swc_fn_3464c816_000061_73a9baa2+0x4e6>
  40b4ae:	mov    QWORD PTR [rsp+0x30],r15
  40b4b3:	xor    r15d,r15d
  40b4b6:	mov    QWORD PTR [rsp+0x38],0x0
  40b4bf:	lea    r12,[rsp+0x10]
  40b4c4:	mov    QWORD PTR [rsp+0x28],r14
  40b4c9:	mov    r14,QWORD PTR [rsp+0x8]
  40b4ce:	mov    QWORD PTR [rsp+0x10],r14
  40b4d3:	cmp    r14,0x10000
  40b4da:	ja     40b4e1 <__swc_fn_3464c816_000061_73a9baa2+0x1a1>
  40b4dc:	mov    rax,r14
  40b4df:	jmp    40b532 <__swc_fn_3464c816_000061_73a9baa2+0x1f2>
  40b4e1:	xor    eax,eax
  40b4e3:	lea    rcx,[r14-0x1]
  40b4e7:	lzcnt  rax,rcx
  40b4ec:	mov    ecx,0x3f
  40b4f1:	sub    rcx,rax
  40b4f4:	mov    eax,0x1
  40b4f9:	lea    rcx,[rcx-0x3]
  40b4fd:	shl    rax,cl
  40b500:	mov    rcx,rax
  40b503:	cmp    rax,0x1000
  40b50a:	mov    eax,0x1000
  40b50f:	cmovb  rcx,rax
  40b513:	mov    rdx,0xffffffffffffffff
  40b51a:	sub    rdx,rcx
  40b51d:	mov    rax,r14
  40b520:	lea    r8,[r14+rcx*1-0x1]
  40b525:	neg    rcx
  40b528:	and    r8,rcx
  40b52b:	cmp    r14,rdx
  40b52e:	cmovbe rax,r8
  40b532:	mov    QWORD PTR [rsp+0x8],rax
  40b537:	lea    rax,[rip+0x16ac2]        # 422000 <__swc_data_base_3464c816>
  40b53e:	mov    rax,QWORD PTR [rax]
  40b541:	cmp    rax,0xffffffffffffffff
  40b545:	je     40b554 <__swc_fn_3464c816_000061_73a9baa2+0x214>
  40b547:	mov    eax,eax
  40b549:	mov    edi,eax
  40b54b:	xor    eax,eax
  40b54d:	call   407000 <pthread_getspecific@plt>
  40b552:	jmp    40b556 <__swc_fn_3464c816_000061_73a9baa2+0x216>
  40b554:	xor    eax,eax
  40b556:	test   rax,rax
  40b559:	jne    40b568 <__swc_fn_3464c816_000061_73a9baa2+0x228>
  40b55b:	call   40a9e0 <__swc_fn_3464c816_000031_3c3e930e>
  40b560:	mov    rcx,rax
  40b563:	call   4103a0 <__swc_fn_3464c816_000128_8d8a7dd2>
  40b568:	test   rax,rax
  40b56b:	je     40b65c <__swc_fn_3464c816_000061_73a9baa2+0x31c>
  40b571:	cmp    QWORD PTR [rax],rbx
  40b574:	jne    40b65c <__swc_fn_3464c816_000061_73a9baa2+0x31c>
  40b57a:	cmp    DWORD PTR [rax+0x20],0x0
  40b57e:	jne    40b65c <__swc_fn_3464c816_000061_73a9baa2+0x31c>
  40b584:	mov    rcx,QWORD PTR [rsp+0x8]
  40b589:	movabs rdx,0x7fffffffffffffff
  40b593:	cmp    rcx,rdx
  40b596:	mov    rdx,0xffffffffffffffff
  40b59d:	lea    r8,[rcx+rcx*1]
  40b5a1:	cmovbe rdx,r8
  40b5a5:	mov    r8d,DWORD PTR [rax+0x730]
  40b5ac:	mov    r9d,r8d
  40b5af:	sub    rdx,rcx
  40b5b2:	inc    rdx
  40b5b5:	xor    r10d,r10d
  40b5b8:	test   r8,r8
  40b5bb:	jbe    40b5eb <__swc_fn_3464c816_000061_73a9baa2+0x2ab>
  40b5bd:	nop    DWORD PTR [rax]
  40b5c0:	mov    r11d,r10d
  40b5c3:	lea    r11,[r11+r11*4]
  40b5c7:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40b5cf:	sub    r11,rcx
  40b5d2:	cmp    r11,rdx
  40b5d5:	jae    40b5e2 <__swc_fn_3464c816_000061_73a9baa2+0x2a2>
  40b5d7:	mov    r9d,r10d
  40b5da:	mov    rdx,r11
  40b5dd:	test   r11,r11
  40b5e0:	je     40b5eb <__swc_fn_3464c816_000061_73a9baa2+0x2ab>
  40b5e2:	add    r10,0x1
  40b5e6:	cmp    r10,r8
  40b5e9:	jb     40b5c0 <__swc_fn_3464c816_000061_73a9baa2+0x280>
  40b5eb:	mov    ecx,DWORD PTR [rax+0x730]
  40b5f1:	cmp    r9d,ecx
  40b5f4:	jne    40b5fa <__swc_fn_3464c816_000061_73a9baa2+0x2ba>
  40b5f6:	xor    eax,eax
  40b5f8:	jmp    40b659 <__swc_fn_3464c816_000061_73a9baa2+0x319>
  40b5fa:	lea    rcx,[r9+r9*4]
  40b5fe:	lea    rcx,[rax+rcx*8+0x738]
  40b606:	vmovups xmm0,XMMWORD PTR [rcx]
  40b60a:	mov    rdx,QWORD PTR [rcx+0x10]
  40b60e:	sub    DWORD PTR [rax+0x730],0x1
  40b615:	mov    r8d,DWORD PTR [rax+0x730]
  40b61c:	lea    r8,[r8+r8*4]
  40b620:	lea    r8,[rax+r8*8+0x738]
  40b628:	vmovups xmm1,XMMWORD PTR [r8]
  40b62d:	vmovups XMMWORD PTR [rcx],xmm1
  40b631:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40b637:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40b63c:	mov    rax,QWORD PTR [r8+0x20]
  40b640:	mov    QWORD PTR [rcx+0x20],rax
  40b644:	vpshufd xmm1,xmm0,0xee
  40b649:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40b64f:	mov    QWORD PTR [rsp+0x10],rdx
  40b654:	vmovq  rax,xmm0
  40b659:	mov    r15,rax
  40b65c:	test   r15,r15
  40b65f:	jne    40b677 <__swc_fn_3464c816_000061_73a9baa2+0x337>
  40b661:	mov    rcx,rbx
  40b664:	mov    rdx,QWORD PTR [rsp+0x8]
  40b669:	mov    r8,r13
  40b66c:	mov    r9,r12
  40b66f:	call   40af30 <__swc_fn_3464c816_000055_ddf32775>
  40b674:	mov    r15,rax
  40b677:	test   r15,r15
  40b67a:	je     40b6bb <__swc_fn_3464c816_000061_73a9baa2+0x37b>
  40b67c:	cmp    QWORD PTR [r12],r14
  40b680:	jae    40b6bb <__swc_fn_3464c816_000061_73a9baa2+0x37b>
  40b682:	mov    rax,r15
  40b685:	add    rax,QWORD PTR [r12]
  40b689:	mov    rdx,r14
  40b68c:	sub    rdx,QWORD PTR [r12]
  40b690:	mov    rcx,rax
  40b693:	call   4072a0 <__swc_fn_3464c816_000003_81215399>
  40b698:	test   al,al
  40b69a:	je     40b6a3 <__swc_fn_3464c816_000061_73a9baa2+0x363>
  40b69c:	mov    QWORD PTR [rsp+0x10],r14
  40b6a1:	jmp    40b6bb <__swc_fn_3464c816_000061_73a9baa2+0x37b>
  40b6a3:	mov    rcx,rbx
  40b6a6:	mov    rdx,r15
  40b6a9:	mov    r8,QWORD PTR [rsp+0x8]
  40b6ae:	mov    r9,QWORD PTR [rsp+0x10]
  40b6b3:	call   40b040 <__swc_fn_3464c816_000058_01964a17>
  40b6b8:	xor    r15d,r15d
  40b6bb:	test   r15,r15
  40b6be:	jne    40b73a <__swc_fn_3464c816_000061_73a9baa2+0x3fa>
  40b6c0:	cmp    r14,0x10000
  40b6c7:	ja     40b6ce <__swc_fn_3464c816_000061_73a9baa2+0x38e>
  40b6c9:	mov    rax,r14
  40b6cc:	jmp    40b71f <__swc_fn_3464c816_000061_73a9baa2+0x3df>
  40b6ce:	xor    eax,eax
  40b6d0:	lea    rcx,[r14-0x1]
  40b6d4:	lzcnt  rax,rcx
  40b6d9:	mov    ecx,0x3f
  40b6de:	sub    rcx,rax
  40b6e1:	mov    eax,0x1
  40b6e6:	lea    rcx,[rcx-0x3]
  40b6ea:	shl    rax,cl
  40b6ed:	mov    rcx,rax
  40b6f0:	cmp    rax,0x1000
  40b6f7:	mov    eax,0x1000
  40b6fc:	cmovb  rcx,rax
  40b700:	mov    rdx,0xffffffffffffffff
  40b707:	sub    rdx,rcx
  40b70a:	mov    rax,r14
  40b70d:	lea    r8,[r14+rcx*1-0x1]
  40b712:	neg    rcx
  40b715:	and    r8,rcx
  40b718:	cmp    r14,rdx
  40b71b:	cmovbe rax,r8
  40b71f:	mov    QWORD PTR [rsp+0x8],rax
  40b724:	mov    QWORD PTR [rsp+0x10],r14
  40b729:	mov    rcx,rbx
  40b72c:	mov    rdx,rax
  40b72f:	mov    r8,r14
  40b732:	call   40aaa0 <__swc_fn_3464c816_000037_1e381f55>
  40b737:	mov    r15,rax
  40b73a:	test   r15,r15
  40b73d:	jne    40b74b <__swc_fn_3464c816_000061_73a9baa2+0x40b>
  40b73f:	mov    r13,QWORD PTR [rsp+0x20]
  40b744:	mov    rsi,QWORD PTR [rsp+0x38]
  40b749:	jmp    40b787 <__swc_fn_3464c816_000061_73a9baa2+0x447>
  40b74b:	mov    rax,r15
  40b74e:	add    rax,QWORD PTR [rsp+0x28]
  40b753:	mov    r13,QWORD PTR [rsp+0x20]
  40b758:	test   r13d,r13d
  40b75b:	mov    rcx,r13
  40b75e:	mov    edx,0x8
  40b763:	cmove  ecx,edx
  40b766:	dec    rcx
  40b769:	mov    rdx,0xffffffffffffffff
  40b770:	sub    rdx,rcx
  40b773:	cmp    rax,rdx
  40b776:	jbe    40b77c <__swc_fn_3464c816_000061_73a9baa2+0x43c>
  40b778:	xor    eax,eax
  40b77a:	jmp    40b784 <__swc_fn_3464c816_000061_73a9baa2+0x444>
  40b77c:	add    rax,rcx
  40b77f:	andn   rax,rcx,rax
  40b784:	mov    rsi,rax
  40b787:	mov    rax,QWORD PTR [rsp+0x8]
  40b78c:	test   r15,r15
  40b78f:	je     40b798 <__swc_fn_3464c816_000061_73a9baa2+0x458>
  40b791:	mov    rdi,QWORD PTR [rsp+0x18]
  40b796:	jmp    40b7aa <__swc_fn_3464c816_000061_73a9baa2+0x46a>
  40b798:	mov    rdi,QWORD PTR [rsp+0x18]
  40b79d:	mov    QWORD PTR [rdi+0x40],0x0
  40b7a5:	jmp    40b826 <__swc_fn_3464c816_000061_73a9baa2+0x4e6>
  40b7aa:	lea    rdx,[rsi-0x58]
  40b7ae:	mov    QWORD PTR [rsi-0x58],r15
  40b7b2:	mov    QWORD PTR [rsi-0x50],rax
  40b7b6:	mov    rax,QWORD PTR [rsp+0x10]
  40b7bb:	mov    QWORD PTR [rsi-0x48],rax
  40b7bf:	mov    QWORD PTR [rsi-0x40],rsi
  40b7c3:	mov    rax,QWORD PTR [rdi+0x48]
  40b7c7:	mov    QWORD PTR [rsi-0x38],rax
  40b7cb:	mov    rax,QWORD PTR [rsp+0x30]
  40b7d0:	mov    QWORD PTR [rsi-0x30],rax
  40b7d4:	mov    DWORD PTR [rsi-0x10],r13d
  40b7d8:	mov    QWORD PTR [rsi-0x28],0x0
  40b7e0:	mov    QWORD PTR [rsi-0x20],0x0
  40b7e8:	add    r15,QWORD PTR [r12]
  40b7ec:	sub    r15,rsi
  40b7ef:	mov    QWORD PTR [rsi-0x30],r15
  40b7f3:	mov    rcx,QWORD PTR [rbx+0x250]
  40b7fa:	nop    WORD PTR [rax+rax*1+0x0]
  40b800:	lea    r8,[rcx+r15*1]
  40b804:	mov    rax,rcx
  40b807:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40b810:	cmp    rax,rcx
  40b813:	je     40b81a <__swc_fn_3464c816_000061_73a9baa2+0x4da>
  40b815:	mov    rcx,rax
  40b818:	jmp    40b800 <__swc_fn_3464c816_000061_73a9baa2+0x4c0>
  40b81a:	mov    rcx,rbx
  40b81d:	call   40e6d0 <__swc_fn_3464c816_000053_9aa81fa7>
  40b822:	mov    QWORD PTR [rdi+0x40],rsi
  40b826:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40b82c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40b832:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40b838:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40b83e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40b847:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40b850:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40b859:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40b862:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40b86b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40b874:	add    rsp,0xf0
  40b87b:	pop    rsi
  40b87c:	pop    rdi
  40b87d:	pop    r15
  40b87f:	pop    r14
  40b881:	pop    r13
  40b883:	pop    r12
  40b885:	pop    rbx
  40b886:	ret
	...

000000000040b890 <__swc_fn_3464c816_000064_20100e91>:
  40b890:	push   rbx
  40b891:	push   r12
  40b893:	push   rdi
  40b894:	push   rsi
  40b895:	sub    rsp,0xb8
  40b89c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40b8a2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40b8a8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40b8ae:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40b8b4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40b8ba:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40b8c0:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40b8c6:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40b8cf:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40b8d8:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40b8e1:	mov    rbx,rdx
  40b8e4:	mov    r12,rcx
  40b8e7:	cmp    DWORD PTR [rbx+0x58],0x0
  40b8eb:	je     40b905 <__swc_fn_3464c816_000064_20100e91+0x75>
  40b8ed:	mov    eax,DWORD PTR [rbx+0x58]
  40b8f0:	sub    eax,0x1
  40b8f3:	test   DWORD PTR [rbx+0x58],eax
  40b8f6:	je     40b905 <__swc_fn_3464c816_000064_20100e91+0x75>
  40b8f8:	mov    QWORD PTR [rbx+0x40],0x0
  40b900:	jmp    40bb17 <__swc_fn_3464c816_000064_20100e91+0x287>
  40b905:	cmp    QWORD PTR [rbx+0x48],0x0
  40b90a:	jne    40b919 <__swc_fn_3464c816_000064_20100e91+0x89>
  40b90c:	mov    QWORD PTR [rbx+0x40],0x0
  40b914:	jmp    40bb17 <__swc_fn_3464c816_000064_20100e91+0x287>
  40b919:	lea    rax,[rsp+0x8]
  40b91e:	mov    rcx,QWORD PTR [rbx+0x48]
  40b922:	cmp    rcx,0x8
  40b926:	ja     40b930 <__swc_fn_3464c816_000064_20100e91+0xa0>
  40b928:	mov    DWORD PTR [rax],0x0
  40b92e:	jmp    40b98b <__swc_fn_3464c816_000064_20100e91+0xfb>
  40b930:	cmp    rcx,0x80
  40b937:	ja     40b947 <__swc_fn_3464c816_000064_20100e91+0xb7>
  40b939:	lea    rcx,[rcx+0xf]
  40b93d:	shr    rcx,0x4
  40b941:	mov    DWORD PTR [rsp+0x8],ecx
  40b945:	jmp    40b98b <__swc_fn_3464c816_000064_20100e91+0xfb>
  40b947:	cmp    rcx,0x10000
  40b94e:	jbe    40b958 <__swc_fn_3464c816_000064_20100e91+0xc8>
  40b950:	mov    DWORD PTR [rax],0xffffffff
  40b956:	jmp    40b98b <__swc_fn_3464c816_000064_20100e91+0xfb>
  40b958:	dec    rcx
  40b95b:	xor    edx,edx
  40b95d:	lzcnt  rdx,rcx
  40b962:	mov    r8d,0x3f
  40b968:	sub    r8d,edx
  40b96b:	lea    edx,[r8-0x2]
  40b96f:	shrx   rcx,rcx,rdx
  40b974:	and    ecx,0x3
  40b977:	lea    edx,[r8-0x7]
  40b97b:	lea    edx,[rdx*4+0x0]
  40b982:	lea    edx,[rdx+0x9]
  40b985:	add    edx,ecx
  40b987:	mov    DWORD PTR [rsp+0x8],edx
  40b98b:	cmp    DWORD PTR [rax],0x0
  40b98e:	jne    40b99e <__swc_fn_3464c816_000064_20100e91+0x10e>
  40b990:	cmp    DWORD PTR [rbx+0x58],0x8
  40b994:	jbe    40b99e <__swc_fn_3464c816_000064_20100e91+0x10e>
  40b996:	mov    DWORD PTR [rsp+0x8],0x1
  40b99e:	cmp    DWORD PTR [rbx+0x58],0x10
  40b9a2:	jbe    40ba21 <__swc_fn_3464c816_000064_20100e91+0x191>
  40b9a8:	cmp    DWORD PTR [rbx+0x58],0x40
  40b9ac:	ja     40ba21 <__swc_fn_3464c816_000064_20100e91+0x191>
  40b9ae:	cmp    DWORD PTR [rax],0xffffffff
  40b9b1:	je     40ba21 <__swc_fn_3464c816_000064_20100e91+0x191>
  40b9b3:	mov    ecx,DWORD PTR [rsp+0x8]
  40b9b7:	mov    edx,DWORD PTR [rbx+0x58]
  40b9ba:	dec    rdx
  40b9bd:	cmp    ecx,0x2d
  40b9c0:	jae    40ba18 <__swc_fn_3464c816_000064_20100e91+0x188>
  40b9c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40b9cc:	nop    DWORD PTR [rax+0x0]
  40b9d0:	mov    r8d,ecx
  40b9d3:	test   ecx,ecx
  40b9d5:	jne    40b9df <__swc_fn_3464c816_000064_20100e91+0x14f>
  40b9d7:	mov    r8d,0x8
  40b9dd:	jmp    40ba0b <__swc_fn_3464c816_000064_20100e91+0x17b>
  40b9df:	cmp    r8d,0x8
  40b9e3:	ja     40b9eb <__swc_fn_3464c816_000064_20100e91+0x15b>
  40b9e5:	shl    r8,0x4
  40b9e9:	jmp    40ba0b <__swc_fn_3464c816_000064_20100e91+0x17b>
  40b9eb:	lea    r8d,[r8-0x9]
  40b9ef:	mov    r9d,r8d
  40b9f2:	shr    r9d,0x2
  40b9f6:	and    r8d,0x3
  40b9fa:	lea    r9d,[r9+0x7]
  40b9fe:	lea    r9d,[r9-0x2]
  40ba02:	lea    r8d,[r8+0x5]
  40ba06:	shlx   r8,r8,r9
  40ba0b:	test   r8,rdx
  40ba0e:	je     40ba1d <__swc_fn_3464c816_000064_20100e91+0x18d>
  40ba10:	add    ecx,0x1
  40ba13:	cmp    ecx,0x2d
  40ba16:	jb     40b9d0 <__swc_fn_3464c816_000064_20100e91+0x140>
  40ba18:	mov    ecx,0xffffffff
  40ba1d:	mov    DWORD PTR [rsp+0x8],ecx
  40ba21:	mov    ecx,DWORD PTR [rsp+0x8]
  40ba25:	cmp    ecx,0xffffffff
  40ba28:	je     40ba30 <__swc_fn_3464c816_000064_20100e91+0x1a0>
  40ba2a:	cmp    DWORD PTR [rbx+0x58],0x40
  40ba2e:	jbe    40ba43 <__swc_fn_3464c816_000064_20100e91+0x1b3>
  40ba30:	mov    rcx,r12
  40ba33:	mov    rdx,rbx
  40ba36:	mov    r8d,DWORD PTR [rax]
  40ba39:	call   40b340 <__swc_fn_3464c816_000061_73a9baa2>
  40ba3e:	jmp    40bb17 <__swc_fn_3464c816_000064_20100e91+0x287>
  40ba43:	lea    rax,[rip+0x165b6]        # 422000 <__swc_data_base_3464c816>
  40ba4a:	mov    rax,QWORD PTR [rax]
  40ba4d:	cmp    rax,0xffffffffffffffff
  40ba51:	je     40ba60 <__swc_fn_3464c816_000064_20100e91+0x1d0>
  40ba53:	mov    eax,eax
  40ba55:	mov    edi,eax
  40ba57:	xor    eax,eax
  40ba59:	call   407000 <pthread_getspecific@plt>
  40ba5e:	jmp    40ba62 <__swc_fn_3464c816_000064_20100e91+0x1d2>
  40ba60:	xor    eax,eax
  40ba62:	test   rax,rax
  40ba65:	jne    40ba74 <__swc_fn_3464c816_000064_20100e91+0x1e4>
  40ba67:	call   40a9e0 <__swc_fn_3464c816_000031_3c3e930e>
  40ba6c:	mov    rcx,rax
  40ba6f:	call   4103a0 <__swc_fn_3464c816_000128_8d8a7dd2>
  40ba74:	test   rax,rax
  40ba77:	je     40ba84 <__swc_fn_3464c816_000064_20100e91+0x1f4>
  40ba79:	cmp    QWORD PTR [rax],r12
  40ba7c:	jne    40ba84 <__swc_fn_3464c816_000064_20100e91+0x1f4>
  40ba7e:	cmp    DWORD PTR [rax+0x20],0x0
  40ba82:	je     40ba8f <__swc_fn_3464c816_000064_20100e91+0x1ff>
  40ba84:	mov    rcx,r12
  40ba87:	mov    rdx,rax
  40ba8a:	call   40e310 <__swc_fn_3464c816_000041_41400651>
  40ba8f:	test   rax,rax
  40ba92:	jne    40ba9e <__swc_fn_3464c816_000064_20100e91+0x20e>
  40ba94:	mov    QWORD PTR [rbx+0x40],0x0
  40ba9c:	jmp    40bb17 <__swc_fn_3464c816_000064_20100e91+0x287>
  40ba9e:	lea    r8,[rsp+0xc]
  40baa3:	mov    ecx,DWORD PTR [rsp+0x8]
  40baa7:	mov    DWORD PTR [rsp+0xc],ecx
  40baab:	mov    ecx,DWORD PTR [r8]
  40baae:	lea    rcx,[rcx+rcx*4]
  40bab2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40bab7:	test   rcx,rcx
  40baba:	je     40baf3 <__swc_fn_3464c816_000064_20100e91+0x263>
  40babc:	mov    rdx,QWORD PTR [rcx]
  40babf:	test   rdx,rdx
  40bac2:	je     40bad0 <__swc_fn_3464c816_000064_20100e91+0x240>
  40bac4:	mov    r9,QWORD PTR [rdx]
  40bac7:	mov    QWORD PTR [rcx],r9
  40baca:	add    DWORD PTR [rcx+0x28],0x1
  40bace:	jmp    40baee <__swc_fn_3464c816_000064_20100e91+0x25e>
  40bad0:	mov    rdx,QWORD PTR [rcx+0x18]
  40bad4:	cmp    QWORD PTR [rcx+0x20],rdx
  40bad8:	jae    40baec <__swc_fn_3464c816_000064_20100e91+0x25c>
  40bada:	mov    rdx,QWORD PTR [rcx+0x20]
  40bade:	mov    r9d,DWORD PTR [rcx+0x2c]
  40bae2:	add    QWORD PTR [rcx+0x20],r9
  40bae6:	add    DWORD PTR [rcx+0x28],0x1
  40baea:	jmp    40baee <__swc_fn_3464c816_000064_20100e91+0x25e>
  40baec:	xor    edx,edx
  40baee:	test   rdx,rdx
  40baf1:	jne    40bb04 <__swc_fn_3464c816_000064_20100e91+0x274>
  40baf3:	mov    rcx,r12
  40baf6:	mov    rdx,rax
  40baf9:	mov    r8d,DWORD PTR [r8]
  40bafc:	call   40e480 <__swc_fn_3464c816_000050_5e919db9>
  40bb01:	mov    rdx,rax
  40bb04:	test   rdx,rdx
  40bb07:	jne    40bb13 <__swc_fn_3464c816_000064_20100e91+0x283>
  40bb09:	mov    QWORD PTR [rbx+0x40],0x0
  40bb11:	jmp    40bb17 <__swc_fn_3464c816_000064_20100e91+0x287>
  40bb13:	mov    QWORD PTR [rbx+0x40],rdx
  40bb17:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40bb1d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40bb23:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40bb29:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40bb2f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40bb35:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40bb3b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40bb41:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40bb4a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40bb53:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40bb5c:	add    rsp,0xb8
  40bb63:	pop    rsi
  40bb64:	pop    rdi
  40bb65:	pop    r12
  40bb67:	pop    rbx
  40bb68:	ret
  40bb69:	add    BYTE PTR [rax],al
  40bb6b:	add    BYTE PTR [rax],al
  40bb6d:	add    BYTE PTR [rax],al
	...

000000000040bb70 <__swc_fn_3464c816_000067_0145abfc>:
  40bb70:	ret
	...

000000000040bb80 <__swc_fn_3464c816_000070_357c932c>:
  40bb80:	push   r12
  40bb82:	push   r13
  40bb84:	push   r14
  40bb86:	push   rdi
  40bb87:	push   rsi
  40bb88:	sub    rsp,0x1a0
  40bb8f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40bb98:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40bba1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40bbaa:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40bbb3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40bbbc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40bbc5:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40bbce:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40bbd7:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40bbe0:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40bbe9:	mov    r12,rdx
  40bbec:	mov    r13,rcx
  40bbef:	mov    rax,QWORD PTR [r12+0x48]
  40bbf4:	mov    ecx,DWORD PTR [r12+0x58]
  40bbf9:	lea    rdx,[rax-0x1]
  40bbfd:	cmp    rdx,0x10000
  40bc04:	jae    40bcfe <__swc_fn_3464c816_000070_357c932c+0x17e>
  40bc0a:	cmp    rax,0x8
  40bc0e:	ja     40bc15 <__swc_fn_3464c816_000070_357c932c+0x95>
  40bc10:	xor    r14d,r14d
  40bc13:	jmp    40bc67 <__swc_fn_3464c816_000070_357c932c+0xe7>
  40bc15:	cmp    rax,0x80
  40bc1c:	ja     40bc28 <__swc_fn_3464c816_000070_357c932c+0xa8>
  40bc1e:	lea    r14,[rax+0xf]
  40bc22:	shr    r14,0x4
  40bc26:	jmp    40bc67 <__swc_fn_3464c816_000070_357c932c+0xe7>
  40bc28:	cmp    rax,0x10000
  40bc2f:	jbe    40bc39 <__swc_fn_3464c816_000070_357c932c+0xb9>
  40bc31:	mov    r14d,0xffffffff
  40bc37:	jmp    40bc67 <__swc_fn_3464c816_000070_357c932c+0xe7>
  40bc39:	xor    eax,eax
  40bc3b:	lzcnt  rax,rdx
  40bc40:	mov    r8d,0x3f
  40bc46:	sub    r8d,eax
  40bc49:	lea    eax,[r8-0x2]
  40bc4d:	shrx   rax,rdx,rax
  40bc52:	and    eax,0x3
  40bc55:	lea    edx,[r8-0x7]
  40bc59:	lea    edx,[rdx*4+0x0]
  40bc60:	lea    edx,[rdx+0x9]
  40bc63:	lea    r14d,[rdx+rax*1]
  40bc67:	cmp    ecx,0x8
  40bc6a:	jbe    40bc83 <__swc_fn_3464c816_000070_357c932c+0x103>
  40bc6c:	cmp    ecx,0x10
  40bc6f:	jne    40bcfe <__swc_fn_3464c816_000070_357c932c+0x17e>
  40bc75:	test   r14d,r14d
  40bc78:	mov    eax,0x1
  40bc7d:	cmove  r14d,eax
  40bc81:	jmp    40bc8a <__swc_fn_3464c816_000070_357c932c+0x10a>
  40bc83:	lea    eax,[rcx-0x1]
  40bc86:	test   eax,ecx
  40bc88:	jne    40bcfe <__swc_fn_3464c816_000070_357c932c+0x17e>
  40bc8a:	lea    rax,[rip+0x1636f]        # 422000 <__swc_data_base_3464c816>
  40bc91:	mov    rax,QWORD PTR [rax]
  40bc94:	cmp    rax,0xffffffffffffffff
  40bc98:	je     40bca7 <__swc_fn_3464c816_000070_357c932c+0x127>
  40bc9a:	mov    eax,eax
  40bc9c:	mov    edi,eax
  40bc9e:	xor    eax,eax
  40bca0:	call   407000 <pthread_getspecific@plt>
  40bca5:	jmp    40bca9 <__swc_fn_3464c816_000070_357c932c+0x129>
  40bca7:	xor    eax,eax
  40bca9:	test   rax,rax
  40bcac:	je     40bcfe <__swc_fn_3464c816_000070_357c932c+0x17e>
  40bcae:	cmp    QWORD PTR [rax],r13
  40bcb1:	jne    40bcfe <__swc_fn_3464c816_000070_357c932c+0x17e>
  40bcb3:	lea    rcx,[r14+r14*4]
  40bcb7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40bcbc:	test   rax,rax
  40bcbf:	je     40bcfe <__swc_fn_3464c816_000070_357c932c+0x17e>
  40bcc1:	mov    rcx,QWORD PTR [rax]
  40bcc4:	test   rcx,rcx
  40bcc7:	je     40bcd5 <__swc_fn_3464c816_000070_357c932c+0x155>
  40bcc9:	mov    rdx,QWORD PTR [rcx]
  40bccc:	mov    QWORD PTR [rax],rdx
  40bccf:	add    DWORD PTR [rax+0x28],0x1
  40bcd3:	jmp    40bcf2 <__swc_fn_3464c816_000070_357c932c+0x172>
  40bcd5:	mov    rcx,QWORD PTR [rax+0x18]
  40bcd9:	cmp    QWORD PTR [rax+0x20],rcx
  40bcdd:	jae    40bcf0 <__swc_fn_3464c816_000070_357c932c+0x170>
  40bcdf:	mov    rcx,QWORD PTR [rax+0x20]
  40bce3:	mov    edx,DWORD PTR [rax+0x2c]
  40bce6:	add    QWORD PTR [rax+0x20],rdx
  40bcea:	add    DWORD PTR [rax+0x28],0x1
  40bcee:	jmp    40bcf2 <__swc_fn_3464c816_000070_357c932c+0x172>
  40bcf0:	xor    ecx,ecx
  40bcf2:	test   rcx,rcx
  40bcf5:	je     40bcfe <__swc_fn_3464c816_000070_357c932c+0x17e>
  40bcf7:	mov    QWORD PTR [r12+0x40],rcx
  40bcfc:	jmp    40bd09 <__swc_fn_3464c816_000070_357c932c+0x189>
  40bcfe:	mov    rcx,r13
  40bd01:	mov    rdx,r12
  40bd04:	call   40ef00 <__swc_fn_3464c816_000071_1e1e3bf8>
  40bd09:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40bd12:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40bd1b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40bd24:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40bd2d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40bd36:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40bd3f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40bd48:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40bd51:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40bd5a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40bd63:	add    rsp,0x1a0
  40bd6a:	pop    rsi
  40bd6b:	pop    rdi
  40bd6c:	pop    r14
  40bd6e:	pop    r13
  40bd70:	pop    r12
  40bd72:	ret
	...

000000000040bd80 <__swc_fn_3464c816_000073_cdd57f51>:
  40bd80:	push   r12
  40bd82:	push   r13
  40bd84:	push   r14
  40bd86:	push   r15
  40bd88:	push   rdi
  40bd89:	push   rsi
  40bd8a:	sub    rsp,0x188
  40bd91:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40bd9a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40bda3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40bdac:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40bdb5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40bdbe:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40bdc7:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40bdd0:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40bdd9:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40bde2:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40bdeb:	mov    r12,rdx
  40bdee:	mov    r13,rcx
  40bdf1:	mov    r14,QWORD PTR [r12+0x40]
  40bdf6:	lea    rax,[rip+0x18273]        # 424070 <__swc_bss_base_3464c816+0x30>
  40bdfd:	mov    rcx,r14
  40be00:	sub    rcx,QWORD PTR [rax+0x8]
  40be04:	mov    rax,QWORD PTR [rip+0x18275]        # 424080 <__swc_bss_base_3464c816+0x40>
  40be0b:	cmp    rcx,rax
  40be0e:	jae    40be3a <__swc_fn_3464c816_000073_cdd57f51+0xba>
  40be10:	mov    rax,r14
  40be13:	and    rax,0xffffffffffc00000
  40be1a:	mov    rcx,r14
  40be1d:	shr    rcx,0x10
  40be21:	and    ecx,0x3f
  40be24:	mov    edx,DWORD PTR [rax+0x28]
  40be27:	shrx   ecx,ecx,edx
  40be2c:	shl    rcx,0x4
  40be30:	lea    r15,[rax+rcx*8+0x80]
  40be38:	jmp    40be45 <__swc_fn_3464c816_000073_cdd57f51+0xc5>
  40be3a:	mov    rcx,r14
  40be3d:	call   40a910 <__swc_fn_3464c816_000022_53fc00d2>
  40be42:	mov    r15,rax
  40be45:	test   r15,r15
  40be48:	je     40beef <__swc_fn_3464c816_000073_cdd57f51+0x16f>
  40be4e:	lea    rax,[rip+0x161ab]        # 422000 <__swc_data_base_3464c816>
  40be55:	mov    rax,QWORD PTR [rax]
  40be58:	cmp    rax,0xffffffffffffffff
  40be5c:	je     40be6b <__swc_fn_3464c816_000073_cdd57f51+0xeb>
  40be5e:	mov    eax,eax
  40be60:	mov    edi,eax
  40be62:	xor    eax,eax
  40be64:	call   407000 <pthread_getspecific@plt>
  40be69:	jmp    40be6d <__swc_fn_3464c816_000073_cdd57f51+0xed>
  40be6b:	xor    eax,eax
  40be6d:	mov    rcx,QWORD PTR [r15+0x40]
  40be71:	cmp    rcx,rax
  40be74:	jne    40bed4 <__swc_fn_3464c816_000073_cdd57f51+0x154>
  40be76:	test   rax,rax
  40be79:	je     40beef <__swc_fn_3464c816_000073_cdd57f51+0x16f>
  40be7b:	mov    ecx,DWORD PTR [r15+0x6c]
  40be7f:	test   ecx,ecx
  40be81:	je     40bea1 <__swc_fn_3464c816_000073_cdd57f51+0x121>
  40be83:	mov    rcx,r13
  40be86:	mov    rdx,rax
  40be89:	mov    r8,r15
  40be8c:	mov    QWORD PTR [rsp+0xd8],rax
  40be94:	call   40e410 <__swc_fn_3464c816_000047_e7fd8d42>
  40be99:	mov    rax,QWORD PTR [rsp+0xd8]
  40bea1:	mov    rcx,QWORD PTR [r15]
  40bea4:	mov    QWORD PTR [r14],rcx
  40bea7:	mov    QWORD PTR [r15],r14
  40beaa:	sub    DWORD PTR [r15+0x28],0x1
  40beaf:	jne    40bee4 <__swc_fn_3464c816_000073_cdd57f51+0x164>
  40beb1:	movzx  ecx,BYTE PTR [r15+0x39]
  40beb6:	lea    rcx,[rcx+rcx*4]
  40beba:	lea    rcx,[rax+rcx*8+0x28]
  40bebf:	cmp    QWORD PTR [rcx],r15
  40bec2:	je     40bee4 <__swc_fn_3464c816_000073_cdd57f51+0x164>
  40bec4:	mov    rcx,r13
  40bec7:	mov    rdx,rax
  40beca:	mov    r8,r15
  40becd:	call   407d80 <__swc_fn_3464c816_000051_27d2a35f>
  40bed2:	jmp    40bee4 <__swc_fn_3464c816_000073_cdd57f51+0x164>
  40bed4:	test   rcx,rcx
  40bed7:	je     40beef <__swc_fn_3464c816_000073_cdd57f51+0x16f>
  40bed9:	mov    rcx,r15
  40bedc:	mov    rdx,r14
  40bedf:	call   40a550 <__swc_fn_3464c816_000010_0569f799>
  40bee4:	mov    QWORD PTR [r12+0x40],0x0
  40beed:	jmp    40befa <__swc_fn_3464c816_000073_cdd57f51+0x17a>
  40beef:	mov    rcx,r13
  40bef2:	mov    rdx,r12
  40bef5:	call   40ef20 <__swc_fn_3464c816_000074_30b8696a>
  40befa:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40bf03:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40bf0c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40bf15:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40bf1e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40bf27:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40bf30:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40bf39:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40bf42:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40bf4b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40bf54:	add    rsp,0x188
  40bf5b:	pop    rsi
  40bf5c:	pop    rdi
  40bf5d:	pop    r15
  40bf5f:	pop    r14
  40bf61:	pop    r13
  40bf63:	pop    r12
  40bf65:	ret
	...

000000000040bf70 <__swc_fn_3464c816_000076_c3ad0fb4>:
  40bf70:	sub    rsp,0x8
  40bf74:	mov    rax,rdx
  40bf77:	mov    rdx,QWORD PTR [rax+0x40]
  40bf7b:	mov    r8,rax
  40bf7e:	call   40bb70 <__swc_fn_3464c816_000067_0145abfc>
  40bf83:	add    rsp,0x8
  40bf87:	ret
	...

000000000040bf90 <__swc_fn_3464c816_000079_633af784>:
  40bf90:	push   rsi
  40bf91:	push   rdi
  40bf92:	sub    rsp,0x8
  40bf96:	cmp    rcx,0xffffffffffffffef
  40bf9a:	ja     40bfc0 <__swc_fn_3464c816_000079_633af784+0x30>
  40bf9c:	xor    esi,esi
  40bf9e:	lea    rax,[rcx+0x100f]
  40bfa5:	and    rax,0xfffffffffffff000
  40bfac:	lea    rcx,[rcx+0x10]
  40bfb0:	cmp    rcx,0xfffffffffffff000
  40bfb7:	cmovbe rsi,rax
  40bfbb:	test   rsi,rsi
  40bfbe:	jne    40bfc9 <__swc_fn_3464c816_000079_633af784+0x39>
  40bfc0:	xor    eax,eax
  40bfc2:	add    rsp,0x8
  40bfc6:	pop    rdi
  40bfc7:	pop    rsi
  40bfc8:	ret
  40bfc9:	mov    rcx,rsi
  40bfcc:	call   40c620 <__swc_fn_3464c816_000109_9f5af8ae>
  40bfd1:	mov    rdi,rax
  40bfd4:	test   rax,rax
  40bfd7:	jne    40bfe2 <__swc_fn_3464c816_000079_633af784+0x52>
  40bfd9:	xor    eax,eax
  40bfdb:	add    rsp,0x8
  40bfdf:	pop    rdi
  40bfe0:	pop    rsi
  40bfe1:	ret
  40bfe2:	mov    rcx,rdi
  40bfe5:	mov    rdx,rsi
  40bfe8:	call   409240 <__swc_fn_3464c816_000111_f9e19033>
  40bfed:	test   al,al
  40bfef:	jne    40c005 <__swc_fn_3464c816_000079_633af784+0x75>
  40bff1:	mov    rcx,rdi
  40bff4:	mov    rdx,rsi
  40bff7:	call   410050 <__swc_fn_3464c816_000113_4e83a03a>
  40bffc:	xor    eax,eax
  40bffe:	add    rsp,0x8
  40c002:	pop    rdi
  40c003:	pop    rsi
  40c004:	ret
  40c005:	mov    QWORD PTR [rdi],rsi
  40c008:	mov    QWORD PTR [rdi+0x8],0x0
  40c010:	lea    rax,[rdi+0x10]
  40c014:	add    rsp,0x8
  40c018:	pop    rdi
  40c019:	pop    rsi
  40c01a:	ret
  40c01b:	add    BYTE PTR [rax],al
  40c01d:	add    BYTE PTR [rax],al
	...

000000000040c020 <__swc_fn_3464c816_000082_ff7d1455>:
  40c020:	sub    rsp,0x8
  40c024:	cmp    BYTE PTR [rcx+0x2c],0x10
  40c028:	jne    40c033 <__swc_fn_3464c816_000082_ff7d1455+0x13>
  40c02a:	test   DWORD PTR [rcx+0x28],0x80
  40c031:	je     40c03b <__swc_fn_3464c816_000082_ff7d1455+0x1b>
  40c033:	mov    rax,rcx
  40c036:	add    rsp,0x8
  40c03a:	ret
  40c03b:	mov    rcx,QWORD PTR [rcx+0x40]
  40c03f:	call   40c020 <__swc_fn_3464c816_000082_ff7d1455>
  40c044:	add    rsp,0x8
  40c048:	ret
	...

000000000040c060 <__swc_fn_3464c816_000085_e24ecd12>:
  40c060:	push   rsi
  40c061:	push   rdi
  40c062:	push   r12
  40c064:	push   r13
  40c066:	sub    rsp,0x8
  40c06a:	mov    rsi,rdx
  40c06d:	mov    rdi,rcx
  40c070:	xor    r8d,r8d
  40c073:	call   4085a0 <__swc_fn_3464c816_000090_14cf59b2>
  40c078:	test   al,al
  40c07a:	je     40c08c <__swc_fn_3464c816_000085_e24ecd12+0x2c>
  40c07c:	mov    eax,0x1
  40c081:	add    rsp,0x8
  40c085:	pop    r13
  40c087:	pop    r12
  40c089:	pop    rdi
  40c08a:	pop    rsi
  40c08b:	ret
  40c08c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40c091:	je     40c0a0 <__swc_fn_3464c816_000085_e24ecd12+0x40>
  40c093:	xor    eax,eax
  40c095:	add    rsp,0x8
  40c099:	pop    r13
  40c09b:	pop    r12
  40c09d:	pop    rdi
  40c09e:	pop    rsi
  40c09f:	ret
  40c0a0:	mov    r12,QWORD PTR [rsi+0x98]
  40c0a7:	mov    rax,QWORD PTR [rsi+0xa0]
  40c0ae:	mov    rsi,rax
  40c0b1:	xor    r13d,r13d
  40c0b4:	test   rsi,rsi
  40c0b7:	je     40c114 <__swc_fn_3464c816_000085_e24ecd12+0xb4>
  40c0b9:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0c3:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0cd:	nop    DWORD PTR [rax]
  40c0d0:	lea    rax,[r13*8+0x0]
  40c0d8:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40c0dd:	mov    rcx,rax
  40c0e0:	call   40c020 <__swc_fn_3464c816_000082_ff7d1455>
  40c0e5:	cmp    BYTE PTR [rax+0x2c],0xe
  40c0e9:	jne    40c10a <__swc_fn_3464c816_000085_e24ecd12+0xaa>
  40c0eb:	mov    rcx,rdi
  40c0ee:	mov    rdx,rax
  40c0f1:	call   40c060 <__swc_fn_3464c816_000085_e24ecd12>
  40c0f6:	test   al,al
  40c0f8:	je     40c10a <__swc_fn_3464c816_000085_e24ecd12+0xaa>
  40c0fa:	mov    eax,0x1
  40c0ff:	add    rsp,0x8
  40c103:	pop    r13
  40c105:	pop    r12
  40c107:	pop    rdi
  40c108:	pop    rsi
  40c109:	ret
  40c10a:	add    r13,0x1
  40c10e:	sub    rsi,0x1
  40c112:	jne    40c0d0 <__swc_fn_3464c816_000085_e24ecd12+0x70>
  40c114:	xor    eax,eax
  40c116:	add    rsp,0x8
  40c11a:	pop    r13
  40c11c:	pop    r12
  40c11e:	pop    rdi
  40c11f:	pop    rsi
  40c120:	ret
	...

000000000040c130 <__swc_fn_3464c816_000088_ab2f35d8>:
  40c130:	sub    rsp,0x18
  40c134:	vxorps xmm0,xmm0,xmm0
  40c138:	vmovdqu XMMWORD PTR [rsp],xmm0
  40c13d:	call   40f130 <__swc_fn_3464c816_000089_3c530920>
  40c142:	add    rsp,0x18
  40c146:	ret
	...

000000000040c150 <__swc_fn_3464c816_000091_f21926ed>:
  40c150:	sub    rsp,0x8
  40c154:	mov    rcx,QWORD PTR [rip+0x1abe5]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40c15b:	test   rcx,rcx
  40c15e:	jne    40c170 <__swc_fn_3464c816_000091_f21926ed+0x20>
  40c160:	call   40a1a0 <__swc_fn_3464c816_000165_56054fe7>
  40c165:	lea    rcx,[rax+0x1]
  40c169:	mov    QWORD PTR [rip+0x1abd0],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40c170:	dec    rcx
  40c173:	call   411e20 <__swc_fn_3464c816_000167_39c041ad>
  40c178:	mov    rax,QWORD PTR [rax+0xc0]
  40c17f:	and    eax,0x1
  40c182:	setne  al
  40c185:	add    rsp,0x8
  40c189:	ret
	...

000000000040c1a0 <__swc_fn_3464c816_000094_383a814c>:
  40c1a0:	push   rbx
  40c1a1:	push   rsi
  40c1a2:	push   rdi
  40c1a3:	push   r12
  40c1a5:	sub    rsp,0x28
  40c1a9:	mov    rbx,rcx
  40c1ac:	call   408900 <__swc_fn_3464c816_000093_0c97fc6c>
  40c1b1:	mov    rcx,QWORD PTR [rip+0x1ab88]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40c1b8:	test   rcx,rcx
  40c1bb:	jne    40c1cd <__swc_fn_3464c816_000094_383a814c+0x2d>
  40c1bd:	call   40a1a0 <__swc_fn_3464c816_000165_56054fe7>
  40c1c2:	lea    rcx,[rax+0x1]
  40c1c6:	mov    QWORD PTR [rip+0x1ab73],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40c1cd:	dec    rcx
  40c1d0:	call   411e20 <__swc_fn_3464c816_000167_39c041ad>
  40c1d5:	mov    rsi,rax
  40c1d8:	lea    rcx,[rsp+0x8]
  40c1dd:	call   40f570 <__swc_fn_3464c816_000092_809deff5>
  40c1e2:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40c1e9:	mov    r12,QWORD PTR [rsi+0xbe8]
  40c1f0:	lea    rcx,[rsi+0x10]
  40c1f4:	call   40d170 <__swc_fn_3464c816_000157_3495a3ca>
  40c1f9:	mov    rcx,rsi
  40c1fc:	call   40f6e0 <__swc_fn_3464c816_000101_afcb7774>
  40c201:	vxorps xmm0,xmm0,xmm0
  40c205:	xor    eax,eax
  40c207:	cs nop WORD PTR [rax+rax*1+0x0]
  40c211:	cs nop WORD PTR [rax+rax*1+0x0]
  40c21b:	nop    DWORD PTR [rax+rax*1+0x0]
  40c220:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40c225:	add    rax,0x10
  40c229:	cmp    rax,0xbf0
  40c230:	jne    40c220 <__swc_fn_3464c816_000094_383a814c+0x80>
  40c232:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c238:	vmovups XMMWORD PTR [rsi],xmm0
  40c23c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c242:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40c24a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40c251:	mov    QWORD PTR [rsi+0xbe8],r12
  40c258:	mov    rcx,QWORD PTR [rip+0x1aae1]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40c25f:	test   rcx,rcx
  40c262:	jne    40c274 <__swc_fn_3464c816_000094_383a814c+0xd4>
  40c264:	call   40a1a0 <__swc_fn_3464c816_000165_56054fe7>
  40c269:	lea    rcx,[rax+0x1]
  40c26d:	mov    QWORD PTR [rip+0x1aacc],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40c274:	dec    rcx
  40c277:	call   411e20 <__swc_fn_3464c816_000167_39c041ad>
  40c27c:	mov    rsi,rax
  40c27f:	mov    QWORD PTR [rsi+0xc0],rbx
  40c286:	and    ebx,0x1
  40c289:	jne    40c28d <__swc_fn_3464c816_000094_383a814c+0xed>
  40c28b:	xor    eax,eax
  40c28d:	test   rbx,rbx
  40c290:	sete   al
  40c293:	xor    cl,cl
  40c295:	xor    dl,dl
  40c297:	xor    r8b,r8b
  40c29a:	xor    r9b,r9b
  40c29d:	xor    r10b,r10b
  40c2a0:	mov    r11,rax
  40c2a3:	call   40ef30 <__swc_fn_3464c816_000077_948ef603>
  40c2a8:	lea    rbx,[rsp+0x18]
  40c2ad:	mov    rcx,rbx
  40c2b0:	call   40f570 <__swc_fn_3464c816_000092_809deff5>
  40c2b5:	lea    rcx,[rsi+0x10]
  40c2b9:	mov    edx,0x400000
  40c2be:	mov    r8,rbx
  40c2c1:	call   409ee0 <__swc_fn_3464c816_000159_6861d596>
  40c2c6:	lea    rcx,[rsi+0x68]
  40c2ca:	mov    edx,0x4000
  40c2cf:	mov    r8,rbx
  40c2d2:	call   409ee0 <__swc_fn_3464c816_000159_6861d596>
  40c2d7:	add    rsp,0x28
  40c2db:	pop    r12
  40c2dd:	pop    rdi
  40c2de:	pop    rsi
  40c2df:	pop    rbx
  40c2e0:	ret
	...

000000000040c2f0 <__swc_fn_3464c816_000097_96d6739a>:
  40c2f0:	push   rbx
  40c2f1:	push   rsi
  40c2f2:	sub    rsp,0x18
  40c2f6:	mov    rbx,rcx
  40c2f9:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40c2fe:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c304:	mov    rsi,QWORD PTR [rbx+0x70]
  40c308:	lea    rcx,[rcx+0x18]
  40c30c:	call   40d170 <__swc_fn_3464c816_000157_3495a3ca>
  40c311:	lea    rcx,[rsp+0x8]
  40c316:	mov    rdx,rbx
  40c319:	mov    r8d,0x78
  40c31f:	call   408960 <__swc_fn_3464c816_000096_a4baaa40>
  40c324:	mov    rax,rsi
  40c327:	add    rsp,0x18
  40c32b:	pop    rsi
  40c32c:	pop    rbx
  40c32d:	ret
	...

000000000040c330 <__swc_fn_3464c816_000100_5714513e>:
  40c330:	push   rsi
  40c331:	push   rdi
  40c332:	sub    rsp,0x8
  40c336:	cmp    QWORD PTR [rcx],0x0
  40c33a:	jne    40c343 <__swc_fn_3464c816_000100_5714513e+0x13>
  40c33c:	add    rsp,0x8
  40c340:	pop    rdi
  40c341:	pop    rsi
  40c342:	ret
  40c343:	mov    rsi,QWORD PTR [rcx]
  40c346:	mov    rax,QWORD PTR [rcx+0x8]
  40c34a:	test   rax,rax
  40c34d:	je     40c363 <__swc_fn_3464c816_000100_5714513e+0x33>
  40c34f:	test   DWORD PTR [rax+0x28],0x400000
  40c356:	je     40c363 <__swc_fn_3464c816_000100_5714513e+0x33>
  40c358:	mov    rcx,QWORD PTR [rax+0x30]
  40c35c:	test   rcx,rcx
  40c35f:	cmovne rax,rcx
  40c363:	lea    rdx,[rip+0x6e66]        # 4131d0 <__swc_rdata_base_3464c816+0xc0>
  40c36a:	lea    rcx,[rip+0x6f47]        # 4132b8 <__swc_rdata_base_3464c816+0x1a8>
  40c371:	mov    r8,rax
  40c374:	xor    r9d,r9d
  40c377:	xor    al,al
  40c379:	mov    r10,rax
  40c37c:	xor    r11d,r11d
  40c37f:	call   40c130 <__swc_fn_3464c816_000088_ab2f35d8>
  40c384:	test   rax,rax
  40c387:	je     40c397 <__swc_fn_3464c816_000100_5714513e+0x67>
  40c389:	mov    rdi,QWORD PTR [rax+0x48]
  40c38d:	test   rdi,rdi
  40c390:	je     40c397 <__swc_fn_3464c816_000100_5714513e+0x67>
  40c392:	mov    rcx,rsi
  40c395:	call   rdi
  40c397:	add    rsp,0x8
  40c39b:	pop    rdi
  40c39c:	pop    rsi
  40c39d:	ret
	...

000000000040c3a0 <__swc_fn_3464c816_000103_0d4cc079>:
  40c3a0:	push   rbx
  40c3a1:	push   rsi
  40c3a2:	push   rdi
  40c3a3:	sub    rsp,0x20
  40c3a7:	mov    rbx,rdx
  40c3aa:	mov    rsi,rcx
  40c3ad:	mov    rcx,QWORD PTR [rip+0x1a98c]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40c3b4:	test   rcx,rcx
  40c3b7:	jne    40c3c9 <__swc_fn_3464c816_000103_0d4cc079+0x29>
  40c3b9:	call   40a1a0 <__swc_fn_3464c816_000165_56054fe7>
  40c3be:	lea    rcx,[rax+0x1]
  40c3c2:	mov    QWORD PTR [rip+0x1a977],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40c3c9:	dec    rcx
  40c3cc:	call   411e20 <__swc_fn_3464c816_000167_39c041ad>
  40c3d1:	mov    rdi,rax
  40c3d4:	mov    rax,QWORD PTR [rdi+0xbd0]
  40c3db:	xor    ecx,ecx
  40c3dd:	test   rax,rax
  40c3e0:	je     40c3e5 <__swc_fn_3464c816_000103_0d4cc079+0x45>
  40c3e2:	mov    rcx,QWORD PTR [rax]
  40c3e5:	call   40a2d0 <__swc_fn_3464c816_000174_02e645b4>
  40c3ea:	lea    rax,[rsp+0x8]
  40c3ef:	lea    rcx,[rdi+0x9c8]
  40c3f6:	mov    QWORD PTR [rsp+0x8],rcx
  40c3fb:	mov    QWORD PTR [rax+0x8],0x40
  40c403:	xor    ecx,ecx
  40c405:	mov    rdx,rax
  40c408:	call   410180 <__swc_fn_3464c816_000119_2d9caf16>
  40c40d:	mov    DWORD PTR [rdi+0xbc8],eax
  40c413:	mov    rdi,QWORD PTR [rdi+0x990]
  40c41a:	test   rdi,rdi
  40c41d:	je     40c427 <__swc_fn_3464c816_000103_0d4cc079+0x87>
  40c41f:	mov    rcx,rsi
  40c422:	mov    rdx,rbx
  40c425:	call   rdi
  40c427:	call   40c150 <__swc_fn_3464c816_000091_f21926ed>
  40c42c:	test   al,al
  40c42e:	je     40c43e <__swc_fn_3464c816_000103_0d4cc079+0x9e>
  40c430:	mov    rcx,rsi
  40c433:	mov    rdx,rbx
  40c436:	xor    r8d,r8d
  40c439:	call   4093e0 <__swc_fn_3464c816_000120_1e032ef6>
  40c43e:	mov    rcx,rsi
  40c441:	mov    rdx,rbx
  40c444:	call   408a60 <__swc_fn_3464c816_000102_14986ec5>
  40c449:	call   40c9d0 <__swc_fn_3464c816_000118_591530fe>
  40c44e:	add    rsp,0x20
  40c452:	pop    rdi
  40c453:	pop    rsi
  40c454:	pop    rbx
  40c455:	ret
	...

000000000040c460 <__swc_fn_3464c816_000106_aba05410>:
  40c460:	test   r8,r8
  40c463:	jne    40c468 <__swc_fn_3464c816_000106_aba05410+0x8>
  40c465:	xor    eax,eax
  40c467:	ret
  40c468:	xor    eax,eax
  40c46a:	nop    WORD PTR [rax+rax*1+0x0]
  40c470:	mov    r9,r8
  40c473:	sub    r9,rax
  40c476:	cmp    r9,0x10
  40c47a:	jb     40c4c4 <__swc_fn_3464c816_000106_aba05410+0x64>
  40c47c:	lea    r9,[rcx+rax*1]
  40c480:	lea    r10,[rdx+rax*1]
  40c484:	vmovups xmm0,XMMWORD PTR [r10]
  40c489:	vmovups xmm1,XMMWORD PTR [r9]
  40c48e:	vpcmpeqb xmm0,xmm1,xmm0
  40c492:	vpmovmskb r9d,xmm0
  40c496:	cmp    r9d,0xffff
  40c49d:	je     40c4be <__swc_fn_3464c816_000106_aba05410+0x5e>
  40c49f:	not    r9d
  40c4a2:	xor    r8d,r8d
  40c4a5:	movzx  r9d,r9w
  40c4a9:	tzcnt  r8d,r9d
  40c4ae:	add    rax,r8
  40c4b1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4b5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4b9:	sub    ecx,eax
  40c4bb:	mov    eax,ecx
  40c4bd:	ret
  40c4be:	lea    rax,[rax+0x10]
  40c4c2:	jmp    40c470 <__swc_fn_3464c816_000106_aba05410+0x10>
  40c4c4:	cmp    r9,0x8
  40c4c8:	jb     40c53b <__swc_fn_3464c816_000106_aba05410+0xdb>
  40c4ca:	lea    r9,[rcx+rax*1]
  40c4ce:	lea    r10,[rdx+rax*1]
  40c4d2:	mov    r9,QWORD PTR [r9]
  40c4d5:	xor    r9,QWORD PTR [r10]
  40c4d8:	test   r9,r9
  40c4db:	je     40c4f9 <__swc_fn_3464c816_000106_aba05410+0x99>
  40c4dd:	xor    r8d,r8d
  40c4e0:	tzcnt  r8,r9
  40c4e5:	shr    r8,0x3
  40c4e9:	add    rax,r8
  40c4ec:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4f0:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4f4:	sub    ecx,eax
  40c4f6:	mov    eax,ecx
  40c4f8:	ret
  40c4f9:	lea    rax,[rax+0x8]
  40c4fd:	cmp    rax,r8
  40c500:	jne    40c505 <__swc_fn_3464c816_000106_aba05410+0xa5>
  40c502:	xor    eax,eax
  40c504:	ret
  40c505:	lea    rax,[r8-0x8]
  40c509:	lea    r8,[rcx+rax*1]
  40c50d:	lea    r9,[rdx+rax*1]
  40c511:	mov    r8,QWORD PTR [r8]
  40c514:	xor    r8,QWORD PTR [r9]
  40c517:	test   r8,r8
  40c51a:	je     40c538 <__swc_fn_3464c816_000106_aba05410+0xd8>
  40c51c:	xor    r9d,r9d
  40c51f:	tzcnt  r9,r8
  40c524:	shr    r9,0x3
  40c528:	add    rax,r9
  40c52b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c52f:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c533:	sub    ecx,eax
  40c535:	mov    eax,ecx
  40c537:	ret
  40c538:	xor    eax,eax
  40c53a:	ret
  40c53b:	cmp    r9,0x4
  40c53f:	jb     40c5b2 <__swc_fn_3464c816_000106_aba05410+0x152>
  40c541:	lea    r9,[rcx+rax*1]
  40c545:	lea    r10,[rdx+rax*1]
  40c549:	mov    r9d,DWORD PTR [r9]
  40c54c:	xor    r9d,DWORD PTR [r10]
  40c54f:	test   r9d,r9d
  40c552:	je     40c570 <__swc_fn_3464c816_000106_aba05410+0x110>
  40c554:	xor    r8d,r8d
  40c557:	tzcnt  r8,r9
  40c55c:	shr    r8,0x3
  40c560:	add    rax,r8
  40c563:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c567:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c56b:	sub    ecx,eax
  40c56d:	mov    eax,ecx
  40c56f:	ret
  40c570:	lea    rax,[rax+0x4]
  40c574:	cmp    rax,r8
  40c577:	jne    40c57c <__swc_fn_3464c816_000106_aba05410+0x11c>
  40c579:	xor    eax,eax
  40c57b:	ret
  40c57c:	lea    rax,[r8-0x4]
  40c580:	lea    r8,[rcx+rax*1]
  40c584:	lea    r9,[rdx+rax*1]
  40c588:	mov    r8d,DWORD PTR [r8]
  40c58b:	xor    r8d,DWORD PTR [r9]
  40c58e:	test   r8d,r8d
  40c591:	je     40c5af <__swc_fn_3464c816_000106_aba05410+0x14f>
  40c593:	xor    r9d,r9d
  40c596:	tzcnt  r9,r8
  40c59b:	shr    r9,0x3
  40c59f:	add    rax,r9
  40c5a2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c5a6:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c5aa:	sub    ecx,eax
  40c5ac:	mov    eax,ecx
  40c5ae:	ret
  40c5af:	xor    eax,eax
  40c5b1:	ret
  40c5b2:	cmp    r9,0x2
  40c5b6:	jb     40c609 <__swc_fn_3464c816_000106_aba05410+0x1a9>
  40c5b8:	lea    r9,[rcx+rax*1]
  40c5bc:	lea    r10,[rdx+rax*1]
  40c5c0:	mov    r9w,WORD PTR [r9]
  40c5c4:	xor    r9w,WORD PTR [r10]
  40c5c8:	test   r9w,r9w
  40c5cc:	je     40c5ee <__swc_fn_3464c816_000106_aba05410+0x18e>
  40c5ce:	xor    r8d,r8d
  40c5d1:	movzx  r9d,r9w
  40c5d5:	tzcnt  r8,r9
  40c5da:	shr    r8,0x3
  40c5de:	add    rax,r8
  40c5e1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c5e5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c5e9:	sub    ecx,eax
  40c5eb:	mov    eax,ecx
  40c5ed:	ret
  40c5ee:	lea    rax,[rax+0x2]
  40c5f2:	cmp    rax,r8
  40c5f5:	jne    40c5fa <__swc_fn_3464c816_000106_aba05410+0x19a>
  40c5f7:	xor    eax,eax
  40c5f9:	ret
  40c5fa:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40c600:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40c606:	sub    eax,ecx
  40c608:	ret
  40c609:	test   r9,r9
  40c60c:	je     40c61b <__swc_fn_3464c816_000106_aba05410+0x1bb>
  40c60e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c612:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c616:	sub    ecx,eax
  40c618:	mov    eax,ecx
  40c61a:	ret
  40c61b:	xor    eax,eax
  40c61d:	ret
	...

000000000040c620 <__swc_fn_3464c816_000109_9f5af8ae>:
  40c620:	push   r12
  40c622:	push   r13
  40c624:	push   r14
  40c626:	push   rdi
  40c627:	push   rsi
  40c628:	push   r15
  40c62a:	sub    rsp,0xd8
  40c631:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c637:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c63d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c643:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c649:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c64f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c658:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c661:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c66a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c673:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c67c:	mov    r12,rcx
  40c67f:	test   rcx,rcx
  40c682:	je     40c69e <__swc_fn_3464c816_000109_9f5af8ae+0x7e>
  40c684:	mov    eax,r12d
  40c687:	and    eax,0xfff
  40c68d:	setne  al
  40c690:	cmp    r12,0xffffffffffffefff
  40c697:	seta   cl
  40c69a:	or     al,cl
  40c69c:	je     40c6a5 <__swc_fn_3464c816_000109_9f5af8ae+0x85>
  40c69e:	xor    eax,eax
  40c6a0:	jmp    40c73b <__swc_fn_3464c816_000109_9f5af8ae+0x11b>
  40c6a5:	call   409100 <__swc_fn_3464c816_000108_b8f4bd15>
  40c6aa:	mov    r13,rax
  40c6ad:	test   rax,rax
  40c6b0:	jne    40c6b9 <__swc_fn_3464c816_000109_9f5af8ae+0x99>
  40c6b2:	xor    eax,eax
  40c6b4:	jmp    40c73b <__swc_fn_3464c816_000109_9f5af8ae+0x11b>
  40c6b9:	lea    r14,[r12+0x1000]
  40c6c1:	xor    edi,edi
  40c6c3:	mov    rsi,r14
  40c6c6:	xor    edx,edx
  40c6c8:	mov    ecx,0x22
  40c6cd:	mov    eax,0xffffffff
  40c6d2:	movsxd r8,eax
  40c6d5:	xor    r9d,r9d
  40c6d8:	xor    eax,eax
  40c6da:	call   4070c0 <mmap@plt>
  40c6df:	mov    r15,rax
  40c6e2:	cmp    rax,0xffffffffffffffff
  40c6e6:	jne    40c6ec <__swc_fn_3464c816_000109_9f5af8ae+0xcc>
  40c6e8:	xor    eax,eax
  40c6ea:	jmp    40c73b <__swc_fn_3464c816_000109_9f5af8ae+0x11b>
  40c6ec:	mov    rdi,r15
  40c6ef:	mov    esi,0x1000
  40c6f4:	mov    edx,0x3
  40c6f9:	xor    eax,eax
  40c6fb:	call   407030 <mprotect@plt>
  40c700:	test   eax,eax
  40c702:	je     40c715 <__swc_fn_3464c816_000109_9f5af8ae+0xf5>
  40c704:	mov    rdi,r15
  40c707:	mov    rsi,r14
  40c70a:	xor    eax,eax
  40c70c:	call   407020 <munmap@plt>
  40c711:	xor    eax,eax
  40c713:	jmp    40c73b <__swc_fn_3464c816_000109_9f5af8ae+0x11b>
  40c715:	mov    QWORD PTR [r15+0x8],r12
  40c719:	mov    rcx,r13
  40c71c:	call   40cd70 <__swc_fn_3464c816_000133_807fd51d>
  40c721:	mov    rax,QWORD PTR [r13+0x8]
  40c725:	mov    QWORD PTR [r15],rax
  40c728:	mov    QWORD PTR [r13+0x8],r15
  40c72c:	mov    rcx,r13
  40c72f:	call   410520 <__swc_fn_3464c816_000134_10472836>
  40c734:	lea    rax,[r15+0x1000]
  40c73b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c741:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c747:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c74d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c753:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c759:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c762:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c76b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c774:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c77d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c786:	add    rsp,0xd8
  40c78d:	pop    r15
  40c78f:	pop    rsi
  40c790:	pop    rdi
  40c791:	pop    r14
  40c793:	pop    r13
  40c795:	pop    r12
  40c797:	ret
	...

000000000040c7a0 <__swc_fn_3464c816_000112_2f7f9346>:
  40c7a0:	push   rbx
  40c7a1:	push   r12
  40c7a3:	push   rdi
  40c7a4:	push   rsi
  40c7a5:	sub    rsp,0xa8
  40c7ac:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c7b2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c7b8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c7be:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c7c4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c7ca:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c7d0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40c7d6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40c7dc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40c7e5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40c7ee:	mov    rbx,rdx
  40c7f1:	mov    r12,rcx
  40c7f4:	mov    rdi,rcx
  40c7f7:	mov    rsi,rdx
  40c7fa:	xor    edx,edx
  40c7fc:	xor    eax,eax
  40c7fe:	call   407030 <mprotect@plt>
  40c803:	test   eax,eax
  40c805:	jne    40c829 <__swc_fn_3464c816_000112_2f7f9346+0x89>
  40c807:	mov    rcx,r12
  40c80a:	mov    rdx,rbx
  40c80d:	xor    al,al
  40c80f:	mov    r8,rax
  40c812:	call   40ffc0 <__swc_fn_3464c816_000110_918d5a21>
  40c817:	mov    rdi,r12
  40c81a:	mov    rsi,rbx
  40c81d:	mov    edx,0x4
  40c822:	xor    eax,eax
  40c824:	call   4070f0 <madvise@plt>
  40c829:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40c82f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40c835:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40c83b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40c841:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40c847:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40c84d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40c853:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40c859:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40c862:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40c86b:	add    rsp,0xa8
  40c872:	pop    rsi
  40c873:	pop    rdi
  40c874:	pop    r12
  40c876:	pop    rbx
  40c877:	ret
	...

000000000040c880 <__swc_fn_3464c816_000115_3f6af4b1>:
  40c880:	push   rsi
  40c881:	push   rdi
  40c882:	push   r12
  40c884:	push   r13
  40c886:	push   r14
  40c888:	sub    rsp,0xe0
  40c88f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c895:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c89b:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c8a1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c8a7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c8ad:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c8b6:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c8bf:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c8c8:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c8d1:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c8da:	mov    rsi,rdx
  40c8dd:	mov    rdi,rcx
  40c8e0:	call   409100 <__swc_fn_3464c816_000108_b8f4bd15>
  40c8e5:	mov    r12,rax
  40c8e8:	test   rax,rax
  40c8eb:	jne    40c8f2 <__swc_fn_3464c816_000115_3f6af4b1+0x72>
  40c8ed:	jmp    40c966 <__swc_fn_3464c816_000115_3f6af4b1+0xe6>
  40c8f2:	mov    rcx,r12
  40c8f5:	call   40cd70 <__swc_fn_3464c816_000133_807fd51d>
  40c8fa:	lea    r13,[r12+0x8]
  40c8ff:	mov    rax,QWORD PTR [r13+0x0]
  40c903:	test   rax,rax
  40c906:	je     40c95e <__swc_fn_3464c816_000115_3f6af4b1+0xde>
  40c908:	nop    DWORD PTR [rax+rax*1+0x0]
  40c910:	lea    rcx,[rax+0x1000]
  40c917:	cmp    rcx,rdi
  40c91a:	jne    40c952 <__swc_fn_3464c816_000115_3f6af4b1+0xd2>
  40c91c:	cmp    QWORD PTR [rax+0x8],rsi
  40c920:	je     40c92c <__swc_fn_3464c816_000115_3f6af4b1+0xac>
  40c922:	mov    rcx,r12
  40c925:	call   410520 <__swc_fn_3464c816_000134_10472836>
  40c92a:	jmp    40c966 <__swc_fn_3464c816_000115_3f6af4b1+0xe6>
  40c92c:	mov    r14,QWORD PTR [rax]
  40c92f:	mov    rdi,rax
  40c932:	lea    rsi,[rsi+0x1000]
  40c939:	xor    eax,eax
  40c93b:	call   407020 <munmap@plt>
  40c940:	test   eax,eax
  40c942:	jne    40c948 <__swc_fn_3464c816_000115_3f6af4b1+0xc8>
  40c944:	mov    QWORD PTR [r13+0x0],r14
  40c948:	mov    rcx,r12
  40c94b:	call   410520 <__swc_fn_3464c816_000134_10472836>
  40c950:	jmp    40c966 <__swc_fn_3464c816_000115_3f6af4b1+0xe6>
  40c952:	mov    r13,rax
  40c955:	mov    rax,QWORD PTR [r13+0x0]
  40c959:	test   rax,rax
  40c95c:	jne    40c910 <__swc_fn_3464c816_000115_3f6af4b1+0x90>
  40c95e:	mov    rcx,r12
  40c961:	call   410520 <__swc_fn_3464c816_000134_10472836>
  40c966:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c96c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c972:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c978:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c97e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c984:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c98d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c996:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c99f:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c9a8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c9b1:	add    rsp,0xe0
  40c9b8:	pop    r14
  40c9ba:	pop    r13
  40c9bc:	pop    r12
  40c9be:	pop    rdi
  40c9bf:	pop    rsi
  40c9c0:	ret
	...

000000000040c9d0 <__swc_fn_3464c816_000118_591530fe>:
  40c9d0:	push   rdi
  40c9d1:	push   rsi
  40c9d2:	sub    rsp,0xa8
  40c9d9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c9df:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c9e5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c9eb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c9f1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c9f7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c9fd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ca03:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ca09:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ca12:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ca1b:	mov    rdi,0xfffffffffffffd66
  40ca22:	xor    eax,eax
  40ca24:	call   407040 <exit@plt>
  40ca29:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ca2f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ca35:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ca3b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ca41:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ca47:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ca4d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ca53:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ca59:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ca62:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ca6b:	add    rsp,0xa8
  40ca72:	pop    rsi
  40ca73:	pop    rdi
  40ca74:	ret
	...

000000000040ca80 <__swc_fn_3464c816_000121_1c5e75b6>:
  40ca80:	push   rbx
  40ca81:	push   rsi
  40ca82:	push   rdi
  40ca83:	sub    rsp,0x30
  40ca87:	mov    rbx,rdx
  40ca8a:	mov    esi,ecx
  40ca8c:	test   ecx,ecx
  40ca8e:	je     40cb63 <__swc_fn_3464c816_000121_1c5e75b6+0xe3>
  40ca94:	mov    rcx,rsi
  40ca97:	shl    rcx,0x4
  40ca9b:	call   40bf90 <__swc_fn_3464c816_000079_633af784>
  40caa0:	test   rax,rax
  40caa3:	je     40cb52 <__swc_fn_3464c816_000121_1c5e75b6+0xd2>
  40caa9:	mov    rcx,rsi
  40caac:	xor    edx,edx
  40caae:	test   rsi,rsi
  40cab1:	jbe    40cb32 <__swc_fn_3464c816_000121_1c5e75b6+0xb2>
  40cab7:	nop    WORD PTR [rax+rax*1+0x0]
  40cac0:	mov    r8d,edx
  40cac3:	mov    r9,QWORD PTR [rbx+r8*8]
  40cac7:	add    r8,r8
  40caca:	lea    r8,[rax+r8*8]
  40cace:	xor    r10d,r10d
  40cad1:	test   r9,r9
  40cad4:	je     40cb10 <__swc_fn_3464c816_000121_1c5e75b6+0x90>
  40cad6:	mov    r11,r9
  40cad9:	mov    dil,BYTE PTR [r11]
  40cadc:	test   dil,dil
  40cadf:	je     40cb10 <__swc_fn_3464c816_000121_1c5e75b6+0x90>
  40cae1:	cs nop WORD PTR [rax+rax*1+0x0]
  40caeb:	cs nop WORD PTR [rax+rax*1+0x0]
  40caf5:	cs nop WORD PTR [rax+rax*1+0x0]
  40caff:	nop
  40cb00:	add    r11,0x1
  40cb04:	add    r10,0x1
  40cb08:	mov    dil,BYTE PTR [r11]
  40cb0b:	test   dil,dil
  40cb0e:	jne    40cb00 <__swc_fn_3464c816_000121_1c5e75b6+0x80>
  40cb10:	mov    QWORD PTR [rsp+0x18],r9
  40cb15:	mov    QWORD PTR [rsp+0x20],r10
  40cb1a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40cb20:	vmovups XMMWORD PTR [r8],xmm0
  40cb25:	add    rdx,0x1
  40cb29:	cmp    rdx,rcx
  40cb2c:	jb     40cac0 <__swc_fn_3464c816_000121_1c5e75b6+0x40>
  40cb32:	lea    rcx,[rip+0x1a217]        # 426d50 <__swc_bss_base_3464c816+0x2d10>
  40cb39:	mov    QWORD PTR [rsp+0x8],rax
  40cb3e:	mov    esi,esi
  40cb40:	mov    QWORD PTR [rsp+0x10],rsi
  40cb45:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40cb4b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40cb50:	jmp    40cb63 <__swc_fn_3464c816_000121_1c5e75b6+0xe3>
  40cb52:	lea    rcx,[rip+0x69c7]        # 413520 <__swc_rdata_base_3464c816+0x410>
  40cb59:	call   410070 <__swc_fn_3464c816_000116_3f5cfdef>
  40cb5e:	call   40c9d0 <__swc_fn_3464c816_000118_591530fe>
  40cb63:	add    rsp,0x30
  40cb67:	pop    rdi
  40cb68:	pop    rsi
  40cb69:	pop    rbx
  40cb6a:	ret
  40cb6b:	add    BYTE PTR [rax],al
  40cb6d:	add    BYTE PTR [rax],al
	...

000000000040cb70 <__swc_fn_3464c816_000124_37eaf452>:
  40cb70:	push   rdi
  40cb71:	push   rsi
  40cb72:	sub    rsp,0xa8
  40cb79:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cb7f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cb85:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cb8b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cb91:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cb97:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cb9d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cba3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cba9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cbb2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cbbb:	mov    edi,ecx
  40cbbd:	xor    eax,eax
  40cbbf:	call   407100 <pthread_key_delete@plt>
  40cbc4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cbca:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cbd0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cbd6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cbdc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cbe2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cbe8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cbee:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cbf4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cbfd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cc06:	add    rsp,0xa8
  40cc0d:	pop    rsi
  40cc0e:	pop    rdi
  40cc0f:	ret

000000000040cc10 <__swc_fn_3464c816_000127_f163135d>:
  40cc10:	push   rdi
  40cc11:	push   rsi
  40cc12:	sub    rsp,0xa8
  40cc19:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cc1f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cc25:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cc2b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cc31:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cc37:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cc3d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cc43:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cc49:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cc52:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cc5b:	test   rcx,rcx
  40cc5e:	je     40cc6f <__swc_fn_3464c816_000127_f163135d+0x5f>
  40cc60:	lea    rax,[rcx-0x1]
  40cc64:	mov    eax,eax
  40cc66:	mov    edi,eax
  40cc68:	xor    eax,eax
  40cc6a:	call   407100 <pthread_key_delete@plt>
  40cc6f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cc75:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cc7b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cc81:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cc87:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cc8d:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cc93:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cc99:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cc9f:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cca8:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ccb1:	add    rsp,0xa8
  40ccb8:	pop    rsi
  40ccb9:	pop    rdi
  40ccba:	ret
  40ccbb:	add    BYTE PTR [rax],al
  40ccbd:	add    BYTE PTR [rax],al
	...

000000000040ccc0 <__swc_fn_3464c816_000130_375c7357>:
  40ccc0:	push   rsi
  40ccc1:	push   rdi
  40ccc2:	sub    rsp,0xa8
  40ccc9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cccf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ccd5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ccdb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cce1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cce7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cced:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ccf3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ccf9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cd02:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cd0b:	xor    eax,eax
  40cd0d:	call   407110 <gettid@plt>
  40cd12:	movsxd rax,eax
  40cd15:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cd1b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cd21:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cd27:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cd2d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cd33:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cd39:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cd3f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cd45:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cd4e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cd57:	add    rsp,0xa8
  40cd5e:	pop    rdi
  40cd5f:	pop    rsi
  40cd60:	ret
	...

000000000040cd70 <__swc_fn_3464c816_000133_807fd51d>:
  40cd70:	push   rbx
  40cd71:	push   rdi
  40cd72:	push   rsi
  40cd73:	sub    rsp,0xc0
  40cd7a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40cd80:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40cd86:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40cd8c:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40cd92:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40cd98:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40cd9e:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40cda4:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40cdad:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40cdb6:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40cdbf:	mov    rbx,rcx
  40cdc2:	cs nop WORD PTR [rax+rax*1+0x0]
  40cdcc:	nop    DWORD PTR [rax+0x0]
  40cdd0:	mov    edx,0x80000000
  40cdd5:	xor    eax,eax
  40cdd7:	lock cmpxchg DWORD PTR [rbx],edx
  40cddb:	test   eax,eax
  40cddd:	je     40ce14 <__swc_fn_3464c816_000133_807fd51d+0xa4>
  40cddf:	mov    eax,DWORD PTR [rbx]
  40cde1:	lea    rcx,[rsp+0x14]
  40cde6:	mov    DWORD PTR [rsp+0x14],eax
  40cdea:	test   eax,eax
  40cdec:	je     40cdd0 <__swc_fn_3464c816_000133_807fd51d+0x60>
  40cdee:	mov    QWORD PTR [rsp],0x0
  40cdf6:	mov    edi,0xca
  40cdfb:	mov    rsi,rbx
  40cdfe:	mov    edx,0x80
  40ce03:	mov    ecx,DWORD PTR [rcx]
  40ce05:	xor    r8d,r8d
  40ce08:	xor    r9d,r9d
  40ce0b:	xor    eax,eax
  40ce0d:	call   407070 <syscall@plt>
  40ce12:	jmp    40cdd0 <__swc_fn_3464c816_000133_807fd51d+0x60>
  40ce14:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ce1a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40ce20:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40ce26:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ce2c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ce32:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ce38:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ce3e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ce47:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ce50:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ce59:	add    rsp,0xc0
  40ce60:	pop    rsi
  40ce61:	pop    rdi
  40ce62:	pop    rbx
  40ce63:	ret
	...

000000000040ce70 <__swc_fn_3464c816_000136_d579ef75>:
  40ce70:	sub    rsp,0x8
  40ce74:	call   410520 <__swc_fn_3464c816_000134_10472836>
  40ce79:	add    rsp,0x8
  40ce7d:	ret
	...

000000000040ce80 <__swc_fn_3464c816_000139_e4a7a8b1>:
  40ce80:	push   rdi
  40ce81:	push   rsi
  40ce82:	sub    rsp,0xa8
  40ce89:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ce8f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ce95:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ce9b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cea1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cea7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cead:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ceb3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ceb9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cec2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cecb:	mov    edi,0x28
  40ced0:	xor    eax,eax
  40ced2:	call   4070d0 <malloc@plt>
  40ced7:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cedd:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cee3:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cee9:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ceef:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cef5:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cefb:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cf01:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cf07:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cf10:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cf19:	add    rsp,0xa8
  40cf20:	pop    rsi
  40cf21:	pop    rdi
  40cf22:	ret
	...

000000000040cf30 <__swc_fn_3464c816_000142_89a6ef72>:
  40cf30:	mov    QWORD PTR [r8],0x0
  40cf37:	cmp    rdx,0x10
  40cf3b:	jae    40cf40 <__swc_fn_3464c816_000142_89a6ef72+0x10>
  40cf3d:	xor    eax,eax
  40cf3f:	ret
  40cf40:	mov    eax,DWORD PTR [rcx]
  40cf42:	cmp    eax,0x42445753
  40cf48:	jne    40cf52 <__swc_fn_3464c816_000142_89a6ef72+0x22>
  40cf4a:	mov    eax,DWORD PTR [rcx+0x4]
  40cf4d:	cmp    eax,0x1
  40cf50:	je     40cf55 <__swc_fn_3464c816_000142_89a6ef72+0x25>
  40cf52:	xor    eax,eax
  40cf54:	ret
  40cf55:	mov    QWORD PTR [r8],rdx
  40cf58:	mov    rax,rcx
  40cf5b:	ret
  40cf5c:	add    BYTE PTR [rax],al
	...

000000000040cf60 <__swc_fn_3464c816_000145_32a1d6a2>:
  40cf60:	push   rbx
  40cf61:	sub    rsp,0xe0
  40cf68:	lea    rbx,[rsp+0x8]
  40cf6d:	vxorps xmm0,xmm0,xmm0
  40cf71:	vmovups YMMWORD PTR [rbx],ymm0
  40cf75:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40cf7a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40cf7f:	vzeroupper
  40cf82:	mov    DWORD PTR [rbx+0x60],0x0
  40cf89:	mov    r8,rbx
  40cf8c:	mov    rdx,rcx
  40cf8f:	nop
  40cf90:	mov    r9,rdx
  40cf93:	movabs rdx,0x6666666666666667
  40cf9d:	mov    rax,r9
  40cfa0:	imul   rdx
  40cfa3:	sar    rdx,0x2
  40cfa7:	mov    r10,rdx
  40cfaa:	shr    rdx,0x3f
  40cfae:	add    r10,rdx
  40cfb1:	mov    rdx,r10
  40cfb4:	imul   r11,r10,0xa
  40cfb8:	sub    r9,r11
  40cfbb:	mov    r11,QWORD PTR [rip+0x657e]        # 413540 <__swc_rdata_base_3464c816+0x430>
  40cfc2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40cfc7:	mov    BYTE PTR [r8],r9b
  40cfca:	lea    r9,[r8+0x1]
  40cfce:	mov    r8,r9
  40cfd1:	test   r10,r10
  40cfd4:	jne    40cf90 <__swc_fn_3464c816_000145_32a1d6a2+0x30>
  40cfd6:	test   rcx,rcx
  40cfd9:	jge    40cfe3 <__swc_fn_3464c816_000145_32a1d6a2+0x83>
  40cfdb:	mov    BYTE PTR [r9],0x2d
  40cfdf:	add    r8,0x1
  40cfe3:	mov    BYTE PTR [r8],0x0
  40cfe7:	sub    r8,0x1
  40cfeb:	mov    rax,rbx
  40cfee:	cmp    rax,r8
  40cff1:	jae    40d016 <__swc_fn_3464c816_000145_32a1d6a2+0xb6>
  40cff3:	cs nop WORD PTR [rax+rax*1+0x0]
  40cffd:	nop    DWORD PTR [rax]
  40d000:	mov    cl,BYTE PTR [r8]
  40d003:	mov    dl,BYTE PTR [rax]
  40d005:	mov    BYTE PTR [r8],dl
  40d008:	sub    r8,0x1
  40d00c:	mov    BYTE PTR [rax],cl
  40d00e:	inc    rax
  40d011:	cmp    rax,r8
  40d014:	jb     40d000 <__swc_fn_3464c816_000145_32a1d6a2+0xa0>
  40d016:	xor    eax,eax
  40d018:	test   rbx,rbx
  40d01b:	je     40d03e <__swc_fn_3464c816_000145_32a1d6a2+0xde>
  40d01d:	mov    rcx,rbx
  40d020:	mov    dl,BYTE PTR [rcx]
  40d022:	test   dl,dl
  40d024:	je     40d03e <__swc_fn_3464c816_000145_32a1d6a2+0xde>
  40d026:	cs nop WORD PTR [rax+rax*1+0x0]
  40d030:	add    rcx,0x1
  40d034:	add    rax,0x1
  40d038:	mov    dl,BYTE PTR [rcx]
  40d03a:	test   dl,dl
  40d03c:	jne    40d030 <__swc_fn_3464c816_000145_32a1d6a2+0xd0>
  40d03e:	mov    QWORD PTR [rbx+0xa8],rbx
  40d045:	mov    QWORD PTR [rbx+0xb0],rax
  40d04c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d054:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d05c:	lea    rcx,[rbx+0xb8]
  40d063:	call   410070 <__swc_fn_3464c816_000116_3f5cfdef>
  40d068:	add    rsp,0xe0
  40d06f:	pop    rbx
  40d070:	ret
	...

000000000040d080 <__swc_fn_3464c816_000148_365b4daf>:
  40d080:	vxorps xmm0,xmm0,xmm0
  40d084:	vmovups XMMWORD PTR [rcx],xmm0
  40d088:	mov    QWORD PTR [rcx+0x10],0x0
  40d090:	ret
	...

000000000040d0a0 <__swc_fn_3464c816_000151_365b4daf>:
  40d0a0:	vxorps xmm0,xmm0,xmm0
  40d0a4:	vmovups XMMWORD PTR [rcx],xmm0
  40d0a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d0ad:	vxorps xmm0,xmm0,xmm0
  40d0b1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d0b6:	vmovups xmm0,XMMWORD PTR [rip+0x657a]        # 413638 <__swc_rdata_base_3464c816+0x528>
  40d0be:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d0c3:	vxorps xmm0,xmm0,xmm0
  40d0c7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d0cc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d0d1:	mov    QWORD PTR [rcx+0x60],0x0
  40d0d9:	ret
  40d0da:	add    BYTE PTR [rax],al
  40d0dc:	add    BYTE PTR [rax],al
	...

000000000040d0e0 <__swc_fn_3464c816_000154_365b4daf>:
  40d0e0:	vxorps xmm0,xmm0,xmm0
  40d0e4:	vmovups XMMWORD PTR [rcx],xmm0
  40d0e8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d0ed:	vxorps xmm0,xmm0,xmm0
  40d0f1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d0f6:	vmovups xmm0,XMMWORD PTR [rip+0x6662]        # 413760 <__swc_rdata_base_3464c816+0x650>
  40d0fe:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d103:	vxorps xmm0,xmm0,xmm0
  40d107:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d10c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d111:	vxorps xmm0,xmm0,xmm0
  40d115:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40d11a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40d11f:	vxorps xmm0,xmm0,xmm0
  40d123:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40d12b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40d133:	vxorps xmm0,xmm0,xmm0
  40d137:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40d13f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40d147:	vxorps xmm0,xmm0,xmm0
  40d14b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40d153:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40d15b:	mov    QWORD PTR [rcx+0xe0],0x0
  40d166:	ret
	...

000000000040d170 <__swc_fn_3464c816_000157_3495a3ca>:
  40d170:	push   rbx
  40d171:	mov    rbx,rcx
  40d174:	call   411ab0 <__swc_fn_3464c816_000158_31e09513>
  40d179:	mov    rax,QWORD PTR [rbx+0x10]
  40d17d:	test   rax,rax
  40d180:	je     40d191 <__swc_fn_3464c816_000157_3495a3ca+0x21>
  40d182:	mov    rcx,rbx
  40d185:	mov    rdx,rax
  40d188:	mov    r8,QWORD PTR [rbx+0x18]
  40d18c:	call   409e90 <__swc_fn_3464c816_000156_9e2052d6>
  40d191:	vxorps xmm0,xmm0,xmm0
  40d195:	vmovups XMMWORD PTR [rbx],xmm0
  40d199:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d19e:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d1a3:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d1a8:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d1ad:	mov    QWORD PTR [rbx+0x50],0x0
  40d1b5:	pop    rbx
  40d1b6:	ret
	...

000000000040d1c0 <__swc_fn_3464c816_000160_dfca9093>:
  40d1c0:	sub    rsp,0x10
  40d1c4:	mov    eax,r8d
  40d1c7:	mov    r8d,r9d
  40d1ca:	test   r9d,r9d
  40d1cd:	jne    40d1e6 <__swc_fn_3464c816_000160_dfca9093+0x26>
  40d1cf:	vmovups xmm0,XMMWORD PTR [rip+0x6641]        # 413818 <__swc_rdata_base_3464c816+0x708>
  40d1d7:	vmovups XMMWORD PTR [r10],xmm0
  40d1dc:	mov    eax,0x1
  40d1e1:	add    rsp,0x10
  40d1e5:	ret
  40d1e6:	mov    r9,r8
  40d1e9:	cmp    r8,rax
  40d1ec:	jb     40d1f3 <__swc_fn_3464c816_000160_dfca9093+0x33>
  40d1ee:	cmp    r9,rdx
  40d1f1:	jb     40d1fa <__swc_fn_3464c816_000160_dfca9093+0x3a>
  40d1f3:	xor    eax,eax
  40d1f5:	add    rsp,0x10
  40d1f9:	ret
  40d1fa:	xor    eax,eax
  40d1fc:	lea    r8,[r9+rax*1]
  40d200:	cmp    r8,rdx
  40d203:	jae    40d233 <__swc_fn_3464c816_000160_dfca9093+0x73>
  40d205:	cs nop WORD PTR [rax+rax*1+0x0]
  40d20f:	cs nop WORD PTR [rax+rax*1+0x0]
  40d219:	nop    DWORD PTR [rax+0x0]
  40d220:	cmp    BYTE PTR [rcx+r8*1],0x0
  40d225:	je     40d233 <__swc_fn_3464c816_000160_dfca9093+0x73>
  40d227:	inc    rax
  40d22a:	lea    r8,[r9+rax*1]
  40d22e:	cmp    r8,rdx
  40d231:	jb     40d220 <__swc_fn_3464c816_000160_dfca9093+0x60>
  40d233:	cmp    r8,rdx
  40d236:	jne    40d23f <__swc_fn_3464c816_000160_dfca9093+0x7f>
  40d238:	xor    eax,eax
  40d23a:	add    rsp,0x10
  40d23e:	ret
  40d23f:	add    rcx,r9
  40d242:	mov    QWORD PTR [rsp],rcx
  40d246:	mov    QWORD PTR [rsp+0x8],rax
  40d24b:	vmovups xmm0,XMMWORD PTR [rsp]
  40d250:	vmovups XMMWORD PTR [r10],xmm0
  40d255:	mov    eax,0x1
  40d25a:	add    rsp,0x10
  40d25e:	ret
	...

000000000040d260 <__swc_fn_3464c816_000163_3a7aae74>:
  40d260:	push   rbp
  40d261:	push   rbx
  40d262:	push   rsi
  40d263:	push   rdi
  40d264:	push   r12
  40d266:	push   r13
  40d268:	push   r14
  40d26a:	push   r15
  40d26c:	sub    rsp,0x10
  40d270:	mov    rbp,rsp
  40d273:	vmovups XMMWORD PTR [rsp],xmm6
  40d278:	sub    rsp,0x50
  40d27c:	mov    rbx,rsp
  40d27f:	mov    rsi,r8
  40d282:	mov    QWORD PTR [rsp+0x30],r8
  40d287:	mov    rdi,rcx
  40d28a:	mov    QWORD PTR [rsp+0x38],rcx
  40d28f:	mov    r12,rdx
  40d292:	xor    r13b,r13b
  40d295:	mov    r14,QWORD PTR [rdi+0x8]
  40d299:	mov    QWORD PTR [rsp+0x40],r14
  40d29e:	xor    r15d,r15d
  40d2a1:	test   r14,r14
  40d2a4:	jbe    40d4fe <__swc_fn_3464c816_000163_3a7aae74+0x29e>
  40d2aa:	mov    r14,QWORD PTR [rdi]
  40d2ad:	mov    rax,QWORD PTR [rsp+0x40]
  40d2b2:	mov    QWORD PTR [rsp+0x48],r14
  40d2b7:	vmovups xmm6,XMMWORD PTR [rip+0x6179]        # 413438 <__swc_rdata_base_3464c816+0x328>
  40d2bf:	nop
  40d2c0:	cmp    QWORD PTR [r14+r15*8],0x0
  40d2c5:	jne    40d2cf <__swc_fn_3464c816_000163_3a7aae74+0x6f>
  40d2c7:	mov    r14,rax
  40d2ca:	jmp    40d4de <__swc_fn_3464c816_000163_3a7aae74+0x27e>
  40d2cf:	mov    rcx,QWORD PTR [rdi]
  40d2d2:	mov    rdx,QWORD PTR [rcx+r15*8]
  40d2d6:	mov    rdi,rbx
  40d2d9:	mov    rcx,rdi
  40d2dc:	sub    rsp,0x8
  40d2e0:	mov    r14,rax
  40d2e3:	call   409f10 <__swc_fn_3464c816_000162_61e293bf>
  40d2e8:	add    rsp,0x8
  40d2ec:	mov    al,BYTE PTR [rbx]
  40d2ee:	test   al,al
  40d2f0:	je     40d4de <__swc_fn_3464c816_000163_3a7aae74+0x27e>
  40d2f6:	mov    al,BYTE PTR [rbx+0x1]
  40d2f9:	test   al,al
  40d2fb:	jne    40d306 <__swc_fn_3464c816_000163_3a7aae74+0xa6>
  40d2fd:	test   sil,sil
  40d300:	je     40d4de <__swc_fn_3464c816_000163_3a7aae74+0x27e>
  40d306:	test   r13b,r13b
  40d309:	jne    40d3c7 <__swc_fn_3464c816_000163_3a7aae74+0x167>
  40d30f:	test   r12,r12
  40d312:	je     40d3c7 <__swc_fn_3464c816_000163_3a7aae74+0x167>
  40d318:	mov    al,BYTE PTR [rbx+0x1]
  40d31b:	test   al,al
  40d31d:	je     40d4de <__swc_fn_3464c816_000163_3a7aae74+0x27e>
  40d323:	mov    eax,DWORD PTR [rbx+0x28]
  40d326:	cmp    DWORD PTR [r12+0x20],eax
  40d32b:	jne    40d4de <__swc_fn_3464c816_000163_3a7aae74+0x27e>
  40d331:	mov    rax,QWORD PTR [r12]
  40d335:	mov    rcx,QWORD PTR [r12+0x8]
  40d33a:	cmp    QWORD PTR [rbx+0x20],rcx
  40d33e:	jne    40d4de <__swc_fn_3464c816_000163_3a7aae74+0x27e>
  40d344:	mov    cl,0x1
  40d346:	test   rax,rax
  40d349:	je     40d3b2 <__swc_fn_3464c816_000163_3a7aae74+0x152>
  40d34f:	mov    rdx,QWORD PTR [rbx+0x20]
  40d353:	xor    r8d,r8d
  40d356:	test   rdx,rdx
  40d359:	jbe    40d3b2 <__swc_fn_3464c816_000163_3a7aae74+0x152>
  40d35b:	mov    r9,QWORD PTR [rbx+0x18]
  40d35f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40d364:	cs nop WORD PTR [rax+rax*1+0x0]
  40d36e:	xchg   ax,ax
  40d370:	mov    r10b,BYTE PTR [rax+r8*1]
  40d374:	cmp    BYTE PTR [r9+r8*1],r10b
  40d378:	je     40d3a9 <__swc_fn_3464c816_000163_3a7aae74+0x149>
  40d37a:	vmovq  r10,xmm0
  40d37f:	cmp    BYTE PTR [r10+r8*1],0x5c
  40d384:	jne    40d38d <__swc_fn_3464c816_000163_3a7aae74+0x12d>
  40d386:	cmp    BYTE PTR [rax+r8*1],0x2f
  40d38b:	je     40d3a9 <__swc_fn_3464c816_000163_3a7aae74+0x149>
  40d38d:	vmovq  r10,xmm0
  40d392:	cmp    BYTE PTR [r10+r8*1],0x2f
  40d397:	jne    40d3a0 <__swc_fn_3464c816_000163_3a7aae74+0x140>
  40d399:	cmp    BYTE PTR [rax+r8*1],0x5c
  40d39e:	je     40d3a9 <__swc_fn_3464c816_000163_3a7aae74+0x149>
  40d3a0:	xor    eax,eax
  40d3a2:	movzx  eax,al
  40d3a5:	mov    cl,al
  40d3a7:	jmp    40d3b2 <__swc_fn_3464c816_000163_3a7aae74+0x152>
  40d3a9:	add    r8,0x1
  40d3ad:	cmp    r8,rdx
  40d3b0:	jb     40d370 <__swc_fn_3464c816_000163_3a7aae74+0x110>
  40d3b2:	test   cl,cl
  40d3b4:	je     40d4de <__swc_fn_3464c816_000163_3a7aae74+0x27e>
  40d3ba:	mov    eax,0x1
  40d3bf:	mov    r13b,al
  40d3c2:	jmp    40d4de <__swc_fn_3464c816_000163_3a7aae74+0x27e>
  40d3c7:	mov    r13b,0x1
  40d3ca:	sub    rsp,0x20
  40d3ce:	mov    rax,rsp
  40d3d1:	lea    rcx,[rdi+0x8]
  40d3d5:	mov    QWORD PTR [rax],rcx
  40d3d8:	lea    rsi,[rip+0x5f31]        # 413310 <__swc_rdata_base_3464c816+0x200>
  40d3df:	mov    QWORD PTR [rax+0x8],rsi
  40d3e3:	mov    QWORD PTR [rax+0x10],rsp
  40d3e7:	mov    QWORD PTR [rax+0x18],0x1
  40d3ef:	lea    rcx,[rsp+0x10]
  40d3f4:	sub    rsp,0x8
  40d3f8:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  40d3fd:	add    rsp,0x8
  40d401:	add    rsp,0x20
  40d405:	mov    al,BYTE PTR [rbx+0x1]
  40d408:	test   al,al
  40d40a:	je     40d4a7 <__swc_fn_3464c816_000163_3a7aae74+0x247>
  40d410:	lea    rax,[rip+0x64a1]        # 4138b8 <__swc_rdata_base_3464c816+0x7a8>
  40d417:	sub    rsp,0x20
  40d41b:	mov    rcx,rsp
  40d41e:	mov    QWORD PTR [rcx],rax
  40d421:	mov    QWORD PTR [rcx+0x8],rsi
  40d425:	mov    QWORD PTR [rcx+0x10],rsp
  40d429:	mov    QWORD PTR [rcx+0x18],0x1
  40d431:	lea    rcx,[rsp+0x10]
  40d436:	sub    rsp,0x8
  40d43a:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  40d43f:	add    rsp,0x8
  40d443:	add    rsp,0x20
  40d447:	mov    eax,DWORD PTR [rbx+0x28]
  40d44a:	sub    rsp,0x60
  40d44e:	mov    rcx,rsp
  40d451:	lea    rdx,[rdi+0x18]
  40d455:	mov    QWORD PTR [rcx+0x18],rdx
  40d459:	mov    QWORD PTR [rcx+0x20],rsi
  40d45d:	vmovups XMMWORD PTR [rcx],xmm6
  40d461:	mov    QWORD PTR [rcx+0x28],rsp
  40d465:	mov    QWORD PTR [rcx+0x30],rsi
  40d469:	mov    DWORD PTR [rcx+0x10],eax
  40d46c:	lea    rax,[rsp+0x10]
  40d471:	mov    QWORD PTR [rcx+0x38],rax
  40d475:	lea    rax,[rip+0x5f54]        # 4133d0 <__swc_rdata_base_3464c816+0x2c0>
  40d47c:	mov    QWORD PTR [rcx+0x40],rax
  40d480:	lea    rax,[rsp+0x18]
  40d485:	mov    QWORD PTR [rcx+0x48],rax
  40d489:	mov    QWORD PTR [rcx+0x50],0x3
  40d491:	lea    rcx,[rsp+0x48]
  40d496:	sub    rsp,0x8
  40d49a:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  40d49f:	add    rsp,0x8
  40d4a3:	add    rsp,0x60
  40d4a7:	lea    rax,[rip+0x5eba]        # 413368 <__swc_rdata_base_3464c816+0x258>
  40d4ae:	sub    rsp,0x20
  40d4b2:	mov    rcx,rsp
  40d4b5:	mov    QWORD PTR [rcx],rax
  40d4b8:	mov    QWORD PTR [rcx+0x8],rsi
  40d4bc:	mov    QWORD PTR [rcx+0x10],rsp
  40d4c0:	mov    QWORD PTR [rcx+0x18],0x1
  40d4c8:	lea    rcx,[rsp+0x10]
  40d4cd:	sub    rsp,0x8
  40d4d1:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  40d4d6:	add    rsp,0x8
  40d4da:	add    rsp,0x20
  40d4de:	add    r15,0x1
  40d4e2:	cmp    r15,r14
  40d4e5:	jae    40d4fe <__swc_fn_3464c816_000163_3a7aae74+0x29e>
  40d4e7:	mov    rsi,QWORD PTR [rsp+0x30]
  40d4ec:	mov    rdi,QWORD PTR [rsp+0x38]
  40d4f1:	mov    rax,r14
  40d4f4:	mov    r14,QWORD PTR [rsp+0x48]
  40d4f9:	jmp    40d2c0 <__swc_fn_3464c816_000163_3a7aae74+0x60>
  40d4fe:	add    rsp,0x50
  40d502:	vmovups xmm6,XMMWORD PTR [rsp]
  40d507:	add    rsp,0x10
  40d50b:	pop    r15
  40d50d:	pop    r14
  40d50f:	pop    r13
  40d511:	pop    r12
  40d513:	pop    rdi
  40d514:	pop    rsi
  40d515:	pop    rbx
  40d516:	pop    rbp
  40d517:	ret
	...

000000000040d520 <__swc_fn_3464c816_000166_c370e18e>:
  40d520:	sub    rsp,0x8
  40d524:	call   4102f0 <__swc_fn_3464c816_000125_7a81492f>
  40d529:	add    rsp,0x8
  40d52d:	ret
	...

000000000040d530 <__swc_fn_3464c816_000169_4694b8ad>:
  40d530:	push   rsi
  40d531:	sub    rsp,0x30
  40d535:	lea    rsi,[rip+0x19864]        # 426da0 <__swc_bss_base_3464c816+0x2d60>
  40d53c:	mov    rax,QWORD PTR [rsi]
  40d53f:	test   rax,rax
  40d542:	je     40d54a <__swc_fn_3464c816_000169_4694b8ad+0x1a>
  40d544:	add    rsp,0x30
  40d548:	pop    rsi
  40d549:	ret
  40d54a:	mov    ecx,0x2
  40d54f:	mov    edx,0x8020
  40d554:	call   40f990 <__swc_fn_3464c816_000107_c8d4a68e>
  40d559:	test   rax,rax
  40d55c:	jne    40d56d <__swc_fn_3464c816_000169_4694b8ad+0x3d>
  40d55e:	mov    QWORD PTR [rsp+0x18],rax
  40d563:	call   40c9d0 <__swc_fn_3464c816_000118_591530fe>
  40d568:	mov    rax,QWORD PTR [rsp+0x18]
  40d56d:	mov    rcx,rax
  40d570:	xchg   QWORD PTR [rsi],rcx
  40d573:	add    rsp,0x30
  40d577:	pop    rsi
  40d578:	ret
  40d579:	add    BYTE PTR [rax],al
  40d57b:	add    BYTE PTR [rax],al
  40d57d:	add    BYTE PTR [rax],al
	...

000000000040d580 <__swc_fn_3464c816_000172_1751ecdd>:
  40d580:	push   rsi
  40d581:	test   r8,r8
  40d584:	jne    40d588 <__swc_fn_3464c816_000172_1751ecdd+0x8>
  40d586:	pop    rsi
  40d587:	ret
  40d588:	lea    rax,[rcx+0x18]
  40d58c:	mov    r10,QWORD PTR [rax]
  40d58f:	lea    r11,[r10+0x1]
  40d593:	mov    QWORD PTR [rax],r11
  40d596:	mov    r11,rdx
  40d599:	not    rdx
  40d59c:	lea    rsi,[r8-0x1]
  40d5a0:	cmp    rsi,rdx
  40d5a3:	ja     40d5c3 <__swc_fn_3464c816_000172_1751ecdd+0x43>
  40d5a5:	lea    rdx,[r11+r8*1]
  40d5a9:	dec    rdx
  40d5ac:	shr    rdx,0x6
  40d5b0:	mov    r8,r11
  40d5b3:	shr    r8,0x6
  40d5b7:	mov    rsi,rdx
  40d5ba:	sub    rsi,r8
  40d5bd:	cmp    rsi,0x8
  40d5c1:	jb     40d5d9 <__swc_fn_3464c816_000172_1751ecdd+0x59>
  40d5c3:	lea    rcx,[rcx+0x10]
  40d5c7:	mov    rdx,QWORD PTR [rcx]
  40d5ca:	add    rdx,r9
  40d5cd:	mov    QWORD PTR [rcx],rdx
  40d5d0:	lea    rcx,[r10+0x2]
  40d5d4:	mov    QWORD PTR [rax],rcx
  40d5d7:	pop    rsi
  40d5d8:	ret
  40d5d9:	shr    r11,0x6
  40d5dd:	nop    DWORD PTR [rax]
  40d5e0:	cmp    r11,rdx
  40d5e3:	ja     40d623 <__swc_fn_3464c816_000172_1751ecdd+0xa3>
  40d5e5:	jmp    40d5f6 <__swc_fn_3464c816_000172_1751ecdd+0x76>
  40d5e7:	nop    WORD PTR [rax+rax*1+0x0]
  40d5f0:	add    r11,0x1
  40d5f4:	jmp    40d5e0 <__swc_fn_3464c816_000172_1751ecdd+0x60>
  40d5f6:	mov    r8,r11
  40d5f9:	shr    r8,0xc
  40d5fd:	mov    rsi,r11
  40d600:	xor    rsi,r8
  40d603:	mov    r8,r11
  40d606:	shr    r8,0x18
  40d60a:	xor    rsi,r8
  40d60d:	and    esi,0xfff
  40d613:	lea    r8,[rcx+rsi*8+0x20]
  40d618:	mov    rsi,QWORD PTR [r8]
  40d61b:	add    rsi,r9
  40d61e:	mov    QWORD PTR [r8],rsi
  40d621:	jmp    40d5f0 <__swc_fn_3464c816_000172_1751ecdd+0x70>
  40d623:	lea    rcx,[r10+0x2]
  40d627:	mov    QWORD PTR [rax],rcx
  40d62a:	pop    rsi
  40d62b:	ret
	...

000000000040d640 <__swc_fn_3464c816_000175_7f24d040>:
  40d640:	push   rbp
  40d641:	push   rbx
  40d642:	push   rsi
  40d643:	push   rdi
  40d644:	push   r12
  40d646:	push   r13
  40d648:	push   r15
  40d64a:	push   r14
  40d64c:	sub    rsp,0x50
  40d650:	mov    rbp,rsp
  40d653:	vmovups XMMWORD PTR [rsp],xmm6
  40d658:	vmovups XMMWORD PTR [rsp+0x10],xmm7
  40d65e:	vmovups XMMWORD PTR [rsp+0x20],xmm8
  40d664:	vmovups XMMWORD PTR [rsp+0x30],xmm9
  40d66a:	vmovups XMMWORD PTR [rsp+0x40],xmm10
  40d670:	sub    rsp,0x70
  40d674:	mov    rbx,rsp
  40d677:	mov    ecx,0x1000000
  40d67c:	sub    rsp,0x8
  40d680:	call   411fc0 <__swc_fn_3464c816_000176_2744b483>
  40d685:	add    rsp,0x8
  40d689:	mov    rsi,rax
  40d68c:	mov    QWORD PTR [rsp+0x50],rax
  40d691:	xor    ecx,ecx
  40d693:	cs nop WORD PTR [rax+rax*1+0x0]
  40d69d:	cs nop WORD PTR [rax+rax*1+0x0]
  40d6a7:	nop    WORD PTR [rax+rax*1+0x0]
  40d6b0:	mov    r8,QWORD PTR [rip+0x14959]        # 422010 <__swc_data_base_3464c816+0x10>
  40d6b7:	imul   r8,r8,0x41a7
  40d6be:	movabs rdx,0x200000005
  40d6c8:	mov    r11,rax
  40d6cb:	mov    rax,r8
  40d6ce:	mul    rdx
  40d6d1:	mov    r9,rdx
  40d6d4:	mov    rdx,r8
  40d6d7:	sub    rdx,r9
  40d6da:	shr    rdx,1
  40d6dd:	add    rdx,r9
  40d6e0:	shr    rdx,0x1e
  40d6e4:	imul   r9,rdx,0x7fffffff
  40d6eb:	sub    r8,r9
  40d6ee:	mov    QWORD PTR [rip+0x1491b],r8        # 422010 <__swc_data_base_3464c816+0x10>
  40d6f5:	mov    DWORD PTR [rsi+rcx*4],r8d
  40d6f9:	add    rcx,0x1
  40d6fd:	mov    r8,QWORD PTR [rip+0x1490c]        # 422010 <__swc_data_base_3464c816+0x10>
  40d704:	imul   r8,r8,0x41a7
  40d70b:	movabs rdx,0x200000005
  40d715:	mov    rax,r8
  40d718:	mul    rdx
  40d71b:	mov    r9,rdx
  40d71e:	mov    rax,r11
  40d721:	mov    rdx,r8
  40d724:	sub    rdx,r9
  40d727:	shr    rdx,1
  40d72a:	add    rdx,r9
  40d72d:	shr    rdx,0x1e
  40d731:	imul   rdx,rdx,0x7fffffff
  40d738:	sub    r8,rdx
  40d73b:	mov    QWORD PTR [rip+0x148ce],r8        # 422010 <__swc_data_base_3464c816+0x10>
  40d742:	mov    DWORD PTR [rsi+rcx*4],r8d
  40d746:	add    rcx,0x1
  40d74a:	cmp    rcx,0x400000
  40d751:	jb     40d6b0 <__swc_fn_3464c816_000175_7f24d040+0x70>
  40d757:	mov    rcx,QWORD PTR [rip+0x148b2]        # 422010 <__swc_data_base_3464c816+0x10>
  40d75e:	imul   rcx,rcx,0x41a7
  40d765:	movabs rdx,0x200000005
  40d76f:	mov    rax,rcx
  40d772:	mul    rdx
  40d775:	mov    r8,rdx
  40d778:	mov    rdx,rcx
  40d77b:	sub    rdx,r8
  40d77e:	shr    rdx,1
  40d781:	add    rdx,r8
  40d784:	shr    rdx,0x1e
  40d788:	imul   r8,rdx,0x7fffffff
  40d78f:	mov    rdi,rcx
  40d792:	sub    rdi,r8
  40d795:	mov    QWORD PTR [rip+0x14874],rdi        # 422010 <__swc_data_base_3464c816+0x10>
  40d79c:	imul   rcx,rdi,0x41a7
  40d7a3:	movabs rdx,0x200000005
  40d7ad:	mov    rax,rcx
  40d7b0:	mul    rdx
  40d7b3:	mov    r8,rdx
  40d7b6:	mov    rdx,rcx
  40d7b9:	sub    rdx,r8
  40d7bc:	shr    rdx,1
  40d7bf:	add    rdx,r8
  40d7c2:	shr    rdx,0x1e
  40d7c6:	imul   rdx,rdx,0x7fffffff
  40d7cd:	mov    r12,rcx
  40d7d0:	sub    r12,rdx
  40d7d3:	mov    QWORD PTR [rip+0x14836],r12        # 422010 <__swc_data_base_3464c816+0x10>
  40d7da:	imul   rcx,r12,0x41a7
  40d7e1:	movabs rdx,0x200000005
  40d7eb:	mov    rax,rcx
  40d7ee:	mul    rdx
  40d7f1:	mov    r8,rdx
  40d7f4:	mov    rdx,rcx
  40d7f7:	sub    rdx,r8
  40d7fa:	shr    rdx,1
  40d7fd:	add    rdx,r8
  40d800:	shr    rdx,0x1e
  40d804:	imul   rdx,rdx,0x7fffffff
  40d80b:	mov    r13,rcx
  40d80e:	sub    r13,rdx
  40d811:	mov    QWORD PTR [rip+0x147f8],r13        # 422010 <__swc_data_base_3464c816+0x10>
  40d818:	imul   rcx,r13,0x41a7
  40d81f:	movabs rdx,0x200000005
  40d829:	mov    rax,rcx
  40d82c:	mul    rdx
  40d82f:	mov    r8,rdx
  40d832:	mov    rdx,rcx
  40d835:	sub    rdx,r8
  40d838:	shr    rdx,1
  40d83b:	add    rdx,r8
  40d83e:	shr    rdx,0x1e
  40d842:	imul   rdx,rdx,0x7fffffff
  40d849:	mov    r14,rcx
  40d84c:	sub    r14,rdx
  40d84f:	mov    QWORD PTR [rip+0x147ba],r14        # 422010 <__swc_data_base_3464c816+0x10>
  40d856:	imul   rcx,r14,0x41a7
  40d85d:	movabs rdx,0x200000005
  40d867:	mov    rax,rcx
  40d86a:	mul    rdx
  40d86d:	mov    r8,rdx
  40d870:	mov    rdx,rcx
  40d873:	sub    rdx,r8
  40d876:	shr    rdx,1
  40d879:	add    rdx,r8
  40d87c:	shr    rdx,0x1e
  40d880:	imul   rdx,rdx,0x7fffffff
  40d887:	mov    r15,rcx
  40d88a:	sub    r15,rdx
  40d88d:	mov    QWORD PTR [rip+0x1477c],r15        # 422010 <__swc_data_base_3464c816+0x10>
  40d894:	imul   rcx,r15,0x41a7
  40d89b:	movabs rdx,0x200000005
  40d8a5:	mov    rax,rcx
  40d8a8:	mul    rdx
  40d8ab:	mov    r8,rdx
  40d8ae:	mov    rdx,rcx
  40d8b1:	sub    rdx,r8
  40d8b4:	shr    rdx,1
  40d8b7:	add    rdx,r8
  40d8ba:	shr    rdx,0x1e
  40d8be:	imul   rdx,rdx,0x7fffffff
  40d8c5:	mov    rsi,rcx
  40d8c8:	sub    rsi,rdx
  40d8cb:	mov    QWORD PTR [rip+0x1473e],rsi        # 422010 <__swc_data_base_3464c816+0x10>
  40d8d2:	imul   rcx,rsi,0x41a7
  40d8d9:	movabs rdx,0x200000005
  40d8e3:	mov    rax,rcx
  40d8e6:	mul    rdx
  40d8e9:	mov    r8,rdx
  40d8ec:	mov    rdx,rcx
  40d8ef:	sub    rdx,r8
  40d8f2:	shr    rdx,1
  40d8f5:	add    rdx,r8
  40d8f8:	shr    rdx,0x1e
  40d8fc:	imul   rdx,rdx,0x7fffffff
  40d903:	mov    QWORD PTR [rsp+0x58],rsi
  40d908:	mov    rsi,rcx
  40d90b:	sub    rsi,rdx
  40d90e:	mov    QWORD PTR [rip+0x146fb],rsi        # 422010 <__swc_data_base_3464c816+0x10>
  40d915:	imul   rcx,rsi,0x41a7
  40d91c:	movabs rdx,0x200000005
  40d926:	mov    rax,rcx
  40d929:	mul    rdx
  40d92c:	mov    r8,rdx
  40d92f:	mov    rdx,rcx
  40d932:	sub    rdx,r8
  40d935:	shr    rdx,1
  40d938:	add    rdx,r8
  40d93b:	shr    rdx,0x1e
  40d93f:	imul   rdx,rdx,0x7fffffff
  40d946:	mov    QWORD PTR [rsp+0x60],rsi
  40d94b:	mov    rsi,rcx
  40d94e:	sub    rsi,rdx
  40d951:	mov    QWORD PTR [rip+0x146b8],rsi        # 422010 <__swc_data_base_3464c816+0x10>
  40d958:	mov    QWORD PTR [rbx],0x0
  40d95f:	mov    rcx,QWORD PTR [rip+0x146aa]        # 422010 <__swc_data_base_3464c816+0x10>
  40d966:	imul   rcx,rcx,0x41a7
  40d96d:	movabs rdx,0x200000005
  40d977:	mov    rax,rcx
  40d97a:	mul    rdx
  40d97d:	mov    r8,rdx
  40d980:	mov    rdx,rcx
  40d983:	sub    rdx,r8
  40d986:	shr    rdx,1
  40d989:	add    rdx,r8
  40d98c:	shr    rdx,0x1e
  40d990:	imul   r8,rdx,0x7fffffff
  40d997:	mov    QWORD PTR [rsp+0x68],rsi
  40d99c:	mov    rsi,rcx
  40d99f:	sub    rsi,r8
  40d9a2:	mov    QWORD PTR [rip+0x14667],rsi        # 422010 <__swc_data_base_3464c816+0x10>
  40d9a9:	mov    DWORD PTR [rbx],esi
  40d9ab:	mov    rcx,QWORD PTR [rip+0x1465e]        # 422010 <__swc_data_base_3464c816+0x10>
  40d9b2:	imul   rcx,rcx,0x41a7
  40d9b9:	movabs rdx,0x200000005
  40d9c3:	mov    rax,rcx
  40d9c6:	mul    rdx
  40d9c9:	mov    r8,rdx
  40d9cc:	mov    rdx,rcx
  40d9cf:	sub    rdx,r8
  40d9d2:	shr    rdx,1
  40d9d5:	add    rdx,r8
  40d9d8:	shr    rdx,0x1e
  40d9dc:	imul   r8,rdx,0x7fffffff
  40d9e3:	mov    rsi,rcx
  40d9e6:	sub    rsi,r8
  40d9e9:	mov    QWORD PTR [rip+0x14620],rsi        # 422010 <__swc_data_base_3464c816+0x10>
  40d9f0:	mov    DWORD PTR [rbx+0x4],esi
  40d9f3:	mov    rcx,QWORD PTR [rip+0x14616]        # 422010 <__swc_data_base_3464c816+0x10>
  40d9fa:	imul   rcx,rcx,0x41a7
  40da01:	movabs rdx,0x200000005
  40da0b:	mov    rax,rcx
  40da0e:	mul    rdx
  40da11:	mov    r8,rdx
  40da14:	mov    rdx,rcx
  40da17:	sub    rdx,r8
  40da1a:	shr    rdx,1
  40da1d:	add    rdx,r8
  40da20:	shr    rdx,0x1e
  40da24:	imul   r8,rdx,0x7fffffff
  40da2b:	mov    rsi,rcx
  40da2e:	sub    rsi,r8
  40da31:	mov    QWORD PTR [rip+0x145d8],rsi        # 422010 <__swc_data_base_3464c816+0x10>
  40da38:	sub    rsp,0x8
  40da3c:	call   40a350 <__swc_fn_3464c816_000177_1ca87929>
  40da41:	add    rsp,0x8
  40da45:	vmovups xmm6,xmm0
  40da49:	lea    rax,[rbx+0xc]
  40da4d:	vxorps xmm0,xmm0,xmm0
  40da51:	vmovups YMMWORD PTR [rbx+0xc],ymm0
  40da56:	vmovups YMMWORD PTR [rbx+0x2c],ymm0
  40da5b:	vzeroupper
  40da5e:	mov    DWORD PTR [rax],0x61707865
  40da64:	mov    DWORD PTR [rax+0x4],0x3320646e
  40da6b:	mov    DWORD PTR [rax+0x8],0x79622d32
  40da72:	mov    DWORD PTR [rax+0xc],0x6b206574
  40da79:	mov    DWORD PTR [rbx+0x1c],edi
  40da7c:	mov    DWORD PTR [rbx+0x20],r12d
  40da80:	mov    DWORD PTR [rbx+0x24],r13d
  40da84:	mov    DWORD PTR [rbx+0x28],r14d
  40da88:	mov    DWORD PTR [rbx+0x2c],r15d
  40da8c:	mov    rax,QWORD PTR [rsp+0x58]
  40da91:	mov    DWORD PTR [rbx+0x30],eax
  40da94:	mov    rax,QWORD PTR [rsp+0x60]
  40da99:	mov    DWORD PTR [rbx+0x34],eax
  40da9c:	mov    rax,QWORD PTR [rsp+0x68]
  40daa1:	mov    DWORD PTR [rbx+0x38],eax
  40daa4:	mov    eax,DWORD PTR [rbx]
  40daa6:	mov    DWORD PTR [rbx+0x40],eax
  40daa9:	mov    eax,DWORD PTR [rbx+0x4]
  40daac:	mov    DWORD PTR [rbx+0x44],eax
  40daaf:	mov    DWORD PTR [rbx+0x48],esi
  40dab2:	xor    eax,eax
  40dab4:	mov    ecx,0x1
  40dab9:	vmovups xmm0,XMMWORD PTR [rip+0x5eff]        # 4139c0 <__swc_rdata_base_3464c816+0x8b0>
  40dac1:	mov    rsi,QWORD PTR [rsp+0x50]
  40dac6:	vmovups xmm1,XMMWORD PTR [rip+0x5f02]        # 4139d0 <__swc_rdata_base_3464c816+0x8c0>
  40dace:	cmp    rax,0x400000
  40dad5:	jae    40dc3b <__swc_fn_3464c816_000175_7f24d040+0x5fb>
  40dadb:	nop    DWORD PTR [rax+rax*1+0x0]
  40dae0:	mov    DWORD PTR [rbx+0x3c],ecx
  40dae3:	vmovups xmm3,XMMWORD PTR [rbx+0xc]
  40dae8:	vmovups xmm4,XMMWORD PTR [rbx+0x1c]
  40daed:	vmovups xmm5,XMMWORD PTR [rbx+0x2c]
  40daf2:	vmovups xmm2,XMMWORD PTR [rbx+0x3c]
  40daf7:	xor    edx,edx
  40daf9:	nop    DWORD PTR [rax+0x0]
  40db00:	vpaddd xmm3,xmm3,xmm4
  40db04:	vpxor  xmm2,xmm2,xmm3
  40db08:	vpshufb xmm2,xmm2,xmm0
  40db0d:	vpaddd xmm5,xmm5,xmm2
  40db11:	vpxor  xmm4,xmm4,xmm5
  40db15:	vpslld xmm7,xmm4,0xc
  40db1a:	vpsrld xmm4,xmm4,0x14
  40db1f:	vpor   xmm4,xmm7,xmm4
  40db23:	vpaddd xmm3,xmm3,xmm4
  40db27:	vpshufd xmm7,xmm3,0x39
  40db2c:	vpshufd xmm2,xmm2,0x39
  40db31:	vpxor  xmm2,xmm2,xmm7
  40db35:	vpshufb xmm2,xmm2,xmm1
  40db3a:	vpshufd xmm5,xmm5,0x39
  40db3f:	vpaddd xmm5,xmm5,xmm2
  40db43:	vpshufd xmm4,xmm4,0x39
  40db48:	vpxor  xmm4,xmm4,xmm5
  40db4c:	vpslld xmm7,xmm4,0x7
  40db51:	vpsrld xmm4,xmm4,0x19
  40db56:	vpor   xmm4,xmm7,xmm4
  40db5a:	vpaddd xmm3,xmm3,xmm4
  40db5e:	vpshufd xmm2,xmm2,0x4e
  40db63:	vpxor  xmm2,xmm2,xmm3
  40db67:	vpshufb xmm2,xmm2,xmm0
  40db6c:	vpshufd xmm5,xmm5,0x39
  40db71:	vpaddd xmm5,xmm5,xmm2
  40db75:	vpxor  xmm4,xmm4,xmm5
  40db79:	vpslld xmm7,xmm4,0xc
  40db7e:	vpsrld xmm4,xmm4,0x14
  40db83:	vpor   xmm4,xmm7,xmm4
  40db87:	vpaddd xmm3,xmm3,xmm4
  40db8b:	vpshufd xmm2,xmm2,0x93
  40db90:	vpshufd xmm7,xmm3,0x93
  40db95:	vpxor  xmm2,xmm2,xmm7
  40db99:	vpshufb xmm2,xmm2,xmm1
  40db9e:	vpshufd xmm5,xmm5,0x93
  40dba3:	vpaddd xmm5,xmm5,xmm2
  40dba7:	vpshufd xmm4,xmm4,0x93
  40dbac:	vpxor  xmm4,xmm4,xmm5
  40dbb0:	vpslld xmm7,xmm4,0x7
  40dbb5:	vpsrld xmm4,xmm4,0x19
  40dbba:	vpor   xmm4,xmm7,xmm4
  40dbbe:	vpshufd xmm5,xmm5,0x93
  40dbc3:	vpshufd xmm2,xmm2,0x4e
  40dbc8:	add    rdx,0x1
  40dbcc:	cmp    rdx,0xa
  40dbd0:	jb     40db00 <__swc_fn_3464c816_000175_7f24d040+0x4c0>
  40dbd6:	lea    rdx,[rsi+rax*4]
  40dbda:	vpaddd xmm3,xmm3,XMMWORD PTR [rsp+0xc]
  40dbe0:	vpxor  xmm3,xmm3,XMMWORD PTR [rsi+rax*4]
  40dbe5:	vpaddd xmm4,xmm4,XMMWORD PTR [rsp+0x1c]
  40dbeb:	vpxor  xmm4,xmm4,XMMWORD PTR [rsi+rax*4+0x10]
  40dbf1:	vpaddd xmm5,xmm5,XMMWORD PTR [rsp+0x2c]
  40dbf7:	vpxor  xmm5,xmm5,XMMWORD PTR [rsi+rax*4+0x20]
  40dbfd:	vpaddd xmm7,xmm2,XMMWORD PTR [rsp+0x3c]
  40dc03:	vpxor  xmm7,xmm7,XMMWORD PTR [rsi+rax*4+0x30]
  40dc09:	vmovdqu XMMWORD PTR [rdx],xmm3
  40dc0d:	vmovdqu XMMWORD PTR [rdx+0x10],xmm4
  40dc12:	vmovdqu XMMWORD PTR [rdx+0x20],xmm5
  40dc17:	vmovdqu XMMWORD PTR [rdx+0x30],xmm7
  40dc1c:	vpshufd xmm2,xmm2,0x3
  40dc21:	vmovd  edx,xmm2
  40dc25:	add    edx,DWORD PTR [rbx+0x48]
  40dc28:	lea    rax,[rax+0x10]
  40dc2c:	inc    ecx
  40dc2e:	cmp    rax,0x400000
  40dc35:	jb     40dae0 <__swc_fn_3464c816_000175_7f24d040+0x4a0>
  40dc3b:	xor    edi,edi
  40dc3d:	xor    eax,eax
  40dc3f:	vxorps xmm0,xmm0,xmm0
  40dc43:	mov    ecx,0x1
  40dc48:	vpinsrd xmm0,xmm0,ecx,0x1
  40dc4e:	mov    ecx,0x2
  40dc53:	vpinsrd xmm0,xmm0,ecx,0x2
  40dc59:	mov    ecx,0x3
  40dc5e:	vpinsrd xmm0,xmm0,ecx,0x3
  40dc64:	vmovss xmm1,DWORD PTR [rip+0x5d74]        # 4139e0 <__swc_rdata_base_3464c816+0x8d0>
  40dc6c:	vpshufd xmm1,xmm1,0x0
  40dc71:	vpaddd xmm2,xmm0,xmm1
  40dc75:	vmovss xmm1,DWORD PTR [rip+0x5d6c]        # 4139e9 <__swc_rdata_base_3464c816+0x8d9>
  40dc7d:	vpshufd xmm1,xmm1,0x0
  40dc82:	vxorps xmm3,xmm3,xmm3
  40dc86:	vxorps xmm4,xmm4,xmm4
  40dc8a:	nop    WORD PTR [rax+rax*1+0x0]
  40dc90:	vpaddd xmm5,xmm0,XMMWORD PTR [rsi+rax*4]
  40dc95:	vpxor  xmm3,xmm3,xmm5
  40dc99:	vpaddd xmm5,xmm2,XMMWORD PTR [rsi+rax*4+0x10]
  40dc9f:	vpxor  xmm4,xmm4,xmm5
  40dca3:	vpaddd xmm2,xmm2,xmm1
  40dca7:	vpaddd xmm0,xmm0,xmm1
  40dcab:	add    rax,0x8
  40dcaf:	cmp    rax,0x3ffff9
  40dcb6:	jb     40dc90 <__swc_fn_3464c816_000175_7f24d040+0x650>
  40dcb8:	vpxor  xmm3,xmm3,xmm4
  40dcbc:	vpshufd xmm5,xmm3,0x4e
  40dcc1:	vpxor  xmm3,xmm3,xmm5
  40dcc5:	vpshufd xmm5,xmm3,0xb1
  40dcca:	vpxor  xmm3,xmm3,xmm5
  40dcce:	vmovd  eax,xmm3
  40dcd2:	xor    rdi,rax
  40dcd5:	sub    rsp,0x8
  40dcd9:	call   40a350 <__swc_fn_3464c816_000177_1ca87929>
  40dcde:	add    rsp,0x8
  40dce2:	vsubsd xmm0,xmm0,xmm6
  40dce6:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x5d04]        # 4139f2 <__swc_rdata_base_3464c816+0x8e2>
  40dcee:	lea    rax,[rip+0x5673]        # 413368 <__swc_rdata_base_3464c816+0x258>
  40dcf5:	sub    rsp,0x90
  40dcfc:	mov    rcx,rsp
  40dcff:	vmovups xmm1,XMMWORD PTR [rip+0x5c91]        # 413998 <__swc_rdata_base_3464c816+0x888>
  40dd07:	vmovups XMMWORD PTR [rcx],xmm1
  40dd0b:	mov    QWORD PTR [rcx+0x30],rsp
  40dd0f:	lea    rdx,[rip+0x55fa]        # 413310 <__swc_rdata_base_3464c816+0x200>
  40dd16:	mov    QWORD PTR [rcx+0x38],rdx
  40dd1a:	mov    QWORD PTR [rcx+0x10],rdi
  40dd1e:	lea    r8,[rsp+0x10]
  40dd23:	mov    QWORD PTR [rcx+0x40],r8
  40dd27:	lea    r8,[rip+0x5bda]        # 413908 <__swc_rdata_base_3464c816+0x7f8>
  40dd2e:	mov    QWORD PTR [rcx+0x48],r8
  40dd32:	vmovups xmm1,XMMWORD PTR [rip+0x5c6e]        # 4139a8 <__swc_rdata_base_3464c816+0x898>
  40dd3a:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40dd3f:	lea    r8,[rsp+0x18]
  40dd44:	mov    QWORD PTR [rcx+0x50],r8
  40dd48:	mov    QWORD PTR [rcx+0x58],rdx
  40dd4c:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40dd51:	lea    r8,[rcx+0x28]
  40dd55:	mov    QWORD PTR [rcx+0x60],r8
  40dd59:	lea    r8,[rip+0x5bf0]        # 413950 <__swc_rdata_base_3464c816+0x840>
  40dd60:	mov    QWORD PTR [rcx+0x68],r8
  40dd64:	mov    QWORD PTR [rcx+0x70],rax
  40dd68:	mov    QWORD PTR [rcx+0x78],rdx
  40dd6c:	lea    rax,[rcx+0x30]
  40dd70:	mov    QWORD PTR [rcx+0x80],rax
  40dd77:	mov    QWORD PTR [rcx+0x88],0x5
  40dd82:	lea    rcx,[rcx+0x80]
  40dd89:	sub    rsp,0x8
  40dd8d:	call   4108e0 <__swc_fn_3464c816_000146_d2097256>
  40dd92:	add    rsp,0x108
  40dd99:	vmovups xmm6,XMMWORD PTR [rsp]
  40dd9e:	vmovups xmm7,XMMWORD PTR [rsp+0x10]
  40dda4:	vmovups xmm8,XMMWORD PTR [rsp+0x20]
  40ddaa:	vmovups xmm9,XMMWORD PTR [rsp+0x30]
  40ddb0:	vmovups xmm10,XMMWORD PTR [rsp+0x40]
  40ddb6:	add    rsp,0x50
  40ddba:	pop    r14
  40ddbc:	pop    r15
  40ddbe:	pop    r13
  40ddc0:	pop    r12
  40ddc2:	pop    rdi
  40ddc3:	pop    rsi
  40ddc4:	pop    rbx
  40ddc5:	pop    rbp
  40ddc6:	ret
	...

000000000040dde0 <__swc_fn_3464c816_000002_102336c4>:
  40dde0:	sub    rsp,0x8
  40dde4:	call   40c620 <__swc_fn_3464c816_000109_9f5af8ae>
  40dde9:	mov    rcx,rax
  40ddec:	test   rax,rax
  40ddef:	je     40de16 <__swc_fn_3464c816_000002_102336c4+0x36>
  40ddf1:	lea    rdx,[rip+0x16248]        # 424040 <__swc_bss_base_3464c816>
  40ddf8:	mov    r8,QWORD PTR [rip+0x16241]        # 424040 <__swc_bss_base_3464c816>
  40ddff:	nop
  40de00:	lea    r9,[r8+0x1]
  40de04:	mov    rax,r8
  40de07:	lock cmpxchg QWORD PTR [rdx],r9
  40de0c:	cmp    rax,r8
  40de0f:	je     40de16 <__swc_fn_3464c816_000002_102336c4+0x36>
  40de11:	mov    r8,rax
  40de14:	jmp    40de00 <__swc_fn_3464c816_000002_102336c4+0x20>
  40de16:	mov    rax,rcx
  40de19:	add    rsp,0x8
  40de1d:	ret
	...

000000000040de20 <__swc_fn_3464c816_000005_6a556171>:
  40de20:	mov    r8d,edx
  40de23:	xor    eax,eax
  40de25:	tzcnt  eax,edx
  40de29:	shrx   r9d,edx,eax
  40de2e:	mov    DWORD PTR [rcx+0x2c],edx
  40de31:	xor    eax,eax
  40de33:	tzcnt  eax,edx
  40de37:	mov    BYTE PTR [rcx+0x38],al
  40de3a:	mov    eax,0xffffffff
  40de3f:	xor    edx,edx
  40de41:	div    r8d
  40de44:	mov    DWORD PTR [rcx+0x34],eax
  40de47:	mov    eax,r9d
  40de4a:	mov    edx,r9d
  40de4d:	imul   edx,r9d
  40de51:	mov    r8d,0x2
  40de57:	sub    r8d,edx
  40de5a:	imul   eax,r8d
  40de5e:	mov    edx,r9d
  40de61:	imul   edx,eax
  40de64:	mov    r8d,0x2
  40de6a:	sub    r8d,edx
  40de6d:	imul   eax,r8d
  40de71:	mov    edx,r9d
  40de74:	imul   edx,eax
  40de77:	mov    r8d,0x2
  40de7d:	sub    r8d,edx
  40de80:	imul   eax,r8d
  40de84:	mov    edx,r9d
  40de87:	imul   edx,eax
  40de8a:	mov    r8d,0x2
  40de90:	sub    r8d,edx
  40de93:	imul   eax,r8d
  40de97:	imul   r9d,eax
  40de9b:	mov    edx,0x2
  40dea0:	sub    edx,r9d
  40dea3:	imul   eax,edx
  40dea6:	mov    DWORD PTR [rcx+0x30],eax
  40dea9:	ret
  40deaa:	add    BYTE PTR [rax],al
  40deac:	add    BYTE PTR [rax],al
	...

000000000040deb0 <__swc_fn_3464c816_000008_b2f73e0d>:
  40deb0:	xor    eax,eax
  40deb2:	mov    DWORD PTR [rcx+0x68],eax
  40deb5:	ret
	...

000000000040dec0 <__swc_fn_3464c816_000011_71c91685>:
  40dec0:	mov    eax,DWORD PTR [rcx+0x28]
  40dec3:	shlx   eax,edx,eax
  40dec8:	shl    rax,0x10
  40decc:	lea    rdx,[rcx+rax*1]
  40ded0:	lea    rax,[rcx+0x3000]
  40ded7:	cmp    rdx,rax
  40deda:	cmovae rax,rdx
  40dede:	ret
	...

000000000040dee0 <__swc_fn_3464c816_000014_be17798c>:
  40dee0:	push   rsi
  40dee1:	push   rdi
  40dee2:	push   r12
  40dee4:	push   r13
  40dee6:	push   r14
  40dee8:	mov    rsi,rdx
  40deeb:	mov    rdi,rcx
  40deee:	rex mov dl,BYTE PTR [rsi+0x3a]
  40def2:	mov    ecx,DWORD PTR [rdi+0x28]
  40def5:	shr    dl,cl
  40def7:	mov    r12d,0x1
  40defd:	mov    ecx,edx
  40deff:	shl    r12,cl
  40df02:	mov    r13d,DWORD PTR [rsi+0x3c]
  40df06:	rex mov BYTE PTR [rsi+0x3b],0x0
  40df0b:	mov    QWORD PTR [rsi+0x40],0x0
  40df13:	mov    QWORD PTR [rsi],0x0
  40df1a:	mov    rax,QWORD PTR [rsi+0x10]
  40df1e:	mov    QWORD PTR [rsi+0x20],rax
  40df22:	lea    r14,[rip+0x1611f]        # 424048 <__swc_bss_base_3464c816+0x8>
  40df29:	mov    rax,QWORD PTR [r14]
  40df2c:	shr    rax,0x2
  40df30:	mov    rcx,rax
  40df33:	cmp    rax,0x800000
  40df3a:	mov    eax,0x800000
  40df3f:	cmovb  rcx,rax
  40df43:	lea    r8,[rip+0x1610e]        # 424058 <__swc_bss_base_3464c816+0x18>
  40df4a:	mov    rax,QWORD PTR [r8]
  40df4d:	mov    r9,rax
  40df50:	lea    r10,[r9+r13*1]
  40df54:	cmp    r10,rcx
  40df57:	ja     40df7b <__swc_fn_3464c816_000014_be17798c+0x9b>
  40df59:	mov    rax,r9
  40df5c:	lock cmpxchg QWORD PTR [r8],r10
  40df61:	cmp    rax,r9
  40df64:	je     40df6b <__swc_fn_3464c816_000014_be17798c+0x8b>
  40df66:	mov    r9,rax
  40df69:	jmp    40df50 <__swc_fn_3464c816_000014_be17798c+0x70>
  40df6b:	mov    rcx,rdi
  40df6e:	mov    rdx,r12
  40df71:	call   40a750 <__swc_fn_3464c816_000016_a0b588d0>
  40df76:	jmp    40dffd <__swc_fn_3464c816_000014_be17798c+0x11d>
  40df7b:	mov    rcx,rdi
  40df7e:	movzx  edx,dl
  40df81:	call   40dec0 <__swc_fn_3464c816_000011_71c91685>
  40df86:	test   r13,r13
  40df89:	je     40dff6 <__swc_fn_3464c816_000014_be17798c+0x116>
  40df8f:	mov    rcx,rax
  40df92:	mov    rdx,r13
  40df95:	call   40c7a0 <__swc_fn_3464c816_000112_2f7f9346>
  40df9a:	mov    rcx,QWORD PTR [rip+0x160a7]        # 424048 <__swc_bss_base_3464c816+0x8>
  40dfa1:	cs nop WORD PTR [rax+rax*1+0x0]
  40dfab:	nop    DWORD PTR [rax+rax*1+0x0]
  40dfb0:	mov    rdx,rcx
  40dfb3:	sub    rdx,r13
  40dfb6:	mov    rax,rcx
  40dfb9:	lock cmpxchg QWORD PTR [r14],rdx
  40dfbe:	cmp    rax,rcx
  40dfc1:	je     40dfc8 <__swc_fn_3464c816_000014_be17798c+0xe8>
  40dfc3:	mov    rcx,rax
  40dfc6:	jmp    40dfb0 <__swc_fn_3464c816_000014_be17798c+0xd0>
  40dfc8:	lea    rcx,[rip+0x16091]        # 424060 <__swc_bss_base_3464c816+0x20>
  40dfcf:	mov    rdx,QWORD PTR [rip+0x1608a]        # 424060 <__swc_bss_base_3464c816+0x20>
  40dfd6:	cs nop WORD PTR [rax+rax*1+0x0]
  40dfe0:	lea    r8,[rdx+0x1]
  40dfe4:	mov    rax,rdx
  40dfe7:	lock cmpxchg QWORD PTR [rcx],r8
  40dfec:	cmp    rax,rdx
  40dfef:	je     40dff6 <__swc_fn_3464c816_000014_be17798c+0x116>
  40dff1:	mov    rdx,rax
  40dff4:	jmp    40dfe0 <__swc_fn_3464c816_000014_be17798c+0x100>
  40dff6:	mov    DWORD PTR [rsi+0x3c],0x0
  40dffd:	mov    rcx,rdi
  40e000:	mov    rdx,r12
  40e003:	call   407600 <__swc_fn_3464c816_000018_77ece227>
  40e008:	pop    r14
  40e00a:	pop    r13
  40e00c:	pop    r12
  40e00e:	pop    rdi
  40e00f:	pop    rsi
  40e010:	ret
	...

000000000040e020 <__swc_fn_3464c816_000017_f003fc47>:
  40e020:	mov    r8,QWORD PTR [rcx+0x48]
  40e024:	test   r8,rdx
  40e027:	je     40e058 <__swc_fn_3464c816_000017_f003fc47+0x38>
  40e029:	nop    DWORD PTR [rax+0x0]
  40e030:	mov    rax,rdx
  40e033:	not    rax
  40e036:	mov    r9,r8
  40e039:	and    r9,rax
  40e03c:	mov    rax,r8
  40e03f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40e045:	cmp    rax,r8
  40e048:	jne    40e050 <__swc_fn_3464c816_000017_f003fc47+0x30>
  40e04a:	mov    eax,0x1
  40e04f:	ret
  40e050:	mov    r8,rax
  40e053:	test   rax,rdx
  40e056:	jne    40e030 <__swc_fn_3464c816_000017_f003fc47+0x10>
  40e058:	xor    eax,eax
  40e05a:	ret
  40e05b:	add    BYTE PTR [rax],al
  40e05d:	add    BYTE PTR [rax],al
	...

000000000040e060 <__swc_fn_3464c816_000020_4285d9c5>:
  40e060:	push   rsi
  40e061:	push   rdi
  40e062:	push   r12
  40e064:	push   r13
  40e066:	sub    rsp,0x8
  40e06a:	mov    rsi,rdx
  40e06d:	mov    rdi,rcx
  40e070:	lea    r12,[rip+0x16179]        # 4241f0 <__swc_bss_base_3464c816+0x1b0>
  40e077:	mov    rcx,r12
  40e07a:	call   4098a0 <__swc_fn_3464c816_000135_db32cc57>
  40e07f:	xor    eax,eax
  40e081:	mov    rcx,QWORD PTR [rip+0x16170]        # 4241f8 <__swc_bss_base_3464c816+0x1b8>
  40e088:	mov    r13,rcx
  40e08b:	test   r13,r13
  40e08e:	je     40e0db <__swc_fn_3464c816_000020_4285d9c5+0x7b>
  40e090:	mov    rcx,QWORD PTR [r13+0x10]
  40e094:	cmp    DWORD PTR [r13+0x28],esi
  40e098:	jne    40e0d0 <__swc_fn_3464c816_000020_4285d9c5+0x70>
  40e09a:	test   rax,rax
  40e09d:	jne    40e0a8 <__swc_fn_3464c816_000020_4285d9c5+0x48>
  40e09f:	mov    QWORD PTR [rip+0x16152],rcx        # 4241f8 <__swc_bss_base_3464c816+0x1b8>
  40e0a6:	jmp    40e0ac <__swc_fn_3464c816_000020_4285d9c5+0x4c>
  40e0a8:	mov    QWORD PTR [rax+0x10],rcx
  40e0ac:	vxorps xmm0,xmm0,xmm0
  40e0b0:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40e0b6:	mov    QWORD PTR [r13+0x8],rdi
  40e0ba:	mov    rcx,r12
  40e0bd:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  40e0c2:	mov    rax,r13
  40e0c5:	add    rsp,0x8
  40e0c9:	pop    r13
  40e0cb:	pop    r12
  40e0cd:	pop    rdi
  40e0ce:	pop    rsi
  40e0cf:	ret
  40e0d0:	mov    rax,r13
  40e0d3:	mov    r13,rcx
  40e0d6:	test   rcx,rcx
  40e0d9:	jne    40e090 <__swc_fn_3464c816_000020_4285d9c5+0x30>
  40e0db:	mov    ecx,esi
  40e0dd:	call   40a780 <__swc_fn_3464c816_000019_447bb610>
  40e0e2:	mov    rsi,rax
  40e0e5:	test   rax,rax
  40e0e8:	jne    40e0ff <__swc_fn_3464c816_000020_4285d9c5+0x9f>
  40e0ea:	mov    rcx,r12
  40e0ed:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  40e0f2:	xor    eax,eax
  40e0f4:	add    rsp,0x8
  40e0f8:	pop    r13
  40e0fa:	pop    r12
  40e0fc:	pop    rdi
  40e0fd:	pop    rsi
  40e0fe:	ret
  40e0ff:	mov    QWORD PTR [rsi+0x8],rdi
  40e103:	mov    rcx,r12
  40e106:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  40e10b:	mov    rax,rsi
  40e10e:	add    rsp,0x8
  40e112:	pop    r13
  40e114:	pop    r12
  40e116:	pop    rdi
  40e117:	pop    rsi
  40e118:	ret
  40e119:	add    BYTE PTR [rax],al
  40e11b:	add    BYTE PTR [rax],al
  40e11d:	add    BYTE PTR [rax],al
	...

000000000040e120 <__swc_fn_3464c816_000023_e876734d>:
  40e120:	vxorps xmm0,xmm0,xmm0
  40e124:	xor    eax,eax
  40e126:	cs nop WORD PTR [rax+rax*1+0x0]
  40e130:	cs nop WORD PTR [rax+rax*1+0x0]
  40e13a:	nop    WORD PTR [rax+rax*1+0x0]
  40e140:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40e145:	add    rax,0x10
  40e149:	cmp    rax,0x2b00
  40e150:	jne    40e140 <__swc_fn_3464c816_000023_e876734d+0x20>
  40e152:	ret
	...

000000000040e160 <__swc_fn_3464c816_000026_e876734d>:
  40e160:	vxorps xmm0,xmm0,xmm0
  40e164:	vmovups XMMWORD PTR [rcx],xmm0
  40e168:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e16d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e172:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e177:	ret
	...

000000000040e180 <__swc_fn_3464c816_000029_e876734d>:
  40e180:	vxorps xmm0,xmm0,xmm0
  40e184:	vmovups XMMWORD PTR [rcx],xmm0
  40e188:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e18d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e192:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e197:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40e19c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40e1a1:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40e1a6:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40e1ab:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40e1b3:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40e1bb:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40e1c3:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40e1cb:	mov    QWORD PTR [rcx+0xc0],0x0
  40e1d6:	ret
	...

000000000040e1e0 <__swc_fn_3464c816_000032_f1940e30>:
  40e1e0:	push   rsi
  40e1e1:	push   rdi
  40e1e2:	sub    rsp,0x8
  40e1e6:	mov    rsi,rcx
  40e1e9:	lea    rdi,[rip+0x13e10]        # 422000 <__swc_data_base_3464c816>
  40e1f0:	mov    rax,QWORD PTR [rdi]
  40e1f3:	cmp    rax,0xffffffffffffffff
  40e1f7:	je     40e1fe <__swc_fn_3464c816_000032_f1940e30+0x1e>
  40e1f9:	mov    rdi,rax
  40e1fc:	jmp    40e22b <__swc_fn_3464c816_000032_f1940e30+0x4b>
  40e1fe:	call   409580 <__swc_fn_3464c816_000123_e4107ade>
  40e203:	mov    rcx,rax
  40e206:	cmp    rax,0xffffffffffffffff
  40e20a:	je     40e23c <__swc_fn_3464c816_000032_f1940e30+0x5c>
  40e20c:	mov    rax,0xffffffffffffffff
  40e213:	lock cmpxchg QWORD PTR [rdi],rcx
  40e218:	cmp    rax,0xffffffffffffffff
  40e21c:	je     40e228 <__swc_fn_3464c816_000032_f1940e30+0x48>
  40e21e:	mov    rdi,rax
  40e221:	call   40cb70 <__swc_fn_3464c816_000124_37eaf452>
  40e226:	jmp    40e22b <__swc_fn_3464c816_000032_f1940e30+0x4b>
  40e228:	mov    rdi,rcx
  40e22b:	cmp    rdi,0xffffffffffffffff
  40e22f:	je     40e23c <__swc_fn_3464c816_000032_f1940e30+0x5c>
  40e231:	mov    rcx,rdi
  40e234:	mov    rdx,rsi
  40e237:	call   4102f0 <__swc_fn_3464c816_000125_7a81492f>
  40e23c:	add    rsp,0x8
  40e240:	pop    rdi
  40e241:	pop    rsi
  40e242:	ret
	...

000000000040e250 <__swc_fn_3464c816_000035_ab2e8c35>:
  40e250:	sub    rsp,0x38
  40e254:	mov    rax,rdx
  40e257:	test   dl,dl
  40e259:	jne    40e271 <__swc_fn_3464c816_000035_ab2e8c35+0x21>
  40e25b:	mov    rax,r8
  40e25e:	test   r8b,r8b
  40e261:	cmove  eax,r9d
  40e265:	test   al,al
  40e267:	cmove  eax,r10d
  40e26b:	test   al,al
  40e26d:	cmove  eax,r11d
  40e271:	test   al,al
  40e273:	jne    40e27a <__swc_fn_3464c816_000035_ab2e8c35+0x2a>
  40e275:	add    rsp,0x38
  40e279:	ret
  40e27a:	lea    rcx,[rip+0x4e8f]        # 413110 <__swc_rdata_base_3464c816>
  40e281:	vmovups xmm0,XMMWORD PTR [rip+0x4e97]        # 413120 <__swc_rdata_base_3464c816+0x10>
  40e289:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e28f:	vmovups xmm0,XMMWORD PTR [rip+0x4e99]        # 413130 <__swc_rdata_base_3464c816+0x20>
  40e297:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e29d:	vmovups xmm0,XMMWORD PTR [rip+0x4e9b]        # 413140 <__swc_rdata_base_3464c816+0x30>
  40e2a5:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e2ab:	lea    rdx,[rsp+0x8]
  40e2b0:	call   40c3a0 <__swc_fn_3464c816_000103_0d4cc079>
  40e2b5:	jmp    40e275 <__swc_fn_3464c816_000035_ab2e8c35+0x25>
	...

000000000040e2c0 <__swc_fn_3464c816_000038_292d55e5>:
  40e2c0:	sub    rsp,0x8
  40e2c4:	mov    eax,0x1000
  40e2c9:	test   eax,eax
  40e2cb:	mov    r8d,0x8
  40e2d1:	cmove  eax,r8d
  40e2d5:	dec    rax
  40e2d8:	mov    r8,0xffffffffffffffff
  40e2df:	sub    r8,rax
  40e2e2:	cmp    rdx,r8
  40e2e5:	ja     40e2f5 <__swc_fn_3464c816_000038_292d55e5+0x35>
  40e2e7:	add    rdx,rax
  40e2ea:	not    rax
  40e2ed:	mov    r8,rdx
  40e2f0:	and    r8,rax
  40e2f3:	jne    40e2fc <__swc_fn_3464c816_000038_292d55e5+0x3c>
  40e2f5:	xor    eax,eax
  40e2f7:	add    rsp,0x8
  40e2fb:	ret
  40e2fc:	mov    rdx,r8
  40e2ff:	call   40aaa0 <__swc_fn_3464c816_000037_1e381f55>
  40e304:	add    rsp,0x8
  40e308:	ret
  40e309:	add    BYTE PTR [rax],al
  40e30b:	add    BYTE PTR [rax],al
  40e30d:	add    BYTE PTR [rax],al
	...

000000000040e310 <__swc_fn_3464c816_000041_41400651>:
  40e310:	push   rsi
  40e311:	push   rdi
  40e312:	sub    rsp,0x8
  40e316:	mov    rsi,rdx
  40e319:	mov    rdi,rcx
  40e31c:	test   rdx,rdx
  40e31f:	je     40e33b <__swc_fn_3464c816_000041_41400651+0x2b>
  40e321:	xor    ecx,ecx
  40e323:	call   407720 <__swc_fn_3464c816_000033_d15eb4ea>
  40e328:	mov    rax,QWORD PTR [rsi]
  40e32b:	test   rax,rax
  40e32e:	je     40e33b <__swc_fn_3464c816_000041_41400651+0x2b>
  40e330:	mov    rcx,rax
  40e333:	mov    rdx,rsi
  40e336:	call   407840 <__swc_fn_3464c816_000042_0573444d>
  40e33b:	mov    rcx,rdi
  40e33e:	call   40ab00 <__swc_fn_3464c816_000040_8029566e>
  40e343:	mov    rsi,rax
  40e346:	test   rax,rax
  40e349:	jne    40e354 <__swc_fn_3464c816_000041_41400651+0x44>
  40e34b:	xor    eax,eax
  40e34d:	add    rsp,0x8
  40e351:	pop    rdi
  40e352:	pop    rsi
  40e353:	ret
  40e354:	mov    rcx,rsi
  40e357:	call   407720 <__swc_fn_3464c816_000033_d15eb4ea>
  40e35c:	mov    rax,rsi
  40e35f:	add    rsp,0x8
  40e363:	pop    rdi
  40e364:	pop    rsi
  40e365:	ret
	...

000000000040e370 <__swc_fn_3464c816_000044_fe6bbfdb>:
  40e370:	movzx  eax,BYTE PTR [r8+0x39]
  40e375:	lea    rax,[rax+rax*4]
  40e379:	lea    rax,[rdx+rax*8+0x28]
  40e37e:	mov    ecx,DWORD PTR [r8+0x6c]
  40e382:	test   ecx,ecx
  40e384:	je     40e3bd <__swc_fn_3464c816_000044_fe6bbfdb+0x4d>
  40e386:	mov    rcx,QWORD PTR [r8+0x50]
  40e38a:	test   rcx,rcx
  40e38d:	je     40e399 <__swc_fn_3464c816_000044_fe6bbfdb+0x29>
  40e38f:	mov    rax,QWORD PTR [r8+0x48]
  40e393:	mov    QWORD PTR [rcx+0x48],rax
  40e397:	jmp    40e3a1 <__swc_fn_3464c816_000044_fe6bbfdb+0x31>
  40e399:	mov    rcx,QWORD PTR [r8+0x48]
  40e39d:	mov    QWORD PTR [rax+0x18],rcx
  40e3a1:	mov    rax,QWORD PTR [r8+0x48]
  40e3a5:	test   rax,rax
  40e3a8:	je     40e3b2 <__swc_fn_3464c816_000044_fe6bbfdb+0x42>
  40e3aa:	mov    rcx,QWORD PTR [r8+0x50]
  40e3ae:	mov    QWORD PTR [rax+0x50],rcx
  40e3b2:	vxorps xmm0,xmm0,xmm0
  40e3b6:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e3bc:	ret
  40e3bd:	mov    rcx,QWORD PTR [r8+0x50]
  40e3c1:	test   rcx,rcx
  40e3c4:	je     40e3d0 <__swc_fn_3464c816_000044_fe6bbfdb+0x60>
  40e3c6:	mov    rdx,QWORD PTR [r8+0x48]
  40e3ca:	mov    QWORD PTR [rcx+0x48],rdx
  40e3ce:	jmp    40e3d8 <__swc_fn_3464c816_000044_fe6bbfdb+0x68>
  40e3d0:	mov    rcx,QWORD PTR [r8+0x48]
  40e3d4:	mov    QWORD PTR [rax+0x8],rcx
  40e3d8:	mov    rcx,QWORD PTR [r8+0x48]
  40e3dc:	test   rcx,rcx
  40e3df:	je     40e3eb <__swc_fn_3464c816_000044_fe6bbfdb+0x7b>
  40e3e1:	mov    rdx,QWORD PTR [r8+0x50]
  40e3e5:	mov    QWORD PTR [rcx+0x50],rdx
  40e3e9:	jmp    40e3f3 <__swc_fn_3464c816_000044_fe6bbfdb+0x83>
  40e3eb:	mov    rcx,QWORD PTR [r8+0x50]
  40e3ef:	mov    QWORD PTR [rax+0x10],rcx
  40e3f3:	cmp    QWORD PTR [rax],r8
  40e3f6:	jne    40e3ff <__swc_fn_3464c816_000044_fe6bbfdb+0x8f>
  40e3f8:	mov    QWORD PTR [rax],0x0
  40e3ff:	vxorps xmm0,xmm0,xmm0
  40e403:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e409:	ret
  40e40a:	add    BYTE PTR [rax],al
  40e40c:	add    BYTE PTR [rax],al
	...

000000000040e410 <__swc_fn_3464c816_000047_e7fd8d42>:
  40e410:	sub    rsp,0x8
  40e414:	mov    r9,r8
  40e417:	mov    r10,rdx
  40e41a:	call   40e370 <__swc_fn_3464c816_000044_fe6bbfdb>
  40e41f:	mov    DWORD PTR [r9+0x6c],0x0
  40e427:	movzx  eax,BYTE PTR [r9+0x39]
  40e42c:	lea    rax,[rax+rax*4]
  40e430:	lea    rax,[r10+rax*8+0x28]
  40e435:	mov    rcx,QWORD PTR [rax+0x10]
  40e439:	mov    QWORD PTR [r9+0x50],rcx
  40e43d:	mov    QWORD PTR [r9+0x48],0x0
  40e445:	mov    rcx,QWORD PTR [rax+0x10]
  40e449:	test   rcx,rcx
  40e44c:	je     40e454 <__swc_fn_3464c816_000047_e7fd8d42+0x44>
  40e44e:	mov    QWORD PTR [rcx+0x48],r9
  40e452:	jmp    40e458 <__swc_fn_3464c816_000047_e7fd8d42+0x48>
  40e454:	mov    QWORD PTR [rax+0x8],r9
  40e458:	mov    QWORD PTR [rax+0x10],r9
  40e45c:	add    rsp,0x8
  40e460:	ret
	...

000000000040e480 <__swc_fn_3464c816_000050_5e919db9>:
  40e480:	push   rsi
  40e481:	push   rdi
  40e482:	push   r12
  40e484:	push   r13
  40e486:	push   r14
  40e488:	push   r15
  40e48a:	sub    rsp,0x1f8
  40e491:	mov    esi,r8d
  40e494:	mov    QWORD PTR [rsp+0x1e8],rsi
  40e49c:	mov    rdi,rcx
  40e49f:	mov    r12,rdx
  40e4a2:	lea    r13,[rsi+rsi*4]
  40e4a6:	lea    r13,[rdx+r13*8+0x28]
  40e4ab:	call   407ca0 <__swc_fn_3464c816_000048_8e68f77b>
  40e4b0:	add    DWORD PTR [r12+0x24],0x1
  40e4b6:	test   BYTE PTR [r12+0x24],0x3f
  40e4bc:	jne    40e4c6 <__swc_fn_3464c816_000050_5e919db9+0x46>
  40e4be:	mov    rcx,rdi
  40e4c1:	call   40ac80 <__swc_fn_3464c816_000049_f6a485a2>
  40e4c6:	mov    rax,QWORD PTR [r13+0x8]
  40e4ca:	mov    r14,rax
  40e4cd:	nop    DWORD PTR [rax]
  40e4d0:	test   r14,r14
  40e4d3:	jne    40e4e2 <__swc_fn_3464c816_000050_5e919db9+0x62>
  40e4d5:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40e4dd:	jmp    40e5e9 <__swc_fn_3464c816_000050_5e919db9+0x169>
  40e4e2:	mov    r15,QWORD PTR [r14+0x48]
  40e4e6:	mov    rcx,r14
  40e4e9:	call   4073f0 <__swc_fn_3464c816_000009_4c3ebf16>
  40e4ee:	mov    rax,QWORD PTR [r14]
  40e4f1:	test   rax,rax
  40e4f4:	je     40e506 <__swc_fn_3464c816_000050_5e919db9+0x86>
  40e4f6:	mov    rcx,QWORD PTR [rax]
  40e4f9:	mov    QWORD PTR [r14],rcx
  40e4fc:	add    DWORD PTR [r14+0x28],0x1
  40e501:	mov    rsi,rax
  40e504:	jmp    40e525 <__swc_fn_3464c816_000050_5e919db9+0xa5>
  40e506:	mov    rax,QWORD PTR [r14+0x18]
  40e50a:	cmp    QWORD PTR [r14+0x20],rax
  40e50e:	jae    40e523 <__swc_fn_3464c816_000050_5e919db9+0xa3>
  40e510:	mov    rsi,QWORD PTR [r14+0x20]
  40e514:	mov    eax,DWORD PTR [r14+0x2c]
  40e518:	add    QWORD PTR [r14+0x20],rax
  40e51c:	add    DWORD PTR [r14+0x28],0x1
  40e521:	jmp    40e525 <__swc_fn_3464c816_000050_5e919db9+0xa5>
  40e523:	xor    esi,esi
  40e525:	test   rsi,rsi
  40e528:	jne    40e56d <__swc_fn_3464c816_000050_5e919db9+0xed>
  40e52a:	mov    rcx,r14
  40e52d:	call   407320 <__swc_fn_3464c816_000006_7b253ae1>
  40e532:	test   al,al
  40e534:	je     40e56d <__swc_fn_3464c816_000050_5e919db9+0xed>
  40e536:	mov    rax,QWORD PTR [r14]
  40e539:	test   rax,rax
  40e53c:	je     40e54b <__swc_fn_3464c816_000050_5e919db9+0xcb>
  40e53e:	mov    rcx,QWORD PTR [rax]
  40e541:	mov    QWORD PTR [r14],rcx
  40e544:	add    DWORD PTR [r14+0x28],0x1
  40e549:	jmp    40e56a <__swc_fn_3464c816_000050_5e919db9+0xea>
  40e54b:	mov    rax,QWORD PTR [r14+0x18]
  40e54f:	cmp    QWORD PTR [r14+0x20],rax
  40e553:	jae    40e568 <__swc_fn_3464c816_000050_5e919db9+0xe8>
  40e555:	mov    rax,QWORD PTR [r14+0x20]
  40e559:	mov    ecx,DWORD PTR [r14+0x2c]
  40e55d:	add    QWORD PTR [r14+0x20],rcx
  40e561:	add    DWORD PTR [r14+0x28],0x1
  40e566:	jmp    40e56a <__swc_fn_3464c816_000050_5e919db9+0xea>
  40e568:	xor    eax,eax
  40e56a:	mov    rsi,rax
  40e56d:	test   rsi,rsi
  40e570:	jne    40e5c3 <__swc_fn_3464c816_000050_5e919db9+0x143>
  40e572:	mov    rcx,rdi
  40e575:	mov    rdx,r12
  40e578:	mov    r8,r14
  40e57b:	call   40abe0 <__swc_fn_3464c816_000046_b28a6ee7>
  40e580:	test   al,al
  40e582:	jne    40e5c3 <__swc_fn_3464c816_000050_5e919db9+0x143>
  40e584:	mov    rcx,r14
  40e587:	call   4073f0 <__swc_fn_3464c816_000009_4c3ebf16>
  40e58c:	mov    rax,QWORD PTR [r14]
  40e58f:	test   rax,rax
  40e592:	je     40e5a1 <__swc_fn_3464c816_000050_5e919db9+0x121>
  40e594:	mov    rcx,QWORD PTR [rax]
  40e597:	mov    QWORD PTR [r14],rcx
  40e59a:	add    DWORD PTR [r14+0x28],0x1
  40e59f:	jmp    40e5c0 <__swc_fn_3464c816_000050_5e919db9+0x140>
  40e5a1:	mov    rax,QWORD PTR [r14+0x18]
  40e5a5:	cmp    QWORD PTR [r14+0x20],rax
  40e5a9:	jae    40e5be <__swc_fn_3464c816_000050_5e919db9+0x13e>
  40e5ab:	mov    rax,QWORD PTR [r14+0x20]
  40e5af:	mov    ecx,DWORD PTR [r14+0x2c]
  40e5b3:	add    QWORD PTR [r14+0x20],rcx
  40e5b7:	add    DWORD PTR [r14+0x28],0x1
  40e5bc:	jmp    40e5c0 <__swc_fn_3464c816_000050_5e919db9+0x140>
  40e5be:	xor    eax,eax
  40e5c0:	mov    rsi,rax
  40e5c3:	test   rsi,rsi
  40e5c6:	je     40e5e1 <__swc_fn_3464c816_000050_5e919db9+0x161>
  40e5c8:	mov    QWORD PTR [r13+0x0],r14
  40e5cc:	mov    rax,rsi
  40e5cf:	add    rsp,0x1f8
  40e5d6:	pop    r15
  40e5d8:	pop    r14
  40e5da:	pop    r13
  40e5dc:	pop    r12
  40e5de:	pop    rdi
  40e5df:	pop    rsi
  40e5e0:	ret
  40e5e1:	mov    r14,r15
  40e5e4:	jmp    40e4d0 <__swc_fn_3464c816_000050_5e919db9+0x50>
  40e5e9:	cs nop WORD PTR [rax+rax*1+0x0]
  40e5f3:	cs nop WORD PTR [rax+rax*1+0x0]
  40e5fd:	nop    DWORD PTR [rax]
  40e600:	mov    rcx,rdi
  40e603:	mov    rdx,r12
  40e606:	mov    r8d,esi
  40e609:	call   4079e0 <__swc_fn_3464c816_000045_bb688d37>
  40e60e:	mov    r14,rax
  40e611:	test   rax,rax
  40e614:	jne    40e62a <__swc_fn_3464c816_000050_5e919db9+0x1aa>
  40e616:	xor    eax,eax
  40e618:	add    rsp,0x1f8
  40e61f:	pop    r15
  40e621:	pop    r14
  40e623:	pop    r13
  40e625:	pop    r12
  40e627:	pop    rdi
  40e628:	pop    rsi
  40e629:	ret
  40e62a:	mov    QWORD PTR [r13+0x0],r14
  40e62e:	mov    rax,QWORD PTR [r14]
  40e631:	test   rax,rax
  40e634:	je     40e646 <__swc_fn_3464c816_000050_5e919db9+0x1c6>
  40e636:	mov    rcx,QWORD PTR [rax]
  40e639:	mov    QWORD PTR [r14],rcx
  40e63c:	add    DWORD PTR [r14+0x28],0x1
  40e641:	mov    r15,rax
  40e644:	jmp    40e666 <__swc_fn_3464c816_000050_5e919db9+0x1e6>
  40e646:	mov    rax,QWORD PTR [r14+0x18]
  40e64a:	cmp    QWORD PTR [r14+0x20],rax
  40e64e:	jae    40e663 <__swc_fn_3464c816_000050_5e919db9+0x1e3>
  40e650:	mov    r15,QWORD PTR [r14+0x20]
  40e654:	mov    eax,DWORD PTR [r14+0x2c]
  40e658:	add    QWORD PTR [r14+0x20],rax
  40e65c:	add    DWORD PTR [r14+0x28],0x1
  40e661:	jmp    40e666 <__swc_fn_3464c816_000050_5e919db9+0x1e6>
  40e663:	xor    r15d,r15d
  40e666:	test   r15,r15
  40e669:	jne    40e6ae <__swc_fn_3464c816_000050_5e919db9+0x22e>
  40e66b:	mov    rcx,r14
  40e66e:	call   407320 <__swc_fn_3464c816_000006_7b253ae1>
  40e673:	test   al,al
  40e675:	je     40e6ae <__swc_fn_3464c816_000050_5e919db9+0x22e>
  40e677:	mov    rax,QWORD PTR [r14]
  40e67a:	test   rax,rax
  40e67d:	je     40e68c <__swc_fn_3464c816_000050_5e919db9+0x20c>
  40e67f:	mov    rcx,QWORD PTR [rax]
  40e682:	mov    QWORD PTR [r14],rcx
  40e685:	add    DWORD PTR [r14+0x28],0x1
  40e68a:	jmp    40e6ab <__swc_fn_3464c816_000050_5e919db9+0x22b>
  40e68c:	mov    rax,QWORD PTR [r14+0x18]
  40e690:	cmp    QWORD PTR [r14+0x20],rax
  40e694:	jae    40e6a9 <__swc_fn_3464c816_000050_5e919db9+0x229>
  40e696:	mov    rax,QWORD PTR [r14+0x20]
  40e69a:	mov    ecx,DWORD PTR [r14+0x2c]
  40e69e:	add    QWORD PTR [r14+0x20],rcx
  40e6a2:	add    DWORD PTR [r14+0x28],0x1
  40e6a7:	jmp    40e6ab <__swc_fn_3464c816_000050_5e919db9+0x22b>
  40e6a9:	xor    eax,eax
  40e6ab:	mov    r15,rax
  40e6ae:	test   r15,r15
  40e6b1:	je     40e600 <__swc_fn_3464c816_000050_5e919db9+0x180>
  40e6b7:	mov    rax,r15
  40e6ba:	add    rsp,0x1f8
  40e6c1:	pop    r15
  40e6c3:	pop    r14
  40e6c5:	pop    r13
  40e6c7:	pop    r12
  40e6c9:	pop    rdi
  40e6ca:	pop    rsi
  40e6cb:	ret
  40e6cc:	add    BYTE PTR [rax],al
	...

000000000040e6d0 <__swc_fn_3464c816_000053_9aa81fa7>:
  40e6d0:	push   rsi
  40e6d1:	push   rdi
  40e6d2:	push   r12
  40e6d4:	mov    rsi,rdx
  40e6d7:	mov    rax,rdx
  40e6da:	shr    rax,0xc
  40e6de:	movabs rdx,0x9e3779b97f4a7c15
  40e6e8:	imul   rax,rdx
  40e6ec:	shr    rax,0x20
  40e6f0:	lea    rax,[rax*8+0x0]
  40e6f8:	shr    rax,0x20
  40e6fc:	lea    rax,[rax*8+0x0]
  40e704:	lea    rax,[rcx+rax*8+0x40]
  40e709:	xor    edx,edx
  40e70b:	test   dl,dl
  40e70d:	lea    rdi,[rcx+0x8]
  40e711:	cmove  rdi,rax
  40e715:	xor    edx,edx
  40e717:	test   dl,dl
  40e719:	lea    r12,[rcx+0x30]
  40e71d:	lea    rax,[rax+0x8]
  40e721:	cmove  r12,rax
  40e725:	mov    rcx,rdi
  40e728:	call   4098a0 <__swc_fn_3464c816_000135_db32cc57>
  40e72d:	mov    QWORD PTR [rsi+0x30],0x0
  40e735:	mov    rax,QWORD PTR [r12]
  40e739:	mov    QWORD PTR [rsi+0x38],rax
  40e73d:	test   rax,rax
  40e740:	je     40e74a <__swc_fn_3464c816_000053_9aa81fa7+0x7a>
  40e742:	mov    rax,QWORD PTR [rsi+0x38]
  40e746:	mov    QWORD PTR [rax+0x30],rsi
  40e74a:	mov    QWORD PTR [r12],rsi
  40e74e:	mov    rcx,rdi
  40e751:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  40e756:	pop    r12
  40e758:	pop    rdi
  40e759:	pop    rsi
  40e75a:	ret
  40e75b:	add    BYTE PTR [rax],al
  40e75d:	add    BYTE PTR [rax],al
	...

000000000040e760 <__swc_fn_3464c816_000056_87dc216f>:
  40e760:	lea    rax,[rdx+rdx*4]
  40e764:	lea    rax,[rcx+rax*8+0x268]
  40e76c:	mov    rdx,QWORD PTR [rax+0x10]
  40e770:	sub    QWORD PTR [rcx+0x2a68],rdx
  40e777:	sub    QWORD PTR [rcx+0x2a70],0x1
  40e77f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40e786:	lea    rdx,[rdx+rdx*4]
  40e78a:	lea    rdx,[rcx+rdx*8+0x268]
  40e792:	vmovups xmm0,XMMWORD PTR [rdx]
  40e796:	vmovups XMMWORD PTR [rax],xmm0
  40e79a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40e79f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e7a4:	mov    rcx,QWORD PTR [rdx+0x20]
  40e7a8:	mov    QWORD PTR [rax+0x20],rcx
  40e7ac:	ret
  40e7ad:	add    BYTE PTR [rax],al
	...

000000000040e7b0 <__swc_fn_3464c816_000059_ee6a254c>:
  40e7b0:	push   rsi
  40e7b1:	push   rdi
  40e7b2:	push   r12
  40e7b4:	push   r13
  40e7b6:	sub    rsp,0x8
  40e7ba:	mov    rsi,r8
  40e7bd:	mov    rdi,rcx
  40e7c0:	mov    r12,rdx
  40e7c3:	xor    r13d,r13d
  40e7c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40e7d0:	mov    eax,DWORD PTR [r12+0x730]
  40e7d8:	cmp    r13d,eax
  40e7db:	jae    40e841 <__swc_fn_3464c816_000059_ee6a254c+0x91>
  40e7dd:	lea    rax,[r13+r13*4+0x0]
  40e7e2:	lea    rax,[r12+rax*8+0x738]
  40e7ea:	mov    rdx,QWORD PTR [rax]
  40e7ed:	mov    r8,QWORD PTR [rax+0x8]
  40e7f1:	mov    r9,QWORD PTR [rax+0x10]
  40e7f5:	cmp    QWORD PTR [rax+0x20],rsi
  40e7f9:	jb     40e800 <__swc_fn_3464c816_000059_ee6a254c+0x50>
  40e7fb:	inc    r13d
  40e7fe:	jmp    40e7d0 <__swc_fn_3464c816_000059_ee6a254c+0x20>
  40e800:	sub    DWORD PTR [r12+0x730],0x1
  40e809:	mov    ecx,DWORD PTR [r12+0x730]
  40e811:	lea    rcx,[rcx+rcx*4]
  40e815:	lea    rcx,[r12+rcx*8+0x738]
  40e81d:	vmovups xmm0,XMMWORD PTR [rcx]
  40e821:	vmovups XMMWORD PTR [rax],xmm0
  40e825:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40e82a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e82f:	mov    rcx,QWORD PTR [rcx+0x20]
  40e833:	mov    QWORD PTR [rax+0x20],rcx
  40e837:	mov    rcx,rdi
  40e83a:	call   407750 <__swc_fn_3464c816_000039_9ae4348f>
  40e83f:	jmp    40e7d0 <__swc_fn_3464c816_000059_ee6a254c+0x20>
  40e841:	add    rsp,0x8
  40e845:	pop    r13
  40e847:	pop    r12
  40e849:	pop    rdi
  40e84a:	pop    rsi
  40e84b:	ret
  40e84c:	add    BYTE PTR [rax],al
	...

000000000040e850 <__swc_fn_3464c816_000062_0a65f1d5>:
  40e850:	push   rsi
  40e851:	push   rdi
  40e852:	push   r12
  40e854:	push   r13
  40e856:	push   r14
  40e858:	mov    rsi,rcx
  40e85b:	mov    rdi,rdx
  40e85e:	mov    r12,QWORD PTR [rdi]
  40e861:	mov    r13,QWORD PTR [rdi+0x18]
  40e865:	mov    rax,r12
  40e868:	add    rax,QWORD PTR [rdi+0x8]
  40e86c:	sub    rax,r13
  40e86f:	cmp    r8,rax
  40e872:	jbe    40e87d <__swc_fn_3464c816_000062_0a65f1d5+0x2d>
  40e874:	pop    r14
  40e876:	pop    r13
  40e878:	pop    r12
  40e87a:	pop    rdi
  40e87b:	pop    rsi
  40e87c:	ret
  40e87d:	lea    rax,[r13+r8*1+0x0]
  40e882:	sub    rax,r12
  40e885:	mov    ecx,0x1000
  40e88a:	test   ecx,ecx
  40e88c:	mov    edx,0x8
  40e891:	cmove  ecx,edx
  40e894:	dec    rcx
  40e897:	mov    rdx,0xffffffffffffffff
  40e89e:	sub    rdx,rcx
  40e8a1:	cmp    rax,rdx
  40e8a4:	jbe    40e8ab <__swc_fn_3464c816_000062_0a65f1d5+0x5b>
  40e8a6:	xor    r14d,r14d
  40e8a9:	jmp    40e8b6 <__swc_fn_3464c816_000062_0a65f1d5+0x66>
  40e8ab:	add    rax,rcx
  40e8ae:	andn   rax,rcx,rax
  40e8b3:	mov    r14,rax
  40e8b6:	mov    rax,QWORD PTR [rdi+0x10]
  40e8ba:	cmp    r14,rax
  40e8bd:	ja     40e8c8 <__swc_fn_3464c816_000062_0a65f1d5+0x78>
  40e8bf:	pop    r14
  40e8c1:	pop    r13
  40e8c3:	pop    r12
  40e8c5:	pop    rdi
  40e8c6:	pop    rsi
  40e8c7:	ret
  40e8c8:	mov    rax,r12
  40e8cb:	add    rax,QWORD PTR [rdi+0x10]
  40e8cf:	mov    rdx,r14
  40e8d2:	sub    rdx,QWORD PTR [rdi+0x10]
  40e8d6:	mov    rcx,rax
  40e8d9:	call   4072a0 <__swc_fn_3464c816_000003_81215399>
  40e8de:	test   al,al
  40e8e0:	jne    40e8eb <__swc_fn_3464c816_000062_0a65f1d5+0x9b>
  40e8e2:	pop    r14
  40e8e4:	pop    r13
  40e8e6:	pop    r12
  40e8e8:	pop    rdi
  40e8e9:	pop    rsi
  40e8ea:	ret
  40e8eb:	add    r12,r14
  40e8ee:	sub    r12,r13
  40e8f1:	mov    rcx,r12
  40e8f4:	sub    rcx,QWORD PTR [rdi+0x28]
  40e8f8:	mov    rdx,QWORD PTR [rsi+0x250]
  40e8ff:	nop
  40e900:	lea    r8,[rdx+rcx*1]
  40e904:	mov    rax,rdx
  40e907:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40e910:	cmp    rax,rdx
  40e913:	je     40e91a <__swc_fn_3464c816_000062_0a65f1d5+0xca>
  40e915:	mov    rdx,rax
  40e918:	jmp    40e900 <__swc_fn_3464c816_000062_0a65f1d5+0xb0>
  40e91a:	mov    QWORD PTR [rdi+0x10],r14
  40e91e:	mov    QWORD PTR [rdi+0x28],r12
  40e922:	pop    r14
  40e924:	pop    r13
  40e926:	pop    r12
  40e928:	pop    rdi
  40e929:	pop    rsi
  40e92a:	ret
  40e92b:	add    BYTE PTR [rax],al
  40e92d:	add    BYTE PTR [rax],al
	...

000000000040e930 <__swc_fn_3464c816_000065_0b20477c>:
  40e930:	push   rbx
  40e931:	push   rsi
  40e932:	push   rdi
  40e933:	push   r12
  40e935:	push   r13
  40e937:	sub    rsp,0xe0
  40e93e:	mov    rbx,rdx
  40e941:	mov    rsi,rcx
  40e944:	cmp    DWORD PTR [rbx+0x58],0x0
  40e948:	je     40e96c <__swc_fn_3464c816_000065_0b20477c+0x3c>
  40e94a:	mov    eax,DWORD PTR [rbx+0x58]
  40e94d:	sub    eax,0x1
  40e950:	test   DWORD PTR [rbx+0x58],eax
  40e953:	je     40e96c <__swc_fn_3464c816_000065_0b20477c+0x3c>
  40e955:	mov    QWORD PTR [rbx+0x40],0x0
  40e95d:	add    rsp,0xe0
  40e964:	pop    r13
  40e966:	pop    r12
  40e968:	pop    rdi
  40e969:	pop    rsi
  40e96a:	pop    rbx
  40e96b:	ret
  40e96c:	mov    rax,QWORD PTR [rbx+0x40]
  40e970:	test   rax,rax
  40e973:	jne    40e98f <__swc_fn_3464c816_000065_0b20477c+0x5f>
  40e975:	mov    rcx,rsi
  40e978:	mov    rdx,rbx
  40e97b:	call   40b890 <__swc_fn_3464c816_000064_20100e91>
  40e980:	add    rsp,0xe0
  40e987:	pop    r13
  40e989:	pop    r12
  40e98b:	pop    rdi
  40e98c:	pop    rsi
  40e98d:	pop    rbx
  40e98e:	ret
  40e98f:	cmp    QWORD PTR [rbx+0x48],0x0
  40e994:	jne    40e9b0 <__swc_fn_3464c816_000065_0b20477c+0x80>
  40e996:	mov    rcx,rsi
  40e999:	mov    rdx,rbx
  40e99c:	call   407f90 <__swc_fn_3464c816_000066_918d3875>
  40e9a1:	add    rsp,0xe0
  40e9a8:	pop    r13
  40e9aa:	pop    r12
  40e9ac:	pop    rdi
  40e9ad:	pop    rsi
  40e9ae:	pop    rbx
  40e9af:	ret
  40e9b0:	mov    rdi,QWORD PTR [rbx+0x40]
  40e9b4:	lea    rax,[rip+0x156b5]        # 424070 <__swc_bss_base_3464c816+0x30>
  40e9bb:	mov    rcx,rdi
  40e9be:	sub    rcx,QWORD PTR [rax+0x8]
  40e9c2:	mov    rax,QWORD PTR [rip+0x156b7]        # 424080 <__swc_bss_base_3464c816+0x40>
  40e9c9:	cmp    rcx,rax
  40e9cc:	jae    40e9f8 <__swc_fn_3464c816_000065_0b20477c+0xc8>
  40e9ce:	mov    rax,rdi
  40e9d1:	and    rax,0xffffffffffc00000
  40e9d8:	mov    rcx,rdi
  40e9db:	shr    rcx,0x10
  40e9df:	and    ecx,0x3f
  40e9e2:	mov    edx,DWORD PTR [rax+0x28]
  40e9e5:	shrx   ecx,ecx,edx
  40e9ea:	shl    rcx,0x4
  40e9ee:	lea    r12,[rax+rcx*8+0x80]
  40e9f6:	jmp    40ea03 <__swc_fn_3464c816_000065_0b20477c+0xd3>
  40e9f8:	mov    rcx,rdi
  40e9fb:	call   40a910 <__swc_fn_3464c816_000022_53fc00d2>
  40ea00:	mov    r12,rax
  40ea03:	test   r12,r12
  40ea06:	je     40ea15 <__swc_fn_3464c816_000065_0b20477c+0xe5>
  40ea08:	mov    eax,DWORD PTR [r12+0x2c]
  40ea0d:	mov    r9d,eax
  40ea10:	mov    r13,rax
  40ea13:	jmp    40ea94 <__swc_fn_3464c816_000065_0b20477c+0x164>
  40ea15:	mov    rcx,rsi
  40ea18:	mov    rdx,rdi
  40ea1b:	call   40af20 <__swc_fn_3464c816_000052_92b016ae>
  40ea20:	mov    rcx,QWORD PTR [rax+0x28]
  40ea24:	mov    r9,rcx
  40ea27:	mov    rdx,QWORD PTR [rax+0x20]
  40ea2b:	mov    r13,rdx
  40ea2e:	cmp    QWORD PTR [rbx+0x48],rcx
  40ea32:	jbe    40ea6b <__swc_fn_3464c816_000065_0b20477c+0x13b>
  40ea34:	mov    ecx,DWORD PTR [rax+0x48]
  40ea37:	cmp    DWORD PTR [rbx+0x58],ecx
  40ea3a:	ja     40ea6b <__swc_fn_3464c816_000065_0b20477c+0x13b>
  40ea3c:	mov    rcx,rsi
  40ea3f:	mov    rdx,rax
  40ea42:	mov    r8,QWORD PTR [rbx+0x48]
  40ea46:	mov    QWORD PTR [rsp+0xc8],r9
  40ea4e:	mov    QWORD PTR [rsp+0xd0],rax
  40ea56:	call   40e850 <__swc_fn_3464c816_000062_0a65f1d5>
  40ea5b:	mov    r9,QWORD PTR [rsp+0xc8]
  40ea63:	mov    rax,QWORD PTR [rsp+0xd0]
  40ea6b:	mov    rcx,QWORD PTR [rax+0x28]
  40ea6f:	cmp    QWORD PTR [rbx+0x48],rcx
  40ea73:	ja     40ea94 <__swc_fn_3464c816_000065_0b20477c+0x164>
  40ea75:	mov    ecx,DWORD PTR [rax+0x48]
  40ea78:	cmp    DWORD PTR [rbx+0x58],ecx
  40ea7b:	ja     40ea94 <__swc_fn_3464c816_000065_0b20477c+0x164>
  40ea7d:	mov    rcx,QWORD PTR [rbx+0x48]
  40ea81:	mov    QWORD PTR [rax+0x20],rcx
  40ea85:	add    rsp,0xe0
  40ea8c:	pop    r13
  40ea8e:	pop    r12
  40ea90:	pop    rdi
  40ea91:	pop    rsi
  40ea92:	pop    rbx
  40ea93:	ret
  40ea94:	test   r12,r12
  40ea97:	je     40eac9 <__swc_fn_3464c816_000065_0b20477c+0x199>
  40ea99:	cmp    QWORD PTR [rbx+0x48],r9
  40ea9d:	ja     40eac9 <__swc_fn_3464c816_000065_0b20477c+0x199>
  40ea9f:	cmp    DWORD PTR [rbx+0x58],0x40
  40eaa3:	ja     40eac9 <__swc_fn_3464c816_000065_0b20477c+0x199>
  40eaa5:	cmp    DWORD PTR [rbx+0x58],0x0
  40eaa9:	je     40eab6 <__swc_fn_3464c816_000065_0b20477c+0x186>
  40eaab:	mov    ecx,DWORD PTR [rbx+0x58]
  40eaae:	dec    rcx
  40eab1:	test   rdi,rcx
  40eab4:	jne    40eac9 <__swc_fn_3464c816_000065_0b20477c+0x199>
  40eab6:	mov    QWORD PTR [rbx+0x40],rdi
  40eaba:	add    rsp,0xe0
  40eac1:	pop    r13
  40eac3:	pop    r12
  40eac5:	pop    rdi
  40eac6:	pop    rsi
  40eac7:	pop    rbx
  40eac8:	ret
  40eac9:	vmovups xmm0,XMMWORD PTR [rbx]
  40eacd:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ead3:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40ead8:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40eade:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40eae3:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40eae9:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40eaee:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40eaf4:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40eaf9:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40eaff:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40eb04:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40eb0a:	mov    QWORD PTR [rsp+0x48],0x0
  40eb13:	mov    rcx,rsi
  40eb16:	lea    rdx,[rsp+0x8]
  40eb1b:	call   40b890 <__swc_fn_3464c816_000064_20100e91>
  40eb20:	mov    rax,QWORD PTR [rsp+0x48]
  40eb25:	test   rax,rax
  40eb28:	jne    40eb41 <__swc_fn_3464c816_000065_0b20477c+0x211>
  40eb2a:	mov    QWORD PTR [rbx+0x40],0x0
  40eb32:	add    rsp,0xe0
  40eb39:	pop    r13
  40eb3b:	pop    r12
  40eb3d:	pop    rdi
  40eb3e:	pop    rsi
  40eb3f:	pop    rbx
  40eb40:	ret
  40eb41:	mov    rax,QWORD PTR [rbx+0x48]
  40eb45:	cmp    r13,rax
  40eb48:	cmovbe rax,r13
  40eb4c:	mov    rcx,QWORD PTR [rsp+0x48]
  40eb51:	mov    rdx,rdi
  40eb54:	mov    r8,rax
  40eb57:	call   4090e0 <__swc_fn_3464c816_000105_83487ba1>
  40eb5c:	vmovups xmm0,XMMWORD PTR [rbx]
  40eb60:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40eb66:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40eb6b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40eb71:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40eb76:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40eb7f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40eb84:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40eb8d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40eb92:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40eb9b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40eba0:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40eba9:	mov    QWORD PTR [rsp+0xa8],rdi
  40ebb1:	mov    rcx,rsi
  40ebb4:	lea    rdx,[rsp+0x68]
  40ebb9:	call   407f90 <__swc_fn_3464c816_000066_918d3875>
  40ebbe:	mov    rax,QWORD PTR [rsp+0x48]
  40ebc3:	mov    QWORD PTR [rbx+0x40],rax
  40ebc7:	add    rsp,0xe0
  40ebce:	pop    r13
  40ebd0:	pop    r12
  40ebd2:	pop    rdi
  40ebd3:	pop    rsi
  40ebd4:	pop    rbx
  40ebd5:	ret
	...

000000000040ebe0 <__swc_fn_3464c816_000068_f501e74b>:
  40ebe0:	push   r12
  40ebe2:	push   rdi
  40ebe3:	push   rsi
  40ebe4:	push   r13
  40ebe6:	push   r14
  40ebe8:	sub    rsp,0x190
  40ebef:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40ebf8:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40ec01:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40ec0a:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40ec13:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40ec1c:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40ec25:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40ec2e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40ec37:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40ec40:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40ec49:	mov    r12,rcx
  40ec4c:	lea    rax,[rip+0x133ad]        # 422000 <__swc_data_base_3464c816>
  40ec53:	mov    rax,QWORD PTR [rax]
  40ec56:	cmp    rax,0xffffffffffffffff
  40ec5a:	je     40ec69 <__swc_fn_3464c816_000068_f501e74b+0x89>
  40ec5c:	mov    eax,eax
  40ec5e:	mov    edi,eax
  40ec60:	xor    eax,eax
  40ec62:	call   407000 <pthread_getspecific@plt>
  40ec67:	jmp    40ec6b <__swc_fn_3464c816_000068_f501e74b+0x8b>
  40ec69:	xor    eax,eax
  40ec6b:	test   rax,rax
  40ec6e:	jne    40ec7d <__swc_fn_3464c816_000068_f501e74b+0x9d>
  40ec70:	call   40a9e0 <__swc_fn_3464c816_000031_3c3e930e>
  40ec75:	mov    rcx,rax
  40ec78:	call   4103a0 <__swc_fn_3464c816_000128_8d8a7dd2>
  40ec7d:	test   rax,rax
  40ec80:	je     40eca6 <__swc_fn_3464c816_000068_f501e74b+0xc6>
  40ec82:	cmp    QWORD PTR [rax],r12
  40ec85:	jne    40eca6 <__swc_fn_3464c816_000068_f501e74b+0xc6>
  40ec87:	xor    ecx,ecx
  40ec89:	mov    QWORD PTR [rsp+0xc8],rax
  40ec91:	call   407720 <__swc_fn_3464c816_000033_d15eb4ea>
  40ec96:	mov    rdx,QWORD PTR [rsp+0xc8]
  40ec9e:	mov    rcx,r12
  40eca1:	call   407840 <__swc_fn_3464c816_000042_0573444d>
  40eca6:	lea    rsi,[r12+0x10]
  40ecab:	mov    rcx,rsi
  40ecae:	call   4098a0 <__swc_fn_3464c816_000135_db32cc57>
  40ecb3:	mov    rdi,QWORD PTR [r12+0x20]
  40ecb8:	test   rdi,rdi
  40ecbb:	je     40ecfe <__swc_fn_3464c816_000068_f501e74b+0x11e>
  40ecbd:	nop    DWORD PTR [rax]
  40ecc0:	mov    rcx,r12
  40ecc3:	mov    rdx,rdi
  40ecc6:	call   40aba0 <__swc_fn_3464c816_000043_47ff6d9b>
  40eccb:	mov    rcx,r12
  40ecce:	mov    rdx,rdi
  40ecd1:	mov    r8,0xffffffffffffffff
  40ecd8:	call   40e7b0 <__swc_fn_3464c816_000059_ee6a254c>
  40ecdd:	mov    rcx,r12
  40ece0:	mov    rdx,rdi
  40ece3:	mov    r8d,0x9b8
  40ece9:	mov    r9d,0x9b8
  40ecef:	call   407750 <__swc_fn_3464c816_000039_9ae4348f>
  40ecf4:	mov    rdi,QWORD PTR [r12+0x20]
  40ecf9:	test   rdi,rdi
  40ecfc:	jne    40ecc0 <__swc_fn_3464c816_000068_f501e74b+0xe0>
  40ecfe:	xor    eax,eax
  40ed00:	xchg   QWORD PTR [r12+0x2a80],rax
  40ed08:	test   rax,rax
  40ed0b:	je     40ed31 <__swc_fn_3464c816_000068_f501e74b+0x151>
  40ed0d:	cs nop WORD PTR [rax+rax*1+0x0]
  40ed17:	nop    WORD PTR [rax+rax*1+0x0]
  40ed20:	mov    rcx,rax
  40ed23:	mov    rax,QWORD PTR [rax+0x78]
  40ed27:	xor    edx,edx
  40ed29:	xchg   DWORD PTR [rcx+0x70],edx
  40ed2c:	test   rax,rax
  40ed2f:	jne    40ed20 <__swc_fn_3464c816_000068_f501e74b+0x140>
  40ed31:	mov    rax,QWORD PTR [r12+0x18]
  40ed36:	mov    rdi,rax
  40ed39:	test   rdi,rdi
  40ed3c:	je     40edd1 <__swc_fn_3464c816_000068_f501e74b+0x1f1>
  40ed42:	cs nop WORD PTR [rax+rax*1+0x0]
  40ed4c:	nop    DWORD PTR [rax+0x0]
  40ed50:	mov    rax,QWORD PTR [rdi+0x10]
  40ed54:	mov    r8d,DWORD PTR [rdi+0x2c]
  40ed58:	xor    r9d,r9d
  40ed5b:	test   r8,r8
  40ed5e:	jbe    40edbd <__swc_fn_3464c816_000068_f501e74b+0x1dd>
  40ed60:	mov    ecx,r9d
  40ed63:	shl    rcx,0x4
  40ed67:	lea    rdx,[rdi+rcx*8+0x80]
  40ed6f:	cmp    BYTE PTR [rdx+0x3b],0x0
  40ed73:	je     40edb4 <__swc_fn_3464c816_000068_f501e74b+0x1d4>
  40ed75:	mov    DWORD PTR [rdx+0x28],0x0
  40ed7c:	mov    rcx,rdi
  40ed7f:	mov    QWORD PTR [rsp+0xd0],rax
  40ed87:	mov    QWORD PTR [rsp+0xd8],r8
  40ed8f:	mov    QWORD PTR [rsp+0xe0],r9
  40ed97:	call   40dee0 <__swc_fn_3464c816_000014_be17798c>
  40ed9c:	mov    rax,QWORD PTR [rsp+0xd0]
  40eda4:	mov    r8,QWORD PTR [rsp+0xd8]
  40edac:	mov    r9,QWORD PTR [rsp+0xe0]
  40edb4:	add    r9,0x1
  40edb8:	cmp    r9,r8
  40edbb:	jb     40ed60 <__swc_fn_3464c816_000068_f501e74b+0x180>
  40edbd:	mov    rcx,rdi
  40edc0:	mov    rdi,rax
  40edc3:	call   407630 <__swc_fn_3464c816_000021_9cf87641>
  40edc8:	test   rdi,rdi
  40edcb:	jne    40ed50 <__swc_fn_3464c816_000068_f501e74b+0x170>
  40edd1:	mov    QWORD PTR [r12+0x18],0x0
  40edda:	mov    QWORD PTR [r12+0x28],0x0
  40ede3:	mov    rcx,rsi
  40ede6:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  40edeb:	mov    esi,0x8
  40edf0:	xor    edi,edi
  40edf2:	test   rsi,rsi
  40edf5:	je     40ee52 <__swc_fn_3464c816_000068_f501e74b+0x272>
  40edfb:	nop    DWORD PTR [rax+rax*1+0x0]
  40ee00:	lea    r13,[rdi*8+0x0]
  40ee08:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40ee0d:	test   r14,r14
  40ee10:	je     40ee48 <__swc_fn_3464c816_000068_f501e74b+0x268>
  40ee12:	cs nop WORD PTR [rax+rax*1+0x0]
  40ee1c:	nop    DWORD PTR [rax+0x0]
  40ee20:	mov    rcx,r12
  40ee23:	mov    rdx,r14
  40ee26:	call   407df0 <__swc_fn_3464c816_000054_e8e85c01>
  40ee2b:	mov    rcx,r12
  40ee2e:	mov    rdx,QWORD PTR [r14]
  40ee31:	mov    r8,QWORD PTR [r14+0x8]
  40ee35:	mov    r9,QWORD PTR [r14+0x10]
  40ee39:	call   407750 <__swc_fn_3464c816_000039_9ae4348f>
  40ee3e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40ee43:	test   r14,r14
  40ee46:	jne    40ee20 <__swc_fn_3464c816_000068_f501e74b+0x240>
  40ee48:	add    rdi,0x1
  40ee4c:	sub    rsi,0x1
  40ee50:	jne    40ee00 <__swc_fn_3464c816_000068_f501e74b+0x220>
  40ee52:	mov    rcx,r12
  40ee55:	call   407ec0 <__swc_fn_3464c816_000060_6818d0d1>
  40ee5a:	lea    rcx,[r12+0x250]
  40ee62:	mov    rdx,QWORD PTR [rcx]
  40ee65:	mov    r8,QWORD PTR [r12+0x250]
  40ee6d:	nop    DWORD PTR [rax]
  40ee70:	mov    r9,r8
  40ee73:	sub    r9,rdx
  40ee76:	mov    rax,r8
  40ee79:	lock cmpxchg QWORD PTR [rcx],r9
  40ee7e:	cmp    rax,r8
  40ee81:	je     40ee88 <__swc_fn_3464c816_000068_f501e74b+0x2a8>
  40ee83:	mov    r8,rax
  40ee86:	jmp    40ee70 <__swc_fn_3464c816_000068_f501e74b+0x290>
  40ee88:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40ee91:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40ee9a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40eea3:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40eeac:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40eeb5:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40eebe:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40eec7:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40eed0:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40eed9:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40eee2:	add    rsp,0x190
  40eee9:	pop    r14
  40eeeb:	pop    r13
  40eeed:	pop    rsi
  40eeee:	pop    rdi
  40eeef:	pop    r12
  40eef1:	ret
	...

000000000040ef00 <__swc_fn_3464c816_000071_1e1e3bf8>:
  40ef00:	sub    rsp,0x8
  40ef04:	mov    QWORD PTR [rdx+0x40],0x0
  40ef0c:	call   40b890 <__swc_fn_3464c816_000064_20100e91>
  40ef11:	add    rsp,0x8
  40ef15:	ret
	...

000000000040ef20 <__swc_fn_3464c816_000074_30b8696a>:
  40ef20:	sub    rsp,0x8
  40ef24:	call   407f90 <__swc_fn_3464c816_000066_918d3875>
  40ef29:	add    rsp,0x8
  40ef2d:	ret
	...

000000000040ef30 <__swc_fn_3464c816_000077_948ef603>:
  40ef30:	push   rbx
  40ef31:	push   rsi
  40ef32:	push   rdi
  40ef33:	push   r12
  40ef35:	push   r13
  40ef37:	push   r14
  40ef39:	push   r15
  40ef3b:	sub    rsp,0x20
  40ef3f:	mov    rbx,r11
  40ef42:	mov    rsi,rcx
  40ef45:	mov    rdi,rdx
  40ef48:	mov    r12,r8
  40ef4b:	mov    r13,r9
  40ef4e:	mov    r14,r10
  40ef51:	mov    rcx,QWORD PTR [rip+0x17de8]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40ef58:	test   rcx,rcx
  40ef5b:	jne    40ef6d <__swc_fn_3464c816_000077_948ef603+0x3d>
  40ef5d:	call   40a1a0 <__swc_fn_3464c816_000165_56054fe7>
  40ef62:	lea    rcx,[rax+0x1]
  40ef66:	mov    QWORD PTR [rip+0x17dd3],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40ef6d:	dec    rcx
  40ef70:	call   411e20 <__swc_fn_3464c816_000167_39c041ad>
  40ef75:	mov    r15,rax
  40ef78:	lea    r11,[rip+0x152c1]        # 424240 <__swc_bss_base_3464c816+0x200>
  40ef7f:	mov    rcx,r11
  40ef82:	call   407740 <__swc_fn_3464c816_000036_290a131c>
  40ef87:	test   al,al
  40ef89:	jne    40ef9a <__swc_fn_3464c816_000077_948ef603+0x6a>
  40ef8b:	mov    rcx,r11
  40ef8e:	call   40aa40 <__swc_fn_3464c816_000034_cf5ba7bd>
  40ef93:	lea    r11,[rip+0x152a6]        # 424240 <__swc_bss_base_3464c816+0x200>
  40ef9a:	mov    rcx,r11
  40ef9d:	mov    rdx,rsi
  40efa0:	mov    r8,rdi
  40efa3:	mov    r9,r12
  40efa6:	mov    r10,r13
  40efa9:	mov    rsi,r11
  40efac:	mov    r11,r14
  40efaf:	call   40e250 <__swc_fn_3464c816_000035_ab2e8c35>
  40efb4:	test   bl,bl
  40efb6:	je     40efdd <__swc_fn_3464c816_000077_948ef603+0xad>
  40efb8:	mov    QWORD PTR [rsp+0x8],rsi
  40efbd:	lea    rax,[rip+0x418c]        # 413150 <__swc_rdata_base_3464c816+0x40>
  40efc4:	mov    QWORD PTR [rsp+0x10],rax
  40efc9:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40efcf:	vmovups XMMWORD PTR [r15],xmm0
  40efd4:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40efdd:	mov    rax,rsi
  40efe0:	add    rsp,0x20
  40efe4:	pop    r15
  40efe6:	pop    r14
  40efe8:	pop    r13
  40efea:	pop    r12
  40efec:	pop    rdi
  40efed:	pop    rsi
  40efee:	pop    rbx
  40efef:	ret

000000000040eff0 <__swc_fn_3464c816_000080_207908fe>:
  40eff0:	sub    rsp,0x8
  40eff4:	mov    rax,rcx
  40eff7:	test   rcx,rcx
  40effa:	jne    40f001 <__swc_fn_3464c816_000080_207908fe+0x11>
  40effc:	add    rsp,0x8
  40f000:	ret
  40f001:	lea    rcx,[rax-0x10]
  40f005:	mov    rax,QWORD PTR [rax-0x10]
  40f009:	mov    rdx,rax
  40f00c:	call   410050 <__swc_fn_3464c816_000113_4e83a03a>
  40f011:	add    rsp,0x8
  40f015:	ret
	...

000000000040f020 <__swc_fn_3464c816_000083_f2d93dad>:
  40f020:	sub    rsp,0x8
  40f024:	xor    r11d,r11d
  40f027:	call   408250 <__swc_fn_3464c816_000084_5ed30bd6>
  40f02c:	add    rsp,0x8
  40f030:	ret
	...

000000000040f040 <__swc_fn_3464c816_000086_d9243de4>:
  40f040:	push   rsi
  40f041:	push   rdi
  40f042:	push   r12
  40f044:	push   r13
  40f046:	push   r14
  40f048:	push   r15
  40f04a:	sub    rsp,0x68
  40f04e:	mov    rsi,r9
  40f051:	mov    rdi,rcx
  40f054:	mov    r12,rdx
  40f057:	mov    r13,r8
  40f05a:	cmp    r8,r9
  40f05d:	jne    40f085 <__swc_fn_3464c816_000086_d9243de4+0x45>
  40f05f:	mov    rcx,rdi
  40f062:	mov    rdx,r12
  40f065:	xor    r8d,r8d
  40f068:	call   4085a0 <__swc_fn_3464c816_000090_14cf59b2>
  40f06d:	test   al,al
  40f06f:	je     40f085 <__swc_fn_3464c816_000086_d9243de4+0x45>
  40f071:	mov    eax,0x1
  40f076:	add    rsp,0x68
  40f07a:	pop    r15
  40f07c:	pop    r14
  40f07e:	pop    r13
  40f080:	pop    r12
  40f082:	pop    rdi
  40f083:	pop    rsi
  40f084:	ret
  40f085:	cmp    BYTE PTR [r12+0x2c],0xe
  40f08b:	je     40f09e <__swc_fn_3464c816_000086_d9243de4+0x5e>
  40f08d:	xor    eax,eax
  40f08f:	add    rsp,0x68
  40f093:	pop    r15
  40f095:	pop    r14
  40f097:	pop    r13
  40f099:	pop    r12
  40f09b:	pop    rdi
  40f09c:	pop    rsi
  40f09d:	ret
  40f09e:	mov    r14,QWORD PTR [r12+0x98]
  40f0a6:	mov    rax,QWORD PTR [r12+0xa0]
  40f0ae:	mov    r12,rax
  40f0b1:	xor    r15d,r15d
  40f0b4:	test   r12,r12
  40f0b7:	je     40f11f <__swc_fn_3464c816_000086_d9243de4+0xdf>
  40f0b9:	nop    DWORD PTR [rax+0x0]
  40f0c0:	mov    QWORD PTR [rsp+0x58],r12
  40f0c5:	lea    r12,[r15*8+0x0]
  40f0cd:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40f0d2:	mov    rcx,rax
  40f0d5:	call   40c020 <__swc_fn_3464c816_000082_ff7d1455>
  40f0da:	cmp    BYTE PTR [rax+0x2c],0xe
  40f0de:	jne    40f110 <__swc_fn_3464c816_000086_d9243de4+0xd0>
  40f0e0:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40f0e5:	lea    r8,[r13+rcx*1+0x0]
  40f0ea:	mov    rcx,rdi
  40f0ed:	mov    rdx,rax
  40f0f0:	mov    r9,rsi
  40f0f3:	call   40f040 <__swc_fn_3464c816_000086_d9243de4>
  40f0f8:	test   al,al
  40f0fa:	je     40f110 <__swc_fn_3464c816_000086_d9243de4+0xd0>
  40f0fc:	mov    eax,0x1
  40f101:	add    rsp,0x68
  40f105:	pop    r15
  40f107:	pop    r14
  40f109:	pop    r13
  40f10b:	pop    r12
  40f10d:	pop    rdi
  40f10e:	pop    rsi
  40f10f:	ret
  40f110:	add    r15,0x1
  40f114:	mov    r12,QWORD PTR [rsp+0x58]
  40f119:	sub    r12,0x1
  40f11d:	jne    40f0c0 <__swc_fn_3464c816_000086_d9243de4+0x80>
  40f11f:	xor    eax,eax
  40f121:	add    rsp,0x68
  40f125:	pop    r15
  40f127:	pop    r14
  40f129:	pop    r13
  40f12b:	pop    r12
  40f12d:	pop    rdi
  40f12e:	pop    rsi
  40f12f:	ret

000000000040f130 <__swc_fn_3464c816_000089_3c530920>:
  40f130:	push   rbp
  40f131:	push   rbx
  40f132:	push   rsi
  40f133:	push   rdi
  40f134:	push   r12
  40f136:	push   r13
  40f138:	push   r14
  40f13a:	push   r15
  40f13c:	sub    rsp,0x38
  40f140:	mov    rbp,rsp
  40f143:	mov    rbx,r11
  40f146:	mov    rsi,rdx
  40f149:	mov    rdi,r8
  40f14c:	mov    r12,r9
  40f14f:	mov    QWORD PTR [rsp+0x18],r9
  40f154:	mov    r13,r10
  40f157:	movzx  r14d,BYTE PTR [rbp+0x80]
  40f15f:	movzx  r15d,BYTE PTR [rbp+0x88]
  40f167:	test   r11,r11
  40f16a:	je     40f170 <__swc_fn_3464c816_000089_3c530920+0x40>
  40f16c:	xor    eax,eax
  40f16e:	mov    BYTE PTR [rbx],al
  40f170:	test   r12,r12
  40f173:	je     40f17e <__swc_fn_3464c816_000089_3c530920+0x4e>
  40f175:	mov    QWORD PTR [r12+0x8],0x0
  40f17e:	test   rcx,rcx
  40f181:	je     40f188 <__swc_fn_3464c816_000089_3c530920+0x58>
  40f183:	test   rsi,rsi
  40f186:	jne    40f19b <__swc_fn_3464c816_000089_3c530920+0x6b>
  40f188:	xor    eax,eax
  40f18a:	add    rsp,0x38
  40f18e:	pop    r15
  40f190:	pop    r14
  40f192:	pop    r13
  40f194:	pop    r12
  40f196:	pop    rdi
  40f197:	pop    rsi
  40f198:	pop    rbx
  40f199:	pop    rbp
  40f19a:	ret
  40f19b:	call   40c020 <__swc_fn_3464c816_000082_ff7d1455>
  40f1a0:	mov    r12,rax
  40f1a3:	mov    al,r15b
  40f1a6:	test   r15b,r15b
  40f1a9:	jne    40f1b9 <__swc_fn_3464c816_000089_3c530920+0x89>
  40f1ab:	mov    eax,DWORD PTR [r12+0x28]
  40f1b0:	and    eax,0x10000
  40f1b6:	setne  al
  40f1b9:	lea    r15,[rsp+0x8]
  40f1be:	mov    QWORD PTR [rsp+0x20],r15
  40f1c3:	rex mov BYTE PTR [rsp+0x8],al
  40f1c8:	test   DWORD PTR [rsi+0x28],0x400000
  40f1cf:	je     40f207 <__swc_fn_3464c816_000089_3c530920+0xd7>
  40f1d1:	test   rsi,rsi
  40f1d4:	je     40f1f4 <__swc_fn_3464c816_000089_3c530920+0xc4>
  40f1d6:	mov    rax,QWORD PTR [rsi+0x38]
  40f1da:	cmp    QWORD PTR [rax+0x10],rsi
  40f1de:	jne    40f1f4 <__swc_fn_3464c816_000089_3c530920+0xc4>
  40f1e0:	rex mov al,BYTE PTR [rsp+0x8]
  40f1e5:	test   al,al
  40f1e7:	sete   al
  40f1ea:	test   r14b,r14b
  40f1ed:	sete   cl
  40f1f0:	test   al,cl
  40f1f2:	je     40f207 <__swc_fn_3464c816_000089_3c530920+0xd7>
  40f1f4:	xor    eax,eax
  40f1f6:	add    rsp,0x38
  40f1fa:	pop    r15
  40f1fc:	pop    r14
  40f1fe:	pop    r13
  40f200:	pop    r12
  40f202:	pop    rdi
  40f203:	pop    rsi
  40f204:	pop    rbx
  40f205:	pop    rbp
  40f206:	ret
  40f207:	mov    r15,r12
  40f20a:	test   r14b,r14b
  40f20d:	jne    40f224 <__swc_fn_3464c816_000089_3c530920+0xf4>
  40f20f:	cmp    BYTE PTR [r12+0x2c],0x6
  40f215:	jne    40f224 <__swc_fn_3464c816_000089_3c530920+0xf4>
  40f217:	mov    rcx,QWORD PTR [r12+0x40]
  40f21c:	call   40c020 <__swc_fn_3464c816_000082_ff7d1455>
  40f221:	mov    r15,rax
  40f224:	test   r14b,r14b
  40f227:	je     40f22d <__swc_fn_3464c816_000089_3c530920+0xfd>
  40f229:	mov    r15,QWORD PTR [r15+0x30]
  40f22d:	mov    rcx,rsi
  40f230:	call   40c020 <__swc_fn_3464c816_000082_ff7d1455>
  40f235:	mov    rsi,rax
  40f238:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f23d:	je     40f274 <__swc_fn_3464c816_000089_3c530920+0x144>
  40f23f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f244:	je     40f274 <__swc_fn_3464c816_000089_3c530920+0x144>
  40f246:	mov    eax,DWORD PTR [rsi+0x28]
  40f249:	and    eax,0x10000
  40f24f:	je     40f274 <__swc_fn_3464c816_000089_3c530920+0x144>
  40f251:	rex mov al,BYTE PTR [rsp+0x8]
  40f256:	test   al,al
  40f258:	jne    40f26d <__swc_fn_3464c816_000089_3c530920+0x13d>
  40f25a:	xor    eax,eax
  40f25c:	add    rsp,0x38
  40f260:	pop    r15
  40f262:	pop    r14
  40f264:	pop    r13
  40f266:	pop    r12
  40f268:	pop    rdi
  40f269:	pop    rsi
  40f26a:	pop    rbx
  40f26b:	pop    rbp
  40f26c:	ret
  40f26d:	mov    rax,QWORD PTR [rsi+0x30]
  40f271:	mov    rsi,rax
  40f274:	mov    r14b,r13b
  40f277:	test   rbx,rbx
  40f27a:	je     40f2b0 <__swc_fn_3464c816_000089_3c530920+0x180>
  40f27c:	cmp    BYTE PTR [r12+0x2c],0x6
  40f282:	jne    40f2b0 <__swc_fn_3464c816_000089_3c530920+0x180>
  40f284:	lea    rdx,[rip+0x3ef5]        # 413180 <__swc_rdata_base_3464c816+0x70>
  40f28b:	mov    rcx,rsi
  40f28e:	xor    r8d,r8d
  40f291:	call   4085a0 <__swc_fn_3464c816_000090_14cf59b2>
  40f296:	test   al,al
  40f298:	je     40f2b0 <__swc_fn_3464c816_000089_3c530920+0x180>
  40f29a:	mov    BYTE PTR [rbx],0x1
  40f29d:	xor    eax,eax
  40f29f:	add    rsp,0x38
  40f2a3:	pop    r15
  40f2a5:	pop    r14
  40f2a7:	pop    r13
  40f2a9:	pop    r12
  40f2ab:	pop    rdi
  40f2ac:	pop    rsi
  40f2ad:	pop    rbx
  40f2ae:	pop    rbp
  40f2af:	ret
  40f2b0:	test   rdi,rdi
  40f2b3:	jne    40f2cd <__swc_fn_3464c816_000089_3c530920+0x19d>
  40f2b5:	test   r13b,r13b
  40f2b8:	jne    40f2cd <__swc_fn_3464c816_000089_3c530920+0x19d>
  40f2ba:	xor    eax,eax
  40f2bc:	add    rsp,0x38
  40f2c0:	pop    r15
  40f2c2:	pop    r14
  40f2c4:	pop    r13
  40f2c6:	pop    r12
  40f2c8:	pop    rdi
  40f2c9:	pop    rsi
  40f2ca:	pop    rbx
  40f2cb:	pop    rbp
  40f2cc:	ret
  40f2cd:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f2d2:	jne    40f388 <__swc_fn_3464c816_000089_3c530920+0x258>
  40f2d8:	mov    rcx,r15
  40f2db:	mov    rdx,rsi
  40f2de:	xor    r8d,r8d
  40f2e1:	call   4085a0 <__swc_fn_3464c816_000090_14cf59b2>
  40f2e6:	test   al,al
  40f2e8:	jne    40f388 <__swc_fn_3464c816_000089_3c530920+0x258>
  40f2ee:	test   DWORD PTR [rsi+0x28],0x10000
  40f2f5:	je     40f313 <__swc_fn_3464c816_000089_3c530920+0x1e3>
  40f2f7:	rex mov al,BYTE PTR [rsp+0x8]
  40f2fc:	test   al,al
  40f2fe:	jne    40f313 <__swc_fn_3464c816_000089_3c530920+0x1e3>
  40f300:	xor    eax,eax
  40f302:	add    rsp,0x38
  40f306:	pop    r15
  40f308:	pop    r14
  40f30a:	pop    r13
  40f30c:	pop    r12
  40f30e:	pop    rdi
  40f30f:	pop    rsi
  40f310:	pop    rbx
  40f311:	pop    rbp
  40f312:	ret
  40f313:	test   rdi,rdi
  40f316:	jne    40f32b <__swc_fn_3464c816_000089_3c530920+0x1fb>
  40f318:	xor    eax,eax
  40f31a:	add    rsp,0x38
  40f31e:	pop    r15
  40f320:	pop    r14
  40f322:	pop    r13
  40f324:	pop    r12
  40f326:	pop    rdi
  40f327:	pop    rsi
  40f328:	pop    rbx
  40f329:	pop    rbp
  40f32a:	ret
  40f32b:	mov    rcx,QWORD PTR [rsi+0x40]
  40f32f:	call   40c020 <__swc_fn_3464c816_000082_ff7d1455>
  40f334:	mov    rsi,rax
  40f337:	mov    rax,QWORD PTR [rdi]
  40f33a:	mov    rdi,rax
  40f33d:	test   rax,rax
  40f340:	jne    40f383 <__swc_fn_3464c816_000089_3c530920+0x253>
  40f342:	test   rbx,rbx
  40f345:	je     40f383 <__swc_fn_3464c816_000089_3c530920+0x253>
  40f347:	mov    rcx,r15
  40f34a:	mov    rdx,rsi
  40f34d:	xor    r8d,r8d
  40f350:	call   4085a0 <__swc_fn_3464c816_000090_14cf59b2>
  40f355:	mov    rcx,rax
  40f358:	test   al,al
  40f35a:	jne    40f37c <__swc_fn_3464c816_000089_3c530920+0x24c>
  40f35c:	mov    rcx,r15
  40f35f:	mov    rdx,rsi
  40f362:	call   40c060 <__swc_fn_3464c816_000085_e24ecd12>
  40f367:	mov    rcx,rax
  40f36a:	test   al,al
  40f36c:	jne    40f37c <__swc_fn_3464c816_000089_3c530920+0x24c>
  40f36e:	mov    rcx,rsi
  40f371:	mov    rdx,r15
  40f374:	call   40c060 <__swc_fn_3464c816_000085_e24ecd12>
  40f379:	mov    rcx,rax
  40f37c:	test   cl,cl
  40f37e:	setne  al
  40f381:	mov    BYTE PTR [rbx],al
  40f383:	xor    eax,eax
  40f385:	mov    r14b,al
  40f388:	test   rdi,rdi
  40f38b:	jne    40f3a5 <__swc_fn_3464c816_000089_3c530920+0x275>
  40f38d:	test   r14b,r14b
  40f390:	jne    40f3a5 <__swc_fn_3464c816_000089_3c530920+0x275>
  40f392:	xor    eax,eax
  40f394:	add    rsp,0x38
  40f398:	pop    r15
  40f39a:	pop    r14
  40f39c:	pop    r13
  40f39e:	pop    r12
  40f3a0:	pop    rdi
  40f3a1:	pop    rsi
  40f3a2:	pop    rbx
  40f3a3:	pop    rbp
  40f3a4:	ret
  40f3a5:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f3aa:	je     40f3b6 <__swc_fn_3464c816_000089_3c530920+0x286>
  40f3ac:	mov    r12,QWORD PTR [rsp+0x18]
  40f3b1:	jmp    40f43e <__swc_fn_3464c816_000089_3c530920+0x30e>
  40f3b6:	mov    r12,QWORD PTR [rsp+0x18]
  40f3bb:	test   r12,r12
  40f3be:	jne    40f3d2 <__swc_fn_3464c816_000089_3c530920+0x2a2>
  40f3c0:	mov    rcx,r15
  40f3c3:	mov    rdx,rsi
  40f3c6:	xor    r8d,r8d
  40f3c9:	call   4085a0 <__swc_fn_3464c816_000090_14cf59b2>
  40f3ce:	test   al,al
  40f3d0:	jne    40f43e <__swc_fn_3464c816_000089_3c530920+0x30e>
  40f3d2:	test   DWORD PTR [rsi+0x28],0x10000
  40f3d9:	je     40f3f7 <__swc_fn_3464c816_000089_3c530920+0x2c7>
  40f3db:	rex mov al,BYTE PTR [rsp+0x8]
  40f3e0:	test   al,al
  40f3e2:	jne    40f3f7 <__swc_fn_3464c816_000089_3c530920+0x2c7>
  40f3e4:	xor    eax,eax
  40f3e6:	add    rsp,0x38
  40f3ea:	pop    r15
  40f3ec:	pop    r14
  40f3ee:	pop    r13
  40f3f0:	pop    r12
  40f3f2:	pop    rdi
  40f3f3:	pop    rsi
  40f3f4:	pop    rbx
  40f3f5:	pop    rbp
  40f3f6:	ret
  40f3f7:	test   rdi,rdi
  40f3fa:	jne    40f40f <__swc_fn_3464c816_000089_3c530920+0x2df>
  40f3fc:	xor    eax,eax
  40f3fe:	add    rsp,0x38
  40f402:	pop    r15
  40f404:	pop    r14
  40f406:	pop    r13
  40f408:	pop    r12
  40f40a:	pop    rdi
  40f40b:	pop    rsi
  40f40c:	pop    rbx
  40f40d:	pop    rbp
  40f40e:	ret
  40f40f:	cmp    QWORD PTR [rdi+0x8],0x0
  40f414:	jne    40f429 <__swc_fn_3464c816_000089_3c530920+0x2f9>
  40f416:	xor    eax,eax
  40f418:	add    rsp,0x38
  40f41c:	pop    r15
  40f41e:	pop    r14
  40f420:	pop    r13
  40f422:	pop    r12
  40f424:	pop    rdi
  40f425:	pop    rsi
  40f426:	pop    rbx
  40f427:	pop    rbp
  40f428:	ret
  40f429:	mov    rax,QWORD PTR [rdi+0x8]
  40f42d:	mov    rax,QWORD PTR [rax]
  40f430:	mov    rsi,rax
  40f433:	mov    rdi,QWORD PTR [rdi]
  40f436:	mov    eax,0x1
  40f43b:	mov    r14b,al
  40f43e:	test   rdi,rdi
  40f441:	mov    rbx,QWORD PTR [rsp+0x20]
  40f446:	jne    40f490 <__swc_fn_3464c816_000089_3c530920+0x360>
  40f448:	test   r14b,r14b
  40f44b:	je     40f47d <__swc_fn_3464c816_000089_3c530920+0x34d>
  40f44d:	test   r12,r12
  40f450:	je     40f47d <__swc_fn_3464c816_000089_3c530920+0x34d>
  40f452:	mov    rcx,r15
  40f455:	mov    rdx,rsi
  40f458:	xor    r8d,r8d
  40f45b:	mov    r9,r12
  40f45e:	mov    rbx,QWORD PTR [rsp+0x20]
  40f463:	movzx  r10d,BYTE PTR [rbx]
  40f467:	call   40f020 <__swc_fn_3464c816_000083_f2d93dad>
  40f46c:	add    rsp,0x38
  40f470:	pop    r15
  40f472:	pop    r14
  40f474:	pop    r13
  40f476:	pop    r12
  40f478:	pop    rdi
  40f479:	pop    rsi
  40f47a:	pop    rbx
  40f47b:	pop    rbp
  40f47c:	ret
  40f47d:	xor    eax,eax
  40f47f:	add    rsp,0x38
  40f483:	pop    r15
  40f485:	pop    r14
  40f487:	pop    r13
  40f489:	pop    r12
  40f48b:	pop    rdi
  40f48c:	pop    rsi
  40f48d:	pop    rbx
  40f48e:	pop    rbp
  40f48f:	ret
  40f490:	mov    r13,rsi
  40f493:	mov    QWORD PTR [rsp+0x28],rdi
  40f498:	cmp    BYTE PTR [r15+0x2c],0xe
  40f49d:	sete   al
  40f4a0:	mov    r14b,al
  40f4a3:	jne    40f4b7 <__swc_fn_3464c816_000089_3c530920+0x387>
  40f4a5:	mov    rcx,rsi
  40f4a8:	mov    rdx,r15
  40f4ab:	call   40c060 <__swc_fn_3464c816_000085_e24ecd12>
  40f4b0:	mov    r14b,al
  40f4b3:	test   al,al
  40f4b5:	jne    40f4ec <__swc_fn_3464c816_000089_3c530920+0x3bc>
  40f4b7:	cmp    BYTE PTR [r15+0x2c],0x12
  40f4bc:	je     40f4ec <__swc_fn_3464c816_000089_3c530920+0x3bc>
  40f4be:	mov    rcx,r15
  40f4c1:	mov    rdx,rsi
  40f4c4:	mov    r8,rdi
  40f4c7:	mov    r9,r12
  40f4ca:	mov    rax,rbx
  40f4cd:	movzx  r10d,BYTE PTR [rax]
  40f4d1:	call   40f020 <__swc_fn_3464c816_000083_f2d93dad>
  40f4d6:	test   rax,rax
  40f4d9:	je     40f4ec <__swc_fn_3464c816_000089_3c530920+0x3bc>
  40f4db:	add    rsp,0x38
  40f4df:	pop    r15
  40f4e1:	pop    r14
  40f4e3:	pop    r13
  40f4e5:	pop    r12
  40f4e7:	pop    rdi
  40f4e8:	pop    rsi
  40f4e9:	pop    rbx
  40f4ea:	pop    rbp
  40f4eb:	ret
  40f4ec:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40f4f1:	jne    40f510 <__swc_fn_3464c816_000089_3c530920+0x3e0>
  40f4f3:	mov    rax,QWORD PTR [rsi+0xd8]
  40f4fa:	test   rax,rax
  40f4fd:	je     40f510 <__swc_fn_3464c816_000089_3c530920+0x3e0>
  40f4ff:	add    rdi,QWORD PTR [rax+0x8]
  40f503:	mov    rax,QWORD PTR [rdi]
  40f506:	sub    rdi,QWORD PTR [rax+0x8]
  40f50a:	mov    rax,QWORD PTR [rax]
  40f50d:	mov    rsi,rax
  40f510:	test   r14b,r14b
  40f513:	je     40f53f <__swc_fn_3464c816_000089_3c530920+0x40f>
  40f515:	mov    rcx,r15
  40f518:	mov    rdx,rsi
  40f51b:	mov    r8,rdi
  40f51e:	mov    r9,r13
  40f521:	mov    r14,QWORD PTR [rsp+0x28]
  40f526:	mov    r10,r14
  40f529:	call   408480 <__swc_fn_3464c816_000087_693f118e>
  40f52e:	add    rsp,0x38
  40f532:	pop    r15
  40f534:	pop    r14
  40f536:	pop    r13
  40f538:	pop    r12
  40f53a:	pop    rdi
  40f53b:	pop    rsi
  40f53c:	pop    rbx
  40f53d:	pop    rbp
  40f53e:	ret
  40f53f:	mov    rcx,r15
  40f542:	mov    rdx,rsi
  40f545:	mov    r8,rdi
  40f548:	mov    r9,r12
  40f54b:	movzx  r10d,BYTE PTR [rbx]
  40f54f:	call   40f020 <__swc_fn_3464c816_000083_f2d93dad>
  40f554:	add    rsp,0x38
  40f558:	pop    r15
  40f55a:	pop    r14
  40f55c:	pop    r13
  40f55e:	pop    r12
  40f560:	pop    rdi
  40f561:	pop    rsi
  40f562:	pop    rbx
  40f563:	pop    rbp
  40f564:	ret
	...

000000000040f570 <__swc_fn_3464c816_000092_809deff5>:
  40f570:	push   rbx
  40f571:	push   rsi
  40f572:	sub    rsp,0x18
  40f576:	mov    rbx,rcx
  40f579:	mov    rcx,QWORD PTR [rip+0x177c0]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40f580:	test   rcx,rcx
  40f583:	jne    40f595 <__swc_fn_3464c816_000092_809deff5+0x25>
  40f585:	call   40a1a0 <__swc_fn_3464c816_000165_56054fe7>
  40f58a:	lea    rcx,[rax+0x1]
  40f58e:	mov    QWORD PTR [rip+0x177ab],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  40f595:	dec    rcx
  40f598:	call   411e20 <__swc_fn_3464c816_000167_39c041ad>
  40f59d:	mov    rsi,rax
  40f5a0:	mov    rax,QWORD PTR [rsi+0x8]
  40f5a4:	test   rax,rax
  40f5a7:	jne    40f5f7 <__swc_fn_3464c816_000092_809deff5+0x87>
  40f5a9:	call   40c150 <__swc_fn_3464c816_000091_f21926ed>
  40f5ae:	test   al,al
  40f5b0:	jne    40f5f7 <__swc_fn_3464c816_000092_809deff5+0x87>
  40f5b2:	lea    rdx,[rip+0x14c87]        # 424240 <__swc_bss_base_3464c816+0x200>
  40f5b9:	mov    rcx,rdx
  40f5bc:	call   407740 <__swc_fn_3464c816_000036_290a131c>
  40f5c1:	test   al,al
  40f5c3:	jne    40f5d4 <__swc_fn_3464c816_000092_809deff5+0x64>
  40f5c5:	mov    rcx,rdx
  40f5c8:	call   40aa40 <__swc_fn_3464c816_000034_cf5ba7bd>
  40f5cd:	lea    rdx,[rip+0x14c6c]        # 424240 <__swc_bss_base_3464c816+0x200>
  40f5d4:	mov    QWORD PTR [rsp+0x8],rdx
  40f5d9:	lea    rax,[rip+0x3b70]        # 413150 <__swc_rdata_base_3464c816+0x40>
  40f5e0:	mov    QWORD PTR [rsp+0x10],rax
  40f5e5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f5eb:	vmovups XMMWORD PTR [rsi],xmm0
  40f5ef:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40f5f7:	vmovups xmm0,XMMWORD PTR [rsi]
  40f5fb:	vmovups XMMWORD PTR [rbx],xmm0
  40f5ff:	mov    rax,rbx
  40f602:	add    rsp,0x18
  40f606:	pop    rsi
  40f607:	pop    rbx
  40f608:	ret
  40f609:	add    BYTE PTR [rax],al
  40f60b:	add    BYTE PTR [rax],al
  40f60d:	add    BYTE PTR [rax],al
	...

000000000040f610 <__swc_fn_3464c816_000095_8cc4b392>:
  40f610:	sub    rsp,0x8
  40f614:	call   409340 <__swc_fn_3464c816_000117_5aba1420>
  40f619:	add    rsp,0x8
  40f61d:	ret
	...

000000000040f620 <__swc_fn_3464c816_000098_f82a1ed3>:
  40f620:	push   rbx
  40f621:	push   rsi
  40f622:	sub    rsp,0x28
  40f626:	mov    rbx,rcx
  40f629:	xor    esi,esi
  40f62b:	jmp    40f640 <__swc_fn_3464c816_000098_f82a1ed3+0x20>
  40f62d:	nop    DWORD PTR [rax]
  40f630:	mov    QWORD PTR [rbx+0x28],rsi
  40f634:	mov    rsi,rbx
  40f637:	mov    rbx,rax
  40f63a:	nop    WORD PTR [rax+rax*1+0x0]
  40f640:	test   rbx,rbx
  40f643:	je     40f6a3 <__swc_fn_3464c816_000098_f82a1ed3+0x83>
  40f645:	mov    rcx,rbx
  40f648:	mov    edx,0x1
  40f64d:	call   408200 <__swc_fn_3464c816_000078_140918ec>
  40f652:	cmp    rax,0x1
  40f656:	jne    40f6a3 <__swc_fn_3464c816_000098_f82a1ed3+0x83>
  40f658:	mov    r10,QWORD PTR [rbx+0x18]
  40f65c:	mov    rcx,r10
  40f65f:	mov    edx,0x1
  40f664:	call   408200 <__swc_fn_3464c816_000078_140918ec>
  40f669:	cmp    rax,0x1
  40f66d:	jne    40f67c <__swc_fn_3464c816_000098_f82a1ed3+0x5c>
  40f66f:	mov    rcx,r10
  40f672:	call   40c2f0 <__swc_fn_3464c816_000097_96d6739a>
  40f677:	test   rax,rax
  40f67a:	jne    40f630 <__swc_fn_3464c816_000098_f82a1ed3+0x10>
  40f67c:	mov    rax,QWORD PTR [rbx+0x20]
  40f680:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40f685:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f68b:	lea    rcx,[rsp+0x8]
  40f690:	mov    rdx,rbx
  40f693:	mov    r8d,0x30
  40f699:	mov    rbx,rax
  40f69c:	call   408960 <__swc_fn_3464c816_000096_a4baaa40>
  40f6a1:	jmp    40f640 <__swc_fn_3464c816_000098_f82a1ed3+0x20>
  40f6a3:	test   rsi,rsi
  40f6a6:	jne    40f6af <__swc_fn_3464c816_000098_f82a1ed3+0x8f>
  40f6a8:	add    rsp,0x28
  40f6ac:	pop    rsi
  40f6ad:	pop    rbx
  40f6ae:	ret
  40f6af:	mov    rax,rsi
  40f6b2:	mov    rsi,QWORD PTR [rsi+0x28]
  40f6b6:	mov    rbx,QWORD PTR [rax+0x20]
  40f6ba:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40f6bf:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f6c5:	lea    rcx,[rsp+0x18]
  40f6ca:	mov    rdx,rax
  40f6cd:	mov    r8d,0x30
  40f6d3:	call   408960 <__swc_fn_3464c816_000096_a4baaa40>
  40f6d8:	jmp    40f640 <__swc_fn_3464c816_000098_f82a1ed3+0x20>
  40f6dd:	add    BYTE PTR [rax],al
	...

000000000040f6e0 <__swc_fn_3464c816_000101_afcb7774>:
  40f6e0:	push   rbx
  40f6e1:	push   rsi
  40f6e2:	push   rdi
  40f6e3:	push   r12
  40f6e5:	push   r13
  40f6e7:	sub    rsp,0x20
  40f6eb:	mov    rbx,rcx
  40f6ee:	lea    rsi,[rcx+0x6f8]
  40f6f5:	mov    edi,0x4
  40f6fa:	mov    r12,rsi
  40f6fd:	test   rdi,rdi
  40f700:	je     40f74a <__swc_fn_3464c816_000101_afcb7774+0x6a>
  40f702:	cs nop WORD PTR [rax+rax*1+0x0]
  40f70c:	nop    DWORD PTR [rax+0x0]
  40f710:	mov    rcx,QWORD PTR [r12+0x10]
  40f715:	mov    QWORD PTR [r12+0x10],0x0
  40f71e:	vxorps xmm0,xmm0,xmm0
  40f722:	vmovups XMMWORD PTR [r12],xmm0
  40f728:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40f72f:	mov    DWORD PTR [r12+0x20],0x0
  40f738:	call   4089b0 <__swc_fn_3464c816_000099_5232b57d>
  40f73d:	add    r12,0x90
  40f744:	sub    rdi,0x1
  40f748:	jne    40f710 <__swc_fn_3464c816_000101_afcb7774+0x30>
  40f74a:	mov    rax,QWORD PTR [rbx+0x938]
  40f751:	mov    rdi,rax
  40f754:	test   rdi,rdi
  40f757:	je     40f7b1 <__swc_fn_3464c816_000101_afcb7774+0xd1>
  40f759:	nop    DWORD PTR [rax+0x0]
  40f760:	mov    r12d,0x10
  40f766:	lea    r13,[rdi+0x18]
  40f76a:	test   r12,r12
  40f76d:	je     40f7a6 <__swc_fn_3464c816_000101_afcb7774+0xc6>
  40f76f:	nop
  40f770:	mov    rcx,QWORD PTR [r13+0x10]
  40f774:	mov    QWORD PTR [r13+0x10],0x0
  40f77c:	vxorps xmm0,xmm0,xmm0
  40f780:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40f786:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40f78c:	mov    DWORD PTR [r13+0x20],0x0
  40f794:	call   4089b0 <__swc_fn_3464c816_000099_5232b57d>
  40f799:	add    r13,0x90
  40f7a0:	sub    r12,0x1
  40f7a4:	jne    40f770 <__swc_fn_3464c816_000101_afcb7774+0x90>
  40f7a6:	mov    rax,QWORD PTR [rdi]
  40f7a9:	mov    rdi,rax
  40f7ac:	test   rax,rax
  40f7af:	jne    40f760 <__swc_fn_3464c816_000101_afcb7774+0x80>
  40f7b1:	vxorps xmm0,xmm0,xmm0
  40f7b5:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40f7bd:	mov    DWORD PTR [rbx+0x9b0],0x0
  40f7c7:	mov    DWORD PTR [rbx+0x9a8],0x0
  40f7d1:	mov    edi,0x4
  40f7d6:	mov    r12,rsi
  40f7d9:	lea    rsi,[rsi+0x38]
  40f7dd:	test   rdi,rdi
  40f7e0:	je     40f80c <__swc_fn_3464c816_000101_afcb7774+0x12c>
  40f7e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f7ec:	nop    DWORD PTR [rax+0x0]
  40f7f0:	mov    rcx,rsi
  40f7f3:	call   40d170 <__swc_fn_3464c816_000157_3495a3ca>
  40f7f8:	add    rsi,0x90
  40f7ff:	add    r12,0x90
  40f806:	sub    rdi,0x1
  40f80a:	jne    40f7f0 <__swc_fn_3464c816_000101_afcb7774+0x110>
  40f80c:	mov    rax,QWORD PTR [rbx+0x938]
  40f813:	mov    rdi,rax
  40f816:	mov    QWORD PTR [rbx+0x938],0x0
  40f821:	test   rdi,rdi
  40f824:	je     40f895 <__swc_fn_3464c816_000101_afcb7774+0x1b5>
  40f82a:	nop    WORD PTR [rax+rax*1+0x0]
  40f830:	mov    esi,0x10
  40f835:	lea    r12,[rdi+0x18]
  40f839:	lea    r13,[rdi+0x50]
  40f83d:	test   rsi,rsi
  40f840:	je     40f86c <__swc_fn_3464c816_000101_afcb7774+0x18c>
  40f842:	cs nop WORD PTR [rax+rax*1+0x0]
  40f84c:	nop    DWORD PTR [rax+0x0]
  40f850:	mov    rcx,r13
  40f853:	call   40d170 <__swc_fn_3464c816_000157_3495a3ca>
  40f858:	add    r13,0x90
  40f85f:	add    r12,0x90
  40f866:	sub    rsi,0x1
  40f86a:	jne    40f850 <__swc_fn_3464c816_000101_afcb7774+0x170>
  40f86c:	mov    rax,QWORD PTR [rdi]
  40f86f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40f874:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f87a:	lea    rcx,[rsp+0x8]
  40f87f:	mov    rdx,rdi
  40f882:	mov    r8d,0x918
  40f888:	mov    rdi,rax
  40f88b:	call   408960 <__swc_fn_3464c816_000096_a4baaa40>
  40f890:	test   rdi,rdi
  40f893:	jne    40f830 <__swc_fn_3464c816_000101_afcb7774+0x150>
  40f895:	lea    rcx,[rbx+0x68]
  40f899:	call   40d170 <__swc_fn_3464c816_000157_3495a3ca>
  40f89e:	add    rsp,0x20
  40f8a2:	pop    r13
  40f8a4:	pop    r12
  40f8a6:	pop    rdi
  40f8a7:	pop    rsi
  40f8a8:	pop    rbx
  40f8a9:	ret
  40f8aa:	add    BYTE PTR [rax],al
  40f8ac:	add    BYTE PTR [rax],al
	...

000000000040f8b0 <__swc_fn_3464c816_000104_04d1a8be>:
  40f8b0:	xor    eax,eax
  40f8b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f8bc:	nop    DWORD PTR [rax+0x0]
  40f8c0:	mov    r9,r8
  40f8c3:	sub    r9,rax
  40f8c6:	cmp    r9,0x40
  40f8ca:	jb     40f908 <__swc_fn_3464c816_000104_04d1a8be+0x58>
  40f8cc:	lea    r9,[rcx+rax*1]
  40f8d0:	lea    r10,[rdx+rax*1]
  40f8d4:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40f8da:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40f8e0:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40f8e6:	vmovups xmm3,XMMWORD PTR [r10]
  40f8eb:	vmovups XMMWORD PTR [r9],xmm3
  40f8f0:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40f8f6:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40f8fc:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40f902:	lea    rax,[rax+0x40]
  40f906:	jmp    40f8c0 <__swc_fn_3464c816_000104_04d1a8be+0x10>
  40f908:	nop    DWORD PTR [rax+rax*1+0x0]
  40f910:	mov    r9,r8
  40f913:	sub    r9,rax
  40f916:	cmp    r9,0x10
  40f91a:	jb     40f934 <__swc_fn_3464c816_000104_04d1a8be+0x84>
  40f91c:	lea    r9,[rdx+rax*1]
  40f920:	lea    r10,[rcx+rax*1]
  40f924:	vmovups xmm0,XMMWORD PTR [r9]
  40f929:	vmovups XMMWORD PTR [r10],xmm0
  40f92e:	lea    rax,[rax+0x10]
  40f932:	jmp    40f910 <__swc_fn_3464c816_000104_04d1a8be+0x60>
  40f934:	cs nop WORD PTR [rax+rax*1+0x0]
  40f93e:	xchg   ax,ax
  40f940:	mov    r9,r8
  40f943:	sub    r9,rax
  40f946:	cmp    r9,0x8
  40f94a:	jb     40f95d <__swc_fn_3464c816_000104_04d1a8be+0xad>
  40f94c:	lea    r9,[rcx+rax*1]
  40f950:	mov    r10,QWORD PTR [rdx+rax*1]
  40f954:	mov    QWORD PTR [r9],r10
  40f957:	lea    rax,[rax+0x8]
  40f95b:	jmp    40f940 <__swc_fn_3464c816_000104_04d1a8be+0x90>
  40f95d:	cmp    rax,r8
  40f960:	jae    40f980 <__swc_fn_3464c816_000104_04d1a8be+0xd0>
  40f962:	cs nop WORD PTR [rax+rax*1+0x0]
  40f96c:	nop    DWORD PTR [rax+0x0]
  40f970:	mov    r9b,BYTE PTR [rdx+rax*1]
  40f974:	mov    BYTE PTR [rcx+rax*1],r9b
  40f978:	inc    rax
  40f97b:	cmp    rax,r8
  40f97e:	jb     40f970 <__swc_fn_3464c816_000104_04d1a8be+0xc0>
  40f980:	ret
	...

000000000040f990 <__swc_fn_3464c816_000107_c8d4a68e>:
  40f990:	push   rbx
  40f991:	push   r12
  40f993:	push   rdi
  40f994:	push   rsi
  40f995:	push   r13
  40f997:	push   r14
  40f999:	push   r15
  40f99b:	sub    rsp,0x170
  40f9a2:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40f9ab:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40f9b4:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40f9bd:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40f9c6:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40f9cf:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40f9d8:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40f9e1:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40f9ea:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40f9f3:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40f9fc:	mov    ebx,edx
  40f9fe:	mov    QWORD PTR [rsp+0xa8],rbx
  40fa06:	mov    r12d,ecx
  40fa09:	test   edx,edx
  40fa0b:	jne    40fa22 <__swc_fn_3464c816_000107_c8d4a68e+0x92>
  40fa0d:	xor    eax,eax
  40fa0f:	add    rsp,0x170
  40fa16:	pop    r15
  40fa18:	pop    r14
  40fa1a:	pop    r13
  40fa1c:	pop    rsi
  40fa1d:	pop    rdi
  40fa1e:	pop    r12
  40fa20:	pop    rbx
  40fa21:	ret
  40fa22:	lea    rdi,[rip+0x3a87]        # 4134b0 <__swc_rdata_base_3464c816+0x3a0>
  40fa29:	mov    esi,0x90000
  40fa2e:	xor    eax,eax
  40fa30:	call   407090 <open@plt>
  40fa35:	mov    r13,rax
  40fa38:	mov    QWORD PTR [rsp+0xb0],rax
  40fa40:	test   eax,eax
  40fa42:	jge    40fa4b <__swc_fn_3464c816_000107_c8d4a68e+0xbb>
  40fa44:	xor    eax,eax
  40fa46:	jmp    40ff46 <__swc_fn_3464c816_000107_c8d4a68e+0x5b6>
  40fa4b:	nop    DWORD PTR [rax+rax*1+0x0]
  40fa50:	movsxd rdi,r13d
  40fa53:	mov    esi,0x2
  40fa58:	xor    eax,eax
  40fa5a:	call   407120 <flock@plt>
  40fa5f:	test   eax,eax
  40fa61:	je     40fa80 <__swc_fn_3464c816_000107_c8d4a68e+0xf0>
  40fa63:	xor    eax,eax
  40fa65:	call   407130 <__errno_location@plt>
  40fa6a:	cmp    DWORD PTR [rax],0x4
  40fa6d:	je     40fa50 <__swc_fn_3464c816_000107_c8d4a68e+0xc0>
  40fa6f:	movsxd rdi,r13d
  40fa72:	xor    eax,eax
  40fa74:	call   4070b0 <close@plt>
  40fa79:	xor    eax,eax
  40fa7b:	jmp    40ff46 <__swc_fn_3464c816_000107_c8d4a68e+0x5b6>
  40fa80:	lea    r14,[rsp+0x8]
  40fa85:	mov    QWORD PTR [rsp+0xb8],r14
  40fa8d:	vxorps xmm0,xmm0,xmm0
  40fa91:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40fa97:	mov    QWORD PTR [rsp+0x18],0x0
  40faa0:	mov    WORD PTR [rsp+0x20],0x0
  40faa7:	mov    DWORD PTR [r14],0x67617753
  40faae:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40fab6:	xor    eax,eax
  40fab8:	call   407010 <getpid@plt>
  40fabd:	mov    ecx,eax
  40fabf:	mov    eax,0x1c
  40fac4:	shrx   eax,ecx,eax
  40fac9:	and    eax,0xf
  40facc:	mov    rdx,QWORD PTR [rip+0x39fd]        # 4134d0 <__swc_rdata_base_3464c816+0x3c0>
  40fad3:	mov    al,BYTE PTR [rdx+rax*1]
  40fad6:	rex mov BYTE PTR [rsp+0x10],al
  40fadb:	mov    eax,0x1c
  40fae0:	shrx   eax,r12d,eax
  40fae5:	and    eax,0xf
  40fae8:	mov    al,BYTE PTR [rdx+rax*1]
  40faeb:	rex mov BYTE PTR [rsp+0x19],al
  40faf0:	mov    eax,0x18
  40faf5:	shrx   eax,ecx,eax
  40fafa:	and    eax,0xf
  40fafd:	mov    al,BYTE PTR [rdx+rax*1]
  40fb00:	rex mov BYTE PTR [rsp+0x11],al
  40fb05:	mov    eax,0x18
  40fb0a:	shrx   eax,r12d,eax
  40fb0f:	and    eax,0xf
  40fb12:	mov    al,BYTE PTR [rdx+rax*1]
  40fb15:	rex mov BYTE PTR [rsp+0x1a],al
  40fb1a:	mov    eax,0x14
  40fb1f:	shrx   eax,ecx,eax
  40fb24:	and    eax,0xf
  40fb27:	mov    al,BYTE PTR [rdx+rax*1]
  40fb2a:	rex mov BYTE PTR [rsp+0x12],al
  40fb2f:	mov    eax,0x14
  40fb34:	shrx   eax,r12d,eax
  40fb39:	and    eax,0xf
  40fb3c:	mov    al,BYTE PTR [rdx+rax*1]
  40fb3f:	rex mov BYTE PTR [rsp+0x1b],al
  40fb44:	mov    eax,0x10
  40fb49:	shrx   eax,ecx,eax
  40fb4e:	and    eax,0xf
  40fb51:	mov    al,BYTE PTR [rdx+rax*1]
  40fb54:	rex mov BYTE PTR [rsp+0x13],al
  40fb59:	mov    eax,0x10
  40fb5e:	shrx   eax,r12d,eax
  40fb63:	and    eax,0xf
  40fb66:	mov    al,BYTE PTR [rdx+rax*1]
  40fb69:	rex mov BYTE PTR [rsp+0x1c],al
  40fb6e:	mov    eax,0xc
  40fb73:	shrx   eax,ecx,eax
  40fb78:	and    eax,0xf
  40fb7b:	mov    al,BYTE PTR [rdx+rax*1]
  40fb7e:	rex mov BYTE PTR [rsp+0x14],al
  40fb83:	mov    eax,0xc
  40fb88:	shrx   eax,r12d,eax
  40fb8d:	and    eax,0xf
  40fb90:	mov    al,BYTE PTR [rdx+rax*1]
  40fb93:	rex mov BYTE PTR [rsp+0x1d],al
  40fb98:	mov    eax,0x8
  40fb9d:	shrx   eax,ecx,eax
  40fba2:	and    eax,0xf
  40fba5:	mov    al,BYTE PTR [rdx+rax*1]
  40fba8:	rex mov BYTE PTR [rsp+0x15],al
  40fbad:	mov    eax,0x8
  40fbb2:	shrx   eax,r12d,eax
  40fbb7:	and    eax,0xf
  40fbba:	mov    al,BYTE PTR [rdx+rax*1]
  40fbbd:	rex mov BYTE PTR [rsp+0x1e],al
  40fbc2:	mov    eax,0x4
  40fbc7:	shrx   eax,ecx,eax
  40fbcc:	and    eax,0xf
  40fbcf:	mov    al,BYTE PTR [rdx+rax*1]
  40fbd2:	rex mov BYTE PTR [rsp+0x16],al
  40fbd7:	mov    eax,0x4
  40fbdc:	shrx   eax,r12d,eax
  40fbe1:	and    eax,0xf
  40fbe4:	mov    al,BYTE PTR [rdx+rax*1]
  40fbe7:	rex mov BYTE PTR [rsp+0x1f],al
  40fbec:	xor    eax,eax
  40fbee:	shrx   eax,ecx,eax
  40fbf3:	and    eax,0xf
  40fbf6:	mov    al,BYTE PTR [rdx+rax*1]
  40fbf9:	rex mov BYTE PTR [rsp+0x17],al
  40fbfe:	xor    eax,eax
  40fc00:	shrx   eax,r12d,eax
  40fc05:	and    eax,0xf
  40fc08:	mov    al,BYTE PTR [rdx+rax*1]
  40fc0b:	rex mov BYTE PTR [rsp+0x20],al
  40fc10:	mov    BYTE PTR [r14+0x10],0x2e
  40fc15:	lea    r12,[rsp+0x22]
  40fc1a:	vxorps xmm0,xmm0,xmm0
  40fc1e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40fc24:	mov    DWORD PTR [r12],0x6d656d2f
  40fc2c:	mov    WORD PTR [r12+0x4],0x6466
  40fc34:	mov    BYTE PTR [r12+0x6],0x3a
  40fc3a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40fc40:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40fc46:	mov    rax,QWORD PTR [rsp+0x18]
  40fc4b:	mov    QWORD PTR [rsp+0x39],rax
  40fc50:	rex mov al,BYTE PTR [rsp+0x20]
  40fc55:	rex mov BYTE PTR [rsp+0x41],al
  40fc5a:	mov    DWORD PTR [r12+0x20],0x65642820
  40fc63:	mov    DWORD PTR [r12+0x24],0x6574656c
  40fc6c:	mov    WORD PTR [r12+0x28],0x2964
  40fc74:	lea    rdi,[rip+0x3840]        # 4134bb <__swc_rdata_base_3464c816+0x3ab>
  40fc7b:	xor    eax,eax
  40fc7d:	call   407140 <opendir@plt>
  40fc82:	mov    r15,rax
  40fc85:	test   rax,rax
  40fc88:	jne    40fc9b <__swc_fn_3464c816_000107_c8d4a68e+0x30b>
  40fc8a:	movsxd rdi,r13d
  40fc8d:	xor    eax,eax
  40fc8f:	call   4070b0 <close@plt>
  40fc94:	xor    eax,eax
  40fc96:	jmp    40ff46 <__swc_fn_3464c816_000107_c8d4a68e+0x5b6>
  40fc9b:	mov    rdi,r15
  40fc9e:	xor    eax,eax
  40fca0:	call   407150 <dirfd@plt>
  40fca5:	lea    r14,[rsp+0x54]
  40fcaa:	mov    DWORD PTR [rsp+0x54],eax
  40fcae:	lea    rbx,[rsp+0x58]
  40fcb3:	cs nop WORD PTR [rax+rax*1+0x0]
  40fcbd:	nop    DWORD PTR [rax]
  40fcc0:	mov    rdi,r15
  40fcc3:	xor    eax,eax
  40fcc5:	call   407160 <readdir@plt>
  40fcca:	test   rax,rax
  40fccd:	jne    40fce4 <__swc_fn_3464c816_000107_c8d4a68e+0x354>
  40fccf:	mov    r12,QWORD PTR [rsp+0xa8]
  40fcd7:	mov    r13,QWORD PTR [rsp+0xb0]
  40fcdf:	jmp    40fe6a <__swc_fn_3464c816_000107_c8d4a68e+0x4da>
  40fce4:	vxorps xmm0,xmm0,xmm0
  40fce8:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  40fcee:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  40fcf4:	vzeroupper
  40fcf7:	lea    r13,[rax+0x13]
  40fcfb:	mov    rax,r14
  40fcfe:	movsxd rdi,DWORD PTR [rax]
  40fd01:	mov    rsi,r13
  40fd04:	mov    rdx,rbx
  40fd07:	mov    ecx,0x40
  40fd0c:	xor    eax,eax
  40fd0e:	call   407170 <readlinkat@plt>
  40fd13:	cmp    rax,0x2a
  40fd17:	jne    40fcc0 <__swc_fn_3464c816_000107_c8d4a68e+0x330>
  40fd19:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40fd1f:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40fd25:	vptest xmm0,xmm0
  40fd2a:	jne    40fd5a <__swc_fn_3464c816_000107_c8d4a68e+0x3ca>
  40fd2c:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40fd32:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40fd38:	vptest xmm0,xmm0
  40fd3d:	jne    40fd5a <__swc_fn_3464c816_000107_c8d4a68e+0x3ca>
  40fd3f:	mov    rcx,QWORD PTR [rsp+0x42]
  40fd44:	cmp    QWORD PTR [rsp+0x78],rcx
  40fd49:	jne    40fd5a <__swc_fn_3464c816_000107_c8d4a68e+0x3ca>
  40fd4b:	mov    cx,WORD PTR [rsp+0x4a]
  40fd50:	cmp    WORD PTR [rsp+0x80],cx
  40fd58:	je     40fd84 <__swc_fn_3464c816_000107_c8d4a68e+0x3f4>
  40fd5a:	mov    rax,rbx
  40fd5d:	mov    rcx,r12
  40fd60:	movzx  edx,BYTE PTR [rax]
  40fd63:	movzx  r8d,BYTE PTR [rcx]
  40fd67:	cmp    rdx,r8
  40fd6a:	jne    40fd76 <__swc_fn_3464c816_000107_c8d4a68e+0x3e6>
  40fd6c:	add    rax,0x1
  40fd70:	add    rcx,0x1
  40fd74:	jmp    40fd60 <__swc_fn_3464c816_000107_c8d4a68e+0x3d0>
  40fd76:	mov    rax,rdx
  40fd79:	sub    rax,r8
  40fd7c:	test   eax,eax
  40fd7e:	jne    40fcc0 <__swc_fn_3464c816_000107_c8d4a68e+0x330>
  40fd84:	movsxd rdi,DWORD PTR [r14]
  40fd87:	mov    rsi,r13
  40fd8a:	mov    edx,0x80002
  40fd8f:	xor    eax,eax
  40fd91:	call   407180 <openat@plt>
  40fd96:	lea    rbx,[rsp+0x98]
  40fd9e:	mov    DWORD PTR [rsp+0x98],eax
  40fda5:	test   eax,eax
  40fda7:	mov    r13,QWORD PTR [rsp+0xb0]
  40fdaf:	jge    40fdd4 <__swc_fn_3464c816_000107_c8d4a68e+0x444>
  40fdb1:	mov    rdi,r15
  40fdb4:	xor    eax,eax
  40fdb6:	call   407190 <closedir@plt>
  40fdbb:	mov    r13,QWORD PTR [rsp+0xb0]
  40fdc3:	movsxd rdi,r13d
  40fdc6:	xor    eax,eax
  40fdc8:	call   4070b0 <close@plt>
  40fdcd:	xor    eax,eax
  40fdcf:	jmp    40ff46 <__swc_fn_3464c816_000107_c8d4a68e+0x5b6>
  40fdd4:	mov    rax,rbx
  40fdd7:	movsxd rdi,DWORD PTR [rax]
  40fdda:	xor    esi,esi
  40fddc:	mov    edx,0x2
  40fde1:	xor    eax,eax
  40fde3:	call   4070a0 <lseek@plt>
  40fde8:	mov    r12,QWORD PTR [rsp+0xa8]
  40fdf0:	cmp    rax,r12
  40fdf3:	je     40fe1a <__swc_fn_3464c816_000107_c8d4a68e+0x48a>
  40fdf5:	movsxd rdi,DWORD PTR [rbx]
  40fdf8:	xor    eax,eax
  40fdfa:	call   4070b0 <close@plt>
  40fdff:	mov    rdi,r15
  40fe02:	xor    eax,eax
  40fe04:	call   407190 <closedir@plt>
  40fe09:	movsxd rdi,r13d
  40fe0c:	xor    eax,eax
  40fe0e:	call   4070b0 <close@plt>
  40fe13:	xor    eax,eax
  40fe15:	jmp    40ff46 <__swc_fn_3464c816_000107_c8d4a68e+0x5b6>
  40fe1a:	xor    edi,edi
  40fe1c:	mov    rsi,r12
  40fe1f:	mov    edx,0x3
  40fe24:	mov    ecx,0x1
  40fe29:	mov    rax,rbx
  40fe2c:	movsxd r8,DWORD PTR [rax]
  40fe2f:	xor    r9d,r9d
  40fe32:	xor    eax,eax
  40fe34:	call   4070c0 <mmap@plt>
  40fe39:	xor    r12d,r12d
  40fe3c:	cmp    rax,0xffffffffffffffff
  40fe40:	cmovne r12,rax
  40fe44:	movsxd rdi,DWORD PTR [rbx]
  40fe47:	xor    eax,eax
  40fe49:	call   4070b0 <close@plt>
  40fe4e:	mov    rdi,r15
  40fe51:	xor    eax,eax
  40fe53:	call   407190 <closedir@plt>
  40fe58:	movsxd rdi,r13d
  40fe5b:	xor    eax,eax
  40fe5d:	call   4070b0 <close@plt>
  40fe62:	mov    rax,r12
  40fe65:	jmp    40ff46 <__swc_fn_3464c816_000107_c8d4a68e+0x5b6>
  40fe6a:	mov    r14,QWORD PTR [rsp+0xb8]
  40fe72:	mov    rdi,r14
  40fe75:	mov    esi,0x1
  40fe7a:	xor    eax,eax
  40fe7c:	call   4071a0 <memfd_create@plt>
  40fe81:	lea    rbx,[rsp+0x9c]
  40fe89:	mov    DWORD PTR [rsp+0x9c],eax
  40fe90:	test   eax,eax
  40fe92:	jge    40feaf <__swc_fn_3464c816_000107_c8d4a68e+0x51f>
  40fe94:	mov    rdi,r15
  40fe97:	xor    eax,eax
  40fe99:	call   407190 <closedir@plt>
  40fe9e:	movsxd rdi,r13d
  40fea1:	xor    eax,eax
  40fea3:	call   4070b0 <close@plt>
  40fea8:	xor    eax,eax
  40feaa:	jmp    40ff46 <__swc_fn_3464c816_000107_c8d4a68e+0x5b6>
  40feaf:	mov    rax,rbx
  40feb2:	movsxd rdi,DWORD PTR [rax]
  40feb5:	mov    rsi,r12
  40feb8:	xor    eax,eax
  40feba:	call   4071b0 <ftruncate@plt>
  40febf:	test   eax,eax
  40fec1:	je     40fee5 <__swc_fn_3464c816_000107_c8d4a68e+0x555>
  40fec3:	movsxd rdi,DWORD PTR [rbx]
  40fec6:	xor    eax,eax
  40fec8:	call   4070b0 <close@plt>
  40fecd:	mov    rdi,r15
  40fed0:	xor    eax,eax
  40fed2:	call   407190 <closedir@plt>
  40fed7:	movsxd rdi,r13d
  40feda:	xor    eax,eax
  40fedc:	call   4070b0 <close@plt>
  40fee1:	xor    eax,eax
  40fee3:	jmp    40ff46 <__swc_fn_3464c816_000107_c8d4a68e+0x5b6>
  40fee5:	xor    edi,edi
  40fee7:	mov    rsi,r12
  40feea:	mov    edx,0x3
  40feef:	mov    ecx,0x1
  40fef4:	mov    rax,rbx
  40fef7:	movsxd r8,DWORD PTR [rax]
  40fefa:	xor    r9d,r9d
  40fefd:	xor    eax,eax
  40feff:	call   4070c0 <mmap@plt>
  40ff04:	mov    r12,rax
  40ff07:	cmp    rax,0xffffffffffffffff
  40ff0b:	jne    40ff2f <__swc_fn_3464c816_000107_c8d4a68e+0x59f>
  40ff0d:	movsxd rdi,DWORD PTR [rbx]
  40ff10:	xor    eax,eax
  40ff12:	call   4070b0 <close@plt>
  40ff17:	mov    rdi,r15
  40ff1a:	xor    eax,eax
  40ff1c:	call   407190 <closedir@plt>
  40ff21:	movsxd rdi,r13d
  40ff24:	xor    eax,eax
  40ff26:	call   4070b0 <close@plt>
  40ff2b:	xor    eax,eax
  40ff2d:	jmp    40ff46 <__swc_fn_3464c816_000107_c8d4a68e+0x5b6>
  40ff2f:	mov    rdi,r15
  40ff32:	xor    eax,eax
  40ff34:	call   407190 <closedir@plt>
  40ff39:	movsxd rdi,r13d
  40ff3c:	xor    eax,eax
  40ff3e:	call   4070b0 <close@plt>
  40ff43:	mov    rax,r12
  40ff46:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40ff4f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40ff58:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40ff61:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40ff6a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  40ff73:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40ff7c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  40ff85:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40ff8e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  40ff97:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  40ffa0:	add    rsp,0x170
  40ffa7:	pop    r15
  40ffa9:	pop    r14
  40ffab:	pop    r13
  40ffad:	pop    rsi
  40ffae:	pop    rdi
  40ffaf:	pop    r12
  40ffb1:	pop    rbx
  40ffb2:	ret
	...

000000000040ffc0 <__swc_fn_3464c816_000110_918d5a21>:
  40ffc0:	push   rsi
  40ffc1:	push   rdi
  40ffc2:	push   r12
  40ffc4:	push   r13
  40ffc6:	sub    rsp,0x8
  40ffca:	mov    rsi,r8
  40ffcd:	mov    rdi,rcx
  40ffd0:	mov    r12,rdx
  40ffd3:	call   409100 <__swc_fn_3464c816_000108_b8f4bd15>
  40ffd8:	mov    r13,rax
  40ffdb:	test   rax,rax
  40ffde:	jne    40ffeb <__swc_fn_3464c816_000110_918d5a21+0x2b>
  40ffe0:	add    rsp,0x8
  40ffe4:	pop    r13
  40ffe6:	pop    r12
  40ffe8:	pop    rdi
  40ffe9:	pop    rsi
  40ffea:	ret
  40ffeb:	mov    rcx,r13
  40ffee:	call   40cd70 <__swc_fn_3464c816_000133_807fd51d>
  40fff3:	mov    rax,QWORD PTR [r13+0x8]
  40fff7:	test   rax,rax
  40fffa:	je     410039 <__swc_fn_3464c816_000110_918d5a21+0x79>
  40fffc:	nop    DWORD PTR [rax+0x0]
  410000:	lea    rcx,[rax+0x1000]
  410007:	cmp    rdi,rcx
  41000a:	jne    410031 <__swc_fn_3464c816_000110_918d5a21+0x71>
  41000c:	cmp    r12,0x1000
  410013:	jb     410031 <__swc_fn_3464c816_000110_918d5a21+0x71>
  410015:	test   sil,sil
  410018:	setne  cl
  41001b:	mov    BYTE PTR [rax+0x10],cl
  41001e:	mov    rcx,r13
  410021:	call   410520 <__swc_fn_3464c816_000134_10472836>
  410026:	add    rsp,0x8
  41002a:	pop    r13
  41002c:	pop    r12
  41002e:	pop    rdi
  41002f:	pop    rsi
  410030:	ret
  410031:	mov    rax,QWORD PTR [rax]
  410034:	test   rax,rax
  410037:	jne    410000 <__swc_fn_3464c816_000110_918d5a21+0x40>
  410039:	mov    rcx,r13
  41003c:	call   410520 <__swc_fn_3464c816_000134_10472836>
  410041:	add    rsp,0x8
  410045:	pop    r13
  410047:	pop    r12
  410049:	pop    rdi
  41004a:	pop    rsi
  41004b:	ret
  41004c:	add    BYTE PTR [rax],al
	...

0000000000410050 <__swc_fn_3464c816_000113_4e83a03a>:
  410050:	sub    rsp,0x8
  410054:	test   rcx,rcx
  410057:	jne    41005e <__swc_fn_3464c816_000113_4e83a03a+0xe>
  410059:	add    rsp,0x8
  41005d:	ret
  41005e:	call   40c880 <__swc_fn_3464c816_000115_3f6af4b1>
  410063:	add    rsp,0x8
  410067:	ret
	...

0000000000410070 <__swc_fn_3464c816_000116_3f5cfdef>:
  410070:	push   r12
  410072:	push   r13
  410074:	push   r14
  410076:	push   rdi
  410077:	push   rsi
  410078:	sub    rsp,0xc0
  41007f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  410085:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  41008b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  410091:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410097:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  41009d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4100a3:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4100a9:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4100b2:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4100bb:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4100c4:	mov    r12,QWORD PTR [rcx]
  4100c7:	test   r12,r12
  4100ca:	jne    4100dc <__swc_fn_3464c816_000116_3f5cfdef+0x6c>
  4100cc:	add    rsp,0xc0
  4100d3:	pop    rsi
  4100d4:	pop    rdi
  4100d5:	pop    r14
  4100d7:	pop    r13
  4100d9:	pop    r12
  4100db:	ret
  4100dc:	xor    r13d,r13d
  4100df:	mov    r14,QWORD PTR [rcx+0x8]
  4100e3:	cs nop WORD PTR [rax+rax*1+0x0]
  4100ed:	nop    DWORD PTR [rax]
  4100f0:	cmp    r13,r14
  4100f3:	jae    41012b <__swc_fn_3464c816_000116_3f5cfdef+0xbb>
  4100f5:	lea    rax,[r12+r13*1]
  4100f9:	mov    rcx,r14
  4100fc:	sub    rcx,r13
  4100ff:	mov    edi,0x1
  410104:	mov    rsi,rax
  410107:	mov    rdx,rcx
  41010a:	xor    eax,eax
  41010c:	call   4071c0 <write@plt>
  410111:	test   rax,rax
  410114:	jle    41011b <__swc_fn_3464c816_000116_3f5cfdef+0xab>
  410116:	add    r13,rax
  410119:	jmp    4100f0 <__swc_fn_3464c816_000116_3f5cfdef+0x80>
  41011b:	je     410129 <__swc_fn_3464c816_000116_3f5cfdef+0xb9>
  41011d:	xor    eax,eax
  41011f:	call   407130 <__errno_location@plt>
  410124:	cmp    DWORD PTR [rax],0x4
  410127:	je     4100f0 <__swc_fn_3464c816_000116_3f5cfdef+0x80>
  410129:	jmp    41012b <__swc_fn_3464c816_000116_3f5cfdef+0xbb>
  41012b:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410131:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  410137:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  41013d:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  410143:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410149:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  41014f:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  410155:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  41015e:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  410167:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410170:	add    rsp,0xc0
  410177:	pop    rsi
  410178:	pop    rdi
  410179:	pop    r14
  41017b:	pop    r13
  41017d:	pop    r12
  41017f:	ret

0000000000410180 <__swc_fn_3464c816_000119_2d9caf16>:
  410180:	push   rbx
  410181:	push   r12
  410183:	push   rdi
  410184:	push   rsi
  410185:	sub    rsp,0x4a8
  41018c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  410195:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  41019e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  4101a7:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  4101b0:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  4101b9:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  4101c2:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  4101cb:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  4101d4:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  4101dd:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  4101e6:	mov    rbx,rdx
  4101e9:	mov    r12d,ecx
  4101ec:	vxorps xmm0,xmm0,xmm0
  4101f0:	xor    eax,eax
  4101f2:	cs nop WORD PTR [rax+rax*1+0x0]
  4101fc:	nop    DWORD PTR [rax+0x0]
  410200:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  410206:	add    rax,0x10
  41020a:	cmp    rax,0x400
  410211:	jne    410200 <__swc_fn_3464c816_000119_2d9caf16+0x80>
  410213:	lea    rdi,[rsp+0x8]
  410218:	mov    esi,0x80
  41021d:	xor    eax,eax
  41021f:	call   4071d0 <backtrace@plt>
  410224:	test   eax,eax
  410226:	jle    410235 <__swc_fn_3464c816_000119_2d9caf16+0xb5>
  410228:	movsxd rax,eax
  41022b:	lea    rcx,[r12+0x1]
  410230:	cmp    rcx,rax
  410233:	jb     410239 <__swc_fn_3464c816_000119_2d9caf16+0xb9>
  410235:	xor    eax,eax
  410237:	jmp    41026a <__swc_fn_3464c816_000119_2d9caf16+0xea>
  410239:	mov    rcx,QWORD PTR [rbx+0x8]
  41023d:	sub    rax,r12
  410240:	lea    rsi,[rax-0x1]
  410244:	cmp    rcx,rsi
  410247:	cmovbe rsi,rcx
  41024b:	lea    eax,[r12+0x1]
  410250:	lea    rax,[rsp+rax*8+0x8]
  410255:	mov    rcx,QWORD PTR [rbx]
  410258:	mov    rdx,rax
  41025b:	lea    r8,[rsi*8+0x0]
  410263:	call   4090e0 <__swc_fn_3464c816_000105_83487ba1>
  410268:	mov    eax,esi
  41026a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  410273:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  41027c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  410285:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  41028e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  410297:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  4102a0:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  4102a9:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  4102b2:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  4102bb:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  4102c4:	add    rsp,0x4a8
  4102cb:	pop    rsi
  4102cc:	pop    rdi
  4102cd:	pop    r12
  4102cf:	pop    rbx
  4102d0:	ret
	...

00000000004102e0 <__swc_fn_3464c816_000122_66e5d2a9>:
  4102e0:	mov    QWORD PTR [rcx],0x0
  4102e7:	ret
	...

00000000004102f0 <__swc_fn_3464c816_000125_7a81492f>:
  4102f0:	push   rdi
  4102f1:	push   rsi
  4102f2:	sub    rsp,0xa8
  4102f9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4102ff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410305:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41030b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410311:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410317:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41031d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410323:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410329:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410332:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41033b:	mov    edi,ecx
  41033d:	mov    rsi,rdx
  410340:	xor    eax,eax
  410342:	call   407060 <pthread_setspecific@plt>
  410347:	test   eax,eax
  410349:	sete   al
  41034c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410352:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410358:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41035e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410364:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  41036a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410370:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410376:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  41037c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410385:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41038e:	add    rsp,0xa8
  410395:	pop    rsi
  410396:	pop    rdi
  410397:	ret
	...

00000000004103a0 <__swc_fn_3464c816_000128_8d8a7dd2>:
  4103a0:	push   rdi
  4103a1:	push   rsi
  4103a2:	sub    rsp,0xa8
  4103a9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4103af:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4103b5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4103bb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4103c1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4103c7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4103cd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4103d3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4103d9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4103e2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4103eb:	test   rcx,rcx
  4103ee:	je     410401 <__swc_fn_3464c816_000128_8d8a7dd2+0x61>
  4103f0:	lea    rax,[rcx-0x1]
  4103f4:	mov    eax,eax
  4103f6:	mov    edi,eax
  4103f8:	xor    eax,eax
  4103fa:	call   407000 <pthread_getspecific@plt>
  4103ff:	jmp    410403 <__swc_fn_3464c816_000128_8d8a7dd2+0x63>
  410401:	xor    eax,eax
  410403:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410409:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  41040f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410415:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41041b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410421:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410427:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41042d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410433:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41043c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410445:	add    rsp,0xa8
  41044c:	pop    rsi
  41044d:	pop    rdi
  41044e:	ret
	...

0000000000410450 <__swc_fn_3464c816_000131_91db8856>:
  410450:	push   rdi
  410451:	push   rsi
  410452:	sub    rsp,0xb8
  410459:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41045f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410465:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41046b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410471:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410477:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41047d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410483:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41048c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410495:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41049e:	vxorps xmm0,xmm0,xmm0
  4104a2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4104a8:	mov    edi,0x1
  4104ad:	lea    rsi,[rsp+0x8]
  4104b2:	xor    eax,eax
  4104b4:	call   4070e0 <clock_gettime@plt>
  4104b9:	mov    rax,QWORD PTR [rsp+0x8]
  4104be:	imul   rax,rax,0x3b9aca00
  4104c5:	add    rax,QWORD PTR [rsp+0x10]
  4104ca:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4104d0:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4104d6:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4104dc:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4104e2:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4104e8:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4104ee:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4104f4:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4104fd:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  410506:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  41050f:	add    rsp,0xb8
  410516:	pop    rsi
  410517:	pop    rdi
  410518:	ret
  410519:	add    BYTE PTR [rax],al
  41051b:	add    BYTE PTR [rax],al
  41051d:	add    BYTE PTR [rax],al
	...

0000000000410520 <__swc_fn_3464c816_000134_10472836>:
  410520:	sub    rsp,0x8
  410524:	xor    eax,eax
  410526:	mov    DWORD PTR [rcx],eax
  410528:	mov    edx,0x7fffffff
  41052d:	call   4097e0 <__swc_fn_3464c816_000132_51cc49e7>
  410532:	add    rsp,0x8
  410536:	ret
	...

0000000000410540 <__swc_fn_3464c816_000137_2d595cc7>:
  410540:	push   rdi
  410541:	push   rsi
  410542:	sub    rsp,0xb8
  410549:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41054f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410555:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41055b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410561:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410567:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41056d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410573:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41057c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410585:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41058e:	mov    edi,0x1
  410593:	xor    eax,eax
  410595:	call   4071e0 <__x86_get_cpuid_feature_leaf@plt>
  41059a:	mov    eax,DWORD PTR [rax+0x14]
  41059d:	and    eax,0x20
  4105a0:	setne  al
  4105a3:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4105a9:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4105af:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4105b5:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4105bb:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4105c1:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4105c7:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4105cd:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4105d6:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4105df:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4105e8:	add    rsp,0xb8
  4105ef:	pop    rsi
  4105f0:	pop    rdi
  4105f1:	ret
	...

0000000000410600 <__swc_fn_3464c816_000140_55003b6d>:
  410600:	push   rsi
  410601:	push   rdi
  410602:	push   r12
  410604:	push   r13
  410606:	push   r14
  410608:	push   r15
  41060a:	cmp    rdx,0x40
  41060e:	jae    41061d <__swc_fn_3464c816_000140_55003b6d+0x1d>
  410610:	xor    eax,eax
  410612:	pop    r15
  410614:	pop    r14
  410616:	pop    r13
  410618:	pop    r12
  41061a:	pop    rdi
  41061b:	pop    rsi
  41061c:	ret
  41061d:	cmp    BYTE PTR [rcx],0x7f
  410620:	jne    410664 <__swc_fn_3464c816_000140_55003b6d+0x64>
  410622:	movzx  eax,BYTE PTR [rcx+0x1]
  410626:	cmp    eax,0x45
  410629:	setne  al
  41062c:	jne    410660 <__swc_fn_3464c816_000140_55003b6d+0x60>
  41062e:	movzx  eax,BYTE PTR [rcx+0x2]
  410632:	cmp    eax,0x4c
  410635:	setne  al
  410638:	jne    410660 <__swc_fn_3464c816_000140_55003b6d+0x60>
  41063a:	movzx  eax,BYTE PTR [rcx+0x3]
  41063e:	cmp    eax,0x46
  410641:	setne  al
  410644:	jne    410660 <__swc_fn_3464c816_000140_55003b6d+0x60>
  410646:	cmp    BYTE PTR [rcx+0x4],0x2
  41064a:	setne  al
  41064d:	jne    410660 <__swc_fn_3464c816_000140_55003b6d+0x60>
  41064f:	cmp    BYTE PTR [rcx+0x5],0x1
  410653:	setne  al
  410656:	jne    410660 <__swc_fn_3464c816_000140_55003b6d+0x60>
  410658:	cmp    WORD PTR [rcx+0x12],0x3e
  41065d:	setne  al
  410660:	test   al,al
  410662:	je     410671 <__swc_fn_3464c816_000140_55003b6d+0x71>
  410664:	xor    eax,eax
  410666:	pop    r15
  410668:	pop    r14
  41066a:	pop    r13
  41066c:	pop    r12
  41066e:	pop    rdi
  41066f:	pop    rsi
  410670:	ret
  410671:	cmp    WORD PTR [rcx+0x3a],0x40
  410676:	jne    410691 <__swc_fn_3464c816_000140_55003b6d+0x91>
  410678:	cmp    WORD PTR [rcx+0x3c],0x0
  41067d:	sete   al
  410680:	je     41068d <__swc_fn_3464c816_000140_55003b6d+0x8d>
  410682:	mov    ax,WORD PTR [rcx+0x3c]
  410686:	cmp    WORD PTR [rcx+0x3e],ax
  41068a:	setae  al
  41068d:	test   al,al
  41068f:	je     41069e <__swc_fn_3464c816_000140_55003b6d+0x9e>
  410691:	xor    eax,eax
  410693:	pop    r15
  410695:	pop    r14
  410697:	pop    r13
  410699:	pop    r12
  41069b:	pop    rdi
  41069c:	pop    rsi
  41069d:	ret
  41069e:	movzx  eax,WORD PTR [rcx+0x3c]
  4106a2:	shl    rax,0x6
  4106a6:	cmp    rax,rdx
  4106a9:	ja     4106b7 <__swc_fn_3464c816_000140_55003b6d+0xb7>
  4106ab:	mov    r9,rdx
  4106ae:	sub    r9,rax
  4106b1:	cmp    QWORD PTR [rcx+0x28],r9
  4106b5:	jbe    4106c4 <__swc_fn_3464c816_000140_55003b6d+0xc4>
  4106b7:	xor    eax,eax
  4106b9:	pop    r15
  4106bb:	pop    r14
  4106bd:	pop    r13
  4106bf:	pop    r12
  4106c1:	pop    rdi
  4106c2:	pop    rsi
  4106c3:	ret
  4106c4:	mov    rax,QWORD PTR [rcx+0x28]
  4106c8:	add    rax,rcx
  4106cb:	movzx  r9d,WORD PTR [rcx+0x3e]
  4106d0:	lea    r9,[r9*8+0x0]
  4106d8:	lea    r10,[rax+r9*8]
  4106dc:	cmp    QWORD PTR [r10+0x20],rdx
  4106e0:	ja     410702 <__swc_fn_3464c816_000140_55003b6d+0x102>
  4106e2:	mov    r11,rdx
  4106e5:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  4106ea:	cmp    QWORD PTR [r10+0x18],r11
  4106ee:	seta   r9b
  4106f2:	ja     4106fd <__swc_fn_3464c816_000140_55003b6d+0xfd>
  4106f4:	cmp    QWORD PTR [r10+0x20],0x9
  4106f9:	setb   r9b
  4106fd:	test   r9b,r9b
  410700:	je     41070f <__swc_fn_3464c816_000140_55003b6d+0x10f>
  410702:	xor    eax,eax
  410704:	pop    r15
  410706:	pop    r14
  410708:	pop    r13
  41070a:	pop    r12
  41070c:	pop    rdi
  41070d:	pop    rsi
  41070e:	ret
  41070f:	movzx  r9d,WORD PTR [rcx+0x3c]
  410714:	xor    r11d,r11d
  410717:	test   r9,r9
  41071a:	jbe    410815 <__swc_fn_3464c816_000140_55003b6d+0x215>
  410720:	mov    rsi,QWORD PTR [r10+0x20]
  410724:	sub    rsi,0x9
  410728:	cs nop WORD PTR [rax+rax*1+0x0]
  410732:	cs nop WORD PTR [rax+rax*1+0x0]
  41073c:	nop    DWORD PTR [rax+0x0]
  410740:	movzx  edi,r11w
  410744:	lea    rdi,[rdi*8+0x0]
  41074c:	lea    r12,[rax+rdi*8]
  410750:	rex mov edi,DWORD PTR [rax+rdi*8]
  410754:	cmp    rdi,rsi
  410757:	ja     410808 <__swc_fn_3464c816_000140_55003b6d+0x208>
  41075d:	mov    r13,QWORD PTR [r10+0x18]
  410761:	add    r13,rdi
  410764:	lea    rdi,[rcx+r13*1]
  410768:	lea    r13,[rip+0x2dc1]        # 413530 <__swc_rdata_base_3464c816+0x420>
  41076f:	movabs r14,0x676264676177732e
  410779:	cmp    QWORD PTR [rdi],r14
  41077c:	jne    410785 <__swc_fn_3464c816_000140_55003b6d+0x185>
  41077e:	rex cmp BYTE PTR [rdi+0x8],0x0
  410783:	je     4107b2 <__swc_fn_3464c816_000140_55003b6d+0x1b2>
  410785:	cs nop WORD PTR [rax+rax*1+0x0]
  41078f:	nop
  410790:	movzx  r14d,BYTE PTR [rdi]
  410794:	movzx  r15d,BYTE PTR [r13+0x0]
  410799:	cmp    r14,r15
  41079c:	jne    4107a8 <__swc_fn_3464c816_000140_55003b6d+0x1a8>
  41079e:	add    rdi,0x1
  4107a2:	add    r13,0x1
  4107a6:	jmp    410790 <__swc_fn_3464c816_000140_55003b6d+0x190>
  4107a8:	mov    rdi,r14
  4107ab:	sub    rdi,r15
  4107ae:	test   edi,edi
  4107b0:	jne    410808 <__swc_fn_3464c816_000140_55003b6d+0x208>
  4107b2:	cmp    DWORD PTR [r12+0x4],0x1
  4107b8:	jne    4107e0 <__swc_fn_3464c816_000140_55003b6d+0x1e0>
  4107ba:	cmp    QWORD PTR [r12+0x20],0x10
  4107c0:	setb   al
  4107c3:	jb     4107dc <__swc_fn_3464c816_000140_55003b6d+0x1dc>
  4107c5:	cmp    QWORD PTR [r12+0x20],rdx
  4107ca:	seta   al
  4107cd:	ja     4107dc <__swc_fn_3464c816_000140_55003b6d+0x1dc>
  4107cf:	sub    rdx,QWORD PTR [r12+0x20]
  4107d4:	cmp    QWORD PTR [r12+0x18],rdx
  4107d9:	seta   al
  4107dc:	test   al,al
  4107de:	je     4107ed <__swc_fn_3464c816_000140_55003b6d+0x1ed>
  4107e0:	xor    eax,eax
  4107e2:	pop    r15
  4107e4:	pop    r14
  4107e6:	pop    r13
  4107e8:	pop    r12
  4107ea:	pop    rdi
  4107eb:	pop    rsi
  4107ec:	ret
  4107ed:	mov    rax,QWORD PTR [r12+0x20]
  4107f2:	mov    QWORD PTR [r8],rax
  4107f5:	mov    rax,QWORD PTR [r12+0x18]
  4107fa:	add    rax,rcx
  4107fd:	pop    r15
  4107ff:	pop    r14
  410801:	pop    r13
  410803:	pop    r12
  410805:	pop    rdi
  410806:	pop    rsi
  410807:	ret
  410808:	add    r11,0x1
  41080c:	cmp    r11,r9
  41080f:	jb     410740 <__swc_fn_3464c816_000140_55003b6d+0x140>
  410815:	xor    eax,eax
  410817:	pop    r15
  410819:	pop    r14
  41081b:	pop    r13
  41081d:	pop    r12
  41081f:	pop    rdi
  410820:	pop    rsi
  410821:	ret
	...

0000000000410830 <__swc_fn_3464c816_000143_b7ad855f>:
  410830:	push   rdi
  410831:	push   rsi
  410832:	sub    rsp,0xa8
  410839:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41083f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410845:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41084b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410851:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410857:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41085d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410863:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410869:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410872:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41087b:	mov    rdi,rcx
  41087e:	xor    eax,eax
  410880:	call   4071f0 <free@plt>
  410885:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41088b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410891:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410897:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41089d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4108a3:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4108a9:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4108af:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4108b5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4108be:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4108c7:	add    rsp,0xa8
  4108ce:	pop    rsi
  4108cf:	pop    rdi
  4108d0:	ret
	...

00000000004108e0 <__swc_fn_3464c816_000146_d2097256>:
  4108e0:	push   rbx
  4108e1:	push   rsi
  4108e2:	push   rdi
  4108e3:	push   r12
  4108e5:	push   r13
  4108e7:	push   r15
  4108e9:	sub    rsp,0x4e8
  4108f0:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  4108f9:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  410902:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  41090b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  410914:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  41091d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  410926:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  41092f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  410938:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  410941:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  41094a:	mov    rbx,QWORD PTR [rcx]
  41094d:	mov    rcx,QWORD PTR [rcx+0x8]
  410951:	mov    rsi,rcx
  410954:	xor    edi,edi
  410956:	vmovsd xmm6,QWORD PTR [rip+0x2c32]        # 413590 <__swc_rdata_base_3464c816+0x480>
  41095e:	vmovsd xmm7,QWORD PTR [rip+0x2c33]        # 413599 <__swc_rdata_base_3464c816+0x489>
  410966:	vmovsd xmm8,QWORD PTR [rip+0x2c34]        # 4135a2 <__swc_rdata_base_3464c816+0x492>
  41096e:	vmovsd xmm9,QWORD PTR [rip+0x2c35]        # 4135ab <__swc_rdata_base_3464c816+0x49b>
  410976:	vmovsd xmm10,QWORD PTR [rip+0x2c36]        # 4135b4 <__swc_rdata_base_3464c816+0x4a4>
  41097e:	vmovups xmm11,xmm6
  410982:	vmovsd QWORD PTR [rsp+0x418],xmm7
  41098b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  410994:	vmovsd QWORD PTR [rsp+0x428],xmm9
  41099d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  4109a6:	vmovsd xmm15,QWORD PTR [rip+0x2c0f]        # 4135bd <__swc_rdata_base_3464c816+0x4ad>
  4109ae:	vmovups xmm14,xmm15
  4109b3:	vmovups xmm0,xmm9
  4109b8:	vmovsd QWORD PTR [rsp+0x438],xmm15
  4109c1:	vmovups xmm13,xmm8
  4109c6:	vmovsd QWORD PTR [rsp+0x440],xmm15
  4109cf:	test   rsi,rsi
  4109d2:	je     4119c3 <__swc_fn_3464c816_000146_d2097256+0x10e3>
  4109d8:	cs nop WORD PTR [rax+rax*1+0x0]
  4109e2:	cs nop WORD PTR [rax+rax*1+0x0]
  4109ec:	nop    DWORD PTR [rax+0x0]
  4109f0:	lea    rcx,[rdi+rdi*1]
  4109f4:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  4109f9:	vpshufd xmm3,xmm2,0xee
  4109fe:	vmovq  rcx,xmm3
  410a03:	test   rcx,rcx
  410a06:	je     410a1c <__swc_fn_3464c816_000146_d2097256+0x13c>
  410a08:	test   DWORD PTR [rcx+0x28],0x400000
  410a0f:	je     410a1c <__swc_fn_3464c816_000146_d2097256+0x13c>
  410a11:	mov    rdx,QWORD PTR [rcx+0x30]
  410a15:	test   rdx,rdx
  410a18:	cmovne rcx,rdx
  410a1c:	test   DWORD PTR [rcx+0x28],0x1000
  410a23:	je     410a44 <__swc_fn_3464c816_000146_d2097256+0x164>
  410a25:	mov    rdx,QWORD PTR [rcx+0x40]
  410a29:	mov    rcx,rdx
  410a2c:	vmovq  r8,xmm2
  410a31:	mov    r8,QWORD PTR [r8]
  410a34:	mov    QWORD PTR [rsp+0x60],r8
  410a39:	mov    QWORD PTR [rsp+0x68],rdx
  410a3e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  410a44:	test   BYTE PTR [rcx+0x28],0x1
  410a48:	jne    410a50 <__swc_fn_3464c816_000146_d2097256+0x170>
  410a4a:	vmovups xmm12,xmm0
  410a4e:	jmp    410a6a <__swc_fn_3464c816_000146_d2097256+0x18a>
  410a50:	vmovq  rax,xmm2
  410a55:	mov    rax,QWORD PTR [rax]
  410a58:	lea    rcx,[rax+0x10]
  410a5c:	vmovups xmm12,xmm0
  410a60:	call   410070 <__swc_fn_3464c816_000116_3f5cfdef>
  410a65:	jmp    4119a5 <__swc_fn_3464c816_000146_d2097256+0x10c5>
  410a6a:	test   DWORD PTR [rcx+0x28],0x400
  410a71:	je     410ad2 <__swc_fn_3464c816_000146_d2097256+0x1f2>
  410a73:	vmovq  rax,xmm2
  410a78:	mov    rax,QWORD PTR [rax]
  410a7b:	xor    ecx,ecx
  410a7d:	test   rax,rax
  410a80:	je     410ab0 <__swc_fn_3464c816_000146_d2097256+0x1d0>
  410a82:	mov    rdx,rax
  410a85:	mov    r8b,BYTE PTR [rdx]
  410a88:	test   r8b,r8b
  410a8b:	je     410ab0 <__swc_fn_3464c816_000146_d2097256+0x1d0>
  410a8d:	cs nop WORD PTR [rax+rax*1+0x0]
  410a97:	nop    WORD PTR [rax+rax*1+0x0]
  410aa0:	add    rdx,0x1
  410aa4:	add    rcx,0x1
  410aa8:	mov    r8b,BYTE PTR [rdx]
  410aab:	test   r8b,r8b
  410aae:	jne    410aa0 <__swc_fn_3464c816_000146_d2097256+0x1c0>
  410ab0:	mov    QWORD PTR [rsp+0x88],rax
  410ab8:	mov    QWORD PTR [rsp+0x90],rcx
  410ac0:	lea    rcx,[rsp+0x88]
  410ac8:	call   410070 <__swc_fn_3464c816_000116_3f5cfdef>
  410acd:	jmp    4119a5 <__swc_fn_3464c816_000146_d2097256+0x10c5>
  410ad2:	cmp    BYTE PTR [rcx+0x2c],0x6
  410ad6:	jne    410aed <__swc_fn_3464c816_000146_d2097256+0x20d>
  410ad8:	vmovq  rax,xmm2
  410add:	mov    rax,QWORD PTR [rax]
  410ae0:	mov    rcx,rax
  410ae3:	call   409cb0 <__swc_fn_3464c816_000144_c3e86ca0>
  410ae8:	jmp    4119a5 <__swc_fn_3464c816_000146_d2097256+0x10c5>
  410aed:	cmp    BYTE PTR [rcx+0x2c],0x1
  410af1:	jne    411999 <__swc_fn_3464c816_000146_d2097256+0x10b9>
  410af7:	vmovq  rdx,xmm2
  410afc:	mov    cl,BYTE PTR [rcx+0x40]
  410aff:	cmp    cl,0x7
  410b02:	jb     410b45 <__swc_fn_3464c816_000146_d2097256+0x265>
  410b04:	je     410bb8 <__swc_fn_3464c816_000146_d2097256+0x2d8>
  410b0a:	cmp    cl,0x8
  410b0d:	je     410bc4 <__swc_fn_3464c816_000146_d2097256+0x2e4>
  410b13:	cmp    cl,0x9
  410b16:	je     410bdd <__swc_fn_3464c816_000146_d2097256+0x2fd>
  410b1c:	cmp    cl,0xa
  410b1f:	je     4112a4 <__swc_fn_3464c816_000146_d2097256+0x9c4>
  410b25:	cmp    cl,0xb
  410b28:	je     41196b <__swc_fn_3464c816_000146_d2097256+0x108b>
  410b2e:	cmp    cl,0xc
  410b31:	je     410bd1 <__swc_fn_3464c816_000146_d2097256+0x2f1>
  410b37:	cmp    cl,0xd
  410b3a:	je     411961 <__swc_fn_3464c816_000146_d2097256+0x1081>
  410b40:	jmp    41198b <__swc_fn_3464c816_000146_d2097256+0x10ab>
  410b45:	cmp    cl,0x1
  410b48:	je     410b68 <__swc_fn_3464c816_000146_d2097256+0x288>
  410b4a:	cmp    cl,0x2
  410b4d:	je     410b76 <__swc_fn_3464c816_000146_d2097256+0x296>
  410b4f:	cmp    cl,0x3
  410b52:	je     410b84 <__swc_fn_3464c816_000146_d2097256+0x2a4>
  410b54:	cmp    cl,0x4
  410b57:	je     410b91 <__swc_fn_3464c816_000146_d2097256+0x2b1>
  410b59:	cmp    cl,0x5
  410b5c:	je     410b9e <__swc_fn_3464c816_000146_d2097256+0x2be>
  410b5e:	cmp    cl,0x6
  410b61:	je     410bab <__swc_fn_3464c816_000146_d2097256+0x2cb>
  410b63:	jmp    41198b <__swc_fn_3464c816_000146_d2097256+0x10ab>
  410b68:	movsx  rcx,BYTE PTR [rdx]
  410b6c:	call   40cf60 <__swc_fn_3464c816_000145_32a1d6a2>
  410b71:	jmp    4119a5 <__swc_fn_3464c816_000146_d2097256+0x10c5>
  410b76:	movsx  rcx,WORD PTR [rdx]
  410b7a:	call   40cf60 <__swc_fn_3464c816_000145_32a1d6a2>
  410b7f:	jmp    4119a5 <__swc_fn_3464c816_000146_d2097256+0x10c5>
  410b84:	movsxd rcx,DWORD PTR [rdx]
  410b87:	call   40cf60 <__swc_fn_3464c816_000145_32a1d6a2>
  410b8c:	jmp    4119a5 <__swc_fn_3464c816_000146_d2097256+0x10c5>
  410b91:	mov    rcx,QWORD PTR [rdx]
  410b94:	call   40cf60 <__swc_fn_3464c816_000145_32a1d6a2>
  410b99:	jmp    4119a5 <__swc_fn_3464c816_000146_d2097256+0x10c5>
  410b9e:	movzx  ecx,BYTE PTR [rdx]
  410ba1:	call   409cb0 <__swc_fn_3464c816_000144_c3e86ca0>
  410ba6:	jmp    4119a5 <__swc_fn_3464c816_000146_d2097256+0x10c5>
  410bab:	movzx  ecx,WORD PTR [rdx]
  410bae:	call   409cb0 <__swc_fn_3464c816_000144_c3e86ca0>
  410bb3:	jmp    4119a5 <__swc_fn_3464c816_000146_d2097256+0x10c5>
  410bb8:	mov    ecx,DWORD PTR [rdx]
  410bba:	call   409cb0 <__swc_fn_3464c816_000144_c3e86ca0>
  410bbf:	jmp    4119a5 <__swc_fn_3464c816_000146_d2097256+0x10c5>
  410bc4:	mov    rcx,QWORD PTR [rdx]
  410bc7:	call   409cb0 <__swc_fn_3464c816_000144_c3e86ca0>
  410bcc:	jmp    4119a5 <__swc_fn_3464c816_000146_d2097256+0x10c5>
  410bd1:	mov    ecx,DWORD PTR [rdx]
  410bd3:	call   409cb0 <__swc_fn_3464c816_000144_c3e86ca0>
  410bd8:	jmp    4119a5 <__swc_fn_3464c816_000146_d2097256+0x10c5>
  410bdd:	lea    rcx,[rsp+0xa8]
  410be5:	vxorps xmm0,xmm0,xmm0
  410be9:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  410bf2:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  410bfb:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  410c04:	vzeroupper
  410c07:	mov    DWORD PTR [rsp+0x108],0x0
  410c12:	vxorpd xmm0,xmm0,xmm0
  410c16:	vmovss xmm1,DWORD PTR [rdx]
  410c1a:	vcvtss2sd xmm0,xmm0,xmm1
  410c1e:	vmovsd xmm1,xmm1,xmm0
  410c22:	vcomisd xmm0,xmm0
  410c26:	setne  dl
  410c29:	movzx  edx,dl
  410c2c:	setp   r8b
  410c30:	movzx  r8d,r8b
  410c34:	or     edx,r8d
  410c37:	test   dl,dl
  410c39:	je     410c46 <__swc_fn_3464c816_000146_d2097256+0x366>
  410c3b:	mov    DWORD PTR [rcx],0x6e616e
  410c41:	jmp    411238 <__swc_fn_3464c816_000146_d2097256+0x958>
  410c46:	vcomisd xmm1,xmm6
  410c4a:	ja     410c52 <__swc_fn_3464c816_000146_d2097256+0x372>
  410c4c:	vcomisd xmm7,xmm1
  410c50:	jbe    410c76 <__swc_fn_3464c816_000146_d2097256+0x396>
  410c52:	vxorpd xmm0,xmm0,xmm0
  410c56:	vcomisd xmm0,xmm1
  410c5a:	jbe    410c6b <__swc_fn_3464c816_000146_d2097256+0x38b>
  410c5c:	mov    DWORD PTR [rcx],0x666e692d
  410c62:	mov    BYTE PTR [rcx+0x4],0x0
  410c66:	jmp    411238 <__swc_fn_3464c816_000146_d2097256+0x958>
  410c6b:	mov    DWORD PTR [rcx],0x666e69
  410c71:	jmp    411238 <__swc_fn_3464c816_000146_d2097256+0x958>
  410c76:	vcomisd xmm1,xmm8
  410c7b:	jae    410c87 <__swc_fn_3464c816_000146_d2097256+0x3a7>
  410c7d:	vcomisd xmm9,xmm1
  410c81:	jbe    410ffe <__swc_fn_3464c816_000146_d2097256+0x71e>
  410c87:	vmovups xmm0,xmm1
  410c8b:	vxorpd xmm2,xmm2,xmm2
  410c8f:	vcomisd xmm2,xmm1
  410c93:	jbe    410ca3 <__swc_fn_3464c816_000146_d2097256+0x3c3>
  410c95:	vmovsd xmm1,xmm1,xmm0
  410c99:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x28af]        # 413550 <__swc_rdata_base_3464c816+0x440>
  410ca1:	jmp    410ca7 <__swc_fn_3464c816_000146_d2097256+0x3c7>
  410ca3:	vmovsd xmm1,xmm1,xmm0
  410ca7:	xor    r8d,r8d
  410caa:	vcomisd xmm1,xmm15
  410caf:	jb     410cd0 <__swc_fn_3464c816_000146_d2097256+0x3f0>
  410cb1:	cs nop WORD PTR [rax+rax*1+0x0]
  410cbb:	nop    DWORD PTR [rax+rax*1+0x0]
  410cc0:	vdivsd xmm1,xmm1,xmm15
  410cc5:	add    r8,0x1
  410cc9:	vcomisd xmm1,xmm15
  410cce:	jae    410cc0 <__swc_fn_3464c816_000146_d2097256+0x3e0>
  410cd0:	mov    r9,rcx
  410cd3:	vxorpd xmm2,xmm2,xmm2
  410cd7:	vcomisd xmm2,xmm0
  410cdb:	jbe    410ce4 <__swc_fn_3464c816_000146_d2097256+0x404>
  410cdd:	mov    BYTE PTR [rcx],0x2d
  410ce0:	lea    r9,[rcx+0x1]
  410ce4:	vcvttsd2si rdx,xmm1
  410ce9:	mov    r10b,dl
  410cec:	add    r10b,0x30
  410cf0:	mov    BYTE PTR [r9],r10b
  410cf3:	vxorpd xmm0,xmm0,xmm0
  410cf7:	movzx  edx,dl
  410cfa:	vcvtsi2sd xmm0,xmm0,rdx
  410cff:	vsubsd xmm0,xmm1,xmm0
  410d03:	vmulsd xmm1,xmm0,xmm15
  410d08:	mov    BYTE PTR [r9+0x1],0x2e
  410d0d:	vcvttsd2si rdx,xmm1
  410d12:	mov    r10b,dl
  410d15:	add    r10b,0x30
  410d19:	mov    BYTE PTR [r9+0x2],r10b
  410d1d:	vxorpd xmm0,xmm0,xmm0
  410d21:	movzx  edx,dl
  410d24:	vcvtsi2sd xmm0,xmm0,rdx
  410d29:	vsubsd xmm0,xmm1,xmm0
  410d2d:	vmulsd xmm1,xmm0,xmm15
  410d32:	vcvttsd2si rdx,xmm1
  410d37:	mov    r10b,dl
  410d3a:	add    r10b,0x30
  410d3e:	mov    BYTE PTR [r9+0x3],r10b
  410d42:	vxorpd xmm0,xmm0,xmm0
  410d46:	movzx  edx,dl
  410d49:	vcvtsi2sd xmm0,xmm0,rdx
  410d4e:	vsubsd xmm0,xmm1,xmm0
  410d52:	vmulsd xmm1,xmm0,xmm15
  410d57:	vcvttsd2si rdx,xmm1
  410d5c:	mov    r10b,dl
  410d5f:	add    r10b,0x30
  410d63:	mov    BYTE PTR [r9+0x4],r10b
  410d67:	vxorpd xmm0,xmm0,xmm0
  410d6b:	movzx  edx,dl
  410d6e:	vcvtsi2sd xmm0,xmm0,rdx
  410d73:	vsubsd xmm0,xmm1,xmm0
  410d77:	vmulsd xmm1,xmm0,xmm15
  410d7c:	vcvttsd2si rdx,xmm1
  410d81:	mov    r10b,dl
  410d84:	add    r10b,0x30
  410d88:	mov    BYTE PTR [r9+0x5],r10b
  410d8c:	vxorpd xmm0,xmm0,xmm0
  410d90:	movzx  edx,dl
  410d93:	vcvtsi2sd xmm0,xmm0,rdx
  410d98:	vsubsd xmm0,xmm1,xmm0
  410d9c:	vmulsd xmm1,xmm0,xmm15
  410da1:	vcvttsd2si rdx,xmm1
  410da6:	mov    r10b,dl
  410da9:	add    r10b,0x30
  410dad:	mov    BYTE PTR [r9+0x6],r10b
  410db1:	vxorpd xmm0,xmm0,xmm0
  410db5:	movzx  edx,dl
  410db8:	vcvtsi2sd xmm0,xmm0,rdx
  410dbd:	vsubsd xmm0,xmm1,xmm0
  410dc1:	vmulsd xmm1,xmm0,xmm15
  410dc6:	vcvttsd2si rdx,xmm1
  410dcb:	mov    r10b,dl
  410dce:	add    r10b,0x30
  410dd2:	mov    BYTE PTR [r9+0x7],r10b
  410dd6:	vxorpd xmm0,xmm0,xmm0
  410dda:	movzx  edx,dl
  410ddd:	vcvtsi2sd xmm0,xmm0,rdx
  410de2:	vsubsd xmm0,xmm1,xmm0
  410de6:	vmulsd xmm1,xmm0,xmm15
  410deb:	vcvttsd2si rdx,xmm1
  410df0:	mov    r10b,dl
  410df3:	add    r10b,0x30
  410df7:	mov    BYTE PTR [r9+0x8],r10b
  410dfb:	vxorpd xmm0,xmm0,xmm0
  410dff:	movzx  edx,dl
  410e02:	vcvtsi2sd xmm0,xmm0,rdx
  410e07:	vsubsd xmm0,xmm1,xmm0
  410e0b:	vmulsd xmm1,xmm0,xmm15
  410e10:	vcvttsd2si rdx,xmm1
  410e15:	mov    r10b,dl
  410e18:	add    r10b,0x30
  410e1c:	mov    BYTE PTR [r9+0x9],r10b
  410e20:	vxorpd xmm0,xmm0,xmm0
  410e24:	movzx  edx,dl
  410e27:	vcvtsi2sd xmm0,xmm0,rdx
  410e2c:	vsubsd xmm0,xmm1,xmm0
  410e30:	vmulsd xmm1,xmm0,xmm15
  410e35:	vcvttsd2si rdx,xmm1
  410e3a:	mov    r10b,dl
  410e3d:	add    r10b,0x30
  410e41:	mov    BYTE PTR [r9+0xa],r10b
  410e45:	vxorpd xmm0,xmm0,xmm0
  410e49:	movzx  edx,dl
  410e4c:	vcvtsi2sd xmm0,xmm0,rdx
  410e51:	vsubsd xmm0,xmm1,xmm0
  410e55:	vmulsd xmm1,xmm0,xmm15
  410e5a:	vcvttsd2si rdx,xmm1
  410e5f:	mov    r10b,dl
  410e62:	add    r10b,0x30
  410e66:	mov    BYTE PTR [r9+0xb],r10b
  410e6a:	lea    r10,[r9+0x4]
  410e6e:	vxorpd xmm0,xmm0,xmm0
  410e72:	movzx  edx,dl
  410e75:	vcvtsi2sd xmm0,xmm0,rdx
  410e7a:	vsubsd xmm0,xmm1,xmm0
  410e7e:	vmulsd xmm1,xmm0,xmm15
  410e83:	vcvttsd2si rdx,xmm1
  410e88:	mov    r11b,dl
  410e8b:	add    r11b,0x30
  410e8f:	mov    BYTE PTR [r9+0xc],r11b
  410e93:	vxorpd xmm0,xmm0,xmm0
  410e97:	movzx  edx,dl
  410e9a:	vcvtsi2sd xmm0,xmm0,rdx
  410e9f:	vsubsd xmm0,xmm1,xmm0
  410ea3:	vmulsd xmm1,xmm0,xmm15
  410ea8:	vcvttsd2si rdx,xmm1
  410ead:	mov    r11b,dl
  410eb0:	add    r11b,0x30
  410eb4:	mov    BYTE PTR [r9+0xd],r11b
  410eb8:	lea    r10,[r10+0x2]
  410ebc:	vxorpd xmm0,xmm0,xmm0
  410ec0:	movzx  edx,dl
  410ec3:	vcvtsi2sd xmm0,xmm0,rdx
  410ec8:	vsubsd xmm0,xmm1,xmm0
  410ecc:	vmulsd xmm1,xmm0,xmm15
  410ed1:	vcvttsd2si rdx,xmm1
  410ed6:	mov    r11b,dl
  410ed9:	add    r11b,0x30
  410edd:	mov    BYTE PTR [r9+0xe],r11b
  410ee1:	vxorpd xmm0,xmm0,xmm0
  410ee5:	movzx  edx,dl
  410ee8:	vcvtsi2sd xmm0,xmm0,rdx
  410eed:	vsubsd xmm0,xmm1,xmm0
  410ef1:	vmulsd xmm1,xmm0,xmm15
  410ef6:	vcvttsd2si rdx,xmm1
  410efb:	mov    r11b,dl
  410efe:	add    r11b,0x30
  410f02:	mov    BYTE PTR [r9+0xf],r11b
  410f06:	lea    r10,[r10+0x2]
  410f0a:	lea    r10,[r10+0x2]
  410f0e:	lea    r10,[r10+0x2]
  410f12:	lea    r10,[r10+0x2]
  410f16:	lea    r10,[r10+0x2]
  410f1a:	vxorpd xmm0,xmm0,xmm0
  410f1e:	movzx  edx,dl
  410f21:	vcvtsi2sd xmm0,xmm0,rdx
  410f26:	vsubsd xmm0,xmm1,xmm0
  410f2a:	vmulsd xmm1,xmm0,xmm15
  410f2f:	vcvttsd2si rdx,xmm1
  410f34:	mov    r11b,dl
  410f37:	add    r11b,0x30
  410f3b:	mov    BYTE PTR [r9+0x10],r11b
  410f3f:	vxorpd xmm0,xmm0,xmm0
  410f43:	movzx  edx,dl
  410f46:	vcvtsi2sd xmm0,xmm0,rdx
  410f4b:	vsubsd xmm0,xmm1,xmm0
  410f4f:	vmulsd xmm1,xmm0,xmm15
  410f54:	vcvttsd2si rdx,xmm1
  410f59:	add    dl,0x30
  410f5c:	mov    BYTE PTR [r9+0x11],dl
  410f60:	mov    BYTE PTR [r10+0x2],0x65
  410f65:	lea    r9,[r10+0x3]
  410f69:	test   r8,r8
  410f6c:	jl     410f75 <__swc_fn_3464c816_000146_d2097256+0x695>
  410f6e:	mov    BYTE PTR [r9],0x2b
  410f72:	inc    r9
  410f75:	mov    r10,r9
  410f78:	mov    rdx,r8
  410f7b:	nop    DWORD PTR [rax+rax*1+0x0]
  410f80:	mov    r11,rdx
  410f83:	movabs rdx,0x6666666666666667
  410f8d:	mov    rax,r11
  410f90:	imul   rdx
  410f93:	sar    rdx,0x2
  410f97:	mov    r12,rdx
  410f9a:	shr    rdx,0x3f
  410f9e:	add    r12,rdx
  410fa1:	mov    rdx,r12
  410fa4:	imul   r13,r12,0xa
  410fa8:	sub    r11,r13
  410fab:	mov    r13,QWORD PTR [rip+0x258e]        # 413540 <__swc_rdata_base_3464c816+0x430>
  410fb2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410fb7:	mov    BYTE PTR [r10],r11b
  410fba:	lea    r11,[r10+0x1]
  410fbe:	mov    r10,r11
  410fc1:	test   r12,r12
  410fc4:	jne    410f80 <__swc_fn_3464c816_000146_d2097256+0x6a0>
  410fc6:	test   r8,r8
  410fc9:	jge    410fd3 <__swc_fn_3464c816_000146_d2097256+0x6f3>
  410fcb:	mov    BYTE PTR [r11],0x2d
  410fcf:	lea    r10,[r11+0x1]
  410fd3:	mov    BYTE PTR [r10],0x0
  410fd7:	sub    r10,0x1
  410fdb:	nop    DWORD PTR [rax+rax*1+0x0]
  410fe0:	cmp    r9,r10
  410fe3:	jae    411238 <__swc_fn_3464c816_000146_d2097256+0x958>
  410fe9:	mov    al,BYTE PTR [r10]
  410fec:	mov    dl,BYTE PTR [r9]
  410fef:	mov    BYTE PTR [r10],dl
  410ff2:	sub    r10,0x1
  410ff6:	mov    BYTE PTR [r9],al
  410ff9:	inc    r9
  410ffc:	jmp    410fe0 <__swc_fn_3464c816_000146_d2097256+0x700>
  410ffe:	vcvttsd2si rdx,xmm1
  411003:	mov    r8,rdx
  411006:	vxorpd xmm0,xmm0,xmm0
  41100a:	vcvtsi2sd xmm0,xmm0,rdx
  41100f:	vsubsd xmm0,xmm1,xmm0
  411013:	mov    r9d,0x8
  411019:	vxorpd xmm2,xmm2,xmm2
  41101d:	vcomisd xmm2,xmm0
  411021:	jbe    41102b <__swc_fn_3464c816_000146_d2097256+0x74b>
  411023:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x2525]        # 413550 <__swc_rdata_base_3464c816+0x440>
  41102b:	test   r9d,r9d
  41102e:	je     41103a <__swc_fn_3464c816_000146_d2097256+0x75a>
  411030:	vmulsd xmm0,xmm0,xmm14
  411035:	dec    r9d
  411038:	jne    411030 <__swc_fn_3464c816_000146_d2097256+0x750>
  41103a:	vcvttsd2si r9,xmm0
  41103f:	mov    r10,r9
  411042:	vxorpd xmm2,xmm2,xmm2
  411046:	vcvtsi2sd xmm2,xmm2,r9
  41104b:	vsubsd xmm0,xmm0,xmm2
  41104f:	vcomisd xmm0,xmm10
  411054:	lea    r9,[r9+0x1]
  411058:	cmova  r10,r9
  41105c:	cmp    r10,0x5f5e100
  411063:	jne    41107c <__swc_fn_3464c816_000146_d2097256+0x79c>
  411065:	lea    r8,[rdx-0x1]
  411069:	vxorpd xmm0,xmm0,xmm0
  41106d:	vcomisd xmm0,xmm1
  411071:	lea    rdx,[rdx+0x1]
  411075:	cmovbe r8,rdx
  411079:	xor    r10d,r10d
  41107c:	mov    r9,rcx
  41107f:	test   r8,r8
  411082:	jne    4110a2 <__swc_fn_3464c816_000146_d2097256+0x7c2>
  411084:	vxorpd xmm0,xmm0,xmm0
  411088:	vcomisd xmm0,xmm1
  41108c:	jbe    411095 <__swc_fn_3464c816_000146_d2097256+0x7b5>
  41108e:	mov    BYTE PTR [rcx],0x2d
  411091:	lea    r9,[rcx+0x1]
  411095:	mov    BYTE PTR [r9],0x30
  411099:	add    r9,0x1
  41109d:	jmp    41113b <__swc_fn_3464c816_000146_d2097256+0x85b>
  4110a2:	mov    r9,rcx
  4110a5:	mov    rdx,r8
  4110a8:	nop    DWORD PTR [rax+rax*1+0x0]
  4110b0:	mov    r11,rdx
  4110b3:	movabs rdx,0x6666666666666667
  4110bd:	mov    r15,rax
  4110c0:	mov    rax,r11
  4110c3:	imul   rdx
  4110c6:	mov    r12,rdx
  4110c9:	mov    rax,r15
  4110cc:	sar    r12,0x2
  4110d0:	mov    rdx,r12
  4110d3:	shr    rdx,0x3f
  4110d7:	add    r12,rdx
  4110da:	mov    rdx,r12
  4110dd:	imul   r13,r12,0xa
  4110e1:	sub    r11,r13
  4110e4:	mov    r13,QWORD PTR [rip+0x2455]        # 413540 <__swc_rdata_base_3464c816+0x430>
  4110eb:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4110f0:	mov    BYTE PTR [r9],r11b
  4110f3:	lea    r11,[r9+0x1]
  4110f7:	mov    r9,r11
  4110fa:	test   r12,r12
  4110fd:	jne    4110b0 <__swc_fn_3464c816_000146_d2097256+0x7d0>
  4110ff:	test   r8,r8
  411102:	jge    41110c <__swc_fn_3464c816_000146_d2097256+0x82c>
  411104:	mov    BYTE PTR [r11],0x2d
  411108:	lea    r9,[r11+0x1]
  41110c:	mov    rdx,r9
  41110f:	mov    BYTE PTR [r9],0x0
  411113:	sub    r9,0x1
  411117:	mov    r8,rcx
  41111a:	cmp    r8,r9
  41111d:	jae    411138 <__swc_fn_3464c816_000146_d2097256+0x858>
  41111f:	nop
  411120:	mov    r11b,BYTE PTR [r9]
  411123:	mov    r12b,BYTE PTR [r8]
  411126:	mov    BYTE PTR [r9],r12b
  411129:	sub    r9,0x1
  41112d:	mov    BYTE PTR [r8],r11b
  411130:	inc    r8
  411133:	cmp    r8,r9
  411136:	jb     411120 <__swc_fn_3464c816_000146_d2097256+0x840>
  411138:	mov    r9,rdx
  41113b:	mov    BYTE PTR [r9],0x2e
  41113f:	add    r9,0x1
  411143:	xor    r8d,r8d
  411146:	test   r10,r10
  411149:	je     41118f <__swc_fn_3464c816_000146_d2097256+0x8af>
  41114b:	mov    r11d,0x989680
  411151:	cmp    r10,r11
  411154:	jge    41118f <__swc_fn_3464c816_000146_d2097256+0x8af>
  411156:	cs nop WORD PTR [rax+rax*1+0x0]
  411160:	inc    r8d
  411163:	movabs rdx,0x6666666666666667
  41116d:	mov    r15,rax
  411170:	mov    rax,r11
  411173:	imul   rdx
  411176:	mov    r11,rdx
  411179:	mov    rax,r15
  41117c:	sar    r11,0x2
  411180:	mov    rdx,r11
  411183:	shr    rdx,0x3f
  411187:	add    r11,rdx
  41118a:	cmp    r10,r11
  41118d:	jl     411160 <__swc_fn_3464c816_000146_d2097256+0x880>
  41118f:	test   r8d,r8d
  411192:	je     4111ad <__swc_fn_3464c816_000146_d2097256+0x8cd>
  411194:	cs nop WORD PTR [rax+rax*1+0x0]
  41119e:	xchg   ax,ax
  4111a0:	mov    BYTE PTR [r9],0x30
  4111a4:	add    r9,0x1
  4111a8:	dec    r8d
  4111ab:	jne    4111a0 <__swc_fn_3464c816_000146_d2097256+0x8c0>
  4111ad:	mov    r8,r9
  4111b0:	mov    rdx,r10
  4111b3:	cs nop WORD PTR [rax+rax*1+0x0]
  4111bd:	nop    DWORD PTR [rax]
  4111c0:	mov    r11,rdx
  4111c3:	movabs rdx,0x6666666666666667
  4111cd:	mov    rax,r11
  4111d0:	imul   rdx
  4111d3:	sar    rdx,0x2
  4111d7:	mov    r12,rdx
  4111da:	shr    rdx,0x3f
  4111de:	add    r12,rdx
  4111e1:	mov    rdx,r12
  4111e4:	imul   r13,r12,0xa
  4111e8:	sub    r11,r13
  4111eb:	mov    r13,QWORD PTR [rip+0x234e]        # 413540 <__swc_rdata_base_3464c816+0x430>
  4111f2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4111f7:	mov    BYTE PTR [r8],r11b
  4111fa:	lea    r11,[r8+0x1]
  4111fe:	mov    r8,r11
  411201:	test   r12,r12
  411204:	jne    4111c0 <__swc_fn_3464c816_000146_d2097256+0x8e0>
  411206:	test   r10,r10
  411209:	jge    411213 <__swc_fn_3464c816_000146_d2097256+0x933>
  41120b:	mov    BYTE PTR [r11],0x2d
  41120f:	lea    r8,[r11+0x1]
  411213:	mov    BYTE PTR [r8],0x0
  411217:	sub    r8,0x1
  41121b:	cmp    r9,r8
  41121e:	jae    411238 <__swc_fn_3464c816_000146_d2097256+0x958>
  411220:	mov    al,BYTE PTR [r8]
  411223:	mov    dl,BYTE PTR [r9]
  411226:	mov    BYTE PTR [r8],dl
  411229:	sub    r8,0x1
  41122d:	mov    BYTE PTR [r9],al
  411230:	inc    r9
  411233:	cmp    r9,r8
  411236:	jb     411220 <__swc_fn_3464c816_000146_d2097256+0x940>
  411238:	xor    eax,eax
  41123a:	test   rcx,rcx
  41123d:	je     411270 <__swc_fn_3464c816_000146_d2097256+0x990>
  41123f:	mov    rdx,rcx
  411242:	mov    r8b,BYTE PTR [rdx]
  411245:	test   r8b,r8b
  411248:	je     411270 <__swc_fn_3464c816_000146_d2097256+0x990>
  41124a:	cs nop WORD PTR [rax+rax*1+0x0]
  411254:	cs nop WORD PTR [rax+rax*1+0x0]
  41125e:	xchg   ax,ax
  411260:	add    rdx,0x1
  411264:	add    rax,0x1
  411268:	mov    r8b,BYTE PTR [rdx]
  41126b:	test   r8b,r8b
  41126e:	jne    411260 <__swc_fn_3464c816_000146_d2097256+0x980>
  411270:	mov    QWORD PTR [rsp+0x240],rcx
  411278:	mov    QWORD PTR [rsp+0x248],rax
  411280:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  411289:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  411292:	lea    rcx,[rsp+0x250]
  41129a:	call   410070 <__swc_fn_3464c816_000116_3f5cfdef>
  41129f:	jmp    4119a5 <__swc_fn_3464c816_000146_d2097256+0x10c5>
  4112a4:	lea    rcx,[rsp+0x260]
  4112ac:	vxorps xmm0,xmm0,xmm0
  4112b0:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  4112b9:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  4112c2:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  4112cb:	vzeroupper
  4112ce:	mov    DWORD PTR [rsp+0x2c0],0x0
  4112d9:	vmovsd xmm0,QWORD PTR [rdx]
  4112dd:	vcomisd xmm0,xmm0
  4112e1:	setne  dl
  4112e4:	movzx  edx,dl
  4112e7:	setp   r8b
  4112eb:	movzx  r8d,r8b
  4112ef:	or     edx,r8d
  4112f2:	test   dl,dl
  4112f4:	je     411301 <__swc_fn_3464c816_000146_d2097256+0xa21>
  4112f6:	mov    DWORD PTR [rcx],0x6e616e
  4112fc:	jmp    411908 <__swc_fn_3464c816_000146_d2097256+0x1028>
  411301:	vcomisd xmm0,xmm11
  411306:	ja     411317 <__swc_fn_3464c816_000146_d2097256+0xa37>
  411308:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  411311:	vcomisd xmm6,xmm0
  411315:	jbe    41133b <__swc_fn_3464c816_000146_d2097256+0xa5b>
  411317:	vxorpd xmm1,xmm1,xmm1
  41131b:	vcomisd xmm1,xmm0
  41131f:	jbe    411330 <__swc_fn_3464c816_000146_d2097256+0xa50>
  411321:	mov    DWORD PTR [rcx],0x666e692d
  411327:	mov    BYTE PTR [rcx+0x4],0x0
  41132b:	jmp    411908 <__swc_fn_3464c816_000146_d2097256+0x1028>
  411330:	mov    DWORD PTR [rcx],0x666e69
  411336:	jmp    411908 <__swc_fn_3464c816_000146_d2097256+0x1028>
  41133b:	vcomisd xmm0,xmm13
  411340:	jae    41134c <__swc_fn_3464c816_000146_d2097256+0xa6c>
  411342:	vcomisd xmm12,xmm0
  411346:	jbe    4116ae <__swc_fn_3464c816_000146_d2097256+0xdce>
  41134c:	vmovups xmm1,xmm0
  411350:	vxorpd xmm2,xmm2,xmm2
  411354:	vcomisd xmm2,xmm0
  411358:	jbe    411368 <__swc_fn_3464c816_000146_d2097256+0xa88>
  41135a:	vmovsd xmm0,xmm0,xmm1
  41135e:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x21ea]        # 413550 <__swc_rdata_base_3464c816+0x440>
  411366:	jmp    41136c <__swc_fn_3464c816_000146_d2097256+0xa8c>
  411368:	vmovsd xmm0,xmm0,xmm1
  41136c:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  411375:	xor    r8d,r8d
  411378:	vcomisd xmm0,xmm6
  41137c:	jb     41138e <__swc_fn_3464c816_000146_d2097256+0xaae>
  41137e:	xchg   ax,ax
  411380:	vdivsd xmm0,xmm0,xmm6
  411384:	add    r8,0x1
  411388:	vcomisd xmm0,xmm6
  41138c:	jae    411380 <__swc_fn_3464c816_000146_d2097256+0xaa0>
  41138e:	mov    r9,rcx
  411391:	vxorpd xmm2,xmm2,xmm2
  411395:	vcomisd xmm2,xmm1
  411399:	jbe    4113a2 <__swc_fn_3464c816_000146_d2097256+0xac2>
  41139b:	mov    BYTE PTR [rcx],0x2d
  41139e:	lea    r9,[rcx+0x1]
  4113a2:	vcvttsd2si rdx,xmm0
  4113a7:	mov    r10b,dl
  4113aa:	add    r10b,0x30
  4113ae:	mov    BYTE PTR [r9],r10b
  4113b1:	vxorpd xmm1,xmm1,xmm1
  4113b5:	movzx  edx,dl
  4113b8:	vcvtsi2sd xmm1,xmm1,rdx
  4113bd:	vsubsd xmm0,xmm0,xmm1
  4113c1:	vmulsd xmm0,xmm0,xmm6
  4113c5:	mov    BYTE PTR [r9+0x1],0x2e
  4113ca:	vcvttsd2si rdx,xmm0
  4113cf:	mov    r10b,dl
  4113d2:	add    r10b,0x30
  4113d6:	mov    BYTE PTR [r9+0x2],r10b
  4113da:	vxorpd xmm1,xmm1,xmm1
  4113de:	movzx  edx,dl
  4113e1:	vcvtsi2sd xmm1,xmm1,rdx
  4113e6:	vsubsd xmm0,xmm0,xmm1
  4113ea:	vmulsd xmm0,xmm0,xmm6
  4113ee:	vcvttsd2si rdx,xmm0
  4113f3:	mov    r10b,dl
  4113f6:	add    r10b,0x30
  4113fa:	mov    BYTE PTR [r9+0x3],r10b
  4113fe:	vxorpd xmm1,xmm1,xmm1
  411402:	movzx  edx,dl
  411405:	vcvtsi2sd xmm1,xmm1,rdx
  41140a:	vsubsd xmm0,xmm0,xmm1
  41140e:	vmulsd xmm0,xmm0,xmm6
  411412:	vcvttsd2si rdx,xmm0
  411417:	mov    r10b,dl
  41141a:	add    r10b,0x30
  41141e:	mov    BYTE PTR [r9+0x4],r10b
  411422:	vxorpd xmm1,xmm1,xmm1
  411426:	movzx  edx,dl
  411429:	vcvtsi2sd xmm1,xmm1,rdx
  41142e:	vsubsd xmm0,xmm0,xmm1
  411432:	vmulsd xmm0,xmm0,xmm6
  411436:	vcvttsd2si rdx,xmm0
  41143b:	mov    r10b,dl
  41143e:	add    r10b,0x30
  411442:	mov    BYTE PTR [r9+0x5],r10b
  411446:	vxorpd xmm1,xmm1,xmm1
  41144a:	movzx  edx,dl
  41144d:	vcvtsi2sd xmm1,xmm1,rdx
  411452:	vsubsd xmm0,xmm0,xmm1
  411456:	vmulsd xmm0,xmm0,xmm6
  41145a:	vcvttsd2si rdx,xmm0
  41145f:	mov    r10b,dl
  411462:	add    r10b,0x30
  411466:	mov    BYTE PTR [r9+0x6],r10b
  41146a:	vxorpd xmm1,xmm1,xmm1
  41146e:	movzx  edx,dl
  411471:	vcvtsi2sd xmm1,xmm1,rdx
  411476:	vsubsd xmm0,xmm0,xmm1
  41147a:	vmulsd xmm0,xmm0,xmm6
  41147e:	vcvttsd2si rdx,xmm0
  411483:	mov    r10b,dl
  411486:	add    r10b,0x30
  41148a:	mov    BYTE PTR [r9+0x7],r10b
  41148e:	vxorpd xmm1,xmm1,xmm1
  411492:	movzx  edx,dl
  411495:	vcvtsi2sd xmm1,xmm1,rdx
  41149a:	vsubsd xmm0,xmm0,xmm1
  41149e:	vmulsd xmm0,xmm0,xmm6
  4114a2:	vcvttsd2si rdx,xmm0
  4114a7:	mov    r10b,dl
  4114aa:	add    r10b,0x30
  4114ae:	mov    BYTE PTR [r9+0x8],r10b
  4114b2:	vxorpd xmm1,xmm1,xmm1
  4114b6:	movzx  edx,dl
  4114b9:	vcvtsi2sd xmm1,xmm1,rdx
  4114be:	vsubsd xmm0,xmm0,xmm1
  4114c2:	vmulsd xmm0,xmm0,xmm6
  4114c6:	vcvttsd2si rdx,xmm0
  4114cb:	mov    r10b,dl
  4114ce:	add    r10b,0x30
  4114d2:	mov    BYTE PTR [r9+0x9],r10b
  4114d6:	vxorpd xmm1,xmm1,xmm1
  4114da:	movzx  edx,dl
  4114dd:	vcvtsi2sd xmm1,xmm1,rdx
  4114e2:	vsubsd xmm0,xmm0,xmm1
  4114e6:	vmulsd xmm0,xmm0,xmm6
  4114ea:	vcvttsd2si rdx,xmm0
  4114ef:	mov    r10b,dl
  4114f2:	add    r10b,0x30
  4114f6:	mov    BYTE PTR [r9+0xa],r10b
  4114fa:	vxorpd xmm1,xmm1,xmm1
  4114fe:	movzx  edx,dl
  411501:	vcvtsi2sd xmm1,xmm1,rdx
  411506:	vsubsd xmm0,xmm0,xmm1
  41150a:	vmulsd xmm0,xmm0,xmm6
  41150e:	vcvttsd2si rdx,xmm0
  411513:	mov    r10b,dl
  411516:	add    r10b,0x30
  41151a:	mov    BYTE PTR [r9+0xb],r10b
  41151e:	lea    r10,[r9+0x4]
  411522:	vxorpd xmm1,xmm1,xmm1
  411526:	movzx  edx,dl
  411529:	vcvtsi2sd xmm1,xmm1,rdx
  41152e:	vsubsd xmm0,xmm0,xmm1
  411532:	vmulsd xmm0,xmm0,xmm6
  411536:	vcvttsd2si rdx,xmm0
  41153b:	mov    r11b,dl
  41153e:	add    r11b,0x30
  411542:	mov    BYTE PTR [r9+0xc],r11b
  411546:	vxorpd xmm1,xmm1,xmm1
  41154a:	movzx  edx,dl
  41154d:	vcvtsi2sd xmm1,xmm1,rdx
  411552:	vsubsd xmm0,xmm0,xmm1
  411556:	vmulsd xmm0,xmm0,xmm6
  41155a:	vcvttsd2si rdx,xmm0
  41155f:	mov    r11b,dl
  411562:	add    r11b,0x30
  411566:	mov    BYTE PTR [r9+0xd],r11b
  41156a:	lea    r10,[r10+0x2]
  41156e:	vxorpd xmm1,xmm1,xmm1
  411572:	movzx  edx,dl
  411575:	vcvtsi2sd xmm1,xmm1,rdx
  41157a:	vsubsd xmm0,xmm0,xmm1
  41157e:	vmulsd xmm0,xmm0,xmm6
  411582:	vcvttsd2si rdx,xmm0
  411587:	mov    r11b,dl
  41158a:	add    r11b,0x30
  41158e:	mov    BYTE PTR [r9+0xe],r11b
  411592:	vxorpd xmm1,xmm1,xmm1
  411596:	movzx  edx,dl
  411599:	vcvtsi2sd xmm1,xmm1,rdx
  41159e:	vsubsd xmm0,xmm0,xmm1
  4115a2:	vmulsd xmm0,xmm0,xmm6
  4115a6:	vcvttsd2si rdx,xmm0
  4115ab:	mov    r11b,dl
  4115ae:	add    r11b,0x30
  4115b2:	mov    BYTE PTR [r9+0xf],r11b
  4115b6:	lea    r10,[r10+0x2]
  4115ba:	lea    r10,[r10+0x2]
  4115be:	lea    r10,[r10+0x2]
  4115c2:	lea    r10,[r10+0x2]
  4115c6:	lea    r10,[r10+0x2]
  4115ca:	vxorpd xmm1,xmm1,xmm1
  4115ce:	movzx  edx,dl
  4115d1:	vcvtsi2sd xmm1,xmm1,rdx
  4115d6:	vsubsd xmm0,xmm0,xmm1
  4115da:	vmulsd xmm0,xmm0,xmm6
  4115de:	vcvttsd2si rdx,xmm0
  4115e3:	mov    r11b,dl
  4115e6:	add    r11b,0x30
  4115ea:	mov    BYTE PTR [r9+0x10],r11b
  4115ee:	vxorpd xmm1,xmm1,xmm1
  4115f2:	movzx  edx,dl
  4115f5:	vcvtsi2sd xmm1,xmm1,rdx
  4115fa:	vsubsd xmm0,xmm0,xmm1
  4115fe:	vmulsd xmm0,xmm0,xmm6
  411602:	vcvttsd2si rdx,xmm0
  411607:	add    dl,0x30
  41160a:	mov    BYTE PTR [r9+0x11],dl
  41160e:	mov    BYTE PTR [r10+0x2],0x65
  411613:	lea    r9,[r10+0x3]
  411617:	test   r8,r8
  41161a:	jl     411623 <__swc_fn_3464c816_000146_d2097256+0xd43>
  41161c:	mov    BYTE PTR [r9],0x2b
  411620:	inc    r9
  411623:	mov    r10,r9
  411626:	mov    rdx,r8
  411629:	nop    DWORD PTR [rax+0x0]
  411630:	mov    r11,rdx
  411633:	movabs rdx,0x6666666666666667
  41163d:	mov    rax,r11
  411640:	imul   rdx
  411643:	sar    rdx,0x2
  411647:	mov    r12,rdx
  41164a:	shr    rdx,0x3f
  41164e:	add    r12,rdx
  411651:	mov    rdx,r12
  411654:	imul   r13,r12,0xa
  411658:	sub    r11,r13
  41165b:	mov    r13,QWORD PTR [rip+0x1ede]        # 413540 <__swc_rdata_base_3464c816+0x430>
  411662:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411667:	mov    BYTE PTR [r10],r11b
  41166a:	lea    r11,[r10+0x1]
  41166e:	mov    r10,r11
  411671:	test   r12,r12
  411674:	jne    411630 <__swc_fn_3464c816_000146_d2097256+0xd50>
  411676:	test   r8,r8
  411679:	jge    411683 <__swc_fn_3464c816_000146_d2097256+0xda3>
  41167b:	mov    BYTE PTR [r11],0x2d
  41167f:	lea    r10,[r11+0x1]
  411683:	mov    BYTE PTR [r10],0x0
  411687:	sub    r10,0x1
  41168b:	nop    DWORD PTR [rax+rax*1+0x0]
  411690:	cmp    r9,r10
  411693:	jae    411908 <__swc_fn_3464c816_000146_d2097256+0x1028>
  411699:	mov    al,BYTE PTR [r10]
  41169c:	mov    dl,BYTE PTR [r9]
  41169f:	mov    BYTE PTR [r10],dl
  4116a2:	sub    r10,0x1
  4116a6:	mov    BYTE PTR [r9],al
  4116a9:	inc    r9
  4116ac:	jmp    411690 <__swc_fn_3464c816_000146_d2097256+0xdb0>
  4116ae:	vcvttsd2si rdx,xmm0
  4116b3:	mov    r8,rdx
  4116b6:	vxorpd xmm1,xmm1,xmm1
  4116ba:	vcvtsi2sd xmm1,xmm1,rdx
  4116bf:	vsubsd xmm1,xmm0,xmm1
  4116c3:	mov    r9d,0x8
  4116c9:	vxorpd xmm2,xmm2,xmm2
  4116cd:	vcomisd xmm2,xmm1
  4116d1:	ja     4116de <__swc_fn_3464c816_000146_d2097256+0xdfe>
  4116d3:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  4116dc:	jmp    4116ef <__swc_fn_3464c816_000146_d2097256+0xe0f>
  4116de:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1e6a]        # 413550 <__swc_rdata_base_3464c816+0x440>
  4116e6:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  4116ef:	test   r9d,r9d
  4116f2:	je     411709 <__swc_fn_3464c816_000146_d2097256+0xe29>
  4116f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4116fe:	xchg   ax,ax
  411700:	vmulsd xmm1,xmm1,xmm6
  411704:	dec    r9d
  411707:	jne    411700 <__swc_fn_3464c816_000146_d2097256+0xe20>
  411709:	vcvttsd2si r9,xmm1
  41170e:	mov    r10,r9
  411711:	vxorpd xmm2,xmm2,xmm2
  411715:	vcvtsi2sd xmm2,xmm2,r9
  41171a:	vsubsd xmm1,xmm1,xmm2
  41171e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  411727:	vcomisd xmm1,xmm6
  41172b:	lea    r9,[r9+0x1]
  41172f:	cmova  r10,r9
  411733:	cmp    r10,0x5f5e100
  41173a:	jne    411753 <__swc_fn_3464c816_000146_d2097256+0xe73>
  41173c:	lea    r8,[rdx-0x1]
  411740:	vxorpd xmm1,xmm1,xmm1
  411744:	vcomisd xmm1,xmm0
  411748:	lea    rdx,[rdx+0x1]
  41174c:	cmovbe r8,rdx
  411750:	xor    r10d,r10d
  411753:	mov    r9,rcx
  411756:	test   r8,r8
  411759:	jne    411779 <__swc_fn_3464c816_000146_d2097256+0xe99>
  41175b:	vxorpd xmm1,xmm1,xmm1
  41175f:	vcomisd xmm1,xmm0
  411763:	jbe    41176c <__swc_fn_3464c816_000146_d2097256+0xe8c>
  411765:	mov    BYTE PTR [rcx],0x2d
  411768:	lea    r9,[rcx+0x1]
  41176c:	mov    BYTE PTR [r9],0x30
  411770:	add    r9,0x1
  411774:	jmp    41180b <__swc_fn_3464c816_000146_d2097256+0xf2b>
  411779:	mov    r9,rcx
  41177c:	mov    rdx,r8
  41177f:	nop
  411780:	mov    r11,rdx
  411783:	movabs rdx,0x6666666666666667
  41178d:	mov    r15,rax
  411790:	mov    rax,r11
  411793:	imul   rdx
  411796:	mov    r12,rdx
  411799:	mov    rax,r15
  41179c:	sar    r12,0x2
  4117a0:	mov    rdx,r12
  4117a3:	shr    rdx,0x3f
  4117a7:	add    r12,rdx
  4117aa:	mov    rdx,r12
  4117ad:	imul   r13,r12,0xa
  4117b1:	sub    r11,r13
  4117b4:	mov    r13,QWORD PTR [rip+0x1d85]        # 413540 <__swc_rdata_base_3464c816+0x430>
  4117bb:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4117c0:	mov    BYTE PTR [r9],r11b
  4117c3:	lea    r11,[r9+0x1]
  4117c7:	mov    r9,r11
  4117ca:	test   r12,r12
  4117cd:	jne    411780 <__swc_fn_3464c816_000146_d2097256+0xea0>
  4117cf:	test   r8,r8
  4117d2:	jge    4117dc <__swc_fn_3464c816_000146_d2097256+0xefc>
  4117d4:	mov    BYTE PTR [r11],0x2d
  4117d8:	lea    r9,[r11+0x1]
  4117dc:	mov    rdx,r9
  4117df:	mov    BYTE PTR [r9],0x0
  4117e3:	sub    r9,0x1
  4117e7:	mov    r8,rcx
  4117ea:	cmp    r8,r9
  4117ed:	jae    411808 <__swc_fn_3464c816_000146_d2097256+0xf28>
  4117ef:	nop
  4117f0:	mov    r11b,BYTE PTR [r9]
  4117f3:	mov    r12b,BYTE PTR [r8]
  4117f6:	mov    BYTE PTR [r9],r12b
  4117f9:	sub    r9,0x1
  4117fd:	mov    BYTE PTR [r8],r11b
  411800:	inc    r8
  411803:	cmp    r8,r9
  411806:	jb     4117f0 <__swc_fn_3464c816_000146_d2097256+0xf10>
  411808:	mov    r9,rdx
  41180b:	mov    BYTE PTR [r9],0x2e
  41180f:	add    r9,0x1
  411813:	xor    r8d,r8d
  411816:	test   r10,r10
  411819:	je     41185f <__swc_fn_3464c816_000146_d2097256+0xf7f>
  41181b:	mov    r11d,0x989680
  411821:	cmp    r10,r11
  411824:	jge    41185f <__swc_fn_3464c816_000146_d2097256+0xf7f>
  411826:	cs nop WORD PTR [rax+rax*1+0x0]
  411830:	inc    r8d
  411833:	movabs rdx,0x6666666666666667
  41183d:	mov    r15,rax
  411840:	mov    rax,r11
  411843:	imul   rdx
  411846:	mov    r11,rdx
  411849:	mov    rax,r15
  41184c:	sar    r11,0x2
  411850:	mov    rdx,r11
  411853:	shr    rdx,0x3f
  411857:	add    r11,rdx
  41185a:	cmp    r10,r11
  41185d:	jl     411830 <__swc_fn_3464c816_000146_d2097256+0xf50>
  41185f:	test   r8d,r8d
  411862:	je     41187d <__swc_fn_3464c816_000146_d2097256+0xf9d>
  411864:	cs nop WORD PTR [rax+rax*1+0x0]
  41186e:	xchg   ax,ax
  411870:	mov    BYTE PTR [r9],0x30
  411874:	add    r9,0x1
  411878:	dec    r8d
  41187b:	jne    411870 <__swc_fn_3464c816_000146_d2097256+0xf90>
  41187d:	mov    r8,r9
  411880:	mov    rdx,r10
  411883:	cs nop WORD PTR [rax+rax*1+0x0]
  41188d:	nop    DWORD PTR [rax]
  411890:	mov    r11,rdx
  411893:	movabs rdx,0x6666666666666667
  41189d:	mov    rax,r11
  4118a0:	imul   rdx
  4118a3:	sar    rdx,0x2
  4118a7:	mov    r12,rdx
  4118aa:	shr    rdx,0x3f
  4118ae:	add    r12,rdx
  4118b1:	mov    rdx,r12
  4118b4:	imul   r13,r12,0xa
  4118b8:	sub    r11,r13
  4118bb:	mov    r13,QWORD PTR [rip+0x1c7e]        # 413540 <__swc_rdata_base_3464c816+0x430>
  4118c2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4118c7:	mov    BYTE PTR [r8],r11b
  4118ca:	lea    r11,[r8+0x1]
  4118ce:	mov    r8,r11
  4118d1:	test   r12,r12
  4118d4:	jne    411890 <__swc_fn_3464c816_000146_d2097256+0xfb0>
  4118d6:	test   r10,r10
  4118d9:	jge    4118e3 <__swc_fn_3464c816_000146_d2097256+0x1003>
  4118db:	mov    BYTE PTR [r11],0x2d
  4118df:	lea    r8,[r11+0x1]
  4118e3:	mov    BYTE PTR [r8],0x0
  4118e7:	sub    r8,0x1
  4118eb:	cmp    r9,r8
  4118ee:	jae    411908 <__swc_fn_3464c816_000146_d2097256+0x1028>
  4118f0:	mov    al,BYTE PTR [r8]
  4118f3:	mov    dl,BYTE PTR [r9]
  4118f6:	mov    BYTE PTR [r8],dl
  4118f9:	sub    r8,0x1
  4118fd:	mov    BYTE PTR [r9],al
  411900:	inc    r9
  411903:	cmp    r9,r8
  411906:	jb     4118f0 <__swc_fn_3464c816_000146_d2097256+0x1010>
  411908:	xor    eax,eax
  41190a:	test   rcx,rcx
  41190d:	je     411930 <__swc_fn_3464c816_000146_d2097256+0x1050>
  41190f:	mov    rdx,rcx
  411912:	mov    r8b,BYTE PTR [rdx]
  411915:	test   r8b,r8b
  411918:	je     411930 <__swc_fn_3464c816_000146_d2097256+0x1050>
  41191a:	nop    WORD PTR [rax+rax*1+0x0]
  411920:	add    rdx,0x1
  411924:	add    rax,0x1
  411928:	mov    r8b,BYTE PTR [rdx]
  41192b:	test   r8b,r8b
  41192e:	jne    411920 <__swc_fn_3464c816_000146_d2097256+0x1040>
  411930:	mov    QWORD PTR [rsp+0x3f8],rcx
  411938:	mov    QWORD PTR [rsp+0x400],rax
  411940:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  411949:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  411952:	lea    rcx,[rsp+0x408]
  41195a:	call   410070 <__swc_fn_3464c816_000116_3f5cfdef>
  41195f:	jmp    4119a5 <__swc_fn_3464c816_000146_d2097256+0x10c5>
  411961:	mov    rcx,rdx
  411964:	call   410070 <__swc_fn_3464c816_000116_3f5cfdef>
  411969:	jmp    4119a5 <__swc_fn_3464c816_000146_d2097256+0x10c5>
  41196b:	mov    al,BYTE PTR [rdx]
  41196d:	test   al,al
  41196f:	je     41197a <__swc_fn_3464c816_000146_d2097256+0x109a>
  411971:	lea    rax,[rip+0x1be8]        # 413560 <__swc_rdata_base_3464c816+0x450>
  411978:	jmp    411981 <__swc_fn_3464c816_000146_d2097256+0x10a1>
  41197a:	lea    rax,[rip+0x1bef]        # 413570 <__swc_rdata_base_3464c816+0x460>
  411981:	mov    rcx,rax
  411984:	call   410070 <__swc_fn_3464c816_000116_3f5cfdef>
  411989:	jmp    4119a5 <__swc_fn_3464c816_000146_d2097256+0x10c5>
  41198b:	lea    rcx,[rip+0x1bee]        # 413580 <__swc_rdata_base_3464c816+0x470>
  411992:	call   410070 <__swc_fn_3464c816_000116_3f5cfdef>
  411997:	jmp    4119a5 <__swc_fn_3464c816_000146_d2097256+0x10c5>
  411999:	lea    rcx,[rip+0x1be0]        # 413580 <__swc_rdata_base_3464c816+0x470>
  4119a0:	call   410070 <__swc_fn_3464c816_000116_3f5cfdef>
  4119a5:	add    rdi,0x1
  4119a9:	sub    rsi,0x1
  4119ad:	vmovups xmm0,xmm12
  4119b2:	vmovsd xmm6,QWORD PTR [rip+0x1bd6]        # 413590 <__swc_rdata_base_3464c816+0x480>
  4119ba:	test   rsi,rsi
  4119bd:	jne    4109f0 <__swc_fn_3464c816_000146_d2097256+0x110>
  4119c3:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  4119cc:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  4119d5:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  4119de:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  4119e7:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  4119f0:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  4119f9:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411a02:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  411a0b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411a14:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  411a1d:	add    rsp,0x4e8
  411a24:	pop    r15
  411a26:	pop    r13
  411a28:	pop    r12
  411a2a:	pop    rdi
  411a2b:	pop    rsi
  411a2c:	pop    rbx
  411a2d:	ret
	...

0000000000411a30 <__swc_fn_3464c816_000149_365b4daf>:
  411a30:	vxorps xmm0,xmm0,xmm0
  411a34:	vmovups XMMWORD PTR [rcx],xmm0
  411a38:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411a3d:	ret
	...

0000000000411a40 <__swc_fn_3464c816_000152_365b4daf>:
  411a40:	vxorps xmm0,xmm0,xmm0
  411a44:	vmovups XMMWORD PTR [rcx],xmm0
  411a48:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411a4d:	vxorps xmm0,xmm0,xmm0
  411a51:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411a56:	vmovups xmm0,XMMWORD PTR [rip+0x1c42]        # 4136a0 <__swc_rdata_base_3464c816+0x590>
  411a5e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411a63:	vxorps xmm0,xmm0,xmm0
  411a67:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411a6c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411a71:	vxorps xmm0,xmm0,xmm0
  411a75:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  411a7a:	mov    QWORD PTR [rcx+0x70],0x0
  411a82:	ret
	...

0000000000411a90 <__swc_fn_3464c816_000155_365b4daf>:
  411a90:	vxorps xmm0,xmm0,xmm0
  411a94:	vmovups XMMWORD PTR [rcx],xmm0
  411a98:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411a9d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411aa2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411aa7:	ret
	...

0000000000411ab0 <__swc_fn_3464c816_000158_31e09513>:
  411ab0:	push   rsi
  411ab1:	push   rdi
  411ab2:	sub    rsp,0x8
  411ab6:	mov    rsi,rcx
  411ab9:	mov    rdi,QWORD PTR [rsi+0x50]
  411abd:	test   rdi,rdi
  411ac0:	je     411ac7 <__swc_fn_3464c816_000158_31e09513+0x17>
  411ac2:	mov    rcx,rsi
  411ac5:	call   rdi
  411ac7:	mov    QWORD PTR [rsi+0x20],0x0
  411acf:	mov    rax,QWORD PTR [rsi+0x30]
  411ad3:	test   rax,rax
  411ad6:	je     411b04 <__swc_fn_3464c816_000158_31e09513+0x54>
  411ad8:	nop    DWORD PTR [rax+rax*1+0x0]
  411ae0:	mov    rdi,QWORD PTR [rax+0x8]
  411ae4:	mov    rcx,rsi
  411ae7:	mov    rdx,QWORD PTR [rax+0x10]
  411aeb:	mov    rax,QWORD PTR [rax+0x18]
  411aef:	mov    r8,rax
  411af2:	call   409e90 <__swc_fn_3464c816_000156_9e2052d6>
  411af7:	mov    QWORD PTR [rsi+0x30],rdi
  411afb:	mov    rax,QWORD PTR [rsi+0x30]
  411aff:	test   rax,rax
  411b02:	jne    411ae0 <__swc_fn_3464c816_000158_31e09513+0x30>
  411b04:	mov    QWORD PTR [rsi+0x38],0x0
  411b0c:	add    rsp,0x8
  411b10:	pop    rdi
  411b11:	pop    rsi
  411b12:	ret
	...

0000000000411b20 <__swc_fn_3464c816_000161_b553c03d>:
  411b20:	push   rbx
  411b21:	push   rsi
  411b22:	push   rdi
  411b23:	push   r12
  411b25:	sub    rsp,0x188
  411b2c:	mov    rbx,rcx
  411b2f:	lea    rsi,[rip+0x1525a]        # 426d90 <__swc_bss_base_3464c816+0x2d50>
  411b36:	mov    rcx,rsi
  411b39:	call   4098a0 <__swc_fn_3464c816_000135_db32cc57>
  411b3e:	mov    rax,QWORD PTR [rip+0x15253]        # 426d98 <__swc_bss_base_3464c816+0x2d58>
  411b45:	mov    rdi,rax
  411b48:	test   rdi,rdi
  411b4b:	je     411b79 <__swc_fn_3464c816_000161_b553c03d+0x59>
  411b4d:	nop    DWORD PTR [rax]
  411b50:	cmp    QWORD PTR [rdi+0x8],rbx
  411b54:	jne    411b6e <__swc_fn_3464c816_000161_b553c03d+0x4e>
  411b56:	mov    rcx,rsi
  411b59:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  411b5e:	mov    rax,rdi
  411b61:	add    rsp,0x188
  411b68:	pop    r12
  411b6a:	pop    rdi
  411b6b:	pop    rsi
  411b6c:	pop    rbx
  411b6d:	ret
  411b6e:	mov    rax,QWORD PTR [rdi]
  411b71:	mov    rdi,rax
  411b74:	test   rax,rax
  411b77:	jne    411b50 <__swc_fn_3464c816_000161_b553c03d+0x30>
  411b79:	call   40ce80 <__swc_fn_3464c816_000139_e4a7a8b1>
  411b7e:	mov    rdi,rax
  411b81:	test   rax,rax
  411b84:	jne    411b9d <__swc_fn_3464c816_000161_b553c03d+0x7d>
  411b86:	mov    rcx,rsi
  411b89:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  411b8e:	xor    eax,eax
  411b90:	add    rsp,0x188
  411b97:	pop    r12
  411b99:	pop    rdi
  411b9a:	pop    rsi
  411b9b:	pop    rbx
  411b9c:	ret
  411b9d:	lea    rax,[rsp+0x18]
  411ba2:	mov    QWORD PTR [rax+0x10],0x0
  411baa:	mov    QWORD PTR [rax+0x18],0x0
  411bb2:	mov    DWORD PTR [rax+0x20],0x0
  411bb9:	mov    BYTE PTR [rax+0x24],0x0
  411bbd:	mov    rax,QWORD PTR [rip+0x151d4]        # 426d98 <__swc_bss_base_3464c816+0x2d58>
  411bc4:	mov    QWORD PTR [rsp+0x18],rax
  411bc9:	mov    QWORD PTR [rsp+0x20],rbx
  411bce:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411bd4:	vmovups XMMWORD PTR [rdi],xmm0
  411bd8:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  411bde:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  411be3:	mov    rax,QWORD PTR [rsp+0x38]
  411be8:	mov    QWORD PTR [rdi+0x20],rax
  411bec:	mov    QWORD PTR [rip+0x151a5],rdi        # 426d98 <__swc_bss_base_3464c816+0x2d58>
  411bf3:	lea    rax,[rsp+0x40]
  411bf8:	mov    QWORD PTR [rax],0x0
  411bff:	mov    rcx,rbx
  411c02:	mov    rdx,rax
  411c05:	call   409980 <__swc_fn_3464c816_000141_5e493395>
  411c0a:	mov    rbx,rax
  411c0d:	test   rax,rax
  411c10:	jne    411c2a <__swc_fn_3464c816_000161_b553c03d+0x10a>
  411c12:	mov    rcx,rsi
  411c15:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  411c1a:	mov    rax,rdi
  411c1d:	add    rsp,0x188
  411c24:	pop    r12
  411c26:	pop    rdi
  411c27:	pop    rsi
  411c28:	pop    rbx
  411c29:	ret
  411c2a:	lea    r12,[rsp+0x50]
  411c2f:	mov    QWORD PTR [r12],0x0
  411c37:	mov    rcx,rbx
  411c3a:	mov    rdx,QWORD PTR [rsp+0x40]
  411c3f:	mov    r8,r12
  411c42:	call   40cf30 <__swc_fn_3464c816_000142_89a6ef72>
  411c47:	test   rax,rax
  411c4a:	jne    411c64 <__swc_fn_3464c816_000161_b553c03d+0x144>
  411c4c:	mov    rcx,rsi
  411c4f:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  411c54:	mov    rax,rdi
  411c57:	add    rsp,0x188
  411c5e:	pop    r12
  411c60:	pop    rdi
  411c61:	pop    rsi
  411c62:	pop    rbx
  411c63:	ret
  411c64:	cmp    QWORD PTR [r12],0x10
  411c69:	jb     411d6c <__swc_fn_3464c816_000161_b553c03d+0x24c>
  411c6f:	mov    ecx,DWORD PTR [rax]
  411c71:	cmp    ecx,0x42445753
  411c77:	jne    411d6c <__swc_fn_3464c816_000161_b553c03d+0x24c>
  411c7d:	mov    ecx,DWORD PTR [rax+0x4]
  411c80:	cmp    ecx,0x1
  411c83:	jne    411d6c <__swc_fn_3464c816_000161_b553c03d+0x24c>
  411c89:	mov    ecx,DWORD PTR [rax+0x8]
  411c8c:	mov    edx,DWORD PTR [rax+0xc]
  411c8f:	imul   r8,rcx,0x14
  411c93:	mov    r9,QWORD PTR [rsp+0x50]
  411c98:	sub    r9,0x10
  411c9c:	cmp    r8,r9
  411c9f:	ja     411d6c <__swc_fn_3464c816_000161_b553c03d+0x24c>
  411ca5:	lea    r8,[r8+0x10]
  411ca9:	cmp    rdx,r8
  411cac:	jb     411d6c <__swc_fn_3464c816_000161_b553c03d+0x24c>
  411cb2:	mov    r8,QWORD PTR [rsp+0x50]
  411cb7:	cmp    rdx,r8
  411cba:	ja     411d6c <__swc_fn_3464c816_000161_b553c03d+0x24c>
  411cc0:	xor    r8d,r8d
  411cc3:	test   rcx,rcx
  411cc6:	jbe    411d92 <__swc_fn_3464c816_000161_b553c03d+0x272>
  411ccc:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  411cd2:	cs nop WORD PTR [rax+rax*1+0x0]
  411cdc:	nop    DWORD PTR [rax+0x0]
  411ce0:	imul   r9,r8,0x14
  411ce4:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  411ce9:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  411cee:	add    r10,r11
  411cf1:	movabs r11,0x100000000
  411cfb:	cmp    r10,r11
  411cfe:	ja     411d6c <__swc_fn_3464c816_000161_b553c03d+0x24c>
  411d00:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  411d05:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  411d0a:	test   r10d,r10d
  411d0d:	setne  r11b
  411d11:	je     411d2b <__swc_fn_3464c816_000161_b553c03d+0x20b>
  411d13:	cmp    r10d,edx
  411d16:	setb   r11b
  411d1a:	jb     411d2b <__swc_fn_3464c816_000161_b553c03d+0x20b>
  411d1c:	vmovq  r11,xmm1
  411d21:	cmp    r10,r11
  411d24:	setae  r10b
  411d28:	mov    r11b,r10b
  411d2b:	mov    r10,r11
  411d2e:	test   r11b,r11b
  411d31:	jne    411d58 <__swc_fn_3464c816_000161_b553c03d+0x238>
  411d33:	test   r9d,r9d
  411d36:	setne  r10b
  411d3a:	je     411d58 <__swc_fn_3464c816_000161_b553c03d+0x238>
  411d3c:	cmp    r9d,edx
  411d3f:	setb   r10b
  411d43:	jb     411d58 <__swc_fn_3464c816_000161_b553c03d+0x238>
  411d45:	vmovq  r10,xmm1
  411d4a:	cmp    r9,r10
  411d4d:	setae  r9b
  411d51:	movzx  r9d,r9b
  411d55:	mov    r10b,r9b
  411d58:	test   r10b,r10b
  411d5b:	jne    411d6c <__swc_fn_3464c816_000161_b553c03d+0x24c>
  411d5d:	add    r8,0x1
  411d61:	cmp    r8,rcx
  411d64:	jb     411ce0 <__swc_fn_3464c816_000161_b553c03d+0x1c0>
  411d6a:	jmp    411d92 <__swc_fn_3464c816_000161_b553c03d+0x272>
  411d6c:	xor    ecx,ecx
  411d6e:	cmp    rax,rbx
  411d71:	cmovne rcx,rax
  411d75:	call   410830 <__swc_fn_3464c816_000143_b7ad855f>
  411d7a:	mov    rcx,rsi
  411d7d:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  411d82:	mov    rax,rdi
  411d85:	add    rsp,0x188
  411d8c:	pop    r12
  411d8e:	pop    rdi
  411d8f:	pop    rsi
  411d90:	pop    rbx
  411d91:	ret
  411d92:	mov    QWORD PTR [rdi+0x10],rax
  411d96:	mov    rcx,QWORD PTR [rsp+0x50]
  411d9b:	mov    QWORD PTR [rdi+0x18],rcx
  411d9f:	mov    eax,DWORD PTR [rax+0x8]
  411da2:	mov    DWORD PTR [rdi+0x20],eax
  411da5:	rex mov BYTE PTR [rdi+0x24],0x1
  411daa:	mov    rcx,rsi
  411dad:	call   40ce70 <__swc_fn_3464c816_000136_d579ef75>
  411db2:	mov    rax,rdi
  411db5:	add    rsp,0x188
  411dbc:	pop    r12
  411dbe:	pop    rdi
  411dbf:	pop    rsi
  411dc0:	pop    rbx
  411dc1:	ret
	...

0000000000411dd0 <__swc_fn_3464c816_000164_d25850aa>:
  411dd0:	push   rsi
  411dd1:	push   rdi
  411dd2:	push   r12
  411dd4:	mov    rsi,rdx
  411dd7:	mov    rdi,rcx
  411dda:	mov    rcx,QWORD PTR [rip+0x14f5f]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  411de1:	test   rcx,rcx
  411de4:	jne    411df6 <__swc_fn_3464c816_000164_d25850aa+0x26>
  411de6:	call   40a1a0 <__swc_fn_3464c816_000165_56054fe7>
  411deb:	lea    rcx,[rax+0x1]
  411def:	mov    QWORD PTR [rip+0x14f4a],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  411df6:	dec    rcx
  411df9:	call   411e20 <__swc_fn_3464c816_000167_39c041ad>
  411dfe:	mov    r12,QWORD PTR [rax+0xbe0]
  411e05:	test   r12,r12
  411e08:	setne  al
  411e0b:	je     411e16 <__swc_fn_3464c816_000164_d25850aa+0x46>
  411e0d:	mov    rcx,rdi
  411e10:	mov    rdx,rsi
  411e13:	call   r12
  411e16:	pop    r12
  411e18:	pop    rdi
  411e19:	pop    rsi
  411e1a:	ret
  411e1b:	add    BYTE PTR [rax],al
  411e1d:	add    BYTE PTR [rax],al
	...

0000000000411e20 <__swc_fn_3464c816_000167_39c041ad>:
  411e20:	push   r12
  411e22:	push   rdi
  411e23:	push   rsi
  411e24:	sub    rsp,0xd0
  411e2b:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  411e31:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  411e37:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  411e3d:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  411e43:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  411e49:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  411e4f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  411e58:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  411e61:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  411e6a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  411e73:	mov    r12,rcx
  411e76:	mov    edi,ecx
  411e78:	xor    eax,eax
  411e7a:	call   407000 <pthread_getspecific@plt>
  411e7f:	test   rax,rax
  411e82:	je     411e86 <__swc_fn_3464c816_000167_39c041ad+0x66>
  411e84:	jmp    411e8e <__swc_fn_3464c816_000167_39c041ad+0x6e>
  411e86:	mov    rcx,r12
  411e89:	call   40a200 <__swc_fn_3464c816_000168_0ad81c51>
  411e8e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  411e94:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  411e9a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  411ea0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  411ea6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  411eac:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  411eb2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  411ebb:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  411ec4:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  411ecd:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  411ed6:	add    rsp,0xd0
  411edd:	pop    rsi
  411ede:	pop    rdi
  411edf:	pop    r12
  411ee1:	ret
	...

0000000000411ef0 <__swc_fn_3464c816_000170_4dbacba0>:
  411ef0:	push   rsi
  411ef1:	sub    rsp,0x30
  411ef5:	lea    rsi,[rip+0x14eac]        # 426da8 <__swc_bss_base_3464c816+0x2d68>
  411efc:	mov    rax,QWORD PTR [rsi]
  411eff:	test   rax,rax
  411f02:	je     411f0a <__swc_fn_3464c816_000170_4dbacba0+0x1a>
  411f04:	add    rsp,0x30
  411f08:	pop    rsi
  411f09:	ret
  411f0a:	mov    ecx,0x3
  411f0f:	mov    edx,0x10
  411f14:	call   40f990 <__swc_fn_3464c816_000107_c8d4a68e>
  411f19:	test   rax,rax
  411f1c:	jne    411f2d <__swc_fn_3464c816_000170_4dbacba0+0x3d>
  411f1e:	mov    QWORD PTR [rsp+0x18],rax
  411f23:	call   40c9d0 <__swc_fn_3464c816_000118_591530fe>
  411f28:	mov    rax,QWORD PTR [rsp+0x18]
  411f2d:	mov    rcx,rax
  411f30:	xchg   QWORD PTR [rsi],rcx
  411f33:	add    rsp,0x30
  411f37:	pop    rsi
  411f38:	ret
  411f39:	add    BYTE PTR [rax],al
  411f3b:	add    BYTE PTR [rax],al
  411f3d:	add    BYTE PTR [rax],al
	...

0000000000411f40 <__swc_fn_3464c816_000173_e17a224b>:
  411f40:	push   rsi
  411f41:	push   rdi
  411f42:	sub    rsp,0x8
  411f46:	mov    rsi,rdx
  411f49:	mov    rdi,rcx
  411f4c:	mov    rax,QWORD PTR [rsi+0x8]
  411f50:	test   rax,rax
  411f53:	je     411f5d <__swc_fn_3464c816_000173_e17a224b+0x1d>
  411f55:	mov    rcx,QWORD PTR [rsi]
  411f58:	mov    QWORD PTR [rax],rcx
  411f5b:	jmp    411f64 <__swc_fn_3464c816_000173_e17a224b+0x24>
  411f5d:	mov    rax,QWORD PTR [rsi]
  411f60:	mov    QWORD PTR [rdi+0x8],rax
  411f64:	mov    rax,QWORD PTR [rsi]
  411f67:	test   rax,rax
  411f6a:	je     411f74 <__swc_fn_3464c816_000173_e17a224b+0x34>
  411f6c:	mov    rcx,QWORD PTR [rsi+0x8]
  411f70:	mov    QWORD PTR [rax+0x8],rcx
  411f74:	mov    rcx,rdi
  411f77:	mov    rdx,QWORD PTR [rsi+0x10]
  411f7b:	mov    r8,QWORD PTR [rsi+0x18]
  411f7f:	mov    r9,0xffffffffffffffff
  411f86:	call   40d580 <__swc_fn_3464c816_000172_1751ecdd>
  411f8b:	mov    QWORD PTR [rsi+0x18],0x0
  411f93:	mov    rax,QWORD PTR [rdi+0x8]
  411f97:	test   rax,rax
  411f9a:	jne    411fac <__swc_fn_3464c816_000173_e17a224b+0x6c>
  411f9c:	call   411ef0 <__swc_fn_3464c816_000170_4dbacba0>
  411fa1:	xor    ecx,ecx
  411fa3:	mov    QWORD PTR [rax+0x8],rcx
  411fa7:	xor    ecx,ecx
  411fa9:	mov    QWORD PTR [rax],rcx
  411fac:	add    rsp,0x8
  411fb0:	pop    rdi
  411fb1:	pop    rsi
  411fb2:	ret
	...

0000000000411fc0 <__swc_fn_3464c816_000176_2744b483>:
  411fc0:	push   rbx
  411fc1:	sub    rsp,0x70
  411fc5:	cmp    rcx,0xffffffffffffffef
  411fc9:	jbe    411fd3 <__swc_fn_3464c816_000176_2744b483+0x13>
  411fcb:	xor    eax,eax
  411fcd:	add    rsp,0x70
  411fd1:	pop    rbx
  411fd2:	ret
  411fd3:	vxorps xmm0,xmm0,xmm0
  411fd7:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  411fdd:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  411fe3:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  411fe9:	vzeroupper
  411fec:	lea    rax,[rcx+0x10]
  411ff0:	mov    QWORD PTR [rsp+0x50],rax
  411ff5:	mov    DWORD PTR [rsp+0x60],0x10
  411ffd:	mov    rcx,QWORD PTR [rip+0x14d3c]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  412004:	test   rcx,rcx
  412007:	jne    412019 <__swc_fn_3464c816_000176_2744b483+0x59>
  412009:	call   40a1a0 <__swc_fn_3464c816_000165_56054fe7>
  41200e:	lea    rcx,[rax+0x1]
  412012:	mov    QWORD PTR [rip+0x14d27],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  412019:	dec    rcx
  41201c:	call   411e20 <__swc_fn_3464c816_000167_39c041ad>
  412021:	mov    rcx,QWORD PTR [rax]
  412024:	lea    rdx,[rsp+0x8]
  412029:	mov    rbx,QWORD PTR [rax+0x8]
  41202d:	mov    rbx,QWORD PTR [rbx+0x8]
  412031:	call   rbx
  412033:	mov    rax,QWORD PTR [rsp+0x48]
  412038:	test   rax,rax
  41203b:	jne    412045 <__swc_fn_3464c816_000176_2744b483+0x85>
  41203d:	xor    eax,eax
  41203f:	add    rsp,0x70
  412043:	pop    rbx
  412044:	ret
  412045:	mov    rcx,QWORD PTR [rsp+0x50]
  41204a:	mov    QWORD PTR [rax],rcx
  41204d:	mov    QWORD PTR [rax+0x8],0x0
  412055:	lea    rax,[rax+0x10]
  412059:	add    rsp,0x70
  41205d:	pop    rbx
  41205e:	ret
