
/workspace/prompt2-20261115/batch5-final-micro/base/chacha/chacha:     file format elf64-x86-64


Disassembly of section .text:

00000000004120a0 <__swc_fn_3464c816_000176_2744b483>:
  4120a0:	push   rbx
  4120a1:	sub    rsp,0x70
  4120a5:	cmp    rcx,0xffffffffffffffef
  4120a9:	jbe    4120b3 <__swc_fn_3464c816_000176_2744b483+0x13>
  4120ab:	xor    eax,eax
  4120ad:	add    rsp,0x70
  4120b1:	pop    rbx
  4120b2:	ret
  4120b3:	vxorps xmm0,xmm0,xmm0
  4120b7:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4120bd:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4120c3:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  4120c9:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  4120cf:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  4120d5:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  4120db:	lea    rax,[rcx+0x10]
  4120df:	mov    QWORD PTR [rsp+0x50],rax
  4120e4:	mov    DWORD PTR [rsp+0x60],0x10
  4120ec:	mov    rcx,QWORD PTR [rip+0x14c4d]        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  4120f3:	test   rcx,rcx
  4120f6:	jne    412108 <__swc_fn_3464c816_000176_2744b483+0x68>
  4120f8:	call   40a1d0 <__swc_fn_3464c816_000165_dc0404ce>
  4120fd:	lea    rcx,[rax+0x1]
  412101:	mov    QWORD PTR [rip+0x14c38],rcx        # 426d40 <__swc_bss_base_3464c816+0x2d00>
  412108:	dec    rcx
  41210b:	call   411f00 <__swc_fn_3464c816_000167_3393d6f4>
  412110:	mov    rcx,QWORD PTR [rax]
  412113:	lea    rdx,[rsp+0x8]
  412118:	mov    rbx,QWORD PTR [rax+0x8]
  41211c:	mov    rbx,QWORD PTR [rbx+0x8]
  412120:	call   rbx
  412122:	mov    rax,QWORD PTR [rsp+0x48]
  412127:	test   rax,rax
  41212a:	jne    412134 <__swc_fn_3464c816_000176_2744b483+0x94>
  41212c:	xor    eax,eax
  41212e:	add    rsp,0x70
  412132:	pop    rbx
  412133:	ret
  412134:	mov    rcx,QWORD PTR [rsp+0x50]
  412139:	mov    QWORD PTR [rax],rcx
  41213c:	mov    QWORD PTR [rax+0x8],0x0
  412144:	lea    rax,[rax+0x10]
  412148:	add    rsp,0x70
  41214c:	pop    rbx
  41214d:	ret
