
/workspace/prompt2-20261115/session-combined-micro/new/nbody/nbody:     file format elf64-x86-64


Disassembly of section .text:

000000000040a560 <__swc_fn_6b1cf01f_000001_0ce64436>:
  40a560:	push   rbp
  40a561:	push   rbx
  40a562:	push   rsi
  40a563:	sub    rsp,0xa8
  40a56a:	mov    rbp,rsp
  40a56d:	vmovups XMMWORD PTR [rsp],xmm6
  40a572:	vmovups XMMWORD PTR [rsp+0x10],xmm7
  40a578:	vmovups XMMWORD PTR [rsp+0x20],xmm8
  40a57e:	vmovups XMMWORD PTR [rsp+0x30],xmm9
  40a584:	vmovups XMMWORD PTR [rsp+0x40],xmm10
  40a58a:	vmovups XMMWORD PTR [rsp+0x50],xmm11
  40a590:	vmovups XMMWORD PTR [rsp+0x60],xmm12
  40a596:	vmovups XMMWORD PTR [rsp+0x70],xmm13
  40a59c:	vmovups XMMWORD PTR [rsp+0x80],xmm14
  40a5a5:	vmovups XMMWORD PTR [rsp+0x90],xmm15
  40a5ae:	sub    rsp,0x510
  40a5b5:	mov    rbx,rsp
  40a5b8:	lea    rax,[rip+0x8b61]        # 413120 <__swc_rdata_base_6b1cf01f+0x10>
  40a5bf:	xor    ecx,ecx
  40a5c1:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5cb:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5d5:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5df:	nop
  40a5e0:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  40a5e5:	vmovdqu XMMWORD PTR [rbx+rcx*1],xmm0
  40a5ea:	add    rcx,0x10
  40a5ee:	cmp    rcx,0x110
  40a5f5:	jne    40a5e0 <__swc_fn_6b1cf01f_000001_0ce64436+0x80>
  40a5f7:	mov    DWORD PTR [rbx+0x110],0x531799ac
  40a601:	mov    DWORD PTR [rbx+0x114],0x3f60a8f3
  40a60b:	sub    rsp,0x8
  40a60f:	call   407270 <__swc_fn_6b1cf01f_000000_1ca87929>
  40a614:	add    rsp,0x8
  40a618:	vmovsd QWORD PTR [rsp+0x2d0],xmm0
  40a621:	vxorpd xmm0,xmm0,xmm0
  40a625:	vmovups xmm2,xmm0
  40a629:	mov    rax,rbx
  40a62c:	vmovsd xmm3,QWORD PTR [rbx+0x18]
  40a631:	vmovsd xmm4,QWORD PTR [rbx+0x30]
  40a636:	vmulsd xmm3,xmm3,xmm4
  40a63a:	vaddsd xmm1,xmm0,xmm3
  40a63e:	vmovsd xmm3,QWORD PTR [rbx+0x20]
  40a643:	vfmadd231sd xmm2,xmm3,xmm4
  40a648:	vmovsd xmm3,QWORD PTR [rbx+0x28]
  40a64d:	vfmadd231sd xmm0,xmm3,xmm4
  40a652:	add    rax,0x38
  40a656:	vmovsd xmm3,QWORD PTR [rax+0x18]
  40a65b:	vmovsd xmm4,QWORD PTR [rax+0x30]
  40a660:	vfmadd231sd xmm1,xmm3,xmm4
  40a665:	vmovsd xmm3,QWORD PTR [rax+0x20]
  40a66a:	vfmadd231sd xmm2,xmm3,xmm4
  40a66f:	vmovsd xmm3,QWORD PTR [rax+0x28]
  40a674:	vfmadd231sd xmm0,xmm3,xmm4
  40a679:	vmovsd xmm3,QWORD PTR [rax+0x50]
  40a67e:	vmovsd xmm4,QWORD PTR [rax+0x68]
  40a683:	vfmadd231sd xmm1,xmm3,xmm4
  40a688:	vmovsd xmm3,QWORD PTR [rax+0x58]
  40a68d:	vfmadd231sd xmm2,xmm3,xmm4
  40a692:	vmovsd xmm3,QWORD PTR [rax+0x60]
  40a697:	vfmadd231sd xmm0,xmm3,xmm4
  40a69c:	vmovsd xmm3,QWORD PTR [rax+0x88]
  40a6a4:	vmovsd xmm4,QWORD PTR [rax+0xa0]
  40a6ac:	vfmadd231sd xmm1,xmm3,xmm4
  40a6b1:	vmovsd xmm3,QWORD PTR [rax+0x90]
  40a6b9:	vfmadd231sd xmm2,xmm3,xmm4
  40a6be:	vmovsd xmm3,QWORD PTR [rax+0x98]
  40a6c6:	vfmadd231sd xmm0,xmm3,xmm4
  40a6cb:	vmovsd xmm3,QWORD PTR [rax+0xc0]
  40a6d3:	vmovsd xmm4,QWORD PTR [rax+0xd8]
  40a6db:	vfmadd231sd xmm1,xmm3,xmm4
  40a6e0:	vmovsd xmm3,QWORD PTR [rax+0xc8]
  40a6e8:	vfmadd231sd xmm2,xmm3,xmm4
  40a6ed:	vmovsd xmm3,QWORD PTR [rax+0xd0]
  40a6f5:	vfmadd231sd xmm0,xmm3,xmm4
  40a6fa:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x8b3e]        # 413240 <__swc_rdata_base_6b1cf01f+0x130>
  40a702:	vmovsd xmm3,QWORD PTR [rip+0x8c4e]        # 413358 <__swc_rdata_base_6b1cf01f+0x248>
  40a70a:	vdivsd xmm1,xmm1,xmm3
  40a70e:	vmovsd QWORD PTR [rbx+0x18],xmm1
  40a713:	vxorpd xmm2,xmm2,XMMWORD PTR [rip+0x8b25]        # 413240 <__swc_rdata_base_6b1cf01f+0x130>
  40a71b:	vdivsd xmm1,xmm2,xmm3
  40a71f:	vmovsd QWORD PTR [rbx+0x20],xmm1
  40a724:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x8b14]        # 413240 <__swc_rdata_base_6b1cf01f+0x130>
  40a72c:	vdivsd xmm0,xmm0,xmm3
  40a730:	vmovsd QWORD PTR [rbx+0x28],xmm0
  40a735:	xor    eax,eax
  40a737:	vmovsd xmm0,QWORD PTR [rip+0x8c22]        # 413361 <__swc_rdata_base_6b1cf01f+0x251>
  40a73f:	vpshufd xmm1,xmm0,0x44
  40a744:	vmovups XMMWORD PTR [rsp+0x2e0],xmm1
  40a74d:	vpunpcklqdq xmm2,xmm0,xmm0
  40a751:	vmovups XMMWORD PTR [rsp+0x2f0],xmm2
  40a75a:	vmovdqu xmm3,XMMWORD PTR [rsp]
  40a75f:	vmovdqu xmm4,XMMWORD PTR [rsp+0x18]
  40a765:	vmovdqu xmm5,XMMWORD PTR [rsp+0x38]
  40a76b:	vmovups XMMWORD PTR [rsp+0x320],xmm5
  40a774:	vmovdqu xmm7,XMMWORD PTR [rsp+0x50]
  40a77a:	vmovdqu xmm8,XMMWORD PTR [rsp+0x70]
  40a780:	vmovups XMMWORD PTR [rsp+0x340],xmm8
  40a789:	vmovdqu xmm9,XMMWORD PTR [rsp+0x88]
  40a792:	vmovdqu xmm10,XMMWORD PTR [rsp+0xa8]
  40a79b:	vmovups XMMWORD PTR [rsp+0x350],xmm10
  40a7a4:	vmovdqu xmm11,XMMWORD PTR [rsp+0xc0]
  40a7ad:	vmovdqu xmm12,XMMWORD PTR [rsp+0xe0]
  40a7b6:	vmovups XMMWORD PTR [rsp+0x360],xmm11
  40a7bf:	vmovups XMMWORD PTR [rsp+0x370],xmm12
  40a7c8:	vmovdqu xmm13,XMMWORD PTR [rsp+0xf8]
  40a7d1:	mov    rcx,QWORD PTR [rsp+0x68]
  40a7d6:	mov    rdx,QWORD PTR [rsp+0x30]
  40a7db:	mov    r8,QWORD PTR [rsp+0xa0]
  40a7e3:	mov    r9,QWORD PTR [rsp+0xd8]
  40a7eb:	mov    r10,QWORD PTR [rsp+0x110]
  40a7f3:	jmp    40a854 <__swc_fn_6b1cf01f_000001_0ce64436+0x2f4>
  40a7f5:	cs nop WORD PTR [rax+rax*1+0x0]
  40a7ff:	cs nop WORD PTR [rax+rax*1+0x0]
  40a809:	nop    DWORD PTR [rax+0x0]
  40a810:	vmovups xmm2,XMMWORD PTR [rsp+0x2f0]
  40a819:	vmovups xmm4,XMMWORD PTR [rsp+0x310]
  40a822:	vmovups xmm5,XMMWORD PTR [rsp+0x320]
  40a82b:	vmovups xmm10,xmm13
  40a830:	vmovups XMMWORD PTR [rsp+0x360],xmm7
  40a839:	vmovups xmm12,xmm11
  40a83e:	vmovups xmm13,xmm3
  40a842:	vmovups xmm3,XMMWORD PTR [rsp+0x300]
  40a84b:	vmovups xmm7,XMMWORD PTR [rsp+0x330]
  40a854:	vsubpd xmm14,xmm3,xmm5
  40a858:	vpsrldq xmm6,xmm14,0x8
  40a85e:	vmovsd xmm15,QWORD PTR [rbx+0x10]
  40a863:	vmovsd QWORD PTR [rsp+0x390],xmm15
  40a86c:	vmovsd xmm0,QWORD PTR [rbx+0x48]
  40a871:	vmovq  rsi,xmm0
  40a876:	vsubsd xmm5,xmm15,xmm0
  40a87a:	vmulsd xmm0,xmm14,xmm14
  40a87f:	vfmadd231sd xmm0,xmm6,xmm6
  40a884:	vfmadd231sd xmm0,xmm5,xmm5
  40a889:	vsubpd xmm6,xmm3,xmm8
  40a88e:	vmulsd xmm8,xmm6,xmm6
  40a892:	vmovups XMMWORD PTR [rsp+0x380],xmm13
  40a89b:	vpsrldq xmm13,xmm6,0x8
  40a8a0:	vfmadd231sd xmm8,xmm13,xmm13
  40a8a5:	vmovsd xmm13,QWORD PTR [rbx+0x80]
  40a8ad:	vmovsd QWORD PTR [rsp+0x3a0],xmm13
  40a8b6:	vsubsd xmm1,xmm15,xmm13
  40a8bb:	vfmadd231sd xmm8,xmm1,xmm1
  40a8c0:	vpunpcklqdq xmm0,xmm0,xmm8
  40a8c5:	vsqrtpd xmm8,xmm0
  40a8c9:	vmulpd xmm0,xmm0,xmm8
  40a8ce:	vdivpd xmm0,xmm2,xmm0
  40a8d2:	vpshufd xmm8,xmm0,0x44
  40a8d7:	vmovq  xmm13,rcx
  40a8dc:	vpshufd xmm13,xmm13,0x44
  40a8e2:	vmulpd xmm11,xmm14,xmm13
  40a8e7:	vmovups XMMWORD PTR [rsp+0x3b0],xmm13
  40a8f0:	vmovq  xmm13,rcx
  40a8f5:	vfnmadd231pd xmm4,xmm11,xmm8
  40a8fa:	vmulsd xmm11,xmm5,xmm13
  40a8ff:	vfnmadd213sd xmm11,xmm0,QWORD PTR [rbx+0x28]
  40a905:	vmovq  xmm13,rdx
  40a90a:	vpshufd xmm13,xmm13,0x44
  40a910:	vmulpd xmm14,xmm14,xmm13
  40a915:	vmulpd xmm8,xmm14,xmm8
  40a91a:	vmovq  xmm14,rdx
  40a91f:	vaddpd xmm7,xmm7,xmm8
  40a924:	vmovups XMMWORD PTR [rsp+0x3d0],xmm7
  40a92d:	vmulsd xmm5,xmm5,xmm14
  40a932:	vfmadd213sd xmm5,xmm0,QWORD PTR [rbx+0x60]
  40a938:	vmovsd QWORD PTR [rsp+0x3e0],xmm5
  40a941:	vmulpd xmm8,xmm6,xmm13
  40a946:	vpsrldq xmm0,xmm0,0x8
  40a94b:	vpshufd xmm5,xmm0,0x44
  40a950:	vmulpd xmm8,xmm8,xmm5
  40a954:	vmovq  xmm2,r8
  40a959:	vpshufd xmm2,xmm2,0x44
  40a95e:	vmulpd xmm6,xmm6,xmm2
  40a962:	vfnmadd231pd xmm4,xmm6,xmm5
  40a967:	vmovq  xmm5,r8
  40a96c:	vmulsd xmm6,xmm1,xmm5
  40a970:	vfnmadd213sd xmm6,xmm0,xmm11
  40a975:	vaddpd xmm8,xmm9,xmm8
  40a97a:	vmovups XMMWORD PTR [rsp+0x410],xmm8
  40a983:	vmulsd xmm1,xmm1,xmm14
  40a988:	vmulsd xmm0,xmm1,xmm0
  40a98c:	vaddsd xmm0,xmm0,QWORD PTR [rbx+0x98]
  40a994:	vmovsd QWORD PTR [rsp+0x420],xmm0
  40a99d:	vsubpd xmm1,xmm3,xmm10
  40a9a2:	vmulpd xmm9,xmm1,xmm13
  40a9a7:	vpsrldq xmm0,xmm1,0x8
  40a9ac:	vmovsd xmm11,QWORD PTR [rbx+0xb8]
  40a9b4:	vmovsd QWORD PTR [rsp+0x428],xmm11
  40a9bd:	vsubsd xmm5,xmm15,xmm11
  40a9c2:	vmulsd xmm8,xmm1,xmm1
  40a9c6:	vfmadd213sd xmm0,xmm0,xmm8
  40a9cb:	vfmadd231sd xmm0,xmm5,xmm5
  40a9d0:	vsubpd xmm8,xmm3,xmm12
  40a9d5:	vmulsd xmm12,xmm8,xmm8
  40a9da:	vpsrldq xmm7,xmm8,0x8
  40a9e0:	vmulsd xmm7,xmm7,xmm7
  40a9e4:	vaddsd xmm7,xmm12,xmm7
  40a9e8:	vmovsd xmm12,QWORD PTR [rbx+0xf0]
  40a9f0:	vmovq  r11,xmm12
  40a9f5:	vsubsd xmm11,xmm15,xmm12
  40a9fa:	vfmadd231sd xmm7,xmm11,xmm11
  40a9ff:	vpunpcklqdq xmm0,xmm0,xmm7
  40aa03:	vsqrtpd xmm7,xmm0
  40aa07:	vmulpd xmm0,xmm0,xmm7
  40aa0b:	vmovups xmm15,XMMWORD PTR [rsp+0x2f0]
  40aa14:	vdivpd xmm0,xmm15,xmm0
  40aa18:	vpshufd xmm7,xmm0,0x44
  40aa1d:	vmulpd xmm9,xmm9,xmm7
  40aa21:	vmovq  xmm12,r9
  40aa26:	vpshufd xmm12,xmm12,0x44
  40aa2c:	vmulpd xmm1,xmm1,xmm12
  40aa31:	vfnmadd213pd xmm1,xmm7,xmm4
  40aa36:	vmovq  xmm7,r9
  40aa3b:	vmovsd QWORD PTR [rsp+0x450],xmm7
  40aa44:	vmulsd xmm4,xmm5,xmm7
  40aa48:	vfnmadd231sd xmm6,xmm4,xmm0
  40aa4d:	vaddpd xmm9,xmm9,XMMWORD PTR [rsp+0x360]
  40aa56:	vmulsd xmm4,xmm5,xmm14
  40aa5b:	vmovsd xmm5,QWORD PTR [rbx+0xd0]
  40aa63:	vfmadd231sd xmm5,xmm4,xmm0
  40aa68:	vmovsd QWORD PTR [rsp+0x458],xmm5
  40aa71:	vmulpd xmm4,xmm8,xmm13
  40aa76:	vpsrldq xmm0,xmm0,0x8
  40aa7b:	vpshufd xmm13,xmm0,0x44
  40aa80:	vmulpd xmm4,xmm4,xmm13
  40aa85:	vmovq  xmm5,r10
  40aa8a:	vpshufd xmm5,xmm5,0x44
  40aa8f:	vmovups XMMWORD PTR [rsp+0x460],xmm5
  40aa98:	vmulpd xmm8,xmm8,xmm5
  40aa9c:	vmulpd xmm8,xmm8,xmm13
  40aaa1:	vmovups xmm13,xmm4
  40aaa5:	vsubpd xmm4,xmm1,xmm8
  40aaaa:	vfmadd231pd xmm3,xmm4,XMMWORD PTR [rsp+0x2e0]
  40aab4:	vmovq  xmm8,r10
  40aab9:	vmovups XMMWORD PTR [rsp+0x300],xmm3
  40aac2:	vmovsd QWORD PTR [rsp+0x470],xmm8
  40aacb:	vaddpd xmm3,xmm13,XMMWORD PTR [rsp+0x380]
  40aad4:	vmovups XMMWORD PTR [rsp+0x480],xmm3
  40aadd:	vmulsd xmm13,xmm11,xmm8
  40aae2:	vfnmadd231sd xmm6,xmm13,xmm0
  40aae7:	vmovsd QWORD PTR [rbx+0x28],xmm6
  40aaec:	vmulsd xmm11,xmm11,xmm14
  40aaf1:	vmulsd xmm0,xmm11,xmm0
  40aaf5:	vaddsd xmm0,xmm0,QWORD PTR [rbx+0x108]
  40aafd:	vmovups xmm13,XMMWORD PTR [rsp+0x320]
  40ab06:	vmovsd QWORD PTR [rsp+0x498],xmm0
  40ab0f:	vsubpd xmm14,xmm13,XMMWORD PTR [rsp+0x340]
  40ab18:	vmovups XMMWORD PTR [rsp+0x310],xmm4
  40ab21:	vmulpd xmm4,xmm14,xmm2
  40ab25:	vmovups xmm6,XMMWORD PTR [rsp+0x3b0]
  40ab2e:	vmovups XMMWORD PTR [rsp+0x3f0],xmm2
  40ab37:	vmulpd xmm2,xmm14,xmm6
  40ab3b:	vpsrldq xmm8,xmm14,0x8
  40ab41:	vmovq  xmm0,rsi
  40ab46:	vsubsd xmm1,xmm0,QWORD PTR [rsp+0x3a0]
  40ab4f:	vmulsd xmm3,xmm14,xmm14
  40ab54:	vfmadd231sd xmm3,xmm8,xmm8
  40ab59:	vfmadd231sd xmm3,xmm1,xmm1
  40ab5e:	vsubpd xmm8,xmm13,xmm10
  40ab63:	vmulsd xmm14,xmm8,xmm8
  40ab68:	vpsrldq xmm10,xmm8,0x8
  40ab6e:	vmulsd xmm10,xmm10,xmm10
  40ab73:	vaddsd xmm10,xmm14,xmm10
  40ab78:	vsubsd xmm11,xmm0,QWORD PTR [rsp+0x428]
  40ab81:	vfmadd231sd xmm10,xmm11,xmm11
  40ab86:	vpunpcklqdq xmm3,xmm3,xmm10
  40ab8b:	vsqrtpd xmm10,xmm3
  40ab8f:	vmulpd xmm3,xmm3,xmm10
  40ab94:	vdivpd xmm3,xmm15,xmm3
  40ab98:	vpshufd xmm10,xmm3,0x44
  40ab9d:	vfnmadd213pd xmm4,xmm10,XMMWORD PTR [rsp+0x3d0]
  40aba7:	vmulpd xmm2,xmm2,xmm10
  40abac:	vaddpd xmm2,xmm2,XMMWORD PTR [rsp+0x410]
  40abb5:	vmovq  xmm10,r8
  40abba:	vmovups XMMWORD PTR [rsp+0x4a0],xmm2
  40abc3:	vmulsd xmm14,xmm1,xmm10
  40abc8:	vmovsd xmm10,QWORD PTR [rsp+0x3e0]
  40abd1:	vfnmadd231sd xmm10,xmm14,xmm3
  40abd6:	vmovq  xmm14,rcx
  40abdb:	vmulsd xmm1,xmm1,xmm14
  40abe0:	vfmadd213sd xmm1,xmm3,QWORD PTR [rsp+0x420]
  40abea:	vmovsd QWORD PTR [rsp+0x4b0],xmm1
  40abf3:	vmulpd xmm2,xmm8,xmm12
  40abf8:	vmulpd xmm8,xmm8,xmm6
  40abfc:	vpsrldq xmm3,xmm3,0x8
  40ac01:	vpshufd xmm1,xmm3,0x44
  40ac06:	vfnmadd213pd xmm2,xmm1,xmm4
  40ac0b:	vfmadd213pd xmm1,xmm8,xmm9
  40ac10:	vmulsd xmm4,xmm11,xmm7
  40ac14:	vfnmadd213sd xmm4,xmm3,xmm10
  40ac19:	vmulsd xmm8,xmm11,xmm14
  40ac1e:	vmulsd xmm3,xmm8,xmm3
  40ac22:	vaddsd xmm3,xmm3,QWORD PTR [rsp+0x458]
  40ac2b:	vmovsd QWORD PTR [rsp+0x4b8],xmm3
  40ac34:	vsubpd xmm9,xmm13,XMMWORD PTR [rsp+0x370]
  40ac3d:	vmulpd xmm10,xmm9,xmm5
  40ac41:	vmulpd xmm6,xmm9,xmm6
  40ac45:	vpsrldq xmm7,xmm9,0x8
  40ac4b:	vmovq  xmm11,r11
  40ac50:	vsubsd xmm5,xmm0,xmm11
  40ac55:	vmulsd xmm0,xmm9,xmm9
  40ac5a:	vfmadd231sd xmm0,xmm7,xmm7
  40ac5f:	vfmadd231sd xmm0,xmm5,xmm5
  40ac64:	vmovups xmm9,XMMWORD PTR [rsp+0x340]
  40ac6d:	vsubpd xmm11,xmm9,XMMWORD PTR [rsp+0x350]
  40ac76:	vmulsd xmm7,xmm11,xmm11
  40ac7b:	vpsrldq xmm8,xmm11,0x8
  40ac81:	vfmadd231sd xmm7,xmm8,xmm8
  40ac86:	vmovsd xmm8,QWORD PTR [rsp+0x3a0]
  40ac8f:	vsubsd xmm3,xmm8,QWORD PTR [rsp+0x428]
  40ac98:	vfmadd231sd xmm7,xmm3,xmm3
  40ac9d:	vpunpcklqdq xmm0,xmm0,xmm7
  40aca1:	vsqrtpd xmm7,xmm0
  40aca5:	vmulpd xmm0,xmm0,xmm7
  40aca9:	vdivpd xmm0,xmm15,xmm0
  40acad:	vpshufd xmm9,xmm0,0x44
  40acb2:	vmulpd xmm7,xmm10,xmm9
  40acb7:	vmovsd xmm15,QWORD PTR [rsp+0x450]
  40acc0:	vsubpd xmm7,xmm2,xmm7
  40acc4:	vmovups xmm2,XMMWORD PTR [rsp+0x2e0]
  40accd:	vfmadd231pd xmm13,xmm7,xmm2
  40acd2:	vmovups XMMWORD PTR [rsp+0x320],xmm13
  40acdb:	vmulpd xmm6,xmm6,xmm9
  40ace0:	vaddpd xmm6,xmm6,XMMWORD PTR [rsp+0x480]
  40ace9:	vmovsd xmm10,QWORD PTR [rsp+0x470]
  40acf2:	vmulsd xmm9,xmm5,xmm10
  40acf7:	vfnmadd231sd xmm4,xmm9,xmm0
  40acfc:	vmovsd QWORD PTR [rbx+0x60],xmm4
  40ad01:	vmulsd xmm5,xmm5,xmm14
  40ad06:	vfmadd213sd xmm5,xmm0,QWORD PTR [rsp+0x498]
  40ad10:	vmulpd xmm9,xmm11,xmm12
  40ad15:	vmovups xmm14,XMMWORD PTR [rsp+0x3f0]
  40ad1e:	vmulpd xmm11,xmm11,xmm14
  40ad23:	vpsrldq xmm0,xmm0,0x8
  40ad28:	vpshufd xmm13,xmm0,0x44
  40ad2d:	vmovups XMMWORD PTR [rsp+0x330],xmm7
  40ad36:	vmovups xmm7,XMMWORD PTR [rsp+0x4a0]
  40ad3f:	vfnmadd231pd xmm7,xmm9,xmm13
  40ad44:	vfmadd231pd xmm1,xmm11,xmm13
  40ad49:	vmovups XMMWORD PTR [rsp+0x4d0],xmm1
  40ad52:	vmulsd xmm9,xmm3,xmm15
  40ad57:	vmovsd xmm11,QWORD PTR [rsp+0x4b0]
  40ad60:	vfnmadd231sd xmm11,xmm9,xmm0
  40ad65:	vmovq  xmm13,r8
  40ad6a:	vmulsd xmm3,xmm3,xmm13
  40ad6f:	vmulsd xmm0,xmm3,xmm0
  40ad73:	vaddsd xmm0,xmm0,QWORD PTR [rsp+0x4b8]
  40ad7c:	vmovups xmm9,XMMWORD PTR [rsp+0x340]
  40ad85:	vmovups xmm3,XMMWORD PTR [rsp+0x370]
  40ad8e:	vmovsd QWORD PTR [rsp+0x4e0],xmm0
  40ad97:	vsubpd xmm4,xmm9,xmm3
  40ad9b:	vmulpd xmm15,xmm4,XMMWORD PTR [rsp+0x460]
  40ada4:	vmulpd xmm14,xmm4,xmm14
  40ada9:	vpsrldq xmm0,xmm4,0x8
  40adae:	vmovq  xmm9,r11
  40adb3:	vsubsd xmm1,xmm8,xmm9
  40adb8:	vmulsd xmm4,xmm4,xmm4
  40adbc:	vfmadd213sd xmm0,xmm0,xmm4
  40adc1:	vfmadd231sd xmm0,xmm1,xmm1
  40adc6:	vmovups xmm4,XMMWORD PTR [rsp+0x350]
  40adcf:	vsubpd xmm8,xmm4,xmm3
  40add3:	vmovups XMMWORD PTR [rsp+0x4f0],xmm8
  40addc:	vmulsd xmm3,xmm8,xmm8
  40ade1:	vpsrldq xmm4,xmm8,0x8
  40ade7:	vfmadd231sd xmm3,xmm4,xmm4
  40adec:	vmovsd xmm4,QWORD PTR [rsp+0x428]
  40adf5:	vmovups XMMWORD PTR [rsp+0x440],xmm12
  40adfe:	vsubsd xmm12,xmm4,xmm9
  40ae03:	vmovsd QWORD PTR [rsp+0x500],xmm12
  40ae0c:	vfmadd231sd xmm3,xmm12,xmm12
  40ae11:	vpunpcklqdq xmm0,xmm0,xmm3
  40ae15:	vsqrtpd xmm3,xmm0
  40ae19:	vmulpd xmm0,xmm0,xmm3
  40ae1d:	vmovups xmm4,XMMWORD PTR [rsp+0x2f0]
  40ae26:	vdivpd xmm0,xmm4,xmm0
  40ae2a:	vpshufd xmm3,xmm0,0x44
  40ae2f:	vmulpd xmm15,xmm15,xmm3
  40ae33:	vmovups xmm8,XMMWORD PTR [rsp+0x340]
  40ae3c:	vmovups xmm4,xmm9
  40ae41:	vmovups xmm12,XMMWORD PTR [rsp+0x460]
  40ae4a:	vsubpd xmm9,xmm7,xmm15
  40ae4f:	vfmadd231pd xmm8,xmm9,xmm2
  40ae54:	vmovups XMMWORD PTR [rsp+0x340],xmm8
  40ae5d:	vfmadd213pd xmm3,xmm14,xmm6
  40ae62:	vmulsd xmm6,xmm1,xmm10
  40ae67:	vfnmadd213sd xmm6,xmm0,xmm11
  40ae6c:	vmovsd QWORD PTR [rbx+0x98],xmm6
  40ae74:	vmulsd xmm1,xmm1,xmm13
  40ae79:	vfmadd213sd xmm1,xmm0,xmm5
  40ae7e:	vmovups xmm5,XMMWORD PTR [rsp+0x4f0]
  40ae87:	vmulpd xmm7,xmm5,xmm12
  40ae8c:	vmulpd xmm5,xmm5,XMMWORD PTR [rsp+0x440]
  40ae95:	vpsrldq xmm0,xmm0,0x8
  40ae9a:	vpshufd xmm11,xmm0,0x44
  40ae9f:	vfnmadd213pd xmm7,xmm11,XMMWORD PTR [rsp+0x4d0]
  40aea9:	vmovups xmm13,XMMWORD PTR [rsp+0x350]
  40aeb2:	vfmadd231pd xmm13,xmm7,xmm2
  40aeb7:	vmovups XMMWORD PTR [rsp+0x350],xmm13
  40aec0:	vmulpd xmm5,xmm5,xmm11
  40aec5:	vmovups xmm11,XMMWORD PTR [rsp+0x370]
  40aece:	vmovsd xmm12,QWORD PTR [rsp+0x3a0]
  40aed7:	vaddpd xmm3,xmm3,xmm5
  40aedb:	vfmadd231pd xmm11,xmm3,xmm2
  40aee0:	vmovsd xmm5,QWORD PTR [rsp+0x500]
  40aee9:	vmovups XMMWORD PTR [rsp+0x370],xmm11
  40aef2:	vmulsd xmm10,xmm5,xmm10
  40aef7:	vfnmadd213sd xmm10,xmm0,QWORD PTR [rsp+0x4e0]
  40af01:	vmovsd QWORD PTR [rbx+0xd0],xmm10
  40af09:	vmulsd xmm5,xmm5,QWORD PTR [rsp+0x450]
  40af12:	vfmadd213sd xmm0,xmm5,xmm1
  40af17:	vmovsd QWORD PTR [rbx+0x108],xmm0
  40af1f:	vmovsd xmm5,QWORD PTR [rip+0x843a]        # 413361 <__swc_rdata_base_6b1cf01f+0x251>
  40af27:	vmovsd xmm1,QWORD PTR [rbx+0x28]
  40af2c:	vfmadd213sd xmm1,xmm5,QWORD PTR [rsp+0x390]
  40af36:	vmovsd QWORD PTR [rbx+0x10],xmm1
  40af3b:	vmovsd xmm1,QWORD PTR [rbx+0x60]
  40af40:	vmovq  xmm14,rsi
  40af45:	vfmadd213sd xmm1,xmm5,xmm14
  40af4a:	vmovsd QWORD PTR [rbx+0x48],xmm1
  40af4f:	vmulsd xmm1,xmm6,xmm5
  40af53:	vaddsd xmm1,xmm12,xmm1
  40af57:	vmovsd QWORD PTR [rbx+0x80],xmm1
  40af5f:	vmulsd xmm1,xmm10,xmm5
  40af63:	vaddsd xmm1,xmm1,QWORD PTR [rsp+0x428]
  40af6c:	vmovsd QWORD PTR [rbx+0xb8],xmm1
  40af74:	vfmadd213sd xmm0,xmm5,xmm4
  40af79:	vmovsd QWORD PTR [rbx+0xf0],xmm0
  40af81:	add    rax,0x1
  40af85:	cmp    rax,0x7a120
  40af8c:	jl     40a810 <__swc_fn_6b1cf01f_000001_0ce64436+0x2b0>
  40af92:	vmovdqu XMMWORD PTR [rsp+0xa8],xmm13
  40af9b:	vmovdqu XMMWORD PTR [rsp+0xc0],xmm7
  40afa4:	vmovdqu XMMWORD PTR [rsp+0xe0],xmm11
  40afad:	vmovdqu XMMWORD PTR [rsp+0xf8],xmm3
  40afb6:	vmovups xmm3,XMMWORD PTR [rsp+0x300]
  40afbf:	vmovdqu XMMWORD PTR [rsp],xmm3
  40afc4:	vmovups xmm4,XMMWORD PTR [rsp+0x310]
  40afcd:	vmovdqu XMMWORD PTR [rsp+0x18],xmm4
  40afd3:	vmovups xmm13,XMMWORD PTR [rsp+0x320]
  40afdc:	vmovdqu XMMWORD PTR [rsp+0x38],xmm13
  40afe2:	vmovups xmm7,XMMWORD PTR [rsp+0x330]
  40afeb:	vmovdqu XMMWORD PTR [rsp+0x50],xmm7
  40aff1:	vmovdqu XMMWORD PTR [rsp+0x70],xmm8
  40aff7:	vmovdqu XMMWORD PTR [rsp+0x88],xmm9
  40b000:	mov    QWORD PTR [rbx+0x258],0x5
  40b00b:	vxorpd xmm0,xmm0,xmm0
  40b00f:	vmovsd xmm1,QWORD PTR [rip+0x8353]        # 41336a <__swc_rdata_base_6b1cf01f+0x25a>
  40b017:	vmovsd xmm3,QWORD PTR [rbx+0x30]
  40b01c:	vmulsd xmm2,xmm1,xmm3
  40b020:	vmovsd xmm4,QWORD PTR [rbx+0x18]
  40b025:	vmulsd xmm4,xmm4,xmm4
  40b029:	vmovsd xmm5,QWORD PTR [rbx+0x20]
  40b02e:	vfmadd231sd xmm4,xmm5,xmm5
  40b033:	vmovsd xmm5,QWORD PTR [rbx+0x28]
  40b038:	vfmadd231sd xmm4,xmm5,xmm5
  40b03d:	vfmadd231sd xmm0,xmm2,xmm4
  40b042:	vmovsd xmm2,QWORD PTR [rbx]
  40b046:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x38]
  40b04b:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  40b050:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x40]
  40b055:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  40b05a:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x48]
  40b05f:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x68]
  40b064:	vmulsd xmm2,xmm2,xmm2
  40b068:	vfmadd231sd xmm2,xmm4,xmm4
  40b06d:	vfmadd231sd xmm2,xmm5,xmm5
  40b072:	vsqrtsd xmm2,xmm2,xmm2
  40b076:	vdivsd xmm2,xmm9,xmm2
  40b07a:	vsubsd xmm0,xmm0,xmm2
  40b07e:	vmovsd xmm2,QWORD PTR [rbx]
  40b082:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x70]
  40b087:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  40b08c:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x78]
  40b091:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  40b096:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x80]
  40b09e:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xa0]
  40b0a6:	vmulsd xmm2,xmm2,xmm2
  40b0aa:	vfmadd231sd xmm2,xmm4,xmm4
  40b0af:	vfmadd231sd xmm2,xmm5,xmm5
  40b0b4:	vsqrtsd xmm2,xmm2,xmm2
  40b0b8:	vdivsd xmm2,xmm9,xmm2
  40b0bc:	vsubsd xmm0,xmm0,xmm2
  40b0c0:	vmovsd xmm2,QWORD PTR [rbx]
  40b0c4:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  40b0cc:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  40b0d1:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  40b0d9:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  40b0de:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  40b0e6:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  40b0ee:	vmulsd xmm2,xmm2,xmm2
  40b0f2:	vfmadd231sd xmm2,xmm4,xmm4
  40b0f7:	vfmadd231sd xmm2,xmm5,xmm5
  40b0fc:	vsqrtsd xmm2,xmm2,xmm2
  40b100:	vdivsd xmm2,xmm9,xmm2
  40b104:	vsubsd xmm0,xmm0,xmm2
  40b108:	vmovsd xmm2,QWORD PTR [rbx]
  40b10c:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xe0]
  40b114:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  40b119:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xe8]
  40b121:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  40b126:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xf0]
  40b12e:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x110]
  40b136:	vmulsd xmm2,xmm2,xmm2
  40b13a:	vfmadd231sd xmm2,xmm4,xmm4
  40b13f:	vfmadd231sd xmm2,xmm5,xmm5
  40b144:	vsqrtsd xmm2,xmm2,xmm2
  40b148:	vdivsd xmm2,xmm9,xmm2
  40b14c:	vsubsd xmm0,xmm0,xmm2
  40b150:	vmovsd xmm3,QWORD PTR [rbx+0x68]
  40b155:	vmulsd xmm2,xmm1,xmm3
  40b159:	vmovsd xmm4,QWORD PTR [rbx+0x50]
  40b15e:	vmulsd xmm4,xmm4,xmm4
  40b162:	vmovsd xmm5,QWORD PTR [rbx+0x58]
  40b167:	vfmadd231sd xmm4,xmm5,xmm5
  40b16c:	vmovsd xmm5,QWORD PTR [rbx+0x60]
  40b171:	vfmadd231sd xmm4,xmm5,xmm5
  40b176:	vfmadd231sd xmm0,xmm2,xmm4
  40b17b:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  40b180:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x70]
  40b185:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  40b18a:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x78]
  40b18f:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  40b194:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x80]
  40b19c:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xa0]
  40b1a4:	vmulsd xmm2,xmm2,xmm2
  40b1a8:	vfmadd231sd xmm2,xmm4,xmm4
  40b1ad:	vfmadd231sd xmm2,xmm5,xmm5
  40b1b2:	vsqrtsd xmm2,xmm2,xmm2
  40b1b6:	vdivsd xmm2,xmm9,xmm2
  40b1ba:	vsubsd xmm0,xmm0,xmm2
  40b1be:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  40b1c3:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  40b1cb:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  40b1d0:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  40b1d8:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  40b1dd:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  40b1e5:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  40b1ed:	vmulsd xmm2,xmm2,xmm2
  40b1f1:	vfmadd231sd xmm2,xmm4,xmm4
  40b1f6:	vfmadd231sd xmm2,xmm5,xmm5
  40b1fb:	vsqrtsd xmm2,xmm2,xmm2
  40b1ff:	vdivsd xmm2,xmm9,xmm2
  40b203:	vsubsd xmm0,xmm0,xmm2
  40b207:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  40b20c:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xe0]
  40b214:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  40b219:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xe8]
  40b221:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  40b226:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xf0]
  40b22e:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x110]
  40b236:	vmulsd xmm2,xmm2,xmm2
  40b23a:	vfmadd231sd xmm2,xmm4,xmm4
  40b23f:	vfmadd231sd xmm2,xmm5,xmm5
  40b244:	vsqrtsd xmm2,xmm2,xmm2
  40b248:	vdivsd xmm2,xmm9,xmm2
  40b24c:	vsubsd xmm0,xmm0,xmm2
  40b250:	vmovsd xmm3,QWORD PTR [rbx+0xa0]
  40b258:	vmulsd xmm2,xmm1,xmm3
  40b25c:	vmovsd xmm4,QWORD PTR [rbx+0x88]
  40b264:	vmulsd xmm4,xmm4,xmm4
  40b268:	vmovsd xmm5,QWORD PTR [rbx+0x90]
  40b270:	vfmadd231sd xmm4,xmm5,xmm5
  40b275:	vmovsd xmm5,QWORD PTR [rbx+0x98]
  40b27d:	vfmadd231sd xmm4,xmm5,xmm5
  40b282:	vfmadd231sd xmm0,xmm2,xmm4
  40b287:	vmovsd xmm2,QWORD PTR [rbx+0x70]
  40b28c:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  40b294:	vmovsd xmm4,QWORD PTR [rbx+0x78]
  40b299:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  40b2a1:	vmovsd xmm5,QWORD PTR [rbx+0x80]
  40b2a9:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  40b2b1:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  40b2b9:	vmulsd xmm2,xmm2,xmm2
  40b2bd:	vfmadd231sd xmm2,xmm4,xmm4
  40b2c2:	vfmadd231sd xmm2,xmm5,xmm5
  40b2c7:	vsqrtsd xmm2,xmm2,xmm2
  40b2cb:	vdivsd xmm2,xmm9,xmm2
  40b2cf:	vsubsd xmm0,xmm0,xmm2
  40b2d3:	vmovsd xmm2,QWORD PTR [rbx+0x70]
  40b2d8:	vmovsd xmm6,QWORD PTR [rbx+0xe0]
  40b2e0:	vsubsd xmm2,xmm2,xmm6
  40b2e4:	vmovsd xmm4,QWORD PTR [rbx+0x78]
  40b2e9:	vmovsd xmm7,QWORD PTR [rbx+0xe8]
  40b2f1:	vsubsd xmm4,xmm4,xmm7
  40b2f5:	vmovsd xmm5,QWORD PTR [rbx+0x80]
  40b2fd:	vmovsd xmm8,QWORD PTR [rbx+0xf0]
  40b305:	vsubsd xmm5,xmm5,xmm8
  40b30a:	vmovsd xmm10,QWORD PTR [rbx+0x110]
  40b312:	vmulsd xmm9,xmm3,xmm10
  40b317:	vmulsd xmm2,xmm2,xmm2
  40b31b:	vfmadd231sd xmm2,xmm4,xmm4
  40b320:	vfmadd231sd xmm2,xmm5,xmm5
  40b325:	vsqrtsd xmm2,xmm2,xmm2
  40b329:	vdivsd xmm2,xmm9,xmm2
  40b32d:	vsubsd xmm0,xmm0,xmm2
  40b331:	vmovsd xmm3,QWORD PTR [rbx+0xd8]
  40b339:	vmulsd xmm2,xmm1,xmm3
  40b33d:	vmovsd xmm4,QWORD PTR [rbx+0xc0]
  40b345:	vmulsd xmm4,xmm4,xmm4
  40b349:	vmovsd xmm5,QWORD PTR [rbx+0xc8]
  40b351:	vfmadd231sd xmm4,xmm5,xmm5
  40b356:	vmovsd xmm5,QWORD PTR [rbx+0xd0]
  40b35e:	vfmadd231sd xmm4,xmm5,xmm5
  40b363:	vfmadd231sd xmm0,xmm2,xmm4
  40b368:	vmovsd xmm2,QWORD PTR [rbx+0xa8]
  40b370:	vsubsd xmm2,xmm2,xmm6
  40b374:	vmovsd xmm4,QWORD PTR [rbx+0xb0]
  40b37c:	vsubsd xmm4,xmm4,xmm7
  40b380:	vmovsd xmm5,QWORD PTR [rbx+0xb8]
  40b388:	vsubsd xmm5,xmm5,xmm8
  40b38d:	vmulsd xmm9,xmm3,xmm10
  40b392:	vmulsd xmm2,xmm2,xmm2
  40b396:	vfmadd231sd xmm2,xmm4,xmm4
  40b39b:	vfmadd231sd xmm2,xmm5,xmm5
  40b3a0:	vsqrtsd xmm2,xmm2,xmm2
  40b3a4:	vdivsd xmm2,xmm9,xmm2
  40b3a8:	vsubsd xmm0,xmm0,xmm2
  40b3ac:	vmulsd xmm2,xmm10,xmm1
  40b3b0:	vmovsd xmm4,QWORD PTR [rbx+0xf8]
  40b3b8:	vmulsd xmm4,xmm4,xmm4
  40b3bc:	vmovsd xmm5,QWORD PTR [rbx+0x100]
  40b3c4:	vfmadd231sd xmm4,xmm5,xmm5
  40b3c9:	vmovsd xmm5,QWORD PTR [rbx+0x108]
  40b3d1:	vfmadd231sd xmm4,xmm5,xmm5
  40b3d6:	vfmadd231sd xmm0,xmm2,xmm4
  40b3db:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x7e5d]        # 413240 <__swc_rdata_base_6b1cf01f+0x130>
  40b3e3:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x7f88]        # 413373 <__swc_rdata_base_6b1cf01f+0x263>
  40b3eb:	vroundsd xmm0,xmm0,xmm0,0x1
  40b3f1:	vmovsd xmm1,QWORD PTR [rip+0x7f83]        # 41337c <__swc_rdata_base_6b1cf01f+0x26c>
  40b3f9:	vcomisd xmm0,xmm1
  40b3fd:	jb     40b417 <__swc_fn_6b1cf01f_000001_0ce64436+0xeb7>
  40b3ff:	vsubsd xmm0,xmm0,xmm1
  40b403:	vcvttsd2si rsi,xmm0
  40b408:	movabs rax,0x8000000000000000
  40b412:	xor    rsi,rax
  40b415:	jmp    40b41c <__swc_fn_6b1cf01f_000001_0ce64436+0xebc>
  40b417:	vcvttsd2si rsi,xmm0
  40b41c:	sub    rsp,0x8
  40b420:	call   407270 <__swc_fn_6b1cf01f_000000_1ca87929>
  40b425:	add    rsp,0x8
  40b429:	vsubsd xmm0,xmm0,QWORD PTR [rsp+0x2d0]
  40b432:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x7f4b]        # 413385 <__swc_rdata_base_6b1cf01f+0x275>
  40b43a:	lea    rax,[rip+0x7e0f]        # 413250 <__swc_rdata_base_6b1cf01f+0x140>
  40b441:	sub    rsp,0x90
  40b448:	mov    rcx,rsp
  40b44b:	vmovups xmm1,XMMWORD PTR [rip+0x7ee5]        # 413338 <__swc_rdata_base_6b1cf01f+0x228>
  40b453:	vmovups XMMWORD PTR [rcx],xmm1
  40b457:	mov    QWORD PTR [rcx+0x30],rsp
  40b45b:	lea    rdx,[rip+0x7dfe]        # 413260 <__swc_rdata_base_6b1cf01f+0x150>
  40b462:	mov    QWORD PTR [rcx+0x38],rdx
  40b466:	mov    QWORD PTR [rcx+0x10],rsi
  40b46a:	lea    r8,[rsp+0x10]
  40b46f:	mov    QWORD PTR [rcx+0x40],r8
  40b473:	lea    r8,[rip+0x7e2e]        # 4132a8 <__swc_rdata_base_6b1cf01f+0x198>
  40b47a:	mov    QWORD PTR [rcx+0x48],r8
  40b47e:	vmovups xmm1,XMMWORD PTR [rip+0x7ec2]        # 413348 <__swc_rdata_base_6b1cf01f+0x238>
  40b486:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40b48b:	lea    r8,[rsp+0x18]
  40b490:	mov    QWORD PTR [rcx+0x50],r8
  40b494:	mov    QWORD PTR [rcx+0x58],rdx
  40b498:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40b49d:	lea    r8,[rcx+0x28]
  40b4a1:	mov    QWORD PTR [rcx+0x60],r8
  40b4a5:	lea    r8,[rip+0x7e44]        # 4132f0 <__swc_rdata_base_6b1cf01f+0x1e0>
  40b4ac:	mov    QWORD PTR [rcx+0x68],r8
  40b4b0:	mov    QWORD PTR [rcx+0x70],rax
  40b4b4:	mov    QWORD PTR [rcx+0x78],rdx
  40b4b8:	lea    rax,[rcx+0x30]
  40b4bc:	mov    QWORD PTR [rcx+0x80],rax
  40b4c3:	mov    QWORD PTR [rcx+0x88],0x5
  40b4ce:	lea    rcx,[rcx+0x80]
  40b4d5:	sub    rsp,0x8
  40b4d9:	call   40e040 <__swc_fn_6b1cf01f_000148_6203dca2>
  40b4de:	add    rsp,0x5a8
  40b4e5:	vmovups xmm6,XMMWORD PTR [rsp]
  40b4ea:	vmovups xmm7,XMMWORD PTR [rsp+0x10]
  40b4f0:	vmovups xmm8,XMMWORD PTR [rsp+0x20]
  40b4f6:	vmovups xmm9,XMMWORD PTR [rsp+0x30]
  40b4fc:	vmovups xmm10,XMMWORD PTR [rsp+0x40]
  40b502:	vmovups xmm11,XMMWORD PTR [rsp+0x50]
  40b508:	vmovups xmm12,XMMWORD PTR [rsp+0x60]
  40b50e:	vmovups xmm13,XMMWORD PTR [rsp+0x70]
  40b514:	vmovups xmm14,XMMWORD PTR [rsp+0x80]
  40b51d:	vmovups xmm15,XMMWORD PTR [rsp+0x90]
  40b526:	add    rsp,0xa8
  40b52d:	pop    rsi
  40b52e:	pop    rbx
  40b52f:	pop    rbp
  40b530:	ret
