
/workspace/prompt2-20261115/batch5-final-micro/new/chacha/chacha:     file format elf64-x86-64


Disassembly of section .text:

000000000040fa30 <__swc_fn_3464c816_000110_6814119b>:
  40fa30:	push   rbx
  40fa31:	push   r12
  40fa33:	push   rdi
  40fa34:	push   rsi
  40fa35:	push   r13
  40fa37:	push   r14
  40fa39:	push   r15
  40fa3b:	sub    rsp,0x170
  40fa42:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40fa4b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40fa54:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40fa5d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40fa66:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40fa6f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40fa78:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40fa81:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40fa8a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40fa93:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40fa9c:	mov    ebx,edx
  40fa9e:	mov    QWORD PTR [rsp+0xa8],rbx
  40faa6:	mov    r12d,ecx
  40faa9:	test   edx,edx
  40faab:	jne    40fac2 <__swc_fn_3464c816_000110_6814119b+0x92>
  40faad:	xor    eax,eax
  40faaf:	add    rsp,0x170
  40fab6:	pop    r15
  40fab8:	pop    r14
  40faba:	pop    r13
  40fabc:	pop    rsi
  40fabd:	pop    rdi
  40fabe:	pop    r12
  40fac0:	pop    rbx
  40fac1:	ret
  40fac2:	lea    rdi,[rip+0x3ae7]        # 4135b0 <__swc_rdata_base_3464c816+0x4a0>
  40fac9:	mov    esi,0x90000
  40face:	xor    eax,eax
  40fad0:	call   407090 <open@plt>
  40fad5:	mov    r13,rax
  40fad8:	mov    QWORD PTR [rsp+0xb0],rax
  40fae0:	test   eax,eax
  40fae2:	jge    40faeb <__swc_fn_3464c816_000110_6814119b+0xbb>
  40fae4:	xor    eax,eax
  40fae6:	jmp    40ffe6 <__swc_fn_3464c816_000110_6814119b+0x5b6>
  40faeb:	nop    DWORD PTR [rax+rax*1+0x0]
  40faf0:	movsxd rdi,r13d
  40faf3:	mov    esi,0x2
  40faf8:	xor    eax,eax
  40fafa:	call   407120 <flock@plt>
  40faff:	test   eax,eax
  40fb01:	je     40fb20 <__swc_fn_3464c816_000110_6814119b+0xf0>
  40fb03:	xor    eax,eax
  40fb05:	call   407130 <__errno_location@plt>
  40fb0a:	cmp    DWORD PTR [rax],0x4
  40fb0d:	je     40faf0 <__swc_fn_3464c816_000110_6814119b+0xc0>
  40fb0f:	movsxd rdi,r13d
  40fb12:	xor    eax,eax
  40fb14:	call   4070b0 <close@plt>
  40fb19:	xor    eax,eax
  40fb1b:	jmp    40ffe6 <__swc_fn_3464c816_000110_6814119b+0x5b6>
  40fb20:	lea    r14,[rsp+0x8]
  40fb25:	mov    QWORD PTR [rsp+0xb8],r14
  40fb2d:	vxorps xmm0,xmm0,xmm0
  40fb31:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40fb37:	mov    QWORD PTR [rsp+0x18],0x0
  40fb40:	mov    WORD PTR [rsp+0x20],0x0
  40fb47:	mov    DWORD PTR [r14],0x67617753
  40fb4e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40fb56:	xor    eax,eax
  40fb58:	call   407010 <getpid@plt>
  40fb5d:	mov    ecx,eax
  40fb5f:	mov    eax,0x1c
  40fb64:	shrx   eax,ecx,eax
  40fb69:	and    eax,0xf
  40fb6c:	mov    rdx,QWORD PTR [rip+0x3a5d]        # 4135d0 <__swc_rdata_base_3464c816+0x4c0>
  40fb73:	mov    al,BYTE PTR [rdx+rax*1]
  40fb76:	rex mov BYTE PTR [rsp+0x10],al
  40fb7b:	mov    eax,0x1c
  40fb80:	shrx   eax,r12d,eax
  40fb85:	and    eax,0xf
  40fb88:	mov    al,BYTE PTR [rdx+rax*1]
  40fb8b:	rex mov BYTE PTR [rsp+0x19],al
  40fb90:	mov    eax,0x18
  40fb95:	shrx   eax,ecx,eax
  40fb9a:	and    eax,0xf
  40fb9d:	mov    al,BYTE PTR [rdx+rax*1]
  40fba0:	rex mov BYTE PTR [rsp+0x11],al
  40fba5:	mov    eax,0x18
  40fbaa:	shrx   eax,r12d,eax
  40fbaf:	and    eax,0xf
  40fbb2:	mov    al,BYTE PTR [rdx+rax*1]
  40fbb5:	rex mov BYTE PTR [rsp+0x1a],al
  40fbba:	mov    eax,0x14
  40fbbf:	shrx   eax,ecx,eax
  40fbc4:	and    eax,0xf
  40fbc7:	mov    al,BYTE PTR [rdx+rax*1]
  40fbca:	rex mov BYTE PTR [rsp+0x12],al
  40fbcf:	mov    eax,0x14
  40fbd4:	shrx   eax,r12d,eax
  40fbd9:	and    eax,0xf
  40fbdc:	mov    al,BYTE PTR [rdx+rax*1]
  40fbdf:	rex mov BYTE PTR [rsp+0x1b],al
  40fbe4:	mov    eax,0x10
  40fbe9:	shrx   eax,ecx,eax
  40fbee:	and    eax,0xf
  40fbf1:	mov    al,BYTE PTR [rdx+rax*1]
  40fbf4:	rex mov BYTE PTR [rsp+0x13],al
  40fbf9:	mov    eax,0x10
  40fbfe:	shrx   eax,r12d,eax
  40fc03:	and    eax,0xf
  40fc06:	mov    al,BYTE PTR [rdx+rax*1]
  40fc09:	rex mov BYTE PTR [rsp+0x1c],al
  40fc0e:	mov    eax,0xc
  40fc13:	shrx   eax,ecx,eax
  40fc18:	and    eax,0xf
  40fc1b:	mov    al,BYTE PTR [rdx+rax*1]
  40fc1e:	rex mov BYTE PTR [rsp+0x14],al
  40fc23:	mov    eax,0xc
  40fc28:	shrx   eax,r12d,eax
  40fc2d:	and    eax,0xf
  40fc30:	mov    al,BYTE PTR [rdx+rax*1]
  40fc33:	rex mov BYTE PTR [rsp+0x1d],al
  40fc38:	mov    eax,0x8
  40fc3d:	shrx   eax,ecx,eax
  40fc42:	and    eax,0xf
  40fc45:	mov    al,BYTE PTR [rdx+rax*1]
  40fc48:	rex mov BYTE PTR [rsp+0x15],al
  40fc4d:	mov    eax,0x8
  40fc52:	shrx   eax,r12d,eax
  40fc57:	and    eax,0xf
  40fc5a:	mov    al,BYTE PTR [rdx+rax*1]
  40fc5d:	rex mov BYTE PTR [rsp+0x1e],al
  40fc62:	mov    eax,0x4
  40fc67:	shrx   eax,ecx,eax
  40fc6c:	and    eax,0xf
  40fc6f:	mov    al,BYTE PTR [rdx+rax*1]
  40fc72:	rex mov BYTE PTR [rsp+0x16],al
  40fc77:	mov    eax,0x4
  40fc7c:	shrx   eax,r12d,eax
  40fc81:	and    eax,0xf
  40fc84:	mov    al,BYTE PTR [rdx+rax*1]
  40fc87:	rex mov BYTE PTR [rsp+0x1f],al
  40fc8c:	xor    eax,eax
  40fc8e:	shrx   eax,ecx,eax
  40fc93:	and    eax,0xf
  40fc96:	mov    al,BYTE PTR [rdx+rax*1]
  40fc99:	rex mov BYTE PTR [rsp+0x17],al
  40fc9e:	xor    eax,eax
  40fca0:	shrx   eax,r12d,eax
  40fca5:	and    eax,0xf
  40fca8:	mov    al,BYTE PTR [rdx+rax*1]
  40fcab:	rex mov BYTE PTR [rsp+0x20],al
  40fcb0:	mov    BYTE PTR [r14+0x10],0x2e
  40fcb5:	lea    r12,[rsp+0x22]
  40fcba:	vxorps xmm0,xmm0,xmm0
  40fcbe:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40fcc4:	mov    DWORD PTR [r12],0x6d656d2f
  40fccc:	mov    WORD PTR [r12+0x4],0x6466
  40fcd4:	mov    BYTE PTR [r12+0x6],0x3a
  40fcda:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40fce0:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40fce6:	mov    rax,QWORD PTR [rsp+0x18]
  40fceb:	mov    QWORD PTR [rsp+0x39],rax
  40fcf0:	rex mov al,BYTE PTR [rsp+0x20]
  40fcf5:	rex mov BYTE PTR [rsp+0x41],al
  40fcfa:	mov    DWORD PTR [r12+0x20],0x65642820
  40fd03:	mov    DWORD PTR [r12+0x24],0x6574656c
  40fd0c:	mov    WORD PTR [r12+0x28],0x2964
  40fd14:	lea    rdi,[rip+0x38a0]        # 4135bb <__swc_rdata_base_3464c816+0x4ab>
  40fd1b:	xor    eax,eax
  40fd1d:	call   407140 <opendir@plt>
  40fd22:	mov    r15,rax
  40fd25:	test   rax,rax
  40fd28:	jne    40fd3b <__swc_fn_3464c816_000110_6814119b+0x30b>
  40fd2a:	movsxd rdi,r13d
  40fd2d:	xor    eax,eax
  40fd2f:	call   4070b0 <close@plt>
  40fd34:	xor    eax,eax
  40fd36:	jmp    40ffe6 <__swc_fn_3464c816_000110_6814119b+0x5b6>
  40fd3b:	mov    rdi,r15
  40fd3e:	xor    eax,eax
  40fd40:	call   407150 <dirfd@plt>
  40fd45:	lea    r14,[rsp+0x54]
  40fd4a:	mov    DWORD PTR [rsp+0x54],eax
  40fd4e:	lea    rbx,[rsp+0x58]
  40fd53:	cs nop WORD PTR [rax+rax*1+0x0]
  40fd5d:	nop    DWORD PTR [rax]
  40fd60:	mov    rdi,r15
  40fd63:	xor    eax,eax
  40fd65:	call   407160 <readdir@plt>
  40fd6a:	test   rax,rax
  40fd6d:	jne    40fd84 <__swc_fn_3464c816_000110_6814119b+0x354>
  40fd6f:	mov    r12,QWORD PTR [rsp+0xa8]
  40fd77:	mov    r13,QWORD PTR [rsp+0xb0]
  40fd7f:	jmp    40ff0a <__swc_fn_3464c816_000110_6814119b+0x4da>
  40fd84:	vxorps xmm0,xmm0,xmm0
  40fd88:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  40fd8e:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  40fd94:	vzeroupper
  40fd97:	lea    r13,[rax+0x13]
  40fd9b:	mov    rax,r14
  40fd9e:	movsxd rdi,DWORD PTR [rax]
  40fda1:	mov    rsi,r13
  40fda4:	mov    rdx,rbx
  40fda7:	mov    ecx,0x40
  40fdac:	xor    eax,eax
  40fdae:	call   407170 <readlinkat@plt>
  40fdb3:	cmp    rax,0x2a
  40fdb7:	jne    40fd60 <__swc_fn_3464c816_000110_6814119b+0x330>
  40fdb9:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40fdbf:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40fdc5:	vptest xmm0,xmm0
  40fdca:	jne    40fdfa <__swc_fn_3464c816_000110_6814119b+0x3ca>
  40fdcc:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40fdd2:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40fdd8:	vptest xmm0,xmm0
  40fddd:	jne    40fdfa <__swc_fn_3464c816_000110_6814119b+0x3ca>
  40fddf:	mov    rcx,QWORD PTR [rsp+0x42]
  40fde4:	cmp    QWORD PTR [rsp+0x78],rcx
  40fde9:	jne    40fdfa <__swc_fn_3464c816_000110_6814119b+0x3ca>
  40fdeb:	mov    cx,WORD PTR [rsp+0x4a]
  40fdf0:	cmp    WORD PTR [rsp+0x80],cx
  40fdf8:	je     40fe24 <__swc_fn_3464c816_000110_6814119b+0x3f4>
  40fdfa:	mov    rax,rbx
  40fdfd:	mov    rcx,r12
  40fe00:	movzx  edx,BYTE PTR [rax]
  40fe03:	movzx  r8d,BYTE PTR [rcx]
  40fe07:	cmp    rdx,r8
  40fe0a:	jne    40fe16 <__swc_fn_3464c816_000110_6814119b+0x3e6>
  40fe0c:	add    rax,0x1
  40fe10:	add    rcx,0x1
  40fe14:	jmp    40fe00 <__swc_fn_3464c816_000110_6814119b+0x3d0>
  40fe16:	mov    rax,rdx
  40fe19:	sub    rax,r8
  40fe1c:	test   eax,eax
  40fe1e:	jne    40fd60 <__swc_fn_3464c816_000110_6814119b+0x330>
  40fe24:	movsxd rdi,DWORD PTR [r14]
  40fe27:	mov    rsi,r13
  40fe2a:	mov    edx,0x80002
  40fe2f:	xor    eax,eax
  40fe31:	call   407180 <openat@plt>
  40fe36:	lea    rbx,[rsp+0x98]
  40fe3e:	mov    DWORD PTR [rsp+0x98],eax
  40fe45:	test   eax,eax
  40fe47:	mov    r13,QWORD PTR [rsp+0xb0]
  40fe4f:	jge    40fe74 <__swc_fn_3464c816_000110_6814119b+0x444>
  40fe51:	mov    rdi,r15
  40fe54:	xor    eax,eax
  40fe56:	call   407190 <closedir@plt>
  40fe5b:	mov    r13,QWORD PTR [rsp+0xb0]
  40fe63:	movsxd rdi,r13d
  40fe66:	xor    eax,eax
  40fe68:	call   4070b0 <close@plt>
  40fe6d:	xor    eax,eax
  40fe6f:	jmp    40ffe6 <__swc_fn_3464c816_000110_6814119b+0x5b6>
  40fe74:	mov    rax,rbx
  40fe77:	movsxd rdi,DWORD PTR [rax]
  40fe7a:	xor    esi,esi
  40fe7c:	mov    edx,0x2
  40fe81:	xor    eax,eax
  40fe83:	call   4070a0 <lseek@plt>
  40fe88:	mov    r12,QWORD PTR [rsp+0xa8]
  40fe90:	cmp    rax,r12
  40fe93:	je     40feba <__swc_fn_3464c816_000110_6814119b+0x48a>
  40fe95:	movsxd rdi,DWORD PTR [rbx]
  40fe98:	xor    eax,eax
  40fe9a:	call   4070b0 <close@plt>
  40fe9f:	mov    rdi,r15
  40fea2:	xor    eax,eax
  40fea4:	call   407190 <closedir@plt>
  40fea9:	movsxd rdi,r13d
  40feac:	xor    eax,eax
  40feae:	call   4070b0 <close@plt>
  40feb3:	xor    eax,eax
  40feb5:	jmp    40ffe6 <__swc_fn_3464c816_000110_6814119b+0x5b6>
  40feba:	xor    edi,edi
  40febc:	mov    rsi,r12
  40febf:	mov    edx,0x3
  40fec4:	mov    ecx,0x1
  40fec9:	mov    rax,rbx
  40fecc:	movsxd r8,DWORD PTR [rax]
  40fecf:	xor    r9d,r9d
  40fed2:	xor    eax,eax
  40fed4:	call   4070c0 <mmap@plt>
  40fed9:	xor    r12d,r12d
  40fedc:	cmp    rax,0xffffffffffffffff
  40fee0:	cmovne r12,rax
  40fee4:	movsxd rdi,DWORD PTR [rbx]
  40fee7:	xor    eax,eax
  40fee9:	call   4070b0 <close@plt>
  40feee:	mov    rdi,r15
  40fef1:	xor    eax,eax
  40fef3:	call   407190 <closedir@plt>
  40fef8:	movsxd rdi,r13d
  40fefb:	xor    eax,eax
  40fefd:	call   4070b0 <close@plt>
  40ff02:	mov    rax,r12
  40ff05:	jmp    40ffe6 <__swc_fn_3464c816_000110_6814119b+0x5b6>
  40ff0a:	mov    r14,QWORD PTR [rsp+0xb8]
  40ff12:	mov    rdi,r14
  40ff15:	mov    esi,0x1
  40ff1a:	xor    eax,eax
  40ff1c:	call   4071a0 <memfd_create@plt>
  40ff21:	lea    rbx,[rsp+0x9c]
  40ff29:	mov    DWORD PTR [rsp+0x9c],eax
  40ff30:	test   eax,eax
  40ff32:	jge    40ff4f <__swc_fn_3464c816_000110_6814119b+0x51f>
  40ff34:	mov    rdi,r15
  40ff37:	xor    eax,eax
  40ff39:	call   407190 <closedir@plt>
  40ff3e:	movsxd rdi,r13d
  40ff41:	xor    eax,eax
  40ff43:	call   4070b0 <close@plt>
  40ff48:	xor    eax,eax
  40ff4a:	jmp    40ffe6 <__swc_fn_3464c816_000110_6814119b+0x5b6>
  40ff4f:	mov    rax,rbx
  40ff52:	movsxd rdi,DWORD PTR [rax]
  40ff55:	mov    rsi,r12
  40ff58:	xor    eax,eax
  40ff5a:	call   4071b0 <ftruncate@plt>
  40ff5f:	test   eax,eax
  40ff61:	je     40ff85 <__swc_fn_3464c816_000110_6814119b+0x555>
  40ff63:	movsxd rdi,DWORD PTR [rbx]
  40ff66:	xor    eax,eax
  40ff68:	call   4070b0 <close@plt>
  40ff6d:	mov    rdi,r15
  40ff70:	xor    eax,eax
  40ff72:	call   407190 <closedir@plt>
  40ff77:	movsxd rdi,r13d
  40ff7a:	xor    eax,eax
  40ff7c:	call   4070b0 <close@plt>
  40ff81:	xor    eax,eax
  40ff83:	jmp    40ffe6 <__swc_fn_3464c816_000110_6814119b+0x5b6>
  40ff85:	xor    edi,edi
  40ff87:	mov    rsi,r12
  40ff8a:	mov    edx,0x3
  40ff8f:	mov    ecx,0x1
  40ff94:	mov    rax,rbx
  40ff97:	movsxd r8,DWORD PTR [rax]
  40ff9a:	xor    r9d,r9d
  40ff9d:	xor    eax,eax
  40ff9f:	call   4070c0 <mmap@plt>
  40ffa4:	mov    r12,rax
  40ffa7:	cmp    rax,0xffffffffffffffff
  40ffab:	jne    40ffcf <__swc_fn_3464c816_000110_6814119b+0x59f>
  40ffad:	movsxd rdi,DWORD PTR [rbx]
  40ffb0:	xor    eax,eax
  40ffb2:	call   4070b0 <close@plt>
  40ffb7:	mov    rdi,r15
  40ffba:	xor    eax,eax
  40ffbc:	call   407190 <closedir@plt>
  40ffc1:	movsxd rdi,r13d
  40ffc4:	xor    eax,eax
  40ffc6:	call   4070b0 <close@plt>
  40ffcb:	xor    eax,eax
  40ffcd:	jmp    40ffe6 <__swc_fn_3464c816_000110_6814119b+0x5b6>
  40ffcf:	mov    rdi,r15
  40ffd2:	xor    eax,eax
  40ffd4:	call   407190 <closedir@plt>
  40ffd9:	movsxd rdi,r13d
  40ffdc:	xor    eax,eax
  40ffde:	call   4070b0 <close@plt>
  40ffe3:	mov    rax,r12
  40ffe6:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40ffef:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40fff8:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  410001:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  41000a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  410013:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  41001c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  410025:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  41002e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  410037:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  410040:	add    rsp,0x170
  410047:	pop    r15
  410049:	pop    r14
  41004b:	pop    r13
  41004d:	pop    rsi
  41004e:	pop    rdi
  41004f:	pop    r12
  410051:	pop    rbx
  410052:	ret
