
/workspace/prompt2-20261115/batch9-audited-micro/base/sort/sort:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xb002]        # 412008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <getpid@plt>:
  407010:	jmp    QWORD PTR [rip+0xaffa]        # 412010 <getpid@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <munmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xaff2]        # 412018 <munmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xafea]        # 412020 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <exit@plt>:
  407040:	jmp    QWORD PTR [rip+0xafe2]        # 412028 <exit@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <pthread_key_create@plt>:
  407050:	jmp    QWORD PTR [rip+0xafda]        # 412030 <pthread_key_create@GLIBC_2.34>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_setspecific@plt>:
  407060:	jmp    QWORD PTR [rip+0xafd2]        # 412038 <pthread_setspecific@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <syscall@plt>:
  407070:	jmp    QWORD PTR [rip+0xafca]        # 412040 <syscall@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dladdr@plt>:
  407080:	jmp    QWORD PTR [rip+0xafc2]        # 412048 <dladdr@GLIBC_2.34>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <open@plt>:
  407090:	jmp    QWORD PTR [rip+0xafba]        # 412050 <open@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <lseek@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xafb2]        # 412058 <lseek@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <close@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xafaa]        # 412060 <close@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <mmap@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xafa2]        # 412068 <mmap@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <malloc@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xaf9a]        # 412070 <malloc@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <clock_gettime@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xaf92]        # 412078 <clock_gettime@GLIBC_2.17>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <madvise@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xaf92]        # 412088 <madvise@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <pthread_key_delete@plt>:
  407100:	jmp    QWORD PTR [rip+0xaf8a]        # 412090 <pthread_key_delete@GLIBC_2.34>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <gettid@plt>:
  407110:	jmp    QWORD PTR [rip+0xaf82]        # 412098 <gettid@GLIBC_2.30>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <flock@plt>:
  407120:	jmp    QWORD PTR [rip+0xaf7a]        # 4120a0 <flock@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <__errno_location@plt>:
  407130:	jmp    QWORD PTR [rip+0xaf72]        # 4120a8 <__errno_location@GLIBC_2.2.5>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <opendir@plt>:
  407140:	jmp    QWORD PTR [rip+0xaf6a]        # 4120b0 <opendir@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <dirfd@plt>:
  407150:	jmp    QWORD PTR [rip+0xaf62]        # 4120b8 <dirfd@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <readdir@plt>:
  407160:	jmp    QWORD PTR [rip+0xaf5a]        # 4120c0 <readdir@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <readlinkat@plt>:
  407170:	jmp    QWORD PTR [rip+0xaf52]        # 4120c8 <readlinkat@GLIBC_2.4>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <openat@plt>:
  407180:	jmp    QWORD PTR [rip+0xaf4a]        # 4120d0 <openat@GLIBC_2.4>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <closedir@plt>:
  407190:	jmp    QWORD PTR [rip+0xaf42]        # 4120d8 <closedir@GLIBC_2.2.5>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <memfd_create@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xaf3a]        # 4120e0 <memfd_create@GLIBC_2.27>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <ftruncate@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xaf32]        # 4120e8 <ftruncate@GLIBC_2.2.5>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <write@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xaf2a]        # 4120f0 <write@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <backtrace@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xaf22]        # 4120f8 <backtrace@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <__x86_get_cpuid_feature_leaf@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xaf1a]        # 412100 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <free@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xaf12]        # 412108 <free@GLIBC_2.2.5>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xaddf]        # 412000 <__swc_fn_ff58629f_000179_05d3c06b+0x560>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40ca80 <__swc_fn_ff58629f_000121_71a5b1cd>
  40724e:	xor    ecx,ecx
  407250:	call   40c1a0 <__swc_fn_ff58629f_000094_335e9a12>
  407255:	call   411aa0 <__swc_fn_ff58629f_000179_05d3c06b>
  40725a:	call   40f070 <__swc_fn_ff58629f_000095_a3245f7e>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_ff58629f_000000_29b04951>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_ff58629f_000003_644dadb7>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_ff58629f_000003_644dadb7+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   409240 <__swc_fn_ff58629f_000111_e724f834>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_ff58629f_000003_644dadb7+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1bd81]        # 423048 <__swc_bss_base_ff58629f+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1bd7a]        # 423048 <__swc_bss_base_ff58629f+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_ff58629f_000003_644dadb7+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_ff58629f_000003_644dadb7+0x30>
  4072e6:	lea    rcx,[rip+0x1bd63]        # 423050 <__swc_bss_base_ff58629f+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1bd5c]        # 423050 <__swc_bss_base_ff58629f+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_ff58629f_000003_644dadb7+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_ff58629f_000003_644dadb7+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_ff58629f_000006_12cb36a2>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40d920 <__swc_fn_ff58629f_000011_e75d466d>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_ff58629f_000012_39679ef8>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_ff58629f_000006_12cb36a2+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_ff58629f_000003_644dadb7>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_ff58629f_000006_12cb36a2+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_ff58629f_000009_2417e911>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_ff58629f_000009_2417e911+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40a530 <__swc_fn_ff58629f_000007_635028f3>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40d910 <__swc_fn_ff58629f_000008_578f1784>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_ff58629f_000009_2417e911+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_ff58629f_000009_2417e911+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_ff58629f_000012_39679ef8>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_ff58629f_000015_aa8c841a>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_ff58629f_000015_aa8c841a+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_ff58629f_000015_aa8c841a+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_ff58629f_000015_aa8c841a+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_ff58629f_000015_aa8c841a+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40da80 <__swc_fn_ff58629f_000017_e238d24c>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_ff58629f_000015_aa8c841a+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1bb3d]        # 423058 <__swc_bss_base_ff58629f+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1bb36]        # 423058 <__swc_bss_base_ff58629f+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_ff58629f_000015_aa8c841a+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_ff58629f_000015_aa8c841a+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40d920 <__swc_fn_ff58629f_000011_e75d466d>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_ff58629f_000015_aa8c841a+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   40c7a0 <__swc_fn_ff58629f_000112_cb2656be>
  407569:	lea    rcx,[rip+0x1bad8]        # 423048 <__swc_bss_base_ff58629f+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1bad1]        # 423048 <__swc_bss_base_ff58629f+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_ff58629f_000015_aa8c841a+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_ff58629f_000015_aa8c841a+0x110>
  407598:	lea    rcx,[rip+0x1bac1]        # 423060 <__swc_bss_base_ff58629f+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1baba]        # 423060 <__swc_bss_base_ff58629f+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_ff58629f_000015_aa8c841a+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_ff58629f_000015_aa8c841a+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_ff58629f_000018_e2e8e4b0>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_ff58629f_000015_aa8c841a+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_ff58629f_000018_e2e8e4b0>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_ff58629f_000018_e2e8e4b0+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_ff58629f_000018_e2e8e4b0+0x10>

0000000000407630 <__swc_fn_ff58629f_000021_fe13ecad>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_ff58629f_000015_aa8c841a>
  40763e:	lea    rdi,[rip+0x1bbab]        # 4231f0 <__swc_bss_base_ff58629f+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   4098a0 <__swc_fn_ff58629f_000135_1fec60ac>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1bb94]        # 4231f8 <__swc_bss_base_ff58629f+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1bb89],rsi        # 4231f8 <__swc_bss_base_ff58629f+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_ff58629f_000024_7e9350e1>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_ff58629f_000027_7e9350e1>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_ff58629f_000030_686c93a8>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_ff58629f_000030_686c93a8+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1992c]        # 421000 <__swc_data_base_ff58629f>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_ff58629f_000030_686c93a8+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_ff58629f_000030_686c93a8+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_ff58629f_000030_686c93a8+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40dc40 <__swc_fn_ff58629f_000032_8c89735c>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_ff58629f_000030_686c93a8+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_ff58629f_000036_62160bb3>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_ff58629f_000030_686c93a8+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_ff58629f_000042_70d5ab54>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_ff58629f_000033_7d7574b6>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40a9e0 <__swc_fn_ff58629f_000031_ed8d61a9>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   409720 <__swc_fn_ff58629f_000129_0672cd48>
  407734:	mov    rcx,rsi
  407737:	call   40dc40 <__swc_fn_ff58629f_000032_8c89735c>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_ff58629f_000036_62160bb3>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_ff58629f_000039_05a50673>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_ff58629f_000039_05a50673+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_ff58629f_000039_05a50673+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_ff58629f_000039_05a50673+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_ff58629f_000039_05a50673+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_ff58629f_000039_05a50673+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   409320 <__swc_fn_ff58629f_000114_0575f585>
  4077ca:	lea    rcx,[rip+0x1b877]        # 423048 <__swc_bss_base_ff58629f+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1b870]        # 423048 <__swc_bss_base_ff58629f+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_ff58629f_000039_05a50673+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_ff58629f_000039_05a50673+0x90>
  4077f8:	lea    rcx,[rip+0x1b861]        # 423060 <__swc_bss_base_ff58629f+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1b85a]        # 423060 <__swc_bss_base_ff58629f+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_ff58629f_000039_05a50673+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_ff58629f_000039_05a50673+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_ff58629f_000042_70d5ab54>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_ff58629f_000042_70d5ab54+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40e210 <__swc_fn_ff58629f_000059_c8e1ff6b>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   4098a0 <__swc_fn_ff58629f_000135_1fec60ac>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_ff58629f_000042_70d5ab54+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_ff58629f_000042_70d5ab54+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_ff58629f_000009_2417e911>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_ff58629f_000042_70d5ab54+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40d940 <__swc_fn_ff58629f_000014_1acdaf22>
  40791e:	jmp    407941 <__swc_fn_ff58629f_000042_70d5ab54+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_ff58629f_000042_70d5ab54+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_ff58629f_000042_70d5ab54+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_ff58629f_000042_70d5ab54+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40aba0 <__swc_fn_ff58629f_000043_3755033a>
  407997:	mov    rcx,rdi
  40799a:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_ff58629f_000039_05a50673>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_ff58629f_000045_06cec934>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_ff58629f_000045_06cec934+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_ff58629f_000045_06cec934+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_ff58629f_000045_06cec934+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_ff58629f_000045_06cec934+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   4098a0 <__swc_fn_ff58629f_000135_1fec60ac>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_ff58629f_000045_06cec934+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_ff58629f_000045_06cec934+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_ff58629f_000045_06cec934+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_ff58629f_000045_06cec934+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_ff58629f_000009_2417e911>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_ff58629f_000045_06cec934+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_ff58629f_000045_06cec934+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_ff58629f_000045_06cec934+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_ff58629f_000045_06cec934+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_ff58629f_000045_06cec934+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40a5e0 <__swc_fn_ff58629f_000013_d15d37c6>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_ff58629f_000045_06cec934+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_ff58629f_000045_06cec934+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_ff58629f_000045_06cec934+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_ff58629f_000045_06cec934+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40dac0 <__swc_fn_ff58629f_000020_4135c89a>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_ff58629f_000045_06cec934+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40a5e0 <__swc_fn_ff58629f_000013_d15d37c6>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_ff58629f_000045_06cec934+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_ff58629f_000021_fe13ecad>
  407c07:	mov    rcx,r14
  407c0a:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_ff58629f_000045_06cec934+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_ff58629f_000045_06cec934+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_ff58629f_000045_06cec934+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_ff58629f_000048_18a95c9b>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_ff58629f_000048_18a95c9b+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_ff58629f_000048_18a95c9b+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_ff58629f_000048_18a95c9b+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_ff58629f_000048_18a95c9b+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40de70 <__swc_fn_ff58629f_000047_3d3eceb4>
  407d14:	jmp    407ce0 <__swc_fn_ff58629f_000048_18a95c9b+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_ff58629f_000048_18a95c9b+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_ff58629f_000048_18a95c9b+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_ff58629f_000048_18a95c9b+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_ff58629f_000048_18a95c9b+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_ff58629f_000048_18a95c9b+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_ff58629f_000048_18a95c9b+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_ff58629f_000048_18a95c9b+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_ff58629f_000051_5b91e689>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_ff58629f_000051_5b91e689+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_ff58629f_000051_5b91e689+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_ff58629f_000051_5b91e689+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_ff58629f_000051_5b91e689+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40ddd0 <__swc_fn_ff58629f_000044_cac7f504>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40d940 <__swc_fn_ff58629f_000014_1acdaf22>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_ff58629f_000054_1dfec8f6>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   4098a0 <__swc_fn_ff58629f_000135_1fec60ac>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_ff58629f_000054_1dfec8f6+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_ff58629f_000054_1dfec8f6+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_ff58629f_000054_1dfec8f6+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_ff58629f_000057_8be0372b>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_ff58629f_000060_9d59636e>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_ff58629f_000060_9d59636e+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_ff58629f_000039_05a50673>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_ff58629f_000060_9d59636e+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_ff58629f_000063_3509a564>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40af20 <__swc_fn_ff58629f_000052_26c6c1c4>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_ff58629f_000054_1dfec8f6>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_ff58629f_000063_3509a564+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_ff58629f_000063_3509a564+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40b040 <__swc_fn_ff58629f_000058_033ce1da>
  407f7f:	mov    rcx,rsi
  407f82:	call   40ac80 <__swc_fn_ff58629f_000049_781177b4>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_ff58629f_000066_77c6e829>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_ff58629f_000066_77c6e829+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1b049]        # 423070 <__swc_bss_base_ff58629f+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1b04b]        # 423080 <__swc_bss_base_ff58629f+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_ff58629f_000066_77c6e829+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_ff58629f_000066_77c6e829+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40a910 <__swc_fn_ff58629f_000022_77c2d682>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_ff58629f_000066_77c6e829+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_ff58629f_000063_3509a564>
  40808f:	jmp    408122 <__swc_fn_ff58629f_000066_77c6e829+0x192>
  408094:	lea    rax,[rip+0x18f65]        # 421000 <__swc_data_base_ff58629f>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_ff58629f_000066_77c6e829+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_ff58629f_000066_77c6e829+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_ff58629f_000066_77c6e829+0x135>
  4080b8:	call   40a9e0 <__swc_fn_ff58629f_000031_ed8d61a9>
  4080bd:	mov    rcx,rax
  4080c0:	call   40fe00 <__swc_fn_ff58629f_000128_9c45d2d7>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_ff58629f_000066_77c6e829+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_ff58629f_000066_77c6e829+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_ff58629f_000066_77c6e829+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40de70 <__swc_fn_ff58629f_000047_3d3eceb4>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_ff58629f_000066_77c6e829+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_ff58629f_000051_5b91e689>
  408115:	jmp    408122 <__swc_fn_ff58629f_000066_77c6e829+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40a550 <__swc_fn_ff58629f_000010_186cd0c2>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_ff58629f_000069_165b6301>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_ff58629f_000036_62160bb3>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_ff58629f_000069_165b6301+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1b09a]        # 423240 <__swc_bss_base_ff58629f+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_ff58629f_000069_165b6301+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   4098a0 <__swc_fn_ff58629f_000135_1fec60ac>
  4081b5:	mov    rcx,rsi
  4081b8:	call   40e640 <__swc_fn_ff58629f_000068_557d6092>
  4081bd:	mov    rcx,rsi
  4081c0:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_ff58629f_000072_b2caea81>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40e390 <__swc_fn_ff58629f_000065_cd9dd53e>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_ff58629f_000075_104c4b5d>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   40e640 <__swc_fn_ff58629f_000068_557d6092>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_ff58629f_000078_5a70c27a>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_ff58629f_000078_5a70c27a+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_ff58629f_000078_5a70c27a+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_ff58629f_000081_85585149>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_ff58629f_000084_746bf146>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_ff58629f_000090_9a1d717d>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_ff58629f_000084_746bf146+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_ff58629f_000084_746bf146+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_ff58629f_000084_746bf146+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_ff58629f_000084_746bf146+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_ff58629f_000090_9a1d717d>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_ff58629f_000084_746bf146+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_ff58629f_000084_746bf146+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_ff58629f_000084_746bf146+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_ff58629f_000084_746bf146+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_ff58629f_000084_746bf146+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_ff58629f_000084_746bf146+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_ff58629f_000084_746bf146+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_ff58629f_000084_746bf146+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_ff58629f_000084_746bf146+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_ff58629f_000084_746bf146+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40c020 <__swc_fn_ff58629f_000082_9f4f5092>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_ff58629f_000084_746bf146+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_ff58629f_000084_746bf146+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_ff58629f_000084_746bf146+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40c020 <__swc_fn_ff58629f_000082_9f4f5092>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_ff58629f_000084_746bf146+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_ff58629f_000084_746bf146>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_ff58629f_000084_746bf146+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_ff58629f_000084_746bf146+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_ff58629f_000087_1fb4fcfe>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_ff58629f_000090_9a1d717d>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_ff58629f_000087_1fb4fcfe+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   40eaa0 <__swc_fn_ff58629f_000086_ac8c6565>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_ff58629f_000087_1fb4fcfe+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_ff58629f_000087_1fb4fcfe+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_ff58629f_000087_1fb4fcfe+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40c020 <__swc_fn_ff58629f_000082_9f4f5092>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_ff58629f_000087_1fb4fcfe+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_ff58629f_000087_1fb4fcfe>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_ff58629f_000087_1fb4fcfe+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_ff58629f_000087_1fb4fcfe+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_ff58629f_000090_9a1d717d>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_ff58629f_000090_9a1d717d+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_ff58629f_000090_9a1d717d+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_ff58629f_000090_9a1d717d+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_ff58629f_000090_9a1d717d+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40c020 <__swc_fn_ff58629f_000082_9f4f5092>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40c020 <__swc_fn_ff58629f_000082_9f4f5092>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_ff58629f_000090_9a1d717d+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_ff58629f_000090_9a1d717d+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_ff58629f_000090_9a1d717d+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_ff58629f_000090_9a1d717d+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_ff58629f_000090_9a1d717d>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_ff58629f_000090_9a1d717d+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_ff58629f_000090_9a1d717d+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_ff58629f_000090_9a1d717d+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_ff58629f_000090_9a1d717d+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_ff58629f_000090_9a1d717d+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_ff58629f_000090_9a1d717d+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_ff58629f_000090_9a1d717d+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_ff58629f_000090_9a1d717d+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_ff58629f_000090_9a1d717d+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_ff58629f_000090_9a1d717d+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_ff58629f_000090_9a1d717d+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_ff58629f_000090_9a1d717d+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_ff58629f_000090_9a1d717d+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_ff58629f_000090_9a1d717d+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_ff58629f_000090_9a1d717d+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_ff58629f_000090_9a1d717d+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   409db0 <__swc_fn_ff58629f_000147_c9c6528e>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_ff58629f_000090_9a1d717d+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_ff58629f_000090_9a1d717d>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_ff58629f_000090_9a1d717d+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_ff58629f_000090_9a1d717d+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_ff58629f_000090_9a1d717d+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   409db0 <__swc_fn_ff58629f_000147_c9c6528e>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   409db0 <__swc_fn_ff58629f_000147_c9c6528e>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_ff58629f_000093_344f5089>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40c150 <__swc_fn_ff58629f_000091_e6773530>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_ff58629f_000093_344f5089+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_ff58629f_000093_344f5089+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   40ffa0 <__swc_fn_ff58629f_000137_899a611e>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_ff58629f_000093_344f5089+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0x9872]        # 4121c0 <__swc_rdata_base_ff58629f+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   40fad0 <__swc_fn_ff58629f_000116_3499f7d6>
  408959:	call   40c9d0 <__swc_fn_ff58629f_000118_2b35b5e0>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_ff58629f_000096_f879630a>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40896f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  408975:	vzeroupper
  408978:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40897e:	mov    QWORD PTR [rsp+0x48],rdx
  408983:	mov    rax,r8
  408986:	cmp    r8,0x1
  40898a:	mov    edx,0x1
  40898f:	cmovb  rax,rdx
  408993:	mov    QWORD PTR [rsp+0x50],rax
  408998:	mov    rbx,QWORD PTR [rcx+0x8]
  40899c:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a0:	mov    rcx,QWORD PTR [rcx]
  4089a3:	lea    rdx,[rsp+0x8]
  4089a8:	call   rbx
  4089aa:	add    rsp,0x70
  4089ae:	pop    rbx
  4089af:	ret

00000000004089b0 <__swc_fn_ff58629f_000099_6e0faaee>:
  4089b0:	push   rbx
  4089b1:	push   rsi
  4089b2:	push   rdi
  4089b3:	sub    rsp,0x30
  4089b7:	mov    rbx,rcx
  4089ba:	test   rcx,rcx
  4089bd:	je     4089d2 <__swc_fn_ff58629f_000099_6e0faaee+0x22>
  4089bf:	mov    rcx,rbx
  4089c2:	mov    edx,0x1
  4089c7:	call   408200 <__swc_fn_ff58629f_000078_5a70c27a>
  4089cc:	cmp    rax,0x1
  4089d0:	je     4089da <__swc_fn_ff58629f_000099_6e0faaee+0x2a>
  4089d2:	add    rsp,0x30
  4089d6:	pop    rdi
  4089d7:	pop    rsi
  4089d8:	pop    rbx
  4089d9:	ret
  4089da:	lea    rsi,[rsp+0x8]
  4089df:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089e4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089ea:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  4089ef:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4089f5:	mov    rax,QWORD PTR [rsp+0x20]
  4089fa:	test   rax,rax
  4089fd:	je     408a13 <__swc_fn_ff58629f_000099_6e0faaee+0x63>
  4089ff:	test   DWORD PTR [rax+0x28],0x400000
  408a06:	je     408a13 <__swc_fn_ff58629f_000099_6e0faaee+0x63>
  408a08:	mov    rcx,QWORD PTR [rax+0x30]
  408a0c:	test   rcx,rcx
  408a0f:	cmovne rax,rcx
  408a13:	mov    edi,DWORD PTR [rax+0x20]
  408a16:	lea    rcx,[rsp+0x18]
  408a1b:	call   40c330 <__swc_fn_ff58629f_000100_2ef16a3e>
  408a20:	mov    rcx,rsi
  408a23:	mov    rdx,QWORD PTR [rsp+0x18]
  408a28:	mov    r8,rdi
  408a2b:	call   408960 <__swc_fn_ff58629f_000096_f879630a>
  408a30:	mov    rcx,QWORD PTR [rbx+0x28]
  408a34:	call   40f080 <__swc_fn_ff58629f_000098_d9d80f1a>
  408a39:	mov    rcx,rsi
  408a3c:	mov    rdx,rbx
  408a3f:	mov    r8d,0x30
  408a45:	call   408960 <__swc_fn_ff58629f_000096_f879630a>
  408a4a:	add    rsp,0x30
  408a4e:	pop    rdi
  408a4f:	pop    rsi
  408a50:	pop    rbx
  408a51:	ret
	...

0000000000408a60 <__swc_fn_ff58629f_000102_29a1093a>:
  408a60:	push   rbp
  408a61:	push   rbx
  408a62:	push   rsi
  408a63:	push   rdi
  408a64:	push   r12
  408a66:	push   r13
  408a68:	push   r14
  408a6a:	push   r15
  408a6c:	sub    rsp,0x500
  408a73:	mov    rbp,rsp
  408a76:	mov    rbx,rsp
  408a79:	mov    rsi,rdx
  408a7c:	mov    rdi,rcx
  408a7f:	mov    rcx,QWORD PTR [rip+0x1d2ba]        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  408a86:	test   rcx,rcx
  408a89:	jne    408aa3 <__swc_fn_ff58629f_000102_29a1093a+0x43>
  408a8b:	sub    rsp,0x8
  408a8f:	call   40a1a0 <__swc_fn_ff58629f_000165_e09accff>
  408a94:	add    rsp,0x8
  408a98:	lea    rcx,[rax+0x1]
  408a9c:	mov    QWORD PTR [rip+0x1d29d],rcx        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  408aa3:	dec    rcx
  408aa6:	sub    rsp,0x8
  408aaa:	call   411880 <__swc_fn_ff58629f_000167_3130645d>
  408aaf:	add    rsp,0x8
  408ab3:	mov    r12,rax
  408ab6:	mov    QWORD PTR [rsp+0x4f0],rax
  408abe:	lea    rax,[rip+0x983b]        # 412300 <__swc_rdata_base_ff58629f+0x1f0>
  408ac5:	sub    rsp,0x20
  408ac9:	mov    rcx,rsp
  408acc:	mov    QWORD PTR [rcx],rax
  408acf:	lea    r13,[rip+0x983a]        # 412310 <__swc_rdata_base_ff58629f+0x200>
  408ad6:	mov    QWORD PTR [rcx+0x8],r13
  408ada:	mov    QWORD PTR [rcx+0x10],rsp
  408ade:	mov    QWORD PTR [rcx+0x18],0x1
  408ae6:	lea    rcx,[rsp+0x10]
  408aeb:	sub    rsp,0x8
  408aef:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  408af4:	add    rsp,0x8
  408af8:	add    rsp,0x20
  408afc:	lea    rax,[rip+0x9855]        # 412358 <__swc_rdata_base_ff58629f+0x248>
  408b03:	sub    rsp,0x20
  408b07:	mov    rcx,rsp
  408b0a:	mov    QWORD PTR [rcx],rax
  408b0d:	mov    QWORD PTR [rcx+0x8],r13
  408b11:	mov    QWORD PTR [rcx+0x10],rsp
  408b15:	mov    QWORD PTR [rcx+0x18],0x1
  408b1d:	lea    rcx,[rsp+0x10]
  408b22:	sub    rsp,0x8
  408b26:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  408b2b:	add    rsp,0x8
  408b2f:	add    rsp,0x20
  408b33:	lea    r14,[rip+0x982e]        # 412368 <__swc_rdata_base_ff58629f+0x258>
  408b3a:	sub    rsp,0x50
  408b3e:	mov    rax,rsp
  408b41:	vmovups xmm0,XMMWORD PTR [rip+0x9957]        # 4124a0 <__swc_rdata_base_ff58629f+0x390>
  408b49:	vmovups XMMWORD PTR [rax],xmm0
  408b4d:	mov    QWORD PTR [rax+0x10],rsp
  408b51:	mov    QWORD PTR [rax+0x18],r13
  408b55:	mov    QWORD PTR [rax+0x20],rdi
  408b59:	lea    rdi,[rip+0x9818]        # 412378 <__swc_rdata_base_ff58629f+0x268>
  408b60:	mov    QWORD PTR [rax+0x28],rdi
  408b64:	mov    QWORD PTR [rax+0x30],r14
  408b68:	mov    QWORD PTR [rax+0x38],r13
  408b6c:	lea    rcx,[rsp+0x10]
  408b71:	mov    QWORD PTR [rax+0x40],rcx
  408b75:	mov    QWORD PTR [rax+0x48],0x3
  408b7d:	lea    rcx,[rsp+0x40]
  408b82:	sub    rsp,0x8
  408b86:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  408b8b:	add    rsp,0x8
  408b8f:	add    rsp,0x50
  408b93:	lea    rax,[rip+0x9826]        # 4123c0 <__swc_rdata_base_ff58629f+0x2b0>
  408b9a:	sub    rsp,0x20
  408b9e:	mov    rcx,rsp
  408ba1:	mov    QWORD PTR [rcx],rax
  408ba4:	mov    QWORD PTR [rcx+0x8],r13
  408ba8:	mov    QWORD PTR [rcx+0x10],rsp
  408bac:	mov    QWORD PTR [rcx+0x18],0x1
  408bb4:	lea    rcx,[rsp+0x10]
  408bb9:	sub    rsp,0x8
  408bbd:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  408bc2:	add    rsp,0x8
  408bc6:	add    rsp,0x20
  408bca:	mov    eax,DWORD PTR [rsi+0x20]
  408bcd:	mov    ecx,DWORD PTR [rsi+0x24]
  408bd0:	sub    rsp,0xa0
  408bd7:	mov    rdx,rsp
  408bda:	mov    QWORD PTR [rdx+0x30],rsi
  408bde:	mov    QWORD PTR [rdx+0x38],rdi
  408be2:	vmovups xmm0,XMMWORD PTR [rip+0x984e]        # 412438 <__swc_rdata_base_ff58629f+0x328>
  408bea:	vmovups XMMWORD PTR [rdx],xmm0
  408bee:	mov    QWORD PTR [rdx+0x40],rsp
  408bf2:	mov    QWORD PTR [rdx+0x48],r13
  408bf6:	mov    DWORD PTR [rdx+0x10],eax
  408bf9:	lea    rax,[rsp+0x10]
  408bfe:	mov    QWORD PTR [rdx+0x50],rax
  408c02:	lea    rax,[rip+0x97c7]        # 4123d0 <__swc_rdata_base_ff58629f+0x2c0>
  408c09:	mov    QWORD PTR [rdx+0x58],rax
  408c0d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c12:	lea    r8,[rsp+0x18]
  408c17:	mov    QWORD PTR [rdx+0x60],r8
  408c1b:	mov    QWORD PTR [rdx+0x68],r13
  408c1f:	mov    DWORD PTR [rdx+0x28],ecx
  408c22:	lea    rcx,[rdx+0x28]
  408c26:	mov    QWORD PTR [rdx+0x70],rcx
  408c2a:	mov    QWORD PTR [rdx+0x78],rax
  408c2e:	mov    QWORD PTR [rdx+0x80],r14
  408c35:	mov    QWORD PTR [rdx+0x88],r13
  408c3c:	lea    rax,[rdx+0x30]
  408c40:	mov    QWORD PTR [rdx+0x90],rax
  408c47:	mov    QWORD PTR [rdx+0x98],0x6
  408c52:	lea    rcx,[rdx+0x90]
  408c59:	sub    rsp,0x8
  408c5d:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  408c62:	add    rsp,0x8
  408c66:	add    rsp,0xa0
  408c6d:	sub    rsp,0x20
  408c71:	mov    rax,rsp
  408c74:	mov    QWORD PTR [rax],r14
  408c77:	mov    QWORD PTR [rax+0x8],r13
  408c7b:	mov    QWORD PTR [rax+0x10],rsp
  408c7f:	mov    QWORD PTR [rax+0x18],0x1
  408c87:	lea    rcx,[rsp+0x10]
  408c8c:	sub    rsp,0x8
  408c90:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  408c95:	add    rsp,0x8
  408c99:	add    rsp,0x20
  408c9d:	mov    eax,DWORD PTR [r12+0x9ac]
  408ca5:	test   eax,eax
  408ca7:	je     408ee0 <__swc_fn_ff58629f_000102_29a1093a+0x480>
  408cad:	lea    rax,[rip+0x9764]        # 412418 <__swc_rdata_base_ff58629f+0x308>
  408cb4:	sub    rsp,0x20
  408cb8:	mov    rcx,rsp
  408cbb:	mov    QWORD PTR [rcx],rax
  408cbe:	mov    QWORD PTR [rcx+0x8],r13
  408cc2:	mov    QWORD PTR [rcx+0x10],rsp
  408cc6:	mov    QWORD PTR [rcx+0x18],0x1
  408cce:	lea    rcx,[rsp+0x10]
  408cd3:	sub    rsp,0x8
  408cd7:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  408cdc:	add    rsp,0x8
  408ce0:	add    rsp,0x20
  408ce4:	mov    eax,DWORD PTR [r12+0x9ac]
  408cec:	dec    eax
  408cee:	mov    esi,eax
  408cf0:	test   esi,esi
  408cf2:	jl     408eb0 <__swc_fn_ff58629f_000102_29a1093a+0x450>
  408cf8:	jmp    408d04 <__swc_fn_ff58629f_000102_29a1093a+0x2a4>
  408cfa:	nop    WORD PTR [rax+rax*1+0x0]
  408d00:	dec    esi
  408d02:	jmp    408cf0 <__swc_fn_ff58629f_000102_29a1093a+0x290>
  408d04:	lea    rax,[rip+0x971d]        # 412428 <__swc_rdata_base_ff58629f+0x318>
  408d0b:	sub    rsp,0x20
  408d0f:	mov    rcx,rsp
  408d12:	mov    QWORD PTR [rcx],rax
  408d15:	mov    QWORD PTR [rcx+0x8],r13
  408d19:	mov    QWORD PTR [rcx+0x10],rsp
  408d1d:	mov    QWORD PTR [rcx+0x18],0x1
  408d25:	lea    rcx,[rsp+0x10]
  408d2a:	sub    rsp,0x8
  408d2e:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  408d33:	add    rsp,0x8
  408d37:	add    rsp,0x20
  408d3b:	movsxd rax,esi
  408d3e:	imul   r15,rax,0x30
  408d42:	add    r15,r12
  408d45:	add    r15,0xf8
  408d4c:	sub    rsp,0x20
  408d50:	mov    rax,rsp
  408d53:	mov    QWORD PTR [rax],r15
  408d56:	mov    QWORD PTR [rax+0x8],rdi
  408d5a:	mov    QWORD PTR [rax+0x10],rsp
  408d5e:	mov    QWORD PTR [rax+0x18],0x1
  408d66:	lea    rcx,[rsp+0x10]
  408d6b:	sub    rsp,0x8
  408d6f:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  408d74:	add    rsp,0x8
  408d78:	add    rsp,0x20
  408d7c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408d84:	lea    rsi,[rip+0x96ad]        # 412438 <__swc_rdata_base_ff58629f+0x328>
  408d8b:	sub    rsp,0x20
  408d8f:	mov    rax,rsp
  408d92:	mov    QWORD PTR [rax],rsi
  408d95:	mov    QWORD PTR [rax+0x8],r13
  408d99:	mov    QWORD PTR [rax+0x10],rsp
  408d9d:	mov    QWORD PTR [rax+0x18],0x1
  408da5:	lea    rcx,[rsp+0x10]
  408daa:	sub    rsp,0x8
  408dae:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  408db3:	add    rsp,0x8
  408db7:	add    rsp,0x20
  408dbb:	sub    rsp,0x30
  408dbf:	mov    rax,rsp
  408dc2:	mov    ecx,DWORD PTR [r15+0x20]
  408dc6:	mov    QWORD PTR [rax],rcx
  408dc9:	mov    QWORD PTR [rax+0x8],rsp
  408dcd:	lea    rdi,[rip+0x9674]        # 412448 <__swc_rdata_base_ff58629f+0x338>
  408dd4:	mov    QWORD PTR [rax+0x10],rdi
  408dd8:	lea    rcx,[rsp+0x8]
  408ddd:	mov    QWORD PTR [rax+0x18],rcx
  408de1:	mov    QWORD PTR [rax+0x20],0x1
  408de9:	lea    rcx,[rsp+0x18]
  408dee:	sub    rsp,0x8
  408df2:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  408df7:	add    rsp,0x8
  408dfb:	add    rsp,0x30
  408dff:	sub    rsp,0x20
  408e03:	mov    rax,rsp
  408e06:	mov    QWORD PTR [rax],rsi
  408e09:	mov    QWORD PTR [rax+0x8],r13
  408e0d:	mov    QWORD PTR [rax+0x10],rsp
  408e11:	mov    QWORD PTR [rax+0x18],0x1
  408e19:	lea    rcx,[rsp+0x10]
  408e1e:	sub    rsp,0x8
  408e22:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  408e27:	add    rsp,0x8
  408e2b:	add    rsp,0x20
  408e2f:	sub    rsp,0x30
  408e33:	mov    rax,rsp
  408e36:	mov    ecx,DWORD PTR [r15+0x24]
  408e3a:	mov    QWORD PTR [rax],rcx
  408e3d:	mov    QWORD PTR [rax+0x8],rsp
  408e41:	mov    QWORD PTR [rax+0x10],rdi
  408e45:	lea    rcx,[rsp+0x8]
  408e4a:	mov    QWORD PTR [rax+0x18],rcx
  408e4e:	mov    QWORD PTR [rax+0x20],0x1
  408e56:	lea    rcx,[rsp+0x18]
  408e5b:	sub    rsp,0x8
  408e5f:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  408e64:	add    rsp,0x8
  408e68:	add    rsp,0x30
  408e6c:	sub    rsp,0x20
  408e70:	mov    rax,rsp
  408e73:	mov    QWORD PTR [rax],r14
  408e76:	mov    QWORD PTR [rax+0x8],r13
  408e7a:	mov    QWORD PTR [rax+0x10],rsp
  408e7e:	mov    QWORD PTR [rax+0x18],0x1
  408e86:	lea    rcx,[rsp+0x10]
  408e8b:	sub    rsp,0x8
  408e8f:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  408e94:	add    rsp,0x8
  408e98:	add    rsp,0x20
  408e9c:	lea    rdi,[rip+0x94d5]        # 412378 <__swc_rdata_base_ff58629f+0x268>
  408ea3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408eab:	jmp    408d00 <__swc_fn_ff58629f_000102_29a1093a+0x2a0>
  408eb0:	sub    rsp,0x20
  408eb4:	mov    rax,rsp
  408eb7:	mov    QWORD PTR [rax],r14
  408eba:	mov    QWORD PTR [rax+0x8],r13
  408ebe:	mov    QWORD PTR [rax+0x10],rsp
  408ec2:	mov    QWORD PTR [rax+0x18],0x1
  408eca:	lea    rcx,[rsp+0x10]
  408ecf:	sub    rsp,0x8
  408ed3:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  408ed8:	add    rsp,0x8
  408edc:	add    rsp,0x20
  408ee0:	lea    rax,[rbx+0x28]
  408ee4:	mov    rcx,rax
  408ee7:	mov    QWORD PTR [rbx+0x28],0x0
  408eef:	mov    QWORD PTR [rbx+0x30],0x0
  408ef7:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408efc:	add    rcx,0x10
  408f00:	mov    edx,0x1f
  408f05:	cs nop WORD PTR [rax+rax*1+0x0]
  408f0f:	nop
  408f10:	vmovups XMMWORD PTR [rcx],xmm0
  408f14:	add    rcx,0x10
  408f18:	sub    rdx,0x1
  408f1c:	jne    408f10 <__swc_fn_ff58629f_000102_29a1093a+0x4b0>
  408f1e:	lea    rsi,[rbx+0x228]
  408f25:	xor    ecx,ecx
  408f27:	cs nop WORD PTR [rax+rax*1+0x0]
  408f31:	cs nop WORD PTR [rax+rax*1+0x0]
  408f3b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f40:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f45:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f4a:	add    rcx,0x10
  408f4e:	cmp    rcx,0x200
  408f55:	jne    408f40 <__swc_fn_ff58629f_000102_29a1093a+0x4e0>
  408f57:	mov    eax,DWORD PTR [r12+0xbc8]
  408f5f:	lea    rcx,[r12+0x9c8]
  408f67:	mov    QWORD PTR [rbx+0x428],rcx
  408f6e:	mov    QWORD PTR [rbx+0x430],rax
  408f75:	lea    rdi,[rbx+0x438]
  408f7c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408f84:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408f8c:	mov    eax,DWORD PTR [r12+0xbc8]
  408f94:	test   eax,eax
  408f96:	jne    408fe3 <__swc_fn_ff58629f_000102_29a1093a+0x583>
  408f98:	lea    rax,[rbx+0x448]
  408f9f:	mov    QWORD PTR [rbx+0x448],rsi
  408fa6:	mov    QWORD PTR [rax+0x8],0x40
  408fae:	mov    ecx,0x1
  408fb3:	mov    rdx,rax
  408fb6:	sub    rsp,0x8
  408fba:	call   40fbe0 <__swc_fn_ff58629f_000119_18cd3882>
  408fbf:	add    rsp,0x8
  408fc3:	mov    QWORD PTR [rbx+0x460],rsi
  408fca:	mov    ecx,eax
  408fcc:	mov    QWORD PTR [rbx+0x468],rcx
  408fd3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408fdb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fe3:	mov    rsi,QWORD PTR [rbx+0x438]
  408fea:	mov    rax,QWORD PTR [rbx+0x440]
  408ff1:	mov    r15,rax
  408ff4:	xor    r12d,r12d
  408ff7:	test   r15,r15
  408ffa:	je     4090b0 <__swc_fn_ff58629f_000102_29a1093a+0x650>
  409000:	mov    rax,QWORD PTR [rsi+r12*8]
  409004:	test   rax,rax
  409007:	je     409026 <__swc_fn_ff58629f_000102_29a1093a+0x5c6>
  409009:	lea    rcx,[rbx+0x4b8]
  409010:	mov    rdx,rax
  409013:	sub    rsp,0x8
  409017:	call   409f10 <__swc_fn_ff58629f_000162_edb9cf73>
  40901c:	add    rsp,0x8
  409020:	mov    al,BYTE PTR [rax]
  409022:	test   al,al
  409024:	jne    409032 <__swc_fn_ff58629f_000102_29a1093a+0x5d2>
  409026:	add    r12,0x1
  40902a:	sub    r15,0x1
  40902e:	jne    409000 <__swc_fn_ff58629f_000102_29a1093a+0x5a0>
  409030:	jmp    4090b0 <__swc_fn_ff58629f_000102_29a1093a+0x650>
  409032:	lea    rax,[rip+0x9457]        # 412490 <__swc_rdata_base_ff58629f+0x380>
  409039:	sub    rsp,0x20
  40903d:	mov    rcx,rsp
  409040:	mov    QWORD PTR [rcx],rax
  409043:	mov    QWORD PTR [rcx+0x8],r13
  409047:	mov    QWORD PTR [rcx+0x10],rsp
  40904b:	mov    QWORD PTR [rcx+0x18],0x1
  409053:	lea    rcx,[rsp+0x10]
  409058:	sub    rsp,0x8
  40905c:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  409061:	add    rsp,0x8
  409065:	add    rsp,0x20
  409069:	mov    rcx,rdi
  40906c:	xor    edx,edx
  40906e:	mov    al,0x1
  409070:	mov    r8,rax
  409073:	sub    rsp,0x8
  409077:	call   40d260 <__swc_fn_ff58629f_000163_5fbed98a>
  40907c:	add    rsp,0x8
  409080:	sub    rsp,0x20
  409084:	mov    rax,rsp
  409087:	mov    QWORD PTR [rax],r14
  40908a:	mov    QWORD PTR [rax+0x8],r13
  40908e:	mov    QWORD PTR [rax+0x10],rsp
  409092:	mov    QWORD PTR [rax+0x18],0x1
  40909a:	lea    rcx,[rsp+0x10]
  40909f:	sub    rsp,0x8
  4090a3:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  4090a8:	add    rsp,0x8
  4090ac:	add    rsp,0x20
  4090b0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090b8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090c4:	add    rsp,0x500
  4090cb:	pop    r15
  4090cd:	pop    r14
  4090cf:	pop    r13
  4090d1:	pop    r12
  4090d3:	pop    rdi
  4090d4:	pop    rsi
  4090d5:	pop    rbx
  4090d6:	pop    rbp
  4090d7:	ret
	...

00000000004090e0 <__swc_fn_ff58629f_000105_b7aef7c0>:
  4090e0:	sub    rsp,0x8
  4090e4:	test   r8,r8
  4090e7:	je     4090ee <__swc_fn_ff58629f_000105_b7aef7c0+0xe>
  4090e9:	call   40f310 <__swc_fn_ff58629f_000104_baf871f8>
  4090ee:	add    rsp,0x8
  4090f2:	ret
	...

0000000000409100 <__swc_fn_ff58629f_000108_32416b9e>:
  409100:	push   rsi
  409101:	push   rdi
  409102:	push   r12
  409104:	push   r13
  409106:	sub    rsp,0xd8
  40910d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409113:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  409119:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40911f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  409125:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40912b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  409134:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40913d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  409146:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40914f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  409158:	xor    eax,eax
  40915a:	call   407010 <getpid@plt>
  40915f:	mov    rsi,rax
  409162:	lea    rdi,[rip+0x1cbdf]        # 425d48 <__swc_bss_base_ff58629f+0x2d08>
  409169:	mov    r12,QWORD PTR [rdi]
  40916c:	test   r12,r12
  40916f:	je     40917d <__swc_fn_ff58629f_000108_32416b9e+0x7d>
  409171:	cmp    DWORD PTR [r12+0x10],esi
  409176:	jne    40917d <__swc_fn_ff58629f_000108_32416b9e+0x7d>
  409178:	mov    rax,r12
  40917b:	jmp    4091e0 <__swc_fn_ff58629f_000108_32416b9e+0xe0>
  40917d:	mov    ecx,0x4
  409182:	mov    edx,0x18
  409187:	call   40f3f0 <__swc_fn_ff58629f_000107_ff529476>
  40918c:	mov    rcx,rax
  40918f:	test   rax,rax
  409192:	jne    409198 <__swc_fn_ff58629f_000108_32416b9e+0x98>
  409194:	xor    eax,eax
  409196:	jmp    4091e0 <__swc_fn_ff58629f_000108_32416b9e+0xe0>
  409198:	mov    DWORD PTR [rcx+0x10],esi
  40919b:	mov    rax,r12
  40919e:	lock cmpxchg QWORD PTR [rdi],rcx
  4091a3:	mov    r13,rax
  4091a6:	cmp    rax,r12
  4091a9:	je     4091bf <__swc_fn_ff58629f_000108_32416b9e+0xbf>
  4091ab:	mov    rdi,rcx
  4091ae:	mov    esi,0x18
  4091b3:	xor    eax,eax
  4091b5:	call   407020 <munmap@plt>
  4091ba:	mov    rax,r13
  4091bd:	jmp    4091e0 <__swc_fn_ff58629f_000108_32416b9e+0xe0>
  4091bf:	test   r12,r12
  4091c2:	je     4091dd <__swc_fn_ff58629f_000108_32416b9e+0xdd>
  4091c4:	mov    rdi,r12
  4091c7:	mov    esi,0x18
  4091cc:	xor    eax,eax
  4091ce:	mov    QWORD PTR [rsp+0x28],rcx
  4091d3:	call   407020 <munmap@plt>
  4091d8:	mov    rcx,QWORD PTR [rsp+0x28]
  4091dd:	mov    rax,rcx
  4091e0:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  4091e6:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  4091ec:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  4091f2:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  4091f8:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  4091fe:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409207:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  409210:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409219:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  409222:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40922b:	add    rsp,0xd8
  409232:	pop    r13
  409234:	pop    r12
  409236:	pop    rdi
  409237:	pop    rsi
  409238:	ret
  409239:	add    BYTE PTR [rax],al
  40923b:	add    BYTE PTR [rax],al
  40923d:	add    BYTE PTR [rax],al
	...

0000000000409240 <__swc_fn_ff58629f_000111_e724f834>:
  409240:	push   rbx
  409241:	push   r12
  409243:	push   rdi
  409244:	push   rsi
  409245:	sub    rsp,0xa8
  40924c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409252:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409258:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40925e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409264:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40926a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409270:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409276:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40927c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409285:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40928e:	mov    rbx,rdx
  409291:	mov    r12,rcx
  409294:	mov    rdi,rcx
  409297:	mov    rsi,rdx
  40929a:	mov    edx,0x3
  40929f:	xor    eax,eax
  4092a1:	call   407030 <mprotect@plt>
  4092a6:	test   eax,eax
  4092a8:	je     4092ae <__swc_fn_ff58629f_000111_e724f834+0x6e>
  4092aa:	xor    eax,eax
  4092ac:	jmp    4092c3 <__swc_fn_ff58629f_000111_e724f834+0x83>
  4092ae:	mov    rcx,r12
  4092b1:	mov    rdx,rbx
  4092b4:	mov    al,0x1
  4092b6:	mov    r8,rax
  4092b9:	call   40fa20 <__swc_fn_ff58629f_000110_e606239a>
  4092be:	mov    eax,0x1
  4092c3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4092c9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4092cf:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4092d5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4092db:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4092e1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4092e7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4092ed:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4092f3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4092fc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409305:	add    rsp,0xa8
  40930c:	pop    rsi
  40930d:	pop    rdi
  40930e:	pop    r12
  409310:	pop    rbx
  409311:	ret
	...

0000000000409320 <__swc_fn_ff58629f_000114_0575f585>:
  409320:	sub    rsp,0x8
  409324:	test   rcx,rcx
  409327:	jne    40932e <__swc_fn_ff58629f_000114_0575f585+0xe>
  409329:	add    rsp,0x8
  40932d:	ret
  40932e:	call   40c880 <__swc_fn_ff58629f_000115_259b5d5a>
  409333:	add    rsp,0x8
  409337:	ret
	...

0000000000409340 <__swc_fn_ff58629f_000117_76ff2f0a>:
  409340:	push   rdi
  409341:	push   rsi
  409342:	sub    rsp,0xa8
  409349:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40934f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409355:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40935b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409361:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409367:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40936d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409373:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409379:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409382:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40938b:	xor    edi,edi
  40938d:	xor    eax,eax
  40938f:	call   407040 <exit@plt>
  409394:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40939a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4093a0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4093a6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4093ac:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4093b2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4093b8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4093be:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4093c4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4093cd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4093d6:	add    rsp,0xa8
  4093dd:	pop    rsi
  4093de:	pop    rdi
  4093df:	ret

00000000004093e0 <__swc_fn_ff58629f_000120_1601f378>:
  4093e0:	push   rbx
  4093e1:	push   rsi
  4093e2:	push   rdi
  4093e3:	push   r12
  4093e5:	sub    rsp,0x18
  4093e9:	mov    rbx,r8
  4093ec:	mov    rsi,rcx
  4093ef:	mov    rdi,rdx
  4093f2:	mov    rcx,QWORD PTR [rip+0x1c947]        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  4093f9:	test   rcx,rcx
  4093fc:	jne    40940e <__swc_fn_ff58629f_000120_1601f378+0x2e>
  4093fe:	call   40a1a0 <__swc_fn_ff58629f_000165_e09accff>
  409403:	lea    rcx,[rax+0x1]
  409407:	mov    QWORD PTR [rip+0x1c932],rcx        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  40940e:	dec    rcx
  409411:	call   411880 <__swc_fn_ff58629f_000167_3130645d>
  409416:	mov    r12,rax
  409419:	cmp    ebx,0x3
  40941c:	jne    40942f <__swc_fn_ff58629f_000120_1601f378+0x4f>
  40941e:	mov    rax,QWORD PTR [r12+0xbd0]
  409426:	test   rax,rax
  409429:	jne    40956c <__swc_fn_ff58629f_000120_1601f378+0x18c>
  40942f:	cmp    ebx,0x5
  409432:	jne    409456 <__swc_fn_ff58629f_000120_1601f378+0x76>
  409434:	call   40c150 <__swc_fn_ff58629f_000091_e6773530>
  409439:	test   al,al
  40943b:	jne    409456 <__swc_fn_ff58629f_000120_1601f378+0x76>
  40943d:	mov    rcx,rsi
  409440:	mov    rdx,rdi
  409443:	call   411830 <__swc_fn_ff58629f_000164_15b66a30>
  409448:	test   al,al
  40944a:	je     409456 <__swc_fn_ff58629f_000120_1601f378+0x76>
  40944c:	add    rsp,0x18
  409450:	pop    r12
  409452:	pop    rdi
  409453:	pop    rsi
  409454:	pop    rbx
  409455:	ret
  409456:	call   40c150 <__swc_fn_ff58629f_000091_e6773530>
  40945b:	test   al,al
  40945d:	jne    4094cf <__swc_fn_ff58629f_000120_1601f378+0xef>
  40945f:	vmovups xmm0,XMMWORD PTR [rsi]
  409463:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409469:	mov    rax,QWORD PTR [rsp+0x8]
  40946e:	test   rax,rax
  409471:	jne    4094c2 <__swc_fn_ff58629f_000120_1601f378+0xe2>
  409473:	cmp    ebx,0x3
  409476:	je     409484 <__swc_fn_ff58629f_000120_1601f378+0xa4>
  409478:	cmp    ebx,0x4
  40947b:	je     409494 <__swc_fn_ff58629f_000120_1601f378+0xb4>
  40947d:	cmp    ebx,0x5
  409480:	je     4094a4 <__swc_fn_ff58629f_000120_1601f378+0xc4>
  409482:	jmp    4094b4 <__swc_fn_ff58629f_000120_1601f378+0xd4>
  409484:	vmovups xmm0,XMMWORD PTR [rip+0x9054]        # 4124e0 <__swc_rdata_base_ff58629f+0x3d0>
  40948c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409492:	jmp    4094c2 <__swc_fn_ff58629f_000120_1601f378+0xe2>
  409494:	vmovups xmm0,XMMWORD PTR [rip+0x9054]        # 4124f0 <__swc_rdata_base_ff58629f+0x3e0>
  40949c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094a2:	jmp    4094c2 <__swc_fn_ff58629f_000120_1601f378+0xe2>
  4094a4:	vmovups xmm0,XMMWORD PTR [rip+0x9054]        # 412500 <__swc_rdata_base_ff58629f+0x3f0>
  4094ac:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094b2:	jmp    4094c2 <__swc_fn_ff58629f_000120_1601f378+0xe2>
  4094b4:	vmovups xmm0,XMMWORD PTR [rip+0x9054]        # 412510 <__swc_rdata_base_ff58629f+0x400>
  4094bc:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094c2:	lea    rcx,[rsp+0x8]
  4094c7:	mov    rdx,rdi
  4094ca:	call   40c3a0 <__swc_fn_ff58629f_000103_2ed36338>
  4094cf:	vmovups xmm0,XMMWORD PTR [rdi]
  4094d3:	vmovups XMMWORD PTR [r12+0x940],xmm0
  4094dd:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  4094e2:	vmovups XMMWORD PTR [r12+0x950],xmm0
  4094ec:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  4094f1:	vmovups XMMWORD PTR [r12+0x960],xmm0
  4094fb:	lea    rax,[r12+0x940]
  409503:	mov    QWORD PTR [r12+0x970],rax
  40950b:	mov    rax,QWORD PTR [rsi]
  40950e:	mov    QWORD PTR [r12+0x978],rax
  409516:	mov    rax,QWORD PTR [rsi+0x8]
  40951a:	mov    QWORD PTR [r12+0x980],rax
  409522:	movsxd rax,ebx
  409525:	mov    QWORD PTR [r12+0x988],rax
  40952d:	cmp    ebx,0x5
  409530:	je     409539 <__swc_fn_ff58629f_000120_1601f378+0x159>
  409532:	xor    ecx,ecx
  409534:	call   40a2d0 <__swc_fn_ff58629f_000174_738eec22>
  409539:	mov    rbx,QWORD PTR [r12+0xbe8]
  409541:	test   rbx,rbx
  409544:	je     409555 <__swc_fn_ff58629f_000120_1601f378+0x175>
  409546:	mov    rcx,r12
  409549:	call   rbx
  40954b:	add    rsp,0x18
  40954f:	pop    r12
  409551:	pop    rdi
  409552:	pop    rsi
  409553:	pop    rbx
  409554:	ret
  409555:	mov    rcx,rsi
  409558:	call   40fad0 <__swc_fn_ff58629f_000116_3499f7d6>
  40955d:	call   40c9d0 <__swc_fn_ff58629f_000118_2b35b5e0>
  409562:	add    rsp,0x18
  409566:	pop    r12
  409568:	pop    rdi
  409569:	pop    rsi
  40956a:	pop    rbx
  40956b:	ret
  40956c:	mov    rcx,rsi
  40956f:	mov    rdx,rdi
  409572:	call   40c3a0 <__swc_fn_ff58629f_000103_2ed36338>
  409577:	jmp    40942f <__swc_fn_ff58629f_000120_1601f378+0x4f>
  40957c:	add    BYTE PTR [rax],al
	...

0000000000409580 <__swc_fn_ff58629f_000123_e9227a3e>:
  409580:	push   rdi
  409581:	push   rsi
  409582:	sub    rsp,0xb8
  409589:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40958f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409595:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40959b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4095a1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4095a7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4095ad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4095b3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4095bc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4095c5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4095ce:	mov    DWORD PTR [rsp+0x8],0x0
  4095d6:	lea    rdi,[rsp+0x8]
  4095db:	xor    esi,esi
  4095dd:	xor    eax,eax
  4095df:	call   407050 <pthread_key_create@plt>
  4095e4:	test   eax,eax
  4095e6:	jne    4095ee <__swc_fn_ff58629f_000123_e9227a3e+0x6e>
  4095e8:	mov    eax,DWORD PTR [rsp+0x8]
  4095ec:	jmp    4095f5 <__swc_fn_ff58629f_000123_e9227a3e+0x75>
  4095ee:	mov    rax,0xffffffffffffffff
  4095f5:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4095fb:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409601:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409607:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40960d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409613:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409619:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40961f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409628:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409631:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40963a:	add    rsp,0xb8
  409641:	pop    rsi
  409642:	pop    rdi
  409643:	ret
	...

0000000000409650 <__swc_fn_ff58629f_000126_5fb20c72>:
  409650:	push   rdi
  409651:	push   rsi
  409652:	sub    rsp,0xb8
  409659:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40965f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409665:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40966b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409671:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409677:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40967d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409683:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40968c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409695:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40969e:	mov    DWORD PTR [rsp+0x8],0x0
  4096a6:	lea    rdi,[rsp+0x8]
  4096ab:	mov    rsi,rcx
  4096ae:	xor    eax,eax
  4096b0:	call   407050 <pthread_key_create@plt>
  4096b5:	test   eax,eax
  4096b7:	jne    4096c2 <__swc_fn_ff58629f_000126_5fb20c72+0x72>
  4096b9:	mov    eax,DWORD PTR [rsp+0x8]
  4096bd:	inc    rax
  4096c0:	jmp    4096c4 <__swc_fn_ff58629f_000126_5fb20c72+0x74>
  4096c2:	xor    eax,eax
  4096c4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4096ca:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4096d0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4096d6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4096dc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4096e2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4096e8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4096ee:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4096f7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409700:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409709:	add    rsp,0xb8
  409710:	pop    rsi
  409711:	pop    rdi
  409712:	ret
	...

0000000000409720 <__swc_fn_ff58629f_000129_0672cd48>:
  409720:	push   rdi
  409721:	push   rsi
  409722:	sub    rsp,0xa8
  409729:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40972f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409735:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40973b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409741:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409747:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40974d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409753:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409759:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409762:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40976b:	test   rcx,rcx
  40976e:	setne  al
  409771:	je     40978a <__swc_fn_ff58629f_000129_0672cd48+0x6a>
  409773:	lea    rax,[rcx-0x1]
  409777:	mov    eax,eax
  409779:	mov    edi,eax
  40977b:	mov    rsi,rdx
  40977e:	xor    eax,eax
  409780:	call   407060 <pthread_setspecific@plt>
  409785:	test   eax,eax
  409787:	sete   al
  40978a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409790:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409796:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40979c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4097a2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4097a8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4097ae:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4097b4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4097ba:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4097c3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4097cc:	add    rsp,0xa8
  4097d3:	pop    rsi
  4097d4:	pop    rdi
  4097d5:	ret
	...

00000000004097e0 <__swc_fn_ff58629f_000132_2b60f756>:
  4097e0:	push   rdi
  4097e1:	push   rsi
  4097e2:	sub    rsp,0xa8
  4097e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4097ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4097f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4097fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409801:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409807:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40980d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409813:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409819:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409822:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40982b:	mov    rax,rdx
  40982e:	mov    QWORD PTR [rsp],0x0
  409836:	mov    edi,0xca
  40983b:	mov    rsi,rcx
  40983e:	mov    edx,0x81
  409843:	mov    eax,eax
  409845:	mov    ecx,eax
  409847:	xor    r8d,r8d
  40984a:	xor    r9d,r9d
  40984d:	xor    eax,eax
  40984f:	call   407070 <syscall@plt>
  409854:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40985a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409860:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409866:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40986c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409872:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409878:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40987e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409884:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40988d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409896:	add    rsp,0xa8
  40989d:	pop    rsi
  40989e:	pop    rdi
  40989f:	ret

00000000004098a0 <__swc_fn_ff58629f_000135_1fec60ac>:
  4098a0:	sub    rsp,0x8
  4098a4:	call   40cd70 <__swc_fn_ff58629f_000133_c6de0049>
  4098a9:	add    rsp,0x8
  4098ad:	ret
	...

00000000004098b0 <__swc_fn_ff58629f_000138_2214b637>:
  4098b0:	push   rdi
  4098b1:	push   rsi
  4098b2:	sub    rsp,0xc8
  4098b9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4098bf:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4098c5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4098cb:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4098d1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4098d7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4098dd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  4098e6:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  4098ef:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  4098f8:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  409901:	vxorps xmm0,xmm0,xmm0
  409905:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40990b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409911:	mov    rdi,rcx
  409914:	lea    rsi,[rsp+0x8]
  409919:	xor    eax,eax
  40991b:	call   407080 <dladdr@plt>
  409920:	xor    ecx,ecx
  409922:	test   eax,eax
  409924:	je     40992b <__swc_fn_ff58629f_000138_2214b637+0x7b>
  409926:	mov    rcx,QWORD PTR [rsp+0x10]
  40992b:	mov    rax,rcx
  40992e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  409934:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40993a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  409940:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  409946:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40994c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  409952:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40995b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  409964:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40996d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  409976:	add    rsp,0xc8
  40997d:	pop    rsi
  40997e:	pop    rdi
  40997f:	ret

0000000000409980 <__swc_fn_ff58629f_000141_376d5f6d>:
  409980:	push   rbx
  409981:	push   r12
  409983:	push   r13
  409985:	push   rdi
  409986:	push   rsi
  409987:	push   r14
  409989:	push   r15
  40998b:	sub    rsp,0x150
  409992:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40999b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  4099a4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  4099ad:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  4099b6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  4099bf:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4099c8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4099d1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4099da:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  4099e3:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  4099ec:	mov    rbx,rdx
  4099ef:	mov    QWORD PTR [rsp+0x98],rdx
  4099f7:	mov    r12,rcx
  4099fa:	mov    QWORD PTR [rsp+0xa0],rcx
  409a02:	mov    QWORD PTR [rbx],0x0
  409a09:	lea    r13,[rip+0x1c370]        # 425d80 <__swc_bss_base_ff58629f+0x2d40>
  409a10:	mov    rcx,r13
  409a13:	call   4098a0 <__swc_fn_ff58629f_000135_1fec60ac>
  409a18:	mov    rax,QWORD PTR [rip+0x1c369]        # 425d88 <__swc_bss_base_ff58629f+0x2d48>
  409a1f:	test   rax,rax
  409a22:	je     409a59 <__swc_fn_ff58629f_000141_376d5f6d+0xd9>
  409a24:	cs nop WORD PTR [rax+rax*1+0x0]
  409a2e:	xchg   ax,ax
  409a30:	cmp    QWORD PTR [rax+0x8],r12
  409a34:	jne    409a51 <__swc_fn_ff58629f_000141_376d5f6d+0xd1>
  409a36:	mov    rcx,QWORD PTR [rax+0x18]
  409a3a:	mov    QWORD PTR [rbx],rcx
  409a3d:	mov    rbx,QWORD PTR [rax+0x10]
  409a41:	mov    rcx,r13
  409a44:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  409a49:	mov    rax,rbx
  409a4c:	jmp    409c3b <__swc_fn_ff58629f_000141_376d5f6d+0x2bb>
  409a51:	mov    rax,QWORD PTR [rax]
  409a54:	test   rax,rax
  409a57:	jne    409a30 <__swc_fn_ff58629f_000141_376d5f6d+0xb0>
  409a59:	vxorps xmm0,xmm0,xmm0
  409a5d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  409a63:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  409a69:	mov    rdi,r12
  409a6c:	lea    rsi,[rsp+0x10]
  409a71:	xor    eax,eax
  409a73:	call   407080 <dladdr@plt>
  409a78:	test   eax,eax
  409a7a:	sete   al
  409a7d:	je     409a8a <__swc_fn_ff58629f_000141_376d5f6d+0x10a>
  409a7f:	mov    rax,QWORD PTR [rsp+0x10]
  409a84:	test   rax,rax
  409a87:	sete   al
  409a8a:	test   al,al
  409a8c:	je     409a9d <__swc_fn_ff58629f_000141_376d5f6d+0x11d>
  409a8e:	mov    rcx,r13
  409a91:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  409a96:	xor    eax,eax
  409a98:	jmp    409c3b <__swc_fn_ff58629f_000141_376d5f6d+0x2bb>
  409a9d:	mov    rdi,QWORD PTR [rsp+0x10]
  409aa2:	mov    esi,0x80000
  409aa7:	xor    eax,eax
  409aa9:	call   407090 <open@plt>
  409aae:	lea    r14,[rsp+0x30]
  409ab3:	mov    DWORD PTR [rsp+0x30],eax
  409ab7:	cmp    DWORD PTR [r14],0x0
  409abb:	jge    409acc <__swc_fn_ff58629f_000141_376d5f6d+0x14c>
  409abd:	mov    rcx,r13
  409ac0:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  409ac5:	xor    eax,eax
  409ac7:	jmp    409c3b <__swc_fn_ff58629f_000141_376d5f6d+0x2bb>
  409acc:	mov    rax,r14
  409acf:	movsxd rdi,DWORD PTR [rax]
  409ad2:	xor    esi,esi
  409ad4:	mov    edx,0x2
  409ad9:	xor    eax,eax
  409adb:	call   4070a0 <lseek@plt>
  409ae0:	mov    r15,rax
  409ae3:	test   rax,rax
  409ae6:	jg     409b01 <__swc_fn_ff58629f_000141_376d5f6d+0x181>
  409ae8:	movsxd rdi,DWORD PTR [r14]
  409aeb:	xor    eax,eax
  409aed:	call   4070b0 <close@plt>
  409af2:	mov    rcx,r13
  409af5:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  409afa:	xor    eax,eax
  409afc:	jmp    409c3b <__swc_fn_ff58629f_000141_376d5f6d+0x2bb>
  409b01:	xor    edi,edi
  409b03:	mov    rsi,r15
  409b06:	mov    edx,0x1
  409b0b:	mov    ecx,0x2
  409b10:	mov    rax,r14
  409b13:	movsxd r8,DWORD PTR [rax]
  409b16:	xor    r9d,r9d
  409b19:	xor    eax,eax
  409b1b:	call   4070c0 <mmap@plt>
  409b20:	mov    rbx,rax
  409b23:	test   rax,rax
  409b26:	sete   al
  409b29:	cmp    rbx,0xffffffffffffffff
  409b2d:	sete   cl
  409b30:	or     al,cl
  409b32:	je     409b4d <__swc_fn_ff58629f_000141_376d5f6d+0x1cd>
  409b34:	movsxd rdi,DWORD PTR [r14]
  409b37:	xor    eax,eax
  409b39:	call   4070b0 <close@plt>
  409b3e:	mov    rcx,r13
  409b41:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  409b46:	xor    eax,eax
  409b48:	jmp    409c3b <__swc_fn_ff58629f_000141_376d5f6d+0x2bb>
  409b4d:	lea    rax,[rsp+0x50]
  409b52:	mov    QWORD PTR [rax],0x0
  409b59:	mov    rcx,rbx
  409b5c:	mov    rdx,r15
  409b5f:	mov    r8,rax
  409b62:	call   410060 <__swc_fn_ff58629f_000140_81b740ca>
  409b67:	mov    r12,rax
  409b6a:	test   rax,rax
  409b6d:	jne    409b95 <__swc_fn_ff58629f_000141_376d5f6d+0x215>
  409b6f:	mov    rdi,rbx
  409b72:	mov    rsi,r15
  409b75:	xor    eax,eax
  409b77:	call   407020 <munmap@plt>
  409b7c:	movsxd rdi,DWORD PTR [r14]
  409b7f:	xor    eax,eax
  409b81:	call   4070b0 <close@plt>
  409b86:	mov    rcx,r13
  409b89:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  409b8e:	xor    eax,eax
  409b90:	jmp    409c3b <__swc_fn_ff58629f_000141_376d5f6d+0x2bb>
  409b95:	mov    edi,0x20
  409b9a:	xor    eax,eax
  409b9c:	call   4070d0 <malloc@plt>
  409ba1:	test   rax,rax
  409ba4:	jne    409bc9 <__swc_fn_ff58629f_000141_376d5f6d+0x249>
  409ba6:	mov    rdi,rbx
  409ba9:	mov    rsi,r15
  409bac:	xor    eax,eax
  409bae:	call   407020 <munmap@plt>
  409bb3:	movsxd rdi,DWORD PTR [r14]
  409bb6:	xor    eax,eax
  409bb8:	call   4070b0 <close@plt>
  409bbd:	mov    rcx,r13
  409bc0:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  409bc5:	xor    eax,eax
  409bc7:	jmp    409c3b <__swc_fn_ff58629f_000141_376d5f6d+0x2bb>
  409bc9:	mov    rcx,QWORD PTR [rip+0x1c1b8]        # 425d88 <__swc_bss_base_ff58629f+0x2d48>
  409bd0:	mov    QWORD PTR [rsp+0x70],rcx
  409bd5:	mov    rcx,QWORD PTR [rsp+0xa0]
  409bdd:	mov    QWORD PTR [rsp+0x78],rcx
  409be2:	mov    QWORD PTR [rsp+0x80],r12
  409bea:	mov    rcx,QWORD PTR [rsp+0x50]
  409bef:	mov    QWORD PTR [rsp+0x88],rcx
  409bf7:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  409bfd:	vmovups XMMWORD PTR [rax],xmm0
  409c01:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  409c0a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  409c0f:	mov    QWORD PTR [rip+0x1c172],rax        # 425d88 <__swc_bss_base_ff58629f+0x2d48>
  409c16:	mov    rax,QWORD PTR [rsp+0x50]
  409c1b:	mov    rbx,QWORD PTR [rsp+0x98]
  409c23:	mov    QWORD PTR [rbx],rax
  409c26:	movsxd rdi,DWORD PTR [r14]
  409c29:	xor    eax,eax
  409c2b:	call   4070b0 <close@plt>
  409c30:	mov    rcx,r13
  409c33:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  409c38:	mov    rax,r12
  409c3b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  409c44:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  409c4d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  409c56:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  409c5f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  409c68:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  409c71:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  409c7a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  409c83:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  409c8c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  409c95:	add    rsp,0x150
  409c9c:	pop    r15
  409c9e:	pop    r14
  409ca0:	pop    rsi
  409ca1:	pop    rdi
  409ca2:	pop    r13
  409ca4:	pop    r12
  409ca6:	pop    rbx
  409ca7:	ret
	...

0000000000409cb0 <__swc_fn_ff58629f_000144_364559f5>:
  409cb0:	push   rbx
  409cb1:	sub    rsp,0xe0
  409cb8:	lea    rbx,[rsp+0x8]
  409cbd:	vxorps xmm0,xmm0,xmm0
  409cc1:	vmovups YMMWORD PTR [rbx],ymm0
  409cc5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  409cca:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  409ccf:	vzeroupper
  409cd2:	mov    DWORD PTR [rbx+0x60],0x0
  409cd9:	mov    r8,rbx
  409cdc:	nop    DWORD PTR [rax+0x0]
  409ce0:	mov    r9,rcx
  409ce3:	movabs rcx,0xcccccccccccccccd
  409ced:	mov    rax,r9
  409cf0:	mul    rcx
  409cf3:	mov    r10,rdx
  409cf6:	shr    r10,0x3
  409cfa:	mov    rcx,r10
  409cfd:	imul   rdx,r10,0xa
  409d01:	sub    r9,rdx
  409d04:	mov    rdx,QWORD PTR [rip+0x8835]        # 412540 <__swc_rdata_base_ff58629f+0x430>
  409d0b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  409d10:	mov    BYTE PTR [r8],dl
  409d13:	lea    rdx,[r8+0x1]
  409d17:	mov    r8,rdx
  409d1a:	test   r10,r10
  409d1d:	jne    409ce0 <__swc_fn_ff58629f_000144_364559f5+0x30>
  409d1f:	mov    BYTE PTR [rdx],0x0
  409d22:	sub    r8,0x1
  409d26:	mov    rax,rbx
  409d29:	cmp    rax,r8
  409d2c:	jae    409d46 <__swc_fn_ff58629f_000144_364559f5+0x96>
  409d2e:	xchg   ax,ax
  409d30:	mov    cl,BYTE PTR [r8]
  409d33:	mov    dl,BYTE PTR [rax]
  409d35:	mov    BYTE PTR [r8],dl
  409d38:	sub    r8,0x1
  409d3c:	mov    BYTE PTR [rax],cl
  409d3e:	inc    rax
  409d41:	cmp    rax,r8
  409d44:	jb     409d30 <__swc_fn_ff58629f_000144_364559f5+0x80>
  409d46:	xor    eax,eax
  409d48:	test   rbx,rbx
  409d4b:	je     409d6e <__swc_fn_ff58629f_000144_364559f5+0xbe>
  409d4d:	mov    rcx,rbx
  409d50:	mov    dl,BYTE PTR [rcx]
  409d52:	test   dl,dl
  409d54:	je     409d6e <__swc_fn_ff58629f_000144_364559f5+0xbe>
  409d56:	cs nop WORD PTR [rax+rax*1+0x0]
  409d60:	add    rcx,0x1
  409d64:	add    rax,0x1
  409d68:	mov    dl,BYTE PTR [rcx]
  409d6a:	test   dl,dl
  409d6c:	jne    409d60 <__swc_fn_ff58629f_000144_364559f5+0xb0>
  409d6e:	mov    QWORD PTR [rbx+0xa8],rbx
  409d75:	mov    QWORD PTR [rbx+0xb0],rax
  409d7c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  409d84:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  409d8c:	lea    rcx,[rbx+0xb8]
  409d93:	call   40fad0 <__swc_fn_ff58629f_000116_3499f7d6>
  409d98:	add    rsp,0xe0
  409d9f:	pop    rbx
  409da0:	ret
	...

0000000000409db0 <__swc_fn_ff58629f_000147_c9c6528e>:
  409db0:	sub    rsp,0x8
  409db4:	mov    rax,QWORD PTR [rcx+0x8]
  409db8:	mov    r8,QWORD PTR [rdx+0x8]
  409dbc:	cmp    rax,r8
  409dbf:	je     409dc8 <__swc_fn_ff58629f_000147_c9c6528e+0x18>
  409dc1:	xor    eax,eax
  409dc3:	add    rsp,0x8
  409dc7:	ret
  409dc8:	test   rax,rax
  409dcb:	jne    409ddc <__swc_fn_ff58629f_000147_c9c6528e+0x2c>
  409dcd:	test   r8,r8
  409dd0:	jne    409ddc <__swc_fn_ff58629f_000147_c9c6528e+0x2c>
  409dd2:	mov    eax,0x1
  409dd7:	add    rsp,0x8
  409ddb:	ret
  409ddc:	mov    rcx,QWORD PTR [rcx]
  409ddf:	mov    rdx,QWORD PTR [rdx]
  409de2:	test   rcx,rcx
  409de5:	sete   r8b
  409de9:	test   rdx,rdx
  409dec:	sete   r9b
  409df0:	or     r8b,r9b
  409df3:	je     409e00 <__swc_fn_ff58629f_000147_c9c6528e+0x50>
  409df5:	cmp    rcx,rdx
  409df8:	sete   al
  409dfb:	add    rsp,0x8
  409dff:	ret
  409e00:	cmp    rcx,rdx
  409e03:	jne    409e0f <__swc_fn_ff58629f_000147_c9c6528e+0x5f>
  409e05:	mov    eax,0x1
  409e0a:	add    rsp,0x8
  409e0e:	ret
  409e0f:	mov    r8,rax
  409e12:	call   40c460 <__swc_fn_ff58629f_000106_77a5d54a>
  409e17:	test   eax,eax
  409e19:	sete   al
  409e1c:	add    rsp,0x8
  409e20:	ret
	...

0000000000409e30 <__swc_fn_ff58629f_000150_33e5e24f>:
  409e30:	vxorps xmm0,xmm0,xmm0
  409e34:	vmovups XMMWORD PTR [rcx],xmm0
  409e38:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e3d:	vxorps xmm0,xmm0,xmm0
  409e41:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e46:	vmovups xmm0,XMMWORD PTR [rip+0x87aa]        # 4125f8 <__swc_rdata_base_ff58629f+0x4e8>
  409e4e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e53:	ret
	...

0000000000409e60 <__swc_fn_ff58629f_000153_33e5e24f>:
  409e60:	vxorps xmm0,xmm0,xmm0
  409e64:	vmovups XMMWORD PTR [rcx],xmm0
  409e68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e6d:	vxorps xmm0,xmm0,xmm0
  409e71:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e76:	vmovups xmm0,XMMWORD PTR [rip+0x889a]        # 412718 <__swc_rdata_base_ff58629f+0x608>
  409e7e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e83:	mov    QWORD PTR [rcx+0x40],0x0
  409e8b:	ret
  409e8c:	add    BYTE PTR [rax],al
	...

0000000000409e90 <__swc_fn_ff58629f_000156_312df05a>:
  409e90:	push   rbx
  409e91:	sub    rsp,0x70
  409e95:	mov    rax,QWORD PTR [rcx]
  409e98:	mov    rbx,QWORD PTR [rcx+0x8]
  409e9c:	vxorps xmm0,xmm0,xmm0
  409ea0:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  409ea6:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  409eac:	vzeroupper
  409eaf:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  409eb5:	mov    QWORD PTR [rsp+0x48],rdx
  409eba:	mov    QWORD PTR [rsp+0x50],r8
  409ebf:	mov    rcx,rax
  409ec2:	lea    rdx,[rsp+0x8]
  409ec7:	mov    rbx,QWORD PTR [rbx+0x18]
  409ecb:	call   rbx
  409ecd:	add    rsp,0x70
  409ed1:	pop    rbx
  409ed2:	ret
	...

0000000000409ee0 <__swc_fn_ff58629f_000159_9d602c76>:
  409ee0:	push   rbx
  409ee1:	push   rsi
  409ee2:	push   rdi
  409ee3:	mov    rbx,r8
  409ee6:	mov    rsi,rcx
  409ee9:	mov    rdi,rdx
  409eec:	call   40d170 <__swc_fn_ff58629f_000157_5c8b11d8>
  409ef1:	vmovups xmm0,XMMWORD PTR [rbx]
  409ef5:	vmovups XMMWORD PTR [rsi],xmm0
  409ef9:	mov    QWORD PTR [rsi+0x18],rdi
  409efd:	pop    rdi
  409efe:	pop    rsi
  409eff:	pop    rbx
  409f00:	ret
	...

0000000000409f10 <__swc_fn_ff58629f_000162_edb9cf73>:
  409f10:	push   rbx
  409f11:	push   rsi
  409f12:	push   rdi
  409f13:	push   r12
  409f15:	push   r13
  409f17:	sub    rsp,0x50
  409f1b:	mov    rbx,rcx
  409f1e:	mov    rsi,rdx
  409f21:	vmovups xmm0,XMMWORD PTR [rip+0x88ff]        # 412828 <__swc_rdata_base_ff58629f+0x718>
  409f29:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409f2f:	vmovups xmm0,XMMWORD PTR [rip+0x8901]        # 412838 <__swc_rdata_base_ff58629f+0x728>
  409f37:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409f3d:	vxorps xmm0,xmm0,xmm0
  409f41:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409f47:	mov    rcx,rdx
  409f4a:	call   4098b0 <__swc_fn_ff58629f_000138_2214b637>
  409f4f:	mov    rdi,rax
  409f52:	test   rax,rax
  409f55:	jne    409f86 <__swc_fn_ff58629f_000162_edb9cf73+0x76>
  409f57:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409f5d:	vmovups XMMWORD PTR [rbx],xmm0
  409f61:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409f67:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409f6c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409f72:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409f77:	mov    rax,rbx
  409f7a:	add    rsp,0x50
  409f7e:	pop    r13
  409f80:	pop    r12
  409f82:	pop    rdi
  409f83:	pop    rsi
  409f84:	pop    rbx
  409f85:	ret
  409f86:	mov    rcx,rdi
  409f89:	call   411580 <__swc_fn_ff58629f_000161_9e36e814>
  409f8e:	mov    r11,rax
  409f91:	test   rax,rax
  409f94:	je     409f9e <__swc_fn_ff58629f_000162_edb9cf73+0x8e>
  409f96:	mov    al,BYTE PTR [r11+0x24]
  409f9a:	test   al,al
  409f9c:	jne    409fcd <__swc_fn_ff58629f_000162_edb9cf73+0xbd>
  409f9e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fa4:	vmovups XMMWORD PTR [rbx],xmm0
  409fa8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fae:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fb3:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fb9:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fbe:	mov    rax,rbx
  409fc1:	add    rsp,0x50
  409fc5:	pop    r13
  409fc7:	pop    r12
  409fc9:	pop    rdi
  409fca:	pop    rsi
  409fcb:	pop    rbx
  409fcc:	ret
  409fcd:	sub    rsi,rdi
  409fd0:	mov    eax,0xffffffff
  409fd5:	cmp    rsi,rax
  409fd8:	jbe    40a009 <__swc_fn_ff58629f_000162_edb9cf73+0xf9>
  409fda:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fe0:	vmovups XMMWORD PTR [rbx],xmm0
  409fe4:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fea:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fef:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409ff5:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409ffa:	mov    rax,rbx
  409ffd:	add    rsp,0x50
  40a001:	pop    r13
  40a003:	pop    r12
  40a005:	pop    rdi
  40a006:	pop    rsi
  40a007:	pop    rbx
  40a008:	ret
  40a009:	mov    rdi,QWORD PTR [r11+0x10]
  40a00d:	mov    eax,DWORD PTR [r11+0x20]
  40a011:	xor    ecx,ecx
  40a013:	test   rax,rax
  40a016:	jbe    40a168 <__swc_fn_ff58629f_000162_edb9cf73+0x258>
  40a01c:	nop    DWORD PTR [rax+0x0]
  40a020:	mov    edx,ecx
  40a022:	imul   r12,rdx,0x14
  40a026:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40a02b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40a030:	mov    r9d,esi
  40a033:	cmp    r9,rdx
  40a036:	jb     40a15b <__swc_fn_ff58629f_000162_edb9cf73+0x24b>
  40a03c:	add    rdx,r8
  40a03f:	mov    r8d,esi
  40a042:	cmp    r8,rdx
  40a045:	jae    40a15b <__swc_fn_ff58629f_000162_edb9cf73+0x24b>
  40a04b:	lea    rsi,[rsp+0x38]
  40a050:	mov    eax,DWORD PTR [rdi+0xc]
  40a053:	mov    DWORD PTR [rsp+0x38],eax
  40a057:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40a05c:	mov    rcx,rdi
  40a05f:	mov    rdx,QWORD PTR [r11+0x18]
  40a063:	mov    r8,rsi
  40a066:	mov    r8d,DWORD PTR [r8]
  40a069:	mov    r9,rax
  40a06c:	lea    r10,[rsp+0x10]
  40a071:	call   40d1c0 <__swc_fn_ff58629f_000160_e25d06b9>
  40a076:	test   al,al
  40a078:	jne    40a0ab <__swc_fn_ff58629f_000162_edb9cf73+0x19b>
  40a07a:	vmovups xmm0,XMMWORD PTR [rip+0x87d6]        # 412858 <__swc_rdata_base_ff58629f+0x748>
  40a082:	vmovups XMMWORD PTR [rbx],xmm0
  40a086:	vmovups xmm0,XMMWORD PTR [rip+0x87da]        # 412868 <__swc_rdata_base_ff58629f+0x758>
  40a08e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a093:	vxorps xmm0,xmm0,xmm0
  40a097:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a09c:	mov    rax,rbx
  40a09f:	add    rsp,0x50
  40a0a3:	pop    r13
  40a0a5:	pop    r12
  40a0a7:	pop    rdi
  40a0a8:	pop    rsi
  40a0a9:	pop    rbx
  40a0aa:	ret
  40a0ab:	lea    r13,[rsp+0x3c]
  40a0b0:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40a0b5:	mov    DWORD PTR [rsp+0x3c],eax
  40a0b9:	test   eax,eax
  40a0bb:	je     40a10c <__swc_fn_ff58629f_000162_edb9cf73+0x1fc>
  40a0bd:	mov    rcx,rdi
  40a0c0:	mov    rdx,QWORD PTR [r11+0x18]
  40a0c4:	mov    r8d,DWORD PTR [rsi]
  40a0c7:	mov    rax,r13
  40a0ca:	mov    r9d,DWORD PTR [rax]
  40a0cd:	lea    r10,[rsp+0x20]
  40a0d2:	call   40d1c0 <__swc_fn_ff58629f_000160_e25d06b9>
  40a0d7:	test   al,al
  40a0d9:	jne    40a10c <__swc_fn_ff58629f_000162_edb9cf73+0x1fc>
  40a0db:	vmovups xmm0,XMMWORD PTR [rip+0x87a5]        # 412888 <__swc_rdata_base_ff58629f+0x778>
  40a0e3:	vmovups XMMWORD PTR [rbx],xmm0
  40a0e7:	vmovups xmm0,XMMWORD PTR [rip+0x87a9]        # 412898 <__swc_rdata_base_ff58629f+0x788>
  40a0ef:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a0f4:	vxorps xmm0,xmm0,xmm0
  40a0f8:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a0fd:	mov    rax,rbx
  40a100:	add    rsp,0x50
  40a104:	pop    r13
  40a106:	pop    r12
  40a108:	pop    rdi
  40a109:	pop    rsi
  40a10a:	pop    rbx
  40a10b:	ret
  40a10c:	mov    eax,0x1
  40a111:	rex mov BYTE PTR [rsp+0x8],al
  40a116:	cmp    DWORD PTR [r13+0x0],0x0
  40a11b:	je     40a12c <__swc_fn_ff58629f_000162_edb9cf73+0x21c>
  40a11d:	rex mov BYTE PTR [rsp+0x9],0x1
  40a123:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40a128:	mov    DWORD PTR [rsp+0x30],eax
  40a12c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a132:	vmovups XMMWORD PTR [rbx],xmm0
  40a136:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a13c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a141:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a147:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a14c:	mov    rax,rbx
  40a14f:	add    rsp,0x50
  40a153:	pop    r13
  40a155:	pop    r12
  40a157:	pop    rdi
  40a158:	pop    rsi
  40a159:	pop    rbx
  40a15a:	ret
  40a15b:	add    rcx,0x1
  40a15f:	cmp    rcx,rax
  40a162:	jb     40a020 <__swc_fn_ff58629f_000162_edb9cf73+0x110>
  40a168:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a16e:	vmovups XMMWORD PTR [rbx],xmm0
  40a172:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a178:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a17d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a183:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a188:	mov    rax,rbx
  40a18b:	add    rsp,0x50
  40a18f:	pop    r13
  40a191:	pop    r12
  40a193:	pop    rdi
  40a194:	pop    rsi
  40a195:	pop    rbx
  40a196:	ret
	...

000000000040a1a0 <__swc_fn_ff58629f_000165_e09accff>:
  40a1a0:	sub    rsp,0x48
  40a1a4:	call   409580 <__swc_fn_ff58629f_000123_e9227a3e>
  40a1a9:	cmp    rax,0xffffffffffffffff
  40a1ad:	je     40a1b4 <__swc_fn_ff58629f_000165_e09accff+0x14>
  40a1af:	add    rsp,0x48
  40a1b3:	ret
  40a1b4:	lea    rcx,[rip+0x870d]        # 4128c8 <__swc_rdata_base_ff58629f+0x7b8>
  40a1bb:	vmovups xmm0,XMMWORD PTR [rip+0x8715]        # 4128d8 <__swc_rdata_base_ff58629f+0x7c8>
  40a1c3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a1c9:	vmovups xmm0,XMMWORD PTR [rip+0x8717]        # 4128e8 <__swc_rdata_base_ff58629f+0x7d8>
  40a1d1:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a1d7:	vmovups xmm0,XMMWORD PTR [rip+0x8719]        # 4128f8 <__swc_rdata_base_ff58629f+0x7e8>
  40a1df:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a1e5:	lea    rdx,[rsp+0x8]
  40a1ea:	mov    QWORD PTR [rsp+0x38],rax
  40a1ef:	call   40c3a0 <__swc_fn_ff58629f_000103_2ed36338>
  40a1f4:	mov    rax,QWORD PTR [rsp+0x38]
  40a1f9:	jmp    40a1af <__swc_fn_ff58629f_000165_e09accff+0xf>
  40a1fb:	add    BYTE PTR [rax],al
  40a1fd:	add    BYTE PTR [rax],al
	...

000000000040a200 <__swc_fn_ff58629f_000168_0ff0458f>:
  40a200:	push   rbx
  40a201:	push   rsi
  40a202:	sub    rsp,0x28
  40a206:	mov    rbx,rcx
  40a209:	mov    DWORD PTR [rsp+0x8],0xbf0
  40a211:	mov    ecx,0xbf0
  40a216:	call   40bf90 <__swc_fn_ff58629f_000079_29fad089>
  40a21b:	mov    rsi,rax
  40a21e:	test   rax,rax
  40a221:	jne    40a22c <__swc_fn_ff58629f_000168_0ff0458f+0x2c>
  40a223:	xor    eax,eax
  40a225:	add    rsp,0x28
  40a229:	pop    rsi
  40a22a:	pop    rbx
  40a22b:	ret
  40a22c:	vxorps xmm0,xmm0,xmm0
  40a230:	xor    eax,eax
  40a232:	cs nop WORD PTR [rax+rax*1+0x0]
  40a23c:	nop    DWORD PTR [rax+0x0]
  40a240:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40a245:	add    rax,0x10
  40a249:	cmp    rax,0xbf0
  40a250:	jne    40a240 <__swc_fn_ff58629f_000168_0ff0458f+0x40>
  40a252:	lea    rax,[rbx+0x1]
  40a256:	mov    QWORD PTR [rsi+0x9c0],rax
  40a25d:	mov    rcx,rbx
  40a260:	mov    rdx,rsi
  40a263:	call   40d520 <__swc_fn_ff58629f_000166_31ca4f53>
  40a268:	test   al,al
  40a26a:	jne    40a27d <__swc_fn_ff58629f_000168_0ff0458f+0x7d>
  40a26c:	mov    rcx,rsi
  40a26f:	call   40ea50 <__swc_fn_ff58629f_000080_851c599a>
  40a274:	xor    eax,eax
  40a276:	add    rsp,0x28
  40a27a:	pop    rsi
  40a27b:	pop    rbx
  40a27c:	ret
  40a27d:	lea    rcx,[rsp+0x18]
  40a282:	call   40efd0 <__swc_fn_ff58629f_000092_17e20532>
  40a287:	mov    rax,rsi
  40a28a:	add    rsp,0x28
  40a28e:	pop    rsi
  40a28f:	pop    rbx
  40a290:	ret
	...

000000000040a2a0 <__swc_fn_ff58629f_000171_06b64c88>:
  40a2a0:	xor    eax,eax
  40a2a2:	mov    edx,0x1
  40a2a7:	lock cmpxchg QWORD PTR [rcx],rdx
  40a2ac:	test   rax,rax
  40a2af:	jne    40a2b2 <__swc_fn_ff58629f_000171_06b64c88+0x12>
  40a2b1:	ret
  40a2b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2bc:	nop    DWORD PTR [rax+0x0]
  40a2c0:	mov    rax,QWORD PTR [rcx]
  40a2c3:	test   rax,rax
  40a2c6:	je     40a2a0 <__swc_fn_ff58629f_000171_06b64c88>
  40a2c8:	jmp    40a2c0 <__swc_fn_ff58629f_000171_06b64c88+0x20>
  40a2ca:	add    BYTE PTR [rax],al
  40a2cc:	add    BYTE PTR [rax],al
	...

000000000040a2d0 <__swc_fn_ff58629f_000174_738eec22>:
  40a2d0:	push   rsi
  40a2d1:	push   rdi
  40a2d2:	sub    rsp,0x38
  40a2d6:	mov    rsi,rcx
  40a2d9:	call   40d530 <__swc_fn_ff58629f_000169_aabbfb4c>
  40a2de:	mov    rdi,rax
  40a2e1:	call   40ccc0 <__swc_fn_ff58629f_000130_d2d78689>
  40a2e6:	mov    r8,rax
  40a2e9:	mov    rcx,rdi
  40a2ec:	call   40a2a0 <__swc_fn_ff58629f_000171_06b64c88>
  40a2f1:	mov    rax,QWORD PTR [rdi+0x8]
  40a2f5:	test   rax,rax
  40a2f8:	je     40a335 <__swc_fn_ff58629f_000174_738eec22+0x65>
  40a2fa:	nop    WORD PTR [rax+rax*1+0x0]
  40a300:	cmp    rax,rsi
  40a303:	je     40a335 <__swc_fn_ff58629f_000174_738eec22+0x65>
  40a305:	mov    r9,QWORD PTR [rax]
  40a308:	cmp    QWORD PTR [rax+0x20],r8
  40a30c:	jne    40a32d <__swc_fn_ff58629f_000174_738eec22+0x5d>
  40a30e:	mov    rcx,rdi
  40a311:	mov    rdx,rax
  40a314:	mov    QWORD PTR [rsp+0x28],r8
  40a319:	mov    QWORD PTR [rsp+0x30],r9
  40a31e:	call   4119a0 <__swc_fn_ff58629f_000173_156cb9fe>
  40a323:	mov    r8,QWORD PTR [rsp+0x28]
  40a328:	mov    r9,QWORD PTR [rsp+0x30]
  40a32d:	mov    rax,r9
  40a330:	test   r9,r9
  40a333:	jne    40a300 <__swc_fn_ff58629f_000174_738eec22+0x30>
  40a335:	xor    eax,eax
  40a337:	mov    QWORD PTR [rdi],rax
  40a33a:	add    rsp,0x38
  40a33e:	pop    rdi
  40a33f:	pop    rsi
  40a340:	ret
	...

000000000040a350 <__swc_fn_ff58629f_000177_1ca87929>:
  40a350:	push   rdi
  40a351:	push   rsi
  40a352:	sub    rsp,0xb8
  40a359:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40a35f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40a365:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40a36b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40a371:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40a377:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40a37d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40a383:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40a38c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40a395:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40a39e:	vxorps xmm0,xmm0,xmm0
  40a3a2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a3a8:	mov    edi,0x1
  40a3ad:	lea    rsi,[rsp+0x8]
  40a3b2:	xor    eax,eax
  40a3b4:	call   4070e0 <clock_gettime@plt>
  40a3b9:	vxorpd xmm0,xmm0,xmm0
  40a3bd:	mov    rax,QWORD PTR [rsp+0x8]
  40a3c2:	vcvtsi2sd xmm0,xmm0,rax
  40a3c7:	vxorpd xmm1,xmm1,xmm1
  40a3cb:	mov    rax,QWORD PTR [rsp+0x10]
  40a3d0:	vcvtsi2sd xmm1,xmm1,rax
  40a3d5:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x852b]        # 412908 <__swc_rdata_base_ff58629f+0x7f8>
  40a3dd:	vaddsd xmm0,xmm0,xmm1
  40a3e1:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40a3e7:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40a3ed:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40a3f3:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40a3f9:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40a3ff:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40a405:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40a40b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40a414:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40a41d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40a426:	add    rsp,0xb8
  40a42d:	pop    rsi
  40a42e:	pop    rdi
  40a42f:	ret
	...

000000000040a440 <__swc_fn_ff58629f_000001_29b04951>:
  40a440:	vxorps xmm0,xmm0,xmm0
  40a444:	xor    eax,eax
  40a446:	cs nop WORD PTR [rax+rax*1+0x0]
  40a450:	cs nop WORD PTR [rax+rax*1+0x0]
  40a45a:	nop    WORD PTR [rax+rax*1+0x0]
  40a460:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a465:	add    rax,0x10
  40a469:	cmp    rax,0x2080
  40a470:	jne    40a460 <__swc_fn_ff58629f_000001_29b04951+0x20>
  40a472:	ret
	...

000000000040a480 <__swc_fn_ff58629f_000004_2fa5c690>:
  40a480:	push   rsi
  40a481:	push   rdi
  40a482:	push   r12
  40a484:	push   r13
  40a486:	push   r14
  40a488:	mov    rsi,rcx
  40a48b:	mov    edi,r10d
  40a48e:	mov    r12,rcx
  40a491:	mov    r13,r9
  40a494:	mov    ecx,DWORD PTR [rdx+0x28]
  40a497:	shlx   r14d,r8d,ecx
  40a49c:	mov    rcx,rdx
  40a49f:	mov    edx,r8d
  40a4a2:	call   40d920 <__swc_fn_ff58629f_000011_e75d466d>
  40a4a7:	mov    rcx,rax
  40a4aa:	mov    eax,DWORD PTR [r12+0x3c]
  40a4af:	xor    edx,edx
  40a4b1:	div    rdi
  40a4b4:	vxorps xmm0,xmm0,xmm0
  40a4b8:	vmovdqu XMMWORD PTR [rsi],xmm0
  40a4bc:	mov    QWORD PTR [r12+0x60],0x0
  40a4c5:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40a4ca:	mov    QWORD PTR [r12+0x10],rcx
  40a4cf:	imul   rax,rdi
  40a4d3:	lea    rdx,[rcx+rax*1]
  40a4d7:	mov    QWORD PTR [r12+0x18],rdx
  40a4dc:	mov    QWORD PTR [r12+0x20],rcx
  40a4e1:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40a4e6:	mov    DWORD PTR [r12+0x28],0x0
  40a4ef:	mov    DWORD PTR [r12+0x68],0x0
  40a4f8:	mov    BYTE PTR [r12+0x39],r13b
  40a4fd:	mov    BYTE PTR [r12+0x3a],r14b
  40a502:	mov    BYTE PTR [r12+0x3b],0x1
  40a508:	mov    DWORD PTR [r12+0x6c],0x0
  40a511:	mov    rcx,r12
  40a514:	mov    edx,edi
  40a516:	call   40d880 <__swc_fn_ff58629f_000005_bcc5b80b>
  40a51b:	pop    r14
  40a51d:	pop    r13
  40a51f:	pop    r12
  40a521:	pop    rdi
  40a522:	pop    rsi
  40a523:	ret
	...

000000000040a530 <__swc_fn_ff58629f_000007_635028f3>:
  40a530:	mov    r8d,0x1
  40a536:	xor    eax,eax
  40a538:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40a53e:	test   eax,eax
  40a540:	jne    40a530 <__swc_fn_ff58629f_000007_635028f3>
  40a542:	ret
	...

000000000040a550 <__swc_fn_ff58629f_000010_186cd0c2>:
  40a550:	lea    r8,[rcx+0x60]
  40a554:	mov    rax,QWORD PTR [r8]
  40a557:	mov    r9,rax
  40a55a:	nop    WORD PTR [rax+rax*1+0x0]
  40a560:	mov    QWORD PTR [rdx],r9
  40a563:	mov    rax,r9
  40a566:	lock cmpxchg QWORD PTR [r8],rdx
  40a56b:	cmp    rax,r9
  40a56e:	jne    40a5d7 <__swc_fn_ff58629f_000010_186cd0c2+0x87>
  40a570:	mov    eax,DWORD PTR [rcx+0x6c]
  40a573:	test   eax,eax
  40a575:	je     40a5d6 <__swc_fn_ff58629f_000010_186cd0c2+0x86>
  40a577:	lea    rdx,[rcx+0x70]
  40a57b:	mov    r9d,0x1
  40a581:	xor    eax,eax
  40a583:	lock cmpxchg DWORD PTR [rdx],r9d
  40a588:	test   eax,eax
  40a58a:	jne    40a5d6 <__swc_fn_ff58629f_000010_186cd0c2+0x86>
  40a58c:	mov    rax,rcx
  40a58f:	and    rax,0xffffffffffc00000
  40a596:	mov    rax,QWORD PTR [rax+0x8]
  40a59a:	test   rax,rax
  40a59d:	jne    40a5a5 <__swc_fn_ff58629f_000010_186cd0c2+0x55>
  40a59f:	xor    eax,eax
  40a5a1:	xchg   DWORD PTR [rdx],eax
  40a5a3:	jmp    40a5d6 <__swc_fn_ff58629f_000010_186cd0c2+0x86>
  40a5a5:	lea    rdx,[rax+0x2a80]
  40a5ac:	mov    rax,QWORD PTR [rdx]
  40a5af:	mov    r8,rax
  40a5b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5bc:	nop    DWORD PTR [rax+0x0]
  40a5c0:	mov    QWORD PTR [rcx+0x78],r8
  40a5c4:	mov    rax,r8
  40a5c7:	lock cmpxchg QWORD PTR [rdx],rcx
  40a5cc:	cmp    rax,r8
  40a5cf:	je     40a5d6 <__swc_fn_ff58629f_000010_186cd0c2+0x86>
  40a5d1:	mov    r8,rax
  40a5d4:	jmp    40a5c0 <__swc_fn_ff58629f_000010_186cd0c2+0x70>
  40a5d6:	ret
  40a5d7:	mov    r9,rax
  40a5da:	jmp    40a560 <__swc_fn_ff58629f_000010_186cd0c2+0x10>
	...

000000000040a5e0 <__swc_fn_ff58629f_000013_d15d37c6>:
  40a5e0:	push   rsi
  40a5e1:	push   rdi
  40a5e2:	push   r12
  40a5e4:	push   r13
  40a5e6:	push   r14
  40a5e8:	push   r15
  40a5ea:	push   rbx
  40a5eb:	sub    rsp,0x30
  40a5ef:	mov    QWORD PTR [rsp+0x18],r8
  40a5f4:	mov    rsi,rcx
  40a5f7:	mov    rdi,rdx
  40a5fa:	mov    rdx,QWORD PTR [rsi+0x40]
  40a5fe:	xchg   ax,ax
  40a600:	mov    rax,rdx
  40a603:	not    rax
  40a606:	and    rax,QWORD PTR [rsi+0x20]
  40a60a:	test   rax,rax
  40a60d:	jne    40a621 <__swc_fn_ff58629f_000013_d15d37c6+0x41>
  40a60f:	xor    eax,eax
  40a611:	add    rsp,0x30
  40a615:	pop    rbx
  40a616:	pop    r15
  40a618:	pop    r14
  40a61a:	pop    r13
  40a61c:	pop    r12
  40a61e:	pop    rdi
  40a61f:	pop    rsi
  40a620:	ret
  40a621:	xor    ecx,ecx
  40a623:	tzcnt  rcx,rax
  40a628:	lea    r12,[rsp+0x8]
  40a62d:	mov    DWORD PTR [rsp+0x8],ecx
  40a631:	mov    r13d,0x1
  40a637:	shl    r13,cl
  40a63a:	mov    rcx,rdx
  40a63d:	or     rcx,r13
  40a640:	mov    rax,rdx
  40a643:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40a649:	cmp    rax,rdx
  40a64c:	je     40a653 <__swc_fn_ff58629f_000013_d15d37c6+0x73>
  40a64e:	mov    rdx,rax
  40a651:	jmp    40a600 <__swc_fn_ff58629f_000013_d15d37c6+0x20>
  40a653:	mov    eax,DWORD PTR [r12]
  40a657:	shl    rax,0x4
  40a65b:	lea    r14,[rsi+rax*8+0x80]
  40a663:	mov    rcx,rsi
  40a666:	mov    rax,r12
  40a669:	mov    edx,DWORD PTR [rax]
  40a66b:	call   40d920 <__swc_fn_ff58629f_000011_e75d466d>
  40a670:	mov    r15,rax
  40a673:	mov    rcx,rsi
  40a676:	mov    rdx,r13
  40a679:	call   40da80 <__swc_fn_ff58629f_000017_e238d24c>
  40a67e:	test   al,al
  40a680:	je     40a6b8 <__swc_fn_ff58629f_000013_d15d37c6+0xd8>
  40a682:	mov    ecx,DWORD PTR [r14+0x3c]
  40a686:	lea    rdx,[rip+0x189cb]        # 423058 <__swc_bss_base_ff58629f+0x18>
  40a68d:	mov    r8,QWORD PTR [rip+0x189c4]        # 423058 <__swc_bss_base_ff58629f+0x18>
  40a694:	cs nop WORD PTR [rax+rax*1+0x0]
  40a69e:	xchg   ax,ax
  40a6a0:	mov    r9,r8
  40a6a3:	sub    r9,rcx
  40a6a6:	mov    rax,r8
  40a6a9:	lock cmpxchg QWORD PTR [rdx],r9
  40a6ae:	cmp    rax,r8
  40a6b1:	je     40a719 <__swc_fn_ff58629f_000013_d15d37c6+0x139>
  40a6b3:	mov    r8,rax
  40a6b6:	jmp    40a6a0 <__swc_fn_ff58629f_000013_d15d37c6+0xc0>
  40a6b8:	mov    rcx,rsi
  40a6bb:	mov    rax,r12
  40a6be:	mov    edx,DWORD PTR [rax]
  40a6c0:	call   407450 <__swc_fn_ff58629f_000012_39679ef8>
  40a6c5:	mov    rcx,r15
  40a6c8:	and    rcx,0xffffffffffff0000
  40a6cf:	lea    rcx,[rcx+0x10000]
  40a6d6:	mov    rbx,rax
  40a6d9:	cmp    rax,rcx
  40a6dc:	cmova  rbx,rcx
  40a6e0:	mov    rax,rbx
  40a6e3:	sub    rax,r15
  40a6e6:	mov    rcx,r15
  40a6e9:	mov    rdx,rax
  40a6ec:	call   4072a0 <__swc_fn_ff58629f_000003_644dadb7>
  40a6f1:	test   al,al
  40a6f3:	jne    40a712 <__swc_fn_ff58629f_000013_d15d37c6+0x132>
  40a6f5:	mov    rcx,rsi
  40a6f8:	mov    rdx,r13
  40a6fb:	call   407600 <__swc_fn_ff58629f_000018_e2e8e4b0>
  40a700:	xor    eax,eax
  40a702:	add    rsp,0x30
  40a706:	pop    rbx
  40a707:	pop    r15
  40a709:	pop    r14
  40a70b:	pop    r13
  40a70d:	pop    r12
  40a70f:	pop    rdi
  40a710:	pop    rsi
  40a711:	ret
  40a712:	sub    rbx,r15
  40a715:	mov    DWORD PTR [r14+0x3c],ebx
  40a719:	mov    rcx,r14
  40a71c:	mov    rdx,rsi
  40a71f:	mov    r8d,DWORD PTR [r12]
  40a723:	mov    r9d,edi
  40a726:	mov    rbx,QWORD PTR [rsp+0x18]
  40a72b:	mov    r10d,ebx
  40a72e:	call   40a480 <__swc_fn_ff58629f_000004_2fa5c690>
  40a733:	mov    rax,r14
  40a736:	add    rsp,0x30
  40a73a:	pop    rbx
  40a73b:	pop    r15
  40a73d:	pop    r14
  40a73f:	pop    r13
  40a741:	pop    r12
  40a743:	pop    rdi
  40a744:	pop    rsi
  40a745:	ret
	...

000000000040a750 <__swc_fn_ff58629f_000016_89da4d6e>:
  40a750:	mov    r8,QWORD PTR [rcx+0x48]
  40a754:	cs nop WORD PTR [rax+rax*1+0x0]
  40a75e:	xchg   ax,ax
  40a760:	mov    r9,r8
  40a763:	or     r9,rdx
  40a766:	mov    rax,r8
  40a769:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40a76f:	cmp    rax,r8
  40a772:	jne    40a775 <__swc_fn_ff58629f_000016_89da4d6e+0x25>
  40a774:	ret
  40a775:	mov    r8,rax
  40a778:	jmp    40a760 <__swc_fn_ff58629f_000016_89da4d6e+0x10>
  40a77a:	add    BYTE PTR [rax],al
  40a77c:	add    BYTE PTR [rax],al
	...

000000000040a780 <__swc_fn_ff58629f_000019_60e50998>:
  40a780:	push   rsi
  40a781:	push   rdi
  40a782:	push   r12
  40a784:	mov    rsi,rcx
  40a787:	xor    edi,edi
  40a789:	lea    r12,[rip+0x188d8]        # 423068 <__swc_bss_base_ff58629f+0x28>
  40a790:	mov    eax,DWORD PTR [r12]
  40a794:	xor    ecx,ecx
  40a796:	test   rax,rax
  40a799:	jbe    40a7d4 <__swc_fn_ff58629f_000019_60e50998+0x54>
  40a79b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a7a0:	lea    rdx,[rip+0x188c9]        # 423070 <__swc_bss_base_ff58629f+0x30>
  40a7a7:	mov    r8d,ecx
  40a7aa:	lea    r8,[r8+r8*2]
  40a7ae:	lea    r8,[rdx+r8*8]
  40a7b2:	mov    rdx,QWORD PTR [r8+0x10]
  40a7b6:	add    rdx,0x400000
  40a7bd:	cmp    rdx,0x40000000
  40a7c4:	ja     40a7cb <__swc_fn_ff58629f_000019_60e50998+0x4b>
  40a7c6:	mov    rdi,r8
  40a7c9:	jmp    40a7d4 <__swc_fn_ff58629f_000019_60e50998+0x54>
  40a7cb:	add    rcx,0x1
  40a7cf:	cmp    rcx,rax
  40a7d2:	jb     40a7a0 <__swc_fn_ff58629f_000019_60e50998+0x20>
  40a7d4:	test   rdi,rdi
  40a7d7:	jne    40a863 <__swc_fn_ff58629f_000019_60e50998+0xe3>
  40a7dd:	cmp    DWORD PTR [r12],0x10
  40a7e2:	jae    40a84b <__swc_fn_ff58629f_000019_60e50998+0xcb>
  40a7e4:	mov    ecx,0x40400000
  40a7e9:	call   40d840 <__swc_fn_ff58629f_000002_390d5093>
  40a7ee:	test   rax,rax
  40a7f1:	je     40a84b <__swc_fn_ff58629f_000019_60e50998+0xcb>
  40a7f3:	lea    rcx,[rip+0x18876]        # 423070 <__swc_bss_base_ff58629f+0x30>
  40a7fa:	mov    edx,DWORD PTR [r12]
  40a7fe:	lea    rdx,[rdx+rdx*2]
  40a802:	lea    rdx,[rcx+rdx*8]
  40a806:	mov    QWORD PTR [rdx],rax
  40a809:	lea    rax,[rax+0x3fffff]
  40a810:	and    rax,0xffffffffffc00000
  40a817:	mov    QWORD PTR [rdx+0x8],rax
  40a81b:	mov    QWORD PTR [rdx+0x10],0x0
  40a823:	mov    edx,DWORD PTR [rip+0x1883f]        # 423068 <__swc_bss_base_ff58629f+0x28>
  40a829:	nop    DWORD PTR [rax+0x0]
  40a830:	lea    r9d,[rdx+0x1]
  40a834:	mov    rax,rdx
  40a837:	lock cmpxchg DWORD PTR [r12],r9d
  40a83d:	mov    r8d,eax
  40a840:	cmp    eax,edx
  40a842:	je     40a852 <__swc_fn_ff58629f_000019_60e50998+0xd2>
  40a844:	mov    rdx,r8
  40a847:	jmp    40a830 <__swc_fn_ff58629f_000019_60e50998+0xb0>
  40a849:	jmp    40a852 <__swc_fn_ff58629f_000019_60e50998+0xd2>
  40a84b:	xor    eax,eax
  40a84d:	pop    r12
  40a84f:	pop    rdi
  40a850:	pop    rsi
  40a851:	ret
  40a852:	mov    eax,DWORD PTR [rip+0x18810]        # 423068 <__swc_bss_base_ff58629f+0x28>
  40a858:	sub    eax,0x1
  40a85b:	lea    rdi,[rax+rax*2]
  40a85f:	lea    rdi,[rcx+rdi*8]
  40a863:	mov    r12,QWORD PTR [rdi+0x8]
  40a867:	add    r12,QWORD PTR [rdi+0x10]
  40a86b:	mov    rcx,r12
  40a86e:	mov    edx,0x3000
  40a873:	call   4072a0 <__swc_fn_ff58629f_000003_644dadb7>
  40a878:	test   al,al
  40a87a:	jne    40a883 <__swc_fn_ff58629f_000019_60e50998+0x103>
  40a87c:	xor    eax,eax
  40a87e:	pop    r12
  40a880:	pop    rdi
  40a881:	pop    rsi
  40a882:	ret
  40a883:	vxorps xmm0,xmm0,xmm0
  40a887:	xor    eax,eax
  40a889:	cs nop WORD PTR [rax+rax*1+0x0]
  40a893:	cs nop WORD PTR [rax+rax*1+0x0]
  40a89d:	nop    DWORD PTR [rax]
  40a8a0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40a8a6:	add    rax,0x10
  40a8aa:	cmp    rax,0x3000
  40a8b1:	jne    40a8a0 <__swc_fn_ff58629f_000019_60e50998+0x120>
  40a8b3:	mov    DWORD PTR [r12+0x28],esi
  40a8b8:	mov    eax,0x40
  40a8bd:	mov    ecx,esi
  40a8bf:	shr    eax,cl
  40a8c1:	mov    DWORD PTR [r12+0x2c],eax
  40a8c6:	cmp    DWORD PTR [r12+0x2c],0x40
  40a8cc:	jb     40a8d7 <__swc_fn_ff58629f_000019_60e50998+0x157>
  40a8ce:	mov    rax,0xffffffffffffffff
  40a8d5:	jmp    40a8e7 <__swc_fn_ff58629f_000019_60e50998+0x167>
  40a8d7:	mov    eax,0x1
  40a8dc:	mov    ecx,DWORD PTR [r12+0x2c]
  40a8e1:	shl    rax,cl
  40a8e4:	dec    rax
  40a8e7:	mov    QWORD PTR [r12+0x20],rax
  40a8ec:	mov    DWORD PTR [r12],0x4e540001
  40a8f4:	mov    DWORD PTR [r12+0x4],0x53474d45
  40a8fd:	add    QWORD PTR [rdi+0x10],0x400000
  40a905:	mov    rax,r12
  40a908:	pop    r12
  40a90a:	pop    rdi
  40a90b:	pop    rsi
  40a90c:	ret
  40a90d:	add    BYTE PTR [rax],al
	...

000000000040a910 <__swc_fn_ff58629f_000022_77c2d682>:
  40a910:	mov    eax,0x1
  40a915:	mov    edx,DWORD PTR [rip+0x1874d]        # 423068 <__swc_bss_base_ff58629f+0x28>
  40a91b:	cmp    eax,edx
  40a91d:	jae    40a96b <__swc_fn_ff58629f_000022_77c2d682+0x5b>
  40a91f:	nop
  40a920:	lea    r8,[rip+0x18749]        # 423070 <__swc_bss_base_ff58629f+0x30>
  40a927:	lea    r9,[rax+rax*2]
  40a92b:	lea    r9,[r8+r9*8]
  40a92f:	mov    r8,rcx
  40a932:	sub    r8,QWORD PTR [r9+0x8]
  40a936:	mov    r9,QWORD PTR [r9+0x10]
  40a93a:	cmp    r8,r9
  40a93d:	jae    40a965 <__swc_fn_ff58629f_000022_77c2d682+0x55>
  40a93f:	mov    rax,rcx
  40a942:	and    rax,0xffffffffffc00000
  40a949:	shr    rcx,0x10
  40a94d:	and    ecx,0x3f
  40a950:	mov    edx,DWORD PTR [rax+0x28]
  40a953:	shrx   ecx,ecx,edx
  40a958:	shl    rcx,0x4
  40a95c:	lea    rax,[rax+rcx*8+0x80]
  40a964:	ret
  40a965:	inc    eax
  40a967:	cmp    eax,edx
  40a969:	jb     40a920 <__swc_fn_ff58629f_000022_77c2d682+0x10>
  40a96b:	xor    eax,eax
  40a96d:	ret
	...

000000000040a970 <__swc_fn_ff58629f_000025_7e9350e1>:
  40a970:	vxorps xmm0,xmm0,xmm0
  40a974:	vmovups XMMWORD PTR [rcx],xmm0
  40a978:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a97d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a982:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a987:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40a98c:	mov    QWORD PTR [rcx+0x50],0x0
  40a994:	ret
	...

000000000040a9a0 <__swc_fn_ff58629f_000028_7e9350e1>:
  40a9a0:	vxorps xmm0,xmm0,xmm0
  40a9a4:	xor    eax,eax
  40a9a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9b0:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9ba:	nop    WORD PTR [rax+rax*1+0x0]
  40a9c0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a9c5:	add    rax,0x10
  40a9c9:	cmp    rax,0x9b0
  40a9d0:	jne    40a9c0 <__swc_fn_ff58629f_000028_7e9350e1+0x20>
  40a9d2:	mov    QWORD PTR [rcx+0x9b0],0x0
  40a9dd:	ret
	...

000000000040a9e0 <__swc_fn_ff58629f_000031_ed8d61a9>:
  40a9e0:	push   rsi
  40a9e1:	push   rdi
  40a9e2:	sub    rsp,0x8
  40a9e6:	lea    rsi,[rip+0x1661b]        # 421008 <__swc_data_base_ff58629f+0x8>
  40a9ed:	mov    rax,QWORD PTR [rsi]
  40a9f0:	mov    ecx,0xffffffff
  40a9f5:	cmp    rax,rcx
  40a9f8:	je     40aa01 <__swc_fn_ff58629f_000031_ed8d61a9+0x21>
  40a9fa:	add    rsp,0x8
  40a9fe:	pop    rdi
  40a9ff:	pop    rsi
  40aa00:	ret
  40aa01:	mov    rcx,QWORD PTR [rip+0x7678]        # 412080 <__swc_fn_ff58629f_000179_05d3c06b+0x5e0>
  40aa08:	call   409650 <__swc_fn_ff58629f_000126_5fb20c72>
  40aa0d:	mov    rcx,rax
  40aa10:	mov    eax,0xffffffff
  40aa15:	lock cmpxchg QWORD PTR [rsi],rcx
  40aa1a:	mov    rdi,rax
  40aa1d:	mov    eax,0xffffffff
  40aa22:	cmp    rdi,rax
  40aa25:	je     40aa36 <__swc_fn_ff58629f_000031_ed8d61a9+0x56>
  40aa27:	call   40cc10 <__swc_fn_ff58629f_000127_75f8ab5c>
  40aa2c:	mov    rax,rdi
  40aa2f:	add    rsp,0x8
  40aa33:	pop    rdi
  40aa34:	pop    rsi
  40aa35:	ret
  40aa36:	mov    rax,rcx
  40aa39:	add    rsp,0x8
  40aa3d:	pop    rdi
  40aa3e:	pop    rsi
  40aa3f:	ret

000000000040aa40 <__swc_fn_ff58629f_000034_c72914a2>:
  40aa40:	sub    rsp,0x8
  40aa44:	vxorps xmm0,xmm0,xmm0
  40aa48:	xor    eax,eax
  40aa4a:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa54:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa5e:	xchg   ax,ax
  40aa60:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40aa65:	add    rax,0x10
  40aa69:	cmp    rax,0x2b00
  40aa70:	jne    40aa60 <__swc_fn_ff58629f_000034_c72914a2+0x20>
  40aa72:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40aa7c:	xor    al,al
  40aa7e:	mov    rdx,rax
  40aa81:	xor    al,al
  40aa83:	mov    r8,rax
  40aa86:	xor    al,al
  40aa88:	mov    r9,rax
  40aa8b:	xor    al,al
  40aa8d:	mov    r10,rax
  40aa90:	xor    al,al
  40aa92:	mov    r11,rax
  40aa95:	call   40dcb0 <__swc_fn_ff58629f_000035_6105596e>
  40aa9a:	add    rsp,0x8
  40aa9e:	ret
	...

000000000040aaa0 <__swc_fn_ff58629f_000037_92e867c2>:
  40aaa0:	push   rsi
  40aaa1:	push   rdi
  40aaa2:	push   r12
  40aaa4:	mov    rsi,r8
  40aaa7:	mov    rdi,rdx
  40aaaa:	mov    rcx,rdx
  40aaad:	call   40d840 <__swc_fn_ff58629f_000002_390d5093>
  40aab2:	mov    r12,rax
  40aab5:	test   rax,rax
  40aab8:	jne    40aac1 <__swc_fn_ff58629f_000037_92e867c2+0x21>
  40aaba:	xor    eax,eax
  40aabc:	pop    r12
  40aabe:	pop    rdi
  40aabf:	pop    rsi
  40aac0:	ret
  40aac1:	mov    rcx,r12
  40aac4:	mov    rdx,rsi
  40aac7:	call   4072a0 <__swc_fn_ff58629f_000003_644dadb7>
  40aacc:	test   al,al
  40aace:	jne    40aae2 <__swc_fn_ff58629f_000037_92e867c2+0x42>
  40aad0:	mov    rcx,r12
  40aad3:	mov    rdx,rdi
  40aad6:	call   40fab0 <__swc_fn_ff58629f_000113_25e345b1>
  40aadb:	xor    eax,eax
  40aadd:	pop    r12
  40aadf:	pop    rdi
  40aae0:	pop    rsi
  40aae1:	ret
  40aae2:	mov    rax,r12
  40aae5:	pop    r12
  40aae7:	pop    rdi
  40aae8:	pop    rsi
  40aae9:	ret
	...

000000000040ab00 <__swc_fn_ff58629f_000040_7a225310>:
  40ab00:	push   rsi
  40ab01:	push   rdi
  40ab02:	push   r12
  40ab04:	mov    rsi,rcx
  40ab07:	mov    edx,0x9b8
  40ab0c:	call   40dd20 <__swc_fn_ff58629f_000038_c7591393>
  40ab11:	mov    rdi,rax
  40ab14:	test   rax,rax
  40ab17:	jne    40ab20 <__swc_fn_ff58629f_000040_7a225310+0x20>
  40ab19:	xor    eax,eax
  40ab1b:	pop    r12
  40ab1d:	pop    rdi
  40ab1e:	pop    rsi
  40ab1f:	ret
  40ab20:	vxorps xmm0,xmm0,xmm0
  40ab24:	xor    eax,eax
  40ab26:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab30:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab3a:	nop    WORD PTR [rax+rax*1+0x0]
  40ab40:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40ab45:	add    rax,0x10
  40ab49:	cmp    rax,0x9b0
  40ab50:	jne    40ab40 <__swc_fn_ff58629f_000040_7a225310+0x40>
  40ab52:	mov    QWORD PTR [rdi+0x9b0],0x0
  40ab5d:	mov    QWORD PTR [rdi],rsi
  40ab60:	call   40ccc0 <__swc_fn_ff58629f_000130_d2d78689>
  40ab65:	mov    QWORD PTR [rdi+0x18],rax
  40ab69:	lea    r12,[rsi+0x10]
  40ab6d:	mov    rcx,r12
  40ab70:	call   4098a0 <__swc_fn_ff58629f_000135_1fec60ac>
  40ab75:	mov    rax,QWORD PTR [rsi+0x20]
  40ab79:	mov    QWORD PTR [rdi+0x8],rax
  40ab7d:	mov    rax,QWORD PTR [rsi+0x20]
  40ab81:	test   rax,rax
  40ab84:	je     40ab8a <__swc_fn_ff58629f_000040_7a225310+0x8a>
  40ab86:	mov    QWORD PTR [rax+0x10],rdi
  40ab8a:	mov    QWORD PTR [rsi+0x20],rdi
  40ab8e:	mov    rcx,r12
  40ab91:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  40ab96:	mov    rax,rdi
  40ab99:	pop    r12
  40ab9b:	pop    rdi
  40ab9c:	pop    rsi
  40ab9d:	ret
	...

000000000040aba0 <__swc_fn_ff58629f_000043_3755033a>:
  40aba0:	mov    rax,QWORD PTR [rdx+0x10]
  40aba4:	test   rax,rax
  40aba7:	je     40abb3 <__swc_fn_ff58629f_000043_3755033a+0x13>
  40aba9:	mov    rcx,QWORD PTR [rdx+0x8]
  40abad:	mov    QWORD PTR [rax+0x8],rcx
  40abb1:	jmp    40abbb <__swc_fn_ff58629f_000043_3755033a+0x1b>
  40abb3:	mov    rax,QWORD PTR [rdx+0x8]
  40abb7:	mov    QWORD PTR [rcx+0x20],rax
  40abbb:	mov    rax,QWORD PTR [rdx+0x8]
  40abbf:	test   rax,rax
  40abc2:	je     40abcc <__swc_fn_ff58629f_000043_3755033a+0x2c>
  40abc4:	mov    rcx,QWORD PTR [rdx+0x10]
  40abc8:	mov    QWORD PTR [rax+0x10],rcx
  40abcc:	vxorps xmm0,xmm0,xmm0
  40abd0:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40abd5:	ret
	...

000000000040abe0 <__swc_fn_ff58629f_000046_49300800>:
  40abe0:	sub    rsp,0x8
  40abe4:	mov    r9,r8
  40abe7:	mov    r10,rdx
  40abea:	call   40ddd0 <__swc_fn_ff58629f_000044_cac7f504>
  40abef:	mov    eax,0x1
  40abf4:	xchg   DWORD PTR [r9+0x6c],eax
  40abf8:	mov    rax,QWORD PTR [r9+0x60]
  40abfc:	test   rax,rax
  40abff:	je     40ac43 <__swc_fn_ff58629f_000046_49300800+0x63>
  40ac01:	xor    eax,eax
  40ac03:	xchg   DWORD PTR [r9+0x6c],eax
  40ac07:	movzx  eax,BYTE PTR [r9+0x39]
  40ac0c:	lea    rax,[rax+rax*4]
  40ac10:	lea    rax,[r10+rax*8+0x28]
  40ac15:	mov    QWORD PTR [r9+0x50],0x0
  40ac1d:	mov    rcx,QWORD PTR [rax+0x8]
  40ac21:	mov    QWORD PTR [r9+0x48],rcx
  40ac25:	mov    rcx,QWORD PTR [rax+0x8]
  40ac29:	test   rcx,rcx
  40ac2c:	je     40ac34 <__swc_fn_ff58629f_000046_49300800+0x54>
  40ac2e:	mov    QWORD PTR [rcx+0x50],r9
  40ac32:	jmp    40ac38 <__swc_fn_ff58629f_000046_49300800+0x58>
  40ac34:	mov    QWORD PTR [rax+0x10],r9
  40ac38:	mov    QWORD PTR [rax+0x8],r9
  40ac3c:	xor    eax,eax
  40ac3e:	add    rsp,0x8
  40ac42:	ret
  40ac43:	movzx  eax,BYTE PTR [r9+0x39]
  40ac48:	lea    rax,[rax+rax*4]
  40ac4c:	lea    rax,[r10+rax*8+0x28]
  40ac51:	mov    QWORD PTR [r9+0x50],0x0
  40ac59:	mov    rcx,QWORD PTR [rax+0x18]
  40ac5d:	mov    QWORD PTR [r9+0x48],rcx
  40ac61:	mov    rcx,QWORD PTR [rax+0x18]
  40ac65:	test   rcx,rcx
  40ac68:	je     40ac6e <__swc_fn_ff58629f_000046_49300800+0x8e>
  40ac6a:	mov    QWORD PTR [rcx+0x50],r9
  40ac6e:	mov    QWORD PTR [rax+0x18],r9
  40ac72:	mov    eax,0x1
  40ac77:	add    rsp,0x8
  40ac7b:	ret
  40ac7c:	add    BYTE PTR [rax],al
	...

000000000040ac80 <__swc_fn_ff58629f_000049_781177b4>:
  40ac80:	push   r12
  40ac82:	push   r13
  40ac84:	push   rdi
  40ac85:	push   rsi
  40ac86:	push   r14
  40ac88:	push   r15
  40ac8a:	sub    rsp,0x178
  40ac91:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40ac9a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40aca3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40acac:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40acb5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40acbe:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40acc7:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40acd0:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40acd9:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40ace2:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40aceb:	mov    r12,rcx
  40acee:	lea    rax,[rip+0x1850b]        # 423200 <__swc_bss_base_ff58629f+0x1c0>
  40acf5:	mov    rcx,QWORD PTR [rax]
  40acf8:	mov    r13,rcx
  40acfb:	test   rcx,rcx
  40acfe:	jne    40ad0e <__swc_fn_ff58629f_000049_781177b4+0x8e>
  40ad00:	mov    r13d,0x1dcd6500
  40ad06:	mov    ecx,0x1dcd6500
  40ad0b:	xchg   QWORD PTR [rax],rcx
  40ad0e:	lea    rax,[rip+0x162eb]        # 421000 <__swc_data_base_ff58629f>
  40ad15:	mov    rax,QWORD PTR [rax]
  40ad18:	cmp    rax,0xffffffffffffffff
  40ad1c:	je     40ad2b <__swc_fn_ff58629f_000049_781177b4+0xab>
  40ad1e:	mov    eax,eax
  40ad20:	mov    edi,eax
  40ad22:	xor    eax,eax
  40ad24:	call   407000 <pthread_getspecific@plt>
  40ad29:	jmp    40ad2d <__swc_fn_ff58629f_000049_781177b4+0xad>
  40ad2b:	xor    eax,eax
  40ad2d:	test   rax,rax
  40ad30:	jne    40ad3f <__swc_fn_ff58629f_000049_781177b4+0xbf>
  40ad32:	call   40a9e0 <__swc_fn_ff58629f_000031_ed8d61a9>
  40ad37:	mov    rcx,rax
  40ad3a:	call   40fe00 <__swc_fn_ff58629f_000128_9c45d2d7>
  40ad3f:	test   rax,rax
  40ad42:	je     40ad54 <__swc_fn_ff58629f_000049_781177b4+0xd4>
  40ad44:	cmp    QWORD PTR [rax],r12
  40ad47:	jne    40ad54 <__swc_fn_ff58629f_000049_781177b4+0xd4>
  40ad49:	cmp    DWORD PTR [rax+0x20],0x0
  40ad4d:	jne    40ad54 <__swc_fn_ff58629f_000049_781177b4+0xd4>
  40ad4f:	mov    rsi,rax
  40ad52:	jmp    40ad56 <__swc_fn_ff58629f_000049_781177b4+0xd6>
  40ad54:	xor    esi,esi
  40ad56:	lea    rdi,[r12+0x2a88]
  40ad5e:	mov    r14,QWORD PTR [rdi]
  40ad61:	test   r14,r14
  40ad64:	jne    40adb3 <__swc_fn_ff58629f_000049_781177b4+0x133>
  40ad66:	lea    rax,[rip+0x182eb]        # 423058 <__swc_bss_base_ff58629f+0x18>
  40ad6d:	mov    rax,QWORD PTR [rax]
  40ad70:	test   rax,rax
  40ad73:	setne  al
  40ad76:	jne    40ad9a <__swc_fn_ff58629f_000049_781177b4+0x11a>
  40ad78:	mov    rax,QWORD PTR [r12+0x2a70]
  40ad80:	test   rax,rax
  40ad83:	setne  al
  40ad86:	jne    40ad9a <__swc_fn_ff58629f_000049_781177b4+0x11a>
  40ad88:	test   rsi,rsi
  40ad8b:	setne  al
  40ad8e:	je     40ad9a <__swc_fn_ff58629f_000049_781177b4+0x11a>
  40ad90:	cmp    DWORD PTR [rsi+0x730],0x0
  40ad97:	setne  al
  40ad9a:	test   al,al
  40ad9c:	je     40adae <__swc_fn_ff58629f_000049_781177b4+0x12e>
  40ad9e:	call   40feb0 <__swc_fn_ff58629f_000131_dc04d759>
  40ada3:	lea    rcx,[rax+r13*1]
  40ada7:	xor    eax,eax
  40ada9:	lock cmpxchg QWORD PTR [rdi],rcx
  40adae:	jmp    40aeb3 <__swc_fn_ff58629f_000049_781177b4+0x233>
  40adb3:	call   40feb0 <__swc_fn_ff58629f_000131_dc04d759>
  40adb8:	mov    r15,rax
  40adbb:	cmp    rax,r14
  40adbe:	jb     40adcf <__swc_fn_ff58629f_000049_781177b4+0x14f>
  40adc0:	xor    ecx,ecx
  40adc2:	mov    rax,r14
  40adc5:	lock cmpxchg QWORD PTR [rdi],rcx
  40adca:	cmp    rax,r14
  40adcd:	je     40add4 <__swc_fn_ff58629f_000049_781177b4+0x154>
  40adcf:	jmp    40aeb3 <__swc_fn_ff58629f_000049_781177b4+0x233>
  40add4:	test   rsi,rsi
  40add7:	je     40adf2 <__swc_fn_ff58629f_000049_781177b4+0x172>
  40add9:	cmp    r15,r13
  40addc:	jb     40adf2 <__swc_fn_ff58629f_000049_781177b4+0x172>
  40adde:	mov    rax,r15
  40ade1:	sub    rax,r13
  40ade4:	mov    rcx,r12
  40ade7:	mov    rdx,rsi
  40adea:	mov    r8,rax
  40aded:	call   40e210 <__swc_fn_ff58629f_000059_c8e1ff6b>
  40adf2:	lea    rsi,[r12+0x10]
  40adf7:	mov    rcx,rsi
  40adfa:	call   4098a0 <__swc_fn_ff58629f_000135_1fec60ac>
  40adff:	mov    rax,QWORD PTR [r12+0x18]
  40ae04:	mov    rdi,rax
  40ae07:	test   rdi,rdi
  40ae0a:	je     40ae34 <__swc_fn_ff58629f_000049_781177b4+0x1b4>
  40ae0c:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae16:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae20:	mov    rcx,rdi
  40ae23:	call   407470 <__swc_fn_ff58629f_000015_aa8c841a>
  40ae28:	mov    rax,QWORD PTR [rdi+0x10]
  40ae2c:	mov    rdi,rax
  40ae2f:	test   rax,rax
  40ae32:	jne    40ae20 <__swc_fn_ff58629f_000049_781177b4+0x1a0>
  40ae34:	mov    rcx,rsi
  40ae37:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  40ae3c:	mov    rcx,r12
  40ae3f:	call   4098a0 <__swc_fn_ff58629f_000135_1fec60ac>
  40ae44:	xor    esi,esi
  40ae46:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae50:	mov    rax,QWORD PTR [r12+0x2a70]
  40ae58:	cmp    rsi,rax
  40ae5b:	jae    40aeab <__swc_fn_ff58629f_000049_781177b4+0x22b>
  40ae5d:	lea    rax,[rsi+rsi*4]
  40ae61:	lea    rax,[r12+rax*8+0x268]
  40ae69:	mov    r8,QWORD PTR [rax]
  40ae6c:	mov    r9,QWORD PTR [rax+0x8]
  40ae70:	mov    r10,QWORD PTR [rax+0x10]
  40ae74:	mov    rax,QWORD PTR [rax+0x20]
  40ae78:	cmp    rax,r15
  40ae7b:	jae    40ae88 <__swc_fn_ff58629f_000049_781177b4+0x208>
  40ae7d:	mov    rcx,r15
  40ae80:	sub    rcx,rax
  40ae83:	cmp    rcx,r13
  40ae86:	jae    40ae8d <__swc_fn_ff58629f_000049_781177b4+0x20d>
  40ae88:	inc    rsi
  40ae8b:	jmp    40ae50 <__swc_fn_ff58629f_000049_781177b4+0x1d0>
  40ae8d:	mov    rcx,r12
  40ae90:	mov    rdx,rsi
  40ae93:	call   40e1c0 <__swc_fn_ff58629f_000056_cfedf3f4>
  40ae98:	mov    rcx,r12
  40ae9b:	mov    rdx,r8
  40ae9e:	mov    r8,r9
  40aea1:	mov    r9,r10
  40aea4:	call   407750 <__swc_fn_ff58629f_000039_05a50673>
  40aea9:	jmp    40ae50 <__swc_fn_ff58629f_000049_781177b4+0x1d0>
  40aeab:	mov    rcx,r12
  40aeae:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  40aeb3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40aebc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40aec5:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40aece:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40aed7:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40aee0:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40aee9:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40aef2:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40aefb:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40af04:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40af0d:	add    rsp,0x178
  40af14:	pop    r15
  40af16:	pop    r14
  40af18:	pop    rsi
  40af19:	pop    rdi
  40af1a:	pop    r13
  40af1c:	pop    r12
  40af1e:	ret
	...

000000000040af20 <__swc_fn_ff58629f_000052_26c6c1c4>:
  40af20:	lea    rax,[rdx-0x58]
  40af24:	ret
	...

000000000040af30 <__swc_fn_ff58629f_000055_da36318f>:
  40af30:	push   rsi
  40af31:	push   rdi
  40af32:	push   r12
  40af34:	push   r13
  40af36:	sub    rsp,0x68
  40af3a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40af40:	mov    rsi,r9
  40af43:	mov    rdi,rcx
  40af46:	mov    r12,rdx
  40af49:	mov    r13,r8
  40af4c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40af54:	jne    40af63 <__swc_fn_ff58629f_000055_da36318f+0x33>
  40af56:	xor    eax,eax
  40af58:	add    rsp,0x68
  40af5c:	pop    r13
  40af5e:	pop    r12
  40af60:	pop    rdi
  40af61:	pop    rsi
  40af62:	ret
  40af63:	mov    rcx,rdi
  40af66:	call   4098a0 <__swc_fn_ff58629f_000135_1fec60ac>
  40af6b:	movabs rax,0x7fffffffffffffff
  40af75:	cmp    r12,rax
  40af78:	mov    rax,0xffffffffffffffff
  40af7f:	lea    rcx,[r12+r12*1]
  40af83:	cmovbe rax,rcx
  40af87:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40af8e:	mov    rdx,rcx
  40af91:	sub    rax,r12
  40af94:	inc    rax
  40af97:	xor    r8d,r8d
  40af9a:	test   rcx,rcx
  40af9d:	jbe    40afc8 <__swc_fn_ff58629f_000055_da36318f+0x98>
  40af9f:	nop
  40afa0:	lea    r9,[r8+r8*4]
  40afa4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40afac:	sub    r9,r12
  40afaf:	cmp    r9,rax
  40afb2:	jae    40afbf <__swc_fn_ff58629f_000055_da36318f+0x8f>
  40afb4:	mov    rdx,r8
  40afb7:	mov    rax,r9
  40afba:	test   r9,r9
  40afbd:	je     40afc8 <__swc_fn_ff58629f_000055_da36318f+0x98>
  40afbf:	add    r8,0x1
  40afc3:	cmp    r8,rcx
  40afc6:	jb     40afa0 <__swc_fn_ff58629f_000055_da36318f+0x70>
  40afc8:	mov    rax,QWORD PTR [rdi+0x2a70]
  40afcf:	cmp    rdx,rax
  40afd2:	jne    40afef <__swc_fn_ff58629f_000055_da36318f+0xbf>
  40afd4:	mov    rcx,rdi
  40afd7:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  40afdc:	xor    eax,eax
  40afde:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40afe4:	add    rsp,0x68
  40afe8:	pop    r13
  40afea:	pop    r12
  40afec:	pop    rdi
  40afed:	pop    rsi
  40afee:	ret
  40afef:	lea    rax,[rdx+rdx*4]
  40aff3:	lea    rax,[rdi+rax*8+0x268]
  40affb:	vmovups xmm6,XMMWORD PTR [rax]
  40afff:	mov    r8,QWORD PTR [rax+0x10]
  40b003:	mov    rcx,rdi
  40b006:	call   40e1c0 <__swc_fn_ff58629f_000056_cfedf3f4>
  40b00b:	vpshufd xmm0,xmm6,0xee
  40b010:	vmovsd QWORD PTR [r13+0x0],xmm0
  40b016:	mov    QWORD PTR [rsi],r8
  40b019:	mov    rcx,rdi
  40b01c:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  40b021:	vmovq  rax,xmm6
  40b026:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b02c:	add    rsp,0x68
  40b030:	pop    r13
  40b032:	pop    r12
  40b034:	pop    rdi
  40b035:	pop    rsi
  40b036:	ret
	...

000000000040b040 <__swc_fn_ff58629f_000058_033ce1da>:
  40b040:	push   r12
  40b042:	push   r13
  40b044:	push   r14
  40b046:	push   r15
  40b048:	push   rdi
  40b049:	push   rsi
  40b04a:	sub    rsp,0x148
  40b051:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40b05a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40b063:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40b06c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40b075:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40b07e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40b087:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40b090:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40b099:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40b0a2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40b0ab:	mov    r12,r9
  40b0ae:	mov    r13,rcx
  40b0b1:	mov    r14,rdx
  40b0b4:	mov    r15,r8
  40b0b7:	test   rdx,rdx
  40b0ba:	jne    40b0ce <__swc_fn_ff58629f_000058_033ce1da+0x8e>
  40b0bc:	add    rsp,0x148
  40b0c3:	pop    rsi
  40b0c4:	pop    rdi
  40b0c5:	pop    r15
  40b0c7:	pop    r14
  40b0c9:	pop    r13
  40b0cb:	pop    r12
  40b0cd:	ret
  40b0ce:	cmp    r12,0x200000
  40b0d5:	ja     40b167 <__swc_fn_ff58629f_000058_033ce1da+0x127>
  40b0db:	lea    rax,[rip+0x15f1e]        # 421000 <__swc_data_base_ff58629f>
  40b0e2:	mov    rax,QWORD PTR [rax]
  40b0e5:	cmp    rax,0xffffffffffffffff
  40b0e9:	je     40b0f8 <__swc_fn_ff58629f_000058_033ce1da+0xb8>
  40b0eb:	mov    eax,eax
  40b0ed:	mov    edi,eax
  40b0ef:	xor    eax,eax
  40b0f1:	call   407000 <pthread_getspecific@plt>
  40b0f6:	jmp    40b0fa <__swc_fn_ff58629f_000058_033ce1da+0xba>
  40b0f8:	xor    eax,eax
  40b0fa:	test   rax,rax
  40b0fd:	je     40b104 <__swc_fn_ff58629f_000058_033ce1da+0xc4>
  40b0ff:	mov    rsi,rax
  40b102:	jmp    40b114 <__swc_fn_ff58629f_000058_033ce1da+0xd4>
  40b104:	call   40a9e0 <__swc_fn_ff58629f_000031_ed8d61a9>
  40b109:	mov    rcx,rax
  40b10c:	call   40fe00 <__swc_fn_ff58629f_000128_9c45d2d7>
  40b111:	mov    rsi,rax
  40b114:	test   rsi,rsi
  40b117:	je     40b167 <__swc_fn_ff58629f_000058_033ce1da+0x127>
  40b119:	cmp    QWORD PTR [rsi],r13
  40b11c:	jne    40b167 <__swc_fn_ff58629f_000058_033ce1da+0x127>
  40b11e:	cmp    DWORD PTR [rsi+0x20],0x0
  40b122:	jne    40b167 <__swc_fn_ff58629f_000058_033ce1da+0x127>
  40b124:	cmp    DWORD PTR [rsi+0x730],0x10
  40b12b:	jae    40b167 <__swc_fn_ff58629f_000058_033ce1da+0x127>
  40b12d:	mov    eax,DWORD PTR [rsi+0x730]
  40b133:	lea    rdi,[rax+rax*4]
  40b137:	lea    rdi,[rsi+rdi*8+0x738]
  40b13f:	mov    QWORD PTR [rdi],r14
  40b142:	mov    QWORD PTR [rdi+0x8],r15
  40b146:	mov    QWORD PTR [rdi+0x10],r12
  40b14a:	mov    QWORD PTR [rdi+0x18],0x0
  40b152:	call   40feb0 <__swc_fn_ff58629f_000131_dc04d759>
  40b157:	mov    QWORD PTR [rdi+0x20],rax
  40b15b:	add    DWORD PTR [rsi+0x730],0x1
  40b162:	jmp    40b2c6 <__swc_fn_ff58629f_000058_033ce1da+0x286>
  40b167:	mov    rcx,r13
  40b16a:	call   407e90 <__swc_fn_ff58629f_000057_8be0372b>
  40b16f:	mov    rsi,rax
  40b172:	cmp    r12,rax
  40b175:	jbe    40b1aa <__swc_fn_ff58629f_000058_033ce1da+0x16a>
  40b177:	cmp    r12,0x10000000
  40b17e:	seta   al
  40b181:	ja     40b190 <__swc_fn_ff58629f_000058_033ce1da+0x150>
  40b183:	mov    rax,QWORD PTR [r13+0x2a70]
  40b18a:	test   rax,rax
  40b18d:	setne  al
  40b190:	test   al,al
  40b192:	je     40b1aa <__swc_fn_ff58629f_000058_033ce1da+0x16a>
  40b194:	mov    rcx,r13
  40b197:	mov    rdx,r14
  40b19a:	mov    r8,r15
  40b19d:	mov    r9,r12
  40b1a0:	call   407750 <__swc_fn_ff58629f_000039_05a50673>
  40b1a5:	jmp    40b2c6 <__swc_fn_ff58629f_000058_033ce1da+0x286>
  40b1aa:	call   40feb0 <__swc_fn_ff58629f_000131_dc04d759>
  40b1af:	mov    rdi,rax
  40b1b2:	mov    rcx,r13
  40b1b5:	call   4098a0 <__swc_fn_ff58629f_000135_1fec60ac>
  40b1ba:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b1c2:	je     40b27a <__swc_fn_ff58629f_000058_033ce1da+0x23a>
  40b1c8:	nop    DWORD PTR [rax+rax*1+0x0]
  40b1d0:	cmp    QWORD PTR [r13+0x2a70],0x100
  40b1db:	jae    40b1f0 <__swc_fn_ff58629f_000058_033ce1da+0x1b0>
  40b1dd:	mov    rax,QWORD PTR [r13+0x2a68]
  40b1e4:	add    rax,r12
  40b1e7:	cmp    rax,rsi
  40b1ea:	jbe    40b27a <__swc_fn_ff58629f_000058_033ce1da+0x23a>
  40b1f0:	xor    eax,eax
  40b1f2:	mov    rcx,QWORD PTR [r13+0x2a70]
  40b1f9:	mov    edx,0x1
  40b1fe:	cmp    rcx,0x1
  40b202:	jbe    40b239 <__swc_fn_ff58629f_000058_033ce1da+0x1f9>
  40b204:	cs nop WORD PTR [rax+rax*1+0x0]
  40b20e:	xchg   ax,ax
  40b210:	lea    r8,[rdx+rdx*4]
  40b214:	lea    r8,[r13+r8*8+0x268]
  40b21c:	lea    r9,[rax+rax*4]
  40b220:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40b228:	cmp    QWORD PTR [r8+0x18],r9
  40b22c:	cmovb  rax,rdx
  40b230:	add    rdx,0x1
  40b234:	cmp    rdx,rcx
  40b237:	jb     40b210 <__swc_fn_ff58629f_000058_033ce1da+0x1d0>
  40b239:	lea    rcx,[rax+rax*4]
  40b23d:	lea    rcx,[r13+rcx*8+0x268]
  40b245:	mov    r8,QWORD PTR [rcx]
  40b248:	mov    r9,QWORD PTR [rcx+0x8]
  40b24c:	mov    r10,QWORD PTR [rcx+0x10]
  40b250:	mov    rcx,r13
  40b253:	mov    rdx,rax
  40b256:	call   40e1c0 <__swc_fn_ff58629f_000056_cfedf3f4>
  40b25b:	mov    rcx,r13
  40b25e:	mov    rdx,r8
  40b261:	mov    r8,r9
  40b264:	mov    r9,r10
  40b267:	call   407750 <__swc_fn_ff58629f_000039_05a50673>
  40b26c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b274:	jne    40b1d0 <__swc_fn_ff58629f_000058_033ce1da+0x190>
  40b27a:	add    QWORD PTR [r13+0x2a78],0x1
  40b282:	mov    rax,QWORD PTR [r13+0x2a70]
  40b289:	lea    rax,[rax+rax*4]
  40b28d:	lea    rax,[r13+rax*8+0x268]
  40b295:	mov    QWORD PTR [rax],r14
  40b298:	mov    QWORD PTR [rax+0x8],r15
  40b29c:	mov    QWORD PTR [rax+0x10],r12
  40b2a0:	mov    rcx,QWORD PTR [r13+0x2a78]
  40b2a7:	mov    QWORD PTR [rax+0x18],rcx
  40b2ab:	mov    QWORD PTR [rax+0x20],rdi
  40b2af:	add    QWORD PTR [r13+0x2a68],r12
  40b2b6:	add    QWORD PTR [r13+0x2a70],0x1
  40b2be:	mov    rcx,r13
  40b2c1:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  40b2c6:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40b2cf:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40b2d8:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40b2e1:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40b2ea:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40b2f3:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40b2fc:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40b305:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40b30e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40b317:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40b320:	add    rsp,0x148
  40b327:	pop    rsi
  40b328:	pop    rdi
  40b329:	pop    r15
  40b32b:	pop    r14
  40b32d:	pop    r13
  40b32f:	pop    r12
  40b331:	ret
	...

000000000040b340 <__swc_fn_ff58629f_000061_1badc238>:
  40b340:	push   rbx
  40b341:	push   r12
  40b343:	push   r13
  40b345:	push   r14
  40b347:	push   r15
  40b349:	push   rdi
  40b34a:	push   rsi
  40b34b:	sub    rsp,0xf0
  40b352:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40b358:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40b35e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40b364:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40b36a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40b373:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40b37c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40b385:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40b38e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40b397:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40b3a0:	mov    eax,r8d
  40b3a3:	mov    rbx,rcx
  40b3a6:	mov    r12,rdx
  40b3a9:	mov    QWORD PTR [rsp+0x18],rdx
  40b3ae:	mov    ecx,DWORD PTR [r12+0x58]
  40b3b3:	mov    r13d,ecx
  40b3b6:	cmp    ecx,0x10
  40b3b9:	mov    ecx,0x10
  40b3be:	cmovb  r13d,ecx
  40b3c2:	test   r13d,r13d
  40b3c5:	mov    rcx,r13
  40b3c8:	mov    edx,0x8
  40b3cd:	cmove  ecx,edx
  40b3d0:	dec    rcx
  40b3d3:	mov    rdx,0xffffffffffffffff
  40b3da:	sub    rdx,rcx
  40b3dd:	xor    r14d,r14d
  40b3e0:	mov    r8,rcx
  40b3e3:	not    r8
  40b3e6:	lea    rcx,[rcx+0x58]
  40b3ea:	and    rcx,r8
  40b3ed:	cmp    rdx,0x58
  40b3f1:	cmovae r14,rcx
  40b3f5:	cmp    eax,0xffffffff
  40b3f8:	jne    40b401 <__swc_fn_ff58629f_000061_1badc238+0xc1>
  40b3fa:	mov    r15,QWORD PTR [r12+0x48]
  40b3ff:	jmp    40b433 <__swc_fn_ff58629f_000061_1badc238+0xf3>
  40b401:	test   eax,eax
  40b403:	jne    40b40c <__swc_fn_ff58629f_000061_1badc238+0xcc>
  40b405:	mov    eax,0x8
  40b40a:	jmp    40b430 <__swc_fn_ff58629f_000061_1badc238+0xf0>
  40b40c:	cmp    eax,0x8
  40b40f:	ja     40b417 <__swc_fn_ff58629f_000061_1badc238+0xd7>
  40b411:	shl    rax,0x4
  40b415:	jmp    40b430 <__swc_fn_ff58629f_000061_1badc238+0xf0>
  40b417:	lea    eax,[rax-0x9]
  40b41a:	mov    ecx,eax
  40b41c:	shr    ecx,0x2
  40b41f:	and    eax,0x3
  40b422:	lea    ecx,[rcx+0x7]
  40b425:	lea    ecx,[rcx-0x2]
  40b428:	lea    eax,[rax+0x5]
  40b42b:	shlx   rax,rax,rcx
  40b430:	mov    r15,rax
  40b433:	lea    rax,[r14+r13*1]
  40b437:	mov    rcx,0xffffffffffffffff
  40b43e:	sub    rcx,rax
  40b441:	cmp    r15,rcx
  40b444:	jbe    40b454 <__swc_fn_ff58629f_000061_1badc238+0x114>
  40b446:	mov    QWORD PTR [r12+0x40],0x0
  40b44f:	jmp    40b826 <__swc_fn_ff58629f_000061_1badc238+0x4e6>
  40b454:	mov    QWORD PTR [rsp+0x20],r13
  40b459:	lea    r13,[rsp+0x8]
  40b45e:	add    rax,r15
  40b461:	mov    ecx,0x1000
  40b466:	test   ecx,ecx
  40b468:	mov    edx,0x8
  40b46d:	cmove  ecx,edx
  40b470:	dec    rcx
  40b473:	mov    rdx,0xffffffffffffffff
  40b47a:	sub    rdx,rcx
  40b47d:	cmp    rax,rdx
  40b480:	jbe    40b48c <__swc_fn_ff58629f_000061_1badc238+0x14c>
  40b482:	mov    QWORD PTR [r13+0x0],0x0
  40b48a:	jmp    40b499 <__swc_fn_ff58629f_000061_1badc238+0x159>
  40b48c:	add    rax,rcx
  40b48f:	andn   rax,rcx,rax
  40b494:	mov    QWORD PTR [rsp+0x8],rax
  40b499:	cmp    QWORD PTR [r13+0x0],0x0
  40b49e:	jne    40b4ae <__swc_fn_ff58629f_000061_1badc238+0x16e>
  40b4a0:	mov    QWORD PTR [r12+0x40],0x0
  40b4a9:	jmp    40b826 <__swc_fn_ff58629f_000061_1badc238+0x4e6>
  40b4ae:	mov    QWORD PTR [rsp+0x30],r15
  40b4b3:	xor    r15d,r15d
  40b4b6:	mov    QWORD PTR [rsp+0x38],0x0
  40b4bf:	lea    r12,[rsp+0x10]
  40b4c4:	mov    QWORD PTR [rsp+0x28],r14
  40b4c9:	mov    r14,QWORD PTR [rsp+0x8]
  40b4ce:	mov    QWORD PTR [rsp+0x10],r14
  40b4d3:	cmp    r14,0x10000
  40b4da:	ja     40b4e1 <__swc_fn_ff58629f_000061_1badc238+0x1a1>
  40b4dc:	mov    rax,r14
  40b4df:	jmp    40b532 <__swc_fn_ff58629f_000061_1badc238+0x1f2>
  40b4e1:	xor    eax,eax
  40b4e3:	lea    rcx,[r14-0x1]
  40b4e7:	lzcnt  rax,rcx
  40b4ec:	mov    ecx,0x3f
  40b4f1:	sub    rcx,rax
  40b4f4:	mov    eax,0x1
  40b4f9:	lea    rcx,[rcx-0x3]
  40b4fd:	shl    rax,cl
  40b500:	mov    rcx,rax
  40b503:	cmp    rax,0x1000
  40b50a:	mov    eax,0x1000
  40b50f:	cmovb  rcx,rax
  40b513:	mov    rdx,0xffffffffffffffff
  40b51a:	sub    rdx,rcx
  40b51d:	mov    rax,r14
  40b520:	lea    r8,[r14+rcx*1-0x1]
  40b525:	neg    rcx
  40b528:	and    r8,rcx
  40b52b:	cmp    r14,rdx
  40b52e:	cmovbe rax,r8
  40b532:	mov    QWORD PTR [rsp+0x8],rax
  40b537:	lea    rax,[rip+0x15ac2]        # 421000 <__swc_data_base_ff58629f>
  40b53e:	mov    rax,QWORD PTR [rax]
  40b541:	cmp    rax,0xffffffffffffffff
  40b545:	je     40b554 <__swc_fn_ff58629f_000061_1badc238+0x214>
  40b547:	mov    eax,eax
  40b549:	mov    edi,eax
  40b54b:	xor    eax,eax
  40b54d:	call   407000 <pthread_getspecific@plt>
  40b552:	jmp    40b556 <__swc_fn_ff58629f_000061_1badc238+0x216>
  40b554:	xor    eax,eax
  40b556:	test   rax,rax
  40b559:	jne    40b568 <__swc_fn_ff58629f_000061_1badc238+0x228>
  40b55b:	call   40a9e0 <__swc_fn_ff58629f_000031_ed8d61a9>
  40b560:	mov    rcx,rax
  40b563:	call   40fe00 <__swc_fn_ff58629f_000128_9c45d2d7>
  40b568:	test   rax,rax
  40b56b:	je     40b65c <__swc_fn_ff58629f_000061_1badc238+0x31c>
  40b571:	cmp    QWORD PTR [rax],rbx
  40b574:	jne    40b65c <__swc_fn_ff58629f_000061_1badc238+0x31c>
  40b57a:	cmp    DWORD PTR [rax+0x20],0x0
  40b57e:	jne    40b65c <__swc_fn_ff58629f_000061_1badc238+0x31c>
  40b584:	mov    rcx,QWORD PTR [rsp+0x8]
  40b589:	movabs rdx,0x7fffffffffffffff
  40b593:	cmp    rcx,rdx
  40b596:	mov    rdx,0xffffffffffffffff
  40b59d:	lea    r8,[rcx+rcx*1]
  40b5a1:	cmovbe rdx,r8
  40b5a5:	mov    r8d,DWORD PTR [rax+0x730]
  40b5ac:	mov    r9d,r8d
  40b5af:	sub    rdx,rcx
  40b5b2:	inc    rdx
  40b5b5:	xor    r10d,r10d
  40b5b8:	test   r8,r8
  40b5bb:	jbe    40b5eb <__swc_fn_ff58629f_000061_1badc238+0x2ab>
  40b5bd:	nop    DWORD PTR [rax]
  40b5c0:	mov    r11d,r10d
  40b5c3:	lea    r11,[r11+r11*4]
  40b5c7:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40b5cf:	sub    r11,rcx
  40b5d2:	cmp    r11,rdx
  40b5d5:	jae    40b5e2 <__swc_fn_ff58629f_000061_1badc238+0x2a2>
  40b5d7:	mov    r9d,r10d
  40b5da:	mov    rdx,r11
  40b5dd:	test   r11,r11
  40b5e0:	je     40b5eb <__swc_fn_ff58629f_000061_1badc238+0x2ab>
  40b5e2:	add    r10,0x1
  40b5e6:	cmp    r10,r8
  40b5e9:	jb     40b5c0 <__swc_fn_ff58629f_000061_1badc238+0x280>
  40b5eb:	mov    ecx,DWORD PTR [rax+0x730]
  40b5f1:	cmp    r9d,ecx
  40b5f4:	jne    40b5fa <__swc_fn_ff58629f_000061_1badc238+0x2ba>
  40b5f6:	xor    eax,eax
  40b5f8:	jmp    40b659 <__swc_fn_ff58629f_000061_1badc238+0x319>
  40b5fa:	lea    rcx,[r9+r9*4]
  40b5fe:	lea    rcx,[rax+rcx*8+0x738]
  40b606:	vmovups xmm0,XMMWORD PTR [rcx]
  40b60a:	mov    rdx,QWORD PTR [rcx+0x10]
  40b60e:	sub    DWORD PTR [rax+0x730],0x1
  40b615:	mov    r8d,DWORD PTR [rax+0x730]
  40b61c:	lea    r8,[r8+r8*4]
  40b620:	lea    r8,[rax+r8*8+0x738]
  40b628:	vmovups xmm1,XMMWORD PTR [r8]
  40b62d:	vmovups XMMWORD PTR [rcx],xmm1
  40b631:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40b637:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40b63c:	mov    rax,QWORD PTR [r8+0x20]
  40b640:	mov    QWORD PTR [rcx+0x20],rax
  40b644:	vpshufd xmm1,xmm0,0xee
  40b649:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40b64f:	mov    QWORD PTR [rsp+0x10],rdx
  40b654:	vmovq  rax,xmm0
  40b659:	mov    r15,rax
  40b65c:	test   r15,r15
  40b65f:	jne    40b677 <__swc_fn_ff58629f_000061_1badc238+0x337>
  40b661:	mov    rcx,rbx
  40b664:	mov    rdx,QWORD PTR [rsp+0x8]
  40b669:	mov    r8,r13
  40b66c:	mov    r9,r12
  40b66f:	call   40af30 <__swc_fn_ff58629f_000055_da36318f>
  40b674:	mov    r15,rax
  40b677:	test   r15,r15
  40b67a:	je     40b6bb <__swc_fn_ff58629f_000061_1badc238+0x37b>
  40b67c:	cmp    QWORD PTR [r12],r14
  40b680:	jae    40b6bb <__swc_fn_ff58629f_000061_1badc238+0x37b>
  40b682:	mov    rax,r15
  40b685:	add    rax,QWORD PTR [r12]
  40b689:	mov    rdx,r14
  40b68c:	sub    rdx,QWORD PTR [r12]
  40b690:	mov    rcx,rax
  40b693:	call   4072a0 <__swc_fn_ff58629f_000003_644dadb7>
  40b698:	test   al,al
  40b69a:	je     40b6a3 <__swc_fn_ff58629f_000061_1badc238+0x363>
  40b69c:	mov    QWORD PTR [rsp+0x10],r14
  40b6a1:	jmp    40b6bb <__swc_fn_ff58629f_000061_1badc238+0x37b>
  40b6a3:	mov    rcx,rbx
  40b6a6:	mov    rdx,r15
  40b6a9:	mov    r8,QWORD PTR [rsp+0x8]
  40b6ae:	mov    r9,QWORD PTR [rsp+0x10]
  40b6b3:	call   40b040 <__swc_fn_ff58629f_000058_033ce1da>
  40b6b8:	xor    r15d,r15d
  40b6bb:	test   r15,r15
  40b6be:	jne    40b73a <__swc_fn_ff58629f_000061_1badc238+0x3fa>
  40b6c0:	cmp    r14,0x10000
  40b6c7:	ja     40b6ce <__swc_fn_ff58629f_000061_1badc238+0x38e>
  40b6c9:	mov    rax,r14
  40b6cc:	jmp    40b71f <__swc_fn_ff58629f_000061_1badc238+0x3df>
  40b6ce:	xor    eax,eax
  40b6d0:	lea    rcx,[r14-0x1]
  40b6d4:	lzcnt  rax,rcx
  40b6d9:	mov    ecx,0x3f
  40b6de:	sub    rcx,rax
  40b6e1:	mov    eax,0x1
  40b6e6:	lea    rcx,[rcx-0x3]
  40b6ea:	shl    rax,cl
  40b6ed:	mov    rcx,rax
  40b6f0:	cmp    rax,0x1000
  40b6f7:	mov    eax,0x1000
  40b6fc:	cmovb  rcx,rax
  40b700:	mov    rdx,0xffffffffffffffff
  40b707:	sub    rdx,rcx
  40b70a:	mov    rax,r14
  40b70d:	lea    r8,[r14+rcx*1-0x1]
  40b712:	neg    rcx
  40b715:	and    r8,rcx
  40b718:	cmp    r14,rdx
  40b71b:	cmovbe rax,r8
  40b71f:	mov    QWORD PTR [rsp+0x8],rax
  40b724:	mov    QWORD PTR [rsp+0x10],r14
  40b729:	mov    rcx,rbx
  40b72c:	mov    rdx,rax
  40b72f:	mov    r8,r14
  40b732:	call   40aaa0 <__swc_fn_ff58629f_000037_92e867c2>
  40b737:	mov    r15,rax
  40b73a:	test   r15,r15
  40b73d:	jne    40b74b <__swc_fn_ff58629f_000061_1badc238+0x40b>
  40b73f:	mov    r13,QWORD PTR [rsp+0x20]
  40b744:	mov    rsi,QWORD PTR [rsp+0x38]
  40b749:	jmp    40b787 <__swc_fn_ff58629f_000061_1badc238+0x447>
  40b74b:	mov    rax,r15
  40b74e:	add    rax,QWORD PTR [rsp+0x28]
  40b753:	mov    r13,QWORD PTR [rsp+0x20]
  40b758:	test   r13d,r13d
  40b75b:	mov    rcx,r13
  40b75e:	mov    edx,0x8
  40b763:	cmove  ecx,edx
  40b766:	dec    rcx
  40b769:	mov    rdx,0xffffffffffffffff
  40b770:	sub    rdx,rcx
  40b773:	cmp    rax,rdx
  40b776:	jbe    40b77c <__swc_fn_ff58629f_000061_1badc238+0x43c>
  40b778:	xor    eax,eax
  40b77a:	jmp    40b784 <__swc_fn_ff58629f_000061_1badc238+0x444>
  40b77c:	add    rax,rcx
  40b77f:	andn   rax,rcx,rax
  40b784:	mov    rsi,rax
  40b787:	mov    rax,QWORD PTR [rsp+0x8]
  40b78c:	test   r15,r15
  40b78f:	je     40b798 <__swc_fn_ff58629f_000061_1badc238+0x458>
  40b791:	mov    rdi,QWORD PTR [rsp+0x18]
  40b796:	jmp    40b7aa <__swc_fn_ff58629f_000061_1badc238+0x46a>
  40b798:	mov    rdi,QWORD PTR [rsp+0x18]
  40b79d:	mov    QWORD PTR [rdi+0x40],0x0
  40b7a5:	jmp    40b826 <__swc_fn_ff58629f_000061_1badc238+0x4e6>
  40b7aa:	lea    rdx,[rsi-0x58]
  40b7ae:	mov    QWORD PTR [rsi-0x58],r15
  40b7b2:	mov    QWORD PTR [rsi-0x50],rax
  40b7b6:	mov    rax,QWORD PTR [rsp+0x10]
  40b7bb:	mov    QWORD PTR [rsi-0x48],rax
  40b7bf:	mov    QWORD PTR [rsi-0x40],rsi
  40b7c3:	mov    rax,QWORD PTR [rdi+0x48]
  40b7c7:	mov    QWORD PTR [rsi-0x38],rax
  40b7cb:	mov    rax,QWORD PTR [rsp+0x30]
  40b7d0:	mov    QWORD PTR [rsi-0x30],rax
  40b7d4:	mov    DWORD PTR [rsi-0x10],r13d
  40b7d8:	mov    QWORD PTR [rsi-0x28],0x0
  40b7e0:	mov    QWORD PTR [rsi-0x20],0x0
  40b7e8:	add    r15,QWORD PTR [r12]
  40b7ec:	sub    r15,rsi
  40b7ef:	mov    QWORD PTR [rsi-0x30],r15
  40b7f3:	mov    rcx,QWORD PTR [rbx+0x250]
  40b7fa:	nop    WORD PTR [rax+rax*1+0x0]
  40b800:	lea    r8,[rcx+r15*1]
  40b804:	mov    rax,rcx
  40b807:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40b810:	cmp    rax,rcx
  40b813:	je     40b81a <__swc_fn_ff58629f_000061_1badc238+0x4da>
  40b815:	mov    rcx,rax
  40b818:	jmp    40b800 <__swc_fn_ff58629f_000061_1badc238+0x4c0>
  40b81a:	mov    rcx,rbx
  40b81d:	call   40e130 <__swc_fn_ff58629f_000053_a8a124d6>
  40b822:	mov    QWORD PTR [rdi+0x40],rsi
  40b826:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40b82c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40b832:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40b838:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40b83e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40b847:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40b850:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40b859:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40b862:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40b86b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40b874:	add    rsp,0xf0
  40b87b:	pop    rsi
  40b87c:	pop    rdi
  40b87d:	pop    r15
  40b87f:	pop    r14
  40b881:	pop    r13
  40b883:	pop    r12
  40b885:	pop    rbx
  40b886:	ret
	...

000000000040b890 <__swc_fn_ff58629f_000064_6905bec4>:
  40b890:	push   rbx
  40b891:	push   r12
  40b893:	push   rdi
  40b894:	push   rsi
  40b895:	sub    rsp,0xb8
  40b89c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40b8a2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40b8a8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40b8ae:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40b8b4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40b8ba:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40b8c0:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40b8c6:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40b8cf:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40b8d8:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40b8e1:	mov    rbx,rdx
  40b8e4:	mov    r12,rcx
  40b8e7:	cmp    DWORD PTR [rbx+0x58],0x0
  40b8eb:	je     40b905 <__swc_fn_ff58629f_000064_6905bec4+0x75>
  40b8ed:	mov    eax,DWORD PTR [rbx+0x58]
  40b8f0:	sub    eax,0x1
  40b8f3:	test   DWORD PTR [rbx+0x58],eax
  40b8f6:	je     40b905 <__swc_fn_ff58629f_000064_6905bec4+0x75>
  40b8f8:	mov    QWORD PTR [rbx+0x40],0x0
  40b900:	jmp    40bb17 <__swc_fn_ff58629f_000064_6905bec4+0x287>
  40b905:	cmp    QWORD PTR [rbx+0x48],0x0
  40b90a:	jne    40b919 <__swc_fn_ff58629f_000064_6905bec4+0x89>
  40b90c:	mov    QWORD PTR [rbx+0x40],0x0
  40b914:	jmp    40bb17 <__swc_fn_ff58629f_000064_6905bec4+0x287>
  40b919:	lea    rax,[rsp+0x8]
  40b91e:	mov    rcx,QWORD PTR [rbx+0x48]
  40b922:	cmp    rcx,0x8
  40b926:	ja     40b930 <__swc_fn_ff58629f_000064_6905bec4+0xa0>
  40b928:	mov    DWORD PTR [rax],0x0
  40b92e:	jmp    40b98b <__swc_fn_ff58629f_000064_6905bec4+0xfb>
  40b930:	cmp    rcx,0x80
  40b937:	ja     40b947 <__swc_fn_ff58629f_000064_6905bec4+0xb7>
  40b939:	lea    rcx,[rcx+0xf]
  40b93d:	shr    rcx,0x4
  40b941:	mov    DWORD PTR [rsp+0x8],ecx
  40b945:	jmp    40b98b <__swc_fn_ff58629f_000064_6905bec4+0xfb>
  40b947:	cmp    rcx,0x10000
  40b94e:	jbe    40b958 <__swc_fn_ff58629f_000064_6905bec4+0xc8>
  40b950:	mov    DWORD PTR [rax],0xffffffff
  40b956:	jmp    40b98b <__swc_fn_ff58629f_000064_6905bec4+0xfb>
  40b958:	dec    rcx
  40b95b:	xor    edx,edx
  40b95d:	lzcnt  rdx,rcx
  40b962:	mov    r8d,0x3f
  40b968:	sub    r8d,edx
  40b96b:	lea    edx,[r8-0x2]
  40b96f:	shrx   rcx,rcx,rdx
  40b974:	and    ecx,0x3
  40b977:	lea    edx,[r8-0x7]
  40b97b:	lea    edx,[rdx*4+0x0]
  40b982:	lea    edx,[rdx+0x9]
  40b985:	add    edx,ecx
  40b987:	mov    DWORD PTR [rsp+0x8],edx
  40b98b:	cmp    DWORD PTR [rax],0x0
  40b98e:	jne    40b99e <__swc_fn_ff58629f_000064_6905bec4+0x10e>
  40b990:	cmp    DWORD PTR [rbx+0x58],0x8
  40b994:	jbe    40b99e <__swc_fn_ff58629f_000064_6905bec4+0x10e>
  40b996:	mov    DWORD PTR [rsp+0x8],0x1
  40b99e:	cmp    DWORD PTR [rbx+0x58],0x10
  40b9a2:	jbe    40ba21 <__swc_fn_ff58629f_000064_6905bec4+0x191>
  40b9a8:	cmp    DWORD PTR [rbx+0x58],0x40
  40b9ac:	ja     40ba21 <__swc_fn_ff58629f_000064_6905bec4+0x191>
  40b9ae:	cmp    DWORD PTR [rax],0xffffffff
  40b9b1:	je     40ba21 <__swc_fn_ff58629f_000064_6905bec4+0x191>
  40b9b3:	mov    ecx,DWORD PTR [rsp+0x8]
  40b9b7:	mov    edx,DWORD PTR [rbx+0x58]
  40b9ba:	dec    rdx
  40b9bd:	cmp    ecx,0x2d
  40b9c0:	jae    40ba18 <__swc_fn_ff58629f_000064_6905bec4+0x188>
  40b9c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40b9cc:	nop    DWORD PTR [rax+0x0]
  40b9d0:	mov    r8d,ecx
  40b9d3:	test   ecx,ecx
  40b9d5:	jne    40b9df <__swc_fn_ff58629f_000064_6905bec4+0x14f>
  40b9d7:	mov    r8d,0x8
  40b9dd:	jmp    40ba0b <__swc_fn_ff58629f_000064_6905bec4+0x17b>
  40b9df:	cmp    r8d,0x8
  40b9e3:	ja     40b9eb <__swc_fn_ff58629f_000064_6905bec4+0x15b>
  40b9e5:	shl    r8,0x4
  40b9e9:	jmp    40ba0b <__swc_fn_ff58629f_000064_6905bec4+0x17b>
  40b9eb:	lea    r8d,[r8-0x9]
  40b9ef:	mov    r9d,r8d
  40b9f2:	shr    r9d,0x2
  40b9f6:	and    r8d,0x3
  40b9fa:	lea    r9d,[r9+0x7]
  40b9fe:	lea    r9d,[r9-0x2]
  40ba02:	lea    r8d,[r8+0x5]
  40ba06:	shlx   r8,r8,r9
  40ba0b:	test   r8,rdx
  40ba0e:	je     40ba1d <__swc_fn_ff58629f_000064_6905bec4+0x18d>
  40ba10:	add    ecx,0x1
  40ba13:	cmp    ecx,0x2d
  40ba16:	jb     40b9d0 <__swc_fn_ff58629f_000064_6905bec4+0x140>
  40ba18:	mov    ecx,0xffffffff
  40ba1d:	mov    DWORD PTR [rsp+0x8],ecx
  40ba21:	mov    ecx,DWORD PTR [rsp+0x8]
  40ba25:	cmp    ecx,0xffffffff
  40ba28:	je     40ba30 <__swc_fn_ff58629f_000064_6905bec4+0x1a0>
  40ba2a:	cmp    DWORD PTR [rbx+0x58],0x40
  40ba2e:	jbe    40ba43 <__swc_fn_ff58629f_000064_6905bec4+0x1b3>
  40ba30:	mov    rcx,r12
  40ba33:	mov    rdx,rbx
  40ba36:	mov    r8d,DWORD PTR [rax]
  40ba39:	call   40b340 <__swc_fn_ff58629f_000061_1badc238>
  40ba3e:	jmp    40bb17 <__swc_fn_ff58629f_000064_6905bec4+0x287>
  40ba43:	lea    rax,[rip+0x155b6]        # 421000 <__swc_data_base_ff58629f>
  40ba4a:	mov    rax,QWORD PTR [rax]
  40ba4d:	cmp    rax,0xffffffffffffffff
  40ba51:	je     40ba60 <__swc_fn_ff58629f_000064_6905bec4+0x1d0>
  40ba53:	mov    eax,eax
  40ba55:	mov    edi,eax
  40ba57:	xor    eax,eax
  40ba59:	call   407000 <pthread_getspecific@plt>
  40ba5e:	jmp    40ba62 <__swc_fn_ff58629f_000064_6905bec4+0x1d2>
  40ba60:	xor    eax,eax
  40ba62:	test   rax,rax
  40ba65:	jne    40ba74 <__swc_fn_ff58629f_000064_6905bec4+0x1e4>
  40ba67:	call   40a9e0 <__swc_fn_ff58629f_000031_ed8d61a9>
  40ba6c:	mov    rcx,rax
  40ba6f:	call   40fe00 <__swc_fn_ff58629f_000128_9c45d2d7>
  40ba74:	test   rax,rax
  40ba77:	je     40ba84 <__swc_fn_ff58629f_000064_6905bec4+0x1f4>
  40ba79:	cmp    QWORD PTR [rax],r12
  40ba7c:	jne    40ba84 <__swc_fn_ff58629f_000064_6905bec4+0x1f4>
  40ba7e:	cmp    DWORD PTR [rax+0x20],0x0
  40ba82:	je     40ba8f <__swc_fn_ff58629f_000064_6905bec4+0x1ff>
  40ba84:	mov    rcx,r12
  40ba87:	mov    rdx,rax
  40ba8a:	call   40dd70 <__swc_fn_ff58629f_000041_ed1cda78>
  40ba8f:	test   rax,rax
  40ba92:	jne    40ba9e <__swc_fn_ff58629f_000064_6905bec4+0x20e>
  40ba94:	mov    QWORD PTR [rbx+0x40],0x0
  40ba9c:	jmp    40bb17 <__swc_fn_ff58629f_000064_6905bec4+0x287>
  40ba9e:	lea    r8,[rsp+0xc]
  40baa3:	mov    ecx,DWORD PTR [rsp+0x8]
  40baa7:	mov    DWORD PTR [rsp+0xc],ecx
  40baab:	mov    ecx,DWORD PTR [r8]
  40baae:	lea    rcx,[rcx+rcx*4]
  40bab2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40bab7:	test   rcx,rcx
  40baba:	je     40baf3 <__swc_fn_ff58629f_000064_6905bec4+0x263>
  40babc:	mov    rdx,QWORD PTR [rcx]
  40babf:	test   rdx,rdx
  40bac2:	je     40bad0 <__swc_fn_ff58629f_000064_6905bec4+0x240>
  40bac4:	mov    r9,QWORD PTR [rdx]
  40bac7:	mov    QWORD PTR [rcx],r9
  40baca:	add    DWORD PTR [rcx+0x28],0x1
  40bace:	jmp    40baee <__swc_fn_ff58629f_000064_6905bec4+0x25e>
  40bad0:	mov    rdx,QWORD PTR [rcx+0x18]
  40bad4:	cmp    QWORD PTR [rcx+0x20],rdx
  40bad8:	jae    40baec <__swc_fn_ff58629f_000064_6905bec4+0x25c>
  40bada:	mov    rdx,QWORD PTR [rcx+0x20]
  40bade:	mov    r9d,DWORD PTR [rcx+0x2c]
  40bae2:	add    QWORD PTR [rcx+0x20],r9
  40bae6:	add    DWORD PTR [rcx+0x28],0x1
  40baea:	jmp    40baee <__swc_fn_ff58629f_000064_6905bec4+0x25e>
  40baec:	xor    edx,edx
  40baee:	test   rdx,rdx
  40baf1:	jne    40bb04 <__swc_fn_ff58629f_000064_6905bec4+0x274>
  40baf3:	mov    rcx,r12
  40baf6:	mov    rdx,rax
  40baf9:	mov    r8d,DWORD PTR [r8]
  40bafc:	call   40dee0 <__swc_fn_ff58629f_000050_e33921d7>
  40bb01:	mov    rdx,rax
  40bb04:	test   rdx,rdx
  40bb07:	jne    40bb13 <__swc_fn_ff58629f_000064_6905bec4+0x283>
  40bb09:	mov    QWORD PTR [rbx+0x40],0x0
  40bb11:	jmp    40bb17 <__swc_fn_ff58629f_000064_6905bec4+0x287>
  40bb13:	mov    QWORD PTR [rbx+0x40],rdx
  40bb17:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40bb1d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40bb23:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40bb29:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40bb2f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40bb35:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40bb3b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40bb41:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40bb4a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40bb53:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40bb5c:	add    rsp,0xb8
  40bb63:	pop    rsi
  40bb64:	pop    rdi
  40bb65:	pop    r12
  40bb67:	pop    rbx
  40bb68:	ret
  40bb69:	add    BYTE PTR [rax],al
  40bb6b:	add    BYTE PTR [rax],al
  40bb6d:	add    BYTE PTR [rax],al
	...

000000000040bb70 <__swc_fn_ff58629f_000067_381f5b88>:
  40bb70:	ret
	...

000000000040bb80 <__swc_fn_ff58629f_000070_2cd83140>:
  40bb80:	push   r12
  40bb82:	push   r13
  40bb84:	push   r14
  40bb86:	push   rdi
  40bb87:	push   rsi
  40bb88:	sub    rsp,0x1a0
  40bb8f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40bb98:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40bba1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40bbaa:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40bbb3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40bbbc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40bbc5:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40bbce:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40bbd7:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40bbe0:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40bbe9:	mov    r12,rdx
  40bbec:	mov    r13,rcx
  40bbef:	mov    rax,QWORD PTR [r12+0x48]
  40bbf4:	mov    ecx,DWORD PTR [r12+0x58]
  40bbf9:	lea    rdx,[rax-0x1]
  40bbfd:	cmp    rdx,0x10000
  40bc04:	jae    40bcfe <__swc_fn_ff58629f_000070_2cd83140+0x17e>
  40bc0a:	cmp    rax,0x8
  40bc0e:	ja     40bc15 <__swc_fn_ff58629f_000070_2cd83140+0x95>
  40bc10:	xor    r14d,r14d
  40bc13:	jmp    40bc67 <__swc_fn_ff58629f_000070_2cd83140+0xe7>
  40bc15:	cmp    rax,0x80
  40bc1c:	ja     40bc28 <__swc_fn_ff58629f_000070_2cd83140+0xa8>
  40bc1e:	lea    r14,[rax+0xf]
  40bc22:	shr    r14,0x4
  40bc26:	jmp    40bc67 <__swc_fn_ff58629f_000070_2cd83140+0xe7>
  40bc28:	cmp    rax,0x10000
  40bc2f:	jbe    40bc39 <__swc_fn_ff58629f_000070_2cd83140+0xb9>
  40bc31:	mov    r14d,0xffffffff
  40bc37:	jmp    40bc67 <__swc_fn_ff58629f_000070_2cd83140+0xe7>
  40bc39:	xor    eax,eax
  40bc3b:	lzcnt  rax,rdx
  40bc40:	mov    r8d,0x3f
  40bc46:	sub    r8d,eax
  40bc49:	lea    eax,[r8-0x2]
  40bc4d:	shrx   rax,rdx,rax
  40bc52:	and    eax,0x3
  40bc55:	lea    edx,[r8-0x7]
  40bc59:	lea    edx,[rdx*4+0x0]
  40bc60:	lea    edx,[rdx+0x9]
  40bc63:	lea    r14d,[rdx+rax*1]
  40bc67:	cmp    ecx,0x8
  40bc6a:	jbe    40bc83 <__swc_fn_ff58629f_000070_2cd83140+0x103>
  40bc6c:	cmp    ecx,0x10
  40bc6f:	jne    40bcfe <__swc_fn_ff58629f_000070_2cd83140+0x17e>
  40bc75:	test   r14d,r14d
  40bc78:	mov    eax,0x1
  40bc7d:	cmove  r14d,eax
  40bc81:	jmp    40bc8a <__swc_fn_ff58629f_000070_2cd83140+0x10a>
  40bc83:	lea    eax,[rcx-0x1]
  40bc86:	test   eax,ecx
  40bc88:	jne    40bcfe <__swc_fn_ff58629f_000070_2cd83140+0x17e>
  40bc8a:	lea    rax,[rip+0x1536f]        # 421000 <__swc_data_base_ff58629f>
  40bc91:	mov    rax,QWORD PTR [rax]
  40bc94:	cmp    rax,0xffffffffffffffff
  40bc98:	je     40bca7 <__swc_fn_ff58629f_000070_2cd83140+0x127>
  40bc9a:	mov    eax,eax
  40bc9c:	mov    edi,eax
  40bc9e:	xor    eax,eax
  40bca0:	call   407000 <pthread_getspecific@plt>
  40bca5:	jmp    40bca9 <__swc_fn_ff58629f_000070_2cd83140+0x129>
  40bca7:	xor    eax,eax
  40bca9:	test   rax,rax
  40bcac:	je     40bcfe <__swc_fn_ff58629f_000070_2cd83140+0x17e>
  40bcae:	cmp    QWORD PTR [rax],r13
  40bcb1:	jne    40bcfe <__swc_fn_ff58629f_000070_2cd83140+0x17e>
  40bcb3:	lea    rcx,[r14+r14*4]
  40bcb7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40bcbc:	test   rax,rax
  40bcbf:	je     40bcfe <__swc_fn_ff58629f_000070_2cd83140+0x17e>
  40bcc1:	mov    rcx,QWORD PTR [rax]
  40bcc4:	test   rcx,rcx
  40bcc7:	je     40bcd5 <__swc_fn_ff58629f_000070_2cd83140+0x155>
  40bcc9:	mov    rdx,QWORD PTR [rcx]
  40bccc:	mov    QWORD PTR [rax],rdx
  40bccf:	add    DWORD PTR [rax+0x28],0x1
  40bcd3:	jmp    40bcf2 <__swc_fn_ff58629f_000070_2cd83140+0x172>
  40bcd5:	mov    rcx,QWORD PTR [rax+0x18]
  40bcd9:	cmp    QWORD PTR [rax+0x20],rcx
  40bcdd:	jae    40bcf0 <__swc_fn_ff58629f_000070_2cd83140+0x170>
  40bcdf:	mov    rcx,QWORD PTR [rax+0x20]
  40bce3:	mov    edx,DWORD PTR [rax+0x2c]
  40bce6:	add    QWORD PTR [rax+0x20],rdx
  40bcea:	add    DWORD PTR [rax+0x28],0x1
  40bcee:	jmp    40bcf2 <__swc_fn_ff58629f_000070_2cd83140+0x172>
  40bcf0:	xor    ecx,ecx
  40bcf2:	test   rcx,rcx
  40bcf5:	je     40bcfe <__swc_fn_ff58629f_000070_2cd83140+0x17e>
  40bcf7:	mov    QWORD PTR [r12+0x40],rcx
  40bcfc:	jmp    40bd09 <__swc_fn_ff58629f_000070_2cd83140+0x189>
  40bcfe:	mov    rcx,r13
  40bd01:	mov    rdx,r12
  40bd04:	call   40e960 <__swc_fn_ff58629f_000071_7e144e9b>
  40bd09:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40bd12:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40bd1b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40bd24:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40bd2d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40bd36:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40bd3f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40bd48:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40bd51:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40bd5a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40bd63:	add    rsp,0x1a0
  40bd6a:	pop    rsi
  40bd6b:	pop    rdi
  40bd6c:	pop    r14
  40bd6e:	pop    r13
  40bd70:	pop    r12
  40bd72:	ret
	...

000000000040bd80 <__swc_fn_ff58629f_000073_c77adf75>:
  40bd80:	push   r12
  40bd82:	push   r13
  40bd84:	push   r14
  40bd86:	push   r15
  40bd88:	push   rdi
  40bd89:	push   rsi
  40bd8a:	sub    rsp,0x188
  40bd91:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40bd9a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40bda3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40bdac:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40bdb5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40bdbe:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40bdc7:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40bdd0:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40bdd9:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40bde2:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40bdeb:	mov    r12,rdx
  40bdee:	mov    r13,rcx
  40bdf1:	mov    r14,QWORD PTR [r12+0x40]
  40bdf6:	lea    rax,[rip+0x17273]        # 423070 <__swc_bss_base_ff58629f+0x30>
  40bdfd:	mov    rcx,r14
  40be00:	sub    rcx,QWORD PTR [rax+0x8]
  40be04:	mov    rax,QWORD PTR [rip+0x17275]        # 423080 <__swc_bss_base_ff58629f+0x40>
  40be0b:	cmp    rcx,rax
  40be0e:	jae    40be3a <__swc_fn_ff58629f_000073_c77adf75+0xba>
  40be10:	mov    rax,r14
  40be13:	and    rax,0xffffffffffc00000
  40be1a:	mov    rcx,r14
  40be1d:	shr    rcx,0x10
  40be21:	and    ecx,0x3f
  40be24:	mov    edx,DWORD PTR [rax+0x28]
  40be27:	shrx   ecx,ecx,edx
  40be2c:	shl    rcx,0x4
  40be30:	lea    r15,[rax+rcx*8+0x80]
  40be38:	jmp    40be45 <__swc_fn_ff58629f_000073_c77adf75+0xc5>
  40be3a:	mov    rcx,r14
  40be3d:	call   40a910 <__swc_fn_ff58629f_000022_77c2d682>
  40be42:	mov    r15,rax
  40be45:	test   r15,r15
  40be48:	je     40beef <__swc_fn_ff58629f_000073_c77adf75+0x16f>
  40be4e:	lea    rax,[rip+0x151ab]        # 421000 <__swc_data_base_ff58629f>
  40be55:	mov    rax,QWORD PTR [rax]
  40be58:	cmp    rax,0xffffffffffffffff
  40be5c:	je     40be6b <__swc_fn_ff58629f_000073_c77adf75+0xeb>
  40be5e:	mov    eax,eax
  40be60:	mov    edi,eax
  40be62:	xor    eax,eax
  40be64:	call   407000 <pthread_getspecific@plt>
  40be69:	jmp    40be6d <__swc_fn_ff58629f_000073_c77adf75+0xed>
  40be6b:	xor    eax,eax
  40be6d:	mov    rcx,QWORD PTR [r15+0x40]
  40be71:	cmp    rcx,rax
  40be74:	jne    40bed4 <__swc_fn_ff58629f_000073_c77adf75+0x154>
  40be76:	test   rax,rax
  40be79:	je     40beef <__swc_fn_ff58629f_000073_c77adf75+0x16f>
  40be7b:	mov    ecx,DWORD PTR [r15+0x6c]
  40be7f:	test   ecx,ecx
  40be81:	je     40bea1 <__swc_fn_ff58629f_000073_c77adf75+0x121>
  40be83:	mov    rcx,r13
  40be86:	mov    rdx,rax
  40be89:	mov    r8,r15
  40be8c:	mov    QWORD PTR [rsp+0xd8],rax
  40be94:	call   40de70 <__swc_fn_ff58629f_000047_3d3eceb4>
  40be99:	mov    rax,QWORD PTR [rsp+0xd8]
  40bea1:	mov    rcx,QWORD PTR [r15]
  40bea4:	mov    QWORD PTR [r14],rcx
  40bea7:	mov    QWORD PTR [r15],r14
  40beaa:	sub    DWORD PTR [r15+0x28],0x1
  40beaf:	jne    40bee4 <__swc_fn_ff58629f_000073_c77adf75+0x164>
  40beb1:	movzx  ecx,BYTE PTR [r15+0x39]
  40beb6:	lea    rcx,[rcx+rcx*4]
  40beba:	lea    rcx,[rax+rcx*8+0x28]
  40bebf:	cmp    QWORD PTR [rcx],r15
  40bec2:	je     40bee4 <__swc_fn_ff58629f_000073_c77adf75+0x164>
  40bec4:	mov    rcx,r13
  40bec7:	mov    rdx,rax
  40beca:	mov    r8,r15
  40becd:	call   407d80 <__swc_fn_ff58629f_000051_5b91e689>
  40bed2:	jmp    40bee4 <__swc_fn_ff58629f_000073_c77adf75+0x164>
  40bed4:	test   rcx,rcx
  40bed7:	je     40beef <__swc_fn_ff58629f_000073_c77adf75+0x16f>
  40bed9:	mov    rcx,r15
  40bedc:	mov    rdx,r14
  40bedf:	call   40a550 <__swc_fn_ff58629f_000010_186cd0c2>
  40bee4:	mov    QWORD PTR [r12+0x40],0x0
  40beed:	jmp    40befa <__swc_fn_ff58629f_000073_c77adf75+0x17a>
  40beef:	mov    rcx,r13
  40bef2:	mov    rdx,r12
  40bef5:	call   40e980 <__swc_fn_ff58629f_000074_9eaf4878>
  40befa:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40bf03:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40bf0c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40bf15:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40bf1e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40bf27:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40bf30:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40bf39:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40bf42:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40bf4b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40bf54:	add    rsp,0x188
  40bf5b:	pop    rsi
  40bf5c:	pop    rdi
  40bf5d:	pop    r15
  40bf5f:	pop    r14
  40bf61:	pop    r13
  40bf63:	pop    r12
  40bf65:	ret
	...

000000000040bf70 <__swc_fn_ff58629f_000076_d8e626b0>:
  40bf70:	sub    rsp,0x8
  40bf74:	mov    rax,rdx
  40bf77:	mov    rdx,QWORD PTR [rax+0x40]
  40bf7b:	mov    r8,rax
  40bf7e:	call   40bb70 <__swc_fn_ff58629f_000067_381f5b88>
  40bf83:	add    rsp,0x8
  40bf87:	ret
	...

000000000040bf90 <__swc_fn_ff58629f_000079_29fad089>:
  40bf90:	push   rsi
  40bf91:	push   rdi
  40bf92:	sub    rsp,0x8
  40bf96:	cmp    rcx,0xffffffffffffffef
  40bf9a:	ja     40bfc0 <__swc_fn_ff58629f_000079_29fad089+0x30>
  40bf9c:	xor    esi,esi
  40bf9e:	lea    rax,[rcx+0x100f]
  40bfa5:	and    rax,0xfffffffffffff000
  40bfac:	lea    rcx,[rcx+0x10]
  40bfb0:	cmp    rcx,0xfffffffffffff000
  40bfb7:	cmovbe rsi,rax
  40bfbb:	test   rsi,rsi
  40bfbe:	jne    40bfc9 <__swc_fn_ff58629f_000079_29fad089+0x39>
  40bfc0:	xor    eax,eax
  40bfc2:	add    rsp,0x8
  40bfc6:	pop    rdi
  40bfc7:	pop    rsi
  40bfc8:	ret
  40bfc9:	mov    rcx,rsi
  40bfcc:	call   40c620 <__swc_fn_ff58629f_000109_aa570b2b>
  40bfd1:	mov    rdi,rax
  40bfd4:	test   rax,rax
  40bfd7:	jne    40bfe2 <__swc_fn_ff58629f_000079_29fad089+0x52>
  40bfd9:	xor    eax,eax
  40bfdb:	add    rsp,0x8
  40bfdf:	pop    rdi
  40bfe0:	pop    rsi
  40bfe1:	ret
  40bfe2:	mov    rcx,rdi
  40bfe5:	mov    rdx,rsi
  40bfe8:	call   409240 <__swc_fn_ff58629f_000111_e724f834>
  40bfed:	test   al,al
  40bfef:	jne    40c005 <__swc_fn_ff58629f_000079_29fad089+0x75>
  40bff1:	mov    rcx,rdi
  40bff4:	mov    rdx,rsi
  40bff7:	call   40fab0 <__swc_fn_ff58629f_000113_25e345b1>
  40bffc:	xor    eax,eax
  40bffe:	add    rsp,0x8
  40c002:	pop    rdi
  40c003:	pop    rsi
  40c004:	ret
  40c005:	mov    QWORD PTR [rdi],rsi
  40c008:	mov    QWORD PTR [rdi+0x8],0x0
  40c010:	lea    rax,[rdi+0x10]
  40c014:	add    rsp,0x8
  40c018:	pop    rdi
  40c019:	pop    rsi
  40c01a:	ret
  40c01b:	add    BYTE PTR [rax],al
  40c01d:	add    BYTE PTR [rax],al
	...

000000000040c020 <__swc_fn_ff58629f_000082_9f4f5092>:
  40c020:	sub    rsp,0x8
  40c024:	cmp    BYTE PTR [rcx+0x2c],0x10
  40c028:	jne    40c033 <__swc_fn_ff58629f_000082_9f4f5092+0x13>
  40c02a:	test   DWORD PTR [rcx+0x28],0x80
  40c031:	je     40c03b <__swc_fn_ff58629f_000082_9f4f5092+0x1b>
  40c033:	mov    rax,rcx
  40c036:	add    rsp,0x8
  40c03a:	ret
  40c03b:	mov    rcx,QWORD PTR [rcx+0x40]
  40c03f:	call   40c020 <__swc_fn_ff58629f_000082_9f4f5092>
  40c044:	add    rsp,0x8
  40c048:	ret
	...

000000000040c060 <__swc_fn_ff58629f_000085_88128f21>:
  40c060:	push   rsi
  40c061:	push   rdi
  40c062:	push   r12
  40c064:	push   r13
  40c066:	sub    rsp,0x8
  40c06a:	mov    rsi,rdx
  40c06d:	mov    rdi,rcx
  40c070:	xor    r8d,r8d
  40c073:	call   4085a0 <__swc_fn_ff58629f_000090_9a1d717d>
  40c078:	test   al,al
  40c07a:	je     40c08c <__swc_fn_ff58629f_000085_88128f21+0x2c>
  40c07c:	mov    eax,0x1
  40c081:	add    rsp,0x8
  40c085:	pop    r13
  40c087:	pop    r12
  40c089:	pop    rdi
  40c08a:	pop    rsi
  40c08b:	ret
  40c08c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40c091:	je     40c0a0 <__swc_fn_ff58629f_000085_88128f21+0x40>
  40c093:	xor    eax,eax
  40c095:	add    rsp,0x8
  40c099:	pop    r13
  40c09b:	pop    r12
  40c09d:	pop    rdi
  40c09e:	pop    rsi
  40c09f:	ret
  40c0a0:	mov    r12,QWORD PTR [rsi+0x98]
  40c0a7:	mov    rax,QWORD PTR [rsi+0xa0]
  40c0ae:	mov    rsi,rax
  40c0b1:	xor    r13d,r13d
  40c0b4:	test   rsi,rsi
  40c0b7:	je     40c114 <__swc_fn_ff58629f_000085_88128f21+0xb4>
  40c0b9:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0c3:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0cd:	nop    DWORD PTR [rax]
  40c0d0:	lea    rax,[r13*8+0x0]
  40c0d8:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40c0dd:	mov    rcx,rax
  40c0e0:	call   40c020 <__swc_fn_ff58629f_000082_9f4f5092>
  40c0e5:	cmp    BYTE PTR [rax+0x2c],0xe
  40c0e9:	jne    40c10a <__swc_fn_ff58629f_000085_88128f21+0xaa>
  40c0eb:	mov    rcx,rdi
  40c0ee:	mov    rdx,rax
  40c0f1:	call   40c060 <__swc_fn_ff58629f_000085_88128f21>
  40c0f6:	test   al,al
  40c0f8:	je     40c10a <__swc_fn_ff58629f_000085_88128f21+0xaa>
  40c0fa:	mov    eax,0x1
  40c0ff:	add    rsp,0x8
  40c103:	pop    r13
  40c105:	pop    r12
  40c107:	pop    rdi
  40c108:	pop    rsi
  40c109:	ret
  40c10a:	add    r13,0x1
  40c10e:	sub    rsi,0x1
  40c112:	jne    40c0d0 <__swc_fn_ff58629f_000085_88128f21+0x70>
  40c114:	xor    eax,eax
  40c116:	add    rsp,0x8
  40c11a:	pop    r13
  40c11c:	pop    r12
  40c11e:	pop    rdi
  40c11f:	pop    rsi
  40c120:	ret
	...

000000000040c130 <__swc_fn_ff58629f_000088_17711411>:
  40c130:	sub    rsp,0x18
  40c134:	vxorps xmm0,xmm0,xmm0
  40c138:	vmovdqu XMMWORD PTR [rsp],xmm0
  40c13d:	call   40eb90 <__swc_fn_ff58629f_000089_157b05de>
  40c142:	add    rsp,0x18
  40c146:	ret
	...

000000000040c150 <__swc_fn_ff58629f_000091_e6773530>:
  40c150:	sub    rsp,0x8
  40c154:	mov    rcx,QWORD PTR [rip+0x19be5]        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  40c15b:	test   rcx,rcx
  40c15e:	jne    40c170 <__swc_fn_ff58629f_000091_e6773530+0x20>
  40c160:	call   40a1a0 <__swc_fn_ff58629f_000165_e09accff>
  40c165:	lea    rcx,[rax+0x1]
  40c169:	mov    QWORD PTR [rip+0x19bd0],rcx        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  40c170:	dec    rcx
  40c173:	call   411880 <__swc_fn_ff58629f_000167_3130645d>
  40c178:	mov    rax,QWORD PTR [rax+0xc0]
  40c17f:	and    eax,0x1
  40c182:	setne  al
  40c185:	add    rsp,0x8
  40c189:	ret
	...

000000000040c1a0 <__swc_fn_ff58629f_000094_335e9a12>:
  40c1a0:	push   rbx
  40c1a1:	push   rsi
  40c1a2:	push   rdi
  40c1a3:	push   r12
  40c1a5:	sub    rsp,0x28
  40c1a9:	mov    rbx,rcx
  40c1ac:	call   408900 <__swc_fn_ff58629f_000093_344f5089>
  40c1b1:	mov    rcx,QWORD PTR [rip+0x19b88]        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  40c1b8:	test   rcx,rcx
  40c1bb:	jne    40c1cd <__swc_fn_ff58629f_000094_335e9a12+0x2d>
  40c1bd:	call   40a1a0 <__swc_fn_ff58629f_000165_e09accff>
  40c1c2:	lea    rcx,[rax+0x1]
  40c1c6:	mov    QWORD PTR [rip+0x19b73],rcx        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  40c1cd:	dec    rcx
  40c1d0:	call   411880 <__swc_fn_ff58629f_000167_3130645d>
  40c1d5:	mov    rsi,rax
  40c1d8:	lea    rcx,[rsp+0x8]
  40c1dd:	call   40efd0 <__swc_fn_ff58629f_000092_17e20532>
  40c1e2:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40c1e9:	mov    r12,QWORD PTR [rsi+0xbe8]
  40c1f0:	lea    rcx,[rsi+0x10]
  40c1f4:	call   40d170 <__swc_fn_ff58629f_000157_5c8b11d8>
  40c1f9:	mov    rcx,rsi
  40c1fc:	call   40f140 <__swc_fn_ff58629f_000101_295ddd7c>
  40c201:	vxorps xmm0,xmm0,xmm0
  40c205:	xor    eax,eax
  40c207:	cs nop WORD PTR [rax+rax*1+0x0]
  40c211:	cs nop WORD PTR [rax+rax*1+0x0]
  40c21b:	nop    DWORD PTR [rax+rax*1+0x0]
  40c220:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40c225:	add    rax,0x10
  40c229:	cmp    rax,0xbf0
  40c230:	jne    40c220 <__swc_fn_ff58629f_000094_335e9a12+0x80>
  40c232:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c238:	vmovups XMMWORD PTR [rsi],xmm0
  40c23c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c242:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40c24a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40c251:	mov    QWORD PTR [rsi+0xbe8],r12
  40c258:	mov    rcx,QWORD PTR [rip+0x19ae1]        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  40c25f:	test   rcx,rcx
  40c262:	jne    40c274 <__swc_fn_ff58629f_000094_335e9a12+0xd4>
  40c264:	call   40a1a0 <__swc_fn_ff58629f_000165_e09accff>
  40c269:	lea    rcx,[rax+0x1]
  40c26d:	mov    QWORD PTR [rip+0x19acc],rcx        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  40c274:	dec    rcx
  40c277:	call   411880 <__swc_fn_ff58629f_000167_3130645d>
  40c27c:	mov    rsi,rax
  40c27f:	mov    QWORD PTR [rsi+0xc0],rbx
  40c286:	and    ebx,0x1
  40c289:	jne    40c28d <__swc_fn_ff58629f_000094_335e9a12+0xed>
  40c28b:	xor    eax,eax
  40c28d:	test   rbx,rbx
  40c290:	sete   al
  40c293:	xor    cl,cl
  40c295:	xor    dl,dl
  40c297:	xor    r8b,r8b
  40c29a:	xor    r9b,r9b
  40c29d:	xor    r10b,r10b
  40c2a0:	mov    r11,rax
  40c2a3:	call   40e990 <__swc_fn_ff58629f_000077_e793b5e1>
  40c2a8:	lea    rbx,[rsp+0x18]
  40c2ad:	mov    rcx,rbx
  40c2b0:	call   40efd0 <__swc_fn_ff58629f_000092_17e20532>
  40c2b5:	lea    rcx,[rsi+0x10]
  40c2b9:	mov    edx,0x400000
  40c2be:	mov    r8,rbx
  40c2c1:	call   409ee0 <__swc_fn_ff58629f_000159_9d602c76>
  40c2c6:	lea    rcx,[rsi+0x68]
  40c2ca:	mov    edx,0x4000
  40c2cf:	mov    r8,rbx
  40c2d2:	call   409ee0 <__swc_fn_ff58629f_000159_9d602c76>
  40c2d7:	add    rsp,0x28
  40c2db:	pop    r12
  40c2dd:	pop    rdi
  40c2de:	pop    rsi
  40c2df:	pop    rbx
  40c2e0:	ret
	...

000000000040c2f0 <__swc_fn_ff58629f_000097_8b4a07e9>:
  40c2f0:	push   rbx
  40c2f1:	push   rsi
  40c2f2:	sub    rsp,0x18
  40c2f6:	mov    rbx,rcx
  40c2f9:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40c2fe:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c304:	mov    rsi,QWORD PTR [rbx+0x70]
  40c308:	lea    rcx,[rcx+0x18]
  40c30c:	call   40d170 <__swc_fn_ff58629f_000157_5c8b11d8>
  40c311:	lea    rcx,[rsp+0x8]
  40c316:	mov    rdx,rbx
  40c319:	mov    r8d,0x78
  40c31f:	call   408960 <__swc_fn_ff58629f_000096_f879630a>
  40c324:	mov    rax,rsi
  40c327:	add    rsp,0x18
  40c32b:	pop    rsi
  40c32c:	pop    rbx
  40c32d:	ret
	...

000000000040c330 <__swc_fn_ff58629f_000100_2ef16a3e>:
  40c330:	push   rsi
  40c331:	push   rdi
  40c332:	sub    rsp,0x8
  40c336:	cmp    QWORD PTR [rcx],0x0
  40c33a:	jne    40c343 <__swc_fn_ff58629f_000100_2ef16a3e+0x13>
  40c33c:	add    rsp,0x8
  40c340:	pop    rdi
  40c341:	pop    rsi
  40c342:	ret
  40c343:	mov    rsi,QWORD PTR [rcx]
  40c346:	mov    rax,QWORD PTR [rcx+0x8]
  40c34a:	test   rax,rax
  40c34d:	je     40c363 <__swc_fn_ff58629f_000100_2ef16a3e+0x33>
  40c34f:	test   DWORD PTR [rax+0x28],0x400000
  40c356:	je     40c363 <__swc_fn_ff58629f_000100_2ef16a3e+0x33>
  40c358:	mov    rcx,QWORD PTR [rax+0x30]
  40c35c:	test   rcx,rcx
  40c35f:	cmovne rax,rcx
  40c363:	lea    rdx,[rip+0x5e66]        # 4121d0 <__swc_rdata_base_ff58629f+0xc0>
  40c36a:	lea    rcx,[rip+0x5f47]        # 4122b8 <__swc_rdata_base_ff58629f+0x1a8>
  40c371:	mov    r8,rax
  40c374:	xor    r9d,r9d
  40c377:	xor    al,al
  40c379:	mov    r10,rax
  40c37c:	xor    r11d,r11d
  40c37f:	call   40c130 <__swc_fn_ff58629f_000088_17711411>
  40c384:	test   rax,rax
  40c387:	je     40c397 <__swc_fn_ff58629f_000100_2ef16a3e+0x67>
  40c389:	mov    rdi,QWORD PTR [rax+0x48]
  40c38d:	test   rdi,rdi
  40c390:	je     40c397 <__swc_fn_ff58629f_000100_2ef16a3e+0x67>
  40c392:	mov    rcx,rsi
  40c395:	call   rdi
  40c397:	add    rsp,0x8
  40c39b:	pop    rdi
  40c39c:	pop    rsi
  40c39d:	ret
	...

000000000040c3a0 <__swc_fn_ff58629f_000103_2ed36338>:
  40c3a0:	push   rbx
  40c3a1:	push   rsi
  40c3a2:	push   rdi
  40c3a3:	sub    rsp,0x20
  40c3a7:	mov    rbx,rdx
  40c3aa:	mov    rsi,rcx
  40c3ad:	mov    rcx,QWORD PTR [rip+0x1998c]        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  40c3b4:	test   rcx,rcx
  40c3b7:	jne    40c3c9 <__swc_fn_ff58629f_000103_2ed36338+0x29>
  40c3b9:	call   40a1a0 <__swc_fn_ff58629f_000165_e09accff>
  40c3be:	lea    rcx,[rax+0x1]
  40c3c2:	mov    QWORD PTR [rip+0x19977],rcx        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  40c3c9:	dec    rcx
  40c3cc:	call   411880 <__swc_fn_ff58629f_000167_3130645d>
  40c3d1:	mov    rdi,rax
  40c3d4:	mov    rax,QWORD PTR [rdi+0xbd0]
  40c3db:	xor    ecx,ecx
  40c3dd:	test   rax,rax
  40c3e0:	je     40c3e5 <__swc_fn_ff58629f_000103_2ed36338+0x45>
  40c3e2:	mov    rcx,QWORD PTR [rax]
  40c3e5:	call   40a2d0 <__swc_fn_ff58629f_000174_738eec22>
  40c3ea:	lea    rax,[rsp+0x8]
  40c3ef:	lea    rcx,[rdi+0x9c8]
  40c3f6:	mov    QWORD PTR [rsp+0x8],rcx
  40c3fb:	mov    QWORD PTR [rax+0x8],0x40
  40c403:	xor    ecx,ecx
  40c405:	mov    rdx,rax
  40c408:	call   40fbe0 <__swc_fn_ff58629f_000119_18cd3882>
  40c40d:	mov    DWORD PTR [rdi+0xbc8],eax
  40c413:	mov    rdi,QWORD PTR [rdi+0x990]
  40c41a:	test   rdi,rdi
  40c41d:	je     40c427 <__swc_fn_ff58629f_000103_2ed36338+0x87>
  40c41f:	mov    rcx,rsi
  40c422:	mov    rdx,rbx
  40c425:	call   rdi
  40c427:	call   40c150 <__swc_fn_ff58629f_000091_e6773530>
  40c42c:	test   al,al
  40c42e:	je     40c43e <__swc_fn_ff58629f_000103_2ed36338+0x9e>
  40c430:	mov    rcx,rsi
  40c433:	mov    rdx,rbx
  40c436:	xor    r8d,r8d
  40c439:	call   4093e0 <__swc_fn_ff58629f_000120_1601f378>
  40c43e:	mov    rcx,rsi
  40c441:	mov    rdx,rbx
  40c444:	call   408a60 <__swc_fn_ff58629f_000102_29a1093a>
  40c449:	call   40c9d0 <__swc_fn_ff58629f_000118_2b35b5e0>
  40c44e:	add    rsp,0x20
  40c452:	pop    rdi
  40c453:	pop    rsi
  40c454:	pop    rbx
  40c455:	ret
	...

000000000040c460 <__swc_fn_ff58629f_000106_77a5d54a>:
  40c460:	test   r8,r8
  40c463:	jne    40c468 <__swc_fn_ff58629f_000106_77a5d54a+0x8>
  40c465:	xor    eax,eax
  40c467:	ret
  40c468:	xor    eax,eax
  40c46a:	nop    WORD PTR [rax+rax*1+0x0]
  40c470:	mov    r9,r8
  40c473:	sub    r9,rax
  40c476:	cmp    r9,0x10
  40c47a:	jb     40c4c4 <__swc_fn_ff58629f_000106_77a5d54a+0x64>
  40c47c:	lea    r9,[rcx+rax*1]
  40c480:	lea    r10,[rdx+rax*1]
  40c484:	vmovups xmm0,XMMWORD PTR [r10]
  40c489:	vmovups xmm1,XMMWORD PTR [r9]
  40c48e:	vpcmpeqb xmm0,xmm1,xmm0
  40c492:	vpmovmskb r9d,xmm0
  40c496:	cmp    r9d,0xffff
  40c49d:	je     40c4be <__swc_fn_ff58629f_000106_77a5d54a+0x5e>
  40c49f:	not    r9d
  40c4a2:	xor    r8d,r8d
  40c4a5:	movzx  r9d,r9w
  40c4a9:	tzcnt  r8d,r9d
  40c4ae:	add    rax,r8
  40c4b1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4b5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4b9:	sub    ecx,eax
  40c4bb:	mov    eax,ecx
  40c4bd:	ret
  40c4be:	lea    rax,[rax+0x10]
  40c4c2:	jmp    40c470 <__swc_fn_ff58629f_000106_77a5d54a+0x10>
  40c4c4:	cmp    r9,0x8
  40c4c8:	jb     40c53b <__swc_fn_ff58629f_000106_77a5d54a+0xdb>
  40c4ca:	lea    r9,[rcx+rax*1]
  40c4ce:	lea    r10,[rdx+rax*1]
  40c4d2:	mov    r9,QWORD PTR [r9]
  40c4d5:	xor    r9,QWORD PTR [r10]
  40c4d8:	test   r9,r9
  40c4db:	je     40c4f9 <__swc_fn_ff58629f_000106_77a5d54a+0x99>
  40c4dd:	xor    r8d,r8d
  40c4e0:	tzcnt  r8,r9
  40c4e5:	shr    r8,0x3
  40c4e9:	add    rax,r8
  40c4ec:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4f0:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4f4:	sub    ecx,eax
  40c4f6:	mov    eax,ecx
  40c4f8:	ret
  40c4f9:	lea    rax,[rax+0x8]
  40c4fd:	cmp    rax,r8
  40c500:	jne    40c505 <__swc_fn_ff58629f_000106_77a5d54a+0xa5>
  40c502:	xor    eax,eax
  40c504:	ret
  40c505:	lea    rax,[r8-0x8]
  40c509:	lea    r8,[rcx+rax*1]
  40c50d:	lea    r9,[rdx+rax*1]
  40c511:	mov    r8,QWORD PTR [r8]
  40c514:	xor    r8,QWORD PTR [r9]
  40c517:	test   r8,r8
  40c51a:	je     40c538 <__swc_fn_ff58629f_000106_77a5d54a+0xd8>
  40c51c:	xor    r9d,r9d
  40c51f:	tzcnt  r9,r8
  40c524:	shr    r9,0x3
  40c528:	add    rax,r9
  40c52b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c52f:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c533:	sub    ecx,eax
  40c535:	mov    eax,ecx
  40c537:	ret
  40c538:	xor    eax,eax
  40c53a:	ret
  40c53b:	cmp    r9,0x4
  40c53f:	jb     40c5b2 <__swc_fn_ff58629f_000106_77a5d54a+0x152>
  40c541:	lea    r9,[rcx+rax*1]
  40c545:	lea    r10,[rdx+rax*1]
  40c549:	mov    r9d,DWORD PTR [r9]
  40c54c:	xor    r9d,DWORD PTR [r10]
  40c54f:	test   r9d,r9d
  40c552:	je     40c570 <__swc_fn_ff58629f_000106_77a5d54a+0x110>
  40c554:	xor    r8d,r8d
  40c557:	tzcnt  r8,r9
  40c55c:	shr    r8,0x3
  40c560:	add    rax,r8
  40c563:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c567:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c56b:	sub    ecx,eax
  40c56d:	mov    eax,ecx
  40c56f:	ret
  40c570:	lea    rax,[rax+0x4]
  40c574:	cmp    rax,r8
  40c577:	jne    40c57c <__swc_fn_ff58629f_000106_77a5d54a+0x11c>
  40c579:	xor    eax,eax
  40c57b:	ret
  40c57c:	lea    rax,[r8-0x4]
  40c580:	lea    r8,[rcx+rax*1]
  40c584:	lea    r9,[rdx+rax*1]
  40c588:	mov    r8d,DWORD PTR [r8]
  40c58b:	xor    r8d,DWORD PTR [r9]
  40c58e:	test   r8d,r8d
  40c591:	je     40c5af <__swc_fn_ff58629f_000106_77a5d54a+0x14f>
  40c593:	xor    r9d,r9d
  40c596:	tzcnt  r9,r8
  40c59b:	shr    r9,0x3
  40c59f:	add    rax,r9
  40c5a2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c5a6:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c5aa:	sub    ecx,eax
  40c5ac:	mov    eax,ecx
  40c5ae:	ret
  40c5af:	xor    eax,eax
  40c5b1:	ret
  40c5b2:	cmp    r9,0x2
  40c5b6:	jb     40c609 <__swc_fn_ff58629f_000106_77a5d54a+0x1a9>
  40c5b8:	lea    r9,[rcx+rax*1]
  40c5bc:	lea    r10,[rdx+rax*1]
  40c5c0:	mov    r9w,WORD PTR [r9]
  40c5c4:	xor    r9w,WORD PTR [r10]
  40c5c8:	test   r9w,r9w
  40c5cc:	je     40c5ee <__swc_fn_ff58629f_000106_77a5d54a+0x18e>
  40c5ce:	xor    r8d,r8d
  40c5d1:	movzx  r9d,r9w
  40c5d5:	tzcnt  r8,r9
  40c5da:	shr    r8,0x3
  40c5de:	add    rax,r8
  40c5e1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c5e5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c5e9:	sub    ecx,eax
  40c5eb:	mov    eax,ecx
  40c5ed:	ret
  40c5ee:	lea    rax,[rax+0x2]
  40c5f2:	cmp    rax,r8
  40c5f5:	jne    40c5fa <__swc_fn_ff58629f_000106_77a5d54a+0x19a>
  40c5f7:	xor    eax,eax
  40c5f9:	ret
  40c5fa:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40c600:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40c606:	sub    eax,ecx
  40c608:	ret
  40c609:	test   r9,r9
  40c60c:	je     40c61b <__swc_fn_ff58629f_000106_77a5d54a+0x1bb>
  40c60e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c612:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c616:	sub    ecx,eax
  40c618:	mov    eax,ecx
  40c61a:	ret
  40c61b:	xor    eax,eax
  40c61d:	ret
	...

000000000040c620 <__swc_fn_ff58629f_000109_aa570b2b>:
  40c620:	push   r12
  40c622:	push   r13
  40c624:	push   r14
  40c626:	push   rdi
  40c627:	push   rsi
  40c628:	push   r15
  40c62a:	sub    rsp,0xd8
  40c631:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c637:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c63d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c643:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c649:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c64f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c658:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c661:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c66a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c673:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c67c:	mov    r12,rcx
  40c67f:	test   rcx,rcx
  40c682:	je     40c69e <__swc_fn_ff58629f_000109_aa570b2b+0x7e>
  40c684:	mov    eax,r12d
  40c687:	and    eax,0xfff
  40c68d:	setne  al
  40c690:	cmp    r12,0xffffffffffffefff
  40c697:	seta   cl
  40c69a:	or     al,cl
  40c69c:	je     40c6a5 <__swc_fn_ff58629f_000109_aa570b2b+0x85>
  40c69e:	xor    eax,eax
  40c6a0:	jmp    40c73b <__swc_fn_ff58629f_000109_aa570b2b+0x11b>
  40c6a5:	call   409100 <__swc_fn_ff58629f_000108_32416b9e>
  40c6aa:	mov    r13,rax
  40c6ad:	test   rax,rax
  40c6b0:	jne    40c6b9 <__swc_fn_ff58629f_000109_aa570b2b+0x99>
  40c6b2:	xor    eax,eax
  40c6b4:	jmp    40c73b <__swc_fn_ff58629f_000109_aa570b2b+0x11b>
  40c6b9:	lea    r14,[r12+0x1000]
  40c6c1:	xor    edi,edi
  40c6c3:	mov    rsi,r14
  40c6c6:	xor    edx,edx
  40c6c8:	mov    ecx,0x22
  40c6cd:	mov    eax,0xffffffff
  40c6d2:	movsxd r8,eax
  40c6d5:	xor    r9d,r9d
  40c6d8:	xor    eax,eax
  40c6da:	call   4070c0 <mmap@plt>
  40c6df:	mov    r15,rax
  40c6e2:	cmp    rax,0xffffffffffffffff
  40c6e6:	jne    40c6ec <__swc_fn_ff58629f_000109_aa570b2b+0xcc>
  40c6e8:	xor    eax,eax
  40c6ea:	jmp    40c73b <__swc_fn_ff58629f_000109_aa570b2b+0x11b>
  40c6ec:	mov    rdi,r15
  40c6ef:	mov    esi,0x1000
  40c6f4:	mov    edx,0x3
  40c6f9:	xor    eax,eax
  40c6fb:	call   407030 <mprotect@plt>
  40c700:	test   eax,eax
  40c702:	je     40c715 <__swc_fn_ff58629f_000109_aa570b2b+0xf5>
  40c704:	mov    rdi,r15
  40c707:	mov    rsi,r14
  40c70a:	xor    eax,eax
  40c70c:	call   407020 <munmap@plt>
  40c711:	xor    eax,eax
  40c713:	jmp    40c73b <__swc_fn_ff58629f_000109_aa570b2b+0x11b>
  40c715:	mov    QWORD PTR [r15+0x8],r12
  40c719:	mov    rcx,r13
  40c71c:	call   40cd70 <__swc_fn_ff58629f_000133_c6de0049>
  40c721:	mov    rax,QWORD PTR [r13+0x8]
  40c725:	mov    QWORD PTR [r15],rax
  40c728:	mov    QWORD PTR [r13+0x8],r15
  40c72c:	mov    rcx,r13
  40c72f:	call   40ff80 <__swc_fn_ff58629f_000134_5696c87e>
  40c734:	lea    rax,[r15+0x1000]
  40c73b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c741:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c747:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c74d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c753:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c759:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c762:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c76b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c774:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c77d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c786:	add    rsp,0xd8
  40c78d:	pop    r15
  40c78f:	pop    rsi
  40c790:	pop    rdi
  40c791:	pop    r14
  40c793:	pop    r13
  40c795:	pop    r12
  40c797:	ret
	...

000000000040c7a0 <__swc_fn_ff58629f_000112_cb2656be>:
  40c7a0:	push   rbx
  40c7a1:	push   r12
  40c7a3:	push   rdi
  40c7a4:	push   rsi
  40c7a5:	sub    rsp,0xa8
  40c7ac:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c7b2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c7b8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c7be:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c7c4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c7ca:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c7d0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40c7d6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40c7dc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40c7e5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40c7ee:	mov    rbx,rdx
  40c7f1:	mov    r12,rcx
  40c7f4:	mov    rdi,rcx
  40c7f7:	mov    rsi,rdx
  40c7fa:	xor    edx,edx
  40c7fc:	xor    eax,eax
  40c7fe:	call   407030 <mprotect@plt>
  40c803:	test   eax,eax
  40c805:	jne    40c829 <__swc_fn_ff58629f_000112_cb2656be+0x89>
  40c807:	mov    rcx,r12
  40c80a:	mov    rdx,rbx
  40c80d:	xor    al,al
  40c80f:	mov    r8,rax
  40c812:	call   40fa20 <__swc_fn_ff58629f_000110_e606239a>
  40c817:	mov    rdi,r12
  40c81a:	mov    rsi,rbx
  40c81d:	mov    edx,0x4
  40c822:	xor    eax,eax
  40c824:	call   4070f0 <madvise@plt>
  40c829:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40c82f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40c835:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40c83b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40c841:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40c847:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40c84d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40c853:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40c859:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40c862:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40c86b:	add    rsp,0xa8
  40c872:	pop    rsi
  40c873:	pop    rdi
  40c874:	pop    r12
  40c876:	pop    rbx
  40c877:	ret
	...

000000000040c880 <__swc_fn_ff58629f_000115_259b5d5a>:
  40c880:	push   rsi
  40c881:	push   rdi
  40c882:	push   r12
  40c884:	push   r13
  40c886:	push   r14
  40c888:	sub    rsp,0xe0
  40c88f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c895:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c89b:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c8a1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c8a7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c8ad:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c8b6:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c8bf:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c8c8:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c8d1:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c8da:	mov    rsi,rdx
  40c8dd:	mov    rdi,rcx
  40c8e0:	call   409100 <__swc_fn_ff58629f_000108_32416b9e>
  40c8e5:	mov    r12,rax
  40c8e8:	test   rax,rax
  40c8eb:	jne    40c8f2 <__swc_fn_ff58629f_000115_259b5d5a+0x72>
  40c8ed:	jmp    40c966 <__swc_fn_ff58629f_000115_259b5d5a+0xe6>
  40c8f2:	mov    rcx,r12
  40c8f5:	call   40cd70 <__swc_fn_ff58629f_000133_c6de0049>
  40c8fa:	lea    r13,[r12+0x8]
  40c8ff:	mov    rax,QWORD PTR [r13+0x0]
  40c903:	test   rax,rax
  40c906:	je     40c95e <__swc_fn_ff58629f_000115_259b5d5a+0xde>
  40c908:	nop    DWORD PTR [rax+rax*1+0x0]
  40c910:	lea    rcx,[rax+0x1000]
  40c917:	cmp    rcx,rdi
  40c91a:	jne    40c952 <__swc_fn_ff58629f_000115_259b5d5a+0xd2>
  40c91c:	cmp    QWORD PTR [rax+0x8],rsi
  40c920:	je     40c92c <__swc_fn_ff58629f_000115_259b5d5a+0xac>
  40c922:	mov    rcx,r12
  40c925:	call   40ff80 <__swc_fn_ff58629f_000134_5696c87e>
  40c92a:	jmp    40c966 <__swc_fn_ff58629f_000115_259b5d5a+0xe6>
  40c92c:	mov    r14,QWORD PTR [rax]
  40c92f:	mov    rdi,rax
  40c932:	lea    rsi,[rsi+0x1000]
  40c939:	xor    eax,eax
  40c93b:	call   407020 <munmap@plt>
  40c940:	test   eax,eax
  40c942:	jne    40c948 <__swc_fn_ff58629f_000115_259b5d5a+0xc8>
  40c944:	mov    QWORD PTR [r13+0x0],r14
  40c948:	mov    rcx,r12
  40c94b:	call   40ff80 <__swc_fn_ff58629f_000134_5696c87e>
  40c950:	jmp    40c966 <__swc_fn_ff58629f_000115_259b5d5a+0xe6>
  40c952:	mov    r13,rax
  40c955:	mov    rax,QWORD PTR [r13+0x0]
  40c959:	test   rax,rax
  40c95c:	jne    40c910 <__swc_fn_ff58629f_000115_259b5d5a+0x90>
  40c95e:	mov    rcx,r12
  40c961:	call   40ff80 <__swc_fn_ff58629f_000134_5696c87e>
  40c966:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c96c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c972:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c978:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c97e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c984:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c98d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c996:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c99f:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c9a8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c9b1:	add    rsp,0xe0
  40c9b8:	pop    r14
  40c9ba:	pop    r13
  40c9bc:	pop    r12
  40c9be:	pop    rdi
  40c9bf:	pop    rsi
  40c9c0:	ret
	...

000000000040c9d0 <__swc_fn_ff58629f_000118_2b35b5e0>:
  40c9d0:	push   rdi
  40c9d1:	push   rsi
  40c9d2:	sub    rsp,0xa8
  40c9d9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c9df:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c9e5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c9eb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c9f1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c9f7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c9fd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ca03:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ca09:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ca12:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ca1b:	mov    rdi,0xfffffffffffffd66
  40ca22:	xor    eax,eax
  40ca24:	call   407040 <exit@plt>
  40ca29:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ca2f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ca35:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ca3b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ca41:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ca47:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ca4d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ca53:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ca59:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ca62:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ca6b:	add    rsp,0xa8
  40ca72:	pop    rsi
  40ca73:	pop    rdi
  40ca74:	ret
	...

000000000040ca80 <__swc_fn_ff58629f_000121_71a5b1cd>:
  40ca80:	push   rbx
  40ca81:	push   rsi
  40ca82:	push   rdi
  40ca83:	sub    rsp,0x30
  40ca87:	mov    rbx,rdx
  40ca8a:	mov    esi,ecx
  40ca8c:	test   ecx,ecx
  40ca8e:	je     40cb63 <__swc_fn_ff58629f_000121_71a5b1cd+0xe3>
  40ca94:	mov    rcx,rsi
  40ca97:	shl    rcx,0x4
  40ca9b:	call   40bf90 <__swc_fn_ff58629f_000079_29fad089>
  40caa0:	test   rax,rax
  40caa3:	je     40cb52 <__swc_fn_ff58629f_000121_71a5b1cd+0xd2>
  40caa9:	mov    rcx,rsi
  40caac:	xor    edx,edx
  40caae:	test   rsi,rsi
  40cab1:	jbe    40cb32 <__swc_fn_ff58629f_000121_71a5b1cd+0xb2>
  40cab7:	nop    WORD PTR [rax+rax*1+0x0]
  40cac0:	mov    r8d,edx
  40cac3:	mov    r9,QWORD PTR [rbx+r8*8]
  40cac7:	add    r8,r8
  40caca:	lea    r8,[rax+r8*8]
  40cace:	xor    r10d,r10d
  40cad1:	test   r9,r9
  40cad4:	je     40cb10 <__swc_fn_ff58629f_000121_71a5b1cd+0x90>
  40cad6:	mov    r11,r9
  40cad9:	mov    dil,BYTE PTR [r11]
  40cadc:	test   dil,dil
  40cadf:	je     40cb10 <__swc_fn_ff58629f_000121_71a5b1cd+0x90>
  40cae1:	cs nop WORD PTR [rax+rax*1+0x0]
  40caeb:	cs nop WORD PTR [rax+rax*1+0x0]
  40caf5:	cs nop WORD PTR [rax+rax*1+0x0]
  40caff:	nop
  40cb00:	add    r11,0x1
  40cb04:	add    r10,0x1
  40cb08:	mov    dil,BYTE PTR [r11]
  40cb0b:	test   dil,dil
  40cb0e:	jne    40cb00 <__swc_fn_ff58629f_000121_71a5b1cd+0x80>
  40cb10:	mov    QWORD PTR [rsp+0x18],r9
  40cb15:	mov    QWORD PTR [rsp+0x20],r10
  40cb1a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40cb20:	vmovups XMMWORD PTR [r8],xmm0
  40cb25:	add    rdx,0x1
  40cb29:	cmp    rdx,rcx
  40cb2c:	jb     40cac0 <__swc_fn_ff58629f_000121_71a5b1cd+0x40>
  40cb32:	lea    rcx,[rip+0x19217]        # 425d50 <__swc_bss_base_ff58629f+0x2d10>
  40cb39:	mov    QWORD PTR [rsp+0x8],rax
  40cb3e:	mov    esi,esi
  40cb40:	mov    QWORD PTR [rsp+0x10],rsi
  40cb45:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40cb4b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40cb50:	jmp    40cb63 <__swc_fn_ff58629f_000121_71a5b1cd+0xe3>
  40cb52:	lea    rcx,[rip+0x59c7]        # 412520 <__swc_rdata_base_ff58629f+0x410>
  40cb59:	call   40fad0 <__swc_fn_ff58629f_000116_3499f7d6>
  40cb5e:	call   40c9d0 <__swc_fn_ff58629f_000118_2b35b5e0>
  40cb63:	add    rsp,0x30
  40cb67:	pop    rdi
  40cb68:	pop    rsi
  40cb69:	pop    rbx
  40cb6a:	ret
  40cb6b:	add    BYTE PTR [rax],al
  40cb6d:	add    BYTE PTR [rax],al
	...

000000000040cb70 <__swc_fn_ff58629f_000124_df97aa0a>:
  40cb70:	push   rdi
  40cb71:	push   rsi
  40cb72:	sub    rsp,0xa8
  40cb79:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cb7f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cb85:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cb8b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cb91:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cb97:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cb9d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cba3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cba9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cbb2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cbbb:	mov    edi,ecx
  40cbbd:	xor    eax,eax
  40cbbf:	call   407100 <pthread_key_delete@plt>
  40cbc4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cbca:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cbd0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cbd6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cbdc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cbe2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cbe8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cbee:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cbf4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cbfd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cc06:	add    rsp,0xa8
  40cc0d:	pop    rsi
  40cc0e:	pop    rdi
  40cc0f:	ret

000000000040cc10 <__swc_fn_ff58629f_000127_75f8ab5c>:
  40cc10:	push   rdi
  40cc11:	push   rsi
  40cc12:	sub    rsp,0xa8
  40cc19:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cc1f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cc25:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cc2b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cc31:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cc37:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cc3d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cc43:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cc49:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cc52:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cc5b:	test   rcx,rcx
  40cc5e:	je     40cc6f <__swc_fn_ff58629f_000127_75f8ab5c+0x5f>
  40cc60:	lea    rax,[rcx-0x1]
  40cc64:	mov    eax,eax
  40cc66:	mov    edi,eax
  40cc68:	xor    eax,eax
  40cc6a:	call   407100 <pthread_key_delete@plt>
  40cc6f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cc75:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cc7b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cc81:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cc87:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cc8d:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cc93:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cc99:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cc9f:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cca8:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ccb1:	add    rsp,0xa8
  40ccb8:	pop    rsi
  40ccb9:	pop    rdi
  40ccba:	ret
  40ccbb:	add    BYTE PTR [rax],al
  40ccbd:	add    BYTE PTR [rax],al
	...

000000000040ccc0 <__swc_fn_ff58629f_000130_d2d78689>:
  40ccc0:	push   rsi
  40ccc1:	push   rdi
  40ccc2:	sub    rsp,0xa8
  40ccc9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cccf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ccd5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ccdb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cce1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cce7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cced:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ccf3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ccf9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cd02:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cd0b:	xor    eax,eax
  40cd0d:	call   407110 <gettid@plt>
  40cd12:	movsxd rax,eax
  40cd15:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cd1b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cd21:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cd27:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cd2d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cd33:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cd39:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cd3f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cd45:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cd4e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cd57:	add    rsp,0xa8
  40cd5e:	pop    rdi
  40cd5f:	pop    rsi
  40cd60:	ret
	...

000000000040cd70 <__swc_fn_ff58629f_000133_c6de0049>:
  40cd70:	push   rbx
  40cd71:	push   rdi
  40cd72:	push   rsi
  40cd73:	sub    rsp,0xc0
  40cd7a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40cd80:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40cd86:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40cd8c:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40cd92:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40cd98:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40cd9e:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40cda4:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40cdad:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40cdb6:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40cdbf:	mov    rbx,rcx
  40cdc2:	cs nop WORD PTR [rax+rax*1+0x0]
  40cdcc:	nop    DWORD PTR [rax+0x0]
  40cdd0:	mov    edx,0x80000000
  40cdd5:	xor    eax,eax
  40cdd7:	lock cmpxchg DWORD PTR [rbx],edx
  40cddb:	test   eax,eax
  40cddd:	je     40ce14 <__swc_fn_ff58629f_000133_c6de0049+0xa4>
  40cddf:	mov    eax,DWORD PTR [rbx]
  40cde1:	lea    rcx,[rsp+0x14]
  40cde6:	mov    DWORD PTR [rsp+0x14],eax
  40cdea:	test   eax,eax
  40cdec:	je     40cdd0 <__swc_fn_ff58629f_000133_c6de0049+0x60>
  40cdee:	mov    QWORD PTR [rsp],0x0
  40cdf6:	mov    edi,0xca
  40cdfb:	mov    rsi,rbx
  40cdfe:	mov    edx,0x80
  40ce03:	mov    ecx,DWORD PTR [rcx]
  40ce05:	xor    r8d,r8d
  40ce08:	xor    r9d,r9d
  40ce0b:	xor    eax,eax
  40ce0d:	call   407070 <syscall@plt>
  40ce12:	jmp    40cdd0 <__swc_fn_ff58629f_000133_c6de0049+0x60>
  40ce14:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ce1a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40ce20:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40ce26:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ce2c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ce32:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ce38:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ce3e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ce47:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ce50:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ce59:	add    rsp,0xc0
  40ce60:	pop    rsi
  40ce61:	pop    rdi
  40ce62:	pop    rbx
  40ce63:	ret
	...

000000000040ce70 <__swc_fn_ff58629f_000136_5589b4a1>:
  40ce70:	sub    rsp,0x8
  40ce74:	call   40ff80 <__swc_fn_ff58629f_000134_5696c87e>
  40ce79:	add    rsp,0x8
  40ce7d:	ret
	...

000000000040ce80 <__swc_fn_ff58629f_000139_20e2e2c7>:
  40ce80:	push   rdi
  40ce81:	push   rsi
  40ce82:	sub    rsp,0xa8
  40ce89:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ce8f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ce95:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ce9b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cea1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cea7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cead:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ceb3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ceb9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cec2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cecb:	mov    edi,0x28
  40ced0:	xor    eax,eax
  40ced2:	call   4070d0 <malloc@plt>
  40ced7:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cedd:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cee3:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cee9:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ceef:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cef5:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cefb:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cf01:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cf07:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cf10:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cf19:	add    rsp,0xa8
  40cf20:	pop    rsi
  40cf21:	pop    rdi
  40cf22:	ret
	...

000000000040cf30 <__swc_fn_ff58629f_000142_e0543f36>:
  40cf30:	mov    QWORD PTR [r8],0x0
  40cf37:	cmp    rdx,0x10
  40cf3b:	jae    40cf40 <__swc_fn_ff58629f_000142_e0543f36+0x10>
  40cf3d:	xor    eax,eax
  40cf3f:	ret
  40cf40:	mov    eax,DWORD PTR [rcx]
  40cf42:	cmp    eax,0x42445753
  40cf48:	jne    40cf52 <__swc_fn_ff58629f_000142_e0543f36+0x22>
  40cf4a:	mov    eax,DWORD PTR [rcx+0x4]
  40cf4d:	cmp    eax,0x1
  40cf50:	je     40cf55 <__swc_fn_ff58629f_000142_e0543f36+0x25>
  40cf52:	xor    eax,eax
  40cf54:	ret
  40cf55:	mov    QWORD PTR [r8],rdx
  40cf58:	mov    rax,rcx
  40cf5b:	ret
  40cf5c:	add    BYTE PTR [rax],al
	...

000000000040cf60 <__swc_fn_ff58629f_000145_071b4f4c>:
  40cf60:	push   rbx
  40cf61:	sub    rsp,0xe0
  40cf68:	lea    rbx,[rsp+0x8]
  40cf6d:	vxorps xmm0,xmm0,xmm0
  40cf71:	vmovups YMMWORD PTR [rbx],ymm0
  40cf75:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40cf7a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40cf7f:	vzeroupper
  40cf82:	mov    DWORD PTR [rbx+0x60],0x0
  40cf89:	mov    r8,rbx
  40cf8c:	mov    rdx,rcx
  40cf8f:	nop
  40cf90:	mov    r9,rdx
  40cf93:	movabs rdx,0x6666666666666667
  40cf9d:	mov    rax,r9
  40cfa0:	imul   rdx
  40cfa3:	sar    rdx,0x2
  40cfa7:	mov    r10,rdx
  40cfaa:	shr    rdx,0x3f
  40cfae:	add    r10,rdx
  40cfb1:	mov    rdx,r10
  40cfb4:	imul   r11,r10,0xa
  40cfb8:	sub    r9,r11
  40cfbb:	mov    r11,QWORD PTR [rip+0x557e]        # 412540 <__swc_rdata_base_ff58629f+0x430>
  40cfc2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40cfc7:	mov    BYTE PTR [r8],r9b
  40cfca:	lea    r9,[r8+0x1]
  40cfce:	mov    r8,r9
  40cfd1:	test   r10,r10
  40cfd4:	jne    40cf90 <__swc_fn_ff58629f_000145_071b4f4c+0x30>
  40cfd6:	test   rcx,rcx
  40cfd9:	jge    40cfe3 <__swc_fn_ff58629f_000145_071b4f4c+0x83>
  40cfdb:	mov    BYTE PTR [r9],0x2d
  40cfdf:	add    r8,0x1
  40cfe3:	mov    BYTE PTR [r8],0x0
  40cfe7:	sub    r8,0x1
  40cfeb:	mov    rax,rbx
  40cfee:	cmp    rax,r8
  40cff1:	jae    40d016 <__swc_fn_ff58629f_000145_071b4f4c+0xb6>
  40cff3:	cs nop WORD PTR [rax+rax*1+0x0]
  40cffd:	nop    DWORD PTR [rax]
  40d000:	mov    cl,BYTE PTR [r8]
  40d003:	mov    dl,BYTE PTR [rax]
  40d005:	mov    BYTE PTR [r8],dl
  40d008:	sub    r8,0x1
  40d00c:	mov    BYTE PTR [rax],cl
  40d00e:	inc    rax
  40d011:	cmp    rax,r8
  40d014:	jb     40d000 <__swc_fn_ff58629f_000145_071b4f4c+0xa0>
  40d016:	xor    eax,eax
  40d018:	test   rbx,rbx
  40d01b:	je     40d03e <__swc_fn_ff58629f_000145_071b4f4c+0xde>
  40d01d:	mov    rcx,rbx
  40d020:	mov    dl,BYTE PTR [rcx]
  40d022:	test   dl,dl
  40d024:	je     40d03e <__swc_fn_ff58629f_000145_071b4f4c+0xde>
  40d026:	cs nop WORD PTR [rax+rax*1+0x0]
  40d030:	add    rcx,0x1
  40d034:	add    rax,0x1
  40d038:	mov    dl,BYTE PTR [rcx]
  40d03a:	test   dl,dl
  40d03c:	jne    40d030 <__swc_fn_ff58629f_000145_071b4f4c+0xd0>
  40d03e:	mov    QWORD PTR [rbx+0xa8],rbx
  40d045:	mov    QWORD PTR [rbx+0xb0],rax
  40d04c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d054:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d05c:	lea    rcx,[rbx+0xb8]
  40d063:	call   40fad0 <__swc_fn_ff58629f_000116_3499f7d6>
  40d068:	add    rsp,0xe0
  40d06f:	pop    rbx
  40d070:	ret
	...

000000000040d080 <__swc_fn_ff58629f_000148_33e5e24f>:
  40d080:	vxorps xmm0,xmm0,xmm0
  40d084:	vmovups XMMWORD PTR [rcx],xmm0
  40d088:	mov    QWORD PTR [rcx+0x10],0x0
  40d090:	ret
	...

000000000040d0a0 <__swc_fn_ff58629f_000151_33e5e24f>:
  40d0a0:	vxorps xmm0,xmm0,xmm0
  40d0a4:	vmovups XMMWORD PTR [rcx],xmm0
  40d0a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d0ad:	vxorps xmm0,xmm0,xmm0
  40d0b1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d0b6:	vmovups xmm0,XMMWORD PTR [rip+0x557a]        # 412638 <__swc_rdata_base_ff58629f+0x528>
  40d0be:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d0c3:	vxorps xmm0,xmm0,xmm0
  40d0c7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d0cc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d0d1:	mov    QWORD PTR [rcx+0x60],0x0
  40d0d9:	ret
  40d0da:	add    BYTE PTR [rax],al
  40d0dc:	add    BYTE PTR [rax],al
	...

000000000040d0e0 <__swc_fn_ff58629f_000154_33e5e24f>:
  40d0e0:	vxorps xmm0,xmm0,xmm0
  40d0e4:	vmovups XMMWORD PTR [rcx],xmm0
  40d0e8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d0ed:	vxorps xmm0,xmm0,xmm0
  40d0f1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d0f6:	vmovups xmm0,XMMWORD PTR [rip+0x5662]        # 412760 <__swc_rdata_base_ff58629f+0x650>
  40d0fe:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d103:	vxorps xmm0,xmm0,xmm0
  40d107:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d10c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d111:	vxorps xmm0,xmm0,xmm0
  40d115:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40d11a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40d11f:	vxorps xmm0,xmm0,xmm0
  40d123:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40d12b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40d133:	vxorps xmm0,xmm0,xmm0
  40d137:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40d13f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40d147:	vxorps xmm0,xmm0,xmm0
  40d14b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40d153:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40d15b:	mov    QWORD PTR [rcx+0xe0],0x0
  40d166:	ret
	...

000000000040d170 <__swc_fn_ff58629f_000157_5c8b11d8>:
  40d170:	push   rbx
  40d171:	mov    rbx,rcx
  40d174:	call   411510 <__swc_fn_ff58629f_000158_6741c23b>
  40d179:	mov    rax,QWORD PTR [rbx+0x10]
  40d17d:	test   rax,rax
  40d180:	je     40d191 <__swc_fn_ff58629f_000157_5c8b11d8+0x21>
  40d182:	mov    rcx,rbx
  40d185:	mov    rdx,rax
  40d188:	mov    r8,QWORD PTR [rbx+0x18]
  40d18c:	call   409e90 <__swc_fn_ff58629f_000156_312df05a>
  40d191:	vxorps xmm0,xmm0,xmm0
  40d195:	vmovups XMMWORD PTR [rbx],xmm0
  40d199:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d19e:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d1a3:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d1a8:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d1ad:	mov    QWORD PTR [rbx+0x50],0x0
  40d1b5:	pop    rbx
  40d1b6:	ret
	...

000000000040d1c0 <__swc_fn_ff58629f_000160_e25d06b9>:
  40d1c0:	sub    rsp,0x10
  40d1c4:	mov    eax,r8d
  40d1c7:	mov    r8d,r9d
  40d1ca:	test   r9d,r9d
  40d1cd:	jne    40d1e6 <__swc_fn_ff58629f_000160_e25d06b9+0x26>
  40d1cf:	vmovups xmm0,XMMWORD PTR [rip+0x5641]        # 412818 <__swc_rdata_base_ff58629f+0x708>
  40d1d7:	vmovups XMMWORD PTR [r10],xmm0
  40d1dc:	mov    eax,0x1
  40d1e1:	add    rsp,0x10
  40d1e5:	ret
  40d1e6:	mov    r9,r8
  40d1e9:	cmp    r8,rax
  40d1ec:	jb     40d1f3 <__swc_fn_ff58629f_000160_e25d06b9+0x33>
  40d1ee:	cmp    r9,rdx
  40d1f1:	jb     40d1fa <__swc_fn_ff58629f_000160_e25d06b9+0x3a>
  40d1f3:	xor    eax,eax
  40d1f5:	add    rsp,0x10
  40d1f9:	ret
  40d1fa:	xor    eax,eax
  40d1fc:	lea    r8,[r9+rax*1]
  40d200:	cmp    r8,rdx
  40d203:	jae    40d233 <__swc_fn_ff58629f_000160_e25d06b9+0x73>
  40d205:	cs nop WORD PTR [rax+rax*1+0x0]
  40d20f:	cs nop WORD PTR [rax+rax*1+0x0]
  40d219:	nop    DWORD PTR [rax+0x0]
  40d220:	cmp    BYTE PTR [rcx+r8*1],0x0
  40d225:	je     40d233 <__swc_fn_ff58629f_000160_e25d06b9+0x73>
  40d227:	inc    rax
  40d22a:	lea    r8,[r9+rax*1]
  40d22e:	cmp    r8,rdx
  40d231:	jb     40d220 <__swc_fn_ff58629f_000160_e25d06b9+0x60>
  40d233:	cmp    r8,rdx
  40d236:	jne    40d23f <__swc_fn_ff58629f_000160_e25d06b9+0x7f>
  40d238:	xor    eax,eax
  40d23a:	add    rsp,0x10
  40d23e:	ret
  40d23f:	add    rcx,r9
  40d242:	mov    QWORD PTR [rsp],rcx
  40d246:	mov    QWORD PTR [rsp+0x8],rax
  40d24b:	vmovups xmm0,XMMWORD PTR [rsp]
  40d250:	vmovups XMMWORD PTR [r10],xmm0
  40d255:	mov    eax,0x1
  40d25a:	add    rsp,0x10
  40d25e:	ret
	...

000000000040d260 <__swc_fn_ff58629f_000163_5fbed98a>:
  40d260:	push   rbp
  40d261:	push   rbx
  40d262:	push   rsi
  40d263:	push   rdi
  40d264:	push   r12
  40d266:	push   r13
  40d268:	push   r14
  40d26a:	push   r15
  40d26c:	sub    rsp,0x10
  40d270:	mov    rbp,rsp
  40d273:	vmovups XMMWORD PTR [rsp],xmm6
  40d278:	sub    rsp,0x50
  40d27c:	mov    rbx,rsp
  40d27f:	mov    rsi,r8
  40d282:	mov    QWORD PTR [rsp+0x30],r8
  40d287:	mov    rdi,rcx
  40d28a:	mov    QWORD PTR [rsp+0x38],rcx
  40d28f:	mov    r12,rdx
  40d292:	xor    r13b,r13b
  40d295:	mov    r14,QWORD PTR [rdi+0x8]
  40d299:	mov    QWORD PTR [rsp+0x40],r14
  40d29e:	xor    r15d,r15d
  40d2a1:	test   r14,r14
  40d2a4:	jbe    40d4fe <__swc_fn_ff58629f_000163_5fbed98a+0x29e>
  40d2aa:	mov    r14,QWORD PTR [rdi]
  40d2ad:	mov    rax,QWORD PTR [rsp+0x40]
  40d2b2:	mov    QWORD PTR [rsp+0x48],r14
  40d2b7:	vmovups xmm6,XMMWORD PTR [rip+0x5179]        # 412438 <__swc_rdata_base_ff58629f+0x328>
  40d2bf:	nop
  40d2c0:	cmp    QWORD PTR [r14+r15*8],0x0
  40d2c5:	jne    40d2cf <__swc_fn_ff58629f_000163_5fbed98a+0x6f>
  40d2c7:	mov    r14,rax
  40d2ca:	jmp    40d4de <__swc_fn_ff58629f_000163_5fbed98a+0x27e>
  40d2cf:	mov    rcx,QWORD PTR [rdi]
  40d2d2:	mov    rdx,QWORD PTR [rcx+r15*8]
  40d2d6:	mov    rdi,rbx
  40d2d9:	mov    rcx,rdi
  40d2dc:	sub    rsp,0x8
  40d2e0:	mov    r14,rax
  40d2e3:	call   409f10 <__swc_fn_ff58629f_000162_edb9cf73>
  40d2e8:	add    rsp,0x8
  40d2ec:	mov    al,BYTE PTR [rbx]
  40d2ee:	test   al,al
  40d2f0:	je     40d4de <__swc_fn_ff58629f_000163_5fbed98a+0x27e>
  40d2f6:	mov    al,BYTE PTR [rbx+0x1]
  40d2f9:	test   al,al
  40d2fb:	jne    40d306 <__swc_fn_ff58629f_000163_5fbed98a+0xa6>
  40d2fd:	test   sil,sil
  40d300:	je     40d4de <__swc_fn_ff58629f_000163_5fbed98a+0x27e>
  40d306:	test   r13b,r13b
  40d309:	jne    40d3c7 <__swc_fn_ff58629f_000163_5fbed98a+0x167>
  40d30f:	test   r12,r12
  40d312:	je     40d3c7 <__swc_fn_ff58629f_000163_5fbed98a+0x167>
  40d318:	mov    al,BYTE PTR [rbx+0x1]
  40d31b:	test   al,al
  40d31d:	je     40d4de <__swc_fn_ff58629f_000163_5fbed98a+0x27e>
  40d323:	mov    eax,DWORD PTR [rbx+0x28]
  40d326:	cmp    DWORD PTR [r12+0x20],eax
  40d32b:	jne    40d4de <__swc_fn_ff58629f_000163_5fbed98a+0x27e>
  40d331:	mov    rax,QWORD PTR [r12]
  40d335:	mov    rcx,QWORD PTR [r12+0x8]
  40d33a:	cmp    QWORD PTR [rbx+0x20],rcx
  40d33e:	jne    40d4de <__swc_fn_ff58629f_000163_5fbed98a+0x27e>
  40d344:	mov    cl,0x1
  40d346:	test   rax,rax
  40d349:	je     40d3b2 <__swc_fn_ff58629f_000163_5fbed98a+0x152>
  40d34f:	mov    rdx,QWORD PTR [rbx+0x20]
  40d353:	xor    r8d,r8d
  40d356:	test   rdx,rdx
  40d359:	jbe    40d3b2 <__swc_fn_ff58629f_000163_5fbed98a+0x152>
  40d35b:	mov    r9,QWORD PTR [rbx+0x18]
  40d35f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40d364:	cs nop WORD PTR [rax+rax*1+0x0]
  40d36e:	xchg   ax,ax
  40d370:	mov    r10b,BYTE PTR [rax+r8*1]
  40d374:	cmp    BYTE PTR [r9+r8*1],r10b
  40d378:	je     40d3a9 <__swc_fn_ff58629f_000163_5fbed98a+0x149>
  40d37a:	vmovq  r10,xmm0
  40d37f:	cmp    BYTE PTR [r10+r8*1],0x5c
  40d384:	jne    40d38d <__swc_fn_ff58629f_000163_5fbed98a+0x12d>
  40d386:	cmp    BYTE PTR [rax+r8*1],0x2f
  40d38b:	je     40d3a9 <__swc_fn_ff58629f_000163_5fbed98a+0x149>
  40d38d:	vmovq  r10,xmm0
  40d392:	cmp    BYTE PTR [r10+r8*1],0x2f
  40d397:	jne    40d3a0 <__swc_fn_ff58629f_000163_5fbed98a+0x140>
  40d399:	cmp    BYTE PTR [rax+r8*1],0x5c
  40d39e:	je     40d3a9 <__swc_fn_ff58629f_000163_5fbed98a+0x149>
  40d3a0:	xor    eax,eax
  40d3a2:	movzx  eax,al
  40d3a5:	mov    cl,al
  40d3a7:	jmp    40d3b2 <__swc_fn_ff58629f_000163_5fbed98a+0x152>
  40d3a9:	add    r8,0x1
  40d3ad:	cmp    r8,rdx
  40d3b0:	jb     40d370 <__swc_fn_ff58629f_000163_5fbed98a+0x110>
  40d3b2:	test   cl,cl
  40d3b4:	je     40d4de <__swc_fn_ff58629f_000163_5fbed98a+0x27e>
  40d3ba:	mov    eax,0x1
  40d3bf:	mov    r13b,al
  40d3c2:	jmp    40d4de <__swc_fn_ff58629f_000163_5fbed98a+0x27e>
  40d3c7:	mov    r13b,0x1
  40d3ca:	sub    rsp,0x20
  40d3ce:	mov    rax,rsp
  40d3d1:	lea    rcx,[rdi+0x8]
  40d3d5:	mov    QWORD PTR [rax],rcx
  40d3d8:	lea    rsi,[rip+0x4f31]        # 412310 <__swc_rdata_base_ff58629f+0x200>
  40d3df:	mov    QWORD PTR [rax+0x8],rsi
  40d3e3:	mov    QWORD PTR [rax+0x10],rsp
  40d3e7:	mov    QWORD PTR [rax+0x18],0x1
  40d3ef:	lea    rcx,[rsp+0x10]
  40d3f4:	sub    rsp,0x8
  40d3f8:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  40d3fd:	add    rsp,0x8
  40d401:	add    rsp,0x20
  40d405:	mov    al,BYTE PTR [rbx+0x1]
  40d408:	test   al,al
  40d40a:	je     40d4a7 <__swc_fn_ff58629f_000163_5fbed98a+0x247>
  40d410:	lea    rax,[rip+0x54a1]        # 4128b8 <__swc_rdata_base_ff58629f+0x7a8>
  40d417:	sub    rsp,0x20
  40d41b:	mov    rcx,rsp
  40d41e:	mov    QWORD PTR [rcx],rax
  40d421:	mov    QWORD PTR [rcx+0x8],rsi
  40d425:	mov    QWORD PTR [rcx+0x10],rsp
  40d429:	mov    QWORD PTR [rcx+0x18],0x1
  40d431:	lea    rcx,[rsp+0x10]
  40d436:	sub    rsp,0x8
  40d43a:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  40d43f:	add    rsp,0x8
  40d443:	add    rsp,0x20
  40d447:	mov    eax,DWORD PTR [rbx+0x28]
  40d44a:	sub    rsp,0x60
  40d44e:	mov    rcx,rsp
  40d451:	lea    rdx,[rdi+0x18]
  40d455:	mov    QWORD PTR [rcx+0x18],rdx
  40d459:	mov    QWORD PTR [rcx+0x20],rsi
  40d45d:	vmovups XMMWORD PTR [rcx],xmm6
  40d461:	mov    QWORD PTR [rcx+0x28],rsp
  40d465:	mov    QWORD PTR [rcx+0x30],rsi
  40d469:	mov    DWORD PTR [rcx+0x10],eax
  40d46c:	lea    rax,[rsp+0x10]
  40d471:	mov    QWORD PTR [rcx+0x38],rax
  40d475:	lea    rax,[rip+0x4f54]        # 4123d0 <__swc_rdata_base_ff58629f+0x2c0>
  40d47c:	mov    QWORD PTR [rcx+0x40],rax
  40d480:	lea    rax,[rsp+0x18]
  40d485:	mov    QWORD PTR [rcx+0x48],rax
  40d489:	mov    QWORD PTR [rcx+0x50],0x3
  40d491:	lea    rcx,[rsp+0x48]
  40d496:	sub    rsp,0x8
  40d49a:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  40d49f:	add    rsp,0x8
  40d4a3:	add    rsp,0x60
  40d4a7:	lea    rax,[rip+0x4eba]        # 412368 <__swc_rdata_base_ff58629f+0x258>
  40d4ae:	sub    rsp,0x20
  40d4b2:	mov    rcx,rsp
  40d4b5:	mov    QWORD PTR [rcx],rax
  40d4b8:	mov    QWORD PTR [rcx+0x8],rsi
  40d4bc:	mov    QWORD PTR [rcx+0x10],rsp
  40d4c0:	mov    QWORD PTR [rcx+0x18],0x1
  40d4c8:	lea    rcx,[rsp+0x10]
  40d4cd:	sub    rsp,0x8
  40d4d1:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  40d4d6:	add    rsp,0x8
  40d4da:	add    rsp,0x20
  40d4de:	add    r15,0x1
  40d4e2:	cmp    r15,r14
  40d4e5:	jae    40d4fe <__swc_fn_ff58629f_000163_5fbed98a+0x29e>
  40d4e7:	mov    rsi,QWORD PTR [rsp+0x30]
  40d4ec:	mov    rdi,QWORD PTR [rsp+0x38]
  40d4f1:	mov    rax,r14
  40d4f4:	mov    r14,QWORD PTR [rsp+0x48]
  40d4f9:	jmp    40d2c0 <__swc_fn_ff58629f_000163_5fbed98a+0x60>
  40d4fe:	add    rsp,0x50
  40d502:	vmovups xmm6,XMMWORD PTR [rsp]
  40d507:	add    rsp,0x10
  40d50b:	pop    r15
  40d50d:	pop    r14
  40d50f:	pop    r13
  40d511:	pop    r12
  40d513:	pop    rdi
  40d514:	pop    rsi
  40d515:	pop    rbx
  40d516:	pop    rbp
  40d517:	ret
	...

000000000040d520 <__swc_fn_ff58629f_000166_31ca4f53>:
  40d520:	sub    rsp,0x8
  40d524:	call   40fd50 <__swc_fn_ff58629f_000125_e19c72b3>
  40d529:	add    rsp,0x8
  40d52d:	ret
	...

000000000040d530 <__swc_fn_ff58629f_000169_aabbfb4c>:
  40d530:	push   rsi
  40d531:	sub    rsp,0x30
  40d535:	lea    rsi,[rip+0x18864]        # 425da0 <__swc_bss_base_ff58629f+0x2d60>
  40d53c:	mov    rax,QWORD PTR [rsi]
  40d53f:	test   rax,rax
  40d542:	je     40d54a <__swc_fn_ff58629f_000169_aabbfb4c+0x1a>
  40d544:	add    rsp,0x30
  40d548:	pop    rsi
  40d549:	ret
  40d54a:	mov    ecx,0x2
  40d54f:	mov    edx,0x8020
  40d554:	call   40f3f0 <__swc_fn_ff58629f_000107_ff529476>
  40d559:	test   rax,rax
  40d55c:	jne    40d56d <__swc_fn_ff58629f_000169_aabbfb4c+0x3d>
  40d55e:	mov    QWORD PTR [rsp+0x18],rax
  40d563:	call   40c9d0 <__swc_fn_ff58629f_000118_2b35b5e0>
  40d568:	mov    rax,QWORD PTR [rsp+0x18]
  40d56d:	mov    rcx,rax
  40d570:	xchg   QWORD PTR [rsi],rcx
  40d573:	add    rsp,0x30
  40d577:	pop    rsi
  40d578:	ret
  40d579:	add    BYTE PTR [rax],al
  40d57b:	add    BYTE PTR [rax],al
  40d57d:	add    BYTE PTR [rax],al
	...

000000000040d580 <__swc_fn_ff58629f_000172_9a88b1d5>:
  40d580:	push   rsi
  40d581:	test   r8,r8
  40d584:	jne    40d588 <__swc_fn_ff58629f_000172_9a88b1d5+0x8>
  40d586:	pop    rsi
  40d587:	ret
  40d588:	lea    rax,[rcx+0x18]
  40d58c:	mov    r10,QWORD PTR [rax]
  40d58f:	lea    r11,[r10+0x1]
  40d593:	mov    QWORD PTR [rax],r11
  40d596:	mov    r11,rdx
  40d599:	not    rdx
  40d59c:	lea    rsi,[r8-0x1]
  40d5a0:	cmp    rsi,rdx
  40d5a3:	ja     40d5c3 <__swc_fn_ff58629f_000172_9a88b1d5+0x43>
  40d5a5:	lea    rdx,[r11+r8*1]
  40d5a9:	dec    rdx
  40d5ac:	shr    rdx,0x6
  40d5b0:	mov    r8,r11
  40d5b3:	shr    r8,0x6
  40d5b7:	mov    rsi,rdx
  40d5ba:	sub    rsi,r8
  40d5bd:	cmp    rsi,0x8
  40d5c1:	jb     40d5d9 <__swc_fn_ff58629f_000172_9a88b1d5+0x59>
  40d5c3:	lea    rcx,[rcx+0x10]
  40d5c7:	mov    rdx,QWORD PTR [rcx]
  40d5ca:	add    rdx,r9
  40d5cd:	mov    QWORD PTR [rcx],rdx
  40d5d0:	lea    rcx,[r10+0x2]
  40d5d4:	mov    QWORD PTR [rax],rcx
  40d5d7:	pop    rsi
  40d5d8:	ret
  40d5d9:	shr    r11,0x6
  40d5dd:	nop    DWORD PTR [rax]
  40d5e0:	cmp    r11,rdx
  40d5e3:	ja     40d623 <__swc_fn_ff58629f_000172_9a88b1d5+0xa3>
  40d5e5:	jmp    40d5f6 <__swc_fn_ff58629f_000172_9a88b1d5+0x76>
  40d5e7:	nop    WORD PTR [rax+rax*1+0x0]
  40d5f0:	add    r11,0x1
  40d5f4:	jmp    40d5e0 <__swc_fn_ff58629f_000172_9a88b1d5+0x60>
  40d5f6:	mov    r8,r11
  40d5f9:	shr    r8,0xc
  40d5fd:	mov    rsi,r11
  40d600:	xor    rsi,r8
  40d603:	mov    r8,r11
  40d606:	shr    r8,0x18
  40d60a:	xor    rsi,r8
  40d60d:	and    esi,0xfff
  40d613:	lea    r8,[rcx+rsi*8+0x20]
  40d618:	mov    rsi,QWORD PTR [r8]
  40d61b:	add    rsi,r9
  40d61e:	mov    QWORD PTR [r8],rsi
  40d621:	jmp    40d5f0 <__swc_fn_ff58629f_000172_9a88b1d5+0x70>
  40d623:	lea    rcx,[r10+0x2]
  40d627:	mov    QWORD PTR [rax],rcx
  40d62a:	pop    rsi
  40d62b:	ret
  40d62c:	add    BYTE PTR [rax],al
	...

000000000040d630 <__swc_fn_ff58629f_000175_2744b483>:
  40d630:	push   rbx
  40d631:	sub    rsp,0x70
  40d635:	cmp    rcx,0xffffffffffffffef
  40d639:	jbe    40d643 <__swc_fn_ff58629f_000175_2744b483+0x13>
  40d63b:	xor    eax,eax
  40d63d:	add    rsp,0x70
  40d641:	pop    rbx
  40d642:	ret
  40d643:	vxorps xmm0,xmm0,xmm0
  40d647:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40d64d:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40d653:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  40d659:	vzeroupper
  40d65c:	lea    rax,[rcx+0x10]
  40d660:	mov    QWORD PTR [rsp+0x50],rax
  40d665:	mov    DWORD PTR [rsp+0x60],0x10
  40d66d:	mov    rcx,QWORD PTR [rip+0x186cc]        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  40d674:	test   rcx,rcx
  40d677:	jne    40d689 <__swc_fn_ff58629f_000175_2744b483+0x59>
  40d679:	call   40a1a0 <__swc_fn_ff58629f_000165_e09accff>
  40d67e:	lea    rcx,[rax+0x1]
  40d682:	mov    QWORD PTR [rip+0x186b7],rcx        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  40d689:	dec    rcx
  40d68c:	call   411880 <__swc_fn_ff58629f_000167_3130645d>
  40d691:	mov    rcx,QWORD PTR [rax]
  40d694:	lea    rdx,[rsp+0x8]
  40d699:	mov    rbx,QWORD PTR [rax+0x8]
  40d69d:	mov    rbx,QWORD PTR [rbx+0x8]
  40d6a1:	call   rbx
  40d6a3:	mov    rax,QWORD PTR [rsp+0x48]
  40d6a8:	test   rax,rax
  40d6ab:	jne    40d6b5 <__swc_fn_ff58629f_000175_2744b483+0x85>
  40d6ad:	xor    eax,eax
  40d6af:	add    rsp,0x70
  40d6b3:	pop    rbx
  40d6b4:	ret
  40d6b5:	mov    rcx,QWORD PTR [rsp+0x50]
  40d6ba:	mov    QWORD PTR [rax],rcx
  40d6bd:	mov    QWORD PTR [rax+0x8],0x0
  40d6c5:	lea    rax,[rax+0x10]
  40d6c9:	add    rsp,0x70
  40d6cd:	pop    rbx
  40d6ce:	ret
	...

000000000040d6e0 <__swc_fn_ff58629f_000178_2a1d71b4>:
  40d6e0:	push   rsi
  40d6e1:	push   rdi
  40d6e2:	push   r12
  40d6e4:	mov    rsi,rcx
  40d6e7:	mov    rdi,rdx
  40d6ea:	mov    r12,r8
  40d6ed:	cs nop WORD PTR [rax+rax*1+0x0]
  40d6f7:	nop    WORD PTR [rax+rax*1+0x0]
  40d700:	mov    rax,r12
  40d703:	sub    rax,rdi
  40d706:	cmp    rax,0x10
  40d70a:	jle    40d7e9 <__swc_fn_ff58629f_000178_2a1d71b4+0x109>
  40d710:	shr    rax,1
  40d713:	lea    rcx,[rdi+rax*1]
  40d717:	mov    rax,QWORD PTR [rsi+rcx*8]
  40d71b:	mov    rdx,QWORD PTR [rsi+rdi*8]
  40d71f:	cmp    rax,rdx
  40d722:	jae    40d72f <__swc_fn_ff58629f_000178_2a1d71b4+0x4f>
  40d724:	mov    QWORD PTR [rsi+rdi*8],rax
  40d728:	mov    QWORD PTR [rsi+rcx*8],rdx
  40d72c:	mov    rdx,rax
  40d72f:	mov    rax,QWORD PTR [rsi+r12*8]
  40d733:	cmp    rax,rdx
  40d736:	jae    40d743 <__swc_fn_ff58629f_000178_2a1d71b4+0x63>
  40d738:	mov    QWORD PTR [rsi+rdi*8],rax
  40d73c:	mov    QWORD PTR [rsi+r12*8],rdx
  40d740:	mov    rax,rdx
  40d743:	mov    rdx,QWORD PTR [rsi+rcx*8]
  40d747:	cmp    rax,rdx
  40d74a:	jae    40d754 <__swc_fn_ff58629f_000178_2a1d71b4+0x74>
  40d74c:	mov    QWORD PTR [rsi+rcx*8],rax
  40d750:	mov    QWORD PTR [rsi+r12*8],rdx
  40d754:	mov    rax,QWORD PTR [rsi+rcx*8]
  40d758:	mov    r9,rdi
  40d75b:	mov    r10,r12
  40d75e:	xchg   ax,ax
  40d760:	cmp    QWORD PTR [rsi+r9*8],rax
  40d764:	jae    40d77a <__swc_fn_ff58629f_000178_2a1d71b4+0x9a>
  40d766:	cs nop WORD PTR [rax+rax*1+0x0]
  40d770:	add    r9,0x1
  40d774:	cmp    QWORD PTR [rsi+r9*8],rax
  40d778:	jb     40d770 <__swc_fn_ff58629f_000178_2a1d71b4+0x90>
  40d77a:	cmp    QWORD PTR [rsi+r10*8],rax
  40d77e:	jbe    40d78a <__swc_fn_ff58629f_000178_2a1d71b4+0xaa>
  40d780:	sub    r10,0x1
  40d784:	cmp    QWORD PTR [rsi+r10*8],rax
  40d788:	ja     40d780 <__swc_fn_ff58629f_000178_2a1d71b4+0xa0>
  40d78a:	cmp    r9,r10
  40d78d:	jg     40d7ac <__swc_fn_ff58629f_000178_2a1d71b4+0xcc>
  40d78f:	mov    rcx,QWORD PTR [rsi+r9*8]
  40d793:	mov    rdx,QWORD PTR [rsi+r10*8]
  40d797:	mov    QWORD PTR [rsi+r9*8],rdx
  40d79b:	mov    QWORD PTR [rsi+r10*8],rcx
  40d79f:	add    r9,0x1
  40d7a3:	sub    r10,0x1
  40d7a7:	cmp    r9,r10
  40d7aa:	jle    40d760 <__swc_fn_ff58629f_000178_2a1d71b4+0x80>
  40d7ac:	mov    rax,r10
  40d7af:	sub    rax,rdi
  40d7b2:	mov    rcx,r12
  40d7b5:	sub    rcx,r9
  40d7b8:	cmp    rax,rcx
  40d7bb:	jge    40d7d3 <__swc_fn_ff58629f_000178_2a1d71b4+0xf3>
  40d7bd:	mov    rcx,rsi
  40d7c0:	mov    rdx,rdi
  40d7c3:	mov    r8,r10
  40d7c6:	mov    rdi,r9
  40d7c9:	call   40d6e0 <__swc_fn_ff58629f_000178_2a1d71b4>
  40d7ce:	jmp    40d700 <__swc_fn_ff58629f_000178_2a1d71b4+0x20>
  40d7d3:	mov    rcx,rsi
  40d7d6:	mov    rdx,r9
  40d7d9:	mov    r8,r12
  40d7dc:	mov    r12,r10
  40d7df:	call   40d6e0 <__swc_fn_ff58629f_000178_2a1d71b4>
  40d7e4:	jmp    40d700 <__swc_fn_ff58629f_000178_2a1d71b4+0x20>
  40d7e9:	lea    rax,[rdi+0x1]
  40d7ed:	cmp    rax,r12
  40d7f0:	jg     40d833 <__swc_fn_ff58629f_000178_2a1d71b4+0x153>
  40d7f2:	cs nop WORD PTR [rax+rax*1+0x0]
  40d7fc:	nop    DWORD PTR [rax+0x0]
  40d800:	mov    rcx,QWORD PTR [rsi+rax*8]
  40d804:	lea    rdx,[rax-0x1]
  40d808:	cmp    rdx,rdi
  40d80b:	jl     40d826 <__swc_fn_ff58629f_000178_2a1d71b4+0x146>
  40d80d:	nop    DWORD PTR [rax]
  40d810:	mov    r8,QWORD PTR [rsi+rdx*8]
  40d814:	cmp    r8,rcx
  40d817:	jbe    40d826 <__swc_fn_ff58629f_000178_2a1d71b4+0x146>
  40d819:	mov    QWORD PTR [rsi+rdx*8+0x8],r8
  40d81e:	dec    rdx
  40d821:	cmp    rdx,rdi
  40d824:	jge    40d810 <__swc_fn_ff58629f_000178_2a1d71b4+0x130>
  40d826:	mov    QWORD PTR [rsi+rdx*8+0x8],rcx
  40d82b:	inc    rax
  40d82e:	cmp    rax,r12
  40d831:	jle    40d800 <__swc_fn_ff58629f_000178_2a1d71b4+0x120>
  40d833:	pop    r12
  40d835:	pop    rdi
  40d836:	pop    rsi
  40d837:	ret
	...

000000000040d840 <__swc_fn_ff58629f_000002_390d5093>:
  40d840:	sub    rsp,0x8
  40d844:	call   40c620 <__swc_fn_ff58629f_000109_aa570b2b>
  40d849:	mov    rcx,rax
  40d84c:	test   rax,rax
  40d84f:	je     40d876 <__swc_fn_ff58629f_000002_390d5093+0x36>
  40d851:	lea    rdx,[rip+0x157e8]        # 423040 <__swc_bss_base_ff58629f>
  40d858:	mov    r8,QWORD PTR [rip+0x157e1]        # 423040 <__swc_bss_base_ff58629f>
  40d85f:	nop
  40d860:	lea    r9,[r8+0x1]
  40d864:	mov    rax,r8
  40d867:	lock cmpxchg QWORD PTR [rdx],r9
  40d86c:	cmp    rax,r8
  40d86f:	je     40d876 <__swc_fn_ff58629f_000002_390d5093+0x36>
  40d871:	mov    r8,rax
  40d874:	jmp    40d860 <__swc_fn_ff58629f_000002_390d5093+0x20>
  40d876:	mov    rax,rcx
  40d879:	add    rsp,0x8
  40d87d:	ret
	...

000000000040d880 <__swc_fn_ff58629f_000005_bcc5b80b>:
  40d880:	mov    r8d,edx
  40d883:	xor    eax,eax
  40d885:	tzcnt  eax,edx
  40d889:	shrx   r9d,edx,eax
  40d88e:	mov    DWORD PTR [rcx+0x2c],edx
  40d891:	xor    eax,eax
  40d893:	tzcnt  eax,edx
  40d897:	mov    BYTE PTR [rcx+0x38],al
  40d89a:	mov    eax,0xffffffff
  40d89f:	xor    edx,edx
  40d8a1:	div    r8d
  40d8a4:	mov    DWORD PTR [rcx+0x34],eax
  40d8a7:	mov    eax,r9d
  40d8aa:	mov    edx,r9d
  40d8ad:	imul   edx,r9d
  40d8b1:	mov    r8d,0x2
  40d8b7:	sub    r8d,edx
  40d8ba:	imul   eax,r8d
  40d8be:	mov    edx,r9d
  40d8c1:	imul   edx,eax
  40d8c4:	mov    r8d,0x2
  40d8ca:	sub    r8d,edx
  40d8cd:	imul   eax,r8d
  40d8d1:	mov    edx,r9d
  40d8d4:	imul   edx,eax
  40d8d7:	mov    r8d,0x2
  40d8dd:	sub    r8d,edx
  40d8e0:	imul   eax,r8d
  40d8e4:	mov    edx,r9d
  40d8e7:	imul   edx,eax
  40d8ea:	mov    r8d,0x2
  40d8f0:	sub    r8d,edx
  40d8f3:	imul   eax,r8d
  40d8f7:	imul   r9d,eax
  40d8fb:	mov    edx,0x2
  40d900:	sub    edx,r9d
  40d903:	imul   eax,edx
  40d906:	mov    DWORD PTR [rcx+0x30],eax
  40d909:	ret
  40d90a:	add    BYTE PTR [rax],al
  40d90c:	add    BYTE PTR [rax],al
	...

000000000040d910 <__swc_fn_ff58629f_000008_578f1784>:
  40d910:	xor    eax,eax
  40d912:	mov    DWORD PTR [rcx+0x68],eax
  40d915:	ret
	...

000000000040d920 <__swc_fn_ff58629f_000011_e75d466d>:
  40d920:	mov    eax,DWORD PTR [rcx+0x28]
  40d923:	shlx   eax,edx,eax
  40d928:	shl    rax,0x10
  40d92c:	lea    rdx,[rcx+rax*1]
  40d930:	lea    rax,[rcx+0x3000]
  40d937:	cmp    rdx,rax
  40d93a:	cmovae rax,rdx
  40d93e:	ret
	...

000000000040d940 <__swc_fn_ff58629f_000014_1acdaf22>:
  40d940:	push   rsi
  40d941:	push   rdi
  40d942:	push   r12
  40d944:	push   r13
  40d946:	push   r14
  40d948:	mov    rsi,rdx
  40d94b:	mov    rdi,rcx
  40d94e:	rex mov dl,BYTE PTR [rsi+0x3a]
  40d952:	mov    ecx,DWORD PTR [rdi+0x28]
  40d955:	shr    dl,cl
  40d957:	mov    r12d,0x1
  40d95d:	mov    ecx,edx
  40d95f:	shl    r12,cl
  40d962:	mov    r13d,DWORD PTR [rsi+0x3c]
  40d966:	rex mov BYTE PTR [rsi+0x3b],0x0
  40d96b:	mov    QWORD PTR [rsi+0x40],0x0
  40d973:	mov    QWORD PTR [rsi],0x0
  40d97a:	mov    rax,QWORD PTR [rsi+0x10]
  40d97e:	mov    QWORD PTR [rsi+0x20],rax
  40d982:	lea    r14,[rip+0x156bf]        # 423048 <__swc_bss_base_ff58629f+0x8>
  40d989:	mov    rax,QWORD PTR [r14]
  40d98c:	shr    rax,0x2
  40d990:	mov    rcx,rax
  40d993:	cmp    rax,0x800000
  40d99a:	mov    eax,0x800000
  40d99f:	cmovb  rcx,rax
  40d9a3:	lea    r8,[rip+0x156ae]        # 423058 <__swc_bss_base_ff58629f+0x18>
  40d9aa:	mov    rax,QWORD PTR [r8]
  40d9ad:	mov    r9,rax
  40d9b0:	lea    r10,[r9+r13*1]
  40d9b4:	cmp    r10,rcx
  40d9b7:	ja     40d9db <__swc_fn_ff58629f_000014_1acdaf22+0x9b>
  40d9b9:	mov    rax,r9
  40d9bc:	lock cmpxchg QWORD PTR [r8],r10
  40d9c1:	cmp    rax,r9
  40d9c4:	je     40d9cb <__swc_fn_ff58629f_000014_1acdaf22+0x8b>
  40d9c6:	mov    r9,rax
  40d9c9:	jmp    40d9b0 <__swc_fn_ff58629f_000014_1acdaf22+0x70>
  40d9cb:	mov    rcx,rdi
  40d9ce:	mov    rdx,r12
  40d9d1:	call   40a750 <__swc_fn_ff58629f_000016_89da4d6e>
  40d9d6:	jmp    40da5d <__swc_fn_ff58629f_000014_1acdaf22+0x11d>
  40d9db:	mov    rcx,rdi
  40d9de:	movzx  edx,dl
  40d9e1:	call   40d920 <__swc_fn_ff58629f_000011_e75d466d>
  40d9e6:	test   r13,r13
  40d9e9:	je     40da56 <__swc_fn_ff58629f_000014_1acdaf22+0x116>
  40d9ef:	mov    rcx,rax
  40d9f2:	mov    rdx,r13
  40d9f5:	call   40c7a0 <__swc_fn_ff58629f_000112_cb2656be>
  40d9fa:	mov    rcx,QWORD PTR [rip+0x15647]        # 423048 <__swc_bss_base_ff58629f+0x8>
  40da01:	cs nop WORD PTR [rax+rax*1+0x0]
  40da0b:	nop    DWORD PTR [rax+rax*1+0x0]
  40da10:	mov    rdx,rcx
  40da13:	sub    rdx,r13
  40da16:	mov    rax,rcx
  40da19:	lock cmpxchg QWORD PTR [r14],rdx
  40da1e:	cmp    rax,rcx
  40da21:	je     40da28 <__swc_fn_ff58629f_000014_1acdaf22+0xe8>
  40da23:	mov    rcx,rax
  40da26:	jmp    40da10 <__swc_fn_ff58629f_000014_1acdaf22+0xd0>
  40da28:	lea    rcx,[rip+0x15631]        # 423060 <__swc_bss_base_ff58629f+0x20>
  40da2f:	mov    rdx,QWORD PTR [rip+0x1562a]        # 423060 <__swc_bss_base_ff58629f+0x20>
  40da36:	cs nop WORD PTR [rax+rax*1+0x0]
  40da40:	lea    r8,[rdx+0x1]
  40da44:	mov    rax,rdx
  40da47:	lock cmpxchg QWORD PTR [rcx],r8
  40da4c:	cmp    rax,rdx
  40da4f:	je     40da56 <__swc_fn_ff58629f_000014_1acdaf22+0x116>
  40da51:	mov    rdx,rax
  40da54:	jmp    40da40 <__swc_fn_ff58629f_000014_1acdaf22+0x100>
  40da56:	mov    DWORD PTR [rsi+0x3c],0x0
  40da5d:	mov    rcx,rdi
  40da60:	mov    rdx,r12
  40da63:	call   407600 <__swc_fn_ff58629f_000018_e2e8e4b0>
  40da68:	pop    r14
  40da6a:	pop    r13
  40da6c:	pop    r12
  40da6e:	pop    rdi
  40da6f:	pop    rsi
  40da70:	ret
	...

000000000040da80 <__swc_fn_ff58629f_000017_e238d24c>:
  40da80:	mov    r8,QWORD PTR [rcx+0x48]
  40da84:	test   r8,rdx
  40da87:	je     40dab8 <__swc_fn_ff58629f_000017_e238d24c+0x38>
  40da89:	nop    DWORD PTR [rax+0x0]
  40da90:	mov    rax,rdx
  40da93:	not    rax
  40da96:	mov    r9,r8
  40da99:	and    r9,rax
  40da9c:	mov    rax,r8
  40da9f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40daa5:	cmp    rax,r8
  40daa8:	jne    40dab0 <__swc_fn_ff58629f_000017_e238d24c+0x30>
  40daaa:	mov    eax,0x1
  40daaf:	ret
  40dab0:	mov    r8,rax
  40dab3:	test   rax,rdx
  40dab6:	jne    40da90 <__swc_fn_ff58629f_000017_e238d24c+0x10>
  40dab8:	xor    eax,eax
  40daba:	ret
  40dabb:	add    BYTE PTR [rax],al
  40dabd:	add    BYTE PTR [rax],al
	...

000000000040dac0 <__swc_fn_ff58629f_000020_4135c89a>:
  40dac0:	push   rsi
  40dac1:	push   rdi
  40dac2:	push   r12
  40dac4:	push   r13
  40dac6:	sub    rsp,0x8
  40daca:	mov    rsi,rdx
  40dacd:	mov    rdi,rcx
  40dad0:	lea    r12,[rip+0x15719]        # 4231f0 <__swc_bss_base_ff58629f+0x1b0>
  40dad7:	mov    rcx,r12
  40dada:	call   4098a0 <__swc_fn_ff58629f_000135_1fec60ac>
  40dadf:	xor    eax,eax
  40dae1:	mov    rcx,QWORD PTR [rip+0x15710]        # 4231f8 <__swc_bss_base_ff58629f+0x1b8>
  40dae8:	mov    r13,rcx
  40daeb:	test   r13,r13
  40daee:	je     40db3b <__swc_fn_ff58629f_000020_4135c89a+0x7b>
  40daf0:	mov    rcx,QWORD PTR [r13+0x10]
  40daf4:	cmp    DWORD PTR [r13+0x28],esi
  40daf8:	jne    40db30 <__swc_fn_ff58629f_000020_4135c89a+0x70>
  40dafa:	test   rax,rax
  40dafd:	jne    40db08 <__swc_fn_ff58629f_000020_4135c89a+0x48>
  40daff:	mov    QWORD PTR [rip+0x156f2],rcx        # 4231f8 <__swc_bss_base_ff58629f+0x1b8>
  40db06:	jmp    40db0c <__swc_fn_ff58629f_000020_4135c89a+0x4c>
  40db08:	mov    QWORD PTR [rax+0x10],rcx
  40db0c:	vxorps xmm0,xmm0,xmm0
  40db10:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40db16:	mov    QWORD PTR [r13+0x8],rdi
  40db1a:	mov    rcx,r12
  40db1d:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  40db22:	mov    rax,r13
  40db25:	add    rsp,0x8
  40db29:	pop    r13
  40db2b:	pop    r12
  40db2d:	pop    rdi
  40db2e:	pop    rsi
  40db2f:	ret
  40db30:	mov    rax,r13
  40db33:	mov    r13,rcx
  40db36:	test   rcx,rcx
  40db39:	jne    40daf0 <__swc_fn_ff58629f_000020_4135c89a+0x30>
  40db3b:	mov    ecx,esi
  40db3d:	call   40a780 <__swc_fn_ff58629f_000019_60e50998>
  40db42:	mov    rsi,rax
  40db45:	test   rax,rax
  40db48:	jne    40db5f <__swc_fn_ff58629f_000020_4135c89a+0x9f>
  40db4a:	mov    rcx,r12
  40db4d:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  40db52:	xor    eax,eax
  40db54:	add    rsp,0x8
  40db58:	pop    r13
  40db5a:	pop    r12
  40db5c:	pop    rdi
  40db5d:	pop    rsi
  40db5e:	ret
  40db5f:	mov    QWORD PTR [rsi+0x8],rdi
  40db63:	mov    rcx,r12
  40db66:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  40db6b:	mov    rax,rsi
  40db6e:	add    rsp,0x8
  40db72:	pop    r13
  40db74:	pop    r12
  40db76:	pop    rdi
  40db77:	pop    rsi
  40db78:	ret
  40db79:	add    BYTE PTR [rax],al
  40db7b:	add    BYTE PTR [rax],al
  40db7d:	add    BYTE PTR [rax],al
	...

000000000040db80 <__swc_fn_ff58629f_000023_7e9350e1>:
  40db80:	vxorps xmm0,xmm0,xmm0
  40db84:	xor    eax,eax
  40db86:	cs nop WORD PTR [rax+rax*1+0x0]
  40db90:	cs nop WORD PTR [rax+rax*1+0x0]
  40db9a:	nop    WORD PTR [rax+rax*1+0x0]
  40dba0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40dba5:	add    rax,0x10
  40dba9:	cmp    rax,0x2b00
  40dbb0:	jne    40dba0 <__swc_fn_ff58629f_000023_7e9350e1+0x20>
  40dbb2:	ret
	...

000000000040dbc0 <__swc_fn_ff58629f_000026_7e9350e1>:
  40dbc0:	vxorps xmm0,xmm0,xmm0
  40dbc4:	vmovups XMMWORD PTR [rcx],xmm0
  40dbc8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40dbcd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40dbd2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40dbd7:	ret
	...

000000000040dbe0 <__swc_fn_ff58629f_000029_7e9350e1>:
  40dbe0:	vxorps xmm0,xmm0,xmm0
  40dbe4:	vmovups XMMWORD PTR [rcx],xmm0
  40dbe8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40dbed:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40dbf2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40dbf7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40dbfc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40dc01:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40dc06:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40dc0b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40dc13:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40dc1b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40dc23:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40dc2b:	mov    QWORD PTR [rcx+0xc0],0x0
  40dc36:	ret
	...

000000000040dc40 <__swc_fn_ff58629f_000032_8c89735c>:
  40dc40:	push   rsi
  40dc41:	push   rdi
  40dc42:	sub    rsp,0x8
  40dc46:	mov    rsi,rcx
  40dc49:	lea    rdi,[rip+0x133b0]        # 421000 <__swc_data_base_ff58629f>
  40dc50:	mov    rax,QWORD PTR [rdi]
  40dc53:	cmp    rax,0xffffffffffffffff
  40dc57:	je     40dc5e <__swc_fn_ff58629f_000032_8c89735c+0x1e>
  40dc59:	mov    rdi,rax
  40dc5c:	jmp    40dc8b <__swc_fn_ff58629f_000032_8c89735c+0x4b>
  40dc5e:	call   409580 <__swc_fn_ff58629f_000123_e9227a3e>
  40dc63:	mov    rcx,rax
  40dc66:	cmp    rax,0xffffffffffffffff
  40dc6a:	je     40dc9c <__swc_fn_ff58629f_000032_8c89735c+0x5c>
  40dc6c:	mov    rax,0xffffffffffffffff
  40dc73:	lock cmpxchg QWORD PTR [rdi],rcx
  40dc78:	cmp    rax,0xffffffffffffffff
  40dc7c:	je     40dc88 <__swc_fn_ff58629f_000032_8c89735c+0x48>
  40dc7e:	mov    rdi,rax
  40dc81:	call   40cb70 <__swc_fn_ff58629f_000124_df97aa0a>
  40dc86:	jmp    40dc8b <__swc_fn_ff58629f_000032_8c89735c+0x4b>
  40dc88:	mov    rdi,rcx
  40dc8b:	cmp    rdi,0xffffffffffffffff
  40dc8f:	je     40dc9c <__swc_fn_ff58629f_000032_8c89735c+0x5c>
  40dc91:	mov    rcx,rdi
  40dc94:	mov    rdx,rsi
  40dc97:	call   40fd50 <__swc_fn_ff58629f_000125_e19c72b3>
  40dc9c:	add    rsp,0x8
  40dca0:	pop    rdi
  40dca1:	pop    rsi
  40dca2:	ret
	...

000000000040dcb0 <__swc_fn_ff58629f_000035_6105596e>:
  40dcb0:	sub    rsp,0x38
  40dcb4:	mov    rax,rdx
  40dcb7:	test   dl,dl
  40dcb9:	jne    40dcd1 <__swc_fn_ff58629f_000035_6105596e+0x21>
  40dcbb:	mov    rax,r8
  40dcbe:	test   r8b,r8b
  40dcc1:	cmove  eax,r9d
  40dcc5:	test   al,al
  40dcc7:	cmove  eax,r10d
  40dccb:	test   al,al
  40dccd:	cmove  eax,r11d
  40dcd1:	test   al,al
  40dcd3:	jne    40dcda <__swc_fn_ff58629f_000035_6105596e+0x2a>
  40dcd5:	add    rsp,0x38
  40dcd9:	ret
  40dcda:	lea    rcx,[rip+0x442f]        # 412110 <__swc_rdata_base_ff58629f>
  40dce1:	vmovups xmm0,XMMWORD PTR [rip+0x4437]        # 412120 <__swc_rdata_base_ff58629f+0x10>
  40dce9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dcef:	vmovups xmm0,XMMWORD PTR [rip+0x4439]        # 412130 <__swc_rdata_base_ff58629f+0x20>
  40dcf7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40dcfd:	vmovups xmm0,XMMWORD PTR [rip+0x443b]        # 412140 <__swc_rdata_base_ff58629f+0x30>
  40dd05:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40dd0b:	lea    rdx,[rsp+0x8]
  40dd10:	call   40c3a0 <__swc_fn_ff58629f_000103_2ed36338>
  40dd15:	jmp    40dcd5 <__swc_fn_ff58629f_000035_6105596e+0x25>
	...

000000000040dd20 <__swc_fn_ff58629f_000038_c7591393>:
  40dd20:	sub    rsp,0x8
  40dd24:	mov    eax,0x1000
  40dd29:	test   eax,eax
  40dd2b:	mov    r8d,0x8
  40dd31:	cmove  eax,r8d
  40dd35:	dec    rax
  40dd38:	mov    r8,0xffffffffffffffff
  40dd3f:	sub    r8,rax
  40dd42:	cmp    rdx,r8
  40dd45:	ja     40dd55 <__swc_fn_ff58629f_000038_c7591393+0x35>
  40dd47:	add    rdx,rax
  40dd4a:	not    rax
  40dd4d:	mov    r8,rdx
  40dd50:	and    r8,rax
  40dd53:	jne    40dd5c <__swc_fn_ff58629f_000038_c7591393+0x3c>
  40dd55:	xor    eax,eax
  40dd57:	add    rsp,0x8
  40dd5b:	ret
  40dd5c:	mov    rdx,r8
  40dd5f:	call   40aaa0 <__swc_fn_ff58629f_000037_92e867c2>
  40dd64:	add    rsp,0x8
  40dd68:	ret
  40dd69:	add    BYTE PTR [rax],al
  40dd6b:	add    BYTE PTR [rax],al
  40dd6d:	add    BYTE PTR [rax],al
	...

000000000040dd70 <__swc_fn_ff58629f_000041_ed1cda78>:
  40dd70:	push   rsi
  40dd71:	push   rdi
  40dd72:	sub    rsp,0x8
  40dd76:	mov    rsi,rdx
  40dd79:	mov    rdi,rcx
  40dd7c:	test   rdx,rdx
  40dd7f:	je     40dd9b <__swc_fn_ff58629f_000041_ed1cda78+0x2b>
  40dd81:	xor    ecx,ecx
  40dd83:	call   407720 <__swc_fn_ff58629f_000033_7d7574b6>
  40dd88:	mov    rax,QWORD PTR [rsi]
  40dd8b:	test   rax,rax
  40dd8e:	je     40dd9b <__swc_fn_ff58629f_000041_ed1cda78+0x2b>
  40dd90:	mov    rcx,rax
  40dd93:	mov    rdx,rsi
  40dd96:	call   407840 <__swc_fn_ff58629f_000042_70d5ab54>
  40dd9b:	mov    rcx,rdi
  40dd9e:	call   40ab00 <__swc_fn_ff58629f_000040_7a225310>
  40dda3:	mov    rsi,rax
  40dda6:	test   rax,rax
  40dda9:	jne    40ddb4 <__swc_fn_ff58629f_000041_ed1cda78+0x44>
  40ddab:	xor    eax,eax
  40ddad:	add    rsp,0x8
  40ddb1:	pop    rdi
  40ddb2:	pop    rsi
  40ddb3:	ret
  40ddb4:	mov    rcx,rsi
  40ddb7:	call   407720 <__swc_fn_ff58629f_000033_7d7574b6>
  40ddbc:	mov    rax,rsi
  40ddbf:	add    rsp,0x8
  40ddc3:	pop    rdi
  40ddc4:	pop    rsi
  40ddc5:	ret
	...

000000000040ddd0 <__swc_fn_ff58629f_000044_cac7f504>:
  40ddd0:	movzx  eax,BYTE PTR [r8+0x39]
  40ddd5:	lea    rax,[rax+rax*4]
  40ddd9:	lea    rax,[rdx+rax*8+0x28]
  40ddde:	mov    ecx,DWORD PTR [r8+0x6c]
  40dde2:	test   ecx,ecx
  40dde4:	je     40de1d <__swc_fn_ff58629f_000044_cac7f504+0x4d>
  40dde6:	mov    rcx,QWORD PTR [r8+0x50]
  40ddea:	test   rcx,rcx
  40dded:	je     40ddf9 <__swc_fn_ff58629f_000044_cac7f504+0x29>
  40ddef:	mov    rax,QWORD PTR [r8+0x48]
  40ddf3:	mov    QWORD PTR [rcx+0x48],rax
  40ddf7:	jmp    40de01 <__swc_fn_ff58629f_000044_cac7f504+0x31>
  40ddf9:	mov    rcx,QWORD PTR [r8+0x48]
  40ddfd:	mov    QWORD PTR [rax+0x18],rcx
  40de01:	mov    rax,QWORD PTR [r8+0x48]
  40de05:	test   rax,rax
  40de08:	je     40de12 <__swc_fn_ff58629f_000044_cac7f504+0x42>
  40de0a:	mov    rcx,QWORD PTR [r8+0x50]
  40de0e:	mov    QWORD PTR [rax+0x50],rcx
  40de12:	vxorps xmm0,xmm0,xmm0
  40de16:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40de1c:	ret
  40de1d:	mov    rcx,QWORD PTR [r8+0x50]
  40de21:	test   rcx,rcx
  40de24:	je     40de30 <__swc_fn_ff58629f_000044_cac7f504+0x60>
  40de26:	mov    rdx,QWORD PTR [r8+0x48]
  40de2a:	mov    QWORD PTR [rcx+0x48],rdx
  40de2e:	jmp    40de38 <__swc_fn_ff58629f_000044_cac7f504+0x68>
  40de30:	mov    rcx,QWORD PTR [r8+0x48]
  40de34:	mov    QWORD PTR [rax+0x8],rcx
  40de38:	mov    rcx,QWORD PTR [r8+0x48]
  40de3c:	test   rcx,rcx
  40de3f:	je     40de4b <__swc_fn_ff58629f_000044_cac7f504+0x7b>
  40de41:	mov    rdx,QWORD PTR [r8+0x50]
  40de45:	mov    QWORD PTR [rcx+0x50],rdx
  40de49:	jmp    40de53 <__swc_fn_ff58629f_000044_cac7f504+0x83>
  40de4b:	mov    rcx,QWORD PTR [r8+0x50]
  40de4f:	mov    QWORD PTR [rax+0x10],rcx
  40de53:	cmp    QWORD PTR [rax],r8
  40de56:	jne    40de5f <__swc_fn_ff58629f_000044_cac7f504+0x8f>
  40de58:	mov    QWORD PTR [rax],0x0
  40de5f:	vxorps xmm0,xmm0,xmm0
  40de63:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40de69:	ret
  40de6a:	add    BYTE PTR [rax],al
  40de6c:	add    BYTE PTR [rax],al
	...

000000000040de70 <__swc_fn_ff58629f_000047_3d3eceb4>:
  40de70:	sub    rsp,0x8
  40de74:	mov    r9,r8
  40de77:	mov    r10,rdx
  40de7a:	call   40ddd0 <__swc_fn_ff58629f_000044_cac7f504>
  40de7f:	mov    DWORD PTR [r9+0x6c],0x0
  40de87:	movzx  eax,BYTE PTR [r9+0x39]
  40de8c:	lea    rax,[rax+rax*4]
  40de90:	lea    rax,[r10+rax*8+0x28]
  40de95:	mov    rcx,QWORD PTR [rax+0x10]
  40de99:	mov    QWORD PTR [r9+0x50],rcx
  40de9d:	mov    QWORD PTR [r9+0x48],0x0
  40dea5:	mov    rcx,QWORD PTR [rax+0x10]
  40dea9:	test   rcx,rcx
  40deac:	je     40deb4 <__swc_fn_ff58629f_000047_3d3eceb4+0x44>
  40deae:	mov    QWORD PTR [rcx+0x48],r9
  40deb2:	jmp    40deb8 <__swc_fn_ff58629f_000047_3d3eceb4+0x48>
  40deb4:	mov    QWORD PTR [rax+0x8],r9
  40deb8:	mov    QWORD PTR [rax+0x10],r9
  40debc:	add    rsp,0x8
  40dec0:	ret
	...

000000000040dee0 <__swc_fn_ff58629f_000050_e33921d7>:
  40dee0:	push   rsi
  40dee1:	push   rdi
  40dee2:	push   r12
  40dee4:	push   r13
  40dee6:	push   r14
  40dee8:	push   r15
  40deea:	sub    rsp,0x1f8
  40def1:	mov    esi,r8d
  40def4:	mov    QWORD PTR [rsp+0x1e8],rsi
  40defc:	mov    rdi,rcx
  40deff:	mov    r12,rdx
  40df02:	lea    r13,[rsi+rsi*4]
  40df06:	lea    r13,[rdx+r13*8+0x28]
  40df0b:	call   407ca0 <__swc_fn_ff58629f_000048_18a95c9b>
  40df10:	add    DWORD PTR [r12+0x24],0x1
  40df16:	test   BYTE PTR [r12+0x24],0x3f
  40df1c:	jne    40df26 <__swc_fn_ff58629f_000050_e33921d7+0x46>
  40df1e:	mov    rcx,rdi
  40df21:	call   40ac80 <__swc_fn_ff58629f_000049_781177b4>
  40df26:	mov    rax,QWORD PTR [r13+0x8]
  40df2a:	mov    r14,rax
  40df2d:	nop    DWORD PTR [rax]
  40df30:	test   r14,r14
  40df33:	jne    40df42 <__swc_fn_ff58629f_000050_e33921d7+0x62>
  40df35:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40df3d:	jmp    40e049 <__swc_fn_ff58629f_000050_e33921d7+0x169>
  40df42:	mov    r15,QWORD PTR [r14+0x48]
  40df46:	mov    rcx,r14
  40df49:	call   4073f0 <__swc_fn_ff58629f_000009_2417e911>
  40df4e:	mov    rax,QWORD PTR [r14]
  40df51:	test   rax,rax
  40df54:	je     40df66 <__swc_fn_ff58629f_000050_e33921d7+0x86>
  40df56:	mov    rcx,QWORD PTR [rax]
  40df59:	mov    QWORD PTR [r14],rcx
  40df5c:	add    DWORD PTR [r14+0x28],0x1
  40df61:	mov    rsi,rax
  40df64:	jmp    40df85 <__swc_fn_ff58629f_000050_e33921d7+0xa5>
  40df66:	mov    rax,QWORD PTR [r14+0x18]
  40df6a:	cmp    QWORD PTR [r14+0x20],rax
  40df6e:	jae    40df83 <__swc_fn_ff58629f_000050_e33921d7+0xa3>
  40df70:	mov    rsi,QWORD PTR [r14+0x20]
  40df74:	mov    eax,DWORD PTR [r14+0x2c]
  40df78:	add    QWORD PTR [r14+0x20],rax
  40df7c:	add    DWORD PTR [r14+0x28],0x1
  40df81:	jmp    40df85 <__swc_fn_ff58629f_000050_e33921d7+0xa5>
  40df83:	xor    esi,esi
  40df85:	test   rsi,rsi
  40df88:	jne    40dfcd <__swc_fn_ff58629f_000050_e33921d7+0xed>
  40df8a:	mov    rcx,r14
  40df8d:	call   407320 <__swc_fn_ff58629f_000006_12cb36a2>
  40df92:	test   al,al
  40df94:	je     40dfcd <__swc_fn_ff58629f_000050_e33921d7+0xed>
  40df96:	mov    rax,QWORD PTR [r14]
  40df99:	test   rax,rax
  40df9c:	je     40dfab <__swc_fn_ff58629f_000050_e33921d7+0xcb>
  40df9e:	mov    rcx,QWORD PTR [rax]
  40dfa1:	mov    QWORD PTR [r14],rcx
  40dfa4:	add    DWORD PTR [r14+0x28],0x1
  40dfa9:	jmp    40dfca <__swc_fn_ff58629f_000050_e33921d7+0xea>
  40dfab:	mov    rax,QWORD PTR [r14+0x18]
  40dfaf:	cmp    QWORD PTR [r14+0x20],rax
  40dfb3:	jae    40dfc8 <__swc_fn_ff58629f_000050_e33921d7+0xe8>
  40dfb5:	mov    rax,QWORD PTR [r14+0x20]
  40dfb9:	mov    ecx,DWORD PTR [r14+0x2c]
  40dfbd:	add    QWORD PTR [r14+0x20],rcx
  40dfc1:	add    DWORD PTR [r14+0x28],0x1
  40dfc6:	jmp    40dfca <__swc_fn_ff58629f_000050_e33921d7+0xea>
  40dfc8:	xor    eax,eax
  40dfca:	mov    rsi,rax
  40dfcd:	test   rsi,rsi
  40dfd0:	jne    40e023 <__swc_fn_ff58629f_000050_e33921d7+0x143>
  40dfd2:	mov    rcx,rdi
  40dfd5:	mov    rdx,r12
  40dfd8:	mov    r8,r14
  40dfdb:	call   40abe0 <__swc_fn_ff58629f_000046_49300800>
  40dfe0:	test   al,al
  40dfe2:	jne    40e023 <__swc_fn_ff58629f_000050_e33921d7+0x143>
  40dfe4:	mov    rcx,r14
  40dfe7:	call   4073f0 <__swc_fn_ff58629f_000009_2417e911>
  40dfec:	mov    rax,QWORD PTR [r14]
  40dfef:	test   rax,rax
  40dff2:	je     40e001 <__swc_fn_ff58629f_000050_e33921d7+0x121>
  40dff4:	mov    rcx,QWORD PTR [rax]
  40dff7:	mov    QWORD PTR [r14],rcx
  40dffa:	add    DWORD PTR [r14+0x28],0x1
  40dfff:	jmp    40e020 <__swc_fn_ff58629f_000050_e33921d7+0x140>
  40e001:	mov    rax,QWORD PTR [r14+0x18]
  40e005:	cmp    QWORD PTR [r14+0x20],rax
  40e009:	jae    40e01e <__swc_fn_ff58629f_000050_e33921d7+0x13e>
  40e00b:	mov    rax,QWORD PTR [r14+0x20]
  40e00f:	mov    ecx,DWORD PTR [r14+0x2c]
  40e013:	add    QWORD PTR [r14+0x20],rcx
  40e017:	add    DWORD PTR [r14+0x28],0x1
  40e01c:	jmp    40e020 <__swc_fn_ff58629f_000050_e33921d7+0x140>
  40e01e:	xor    eax,eax
  40e020:	mov    rsi,rax
  40e023:	test   rsi,rsi
  40e026:	je     40e041 <__swc_fn_ff58629f_000050_e33921d7+0x161>
  40e028:	mov    QWORD PTR [r13+0x0],r14
  40e02c:	mov    rax,rsi
  40e02f:	add    rsp,0x1f8
  40e036:	pop    r15
  40e038:	pop    r14
  40e03a:	pop    r13
  40e03c:	pop    r12
  40e03e:	pop    rdi
  40e03f:	pop    rsi
  40e040:	ret
  40e041:	mov    r14,r15
  40e044:	jmp    40df30 <__swc_fn_ff58629f_000050_e33921d7+0x50>
  40e049:	cs nop WORD PTR [rax+rax*1+0x0]
  40e053:	cs nop WORD PTR [rax+rax*1+0x0]
  40e05d:	nop    DWORD PTR [rax]
  40e060:	mov    rcx,rdi
  40e063:	mov    rdx,r12
  40e066:	mov    r8d,esi
  40e069:	call   4079e0 <__swc_fn_ff58629f_000045_06cec934>
  40e06e:	mov    r14,rax
  40e071:	test   rax,rax
  40e074:	jne    40e08a <__swc_fn_ff58629f_000050_e33921d7+0x1aa>
  40e076:	xor    eax,eax
  40e078:	add    rsp,0x1f8
  40e07f:	pop    r15
  40e081:	pop    r14
  40e083:	pop    r13
  40e085:	pop    r12
  40e087:	pop    rdi
  40e088:	pop    rsi
  40e089:	ret
  40e08a:	mov    QWORD PTR [r13+0x0],r14
  40e08e:	mov    rax,QWORD PTR [r14]
  40e091:	test   rax,rax
  40e094:	je     40e0a6 <__swc_fn_ff58629f_000050_e33921d7+0x1c6>
  40e096:	mov    rcx,QWORD PTR [rax]
  40e099:	mov    QWORD PTR [r14],rcx
  40e09c:	add    DWORD PTR [r14+0x28],0x1
  40e0a1:	mov    r15,rax
  40e0a4:	jmp    40e0c6 <__swc_fn_ff58629f_000050_e33921d7+0x1e6>
  40e0a6:	mov    rax,QWORD PTR [r14+0x18]
  40e0aa:	cmp    QWORD PTR [r14+0x20],rax
  40e0ae:	jae    40e0c3 <__swc_fn_ff58629f_000050_e33921d7+0x1e3>
  40e0b0:	mov    r15,QWORD PTR [r14+0x20]
  40e0b4:	mov    eax,DWORD PTR [r14+0x2c]
  40e0b8:	add    QWORD PTR [r14+0x20],rax
  40e0bc:	add    DWORD PTR [r14+0x28],0x1
  40e0c1:	jmp    40e0c6 <__swc_fn_ff58629f_000050_e33921d7+0x1e6>
  40e0c3:	xor    r15d,r15d
  40e0c6:	test   r15,r15
  40e0c9:	jne    40e10e <__swc_fn_ff58629f_000050_e33921d7+0x22e>
  40e0cb:	mov    rcx,r14
  40e0ce:	call   407320 <__swc_fn_ff58629f_000006_12cb36a2>
  40e0d3:	test   al,al
  40e0d5:	je     40e10e <__swc_fn_ff58629f_000050_e33921d7+0x22e>
  40e0d7:	mov    rax,QWORD PTR [r14]
  40e0da:	test   rax,rax
  40e0dd:	je     40e0ec <__swc_fn_ff58629f_000050_e33921d7+0x20c>
  40e0df:	mov    rcx,QWORD PTR [rax]
  40e0e2:	mov    QWORD PTR [r14],rcx
  40e0e5:	add    DWORD PTR [r14+0x28],0x1
  40e0ea:	jmp    40e10b <__swc_fn_ff58629f_000050_e33921d7+0x22b>
  40e0ec:	mov    rax,QWORD PTR [r14+0x18]
  40e0f0:	cmp    QWORD PTR [r14+0x20],rax
  40e0f4:	jae    40e109 <__swc_fn_ff58629f_000050_e33921d7+0x229>
  40e0f6:	mov    rax,QWORD PTR [r14+0x20]
  40e0fa:	mov    ecx,DWORD PTR [r14+0x2c]
  40e0fe:	add    QWORD PTR [r14+0x20],rcx
  40e102:	add    DWORD PTR [r14+0x28],0x1
  40e107:	jmp    40e10b <__swc_fn_ff58629f_000050_e33921d7+0x22b>
  40e109:	xor    eax,eax
  40e10b:	mov    r15,rax
  40e10e:	test   r15,r15
  40e111:	je     40e060 <__swc_fn_ff58629f_000050_e33921d7+0x180>
  40e117:	mov    rax,r15
  40e11a:	add    rsp,0x1f8
  40e121:	pop    r15
  40e123:	pop    r14
  40e125:	pop    r13
  40e127:	pop    r12
  40e129:	pop    rdi
  40e12a:	pop    rsi
  40e12b:	ret
  40e12c:	add    BYTE PTR [rax],al
	...

000000000040e130 <__swc_fn_ff58629f_000053_a8a124d6>:
  40e130:	push   rsi
  40e131:	push   rdi
  40e132:	push   r12
  40e134:	mov    rsi,rdx
  40e137:	mov    rax,rdx
  40e13a:	shr    rax,0xc
  40e13e:	movabs rdx,0x9e3779b97f4a7c15
  40e148:	imul   rax,rdx
  40e14c:	shr    rax,0x20
  40e150:	lea    rax,[rax*8+0x0]
  40e158:	shr    rax,0x20
  40e15c:	lea    rax,[rax*8+0x0]
  40e164:	lea    rax,[rcx+rax*8+0x40]
  40e169:	xor    edx,edx
  40e16b:	test   dl,dl
  40e16d:	lea    rdi,[rcx+0x8]
  40e171:	cmove  rdi,rax
  40e175:	xor    edx,edx
  40e177:	test   dl,dl
  40e179:	lea    r12,[rcx+0x30]
  40e17d:	lea    rax,[rax+0x8]
  40e181:	cmove  r12,rax
  40e185:	mov    rcx,rdi
  40e188:	call   4098a0 <__swc_fn_ff58629f_000135_1fec60ac>
  40e18d:	mov    QWORD PTR [rsi+0x30],0x0
  40e195:	mov    rax,QWORD PTR [r12]
  40e199:	mov    QWORD PTR [rsi+0x38],rax
  40e19d:	test   rax,rax
  40e1a0:	je     40e1aa <__swc_fn_ff58629f_000053_a8a124d6+0x7a>
  40e1a2:	mov    rax,QWORD PTR [rsi+0x38]
  40e1a6:	mov    QWORD PTR [rax+0x30],rsi
  40e1aa:	mov    QWORD PTR [r12],rsi
  40e1ae:	mov    rcx,rdi
  40e1b1:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  40e1b6:	pop    r12
  40e1b8:	pop    rdi
  40e1b9:	pop    rsi
  40e1ba:	ret
  40e1bb:	add    BYTE PTR [rax],al
  40e1bd:	add    BYTE PTR [rax],al
	...

000000000040e1c0 <__swc_fn_ff58629f_000056_cfedf3f4>:
  40e1c0:	lea    rax,[rdx+rdx*4]
  40e1c4:	lea    rax,[rcx+rax*8+0x268]
  40e1cc:	mov    rdx,QWORD PTR [rax+0x10]
  40e1d0:	sub    QWORD PTR [rcx+0x2a68],rdx
  40e1d7:	sub    QWORD PTR [rcx+0x2a70],0x1
  40e1df:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40e1e6:	lea    rdx,[rdx+rdx*4]
  40e1ea:	lea    rdx,[rcx+rdx*8+0x268]
  40e1f2:	vmovups xmm0,XMMWORD PTR [rdx]
  40e1f6:	vmovups XMMWORD PTR [rax],xmm0
  40e1fa:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40e1ff:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e204:	mov    rcx,QWORD PTR [rdx+0x20]
  40e208:	mov    QWORD PTR [rax+0x20],rcx
  40e20c:	ret
  40e20d:	add    BYTE PTR [rax],al
	...

000000000040e210 <__swc_fn_ff58629f_000059_c8e1ff6b>:
  40e210:	push   rsi
  40e211:	push   rdi
  40e212:	push   r12
  40e214:	push   r13
  40e216:	sub    rsp,0x8
  40e21a:	mov    rsi,r8
  40e21d:	mov    rdi,rcx
  40e220:	mov    r12,rdx
  40e223:	xor    r13d,r13d
  40e226:	cs nop WORD PTR [rax+rax*1+0x0]
  40e230:	mov    eax,DWORD PTR [r12+0x730]
  40e238:	cmp    r13d,eax
  40e23b:	jae    40e2a1 <__swc_fn_ff58629f_000059_c8e1ff6b+0x91>
  40e23d:	lea    rax,[r13+r13*4+0x0]
  40e242:	lea    rax,[r12+rax*8+0x738]
  40e24a:	mov    rdx,QWORD PTR [rax]
  40e24d:	mov    r8,QWORD PTR [rax+0x8]
  40e251:	mov    r9,QWORD PTR [rax+0x10]
  40e255:	cmp    QWORD PTR [rax+0x20],rsi
  40e259:	jb     40e260 <__swc_fn_ff58629f_000059_c8e1ff6b+0x50>
  40e25b:	inc    r13d
  40e25e:	jmp    40e230 <__swc_fn_ff58629f_000059_c8e1ff6b+0x20>
  40e260:	sub    DWORD PTR [r12+0x730],0x1
  40e269:	mov    ecx,DWORD PTR [r12+0x730]
  40e271:	lea    rcx,[rcx+rcx*4]
  40e275:	lea    rcx,[r12+rcx*8+0x738]
  40e27d:	vmovups xmm0,XMMWORD PTR [rcx]
  40e281:	vmovups XMMWORD PTR [rax],xmm0
  40e285:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40e28a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e28f:	mov    rcx,QWORD PTR [rcx+0x20]
  40e293:	mov    QWORD PTR [rax+0x20],rcx
  40e297:	mov    rcx,rdi
  40e29a:	call   407750 <__swc_fn_ff58629f_000039_05a50673>
  40e29f:	jmp    40e230 <__swc_fn_ff58629f_000059_c8e1ff6b+0x20>
  40e2a1:	add    rsp,0x8
  40e2a5:	pop    r13
  40e2a7:	pop    r12
  40e2a9:	pop    rdi
  40e2aa:	pop    rsi
  40e2ab:	ret
  40e2ac:	add    BYTE PTR [rax],al
	...

000000000040e2b0 <__swc_fn_ff58629f_000062_baa48dba>:
  40e2b0:	push   rsi
  40e2b1:	push   rdi
  40e2b2:	push   r12
  40e2b4:	push   r13
  40e2b6:	push   r14
  40e2b8:	mov    rsi,rcx
  40e2bb:	mov    rdi,rdx
  40e2be:	mov    r12,QWORD PTR [rdi]
  40e2c1:	mov    r13,QWORD PTR [rdi+0x18]
  40e2c5:	mov    rax,r12
  40e2c8:	add    rax,QWORD PTR [rdi+0x8]
  40e2cc:	sub    rax,r13
  40e2cf:	cmp    r8,rax
  40e2d2:	jbe    40e2dd <__swc_fn_ff58629f_000062_baa48dba+0x2d>
  40e2d4:	pop    r14
  40e2d6:	pop    r13
  40e2d8:	pop    r12
  40e2da:	pop    rdi
  40e2db:	pop    rsi
  40e2dc:	ret
  40e2dd:	lea    rax,[r13+r8*1+0x0]
  40e2e2:	sub    rax,r12
  40e2e5:	mov    ecx,0x1000
  40e2ea:	test   ecx,ecx
  40e2ec:	mov    edx,0x8
  40e2f1:	cmove  ecx,edx
  40e2f4:	dec    rcx
  40e2f7:	mov    rdx,0xffffffffffffffff
  40e2fe:	sub    rdx,rcx
  40e301:	cmp    rax,rdx
  40e304:	jbe    40e30b <__swc_fn_ff58629f_000062_baa48dba+0x5b>
  40e306:	xor    r14d,r14d
  40e309:	jmp    40e316 <__swc_fn_ff58629f_000062_baa48dba+0x66>
  40e30b:	add    rax,rcx
  40e30e:	andn   rax,rcx,rax
  40e313:	mov    r14,rax
  40e316:	mov    rax,QWORD PTR [rdi+0x10]
  40e31a:	cmp    r14,rax
  40e31d:	ja     40e328 <__swc_fn_ff58629f_000062_baa48dba+0x78>
  40e31f:	pop    r14
  40e321:	pop    r13
  40e323:	pop    r12
  40e325:	pop    rdi
  40e326:	pop    rsi
  40e327:	ret
  40e328:	mov    rax,r12
  40e32b:	add    rax,QWORD PTR [rdi+0x10]
  40e32f:	mov    rdx,r14
  40e332:	sub    rdx,QWORD PTR [rdi+0x10]
  40e336:	mov    rcx,rax
  40e339:	call   4072a0 <__swc_fn_ff58629f_000003_644dadb7>
  40e33e:	test   al,al
  40e340:	jne    40e34b <__swc_fn_ff58629f_000062_baa48dba+0x9b>
  40e342:	pop    r14
  40e344:	pop    r13
  40e346:	pop    r12
  40e348:	pop    rdi
  40e349:	pop    rsi
  40e34a:	ret
  40e34b:	add    r12,r14
  40e34e:	sub    r12,r13
  40e351:	mov    rcx,r12
  40e354:	sub    rcx,QWORD PTR [rdi+0x28]
  40e358:	mov    rdx,QWORD PTR [rsi+0x250]
  40e35f:	nop
  40e360:	lea    r8,[rdx+rcx*1]
  40e364:	mov    rax,rdx
  40e367:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40e370:	cmp    rax,rdx
  40e373:	je     40e37a <__swc_fn_ff58629f_000062_baa48dba+0xca>
  40e375:	mov    rdx,rax
  40e378:	jmp    40e360 <__swc_fn_ff58629f_000062_baa48dba+0xb0>
  40e37a:	mov    QWORD PTR [rdi+0x10],r14
  40e37e:	mov    QWORD PTR [rdi+0x28],r12
  40e382:	pop    r14
  40e384:	pop    r13
  40e386:	pop    r12
  40e388:	pop    rdi
  40e389:	pop    rsi
  40e38a:	ret
  40e38b:	add    BYTE PTR [rax],al
  40e38d:	add    BYTE PTR [rax],al
	...

000000000040e390 <__swc_fn_ff58629f_000065_cd9dd53e>:
  40e390:	push   rbx
  40e391:	push   rsi
  40e392:	push   rdi
  40e393:	push   r12
  40e395:	push   r13
  40e397:	sub    rsp,0xe0
  40e39e:	mov    rbx,rdx
  40e3a1:	mov    rsi,rcx
  40e3a4:	cmp    DWORD PTR [rbx+0x58],0x0
  40e3a8:	je     40e3cc <__swc_fn_ff58629f_000065_cd9dd53e+0x3c>
  40e3aa:	mov    eax,DWORD PTR [rbx+0x58]
  40e3ad:	sub    eax,0x1
  40e3b0:	test   DWORD PTR [rbx+0x58],eax
  40e3b3:	je     40e3cc <__swc_fn_ff58629f_000065_cd9dd53e+0x3c>
  40e3b5:	mov    QWORD PTR [rbx+0x40],0x0
  40e3bd:	add    rsp,0xe0
  40e3c4:	pop    r13
  40e3c6:	pop    r12
  40e3c8:	pop    rdi
  40e3c9:	pop    rsi
  40e3ca:	pop    rbx
  40e3cb:	ret
  40e3cc:	mov    rax,QWORD PTR [rbx+0x40]
  40e3d0:	test   rax,rax
  40e3d3:	jne    40e3ef <__swc_fn_ff58629f_000065_cd9dd53e+0x5f>
  40e3d5:	mov    rcx,rsi
  40e3d8:	mov    rdx,rbx
  40e3db:	call   40b890 <__swc_fn_ff58629f_000064_6905bec4>
  40e3e0:	add    rsp,0xe0
  40e3e7:	pop    r13
  40e3e9:	pop    r12
  40e3eb:	pop    rdi
  40e3ec:	pop    rsi
  40e3ed:	pop    rbx
  40e3ee:	ret
  40e3ef:	cmp    QWORD PTR [rbx+0x48],0x0
  40e3f4:	jne    40e410 <__swc_fn_ff58629f_000065_cd9dd53e+0x80>
  40e3f6:	mov    rcx,rsi
  40e3f9:	mov    rdx,rbx
  40e3fc:	call   407f90 <__swc_fn_ff58629f_000066_77c6e829>
  40e401:	add    rsp,0xe0
  40e408:	pop    r13
  40e40a:	pop    r12
  40e40c:	pop    rdi
  40e40d:	pop    rsi
  40e40e:	pop    rbx
  40e40f:	ret
  40e410:	mov    rdi,QWORD PTR [rbx+0x40]
  40e414:	lea    rax,[rip+0x14c55]        # 423070 <__swc_bss_base_ff58629f+0x30>
  40e41b:	mov    rcx,rdi
  40e41e:	sub    rcx,QWORD PTR [rax+0x8]
  40e422:	mov    rax,QWORD PTR [rip+0x14c57]        # 423080 <__swc_bss_base_ff58629f+0x40>
  40e429:	cmp    rcx,rax
  40e42c:	jae    40e458 <__swc_fn_ff58629f_000065_cd9dd53e+0xc8>
  40e42e:	mov    rax,rdi
  40e431:	and    rax,0xffffffffffc00000
  40e438:	mov    rcx,rdi
  40e43b:	shr    rcx,0x10
  40e43f:	and    ecx,0x3f
  40e442:	mov    edx,DWORD PTR [rax+0x28]
  40e445:	shrx   ecx,ecx,edx
  40e44a:	shl    rcx,0x4
  40e44e:	lea    r12,[rax+rcx*8+0x80]
  40e456:	jmp    40e463 <__swc_fn_ff58629f_000065_cd9dd53e+0xd3>
  40e458:	mov    rcx,rdi
  40e45b:	call   40a910 <__swc_fn_ff58629f_000022_77c2d682>
  40e460:	mov    r12,rax
  40e463:	test   r12,r12
  40e466:	je     40e475 <__swc_fn_ff58629f_000065_cd9dd53e+0xe5>
  40e468:	mov    eax,DWORD PTR [r12+0x2c]
  40e46d:	mov    r9d,eax
  40e470:	mov    r13,rax
  40e473:	jmp    40e4f4 <__swc_fn_ff58629f_000065_cd9dd53e+0x164>
  40e475:	mov    rcx,rsi
  40e478:	mov    rdx,rdi
  40e47b:	call   40af20 <__swc_fn_ff58629f_000052_26c6c1c4>
  40e480:	mov    rcx,QWORD PTR [rax+0x28]
  40e484:	mov    r9,rcx
  40e487:	mov    rdx,QWORD PTR [rax+0x20]
  40e48b:	mov    r13,rdx
  40e48e:	cmp    QWORD PTR [rbx+0x48],rcx
  40e492:	jbe    40e4cb <__swc_fn_ff58629f_000065_cd9dd53e+0x13b>
  40e494:	mov    ecx,DWORD PTR [rax+0x48]
  40e497:	cmp    DWORD PTR [rbx+0x58],ecx
  40e49a:	ja     40e4cb <__swc_fn_ff58629f_000065_cd9dd53e+0x13b>
  40e49c:	mov    rcx,rsi
  40e49f:	mov    rdx,rax
  40e4a2:	mov    r8,QWORD PTR [rbx+0x48]
  40e4a6:	mov    QWORD PTR [rsp+0xc8],r9
  40e4ae:	mov    QWORD PTR [rsp+0xd0],rax
  40e4b6:	call   40e2b0 <__swc_fn_ff58629f_000062_baa48dba>
  40e4bb:	mov    r9,QWORD PTR [rsp+0xc8]
  40e4c3:	mov    rax,QWORD PTR [rsp+0xd0]
  40e4cb:	mov    rcx,QWORD PTR [rax+0x28]
  40e4cf:	cmp    QWORD PTR [rbx+0x48],rcx
  40e4d3:	ja     40e4f4 <__swc_fn_ff58629f_000065_cd9dd53e+0x164>
  40e4d5:	mov    ecx,DWORD PTR [rax+0x48]
  40e4d8:	cmp    DWORD PTR [rbx+0x58],ecx
  40e4db:	ja     40e4f4 <__swc_fn_ff58629f_000065_cd9dd53e+0x164>
  40e4dd:	mov    rcx,QWORD PTR [rbx+0x48]
  40e4e1:	mov    QWORD PTR [rax+0x20],rcx
  40e4e5:	add    rsp,0xe0
  40e4ec:	pop    r13
  40e4ee:	pop    r12
  40e4f0:	pop    rdi
  40e4f1:	pop    rsi
  40e4f2:	pop    rbx
  40e4f3:	ret
  40e4f4:	test   r12,r12
  40e4f7:	je     40e529 <__swc_fn_ff58629f_000065_cd9dd53e+0x199>
  40e4f9:	cmp    QWORD PTR [rbx+0x48],r9
  40e4fd:	ja     40e529 <__swc_fn_ff58629f_000065_cd9dd53e+0x199>
  40e4ff:	cmp    DWORD PTR [rbx+0x58],0x40
  40e503:	ja     40e529 <__swc_fn_ff58629f_000065_cd9dd53e+0x199>
  40e505:	cmp    DWORD PTR [rbx+0x58],0x0
  40e509:	je     40e516 <__swc_fn_ff58629f_000065_cd9dd53e+0x186>
  40e50b:	mov    ecx,DWORD PTR [rbx+0x58]
  40e50e:	dec    rcx
  40e511:	test   rdi,rcx
  40e514:	jne    40e529 <__swc_fn_ff58629f_000065_cd9dd53e+0x199>
  40e516:	mov    QWORD PTR [rbx+0x40],rdi
  40e51a:	add    rsp,0xe0
  40e521:	pop    r13
  40e523:	pop    r12
  40e525:	pop    rdi
  40e526:	pop    rsi
  40e527:	pop    rbx
  40e528:	ret
  40e529:	vmovups xmm0,XMMWORD PTR [rbx]
  40e52d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e533:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40e538:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e53e:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40e543:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e549:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40e54e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40e554:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40e559:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40e55f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40e564:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40e56a:	mov    QWORD PTR [rsp+0x48],0x0
  40e573:	mov    rcx,rsi
  40e576:	lea    rdx,[rsp+0x8]
  40e57b:	call   40b890 <__swc_fn_ff58629f_000064_6905bec4>
  40e580:	mov    rax,QWORD PTR [rsp+0x48]
  40e585:	test   rax,rax
  40e588:	jne    40e5a1 <__swc_fn_ff58629f_000065_cd9dd53e+0x211>
  40e58a:	mov    QWORD PTR [rbx+0x40],0x0
  40e592:	add    rsp,0xe0
  40e599:	pop    r13
  40e59b:	pop    r12
  40e59d:	pop    rdi
  40e59e:	pop    rsi
  40e59f:	pop    rbx
  40e5a0:	ret
  40e5a1:	mov    rax,QWORD PTR [rbx+0x48]
  40e5a5:	cmp    r13,rax
  40e5a8:	cmovbe rax,r13
  40e5ac:	mov    rcx,QWORD PTR [rsp+0x48]
  40e5b1:	mov    rdx,rdi
  40e5b4:	mov    r8,rax
  40e5b7:	call   4090e0 <__swc_fn_ff58629f_000105_b7aef7c0>
  40e5bc:	vmovups xmm0,XMMWORD PTR [rbx]
  40e5c0:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40e5c6:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40e5cb:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40e5d1:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40e5d6:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40e5df:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40e5e4:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40e5ed:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40e5f2:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40e5fb:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40e600:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40e609:	mov    QWORD PTR [rsp+0xa8],rdi
  40e611:	mov    rcx,rsi
  40e614:	lea    rdx,[rsp+0x68]
  40e619:	call   407f90 <__swc_fn_ff58629f_000066_77c6e829>
  40e61e:	mov    rax,QWORD PTR [rsp+0x48]
  40e623:	mov    QWORD PTR [rbx+0x40],rax
  40e627:	add    rsp,0xe0
  40e62e:	pop    r13
  40e630:	pop    r12
  40e632:	pop    rdi
  40e633:	pop    rsi
  40e634:	pop    rbx
  40e635:	ret
	...

000000000040e640 <__swc_fn_ff58629f_000068_557d6092>:
  40e640:	push   r12
  40e642:	push   rdi
  40e643:	push   rsi
  40e644:	push   r13
  40e646:	push   r14
  40e648:	sub    rsp,0x190
  40e64f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40e658:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40e661:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40e66a:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40e673:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40e67c:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40e685:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40e68e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40e697:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40e6a0:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40e6a9:	mov    r12,rcx
  40e6ac:	lea    rax,[rip+0x1294d]        # 421000 <__swc_data_base_ff58629f>
  40e6b3:	mov    rax,QWORD PTR [rax]
  40e6b6:	cmp    rax,0xffffffffffffffff
  40e6ba:	je     40e6c9 <__swc_fn_ff58629f_000068_557d6092+0x89>
  40e6bc:	mov    eax,eax
  40e6be:	mov    edi,eax
  40e6c0:	xor    eax,eax
  40e6c2:	call   407000 <pthread_getspecific@plt>
  40e6c7:	jmp    40e6cb <__swc_fn_ff58629f_000068_557d6092+0x8b>
  40e6c9:	xor    eax,eax
  40e6cb:	test   rax,rax
  40e6ce:	jne    40e6dd <__swc_fn_ff58629f_000068_557d6092+0x9d>
  40e6d0:	call   40a9e0 <__swc_fn_ff58629f_000031_ed8d61a9>
  40e6d5:	mov    rcx,rax
  40e6d8:	call   40fe00 <__swc_fn_ff58629f_000128_9c45d2d7>
  40e6dd:	test   rax,rax
  40e6e0:	je     40e706 <__swc_fn_ff58629f_000068_557d6092+0xc6>
  40e6e2:	cmp    QWORD PTR [rax],r12
  40e6e5:	jne    40e706 <__swc_fn_ff58629f_000068_557d6092+0xc6>
  40e6e7:	xor    ecx,ecx
  40e6e9:	mov    QWORD PTR [rsp+0xc8],rax
  40e6f1:	call   407720 <__swc_fn_ff58629f_000033_7d7574b6>
  40e6f6:	mov    rdx,QWORD PTR [rsp+0xc8]
  40e6fe:	mov    rcx,r12
  40e701:	call   407840 <__swc_fn_ff58629f_000042_70d5ab54>
  40e706:	lea    rsi,[r12+0x10]
  40e70b:	mov    rcx,rsi
  40e70e:	call   4098a0 <__swc_fn_ff58629f_000135_1fec60ac>
  40e713:	mov    rdi,QWORD PTR [r12+0x20]
  40e718:	test   rdi,rdi
  40e71b:	je     40e75e <__swc_fn_ff58629f_000068_557d6092+0x11e>
  40e71d:	nop    DWORD PTR [rax]
  40e720:	mov    rcx,r12
  40e723:	mov    rdx,rdi
  40e726:	call   40aba0 <__swc_fn_ff58629f_000043_3755033a>
  40e72b:	mov    rcx,r12
  40e72e:	mov    rdx,rdi
  40e731:	mov    r8,0xffffffffffffffff
  40e738:	call   40e210 <__swc_fn_ff58629f_000059_c8e1ff6b>
  40e73d:	mov    rcx,r12
  40e740:	mov    rdx,rdi
  40e743:	mov    r8d,0x9b8
  40e749:	mov    r9d,0x9b8
  40e74f:	call   407750 <__swc_fn_ff58629f_000039_05a50673>
  40e754:	mov    rdi,QWORD PTR [r12+0x20]
  40e759:	test   rdi,rdi
  40e75c:	jne    40e720 <__swc_fn_ff58629f_000068_557d6092+0xe0>
  40e75e:	xor    eax,eax
  40e760:	xchg   QWORD PTR [r12+0x2a80],rax
  40e768:	test   rax,rax
  40e76b:	je     40e791 <__swc_fn_ff58629f_000068_557d6092+0x151>
  40e76d:	cs nop WORD PTR [rax+rax*1+0x0]
  40e777:	nop    WORD PTR [rax+rax*1+0x0]
  40e780:	mov    rcx,rax
  40e783:	mov    rax,QWORD PTR [rax+0x78]
  40e787:	xor    edx,edx
  40e789:	xchg   DWORD PTR [rcx+0x70],edx
  40e78c:	test   rax,rax
  40e78f:	jne    40e780 <__swc_fn_ff58629f_000068_557d6092+0x140>
  40e791:	mov    rax,QWORD PTR [r12+0x18]
  40e796:	mov    rdi,rax
  40e799:	test   rdi,rdi
  40e79c:	je     40e831 <__swc_fn_ff58629f_000068_557d6092+0x1f1>
  40e7a2:	cs nop WORD PTR [rax+rax*1+0x0]
  40e7ac:	nop    DWORD PTR [rax+0x0]
  40e7b0:	mov    rax,QWORD PTR [rdi+0x10]
  40e7b4:	mov    r8d,DWORD PTR [rdi+0x2c]
  40e7b8:	xor    r9d,r9d
  40e7bb:	test   r8,r8
  40e7be:	jbe    40e81d <__swc_fn_ff58629f_000068_557d6092+0x1dd>
  40e7c0:	mov    ecx,r9d
  40e7c3:	shl    rcx,0x4
  40e7c7:	lea    rdx,[rdi+rcx*8+0x80]
  40e7cf:	cmp    BYTE PTR [rdx+0x3b],0x0
  40e7d3:	je     40e814 <__swc_fn_ff58629f_000068_557d6092+0x1d4>
  40e7d5:	mov    DWORD PTR [rdx+0x28],0x0
  40e7dc:	mov    rcx,rdi
  40e7df:	mov    QWORD PTR [rsp+0xd0],rax
  40e7e7:	mov    QWORD PTR [rsp+0xd8],r8
  40e7ef:	mov    QWORD PTR [rsp+0xe0],r9
  40e7f7:	call   40d940 <__swc_fn_ff58629f_000014_1acdaf22>
  40e7fc:	mov    rax,QWORD PTR [rsp+0xd0]
  40e804:	mov    r8,QWORD PTR [rsp+0xd8]
  40e80c:	mov    r9,QWORD PTR [rsp+0xe0]
  40e814:	add    r9,0x1
  40e818:	cmp    r9,r8
  40e81b:	jb     40e7c0 <__swc_fn_ff58629f_000068_557d6092+0x180>
  40e81d:	mov    rcx,rdi
  40e820:	mov    rdi,rax
  40e823:	call   407630 <__swc_fn_ff58629f_000021_fe13ecad>
  40e828:	test   rdi,rdi
  40e82b:	jne    40e7b0 <__swc_fn_ff58629f_000068_557d6092+0x170>
  40e831:	mov    QWORD PTR [r12+0x18],0x0
  40e83a:	mov    QWORD PTR [r12+0x28],0x0
  40e843:	mov    rcx,rsi
  40e846:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  40e84b:	mov    esi,0x8
  40e850:	xor    edi,edi
  40e852:	test   rsi,rsi
  40e855:	je     40e8b2 <__swc_fn_ff58629f_000068_557d6092+0x272>
  40e85b:	nop    DWORD PTR [rax+rax*1+0x0]
  40e860:	lea    r13,[rdi*8+0x0]
  40e868:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40e86d:	test   r14,r14
  40e870:	je     40e8a8 <__swc_fn_ff58629f_000068_557d6092+0x268>
  40e872:	cs nop WORD PTR [rax+rax*1+0x0]
  40e87c:	nop    DWORD PTR [rax+0x0]
  40e880:	mov    rcx,r12
  40e883:	mov    rdx,r14
  40e886:	call   407df0 <__swc_fn_ff58629f_000054_1dfec8f6>
  40e88b:	mov    rcx,r12
  40e88e:	mov    rdx,QWORD PTR [r14]
  40e891:	mov    r8,QWORD PTR [r14+0x8]
  40e895:	mov    r9,QWORD PTR [r14+0x10]
  40e899:	call   407750 <__swc_fn_ff58629f_000039_05a50673>
  40e89e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40e8a3:	test   r14,r14
  40e8a6:	jne    40e880 <__swc_fn_ff58629f_000068_557d6092+0x240>
  40e8a8:	add    rdi,0x1
  40e8ac:	sub    rsi,0x1
  40e8b0:	jne    40e860 <__swc_fn_ff58629f_000068_557d6092+0x220>
  40e8b2:	mov    rcx,r12
  40e8b5:	call   407ec0 <__swc_fn_ff58629f_000060_9d59636e>
  40e8ba:	lea    rcx,[r12+0x250]
  40e8c2:	mov    rdx,QWORD PTR [rcx]
  40e8c5:	mov    r8,QWORD PTR [r12+0x250]
  40e8cd:	nop    DWORD PTR [rax]
  40e8d0:	mov    r9,r8
  40e8d3:	sub    r9,rdx
  40e8d6:	mov    rax,r8
  40e8d9:	lock cmpxchg QWORD PTR [rcx],r9
  40e8de:	cmp    rax,r8
  40e8e1:	je     40e8e8 <__swc_fn_ff58629f_000068_557d6092+0x2a8>
  40e8e3:	mov    r8,rax
  40e8e6:	jmp    40e8d0 <__swc_fn_ff58629f_000068_557d6092+0x290>
  40e8e8:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40e8f1:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40e8fa:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40e903:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40e90c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40e915:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40e91e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40e927:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40e930:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40e939:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40e942:	add    rsp,0x190
  40e949:	pop    r14
  40e94b:	pop    r13
  40e94d:	pop    rsi
  40e94e:	pop    rdi
  40e94f:	pop    r12
  40e951:	ret
	...

000000000040e960 <__swc_fn_ff58629f_000071_7e144e9b>:
  40e960:	sub    rsp,0x8
  40e964:	mov    QWORD PTR [rdx+0x40],0x0
  40e96c:	call   40b890 <__swc_fn_ff58629f_000064_6905bec4>
  40e971:	add    rsp,0x8
  40e975:	ret
	...

000000000040e980 <__swc_fn_ff58629f_000074_9eaf4878>:
  40e980:	sub    rsp,0x8
  40e984:	call   407f90 <__swc_fn_ff58629f_000066_77c6e829>
  40e989:	add    rsp,0x8
  40e98d:	ret
	...

000000000040e990 <__swc_fn_ff58629f_000077_e793b5e1>:
  40e990:	push   rbx
  40e991:	push   rsi
  40e992:	push   rdi
  40e993:	push   r12
  40e995:	push   r13
  40e997:	push   r14
  40e999:	push   r15
  40e99b:	sub    rsp,0x20
  40e99f:	mov    rbx,r11
  40e9a2:	mov    rsi,rcx
  40e9a5:	mov    rdi,rdx
  40e9a8:	mov    r12,r8
  40e9ab:	mov    r13,r9
  40e9ae:	mov    r14,r10
  40e9b1:	mov    rcx,QWORD PTR [rip+0x17388]        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  40e9b8:	test   rcx,rcx
  40e9bb:	jne    40e9cd <__swc_fn_ff58629f_000077_e793b5e1+0x3d>
  40e9bd:	call   40a1a0 <__swc_fn_ff58629f_000165_e09accff>
  40e9c2:	lea    rcx,[rax+0x1]
  40e9c6:	mov    QWORD PTR [rip+0x17373],rcx        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  40e9cd:	dec    rcx
  40e9d0:	call   411880 <__swc_fn_ff58629f_000167_3130645d>
  40e9d5:	mov    r15,rax
  40e9d8:	lea    r11,[rip+0x14861]        # 423240 <__swc_bss_base_ff58629f+0x200>
  40e9df:	mov    rcx,r11
  40e9e2:	call   407740 <__swc_fn_ff58629f_000036_62160bb3>
  40e9e7:	test   al,al
  40e9e9:	jne    40e9fa <__swc_fn_ff58629f_000077_e793b5e1+0x6a>
  40e9eb:	mov    rcx,r11
  40e9ee:	call   40aa40 <__swc_fn_ff58629f_000034_c72914a2>
  40e9f3:	lea    r11,[rip+0x14846]        # 423240 <__swc_bss_base_ff58629f+0x200>
  40e9fa:	mov    rcx,r11
  40e9fd:	mov    rdx,rsi
  40ea00:	mov    r8,rdi
  40ea03:	mov    r9,r12
  40ea06:	mov    r10,r13
  40ea09:	mov    rsi,r11
  40ea0c:	mov    r11,r14
  40ea0f:	call   40dcb0 <__swc_fn_ff58629f_000035_6105596e>
  40ea14:	test   bl,bl
  40ea16:	je     40ea3d <__swc_fn_ff58629f_000077_e793b5e1+0xad>
  40ea18:	mov    QWORD PTR [rsp+0x8],rsi
  40ea1d:	lea    rax,[rip+0x372c]        # 412150 <__swc_rdata_base_ff58629f+0x40>
  40ea24:	mov    QWORD PTR [rsp+0x10],rax
  40ea29:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ea2f:	vmovups XMMWORD PTR [r15],xmm0
  40ea34:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40ea3d:	mov    rax,rsi
  40ea40:	add    rsp,0x20
  40ea44:	pop    r15
  40ea46:	pop    r14
  40ea48:	pop    r13
  40ea4a:	pop    r12
  40ea4c:	pop    rdi
  40ea4d:	pop    rsi
  40ea4e:	pop    rbx
  40ea4f:	ret

000000000040ea50 <__swc_fn_ff58629f_000080_851c599a>:
  40ea50:	sub    rsp,0x8
  40ea54:	mov    rax,rcx
  40ea57:	test   rcx,rcx
  40ea5a:	jne    40ea61 <__swc_fn_ff58629f_000080_851c599a+0x11>
  40ea5c:	add    rsp,0x8
  40ea60:	ret
  40ea61:	lea    rcx,[rax-0x10]
  40ea65:	mov    rax,QWORD PTR [rax-0x10]
  40ea69:	mov    rdx,rax
  40ea6c:	call   40fab0 <__swc_fn_ff58629f_000113_25e345b1>
  40ea71:	add    rsp,0x8
  40ea75:	ret
	...

000000000040ea80 <__swc_fn_ff58629f_000083_fb84e43e>:
  40ea80:	sub    rsp,0x8
  40ea84:	xor    r11d,r11d
  40ea87:	call   408250 <__swc_fn_ff58629f_000084_746bf146>
  40ea8c:	add    rsp,0x8
  40ea90:	ret
	...

000000000040eaa0 <__swc_fn_ff58629f_000086_ac8c6565>:
  40eaa0:	push   rsi
  40eaa1:	push   rdi
  40eaa2:	push   r12
  40eaa4:	push   r13
  40eaa6:	push   r14
  40eaa8:	push   r15
  40eaaa:	sub    rsp,0x68
  40eaae:	mov    rsi,r9
  40eab1:	mov    rdi,rcx
  40eab4:	mov    r12,rdx
  40eab7:	mov    r13,r8
  40eaba:	cmp    r8,r9
  40eabd:	jne    40eae5 <__swc_fn_ff58629f_000086_ac8c6565+0x45>
  40eabf:	mov    rcx,rdi
  40eac2:	mov    rdx,r12
  40eac5:	xor    r8d,r8d
  40eac8:	call   4085a0 <__swc_fn_ff58629f_000090_9a1d717d>
  40eacd:	test   al,al
  40eacf:	je     40eae5 <__swc_fn_ff58629f_000086_ac8c6565+0x45>
  40ead1:	mov    eax,0x1
  40ead6:	add    rsp,0x68
  40eada:	pop    r15
  40eadc:	pop    r14
  40eade:	pop    r13
  40eae0:	pop    r12
  40eae2:	pop    rdi
  40eae3:	pop    rsi
  40eae4:	ret
  40eae5:	cmp    BYTE PTR [r12+0x2c],0xe
  40eaeb:	je     40eafe <__swc_fn_ff58629f_000086_ac8c6565+0x5e>
  40eaed:	xor    eax,eax
  40eaef:	add    rsp,0x68
  40eaf3:	pop    r15
  40eaf5:	pop    r14
  40eaf7:	pop    r13
  40eaf9:	pop    r12
  40eafb:	pop    rdi
  40eafc:	pop    rsi
  40eafd:	ret
  40eafe:	mov    r14,QWORD PTR [r12+0x98]
  40eb06:	mov    rax,QWORD PTR [r12+0xa0]
  40eb0e:	mov    r12,rax
  40eb11:	xor    r15d,r15d
  40eb14:	test   r12,r12
  40eb17:	je     40eb7f <__swc_fn_ff58629f_000086_ac8c6565+0xdf>
  40eb19:	nop    DWORD PTR [rax+0x0]
  40eb20:	mov    QWORD PTR [rsp+0x58],r12
  40eb25:	lea    r12,[r15*8+0x0]
  40eb2d:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40eb32:	mov    rcx,rax
  40eb35:	call   40c020 <__swc_fn_ff58629f_000082_9f4f5092>
  40eb3a:	cmp    BYTE PTR [rax+0x2c],0xe
  40eb3e:	jne    40eb70 <__swc_fn_ff58629f_000086_ac8c6565+0xd0>
  40eb40:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40eb45:	lea    r8,[r13+rcx*1+0x0]
  40eb4a:	mov    rcx,rdi
  40eb4d:	mov    rdx,rax
  40eb50:	mov    r9,rsi
  40eb53:	call   40eaa0 <__swc_fn_ff58629f_000086_ac8c6565>
  40eb58:	test   al,al
  40eb5a:	je     40eb70 <__swc_fn_ff58629f_000086_ac8c6565+0xd0>
  40eb5c:	mov    eax,0x1
  40eb61:	add    rsp,0x68
  40eb65:	pop    r15
  40eb67:	pop    r14
  40eb69:	pop    r13
  40eb6b:	pop    r12
  40eb6d:	pop    rdi
  40eb6e:	pop    rsi
  40eb6f:	ret
  40eb70:	add    r15,0x1
  40eb74:	mov    r12,QWORD PTR [rsp+0x58]
  40eb79:	sub    r12,0x1
  40eb7d:	jne    40eb20 <__swc_fn_ff58629f_000086_ac8c6565+0x80>
  40eb7f:	xor    eax,eax
  40eb81:	add    rsp,0x68
  40eb85:	pop    r15
  40eb87:	pop    r14
  40eb89:	pop    r13
  40eb8b:	pop    r12
  40eb8d:	pop    rdi
  40eb8e:	pop    rsi
  40eb8f:	ret

000000000040eb90 <__swc_fn_ff58629f_000089_157b05de>:
  40eb90:	push   rbp
  40eb91:	push   rbx
  40eb92:	push   rsi
  40eb93:	push   rdi
  40eb94:	push   r12
  40eb96:	push   r13
  40eb98:	push   r14
  40eb9a:	push   r15
  40eb9c:	sub    rsp,0x38
  40eba0:	mov    rbp,rsp
  40eba3:	mov    rbx,r11
  40eba6:	mov    rsi,rdx
  40eba9:	mov    rdi,r8
  40ebac:	mov    r12,r9
  40ebaf:	mov    QWORD PTR [rsp+0x18],r9
  40ebb4:	mov    r13,r10
  40ebb7:	movzx  r14d,BYTE PTR [rbp+0x80]
  40ebbf:	movzx  r15d,BYTE PTR [rbp+0x88]
  40ebc7:	test   r11,r11
  40ebca:	je     40ebd0 <__swc_fn_ff58629f_000089_157b05de+0x40>
  40ebcc:	xor    eax,eax
  40ebce:	mov    BYTE PTR [rbx],al
  40ebd0:	test   r12,r12
  40ebd3:	je     40ebde <__swc_fn_ff58629f_000089_157b05de+0x4e>
  40ebd5:	mov    QWORD PTR [r12+0x8],0x0
  40ebde:	test   rcx,rcx
  40ebe1:	je     40ebe8 <__swc_fn_ff58629f_000089_157b05de+0x58>
  40ebe3:	test   rsi,rsi
  40ebe6:	jne    40ebfb <__swc_fn_ff58629f_000089_157b05de+0x6b>
  40ebe8:	xor    eax,eax
  40ebea:	add    rsp,0x38
  40ebee:	pop    r15
  40ebf0:	pop    r14
  40ebf2:	pop    r13
  40ebf4:	pop    r12
  40ebf6:	pop    rdi
  40ebf7:	pop    rsi
  40ebf8:	pop    rbx
  40ebf9:	pop    rbp
  40ebfa:	ret
  40ebfb:	call   40c020 <__swc_fn_ff58629f_000082_9f4f5092>
  40ec00:	mov    r12,rax
  40ec03:	mov    al,r15b
  40ec06:	test   r15b,r15b
  40ec09:	jne    40ec19 <__swc_fn_ff58629f_000089_157b05de+0x89>
  40ec0b:	mov    eax,DWORD PTR [r12+0x28]
  40ec10:	and    eax,0x10000
  40ec16:	setne  al
  40ec19:	lea    r15,[rsp+0x8]
  40ec1e:	mov    QWORD PTR [rsp+0x20],r15
  40ec23:	rex mov BYTE PTR [rsp+0x8],al
  40ec28:	test   DWORD PTR [rsi+0x28],0x400000
  40ec2f:	je     40ec67 <__swc_fn_ff58629f_000089_157b05de+0xd7>
  40ec31:	test   rsi,rsi
  40ec34:	je     40ec54 <__swc_fn_ff58629f_000089_157b05de+0xc4>
  40ec36:	mov    rax,QWORD PTR [rsi+0x38]
  40ec3a:	cmp    QWORD PTR [rax+0x10],rsi
  40ec3e:	jne    40ec54 <__swc_fn_ff58629f_000089_157b05de+0xc4>
  40ec40:	rex mov al,BYTE PTR [rsp+0x8]
  40ec45:	test   al,al
  40ec47:	sete   al
  40ec4a:	test   r14b,r14b
  40ec4d:	sete   cl
  40ec50:	test   al,cl
  40ec52:	je     40ec67 <__swc_fn_ff58629f_000089_157b05de+0xd7>
  40ec54:	xor    eax,eax
  40ec56:	add    rsp,0x38
  40ec5a:	pop    r15
  40ec5c:	pop    r14
  40ec5e:	pop    r13
  40ec60:	pop    r12
  40ec62:	pop    rdi
  40ec63:	pop    rsi
  40ec64:	pop    rbx
  40ec65:	pop    rbp
  40ec66:	ret
  40ec67:	mov    r15,r12
  40ec6a:	test   r14b,r14b
  40ec6d:	jne    40ec84 <__swc_fn_ff58629f_000089_157b05de+0xf4>
  40ec6f:	cmp    BYTE PTR [r12+0x2c],0x6
  40ec75:	jne    40ec84 <__swc_fn_ff58629f_000089_157b05de+0xf4>
  40ec77:	mov    rcx,QWORD PTR [r12+0x40]
  40ec7c:	call   40c020 <__swc_fn_ff58629f_000082_9f4f5092>
  40ec81:	mov    r15,rax
  40ec84:	test   r14b,r14b
  40ec87:	je     40ec8d <__swc_fn_ff58629f_000089_157b05de+0xfd>
  40ec89:	mov    r15,QWORD PTR [r15+0x30]
  40ec8d:	mov    rcx,rsi
  40ec90:	call   40c020 <__swc_fn_ff58629f_000082_9f4f5092>
  40ec95:	mov    rsi,rax
  40ec98:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40ec9d:	je     40ecd4 <__swc_fn_ff58629f_000089_157b05de+0x144>
  40ec9f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40eca4:	je     40ecd4 <__swc_fn_ff58629f_000089_157b05de+0x144>
  40eca6:	mov    eax,DWORD PTR [rsi+0x28]
  40eca9:	and    eax,0x10000
  40ecaf:	je     40ecd4 <__swc_fn_ff58629f_000089_157b05de+0x144>
  40ecb1:	rex mov al,BYTE PTR [rsp+0x8]
  40ecb6:	test   al,al
  40ecb8:	jne    40eccd <__swc_fn_ff58629f_000089_157b05de+0x13d>
  40ecba:	xor    eax,eax
  40ecbc:	add    rsp,0x38
  40ecc0:	pop    r15
  40ecc2:	pop    r14
  40ecc4:	pop    r13
  40ecc6:	pop    r12
  40ecc8:	pop    rdi
  40ecc9:	pop    rsi
  40ecca:	pop    rbx
  40eccb:	pop    rbp
  40eccc:	ret
  40eccd:	mov    rax,QWORD PTR [rsi+0x30]
  40ecd1:	mov    rsi,rax
  40ecd4:	mov    r14b,r13b
  40ecd7:	test   rbx,rbx
  40ecda:	je     40ed10 <__swc_fn_ff58629f_000089_157b05de+0x180>
  40ecdc:	cmp    BYTE PTR [r12+0x2c],0x6
  40ece2:	jne    40ed10 <__swc_fn_ff58629f_000089_157b05de+0x180>
  40ece4:	lea    rdx,[rip+0x3495]        # 412180 <__swc_rdata_base_ff58629f+0x70>
  40eceb:	mov    rcx,rsi
  40ecee:	xor    r8d,r8d
  40ecf1:	call   4085a0 <__swc_fn_ff58629f_000090_9a1d717d>
  40ecf6:	test   al,al
  40ecf8:	je     40ed10 <__swc_fn_ff58629f_000089_157b05de+0x180>
  40ecfa:	mov    BYTE PTR [rbx],0x1
  40ecfd:	xor    eax,eax
  40ecff:	add    rsp,0x38
  40ed03:	pop    r15
  40ed05:	pop    r14
  40ed07:	pop    r13
  40ed09:	pop    r12
  40ed0b:	pop    rdi
  40ed0c:	pop    rsi
  40ed0d:	pop    rbx
  40ed0e:	pop    rbp
  40ed0f:	ret
  40ed10:	test   rdi,rdi
  40ed13:	jne    40ed2d <__swc_fn_ff58629f_000089_157b05de+0x19d>
  40ed15:	test   r13b,r13b
  40ed18:	jne    40ed2d <__swc_fn_ff58629f_000089_157b05de+0x19d>
  40ed1a:	xor    eax,eax
  40ed1c:	add    rsp,0x38
  40ed20:	pop    r15
  40ed22:	pop    r14
  40ed24:	pop    r13
  40ed26:	pop    r12
  40ed28:	pop    rdi
  40ed29:	pop    rsi
  40ed2a:	pop    rbx
  40ed2b:	pop    rbp
  40ed2c:	ret
  40ed2d:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40ed32:	jne    40ede8 <__swc_fn_ff58629f_000089_157b05de+0x258>
  40ed38:	mov    rcx,r15
  40ed3b:	mov    rdx,rsi
  40ed3e:	xor    r8d,r8d
  40ed41:	call   4085a0 <__swc_fn_ff58629f_000090_9a1d717d>
  40ed46:	test   al,al
  40ed48:	jne    40ede8 <__swc_fn_ff58629f_000089_157b05de+0x258>
  40ed4e:	test   DWORD PTR [rsi+0x28],0x10000
  40ed55:	je     40ed73 <__swc_fn_ff58629f_000089_157b05de+0x1e3>
  40ed57:	rex mov al,BYTE PTR [rsp+0x8]
  40ed5c:	test   al,al
  40ed5e:	jne    40ed73 <__swc_fn_ff58629f_000089_157b05de+0x1e3>
  40ed60:	xor    eax,eax
  40ed62:	add    rsp,0x38
  40ed66:	pop    r15
  40ed68:	pop    r14
  40ed6a:	pop    r13
  40ed6c:	pop    r12
  40ed6e:	pop    rdi
  40ed6f:	pop    rsi
  40ed70:	pop    rbx
  40ed71:	pop    rbp
  40ed72:	ret
  40ed73:	test   rdi,rdi
  40ed76:	jne    40ed8b <__swc_fn_ff58629f_000089_157b05de+0x1fb>
  40ed78:	xor    eax,eax
  40ed7a:	add    rsp,0x38
  40ed7e:	pop    r15
  40ed80:	pop    r14
  40ed82:	pop    r13
  40ed84:	pop    r12
  40ed86:	pop    rdi
  40ed87:	pop    rsi
  40ed88:	pop    rbx
  40ed89:	pop    rbp
  40ed8a:	ret
  40ed8b:	mov    rcx,QWORD PTR [rsi+0x40]
  40ed8f:	call   40c020 <__swc_fn_ff58629f_000082_9f4f5092>
  40ed94:	mov    rsi,rax
  40ed97:	mov    rax,QWORD PTR [rdi]
  40ed9a:	mov    rdi,rax
  40ed9d:	test   rax,rax
  40eda0:	jne    40ede3 <__swc_fn_ff58629f_000089_157b05de+0x253>
  40eda2:	test   rbx,rbx
  40eda5:	je     40ede3 <__swc_fn_ff58629f_000089_157b05de+0x253>
  40eda7:	mov    rcx,r15
  40edaa:	mov    rdx,rsi
  40edad:	xor    r8d,r8d
  40edb0:	call   4085a0 <__swc_fn_ff58629f_000090_9a1d717d>
  40edb5:	mov    rcx,rax
  40edb8:	test   al,al
  40edba:	jne    40eddc <__swc_fn_ff58629f_000089_157b05de+0x24c>
  40edbc:	mov    rcx,r15
  40edbf:	mov    rdx,rsi
  40edc2:	call   40c060 <__swc_fn_ff58629f_000085_88128f21>
  40edc7:	mov    rcx,rax
  40edca:	test   al,al
  40edcc:	jne    40eddc <__swc_fn_ff58629f_000089_157b05de+0x24c>
  40edce:	mov    rcx,rsi
  40edd1:	mov    rdx,r15
  40edd4:	call   40c060 <__swc_fn_ff58629f_000085_88128f21>
  40edd9:	mov    rcx,rax
  40eddc:	test   cl,cl
  40edde:	setne  al
  40ede1:	mov    BYTE PTR [rbx],al
  40ede3:	xor    eax,eax
  40ede5:	mov    r14b,al
  40ede8:	test   rdi,rdi
  40edeb:	jne    40ee05 <__swc_fn_ff58629f_000089_157b05de+0x275>
  40eded:	test   r14b,r14b
  40edf0:	jne    40ee05 <__swc_fn_ff58629f_000089_157b05de+0x275>
  40edf2:	xor    eax,eax
  40edf4:	add    rsp,0x38
  40edf8:	pop    r15
  40edfa:	pop    r14
  40edfc:	pop    r13
  40edfe:	pop    r12
  40ee00:	pop    rdi
  40ee01:	pop    rsi
  40ee02:	pop    rbx
  40ee03:	pop    rbp
  40ee04:	ret
  40ee05:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40ee0a:	je     40ee16 <__swc_fn_ff58629f_000089_157b05de+0x286>
  40ee0c:	mov    r12,QWORD PTR [rsp+0x18]
  40ee11:	jmp    40ee9e <__swc_fn_ff58629f_000089_157b05de+0x30e>
  40ee16:	mov    r12,QWORD PTR [rsp+0x18]
  40ee1b:	test   r12,r12
  40ee1e:	jne    40ee32 <__swc_fn_ff58629f_000089_157b05de+0x2a2>
  40ee20:	mov    rcx,r15
  40ee23:	mov    rdx,rsi
  40ee26:	xor    r8d,r8d
  40ee29:	call   4085a0 <__swc_fn_ff58629f_000090_9a1d717d>
  40ee2e:	test   al,al
  40ee30:	jne    40ee9e <__swc_fn_ff58629f_000089_157b05de+0x30e>
  40ee32:	test   DWORD PTR [rsi+0x28],0x10000
  40ee39:	je     40ee57 <__swc_fn_ff58629f_000089_157b05de+0x2c7>
  40ee3b:	rex mov al,BYTE PTR [rsp+0x8]
  40ee40:	test   al,al
  40ee42:	jne    40ee57 <__swc_fn_ff58629f_000089_157b05de+0x2c7>
  40ee44:	xor    eax,eax
  40ee46:	add    rsp,0x38
  40ee4a:	pop    r15
  40ee4c:	pop    r14
  40ee4e:	pop    r13
  40ee50:	pop    r12
  40ee52:	pop    rdi
  40ee53:	pop    rsi
  40ee54:	pop    rbx
  40ee55:	pop    rbp
  40ee56:	ret
  40ee57:	test   rdi,rdi
  40ee5a:	jne    40ee6f <__swc_fn_ff58629f_000089_157b05de+0x2df>
  40ee5c:	xor    eax,eax
  40ee5e:	add    rsp,0x38
  40ee62:	pop    r15
  40ee64:	pop    r14
  40ee66:	pop    r13
  40ee68:	pop    r12
  40ee6a:	pop    rdi
  40ee6b:	pop    rsi
  40ee6c:	pop    rbx
  40ee6d:	pop    rbp
  40ee6e:	ret
  40ee6f:	cmp    QWORD PTR [rdi+0x8],0x0
  40ee74:	jne    40ee89 <__swc_fn_ff58629f_000089_157b05de+0x2f9>
  40ee76:	xor    eax,eax
  40ee78:	add    rsp,0x38
  40ee7c:	pop    r15
  40ee7e:	pop    r14
  40ee80:	pop    r13
  40ee82:	pop    r12
  40ee84:	pop    rdi
  40ee85:	pop    rsi
  40ee86:	pop    rbx
  40ee87:	pop    rbp
  40ee88:	ret
  40ee89:	mov    rax,QWORD PTR [rdi+0x8]
  40ee8d:	mov    rax,QWORD PTR [rax]
  40ee90:	mov    rsi,rax
  40ee93:	mov    rdi,QWORD PTR [rdi]
  40ee96:	mov    eax,0x1
  40ee9b:	mov    r14b,al
  40ee9e:	test   rdi,rdi
  40eea1:	mov    rbx,QWORD PTR [rsp+0x20]
  40eea6:	jne    40eef0 <__swc_fn_ff58629f_000089_157b05de+0x360>
  40eea8:	test   r14b,r14b
  40eeab:	je     40eedd <__swc_fn_ff58629f_000089_157b05de+0x34d>
  40eead:	test   r12,r12
  40eeb0:	je     40eedd <__swc_fn_ff58629f_000089_157b05de+0x34d>
  40eeb2:	mov    rcx,r15
  40eeb5:	mov    rdx,rsi
  40eeb8:	xor    r8d,r8d
  40eebb:	mov    r9,r12
  40eebe:	mov    rbx,QWORD PTR [rsp+0x20]
  40eec3:	movzx  r10d,BYTE PTR [rbx]
  40eec7:	call   40ea80 <__swc_fn_ff58629f_000083_fb84e43e>
  40eecc:	add    rsp,0x38
  40eed0:	pop    r15
  40eed2:	pop    r14
  40eed4:	pop    r13
  40eed6:	pop    r12
  40eed8:	pop    rdi
  40eed9:	pop    rsi
  40eeda:	pop    rbx
  40eedb:	pop    rbp
  40eedc:	ret
  40eedd:	xor    eax,eax
  40eedf:	add    rsp,0x38
  40eee3:	pop    r15
  40eee5:	pop    r14
  40eee7:	pop    r13
  40eee9:	pop    r12
  40eeeb:	pop    rdi
  40eeec:	pop    rsi
  40eeed:	pop    rbx
  40eeee:	pop    rbp
  40eeef:	ret
  40eef0:	mov    r13,rsi
  40eef3:	mov    QWORD PTR [rsp+0x28],rdi
  40eef8:	cmp    BYTE PTR [r15+0x2c],0xe
  40eefd:	sete   al
  40ef00:	mov    r14b,al
  40ef03:	jne    40ef17 <__swc_fn_ff58629f_000089_157b05de+0x387>
  40ef05:	mov    rcx,rsi
  40ef08:	mov    rdx,r15
  40ef0b:	call   40c060 <__swc_fn_ff58629f_000085_88128f21>
  40ef10:	mov    r14b,al
  40ef13:	test   al,al
  40ef15:	jne    40ef4c <__swc_fn_ff58629f_000089_157b05de+0x3bc>
  40ef17:	cmp    BYTE PTR [r15+0x2c],0x12
  40ef1c:	je     40ef4c <__swc_fn_ff58629f_000089_157b05de+0x3bc>
  40ef1e:	mov    rcx,r15
  40ef21:	mov    rdx,rsi
  40ef24:	mov    r8,rdi
  40ef27:	mov    r9,r12
  40ef2a:	mov    rax,rbx
  40ef2d:	movzx  r10d,BYTE PTR [rax]
  40ef31:	call   40ea80 <__swc_fn_ff58629f_000083_fb84e43e>
  40ef36:	test   rax,rax
  40ef39:	je     40ef4c <__swc_fn_ff58629f_000089_157b05de+0x3bc>
  40ef3b:	add    rsp,0x38
  40ef3f:	pop    r15
  40ef41:	pop    r14
  40ef43:	pop    r13
  40ef45:	pop    r12
  40ef47:	pop    rdi
  40ef48:	pop    rsi
  40ef49:	pop    rbx
  40ef4a:	pop    rbp
  40ef4b:	ret
  40ef4c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40ef51:	jne    40ef70 <__swc_fn_ff58629f_000089_157b05de+0x3e0>
  40ef53:	mov    rax,QWORD PTR [rsi+0xd8]
  40ef5a:	test   rax,rax
  40ef5d:	je     40ef70 <__swc_fn_ff58629f_000089_157b05de+0x3e0>
  40ef5f:	add    rdi,QWORD PTR [rax+0x8]
  40ef63:	mov    rax,QWORD PTR [rdi]
  40ef66:	sub    rdi,QWORD PTR [rax+0x8]
  40ef6a:	mov    rax,QWORD PTR [rax]
  40ef6d:	mov    rsi,rax
  40ef70:	test   r14b,r14b
  40ef73:	je     40ef9f <__swc_fn_ff58629f_000089_157b05de+0x40f>
  40ef75:	mov    rcx,r15
  40ef78:	mov    rdx,rsi
  40ef7b:	mov    r8,rdi
  40ef7e:	mov    r9,r13
  40ef81:	mov    r14,QWORD PTR [rsp+0x28]
  40ef86:	mov    r10,r14
  40ef89:	call   408480 <__swc_fn_ff58629f_000087_1fb4fcfe>
  40ef8e:	add    rsp,0x38
  40ef92:	pop    r15
  40ef94:	pop    r14
  40ef96:	pop    r13
  40ef98:	pop    r12
  40ef9a:	pop    rdi
  40ef9b:	pop    rsi
  40ef9c:	pop    rbx
  40ef9d:	pop    rbp
  40ef9e:	ret
  40ef9f:	mov    rcx,r15
  40efa2:	mov    rdx,rsi
  40efa5:	mov    r8,rdi
  40efa8:	mov    r9,r12
  40efab:	movzx  r10d,BYTE PTR [rbx]
  40efaf:	call   40ea80 <__swc_fn_ff58629f_000083_fb84e43e>
  40efb4:	add    rsp,0x38
  40efb8:	pop    r15
  40efba:	pop    r14
  40efbc:	pop    r13
  40efbe:	pop    r12
  40efc0:	pop    rdi
  40efc1:	pop    rsi
  40efc2:	pop    rbx
  40efc3:	pop    rbp
  40efc4:	ret
	...

000000000040efd0 <__swc_fn_ff58629f_000092_17e20532>:
  40efd0:	push   rbx
  40efd1:	push   rsi
  40efd2:	sub    rsp,0x18
  40efd6:	mov    rbx,rcx
  40efd9:	mov    rcx,QWORD PTR [rip+0x16d60]        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  40efe0:	test   rcx,rcx
  40efe3:	jne    40eff5 <__swc_fn_ff58629f_000092_17e20532+0x25>
  40efe5:	call   40a1a0 <__swc_fn_ff58629f_000165_e09accff>
  40efea:	lea    rcx,[rax+0x1]
  40efee:	mov    QWORD PTR [rip+0x16d4b],rcx        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  40eff5:	dec    rcx
  40eff8:	call   411880 <__swc_fn_ff58629f_000167_3130645d>
  40effd:	mov    rsi,rax
  40f000:	mov    rax,QWORD PTR [rsi+0x8]
  40f004:	test   rax,rax
  40f007:	jne    40f057 <__swc_fn_ff58629f_000092_17e20532+0x87>
  40f009:	call   40c150 <__swc_fn_ff58629f_000091_e6773530>
  40f00e:	test   al,al
  40f010:	jne    40f057 <__swc_fn_ff58629f_000092_17e20532+0x87>
  40f012:	lea    rdx,[rip+0x14227]        # 423240 <__swc_bss_base_ff58629f+0x200>
  40f019:	mov    rcx,rdx
  40f01c:	call   407740 <__swc_fn_ff58629f_000036_62160bb3>
  40f021:	test   al,al
  40f023:	jne    40f034 <__swc_fn_ff58629f_000092_17e20532+0x64>
  40f025:	mov    rcx,rdx
  40f028:	call   40aa40 <__swc_fn_ff58629f_000034_c72914a2>
  40f02d:	lea    rdx,[rip+0x1420c]        # 423240 <__swc_bss_base_ff58629f+0x200>
  40f034:	mov    QWORD PTR [rsp+0x8],rdx
  40f039:	lea    rax,[rip+0x3110]        # 412150 <__swc_rdata_base_ff58629f+0x40>
  40f040:	mov    QWORD PTR [rsp+0x10],rax
  40f045:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f04b:	vmovups XMMWORD PTR [rsi],xmm0
  40f04f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40f057:	vmovups xmm0,XMMWORD PTR [rsi]
  40f05b:	vmovups XMMWORD PTR [rbx],xmm0
  40f05f:	mov    rax,rbx
  40f062:	add    rsp,0x18
  40f066:	pop    rsi
  40f067:	pop    rbx
  40f068:	ret
  40f069:	add    BYTE PTR [rax],al
  40f06b:	add    BYTE PTR [rax],al
  40f06d:	add    BYTE PTR [rax],al
	...

000000000040f070 <__swc_fn_ff58629f_000095_a3245f7e>:
  40f070:	sub    rsp,0x8
  40f074:	call   409340 <__swc_fn_ff58629f_000117_76ff2f0a>
  40f079:	add    rsp,0x8
  40f07d:	ret
	...

000000000040f080 <__swc_fn_ff58629f_000098_d9d80f1a>:
  40f080:	push   rbx
  40f081:	push   rsi
  40f082:	sub    rsp,0x28
  40f086:	mov    rbx,rcx
  40f089:	xor    esi,esi
  40f08b:	jmp    40f0a0 <__swc_fn_ff58629f_000098_d9d80f1a+0x20>
  40f08d:	nop    DWORD PTR [rax]
  40f090:	mov    QWORD PTR [rbx+0x28],rsi
  40f094:	mov    rsi,rbx
  40f097:	mov    rbx,rax
  40f09a:	nop    WORD PTR [rax+rax*1+0x0]
  40f0a0:	test   rbx,rbx
  40f0a3:	je     40f103 <__swc_fn_ff58629f_000098_d9d80f1a+0x83>
  40f0a5:	mov    rcx,rbx
  40f0a8:	mov    edx,0x1
  40f0ad:	call   408200 <__swc_fn_ff58629f_000078_5a70c27a>
  40f0b2:	cmp    rax,0x1
  40f0b6:	jne    40f103 <__swc_fn_ff58629f_000098_d9d80f1a+0x83>
  40f0b8:	mov    r10,QWORD PTR [rbx+0x18]
  40f0bc:	mov    rcx,r10
  40f0bf:	mov    edx,0x1
  40f0c4:	call   408200 <__swc_fn_ff58629f_000078_5a70c27a>
  40f0c9:	cmp    rax,0x1
  40f0cd:	jne    40f0dc <__swc_fn_ff58629f_000098_d9d80f1a+0x5c>
  40f0cf:	mov    rcx,r10
  40f0d2:	call   40c2f0 <__swc_fn_ff58629f_000097_8b4a07e9>
  40f0d7:	test   rax,rax
  40f0da:	jne    40f090 <__swc_fn_ff58629f_000098_d9d80f1a+0x10>
  40f0dc:	mov    rax,QWORD PTR [rbx+0x20]
  40f0e0:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40f0e5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f0eb:	lea    rcx,[rsp+0x8]
  40f0f0:	mov    rdx,rbx
  40f0f3:	mov    r8d,0x30
  40f0f9:	mov    rbx,rax
  40f0fc:	call   408960 <__swc_fn_ff58629f_000096_f879630a>
  40f101:	jmp    40f0a0 <__swc_fn_ff58629f_000098_d9d80f1a+0x20>
  40f103:	test   rsi,rsi
  40f106:	jne    40f10f <__swc_fn_ff58629f_000098_d9d80f1a+0x8f>
  40f108:	add    rsp,0x28
  40f10c:	pop    rsi
  40f10d:	pop    rbx
  40f10e:	ret
  40f10f:	mov    rax,rsi
  40f112:	mov    rsi,QWORD PTR [rsi+0x28]
  40f116:	mov    rbx,QWORD PTR [rax+0x20]
  40f11a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40f11f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f125:	lea    rcx,[rsp+0x18]
  40f12a:	mov    rdx,rax
  40f12d:	mov    r8d,0x30
  40f133:	call   408960 <__swc_fn_ff58629f_000096_f879630a>
  40f138:	jmp    40f0a0 <__swc_fn_ff58629f_000098_d9d80f1a+0x20>
  40f13d:	add    BYTE PTR [rax],al
	...

000000000040f140 <__swc_fn_ff58629f_000101_295ddd7c>:
  40f140:	push   rbx
  40f141:	push   rsi
  40f142:	push   rdi
  40f143:	push   r12
  40f145:	push   r13
  40f147:	sub    rsp,0x20
  40f14b:	mov    rbx,rcx
  40f14e:	lea    rsi,[rcx+0x6f8]
  40f155:	mov    edi,0x4
  40f15a:	mov    r12,rsi
  40f15d:	test   rdi,rdi
  40f160:	je     40f1aa <__swc_fn_ff58629f_000101_295ddd7c+0x6a>
  40f162:	cs nop WORD PTR [rax+rax*1+0x0]
  40f16c:	nop    DWORD PTR [rax+0x0]
  40f170:	mov    rcx,QWORD PTR [r12+0x10]
  40f175:	mov    QWORD PTR [r12+0x10],0x0
  40f17e:	vxorps xmm0,xmm0,xmm0
  40f182:	vmovups XMMWORD PTR [r12],xmm0
  40f188:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40f18f:	mov    DWORD PTR [r12+0x20],0x0
  40f198:	call   4089b0 <__swc_fn_ff58629f_000099_6e0faaee>
  40f19d:	add    r12,0x90
  40f1a4:	sub    rdi,0x1
  40f1a8:	jne    40f170 <__swc_fn_ff58629f_000101_295ddd7c+0x30>
  40f1aa:	mov    rax,QWORD PTR [rbx+0x938]
  40f1b1:	mov    rdi,rax
  40f1b4:	test   rdi,rdi
  40f1b7:	je     40f211 <__swc_fn_ff58629f_000101_295ddd7c+0xd1>
  40f1b9:	nop    DWORD PTR [rax+0x0]
  40f1c0:	mov    r12d,0x10
  40f1c6:	lea    r13,[rdi+0x18]
  40f1ca:	test   r12,r12
  40f1cd:	je     40f206 <__swc_fn_ff58629f_000101_295ddd7c+0xc6>
  40f1cf:	nop
  40f1d0:	mov    rcx,QWORD PTR [r13+0x10]
  40f1d4:	mov    QWORD PTR [r13+0x10],0x0
  40f1dc:	vxorps xmm0,xmm0,xmm0
  40f1e0:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40f1e6:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40f1ec:	mov    DWORD PTR [r13+0x20],0x0
  40f1f4:	call   4089b0 <__swc_fn_ff58629f_000099_6e0faaee>
  40f1f9:	add    r13,0x90
  40f200:	sub    r12,0x1
  40f204:	jne    40f1d0 <__swc_fn_ff58629f_000101_295ddd7c+0x90>
  40f206:	mov    rax,QWORD PTR [rdi]
  40f209:	mov    rdi,rax
  40f20c:	test   rax,rax
  40f20f:	jne    40f1c0 <__swc_fn_ff58629f_000101_295ddd7c+0x80>
  40f211:	vxorps xmm0,xmm0,xmm0
  40f215:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40f21d:	mov    DWORD PTR [rbx+0x9b0],0x0
  40f227:	mov    DWORD PTR [rbx+0x9a8],0x0
  40f231:	mov    edi,0x4
  40f236:	mov    r12,rsi
  40f239:	lea    rsi,[rsi+0x38]
  40f23d:	test   rdi,rdi
  40f240:	je     40f26c <__swc_fn_ff58629f_000101_295ddd7c+0x12c>
  40f242:	cs nop WORD PTR [rax+rax*1+0x0]
  40f24c:	nop    DWORD PTR [rax+0x0]
  40f250:	mov    rcx,rsi
  40f253:	call   40d170 <__swc_fn_ff58629f_000157_5c8b11d8>
  40f258:	add    rsi,0x90
  40f25f:	add    r12,0x90
  40f266:	sub    rdi,0x1
  40f26a:	jne    40f250 <__swc_fn_ff58629f_000101_295ddd7c+0x110>
  40f26c:	mov    rax,QWORD PTR [rbx+0x938]
  40f273:	mov    rdi,rax
  40f276:	mov    QWORD PTR [rbx+0x938],0x0
  40f281:	test   rdi,rdi
  40f284:	je     40f2f5 <__swc_fn_ff58629f_000101_295ddd7c+0x1b5>
  40f28a:	nop    WORD PTR [rax+rax*1+0x0]
  40f290:	mov    esi,0x10
  40f295:	lea    r12,[rdi+0x18]
  40f299:	lea    r13,[rdi+0x50]
  40f29d:	test   rsi,rsi
  40f2a0:	je     40f2cc <__swc_fn_ff58629f_000101_295ddd7c+0x18c>
  40f2a2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f2ac:	nop    DWORD PTR [rax+0x0]
  40f2b0:	mov    rcx,r13
  40f2b3:	call   40d170 <__swc_fn_ff58629f_000157_5c8b11d8>
  40f2b8:	add    r13,0x90
  40f2bf:	add    r12,0x90
  40f2c6:	sub    rsi,0x1
  40f2ca:	jne    40f2b0 <__swc_fn_ff58629f_000101_295ddd7c+0x170>
  40f2cc:	mov    rax,QWORD PTR [rdi]
  40f2cf:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40f2d4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f2da:	lea    rcx,[rsp+0x8]
  40f2df:	mov    rdx,rdi
  40f2e2:	mov    r8d,0x918
  40f2e8:	mov    rdi,rax
  40f2eb:	call   408960 <__swc_fn_ff58629f_000096_f879630a>
  40f2f0:	test   rdi,rdi
  40f2f3:	jne    40f290 <__swc_fn_ff58629f_000101_295ddd7c+0x150>
  40f2f5:	lea    rcx,[rbx+0x68]
  40f2f9:	call   40d170 <__swc_fn_ff58629f_000157_5c8b11d8>
  40f2fe:	add    rsp,0x20
  40f302:	pop    r13
  40f304:	pop    r12
  40f306:	pop    rdi
  40f307:	pop    rsi
  40f308:	pop    rbx
  40f309:	ret
  40f30a:	add    BYTE PTR [rax],al
  40f30c:	add    BYTE PTR [rax],al
	...

000000000040f310 <__swc_fn_ff58629f_000104_baf871f8>:
  40f310:	xor    eax,eax
  40f312:	cs nop WORD PTR [rax+rax*1+0x0]
  40f31c:	nop    DWORD PTR [rax+0x0]
  40f320:	mov    r9,r8
  40f323:	sub    r9,rax
  40f326:	cmp    r9,0x40
  40f32a:	jb     40f368 <__swc_fn_ff58629f_000104_baf871f8+0x58>
  40f32c:	lea    r9,[rcx+rax*1]
  40f330:	lea    r10,[rdx+rax*1]
  40f334:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40f33a:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40f340:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40f346:	vmovups xmm3,XMMWORD PTR [r10]
  40f34b:	vmovups XMMWORD PTR [r9],xmm3
  40f350:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40f356:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40f35c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40f362:	lea    rax,[rax+0x40]
  40f366:	jmp    40f320 <__swc_fn_ff58629f_000104_baf871f8+0x10>
  40f368:	nop    DWORD PTR [rax+rax*1+0x0]
  40f370:	mov    r9,r8
  40f373:	sub    r9,rax
  40f376:	cmp    r9,0x10
  40f37a:	jb     40f394 <__swc_fn_ff58629f_000104_baf871f8+0x84>
  40f37c:	lea    r9,[rdx+rax*1]
  40f380:	lea    r10,[rcx+rax*1]
  40f384:	vmovups xmm0,XMMWORD PTR [r9]
  40f389:	vmovups XMMWORD PTR [r10],xmm0
  40f38e:	lea    rax,[rax+0x10]
  40f392:	jmp    40f370 <__swc_fn_ff58629f_000104_baf871f8+0x60>
  40f394:	cs nop WORD PTR [rax+rax*1+0x0]
  40f39e:	xchg   ax,ax
  40f3a0:	mov    r9,r8
  40f3a3:	sub    r9,rax
  40f3a6:	cmp    r9,0x8
  40f3aa:	jb     40f3bd <__swc_fn_ff58629f_000104_baf871f8+0xad>
  40f3ac:	lea    r9,[rcx+rax*1]
  40f3b0:	mov    r10,QWORD PTR [rdx+rax*1]
  40f3b4:	mov    QWORD PTR [r9],r10
  40f3b7:	lea    rax,[rax+0x8]
  40f3bb:	jmp    40f3a0 <__swc_fn_ff58629f_000104_baf871f8+0x90>
  40f3bd:	cmp    rax,r8
  40f3c0:	jae    40f3e0 <__swc_fn_ff58629f_000104_baf871f8+0xd0>
  40f3c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f3cc:	nop    DWORD PTR [rax+0x0]
  40f3d0:	mov    r9b,BYTE PTR [rdx+rax*1]
  40f3d4:	mov    BYTE PTR [rcx+rax*1],r9b
  40f3d8:	inc    rax
  40f3db:	cmp    rax,r8
  40f3de:	jb     40f3d0 <__swc_fn_ff58629f_000104_baf871f8+0xc0>
  40f3e0:	ret
	...

000000000040f3f0 <__swc_fn_ff58629f_000107_ff529476>:
  40f3f0:	push   rbx
  40f3f1:	push   r12
  40f3f3:	push   rdi
  40f3f4:	push   rsi
  40f3f5:	push   r13
  40f3f7:	push   r14
  40f3f9:	push   r15
  40f3fb:	sub    rsp,0x170
  40f402:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40f40b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40f414:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40f41d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40f426:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40f42f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40f438:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40f441:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40f44a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40f453:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40f45c:	mov    ebx,edx
  40f45e:	mov    QWORD PTR [rsp+0xa8],rbx
  40f466:	mov    r12d,ecx
  40f469:	test   edx,edx
  40f46b:	jne    40f482 <__swc_fn_ff58629f_000107_ff529476+0x92>
  40f46d:	xor    eax,eax
  40f46f:	add    rsp,0x170
  40f476:	pop    r15
  40f478:	pop    r14
  40f47a:	pop    r13
  40f47c:	pop    rsi
  40f47d:	pop    rdi
  40f47e:	pop    r12
  40f480:	pop    rbx
  40f481:	ret
  40f482:	lea    rdi,[rip+0x3027]        # 4124b0 <__swc_rdata_base_ff58629f+0x3a0>
  40f489:	mov    esi,0x90000
  40f48e:	xor    eax,eax
  40f490:	call   407090 <open@plt>
  40f495:	mov    r13,rax
  40f498:	mov    QWORD PTR [rsp+0xb0],rax
  40f4a0:	test   eax,eax
  40f4a2:	jge    40f4ab <__swc_fn_ff58629f_000107_ff529476+0xbb>
  40f4a4:	xor    eax,eax
  40f4a6:	jmp    40f9a6 <__swc_fn_ff58629f_000107_ff529476+0x5b6>
  40f4ab:	nop    DWORD PTR [rax+rax*1+0x0]
  40f4b0:	movsxd rdi,r13d
  40f4b3:	mov    esi,0x2
  40f4b8:	xor    eax,eax
  40f4ba:	call   407120 <flock@plt>
  40f4bf:	test   eax,eax
  40f4c1:	je     40f4e0 <__swc_fn_ff58629f_000107_ff529476+0xf0>
  40f4c3:	xor    eax,eax
  40f4c5:	call   407130 <__errno_location@plt>
  40f4ca:	cmp    DWORD PTR [rax],0x4
  40f4cd:	je     40f4b0 <__swc_fn_ff58629f_000107_ff529476+0xc0>
  40f4cf:	movsxd rdi,r13d
  40f4d2:	xor    eax,eax
  40f4d4:	call   4070b0 <close@plt>
  40f4d9:	xor    eax,eax
  40f4db:	jmp    40f9a6 <__swc_fn_ff58629f_000107_ff529476+0x5b6>
  40f4e0:	lea    r14,[rsp+0x8]
  40f4e5:	mov    QWORD PTR [rsp+0xb8],r14
  40f4ed:	vxorps xmm0,xmm0,xmm0
  40f4f1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f4f7:	mov    QWORD PTR [rsp+0x18],0x0
  40f500:	mov    WORD PTR [rsp+0x20],0x0
  40f507:	mov    DWORD PTR [r14],0x67617753
  40f50e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40f516:	xor    eax,eax
  40f518:	call   407010 <getpid@plt>
  40f51d:	mov    ecx,eax
  40f51f:	mov    eax,0x1c
  40f524:	shrx   eax,ecx,eax
  40f529:	and    eax,0xf
  40f52c:	mov    rdx,QWORD PTR [rip+0x2f9d]        # 4124d0 <__swc_rdata_base_ff58629f+0x3c0>
  40f533:	mov    al,BYTE PTR [rdx+rax*1]
  40f536:	rex mov BYTE PTR [rsp+0x10],al
  40f53b:	mov    eax,0x1c
  40f540:	shrx   eax,r12d,eax
  40f545:	and    eax,0xf
  40f548:	mov    al,BYTE PTR [rdx+rax*1]
  40f54b:	rex mov BYTE PTR [rsp+0x19],al
  40f550:	mov    eax,0x18
  40f555:	shrx   eax,ecx,eax
  40f55a:	and    eax,0xf
  40f55d:	mov    al,BYTE PTR [rdx+rax*1]
  40f560:	rex mov BYTE PTR [rsp+0x11],al
  40f565:	mov    eax,0x18
  40f56a:	shrx   eax,r12d,eax
  40f56f:	and    eax,0xf
  40f572:	mov    al,BYTE PTR [rdx+rax*1]
  40f575:	rex mov BYTE PTR [rsp+0x1a],al
  40f57a:	mov    eax,0x14
  40f57f:	shrx   eax,ecx,eax
  40f584:	and    eax,0xf
  40f587:	mov    al,BYTE PTR [rdx+rax*1]
  40f58a:	rex mov BYTE PTR [rsp+0x12],al
  40f58f:	mov    eax,0x14
  40f594:	shrx   eax,r12d,eax
  40f599:	and    eax,0xf
  40f59c:	mov    al,BYTE PTR [rdx+rax*1]
  40f59f:	rex mov BYTE PTR [rsp+0x1b],al
  40f5a4:	mov    eax,0x10
  40f5a9:	shrx   eax,ecx,eax
  40f5ae:	and    eax,0xf
  40f5b1:	mov    al,BYTE PTR [rdx+rax*1]
  40f5b4:	rex mov BYTE PTR [rsp+0x13],al
  40f5b9:	mov    eax,0x10
  40f5be:	shrx   eax,r12d,eax
  40f5c3:	and    eax,0xf
  40f5c6:	mov    al,BYTE PTR [rdx+rax*1]
  40f5c9:	rex mov BYTE PTR [rsp+0x1c],al
  40f5ce:	mov    eax,0xc
  40f5d3:	shrx   eax,ecx,eax
  40f5d8:	and    eax,0xf
  40f5db:	mov    al,BYTE PTR [rdx+rax*1]
  40f5de:	rex mov BYTE PTR [rsp+0x14],al
  40f5e3:	mov    eax,0xc
  40f5e8:	shrx   eax,r12d,eax
  40f5ed:	and    eax,0xf
  40f5f0:	mov    al,BYTE PTR [rdx+rax*1]
  40f5f3:	rex mov BYTE PTR [rsp+0x1d],al
  40f5f8:	mov    eax,0x8
  40f5fd:	shrx   eax,ecx,eax
  40f602:	and    eax,0xf
  40f605:	mov    al,BYTE PTR [rdx+rax*1]
  40f608:	rex mov BYTE PTR [rsp+0x15],al
  40f60d:	mov    eax,0x8
  40f612:	shrx   eax,r12d,eax
  40f617:	and    eax,0xf
  40f61a:	mov    al,BYTE PTR [rdx+rax*1]
  40f61d:	rex mov BYTE PTR [rsp+0x1e],al
  40f622:	mov    eax,0x4
  40f627:	shrx   eax,ecx,eax
  40f62c:	and    eax,0xf
  40f62f:	mov    al,BYTE PTR [rdx+rax*1]
  40f632:	rex mov BYTE PTR [rsp+0x16],al
  40f637:	mov    eax,0x4
  40f63c:	shrx   eax,r12d,eax
  40f641:	and    eax,0xf
  40f644:	mov    al,BYTE PTR [rdx+rax*1]
  40f647:	rex mov BYTE PTR [rsp+0x1f],al
  40f64c:	xor    eax,eax
  40f64e:	shrx   eax,ecx,eax
  40f653:	and    eax,0xf
  40f656:	mov    al,BYTE PTR [rdx+rax*1]
  40f659:	rex mov BYTE PTR [rsp+0x17],al
  40f65e:	xor    eax,eax
  40f660:	shrx   eax,r12d,eax
  40f665:	and    eax,0xf
  40f668:	mov    al,BYTE PTR [rdx+rax*1]
  40f66b:	rex mov BYTE PTR [rsp+0x20],al
  40f670:	mov    BYTE PTR [r14+0x10],0x2e
  40f675:	lea    r12,[rsp+0x22]
  40f67a:	vxorps xmm0,xmm0,xmm0
  40f67e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40f684:	mov    DWORD PTR [r12],0x6d656d2f
  40f68c:	mov    WORD PTR [r12+0x4],0x6466
  40f694:	mov    BYTE PTR [r12+0x6],0x3a
  40f69a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f6a0:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40f6a6:	mov    rax,QWORD PTR [rsp+0x18]
  40f6ab:	mov    QWORD PTR [rsp+0x39],rax
  40f6b0:	rex mov al,BYTE PTR [rsp+0x20]
  40f6b5:	rex mov BYTE PTR [rsp+0x41],al
  40f6ba:	mov    DWORD PTR [r12+0x20],0x65642820
  40f6c3:	mov    DWORD PTR [r12+0x24],0x6574656c
  40f6cc:	mov    WORD PTR [r12+0x28],0x2964
  40f6d4:	lea    rdi,[rip+0x2de0]        # 4124bb <__swc_rdata_base_ff58629f+0x3ab>
  40f6db:	xor    eax,eax
  40f6dd:	call   407140 <opendir@plt>
  40f6e2:	mov    r15,rax
  40f6e5:	test   rax,rax
  40f6e8:	jne    40f6fb <__swc_fn_ff58629f_000107_ff529476+0x30b>
  40f6ea:	movsxd rdi,r13d
  40f6ed:	xor    eax,eax
  40f6ef:	call   4070b0 <close@plt>
  40f6f4:	xor    eax,eax
  40f6f6:	jmp    40f9a6 <__swc_fn_ff58629f_000107_ff529476+0x5b6>
  40f6fb:	mov    rdi,r15
  40f6fe:	xor    eax,eax
  40f700:	call   407150 <dirfd@plt>
  40f705:	lea    r14,[rsp+0x54]
  40f70a:	mov    DWORD PTR [rsp+0x54],eax
  40f70e:	lea    rbx,[rsp+0x58]
  40f713:	cs nop WORD PTR [rax+rax*1+0x0]
  40f71d:	nop    DWORD PTR [rax]
  40f720:	mov    rdi,r15
  40f723:	xor    eax,eax
  40f725:	call   407160 <readdir@plt>
  40f72a:	test   rax,rax
  40f72d:	jne    40f744 <__swc_fn_ff58629f_000107_ff529476+0x354>
  40f72f:	mov    r12,QWORD PTR [rsp+0xa8]
  40f737:	mov    r13,QWORD PTR [rsp+0xb0]
  40f73f:	jmp    40f8ca <__swc_fn_ff58629f_000107_ff529476+0x4da>
  40f744:	vxorps xmm0,xmm0,xmm0
  40f748:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  40f74e:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  40f754:	vzeroupper
  40f757:	lea    r13,[rax+0x13]
  40f75b:	mov    rax,r14
  40f75e:	movsxd rdi,DWORD PTR [rax]
  40f761:	mov    rsi,r13
  40f764:	mov    rdx,rbx
  40f767:	mov    ecx,0x40
  40f76c:	xor    eax,eax
  40f76e:	call   407170 <readlinkat@plt>
  40f773:	cmp    rax,0x2a
  40f777:	jne    40f720 <__swc_fn_ff58629f_000107_ff529476+0x330>
  40f779:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40f77f:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40f785:	vptest xmm0,xmm0
  40f78a:	jne    40f7ba <__swc_fn_ff58629f_000107_ff529476+0x3ca>
  40f78c:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40f792:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40f798:	vptest xmm0,xmm0
  40f79d:	jne    40f7ba <__swc_fn_ff58629f_000107_ff529476+0x3ca>
  40f79f:	mov    rcx,QWORD PTR [rsp+0x42]
  40f7a4:	cmp    QWORD PTR [rsp+0x78],rcx
  40f7a9:	jne    40f7ba <__swc_fn_ff58629f_000107_ff529476+0x3ca>
  40f7ab:	mov    cx,WORD PTR [rsp+0x4a]
  40f7b0:	cmp    WORD PTR [rsp+0x80],cx
  40f7b8:	je     40f7e4 <__swc_fn_ff58629f_000107_ff529476+0x3f4>
  40f7ba:	mov    rax,rbx
  40f7bd:	mov    rcx,r12
  40f7c0:	movzx  edx,BYTE PTR [rax]
  40f7c3:	movzx  r8d,BYTE PTR [rcx]
  40f7c7:	cmp    rdx,r8
  40f7ca:	jne    40f7d6 <__swc_fn_ff58629f_000107_ff529476+0x3e6>
  40f7cc:	add    rax,0x1
  40f7d0:	add    rcx,0x1
  40f7d4:	jmp    40f7c0 <__swc_fn_ff58629f_000107_ff529476+0x3d0>
  40f7d6:	mov    rax,rdx
  40f7d9:	sub    rax,r8
  40f7dc:	test   eax,eax
  40f7de:	jne    40f720 <__swc_fn_ff58629f_000107_ff529476+0x330>
  40f7e4:	movsxd rdi,DWORD PTR [r14]
  40f7e7:	mov    rsi,r13
  40f7ea:	mov    edx,0x80002
  40f7ef:	xor    eax,eax
  40f7f1:	call   407180 <openat@plt>
  40f7f6:	lea    rbx,[rsp+0x98]
  40f7fe:	mov    DWORD PTR [rsp+0x98],eax
  40f805:	test   eax,eax
  40f807:	mov    r13,QWORD PTR [rsp+0xb0]
  40f80f:	jge    40f834 <__swc_fn_ff58629f_000107_ff529476+0x444>
  40f811:	mov    rdi,r15
  40f814:	xor    eax,eax
  40f816:	call   407190 <closedir@plt>
  40f81b:	mov    r13,QWORD PTR [rsp+0xb0]
  40f823:	movsxd rdi,r13d
  40f826:	xor    eax,eax
  40f828:	call   4070b0 <close@plt>
  40f82d:	xor    eax,eax
  40f82f:	jmp    40f9a6 <__swc_fn_ff58629f_000107_ff529476+0x5b6>
  40f834:	mov    rax,rbx
  40f837:	movsxd rdi,DWORD PTR [rax]
  40f83a:	xor    esi,esi
  40f83c:	mov    edx,0x2
  40f841:	xor    eax,eax
  40f843:	call   4070a0 <lseek@plt>
  40f848:	mov    r12,QWORD PTR [rsp+0xa8]
  40f850:	cmp    rax,r12
  40f853:	je     40f87a <__swc_fn_ff58629f_000107_ff529476+0x48a>
  40f855:	movsxd rdi,DWORD PTR [rbx]
  40f858:	xor    eax,eax
  40f85a:	call   4070b0 <close@plt>
  40f85f:	mov    rdi,r15
  40f862:	xor    eax,eax
  40f864:	call   407190 <closedir@plt>
  40f869:	movsxd rdi,r13d
  40f86c:	xor    eax,eax
  40f86e:	call   4070b0 <close@plt>
  40f873:	xor    eax,eax
  40f875:	jmp    40f9a6 <__swc_fn_ff58629f_000107_ff529476+0x5b6>
  40f87a:	xor    edi,edi
  40f87c:	mov    rsi,r12
  40f87f:	mov    edx,0x3
  40f884:	mov    ecx,0x1
  40f889:	mov    rax,rbx
  40f88c:	movsxd r8,DWORD PTR [rax]
  40f88f:	xor    r9d,r9d
  40f892:	xor    eax,eax
  40f894:	call   4070c0 <mmap@plt>
  40f899:	xor    r12d,r12d
  40f89c:	cmp    rax,0xffffffffffffffff
  40f8a0:	cmovne r12,rax
  40f8a4:	movsxd rdi,DWORD PTR [rbx]
  40f8a7:	xor    eax,eax
  40f8a9:	call   4070b0 <close@plt>
  40f8ae:	mov    rdi,r15
  40f8b1:	xor    eax,eax
  40f8b3:	call   407190 <closedir@plt>
  40f8b8:	movsxd rdi,r13d
  40f8bb:	xor    eax,eax
  40f8bd:	call   4070b0 <close@plt>
  40f8c2:	mov    rax,r12
  40f8c5:	jmp    40f9a6 <__swc_fn_ff58629f_000107_ff529476+0x5b6>
  40f8ca:	mov    r14,QWORD PTR [rsp+0xb8]
  40f8d2:	mov    rdi,r14
  40f8d5:	mov    esi,0x1
  40f8da:	xor    eax,eax
  40f8dc:	call   4071a0 <memfd_create@plt>
  40f8e1:	lea    rbx,[rsp+0x9c]
  40f8e9:	mov    DWORD PTR [rsp+0x9c],eax
  40f8f0:	test   eax,eax
  40f8f2:	jge    40f90f <__swc_fn_ff58629f_000107_ff529476+0x51f>
  40f8f4:	mov    rdi,r15
  40f8f7:	xor    eax,eax
  40f8f9:	call   407190 <closedir@plt>
  40f8fe:	movsxd rdi,r13d
  40f901:	xor    eax,eax
  40f903:	call   4070b0 <close@plt>
  40f908:	xor    eax,eax
  40f90a:	jmp    40f9a6 <__swc_fn_ff58629f_000107_ff529476+0x5b6>
  40f90f:	mov    rax,rbx
  40f912:	movsxd rdi,DWORD PTR [rax]
  40f915:	mov    rsi,r12
  40f918:	xor    eax,eax
  40f91a:	call   4071b0 <ftruncate@plt>
  40f91f:	test   eax,eax
  40f921:	je     40f945 <__swc_fn_ff58629f_000107_ff529476+0x555>
  40f923:	movsxd rdi,DWORD PTR [rbx]
  40f926:	xor    eax,eax
  40f928:	call   4070b0 <close@plt>
  40f92d:	mov    rdi,r15
  40f930:	xor    eax,eax
  40f932:	call   407190 <closedir@plt>
  40f937:	movsxd rdi,r13d
  40f93a:	xor    eax,eax
  40f93c:	call   4070b0 <close@plt>
  40f941:	xor    eax,eax
  40f943:	jmp    40f9a6 <__swc_fn_ff58629f_000107_ff529476+0x5b6>
  40f945:	xor    edi,edi
  40f947:	mov    rsi,r12
  40f94a:	mov    edx,0x3
  40f94f:	mov    ecx,0x1
  40f954:	mov    rax,rbx
  40f957:	movsxd r8,DWORD PTR [rax]
  40f95a:	xor    r9d,r9d
  40f95d:	xor    eax,eax
  40f95f:	call   4070c0 <mmap@plt>
  40f964:	mov    r12,rax
  40f967:	cmp    rax,0xffffffffffffffff
  40f96b:	jne    40f98f <__swc_fn_ff58629f_000107_ff529476+0x59f>
  40f96d:	movsxd rdi,DWORD PTR [rbx]
  40f970:	xor    eax,eax
  40f972:	call   4070b0 <close@plt>
  40f977:	mov    rdi,r15
  40f97a:	xor    eax,eax
  40f97c:	call   407190 <closedir@plt>
  40f981:	movsxd rdi,r13d
  40f984:	xor    eax,eax
  40f986:	call   4070b0 <close@plt>
  40f98b:	xor    eax,eax
  40f98d:	jmp    40f9a6 <__swc_fn_ff58629f_000107_ff529476+0x5b6>
  40f98f:	mov    rdi,r15
  40f992:	xor    eax,eax
  40f994:	call   407190 <closedir@plt>
  40f999:	movsxd rdi,r13d
  40f99c:	xor    eax,eax
  40f99e:	call   4070b0 <close@plt>
  40f9a3:	mov    rax,r12
  40f9a6:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40f9af:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40f9b8:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40f9c1:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40f9ca:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  40f9d3:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40f9dc:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  40f9e5:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40f9ee:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  40f9f7:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  40fa00:	add    rsp,0x170
  40fa07:	pop    r15
  40fa09:	pop    r14
  40fa0b:	pop    r13
  40fa0d:	pop    rsi
  40fa0e:	pop    rdi
  40fa0f:	pop    r12
  40fa11:	pop    rbx
  40fa12:	ret
	...

000000000040fa20 <__swc_fn_ff58629f_000110_e606239a>:
  40fa20:	push   rsi
  40fa21:	push   rdi
  40fa22:	push   r12
  40fa24:	push   r13
  40fa26:	sub    rsp,0x8
  40fa2a:	mov    rsi,r8
  40fa2d:	mov    rdi,rcx
  40fa30:	mov    r12,rdx
  40fa33:	call   409100 <__swc_fn_ff58629f_000108_32416b9e>
  40fa38:	mov    r13,rax
  40fa3b:	test   rax,rax
  40fa3e:	jne    40fa4b <__swc_fn_ff58629f_000110_e606239a+0x2b>
  40fa40:	add    rsp,0x8
  40fa44:	pop    r13
  40fa46:	pop    r12
  40fa48:	pop    rdi
  40fa49:	pop    rsi
  40fa4a:	ret
  40fa4b:	mov    rcx,r13
  40fa4e:	call   40cd70 <__swc_fn_ff58629f_000133_c6de0049>
  40fa53:	mov    rax,QWORD PTR [r13+0x8]
  40fa57:	test   rax,rax
  40fa5a:	je     40fa99 <__swc_fn_ff58629f_000110_e606239a+0x79>
  40fa5c:	nop    DWORD PTR [rax+0x0]
  40fa60:	lea    rcx,[rax+0x1000]
  40fa67:	cmp    rdi,rcx
  40fa6a:	jne    40fa91 <__swc_fn_ff58629f_000110_e606239a+0x71>
  40fa6c:	cmp    r12,0x1000
  40fa73:	jb     40fa91 <__swc_fn_ff58629f_000110_e606239a+0x71>
  40fa75:	test   sil,sil
  40fa78:	setne  cl
  40fa7b:	mov    BYTE PTR [rax+0x10],cl
  40fa7e:	mov    rcx,r13
  40fa81:	call   40ff80 <__swc_fn_ff58629f_000134_5696c87e>
  40fa86:	add    rsp,0x8
  40fa8a:	pop    r13
  40fa8c:	pop    r12
  40fa8e:	pop    rdi
  40fa8f:	pop    rsi
  40fa90:	ret
  40fa91:	mov    rax,QWORD PTR [rax]
  40fa94:	test   rax,rax
  40fa97:	jne    40fa60 <__swc_fn_ff58629f_000110_e606239a+0x40>
  40fa99:	mov    rcx,r13
  40fa9c:	call   40ff80 <__swc_fn_ff58629f_000134_5696c87e>
  40faa1:	add    rsp,0x8
  40faa5:	pop    r13
  40faa7:	pop    r12
  40faa9:	pop    rdi
  40faaa:	pop    rsi
  40faab:	ret
  40faac:	add    BYTE PTR [rax],al
	...

000000000040fab0 <__swc_fn_ff58629f_000113_25e345b1>:
  40fab0:	sub    rsp,0x8
  40fab4:	test   rcx,rcx
  40fab7:	jne    40fabe <__swc_fn_ff58629f_000113_25e345b1+0xe>
  40fab9:	add    rsp,0x8
  40fabd:	ret
  40fabe:	call   40c880 <__swc_fn_ff58629f_000115_259b5d5a>
  40fac3:	add    rsp,0x8
  40fac7:	ret
	...

000000000040fad0 <__swc_fn_ff58629f_000116_3499f7d6>:
  40fad0:	push   r12
  40fad2:	push   r13
  40fad4:	push   r14
  40fad6:	push   rdi
  40fad7:	push   rsi
  40fad8:	sub    rsp,0xc0
  40fadf:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40fae5:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40faeb:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40faf1:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40faf7:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40fafd:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40fb03:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40fb09:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40fb12:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40fb1b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40fb24:	mov    r12,QWORD PTR [rcx]
  40fb27:	test   r12,r12
  40fb2a:	jne    40fb3c <__swc_fn_ff58629f_000116_3499f7d6+0x6c>
  40fb2c:	add    rsp,0xc0
  40fb33:	pop    rsi
  40fb34:	pop    rdi
  40fb35:	pop    r14
  40fb37:	pop    r13
  40fb39:	pop    r12
  40fb3b:	ret
  40fb3c:	xor    r13d,r13d
  40fb3f:	mov    r14,QWORD PTR [rcx+0x8]
  40fb43:	cs nop WORD PTR [rax+rax*1+0x0]
  40fb4d:	nop    DWORD PTR [rax]
  40fb50:	cmp    r13,r14
  40fb53:	jae    40fb8b <__swc_fn_ff58629f_000116_3499f7d6+0xbb>
  40fb55:	lea    rax,[r12+r13*1]
  40fb59:	mov    rcx,r14
  40fb5c:	sub    rcx,r13
  40fb5f:	mov    edi,0x1
  40fb64:	mov    rsi,rax
  40fb67:	mov    rdx,rcx
  40fb6a:	xor    eax,eax
  40fb6c:	call   4071c0 <write@plt>
  40fb71:	test   rax,rax
  40fb74:	jle    40fb7b <__swc_fn_ff58629f_000116_3499f7d6+0xab>
  40fb76:	add    r13,rax
  40fb79:	jmp    40fb50 <__swc_fn_ff58629f_000116_3499f7d6+0x80>
  40fb7b:	je     40fb89 <__swc_fn_ff58629f_000116_3499f7d6+0xb9>
  40fb7d:	xor    eax,eax
  40fb7f:	call   407130 <__errno_location@plt>
  40fb84:	cmp    DWORD PTR [rax],0x4
  40fb87:	je     40fb50 <__swc_fn_ff58629f_000116_3499f7d6+0x80>
  40fb89:	jmp    40fb8b <__swc_fn_ff58629f_000116_3499f7d6+0xbb>
  40fb8b:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40fb91:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40fb97:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40fb9d:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40fba3:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40fba9:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40fbaf:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40fbb5:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40fbbe:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40fbc7:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40fbd0:	add    rsp,0xc0
  40fbd7:	pop    rsi
  40fbd8:	pop    rdi
  40fbd9:	pop    r14
  40fbdb:	pop    r13
  40fbdd:	pop    r12
  40fbdf:	ret

000000000040fbe0 <__swc_fn_ff58629f_000119_18cd3882>:
  40fbe0:	push   rbx
  40fbe1:	push   r12
  40fbe3:	push   rdi
  40fbe4:	push   rsi
  40fbe5:	sub    rsp,0x4a8
  40fbec:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  40fbf5:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  40fbfe:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  40fc07:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  40fc10:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  40fc19:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  40fc22:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  40fc2b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  40fc34:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  40fc3d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  40fc46:	mov    rbx,rdx
  40fc49:	mov    r12d,ecx
  40fc4c:	vxorps xmm0,xmm0,xmm0
  40fc50:	xor    eax,eax
  40fc52:	cs nop WORD PTR [rax+rax*1+0x0]
  40fc5c:	nop    DWORD PTR [rax+0x0]
  40fc60:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  40fc66:	add    rax,0x10
  40fc6a:	cmp    rax,0x400
  40fc71:	jne    40fc60 <__swc_fn_ff58629f_000119_18cd3882+0x80>
  40fc73:	lea    rdi,[rsp+0x8]
  40fc78:	mov    esi,0x80
  40fc7d:	xor    eax,eax
  40fc7f:	call   4071d0 <backtrace@plt>
  40fc84:	test   eax,eax
  40fc86:	jle    40fc95 <__swc_fn_ff58629f_000119_18cd3882+0xb5>
  40fc88:	movsxd rax,eax
  40fc8b:	lea    rcx,[r12+0x1]
  40fc90:	cmp    rcx,rax
  40fc93:	jb     40fc99 <__swc_fn_ff58629f_000119_18cd3882+0xb9>
  40fc95:	xor    eax,eax
  40fc97:	jmp    40fcca <__swc_fn_ff58629f_000119_18cd3882+0xea>
  40fc99:	mov    rcx,QWORD PTR [rbx+0x8]
  40fc9d:	sub    rax,r12
  40fca0:	lea    rsi,[rax-0x1]
  40fca4:	cmp    rcx,rsi
  40fca7:	cmovbe rsi,rcx
  40fcab:	lea    eax,[r12+0x1]
  40fcb0:	lea    rax,[rsp+rax*8+0x8]
  40fcb5:	mov    rcx,QWORD PTR [rbx]
  40fcb8:	mov    rdx,rax
  40fcbb:	lea    r8,[rsi*8+0x0]
  40fcc3:	call   4090e0 <__swc_fn_ff58629f_000105_b7aef7c0>
  40fcc8:	mov    eax,esi
  40fcca:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  40fcd3:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  40fcdc:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  40fce5:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  40fcee:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  40fcf7:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  40fd00:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  40fd09:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  40fd12:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  40fd1b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  40fd24:	add    rsp,0x4a8
  40fd2b:	pop    rsi
  40fd2c:	pop    rdi
  40fd2d:	pop    r12
  40fd2f:	pop    rbx
  40fd30:	ret
	...

000000000040fd40 <__swc_fn_ff58629f_000122_c37da69c>:
  40fd40:	mov    QWORD PTR [rcx],0x0
  40fd47:	ret
	...

000000000040fd50 <__swc_fn_ff58629f_000125_e19c72b3>:
  40fd50:	push   rdi
  40fd51:	push   rsi
  40fd52:	sub    rsp,0xa8
  40fd59:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40fd5f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40fd65:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40fd6b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40fd71:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40fd77:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40fd7d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40fd83:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40fd89:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40fd92:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40fd9b:	mov    edi,ecx
  40fd9d:	mov    rsi,rdx
  40fda0:	xor    eax,eax
  40fda2:	call   407060 <pthread_setspecific@plt>
  40fda7:	test   eax,eax
  40fda9:	sete   al
  40fdac:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40fdb2:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40fdb8:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40fdbe:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40fdc4:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40fdca:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40fdd0:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40fdd6:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40fddc:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40fde5:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40fdee:	add    rsp,0xa8
  40fdf5:	pop    rsi
  40fdf6:	pop    rdi
  40fdf7:	ret
	...

000000000040fe00 <__swc_fn_ff58629f_000128_9c45d2d7>:
  40fe00:	push   rdi
  40fe01:	push   rsi
  40fe02:	sub    rsp,0xa8
  40fe09:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40fe0f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40fe15:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40fe1b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40fe21:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40fe27:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40fe2d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40fe33:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40fe39:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40fe42:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40fe4b:	test   rcx,rcx
  40fe4e:	je     40fe61 <__swc_fn_ff58629f_000128_9c45d2d7+0x61>
  40fe50:	lea    rax,[rcx-0x1]
  40fe54:	mov    eax,eax
  40fe56:	mov    edi,eax
  40fe58:	xor    eax,eax
  40fe5a:	call   407000 <pthread_getspecific@plt>
  40fe5f:	jmp    40fe63 <__swc_fn_ff58629f_000128_9c45d2d7+0x63>
  40fe61:	xor    eax,eax
  40fe63:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40fe69:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40fe6f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40fe75:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40fe7b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40fe81:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40fe87:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40fe8d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40fe93:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40fe9c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40fea5:	add    rsp,0xa8
  40feac:	pop    rsi
  40fead:	pop    rdi
  40feae:	ret
	...

000000000040feb0 <__swc_fn_ff58629f_000131_dc04d759>:
  40feb0:	push   rdi
  40feb1:	push   rsi
  40feb2:	sub    rsp,0xb8
  40feb9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40febf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40fec5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40fecb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40fed1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40fed7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40fedd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40fee3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40feec:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40fef5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40fefe:	vxorps xmm0,xmm0,xmm0
  40ff02:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ff08:	mov    edi,0x1
  40ff0d:	lea    rsi,[rsp+0x8]
  40ff12:	xor    eax,eax
  40ff14:	call   4070e0 <clock_gettime@plt>
  40ff19:	mov    rax,QWORD PTR [rsp+0x8]
  40ff1e:	imul   rax,rax,0x3b9aca00
  40ff25:	add    rax,QWORD PTR [rsp+0x10]
  40ff2a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ff30:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40ff36:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40ff3c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ff42:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ff48:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ff4e:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ff54:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ff5d:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ff66:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ff6f:	add    rsp,0xb8
  40ff76:	pop    rsi
  40ff77:	pop    rdi
  40ff78:	ret
  40ff79:	add    BYTE PTR [rax],al
  40ff7b:	add    BYTE PTR [rax],al
  40ff7d:	add    BYTE PTR [rax],al
	...

000000000040ff80 <__swc_fn_ff58629f_000134_5696c87e>:
  40ff80:	sub    rsp,0x8
  40ff84:	xor    eax,eax
  40ff86:	mov    DWORD PTR [rcx],eax
  40ff88:	mov    edx,0x7fffffff
  40ff8d:	call   4097e0 <__swc_fn_ff58629f_000132_2b60f756>
  40ff92:	add    rsp,0x8
  40ff96:	ret
	...

000000000040ffa0 <__swc_fn_ff58629f_000137_899a611e>:
  40ffa0:	push   rdi
  40ffa1:	push   rsi
  40ffa2:	sub    rsp,0xb8
  40ffa9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40ffaf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40ffb5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40ffbb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40ffc1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40ffc7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40ffcd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40ffd3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40ffdc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40ffe5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40ffee:	mov    edi,0x1
  40fff3:	xor    eax,eax
  40fff5:	call   4071e0 <__x86_get_cpuid_feature_leaf@plt>
  40fffa:	mov    eax,DWORD PTR [rax+0x14]
  40fffd:	and    eax,0x20
  410000:	setne  al
  410003:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410009:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  41000f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410015:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41001b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410021:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  410027:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41002d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  410036:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  41003f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410048:	add    rsp,0xb8
  41004f:	pop    rsi
  410050:	pop    rdi
  410051:	ret
	...

0000000000410060 <__swc_fn_ff58629f_000140_81b740ca>:
  410060:	push   rsi
  410061:	push   rdi
  410062:	push   r12
  410064:	push   r13
  410066:	push   r14
  410068:	push   r15
  41006a:	cmp    rdx,0x40
  41006e:	jae    41007d <__swc_fn_ff58629f_000140_81b740ca+0x1d>
  410070:	xor    eax,eax
  410072:	pop    r15
  410074:	pop    r14
  410076:	pop    r13
  410078:	pop    r12
  41007a:	pop    rdi
  41007b:	pop    rsi
  41007c:	ret
  41007d:	cmp    BYTE PTR [rcx],0x7f
  410080:	jne    4100c4 <__swc_fn_ff58629f_000140_81b740ca+0x64>
  410082:	movzx  eax,BYTE PTR [rcx+0x1]
  410086:	cmp    eax,0x45
  410089:	setne  al
  41008c:	jne    4100c0 <__swc_fn_ff58629f_000140_81b740ca+0x60>
  41008e:	movzx  eax,BYTE PTR [rcx+0x2]
  410092:	cmp    eax,0x4c
  410095:	setne  al
  410098:	jne    4100c0 <__swc_fn_ff58629f_000140_81b740ca+0x60>
  41009a:	movzx  eax,BYTE PTR [rcx+0x3]
  41009e:	cmp    eax,0x46
  4100a1:	setne  al
  4100a4:	jne    4100c0 <__swc_fn_ff58629f_000140_81b740ca+0x60>
  4100a6:	cmp    BYTE PTR [rcx+0x4],0x2
  4100aa:	setne  al
  4100ad:	jne    4100c0 <__swc_fn_ff58629f_000140_81b740ca+0x60>
  4100af:	cmp    BYTE PTR [rcx+0x5],0x1
  4100b3:	setne  al
  4100b6:	jne    4100c0 <__swc_fn_ff58629f_000140_81b740ca+0x60>
  4100b8:	cmp    WORD PTR [rcx+0x12],0x3e
  4100bd:	setne  al
  4100c0:	test   al,al
  4100c2:	je     4100d1 <__swc_fn_ff58629f_000140_81b740ca+0x71>
  4100c4:	xor    eax,eax
  4100c6:	pop    r15
  4100c8:	pop    r14
  4100ca:	pop    r13
  4100cc:	pop    r12
  4100ce:	pop    rdi
  4100cf:	pop    rsi
  4100d0:	ret
  4100d1:	cmp    WORD PTR [rcx+0x3a],0x40
  4100d6:	jne    4100f1 <__swc_fn_ff58629f_000140_81b740ca+0x91>
  4100d8:	cmp    WORD PTR [rcx+0x3c],0x0
  4100dd:	sete   al
  4100e0:	je     4100ed <__swc_fn_ff58629f_000140_81b740ca+0x8d>
  4100e2:	mov    ax,WORD PTR [rcx+0x3c]
  4100e6:	cmp    WORD PTR [rcx+0x3e],ax
  4100ea:	setae  al
  4100ed:	test   al,al
  4100ef:	je     4100fe <__swc_fn_ff58629f_000140_81b740ca+0x9e>
  4100f1:	xor    eax,eax
  4100f3:	pop    r15
  4100f5:	pop    r14
  4100f7:	pop    r13
  4100f9:	pop    r12
  4100fb:	pop    rdi
  4100fc:	pop    rsi
  4100fd:	ret
  4100fe:	movzx  eax,WORD PTR [rcx+0x3c]
  410102:	shl    rax,0x6
  410106:	cmp    rax,rdx
  410109:	ja     410117 <__swc_fn_ff58629f_000140_81b740ca+0xb7>
  41010b:	mov    r9,rdx
  41010e:	sub    r9,rax
  410111:	cmp    QWORD PTR [rcx+0x28],r9
  410115:	jbe    410124 <__swc_fn_ff58629f_000140_81b740ca+0xc4>
  410117:	xor    eax,eax
  410119:	pop    r15
  41011b:	pop    r14
  41011d:	pop    r13
  41011f:	pop    r12
  410121:	pop    rdi
  410122:	pop    rsi
  410123:	ret
  410124:	mov    rax,QWORD PTR [rcx+0x28]
  410128:	add    rax,rcx
  41012b:	movzx  r9d,WORD PTR [rcx+0x3e]
  410130:	lea    r9,[r9*8+0x0]
  410138:	lea    r10,[rax+r9*8]
  41013c:	cmp    QWORD PTR [r10+0x20],rdx
  410140:	ja     410162 <__swc_fn_ff58629f_000140_81b740ca+0x102>
  410142:	mov    r11,rdx
  410145:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  41014a:	cmp    QWORD PTR [r10+0x18],r11
  41014e:	seta   r9b
  410152:	ja     41015d <__swc_fn_ff58629f_000140_81b740ca+0xfd>
  410154:	cmp    QWORD PTR [r10+0x20],0x9
  410159:	setb   r9b
  41015d:	test   r9b,r9b
  410160:	je     41016f <__swc_fn_ff58629f_000140_81b740ca+0x10f>
  410162:	xor    eax,eax
  410164:	pop    r15
  410166:	pop    r14
  410168:	pop    r13
  41016a:	pop    r12
  41016c:	pop    rdi
  41016d:	pop    rsi
  41016e:	ret
  41016f:	movzx  r9d,WORD PTR [rcx+0x3c]
  410174:	xor    r11d,r11d
  410177:	test   r9,r9
  41017a:	jbe    410275 <__swc_fn_ff58629f_000140_81b740ca+0x215>
  410180:	mov    rsi,QWORD PTR [r10+0x20]
  410184:	sub    rsi,0x9
  410188:	cs nop WORD PTR [rax+rax*1+0x0]
  410192:	cs nop WORD PTR [rax+rax*1+0x0]
  41019c:	nop    DWORD PTR [rax+0x0]
  4101a0:	movzx  edi,r11w
  4101a4:	lea    rdi,[rdi*8+0x0]
  4101ac:	lea    r12,[rax+rdi*8]
  4101b0:	rex mov edi,DWORD PTR [rax+rdi*8]
  4101b4:	cmp    rdi,rsi
  4101b7:	ja     410268 <__swc_fn_ff58629f_000140_81b740ca+0x208>
  4101bd:	mov    r13,QWORD PTR [r10+0x18]
  4101c1:	add    r13,rdi
  4101c4:	lea    rdi,[rcx+r13*1]
  4101c8:	lea    r13,[rip+0x2361]        # 412530 <__swc_rdata_base_ff58629f+0x420>
  4101cf:	movabs r14,0x676264676177732e
  4101d9:	cmp    QWORD PTR [rdi],r14
  4101dc:	jne    4101e5 <__swc_fn_ff58629f_000140_81b740ca+0x185>
  4101de:	rex cmp BYTE PTR [rdi+0x8],0x0
  4101e3:	je     410212 <__swc_fn_ff58629f_000140_81b740ca+0x1b2>
  4101e5:	cs nop WORD PTR [rax+rax*1+0x0]
  4101ef:	nop
  4101f0:	movzx  r14d,BYTE PTR [rdi]
  4101f4:	movzx  r15d,BYTE PTR [r13+0x0]
  4101f9:	cmp    r14,r15
  4101fc:	jne    410208 <__swc_fn_ff58629f_000140_81b740ca+0x1a8>
  4101fe:	add    rdi,0x1
  410202:	add    r13,0x1
  410206:	jmp    4101f0 <__swc_fn_ff58629f_000140_81b740ca+0x190>
  410208:	mov    rdi,r14
  41020b:	sub    rdi,r15
  41020e:	test   edi,edi
  410210:	jne    410268 <__swc_fn_ff58629f_000140_81b740ca+0x208>
  410212:	cmp    DWORD PTR [r12+0x4],0x1
  410218:	jne    410240 <__swc_fn_ff58629f_000140_81b740ca+0x1e0>
  41021a:	cmp    QWORD PTR [r12+0x20],0x10
  410220:	setb   al
  410223:	jb     41023c <__swc_fn_ff58629f_000140_81b740ca+0x1dc>
  410225:	cmp    QWORD PTR [r12+0x20],rdx
  41022a:	seta   al
  41022d:	ja     41023c <__swc_fn_ff58629f_000140_81b740ca+0x1dc>
  41022f:	sub    rdx,QWORD PTR [r12+0x20]
  410234:	cmp    QWORD PTR [r12+0x18],rdx
  410239:	seta   al
  41023c:	test   al,al
  41023e:	je     41024d <__swc_fn_ff58629f_000140_81b740ca+0x1ed>
  410240:	xor    eax,eax
  410242:	pop    r15
  410244:	pop    r14
  410246:	pop    r13
  410248:	pop    r12
  41024a:	pop    rdi
  41024b:	pop    rsi
  41024c:	ret
  41024d:	mov    rax,QWORD PTR [r12+0x20]
  410252:	mov    QWORD PTR [r8],rax
  410255:	mov    rax,QWORD PTR [r12+0x18]
  41025a:	add    rax,rcx
  41025d:	pop    r15
  41025f:	pop    r14
  410261:	pop    r13
  410263:	pop    r12
  410265:	pop    rdi
  410266:	pop    rsi
  410267:	ret
  410268:	add    r11,0x1
  41026c:	cmp    r11,r9
  41026f:	jb     4101a0 <__swc_fn_ff58629f_000140_81b740ca+0x140>
  410275:	xor    eax,eax
  410277:	pop    r15
  410279:	pop    r14
  41027b:	pop    r13
  41027d:	pop    r12
  41027f:	pop    rdi
  410280:	pop    rsi
  410281:	ret
	...

0000000000410290 <__swc_fn_ff58629f_000143_afffe963>:
  410290:	push   rdi
  410291:	push   rsi
  410292:	sub    rsp,0xa8
  410299:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41029f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4102a5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4102ab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4102b1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4102b7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4102bd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4102c3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4102c9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4102d2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4102db:	mov    rdi,rcx
  4102de:	xor    eax,eax
  4102e0:	call   4071f0 <free@plt>
  4102e5:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4102eb:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4102f1:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4102f7:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4102fd:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410303:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410309:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41030f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410315:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41031e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410327:	add    rsp,0xa8
  41032e:	pop    rsi
  41032f:	pop    rdi
  410330:	ret
	...

0000000000410340 <__swc_fn_ff58629f_000146_e9d46966>:
  410340:	push   rbx
  410341:	push   rsi
  410342:	push   rdi
  410343:	push   r12
  410345:	push   r13
  410347:	push   r15
  410349:	sub    rsp,0x4e8
  410350:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  410359:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  410362:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  41036b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  410374:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  41037d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  410386:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  41038f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  410398:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  4103a1:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  4103aa:	mov    rbx,QWORD PTR [rcx]
  4103ad:	mov    rcx,QWORD PTR [rcx+0x8]
  4103b1:	mov    rsi,rcx
  4103b4:	xor    edi,edi
  4103b6:	vmovsd xmm6,QWORD PTR [rip+0x21d2]        # 412590 <__swc_rdata_base_ff58629f+0x480>
  4103be:	vmovsd xmm7,QWORD PTR [rip+0x21d3]        # 412599 <__swc_rdata_base_ff58629f+0x489>
  4103c6:	vmovsd xmm8,QWORD PTR [rip+0x21d4]        # 4125a2 <__swc_rdata_base_ff58629f+0x492>
  4103ce:	vmovsd xmm9,QWORD PTR [rip+0x21d5]        # 4125ab <__swc_rdata_base_ff58629f+0x49b>
  4103d6:	vmovsd xmm10,QWORD PTR [rip+0x21d6]        # 4125b4 <__swc_rdata_base_ff58629f+0x4a4>
  4103de:	vmovups xmm11,xmm6
  4103e2:	vmovsd QWORD PTR [rsp+0x418],xmm7
  4103eb:	vmovsd QWORD PTR [rsp+0x420],xmm8
  4103f4:	vmovsd QWORD PTR [rsp+0x428],xmm9
  4103fd:	vmovsd QWORD PTR [rsp+0x430],xmm10
  410406:	vmovsd xmm15,QWORD PTR [rip+0x21af]        # 4125bd <__swc_rdata_base_ff58629f+0x4ad>
  41040e:	vmovups xmm14,xmm15
  410413:	vmovups xmm0,xmm9
  410418:	vmovsd QWORD PTR [rsp+0x438],xmm15
  410421:	vmovups xmm13,xmm8
  410426:	vmovsd QWORD PTR [rsp+0x440],xmm15
  41042f:	test   rsi,rsi
  410432:	je     411423 <__swc_fn_ff58629f_000146_e9d46966+0x10e3>
  410438:	cs nop WORD PTR [rax+rax*1+0x0]
  410442:	cs nop WORD PTR [rax+rax*1+0x0]
  41044c:	nop    DWORD PTR [rax+0x0]
  410450:	lea    rcx,[rdi+rdi*1]
  410454:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  410459:	vpshufd xmm3,xmm2,0xee
  41045e:	vmovq  rcx,xmm3
  410463:	test   rcx,rcx
  410466:	je     41047c <__swc_fn_ff58629f_000146_e9d46966+0x13c>
  410468:	test   DWORD PTR [rcx+0x28],0x400000
  41046f:	je     41047c <__swc_fn_ff58629f_000146_e9d46966+0x13c>
  410471:	mov    rdx,QWORD PTR [rcx+0x30]
  410475:	test   rdx,rdx
  410478:	cmovne rcx,rdx
  41047c:	test   DWORD PTR [rcx+0x28],0x1000
  410483:	je     4104a4 <__swc_fn_ff58629f_000146_e9d46966+0x164>
  410485:	mov    rdx,QWORD PTR [rcx+0x40]
  410489:	mov    rcx,rdx
  41048c:	vmovq  r8,xmm2
  410491:	mov    r8,QWORD PTR [r8]
  410494:	mov    QWORD PTR [rsp+0x60],r8
  410499:	mov    QWORD PTR [rsp+0x68],rdx
  41049e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  4104a4:	test   BYTE PTR [rcx+0x28],0x1
  4104a8:	jne    4104b0 <__swc_fn_ff58629f_000146_e9d46966+0x170>
  4104aa:	vmovups xmm12,xmm0
  4104ae:	jmp    4104ca <__swc_fn_ff58629f_000146_e9d46966+0x18a>
  4104b0:	vmovq  rax,xmm2
  4104b5:	mov    rax,QWORD PTR [rax]
  4104b8:	lea    rcx,[rax+0x10]
  4104bc:	vmovups xmm12,xmm0
  4104c0:	call   40fad0 <__swc_fn_ff58629f_000116_3499f7d6>
  4104c5:	jmp    411405 <__swc_fn_ff58629f_000146_e9d46966+0x10c5>
  4104ca:	test   DWORD PTR [rcx+0x28],0x400
  4104d1:	je     410532 <__swc_fn_ff58629f_000146_e9d46966+0x1f2>
  4104d3:	vmovq  rax,xmm2
  4104d8:	mov    rax,QWORD PTR [rax]
  4104db:	xor    ecx,ecx
  4104dd:	test   rax,rax
  4104e0:	je     410510 <__swc_fn_ff58629f_000146_e9d46966+0x1d0>
  4104e2:	mov    rdx,rax
  4104e5:	mov    r8b,BYTE PTR [rdx]
  4104e8:	test   r8b,r8b
  4104eb:	je     410510 <__swc_fn_ff58629f_000146_e9d46966+0x1d0>
  4104ed:	cs nop WORD PTR [rax+rax*1+0x0]
  4104f7:	nop    WORD PTR [rax+rax*1+0x0]
  410500:	add    rdx,0x1
  410504:	add    rcx,0x1
  410508:	mov    r8b,BYTE PTR [rdx]
  41050b:	test   r8b,r8b
  41050e:	jne    410500 <__swc_fn_ff58629f_000146_e9d46966+0x1c0>
  410510:	mov    QWORD PTR [rsp+0x88],rax
  410518:	mov    QWORD PTR [rsp+0x90],rcx
  410520:	lea    rcx,[rsp+0x88]
  410528:	call   40fad0 <__swc_fn_ff58629f_000116_3499f7d6>
  41052d:	jmp    411405 <__swc_fn_ff58629f_000146_e9d46966+0x10c5>
  410532:	cmp    BYTE PTR [rcx+0x2c],0x6
  410536:	jne    41054d <__swc_fn_ff58629f_000146_e9d46966+0x20d>
  410538:	vmovq  rax,xmm2
  41053d:	mov    rax,QWORD PTR [rax]
  410540:	mov    rcx,rax
  410543:	call   409cb0 <__swc_fn_ff58629f_000144_364559f5>
  410548:	jmp    411405 <__swc_fn_ff58629f_000146_e9d46966+0x10c5>
  41054d:	cmp    BYTE PTR [rcx+0x2c],0x1
  410551:	jne    4113f9 <__swc_fn_ff58629f_000146_e9d46966+0x10b9>
  410557:	vmovq  rdx,xmm2
  41055c:	mov    cl,BYTE PTR [rcx+0x40]
  41055f:	cmp    cl,0x7
  410562:	jb     4105a5 <__swc_fn_ff58629f_000146_e9d46966+0x265>
  410564:	je     410618 <__swc_fn_ff58629f_000146_e9d46966+0x2d8>
  41056a:	cmp    cl,0x8
  41056d:	je     410624 <__swc_fn_ff58629f_000146_e9d46966+0x2e4>
  410573:	cmp    cl,0x9
  410576:	je     41063d <__swc_fn_ff58629f_000146_e9d46966+0x2fd>
  41057c:	cmp    cl,0xa
  41057f:	je     410d04 <__swc_fn_ff58629f_000146_e9d46966+0x9c4>
  410585:	cmp    cl,0xb
  410588:	je     4113cb <__swc_fn_ff58629f_000146_e9d46966+0x108b>
  41058e:	cmp    cl,0xc
  410591:	je     410631 <__swc_fn_ff58629f_000146_e9d46966+0x2f1>
  410597:	cmp    cl,0xd
  41059a:	je     4113c1 <__swc_fn_ff58629f_000146_e9d46966+0x1081>
  4105a0:	jmp    4113eb <__swc_fn_ff58629f_000146_e9d46966+0x10ab>
  4105a5:	cmp    cl,0x1
  4105a8:	je     4105c8 <__swc_fn_ff58629f_000146_e9d46966+0x288>
  4105aa:	cmp    cl,0x2
  4105ad:	je     4105d6 <__swc_fn_ff58629f_000146_e9d46966+0x296>
  4105af:	cmp    cl,0x3
  4105b2:	je     4105e4 <__swc_fn_ff58629f_000146_e9d46966+0x2a4>
  4105b4:	cmp    cl,0x4
  4105b7:	je     4105f1 <__swc_fn_ff58629f_000146_e9d46966+0x2b1>
  4105b9:	cmp    cl,0x5
  4105bc:	je     4105fe <__swc_fn_ff58629f_000146_e9d46966+0x2be>
  4105be:	cmp    cl,0x6
  4105c1:	je     41060b <__swc_fn_ff58629f_000146_e9d46966+0x2cb>
  4105c3:	jmp    4113eb <__swc_fn_ff58629f_000146_e9d46966+0x10ab>
  4105c8:	movsx  rcx,BYTE PTR [rdx]
  4105cc:	call   40cf60 <__swc_fn_ff58629f_000145_071b4f4c>
  4105d1:	jmp    411405 <__swc_fn_ff58629f_000146_e9d46966+0x10c5>
  4105d6:	movsx  rcx,WORD PTR [rdx]
  4105da:	call   40cf60 <__swc_fn_ff58629f_000145_071b4f4c>
  4105df:	jmp    411405 <__swc_fn_ff58629f_000146_e9d46966+0x10c5>
  4105e4:	movsxd rcx,DWORD PTR [rdx]
  4105e7:	call   40cf60 <__swc_fn_ff58629f_000145_071b4f4c>
  4105ec:	jmp    411405 <__swc_fn_ff58629f_000146_e9d46966+0x10c5>
  4105f1:	mov    rcx,QWORD PTR [rdx]
  4105f4:	call   40cf60 <__swc_fn_ff58629f_000145_071b4f4c>
  4105f9:	jmp    411405 <__swc_fn_ff58629f_000146_e9d46966+0x10c5>
  4105fe:	movzx  ecx,BYTE PTR [rdx]
  410601:	call   409cb0 <__swc_fn_ff58629f_000144_364559f5>
  410606:	jmp    411405 <__swc_fn_ff58629f_000146_e9d46966+0x10c5>
  41060b:	movzx  ecx,WORD PTR [rdx]
  41060e:	call   409cb0 <__swc_fn_ff58629f_000144_364559f5>
  410613:	jmp    411405 <__swc_fn_ff58629f_000146_e9d46966+0x10c5>
  410618:	mov    ecx,DWORD PTR [rdx]
  41061a:	call   409cb0 <__swc_fn_ff58629f_000144_364559f5>
  41061f:	jmp    411405 <__swc_fn_ff58629f_000146_e9d46966+0x10c5>
  410624:	mov    rcx,QWORD PTR [rdx]
  410627:	call   409cb0 <__swc_fn_ff58629f_000144_364559f5>
  41062c:	jmp    411405 <__swc_fn_ff58629f_000146_e9d46966+0x10c5>
  410631:	mov    ecx,DWORD PTR [rdx]
  410633:	call   409cb0 <__swc_fn_ff58629f_000144_364559f5>
  410638:	jmp    411405 <__swc_fn_ff58629f_000146_e9d46966+0x10c5>
  41063d:	lea    rcx,[rsp+0xa8]
  410645:	vxorps xmm0,xmm0,xmm0
  410649:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  410652:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  41065b:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  410664:	vzeroupper
  410667:	mov    DWORD PTR [rsp+0x108],0x0
  410672:	vxorpd xmm0,xmm0,xmm0
  410676:	vmovss xmm1,DWORD PTR [rdx]
  41067a:	vcvtss2sd xmm0,xmm0,xmm1
  41067e:	vmovsd xmm1,xmm1,xmm0
  410682:	vcomisd xmm0,xmm0
  410686:	setne  dl
  410689:	movzx  edx,dl
  41068c:	setp   r8b
  410690:	movzx  r8d,r8b
  410694:	or     edx,r8d
  410697:	test   dl,dl
  410699:	je     4106a6 <__swc_fn_ff58629f_000146_e9d46966+0x366>
  41069b:	mov    DWORD PTR [rcx],0x6e616e
  4106a1:	jmp    410c98 <__swc_fn_ff58629f_000146_e9d46966+0x958>
  4106a6:	vcomisd xmm1,xmm6
  4106aa:	ja     4106b2 <__swc_fn_ff58629f_000146_e9d46966+0x372>
  4106ac:	vcomisd xmm7,xmm1
  4106b0:	jbe    4106d6 <__swc_fn_ff58629f_000146_e9d46966+0x396>
  4106b2:	vxorpd xmm0,xmm0,xmm0
  4106b6:	vcomisd xmm0,xmm1
  4106ba:	jbe    4106cb <__swc_fn_ff58629f_000146_e9d46966+0x38b>
  4106bc:	mov    DWORD PTR [rcx],0x666e692d
  4106c2:	mov    BYTE PTR [rcx+0x4],0x0
  4106c6:	jmp    410c98 <__swc_fn_ff58629f_000146_e9d46966+0x958>
  4106cb:	mov    DWORD PTR [rcx],0x666e69
  4106d1:	jmp    410c98 <__swc_fn_ff58629f_000146_e9d46966+0x958>
  4106d6:	vcomisd xmm1,xmm8
  4106db:	jae    4106e7 <__swc_fn_ff58629f_000146_e9d46966+0x3a7>
  4106dd:	vcomisd xmm9,xmm1
  4106e1:	jbe    410a5e <__swc_fn_ff58629f_000146_e9d46966+0x71e>
  4106e7:	vmovups xmm0,xmm1
  4106eb:	vxorpd xmm2,xmm2,xmm2
  4106ef:	vcomisd xmm2,xmm1
  4106f3:	jbe    410703 <__swc_fn_ff58629f_000146_e9d46966+0x3c3>
  4106f5:	vmovsd xmm1,xmm1,xmm0
  4106f9:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1e4f]        # 412550 <__swc_rdata_base_ff58629f+0x440>
  410701:	jmp    410707 <__swc_fn_ff58629f_000146_e9d46966+0x3c7>
  410703:	vmovsd xmm1,xmm1,xmm0
  410707:	xor    r8d,r8d
  41070a:	vcomisd xmm1,xmm15
  41070f:	jb     410730 <__swc_fn_ff58629f_000146_e9d46966+0x3f0>
  410711:	cs nop WORD PTR [rax+rax*1+0x0]
  41071b:	nop    DWORD PTR [rax+rax*1+0x0]
  410720:	vdivsd xmm1,xmm1,xmm15
  410725:	add    r8,0x1
  410729:	vcomisd xmm1,xmm15
  41072e:	jae    410720 <__swc_fn_ff58629f_000146_e9d46966+0x3e0>
  410730:	mov    r9,rcx
  410733:	vxorpd xmm2,xmm2,xmm2
  410737:	vcomisd xmm2,xmm0
  41073b:	jbe    410744 <__swc_fn_ff58629f_000146_e9d46966+0x404>
  41073d:	mov    BYTE PTR [rcx],0x2d
  410740:	lea    r9,[rcx+0x1]
  410744:	vcvttsd2si rdx,xmm1
  410749:	mov    r10b,dl
  41074c:	add    r10b,0x30
  410750:	mov    BYTE PTR [r9],r10b
  410753:	vxorpd xmm0,xmm0,xmm0
  410757:	movzx  edx,dl
  41075a:	vcvtsi2sd xmm0,xmm0,rdx
  41075f:	vsubsd xmm0,xmm1,xmm0
  410763:	vmulsd xmm1,xmm0,xmm15
  410768:	mov    BYTE PTR [r9+0x1],0x2e
  41076d:	vcvttsd2si rdx,xmm1
  410772:	mov    r10b,dl
  410775:	add    r10b,0x30
  410779:	mov    BYTE PTR [r9+0x2],r10b
  41077d:	vxorpd xmm0,xmm0,xmm0
  410781:	movzx  edx,dl
  410784:	vcvtsi2sd xmm0,xmm0,rdx
  410789:	vsubsd xmm0,xmm1,xmm0
  41078d:	vmulsd xmm1,xmm0,xmm15
  410792:	vcvttsd2si rdx,xmm1
  410797:	mov    r10b,dl
  41079a:	add    r10b,0x30
  41079e:	mov    BYTE PTR [r9+0x3],r10b
  4107a2:	vxorpd xmm0,xmm0,xmm0
  4107a6:	movzx  edx,dl
  4107a9:	vcvtsi2sd xmm0,xmm0,rdx
  4107ae:	vsubsd xmm0,xmm1,xmm0
  4107b2:	vmulsd xmm1,xmm0,xmm15
  4107b7:	vcvttsd2si rdx,xmm1
  4107bc:	mov    r10b,dl
  4107bf:	add    r10b,0x30
  4107c3:	mov    BYTE PTR [r9+0x4],r10b
  4107c7:	vxorpd xmm0,xmm0,xmm0
  4107cb:	movzx  edx,dl
  4107ce:	vcvtsi2sd xmm0,xmm0,rdx
  4107d3:	vsubsd xmm0,xmm1,xmm0
  4107d7:	vmulsd xmm1,xmm0,xmm15
  4107dc:	vcvttsd2si rdx,xmm1
  4107e1:	mov    r10b,dl
  4107e4:	add    r10b,0x30
  4107e8:	mov    BYTE PTR [r9+0x5],r10b
  4107ec:	vxorpd xmm0,xmm0,xmm0
  4107f0:	movzx  edx,dl
  4107f3:	vcvtsi2sd xmm0,xmm0,rdx
  4107f8:	vsubsd xmm0,xmm1,xmm0
  4107fc:	vmulsd xmm1,xmm0,xmm15
  410801:	vcvttsd2si rdx,xmm1
  410806:	mov    r10b,dl
  410809:	add    r10b,0x30
  41080d:	mov    BYTE PTR [r9+0x6],r10b
  410811:	vxorpd xmm0,xmm0,xmm0
  410815:	movzx  edx,dl
  410818:	vcvtsi2sd xmm0,xmm0,rdx
  41081d:	vsubsd xmm0,xmm1,xmm0
  410821:	vmulsd xmm1,xmm0,xmm15
  410826:	vcvttsd2si rdx,xmm1
  41082b:	mov    r10b,dl
  41082e:	add    r10b,0x30
  410832:	mov    BYTE PTR [r9+0x7],r10b
  410836:	vxorpd xmm0,xmm0,xmm0
  41083a:	movzx  edx,dl
  41083d:	vcvtsi2sd xmm0,xmm0,rdx
  410842:	vsubsd xmm0,xmm1,xmm0
  410846:	vmulsd xmm1,xmm0,xmm15
  41084b:	vcvttsd2si rdx,xmm1
  410850:	mov    r10b,dl
  410853:	add    r10b,0x30
  410857:	mov    BYTE PTR [r9+0x8],r10b
  41085b:	vxorpd xmm0,xmm0,xmm0
  41085f:	movzx  edx,dl
  410862:	vcvtsi2sd xmm0,xmm0,rdx
  410867:	vsubsd xmm0,xmm1,xmm0
  41086b:	vmulsd xmm1,xmm0,xmm15
  410870:	vcvttsd2si rdx,xmm1
  410875:	mov    r10b,dl
  410878:	add    r10b,0x30
  41087c:	mov    BYTE PTR [r9+0x9],r10b
  410880:	vxorpd xmm0,xmm0,xmm0
  410884:	movzx  edx,dl
  410887:	vcvtsi2sd xmm0,xmm0,rdx
  41088c:	vsubsd xmm0,xmm1,xmm0
  410890:	vmulsd xmm1,xmm0,xmm15
  410895:	vcvttsd2si rdx,xmm1
  41089a:	mov    r10b,dl
  41089d:	add    r10b,0x30
  4108a1:	mov    BYTE PTR [r9+0xa],r10b
  4108a5:	vxorpd xmm0,xmm0,xmm0
  4108a9:	movzx  edx,dl
  4108ac:	vcvtsi2sd xmm0,xmm0,rdx
  4108b1:	vsubsd xmm0,xmm1,xmm0
  4108b5:	vmulsd xmm1,xmm0,xmm15
  4108ba:	vcvttsd2si rdx,xmm1
  4108bf:	mov    r10b,dl
  4108c2:	add    r10b,0x30
  4108c6:	mov    BYTE PTR [r9+0xb],r10b
  4108ca:	lea    r10,[r9+0x4]
  4108ce:	vxorpd xmm0,xmm0,xmm0
  4108d2:	movzx  edx,dl
  4108d5:	vcvtsi2sd xmm0,xmm0,rdx
  4108da:	vsubsd xmm0,xmm1,xmm0
  4108de:	vmulsd xmm1,xmm0,xmm15
  4108e3:	vcvttsd2si rdx,xmm1
  4108e8:	mov    r11b,dl
  4108eb:	add    r11b,0x30
  4108ef:	mov    BYTE PTR [r9+0xc],r11b
  4108f3:	vxorpd xmm0,xmm0,xmm0
  4108f7:	movzx  edx,dl
  4108fa:	vcvtsi2sd xmm0,xmm0,rdx
  4108ff:	vsubsd xmm0,xmm1,xmm0
  410903:	vmulsd xmm1,xmm0,xmm15
  410908:	vcvttsd2si rdx,xmm1
  41090d:	mov    r11b,dl
  410910:	add    r11b,0x30
  410914:	mov    BYTE PTR [r9+0xd],r11b
  410918:	lea    r10,[r10+0x2]
  41091c:	vxorpd xmm0,xmm0,xmm0
  410920:	movzx  edx,dl
  410923:	vcvtsi2sd xmm0,xmm0,rdx
  410928:	vsubsd xmm0,xmm1,xmm0
  41092c:	vmulsd xmm1,xmm0,xmm15
  410931:	vcvttsd2si rdx,xmm1
  410936:	mov    r11b,dl
  410939:	add    r11b,0x30
  41093d:	mov    BYTE PTR [r9+0xe],r11b
  410941:	vxorpd xmm0,xmm0,xmm0
  410945:	movzx  edx,dl
  410948:	vcvtsi2sd xmm0,xmm0,rdx
  41094d:	vsubsd xmm0,xmm1,xmm0
  410951:	vmulsd xmm1,xmm0,xmm15
  410956:	vcvttsd2si rdx,xmm1
  41095b:	mov    r11b,dl
  41095e:	add    r11b,0x30
  410962:	mov    BYTE PTR [r9+0xf],r11b
  410966:	lea    r10,[r10+0x2]
  41096a:	lea    r10,[r10+0x2]
  41096e:	lea    r10,[r10+0x2]
  410972:	lea    r10,[r10+0x2]
  410976:	lea    r10,[r10+0x2]
  41097a:	vxorpd xmm0,xmm0,xmm0
  41097e:	movzx  edx,dl
  410981:	vcvtsi2sd xmm0,xmm0,rdx
  410986:	vsubsd xmm0,xmm1,xmm0
  41098a:	vmulsd xmm1,xmm0,xmm15
  41098f:	vcvttsd2si rdx,xmm1
  410994:	mov    r11b,dl
  410997:	add    r11b,0x30
  41099b:	mov    BYTE PTR [r9+0x10],r11b
  41099f:	vxorpd xmm0,xmm0,xmm0
  4109a3:	movzx  edx,dl
  4109a6:	vcvtsi2sd xmm0,xmm0,rdx
  4109ab:	vsubsd xmm0,xmm1,xmm0
  4109af:	vmulsd xmm1,xmm0,xmm15
  4109b4:	vcvttsd2si rdx,xmm1
  4109b9:	add    dl,0x30
  4109bc:	mov    BYTE PTR [r9+0x11],dl
  4109c0:	mov    BYTE PTR [r10+0x2],0x65
  4109c5:	lea    r9,[r10+0x3]
  4109c9:	test   r8,r8
  4109cc:	jl     4109d5 <__swc_fn_ff58629f_000146_e9d46966+0x695>
  4109ce:	mov    BYTE PTR [r9],0x2b
  4109d2:	inc    r9
  4109d5:	mov    r10,r9
  4109d8:	mov    rdx,r8
  4109db:	nop    DWORD PTR [rax+rax*1+0x0]
  4109e0:	mov    r11,rdx
  4109e3:	movabs rdx,0x6666666666666667
  4109ed:	mov    rax,r11
  4109f0:	imul   rdx
  4109f3:	sar    rdx,0x2
  4109f7:	mov    r12,rdx
  4109fa:	shr    rdx,0x3f
  4109fe:	add    r12,rdx
  410a01:	mov    rdx,r12
  410a04:	imul   r13,r12,0xa
  410a08:	sub    r11,r13
  410a0b:	mov    r13,QWORD PTR [rip+0x1b2e]        # 412540 <__swc_rdata_base_ff58629f+0x430>
  410a12:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410a17:	mov    BYTE PTR [r10],r11b
  410a1a:	lea    r11,[r10+0x1]
  410a1e:	mov    r10,r11
  410a21:	test   r12,r12
  410a24:	jne    4109e0 <__swc_fn_ff58629f_000146_e9d46966+0x6a0>
  410a26:	test   r8,r8
  410a29:	jge    410a33 <__swc_fn_ff58629f_000146_e9d46966+0x6f3>
  410a2b:	mov    BYTE PTR [r11],0x2d
  410a2f:	lea    r10,[r11+0x1]
  410a33:	mov    BYTE PTR [r10],0x0
  410a37:	sub    r10,0x1
  410a3b:	nop    DWORD PTR [rax+rax*1+0x0]
  410a40:	cmp    r9,r10
  410a43:	jae    410c98 <__swc_fn_ff58629f_000146_e9d46966+0x958>
  410a49:	mov    al,BYTE PTR [r10]
  410a4c:	mov    dl,BYTE PTR [r9]
  410a4f:	mov    BYTE PTR [r10],dl
  410a52:	sub    r10,0x1
  410a56:	mov    BYTE PTR [r9],al
  410a59:	inc    r9
  410a5c:	jmp    410a40 <__swc_fn_ff58629f_000146_e9d46966+0x700>
  410a5e:	vcvttsd2si rdx,xmm1
  410a63:	mov    r8,rdx
  410a66:	vxorpd xmm0,xmm0,xmm0
  410a6a:	vcvtsi2sd xmm0,xmm0,rdx
  410a6f:	vsubsd xmm0,xmm1,xmm0
  410a73:	mov    r9d,0x8
  410a79:	vxorpd xmm2,xmm2,xmm2
  410a7d:	vcomisd xmm2,xmm0
  410a81:	jbe    410a8b <__swc_fn_ff58629f_000146_e9d46966+0x74b>
  410a83:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x1ac5]        # 412550 <__swc_rdata_base_ff58629f+0x440>
  410a8b:	test   r9d,r9d
  410a8e:	je     410a9a <__swc_fn_ff58629f_000146_e9d46966+0x75a>
  410a90:	vmulsd xmm0,xmm0,xmm14
  410a95:	dec    r9d
  410a98:	jne    410a90 <__swc_fn_ff58629f_000146_e9d46966+0x750>
  410a9a:	vcvttsd2si r9,xmm0
  410a9f:	mov    r10,r9
  410aa2:	vxorpd xmm2,xmm2,xmm2
  410aa6:	vcvtsi2sd xmm2,xmm2,r9
  410aab:	vsubsd xmm0,xmm0,xmm2
  410aaf:	vcomisd xmm0,xmm10
  410ab4:	lea    r9,[r9+0x1]
  410ab8:	cmova  r10,r9
  410abc:	cmp    r10,0x5f5e100
  410ac3:	jne    410adc <__swc_fn_ff58629f_000146_e9d46966+0x79c>
  410ac5:	lea    r8,[rdx-0x1]
  410ac9:	vxorpd xmm0,xmm0,xmm0
  410acd:	vcomisd xmm0,xmm1
  410ad1:	lea    rdx,[rdx+0x1]
  410ad5:	cmovbe r8,rdx
  410ad9:	xor    r10d,r10d
  410adc:	mov    r9,rcx
  410adf:	test   r8,r8
  410ae2:	jne    410b02 <__swc_fn_ff58629f_000146_e9d46966+0x7c2>
  410ae4:	vxorpd xmm0,xmm0,xmm0
  410ae8:	vcomisd xmm0,xmm1
  410aec:	jbe    410af5 <__swc_fn_ff58629f_000146_e9d46966+0x7b5>
  410aee:	mov    BYTE PTR [rcx],0x2d
  410af1:	lea    r9,[rcx+0x1]
  410af5:	mov    BYTE PTR [r9],0x30
  410af9:	add    r9,0x1
  410afd:	jmp    410b9b <__swc_fn_ff58629f_000146_e9d46966+0x85b>
  410b02:	mov    r9,rcx
  410b05:	mov    rdx,r8
  410b08:	nop    DWORD PTR [rax+rax*1+0x0]
  410b10:	mov    r11,rdx
  410b13:	movabs rdx,0x6666666666666667
  410b1d:	mov    r15,rax
  410b20:	mov    rax,r11
  410b23:	imul   rdx
  410b26:	mov    r12,rdx
  410b29:	mov    rax,r15
  410b2c:	sar    r12,0x2
  410b30:	mov    rdx,r12
  410b33:	shr    rdx,0x3f
  410b37:	add    r12,rdx
  410b3a:	mov    rdx,r12
  410b3d:	imul   r13,r12,0xa
  410b41:	sub    r11,r13
  410b44:	mov    r13,QWORD PTR [rip+0x19f5]        # 412540 <__swc_rdata_base_ff58629f+0x430>
  410b4b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410b50:	mov    BYTE PTR [r9],r11b
  410b53:	lea    r11,[r9+0x1]
  410b57:	mov    r9,r11
  410b5a:	test   r12,r12
  410b5d:	jne    410b10 <__swc_fn_ff58629f_000146_e9d46966+0x7d0>
  410b5f:	test   r8,r8
  410b62:	jge    410b6c <__swc_fn_ff58629f_000146_e9d46966+0x82c>
  410b64:	mov    BYTE PTR [r11],0x2d
  410b68:	lea    r9,[r11+0x1]
  410b6c:	mov    rdx,r9
  410b6f:	mov    BYTE PTR [r9],0x0
  410b73:	sub    r9,0x1
  410b77:	mov    r8,rcx
  410b7a:	cmp    r8,r9
  410b7d:	jae    410b98 <__swc_fn_ff58629f_000146_e9d46966+0x858>
  410b7f:	nop
  410b80:	mov    r11b,BYTE PTR [r9]
  410b83:	mov    r12b,BYTE PTR [r8]
  410b86:	mov    BYTE PTR [r9],r12b
  410b89:	sub    r9,0x1
  410b8d:	mov    BYTE PTR [r8],r11b
  410b90:	inc    r8
  410b93:	cmp    r8,r9
  410b96:	jb     410b80 <__swc_fn_ff58629f_000146_e9d46966+0x840>
  410b98:	mov    r9,rdx
  410b9b:	mov    BYTE PTR [r9],0x2e
  410b9f:	add    r9,0x1
  410ba3:	xor    r8d,r8d
  410ba6:	test   r10,r10
  410ba9:	je     410bef <__swc_fn_ff58629f_000146_e9d46966+0x8af>
  410bab:	mov    r11d,0x989680
  410bb1:	cmp    r10,r11
  410bb4:	jge    410bef <__swc_fn_ff58629f_000146_e9d46966+0x8af>
  410bb6:	cs nop WORD PTR [rax+rax*1+0x0]
  410bc0:	inc    r8d
  410bc3:	movabs rdx,0x6666666666666667
  410bcd:	mov    r15,rax
  410bd0:	mov    rax,r11
  410bd3:	imul   rdx
  410bd6:	mov    r11,rdx
  410bd9:	mov    rax,r15
  410bdc:	sar    r11,0x2
  410be0:	mov    rdx,r11
  410be3:	shr    rdx,0x3f
  410be7:	add    r11,rdx
  410bea:	cmp    r10,r11
  410bed:	jl     410bc0 <__swc_fn_ff58629f_000146_e9d46966+0x880>
  410bef:	test   r8d,r8d
  410bf2:	je     410c0d <__swc_fn_ff58629f_000146_e9d46966+0x8cd>
  410bf4:	cs nop WORD PTR [rax+rax*1+0x0]
  410bfe:	xchg   ax,ax
  410c00:	mov    BYTE PTR [r9],0x30
  410c04:	add    r9,0x1
  410c08:	dec    r8d
  410c0b:	jne    410c00 <__swc_fn_ff58629f_000146_e9d46966+0x8c0>
  410c0d:	mov    r8,r9
  410c10:	mov    rdx,r10
  410c13:	cs nop WORD PTR [rax+rax*1+0x0]
  410c1d:	nop    DWORD PTR [rax]
  410c20:	mov    r11,rdx
  410c23:	movabs rdx,0x6666666666666667
  410c2d:	mov    rax,r11
  410c30:	imul   rdx
  410c33:	sar    rdx,0x2
  410c37:	mov    r12,rdx
  410c3a:	shr    rdx,0x3f
  410c3e:	add    r12,rdx
  410c41:	mov    rdx,r12
  410c44:	imul   r13,r12,0xa
  410c48:	sub    r11,r13
  410c4b:	mov    r13,QWORD PTR [rip+0x18ee]        # 412540 <__swc_rdata_base_ff58629f+0x430>
  410c52:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410c57:	mov    BYTE PTR [r8],r11b
  410c5a:	lea    r11,[r8+0x1]
  410c5e:	mov    r8,r11
  410c61:	test   r12,r12
  410c64:	jne    410c20 <__swc_fn_ff58629f_000146_e9d46966+0x8e0>
  410c66:	test   r10,r10
  410c69:	jge    410c73 <__swc_fn_ff58629f_000146_e9d46966+0x933>
  410c6b:	mov    BYTE PTR [r11],0x2d
  410c6f:	lea    r8,[r11+0x1]
  410c73:	mov    BYTE PTR [r8],0x0
  410c77:	sub    r8,0x1
  410c7b:	cmp    r9,r8
  410c7e:	jae    410c98 <__swc_fn_ff58629f_000146_e9d46966+0x958>
  410c80:	mov    al,BYTE PTR [r8]
  410c83:	mov    dl,BYTE PTR [r9]
  410c86:	mov    BYTE PTR [r8],dl
  410c89:	sub    r8,0x1
  410c8d:	mov    BYTE PTR [r9],al
  410c90:	inc    r9
  410c93:	cmp    r9,r8
  410c96:	jb     410c80 <__swc_fn_ff58629f_000146_e9d46966+0x940>
  410c98:	xor    eax,eax
  410c9a:	test   rcx,rcx
  410c9d:	je     410cd0 <__swc_fn_ff58629f_000146_e9d46966+0x990>
  410c9f:	mov    rdx,rcx
  410ca2:	mov    r8b,BYTE PTR [rdx]
  410ca5:	test   r8b,r8b
  410ca8:	je     410cd0 <__swc_fn_ff58629f_000146_e9d46966+0x990>
  410caa:	cs nop WORD PTR [rax+rax*1+0x0]
  410cb4:	cs nop WORD PTR [rax+rax*1+0x0]
  410cbe:	xchg   ax,ax
  410cc0:	add    rdx,0x1
  410cc4:	add    rax,0x1
  410cc8:	mov    r8b,BYTE PTR [rdx]
  410ccb:	test   r8b,r8b
  410cce:	jne    410cc0 <__swc_fn_ff58629f_000146_e9d46966+0x980>
  410cd0:	mov    QWORD PTR [rsp+0x240],rcx
  410cd8:	mov    QWORD PTR [rsp+0x248],rax
  410ce0:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  410ce9:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  410cf2:	lea    rcx,[rsp+0x250]
  410cfa:	call   40fad0 <__swc_fn_ff58629f_000116_3499f7d6>
  410cff:	jmp    411405 <__swc_fn_ff58629f_000146_e9d46966+0x10c5>
  410d04:	lea    rcx,[rsp+0x260]
  410d0c:	vxorps xmm0,xmm0,xmm0
  410d10:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  410d19:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  410d22:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  410d2b:	vzeroupper
  410d2e:	mov    DWORD PTR [rsp+0x2c0],0x0
  410d39:	vmovsd xmm0,QWORD PTR [rdx]
  410d3d:	vcomisd xmm0,xmm0
  410d41:	setne  dl
  410d44:	movzx  edx,dl
  410d47:	setp   r8b
  410d4b:	movzx  r8d,r8b
  410d4f:	or     edx,r8d
  410d52:	test   dl,dl
  410d54:	je     410d61 <__swc_fn_ff58629f_000146_e9d46966+0xa21>
  410d56:	mov    DWORD PTR [rcx],0x6e616e
  410d5c:	jmp    411368 <__swc_fn_ff58629f_000146_e9d46966+0x1028>
  410d61:	vcomisd xmm0,xmm11
  410d66:	ja     410d77 <__swc_fn_ff58629f_000146_e9d46966+0xa37>
  410d68:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  410d71:	vcomisd xmm6,xmm0
  410d75:	jbe    410d9b <__swc_fn_ff58629f_000146_e9d46966+0xa5b>
  410d77:	vxorpd xmm1,xmm1,xmm1
  410d7b:	vcomisd xmm1,xmm0
  410d7f:	jbe    410d90 <__swc_fn_ff58629f_000146_e9d46966+0xa50>
  410d81:	mov    DWORD PTR [rcx],0x666e692d
  410d87:	mov    BYTE PTR [rcx+0x4],0x0
  410d8b:	jmp    411368 <__swc_fn_ff58629f_000146_e9d46966+0x1028>
  410d90:	mov    DWORD PTR [rcx],0x666e69
  410d96:	jmp    411368 <__swc_fn_ff58629f_000146_e9d46966+0x1028>
  410d9b:	vcomisd xmm0,xmm13
  410da0:	jae    410dac <__swc_fn_ff58629f_000146_e9d46966+0xa6c>
  410da2:	vcomisd xmm12,xmm0
  410da6:	jbe    41110e <__swc_fn_ff58629f_000146_e9d46966+0xdce>
  410dac:	vmovups xmm1,xmm0
  410db0:	vxorpd xmm2,xmm2,xmm2
  410db4:	vcomisd xmm2,xmm0
  410db8:	jbe    410dc8 <__swc_fn_ff58629f_000146_e9d46966+0xa88>
  410dba:	vmovsd xmm0,xmm0,xmm1
  410dbe:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x178a]        # 412550 <__swc_rdata_base_ff58629f+0x440>
  410dc6:	jmp    410dcc <__swc_fn_ff58629f_000146_e9d46966+0xa8c>
  410dc8:	vmovsd xmm0,xmm0,xmm1
  410dcc:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  410dd5:	xor    r8d,r8d
  410dd8:	vcomisd xmm0,xmm6
  410ddc:	jb     410dee <__swc_fn_ff58629f_000146_e9d46966+0xaae>
  410dde:	xchg   ax,ax
  410de0:	vdivsd xmm0,xmm0,xmm6
  410de4:	add    r8,0x1
  410de8:	vcomisd xmm0,xmm6
  410dec:	jae    410de0 <__swc_fn_ff58629f_000146_e9d46966+0xaa0>
  410dee:	mov    r9,rcx
  410df1:	vxorpd xmm2,xmm2,xmm2
  410df5:	vcomisd xmm2,xmm1
  410df9:	jbe    410e02 <__swc_fn_ff58629f_000146_e9d46966+0xac2>
  410dfb:	mov    BYTE PTR [rcx],0x2d
  410dfe:	lea    r9,[rcx+0x1]
  410e02:	vcvttsd2si rdx,xmm0
  410e07:	mov    r10b,dl
  410e0a:	add    r10b,0x30
  410e0e:	mov    BYTE PTR [r9],r10b
  410e11:	vxorpd xmm1,xmm1,xmm1
  410e15:	movzx  edx,dl
  410e18:	vcvtsi2sd xmm1,xmm1,rdx
  410e1d:	vsubsd xmm0,xmm0,xmm1
  410e21:	vmulsd xmm0,xmm0,xmm6
  410e25:	mov    BYTE PTR [r9+0x1],0x2e
  410e2a:	vcvttsd2si rdx,xmm0
  410e2f:	mov    r10b,dl
  410e32:	add    r10b,0x30
  410e36:	mov    BYTE PTR [r9+0x2],r10b
  410e3a:	vxorpd xmm1,xmm1,xmm1
  410e3e:	movzx  edx,dl
  410e41:	vcvtsi2sd xmm1,xmm1,rdx
  410e46:	vsubsd xmm0,xmm0,xmm1
  410e4a:	vmulsd xmm0,xmm0,xmm6
  410e4e:	vcvttsd2si rdx,xmm0
  410e53:	mov    r10b,dl
  410e56:	add    r10b,0x30
  410e5a:	mov    BYTE PTR [r9+0x3],r10b
  410e5e:	vxorpd xmm1,xmm1,xmm1
  410e62:	movzx  edx,dl
  410e65:	vcvtsi2sd xmm1,xmm1,rdx
  410e6a:	vsubsd xmm0,xmm0,xmm1
  410e6e:	vmulsd xmm0,xmm0,xmm6
  410e72:	vcvttsd2si rdx,xmm0
  410e77:	mov    r10b,dl
  410e7a:	add    r10b,0x30
  410e7e:	mov    BYTE PTR [r9+0x4],r10b
  410e82:	vxorpd xmm1,xmm1,xmm1
  410e86:	movzx  edx,dl
  410e89:	vcvtsi2sd xmm1,xmm1,rdx
  410e8e:	vsubsd xmm0,xmm0,xmm1
  410e92:	vmulsd xmm0,xmm0,xmm6
  410e96:	vcvttsd2si rdx,xmm0
  410e9b:	mov    r10b,dl
  410e9e:	add    r10b,0x30
  410ea2:	mov    BYTE PTR [r9+0x5],r10b
  410ea6:	vxorpd xmm1,xmm1,xmm1
  410eaa:	movzx  edx,dl
  410ead:	vcvtsi2sd xmm1,xmm1,rdx
  410eb2:	vsubsd xmm0,xmm0,xmm1
  410eb6:	vmulsd xmm0,xmm0,xmm6
  410eba:	vcvttsd2si rdx,xmm0
  410ebf:	mov    r10b,dl
  410ec2:	add    r10b,0x30
  410ec6:	mov    BYTE PTR [r9+0x6],r10b
  410eca:	vxorpd xmm1,xmm1,xmm1
  410ece:	movzx  edx,dl
  410ed1:	vcvtsi2sd xmm1,xmm1,rdx
  410ed6:	vsubsd xmm0,xmm0,xmm1
  410eda:	vmulsd xmm0,xmm0,xmm6
  410ede:	vcvttsd2si rdx,xmm0
  410ee3:	mov    r10b,dl
  410ee6:	add    r10b,0x30
  410eea:	mov    BYTE PTR [r9+0x7],r10b
  410eee:	vxorpd xmm1,xmm1,xmm1
  410ef2:	movzx  edx,dl
  410ef5:	vcvtsi2sd xmm1,xmm1,rdx
  410efa:	vsubsd xmm0,xmm0,xmm1
  410efe:	vmulsd xmm0,xmm0,xmm6
  410f02:	vcvttsd2si rdx,xmm0
  410f07:	mov    r10b,dl
  410f0a:	add    r10b,0x30
  410f0e:	mov    BYTE PTR [r9+0x8],r10b
  410f12:	vxorpd xmm1,xmm1,xmm1
  410f16:	movzx  edx,dl
  410f19:	vcvtsi2sd xmm1,xmm1,rdx
  410f1e:	vsubsd xmm0,xmm0,xmm1
  410f22:	vmulsd xmm0,xmm0,xmm6
  410f26:	vcvttsd2si rdx,xmm0
  410f2b:	mov    r10b,dl
  410f2e:	add    r10b,0x30
  410f32:	mov    BYTE PTR [r9+0x9],r10b
  410f36:	vxorpd xmm1,xmm1,xmm1
  410f3a:	movzx  edx,dl
  410f3d:	vcvtsi2sd xmm1,xmm1,rdx
  410f42:	vsubsd xmm0,xmm0,xmm1
  410f46:	vmulsd xmm0,xmm0,xmm6
  410f4a:	vcvttsd2si rdx,xmm0
  410f4f:	mov    r10b,dl
  410f52:	add    r10b,0x30
  410f56:	mov    BYTE PTR [r9+0xa],r10b
  410f5a:	vxorpd xmm1,xmm1,xmm1
  410f5e:	movzx  edx,dl
  410f61:	vcvtsi2sd xmm1,xmm1,rdx
  410f66:	vsubsd xmm0,xmm0,xmm1
  410f6a:	vmulsd xmm0,xmm0,xmm6
  410f6e:	vcvttsd2si rdx,xmm0
  410f73:	mov    r10b,dl
  410f76:	add    r10b,0x30
  410f7a:	mov    BYTE PTR [r9+0xb],r10b
  410f7e:	lea    r10,[r9+0x4]
  410f82:	vxorpd xmm1,xmm1,xmm1
  410f86:	movzx  edx,dl
  410f89:	vcvtsi2sd xmm1,xmm1,rdx
  410f8e:	vsubsd xmm0,xmm0,xmm1
  410f92:	vmulsd xmm0,xmm0,xmm6
  410f96:	vcvttsd2si rdx,xmm0
  410f9b:	mov    r11b,dl
  410f9e:	add    r11b,0x30
  410fa2:	mov    BYTE PTR [r9+0xc],r11b
  410fa6:	vxorpd xmm1,xmm1,xmm1
  410faa:	movzx  edx,dl
  410fad:	vcvtsi2sd xmm1,xmm1,rdx
  410fb2:	vsubsd xmm0,xmm0,xmm1
  410fb6:	vmulsd xmm0,xmm0,xmm6
  410fba:	vcvttsd2si rdx,xmm0
  410fbf:	mov    r11b,dl
  410fc2:	add    r11b,0x30
  410fc6:	mov    BYTE PTR [r9+0xd],r11b
  410fca:	lea    r10,[r10+0x2]
  410fce:	vxorpd xmm1,xmm1,xmm1
  410fd2:	movzx  edx,dl
  410fd5:	vcvtsi2sd xmm1,xmm1,rdx
  410fda:	vsubsd xmm0,xmm0,xmm1
  410fde:	vmulsd xmm0,xmm0,xmm6
  410fe2:	vcvttsd2si rdx,xmm0
  410fe7:	mov    r11b,dl
  410fea:	add    r11b,0x30
  410fee:	mov    BYTE PTR [r9+0xe],r11b
  410ff2:	vxorpd xmm1,xmm1,xmm1
  410ff6:	movzx  edx,dl
  410ff9:	vcvtsi2sd xmm1,xmm1,rdx
  410ffe:	vsubsd xmm0,xmm0,xmm1
  411002:	vmulsd xmm0,xmm0,xmm6
  411006:	vcvttsd2si rdx,xmm0
  41100b:	mov    r11b,dl
  41100e:	add    r11b,0x30
  411012:	mov    BYTE PTR [r9+0xf],r11b
  411016:	lea    r10,[r10+0x2]
  41101a:	lea    r10,[r10+0x2]
  41101e:	lea    r10,[r10+0x2]
  411022:	lea    r10,[r10+0x2]
  411026:	lea    r10,[r10+0x2]
  41102a:	vxorpd xmm1,xmm1,xmm1
  41102e:	movzx  edx,dl
  411031:	vcvtsi2sd xmm1,xmm1,rdx
  411036:	vsubsd xmm0,xmm0,xmm1
  41103a:	vmulsd xmm0,xmm0,xmm6
  41103e:	vcvttsd2si rdx,xmm0
  411043:	mov    r11b,dl
  411046:	add    r11b,0x30
  41104a:	mov    BYTE PTR [r9+0x10],r11b
  41104e:	vxorpd xmm1,xmm1,xmm1
  411052:	movzx  edx,dl
  411055:	vcvtsi2sd xmm1,xmm1,rdx
  41105a:	vsubsd xmm0,xmm0,xmm1
  41105e:	vmulsd xmm0,xmm0,xmm6
  411062:	vcvttsd2si rdx,xmm0
  411067:	add    dl,0x30
  41106a:	mov    BYTE PTR [r9+0x11],dl
  41106e:	mov    BYTE PTR [r10+0x2],0x65
  411073:	lea    r9,[r10+0x3]
  411077:	test   r8,r8
  41107a:	jl     411083 <__swc_fn_ff58629f_000146_e9d46966+0xd43>
  41107c:	mov    BYTE PTR [r9],0x2b
  411080:	inc    r9
  411083:	mov    r10,r9
  411086:	mov    rdx,r8
  411089:	nop    DWORD PTR [rax+0x0]
  411090:	mov    r11,rdx
  411093:	movabs rdx,0x6666666666666667
  41109d:	mov    rax,r11
  4110a0:	imul   rdx
  4110a3:	sar    rdx,0x2
  4110a7:	mov    r12,rdx
  4110aa:	shr    rdx,0x3f
  4110ae:	add    r12,rdx
  4110b1:	mov    rdx,r12
  4110b4:	imul   r13,r12,0xa
  4110b8:	sub    r11,r13
  4110bb:	mov    r13,QWORD PTR [rip+0x147e]        # 412540 <__swc_rdata_base_ff58629f+0x430>
  4110c2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4110c7:	mov    BYTE PTR [r10],r11b
  4110ca:	lea    r11,[r10+0x1]
  4110ce:	mov    r10,r11
  4110d1:	test   r12,r12
  4110d4:	jne    411090 <__swc_fn_ff58629f_000146_e9d46966+0xd50>
  4110d6:	test   r8,r8
  4110d9:	jge    4110e3 <__swc_fn_ff58629f_000146_e9d46966+0xda3>
  4110db:	mov    BYTE PTR [r11],0x2d
  4110df:	lea    r10,[r11+0x1]
  4110e3:	mov    BYTE PTR [r10],0x0
  4110e7:	sub    r10,0x1
  4110eb:	nop    DWORD PTR [rax+rax*1+0x0]
  4110f0:	cmp    r9,r10
  4110f3:	jae    411368 <__swc_fn_ff58629f_000146_e9d46966+0x1028>
  4110f9:	mov    al,BYTE PTR [r10]
  4110fc:	mov    dl,BYTE PTR [r9]
  4110ff:	mov    BYTE PTR [r10],dl
  411102:	sub    r10,0x1
  411106:	mov    BYTE PTR [r9],al
  411109:	inc    r9
  41110c:	jmp    4110f0 <__swc_fn_ff58629f_000146_e9d46966+0xdb0>
  41110e:	vcvttsd2si rdx,xmm0
  411113:	mov    r8,rdx
  411116:	vxorpd xmm1,xmm1,xmm1
  41111a:	vcvtsi2sd xmm1,xmm1,rdx
  41111f:	vsubsd xmm1,xmm0,xmm1
  411123:	mov    r9d,0x8
  411129:	vxorpd xmm2,xmm2,xmm2
  41112d:	vcomisd xmm2,xmm1
  411131:	ja     41113e <__swc_fn_ff58629f_000146_e9d46966+0xdfe>
  411133:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41113c:	jmp    41114f <__swc_fn_ff58629f_000146_e9d46966+0xe0f>
  41113e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x140a]        # 412550 <__swc_rdata_base_ff58629f+0x440>
  411146:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41114f:	test   r9d,r9d
  411152:	je     411169 <__swc_fn_ff58629f_000146_e9d46966+0xe29>
  411154:	cs nop WORD PTR [rax+rax*1+0x0]
  41115e:	xchg   ax,ax
  411160:	vmulsd xmm1,xmm1,xmm6
  411164:	dec    r9d
  411167:	jne    411160 <__swc_fn_ff58629f_000146_e9d46966+0xe20>
  411169:	vcvttsd2si r9,xmm1
  41116e:	mov    r10,r9
  411171:	vxorpd xmm2,xmm2,xmm2
  411175:	vcvtsi2sd xmm2,xmm2,r9
  41117a:	vsubsd xmm1,xmm1,xmm2
  41117e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  411187:	vcomisd xmm1,xmm6
  41118b:	lea    r9,[r9+0x1]
  41118f:	cmova  r10,r9
  411193:	cmp    r10,0x5f5e100
  41119a:	jne    4111b3 <__swc_fn_ff58629f_000146_e9d46966+0xe73>
  41119c:	lea    r8,[rdx-0x1]
  4111a0:	vxorpd xmm1,xmm1,xmm1
  4111a4:	vcomisd xmm1,xmm0
  4111a8:	lea    rdx,[rdx+0x1]
  4111ac:	cmovbe r8,rdx
  4111b0:	xor    r10d,r10d
  4111b3:	mov    r9,rcx
  4111b6:	test   r8,r8
  4111b9:	jne    4111d9 <__swc_fn_ff58629f_000146_e9d46966+0xe99>
  4111bb:	vxorpd xmm1,xmm1,xmm1
  4111bf:	vcomisd xmm1,xmm0
  4111c3:	jbe    4111cc <__swc_fn_ff58629f_000146_e9d46966+0xe8c>
  4111c5:	mov    BYTE PTR [rcx],0x2d
  4111c8:	lea    r9,[rcx+0x1]
  4111cc:	mov    BYTE PTR [r9],0x30
  4111d0:	add    r9,0x1
  4111d4:	jmp    41126b <__swc_fn_ff58629f_000146_e9d46966+0xf2b>
  4111d9:	mov    r9,rcx
  4111dc:	mov    rdx,r8
  4111df:	nop
  4111e0:	mov    r11,rdx
  4111e3:	movabs rdx,0x6666666666666667
  4111ed:	mov    r15,rax
  4111f0:	mov    rax,r11
  4111f3:	imul   rdx
  4111f6:	mov    r12,rdx
  4111f9:	mov    rax,r15
  4111fc:	sar    r12,0x2
  411200:	mov    rdx,r12
  411203:	shr    rdx,0x3f
  411207:	add    r12,rdx
  41120a:	mov    rdx,r12
  41120d:	imul   r13,r12,0xa
  411211:	sub    r11,r13
  411214:	mov    r13,QWORD PTR [rip+0x1325]        # 412540 <__swc_rdata_base_ff58629f+0x430>
  41121b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411220:	mov    BYTE PTR [r9],r11b
  411223:	lea    r11,[r9+0x1]
  411227:	mov    r9,r11
  41122a:	test   r12,r12
  41122d:	jne    4111e0 <__swc_fn_ff58629f_000146_e9d46966+0xea0>
  41122f:	test   r8,r8
  411232:	jge    41123c <__swc_fn_ff58629f_000146_e9d46966+0xefc>
  411234:	mov    BYTE PTR [r11],0x2d
  411238:	lea    r9,[r11+0x1]
  41123c:	mov    rdx,r9
  41123f:	mov    BYTE PTR [r9],0x0
  411243:	sub    r9,0x1
  411247:	mov    r8,rcx
  41124a:	cmp    r8,r9
  41124d:	jae    411268 <__swc_fn_ff58629f_000146_e9d46966+0xf28>
  41124f:	nop
  411250:	mov    r11b,BYTE PTR [r9]
  411253:	mov    r12b,BYTE PTR [r8]
  411256:	mov    BYTE PTR [r9],r12b
  411259:	sub    r9,0x1
  41125d:	mov    BYTE PTR [r8],r11b
  411260:	inc    r8
  411263:	cmp    r8,r9
  411266:	jb     411250 <__swc_fn_ff58629f_000146_e9d46966+0xf10>
  411268:	mov    r9,rdx
  41126b:	mov    BYTE PTR [r9],0x2e
  41126f:	add    r9,0x1
  411273:	xor    r8d,r8d
  411276:	test   r10,r10
  411279:	je     4112bf <__swc_fn_ff58629f_000146_e9d46966+0xf7f>
  41127b:	mov    r11d,0x989680
  411281:	cmp    r10,r11
  411284:	jge    4112bf <__swc_fn_ff58629f_000146_e9d46966+0xf7f>
  411286:	cs nop WORD PTR [rax+rax*1+0x0]
  411290:	inc    r8d
  411293:	movabs rdx,0x6666666666666667
  41129d:	mov    r15,rax
  4112a0:	mov    rax,r11
  4112a3:	imul   rdx
  4112a6:	mov    r11,rdx
  4112a9:	mov    rax,r15
  4112ac:	sar    r11,0x2
  4112b0:	mov    rdx,r11
  4112b3:	shr    rdx,0x3f
  4112b7:	add    r11,rdx
  4112ba:	cmp    r10,r11
  4112bd:	jl     411290 <__swc_fn_ff58629f_000146_e9d46966+0xf50>
  4112bf:	test   r8d,r8d
  4112c2:	je     4112dd <__swc_fn_ff58629f_000146_e9d46966+0xf9d>
  4112c4:	cs nop WORD PTR [rax+rax*1+0x0]
  4112ce:	xchg   ax,ax
  4112d0:	mov    BYTE PTR [r9],0x30
  4112d4:	add    r9,0x1
  4112d8:	dec    r8d
  4112db:	jne    4112d0 <__swc_fn_ff58629f_000146_e9d46966+0xf90>
  4112dd:	mov    r8,r9
  4112e0:	mov    rdx,r10
  4112e3:	cs nop WORD PTR [rax+rax*1+0x0]
  4112ed:	nop    DWORD PTR [rax]
  4112f0:	mov    r11,rdx
  4112f3:	movabs rdx,0x6666666666666667
  4112fd:	mov    rax,r11
  411300:	imul   rdx
  411303:	sar    rdx,0x2
  411307:	mov    r12,rdx
  41130a:	shr    rdx,0x3f
  41130e:	add    r12,rdx
  411311:	mov    rdx,r12
  411314:	imul   r13,r12,0xa
  411318:	sub    r11,r13
  41131b:	mov    r13,QWORD PTR [rip+0x121e]        # 412540 <__swc_rdata_base_ff58629f+0x430>
  411322:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411327:	mov    BYTE PTR [r8],r11b
  41132a:	lea    r11,[r8+0x1]
  41132e:	mov    r8,r11
  411331:	test   r12,r12
  411334:	jne    4112f0 <__swc_fn_ff58629f_000146_e9d46966+0xfb0>
  411336:	test   r10,r10
  411339:	jge    411343 <__swc_fn_ff58629f_000146_e9d46966+0x1003>
  41133b:	mov    BYTE PTR [r11],0x2d
  41133f:	lea    r8,[r11+0x1]
  411343:	mov    BYTE PTR [r8],0x0
  411347:	sub    r8,0x1
  41134b:	cmp    r9,r8
  41134e:	jae    411368 <__swc_fn_ff58629f_000146_e9d46966+0x1028>
  411350:	mov    al,BYTE PTR [r8]
  411353:	mov    dl,BYTE PTR [r9]
  411356:	mov    BYTE PTR [r8],dl
  411359:	sub    r8,0x1
  41135d:	mov    BYTE PTR [r9],al
  411360:	inc    r9
  411363:	cmp    r9,r8
  411366:	jb     411350 <__swc_fn_ff58629f_000146_e9d46966+0x1010>
  411368:	xor    eax,eax
  41136a:	test   rcx,rcx
  41136d:	je     411390 <__swc_fn_ff58629f_000146_e9d46966+0x1050>
  41136f:	mov    rdx,rcx
  411372:	mov    r8b,BYTE PTR [rdx]
  411375:	test   r8b,r8b
  411378:	je     411390 <__swc_fn_ff58629f_000146_e9d46966+0x1050>
  41137a:	nop    WORD PTR [rax+rax*1+0x0]
  411380:	add    rdx,0x1
  411384:	add    rax,0x1
  411388:	mov    r8b,BYTE PTR [rdx]
  41138b:	test   r8b,r8b
  41138e:	jne    411380 <__swc_fn_ff58629f_000146_e9d46966+0x1040>
  411390:	mov    QWORD PTR [rsp+0x3f8],rcx
  411398:	mov    QWORD PTR [rsp+0x400],rax
  4113a0:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  4113a9:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  4113b2:	lea    rcx,[rsp+0x408]
  4113ba:	call   40fad0 <__swc_fn_ff58629f_000116_3499f7d6>
  4113bf:	jmp    411405 <__swc_fn_ff58629f_000146_e9d46966+0x10c5>
  4113c1:	mov    rcx,rdx
  4113c4:	call   40fad0 <__swc_fn_ff58629f_000116_3499f7d6>
  4113c9:	jmp    411405 <__swc_fn_ff58629f_000146_e9d46966+0x10c5>
  4113cb:	mov    al,BYTE PTR [rdx]
  4113cd:	test   al,al
  4113cf:	je     4113da <__swc_fn_ff58629f_000146_e9d46966+0x109a>
  4113d1:	lea    rax,[rip+0x1188]        # 412560 <__swc_rdata_base_ff58629f+0x450>
  4113d8:	jmp    4113e1 <__swc_fn_ff58629f_000146_e9d46966+0x10a1>
  4113da:	lea    rax,[rip+0x118f]        # 412570 <__swc_rdata_base_ff58629f+0x460>
  4113e1:	mov    rcx,rax
  4113e4:	call   40fad0 <__swc_fn_ff58629f_000116_3499f7d6>
  4113e9:	jmp    411405 <__swc_fn_ff58629f_000146_e9d46966+0x10c5>
  4113eb:	lea    rcx,[rip+0x118e]        # 412580 <__swc_rdata_base_ff58629f+0x470>
  4113f2:	call   40fad0 <__swc_fn_ff58629f_000116_3499f7d6>
  4113f7:	jmp    411405 <__swc_fn_ff58629f_000146_e9d46966+0x10c5>
  4113f9:	lea    rcx,[rip+0x1180]        # 412580 <__swc_rdata_base_ff58629f+0x470>
  411400:	call   40fad0 <__swc_fn_ff58629f_000116_3499f7d6>
  411405:	add    rdi,0x1
  411409:	sub    rsi,0x1
  41140d:	vmovups xmm0,xmm12
  411412:	vmovsd xmm6,QWORD PTR [rip+0x1176]        # 412590 <__swc_rdata_base_ff58629f+0x480>
  41141a:	test   rsi,rsi
  41141d:	jne    410450 <__swc_fn_ff58629f_000146_e9d46966+0x110>
  411423:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  41142c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  411435:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  41143e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411447:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411450:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411459:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411462:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  41146b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411474:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  41147d:	add    rsp,0x4e8
  411484:	pop    r15
  411486:	pop    r13
  411488:	pop    r12
  41148a:	pop    rdi
  41148b:	pop    rsi
  41148c:	pop    rbx
  41148d:	ret
	...

0000000000411490 <__swc_fn_ff58629f_000149_33e5e24f>:
  411490:	vxorps xmm0,xmm0,xmm0
  411494:	vmovups XMMWORD PTR [rcx],xmm0
  411498:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41149d:	ret
	...

00000000004114a0 <__swc_fn_ff58629f_000152_33e5e24f>:
  4114a0:	vxorps xmm0,xmm0,xmm0
  4114a4:	vmovups XMMWORD PTR [rcx],xmm0
  4114a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4114ad:	vxorps xmm0,xmm0,xmm0
  4114b1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4114b6:	vmovups xmm0,XMMWORD PTR [rip+0x11e2]        # 4126a0 <__swc_rdata_base_ff58629f+0x590>
  4114be:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4114c3:	vxorps xmm0,xmm0,xmm0
  4114c7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  4114cc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  4114d1:	vxorps xmm0,xmm0,xmm0
  4114d5:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  4114da:	mov    QWORD PTR [rcx+0x70],0x0
  4114e2:	ret
	...

00000000004114f0 <__swc_fn_ff58629f_000155_33e5e24f>:
  4114f0:	vxorps xmm0,xmm0,xmm0
  4114f4:	vmovups XMMWORD PTR [rcx],xmm0
  4114f8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4114fd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411502:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411507:	ret
	...

0000000000411510 <__swc_fn_ff58629f_000158_6741c23b>:
  411510:	push   rsi
  411511:	push   rdi
  411512:	sub    rsp,0x8
  411516:	mov    rsi,rcx
  411519:	mov    rdi,QWORD PTR [rsi+0x50]
  41151d:	test   rdi,rdi
  411520:	je     411527 <__swc_fn_ff58629f_000158_6741c23b+0x17>
  411522:	mov    rcx,rsi
  411525:	call   rdi
  411527:	mov    QWORD PTR [rsi+0x20],0x0
  41152f:	mov    rax,QWORD PTR [rsi+0x30]
  411533:	test   rax,rax
  411536:	je     411564 <__swc_fn_ff58629f_000158_6741c23b+0x54>
  411538:	nop    DWORD PTR [rax+rax*1+0x0]
  411540:	mov    rdi,QWORD PTR [rax+0x8]
  411544:	mov    rcx,rsi
  411547:	mov    rdx,QWORD PTR [rax+0x10]
  41154b:	mov    rax,QWORD PTR [rax+0x18]
  41154f:	mov    r8,rax
  411552:	call   409e90 <__swc_fn_ff58629f_000156_312df05a>
  411557:	mov    QWORD PTR [rsi+0x30],rdi
  41155b:	mov    rax,QWORD PTR [rsi+0x30]
  41155f:	test   rax,rax
  411562:	jne    411540 <__swc_fn_ff58629f_000158_6741c23b+0x30>
  411564:	mov    QWORD PTR [rsi+0x38],0x0
  41156c:	add    rsp,0x8
  411570:	pop    rdi
  411571:	pop    rsi
  411572:	ret
	...

0000000000411580 <__swc_fn_ff58629f_000161_9e36e814>:
  411580:	push   rbx
  411581:	push   rsi
  411582:	push   rdi
  411583:	push   r12
  411585:	sub    rsp,0x188
  41158c:	mov    rbx,rcx
  41158f:	lea    rsi,[rip+0x147fa]        # 425d90 <__swc_bss_base_ff58629f+0x2d50>
  411596:	mov    rcx,rsi
  411599:	call   4098a0 <__swc_fn_ff58629f_000135_1fec60ac>
  41159e:	mov    rax,QWORD PTR [rip+0x147f3]        # 425d98 <__swc_bss_base_ff58629f+0x2d58>
  4115a5:	mov    rdi,rax
  4115a8:	test   rdi,rdi
  4115ab:	je     4115d9 <__swc_fn_ff58629f_000161_9e36e814+0x59>
  4115ad:	nop    DWORD PTR [rax]
  4115b0:	cmp    QWORD PTR [rdi+0x8],rbx
  4115b4:	jne    4115ce <__swc_fn_ff58629f_000161_9e36e814+0x4e>
  4115b6:	mov    rcx,rsi
  4115b9:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  4115be:	mov    rax,rdi
  4115c1:	add    rsp,0x188
  4115c8:	pop    r12
  4115ca:	pop    rdi
  4115cb:	pop    rsi
  4115cc:	pop    rbx
  4115cd:	ret
  4115ce:	mov    rax,QWORD PTR [rdi]
  4115d1:	mov    rdi,rax
  4115d4:	test   rax,rax
  4115d7:	jne    4115b0 <__swc_fn_ff58629f_000161_9e36e814+0x30>
  4115d9:	call   40ce80 <__swc_fn_ff58629f_000139_20e2e2c7>
  4115de:	mov    rdi,rax
  4115e1:	test   rax,rax
  4115e4:	jne    4115fd <__swc_fn_ff58629f_000161_9e36e814+0x7d>
  4115e6:	mov    rcx,rsi
  4115e9:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  4115ee:	xor    eax,eax
  4115f0:	add    rsp,0x188
  4115f7:	pop    r12
  4115f9:	pop    rdi
  4115fa:	pop    rsi
  4115fb:	pop    rbx
  4115fc:	ret
  4115fd:	lea    rax,[rsp+0x18]
  411602:	mov    QWORD PTR [rax+0x10],0x0
  41160a:	mov    QWORD PTR [rax+0x18],0x0
  411612:	mov    DWORD PTR [rax+0x20],0x0
  411619:	mov    BYTE PTR [rax+0x24],0x0
  41161d:	mov    rax,QWORD PTR [rip+0x14774]        # 425d98 <__swc_bss_base_ff58629f+0x2d58>
  411624:	mov    QWORD PTR [rsp+0x18],rax
  411629:	mov    QWORD PTR [rsp+0x20],rbx
  41162e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411634:	vmovups XMMWORD PTR [rdi],xmm0
  411638:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  41163e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  411643:	mov    rax,QWORD PTR [rsp+0x38]
  411648:	mov    QWORD PTR [rdi+0x20],rax
  41164c:	mov    QWORD PTR [rip+0x14745],rdi        # 425d98 <__swc_bss_base_ff58629f+0x2d58>
  411653:	lea    rax,[rsp+0x40]
  411658:	mov    QWORD PTR [rax],0x0
  41165f:	mov    rcx,rbx
  411662:	mov    rdx,rax
  411665:	call   409980 <__swc_fn_ff58629f_000141_376d5f6d>
  41166a:	mov    rbx,rax
  41166d:	test   rax,rax
  411670:	jne    41168a <__swc_fn_ff58629f_000161_9e36e814+0x10a>
  411672:	mov    rcx,rsi
  411675:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  41167a:	mov    rax,rdi
  41167d:	add    rsp,0x188
  411684:	pop    r12
  411686:	pop    rdi
  411687:	pop    rsi
  411688:	pop    rbx
  411689:	ret
  41168a:	lea    r12,[rsp+0x50]
  41168f:	mov    QWORD PTR [r12],0x0
  411697:	mov    rcx,rbx
  41169a:	mov    rdx,QWORD PTR [rsp+0x40]
  41169f:	mov    r8,r12
  4116a2:	call   40cf30 <__swc_fn_ff58629f_000142_e0543f36>
  4116a7:	test   rax,rax
  4116aa:	jne    4116c4 <__swc_fn_ff58629f_000161_9e36e814+0x144>
  4116ac:	mov    rcx,rsi
  4116af:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  4116b4:	mov    rax,rdi
  4116b7:	add    rsp,0x188
  4116be:	pop    r12
  4116c0:	pop    rdi
  4116c1:	pop    rsi
  4116c2:	pop    rbx
  4116c3:	ret
  4116c4:	cmp    QWORD PTR [r12],0x10
  4116c9:	jb     4117cc <__swc_fn_ff58629f_000161_9e36e814+0x24c>
  4116cf:	mov    ecx,DWORD PTR [rax]
  4116d1:	cmp    ecx,0x42445753
  4116d7:	jne    4117cc <__swc_fn_ff58629f_000161_9e36e814+0x24c>
  4116dd:	mov    ecx,DWORD PTR [rax+0x4]
  4116e0:	cmp    ecx,0x1
  4116e3:	jne    4117cc <__swc_fn_ff58629f_000161_9e36e814+0x24c>
  4116e9:	mov    ecx,DWORD PTR [rax+0x8]
  4116ec:	mov    edx,DWORD PTR [rax+0xc]
  4116ef:	imul   r8,rcx,0x14
  4116f3:	mov    r9,QWORD PTR [rsp+0x50]
  4116f8:	sub    r9,0x10
  4116fc:	cmp    r8,r9
  4116ff:	ja     4117cc <__swc_fn_ff58629f_000161_9e36e814+0x24c>
  411705:	lea    r8,[r8+0x10]
  411709:	cmp    rdx,r8
  41170c:	jb     4117cc <__swc_fn_ff58629f_000161_9e36e814+0x24c>
  411712:	mov    r8,QWORD PTR [rsp+0x50]
  411717:	cmp    rdx,r8
  41171a:	ja     4117cc <__swc_fn_ff58629f_000161_9e36e814+0x24c>
  411720:	xor    r8d,r8d
  411723:	test   rcx,rcx
  411726:	jbe    4117f2 <__swc_fn_ff58629f_000161_9e36e814+0x272>
  41172c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  411732:	cs nop WORD PTR [rax+rax*1+0x0]
  41173c:	nop    DWORD PTR [rax+0x0]
  411740:	imul   r9,r8,0x14
  411744:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  411749:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  41174e:	add    r10,r11
  411751:	movabs r11,0x100000000
  41175b:	cmp    r10,r11
  41175e:	ja     4117cc <__swc_fn_ff58629f_000161_9e36e814+0x24c>
  411760:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  411765:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  41176a:	test   r10d,r10d
  41176d:	setne  r11b
  411771:	je     41178b <__swc_fn_ff58629f_000161_9e36e814+0x20b>
  411773:	cmp    r10d,edx
  411776:	setb   r11b
  41177a:	jb     41178b <__swc_fn_ff58629f_000161_9e36e814+0x20b>
  41177c:	vmovq  r11,xmm1
  411781:	cmp    r10,r11
  411784:	setae  r10b
  411788:	mov    r11b,r10b
  41178b:	mov    r10,r11
  41178e:	test   r11b,r11b
  411791:	jne    4117b8 <__swc_fn_ff58629f_000161_9e36e814+0x238>
  411793:	test   r9d,r9d
  411796:	setne  r10b
  41179a:	je     4117b8 <__swc_fn_ff58629f_000161_9e36e814+0x238>
  41179c:	cmp    r9d,edx
  41179f:	setb   r10b
  4117a3:	jb     4117b8 <__swc_fn_ff58629f_000161_9e36e814+0x238>
  4117a5:	vmovq  r10,xmm1
  4117aa:	cmp    r9,r10
  4117ad:	setae  r9b
  4117b1:	movzx  r9d,r9b
  4117b5:	mov    r10b,r9b
  4117b8:	test   r10b,r10b
  4117bb:	jne    4117cc <__swc_fn_ff58629f_000161_9e36e814+0x24c>
  4117bd:	add    r8,0x1
  4117c1:	cmp    r8,rcx
  4117c4:	jb     411740 <__swc_fn_ff58629f_000161_9e36e814+0x1c0>
  4117ca:	jmp    4117f2 <__swc_fn_ff58629f_000161_9e36e814+0x272>
  4117cc:	xor    ecx,ecx
  4117ce:	cmp    rax,rbx
  4117d1:	cmovne rcx,rax
  4117d5:	call   410290 <__swc_fn_ff58629f_000143_afffe963>
  4117da:	mov    rcx,rsi
  4117dd:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  4117e2:	mov    rax,rdi
  4117e5:	add    rsp,0x188
  4117ec:	pop    r12
  4117ee:	pop    rdi
  4117ef:	pop    rsi
  4117f0:	pop    rbx
  4117f1:	ret
  4117f2:	mov    QWORD PTR [rdi+0x10],rax
  4117f6:	mov    rcx,QWORD PTR [rsp+0x50]
  4117fb:	mov    QWORD PTR [rdi+0x18],rcx
  4117ff:	mov    eax,DWORD PTR [rax+0x8]
  411802:	mov    DWORD PTR [rdi+0x20],eax
  411805:	rex mov BYTE PTR [rdi+0x24],0x1
  41180a:	mov    rcx,rsi
  41180d:	call   40ce70 <__swc_fn_ff58629f_000136_5589b4a1>
  411812:	mov    rax,rdi
  411815:	add    rsp,0x188
  41181c:	pop    r12
  41181e:	pop    rdi
  41181f:	pop    rsi
  411820:	pop    rbx
  411821:	ret
	...

0000000000411830 <__swc_fn_ff58629f_000164_15b66a30>:
  411830:	push   rsi
  411831:	push   rdi
  411832:	push   r12
  411834:	mov    rsi,rdx
  411837:	mov    rdi,rcx
  41183a:	mov    rcx,QWORD PTR [rip+0x144ff]        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  411841:	test   rcx,rcx
  411844:	jne    411856 <__swc_fn_ff58629f_000164_15b66a30+0x26>
  411846:	call   40a1a0 <__swc_fn_ff58629f_000165_e09accff>
  41184b:	lea    rcx,[rax+0x1]
  41184f:	mov    QWORD PTR [rip+0x144ea],rcx        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  411856:	dec    rcx
  411859:	call   411880 <__swc_fn_ff58629f_000167_3130645d>
  41185e:	mov    r12,QWORD PTR [rax+0xbe0]
  411865:	test   r12,r12
  411868:	setne  al
  41186b:	je     411876 <__swc_fn_ff58629f_000164_15b66a30+0x46>
  41186d:	mov    rcx,rdi
  411870:	mov    rdx,rsi
  411873:	call   r12
  411876:	pop    r12
  411878:	pop    rdi
  411879:	pop    rsi
  41187a:	ret
  41187b:	add    BYTE PTR [rax],al
  41187d:	add    BYTE PTR [rax],al
	...

0000000000411880 <__swc_fn_ff58629f_000167_3130645d>:
  411880:	push   r12
  411882:	push   rdi
  411883:	push   rsi
  411884:	sub    rsp,0xd0
  41188b:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  411891:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  411897:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  41189d:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4118a3:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4118a9:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4118af:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  4118b8:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  4118c1:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  4118ca:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  4118d3:	mov    r12,rcx
  4118d6:	mov    edi,ecx
  4118d8:	xor    eax,eax
  4118da:	call   407000 <pthread_getspecific@plt>
  4118df:	test   rax,rax
  4118e2:	je     4118e6 <__swc_fn_ff58629f_000167_3130645d+0x66>
  4118e4:	jmp    4118ee <__swc_fn_ff58629f_000167_3130645d+0x6e>
  4118e6:	mov    rcx,r12
  4118e9:	call   40a200 <__swc_fn_ff58629f_000168_0ff0458f>
  4118ee:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  4118f4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  4118fa:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  411900:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  411906:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  41190c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  411912:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  41191b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  411924:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  41192d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  411936:	add    rsp,0xd0
  41193d:	pop    rsi
  41193e:	pop    rdi
  41193f:	pop    r12
  411941:	ret
	...

0000000000411950 <__swc_fn_ff58629f_000170_8b7c1b80>:
  411950:	push   rsi
  411951:	sub    rsp,0x30
  411955:	lea    rsi,[rip+0x1444c]        # 425da8 <__swc_bss_base_ff58629f+0x2d68>
  41195c:	mov    rax,QWORD PTR [rsi]
  41195f:	test   rax,rax
  411962:	je     41196a <__swc_fn_ff58629f_000170_8b7c1b80+0x1a>
  411964:	add    rsp,0x30
  411968:	pop    rsi
  411969:	ret
  41196a:	mov    ecx,0x3
  41196f:	mov    edx,0x10
  411974:	call   40f3f0 <__swc_fn_ff58629f_000107_ff529476>
  411979:	test   rax,rax
  41197c:	jne    41198d <__swc_fn_ff58629f_000170_8b7c1b80+0x3d>
  41197e:	mov    QWORD PTR [rsp+0x18],rax
  411983:	call   40c9d0 <__swc_fn_ff58629f_000118_2b35b5e0>
  411988:	mov    rax,QWORD PTR [rsp+0x18]
  41198d:	mov    rcx,rax
  411990:	xchg   QWORD PTR [rsi],rcx
  411993:	add    rsp,0x30
  411997:	pop    rsi
  411998:	ret
  411999:	add    BYTE PTR [rax],al
  41199b:	add    BYTE PTR [rax],al
  41199d:	add    BYTE PTR [rax],al
	...

00000000004119a0 <__swc_fn_ff58629f_000173_156cb9fe>:
  4119a0:	push   rsi
  4119a1:	push   rdi
  4119a2:	sub    rsp,0x8
  4119a6:	mov    rsi,rdx
  4119a9:	mov    rdi,rcx
  4119ac:	mov    rax,QWORD PTR [rsi+0x8]
  4119b0:	test   rax,rax
  4119b3:	je     4119bd <__swc_fn_ff58629f_000173_156cb9fe+0x1d>
  4119b5:	mov    rcx,QWORD PTR [rsi]
  4119b8:	mov    QWORD PTR [rax],rcx
  4119bb:	jmp    4119c4 <__swc_fn_ff58629f_000173_156cb9fe+0x24>
  4119bd:	mov    rax,QWORD PTR [rsi]
  4119c0:	mov    QWORD PTR [rdi+0x8],rax
  4119c4:	mov    rax,QWORD PTR [rsi]
  4119c7:	test   rax,rax
  4119ca:	je     4119d4 <__swc_fn_ff58629f_000173_156cb9fe+0x34>
  4119cc:	mov    rcx,QWORD PTR [rsi+0x8]
  4119d0:	mov    QWORD PTR [rax+0x8],rcx
  4119d4:	mov    rcx,rdi
  4119d7:	mov    rdx,QWORD PTR [rsi+0x10]
  4119db:	mov    r8,QWORD PTR [rsi+0x18]
  4119df:	mov    r9,0xffffffffffffffff
  4119e6:	call   40d580 <__swc_fn_ff58629f_000172_9a88b1d5>
  4119eb:	mov    QWORD PTR [rsi+0x18],0x0
  4119f3:	mov    rax,QWORD PTR [rdi+0x8]
  4119f7:	test   rax,rax
  4119fa:	jne    411a0c <__swc_fn_ff58629f_000173_156cb9fe+0x6c>
  4119fc:	call   411950 <__swc_fn_ff58629f_000170_8b7c1b80>
  411a01:	xor    ecx,ecx
  411a03:	mov    QWORD PTR [rax+0x8],rcx
  411a07:	xor    ecx,ecx
  411a09:	mov    QWORD PTR [rax],rcx
  411a0c:	add    rsp,0x8
  411a10:	pop    rdi
  411a11:	pop    rsi
  411a12:	ret
	...

0000000000411a20 <__swc_fn_ff58629f_000176_5d3d19bd>:
  411a20:	push   rbx
  411a21:	sub    rsp,0x70
  411a25:	test   rcx,rcx
  411a28:	jne    411a30 <__swc_fn_ff58629f_000176_5d3d19bd+0x10>
  411a2a:	add    rsp,0x70
  411a2e:	pop    rbx
  411a2f:	ret
  411a30:	vxorps xmm0,xmm0,xmm0
  411a34:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  411a3a:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  411a40:	vzeroupper
  411a43:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  411a49:	lea    rax,[rcx-0x10]
  411a4d:	mov    QWORD PTR [rsp+0x48],rax
  411a52:	mov    rax,QWORD PTR [rcx-0x10]
  411a56:	mov    QWORD PTR [rsp+0x50],rax
  411a5b:	mov    rcx,QWORD PTR [rip+0x142de]        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  411a62:	test   rcx,rcx
  411a65:	jne    411a77 <__swc_fn_ff58629f_000176_5d3d19bd+0x57>
  411a67:	call   40a1a0 <__swc_fn_ff58629f_000165_e09accff>
  411a6c:	lea    rcx,[rax+0x1]
  411a70:	mov    QWORD PTR [rip+0x142c9],rcx        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  411a77:	dec    rcx
  411a7a:	call   411880 <__swc_fn_ff58629f_000167_3130645d>
  411a7f:	mov    rcx,QWORD PTR [rax]
  411a82:	lea    rdx,[rsp+0x8]
  411a87:	mov    rbx,QWORD PTR [rax+0x8]
  411a8b:	mov    rbx,QWORD PTR [rbx+0x18]
  411a8f:	call   rbx
  411a91:	add    rsp,0x70
  411a95:	pop    rbx
  411a96:	ret
	...

0000000000411aa0 <__swc_fn_ff58629f_000179_05d3c06b>:
  411aa0:	push   rbp
  411aa1:	push   rsi
  411aa2:	push   rdi
  411aa3:	sub    rsp,0x18
  411aa7:	mov    rbp,rsp
  411aaa:	vmovups XMMWORD PTR [rsp],xmm6
  411aaf:	sub    rsp,0x50
  411ab3:	mov    ecx,0x249f00
  411ab8:	sub    rsp,0x8
  411abc:	call   40d630 <__swc_fn_ff58629f_000175_2744b483>
  411ac1:	add    rsp,0x8
  411ac5:	mov    rsi,rax
  411ac8:	xor    ecx,ecx
  411aca:	nop    WORD PTR [rax+rax*1+0x0]
  411ad0:	mov    r8,QWORD PTR [rip+0xf539]        # 421010 <__swc_data_base_ff58629f+0x10>
  411ad7:	imul   r8,r8,0x41a7
  411ade:	movabs rdx,0x200000005
  411ae8:	mov    r11,rax
  411aeb:	mov    rax,r8
  411aee:	mul    rdx
  411af1:	mov    r9,rdx
  411af4:	mov    rdx,r8
  411af7:	sub    rdx,r9
  411afa:	shr    rdx,1
  411afd:	add    rdx,r9
  411b00:	shr    rdx,0x1e
  411b04:	imul   r9,rdx,0x7fffffff
  411b0b:	sub    r8,r9
  411b0e:	mov    QWORD PTR [rip+0xf4fb],r8        # 421010 <__swc_data_base_ff58629f+0x10>
  411b15:	mov    QWORD PTR [rsi+rcx*8],r8
  411b19:	add    rcx,0x1
  411b1d:	mov    r8,QWORD PTR [rip+0xf4ec]        # 421010 <__swc_data_base_ff58629f+0x10>
  411b24:	imul   r8,r8,0x41a7
  411b2b:	movabs rdx,0x200000005
  411b35:	mov    rax,r8
  411b38:	mul    rdx
  411b3b:	mov    r9,rdx
  411b3e:	mov    rax,r11
  411b41:	mov    rdx,r8
  411b44:	sub    rdx,r9
  411b47:	shr    rdx,1
  411b4a:	add    rdx,r9
  411b4d:	shr    rdx,0x1e
  411b51:	imul   rdx,rdx,0x7fffffff
  411b58:	sub    r8,rdx
  411b5b:	mov    QWORD PTR [rip+0xf4ae],r8        # 421010 <__swc_data_base_ff58629f+0x10>
  411b62:	mov    QWORD PTR [rsi+rcx*8],r8
  411b66:	add    rcx,0x1
  411b6a:	cmp    rcx,0x493e0
  411b71:	jl     411ad0 <__swc_fn_ff58629f_000179_05d3c06b+0x30>
  411b77:	sub    rsp,0x8
  411b7b:	call   40a350 <__swc_fn_ff58629f_000177_1ca87929>
  411b80:	add    rsp,0x8
  411b84:	vmovups xmm6,xmm0
  411b88:	mov    rcx,rsi
  411b8b:	xor    edx,edx
  411b8d:	mov    r8d,0x493df
  411b93:	sub    rsp,0x8
  411b97:	call   40d6e0 <__swc_fn_ff58629f_000178_2a1d71b4>
  411b9c:	add    rsp,0x8
  411ba0:	mov    cl,0x1
  411ba2:	mov    edx,0x1
  411ba7:	nop    WORD PTR [rax+rax*1+0x0]
  411bb0:	mov    r8,QWORD PTR [rsi+rdx*8]
  411bb4:	cmp    QWORD PTR [rsi+rdx*8-0x8],r8
  411bb9:	jbe    411bbd <__swc_fn_ff58629f_000179_05d3c06b+0x11d>
  411bbb:	xor    ecx,ecx
  411bbd:	add    rdx,0x1
  411bc1:	cmp    rdx,0x493e0
  411bc8:	jl     411bb0 <__swc_fn_ff58629f_000179_05d3c06b+0x110>
  411bca:	xor    edi,edi
  411bcc:	test   cl,cl
  411bce:	je     411c92 <__swc_fn_ff58629f_000179_05d3c06b+0x1f2>
  411bd4:	xor    ecx,ecx
  411bd6:	cs nop WORD PTR [rax+rax*1+0x0]
  411be0:	mov    r8,QWORD PTR [rsi+rcx*8]
  411be4:	mov    r9,r8
  411be7:	shr    r8,0x3
  411beb:	movabs rdx,0x20c49ba5e353f7cf
  411bf5:	mov    r10,rax
  411bf8:	mov    rax,r8
  411bfb:	mul    rdx
  411bfe:	mov    r11,r10
  411c01:	shr    rdx,0x4
  411c05:	imul   rdx,rdx,0x3e8
  411c0c:	sub    r9,rdx
  411c0f:	mov    edx,ecx
  411c11:	imul   rdx,rdx,0x24924925
  411c18:	shr    rdx,0x20
  411c1c:	imul   edx,edx,0x7
  411c1f:	mov    r8d,ecx
  411c22:	sub    r8d,edx
  411c25:	lea    rdx,[r8+0x1]
  411c29:	imul   r9,rdx
  411c2d:	add    rdi,r9
  411c30:	add    rcx,0x1
  411c34:	mov    r8,QWORD PTR [rsi+rcx*8]
  411c38:	mov    r9,r8
  411c3b:	shr    r8,0x3
  411c3f:	movabs rdx,0x20c49ba5e353f7cf
  411c49:	mov    rax,r8
  411c4c:	mul    rdx
  411c4f:	mov    rax,r11
  411c52:	shr    rdx,0x4
  411c56:	imul   rdx,rdx,0x3e8
  411c5d:	sub    r9,rdx
  411c60:	mov    edx,ecx
  411c62:	imul   rdx,rdx,0x24924925
  411c69:	shr    rdx,0x20
  411c6d:	imul   edx,edx,0x7
  411c70:	mov    r8d,ecx
  411c73:	sub    r8d,edx
  411c76:	lea    rdx,[r8+0x1]
  411c7a:	imul   r9,rdx
  411c7e:	add    rdi,r9
  411c81:	add    rcx,0x1
  411c85:	cmp    rcx,0x493e0
  411c8c:	jl     411be0 <__swc_fn_ff58629f_000179_05d3c06b+0x140>
  411c92:	sub    rsp,0x8
  411c96:	call   40a350 <__swc_fn_ff58629f_000177_1ca87929>
  411c9b:	add    rsp,0x8
  411c9f:	vsubsd xmm0,xmm0,xmm6
  411ca3:	vmulsd xmm0,xmm0,QWORD PTR [rip+0xd1d]        # 4129c8 <__swc_rdata_base_ff58629f+0x8b8>
  411cab:	lea    rax,[rip+0x6b6]        # 412368 <__swc_rdata_base_ff58629f+0x258>
  411cb2:	sub    rsp,0x90
  411cb9:	mov    rcx,rsp
  411cbc:	vmovups xmm1,XMMWORD PTR [rip+0xce4]        # 4129a8 <__swc_rdata_base_ff58629f+0x898>
  411cc4:	vmovups XMMWORD PTR [rcx],xmm1
  411cc8:	mov    QWORD PTR [rcx+0x30],rsp
  411ccc:	lea    rdx,[rip+0x63d]        # 412310 <__swc_rdata_base_ff58629f+0x200>
  411cd3:	mov    QWORD PTR [rcx+0x38],rdx
  411cd7:	mov    QWORD PTR [rcx+0x10],rdi
  411cdb:	lea    r8,[rsp+0x10]
  411ce0:	mov    QWORD PTR [rcx+0x40],r8
  411ce4:	lea    r8,[rip+0xc2d]        # 412918 <__swc_rdata_base_ff58629f+0x808>
  411ceb:	mov    QWORD PTR [rcx+0x48],r8
  411cef:	vmovups xmm1,XMMWORD PTR [rip+0xcc1]        # 4129b8 <__swc_rdata_base_ff58629f+0x8a8>
  411cf7:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  411cfc:	lea    r8,[rsp+0x18]
  411d01:	mov    QWORD PTR [rcx+0x50],r8
  411d05:	mov    QWORD PTR [rcx+0x58],rdx
  411d09:	vmovsd QWORD PTR [rcx+0x28],xmm0
  411d0e:	lea    r8,[rcx+0x28]
  411d12:	mov    QWORD PTR [rcx+0x60],r8
  411d16:	lea    r8,[rip+0xc43]        # 412960 <__swc_rdata_base_ff58629f+0x850>
  411d1d:	mov    QWORD PTR [rcx+0x68],r8
  411d21:	mov    QWORD PTR [rcx+0x70],rax
  411d25:	mov    QWORD PTR [rcx+0x78],rdx
  411d29:	lea    rax,[rcx+0x30]
  411d2d:	mov    QWORD PTR [rcx+0x80],rax
  411d34:	mov    QWORD PTR [rcx+0x88],0x5
  411d3f:	lea    rcx,[rcx+0x80]
  411d46:	sub    rsp,0x8
  411d4a:	call   410340 <__swc_fn_ff58629f_000146_e9d46966>
  411d4f:	add    rsp,0x8
  411d53:	add    rsp,0x90
  411d5a:	mov    rcx,rsi
  411d5d:	sub    rsp,0x8
  411d61:	call   411a20 <__swc_fn_ff58629f_000176_5d3d19bd>
  411d66:	add    rsp,0x58
  411d6a:	vmovups xmm6,XMMWORD PTR [rsp]
  411d6f:	add    rsp,0x18
  411d73:	pop    rdi
  411d74:	pop    rsi
  411d75:	pop    rbp
  411d76:	ret
