
/workspace/prompt2-20261115/session-combined-micro/base/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

000000000040b920 <__swc_fn_4fa09e82_000180_913db40c>:
  40b920:	push   rbp
  40b921:	push   rbx
  40b922:	push   rsi
  40b923:	push   rdi
  40b924:	push   r12
  40b926:	push   r15
  40b928:	push   r13
  40b92a:	push   r14
  40b92c:	sub    rsp,0x10
  40b930:	mov    rbp,rsp
  40b933:	vmovups XMMWORD PTR [rsp],xmm6
  40b938:	sub    rsp,0x50
  40b93c:	mov    rbx,rsp
  40b93f:	sub    rsp,0x8
  40b943:	mov    ecx,0x13880
  40b948:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  40b94d:	mov    rsi,rax
  40b950:	mov    ecx,0x9c40
  40b955:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  40b95a:	mov    rdi,rax
  40b95d:	mov    ecx,0x9c40
  40b962:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  40b967:	mov    r12,rax
  40b96a:	xor    ecx,ecx
  40b96c:	xor    r8d,r8d
  40b96f:	cs nop WORD PTR [rax+rax*1+0x0]
  40b979:	nop    DWORD PTR [rax+0x0]
  40b980:	lea    r9,[r8+0x1]
  40b984:	mov    r10,r9
  40b987:	movabs rdx,0xaaaaaaaaaaaaaaab
  40b991:	mov    r15,rax
  40b994:	mov    rax,r8
  40b997:	mul    rdx
  40b99a:	mov    r11,rdx
  40b99d:	mov    rax,r15
  40b9a0:	shr    r11,0x2
  40b9a4:	imul   r11,r11,0x6
  40b9a8:	mov    rdx,r8
  40b9ab:	sub    rdx,r11
  40b9ae:	lea    r11,[rdx+0x3]
  40b9b2:	mov    QWORD PTR [rdi+r8*8],rcx
  40b9b6:	mov    QWORD PTR [r12+r8*8],r11
  40b9ba:	xor    r8d,r8d
  40b9bd:	test   r11,r11
  40b9c0:	jbe    40ba14 <__swc_fn_4fa09e82_000180_913db40c+0xf4>
  40b9c2:	xor    r13d,r13d
  40b9c5:	cs nop WORD PTR [rax+rax*1+0x0]
  40b9cf:	nop
  40b9d0:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40b9da:	mov    r15,rax
  40b9dd:	mov    rax,r10
  40b9e0:	mul    rdx
  40b9e3:	mov    r14,rdx
  40b9e6:	mov    rax,r15
  40b9e9:	shr    r14,0x3
  40b9ed:	imul   r14,r14,0x1a
  40b9f1:	sub    r10,r14
  40b9f4:	lea    r10,[r10+0x61]
  40b9f8:	mov    BYTE PTR [rsi+rcx*1],r10b
  40b9fc:	inc    rcx
  40b9ff:	shr    rdx,0x3
  40ba03:	lea    r10,[rdx+r13*1]
  40ba07:	add    r8,0x1
  40ba0b:	add    r13,0x7
  40ba0f:	cmp    r8,r11
  40ba12:	jb     40b9d0 <__swc_fn_4fa09e82_000180_913db40c+0xb0>
  40ba14:	mov    r8,r9
  40ba17:	cmp    r9,0x1388
  40ba1e:	jb     40b980 <__swc_fn_4fa09e82_000180_913db40c+0x60>
  40ba24:	mov    ecx,0x16e3600
  40ba29:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  40ba2e:	mov    QWORD PTR [rip+0x1b39b],rax        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40ba35:	xor    ecx,ecx
  40ba37:	xor    r8d,r8d
  40ba3a:	nop    WORD PTR [rax+rax*1+0x0]
  40ba40:	mov    r9,QWORD PTR [rip+0x165c9]        # 422010 <__swc_data_base_4fa09e82+0x10>
  40ba47:	imul   r9,r9,0x41a7
  40ba4e:	movabs rdx,0x200000005
  40ba58:	mov    r11,rax
  40ba5b:	mov    rax,r9
  40ba5e:	mul    rdx
  40ba61:	mov    r10,rdx
  40ba64:	mov    rdx,r9
  40ba67:	sub    rdx,r10
  40ba6a:	shr    rdx,1
  40ba6d:	add    rdx,r10
  40ba70:	shr    rdx,0x1e
  40ba74:	imul   r10,rdx,0x7fffffff
  40ba7b:	sub    r9,r10
  40ba7e:	mov    QWORD PTR [rip+0x1658b],r9        # 422010 <__swc_data_base_4fa09e82+0x10>
  40ba85:	movabs rdx,0x346dc5d63886594b
  40ba8f:	mov    rax,r9
  40ba92:	mul    rdx
  40ba95:	mov    rax,r11
  40ba98:	shr    rdx,0xa
  40ba9c:	imul   rdx,rdx,0x1388
  40baa3:	sub    r9,rdx
  40baa6:	mov    rdx,QWORD PTR [rdi+r9*8]
  40baaa:	mov    r9,QWORD PTR [r12+r9*8]
  40baae:	xor    r10d,r10d
  40bab1:	test   r9,r9
  40bab4:	jbe    40bad4 <__swc_fn_4fa09e82_000180_913db40c+0x1b4>
  40bab6:	mov    r11,QWORD PTR [rip+0x1b313]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40babd:	add    rdx,rsi
  40bac0:	mov    r13b,BYTE PTR [rdx+r10*1]
  40bac4:	mov    BYTE PTR [r11+rcx*1],r13b
  40bac8:	inc    rcx
  40bacb:	add    r10,0x1
  40bacf:	cmp    r10,r9
  40bad2:	jb     40bac0 <__swc_fn_4fa09e82_000180_913db40c+0x1a0>
  40bad4:	lea    r9,[r8+0x1]
  40bad8:	movabs rdx,0xaaaaaaaaaaaaaaab
  40bae2:	mov    r11,rax
  40bae5:	mov    rax,r9
  40bae8:	mul    rdx
  40baeb:	mov    r8,rdx
  40baee:	mov    rax,r11
  40baf1:	shr    r8,0x3
  40baf5:	imul   r8,r8,0xc
  40baf9:	mov    rdx,r9
  40bafc:	sub    rdx,r8
  40baff:	jne    40bb0e <__swc_fn_4fa09e82_000180_913db40c+0x1ee>
  40bb01:	mov    rdx,QWORD PTR [rip+0x1b2c8]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40bb08:	mov    BYTE PTR [rdx+rcx*1],0xa
  40bb0c:	jmp    40bb19 <__swc_fn_4fa09e82_000180_913db40c+0x1f9>
  40bb0e:	mov    rdx,QWORD PTR [rip+0x1b2bb]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40bb15:	mov    BYTE PTR [rdx+rcx*1],0x20
  40bb19:	lea    r13,[rcx+0x1]
  40bb1d:	mov    r15,r13
  40bb20:	mov    rcx,r13
  40bb23:	mov    r8,r9
  40bb26:	cmp    r9,0x1e8480
  40bb2d:	jb     40ba40 <__swc_fn_4fa09e82_000180_913db40c+0x120>
  40bb33:	mov    QWORD PTR [rsp+0x48],r15
  40bb38:	call   40f2a0 <__swc_fn_4fa09e82_000178_1ca87929>
  40bb3d:	vmovups xmm6,xmm0
  40bb41:	mov    rsi,rbx
  40bb44:	mov    QWORD PTR [rsp+0x50],rsi
  40bb49:	vxorps xmm0,xmm0,xmm0
  40bb4d:	vmovups XMMWORD PTR [rbx],xmm0
  40bb51:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40bb56:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40bb5b:	mov    QWORD PTR [rbx+0x30],0x0
  40bb63:	mov    r8,QWORD PTR [rip+0x1b266]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40bb6a:	mov    rcx,rsi
  40bb6d:	mov    edx,0x4000
  40bb72:	call   412130 <__swc_fn_4fa09e82_000176_e7f0b636>
  40bb77:	xor    edi,edi
  40bb79:	xor    al,al
  40bb7b:	xor    r12d,r12d
  40bb7e:	cmp    r12,r13
  40bb81:	jae    40bcef <__swc_fn_4fa09e82_000180_913db40c+0x3cf>
  40bb87:	nop    WORD PTR [rax+rax*1+0x0]
  40bb90:	mov    rcx,QWORD PTR [rip+0x1b239]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40bb97:	mov    cl,BYTE PTR [rcx+r12*1]
  40bb9b:	sub    cl,0x61
  40bb9e:	cmp    cl,0x19
  40bba1:	ja     40bbb8 <__swc_fn_4fa09e82_000180_913db40c+0x298>
  40bba3:	test   al,al
  40bba5:	jne    40bcde <__swc_fn_4fa09e82_000180_913db40c+0x3be>
  40bbab:	mov    rdi,r12
  40bbae:	mov    eax,0x1
  40bbb3:	jmp    40bcde <__swc_fn_4fa09e82_000180_913db40c+0x3be>
  40bbb8:	test   al,al
  40bbba:	je     40bcde <__swc_fn_4fa09e82_000180_913db40c+0x3be>
  40bbc0:	mov    r14,r12
  40bbc3:	sub    r14,rdi
  40bbc6:	mov    eax,0x811c9dc5
  40bbcb:	xor    ecx,ecx
  40bbcd:	test   r14,r14
  40bbd0:	jbe    40bc52 <__swc_fn_4fa09e82_000180_913db40c+0x332>
  40bbd6:	mov    rdx,QWORD PTR [rbx+0x20]
  40bbda:	add    rdx,rdi
  40bbdd:	cmp    r14,0x4
  40bbe1:	jb     40bc40 <__swc_fn_4fa09e82_000180_913db40c+0x320>
  40bbe7:	lea    r8,[r14-0x3]
  40bbeb:	cs nop WORD PTR [rax+rax*1+0x0]
  40bbf5:	cs nop WORD PTR [rax+rax*1+0x0]
  40bbff:	nop
  40bc00:	xor    al,BYTE PTR [rdx+rcx*1]
  40bc03:	imul   eax,eax,0x1000193
  40bc09:	xor    al,BYTE PTR [rdx+rcx*1+0x1]
  40bc0d:	imul   eax,eax,0x1000193
  40bc13:	xor    al,BYTE PTR [rdx+rcx*1+0x2]
  40bc17:	imul   eax,eax,0x1000193
  40bc1d:	xor    al,BYTE PTR [rdx+rcx*1+0x3]
  40bc21:	imul   eax,eax,0x1000193
  40bc27:	add    rcx,0x4
  40bc2b:	cmp    rcx,r8
  40bc2e:	jb     40bc00 <__swc_fn_4fa09e82_000180_913db40c+0x2e0>
  40bc30:	cmp    rcx,r14
  40bc33:	jae    40bc52 <__swc_fn_4fa09e82_000180_913db40c+0x332>
  40bc35:	cs nop WORD PTR [rax+rax*1+0x0]
  40bc3f:	nop
  40bc40:	xor    al,BYTE PTR [rdx+rcx*1]
  40bc43:	imul   eax,eax,0x1000193
  40bc49:	add    rcx,0x1
  40bc4d:	cmp    rcx,r14
  40bc50:	jb     40bc40 <__swc_fn_4fa09e82_000180_913db40c+0x320>
  40bc52:	and    rax,QWORD PTR [rbx+0x28]
  40bc56:	mov    r15,rax
  40bc59:	mov    rsi,QWORD PTR [rbx+0x18]
  40bc5d:	mov    r13,QWORD PTR [rbx+0x8]
  40bc61:	cmp    BYTE PTR [rsi+r15*1],0x0
  40bc66:	je     40bca6 <__swc_fn_4fa09e82_000180_913db40c+0x386>
  40bc68:	nop    DWORD PTR [rax+rax*1+0x0]
  40bc70:	cmp    QWORD PTR [r13+r15*8+0x0],r14
  40bc75:	jne    40bc98 <__swc_fn_4fa09e82_000180_913db40c+0x378>
  40bc77:	mov    rax,QWORD PTR [rbx]
  40bc7a:	mov    rax,QWORD PTR [rax+r15*8]
  40bc7e:	mov    rcx,QWORD PTR [rbx+0x20]
  40bc82:	add    rax,rcx
  40bc85:	lea    rdx,[rcx+rdi*1]
  40bc89:	mov    rcx,rax
  40bc8c:	mov    r8,r14
  40bc8f:	call   410f30 <__swc_fn_4fa09e82_000107_ed4b1681>
  40bc94:	test   eax,eax
  40bc96:	je     40bca6 <__swc_fn_4fa09e82_000180_913db40c+0x386>
  40bc98:	inc    r15
  40bc9b:	and    r15,QWORD PTR [rbx+0x28]
  40bc9f:	cmp    BYTE PTR [rsi+r15*1],0x0
  40bca4:	jne    40bc70 <__swc_fn_4fa09e82_000180_913db40c+0x350>
  40bca6:	cmp    BYTE PTR [rsi+r15*1],0x0
  40bcab:	jne    40bcd4 <__swc_fn_4fa09e82_000180_913db40c+0x3b4>
  40bcad:	mov    BYTE PTR [rsi+r15*1],0x1
  40bcb2:	mov    rax,QWORD PTR [rbx]
  40bcb5:	mov    QWORD PTR [rax+r15*8],rdi
  40bcb9:	mov    rax,QWORD PTR [rbx+0x8]
  40bcbd:	mov    QWORD PTR [rax+r15*8],r14
  40bcc1:	mov    rax,QWORD PTR [rbx+0x10]
  40bcc5:	mov    QWORD PTR [rax+r15*8],0x1
  40bccd:	add    QWORD PTR [rbx+0x30],0x1
  40bcd2:	jmp    40bcdc <__swc_fn_4fa09e82_000180_913db40c+0x3bc>
  40bcd4:	mov    rax,QWORD PTR [rbx+0x10]
  40bcd8:	inc    QWORD PTR [rax+r15*8]
  40bcdc:	xor    eax,eax
  40bcde:	inc    r12
  40bce1:	mov    r13,QWORD PTR [rsp+0x48]
  40bce6:	cmp    r12,r13
  40bce9:	jb     40bb90 <__swc_fn_4fa09e82_000180_913db40c+0x270>
  40bcef:	test   al,al
  40bcf1:	je     40be1b <__swc_fn_4fa09e82_000180_913db40c+0x4fb>
  40bcf7:	mov    r13,QWORD PTR [rsp+0x48]
  40bcfc:	sub    r13,rdi
  40bcff:	mov    eax,0x811c9dc5
  40bd04:	xor    ecx,ecx
  40bd06:	test   r13,r13
  40bd09:	jbe    40bd92 <__swc_fn_4fa09e82_000180_913db40c+0x472>
  40bd0f:	mov    rdx,QWORD PTR [rbx+0x20]
  40bd13:	add    rdx,rdi
  40bd16:	cmp    r13,0x4
  40bd1a:	jb     40bd80 <__swc_fn_4fa09e82_000180_913db40c+0x460>
  40bd20:	lea    r8,[r13-0x3]
  40bd24:	cs nop WORD PTR [rax+rax*1+0x0]
  40bd2e:	cs nop WORD PTR [rax+rax*1+0x0]
  40bd38:	nop    DWORD PTR [rax+rax*1+0x0]
  40bd40:	xor    al,BYTE PTR [rdx+rcx*1]
  40bd43:	imul   eax,eax,0x1000193
  40bd49:	xor    al,BYTE PTR [rdx+rcx*1+0x1]
  40bd4d:	imul   eax,eax,0x1000193
  40bd53:	xor    al,BYTE PTR [rdx+rcx*1+0x2]
  40bd57:	imul   eax,eax,0x1000193
  40bd5d:	xor    al,BYTE PTR [rdx+rcx*1+0x3]
  40bd61:	imul   eax,eax,0x1000193
  40bd67:	add    rcx,0x4
  40bd6b:	cmp    rcx,r8
  40bd6e:	jb     40bd40 <__swc_fn_4fa09e82_000180_913db40c+0x420>
  40bd70:	cmp    rcx,r13
  40bd73:	jae    40bd92 <__swc_fn_4fa09e82_000180_913db40c+0x472>
  40bd75:	cs nop WORD PTR [rax+rax*1+0x0]
  40bd7f:	nop
  40bd80:	xor    al,BYTE PTR [rdx+rcx*1]
  40bd83:	imul   eax,eax,0x1000193
  40bd89:	add    rcx,0x1
  40bd8d:	cmp    rcx,r13
  40bd90:	jb     40bd80 <__swc_fn_4fa09e82_000180_913db40c+0x460>
  40bd92:	mov    rsi,QWORD PTR [rsp+0x50]
  40bd97:	and    rax,QWORD PTR [rsi+0x28]
  40bd9b:	mov    r12,rax
  40bd9e:	mov    r14,QWORD PTR [rbx+0x18]
  40bda2:	mov    r15,QWORD PTR [rbx+0x8]
  40bda6:	cmp    BYTE PTR [r14+r12*1],0x0
  40bdab:	je     40bde5 <__swc_fn_4fa09e82_000180_913db40c+0x4c5>
  40bdad:	nop    DWORD PTR [rax]
  40bdb0:	cmp    QWORD PTR [r15+r12*8],r13
  40bdb4:	jne    40bdd7 <__swc_fn_4fa09e82_000180_913db40c+0x4b7>
  40bdb6:	mov    rax,QWORD PTR [rbx]
  40bdb9:	mov    rax,QWORD PTR [rax+r12*8]
  40bdbd:	mov    rcx,QWORD PTR [rbx+0x20]
  40bdc1:	add    rax,rcx
  40bdc4:	lea    rdx,[rcx+rdi*1]
  40bdc8:	mov    rcx,rax
  40bdcb:	mov    r8,r13
  40bdce:	call   410f30 <__swc_fn_4fa09e82_000107_ed4b1681>
  40bdd3:	test   eax,eax
  40bdd5:	je     40bde5 <__swc_fn_4fa09e82_000180_913db40c+0x4c5>
  40bdd7:	inc    r12
  40bdda:	and    r12,QWORD PTR [rbx+0x28]
  40bdde:	cmp    BYTE PTR [r14+r12*1],0x0
  40bde3:	jne    40bdb0 <__swc_fn_4fa09e82_000180_913db40c+0x490>
  40bde5:	cmp    BYTE PTR [r14+r12*1],0x0
  40bdea:	jne    40be13 <__swc_fn_4fa09e82_000180_913db40c+0x4f3>
  40bdec:	mov    BYTE PTR [r14+r12*1],0x1
  40bdf1:	mov    rax,QWORD PTR [rbx]
  40bdf4:	mov    QWORD PTR [rax+r12*8],rdi
  40bdf8:	mov    rax,QWORD PTR [rbx+0x8]
  40bdfc:	mov    QWORD PTR [rax+r12*8],r13
  40be00:	mov    rax,QWORD PTR [rbx+0x10]
  40be04:	mov    QWORD PTR [rax+r12*8],0x1
  40be0c:	add    QWORD PTR [rsi+0x30],0x1
  40be11:	jmp    40be1b <__swc_fn_4fa09e82_000180_913db40c+0x4fb>
  40be13:	mov    rax,QWORD PTR [rbx+0x10]
  40be17:	inc    QWORD PTR [rax+r12*8]
  40be1b:	mov    rsi,QWORD PTR [rbx+0x30]
  40be1f:	lea    rdi,[rsi*8+0x0]
  40be27:	mov    rcx,rdi
  40be2a:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  40be2f:	mov    QWORD PTR [rip+0x1af82],rax        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  40be36:	mov    rcx,rdi
  40be39:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  40be3e:	mov    QWORD PTR [rip+0x1af83],rax        # 426dc8 <__swc_bss_base_4fa09e82+0x2d88>
  40be45:	mov    rcx,rdi
  40be48:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  40be4d:	mov    QWORD PTR [rip+0x1af6c],rax        # 426dc0 <__swc_bss_base_4fa09e82+0x2d80>
  40be54:	mov    rcx,rdi
  40be57:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  40be5c:	mov    QWORD PTR [rip+0x1af4d],rax        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  40be63:	xor    ecx,ecx
  40be65:	xor    edx,edx
  40be67:	mov    r8,QWORD PTR [rip+0x1af4a]        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  40be6e:	mov    r9,QWORD PTR [rip+0x1af53]        # 426dc8 <__swc_bss_base_4fa09e82+0x2d88>
  40be75:	mov    r10,QWORD PTR [rip+0x1af44]        # 426dc0 <__swc_bss_base_4fa09e82+0x2d80>
  40be7c:	cs nop WORD PTR [rax+rax*1+0x0]
  40be86:	cs nop WORD PTR [rax+rax*1+0x0]
  40be90:	mov    r11,QWORD PTR [rbx+0x18]
  40be94:	cmp    BYTE PTR [r11+rdx*1],0x0
  40be99:	je     40bec5 <__swc_fn_4fa09e82_000180_913db40c+0x5a5>
  40be9b:	mov    r11,QWORD PTR [rbx+0x10]
  40be9f:	mov    r11,QWORD PTR [r11+rdx*8]
  40bea3:	mov    QWORD PTR [r8+rcx*8],r11
  40bea7:	mov    r11,QWORD PTR [rbx]
  40beaa:	mov    r11,QWORD PTR [r11+rdx*8]
  40beae:	mov    QWORD PTR [r9+rcx*8],r11
  40beb2:	mov    r11,QWORD PTR [rbx+0x8]
  40beb6:	mov    r11,QWORD PTR [r11+rdx*8]
  40beba:	mov    QWORD PTR [r10+rcx*8],r11
  40bebe:	mov    QWORD PTR [rax+rcx*8],rcx
  40bec2:	inc    rcx
  40bec5:	add    rdx,0x1
  40bec9:	cmp    rdx,0x4000
  40bed0:	jb     40be90 <__swc_fn_4fa09e82_000180_913db40c+0x570>
  40bed2:	xor    ecx,ecx
  40bed4:	lea    rdx,[rsi-0x1]
  40bed8:	call   4121b0 <__swc_fn_4fa09e82_000179_6937fe70>
  40bedd:	imul   rsi,rsi,0x7
  40bee1:	xor    eax,eax
  40bee3:	mov    rcx,QWORD PTR [rip+0x1aec6]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  40beea:	mov    rdx,QWORD PTR [rip+0x1aec7]        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  40bef1:	cs nop WORD PTR [rax+rax*1+0x0]
  40befb:	nop    DWORD PTR [rax+rax*1+0x0]
  40bf00:	lea    r8,[rax+0x1]
  40bf04:	mov    rax,QWORD PTR [rcx+rax*8]
  40bf08:	mov    r9,r8
  40bf0b:	imul   r9,QWORD PTR [rdx+rax*8]
  40bf10:	add    rsi,r9
  40bf13:	mov    rax,r8
  40bf16:	cmp    r8,0x14
  40bf1a:	jb     40bf00 <__swc_fn_4fa09e82_000180_913db40c+0x5e0>
  40bf1c:	call   40f2a0 <__swc_fn_4fa09e82_000178_1ca87929>
  40bf21:	vsubsd xmm0,xmm0,xmm6
  40bf25:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x7a9b]        # 4139c8 <__swc_rdata_base_4fa09e82+0x8b8>
  40bf2d:	lea    rax,[rip+0x7434]        # 413368 <__swc_rdata_base_4fa09e82+0x258>
  40bf34:	sub    rsp,0x88
  40bf3b:	mov    rcx,rsp
  40bf3e:	vmovups xmm1,XMMWORD PTR [rip+0x7a62]        # 4139a8 <__swc_rdata_base_4fa09e82+0x898>
  40bf46:	vmovups XMMWORD PTR [rcx],xmm1
  40bf4a:	mov    QWORD PTR [rcx+0x30],rsp
  40bf4e:	lea    rdx,[rip+0x73bb]        # 413310 <__swc_rdata_base_4fa09e82+0x200>
  40bf55:	mov    QWORD PTR [rcx+0x38],rdx
  40bf59:	mov    QWORD PTR [rcx+0x10],rsi
  40bf5d:	lea    r8,[rsp+0x10]
  40bf62:	mov    QWORD PTR [rcx+0x40],r8
  40bf66:	lea    r8,[rip+0x79ab]        # 413918 <__swc_rdata_base_4fa09e82+0x808>
  40bf6d:	mov    QWORD PTR [rcx+0x48],r8
  40bf71:	vmovups xmm1,XMMWORD PTR [rip+0x7a3f]        # 4139b8 <__swc_rdata_base_4fa09e82+0x8a8>
  40bf79:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40bf7e:	lea    r8,[rsp+0x18]
  40bf83:	mov    QWORD PTR [rcx+0x50],r8
  40bf87:	mov    QWORD PTR [rcx+0x58],rdx
  40bf8b:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40bf90:	lea    r8,[rcx+0x28]
  40bf94:	mov    QWORD PTR [rcx+0x60],r8
  40bf98:	lea    r8,[rip+0x79c1]        # 413960 <__swc_rdata_base_4fa09e82+0x850>
  40bf9f:	mov    QWORD PTR [rcx+0x68],r8
  40bfa3:	mov    QWORD PTR [rcx+0x70],rax
  40bfa7:	mov    QWORD PTR [rcx+0x78],rdx
  40bfab:	lea    rax,[rcx+0x30]
  40bfaf:	mov    QWORD PTR [rcx+0x80],rax
  40bfb6:	mov    QWORD PTR [rcx+0x88],0x5
  40bfc1:	lea    rcx,[rcx+0x80]
  40bfc8:	sub    rsp,0x8
  40bfcc:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  40bfd1:	add    rsp,0xe8
  40bfd8:	vmovups xmm6,XMMWORD PTR [rsp]
  40bfdd:	add    rsp,0x10
  40bfe1:	pop    r14
  40bfe3:	pop    r13
  40bfe5:	pop    r15
  40bfe7:	pop    r12
  40bfe9:	pop    rdi
  40bfea:	pop    rsi
  40bfeb:	pop    rbx
  40bfec:	pop    rbp
  40bfed:	ret
