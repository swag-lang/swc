
/workspace/prompt2-20261115/batch7-placement-micro/new/sort/sort:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xb00a]        # 412010 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <mmap@plt>:
  407010:	jmp    QWORD PTR [rip+0xb002]        # 412018 <mmap@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <mprotect@plt>:
  407020:	jmp    QWORD PTR [rip+0xaffa]        # 412020 <mprotect@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <munmap@plt>:
  407030:	jmp    QWORD PTR [rip+0xaff2]        # 412028 <munmap@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <madvise@plt>:
  407040:	jmp    QWORD PTR [rip+0xafea]        # 412030 <madvise@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <exit@plt>:
  407050:	jmp    QWORD PTR [rip+0xafe2]        # 412038 <exit@GLIBC_2.2.5>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_key_delete@plt>:
  407060:	jmp    QWORD PTR [rip+0xafda]        # 412040 <pthread_key_delete@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <gettid@plt>:
  407070:	jmp    QWORD PTR [rip+0xafd2]        # 412048 <gettid@GLIBC_2.30>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <syscall@plt>:
  407080:	jmp    QWORD PTR [rip+0xafca]        # 412050 <syscall@GLIBC_2.2.5>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <malloc@plt>:
  407090:	jmp    QWORD PTR [rip+0xafc2]        # 412058 <malloc@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <open@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xafba]        # 412060 <open@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <flock@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xafb2]        # 412068 <flock@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <__errno_location@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xafaa]        # 412070 <__errno_location@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <close@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xafa2]        # 412078 <close@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <getpid@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xaf9a]        # 412080 <getpid@GLIBC_2.2.5>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <opendir@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xaf92]        # 412088 <opendir@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <dirfd@plt>:
  407100:	jmp    QWORD PTR [rip+0xaf8a]        # 412090 <dirfd@GLIBC_2.2.5>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <readdir@plt>:
  407110:	jmp    QWORD PTR [rip+0xaf82]        # 412098 <readdir@GLIBC_2.2.5>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <readlinkat@plt>:
  407120:	jmp    QWORD PTR [rip+0xaf7a]        # 4120a0 <readlinkat@GLIBC_2.4>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <openat@plt>:
  407130:	jmp    QWORD PTR [rip+0xaf72]        # 4120a8 <openat@GLIBC_2.4>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <closedir@plt>:
  407140:	jmp    QWORD PTR [rip+0xaf6a]        # 4120b0 <closedir@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <lseek@plt>:
  407150:	jmp    QWORD PTR [rip+0xaf62]        # 4120b8 <lseek@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <memfd_create@plt>:
  407160:	jmp    QWORD PTR [rip+0xaf5a]        # 4120c0 <memfd_create@GLIBC_2.27>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <ftruncate@plt>:
  407170:	jmp    QWORD PTR [rip+0xaf52]        # 4120c8 <ftruncate@GLIBC_2.2.5>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <write@plt>:
  407180:	jmp    QWORD PTR [rip+0xaf4a]        # 4120d0 <write@GLIBC_2.2.5>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <backtrace@plt>:
  407190:	jmp    QWORD PTR [rip+0xaf42]        # 4120d8 <backtrace@GLIBC_2.2.5>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <pthread_setspecific@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xaf3a]        # 4120e0 <pthread_setspecific@GLIBC_2.34>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <clock_gettime@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xaf32]        # 4120e8 <clock_gettime@GLIBC_2.17>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <__x86_get_cpuid_feature_leaf@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xaf2a]        # 4120f0 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <free@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xaf22]        # 4120f8 <free@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <pthread_key_create@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xaf1a]        # 412100 <pthread_key_create@GLIBC_2.34>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <dladdr@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xaf12]        # 412108 <dladdr@GLIBC_2.34>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xaddf]        # 412000 <__swc_fn_ff58629f_000179_718d7b54+0x310>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   409ac0 <__swc_fn_ff58629f_000126_540bf7e8>
  40724e:	xor    ecx,ecx
  407250:	call   4091e0 <__swc_fn_ff58629f_000099_4f209617>
  407255:	call   40a700 <__swc_fn_ff58629f_000004_05d3c06b>
  40725a:	call   40c210 <__swc_fn_ff58629f_000100_65137b72>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_ff58629f_000000_2744b483>:
  407270:	push   rbx
  407271:	sub    rsp,0x70
  407275:	cmp    rcx,0xffffffffffffffef
  407279:	jbe    407283 <__swc_fn_ff58629f_000000_2744b483+0x13>
  40727b:	xor    eax,eax
  40727d:	add    rsp,0x70
  407281:	pop    rbx
  407282:	ret
  407283:	vxorps xmm0,xmm0,xmm0
  407287:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40728d:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  407293:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  407299:	vzeroupper
  40729c:	lea    rax,[rcx+0x10]
  4072a0:	mov    QWORD PTR [rsp+0x50],rax
  4072a5:	mov    DWORD PTR [rsp+0x60],0x10
  4072ad:	mov    rcx,QWORD PTR [rip+0x1bd8c]        # 423040 <__swc_bss_base_ff58629f>
  4072b4:	test   rcx,rcx
  4072b7:	jne    4072c9 <__swc_fn_ff58629f_000000_2744b483+0x59>
  4072b9:	call   411bc0 <__swc_fn_ff58629f_000170_994c8876>
  4072be:	lea    rcx,[rax+0x1]
  4072c2:	mov    QWORD PTR [rip+0x1bd77],rcx        # 423040 <__swc_bss_base_ff58629f>
  4072c9:	dec    rcx
  4072cc:	call   40ea20 <__swc_fn_ff58629f_000172_360af05d>
  4072d1:	mov    rcx,QWORD PTR [rax]
  4072d4:	lea    rdx,[rsp+0x8]
  4072d9:	mov    rbx,QWORD PTR [rax+0x8]
  4072dd:	mov    rbx,QWORD PTR [rbx+0x8]
  4072e1:	call   rbx
  4072e3:	mov    rax,QWORD PTR [rsp+0x48]
  4072e8:	test   rax,rax
  4072eb:	jne    4072f5 <__swc_fn_ff58629f_000000_2744b483+0x85>
  4072ed:	xor    eax,eax
  4072ef:	add    rsp,0x70
  4072f3:	pop    rbx
  4072f4:	ret
  4072f5:	mov    rcx,QWORD PTR [rsp+0x50]
  4072fa:	mov    QWORD PTR [rax],rcx
  4072fd:	mov    QWORD PTR [rax+0x8],0x0
  407305:	lea    rax,[rax+0x10]
  407309:	add    rsp,0x70
  40730d:	pop    rbx
  40730e:	ret
	...

0000000000407320 <__swc_fn_ff58629f_000003_2a1d71b4>:
  407320:	push   rsi
  407321:	push   rdi
  407322:	push   r12
  407324:	mov    rsi,rcx
  407327:	mov    rdi,rdx
  40732a:	mov    r12,r8
  40732d:	cs nop WORD PTR [rax+rax*1+0x0]
  407337:	nop    WORD PTR [rax+rax*1+0x0]
  407340:	mov    rax,r12
  407343:	sub    rax,rdi
  407346:	cmp    rax,0x10
  40734a:	jle    407429 <__swc_fn_ff58629f_000003_2a1d71b4+0x109>
  407350:	shr    rax,1
  407353:	lea    rcx,[rdi+rax*1]
  407357:	mov    rax,QWORD PTR [rsi+rcx*8]
  40735b:	mov    rdx,QWORD PTR [rsi+rdi*8]
  40735f:	cmp    rax,rdx
  407362:	jae    40736f <__swc_fn_ff58629f_000003_2a1d71b4+0x4f>
  407364:	mov    QWORD PTR [rsi+rdi*8],rax
  407368:	mov    QWORD PTR [rsi+rcx*8],rdx
  40736c:	mov    rdx,rax
  40736f:	mov    rax,QWORD PTR [rsi+r12*8]
  407373:	cmp    rax,rdx
  407376:	jae    407383 <__swc_fn_ff58629f_000003_2a1d71b4+0x63>
  407378:	mov    QWORD PTR [rsi+rdi*8],rax
  40737c:	mov    QWORD PTR [rsi+r12*8],rdx
  407380:	mov    rax,rdx
  407383:	mov    rdx,QWORD PTR [rsi+rcx*8]
  407387:	cmp    rax,rdx
  40738a:	jae    407394 <__swc_fn_ff58629f_000003_2a1d71b4+0x74>
  40738c:	mov    QWORD PTR [rsi+rcx*8],rax
  407390:	mov    QWORD PTR [rsi+r12*8],rdx
  407394:	mov    rax,QWORD PTR [rsi+rcx*8]
  407398:	mov    r9,rdi
  40739b:	mov    r10,r12
  40739e:	xchg   ax,ax
  4073a0:	cmp    QWORD PTR [rsi+r9*8],rax
  4073a4:	jae    4073ba <__swc_fn_ff58629f_000003_2a1d71b4+0x9a>
  4073a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4073b0:	add    r9,0x1
  4073b4:	cmp    QWORD PTR [rsi+r9*8],rax
  4073b8:	jb     4073b0 <__swc_fn_ff58629f_000003_2a1d71b4+0x90>
  4073ba:	cmp    QWORD PTR [rsi+r10*8],rax
  4073be:	jbe    4073ca <__swc_fn_ff58629f_000003_2a1d71b4+0xaa>
  4073c0:	sub    r10,0x1
  4073c4:	cmp    QWORD PTR [rsi+r10*8],rax
  4073c8:	ja     4073c0 <__swc_fn_ff58629f_000003_2a1d71b4+0xa0>
  4073ca:	cmp    r9,r10
  4073cd:	jg     4073ec <__swc_fn_ff58629f_000003_2a1d71b4+0xcc>
  4073cf:	mov    rcx,QWORD PTR [rsi+r9*8]
  4073d3:	mov    rdx,QWORD PTR [rsi+r10*8]
  4073d7:	mov    QWORD PTR [rsi+r9*8],rdx
  4073db:	mov    QWORD PTR [rsi+r10*8],rcx
  4073df:	add    r9,0x1
  4073e3:	sub    r10,0x1
  4073e7:	cmp    r9,r10
  4073ea:	jle    4073a0 <__swc_fn_ff58629f_000003_2a1d71b4+0x80>
  4073ec:	mov    rax,r10
  4073ef:	sub    rax,rdi
  4073f2:	mov    rcx,r12
  4073f5:	sub    rcx,r9
  4073f8:	cmp    rax,rcx
  4073fb:	jge    407413 <__swc_fn_ff58629f_000003_2a1d71b4+0xf3>
  4073fd:	mov    rcx,rsi
  407400:	mov    rdx,rdi
  407403:	mov    r8,r10
  407406:	mov    rdi,r9
  407409:	call   407320 <__swc_fn_ff58629f_000003_2a1d71b4>
  40740e:	jmp    407340 <__swc_fn_ff58629f_000003_2a1d71b4+0x20>
  407413:	mov    rcx,rsi
  407416:	mov    rdx,r9
  407419:	mov    r8,r12
  40741c:	mov    r12,r10
  40741f:	call   407320 <__swc_fn_ff58629f_000003_2a1d71b4>
  407424:	jmp    407340 <__swc_fn_ff58629f_000003_2a1d71b4+0x20>
  407429:	lea    rax,[rdi+0x1]
  40742d:	cmp    rax,r12
  407430:	jg     407473 <__swc_fn_ff58629f_000003_2a1d71b4+0x153>
  407432:	cs nop WORD PTR [rax+rax*1+0x0]
  40743c:	nop    DWORD PTR [rax+0x0]
  407440:	mov    rcx,QWORD PTR [rsi+rax*8]
  407444:	lea    rdx,[rax-0x1]
  407448:	cmp    rdx,rdi
  40744b:	jl     407466 <__swc_fn_ff58629f_000003_2a1d71b4+0x146>
  40744d:	nop    DWORD PTR [rax]
  407450:	mov    r8,QWORD PTR [rsi+rdx*8]
  407454:	cmp    r8,rcx
  407457:	jbe    407466 <__swc_fn_ff58629f_000003_2a1d71b4+0x146>
  407459:	mov    QWORD PTR [rsi+rdx*8+0x8],r8
  40745e:	dec    rdx
  407461:	cmp    rdx,rdi
  407464:	jge    407450 <__swc_fn_ff58629f_000003_2a1d71b4+0x130>
  407466:	mov    QWORD PTR [rsi+rdx*8+0x8],rcx
  40746b:	inc    rax
  40746e:	cmp    rax,r12
  407471:	jle    407440 <__swc_fn_ff58629f_000003_2a1d71b4+0x120>
  407473:	pop    r12
  407475:	pop    rdi
  407476:	pop    rsi
  407477:	ret
	...

0000000000407480 <__swc_fn_ff58629f_000006_9ee35b18>:
  407480:	vxorps xmm0,xmm0,xmm0
  407484:	xor    eax,eax
  407486:	cs nop WORD PTR [rax+rax*1+0x0]
  407490:	cs nop WORD PTR [rax+rax*1+0x0]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  4074a5:	add    rax,0x10
  4074a9:	cmp    rax,0x2080
  4074b0:	jne    4074a0 <__swc_fn_ff58629f_000006_9ee35b18+0x20>
  4074b2:	ret
	...

00000000004074c0 <__swc_fn_ff58629f_000009_d64b2baa>:
  4074c0:	push   rsi
  4074c1:	push   rdi
  4074c2:	push   r12
  4074c4:	push   r13
  4074c6:	push   r14
  4074c8:	mov    rsi,rcx
  4074cb:	mov    edi,r10d
  4074ce:	mov    r12,rcx
  4074d1:	mov    r13,r9
  4074d4:	mov    ecx,DWORD PTR [rdx+0x28]
  4074d7:	shlx   r14d,r8d,ecx
  4074dc:	mov    rcx,rdx
  4074df:	mov    edx,r8d
  4074e2:	call   40aac0 <__swc_fn_ff58629f_000016_9dea5065>
  4074e7:	mov    rcx,rax
  4074ea:	mov    eax,DWORD PTR [r12+0x3c]
  4074ef:	xor    edx,edx
  4074f1:	div    rdi
  4074f4:	vxorps xmm0,xmm0,xmm0
  4074f8:	vmovdqu XMMWORD PTR [rsi],xmm0
  4074fc:	mov    QWORD PTR [r12+0x60],0x0
  407505:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40750a:	mov    QWORD PTR [r12+0x10],rcx
  40750f:	imul   rax,rdi
  407513:	lea    rdx,[rcx+rax*1]
  407517:	mov    QWORD PTR [r12+0x18],rdx
  40751c:	mov    QWORD PTR [r12+0x20],rcx
  407521:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  407526:	mov    DWORD PTR [r12+0x28],0x0
  40752f:	mov    DWORD PTR [r12+0x68],0x0
  407538:	mov    BYTE PTR [r12+0x39],r13b
  40753d:	mov    BYTE PTR [r12+0x3a],r14b
  407542:	mov    BYTE PTR [r12+0x3b],0x1
  407548:	mov    DWORD PTR [r12+0x6c],0x0
  407551:	mov    rcx,r12
  407554:	mov    edx,edi
  407556:	call   40aa20 <__swc_fn_ff58629f_000010_065ed5b1>
  40755b:	pop    r14
  40755d:	pop    r13
  40755f:	pop    r12
  407561:	pop    rdi
  407562:	pop    rsi
  407563:	ret
	...

0000000000407570 <__swc_fn_ff58629f_000012_c3647f66>:
  407570:	mov    r8d,0x1
  407576:	xor    eax,eax
  407578:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40757e:	test   eax,eax
  407580:	jne    407570 <__swc_fn_ff58629f_000012_c3647f66>
  407582:	ret
	...

0000000000407590 <__swc_fn_ff58629f_000015_524c1f23>:
  407590:	lea    r8,[rcx+0x60]
  407594:	mov    rax,QWORD PTR [r8]
  407597:	mov    r9,rax
  40759a:	nop    WORD PTR [rax+rax*1+0x0]
  4075a0:	mov    QWORD PTR [rdx],r9
  4075a3:	mov    rax,r9
  4075a6:	lock cmpxchg QWORD PTR [r8],rdx
  4075ab:	cmp    rax,r9
  4075ae:	jne    407617 <__swc_fn_ff58629f_000015_524c1f23+0x87>
  4075b0:	mov    eax,DWORD PTR [rcx+0x6c]
  4075b3:	test   eax,eax
  4075b5:	je     407616 <__swc_fn_ff58629f_000015_524c1f23+0x86>
  4075b7:	lea    rdx,[rcx+0x70]
  4075bb:	mov    r9d,0x1
  4075c1:	xor    eax,eax
  4075c3:	lock cmpxchg DWORD PTR [rdx],r9d
  4075c8:	test   eax,eax
  4075ca:	jne    407616 <__swc_fn_ff58629f_000015_524c1f23+0x86>
  4075cc:	mov    rax,rcx
  4075cf:	and    rax,0xffffffffffc00000
  4075d6:	mov    rax,QWORD PTR [rax+0x8]
  4075da:	test   rax,rax
  4075dd:	jne    4075e5 <__swc_fn_ff58629f_000015_524c1f23+0x55>
  4075df:	xor    eax,eax
  4075e1:	xchg   DWORD PTR [rdx],eax
  4075e3:	jmp    407616 <__swc_fn_ff58629f_000015_524c1f23+0x86>
  4075e5:	lea    rdx,[rax+0x2a80]
  4075ec:	mov    rax,QWORD PTR [rdx]
  4075ef:	mov    r8,rax
  4075f2:	cs nop WORD PTR [rax+rax*1+0x0]
  4075fc:	nop    DWORD PTR [rax+0x0]
  407600:	mov    QWORD PTR [rcx+0x78],r8
  407604:	mov    rax,r8
  407607:	lock cmpxchg QWORD PTR [rdx],rcx
  40760c:	cmp    rax,r8
  40760f:	je     407616 <__swc_fn_ff58629f_000015_524c1f23+0x86>
  407611:	mov    r8,rax
  407614:	jmp    407600 <__swc_fn_ff58629f_000015_524c1f23+0x70>
  407616:	ret
  407617:	mov    r9,rax
  40761a:	jmp    4075a0 <__swc_fn_ff58629f_000015_524c1f23+0x10>
	...

0000000000407620 <__swc_fn_ff58629f_000018_efc44797>:
  407620:	push   rsi
  407621:	push   rdi
  407622:	push   r12
  407624:	push   r13
  407626:	push   r14
  407628:	push   r15
  40762a:	push   rbx
  40762b:	sub    rsp,0x30
  40762f:	mov    QWORD PTR [rsp+0x18],r8
  407634:	mov    rsi,rcx
  407637:	mov    rdi,rdx
  40763a:	mov    rdx,QWORD PTR [rsi+0x40]
  40763e:	xchg   ax,ax
  407640:	mov    rax,rdx
  407643:	not    rax
  407646:	and    rax,QWORD PTR [rsi+0x20]
  40764a:	test   rax,rax
  40764d:	jne    407661 <__swc_fn_ff58629f_000018_efc44797+0x41>
  40764f:	xor    eax,eax
  407651:	add    rsp,0x30
  407655:	pop    rbx
  407656:	pop    r15
  407658:	pop    r14
  40765a:	pop    r13
  40765c:	pop    r12
  40765e:	pop    rdi
  40765f:	pop    rsi
  407660:	ret
  407661:	xor    ecx,ecx
  407663:	tzcnt  rcx,rax
  407668:	lea    r12,[rsp+0x8]
  40766d:	mov    DWORD PTR [rsp+0x8],ecx
  407671:	mov    r13d,0x1
  407677:	shl    r13,cl
  40767a:	mov    rcx,rdx
  40767d:	or     rcx,r13
  407680:	mov    rax,rdx
  407683:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  407689:	cmp    rax,rdx
  40768c:	je     407693 <__swc_fn_ff58629f_000018_efc44797+0x73>
  40768e:	mov    rdx,rax
  407691:	jmp    407640 <__swc_fn_ff58629f_000018_efc44797+0x20>
  407693:	mov    eax,DWORD PTR [r12]
  407697:	shl    rax,0x4
  40769b:	lea    r14,[rsi+rax*8+0x80]
  4076a3:	mov    rcx,rsi
  4076a6:	mov    rax,r12
  4076a9:	mov    edx,DWORD PTR [rax]
  4076ab:	call   40aac0 <__swc_fn_ff58629f_000016_9dea5065>
  4076b0:	mov    r15,rax
  4076b3:	mov    rcx,rsi
  4076b6:	mov    rdx,r13
  4076b9:	call   40ac20 <__swc_fn_ff58629f_000022_fd2b165c>
  4076be:	test   al,al
  4076c0:	je     4076f8 <__swc_fn_ff58629f_000018_efc44797+0xd8>
  4076c2:	mov    ecx,DWORD PTR [r14+0x3c]
  4076c6:	lea    rdx,[rip+0x1b993]        # 423060 <__swc_bss_base_ff58629f+0x20>
  4076cd:	mov    r8,QWORD PTR [rip+0x1b98c]        # 423060 <__swc_bss_base_ff58629f+0x20>
  4076d4:	cs nop WORD PTR [rax+rax*1+0x0]
  4076de:	xchg   ax,ax
  4076e0:	mov    r9,r8
  4076e3:	sub    r9,rcx
  4076e6:	mov    rax,r8
  4076e9:	lock cmpxchg QWORD PTR [rdx],r9
  4076ee:	cmp    rax,r8
  4076f1:	je     407759 <__swc_fn_ff58629f_000018_efc44797+0x139>
  4076f3:	mov    r8,rax
  4076f6:	jmp    4076e0 <__swc_fn_ff58629f_000018_efc44797+0xc0>
  4076f8:	mov    rcx,rsi
  4076fb:	mov    rax,r12
  4076fe:	mov    edx,DWORD PTR [rax]
  407700:	call   40ee80 <__swc_fn_ff58629f_000017_9afb7cfb>
  407705:	mov    rcx,r15
  407708:	and    rcx,0xffffffffffff0000
  40770f:	lea    rcx,[rcx+0x10000]
  407716:	mov    rbx,rax
  407719:	cmp    rax,rcx
  40771c:	cmova  rbx,rcx
  407720:	mov    rax,rbx
  407723:	sub    rax,r15
  407726:	mov    rcx,r15
  407729:	mov    rdx,rax
  40772c:	call   40ecd0 <__swc_fn_ff58629f_000008_f7acedb0>
  407731:	test   al,al
  407733:	jne    407752 <__swc_fn_ff58629f_000018_efc44797+0x132>
  407735:	mov    rcx,rsi
  407738:	mov    rdx,r13
  40773b:	call   40f030 <__swc_fn_ff58629f_000023_c8f5f27c>
  407740:	xor    eax,eax
  407742:	add    rsp,0x30
  407746:	pop    rbx
  407747:	pop    r15
  407749:	pop    r14
  40774b:	pop    r13
  40774d:	pop    r12
  40774f:	pop    rdi
  407750:	pop    rsi
  407751:	ret
  407752:	sub    rbx,r15
  407755:	mov    DWORD PTR [r14+0x3c],ebx
  407759:	mov    rcx,r14
  40775c:	mov    rdx,rsi
  40775f:	mov    r8d,DWORD PTR [r12]
  407763:	mov    r9d,edi
  407766:	mov    rbx,QWORD PTR [rsp+0x18]
  40776b:	mov    r10d,ebx
  40776e:	call   4074c0 <__swc_fn_ff58629f_000009_d64b2baa>
  407773:	mov    rax,r14
  407776:	add    rsp,0x30
  40777a:	pop    rbx
  40777b:	pop    r15
  40777d:	pop    r14
  40777f:	pop    r13
  407781:	pop    r12
  407783:	pop    rdi
  407784:	pop    rsi
  407785:	ret
	...

0000000000407790 <__swc_fn_ff58629f_000021_de02dbdf>:
  407790:	mov    r8,QWORD PTR [rcx+0x48]
  407794:	cs nop WORD PTR [rax+rax*1+0x0]
  40779e:	xchg   ax,ax
  4077a0:	mov    r9,r8
  4077a3:	or     r9,rdx
  4077a6:	mov    rax,r8
  4077a9:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  4077af:	cmp    rax,r8
  4077b2:	jne    4077b5 <__swc_fn_ff58629f_000021_de02dbdf+0x25>
  4077b4:	ret
  4077b5:	mov    r8,rax
  4077b8:	jmp    4077a0 <__swc_fn_ff58629f_000021_de02dbdf+0x10>
  4077ba:	add    BYTE PTR [rax],al
  4077bc:	add    BYTE PTR [rax],al
	...

00000000004077c0 <__swc_fn_ff58629f_000024_2d0fcd2c>:
  4077c0:	push   rsi
  4077c1:	push   rdi
  4077c2:	push   r12
  4077c4:	mov    rsi,rcx
  4077c7:	xor    edi,edi
  4077c9:	lea    r12,[rip+0x1b8a0]        # 423070 <__swc_bss_base_ff58629f+0x30>
  4077d0:	mov    eax,DWORD PTR [r12]
  4077d4:	xor    ecx,ecx
  4077d6:	test   rax,rax
  4077d9:	jbe    407814 <__swc_fn_ff58629f_000024_2d0fcd2c+0x54>
  4077db:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	lea    rdx,[rip+0x1b891]        # 423078 <__swc_bss_base_ff58629f+0x38>
  4077e7:	mov    r8d,ecx
  4077ea:	lea    r8,[r8+r8*2]
  4077ee:	lea    r8,[rdx+r8*8]
  4077f2:	mov    rdx,QWORD PTR [r8+0x10]
  4077f6:	add    rdx,0x400000
  4077fd:	cmp    rdx,0x40000000
  407804:	ja     40780b <__swc_fn_ff58629f_000024_2d0fcd2c+0x4b>
  407806:	mov    rdi,r8
  407809:	jmp    407814 <__swc_fn_ff58629f_000024_2d0fcd2c+0x54>
  40780b:	add    rcx,0x1
  40780f:	cmp    rcx,rax
  407812:	jb     4077e0 <__swc_fn_ff58629f_000024_2d0fcd2c+0x20>
  407814:	test   rdi,rdi
  407817:	jne    4078a3 <__swc_fn_ff58629f_000024_2d0fcd2c+0xe3>
  40781d:	cmp    DWORD PTR [r12],0x10
  407822:	jae    40788b <__swc_fn_ff58629f_000024_2d0fcd2c+0xcb>
  407824:	mov    ecx,0x40400000
  407829:	call   40a9e0 <__swc_fn_ff58629f_000007_81d2e1e9>
  40782e:	test   rax,rax
  407831:	je     40788b <__swc_fn_ff58629f_000024_2d0fcd2c+0xcb>
  407833:	lea    rcx,[rip+0x1b83e]        # 423078 <__swc_bss_base_ff58629f+0x38>
  40783a:	mov    edx,DWORD PTR [r12]
  40783e:	lea    rdx,[rdx+rdx*2]
  407842:	lea    rdx,[rcx+rdx*8]
  407846:	mov    QWORD PTR [rdx],rax
  407849:	lea    rax,[rax+0x3fffff]
  407850:	and    rax,0xffffffffffc00000
  407857:	mov    QWORD PTR [rdx+0x8],rax
  40785b:	mov    QWORD PTR [rdx+0x10],0x0
  407863:	mov    edx,DWORD PTR [rip+0x1b807]        # 423070 <__swc_bss_base_ff58629f+0x30>
  407869:	nop    DWORD PTR [rax+0x0]
  407870:	lea    r9d,[rdx+0x1]
  407874:	mov    rax,rdx
  407877:	lock cmpxchg DWORD PTR [r12],r9d
  40787d:	mov    r8d,eax
  407880:	cmp    eax,edx
  407882:	je     407892 <__swc_fn_ff58629f_000024_2d0fcd2c+0xd2>
  407884:	mov    rdx,r8
  407887:	jmp    407870 <__swc_fn_ff58629f_000024_2d0fcd2c+0xb0>
  407889:	jmp    407892 <__swc_fn_ff58629f_000024_2d0fcd2c+0xd2>
  40788b:	xor    eax,eax
  40788d:	pop    r12
  40788f:	pop    rdi
  407890:	pop    rsi
  407891:	ret
  407892:	mov    eax,DWORD PTR [rip+0x1b7d8]        # 423070 <__swc_bss_base_ff58629f+0x30>
  407898:	sub    eax,0x1
  40789b:	lea    rdi,[rax+rax*2]
  40789f:	lea    rdi,[rcx+rdi*8]
  4078a3:	mov    r12,QWORD PTR [rdi+0x8]
  4078a7:	add    r12,QWORD PTR [rdi+0x10]
  4078ab:	mov    rcx,r12
  4078ae:	mov    edx,0x3000
  4078b3:	call   40ecd0 <__swc_fn_ff58629f_000008_f7acedb0>
  4078b8:	test   al,al
  4078ba:	jne    4078c3 <__swc_fn_ff58629f_000024_2d0fcd2c+0x103>
  4078bc:	xor    eax,eax
  4078be:	pop    r12
  4078c0:	pop    rdi
  4078c1:	pop    rsi
  4078c2:	ret
  4078c3:	vxorps xmm0,xmm0,xmm0
  4078c7:	xor    eax,eax
  4078c9:	cs nop WORD PTR [rax+rax*1+0x0]
  4078d3:	cs nop WORD PTR [rax+rax*1+0x0]
  4078dd:	nop    DWORD PTR [rax]
  4078e0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  4078e6:	add    rax,0x10
  4078ea:	cmp    rax,0x3000
  4078f1:	jne    4078e0 <__swc_fn_ff58629f_000024_2d0fcd2c+0x120>
  4078f3:	mov    DWORD PTR [r12+0x28],esi
  4078f8:	mov    eax,0x40
  4078fd:	mov    ecx,esi
  4078ff:	shr    eax,cl
  407901:	mov    DWORD PTR [r12+0x2c],eax
  407906:	cmp    DWORD PTR [r12+0x2c],0x40
  40790c:	jb     407917 <__swc_fn_ff58629f_000024_2d0fcd2c+0x157>
  40790e:	mov    rax,0xffffffffffffffff
  407915:	jmp    407927 <__swc_fn_ff58629f_000024_2d0fcd2c+0x167>
  407917:	mov    eax,0x1
  40791c:	mov    ecx,DWORD PTR [r12+0x2c]
  407921:	shl    rax,cl
  407924:	dec    rax
  407927:	mov    QWORD PTR [r12+0x20],rax
  40792c:	mov    DWORD PTR [r12],0x4e540001
  407934:	mov    DWORD PTR [r12+0x4],0x53474d45
  40793d:	add    QWORD PTR [rdi+0x10],0x400000
  407945:	mov    rax,r12
  407948:	pop    r12
  40794a:	pop    rdi
  40794b:	pop    rsi
  40794c:	ret
  40794d:	add    BYTE PTR [rax],al
	...

0000000000407950 <__swc_fn_ff58629f_000027_bcdc5519>:
  407950:	mov    eax,0x1
  407955:	mov    edx,DWORD PTR [rip+0x1b715]        # 423070 <__swc_bss_base_ff58629f+0x30>
  40795b:	cmp    eax,edx
  40795d:	jae    4079ab <__swc_fn_ff58629f_000027_bcdc5519+0x5b>
  40795f:	nop
  407960:	lea    r8,[rip+0x1b711]        # 423078 <__swc_bss_base_ff58629f+0x38>
  407967:	lea    r9,[rax+rax*2]
  40796b:	lea    r9,[r8+r9*8]
  40796f:	mov    r8,rcx
  407972:	sub    r8,QWORD PTR [r9+0x8]
  407976:	mov    r9,QWORD PTR [r9+0x10]
  40797a:	cmp    r8,r9
  40797d:	jae    4079a5 <__swc_fn_ff58629f_000027_bcdc5519+0x55>
  40797f:	mov    rax,rcx
  407982:	and    rax,0xffffffffffc00000
  407989:	shr    rcx,0x10
  40798d:	and    ecx,0x3f
  407990:	mov    edx,DWORD PTR [rax+0x28]
  407993:	shrx   ecx,ecx,edx
  407998:	shl    rcx,0x4
  40799c:	lea    rax,[rax+rcx*8+0x80]
  4079a4:	ret
  4079a5:	inc    eax
  4079a7:	cmp    eax,edx
  4079a9:	jb     407960 <__swc_fn_ff58629f_000027_bcdc5519+0x10>
  4079ab:	xor    eax,eax
  4079ad:	ret
	...

00000000004079b0 <__swc_fn_ff58629f_000030_9798fb47>:
  4079b0:	vxorps xmm0,xmm0,xmm0
  4079b4:	vmovups XMMWORD PTR [rcx],xmm0
  4079b8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4079bd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4079c2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4079c7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  4079cc:	mov    QWORD PTR [rcx+0x50],0x0
  4079d4:	ret
	...

00000000004079e0 <__swc_fn_ff58629f_000033_9798fb47>:
  4079e0:	vxorps xmm0,xmm0,xmm0
  4079e4:	xor    eax,eax
  4079e6:	cs nop WORD PTR [rax+rax*1+0x0]
  4079f0:	cs nop WORD PTR [rax+rax*1+0x0]
  4079fa:	nop    WORD PTR [rax+rax*1+0x0]
  407a00:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  407a05:	add    rax,0x10
  407a09:	cmp    rax,0x9b0
  407a10:	jne    407a00 <__swc_fn_ff58629f_000033_9798fb47+0x20>
  407a12:	mov    QWORD PTR [rcx+0x9b0],0x0
  407a1d:	ret
	...

0000000000407a20 <__swc_fn_ff58629f_000036_cd1a4e8c>:
  407a20:	push   rsi
  407a21:	push   rdi
  407a22:	sub    rsp,0x8
  407a26:	lea    rsi,[rip+0x195e3]        # 421010 <__swc_data_base_ff58629f+0x10>
  407a2d:	mov    rax,QWORD PTR [rsi]
  407a30:	mov    ecx,0xffffffff
  407a35:	cmp    rax,rcx
  407a38:	je     407a41 <__swc_fn_ff58629f_000036_cd1a4e8c+0x21>
  407a3a:	add    rsp,0x8
  407a3e:	pop    rdi
  407a3f:	pop    rsi
  407a40:	ret
  407a41:	mov    rcx,QWORD PTR [rip+0xa5c0]        # 412008 <__swc_fn_ff58629f_000179_718d7b54+0x318>
  407a48:	call   411070 <__swc_fn_ff58629f_000131_4a82cdf6>
  407a4d:	mov    rcx,rax
  407a50:	mov    eax,0xffffffff
  407a55:	lock cmpxchg QWORD PTR [rsi],rcx
  407a5a:	mov    rdi,rax
  407a5d:	mov    eax,0xffffffff
  407a62:	cmp    rdi,rax
  407a65:	je     407a76 <__swc_fn_ff58629f_000036_cd1a4e8c+0x56>
  407a67:	call   409c50 <__swc_fn_ff58629f_000132_a611b8c4>
  407a6c:	mov    rax,rdi
  407a6f:	add    rsp,0x8
  407a73:	pop    rdi
  407a74:	pop    rsi
  407a75:	ret
  407a76:	mov    rax,rcx
  407a79:	add    rsp,0x8
  407a7d:	pop    rdi
  407a7e:	pop    rsi
  407a7f:	ret

0000000000407a80 <__swc_fn_ff58629f_000039_14f56618>:
  407a80:	sub    rsp,0x8
  407a84:	vxorps xmm0,xmm0,xmm0
  407a88:	xor    eax,eax
  407a8a:	cs nop WORD PTR [rax+rax*1+0x0]
  407a94:	cs nop WORD PTR [rax+rax*1+0x0]
  407a9e:	xchg   ax,ax
  407aa0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  407aa5:	add    rax,0x10
  407aa9:	cmp    rax,0x2b00
  407ab0:	jne    407aa0 <__swc_fn_ff58629f_000039_14f56618+0x20>
  407ab2:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  407abc:	xor    al,al
  407abe:	mov    rdx,rax
  407ac1:	xor    al,al
  407ac3:	mov    r8,rax
  407ac6:	xor    al,al
  407ac8:	mov    r9,rax
  407acb:	xor    al,al
  407acd:	mov    r10,rax
  407ad0:	xor    al,al
  407ad2:	mov    r11,rax
  407ad5:	call   40ae50 <__swc_fn_ff58629f_000040_03f1bf9a>
  407ada:	add    rsp,0x8
  407ade:	ret
	...

0000000000407ae0 <__swc_fn_ff58629f_000042_c90d80c1>:
  407ae0:	push   rsi
  407ae1:	push   rdi
  407ae2:	push   r12
  407ae4:	mov    rsi,r8
  407ae7:	mov    rdi,rdx
  407aea:	mov    rcx,rdx
  407aed:	call   40a9e0 <__swc_fn_ff58629f_000007_81d2e1e9>
  407af2:	mov    r12,rax
  407af5:	test   rax,rax
  407af8:	jne    407b01 <__swc_fn_ff58629f_000042_c90d80c1+0x21>
  407afa:	xor    eax,eax
  407afc:	pop    r12
  407afe:	pop    rdi
  407aff:	pop    rsi
  407b00:	ret
  407b01:	mov    rcx,r12
  407b04:	mov    rdx,rsi
  407b07:	call   40ecd0 <__swc_fn_ff58629f_000008_f7acedb0>
  407b0c:	test   al,al
  407b0e:	jne    407b22 <__swc_fn_ff58629f_000042_c90d80c1+0x42>
  407b10:	mov    rcx,r12
  407b13:	mov    rdx,rdi
  407b16:	call   40cc50 <__swc_fn_ff58629f_000118_ed2d8fed>
  407b1b:	xor    eax,eax
  407b1d:	pop    r12
  407b1f:	pop    rdi
  407b20:	pop    rsi
  407b21:	ret
  407b22:	mov    rax,r12
  407b25:	pop    r12
  407b27:	pop    rdi
  407b28:	pop    rsi
  407b29:	ret
	...

0000000000407b40 <__swc_fn_ff58629f_000045_a78ae66b>:
  407b40:	push   rsi
  407b41:	push   rdi
  407b42:	push   r12
  407b44:	mov    rsi,rcx
  407b47:	mov    edx,0x9b8
  407b4c:	call   40aec0 <__swc_fn_ff58629f_000043_facd3e17>
  407b51:	mov    rdi,rax
  407b54:	test   rax,rax
  407b57:	jne    407b60 <__swc_fn_ff58629f_000045_a78ae66b+0x20>
  407b59:	xor    eax,eax
  407b5b:	pop    r12
  407b5d:	pop    rdi
  407b5e:	pop    rsi
  407b5f:	ret
  407b60:	vxorps xmm0,xmm0,xmm0
  407b64:	xor    eax,eax
  407b66:	cs nop WORD PTR [rax+rax*1+0x0]
  407b70:	cs nop WORD PTR [rax+rax*1+0x0]
  407b7a:	nop    WORD PTR [rax+rax*1+0x0]
  407b80:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  407b85:	add    rax,0x10
  407b89:	cmp    rax,0x9b0
  407b90:	jne    407b80 <__swc_fn_ff58629f_000045_a78ae66b+0x40>
  407b92:	mov    QWORD PTR [rdi+0x9b0],0x0
  407b9d:	mov    QWORD PTR [rdi],rsi
  407ba0:	call   409d00 <__swc_fn_ff58629f_000135_a9c1c700>
  407ba5:	mov    QWORD PTR [rdi+0x18],rax
  407ba9:	lea    r12,[rsi+0x10]
  407bad:	mov    rcx,r12
  407bb0:	call   4112c0 <__swc_fn_ff58629f_000140_86bb0f90>
  407bb5:	mov    rax,QWORD PTR [rsi+0x20]
  407bb9:	mov    QWORD PTR [rdi+0x8],rax
  407bbd:	mov    rax,QWORD PTR [rsi+0x20]
  407bc1:	test   rax,rax
  407bc4:	je     407bca <__swc_fn_ff58629f_000045_a78ae66b+0x8a>
  407bc6:	mov    QWORD PTR [rax+0x10],rdi
  407bca:	mov    QWORD PTR [rsi+0x20],rdi
  407bce:	mov    rcx,r12
  407bd1:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  407bd6:	mov    rax,rdi
  407bd9:	pop    r12
  407bdb:	pop    rdi
  407bdc:	pop    rsi
  407bdd:	ret
	...

0000000000407be0 <__swc_fn_ff58629f_000048_6e7a8d58>:
  407be0:	mov    rax,QWORD PTR [rdx+0x10]
  407be4:	test   rax,rax
  407be7:	je     407bf3 <__swc_fn_ff58629f_000048_6e7a8d58+0x13>
  407be9:	mov    rcx,QWORD PTR [rdx+0x8]
  407bed:	mov    QWORD PTR [rax+0x8],rcx
  407bf1:	jmp    407bfb <__swc_fn_ff58629f_000048_6e7a8d58+0x1b>
  407bf3:	mov    rax,QWORD PTR [rdx+0x8]
  407bf7:	mov    QWORD PTR [rcx+0x20],rax
  407bfb:	mov    rax,QWORD PTR [rdx+0x8]
  407bff:	test   rax,rax
  407c02:	je     407c0c <__swc_fn_ff58629f_000048_6e7a8d58+0x2c>
  407c04:	mov    rcx,QWORD PTR [rdx+0x10]
  407c08:	mov    QWORD PTR [rax+0x10],rcx
  407c0c:	vxorps xmm0,xmm0,xmm0
  407c10:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  407c15:	ret
	...

0000000000407c20 <__swc_fn_ff58629f_000051_129b9bf4>:
  407c20:	sub    rsp,0x8
  407c24:	mov    r9,r8
  407c27:	mov    r10,rdx
  407c2a:	call   40af70 <__swc_fn_ff58629f_000049_137687bb>
  407c2f:	mov    eax,0x1
  407c34:	xchg   DWORD PTR [r9+0x6c],eax
  407c38:	mov    rax,QWORD PTR [r9+0x60]
  407c3c:	test   rax,rax
  407c3f:	je     407c83 <__swc_fn_ff58629f_000051_129b9bf4+0x63>
  407c41:	xor    eax,eax
  407c43:	xchg   DWORD PTR [r9+0x6c],eax
  407c47:	movzx  eax,BYTE PTR [r9+0x39]
  407c4c:	lea    rax,[rax+rax*4]
  407c50:	lea    rax,[r10+rax*8+0x28]
  407c55:	mov    QWORD PTR [r9+0x50],0x0
  407c5d:	mov    rcx,QWORD PTR [rax+0x8]
  407c61:	mov    QWORD PTR [r9+0x48],rcx
  407c65:	mov    rcx,QWORD PTR [rax+0x8]
  407c69:	test   rcx,rcx
  407c6c:	je     407c74 <__swc_fn_ff58629f_000051_129b9bf4+0x54>
  407c6e:	mov    QWORD PTR [rcx+0x50],r9
  407c72:	jmp    407c78 <__swc_fn_ff58629f_000051_129b9bf4+0x58>
  407c74:	mov    QWORD PTR [rax+0x10],r9
  407c78:	mov    QWORD PTR [rax+0x8],r9
  407c7c:	xor    eax,eax
  407c7e:	add    rsp,0x8
  407c82:	ret
  407c83:	movzx  eax,BYTE PTR [r9+0x39]
  407c88:	lea    rax,[rax+rax*4]
  407c8c:	lea    rax,[r10+rax*8+0x28]
  407c91:	mov    QWORD PTR [r9+0x50],0x0
  407c99:	mov    rcx,QWORD PTR [rax+0x18]
  407c9d:	mov    QWORD PTR [r9+0x48],rcx
  407ca1:	mov    rcx,QWORD PTR [rax+0x18]
  407ca5:	test   rcx,rcx
  407ca8:	je     407cae <__swc_fn_ff58629f_000051_129b9bf4+0x8e>
  407caa:	mov    QWORD PTR [rcx+0x50],r9
  407cae:	mov    QWORD PTR [rax+0x18],r9
  407cb2:	mov    eax,0x1
  407cb7:	add    rsp,0x8
  407cbb:	ret
  407cbc:	add    BYTE PTR [rax],al
	...

0000000000407cc0 <__swc_fn_ff58629f_000054_3af34d7f>:
  407cc0:	push   r12
  407cc2:	push   r13
  407cc4:	push   rdi
  407cc5:	push   rsi
  407cc6:	push   r14
  407cc8:	push   r15
  407cca:	sub    rsp,0x178
  407cd1:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  407cda:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  407ce3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  407cec:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  407cf5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  407cfe:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  407d07:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  407d10:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  407d19:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  407d22:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  407d2b:	mov    r12,rcx
  407d2e:	lea    rax,[rip+0x1b4d3]        # 423208 <__swc_bss_base_ff58629f+0x1c8>
  407d35:	mov    rcx,QWORD PTR [rax]
  407d38:	mov    r13,rcx
  407d3b:	test   rcx,rcx
  407d3e:	jne    407d4e <__swc_fn_ff58629f_000054_3af34d7f+0x8e>
  407d40:	mov    r13d,0x1dcd6500
  407d46:	mov    ecx,0x1dcd6500
  407d4b:	xchg   QWORD PTR [rax],rcx
  407d4e:	lea    rax,[rip+0x192b3]        # 421008 <__swc_data_base_ff58629f+0x8>
  407d55:	mov    rax,QWORD PTR [rax]
  407d58:	cmp    rax,0xffffffffffffffff
  407d5c:	je     407d6b <__swc_fn_ff58629f_000054_3af34d7f+0xab>
  407d5e:	mov    eax,eax
  407d60:	mov    edi,eax
  407d62:	xor    eax,eax
  407d64:	call   407000 <pthread_getspecific@plt>
  407d69:	jmp    407d6d <__swc_fn_ff58629f_000054_3af34d7f+0xad>
  407d6b:	xor    eax,eax
  407d6d:	test   rax,rax
  407d70:	jne    407d7f <__swc_fn_ff58629f_000054_3af34d7f+0xbf>
  407d72:	call   407a20 <__swc_fn_ff58629f_000036_cd1a4e8c>
  407d77:	mov    rcx,rax
  407d7a:	call   40cfa0 <__swc_fn_ff58629f_000133_5f757033>
  407d7f:	test   rax,rax
  407d82:	je     407d94 <__swc_fn_ff58629f_000054_3af34d7f+0xd4>
  407d84:	cmp    QWORD PTR [rax],r12
  407d87:	jne    407d94 <__swc_fn_ff58629f_000054_3af34d7f+0xd4>
  407d89:	cmp    DWORD PTR [rax+0x20],0x0
  407d8d:	jne    407d94 <__swc_fn_ff58629f_000054_3af34d7f+0xd4>
  407d8f:	mov    rsi,rax
  407d92:	jmp    407d96 <__swc_fn_ff58629f_000054_3af34d7f+0xd6>
  407d94:	xor    esi,esi
  407d96:	lea    rdi,[r12+0x2a88]
  407d9e:	mov    r14,QWORD PTR [rdi]
  407da1:	test   r14,r14
  407da4:	jne    407df3 <__swc_fn_ff58629f_000054_3af34d7f+0x133>
  407da6:	lea    rax,[rip+0x1b2b3]        # 423060 <__swc_bss_base_ff58629f+0x20>
  407dad:	mov    rax,QWORD PTR [rax]
  407db0:	test   rax,rax
  407db3:	setne  al
  407db6:	jne    407dda <__swc_fn_ff58629f_000054_3af34d7f+0x11a>
  407db8:	mov    rax,QWORD PTR [r12+0x2a70]
  407dc0:	test   rax,rax
  407dc3:	setne  al
  407dc6:	jne    407dda <__swc_fn_ff58629f_000054_3af34d7f+0x11a>
  407dc8:	test   rsi,rsi
  407dcb:	setne  al
  407dce:	je     407dda <__swc_fn_ff58629f_000054_3af34d7f+0x11a>
  407dd0:	cmp    DWORD PTR [rsi+0x730],0x0
  407dd7:	setne  al
  407dda:	test   al,al
  407ddc:	je     407dee <__swc_fn_ff58629f_000054_3af34d7f+0x12e>
  407dde:	call   40d050 <__swc_fn_ff58629f_000136_07d76562>
  407de3:	lea    rcx,[rax+r13*1]
  407de7:	xor    eax,eax
  407de9:	lock cmpxchg QWORD PTR [rdi],rcx
  407dee:	jmp    407ef3 <__swc_fn_ff58629f_000054_3af34d7f+0x233>
  407df3:	call   40d050 <__swc_fn_ff58629f_000136_07d76562>
  407df8:	mov    r15,rax
  407dfb:	cmp    rax,r14
  407dfe:	jb     407e0f <__swc_fn_ff58629f_000054_3af34d7f+0x14f>
  407e00:	xor    ecx,ecx
  407e02:	mov    rax,r14
  407e05:	lock cmpxchg QWORD PTR [rdi],rcx
  407e0a:	cmp    rax,r14
  407e0d:	je     407e14 <__swc_fn_ff58629f_000054_3af34d7f+0x154>
  407e0f:	jmp    407ef3 <__swc_fn_ff58629f_000054_3af34d7f+0x233>
  407e14:	test   rsi,rsi
  407e17:	je     407e32 <__swc_fn_ff58629f_000054_3af34d7f+0x172>
  407e19:	cmp    r15,r13
  407e1c:	jb     407e32 <__swc_fn_ff58629f_000054_3af34d7f+0x172>
  407e1e:	mov    rax,r15
  407e21:	sub    rax,r13
  407e24:	mov    rcx,r12
  407e27:	mov    rdx,rsi
  407e2a:	mov    r8,rax
  407e2d:	call   40b3b0 <__swc_fn_ff58629f_000064_dea90857>
  407e32:	lea    rsi,[r12+0x10]
  407e37:	mov    rcx,rsi
  407e3a:	call   4112c0 <__swc_fn_ff58629f_000140_86bb0f90>
  407e3f:	mov    rax,QWORD PTR [r12+0x18]
  407e44:	mov    rdi,rax
  407e47:	test   rdi,rdi
  407e4a:	je     407e74 <__swc_fn_ff58629f_000054_3af34d7f+0x1b4>
  407e4c:	cs nop WORD PTR [rax+rax*1+0x0]
  407e56:	cs nop WORD PTR [rax+rax*1+0x0]
  407e60:	mov    rcx,rdi
  407e63:	call   40eea0 <__swc_fn_ff58629f_000020_adca76cf>
  407e68:	mov    rax,QWORD PTR [rdi+0x10]
  407e6c:	mov    rdi,rax
  407e6f:	test   rax,rax
  407e72:	jne    407e60 <__swc_fn_ff58629f_000054_3af34d7f+0x1a0>
  407e74:	mov    rcx,rsi
  407e77:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  407e7c:	mov    rcx,r12
  407e7f:	call   4112c0 <__swc_fn_ff58629f_000140_86bb0f90>
  407e84:	xor    esi,esi
  407e86:	cs nop WORD PTR [rax+rax*1+0x0]
  407e90:	mov    rax,QWORD PTR [r12+0x2a70]
  407e98:	cmp    rsi,rax
  407e9b:	jae    407eeb <__swc_fn_ff58629f_000054_3af34d7f+0x22b>
  407e9d:	lea    rax,[rsi+rsi*4]
  407ea1:	lea    rax,[r12+rax*8+0x268]
  407ea9:	mov    r8,QWORD PTR [rax]
  407eac:	mov    r9,QWORD PTR [rax+0x8]
  407eb0:	mov    r10,QWORD PTR [rax+0x10]
  407eb4:	mov    rax,QWORD PTR [rax+0x20]
  407eb8:	cmp    rax,r15
  407ebb:	jae    407ec8 <__swc_fn_ff58629f_000054_3af34d7f+0x208>
  407ebd:	mov    rcx,r15
  407ec0:	sub    rcx,rax
  407ec3:	cmp    rcx,r13
  407ec6:	jae    407ecd <__swc_fn_ff58629f_000054_3af34d7f+0x20d>
  407ec8:	inc    rsi
  407ecb:	jmp    407e90 <__swc_fn_ff58629f_000054_3af34d7f+0x1d0>
  407ecd:	mov    rcx,r12
  407ed0:	mov    rdx,rsi
  407ed3:	call   40b360 <__swc_fn_ff58629f_000061_15c28ca7>
  407ed8:	mov    rcx,r12
  407edb:	mov    rdx,r8
  407ede:	mov    r8,r9
  407ee1:	mov    r9,r10
  407ee4:	call   40f180 <__swc_fn_ff58629f_000044_d3c2ab54>
  407ee9:	jmp    407e90 <__swc_fn_ff58629f_000054_3af34d7f+0x1d0>
  407eeb:	mov    rcx,r12
  407eee:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  407ef3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  407efc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  407f05:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  407f0e:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  407f17:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  407f20:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  407f29:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  407f32:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  407f3b:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  407f44:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  407f4d:	add    rsp,0x178
  407f54:	pop    r15
  407f56:	pop    r14
  407f58:	pop    rsi
  407f59:	pop    rdi
  407f5a:	pop    r13
  407f5c:	pop    r12
  407f5e:	ret
	...

0000000000407f60 <__swc_fn_ff58629f_000057_df0696cd>:
  407f60:	lea    rax,[rdx-0x58]
  407f64:	ret
	...

0000000000407f70 <__swc_fn_ff58629f_000060_2ca0cb05>:
  407f70:	push   rsi
  407f71:	push   rdi
  407f72:	push   r12
  407f74:	push   r13
  407f76:	sub    rsp,0x68
  407f7a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  407f80:	mov    rsi,r9
  407f83:	mov    rdi,rcx
  407f86:	mov    r12,rdx
  407f89:	mov    r13,r8
  407f8c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  407f94:	jne    407fa3 <__swc_fn_ff58629f_000060_2ca0cb05+0x33>
  407f96:	xor    eax,eax
  407f98:	add    rsp,0x68
  407f9c:	pop    r13
  407f9e:	pop    r12
  407fa0:	pop    rdi
  407fa1:	pop    rsi
  407fa2:	ret
  407fa3:	mov    rcx,rdi
  407fa6:	call   4112c0 <__swc_fn_ff58629f_000140_86bb0f90>
  407fab:	movabs rax,0x7fffffffffffffff
  407fb5:	cmp    r12,rax
  407fb8:	mov    rax,0xffffffffffffffff
  407fbf:	lea    rcx,[r12+r12*1]
  407fc3:	cmovbe rax,rcx
  407fc7:	mov    rcx,QWORD PTR [rdi+0x2a70]
  407fce:	mov    rdx,rcx
  407fd1:	sub    rax,r12
  407fd4:	inc    rax
  407fd7:	xor    r8d,r8d
  407fda:	test   rcx,rcx
  407fdd:	jbe    408008 <__swc_fn_ff58629f_000060_2ca0cb05+0x98>
  407fdf:	nop
  407fe0:	lea    r9,[r8+r8*4]
  407fe4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  407fec:	sub    r9,r12
  407fef:	cmp    r9,rax
  407ff2:	jae    407fff <__swc_fn_ff58629f_000060_2ca0cb05+0x8f>
  407ff4:	mov    rdx,r8
  407ff7:	mov    rax,r9
  407ffa:	test   r9,r9
  407ffd:	je     408008 <__swc_fn_ff58629f_000060_2ca0cb05+0x98>
  407fff:	add    r8,0x1
  408003:	cmp    r8,rcx
  408006:	jb     407fe0 <__swc_fn_ff58629f_000060_2ca0cb05+0x70>
  408008:	mov    rax,QWORD PTR [rdi+0x2a70]
  40800f:	cmp    rdx,rax
  408012:	jne    40802f <__swc_fn_ff58629f_000060_2ca0cb05+0xbf>
  408014:	mov    rcx,rdi
  408017:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40801c:	xor    eax,eax
  40801e:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  408024:	add    rsp,0x68
  408028:	pop    r13
  40802a:	pop    r12
  40802c:	pop    rdi
  40802d:	pop    rsi
  40802e:	ret
  40802f:	lea    rax,[rdx+rdx*4]
  408033:	lea    rax,[rdi+rax*8+0x268]
  40803b:	vmovups xmm6,XMMWORD PTR [rax]
  40803f:	mov    r8,QWORD PTR [rax+0x10]
  408043:	mov    rcx,rdi
  408046:	call   40b360 <__swc_fn_ff58629f_000061_15c28ca7>
  40804b:	vpshufd xmm0,xmm6,0xee
  408050:	vmovsd QWORD PTR [r13+0x0],xmm0
  408056:	mov    QWORD PTR [rsi],r8
  408059:	mov    rcx,rdi
  40805c:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  408061:	vmovq  rax,xmm6
  408066:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40806c:	add    rsp,0x68
  408070:	pop    r13
  408072:	pop    r12
  408074:	pop    rdi
  408075:	pop    rsi
  408076:	ret
	...

0000000000408080 <__swc_fn_ff58629f_000063_b304235a>:
  408080:	push   r12
  408082:	push   r13
  408084:	push   r14
  408086:	push   r15
  408088:	push   rdi
  408089:	push   rsi
  40808a:	sub    rsp,0x148
  408091:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40809a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  4080a3:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  4080ac:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  4080b5:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  4080be:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4080c7:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4080d0:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4080d9:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  4080e2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  4080eb:	mov    r12,r9
  4080ee:	mov    r13,rcx
  4080f1:	mov    r14,rdx
  4080f4:	mov    r15,r8
  4080f7:	test   rdx,rdx
  4080fa:	jne    40810e <__swc_fn_ff58629f_000063_b304235a+0x8e>
  4080fc:	add    rsp,0x148
  408103:	pop    rsi
  408104:	pop    rdi
  408105:	pop    r15
  408107:	pop    r14
  408109:	pop    r13
  40810b:	pop    r12
  40810d:	ret
  40810e:	cmp    r12,0x200000
  408115:	ja     4081a7 <__swc_fn_ff58629f_000063_b304235a+0x127>
  40811b:	lea    rax,[rip+0x18ee6]        # 421008 <__swc_data_base_ff58629f+0x8>
  408122:	mov    rax,QWORD PTR [rax]
  408125:	cmp    rax,0xffffffffffffffff
  408129:	je     408138 <__swc_fn_ff58629f_000063_b304235a+0xb8>
  40812b:	mov    eax,eax
  40812d:	mov    edi,eax
  40812f:	xor    eax,eax
  408131:	call   407000 <pthread_getspecific@plt>
  408136:	jmp    40813a <__swc_fn_ff58629f_000063_b304235a+0xba>
  408138:	xor    eax,eax
  40813a:	test   rax,rax
  40813d:	je     408144 <__swc_fn_ff58629f_000063_b304235a+0xc4>
  40813f:	mov    rsi,rax
  408142:	jmp    408154 <__swc_fn_ff58629f_000063_b304235a+0xd4>
  408144:	call   407a20 <__swc_fn_ff58629f_000036_cd1a4e8c>
  408149:	mov    rcx,rax
  40814c:	call   40cfa0 <__swc_fn_ff58629f_000133_5f757033>
  408151:	mov    rsi,rax
  408154:	test   rsi,rsi
  408157:	je     4081a7 <__swc_fn_ff58629f_000063_b304235a+0x127>
  408159:	cmp    QWORD PTR [rsi],r13
  40815c:	jne    4081a7 <__swc_fn_ff58629f_000063_b304235a+0x127>
  40815e:	cmp    DWORD PTR [rsi+0x20],0x0
  408162:	jne    4081a7 <__swc_fn_ff58629f_000063_b304235a+0x127>
  408164:	cmp    DWORD PTR [rsi+0x730],0x10
  40816b:	jae    4081a7 <__swc_fn_ff58629f_000063_b304235a+0x127>
  40816d:	mov    eax,DWORD PTR [rsi+0x730]
  408173:	lea    rdi,[rax+rax*4]
  408177:	lea    rdi,[rsi+rdi*8+0x738]
  40817f:	mov    QWORD PTR [rdi],r14
  408182:	mov    QWORD PTR [rdi+0x8],r15
  408186:	mov    QWORD PTR [rdi+0x10],r12
  40818a:	mov    QWORD PTR [rdi+0x18],0x0
  408192:	call   40d050 <__swc_fn_ff58629f_000136_07d76562>
  408197:	mov    QWORD PTR [rdi+0x20],rax
  40819b:	add    DWORD PTR [rsi+0x730],0x1
  4081a2:	jmp    408306 <__swc_fn_ff58629f_000063_b304235a+0x286>
  4081a7:	mov    rcx,r13
  4081aa:	call   40f8b0 <__swc_fn_ff58629f_000062_ad030a10>
  4081af:	mov    rsi,rax
  4081b2:	cmp    r12,rax
  4081b5:	jbe    4081ea <__swc_fn_ff58629f_000063_b304235a+0x16a>
  4081b7:	cmp    r12,0x10000000
  4081be:	seta   al
  4081c1:	ja     4081d0 <__swc_fn_ff58629f_000063_b304235a+0x150>
  4081c3:	mov    rax,QWORD PTR [r13+0x2a70]
  4081ca:	test   rax,rax
  4081cd:	setne  al
  4081d0:	test   al,al
  4081d2:	je     4081ea <__swc_fn_ff58629f_000063_b304235a+0x16a>
  4081d4:	mov    rcx,r13
  4081d7:	mov    rdx,r14
  4081da:	mov    r8,r15
  4081dd:	mov    r9,r12
  4081e0:	call   40f180 <__swc_fn_ff58629f_000044_d3c2ab54>
  4081e5:	jmp    408306 <__swc_fn_ff58629f_000063_b304235a+0x286>
  4081ea:	call   40d050 <__swc_fn_ff58629f_000136_07d76562>
  4081ef:	mov    rdi,rax
  4081f2:	mov    rcx,r13
  4081f5:	call   4112c0 <__swc_fn_ff58629f_000140_86bb0f90>
  4081fa:	cmp    QWORD PTR [r13+0x2a70],0x0
  408202:	je     4082ba <__swc_fn_ff58629f_000063_b304235a+0x23a>
  408208:	nop    DWORD PTR [rax+rax*1+0x0]
  408210:	cmp    QWORD PTR [r13+0x2a70],0x100
  40821b:	jae    408230 <__swc_fn_ff58629f_000063_b304235a+0x1b0>
  40821d:	mov    rax,QWORD PTR [r13+0x2a68]
  408224:	add    rax,r12
  408227:	cmp    rax,rsi
  40822a:	jbe    4082ba <__swc_fn_ff58629f_000063_b304235a+0x23a>
  408230:	xor    eax,eax
  408232:	mov    rcx,QWORD PTR [r13+0x2a70]
  408239:	mov    edx,0x1
  40823e:	cmp    rcx,0x1
  408242:	jbe    408279 <__swc_fn_ff58629f_000063_b304235a+0x1f9>
  408244:	cs nop WORD PTR [rax+rax*1+0x0]
  40824e:	xchg   ax,ax
  408250:	lea    r8,[rdx+rdx*4]
  408254:	lea    r8,[r13+r8*8+0x268]
  40825c:	lea    r9,[rax+rax*4]
  408260:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  408268:	cmp    QWORD PTR [r8+0x18],r9
  40826c:	cmovb  rax,rdx
  408270:	add    rdx,0x1
  408274:	cmp    rdx,rcx
  408277:	jb     408250 <__swc_fn_ff58629f_000063_b304235a+0x1d0>
  408279:	lea    rcx,[rax+rax*4]
  40827d:	lea    rcx,[r13+rcx*8+0x268]
  408285:	mov    r8,QWORD PTR [rcx]
  408288:	mov    r9,QWORD PTR [rcx+0x8]
  40828c:	mov    r10,QWORD PTR [rcx+0x10]
  408290:	mov    rcx,r13
  408293:	mov    rdx,rax
  408296:	call   40b360 <__swc_fn_ff58629f_000061_15c28ca7>
  40829b:	mov    rcx,r13
  40829e:	mov    rdx,r8
  4082a1:	mov    r8,r9
  4082a4:	mov    r9,r10
  4082a7:	call   40f180 <__swc_fn_ff58629f_000044_d3c2ab54>
  4082ac:	cmp    QWORD PTR [r13+0x2a70],0x0
  4082b4:	jne    408210 <__swc_fn_ff58629f_000063_b304235a+0x190>
  4082ba:	add    QWORD PTR [r13+0x2a78],0x1
  4082c2:	mov    rax,QWORD PTR [r13+0x2a70]
  4082c9:	lea    rax,[rax+rax*4]
  4082cd:	lea    rax,[r13+rax*8+0x268]
  4082d5:	mov    QWORD PTR [rax],r14
  4082d8:	mov    QWORD PTR [rax+0x8],r15
  4082dc:	mov    QWORD PTR [rax+0x10],r12
  4082e0:	mov    rcx,QWORD PTR [r13+0x2a78]
  4082e7:	mov    QWORD PTR [rax+0x18],rcx
  4082eb:	mov    QWORD PTR [rax+0x20],rdi
  4082ef:	add    QWORD PTR [r13+0x2a68],r12
  4082f6:	add    QWORD PTR [r13+0x2a70],0x1
  4082fe:	mov    rcx,r13
  408301:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  408306:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40830f:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  408318:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  408321:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40832a:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  408333:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40833c:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  408345:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40834e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  408357:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  408360:	add    rsp,0x148
  408367:	pop    rsi
  408368:	pop    rdi
  408369:	pop    r15
  40836b:	pop    r14
  40836d:	pop    r13
  40836f:	pop    r12
  408371:	ret
	...

0000000000408380 <__swc_fn_ff58629f_000066_d9ee99ea>:
  408380:	push   rbx
  408381:	push   r12
  408383:	push   r13
  408385:	push   r14
  408387:	push   r15
  408389:	push   rdi
  40838a:	push   rsi
  40838b:	sub    rsp,0xf0
  408392:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  408398:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40839e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  4083a4:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  4083aa:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  4083b3:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  4083bc:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  4083c5:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  4083ce:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  4083d7:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  4083e0:	mov    eax,r8d
  4083e3:	mov    rbx,rcx
  4083e6:	mov    r12,rdx
  4083e9:	mov    QWORD PTR [rsp+0x18],rdx
  4083ee:	mov    ecx,DWORD PTR [r12+0x58]
  4083f3:	mov    r13d,ecx
  4083f6:	cmp    ecx,0x10
  4083f9:	mov    ecx,0x10
  4083fe:	cmovb  r13d,ecx
  408402:	test   r13d,r13d
  408405:	mov    rcx,r13
  408408:	mov    edx,0x8
  40840d:	cmove  ecx,edx
  408410:	dec    rcx
  408413:	mov    rdx,0xffffffffffffffff
  40841a:	sub    rdx,rcx
  40841d:	xor    r14d,r14d
  408420:	mov    r8,rcx
  408423:	not    r8
  408426:	lea    rcx,[rcx+0x58]
  40842a:	and    rcx,r8
  40842d:	cmp    rdx,0x58
  408431:	cmovae r14,rcx
  408435:	cmp    eax,0xffffffff
  408438:	jne    408441 <__swc_fn_ff58629f_000066_d9ee99ea+0xc1>
  40843a:	mov    r15,QWORD PTR [r12+0x48]
  40843f:	jmp    408473 <__swc_fn_ff58629f_000066_d9ee99ea+0xf3>
  408441:	test   eax,eax
  408443:	jne    40844c <__swc_fn_ff58629f_000066_d9ee99ea+0xcc>
  408445:	mov    eax,0x8
  40844a:	jmp    408470 <__swc_fn_ff58629f_000066_d9ee99ea+0xf0>
  40844c:	cmp    eax,0x8
  40844f:	ja     408457 <__swc_fn_ff58629f_000066_d9ee99ea+0xd7>
  408451:	shl    rax,0x4
  408455:	jmp    408470 <__swc_fn_ff58629f_000066_d9ee99ea+0xf0>
  408457:	lea    eax,[rax-0x9]
  40845a:	mov    ecx,eax
  40845c:	shr    ecx,0x2
  40845f:	and    eax,0x3
  408462:	lea    ecx,[rcx+0x7]
  408465:	lea    ecx,[rcx-0x2]
  408468:	lea    eax,[rax+0x5]
  40846b:	shlx   rax,rax,rcx
  408470:	mov    r15,rax
  408473:	lea    rax,[r14+r13*1]
  408477:	mov    rcx,0xffffffffffffffff
  40847e:	sub    rcx,rax
  408481:	cmp    r15,rcx
  408484:	jbe    408494 <__swc_fn_ff58629f_000066_d9ee99ea+0x114>
  408486:	mov    QWORD PTR [r12+0x40],0x0
  40848f:	jmp    408866 <__swc_fn_ff58629f_000066_d9ee99ea+0x4e6>
  408494:	mov    QWORD PTR [rsp+0x20],r13
  408499:	lea    r13,[rsp+0x8]
  40849e:	add    rax,r15
  4084a1:	mov    ecx,0x1000
  4084a6:	test   ecx,ecx
  4084a8:	mov    edx,0x8
  4084ad:	cmove  ecx,edx
  4084b0:	dec    rcx
  4084b3:	mov    rdx,0xffffffffffffffff
  4084ba:	sub    rdx,rcx
  4084bd:	cmp    rax,rdx
  4084c0:	jbe    4084cc <__swc_fn_ff58629f_000066_d9ee99ea+0x14c>
  4084c2:	mov    QWORD PTR [r13+0x0],0x0
  4084ca:	jmp    4084d9 <__swc_fn_ff58629f_000066_d9ee99ea+0x159>
  4084cc:	add    rax,rcx
  4084cf:	andn   rax,rcx,rax
  4084d4:	mov    QWORD PTR [rsp+0x8],rax
  4084d9:	cmp    QWORD PTR [r13+0x0],0x0
  4084de:	jne    4084ee <__swc_fn_ff58629f_000066_d9ee99ea+0x16e>
  4084e0:	mov    QWORD PTR [r12+0x40],0x0
  4084e9:	jmp    408866 <__swc_fn_ff58629f_000066_d9ee99ea+0x4e6>
  4084ee:	mov    QWORD PTR [rsp+0x30],r15
  4084f3:	xor    r15d,r15d
  4084f6:	mov    QWORD PTR [rsp+0x38],0x0
  4084ff:	lea    r12,[rsp+0x10]
  408504:	mov    QWORD PTR [rsp+0x28],r14
  408509:	mov    r14,QWORD PTR [rsp+0x8]
  40850e:	mov    QWORD PTR [rsp+0x10],r14
  408513:	cmp    r14,0x10000
  40851a:	ja     408521 <__swc_fn_ff58629f_000066_d9ee99ea+0x1a1>
  40851c:	mov    rax,r14
  40851f:	jmp    408572 <__swc_fn_ff58629f_000066_d9ee99ea+0x1f2>
  408521:	xor    eax,eax
  408523:	lea    rcx,[r14-0x1]
  408527:	lzcnt  rax,rcx
  40852c:	mov    ecx,0x3f
  408531:	sub    rcx,rax
  408534:	mov    eax,0x1
  408539:	lea    rcx,[rcx-0x3]
  40853d:	shl    rax,cl
  408540:	mov    rcx,rax
  408543:	cmp    rax,0x1000
  40854a:	mov    eax,0x1000
  40854f:	cmovb  rcx,rax
  408553:	mov    rdx,0xffffffffffffffff
  40855a:	sub    rdx,rcx
  40855d:	mov    rax,r14
  408560:	lea    r8,[r14+rcx*1-0x1]
  408565:	neg    rcx
  408568:	and    r8,rcx
  40856b:	cmp    r14,rdx
  40856e:	cmovbe rax,r8
  408572:	mov    QWORD PTR [rsp+0x8],rax
  408577:	lea    rax,[rip+0x18a8a]        # 421008 <__swc_data_base_ff58629f+0x8>
  40857e:	mov    rax,QWORD PTR [rax]
  408581:	cmp    rax,0xffffffffffffffff
  408585:	je     408594 <__swc_fn_ff58629f_000066_d9ee99ea+0x214>
  408587:	mov    eax,eax
  408589:	mov    edi,eax
  40858b:	xor    eax,eax
  40858d:	call   407000 <pthread_getspecific@plt>
  408592:	jmp    408596 <__swc_fn_ff58629f_000066_d9ee99ea+0x216>
  408594:	xor    eax,eax
  408596:	test   rax,rax
  408599:	jne    4085a8 <__swc_fn_ff58629f_000066_d9ee99ea+0x228>
  40859b:	call   407a20 <__swc_fn_ff58629f_000036_cd1a4e8c>
  4085a0:	mov    rcx,rax
  4085a3:	call   40cfa0 <__swc_fn_ff58629f_000133_5f757033>
  4085a8:	test   rax,rax
  4085ab:	je     40869c <__swc_fn_ff58629f_000066_d9ee99ea+0x31c>
  4085b1:	cmp    QWORD PTR [rax],rbx
  4085b4:	jne    40869c <__swc_fn_ff58629f_000066_d9ee99ea+0x31c>
  4085ba:	cmp    DWORD PTR [rax+0x20],0x0
  4085be:	jne    40869c <__swc_fn_ff58629f_000066_d9ee99ea+0x31c>
  4085c4:	mov    rcx,QWORD PTR [rsp+0x8]
  4085c9:	movabs rdx,0x7fffffffffffffff
  4085d3:	cmp    rcx,rdx
  4085d6:	mov    rdx,0xffffffffffffffff
  4085dd:	lea    r8,[rcx+rcx*1]
  4085e1:	cmovbe rdx,r8
  4085e5:	mov    r8d,DWORD PTR [rax+0x730]
  4085ec:	mov    r9d,r8d
  4085ef:	sub    rdx,rcx
  4085f2:	inc    rdx
  4085f5:	xor    r10d,r10d
  4085f8:	test   r8,r8
  4085fb:	jbe    40862b <__swc_fn_ff58629f_000066_d9ee99ea+0x2ab>
  4085fd:	nop    DWORD PTR [rax]
  408600:	mov    r11d,r10d
  408603:	lea    r11,[r11+r11*4]
  408607:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40860f:	sub    r11,rcx
  408612:	cmp    r11,rdx
  408615:	jae    408622 <__swc_fn_ff58629f_000066_d9ee99ea+0x2a2>
  408617:	mov    r9d,r10d
  40861a:	mov    rdx,r11
  40861d:	test   r11,r11
  408620:	je     40862b <__swc_fn_ff58629f_000066_d9ee99ea+0x2ab>
  408622:	add    r10,0x1
  408626:	cmp    r10,r8
  408629:	jb     408600 <__swc_fn_ff58629f_000066_d9ee99ea+0x280>
  40862b:	mov    ecx,DWORD PTR [rax+0x730]
  408631:	cmp    r9d,ecx
  408634:	jne    40863a <__swc_fn_ff58629f_000066_d9ee99ea+0x2ba>
  408636:	xor    eax,eax
  408638:	jmp    408699 <__swc_fn_ff58629f_000066_d9ee99ea+0x319>
  40863a:	lea    rcx,[r9+r9*4]
  40863e:	lea    rcx,[rax+rcx*8+0x738]
  408646:	vmovups xmm0,XMMWORD PTR [rcx]
  40864a:	mov    rdx,QWORD PTR [rcx+0x10]
  40864e:	sub    DWORD PTR [rax+0x730],0x1
  408655:	mov    r8d,DWORD PTR [rax+0x730]
  40865c:	lea    r8,[r8+r8*4]
  408660:	lea    r8,[rax+r8*8+0x738]
  408668:	vmovups xmm1,XMMWORD PTR [r8]
  40866d:	vmovups XMMWORD PTR [rcx],xmm1
  408671:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  408677:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40867c:	mov    rax,QWORD PTR [r8+0x20]
  408680:	mov    QWORD PTR [rcx+0x20],rax
  408684:	vpshufd xmm1,xmm0,0xee
  408689:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40868f:	mov    QWORD PTR [rsp+0x10],rdx
  408694:	vmovq  rax,xmm0
  408699:	mov    r15,rax
  40869c:	test   r15,r15
  40869f:	jne    4086b7 <__swc_fn_ff58629f_000066_d9ee99ea+0x337>
  4086a1:	mov    rcx,rbx
  4086a4:	mov    rdx,QWORD PTR [rsp+0x8]
  4086a9:	mov    r8,r13
  4086ac:	mov    r9,r12
  4086af:	call   407f70 <__swc_fn_ff58629f_000060_2ca0cb05>
  4086b4:	mov    r15,rax
  4086b7:	test   r15,r15
  4086ba:	je     4086fb <__swc_fn_ff58629f_000066_d9ee99ea+0x37b>
  4086bc:	cmp    QWORD PTR [r12],r14
  4086c0:	jae    4086fb <__swc_fn_ff58629f_000066_d9ee99ea+0x37b>
  4086c2:	mov    rax,r15
  4086c5:	add    rax,QWORD PTR [r12]
  4086c9:	mov    rdx,r14
  4086cc:	sub    rdx,QWORD PTR [r12]
  4086d0:	mov    rcx,rax
  4086d3:	call   40ecd0 <__swc_fn_ff58629f_000008_f7acedb0>
  4086d8:	test   al,al
  4086da:	je     4086e3 <__swc_fn_ff58629f_000066_d9ee99ea+0x363>
  4086dc:	mov    QWORD PTR [rsp+0x10],r14
  4086e1:	jmp    4086fb <__swc_fn_ff58629f_000066_d9ee99ea+0x37b>
  4086e3:	mov    rcx,rbx
  4086e6:	mov    rdx,r15
  4086e9:	mov    r8,QWORD PTR [rsp+0x8]
  4086ee:	mov    r9,QWORD PTR [rsp+0x10]
  4086f3:	call   408080 <__swc_fn_ff58629f_000063_b304235a>
  4086f8:	xor    r15d,r15d
  4086fb:	test   r15,r15
  4086fe:	jne    40877a <__swc_fn_ff58629f_000066_d9ee99ea+0x3fa>
  408700:	cmp    r14,0x10000
  408707:	ja     40870e <__swc_fn_ff58629f_000066_d9ee99ea+0x38e>
  408709:	mov    rax,r14
  40870c:	jmp    40875f <__swc_fn_ff58629f_000066_d9ee99ea+0x3df>
  40870e:	xor    eax,eax
  408710:	lea    rcx,[r14-0x1]
  408714:	lzcnt  rax,rcx
  408719:	mov    ecx,0x3f
  40871e:	sub    rcx,rax
  408721:	mov    eax,0x1
  408726:	lea    rcx,[rcx-0x3]
  40872a:	shl    rax,cl
  40872d:	mov    rcx,rax
  408730:	cmp    rax,0x1000
  408737:	mov    eax,0x1000
  40873c:	cmovb  rcx,rax
  408740:	mov    rdx,0xffffffffffffffff
  408747:	sub    rdx,rcx
  40874a:	mov    rax,r14
  40874d:	lea    r8,[r14+rcx*1-0x1]
  408752:	neg    rcx
  408755:	and    r8,rcx
  408758:	cmp    r14,rdx
  40875b:	cmovbe rax,r8
  40875f:	mov    QWORD PTR [rsp+0x8],rax
  408764:	mov    QWORD PTR [rsp+0x10],r14
  408769:	mov    rcx,rbx
  40876c:	mov    rdx,rax
  40876f:	mov    r8,r14
  408772:	call   407ae0 <__swc_fn_ff58629f_000042_c90d80c1>
  408777:	mov    r15,rax
  40877a:	test   r15,r15
  40877d:	jne    40878b <__swc_fn_ff58629f_000066_d9ee99ea+0x40b>
  40877f:	mov    r13,QWORD PTR [rsp+0x20]
  408784:	mov    rsi,QWORD PTR [rsp+0x38]
  408789:	jmp    4087c7 <__swc_fn_ff58629f_000066_d9ee99ea+0x447>
  40878b:	mov    rax,r15
  40878e:	add    rax,QWORD PTR [rsp+0x28]
  408793:	mov    r13,QWORD PTR [rsp+0x20]
  408798:	test   r13d,r13d
  40879b:	mov    rcx,r13
  40879e:	mov    edx,0x8
  4087a3:	cmove  ecx,edx
  4087a6:	dec    rcx
  4087a9:	mov    rdx,0xffffffffffffffff
  4087b0:	sub    rdx,rcx
  4087b3:	cmp    rax,rdx
  4087b6:	jbe    4087bc <__swc_fn_ff58629f_000066_d9ee99ea+0x43c>
  4087b8:	xor    eax,eax
  4087ba:	jmp    4087c4 <__swc_fn_ff58629f_000066_d9ee99ea+0x444>
  4087bc:	add    rax,rcx
  4087bf:	andn   rax,rcx,rax
  4087c4:	mov    rsi,rax
  4087c7:	mov    rax,QWORD PTR [rsp+0x8]
  4087cc:	test   r15,r15
  4087cf:	je     4087d8 <__swc_fn_ff58629f_000066_d9ee99ea+0x458>
  4087d1:	mov    rdi,QWORD PTR [rsp+0x18]
  4087d6:	jmp    4087ea <__swc_fn_ff58629f_000066_d9ee99ea+0x46a>
  4087d8:	mov    rdi,QWORD PTR [rsp+0x18]
  4087dd:	mov    QWORD PTR [rdi+0x40],0x0
  4087e5:	jmp    408866 <__swc_fn_ff58629f_000066_d9ee99ea+0x4e6>
  4087ea:	lea    rdx,[rsi-0x58]
  4087ee:	mov    QWORD PTR [rsi-0x58],r15
  4087f2:	mov    QWORD PTR [rsi-0x50],rax
  4087f6:	mov    rax,QWORD PTR [rsp+0x10]
  4087fb:	mov    QWORD PTR [rsi-0x48],rax
  4087ff:	mov    QWORD PTR [rsi-0x40],rsi
  408803:	mov    rax,QWORD PTR [rdi+0x48]
  408807:	mov    QWORD PTR [rsi-0x38],rax
  40880b:	mov    rax,QWORD PTR [rsp+0x30]
  408810:	mov    QWORD PTR [rsi-0x30],rax
  408814:	mov    DWORD PTR [rsi-0x10],r13d
  408818:	mov    QWORD PTR [rsi-0x28],0x0
  408820:	mov    QWORD PTR [rsi-0x20],0x0
  408828:	add    r15,QWORD PTR [r12]
  40882c:	sub    r15,rsi
  40882f:	mov    QWORD PTR [rsi-0x30],r15
  408833:	mov    rcx,QWORD PTR [rbx+0x250]
  40883a:	nop    WORD PTR [rax+rax*1+0x0]
  408840:	lea    r8,[rcx+r15*1]
  408844:	mov    rax,rcx
  408847:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  408850:	cmp    rax,rcx
  408853:	je     40885a <__swc_fn_ff58629f_000066_d9ee99ea+0x4da>
  408855:	mov    rcx,rax
  408858:	jmp    408840 <__swc_fn_ff58629f_000066_d9ee99ea+0x4c0>
  40885a:	mov    rcx,rbx
  40885d:	call   40b2d0 <__swc_fn_ff58629f_000058_7e1dbcb0>
  408862:	mov    QWORD PTR [rdi+0x40],rsi
  408866:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40886c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  408872:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  408878:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40887e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  408887:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  408890:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  408899:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  4088a2:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  4088ab:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  4088b4:	add    rsp,0xf0
  4088bb:	pop    rsi
  4088bc:	pop    rdi
  4088bd:	pop    r15
  4088bf:	pop    r14
  4088c1:	pop    r13
  4088c3:	pop    r12
  4088c5:	pop    rbx
  4088c6:	ret
	...

00000000004088d0 <__swc_fn_ff58629f_000069_f3aa21af>:
  4088d0:	push   rbx
  4088d1:	push   r12
  4088d3:	push   rdi
  4088d4:	push   rsi
  4088d5:	sub    rsp,0xb8
  4088dc:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4088e2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4088e8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4088ee:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4088f4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4088fa:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  408900:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  408906:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40890f:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  408918:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  408921:	mov    rbx,rdx
  408924:	mov    r12,rcx
  408927:	cmp    DWORD PTR [rbx+0x58],0x0
  40892b:	je     408945 <__swc_fn_ff58629f_000069_f3aa21af+0x75>
  40892d:	mov    eax,DWORD PTR [rbx+0x58]
  408930:	sub    eax,0x1
  408933:	test   DWORD PTR [rbx+0x58],eax
  408936:	je     408945 <__swc_fn_ff58629f_000069_f3aa21af+0x75>
  408938:	mov    QWORD PTR [rbx+0x40],0x0
  408940:	jmp    408b57 <__swc_fn_ff58629f_000069_f3aa21af+0x287>
  408945:	cmp    QWORD PTR [rbx+0x48],0x0
  40894a:	jne    408959 <__swc_fn_ff58629f_000069_f3aa21af+0x89>
  40894c:	mov    QWORD PTR [rbx+0x40],0x0
  408954:	jmp    408b57 <__swc_fn_ff58629f_000069_f3aa21af+0x287>
  408959:	lea    rax,[rsp+0x8]
  40895e:	mov    rcx,QWORD PTR [rbx+0x48]
  408962:	cmp    rcx,0x8
  408966:	ja     408970 <__swc_fn_ff58629f_000069_f3aa21af+0xa0>
  408968:	mov    DWORD PTR [rax],0x0
  40896e:	jmp    4089cb <__swc_fn_ff58629f_000069_f3aa21af+0xfb>
  408970:	cmp    rcx,0x80
  408977:	ja     408987 <__swc_fn_ff58629f_000069_f3aa21af+0xb7>
  408979:	lea    rcx,[rcx+0xf]
  40897d:	shr    rcx,0x4
  408981:	mov    DWORD PTR [rsp+0x8],ecx
  408985:	jmp    4089cb <__swc_fn_ff58629f_000069_f3aa21af+0xfb>
  408987:	cmp    rcx,0x10000
  40898e:	jbe    408998 <__swc_fn_ff58629f_000069_f3aa21af+0xc8>
  408990:	mov    DWORD PTR [rax],0xffffffff
  408996:	jmp    4089cb <__swc_fn_ff58629f_000069_f3aa21af+0xfb>
  408998:	dec    rcx
  40899b:	xor    edx,edx
  40899d:	lzcnt  rdx,rcx
  4089a2:	mov    r8d,0x3f
  4089a8:	sub    r8d,edx
  4089ab:	lea    edx,[r8-0x2]
  4089af:	shrx   rcx,rcx,rdx
  4089b4:	and    ecx,0x3
  4089b7:	lea    edx,[r8-0x7]
  4089bb:	lea    edx,[rdx*4+0x0]
  4089c2:	lea    edx,[rdx+0x9]
  4089c5:	add    edx,ecx
  4089c7:	mov    DWORD PTR [rsp+0x8],edx
  4089cb:	cmp    DWORD PTR [rax],0x0
  4089ce:	jne    4089de <__swc_fn_ff58629f_000069_f3aa21af+0x10e>
  4089d0:	cmp    DWORD PTR [rbx+0x58],0x8
  4089d4:	jbe    4089de <__swc_fn_ff58629f_000069_f3aa21af+0x10e>
  4089d6:	mov    DWORD PTR [rsp+0x8],0x1
  4089de:	cmp    DWORD PTR [rbx+0x58],0x10
  4089e2:	jbe    408a61 <__swc_fn_ff58629f_000069_f3aa21af+0x191>
  4089e8:	cmp    DWORD PTR [rbx+0x58],0x40
  4089ec:	ja     408a61 <__swc_fn_ff58629f_000069_f3aa21af+0x191>
  4089ee:	cmp    DWORD PTR [rax],0xffffffff
  4089f1:	je     408a61 <__swc_fn_ff58629f_000069_f3aa21af+0x191>
  4089f3:	mov    ecx,DWORD PTR [rsp+0x8]
  4089f7:	mov    edx,DWORD PTR [rbx+0x58]
  4089fa:	dec    rdx
  4089fd:	cmp    ecx,0x2d
  408a00:	jae    408a58 <__swc_fn_ff58629f_000069_f3aa21af+0x188>
  408a02:	cs nop WORD PTR [rax+rax*1+0x0]
  408a0c:	nop    DWORD PTR [rax+0x0]
  408a10:	mov    r8d,ecx
  408a13:	test   ecx,ecx
  408a15:	jne    408a1f <__swc_fn_ff58629f_000069_f3aa21af+0x14f>
  408a17:	mov    r8d,0x8
  408a1d:	jmp    408a4b <__swc_fn_ff58629f_000069_f3aa21af+0x17b>
  408a1f:	cmp    r8d,0x8
  408a23:	ja     408a2b <__swc_fn_ff58629f_000069_f3aa21af+0x15b>
  408a25:	shl    r8,0x4
  408a29:	jmp    408a4b <__swc_fn_ff58629f_000069_f3aa21af+0x17b>
  408a2b:	lea    r8d,[r8-0x9]
  408a2f:	mov    r9d,r8d
  408a32:	shr    r9d,0x2
  408a36:	and    r8d,0x3
  408a3a:	lea    r9d,[r9+0x7]
  408a3e:	lea    r9d,[r9-0x2]
  408a42:	lea    r8d,[r8+0x5]
  408a46:	shlx   r8,r8,r9
  408a4b:	test   r8,rdx
  408a4e:	je     408a5d <__swc_fn_ff58629f_000069_f3aa21af+0x18d>
  408a50:	add    ecx,0x1
  408a53:	cmp    ecx,0x2d
  408a56:	jb     408a10 <__swc_fn_ff58629f_000069_f3aa21af+0x140>
  408a58:	mov    ecx,0xffffffff
  408a5d:	mov    DWORD PTR [rsp+0x8],ecx
  408a61:	mov    ecx,DWORD PTR [rsp+0x8]
  408a65:	cmp    ecx,0xffffffff
  408a68:	je     408a70 <__swc_fn_ff58629f_000069_f3aa21af+0x1a0>
  408a6a:	cmp    DWORD PTR [rbx+0x58],0x40
  408a6e:	jbe    408a83 <__swc_fn_ff58629f_000069_f3aa21af+0x1b3>
  408a70:	mov    rcx,r12
  408a73:	mov    rdx,rbx
  408a76:	mov    r8d,DWORD PTR [rax]
  408a79:	call   408380 <__swc_fn_ff58629f_000066_d9ee99ea>
  408a7e:	jmp    408b57 <__swc_fn_ff58629f_000069_f3aa21af+0x287>
  408a83:	lea    rax,[rip+0x1857e]        # 421008 <__swc_data_base_ff58629f+0x8>
  408a8a:	mov    rax,QWORD PTR [rax]
  408a8d:	cmp    rax,0xffffffffffffffff
  408a91:	je     408aa0 <__swc_fn_ff58629f_000069_f3aa21af+0x1d0>
  408a93:	mov    eax,eax
  408a95:	mov    edi,eax
  408a97:	xor    eax,eax
  408a99:	call   407000 <pthread_getspecific@plt>
  408a9e:	jmp    408aa2 <__swc_fn_ff58629f_000069_f3aa21af+0x1d2>
  408aa0:	xor    eax,eax
  408aa2:	test   rax,rax
  408aa5:	jne    408ab4 <__swc_fn_ff58629f_000069_f3aa21af+0x1e4>
  408aa7:	call   407a20 <__swc_fn_ff58629f_000036_cd1a4e8c>
  408aac:	mov    rcx,rax
  408aaf:	call   40cfa0 <__swc_fn_ff58629f_000133_5f757033>
  408ab4:	test   rax,rax
  408ab7:	je     408ac4 <__swc_fn_ff58629f_000069_f3aa21af+0x1f4>
  408ab9:	cmp    QWORD PTR [rax],r12
  408abc:	jne    408ac4 <__swc_fn_ff58629f_000069_f3aa21af+0x1f4>
  408abe:	cmp    DWORD PTR [rax+0x20],0x0
  408ac2:	je     408acf <__swc_fn_ff58629f_000069_f3aa21af+0x1ff>
  408ac4:	mov    rcx,r12
  408ac7:	mov    rdx,rax
  408aca:	call   40af10 <__swc_fn_ff58629f_000046_d8bd27c3>
  408acf:	test   rax,rax
  408ad2:	jne    408ade <__swc_fn_ff58629f_000069_f3aa21af+0x20e>
  408ad4:	mov    QWORD PTR [rbx+0x40],0x0
  408adc:	jmp    408b57 <__swc_fn_ff58629f_000069_f3aa21af+0x287>
  408ade:	lea    r8,[rsp+0xc]
  408ae3:	mov    ecx,DWORD PTR [rsp+0x8]
  408ae7:	mov    DWORD PTR [rsp+0xc],ecx
  408aeb:	mov    ecx,DWORD PTR [r8]
  408aee:	lea    rcx,[rcx+rcx*4]
  408af2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  408af7:	test   rcx,rcx
  408afa:	je     408b33 <__swc_fn_ff58629f_000069_f3aa21af+0x263>
  408afc:	mov    rdx,QWORD PTR [rcx]
  408aff:	test   rdx,rdx
  408b02:	je     408b10 <__swc_fn_ff58629f_000069_f3aa21af+0x240>
  408b04:	mov    r9,QWORD PTR [rdx]
  408b07:	mov    QWORD PTR [rcx],r9
  408b0a:	add    DWORD PTR [rcx+0x28],0x1
  408b0e:	jmp    408b2e <__swc_fn_ff58629f_000069_f3aa21af+0x25e>
  408b10:	mov    rdx,QWORD PTR [rcx+0x18]
  408b14:	cmp    QWORD PTR [rcx+0x20],rdx
  408b18:	jae    408b2c <__swc_fn_ff58629f_000069_f3aa21af+0x25c>
  408b1a:	mov    rdx,QWORD PTR [rcx+0x20]
  408b1e:	mov    r9d,DWORD PTR [rcx+0x2c]
  408b22:	add    QWORD PTR [rcx+0x20],r9
  408b26:	add    DWORD PTR [rcx+0x28],0x1
  408b2a:	jmp    408b2e <__swc_fn_ff58629f_000069_f3aa21af+0x25e>
  408b2c:	xor    edx,edx
  408b2e:	test   rdx,rdx
  408b31:	jne    408b44 <__swc_fn_ff58629f_000069_f3aa21af+0x274>
  408b33:	mov    rcx,r12
  408b36:	mov    rdx,rax
  408b39:	mov    r8d,DWORD PTR [r8]
  408b3c:	call   40b080 <__swc_fn_ff58629f_000055_faa92dcc>
  408b41:	mov    rdx,rax
  408b44:	test   rdx,rdx
  408b47:	jne    408b53 <__swc_fn_ff58629f_000069_f3aa21af+0x283>
  408b49:	mov    QWORD PTR [rbx+0x40],0x0
  408b51:	jmp    408b57 <__swc_fn_ff58629f_000069_f3aa21af+0x287>
  408b53:	mov    QWORD PTR [rbx+0x40],rdx
  408b57:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  408b5d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  408b63:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  408b69:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  408b6f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  408b75:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  408b7b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  408b81:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  408b8a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  408b93:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  408b9c:	add    rsp,0xb8
  408ba3:	pop    rsi
  408ba4:	pop    rdi
  408ba5:	pop    r12
  408ba7:	pop    rbx
  408ba8:	ret
  408ba9:	add    BYTE PTR [rax],al
  408bab:	add    BYTE PTR [rax],al
  408bad:	add    BYTE PTR [rax],al
	...

0000000000408bb0 <__swc_fn_ff58629f_000072_b3d7b28e>:
  408bb0:	ret
	...

0000000000408bc0 <__swc_fn_ff58629f_000075_042643a3>:
  408bc0:	push   r12
  408bc2:	push   r13
  408bc4:	push   r14
  408bc6:	push   rdi
  408bc7:	push   rsi
  408bc8:	sub    rsp,0x1a0
  408bcf:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  408bd8:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  408be1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  408bea:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  408bf3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  408bfc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  408c05:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  408c0e:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  408c17:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  408c20:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  408c29:	mov    r12,rdx
  408c2c:	mov    r13,rcx
  408c2f:	mov    rax,QWORD PTR [r12+0x48]
  408c34:	mov    ecx,DWORD PTR [r12+0x58]
  408c39:	lea    rdx,[rax-0x1]
  408c3d:	cmp    rdx,0x10000
  408c44:	jae    408d3e <__swc_fn_ff58629f_000075_042643a3+0x17e>
  408c4a:	cmp    rax,0x8
  408c4e:	ja     408c55 <__swc_fn_ff58629f_000075_042643a3+0x95>
  408c50:	xor    r14d,r14d
  408c53:	jmp    408ca7 <__swc_fn_ff58629f_000075_042643a3+0xe7>
  408c55:	cmp    rax,0x80
  408c5c:	ja     408c68 <__swc_fn_ff58629f_000075_042643a3+0xa8>
  408c5e:	lea    r14,[rax+0xf]
  408c62:	shr    r14,0x4
  408c66:	jmp    408ca7 <__swc_fn_ff58629f_000075_042643a3+0xe7>
  408c68:	cmp    rax,0x10000
  408c6f:	jbe    408c79 <__swc_fn_ff58629f_000075_042643a3+0xb9>
  408c71:	mov    r14d,0xffffffff
  408c77:	jmp    408ca7 <__swc_fn_ff58629f_000075_042643a3+0xe7>
  408c79:	xor    eax,eax
  408c7b:	lzcnt  rax,rdx
  408c80:	mov    r8d,0x3f
  408c86:	sub    r8d,eax
  408c89:	lea    eax,[r8-0x2]
  408c8d:	shrx   rax,rdx,rax
  408c92:	and    eax,0x3
  408c95:	lea    edx,[r8-0x7]
  408c99:	lea    edx,[rdx*4+0x0]
  408ca0:	lea    edx,[rdx+0x9]
  408ca3:	lea    r14d,[rdx+rax*1]
  408ca7:	cmp    ecx,0x8
  408caa:	jbe    408cc3 <__swc_fn_ff58629f_000075_042643a3+0x103>
  408cac:	cmp    ecx,0x10
  408caf:	jne    408d3e <__swc_fn_ff58629f_000075_042643a3+0x17e>
  408cb5:	test   r14d,r14d
  408cb8:	mov    eax,0x1
  408cbd:	cmove  r14d,eax
  408cc1:	jmp    408cca <__swc_fn_ff58629f_000075_042643a3+0x10a>
  408cc3:	lea    eax,[rcx-0x1]
  408cc6:	test   eax,ecx
  408cc8:	jne    408d3e <__swc_fn_ff58629f_000075_042643a3+0x17e>
  408cca:	lea    rax,[rip+0x18337]        # 421008 <__swc_data_base_ff58629f+0x8>
  408cd1:	mov    rax,QWORD PTR [rax]
  408cd4:	cmp    rax,0xffffffffffffffff
  408cd8:	je     408ce7 <__swc_fn_ff58629f_000075_042643a3+0x127>
  408cda:	mov    eax,eax
  408cdc:	mov    edi,eax
  408cde:	xor    eax,eax
  408ce0:	call   407000 <pthread_getspecific@plt>
  408ce5:	jmp    408ce9 <__swc_fn_ff58629f_000075_042643a3+0x129>
  408ce7:	xor    eax,eax
  408ce9:	test   rax,rax
  408cec:	je     408d3e <__swc_fn_ff58629f_000075_042643a3+0x17e>
  408cee:	cmp    QWORD PTR [rax],r13
  408cf1:	jne    408d3e <__swc_fn_ff58629f_000075_042643a3+0x17e>
  408cf3:	lea    rcx,[r14+r14*4]
  408cf7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  408cfc:	test   rax,rax
  408cff:	je     408d3e <__swc_fn_ff58629f_000075_042643a3+0x17e>
  408d01:	mov    rcx,QWORD PTR [rax]
  408d04:	test   rcx,rcx
  408d07:	je     408d15 <__swc_fn_ff58629f_000075_042643a3+0x155>
  408d09:	mov    rdx,QWORD PTR [rcx]
  408d0c:	mov    QWORD PTR [rax],rdx
  408d0f:	add    DWORD PTR [rax+0x28],0x1
  408d13:	jmp    408d32 <__swc_fn_ff58629f_000075_042643a3+0x172>
  408d15:	mov    rcx,QWORD PTR [rax+0x18]
  408d19:	cmp    QWORD PTR [rax+0x20],rcx
  408d1d:	jae    408d30 <__swc_fn_ff58629f_000075_042643a3+0x170>
  408d1f:	mov    rcx,QWORD PTR [rax+0x20]
  408d23:	mov    edx,DWORD PTR [rax+0x2c]
  408d26:	add    QWORD PTR [rax+0x20],rdx
  408d2a:	add    DWORD PTR [rax+0x28],0x1
  408d2e:	jmp    408d32 <__swc_fn_ff58629f_000075_042643a3+0x172>
  408d30:	xor    ecx,ecx
  408d32:	test   rcx,rcx
  408d35:	je     408d3e <__swc_fn_ff58629f_000075_042643a3+0x17e>
  408d37:	mov    QWORD PTR [r12+0x40],rcx
  408d3c:	jmp    408d49 <__swc_fn_ff58629f_000075_042643a3+0x189>
  408d3e:	mov    rcx,r13
  408d41:	mov    rdx,r12
  408d44:	call   40bb00 <__swc_fn_ff58629f_000076_64d36d78>
  408d49:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  408d52:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  408d5b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  408d64:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  408d6d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  408d76:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  408d7f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  408d88:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  408d91:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  408d9a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  408da3:	add    rsp,0x1a0
  408daa:	pop    rsi
  408dab:	pop    rdi
  408dac:	pop    r14
  408dae:	pop    r13
  408db0:	pop    r12
  408db2:	ret
	...

0000000000408dc0 <__swc_fn_ff58629f_000078_7b195156>:
  408dc0:	push   r12
  408dc2:	push   r13
  408dc4:	push   r14
  408dc6:	push   r15
  408dc8:	push   rdi
  408dc9:	push   rsi
  408dca:	sub    rsp,0x188
  408dd1:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  408dda:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  408de3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  408dec:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  408df5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  408dfe:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  408e07:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  408e10:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  408e19:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  408e22:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  408e2b:	mov    r12,rdx
  408e2e:	mov    r13,rcx
  408e31:	mov    r14,QWORD PTR [r12+0x40]
  408e36:	lea    rax,[rip+0x1a23b]        # 423078 <__swc_bss_base_ff58629f+0x38>
  408e3d:	mov    rcx,r14
  408e40:	sub    rcx,QWORD PTR [rax+0x8]
  408e44:	mov    rax,QWORD PTR [rip+0x1a23d]        # 423088 <__swc_bss_base_ff58629f+0x48>
  408e4b:	cmp    rcx,rax
  408e4e:	jae    408e7a <__swc_fn_ff58629f_000078_7b195156+0xba>
  408e50:	mov    rax,r14
  408e53:	and    rax,0xffffffffffc00000
  408e5a:	mov    rcx,r14
  408e5d:	shr    rcx,0x10
  408e61:	and    ecx,0x3f
  408e64:	mov    edx,DWORD PTR [rax+0x28]
  408e67:	shrx   ecx,ecx,edx
  408e6c:	shl    rcx,0x4
  408e70:	lea    r15,[rax+rcx*8+0x80]
  408e78:	jmp    408e85 <__swc_fn_ff58629f_000078_7b195156+0xc5>
  408e7a:	mov    rcx,r14
  408e7d:	call   407950 <__swc_fn_ff58629f_000027_bcdc5519>
  408e82:	mov    r15,rax
  408e85:	test   r15,r15
  408e88:	je     408f2f <__swc_fn_ff58629f_000078_7b195156+0x16f>
  408e8e:	lea    rax,[rip+0x18173]        # 421008 <__swc_data_base_ff58629f+0x8>
  408e95:	mov    rax,QWORD PTR [rax]
  408e98:	cmp    rax,0xffffffffffffffff
  408e9c:	je     408eab <__swc_fn_ff58629f_000078_7b195156+0xeb>
  408e9e:	mov    eax,eax
  408ea0:	mov    edi,eax
  408ea2:	xor    eax,eax
  408ea4:	call   407000 <pthread_getspecific@plt>
  408ea9:	jmp    408ead <__swc_fn_ff58629f_000078_7b195156+0xed>
  408eab:	xor    eax,eax
  408ead:	mov    rcx,QWORD PTR [r15+0x40]
  408eb1:	cmp    rcx,rax
  408eb4:	jne    408f14 <__swc_fn_ff58629f_000078_7b195156+0x154>
  408eb6:	test   rax,rax
  408eb9:	je     408f2f <__swc_fn_ff58629f_000078_7b195156+0x16f>
  408ebb:	mov    ecx,DWORD PTR [r15+0x6c]
  408ebf:	test   ecx,ecx
  408ec1:	je     408ee1 <__swc_fn_ff58629f_000078_7b195156+0x121>
  408ec3:	mov    rcx,r13
  408ec6:	mov    rdx,rax
  408ec9:	mov    r8,r15
  408ecc:	mov    QWORD PTR [rsp+0xd8],rax
  408ed4:	call   40b010 <__swc_fn_ff58629f_000052_e072b516>
  408ed9:	mov    rax,QWORD PTR [rsp+0xd8]
  408ee1:	mov    rcx,QWORD PTR [r15]
  408ee4:	mov    QWORD PTR [r14],rcx
  408ee7:	mov    QWORD PTR [r15],r14
  408eea:	sub    DWORD PTR [r15+0x28],0x1
  408eef:	jne    408f24 <__swc_fn_ff58629f_000078_7b195156+0x164>
  408ef1:	movzx  ecx,BYTE PTR [r15+0x39]
  408ef6:	lea    rcx,[rcx+rcx*4]
  408efa:	lea    rcx,[rax+rcx*8+0x28]
  408eff:	cmp    QWORD PTR [rcx],r15
  408f02:	je     408f24 <__swc_fn_ff58629f_000078_7b195156+0x164>
  408f04:	mov    rcx,r13
  408f07:	mov    rdx,rax
  408f0a:	mov    r8,r15
  408f0d:	call   40f7a0 <__swc_fn_ff58629f_000056_2e3450f7>
  408f12:	jmp    408f24 <__swc_fn_ff58629f_000078_7b195156+0x164>
  408f14:	test   rcx,rcx
  408f17:	je     408f2f <__swc_fn_ff58629f_000078_7b195156+0x16f>
  408f19:	mov    rcx,r15
  408f1c:	mov    rdx,r14
  408f1f:	call   407590 <__swc_fn_ff58629f_000015_524c1f23>
  408f24:	mov    QWORD PTR [r12+0x40],0x0
  408f2d:	jmp    408f3a <__swc_fn_ff58629f_000078_7b195156+0x17a>
  408f2f:	mov    rcx,r13
  408f32:	mov    rdx,r12
  408f35:	call   40bb20 <__swc_fn_ff58629f_000079_1966ae2e>
  408f3a:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  408f43:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  408f4c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  408f55:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  408f5e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  408f67:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  408f70:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  408f79:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  408f82:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  408f8b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  408f94:	add    rsp,0x188
  408f9b:	pop    rsi
  408f9c:	pop    rdi
  408f9d:	pop    r15
  408f9f:	pop    r14
  408fa1:	pop    r13
  408fa3:	pop    r12
  408fa5:	ret
	...

0000000000408fb0 <__swc_fn_ff58629f_000081_d2cd17e2>:
  408fb0:	sub    rsp,0x8
  408fb4:	mov    rax,rdx
  408fb7:	mov    rdx,QWORD PTR [rax+0x40]
  408fbb:	mov    r8,rax
  408fbe:	call   408bb0 <__swc_fn_ff58629f_000072_b3d7b28e>
  408fc3:	add    rsp,0x8
  408fc7:	ret
	...

0000000000408fd0 <__swc_fn_ff58629f_000084_4a10c7e7>:
  408fd0:	push   rsi
  408fd1:	push   rdi
  408fd2:	sub    rsp,0x8
  408fd6:	cmp    rcx,0xffffffffffffffef
  408fda:	ja     409000 <__swc_fn_ff58629f_000084_4a10c7e7+0x30>
  408fdc:	xor    esi,esi
  408fde:	lea    rax,[rcx+0x100f]
  408fe5:	and    rax,0xfffffffffffff000
  408fec:	lea    rcx,[rcx+0x10]
  408ff0:	cmp    rcx,0xfffffffffffff000
  408ff7:	cmovbe rsi,rax
  408ffb:	test   rsi,rsi
  408ffe:	jne    409009 <__swc_fn_ff58629f_000084_4a10c7e7+0x39>
  409000:	xor    eax,eax
  409002:	add    rsp,0x8
  409006:	pop    rdi
  409007:	pop    rsi
  409008:	ret
  409009:	mov    rcx,rsi
  40900c:	call   409660 <__swc_fn_ff58629f_000114_6b799b8d>
  409011:	mov    rdi,rax
  409014:	test   rax,rax
  409017:	jne    409022 <__swc_fn_ff58629f_000084_4a10c7e7+0x52>
  409019:	xor    eax,eax
  40901b:	add    rsp,0x8
  40901f:	pop    rdi
  409020:	pop    rsi
  409021:	ret
  409022:	mov    rcx,rdi
  409025:	mov    rdx,rsi
  409028:	call   410c60 <__swc_fn_ff58629f_000116_36905703>
  40902d:	test   al,al
  40902f:	jne    409045 <__swc_fn_ff58629f_000084_4a10c7e7+0x75>
  409031:	mov    rcx,rdi
  409034:	mov    rdx,rsi
  409037:	call   40cc50 <__swc_fn_ff58629f_000118_ed2d8fed>
  40903c:	xor    eax,eax
  40903e:	add    rsp,0x8
  409042:	pop    rdi
  409043:	pop    rsi
  409044:	ret
  409045:	mov    QWORD PTR [rdi],rsi
  409048:	mov    QWORD PTR [rdi+0x8],0x0
  409050:	lea    rax,[rdi+0x10]
  409054:	add    rsp,0x8
  409058:	pop    rdi
  409059:	pop    rsi
  40905a:	ret
  40905b:	add    BYTE PTR [rax],al
  40905d:	add    BYTE PTR [rax],al
	...

0000000000409060 <__swc_fn_ff58629f_000087_3953ef98>:
  409060:	sub    rsp,0x8
  409064:	cmp    BYTE PTR [rcx+0x2c],0x10
  409068:	jne    409073 <__swc_fn_ff58629f_000087_3953ef98+0x13>
  40906a:	test   DWORD PTR [rcx+0x28],0x80
  409071:	je     40907b <__swc_fn_ff58629f_000087_3953ef98+0x1b>
  409073:	mov    rax,rcx
  409076:	add    rsp,0x8
  40907a:	ret
  40907b:	mov    rcx,QWORD PTR [rcx+0x40]
  40907f:	call   409060 <__swc_fn_ff58629f_000087_3953ef98>
  409084:	add    rsp,0x8
  409088:	ret
	...

00000000004090a0 <__swc_fn_ff58629f_000090_d182c4dc>:
  4090a0:	push   rsi
  4090a1:	push   rdi
  4090a2:	push   r12
  4090a4:	push   r13
  4090a6:	sub    rsp,0x8
  4090aa:	mov    rsi,rdx
  4090ad:	mov    rdi,rcx
  4090b0:	xor    r8d,r8d
  4090b3:	call   40ffc0 <__swc_fn_ff58629f_000095_63c1827b>
  4090b8:	test   al,al
  4090ba:	je     4090cc <__swc_fn_ff58629f_000090_d182c4dc+0x2c>
  4090bc:	mov    eax,0x1
  4090c1:	add    rsp,0x8
  4090c5:	pop    r13
  4090c7:	pop    r12
  4090c9:	pop    rdi
  4090ca:	pop    rsi
  4090cb:	ret
  4090cc:	rex cmp BYTE PTR [rsi+0x2c],0xe
  4090d1:	je     4090e0 <__swc_fn_ff58629f_000090_d182c4dc+0x40>
  4090d3:	xor    eax,eax
  4090d5:	add    rsp,0x8
  4090d9:	pop    r13
  4090db:	pop    r12
  4090dd:	pop    rdi
  4090de:	pop    rsi
  4090df:	ret
  4090e0:	mov    r12,QWORD PTR [rsi+0x98]
  4090e7:	mov    rax,QWORD PTR [rsi+0xa0]
  4090ee:	mov    rsi,rax
  4090f1:	xor    r13d,r13d
  4090f4:	test   rsi,rsi
  4090f7:	je     409154 <__swc_fn_ff58629f_000090_d182c4dc+0xb4>
  4090f9:	cs nop WORD PTR [rax+rax*1+0x0]
  409103:	cs nop WORD PTR [rax+rax*1+0x0]
  40910d:	nop    DWORD PTR [rax]
  409110:	lea    rax,[r13*8+0x0]
  409118:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40911d:	mov    rcx,rax
  409120:	call   409060 <__swc_fn_ff58629f_000087_3953ef98>
  409125:	cmp    BYTE PTR [rax+0x2c],0xe
  409129:	jne    40914a <__swc_fn_ff58629f_000090_d182c4dc+0xaa>
  40912b:	mov    rcx,rdi
  40912e:	mov    rdx,rax
  409131:	call   4090a0 <__swc_fn_ff58629f_000090_d182c4dc>
  409136:	test   al,al
  409138:	je     40914a <__swc_fn_ff58629f_000090_d182c4dc+0xaa>
  40913a:	mov    eax,0x1
  40913f:	add    rsp,0x8
  409143:	pop    r13
  409145:	pop    r12
  409147:	pop    rdi
  409148:	pop    rsi
  409149:	ret
  40914a:	add    r13,0x1
  40914e:	sub    rsi,0x1
  409152:	jne    409110 <__swc_fn_ff58629f_000090_d182c4dc+0x70>
  409154:	xor    eax,eax
  409156:	add    rsp,0x8
  40915a:	pop    r13
  40915c:	pop    r12
  40915e:	pop    rdi
  40915f:	pop    rsi
  409160:	ret
	...

0000000000409170 <__swc_fn_ff58629f_000093_14c65203>:
  409170:	sub    rsp,0x18
  409174:	vxorps xmm0,xmm0,xmm0
  409178:	vmovdqu XMMWORD PTR [rsp],xmm0
  40917d:	call   40bd30 <__swc_fn_ff58629f_000094_c2567a3b>
  409182:	add    rsp,0x18
  409186:	ret
	...

0000000000409190 <__swc_fn_ff58629f_000096_ad13d15c>:
  409190:	sub    rsp,0x8
  409194:	mov    rcx,QWORD PTR [rip+0x19ea5]        # 423040 <__swc_bss_base_ff58629f>
  40919b:	test   rcx,rcx
  40919e:	jne    4091b0 <__swc_fn_ff58629f_000096_ad13d15c+0x20>
  4091a0:	call   411bc0 <__swc_fn_ff58629f_000170_994c8876>
  4091a5:	lea    rcx,[rax+0x1]
  4091a9:	mov    QWORD PTR [rip+0x19e90],rcx        # 423040 <__swc_bss_base_ff58629f>
  4091b0:	dec    rcx
  4091b3:	call   40ea20 <__swc_fn_ff58629f_000172_360af05d>
  4091b8:	mov    rax,QWORD PTR [rax+0xc0]
  4091bf:	and    eax,0x1
  4091c2:	setne  al
  4091c5:	add    rsp,0x8
  4091c9:	ret
	...

00000000004091e0 <__swc_fn_ff58629f_000099_4f209617>:
  4091e0:	push   rbx
  4091e1:	push   rsi
  4091e2:	push   rdi
  4091e3:	push   r12
  4091e5:	sub    rsp,0x28
  4091e9:	mov    rbx,rcx
  4091ec:	call   410320 <__swc_fn_ff58629f_000098_4185993f>
  4091f1:	mov    rcx,QWORD PTR [rip+0x19e48]        # 423040 <__swc_bss_base_ff58629f>
  4091f8:	test   rcx,rcx
  4091fb:	jne    40920d <__swc_fn_ff58629f_000099_4f209617+0x2d>
  4091fd:	call   411bc0 <__swc_fn_ff58629f_000170_994c8876>
  409202:	lea    rcx,[rax+0x1]
  409206:	mov    QWORD PTR [rip+0x19e33],rcx        # 423040 <__swc_bss_base_ff58629f>
  40920d:	dec    rcx
  409210:	call   40ea20 <__swc_fn_ff58629f_000172_360af05d>
  409215:	mov    rsi,rax
  409218:	lea    rcx,[rsp+0x8]
  40921d:	call   40c170 <__swc_fn_ff58629f_000097_93bfe675>
  409222:	mov    rdi,QWORD PTR [rsi+0x9c0]
  409229:	mov    r12,QWORD PTR [rsi+0xbe8]
  409230:	lea    rcx,[rsi+0x10]
  409234:	call   40a1b0 <__swc_fn_ff58629f_000162_13ead2ff>
  409239:	mov    rcx,rsi
  40923c:	call   40c2e0 <__swc_fn_ff58629f_000106_5a85fcf5>
  409241:	vxorps xmm0,xmm0,xmm0
  409245:	xor    eax,eax
  409247:	cs nop WORD PTR [rax+rax*1+0x0]
  409251:	cs nop WORD PTR [rax+rax*1+0x0]
  40925b:	nop    DWORD PTR [rax+rax*1+0x0]
  409260:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  409265:	add    rax,0x10
  409269:	cmp    rax,0xbf0
  409270:	jne    409260 <__swc_fn_ff58629f_000099_4f209617+0x80>
  409272:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409278:	vmovups XMMWORD PTR [rsi],xmm0
  40927c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409282:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40928a:	mov    QWORD PTR [rsi+0x9c0],rdi
  409291:	mov    QWORD PTR [rsi+0xbe8],r12
  409298:	mov    rcx,QWORD PTR [rip+0x19da1]        # 423040 <__swc_bss_base_ff58629f>
  40929f:	test   rcx,rcx
  4092a2:	jne    4092b4 <__swc_fn_ff58629f_000099_4f209617+0xd4>
  4092a4:	call   411bc0 <__swc_fn_ff58629f_000170_994c8876>
  4092a9:	lea    rcx,[rax+0x1]
  4092ad:	mov    QWORD PTR [rip+0x19d8c],rcx        # 423040 <__swc_bss_base_ff58629f>
  4092b4:	dec    rcx
  4092b7:	call   40ea20 <__swc_fn_ff58629f_000172_360af05d>
  4092bc:	mov    rsi,rax
  4092bf:	mov    QWORD PTR [rsi+0xc0],rbx
  4092c6:	and    ebx,0x1
  4092c9:	jne    4092cd <__swc_fn_ff58629f_000099_4f209617+0xed>
  4092cb:	xor    eax,eax
  4092cd:	test   rbx,rbx
  4092d0:	sete   al
  4092d3:	xor    cl,cl
  4092d5:	xor    dl,dl
  4092d7:	xor    r8b,r8b
  4092da:	xor    r9b,r9b
  4092dd:	xor    r10b,r10b
  4092e0:	mov    r11,rax
  4092e3:	call   40bb30 <__swc_fn_ff58629f_000082_5cc7acfc>
  4092e8:	lea    rbx,[rsp+0x18]
  4092ed:	mov    rcx,rbx
  4092f0:	call   40c170 <__swc_fn_ff58629f_000097_93bfe675>
  4092f5:	lea    rcx,[rsi+0x10]
  4092f9:	mov    edx,0x400000
  4092fe:	mov    r8,rbx
  409301:	call   411900 <__swc_fn_ff58629f_000164_8a3d304f>
  409306:	lea    rcx,[rsi+0x68]
  40930a:	mov    edx,0x4000
  40930f:	mov    r8,rbx
  409312:	call   411900 <__swc_fn_ff58629f_000164_8a3d304f>
  409317:	add    rsp,0x28
  40931b:	pop    r12
  40931d:	pop    rdi
  40931e:	pop    rsi
  40931f:	pop    rbx
  409320:	ret
	...

0000000000409330 <__swc_fn_ff58629f_000102_d0b19c14>:
  409330:	push   rbx
  409331:	push   rsi
  409332:	sub    rsp,0x18
  409336:	mov    rbx,rcx
  409339:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40933e:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409344:	mov    rsi,QWORD PTR [rbx+0x70]
  409348:	lea    rcx,[rcx+0x18]
  40934c:	call   40a1b0 <__swc_fn_ff58629f_000162_13ead2ff>
  409351:	lea    rcx,[rsp+0x8]
  409356:	mov    rdx,rbx
  409359:	mov    r8d,0x78
  40935f:	call   410380 <__swc_fn_ff58629f_000101_d4bdcaa4>
  409364:	mov    rax,rsi
  409367:	add    rsp,0x18
  40936b:	pop    rsi
  40936c:	pop    rbx
  40936d:	ret
	...

0000000000409370 <__swc_fn_ff58629f_000105_3c3b96fb>:
  409370:	push   rsi
  409371:	push   rdi
  409372:	sub    rsp,0x8
  409376:	cmp    QWORD PTR [rcx],0x0
  40937a:	jne    409383 <__swc_fn_ff58629f_000105_3c3b96fb+0x13>
  40937c:	add    rsp,0x8
  409380:	pop    rdi
  409381:	pop    rsi
  409382:	ret
  409383:	mov    rsi,QWORD PTR [rcx]
  409386:	mov    rax,QWORD PTR [rcx+0x8]
  40938a:	test   rax,rax
  40938d:	je     4093a3 <__swc_fn_ff58629f_000105_3c3b96fb+0x33>
  40938f:	test   DWORD PTR [rax+0x28],0x400000
  409396:	je     4093a3 <__swc_fn_ff58629f_000105_3c3b96fb+0x33>
  409398:	mov    rcx,QWORD PTR [rax+0x30]
  40939c:	test   rcx,rcx
  40939f:	cmovne rax,rcx
  4093a3:	lea    rdx,[rip+0x8f4e]        # 4122f8 <__swc_rdata_base_ff58629f+0x1e8>
  4093aa:	lea    rcx,[rip+0x902f]        # 4123e0 <__swc_rdata_base_ff58629f+0x2d0>
  4093b1:	mov    r8,rax
  4093b4:	xor    r9d,r9d
  4093b7:	xor    al,al
  4093b9:	mov    r10,rax
  4093bc:	xor    r11d,r11d
  4093bf:	call   409170 <__swc_fn_ff58629f_000093_14c65203>
  4093c4:	test   rax,rax
  4093c7:	je     4093d7 <__swc_fn_ff58629f_000105_3c3b96fb+0x67>
  4093c9:	mov    rdi,QWORD PTR [rax+0x48]
  4093cd:	test   rdi,rdi
  4093d0:	je     4093d7 <__swc_fn_ff58629f_000105_3c3b96fb+0x67>
  4093d2:	mov    rcx,rsi
  4093d5:	call   rdi
  4093d7:	add    rsp,0x8
  4093db:	pop    rdi
  4093dc:	pop    rsi
  4093dd:	ret
	...

00000000004093e0 <__swc_fn_ff58629f_000108_90faaa26>:
  4093e0:	push   rbx
  4093e1:	push   rsi
  4093e2:	push   rdi
  4093e3:	sub    rsp,0x20
  4093e7:	mov    rbx,rdx
  4093ea:	mov    rsi,rcx
  4093ed:	mov    rcx,QWORD PTR [rip+0x19c4c]        # 423040 <__swc_bss_base_ff58629f>
  4093f4:	test   rcx,rcx
  4093f7:	jne    409409 <__swc_fn_ff58629f_000108_90faaa26+0x29>
  4093f9:	call   411bc0 <__swc_fn_ff58629f_000170_994c8876>
  4093fe:	lea    rcx,[rax+0x1]
  409402:	mov    QWORD PTR [rip+0x19c37],rcx        # 423040 <__swc_bss_base_ff58629f>
  409409:	dec    rcx
  40940c:	call   40ea20 <__swc_fn_ff58629f_000172_360af05d>
  409411:	mov    rdi,rax
  409414:	mov    rax,QWORD PTR [rdi+0xbd0]
  40941b:	xor    ecx,ecx
  40941d:	test   rax,rax
  409420:	je     409425 <__swc_fn_ff58629f_000108_90faaa26+0x45>
  409422:	mov    rcx,QWORD PTR [rax]
  409425:	call   411cf0 <__swc_fn_ff58629f_000179_718d7b54>
  40942a:	lea    rax,[rsp+0x8]
  40942f:	lea    rcx,[rdi+0x9c8]
  409436:	mov    QWORD PTR [rsp+0x8],rcx
  40943b:	mov    QWORD PTR [rax+0x8],0x40
  409443:	xor    ecx,ecx
  409445:	mov    rdx,rax
  409448:	call   40cd80 <__swc_fn_ff58629f_000124_4f256d58>
  40944d:	mov    DWORD PTR [rdi+0xbc8],eax
  409453:	mov    rdi,QWORD PTR [rdi+0x990]
  40945a:	test   rdi,rdi
  40945d:	je     409467 <__swc_fn_ff58629f_000108_90faaa26+0x87>
  40945f:	mov    rcx,rsi
  409462:	mov    rdx,rbx
  409465:	call   rdi
  409467:	call   409190 <__swc_fn_ff58629f_000096_ad13d15c>
  40946c:	test   al,al
  40946e:	je     40947e <__swc_fn_ff58629f_000108_90faaa26+0x9e>
  409470:	mov    rcx,rsi
  409473:	mov    rdx,rbx
  409476:	xor    r8d,r8d
  409479:	call   410e00 <__swc_fn_ff58629f_000125_83db7238>
  40947e:	mov    rcx,rsi
  409481:	mov    rdx,rbx
  409484:	call   410480 <__swc_fn_ff58629f_000107_ffe51047>
  409489:	call   409a10 <__swc_fn_ff58629f_000123_be2e2f68>
  40948e:	add    rsp,0x20
  409492:	pop    rdi
  409493:	pop    rsi
  409494:	pop    rbx
  409495:	ret
	...

00000000004094a0 <__swc_fn_ff58629f_000111_3dc01326>:
  4094a0:	test   r8,r8
  4094a3:	jne    4094a8 <__swc_fn_ff58629f_000111_3dc01326+0x8>
  4094a5:	xor    eax,eax
  4094a7:	ret
  4094a8:	xor    eax,eax
  4094aa:	nop    WORD PTR [rax+rax*1+0x0]
  4094b0:	mov    r9,r8
  4094b3:	sub    r9,rax
  4094b6:	cmp    r9,0x10
  4094ba:	jb     409504 <__swc_fn_ff58629f_000111_3dc01326+0x64>
  4094bc:	lea    r9,[rcx+rax*1]
  4094c0:	lea    r10,[rdx+rax*1]
  4094c4:	vmovups xmm0,XMMWORD PTR [r10]
  4094c9:	vmovups xmm1,XMMWORD PTR [r9]
  4094ce:	vpcmpeqb xmm0,xmm1,xmm0
  4094d2:	vpmovmskb r9d,xmm0
  4094d6:	cmp    r9d,0xffff
  4094dd:	je     4094fe <__swc_fn_ff58629f_000111_3dc01326+0x5e>
  4094df:	not    r9d
  4094e2:	xor    r8d,r8d
  4094e5:	movzx  r9d,r9w
  4094e9:	tzcnt  r8d,r9d
  4094ee:	add    rax,r8
  4094f1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  4094f5:	movzx  eax,BYTE PTR [rdx+rax*1]
  4094f9:	sub    ecx,eax
  4094fb:	mov    eax,ecx
  4094fd:	ret
  4094fe:	lea    rax,[rax+0x10]
  409502:	jmp    4094b0 <__swc_fn_ff58629f_000111_3dc01326+0x10>
  409504:	cmp    r9,0x8
  409508:	jb     40957b <__swc_fn_ff58629f_000111_3dc01326+0xdb>
  40950a:	lea    r9,[rcx+rax*1]
  40950e:	lea    r10,[rdx+rax*1]
  409512:	mov    r9,QWORD PTR [r9]
  409515:	xor    r9,QWORD PTR [r10]
  409518:	test   r9,r9
  40951b:	je     409539 <__swc_fn_ff58629f_000111_3dc01326+0x99>
  40951d:	xor    r8d,r8d
  409520:	tzcnt  r8,r9
  409525:	shr    r8,0x3
  409529:	add    rax,r8
  40952c:	movzx  ecx,BYTE PTR [rcx+rax*1]
  409530:	movzx  eax,BYTE PTR [rdx+rax*1]
  409534:	sub    ecx,eax
  409536:	mov    eax,ecx
  409538:	ret
  409539:	lea    rax,[rax+0x8]
  40953d:	cmp    rax,r8
  409540:	jne    409545 <__swc_fn_ff58629f_000111_3dc01326+0xa5>
  409542:	xor    eax,eax
  409544:	ret
  409545:	lea    rax,[r8-0x8]
  409549:	lea    r8,[rcx+rax*1]
  40954d:	lea    r9,[rdx+rax*1]
  409551:	mov    r8,QWORD PTR [r8]
  409554:	xor    r8,QWORD PTR [r9]
  409557:	test   r8,r8
  40955a:	je     409578 <__swc_fn_ff58629f_000111_3dc01326+0xd8>
  40955c:	xor    r9d,r9d
  40955f:	tzcnt  r9,r8
  409564:	shr    r9,0x3
  409568:	add    rax,r9
  40956b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40956f:	movzx  eax,BYTE PTR [rdx+rax*1]
  409573:	sub    ecx,eax
  409575:	mov    eax,ecx
  409577:	ret
  409578:	xor    eax,eax
  40957a:	ret
  40957b:	cmp    r9,0x4
  40957f:	jb     4095f2 <__swc_fn_ff58629f_000111_3dc01326+0x152>
  409581:	lea    r9,[rcx+rax*1]
  409585:	lea    r10,[rdx+rax*1]
  409589:	mov    r9d,DWORD PTR [r9]
  40958c:	xor    r9d,DWORD PTR [r10]
  40958f:	test   r9d,r9d
  409592:	je     4095b0 <__swc_fn_ff58629f_000111_3dc01326+0x110>
  409594:	xor    r8d,r8d
  409597:	tzcnt  r8,r9
  40959c:	shr    r8,0x3
  4095a0:	add    rax,r8
  4095a3:	movzx  ecx,BYTE PTR [rcx+rax*1]
  4095a7:	movzx  eax,BYTE PTR [rdx+rax*1]
  4095ab:	sub    ecx,eax
  4095ad:	mov    eax,ecx
  4095af:	ret
  4095b0:	lea    rax,[rax+0x4]
  4095b4:	cmp    rax,r8
  4095b7:	jne    4095bc <__swc_fn_ff58629f_000111_3dc01326+0x11c>
  4095b9:	xor    eax,eax
  4095bb:	ret
  4095bc:	lea    rax,[r8-0x4]
  4095c0:	lea    r8,[rcx+rax*1]
  4095c4:	lea    r9,[rdx+rax*1]
  4095c8:	mov    r8d,DWORD PTR [r8]
  4095cb:	xor    r8d,DWORD PTR [r9]
  4095ce:	test   r8d,r8d
  4095d1:	je     4095ef <__swc_fn_ff58629f_000111_3dc01326+0x14f>
  4095d3:	xor    r9d,r9d
  4095d6:	tzcnt  r9,r8
  4095db:	shr    r9,0x3
  4095df:	add    rax,r9
  4095e2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  4095e6:	movzx  eax,BYTE PTR [rdx+rax*1]
  4095ea:	sub    ecx,eax
  4095ec:	mov    eax,ecx
  4095ee:	ret
  4095ef:	xor    eax,eax
  4095f1:	ret
  4095f2:	cmp    r9,0x2
  4095f6:	jb     409649 <__swc_fn_ff58629f_000111_3dc01326+0x1a9>
  4095f8:	lea    r9,[rcx+rax*1]
  4095fc:	lea    r10,[rdx+rax*1]
  409600:	mov    r9w,WORD PTR [r9]
  409604:	xor    r9w,WORD PTR [r10]
  409608:	test   r9w,r9w
  40960c:	je     40962e <__swc_fn_ff58629f_000111_3dc01326+0x18e>
  40960e:	xor    r8d,r8d
  409611:	movzx  r9d,r9w
  409615:	tzcnt  r8,r9
  40961a:	shr    r8,0x3
  40961e:	add    rax,r8
  409621:	movzx  ecx,BYTE PTR [rcx+rax*1]
  409625:	movzx  eax,BYTE PTR [rdx+rax*1]
  409629:	sub    ecx,eax
  40962b:	mov    eax,ecx
  40962d:	ret
  40962e:	lea    rax,[rax+0x2]
  409632:	cmp    rax,r8
  409635:	jne    40963a <__swc_fn_ff58629f_000111_3dc01326+0x19a>
  409637:	xor    eax,eax
  409639:	ret
  40963a:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  409640:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  409646:	sub    eax,ecx
  409648:	ret
  409649:	test   r9,r9
  40964c:	je     40965b <__swc_fn_ff58629f_000111_3dc01326+0x1bb>
  40964e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  409652:	movzx  eax,BYTE PTR [rdx+rax*1]
  409656:	sub    ecx,eax
  409658:	mov    eax,ecx
  40965a:	ret
  40965b:	xor    eax,eax
  40965d:	ret
	...

0000000000409660 <__swc_fn_ff58629f_000114_6b799b8d>:
  409660:	push   r12
  409662:	push   r13
  409664:	push   r14
  409666:	push   rdi
  409667:	push   rsi
  409668:	push   r15
  40966a:	sub    rsp,0xd8
  409671:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409677:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40967d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  409683:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  409689:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40968f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  409698:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  4096a1:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  4096aa:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  4096b3:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  4096bc:	mov    r12,rcx
  4096bf:	test   rcx,rcx
  4096c2:	je     4096de <__swc_fn_ff58629f_000114_6b799b8d+0x7e>
  4096c4:	mov    eax,r12d
  4096c7:	and    eax,0xfff
  4096cd:	setne  al
  4096d0:	cmp    r12,0xffffffffffffefff
  4096d7:	seta   cl
  4096da:	or     al,cl
  4096dc:	je     4096e5 <__swc_fn_ff58629f_000114_6b799b8d+0x85>
  4096de:	xor    eax,eax
  4096e0:	jmp    40977b <__swc_fn_ff58629f_000114_6b799b8d+0x11b>
  4096e5:	call   410b20 <__swc_fn_ff58629f_000113_126150d1>
  4096ea:	mov    r13,rax
  4096ed:	test   rax,rax
  4096f0:	jne    4096f9 <__swc_fn_ff58629f_000114_6b799b8d+0x99>
  4096f2:	xor    eax,eax
  4096f4:	jmp    40977b <__swc_fn_ff58629f_000114_6b799b8d+0x11b>
  4096f9:	lea    r14,[r12+0x1000]
  409701:	xor    edi,edi
  409703:	mov    rsi,r14
  409706:	xor    edx,edx
  409708:	mov    ecx,0x22
  40970d:	mov    eax,0xffffffff
  409712:	movsxd r8,eax
  409715:	xor    r9d,r9d
  409718:	xor    eax,eax
  40971a:	call   407010 <mmap@plt>
  40971f:	mov    r15,rax
  409722:	cmp    rax,0xffffffffffffffff
  409726:	jne    40972c <__swc_fn_ff58629f_000114_6b799b8d+0xcc>
  409728:	xor    eax,eax
  40972a:	jmp    40977b <__swc_fn_ff58629f_000114_6b799b8d+0x11b>
  40972c:	mov    rdi,r15
  40972f:	mov    esi,0x1000
  409734:	mov    edx,0x3
  409739:	xor    eax,eax
  40973b:	call   407020 <mprotect@plt>
  409740:	test   eax,eax
  409742:	je     409755 <__swc_fn_ff58629f_000114_6b799b8d+0xf5>
  409744:	mov    rdi,r15
  409747:	mov    rsi,r14
  40974a:	xor    eax,eax
  40974c:	call   407030 <munmap@plt>
  409751:	xor    eax,eax
  409753:	jmp    40977b <__swc_fn_ff58629f_000114_6b799b8d+0x11b>
  409755:	mov    QWORD PTR [r15+0x8],r12
  409759:	mov    rcx,r13
  40975c:	call   409db0 <__swc_fn_ff58629f_000138_8c07c14b>
  409761:	mov    rax,QWORD PTR [r13+0x8]
  409765:	mov    QWORD PTR [r15],rax
  409768:	mov    QWORD PTR [r13+0x8],r15
  40976c:	mov    rcx,r13
  40976f:	call   40d120 <__swc_fn_ff58629f_000139_715e84ff>
  409774:	lea    rax,[r15+0x1000]
  40977b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  409781:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  409787:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40978d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  409793:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  409799:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  4097a2:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  4097ab:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  4097b4:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  4097bd:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  4097c6:	add    rsp,0xd8
  4097cd:	pop    r15
  4097cf:	pop    rsi
  4097d0:	pop    rdi
  4097d1:	pop    r14
  4097d3:	pop    r13
  4097d5:	pop    r12
  4097d7:	ret
	...

00000000004097e0 <__swc_fn_ff58629f_000117_e9fc0224>:
  4097e0:	push   rbx
  4097e1:	push   r12
  4097e3:	push   rdi
  4097e4:	push   rsi
  4097e5:	sub    rsp,0xa8
  4097ec:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4097f2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4097f8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4097fe:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409804:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40980a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409810:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409816:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40981c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409825:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40982e:	mov    rbx,rdx
  409831:	mov    r12,rcx
  409834:	mov    rdi,rcx
  409837:	mov    rsi,rdx
  40983a:	xor    edx,edx
  40983c:	xor    eax,eax
  40983e:	call   407020 <mprotect@plt>
  409843:	test   eax,eax
  409845:	jne    409869 <__swc_fn_ff58629f_000117_e9fc0224+0x89>
  409847:	mov    rcx,r12
  40984a:	mov    rdx,rbx
  40984d:	xor    al,al
  40984f:	mov    r8,rax
  409852:	call   40cbc0 <__swc_fn_ff58629f_000115_5f48311c>
  409857:	mov    rdi,r12
  40985a:	mov    rsi,rbx
  40985d:	mov    edx,0x4
  409862:	xor    eax,eax
  409864:	call   407040 <madvise@plt>
  409869:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40986f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409875:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40987b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409881:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409887:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40988d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409893:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409899:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4098a2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4098ab:	add    rsp,0xa8
  4098b2:	pop    rsi
  4098b3:	pop    rdi
  4098b4:	pop    r12
  4098b6:	pop    rbx
  4098b7:	ret
	...

00000000004098c0 <__swc_fn_ff58629f_000120_d3318640>:
  4098c0:	push   rsi
  4098c1:	push   rdi
  4098c2:	push   r12
  4098c4:	push   r13
  4098c6:	push   r14
  4098c8:	sub    rsp,0xe0
  4098cf:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  4098d5:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  4098db:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  4098e1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  4098e7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  4098ed:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  4098f6:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  4098ff:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  409908:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  409911:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40991a:	mov    rsi,rdx
  40991d:	mov    rdi,rcx
  409920:	call   410b20 <__swc_fn_ff58629f_000113_126150d1>
  409925:	mov    r12,rax
  409928:	test   rax,rax
  40992b:	jne    409932 <__swc_fn_ff58629f_000120_d3318640+0x72>
  40992d:	jmp    4099a6 <__swc_fn_ff58629f_000120_d3318640+0xe6>
  409932:	mov    rcx,r12
  409935:	call   409db0 <__swc_fn_ff58629f_000138_8c07c14b>
  40993a:	lea    r13,[r12+0x8]
  40993f:	mov    rax,QWORD PTR [r13+0x0]
  409943:	test   rax,rax
  409946:	je     40999e <__swc_fn_ff58629f_000120_d3318640+0xde>
  409948:	nop    DWORD PTR [rax+rax*1+0x0]
  409950:	lea    rcx,[rax+0x1000]
  409957:	cmp    rcx,rdi
  40995a:	jne    409992 <__swc_fn_ff58629f_000120_d3318640+0xd2>
  40995c:	cmp    QWORD PTR [rax+0x8],rsi
  409960:	je     40996c <__swc_fn_ff58629f_000120_d3318640+0xac>
  409962:	mov    rcx,r12
  409965:	call   40d120 <__swc_fn_ff58629f_000139_715e84ff>
  40996a:	jmp    4099a6 <__swc_fn_ff58629f_000120_d3318640+0xe6>
  40996c:	mov    r14,QWORD PTR [rax]
  40996f:	mov    rdi,rax
  409972:	lea    rsi,[rsi+0x1000]
  409979:	xor    eax,eax
  40997b:	call   407030 <munmap@plt>
  409980:	test   eax,eax
  409982:	jne    409988 <__swc_fn_ff58629f_000120_d3318640+0xc8>
  409984:	mov    QWORD PTR [r13+0x0],r14
  409988:	mov    rcx,r12
  40998b:	call   40d120 <__swc_fn_ff58629f_000139_715e84ff>
  409990:	jmp    4099a6 <__swc_fn_ff58629f_000120_d3318640+0xe6>
  409992:	mov    r13,rax
  409995:	mov    rax,QWORD PTR [r13+0x0]
  409999:	test   rax,rax
  40999c:	jne    409950 <__swc_fn_ff58629f_000120_d3318640+0x90>
  40999e:	mov    rcx,r12
  4099a1:	call   40d120 <__swc_fn_ff58629f_000139_715e84ff>
  4099a6:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  4099ac:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  4099b2:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  4099b8:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  4099be:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  4099c4:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  4099cd:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  4099d6:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  4099df:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  4099e8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  4099f1:	add    rsp,0xe0
  4099f8:	pop    r14
  4099fa:	pop    r13
  4099fc:	pop    r12
  4099fe:	pop    rdi
  4099ff:	pop    rsi
  409a00:	ret
	...

0000000000409a10 <__swc_fn_ff58629f_000123_be2e2f68>:
  409a10:	push   rdi
  409a11:	push   rsi
  409a12:	sub    rsp,0xa8
  409a19:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409a1f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409a25:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409a2b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409a31:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409a37:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409a3d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409a43:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409a49:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409a52:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409a5b:	mov    rdi,0xfffffffffffffd66
  409a62:	xor    eax,eax
  409a64:	call   407050 <exit@plt>
  409a69:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409a6f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409a75:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409a7b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409a81:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409a87:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409a8d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409a93:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409a99:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409aa2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409aab:	add    rsp,0xa8
  409ab2:	pop    rsi
  409ab3:	pop    rdi
  409ab4:	ret
	...

0000000000409ac0 <__swc_fn_ff58629f_000126_540bf7e8>:
  409ac0:	push   rbx
  409ac1:	push   rsi
  409ac2:	push   rdi
  409ac3:	sub    rsp,0x30
  409ac7:	mov    rbx,rdx
  409aca:	mov    esi,ecx
  409acc:	test   ecx,ecx
  409ace:	je     409ba3 <__swc_fn_ff58629f_000126_540bf7e8+0xe3>
  409ad4:	mov    rcx,rsi
  409ad7:	shl    rcx,0x4
  409adb:	call   408fd0 <__swc_fn_ff58629f_000084_4a10c7e7>
  409ae0:	test   rax,rax
  409ae3:	je     409b92 <__swc_fn_ff58629f_000126_540bf7e8+0xd2>
  409ae9:	mov    rcx,rsi
  409aec:	xor    edx,edx
  409aee:	test   rsi,rsi
  409af1:	jbe    409b72 <__swc_fn_ff58629f_000126_540bf7e8+0xb2>
  409af7:	nop    WORD PTR [rax+rax*1+0x0]
  409b00:	mov    r8d,edx
  409b03:	mov    r9,QWORD PTR [rbx+r8*8]
  409b07:	add    r8,r8
  409b0a:	lea    r8,[rax+r8*8]
  409b0e:	xor    r10d,r10d
  409b11:	test   r9,r9
  409b14:	je     409b50 <__swc_fn_ff58629f_000126_540bf7e8+0x90>
  409b16:	mov    r11,r9
  409b19:	mov    dil,BYTE PTR [r11]
  409b1c:	test   dil,dil
  409b1f:	je     409b50 <__swc_fn_ff58629f_000126_540bf7e8+0x90>
  409b21:	cs nop WORD PTR [rax+rax*1+0x0]
  409b2b:	cs nop WORD PTR [rax+rax*1+0x0]
  409b35:	cs nop WORD PTR [rax+rax*1+0x0]
  409b3f:	nop
  409b40:	add    r11,0x1
  409b44:	add    r10,0x1
  409b48:	mov    dil,BYTE PTR [r11]
  409b4b:	test   dil,dil
  409b4e:	jne    409b40 <__swc_fn_ff58629f_000126_540bf7e8+0x80>
  409b50:	mov    QWORD PTR [rsp+0x18],r9
  409b55:	mov    QWORD PTR [rsp+0x20],r10
  409b5a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409b60:	vmovups XMMWORD PTR [r8],xmm0
  409b65:	add    rdx,0x1
  409b69:	cmp    rdx,rcx
  409b6c:	jb     409b00 <__swc_fn_ff58629f_000126_540bf7e8+0x40>
  409b72:	lea    rcx,[rip+0x1c1cf]        # 425d48 <__swc_bss_base_ff58629f+0x2d08>
  409b79:	mov    QWORD PTR [rsp+0x8],rax
  409b7e:	mov    esi,esi
  409b80:	mov    QWORD PTR [rsp+0x10],rsi
  409b85:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409b8b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409b90:	jmp    409ba3 <__swc_fn_ff58629f_000126_540bf7e8+0xe3>
  409b92:	lea    rcx,[rip+0x8a57]        # 4125f0 <__swc_rdata_base_ff58629f+0x4e0>
  409b99:	call   40cc70 <__swc_fn_ff58629f_000121_2648f149>
  409b9e:	call   409a10 <__swc_fn_ff58629f_000123_be2e2f68>
  409ba3:	add    rsp,0x30
  409ba7:	pop    rdi
  409ba8:	pop    rsi
  409ba9:	pop    rbx
  409baa:	ret
  409bab:	add    BYTE PTR [rax],al
  409bad:	add    BYTE PTR [rax],al
	...

0000000000409bb0 <__swc_fn_ff58629f_000129_a481cb88>:
  409bb0:	push   rdi
  409bb1:	push   rsi
  409bb2:	sub    rsp,0xa8
  409bb9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409bbf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409bc5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409bcb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409bd1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409bd7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409bdd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409be3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409be9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409bf2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409bfb:	mov    edi,ecx
  409bfd:	xor    eax,eax
  409bff:	call   407060 <pthread_key_delete@plt>
  409c04:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409c0a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409c10:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409c16:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409c1c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409c22:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409c28:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409c2e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409c34:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409c3d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409c46:	add    rsp,0xa8
  409c4d:	pop    rsi
  409c4e:	pop    rdi
  409c4f:	ret

0000000000409c50 <__swc_fn_ff58629f_000132_a611b8c4>:
  409c50:	push   rdi
  409c51:	push   rsi
  409c52:	sub    rsp,0xa8
  409c59:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409c5f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409c65:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409c6b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409c71:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409c77:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409c7d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409c83:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409c89:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409c92:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409c9b:	test   rcx,rcx
  409c9e:	je     409caf <__swc_fn_ff58629f_000132_a611b8c4+0x5f>
  409ca0:	lea    rax,[rcx-0x1]
  409ca4:	mov    eax,eax
  409ca6:	mov    edi,eax
  409ca8:	xor    eax,eax
  409caa:	call   407060 <pthread_key_delete@plt>
  409caf:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409cb5:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409cbb:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409cc1:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409cc7:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409ccd:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409cd3:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409cd9:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409cdf:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409ce8:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409cf1:	add    rsp,0xa8
  409cf8:	pop    rsi
  409cf9:	pop    rdi
  409cfa:	ret
  409cfb:	add    BYTE PTR [rax],al
  409cfd:	add    BYTE PTR [rax],al
	...

0000000000409d00 <__swc_fn_ff58629f_000135_a9c1c700>:
  409d00:	push   rsi
  409d01:	push   rdi
  409d02:	sub    rsp,0xa8
  409d09:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409d0f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409d15:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409d1b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409d21:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409d27:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409d2d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409d33:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409d39:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409d42:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409d4b:	xor    eax,eax
  409d4d:	call   407070 <gettid@plt>
  409d52:	movsxd rax,eax
  409d55:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409d5b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409d61:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409d67:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409d6d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409d73:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409d79:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409d7f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409d85:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409d8e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409d97:	add    rsp,0xa8
  409d9e:	pop    rdi
  409d9f:	pop    rsi
  409da0:	ret
	...

0000000000409db0 <__swc_fn_ff58629f_000138_8c07c14b>:
  409db0:	push   rbx
  409db1:	push   rdi
  409db2:	push   rsi
  409db3:	sub    rsp,0xc0
  409dba:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409dc0:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409dc6:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409dcc:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409dd2:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409dd8:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409dde:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409de4:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409ded:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409df6:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409dff:	mov    rbx,rcx
  409e02:	cs nop WORD PTR [rax+rax*1+0x0]
  409e0c:	nop    DWORD PTR [rax+0x0]
  409e10:	mov    edx,0x80000000
  409e15:	xor    eax,eax
  409e17:	lock cmpxchg DWORD PTR [rbx],edx
  409e1b:	test   eax,eax
  409e1d:	je     409e54 <__swc_fn_ff58629f_000138_8c07c14b+0xa4>
  409e1f:	mov    eax,DWORD PTR [rbx]
  409e21:	lea    rcx,[rsp+0x14]
  409e26:	mov    DWORD PTR [rsp+0x14],eax
  409e2a:	test   eax,eax
  409e2c:	je     409e10 <__swc_fn_ff58629f_000138_8c07c14b+0x60>
  409e2e:	mov    QWORD PTR [rsp],0x0
  409e36:	mov    edi,0xca
  409e3b:	mov    rsi,rbx
  409e3e:	mov    edx,0x80
  409e43:	mov    ecx,DWORD PTR [rcx]
  409e45:	xor    r8d,r8d
  409e48:	xor    r9d,r9d
  409e4b:	xor    eax,eax
  409e4d:	call   407080 <syscall@plt>
  409e52:	jmp    409e10 <__swc_fn_ff58629f_000138_8c07c14b+0x60>
  409e54:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409e5a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409e60:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409e66:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409e6c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409e72:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409e78:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409e7e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409e87:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409e90:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409e99:	add    rsp,0xc0
  409ea0:	pop    rsi
  409ea1:	pop    rdi
  409ea2:	pop    rbx
  409ea3:	ret
	...

0000000000409eb0 <__swc_fn_ff58629f_000141_055b38a4>:
  409eb0:	sub    rsp,0x8
  409eb4:	call   40d120 <__swc_fn_ff58629f_000139_715e84ff>
  409eb9:	add    rsp,0x8
  409ebd:	ret
	...

0000000000409ec0 <__swc_fn_ff58629f_000144_d299b428>:
  409ec0:	push   rdi
  409ec1:	push   rsi
  409ec2:	sub    rsp,0xa8
  409ec9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409ecf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409ed5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409edb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409ee1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409ee7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409eed:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409ef3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409ef9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409f02:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409f0b:	mov    edi,0x28
  409f10:	xor    eax,eax
  409f12:	call   407090 <malloc@plt>
  409f17:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409f1d:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409f23:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409f29:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409f2f:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409f35:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409f3b:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409f41:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409f47:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409f50:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409f59:	add    rsp,0xa8
  409f60:	pop    rsi
  409f61:	pop    rdi
  409f62:	ret
	...

0000000000409f70 <__swc_fn_ff58629f_000147_162f363d>:
  409f70:	mov    QWORD PTR [r8],0x0
  409f77:	cmp    rdx,0x10
  409f7b:	jae    409f80 <__swc_fn_ff58629f_000147_162f363d+0x10>
  409f7d:	xor    eax,eax
  409f7f:	ret
  409f80:	mov    eax,DWORD PTR [rcx]
  409f82:	cmp    eax,0x42445753
  409f88:	jne    409f92 <__swc_fn_ff58629f_000147_162f363d+0x22>
  409f8a:	mov    eax,DWORD PTR [rcx+0x4]
  409f8d:	cmp    eax,0x1
  409f90:	je     409f95 <__swc_fn_ff58629f_000147_162f363d+0x25>
  409f92:	xor    eax,eax
  409f94:	ret
  409f95:	mov    QWORD PTR [r8],rdx
  409f98:	mov    rax,rcx
  409f9b:	ret
  409f9c:	add    BYTE PTR [rax],al
	...

0000000000409fa0 <__swc_fn_ff58629f_000150_2eb804cc>:
  409fa0:	push   rbx
  409fa1:	sub    rsp,0xe0
  409fa8:	lea    rbx,[rsp+0x8]
  409fad:	vxorps xmm0,xmm0,xmm0
  409fb1:	vmovups YMMWORD PTR [rbx],ymm0
  409fb5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  409fba:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  409fbf:	vzeroupper
  409fc2:	mov    DWORD PTR [rbx+0x60],0x0
  409fc9:	mov    r8,rbx
  409fcc:	mov    rdx,rcx
  409fcf:	nop
  409fd0:	mov    r9,rdx
  409fd3:	movabs rdx,0x6666666666666667
  409fdd:	mov    rax,r9
  409fe0:	imul   rdx
  409fe3:	sar    rdx,0x2
  409fe7:	mov    r10,rdx
  409fea:	shr    rdx,0x3f
  409fee:	add    r10,rdx
  409ff1:	mov    rdx,r10
  409ff4:	imul   r11,r10,0xa
  409ff8:	sub    r9,r11
  409ffb:	mov    r11,QWORD PTR [rip+0x860e]        # 412610 <__swc_rdata_base_ff58629f+0x500>
  40a002:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40a007:	mov    BYTE PTR [r8],r9b
  40a00a:	lea    r9,[r8+0x1]
  40a00e:	mov    r8,r9
  40a011:	test   r10,r10
  40a014:	jne    409fd0 <__swc_fn_ff58629f_000150_2eb804cc+0x30>
  40a016:	test   rcx,rcx
  40a019:	jge    40a023 <__swc_fn_ff58629f_000150_2eb804cc+0x83>
  40a01b:	mov    BYTE PTR [r9],0x2d
  40a01f:	add    r8,0x1
  40a023:	mov    BYTE PTR [r8],0x0
  40a027:	sub    r8,0x1
  40a02b:	mov    rax,rbx
  40a02e:	cmp    rax,r8
  40a031:	jae    40a056 <__swc_fn_ff58629f_000150_2eb804cc+0xb6>
  40a033:	cs nop WORD PTR [rax+rax*1+0x0]
  40a03d:	nop    DWORD PTR [rax]
  40a040:	mov    cl,BYTE PTR [r8]
  40a043:	mov    dl,BYTE PTR [rax]
  40a045:	mov    BYTE PTR [r8],dl
  40a048:	sub    r8,0x1
  40a04c:	mov    BYTE PTR [rax],cl
  40a04e:	inc    rax
  40a051:	cmp    rax,r8
  40a054:	jb     40a040 <__swc_fn_ff58629f_000150_2eb804cc+0xa0>
  40a056:	xor    eax,eax
  40a058:	test   rbx,rbx
  40a05b:	je     40a07e <__swc_fn_ff58629f_000150_2eb804cc+0xde>
  40a05d:	mov    rcx,rbx
  40a060:	mov    dl,BYTE PTR [rcx]
  40a062:	test   dl,dl
  40a064:	je     40a07e <__swc_fn_ff58629f_000150_2eb804cc+0xde>
  40a066:	cs nop WORD PTR [rax+rax*1+0x0]
  40a070:	add    rcx,0x1
  40a074:	add    rax,0x1
  40a078:	mov    dl,BYTE PTR [rcx]
  40a07a:	test   dl,dl
  40a07c:	jne    40a070 <__swc_fn_ff58629f_000150_2eb804cc+0xd0>
  40a07e:	mov    QWORD PTR [rbx+0xa8],rbx
  40a085:	mov    QWORD PTR [rbx+0xb0],rax
  40a08c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40a094:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40a09c:	lea    rcx,[rbx+0xb8]
  40a0a3:	call   40cc70 <__swc_fn_ff58629f_000121_2648f149>
  40a0a8:	add    rsp,0xe0
  40a0af:	pop    rbx
  40a0b0:	ret
	...

000000000040a0c0 <__swc_fn_ff58629f_000153_86f1d437>:
  40a0c0:	vxorps xmm0,xmm0,xmm0
  40a0c4:	vmovups XMMWORD PTR [rcx],xmm0
  40a0c8:	mov    QWORD PTR [rcx+0x10],0x0
  40a0d0:	ret
	...

000000000040a0e0 <__swc_fn_ff58629f_000156_86f1d437>:
  40a0e0:	vxorps xmm0,xmm0,xmm0
  40a0e4:	vmovups XMMWORD PTR [rcx],xmm0
  40a0e8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a0ed:	vxorps xmm0,xmm0,xmm0
  40a0f1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a0f6:	vmovups xmm0,XMMWORD PTR [rip+0x860a]        # 412708 <__swc_rdata_base_ff58629f+0x5f8>
  40a0fe:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a103:	vxorps xmm0,xmm0,xmm0
  40a107:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40a10c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40a111:	mov    QWORD PTR [rcx+0x60],0x0
  40a119:	ret
  40a11a:	add    BYTE PTR [rax],al
  40a11c:	add    BYTE PTR [rax],al
	...

000000000040a120 <__swc_fn_ff58629f_000159_86f1d437>:
  40a120:	vxorps xmm0,xmm0,xmm0
  40a124:	vmovups XMMWORD PTR [rcx],xmm0
  40a128:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a12d:	vxorps xmm0,xmm0,xmm0
  40a131:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a136:	vmovups xmm0,XMMWORD PTR [rip+0x86f2]        # 412830 <__swc_rdata_base_ff58629f+0x720>
  40a13e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a143:	vxorps xmm0,xmm0,xmm0
  40a147:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40a14c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40a151:	vxorps xmm0,xmm0,xmm0
  40a155:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40a15a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40a15f:	vxorps xmm0,xmm0,xmm0
  40a163:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40a16b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40a173:	vxorps xmm0,xmm0,xmm0
  40a177:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40a17f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40a187:	vxorps xmm0,xmm0,xmm0
  40a18b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40a193:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40a19b:	mov    QWORD PTR [rcx+0xe0],0x0
  40a1a6:	ret
	...

000000000040a1b0 <__swc_fn_ff58629f_000162_13ead2ff>:
  40a1b0:	push   rbx
  40a1b1:	mov    rbx,rcx
  40a1b4:	call   40e6b0 <__swc_fn_ff58629f_000163_e36363a8>
  40a1b9:	mov    rax,QWORD PTR [rbx+0x10]
  40a1bd:	test   rax,rax
  40a1c0:	je     40a1d1 <__swc_fn_ff58629f_000162_13ead2ff+0x21>
  40a1c2:	mov    rcx,rbx
  40a1c5:	mov    rdx,rax
  40a1c8:	mov    r8,QWORD PTR [rbx+0x18]
  40a1cc:	call   4118b0 <__swc_fn_ff58629f_000161_47b270e1>
  40a1d1:	vxorps xmm0,xmm0,xmm0
  40a1d5:	vmovups XMMWORD PTR [rbx],xmm0
  40a1d9:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a1de:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a1e3:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40a1e8:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40a1ed:	mov    QWORD PTR [rbx+0x50],0x0
  40a1f5:	pop    rbx
  40a1f6:	ret
	...

000000000040a200 <__swc_fn_ff58629f_000165_72795826>:
  40a200:	sub    rsp,0x10
  40a204:	mov    eax,r8d
  40a207:	mov    r8d,r9d
  40a20a:	test   r9d,r9d
  40a20d:	jne    40a226 <__swc_fn_ff58629f_000165_72795826+0x26>
  40a20f:	vmovups xmm0,XMMWORD PTR [rip+0x86d1]        # 4128e8 <__swc_rdata_base_ff58629f+0x7d8>
  40a217:	vmovups XMMWORD PTR [r10],xmm0
  40a21c:	mov    eax,0x1
  40a221:	add    rsp,0x10
  40a225:	ret
  40a226:	mov    r9,r8
  40a229:	cmp    r8,rax
  40a22c:	jb     40a233 <__swc_fn_ff58629f_000165_72795826+0x33>
  40a22e:	cmp    r9,rdx
  40a231:	jb     40a23a <__swc_fn_ff58629f_000165_72795826+0x3a>
  40a233:	xor    eax,eax
  40a235:	add    rsp,0x10
  40a239:	ret
  40a23a:	xor    eax,eax
  40a23c:	lea    r8,[r9+rax*1]
  40a240:	cmp    r8,rdx
  40a243:	jae    40a273 <__swc_fn_ff58629f_000165_72795826+0x73>
  40a245:	cs nop WORD PTR [rax+rax*1+0x0]
  40a24f:	cs nop WORD PTR [rax+rax*1+0x0]
  40a259:	nop    DWORD PTR [rax+0x0]
  40a260:	cmp    BYTE PTR [rcx+r8*1],0x0
  40a265:	je     40a273 <__swc_fn_ff58629f_000165_72795826+0x73>
  40a267:	inc    rax
  40a26a:	lea    r8,[r9+rax*1]
  40a26e:	cmp    r8,rdx
  40a271:	jb     40a260 <__swc_fn_ff58629f_000165_72795826+0x60>
  40a273:	cmp    r8,rdx
  40a276:	jne    40a27f <__swc_fn_ff58629f_000165_72795826+0x7f>
  40a278:	xor    eax,eax
  40a27a:	add    rsp,0x10
  40a27e:	ret
  40a27f:	add    rcx,r9
  40a282:	mov    QWORD PTR [rsp],rcx
  40a286:	mov    QWORD PTR [rsp+0x8],rax
  40a28b:	vmovups xmm0,XMMWORD PTR [rsp]
  40a290:	vmovups XMMWORD PTR [r10],xmm0
  40a295:	mov    eax,0x1
  40a29a:	add    rsp,0x10
  40a29e:	ret
	...

000000000040a2a0 <__swc_fn_ff58629f_000168_bcc835b8>:
  40a2a0:	push   rbp
  40a2a1:	push   rbx
  40a2a2:	push   rsi
  40a2a3:	push   rdi
  40a2a4:	push   r12
  40a2a6:	push   r13
  40a2a8:	push   r14
  40a2aa:	push   r15
  40a2ac:	sub    rsp,0x10
  40a2b0:	mov    rbp,rsp
  40a2b3:	vmovups XMMWORD PTR [rsp],xmm6
  40a2b8:	sub    rsp,0x50
  40a2bc:	mov    rbx,rsp
  40a2bf:	mov    rsi,r8
  40a2c2:	mov    QWORD PTR [rsp+0x30],r8
  40a2c7:	mov    rdi,rcx
  40a2ca:	mov    QWORD PTR [rsp+0x38],rcx
  40a2cf:	mov    r12,rdx
  40a2d2:	xor    r13b,r13b
  40a2d5:	mov    r14,QWORD PTR [rdi+0x8]
  40a2d9:	mov    QWORD PTR [rsp+0x40],r14
  40a2de:	xor    r15d,r15d
  40a2e1:	test   r14,r14
  40a2e4:	jbe    40a53e <__swc_fn_ff58629f_000168_bcc835b8+0x29e>
  40a2ea:	mov    r14,QWORD PTR [rdi]
  40a2ed:	mov    rax,QWORD PTR [rsp+0x40]
  40a2f2:	mov    QWORD PTR [rsp+0x48],r14
  40a2f7:	vmovups xmm6,XMMWORD PTR [rip+0x8209]        # 412508 <__swc_rdata_base_ff58629f+0x3f8>
  40a2ff:	nop
  40a300:	cmp    QWORD PTR [r14+r15*8],0x0
  40a305:	jne    40a30f <__swc_fn_ff58629f_000168_bcc835b8+0x6f>
  40a307:	mov    r14,rax
  40a30a:	jmp    40a51e <__swc_fn_ff58629f_000168_bcc835b8+0x27e>
  40a30f:	mov    rcx,QWORD PTR [rdi]
  40a312:	mov    rdx,QWORD PTR [rcx+r15*8]
  40a316:	mov    rdi,rbx
  40a319:	mov    rcx,rdi
  40a31c:	sub    rsp,0x8
  40a320:	mov    r14,rax
  40a323:	call   411930 <__swc_fn_ff58629f_000167_cc119975>
  40a328:	add    rsp,0x8
  40a32c:	mov    al,BYTE PTR [rbx]
  40a32e:	test   al,al
  40a330:	je     40a51e <__swc_fn_ff58629f_000168_bcc835b8+0x27e>
  40a336:	mov    al,BYTE PTR [rbx+0x1]
  40a339:	test   al,al
  40a33b:	jne    40a346 <__swc_fn_ff58629f_000168_bcc835b8+0xa6>
  40a33d:	test   sil,sil
  40a340:	je     40a51e <__swc_fn_ff58629f_000168_bcc835b8+0x27e>
  40a346:	test   r13b,r13b
  40a349:	jne    40a407 <__swc_fn_ff58629f_000168_bcc835b8+0x167>
  40a34f:	test   r12,r12
  40a352:	je     40a407 <__swc_fn_ff58629f_000168_bcc835b8+0x167>
  40a358:	mov    al,BYTE PTR [rbx+0x1]
  40a35b:	test   al,al
  40a35d:	je     40a51e <__swc_fn_ff58629f_000168_bcc835b8+0x27e>
  40a363:	mov    eax,DWORD PTR [rbx+0x28]
  40a366:	cmp    DWORD PTR [r12+0x20],eax
  40a36b:	jne    40a51e <__swc_fn_ff58629f_000168_bcc835b8+0x27e>
  40a371:	mov    rax,QWORD PTR [r12]
  40a375:	mov    rcx,QWORD PTR [r12+0x8]
  40a37a:	cmp    QWORD PTR [rbx+0x20],rcx
  40a37e:	jne    40a51e <__swc_fn_ff58629f_000168_bcc835b8+0x27e>
  40a384:	mov    cl,0x1
  40a386:	test   rax,rax
  40a389:	je     40a3f2 <__swc_fn_ff58629f_000168_bcc835b8+0x152>
  40a38f:	mov    rdx,QWORD PTR [rbx+0x20]
  40a393:	xor    r8d,r8d
  40a396:	test   rdx,rdx
  40a399:	jbe    40a3f2 <__swc_fn_ff58629f_000168_bcc835b8+0x152>
  40a39b:	mov    r9,QWORD PTR [rbx+0x18]
  40a39f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40a3a4:	cs nop WORD PTR [rax+rax*1+0x0]
  40a3ae:	xchg   ax,ax
  40a3b0:	mov    r10b,BYTE PTR [rax+r8*1]
  40a3b4:	cmp    BYTE PTR [r9+r8*1],r10b
  40a3b8:	je     40a3e9 <__swc_fn_ff58629f_000168_bcc835b8+0x149>
  40a3ba:	vmovq  r10,xmm0
  40a3bf:	cmp    BYTE PTR [r10+r8*1],0x5c
  40a3c4:	jne    40a3cd <__swc_fn_ff58629f_000168_bcc835b8+0x12d>
  40a3c6:	cmp    BYTE PTR [rax+r8*1],0x2f
  40a3cb:	je     40a3e9 <__swc_fn_ff58629f_000168_bcc835b8+0x149>
  40a3cd:	vmovq  r10,xmm0
  40a3d2:	cmp    BYTE PTR [r10+r8*1],0x2f
  40a3d7:	jne    40a3e0 <__swc_fn_ff58629f_000168_bcc835b8+0x140>
  40a3d9:	cmp    BYTE PTR [rax+r8*1],0x5c
  40a3de:	je     40a3e9 <__swc_fn_ff58629f_000168_bcc835b8+0x149>
  40a3e0:	xor    eax,eax
  40a3e2:	movzx  eax,al
  40a3e5:	mov    cl,al
  40a3e7:	jmp    40a3f2 <__swc_fn_ff58629f_000168_bcc835b8+0x152>
  40a3e9:	add    r8,0x1
  40a3ed:	cmp    r8,rdx
  40a3f0:	jb     40a3b0 <__swc_fn_ff58629f_000168_bcc835b8+0x110>
  40a3f2:	test   cl,cl
  40a3f4:	je     40a51e <__swc_fn_ff58629f_000168_bcc835b8+0x27e>
  40a3fa:	mov    eax,0x1
  40a3ff:	mov    r13b,al
  40a402:	jmp    40a51e <__swc_fn_ff58629f_000168_bcc835b8+0x27e>
  40a407:	mov    r13b,0x1
  40a40a:	sub    rsp,0x20
  40a40e:	mov    rax,rsp
  40a411:	lea    rcx,[rdi+0x8]
  40a415:	mov    QWORD PTR [rax],rcx
  40a418:	lea    rsi,[rip+0x7d11]        # 412130 <__swc_rdata_base_ff58629f+0x20>
  40a41f:	mov    QWORD PTR [rax+0x8],rsi
  40a423:	mov    QWORD PTR [rax+0x10],rsp
  40a427:	mov    QWORD PTR [rax+0x18],0x1
  40a42f:	lea    rcx,[rsp+0x10]
  40a434:	sub    rsp,0x8
  40a438:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  40a43d:	add    rsp,0x8
  40a441:	add    rsp,0x20
  40a445:	mov    al,BYTE PTR [rbx+0x1]
  40a448:	test   al,al
  40a44a:	je     40a4e7 <__swc_fn_ff58629f_000168_bcc835b8+0x247>
  40a450:	lea    rax,[rip+0x8531]        # 412988 <__swc_rdata_base_ff58629f+0x878>
  40a457:	sub    rsp,0x20
  40a45b:	mov    rcx,rsp
  40a45e:	mov    QWORD PTR [rcx],rax
  40a461:	mov    QWORD PTR [rcx+0x8],rsi
  40a465:	mov    QWORD PTR [rcx+0x10],rsp
  40a469:	mov    QWORD PTR [rcx+0x18],0x1
  40a471:	lea    rcx,[rsp+0x10]
  40a476:	sub    rsp,0x8
  40a47a:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  40a47f:	add    rsp,0x8
  40a483:	add    rsp,0x20
  40a487:	mov    eax,DWORD PTR [rbx+0x28]
  40a48a:	sub    rsp,0x60
  40a48e:	mov    rcx,rsp
  40a491:	lea    rdx,[rdi+0x18]
  40a495:	mov    QWORD PTR [rcx+0x18],rdx
  40a499:	mov    QWORD PTR [rcx+0x20],rsi
  40a49d:	vmovups XMMWORD PTR [rcx],xmm6
  40a4a1:	mov    QWORD PTR [rcx+0x28],rsp
  40a4a5:	mov    QWORD PTR [rcx+0x30],rsi
  40a4a9:	mov    DWORD PTR [rcx+0x10],eax
  40a4ac:	lea    rax,[rsp+0x10]
  40a4b1:	mov    QWORD PTR [rcx+0x38],rax
  40a4b5:	lea    rax,[rip+0x7fe4]        # 4124a0 <__swc_rdata_base_ff58629f+0x390>
  40a4bc:	mov    QWORD PTR [rcx+0x40],rax
  40a4c0:	lea    rax,[rsp+0x18]
  40a4c5:	mov    QWORD PTR [rcx+0x48],rax
  40a4c9:	mov    QWORD PTR [rcx+0x50],0x3
  40a4d1:	lea    rcx,[rsp+0x48]
  40a4d6:	sub    rsp,0x8
  40a4da:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  40a4df:	add    rsp,0x8
  40a4e3:	add    rsp,0x60
  40a4e7:	lea    rax,[rip+0x7c32]        # 412120 <__swc_rdata_base_ff58629f+0x10>
  40a4ee:	sub    rsp,0x20
  40a4f2:	mov    rcx,rsp
  40a4f5:	mov    QWORD PTR [rcx],rax
  40a4f8:	mov    QWORD PTR [rcx+0x8],rsi
  40a4fc:	mov    QWORD PTR [rcx+0x10],rsp
  40a500:	mov    QWORD PTR [rcx+0x18],0x1
  40a508:	lea    rcx,[rsp+0x10]
  40a50d:	sub    rsp,0x8
  40a511:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  40a516:	add    rsp,0x8
  40a51a:	add    rsp,0x20
  40a51e:	add    r15,0x1
  40a522:	cmp    r15,r14
  40a525:	jae    40a53e <__swc_fn_ff58629f_000168_bcc835b8+0x29e>
  40a527:	mov    rsi,QWORD PTR [rsp+0x30]
  40a52c:	mov    rdi,QWORD PTR [rsp+0x38]
  40a531:	mov    rax,r14
  40a534:	mov    r14,QWORD PTR [rsp+0x48]
  40a539:	jmp    40a300 <__swc_fn_ff58629f_000168_bcc835b8+0x60>
  40a53e:	add    rsp,0x50
  40a542:	vmovups xmm6,XMMWORD PTR [rsp]
  40a547:	add    rsp,0x10
  40a54b:	pop    r15
  40a54d:	pop    r14
  40a54f:	pop    r13
  40a551:	pop    r12
  40a553:	pop    rdi
  40a554:	pop    rsi
  40a555:	pop    rbx
  40a556:	pop    rbp
  40a557:	ret
	...

000000000040a560 <__swc_fn_ff58629f_000171_646fdf20>:
  40a560:	sub    rsp,0x8
  40a564:	call   40cef0 <__swc_fn_ff58629f_000130_4bbe3f14>
  40a569:	add    rsp,0x8
  40a56d:	ret
	...

000000000040a570 <__swc_fn_ff58629f_000174_1e0ea8cf>:
  40a570:	push   rsi
  40a571:	sub    rsp,0x30
  40a575:	lea    rsi,[rip+0x1b81c]        # 425d98 <__swc_bss_base_ff58629f+0x2d58>
  40a57c:	mov    rax,QWORD PTR [rsi]
  40a57f:	test   rax,rax
  40a582:	je     40a58a <__swc_fn_ff58629f_000174_1e0ea8cf+0x1a>
  40a584:	add    rsp,0x30
  40a588:	pop    rsi
  40a589:	ret
  40a58a:	mov    ecx,0x2
  40a58f:	mov    edx,0x8020
  40a594:	call   40c590 <__swc_fn_ff58629f_000112_6814119b>
  40a599:	test   rax,rax
  40a59c:	jne    40a5ad <__swc_fn_ff58629f_000174_1e0ea8cf+0x3d>
  40a59e:	mov    QWORD PTR [rsp+0x18],rax
  40a5a3:	call   409a10 <__swc_fn_ff58629f_000123_be2e2f68>
  40a5a8:	mov    rax,QWORD PTR [rsp+0x18]
  40a5ad:	mov    rcx,rax
  40a5b0:	xchg   QWORD PTR [rsi],rcx
  40a5b3:	add    rsp,0x30
  40a5b7:	pop    rsi
  40a5b8:	ret
  40a5b9:	add    BYTE PTR [rax],al
  40a5bb:	add    BYTE PTR [rax],al
  40a5bd:	add    BYTE PTR [rax],al
	...

000000000040a5c0 <__swc_fn_ff58629f_000177_4de704de>:
  40a5c0:	push   rsi
  40a5c1:	test   r8,r8
  40a5c4:	jne    40a5c8 <__swc_fn_ff58629f_000177_4de704de+0x8>
  40a5c6:	pop    rsi
  40a5c7:	ret
  40a5c8:	lea    rax,[rcx+0x18]
  40a5cc:	mov    r10,QWORD PTR [rax]
  40a5cf:	lea    r11,[r10+0x1]
  40a5d3:	mov    QWORD PTR [rax],r11
  40a5d6:	mov    r11,rdx
  40a5d9:	not    rdx
  40a5dc:	lea    rsi,[r8-0x1]
  40a5e0:	cmp    rsi,rdx
  40a5e3:	ja     40a603 <__swc_fn_ff58629f_000177_4de704de+0x43>
  40a5e5:	lea    rdx,[r11+r8*1]
  40a5e9:	dec    rdx
  40a5ec:	shr    rdx,0x6
  40a5f0:	mov    r8,r11
  40a5f3:	shr    r8,0x6
  40a5f7:	mov    rsi,rdx
  40a5fa:	sub    rsi,r8
  40a5fd:	cmp    rsi,0x8
  40a601:	jb     40a619 <__swc_fn_ff58629f_000177_4de704de+0x59>
  40a603:	lea    rcx,[rcx+0x10]
  40a607:	mov    rdx,QWORD PTR [rcx]
  40a60a:	add    rdx,r9
  40a60d:	mov    QWORD PTR [rcx],rdx
  40a610:	lea    rcx,[r10+0x2]
  40a614:	mov    QWORD PTR [rax],rcx
  40a617:	pop    rsi
  40a618:	ret
  40a619:	shr    r11,0x6
  40a61d:	nop    DWORD PTR [rax]
  40a620:	cmp    r11,rdx
  40a623:	ja     40a663 <__swc_fn_ff58629f_000177_4de704de+0xa3>
  40a625:	jmp    40a636 <__swc_fn_ff58629f_000177_4de704de+0x76>
  40a627:	nop    WORD PTR [rax+rax*1+0x0]
  40a630:	add    r11,0x1
  40a634:	jmp    40a620 <__swc_fn_ff58629f_000177_4de704de+0x60>
  40a636:	mov    r8,r11
  40a639:	shr    r8,0xc
  40a63d:	mov    rsi,r11
  40a640:	xor    rsi,r8
  40a643:	mov    r8,r11
  40a646:	shr    r8,0x18
  40a64a:	xor    rsi,r8
  40a64d:	and    esi,0xfff
  40a653:	lea    r8,[rcx+rsi*8+0x20]
  40a658:	mov    rsi,QWORD PTR [r8]
  40a65b:	add    rsi,r9
  40a65e:	mov    QWORD PTR [r8],rsi
  40a661:	jmp    40a630 <__swc_fn_ff58629f_000177_4de704de+0x70>
  40a663:	lea    rcx,[r10+0x2]
  40a667:	mov    QWORD PTR [rax],rcx
  40a66a:	pop    rsi
  40a66b:	ret
	...

000000000040a680 <__swc_fn_ff58629f_000001_5d3d19bd>:
  40a680:	push   rbx
  40a681:	sub    rsp,0x70
  40a685:	test   rcx,rcx
  40a688:	jne    40a690 <__swc_fn_ff58629f_000001_5d3d19bd+0x10>
  40a68a:	add    rsp,0x70
  40a68e:	pop    rbx
  40a68f:	ret
  40a690:	vxorps xmm0,xmm0,xmm0
  40a694:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40a69a:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40a6a0:	vzeroupper
  40a6a3:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40a6a9:	lea    rax,[rcx-0x10]
  40a6ad:	mov    QWORD PTR [rsp+0x48],rax
  40a6b2:	mov    rax,QWORD PTR [rcx-0x10]
  40a6b6:	mov    QWORD PTR [rsp+0x50],rax
  40a6bb:	mov    rcx,QWORD PTR [rip+0x1897e]        # 423040 <__swc_bss_base_ff58629f>
  40a6c2:	test   rcx,rcx
  40a6c5:	jne    40a6d7 <__swc_fn_ff58629f_000001_5d3d19bd+0x57>
  40a6c7:	call   411bc0 <__swc_fn_ff58629f_000170_994c8876>
  40a6cc:	lea    rcx,[rax+0x1]
  40a6d0:	mov    QWORD PTR [rip+0x18969],rcx        # 423040 <__swc_bss_base_ff58629f>
  40a6d7:	dec    rcx
  40a6da:	call   40ea20 <__swc_fn_ff58629f_000172_360af05d>
  40a6df:	mov    rcx,QWORD PTR [rax]
  40a6e2:	lea    rdx,[rsp+0x8]
  40a6e7:	mov    rbx,QWORD PTR [rax+0x8]
  40a6eb:	mov    rbx,QWORD PTR [rbx+0x18]
  40a6ef:	call   rbx
  40a6f1:	add    rsp,0x70
  40a6f5:	pop    rbx
  40a6f6:	ret
	...

000000000040a700 <__swc_fn_ff58629f_000004_05d3c06b>:
  40a700:	push   rbp
  40a701:	push   rsi
  40a702:	push   rdi
  40a703:	sub    rsp,0x18
  40a707:	mov    rbp,rsp
  40a70a:	vmovups XMMWORD PTR [rsp],xmm6
  40a70f:	sub    rsp,0x50
  40a713:	mov    ecx,0x249f00
  40a718:	sub    rsp,0x8
  40a71c:	call   407270 <__swc_fn_ff58629f_000000_2744b483>
  40a721:	add    rsp,0x8
  40a725:	mov    rsi,rax
  40a728:	xor    ecx,ecx
  40a72a:	nop    WORD PTR [rax+rax*1+0x0]
  40a730:	mov    r8,QWORD PTR [rip+0x168c9]        # 421000 <__swc_data_base_ff58629f>
  40a737:	imul   r8,r8,0x41a7
  40a73e:	movabs rdx,0x200000005
  40a748:	mov    r11,rax
  40a74b:	mov    rax,r8
  40a74e:	mul    rdx
  40a751:	mov    r9,rdx
  40a754:	mov    rdx,r8
  40a757:	sub    rdx,r9
  40a75a:	shr    rdx,1
  40a75d:	add    rdx,r9
  40a760:	shr    rdx,0x1e
  40a764:	imul   r9,rdx,0x7fffffff
  40a76b:	sub    r8,r9
  40a76e:	mov    QWORD PTR [rip+0x1688b],r8        # 421000 <__swc_data_base_ff58629f>
  40a775:	mov    QWORD PTR [rsi+rcx*8],r8
  40a779:	add    rcx,0x1
  40a77d:	mov    r8,QWORD PTR [rip+0x1687c]        # 421000 <__swc_data_base_ff58629f>
  40a784:	imul   r8,r8,0x41a7
  40a78b:	movabs rdx,0x200000005
  40a795:	mov    rax,r8
  40a798:	mul    rdx
  40a79b:	mov    r9,rdx
  40a79e:	mov    rax,r11
  40a7a1:	mov    rdx,r8
  40a7a4:	sub    rdx,r9
  40a7a7:	shr    rdx,1
  40a7aa:	add    rdx,r9
  40a7ad:	shr    rdx,0x1e
  40a7b1:	imul   rdx,rdx,0x7fffffff
  40a7b8:	sub    r8,rdx
  40a7bb:	mov    QWORD PTR [rip+0x1683e],r8        # 421000 <__swc_data_base_ff58629f>
  40a7c2:	mov    QWORD PTR [rsi+rcx*8],r8
  40a7c6:	add    rcx,0x1
  40a7ca:	cmp    rcx,0x493e0
  40a7d1:	jl     40a730 <__swc_fn_ff58629f_000004_05d3c06b+0x30>
  40a7d7:	sub    rsp,0x8
  40a7db:	call   40ebc0 <__swc_fn_ff58629f_000002_1ca87929>
  40a7e0:	add    rsp,0x8
  40a7e4:	vmovups xmm6,xmm0
  40a7e8:	mov    rcx,rsi
  40a7eb:	xor    edx,edx
  40a7ed:	mov    r8d,0x493df
  40a7f3:	sub    rsp,0x8
  40a7f7:	call   407320 <__swc_fn_ff58629f_000003_2a1d71b4>
  40a7fc:	add    rsp,0x8
  40a800:	mov    cl,0x1
  40a802:	mov    edx,0x1
  40a807:	nop    WORD PTR [rax+rax*1+0x0]
  40a810:	mov    r8,QWORD PTR [rsi+rdx*8]
  40a814:	cmp    QWORD PTR [rsi+rdx*8-0x8],r8
  40a819:	jbe    40a81d <__swc_fn_ff58629f_000004_05d3c06b+0x11d>
  40a81b:	xor    ecx,ecx
  40a81d:	add    rdx,0x1
  40a821:	cmp    rdx,0x493e0
  40a828:	jl     40a810 <__swc_fn_ff58629f_000004_05d3c06b+0x110>
  40a82a:	xor    edi,edi
  40a82c:	test   cl,cl
  40a82e:	je     40a8f2 <__swc_fn_ff58629f_000004_05d3c06b+0x1f2>
  40a834:	xor    ecx,ecx
  40a836:	cs nop WORD PTR [rax+rax*1+0x0]
  40a840:	mov    r8,QWORD PTR [rsi+rcx*8]
  40a844:	mov    r9,r8
  40a847:	shr    r8,0x3
  40a84b:	movabs rdx,0x20c49ba5e353f7cf
  40a855:	mov    r10,rax
  40a858:	mov    rax,r8
  40a85b:	mul    rdx
  40a85e:	mov    r11,r10
  40a861:	shr    rdx,0x4
  40a865:	imul   rdx,rdx,0x3e8
  40a86c:	sub    r9,rdx
  40a86f:	mov    edx,ecx
  40a871:	imul   rdx,rdx,0x24924925
  40a878:	shr    rdx,0x20
  40a87c:	imul   edx,edx,0x7
  40a87f:	mov    r8d,ecx
  40a882:	sub    r8d,edx
  40a885:	lea    rdx,[r8+0x1]
  40a889:	imul   r9,rdx
  40a88d:	add    rdi,r9
  40a890:	add    rcx,0x1
  40a894:	mov    r8,QWORD PTR [rsi+rcx*8]
  40a898:	mov    r9,r8
  40a89b:	shr    r8,0x3
  40a89f:	movabs rdx,0x20c49ba5e353f7cf
  40a8a9:	mov    rax,r8
  40a8ac:	mul    rdx
  40a8af:	mov    rax,r11
  40a8b2:	shr    rdx,0x4
  40a8b6:	imul   rdx,rdx,0x3e8
  40a8bd:	sub    r9,rdx
  40a8c0:	mov    edx,ecx
  40a8c2:	imul   rdx,rdx,0x24924925
  40a8c9:	shr    rdx,0x20
  40a8cd:	imul   edx,edx,0x7
  40a8d0:	mov    r8d,ecx
  40a8d3:	sub    r8d,edx
  40a8d6:	lea    rdx,[r8+0x1]
  40a8da:	imul   r9,rdx
  40a8de:	add    rdi,r9
  40a8e1:	add    rcx,0x1
  40a8e5:	cmp    rcx,0x493e0
  40a8ec:	jl     40a840 <__swc_fn_ff58629f_000004_05d3c06b+0x140>
  40a8f2:	sub    rsp,0x8
  40a8f6:	call   40ebc0 <__swc_fn_ff58629f_000002_1ca87929>
  40a8fb:	add    rsp,0x8
  40a8ff:	vsubsd xmm0,xmm0,xmm6
  40a903:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x791d]        # 412228 <__swc_rdata_base_ff58629f+0x118>
  40a90b:	lea    rax,[rip+0x780e]        # 412120 <__swc_rdata_base_ff58629f+0x10>
  40a912:	sub    rsp,0x90
  40a919:	mov    rcx,rsp
  40a91c:	vmovups xmm1,XMMWORD PTR [rip+0x78e4]        # 412208 <__swc_rdata_base_ff58629f+0xf8>
  40a924:	vmovups XMMWORD PTR [rcx],xmm1
  40a928:	mov    QWORD PTR [rcx+0x30],rsp
  40a92c:	lea    rdx,[rip+0x77fd]        # 412130 <__swc_rdata_base_ff58629f+0x20>
  40a933:	mov    QWORD PTR [rcx+0x38],rdx
  40a937:	mov    QWORD PTR [rcx+0x10],rdi
  40a93b:	lea    r8,[rsp+0x10]
  40a940:	mov    QWORD PTR [rcx+0x40],r8
  40a944:	lea    r8,[rip+0x782d]        # 412178 <__swc_rdata_base_ff58629f+0x68>
  40a94b:	mov    QWORD PTR [rcx+0x48],r8
  40a94f:	vmovups xmm1,XMMWORD PTR [rip+0x78c1]        # 412218 <__swc_rdata_base_ff58629f+0x108>
  40a957:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40a95c:	lea    r8,[rsp+0x18]
  40a961:	mov    QWORD PTR [rcx+0x50],r8
  40a965:	mov    QWORD PTR [rcx+0x58],rdx
  40a969:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40a96e:	lea    r8,[rcx+0x28]
  40a972:	mov    QWORD PTR [rcx+0x60],r8
  40a976:	lea    r8,[rip+0x7843]        # 4121c0 <__swc_rdata_base_ff58629f+0xb0>
  40a97d:	mov    QWORD PTR [rcx+0x68],r8
  40a981:	mov    QWORD PTR [rcx+0x70],rax
  40a985:	mov    QWORD PTR [rcx+0x78],rdx
  40a989:	lea    rax,[rcx+0x30]
  40a98d:	mov    QWORD PTR [rcx+0x80],rax
  40a994:	mov    QWORD PTR [rcx+0x88],0x5
  40a99f:	lea    rcx,[rcx+0x80]
  40a9a6:	sub    rsp,0x8
  40a9aa:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  40a9af:	add    rsp,0x8
  40a9b3:	add    rsp,0x90
  40a9ba:	mov    rcx,rsi
  40a9bd:	sub    rsp,0x8
  40a9c1:	call   40a680 <__swc_fn_ff58629f_000001_5d3d19bd>
  40a9c6:	add    rsp,0x58
  40a9ca:	vmovups xmm6,XMMWORD PTR [rsp]
  40a9cf:	add    rsp,0x18
  40a9d3:	pop    rdi
  40a9d4:	pop    rsi
  40a9d5:	pop    rbp
  40a9d6:	ret
	...

000000000040a9e0 <__swc_fn_ff58629f_000007_81d2e1e9>:
  40a9e0:	sub    rsp,0x8
  40a9e4:	call   409660 <__swc_fn_ff58629f_000114_6b799b8d>
  40a9e9:	mov    rcx,rax
  40a9ec:	test   rax,rax
  40a9ef:	je     40aa16 <__swc_fn_ff58629f_000007_81d2e1e9+0x36>
  40a9f1:	lea    rdx,[rip+0x18650]        # 423048 <__swc_bss_base_ff58629f+0x8>
  40a9f8:	mov    r8,QWORD PTR [rip+0x18649]        # 423048 <__swc_bss_base_ff58629f+0x8>
  40a9ff:	nop
  40aa00:	lea    r9,[r8+0x1]
  40aa04:	mov    rax,r8
  40aa07:	lock cmpxchg QWORD PTR [rdx],r9
  40aa0c:	cmp    rax,r8
  40aa0f:	je     40aa16 <__swc_fn_ff58629f_000007_81d2e1e9+0x36>
  40aa11:	mov    r8,rax
  40aa14:	jmp    40aa00 <__swc_fn_ff58629f_000007_81d2e1e9+0x20>
  40aa16:	mov    rax,rcx
  40aa19:	add    rsp,0x8
  40aa1d:	ret
	...

000000000040aa20 <__swc_fn_ff58629f_000010_065ed5b1>:
  40aa20:	mov    r8d,edx
  40aa23:	xor    eax,eax
  40aa25:	tzcnt  eax,edx
  40aa29:	shrx   r9d,edx,eax
  40aa2e:	mov    DWORD PTR [rcx+0x2c],edx
  40aa31:	xor    eax,eax
  40aa33:	tzcnt  eax,edx
  40aa37:	mov    BYTE PTR [rcx+0x38],al
  40aa3a:	mov    eax,0xffffffff
  40aa3f:	xor    edx,edx
  40aa41:	div    r8d
  40aa44:	mov    DWORD PTR [rcx+0x34],eax
  40aa47:	mov    eax,r9d
  40aa4a:	mov    edx,r9d
  40aa4d:	imul   edx,r9d
  40aa51:	mov    r8d,0x2
  40aa57:	sub    r8d,edx
  40aa5a:	imul   eax,r8d
  40aa5e:	mov    edx,r9d
  40aa61:	imul   edx,eax
  40aa64:	mov    r8d,0x2
  40aa6a:	sub    r8d,edx
  40aa6d:	imul   eax,r8d
  40aa71:	mov    edx,r9d
  40aa74:	imul   edx,eax
  40aa77:	mov    r8d,0x2
  40aa7d:	sub    r8d,edx
  40aa80:	imul   eax,r8d
  40aa84:	mov    edx,r9d
  40aa87:	imul   edx,eax
  40aa8a:	mov    r8d,0x2
  40aa90:	sub    r8d,edx
  40aa93:	imul   eax,r8d
  40aa97:	imul   r9d,eax
  40aa9b:	mov    edx,0x2
  40aaa0:	sub    edx,r9d
  40aaa3:	imul   eax,edx
  40aaa6:	mov    DWORD PTR [rcx+0x30],eax
  40aaa9:	ret
  40aaaa:	add    BYTE PTR [rax],al
  40aaac:	add    BYTE PTR [rax],al
	...

000000000040aab0 <__swc_fn_ff58629f_000013_861b8b62>:
  40aab0:	xor    eax,eax
  40aab2:	mov    DWORD PTR [rcx+0x68],eax
  40aab5:	ret
	...

000000000040aac0 <__swc_fn_ff58629f_000016_9dea5065>:
  40aac0:	mov    eax,DWORD PTR [rcx+0x28]
  40aac3:	shlx   eax,edx,eax
  40aac8:	shl    rax,0x10
  40aacc:	lea    rdx,[rcx+rax*1]
  40aad0:	lea    rax,[rcx+0x3000]
  40aad7:	cmp    rdx,rax
  40aada:	cmovae rax,rdx
  40aade:	ret
	...

000000000040aae0 <__swc_fn_ff58629f_000019_283e2b5e>:
  40aae0:	push   rsi
  40aae1:	push   rdi
  40aae2:	push   r12
  40aae4:	push   r13
  40aae6:	push   r14
  40aae8:	mov    rsi,rdx
  40aaeb:	mov    rdi,rcx
  40aaee:	rex mov dl,BYTE PTR [rsi+0x3a]
  40aaf2:	mov    ecx,DWORD PTR [rdi+0x28]
  40aaf5:	shr    dl,cl
  40aaf7:	mov    r12d,0x1
  40aafd:	mov    ecx,edx
  40aaff:	shl    r12,cl
  40ab02:	mov    r13d,DWORD PTR [rsi+0x3c]
  40ab06:	rex mov BYTE PTR [rsi+0x3b],0x0
  40ab0b:	mov    QWORD PTR [rsi+0x40],0x0
  40ab13:	mov    QWORD PTR [rsi],0x0
  40ab1a:	mov    rax,QWORD PTR [rsi+0x10]
  40ab1e:	mov    QWORD PTR [rsi+0x20],rax
  40ab22:	lea    r14,[rip+0x18527]        # 423050 <__swc_bss_base_ff58629f+0x10>
  40ab29:	mov    rax,QWORD PTR [r14]
  40ab2c:	shr    rax,0x2
  40ab30:	mov    rcx,rax
  40ab33:	cmp    rax,0x800000
  40ab3a:	mov    eax,0x800000
  40ab3f:	cmovb  rcx,rax
  40ab43:	lea    r8,[rip+0x18516]        # 423060 <__swc_bss_base_ff58629f+0x20>
  40ab4a:	mov    rax,QWORD PTR [r8]
  40ab4d:	mov    r9,rax
  40ab50:	lea    r10,[r9+r13*1]
  40ab54:	cmp    r10,rcx
  40ab57:	ja     40ab7b <__swc_fn_ff58629f_000019_283e2b5e+0x9b>
  40ab59:	mov    rax,r9
  40ab5c:	lock cmpxchg QWORD PTR [r8],r10
  40ab61:	cmp    rax,r9
  40ab64:	je     40ab6b <__swc_fn_ff58629f_000019_283e2b5e+0x8b>
  40ab66:	mov    r9,rax
  40ab69:	jmp    40ab50 <__swc_fn_ff58629f_000019_283e2b5e+0x70>
  40ab6b:	mov    rcx,rdi
  40ab6e:	mov    rdx,r12
  40ab71:	call   407790 <__swc_fn_ff58629f_000021_de02dbdf>
  40ab76:	jmp    40abfd <__swc_fn_ff58629f_000019_283e2b5e+0x11d>
  40ab7b:	mov    rcx,rdi
  40ab7e:	movzx  edx,dl
  40ab81:	call   40aac0 <__swc_fn_ff58629f_000016_9dea5065>
  40ab86:	test   r13,r13
  40ab89:	je     40abf6 <__swc_fn_ff58629f_000019_283e2b5e+0x116>
  40ab8f:	mov    rcx,rax
  40ab92:	mov    rdx,r13
  40ab95:	call   4097e0 <__swc_fn_ff58629f_000117_e9fc0224>
  40ab9a:	mov    rcx,QWORD PTR [rip+0x184af]        # 423050 <__swc_bss_base_ff58629f+0x10>
  40aba1:	cs nop WORD PTR [rax+rax*1+0x0]
  40abab:	nop    DWORD PTR [rax+rax*1+0x0]
  40abb0:	mov    rdx,rcx
  40abb3:	sub    rdx,r13
  40abb6:	mov    rax,rcx
  40abb9:	lock cmpxchg QWORD PTR [r14],rdx
  40abbe:	cmp    rax,rcx
  40abc1:	je     40abc8 <__swc_fn_ff58629f_000019_283e2b5e+0xe8>
  40abc3:	mov    rcx,rax
  40abc6:	jmp    40abb0 <__swc_fn_ff58629f_000019_283e2b5e+0xd0>
  40abc8:	lea    rcx,[rip+0x18499]        # 423068 <__swc_bss_base_ff58629f+0x28>
  40abcf:	mov    rdx,QWORD PTR [rip+0x18492]        # 423068 <__swc_bss_base_ff58629f+0x28>
  40abd6:	cs nop WORD PTR [rax+rax*1+0x0]
  40abe0:	lea    r8,[rdx+0x1]
  40abe4:	mov    rax,rdx
  40abe7:	lock cmpxchg QWORD PTR [rcx],r8
  40abec:	cmp    rax,rdx
  40abef:	je     40abf6 <__swc_fn_ff58629f_000019_283e2b5e+0x116>
  40abf1:	mov    rdx,rax
  40abf4:	jmp    40abe0 <__swc_fn_ff58629f_000019_283e2b5e+0x100>
  40abf6:	mov    DWORD PTR [rsi+0x3c],0x0
  40abfd:	mov    rcx,rdi
  40ac00:	mov    rdx,r12
  40ac03:	call   40f030 <__swc_fn_ff58629f_000023_c8f5f27c>
  40ac08:	pop    r14
  40ac0a:	pop    r13
  40ac0c:	pop    r12
  40ac0e:	pop    rdi
  40ac0f:	pop    rsi
  40ac10:	ret
	...

000000000040ac20 <__swc_fn_ff58629f_000022_fd2b165c>:
  40ac20:	mov    r8,QWORD PTR [rcx+0x48]
  40ac24:	test   r8,rdx
  40ac27:	je     40ac58 <__swc_fn_ff58629f_000022_fd2b165c+0x38>
  40ac29:	nop    DWORD PTR [rax+0x0]
  40ac30:	mov    rax,rdx
  40ac33:	not    rax
  40ac36:	mov    r9,r8
  40ac39:	and    r9,rax
  40ac3c:	mov    rax,r8
  40ac3f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40ac45:	cmp    rax,r8
  40ac48:	jne    40ac50 <__swc_fn_ff58629f_000022_fd2b165c+0x30>
  40ac4a:	mov    eax,0x1
  40ac4f:	ret
  40ac50:	mov    r8,rax
  40ac53:	test   rax,rdx
  40ac56:	jne    40ac30 <__swc_fn_ff58629f_000022_fd2b165c+0x10>
  40ac58:	xor    eax,eax
  40ac5a:	ret
  40ac5b:	add    BYTE PTR [rax],al
  40ac5d:	add    BYTE PTR [rax],al
	...

000000000040ac60 <__swc_fn_ff58629f_000025_2685aade>:
  40ac60:	push   rsi
  40ac61:	push   rdi
  40ac62:	push   r12
  40ac64:	push   r13
  40ac66:	sub    rsp,0x8
  40ac6a:	mov    rsi,rdx
  40ac6d:	mov    rdi,rcx
  40ac70:	lea    r12,[rip+0x18581]        # 4231f8 <__swc_bss_base_ff58629f+0x1b8>
  40ac77:	mov    rcx,r12
  40ac7a:	call   4112c0 <__swc_fn_ff58629f_000140_86bb0f90>
  40ac7f:	xor    eax,eax
  40ac81:	mov    rcx,QWORD PTR [rip+0x18578]        # 423200 <__swc_bss_base_ff58629f+0x1c0>
  40ac88:	mov    r13,rcx
  40ac8b:	test   r13,r13
  40ac8e:	je     40acdb <__swc_fn_ff58629f_000025_2685aade+0x7b>
  40ac90:	mov    rcx,QWORD PTR [r13+0x10]
  40ac94:	cmp    DWORD PTR [r13+0x28],esi
  40ac98:	jne    40acd0 <__swc_fn_ff58629f_000025_2685aade+0x70>
  40ac9a:	test   rax,rax
  40ac9d:	jne    40aca8 <__swc_fn_ff58629f_000025_2685aade+0x48>
  40ac9f:	mov    QWORD PTR [rip+0x1855a],rcx        # 423200 <__swc_bss_base_ff58629f+0x1c0>
  40aca6:	jmp    40acac <__swc_fn_ff58629f_000025_2685aade+0x4c>
  40aca8:	mov    QWORD PTR [rax+0x10],rcx
  40acac:	vxorps xmm0,xmm0,xmm0
  40acb0:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40acb6:	mov    QWORD PTR [r13+0x8],rdi
  40acba:	mov    rcx,r12
  40acbd:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40acc2:	mov    rax,r13
  40acc5:	add    rsp,0x8
  40acc9:	pop    r13
  40accb:	pop    r12
  40accd:	pop    rdi
  40acce:	pop    rsi
  40accf:	ret
  40acd0:	mov    rax,r13
  40acd3:	mov    r13,rcx
  40acd6:	test   rcx,rcx
  40acd9:	jne    40ac90 <__swc_fn_ff58629f_000025_2685aade+0x30>
  40acdb:	mov    ecx,esi
  40acdd:	call   4077c0 <__swc_fn_ff58629f_000024_2d0fcd2c>
  40ace2:	mov    rsi,rax
  40ace5:	test   rax,rax
  40ace8:	jne    40acff <__swc_fn_ff58629f_000025_2685aade+0x9f>
  40acea:	mov    rcx,r12
  40aced:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40acf2:	xor    eax,eax
  40acf4:	add    rsp,0x8
  40acf8:	pop    r13
  40acfa:	pop    r12
  40acfc:	pop    rdi
  40acfd:	pop    rsi
  40acfe:	ret
  40acff:	mov    QWORD PTR [rsi+0x8],rdi
  40ad03:	mov    rcx,r12
  40ad06:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40ad0b:	mov    rax,rsi
  40ad0e:	add    rsp,0x8
  40ad12:	pop    r13
  40ad14:	pop    r12
  40ad16:	pop    rdi
  40ad17:	pop    rsi
  40ad18:	ret
  40ad19:	add    BYTE PTR [rax],al
  40ad1b:	add    BYTE PTR [rax],al
  40ad1d:	add    BYTE PTR [rax],al
	...

000000000040ad20 <__swc_fn_ff58629f_000028_9798fb47>:
  40ad20:	vxorps xmm0,xmm0,xmm0
  40ad24:	xor    eax,eax
  40ad26:	cs nop WORD PTR [rax+rax*1+0x0]
  40ad30:	cs nop WORD PTR [rax+rax*1+0x0]
  40ad3a:	nop    WORD PTR [rax+rax*1+0x0]
  40ad40:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40ad45:	add    rax,0x10
  40ad49:	cmp    rax,0x2b00
  40ad50:	jne    40ad40 <__swc_fn_ff58629f_000028_9798fb47+0x20>
  40ad52:	ret
	...

000000000040ad60 <__swc_fn_ff58629f_000031_9798fb47>:
  40ad60:	vxorps xmm0,xmm0,xmm0
  40ad64:	vmovups XMMWORD PTR [rcx],xmm0
  40ad68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40ad6d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40ad72:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40ad77:	ret
	...

000000000040ad80 <__swc_fn_ff58629f_000034_9798fb47>:
  40ad80:	vxorps xmm0,xmm0,xmm0
  40ad84:	vmovups XMMWORD PTR [rcx],xmm0
  40ad88:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40ad8d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40ad92:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40ad97:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40ad9c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40ada1:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40ada6:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40adab:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40adb3:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40adbb:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40adc3:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40adcb:	mov    QWORD PTR [rcx+0xc0],0x0
  40add6:	ret
	...

000000000040ade0 <__swc_fn_ff58629f_000037_92d9bbff>:
  40ade0:	push   rsi
  40ade1:	push   rdi
  40ade2:	sub    rsp,0x8
  40ade6:	mov    rsi,rcx
  40ade9:	lea    rdi,[rip+0x16218]        # 421008 <__swc_data_base_ff58629f+0x8>
  40adf0:	mov    rax,QWORD PTR [rdi]
  40adf3:	cmp    rax,0xffffffffffffffff
  40adf7:	je     40adfe <__swc_fn_ff58629f_000037_92d9bbff+0x1e>
  40adf9:	mov    rdi,rax
  40adfc:	jmp    40ae2b <__swc_fn_ff58629f_000037_92d9bbff+0x4b>
  40adfe:	call   410fa0 <__swc_fn_ff58629f_000128_58f0f391>
  40ae03:	mov    rcx,rax
  40ae06:	cmp    rax,0xffffffffffffffff
  40ae0a:	je     40ae3c <__swc_fn_ff58629f_000037_92d9bbff+0x5c>
  40ae0c:	mov    rax,0xffffffffffffffff
  40ae13:	lock cmpxchg QWORD PTR [rdi],rcx
  40ae18:	cmp    rax,0xffffffffffffffff
  40ae1c:	je     40ae28 <__swc_fn_ff58629f_000037_92d9bbff+0x48>
  40ae1e:	mov    rdi,rax
  40ae21:	call   409bb0 <__swc_fn_ff58629f_000129_a481cb88>
  40ae26:	jmp    40ae2b <__swc_fn_ff58629f_000037_92d9bbff+0x4b>
  40ae28:	mov    rdi,rcx
  40ae2b:	cmp    rdi,0xffffffffffffffff
  40ae2f:	je     40ae3c <__swc_fn_ff58629f_000037_92d9bbff+0x5c>
  40ae31:	mov    rcx,rdi
  40ae34:	mov    rdx,rsi
  40ae37:	call   40cef0 <__swc_fn_ff58629f_000130_4bbe3f14>
  40ae3c:	add    rsp,0x8
  40ae40:	pop    rdi
  40ae41:	pop    rsi
  40ae42:	ret
	...

000000000040ae50 <__swc_fn_ff58629f_000040_03f1bf9a>:
  40ae50:	sub    rsp,0x38
  40ae54:	mov    rax,rdx
  40ae57:	test   dl,dl
  40ae59:	jne    40ae71 <__swc_fn_ff58629f_000040_03f1bf9a+0x21>
  40ae5b:	mov    rax,r8
  40ae5e:	test   r8b,r8b
  40ae61:	cmove  eax,r9d
  40ae65:	test   al,al
  40ae67:	cmove  eax,r10d
  40ae6b:	test   al,al
  40ae6d:	cmove  eax,r11d
  40ae71:	test   al,al
  40ae73:	jne    40ae7a <__swc_fn_ff58629f_000040_03f1bf9a+0x2a>
  40ae75:	add    rsp,0x38
  40ae79:	ret
  40ae7a:	lea    rcx,[rip+0x73b7]        # 412238 <__swc_rdata_base_ff58629f+0x128>
  40ae81:	vmovups xmm0,XMMWORD PTR [rip+0x73bf]        # 412248 <__swc_rdata_base_ff58629f+0x138>
  40ae89:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ae8f:	vmovups xmm0,XMMWORD PTR [rip+0x73c1]        # 412258 <__swc_rdata_base_ff58629f+0x148>
  40ae97:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40ae9d:	vmovups xmm0,XMMWORD PTR [rip+0x73c3]        # 412268 <__swc_rdata_base_ff58629f+0x158>
  40aea5:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40aeab:	lea    rdx,[rsp+0x8]
  40aeb0:	call   4093e0 <__swc_fn_ff58629f_000108_90faaa26>
  40aeb5:	jmp    40ae75 <__swc_fn_ff58629f_000040_03f1bf9a+0x25>
	...

000000000040aec0 <__swc_fn_ff58629f_000043_facd3e17>:
  40aec0:	sub    rsp,0x8
  40aec4:	mov    eax,0x1000
  40aec9:	test   eax,eax
  40aecb:	mov    r8d,0x8
  40aed1:	cmove  eax,r8d
  40aed5:	dec    rax
  40aed8:	mov    r8,0xffffffffffffffff
  40aedf:	sub    r8,rax
  40aee2:	cmp    rdx,r8
  40aee5:	ja     40aef5 <__swc_fn_ff58629f_000043_facd3e17+0x35>
  40aee7:	add    rdx,rax
  40aeea:	not    rax
  40aeed:	mov    r8,rdx
  40aef0:	and    r8,rax
  40aef3:	jne    40aefc <__swc_fn_ff58629f_000043_facd3e17+0x3c>
  40aef5:	xor    eax,eax
  40aef7:	add    rsp,0x8
  40aefb:	ret
  40aefc:	mov    rdx,r8
  40aeff:	call   407ae0 <__swc_fn_ff58629f_000042_c90d80c1>
  40af04:	add    rsp,0x8
  40af08:	ret
  40af09:	add    BYTE PTR [rax],al
  40af0b:	add    BYTE PTR [rax],al
  40af0d:	add    BYTE PTR [rax],al
	...

000000000040af10 <__swc_fn_ff58629f_000046_d8bd27c3>:
  40af10:	push   rsi
  40af11:	push   rdi
  40af12:	sub    rsp,0x8
  40af16:	mov    rsi,rdx
  40af19:	mov    rdi,rcx
  40af1c:	test   rdx,rdx
  40af1f:	je     40af3b <__swc_fn_ff58629f_000046_d8bd27c3+0x2b>
  40af21:	xor    ecx,ecx
  40af23:	call   40f150 <__swc_fn_ff58629f_000038_28d0e998>
  40af28:	mov    rax,QWORD PTR [rsi]
  40af2b:	test   rax,rax
  40af2e:	je     40af3b <__swc_fn_ff58629f_000046_d8bd27c3+0x2b>
  40af30:	mov    rcx,rax
  40af33:	mov    rdx,rsi
  40af36:	call   40f260 <__swc_fn_ff58629f_000047_b30433d0>
  40af3b:	mov    rcx,rdi
  40af3e:	call   407b40 <__swc_fn_ff58629f_000045_a78ae66b>
  40af43:	mov    rsi,rax
  40af46:	test   rax,rax
  40af49:	jne    40af54 <__swc_fn_ff58629f_000046_d8bd27c3+0x44>
  40af4b:	xor    eax,eax
  40af4d:	add    rsp,0x8
  40af51:	pop    rdi
  40af52:	pop    rsi
  40af53:	ret
  40af54:	mov    rcx,rsi
  40af57:	call   40f150 <__swc_fn_ff58629f_000038_28d0e998>
  40af5c:	mov    rax,rsi
  40af5f:	add    rsp,0x8
  40af63:	pop    rdi
  40af64:	pop    rsi
  40af65:	ret
	...

000000000040af70 <__swc_fn_ff58629f_000049_137687bb>:
  40af70:	movzx  eax,BYTE PTR [r8+0x39]
  40af75:	lea    rax,[rax+rax*4]
  40af79:	lea    rax,[rdx+rax*8+0x28]
  40af7e:	mov    ecx,DWORD PTR [r8+0x6c]
  40af82:	test   ecx,ecx
  40af84:	je     40afbd <__swc_fn_ff58629f_000049_137687bb+0x4d>
  40af86:	mov    rcx,QWORD PTR [r8+0x50]
  40af8a:	test   rcx,rcx
  40af8d:	je     40af99 <__swc_fn_ff58629f_000049_137687bb+0x29>
  40af8f:	mov    rax,QWORD PTR [r8+0x48]
  40af93:	mov    QWORD PTR [rcx+0x48],rax
  40af97:	jmp    40afa1 <__swc_fn_ff58629f_000049_137687bb+0x31>
  40af99:	mov    rcx,QWORD PTR [r8+0x48]
  40af9d:	mov    QWORD PTR [rax+0x18],rcx
  40afa1:	mov    rax,QWORD PTR [r8+0x48]
  40afa5:	test   rax,rax
  40afa8:	je     40afb2 <__swc_fn_ff58629f_000049_137687bb+0x42>
  40afaa:	mov    rcx,QWORD PTR [r8+0x50]
  40afae:	mov    QWORD PTR [rax+0x50],rcx
  40afb2:	vxorps xmm0,xmm0,xmm0
  40afb6:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40afbc:	ret
  40afbd:	mov    rcx,QWORD PTR [r8+0x50]
  40afc1:	test   rcx,rcx
  40afc4:	je     40afd0 <__swc_fn_ff58629f_000049_137687bb+0x60>
  40afc6:	mov    rdx,QWORD PTR [r8+0x48]
  40afca:	mov    QWORD PTR [rcx+0x48],rdx
  40afce:	jmp    40afd8 <__swc_fn_ff58629f_000049_137687bb+0x68>
  40afd0:	mov    rcx,QWORD PTR [r8+0x48]
  40afd4:	mov    QWORD PTR [rax+0x8],rcx
  40afd8:	mov    rcx,QWORD PTR [r8+0x48]
  40afdc:	test   rcx,rcx
  40afdf:	je     40afeb <__swc_fn_ff58629f_000049_137687bb+0x7b>
  40afe1:	mov    rdx,QWORD PTR [r8+0x50]
  40afe5:	mov    QWORD PTR [rcx+0x50],rdx
  40afe9:	jmp    40aff3 <__swc_fn_ff58629f_000049_137687bb+0x83>
  40afeb:	mov    rcx,QWORD PTR [r8+0x50]
  40afef:	mov    QWORD PTR [rax+0x10],rcx
  40aff3:	cmp    QWORD PTR [rax],r8
  40aff6:	jne    40afff <__swc_fn_ff58629f_000049_137687bb+0x8f>
  40aff8:	mov    QWORD PTR [rax],0x0
  40afff:	vxorps xmm0,xmm0,xmm0
  40b003:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40b009:	ret
  40b00a:	add    BYTE PTR [rax],al
  40b00c:	add    BYTE PTR [rax],al
	...

000000000040b010 <__swc_fn_ff58629f_000052_e072b516>:
  40b010:	sub    rsp,0x8
  40b014:	mov    r9,r8
  40b017:	mov    r10,rdx
  40b01a:	call   40af70 <__swc_fn_ff58629f_000049_137687bb>
  40b01f:	mov    DWORD PTR [r9+0x6c],0x0
  40b027:	movzx  eax,BYTE PTR [r9+0x39]
  40b02c:	lea    rax,[rax+rax*4]
  40b030:	lea    rax,[r10+rax*8+0x28]
  40b035:	mov    rcx,QWORD PTR [rax+0x10]
  40b039:	mov    QWORD PTR [r9+0x50],rcx
  40b03d:	mov    QWORD PTR [r9+0x48],0x0
  40b045:	mov    rcx,QWORD PTR [rax+0x10]
  40b049:	test   rcx,rcx
  40b04c:	je     40b054 <__swc_fn_ff58629f_000052_e072b516+0x44>
  40b04e:	mov    QWORD PTR [rcx+0x48],r9
  40b052:	jmp    40b058 <__swc_fn_ff58629f_000052_e072b516+0x48>
  40b054:	mov    QWORD PTR [rax+0x8],r9
  40b058:	mov    QWORD PTR [rax+0x10],r9
  40b05c:	add    rsp,0x8
  40b060:	ret
	...

000000000040b080 <__swc_fn_ff58629f_000055_faa92dcc>:
  40b080:	push   rsi
  40b081:	push   rdi
  40b082:	push   r12
  40b084:	push   r13
  40b086:	push   r14
  40b088:	push   r15
  40b08a:	sub    rsp,0x1f8
  40b091:	mov    esi,r8d
  40b094:	mov    QWORD PTR [rsp+0x1e8],rsi
  40b09c:	mov    rdi,rcx
  40b09f:	mov    r12,rdx
  40b0a2:	lea    r13,[rsi+rsi*4]
  40b0a6:	lea    r13,[rdx+r13*8+0x28]
  40b0ab:	call   40f6c0 <__swc_fn_ff58629f_000053_d846b172>
  40b0b0:	add    DWORD PTR [r12+0x24],0x1
  40b0b6:	test   BYTE PTR [r12+0x24],0x3f
  40b0bc:	jne    40b0c6 <__swc_fn_ff58629f_000055_faa92dcc+0x46>
  40b0be:	mov    rcx,rdi
  40b0c1:	call   407cc0 <__swc_fn_ff58629f_000054_3af34d7f>
  40b0c6:	mov    rax,QWORD PTR [r13+0x8]
  40b0ca:	mov    r14,rax
  40b0cd:	nop    DWORD PTR [rax]
  40b0d0:	test   r14,r14
  40b0d3:	jne    40b0e2 <__swc_fn_ff58629f_000055_faa92dcc+0x62>
  40b0d5:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40b0dd:	jmp    40b1e9 <__swc_fn_ff58629f_000055_faa92dcc+0x169>
  40b0e2:	mov    r15,QWORD PTR [r14+0x48]
  40b0e6:	mov    rcx,r14
  40b0e9:	call   40ee20 <__swc_fn_ff58629f_000014_e4b0ddfc>
  40b0ee:	mov    rax,QWORD PTR [r14]
  40b0f1:	test   rax,rax
  40b0f4:	je     40b106 <__swc_fn_ff58629f_000055_faa92dcc+0x86>
  40b0f6:	mov    rcx,QWORD PTR [rax]
  40b0f9:	mov    QWORD PTR [r14],rcx
  40b0fc:	add    DWORD PTR [r14+0x28],0x1
  40b101:	mov    rsi,rax
  40b104:	jmp    40b125 <__swc_fn_ff58629f_000055_faa92dcc+0xa5>
  40b106:	mov    rax,QWORD PTR [r14+0x18]
  40b10a:	cmp    QWORD PTR [r14+0x20],rax
  40b10e:	jae    40b123 <__swc_fn_ff58629f_000055_faa92dcc+0xa3>
  40b110:	mov    rsi,QWORD PTR [r14+0x20]
  40b114:	mov    eax,DWORD PTR [r14+0x2c]
  40b118:	add    QWORD PTR [r14+0x20],rax
  40b11c:	add    DWORD PTR [r14+0x28],0x1
  40b121:	jmp    40b125 <__swc_fn_ff58629f_000055_faa92dcc+0xa5>
  40b123:	xor    esi,esi
  40b125:	test   rsi,rsi
  40b128:	jne    40b16d <__swc_fn_ff58629f_000055_faa92dcc+0xed>
  40b12a:	mov    rcx,r14
  40b12d:	call   40ed50 <__swc_fn_ff58629f_000011_24a20786>
  40b132:	test   al,al
  40b134:	je     40b16d <__swc_fn_ff58629f_000055_faa92dcc+0xed>
  40b136:	mov    rax,QWORD PTR [r14]
  40b139:	test   rax,rax
  40b13c:	je     40b14b <__swc_fn_ff58629f_000055_faa92dcc+0xcb>
  40b13e:	mov    rcx,QWORD PTR [rax]
  40b141:	mov    QWORD PTR [r14],rcx
  40b144:	add    DWORD PTR [r14+0x28],0x1
  40b149:	jmp    40b16a <__swc_fn_ff58629f_000055_faa92dcc+0xea>
  40b14b:	mov    rax,QWORD PTR [r14+0x18]
  40b14f:	cmp    QWORD PTR [r14+0x20],rax
  40b153:	jae    40b168 <__swc_fn_ff58629f_000055_faa92dcc+0xe8>
  40b155:	mov    rax,QWORD PTR [r14+0x20]
  40b159:	mov    ecx,DWORD PTR [r14+0x2c]
  40b15d:	add    QWORD PTR [r14+0x20],rcx
  40b161:	add    DWORD PTR [r14+0x28],0x1
  40b166:	jmp    40b16a <__swc_fn_ff58629f_000055_faa92dcc+0xea>
  40b168:	xor    eax,eax
  40b16a:	mov    rsi,rax
  40b16d:	test   rsi,rsi
  40b170:	jne    40b1c3 <__swc_fn_ff58629f_000055_faa92dcc+0x143>
  40b172:	mov    rcx,rdi
  40b175:	mov    rdx,r12
  40b178:	mov    r8,r14
  40b17b:	call   407c20 <__swc_fn_ff58629f_000051_129b9bf4>
  40b180:	test   al,al
  40b182:	jne    40b1c3 <__swc_fn_ff58629f_000055_faa92dcc+0x143>
  40b184:	mov    rcx,r14
  40b187:	call   40ee20 <__swc_fn_ff58629f_000014_e4b0ddfc>
  40b18c:	mov    rax,QWORD PTR [r14]
  40b18f:	test   rax,rax
  40b192:	je     40b1a1 <__swc_fn_ff58629f_000055_faa92dcc+0x121>
  40b194:	mov    rcx,QWORD PTR [rax]
  40b197:	mov    QWORD PTR [r14],rcx
  40b19a:	add    DWORD PTR [r14+0x28],0x1
  40b19f:	jmp    40b1c0 <__swc_fn_ff58629f_000055_faa92dcc+0x140>
  40b1a1:	mov    rax,QWORD PTR [r14+0x18]
  40b1a5:	cmp    QWORD PTR [r14+0x20],rax
  40b1a9:	jae    40b1be <__swc_fn_ff58629f_000055_faa92dcc+0x13e>
  40b1ab:	mov    rax,QWORD PTR [r14+0x20]
  40b1af:	mov    ecx,DWORD PTR [r14+0x2c]
  40b1b3:	add    QWORD PTR [r14+0x20],rcx
  40b1b7:	add    DWORD PTR [r14+0x28],0x1
  40b1bc:	jmp    40b1c0 <__swc_fn_ff58629f_000055_faa92dcc+0x140>
  40b1be:	xor    eax,eax
  40b1c0:	mov    rsi,rax
  40b1c3:	test   rsi,rsi
  40b1c6:	je     40b1e1 <__swc_fn_ff58629f_000055_faa92dcc+0x161>
  40b1c8:	mov    QWORD PTR [r13+0x0],r14
  40b1cc:	mov    rax,rsi
  40b1cf:	add    rsp,0x1f8
  40b1d6:	pop    r15
  40b1d8:	pop    r14
  40b1da:	pop    r13
  40b1dc:	pop    r12
  40b1de:	pop    rdi
  40b1df:	pop    rsi
  40b1e0:	ret
  40b1e1:	mov    r14,r15
  40b1e4:	jmp    40b0d0 <__swc_fn_ff58629f_000055_faa92dcc+0x50>
  40b1e9:	cs nop WORD PTR [rax+rax*1+0x0]
  40b1f3:	cs nop WORD PTR [rax+rax*1+0x0]
  40b1fd:	nop    DWORD PTR [rax]
  40b200:	mov    rcx,rdi
  40b203:	mov    rdx,r12
  40b206:	mov    r8d,esi
  40b209:	call   40f400 <__swc_fn_ff58629f_000050_ad48ec88>
  40b20e:	mov    r14,rax
  40b211:	test   rax,rax
  40b214:	jne    40b22a <__swc_fn_ff58629f_000055_faa92dcc+0x1aa>
  40b216:	xor    eax,eax
  40b218:	add    rsp,0x1f8
  40b21f:	pop    r15
  40b221:	pop    r14
  40b223:	pop    r13
  40b225:	pop    r12
  40b227:	pop    rdi
  40b228:	pop    rsi
  40b229:	ret
  40b22a:	mov    QWORD PTR [r13+0x0],r14
  40b22e:	mov    rax,QWORD PTR [r14]
  40b231:	test   rax,rax
  40b234:	je     40b246 <__swc_fn_ff58629f_000055_faa92dcc+0x1c6>
  40b236:	mov    rcx,QWORD PTR [rax]
  40b239:	mov    QWORD PTR [r14],rcx
  40b23c:	add    DWORD PTR [r14+0x28],0x1
  40b241:	mov    r15,rax
  40b244:	jmp    40b266 <__swc_fn_ff58629f_000055_faa92dcc+0x1e6>
  40b246:	mov    rax,QWORD PTR [r14+0x18]
  40b24a:	cmp    QWORD PTR [r14+0x20],rax
  40b24e:	jae    40b263 <__swc_fn_ff58629f_000055_faa92dcc+0x1e3>
  40b250:	mov    r15,QWORD PTR [r14+0x20]
  40b254:	mov    eax,DWORD PTR [r14+0x2c]
  40b258:	add    QWORD PTR [r14+0x20],rax
  40b25c:	add    DWORD PTR [r14+0x28],0x1
  40b261:	jmp    40b266 <__swc_fn_ff58629f_000055_faa92dcc+0x1e6>
  40b263:	xor    r15d,r15d
  40b266:	test   r15,r15
  40b269:	jne    40b2ae <__swc_fn_ff58629f_000055_faa92dcc+0x22e>
  40b26b:	mov    rcx,r14
  40b26e:	call   40ed50 <__swc_fn_ff58629f_000011_24a20786>
  40b273:	test   al,al
  40b275:	je     40b2ae <__swc_fn_ff58629f_000055_faa92dcc+0x22e>
  40b277:	mov    rax,QWORD PTR [r14]
  40b27a:	test   rax,rax
  40b27d:	je     40b28c <__swc_fn_ff58629f_000055_faa92dcc+0x20c>
  40b27f:	mov    rcx,QWORD PTR [rax]
  40b282:	mov    QWORD PTR [r14],rcx
  40b285:	add    DWORD PTR [r14+0x28],0x1
  40b28a:	jmp    40b2ab <__swc_fn_ff58629f_000055_faa92dcc+0x22b>
  40b28c:	mov    rax,QWORD PTR [r14+0x18]
  40b290:	cmp    QWORD PTR [r14+0x20],rax
  40b294:	jae    40b2a9 <__swc_fn_ff58629f_000055_faa92dcc+0x229>
  40b296:	mov    rax,QWORD PTR [r14+0x20]
  40b29a:	mov    ecx,DWORD PTR [r14+0x2c]
  40b29e:	add    QWORD PTR [r14+0x20],rcx
  40b2a2:	add    DWORD PTR [r14+0x28],0x1
  40b2a7:	jmp    40b2ab <__swc_fn_ff58629f_000055_faa92dcc+0x22b>
  40b2a9:	xor    eax,eax
  40b2ab:	mov    r15,rax
  40b2ae:	test   r15,r15
  40b2b1:	je     40b200 <__swc_fn_ff58629f_000055_faa92dcc+0x180>
  40b2b7:	mov    rax,r15
  40b2ba:	add    rsp,0x1f8
  40b2c1:	pop    r15
  40b2c3:	pop    r14
  40b2c5:	pop    r13
  40b2c7:	pop    r12
  40b2c9:	pop    rdi
  40b2ca:	pop    rsi
  40b2cb:	ret
  40b2cc:	add    BYTE PTR [rax],al
	...

000000000040b2d0 <__swc_fn_ff58629f_000058_7e1dbcb0>:
  40b2d0:	push   rsi
  40b2d1:	push   rdi
  40b2d2:	push   r12
  40b2d4:	mov    rsi,rdx
  40b2d7:	mov    rax,rdx
  40b2da:	shr    rax,0xc
  40b2de:	movabs rdx,0x9e3779b97f4a7c15
  40b2e8:	imul   rax,rdx
  40b2ec:	shr    rax,0x20
  40b2f0:	lea    rax,[rax*8+0x0]
  40b2f8:	shr    rax,0x20
  40b2fc:	lea    rax,[rax*8+0x0]
  40b304:	lea    rax,[rcx+rax*8+0x40]
  40b309:	xor    edx,edx
  40b30b:	test   dl,dl
  40b30d:	lea    rdi,[rcx+0x8]
  40b311:	cmove  rdi,rax
  40b315:	xor    edx,edx
  40b317:	test   dl,dl
  40b319:	lea    r12,[rcx+0x30]
  40b31d:	lea    rax,[rax+0x8]
  40b321:	cmove  r12,rax
  40b325:	mov    rcx,rdi
  40b328:	call   4112c0 <__swc_fn_ff58629f_000140_86bb0f90>
  40b32d:	mov    QWORD PTR [rsi+0x30],0x0
  40b335:	mov    rax,QWORD PTR [r12]
  40b339:	mov    QWORD PTR [rsi+0x38],rax
  40b33d:	test   rax,rax
  40b340:	je     40b34a <__swc_fn_ff58629f_000058_7e1dbcb0+0x7a>
  40b342:	mov    rax,QWORD PTR [rsi+0x38]
  40b346:	mov    QWORD PTR [rax+0x30],rsi
  40b34a:	mov    QWORD PTR [r12],rsi
  40b34e:	mov    rcx,rdi
  40b351:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40b356:	pop    r12
  40b358:	pop    rdi
  40b359:	pop    rsi
  40b35a:	ret
  40b35b:	add    BYTE PTR [rax],al
  40b35d:	add    BYTE PTR [rax],al
	...

000000000040b360 <__swc_fn_ff58629f_000061_15c28ca7>:
  40b360:	lea    rax,[rdx+rdx*4]
  40b364:	lea    rax,[rcx+rax*8+0x268]
  40b36c:	mov    rdx,QWORD PTR [rax+0x10]
  40b370:	sub    QWORD PTR [rcx+0x2a68],rdx
  40b377:	sub    QWORD PTR [rcx+0x2a70],0x1
  40b37f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40b386:	lea    rdx,[rdx+rdx*4]
  40b38a:	lea    rdx,[rcx+rdx*8+0x268]
  40b392:	vmovups xmm0,XMMWORD PTR [rdx]
  40b396:	vmovups XMMWORD PTR [rax],xmm0
  40b39a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40b39f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40b3a4:	mov    rcx,QWORD PTR [rdx+0x20]
  40b3a8:	mov    QWORD PTR [rax+0x20],rcx
  40b3ac:	ret
  40b3ad:	add    BYTE PTR [rax],al
	...

000000000040b3b0 <__swc_fn_ff58629f_000064_dea90857>:
  40b3b0:	push   rsi
  40b3b1:	push   rdi
  40b3b2:	push   r12
  40b3b4:	push   r13
  40b3b6:	sub    rsp,0x8
  40b3ba:	mov    rsi,r8
  40b3bd:	mov    rdi,rcx
  40b3c0:	mov    r12,rdx
  40b3c3:	xor    r13d,r13d
  40b3c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40b3d0:	mov    eax,DWORD PTR [r12+0x730]
  40b3d8:	cmp    r13d,eax
  40b3db:	jae    40b441 <__swc_fn_ff58629f_000064_dea90857+0x91>
  40b3dd:	lea    rax,[r13+r13*4+0x0]
  40b3e2:	lea    rax,[r12+rax*8+0x738]
  40b3ea:	mov    rdx,QWORD PTR [rax]
  40b3ed:	mov    r8,QWORD PTR [rax+0x8]
  40b3f1:	mov    r9,QWORD PTR [rax+0x10]
  40b3f5:	cmp    QWORD PTR [rax+0x20],rsi
  40b3f9:	jb     40b400 <__swc_fn_ff58629f_000064_dea90857+0x50>
  40b3fb:	inc    r13d
  40b3fe:	jmp    40b3d0 <__swc_fn_ff58629f_000064_dea90857+0x20>
  40b400:	sub    DWORD PTR [r12+0x730],0x1
  40b409:	mov    ecx,DWORD PTR [r12+0x730]
  40b411:	lea    rcx,[rcx+rcx*4]
  40b415:	lea    rcx,[r12+rcx*8+0x738]
  40b41d:	vmovups xmm0,XMMWORD PTR [rcx]
  40b421:	vmovups XMMWORD PTR [rax],xmm0
  40b425:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40b42a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40b42f:	mov    rcx,QWORD PTR [rcx+0x20]
  40b433:	mov    QWORD PTR [rax+0x20],rcx
  40b437:	mov    rcx,rdi
  40b43a:	call   40f180 <__swc_fn_ff58629f_000044_d3c2ab54>
  40b43f:	jmp    40b3d0 <__swc_fn_ff58629f_000064_dea90857+0x20>
  40b441:	add    rsp,0x8
  40b445:	pop    r13
  40b447:	pop    r12
  40b449:	pop    rdi
  40b44a:	pop    rsi
  40b44b:	ret
  40b44c:	add    BYTE PTR [rax],al
	...

000000000040b450 <__swc_fn_ff58629f_000067_de167e8d>:
  40b450:	push   rsi
  40b451:	push   rdi
  40b452:	push   r12
  40b454:	push   r13
  40b456:	push   r14
  40b458:	mov    rsi,rcx
  40b45b:	mov    rdi,rdx
  40b45e:	mov    r12,QWORD PTR [rdi]
  40b461:	mov    r13,QWORD PTR [rdi+0x18]
  40b465:	mov    rax,r12
  40b468:	add    rax,QWORD PTR [rdi+0x8]
  40b46c:	sub    rax,r13
  40b46f:	cmp    r8,rax
  40b472:	jbe    40b47d <__swc_fn_ff58629f_000067_de167e8d+0x2d>
  40b474:	pop    r14
  40b476:	pop    r13
  40b478:	pop    r12
  40b47a:	pop    rdi
  40b47b:	pop    rsi
  40b47c:	ret
  40b47d:	lea    rax,[r13+r8*1+0x0]
  40b482:	sub    rax,r12
  40b485:	mov    ecx,0x1000
  40b48a:	test   ecx,ecx
  40b48c:	mov    edx,0x8
  40b491:	cmove  ecx,edx
  40b494:	dec    rcx
  40b497:	mov    rdx,0xffffffffffffffff
  40b49e:	sub    rdx,rcx
  40b4a1:	cmp    rax,rdx
  40b4a4:	jbe    40b4ab <__swc_fn_ff58629f_000067_de167e8d+0x5b>
  40b4a6:	xor    r14d,r14d
  40b4a9:	jmp    40b4b6 <__swc_fn_ff58629f_000067_de167e8d+0x66>
  40b4ab:	add    rax,rcx
  40b4ae:	andn   rax,rcx,rax
  40b4b3:	mov    r14,rax
  40b4b6:	mov    rax,QWORD PTR [rdi+0x10]
  40b4ba:	cmp    r14,rax
  40b4bd:	ja     40b4c8 <__swc_fn_ff58629f_000067_de167e8d+0x78>
  40b4bf:	pop    r14
  40b4c1:	pop    r13
  40b4c3:	pop    r12
  40b4c5:	pop    rdi
  40b4c6:	pop    rsi
  40b4c7:	ret
  40b4c8:	mov    rax,r12
  40b4cb:	add    rax,QWORD PTR [rdi+0x10]
  40b4cf:	mov    rdx,r14
  40b4d2:	sub    rdx,QWORD PTR [rdi+0x10]
  40b4d6:	mov    rcx,rax
  40b4d9:	call   40ecd0 <__swc_fn_ff58629f_000008_f7acedb0>
  40b4de:	test   al,al
  40b4e0:	jne    40b4eb <__swc_fn_ff58629f_000067_de167e8d+0x9b>
  40b4e2:	pop    r14
  40b4e4:	pop    r13
  40b4e6:	pop    r12
  40b4e8:	pop    rdi
  40b4e9:	pop    rsi
  40b4ea:	ret
  40b4eb:	add    r12,r14
  40b4ee:	sub    r12,r13
  40b4f1:	mov    rcx,r12
  40b4f4:	sub    rcx,QWORD PTR [rdi+0x28]
  40b4f8:	mov    rdx,QWORD PTR [rsi+0x250]
  40b4ff:	nop
  40b500:	lea    r8,[rdx+rcx*1]
  40b504:	mov    rax,rdx
  40b507:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40b510:	cmp    rax,rdx
  40b513:	je     40b51a <__swc_fn_ff58629f_000067_de167e8d+0xca>
  40b515:	mov    rdx,rax
  40b518:	jmp    40b500 <__swc_fn_ff58629f_000067_de167e8d+0xb0>
  40b51a:	mov    QWORD PTR [rdi+0x10],r14
  40b51e:	mov    QWORD PTR [rdi+0x28],r12
  40b522:	pop    r14
  40b524:	pop    r13
  40b526:	pop    r12
  40b528:	pop    rdi
  40b529:	pop    rsi
  40b52a:	ret
  40b52b:	add    BYTE PTR [rax],al
  40b52d:	add    BYTE PTR [rax],al
	...

000000000040b530 <__swc_fn_ff58629f_000070_7130736e>:
  40b530:	push   rbx
  40b531:	push   rsi
  40b532:	push   rdi
  40b533:	push   r12
  40b535:	push   r13
  40b537:	sub    rsp,0xe0
  40b53e:	mov    rbx,rdx
  40b541:	mov    rsi,rcx
  40b544:	cmp    DWORD PTR [rbx+0x58],0x0
  40b548:	je     40b56c <__swc_fn_ff58629f_000070_7130736e+0x3c>
  40b54a:	mov    eax,DWORD PTR [rbx+0x58]
  40b54d:	sub    eax,0x1
  40b550:	test   DWORD PTR [rbx+0x58],eax
  40b553:	je     40b56c <__swc_fn_ff58629f_000070_7130736e+0x3c>
  40b555:	mov    QWORD PTR [rbx+0x40],0x0
  40b55d:	add    rsp,0xe0
  40b564:	pop    r13
  40b566:	pop    r12
  40b568:	pop    rdi
  40b569:	pop    rsi
  40b56a:	pop    rbx
  40b56b:	ret
  40b56c:	mov    rax,QWORD PTR [rbx+0x40]
  40b570:	test   rax,rax
  40b573:	jne    40b58f <__swc_fn_ff58629f_000070_7130736e+0x5f>
  40b575:	mov    rcx,rsi
  40b578:	mov    rdx,rbx
  40b57b:	call   4088d0 <__swc_fn_ff58629f_000069_f3aa21af>
  40b580:	add    rsp,0xe0
  40b587:	pop    r13
  40b589:	pop    r12
  40b58b:	pop    rdi
  40b58c:	pop    rsi
  40b58d:	pop    rbx
  40b58e:	ret
  40b58f:	cmp    QWORD PTR [rbx+0x48],0x0
  40b594:	jne    40b5b0 <__swc_fn_ff58629f_000070_7130736e+0x80>
  40b596:	mov    rcx,rsi
  40b599:	mov    rdx,rbx
  40b59c:	call   40f9b0 <__swc_fn_ff58629f_000071_97813b89>
  40b5a1:	add    rsp,0xe0
  40b5a8:	pop    r13
  40b5aa:	pop    r12
  40b5ac:	pop    rdi
  40b5ad:	pop    rsi
  40b5ae:	pop    rbx
  40b5af:	ret
  40b5b0:	mov    rdi,QWORD PTR [rbx+0x40]
  40b5b4:	lea    rax,[rip+0x17abd]        # 423078 <__swc_bss_base_ff58629f+0x38>
  40b5bb:	mov    rcx,rdi
  40b5be:	sub    rcx,QWORD PTR [rax+0x8]
  40b5c2:	mov    rax,QWORD PTR [rip+0x17abf]        # 423088 <__swc_bss_base_ff58629f+0x48>
  40b5c9:	cmp    rcx,rax
  40b5cc:	jae    40b5f8 <__swc_fn_ff58629f_000070_7130736e+0xc8>
  40b5ce:	mov    rax,rdi
  40b5d1:	and    rax,0xffffffffffc00000
  40b5d8:	mov    rcx,rdi
  40b5db:	shr    rcx,0x10
  40b5df:	and    ecx,0x3f
  40b5e2:	mov    edx,DWORD PTR [rax+0x28]
  40b5e5:	shrx   ecx,ecx,edx
  40b5ea:	shl    rcx,0x4
  40b5ee:	lea    r12,[rax+rcx*8+0x80]
  40b5f6:	jmp    40b603 <__swc_fn_ff58629f_000070_7130736e+0xd3>
  40b5f8:	mov    rcx,rdi
  40b5fb:	call   407950 <__swc_fn_ff58629f_000027_bcdc5519>
  40b600:	mov    r12,rax
  40b603:	test   r12,r12
  40b606:	je     40b615 <__swc_fn_ff58629f_000070_7130736e+0xe5>
  40b608:	mov    eax,DWORD PTR [r12+0x2c]
  40b60d:	mov    r9d,eax
  40b610:	mov    r13,rax
  40b613:	jmp    40b694 <__swc_fn_ff58629f_000070_7130736e+0x164>
  40b615:	mov    rcx,rsi
  40b618:	mov    rdx,rdi
  40b61b:	call   407f60 <__swc_fn_ff58629f_000057_df0696cd>
  40b620:	mov    rcx,QWORD PTR [rax+0x28]
  40b624:	mov    r9,rcx
  40b627:	mov    rdx,QWORD PTR [rax+0x20]
  40b62b:	mov    r13,rdx
  40b62e:	cmp    QWORD PTR [rbx+0x48],rcx
  40b632:	jbe    40b66b <__swc_fn_ff58629f_000070_7130736e+0x13b>
  40b634:	mov    ecx,DWORD PTR [rax+0x48]
  40b637:	cmp    DWORD PTR [rbx+0x58],ecx
  40b63a:	ja     40b66b <__swc_fn_ff58629f_000070_7130736e+0x13b>
  40b63c:	mov    rcx,rsi
  40b63f:	mov    rdx,rax
  40b642:	mov    r8,QWORD PTR [rbx+0x48]
  40b646:	mov    QWORD PTR [rsp+0xc8],r9
  40b64e:	mov    QWORD PTR [rsp+0xd0],rax
  40b656:	call   40b450 <__swc_fn_ff58629f_000067_de167e8d>
  40b65b:	mov    r9,QWORD PTR [rsp+0xc8]
  40b663:	mov    rax,QWORD PTR [rsp+0xd0]
  40b66b:	mov    rcx,QWORD PTR [rax+0x28]
  40b66f:	cmp    QWORD PTR [rbx+0x48],rcx
  40b673:	ja     40b694 <__swc_fn_ff58629f_000070_7130736e+0x164>
  40b675:	mov    ecx,DWORD PTR [rax+0x48]
  40b678:	cmp    DWORD PTR [rbx+0x58],ecx
  40b67b:	ja     40b694 <__swc_fn_ff58629f_000070_7130736e+0x164>
  40b67d:	mov    rcx,QWORD PTR [rbx+0x48]
  40b681:	mov    QWORD PTR [rax+0x20],rcx
  40b685:	add    rsp,0xe0
  40b68c:	pop    r13
  40b68e:	pop    r12
  40b690:	pop    rdi
  40b691:	pop    rsi
  40b692:	pop    rbx
  40b693:	ret
  40b694:	test   r12,r12
  40b697:	je     40b6c9 <__swc_fn_ff58629f_000070_7130736e+0x199>
  40b699:	cmp    QWORD PTR [rbx+0x48],r9
  40b69d:	ja     40b6c9 <__swc_fn_ff58629f_000070_7130736e+0x199>
  40b69f:	cmp    DWORD PTR [rbx+0x58],0x40
  40b6a3:	ja     40b6c9 <__swc_fn_ff58629f_000070_7130736e+0x199>
  40b6a5:	cmp    DWORD PTR [rbx+0x58],0x0
  40b6a9:	je     40b6b6 <__swc_fn_ff58629f_000070_7130736e+0x186>
  40b6ab:	mov    ecx,DWORD PTR [rbx+0x58]
  40b6ae:	dec    rcx
  40b6b1:	test   rdi,rcx
  40b6b4:	jne    40b6c9 <__swc_fn_ff58629f_000070_7130736e+0x199>
  40b6b6:	mov    QWORD PTR [rbx+0x40],rdi
  40b6ba:	add    rsp,0xe0
  40b6c1:	pop    r13
  40b6c3:	pop    r12
  40b6c5:	pop    rdi
  40b6c6:	pop    rsi
  40b6c7:	pop    rbx
  40b6c8:	ret
  40b6c9:	vmovups xmm0,XMMWORD PTR [rbx]
  40b6cd:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40b6d3:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40b6d8:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40b6de:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40b6e3:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40b6e9:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40b6ee:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40b6f4:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40b6f9:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40b6ff:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40b704:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40b70a:	mov    QWORD PTR [rsp+0x48],0x0
  40b713:	mov    rcx,rsi
  40b716:	lea    rdx,[rsp+0x8]
  40b71b:	call   4088d0 <__swc_fn_ff58629f_000069_f3aa21af>
  40b720:	mov    rax,QWORD PTR [rsp+0x48]
  40b725:	test   rax,rax
  40b728:	jne    40b741 <__swc_fn_ff58629f_000070_7130736e+0x211>
  40b72a:	mov    QWORD PTR [rbx+0x40],0x0
  40b732:	add    rsp,0xe0
  40b739:	pop    r13
  40b73b:	pop    r12
  40b73d:	pop    rdi
  40b73e:	pop    rsi
  40b73f:	pop    rbx
  40b740:	ret
  40b741:	mov    rax,QWORD PTR [rbx+0x48]
  40b745:	cmp    r13,rax
  40b748:	cmovbe rax,r13
  40b74c:	mov    rcx,QWORD PTR [rsp+0x48]
  40b751:	mov    rdx,rdi
  40b754:	mov    r8,rax
  40b757:	call   410b00 <__swc_fn_ff58629f_000110_7c204aac>
  40b75c:	vmovups xmm0,XMMWORD PTR [rbx]
  40b760:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40b766:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40b76b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40b771:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40b776:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40b77f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40b784:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40b78d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40b792:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40b79b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40b7a0:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40b7a9:	mov    QWORD PTR [rsp+0xa8],rdi
  40b7b1:	mov    rcx,rsi
  40b7b4:	lea    rdx,[rsp+0x68]
  40b7b9:	call   40f9b0 <__swc_fn_ff58629f_000071_97813b89>
  40b7be:	mov    rax,QWORD PTR [rsp+0x48]
  40b7c3:	mov    QWORD PTR [rbx+0x40],rax
  40b7c7:	add    rsp,0xe0
  40b7ce:	pop    r13
  40b7d0:	pop    r12
  40b7d2:	pop    rdi
  40b7d3:	pop    rsi
  40b7d4:	pop    rbx
  40b7d5:	ret
	...

000000000040b7e0 <__swc_fn_ff58629f_000073_61e60aab>:
  40b7e0:	push   r12
  40b7e2:	push   rdi
  40b7e3:	push   rsi
  40b7e4:	push   r13
  40b7e6:	push   r14
  40b7e8:	sub    rsp,0x190
  40b7ef:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40b7f8:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40b801:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40b80a:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40b813:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40b81c:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40b825:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40b82e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40b837:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40b840:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40b849:	mov    r12,rcx
  40b84c:	lea    rax,[rip+0x157b5]        # 421008 <__swc_data_base_ff58629f+0x8>
  40b853:	mov    rax,QWORD PTR [rax]
  40b856:	cmp    rax,0xffffffffffffffff
  40b85a:	je     40b869 <__swc_fn_ff58629f_000073_61e60aab+0x89>
  40b85c:	mov    eax,eax
  40b85e:	mov    edi,eax
  40b860:	xor    eax,eax
  40b862:	call   407000 <pthread_getspecific@plt>
  40b867:	jmp    40b86b <__swc_fn_ff58629f_000073_61e60aab+0x8b>
  40b869:	xor    eax,eax
  40b86b:	test   rax,rax
  40b86e:	jne    40b87d <__swc_fn_ff58629f_000073_61e60aab+0x9d>
  40b870:	call   407a20 <__swc_fn_ff58629f_000036_cd1a4e8c>
  40b875:	mov    rcx,rax
  40b878:	call   40cfa0 <__swc_fn_ff58629f_000133_5f757033>
  40b87d:	test   rax,rax
  40b880:	je     40b8a6 <__swc_fn_ff58629f_000073_61e60aab+0xc6>
  40b882:	cmp    QWORD PTR [rax],r12
  40b885:	jne    40b8a6 <__swc_fn_ff58629f_000073_61e60aab+0xc6>
  40b887:	xor    ecx,ecx
  40b889:	mov    QWORD PTR [rsp+0xc8],rax
  40b891:	call   40f150 <__swc_fn_ff58629f_000038_28d0e998>
  40b896:	mov    rdx,QWORD PTR [rsp+0xc8]
  40b89e:	mov    rcx,r12
  40b8a1:	call   40f260 <__swc_fn_ff58629f_000047_b30433d0>
  40b8a6:	lea    rsi,[r12+0x10]
  40b8ab:	mov    rcx,rsi
  40b8ae:	call   4112c0 <__swc_fn_ff58629f_000140_86bb0f90>
  40b8b3:	mov    rdi,QWORD PTR [r12+0x20]
  40b8b8:	test   rdi,rdi
  40b8bb:	je     40b8fe <__swc_fn_ff58629f_000073_61e60aab+0x11e>
  40b8bd:	nop    DWORD PTR [rax]
  40b8c0:	mov    rcx,r12
  40b8c3:	mov    rdx,rdi
  40b8c6:	call   407be0 <__swc_fn_ff58629f_000048_6e7a8d58>
  40b8cb:	mov    rcx,r12
  40b8ce:	mov    rdx,rdi
  40b8d1:	mov    r8,0xffffffffffffffff
  40b8d8:	call   40b3b0 <__swc_fn_ff58629f_000064_dea90857>
  40b8dd:	mov    rcx,r12
  40b8e0:	mov    rdx,rdi
  40b8e3:	mov    r8d,0x9b8
  40b8e9:	mov    r9d,0x9b8
  40b8ef:	call   40f180 <__swc_fn_ff58629f_000044_d3c2ab54>
  40b8f4:	mov    rdi,QWORD PTR [r12+0x20]
  40b8f9:	test   rdi,rdi
  40b8fc:	jne    40b8c0 <__swc_fn_ff58629f_000073_61e60aab+0xe0>
  40b8fe:	xor    eax,eax
  40b900:	xchg   QWORD PTR [r12+0x2a80],rax
  40b908:	test   rax,rax
  40b90b:	je     40b931 <__swc_fn_ff58629f_000073_61e60aab+0x151>
  40b90d:	cs nop WORD PTR [rax+rax*1+0x0]
  40b917:	nop    WORD PTR [rax+rax*1+0x0]
  40b920:	mov    rcx,rax
  40b923:	mov    rax,QWORD PTR [rax+0x78]
  40b927:	xor    edx,edx
  40b929:	xchg   DWORD PTR [rcx+0x70],edx
  40b92c:	test   rax,rax
  40b92f:	jne    40b920 <__swc_fn_ff58629f_000073_61e60aab+0x140>
  40b931:	mov    rax,QWORD PTR [r12+0x18]
  40b936:	mov    rdi,rax
  40b939:	test   rdi,rdi
  40b93c:	je     40b9d1 <__swc_fn_ff58629f_000073_61e60aab+0x1f1>
  40b942:	cs nop WORD PTR [rax+rax*1+0x0]
  40b94c:	nop    DWORD PTR [rax+0x0]
  40b950:	mov    rax,QWORD PTR [rdi+0x10]
  40b954:	mov    r8d,DWORD PTR [rdi+0x2c]
  40b958:	xor    r9d,r9d
  40b95b:	test   r8,r8
  40b95e:	jbe    40b9bd <__swc_fn_ff58629f_000073_61e60aab+0x1dd>
  40b960:	mov    ecx,r9d
  40b963:	shl    rcx,0x4
  40b967:	lea    rdx,[rdi+rcx*8+0x80]
  40b96f:	cmp    BYTE PTR [rdx+0x3b],0x0
  40b973:	je     40b9b4 <__swc_fn_ff58629f_000073_61e60aab+0x1d4>
  40b975:	mov    DWORD PTR [rdx+0x28],0x0
  40b97c:	mov    rcx,rdi
  40b97f:	mov    QWORD PTR [rsp+0xd0],rax
  40b987:	mov    QWORD PTR [rsp+0xd8],r8
  40b98f:	mov    QWORD PTR [rsp+0xe0],r9
  40b997:	call   40aae0 <__swc_fn_ff58629f_000019_283e2b5e>
  40b99c:	mov    rax,QWORD PTR [rsp+0xd0]
  40b9a4:	mov    r8,QWORD PTR [rsp+0xd8]
  40b9ac:	mov    r9,QWORD PTR [rsp+0xe0]
  40b9b4:	add    r9,0x1
  40b9b8:	cmp    r9,r8
  40b9bb:	jb     40b960 <__swc_fn_ff58629f_000073_61e60aab+0x180>
  40b9bd:	mov    rcx,rdi
  40b9c0:	mov    rdi,rax
  40b9c3:	call   40f060 <__swc_fn_ff58629f_000026_aa910677>
  40b9c8:	test   rdi,rdi
  40b9cb:	jne    40b950 <__swc_fn_ff58629f_000073_61e60aab+0x170>
  40b9d1:	mov    QWORD PTR [r12+0x18],0x0
  40b9da:	mov    QWORD PTR [r12+0x28],0x0
  40b9e3:	mov    rcx,rsi
  40b9e6:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40b9eb:	mov    esi,0x8
  40b9f0:	xor    edi,edi
  40b9f2:	test   rsi,rsi
  40b9f5:	je     40ba52 <__swc_fn_ff58629f_000073_61e60aab+0x272>
  40b9fb:	nop    DWORD PTR [rax+rax*1+0x0]
  40ba00:	lea    r13,[rdi*8+0x0]
  40ba08:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40ba0d:	test   r14,r14
  40ba10:	je     40ba48 <__swc_fn_ff58629f_000073_61e60aab+0x268>
  40ba12:	cs nop WORD PTR [rax+rax*1+0x0]
  40ba1c:	nop    DWORD PTR [rax+0x0]
  40ba20:	mov    rcx,r12
  40ba23:	mov    rdx,r14
  40ba26:	call   40f810 <__swc_fn_ff58629f_000059_1bb23e77>
  40ba2b:	mov    rcx,r12
  40ba2e:	mov    rdx,QWORD PTR [r14]
  40ba31:	mov    r8,QWORD PTR [r14+0x8]
  40ba35:	mov    r9,QWORD PTR [r14+0x10]
  40ba39:	call   40f180 <__swc_fn_ff58629f_000044_d3c2ab54>
  40ba3e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40ba43:	test   r14,r14
  40ba46:	jne    40ba20 <__swc_fn_ff58629f_000073_61e60aab+0x240>
  40ba48:	add    rdi,0x1
  40ba4c:	sub    rsi,0x1
  40ba50:	jne    40ba00 <__swc_fn_ff58629f_000073_61e60aab+0x220>
  40ba52:	mov    rcx,r12
  40ba55:	call   40f8e0 <__swc_fn_ff58629f_000065_ffcd96eb>
  40ba5a:	lea    rcx,[r12+0x250]
  40ba62:	mov    rdx,QWORD PTR [rcx]
  40ba65:	mov    r8,QWORD PTR [r12+0x250]
  40ba6d:	nop    DWORD PTR [rax]
  40ba70:	mov    r9,r8
  40ba73:	sub    r9,rdx
  40ba76:	mov    rax,r8
  40ba79:	lock cmpxchg QWORD PTR [rcx],r9
  40ba7e:	cmp    rax,r8
  40ba81:	je     40ba88 <__swc_fn_ff58629f_000073_61e60aab+0x2a8>
  40ba83:	mov    r8,rax
  40ba86:	jmp    40ba70 <__swc_fn_ff58629f_000073_61e60aab+0x290>
  40ba88:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40ba91:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40ba9a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40baa3:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40baac:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40bab5:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40babe:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40bac7:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40bad0:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40bad9:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40bae2:	add    rsp,0x190
  40bae9:	pop    r14
  40baeb:	pop    r13
  40baed:	pop    rsi
  40baee:	pop    rdi
  40baef:	pop    r12
  40baf1:	ret
	...

000000000040bb00 <__swc_fn_ff58629f_000076_64d36d78>:
  40bb00:	sub    rsp,0x8
  40bb04:	mov    QWORD PTR [rdx+0x40],0x0
  40bb0c:	call   4088d0 <__swc_fn_ff58629f_000069_f3aa21af>
  40bb11:	add    rsp,0x8
  40bb15:	ret
	...

000000000040bb20 <__swc_fn_ff58629f_000079_1966ae2e>:
  40bb20:	sub    rsp,0x8
  40bb24:	call   40f9b0 <__swc_fn_ff58629f_000071_97813b89>
  40bb29:	add    rsp,0x8
  40bb2d:	ret
	...

000000000040bb30 <__swc_fn_ff58629f_000082_5cc7acfc>:
  40bb30:	push   rbx
  40bb31:	push   rsi
  40bb32:	push   rdi
  40bb33:	push   r12
  40bb35:	push   r13
  40bb37:	push   r14
  40bb39:	push   r15
  40bb3b:	sub    rsp,0x20
  40bb3f:	mov    rbx,r11
  40bb42:	mov    rsi,rcx
  40bb45:	mov    rdi,rdx
  40bb48:	mov    r12,r8
  40bb4b:	mov    r13,r9
  40bb4e:	mov    r14,r10
  40bb51:	mov    rcx,QWORD PTR [rip+0x174e8]        # 423040 <__swc_bss_base_ff58629f>
  40bb58:	test   rcx,rcx
  40bb5b:	jne    40bb6d <__swc_fn_ff58629f_000082_5cc7acfc+0x3d>
  40bb5d:	call   411bc0 <__swc_fn_ff58629f_000170_994c8876>
  40bb62:	lea    rcx,[rax+0x1]
  40bb66:	mov    QWORD PTR [rip+0x174d3],rcx        # 423040 <__swc_bss_base_ff58629f>
  40bb6d:	dec    rcx
  40bb70:	call   40ea20 <__swc_fn_ff58629f_000172_360af05d>
  40bb75:	mov    r15,rax
  40bb78:	lea    r11,[rip+0x176c1]        # 423240 <__swc_bss_base_ff58629f+0x200>
  40bb7f:	mov    rcx,r11
  40bb82:	call   40f170 <__swc_fn_ff58629f_000041_eb6108f2>
  40bb87:	test   al,al
  40bb89:	jne    40bb9a <__swc_fn_ff58629f_000082_5cc7acfc+0x6a>
  40bb8b:	mov    rcx,r11
  40bb8e:	call   407a80 <__swc_fn_ff58629f_000039_14f56618>
  40bb93:	lea    r11,[rip+0x176a6]        # 423240 <__swc_bss_base_ff58629f+0x200>
  40bb9a:	mov    rcx,r11
  40bb9d:	mov    rdx,rsi
  40bba0:	mov    r8,rdi
  40bba3:	mov    r9,r12
  40bba6:	mov    r10,r13
  40bba9:	mov    rsi,r11
  40bbac:	mov    r11,r14
  40bbaf:	call   40ae50 <__swc_fn_ff58629f_000040_03f1bf9a>
  40bbb4:	test   bl,bl
  40bbb6:	je     40bbdd <__swc_fn_ff58629f_000082_5cc7acfc+0xad>
  40bbb8:	mov    QWORD PTR [rsp+0x8],rsi
  40bbbd:	lea    rax,[rip+0x66b4]        # 412278 <__swc_rdata_base_ff58629f+0x168>
  40bbc4:	mov    QWORD PTR [rsp+0x10],rax
  40bbc9:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40bbcf:	vmovups XMMWORD PTR [r15],xmm0
  40bbd4:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40bbdd:	mov    rax,rsi
  40bbe0:	add    rsp,0x20
  40bbe4:	pop    r15
  40bbe6:	pop    r14
  40bbe8:	pop    r13
  40bbea:	pop    r12
  40bbec:	pop    rdi
  40bbed:	pop    rsi
  40bbee:	pop    rbx
  40bbef:	ret

000000000040bbf0 <__swc_fn_ff58629f_000085_cf82995a>:
  40bbf0:	sub    rsp,0x8
  40bbf4:	mov    rax,rcx
  40bbf7:	test   rcx,rcx
  40bbfa:	jne    40bc01 <__swc_fn_ff58629f_000085_cf82995a+0x11>
  40bbfc:	add    rsp,0x8
  40bc00:	ret
  40bc01:	lea    rcx,[rax-0x10]
  40bc05:	mov    rax,QWORD PTR [rax-0x10]
  40bc09:	mov    rdx,rax
  40bc0c:	call   40cc50 <__swc_fn_ff58629f_000118_ed2d8fed>
  40bc11:	add    rsp,0x8
  40bc15:	ret
	...

000000000040bc20 <__swc_fn_ff58629f_000088_ef55f6e4>:
  40bc20:	sub    rsp,0x8
  40bc24:	xor    r11d,r11d
  40bc27:	call   40fc70 <__swc_fn_ff58629f_000089_0d280354>
  40bc2c:	add    rsp,0x8
  40bc30:	ret
	...

000000000040bc40 <__swc_fn_ff58629f_000091_23214800>:
  40bc40:	push   rsi
  40bc41:	push   rdi
  40bc42:	push   r12
  40bc44:	push   r13
  40bc46:	push   r14
  40bc48:	push   r15
  40bc4a:	sub    rsp,0x68
  40bc4e:	mov    rsi,r9
  40bc51:	mov    rdi,rcx
  40bc54:	mov    r12,rdx
  40bc57:	mov    r13,r8
  40bc5a:	cmp    r8,r9
  40bc5d:	jne    40bc85 <__swc_fn_ff58629f_000091_23214800+0x45>
  40bc5f:	mov    rcx,rdi
  40bc62:	mov    rdx,r12
  40bc65:	xor    r8d,r8d
  40bc68:	call   40ffc0 <__swc_fn_ff58629f_000095_63c1827b>
  40bc6d:	test   al,al
  40bc6f:	je     40bc85 <__swc_fn_ff58629f_000091_23214800+0x45>
  40bc71:	mov    eax,0x1
  40bc76:	add    rsp,0x68
  40bc7a:	pop    r15
  40bc7c:	pop    r14
  40bc7e:	pop    r13
  40bc80:	pop    r12
  40bc82:	pop    rdi
  40bc83:	pop    rsi
  40bc84:	ret
  40bc85:	cmp    BYTE PTR [r12+0x2c],0xe
  40bc8b:	je     40bc9e <__swc_fn_ff58629f_000091_23214800+0x5e>
  40bc8d:	xor    eax,eax
  40bc8f:	add    rsp,0x68
  40bc93:	pop    r15
  40bc95:	pop    r14
  40bc97:	pop    r13
  40bc99:	pop    r12
  40bc9b:	pop    rdi
  40bc9c:	pop    rsi
  40bc9d:	ret
  40bc9e:	mov    r14,QWORD PTR [r12+0x98]
  40bca6:	mov    rax,QWORD PTR [r12+0xa0]
  40bcae:	mov    r12,rax
  40bcb1:	xor    r15d,r15d
  40bcb4:	test   r12,r12
  40bcb7:	je     40bd1f <__swc_fn_ff58629f_000091_23214800+0xdf>
  40bcb9:	nop    DWORD PTR [rax+0x0]
  40bcc0:	mov    QWORD PTR [rsp+0x58],r12
  40bcc5:	lea    r12,[r15*8+0x0]
  40bccd:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40bcd2:	mov    rcx,rax
  40bcd5:	call   409060 <__swc_fn_ff58629f_000087_3953ef98>
  40bcda:	cmp    BYTE PTR [rax+0x2c],0xe
  40bcde:	jne    40bd10 <__swc_fn_ff58629f_000091_23214800+0xd0>
  40bce0:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40bce5:	lea    r8,[r13+rcx*1+0x0]
  40bcea:	mov    rcx,rdi
  40bced:	mov    rdx,rax
  40bcf0:	mov    r9,rsi
  40bcf3:	call   40bc40 <__swc_fn_ff58629f_000091_23214800>
  40bcf8:	test   al,al
  40bcfa:	je     40bd10 <__swc_fn_ff58629f_000091_23214800+0xd0>
  40bcfc:	mov    eax,0x1
  40bd01:	add    rsp,0x68
  40bd05:	pop    r15
  40bd07:	pop    r14
  40bd09:	pop    r13
  40bd0b:	pop    r12
  40bd0d:	pop    rdi
  40bd0e:	pop    rsi
  40bd0f:	ret
  40bd10:	add    r15,0x1
  40bd14:	mov    r12,QWORD PTR [rsp+0x58]
  40bd19:	sub    r12,0x1
  40bd1d:	jne    40bcc0 <__swc_fn_ff58629f_000091_23214800+0x80>
  40bd1f:	xor    eax,eax
  40bd21:	add    rsp,0x68
  40bd25:	pop    r15
  40bd27:	pop    r14
  40bd29:	pop    r13
  40bd2b:	pop    r12
  40bd2d:	pop    rdi
  40bd2e:	pop    rsi
  40bd2f:	ret

000000000040bd30 <__swc_fn_ff58629f_000094_c2567a3b>:
  40bd30:	push   rbp
  40bd31:	push   rbx
  40bd32:	push   rsi
  40bd33:	push   rdi
  40bd34:	push   r12
  40bd36:	push   r13
  40bd38:	push   r14
  40bd3a:	push   r15
  40bd3c:	sub    rsp,0x38
  40bd40:	mov    rbp,rsp
  40bd43:	mov    rbx,r11
  40bd46:	mov    rsi,rdx
  40bd49:	mov    rdi,r8
  40bd4c:	mov    r12,r9
  40bd4f:	mov    QWORD PTR [rsp+0x18],r9
  40bd54:	mov    r13,r10
  40bd57:	movzx  r14d,BYTE PTR [rbp+0x80]
  40bd5f:	movzx  r15d,BYTE PTR [rbp+0x88]
  40bd67:	test   r11,r11
  40bd6a:	je     40bd70 <__swc_fn_ff58629f_000094_c2567a3b+0x40>
  40bd6c:	xor    eax,eax
  40bd6e:	mov    BYTE PTR [rbx],al
  40bd70:	test   r12,r12
  40bd73:	je     40bd7e <__swc_fn_ff58629f_000094_c2567a3b+0x4e>
  40bd75:	mov    QWORD PTR [r12+0x8],0x0
  40bd7e:	test   rcx,rcx
  40bd81:	je     40bd88 <__swc_fn_ff58629f_000094_c2567a3b+0x58>
  40bd83:	test   rsi,rsi
  40bd86:	jne    40bd9b <__swc_fn_ff58629f_000094_c2567a3b+0x6b>
  40bd88:	xor    eax,eax
  40bd8a:	add    rsp,0x38
  40bd8e:	pop    r15
  40bd90:	pop    r14
  40bd92:	pop    r13
  40bd94:	pop    r12
  40bd96:	pop    rdi
  40bd97:	pop    rsi
  40bd98:	pop    rbx
  40bd99:	pop    rbp
  40bd9a:	ret
  40bd9b:	call   409060 <__swc_fn_ff58629f_000087_3953ef98>
  40bda0:	mov    r12,rax
  40bda3:	mov    al,r15b
  40bda6:	test   r15b,r15b
  40bda9:	jne    40bdb9 <__swc_fn_ff58629f_000094_c2567a3b+0x89>
  40bdab:	mov    eax,DWORD PTR [r12+0x28]
  40bdb0:	and    eax,0x10000
  40bdb6:	setne  al
  40bdb9:	lea    r15,[rsp+0x8]
  40bdbe:	mov    QWORD PTR [rsp+0x20],r15
  40bdc3:	rex mov BYTE PTR [rsp+0x8],al
  40bdc8:	test   DWORD PTR [rsi+0x28],0x400000
  40bdcf:	je     40be07 <__swc_fn_ff58629f_000094_c2567a3b+0xd7>
  40bdd1:	test   rsi,rsi
  40bdd4:	je     40bdf4 <__swc_fn_ff58629f_000094_c2567a3b+0xc4>
  40bdd6:	mov    rax,QWORD PTR [rsi+0x38]
  40bdda:	cmp    QWORD PTR [rax+0x10],rsi
  40bdde:	jne    40bdf4 <__swc_fn_ff58629f_000094_c2567a3b+0xc4>
  40bde0:	rex mov al,BYTE PTR [rsp+0x8]
  40bde5:	test   al,al
  40bde7:	sete   al
  40bdea:	test   r14b,r14b
  40bded:	sete   cl
  40bdf0:	test   al,cl
  40bdf2:	je     40be07 <__swc_fn_ff58629f_000094_c2567a3b+0xd7>
  40bdf4:	xor    eax,eax
  40bdf6:	add    rsp,0x38
  40bdfa:	pop    r15
  40bdfc:	pop    r14
  40bdfe:	pop    r13
  40be00:	pop    r12
  40be02:	pop    rdi
  40be03:	pop    rsi
  40be04:	pop    rbx
  40be05:	pop    rbp
  40be06:	ret
  40be07:	mov    r15,r12
  40be0a:	test   r14b,r14b
  40be0d:	jne    40be24 <__swc_fn_ff58629f_000094_c2567a3b+0xf4>
  40be0f:	cmp    BYTE PTR [r12+0x2c],0x6
  40be15:	jne    40be24 <__swc_fn_ff58629f_000094_c2567a3b+0xf4>
  40be17:	mov    rcx,QWORD PTR [r12+0x40]
  40be1c:	call   409060 <__swc_fn_ff58629f_000087_3953ef98>
  40be21:	mov    r15,rax
  40be24:	test   r14b,r14b
  40be27:	je     40be2d <__swc_fn_ff58629f_000094_c2567a3b+0xfd>
  40be29:	mov    r15,QWORD PTR [r15+0x30]
  40be2d:	mov    rcx,rsi
  40be30:	call   409060 <__swc_fn_ff58629f_000087_3953ef98>
  40be35:	mov    rsi,rax
  40be38:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40be3d:	je     40be74 <__swc_fn_ff58629f_000094_c2567a3b+0x144>
  40be3f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40be44:	je     40be74 <__swc_fn_ff58629f_000094_c2567a3b+0x144>
  40be46:	mov    eax,DWORD PTR [rsi+0x28]
  40be49:	and    eax,0x10000
  40be4f:	je     40be74 <__swc_fn_ff58629f_000094_c2567a3b+0x144>
  40be51:	rex mov al,BYTE PTR [rsp+0x8]
  40be56:	test   al,al
  40be58:	jne    40be6d <__swc_fn_ff58629f_000094_c2567a3b+0x13d>
  40be5a:	xor    eax,eax
  40be5c:	add    rsp,0x38
  40be60:	pop    r15
  40be62:	pop    r14
  40be64:	pop    r13
  40be66:	pop    r12
  40be68:	pop    rdi
  40be69:	pop    rsi
  40be6a:	pop    rbx
  40be6b:	pop    rbp
  40be6c:	ret
  40be6d:	mov    rax,QWORD PTR [rsi+0x30]
  40be71:	mov    rsi,rax
  40be74:	mov    r14b,r13b
  40be77:	test   rbx,rbx
  40be7a:	je     40beb0 <__swc_fn_ff58629f_000094_c2567a3b+0x180>
  40be7c:	cmp    BYTE PTR [r12+0x2c],0x6
  40be82:	jne    40beb0 <__swc_fn_ff58629f_000094_c2567a3b+0x180>
  40be84:	lea    rdx,[rip+0x641d]        # 4122a8 <__swc_rdata_base_ff58629f+0x198>
  40be8b:	mov    rcx,rsi
  40be8e:	xor    r8d,r8d
  40be91:	call   40ffc0 <__swc_fn_ff58629f_000095_63c1827b>
  40be96:	test   al,al
  40be98:	je     40beb0 <__swc_fn_ff58629f_000094_c2567a3b+0x180>
  40be9a:	mov    BYTE PTR [rbx],0x1
  40be9d:	xor    eax,eax
  40be9f:	add    rsp,0x38
  40bea3:	pop    r15
  40bea5:	pop    r14
  40bea7:	pop    r13
  40bea9:	pop    r12
  40beab:	pop    rdi
  40beac:	pop    rsi
  40bead:	pop    rbx
  40beae:	pop    rbp
  40beaf:	ret
  40beb0:	test   rdi,rdi
  40beb3:	jne    40becd <__swc_fn_ff58629f_000094_c2567a3b+0x19d>
  40beb5:	test   r13b,r13b
  40beb8:	jne    40becd <__swc_fn_ff58629f_000094_c2567a3b+0x19d>
  40beba:	xor    eax,eax
  40bebc:	add    rsp,0x38
  40bec0:	pop    r15
  40bec2:	pop    r14
  40bec4:	pop    r13
  40bec6:	pop    r12
  40bec8:	pop    rdi
  40bec9:	pop    rsi
  40beca:	pop    rbx
  40becb:	pop    rbp
  40becc:	ret
  40becd:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40bed2:	jne    40bf88 <__swc_fn_ff58629f_000094_c2567a3b+0x258>
  40bed8:	mov    rcx,r15
  40bedb:	mov    rdx,rsi
  40bede:	xor    r8d,r8d
  40bee1:	call   40ffc0 <__swc_fn_ff58629f_000095_63c1827b>
  40bee6:	test   al,al
  40bee8:	jne    40bf88 <__swc_fn_ff58629f_000094_c2567a3b+0x258>
  40beee:	test   DWORD PTR [rsi+0x28],0x10000
  40bef5:	je     40bf13 <__swc_fn_ff58629f_000094_c2567a3b+0x1e3>
  40bef7:	rex mov al,BYTE PTR [rsp+0x8]
  40befc:	test   al,al
  40befe:	jne    40bf13 <__swc_fn_ff58629f_000094_c2567a3b+0x1e3>
  40bf00:	xor    eax,eax
  40bf02:	add    rsp,0x38
  40bf06:	pop    r15
  40bf08:	pop    r14
  40bf0a:	pop    r13
  40bf0c:	pop    r12
  40bf0e:	pop    rdi
  40bf0f:	pop    rsi
  40bf10:	pop    rbx
  40bf11:	pop    rbp
  40bf12:	ret
  40bf13:	test   rdi,rdi
  40bf16:	jne    40bf2b <__swc_fn_ff58629f_000094_c2567a3b+0x1fb>
  40bf18:	xor    eax,eax
  40bf1a:	add    rsp,0x38
  40bf1e:	pop    r15
  40bf20:	pop    r14
  40bf22:	pop    r13
  40bf24:	pop    r12
  40bf26:	pop    rdi
  40bf27:	pop    rsi
  40bf28:	pop    rbx
  40bf29:	pop    rbp
  40bf2a:	ret
  40bf2b:	mov    rcx,QWORD PTR [rsi+0x40]
  40bf2f:	call   409060 <__swc_fn_ff58629f_000087_3953ef98>
  40bf34:	mov    rsi,rax
  40bf37:	mov    rax,QWORD PTR [rdi]
  40bf3a:	mov    rdi,rax
  40bf3d:	test   rax,rax
  40bf40:	jne    40bf83 <__swc_fn_ff58629f_000094_c2567a3b+0x253>
  40bf42:	test   rbx,rbx
  40bf45:	je     40bf83 <__swc_fn_ff58629f_000094_c2567a3b+0x253>
  40bf47:	mov    rcx,r15
  40bf4a:	mov    rdx,rsi
  40bf4d:	xor    r8d,r8d
  40bf50:	call   40ffc0 <__swc_fn_ff58629f_000095_63c1827b>
  40bf55:	mov    rcx,rax
  40bf58:	test   al,al
  40bf5a:	jne    40bf7c <__swc_fn_ff58629f_000094_c2567a3b+0x24c>
  40bf5c:	mov    rcx,r15
  40bf5f:	mov    rdx,rsi
  40bf62:	call   4090a0 <__swc_fn_ff58629f_000090_d182c4dc>
  40bf67:	mov    rcx,rax
  40bf6a:	test   al,al
  40bf6c:	jne    40bf7c <__swc_fn_ff58629f_000094_c2567a3b+0x24c>
  40bf6e:	mov    rcx,rsi
  40bf71:	mov    rdx,r15
  40bf74:	call   4090a0 <__swc_fn_ff58629f_000090_d182c4dc>
  40bf79:	mov    rcx,rax
  40bf7c:	test   cl,cl
  40bf7e:	setne  al
  40bf81:	mov    BYTE PTR [rbx],al
  40bf83:	xor    eax,eax
  40bf85:	mov    r14b,al
  40bf88:	test   rdi,rdi
  40bf8b:	jne    40bfa5 <__swc_fn_ff58629f_000094_c2567a3b+0x275>
  40bf8d:	test   r14b,r14b
  40bf90:	jne    40bfa5 <__swc_fn_ff58629f_000094_c2567a3b+0x275>
  40bf92:	xor    eax,eax
  40bf94:	add    rsp,0x38
  40bf98:	pop    r15
  40bf9a:	pop    r14
  40bf9c:	pop    r13
  40bf9e:	pop    r12
  40bfa0:	pop    rdi
  40bfa1:	pop    rsi
  40bfa2:	pop    rbx
  40bfa3:	pop    rbp
  40bfa4:	ret
  40bfa5:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40bfaa:	je     40bfb6 <__swc_fn_ff58629f_000094_c2567a3b+0x286>
  40bfac:	mov    r12,QWORD PTR [rsp+0x18]
  40bfb1:	jmp    40c03e <__swc_fn_ff58629f_000094_c2567a3b+0x30e>
  40bfb6:	mov    r12,QWORD PTR [rsp+0x18]
  40bfbb:	test   r12,r12
  40bfbe:	jne    40bfd2 <__swc_fn_ff58629f_000094_c2567a3b+0x2a2>
  40bfc0:	mov    rcx,r15
  40bfc3:	mov    rdx,rsi
  40bfc6:	xor    r8d,r8d
  40bfc9:	call   40ffc0 <__swc_fn_ff58629f_000095_63c1827b>
  40bfce:	test   al,al
  40bfd0:	jne    40c03e <__swc_fn_ff58629f_000094_c2567a3b+0x30e>
  40bfd2:	test   DWORD PTR [rsi+0x28],0x10000
  40bfd9:	je     40bff7 <__swc_fn_ff58629f_000094_c2567a3b+0x2c7>
  40bfdb:	rex mov al,BYTE PTR [rsp+0x8]
  40bfe0:	test   al,al
  40bfe2:	jne    40bff7 <__swc_fn_ff58629f_000094_c2567a3b+0x2c7>
  40bfe4:	xor    eax,eax
  40bfe6:	add    rsp,0x38
  40bfea:	pop    r15
  40bfec:	pop    r14
  40bfee:	pop    r13
  40bff0:	pop    r12
  40bff2:	pop    rdi
  40bff3:	pop    rsi
  40bff4:	pop    rbx
  40bff5:	pop    rbp
  40bff6:	ret
  40bff7:	test   rdi,rdi
  40bffa:	jne    40c00f <__swc_fn_ff58629f_000094_c2567a3b+0x2df>
  40bffc:	xor    eax,eax
  40bffe:	add    rsp,0x38
  40c002:	pop    r15
  40c004:	pop    r14
  40c006:	pop    r13
  40c008:	pop    r12
  40c00a:	pop    rdi
  40c00b:	pop    rsi
  40c00c:	pop    rbx
  40c00d:	pop    rbp
  40c00e:	ret
  40c00f:	cmp    QWORD PTR [rdi+0x8],0x0
  40c014:	jne    40c029 <__swc_fn_ff58629f_000094_c2567a3b+0x2f9>
  40c016:	xor    eax,eax
  40c018:	add    rsp,0x38
  40c01c:	pop    r15
  40c01e:	pop    r14
  40c020:	pop    r13
  40c022:	pop    r12
  40c024:	pop    rdi
  40c025:	pop    rsi
  40c026:	pop    rbx
  40c027:	pop    rbp
  40c028:	ret
  40c029:	mov    rax,QWORD PTR [rdi+0x8]
  40c02d:	mov    rax,QWORD PTR [rax]
  40c030:	mov    rsi,rax
  40c033:	mov    rdi,QWORD PTR [rdi]
  40c036:	mov    eax,0x1
  40c03b:	mov    r14b,al
  40c03e:	test   rdi,rdi
  40c041:	mov    rbx,QWORD PTR [rsp+0x20]
  40c046:	jne    40c090 <__swc_fn_ff58629f_000094_c2567a3b+0x360>
  40c048:	test   r14b,r14b
  40c04b:	je     40c07d <__swc_fn_ff58629f_000094_c2567a3b+0x34d>
  40c04d:	test   r12,r12
  40c050:	je     40c07d <__swc_fn_ff58629f_000094_c2567a3b+0x34d>
  40c052:	mov    rcx,r15
  40c055:	mov    rdx,rsi
  40c058:	xor    r8d,r8d
  40c05b:	mov    r9,r12
  40c05e:	mov    rbx,QWORD PTR [rsp+0x20]
  40c063:	movzx  r10d,BYTE PTR [rbx]
  40c067:	call   40bc20 <__swc_fn_ff58629f_000088_ef55f6e4>
  40c06c:	add    rsp,0x38
  40c070:	pop    r15
  40c072:	pop    r14
  40c074:	pop    r13
  40c076:	pop    r12
  40c078:	pop    rdi
  40c079:	pop    rsi
  40c07a:	pop    rbx
  40c07b:	pop    rbp
  40c07c:	ret
  40c07d:	xor    eax,eax
  40c07f:	add    rsp,0x38
  40c083:	pop    r15
  40c085:	pop    r14
  40c087:	pop    r13
  40c089:	pop    r12
  40c08b:	pop    rdi
  40c08c:	pop    rsi
  40c08d:	pop    rbx
  40c08e:	pop    rbp
  40c08f:	ret
  40c090:	mov    r13,rsi
  40c093:	mov    QWORD PTR [rsp+0x28],rdi
  40c098:	cmp    BYTE PTR [r15+0x2c],0xe
  40c09d:	sete   al
  40c0a0:	mov    r14b,al
  40c0a3:	jne    40c0b7 <__swc_fn_ff58629f_000094_c2567a3b+0x387>
  40c0a5:	mov    rcx,rsi
  40c0a8:	mov    rdx,r15
  40c0ab:	call   4090a0 <__swc_fn_ff58629f_000090_d182c4dc>
  40c0b0:	mov    r14b,al
  40c0b3:	test   al,al
  40c0b5:	jne    40c0ec <__swc_fn_ff58629f_000094_c2567a3b+0x3bc>
  40c0b7:	cmp    BYTE PTR [r15+0x2c],0x12
  40c0bc:	je     40c0ec <__swc_fn_ff58629f_000094_c2567a3b+0x3bc>
  40c0be:	mov    rcx,r15
  40c0c1:	mov    rdx,rsi
  40c0c4:	mov    r8,rdi
  40c0c7:	mov    r9,r12
  40c0ca:	mov    rax,rbx
  40c0cd:	movzx  r10d,BYTE PTR [rax]
  40c0d1:	call   40bc20 <__swc_fn_ff58629f_000088_ef55f6e4>
  40c0d6:	test   rax,rax
  40c0d9:	je     40c0ec <__swc_fn_ff58629f_000094_c2567a3b+0x3bc>
  40c0db:	add    rsp,0x38
  40c0df:	pop    r15
  40c0e1:	pop    r14
  40c0e3:	pop    r13
  40c0e5:	pop    r12
  40c0e7:	pop    rdi
  40c0e8:	pop    rsi
  40c0e9:	pop    rbx
  40c0ea:	pop    rbp
  40c0eb:	ret
  40c0ec:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40c0f1:	jne    40c110 <__swc_fn_ff58629f_000094_c2567a3b+0x3e0>
  40c0f3:	mov    rax,QWORD PTR [rsi+0xd8]
  40c0fa:	test   rax,rax
  40c0fd:	je     40c110 <__swc_fn_ff58629f_000094_c2567a3b+0x3e0>
  40c0ff:	add    rdi,QWORD PTR [rax+0x8]
  40c103:	mov    rax,QWORD PTR [rdi]
  40c106:	sub    rdi,QWORD PTR [rax+0x8]
  40c10a:	mov    rax,QWORD PTR [rax]
  40c10d:	mov    rsi,rax
  40c110:	test   r14b,r14b
  40c113:	je     40c13f <__swc_fn_ff58629f_000094_c2567a3b+0x40f>
  40c115:	mov    rcx,r15
  40c118:	mov    rdx,rsi
  40c11b:	mov    r8,rdi
  40c11e:	mov    r9,r13
  40c121:	mov    r14,QWORD PTR [rsp+0x28]
  40c126:	mov    r10,r14
  40c129:	call   40fea0 <__swc_fn_ff58629f_000092_c1c9085b>
  40c12e:	add    rsp,0x38
  40c132:	pop    r15
  40c134:	pop    r14
  40c136:	pop    r13
  40c138:	pop    r12
  40c13a:	pop    rdi
  40c13b:	pop    rsi
  40c13c:	pop    rbx
  40c13d:	pop    rbp
  40c13e:	ret
  40c13f:	mov    rcx,r15
  40c142:	mov    rdx,rsi
  40c145:	mov    r8,rdi
  40c148:	mov    r9,r12
  40c14b:	movzx  r10d,BYTE PTR [rbx]
  40c14f:	call   40bc20 <__swc_fn_ff58629f_000088_ef55f6e4>
  40c154:	add    rsp,0x38
  40c158:	pop    r15
  40c15a:	pop    r14
  40c15c:	pop    r13
  40c15e:	pop    r12
  40c160:	pop    rdi
  40c161:	pop    rsi
  40c162:	pop    rbx
  40c163:	pop    rbp
  40c164:	ret
	...

000000000040c170 <__swc_fn_ff58629f_000097_93bfe675>:
  40c170:	push   rbx
  40c171:	push   rsi
  40c172:	sub    rsp,0x18
  40c176:	mov    rbx,rcx
  40c179:	mov    rcx,QWORD PTR [rip+0x16ec0]        # 423040 <__swc_bss_base_ff58629f>
  40c180:	test   rcx,rcx
  40c183:	jne    40c195 <__swc_fn_ff58629f_000097_93bfe675+0x25>
  40c185:	call   411bc0 <__swc_fn_ff58629f_000170_994c8876>
  40c18a:	lea    rcx,[rax+0x1]
  40c18e:	mov    QWORD PTR [rip+0x16eab],rcx        # 423040 <__swc_bss_base_ff58629f>
  40c195:	dec    rcx
  40c198:	call   40ea20 <__swc_fn_ff58629f_000172_360af05d>
  40c19d:	mov    rsi,rax
  40c1a0:	mov    rax,QWORD PTR [rsi+0x8]
  40c1a4:	test   rax,rax
  40c1a7:	jne    40c1f7 <__swc_fn_ff58629f_000097_93bfe675+0x87>
  40c1a9:	call   409190 <__swc_fn_ff58629f_000096_ad13d15c>
  40c1ae:	test   al,al
  40c1b0:	jne    40c1f7 <__swc_fn_ff58629f_000097_93bfe675+0x87>
  40c1b2:	lea    rdx,[rip+0x17087]        # 423240 <__swc_bss_base_ff58629f+0x200>
  40c1b9:	mov    rcx,rdx
  40c1bc:	call   40f170 <__swc_fn_ff58629f_000041_eb6108f2>
  40c1c1:	test   al,al
  40c1c3:	jne    40c1d4 <__swc_fn_ff58629f_000097_93bfe675+0x64>
  40c1c5:	mov    rcx,rdx
  40c1c8:	call   407a80 <__swc_fn_ff58629f_000039_14f56618>
  40c1cd:	lea    rdx,[rip+0x1706c]        # 423240 <__swc_bss_base_ff58629f+0x200>
  40c1d4:	mov    QWORD PTR [rsp+0x8],rdx
  40c1d9:	lea    rax,[rip+0x6098]        # 412278 <__swc_rdata_base_ff58629f+0x168>
  40c1e0:	mov    QWORD PTR [rsp+0x10],rax
  40c1e5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c1eb:	vmovups XMMWORD PTR [rsi],xmm0
  40c1ef:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40c1f7:	vmovups xmm0,XMMWORD PTR [rsi]
  40c1fb:	vmovups XMMWORD PTR [rbx],xmm0
  40c1ff:	mov    rax,rbx
  40c202:	add    rsp,0x18
  40c206:	pop    rsi
  40c207:	pop    rbx
  40c208:	ret
  40c209:	add    BYTE PTR [rax],al
  40c20b:	add    BYTE PTR [rax],al
  40c20d:	add    BYTE PTR [rax],al
	...

000000000040c210 <__swc_fn_ff58629f_000100_65137b72>:
  40c210:	sub    rsp,0x8
  40c214:	call   410d60 <__swc_fn_ff58629f_000122_0a5fa85a>
  40c219:	add    rsp,0x8
  40c21d:	ret
	...

000000000040c220 <__swc_fn_ff58629f_000103_e34f54dc>:
  40c220:	push   rbx
  40c221:	push   rsi
  40c222:	sub    rsp,0x28
  40c226:	mov    rbx,rcx
  40c229:	xor    esi,esi
  40c22b:	jmp    40c240 <__swc_fn_ff58629f_000103_e34f54dc+0x20>
  40c22d:	nop    DWORD PTR [rax]
  40c230:	mov    QWORD PTR [rbx+0x28],rsi
  40c234:	mov    rsi,rbx
  40c237:	mov    rbx,rax
  40c23a:	nop    WORD PTR [rax+rax*1+0x0]
  40c240:	test   rbx,rbx
  40c243:	je     40c2a3 <__swc_fn_ff58629f_000103_e34f54dc+0x83>
  40c245:	mov    rcx,rbx
  40c248:	mov    edx,0x1
  40c24d:	call   40fc20 <__swc_fn_ff58629f_000083_63a67586>
  40c252:	cmp    rax,0x1
  40c256:	jne    40c2a3 <__swc_fn_ff58629f_000103_e34f54dc+0x83>
  40c258:	mov    r10,QWORD PTR [rbx+0x18]
  40c25c:	mov    rcx,r10
  40c25f:	mov    edx,0x1
  40c264:	call   40fc20 <__swc_fn_ff58629f_000083_63a67586>
  40c269:	cmp    rax,0x1
  40c26d:	jne    40c27c <__swc_fn_ff58629f_000103_e34f54dc+0x5c>
  40c26f:	mov    rcx,r10
  40c272:	call   409330 <__swc_fn_ff58629f_000102_d0b19c14>
  40c277:	test   rax,rax
  40c27a:	jne    40c230 <__swc_fn_ff58629f_000103_e34f54dc+0x10>
  40c27c:	mov    rax,QWORD PTR [rbx+0x20]
  40c280:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40c285:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c28b:	lea    rcx,[rsp+0x8]
  40c290:	mov    rdx,rbx
  40c293:	mov    r8d,0x30
  40c299:	mov    rbx,rax
  40c29c:	call   410380 <__swc_fn_ff58629f_000101_d4bdcaa4>
  40c2a1:	jmp    40c240 <__swc_fn_ff58629f_000103_e34f54dc+0x20>
  40c2a3:	test   rsi,rsi
  40c2a6:	jne    40c2af <__swc_fn_ff58629f_000103_e34f54dc+0x8f>
  40c2a8:	add    rsp,0x28
  40c2ac:	pop    rsi
  40c2ad:	pop    rbx
  40c2ae:	ret
  40c2af:	mov    rax,rsi
  40c2b2:	mov    rsi,QWORD PTR [rsi+0x28]
  40c2b6:	mov    rbx,QWORD PTR [rax+0x20]
  40c2ba:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40c2bf:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40c2c5:	lea    rcx,[rsp+0x18]
  40c2ca:	mov    rdx,rax
  40c2cd:	mov    r8d,0x30
  40c2d3:	call   410380 <__swc_fn_ff58629f_000101_d4bdcaa4>
  40c2d8:	jmp    40c240 <__swc_fn_ff58629f_000103_e34f54dc+0x20>
  40c2dd:	add    BYTE PTR [rax],al
	...

000000000040c2e0 <__swc_fn_ff58629f_000106_5a85fcf5>:
  40c2e0:	push   rbx
  40c2e1:	push   rsi
  40c2e2:	push   rdi
  40c2e3:	push   r12
  40c2e5:	push   r13
  40c2e7:	sub    rsp,0x20
  40c2eb:	mov    rbx,rcx
  40c2ee:	lea    rsi,[rcx+0x6f8]
  40c2f5:	mov    edi,0x4
  40c2fa:	mov    r12,rsi
  40c2fd:	test   rdi,rdi
  40c300:	je     40c34a <__swc_fn_ff58629f_000106_5a85fcf5+0x6a>
  40c302:	cs nop WORD PTR [rax+rax*1+0x0]
  40c30c:	nop    DWORD PTR [rax+0x0]
  40c310:	mov    rcx,QWORD PTR [r12+0x10]
  40c315:	mov    QWORD PTR [r12+0x10],0x0
  40c31e:	vxorps xmm0,xmm0,xmm0
  40c322:	vmovups XMMWORD PTR [r12],xmm0
  40c328:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40c32f:	mov    DWORD PTR [r12+0x20],0x0
  40c338:	call   4103d0 <__swc_fn_ff58629f_000104_2fdd2c61>
  40c33d:	add    r12,0x90
  40c344:	sub    rdi,0x1
  40c348:	jne    40c310 <__swc_fn_ff58629f_000106_5a85fcf5+0x30>
  40c34a:	mov    rax,QWORD PTR [rbx+0x938]
  40c351:	mov    rdi,rax
  40c354:	test   rdi,rdi
  40c357:	je     40c3b1 <__swc_fn_ff58629f_000106_5a85fcf5+0xd1>
  40c359:	nop    DWORD PTR [rax+0x0]
  40c360:	mov    r12d,0x10
  40c366:	lea    r13,[rdi+0x18]
  40c36a:	test   r12,r12
  40c36d:	je     40c3a6 <__swc_fn_ff58629f_000106_5a85fcf5+0xc6>
  40c36f:	nop
  40c370:	mov    rcx,QWORD PTR [r13+0x10]
  40c374:	mov    QWORD PTR [r13+0x10],0x0
  40c37c:	vxorps xmm0,xmm0,xmm0
  40c380:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40c386:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40c38c:	mov    DWORD PTR [r13+0x20],0x0
  40c394:	call   4103d0 <__swc_fn_ff58629f_000104_2fdd2c61>
  40c399:	add    r13,0x90
  40c3a0:	sub    r12,0x1
  40c3a4:	jne    40c370 <__swc_fn_ff58629f_000106_5a85fcf5+0x90>
  40c3a6:	mov    rax,QWORD PTR [rdi]
  40c3a9:	mov    rdi,rax
  40c3ac:	test   rax,rax
  40c3af:	jne    40c360 <__swc_fn_ff58629f_000106_5a85fcf5+0x80>
  40c3b1:	vxorps xmm0,xmm0,xmm0
  40c3b5:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40c3bd:	mov    DWORD PTR [rbx+0x9b0],0x0
  40c3c7:	mov    DWORD PTR [rbx+0x9a8],0x0
  40c3d1:	mov    edi,0x4
  40c3d6:	mov    r12,rsi
  40c3d9:	lea    rsi,[rsi+0x38]
  40c3dd:	test   rdi,rdi
  40c3e0:	je     40c40c <__swc_fn_ff58629f_000106_5a85fcf5+0x12c>
  40c3e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40c3ec:	nop    DWORD PTR [rax+0x0]
  40c3f0:	mov    rcx,rsi
  40c3f3:	call   40a1b0 <__swc_fn_ff58629f_000162_13ead2ff>
  40c3f8:	add    rsi,0x90
  40c3ff:	add    r12,0x90
  40c406:	sub    rdi,0x1
  40c40a:	jne    40c3f0 <__swc_fn_ff58629f_000106_5a85fcf5+0x110>
  40c40c:	mov    rax,QWORD PTR [rbx+0x938]
  40c413:	mov    rdi,rax
  40c416:	mov    QWORD PTR [rbx+0x938],0x0
  40c421:	test   rdi,rdi
  40c424:	je     40c495 <__swc_fn_ff58629f_000106_5a85fcf5+0x1b5>
  40c42a:	nop    WORD PTR [rax+rax*1+0x0]
  40c430:	mov    esi,0x10
  40c435:	lea    r12,[rdi+0x18]
  40c439:	lea    r13,[rdi+0x50]
  40c43d:	test   rsi,rsi
  40c440:	je     40c46c <__swc_fn_ff58629f_000106_5a85fcf5+0x18c>
  40c442:	cs nop WORD PTR [rax+rax*1+0x0]
  40c44c:	nop    DWORD PTR [rax+0x0]
  40c450:	mov    rcx,r13
  40c453:	call   40a1b0 <__swc_fn_ff58629f_000162_13ead2ff>
  40c458:	add    r13,0x90
  40c45f:	add    r12,0x90
  40c466:	sub    rsi,0x1
  40c46a:	jne    40c450 <__swc_fn_ff58629f_000106_5a85fcf5+0x170>
  40c46c:	mov    rax,QWORD PTR [rdi]
  40c46f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40c474:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c47a:	lea    rcx,[rsp+0x8]
  40c47f:	mov    rdx,rdi
  40c482:	mov    r8d,0x918
  40c488:	mov    rdi,rax
  40c48b:	call   410380 <__swc_fn_ff58629f_000101_d4bdcaa4>
  40c490:	test   rdi,rdi
  40c493:	jne    40c430 <__swc_fn_ff58629f_000106_5a85fcf5+0x150>
  40c495:	lea    rcx,[rbx+0x68]
  40c499:	call   40a1b0 <__swc_fn_ff58629f_000162_13ead2ff>
  40c49e:	add    rsp,0x20
  40c4a2:	pop    r13
  40c4a4:	pop    r12
  40c4a6:	pop    rdi
  40c4a7:	pop    rsi
  40c4a8:	pop    rbx
  40c4a9:	ret
  40c4aa:	add    BYTE PTR [rax],al
  40c4ac:	add    BYTE PTR [rax],al
	...

000000000040c4b0 <__swc_fn_ff58629f_000109_c51c3158>:
  40c4b0:	xor    eax,eax
  40c4b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40c4bc:	nop    DWORD PTR [rax+0x0]
  40c4c0:	mov    r9,r8
  40c4c3:	sub    r9,rax
  40c4c6:	cmp    r9,0x40
  40c4ca:	jb     40c508 <__swc_fn_ff58629f_000109_c51c3158+0x58>
  40c4cc:	lea    r9,[rcx+rax*1]
  40c4d0:	lea    r10,[rdx+rax*1]
  40c4d4:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40c4da:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40c4e0:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40c4e6:	vmovups xmm3,XMMWORD PTR [r10]
  40c4eb:	vmovups XMMWORD PTR [r9],xmm3
  40c4f0:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40c4f6:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40c4fc:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40c502:	lea    rax,[rax+0x40]
  40c506:	jmp    40c4c0 <__swc_fn_ff58629f_000109_c51c3158+0x10>
  40c508:	nop    DWORD PTR [rax+rax*1+0x0]
  40c510:	mov    r9,r8
  40c513:	sub    r9,rax
  40c516:	cmp    r9,0x10
  40c51a:	jb     40c534 <__swc_fn_ff58629f_000109_c51c3158+0x84>
  40c51c:	lea    r9,[rdx+rax*1]
  40c520:	lea    r10,[rcx+rax*1]
  40c524:	vmovups xmm0,XMMWORD PTR [r9]
  40c529:	vmovups XMMWORD PTR [r10],xmm0
  40c52e:	lea    rax,[rax+0x10]
  40c532:	jmp    40c510 <__swc_fn_ff58629f_000109_c51c3158+0x60>
  40c534:	cs nop WORD PTR [rax+rax*1+0x0]
  40c53e:	xchg   ax,ax
  40c540:	mov    r9,r8
  40c543:	sub    r9,rax
  40c546:	cmp    r9,0x8
  40c54a:	jb     40c55d <__swc_fn_ff58629f_000109_c51c3158+0xad>
  40c54c:	lea    r9,[rcx+rax*1]
  40c550:	mov    r10,QWORD PTR [rdx+rax*1]
  40c554:	mov    QWORD PTR [r9],r10
  40c557:	lea    rax,[rax+0x8]
  40c55b:	jmp    40c540 <__swc_fn_ff58629f_000109_c51c3158+0x90>
  40c55d:	cmp    rax,r8
  40c560:	jae    40c580 <__swc_fn_ff58629f_000109_c51c3158+0xd0>
  40c562:	cs nop WORD PTR [rax+rax*1+0x0]
  40c56c:	nop    DWORD PTR [rax+0x0]
  40c570:	mov    r9b,BYTE PTR [rdx+rax*1]
  40c574:	mov    BYTE PTR [rcx+rax*1],r9b
  40c578:	inc    rax
  40c57b:	cmp    rax,r8
  40c57e:	jb     40c570 <__swc_fn_ff58629f_000109_c51c3158+0xc0>
  40c580:	ret
	...

000000000040c590 <__swc_fn_ff58629f_000112_6814119b>:
  40c590:	push   rbx
  40c591:	push   r12
  40c593:	push   rdi
  40c594:	push   rsi
  40c595:	push   r13
  40c597:	push   r14
  40c599:	push   r15
  40c59b:	sub    rsp,0x170
  40c5a2:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40c5ab:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40c5b4:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40c5bd:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40c5c6:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40c5cf:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40c5d8:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40c5e1:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40c5ea:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40c5f3:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40c5fc:	mov    ebx,edx
  40c5fe:	mov    QWORD PTR [rsp+0xa8],rbx
  40c606:	mov    r12d,ecx
  40c609:	test   edx,edx
  40c60b:	jne    40c622 <__swc_fn_ff58629f_000112_6814119b+0x92>
  40c60d:	xor    eax,eax
  40c60f:	add    rsp,0x170
  40c616:	pop    r15
  40c618:	pop    r14
  40c61a:	pop    r13
  40c61c:	pop    rsi
  40c61d:	pop    rdi
  40c61e:	pop    r12
  40c620:	pop    rbx
  40c621:	ret
  40c622:	lea    rdi,[rip+0x5f57]        # 412580 <__swc_rdata_base_ff58629f+0x470>
  40c629:	mov    esi,0x90000
  40c62e:	xor    eax,eax
  40c630:	call   4070a0 <open@plt>
  40c635:	mov    r13,rax
  40c638:	mov    QWORD PTR [rsp+0xb0],rax
  40c640:	test   eax,eax
  40c642:	jge    40c64b <__swc_fn_ff58629f_000112_6814119b+0xbb>
  40c644:	xor    eax,eax
  40c646:	jmp    40cb46 <__swc_fn_ff58629f_000112_6814119b+0x5b6>
  40c64b:	nop    DWORD PTR [rax+rax*1+0x0]
  40c650:	movsxd rdi,r13d
  40c653:	mov    esi,0x2
  40c658:	xor    eax,eax
  40c65a:	call   4070b0 <flock@plt>
  40c65f:	test   eax,eax
  40c661:	je     40c680 <__swc_fn_ff58629f_000112_6814119b+0xf0>
  40c663:	xor    eax,eax
  40c665:	call   4070c0 <__errno_location@plt>
  40c66a:	cmp    DWORD PTR [rax],0x4
  40c66d:	je     40c650 <__swc_fn_ff58629f_000112_6814119b+0xc0>
  40c66f:	movsxd rdi,r13d
  40c672:	xor    eax,eax
  40c674:	call   4070d0 <close@plt>
  40c679:	xor    eax,eax
  40c67b:	jmp    40cb46 <__swc_fn_ff58629f_000112_6814119b+0x5b6>
  40c680:	lea    r14,[rsp+0x8]
  40c685:	mov    QWORD PTR [rsp+0xb8],r14
  40c68d:	vxorps xmm0,xmm0,xmm0
  40c691:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c697:	mov    QWORD PTR [rsp+0x18],0x0
  40c6a0:	mov    WORD PTR [rsp+0x20],0x0
  40c6a7:	mov    DWORD PTR [r14],0x67617753
  40c6ae:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40c6b6:	xor    eax,eax
  40c6b8:	call   4070e0 <getpid@plt>
  40c6bd:	mov    ecx,eax
  40c6bf:	mov    eax,0x1c
  40c6c4:	shrx   eax,ecx,eax
  40c6c9:	and    eax,0xf
  40c6cc:	mov    rdx,QWORD PTR [rip+0x5ecd]        # 4125a0 <__swc_rdata_base_ff58629f+0x490>
  40c6d3:	mov    al,BYTE PTR [rdx+rax*1]
  40c6d6:	rex mov BYTE PTR [rsp+0x10],al
  40c6db:	mov    eax,0x1c
  40c6e0:	shrx   eax,r12d,eax
  40c6e5:	and    eax,0xf
  40c6e8:	mov    al,BYTE PTR [rdx+rax*1]
  40c6eb:	rex mov BYTE PTR [rsp+0x19],al
  40c6f0:	mov    eax,0x18
  40c6f5:	shrx   eax,ecx,eax
  40c6fa:	and    eax,0xf
  40c6fd:	mov    al,BYTE PTR [rdx+rax*1]
  40c700:	rex mov BYTE PTR [rsp+0x11],al
  40c705:	mov    eax,0x18
  40c70a:	shrx   eax,r12d,eax
  40c70f:	and    eax,0xf
  40c712:	mov    al,BYTE PTR [rdx+rax*1]
  40c715:	rex mov BYTE PTR [rsp+0x1a],al
  40c71a:	mov    eax,0x14
  40c71f:	shrx   eax,ecx,eax
  40c724:	and    eax,0xf
  40c727:	mov    al,BYTE PTR [rdx+rax*1]
  40c72a:	rex mov BYTE PTR [rsp+0x12],al
  40c72f:	mov    eax,0x14
  40c734:	shrx   eax,r12d,eax
  40c739:	and    eax,0xf
  40c73c:	mov    al,BYTE PTR [rdx+rax*1]
  40c73f:	rex mov BYTE PTR [rsp+0x1b],al
  40c744:	mov    eax,0x10
  40c749:	shrx   eax,ecx,eax
  40c74e:	and    eax,0xf
  40c751:	mov    al,BYTE PTR [rdx+rax*1]
  40c754:	rex mov BYTE PTR [rsp+0x13],al
  40c759:	mov    eax,0x10
  40c75e:	shrx   eax,r12d,eax
  40c763:	and    eax,0xf
  40c766:	mov    al,BYTE PTR [rdx+rax*1]
  40c769:	rex mov BYTE PTR [rsp+0x1c],al
  40c76e:	mov    eax,0xc
  40c773:	shrx   eax,ecx,eax
  40c778:	and    eax,0xf
  40c77b:	mov    al,BYTE PTR [rdx+rax*1]
  40c77e:	rex mov BYTE PTR [rsp+0x14],al
  40c783:	mov    eax,0xc
  40c788:	shrx   eax,r12d,eax
  40c78d:	and    eax,0xf
  40c790:	mov    al,BYTE PTR [rdx+rax*1]
  40c793:	rex mov BYTE PTR [rsp+0x1d],al
  40c798:	mov    eax,0x8
  40c79d:	shrx   eax,ecx,eax
  40c7a2:	and    eax,0xf
  40c7a5:	mov    al,BYTE PTR [rdx+rax*1]
  40c7a8:	rex mov BYTE PTR [rsp+0x15],al
  40c7ad:	mov    eax,0x8
  40c7b2:	shrx   eax,r12d,eax
  40c7b7:	and    eax,0xf
  40c7ba:	mov    al,BYTE PTR [rdx+rax*1]
  40c7bd:	rex mov BYTE PTR [rsp+0x1e],al
  40c7c2:	mov    eax,0x4
  40c7c7:	shrx   eax,ecx,eax
  40c7cc:	and    eax,0xf
  40c7cf:	mov    al,BYTE PTR [rdx+rax*1]
  40c7d2:	rex mov BYTE PTR [rsp+0x16],al
  40c7d7:	mov    eax,0x4
  40c7dc:	shrx   eax,r12d,eax
  40c7e1:	and    eax,0xf
  40c7e4:	mov    al,BYTE PTR [rdx+rax*1]
  40c7e7:	rex mov BYTE PTR [rsp+0x1f],al
  40c7ec:	xor    eax,eax
  40c7ee:	shrx   eax,ecx,eax
  40c7f3:	and    eax,0xf
  40c7f6:	mov    al,BYTE PTR [rdx+rax*1]
  40c7f9:	rex mov BYTE PTR [rsp+0x17],al
  40c7fe:	xor    eax,eax
  40c800:	shrx   eax,r12d,eax
  40c805:	and    eax,0xf
  40c808:	mov    al,BYTE PTR [rdx+rax*1]
  40c80b:	rex mov BYTE PTR [rsp+0x20],al
  40c810:	mov    BYTE PTR [r14+0x10],0x2e
  40c815:	lea    r12,[rsp+0x22]
  40c81a:	vxorps xmm0,xmm0,xmm0
  40c81e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40c824:	mov    DWORD PTR [r12],0x6d656d2f
  40c82c:	mov    WORD PTR [r12+0x4],0x6466
  40c834:	mov    BYTE PTR [r12+0x6],0x3a
  40c83a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c840:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40c846:	mov    rax,QWORD PTR [rsp+0x18]
  40c84b:	mov    QWORD PTR [rsp+0x39],rax
  40c850:	rex mov al,BYTE PTR [rsp+0x20]
  40c855:	rex mov BYTE PTR [rsp+0x41],al
  40c85a:	mov    DWORD PTR [r12+0x20],0x65642820
  40c863:	mov    DWORD PTR [r12+0x24],0x6574656c
  40c86c:	mov    WORD PTR [r12+0x28],0x2964
  40c874:	lea    rdi,[rip+0x5d10]        # 41258b <__swc_rdata_base_ff58629f+0x47b>
  40c87b:	xor    eax,eax
  40c87d:	call   4070f0 <opendir@plt>
  40c882:	mov    r15,rax
  40c885:	test   rax,rax
  40c888:	jne    40c89b <__swc_fn_ff58629f_000112_6814119b+0x30b>
  40c88a:	movsxd rdi,r13d
  40c88d:	xor    eax,eax
  40c88f:	call   4070d0 <close@plt>
  40c894:	xor    eax,eax
  40c896:	jmp    40cb46 <__swc_fn_ff58629f_000112_6814119b+0x5b6>
  40c89b:	mov    rdi,r15
  40c89e:	xor    eax,eax
  40c8a0:	call   407100 <dirfd@plt>
  40c8a5:	lea    r14,[rsp+0x54]
  40c8aa:	mov    DWORD PTR [rsp+0x54],eax
  40c8ae:	lea    rbx,[rsp+0x58]
  40c8b3:	cs nop WORD PTR [rax+rax*1+0x0]
  40c8bd:	nop    DWORD PTR [rax]
  40c8c0:	mov    rdi,r15
  40c8c3:	xor    eax,eax
  40c8c5:	call   407110 <readdir@plt>
  40c8ca:	test   rax,rax
  40c8cd:	jne    40c8e4 <__swc_fn_ff58629f_000112_6814119b+0x354>
  40c8cf:	mov    r12,QWORD PTR [rsp+0xa8]
  40c8d7:	mov    r13,QWORD PTR [rsp+0xb0]
  40c8df:	jmp    40ca6a <__swc_fn_ff58629f_000112_6814119b+0x4da>
  40c8e4:	vxorps xmm0,xmm0,xmm0
  40c8e8:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  40c8ee:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  40c8f4:	vzeroupper
  40c8f7:	lea    r13,[rax+0x13]
  40c8fb:	mov    rax,r14
  40c8fe:	movsxd rdi,DWORD PTR [rax]
  40c901:	mov    rsi,r13
  40c904:	mov    rdx,rbx
  40c907:	mov    ecx,0x40
  40c90c:	xor    eax,eax
  40c90e:	call   407120 <readlinkat@plt>
  40c913:	cmp    rax,0x2a
  40c917:	jne    40c8c0 <__swc_fn_ff58629f_000112_6814119b+0x330>
  40c919:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40c91f:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40c925:	vptest xmm0,xmm0
  40c92a:	jne    40c95a <__swc_fn_ff58629f_000112_6814119b+0x3ca>
  40c92c:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40c932:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40c938:	vptest xmm0,xmm0
  40c93d:	jne    40c95a <__swc_fn_ff58629f_000112_6814119b+0x3ca>
  40c93f:	mov    rcx,QWORD PTR [rsp+0x42]
  40c944:	cmp    QWORD PTR [rsp+0x78],rcx
  40c949:	jne    40c95a <__swc_fn_ff58629f_000112_6814119b+0x3ca>
  40c94b:	mov    cx,WORD PTR [rsp+0x4a]
  40c950:	cmp    WORD PTR [rsp+0x80],cx
  40c958:	je     40c984 <__swc_fn_ff58629f_000112_6814119b+0x3f4>
  40c95a:	mov    rax,rbx
  40c95d:	mov    rcx,r12
  40c960:	movzx  edx,BYTE PTR [rax]
  40c963:	movzx  r8d,BYTE PTR [rcx]
  40c967:	cmp    rdx,r8
  40c96a:	jne    40c976 <__swc_fn_ff58629f_000112_6814119b+0x3e6>
  40c96c:	add    rax,0x1
  40c970:	add    rcx,0x1
  40c974:	jmp    40c960 <__swc_fn_ff58629f_000112_6814119b+0x3d0>
  40c976:	mov    rax,rdx
  40c979:	sub    rax,r8
  40c97c:	test   eax,eax
  40c97e:	jne    40c8c0 <__swc_fn_ff58629f_000112_6814119b+0x330>
  40c984:	movsxd rdi,DWORD PTR [r14]
  40c987:	mov    rsi,r13
  40c98a:	mov    edx,0x80002
  40c98f:	xor    eax,eax
  40c991:	call   407130 <openat@plt>
  40c996:	lea    rbx,[rsp+0x98]
  40c99e:	mov    DWORD PTR [rsp+0x98],eax
  40c9a5:	test   eax,eax
  40c9a7:	mov    r13,QWORD PTR [rsp+0xb0]
  40c9af:	jge    40c9d4 <__swc_fn_ff58629f_000112_6814119b+0x444>
  40c9b1:	mov    rdi,r15
  40c9b4:	xor    eax,eax
  40c9b6:	call   407140 <closedir@plt>
  40c9bb:	mov    r13,QWORD PTR [rsp+0xb0]
  40c9c3:	movsxd rdi,r13d
  40c9c6:	xor    eax,eax
  40c9c8:	call   4070d0 <close@plt>
  40c9cd:	xor    eax,eax
  40c9cf:	jmp    40cb46 <__swc_fn_ff58629f_000112_6814119b+0x5b6>
  40c9d4:	mov    rax,rbx
  40c9d7:	movsxd rdi,DWORD PTR [rax]
  40c9da:	xor    esi,esi
  40c9dc:	mov    edx,0x2
  40c9e1:	xor    eax,eax
  40c9e3:	call   407150 <lseek@plt>
  40c9e8:	mov    r12,QWORD PTR [rsp+0xa8]
  40c9f0:	cmp    rax,r12
  40c9f3:	je     40ca1a <__swc_fn_ff58629f_000112_6814119b+0x48a>
  40c9f5:	movsxd rdi,DWORD PTR [rbx]
  40c9f8:	xor    eax,eax
  40c9fa:	call   4070d0 <close@plt>
  40c9ff:	mov    rdi,r15
  40ca02:	xor    eax,eax
  40ca04:	call   407140 <closedir@plt>
  40ca09:	movsxd rdi,r13d
  40ca0c:	xor    eax,eax
  40ca0e:	call   4070d0 <close@plt>
  40ca13:	xor    eax,eax
  40ca15:	jmp    40cb46 <__swc_fn_ff58629f_000112_6814119b+0x5b6>
  40ca1a:	xor    edi,edi
  40ca1c:	mov    rsi,r12
  40ca1f:	mov    edx,0x3
  40ca24:	mov    ecx,0x1
  40ca29:	mov    rax,rbx
  40ca2c:	movsxd r8,DWORD PTR [rax]
  40ca2f:	xor    r9d,r9d
  40ca32:	xor    eax,eax
  40ca34:	call   407010 <mmap@plt>
  40ca39:	xor    r12d,r12d
  40ca3c:	cmp    rax,0xffffffffffffffff
  40ca40:	cmovne r12,rax
  40ca44:	movsxd rdi,DWORD PTR [rbx]
  40ca47:	xor    eax,eax
  40ca49:	call   4070d0 <close@plt>
  40ca4e:	mov    rdi,r15
  40ca51:	xor    eax,eax
  40ca53:	call   407140 <closedir@plt>
  40ca58:	movsxd rdi,r13d
  40ca5b:	xor    eax,eax
  40ca5d:	call   4070d0 <close@plt>
  40ca62:	mov    rax,r12
  40ca65:	jmp    40cb46 <__swc_fn_ff58629f_000112_6814119b+0x5b6>
  40ca6a:	mov    r14,QWORD PTR [rsp+0xb8]
  40ca72:	mov    rdi,r14
  40ca75:	mov    esi,0x1
  40ca7a:	xor    eax,eax
  40ca7c:	call   407160 <memfd_create@plt>
  40ca81:	lea    rbx,[rsp+0x9c]
  40ca89:	mov    DWORD PTR [rsp+0x9c],eax
  40ca90:	test   eax,eax
  40ca92:	jge    40caaf <__swc_fn_ff58629f_000112_6814119b+0x51f>
  40ca94:	mov    rdi,r15
  40ca97:	xor    eax,eax
  40ca99:	call   407140 <closedir@plt>
  40ca9e:	movsxd rdi,r13d
  40caa1:	xor    eax,eax
  40caa3:	call   4070d0 <close@plt>
  40caa8:	xor    eax,eax
  40caaa:	jmp    40cb46 <__swc_fn_ff58629f_000112_6814119b+0x5b6>
  40caaf:	mov    rax,rbx
  40cab2:	movsxd rdi,DWORD PTR [rax]
  40cab5:	mov    rsi,r12
  40cab8:	xor    eax,eax
  40caba:	call   407170 <ftruncate@plt>
  40cabf:	test   eax,eax
  40cac1:	je     40cae5 <__swc_fn_ff58629f_000112_6814119b+0x555>
  40cac3:	movsxd rdi,DWORD PTR [rbx]
  40cac6:	xor    eax,eax
  40cac8:	call   4070d0 <close@plt>
  40cacd:	mov    rdi,r15
  40cad0:	xor    eax,eax
  40cad2:	call   407140 <closedir@plt>
  40cad7:	movsxd rdi,r13d
  40cada:	xor    eax,eax
  40cadc:	call   4070d0 <close@plt>
  40cae1:	xor    eax,eax
  40cae3:	jmp    40cb46 <__swc_fn_ff58629f_000112_6814119b+0x5b6>
  40cae5:	xor    edi,edi
  40cae7:	mov    rsi,r12
  40caea:	mov    edx,0x3
  40caef:	mov    ecx,0x1
  40caf4:	mov    rax,rbx
  40caf7:	movsxd r8,DWORD PTR [rax]
  40cafa:	xor    r9d,r9d
  40cafd:	xor    eax,eax
  40caff:	call   407010 <mmap@plt>
  40cb04:	mov    r12,rax
  40cb07:	cmp    rax,0xffffffffffffffff
  40cb0b:	jne    40cb2f <__swc_fn_ff58629f_000112_6814119b+0x59f>
  40cb0d:	movsxd rdi,DWORD PTR [rbx]
  40cb10:	xor    eax,eax
  40cb12:	call   4070d0 <close@plt>
  40cb17:	mov    rdi,r15
  40cb1a:	xor    eax,eax
  40cb1c:	call   407140 <closedir@plt>
  40cb21:	movsxd rdi,r13d
  40cb24:	xor    eax,eax
  40cb26:	call   4070d0 <close@plt>
  40cb2b:	xor    eax,eax
  40cb2d:	jmp    40cb46 <__swc_fn_ff58629f_000112_6814119b+0x5b6>
  40cb2f:	mov    rdi,r15
  40cb32:	xor    eax,eax
  40cb34:	call   407140 <closedir@plt>
  40cb39:	movsxd rdi,r13d
  40cb3c:	xor    eax,eax
  40cb3e:	call   4070d0 <close@plt>
  40cb43:	mov    rax,r12
  40cb46:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40cb4f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40cb58:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40cb61:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40cb6a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  40cb73:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40cb7c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  40cb85:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40cb8e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  40cb97:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  40cba0:	add    rsp,0x170
  40cba7:	pop    r15
  40cba9:	pop    r14
  40cbab:	pop    r13
  40cbad:	pop    rsi
  40cbae:	pop    rdi
  40cbaf:	pop    r12
  40cbb1:	pop    rbx
  40cbb2:	ret
	...

000000000040cbc0 <__swc_fn_ff58629f_000115_5f48311c>:
  40cbc0:	push   rsi
  40cbc1:	push   rdi
  40cbc2:	push   r12
  40cbc4:	push   r13
  40cbc6:	sub    rsp,0x8
  40cbca:	mov    rsi,r8
  40cbcd:	mov    rdi,rcx
  40cbd0:	mov    r12,rdx
  40cbd3:	call   410b20 <__swc_fn_ff58629f_000113_126150d1>
  40cbd8:	mov    r13,rax
  40cbdb:	test   rax,rax
  40cbde:	jne    40cbeb <__swc_fn_ff58629f_000115_5f48311c+0x2b>
  40cbe0:	add    rsp,0x8
  40cbe4:	pop    r13
  40cbe6:	pop    r12
  40cbe8:	pop    rdi
  40cbe9:	pop    rsi
  40cbea:	ret
  40cbeb:	mov    rcx,r13
  40cbee:	call   409db0 <__swc_fn_ff58629f_000138_8c07c14b>
  40cbf3:	mov    rax,QWORD PTR [r13+0x8]
  40cbf7:	test   rax,rax
  40cbfa:	je     40cc39 <__swc_fn_ff58629f_000115_5f48311c+0x79>
  40cbfc:	nop    DWORD PTR [rax+0x0]
  40cc00:	lea    rcx,[rax+0x1000]
  40cc07:	cmp    rdi,rcx
  40cc0a:	jne    40cc31 <__swc_fn_ff58629f_000115_5f48311c+0x71>
  40cc0c:	cmp    r12,0x1000
  40cc13:	jb     40cc31 <__swc_fn_ff58629f_000115_5f48311c+0x71>
  40cc15:	test   sil,sil
  40cc18:	setne  cl
  40cc1b:	mov    BYTE PTR [rax+0x10],cl
  40cc1e:	mov    rcx,r13
  40cc21:	call   40d120 <__swc_fn_ff58629f_000139_715e84ff>
  40cc26:	add    rsp,0x8
  40cc2a:	pop    r13
  40cc2c:	pop    r12
  40cc2e:	pop    rdi
  40cc2f:	pop    rsi
  40cc30:	ret
  40cc31:	mov    rax,QWORD PTR [rax]
  40cc34:	test   rax,rax
  40cc37:	jne    40cc00 <__swc_fn_ff58629f_000115_5f48311c+0x40>
  40cc39:	mov    rcx,r13
  40cc3c:	call   40d120 <__swc_fn_ff58629f_000139_715e84ff>
  40cc41:	add    rsp,0x8
  40cc45:	pop    r13
  40cc47:	pop    r12
  40cc49:	pop    rdi
  40cc4a:	pop    rsi
  40cc4b:	ret
  40cc4c:	add    BYTE PTR [rax],al
	...

000000000040cc50 <__swc_fn_ff58629f_000118_ed2d8fed>:
  40cc50:	sub    rsp,0x8
  40cc54:	test   rcx,rcx
  40cc57:	jne    40cc5e <__swc_fn_ff58629f_000118_ed2d8fed+0xe>
  40cc59:	add    rsp,0x8
  40cc5d:	ret
  40cc5e:	call   4098c0 <__swc_fn_ff58629f_000120_d3318640>
  40cc63:	add    rsp,0x8
  40cc67:	ret
	...

000000000040cc70 <__swc_fn_ff58629f_000121_2648f149>:
  40cc70:	push   r12
  40cc72:	push   r13
  40cc74:	push   r14
  40cc76:	push   rdi
  40cc77:	push   rsi
  40cc78:	sub    rsp,0xc0
  40cc7f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40cc85:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40cc8b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40cc91:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40cc97:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40cc9d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40cca3:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40cca9:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40ccb2:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40ccbb:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40ccc4:	mov    r12,QWORD PTR [rcx]
  40ccc7:	test   r12,r12
  40ccca:	jne    40ccdc <__swc_fn_ff58629f_000121_2648f149+0x6c>
  40cccc:	add    rsp,0xc0
  40ccd3:	pop    rsi
  40ccd4:	pop    rdi
  40ccd5:	pop    r14
  40ccd7:	pop    r13
  40ccd9:	pop    r12
  40ccdb:	ret
  40ccdc:	xor    r13d,r13d
  40ccdf:	mov    r14,QWORD PTR [rcx+0x8]
  40cce3:	cs nop WORD PTR [rax+rax*1+0x0]
  40cced:	nop    DWORD PTR [rax]
  40ccf0:	cmp    r13,r14
  40ccf3:	jae    40cd2b <__swc_fn_ff58629f_000121_2648f149+0xbb>
  40ccf5:	lea    rax,[r12+r13*1]
  40ccf9:	mov    rcx,r14
  40ccfc:	sub    rcx,r13
  40ccff:	mov    edi,0x1
  40cd04:	mov    rsi,rax
  40cd07:	mov    rdx,rcx
  40cd0a:	xor    eax,eax
  40cd0c:	call   407180 <write@plt>
  40cd11:	test   rax,rax
  40cd14:	jle    40cd1b <__swc_fn_ff58629f_000121_2648f149+0xab>
  40cd16:	add    r13,rax
  40cd19:	jmp    40ccf0 <__swc_fn_ff58629f_000121_2648f149+0x80>
  40cd1b:	je     40cd29 <__swc_fn_ff58629f_000121_2648f149+0xb9>
  40cd1d:	xor    eax,eax
  40cd1f:	call   4070c0 <__errno_location@plt>
  40cd24:	cmp    DWORD PTR [rax],0x4
  40cd27:	je     40ccf0 <__swc_fn_ff58629f_000121_2648f149+0x80>
  40cd29:	jmp    40cd2b <__swc_fn_ff58629f_000121_2648f149+0xbb>
  40cd2b:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40cd31:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40cd37:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40cd3d:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40cd43:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40cd49:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40cd4f:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40cd55:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40cd5e:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40cd67:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40cd70:	add    rsp,0xc0
  40cd77:	pop    rsi
  40cd78:	pop    rdi
  40cd79:	pop    r14
  40cd7b:	pop    r13
  40cd7d:	pop    r12
  40cd7f:	ret

000000000040cd80 <__swc_fn_ff58629f_000124_4f256d58>:
  40cd80:	push   rbx
  40cd81:	push   r12
  40cd83:	push   rdi
  40cd84:	push   rsi
  40cd85:	sub    rsp,0x4a8
  40cd8c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  40cd95:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  40cd9e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  40cda7:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  40cdb0:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  40cdb9:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  40cdc2:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  40cdcb:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  40cdd4:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  40cddd:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  40cde6:	mov    rbx,rdx
  40cde9:	mov    r12d,ecx
  40cdec:	vxorps xmm0,xmm0,xmm0
  40cdf0:	xor    eax,eax
  40cdf2:	cs nop WORD PTR [rax+rax*1+0x0]
  40cdfc:	nop    DWORD PTR [rax+0x0]
  40ce00:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  40ce06:	add    rax,0x10
  40ce0a:	cmp    rax,0x400
  40ce11:	jne    40ce00 <__swc_fn_ff58629f_000124_4f256d58+0x80>
  40ce13:	lea    rdi,[rsp+0x8]
  40ce18:	mov    esi,0x80
  40ce1d:	xor    eax,eax
  40ce1f:	call   407190 <backtrace@plt>
  40ce24:	test   eax,eax
  40ce26:	jle    40ce35 <__swc_fn_ff58629f_000124_4f256d58+0xb5>
  40ce28:	movsxd rax,eax
  40ce2b:	lea    rcx,[r12+0x1]
  40ce30:	cmp    rcx,rax
  40ce33:	jb     40ce39 <__swc_fn_ff58629f_000124_4f256d58+0xb9>
  40ce35:	xor    eax,eax
  40ce37:	jmp    40ce6a <__swc_fn_ff58629f_000124_4f256d58+0xea>
  40ce39:	mov    rcx,QWORD PTR [rbx+0x8]
  40ce3d:	sub    rax,r12
  40ce40:	lea    rsi,[rax-0x1]
  40ce44:	cmp    rcx,rsi
  40ce47:	cmovbe rsi,rcx
  40ce4b:	lea    eax,[r12+0x1]
  40ce50:	lea    rax,[rsp+rax*8+0x8]
  40ce55:	mov    rcx,QWORD PTR [rbx]
  40ce58:	mov    rdx,rax
  40ce5b:	lea    r8,[rsi*8+0x0]
  40ce63:	call   410b00 <__swc_fn_ff58629f_000110_7c204aac>
  40ce68:	mov    eax,esi
  40ce6a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  40ce73:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  40ce7c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  40ce85:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  40ce8e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  40ce97:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  40cea0:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  40cea9:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  40ceb2:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  40cebb:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  40cec4:	add    rsp,0x4a8
  40cecb:	pop    rsi
  40cecc:	pop    rdi
  40cecd:	pop    r12
  40cecf:	pop    rbx
  40ced0:	ret
	...

000000000040cee0 <__swc_fn_ff58629f_000127_fcd5a289>:
  40cee0:	mov    QWORD PTR [rcx],0x0
  40cee7:	ret
	...

000000000040cef0 <__swc_fn_ff58629f_000130_4bbe3f14>:
  40cef0:	push   rdi
  40cef1:	push   rsi
  40cef2:	sub    rsp,0xa8
  40cef9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ceff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cf05:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cf0b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cf11:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cf17:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cf1d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cf23:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cf29:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cf32:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cf3b:	mov    edi,ecx
  40cf3d:	mov    rsi,rdx
  40cf40:	xor    eax,eax
  40cf42:	call   4071a0 <pthread_setspecific@plt>
  40cf47:	test   eax,eax
  40cf49:	sete   al
  40cf4c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cf52:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cf58:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cf5e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cf64:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cf6a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cf70:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cf76:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cf7c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cf85:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cf8e:	add    rsp,0xa8
  40cf95:	pop    rsi
  40cf96:	pop    rdi
  40cf97:	ret
	...

000000000040cfa0 <__swc_fn_ff58629f_000133_5f757033>:
  40cfa0:	push   rdi
  40cfa1:	push   rsi
  40cfa2:	sub    rsp,0xa8
  40cfa9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cfaf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cfb5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cfbb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cfc1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cfc7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cfcd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cfd3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cfd9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cfe2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cfeb:	test   rcx,rcx
  40cfee:	je     40d001 <__swc_fn_ff58629f_000133_5f757033+0x61>
  40cff0:	lea    rax,[rcx-0x1]
  40cff4:	mov    eax,eax
  40cff6:	mov    edi,eax
  40cff8:	xor    eax,eax
  40cffa:	call   407000 <pthread_getspecific@plt>
  40cfff:	jmp    40d003 <__swc_fn_ff58629f_000133_5f757033+0x63>
  40d001:	xor    eax,eax
  40d003:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d009:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d00f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d015:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d01b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d021:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d027:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d02d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d033:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d03c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d045:	add    rsp,0xa8
  40d04c:	pop    rsi
  40d04d:	pop    rdi
  40d04e:	ret
	...

000000000040d050 <__swc_fn_ff58629f_000136_07d76562>:
  40d050:	push   rdi
  40d051:	push   rsi
  40d052:	sub    rsp,0xb8
  40d059:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40d05f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40d065:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40d06b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40d071:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40d077:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40d07d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40d083:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40d08c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40d095:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40d09e:	vxorps xmm0,xmm0,xmm0
  40d0a2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40d0a8:	mov    edi,0x1
  40d0ad:	lea    rsi,[rsp+0x8]
  40d0b2:	xor    eax,eax
  40d0b4:	call   4071b0 <clock_gettime@plt>
  40d0b9:	mov    rax,QWORD PTR [rsp+0x8]
  40d0be:	imul   rax,rax,0x3b9aca00
  40d0c5:	add    rax,QWORD PTR [rsp+0x10]
  40d0ca:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40d0d0:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40d0d6:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40d0dc:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40d0e2:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40d0e8:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40d0ee:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40d0f4:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40d0fd:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40d106:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40d10f:	add    rsp,0xb8
  40d116:	pop    rsi
  40d117:	pop    rdi
  40d118:	ret
  40d119:	add    BYTE PTR [rax],al
  40d11b:	add    BYTE PTR [rax],al
  40d11d:	add    BYTE PTR [rax],al
	...

000000000040d120 <__swc_fn_ff58629f_000139_715e84ff>:
  40d120:	sub    rsp,0x8
  40d124:	xor    eax,eax
  40d126:	mov    DWORD PTR [rcx],eax
  40d128:	mov    edx,0x7fffffff
  40d12d:	call   411200 <__swc_fn_ff58629f_000137_865f5106>
  40d132:	add    rsp,0x8
  40d136:	ret
	...

000000000040d140 <__swc_fn_ff58629f_000142_519fdf94>:
  40d140:	push   rdi
  40d141:	push   rsi
  40d142:	sub    rsp,0xb8
  40d149:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40d14f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40d155:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40d15b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40d161:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40d167:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40d16d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40d173:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40d17c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40d185:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40d18e:	mov    edi,0x1
  40d193:	xor    eax,eax
  40d195:	call   4071c0 <__x86_get_cpuid_feature_leaf@plt>
  40d19a:	mov    eax,DWORD PTR [rax+0x14]
  40d19d:	and    eax,0x20
  40d1a0:	setne  al
  40d1a3:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40d1a9:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40d1af:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40d1b5:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40d1bb:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40d1c1:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40d1c7:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40d1cd:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40d1d6:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40d1df:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40d1e8:	add    rsp,0xb8
  40d1ef:	pop    rsi
  40d1f0:	pop    rdi
  40d1f1:	ret
	...

000000000040d200 <__swc_fn_ff58629f_000145_d5d4d43f>:
  40d200:	push   rsi
  40d201:	push   rdi
  40d202:	push   r12
  40d204:	push   r13
  40d206:	push   r14
  40d208:	push   r15
  40d20a:	cmp    rdx,0x40
  40d20e:	jae    40d21d <__swc_fn_ff58629f_000145_d5d4d43f+0x1d>
  40d210:	xor    eax,eax
  40d212:	pop    r15
  40d214:	pop    r14
  40d216:	pop    r13
  40d218:	pop    r12
  40d21a:	pop    rdi
  40d21b:	pop    rsi
  40d21c:	ret
  40d21d:	cmp    BYTE PTR [rcx],0x7f
  40d220:	jne    40d264 <__swc_fn_ff58629f_000145_d5d4d43f+0x64>
  40d222:	movzx  eax,BYTE PTR [rcx+0x1]
  40d226:	cmp    eax,0x45
  40d229:	setne  al
  40d22c:	jne    40d260 <__swc_fn_ff58629f_000145_d5d4d43f+0x60>
  40d22e:	movzx  eax,BYTE PTR [rcx+0x2]
  40d232:	cmp    eax,0x4c
  40d235:	setne  al
  40d238:	jne    40d260 <__swc_fn_ff58629f_000145_d5d4d43f+0x60>
  40d23a:	movzx  eax,BYTE PTR [rcx+0x3]
  40d23e:	cmp    eax,0x46
  40d241:	setne  al
  40d244:	jne    40d260 <__swc_fn_ff58629f_000145_d5d4d43f+0x60>
  40d246:	cmp    BYTE PTR [rcx+0x4],0x2
  40d24a:	setne  al
  40d24d:	jne    40d260 <__swc_fn_ff58629f_000145_d5d4d43f+0x60>
  40d24f:	cmp    BYTE PTR [rcx+0x5],0x1
  40d253:	setne  al
  40d256:	jne    40d260 <__swc_fn_ff58629f_000145_d5d4d43f+0x60>
  40d258:	cmp    WORD PTR [rcx+0x12],0x3e
  40d25d:	setne  al
  40d260:	test   al,al
  40d262:	je     40d271 <__swc_fn_ff58629f_000145_d5d4d43f+0x71>
  40d264:	xor    eax,eax
  40d266:	pop    r15
  40d268:	pop    r14
  40d26a:	pop    r13
  40d26c:	pop    r12
  40d26e:	pop    rdi
  40d26f:	pop    rsi
  40d270:	ret
  40d271:	cmp    WORD PTR [rcx+0x3a],0x40
  40d276:	jne    40d291 <__swc_fn_ff58629f_000145_d5d4d43f+0x91>
  40d278:	cmp    WORD PTR [rcx+0x3c],0x0
  40d27d:	sete   al
  40d280:	je     40d28d <__swc_fn_ff58629f_000145_d5d4d43f+0x8d>
  40d282:	mov    ax,WORD PTR [rcx+0x3c]
  40d286:	cmp    WORD PTR [rcx+0x3e],ax
  40d28a:	setae  al
  40d28d:	test   al,al
  40d28f:	je     40d29e <__swc_fn_ff58629f_000145_d5d4d43f+0x9e>
  40d291:	xor    eax,eax
  40d293:	pop    r15
  40d295:	pop    r14
  40d297:	pop    r13
  40d299:	pop    r12
  40d29b:	pop    rdi
  40d29c:	pop    rsi
  40d29d:	ret
  40d29e:	movzx  eax,WORD PTR [rcx+0x3c]
  40d2a2:	shl    rax,0x6
  40d2a6:	cmp    rax,rdx
  40d2a9:	ja     40d2b7 <__swc_fn_ff58629f_000145_d5d4d43f+0xb7>
  40d2ab:	mov    r9,rdx
  40d2ae:	sub    r9,rax
  40d2b1:	cmp    QWORD PTR [rcx+0x28],r9
  40d2b5:	jbe    40d2c4 <__swc_fn_ff58629f_000145_d5d4d43f+0xc4>
  40d2b7:	xor    eax,eax
  40d2b9:	pop    r15
  40d2bb:	pop    r14
  40d2bd:	pop    r13
  40d2bf:	pop    r12
  40d2c1:	pop    rdi
  40d2c2:	pop    rsi
  40d2c3:	ret
  40d2c4:	mov    rax,QWORD PTR [rcx+0x28]
  40d2c8:	add    rax,rcx
  40d2cb:	movzx  r9d,WORD PTR [rcx+0x3e]
  40d2d0:	lea    r9,[r9*8+0x0]
  40d2d8:	lea    r10,[rax+r9*8]
  40d2dc:	cmp    QWORD PTR [r10+0x20],rdx
  40d2e0:	ja     40d302 <__swc_fn_ff58629f_000145_d5d4d43f+0x102>
  40d2e2:	mov    r11,rdx
  40d2e5:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  40d2ea:	cmp    QWORD PTR [r10+0x18],r11
  40d2ee:	seta   r9b
  40d2f2:	ja     40d2fd <__swc_fn_ff58629f_000145_d5d4d43f+0xfd>
  40d2f4:	cmp    QWORD PTR [r10+0x20],0x9
  40d2f9:	setb   r9b
  40d2fd:	test   r9b,r9b
  40d300:	je     40d30f <__swc_fn_ff58629f_000145_d5d4d43f+0x10f>
  40d302:	xor    eax,eax
  40d304:	pop    r15
  40d306:	pop    r14
  40d308:	pop    r13
  40d30a:	pop    r12
  40d30c:	pop    rdi
  40d30d:	pop    rsi
  40d30e:	ret
  40d30f:	movzx  r9d,WORD PTR [rcx+0x3c]
  40d314:	xor    r11d,r11d
  40d317:	test   r9,r9
  40d31a:	jbe    40d415 <__swc_fn_ff58629f_000145_d5d4d43f+0x215>
  40d320:	mov    rsi,QWORD PTR [r10+0x20]
  40d324:	sub    rsi,0x9
  40d328:	cs nop WORD PTR [rax+rax*1+0x0]
  40d332:	cs nop WORD PTR [rax+rax*1+0x0]
  40d33c:	nop    DWORD PTR [rax+0x0]
  40d340:	movzx  edi,r11w
  40d344:	lea    rdi,[rdi*8+0x0]
  40d34c:	lea    r12,[rax+rdi*8]
  40d350:	rex mov edi,DWORD PTR [rax+rdi*8]
  40d354:	cmp    rdi,rsi
  40d357:	ja     40d408 <__swc_fn_ff58629f_000145_d5d4d43f+0x208>
  40d35d:	mov    r13,QWORD PTR [r10+0x18]
  40d361:	add    r13,rdi
  40d364:	lea    rdi,[rcx+r13*1]
  40d368:	lea    r13,[rip+0x5291]        # 412600 <__swc_rdata_base_ff58629f+0x4f0>
  40d36f:	movabs r14,0x676264676177732e
  40d379:	cmp    QWORD PTR [rdi],r14
  40d37c:	jne    40d385 <__swc_fn_ff58629f_000145_d5d4d43f+0x185>
  40d37e:	rex cmp BYTE PTR [rdi+0x8],0x0
  40d383:	je     40d3b2 <__swc_fn_ff58629f_000145_d5d4d43f+0x1b2>
  40d385:	cs nop WORD PTR [rax+rax*1+0x0]
  40d38f:	nop
  40d390:	movzx  r14d,BYTE PTR [rdi]
  40d394:	movzx  r15d,BYTE PTR [r13+0x0]
  40d399:	cmp    r14,r15
  40d39c:	jne    40d3a8 <__swc_fn_ff58629f_000145_d5d4d43f+0x1a8>
  40d39e:	add    rdi,0x1
  40d3a2:	add    r13,0x1
  40d3a6:	jmp    40d390 <__swc_fn_ff58629f_000145_d5d4d43f+0x190>
  40d3a8:	mov    rdi,r14
  40d3ab:	sub    rdi,r15
  40d3ae:	test   edi,edi
  40d3b0:	jne    40d408 <__swc_fn_ff58629f_000145_d5d4d43f+0x208>
  40d3b2:	cmp    DWORD PTR [r12+0x4],0x1
  40d3b8:	jne    40d3e0 <__swc_fn_ff58629f_000145_d5d4d43f+0x1e0>
  40d3ba:	cmp    QWORD PTR [r12+0x20],0x10
  40d3c0:	setb   al
  40d3c3:	jb     40d3dc <__swc_fn_ff58629f_000145_d5d4d43f+0x1dc>
  40d3c5:	cmp    QWORD PTR [r12+0x20],rdx
  40d3ca:	seta   al
  40d3cd:	ja     40d3dc <__swc_fn_ff58629f_000145_d5d4d43f+0x1dc>
  40d3cf:	sub    rdx,QWORD PTR [r12+0x20]
  40d3d4:	cmp    QWORD PTR [r12+0x18],rdx
  40d3d9:	seta   al
  40d3dc:	test   al,al
  40d3de:	je     40d3ed <__swc_fn_ff58629f_000145_d5d4d43f+0x1ed>
  40d3e0:	xor    eax,eax
  40d3e2:	pop    r15
  40d3e4:	pop    r14
  40d3e6:	pop    r13
  40d3e8:	pop    r12
  40d3ea:	pop    rdi
  40d3eb:	pop    rsi
  40d3ec:	ret
  40d3ed:	mov    rax,QWORD PTR [r12+0x20]
  40d3f2:	mov    QWORD PTR [r8],rax
  40d3f5:	mov    rax,QWORD PTR [r12+0x18]
  40d3fa:	add    rax,rcx
  40d3fd:	pop    r15
  40d3ff:	pop    r14
  40d401:	pop    r13
  40d403:	pop    r12
  40d405:	pop    rdi
  40d406:	pop    rsi
  40d407:	ret
  40d408:	add    r11,0x1
  40d40c:	cmp    r11,r9
  40d40f:	jb     40d340 <__swc_fn_ff58629f_000145_d5d4d43f+0x140>
  40d415:	xor    eax,eax
  40d417:	pop    r15
  40d419:	pop    r14
  40d41b:	pop    r13
  40d41d:	pop    r12
  40d41f:	pop    rdi
  40d420:	pop    rsi
  40d421:	ret
	...

000000000040d430 <__swc_fn_ff58629f_000148_d7edc04f>:
  40d430:	push   rdi
  40d431:	push   rsi
  40d432:	sub    rsp,0xa8
  40d439:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d43f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d445:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d44b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d451:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d457:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d45d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d463:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d469:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d472:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d47b:	mov    rdi,rcx
  40d47e:	xor    eax,eax
  40d480:	call   4071d0 <free@plt>
  40d485:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d48b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d491:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d497:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d49d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d4a3:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d4a9:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d4af:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d4b5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d4be:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d4c7:	add    rsp,0xa8
  40d4ce:	pop    rsi
  40d4cf:	pop    rdi
  40d4d0:	ret
	...

000000000040d4e0 <__swc_fn_ff58629f_000151_6203dca2>:
  40d4e0:	push   rbx
  40d4e1:	push   rsi
  40d4e2:	push   rdi
  40d4e3:	push   r12
  40d4e5:	push   r13
  40d4e7:	push   r15
  40d4e9:	sub    rsp,0x4e8
  40d4f0:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  40d4f9:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  40d502:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  40d50b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  40d514:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  40d51d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  40d526:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  40d52f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  40d538:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  40d541:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  40d54a:	mov    rbx,QWORD PTR [rcx]
  40d54d:	mov    rcx,QWORD PTR [rcx+0x8]
  40d551:	mov    rsi,rcx
  40d554:	xor    edi,edi
  40d556:	vmovsd xmm6,QWORD PTR [rip+0x5102]        # 412660 <__swc_rdata_base_ff58629f+0x550>
  40d55e:	vmovsd xmm7,QWORD PTR [rip+0x5103]        # 412669 <__swc_rdata_base_ff58629f+0x559>
  40d566:	vmovsd xmm8,QWORD PTR [rip+0x5104]        # 412672 <__swc_rdata_base_ff58629f+0x562>
  40d56e:	vmovsd xmm9,QWORD PTR [rip+0x5105]        # 41267b <__swc_rdata_base_ff58629f+0x56b>
  40d576:	vmovsd xmm10,QWORD PTR [rip+0x5106]        # 412684 <__swc_rdata_base_ff58629f+0x574>
  40d57e:	vmovups xmm11,xmm6
  40d582:	vmovsd QWORD PTR [rsp+0x418],xmm7
  40d58b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  40d594:	vmovsd QWORD PTR [rsp+0x428],xmm9
  40d59d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  40d5a6:	vmovsd xmm15,QWORD PTR [rip+0x50df]        # 41268d <__swc_rdata_base_ff58629f+0x57d>
  40d5ae:	vmovups xmm14,xmm15
  40d5b3:	vmovups xmm0,xmm9
  40d5b8:	vmovsd QWORD PTR [rsp+0x438],xmm15
  40d5c1:	vmovups xmm13,xmm8
  40d5c6:	vmovsd QWORD PTR [rsp+0x440],xmm15
  40d5cf:	test   rsi,rsi
  40d5d2:	je     40e5c3 <__swc_fn_ff58629f_000151_6203dca2+0x10e3>
  40d5d8:	cs nop WORD PTR [rax+rax*1+0x0]
  40d5e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40d5ec:	nop    DWORD PTR [rax+0x0]
  40d5f0:	lea    rcx,[rdi+rdi*1]
  40d5f4:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  40d5f9:	vpshufd xmm3,xmm2,0xee
  40d5fe:	vmovq  rcx,xmm3
  40d603:	test   rcx,rcx
  40d606:	je     40d61c <__swc_fn_ff58629f_000151_6203dca2+0x13c>
  40d608:	test   DWORD PTR [rcx+0x28],0x400000
  40d60f:	je     40d61c <__swc_fn_ff58629f_000151_6203dca2+0x13c>
  40d611:	mov    rdx,QWORD PTR [rcx+0x30]
  40d615:	test   rdx,rdx
  40d618:	cmovne rcx,rdx
  40d61c:	test   DWORD PTR [rcx+0x28],0x1000
  40d623:	je     40d644 <__swc_fn_ff58629f_000151_6203dca2+0x164>
  40d625:	mov    rdx,QWORD PTR [rcx+0x40]
  40d629:	mov    rcx,rdx
  40d62c:	vmovq  r8,xmm2
  40d631:	mov    r8,QWORD PTR [r8]
  40d634:	mov    QWORD PTR [rsp+0x60],r8
  40d639:	mov    QWORD PTR [rsp+0x68],rdx
  40d63e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  40d644:	test   BYTE PTR [rcx+0x28],0x1
  40d648:	jne    40d650 <__swc_fn_ff58629f_000151_6203dca2+0x170>
  40d64a:	vmovups xmm12,xmm0
  40d64e:	jmp    40d66a <__swc_fn_ff58629f_000151_6203dca2+0x18a>
  40d650:	vmovq  rax,xmm2
  40d655:	mov    rax,QWORD PTR [rax]
  40d658:	lea    rcx,[rax+0x10]
  40d65c:	vmovups xmm12,xmm0
  40d660:	call   40cc70 <__swc_fn_ff58629f_000121_2648f149>
  40d665:	jmp    40e5a5 <__swc_fn_ff58629f_000151_6203dca2+0x10c5>
  40d66a:	test   DWORD PTR [rcx+0x28],0x400
  40d671:	je     40d6d2 <__swc_fn_ff58629f_000151_6203dca2+0x1f2>
  40d673:	vmovq  rax,xmm2
  40d678:	mov    rax,QWORD PTR [rax]
  40d67b:	xor    ecx,ecx
  40d67d:	test   rax,rax
  40d680:	je     40d6b0 <__swc_fn_ff58629f_000151_6203dca2+0x1d0>
  40d682:	mov    rdx,rax
  40d685:	mov    r8b,BYTE PTR [rdx]
  40d688:	test   r8b,r8b
  40d68b:	je     40d6b0 <__swc_fn_ff58629f_000151_6203dca2+0x1d0>
  40d68d:	cs nop WORD PTR [rax+rax*1+0x0]
  40d697:	nop    WORD PTR [rax+rax*1+0x0]
  40d6a0:	add    rdx,0x1
  40d6a4:	add    rcx,0x1
  40d6a8:	mov    r8b,BYTE PTR [rdx]
  40d6ab:	test   r8b,r8b
  40d6ae:	jne    40d6a0 <__swc_fn_ff58629f_000151_6203dca2+0x1c0>
  40d6b0:	mov    QWORD PTR [rsp+0x88],rax
  40d6b8:	mov    QWORD PTR [rsp+0x90],rcx
  40d6c0:	lea    rcx,[rsp+0x88]
  40d6c8:	call   40cc70 <__swc_fn_ff58629f_000121_2648f149>
  40d6cd:	jmp    40e5a5 <__swc_fn_ff58629f_000151_6203dca2+0x10c5>
  40d6d2:	cmp    BYTE PTR [rcx+0x2c],0x6
  40d6d6:	jne    40d6ed <__swc_fn_ff58629f_000151_6203dca2+0x20d>
  40d6d8:	vmovq  rax,xmm2
  40d6dd:	mov    rax,QWORD PTR [rax]
  40d6e0:	mov    rcx,rax
  40d6e3:	call   4116d0 <__swc_fn_ff58629f_000149_43c96957>
  40d6e8:	jmp    40e5a5 <__swc_fn_ff58629f_000151_6203dca2+0x10c5>
  40d6ed:	cmp    BYTE PTR [rcx+0x2c],0x1
  40d6f1:	jne    40e599 <__swc_fn_ff58629f_000151_6203dca2+0x10b9>
  40d6f7:	vmovq  rdx,xmm2
  40d6fc:	mov    cl,BYTE PTR [rcx+0x40]
  40d6ff:	cmp    cl,0x7
  40d702:	jb     40d745 <__swc_fn_ff58629f_000151_6203dca2+0x265>
  40d704:	je     40d7b8 <__swc_fn_ff58629f_000151_6203dca2+0x2d8>
  40d70a:	cmp    cl,0x8
  40d70d:	je     40d7c4 <__swc_fn_ff58629f_000151_6203dca2+0x2e4>
  40d713:	cmp    cl,0x9
  40d716:	je     40d7dd <__swc_fn_ff58629f_000151_6203dca2+0x2fd>
  40d71c:	cmp    cl,0xa
  40d71f:	je     40dea4 <__swc_fn_ff58629f_000151_6203dca2+0x9c4>
  40d725:	cmp    cl,0xb
  40d728:	je     40e56b <__swc_fn_ff58629f_000151_6203dca2+0x108b>
  40d72e:	cmp    cl,0xc
  40d731:	je     40d7d1 <__swc_fn_ff58629f_000151_6203dca2+0x2f1>
  40d737:	cmp    cl,0xd
  40d73a:	je     40e561 <__swc_fn_ff58629f_000151_6203dca2+0x1081>
  40d740:	jmp    40e58b <__swc_fn_ff58629f_000151_6203dca2+0x10ab>
  40d745:	cmp    cl,0x1
  40d748:	je     40d768 <__swc_fn_ff58629f_000151_6203dca2+0x288>
  40d74a:	cmp    cl,0x2
  40d74d:	je     40d776 <__swc_fn_ff58629f_000151_6203dca2+0x296>
  40d74f:	cmp    cl,0x3
  40d752:	je     40d784 <__swc_fn_ff58629f_000151_6203dca2+0x2a4>
  40d754:	cmp    cl,0x4
  40d757:	je     40d791 <__swc_fn_ff58629f_000151_6203dca2+0x2b1>
  40d759:	cmp    cl,0x5
  40d75c:	je     40d79e <__swc_fn_ff58629f_000151_6203dca2+0x2be>
  40d75e:	cmp    cl,0x6
  40d761:	je     40d7ab <__swc_fn_ff58629f_000151_6203dca2+0x2cb>
  40d763:	jmp    40e58b <__swc_fn_ff58629f_000151_6203dca2+0x10ab>
  40d768:	movsx  rcx,BYTE PTR [rdx]
  40d76c:	call   409fa0 <__swc_fn_ff58629f_000150_2eb804cc>
  40d771:	jmp    40e5a5 <__swc_fn_ff58629f_000151_6203dca2+0x10c5>
  40d776:	movsx  rcx,WORD PTR [rdx]
  40d77a:	call   409fa0 <__swc_fn_ff58629f_000150_2eb804cc>
  40d77f:	jmp    40e5a5 <__swc_fn_ff58629f_000151_6203dca2+0x10c5>
  40d784:	movsxd rcx,DWORD PTR [rdx]
  40d787:	call   409fa0 <__swc_fn_ff58629f_000150_2eb804cc>
  40d78c:	jmp    40e5a5 <__swc_fn_ff58629f_000151_6203dca2+0x10c5>
  40d791:	mov    rcx,QWORD PTR [rdx]
  40d794:	call   409fa0 <__swc_fn_ff58629f_000150_2eb804cc>
  40d799:	jmp    40e5a5 <__swc_fn_ff58629f_000151_6203dca2+0x10c5>
  40d79e:	movzx  ecx,BYTE PTR [rdx]
  40d7a1:	call   4116d0 <__swc_fn_ff58629f_000149_43c96957>
  40d7a6:	jmp    40e5a5 <__swc_fn_ff58629f_000151_6203dca2+0x10c5>
  40d7ab:	movzx  ecx,WORD PTR [rdx]
  40d7ae:	call   4116d0 <__swc_fn_ff58629f_000149_43c96957>
  40d7b3:	jmp    40e5a5 <__swc_fn_ff58629f_000151_6203dca2+0x10c5>
  40d7b8:	mov    ecx,DWORD PTR [rdx]
  40d7ba:	call   4116d0 <__swc_fn_ff58629f_000149_43c96957>
  40d7bf:	jmp    40e5a5 <__swc_fn_ff58629f_000151_6203dca2+0x10c5>
  40d7c4:	mov    rcx,QWORD PTR [rdx]
  40d7c7:	call   4116d0 <__swc_fn_ff58629f_000149_43c96957>
  40d7cc:	jmp    40e5a5 <__swc_fn_ff58629f_000151_6203dca2+0x10c5>
  40d7d1:	mov    ecx,DWORD PTR [rdx]
  40d7d3:	call   4116d0 <__swc_fn_ff58629f_000149_43c96957>
  40d7d8:	jmp    40e5a5 <__swc_fn_ff58629f_000151_6203dca2+0x10c5>
  40d7dd:	lea    rcx,[rsp+0xa8]
  40d7e5:	vxorps xmm0,xmm0,xmm0
  40d7e9:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  40d7f2:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  40d7fb:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  40d804:	vzeroupper
  40d807:	mov    DWORD PTR [rsp+0x108],0x0
  40d812:	vxorpd xmm0,xmm0,xmm0
  40d816:	vmovss xmm1,DWORD PTR [rdx]
  40d81a:	vcvtss2sd xmm0,xmm0,xmm1
  40d81e:	vmovsd xmm1,xmm1,xmm0
  40d822:	vcomisd xmm0,xmm0
  40d826:	setne  dl
  40d829:	movzx  edx,dl
  40d82c:	setp   r8b
  40d830:	movzx  r8d,r8b
  40d834:	or     edx,r8d
  40d837:	test   dl,dl
  40d839:	je     40d846 <__swc_fn_ff58629f_000151_6203dca2+0x366>
  40d83b:	mov    DWORD PTR [rcx],0x6e616e
  40d841:	jmp    40de38 <__swc_fn_ff58629f_000151_6203dca2+0x958>
  40d846:	vcomisd xmm1,xmm6
  40d84a:	ja     40d852 <__swc_fn_ff58629f_000151_6203dca2+0x372>
  40d84c:	vcomisd xmm7,xmm1
  40d850:	jbe    40d876 <__swc_fn_ff58629f_000151_6203dca2+0x396>
  40d852:	vxorpd xmm0,xmm0,xmm0
  40d856:	vcomisd xmm0,xmm1
  40d85a:	jbe    40d86b <__swc_fn_ff58629f_000151_6203dca2+0x38b>
  40d85c:	mov    DWORD PTR [rcx],0x666e692d
  40d862:	mov    BYTE PTR [rcx+0x4],0x0
  40d866:	jmp    40de38 <__swc_fn_ff58629f_000151_6203dca2+0x958>
  40d86b:	mov    DWORD PTR [rcx],0x666e69
  40d871:	jmp    40de38 <__swc_fn_ff58629f_000151_6203dca2+0x958>
  40d876:	vcomisd xmm1,xmm8
  40d87b:	jae    40d887 <__swc_fn_ff58629f_000151_6203dca2+0x3a7>
  40d87d:	vcomisd xmm9,xmm1
  40d881:	jbe    40dbfe <__swc_fn_ff58629f_000151_6203dca2+0x71e>
  40d887:	vmovups xmm0,xmm1
  40d88b:	vxorpd xmm2,xmm2,xmm2
  40d88f:	vcomisd xmm2,xmm1
  40d893:	jbe    40d8a3 <__swc_fn_ff58629f_000151_6203dca2+0x3c3>
  40d895:	vmovsd xmm1,xmm1,xmm0
  40d899:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x4d7f]        # 412620 <__swc_rdata_base_ff58629f+0x510>
  40d8a1:	jmp    40d8a7 <__swc_fn_ff58629f_000151_6203dca2+0x3c7>
  40d8a3:	vmovsd xmm1,xmm1,xmm0
  40d8a7:	xor    r8d,r8d
  40d8aa:	vcomisd xmm1,xmm15
  40d8af:	jb     40d8d0 <__swc_fn_ff58629f_000151_6203dca2+0x3f0>
  40d8b1:	cs nop WORD PTR [rax+rax*1+0x0]
  40d8bb:	nop    DWORD PTR [rax+rax*1+0x0]
  40d8c0:	vdivsd xmm1,xmm1,xmm15
  40d8c5:	add    r8,0x1
  40d8c9:	vcomisd xmm1,xmm15
  40d8ce:	jae    40d8c0 <__swc_fn_ff58629f_000151_6203dca2+0x3e0>
  40d8d0:	mov    r9,rcx
  40d8d3:	vxorpd xmm2,xmm2,xmm2
  40d8d7:	vcomisd xmm2,xmm0
  40d8db:	jbe    40d8e4 <__swc_fn_ff58629f_000151_6203dca2+0x404>
  40d8dd:	mov    BYTE PTR [rcx],0x2d
  40d8e0:	lea    r9,[rcx+0x1]
  40d8e4:	vcvttsd2si rdx,xmm1
  40d8e9:	mov    r10b,dl
  40d8ec:	add    r10b,0x30
  40d8f0:	mov    BYTE PTR [r9],r10b
  40d8f3:	vxorpd xmm0,xmm0,xmm0
  40d8f7:	movzx  edx,dl
  40d8fa:	vcvtsi2sd xmm0,xmm0,rdx
  40d8ff:	vsubsd xmm0,xmm1,xmm0
  40d903:	vmulsd xmm1,xmm0,xmm15
  40d908:	mov    BYTE PTR [r9+0x1],0x2e
  40d90d:	vcvttsd2si rdx,xmm1
  40d912:	mov    r10b,dl
  40d915:	add    r10b,0x30
  40d919:	mov    BYTE PTR [r9+0x2],r10b
  40d91d:	vxorpd xmm0,xmm0,xmm0
  40d921:	movzx  edx,dl
  40d924:	vcvtsi2sd xmm0,xmm0,rdx
  40d929:	vsubsd xmm0,xmm1,xmm0
  40d92d:	vmulsd xmm1,xmm0,xmm15
  40d932:	vcvttsd2si rdx,xmm1
  40d937:	mov    r10b,dl
  40d93a:	add    r10b,0x30
  40d93e:	mov    BYTE PTR [r9+0x3],r10b
  40d942:	vxorpd xmm0,xmm0,xmm0
  40d946:	movzx  edx,dl
  40d949:	vcvtsi2sd xmm0,xmm0,rdx
  40d94e:	vsubsd xmm0,xmm1,xmm0
  40d952:	vmulsd xmm1,xmm0,xmm15
  40d957:	vcvttsd2si rdx,xmm1
  40d95c:	mov    r10b,dl
  40d95f:	add    r10b,0x30
  40d963:	mov    BYTE PTR [r9+0x4],r10b
  40d967:	vxorpd xmm0,xmm0,xmm0
  40d96b:	movzx  edx,dl
  40d96e:	vcvtsi2sd xmm0,xmm0,rdx
  40d973:	vsubsd xmm0,xmm1,xmm0
  40d977:	vmulsd xmm1,xmm0,xmm15
  40d97c:	vcvttsd2si rdx,xmm1
  40d981:	mov    r10b,dl
  40d984:	add    r10b,0x30
  40d988:	mov    BYTE PTR [r9+0x5],r10b
  40d98c:	vxorpd xmm0,xmm0,xmm0
  40d990:	movzx  edx,dl
  40d993:	vcvtsi2sd xmm0,xmm0,rdx
  40d998:	vsubsd xmm0,xmm1,xmm0
  40d99c:	vmulsd xmm1,xmm0,xmm15
  40d9a1:	vcvttsd2si rdx,xmm1
  40d9a6:	mov    r10b,dl
  40d9a9:	add    r10b,0x30
  40d9ad:	mov    BYTE PTR [r9+0x6],r10b
  40d9b1:	vxorpd xmm0,xmm0,xmm0
  40d9b5:	movzx  edx,dl
  40d9b8:	vcvtsi2sd xmm0,xmm0,rdx
  40d9bd:	vsubsd xmm0,xmm1,xmm0
  40d9c1:	vmulsd xmm1,xmm0,xmm15
  40d9c6:	vcvttsd2si rdx,xmm1
  40d9cb:	mov    r10b,dl
  40d9ce:	add    r10b,0x30
  40d9d2:	mov    BYTE PTR [r9+0x7],r10b
  40d9d6:	vxorpd xmm0,xmm0,xmm0
  40d9da:	movzx  edx,dl
  40d9dd:	vcvtsi2sd xmm0,xmm0,rdx
  40d9e2:	vsubsd xmm0,xmm1,xmm0
  40d9e6:	vmulsd xmm1,xmm0,xmm15
  40d9eb:	vcvttsd2si rdx,xmm1
  40d9f0:	mov    r10b,dl
  40d9f3:	add    r10b,0x30
  40d9f7:	mov    BYTE PTR [r9+0x8],r10b
  40d9fb:	vxorpd xmm0,xmm0,xmm0
  40d9ff:	movzx  edx,dl
  40da02:	vcvtsi2sd xmm0,xmm0,rdx
  40da07:	vsubsd xmm0,xmm1,xmm0
  40da0b:	vmulsd xmm1,xmm0,xmm15
  40da10:	vcvttsd2si rdx,xmm1
  40da15:	mov    r10b,dl
  40da18:	add    r10b,0x30
  40da1c:	mov    BYTE PTR [r9+0x9],r10b
  40da20:	vxorpd xmm0,xmm0,xmm0
  40da24:	movzx  edx,dl
  40da27:	vcvtsi2sd xmm0,xmm0,rdx
  40da2c:	vsubsd xmm0,xmm1,xmm0
  40da30:	vmulsd xmm1,xmm0,xmm15
  40da35:	vcvttsd2si rdx,xmm1
  40da3a:	mov    r10b,dl
  40da3d:	add    r10b,0x30
  40da41:	mov    BYTE PTR [r9+0xa],r10b
  40da45:	vxorpd xmm0,xmm0,xmm0
  40da49:	movzx  edx,dl
  40da4c:	vcvtsi2sd xmm0,xmm0,rdx
  40da51:	vsubsd xmm0,xmm1,xmm0
  40da55:	vmulsd xmm1,xmm0,xmm15
  40da5a:	vcvttsd2si rdx,xmm1
  40da5f:	mov    r10b,dl
  40da62:	add    r10b,0x30
  40da66:	mov    BYTE PTR [r9+0xb],r10b
  40da6a:	lea    r10,[r9+0x4]
  40da6e:	vxorpd xmm0,xmm0,xmm0
  40da72:	movzx  edx,dl
  40da75:	vcvtsi2sd xmm0,xmm0,rdx
  40da7a:	vsubsd xmm0,xmm1,xmm0
  40da7e:	vmulsd xmm1,xmm0,xmm15
  40da83:	vcvttsd2si rdx,xmm1
  40da88:	mov    r11b,dl
  40da8b:	add    r11b,0x30
  40da8f:	mov    BYTE PTR [r9+0xc],r11b
  40da93:	vxorpd xmm0,xmm0,xmm0
  40da97:	movzx  edx,dl
  40da9a:	vcvtsi2sd xmm0,xmm0,rdx
  40da9f:	vsubsd xmm0,xmm1,xmm0
  40daa3:	vmulsd xmm1,xmm0,xmm15
  40daa8:	vcvttsd2si rdx,xmm1
  40daad:	mov    r11b,dl
  40dab0:	add    r11b,0x30
  40dab4:	mov    BYTE PTR [r9+0xd],r11b
  40dab8:	lea    r10,[r10+0x2]
  40dabc:	vxorpd xmm0,xmm0,xmm0
  40dac0:	movzx  edx,dl
  40dac3:	vcvtsi2sd xmm0,xmm0,rdx
  40dac8:	vsubsd xmm0,xmm1,xmm0
  40dacc:	vmulsd xmm1,xmm0,xmm15
  40dad1:	vcvttsd2si rdx,xmm1
  40dad6:	mov    r11b,dl
  40dad9:	add    r11b,0x30
  40dadd:	mov    BYTE PTR [r9+0xe],r11b
  40dae1:	vxorpd xmm0,xmm0,xmm0
  40dae5:	movzx  edx,dl
  40dae8:	vcvtsi2sd xmm0,xmm0,rdx
  40daed:	vsubsd xmm0,xmm1,xmm0
  40daf1:	vmulsd xmm1,xmm0,xmm15
  40daf6:	vcvttsd2si rdx,xmm1
  40dafb:	mov    r11b,dl
  40dafe:	add    r11b,0x30
  40db02:	mov    BYTE PTR [r9+0xf],r11b
  40db06:	lea    r10,[r10+0x2]
  40db0a:	lea    r10,[r10+0x2]
  40db0e:	lea    r10,[r10+0x2]
  40db12:	lea    r10,[r10+0x2]
  40db16:	lea    r10,[r10+0x2]
  40db1a:	vxorpd xmm0,xmm0,xmm0
  40db1e:	movzx  edx,dl
  40db21:	vcvtsi2sd xmm0,xmm0,rdx
  40db26:	vsubsd xmm0,xmm1,xmm0
  40db2a:	vmulsd xmm1,xmm0,xmm15
  40db2f:	vcvttsd2si rdx,xmm1
  40db34:	mov    r11b,dl
  40db37:	add    r11b,0x30
  40db3b:	mov    BYTE PTR [r9+0x10],r11b
  40db3f:	vxorpd xmm0,xmm0,xmm0
  40db43:	movzx  edx,dl
  40db46:	vcvtsi2sd xmm0,xmm0,rdx
  40db4b:	vsubsd xmm0,xmm1,xmm0
  40db4f:	vmulsd xmm1,xmm0,xmm15
  40db54:	vcvttsd2si rdx,xmm1
  40db59:	add    dl,0x30
  40db5c:	mov    BYTE PTR [r9+0x11],dl
  40db60:	mov    BYTE PTR [r10+0x2],0x65
  40db65:	lea    r9,[r10+0x3]
  40db69:	test   r8,r8
  40db6c:	jl     40db75 <__swc_fn_ff58629f_000151_6203dca2+0x695>
  40db6e:	mov    BYTE PTR [r9],0x2b
  40db72:	inc    r9
  40db75:	mov    r10,r9
  40db78:	mov    rdx,r8
  40db7b:	nop    DWORD PTR [rax+rax*1+0x0]
  40db80:	mov    r11,rdx
  40db83:	movabs rdx,0x6666666666666667
  40db8d:	mov    rax,r11
  40db90:	imul   rdx
  40db93:	sar    rdx,0x2
  40db97:	mov    r12,rdx
  40db9a:	shr    rdx,0x3f
  40db9e:	add    r12,rdx
  40dba1:	mov    rdx,r12
  40dba4:	imul   r13,r12,0xa
  40dba8:	sub    r11,r13
  40dbab:	mov    r13,QWORD PTR [rip+0x4a5e]        # 412610 <__swc_rdata_base_ff58629f+0x500>
  40dbb2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40dbb7:	mov    BYTE PTR [r10],r11b
  40dbba:	lea    r11,[r10+0x1]
  40dbbe:	mov    r10,r11
  40dbc1:	test   r12,r12
  40dbc4:	jne    40db80 <__swc_fn_ff58629f_000151_6203dca2+0x6a0>
  40dbc6:	test   r8,r8
  40dbc9:	jge    40dbd3 <__swc_fn_ff58629f_000151_6203dca2+0x6f3>
  40dbcb:	mov    BYTE PTR [r11],0x2d
  40dbcf:	lea    r10,[r11+0x1]
  40dbd3:	mov    BYTE PTR [r10],0x0
  40dbd7:	sub    r10,0x1
  40dbdb:	nop    DWORD PTR [rax+rax*1+0x0]
  40dbe0:	cmp    r9,r10
  40dbe3:	jae    40de38 <__swc_fn_ff58629f_000151_6203dca2+0x958>
  40dbe9:	mov    al,BYTE PTR [r10]
  40dbec:	mov    dl,BYTE PTR [r9]
  40dbef:	mov    BYTE PTR [r10],dl
  40dbf2:	sub    r10,0x1
  40dbf6:	mov    BYTE PTR [r9],al
  40dbf9:	inc    r9
  40dbfc:	jmp    40dbe0 <__swc_fn_ff58629f_000151_6203dca2+0x700>
  40dbfe:	vcvttsd2si rdx,xmm1
  40dc03:	mov    r8,rdx
  40dc06:	vxorpd xmm0,xmm0,xmm0
  40dc0a:	vcvtsi2sd xmm0,xmm0,rdx
  40dc0f:	vsubsd xmm0,xmm1,xmm0
  40dc13:	mov    r9d,0x8
  40dc19:	vxorpd xmm2,xmm2,xmm2
  40dc1d:	vcomisd xmm2,xmm0
  40dc21:	jbe    40dc2b <__swc_fn_ff58629f_000151_6203dca2+0x74b>
  40dc23:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x49f5]        # 412620 <__swc_rdata_base_ff58629f+0x510>
  40dc2b:	test   r9d,r9d
  40dc2e:	je     40dc3a <__swc_fn_ff58629f_000151_6203dca2+0x75a>
  40dc30:	vmulsd xmm0,xmm0,xmm14
  40dc35:	dec    r9d
  40dc38:	jne    40dc30 <__swc_fn_ff58629f_000151_6203dca2+0x750>
  40dc3a:	vcvttsd2si r9,xmm0
  40dc3f:	mov    r10,r9
  40dc42:	vxorpd xmm2,xmm2,xmm2
  40dc46:	vcvtsi2sd xmm2,xmm2,r9
  40dc4b:	vsubsd xmm0,xmm0,xmm2
  40dc4f:	vcomisd xmm0,xmm10
  40dc54:	lea    r9,[r9+0x1]
  40dc58:	cmova  r10,r9
  40dc5c:	cmp    r10,0x5f5e100
  40dc63:	jne    40dc7c <__swc_fn_ff58629f_000151_6203dca2+0x79c>
  40dc65:	lea    r8,[rdx-0x1]
  40dc69:	vxorpd xmm0,xmm0,xmm0
  40dc6d:	vcomisd xmm0,xmm1
  40dc71:	lea    rdx,[rdx+0x1]
  40dc75:	cmovbe r8,rdx
  40dc79:	xor    r10d,r10d
  40dc7c:	mov    r9,rcx
  40dc7f:	test   r8,r8
  40dc82:	jne    40dca2 <__swc_fn_ff58629f_000151_6203dca2+0x7c2>
  40dc84:	vxorpd xmm0,xmm0,xmm0
  40dc88:	vcomisd xmm0,xmm1
  40dc8c:	jbe    40dc95 <__swc_fn_ff58629f_000151_6203dca2+0x7b5>
  40dc8e:	mov    BYTE PTR [rcx],0x2d
  40dc91:	lea    r9,[rcx+0x1]
  40dc95:	mov    BYTE PTR [r9],0x30
  40dc99:	add    r9,0x1
  40dc9d:	jmp    40dd3b <__swc_fn_ff58629f_000151_6203dca2+0x85b>
  40dca2:	mov    r9,rcx
  40dca5:	mov    rdx,r8
  40dca8:	nop    DWORD PTR [rax+rax*1+0x0]
  40dcb0:	mov    r11,rdx
  40dcb3:	movabs rdx,0x6666666666666667
  40dcbd:	mov    r15,rax
  40dcc0:	mov    rax,r11
  40dcc3:	imul   rdx
  40dcc6:	mov    r12,rdx
  40dcc9:	mov    rax,r15
  40dccc:	sar    r12,0x2
  40dcd0:	mov    rdx,r12
  40dcd3:	shr    rdx,0x3f
  40dcd7:	add    r12,rdx
  40dcda:	mov    rdx,r12
  40dcdd:	imul   r13,r12,0xa
  40dce1:	sub    r11,r13
  40dce4:	mov    r13,QWORD PTR [rip+0x4925]        # 412610 <__swc_rdata_base_ff58629f+0x500>
  40dceb:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40dcf0:	mov    BYTE PTR [r9],r11b
  40dcf3:	lea    r11,[r9+0x1]
  40dcf7:	mov    r9,r11
  40dcfa:	test   r12,r12
  40dcfd:	jne    40dcb0 <__swc_fn_ff58629f_000151_6203dca2+0x7d0>
  40dcff:	test   r8,r8
  40dd02:	jge    40dd0c <__swc_fn_ff58629f_000151_6203dca2+0x82c>
  40dd04:	mov    BYTE PTR [r11],0x2d
  40dd08:	lea    r9,[r11+0x1]
  40dd0c:	mov    rdx,r9
  40dd0f:	mov    BYTE PTR [r9],0x0
  40dd13:	sub    r9,0x1
  40dd17:	mov    r8,rcx
  40dd1a:	cmp    r8,r9
  40dd1d:	jae    40dd38 <__swc_fn_ff58629f_000151_6203dca2+0x858>
  40dd1f:	nop
  40dd20:	mov    r11b,BYTE PTR [r9]
  40dd23:	mov    r12b,BYTE PTR [r8]
  40dd26:	mov    BYTE PTR [r9],r12b
  40dd29:	sub    r9,0x1
  40dd2d:	mov    BYTE PTR [r8],r11b
  40dd30:	inc    r8
  40dd33:	cmp    r8,r9
  40dd36:	jb     40dd20 <__swc_fn_ff58629f_000151_6203dca2+0x840>
  40dd38:	mov    r9,rdx
  40dd3b:	mov    BYTE PTR [r9],0x2e
  40dd3f:	add    r9,0x1
  40dd43:	xor    r8d,r8d
  40dd46:	test   r10,r10
  40dd49:	je     40dd8f <__swc_fn_ff58629f_000151_6203dca2+0x8af>
  40dd4b:	mov    r11d,0x989680
  40dd51:	cmp    r10,r11
  40dd54:	jge    40dd8f <__swc_fn_ff58629f_000151_6203dca2+0x8af>
  40dd56:	cs nop WORD PTR [rax+rax*1+0x0]
  40dd60:	inc    r8d
  40dd63:	movabs rdx,0x6666666666666667
  40dd6d:	mov    r15,rax
  40dd70:	mov    rax,r11
  40dd73:	imul   rdx
  40dd76:	mov    r11,rdx
  40dd79:	mov    rax,r15
  40dd7c:	sar    r11,0x2
  40dd80:	mov    rdx,r11
  40dd83:	shr    rdx,0x3f
  40dd87:	add    r11,rdx
  40dd8a:	cmp    r10,r11
  40dd8d:	jl     40dd60 <__swc_fn_ff58629f_000151_6203dca2+0x880>
  40dd8f:	test   r8d,r8d
  40dd92:	je     40ddad <__swc_fn_ff58629f_000151_6203dca2+0x8cd>
  40dd94:	cs nop WORD PTR [rax+rax*1+0x0]
  40dd9e:	xchg   ax,ax
  40dda0:	mov    BYTE PTR [r9],0x30
  40dda4:	add    r9,0x1
  40dda8:	dec    r8d
  40ddab:	jne    40dda0 <__swc_fn_ff58629f_000151_6203dca2+0x8c0>
  40ddad:	mov    r8,r9
  40ddb0:	mov    rdx,r10
  40ddb3:	cs nop WORD PTR [rax+rax*1+0x0]
  40ddbd:	nop    DWORD PTR [rax]
  40ddc0:	mov    r11,rdx
  40ddc3:	movabs rdx,0x6666666666666667
  40ddcd:	mov    rax,r11
  40ddd0:	imul   rdx
  40ddd3:	sar    rdx,0x2
  40ddd7:	mov    r12,rdx
  40ddda:	shr    rdx,0x3f
  40ddde:	add    r12,rdx
  40dde1:	mov    rdx,r12
  40dde4:	imul   r13,r12,0xa
  40dde8:	sub    r11,r13
  40ddeb:	mov    r13,QWORD PTR [rip+0x481e]        # 412610 <__swc_rdata_base_ff58629f+0x500>
  40ddf2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40ddf7:	mov    BYTE PTR [r8],r11b
  40ddfa:	lea    r11,[r8+0x1]
  40ddfe:	mov    r8,r11
  40de01:	test   r12,r12
  40de04:	jne    40ddc0 <__swc_fn_ff58629f_000151_6203dca2+0x8e0>
  40de06:	test   r10,r10
  40de09:	jge    40de13 <__swc_fn_ff58629f_000151_6203dca2+0x933>
  40de0b:	mov    BYTE PTR [r11],0x2d
  40de0f:	lea    r8,[r11+0x1]
  40de13:	mov    BYTE PTR [r8],0x0
  40de17:	sub    r8,0x1
  40de1b:	cmp    r9,r8
  40de1e:	jae    40de38 <__swc_fn_ff58629f_000151_6203dca2+0x958>
  40de20:	mov    al,BYTE PTR [r8]
  40de23:	mov    dl,BYTE PTR [r9]
  40de26:	mov    BYTE PTR [r8],dl
  40de29:	sub    r8,0x1
  40de2d:	mov    BYTE PTR [r9],al
  40de30:	inc    r9
  40de33:	cmp    r9,r8
  40de36:	jb     40de20 <__swc_fn_ff58629f_000151_6203dca2+0x940>
  40de38:	xor    eax,eax
  40de3a:	test   rcx,rcx
  40de3d:	je     40de70 <__swc_fn_ff58629f_000151_6203dca2+0x990>
  40de3f:	mov    rdx,rcx
  40de42:	mov    r8b,BYTE PTR [rdx]
  40de45:	test   r8b,r8b
  40de48:	je     40de70 <__swc_fn_ff58629f_000151_6203dca2+0x990>
  40de4a:	cs nop WORD PTR [rax+rax*1+0x0]
  40de54:	cs nop WORD PTR [rax+rax*1+0x0]
  40de5e:	xchg   ax,ax
  40de60:	add    rdx,0x1
  40de64:	add    rax,0x1
  40de68:	mov    r8b,BYTE PTR [rdx]
  40de6b:	test   r8b,r8b
  40de6e:	jne    40de60 <__swc_fn_ff58629f_000151_6203dca2+0x980>
  40de70:	mov    QWORD PTR [rsp+0x240],rcx
  40de78:	mov    QWORD PTR [rsp+0x248],rax
  40de80:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  40de89:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  40de92:	lea    rcx,[rsp+0x250]
  40de9a:	call   40cc70 <__swc_fn_ff58629f_000121_2648f149>
  40de9f:	jmp    40e5a5 <__swc_fn_ff58629f_000151_6203dca2+0x10c5>
  40dea4:	lea    rcx,[rsp+0x260]
  40deac:	vxorps xmm0,xmm0,xmm0
  40deb0:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  40deb9:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  40dec2:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  40decb:	vzeroupper
  40dece:	mov    DWORD PTR [rsp+0x2c0],0x0
  40ded9:	vmovsd xmm0,QWORD PTR [rdx]
  40dedd:	vcomisd xmm0,xmm0
  40dee1:	setne  dl
  40dee4:	movzx  edx,dl
  40dee7:	setp   r8b
  40deeb:	movzx  r8d,r8b
  40deef:	or     edx,r8d
  40def2:	test   dl,dl
  40def4:	je     40df01 <__swc_fn_ff58629f_000151_6203dca2+0xa21>
  40def6:	mov    DWORD PTR [rcx],0x6e616e
  40defc:	jmp    40e508 <__swc_fn_ff58629f_000151_6203dca2+0x1028>
  40df01:	vcomisd xmm0,xmm11
  40df06:	ja     40df17 <__swc_fn_ff58629f_000151_6203dca2+0xa37>
  40df08:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  40df11:	vcomisd xmm6,xmm0
  40df15:	jbe    40df3b <__swc_fn_ff58629f_000151_6203dca2+0xa5b>
  40df17:	vxorpd xmm1,xmm1,xmm1
  40df1b:	vcomisd xmm1,xmm0
  40df1f:	jbe    40df30 <__swc_fn_ff58629f_000151_6203dca2+0xa50>
  40df21:	mov    DWORD PTR [rcx],0x666e692d
  40df27:	mov    BYTE PTR [rcx+0x4],0x0
  40df2b:	jmp    40e508 <__swc_fn_ff58629f_000151_6203dca2+0x1028>
  40df30:	mov    DWORD PTR [rcx],0x666e69
  40df36:	jmp    40e508 <__swc_fn_ff58629f_000151_6203dca2+0x1028>
  40df3b:	vcomisd xmm0,xmm13
  40df40:	jae    40df4c <__swc_fn_ff58629f_000151_6203dca2+0xa6c>
  40df42:	vcomisd xmm12,xmm0
  40df46:	jbe    40e2ae <__swc_fn_ff58629f_000151_6203dca2+0xdce>
  40df4c:	vmovups xmm1,xmm0
  40df50:	vxorpd xmm2,xmm2,xmm2
  40df54:	vcomisd xmm2,xmm0
  40df58:	jbe    40df68 <__swc_fn_ff58629f_000151_6203dca2+0xa88>
  40df5a:	vmovsd xmm0,xmm0,xmm1
  40df5e:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x46ba]        # 412620 <__swc_rdata_base_ff58629f+0x510>
  40df66:	jmp    40df6c <__swc_fn_ff58629f_000151_6203dca2+0xa8c>
  40df68:	vmovsd xmm0,xmm0,xmm1
  40df6c:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  40df75:	xor    r8d,r8d
  40df78:	vcomisd xmm0,xmm6
  40df7c:	jb     40df8e <__swc_fn_ff58629f_000151_6203dca2+0xaae>
  40df7e:	xchg   ax,ax
  40df80:	vdivsd xmm0,xmm0,xmm6
  40df84:	add    r8,0x1
  40df88:	vcomisd xmm0,xmm6
  40df8c:	jae    40df80 <__swc_fn_ff58629f_000151_6203dca2+0xaa0>
  40df8e:	mov    r9,rcx
  40df91:	vxorpd xmm2,xmm2,xmm2
  40df95:	vcomisd xmm2,xmm1
  40df99:	jbe    40dfa2 <__swc_fn_ff58629f_000151_6203dca2+0xac2>
  40df9b:	mov    BYTE PTR [rcx],0x2d
  40df9e:	lea    r9,[rcx+0x1]
  40dfa2:	vcvttsd2si rdx,xmm0
  40dfa7:	mov    r10b,dl
  40dfaa:	add    r10b,0x30
  40dfae:	mov    BYTE PTR [r9],r10b
  40dfb1:	vxorpd xmm1,xmm1,xmm1
  40dfb5:	movzx  edx,dl
  40dfb8:	vcvtsi2sd xmm1,xmm1,rdx
  40dfbd:	vsubsd xmm0,xmm0,xmm1
  40dfc1:	vmulsd xmm0,xmm0,xmm6
  40dfc5:	mov    BYTE PTR [r9+0x1],0x2e
  40dfca:	vcvttsd2si rdx,xmm0
  40dfcf:	mov    r10b,dl
  40dfd2:	add    r10b,0x30
  40dfd6:	mov    BYTE PTR [r9+0x2],r10b
  40dfda:	vxorpd xmm1,xmm1,xmm1
  40dfde:	movzx  edx,dl
  40dfe1:	vcvtsi2sd xmm1,xmm1,rdx
  40dfe6:	vsubsd xmm0,xmm0,xmm1
  40dfea:	vmulsd xmm0,xmm0,xmm6
  40dfee:	vcvttsd2si rdx,xmm0
  40dff3:	mov    r10b,dl
  40dff6:	add    r10b,0x30
  40dffa:	mov    BYTE PTR [r9+0x3],r10b
  40dffe:	vxorpd xmm1,xmm1,xmm1
  40e002:	movzx  edx,dl
  40e005:	vcvtsi2sd xmm1,xmm1,rdx
  40e00a:	vsubsd xmm0,xmm0,xmm1
  40e00e:	vmulsd xmm0,xmm0,xmm6
  40e012:	vcvttsd2si rdx,xmm0
  40e017:	mov    r10b,dl
  40e01a:	add    r10b,0x30
  40e01e:	mov    BYTE PTR [r9+0x4],r10b
  40e022:	vxorpd xmm1,xmm1,xmm1
  40e026:	movzx  edx,dl
  40e029:	vcvtsi2sd xmm1,xmm1,rdx
  40e02e:	vsubsd xmm0,xmm0,xmm1
  40e032:	vmulsd xmm0,xmm0,xmm6
  40e036:	vcvttsd2si rdx,xmm0
  40e03b:	mov    r10b,dl
  40e03e:	add    r10b,0x30
  40e042:	mov    BYTE PTR [r9+0x5],r10b
  40e046:	vxorpd xmm1,xmm1,xmm1
  40e04a:	movzx  edx,dl
  40e04d:	vcvtsi2sd xmm1,xmm1,rdx
  40e052:	vsubsd xmm0,xmm0,xmm1
  40e056:	vmulsd xmm0,xmm0,xmm6
  40e05a:	vcvttsd2si rdx,xmm0
  40e05f:	mov    r10b,dl
  40e062:	add    r10b,0x30
  40e066:	mov    BYTE PTR [r9+0x6],r10b
  40e06a:	vxorpd xmm1,xmm1,xmm1
  40e06e:	movzx  edx,dl
  40e071:	vcvtsi2sd xmm1,xmm1,rdx
  40e076:	vsubsd xmm0,xmm0,xmm1
  40e07a:	vmulsd xmm0,xmm0,xmm6
  40e07e:	vcvttsd2si rdx,xmm0
  40e083:	mov    r10b,dl
  40e086:	add    r10b,0x30
  40e08a:	mov    BYTE PTR [r9+0x7],r10b
  40e08e:	vxorpd xmm1,xmm1,xmm1
  40e092:	movzx  edx,dl
  40e095:	vcvtsi2sd xmm1,xmm1,rdx
  40e09a:	vsubsd xmm0,xmm0,xmm1
  40e09e:	vmulsd xmm0,xmm0,xmm6
  40e0a2:	vcvttsd2si rdx,xmm0
  40e0a7:	mov    r10b,dl
  40e0aa:	add    r10b,0x30
  40e0ae:	mov    BYTE PTR [r9+0x8],r10b
  40e0b2:	vxorpd xmm1,xmm1,xmm1
  40e0b6:	movzx  edx,dl
  40e0b9:	vcvtsi2sd xmm1,xmm1,rdx
  40e0be:	vsubsd xmm0,xmm0,xmm1
  40e0c2:	vmulsd xmm0,xmm0,xmm6
  40e0c6:	vcvttsd2si rdx,xmm0
  40e0cb:	mov    r10b,dl
  40e0ce:	add    r10b,0x30
  40e0d2:	mov    BYTE PTR [r9+0x9],r10b
  40e0d6:	vxorpd xmm1,xmm1,xmm1
  40e0da:	movzx  edx,dl
  40e0dd:	vcvtsi2sd xmm1,xmm1,rdx
  40e0e2:	vsubsd xmm0,xmm0,xmm1
  40e0e6:	vmulsd xmm0,xmm0,xmm6
  40e0ea:	vcvttsd2si rdx,xmm0
  40e0ef:	mov    r10b,dl
  40e0f2:	add    r10b,0x30
  40e0f6:	mov    BYTE PTR [r9+0xa],r10b
  40e0fa:	vxorpd xmm1,xmm1,xmm1
  40e0fe:	movzx  edx,dl
  40e101:	vcvtsi2sd xmm1,xmm1,rdx
  40e106:	vsubsd xmm0,xmm0,xmm1
  40e10a:	vmulsd xmm0,xmm0,xmm6
  40e10e:	vcvttsd2si rdx,xmm0
  40e113:	mov    r10b,dl
  40e116:	add    r10b,0x30
  40e11a:	mov    BYTE PTR [r9+0xb],r10b
  40e11e:	lea    r10,[r9+0x4]
  40e122:	vxorpd xmm1,xmm1,xmm1
  40e126:	movzx  edx,dl
  40e129:	vcvtsi2sd xmm1,xmm1,rdx
  40e12e:	vsubsd xmm0,xmm0,xmm1
  40e132:	vmulsd xmm0,xmm0,xmm6
  40e136:	vcvttsd2si rdx,xmm0
  40e13b:	mov    r11b,dl
  40e13e:	add    r11b,0x30
  40e142:	mov    BYTE PTR [r9+0xc],r11b
  40e146:	vxorpd xmm1,xmm1,xmm1
  40e14a:	movzx  edx,dl
  40e14d:	vcvtsi2sd xmm1,xmm1,rdx
  40e152:	vsubsd xmm0,xmm0,xmm1
  40e156:	vmulsd xmm0,xmm0,xmm6
  40e15a:	vcvttsd2si rdx,xmm0
  40e15f:	mov    r11b,dl
  40e162:	add    r11b,0x30
  40e166:	mov    BYTE PTR [r9+0xd],r11b
  40e16a:	lea    r10,[r10+0x2]
  40e16e:	vxorpd xmm1,xmm1,xmm1
  40e172:	movzx  edx,dl
  40e175:	vcvtsi2sd xmm1,xmm1,rdx
  40e17a:	vsubsd xmm0,xmm0,xmm1
  40e17e:	vmulsd xmm0,xmm0,xmm6
  40e182:	vcvttsd2si rdx,xmm0
  40e187:	mov    r11b,dl
  40e18a:	add    r11b,0x30
  40e18e:	mov    BYTE PTR [r9+0xe],r11b
  40e192:	vxorpd xmm1,xmm1,xmm1
  40e196:	movzx  edx,dl
  40e199:	vcvtsi2sd xmm1,xmm1,rdx
  40e19e:	vsubsd xmm0,xmm0,xmm1
  40e1a2:	vmulsd xmm0,xmm0,xmm6
  40e1a6:	vcvttsd2si rdx,xmm0
  40e1ab:	mov    r11b,dl
  40e1ae:	add    r11b,0x30
  40e1b2:	mov    BYTE PTR [r9+0xf],r11b
  40e1b6:	lea    r10,[r10+0x2]
  40e1ba:	lea    r10,[r10+0x2]
  40e1be:	lea    r10,[r10+0x2]
  40e1c2:	lea    r10,[r10+0x2]
  40e1c6:	lea    r10,[r10+0x2]
  40e1ca:	vxorpd xmm1,xmm1,xmm1
  40e1ce:	movzx  edx,dl
  40e1d1:	vcvtsi2sd xmm1,xmm1,rdx
  40e1d6:	vsubsd xmm0,xmm0,xmm1
  40e1da:	vmulsd xmm0,xmm0,xmm6
  40e1de:	vcvttsd2si rdx,xmm0
  40e1e3:	mov    r11b,dl
  40e1e6:	add    r11b,0x30
  40e1ea:	mov    BYTE PTR [r9+0x10],r11b
  40e1ee:	vxorpd xmm1,xmm1,xmm1
  40e1f2:	movzx  edx,dl
  40e1f5:	vcvtsi2sd xmm1,xmm1,rdx
  40e1fa:	vsubsd xmm0,xmm0,xmm1
  40e1fe:	vmulsd xmm0,xmm0,xmm6
  40e202:	vcvttsd2si rdx,xmm0
  40e207:	add    dl,0x30
  40e20a:	mov    BYTE PTR [r9+0x11],dl
  40e20e:	mov    BYTE PTR [r10+0x2],0x65
  40e213:	lea    r9,[r10+0x3]
  40e217:	test   r8,r8
  40e21a:	jl     40e223 <__swc_fn_ff58629f_000151_6203dca2+0xd43>
  40e21c:	mov    BYTE PTR [r9],0x2b
  40e220:	inc    r9
  40e223:	mov    r10,r9
  40e226:	mov    rdx,r8
  40e229:	nop    DWORD PTR [rax+0x0]
  40e230:	mov    r11,rdx
  40e233:	movabs rdx,0x6666666666666667
  40e23d:	mov    rax,r11
  40e240:	imul   rdx
  40e243:	sar    rdx,0x2
  40e247:	mov    r12,rdx
  40e24a:	shr    rdx,0x3f
  40e24e:	add    r12,rdx
  40e251:	mov    rdx,r12
  40e254:	imul   r13,r12,0xa
  40e258:	sub    r11,r13
  40e25b:	mov    r13,QWORD PTR [rip+0x43ae]        # 412610 <__swc_rdata_base_ff58629f+0x500>
  40e262:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40e267:	mov    BYTE PTR [r10],r11b
  40e26a:	lea    r11,[r10+0x1]
  40e26e:	mov    r10,r11
  40e271:	test   r12,r12
  40e274:	jne    40e230 <__swc_fn_ff58629f_000151_6203dca2+0xd50>
  40e276:	test   r8,r8
  40e279:	jge    40e283 <__swc_fn_ff58629f_000151_6203dca2+0xda3>
  40e27b:	mov    BYTE PTR [r11],0x2d
  40e27f:	lea    r10,[r11+0x1]
  40e283:	mov    BYTE PTR [r10],0x0
  40e287:	sub    r10,0x1
  40e28b:	nop    DWORD PTR [rax+rax*1+0x0]
  40e290:	cmp    r9,r10
  40e293:	jae    40e508 <__swc_fn_ff58629f_000151_6203dca2+0x1028>
  40e299:	mov    al,BYTE PTR [r10]
  40e29c:	mov    dl,BYTE PTR [r9]
  40e29f:	mov    BYTE PTR [r10],dl
  40e2a2:	sub    r10,0x1
  40e2a6:	mov    BYTE PTR [r9],al
  40e2a9:	inc    r9
  40e2ac:	jmp    40e290 <__swc_fn_ff58629f_000151_6203dca2+0xdb0>
  40e2ae:	vcvttsd2si rdx,xmm0
  40e2b3:	mov    r8,rdx
  40e2b6:	vxorpd xmm1,xmm1,xmm1
  40e2ba:	vcvtsi2sd xmm1,xmm1,rdx
  40e2bf:	vsubsd xmm1,xmm0,xmm1
  40e2c3:	mov    r9d,0x8
  40e2c9:	vxorpd xmm2,xmm2,xmm2
  40e2cd:	vcomisd xmm2,xmm1
  40e2d1:	ja     40e2de <__swc_fn_ff58629f_000151_6203dca2+0xdfe>
  40e2d3:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40e2dc:	jmp    40e2ef <__swc_fn_ff58629f_000151_6203dca2+0xe0f>
  40e2de:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x433a]        # 412620 <__swc_rdata_base_ff58629f+0x510>
  40e2e6:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40e2ef:	test   r9d,r9d
  40e2f2:	je     40e309 <__swc_fn_ff58629f_000151_6203dca2+0xe29>
  40e2f4:	cs nop WORD PTR [rax+rax*1+0x0]
  40e2fe:	xchg   ax,ax
  40e300:	vmulsd xmm1,xmm1,xmm6
  40e304:	dec    r9d
  40e307:	jne    40e300 <__swc_fn_ff58629f_000151_6203dca2+0xe20>
  40e309:	vcvttsd2si r9,xmm1
  40e30e:	mov    r10,r9
  40e311:	vxorpd xmm2,xmm2,xmm2
  40e315:	vcvtsi2sd xmm2,xmm2,r9
  40e31a:	vsubsd xmm1,xmm1,xmm2
  40e31e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  40e327:	vcomisd xmm1,xmm6
  40e32b:	lea    r9,[r9+0x1]
  40e32f:	cmova  r10,r9
  40e333:	cmp    r10,0x5f5e100
  40e33a:	jne    40e353 <__swc_fn_ff58629f_000151_6203dca2+0xe73>
  40e33c:	lea    r8,[rdx-0x1]
  40e340:	vxorpd xmm1,xmm1,xmm1
  40e344:	vcomisd xmm1,xmm0
  40e348:	lea    rdx,[rdx+0x1]
  40e34c:	cmovbe r8,rdx
  40e350:	xor    r10d,r10d
  40e353:	mov    r9,rcx
  40e356:	test   r8,r8
  40e359:	jne    40e379 <__swc_fn_ff58629f_000151_6203dca2+0xe99>
  40e35b:	vxorpd xmm1,xmm1,xmm1
  40e35f:	vcomisd xmm1,xmm0
  40e363:	jbe    40e36c <__swc_fn_ff58629f_000151_6203dca2+0xe8c>
  40e365:	mov    BYTE PTR [rcx],0x2d
  40e368:	lea    r9,[rcx+0x1]
  40e36c:	mov    BYTE PTR [r9],0x30
  40e370:	add    r9,0x1
  40e374:	jmp    40e40b <__swc_fn_ff58629f_000151_6203dca2+0xf2b>
  40e379:	mov    r9,rcx
  40e37c:	mov    rdx,r8
  40e37f:	nop
  40e380:	mov    r11,rdx
  40e383:	movabs rdx,0x6666666666666667
  40e38d:	mov    r15,rax
  40e390:	mov    rax,r11
  40e393:	imul   rdx
  40e396:	mov    r12,rdx
  40e399:	mov    rax,r15
  40e39c:	sar    r12,0x2
  40e3a0:	mov    rdx,r12
  40e3a3:	shr    rdx,0x3f
  40e3a7:	add    r12,rdx
  40e3aa:	mov    rdx,r12
  40e3ad:	imul   r13,r12,0xa
  40e3b1:	sub    r11,r13
  40e3b4:	mov    r13,QWORD PTR [rip+0x4255]        # 412610 <__swc_rdata_base_ff58629f+0x500>
  40e3bb:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40e3c0:	mov    BYTE PTR [r9],r11b
  40e3c3:	lea    r11,[r9+0x1]
  40e3c7:	mov    r9,r11
  40e3ca:	test   r12,r12
  40e3cd:	jne    40e380 <__swc_fn_ff58629f_000151_6203dca2+0xea0>
  40e3cf:	test   r8,r8
  40e3d2:	jge    40e3dc <__swc_fn_ff58629f_000151_6203dca2+0xefc>
  40e3d4:	mov    BYTE PTR [r11],0x2d
  40e3d8:	lea    r9,[r11+0x1]
  40e3dc:	mov    rdx,r9
  40e3df:	mov    BYTE PTR [r9],0x0
  40e3e3:	sub    r9,0x1
  40e3e7:	mov    r8,rcx
  40e3ea:	cmp    r8,r9
  40e3ed:	jae    40e408 <__swc_fn_ff58629f_000151_6203dca2+0xf28>
  40e3ef:	nop
  40e3f0:	mov    r11b,BYTE PTR [r9]
  40e3f3:	mov    r12b,BYTE PTR [r8]
  40e3f6:	mov    BYTE PTR [r9],r12b
  40e3f9:	sub    r9,0x1
  40e3fd:	mov    BYTE PTR [r8],r11b
  40e400:	inc    r8
  40e403:	cmp    r8,r9
  40e406:	jb     40e3f0 <__swc_fn_ff58629f_000151_6203dca2+0xf10>
  40e408:	mov    r9,rdx
  40e40b:	mov    BYTE PTR [r9],0x2e
  40e40f:	add    r9,0x1
  40e413:	xor    r8d,r8d
  40e416:	test   r10,r10
  40e419:	je     40e45f <__swc_fn_ff58629f_000151_6203dca2+0xf7f>
  40e41b:	mov    r11d,0x989680
  40e421:	cmp    r10,r11
  40e424:	jge    40e45f <__swc_fn_ff58629f_000151_6203dca2+0xf7f>
  40e426:	cs nop WORD PTR [rax+rax*1+0x0]
  40e430:	inc    r8d
  40e433:	movabs rdx,0x6666666666666667
  40e43d:	mov    r15,rax
  40e440:	mov    rax,r11
  40e443:	imul   rdx
  40e446:	mov    r11,rdx
  40e449:	mov    rax,r15
  40e44c:	sar    r11,0x2
  40e450:	mov    rdx,r11
  40e453:	shr    rdx,0x3f
  40e457:	add    r11,rdx
  40e45a:	cmp    r10,r11
  40e45d:	jl     40e430 <__swc_fn_ff58629f_000151_6203dca2+0xf50>
  40e45f:	test   r8d,r8d
  40e462:	je     40e47d <__swc_fn_ff58629f_000151_6203dca2+0xf9d>
  40e464:	cs nop WORD PTR [rax+rax*1+0x0]
  40e46e:	xchg   ax,ax
  40e470:	mov    BYTE PTR [r9],0x30
  40e474:	add    r9,0x1
  40e478:	dec    r8d
  40e47b:	jne    40e470 <__swc_fn_ff58629f_000151_6203dca2+0xf90>
  40e47d:	mov    r8,r9
  40e480:	mov    rdx,r10
  40e483:	cs nop WORD PTR [rax+rax*1+0x0]
  40e48d:	nop    DWORD PTR [rax]
  40e490:	mov    r11,rdx
  40e493:	movabs rdx,0x6666666666666667
  40e49d:	mov    rax,r11
  40e4a0:	imul   rdx
  40e4a3:	sar    rdx,0x2
  40e4a7:	mov    r12,rdx
  40e4aa:	shr    rdx,0x3f
  40e4ae:	add    r12,rdx
  40e4b1:	mov    rdx,r12
  40e4b4:	imul   r13,r12,0xa
  40e4b8:	sub    r11,r13
  40e4bb:	mov    r13,QWORD PTR [rip+0x414e]        # 412610 <__swc_rdata_base_ff58629f+0x500>
  40e4c2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40e4c7:	mov    BYTE PTR [r8],r11b
  40e4ca:	lea    r11,[r8+0x1]
  40e4ce:	mov    r8,r11
  40e4d1:	test   r12,r12
  40e4d4:	jne    40e490 <__swc_fn_ff58629f_000151_6203dca2+0xfb0>
  40e4d6:	test   r10,r10
  40e4d9:	jge    40e4e3 <__swc_fn_ff58629f_000151_6203dca2+0x1003>
  40e4db:	mov    BYTE PTR [r11],0x2d
  40e4df:	lea    r8,[r11+0x1]
  40e4e3:	mov    BYTE PTR [r8],0x0
  40e4e7:	sub    r8,0x1
  40e4eb:	cmp    r9,r8
  40e4ee:	jae    40e508 <__swc_fn_ff58629f_000151_6203dca2+0x1028>
  40e4f0:	mov    al,BYTE PTR [r8]
  40e4f3:	mov    dl,BYTE PTR [r9]
  40e4f6:	mov    BYTE PTR [r8],dl
  40e4f9:	sub    r8,0x1
  40e4fd:	mov    BYTE PTR [r9],al
  40e500:	inc    r9
  40e503:	cmp    r9,r8
  40e506:	jb     40e4f0 <__swc_fn_ff58629f_000151_6203dca2+0x1010>
  40e508:	xor    eax,eax
  40e50a:	test   rcx,rcx
  40e50d:	je     40e530 <__swc_fn_ff58629f_000151_6203dca2+0x1050>
  40e50f:	mov    rdx,rcx
  40e512:	mov    r8b,BYTE PTR [rdx]
  40e515:	test   r8b,r8b
  40e518:	je     40e530 <__swc_fn_ff58629f_000151_6203dca2+0x1050>
  40e51a:	nop    WORD PTR [rax+rax*1+0x0]
  40e520:	add    rdx,0x1
  40e524:	add    rax,0x1
  40e528:	mov    r8b,BYTE PTR [rdx]
  40e52b:	test   r8b,r8b
  40e52e:	jne    40e520 <__swc_fn_ff58629f_000151_6203dca2+0x1040>
  40e530:	mov    QWORD PTR [rsp+0x3f8],rcx
  40e538:	mov    QWORD PTR [rsp+0x400],rax
  40e540:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  40e549:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  40e552:	lea    rcx,[rsp+0x408]
  40e55a:	call   40cc70 <__swc_fn_ff58629f_000121_2648f149>
  40e55f:	jmp    40e5a5 <__swc_fn_ff58629f_000151_6203dca2+0x10c5>
  40e561:	mov    rcx,rdx
  40e564:	call   40cc70 <__swc_fn_ff58629f_000121_2648f149>
  40e569:	jmp    40e5a5 <__swc_fn_ff58629f_000151_6203dca2+0x10c5>
  40e56b:	mov    al,BYTE PTR [rdx]
  40e56d:	test   al,al
  40e56f:	je     40e57a <__swc_fn_ff58629f_000151_6203dca2+0x109a>
  40e571:	lea    rax,[rip+0x40b8]        # 412630 <__swc_rdata_base_ff58629f+0x520>
  40e578:	jmp    40e581 <__swc_fn_ff58629f_000151_6203dca2+0x10a1>
  40e57a:	lea    rax,[rip+0x40bf]        # 412640 <__swc_rdata_base_ff58629f+0x530>
  40e581:	mov    rcx,rax
  40e584:	call   40cc70 <__swc_fn_ff58629f_000121_2648f149>
  40e589:	jmp    40e5a5 <__swc_fn_ff58629f_000151_6203dca2+0x10c5>
  40e58b:	lea    rcx,[rip+0x40be]        # 412650 <__swc_rdata_base_ff58629f+0x540>
  40e592:	call   40cc70 <__swc_fn_ff58629f_000121_2648f149>
  40e597:	jmp    40e5a5 <__swc_fn_ff58629f_000151_6203dca2+0x10c5>
  40e599:	lea    rcx,[rip+0x40b0]        # 412650 <__swc_rdata_base_ff58629f+0x540>
  40e5a0:	call   40cc70 <__swc_fn_ff58629f_000121_2648f149>
  40e5a5:	add    rdi,0x1
  40e5a9:	sub    rsi,0x1
  40e5ad:	vmovups xmm0,xmm12
  40e5b2:	vmovsd xmm6,QWORD PTR [rip+0x40a6]        # 412660 <__swc_rdata_base_ff58629f+0x550>
  40e5ba:	test   rsi,rsi
  40e5bd:	jne    40d5f0 <__swc_fn_ff58629f_000151_6203dca2+0x110>
  40e5c3:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  40e5cc:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  40e5d5:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  40e5de:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  40e5e7:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  40e5f0:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  40e5f9:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  40e602:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  40e60b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  40e614:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  40e61d:	add    rsp,0x4e8
  40e624:	pop    r15
  40e626:	pop    r13
  40e628:	pop    r12
  40e62a:	pop    rdi
  40e62b:	pop    rsi
  40e62c:	pop    rbx
  40e62d:	ret
	...

000000000040e630 <__swc_fn_ff58629f_000154_86f1d437>:
  40e630:	vxorps xmm0,xmm0,xmm0
  40e634:	vmovups XMMWORD PTR [rcx],xmm0
  40e638:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e63d:	ret
	...

000000000040e640 <__swc_fn_ff58629f_000157_86f1d437>:
  40e640:	vxorps xmm0,xmm0,xmm0
  40e644:	vmovups XMMWORD PTR [rcx],xmm0
  40e648:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e64d:	vxorps xmm0,xmm0,xmm0
  40e651:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e656:	vmovups xmm0,XMMWORD PTR [rip+0x4112]        # 412770 <__swc_rdata_base_ff58629f+0x660>
  40e65e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e663:	vxorps xmm0,xmm0,xmm0
  40e667:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40e66c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40e671:	vxorps xmm0,xmm0,xmm0
  40e675:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40e67a:	mov    QWORD PTR [rcx+0x70],0x0
  40e682:	ret
	...

000000000040e690 <__swc_fn_ff58629f_000160_86f1d437>:
  40e690:	vxorps xmm0,xmm0,xmm0
  40e694:	vmovups XMMWORD PTR [rcx],xmm0
  40e698:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e69d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e6a2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e6a7:	ret
	...

000000000040e6b0 <__swc_fn_ff58629f_000163_e36363a8>:
  40e6b0:	push   rsi
  40e6b1:	push   rdi
  40e6b2:	sub    rsp,0x8
  40e6b6:	mov    rsi,rcx
  40e6b9:	mov    rdi,QWORD PTR [rsi+0x50]
  40e6bd:	test   rdi,rdi
  40e6c0:	je     40e6c7 <__swc_fn_ff58629f_000163_e36363a8+0x17>
  40e6c2:	mov    rcx,rsi
  40e6c5:	call   rdi
  40e6c7:	mov    QWORD PTR [rsi+0x20],0x0
  40e6cf:	mov    rax,QWORD PTR [rsi+0x30]
  40e6d3:	test   rax,rax
  40e6d6:	je     40e704 <__swc_fn_ff58629f_000163_e36363a8+0x54>
  40e6d8:	nop    DWORD PTR [rax+rax*1+0x0]
  40e6e0:	mov    rdi,QWORD PTR [rax+0x8]
  40e6e4:	mov    rcx,rsi
  40e6e7:	mov    rdx,QWORD PTR [rax+0x10]
  40e6eb:	mov    rax,QWORD PTR [rax+0x18]
  40e6ef:	mov    r8,rax
  40e6f2:	call   4118b0 <__swc_fn_ff58629f_000161_47b270e1>
  40e6f7:	mov    QWORD PTR [rsi+0x30],rdi
  40e6fb:	mov    rax,QWORD PTR [rsi+0x30]
  40e6ff:	test   rax,rax
  40e702:	jne    40e6e0 <__swc_fn_ff58629f_000163_e36363a8+0x30>
  40e704:	mov    QWORD PTR [rsi+0x38],0x0
  40e70c:	add    rsp,0x8
  40e710:	pop    rdi
  40e711:	pop    rsi
  40e712:	ret
	...

000000000040e720 <__swc_fn_ff58629f_000166_016ee66a>:
  40e720:	push   rbx
  40e721:	push   rsi
  40e722:	push   rdi
  40e723:	push   r12
  40e725:	sub    rsp,0x188
  40e72c:	mov    rbx,rcx
  40e72f:	lea    rsi,[rip+0x17652]        # 425d88 <__swc_bss_base_ff58629f+0x2d48>
  40e736:	mov    rcx,rsi
  40e739:	call   4112c0 <__swc_fn_ff58629f_000140_86bb0f90>
  40e73e:	mov    rax,QWORD PTR [rip+0x1764b]        # 425d90 <__swc_bss_base_ff58629f+0x2d50>
  40e745:	mov    rdi,rax
  40e748:	test   rdi,rdi
  40e74b:	je     40e779 <__swc_fn_ff58629f_000166_016ee66a+0x59>
  40e74d:	nop    DWORD PTR [rax]
  40e750:	cmp    QWORD PTR [rdi+0x8],rbx
  40e754:	jne    40e76e <__swc_fn_ff58629f_000166_016ee66a+0x4e>
  40e756:	mov    rcx,rsi
  40e759:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40e75e:	mov    rax,rdi
  40e761:	add    rsp,0x188
  40e768:	pop    r12
  40e76a:	pop    rdi
  40e76b:	pop    rsi
  40e76c:	pop    rbx
  40e76d:	ret
  40e76e:	mov    rax,QWORD PTR [rdi]
  40e771:	mov    rdi,rax
  40e774:	test   rax,rax
  40e777:	jne    40e750 <__swc_fn_ff58629f_000166_016ee66a+0x30>
  40e779:	call   409ec0 <__swc_fn_ff58629f_000144_d299b428>
  40e77e:	mov    rdi,rax
  40e781:	test   rax,rax
  40e784:	jne    40e79d <__swc_fn_ff58629f_000166_016ee66a+0x7d>
  40e786:	mov    rcx,rsi
  40e789:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40e78e:	xor    eax,eax
  40e790:	add    rsp,0x188
  40e797:	pop    r12
  40e799:	pop    rdi
  40e79a:	pop    rsi
  40e79b:	pop    rbx
  40e79c:	ret
  40e79d:	lea    rax,[rsp+0x18]
  40e7a2:	mov    QWORD PTR [rax+0x10],0x0
  40e7aa:	mov    QWORD PTR [rax+0x18],0x0
  40e7b2:	mov    DWORD PTR [rax+0x20],0x0
  40e7b9:	mov    BYTE PTR [rax+0x24],0x0
  40e7bd:	mov    rax,QWORD PTR [rip+0x175cc]        # 425d90 <__swc_bss_base_ff58629f+0x2d50>
  40e7c4:	mov    QWORD PTR [rsp+0x18],rax
  40e7c9:	mov    QWORD PTR [rsp+0x20],rbx
  40e7ce:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e7d4:	vmovups XMMWORD PTR [rdi],xmm0
  40e7d8:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e7de:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  40e7e3:	mov    rax,QWORD PTR [rsp+0x38]
  40e7e8:	mov    QWORD PTR [rdi+0x20],rax
  40e7ec:	mov    QWORD PTR [rip+0x1759d],rdi        # 425d90 <__swc_bss_base_ff58629f+0x2d50>
  40e7f3:	lea    rax,[rsp+0x40]
  40e7f8:	mov    QWORD PTR [rax],0x0
  40e7ff:	mov    rcx,rbx
  40e802:	mov    rdx,rax
  40e805:	call   4113a0 <__swc_fn_ff58629f_000146_1534de9a>
  40e80a:	mov    rbx,rax
  40e80d:	test   rax,rax
  40e810:	jne    40e82a <__swc_fn_ff58629f_000166_016ee66a+0x10a>
  40e812:	mov    rcx,rsi
  40e815:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40e81a:	mov    rax,rdi
  40e81d:	add    rsp,0x188
  40e824:	pop    r12
  40e826:	pop    rdi
  40e827:	pop    rsi
  40e828:	pop    rbx
  40e829:	ret
  40e82a:	lea    r12,[rsp+0x50]
  40e82f:	mov    QWORD PTR [r12],0x0
  40e837:	mov    rcx,rbx
  40e83a:	mov    rdx,QWORD PTR [rsp+0x40]
  40e83f:	mov    r8,r12
  40e842:	call   409f70 <__swc_fn_ff58629f_000147_162f363d>
  40e847:	test   rax,rax
  40e84a:	jne    40e864 <__swc_fn_ff58629f_000166_016ee66a+0x144>
  40e84c:	mov    rcx,rsi
  40e84f:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40e854:	mov    rax,rdi
  40e857:	add    rsp,0x188
  40e85e:	pop    r12
  40e860:	pop    rdi
  40e861:	pop    rsi
  40e862:	pop    rbx
  40e863:	ret
  40e864:	cmp    QWORD PTR [r12],0x10
  40e869:	jb     40e96c <__swc_fn_ff58629f_000166_016ee66a+0x24c>
  40e86f:	mov    ecx,DWORD PTR [rax]
  40e871:	cmp    ecx,0x42445753
  40e877:	jne    40e96c <__swc_fn_ff58629f_000166_016ee66a+0x24c>
  40e87d:	mov    ecx,DWORD PTR [rax+0x4]
  40e880:	cmp    ecx,0x1
  40e883:	jne    40e96c <__swc_fn_ff58629f_000166_016ee66a+0x24c>
  40e889:	mov    ecx,DWORD PTR [rax+0x8]
  40e88c:	mov    edx,DWORD PTR [rax+0xc]
  40e88f:	imul   r8,rcx,0x14
  40e893:	mov    r9,QWORD PTR [rsp+0x50]
  40e898:	sub    r9,0x10
  40e89c:	cmp    r8,r9
  40e89f:	ja     40e96c <__swc_fn_ff58629f_000166_016ee66a+0x24c>
  40e8a5:	lea    r8,[r8+0x10]
  40e8a9:	cmp    rdx,r8
  40e8ac:	jb     40e96c <__swc_fn_ff58629f_000166_016ee66a+0x24c>
  40e8b2:	mov    r8,QWORD PTR [rsp+0x50]
  40e8b7:	cmp    rdx,r8
  40e8ba:	ja     40e96c <__swc_fn_ff58629f_000166_016ee66a+0x24c>
  40e8c0:	xor    r8d,r8d
  40e8c3:	test   rcx,rcx
  40e8c6:	jbe    40e992 <__swc_fn_ff58629f_000166_016ee66a+0x272>
  40e8cc:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  40e8d2:	cs nop WORD PTR [rax+rax*1+0x0]
  40e8dc:	nop    DWORD PTR [rax+0x0]
  40e8e0:	imul   r9,r8,0x14
  40e8e4:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  40e8e9:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  40e8ee:	add    r10,r11
  40e8f1:	movabs r11,0x100000000
  40e8fb:	cmp    r10,r11
  40e8fe:	ja     40e96c <__swc_fn_ff58629f_000166_016ee66a+0x24c>
  40e900:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  40e905:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  40e90a:	test   r10d,r10d
  40e90d:	setne  r11b
  40e911:	je     40e92b <__swc_fn_ff58629f_000166_016ee66a+0x20b>
  40e913:	cmp    r10d,edx
  40e916:	setb   r11b
  40e91a:	jb     40e92b <__swc_fn_ff58629f_000166_016ee66a+0x20b>
  40e91c:	vmovq  r11,xmm1
  40e921:	cmp    r10,r11
  40e924:	setae  r10b
  40e928:	mov    r11b,r10b
  40e92b:	mov    r10,r11
  40e92e:	test   r11b,r11b
  40e931:	jne    40e958 <__swc_fn_ff58629f_000166_016ee66a+0x238>
  40e933:	test   r9d,r9d
  40e936:	setne  r10b
  40e93a:	je     40e958 <__swc_fn_ff58629f_000166_016ee66a+0x238>
  40e93c:	cmp    r9d,edx
  40e93f:	setb   r10b
  40e943:	jb     40e958 <__swc_fn_ff58629f_000166_016ee66a+0x238>
  40e945:	vmovq  r10,xmm1
  40e94a:	cmp    r9,r10
  40e94d:	setae  r9b
  40e951:	movzx  r9d,r9b
  40e955:	mov    r10b,r9b
  40e958:	test   r10b,r10b
  40e95b:	jne    40e96c <__swc_fn_ff58629f_000166_016ee66a+0x24c>
  40e95d:	add    r8,0x1
  40e961:	cmp    r8,rcx
  40e964:	jb     40e8e0 <__swc_fn_ff58629f_000166_016ee66a+0x1c0>
  40e96a:	jmp    40e992 <__swc_fn_ff58629f_000166_016ee66a+0x272>
  40e96c:	xor    ecx,ecx
  40e96e:	cmp    rax,rbx
  40e971:	cmovne rcx,rax
  40e975:	call   40d430 <__swc_fn_ff58629f_000148_d7edc04f>
  40e97a:	mov    rcx,rsi
  40e97d:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40e982:	mov    rax,rdi
  40e985:	add    rsp,0x188
  40e98c:	pop    r12
  40e98e:	pop    rdi
  40e98f:	pop    rsi
  40e990:	pop    rbx
  40e991:	ret
  40e992:	mov    QWORD PTR [rdi+0x10],rax
  40e996:	mov    rcx,QWORD PTR [rsp+0x50]
  40e99b:	mov    QWORD PTR [rdi+0x18],rcx
  40e99f:	mov    eax,DWORD PTR [rax+0x8]
  40e9a2:	mov    DWORD PTR [rdi+0x20],eax
  40e9a5:	rex mov BYTE PTR [rdi+0x24],0x1
  40e9aa:	mov    rcx,rsi
  40e9ad:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40e9b2:	mov    rax,rdi
  40e9b5:	add    rsp,0x188
  40e9bc:	pop    r12
  40e9be:	pop    rdi
  40e9bf:	pop    rsi
  40e9c0:	pop    rbx
  40e9c1:	ret
	...

000000000040e9d0 <__swc_fn_ff58629f_000169_3459066f>:
  40e9d0:	push   rsi
  40e9d1:	push   rdi
  40e9d2:	push   r12
  40e9d4:	mov    rsi,rdx
  40e9d7:	mov    rdi,rcx
  40e9da:	mov    rcx,QWORD PTR [rip+0x1465f]        # 423040 <__swc_bss_base_ff58629f>
  40e9e1:	test   rcx,rcx
  40e9e4:	jne    40e9f6 <__swc_fn_ff58629f_000169_3459066f+0x26>
  40e9e6:	call   411bc0 <__swc_fn_ff58629f_000170_994c8876>
  40e9eb:	lea    rcx,[rax+0x1]
  40e9ef:	mov    QWORD PTR [rip+0x1464a],rcx        # 423040 <__swc_bss_base_ff58629f>
  40e9f6:	dec    rcx
  40e9f9:	call   40ea20 <__swc_fn_ff58629f_000172_360af05d>
  40e9fe:	mov    r12,QWORD PTR [rax+0xbe0]
  40ea05:	test   r12,r12
  40ea08:	setne  al
  40ea0b:	je     40ea16 <__swc_fn_ff58629f_000169_3459066f+0x46>
  40ea0d:	mov    rcx,rdi
  40ea10:	mov    rdx,rsi
  40ea13:	call   r12
  40ea16:	pop    r12
  40ea18:	pop    rdi
  40ea19:	pop    rsi
  40ea1a:	ret
  40ea1b:	add    BYTE PTR [rax],al
  40ea1d:	add    BYTE PTR [rax],al
	...

000000000040ea20 <__swc_fn_ff58629f_000172_360af05d>:
  40ea20:	push   r12
  40ea22:	push   rdi
  40ea23:	push   rsi
  40ea24:	sub    rsp,0xd0
  40ea2b:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40ea31:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40ea37:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40ea3d:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40ea43:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40ea49:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40ea4f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40ea58:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40ea61:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40ea6a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40ea73:	mov    r12,rcx
  40ea76:	mov    edi,ecx
  40ea78:	xor    eax,eax
  40ea7a:	call   407000 <pthread_getspecific@plt>
  40ea7f:	test   rax,rax
  40ea82:	je     40ea86 <__swc_fn_ff58629f_000172_360af05d+0x66>
  40ea84:	jmp    40ea8e <__swc_fn_ff58629f_000172_360af05d+0x6e>
  40ea86:	mov    rcx,r12
  40ea89:	call   411c20 <__swc_fn_ff58629f_000173_cbeff767>
  40ea8e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40ea94:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40ea9a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40eaa0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40eaa6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40eaac:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40eab2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40eabb:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40eac4:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40eacd:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40ead6:	add    rsp,0xd0
  40eadd:	pop    rsi
  40eade:	pop    rdi
  40eadf:	pop    r12
  40eae1:	ret
	...

000000000040eaf0 <__swc_fn_ff58629f_000175_5eac0ab4>:
  40eaf0:	push   rsi
  40eaf1:	sub    rsp,0x30
  40eaf5:	lea    rsi,[rip+0x172a4]        # 425da0 <__swc_bss_base_ff58629f+0x2d60>
  40eafc:	mov    rax,QWORD PTR [rsi]
  40eaff:	test   rax,rax
  40eb02:	je     40eb0a <__swc_fn_ff58629f_000175_5eac0ab4+0x1a>
  40eb04:	add    rsp,0x30
  40eb08:	pop    rsi
  40eb09:	ret
  40eb0a:	mov    ecx,0x3
  40eb0f:	mov    edx,0x10
  40eb14:	call   40c590 <__swc_fn_ff58629f_000112_6814119b>
  40eb19:	test   rax,rax
  40eb1c:	jne    40eb2d <__swc_fn_ff58629f_000175_5eac0ab4+0x3d>
  40eb1e:	mov    QWORD PTR [rsp+0x18],rax
  40eb23:	call   409a10 <__swc_fn_ff58629f_000123_be2e2f68>
  40eb28:	mov    rax,QWORD PTR [rsp+0x18]
  40eb2d:	mov    rcx,rax
  40eb30:	xchg   QWORD PTR [rsi],rcx
  40eb33:	add    rsp,0x30
  40eb37:	pop    rsi
  40eb38:	ret
  40eb39:	add    BYTE PTR [rax],al
  40eb3b:	add    BYTE PTR [rax],al
  40eb3d:	add    BYTE PTR [rax],al
	...

000000000040eb40 <__swc_fn_ff58629f_000178_cf4ffedd>:
  40eb40:	push   rsi
  40eb41:	push   rdi
  40eb42:	sub    rsp,0x8
  40eb46:	mov    rsi,rdx
  40eb49:	mov    rdi,rcx
  40eb4c:	mov    rax,QWORD PTR [rsi+0x8]
  40eb50:	test   rax,rax
  40eb53:	je     40eb5d <__swc_fn_ff58629f_000178_cf4ffedd+0x1d>
  40eb55:	mov    rcx,QWORD PTR [rsi]
  40eb58:	mov    QWORD PTR [rax],rcx
  40eb5b:	jmp    40eb64 <__swc_fn_ff58629f_000178_cf4ffedd+0x24>
  40eb5d:	mov    rax,QWORD PTR [rsi]
  40eb60:	mov    QWORD PTR [rdi+0x8],rax
  40eb64:	mov    rax,QWORD PTR [rsi]
  40eb67:	test   rax,rax
  40eb6a:	je     40eb74 <__swc_fn_ff58629f_000178_cf4ffedd+0x34>
  40eb6c:	mov    rcx,QWORD PTR [rsi+0x8]
  40eb70:	mov    QWORD PTR [rax+0x8],rcx
  40eb74:	mov    rcx,rdi
  40eb77:	mov    rdx,QWORD PTR [rsi+0x10]
  40eb7b:	mov    r8,QWORD PTR [rsi+0x18]
  40eb7f:	mov    r9,0xffffffffffffffff
  40eb86:	call   40a5c0 <__swc_fn_ff58629f_000177_4de704de>
  40eb8b:	mov    QWORD PTR [rsi+0x18],0x0
  40eb93:	mov    rax,QWORD PTR [rdi+0x8]
  40eb97:	test   rax,rax
  40eb9a:	jne    40ebac <__swc_fn_ff58629f_000178_cf4ffedd+0x6c>
  40eb9c:	call   40eaf0 <__swc_fn_ff58629f_000175_5eac0ab4>
  40eba1:	xor    ecx,ecx
  40eba3:	mov    QWORD PTR [rax+0x8],rcx
  40eba7:	xor    ecx,ecx
  40eba9:	mov    QWORD PTR [rax],rcx
  40ebac:	add    rsp,0x8
  40ebb0:	pop    rdi
  40ebb1:	pop    rsi
  40ebb2:	ret
	...

000000000040ebc0 <__swc_fn_ff58629f_000002_1ca87929>:
  40ebc0:	push   rdi
  40ebc1:	push   rsi
  40ebc2:	sub    rsp,0xb8
  40ebc9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40ebcf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40ebd5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40ebdb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40ebe1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40ebe7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40ebed:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40ebf3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40ebfc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40ec05:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40ec0e:	vxorps xmm0,xmm0,xmm0
  40ec12:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ec18:	mov    edi,0x1
  40ec1d:	lea    rsi,[rsp+0x8]
  40ec22:	xor    eax,eax
  40ec24:	call   4071b0 <clock_gettime@plt>
  40ec29:	vxorpd xmm0,xmm0,xmm0
  40ec2d:	mov    rax,QWORD PTR [rsp+0x8]
  40ec32:	vcvtsi2sd xmm0,xmm0,rax
  40ec37:	vxorpd xmm1,xmm1,xmm1
  40ec3b:	mov    rax,QWORD PTR [rsp+0x10]
  40ec40:	vcvtsi2sd xmm1,xmm1,rax
  40ec45:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x34c3]        # 412110 <__swc_rdata_base_ff58629f>
  40ec4d:	vaddsd xmm0,xmm0,xmm1
  40ec51:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ec57:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40ec5d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40ec63:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ec69:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ec6f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ec75:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ec7b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ec84:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ec8d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ec96:	add    rsp,0xb8
  40ec9d:	pop    rsi
  40ec9e:	pop    rdi
  40ec9f:	ret

000000000040eca0 <__swc_fn_ff58629f_000005_9ee35b18>:
  40eca0:	vxorps xmm0,xmm0,xmm0
  40eca4:	vmovups XMMWORD PTR [rcx],xmm0
  40eca8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40ecad:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40ecb2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40ecb7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40ecbc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40ecc1:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40ecc6:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40eccb:	ret
  40eccc:	add    BYTE PTR [rax],al
	...

000000000040ecd0 <__swc_fn_ff58629f_000008_f7acedb0>:
  40ecd0:	push   rsi
  40ecd1:	mov    rsi,rdx
  40ecd4:	test   rdx,rdx
  40ecd7:	jne    40ece0 <__swc_fn_ff58629f_000008_f7acedb0+0x10>
  40ecd9:	mov    eax,0x1
  40ecde:	pop    rsi
  40ecdf:	ret
  40ece0:	mov    rdx,rsi
  40ece3:	call   410c60 <__swc_fn_ff58629f_000116_36905703>
  40ece8:	test   al,al
  40ecea:	jne    40ecf0 <__swc_fn_ff58629f_000008_f7acedb0+0x20>
  40ecec:	xor    eax,eax
  40ecee:	pop    rsi
  40ecef:	ret
  40ecf0:	lea    rcx,[rip+0x14359]        # 423050 <__swc_bss_base_ff58629f+0x10>
  40ecf7:	mov    rdx,QWORD PTR [rip+0x14352]        # 423050 <__swc_bss_base_ff58629f+0x10>
  40ecfe:	xchg   ax,ax
  40ed00:	lea    r8,[rdx+rsi*1]
  40ed04:	mov    rax,rdx
  40ed07:	lock cmpxchg QWORD PTR [rcx],r8
  40ed0c:	cmp    rax,rdx
  40ed0f:	je     40ed16 <__swc_fn_ff58629f_000008_f7acedb0+0x46>
  40ed11:	mov    rdx,rax
  40ed14:	jmp    40ed00 <__swc_fn_ff58629f_000008_f7acedb0+0x30>
  40ed16:	lea    rcx,[rip+0x1433b]        # 423058 <__swc_bss_base_ff58629f+0x18>
  40ed1d:	mov    rdx,QWORD PTR [rip+0x14334]        # 423058 <__swc_bss_base_ff58629f+0x18>
  40ed24:	cs nop WORD PTR [rax+rax*1+0x0]
  40ed2e:	xchg   ax,ax
  40ed30:	lea    r8,[rdx+0x1]
  40ed34:	mov    rax,rdx
  40ed37:	lock cmpxchg QWORD PTR [rcx],r8
  40ed3c:	cmp    rax,rdx
  40ed3f:	je     40ed46 <__swc_fn_ff58629f_000008_f7acedb0+0x76>
  40ed41:	mov    rdx,rax
  40ed44:	jmp    40ed30 <__swc_fn_ff58629f_000008_f7acedb0+0x60>
  40ed46:	mov    eax,0x1
  40ed4b:	pop    rsi
  40ed4c:	ret
  40ed4d:	add    BYTE PTR [rax],al
	...

000000000040ed50 <__swc_fn_ff58629f_000011_24a20786>:
  40ed50:	push   rbx
  40ed51:	push   rsi
  40ed52:	push   rdi
  40ed53:	push   r12
  40ed55:	sub    rsp,0x18
  40ed59:	mov    rbx,rcx
  40ed5c:	mov    rsi,rcx
  40ed5f:	and    rsi,0xffffffffffc00000
  40ed66:	movzx  eax,BYTE PTR [rbx+0x3a]
  40ed6a:	mov    ecx,DWORD PTR [rsi+0x28]
  40ed6d:	shrx   eax,eax,ecx
  40ed72:	lea    rdi,[rsp+0x8]
  40ed77:	mov    DWORD PTR [rsp+0x8],eax
  40ed7b:	mov    rcx,rsi
  40ed7e:	mov    rax,rdi
  40ed81:	mov    edx,DWORD PTR [rax]
  40ed83:	call   40aac0 <__swc_fn_ff58629f_000016_9dea5065>
  40ed88:	mov    r12,rax
  40ed8b:	mov    rcx,rsi
  40ed8e:	mov    edx,DWORD PTR [rdi]
  40ed90:	call   40ee80 <__swc_fn_ff58629f_000017_9afb7cfb>
  40ed95:	mov    rcx,r12
  40ed98:	mov    edx,DWORD PTR [rbx+0x3c]
  40ed9b:	add    rcx,rdx
  40ed9e:	cmp    rcx,rax
  40eda1:	jb     40edaf <__swc_fn_ff58629f_000011_24a20786+0x5f>
  40eda3:	xor    eax,eax
  40eda5:	add    rsp,0x18
  40eda9:	pop    r12
  40edab:	pop    rdi
  40edac:	pop    rsi
  40edad:	pop    rbx
  40edae:	ret
  40edaf:	mov    rdx,QWORD PTR [rbx+0x20]
  40edb3:	mov    r8d,DWORD PTR [rbx+0x2c]
  40edb7:	add    rdx,r8
  40edba:	lea    rsi,[rdx+0xffff]
  40edc1:	and    rsi,0xffffffffffff0000
  40edc8:	cmp    rax,rsi
  40edcb:	cmovbe rsi,rax
  40edcf:	mov    rax,rsi
  40edd2:	sub    rax,rcx
  40edd5:	mov    rdx,rax
  40edd8:	call   40ecd0 <__swc_fn_ff58629f_000008_f7acedb0>
  40eddd:	test   al,al
  40eddf:	jne    40eded <__swc_fn_ff58629f_000011_24a20786+0x9d>
  40ede1:	xor    eax,eax
  40ede3:	add    rsp,0x18
  40ede7:	pop    r12
  40ede9:	pop    rdi
  40edea:	pop    rsi
  40edeb:	pop    rbx
  40edec:	ret
  40eded:	sub    rsi,r12
  40edf0:	mov    DWORD PTR [rbx+0x3c],esi
  40edf3:	mov    ecx,DWORD PTR [rbx+0x2c]
  40edf6:	mov    rax,rsi
  40edf9:	xor    edx,edx
  40edfb:	div    rcx
  40edfe:	imul   rax,rcx
  40ee02:	add    r12,rax
  40ee05:	mov    QWORD PTR [rbx+0x18],r12
  40ee09:	mov    eax,0x1
  40ee0e:	add    rsp,0x18
  40ee12:	pop    r12
  40ee14:	pop    rdi
  40ee15:	pop    rsi
  40ee16:	pop    rbx
  40ee17:	ret
	...

000000000040ee20 <__swc_fn_ff58629f_000014_e4b0ddfc>:
  40ee20:	sub    rsp,0x8
  40ee24:	mov    rdx,rcx
  40ee27:	lea    r9,[rcx+0x60]
  40ee2b:	mov    rax,QWORD PTR [r9]
  40ee2e:	test   rax,rax
  40ee31:	jne    40ee38 <__swc_fn_ff58629f_000014_e4b0ddfc+0x18>
  40ee33:	add    rsp,0x8
  40ee37:	ret
  40ee38:	mov    rcx,rdx
  40ee3b:	call   407570 <__swc_fn_ff58629f_000012_c3647f66>
  40ee40:	xor    eax,eax
  40ee42:	xchg   QWORD PTR [r9],rax
  40ee45:	mov    r8,rax
  40ee48:	mov    rcx,rdx
  40ee4b:	call   40aab0 <__swc_fn_ff58629f_000013_861b8b62>
  40ee50:	xor    eax,eax
  40ee52:	test   r8,r8
  40ee55:	je     40ee76 <__swc_fn_ff58629f_000014_e4b0ddfc+0x56>
  40ee57:	nop    WORD PTR [rax+rax*1+0x0]
  40ee60:	mov    rcx,QWORD PTR [r8]
  40ee63:	mov    r9,QWORD PTR [rdx]
  40ee66:	mov    QWORD PTR [r8],r9
  40ee69:	mov    QWORD PTR [rdx],r8
  40ee6c:	mov    r8,rcx
  40ee6f:	inc    eax
  40ee71:	test   rcx,rcx
  40ee74:	jne    40ee60 <__swc_fn_ff58629f_000014_e4b0ddfc+0x40>
  40ee76:	sub    DWORD PTR [rdx+0x28],eax
  40ee79:	add    rsp,0x8
  40ee7d:	ret
	...

000000000040ee80 <__swc_fn_ff58629f_000017_9afb7cfb>:
  40ee80:	lea    eax,[rdx+0x1]
  40ee83:	mov    edx,DWORD PTR [rcx+0x28]
  40ee86:	shlx   eax,eax,edx
  40ee8b:	shl    rax,0x10
  40ee8f:	add    rax,rcx
  40ee92:	ret
	...

000000000040eea0 <__swc_fn_ff58629f_000020_adca76cf>:
  40eea0:	push   rbx
  40eea1:	push   rsi
  40eea2:	push   rdi
  40eea3:	push   r12
  40eea5:	push   r13
  40eea7:	push   r14
  40eea9:	push   r15
  40eeab:	sub    rsp,0x30
  40eeaf:	mov    rbx,rcx
  40eeb2:	lea    rsi,[rcx+0x48]
  40eeb6:	mov    QWORD PTR [rsp+0x18],rsi
  40eebb:	mov    rax,QWORD PTR [rsi]
  40eebe:	mov    rdi,rax
  40eec1:	lea    r12,[rsp+0x8]
  40eec6:	lea    r13,[rcx+0x40]
  40eeca:	nop    WORD PTR [rax+rax*1+0x0]
  40eed0:	test   rdi,rdi
  40eed3:	je     40f013 <__swc_fn_ff58629f_000020_adca76cf+0x173>
  40eed9:	xor    eax,eax
  40eedb:	tzcnt  rax,rdi
  40eee0:	mov    DWORD PTR [rsp+0x8],eax
  40eee4:	mov    r14d,0x1
  40eeea:	mov    ecx,eax
  40eeec:	shl    r14,cl
  40eeef:	andn   rdi,r14,rdi
  40eef4:	mov    rcx,QWORD PTR [r13+0x0]
  40eef8:	test   rcx,r14
  40eefb:	jne    40eed0 <__swc_fn_ff58629f_000020_adca76cf+0x30>
  40eefd:	mov    rdx,rcx
  40ef00:	or     rdx,r14
  40ef03:	mov    rax,rcx
  40ef06:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  40ef0c:	cmp    rax,rcx
  40ef0f:	je     40ef19 <__swc_fn_ff58629f_000020_adca76cf+0x79>
  40ef11:	mov    rax,QWORD PTR [rsi]
  40ef14:	mov    rdi,rax
  40ef17:	jmp    40eed0 <__swc_fn_ff58629f_000020_adca76cf+0x30>
  40ef19:	mov    rcx,rbx
  40ef1c:	mov    rdx,r14
  40ef1f:	call   40ac20 <__swc_fn_ff58629f_000022_fd2b165c>
  40ef24:	test   al,al
  40ef26:	je     40effe <__swc_fn_ff58629f_000020_adca76cf+0x15e>
  40ef2c:	mov    eax,DWORD PTR [r12]
  40ef30:	shl    rax,0x4
  40ef34:	lea    r15,[rbx+rax*8+0x80]
  40ef3c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  40ef44:	lea    rcx,[rip+0x14115]        # 423060 <__swc_bss_base_ff58629f+0x20>
  40ef4b:	mov    rdx,QWORD PTR [rip+0x1410e]        # 423060 <__swc_bss_base_ff58629f+0x20>
  40ef52:	cs nop WORD PTR [rax+rax*1+0x0]
  40ef5c:	nop    DWORD PTR [rax+0x0]
  40ef60:	mov    r8,rdx
  40ef63:	sub    r8,rsi
  40ef66:	mov    rax,rdx
  40ef69:	lock cmpxchg QWORD PTR [rcx],r8
  40ef6e:	cmp    rax,rdx
  40ef71:	je     40ef78 <__swc_fn_ff58629f_000020_adca76cf+0xd8>
  40ef73:	mov    rdx,rax
  40ef76:	jmp    40ef60 <__swc_fn_ff58629f_000020_adca76cf+0xc0>
  40ef78:	mov    rcx,rbx
  40ef7b:	mov    rax,r12
  40ef7e:	mov    edx,DWORD PTR [rax]
  40ef80:	call   40aac0 <__swc_fn_ff58629f_000016_9dea5065>
  40ef85:	test   rsi,rsi
  40ef88:	je     40eff6 <__swc_fn_ff58629f_000020_adca76cf+0x156>
  40ef8e:	mov    rcx,rax
  40ef91:	mov    rdx,rsi
  40ef94:	call   4097e0 <__swc_fn_ff58629f_000117_e9fc0224>
  40ef99:	lea    rcx,[rip+0x140b0]        # 423050 <__swc_bss_base_ff58629f+0x10>
  40efa0:	mov    rdx,QWORD PTR [rip+0x140a9]        # 423050 <__swc_bss_base_ff58629f+0x10>
  40efa7:	nop    WORD PTR [rax+rax*1+0x0]
  40efb0:	mov    r8,rdx
  40efb3:	sub    r8,rsi
  40efb6:	mov    rax,rdx
  40efb9:	lock cmpxchg QWORD PTR [rcx],r8
  40efbe:	cmp    rax,rdx
  40efc1:	je     40efc8 <__swc_fn_ff58629f_000020_adca76cf+0x128>
  40efc3:	mov    rdx,rax
  40efc6:	jmp    40efb0 <__swc_fn_ff58629f_000020_adca76cf+0x110>
  40efc8:	lea    rcx,[rip+0x14099]        # 423068 <__swc_bss_base_ff58629f+0x28>
  40efcf:	mov    rdx,QWORD PTR [rip+0x14092]        # 423068 <__swc_bss_base_ff58629f+0x28>
  40efd6:	cs nop WORD PTR [rax+rax*1+0x0]
  40efe0:	lea    r8,[rdx+0x1]
  40efe4:	mov    rax,rdx
  40efe7:	lock cmpxchg QWORD PTR [rcx],r8
  40efec:	cmp    rax,rdx
  40efef:	je     40eff6 <__swc_fn_ff58629f_000020_adca76cf+0x156>
  40eff1:	mov    rdx,rax
  40eff4:	jmp    40efe0 <__swc_fn_ff58629f_000020_adca76cf+0x140>
  40eff6:	mov    DWORD PTR [r15+0x3c],0x0
  40effe:	mov    rcx,rbx
  40f001:	mov    rdx,r14
  40f004:	call   40f030 <__swc_fn_ff58629f_000023_c8f5f27c>
  40f009:	mov    rsi,QWORD PTR [rsp+0x18]
  40f00e:	jmp    40eed0 <__swc_fn_ff58629f_000020_adca76cf+0x30>
  40f013:	add    rsp,0x30
  40f017:	pop    r15
  40f019:	pop    r14
  40f01b:	pop    r13
  40f01d:	pop    r12
  40f01f:	pop    rdi
  40f020:	pop    rsi
  40f021:	pop    rbx
  40f022:	ret
	...

000000000040f030 <__swc_fn_ff58629f_000023_c8f5f27c>:
  40f030:	mov    r8,QWORD PTR [rcx+0x40]
  40f034:	cs nop WORD PTR [rax+rax*1+0x0]
  40f03e:	xchg   ax,ax
  40f040:	mov    rax,rdx
  40f043:	not    rax
  40f046:	mov    r9,r8
  40f049:	and    r9,rax
  40f04c:	mov    rax,r8
  40f04f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  40f055:	cmp    rax,r8
  40f058:	jne    40f05b <__swc_fn_ff58629f_000023_c8f5f27c+0x2b>
  40f05a:	ret
  40f05b:	mov    r8,rax
  40f05e:	jmp    40f040 <__swc_fn_ff58629f_000023_c8f5f27c+0x10>

000000000040f060 <__swc_fn_ff58629f_000026_aa910677>:
  40f060:	push   rsi
  40f061:	push   rdi
  40f062:	sub    rsp,0x8
  40f066:	mov    rsi,rcx
  40f069:	call   40eea0 <__swc_fn_ff58629f_000020_adca76cf>
  40f06e:	lea    rdi,[rip+0x14183]        # 4231f8 <__swc_bss_base_ff58629f+0x1b8>
  40f075:	mov    rcx,rdi
  40f078:	call   4112c0 <__swc_fn_ff58629f_000140_86bb0f90>
  40f07d:	mov    QWORD PTR [rsi+0x8],0x0
  40f085:	mov    QWORD PTR [rsi+0x18],0x0
  40f08d:	mov    rax,QWORD PTR [rip+0x1416c]        # 423200 <__swc_bss_base_ff58629f+0x1c0>
  40f094:	mov    QWORD PTR [rsi+0x10],rax
  40f098:	mov    QWORD PTR [rip+0x14161],rsi        # 423200 <__swc_bss_base_ff58629f+0x1c0>
  40f09f:	mov    rcx,rdi
  40f0a2:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40f0a7:	add    rsp,0x8
  40f0ab:	pop    rdi
  40f0ac:	pop    rsi
  40f0ad:	ret
	...

000000000040f0b0 <__swc_fn_ff58629f_000029_9798fb47>:
  40f0b0:	vxorps xmm0,xmm0,xmm0
  40f0b4:	vmovups XMMWORD PTR [rcx],xmm0
  40f0b8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f0bd:	mov    QWORD PTR [rcx+0x20],0x0
  40f0c5:	ret
	...

000000000040f0d0 <__swc_fn_ff58629f_000032_9798fb47>:
  40f0d0:	vxorps xmm0,xmm0,xmm0
  40f0d4:	vmovups XMMWORD PTR [rcx],xmm0
  40f0d8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f0dd:	mov    QWORD PTR [rcx+0x20],0x0
  40f0e5:	ret
	...

000000000040f0f0 <__swc_fn_ff58629f_000035_9128bcf9>:
  40f0f0:	push   r12
  40f0f2:	mov    r12,rdi
  40f0f5:	test   rdi,rdi
  40f0f8:	jne    40f0fd <__swc_fn_ff58629f_000035_9128bcf9+0xd>
  40f0fa:	pop    r12
  40f0fc:	ret
  40f0fd:	lea    rax,[rip+0x11f04]        # 421008 <__swc_data_base_ff58629f+0x8>
  40f104:	mov    rax,QWORD PTR [rax]
  40f107:	cmp    rax,0xffffffffffffffff
  40f10b:	je     40f11a <__swc_fn_ff58629f_000035_9128bcf9+0x2a>
  40f10d:	mov    eax,eax
  40f10f:	mov    edi,eax
  40f111:	xor    eax,eax
  40f113:	call   407000 <pthread_getspecific@plt>
  40f118:	jmp    40f11c <__swc_fn_ff58629f_000035_9128bcf9+0x2c>
  40f11a:	xor    eax,eax
  40f11c:	cmp    rax,r12
  40f11f:	jne    40f128 <__swc_fn_ff58629f_000035_9128bcf9+0x38>
  40f121:	xor    ecx,ecx
  40f123:	call   40ade0 <__swc_fn_ff58629f_000037_92d9bbff>
  40f128:	mov    rdx,QWORD PTR [r12]
  40f12c:	test   rdx,rdx
  40f12f:	je     40f148 <__swc_fn_ff58629f_000035_9128bcf9+0x58>
  40f131:	mov    rcx,rdx
  40f134:	call   40f170 <__swc_fn_ff58629f_000041_eb6108f2>
  40f139:	test   al,al
  40f13b:	je     40f148 <__swc_fn_ff58629f_000035_9128bcf9+0x58>
  40f13d:	mov    rcx,rdx
  40f140:	mov    rdx,r12
  40f143:	call   40f260 <__swc_fn_ff58629f_000047_b30433d0>
  40f148:	pop    r12
  40f14a:	ret
  40f14b:	add    BYTE PTR [rax],al
  40f14d:	add    BYTE PTR [rax],al
	...

000000000040f150 <__swc_fn_ff58629f_000038_28d0e998>:
  40f150:	push   rsi
  40f151:	mov    rsi,rcx
  40f154:	call   407a20 <__swc_fn_ff58629f_000036_cd1a4e8c>
  40f159:	mov    rcx,rax
  40f15c:	mov    rdx,rsi
  40f15f:	call   411140 <__swc_fn_ff58629f_000134_ae5891af>
  40f164:	mov    rcx,rsi
  40f167:	call   40ade0 <__swc_fn_ff58629f_000037_92d9bbff>
  40f16c:	pop    rsi
  40f16d:	ret
	...

000000000040f170 <__swc_fn_ff58629f_000041_eb6108f2>:
  40f170:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40f17a:	sete   al
  40f17d:	ret
	...

000000000040f180 <__swc_fn_ff58629f_000044_d3c2ab54>:
  40f180:	push   rsi
  40f181:	test   rdx,rdx
  40f184:	jne    40f188 <__swc_fn_ff58629f_000044_d3c2ab54+0x8>
  40f186:	pop    rsi
  40f187:	ret
  40f188:	mov    rax,r8
  40f18b:	mov    ecx,0x1000
  40f190:	test   ecx,ecx
  40f192:	mov    r10d,0x8
  40f198:	cmove  ecx,r10d
  40f19c:	dec    rcx
  40f19f:	mov    r10,0xffffffffffffffff
  40f1a6:	sub    r10,rcx
  40f1a9:	cmp    r8,r10
  40f1ac:	jbe    40f1b2 <__swc_fn_ff58629f_000044_d3c2ab54+0x32>
  40f1ae:	xor    eax,eax
  40f1b0:	jmp    40f1ba <__swc_fn_ff58629f_000044_d3c2ab54+0x3a>
  40f1b2:	add    rax,rcx
  40f1b5:	andn   rax,rcx,rax
  40f1ba:	mov    ecx,0x1000
  40f1bf:	test   ecx,ecx
  40f1c1:	mov    r8d,0x8
  40f1c7:	cmove  ecx,r8d
  40f1cb:	dec    rcx
  40f1ce:	mov    r8,0xffffffffffffffff
  40f1d5:	sub    r8,rcx
  40f1d8:	cmp    r9,r8
  40f1db:	jbe    40f1e1 <__swc_fn_ff58629f_000044_d3c2ab54+0x61>
  40f1dd:	xor    esi,esi
  40f1df:	jmp    40f1ec <__swc_fn_ff58629f_000044_d3c2ab54+0x6c>
  40f1e1:	add    r9,rcx
  40f1e4:	andn   r9,rcx,r9
  40f1e9:	mov    rsi,r9
  40f1ec:	mov    rcx,rdx
  40f1ef:	mov    rdx,rax
  40f1f2:	mov    r8,rsi
  40f1f5:	call   410d40 <__swc_fn_ff58629f_000119_5208f471>
  40f1fa:	lea    rcx,[rip+0x13e4f]        # 423050 <__swc_bss_base_ff58629f+0x10>
  40f201:	mov    rdx,QWORD PTR [rip+0x13e48]        # 423050 <__swc_bss_base_ff58629f+0x10>
  40f208:	nop    DWORD PTR [rax+rax*1+0x0]
  40f210:	mov    r8,rdx
  40f213:	sub    r8,rsi
  40f216:	mov    rax,rdx
  40f219:	lock cmpxchg QWORD PTR [rcx],r8
  40f21e:	cmp    rax,rdx
  40f221:	je     40f228 <__swc_fn_ff58629f_000044_d3c2ab54+0xa8>
  40f223:	mov    rdx,rax
  40f226:	jmp    40f210 <__swc_fn_ff58629f_000044_d3c2ab54+0x90>
  40f228:	lea    rcx,[rip+0x13e39]        # 423068 <__swc_bss_base_ff58629f+0x28>
  40f22f:	mov    rdx,QWORD PTR [rip+0x13e32]        # 423068 <__swc_bss_base_ff58629f+0x28>
  40f236:	cs nop WORD PTR [rax+rax*1+0x0]
  40f240:	lea    r8,[rdx+0x1]
  40f244:	mov    rax,rdx
  40f247:	lock cmpxchg QWORD PTR [rcx],r8
  40f24c:	cmp    rax,rdx
  40f24f:	je     40f256 <__swc_fn_ff58629f_000044_d3c2ab54+0xd6>
  40f251:	mov    rdx,rax
  40f254:	jmp    40f240 <__swc_fn_ff58629f_000044_d3c2ab54+0xc0>
  40f256:	pop    rsi
  40f257:	ret
	...

000000000040f260 <__swc_fn_ff58629f_000047_b30433d0>:
  40f260:	push   rbx
  40f261:	push   rsi
  40f262:	push   rdi
  40f263:	push   r12
  40f265:	push   r13
  40f267:	push   r14
  40f269:	push   r15
  40f26b:	sub    rsp,0x30
  40f26f:	mov    rbx,rdx
  40f272:	mov    QWORD PTR [rsp+0x18],rdx
  40f277:	mov    rsi,rcx
  40f27a:	mov    eax,0x1
  40f27f:	xchg   DWORD PTR [rbx+0x20],eax
  40f282:	test   eax,eax
  40f284:	je     40f296 <__swc_fn_ff58629f_000047_b30433d0+0x36>
  40f286:	add    rsp,0x30
  40f28a:	pop    r15
  40f28c:	pop    r14
  40f28e:	pop    r13
  40f290:	pop    r12
  40f292:	pop    rdi
  40f293:	pop    rsi
  40f294:	pop    rbx
  40f295:	ret
  40f296:	mov    rcx,rsi
  40f299:	mov    rdx,rbx
  40f29c:	mov    r8,0xffffffffffffffff
  40f2a3:	call   40b3b0 <__swc_fn_ff58629f_000064_dea90857>
  40f2a8:	lea    rdi,[rsi+0x10]
  40f2ac:	mov    QWORD PTR [rsp+0x20],rdi
  40f2b1:	mov    rcx,rdi
  40f2b4:	call   4112c0 <__swc_fn_ff58629f_000140_86bb0f90>
  40f2b9:	xor    r12d,r12d
  40f2bc:	cs nop WORD PTR [rax+rax*1+0x0]
  40f2c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40f2d0:	mov    eax,r12d
  40f2d3:	lea    r13,[rax+rax*4]
  40f2d7:	lea    r13,[rbx+r13*8+0x28]
  40f2dc:	mov    rax,QWORD PTR [r13+0x8]
  40f2e0:	mov    QWORD PTR [rsp+0x8],rax
  40f2e5:	mov    rax,QWORD PTR [r13+0x18]
  40f2e9:	mov    QWORD PTR [rsp+0x10],rax
  40f2ee:	mov    r14d,0x2
  40f2f4:	xor    r15d,r15d
  40f2f7:	test   r14,r14
  40f2fa:	je     40f377 <__swc_fn_ff58629f_000047_b30433d0+0x117>
  40f300:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  40f305:	mov    rdi,rax
  40f308:	test   rdi,rdi
  40f30b:	je     40f369 <__swc_fn_ff58629f_000047_b30433d0+0x109>
  40f30d:	nop    DWORD PTR [rax]
  40f310:	mov    rbx,QWORD PTR [rdi+0x48]
  40f314:	mov    DWORD PTR [rdi+0x6c],0x0
  40f31b:	mov    rcx,rdi
  40f31e:	call   40ee20 <__swc_fn_ff58629f_000014_e4b0ddfc>
  40f323:	cmp    DWORD PTR [rdi+0x28],0x0
  40f327:	jne    40f340 <__swc_fn_ff58629f_000047_b30433d0+0xe0>
  40f329:	mov    rax,rdi
  40f32c:	and    rax,0xffffffffffc00000
  40f333:	mov    rcx,rax
  40f336:	mov    rdx,rdi
  40f339:	call   40aae0 <__swc_fn_ff58629f_000019_283e2b5e>
  40f33e:	jmp    40f361 <__swc_fn_ff58629f_000047_b30433d0+0x101>
  40f340:	mov    QWORD PTR [rdi+0x40],0x0
  40f348:	rex mov BYTE PTR [rdi+0x3b],0x2
  40f34d:	mov    QWORD PTR [rdi+0x50],0x0
  40f355:	mov    rax,QWORD PTR [rsi+0x28]
  40f359:	mov    QWORD PTR [rdi+0x48],rax
  40f35d:	mov    QWORD PTR [rsi+0x28],rdi
  40f361:	mov    rdi,rbx
  40f364:	test   rbx,rbx
  40f367:	jne    40f310 <__swc_fn_ff58629f_000047_b30433d0+0xb0>
  40f369:	add    r15,0x1
  40f36d:	sub    r14,0x1
  40f371:	jne    40f300 <__swc_fn_ff58629f_000047_b30433d0+0xa0>
  40f377:	vxorps xmm0,xmm0,xmm0
  40f37b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  40f381:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40f387:	mov    QWORD PTR [r13+0x20],0x0
  40f38f:	add    r12,0x1
  40f393:	cmp    r12,0x2d
  40f397:	mov    rbx,QWORD PTR [rsp+0x18]
  40f39c:	jb     40f2d0 <__swc_fn_ff58629f_000047_b30433d0+0x70>
  40f3a2:	mov    rcx,rsi
  40f3a5:	mov    rbx,QWORD PTR [rsp+0x18]
  40f3aa:	mov    rdx,rbx
  40f3ad:	mov    rdi,QWORD PTR [rsp+0x20]
  40f3b2:	call   407be0 <__swc_fn_ff58629f_000048_6e7a8d58>
  40f3b7:	mov    rcx,rdi
  40f3ba:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40f3bf:	mov    rcx,rsi
  40f3c2:	mov    rdx,rbx
  40f3c5:	mov    r8d,0x9b8
  40f3cb:	mov    r9d,0x9b8
  40f3d1:	call   40f180 <__swc_fn_ff58629f_000044_d3c2ab54>
  40f3d6:	add    rsp,0x30
  40f3da:	pop    r15
  40f3dc:	pop    r14
  40f3de:	pop    r13
  40f3e0:	pop    r12
  40f3e2:	pop    rdi
  40f3e3:	pop    rsi
  40f3e4:	pop    rbx
  40f3e5:	ret
	...

000000000040f400 <__swc_fn_ff58629f_000050_ad48ec88>:
  40f400:	push   rbx
  40f401:	push   rsi
  40f402:	push   rdi
  40f403:	push   r12
  40f405:	push   r13
  40f407:	push   r14
  40f409:	push   r15
  40f40b:	sub    rsp,0x30
  40f40f:	mov    ebx,r8d
  40f412:	mov    rsi,rcx
  40f415:	mov    rdi,rdx
  40f418:	test   r8d,r8d
  40f41b:	jne    40f424 <__swc_fn_ff58629f_000050_ad48ec88+0x24>
  40f41d:	mov    eax,0x8
  40f422:	jmp    40f44b <__swc_fn_ff58629f_000050_ad48ec88+0x4b>
  40f424:	cmp    ebx,0x8
  40f427:	ja     40f432 <__swc_fn_ff58629f_000050_ad48ec88+0x32>
  40f429:	mov    rax,rbx
  40f42c:	shl    rax,0x4
  40f430:	jmp    40f44b <__swc_fn_ff58629f_000050_ad48ec88+0x4b>
  40f432:	lea    eax,[rbx-0x9]
  40f435:	mov    ecx,eax
  40f437:	shr    ecx,0x2
  40f43a:	and    eax,0x3
  40f43d:	lea    ecx,[rcx+0x7]
  40f440:	lea    ecx,[rcx-0x2]
  40f443:	lea    eax,[rax+0x5]
  40f446:	shlx   rax,rax,rcx
  40f44b:	lea    r12,[rsp+0x8]
  40f450:	mov    DWORD PTR [rsp+0x8],eax
  40f454:	lea    r13,[rsp+0xc]
  40f459:	mov    QWORD PTR [rsp+0x18],r13
  40f45e:	xor    eax,eax
  40f460:	cmp    ebx,0x21
  40f463:	setae  al
  40f466:	lea    eax,[rax+rax*2]
  40f469:	mov    DWORD PTR [rsp+0xc],eax
  40f46d:	lea    r14,[rsi+0x10]
  40f471:	mov    rcx,r14
  40f474:	call   4112c0 <__swc_fn_ff58629f_000140_86bb0f90>
  40f479:	xor    eax,eax
  40f47b:	mov    rcx,QWORD PTR [rsi+0x28]
  40f47f:	mov    r15,rcx
  40f482:	test   r15,r15
  40f485:	je     40f536 <__swc_fn_ff58629f_000050_ad48ec88+0x136>
  40f48b:	cs nop WORD PTR [rax+rax*1+0x0]
  40f495:	cs nop WORD PTR [rax+rax*1+0x0]
  40f49f:	nop
  40f4a0:	mov    rcx,QWORD PTR [r15+0x48]
  40f4a4:	movzx  edx,BYTE PTR [r15+0x39]
  40f4a9:	cmp    edx,ebx
  40f4ab:	jne    40f527 <__swc_fn_ff58629f_000050_ad48ec88+0x127>
  40f4ad:	test   rax,rax
  40f4b0:	jne    40f4b8 <__swc_fn_ff58629f_000050_ad48ec88+0xb8>
  40f4b2:	mov    QWORD PTR [rsi+0x28],rcx
  40f4b6:	jmp    40f4bc <__swc_fn_ff58629f_000050_ad48ec88+0xbc>
  40f4b8:	mov    QWORD PTR [rax+0x48],rcx
  40f4bc:	vxorps xmm0,xmm0,xmm0
  40f4c0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  40f4c6:	mov    BYTE PTR [r15+0x3b],0x1
  40f4cb:	mov    QWORD PTR [r15+0x40],rdi
  40f4cf:	mov    rcx,r15
  40f4d2:	call   40ee20 <__swc_fn_ff58629f_000014_e4b0ddfc>
  40f4d7:	movzx  eax,BYTE PTR [r15+0x39]
  40f4dc:	lea    rax,[rax+rax*4]
  40f4e0:	lea    rax,[rdi+rax*8+0x28]
  40f4e5:	mov    rcx,QWORD PTR [rax+0x10]
  40f4e9:	mov    QWORD PTR [r15+0x50],rcx
  40f4ed:	mov    QWORD PTR [r15+0x48],0x0
  40f4f5:	mov    rcx,QWORD PTR [rax+0x10]
  40f4f9:	test   rcx,rcx
  40f4fc:	je     40f504 <__swc_fn_ff58629f_000050_ad48ec88+0x104>
  40f4fe:	mov    QWORD PTR [rcx+0x48],r15
  40f502:	jmp    40f508 <__swc_fn_ff58629f_000050_ad48ec88+0x108>
  40f504:	mov    QWORD PTR [rax+0x8],r15
  40f508:	mov    QWORD PTR [rax+0x10],r15
  40f50c:	mov    rcx,r14
  40f50f:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40f514:	mov    rax,r15
  40f517:	add    rsp,0x30
  40f51b:	pop    r15
  40f51d:	pop    r14
  40f51f:	pop    r13
  40f521:	pop    r12
  40f523:	pop    rdi
  40f524:	pop    rsi
  40f525:	pop    rbx
  40f526:	ret
  40f527:	mov    rax,r15
  40f52a:	mov    r15,rcx
  40f52d:	test   rcx,rcx
  40f530:	jne    40f4a0 <__swc_fn_ff58629f_000050_ad48ec88+0xa0>
  40f536:	mov    rax,QWORD PTR [rsi+0x18]
  40f53a:	mov    r15,rax
  40f53d:	test   r15,r15
  40f540:	je     40f5d6 <__swc_fn_ff58629f_000050_ad48ec88+0x1d6>
  40f546:	cs nop WORD PTR [rax+rax*1+0x0]
  40f550:	mov    eax,DWORD PTR [rsp+0xc]
  40f554:	cmp    DWORD PTR [r15+0x28],eax
  40f558:	jne    40f5c6 <__swc_fn_ff58629f_000050_ad48ec88+0x1c6>
  40f55a:	mov    rcx,r15
  40f55d:	mov    edx,ebx
  40f55f:	mov    rax,r12
  40f562:	mov    r8d,DWORD PTR [rax]
  40f565:	call   407620 <__swc_fn_ff58629f_000018_efc44797>
  40f56a:	mov    r13,rax
  40f56d:	test   rax,rax
  40f570:	je     40f5c6 <__swc_fn_ff58629f_000050_ad48ec88+0x1c6>
  40f572:	mov    QWORD PTR [r13+0x40],rdi
  40f576:	movzx  eax,BYTE PTR [r13+0x39]
  40f57b:	lea    rax,[rax+rax*4]
  40f57f:	lea    rax,[rdi+rax*8+0x28]
  40f584:	mov    rcx,QWORD PTR [rax+0x10]
  40f588:	mov    QWORD PTR [r13+0x50],rcx
  40f58c:	mov    QWORD PTR [r13+0x48],0x0
  40f594:	mov    rcx,QWORD PTR [rax+0x10]
  40f598:	test   rcx,rcx
  40f59b:	je     40f5a3 <__swc_fn_ff58629f_000050_ad48ec88+0x1a3>
  40f59d:	mov    QWORD PTR [rcx+0x48],r13
  40f5a1:	jmp    40f5a7 <__swc_fn_ff58629f_000050_ad48ec88+0x1a7>
  40f5a3:	mov    QWORD PTR [rax+0x8],r13
  40f5a7:	mov    QWORD PTR [rax+0x10],r13
  40f5ab:	mov    rcx,r14
  40f5ae:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40f5b3:	mov    rax,r13
  40f5b6:	add    rsp,0x30
  40f5ba:	pop    r15
  40f5bc:	pop    r14
  40f5be:	pop    r13
  40f5c0:	pop    r12
  40f5c2:	pop    rdi
  40f5c3:	pop    rsi
  40f5c4:	pop    rbx
  40f5c5:	ret
  40f5c6:	mov    rax,QWORD PTR [r15+0x10]
  40f5ca:	mov    r15,rax
  40f5cd:	test   rax,rax
  40f5d0:	jne    40f550 <__swc_fn_ff58629f_000050_ad48ec88+0x150>
  40f5d6:	mov    rcx,rsi
  40f5d9:	mov    r13,QWORD PTR [rsp+0x18]
  40f5de:	mov    edx,DWORD PTR [r13+0x0]
  40f5e2:	call   40ac60 <__swc_fn_ff58629f_000025_2685aade>
  40f5e7:	mov    r13,rax
  40f5ea:	test   rax,rax
  40f5ed:	jne    40f609 <__swc_fn_ff58629f_000050_ad48ec88+0x209>
  40f5ef:	mov    rcx,r14
  40f5f2:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40f5f7:	xor    eax,eax
  40f5f9:	add    rsp,0x30
  40f5fd:	pop    r15
  40f5ff:	pop    r14
  40f601:	pop    r13
  40f603:	pop    r12
  40f605:	pop    rdi
  40f606:	pop    rsi
  40f607:	pop    rbx
  40f608:	ret
  40f609:	mov    rcx,r13
  40f60c:	mov    edx,ebx
  40f60e:	mov    r8d,DWORD PTR [r12]
  40f612:	call   407620 <__swc_fn_ff58629f_000018_efc44797>
  40f617:	mov    rbx,rax
  40f61a:	test   rax,rax
  40f61d:	jne    40f641 <__swc_fn_ff58629f_000050_ad48ec88+0x241>
  40f61f:	mov    rcx,r13
  40f622:	call   40f060 <__swc_fn_ff58629f_000026_aa910677>
  40f627:	mov    rcx,r14
  40f62a:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40f62f:	xor    eax,eax
  40f631:	add    rsp,0x30
  40f635:	pop    r15
  40f637:	pop    r14
  40f639:	pop    r13
  40f63b:	pop    r12
  40f63d:	pop    rdi
  40f63e:	pop    rsi
  40f63f:	pop    rbx
  40f640:	ret
  40f641:	mov    rax,QWORD PTR [rsi+0x18]
  40f645:	mov    QWORD PTR [r13+0x10],rax
  40f649:	mov    rax,QWORD PTR [rsi+0x18]
  40f64d:	test   rax,rax
  40f650:	je     40f656 <__swc_fn_ff58629f_000050_ad48ec88+0x256>
  40f652:	mov    QWORD PTR [rax+0x18],r13
  40f656:	mov    QWORD PTR [rsi+0x18],r13
  40f65a:	mov    QWORD PTR [rbx+0x40],rdi
  40f65e:	movzx  eax,BYTE PTR [rbx+0x39]
  40f662:	lea    rax,[rax+rax*4]
  40f666:	lea    rax,[rdi+rax*8+0x28]
  40f66b:	mov    rcx,QWORD PTR [rax+0x10]
  40f66f:	mov    QWORD PTR [rbx+0x50],rcx
  40f673:	mov    QWORD PTR [rbx+0x48],0x0
  40f67b:	mov    rcx,QWORD PTR [rax+0x10]
  40f67f:	test   rcx,rcx
  40f682:	je     40f68a <__swc_fn_ff58629f_000050_ad48ec88+0x28a>
  40f684:	mov    QWORD PTR [rcx+0x48],rbx
  40f688:	jmp    40f68e <__swc_fn_ff58629f_000050_ad48ec88+0x28e>
  40f68a:	mov    QWORD PTR [rax+0x8],rbx
  40f68e:	mov    QWORD PTR [rax+0x10],rbx
  40f692:	mov    rcx,r14
  40f695:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40f69a:	mov    rax,rbx
  40f69d:	add    rsp,0x30
  40f6a1:	pop    r15
  40f6a3:	pop    r14
  40f6a5:	pop    r13
  40f6a7:	pop    r12
  40f6a9:	pop    rdi
  40f6aa:	pop    rsi
  40f6ab:	pop    rbx
  40f6ac:	ret
	...

000000000040f6c0 <__swc_fn_ff58629f_000053_d846b172>:
  40f6c0:	push   rsi
  40f6c1:	push   rdi
  40f6c2:	push   r12
  40f6c4:	mov    rsi,rdx
  40f6c7:	mov    rdi,rcx
  40f6ca:	lea    rax,[rcx+0x2a80]
  40f6d1:	mov    rcx,QWORD PTR [rax]
  40f6d4:	test   rcx,rcx
  40f6d7:	jne    40f6de <__swc_fn_ff58629f_000053_d846b172+0x1e>
  40f6d9:	pop    r12
  40f6db:	pop    rdi
  40f6dc:	pop    rsi
  40f6dd:	ret
  40f6de:	xor    ecx,ecx
  40f6e0:	xchg   QWORD PTR [rax],rcx
  40f6e3:	mov    r12,rcx
  40f6e6:	cs nop WORD PTR [rax+rax*1+0x0]
  40f6f0:	cs nop WORD PTR [rax+rax*1+0x0]
  40f6fa:	nop    WORD PTR [rax+rax*1+0x0]
  40f700:	test   r12,r12
  40f703:	je     40f79a <__swc_fn_ff58629f_000053_d846b172+0xda>
  40f709:	mov    r8,r12
  40f70c:	mov    r12,QWORD PTR [r12+0x78]
  40f711:	lea    rcx,[r8+0x70]
  40f715:	xor    eax,eax
  40f717:	xchg   DWORD PTR [r8+0x70],eax
  40f71b:	cmp    QWORD PTR [r8+0x40],rsi
  40f71f:	jne    40f736 <__swc_fn_ff58629f_000053_d846b172+0x76>
  40f721:	mov    eax,DWORD PTR [r8+0x6c]
  40f725:	test   eax,eax
  40f727:	je     40f700 <__swc_fn_ff58629f_000053_d846b172+0x40>
  40f729:	mov    rcx,rdi
  40f72c:	mov    rdx,rsi
  40f72f:	call   40b010 <__swc_fn_ff58629f_000052_e072b516>
  40f734:	jmp    40f700 <__swc_fn_ff58629f_000053_d846b172+0x40>
  40f736:	mov    rax,QWORD PTR [r8+0x40]
  40f73a:	test   rax,rax
  40f73d:	je     40f700 <__swc_fn_ff58629f_000053_d846b172+0x40>
  40f73f:	mov    eax,DWORD PTR [r8+0x6c]
  40f743:	test   eax,eax
  40f745:	je     40f700 <__swc_fn_ff58629f_000053_d846b172+0x40>
  40f747:	mov    r9d,0x1
  40f74d:	xor    eax,eax
  40f74f:	lock cmpxchg DWORD PTR [rcx],r9d
  40f754:	test   eax,eax
  40f756:	jne    40f700 <__swc_fn_ff58629f_000053_d846b172+0x40>
  40f758:	mov    rax,r8
  40f75b:	and    rax,0xffffffffffc00000
  40f762:	mov    rax,QWORD PTR [rax+0x8]
  40f766:	test   rax,rax
  40f769:	jne    40f771 <__swc_fn_ff58629f_000053_d846b172+0xb1>
  40f76b:	xor    eax,eax
  40f76d:	xchg   DWORD PTR [rcx],eax
  40f76f:	jmp    40f700 <__swc_fn_ff58629f_000053_d846b172+0x40>
  40f771:	lea    rcx,[rax+0x2a80]
  40f778:	mov    rax,QWORD PTR [rcx]
  40f77b:	mov    rdx,rax
  40f77e:	xchg   ax,ax
  40f780:	mov    QWORD PTR [r8+0x78],rdx
  40f784:	mov    rax,rdx
  40f787:	lock cmpxchg QWORD PTR [rcx],r8
  40f78c:	cmp    rax,rdx
  40f78f:	je     40f700 <__swc_fn_ff58629f_000053_d846b172+0x40>
  40f795:	mov    rdx,rax
  40f798:	jmp    40f780 <__swc_fn_ff58629f_000053_d846b172+0xc0>
  40f79a:	pop    r12
  40f79c:	pop    rdi
  40f79d:	pop    rsi
  40f79e:	ret
	...

000000000040f7a0 <__swc_fn_ff58629f_000056_2e3450f7>:
  40f7a0:	sub    rsp,0x8
  40f7a4:	mov    r9,r8
  40f7a7:	movzx  eax,BYTE PTR [r9+0x39]
  40f7ac:	lea    rax,[rax+rax*4]
  40f7b0:	lea    rax,[rdx+rax*8+0x28]
  40f7b5:	cmp    QWORD PTR [rax],r9
  40f7b8:	je     40f7c0 <__swc_fn_ff58629f_000056_2e3450f7+0x20>
  40f7ba:	cmp    QWORD PTR [rax+0x20],r9
  40f7be:	jne    40f7c5 <__swc_fn_ff58629f_000056_2e3450f7+0x25>
  40f7c0:	add    rsp,0x8
  40f7c4:	ret
  40f7c5:	cmp    QWORD PTR [rax+0x20],0x0
  40f7ca:	je     40f7d7 <__swc_fn_ff58629f_000056_2e3450f7+0x37>
  40f7cc:	mov    r8,QWORD PTR [rax+0x20]
  40f7d0:	cmp    DWORD PTR [r8+0x28],0x0
  40f7d5:	je     40f7e0 <__swc_fn_ff58629f_000056_2e3450f7+0x40>
  40f7d7:	mov    QWORD PTR [rax+0x20],r9
  40f7db:	add    rsp,0x8
  40f7df:	ret
  40f7e0:	mov    r8,r9
  40f7e3:	call   40af70 <__swc_fn_ff58629f_000049_137687bb>
  40f7e8:	mov    rax,r9
  40f7eb:	and    rax,0xffffffffffc00000
  40f7f2:	mov    rcx,rax
  40f7f5:	mov    rdx,r9
  40f7f8:	call   40aae0 <__swc_fn_ff58629f_000019_283e2b5e>
  40f7fd:	add    rsp,0x8
  40f801:	ret
	...

000000000040f810 <__swc_fn_ff58629f_000059_1bb23e77>:
  40f810:	push   rsi
  40f811:	push   rdi
  40f812:	push   r12
  40f814:	mov    rsi,rdx
  40f817:	mov    rax,rdx
  40f81a:	shr    rax,0xc
  40f81e:	movabs rdx,0x9e3779b97f4a7c15
  40f828:	imul   rax,rdx
  40f82c:	shr    rax,0x20
  40f830:	lea    rax,[rax*8+0x0]
  40f838:	shr    rax,0x20
  40f83c:	lea    rax,[rax*8+0x0]
  40f844:	lea    rax,[rcx+rax*8+0x40]
  40f849:	xor    edx,edx
  40f84b:	test   dl,dl
  40f84d:	lea    rdi,[rcx+0x8]
  40f851:	cmove  rdi,rax
  40f855:	xor    edx,edx
  40f857:	test   dl,dl
  40f859:	lea    r12,[rcx+0x30]
  40f85d:	lea    rax,[rax+0x8]
  40f861:	cmove  r12,rax
  40f865:	mov    rcx,rdi
  40f868:	call   4112c0 <__swc_fn_ff58629f_000140_86bb0f90>
  40f86d:	mov    rax,QWORD PTR [rsi+0x30]
  40f871:	test   rax,rax
  40f874:	jne    40f880 <__swc_fn_ff58629f_000059_1bb23e77+0x70>
  40f876:	mov    rax,QWORD PTR [rsi+0x38]
  40f87a:	mov    QWORD PTR [r12],rax
  40f87e:	jmp    40f888 <__swc_fn_ff58629f_000059_1bb23e77+0x78>
  40f880:	mov    rcx,QWORD PTR [rsi+0x38]
  40f884:	mov    QWORD PTR [rax+0x38],rcx
  40f888:	mov    rax,QWORD PTR [rsi+0x38]
  40f88c:	test   rax,rax
  40f88f:	je     40f899 <__swc_fn_ff58629f_000059_1bb23e77+0x89>
  40f891:	mov    rcx,QWORD PTR [rsi+0x30]
  40f895:	mov    QWORD PTR [rax+0x30],rcx
  40f899:	vxorps xmm0,xmm0,xmm0
  40f89d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  40f8a2:	mov    rcx,rdi
  40f8a5:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40f8aa:	pop    r12
  40f8ac:	pop    rdi
  40f8ad:	pop    rsi
  40f8ae:	ret
	...

000000000040f8b0 <__swc_fn_ff58629f_000062_ad030a10>:
  40f8b0:	mov    rax,QWORD PTR [rcx+0x250]
  40f8b7:	mov    rcx,rax
  40f8ba:	cmp    rax,0x1000000
  40f8c1:	mov    eax,0x1000000
  40f8c6:	cmovb  rcx,rax
  40f8ca:	mov    rax,rcx
  40f8cd:	cmp    rcx,0x10000000
  40f8d4:	mov    ecx,0x10000000
  40f8d9:	cmova  rax,rcx
  40f8dd:	ret
	...

000000000040f8e0 <__swc_fn_ff58629f_000065_ffcd96eb>:
  40f8e0:	push   rsi
  40f8e1:	push   rdi
  40f8e2:	push   r12
  40f8e4:	mov    rsi,rcx
  40f8e7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  40f8ee:	xor    r12d,r12d
  40f8f1:	test   rdi,rdi
  40f8f4:	jbe    40f92b <__swc_fn_ff58629f_000065_ffcd96eb+0x4b>
  40f8f6:	cs nop WORD PTR [rax+rax*1+0x0]
  40f900:	lea    rax,[r12+r12*4]
  40f904:	lea    rax,[rsi+rax*8+0x268]
  40f90c:	mov    rcx,rsi
  40f90f:	mov    rdx,QWORD PTR [rax]
  40f912:	mov    r8,QWORD PTR [rax+0x8]
  40f916:	mov    rax,QWORD PTR [rax+0x10]
  40f91a:	mov    r9,rax
  40f91d:	call   40f180 <__swc_fn_ff58629f_000044_d3c2ab54>
  40f922:	add    r12,0x1
  40f926:	cmp    r12,rdi
  40f929:	jb     40f900 <__swc_fn_ff58629f_000065_ffcd96eb+0x20>
  40f92b:	vxorps xmm0,xmm0,xmm0
  40f92f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  40f937:	pop    r12
  40f939:	pop    rdi
  40f93a:	pop    rsi
  40f93b:	ret
  40f93c:	add    BYTE PTR [rax],al
	...

000000000040f940 <__swc_fn_ff58629f_000068_8c7d044b>:
  40f940:	push   rsi
  40f941:	push   rdi
  40f942:	sub    rsp,0x8
  40f946:	mov    rsi,rcx
  40f949:	call   407f60 <__swc_fn_ff58629f_000057_df0696cd>
  40f94e:	mov    rdi,rax
  40f951:	mov    rcx,rsi
  40f954:	mov    rdx,rax
  40f957:	call   40f810 <__swc_fn_ff58629f_000059_1bb23e77>
  40f95c:	mov    rcx,QWORD PTR [rdi+0x28]
  40f960:	mov    rdx,QWORD PTR [rsi+0x250]
  40f967:	nop    WORD PTR [rax+rax*1+0x0]
  40f970:	mov    r8,rdx
  40f973:	sub    r8,rcx
  40f976:	mov    rax,rdx
  40f979:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40f982:	cmp    rax,rdx
  40f985:	je     40f98c <__swc_fn_ff58629f_000068_8c7d044b+0x4c>
  40f987:	mov    rdx,rax
  40f98a:	jmp    40f970 <__swc_fn_ff58629f_000068_8c7d044b+0x30>
  40f98c:	mov    rcx,rsi
  40f98f:	mov    rdx,QWORD PTR [rdi]
  40f992:	mov    r8,QWORD PTR [rdi+0x8]
  40f996:	mov    r9,QWORD PTR [rdi+0x10]
  40f99a:	call   408080 <__swc_fn_ff58629f_000063_b304235a>
  40f99f:	mov    rcx,rsi
  40f9a2:	call   407cc0 <__swc_fn_ff58629f_000054_3af34d7f>
  40f9a7:	add    rsp,0x8
  40f9ab:	pop    rdi
  40f9ac:	pop    rsi
  40f9ad:	ret
	...

000000000040f9b0 <__swc_fn_ff58629f_000071_97813b89>:
  40f9b0:	push   r12
  40f9b2:	push   r13
  40f9b4:	push   r14
  40f9b6:	push   rdi
  40f9b7:	push   rsi
  40f9b8:	sub    rsp,0x1b0
  40f9bf:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  40f9c8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  40f9d1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  40f9da:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  40f9e3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  40f9ec:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  40f9f5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  40f9fe:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  40fa07:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  40fa10:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  40fa19:	mov    r8,rdx
  40fa1c:	mov    r12,rcx
  40fa1f:	mov    r13,QWORD PTR [r8+0x40]
  40fa23:	test   r13,r13
  40fa26:	jne    40fa38 <__swc_fn_ff58629f_000071_97813b89+0x88>
  40fa28:	add    rsp,0x1b0
  40fa2f:	pop    rsi
  40fa30:	pop    rdi
  40fa31:	pop    r14
  40fa33:	pop    r13
  40fa35:	pop    r12
  40fa37:	ret
  40fa38:	mov    QWORD PTR [r8+0x40],0x0
  40fa40:	lea    rax,[rip+0x13631]        # 423078 <__swc_bss_base_ff58629f+0x38>
  40fa47:	mov    rcx,r13
  40fa4a:	sub    rcx,QWORD PTR [rax+0x8]
  40fa4e:	mov    rax,QWORD PTR [rip+0x13633]        # 423088 <__swc_bss_base_ff58629f+0x48>
  40fa55:	cmp    rcx,rax
  40fa58:	jae    40fa84 <__swc_fn_ff58629f_000071_97813b89+0xd4>
  40fa5a:	mov    rax,r13
  40fa5d:	and    rax,0xffffffffffc00000
  40fa64:	mov    rcx,r13
  40fa67:	shr    rcx,0x10
  40fa6b:	and    ecx,0x3f
  40fa6e:	mov    edx,DWORD PTR [rax+0x28]
  40fa71:	shrx   ecx,ecx,edx
  40fa76:	shl    rcx,0x4
  40fa7a:	lea    r14,[rax+rcx*8+0x80]
  40fa82:	jmp    40fa9f <__swc_fn_ff58629f_000071_97813b89+0xef>
  40fa84:	mov    rcx,r13
  40fa87:	mov    QWORD PTR [rsp+0xf8],r8
  40fa8f:	call   407950 <__swc_fn_ff58629f_000027_bcdc5519>
  40fa94:	mov    r8,QWORD PTR [rsp+0xf8]
  40fa9c:	mov    r14,rax
  40fa9f:	test   r14,r14
  40faa2:	jne    40fab4 <__swc_fn_ff58629f_000071_97813b89+0x104>
  40faa4:	mov    rcx,r12
  40faa7:	mov    rdx,r13
  40faaa:	call   40f940 <__swc_fn_ff58629f_000068_8c7d044b>
  40faaf:	jmp    40fb42 <__swc_fn_ff58629f_000071_97813b89+0x192>
  40fab4:	lea    rax,[rip+0x1154d]        # 421008 <__swc_data_base_ff58629f+0x8>
  40fabb:	mov    rax,QWORD PTR [rax]
  40fabe:	cmp    rax,0xffffffffffffffff
  40fac2:	je     40fad1 <__swc_fn_ff58629f_000071_97813b89+0x121>
  40fac4:	mov    eax,eax
  40fac6:	mov    edi,eax
  40fac8:	xor    eax,eax
  40faca:	call   407000 <pthread_getspecific@plt>
  40facf:	jmp    40fad3 <__swc_fn_ff58629f_000071_97813b89+0x123>
  40fad1:	xor    eax,eax
  40fad3:	test   rax,rax
  40fad6:	jne    40fae5 <__swc_fn_ff58629f_000071_97813b89+0x135>
  40fad8:	call   407a20 <__swc_fn_ff58629f_000036_cd1a4e8c>
  40fadd:	mov    rcx,rax
  40fae0:	call   40cfa0 <__swc_fn_ff58629f_000133_5f757033>
  40fae5:	test   rax,rax
  40fae8:	je     40fb37 <__swc_fn_ff58629f_000071_97813b89+0x187>
  40faea:	cmp    QWORD PTR [r14+0x40],rax
  40faee:	jne    40fb37 <__swc_fn_ff58629f_000071_97813b89+0x187>
  40faf0:	mov    ecx,DWORD PTR [r14+0x6c]
  40faf4:	test   ecx,ecx
  40faf6:	je     40fb16 <__swc_fn_ff58629f_000071_97813b89+0x166>
  40faf8:	mov    rcx,r12
  40fafb:	mov    rdx,rax
  40fafe:	mov    r8,r14
  40fb01:	mov    QWORD PTR [rsp+0x100],rax
  40fb09:	call   40b010 <__swc_fn_ff58629f_000052_e072b516>
  40fb0e:	mov    rax,QWORD PTR [rsp+0x100]
  40fb16:	mov    rcx,QWORD PTR [r14]
  40fb19:	mov    QWORD PTR [r13+0x0],rcx
  40fb1d:	mov    QWORD PTR [r14],r13
  40fb20:	sub    DWORD PTR [r14+0x28],0x1
  40fb25:	jne    40fb42 <__swc_fn_ff58629f_000071_97813b89+0x192>
  40fb27:	mov    rcx,r12
  40fb2a:	mov    rdx,rax
  40fb2d:	mov    r8,r14
  40fb30:	call   40f7a0 <__swc_fn_ff58629f_000056_2e3450f7>
  40fb35:	jmp    40fb42 <__swc_fn_ff58629f_000071_97813b89+0x192>
  40fb37:	mov    rcx,r14
  40fb3a:	mov    rdx,r13
  40fb3d:	call   407590 <__swc_fn_ff58629f_000015_524c1f23>
  40fb42:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40fb4b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  40fb54:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40fb5d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  40fb66:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40fb6f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  40fb78:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  40fb81:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40fb8a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  40fb93:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40fb9c:	add    rsp,0x1b0
  40fba3:	pop    rsi
  40fba4:	pop    rdi
  40fba5:	pop    r14
  40fba7:	pop    r13
  40fba9:	pop    r12
  40fbab:	ret
  40fbac:	add    BYTE PTR [rax],al
	...

000000000040fbb0 <__swc_fn_ff58629f_000074_9c99bf04>:
  40fbb0:	push   rsi
  40fbb1:	mov    rsi,rcx
  40fbb4:	call   40f170 <__swc_fn_ff58629f_000041_eb6108f2>
  40fbb9:	test   al,al
  40fbbb:	jne    40fbbf <__swc_fn_ff58629f_000074_9c99bf04+0xf>
  40fbbd:	pop    rsi
  40fbbe:	ret
  40fbbf:	lea    rax,[rip+0x1367a]        # 423240 <__swc_bss_base_ff58629f+0x200>
  40fbc6:	cmp    rsi,rax
  40fbc9:	jne    40fbcd <__swc_fn_ff58629f_000074_9c99bf04+0x1d>
  40fbcb:	pop    rsi
  40fbcc:	ret
  40fbcd:	mov    rcx,rsi
  40fbd0:	call   4112c0 <__swc_fn_ff58629f_000140_86bb0f90>
  40fbd5:	mov    rcx,rsi
  40fbd8:	call   40b7e0 <__swc_fn_ff58629f_000073_61e60aab>
  40fbdd:	mov    rcx,rsi
  40fbe0:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  40fbe5:	pop    rsi
  40fbe6:	ret
	...

000000000040fbf0 <__swc_fn_ff58629f_000077_15bd096c>:
  40fbf0:	sub    rsp,0x8
  40fbf4:	call   40b530 <__swc_fn_ff58629f_000070_7130736e>
  40fbf9:	add    rsp,0x8
  40fbfd:	ret
	...

000000000040fc00 <__swc_fn_ff58629f_000080_a5fd3362>:
  40fc00:	push   rsi
  40fc01:	mov    rsi,rdx
  40fc04:	call   40b7e0 <__swc_fn_ff58629f_000073_61e60aab>
  40fc09:	mov    QWORD PTR [rsi+0x40],0x0
  40fc11:	pop    rsi
  40fc12:	ret
	...

000000000040fc20 <__swc_fn_ff58629f_000083_63a67586>:
  40fc20:	mov    r8,rcx
  40fc23:	mov    rcx,QWORD PTR [rcx]
  40fc26:	cs nop WORD PTR [rax+rax*1+0x0]
  40fc30:	mov    r9,rcx
  40fc33:	sub    r9,rdx
  40fc36:	mov    rax,rcx
  40fc39:	lock cmpxchg QWORD PTR [r8],r9
  40fc3e:	cmp    rax,rcx
  40fc41:	je     40fc48 <__swc_fn_ff58629f_000083_63a67586+0x28>
  40fc43:	mov    rcx,rax
  40fc46:	jmp    40fc30 <__swc_fn_ff58629f_000083_63a67586+0x10>
  40fc48:	mov    rax,rcx
  40fc4b:	ret
  40fc4c:	add    BYTE PTR [rax],al
	...

000000000040fc50 <__swc_fn_ff58629f_000086_c618ff58>:
  40fc50:	vxorps xmm0,xmm0,xmm0
  40fc54:	vmovups XMMWORD PTR [rcx],xmm0
  40fc58:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40fc5d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40fc62:	ret
	...

000000000040fc70 <__swc_fn_ff58629f_000089_0d280354>:
  40fc70:	push   rsi
  40fc71:	push   rdi
  40fc72:	push   r12
  40fc74:	push   r13
  40fc76:	push   r15
  40fc78:	push   r14
  40fc7a:	push   rbx
  40fc7b:	sub    rsp,0x60
  40fc7f:	mov    QWORD PTR [rsp+0x28],r11
  40fc84:	mov    rsi,rcx
  40fc87:	mov    rdi,rdx
  40fc8a:	mov    QWORD PTR [rsp+0x30],rdx
  40fc8f:	mov    r12,r8
  40fc92:	mov    r13,r9
  40fc95:	mov    QWORD PTR [rsp+0x38],r10
  40fc9a:	xor    r8d,r8d
  40fc9d:	call   40ffc0 <__swc_fn_ff58629f_000095_63c1827b>
  40fca2:	test   al,al
  40fca4:	je     40fcb9 <__swc_fn_ff58629f_000089_0d280354+0x49>
  40fca6:	mov    rax,r12
  40fca9:	add    rsp,0x60
  40fcad:	pop    rbx
  40fcae:	pop    r14
  40fcb0:	pop    r15
  40fcb2:	pop    r13
  40fcb4:	pop    r12
  40fcb6:	pop    rdi
  40fcb7:	pop    rsi
  40fcb8:	ret
  40fcb9:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40fcbe:	je     40fcd2 <__swc_fn_ff58629f_000089_0d280354+0x62>
  40fcc0:	xor    eax,eax
  40fcc2:	add    rsp,0x60
  40fcc6:	pop    rbx
  40fcc7:	pop    r14
  40fcc9:	pop    r15
  40fccb:	pop    r13
  40fccd:	pop    r12
  40fccf:	pop    rdi
  40fcd0:	pop    rsi
  40fcd1:	ret
  40fcd2:	mov    r15,rdi
  40fcd5:	mov    QWORD PTR [rsp+0x40],rdi
  40fcda:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40fcdf:	jne    40fd4f <__swc_fn_ff58629f_000089_0d280354+0xdf>
  40fce1:	mov    r14,QWORD PTR [r15+0xb8]
  40fce8:	mov    rax,QWORD PTR [r15+0xc0]
  40fcef:	mov    r15,rax
  40fcf2:	xor    edi,edi
  40fcf4:	test   r15,r15
  40fcf7:	je     40fd4f <__swc_fn_ff58629f_000089_0d280354+0xdf>
  40fcf9:	nop    DWORD PTR [rax+0x0]
  40fd00:	lea    rbx,[rdi*8+0x0]
  40fd08:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  40fd0d:	mov    rcx,rax
  40fd10:	mov    rdx,rsi
  40fd13:	xor    r8d,r8d
  40fd16:	call   40ffc0 <__swc_fn_ff58629f_000095_63c1827b>
  40fd1b:	test   al,al
  40fd1d:	je     40fd45 <__swc_fn_ff58629f_000089_0d280354+0xd5>
  40fd1f:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  40fd24:	test   rax,rax
  40fd27:	je     40fd45 <__swc_fn_ff58629f_000089_0d280354+0xd5>
  40fd29:	test   r13,r13
  40fd2c:	je     40fd32 <__swc_fn_ff58629f_000089_0d280354+0xc2>
  40fd2e:	mov    QWORD PTR [r13+0x8],rax
  40fd32:	mov    rax,r12
  40fd35:	add    rsp,0x60
  40fd39:	pop    rbx
  40fd3a:	pop    r14
  40fd3c:	pop    r15
  40fd3e:	pop    r13
  40fd40:	pop    r12
  40fd42:	pop    rdi
  40fd43:	pop    rsi
  40fd44:	ret
  40fd45:	add    rdi,0x1
  40fd49:	sub    r15,0x1
  40fd4d:	jne    40fd00 <__swc_fn_ff58629f_000089_0d280354+0x90>
  40fd4f:	test   r12,r12
  40fd52:	jne    40fd66 <__swc_fn_ff58629f_000089_0d280354+0xf6>
  40fd54:	xor    eax,eax
  40fd56:	add    rsp,0x60
  40fd5a:	pop    rbx
  40fd5b:	pop    r14
  40fd5d:	pop    r15
  40fd5f:	pop    r13
  40fd61:	pop    r12
  40fd63:	pop    rdi
  40fd64:	pop    rsi
  40fd65:	ret
  40fd66:	mov    rbx,QWORD PTR [rsp+0x28]
  40fd6b:	mov    rdi,QWORD PTR [rsp+0x30]
  40fd70:	mov    rax,rbx
  40fd73:	test   rax,rax
  40fd76:	je     40fda6 <__swc_fn_ff58629f_000089_0d280354+0x136>
  40fd78:	nop    DWORD PTR [rax+rax*1+0x0]
  40fd80:	cmp    QWORD PTR [rax+0x8],r12
  40fd84:	jne    40fd9d <__swc_fn_ff58629f_000089_0d280354+0x12d>
  40fd86:	cmp    QWORD PTR [rax],rdi
  40fd89:	jne    40fd9d <__swc_fn_ff58629f_000089_0d280354+0x12d>
  40fd8b:	xor    eax,eax
  40fd8d:	add    rsp,0x60
  40fd91:	pop    rbx
  40fd92:	pop    r14
  40fd94:	pop    r15
  40fd96:	pop    r13
  40fd98:	pop    r12
  40fd9a:	pop    rdi
  40fd9b:	pop    rsi
  40fd9c:	ret
  40fd9d:	mov    rax,QWORD PTR [rax+0x10]
  40fda1:	test   rax,rax
  40fda4:	jne    40fd80 <__swc_fn_ff58629f_000089_0d280354+0x110>
  40fda6:	lea    r14,[rsp+0x8]
  40fdab:	mov    QWORD PTR [rsp+0x48],r14
  40fdb0:	mov    QWORD PTR [rsp+0x8],rdi
  40fdb5:	mov    QWORD PTR [rsp+0x10],r12
  40fdba:	mov    QWORD PTR [rsp+0x18],rbx
  40fdbf:	mov    r15,QWORD PTR [rsp+0x40]
  40fdc4:	mov    rbx,QWORD PTR [r15+0x98]
  40fdcb:	mov    rax,QWORD PTR [r15+0xa0]
  40fdd2:	mov    rdi,rax
  40fdd5:	mov    r15,QWORD PTR [rsp+0x38]
  40fdda:	xor    r14d,r14d
  40fddd:	test   rdi,rdi
  40fde0:	je     40fe8a <__swc_fn_ff58629f_000089_0d280354+0x21a>
  40fde6:	cs nop WORD PTR [rax+rax*1+0x0]
  40fdf0:	mov    QWORD PTR [rsp+0x50],rdi
  40fdf5:	lea    rdi,[r14*8+0x0]
  40fdfd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  40fe02:	mov    rcx,rax
  40fe05:	call   409060 <__swc_fn_ff58629f_000087_3953ef98>
  40fe0a:	test   DWORD PTR [rax+0x28],0x10000
  40fe11:	je     40fe18 <__swc_fn_ff58629f_000089_0d280354+0x1a8>
  40fe13:	test   r15b,r15b
  40fe16:	je     40fe71 <__swc_fn_ff58629f_000089_0d280354+0x201>
  40fe18:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  40fe1c:	lea    rdi,[r12+rcx*1]
  40fe20:	cmp    BYTE PTR [rax+0x2c],0x6
  40fe24:	jne    40fe38 <__swc_fn_ff58629f_000089_0d280354+0x1c8>
  40fe26:	mov    rax,QWORD PTR [rax+0x40]
  40fe2a:	mov    rcx,rax
  40fe2d:	call   409060 <__swc_fn_ff58629f_000087_3953ef98>
  40fe32:	mov    rcx,QWORD PTR [rdi]
  40fe35:	mov    rdi,rcx
  40fe38:	test   rdi,rdi
  40fe3b:	je     40fe71 <__swc_fn_ff58629f_000089_0d280354+0x201>
  40fe3d:	mov    rcx,rsi
  40fe40:	mov    rdx,rax
  40fe43:	mov    r8,rdi
  40fe46:	mov    r9,r13
  40fe49:	mov    al,r15b
  40fe4c:	mov    r10,rax
  40fe4f:	mov    rdi,QWORD PTR [rsp+0x48]
  40fe54:	mov    r11,rdi
  40fe57:	call   40fc70 <__swc_fn_ff58629f_000089_0d280354>
  40fe5c:	test   rax,rax
  40fe5f:	je     40fe71 <__swc_fn_ff58629f_000089_0d280354+0x201>
  40fe61:	add    rsp,0x60
  40fe65:	pop    rbx
  40fe66:	pop    r14
  40fe68:	pop    r15
  40fe6a:	pop    r13
  40fe6c:	pop    r12
  40fe6e:	pop    rdi
  40fe6f:	pop    rsi
  40fe70:	ret
  40fe71:	add    r14,0x1
  40fe75:	mov    rax,QWORD PTR [rsp+0x50]
  40fe7a:	sub    rax,0x1
  40fe7e:	mov    rdi,rax
  40fe81:	test   rax,rax
  40fe84:	jne    40fdf0 <__swc_fn_ff58629f_000089_0d280354+0x180>
  40fe8a:	xor    eax,eax
  40fe8c:	add    rsp,0x60
  40fe90:	pop    rbx
  40fe91:	pop    r14
  40fe93:	pop    r15
  40fe95:	pop    r13
  40fe97:	pop    r12
  40fe99:	pop    rdi
  40fe9a:	pop    rsi
  40fe9b:	ret
  40fe9c:	add    BYTE PTR [rax],al
	...

000000000040fea0 <__swc_fn_ff58629f_000092_c1c9085b>:
  40fea0:	push   rsi
  40fea1:	push   rdi
  40fea2:	push   r12
  40fea4:	push   r13
  40fea6:	push   r14
  40fea8:	push   r15
  40feaa:	sub    rsp,0x78
  40feae:	mov    rsi,r10
  40feb1:	mov    QWORD PTR [rsp+0x68],r10
  40feb6:	mov    rdi,rcx
  40feb9:	mov    r12,rdx
  40febc:	mov    r13,r8
  40febf:	mov    r14,r9
  40fec2:	xor    r8d,r8d
  40fec5:	call   40ffc0 <__swc_fn_ff58629f_000095_63c1827b>
  40feca:	test   al,al
  40fecc:	je     40fef5 <__swc_fn_ff58629f_000092_c1c9085b+0x55>
  40fece:	mov    rcx,r14
  40fed1:	mov    rdx,r12
  40fed4:	mov    r8,r13
  40fed7:	mov    r9,rsi
  40feda:	call   40bc40 <__swc_fn_ff58629f_000091_23214800>
  40fedf:	test   al,al
  40fee1:	je     40fef5 <__swc_fn_ff58629f_000092_c1c9085b+0x55>
  40fee3:	mov    rax,r13
  40fee6:	add    rsp,0x78
  40feea:	pop    r15
  40feec:	pop    r14
  40feee:	pop    r13
  40fef0:	pop    r12
  40fef2:	pop    rdi
  40fef3:	pop    rsi
  40fef4:	ret
  40fef5:	cmp    BYTE PTR [r12+0x2c],0xe
  40fefb:	je     40ff0e <__swc_fn_ff58629f_000092_c1c9085b+0x6e>
  40fefd:	xor    eax,eax
  40feff:	add    rsp,0x78
  40ff03:	pop    r15
  40ff05:	pop    r14
  40ff07:	pop    r13
  40ff09:	pop    r12
  40ff0b:	pop    rdi
  40ff0c:	pop    rsi
  40ff0d:	ret
  40ff0e:	mov    r15,QWORD PTR [r12+0x98]
  40ff16:	mov    rax,QWORD PTR [r12+0xa0]
  40ff1e:	mov    r12,rax
  40ff21:	xor    esi,esi
  40ff23:	test   r12,r12
  40ff26:	je     40ff99 <__swc_fn_ff58629f_000092_c1c9085b+0xf9>
  40ff28:	nop    DWORD PTR [rax+rax*1+0x0]
  40ff30:	mov    QWORD PTR [rsp+0x70],r12
  40ff35:	lea    r12,[rsi*8+0x0]
  40ff3d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  40ff42:	mov    rcx,rax
  40ff45:	call   409060 <__swc_fn_ff58629f_000087_3953ef98>
  40ff4a:	cmp    BYTE PTR [rax+0x2c],0xe
  40ff4e:	jne    40ff84 <__swc_fn_ff58629f_000092_c1c9085b+0xe4>
  40ff50:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  40ff55:	lea    r8,[r13+rcx*1+0x0]
  40ff5a:	mov    rcx,rdi
  40ff5d:	mov    rdx,rax
  40ff60:	mov    r9,r14
  40ff63:	mov    r12,QWORD PTR [rsp+0x68]
  40ff68:	mov    r10,r12
  40ff6b:	call   40fea0 <__swc_fn_ff58629f_000092_c1c9085b>
  40ff70:	test   rax,rax
  40ff73:	je     40ff84 <__swc_fn_ff58629f_000092_c1c9085b+0xe4>
  40ff75:	add    rsp,0x78
  40ff79:	pop    r15
  40ff7b:	pop    r14
  40ff7d:	pop    r13
  40ff7f:	pop    r12
  40ff81:	pop    rdi
  40ff82:	pop    rsi
  40ff83:	ret
  40ff84:	add    rsi,0x1
  40ff88:	mov    rax,QWORD PTR [rsp+0x70]
  40ff8d:	sub    rax,0x1
  40ff91:	mov    r12,rax
  40ff94:	test   rax,rax
  40ff97:	jne    40ff30 <__swc_fn_ff58629f_000092_c1c9085b+0x90>
  40ff99:	xor    eax,eax
  40ff9b:	add    rsp,0x78
  40ff9f:	pop    r15
  40ffa1:	pop    r14
  40ffa3:	pop    r13
  40ffa5:	pop    r12
  40ffa7:	pop    rdi
  40ffa8:	pop    rsi
  40ffa9:	ret
	...

000000000040ffc0 <__swc_fn_ff58629f_000095_63c1827b>:
  40ffc0:	push   rbx
  40ffc1:	push   rsi
  40ffc2:	push   rdi
  40ffc3:	push   r12
  40ffc5:	push   r13
  40ffc7:	push   r14
  40ffc9:	push   r15
  40ffcb:	sub    rsp,0x120
  40ffd2:	mov    rbx,r8
  40ffd5:	mov    rsi,rdx
  40ffd8:	test   rcx,rcx
  40ffdb:	jne    40fffa <__swc_fn_ff58629f_000095_63c1827b+0x3a>
  40ffdd:	test   rsi,rsi
  40ffe0:	jne    40fffa <__swc_fn_ff58629f_000095_63c1827b+0x3a>
  40ffe2:	mov    eax,0x1
  40ffe7:	add    rsp,0x120
  40ffee:	pop    r15
  40fff0:	pop    r14
  40fff2:	pop    r13
  40fff4:	pop    r12
  40fff6:	pop    rdi
  40fff7:	pop    rsi
  40fff8:	pop    rbx
  40fff9:	ret
  40fffa:	test   rcx,rcx
  40fffd:	je     410004 <__swc_fn_ff58629f_000095_63c1827b+0x44>
  40ffff:	test   rsi,rsi
  410002:	jne    410019 <__swc_fn_ff58629f_000095_63c1827b+0x59>
  410004:	xor    eax,eax
  410006:	add    rsp,0x120
  41000d:	pop    r15
  41000f:	pop    r14
  410011:	pop    r13
  410013:	pop    r12
  410015:	pop    rdi
  410016:	pop    rsi
  410017:	pop    rbx
  410018:	ret
  410019:	call   409060 <__swc_fn_ff58629f_000087_3953ef98>
  41001e:	mov    rdi,rax
  410021:	mov    rcx,rsi
  410024:	call   409060 <__swc_fn_ff58629f_000087_3953ef98>
  410029:	test   bl,0x1
  41002c:	je     41006a <__swc_fn_ff58629f_000095_63c1827b+0xaa>
  41002e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  410033:	jne    41006a <__swc_fn_ff58629f_000095_63c1827b+0xaa>
  410035:	mov    ecx,DWORD PTR [rdi+0x28]
  410038:	test   ecx,0x1000
  41003e:	je     41006a <__swc_fn_ff58629f_000095_63c1827b+0xaa>
  410040:	test   ecx,0x10000
  410046:	je     41006a <__swc_fn_ff58629f_000095_63c1827b+0xaa>
  410048:	mov    rcx,QWORD PTR [rdi+0x40]
  41004c:	mov    rdx,rax
  41004f:	mov    r8d,ebx
  410052:	call   40ffc0 <__swc_fn_ff58629f_000095_63c1827b>
  410057:	add    rsp,0x120
  41005e:	pop    r15
  410060:	pop    r14
  410062:	pop    r13
  410064:	pop    r12
  410066:	pop    rdi
  410067:	pop    rsi
  410068:	pop    rbx
  410069:	ret
  41006a:	mov    cl,BYTE PTR [rax+0x2c]
  41006d:	rex cmp BYTE PTR [rdi+0x2c],cl
  410071:	jne    41007b <__swc_fn_ff58629f_000095_63c1827b+0xbb>
  410073:	mov    ecx,DWORD PTR [rax+0x20]
  410076:	cmp    DWORD PTR [rdi+0x20],ecx
  410079:	je     410090 <__swc_fn_ff58629f_000095_63c1827b+0xd0>
  41007b:	xor    eax,eax
  41007d:	add    rsp,0x120
  410084:	pop    r15
  410086:	pop    r14
  410088:	pop    r13
  41008a:	pop    r12
  41008c:	pop    rdi
  41008d:	pop    rsi
  41008e:	pop    rbx
  41008f:	ret
  410090:	mov    ecx,DWORD PTR [rdi+0x28]
  410093:	and    ecx,0xffb5ffff
  410099:	mov    edx,DWORD PTR [rax+0x28]
  41009c:	and    edx,0xffb5ffff
  4100a2:	cmp    ecx,edx
  4100a4:	je     4100bb <__swc_fn_ff58629f_000095_63c1827b+0xfb>
  4100a6:	xor    eax,eax
  4100a8:	add    rsp,0x120
  4100af:	pop    r15
  4100b1:	pop    r14
  4100b3:	pop    r13
  4100b5:	pop    r12
  4100b7:	pop    rdi
  4100b8:	pop    rsi
  4100b9:	pop    rbx
  4100ba:	ret
  4100bb:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4100c0:	jne    410115 <__swc_fn_ff58629f_000095_63c1827b+0x155>
  4100c2:	mov    cl,BYTE PTR [rax+0x40]
  4100c5:	rex cmp BYTE PTR [rdi+0x40],cl
  4100c9:	je     4100e0 <__swc_fn_ff58629f_000095_63c1827b+0x120>
  4100cb:	xor    eax,eax
  4100cd:	add    rsp,0x120
  4100d4:	pop    r15
  4100d6:	pop    r14
  4100d8:	pop    r13
  4100da:	pop    r12
  4100dc:	pop    rdi
  4100dd:	pop    rsi
  4100de:	pop    rbx
  4100df:	ret
  4100e0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4100e5:	je     4100fd <__swc_fn_ff58629f_000095_63c1827b+0x13d>
  4100e7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4100ec:	sete   cl
  4100ef:	je     4100f9 <__swc_fn_ff58629f_000095_63c1827b+0x139>
  4100f1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4100f6:	sete   cl
  4100f9:	test   cl,cl
  4100fb:	je     410115 <__swc_fn_ff58629f_000095_63c1827b+0x155>
  4100fd:	mov    eax,0x1
  410102:	add    rsp,0x120
  410109:	pop    r15
  41010b:	pop    r14
  41010d:	pop    r13
  41010f:	pop    r12
  410111:	pop    rdi
  410112:	pop    rsi
  410113:	pop    rbx
  410114:	ret
  410115:	test   DWORD PTR [rdi+0x28],0x200200
  41011c:	je     4102cf <__swc_fn_ff58629f_000095_63c1827b+0x30f>
  410122:	mov    rsi,QWORD PTR [rdi+0x88]
  410129:	mov    rdi,QWORD PTR [rdi+0x90]
  410130:	mov    r12,QWORD PTR [rax+0x88]
  410137:	mov    rax,QWORD PTR [rax+0x90]
  41013e:	cmp    rdi,rax
  410141:	je     410158 <__swc_fn_ff58629f_000095_63c1827b+0x198>
  410143:	xor    eax,eax
  410145:	add    rsp,0x120
  41014c:	pop    r15
  41014e:	pop    r14
  410150:	pop    r13
  410152:	pop    r12
  410154:	pop    rdi
  410155:	pop    rsi
  410156:	pop    rbx
  410157:	ret
  410158:	test   rsi,rsi
  41015b:	je     410162 <__swc_fn_ff58629f_000095_63c1827b+0x1a2>
  41015d:	test   r12,r12
  410160:	jne    41017a <__swc_fn_ff58629f_000095_63c1827b+0x1ba>
  410162:	mov    eax,0x1
  410167:	add    rsp,0x120
  41016e:	pop    r15
  410170:	pop    r14
  410172:	pop    r13
  410174:	pop    r12
  410176:	pop    rdi
  410177:	pop    rsi
  410178:	pop    rbx
  410179:	ret
  41017a:	xor    r13d,r13d
  41017d:	test   rdi,rdi
  410180:	jbe    4102b7 <__swc_fn_ff58629f_000095_63c1827b+0x2f7>
  410186:	lea    r14,[rsp+0x78]
  41018b:	lea    r15,[rsp+0xb8]
  410193:	cs nop WORD PTR [rax+rax*1+0x0]
  41019d:	cs nop WORD PTR [rax+rax*1+0x0]
  4101a7:	nop    WORD PTR [rax+rax*1+0x0]
  4101b0:	lea    rax,[r13*8+0x0]
  4101b8:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  4101bd:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4101c3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4101c9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4101d2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4101d8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4101e1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4101e7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4101f0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4101f6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4101ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  410206:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  41020f:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  410216:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  41021f:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  410226:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  41022f:	xor    al,al
  410231:	rex test BYTE PTR [rsp+0xb0],0x1
  41023a:	je     410241 <__swc_fn_ff58629f_000095_63c1827b+0x281>
  41023c:	mov    eax,0x1
  410241:	rex test BYTE PTR [rsp+0xf0],0x1
  41024a:	je     410251 <__swc_fn_ff58629f_000095_63c1827b+0x291>
  41024c:	mov    eax,0x1
  410251:	test   al,al
  410253:	jne    410279 <__swc_fn_ff58629f_000095_63c1827b+0x2b9>
  410255:	mov    rcx,r14
  410258:	mov    rdx,r15
  41025b:	call   4117d0 <__swc_fn_ff58629f_000152_6fb05988>
  410260:	test   al,al
  410262:	jne    410279 <__swc_fn_ff58629f_000095_63c1827b+0x2b9>
  410264:	xor    eax,eax
  410266:	add    rsp,0x120
  41026d:	pop    r15
  41026f:	pop    r14
  410271:	pop    r13
  410273:	pop    r12
  410275:	pop    rdi
  410276:	pop    rsi
  410277:	pop    rbx
  410278:	ret
  410279:	mov    rcx,QWORD PTR [rsp+0x88]
  410281:	mov    rdx,QWORD PTR [rsp+0xc8]
  410289:	mov    r8d,ebx
  41028c:	call   40ffc0 <__swc_fn_ff58629f_000095_63c1827b>
  410291:	test   al,al
  410293:	jne    4102aa <__swc_fn_ff58629f_000095_63c1827b+0x2ea>
  410295:	xor    eax,eax
  410297:	add    rsp,0x120
  41029e:	pop    r15
  4102a0:	pop    r14
  4102a2:	pop    r13
  4102a4:	pop    r12
  4102a6:	pop    rdi
  4102a7:	pop    rsi
  4102a8:	pop    rbx
  4102a9:	ret
  4102aa:	add    r13,0x1
  4102ae:	cmp    r13,rdi
  4102b1:	jb     4101b0 <__swc_fn_ff58629f_000095_63c1827b+0x1f0>
  4102b7:	mov    eax,0x1
  4102bc:	add    rsp,0x120
  4102c3:	pop    r15
  4102c5:	pop    r14
  4102c7:	pop    r13
  4102c9:	pop    r12
  4102cb:	pop    rdi
  4102cc:	pop    rsi
  4102cd:	pop    rbx
  4102ce:	ret
  4102cf:	test   bl,0x2
  4102d2:	je     4102f4 <__swc_fn_ff58629f_000095_63c1827b+0x334>
  4102d4:	lea    rcx,[rdi+0x10]
  4102d8:	lea    rdx,[rax+0x10]
  4102dc:	call   4117d0 <__swc_fn_ff58629f_000152_6fb05988>
  4102e1:	add    rsp,0x120
  4102e8:	pop    r15
  4102ea:	pop    r14
  4102ec:	pop    r13
  4102ee:	pop    r12
  4102f0:	pop    rdi
  4102f1:	pop    rsi
  4102f2:	pop    rbx
  4102f3:	ret
  4102f4:	mov    rcx,rdi
  4102f7:	mov    rdx,rax
  4102fa:	call   4117d0 <__swc_fn_ff58629f_000152_6fb05988>
  4102ff:	add    rsp,0x120
  410306:	pop    r15
  410308:	pop    r14
  41030a:	pop    r13
  41030c:	pop    r12
  41030e:	pop    rdi
  41030f:	pop    rsi
  410310:	pop    rbx
  410311:	ret
	...

0000000000410320 <__swc_fn_ff58629f_000098_4185993f>:
  410320:	push   rbx
  410321:	mov    rbx,rcx
  410324:	call   409190 <__swc_fn_ff58629f_000096_ad13d15c>
  410329:	movzx  r11d,al
  41032d:	mov    r8b,r11b
  410330:	test   r8b,r8b
  410333:	jne    41034d <__swc_fn_ff58629f_000098_4185993f+0x2d>
  410335:	mov    r11d,0x1
  41033b:	mov    r10,rbx
  41033e:	mov    r9,r11
  410341:	and    r10,r11
  410344:	test   r10,r10
  410347:	setne  dl
  41034a:	mov    r8b,dl
  41034d:	mov    r10b,r8b
  410350:	test   r10b,r10b
  410353:	je     410357 <__swc_fn_ff58629f_000098_4185993f+0x37>
  410355:	pop    rbx
  410356:	ret
  410357:	call   40d140 <__swc_fn_ff58629f_000142_519fdf94>
  41035c:	movzx  r10d,al
  410360:	test   r10b,r10b
  410363:	je     410367 <__swc_fn_ff58629f_000098_4185993f+0x47>
  410365:	pop    rbx
  410366:	ret
  410367:	lea    r10,[rip+0x1f7a]        # 4122e8 <__swc_rdata_base_ff58629f+0x1d8>
  41036e:	mov    rax,r10
  410371:	mov    rcx,rax
  410374:	call   40cc70 <__swc_fn_ff58629f_000121_2648f149>
  410379:	call   409a10 <__swc_fn_ff58629f_000123_be2e2f68>
  41037e:	pop    rbx
  41037f:	ret

0000000000410380 <__swc_fn_ff58629f_000101_d4bdcaa4>:
  410380:	push   rbx
  410381:	sub    rsp,0x70
  410385:	vxorps xmm0,xmm0,xmm0
  410389:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  41038f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  410395:	vzeroupper
  410398:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  41039e:	mov    QWORD PTR [rsp+0x48],rdx
  4103a3:	mov    rax,r8
  4103a6:	cmp    r8,0x1
  4103aa:	mov    edx,0x1
  4103af:	cmovb  rax,rdx
  4103b3:	mov    QWORD PTR [rsp+0x50],rax
  4103b8:	mov    rbx,QWORD PTR [rcx+0x8]
  4103bc:	mov    rbx,QWORD PTR [rbx+0x18]
  4103c0:	mov    rcx,QWORD PTR [rcx]
  4103c3:	lea    rdx,[rsp+0x8]
  4103c8:	call   rbx
  4103ca:	add    rsp,0x70
  4103ce:	pop    rbx
  4103cf:	ret

00000000004103d0 <__swc_fn_ff58629f_000104_2fdd2c61>:
  4103d0:	push   rbx
  4103d1:	push   rsi
  4103d2:	push   rdi
  4103d3:	sub    rsp,0x30
  4103d7:	mov    rbx,rcx
  4103da:	test   rcx,rcx
  4103dd:	je     4103f2 <__swc_fn_ff58629f_000104_2fdd2c61+0x22>
  4103df:	mov    rcx,rbx
  4103e2:	mov    edx,0x1
  4103e7:	call   40fc20 <__swc_fn_ff58629f_000083_63a67586>
  4103ec:	cmp    rax,0x1
  4103f0:	je     4103fa <__swc_fn_ff58629f_000104_2fdd2c61+0x2a>
  4103f2:	add    rsp,0x30
  4103f6:	pop    rdi
  4103f7:	pop    rsi
  4103f8:	pop    rbx
  4103f9:	ret
  4103fa:	lea    rsi,[rsp+0x8]
  4103ff:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  410404:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  41040a:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  41040f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  410415:	mov    rax,QWORD PTR [rsp+0x20]
  41041a:	test   rax,rax
  41041d:	je     410433 <__swc_fn_ff58629f_000104_2fdd2c61+0x63>
  41041f:	test   DWORD PTR [rax+0x28],0x400000
  410426:	je     410433 <__swc_fn_ff58629f_000104_2fdd2c61+0x63>
  410428:	mov    rcx,QWORD PTR [rax+0x30]
  41042c:	test   rcx,rcx
  41042f:	cmovne rax,rcx
  410433:	mov    edi,DWORD PTR [rax+0x20]
  410436:	lea    rcx,[rsp+0x18]
  41043b:	call   409370 <__swc_fn_ff58629f_000105_3c3b96fb>
  410440:	mov    rcx,rsi
  410443:	mov    rdx,QWORD PTR [rsp+0x18]
  410448:	mov    r8,rdi
  41044b:	call   410380 <__swc_fn_ff58629f_000101_d4bdcaa4>
  410450:	mov    rcx,QWORD PTR [rbx+0x28]
  410454:	call   40c220 <__swc_fn_ff58629f_000103_e34f54dc>
  410459:	mov    rcx,rsi
  41045c:	mov    rdx,rbx
  41045f:	mov    r8d,0x30
  410465:	call   410380 <__swc_fn_ff58629f_000101_d4bdcaa4>
  41046a:	add    rsp,0x30
  41046e:	pop    rdi
  41046f:	pop    rsi
  410470:	pop    rbx
  410471:	ret
	...

0000000000410480 <__swc_fn_ff58629f_000107_ffe51047>:
  410480:	push   rbp
  410481:	push   rbx
  410482:	push   rsi
  410483:	push   rdi
  410484:	push   r12
  410486:	push   r13
  410488:	push   r14
  41048a:	push   r15
  41048c:	sub    rsp,0x500
  410493:	mov    rbp,rsp
  410496:	mov    rbx,rsp
  410499:	mov    rsi,rdx
  41049c:	mov    rdi,rcx
  41049f:	mov    rcx,QWORD PTR [rip+0x12b9a]        # 423040 <__swc_bss_base_ff58629f>
  4104a6:	test   rcx,rcx
  4104a9:	jne    4104c3 <__swc_fn_ff58629f_000107_ffe51047+0x43>
  4104ab:	sub    rsp,0x8
  4104af:	call   411bc0 <__swc_fn_ff58629f_000170_994c8876>
  4104b4:	add    rsp,0x8
  4104b8:	lea    rcx,[rax+0x1]
  4104bc:	mov    QWORD PTR [rip+0x12b7d],rcx        # 423040 <__swc_bss_base_ff58629f>
  4104c3:	dec    rcx
  4104c6:	sub    rsp,0x8
  4104ca:	call   40ea20 <__swc_fn_ff58629f_000172_360af05d>
  4104cf:	add    rsp,0x8
  4104d3:	mov    r12,rax
  4104d6:	mov    QWORD PTR [rsp+0x4f0],rax
  4104de:	lea    rax,[rip+0x1f43]        # 412428 <__swc_rdata_base_ff58629f+0x318>
  4104e5:	sub    rsp,0x20
  4104e9:	mov    rcx,rsp
  4104ec:	mov    QWORD PTR [rcx],rax
  4104ef:	lea    r13,[rip+0x1c3a]        # 412130 <__swc_rdata_base_ff58629f+0x20>
  4104f6:	mov    QWORD PTR [rcx+0x8],r13
  4104fa:	mov    QWORD PTR [rcx+0x10],rsp
  4104fe:	mov    QWORD PTR [rcx+0x18],0x1
  410506:	lea    rcx,[rsp+0x10]
  41050b:	sub    rsp,0x8
  41050f:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  410514:	add    rsp,0x8
  410518:	add    rsp,0x20
  41051c:	lea    rax,[rip+0x1f15]        # 412438 <__swc_rdata_base_ff58629f+0x328>
  410523:	sub    rsp,0x20
  410527:	mov    rcx,rsp
  41052a:	mov    QWORD PTR [rcx],rax
  41052d:	mov    QWORD PTR [rcx+0x8],r13
  410531:	mov    QWORD PTR [rcx+0x10],rsp
  410535:	mov    QWORD PTR [rcx+0x18],0x1
  41053d:	lea    rcx,[rsp+0x10]
  410542:	sub    rsp,0x8
  410546:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  41054b:	add    rsp,0x8
  41054f:	add    rsp,0x20
  410553:	lea    r14,[rip+0x1bc6]        # 412120 <__swc_rdata_base_ff58629f+0x10>
  41055a:	sub    rsp,0x50
  41055e:	mov    rax,rsp
  410561:	vmovups xmm0,XMMWORD PTR [rip+0x2007]        # 412570 <__swc_rdata_base_ff58629f+0x460>
  410569:	vmovups XMMWORD PTR [rax],xmm0
  41056d:	mov    QWORD PTR [rax+0x10],rsp
  410571:	mov    QWORD PTR [rax+0x18],r13
  410575:	mov    QWORD PTR [rax+0x20],rdi
  410579:	lea    rdi,[rip+0x1ec8]        # 412448 <__swc_rdata_base_ff58629f+0x338>
  410580:	mov    QWORD PTR [rax+0x28],rdi
  410584:	mov    QWORD PTR [rax+0x30],r14
  410588:	mov    QWORD PTR [rax+0x38],r13
  41058c:	lea    rcx,[rsp+0x10]
  410591:	mov    QWORD PTR [rax+0x40],rcx
  410595:	mov    QWORD PTR [rax+0x48],0x3
  41059d:	lea    rcx,[rsp+0x40]
  4105a2:	sub    rsp,0x8
  4105a6:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  4105ab:	add    rsp,0x8
  4105af:	add    rsp,0x50
  4105b3:	lea    rax,[rip+0x1ed6]        # 412490 <__swc_rdata_base_ff58629f+0x380>
  4105ba:	sub    rsp,0x20
  4105be:	mov    rcx,rsp
  4105c1:	mov    QWORD PTR [rcx],rax
  4105c4:	mov    QWORD PTR [rcx+0x8],r13
  4105c8:	mov    QWORD PTR [rcx+0x10],rsp
  4105cc:	mov    QWORD PTR [rcx+0x18],0x1
  4105d4:	lea    rcx,[rsp+0x10]
  4105d9:	sub    rsp,0x8
  4105dd:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  4105e2:	add    rsp,0x8
  4105e6:	add    rsp,0x20
  4105ea:	mov    eax,DWORD PTR [rsi+0x20]
  4105ed:	mov    ecx,DWORD PTR [rsi+0x24]
  4105f0:	sub    rsp,0xa0
  4105f7:	mov    rdx,rsp
  4105fa:	mov    QWORD PTR [rdx+0x30],rsi
  4105fe:	mov    QWORD PTR [rdx+0x38],rdi
  410602:	vmovups xmm0,XMMWORD PTR [rip+0x1efe]        # 412508 <__swc_rdata_base_ff58629f+0x3f8>
  41060a:	vmovups XMMWORD PTR [rdx],xmm0
  41060e:	mov    QWORD PTR [rdx+0x40],rsp
  410612:	mov    QWORD PTR [rdx+0x48],r13
  410616:	mov    DWORD PTR [rdx+0x10],eax
  410619:	lea    rax,[rsp+0x10]
  41061e:	mov    QWORD PTR [rdx+0x50],rax
  410622:	lea    rax,[rip+0x1e77]        # 4124a0 <__swc_rdata_base_ff58629f+0x390>
  410629:	mov    QWORD PTR [rdx+0x58],rax
  41062d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  410632:	lea    r8,[rsp+0x18]
  410637:	mov    QWORD PTR [rdx+0x60],r8
  41063b:	mov    QWORD PTR [rdx+0x68],r13
  41063f:	mov    DWORD PTR [rdx+0x28],ecx
  410642:	lea    rcx,[rdx+0x28]
  410646:	mov    QWORD PTR [rdx+0x70],rcx
  41064a:	mov    QWORD PTR [rdx+0x78],rax
  41064e:	mov    QWORD PTR [rdx+0x80],r14
  410655:	mov    QWORD PTR [rdx+0x88],r13
  41065c:	lea    rax,[rdx+0x30]
  410660:	mov    QWORD PTR [rdx+0x90],rax
  410667:	mov    QWORD PTR [rdx+0x98],0x6
  410672:	lea    rcx,[rdx+0x90]
  410679:	sub    rsp,0x8
  41067d:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  410682:	add    rsp,0x8
  410686:	add    rsp,0xa0
  41068d:	sub    rsp,0x20
  410691:	mov    rax,rsp
  410694:	mov    QWORD PTR [rax],r14
  410697:	mov    QWORD PTR [rax+0x8],r13
  41069b:	mov    QWORD PTR [rax+0x10],rsp
  41069f:	mov    QWORD PTR [rax+0x18],0x1
  4106a7:	lea    rcx,[rsp+0x10]
  4106ac:	sub    rsp,0x8
  4106b0:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  4106b5:	add    rsp,0x8
  4106b9:	add    rsp,0x20
  4106bd:	mov    eax,DWORD PTR [r12+0x9ac]
  4106c5:	test   eax,eax
  4106c7:	je     410900 <__swc_fn_ff58629f_000107_ffe51047+0x480>
  4106cd:	lea    rax,[rip+0x1e14]        # 4124e8 <__swc_rdata_base_ff58629f+0x3d8>
  4106d4:	sub    rsp,0x20
  4106d8:	mov    rcx,rsp
  4106db:	mov    QWORD PTR [rcx],rax
  4106de:	mov    QWORD PTR [rcx+0x8],r13
  4106e2:	mov    QWORD PTR [rcx+0x10],rsp
  4106e6:	mov    QWORD PTR [rcx+0x18],0x1
  4106ee:	lea    rcx,[rsp+0x10]
  4106f3:	sub    rsp,0x8
  4106f7:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  4106fc:	add    rsp,0x8
  410700:	add    rsp,0x20
  410704:	mov    eax,DWORD PTR [r12+0x9ac]
  41070c:	dec    eax
  41070e:	mov    esi,eax
  410710:	test   esi,esi
  410712:	jl     4108d0 <__swc_fn_ff58629f_000107_ffe51047+0x450>
  410718:	jmp    410724 <__swc_fn_ff58629f_000107_ffe51047+0x2a4>
  41071a:	nop    WORD PTR [rax+rax*1+0x0]
  410720:	dec    esi
  410722:	jmp    410710 <__swc_fn_ff58629f_000107_ffe51047+0x290>
  410724:	lea    rax,[rip+0x1dcd]        # 4124f8 <__swc_rdata_base_ff58629f+0x3e8>
  41072b:	sub    rsp,0x20
  41072f:	mov    rcx,rsp
  410732:	mov    QWORD PTR [rcx],rax
  410735:	mov    QWORD PTR [rcx+0x8],r13
  410739:	mov    QWORD PTR [rcx+0x10],rsp
  41073d:	mov    QWORD PTR [rcx+0x18],0x1
  410745:	lea    rcx,[rsp+0x10]
  41074a:	sub    rsp,0x8
  41074e:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  410753:	add    rsp,0x8
  410757:	add    rsp,0x20
  41075b:	movsxd rax,esi
  41075e:	imul   r15,rax,0x30
  410762:	add    r15,r12
  410765:	add    r15,0xf8
  41076c:	sub    rsp,0x20
  410770:	mov    rax,rsp
  410773:	mov    QWORD PTR [rax],r15
  410776:	mov    QWORD PTR [rax+0x8],rdi
  41077a:	mov    QWORD PTR [rax+0x10],rsp
  41077e:	mov    QWORD PTR [rax+0x18],0x1
  410786:	lea    rcx,[rsp+0x10]
  41078b:	sub    rsp,0x8
  41078f:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  410794:	add    rsp,0x8
  410798:	add    rsp,0x20
  41079c:	mov    QWORD PTR [rsp+0x4f8],rsi
  4107a4:	lea    rsi,[rip+0x1d5d]        # 412508 <__swc_rdata_base_ff58629f+0x3f8>
  4107ab:	sub    rsp,0x20
  4107af:	mov    rax,rsp
  4107b2:	mov    QWORD PTR [rax],rsi
  4107b5:	mov    QWORD PTR [rax+0x8],r13
  4107b9:	mov    QWORD PTR [rax+0x10],rsp
  4107bd:	mov    QWORD PTR [rax+0x18],0x1
  4107c5:	lea    rcx,[rsp+0x10]
  4107ca:	sub    rsp,0x8
  4107ce:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  4107d3:	add    rsp,0x8
  4107d7:	add    rsp,0x20
  4107db:	sub    rsp,0x30
  4107df:	mov    rax,rsp
  4107e2:	mov    ecx,DWORD PTR [r15+0x20]
  4107e6:	mov    QWORD PTR [rax],rcx
  4107e9:	mov    QWORD PTR [rax+0x8],rsp
  4107ed:	lea    rdi,[rip+0x1d24]        # 412518 <__swc_rdata_base_ff58629f+0x408>
  4107f4:	mov    QWORD PTR [rax+0x10],rdi
  4107f8:	lea    rcx,[rsp+0x8]
  4107fd:	mov    QWORD PTR [rax+0x18],rcx
  410801:	mov    QWORD PTR [rax+0x20],0x1
  410809:	lea    rcx,[rsp+0x18]
  41080e:	sub    rsp,0x8
  410812:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  410817:	add    rsp,0x8
  41081b:	add    rsp,0x30
  41081f:	sub    rsp,0x20
  410823:	mov    rax,rsp
  410826:	mov    QWORD PTR [rax],rsi
  410829:	mov    QWORD PTR [rax+0x8],r13
  41082d:	mov    QWORD PTR [rax+0x10],rsp
  410831:	mov    QWORD PTR [rax+0x18],0x1
  410839:	lea    rcx,[rsp+0x10]
  41083e:	sub    rsp,0x8
  410842:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  410847:	add    rsp,0x8
  41084b:	add    rsp,0x20
  41084f:	sub    rsp,0x30
  410853:	mov    rax,rsp
  410856:	mov    ecx,DWORD PTR [r15+0x24]
  41085a:	mov    QWORD PTR [rax],rcx
  41085d:	mov    QWORD PTR [rax+0x8],rsp
  410861:	mov    QWORD PTR [rax+0x10],rdi
  410865:	lea    rcx,[rsp+0x8]
  41086a:	mov    QWORD PTR [rax+0x18],rcx
  41086e:	mov    QWORD PTR [rax+0x20],0x1
  410876:	lea    rcx,[rsp+0x18]
  41087b:	sub    rsp,0x8
  41087f:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  410884:	add    rsp,0x8
  410888:	add    rsp,0x30
  41088c:	sub    rsp,0x20
  410890:	mov    rax,rsp
  410893:	mov    QWORD PTR [rax],r14
  410896:	mov    QWORD PTR [rax+0x8],r13
  41089a:	mov    QWORD PTR [rax+0x10],rsp
  41089e:	mov    QWORD PTR [rax+0x18],0x1
  4108a6:	lea    rcx,[rsp+0x10]
  4108ab:	sub    rsp,0x8
  4108af:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  4108b4:	add    rsp,0x8
  4108b8:	add    rsp,0x20
  4108bc:	lea    rdi,[rip+0x1b85]        # 412448 <__swc_rdata_base_ff58629f+0x338>
  4108c3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  4108cb:	jmp    410720 <__swc_fn_ff58629f_000107_ffe51047+0x2a0>
  4108d0:	sub    rsp,0x20
  4108d4:	mov    rax,rsp
  4108d7:	mov    QWORD PTR [rax],r14
  4108da:	mov    QWORD PTR [rax+0x8],r13
  4108de:	mov    QWORD PTR [rax+0x10],rsp
  4108e2:	mov    QWORD PTR [rax+0x18],0x1
  4108ea:	lea    rcx,[rsp+0x10]
  4108ef:	sub    rsp,0x8
  4108f3:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  4108f8:	add    rsp,0x8
  4108fc:	add    rsp,0x20
  410900:	lea    rax,[rbx+0x28]
  410904:	mov    rcx,rax
  410907:	mov    QWORD PTR [rbx+0x28],0x0
  41090f:	mov    QWORD PTR [rbx+0x30],0x0
  410917:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  41091c:	add    rcx,0x10
  410920:	mov    edx,0x1f
  410925:	cs nop WORD PTR [rax+rax*1+0x0]
  41092f:	nop
  410930:	vmovups XMMWORD PTR [rcx],xmm0
  410934:	add    rcx,0x10
  410938:	sub    rdx,0x1
  41093c:	jne    410930 <__swc_fn_ff58629f_000107_ffe51047+0x4b0>
  41093e:	lea    rsi,[rbx+0x228]
  410945:	xor    ecx,ecx
  410947:	cs nop WORD PTR [rax+rax*1+0x0]
  410951:	cs nop WORD PTR [rax+rax*1+0x0]
  41095b:	nop    DWORD PTR [rax+rax*1+0x0]
  410960:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  410965:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  41096a:	add    rcx,0x10
  41096e:	cmp    rcx,0x200
  410975:	jne    410960 <__swc_fn_ff58629f_000107_ffe51047+0x4e0>
  410977:	mov    eax,DWORD PTR [r12+0xbc8]
  41097f:	lea    rcx,[r12+0x9c8]
  410987:	mov    QWORD PTR [rbx+0x428],rcx
  41098e:	mov    QWORD PTR [rbx+0x430],rax
  410995:	lea    rdi,[rbx+0x438]
  41099c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  4109a4:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  4109ac:	mov    eax,DWORD PTR [r12+0xbc8]
  4109b4:	test   eax,eax
  4109b6:	jne    410a03 <__swc_fn_ff58629f_000107_ffe51047+0x583>
  4109b8:	lea    rax,[rbx+0x448]
  4109bf:	mov    QWORD PTR [rbx+0x448],rsi
  4109c6:	mov    QWORD PTR [rax+0x8],0x40
  4109ce:	mov    ecx,0x1
  4109d3:	mov    rdx,rax
  4109d6:	sub    rsp,0x8
  4109da:	call   40cd80 <__swc_fn_ff58629f_000124_4f256d58>
  4109df:	add    rsp,0x8
  4109e3:	mov    QWORD PTR [rbx+0x460],rsi
  4109ea:	mov    ecx,eax
  4109ec:	mov    QWORD PTR [rbx+0x468],rcx
  4109f3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  4109fb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  410a03:	mov    rsi,QWORD PTR [rbx+0x438]
  410a0a:	mov    rax,QWORD PTR [rbx+0x440]
  410a11:	mov    r15,rax
  410a14:	xor    r12d,r12d
  410a17:	test   r15,r15
  410a1a:	je     410ad0 <__swc_fn_ff58629f_000107_ffe51047+0x650>
  410a20:	mov    rax,QWORD PTR [rsi+r12*8]
  410a24:	test   rax,rax
  410a27:	je     410a46 <__swc_fn_ff58629f_000107_ffe51047+0x5c6>
  410a29:	lea    rcx,[rbx+0x4b8]
  410a30:	mov    rdx,rax
  410a33:	sub    rsp,0x8
  410a37:	call   411930 <__swc_fn_ff58629f_000167_cc119975>
  410a3c:	add    rsp,0x8
  410a40:	mov    al,BYTE PTR [rax]
  410a42:	test   al,al
  410a44:	jne    410a52 <__swc_fn_ff58629f_000107_ffe51047+0x5d2>
  410a46:	add    r12,0x1
  410a4a:	sub    r15,0x1
  410a4e:	jne    410a20 <__swc_fn_ff58629f_000107_ffe51047+0x5a0>
  410a50:	jmp    410ad0 <__swc_fn_ff58629f_000107_ffe51047+0x650>
  410a52:	lea    rax,[rip+0x1b07]        # 412560 <__swc_rdata_base_ff58629f+0x450>
  410a59:	sub    rsp,0x20
  410a5d:	mov    rcx,rsp
  410a60:	mov    QWORD PTR [rcx],rax
  410a63:	mov    QWORD PTR [rcx+0x8],r13
  410a67:	mov    QWORD PTR [rcx+0x10],rsp
  410a6b:	mov    QWORD PTR [rcx+0x18],0x1
  410a73:	lea    rcx,[rsp+0x10]
  410a78:	sub    rsp,0x8
  410a7c:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  410a81:	add    rsp,0x8
  410a85:	add    rsp,0x20
  410a89:	mov    rcx,rdi
  410a8c:	xor    edx,edx
  410a8e:	mov    al,0x1
  410a90:	mov    r8,rax
  410a93:	sub    rsp,0x8
  410a97:	call   40a2a0 <__swc_fn_ff58629f_000168_bcc835b8>
  410a9c:	add    rsp,0x8
  410aa0:	sub    rsp,0x20
  410aa4:	mov    rax,rsp
  410aa7:	mov    QWORD PTR [rax],r14
  410aaa:	mov    QWORD PTR [rax+0x8],r13
  410aae:	mov    QWORD PTR [rax+0x10],rsp
  410ab2:	mov    QWORD PTR [rax+0x18],0x1
  410aba:	lea    rcx,[rsp+0x10]
  410abf:	sub    rsp,0x8
  410ac3:	call   40d4e0 <__swc_fn_ff58629f_000151_6203dca2>
  410ac8:	add    rsp,0x8
  410acc:	add    rsp,0x20
  410ad0:	mov    r12,QWORD PTR [rsp+0x4f0]
  410ad8:	mov    DWORD PTR [r12+0xbc8],0x0
  410ae4:	add    rsp,0x500
  410aeb:	pop    r15
  410aed:	pop    r14
  410aef:	pop    r13
  410af1:	pop    r12
  410af3:	pop    rdi
  410af4:	pop    rsi
  410af5:	pop    rbx
  410af6:	pop    rbp
  410af7:	ret
	...

0000000000410b00 <__swc_fn_ff58629f_000110_7c204aac>:
  410b00:	sub    rsp,0x8
  410b04:	test   r8,r8
  410b07:	je     410b0e <__swc_fn_ff58629f_000110_7c204aac+0xe>
  410b09:	call   40c4b0 <__swc_fn_ff58629f_000109_c51c3158>
  410b0e:	add    rsp,0x8
  410b12:	ret
	...

0000000000410b20 <__swc_fn_ff58629f_000113_126150d1>:
  410b20:	push   rsi
  410b21:	push   rdi
  410b22:	push   r12
  410b24:	push   r13
  410b26:	sub    rsp,0xd8
  410b2d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  410b33:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  410b39:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  410b3f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  410b45:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  410b4b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  410b54:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  410b5d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  410b66:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  410b6f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  410b78:	xor    eax,eax
  410b7a:	call   4070e0 <getpid@plt>
  410b7f:	mov    rsi,rax
  410b82:	lea    rdi,[rip+0x151b7]        # 425d40 <__swc_bss_base_ff58629f+0x2d00>
  410b89:	mov    r12,QWORD PTR [rdi]
  410b8c:	test   r12,r12
  410b8f:	je     410b9d <__swc_fn_ff58629f_000113_126150d1+0x7d>
  410b91:	cmp    DWORD PTR [r12+0x10],esi
  410b96:	jne    410b9d <__swc_fn_ff58629f_000113_126150d1+0x7d>
  410b98:	mov    rax,r12
  410b9b:	jmp    410c00 <__swc_fn_ff58629f_000113_126150d1+0xe0>
  410b9d:	mov    ecx,0x4
  410ba2:	mov    edx,0x18
  410ba7:	call   40c590 <__swc_fn_ff58629f_000112_6814119b>
  410bac:	mov    rcx,rax
  410baf:	test   rax,rax
  410bb2:	jne    410bb8 <__swc_fn_ff58629f_000113_126150d1+0x98>
  410bb4:	xor    eax,eax
  410bb6:	jmp    410c00 <__swc_fn_ff58629f_000113_126150d1+0xe0>
  410bb8:	mov    DWORD PTR [rcx+0x10],esi
  410bbb:	mov    rax,r12
  410bbe:	lock cmpxchg QWORD PTR [rdi],rcx
  410bc3:	mov    r13,rax
  410bc6:	cmp    rax,r12
  410bc9:	je     410bdf <__swc_fn_ff58629f_000113_126150d1+0xbf>
  410bcb:	mov    rdi,rcx
  410bce:	mov    esi,0x18
  410bd3:	xor    eax,eax
  410bd5:	call   407030 <munmap@plt>
  410bda:	mov    rax,r13
  410bdd:	jmp    410c00 <__swc_fn_ff58629f_000113_126150d1+0xe0>
  410bdf:	test   r12,r12
  410be2:	je     410bfd <__swc_fn_ff58629f_000113_126150d1+0xdd>
  410be4:	mov    rdi,r12
  410be7:	mov    esi,0x18
  410bec:	xor    eax,eax
  410bee:	mov    QWORD PTR [rsp+0x28],rcx
  410bf3:	call   407030 <munmap@plt>
  410bf8:	mov    rcx,QWORD PTR [rsp+0x28]
  410bfd:	mov    rax,rcx
  410c00:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  410c06:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  410c0c:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  410c12:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  410c18:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  410c1e:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  410c27:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  410c30:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  410c39:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  410c42:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  410c4b:	add    rsp,0xd8
  410c52:	pop    r13
  410c54:	pop    r12
  410c56:	pop    rdi
  410c57:	pop    rsi
  410c58:	ret
  410c59:	add    BYTE PTR [rax],al
  410c5b:	add    BYTE PTR [rax],al
  410c5d:	add    BYTE PTR [rax],al
	...

0000000000410c60 <__swc_fn_ff58629f_000116_36905703>:
  410c60:	push   rbx
  410c61:	push   r12
  410c63:	push   rdi
  410c64:	push   rsi
  410c65:	sub    rsp,0xa8
  410c6c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  410c72:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410c78:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  410c7e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410c84:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410c8a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  410c90:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410c96:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410c9c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410ca5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  410cae:	mov    rbx,rdx
  410cb1:	mov    r12,rcx
  410cb4:	mov    rdi,rcx
  410cb7:	mov    rsi,rdx
  410cba:	mov    edx,0x3
  410cbf:	xor    eax,eax
  410cc1:	call   407020 <mprotect@plt>
  410cc6:	test   eax,eax
  410cc8:	je     410cce <__swc_fn_ff58629f_000116_36905703+0x6e>
  410cca:	xor    eax,eax
  410ccc:	jmp    410ce3 <__swc_fn_ff58629f_000116_36905703+0x83>
  410cce:	mov    rcx,r12
  410cd1:	mov    rdx,rbx
  410cd4:	mov    al,0x1
  410cd6:	mov    r8,rax
  410cd9:	call   40cbc0 <__swc_fn_ff58629f_000115_5f48311c>
  410cde:	mov    eax,0x1
  410ce3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410ce9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410cef:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410cf5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410cfb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410d01:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410d07:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410d0d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410d13:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410d1c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410d25:	add    rsp,0xa8
  410d2c:	pop    rsi
  410d2d:	pop    rdi
  410d2e:	pop    r12
  410d30:	pop    rbx
  410d31:	ret
	...

0000000000410d40 <__swc_fn_ff58629f_000119_5208f471>:
  410d40:	sub    rsp,0x8
  410d44:	test   rcx,rcx
  410d47:	jne    410d4e <__swc_fn_ff58629f_000119_5208f471+0xe>
  410d49:	add    rsp,0x8
  410d4d:	ret
  410d4e:	call   4098c0 <__swc_fn_ff58629f_000120_d3318640>
  410d53:	add    rsp,0x8
  410d57:	ret
	...

0000000000410d60 <__swc_fn_ff58629f_000122_0a5fa85a>:
  410d60:	push   rdi
  410d61:	push   rsi
  410d62:	sub    rsp,0xa8
  410d69:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  410d6f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410d75:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  410d7b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410d81:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410d87:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  410d8d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410d93:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410d99:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410da2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  410dab:	xor    edi,edi
  410dad:	xor    eax,eax
  410daf:	call   407050 <exit@plt>
  410db4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410dba:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410dc0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410dc6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410dcc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410dd2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410dd8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410dde:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410de4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410ded:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410df6:	add    rsp,0xa8
  410dfd:	pop    rsi
  410dfe:	pop    rdi
  410dff:	ret

0000000000410e00 <__swc_fn_ff58629f_000125_83db7238>:
  410e00:	push   rbx
  410e01:	push   rsi
  410e02:	push   rdi
  410e03:	push   r12
  410e05:	sub    rsp,0x18
  410e09:	mov    rbx,r8
  410e0c:	mov    rsi,rcx
  410e0f:	mov    rdi,rdx
  410e12:	mov    rcx,QWORD PTR [rip+0x12227]        # 423040 <__swc_bss_base_ff58629f>
  410e19:	test   rcx,rcx
  410e1c:	jne    410e2e <__swc_fn_ff58629f_000125_83db7238+0x2e>
  410e1e:	call   411bc0 <__swc_fn_ff58629f_000170_994c8876>
  410e23:	lea    rcx,[rax+0x1]
  410e27:	mov    QWORD PTR [rip+0x12212],rcx        # 423040 <__swc_bss_base_ff58629f>
  410e2e:	dec    rcx
  410e31:	call   40ea20 <__swc_fn_ff58629f_000172_360af05d>
  410e36:	mov    r12,rax
  410e39:	cmp    ebx,0x3
  410e3c:	jne    410e4f <__swc_fn_ff58629f_000125_83db7238+0x4f>
  410e3e:	mov    rax,QWORD PTR [r12+0xbd0]
  410e46:	test   rax,rax
  410e49:	jne    410f8c <__swc_fn_ff58629f_000125_83db7238+0x18c>
  410e4f:	cmp    ebx,0x5
  410e52:	jne    410e76 <__swc_fn_ff58629f_000125_83db7238+0x76>
  410e54:	call   409190 <__swc_fn_ff58629f_000096_ad13d15c>
  410e59:	test   al,al
  410e5b:	jne    410e76 <__swc_fn_ff58629f_000125_83db7238+0x76>
  410e5d:	mov    rcx,rsi
  410e60:	mov    rdx,rdi
  410e63:	call   40e9d0 <__swc_fn_ff58629f_000169_3459066f>
  410e68:	test   al,al
  410e6a:	je     410e76 <__swc_fn_ff58629f_000125_83db7238+0x76>
  410e6c:	add    rsp,0x18
  410e70:	pop    r12
  410e72:	pop    rdi
  410e73:	pop    rsi
  410e74:	pop    rbx
  410e75:	ret
  410e76:	call   409190 <__swc_fn_ff58629f_000096_ad13d15c>
  410e7b:	test   al,al
  410e7d:	jne    410eef <__swc_fn_ff58629f_000125_83db7238+0xef>
  410e7f:	vmovups xmm0,XMMWORD PTR [rsi]
  410e83:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410e89:	mov    rax,QWORD PTR [rsp+0x8]
  410e8e:	test   rax,rax
  410e91:	jne    410ee2 <__swc_fn_ff58629f_000125_83db7238+0xe2>
  410e93:	cmp    ebx,0x3
  410e96:	je     410ea4 <__swc_fn_ff58629f_000125_83db7238+0xa4>
  410e98:	cmp    ebx,0x4
  410e9b:	je     410eb4 <__swc_fn_ff58629f_000125_83db7238+0xb4>
  410e9d:	cmp    ebx,0x5
  410ea0:	je     410ec4 <__swc_fn_ff58629f_000125_83db7238+0xc4>
  410ea2:	jmp    410ed4 <__swc_fn_ff58629f_000125_83db7238+0xd4>
  410ea4:	vmovups xmm0,XMMWORD PTR [rip+0x1704]        # 4125b0 <__swc_rdata_base_ff58629f+0x4a0>
  410eac:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410eb2:	jmp    410ee2 <__swc_fn_ff58629f_000125_83db7238+0xe2>
  410eb4:	vmovups xmm0,XMMWORD PTR [rip+0x1704]        # 4125c0 <__swc_rdata_base_ff58629f+0x4b0>
  410ebc:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410ec2:	jmp    410ee2 <__swc_fn_ff58629f_000125_83db7238+0xe2>
  410ec4:	vmovups xmm0,XMMWORD PTR [rip+0x1704]        # 4125d0 <__swc_rdata_base_ff58629f+0x4c0>
  410ecc:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410ed2:	jmp    410ee2 <__swc_fn_ff58629f_000125_83db7238+0xe2>
  410ed4:	vmovups xmm0,XMMWORD PTR [rip+0x1704]        # 4125e0 <__swc_rdata_base_ff58629f+0x4d0>
  410edc:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410ee2:	lea    rcx,[rsp+0x8]
  410ee7:	mov    rdx,rdi
  410eea:	call   4093e0 <__swc_fn_ff58629f_000108_90faaa26>
  410eef:	vmovups xmm0,XMMWORD PTR [rdi]
  410ef3:	vmovups XMMWORD PTR [r12+0x940],xmm0
  410efd:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  410f02:	vmovups XMMWORD PTR [r12+0x950],xmm0
  410f0c:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  410f11:	vmovups XMMWORD PTR [r12+0x960],xmm0
  410f1b:	lea    rax,[r12+0x940]
  410f23:	mov    QWORD PTR [r12+0x970],rax
  410f2b:	mov    rax,QWORD PTR [rsi]
  410f2e:	mov    QWORD PTR [r12+0x978],rax
  410f36:	mov    rax,QWORD PTR [rsi+0x8]
  410f3a:	mov    QWORD PTR [r12+0x980],rax
  410f42:	movsxd rax,ebx
  410f45:	mov    QWORD PTR [r12+0x988],rax
  410f4d:	cmp    ebx,0x5
  410f50:	je     410f59 <__swc_fn_ff58629f_000125_83db7238+0x159>
  410f52:	xor    ecx,ecx
  410f54:	call   411cf0 <__swc_fn_ff58629f_000179_718d7b54>
  410f59:	mov    rbx,QWORD PTR [r12+0xbe8]
  410f61:	test   rbx,rbx
  410f64:	je     410f75 <__swc_fn_ff58629f_000125_83db7238+0x175>
  410f66:	mov    rcx,r12
  410f69:	call   rbx
  410f6b:	add    rsp,0x18
  410f6f:	pop    r12
  410f71:	pop    rdi
  410f72:	pop    rsi
  410f73:	pop    rbx
  410f74:	ret
  410f75:	mov    rcx,rsi
  410f78:	call   40cc70 <__swc_fn_ff58629f_000121_2648f149>
  410f7d:	call   409a10 <__swc_fn_ff58629f_000123_be2e2f68>
  410f82:	add    rsp,0x18
  410f86:	pop    r12
  410f88:	pop    rdi
  410f89:	pop    rsi
  410f8a:	pop    rbx
  410f8b:	ret
  410f8c:	mov    rcx,rsi
  410f8f:	mov    rdx,rdi
  410f92:	call   4093e0 <__swc_fn_ff58629f_000108_90faaa26>
  410f97:	jmp    410e4f <__swc_fn_ff58629f_000125_83db7238+0x4f>
  410f9c:	add    BYTE PTR [rax],al
	...

0000000000410fa0 <__swc_fn_ff58629f_000128_58f0f391>:
  410fa0:	push   rdi
  410fa1:	push   rsi
  410fa2:	sub    rsp,0xb8
  410fa9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  410faf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410fb5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  410fbb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410fc1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410fc7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  410fcd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410fd3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  410fdc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410fe5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  410fee:	mov    DWORD PTR [rsp+0x8],0x0
  410ff6:	lea    rdi,[rsp+0x8]
  410ffb:	xor    esi,esi
  410ffd:	xor    eax,eax
  410fff:	call   4071e0 <pthread_key_create@plt>
  411004:	test   eax,eax
  411006:	jne    41100e <__swc_fn_ff58629f_000128_58f0f391+0x6e>
  411008:	mov    eax,DWORD PTR [rsp+0x8]
  41100c:	jmp    411015 <__swc_fn_ff58629f_000128_58f0f391+0x75>
  41100e:	mov    rax,0xffffffffffffffff
  411015:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  41101b:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  411021:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  411027:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41102d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  411033:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  411039:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41103f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  411048:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  411051:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  41105a:	add    rsp,0xb8
  411061:	pop    rsi
  411062:	pop    rdi
  411063:	ret
	...

0000000000411070 <__swc_fn_ff58629f_000131_4a82cdf6>:
  411070:	push   rdi
  411071:	push   rsi
  411072:	sub    rsp,0xb8
  411079:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41107f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  411085:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41108b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  411091:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  411097:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41109d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4110a3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4110ac:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4110b5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4110be:	mov    DWORD PTR [rsp+0x8],0x0
  4110c6:	lea    rdi,[rsp+0x8]
  4110cb:	mov    rsi,rcx
  4110ce:	xor    eax,eax
  4110d0:	call   4071e0 <pthread_key_create@plt>
  4110d5:	test   eax,eax
  4110d7:	jne    4110e2 <__swc_fn_ff58629f_000131_4a82cdf6+0x72>
  4110d9:	mov    eax,DWORD PTR [rsp+0x8]
  4110dd:	inc    rax
  4110e0:	jmp    4110e4 <__swc_fn_ff58629f_000131_4a82cdf6+0x74>
  4110e2:	xor    eax,eax
  4110e4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4110ea:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4110f0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4110f6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4110fc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  411102:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  411108:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41110e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  411117:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  411120:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  411129:	add    rsp,0xb8
  411130:	pop    rsi
  411131:	pop    rdi
  411132:	ret
	...

0000000000411140 <__swc_fn_ff58629f_000134_ae5891af>:
  411140:	push   rdi
  411141:	push   rsi
  411142:	sub    rsp,0xa8
  411149:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41114f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411155:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41115b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411161:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411167:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41116d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411173:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411179:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411182:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41118b:	test   rcx,rcx
  41118e:	setne  al
  411191:	je     4111aa <__swc_fn_ff58629f_000134_ae5891af+0x6a>
  411193:	lea    rax,[rcx-0x1]
  411197:	mov    eax,eax
  411199:	mov    edi,eax
  41119b:	mov    rsi,rdx
  41119e:	xor    eax,eax
  4111a0:	call   4071a0 <pthread_setspecific@plt>
  4111a5:	test   eax,eax
  4111a7:	sete   al
  4111aa:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4111b0:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4111b6:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4111bc:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4111c2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4111c8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4111ce:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4111d4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4111da:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4111e3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4111ec:	add    rsp,0xa8
  4111f3:	pop    rsi
  4111f4:	pop    rdi
  4111f5:	ret
	...

0000000000411200 <__swc_fn_ff58629f_000137_865f5106>:
  411200:	push   rdi
  411201:	push   rsi
  411202:	sub    rsp,0xa8
  411209:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41120f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411215:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41121b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411221:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411227:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41122d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411233:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411239:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411242:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41124b:	mov    rax,rdx
  41124e:	mov    QWORD PTR [rsp],0x0
  411256:	mov    edi,0xca
  41125b:	mov    rsi,rcx
  41125e:	mov    edx,0x81
  411263:	mov    eax,eax
  411265:	mov    ecx,eax
  411267:	xor    r8d,r8d
  41126a:	xor    r9d,r9d
  41126d:	xor    eax,eax
  41126f:	call   407080 <syscall@plt>
  411274:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41127a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411280:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411286:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41128c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411292:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411298:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41129e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4112a4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4112ad:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4112b6:	add    rsp,0xa8
  4112bd:	pop    rsi
  4112be:	pop    rdi
  4112bf:	ret

00000000004112c0 <__swc_fn_ff58629f_000140_86bb0f90>:
  4112c0:	sub    rsp,0x8
  4112c4:	call   409db0 <__swc_fn_ff58629f_000138_8c07c14b>
  4112c9:	add    rsp,0x8
  4112cd:	ret
	...

00000000004112d0 <__swc_fn_ff58629f_000143_be4c2719>:
  4112d0:	push   rdi
  4112d1:	push   rsi
  4112d2:	sub    rsp,0xc8
  4112d9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4112df:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4112e5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4112eb:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4112f1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4112f7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4112fd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  411306:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  41130f:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  411318:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  411321:	vxorps xmm0,xmm0,xmm0
  411325:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  41132b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  411331:	mov    rdi,rcx
  411334:	lea    rsi,[rsp+0x8]
  411339:	xor    eax,eax
  41133b:	call   4071f0 <dladdr@plt>
  411340:	xor    ecx,ecx
  411342:	test   eax,eax
  411344:	je     41134b <__swc_fn_ff58629f_000143_be4c2719+0x7b>
  411346:	mov    rcx,QWORD PTR [rsp+0x10]
  41134b:	mov    rax,rcx
  41134e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  411354:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  41135a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  411360:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  411366:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  41136c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  411372:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  41137b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  411384:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  41138d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  411396:	add    rsp,0xc8
  41139d:	pop    rsi
  41139e:	pop    rdi
  41139f:	ret

00000000004113a0 <__swc_fn_ff58629f_000146_1534de9a>:
  4113a0:	push   rbx
  4113a1:	push   r12
  4113a3:	push   r13
  4113a5:	push   rdi
  4113a6:	push   rsi
  4113a7:	push   r14
  4113a9:	push   r15
  4113ab:	sub    rsp,0x150
  4113b2:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  4113bb:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  4113c4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  4113cd:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  4113d6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  4113df:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4113e8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4113f1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4113fa:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  411403:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  41140c:	mov    rbx,rdx
  41140f:	mov    QWORD PTR [rsp+0x98],rdx
  411417:	mov    r12,rcx
  41141a:	mov    QWORD PTR [rsp+0xa0],rcx
  411422:	mov    QWORD PTR [rbx],0x0
  411429:	lea    r13,[rip+0x14948]        # 425d78 <__swc_bss_base_ff58629f+0x2d38>
  411430:	mov    rcx,r13
  411433:	call   4112c0 <__swc_fn_ff58629f_000140_86bb0f90>
  411438:	mov    rax,QWORD PTR [rip+0x14941]        # 425d80 <__swc_bss_base_ff58629f+0x2d40>
  41143f:	test   rax,rax
  411442:	je     411479 <__swc_fn_ff58629f_000146_1534de9a+0xd9>
  411444:	cs nop WORD PTR [rax+rax*1+0x0]
  41144e:	xchg   ax,ax
  411450:	cmp    QWORD PTR [rax+0x8],r12
  411454:	jne    411471 <__swc_fn_ff58629f_000146_1534de9a+0xd1>
  411456:	mov    rcx,QWORD PTR [rax+0x18]
  41145a:	mov    QWORD PTR [rbx],rcx
  41145d:	mov    rbx,QWORD PTR [rax+0x10]
  411461:	mov    rcx,r13
  411464:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  411469:	mov    rax,rbx
  41146c:	jmp    41165b <__swc_fn_ff58629f_000146_1534de9a+0x2bb>
  411471:	mov    rax,QWORD PTR [rax]
  411474:	test   rax,rax
  411477:	jne    411450 <__swc_fn_ff58629f_000146_1534de9a+0xb0>
  411479:	vxorps xmm0,xmm0,xmm0
  41147d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  411483:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  411489:	mov    rdi,r12
  41148c:	lea    rsi,[rsp+0x10]
  411491:	xor    eax,eax
  411493:	call   4071f0 <dladdr@plt>
  411498:	test   eax,eax
  41149a:	sete   al
  41149d:	je     4114aa <__swc_fn_ff58629f_000146_1534de9a+0x10a>
  41149f:	mov    rax,QWORD PTR [rsp+0x10]
  4114a4:	test   rax,rax
  4114a7:	sete   al
  4114aa:	test   al,al
  4114ac:	je     4114bd <__swc_fn_ff58629f_000146_1534de9a+0x11d>
  4114ae:	mov    rcx,r13
  4114b1:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  4114b6:	xor    eax,eax
  4114b8:	jmp    41165b <__swc_fn_ff58629f_000146_1534de9a+0x2bb>
  4114bd:	mov    rdi,QWORD PTR [rsp+0x10]
  4114c2:	mov    esi,0x80000
  4114c7:	xor    eax,eax
  4114c9:	call   4070a0 <open@plt>
  4114ce:	lea    r14,[rsp+0x30]
  4114d3:	mov    DWORD PTR [rsp+0x30],eax
  4114d7:	cmp    DWORD PTR [r14],0x0
  4114db:	jge    4114ec <__swc_fn_ff58629f_000146_1534de9a+0x14c>
  4114dd:	mov    rcx,r13
  4114e0:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  4114e5:	xor    eax,eax
  4114e7:	jmp    41165b <__swc_fn_ff58629f_000146_1534de9a+0x2bb>
  4114ec:	mov    rax,r14
  4114ef:	movsxd rdi,DWORD PTR [rax]
  4114f2:	xor    esi,esi
  4114f4:	mov    edx,0x2
  4114f9:	xor    eax,eax
  4114fb:	call   407150 <lseek@plt>
  411500:	mov    r15,rax
  411503:	test   rax,rax
  411506:	jg     411521 <__swc_fn_ff58629f_000146_1534de9a+0x181>
  411508:	movsxd rdi,DWORD PTR [r14]
  41150b:	xor    eax,eax
  41150d:	call   4070d0 <close@plt>
  411512:	mov    rcx,r13
  411515:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  41151a:	xor    eax,eax
  41151c:	jmp    41165b <__swc_fn_ff58629f_000146_1534de9a+0x2bb>
  411521:	xor    edi,edi
  411523:	mov    rsi,r15
  411526:	mov    edx,0x1
  41152b:	mov    ecx,0x2
  411530:	mov    rax,r14
  411533:	movsxd r8,DWORD PTR [rax]
  411536:	xor    r9d,r9d
  411539:	xor    eax,eax
  41153b:	call   407010 <mmap@plt>
  411540:	mov    rbx,rax
  411543:	test   rax,rax
  411546:	sete   al
  411549:	cmp    rbx,0xffffffffffffffff
  41154d:	sete   cl
  411550:	or     al,cl
  411552:	je     41156d <__swc_fn_ff58629f_000146_1534de9a+0x1cd>
  411554:	movsxd rdi,DWORD PTR [r14]
  411557:	xor    eax,eax
  411559:	call   4070d0 <close@plt>
  41155e:	mov    rcx,r13
  411561:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  411566:	xor    eax,eax
  411568:	jmp    41165b <__swc_fn_ff58629f_000146_1534de9a+0x2bb>
  41156d:	lea    rax,[rsp+0x50]
  411572:	mov    QWORD PTR [rax],0x0
  411579:	mov    rcx,rbx
  41157c:	mov    rdx,r15
  41157f:	mov    r8,rax
  411582:	call   40d200 <__swc_fn_ff58629f_000145_d5d4d43f>
  411587:	mov    r12,rax
  41158a:	test   rax,rax
  41158d:	jne    4115b5 <__swc_fn_ff58629f_000146_1534de9a+0x215>
  41158f:	mov    rdi,rbx
  411592:	mov    rsi,r15
  411595:	xor    eax,eax
  411597:	call   407030 <munmap@plt>
  41159c:	movsxd rdi,DWORD PTR [r14]
  41159f:	xor    eax,eax
  4115a1:	call   4070d0 <close@plt>
  4115a6:	mov    rcx,r13
  4115a9:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  4115ae:	xor    eax,eax
  4115b0:	jmp    41165b <__swc_fn_ff58629f_000146_1534de9a+0x2bb>
  4115b5:	mov    edi,0x20
  4115ba:	xor    eax,eax
  4115bc:	call   407090 <malloc@plt>
  4115c1:	test   rax,rax
  4115c4:	jne    4115e9 <__swc_fn_ff58629f_000146_1534de9a+0x249>
  4115c6:	mov    rdi,rbx
  4115c9:	mov    rsi,r15
  4115cc:	xor    eax,eax
  4115ce:	call   407030 <munmap@plt>
  4115d3:	movsxd rdi,DWORD PTR [r14]
  4115d6:	xor    eax,eax
  4115d8:	call   4070d0 <close@plt>
  4115dd:	mov    rcx,r13
  4115e0:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  4115e5:	xor    eax,eax
  4115e7:	jmp    41165b <__swc_fn_ff58629f_000146_1534de9a+0x2bb>
  4115e9:	mov    rcx,QWORD PTR [rip+0x14790]        # 425d80 <__swc_bss_base_ff58629f+0x2d40>
  4115f0:	mov    QWORD PTR [rsp+0x70],rcx
  4115f5:	mov    rcx,QWORD PTR [rsp+0xa0]
  4115fd:	mov    QWORD PTR [rsp+0x78],rcx
  411602:	mov    QWORD PTR [rsp+0x80],r12
  41160a:	mov    rcx,QWORD PTR [rsp+0x50]
  41160f:	mov    QWORD PTR [rsp+0x88],rcx
  411617:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  41161d:	vmovups XMMWORD PTR [rax],xmm0
  411621:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  41162a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  41162f:	mov    QWORD PTR [rip+0x1474a],rax        # 425d80 <__swc_bss_base_ff58629f+0x2d40>
  411636:	mov    rax,QWORD PTR [rsp+0x50]
  41163b:	mov    rbx,QWORD PTR [rsp+0x98]
  411643:	mov    QWORD PTR [rbx],rax
  411646:	movsxd rdi,DWORD PTR [r14]
  411649:	xor    eax,eax
  41164b:	call   4070d0 <close@plt>
  411650:	mov    rcx,r13
  411653:	call   409eb0 <__swc_fn_ff58629f_000141_055b38a4>
  411658:	mov    rax,r12
  41165b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  411664:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  41166d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  411676:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  41167f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  411688:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  411691:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  41169a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  4116a3:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  4116ac:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  4116b5:	add    rsp,0x150
  4116bc:	pop    r15
  4116be:	pop    r14
  4116c0:	pop    rsi
  4116c1:	pop    rdi
  4116c2:	pop    r13
  4116c4:	pop    r12
  4116c6:	pop    rbx
  4116c7:	ret
	...

00000000004116d0 <__swc_fn_ff58629f_000149_43c96957>:
  4116d0:	push   rbx
  4116d1:	sub    rsp,0xe0
  4116d8:	lea    rbx,[rsp+0x8]
  4116dd:	vxorps xmm0,xmm0,xmm0
  4116e1:	vmovups YMMWORD PTR [rbx],ymm0
  4116e5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  4116ea:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  4116ef:	vzeroupper
  4116f2:	mov    DWORD PTR [rbx+0x60],0x0
  4116f9:	mov    r8,rbx
  4116fc:	nop    DWORD PTR [rax+0x0]
  411700:	mov    r9,rcx
  411703:	movabs rcx,0xcccccccccccccccd
  41170d:	mov    rax,r9
  411710:	mul    rcx
  411713:	mov    r10,rdx
  411716:	shr    r10,0x3
  41171a:	mov    rcx,r10
  41171d:	imul   rdx,r10,0xa
  411721:	sub    r9,rdx
  411724:	mov    rdx,QWORD PTR [rip+0xee5]        # 412610 <__swc_rdata_base_ff58629f+0x500>
  41172b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  411730:	mov    BYTE PTR [r8],dl
  411733:	lea    rdx,[r8+0x1]
  411737:	mov    r8,rdx
  41173a:	test   r10,r10
  41173d:	jne    411700 <__swc_fn_ff58629f_000149_43c96957+0x30>
  41173f:	mov    BYTE PTR [rdx],0x0
  411742:	sub    r8,0x1
  411746:	mov    rax,rbx
  411749:	cmp    rax,r8
  41174c:	jae    411766 <__swc_fn_ff58629f_000149_43c96957+0x96>
  41174e:	xchg   ax,ax
  411750:	mov    cl,BYTE PTR [r8]
  411753:	mov    dl,BYTE PTR [rax]
  411755:	mov    BYTE PTR [r8],dl
  411758:	sub    r8,0x1
  41175c:	mov    BYTE PTR [rax],cl
  41175e:	inc    rax
  411761:	cmp    rax,r8
  411764:	jb     411750 <__swc_fn_ff58629f_000149_43c96957+0x80>
  411766:	xor    eax,eax
  411768:	test   rbx,rbx
  41176b:	je     41178e <__swc_fn_ff58629f_000149_43c96957+0xbe>
  41176d:	mov    rcx,rbx
  411770:	mov    dl,BYTE PTR [rcx]
  411772:	test   dl,dl
  411774:	je     41178e <__swc_fn_ff58629f_000149_43c96957+0xbe>
  411776:	cs nop WORD PTR [rax+rax*1+0x0]
  411780:	add    rcx,0x1
  411784:	add    rax,0x1
  411788:	mov    dl,BYTE PTR [rcx]
  41178a:	test   dl,dl
  41178c:	jne    411780 <__swc_fn_ff58629f_000149_43c96957+0xb0>
  41178e:	mov    QWORD PTR [rbx+0xa8],rbx
  411795:	mov    QWORD PTR [rbx+0xb0],rax
  41179c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  4117a4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  4117ac:	lea    rcx,[rbx+0xb8]
  4117b3:	call   40cc70 <__swc_fn_ff58629f_000121_2648f149>
  4117b8:	add    rsp,0xe0
  4117bf:	pop    rbx
  4117c0:	ret
	...

00000000004117d0 <__swc_fn_ff58629f_000152_6fb05988>:
  4117d0:	sub    rsp,0x8
  4117d4:	mov    rax,QWORD PTR [rcx+0x8]
  4117d8:	mov    r8,QWORD PTR [rdx+0x8]
  4117dc:	cmp    rax,r8
  4117df:	je     4117e8 <__swc_fn_ff58629f_000152_6fb05988+0x18>
  4117e1:	xor    eax,eax
  4117e3:	add    rsp,0x8
  4117e7:	ret
  4117e8:	test   rax,rax
  4117eb:	jne    4117fc <__swc_fn_ff58629f_000152_6fb05988+0x2c>
  4117ed:	test   r8,r8
  4117f0:	jne    4117fc <__swc_fn_ff58629f_000152_6fb05988+0x2c>
  4117f2:	mov    eax,0x1
  4117f7:	add    rsp,0x8
  4117fb:	ret
  4117fc:	mov    rcx,QWORD PTR [rcx]
  4117ff:	mov    rdx,QWORD PTR [rdx]
  411802:	test   rcx,rcx
  411805:	sete   r8b
  411809:	test   rdx,rdx
  41180c:	sete   r9b
  411810:	or     r8b,r9b
  411813:	je     411820 <__swc_fn_ff58629f_000152_6fb05988+0x50>
  411815:	cmp    rcx,rdx
  411818:	sete   al
  41181b:	add    rsp,0x8
  41181f:	ret
  411820:	cmp    rcx,rdx
  411823:	jne    41182f <__swc_fn_ff58629f_000152_6fb05988+0x5f>
  411825:	mov    eax,0x1
  41182a:	add    rsp,0x8
  41182e:	ret
  41182f:	mov    r8,rax
  411832:	call   4094a0 <__swc_fn_ff58629f_000111_3dc01326>
  411837:	test   eax,eax
  411839:	sete   al
  41183c:	add    rsp,0x8
  411840:	ret
	...

0000000000411850 <__swc_fn_ff58629f_000155_86f1d437>:
  411850:	vxorps xmm0,xmm0,xmm0
  411854:	vmovups XMMWORD PTR [rcx],xmm0
  411858:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41185d:	vxorps xmm0,xmm0,xmm0
  411861:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411866:	vmovups xmm0,XMMWORD PTR [rip+0xe5a]        # 4126c8 <__swc_rdata_base_ff58629f+0x5b8>
  41186e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411873:	ret
	...

0000000000411880 <__swc_fn_ff58629f_000158_86f1d437>:
  411880:	vxorps xmm0,xmm0,xmm0
  411884:	vmovups XMMWORD PTR [rcx],xmm0
  411888:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41188d:	vxorps xmm0,xmm0,xmm0
  411891:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411896:	vmovups xmm0,XMMWORD PTR [rip+0xf4a]        # 4127e8 <__swc_rdata_base_ff58629f+0x6d8>
  41189e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4118a3:	mov    QWORD PTR [rcx+0x40],0x0
  4118ab:	ret
  4118ac:	add    BYTE PTR [rax],al
	...

00000000004118b0 <__swc_fn_ff58629f_000161_47b270e1>:
  4118b0:	push   rbx
  4118b1:	sub    rsp,0x70
  4118b5:	mov    rax,QWORD PTR [rcx]
  4118b8:	mov    rbx,QWORD PTR [rcx+0x8]
  4118bc:	vxorps xmm0,xmm0,xmm0
  4118c0:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  4118c6:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  4118cc:	vzeroupper
  4118cf:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  4118d5:	mov    QWORD PTR [rsp+0x48],rdx
  4118da:	mov    QWORD PTR [rsp+0x50],r8
  4118df:	mov    rcx,rax
  4118e2:	lea    rdx,[rsp+0x8]
  4118e7:	mov    rbx,QWORD PTR [rbx+0x18]
  4118eb:	call   rbx
  4118ed:	add    rsp,0x70
  4118f1:	pop    rbx
  4118f2:	ret
	...

0000000000411900 <__swc_fn_ff58629f_000164_8a3d304f>:
  411900:	push   rbx
  411901:	push   rsi
  411902:	push   rdi
  411903:	mov    rbx,r8
  411906:	mov    rsi,rcx
  411909:	mov    rdi,rdx
  41190c:	call   40a1b0 <__swc_fn_ff58629f_000162_13ead2ff>
  411911:	vmovups xmm0,XMMWORD PTR [rbx]
  411915:	vmovups XMMWORD PTR [rsi],xmm0
  411919:	mov    QWORD PTR [rsi+0x18],rdi
  41191d:	pop    rdi
  41191e:	pop    rsi
  41191f:	pop    rbx
  411920:	ret
	...

0000000000411930 <__swc_fn_ff58629f_000167_cc119975>:
  411930:	push   rbx
  411931:	push   rsi
  411932:	push   rdi
  411933:	push   r12
  411935:	push   r13
  411937:	sub    rsp,0x50
  41193b:	mov    rbx,rcx
  41193e:	mov    rsi,rdx
  411941:	vmovups xmm0,XMMWORD PTR [rip+0xfaf]        # 4128f8 <__swc_rdata_base_ff58629f+0x7e8>
  411949:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  41194f:	vmovups xmm0,XMMWORD PTR [rip+0xfb1]        # 412908 <__swc_rdata_base_ff58629f+0x7f8>
  411957:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  41195d:	vxorps xmm0,xmm0,xmm0
  411961:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  411967:	mov    rcx,rdx
  41196a:	call   4112d0 <__swc_fn_ff58629f_000143_be4c2719>
  41196f:	mov    rdi,rax
  411972:	test   rax,rax
  411975:	jne    4119a6 <__swc_fn_ff58629f_000167_cc119975+0x76>
  411977:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  41197d:	vmovups XMMWORD PTR [rbx],xmm0
  411981:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411987:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  41198c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  411992:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  411997:	mov    rax,rbx
  41199a:	add    rsp,0x50
  41199e:	pop    r13
  4119a0:	pop    r12
  4119a2:	pop    rdi
  4119a3:	pop    rsi
  4119a4:	pop    rbx
  4119a5:	ret
  4119a6:	mov    rcx,rdi
  4119a9:	call   40e720 <__swc_fn_ff58629f_000166_016ee66a>
  4119ae:	mov    r11,rax
  4119b1:	test   rax,rax
  4119b4:	je     4119be <__swc_fn_ff58629f_000167_cc119975+0x8e>
  4119b6:	mov    al,BYTE PTR [r11+0x24]
  4119ba:	test   al,al
  4119bc:	jne    4119ed <__swc_fn_ff58629f_000167_cc119975+0xbd>
  4119be:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4119c4:	vmovups XMMWORD PTR [rbx],xmm0
  4119c8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  4119ce:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  4119d3:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  4119d9:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  4119de:	mov    rax,rbx
  4119e1:	add    rsp,0x50
  4119e5:	pop    r13
  4119e7:	pop    r12
  4119e9:	pop    rdi
  4119ea:	pop    rsi
  4119eb:	pop    rbx
  4119ec:	ret
  4119ed:	sub    rsi,rdi
  4119f0:	mov    eax,0xffffffff
  4119f5:	cmp    rsi,rax
  4119f8:	jbe    411a29 <__swc_fn_ff58629f_000167_cc119975+0xf9>
  4119fa:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  411a00:	vmovups XMMWORD PTR [rbx],xmm0
  411a04:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411a0a:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  411a0f:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  411a15:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  411a1a:	mov    rax,rbx
  411a1d:	add    rsp,0x50
  411a21:	pop    r13
  411a23:	pop    r12
  411a25:	pop    rdi
  411a26:	pop    rsi
  411a27:	pop    rbx
  411a28:	ret
  411a29:	mov    rdi,QWORD PTR [r11+0x10]
  411a2d:	mov    eax,DWORD PTR [r11+0x20]
  411a31:	xor    ecx,ecx
  411a33:	test   rax,rax
  411a36:	jbe    411b88 <__swc_fn_ff58629f_000167_cc119975+0x258>
  411a3c:	nop    DWORD PTR [rax+0x0]
  411a40:	mov    edx,ecx
  411a42:	imul   r12,rdx,0x14
  411a46:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  411a4b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  411a50:	mov    r9d,esi
  411a53:	cmp    r9,rdx
  411a56:	jb     411b7b <__swc_fn_ff58629f_000167_cc119975+0x24b>
  411a5c:	add    rdx,r8
  411a5f:	mov    r8d,esi
  411a62:	cmp    r8,rdx
  411a65:	jae    411b7b <__swc_fn_ff58629f_000167_cc119975+0x24b>
  411a6b:	lea    rsi,[rsp+0x38]
  411a70:	mov    eax,DWORD PTR [rdi+0xc]
  411a73:	mov    DWORD PTR [rsp+0x38],eax
  411a77:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  411a7c:	mov    rcx,rdi
  411a7f:	mov    rdx,QWORD PTR [r11+0x18]
  411a83:	mov    r8,rsi
  411a86:	mov    r8d,DWORD PTR [r8]
  411a89:	mov    r9,rax
  411a8c:	lea    r10,[rsp+0x10]
  411a91:	call   40a200 <__swc_fn_ff58629f_000165_72795826>
  411a96:	test   al,al
  411a98:	jne    411acb <__swc_fn_ff58629f_000167_cc119975+0x19b>
  411a9a:	vmovups xmm0,XMMWORD PTR [rip+0xe86]        # 412928 <__swc_rdata_base_ff58629f+0x818>
  411aa2:	vmovups XMMWORD PTR [rbx],xmm0
  411aa6:	vmovups xmm0,XMMWORD PTR [rip+0xe8a]        # 412938 <__swc_rdata_base_ff58629f+0x828>
  411aae:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  411ab3:	vxorps xmm0,xmm0,xmm0
  411ab7:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  411abc:	mov    rax,rbx
  411abf:	add    rsp,0x50
  411ac3:	pop    r13
  411ac5:	pop    r12
  411ac7:	pop    rdi
  411ac8:	pop    rsi
  411ac9:	pop    rbx
  411aca:	ret
  411acb:	lea    r13,[rsp+0x3c]
  411ad0:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  411ad5:	mov    DWORD PTR [rsp+0x3c],eax
  411ad9:	test   eax,eax
  411adb:	je     411b2c <__swc_fn_ff58629f_000167_cc119975+0x1fc>
  411add:	mov    rcx,rdi
  411ae0:	mov    rdx,QWORD PTR [r11+0x18]
  411ae4:	mov    r8d,DWORD PTR [rsi]
  411ae7:	mov    rax,r13
  411aea:	mov    r9d,DWORD PTR [rax]
  411aed:	lea    r10,[rsp+0x20]
  411af2:	call   40a200 <__swc_fn_ff58629f_000165_72795826>
  411af7:	test   al,al
  411af9:	jne    411b2c <__swc_fn_ff58629f_000167_cc119975+0x1fc>
  411afb:	vmovups xmm0,XMMWORD PTR [rip+0xe55]        # 412958 <__swc_rdata_base_ff58629f+0x848>
  411b03:	vmovups XMMWORD PTR [rbx],xmm0
  411b07:	vmovups xmm0,XMMWORD PTR [rip+0xe59]        # 412968 <__swc_rdata_base_ff58629f+0x858>
  411b0f:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  411b14:	vxorps xmm0,xmm0,xmm0
  411b18:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  411b1d:	mov    rax,rbx
  411b20:	add    rsp,0x50
  411b24:	pop    r13
  411b26:	pop    r12
  411b28:	pop    rdi
  411b29:	pop    rsi
  411b2a:	pop    rbx
  411b2b:	ret
  411b2c:	mov    eax,0x1
  411b31:	rex mov BYTE PTR [rsp+0x8],al
  411b36:	cmp    DWORD PTR [r13+0x0],0x0
  411b3b:	je     411b4c <__swc_fn_ff58629f_000167_cc119975+0x21c>
  411b3d:	rex mov BYTE PTR [rsp+0x9],0x1
  411b43:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  411b48:	mov    DWORD PTR [rsp+0x30],eax
  411b4c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  411b52:	vmovups XMMWORD PTR [rbx],xmm0
  411b56:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411b5c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  411b61:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  411b67:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  411b6c:	mov    rax,rbx
  411b6f:	add    rsp,0x50
  411b73:	pop    r13
  411b75:	pop    r12
  411b77:	pop    rdi
  411b78:	pop    rsi
  411b79:	pop    rbx
  411b7a:	ret
  411b7b:	add    rcx,0x1
  411b7f:	cmp    rcx,rax
  411b82:	jb     411a40 <__swc_fn_ff58629f_000167_cc119975+0x110>
  411b88:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  411b8e:	vmovups XMMWORD PTR [rbx],xmm0
  411b92:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411b98:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  411b9d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  411ba3:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  411ba8:	mov    rax,rbx
  411bab:	add    rsp,0x50
  411baf:	pop    r13
  411bb1:	pop    r12
  411bb3:	pop    rdi
  411bb4:	pop    rsi
  411bb5:	pop    rbx
  411bb6:	ret
	...

0000000000411bc0 <__swc_fn_ff58629f_000170_994c8876>:
  411bc0:	sub    rsp,0x48
  411bc4:	call   410fa0 <__swc_fn_ff58629f_000128_58f0f391>
  411bc9:	cmp    rax,0xffffffffffffffff
  411bcd:	je     411bd4 <__swc_fn_ff58629f_000170_994c8876+0x14>
  411bcf:	add    rsp,0x48
  411bd3:	ret
  411bd4:	lea    rcx,[rip+0xdbd]        # 412998 <__swc_rdata_base_ff58629f+0x888>
  411bdb:	vmovups xmm0,XMMWORD PTR [rip+0xdc5]        # 4129a8 <__swc_rdata_base_ff58629f+0x898>
  411be3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  411be9:	vmovups xmm0,XMMWORD PTR [rip+0xdc7]        # 4129b8 <__swc_rdata_base_ff58629f+0x8a8>
  411bf1:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  411bf7:	vmovups xmm0,XMMWORD PTR [rip+0xdc9]        # 4129c8 <__swc_rdata_base_ff58629f+0x8b8>
  411bff:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  411c05:	lea    rdx,[rsp+0x8]
  411c0a:	mov    QWORD PTR [rsp+0x38],rax
  411c0f:	call   4093e0 <__swc_fn_ff58629f_000108_90faaa26>
  411c14:	mov    rax,QWORD PTR [rsp+0x38]
  411c19:	jmp    411bcf <__swc_fn_ff58629f_000170_994c8876+0xf>
  411c1b:	add    BYTE PTR [rax],al
  411c1d:	add    BYTE PTR [rax],al
	...

0000000000411c20 <__swc_fn_ff58629f_000173_cbeff767>:
  411c20:	push   rbx
  411c21:	push   rsi
  411c22:	sub    rsp,0x28
  411c26:	mov    rbx,rcx
  411c29:	mov    DWORD PTR [rsp+0x8],0xbf0
  411c31:	mov    ecx,0xbf0
  411c36:	call   408fd0 <__swc_fn_ff58629f_000084_4a10c7e7>
  411c3b:	mov    rsi,rax
  411c3e:	test   rax,rax
  411c41:	jne    411c4c <__swc_fn_ff58629f_000173_cbeff767+0x2c>
  411c43:	xor    eax,eax
  411c45:	add    rsp,0x28
  411c49:	pop    rsi
  411c4a:	pop    rbx
  411c4b:	ret
  411c4c:	vxorps xmm0,xmm0,xmm0
  411c50:	xor    eax,eax
  411c52:	cs nop WORD PTR [rax+rax*1+0x0]
  411c5c:	nop    DWORD PTR [rax+0x0]
  411c60:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  411c65:	add    rax,0x10
  411c69:	cmp    rax,0xbf0
  411c70:	jne    411c60 <__swc_fn_ff58629f_000173_cbeff767+0x40>
  411c72:	lea    rax,[rbx+0x1]
  411c76:	mov    QWORD PTR [rsi+0x9c0],rax
  411c7d:	mov    rcx,rbx
  411c80:	mov    rdx,rsi
  411c83:	call   40a560 <__swc_fn_ff58629f_000171_646fdf20>
  411c88:	test   al,al
  411c8a:	jne    411c9d <__swc_fn_ff58629f_000173_cbeff767+0x7d>
  411c8c:	mov    rcx,rsi
  411c8f:	call   40bbf0 <__swc_fn_ff58629f_000085_cf82995a>
  411c94:	xor    eax,eax
  411c96:	add    rsp,0x28
  411c9a:	pop    rsi
  411c9b:	pop    rbx
  411c9c:	ret
  411c9d:	lea    rcx,[rsp+0x18]
  411ca2:	call   40c170 <__swc_fn_ff58629f_000097_93bfe675>
  411ca7:	mov    rax,rsi
  411caa:	add    rsp,0x28
  411cae:	pop    rsi
  411caf:	pop    rbx
  411cb0:	ret
	...

0000000000411cc0 <__swc_fn_ff58629f_000176_e09f8b62>:
  411cc0:	xor    eax,eax
  411cc2:	mov    edx,0x1
  411cc7:	lock cmpxchg QWORD PTR [rcx],rdx
  411ccc:	test   rax,rax
  411ccf:	jne    411cd2 <__swc_fn_ff58629f_000176_e09f8b62+0x12>
  411cd1:	ret
  411cd2:	cs nop WORD PTR [rax+rax*1+0x0]
  411cdc:	nop    DWORD PTR [rax+0x0]
  411ce0:	mov    rax,QWORD PTR [rcx]
  411ce3:	test   rax,rax
  411ce6:	je     411cc0 <__swc_fn_ff58629f_000176_e09f8b62>
  411ce8:	jmp    411ce0 <__swc_fn_ff58629f_000176_e09f8b62+0x20>
  411cea:	add    BYTE PTR [rax],al
  411cec:	add    BYTE PTR [rax],al
	...

0000000000411cf0 <__swc_fn_ff58629f_000179_718d7b54>:
  411cf0:	push   rsi
  411cf1:	push   rdi
  411cf2:	sub    rsp,0x38
  411cf6:	mov    rsi,rcx
  411cf9:	call   40a570 <__swc_fn_ff58629f_000174_1e0ea8cf>
  411cfe:	mov    rdi,rax
  411d01:	call   409d00 <__swc_fn_ff58629f_000135_a9c1c700>
  411d06:	mov    r8,rax
  411d09:	mov    rcx,rdi
  411d0c:	call   411cc0 <__swc_fn_ff58629f_000176_e09f8b62>
  411d11:	mov    rax,QWORD PTR [rdi+0x8]
  411d15:	test   rax,rax
  411d18:	je     411d55 <__swc_fn_ff58629f_000179_718d7b54+0x65>
  411d1a:	nop    WORD PTR [rax+rax*1+0x0]
  411d20:	cmp    rax,rsi
  411d23:	je     411d55 <__swc_fn_ff58629f_000179_718d7b54+0x65>
  411d25:	mov    r9,QWORD PTR [rax]
  411d28:	cmp    QWORD PTR [rax+0x20],r8
  411d2c:	jne    411d4d <__swc_fn_ff58629f_000179_718d7b54+0x5d>
  411d2e:	mov    rcx,rdi
  411d31:	mov    rdx,rax
  411d34:	mov    QWORD PTR [rsp+0x28],r8
  411d39:	mov    QWORD PTR [rsp+0x30],r9
  411d3e:	call   40eb40 <__swc_fn_ff58629f_000178_cf4ffedd>
  411d43:	mov    r8,QWORD PTR [rsp+0x28]
  411d48:	mov    r9,QWORD PTR [rsp+0x30]
  411d4d:	mov    rax,r9
  411d50:	test   r9,r9
  411d53:	jne    411d20 <__swc_fn_ff58629f_000179_718d7b54+0x30>
  411d55:	xor    eax,eax
  411d57:	mov    QWORD PTR [rdi],rax
  411d5a:	add    rsp,0x38
  411d5e:	pop    rdi
  411d5f:	pop    rsi
  411d60:	ret
