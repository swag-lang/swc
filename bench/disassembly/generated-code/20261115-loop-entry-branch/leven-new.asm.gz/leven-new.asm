
/workspace/prompt2-20261115/batch7-placement-micro/new/leven/leven:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <getpid@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <getpid@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <munmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <munmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <exit@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <exit@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <pthread_key_create@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <pthread_key_create@GLIBC_2.34>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_setspecific@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <pthread_setspecific@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <syscall@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <syscall@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dladdr@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <dladdr@GLIBC_2.34>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <open@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <open@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <lseek@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <lseek@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <close@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <close@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <mmap@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <mmap@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <malloc@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <malloc@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <clock_gettime@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf92]        # 413078 <clock_gettime@GLIBC_2.17>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <madvise@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf92]        # 413088 <madvise@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <pthread_key_delete@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf8a]        # 413090 <pthread_key_delete@GLIBC_2.34>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <gettid@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf82]        # 413098 <gettid@GLIBC_2.30>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <flock@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf7a]        # 4130a0 <flock@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <__errno_location@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf72]        # 4130a8 <__errno_location@GLIBC_2.2.5>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <opendir@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf6a]        # 4130b0 <opendir@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <dirfd@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf62]        # 4130b8 <dirfd@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <readdir@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <readdir@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <readlinkat@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <readlinkat@GLIBC_2.4>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <openat@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <openat@GLIBC_2.4>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <closedir@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <closedir@GLIBC_2.2.5>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <memfd_create@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <memfd_create@GLIBC_2.27>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <ftruncate@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <ftruncate@GLIBC_2.2.5>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <write@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <write@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <backtrace@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <backtrace@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <__x86_get_cpuid_feature_leaf@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <free@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <free@GLIBC_2.2.5>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_fc36583a_000176_cf4ffedd+0xf20>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40cb20 <__swc_fn_fc36583a_000124_540bf7e8>
  40724e:	xor    ecx,ecx
  407250:	call   40c240 <__swc_fn_fc36583a_000097_4f209617>
  407255:	call   40d6e0 <__swc_fn_fc36583a_000002_aa67484d>
  40725a:	call   40f7b0 <__swc_fn_fc36583a_000098_65137b72>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_fc36583a_000000_2744b483>:
  407270:	push   rbx
  407271:	sub    rsp,0x70
  407275:	cmp    rcx,0xffffffffffffffef
  407279:	jbe    407283 <__swc_fn_fc36583a_000000_2744b483+0x13>
  40727b:	xor    eax,eax
  40727d:	add    rsp,0x70
  407281:	pop    rbx
  407282:	ret
  407283:	vxorps xmm0,xmm0,xmm0
  407287:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40728d:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  407293:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  407299:	vzeroupper
  40729c:	lea    rax,[rcx+0x10]
  4072a0:	mov    QWORD PTR [rsp+0x50],rax
  4072a5:	mov    DWORD PTR [rsp+0x60],0x10
  4072ad:	mov    rcx,QWORD PTR [rip+0x1cd8c]        # 424040 <__swc_bss_base_fc36583a>
  4072b4:	test   rcx,rcx
  4072b7:	jne    4072c9 <__swc_fn_fc36583a_000000_2744b483+0x59>
  4072b9:	call   40a240 <__swc_fn_fc36583a_000168_994c8876>
  4072be:	lea    rcx,[rax+0x1]
  4072c2:	mov    QWORD PTR [rip+0x1cd77],rcx        # 424040 <__swc_bss_base_fc36583a>
  4072c9:	dec    rcx
  4072cc:	call   411fc0 <__swc_fn_fc36583a_000170_360af05d>
  4072d1:	mov    rcx,QWORD PTR [rax]
  4072d4:	lea    rdx,[rsp+0x8]
  4072d9:	mov    rbx,QWORD PTR [rax+0x8]
  4072dd:	mov    rbx,QWORD PTR [rbx+0x8]
  4072e1:	call   rbx
  4072e3:	mov    rax,QWORD PTR [rsp+0x48]
  4072e8:	test   rax,rax
  4072eb:	jne    4072f5 <__swc_fn_fc36583a_000000_2744b483+0x85>
  4072ed:	xor    eax,eax
  4072ef:	add    rsp,0x70
  4072f3:	pop    rbx
  4072f4:	ret
  4072f5:	mov    rcx,QWORD PTR [rsp+0x50]
  4072fa:	mov    QWORD PTR [rax],rcx
  4072fd:	mov    QWORD PTR [rax+0x8],0x0
  407305:	lea    rax,[rax+0x10]
  407309:	add    rsp,0x70
  40730d:	pop    rbx
  40730e:	ret
	...

0000000000407310 <__swc_fn_fc36583a_000003_9ee35b18>:
  407310:	vxorps xmm0,xmm0,xmm0
  407314:	vmovups XMMWORD PTR [rcx],xmm0
  407318:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40731d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407322:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407327:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40732c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407331:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407336:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40733b:	ret
  40733c:	add    BYTE PTR [rax],al
	...

0000000000407340 <__swc_fn_fc36583a_000006_f7acedb0>:
  407340:	push   rsi
  407341:	mov    rsi,rdx
  407344:	test   rdx,rdx
  407347:	jne    407350 <__swc_fn_fc36583a_000006_f7acedb0+0x10>
  407349:	mov    eax,0x1
  40734e:	pop    rsi
  40734f:	ret
  407350:	mov    rdx,rsi
  407353:	call   4092e0 <__swc_fn_fc36583a_000114_36905703>
  407358:	test   al,al
  40735a:	jne    407360 <__swc_fn_fc36583a_000006_f7acedb0+0x20>
  40735c:	xor    eax,eax
  40735e:	pop    rsi
  40735f:	ret
  407360:	lea    rcx,[rip+0x1cd19]        # 424080 <__swc_bss_base_fc36583a+0x40>
  407367:	mov    rdx,QWORD PTR [rip+0x1cd12]        # 424080 <__swc_bss_base_fc36583a+0x40>
  40736e:	xchg   ax,ax
  407370:	lea    r8,[rdx+rsi*1]
  407374:	mov    rax,rdx
  407377:	lock cmpxchg QWORD PTR [rcx],r8
  40737c:	cmp    rax,rdx
  40737f:	je     407386 <__swc_fn_fc36583a_000006_f7acedb0+0x46>
  407381:	mov    rdx,rax
  407384:	jmp    407370 <__swc_fn_fc36583a_000006_f7acedb0+0x30>
  407386:	lea    rcx,[rip+0x1ccfb]        # 424088 <__swc_bss_base_fc36583a+0x48>
  40738d:	mov    rdx,QWORD PTR [rip+0x1ccf4]        # 424088 <__swc_bss_base_fc36583a+0x48>
  407394:	cs nop WORD PTR [rax+rax*1+0x0]
  40739e:	xchg   ax,ax
  4073a0:	lea    r8,[rdx+0x1]
  4073a4:	mov    rax,rdx
  4073a7:	lock cmpxchg QWORD PTR [rcx],r8
  4073ac:	cmp    rax,rdx
  4073af:	je     4073b6 <__swc_fn_fc36583a_000006_f7acedb0+0x76>
  4073b1:	mov    rdx,rax
  4073b4:	jmp    4073a0 <__swc_fn_fc36583a_000006_f7acedb0+0x60>
  4073b6:	mov    eax,0x1
  4073bb:	pop    rsi
  4073bc:	ret
  4073bd:	add    BYTE PTR [rax],al
	...

00000000004073c0 <__swc_fn_fc36583a_000009_24a20786>:
  4073c0:	push   rbx
  4073c1:	push   rsi
  4073c2:	push   rdi
  4073c3:	push   r12
  4073c5:	sub    rsp,0x18
  4073c9:	mov    rbx,rcx
  4073cc:	mov    rsi,rcx
  4073cf:	and    rsi,0xffffffffffc00000
  4073d6:	movzx  eax,BYTE PTR [rbx+0x3a]
  4073da:	mov    ecx,DWORD PTR [rsi+0x28]
  4073dd:	shrx   eax,eax,ecx
  4073e2:	lea    rdi,[rsp+0x8]
  4073e7:	mov    DWORD PTR [rsp+0x8],eax
  4073eb:	mov    rcx,rsi
  4073ee:	mov    rax,rdi
  4073f1:	mov    edx,DWORD PTR [rax]
  4073f3:	call   40e050 <__swc_fn_fc36583a_000014_9dea5065>
  4073f8:	mov    r12,rax
  4073fb:	mov    rcx,rsi
  4073fe:	mov    edx,DWORD PTR [rdi]
  407400:	call   4074f0 <__swc_fn_fc36583a_000015_9afb7cfb>
  407405:	mov    rcx,r12
  407408:	mov    edx,DWORD PTR [rbx+0x3c]
  40740b:	add    rcx,rdx
  40740e:	cmp    rcx,rax
  407411:	jb     40741f <__swc_fn_fc36583a_000009_24a20786+0x5f>
  407413:	xor    eax,eax
  407415:	add    rsp,0x18
  407419:	pop    r12
  40741b:	pop    rdi
  40741c:	pop    rsi
  40741d:	pop    rbx
  40741e:	ret
  40741f:	mov    rdx,QWORD PTR [rbx+0x20]
  407423:	mov    r8d,DWORD PTR [rbx+0x2c]
  407427:	add    rdx,r8
  40742a:	lea    rsi,[rdx+0xffff]
  407431:	and    rsi,0xffffffffffff0000
  407438:	cmp    rax,rsi
  40743b:	cmovbe rsi,rax
  40743f:	mov    rax,rsi
  407442:	sub    rax,rcx
  407445:	mov    rdx,rax
  407448:	call   407340 <__swc_fn_fc36583a_000006_f7acedb0>
  40744d:	test   al,al
  40744f:	jne    40745d <__swc_fn_fc36583a_000009_24a20786+0x9d>
  407451:	xor    eax,eax
  407453:	add    rsp,0x18
  407457:	pop    r12
  407459:	pop    rdi
  40745a:	pop    rsi
  40745b:	pop    rbx
  40745c:	ret
  40745d:	sub    rsi,r12
  407460:	mov    DWORD PTR [rbx+0x3c],esi
  407463:	mov    ecx,DWORD PTR [rbx+0x2c]
  407466:	mov    rax,rsi
  407469:	xor    edx,edx
  40746b:	div    rcx
  40746e:	imul   rax,rcx
  407472:	add    r12,rax
  407475:	mov    QWORD PTR [rbx+0x18],r12
  407479:	mov    eax,0x1
  40747e:	add    rsp,0x18
  407482:	pop    r12
  407484:	pop    rdi
  407485:	pop    rsi
  407486:	pop    rbx
  407487:	ret
	...

0000000000407490 <__swc_fn_fc36583a_000012_e4b0ddfc>:
  407490:	sub    rsp,0x8
  407494:	mov    rdx,rcx
  407497:	lea    r9,[rcx+0x60]
  40749b:	mov    rax,QWORD PTR [r9]
  40749e:	test   rax,rax
  4074a1:	jne    4074a8 <__swc_fn_fc36583a_000012_e4b0ddfc+0x18>
  4074a3:	add    rsp,0x8
  4074a7:	ret
  4074a8:	mov    rcx,rdx
  4074ab:	call   40a5d0 <__swc_fn_fc36583a_000010_c3647f66>
  4074b0:	xor    eax,eax
  4074b2:	xchg   QWORD PTR [r9],rax
  4074b5:	mov    r8,rax
  4074b8:	mov    rcx,rdx
  4074bb:	call   40e040 <__swc_fn_fc36583a_000011_861b8b62>
  4074c0:	xor    eax,eax
  4074c2:	test   r8,r8
  4074c5:	je     4074e6 <__swc_fn_fc36583a_000012_e4b0ddfc+0x56>
  4074c7:	nop    WORD PTR [rax+rax*1+0x0]
  4074d0:	mov    rcx,QWORD PTR [r8]
  4074d3:	mov    r9,QWORD PTR [rdx]
  4074d6:	mov    QWORD PTR [r8],r9
  4074d9:	mov    QWORD PTR [rdx],r8
  4074dc:	mov    r8,rcx
  4074df:	inc    eax
  4074e1:	test   rcx,rcx
  4074e4:	jne    4074d0 <__swc_fn_fc36583a_000012_e4b0ddfc+0x40>
  4074e6:	sub    DWORD PTR [rdx+0x28],eax
  4074e9:	add    rsp,0x8
  4074ed:	ret
	...

00000000004074f0 <__swc_fn_fc36583a_000015_9afb7cfb>:
  4074f0:	lea    eax,[rdx+0x1]
  4074f3:	mov    edx,DWORD PTR [rcx+0x28]
  4074f6:	shlx   eax,eax,edx
  4074fb:	shl    rax,0x10
  4074ff:	add    rax,rcx
  407502:	ret
	...

0000000000407510 <__swc_fn_fc36583a_000018_adca76cf>:
  407510:	push   rbx
  407511:	push   rsi
  407512:	push   rdi
  407513:	push   r12
  407515:	push   r13
  407517:	push   r14
  407519:	push   r15
  40751b:	sub    rsp,0x30
  40751f:	mov    rbx,rcx
  407522:	lea    rsi,[rcx+0x48]
  407526:	mov    QWORD PTR [rsp+0x18],rsi
  40752b:	mov    rax,QWORD PTR [rsi]
  40752e:	mov    rdi,rax
  407531:	lea    r12,[rsp+0x8]
  407536:	lea    r13,[rcx+0x40]
  40753a:	nop    WORD PTR [rax+rax*1+0x0]
  407540:	test   rdi,rdi
  407543:	je     407683 <__swc_fn_fc36583a_000018_adca76cf+0x173>
  407549:	xor    eax,eax
  40754b:	tzcnt  rax,rdi
  407550:	mov    DWORD PTR [rsp+0x8],eax
  407554:	mov    r14d,0x1
  40755a:	mov    ecx,eax
  40755c:	shl    r14,cl
  40755f:	andn   rdi,r14,rdi
  407564:	mov    rcx,QWORD PTR [r13+0x0]
  407568:	test   rcx,r14
  40756b:	jne    407540 <__swc_fn_fc36583a_000018_adca76cf+0x30>
  40756d:	mov    rdx,rcx
  407570:	or     rdx,r14
  407573:	mov    rax,rcx
  407576:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  40757c:	cmp    rax,rcx
  40757f:	je     407589 <__swc_fn_fc36583a_000018_adca76cf+0x79>
  407581:	mov    rax,QWORD PTR [rsi]
  407584:	mov    rdi,rax
  407587:	jmp    407540 <__swc_fn_fc36583a_000018_adca76cf+0x30>
  407589:	mov    rcx,rbx
  40758c:	mov    rdx,r14
  40758f:	call   40e1b0 <__swc_fn_fc36583a_000020_fd2b165c>
  407594:	test   al,al
  407596:	je     40766e <__swc_fn_fc36583a_000018_adca76cf+0x15e>
  40759c:	mov    eax,DWORD PTR [r12]
  4075a0:	shl    rax,0x4
  4075a4:	lea    r15,[rbx+rax*8+0x80]
  4075ac:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  4075b4:	lea    rcx,[rip+0x1cad5]        # 424090 <__swc_bss_base_fc36583a+0x50>
  4075bb:	mov    rdx,QWORD PTR [rip+0x1cace]        # 424090 <__swc_bss_base_fc36583a+0x50>
  4075c2:	cs nop WORD PTR [rax+rax*1+0x0]
  4075cc:	nop    DWORD PTR [rax+0x0]
  4075d0:	mov    r8,rdx
  4075d3:	sub    r8,rsi
  4075d6:	mov    rax,rdx
  4075d9:	lock cmpxchg QWORD PTR [rcx],r8
  4075de:	cmp    rax,rdx
  4075e1:	je     4075e8 <__swc_fn_fc36583a_000018_adca76cf+0xd8>
  4075e3:	mov    rdx,rax
  4075e6:	jmp    4075d0 <__swc_fn_fc36583a_000018_adca76cf+0xc0>
  4075e8:	mov    rcx,rbx
  4075eb:	mov    rax,r12
  4075ee:	mov    edx,DWORD PTR [rax]
  4075f0:	call   40e050 <__swc_fn_fc36583a_000014_9dea5065>
  4075f5:	test   rsi,rsi
  4075f8:	je     407666 <__swc_fn_fc36583a_000018_adca76cf+0x156>
  4075fe:	mov    rcx,rax
  407601:	mov    rdx,rsi
  407604:	call   40c840 <__swc_fn_fc36583a_000115_e9fc0224>
  407609:	lea    rcx,[rip+0x1ca70]        # 424080 <__swc_bss_base_fc36583a+0x40>
  407610:	mov    rdx,QWORD PTR [rip+0x1ca69]        # 424080 <__swc_bss_base_fc36583a+0x40>
  407617:	nop    WORD PTR [rax+rax*1+0x0]
  407620:	mov    r8,rdx
  407623:	sub    r8,rsi
  407626:	mov    rax,rdx
  407629:	lock cmpxchg QWORD PTR [rcx],r8
  40762e:	cmp    rax,rdx
  407631:	je     407638 <__swc_fn_fc36583a_000018_adca76cf+0x128>
  407633:	mov    rdx,rax
  407636:	jmp    407620 <__swc_fn_fc36583a_000018_adca76cf+0x110>
  407638:	lea    rcx,[rip+0x1ca59]        # 424098 <__swc_bss_base_fc36583a+0x58>
  40763f:	mov    rdx,QWORD PTR [rip+0x1ca52]        # 424098 <__swc_bss_base_fc36583a+0x58>
  407646:	cs nop WORD PTR [rax+rax*1+0x0]
  407650:	lea    r8,[rdx+0x1]
  407654:	mov    rax,rdx
  407657:	lock cmpxchg QWORD PTR [rcx],r8
  40765c:	cmp    rax,rdx
  40765f:	je     407666 <__swc_fn_fc36583a_000018_adca76cf+0x156>
  407661:	mov    rdx,rax
  407664:	jmp    407650 <__swc_fn_fc36583a_000018_adca76cf+0x140>
  407666:	mov    DWORD PTR [r15+0x3c],0x0
  40766e:	mov    rcx,rbx
  407671:	mov    rdx,r14
  407674:	call   4076a0 <__swc_fn_fc36583a_000021_c8f5f27c>
  407679:	mov    rsi,QWORD PTR [rsp+0x18]
  40767e:	jmp    407540 <__swc_fn_fc36583a_000018_adca76cf+0x30>
  407683:	add    rsp,0x30
  407687:	pop    r15
  407689:	pop    r14
  40768b:	pop    r13
  40768d:	pop    r12
  40768f:	pop    rdi
  407690:	pop    rsi
  407691:	pop    rbx
  407692:	ret
	...

00000000004076a0 <__swc_fn_fc36583a_000021_c8f5f27c>:
  4076a0:	mov    r8,QWORD PTR [rcx+0x40]
  4076a4:	cs nop WORD PTR [rax+rax*1+0x0]
  4076ae:	xchg   ax,ax
  4076b0:	mov    rax,rdx
  4076b3:	not    rax
  4076b6:	mov    r9,r8
  4076b9:	and    r9,rax
  4076bc:	mov    rax,r8
  4076bf:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  4076c5:	cmp    rax,r8
  4076c8:	jne    4076cb <__swc_fn_fc36583a_000021_c8f5f27c+0x2b>
  4076ca:	ret
  4076cb:	mov    r8,rax
  4076ce:	jmp    4076b0 <__swc_fn_fc36583a_000021_c8f5f27c+0x10>

00000000004076d0 <__swc_fn_fc36583a_000024_aa910677>:
  4076d0:	push   rsi
  4076d1:	push   rdi
  4076d2:	sub    rsp,0x8
  4076d6:	mov    rsi,rcx
  4076d9:	call   407510 <__swc_fn_fc36583a_000018_adca76cf>
  4076de:	lea    rdi,[rip+0x1cb43]        # 424228 <__swc_bss_base_fc36583a+0x1e8>
  4076e5:	mov    rcx,rdi
  4076e8:	call   409940 <__swc_fn_fc36583a_000138_86bb0f90>
  4076ed:	mov    QWORD PTR [rsi+0x8],0x0
  4076f5:	mov    QWORD PTR [rsi+0x18],0x0
  4076fd:	mov    rax,QWORD PTR [rip+0x1cb2c]        # 424230 <__swc_bss_base_fc36583a+0x1f0>
  407704:	mov    QWORD PTR [rsi+0x10],rax
  407708:	mov    QWORD PTR [rip+0x1cb21],rsi        # 424230 <__swc_bss_base_fc36583a+0x1f0>
  40770f:	mov    rcx,rdi
  407712:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  407717:	add    rsp,0x8
  40771b:	pop    rdi
  40771c:	pop    rsi
  40771d:	ret
	...

0000000000407720 <__swc_fn_fc36583a_000027_9798fb47>:
  407720:	vxorps xmm0,xmm0,xmm0
  407724:	vmovups XMMWORD PTR [rcx],xmm0
  407728:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40772d:	mov    QWORD PTR [rcx+0x20],0x0
  407735:	ret
	...

0000000000407740 <__swc_fn_fc36583a_000030_9798fb47>:
  407740:	vxorps xmm0,xmm0,xmm0
  407744:	vmovups XMMWORD PTR [rcx],xmm0
  407748:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40774d:	mov    QWORD PTR [rcx+0x20],0x0
  407755:	ret
	...

0000000000407760 <__swc_fn_fc36583a_000033_9128bcf9>:
  407760:	push   r12
  407762:	mov    r12,rdi
  407765:	test   rdi,rdi
  407768:	jne    40776d <__swc_fn_fc36583a_000033_9128bcf9+0xd>
  40776a:	pop    r12
  40776c:	ret
  40776d:	lea    rax,[rip+0x1a894]        # 422008 <__swc_data_base_fc36583a+0x8>
  407774:	mov    rax,QWORD PTR [rax]
  407777:	cmp    rax,0xffffffffffffffff
  40777b:	je     40778a <__swc_fn_fc36583a_000033_9128bcf9+0x2a>
  40777d:	mov    eax,eax
  40777f:	mov    edi,eax
  407781:	xor    eax,eax
  407783:	call   407000 <pthread_getspecific@plt>
  407788:	jmp    40778c <__swc_fn_fc36583a_000033_9128bcf9+0x2c>
  40778a:	xor    eax,eax
  40778c:	cmp    rax,r12
  40778f:	jne    407798 <__swc_fn_fc36583a_000033_9128bcf9+0x38>
  407791:	xor    ecx,ecx
  407793:	call   40e380 <__swc_fn_fc36583a_000035_92d9bbff>
  407798:	mov    rdx,QWORD PTR [r12]
  40779c:	test   rdx,rdx
  40779f:	je     4077b8 <__swc_fn_fc36583a_000033_9128bcf9+0x58>
  4077a1:	mov    rcx,rdx
  4077a4:	call   4077e0 <__swc_fn_fc36583a_000039_eb6108f2>
  4077a9:	test   al,al
  4077ab:	je     4077b8 <__swc_fn_fc36583a_000033_9128bcf9+0x58>
  4077ad:	mov    rcx,rdx
  4077b0:	mov    rdx,r12
  4077b3:	call   4078e0 <__swc_fn_fc36583a_000045_b30433d0>
  4077b8:	pop    r12
  4077ba:	ret
  4077bb:	add    BYTE PTR [rax],al
  4077bd:	add    BYTE PTR [rax],al
	...

00000000004077c0 <__swc_fn_fc36583a_000036_28d0e998>:
  4077c0:	push   rsi
  4077c1:	mov    rsi,rcx
  4077c4:	call   40aa80 <__swc_fn_fc36583a_000034_cd1a4e8c>
  4077c9:	mov    rcx,rax
  4077cc:	mov    rdx,rsi
  4077cf:	call   4097c0 <__swc_fn_fc36583a_000132_ae5891af>
  4077d4:	mov    rcx,rsi
  4077d7:	call   40e380 <__swc_fn_fc36583a_000035_92d9bbff>
  4077dc:	pop    rsi
  4077dd:	ret
	...

00000000004077e0 <__swc_fn_fc36583a_000039_eb6108f2>:
  4077e0:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  4077ea:	sete   al
  4077ed:	ret
	...

00000000004077f0 <__swc_fn_fc36583a_000042_d3c2ab54>:
  4077f0:	push   rsi
  4077f1:	test   rdx,rdx
  4077f4:	jne    4077f8 <__swc_fn_fc36583a_000042_d3c2ab54+0x8>
  4077f6:	pop    rsi
  4077f7:	ret
  4077f8:	mov    rax,r8
  4077fb:	mov    ecx,0x1000
  407800:	test   ecx,ecx
  407802:	mov    r10d,0x8
  407808:	cmove  ecx,r10d
  40780c:	dec    rcx
  40780f:	mov    r10,0xffffffffffffffff
  407816:	sub    r10,rcx
  407819:	cmp    r8,r10
  40781c:	jbe    407822 <__swc_fn_fc36583a_000042_d3c2ab54+0x32>
  40781e:	xor    eax,eax
  407820:	jmp    40782a <__swc_fn_fc36583a_000042_d3c2ab54+0x3a>
  407822:	add    rax,rcx
  407825:	andn   rax,rcx,rax
  40782a:	mov    ecx,0x1000
  40782f:	test   ecx,ecx
  407831:	mov    r8d,0x8
  407837:	cmove  ecx,r8d
  40783b:	dec    rcx
  40783e:	mov    r8,0xffffffffffffffff
  407845:	sub    r8,rcx
  407848:	cmp    r9,r8
  40784b:	jbe    407851 <__swc_fn_fc36583a_000042_d3c2ab54+0x61>
  40784d:	xor    esi,esi
  40784f:	jmp    40785c <__swc_fn_fc36583a_000042_d3c2ab54+0x6c>
  407851:	add    r9,rcx
  407854:	andn   r9,rcx,r9
  407859:	mov    rsi,r9
  40785c:	mov    rcx,rdx
  40785f:	mov    rdx,rax
  407862:	mov    r8,rsi
  407865:	call   4093c0 <__swc_fn_fc36583a_000117_5208f471>
  40786a:	lea    rcx,[rip+0x1c80f]        # 424080 <__swc_bss_base_fc36583a+0x40>
  407871:	mov    rdx,QWORD PTR [rip+0x1c808]        # 424080 <__swc_bss_base_fc36583a+0x40>
  407878:	nop    DWORD PTR [rax+rax*1+0x0]
  407880:	mov    r8,rdx
  407883:	sub    r8,rsi
  407886:	mov    rax,rdx
  407889:	lock cmpxchg QWORD PTR [rcx],r8
  40788e:	cmp    rax,rdx
  407891:	je     407898 <__swc_fn_fc36583a_000042_d3c2ab54+0xa8>
  407893:	mov    rdx,rax
  407896:	jmp    407880 <__swc_fn_fc36583a_000042_d3c2ab54+0x90>
  407898:	lea    rcx,[rip+0x1c7f9]        # 424098 <__swc_bss_base_fc36583a+0x58>
  40789f:	mov    rdx,QWORD PTR [rip+0x1c7f2]        # 424098 <__swc_bss_base_fc36583a+0x58>
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	lea    r8,[rdx+0x1]
  4078b4:	mov    rax,rdx
  4078b7:	lock cmpxchg QWORD PTR [rcx],r8
  4078bc:	cmp    rax,rdx
  4078bf:	je     4078c6 <__swc_fn_fc36583a_000042_d3c2ab54+0xd6>
  4078c1:	mov    rdx,rax
  4078c4:	jmp    4078b0 <__swc_fn_fc36583a_000042_d3c2ab54+0xc0>
  4078c6:	pop    rsi
  4078c7:	ret
	...

00000000004078e0 <__swc_fn_fc36583a_000045_b30433d0>:
  4078e0:	push   rbx
  4078e1:	push   rsi
  4078e2:	push   rdi
  4078e3:	push   r12
  4078e5:	push   r13
  4078e7:	push   r14
  4078e9:	push   r15
  4078eb:	sub    rsp,0x30
  4078ef:	mov    rbx,rdx
  4078f2:	mov    QWORD PTR [rsp+0x18],rdx
  4078f7:	mov    rsi,rcx
  4078fa:	mov    eax,0x1
  4078ff:	xchg   DWORD PTR [rbx+0x20],eax
  407902:	test   eax,eax
  407904:	je     407916 <__swc_fn_fc36583a_000045_b30433d0+0x36>
  407906:	add    rsp,0x30
  40790a:	pop    r15
  40790c:	pop    r14
  40790e:	pop    r13
  407910:	pop    r12
  407912:	pop    rdi
  407913:	pop    rsi
  407914:	pop    rbx
  407915:	ret
  407916:	mov    rcx,rsi
  407919:	mov    rdx,rbx
  40791c:	mov    r8,0xffffffffffffffff
  407923:	call   40e950 <__swc_fn_fc36583a_000062_dea90857>
  407928:	lea    rdi,[rsi+0x10]
  40792c:	mov    QWORD PTR [rsp+0x20],rdi
  407931:	mov    rcx,rdi
  407934:	call   409940 <__swc_fn_fc36583a_000138_86bb0f90>
  407939:	xor    r12d,r12d
  40793c:	cs nop WORD PTR [rax+rax*1+0x0]
  407946:	cs nop WORD PTR [rax+rax*1+0x0]
  407950:	mov    eax,r12d
  407953:	lea    r13,[rax+rax*4]
  407957:	lea    r13,[rbx+r13*8+0x28]
  40795c:	mov    rax,QWORD PTR [r13+0x8]
  407960:	mov    QWORD PTR [rsp+0x8],rax
  407965:	mov    rax,QWORD PTR [r13+0x18]
  407969:	mov    QWORD PTR [rsp+0x10],rax
  40796e:	mov    r14d,0x2
  407974:	xor    r15d,r15d
  407977:	test   r14,r14
  40797a:	je     4079f7 <__swc_fn_fc36583a_000045_b30433d0+0x117>
  407980:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  407985:	mov    rdi,rax
  407988:	test   rdi,rdi
  40798b:	je     4079e9 <__swc_fn_fc36583a_000045_b30433d0+0x109>
  40798d:	nop    DWORD PTR [rax]
  407990:	mov    rbx,QWORD PTR [rdi+0x48]
  407994:	mov    DWORD PTR [rdi+0x6c],0x0
  40799b:	mov    rcx,rdi
  40799e:	call   407490 <__swc_fn_fc36583a_000012_e4b0ddfc>
  4079a3:	cmp    DWORD PTR [rdi+0x28],0x0
  4079a7:	jne    4079c0 <__swc_fn_fc36583a_000045_b30433d0+0xe0>
  4079a9:	mov    rax,rdi
  4079ac:	and    rax,0xffffffffffc00000
  4079b3:	mov    rcx,rax
  4079b6:	mov    rdx,rdi
  4079b9:	call   40e070 <__swc_fn_fc36583a_000017_283e2b5e>
  4079be:	jmp    4079e1 <__swc_fn_fc36583a_000045_b30433d0+0x101>
  4079c0:	mov    QWORD PTR [rdi+0x40],0x0
  4079c8:	rex mov BYTE PTR [rdi+0x3b],0x2
  4079cd:	mov    QWORD PTR [rdi+0x50],0x0
  4079d5:	mov    rax,QWORD PTR [rsi+0x28]
  4079d9:	mov    QWORD PTR [rdi+0x48],rax
  4079dd:	mov    QWORD PTR [rsi+0x28],rdi
  4079e1:	mov    rdi,rbx
  4079e4:	test   rbx,rbx
  4079e7:	jne    407990 <__swc_fn_fc36583a_000045_b30433d0+0xb0>
  4079e9:	add    r15,0x1
  4079ed:	sub    r14,0x1
  4079f1:	jne    407980 <__swc_fn_fc36583a_000045_b30433d0+0xa0>
  4079f7:	vxorps xmm0,xmm0,xmm0
  4079fb:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407a01:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407a07:	mov    QWORD PTR [r13+0x20],0x0
  407a0f:	add    r12,0x1
  407a13:	cmp    r12,0x2d
  407a17:	mov    rbx,QWORD PTR [rsp+0x18]
  407a1c:	jb     407950 <__swc_fn_fc36583a_000045_b30433d0+0x70>
  407a22:	mov    rcx,rsi
  407a25:	mov    rbx,QWORD PTR [rsp+0x18]
  407a2a:	mov    rdx,rbx
  407a2d:	mov    rdi,QWORD PTR [rsp+0x20]
  407a32:	call   40ac40 <__swc_fn_fc36583a_000046_6e7a8d58>
  407a37:	mov    rcx,rdi
  407a3a:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  407a3f:	mov    rcx,rsi
  407a42:	mov    rdx,rbx
  407a45:	mov    r8d,0x9b8
  407a4b:	mov    r9d,0x9b8
  407a51:	call   4077f0 <__swc_fn_fc36583a_000042_d3c2ab54>
  407a56:	add    rsp,0x30
  407a5a:	pop    r15
  407a5c:	pop    r14
  407a5e:	pop    r13
  407a60:	pop    r12
  407a62:	pop    rdi
  407a63:	pop    rsi
  407a64:	pop    rbx
  407a65:	ret
	...

0000000000407a80 <__swc_fn_fc36583a_000048_ad48ec88>:
  407a80:	push   rbx
  407a81:	push   rsi
  407a82:	push   rdi
  407a83:	push   r12
  407a85:	push   r13
  407a87:	push   r14
  407a89:	push   r15
  407a8b:	sub    rsp,0x30
  407a8f:	mov    ebx,r8d
  407a92:	mov    rsi,rcx
  407a95:	mov    rdi,rdx
  407a98:	test   r8d,r8d
  407a9b:	jne    407aa4 <__swc_fn_fc36583a_000048_ad48ec88+0x24>
  407a9d:	mov    eax,0x8
  407aa2:	jmp    407acb <__swc_fn_fc36583a_000048_ad48ec88+0x4b>
  407aa4:	cmp    ebx,0x8
  407aa7:	ja     407ab2 <__swc_fn_fc36583a_000048_ad48ec88+0x32>
  407aa9:	mov    rax,rbx
  407aac:	shl    rax,0x4
  407ab0:	jmp    407acb <__swc_fn_fc36583a_000048_ad48ec88+0x4b>
  407ab2:	lea    eax,[rbx-0x9]
  407ab5:	mov    ecx,eax
  407ab7:	shr    ecx,0x2
  407aba:	and    eax,0x3
  407abd:	lea    ecx,[rcx+0x7]
  407ac0:	lea    ecx,[rcx-0x2]
  407ac3:	lea    eax,[rax+0x5]
  407ac6:	shlx   rax,rax,rcx
  407acb:	lea    r12,[rsp+0x8]
  407ad0:	mov    DWORD PTR [rsp+0x8],eax
  407ad4:	lea    r13,[rsp+0xc]
  407ad9:	mov    QWORD PTR [rsp+0x18],r13
  407ade:	xor    eax,eax
  407ae0:	cmp    ebx,0x21
  407ae3:	setae  al
  407ae6:	lea    eax,[rax+rax*2]
  407ae9:	mov    DWORD PTR [rsp+0xc],eax
  407aed:	lea    r14,[rsi+0x10]
  407af1:	mov    rcx,r14
  407af4:	call   409940 <__swc_fn_fc36583a_000138_86bb0f90>
  407af9:	xor    eax,eax
  407afb:	mov    rcx,QWORD PTR [rsi+0x28]
  407aff:	mov    r15,rcx
  407b02:	test   r15,r15
  407b05:	je     407bb6 <__swc_fn_fc36583a_000048_ad48ec88+0x136>
  407b0b:	cs nop WORD PTR [rax+rax*1+0x0]
  407b15:	cs nop WORD PTR [rax+rax*1+0x0]
  407b1f:	nop
  407b20:	mov    rcx,QWORD PTR [r15+0x48]
  407b24:	movzx  edx,BYTE PTR [r15+0x39]
  407b29:	cmp    edx,ebx
  407b2b:	jne    407ba7 <__swc_fn_fc36583a_000048_ad48ec88+0x127>
  407b2d:	test   rax,rax
  407b30:	jne    407b38 <__swc_fn_fc36583a_000048_ad48ec88+0xb8>
  407b32:	mov    QWORD PTR [rsi+0x28],rcx
  407b36:	jmp    407b3c <__swc_fn_fc36583a_000048_ad48ec88+0xbc>
  407b38:	mov    QWORD PTR [rax+0x48],rcx
  407b3c:	vxorps xmm0,xmm0,xmm0
  407b40:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407b46:	mov    BYTE PTR [r15+0x3b],0x1
  407b4b:	mov    QWORD PTR [r15+0x40],rdi
  407b4f:	mov    rcx,r15
  407b52:	call   407490 <__swc_fn_fc36583a_000012_e4b0ddfc>
  407b57:	movzx  eax,BYTE PTR [r15+0x39]
  407b5c:	lea    rax,[rax+rax*4]
  407b60:	lea    rax,[rdi+rax*8+0x28]
  407b65:	mov    rcx,QWORD PTR [rax+0x10]
  407b69:	mov    QWORD PTR [r15+0x50],rcx
  407b6d:	mov    QWORD PTR [r15+0x48],0x0
  407b75:	mov    rcx,QWORD PTR [rax+0x10]
  407b79:	test   rcx,rcx
  407b7c:	je     407b84 <__swc_fn_fc36583a_000048_ad48ec88+0x104>
  407b7e:	mov    QWORD PTR [rcx+0x48],r15
  407b82:	jmp    407b88 <__swc_fn_fc36583a_000048_ad48ec88+0x108>
  407b84:	mov    QWORD PTR [rax+0x8],r15
  407b88:	mov    QWORD PTR [rax+0x10],r15
  407b8c:	mov    rcx,r14
  407b8f:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  407b94:	mov    rax,r15
  407b97:	add    rsp,0x30
  407b9b:	pop    r15
  407b9d:	pop    r14
  407b9f:	pop    r13
  407ba1:	pop    r12
  407ba3:	pop    rdi
  407ba4:	pop    rsi
  407ba5:	pop    rbx
  407ba6:	ret
  407ba7:	mov    rax,r15
  407baa:	mov    r15,rcx
  407bad:	test   rcx,rcx
  407bb0:	jne    407b20 <__swc_fn_fc36583a_000048_ad48ec88+0xa0>
  407bb6:	mov    rax,QWORD PTR [rsi+0x18]
  407bba:	mov    r15,rax
  407bbd:	test   r15,r15
  407bc0:	je     407c56 <__swc_fn_fc36583a_000048_ad48ec88+0x1d6>
  407bc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407bd0:	mov    eax,DWORD PTR [rsp+0xc]
  407bd4:	cmp    DWORD PTR [r15+0x28],eax
  407bd8:	jne    407c46 <__swc_fn_fc36583a_000048_ad48ec88+0x1c6>
  407bda:	mov    rcx,r15
  407bdd:	mov    edx,ebx
  407bdf:	mov    rax,r12
  407be2:	mov    r8d,DWORD PTR [rax]
  407be5:	call   40a680 <__swc_fn_fc36583a_000016_efc44797>
  407bea:	mov    r13,rax
  407bed:	test   rax,rax
  407bf0:	je     407c46 <__swc_fn_fc36583a_000048_ad48ec88+0x1c6>
  407bf2:	mov    QWORD PTR [r13+0x40],rdi
  407bf6:	movzx  eax,BYTE PTR [r13+0x39]
  407bfb:	lea    rax,[rax+rax*4]
  407bff:	lea    rax,[rdi+rax*8+0x28]
  407c04:	mov    rcx,QWORD PTR [rax+0x10]
  407c08:	mov    QWORD PTR [r13+0x50],rcx
  407c0c:	mov    QWORD PTR [r13+0x48],0x0
  407c14:	mov    rcx,QWORD PTR [rax+0x10]
  407c18:	test   rcx,rcx
  407c1b:	je     407c23 <__swc_fn_fc36583a_000048_ad48ec88+0x1a3>
  407c1d:	mov    QWORD PTR [rcx+0x48],r13
  407c21:	jmp    407c27 <__swc_fn_fc36583a_000048_ad48ec88+0x1a7>
  407c23:	mov    QWORD PTR [rax+0x8],r13
  407c27:	mov    QWORD PTR [rax+0x10],r13
  407c2b:	mov    rcx,r14
  407c2e:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  407c33:	mov    rax,r13
  407c36:	add    rsp,0x30
  407c3a:	pop    r15
  407c3c:	pop    r14
  407c3e:	pop    r13
  407c40:	pop    r12
  407c42:	pop    rdi
  407c43:	pop    rsi
  407c44:	pop    rbx
  407c45:	ret
  407c46:	mov    rax,QWORD PTR [r15+0x10]
  407c4a:	mov    r15,rax
  407c4d:	test   rax,rax
  407c50:	jne    407bd0 <__swc_fn_fc36583a_000048_ad48ec88+0x150>
  407c56:	mov    rcx,rsi
  407c59:	mov    r13,QWORD PTR [rsp+0x18]
  407c5e:	mov    edx,DWORD PTR [r13+0x0]
  407c62:	call   40e1f0 <__swc_fn_fc36583a_000023_2685aade>
  407c67:	mov    r13,rax
  407c6a:	test   rax,rax
  407c6d:	jne    407c89 <__swc_fn_fc36583a_000048_ad48ec88+0x209>
  407c6f:	mov    rcx,r14
  407c72:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  407c77:	xor    eax,eax
  407c79:	add    rsp,0x30
  407c7d:	pop    r15
  407c7f:	pop    r14
  407c81:	pop    r13
  407c83:	pop    r12
  407c85:	pop    rdi
  407c86:	pop    rsi
  407c87:	pop    rbx
  407c88:	ret
  407c89:	mov    rcx,r13
  407c8c:	mov    edx,ebx
  407c8e:	mov    r8d,DWORD PTR [r12]
  407c92:	call   40a680 <__swc_fn_fc36583a_000016_efc44797>
  407c97:	mov    rbx,rax
  407c9a:	test   rax,rax
  407c9d:	jne    407cc1 <__swc_fn_fc36583a_000048_ad48ec88+0x241>
  407c9f:	mov    rcx,r13
  407ca2:	call   4076d0 <__swc_fn_fc36583a_000024_aa910677>
  407ca7:	mov    rcx,r14
  407caa:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  407caf:	xor    eax,eax
  407cb1:	add    rsp,0x30
  407cb5:	pop    r15
  407cb7:	pop    r14
  407cb9:	pop    r13
  407cbb:	pop    r12
  407cbd:	pop    rdi
  407cbe:	pop    rsi
  407cbf:	pop    rbx
  407cc0:	ret
  407cc1:	mov    rax,QWORD PTR [rsi+0x18]
  407cc5:	mov    QWORD PTR [r13+0x10],rax
  407cc9:	mov    rax,QWORD PTR [rsi+0x18]
  407ccd:	test   rax,rax
  407cd0:	je     407cd6 <__swc_fn_fc36583a_000048_ad48ec88+0x256>
  407cd2:	mov    QWORD PTR [rax+0x18],r13
  407cd6:	mov    QWORD PTR [rsi+0x18],r13
  407cda:	mov    QWORD PTR [rbx+0x40],rdi
  407cde:	movzx  eax,BYTE PTR [rbx+0x39]
  407ce2:	lea    rax,[rax+rax*4]
  407ce6:	lea    rax,[rdi+rax*8+0x28]
  407ceb:	mov    rcx,QWORD PTR [rax+0x10]
  407cef:	mov    QWORD PTR [rbx+0x50],rcx
  407cf3:	mov    QWORD PTR [rbx+0x48],0x0
  407cfb:	mov    rcx,QWORD PTR [rax+0x10]
  407cff:	test   rcx,rcx
  407d02:	je     407d0a <__swc_fn_fc36583a_000048_ad48ec88+0x28a>
  407d04:	mov    QWORD PTR [rcx+0x48],rbx
  407d08:	jmp    407d0e <__swc_fn_fc36583a_000048_ad48ec88+0x28e>
  407d0a:	mov    QWORD PTR [rax+0x8],rbx
  407d0e:	mov    QWORD PTR [rax+0x10],rbx
  407d12:	mov    rcx,r14
  407d15:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  407d1a:	mov    rax,rbx
  407d1d:	add    rsp,0x30
  407d21:	pop    r15
  407d23:	pop    r14
  407d25:	pop    r13
  407d27:	pop    r12
  407d29:	pop    rdi
  407d2a:	pop    rsi
  407d2b:	pop    rbx
  407d2c:	ret
	...

0000000000407d40 <__swc_fn_fc36583a_000051_d846b172>:
  407d40:	push   rsi
  407d41:	push   rdi
  407d42:	push   r12
  407d44:	mov    rsi,rdx
  407d47:	mov    rdi,rcx
  407d4a:	lea    rax,[rcx+0x2a80]
  407d51:	mov    rcx,QWORD PTR [rax]
  407d54:	test   rcx,rcx
  407d57:	jne    407d5e <__swc_fn_fc36583a_000051_d846b172+0x1e>
  407d59:	pop    r12
  407d5b:	pop    rdi
  407d5c:	pop    rsi
  407d5d:	ret
  407d5e:	xor    ecx,ecx
  407d60:	xchg   QWORD PTR [rax],rcx
  407d63:	mov    r12,rcx
  407d66:	cs nop WORD PTR [rax+rax*1+0x0]
  407d70:	cs nop WORD PTR [rax+rax*1+0x0]
  407d7a:	nop    WORD PTR [rax+rax*1+0x0]
  407d80:	test   r12,r12
  407d83:	je     407e1a <__swc_fn_fc36583a_000051_d846b172+0xda>
  407d89:	mov    r8,r12
  407d8c:	mov    r12,QWORD PTR [r12+0x78]
  407d91:	lea    rcx,[r8+0x70]
  407d95:	xor    eax,eax
  407d97:	xchg   DWORD PTR [r8+0x70],eax
  407d9b:	cmp    QWORD PTR [r8+0x40],rsi
  407d9f:	jne    407db6 <__swc_fn_fc36583a_000051_d846b172+0x76>
  407da1:	mov    eax,DWORD PTR [r8+0x6c]
  407da5:	test   eax,eax
  407da7:	je     407d80 <__swc_fn_fc36583a_000051_d846b172+0x40>
  407da9:	mov    rcx,rdi
  407dac:	mov    rdx,rsi
  407daf:	call   40e5b0 <__swc_fn_fc36583a_000050_e072b516>
  407db4:	jmp    407d80 <__swc_fn_fc36583a_000051_d846b172+0x40>
  407db6:	mov    rax,QWORD PTR [r8+0x40]
  407dba:	test   rax,rax
  407dbd:	je     407d80 <__swc_fn_fc36583a_000051_d846b172+0x40>
  407dbf:	mov    eax,DWORD PTR [r8+0x6c]
  407dc3:	test   eax,eax
  407dc5:	je     407d80 <__swc_fn_fc36583a_000051_d846b172+0x40>
  407dc7:	mov    r9d,0x1
  407dcd:	xor    eax,eax
  407dcf:	lock cmpxchg DWORD PTR [rcx],r9d
  407dd4:	test   eax,eax
  407dd6:	jne    407d80 <__swc_fn_fc36583a_000051_d846b172+0x40>
  407dd8:	mov    rax,r8
  407ddb:	and    rax,0xffffffffffc00000
  407de2:	mov    rax,QWORD PTR [rax+0x8]
  407de6:	test   rax,rax
  407de9:	jne    407df1 <__swc_fn_fc36583a_000051_d846b172+0xb1>
  407deb:	xor    eax,eax
  407ded:	xchg   DWORD PTR [rcx],eax
  407def:	jmp    407d80 <__swc_fn_fc36583a_000051_d846b172+0x40>
  407df1:	lea    rcx,[rax+0x2a80]
  407df8:	mov    rax,QWORD PTR [rcx]
  407dfb:	mov    rdx,rax
  407dfe:	xchg   ax,ax
  407e00:	mov    QWORD PTR [r8+0x78],rdx
  407e04:	mov    rax,rdx
  407e07:	lock cmpxchg QWORD PTR [rcx],r8
  407e0c:	cmp    rax,rdx
  407e0f:	je     407d80 <__swc_fn_fc36583a_000051_d846b172+0x40>
  407e15:	mov    rdx,rax
  407e18:	jmp    407e00 <__swc_fn_fc36583a_000051_d846b172+0xc0>
  407e1a:	pop    r12
  407e1c:	pop    rdi
  407e1d:	pop    rsi
  407e1e:	ret
	...

0000000000407e20 <__swc_fn_fc36583a_000054_2e3450f7>:
  407e20:	sub    rsp,0x8
  407e24:	mov    r9,r8
  407e27:	movzx  eax,BYTE PTR [r9+0x39]
  407e2c:	lea    rax,[rax+rax*4]
  407e30:	lea    rax,[rdx+rax*8+0x28]
  407e35:	cmp    QWORD PTR [rax],r9
  407e38:	je     407e40 <__swc_fn_fc36583a_000054_2e3450f7+0x20>
  407e3a:	cmp    QWORD PTR [rax+0x20],r9
  407e3e:	jne    407e45 <__swc_fn_fc36583a_000054_2e3450f7+0x25>
  407e40:	add    rsp,0x8
  407e44:	ret
  407e45:	cmp    QWORD PTR [rax+0x20],0x0
  407e4a:	je     407e57 <__swc_fn_fc36583a_000054_2e3450f7+0x37>
  407e4c:	mov    r8,QWORD PTR [rax+0x20]
  407e50:	cmp    DWORD PTR [r8+0x28],0x0
  407e55:	je     407e60 <__swc_fn_fc36583a_000054_2e3450f7+0x40>
  407e57:	mov    QWORD PTR [rax+0x20],r9
  407e5b:	add    rsp,0x8
  407e5f:	ret
  407e60:	mov    r8,r9
  407e63:	call   40e510 <__swc_fn_fc36583a_000047_137687bb>
  407e68:	mov    rax,r9
  407e6b:	and    rax,0xffffffffffc00000
  407e72:	mov    rcx,rax
  407e75:	mov    rdx,r9
  407e78:	call   40e070 <__swc_fn_fc36583a_000017_283e2b5e>
  407e7d:	add    rsp,0x8
  407e81:	ret
	...

0000000000407e90 <__swc_fn_fc36583a_000057_1bb23e77>:
  407e90:	push   rsi
  407e91:	push   rdi
  407e92:	push   r12
  407e94:	mov    rsi,rdx
  407e97:	mov    rax,rdx
  407e9a:	shr    rax,0xc
  407e9e:	movabs rdx,0x9e3779b97f4a7c15
  407ea8:	imul   rax,rdx
  407eac:	shr    rax,0x20
  407eb0:	lea    rax,[rax*8+0x0]
  407eb8:	shr    rax,0x20
  407ebc:	lea    rax,[rax*8+0x0]
  407ec4:	lea    rax,[rcx+rax*8+0x40]
  407ec9:	xor    edx,edx
  407ecb:	test   dl,dl
  407ecd:	lea    rdi,[rcx+0x8]
  407ed1:	cmove  rdi,rax
  407ed5:	xor    edx,edx
  407ed7:	test   dl,dl
  407ed9:	lea    r12,[rcx+0x30]
  407edd:	lea    rax,[rax+0x8]
  407ee1:	cmove  r12,rax
  407ee5:	mov    rcx,rdi
  407ee8:	call   409940 <__swc_fn_fc36583a_000138_86bb0f90>
  407eed:	mov    rax,QWORD PTR [rsi+0x30]
  407ef1:	test   rax,rax
  407ef4:	jne    407f00 <__swc_fn_fc36583a_000057_1bb23e77+0x70>
  407ef6:	mov    rax,QWORD PTR [rsi+0x38]
  407efa:	mov    QWORD PTR [r12],rax
  407efe:	jmp    407f08 <__swc_fn_fc36583a_000057_1bb23e77+0x78>
  407f00:	mov    rcx,QWORD PTR [rsi+0x38]
  407f04:	mov    QWORD PTR [rax+0x38],rcx
  407f08:	mov    rax,QWORD PTR [rsi+0x38]
  407f0c:	test   rax,rax
  407f0f:	je     407f19 <__swc_fn_fc36583a_000057_1bb23e77+0x89>
  407f11:	mov    rcx,QWORD PTR [rsi+0x30]
  407f15:	mov    QWORD PTR [rax+0x30],rcx
  407f19:	vxorps xmm0,xmm0,xmm0
  407f1d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407f22:	mov    rcx,rdi
  407f25:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  407f2a:	pop    r12
  407f2c:	pop    rdi
  407f2d:	pop    rsi
  407f2e:	ret
	...

0000000000407f30 <__swc_fn_fc36583a_000060_ad030a10>:
  407f30:	mov    rax,QWORD PTR [rcx+0x250]
  407f37:	mov    rcx,rax
  407f3a:	cmp    rax,0x1000000
  407f41:	mov    eax,0x1000000
  407f46:	cmovb  rcx,rax
  407f4a:	mov    rax,rcx
  407f4d:	cmp    rcx,0x10000000
  407f54:	mov    ecx,0x10000000
  407f59:	cmova  rax,rcx
  407f5d:	ret
	...

0000000000407f60 <__swc_fn_fc36583a_000063_ffcd96eb>:
  407f60:	push   rsi
  407f61:	push   rdi
  407f62:	push   r12
  407f64:	mov    rsi,rcx
  407f67:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407f6e:	xor    r12d,r12d
  407f71:	test   rdi,rdi
  407f74:	jbe    407fab <__swc_fn_fc36583a_000063_ffcd96eb+0x4b>
  407f76:	cs nop WORD PTR [rax+rax*1+0x0]
  407f80:	lea    rax,[r12+r12*4]
  407f84:	lea    rax,[rsi+rax*8+0x268]
  407f8c:	mov    rcx,rsi
  407f8f:	mov    rdx,QWORD PTR [rax]
  407f92:	mov    r8,QWORD PTR [rax+0x8]
  407f96:	mov    rax,QWORD PTR [rax+0x10]
  407f9a:	mov    r9,rax
  407f9d:	call   4077f0 <__swc_fn_fc36583a_000042_d3c2ab54>
  407fa2:	add    r12,0x1
  407fa6:	cmp    r12,rdi
  407fa9:	jb     407f80 <__swc_fn_fc36583a_000063_ffcd96eb+0x20>
  407fab:	vxorps xmm0,xmm0,xmm0
  407faf:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407fb7:	pop    r12
  407fb9:	pop    rdi
  407fba:	pop    rsi
  407fbb:	ret
  407fbc:	add    BYTE PTR [rax],al
	...

0000000000407fc0 <__swc_fn_fc36583a_000066_8c7d044b>:
  407fc0:	push   rsi
  407fc1:	push   rdi
  407fc2:	sub    rsp,0x8
  407fc6:	mov    rsi,rcx
  407fc9:	call   40afc0 <__swc_fn_fc36583a_000055_df0696cd>
  407fce:	mov    rdi,rax
  407fd1:	mov    rcx,rsi
  407fd4:	mov    rdx,rax
  407fd7:	call   407e90 <__swc_fn_fc36583a_000057_1bb23e77>
  407fdc:	mov    rcx,QWORD PTR [rdi+0x28]
  407fe0:	mov    rdx,QWORD PTR [rsi+0x250]
  407fe7:	nop    WORD PTR [rax+rax*1+0x0]
  407ff0:	mov    r8,rdx
  407ff3:	sub    r8,rcx
  407ff6:	mov    rax,rdx
  407ff9:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  408002:	cmp    rax,rdx
  408005:	je     40800c <__swc_fn_fc36583a_000066_8c7d044b+0x4c>
  408007:	mov    rdx,rax
  40800a:	jmp    407ff0 <__swc_fn_fc36583a_000066_8c7d044b+0x30>
  40800c:	mov    rcx,rsi
  40800f:	mov    rdx,QWORD PTR [rdi]
  408012:	mov    r8,QWORD PTR [rdi+0x8]
  408016:	mov    r9,QWORD PTR [rdi+0x10]
  40801a:	call   40b0e0 <__swc_fn_fc36583a_000061_b304235a>
  40801f:	mov    rcx,rsi
  408022:	call   40ad20 <__swc_fn_fc36583a_000052_3af34d7f>
  408027:	add    rsp,0x8
  40802b:	pop    rdi
  40802c:	pop    rsi
  40802d:	ret
	...

0000000000408030 <__swc_fn_fc36583a_000069_97813b89>:
  408030:	push   r12
  408032:	push   r13
  408034:	push   r14
  408036:	push   rdi
  408037:	push   rsi
  408038:	sub    rsp,0x1b0
  40803f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  408048:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  408051:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  40805a:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  408063:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  40806c:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  408075:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  40807e:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  408087:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  408090:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  408099:	mov    r8,rdx
  40809c:	mov    r12,rcx
  40809f:	mov    r13,QWORD PTR [r8+0x40]
  4080a3:	test   r13,r13
  4080a6:	jne    4080b8 <__swc_fn_fc36583a_000069_97813b89+0x88>
  4080a8:	add    rsp,0x1b0
  4080af:	pop    rsi
  4080b0:	pop    rdi
  4080b1:	pop    r14
  4080b3:	pop    r13
  4080b5:	pop    r12
  4080b7:	ret
  4080b8:	mov    QWORD PTR [r8+0x40],0x0
  4080c0:	lea    rax,[rip+0x1bfe1]        # 4240a8 <__swc_bss_base_fc36583a+0x68>
  4080c7:	mov    rcx,r13
  4080ca:	sub    rcx,QWORD PTR [rax+0x8]
  4080ce:	mov    rax,QWORD PTR [rip+0x1bfe3]        # 4240b8 <__swc_bss_base_fc36583a+0x78>
  4080d5:	cmp    rcx,rax
  4080d8:	jae    408104 <__swc_fn_fc36583a_000069_97813b89+0xd4>
  4080da:	mov    rax,r13
  4080dd:	and    rax,0xffffffffffc00000
  4080e4:	mov    rcx,r13
  4080e7:	shr    rcx,0x10
  4080eb:	and    ecx,0x3f
  4080ee:	mov    edx,DWORD PTR [rax+0x28]
  4080f1:	shrx   ecx,ecx,edx
  4080f6:	shl    rcx,0x4
  4080fa:	lea    r14,[rax+rcx*8+0x80]
  408102:	jmp    40811f <__swc_fn_fc36583a_000069_97813b89+0xef>
  408104:	mov    rcx,r13
  408107:	mov    QWORD PTR [rsp+0xf8],r8
  40810f:	call   40a9b0 <__swc_fn_fc36583a_000025_bcdc5519>
  408114:	mov    r8,QWORD PTR [rsp+0xf8]
  40811c:	mov    r14,rax
  40811f:	test   r14,r14
  408122:	jne    408134 <__swc_fn_fc36583a_000069_97813b89+0x104>
  408124:	mov    rcx,r12
  408127:	mov    rdx,r13
  40812a:	call   407fc0 <__swc_fn_fc36583a_000066_8c7d044b>
  40812f:	jmp    4081c2 <__swc_fn_fc36583a_000069_97813b89+0x192>
  408134:	lea    rax,[rip+0x19ecd]        # 422008 <__swc_data_base_fc36583a+0x8>
  40813b:	mov    rax,QWORD PTR [rax]
  40813e:	cmp    rax,0xffffffffffffffff
  408142:	je     408151 <__swc_fn_fc36583a_000069_97813b89+0x121>
  408144:	mov    eax,eax
  408146:	mov    edi,eax
  408148:	xor    eax,eax
  40814a:	call   407000 <pthread_getspecific@plt>
  40814f:	jmp    408153 <__swc_fn_fc36583a_000069_97813b89+0x123>
  408151:	xor    eax,eax
  408153:	test   rax,rax
  408156:	jne    408165 <__swc_fn_fc36583a_000069_97813b89+0x135>
  408158:	call   40aa80 <__swc_fn_fc36583a_000034_cd1a4e8c>
  40815d:	mov    rcx,rax
  408160:	call   410540 <__swc_fn_fc36583a_000131_5f757033>
  408165:	test   rax,rax
  408168:	je     4081b7 <__swc_fn_fc36583a_000069_97813b89+0x187>
  40816a:	cmp    QWORD PTR [r14+0x40],rax
  40816e:	jne    4081b7 <__swc_fn_fc36583a_000069_97813b89+0x187>
  408170:	mov    ecx,DWORD PTR [r14+0x6c]
  408174:	test   ecx,ecx
  408176:	je     408196 <__swc_fn_fc36583a_000069_97813b89+0x166>
  408178:	mov    rcx,r12
  40817b:	mov    rdx,rax
  40817e:	mov    r8,r14
  408181:	mov    QWORD PTR [rsp+0x100],rax
  408189:	call   40e5b0 <__swc_fn_fc36583a_000050_e072b516>
  40818e:	mov    rax,QWORD PTR [rsp+0x100]
  408196:	mov    rcx,QWORD PTR [r14]
  408199:	mov    QWORD PTR [r13+0x0],rcx
  40819d:	mov    QWORD PTR [r14],r13
  4081a0:	sub    DWORD PTR [r14+0x28],0x1
  4081a5:	jne    4081c2 <__swc_fn_fc36583a_000069_97813b89+0x192>
  4081a7:	mov    rcx,r12
  4081aa:	mov    rdx,rax
  4081ad:	mov    r8,r14
  4081b0:	call   407e20 <__swc_fn_fc36583a_000054_2e3450f7>
  4081b5:	jmp    4081c2 <__swc_fn_fc36583a_000069_97813b89+0x192>
  4081b7:	mov    rcx,r14
  4081ba:	mov    rdx,r13
  4081bd:	call   40a5f0 <__swc_fn_fc36583a_000013_524c1f23>
  4081c2:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  4081cb:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  4081d4:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  4081dd:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  4081e6:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  4081ef:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  4081f8:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408201:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40820a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408213:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40821c:	add    rsp,0x1b0
  408223:	pop    rsi
  408224:	pop    rdi
  408225:	pop    r14
  408227:	pop    r13
  408229:	pop    r12
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_fc36583a_000072_9c99bf04>:
  408230:	push   rsi
  408231:	mov    rsi,rcx
  408234:	call   4077e0 <__swc_fn_fc36583a_000039_eb6108f2>
  408239:	test   al,al
  40823b:	jne    40823f <__swc_fn_fc36583a_000072_9c99bf04+0xf>
  40823d:	pop    rsi
  40823e:	ret
  40823f:	lea    rax,[rip+0x1bffa]        # 424240 <__swc_bss_base_fc36583a+0x200>
  408246:	cmp    rsi,rax
  408249:	jne    40824d <__swc_fn_fc36583a_000072_9c99bf04+0x1d>
  40824b:	pop    rsi
  40824c:	ret
  40824d:	mov    rcx,rsi
  408250:	call   409940 <__swc_fn_fc36583a_000138_86bb0f90>
  408255:	mov    rcx,rsi
  408258:	call   40ed80 <__swc_fn_fc36583a_000071_61e60aab>
  40825d:	mov    rcx,rsi
  408260:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  408265:	pop    rsi
  408266:	ret
	...

0000000000408270 <__swc_fn_fc36583a_000075_15bd096c>:
  408270:	sub    rsp,0x8
  408274:	call   40ead0 <__swc_fn_fc36583a_000068_7130736e>
  408279:	add    rsp,0x8
  40827d:	ret
	...

0000000000408280 <__swc_fn_fc36583a_000078_a5fd3362>:
  408280:	push   rsi
  408281:	mov    rsi,rdx
  408284:	call   40ed80 <__swc_fn_fc36583a_000071_61e60aab>
  408289:	mov    QWORD PTR [rsi+0x40],0x0
  408291:	pop    rsi
  408292:	ret
	...

00000000004082a0 <__swc_fn_fc36583a_000081_63a67586>:
  4082a0:	mov    r8,rcx
  4082a3:	mov    rcx,QWORD PTR [rcx]
  4082a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4082b0:	mov    r9,rcx
  4082b3:	sub    r9,rdx
  4082b6:	mov    rax,rcx
  4082b9:	lock cmpxchg QWORD PTR [r8],r9
  4082be:	cmp    rax,rcx
  4082c1:	je     4082c8 <__swc_fn_fc36583a_000081_63a67586+0x28>
  4082c3:	mov    rcx,rax
  4082c6:	jmp    4082b0 <__swc_fn_fc36583a_000081_63a67586+0x10>
  4082c8:	mov    rax,rcx
  4082cb:	ret
  4082cc:	add    BYTE PTR [rax],al
	...

00000000004082d0 <__swc_fn_fc36583a_000084_c618ff58>:
  4082d0:	vxorps xmm0,xmm0,xmm0
  4082d4:	vmovups XMMWORD PTR [rcx],xmm0
  4082d8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4082dd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4082e2:	ret
	...

00000000004082f0 <__swc_fn_fc36583a_000087_0d280354>:
  4082f0:	push   rsi
  4082f1:	push   rdi
  4082f2:	push   r12
  4082f4:	push   r13
  4082f6:	push   r15
  4082f8:	push   r14
  4082fa:	push   rbx
  4082fb:	sub    rsp,0x60
  4082ff:	mov    QWORD PTR [rsp+0x28],r11
  408304:	mov    rsi,rcx
  408307:	mov    rdi,rdx
  40830a:	mov    QWORD PTR [rsp+0x30],rdx
  40830f:	mov    r12,r8
  408312:	mov    r13,r9
  408315:	mov    QWORD PTR [rsp+0x38],r10
  40831a:	xor    r8d,r8d
  40831d:	call   408640 <__swc_fn_fc36583a_000093_63c1827b>
  408322:	test   al,al
  408324:	je     408339 <__swc_fn_fc36583a_000087_0d280354+0x49>
  408326:	mov    rax,r12
  408329:	add    rsp,0x60
  40832d:	pop    rbx
  40832e:	pop    r14
  408330:	pop    r15
  408332:	pop    r13
  408334:	pop    r12
  408336:	pop    rdi
  408337:	pop    rsi
  408338:	ret
  408339:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40833e:	je     408352 <__swc_fn_fc36583a_000087_0d280354+0x62>
  408340:	xor    eax,eax
  408342:	add    rsp,0x60
  408346:	pop    rbx
  408347:	pop    r14
  408349:	pop    r15
  40834b:	pop    r13
  40834d:	pop    r12
  40834f:	pop    rdi
  408350:	pop    rsi
  408351:	ret
  408352:	mov    r15,rdi
  408355:	mov    QWORD PTR [rsp+0x40],rdi
  40835a:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40835f:	jne    4083cf <__swc_fn_fc36583a_000087_0d280354+0xdf>
  408361:	mov    r14,QWORD PTR [r15+0xb8]
  408368:	mov    rax,QWORD PTR [r15+0xc0]
  40836f:	mov    r15,rax
  408372:	xor    edi,edi
  408374:	test   r15,r15
  408377:	je     4083cf <__swc_fn_fc36583a_000087_0d280354+0xdf>
  408379:	nop    DWORD PTR [rax+0x0]
  408380:	lea    rbx,[rdi*8+0x0]
  408388:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  40838d:	mov    rcx,rax
  408390:	mov    rdx,rsi
  408393:	xor    r8d,r8d
  408396:	call   408640 <__swc_fn_fc36583a_000093_63c1827b>
  40839b:	test   al,al
  40839d:	je     4083c5 <__swc_fn_fc36583a_000087_0d280354+0xd5>
  40839f:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  4083a4:	test   rax,rax
  4083a7:	je     4083c5 <__swc_fn_fc36583a_000087_0d280354+0xd5>
  4083a9:	test   r13,r13
  4083ac:	je     4083b2 <__swc_fn_fc36583a_000087_0d280354+0xc2>
  4083ae:	mov    QWORD PTR [r13+0x8],rax
  4083b2:	mov    rax,r12
  4083b5:	add    rsp,0x60
  4083b9:	pop    rbx
  4083ba:	pop    r14
  4083bc:	pop    r15
  4083be:	pop    r13
  4083c0:	pop    r12
  4083c2:	pop    rdi
  4083c3:	pop    rsi
  4083c4:	ret
  4083c5:	add    rdi,0x1
  4083c9:	sub    r15,0x1
  4083cd:	jne    408380 <__swc_fn_fc36583a_000087_0d280354+0x90>
  4083cf:	test   r12,r12
  4083d2:	jne    4083e6 <__swc_fn_fc36583a_000087_0d280354+0xf6>
  4083d4:	xor    eax,eax
  4083d6:	add    rsp,0x60
  4083da:	pop    rbx
  4083db:	pop    r14
  4083dd:	pop    r15
  4083df:	pop    r13
  4083e1:	pop    r12
  4083e3:	pop    rdi
  4083e4:	pop    rsi
  4083e5:	ret
  4083e6:	mov    rbx,QWORD PTR [rsp+0x28]
  4083eb:	mov    rdi,QWORD PTR [rsp+0x30]
  4083f0:	mov    rax,rbx
  4083f3:	test   rax,rax
  4083f6:	je     408426 <__swc_fn_fc36583a_000087_0d280354+0x136>
  4083f8:	nop    DWORD PTR [rax+rax*1+0x0]
  408400:	cmp    QWORD PTR [rax+0x8],r12
  408404:	jne    40841d <__swc_fn_fc36583a_000087_0d280354+0x12d>
  408406:	cmp    QWORD PTR [rax],rdi
  408409:	jne    40841d <__swc_fn_fc36583a_000087_0d280354+0x12d>
  40840b:	xor    eax,eax
  40840d:	add    rsp,0x60
  408411:	pop    rbx
  408412:	pop    r14
  408414:	pop    r15
  408416:	pop    r13
  408418:	pop    r12
  40841a:	pop    rdi
  40841b:	pop    rsi
  40841c:	ret
  40841d:	mov    rax,QWORD PTR [rax+0x10]
  408421:	test   rax,rax
  408424:	jne    408400 <__swc_fn_fc36583a_000087_0d280354+0x110>
  408426:	lea    r14,[rsp+0x8]
  40842b:	mov    QWORD PTR [rsp+0x48],r14
  408430:	mov    QWORD PTR [rsp+0x8],rdi
  408435:	mov    QWORD PTR [rsp+0x10],r12
  40843a:	mov    QWORD PTR [rsp+0x18],rbx
  40843f:	mov    r15,QWORD PTR [rsp+0x40]
  408444:	mov    rbx,QWORD PTR [r15+0x98]
  40844b:	mov    rax,QWORD PTR [r15+0xa0]
  408452:	mov    rdi,rax
  408455:	mov    r15,QWORD PTR [rsp+0x38]
  40845a:	xor    r14d,r14d
  40845d:	test   rdi,rdi
  408460:	je     40850a <__swc_fn_fc36583a_000087_0d280354+0x21a>
  408466:	cs nop WORD PTR [rax+rax*1+0x0]
  408470:	mov    QWORD PTR [rsp+0x50],rdi
  408475:	lea    rdi,[r14*8+0x0]
  40847d:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  408482:	mov    rcx,rax
  408485:	call   40c0c0 <__swc_fn_fc36583a_000085_3953ef98>
  40848a:	test   DWORD PTR [rax+0x28],0x10000
  408491:	je     408498 <__swc_fn_fc36583a_000087_0d280354+0x1a8>
  408493:	test   r15b,r15b
  408496:	je     4084f1 <__swc_fn_fc36583a_000087_0d280354+0x201>
  408498:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  40849c:	lea    rdi,[r12+rcx*1]
  4084a0:	cmp    BYTE PTR [rax+0x2c],0x6
  4084a4:	jne    4084b8 <__swc_fn_fc36583a_000087_0d280354+0x1c8>
  4084a6:	mov    rax,QWORD PTR [rax+0x40]
  4084aa:	mov    rcx,rax
  4084ad:	call   40c0c0 <__swc_fn_fc36583a_000085_3953ef98>
  4084b2:	mov    rcx,QWORD PTR [rdi]
  4084b5:	mov    rdi,rcx
  4084b8:	test   rdi,rdi
  4084bb:	je     4084f1 <__swc_fn_fc36583a_000087_0d280354+0x201>
  4084bd:	mov    rcx,rsi
  4084c0:	mov    rdx,rax
  4084c3:	mov    r8,rdi
  4084c6:	mov    r9,r13
  4084c9:	mov    al,r15b
  4084cc:	mov    r10,rax
  4084cf:	mov    rdi,QWORD PTR [rsp+0x48]
  4084d4:	mov    r11,rdi
  4084d7:	call   4082f0 <__swc_fn_fc36583a_000087_0d280354>
  4084dc:	test   rax,rax
  4084df:	je     4084f1 <__swc_fn_fc36583a_000087_0d280354+0x201>
  4084e1:	add    rsp,0x60
  4084e5:	pop    rbx
  4084e6:	pop    r14
  4084e8:	pop    r15
  4084ea:	pop    r13
  4084ec:	pop    r12
  4084ee:	pop    rdi
  4084ef:	pop    rsi
  4084f0:	ret
  4084f1:	add    r14,0x1
  4084f5:	mov    rax,QWORD PTR [rsp+0x50]
  4084fa:	sub    rax,0x1
  4084fe:	mov    rdi,rax
  408501:	test   rax,rax
  408504:	jne    408470 <__swc_fn_fc36583a_000087_0d280354+0x180>
  40850a:	xor    eax,eax
  40850c:	add    rsp,0x60
  408510:	pop    rbx
  408511:	pop    r14
  408513:	pop    r15
  408515:	pop    r13
  408517:	pop    r12
  408519:	pop    rdi
  40851a:	pop    rsi
  40851b:	ret
  40851c:	add    BYTE PTR [rax],al
	...

0000000000408520 <__swc_fn_fc36583a_000090_c1c9085b>:
  408520:	push   rsi
  408521:	push   rdi
  408522:	push   r12
  408524:	push   r13
  408526:	push   r14
  408528:	push   r15
  40852a:	sub    rsp,0x78
  40852e:	mov    rsi,r10
  408531:	mov    QWORD PTR [rsp+0x68],r10
  408536:	mov    rdi,rcx
  408539:	mov    r12,rdx
  40853c:	mov    r13,r8
  40853f:	mov    r14,r9
  408542:	xor    r8d,r8d
  408545:	call   408640 <__swc_fn_fc36583a_000093_63c1827b>
  40854a:	test   al,al
  40854c:	je     408575 <__swc_fn_fc36583a_000090_c1c9085b+0x55>
  40854e:	mov    rcx,r14
  408551:	mov    rdx,r12
  408554:	mov    r8,r13
  408557:	mov    r9,rsi
  40855a:	call   40f1e0 <__swc_fn_fc36583a_000089_23214800>
  40855f:	test   al,al
  408561:	je     408575 <__swc_fn_fc36583a_000090_c1c9085b+0x55>
  408563:	mov    rax,r13
  408566:	add    rsp,0x78
  40856a:	pop    r15
  40856c:	pop    r14
  40856e:	pop    r13
  408570:	pop    r12
  408572:	pop    rdi
  408573:	pop    rsi
  408574:	ret
  408575:	cmp    BYTE PTR [r12+0x2c],0xe
  40857b:	je     40858e <__swc_fn_fc36583a_000090_c1c9085b+0x6e>
  40857d:	xor    eax,eax
  40857f:	add    rsp,0x78
  408583:	pop    r15
  408585:	pop    r14
  408587:	pop    r13
  408589:	pop    r12
  40858b:	pop    rdi
  40858c:	pop    rsi
  40858d:	ret
  40858e:	mov    r15,QWORD PTR [r12+0x98]
  408596:	mov    rax,QWORD PTR [r12+0xa0]
  40859e:	mov    r12,rax
  4085a1:	xor    esi,esi
  4085a3:	test   r12,r12
  4085a6:	je     408619 <__swc_fn_fc36583a_000090_c1c9085b+0xf9>
  4085a8:	nop    DWORD PTR [rax+rax*1+0x0]
  4085b0:	mov    QWORD PTR [rsp+0x70],r12
  4085b5:	lea    r12,[rsi*8+0x0]
  4085bd:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  4085c2:	mov    rcx,rax
  4085c5:	call   40c0c0 <__swc_fn_fc36583a_000085_3953ef98>
  4085ca:	cmp    BYTE PTR [rax+0x2c],0xe
  4085ce:	jne    408604 <__swc_fn_fc36583a_000090_c1c9085b+0xe4>
  4085d0:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  4085d5:	lea    r8,[r13+rcx*1+0x0]
  4085da:	mov    rcx,rdi
  4085dd:	mov    rdx,rax
  4085e0:	mov    r9,r14
  4085e3:	mov    r12,QWORD PTR [rsp+0x68]
  4085e8:	mov    r10,r12
  4085eb:	call   408520 <__swc_fn_fc36583a_000090_c1c9085b>
  4085f0:	test   rax,rax
  4085f3:	je     408604 <__swc_fn_fc36583a_000090_c1c9085b+0xe4>
  4085f5:	add    rsp,0x78
  4085f9:	pop    r15
  4085fb:	pop    r14
  4085fd:	pop    r13
  4085ff:	pop    r12
  408601:	pop    rdi
  408602:	pop    rsi
  408603:	ret
  408604:	add    rsi,0x1
  408608:	mov    rax,QWORD PTR [rsp+0x70]
  40860d:	sub    rax,0x1
  408611:	mov    r12,rax
  408614:	test   rax,rax
  408617:	jne    4085b0 <__swc_fn_fc36583a_000090_c1c9085b+0x90>
  408619:	xor    eax,eax
  40861b:	add    rsp,0x78
  40861f:	pop    r15
  408621:	pop    r14
  408623:	pop    r13
  408625:	pop    r12
  408627:	pop    rdi
  408628:	pop    rsi
  408629:	ret
	...

0000000000408640 <__swc_fn_fc36583a_000093_63c1827b>:
  408640:	push   rbx
  408641:	push   rsi
  408642:	push   rdi
  408643:	push   r12
  408645:	push   r13
  408647:	push   r14
  408649:	push   r15
  40864b:	sub    rsp,0x120
  408652:	mov    rbx,r8
  408655:	mov    rsi,rdx
  408658:	test   rcx,rcx
  40865b:	jne    40867a <__swc_fn_fc36583a_000093_63c1827b+0x3a>
  40865d:	test   rsi,rsi
  408660:	jne    40867a <__swc_fn_fc36583a_000093_63c1827b+0x3a>
  408662:	mov    eax,0x1
  408667:	add    rsp,0x120
  40866e:	pop    r15
  408670:	pop    r14
  408672:	pop    r13
  408674:	pop    r12
  408676:	pop    rdi
  408677:	pop    rsi
  408678:	pop    rbx
  408679:	ret
  40867a:	test   rcx,rcx
  40867d:	je     408684 <__swc_fn_fc36583a_000093_63c1827b+0x44>
  40867f:	test   rsi,rsi
  408682:	jne    408699 <__swc_fn_fc36583a_000093_63c1827b+0x59>
  408684:	xor    eax,eax
  408686:	add    rsp,0x120
  40868d:	pop    r15
  40868f:	pop    r14
  408691:	pop    r13
  408693:	pop    r12
  408695:	pop    rdi
  408696:	pop    rsi
  408697:	pop    rbx
  408698:	ret
  408699:	call   40c0c0 <__swc_fn_fc36583a_000085_3953ef98>
  40869e:	mov    rdi,rax
  4086a1:	mov    rcx,rsi
  4086a4:	call   40c0c0 <__swc_fn_fc36583a_000085_3953ef98>
  4086a9:	test   bl,0x1
  4086ac:	je     4086ea <__swc_fn_fc36583a_000093_63c1827b+0xaa>
  4086ae:	rex cmp BYTE PTR [rdi+0x2c],0x6
  4086b3:	jne    4086ea <__swc_fn_fc36583a_000093_63c1827b+0xaa>
  4086b5:	mov    ecx,DWORD PTR [rdi+0x28]
  4086b8:	test   ecx,0x1000
  4086be:	je     4086ea <__swc_fn_fc36583a_000093_63c1827b+0xaa>
  4086c0:	test   ecx,0x10000
  4086c6:	je     4086ea <__swc_fn_fc36583a_000093_63c1827b+0xaa>
  4086c8:	mov    rcx,QWORD PTR [rdi+0x40]
  4086cc:	mov    rdx,rax
  4086cf:	mov    r8d,ebx
  4086d2:	call   408640 <__swc_fn_fc36583a_000093_63c1827b>
  4086d7:	add    rsp,0x120
  4086de:	pop    r15
  4086e0:	pop    r14
  4086e2:	pop    r13
  4086e4:	pop    r12
  4086e6:	pop    rdi
  4086e7:	pop    rsi
  4086e8:	pop    rbx
  4086e9:	ret
  4086ea:	mov    cl,BYTE PTR [rax+0x2c]
  4086ed:	rex cmp BYTE PTR [rdi+0x2c],cl
  4086f1:	jne    4086fb <__swc_fn_fc36583a_000093_63c1827b+0xbb>
  4086f3:	mov    ecx,DWORD PTR [rax+0x20]
  4086f6:	cmp    DWORD PTR [rdi+0x20],ecx
  4086f9:	je     408710 <__swc_fn_fc36583a_000093_63c1827b+0xd0>
  4086fb:	xor    eax,eax
  4086fd:	add    rsp,0x120
  408704:	pop    r15
  408706:	pop    r14
  408708:	pop    r13
  40870a:	pop    r12
  40870c:	pop    rdi
  40870d:	pop    rsi
  40870e:	pop    rbx
  40870f:	ret
  408710:	mov    ecx,DWORD PTR [rdi+0x28]
  408713:	and    ecx,0xffb5ffff
  408719:	mov    edx,DWORD PTR [rax+0x28]
  40871c:	and    edx,0xffb5ffff
  408722:	cmp    ecx,edx
  408724:	je     40873b <__swc_fn_fc36583a_000093_63c1827b+0xfb>
  408726:	xor    eax,eax
  408728:	add    rsp,0x120
  40872f:	pop    r15
  408731:	pop    r14
  408733:	pop    r13
  408735:	pop    r12
  408737:	pop    rdi
  408738:	pop    rsi
  408739:	pop    rbx
  40873a:	ret
  40873b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  408740:	jne    408795 <__swc_fn_fc36583a_000093_63c1827b+0x155>
  408742:	mov    cl,BYTE PTR [rax+0x40]
  408745:	rex cmp BYTE PTR [rdi+0x40],cl
  408749:	je     408760 <__swc_fn_fc36583a_000093_63c1827b+0x120>
  40874b:	xor    eax,eax
  40874d:	add    rsp,0x120
  408754:	pop    r15
  408756:	pop    r14
  408758:	pop    r13
  40875a:	pop    r12
  40875c:	pop    rdi
  40875d:	pop    rsi
  40875e:	pop    rbx
  40875f:	ret
  408760:	rex cmp BYTE PTR [rdi+0x40],0xd
  408765:	je     40877d <__swc_fn_fc36583a_000093_63c1827b+0x13d>
  408767:	rex cmp BYTE PTR [rdi+0x40],0xf
  40876c:	sete   cl
  40876f:	je     408779 <__swc_fn_fc36583a_000093_63c1827b+0x139>
  408771:	rex cmp BYTE PTR [rdi+0x40],0xe
  408776:	sete   cl
  408779:	test   cl,cl
  40877b:	je     408795 <__swc_fn_fc36583a_000093_63c1827b+0x155>
  40877d:	mov    eax,0x1
  408782:	add    rsp,0x120
  408789:	pop    r15
  40878b:	pop    r14
  40878d:	pop    r13
  40878f:	pop    r12
  408791:	pop    rdi
  408792:	pop    rsi
  408793:	pop    rbx
  408794:	ret
  408795:	test   DWORD PTR [rdi+0x28],0x200200
  40879c:	je     40894f <__swc_fn_fc36583a_000093_63c1827b+0x30f>
  4087a2:	mov    rsi,QWORD PTR [rdi+0x88]
  4087a9:	mov    rdi,QWORD PTR [rdi+0x90]
  4087b0:	mov    r12,QWORD PTR [rax+0x88]
  4087b7:	mov    rax,QWORD PTR [rax+0x90]
  4087be:	cmp    rdi,rax
  4087c1:	je     4087d8 <__swc_fn_fc36583a_000093_63c1827b+0x198>
  4087c3:	xor    eax,eax
  4087c5:	add    rsp,0x120
  4087cc:	pop    r15
  4087ce:	pop    r14
  4087d0:	pop    r13
  4087d2:	pop    r12
  4087d4:	pop    rdi
  4087d5:	pop    rsi
  4087d6:	pop    rbx
  4087d7:	ret
  4087d8:	test   rsi,rsi
  4087db:	je     4087e2 <__swc_fn_fc36583a_000093_63c1827b+0x1a2>
  4087dd:	test   r12,r12
  4087e0:	jne    4087fa <__swc_fn_fc36583a_000093_63c1827b+0x1ba>
  4087e2:	mov    eax,0x1
  4087e7:	add    rsp,0x120
  4087ee:	pop    r15
  4087f0:	pop    r14
  4087f2:	pop    r13
  4087f4:	pop    r12
  4087f6:	pop    rdi
  4087f7:	pop    rsi
  4087f8:	pop    rbx
  4087f9:	ret
  4087fa:	xor    r13d,r13d
  4087fd:	test   rdi,rdi
  408800:	jbe    408937 <__swc_fn_fc36583a_000093_63c1827b+0x2f7>
  408806:	lea    r14,[rsp+0x78]
  40880b:	lea    r15,[rsp+0xb8]
  408813:	cs nop WORD PTR [rax+rax*1+0x0]
  40881d:	cs nop WORD PTR [rax+rax*1+0x0]
  408827:	nop    WORD PTR [rax+rax*1+0x0]
  408830:	lea    rax,[r13*8+0x0]
  408838:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40883d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  408843:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  408849:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  408852:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  408858:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  408861:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  408867:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  408870:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  408876:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40887f:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  408886:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  40888f:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  408896:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  40889f:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  4088a6:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  4088af:	xor    al,al
  4088b1:	rex test BYTE PTR [rsp+0xb0],0x1
  4088ba:	je     4088c1 <__swc_fn_fc36583a_000093_63c1827b+0x281>
  4088bc:	mov    eax,0x1
  4088c1:	rex test BYTE PTR [rsp+0xf0],0x1
  4088ca:	je     4088d1 <__swc_fn_fc36583a_000093_63c1827b+0x291>
  4088cc:	mov    eax,0x1
  4088d1:	test   al,al
  4088d3:	jne    4088f9 <__swc_fn_fc36583a_000093_63c1827b+0x2b9>
  4088d5:	mov    rcx,r14
  4088d8:	mov    rdx,r15
  4088db:	call   409e50 <__swc_fn_fc36583a_000150_6fb05988>
  4088e0:	test   al,al
  4088e2:	jne    4088f9 <__swc_fn_fc36583a_000093_63c1827b+0x2b9>
  4088e4:	xor    eax,eax
  4088e6:	add    rsp,0x120
  4088ed:	pop    r15
  4088ef:	pop    r14
  4088f1:	pop    r13
  4088f3:	pop    r12
  4088f5:	pop    rdi
  4088f6:	pop    rsi
  4088f7:	pop    rbx
  4088f8:	ret
  4088f9:	mov    rcx,QWORD PTR [rsp+0x88]
  408901:	mov    rdx,QWORD PTR [rsp+0xc8]
  408909:	mov    r8d,ebx
  40890c:	call   408640 <__swc_fn_fc36583a_000093_63c1827b>
  408911:	test   al,al
  408913:	jne    40892a <__swc_fn_fc36583a_000093_63c1827b+0x2ea>
  408915:	xor    eax,eax
  408917:	add    rsp,0x120
  40891e:	pop    r15
  408920:	pop    r14
  408922:	pop    r13
  408924:	pop    r12
  408926:	pop    rdi
  408927:	pop    rsi
  408928:	pop    rbx
  408929:	ret
  40892a:	add    r13,0x1
  40892e:	cmp    r13,rdi
  408931:	jb     408830 <__swc_fn_fc36583a_000093_63c1827b+0x1f0>
  408937:	mov    eax,0x1
  40893c:	add    rsp,0x120
  408943:	pop    r15
  408945:	pop    r14
  408947:	pop    r13
  408949:	pop    r12
  40894b:	pop    rdi
  40894c:	pop    rsi
  40894d:	pop    rbx
  40894e:	ret
  40894f:	test   bl,0x2
  408952:	je     408974 <__swc_fn_fc36583a_000093_63c1827b+0x334>
  408954:	lea    rcx,[rdi+0x10]
  408958:	lea    rdx,[rax+0x10]
  40895c:	call   409e50 <__swc_fn_fc36583a_000150_6fb05988>
  408961:	add    rsp,0x120
  408968:	pop    r15
  40896a:	pop    r14
  40896c:	pop    r13
  40896e:	pop    r12
  408970:	pop    rdi
  408971:	pop    rsi
  408972:	pop    rbx
  408973:	ret
  408974:	mov    rcx,rdi
  408977:	mov    rdx,rax
  40897a:	call   409e50 <__swc_fn_fc36583a_000150_6fb05988>
  40897f:	add    rsp,0x120
  408986:	pop    r15
  408988:	pop    r14
  40898a:	pop    r13
  40898c:	pop    r12
  40898e:	pop    rdi
  40898f:	pop    rsi
  408990:	pop    rbx
  408991:	ret
	...

00000000004089a0 <__swc_fn_fc36583a_000096_4185993f>:
  4089a0:	push   rbx
  4089a1:	mov    rbx,rcx
  4089a4:	call   40c1f0 <__swc_fn_fc36583a_000094_ad13d15c>
  4089a9:	movzx  r11d,al
  4089ad:	mov    r8b,r11b
  4089b0:	test   r8b,r8b
  4089b3:	jne    4089cd <__swc_fn_fc36583a_000096_4185993f+0x2d>
  4089b5:	mov    r11d,0x1
  4089bb:	mov    r10,rbx
  4089be:	mov    r9,r11
  4089c1:	and    r10,r11
  4089c4:	test   r10,r10
  4089c7:	setne  dl
  4089ca:	mov    r8b,dl
  4089cd:	mov    r10b,r8b
  4089d0:	test   r10b,r10b
  4089d3:	je     4089d7 <__swc_fn_fc36583a_000096_4185993f+0x37>
  4089d5:	pop    rbx
  4089d6:	ret
  4089d7:	call   4106e0 <__swc_fn_fc36583a_000140_519fdf94>
  4089dc:	movzx  r10d,al
  4089e0:	test   r10b,r10b
  4089e3:	je     4089e7 <__swc_fn_fc36583a_000096_4185993f+0x47>
  4089e5:	pop    rbx
  4089e6:	ret
  4089e7:	lea    r10,[rip+0xa8fa]        # 4132e8 <__swc_rdata_base_fc36583a+0x1d8>
  4089ee:	mov    rax,r10
  4089f1:	mov    rcx,rax
  4089f4:	call   410210 <__swc_fn_fc36583a_000119_2648f149>
  4089f9:	call   40ca70 <__swc_fn_fc36583a_000121_be2e2f68>
  4089fe:	pop    rbx
  4089ff:	ret

0000000000408a00 <__swc_fn_fc36583a_000099_d4bdcaa4>:
  408a00:	push   rbx
  408a01:	sub    rsp,0x70
  408a05:	vxorps xmm0,xmm0,xmm0
  408a09:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  408a0f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  408a15:	vzeroupper
  408a18:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  408a1e:	mov    QWORD PTR [rsp+0x48],rdx
  408a23:	mov    rax,r8
  408a26:	cmp    r8,0x1
  408a2a:	mov    edx,0x1
  408a2f:	cmovb  rax,rdx
  408a33:	mov    QWORD PTR [rsp+0x50],rax
  408a38:	mov    rbx,QWORD PTR [rcx+0x8]
  408a3c:	mov    rbx,QWORD PTR [rbx+0x18]
  408a40:	mov    rcx,QWORD PTR [rcx]
  408a43:	lea    rdx,[rsp+0x8]
  408a48:	call   rbx
  408a4a:	add    rsp,0x70
  408a4e:	pop    rbx
  408a4f:	ret

0000000000408a50 <__swc_fn_fc36583a_000102_2fdd2c61>:
  408a50:	push   rbx
  408a51:	push   rsi
  408a52:	push   rdi
  408a53:	sub    rsp,0x30
  408a57:	mov    rbx,rcx
  408a5a:	test   rcx,rcx
  408a5d:	je     408a72 <__swc_fn_fc36583a_000102_2fdd2c61+0x22>
  408a5f:	mov    rcx,rbx
  408a62:	mov    edx,0x1
  408a67:	call   4082a0 <__swc_fn_fc36583a_000081_63a67586>
  408a6c:	cmp    rax,0x1
  408a70:	je     408a7a <__swc_fn_fc36583a_000102_2fdd2c61+0x2a>
  408a72:	add    rsp,0x30
  408a76:	pop    rdi
  408a77:	pop    rsi
  408a78:	pop    rbx
  408a79:	ret
  408a7a:	lea    rsi,[rsp+0x8]
  408a7f:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  408a84:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  408a8a:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  408a8f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408a95:	mov    rax,QWORD PTR [rsp+0x20]
  408a9a:	test   rax,rax
  408a9d:	je     408ab3 <__swc_fn_fc36583a_000102_2fdd2c61+0x63>
  408a9f:	test   DWORD PTR [rax+0x28],0x400000
  408aa6:	je     408ab3 <__swc_fn_fc36583a_000102_2fdd2c61+0x63>
  408aa8:	mov    rcx,QWORD PTR [rax+0x30]
  408aac:	test   rcx,rcx
  408aaf:	cmovne rax,rcx
  408ab3:	mov    edi,DWORD PTR [rax+0x20]
  408ab6:	lea    rcx,[rsp+0x18]
  408abb:	call   40c3d0 <__swc_fn_fc36583a_000103_3c3b96fb>
  408ac0:	mov    rcx,rsi
  408ac3:	mov    rdx,QWORD PTR [rsp+0x18]
  408ac8:	mov    r8,rdi
  408acb:	call   408a00 <__swc_fn_fc36583a_000099_d4bdcaa4>
  408ad0:	mov    rcx,QWORD PTR [rbx+0x28]
  408ad4:	call   40f7c0 <__swc_fn_fc36583a_000101_e34f54dc>
  408ad9:	mov    rcx,rsi
  408adc:	mov    rdx,rbx
  408adf:	mov    r8d,0x30
  408ae5:	call   408a00 <__swc_fn_fc36583a_000099_d4bdcaa4>
  408aea:	add    rsp,0x30
  408aee:	pop    rdi
  408aef:	pop    rsi
  408af0:	pop    rbx
  408af1:	ret
	...

0000000000408b00 <__swc_fn_fc36583a_000105_ffe51047>:
  408b00:	push   rbp
  408b01:	push   rbx
  408b02:	push   rsi
  408b03:	push   rdi
  408b04:	push   r12
  408b06:	push   r13
  408b08:	push   r14
  408b0a:	push   r15
  408b0c:	sub    rsp,0x500
  408b13:	mov    rbp,rsp
  408b16:	mov    rbx,rsp
  408b19:	mov    rsi,rdx
  408b1c:	mov    rdi,rcx
  408b1f:	mov    rcx,QWORD PTR [rip+0x1b51a]        # 424040 <__swc_bss_base_fc36583a>
  408b26:	test   rcx,rcx
  408b29:	jne    408b43 <__swc_fn_fc36583a_000105_ffe51047+0x43>
  408b2b:	sub    rsp,0x8
  408b2f:	call   40a240 <__swc_fn_fc36583a_000168_994c8876>
  408b34:	add    rsp,0x8
  408b38:	lea    rcx,[rax+0x1]
  408b3c:	mov    QWORD PTR [rip+0x1b4fd],rcx        # 424040 <__swc_bss_base_fc36583a>
  408b43:	dec    rcx
  408b46:	sub    rsp,0x8
  408b4a:	call   411fc0 <__swc_fn_fc36583a_000170_360af05d>
  408b4f:	add    rsp,0x8
  408b53:	mov    r12,rax
  408b56:	mov    QWORD PTR [rsp+0x4f0],rax
  408b5e:	lea    rax,[rip+0xa8c3]        # 413428 <__swc_rdata_base_fc36583a+0x318>
  408b65:	sub    rsp,0x20
  408b69:	mov    rcx,rsp
  408b6c:	mov    QWORD PTR [rcx],rax
  408b6f:	lea    r13,[rip+0xa5ba]        # 413130 <__swc_rdata_base_fc36583a+0x20>
  408b76:	mov    QWORD PTR [rcx+0x8],r13
  408b7a:	mov    QWORD PTR [rcx+0x10],rsp
  408b7e:	mov    QWORD PTR [rcx+0x18],0x1
  408b86:	lea    rcx,[rsp+0x10]
  408b8b:	sub    rsp,0x8
  408b8f:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  408b94:	add    rsp,0x8
  408b98:	add    rsp,0x20
  408b9c:	lea    rax,[rip+0xa895]        # 413438 <__swc_rdata_base_fc36583a+0x328>
  408ba3:	sub    rsp,0x20
  408ba7:	mov    rcx,rsp
  408baa:	mov    QWORD PTR [rcx],rax
  408bad:	mov    QWORD PTR [rcx+0x8],r13
  408bb1:	mov    QWORD PTR [rcx+0x10],rsp
  408bb5:	mov    QWORD PTR [rcx+0x18],0x1
  408bbd:	lea    rcx,[rsp+0x10]
  408bc2:	sub    rsp,0x8
  408bc6:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  408bcb:	add    rsp,0x8
  408bcf:	add    rsp,0x20
  408bd3:	lea    r14,[rip+0xa546]        # 413120 <__swc_rdata_base_fc36583a+0x10>
  408bda:	sub    rsp,0x50
  408bde:	mov    rax,rsp
  408be1:	vmovups xmm0,XMMWORD PTR [rip+0xa987]        # 413570 <__swc_rdata_base_fc36583a+0x460>
  408be9:	vmovups XMMWORD PTR [rax],xmm0
  408bed:	mov    QWORD PTR [rax+0x10],rsp
  408bf1:	mov    QWORD PTR [rax+0x18],r13
  408bf5:	mov    QWORD PTR [rax+0x20],rdi
  408bf9:	lea    rdi,[rip+0xa848]        # 413448 <__swc_rdata_base_fc36583a+0x338>
  408c00:	mov    QWORD PTR [rax+0x28],rdi
  408c04:	mov    QWORD PTR [rax+0x30],r14
  408c08:	mov    QWORD PTR [rax+0x38],r13
  408c0c:	lea    rcx,[rsp+0x10]
  408c11:	mov    QWORD PTR [rax+0x40],rcx
  408c15:	mov    QWORD PTR [rax+0x48],0x3
  408c1d:	lea    rcx,[rsp+0x40]
  408c22:	sub    rsp,0x8
  408c26:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  408c2b:	add    rsp,0x8
  408c2f:	add    rsp,0x50
  408c33:	lea    rax,[rip+0xa856]        # 413490 <__swc_rdata_base_fc36583a+0x380>
  408c3a:	sub    rsp,0x20
  408c3e:	mov    rcx,rsp
  408c41:	mov    QWORD PTR [rcx],rax
  408c44:	mov    QWORD PTR [rcx+0x8],r13
  408c48:	mov    QWORD PTR [rcx+0x10],rsp
  408c4c:	mov    QWORD PTR [rcx+0x18],0x1
  408c54:	lea    rcx,[rsp+0x10]
  408c59:	sub    rsp,0x8
  408c5d:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  408c62:	add    rsp,0x8
  408c66:	add    rsp,0x20
  408c6a:	mov    eax,DWORD PTR [rsi+0x20]
  408c6d:	mov    ecx,DWORD PTR [rsi+0x24]
  408c70:	sub    rsp,0xa0
  408c77:	mov    rdx,rsp
  408c7a:	mov    QWORD PTR [rdx+0x30],rsi
  408c7e:	mov    QWORD PTR [rdx+0x38],rdi
  408c82:	vmovups xmm0,XMMWORD PTR [rip+0xa87e]        # 413508 <__swc_rdata_base_fc36583a+0x3f8>
  408c8a:	vmovups XMMWORD PTR [rdx],xmm0
  408c8e:	mov    QWORD PTR [rdx+0x40],rsp
  408c92:	mov    QWORD PTR [rdx+0x48],r13
  408c96:	mov    DWORD PTR [rdx+0x10],eax
  408c99:	lea    rax,[rsp+0x10]
  408c9e:	mov    QWORD PTR [rdx+0x50],rax
  408ca2:	lea    rax,[rip+0xa7f7]        # 4134a0 <__swc_rdata_base_fc36583a+0x390>
  408ca9:	mov    QWORD PTR [rdx+0x58],rax
  408cad:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408cb2:	lea    r8,[rsp+0x18]
  408cb7:	mov    QWORD PTR [rdx+0x60],r8
  408cbb:	mov    QWORD PTR [rdx+0x68],r13
  408cbf:	mov    DWORD PTR [rdx+0x28],ecx
  408cc2:	lea    rcx,[rdx+0x28]
  408cc6:	mov    QWORD PTR [rdx+0x70],rcx
  408cca:	mov    QWORD PTR [rdx+0x78],rax
  408cce:	mov    QWORD PTR [rdx+0x80],r14
  408cd5:	mov    QWORD PTR [rdx+0x88],r13
  408cdc:	lea    rax,[rdx+0x30]
  408ce0:	mov    QWORD PTR [rdx+0x90],rax
  408ce7:	mov    QWORD PTR [rdx+0x98],0x6
  408cf2:	lea    rcx,[rdx+0x90]
  408cf9:	sub    rsp,0x8
  408cfd:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  408d02:	add    rsp,0x8
  408d06:	add    rsp,0xa0
  408d0d:	sub    rsp,0x20
  408d11:	mov    rax,rsp
  408d14:	mov    QWORD PTR [rax],r14
  408d17:	mov    QWORD PTR [rax+0x8],r13
  408d1b:	mov    QWORD PTR [rax+0x10],rsp
  408d1f:	mov    QWORD PTR [rax+0x18],0x1
  408d27:	lea    rcx,[rsp+0x10]
  408d2c:	sub    rsp,0x8
  408d30:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  408d35:	add    rsp,0x8
  408d39:	add    rsp,0x20
  408d3d:	mov    eax,DWORD PTR [r12+0x9ac]
  408d45:	test   eax,eax
  408d47:	je     408f80 <__swc_fn_fc36583a_000105_ffe51047+0x480>
  408d4d:	lea    rax,[rip+0xa794]        # 4134e8 <__swc_rdata_base_fc36583a+0x3d8>
  408d54:	sub    rsp,0x20
  408d58:	mov    rcx,rsp
  408d5b:	mov    QWORD PTR [rcx],rax
  408d5e:	mov    QWORD PTR [rcx+0x8],r13
  408d62:	mov    QWORD PTR [rcx+0x10],rsp
  408d66:	mov    QWORD PTR [rcx+0x18],0x1
  408d6e:	lea    rcx,[rsp+0x10]
  408d73:	sub    rsp,0x8
  408d77:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  408d7c:	add    rsp,0x8
  408d80:	add    rsp,0x20
  408d84:	mov    eax,DWORD PTR [r12+0x9ac]
  408d8c:	dec    eax
  408d8e:	mov    esi,eax
  408d90:	test   esi,esi
  408d92:	jl     408f50 <__swc_fn_fc36583a_000105_ffe51047+0x450>
  408d98:	jmp    408da4 <__swc_fn_fc36583a_000105_ffe51047+0x2a4>
  408d9a:	nop    WORD PTR [rax+rax*1+0x0]
  408da0:	dec    esi
  408da2:	jmp    408d90 <__swc_fn_fc36583a_000105_ffe51047+0x290>
  408da4:	lea    rax,[rip+0xa74d]        # 4134f8 <__swc_rdata_base_fc36583a+0x3e8>
  408dab:	sub    rsp,0x20
  408daf:	mov    rcx,rsp
  408db2:	mov    QWORD PTR [rcx],rax
  408db5:	mov    QWORD PTR [rcx+0x8],r13
  408db9:	mov    QWORD PTR [rcx+0x10],rsp
  408dbd:	mov    QWORD PTR [rcx+0x18],0x1
  408dc5:	lea    rcx,[rsp+0x10]
  408dca:	sub    rsp,0x8
  408dce:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  408dd3:	add    rsp,0x8
  408dd7:	add    rsp,0x20
  408ddb:	movsxd rax,esi
  408dde:	imul   r15,rax,0x30
  408de2:	add    r15,r12
  408de5:	add    r15,0xf8
  408dec:	sub    rsp,0x20
  408df0:	mov    rax,rsp
  408df3:	mov    QWORD PTR [rax],r15
  408df6:	mov    QWORD PTR [rax+0x8],rdi
  408dfa:	mov    QWORD PTR [rax+0x10],rsp
  408dfe:	mov    QWORD PTR [rax+0x18],0x1
  408e06:	lea    rcx,[rsp+0x10]
  408e0b:	sub    rsp,0x8
  408e0f:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  408e14:	add    rsp,0x8
  408e18:	add    rsp,0x20
  408e1c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408e24:	lea    rsi,[rip+0xa6dd]        # 413508 <__swc_rdata_base_fc36583a+0x3f8>
  408e2b:	sub    rsp,0x20
  408e2f:	mov    rax,rsp
  408e32:	mov    QWORD PTR [rax],rsi
  408e35:	mov    QWORD PTR [rax+0x8],r13
  408e39:	mov    QWORD PTR [rax+0x10],rsp
  408e3d:	mov    QWORD PTR [rax+0x18],0x1
  408e45:	lea    rcx,[rsp+0x10]
  408e4a:	sub    rsp,0x8
  408e4e:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  408e53:	add    rsp,0x8
  408e57:	add    rsp,0x20
  408e5b:	sub    rsp,0x30
  408e5f:	mov    rax,rsp
  408e62:	mov    ecx,DWORD PTR [r15+0x20]
  408e66:	mov    QWORD PTR [rax],rcx
  408e69:	mov    QWORD PTR [rax+0x8],rsp
  408e6d:	lea    rdi,[rip+0xa6a4]        # 413518 <__swc_rdata_base_fc36583a+0x408>
  408e74:	mov    QWORD PTR [rax+0x10],rdi
  408e78:	lea    rcx,[rsp+0x8]
  408e7d:	mov    QWORD PTR [rax+0x18],rcx
  408e81:	mov    QWORD PTR [rax+0x20],0x1
  408e89:	lea    rcx,[rsp+0x18]
  408e8e:	sub    rsp,0x8
  408e92:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  408e97:	add    rsp,0x8
  408e9b:	add    rsp,0x30
  408e9f:	sub    rsp,0x20
  408ea3:	mov    rax,rsp
  408ea6:	mov    QWORD PTR [rax],rsi
  408ea9:	mov    QWORD PTR [rax+0x8],r13
  408ead:	mov    QWORD PTR [rax+0x10],rsp
  408eb1:	mov    QWORD PTR [rax+0x18],0x1
  408eb9:	lea    rcx,[rsp+0x10]
  408ebe:	sub    rsp,0x8
  408ec2:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  408ec7:	add    rsp,0x8
  408ecb:	add    rsp,0x20
  408ecf:	sub    rsp,0x30
  408ed3:	mov    rax,rsp
  408ed6:	mov    ecx,DWORD PTR [r15+0x24]
  408eda:	mov    QWORD PTR [rax],rcx
  408edd:	mov    QWORD PTR [rax+0x8],rsp
  408ee1:	mov    QWORD PTR [rax+0x10],rdi
  408ee5:	lea    rcx,[rsp+0x8]
  408eea:	mov    QWORD PTR [rax+0x18],rcx
  408eee:	mov    QWORD PTR [rax+0x20],0x1
  408ef6:	lea    rcx,[rsp+0x18]
  408efb:	sub    rsp,0x8
  408eff:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  408f04:	add    rsp,0x8
  408f08:	add    rsp,0x30
  408f0c:	sub    rsp,0x20
  408f10:	mov    rax,rsp
  408f13:	mov    QWORD PTR [rax],r14
  408f16:	mov    QWORD PTR [rax+0x8],r13
  408f1a:	mov    QWORD PTR [rax+0x10],rsp
  408f1e:	mov    QWORD PTR [rax+0x18],0x1
  408f26:	lea    rcx,[rsp+0x10]
  408f2b:	sub    rsp,0x8
  408f2f:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  408f34:	add    rsp,0x8
  408f38:	add    rsp,0x20
  408f3c:	lea    rdi,[rip+0xa505]        # 413448 <__swc_rdata_base_fc36583a+0x338>
  408f43:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408f4b:	jmp    408da0 <__swc_fn_fc36583a_000105_ffe51047+0x2a0>
  408f50:	sub    rsp,0x20
  408f54:	mov    rax,rsp
  408f57:	mov    QWORD PTR [rax],r14
  408f5a:	mov    QWORD PTR [rax+0x8],r13
  408f5e:	mov    QWORD PTR [rax+0x10],rsp
  408f62:	mov    QWORD PTR [rax+0x18],0x1
  408f6a:	lea    rcx,[rsp+0x10]
  408f6f:	sub    rsp,0x8
  408f73:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  408f78:	add    rsp,0x8
  408f7c:	add    rsp,0x20
  408f80:	lea    rax,[rbx+0x28]
  408f84:	mov    rcx,rax
  408f87:	mov    QWORD PTR [rbx+0x28],0x0
  408f8f:	mov    QWORD PTR [rbx+0x30],0x0
  408f97:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408f9c:	add    rcx,0x10
  408fa0:	mov    edx,0x1f
  408fa5:	cs nop WORD PTR [rax+rax*1+0x0]
  408faf:	nop
  408fb0:	vmovups XMMWORD PTR [rcx],xmm0
  408fb4:	add    rcx,0x10
  408fb8:	sub    rdx,0x1
  408fbc:	jne    408fb0 <__swc_fn_fc36583a_000105_ffe51047+0x4b0>
  408fbe:	lea    rsi,[rbx+0x228]
  408fc5:	xor    ecx,ecx
  408fc7:	cs nop WORD PTR [rax+rax*1+0x0]
  408fd1:	cs nop WORD PTR [rax+rax*1+0x0]
  408fdb:	nop    DWORD PTR [rax+rax*1+0x0]
  408fe0:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408fe5:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408fea:	add    rcx,0x10
  408fee:	cmp    rcx,0x200
  408ff5:	jne    408fe0 <__swc_fn_fc36583a_000105_ffe51047+0x4e0>
  408ff7:	mov    eax,DWORD PTR [r12+0xbc8]
  408fff:	lea    rcx,[r12+0x9c8]
  409007:	mov    QWORD PTR [rbx+0x428],rcx
  40900e:	mov    QWORD PTR [rbx+0x430],rax
  409015:	lea    rdi,[rbx+0x438]
  40901c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  409024:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  40902c:	mov    eax,DWORD PTR [r12+0xbc8]
  409034:	test   eax,eax
  409036:	jne    409083 <__swc_fn_fc36583a_000105_ffe51047+0x583>
  409038:	lea    rax,[rbx+0x448]
  40903f:	mov    QWORD PTR [rbx+0x448],rsi
  409046:	mov    QWORD PTR [rax+0x8],0x40
  40904e:	mov    ecx,0x1
  409053:	mov    rdx,rax
  409056:	sub    rsp,0x8
  40905a:	call   410320 <__swc_fn_fc36583a_000122_4f256d58>
  40905f:	add    rsp,0x8
  409063:	mov    QWORD PTR [rbx+0x460],rsi
  40906a:	mov    ecx,eax
  40906c:	mov    QWORD PTR [rbx+0x468],rcx
  409073:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  40907b:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  409083:	mov    rsi,QWORD PTR [rbx+0x438]
  40908a:	mov    rax,QWORD PTR [rbx+0x440]
  409091:	mov    r15,rax
  409094:	xor    r12d,r12d
  409097:	test   r15,r15
  40909a:	je     409150 <__swc_fn_fc36583a_000105_ffe51047+0x650>
  4090a0:	mov    rax,QWORD PTR [rsi+r12*8]
  4090a4:	test   rax,rax
  4090a7:	je     4090c6 <__swc_fn_fc36583a_000105_ffe51047+0x5c6>
  4090a9:	lea    rcx,[rbx+0x4b8]
  4090b0:	mov    rdx,rax
  4090b3:	sub    rsp,0x8
  4090b7:	call   409fb0 <__swc_fn_fc36583a_000165_cc119975>
  4090bc:	add    rsp,0x8
  4090c0:	mov    al,BYTE PTR [rax]
  4090c2:	test   al,al
  4090c4:	jne    4090d2 <__swc_fn_fc36583a_000105_ffe51047+0x5d2>
  4090c6:	add    r12,0x1
  4090ca:	sub    r15,0x1
  4090ce:	jne    4090a0 <__swc_fn_fc36583a_000105_ffe51047+0x5a0>
  4090d0:	jmp    409150 <__swc_fn_fc36583a_000105_ffe51047+0x650>
  4090d2:	lea    rax,[rip+0xa487]        # 413560 <__swc_rdata_base_fc36583a+0x450>
  4090d9:	sub    rsp,0x20
  4090dd:	mov    rcx,rsp
  4090e0:	mov    QWORD PTR [rcx],rax
  4090e3:	mov    QWORD PTR [rcx+0x8],r13
  4090e7:	mov    QWORD PTR [rcx+0x10],rsp
  4090eb:	mov    QWORD PTR [rcx+0x18],0x1
  4090f3:	lea    rcx,[rsp+0x10]
  4090f8:	sub    rsp,0x8
  4090fc:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  409101:	add    rsp,0x8
  409105:	add    rsp,0x20
  409109:	mov    rcx,rdi
  40910c:	xor    edx,edx
  40910e:	mov    al,0x1
  409110:	mov    r8,rax
  409113:	sub    rsp,0x8
  409117:	call   40d300 <__swc_fn_fc36583a_000166_bcc835b8>
  40911c:	add    rsp,0x8
  409120:	sub    rsp,0x20
  409124:	mov    rax,rsp
  409127:	mov    QWORD PTR [rax],r14
  40912a:	mov    QWORD PTR [rax+0x8],r13
  40912e:	mov    QWORD PTR [rax+0x10],rsp
  409132:	mov    QWORD PTR [rax+0x18],0x1
  40913a:	lea    rcx,[rsp+0x10]
  40913f:	sub    rsp,0x8
  409143:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  409148:	add    rsp,0x8
  40914c:	add    rsp,0x20
  409150:	mov    r12,QWORD PTR [rsp+0x4f0]
  409158:	mov    DWORD PTR [r12+0xbc8],0x0
  409164:	add    rsp,0x500
  40916b:	pop    r15
  40916d:	pop    r14
  40916f:	pop    r13
  409171:	pop    r12
  409173:	pop    rdi
  409174:	pop    rsi
  409175:	pop    rbx
  409176:	pop    rbp
  409177:	ret
	...

0000000000409180 <__swc_fn_fc36583a_000108_7c204aac>:
  409180:	sub    rsp,0x8
  409184:	test   r8,r8
  409187:	je     40918e <__swc_fn_fc36583a_000108_7c204aac+0xe>
  409189:	call   40fa50 <__swc_fn_fc36583a_000107_c51c3158>
  40918e:	add    rsp,0x8
  409192:	ret
	...

00000000004091a0 <__swc_fn_fc36583a_000111_126150d1>:
  4091a0:	push   rsi
  4091a1:	push   rdi
  4091a2:	push   r12
  4091a4:	push   r13
  4091a6:	sub    rsp,0xd8
  4091ad:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  4091b3:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  4091b9:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  4091bf:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  4091c5:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  4091cb:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  4091d4:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  4091dd:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  4091e6:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  4091ef:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  4091f8:	xor    eax,eax
  4091fa:	call   407010 <getpid@plt>
  4091ff:	mov    rsi,rax
  409202:	lea    rdi,[rip+0x1db37]        # 426d40 <__swc_bss_base_fc36583a+0x2d00>
  409209:	mov    r12,QWORD PTR [rdi]
  40920c:	test   r12,r12
  40920f:	je     40921d <__swc_fn_fc36583a_000111_126150d1+0x7d>
  409211:	cmp    DWORD PTR [r12+0x10],esi
  409216:	jne    40921d <__swc_fn_fc36583a_000111_126150d1+0x7d>
  409218:	mov    rax,r12
  40921b:	jmp    409280 <__swc_fn_fc36583a_000111_126150d1+0xe0>
  40921d:	mov    ecx,0x4
  409222:	mov    edx,0x18
  409227:	call   40fb30 <__swc_fn_fc36583a_000110_6814119b>
  40922c:	mov    rcx,rax
  40922f:	test   rax,rax
  409232:	jne    409238 <__swc_fn_fc36583a_000111_126150d1+0x98>
  409234:	xor    eax,eax
  409236:	jmp    409280 <__swc_fn_fc36583a_000111_126150d1+0xe0>
  409238:	mov    DWORD PTR [rcx+0x10],esi
  40923b:	mov    rax,r12
  40923e:	lock cmpxchg QWORD PTR [rdi],rcx
  409243:	mov    r13,rax
  409246:	cmp    rax,r12
  409249:	je     40925f <__swc_fn_fc36583a_000111_126150d1+0xbf>
  40924b:	mov    rdi,rcx
  40924e:	mov    esi,0x18
  409253:	xor    eax,eax
  409255:	call   407020 <munmap@plt>
  40925a:	mov    rax,r13
  40925d:	jmp    409280 <__swc_fn_fc36583a_000111_126150d1+0xe0>
  40925f:	test   r12,r12
  409262:	je     40927d <__swc_fn_fc36583a_000111_126150d1+0xdd>
  409264:	mov    rdi,r12
  409267:	mov    esi,0x18
  40926c:	xor    eax,eax
  40926e:	mov    QWORD PTR [rsp+0x28],rcx
  409273:	call   407020 <munmap@plt>
  409278:	mov    rcx,QWORD PTR [rsp+0x28]
  40927d:	mov    rax,rcx
  409280:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  409286:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40928c:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  409292:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  409298:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40929e:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  4092a7:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  4092b0:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  4092b9:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  4092c2:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  4092cb:	add    rsp,0xd8
  4092d2:	pop    r13
  4092d4:	pop    r12
  4092d6:	pop    rdi
  4092d7:	pop    rsi
  4092d8:	ret
  4092d9:	add    BYTE PTR [rax],al
  4092db:	add    BYTE PTR [rax],al
  4092dd:	add    BYTE PTR [rax],al
	...

00000000004092e0 <__swc_fn_fc36583a_000114_36905703>:
  4092e0:	push   rbx
  4092e1:	push   r12
  4092e3:	push   rdi
  4092e4:	push   rsi
  4092e5:	sub    rsp,0xa8
  4092ec:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4092f2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4092f8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4092fe:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409304:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40930a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409310:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409316:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40931c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409325:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40932e:	mov    rbx,rdx
  409331:	mov    r12,rcx
  409334:	mov    rdi,rcx
  409337:	mov    rsi,rdx
  40933a:	mov    edx,0x3
  40933f:	xor    eax,eax
  409341:	call   407030 <mprotect@plt>
  409346:	test   eax,eax
  409348:	je     40934e <__swc_fn_fc36583a_000114_36905703+0x6e>
  40934a:	xor    eax,eax
  40934c:	jmp    409363 <__swc_fn_fc36583a_000114_36905703+0x83>
  40934e:	mov    rcx,r12
  409351:	mov    rdx,rbx
  409354:	mov    al,0x1
  409356:	mov    r8,rax
  409359:	call   410160 <__swc_fn_fc36583a_000113_5f48311c>
  40935e:	mov    eax,0x1
  409363:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409369:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40936f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409375:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40937b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409381:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409387:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40938d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409393:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40939c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4093a5:	add    rsp,0xa8
  4093ac:	pop    rsi
  4093ad:	pop    rdi
  4093ae:	pop    r12
  4093b0:	pop    rbx
  4093b1:	ret
	...

00000000004093c0 <__swc_fn_fc36583a_000117_5208f471>:
  4093c0:	sub    rsp,0x8
  4093c4:	test   rcx,rcx
  4093c7:	jne    4093ce <__swc_fn_fc36583a_000117_5208f471+0xe>
  4093c9:	add    rsp,0x8
  4093cd:	ret
  4093ce:	call   40c920 <__swc_fn_fc36583a_000118_d3318640>
  4093d3:	add    rsp,0x8
  4093d7:	ret
	...

00000000004093e0 <__swc_fn_fc36583a_000120_0a5fa85a>:
  4093e0:	push   rdi
  4093e1:	push   rsi
  4093e2:	sub    rsp,0xa8
  4093e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4093ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4093f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4093fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409401:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409407:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40940d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409413:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409419:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409422:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40942b:	xor    edi,edi
  40942d:	xor    eax,eax
  40942f:	call   407040 <exit@plt>
  409434:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40943a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409440:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409446:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40944c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409452:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409458:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40945e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409464:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40946d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409476:	add    rsp,0xa8
  40947d:	pop    rsi
  40947e:	pop    rdi
  40947f:	ret

0000000000409480 <__swc_fn_fc36583a_000123_83db7238>:
  409480:	push   rbx
  409481:	push   rsi
  409482:	push   rdi
  409483:	push   r12
  409485:	sub    rsp,0x18
  409489:	mov    rbx,r8
  40948c:	mov    rsi,rcx
  40948f:	mov    rdi,rdx
  409492:	mov    rcx,QWORD PTR [rip+0x1aba7]        # 424040 <__swc_bss_base_fc36583a>
  409499:	test   rcx,rcx
  40949c:	jne    4094ae <__swc_fn_fc36583a_000123_83db7238+0x2e>
  40949e:	call   40a240 <__swc_fn_fc36583a_000168_994c8876>
  4094a3:	lea    rcx,[rax+0x1]
  4094a7:	mov    QWORD PTR [rip+0x1ab92],rcx        # 424040 <__swc_bss_base_fc36583a>
  4094ae:	dec    rcx
  4094b1:	call   411fc0 <__swc_fn_fc36583a_000170_360af05d>
  4094b6:	mov    r12,rax
  4094b9:	cmp    ebx,0x3
  4094bc:	jne    4094cf <__swc_fn_fc36583a_000123_83db7238+0x4f>
  4094be:	mov    rax,QWORD PTR [r12+0xbd0]
  4094c6:	test   rax,rax
  4094c9:	jne    40960c <__swc_fn_fc36583a_000123_83db7238+0x18c>
  4094cf:	cmp    ebx,0x5
  4094d2:	jne    4094f6 <__swc_fn_fc36583a_000123_83db7238+0x76>
  4094d4:	call   40c1f0 <__swc_fn_fc36583a_000094_ad13d15c>
  4094d9:	test   al,al
  4094db:	jne    4094f6 <__swc_fn_fc36583a_000123_83db7238+0x76>
  4094dd:	mov    rcx,rsi
  4094e0:	mov    rdx,rdi
  4094e3:	call   411f70 <__swc_fn_fc36583a_000167_3459066f>
  4094e8:	test   al,al
  4094ea:	je     4094f6 <__swc_fn_fc36583a_000123_83db7238+0x76>
  4094ec:	add    rsp,0x18
  4094f0:	pop    r12
  4094f2:	pop    rdi
  4094f3:	pop    rsi
  4094f4:	pop    rbx
  4094f5:	ret
  4094f6:	call   40c1f0 <__swc_fn_fc36583a_000094_ad13d15c>
  4094fb:	test   al,al
  4094fd:	jne    40956f <__swc_fn_fc36583a_000123_83db7238+0xef>
  4094ff:	vmovups xmm0,XMMWORD PTR [rsi]
  409503:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409509:	mov    rax,QWORD PTR [rsp+0x8]
  40950e:	test   rax,rax
  409511:	jne    409562 <__swc_fn_fc36583a_000123_83db7238+0xe2>
  409513:	cmp    ebx,0x3
  409516:	je     409524 <__swc_fn_fc36583a_000123_83db7238+0xa4>
  409518:	cmp    ebx,0x4
  40951b:	je     409534 <__swc_fn_fc36583a_000123_83db7238+0xb4>
  40951d:	cmp    ebx,0x5
  409520:	je     409544 <__swc_fn_fc36583a_000123_83db7238+0xc4>
  409522:	jmp    409554 <__swc_fn_fc36583a_000123_83db7238+0xd4>
  409524:	vmovups xmm0,XMMWORD PTR [rip+0xa084]        # 4135b0 <__swc_rdata_base_fc36583a+0x4a0>
  40952c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409532:	jmp    409562 <__swc_fn_fc36583a_000123_83db7238+0xe2>
  409534:	vmovups xmm0,XMMWORD PTR [rip+0xa084]        # 4135c0 <__swc_rdata_base_fc36583a+0x4b0>
  40953c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409542:	jmp    409562 <__swc_fn_fc36583a_000123_83db7238+0xe2>
  409544:	vmovups xmm0,XMMWORD PTR [rip+0xa084]        # 4135d0 <__swc_rdata_base_fc36583a+0x4c0>
  40954c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409552:	jmp    409562 <__swc_fn_fc36583a_000123_83db7238+0xe2>
  409554:	vmovups xmm0,XMMWORD PTR [rip+0xa084]        # 4135e0 <__swc_rdata_base_fc36583a+0x4d0>
  40955c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409562:	lea    rcx,[rsp+0x8]
  409567:	mov    rdx,rdi
  40956a:	call   40c440 <__swc_fn_fc36583a_000106_90faaa26>
  40956f:	vmovups xmm0,XMMWORD PTR [rdi]
  409573:	vmovups XMMWORD PTR [r12+0x940],xmm0
  40957d:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  409582:	vmovups XMMWORD PTR [r12+0x950],xmm0
  40958c:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  409591:	vmovups XMMWORD PTR [r12+0x960],xmm0
  40959b:	lea    rax,[r12+0x940]
  4095a3:	mov    QWORD PTR [r12+0x970],rax
  4095ab:	mov    rax,QWORD PTR [rsi]
  4095ae:	mov    QWORD PTR [r12+0x978],rax
  4095b6:	mov    rax,QWORD PTR [rsi+0x8]
  4095ba:	mov    QWORD PTR [r12+0x980],rax
  4095c2:	movsxd rax,ebx
  4095c5:	mov    QWORD PTR [r12+0x988],rax
  4095cd:	cmp    ebx,0x5
  4095d0:	je     4095d9 <__swc_fn_fc36583a_000123_83db7238+0x159>
  4095d2:	xor    ecx,ecx
  4095d4:	call   40a370 <__swc_fn_fc36583a_000177_718d7b54>
  4095d9:	mov    rbx,QWORD PTR [r12+0xbe8]
  4095e1:	test   rbx,rbx
  4095e4:	je     4095f5 <__swc_fn_fc36583a_000123_83db7238+0x175>
  4095e6:	mov    rcx,r12
  4095e9:	call   rbx
  4095eb:	add    rsp,0x18
  4095ef:	pop    r12
  4095f1:	pop    rdi
  4095f2:	pop    rsi
  4095f3:	pop    rbx
  4095f4:	ret
  4095f5:	mov    rcx,rsi
  4095f8:	call   410210 <__swc_fn_fc36583a_000119_2648f149>
  4095fd:	call   40ca70 <__swc_fn_fc36583a_000121_be2e2f68>
  409602:	add    rsp,0x18
  409606:	pop    r12
  409608:	pop    rdi
  409609:	pop    rsi
  40960a:	pop    rbx
  40960b:	ret
  40960c:	mov    rcx,rsi
  40960f:	mov    rdx,rdi
  409612:	call   40c440 <__swc_fn_fc36583a_000106_90faaa26>
  409617:	jmp    4094cf <__swc_fn_fc36583a_000123_83db7238+0x4f>
  40961c:	add    BYTE PTR [rax],al
	...

0000000000409620 <__swc_fn_fc36583a_000126_58f0f391>:
  409620:	push   rdi
  409621:	push   rsi
  409622:	sub    rsp,0xb8
  409629:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40962f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409635:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40963b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409641:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409647:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40964d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409653:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40965c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409665:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40966e:	mov    DWORD PTR [rsp+0x8],0x0
  409676:	lea    rdi,[rsp+0x8]
  40967b:	xor    esi,esi
  40967d:	xor    eax,eax
  40967f:	call   407050 <pthread_key_create@plt>
  409684:	test   eax,eax
  409686:	jne    40968e <__swc_fn_fc36583a_000126_58f0f391+0x6e>
  409688:	mov    eax,DWORD PTR [rsp+0x8]
  40968c:	jmp    409695 <__swc_fn_fc36583a_000126_58f0f391+0x75>
  40968e:	mov    rax,0xffffffffffffffff
  409695:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40969b:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4096a1:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4096a7:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4096ad:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4096b3:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4096b9:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4096bf:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4096c8:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4096d1:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4096da:	add    rsp,0xb8
  4096e1:	pop    rsi
  4096e2:	pop    rdi
  4096e3:	ret
	...

00000000004096f0 <__swc_fn_fc36583a_000129_4a82cdf6>:
  4096f0:	push   rdi
  4096f1:	push   rsi
  4096f2:	sub    rsp,0xb8
  4096f9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4096ff:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409705:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40970b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409711:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409717:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40971d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409723:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40972c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409735:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40973e:	mov    DWORD PTR [rsp+0x8],0x0
  409746:	lea    rdi,[rsp+0x8]
  40974b:	mov    rsi,rcx
  40974e:	xor    eax,eax
  409750:	call   407050 <pthread_key_create@plt>
  409755:	test   eax,eax
  409757:	jne    409762 <__swc_fn_fc36583a_000129_4a82cdf6+0x72>
  409759:	mov    eax,DWORD PTR [rsp+0x8]
  40975d:	inc    rax
  409760:	jmp    409764 <__swc_fn_fc36583a_000129_4a82cdf6+0x74>
  409762:	xor    eax,eax
  409764:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40976a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409770:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409776:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40977c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409782:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409788:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40978e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409797:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4097a0:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4097a9:	add    rsp,0xb8
  4097b0:	pop    rsi
  4097b1:	pop    rdi
  4097b2:	ret
	...

00000000004097c0 <__swc_fn_fc36583a_000132_ae5891af>:
  4097c0:	push   rdi
  4097c1:	push   rsi
  4097c2:	sub    rsp,0xa8
  4097c9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4097cf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4097d5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4097db:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4097e1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4097e7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4097ed:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4097f3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4097f9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409802:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40980b:	test   rcx,rcx
  40980e:	setne  al
  409811:	je     40982a <__swc_fn_fc36583a_000132_ae5891af+0x6a>
  409813:	lea    rax,[rcx-0x1]
  409817:	mov    eax,eax
  409819:	mov    edi,eax
  40981b:	mov    rsi,rdx
  40981e:	xor    eax,eax
  409820:	call   407060 <pthread_setspecific@plt>
  409825:	test   eax,eax
  409827:	sete   al
  40982a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409830:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409836:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40983c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409842:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409848:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40984e:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409854:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40985a:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409863:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40986c:	add    rsp,0xa8
  409873:	pop    rsi
  409874:	pop    rdi
  409875:	ret
	...

0000000000409880 <__swc_fn_fc36583a_000135_865f5106>:
  409880:	push   rdi
  409881:	push   rsi
  409882:	sub    rsp,0xa8
  409889:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40988f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409895:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40989b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4098a1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4098a7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4098ad:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4098b3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4098b9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4098c2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4098cb:	mov    rax,rdx
  4098ce:	mov    QWORD PTR [rsp],0x0
  4098d6:	mov    edi,0xca
  4098db:	mov    rsi,rcx
  4098de:	mov    edx,0x81
  4098e3:	mov    eax,eax
  4098e5:	mov    ecx,eax
  4098e7:	xor    r8d,r8d
  4098ea:	xor    r9d,r9d
  4098ed:	xor    eax,eax
  4098ef:	call   407070 <syscall@plt>
  4098f4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4098fa:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409900:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409906:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40990c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409912:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409918:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40991e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409924:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40992d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409936:	add    rsp,0xa8
  40993d:	pop    rsi
  40993e:	pop    rdi
  40993f:	ret

0000000000409940 <__swc_fn_fc36583a_000138_86bb0f90>:
  409940:	sub    rsp,0x8
  409944:	call   40ce10 <__swc_fn_fc36583a_000136_8c07c14b>
  409949:	add    rsp,0x8
  40994d:	ret
	...

0000000000409950 <__swc_fn_fc36583a_000141_be4c2719>:
  409950:	push   rdi
  409951:	push   rsi
  409952:	sub    rsp,0xc8
  409959:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40995f:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  409965:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40996b:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  409971:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  409977:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40997d:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  409986:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40998f:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  409998:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  4099a1:	vxorps xmm0,xmm0,xmm0
  4099a5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4099ab:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4099b1:	mov    rdi,rcx
  4099b4:	lea    rsi,[rsp+0x8]
  4099b9:	xor    eax,eax
  4099bb:	call   407080 <dladdr@plt>
  4099c0:	xor    ecx,ecx
  4099c2:	test   eax,eax
  4099c4:	je     4099cb <__swc_fn_fc36583a_000141_be4c2719+0x7b>
  4099c6:	mov    rcx,QWORD PTR [rsp+0x10]
  4099cb:	mov    rax,rcx
  4099ce:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  4099d4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  4099da:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  4099e0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  4099e6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  4099ec:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  4099f2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  4099fb:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  409a04:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  409a0d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  409a16:	add    rsp,0xc8
  409a1d:	pop    rsi
  409a1e:	pop    rdi
  409a1f:	ret

0000000000409a20 <__swc_fn_fc36583a_000144_1534de9a>:
  409a20:	push   rbx
  409a21:	push   r12
  409a23:	push   r13
  409a25:	push   rdi
  409a26:	push   rsi
  409a27:	push   r14
  409a29:	push   r15
  409a2b:	sub    rsp,0x150
  409a32:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  409a3b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  409a44:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  409a4d:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  409a56:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  409a5f:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  409a68:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  409a71:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  409a7a:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  409a83:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  409a8c:	mov    rbx,rdx
  409a8f:	mov    QWORD PTR [rsp+0x98],rdx
  409a97:	mov    r12,rcx
  409a9a:	mov    QWORD PTR [rsp+0xa0],rcx
  409aa2:	mov    QWORD PTR [rbx],0x0
  409aa9:	lea    r13,[rip+0x1d2c8]        # 426d78 <__swc_bss_base_fc36583a+0x2d38>
  409ab0:	mov    rcx,r13
  409ab3:	call   409940 <__swc_fn_fc36583a_000138_86bb0f90>
  409ab8:	mov    rax,QWORD PTR [rip+0x1d2c1]        # 426d80 <__swc_bss_base_fc36583a+0x2d40>
  409abf:	test   rax,rax
  409ac2:	je     409af9 <__swc_fn_fc36583a_000144_1534de9a+0xd9>
  409ac4:	cs nop WORD PTR [rax+rax*1+0x0]
  409ace:	xchg   ax,ax
  409ad0:	cmp    QWORD PTR [rax+0x8],r12
  409ad4:	jne    409af1 <__swc_fn_fc36583a_000144_1534de9a+0xd1>
  409ad6:	mov    rcx,QWORD PTR [rax+0x18]
  409ada:	mov    QWORD PTR [rbx],rcx
  409add:	mov    rbx,QWORD PTR [rax+0x10]
  409ae1:	mov    rcx,r13
  409ae4:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  409ae9:	mov    rax,rbx
  409aec:	jmp    409cdb <__swc_fn_fc36583a_000144_1534de9a+0x2bb>
  409af1:	mov    rax,QWORD PTR [rax]
  409af4:	test   rax,rax
  409af7:	jne    409ad0 <__swc_fn_fc36583a_000144_1534de9a+0xb0>
  409af9:	vxorps xmm0,xmm0,xmm0
  409afd:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  409b03:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  409b09:	mov    rdi,r12
  409b0c:	lea    rsi,[rsp+0x10]
  409b11:	xor    eax,eax
  409b13:	call   407080 <dladdr@plt>
  409b18:	test   eax,eax
  409b1a:	sete   al
  409b1d:	je     409b2a <__swc_fn_fc36583a_000144_1534de9a+0x10a>
  409b1f:	mov    rax,QWORD PTR [rsp+0x10]
  409b24:	test   rax,rax
  409b27:	sete   al
  409b2a:	test   al,al
  409b2c:	je     409b3d <__swc_fn_fc36583a_000144_1534de9a+0x11d>
  409b2e:	mov    rcx,r13
  409b31:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  409b36:	xor    eax,eax
  409b38:	jmp    409cdb <__swc_fn_fc36583a_000144_1534de9a+0x2bb>
  409b3d:	mov    rdi,QWORD PTR [rsp+0x10]
  409b42:	mov    esi,0x80000
  409b47:	xor    eax,eax
  409b49:	call   407090 <open@plt>
  409b4e:	lea    r14,[rsp+0x30]
  409b53:	mov    DWORD PTR [rsp+0x30],eax
  409b57:	cmp    DWORD PTR [r14],0x0
  409b5b:	jge    409b6c <__swc_fn_fc36583a_000144_1534de9a+0x14c>
  409b5d:	mov    rcx,r13
  409b60:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  409b65:	xor    eax,eax
  409b67:	jmp    409cdb <__swc_fn_fc36583a_000144_1534de9a+0x2bb>
  409b6c:	mov    rax,r14
  409b6f:	movsxd rdi,DWORD PTR [rax]
  409b72:	xor    esi,esi
  409b74:	mov    edx,0x2
  409b79:	xor    eax,eax
  409b7b:	call   4070a0 <lseek@plt>
  409b80:	mov    r15,rax
  409b83:	test   rax,rax
  409b86:	jg     409ba1 <__swc_fn_fc36583a_000144_1534de9a+0x181>
  409b88:	movsxd rdi,DWORD PTR [r14]
  409b8b:	xor    eax,eax
  409b8d:	call   4070b0 <close@plt>
  409b92:	mov    rcx,r13
  409b95:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  409b9a:	xor    eax,eax
  409b9c:	jmp    409cdb <__swc_fn_fc36583a_000144_1534de9a+0x2bb>
  409ba1:	xor    edi,edi
  409ba3:	mov    rsi,r15
  409ba6:	mov    edx,0x1
  409bab:	mov    ecx,0x2
  409bb0:	mov    rax,r14
  409bb3:	movsxd r8,DWORD PTR [rax]
  409bb6:	xor    r9d,r9d
  409bb9:	xor    eax,eax
  409bbb:	call   4070c0 <mmap@plt>
  409bc0:	mov    rbx,rax
  409bc3:	test   rax,rax
  409bc6:	sete   al
  409bc9:	cmp    rbx,0xffffffffffffffff
  409bcd:	sete   cl
  409bd0:	or     al,cl
  409bd2:	je     409bed <__swc_fn_fc36583a_000144_1534de9a+0x1cd>
  409bd4:	movsxd rdi,DWORD PTR [r14]
  409bd7:	xor    eax,eax
  409bd9:	call   4070b0 <close@plt>
  409bde:	mov    rcx,r13
  409be1:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  409be6:	xor    eax,eax
  409be8:	jmp    409cdb <__swc_fn_fc36583a_000144_1534de9a+0x2bb>
  409bed:	lea    rax,[rsp+0x50]
  409bf2:	mov    QWORD PTR [rax],0x0
  409bf9:	mov    rcx,rbx
  409bfc:	mov    rdx,r15
  409bff:	mov    r8,rax
  409c02:	call   4107a0 <__swc_fn_fc36583a_000143_d5d4d43f>
  409c07:	mov    r12,rax
  409c0a:	test   rax,rax
  409c0d:	jne    409c35 <__swc_fn_fc36583a_000144_1534de9a+0x215>
  409c0f:	mov    rdi,rbx
  409c12:	mov    rsi,r15
  409c15:	xor    eax,eax
  409c17:	call   407020 <munmap@plt>
  409c1c:	movsxd rdi,DWORD PTR [r14]
  409c1f:	xor    eax,eax
  409c21:	call   4070b0 <close@plt>
  409c26:	mov    rcx,r13
  409c29:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  409c2e:	xor    eax,eax
  409c30:	jmp    409cdb <__swc_fn_fc36583a_000144_1534de9a+0x2bb>
  409c35:	mov    edi,0x20
  409c3a:	xor    eax,eax
  409c3c:	call   4070d0 <malloc@plt>
  409c41:	test   rax,rax
  409c44:	jne    409c69 <__swc_fn_fc36583a_000144_1534de9a+0x249>
  409c46:	mov    rdi,rbx
  409c49:	mov    rsi,r15
  409c4c:	xor    eax,eax
  409c4e:	call   407020 <munmap@plt>
  409c53:	movsxd rdi,DWORD PTR [r14]
  409c56:	xor    eax,eax
  409c58:	call   4070b0 <close@plt>
  409c5d:	mov    rcx,r13
  409c60:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  409c65:	xor    eax,eax
  409c67:	jmp    409cdb <__swc_fn_fc36583a_000144_1534de9a+0x2bb>
  409c69:	mov    rcx,QWORD PTR [rip+0x1d110]        # 426d80 <__swc_bss_base_fc36583a+0x2d40>
  409c70:	mov    QWORD PTR [rsp+0x70],rcx
  409c75:	mov    rcx,QWORD PTR [rsp+0xa0]
  409c7d:	mov    QWORD PTR [rsp+0x78],rcx
  409c82:	mov    QWORD PTR [rsp+0x80],r12
  409c8a:	mov    rcx,QWORD PTR [rsp+0x50]
  409c8f:	mov    QWORD PTR [rsp+0x88],rcx
  409c97:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  409c9d:	vmovups XMMWORD PTR [rax],xmm0
  409ca1:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  409caa:	vmovups XMMWORD PTR [rax+0x10],xmm0
  409caf:	mov    QWORD PTR [rip+0x1d0ca],rax        # 426d80 <__swc_bss_base_fc36583a+0x2d40>
  409cb6:	mov    rax,QWORD PTR [rsp+0x50]
  409cbb:	mov    rbx,QWORD PTR [rsp+0x98]
  409cc3:	mov    QWORD PTR [rbx],rax
  409cc6:	movsxd rdi,DWORD PTR [r14]
  409cc9:	xor    eax,eax
  409ccb:	call   4070b0 <close@plt>
  409cd0:	mov    rcx,r13
  409cd3:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  409cd8:	mov    rax,r12
  409cdb:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  409ce4:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  409ced:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  409cf6:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  409cff:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  409d08:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  409d11:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  409d1a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  409d23:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  409d2c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  409d35:	add    rsp,0x150
  409d3c:	pop    r15
  409d3e:	pop    r14
  409d40:	pop    rsi
  409d41:	pop    rdi
  409d42:	pop    r13
  409d44:	pop    r12
  409d46:	pop    rbx
  409d47:	ret
	...

0000000000409d50 <__swc_fn_fc36583a_000147_43c96957>:
  409d50:	push   rbx
  409d51:	sub    rsp,0xe0
  409d58:	lea    rbx,[rsp+0x8]
  409d5d:	vxorps xmm0,xmm0,xmm0
  409d61:	vmovups YMMWORD PTR [rbx],ymm0
  409d65:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  409d6a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  409d6f:	vzeroupper
  409d72:	mov    DWORD PTR [rbx+0x60],0x0
  409d79:	mov    r8,rbx
  409d7c:	nop    DWORD PTR [rax+0x0]
  409d80:	mov    r9,rcx
  409d83:	movabs rcx,0xcccccccccccccccd
  409d8d:	mov    rax,r9
  409d90:	mul    rcx
  409d93:	mov    r10,rdx
  409d96:	shr    r10,0x3
  409d9a:	mov    rcx,r10
  409d9d:	imul   rdx,r10,0xa
  409da1:	sub    r9,rdx
  409da4:	mov    rdx,QWORD PTR [rip+0x9865]        # 413610 <__swc_rdata_base_fc36583a+0x500>
  409dab:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  409db0:	mov    BYTE PTR [r8],dl
  409db3:	lea    rdx,[r8+0x1]
  409db7:	mov    r8,rdx
  409dba:	test   r10,r10
  409dbd:	jne    409d80 <__swc_fn_fc36583a_000147_43c96957+0x30>
  409dbf:	mov    BYTE PTR [rdx],0x0
  409dc2:	sub    r8,0x1
  409dc6:	mov    rax,rbx
  409dc9:	cmp    rax,r8
  409dcc:	jae    409de6 <__swc_fn_fc36583a_000147_43c96957+0x96>
  409dce:	xchg   ax,ax
  409dd0:	mov    cl,BYTE PTR [r8]
  409dd3:	mov    dl,BYTE PTR [rax]
  409dd5:	mov    BYTE PTR [r8],dl
  409dd8:	sub    r8,0x1
  409ddc:	mov    BYTE PTR [rax],cl
  409dde:	inc    rax
  409de1:	cmp    rax,r8
  409de4:	jb     409dd0 <__swc_fn_fc36583a_000147_43c96957+0x80>
  409de6:	xor    eax,eax
  409de8:	test   rbx,rbx
  409deb:	je     409e0e <__swc_fn_fc36583a_000147_43c96957+0xbe>
  409ded:	mov    rcx,rbx
  409df0:	mov    dl,BYTE PTR [rcx]
  409df2:	test   dl,dl
  409df4:	je     409e0e <__swc_fn_fc36583a_000147_43c96957+0xbe>
  409df6:	cs nop WORD PTR [rax+rax*1+0x0]
  409e00:	add    rcx,0x1
  409e04:	add    rax,0x1
  409e08:	mov    dl,BYTE PTR [rcx]
  409e0a:	test   dl,dl
  409e0c:	jne    409e00 <__swc_fn_fc36583a_000147_43c96957+0xb0>
  409e0e:	mov    QWORD PTR [rbx+0xa8],rbx
  409e15:	mov    QWORD PTR [rbx+0xb0],rax
  409e1c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  409e24:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  409e2c:	lea    rcx,[rbx+0xb8]
  409e33:	call   410210 <__swc_fn_fc36583a_000119_2648f149>
  409e38:	add    rsp,0xe0
  409e3f:	pop    rbx
  409e40:	ret
	...

0000000000409e50 <__swc_fn_fc36583a_000150_6fb05988>:
  409e50:	sub    rsp,0x8
  409e54:	mov    rax,QWORD PTR [rcx+0x8]
  409e58:	mov    r8,QWORD PTR [rdx+0x8]
  409e5c:	cmp    rax,r8
  409e5f:	je     409e68 <__swc_fn_fc36583a_000150_6fb05988+0x18>
  409e61:	xor    eax,eax
  409e63:	add    rsp,0x8
  409e67:	ret
  409e68:	test   rax,rax
  409e6b:	jne    409e7c <__swc_fn_fc36583a_000150_6fb05988+0x2c>
  409e6d:	test   r8,r8
  409e70:	jne    409e7c <__swc_fn_fc36583a_000150_6fb05988+0x2c>
  409e72:	mov    eax,0x1
  409e77:	add    rsp,0x8
  409e7b:	ret
  409e7c:	mov    rcx,QWORD PTR [rcx]
  409e7f:	mov    rdx,QWORD PTR [rdx]
  409e82:	test   rcx,rcx
  409e85:	sete   r8b
  409e89:	test   rdx,rdx
  409e8c:	sete   r9b
  409e90:	or     r8b,r9b
  409e93:	je     409ea0 <__swc_fn_fc36583a_000150_6fb05988+0x50>
  409e95:	cmp    rcx,rdx
  409e98:	sete   al
  409e9b:	add    rsp,0x8
  409e9f:	ret
  409ea0:	cmp    rcx,rdx
  409ea3:	jne    409eaf <__swc_fn_fc36583a_000150_6fb05988+0x5f>
  409ea5:	mov    eax,0x1
  409eaa:	add    rsp,0x8
  409eae:	ret
  409eaf:	mov    r8,rax
  409eb2:	call   40c500 <__swc_fn_fc36583a_000109_3dc01326>
  409eb7:	test   eax,eax
  409eb9:	sete   al
  409ebc:	add    rsp,0x8
  409ec0:	ret
	...

0000000000409ed0 <__swc_fn_fc36583a_000153_86f1d437>:
  409ed0:	vxorps xmm0,xmm0,xmm0
  409ed4:	vmovups XMMWORD PTR [rcx],xmm0
  409ed8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409edd:	vxorps xmm0,xmm0,xmm0
  409ee1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409ee6:	vmovups xmm0,XMMWORD PTR [rip+0x97da]        # 4136c8 <__swc_rdata_base_fc36583a+0x5b8>
  409eee:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409ef3:	ret
	...

0000000000409f00 <__swc_fn_fc36583a_000156_86f1d437>:
  409f00:	vxorps xmm0,xmm0,xmm0
  409f04:	vmovups XMMWORD PTR [rcx],xmm0
  409f08:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409f0d:	vxorps xmm0,xmm0,xmm0
  409f11:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409f16:	vmovups xmm0,XMMWORD PTR [rip+0x98ca]        # 4137e8 <__swc_rdata_base_fc36583a+0x6d8>
  409f1e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409f23:	mov    QWORD PTR [rcx+0x40],0x0
  409f2b:	ret
  409f2c:	add    BYTE PTR [rax],al
	...

0000000000409f30 <__swc_fn_fc36583a_000159_47b270e1>:
  409f30:	push   rbx
  409f31:	sub    rsp,0x70
  409f35:	mov    rax,QWORD PTR [rcx]
  409f38:	mov    rbx,QWORD PTR [rcx+0x8]
  409f3c:	vxorps xmm0,xmm0,xmm0
  409f40:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  409f46:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  409f4c:	vzeroupper
  409f4f:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  409f55:	mov    QWORD PTR [rsp+0x48],rdx
  409f5a:	mov    QWORD PTR [rsp+0x50],r8
  409f5f:	mov    rcx,rax
  409f62:	lea    rdx,[rsp+0x8]
  409f67:	mov    rbx,QWORD PTR [rbx+0x18]
  409f6b:	call   rbx
  409f6d:	add    rsp,0x70
  409f71:	pop    rbx
  409f72:	ret
	...

0000000000409f80 <__swc_fn_fc36583a_000162_8a3d304f>:
  409f80:	push   rbx
  409f81:	push   rsi
  409f82:	push   rdi
  409f83:	mov    rbx,r8
  409f86:	mov    rsi,rcx
  409f89:	mov    rdi,rdx
  409f8c:	call   40d210 <__swc_fn_fc36583a_000160_13ead2ff>
  409f91:	vmovups xmm0,XMMWORD PTR [rbx]
  409f95:	vmovups XMMWORD PTR [rsi],xmm0
  409f99:	mov    QWORD PTR [rsi+0x18],rdi
  409f9d:	pop    rdi
  409f9e:	pop    rsi
  409f9f:	pop    rbx
  409fa0:	ret
	...

0000000000409fb0 <__swc_fn_fc36583a_000165_cc119975>:
  409fb0:	push   rbx
  409fb1:	push   rsi
  409fb2:	push   rdi
  409fb3:	push   r12
  409fb5:	push   r13
  409fb7:	sub    rsp,0x50
  409fbb:	mov    rbx,rcx
  409fbe:	mov    rsi,rdx
  409fc1:	vmovups xmm0,XMMWORD PTR [rip+0x992f]        # 4138f8 <__swc_rdata_base_fc36583a+0x7e8>
  409fc9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409fcf:	vmovups xmm0,XMMWORD PTR [rip+0x9931]        # 413908 <__swc_rdata_base_fc36583a+0x7f8>
  409fd7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409fdd:	vxorps xmm0,xmm0,xmm0
  409fe1:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409fe7:	mov    rcx,rdx
  409fea:	call   409950 <__swc_fn_fc36583a_000141_be4c2719>
  409fef:	mov    rdi,rax
  409ff2:	test   rax,rax
  409ff5:	jne    40a026 <__swc_fn_fc36583a_000165_cc119975+0x76>
  409ff7:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409ffd:	vmovups XMMWORD PTR [rbx],xmm0
  40a001:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a007:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a00c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a012:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a017:	mov    rax,rbx
  40a01a:	add    rsp,0x50
  40a01e:	pop    r13
  40a020:	pop    r12
  40a022:	pop    rdi
  40a023:	pop    rsi
  40a024:	pop    rbx
  40a025:	ret
  40a026:	mov    rcx,rdi
  40a029:	call   411cc0 <__swc_fn_fc36583a_000164_016ee66a>
  40a02e:	mov    r11,rax
  40a031:	test   rax,rax
  40a034:	je     40a03e <__swc_fn_fc36583a_000165_cc119975+0x8e>
  40a036:	mov    al,BYTE PTR [r11+0x24]
  40a03a:	test   al,al
  40a03c:	jne    40a06d <__swc_fn_fc36583a_000165_cc119975+0xbd>
  40a03e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a044:	vmovups XMMWORD PTR [rbx],xmm0
  40a048:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a04e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a053:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a059:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a05e:	mov    rax,rbx
  40a061:	add    rsp,0x50
  40a065:	pop    r13
  40a067:	pop    r12
  40a069:	pop    rdi
  40a06a:	pop    rsi
  40a06b:	pop    rbx
  40a06c:	ret
  40a06d:	sub    rsi,rdi
  40a070:	mov    eax,0xffffffff
  40a075:	cmp    rsi,rax
  40a078:	jbe    40a0a9 <__swc_fn_fc36583a_000165_cc119975+0xf9>
  40a07a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a080:	vmovups XMMWORD PTR [rbx],xmm0
  40a084:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a08a:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a08f:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a095:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a09a:	mov    rax,rbx
  40a09d:	add    rsp,0x50
  40a0a1:	pop    r13
  40a0a3:	pop    r12
  40a0a5:	pop    rdi
  40a0a6:	pop    rsi
  40a0a7:	pop    rbx
  40a0a8:	ret
  40a0a9:	mov    rdi,QWORD PTR [r11+0x10]
  40a0ad:	mov    eax,DWORD PTR [r11+0x20]
  40a0b1:	xor    ecx,ecx
  40a0b3:	test   rax,rax
  40a0b6:	jbe    40a208 <__swc_fn_fc36583a_000165_cc119975+0x258>
  40a0bc:	nop    DWORD PTR [rax+0x0]
  40a0c0:	mov    edx,ecx
  40a0c2:	imul   r12,rdx,0x14
  40a0c6:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40a0cb:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40a0d0:	mov    r9d,esi
  40a0d3:	cmp    r9,rdx
  40a0d6:	jb     40a1fb <__swc_fn_fc36583a_000165_cc119975+0x24b>
  40a0dc:	add    rdx,r8
  40a0df:	mov    r8d,esi
  40a0e2:	cmp    r8,rdx
  40a0e5:	jae    40a1fb <__swc_fn_fc36583a_000165_cc119975+0x24b>
  40a0eb:	lea    rsi,[rsp+0x38]
  40a0f0:	mov    eax,DWORD PTR [rdi+0xc]
  40a0f3:	mov    DWORD PTR [rsp+0x38],eax
  40a0f7:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40a0fc:	mov    rcx,rdi
  40a0ff:	mov    rdx,QWORD PTR [r11+0x18]
  40a103:	mov    r8,rsi
  40a106:	mov    r8d,DWORD PTR [r8]
  40a109:	mov    r9,rax
  40a10c:	lea    r10,[rsp+0x10]
  40a111:	call   40d260 <__swc_fn_fc36583a_000163_72795826>
  40a116:	test   al,al
  40a118:	jne    40a14b <__swc_fn_fc36583a_000165_cc119975+0x19b>
  40a11a:	vmovups xmm0,XMMWORD PTR [rip+0x9806]        # 413928 <__swc_rdata_base_fc36583a+0x818>
  40a122:	vmovups XMMWORD PTR [rbx],xmm0
  40a126:	vmovups xmm0,XMMWORD PTR [rip+0x980a]        # 413938 <__swc_rdata_base_fc36583a+0x828>
  40a12e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a133:	vxorps xmm0,xmm0,xmm0
  40a137:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a13c:	mov    rax,rbx
  40a13f:	add    rsp,0x50
  40a143:	pop    r13
  40a145:	pop    r12
  40a147:	pop    rdi
  40a148:	pop    rsi
  40a149:	pop    rbx
  40a14a:	ret
  40a14b:	lea    r13,[rsp+0x3c]
  40a150:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40a155:	mov    DWORD PTR [rsp+0x3c],eax
  40a159:	test   eax,eax
  40a15b:	je     40a1ac <__swc_fn_fc36583a_000165_cc119975+0x1fc>
  40a15d:	mov    rcx,rdi
  40a160:	mov    rdx,QWORD PTR [r11+0x18]
  40a164:	mov    r8d,DWORD PTR [rsi]
  40a167:	mov    rax,r13
  40a16a:	mov    r9d,DWORD PTR [rax]
  40a16d:	lea    r10,[rsp+0x20]
  40a172:	call   40d260 <__swc_fn_fc36583a_000163_72795826>
  40a177:	test   al,al
  40a179:	jne    40a1ac <__swc_fn_fc36583a_000165_cc119975+0x1fc>
  40a17b:	vmovups xmm0,XMMWORD PTR [rip+0x97d5]        # 413958 <__swc_rdata_base_fc36583a+0x848>
  40a183:	vmovups XMMWORD PTR [rbx],xmm0
  40a187:	vmovups xmm0,XMMWORD PTR [rip+0x97d9]        # 413968 <__swc_rdata_base_fc36583a+0x858>
  40a18f:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a194:	vxorps xmm0,xmm0,xmm0
  40a198:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a19d:	mov    rax,rbx
  40a1a0:	add    rsp,0x50
  40a1a4:	pop    r13
  40a1a6:	pop    r12
  40a1a8:	pop    rdi
  40a1a9:	pop    rsi
  40a1aa:	pop    rbx
  40a1ab:	ret
  40a1ac:	mov    eax,0x1
  40a1b1:	rex mov BYTE PTR [rsp+0x8],al
  40a1b6:	cmp    DWORD PTR [r13+0x0],0x0
  40a1bb:	je     40a1cc <__swc_fn_fc36583a_000165_cc119975+0x21c>
  40a1bd:	rex mov BYTE PTR [rsp+0x9],0x1
  40a1c3:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40a1c8:	mov    DWORD PTR [rsp+0x30],eax
  40a1cc:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a1d2:	vmovups XMMWORD PTR [rbx],xmm0
  40a1d6:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a1dc:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a1e1:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a1e7:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a1ec:	mov    rax,rbx
  40a1ef:	add    rsp,0x50
  40a1f3:	pop    r13
  40a1f5:	pop    r12
  40a1f7:	pop    rdi
  40a1f8:	pop    rsi
  40a1f9:	pop    rbx
  40a1fa:	ret
  40a1fb:	add    rcx,0x1
  40a1ff:	cmp    rcx,rax
  40a202:	jb     40a0c0 <__swc_fn_fc36583a_000165_cc119975+0x110>
  40a208:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a20e:	vmovups XMMWORD PTR [rbx],xmm0
  40a212:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a218:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a21d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a223:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a228:	mov    rax,rbx
  40a22b:	add    rsp,0x50
  40a22f:	pop    r13
  40a231:	pop    r12
  40a233:	pop    rdi
  40a234:	pop    rsi
  40a235:	pop    rbx
  40a236:	ret
	...

000000000040a240 <__swc_fn_fc36583a_000168_994c8876>:
  40a240:	sub    rsp,0x48
  40a244:	call   409620 <__swc_fn_fc36583a_000126_58f0f391>
  40a249:	cmp    rax,0xffffffffffffffff
  40a24d:	je     40a254 <__swc_fn_fc36583a_000168_994c8876+0x14>
  40a24f:	add    rsp,0x48
  40a253:	ret
  40a254:	lea    rcx,[rip+0x973d]        # 413998 <__swc_rdata_base_fc36583a+0x888>
  40a25b:	vmovups xmm0,XMMWORD PTR [rip+0x9745]        # 4139a8 <__swc_rdata_base_fc36583a+0x898>
  40a263:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a269:	vmovups xmm0,XMMWORD PTR [rip+0x9747]        # 4139b8 <__swc_rdata_base_fc36583a+0x8a8>
  40a271:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a277:	vmovups xmm0,XMMWORD PTR [rip+0x9749]        # 4139c8 <__swc_rdata_base_fc36583a+0x8b8>
  40a27f:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a285:	lea    rdx,[rsp+0x8]
  40a28a:	mov    QWORD PTR [rsp+0x38],rax
  40a28f:	call   40c440 <__swc_fn_fc36583a_000106_90faaa26>
  40a294:	mov    rax,QWORD PTR [rsp+0x38]
  40a299:	jmp    40a24f <__swc_fn_fc36583a_000168_994c8876+0xf>
  40a29b:	add    BYTE PTR [rax],al
  40a29d:	add    BYTE PTR [rax],al
	...

000000000040a2a0 <__swc_fn_fc36583a_000171_cbeff767>:
  40a2a0:	push   rbx
  40a2a1:	push   rsi
  40a2a2:	sub    rsp,0x28
  40a2a6:	mov    rbx,rcx
  40a2a9:	mov    DWORD PTR [rsp+0x8],0xbf0
  40a2b1:	mov    ecx,0xbf0
  40a2b6:	call   40c030 <__swc_fn_fc36583a_000082_4a10c7e7>
  40a2bb:	mov    rsi,rax
  40a2be:	test   rax,rax
  40a2c1:	jne    40a2cc <__swc_fn_fc36583a_000171_cbeff767+0x2c>
  40a2c3:	xor    eax,eax
  40a2c5:	add    rsp,0x28
  40a2c9:	pop    rsi
  40a2ca:	pop    rbx
  40a2cb:	ret
  40a2cc:	vxorps xmm0,xmm0,xmm0
  40a2d0:	xor    eax,eax
  40a2d2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2dc:	nop    DWORD PTR [rax+0x0]
  40a2e0:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40a2e5:	add    rax,0x10
  40a2e9:	cmp    rax,0xbf0
  40a2f0:	jne    40a2e0 <__swc_fn_fc36583a_000171_cbeff767+0x40>
  40a2f2:	lea    rax,[rbx+0x1]
  40a2f6:	mov    QWORD PTR [rsi+0x9c0],rax
  40a2fd:	mov    rcx,rbx
  40a300:	mov    rdx,rsi
  40a303:	call   40d5c0 <__swc_fn_fc36583a_000169_646fdf20>
  40a308:	test   al,al
  40a30a:	jne    40a31d <__swc_fn_fc36583a_000171_cbeff767+0x7d>
  40a30c:	mov    rcx,rsi
  40a30f:	call   40f190 <__swc_fn_fc36583a_000083_cf82995a>
  40a314:	xor    eax,eax
  40a316:	add    rsp,0x28
  40a31a:	pop    rsi
  40a31b:	pop    rbx
  40a31c:	ret
  40a31d:	lea    rcx,[rsp+0x18]
  40a322:	call   40f710 <__swc_fn_fc36583a_000095_93bfe675>
  40a327:	mov    rax,rsi
  40a32a:	add    rsp,0x28
  40a32e:	pop    rsi
  40a32f:	pop    rbx
  40a330:	ret
	...

000000000040a340 <__swc_fn_fc36583a_000174_e09f8b62>:
  40a340:	xor    eax,eax
  40a342:	mov    edx,0x1
  40a347:	lock cmpxchg QWORD PTR [rcx],rdx
  40a34c:	test   rax,rax
  40a34f:	jne    40a352 <__swc_fn_fc36583a_000174_e09f8b62+0x12>
  40a351:	ret
  40a352:	cs nop WORD PTR [rax+rax*1+0x0]
  40a35c:	nop    DWORD PTR [rax+0x0]
  40a360:	mov    rax,QWORD PTR [rcx]
  40a363:	test   rax,rax
  40a366:	je     40a340 <__swc_fn_fc36583a_000174_e09f8b62>
  40a368:	jmp    40a360 <__swc_fn_fc36583a_000174_e09f8b62+0x20>
  40a36a:	add    BYTE PTR [rax],al
  40a36c:	add    BYTE PTR [rax],al
	...

000000000040a370 <__swc_fn_fc36583a_000177_718d7b54>:
  40a370:	push   rsi
  40a371:	push   rdi
  40a372:	sub    rsp,0x38
  40a376:	mov    rsi,rcx
  40a379:	call   40d5d0 <__swc_fn_fc36583a_000172_1e0ea8cf>
  40a37e:	mov    rdi,rax
  40a381:	call   40cd60 <__swc_fn_fc36583a_000133_a9c1c700>
  40a386:	mov    r8,rax
  40a389:	mov    rcx,rdi
  40a38c:	call   40a340 <__swc_fn_fc36583a_000174_e09f8b62>
  40a391:	mov    rax,QWORD PTR [rdi+0x8]
  40a395:	test   rax,rax
  40a398:	je     40a3d5 <__swc_fn_fc36583a_000177_718d7b54+0x65>
  40a39a:	nop    WORD PTR [rax+rax*1+0x0]
  40a3a0:	cmp    rax,rsi
  40a3a3:	je     40a3d5 <__swc_fn_fc36583a_000177_718d7b54+0x65>
  40a3a5:	mov    r9,QWORD PTR [rax]
  40a3a8:	cmp    QWORD PTR [rax+0x20],r8
  40a3ac:	jne    40a3cd <__swc_fn_fc36583a_000177_718d7b54+0x5d>
  40a3ae:	mov    rcx,rdi
  40a3b1:	mov    rdx,rax
  40a3b4:	mov    QWORD PTR [rsp+0x28],r8
  40a3b9:	mov    QWORD PTR [rsp+0x30],r9
  40a3be:	call   4120e0 <__swc_fn_fc36583a_000176_cf4ffedd>
  40a3c3:	mov    r8,QWORD PTR [rsp+0x28]
  40a3c8:	mov    r9,QWORD PTR [rsp+0x30]
  40a3cd:	mov    rax,r9
  40a3d0:	test   r9,r9
  40a3d3:	jne    40a3a0 <__swc_fn_fc36583a_000177_718d7b54+0x30>
  40a3d5:	xor    eax,eax
  40a3d7:	mov    QWORD PTR [rdi],rax
  40a3da:	add    rsp,0x38
  40a3de:	pop    rdi
  40a3df:	pop    rsi
  40a3e0:	ret
	...

000000000040a400 <__swc_fn_fc36583a_000001_1ca87929>:
  40a400:	push   rdi
  40a401:	push   rsi
  40a402:	sub    rsp,0xb8
  40a409:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40a40f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40a415:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40a41b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40a421:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40a427:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40a42d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40a433:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40a43c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40a445:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40a44e:	vxorps xmm0,xmm0,xmm0
  40a452:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a458:	mov    edi,0x1
  40a45d:	lea    rsi,[rsp+0x8]
  40a462:	xor    eax,eax
  40a464:	call   4070e0 <clock_gettime@plt>
  40a469:	vxorpd xmm0,xmm0,xmm0
  40a46d:	mov    rax,QWORD PTR [rsp+0x8]
  40a472:	vcvtsi2sd xmm0,xmm0,rax
  40a477:	vxorpd xmm1,xmm1,xmm1
  40a47b:	mov    rax,QWORD PTR [rsp+0x10]
  40a480:	vcvtsi2sd xmm1,xmm1,rax
  40a485:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x8c83]        # 413110 <__swc_rdata_base_fc36583a>
  40a48d:	vaddsd xmm0,xmm0,xmm1
  40a491:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40a497:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40a49d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40a4a3:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40a4a9:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40a4af:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40a4b5:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40a4bb:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40a4c4:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40a4cd:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40a4d6:	add    rsp,0xb8
  40a4dd:	pop    rsi
  40a4de:	pop    rdi
  40a4df:	ret

000000000040a4e0 <__swc_fn_fc36583a_000004_9ee35b18>:
  40a4e0:	vxorps xmm0,xmm0,xmm0
  40a4e4:	xor    eax,eax
  40a4e6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a4f0:	cs nop WORD PTR [rax+rax*1+0x0]
  40a4fa:	nop    WORD PTR [rax+rax*1+0x0]
  40a500:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a505:	add    rax,0x10
  40a509:	cmp    rax,0x2080
  40a510:	jne    40a500 <__swc_fn_fc36583a_000004_9ee35b18+0x20>
  40a512:	ret
	...

000000000040a520 <__swc_fn_fc36583a_000007_d64b2baa>:
  40a520:	push   rsi
  40a521:	push   rdi
  40a522:	push   r12
  40a524:	push   r13
  40a526:	push   r14
  40a528:	mov    rsi,rcx
  40a52b:	mov    edi,r10d
  40a52e:	mov    r12,rcx
  40a531:	mov    r13,r9
  40a534:	mov    ecx,DWORD PTR [rdx+0x28]
  40a537:	shlx   r14d,r8d,ecx
  40a53c:	mov    rcx,rdx
  40a53f:	mov    edx,r8d
  40a542:	call   40e050 <__swc_fn_fc36583a_000014_9dea5065>
  40a547:	mov    rcx,rax
  40a54a:	mov    eax,DWORD PTR [r12+0x3c]
  40a54f:	xor    edx,edx
  40a551:	div    rdi
  40a554:	vxorps xmm0,xmm0,xmm0
  40a558:	vmovdqu XMMWORD PTR [rsi],xmm0
  40a55c:	mov    QWORD PTR [r12+0x60],0x0
  40a565:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40a56a:	mov    QWORD PTR [r12+0x10],rcx
  40a56f:	imul   rax,rdi
  40a573:	lea    rdx,[rcx+rax*1]
  40a577:	mov    QWORD PTR [r12+0x18],rdx
  40a57c:	mov    QWORD PTR [r12+0x20],rcx
  40a581:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40a586:	mov    DWORD PTR [r12+0x28],0x0
  40a58f:	mov    DWORD PTR [r12+0x68],0x0
  40a598:	mov    BYTE PTR [r12+0x39],r13b
  40a59d:	mov    BYTE PTR [r12+0x3a],r14b
  40a5a2:	mov    BYTE PTR [r12+0x3b],0x1
  40a5a8:	mov    DWORD PTR [r12+0x6c],0x0
  40a5b1:	mov    rcx,r12
  40a5b4:	mov    edx,edi
  40a5b6:	call   40dfb0 <__swc_fn_fc36583a_000008_065ed5b1>
  40a5bb:	pop    r14
  40a5bd:	pop    r13
  40a5bf:	pop    r12
  40a5c1:	pop    rdi
  40a5c2:	pop    rsi
  40a5c3:	ret
	...

000000000040a5d0 <__swc_fn_fc36583a_000010_c3647f66>:
  40a5d0:	mov    r8d,0x1
  40a5d6:	xor    eax,eax
  40a5d8:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40a5de:	test   eax,eax
  40a5e0:	jne    40a5d0 <__swc_fn_fc36583a_000010_c3647f66>
  40a5e2:	ret
	...

000000000040a5f0 <__swc_fn_fc36583a_000013_524c1f23>:
  40a5f0:	lea    r8,[rcx+0x60]
  40a5f4:	mov    rax,QWORD PTR [r8]
  40a5f7:	mov    r9,rax
  40a5fa:	nop    WORD PTR [rax+rax*1+0x0]
  40a600:	mov    QWORD PTR [rdx],r9
  40a603:	mov    rax,r9
  40a606:	lock cmpxchg QWORD PTR [r8],rdx
  40a60b:	cmp    rax,r9
  40a60e:	jne    40a677 <__swc_fn_fc36583a_000013_524c1f23+0x87>
  40a610:	mov    eax,DWORD PTR [rcx+0x6c]
  40a613:	test   eax,eax
  40a615:	je     40a676 <__swc_fn_fc36583a_000013_524c1f23+0x86>
  40a617:	lea    rdx,[rcx+0x70]
  40a61b:	mov    r9d,0x1
  40a621:	xor    eax,eax
  40a623:	lock cmpxchg DWORD PTR [rdx],r9d
  40a628:	test   eax,eax
  40a62a:	jne    40a676 <__swc_fn_fc36583a_000013_524c1f23+0x86>
  40a62c:	mov    rax,rcx
  40a62f:	and    rax,0xffffffffffc00000
  40a636:	mov    rax,QWORD PTR [rax+0x8]
  40a63a:	test   rax,rax
  40a63d:	jne    40a645 <__swc_fn_fc36583a_000013_524c1f23+0x55>
  40a63f:	xor    eax,eax
  40a641:	xchg   DWORD PTR [rdx],eax
  40a643:	jmp    40a676 <__swc_fn_fc36583a_000013_524c1f23+0x86>
  40a645:	lea    rdx,[rax+0x2a80]
  40a64c:	mov    rax,QWORD PTR [rdx]
  40a64f:	mov    r8,rax
  40a652:	cs nop WORD PTR [rax+rax*1+0x0]
  40a65c:	nop    DWORD PTR [rax+0x0]
  40a660:	mov    QWORD PTR [rcx+0x78],r8
  40a664:	mov    rax,r8
  40a667:	lock cmpxchg QWORD PTR [rdx],rcx
  40a66c:	cmp    rax,r8
  40a66f:	je     40a676 <__swc_fn_fc36583a_000013_524c1f23+0x86>
  40a671:	mov    r8,rax
  40a674:	jmp    40a660 <__swc_fn_fc36583a_000013_524c1f23+0x70>
  40a676:	ret
  40a677:	mov    r9,rax
  40a67a:	jmp    40a600 <__swc_fn_fc36583a_000013_524c1f23+0x10>
	...

000000000040a680 <__swc_fn_fc36583a_000016_efc44797>:
  40a680:	push   rsi
  40a681:	push   rdi
  40a682:	push   r12
  40a684:	push   r13
  40a686:	push   r14
  40a688:	push   r15
  40a68a:	push   rbx
  40a68b:	sub    rsp,0x30
  40a68f:	mov    QWORD PTR [rsp+0x18],r8
  40a694:	mov    rsi,rcx
  40a697:	mov    rdi,rdx
  40a69a:	mov    rdx,QWORD PTR [rsi+0x40]
  40a69e:	xchg   ax,ax
  40a6a0:	mov    rax,rdx
  40a6a3:	not    rax
  40a6a6:	and    rax,QWORD PTR [rsi+0x20]
  40a6aa:	test   rax,rax
  40a6ad:	jne    40a6c1 <__swc_fn_fc36583a_000016_efc44797+0x41>
  40a6af:	xor    eax,eax
  40a6b1:	add    rsp,0x30
  40a6b5:	pop    rbx
  40a6b6:	pop    r15
  40a6b8:	pop    r14
  40a6ba:	pop    r13
  40a6bc:	pop    r12
  40a6be:	pop    rdi
  40a6bf:	pop    rsi
  40a6c0:	ret
  40a6c1:	xor    ecx,ecx
  40a6c3:	tzcnt  rcx,rax
  40a6c8:	lea    r12,[rsp+0x8]
  40a6cd:	mov    DWORD PTR [rsp+0x8],ecx
  40a6d1:	mov    r13d,0x1
  40a6d7:	shl    r13,cl
  40a6da:	mov    rcx,rdx
  40a6dd:	or     rcx,r13
  40a6e0:	mov    rax,rdx
  40a6e3:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40a6e9:	cmp    rax,rdx
  40a6ec:	je     40a6f3 <__swc_fn_fc36583a_000016_efc44797+0x73>
  40a6ee:	mov    rdx,rax
  40a6f1:	jmp    40a6a0 <__swc_fn_fc36583a_000016_efc44797+0x20>
  40a6f3:	mov    eax,DWORD PTR [r12]
  40a6f7:	shl    rax,0x4
  40a6fb:	lea    r14,[rsi+rax*8+0x80]
  40a703:	mov    rcx,rsi
  40a706:	mov    rax,r12
  40a709:	mov    edx,DWORD PTR [rax]
  40a70b:	call   40e050 <__swc_fn_fc36583a_000014_9dea5065>
  40a710:	mov    r15,rax
  40a713:	mov    rcx,rsi
  40a716:	mov    rdx,r13
  40a719:	call   40e1b0 <__swc_fn_fc36583a_000020_fd2b165c>
  40a71e:	test   al,al
  40a720:	je     40a758 <__swc_fn_fc36583a_000016_efc44797+0xd8>
  40a722:	mov    ecx,DWORD PTR [r14+0x3c]
  40a726:	lea    rdx,[rip+0x19963]        # 424090 <__swc_bss_base_fc36583a+0x50>
  40a72d:	mov    r8,QWORD PTR [rip+0x1995c]        # 424090 <__swc_bss_base_fc36583a+0x50>
  40a734:	cs nop WORD PTR [rax+rax*1+0x0]
  40a73e:	xchg   ax,ax
  40a740:	mov    r9,r8
  40a743:	sub    r9,rcx
  40a746:	mov    rax,r8
  40a749:	lock cmpxchg QWORD PTR [rdx],r9
  40a74e:	cmp    rax,r8
  40a751:	je     40a7b9 <__swc_fn_fc36583a_000016_efc44797+0x139>
  40a753:	mov    r8,rax
  40a756:	jmp    40a740 <__swc_fn_fc36583a_000016_efc44797+0xc0>
  40a758:	mov    rcx,rsi
  40a75b:	mov    rax,r12
  40a75e:	mov    edx,DWORD PTR [rax]
  40a760:	call   4074f0 <__swc_fn_fc36583a_000015_9afb7cfb>
  40a765:	mov    rcx,r15
  40a768:	and    rcx,0xffffffffffff0000
  40a76f:	lea    rcx,[rcx+0x10000]
  40a776:	mov    rbx,rax
  40a779:	cmp    rax,rcx
  40a77c:	cmova  rbx,rcx
  40a780:	mov    rax,rbx
  40a783:	sub    rax,r15
  40a786:	mov    rcx,r15
  40a789:	mov    rdx,rax
  40a78c:	call   407340 <__swc_fn_fc36583a_000006_f7acedb0>
  40a791:	test   al,al
  40a793:	jne    40a7b2 <__swc_fn_fc36583a_000016_efc44797+0x132>
  40a795:	mov    rcx,rsi
  40a798:	mov    rdx,r13
  40a79b:	call   4076a0 <__swc_fn_fc36583a_000021_c8f5f27c>
  40a7a0:	xor    eax,eax
  40a7a2:	add    rsp,0x30
  40a7a6:	pop    rbx
  40a7a7:	pop    r15
  40a7a9:	pop    r14
  40a7ab:	pop    r13
  40a7ad:	pop    r12
  40a7af:	pop    rdi
  40a7b0:	pop    rsi
  40a7b1:	ret
  40a7b2:	sub    rbx,r15
  40a7b5:	mov    DWORD PTR [r14+0x3c],ebx
  40a7b9:	mov    rcx,r14
  40a7bc:	mov    rdx,rsi
  40a7bf:	mov    r8d,DWORD PTR [r12]
  40a7c3:	mov    r9d,edi
  40a7c6:	mov    rbx,QWORD PTR [rsp+0x18]
  40a7cb:	mov    r10d,ebx
  40a7ce:	call   40a520 <__swc_fn_fc36583a_000007_d64b2baa>
  40a7d3:	mov    rax,r14
  40a7d6:	add    rsp,0x30
  40a7da:	pop    rbx
  40a7db:	pop    r15
  40a7dd:	pop    r14
  40a7df:	pop    r13
  40a7e1:	pop    r12
  40a7e3:	pop    rdi
  40a7e4:	pop    rsi
  40a7e5:	ret
	...

000000000040a7f0 <__swc_fn_fc36583a_000019_de02dbdf>:
  40a7f0:	mov    r8,QWORD PTR [rcx+0x48]
  40a7f4:	cs nop WORD PTR [rax+rax*1+0x0]
  40a7fe:	xchg   ax,ax
  40a800:	mov    r9,r8
  40a803:	or     r9,rdx
  40a806:	mov    rax,r8
  40a809:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40a80f:	cmp    rax,r8
  40a812:	jne    40a815 <__swc_fn_fc36583a_000019_de02dbdf+0x25>
  40a814:	ret
  40a815:	mov    r8,rax
  40a818:	jmp    40a800 <__swc_fn_fc36583a_000019_de02dbdf+0x10>
  40a81a:	add    BYTE PTR [rax],al
  40a81c:	add    BYTE PTR [rax],al
	...

000000000040a820 <__swc_fn_fc36583a_000022_2d0fcd2c>:
  40a820:	push   rsi
  40a821:	push   rdi
  40a822:	push   r12
  40a824:	mov    rsi,rcx
  40a827:	xor    edi,edi
  40a829:	lea    r12,[rip+0x19870]        # 4240a0 <__swc_bss_base_fc36583a+0x60>
  40a830:	mov    eax,DWORD PTR [r12]
  40a834:	xor    ecx,ecx
  40a836:	test   rax,rax
  40a839:	jbe    40a874 <__swc_fn_fc36583a_000022_2d0fcd2c+0x54>
  40a83b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a840:	lea    rdx,[rip+0x19861]        # 4240a8 <__swc_bss_base_fc36583a+0x68>
  40a847:	mov    r8d,ecx
  40a84a:	lea    r8,[r8+r8*2]
  40a84e:	lea    r8,[rdx+r8*8]
  40a852:	mov    rdx,QWORD PTR [r8+0x10]
  40a856:	add    rdx,0x400000
  40a85d:	cmp    rdx,0x40000000
  40a864:	ja     40a86b <__swc_fn_fc36583a_000022_2d0fcd2c+0x4b>
  40a866:	mov    rdi,r8
  40a869:	jmp    40a874 <__swc_fn_fc36583a_000022_2d0fcd2c+0x54>
  40a86b:	add    rcx,0x1
  40a86f:	cmp    rcx,rax
  40a872:	jb     40a840 <__swc_fn_fc36583a_000022_2d0fcd2c+0x20>
  40a874:	test   rdi,rdi
  40a877:	jne    40a903 <__swc_fn_fc36583a_000022_2d0fcd2c+0xe3>
  40a87d:	cmp    DWORD PTR [r12],0x10
  40a882:	jae    40a8eb <__swc_fn_fc36583a_000022_2d0fcd2c+0xcb>
  40a884:	mov    ecx,0x40400000
  40a889:	call   40df70 <__swc_fn_fc36583a_000005_81d2e1e9>
  40a88e:	test   rax,rax
  40a891:	je     40a8eb <__swc_fn_fc36583a_000022_2d0fcd2c+0xcb>
  40a893:	lea    rcx,[rip+0x1980e]        # 4240a8 <__swc_bss_base_fc36583a+0x68>
  40a89a:	mov    edx,DWORD PTR [r12]
  40a89e:	lea    rdx,[rdx+rdx*2]
  40a8a2:	lea    rdx,[rcx+rdx*8]
  40a8a6:	mov    QWORD PTR [rdx],rax
  40a8a9:	lea    rax,[rax+0x3fffff]
  40a8b0:	and    rax,0xffffffffffc00000
  40a8b7:	mov    QWORD PTR [rdx+0x8],rax
  40a8bb:	mov    QWORD PTR [rdx+0x10],0x0
  40a8c3:	mov    edx,DWORD PTR [rip+0x197d7]        # 4240a0 <__swc_bss_base_fc36583a+0x60>
  40a8c9:	nop    DWORD PTR [rax+0x0]
  40a8d0:	lea    r9d,[rdx+0x1]
  40a8d4:	mov    rax,rdx
  40a8d7:	lock cmpxchg DWORD PTR [r12],r9d
  40a8dd:	mov    r8d,eax
  40a8e0:	cmp    eax,edx
  40a8e2:	je     40a8f2 <__swc_fn_fc36583a_000022_2d0fcd2c+0xd2>
  40a8e4:	mov    rdx,r8
  40a8e7:	jmp    40a8d0 <__swc_fn_fc36583a_000022_2d0fcd2c+0xb0>
  40a8e9:	jmp    40a8f2 <__swc_fn_fc36583a_000022_2d0fcd2c+0xd2>
  40a8eb:	xor    eax,eax
  40a8ed:	pop    r12
  40a8ef:	pop    rdi
  40a8f0:	pop    rsi
  40a8f1:	ret
  40a8f2:	mov    eax,DWORD PTR [rip+0x197a8]        # 4240a0 <__swc_bss_base_fc36583a+0x60>
  40a8f8:	sub    eax,0x1
  40a8fb:	lea    rdi,[rax+rax*2]
  40a8ff:	lea    rdi,[rcx+rdi*8]
  40a903:	mov    r12,QWORD PTR [rdi+0x8]
  40a907:	add    r12,QWORD PTR [rdi+0x10]
  40a90b:	mov    rcx,r12
  40a90e:	mov    edx,0x3000
  40a913:	call   407340 <__swc_fn_fc36583a_000006_f7acedb0>
  40a918:	test   al,al
  40a91a:	jne    40a923 <__swc_fn_fc36583a_000022_2d0fcd2c+0x103>
  40a91c:	xor    eax,eax
  40a91e:	pop    r12
  40a920:	pop    rdi
  40a921:	pop    rsi
  40a922:	ret
  40a923:	vxorps xmm0,xmm0,xmm0
  40a927:	xor    eax,eax
  40a929:	cs nop WORD PTR [rax+rax*1+0x0]
  40a933:	cs nop WORD PTR [rax+rax*1+0x0]
  40a93d:	nop    DWORD PTR [rax]
  40a940:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40a946:	add    rax,0x10
  40a94a:	cmp    rax,0x3000
  40a951:	jne    40a940 <__swc_fn_fc36583a_000022_2d0fcd2c+0x120>
  40a953:	mov    DWORD PTR [r12+0x28],esi
  40a958:	mov    eax,0x40
  40a95d:	mov    ecx,esi
  40a95f:	shr    eax,cl
  40a961:	mov    DWORD PTR [r12+0x2c],eax
  40a966:	cmp    DWORD PTR [r12+0x2c],0x40
  40a96c:	jb     40a977 <__swc_fn_fc36583a_000022_2d0fcd2c+0x157>
  40a96e:	mov    rax,0xffffffffffffffff
  40a975:	jmp    40a987 <__swc_fn_fc36583a_000022_2d0fcd2c+0x167>
  40a977:	mov    eax,0x1
  40a97c:	mov    ecx,DWORD PTR [r12+0x2c]
  40a981:	shl    rax,cl
  40a984:	dec    rax
  40a987:	mov    QWORD PTR [r12+0x20],rax
  40a98c:	mov    DWORD PTR [r12],0x4e540001
  40a994:	mov    DWORD PTR [r12+0x4],0x53474d45
  40a99d:	add    QWORD PTR [rdi+0x10],0x400000
  40a9a5:	mov    rax,r12
  40a9a8:	pop    r12
  40a9aa:	pop    rdi
  40a9ab:	pop    rsi
  40a9ac:	ret
  40a9ad:	add    BYTE PTR [rax],al
	...

000000000040a9b0 <__swc_fn_fc36583a_000025_bcdc5519>:
  40a9b0:	mov    eax,0x1
  40a9b5:	mov    edx,DWORD PTR [rip+0x196e5]        # 4240a0 <__swc_bss_base_fc36583a+0x60>
  40a9bb:	cmp    eax,edx
  40a9bd:	jae    40aa0b <__swc_fn_fc36583a_000025_bcdc5519+0x5b>
  40a9bf:	nop
  40a9c0:	lea    r8,[rip+0x196e1]        # 4240a8 <__swc_bss_base_fc36583a+0x68>
  40a9c7:	lea    r9,[rax+rax*2]
  40a9cb:	lea    r9,[r8+r9*8]
  40a9cf:	mov    r8,rcx
  40a9d2:	sub    r8,QWORD PTR [r9+0x8]
  40a9d6:	mov    r9,QWORD PTR [r9+0x10]
  40a9da:	cmp    r8,r9
  40a9dd:	jae    40aa05 <__swc_fn_fc36583a_000025_bcdc5519+0x55>
  40a9df:	mov    rax,rcx
  40a9e2:	and    rax,0xffffffffffc00000
  40a9e9:	shr    rcx,0x10
  40a9ed:	and    ecx,0x3f
  40a9f0:	mov    edx,DWORD PTR [rax+0x28]
  40a9f3:	shrx   ecx,ecx,edx
  40a9f8:	shl    rcx,0x4
  40a9fc:	lea    rax,[rax+rcx*8+0x80]
  40aa04:	ret
  40aa05:	inc    eax
  40aa07:	cmp    eax,edx
  40aa09:	jb     40a9c0 <__swc_fn_fc36583a_000025_bcdc5519+0x10>
  40aa0b:	xor    eax,eax
  40aa0d:	ret
	...

000000000040aa10 <__swc_fn_fc36583a_000028_9798fb47>:
  40aa10:	vxorps xmm0,xmm0,xmm0
  40aa14:	vmovups XMMWORD PTR [rcx],xmm0
  40aa18:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40aa1d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40aa22:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40aa27:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40aa2c:	mov    QWORD PTR [rcx+0x50],0x0
  40aa34:	ret
	...

000000000040aa40 <__swc_fn_fc36583a_000031_9798fb47>:
  40aa40:	vxorps xmm0,xmm0,xmm0
  40aa44:	xor    eax,eax
  40aa46:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa50:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa5a:	nop    WORD PTR [rax+rax*1+0x0]
  40aa60:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40aa65:	add    rax,0x10
  40aa69:	cmp    rax,0x9b0
  40aa70:	jne    40aa60 <__swc_fn_fc36583a_000031_9798fb47+0x20>
  40aa72:	mov    QWORD PTR [rcx+0x9b0],0x0
  40aa7d:	ret
	...

000000000040aa80 <__swc_fn_fc36583a_000034_cd1a4e8c>:
  40aa80:	push   rsi
  40aa81:	push   rdi
  40aa82:	sub    rsp,0x8
  40aa86:	lea    rsi,[rip+0x17583]        # 422010 <__swc_data_base_fc36583a+0x10>
  40aa8d:	mov    rax,QWORD PTR [rsi]
  40aa90:	mov    ecx,0xffffffff
  40aa95:	cmp    rax,rcx
  40aa98:	je     40aaa1 <__swc_fn_fc36583a_000034_cd1a4e8c+0x21>
  40aa9a:	add    rsp,0x8
  40aa9e:	pop    rdi
  40aa9f:	pop    rsi
  40aaa0:	ret
  40aaa1:	mov    rcx,QWORD PTR [rip+0x85d8]        # 413080 <__swc_fn_fc36583a_000176_cf4ffedd+0xfa0>
  40aaa8:	call   4096f0 <__swc_fn_fc36583a_000129_4a82cdf6>
  40aaad:	mov    rcx,rax
  40aab0:	mov    eax,0xffffffff
  40aab5:	lock cmpxchg QWORD PTR [rsi],rcx
  40aaba:	mov    rdi,rax
  40aabd:	mov    eax,0xffffffff
  40aac2:	cmp    rdi,rax
  40aac5:	je     40aad6 <__swc_fn_fc36583a_000034_cd1a4e8c+0x56>
  40aac7:	call   40ccb0 <__swc_fn_fc36583a_000130_a611b8c4>
  40aacc:	mov    rax,rdi
  40aacf:	add    rsp,0x8
  40aad3:	pop    rdi
  40aad4:	pop    rsi
  40aad5:	ret
  40aad6:	mov    rax,rcx
  40aad9:	add    rsp,0x8
  40aadd:	pop    rdi
  40aade:	pop    rsi
  40aadf:	ret

000000000040aae0 <__swc_fn_fc36583a_000037_14f56618>:
  40aae0:	sub    rsp,0x8
  40aae4:	vxorps xmm0,xmm0,xmm0
  40aae8:	xor    eax,eax
  40aaea:	cs nop WORD PTR [rax+rax*1+0x0]
  40aaf4:	cs nop WORD PTR [rax+rax*1+0x0]
  40aafe:	xchg   ax,ax
  40ab00:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40ab05:	add    rax,0x10
  40ab09:	cmp    rax,0x2b00
  40ab10:	jne    40ab00 <__swc_fn_fc36583a_000037_14f56618+0x20>
  40ab12:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40ab1c:	xor    al,al
  40ab1e:	mov    rdx,rax
  40ab21:	xor    al,al
  40ab23:	mov    r8,rax
  40ab26:	xor    al,al
  40ab28:	mov    r9,rax
  40ab2b:	xor    al,al
  40ab2d:	mov    r10,rax
  40ab30:	xor    al,al
  40ab32:	mov    r11,rax
  40ab35:	call   40e3f0 <__swc_fn_fc36583a_000038_03f1bf9a>
  40ab3a:	add    rsp,0x8
  40ab3e:	ret
	...

000000000040ab40 <__swc_fn_fc36583a_000040_c90d80c1>:
  40ab40:	push   rsi
  40ab41:	push   rdi
  40ab42:	push   r12
  40ab44:	mov    rsi,r8
  40ab47:	mov    rdi,rdx
  40ab4a:	mov    rcx,rdx
  40ab4d:	call   40df70 <__swc_fn_fc36583a_000005_81d2e1e9>
  40ab52:	mov    r12,rax
  40ab55:	test   rax,rax
  40ab58:	jne    40ab61 <__swc_fn_fc36583a_000040_c90d80c1+0x21>
  40ab5a:	xor    eax,eax
  40ab5c:	pop    r12
  40ab5e:	pop    rdi
  40ab5f:	pop    rsi
  40ab60:	ret
  40ab61:	mov    rcx,r12
  40ab64:	mov    rdx,rsi
  40ab67:	call   407340 <__swc_fn_fc36583a_000006_f7acedb0>
  40ab6c:	test   al,al
  40ab6e:	jne    40ab82 <__swc_fn_fc36583a_000040_c90d80c1+0x42>
  40ab70:	mov    rcx,r12
  40ab73:	mov    rdx,rdi
  40ab76:	call   4101f0 <__swc_fn_fc36583a_000116_ed2d8fed>
  40ab7b:	xor    eax,eax
  40ab7d:	pop    r12
  40ab7f:	pop    rdi
  40ab80:	pop    rsi
  40ab81:	ret
  40ab82:	mov    rax,r12
  40ab85:	pop    r12
  40ab87:	pop    rdi
  40ab88:	pop    rsi
  40ab89:	ret
	...

000000000040aba0 <__swc_fn_fc36583a_000043_a78ae66b>:
  40aba0:	push   rsi
  40aba1:	push   rdi
  40aba2:	push   r12
  40aba4:	mov    rsi,rcx
  40aba7:	mov    edx,0x9b8
  40abac:	call   40e460 <__swc_fn_fc36583a_000041_facd3e17>
  40abb1:	mov    rdi,rax
  40abb4:	test   rax,rax
  40abb7:	jne    40abc0 <__swc_fn_fc36583a_000043_a78ae66b+0x20>
  40abb9:	xor    eax,eax
  40abbb:	pop    r12
  40abbd:	pop    rdi
  40abbe:	pop    rsi
  40abbf:	ret
  40abc0:	vxorps xmm0,xmm0,xmm0
  40abc4:	xor    eax,eax
  40abc6:	cs nop WORD PTR [rax+rax*1+0x0]
  40abd0:	cs nop WORD PTR [rax+rax*1+0x0]
  40abda:	nop    WORD PTR [rax+rax*1+0x0]
  40abe0:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40abe5:	add    rax,0x10
  40abe9:	cmp    rax,0x9b0
  40abf0:	jne    40abe0 <__swc_fn_fc36583a_000043_a78ae66b+0x40>
  40abf2:	mov    QWORD PTR [rdi+0x9b0],0x0
  40abfd:	mov    QWORD PTR [rdi],rsi
  40ac00:	call   40cd60 <__swc_fn_fc36583a_000133_a9c1c700>
  40ac05:	mov    QWORD PTR [rdi+0x18],rax
  40ac09:	lea    r12,[rsi+0x10]
  40ac0d:	mov    rcx,r12
  40ac10:	call   409940 <__swc_fn_fc36583a_000138_86bb0f90>
  40ac15:	mov    rax,QWORD PTR [rsi+0x20]
  40ac19:	mov    QWORD PTR [rdi+0x8],rax
  40ac1d:	mov    rax,QWORD PTR [rsi+0x20]
  40ac21:	test   rax,rax
  40ac24:	je     40ac2a <__swc_fn_fc36583a_000043_a78ae66b+0x8a>
  40ac26:	mov    QWORD PTR [rax+0x10],rdi
  40ac2a:	mov    QWORD PTR [rsi+0x20],rdi
  40ac2e:	mov    rcx,r12
  40ac31:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  40ac36:	mov    rax,rdi
  40ac39:	pop    r12
  40ac3b:	pop    rdi
  40ac3c:	pop    rsi
  40ac3d:	ret
	...

000000000040ac40 <__swc_fn_fc36583a_000046_6e7a8d58>:
  40ac40:	mov    rax,QWORD PTR [rdx+0x10]
  40ac44:	test   rax,rax
  40ac47:	je     40ac53 <__swc_fn_fc36583a_000046_6e7a8d58+0x13>
  40ac49:	mov    rcx,QWORD PTR [rdx+0x8]
  40ac4d:	mov    QWORD PTR [rax+0x8],rcx
  40ac51:	jmp    40ac5b <__swc_fn_fc36583a_000046_6e7a8d58+0x1b>
  40ac53:	mov    rax,QWORD PTR [rdx+0x8]
  40ac57:	mov    QWORD PTR [rcx+0x20],rax
  40ac5b:	mov    rax,QWORD PTR [rdx+0x8]
  40ac5f:	test   rax,rax
  40ac62:	je     40ac6c <__swc_fn_fc36583a_000046_6e7a8d58+0x2c>
  40ac64:	mov    rcx,QWORD PTR [rdx+0x10]
  40ac68:	mov    QWORD PTR [rax+0x10],rcx
  40ac6c:	vxorps xmm0,xmm0,xmm0
  40ac70:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40ac75:	ret
	...

000000000040ac80 <__swc_fn_fc36583a_000049_129b9bf4>:
  40ac80:	sub    rsp,0x8
  40ac84:	mov    r9,r8
  40ac87:	mov    r10,rdx
  40ac8a:	call   40e510 <__swc_fn_fc36583a_000047_137687bb>
  40ac8f:	mov    eax,0x1
  40ac94:	xchg   DWORD PTR [r9+0x6c],eax
  40ac98:	mov    rax,QWORD PTR [r9+0x60]
  40ac9c:	test   rax,rax
  40ac9f:	je     40ace3 <__swc_fn_fc36583a_000049_129b9bf4+0x63>
  40aca1:	xor    eax,eax
  40aca3:	xchg   DWORD PTR [r9+0x6c],eax
  40aca7:	movzx  eax,BYTE PTR [r9+0x39]
  40acac:	lea    rax,[rax+rax*4]
  40acb0:	lea    rax,[r10+rax*8+0x28]
  40acb5:	mov    QWORD PTR [r9+0x50],0x0
  40acbd:	mov    rcx,QWORD PTR [rax+0x8]
  40acc1:	mov    QWORD PTR [r9+0x48],rcx
  40acc5:	mov    rcx,QWORD PTR [rax+0x8]
  40acc9:	test   rcx,rcx
  40accc:	je     40acd4 <__swc_fn_fc36583a_000049_129b9bf4+0x54>
  40acce:	mov    QWORD PTR [rcx+0x50],r9
  40acd2:	jmp    40acd8 <__swc_fn_fc36583a_000049_129b9bf4+0x58>
  40acd4:	mov    QWORD PTR [rax+0x10],r9
  40acd8:	mov    QWORD PTR [rax+0x8],r9
  40acdc:	xor    eax,eax
  40acde:	add    rsp,0x8
  40ace2:	ret
  40ace3:	movzx  eax,BYTE PTR [r9+0x39]
  40ace8:	lea    rax,[rax+rax*4]
  40acec:	lea    rax,[r10+rax*8+0x28]
  40acf1:	mov    QWORD PTR [r9+0x50],0x0
  40acf9:	mov    rcx,QWORD PTR [rax+0x18]
  40acfd:	mov    QWORD PTR [r9+0x48],rcx
  40ad01:	mov    rcx,QWORD PTR [rax+0x18]
  40ad05:	test   rcx,rcx
  40ad08:	je     40ad0e <__swc_fn_fc36583a_000049_129b9bf4+0x8e>
  40ad0a:	mov    QWORD PTR [rcx+0x50],r9
  40ad0e:	mov    QWORD PTR [rax+0x18],r9
  40ad12:	mov    eax,0x1
  40ad17:	add    rsp,0x8
  40ad1b:	ret
  40ad1c:	add    BYTE PTR [rax],al
	...

000000000040ad20 <__swc_fn_fc36583a_000052_3af34d7f>:
  40ad20:	push   r12
  40ad22:	push   r13
  40ad24:	push   rdi
  40ad25:	push   rsi
  40ad26:	push   r14
  40ad28:	push   r15
  40ad2a:	sub    rsp,0x178
  40ad31:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40ad3a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40ad43:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40ad4c:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40ad55:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40ad5e:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40ad67:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40ad70:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40ad79:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40ad82:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40ad8b:	mov    r12,rcx
  40ad8e:	lea    rax,[rip+0x194a3]        # 424238 <__swc_bss_base_fc36583a+0x1f8>
  40ad95:	mov    rcx,QWORD PTR [rax]
  40ad98:	mov    r13,rcx
  40ad9b:	test   rcx,rcx
  40ad9e:	jne    40adae <__swc_fn_fc36583a_000052_3af34d7f+0x8e>
  40ada0:	mov    r13d,0x1dcd6500
  40ada6:	mov    ecx,0x1dcd6500
  40adab:	xchg   QWORD PTR [rax],rcx
  40adae:	lea    rax,[rip+0x17253]        # 422008 <__swc_data_base_fc36583a+0x8>
  40adb5:	mov    rax,QWORD PTR [rax]
  40adb8:	cmp    rax,0xffffffffffffffff
  40adbc:	je     40adcb <__swc_fn_fc36583a_000052_3af34d7f+0xab>
  40adbe:	mov    eax,eax
  40adc0:	mov    edi,eax
  40adc2:	xor    eax,eax
  40adc4:	call   407000 <pthread_getspecific@plt>
  40adc9:	jmp    40adcd <__swc_fn_fc36583a_000052_3af34d7f+0xad>
  40adcb:	xor    eax,eax
  40adcd:	test   rax,rax
  40add0:	jne    40addf <__swc_fn_fc36583a_000052_3af34d7f+0xbf>
  40add2:	call   40aa80 <__swc_fn_fc36583a_000034_cd1a4e8c>
  40add7:	mov    rcx,rax
  40adda:	call   410540 <__swc_fn_fc36583a_000131_5f757033>
  40addf:	test   rax,rax
  40ade2:	je     40adf4 <__swc_fn_fc36583a_000052_3af34d7f+0xd4>
  40ade4:	cmp    QWORD PTR [rax],r12
  40ade7:	jne    40adf4 <__swc_fn_fc36583a_000052_3af34d7f+0xd4>
  40ade9:	cmp    DWORD PTR [rax+0x20],0x0
  40aded:	jne    40adf4 <__swc_fn_fc36583a_000052_3af34d7f+0xd4>
  40adef:	mov    rsi,rax
  40adf2:	jmp    40adf6 <__swc_fn_fc36583a_000052_3af34d7f+0xd6>
  40adf4:	xor    esi,esi
  40adf6:	lea    rdi,[r12+0x2a88]
  40adfe:	mov    r14,QWORD PTR [rdi]
  40ae01:	test   r14,r14
  40ae04:	jne    40ae53 <__swc_fn_fc36583a_000052_3af34d7f+0x133>
  40ae06:	lea    rax,[rip+0x19283]        # 424090 <__swc_bss_base_fc36583a+0x50>
  40ae0d:	mov    rax,QWORD PTR [rax]
  40ae10:	test   rax,rax
  40ae13:	setne  al
  40ae16:	jne    40ae3a <__swc_fn_fc36583a_000052_3af34d7f+0x11a>
  40ae18:	mov    rax,QWORD PTR [r12+0x2a70]
  40ae20:	test   rax,rax
  40ae23:	setne  al
  40ae26:	jne    40ae3a <__swc_fn_fc36583a_000052_3af34d7f+0x11a>
  40ae28:	test   rsi,rsi
  40ae2b:	setne  al
  40ae2e:	je     40ae3a <__swc_fn_fc36583a_000052_3af34d7f+0x11a>
  40ae30:	cmp    DWORD PTR [rsi+0x730],0x0
  40ae37:	setne  al
  40ae3a:	test   al,al
  40ae3c:	je     40ae4e <__swc_fn_fc36583a_000052_3af34d7f+0x12e>
  40ae3e:	call   4105f0 <__swc_fn_fc36583a_000134_07d76562>
  40ae43:	lea    rcx,[rax+r13*1]
  40ae47:	xor    eax,eax
  40ae49:	lock cmpxchg QWORD PTR [rdi],rcx
  40ae4e:	jmp    40af53 <__swc_fn_fc36583a_000052_3af34d7f+0x233>
  40ae53:	call   4105f0 <__swc_fn_fc36583a_000134_07d76562>
  40ae58:	mov    r15,rax
  40ae5b:	cmp    rax,r14
  40ae5e:	jb     40ae6f <__swc_fn_fc36583a_000052_3af34d7f+0x14f>
  40ae60:	xor    ecx,ecx
  40ae62:	mov    rax,r14
  40ae65:	lock cmpxchg QWORD PTR [rdi],rcx
  40ae6a:	cmp    rax,r14
  40ae6d:	je     40ae74 <__swc_fn_fc36583a_000052_3af34d7f+0x154>
  40ae6f:	jmp    40af53 <__swc_fn_fc36583a_000052_3af34d7f+0x233>
  40ae74:	test   rsi,rsi
  40ae77:	je     40ae92 <__swc_fn_fc36583a_000052_3af34d7f+0x172>
  40ae79:	cmp    r15,r13
  40ae7c:	jb     40ae92 <__swc_fn_fc36583a_000052_3af34d7f+0x172>
  40ae7e:	mov    rax,r15
  40ae81:	sub    rax,r13
  40ae84:	mov    rcx,r12
  40ae87:	mov    rdx,rsi
  40ae8a:	mov    r8,rax
  40ae8d:	call   40e950 <__swc_fn_fc36583a_000062_dea90857>
  40ae92:	lea    rsi,[r12+0x10]
  40ae97:	mov    rcx,rsi
  40ae9a:	call   409940 <__swc_fn_fc36583a_000138_86bb0f90>
  40ae9f:	mov    rax,QWORD PTR [r12+0x18]
  40aea4:	mov    rdi,rax
  40aea7:	test   rdi,rdi
  40aeaa:	je     40aed4 <__swc_fn_fc36583a_000052_3af34d7f+0x1b4>
  40aeac:	cs nop WORD PTR [rax+rax*1+0x0]
  40aeb6:	cs nop WORD PTR [rax+rax*1+0x0]
  40aec0:	mov    rcx,rdi
  40aec3:	call   407510 <__swc_fn_fc36583a_000018_adca76cf>
  40aec8:	mov    rax,QWORD PTR [rdi+0x10]
  40aecc:	mov    rdi,rax
  40aecf:	test   rax,rax
  40aed2:	jne    40aec0 <__swc_fn_fc36583a_000052_3af34d7f+0x1a0>
  40aed4:	mov    rcx,rsi
  40aed7:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  40aedc:	mov    rcx,r12
  40aedf:	call   409940 <__swc_fn_fc36583a_000138_86bb0f90>
  40aee4:	xor    esi,esi
  40aee6:	cs nop WORD PTR [rax+rax*1+0x0]
  40aef0:	mov    rax,QWORD PTR [r12+0x2a70]
  40aef8:	cmp    rsi,rax
  40aefb:	jae    40af4b <__swc_fn_fc36583a_000052_3af34d7f+0x22b>
  40aefd:	lea    rax,[rsi+rsi*4]
  40af01:	lea    rax,[r12+rax*8+0x268]
  40af09:	mov    r8,QWORD PTR [rax]
  40af0c:	mov    r9,QWORD PTR [rax+0x8]
  40af10:	mov    r10,QWORD PTR [rax+0x10]
  40af14:	mov    rax,QWORD PTR [rax+0x20]
  40af18:	cmp    rax,r15
  40af1b:	jae    40af28 <__swc_fn_fc36583a_000052_3af34d7f+0x208>
  40af1d:	mov    rcx,r15
  40af20:	sub    rcx,rax
  40af23:	cmp    rcx,r13
  40af26:	jae    40af2d <__swc_fn_fc36583a_000052_3af34d7f+0x20d>
  40af28:	inc    rsi
  40af2b:	jmp    40aef0 <__swc_fn_fc36583a_000052_3af34d7f+0x1d0>
  40af2d:	mov    rcx,r12
  40af30:	mov    rdx,rsi
  40af33:	call   40e900 <__swc_fn_fc36583a_000059_15c28ca7>
  40af38:	mov    rcx,r12
  40af3b:	mov    rdx,r8
  40af3e:	mov    r8,r9
  40af41:	mov    r9,r10
  40af44:	call   4077f0 <__swc_fn_fc36583a_000042_d3c2ab54>
  40af49:	jmp    40aef0 <__swc_fn_fc36583a_000052_3af34d7f+0x1d0>
  40af4b:	mov    rcx,r12
  40af4e:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  40af53:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40af5c:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40af65:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40af6e:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40af77:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40af80:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40af89:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40af92:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40af9b:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40afa4:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40afad:	add    rsp,0x178
  40afb4:	pop    r15
  40afb6:	pop    r14
  40afb8:	pop    rsi
  40afb9:	pop    rdi
  40afba:	pop    r13
  40afbc:	pop    r12
  40afbe:	ret
	...

000000000040afc0 <__swc_fn_fc36583a_000055_df0696cd>:
  40afc0:	lea    rax,[rdx-0x58]
  40afc4:	ret
	...

000000000040afd0 <__swc_fn_fc36583a_000058_2ca0cb05>:
  40afd0:	push   rsi
  40afd1:	push   rdi
  40afd2:	push   r12
  40afd4:	push   r13
  40afd6:	sub    rsp,0x68
  40afda:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40afe0:	mov    rsi,r9
  40afe3:	mov    rdi,rcx
  40afe6:	mov    r12,rdx
  40afe9:	mov    r13,r8
  40afec:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40aff4:	jne    40b003 <__swc_fn_fc36583a_000058_2ca0cb05+0x33>
  40aff6:	xor    eax,eax
  40aff8:	add    rsp,0x68
  40affc:	pop    r13
  40affe:	pop    r12
  40b000:	pop    rdi
  40b001:	pop    rsi
  40b002:	ret
  40b003:	mov    rcx,rdi
  40b006:	call   409940 <__swc_fn_fc36583a_000138_86bb0f90>
  40b00b:	movabs rax,0x7fffffffffffffff
  40b015:	cmp    r12,rax
  40b018:	mov    rax,0xffffffffffffffff
  40b01f:	lea    rcx,[r12+r12*1]
  40b023:	cmovbe rax,rcx
  40b027:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40b02e:	mov    rdx,rcx
  40b031:	sub    rax,r12
  40b034:	inc    rax
  40b037:	xor    r8d,r8d
  40b03a:	test   rcx,rcx
  40b03d:	jbe    40b068 <__swc_fn_fc36583a_000058_2ca0cb05+0x98>
  40b03f:	nop
  40b040:	lea    r9,[r8+r8*4]
  40b044:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40b04c:	sub    r9,r12
  40b04f:	cmp    r9,rax
  40b052:	jae    40b05f <__swc_fn_fc36583a_000058_2ca0cb05+0x8f>
  40b054:	mov    rdx,r8
  40b057:	mov    rax,r9
  40b05a:	test   r9,r9
  40b05d:	je     40b068 <__swc_fn_fc36583a_000058_2ca0cb05+0x98>
  40b05f:	add    r8,0x1
  40b063:	cmp    r8,rcx
  40b066:	jb     40b040 <__swc_fn_fc36583a_000058_2ca0cb05+0x70>
  40b068:	mov    rax,QWORD PTR [rdi+0x2a70]
  40b06f:	cmp    rdx,rax
  40b072:	jne    40b08f <__swc_fn_fc36583a_000058_2ca0cb05+0xbf>
  40b074:	mov    rcx,rdi
  40b077:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  40b07c:	xor    eax,eax
  40b07e:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b084:	add    rsp,0x68
  40b088:	pop    r13
  40b08a:	pop    r12
  40b08c:	pop    rdi
  40b08d:	pop    rsi
  40b08e:	ret
  40b08f:	lea    rax,[rdx+rdx*4]
  40b093:	lea    rax,[rdi+rax*8+0x268]
  40b09b:	vmovups xmm6,XMMWORD PTR [rax]
  40b09f:	mov    r8,QWORD PTR [rax+0x10]
  40b0a3:	mov    rcx,rdi
  40b0a6:	call   40e900 <__swc_fn_fc36583a_000059_15c28ca7>
  40b0ab:	vpshufd xmm0,xmm6,0xee
  40b0b0:	vmovsd QWORD PTR [r13+0x0],xmm0
  40b0b6:	mov    QWORD PTR [rsi],r8
  40b0b9:	mov    rcx,rdi
  40b0bc:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  40b0c1:	vmovq  rax,xmm6
  40b0c6:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b0cc:	add    rsp,0x68
  40b0d0:	pop    r13
  40b0d2:	pop    r12
  40b0d4:	pop    rdi
  40b0d5:	pop    rsi
  40b0d6:	ret
	...

000000000040b0e0 <__swc_fn_fc36583a_000061_b304235a>:
  40b0e0:	push   r12
  40b0e2:	push   r13
  40b0e4:	push   r14
  40b0e6:	push   r15
  40b0e8:	push   rdi
  40b0e9:	push   rsi
  40b0ea:	sub    rsp,0x148
  40b0f1:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40b0fa:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40b103:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40b10c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40b115:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40b11e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40b127:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40b130:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40b139:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40b142:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40b14b:	mov    r12,r9
  40b14e:	mov    r13,rcx
  40b151:	mov    r14,rdx
  40b154:	mov    r15,r8
  40b157:	test   rdx,rdx
  40b15a:	jne    40b16e <__swc_fn_fc36583a_000061_b304235a+0x8e>
  40b15c:	add    rsp,0x148
  40b163:	pop    rsi
  40b164:	pop    rdi
  40b165:	pop    r15
  40b167:	pop    r14
  40b169:	pop    r13
  40b16b:	pop    r12
  40b16d:	ret
  40b16e:	cmp    r12,0x200000
  40b175:	ja     40b207 <__swc_fn_fc36583a_000061_b304235a+0x127>
  40b17b:	lea    rax,[rip+0x16e86]        # 422008 <__swc_data_base_fc36583a+0x8>
  40b182:	mov    rax,QWORD PTR [rax]
  40b185:	cmp    rax,0xffffffffffffffff
  40b189:	je     40b198 <__swc_fn_fc36583a_000061_b304235a+0xb8>
  40b18b:	mov    eax,eax
  40b18d:	mov    edi,eax
  40b18f:	xor    eax,eax
  40b191:	call   407000 <pthread_getspecific@plt>
  40b196:	jmp    40b19a <__swc_fn_fc36583a_000061_b304235a+0xba>
  40b198:	xor    eax,eax
  40b19a:	test   rax,rax
  40b19d:	je     40b1a4 <__swc_fn_fc36583a_000061_b304235a+0xc4>
  40b19f:	mov    rsi,rax
  40b1a2:	jmp    40b1b4 <__swc_fn_fc36583a_000061_b304235a+0xd4>
  40b1a4:	call   40aa80 <__swc_fn_fc36583a_000034_cd1a4e8c>
  40b1a9:	mov    rcx,rax
  40b1ac:	call   410540 <__swc_fn_fc36583a_000131_5f757033>
  40b1b1:	mov    rsi,rax
  40b1b4:	test   rsi,rsi
  40b1b7:	je     40b207 <__swc_fn_fc36583a_000061_b304235a+0x127>
  40b1b9:	cmp    QWORD PTR [rsi],r13
  40b1bc:	jne    40b207 <__swc_fn_fc36583a_000061_b304235a+0x127>
  40b1be:	cmp    DWORD PTR [rsi+0x20],0x0
  40b1c2:	jne    40b207 <__swc_fn_fc36583a_000061_b304235a+0x127>
  40b1c4:	cmp    DWORD PTR [rsi+0x730],0x10
  40b1cb:	jae    40b207 <__swc_fn_fc36583a_000061_b304235a+0x127>
  40b1cd:	mov    eax,DWORD PTR [rsi+0x730]
  40b1d3:	lea    rdi,[rax+rax*4]
  40b1d7:	lea    rdi,[rsi+rdi*8+0x738]
  40b1df:	mov    QWORD PTR [rdi],r14
  40b1e2:	mov    QWORD PTR [rdi+0x8],r15
  40b1e6:	mov    QWORD PTR [rdi+0x10],r12
  40b1ea:	mov    QWORD PTR [rdi+0x18],0x0
  40b1f2:	call   4105f0 <__swc_fn_fc36583a_000134_07d76562>
  40b1f7:	mov    QWORD PTR [rdi+0x20],rax
  40b1fb:	add    DWORD PTR [rsi+0x730],0x1
  40b202:	jmp    40b366 <__swc_fn_fc36583a_000061_b304235a+0x286>
  40b207:	mov    rcx,r13
  40b20a:	call   407f30 <__swc_fn_fc36583a_000060_ad030a10>
  40b20f:	mov    rsi,rax
  40b212:	cmp    r12,rax
  40b215:	jbe    40b24a <__swc_fn_fc36583a_000061_b304235a+0x16a>
  40b217:	cmp    r12,0x10000000
  40b21e:	seta   al
  40b221:	ja     40b230 <__swc_fn_fc36583a_000061_b304235a+0x150>
  40b223:	mov    rax,QWORD PTR [r13+0x2a70]
  40b22a:	test   rax,rax
  40b22d:	setne  al
  40b230:	test   al,al
  40b232:	je     40b24a <__swc_fn_fc36583a_000061_b304235a+0x16a>
  40b234:	mov    rcx,r13
  40b237:	mov    rdx,r14
  40b23a:	mov    r8,r15
  40b23d:	mov    r9,r12
  40b240:	call   4077f0 <__swc_fn_fc36583a_000042_d3c2ab54>
  40b245:	jmp    40b366 <__swc_fn_fc36583a_000061_b304235a+0x286>
  40b24a:	call   4105f0 <__swc_fn_fc36583a_000134_07d76562>
  40b24f:	mov    rdi,rax
  40b252:	mov    rcx,r13
  40b255:	call   409940 <__swc_fn_fc36583a_000138_86bb0f90>
  40b25a:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b262:	je     40b31a <__swc_fn_fc36583a_000061_b304235a+0x23a>
  40b268:	nop    DWORD PTR [rax+rax*1+0x0]
  40b270:	cmp    QWORD PTR [r13+0x2a70],0x100
  40b27b:	jae    40b290 <__swc_fn_fc36583a_000061_b304235a+0x1b0>
  40b27d:	mov    rax,QWORD PTR [r13+0x2a68]
  40b284:	add    rax,r12
  40b287:	cmp    rax,rsi
  40b28a:	jbe    40b31a <__swc_fn_fc36583a_000061_b304235a+0x23a>
  40b290:	xor    eax,eax
  40b292:	mov    rcx,QWORD PTR [r13+0x2a70]
  40b299:	mov    edx,0x1
  40b29e:	cmp    rcx,0x1
  40b2a2:	jbe    40b2d9 <__swc_fn_fc36583a_000061_b304235a+0x1f9>
  40b2a4:	cs nop WORD PTR [rax+rax*1+0x0]
  40b2ae:	xchg   ax,ax
  40b2b0:	lea    r8,[rdx+rdx*4]
  40b2b4:	lea    r8,[r13+r8*8+0x268]
  40b2bc:	lea    r9,[rax+rax*4]
  40b2c0:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40b2c8:	cmp    QWORD PTR [r8+0x18],r9
  40b2cc:	cmovb  rax,rdx
  40b2d0:	add    rdx,0x1
  40b2d4:	cmp    rdx,rcx
  40b2d7:	jb     40b2b0 <__swc_fn_fc36583a_000061_b304235a+0x1d0>
  40b2d9:	lea    rcx,[rax+rax*4]
  40b2dd:	lea    rcx,[r13+rcx*8+0x268]
  40b2e5:	mov    r8,QWORD PTR [rcx]
  40b2e8:	mov    r9,QWORD PTR [rcx+0x8]
  40b2ec:	mov    r10,QWORD PTR [rcx+0x10]
  40b2f0:	mov    rcx,r13
  40b2f3:	mov    rdx,rax
  40b2f6:	call   40e900 <__swc_fn_fc36583a_000059_15c28ca7>
  40b2fb:	mov    rcx,r13
  40b2fe:	mov    rdx,r8
  40b301:	mov    r8,r9
  40b304:	mov    r9,r10
  40b307:	call   4077f0 <__swc_fn_fc36583a_000042_d3c2ab54>
  40b30c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b314:	jne    40b270 <__swc_fn_fc36583a_000061_b304235a+0x190>
  40b31a:	add    QWORD PTR [r13+0x2a78],0x1
  40b322:	mov    rax,QWORD PTR [r13+0x2a70]
  40b329:	lea    rax,[rax+rax*4]
  40b32d:	lea    rax,[r13+rax*8+0x268]
  40b335:	mov    QWORD PTR [rax],r14
  40b338:	mov    QWORD PTR [rax+0x8],r15
  40b33c:	mov    QWORD PTR [rax+0x10],r12
  40b340:	mov    rcx,QWORD PTR [r13+0x2a78]
  40b347:	mov    QWORD PTR [rax+0x18],rcx
  40b34b:	mov    QWORD PTR [rax+0x20],rdi
  40b34f:	add    QWORD PTR [r13+0x2a68],r12
  40b356:	add    QWORD PTR [r13+0x2a70],0x1
  40b35e:	mov    rcx,r13
  40b361:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  40b366:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40b36f:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40b378:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40b381:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40b38a:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40b393:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40b39c:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40b3a5:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40b3ae:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40b3b7:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40b3c0:	add    rsp,0x148
  40b3c7:	pop    rsi
  40b3c8:	pop    rdi
  40b3c9:	pop    r15
  40b3cb:	pop    r14
  40b3cd:	pop    r13
  40b3cf:	pop    r12
  40b3d1:	ret
	...

000000000040b3e0 <__swc_fn_fc36583a_000064_d9ee99ea>:
  40b3e0:	push   rbx
  40b3e1:	push   r12
  40b3e3:	push   r13
  40b3e5:	push   r14
  40b3e7:	push   r15
  40b3e9:	push   rdi
  40b3ea:	push   rsi
  40b3eb:	sub    rsp,0xf0
  40b3f2:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40b3f8:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40b3fe:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40b404:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40b40a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40b413:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40b41c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40b425:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40b42e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40b437:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40b440:	mov    eax,r8d
  40b443:	mov    rbx,rcx
  40b446:	mov    r12,rdx
  40b449:	mov    QWORD PTR [rsp+0x18],rdx
  40b44e:	mov    ecx,DWORD PTR [r12+0x58]
  40b453:	mov    r13d,ecx
  40b456:	cmp    ecx,0x10
  40b459:	mov    ecx,0x10
  40b45e:	cmovb  r13d,ecx
  40b462:	test   r13d,r13d
  40b465:	mov    rcx,r13
  40b468:	mov    edx,0x8
  40b46d:	cmove  ecx,edx
  40b470:	dec    rcx
  40b473:	mov    rdx,0xffffffffffffffff
  40b47a:	sub    rdx,rcx
  40b47d:	xor    r14d,r14d
  40b480:	mov    r8,rcx
  40b483:	not    r8
  40b486:	lea    rcx,[rcx+0x58]
  40b48a:	and    rcx,r8
  40b48d:	cmp    rdx,0x58
  40b491:	cmovae r14,rcx
  40b495:	cmp    eax,0xffffffff
  40b498:	jne    40b4a1 <__swc_fn_fc36583a_000064_d9ee99ea+0xc1>
  40b49a:	mov    r15,QWORD PTR [r12+0x48]
  40b49f:	jmp    40b4d3 <__swc_fn_fc36583a_000064_d9ee99ea+0xf3>
  40b4a1:	test   eax,eax
  40b4a3:	jne    40b4ac <__swc_fn_fc36583a_000064_d9ee99ea+0xcc>
  40b4a5:	mov    eax,0x8
  40b4aa:	jmp    40b4d0 <__swc_fn_fc36583a_000064_d9ee99ea+0xf0>
  40b4ac:	cmp    eax,0x8
  40b4af:	ja     40b4b7 <__swc_fn_fc36583a_000064_d9ee99ea+0xd7>
  40b4b1:	shl    rax,0x4
  40b4b5:	jmp    40b4d0 <__swc_fn_fc36583a_000064_d9ee99ea+0xf0>
  40b4b7:	lea    eax,[rax-0x9]
  40b4ba:	mov    ecx,eax
  40b4bc:	shr    ecx,0x2
  40b4bf:	and    eax,0x3
  40b4c2:	lea    ecx,[rcx+0x7]
  40b4c5:	lea    ecx,[rcx-0x2]
  40b4c8:	lea    eax,[rax+0x5]
  40b4cb:	shlx   rax,rax,rcx
  40b4d0:	mov    r15,rax
  40b4d3:	lea    rax,[r14+r13*1]
  40b4d7:	mov    rcx,0xffffffffffffffff
  40b4de:	sub    rcx,rax
  40b4e1:	cmp    r15,rcx
  40b4e4:	jbe    40b4f4 <__swc_fn_fc36583a_000064_d9ee99ea+0x114>
  40b4e6:	mov    QWORD PTR [r12+0x40],0x0
  40b4ef:	jmp    40b8c6 <__swc_fn_fc36583a_000064_d9ee99ea+0x4e6>
  40b4f4:	mov    QWORD PTR [rsp+0x20],r13
  40b4f9:	lea    r13,[rsp+0x8]
  40b4fe:	add    rax,r15
  40b501:	mov    ecx,0x1000
  40b506:	test   ecx,ecx
  40b508:	mov    edx,0x8
  40b50d:	cmove  ecx,edx
  40b510:	dec    rcx
  40b513:	mov    rdx,0xffffffffffffffff
  40b51a:	sub    rdx,rcx
  40b51d:	cmp    rax,rdx
  40b520:	jbe    40b52c <__swc_fn_fc36583a_000064_d9ee99ea+0x14c>
  40b522:	mov    QWORD PTR [r13+0x0],0x0
  40b52a:	jmp    40b539 <__swc_fn_fc36583a_000064_d9ee99ea+0x159>
  40b52c:	add    rax,rcx
  40b52f:	andn   rax,rcx,rax
  40b534:	mov    QWORD PTR [rsp+0x8],rax
  40b539:	cmp    QWORD PTR [r13+0x0],0x0
  40b53e:	jne    40b54e <__swc_fn_fc36583a_000064_d9ee99ea+0x16e>
  40b540:	mov    QWORD PTR [r12+0x40],0x0
  40b549:	jmp    40b8c6 <__swc_fn_fc36583a_000064_d9ee99ea+0x4e6>
  40b54e:	mov    QWORD PTR [rsp+0x30],r15
  40b553:	xor    r15d,r15d
  40b556:	mov    QWORD PTR [rsp+0x38],0x0
  40b55f:	lea    r12,[rsp+0x10]
  40b564:	mov    QWORD PTR [rsp+0x28],r14
  40b569:	mov    r14,QWORD PTR [rsp+0x8]
  40b56e:	mov    QWORD PTR [rsp+0x10],r14
  40b573:	cmp    r14,0x10000
  40b57a:	ja     40b581 <__swc_fn_fc36583a_000064_d9ee99ea+0x1a1>
  40b57c:	mov    rax,r14
  40b57f:	jmp    40b5d2 <__swc_fn_fc36583a_000064_d9ee99ea+0x1f2>
  40b581:	xor    eax,eax
  40b583:	lea    rcx,[r14-0x1]
  40b587:	lzcnt  rax,rcx
  40b58c:	mov    ecx,0x3f
  40b591:	sub    rcx,rax
  40b594:	mov    eax,0x1
  40b599:	lea    rcx,[rcx-0x3]
  40b59d:	shl    rax,cl
  40b5a0:	mov    rcx,rax
  40b5a3:	cmp    rax,0x1000
  40b5aa:	mov    eax,0x1000
  40b5af:	cmovb  rcx,rax
  40b5b3:	mov    rdx,0xffffffffffffffff
  40b5ba:	sub    rdx,rcx
  40b5bd:	mov    rax,r14
  40b5c0:	lea    r8,[r14+rcx*1-0x1]
  40b5c5:	neg    rcx
  40b5c8:	and    r8,rcx
  40b5cb:	cmp    r14,rdx
  40b5ce:	cmovbe rax,r8
  40b5d2:	mov    QWORD PTR [rsp+0x8],rax
  40b5d7:	lea    rax,[rip+0x16a2a]        # 422008 <__swc_data_base_fc36583a+0x8>
  40b5de:	mov    rax,QWORD PTR [rax]
  40b5e1:	cmp    rax,0xffffffffffffffff
  40b5e5:	je     40b5f4 <__swc_fn_fc36583a_000064_d9ee99ea+0x214>
  40b5e7:	mov    eax,eax
  40b5e9:	mov    edi,eax
  40b5eb:	xor    eax,eax
  40b5ed:	call   407000 <pthread_getspecific@plt>
  40b5f2:	jmp    40b5f6 <__swc_fn_fc36583a_000064_d9ee99ea+0x216>
  40b5f4:	xor    eax,eax
  40b5f6:	test   rax,rax
  40b5f9:	jne    40b608 <__swc_fn_fc36583a_000064_d9ee99ea+0x228>
  40b5fb:	call   40aa80 <__swc_fn_fc36583a_000034_cd1a4e8c>
  40b600:	mov    rcx,rax
  40b603:	call   410540 <__swc_fn_fc36583a_000131_5f757033>
  40b608:	test   rax,rax
  40b60b:	je     40b6fc <__swc_fn_fc36583a_000064_d9ee99ea+0x31c>
  40b611:	cmp    QWORD PTR [rax],rbx
  40b614:	jne    40b6fc <__swc_fn_fc36583a_000064_d9ee99ea+0x31c>
  40b61a:	cmp    DWORD PTR [rax+0x20],0x0
  40b61e:	jne    40b6fc <__swc_fn_fc36583a_000064_d9ee99ea+0x31c>
  40b624:	mov    rcx,QWORD PTR [rsp+0x8]
  40b629:	movabs rdx,0x7fffffffffffffff
  40b633:	cmp    rcx,rdx
  40b636:	mov    rdx,0xffffffffffffffff
  40b63d:	lea    r8,[rcx+rcx*1]
  40b641:	cmovbe rdx,r8
  40b645:	mov    r8d,DWORD PTR [rax+0x730]
  40b64c:	mov    r9d,r8d
  40b64f:	sub    rdx,rcx
  40b652:	inc    rdx
  40b655:	xor    r10d,r10d
  40b658:	test   r8,r8
  40b65b:	jbe    40b68b <__swc_fn_fc36583a_000064_d9ee99ea+0x2ab>
  40b65d:	nop    DWORD PTR [rax]
  40b660:	mov    r11d,r10d
  40b663:	lea    r11,[r11+r11*4]
  40b667:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40b66f:	sub    r11,rcx
  40b672:	cmp    r11,rdx
  40b675:	jae    40b682 <__swc_fn_fc36583a_000064_d9ee99ea+0x2a2>
  40b677:	mov    r9d,r10d
  40b67a:	mov    rdx,r11
  40b67d:	test   r11,r11
  40b680:	je     40b68b <__swc_fn_fc36583a_000064_d9ee99ea+0x2ab>
  40b682:	add    r10,0x1
  40b686:	cmp    r10,r8
  40b689:	jb     40b660 <__swc_fn_fc36583a_000064_d9ee99ea+0x280>
  40b68b:	mov    ecx,DWORD PTR [rax+0x730]
  40b691:	cmp    r9d,ecx
  40b694:	jne    40b69a <__swc_fn_fc36583a_000064_d9ee99ea+0x2ba>
  40b696:	xor    eax,eax
  40b698:	jmp    40b6f9 <__swc_fn_fc36583a_000064_d9ee99ea+0x319>
  40b69a:	lea    rcx,[r9+r9*4]
  40b69e:	lea    rcx,[rax+rcx*8+0x738]
  40b6a6:	vmovups xmm0,XMMWORD PTR [rcx]
  40b6aa:	mov    rdx,QWORD PTR [rcx+0x10]
  40b6ae:	sub    DWORD PTR [rax+0x730],0x1
  40b6b5:	mov    r8d,DWORD PTR [rax+0x730]
  40b6bc:	lea    r8,[r8+r8*4]
  40b6c0:	lea    r8,[rax+r8*8+0x738]
  40b6c8:	vmovups xmm1,XMMWORD PTR [r8]
  40b6cd:	vmovups XMMWORD PTR [rcx],xmm1
  40b6d1:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40b6d7:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40b6dc:	mov    rax,QWORD PTR [r8+0x20]
  40b6e0:	mov    QWORD PTR [rcx+0x20],rax
  40b6e4:	vpshufd xmm1,xmm0,0xee
  40b6e9:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40b6ef:	mov    QWORD PTR [rsp+0x10],rdx
  40b6f4:	vmovq  rax,xmm0
  40b6f9:	mov    r15,rax
  40b6fc:	test   r15,r15
  40b6ff:	jne    40b717 <__swc_fn_fc36583a_000064_d9ee99ea+0x337>
  40b701:	mov    rcx,rbx
  40b704:	mov    rdx,QWORD PTR [rsp+0x8]
  40b709:	mov    r8,r13
  40b70c:	mov    r9,r12
  40b70f:	call   40afd0 <__swc_fn_fc36583a_000058_2ca0cb05>
  40b714:	mov    r15,rax
  40b717:	test   r15,r15
  40b71a:	je     40b75b <__swc_fn_fc36583a_000064_d9ee99ea+0x37b>
  40b71c:	cmp    QWORD PTR [r12],r14
  40b720:	jae    40b75b <__swc_fn_fc36583a_000064_d9ee99ea+0x37b>
  40b722:	mov    rax,r15
  40b725:	add    rax,QWORD PTR [r12]
  40b729:	mov    rdx,r14
  40b72c:	sub    rdx,QWORD PTR [r12]
  40b730:	mov    rcx,rax
  40b733:	call   407340 <__swc_fn_fc36583a_000006_f7acedb0>
  40b738:	test   al,al
  40b73a:	je     40b743 <__swc_fn_fc36583a_000064_d9ee99ea+0x363>
  40b73c:	mov    QWORD PTR [rsp+0x10],r14
  40b741:	jmp    40b75b <__swc_fn_fc36583a_000064_d9ee99ea+0x37b>
  40b743:	mov    rcx,rbx
  40b746:	mov    rdx,r15
  40b749:	mov    r8,QWORD PTR [rsp+0x8]
  40b74e:	mov    r9,QWORD PTR [rsp+0x10]
  40b753:	call   40b0e0 <__swc_fn_fc36583a_000061_b304235a>
  40b758:	xor    r15d,r15d
  40b75b:	test   r15,r15
  40b75e:	jne    40b7da <__swc_fn_fc36583a_000064_d9ee99ea+0x3fa>
  40b760:	cmp    r14,0x10000
  40b767:	ja     40b76e <__swc_fn_fc36583a_000064_d9ee99ea+0x38e>
  40b769:	mov    rax,r14
  40b76c:	jmp    40b7bf <__swc_fn_fc36583a_000064_d9ee99ea+0x3df>
  40b76e:	xor    eax,eax
  40b770:	lea    rcx,[r14-0x1]
  40b774:	lzcnt  rax,rcx
  40b779:	mov    ecx,0x3f
  40b77e:	sub    rcx,rax
  40b781:	mov    eax,0x1
  40b786:	lea    rcx,[rcx-0x3]
  40b78a:	shl    rax,cl
  40b78d:	mov    rcx,rax
  40b790:	cmp    rax,0x1000
  40b797:	mov    eax,0x1000
  40b79c:	cmovb  rcx,rax
  40b7a0:	mov    rdx,0xffffffffffffffff
  40b7a7:	sub    rdx,rcx
  40b7aa:	mov    rax,r14
  40b7ad:	lea    r8,[r14+rcx*1-0x1]
  40b7b2:	neg    rcx
  40b7b5:	and    r8,rcx
  40b7b8:	cmp    r14,rdx
  40b7bb:	cmovbe rax,r8
  40b7bf:	mov    QWORD PTR [rsp+0x8],rax
  40b7c4:	mov    QWORD PTR [rsp+0x10],r14
  40b7c9:	mov    rcx,rbx
  40b7cc:	mov    rdx,rax
  40b7cf:	mov    r8,r14
  40b7d2:	call   40ab40 <__swc_fn_fc36583a_000040_c90d80c1>
  40b7d7:	mov    r15,rax
  40b7da:	test   r15,r15
  40b7dd:	jne    40b7eb <__swc_fn_fc36583a_000064_d9ee99ea+0x40b>
  40b7df:	mov    r13,QWORD PTR [rsp+0x20]
  40b7e4:	mov    rsi,QWORD PTR [rsp+0x38]
  40b7e9:	jmp    40b827 <__swc_fn_fc36583a_000064_d9ee99ea+0x447>
  40b7eb:	mov    rax,r15
  40b7ee:	add    rax,QWORD PTR [rsp+0x28]
  40b7f3:	mov    r13,QWORD PTR [rsp+0x20]
  40b7f8:	test   r13d,r13d
  40b7fb:	mov    rcx,r13
  40b7fe:	mov    edx,0x8
  40b803:	cmove  ecx,edx
  40b806:	dec    rcx
  40b809:	mov    rdx,0xffffffffffffffff
  40b810:	sub    rdx,rcx
  40b813:	cmp    rax,rdx
  40b816:	jbe    40b81c <__swc_fn_fc36583a_000064_d9ee99ea+0x43c>
  40b818:	xor    eax,eax
  40b81a:	jmp    40b824 <__swc_fn_fc36583a_000064_d9ee99ea+0x444>
  40b81c:	add    rax,rcx
  40b81f:	andn   rax,rcx,rax
  40b824:	mov    rsi,rax
  40b827:	mov    rax,QWORD PTR [rsp+0x8]
  40b82c:	test   r15,r15
  40b82f:	je     40b838 <__swc_fn_fc36583a_000064_d9ee99ea+0x458>
  40b831:	mov    rdi,QWORD PTR [rsp+0x18]
  40b836:	jmp    40b84a <__swc_fn_fc36583a_000064_d9ee99ea+0x46a>
  40b838:	mov    rdi,QWORD PTR [rsp+0x18]
  40b83d:	mov    QWORD PTR [rdi+0x40],0x0
  40b845:	jmp    40b8c6 <__swc_fn_fc36583a_000064_d9ee99ea+0x4e6>
  40b84a:	lea    rdx,[rsi-0x58]
  40b84e:	mov    QWORD PTR [rsi-0x58],r15
  40b852:	mov    QWORD PTR [rsi-0x50],rax
  40b856:	mov    rax,QWORD PTR [rsp+0x10]
  40b85b:	mov    QWORD PTR [rsi-0x48],rax
  40b85f:	mov    QWORD PTR [rsi-0x40],rsi
  40b863:	mov    rax,QWORD PTR [rdi+0x48]
  40b867:	mov    QWORD PTR [rsi-0x38],rax
  40b86b:	mov    rax,QWORD PTR [rsp+0x30]
  40b870:	mov    QWORD PTR [rsi-0x30],rax
  40b874:	mov    DWORD PTR [rsi-0x10],r13d
  40b878:	mov    QWORD PTR [rsi-0x28],0x0
  40b880:	mov    QWORD PTR [rsi-0x20],0x0
  40b888:	add    r15,QWORD PTR [r12]
  40b88c:	sub    r15,rsi
  40b88f:	mov    QWORD PTR [rsi-0x30],r15
  40b893:	mov    rcx,QWORD PTR [rbx+0x250]
  40b89a:	nop    WORD PTR [rax+rax*1+0x0]
  40b8a0:	lea    r8,[rcx+r15*1]
  40b8a4:	mov    rax,rcx
  40b8a7:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40b8b0:	cmp    rax,rcx
  40b8b3:	je     40b8ba <__swc_fn_fc36583a_000064_d9ee99ea+0x4da>
  40b8b5:	mov    rcx,rax
  40b8b8:	jmp    40b8a0 <__swc_fn_fc36583a_000064_d9ee99ea+0x4c0>
  40b8ba:	mov    rcx,rbx
  40b8bd:	call   40e870 <__swc_fn_fc36583a_000056_7e1dbcb0>
  40b8c2:	mov    QWORD PTR [rdi+0x40],rsi
  40b8c6:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40b8cc:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40b8d2:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40b8d8:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40b8de:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40b8e7:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40b8f0:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40b8f9:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40b902:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40b90b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40b914:	add    rsp,0xf0
  40b91b:	pop    rsi
  40b91c:	pop    rdi
  40b91d:	pop    r15
  40b91f:	pop    r14
  40b921:	pop    r13
  40b923:	pop    r12
  40b925:	pop    rbx
  40b926:	ret
	...

000000000040b930 <__swc_fn_fc36583a_000067_f3aa21af>:
  40b930:	push   rbx
  40b931:	push   r12
  40b933:	push   rdi
  40b934:	push   rsi
  40b935:	sub    rsp,0xb8
  40b93c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40b942:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40b948:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40b94e:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40b954:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40b95a:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40b960:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40b966:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40b96f:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40b978:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40b981:	mov    rbx,rdx
  40b984:	mov    r12,rcx
  40b987:	cmp    DWORD PTR [rbx+0x58],0x0
  40b98b:	je     40b9a5 <__swc_fn_fc36583a_000067_f3aa21af+0x75>
  40b98d:	mov    eax,DWORD PTR [rbx+0x58]
  40b990:	sub    eax,0x1
  40b993:	test   DWORD PTR [rbx+0x58],eax
  40b996:	je     40b9a5 <__swc_fn_fc36583a_000067_f3aa21af+0x75>
  40b998:	mov    QWORD PTR [rbx+0x40],0x0
  40b9a0:	jmp    40bbb7 <__swc_fn_fc36583a_000067_f3aa21af+0x287>
  40b9a5:	cmp    QWORD PTR [rbx+0x48],0x0
  40b9aa:	jne    40b9b9 <__swc_fn_fc36583a_000067_f3aa21af+0x89>
  40b9ac:	mov    QWORD PTR [rbx+0x40],0x0
  40b9b4:	jmp    40bbb7 <__swc_fn_fc36583a_000067_f3aa21af+0x287>
  40b9b9:	lea    rax,[rsp+0x8]
  40b9be:	mov    rcx,QWORD PTR [rbx+0x48]
  40b9c2:	cmp    rcx,0x8
  40b9c6:	ja     40b9d0 <__swc_fn_fc36583a_000067_f3aa21af+0xa0>
  40b9c8:	mov    DWORD PTR [rax],0x0
  40b9ce:	jmp    40ba2b <__swc_fn_fc36583a_000067_f3aa21af+0xfb>
  40b9d0:	cmp    rcx,0x80
  40b9d7:	ja     40b9e7 <__swc_fn_fc36583a_000067_f3aa21af+0xb7>
  40b9d9:	lea    rcx,[rcx+0xf]
  40b9dd:	shr    rcx,0x4
  40b9e1:	mov    DWORD PTR [rsp+0x8],ecx
  40b9e5:	jmp    40ba2b <__swc_fn_fc36583a_000067_f3aa21af+0xfb>
  40b9e7:	cmp    rcx,0x10000
  40b9ee:	jbe    40b9f8 <__swc_fn_fc36583a_000067_f3aa21af+0xc8>
  40b9f0:	mov    DWORD PTR [rax],0xffffffff
  40b9f6:	jmp    40ba2b <__swc_fn_fc36583a_000067_f3aa21af+0xfb>
  40b9f8:	dec    rcx
  40b9fb:	xor    edx,edx
  40b9fd:	lzcnt  rdx,rcx
  40ba02:	mov    r8d,0x3f
  40ba08:	sub    r8d,edx
  40ba0b:	lea    edx,[r8-0x2]
  40ba0f:	shrx   rcx,rcx,rdx
  40ba14:	and    ecx,0x3
  40ba17:	lea    edx,[r8-0x7]
  40ba1b:	lea    edx,[rdx*4+0x0]
  40ba22:	lea    edx,[rdx+0x9]
  40ba25:	add    edx,ecx
  40ba27:	mov    DWORD PTR [rsp+0x8],edx
  40ba2b:	cmp    DWORD PTR [rax],0x0
  40ba2e:	jne    40ba3e <__swc_fn_fc36583a_000067_f3aa21af+0x10e>
  40ba30:	cmp    DWORD PTR [rbx+0x58],0x8
  40ba34:	jbe    40ba3e <__swc_fn_fc36583a_000067_f3aa21af+0x10e>
  40ba36:	mov    DWORD PTR [rsp+0x8],0x1
  40ba3e:	cmp    DWORD PTR [rbx+0x58],0x10
  40ba42:	jbe    40bac1 <__swc_fn_fc36583a_000067_f3aa21af+0x191>
  40ba48:	cmp    DWORD PTR [rbx+0x58],0x40
  40ba4c:	ja     40bac1 <__swc_fn_fc36583a_000067_f3aa21af+0x191>
  40ba4e:	cmp    DWORD PTR [rax],0xffffffff
  40ba51:	je     40bac1 <__swc_fn_fc36583a_000067_f3aa21af+0x191>
  40ba53:	mov    ecx,DWORD PTR [rsp+0x8]
  40ba57:	mov    edx,DWORD PTR [rbx+0x58]
  40ba5a:	dec    rdx
  40ba5d:	cmp    ecx,0x2d
  40ba60:	jae    40bab8 <__swc_fn_fc36583a_000067_f3aa21af+0x188>
  40ba62:	cs nop WORD PTR [rax+rax*1+0x0]
  40ba6c:	nop    DWORD PTR [rax+0x0]
  40ba70:	mov    r8d,ecx
  40ba73:	test   ecx,ecx
  40ba75:	jne    40ba7f <__swc_fn_fc36583a_000067_f3aa21af+0x14f>
  40ba77:	mov    r8d,0x8
  40ba7d:	jmp    40baab <__swc_fn_fc36583a_000067_f3aa21af+0x17b>
  40ba7f:	cmp    r8d,0x8
  40ba83:	ja     40ba8b <__swc_fn_fc36583a_000067_f3aa21af+0x15b>
  40ba85:	shl    r8,0x4
  40ba89:	jmp    40baab <__swc_fn_fc36583a_000067_f3aa21af+0x17b>
  40ba8b:	lea    r8d,[r8-0x9]
  40ba8f:	mov    r9d,r8d
  40ba92:	shr    r9d,0x2
  40ba96:	and    r8d,0x3
  40ba9a:	lea    r9d,[r9+0x7]
  40ba9e:	lea    r9d,[r9-0x2]
  40baa2:	lea    r8d,[r8+0x5]
  40baa6:	shlx   r8,r8,r9
  40baab:	test   r8,rdx
  40baae:	je     40babd <__swc_fn_fc36583a_000067_f3aa21af+0x18d>
  40bab0:	add    ecx,0x1
  40bab3:	cmp    ecx,0x2d
  40bab6:	jb     40ba70 <__swc_fn_fc36583a_000067_f3aa21af+0x140>
  40bab8:	mov    ecx,0xffffffff
  40babd:	mov    DWORD PTR [rsp+0x8],ecx
  40bac1:	mov    ecx,DWORD PTR [rsp+0x8]
  40bac5:	cmp    ecx,0xffffffff
  40bac8:	je     40bad0 <__swc_fn_fc36583a_000067_f3aa21af+0x1a0>
  40baca:	cmp    DWORD PTR [rbx+0x58],0x40
  40bace:	jbe    40bae3 <__swc_fn_fc36583a_000067_f3aa21af+0x1b3>
  40bad0:	mov    rcx,r12
  40bad3:	mov    rdx,rbx
  40bad6:	mov    r8d,DWORD PTR [rax]
  40bad9:	call   40b3e0 <__swc_fn_fc36583a_000064_d9ee99ea>
  40bade:	jmp    40bbb7 <__swc_fn_fc36583a_000067_f3aa21af+0x287>
  40bae3:	lea    rax,[rip+0x1651e]        # 422008 <__swc_data_base_fc36583a+0x8>
  40baea:	mov    rax,QWORD PTR [rax]
  40baed:	cmp    rax,0xffffffffffffffff
  40baf1:	je     40bb00 <__swc_fn_fc36583a_000067_f3aa21af+0x1d0>
  40baf3:	mov    eax,eax
  40baf5:	mov    edi,eax
  40baf7:	xor    eax,eax
  40baf9:	call   407000 <pthread_getspecific@plt>
  40bafe:	jmp    40bb02 <__swc_fn_fc36583a_000067_f3aa21af+0x1d2>
  40bb00:	xor    eax,eax
  40bb02:	test   rax,rax
  40bb05:	jne    40bb14 <__swc_fn_fc36583a_000067_f3aa21af+0x1e4>
  40bb07:	call   40aa80 <__swc_fn_fc36583a_000034_cd1a4e8c>
  40bb0c:	mov    rcx,rax
  40bb0f:	call   410540 <__swc_fn_fc36583a_000131_5f757033>
  40bb14:	test   rax,rax
  40bb17:	je     40bb24 <__swc_fn_fc36583a_000067_f3aa21af+0x1f4>
  40bb19:	cmp    QWORD PTR [rax],r12
  40bb1c:	jne    40bb24 <__swc_fn_fc36583a_000067_f3aa21af+0x1f4>
  40bb1e:	cmp    DWORD PTR [rax+0x20],0x0
  40bb22:	je     40bb2f <__swc_fn_fc36583a_000067_f3aa21af+0x1ff>
  40bb24:	mov    rcx,r12
  40bb27:	mov    rdx,rax
  40bb2a:	call   40e4b0 <__swc_fn_fc36583a_000044_d8bd27c3>
  40bb2f:	test   rax,rax
  40bb32:	jne    40bb3e <__swc_fn_fc36583a_000067_f3aa21af+0x20e>
  40bb34:	mov    QWORD PTR [rbx+0x40],0x0
  40bb3c:	jmp    40bbb7 <__swc_fn_fc36583a_000067_f3aa21af+0x287>
  40bb3e:	lea    r8,[rsp+0xc]
  40bb43:	mov    ecx,DWORD PTR [rsp+0x8]
  40bb47:	mov    DWORD PTR [rsp+0xc],ecx
  40bb4b:	mov    ecx,DWORD PTR [r8]
  40bb4e:	lea    rcx,[rcx+rcx*4]
  40bb52:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40bb57:	test   rcx,rcx
  40bb5a:	je     40bb93 <__swc_fn_fc36583a_000067_f3aa21af+0x263>
  40bb5c:	mov    rdx,QWORD PTR [rcx]
  40bb5f:	test   rdx,rdx
  40bb62:	je     40bb70 <__swc_fn_fc36583a_000067_f3aa21af+0x240>
  40bb64:	mov    r9,QWORD PTR [rdx]
  40bb67:	mov    QWORD PTR [rcx],r9
  40bb6a:	add    DWORD PTR [rcx+0x28],0x1
  40bb6e:	jmp    40bb8e <__swc_fn_fc36583a_000067_f3aa21af+0x25e>
  40bb70:	mov    rdx,QWORD PTR [rcx+0x18]
  40bb74:	cmp    QWORD PTR [rcx+0x20],rdx
  40bb78:	jae    40bb8c <__swc_fn_fc36583a_000067_f3aa21af+0x25c>
  40bb7a:	mov    rdx,QWORD PTR [rcx+0x20]
  40bb7e:	mov    r9d,DWORD PTR [rcx+0x2c]
  40bb82:	add    QWORD PTR [rcx+0x20],r9
  40bb86:	add    DWORD PTR [rcx+0x28],0x1
  40bb8a:	jmp    40bb8e <__swc_fn_fc36583a_000067_f3aa21af+0x25e>
  40bb8c:	xor    edx,edx
  40bb8e:	test   rdx,rdx
  40bb91:	jne    40bba4 <__swc_fn_fc36583a_000067_f3aa21af+0x274>
  40bb93:	mov    rcx,r12
  40bb96:	mov    rdx,rax
  40bb99:	mov    r8d,DWORD PTR [r8]
  40bb9c:	call   40e620 <__swc_fn_fc36583a_000053_faa92dcc>
  40bba1:	mov    rdx,rax
  40bba4:	test   rdx,rdx
  40bba7:	jne    40bbb3 <__swc_fn_fc36583a_000067_f3aa21af+0x283>
  40bba9:	mov    QWORD PTR [rbx+0x40],0x0
  40bbb1:	jmp    40bbb7 <__swc_fn_fc36583a_000067_f3aa21af+0x287>
  40bbb3:	mov    QWORD PTR [rbx+0x40],rdx
  40bbb7:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40bbbd:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40bbc3:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40bbc9:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40bbcf:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40bbd5:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40bbdb:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40bbe1:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40bbea:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40bbf3:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40bbfc:	add    rsp,0xb8
  40bc03:	pop    rsi
  40bc04:	pop    rdi
  40bc05:	pop    r12
  40bc07:	pop    rbx
  40bc08:	ret
  40bc09:	add    BYTE PTR [rax],al
  40bc0b:	add    BYTE PTR [rax],al
  40bc0d:	add    BYTE PTR [rax],al
	...

000000000040bc10 <__swc_fn_fc36583a_000070_b3d7b28e>:
  40bc10:	ret
	...

000000000040bc20 <__swc_fn_fc36583a_000073_042643a3>:
  40bc20:	push   r12
  40bc22:	push   r13
  40bc24:	push   r14
  40bc26:	push   rdi
  40bc27:	push   rsi
  40bc28:	sub    rsp,0x1a0
  40bc2f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40bc38:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40bc41:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40bc4a:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40bc53:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40bc5c:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40bc65:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40bc6e:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40bc77:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40bc80:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40bc89:	mov    r12,rdx
  40bc8c:	mov    r13,rcx
  40bc8f:	mov    rax,QWORD PTR [r12+0x48]
  40bc94:	mov    ecx,DWORD PTR [r12+0x58]
  40bc99:	lea    rdx,[rax-0x1]
  40bc9d:	cmp    rdx,0x10000
  40bca4:	jae    40bd9e <__swc_fn_fc36583a_000073_042643a3+0x17e>
  40bcaa:	cmp    rax,0x8
  40bcae:	ja     40bcb5 <__swc_fn_fc36583a_000073_042643a3+0x95>
  40bcb0:	xor    r14d,r14d
  40bcb3:	jmp    40bd07 <__swc_fn_fc36583a_000073_042643a3+0xe7>
  40bcb5:	cmp    rax,0x80
  40bcbc:	ja     40bcc8 <__swc_fn_fc36583a_000073_042643a3+0xa8>
  40bcbe:	lea    r14,[rax+0xf]
  40bcc2:	shr    r14,0x4
  40bcc6:	jmp    40bd07 <__swc_fn_fc36583a_000073_042643a3+0xe7>
  40bcc8:	cmp    rax,0x10000
  40bccf:	jbe    40bcd9 <__swc_fn_fc36583a_000073_042643a3+0xb9>
  40bcd1:	mov    r14d,0xffffffff
  40bcd7:	jmp    40bd07 <__swc_fn_fc36583a_000073_042643a3+0xe7>
  40bcd9:	xor    eax,eax
  40bcdb:	lzcnt  rax,rdx
  40bce0:	mov    r8d,0x3f
  40bce6:	sub    r8d,eax
  40bce9:	lea    eax,[r8-0x2]
  40bced:	shrx   rax,rdx,rax
  40bcf2:	and    eax,0x3
  40bcf5:	lea    edx,[r8-0x7]
  40bcf9:	lea    edx,[rdx*4+0x0]
  40bd00:	lea    edx,[rdx+0x9]
  40bd03:	lea    r14d,[rdx+rax*1]
  40bd07:	cmp    ecx,0x8
  40bd0a:	jbe    40bd23 <__swc_fn_fc36583a_000073_042643a3+0x103>
  40bd0c:	cmp    ecx,0x10
  40bd0f:	jne    40bd9e <__swc_fn_fc36583a_000073_042643a3+0x17e>
  40bd15:	test   r14d,r14d
  40bd18:	mov    eax,0x1
  40bd1d:	cmove  r14d,eax
  40bd21:	jmp    40bd2a <__swc_fn_fc36583a_000073_042643a3+0x10a>
  40bd23:	lea    eax,[rcx-0x1]
  40bd26:	test   eax,ecx
  40bd28:	jne    40bd9e <__swc_fn_fc36583a_000073_042643a3+0x17e>
  40bd2a:	lea    rax,[rip+0x162d7]        # 422008 <__swc_data_base_fc36583a+0x8>
  40bd31:	mov    rax,QWORD PTR [rax]
  40bd34:	cmp    rax,0xffffffffffffffff
  40bd38:	je     40bd47 <__swc_fn_fc36583a_000073_042643a3+0x127>
  40bd3a:	mov    eax,eax
  40bd3c:	mov    edi,eax
  40bd3e:	xor    eax,eax
  40bd40:	call   407000 <pthread_getspecific@plt>
  40bd45:	jmp    40bd49 <__swc_fn_fc36583a_000073_042643a3+0x129>
  40bd47:	xor    eax,eax
  40bd49:	test   rax,rax
  40bd4c:	je     40bd9e <__swc_fn_fc36583a_000073_042643a3+0x17e>
  40bd4e:	cmp    QWORD PTR [rax],r13
  40bd51:	jne    40bd9e <__swc_fn_fc36583a_000073_042643a3+0x17e>
  40bd53:	lea    rcx,[r14+r14*4]
  40bd57:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40bd5c:	test   rax,rax
  40bd5f:	je     40bd9e <__swc_fn_fc36583a_000073_042643a3+0x17e>
  40bd61:	mov    rcx,QWORD PTR [rax]
  40bd64:	test   rcx,rcx
  40bd67:	je     40bd75 <__swc_fn_fc36583a_000073_042643a3+0x155>
  40bd69:	mov    rdx,QWORD PTR [rcx]
  40bd6c:	mov    QWORD PTR [rax],rdx
  40bd6f:	add    DWORD PTR [rax+0x28],0x1
  40bd73:	jmp    40bd92 <__swc_fn_fc36583a_000073_042643a3+0x172>
  40bd75:	mov    rcx,QWORD PTR [rax+0x18]
  40bd79:	cmp    QWORD PTR [rax+0x20],rcx
  40bd7d:	jae    40bd90 <__swc_fn_fc36583a_000073_042643a3+0x170>
  40bd7f:	mov    rcx,QWORD PTR [rax+0x20]
  40bd83:	mov    edx,DWORD PTR [rax+0x2c]
  40bd86:	add    QWORD PTR [rax+0x20],rdx
  40bd8a:	add    DWORD PTR [rax+0x28],0x1
  40bd8e:	jmp    40bd92 <__swc_fn_fc36583a_000073_042643a3+0x172>
  40bd90:	xor    ecx,ecx
  40bd92:	test   rcx,rcx
  40bd95:	je     40bd9e <__swc_fn_fc36583a_000073_042643a3+0x17e>
  40bd97:	mov    QWORD PTR [r12+0x40],rcx
  40bd9c:	jmp    40bda9 <__swc_fn_fc36583a_000073_042643a3+0x189>
  40bd9e:	mov    rcx,r13
  40bda1:	mov    rdx,r12
  40bda4:	call   40f0a0 <__swc_fn_fc36583a_000074_64d36d78>
  40bda9:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40bdb2:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40bdbb:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40bdc4:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40bdcd:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40bdd6:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40bddf:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40bde8:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40bdf1:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40bdfa:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40be03:	add    rsp,0x1a0
  40be0a:	pop    rsi
  40be0b:	pop    rdi
  40be0c:	pop    r14
  40be0e:	pop    r13
  40be10:	pop    r12
  40be12:	ret
	...

000000000040be20 <__swc_fn_fc36583a_000076_7b195156>:
  40be20:	push   r12
  40be22:	push   r13
  40be24:	push   r14
  40be26:	push   r15
  40be28:	push   rdi
  40be29:	push   rsi
  40be2a:	sub    rsp,0x188
  40be31:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40be3a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40be43:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40be4c:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40be55:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40be5e:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40be67:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40be70:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40be79:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40be82:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40be8b:	mov    r12,rdx
  40be8e:	mov    r13,rcx
  40be91:	mov    r14,QWORD PTR [r12+0x40]
  40be96:	lea    rax,[rip+0x1820b]        # 4240a8 <__swc_bss_base_fc36583a+0x68>
  40be9d:	mov    rcx,r14
  40bea0:	sub    rcx,QWORD PTR [rax+0x8]
  40bea4:	mov    rax,QWORD PTR [rip+0x1820d]        # 4240b8 <__swc_bss_base_fc36583a+0x78>
  40beab:	cmp    rcx,rax
  40beae:	jae    40beda <__swc_fn_fc36583a_000076_7b195156+0xba>
  40beb0:	mov    rax,r14
  40beb3:	and    rax,0xffffffffffc00000
  40beba:	mov    rcx,r14
  40bebd:	shr    rcx,0x10
  40bec1:	and    ecx,0x3f
  40bec4:	mov    edx,DWORD PTR [rax+0x28]
  40bec7:	shrx   ecx,ecx,edx
  40becc:	shl    rcx,0x4
  40bed0:	lea    r15,[rax+rcx*8+0x80]
  40bed8:	jmp    40bee5 <__swc_fn_fc36583a_000076_7b195156+0xc5>
  40beda:	mov    rcx,r14
  40bedd:	call   40a9b0 <__swc_fn_fc36583a_000025_bcdc5519>
  40bee2:	mov    r15,rax
  40bee5:	test   r15,r15
  40bee8:	je     40bf8f <__swc_fn_fc36583a_000076_7b195156+0x16f>
  40beee:	lea    rax,[rip+0x16113]        # 422008 <__swc_data_base_fc36583a+0x8>
  40bef5:	mov    rax,QWORD PTR [rax]
  40bef8:	cmp    rax,0xffffffffffffffff
  40befc:	je     40bf0b <__swc_fn_fc36583a_000076_7b195156+0xeb>
  40befe:	mov    eax,eax
  40bf00:	mov    edi,eax
  40bf02:	xor    eax,eax
  40bf04:	call   407000 <pthread_getspecific@plt>
  40bf09:	jmp    40bf0d <__swc_fn_fc36583a_000076_7b195156+0xed>
  40bf0b:	xor    eax,eax
  40bf0d:	mov    rcx,QWORD PTR [r15+0x40]
  40bf11:	cmp    rcx,rax
  40bf14:	jne    40bf74 <__swc_fn_fc36583a_000076_7b195156+0x154>
  40bf16:	test   rax,rax
  40bf19:	je     40bf8f <__swc_fn_fc36583a_000076_7b195156+0x16f>
  40bf1b:	mov    ecx,DWORD PTR [r15+0x6c]
  40bf1f:	test   ecx,ecx
  40bf21:	je     40bf41 <__swc_fn_fc36583a_000076_7b195156+0x121>
  40bf23:	mov    rcx,r13
  40bf26:	mov    rdx,rax
  40bf29:	mov    r8,r15
  40bf2c:	mov    QWORD PTR [rsp+0xd8],rax
  40bf34:	call   40e5b0 <__swc_fn_fc36583a_000050_e072b516>
  40bf39:	mov    rax,QWORD PTR [rsp+0xd8]
  40bf41:	mov    rcx,QWORD PTR [r15]
  40bf44:	mov    QWORD PTR [r14],rcx
  40bf47:	mov    QWORD PTR [r15],r14
  40bf4a:	sub    DWORD PTR [r15+0x28],0x1
  40bf4f:	jne    40bf84 <__swc_fn_fc36583a_000076_7b195156+0x164>
  40bf51:	movzx  ecx,BYTE PTR [r15+0x39]
  40bf56:	lea    rcx,[rcx+rcx*4]
  40bf5a:	lea    rcx,[rax+rcx*8+0x28]
  40bf5f:	cmp    QWORD PTR [rcx],r15
  40bf62:	je     40bf84 <__swc_fn_fc36583a_000076_7b195156+0x164>
  40bf64:	mov    rcx,r13
  40bf67:	mov    rdx,rax
  40bf6a:	mov    r8,r15
  40bf6d:	call   407e20 <__swc_fn_fc36583a_000054_2e3450f7>
  40bf72:	jmp    40bf84 <__swc_fn_fc36583a_000076_7b195156+0x164>
  40bf74:	test   rcx,rcx
  40bf77:	je     40bf8f <__swc_fn_fc36583a_000076_7b195156+0x16f>
  40bf79:	mov    rcx,r15
  40bf7c:	mov    rdx,r14
  40bf7f:	call   40a5f0 <__swc_fn_fc36583a_000013_524c1f23>
  40bf84:	mov    QWORD PTR [r12+0x40],0x0
  40bf8d:	jmp    40bf9a <__swc_fn_fc36583a_000076_7b195156+0x17a>
  40bf8f:	mov    rcx,r13
  40bf92:	mov    rdx,r12
  40bf95:	call   40f0c0 <__swc_fn_fc36583a_000077_1966ae2e>
  40bf9a:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40bfa3:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40bfac:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40bfb5:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40bfbe:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40bfc7:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40bfd0:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40bfd9:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40bfe2:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40bfeb:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40bff4:	add    rsp,0x188
  40bffb:	pop    rsi
  40bffc:	pop    rdi
  40bffd:	pop    r15
  40bfff:	pop    r14
  40c001:	pop    r13
  40c003:	pop    r12
  40c005:	ret
	...

000000000040c010 <__swc_fn_fc36583a_000079_d2cd17e2>:
  40c010:	sub    rsp,0x8
  40c014:	mov    rax,rdx
  40c017:	mov    rdx,QWORD PTR [rax+0x40]
  40c01b:	mov    r8,rax
  40c01e:	call   40bc10 <__swc_fn_fc36583a_000070_b3d7b28e>
  40c023:	add    rsp,0x8
  40c027:	ret
	...

000000000040c030 <__swc_fn_fc36583a_000082_4a10c7e7>:
  40c030:	push   rsi
  40c031:	push   rdi
  40c032:	sub    rsp,0x8
  40c036:	cmp    rcx,0xffffffffffffffef
  40c03a:	ja     40c060 <__swc_fn_fc36583a_000082_4a10c7e7+0x30>
  40c03c:	xor    esi,esi
  40c03e:	lea    rax,[rcx+0x100f]
  40c045:	and    rax,0xfffffffffffff000
  40c04c:	lea    rcx,[rcx+0x10]
  40c050:	cmp    rcx,0xfffffffffffff000
  40c057:	cmovbe rsi,rax
  40c05b:	test   rsi,rsi
  40c05e:	jne    40c069 <__swc_fn_fc36583a_000082_4a10c7e7+0x39>
  40c060:	xor    eax,eax
  40c062:	add    rsp,0x8
  40c066:	pop    rdi
  40c067:	pop    rsi
  40c068:	ret
  40c069:	mov    rcx,rsi
  40c06c:	call   40c6c0 <__swc_fn_fc36583a_000112_6b799b8d>
  40c071:	mov    rdi,rax
  40c074:	test   rax,rax
  40c077:	jne    40c082 <__swc_fn_fc36583a_000082_4a10c7e7+0x52>
  40c079:	xor    eax,eax
  40c07b:	add    rsp,0x8
  40c07f:	pop    rdi
  40c080:	pop    rsi
  40c081:	ret
  40c082:	mov    rcx,rdi
  40c085:	mov    rdx,rsi
  40c088:	call   4092e0 <__swc_fn_fc36583a_000114_36905703>
  40c08d:	test   al,al
  40c08f:	jne    40c0a5 <__swc_fn_fc36583a_000082_4a10c7e7+0x75>
  40c091:	mov    rcx,rdi
  40c094:	mov    rdx,rsi
  40c097:	call   4101f0 <__swc_fn_fc36583a_000116_ed2d8fed>
  40c09c:	xor    eax,eax
  40c09e:	add    rsp,0x8
  40c0a2:	pop    rdi
  40c0a3:	pop    rsi
  40c0a4:	ret
  40c0a5:	mov    QWORD PTR [rdi],rsi
  40c0a8:	mov    QWORD PTR [rdi+0x8],0x0
  40c0b0:	lea    rax,[rdi+0x10]
  40c0b4:	add    rsp,0x8
  40c0b8:	pop    rdi
  40c0b9:	pop    rsi
  40c0ba:	ret
  40c0bb:	add    BYTE PTR [rax],al
  40c0bd:	add    BYTE PTR [rax],al
	...

000000000040c0c0 <__swc_fn_fc36583a_000085_3953ef98>:
  40c0c0:	sub    rsp,0x8
  40c0c4:	cmp    BYTE PTR [rcx+0x2c],0x10
  40c0c8:	jne    40c0d3 <__swc_fn_fc36583a_000085_3953ef98+0x13>
  40c0ca:	test   DWORD PTR [rcx+0x28],0x80
  40c0d1:	je     40c0db <__swc_fn_fc36583a_000085_3953ef98+0x1b>
  40c0d3:	mov    rax,rcx
  40c0d6:	add    rsp,0x8
  40c0da:	ret
  40c0db:	mov    rcx,QWORD PTR [rcx+0x40]
  40c0df:	call   40c0c0 <__swc_fn_fc36583a_000085_3953ef98>
  40c0e4:	add    rsp,0x8
  40c0e8:	ret
	...

000000000040c100 <__swc_fn_fc36583a_000088_d182c4dc>:
  40c100:	push   rsi
  40c101:	push   rdi
  40c102:	push   r12
  40c104:	push   r13
  40c106:	sub    rsp,0x8
  40c10a:	mov    rsi,rdx
  40c10d:	mov    rdi,rcx
  40c110:	xor    r8d,r8d
  40c113:	call   408640 <__swc_fn_fc36583a_000093_63c1827b>
  40c118:	test   al,al
  40c11a:	je     40c12c <__swc_fn_fc36583a_000088_d182c4dc+0x2c>
  40c11c:	mov    eax,0x1
  40c121:	add    rsp,0x8
  40c125:	pop    r13
  40c127:	pop    r12
  40c129:	pop    rdi
  40c12a:	pop    rsi
  40c12b:	ret
  40c12c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40c131:	je     40c140 <__swc_fn_fc36583a_000088_d182c4dc+0x40>
  40c133:	xor    eax,eax
  40c135:	add    rsp,0x8
  40c139:	pop    r13
  40c13b:	pop    r12
  40c13d:	pop    rdi
  40c13e:	pop    rsi
  40c13f:	ret
  40c140:	mov    r12,QWORD PTR [rsi+0x98]
  40c147:	mov    rax,QWORD PTR [rsi+0xa0]
  40c14e:	mov    rsi,rax
  40c151:	xor    r13d,r13d
  40c154:	test   rsi,rsi
  40c157:	je     40c1b4 <__swc_fn_fc36583a_000088_d182c4dc+0xb4>
  40c159:	cs nop WORD PTR [rax+rax*1+0x0]
  40c163:	cs nop WORD PTR [rax+rax*1+0x0]
  40c16d:	nop    DWORD PTR [rax]
  40c170:	lea    rax,[r13*8+0x0]
  40c178:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40c17d:	mov    rcx,rax
  40c180:	call   40c0c0 <__swc_fn_fc36583a_000085_3953ef98>
  40c185:	cmp    BYTE PTR [rax+0x2c],0xe
  40c189:	jne    40c1aa <__swc_fn_fc36583a_000088_d182c4dc+0xaa>
  40c18b:	mov    rcx,rdi
  40c18e:	mov    rdx,rax
  40c191:	call   40c100 <__swc_fn_fc36583a_000088_d182c4dc>
  40c196:	test   al,al
  40c198:	je     40c1aa <__swc_fn_fc36583a_000088_d182c4dc+0xaa>
  40c19a:	mov    eax,0x1
  40c19f:	add    rsp,0x8
  40c1a3:	pop    r13
  40c1a5:	pop    r12
  40c1a7:	pop    rdi
  40c1a8:	pop    rsi
  40c1a9:	ret
  40c1aa:	add    r13,0x1
  40c1ae:	sub    rsi,0x1
  40c1b2:	jne    40c170 <__swc_fn_fc36583a_000088_d182c4dc+0x70>
  40c1b4:	xor    eax,eax
  40c1b6:	add    rsp,0x8
  40c1ba:	pop    r13
  40c1bc:	pop    r12
  40c1be:	pop    rdi
  40c1bf:	pop    rsi
  40c1c0:	ret
	...

000000000040c1d0 <__swc_fn_fc36583a_000091_14c65203>:
  40c1d0:	sub    rsp,0x18
  40c1d4:	vxorps xmm0,xmm0,xmm0
  40c1d8:	vmovdqu XMMWORD PTR [rsp],xmm0
  40c1dd:	call   40f2d0 <__swc_fn_fc36583a_000092_c2567a3b>
  40c1e2:	add    rsp,0x18
  40c1e6:	ret
	...

000000000040c1f0 <__swc_fn_fc36583a_000094_ad13d15c>:
  40c1f0:	sub    rsp,0x8
  40c1f4:	mov    rcx,QWORD PTR [rip+0x17e45]        # 424040 <__swc_bss_base_fc36583a>
  40c1fb:	test   rcx,rcx
  40c1fe:	jne    40c210 <__swc_fn_fc36583a_000094_ad13d15c+0x20>
  40c200:	call   40a240 <__swc_fn_fc36583a_000168_994c8876>
  40c205:	lea    rcx,[rax+0x1]
  40c209:	mov    QWORD PTR [rip+0x17e30],rcx        # 424040 <__swc_bss_base_fc36583a>
  40c210:	dec    rcx
  40c213:	call   411fc0 <__swc_fn_fc36583a_000170_360af05d>
  40c218:	mov    rax,QWORD PTR [rax+0xc0]
  40c21f:	and    eax,0x1
  40c222:	setne  al
  40c225:	add    rsp,0x8
  40c229:	ret
	...

000000000040c240 <__swc_fn_fc36583a_000097_4f209617>:
  40c240:	push   rbx
  40c241:	push   rsi
  40c242:	push   rdi
  40c243:	push   r12
  40c245:	sub    rsp,0x28
  40c249:	mov    rbx,rcx
  40c24c:	call   4089a0 <__swc_fn_fc36583a_000096_4185993f>
  40c251:	mov    rcx,QWORD PTR [rip+0x17de8]        # 424040 <__swc_bss_base_fc36583a>
  40c258:	test   rcx,rcx
  40c25b:	jne    40c26d <__swc_fn_fc36583a_000097_4f209617+0x2d>
  40c25d:	call   40a240 <__swc_fn_fc36583a_000168_994c8876>
  40c262:	lea    rcx,[rax+0x1]
  40c266:	mov    QWORD PTR [rip+0x17dd3],rcx        # 424040 <__swc_bss_base_fc36583a>
  40c26d:	dec    rcx
  40c270:	call   411fc0 <__swc_fn_fc36583a_000170_360af05d>
  40c275:	mov    rsi,rax
  40c278:	lea    rcx,[rsp+0x8]
  40c27d:	call   40f710 <__swc_fn_fc36583a_000095_93bfe675>
  40c282:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40c289:	mov    r12,QWORD PTR [rsi+0xbe8]
  40c290:	lea    rcx,[rsi+0x10]
  40c294:	call   40d210 <__swc_fn_fc36583a_000160_13ead2ff>
  40c299:	mov    rcx,rsi
  40c29c:	call   40f880 <__swc_fn_fc36583a_000104_5a85fcf5>
  40c2a1:	vxorps xmm0,xmm0,xmm0
  40c2a5:	xor    eax,eax
  40c2a7:	cs nop WORD PTR [rax+rax*1+0x0]
  40c2b1:	cs nop WORD PTR [rax+rax*1+0x0]
  40c2bb:	nop    DWORD PTR [rax+rax*1+0x0]
  40c2c0:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40c2c5:	add    rax,0x10
  40c2c9:	cmp    rax,0xbf0
  40c2d0:	jne    40c2c0 <__swc_fn_fc36583a_000097_4f209617+0x80>
  40c2d2:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c2d8:	vmovups XMMWORD PTR [rsi],xmm0
  40c2dc:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c2e2:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40c2ea:	mov    QWORD PTR [rsi+0x9c0],rdi
  40c2f1:	mov    QWORD PTR [rsi+0xbe8],r12
  40c2f8:	mov    rcx,QWORD PTR [rip+0x17d41]        # 424040 <__swc_bss_base_fc36583a>
  40c2ff:	test   rcx,rcx
  40c302:	jne    40c314 <__swc_fn_fc36583a_000097_4f209617+0xd4>
  40c304:	call   40a240 <__swc_fn_fc36583a_000168_994c8876>
  40c309:	lea    rcx,[rax+0x1]
  40c30d:	mov    QWORD PTR [rip+0x17d2c],rcx        # 424040 <__swc_bss_base_fc36583a>
  40c314:	dec    rcx
  40c317:	call   411fc0 <__swc_fn_fc36583a_000170_360af05d>
  40c31c:	mov    rsi,rax
  40c31f:	mov    QWORD PTR [rsi+0xc0],rbx
  40c326:	and    ebx,0x1
  40c329:	jne    40c32d <__swc_fn_fc36583a_000097_4f209617+0xed>
  40c32b:	xor    eax,eax
  40c32d:	test   rbx,rbx
  40c330:	sete   al
  40c333:	xor    cl,cl
  40c335:	xor    dl,dl
  40c337:	xor    r8b,r8b
  40c33a:	xor    r9b,r9b
  40c33d:	xor    r10b,r10b
  40c340:	mov    r11,rax
  40c343:	call   40f0d0 <__swc_fn_fc36583a_000080_5cc7acfc>
  40c348:	lea    rbx,[rsp+0x18]
  40c34d:	mov    rcx,rbx
  40c350:	call   40f710 <__swc_fn_fc36583a_000095_93bfe675>
  40c355:	lea    rcx,[rsi+0x10]
  40c359:	mov    edx,0x400000
  40c35e:	mov    r8,rbx
  40c361:	call   409f80 <__swc_fn_fc36583a_000162_8a3d304f>
  40c366:	lea    rcx,[rsi+0x68]
  40c36a:	mov    edx,0x4000
  40c36f:	mov    r8,rbx
  40c372:	call   409f80 <__swc_fn_fc36583a_000162_8a3d304f>
  40c377:	add    rsp,0x28
  40c37b:	pop    r12
  40c37d:	pop    rdi
  40c37e:	pop    rsi
  40c37f:	pop    rbx
  40c380:	ret
	...

000000000040c390 <__swc_fn_fc36583a_000100_d0b19c14>:
  40c390:	push   rbx
  40c391:	push   rsi
  40c392:	sub    rsp,0x18
  40c396:	mov    rbx,rcx
  40c399:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40c39e:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c3a4:	mov    rsi,QWORD PTR [rbx+0x70]
  40c3a8:	lea    rcx,[rcx+0x18]
  40c3ac:	call   40d210 <__swc_fn_fc36583a_000160_13ead2ff>
  40c3b1:	lea    rcx,[rsp+0x8]
  40c3b6:	mov    rdx,rbx
  40c3b9:	mov    r8d,0x78
  40c3bf:	call   408a00 <__swc_fn_fc36583a_000099_d4bdcaa4>
  40c3c4:	mov    rax,rsi
  40c3c7:	add    rsp,0x18
  40c3cb:	pop    rsi
  40c3cc:	pop    rbx
  40c3cd:	ret
	...

000000000040c3d0 <__swc_fn_fc36583a_000103_3c3b96fb>:
  40c3d0:	push   rsi
  40c3d1:	push   rdi
  40c3d2:	sub    rsp,0x8
  40c3d6:	cmp    QWORD PTR [rcx],0x0
  40c3da:	jne    40c3e3 <__swc_fn_fc36583a_000103_3c3b96fb+0x13>
  40c3dc:	add    rsp,0x8
  40c3e0:	pop    rdi
  40c3e1:	pop    rsi
  40c3e2:	ret
  40c3e3:	mov    rsi,QWORD PTR [rcx]
  40c3e6:	mov    rax,QWORD PTR [rcx+0x8]
  40c3ea:	test   rax,rax
  40c3ed:	je     40c403 <__swc_fn_fc36583a_000103_3c3b96fb+0x33>
  40c3ef:	test   DWORD PTR [rax+0x28],0x400000
  40c3f6:	je     40c403 <__swc_fn_fc36583a_000103_3c3b96fb+0x33>
  40c3f8:	mov    rcx,QWORD PTR [rax+0x30]
  40c3fc:	test   rcx,rcx
  40c3ff:	cmovne rax,rcx
  40c403:	lea    rdx,[rip+0x6eee]        # 4132f8 <__swc_rdata_base_fc36583a+0x1e8>
  40c40a:	lea    rcx,[rip+0x6fcf]        # 4133e0 <__swc_rdata_base_fc36583a+0x2d0>
  40c411:	mov    r8,rax
  40c414:	xor    r9d,r9d
  40c417:	xor    al,al
  40c419:	mov    r10,rax
  40c41c:	xor    r11d,r11d
  40c41f:	call   40c1d0 <__swc_fn_fc36583a_000091_14c65203>
  40c424:	test   rax,rax
  40c427:	je     40c437 <__swc_fn_fc36583a_000103_3c3b96fb+0x67>
  40c429:	mov    rdi,QWORD PTR [rax+0x48]
  40c42d:	test   rdi,rdi
  40c430:	je     40c437 <__swc_fn_fc36583a_000103_3c3b96fb+0x67>
  40c432:	mov    rcx,rsi
  40c435:	call   rdi
  40c437:	add    rsp,0x8
  40c43b:	pop    rdi
  40c43c:	pop    rsi
  40c43d:	ret
	...

000000000040c440 <__swc_fn_fc36583a_000106_90faaa26>:
  40c440:	push   rbx
  40c441:	push   rsi
  40c442:	push   rdi
  40c443:	sub    rsp,0x20
  40c447:	mov    rbx,rdx
  40c44a:	mov    rsi,rcx
  40c44d:	mov    rcx,QWORD PTR [rip+0x17bec]        # 424040 <__swc_bss_base_fc36583a>
  40c454:	test   rcx,rcx
  40c457:	jne    40c469 <__swc_fn_fc36583a_000106_90faaa26+0x29>
  40c459:	call   40a240 <__swc_fn_fc36583a_000168_994c8876>
  40c45e:	lea    rcx,[rax+0x1]
  40c462:	mov    QWORD PTR [rip+0x17bd7],rcx        # 424040 <__swc_bss_base_fc36583a>
  40c469:	dec    rcx
  40c46c:	call   411fc0 <__swc_fn_fc36583a_000170_360af05d>
  40c471:	mov    rdi,rax
  40c474:	mov    rax,QWORD PTR [rdi+0xbd0]
  40c47b:	xor    ecx,ecx
  40c47d:	test   rax,rax
  40c480:	je     40c485 <__swc_fn_fc36583a_000106_90faaa26+0x45>
  40c482:	mov    rcx,QWORD PTR [rax]
  40c485:	call   40a370 <__swc_fn_fc36583a_000177_718d7b54>
  40c48a:	lea    rax,[rsp+0x8]
  40c48f:	lea    rcx,[rdi+0x9c8]
  40c496:	mov    QWORD PTR [rsp+0x8],rcx
  40c49b:	mov    QWORD PTR [rax+0x8],0x40
  40c4a3:	xor    ecx,ecx
  40c4a5:	mov    rdx,rax
  40c4a8:	call   410320 <__swc_fn_fc36583a_000122_4f256d58>
  40c4ad:	mov    DWORD PTR [rdi+0xbc8],eax
  40c4b3:	mov    rdi,QWORD PTR [rdi+0x990]
  40c4ba:	test   rdi,rdi
  40c4bd:	je     40c4c7 <__swc_fn_fc36583a_000106_90faaa26+0x87>
  40c4bf:	mov    rcx,rsi
  40c4c2:	mov    rdx,rbx
  40c4c5:	call   rdi
  40c4c7:	call   40c1f0 <__swc_fn_fc36583a_000094_ad13d15c>
  40c4cc:	test   al,al
  40c4ce:	je     40c4de <__swc_fn_fc36583a_000106_90faaa26+0x9e>
  40c4d0:	mov    rcx,rsi
  40c4d3:	mov    rdx,rbx
  40c4d6:	xor    r8d,r8d
  40c4d9:	call   409480 <__swc_fn_fc36583a_000123_83db7238>
  40c4de:	mov    rcx,rsi
  40c4e1:	mov    rdx,rbx
  40c4e4:	call   408b00 <__swc_fn_fc36583a_000105_ffe51047>
  40c4e9:	call   40ca70 <__swc_fn_fc36583a_000121_be2e2f68>
  40c4ee:	add    rsp,0x20
  40c4f2:	pop    rdi
  40c4f3:	pop    rsi
  40c4f4:	pop    rbx
  40c4f5:	ret
	...

000000000040c500 <__swc_fn_fc36583a_000109_3dc01326>:
  40c500:	test   r8,r8
  40c503:	jne    40c508 <__swc_fn_fc36583a_000109_3dc01326+0x8>
  40c505:	xor    eax,eax
  40c507:	ret
  40c508:	xor    eax,eax
  40c50a:	nop    WORD PTR [rax+rax*1+0x0]
  40c510:	mov    r9,r8
  40c513:	sub    r9,rax
  40c516:	cmp    r9,0x10
  40c51a:	jb     40c564 <__swc_fn_fc36583a_000109_3dc01326+0x64>
  40c51c:	lea    r9,[rcx+rax*1]
  40c520:	lea    r10,[rdx+rax*1]
  40c524:	vmovups xmm0,XMMWORD PTR [r10]
  40c529:	vmovups xmm1,XMMWORD PTR [r9]
  40c52e:	vpcmpeqb xmm0,xmm1,xmm0
  40c532:	vpmovmskb r9d,xmm0
  40c536:	cmp    r9d,0xffff
  40c53d:	je     40c55e <__swc_fn_fc36583a_000109_3dc01326+0x5e>
  40c53f:	not    r9d
  40c542:	xor    r8d,r8d
  40c545:	movzx  r9d,r9w
  40c549:	tzcnt  r8d,r9d
  40c54e:	add    rax,r8
  40c551:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c555:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c559:	sub    ecx,eax
  40c55b:	mov    eax,ecx
  40c55d:	ret
  40c55e:	lea    rax,[rax+0x10]
  40c562:	jmp    40c510 <__swc_fn_fc36583a_000109_3dc01326+0x10>
  40c564:	cmp    r9,0x8
  40c568:	jb     40c5db <__swc_fn_fc36583a_000109_3dc01326+0xdb>
  40c56a:	lea    r9,[rcx+rax*1]
  40c56e:	lea    r10,[rdx+rax*1]
  40c572:	mov    r9,QWORD PTR [r9]
  40c575:	xor    r9,QWORD PTR [r10]
  40c578:	test   r9,r9
  40c57b:	je     40c599 <__swc_fn_fc36583a_000109_3dc01326+0x99>
  40c57d:	xor    r8d,r8d
  40c580:	tzcnt  r8,r9
  40c585:	shr    r8,0x3
  40c589:	add    rax,r8
  40c58c:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c590:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c594:	sub    ecx,eax
  40c596:	mov    eax,ecx
  40c598:	ret
  40c599:	lea    rax,[rax+0x8]
  40c59d:	cmp    rax,r8
  40c5a0:	jne    40c5a5 <__swc_fn_fc36583a_000109_3dc01326+0xa5>
  40c5a2:	xor    eax,eax
  40c5a4:	ret
  40c5a5:	lea    rax,[r8-0x8]
  40c5a9:	lea    r8,[rcx+rax*1]
  40c5ad:	lea    r9,[rdx+rax*1]
  40c5b1:	mov    r8,QWORD PTR [r8]
  40c5b4:	xor    r8,QWORD PTR [r9]
  40c5b7:	test   r8,r8
  40c5ba:	je     40c5d8 <__swc_fn_fc36583a_000109_3dc01326+0xd8>
  40c5bc:	xor    r9d,r9d
  40c5bf:	tzcnt  r9,r8
  40c5c4:	shr    r9,0x3
  40c5c8:	add    rax,r9
  40c5cb:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c5cf:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c5d3:	sub    ecx,eax
  40c5d5:	mov    eax,ecx
  40c5d7:	ret
  40c5d8:	xor    eax,eax
  40c5da:	ret
  40c5db:	cmp    r9,0x4
  40c5df:	jb     40c652 <__swc_fn_fc36583a_000109_3dc01326+0x152>
  40c5e1:	lea    r9,[rcx+rax*1]
  40c5e5:	lea    r10,[rdx+rax*1]
  40c5e9:	mov    r9d,DWORD PTR [r9]
  40c5ec:	xor    r9d,DWORD PTR [r10]
  40c5ef:	test   r9d,r9d
  40c5f2:	je     40c610 <__swc_fn_fc36583a_000109_3dc01326+0x110>
  40c5f4:	xor    r8d,r8d
  40c5f7:	tzcnt  r8,r9
  40c5fc:	shr    r8,0x3
  40c600:	add    rax,r8
  40c603:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c607:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c60b:	sub    ecx,eax
  40c60d:	mov    eax,ecx
  40c60f:	ret
  40c610:	lea    rax,[rax+0x4]
  40c614:	cmp    rax,r8
  40c617:	jne    40c61c <__swc_fn_fc36583a_000109_3dc01326+0x11c>
  40c619:	xor    eax,eax
  40c61b:	ret
  40c61c:	lea    rax,[r8-0x4]
  40c620:	lea    r8,[rcx+rax*1]
  40c624:	lea    r9,[rdx+rax*1]
  40c628:	mov    r8d,DWORD PTR [r8]
  40c62b:	xor    r8d,DWORD PTR [r9]
  40c62e:	test   r8d,r8d
  40c631:	je     40c64f <__swc_fn_fc36583a_000109_3dc01326+0x14f>
  40c633:	xor    r9d,r9d
  40c636:	tzcnt  r9,r8
  40c63b:	shr    r9,0x3
  40c63f:	add    rax,r9
  40c642:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c646:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c64a:	sub    ecx,eax
  40c64c:	mov    eax,ecx
  40c64e:	ret
  40c64f:	xor    eax,eax
  40c651:	ret
  40c652:	cmp    r9,0x2
  40c656:	jb     40c6a9 <__swc_fn_fc36583a_000109_3dc01326+0x1a9>
  40c658:	lea    r9,[rcx+rax*1]
  40c65c:	lea    r10,[rdx+rax*1]
  40c660:	mov    r9w,WORD PTR [r9]
  40c664:	xor    r9w,WORD PTR [r10]
  40c668:	test   r9w,r9w
  40c66c:	je     40c68e <__swc_fn_fc36583a_000109_3dc01326+0x18e>
  40c66e:	xor    r8d,r8d
  40c671:	movzx  r9d,r9w
  40c675:	tzcnt  r8,r9
  40c67a:	shr    r8,0x3
  40c67e:	add    rax,r8
  40c681:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c685:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c689:	sub    ecx,eax
  40c68b:	mov    eax,ecx
  40c68d:	ret
  40c68e:	lea    rax,[rax+0x2]
  40c692:	cmp    rax,r8
  40c695:	jne    40c69a <__swc_fn_fc36583a_000109_3dc01326+0x19a>
  40c697:	xor    eax,eax
  40c699:	ret
  40c69a:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40c6a0:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40c6a6:	sub    eax,ecx
  40c6a8:	ret
  40c6a9:	test   r9,r9
  40c6ac:	je     40c6bb <__swc_fn_fc36583a_000109_3dc01326+0x1bb>
  40c6ae:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c6b2:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c6b6:	sub    ecx,eax
  40c6b8:	mov    eax,ecx
  40c6ba:	ret
  40c6bb:	xor    eax,eax
  40c6bd:	ret
	...

000000000040c6c0 <__swc_fn_fc36583a_000112_6b799b8d>:
  40c6c0:	push   r12
  40c6c2:	push   r13
  40c6c4:	push   r14
  40c6c6:	push   rdi
  40c6c7:	push   rsi
  40c6c8:	push   r15
  40c6ca:	sub    rsp,0xd8
  40c6d1:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c6d7:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c6dd:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c6e3:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c6e9:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c6ef:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c6f8:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c701:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c70a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c713:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c71c:	mov    r12,rcx
  40c71f:	test   rcx,rcx
  40c722:	je     40c73e <__swc_fn_fc36583a_000112_6b799b8d+0x7e>
  40c724:	mov    eax,r12d
  40c727:	and    eax,0xfff
  40c72d:	setne  al
  40c730:	cmp    r12,0xffffffffffffefff
  40c737:	seta   cl
  40c73a:	or     al,cl
  40c73c:	je     40c745 <__swc_fn_fc36583a_000112_6b799b8d+0x85>
  40c73e:	xor    eax,eax
  40c740:	jmp    40c7db <__swc_fn_fc36583a_000112_6b799b8d+0x11b>
  40c745:	call   4091a0 <__swc_fn_fc36583a_000111_126150d1>
  40c74a:	mov    r13,rax
  40c74d:	test   rax,rax
  40c750:	jne    40c759 <__swc_fn_fc36583a_000112_6b799b8d+0x99>
  40c752:	xor    eax,eax
  40c754:	jmp    40c7db <__swc_fn_fc36583a_000112_6b799b8d+0x11b>
  40c759:	lea    r14,[r12+0x1000]
  40c761:	xor    edi,edi
  40c763:	mov    rsi,r14
  40c766:	xor    edx,edx
  40c768:	mov    ecx,0x22
  40c76d:	mov    eax,0xffffffff
  40c772:	movsxd r8,eax
  40c775:	xor    r9d,r9d
  40c778:	xor    eax,eax
  40c77a:	call   4070c0 <mmap@plt>
  40c77f:	mov    r15,rax
  40c782:	cmp    rax,0xffffffffffffffff
  40c786:	jne    40c78c <__swc_fn_fc36583a_000112_6b799b8d+0xcc>
  40c788:	xor    eax,eax
  40c78a:	jmp    40c7db <__swc_fn_fc36583a_000112_6b799b8d+0x11b>
  40c78c:	mov    rdi,r15
  40c78f:	mov    esi,0x1000
  40c794:	mov    edx,0x3
  40c799:	xor    eax,eax
  40c79b:	call   407030 <mprotect@plt>
  40c7a0:	test   eax,eax
  40c7a2:	je     40c7b5 <__swc_fn_fc36583a_000112_6b799b8d+0xf5>
  40c7a4:	mov    rdi,r15
  40c7a7:	mov    rsi,r14
  40c7aa:	xor    eax,eax
  40c7ac:	call   407020 <munmap@plt>
  40c7b1:	xor    eax,eax
  40c7b3:	jmp    40c7db <__swc_fn_fc36583a_000112_6b799b8d+0x11b>
  40c7b5:	mov    QWORD PTR [r15+0x8],r12
  40c7b9:	mov    rcx,r13
  40c7bc:	call   40ce10 <__swc_fn_fc36583a_000136_8c07c14b>
  40c7c1:	mov    rax,QWORD PTR [r13+0x8]
  40c7c5:	mov    QWORD PTR [r15],rax
  40c7c8:	mov    QWORD PTR [r13+0x8],r15
  40c7cc:	mov    rcx,r13
  40c7cf:	call   4106c0 <__swc_fn_fc36583a_000137_715e84ff>
  40c7d4:	lea    rax,[r15+0x1000]
  40c7db:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c7e1:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c7e7:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c7ed:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c7f3:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c7f9:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c802:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c80b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c814:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c81d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c826:	add    rsp,0xd8
  40c82d:	pop    r15
  40c82f:	pop    rsi
  40c830:	pop    rdi
  40c831:	pop    r14
  40c833:	pop    r13
  40c835:	pop    r12
  40c837:	ret
	...

000000000040c840 <__swc_fn_fc36583a_000115_e9fc0224>:
  40c840:	push   rbx
  40c841:	push   r12
  40c843:	push   rdi
  40c844:	push   rsi
  40c845:	sub    rsp,0xa8
  40c84c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c852:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c858:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c85e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c864:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c86a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c870:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40c876:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40c87c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40c885:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40c88e:	mov    rbx,rdx
  40c891:	mov    r12,rcx
  40c894:	mov    rdi,rcx
  40c897:	mov    rsi,rdx
  40c89a:	xor    edx,edx
  40c89c:	xor    eax,eax
  40c89e:	call   407030 <mprotect@plt>
  40c8a3:	test   eax,eax
  40c8a5:	jne    40c8c9 <__swc_fn_fc36583a_000115_e9fc0224+0x89>
  40c8a7:	mov    rcx,r12
  40c8aa:	mov    rdx,rbx
  40c8ad:	xor    al,al
  40c8af:	mov    r8,rax
  40c8b2:	call   410160 <__swc_fn_fc36583a_000113_5f48311c>
  40c8b7:	mov    rdi,r12
  40c8ba:	mov    rsi,rbx
  40c8bd:	mov    edx,0x4
  40c8c2:	xor    eax,eax
  40c8c4:	call   4070f0 <madvise@plt>
  40c8c9:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40c8cf:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40c8d5:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40c8db:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40c8e1:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40c8e7:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40c8ed:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40c8f3:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40c8f9:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40c902:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40c90b:	add    rsp,0xa8
  40c912:	pop    rsi
  40c913:	pop    rdi
  40c914:	pop    r12
  40c916:	pop    rbx
  40c917:	ret
	...

000000000040c920 <__swc_fn_fc36583a_000118_d3318640>:
  40c920:	push   rsi
  40c921:	push   rdi
  40c922:	push   r12
  40c924:	push   r13
  40c926:	push   r14
  40c928:	sub    rsp,0xe0
  40c92f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c935:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c93b:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c941:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c947:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c94d:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c956:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c95f:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c968:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c971:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c97a:	mov    rsi,rdx
  40c97d:	mov    rdi,rcx
  40c980:	call   4091a0 <__swc_fn_fc36583a_000111_126150d1>
  40c985:	mov    r12,rax
  40c988:	test   rax,rax
  40c98b:	jne    40c992 <__swc_fn_fc36583a_000118_d3318640+0x72>
  40c98d:	jmp    40ca06 <__swc_fn_fc36583a_000118_d3318640+0xe6>
  40c992:	mov    rcx,r12
  40c995:	call   40ce10 <__swc_fn_fc36583a_000136_8c07c14b>
  40c99a:	lea    r13,[r12+0x8]
  40c99f:	mov    rax,QWORD PTR [r13+0x0]
  40c9a3:	test   rax,rax
  40c9a6:	je     40c9fe <__swc_fn_fc36583a_000118_d3318640+0xde>
  40c9a8:	nop    DWORD PTR [rax+rax*1+0x0]
  40c9b0:	lea    rcx,[rax+0x1000]
  40c9b7:	cmp    rcx,rdi
  40c9ba:	jne    40c9f2 <__swc_fn_fc36583a_000118_d3318640+0xd2>
  40c9bc:	cmp    QWORD PTR [rax+0x8],rsi
  40c9c0:	je     40c9cc <__swc_fn_fc36583a_000118_d3318640+0xac>
  40c9c2:	mov    rcx,r12
  40c9c5:	call   4106c0 <__swc_fn_fc36583a_000137_715e84ff>
  40c9ca:	jmp    40ca06 <__swc_fn_fc36583a_000118_d3318640+0xe6>
  40c9cc:	mov    r14,QWORD PTR [rax]
  40c9cf:	mov    rdi,rax
  40c9d2:	lea    rsi,[rsi+0x1000]
  40c9d9:	xor    eax,eax
  40c9db:	call   407020 <munmap@plt>
  40c9e0:	test   eax,eax
  40c9e2:	jne    40c9e8 <__swc_fn_fc36583a_000118_d3318640+0xc8>
  40c9e4:	mov    QWORD PTR [r13+0x0],r14
  40c9e8:	mov    rcx,r12
  40c9eb:	call   4106c0 <__swc_fn_fc36583a_000137_715e84ff>
  40c9f0:	jmp    40ca06 <__swc_fn_fc36583a_000118_d3318640+0xe6>
  40c9f2:	mov    r13,rax
  40c9f5:	mov    rax,QWORD PTR [r13+0x0]
  40c9f9:	test   rax,rax
  40c9fc:	jne    40c9b0 <__swc_fn_fc36583a_000118_d3318640+0x90>
  40c9fe:	mov    rcx,r12
  40ca01:	call   4106c0 <__swc_fn_fc36583a_000137_715e84ff>
  40ca06:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40ca0c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40ca12:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40ca18:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40ca1e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40ca24:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40ca2d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40ca36:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40ca3f:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40ca48:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40ca51:	add    rsp,0xe0
  40ca58:	pop    r14
  40ca5a:	pop    r13
  40ca5c:	pop    r12
  40ca5e:	pop    rdi
  40ca5f:	pop    rsi
  40ca60:	ret
	...

000000000040ca70 <__swc_fn_fc36583a_000121_be2e2f68>:
  40ca70:	push   rdi
  40ca71:	push   rsi
  40ca72:	sub    rsp,0xa8
  40ca79:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ca7f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ca85:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ca8b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40ca91:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40ca97:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40ca9d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40caa3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40caa9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cab2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cabb:	mov    rdi,0xfffffffffffffd66
  40cac2:	xor    eax,eax
  40cac4:	call   407040 <exit@plt>
  40cac9:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cacf:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cad5:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cadb:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cae1:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cae7:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40caed:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40caf3:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40caf9:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cb02:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cb0b:	add    rsp,0xa8
  40cb12:	pop    rsi
  40cb13:	pop    rdi
  40cb14:	ret
	...

000000000040cb20 <__swc_fn_fc36583a_000124_540bf7e8>:
  40cb20:	push   rbx
  40cb21:	push   rsi
  40cb22:	push   rdi
  40cb23:	sub    rsp,0x30
  40cb27:	mov    rbx,rdx
  40cb2a:	mov    esi,ecx
  40cb2c:	test   ecx,ecx
  40cb2e:	je     40cc03 <__swc_fn_fc36583a_000124_540bf7e8+0xe3>
  40cb34:	mov    rcx,rsi
  40cb37:	shl    rcx,0x4
  40cb3b:	call   40c030 <__swc_fn_fc36583a_000082_4a10c7e7>
  40cb40:	test   rax,rax
  40cb43:	je     40cbf2 <__swc_fn_fc36583a_000124_540bf7e8+0xd2>
  40cb49:	mov    rcx,rsi
  40cb4c:	xor    edx,edx
  40cb4e:	test   rsi,rsi
  40cb51:	jbe    40cbd2 <__swc_fn_fc36583a_000124_540bf7e8+0xb2>
  40cb57:	nop    WORD PTR [rax+rax*1+0x0]
  40cb60:	mov    r8d,edx
  40cb63:	mov    r9,QWORD PTR [rbx+r8*8]
  40cb67:	add    r8,r8
  40cb6a:	lea    r8,[rax+r8*8]
  40cb6e:	xor    r10d,r10d
  40cb71:	test   r9,r9
  40cb74:	je     40cbb0 <__swc_fn_fc36583a_000124_540bf7e8+0x90>
  40cb76:	mov    r11,r9
  40cb79:	mov    dil,BYTE PTR [r11]
  40cb7c:	test   dil,dil
  40cb7f:	je     40cbb0 <__swc_fn_fc36583a_000124_540bf7e8+0x90>
  40cb81:	cs nop WORD PTR [rax+rax*1+0x0]
  40cb8b:	cs nop WORD PTR [rax+rax*1+0x0]
  40cb95:	cs nop WORD PTR [rax+rax*1+0x0]
  40cb9f:	nop
  40cba0:	add    r11,0x1
  40cba4:	add    r10,0x1
  40cba8:	mov    dil,BYTE PTR [r11]
  40cbab:	test   dil,dil
  40cbae:	jne    40cba0 <__swc_fn_fc36583a_000124_540bf7e8+0x80>
  40cbb0:	mov    QWORD PTR [rsp+0x18],r9
  40cbb5:	mov    QWORD PTR [rsp+0x20],r10
  40cbba:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40cbc0:	vmovups XMMWORD PTR [r8],xmm0
  40cbc5:	add    rdx,0x1
  40cbc9:	cmp    rdx,rcx
  40cbcc:	jb     40cb60 <__swc_fn_fc36583a_000124_540bf7e8+0x40>
  40cbd2:	lea    rcx,[rip+0x1a16f]        # 426d48 <__swc_bss_base_fc36583a+0x2d08>
  40cbd9:	mov    QWORD PTR [rsp+0x8],rax
  40cbde:	mov    esi,esi
  40cbe0:	mov    QWORD PTR [rsp+0x10],rsi
  40cbe5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40cbeb:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40cbf0:	jmp    40cc03 <__swc_fn_fc36583a_000124_540bf7e8+0xe3>
  40cbf2:	lea    rcx,[rip+0x69f7]        # 4135f0 <__swc_rdata_base_fc36583a+0x4e0>
  40cbf9:	call   410210 <__swc_fn_fc36583a_000119_2648f149>
  40cbfe:	call   40ca70 <__swc_fn_fc36583a_000121_be2e2f68>
  40cc03:	add    rsp,0x30
  40cc07:	pop    rdi
  40cc08:	pop    rsi
  40cc09:	pop    rbx
  40cc0a:	ret
  40cc0b:	add    BYTE PTR [rax],al
  40cc0d:	add    BYTE PTR [rax],al
	...

000000000040cc10 <__swc_fn_fc36583a_000127_a481cb88>:
  40cc10:	push   rdi
  40cc11:	push   rsi
  40cc12:	sub    rsp,0xa8
  40cc19:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cc1f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cc25:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cc2b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cc31:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cc37:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cc3d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cc43:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cc49:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cc52:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cc5b:	mov    edi,ecx
  40cc5d:	xor    eax,eax
  40cc5f:	call   407100 <pthread_key_delete@plt>
  40cc64:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cc6a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cc70:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cc76:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cc7c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cc82:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cc88:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cc8e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cc94:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cc9d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cca6:	add    rsp,0xa8
  40ccad:	pop    rsi
  40ccae:	pop    rdi
  40ccaf:	ret

000000000040ccb0 <__swc_fn_fc36583a_000130_a611b8c4>:
  40ccb0:	push   rdi
  40ccb1:	push   rsi
  40ccb2:	sub    rsp,0xa8
  40ccb9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ccbf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ccc5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cccb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40ccd1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40ccd7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40ccdd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cce3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cce9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ccf2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ccfb:	test   rcx,rcx
  40ccfe:	je     40cd0f <__swc_fn_fc36583a_000130_a611b8c4+0x5f>
  40cd00:	lea    rax,[rcx-0x1]
  40cd04:	mov    eax,eax
  40cd06:	mov    edi,eax
  40cd08:	xor    eax,eax
  40cd0a:	call   407100 <pthread_key_delete@plt>
  40cd0f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cd15:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cd1b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cd21:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cd27:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cd2d:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cd33:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cd39:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cd3f:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cd48:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cd51:	add    rsp,0xa8
  40cd58:	pop    rsi
  40cd59:	pop    rdi
  40cd5a:	ret
  40cd5b:	add    BYTE PTR [rax],al
  40cd5d:	add    BYTE PTR [rax],al
	...

000000000040cd60 <__swc_fn_fc36583a_000133_a9c1c700>:
  40cd60:	push   rsi
  40cd61:	push   rdi
  40cd62:	sub    rsp,0xa8
  40cd69:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cd6f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cd75:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cd7b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cd81:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cd87:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cd8d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cd93:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cd99:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cda2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cdab:	xor    eax,eax
  40cdad:	call   407110 <gettid@plt>
  40cdb2:	movsxd rax,eax
  40cdb5:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cdbb:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cdc1:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cdc7:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cdcd:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cdd3:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cdd9:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cddf:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cde5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cdee:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cdf7:	add    rsp,0xa8
  40cdfe:	pop    rdi
  40cdff:	pop    rsi
  40ce00:	ret
	...

000000000040ce10 <__swc_fn_fc36583a_000136_8c07c14b>:
  40ce10:	push   rbx
  40ce11:	push   rdi
  40ce12:	push   rsi
  40ce13:	sub    rsp,0xc0
  40ce1a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40ce20:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40ce26:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40ce2c:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40ce32:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40ce38:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40ce3e:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40ce44:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40ce4d:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40ce56:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40ce5f:	mov    rbx,rcx
  40ce62:	cs nop WORD PTR [rax+rax*1+0x0]
  40ce6c:	nop    DWORD PTR [rax+0x0]
  40ce70:	mov    edx,0x80000000
  40ce75:	xor    eax,eax
  40ce77:	lock cmpxchg DWORD PTR [rbx],edx
  40ce7b:	test   eax,eax
  40ce7d:	je     40ceb4 <__swc_fn_fc36583a_000136_8c07c14b+0xa4>
  40ce7f:	mov    eax,DWORD PTR [rbx]
  40ce81:	lea    rcx,[rsp+0x14]
  40ce86:	mov    DWORD PTR [rsp+0x14],eax
  40ce8a:	test   eax,eax
  40ce8c:	je     40ce70 <__swc_fn_fc36583a_000136_8c07c14b+0x60>
  40ce8e:	mov    QWORD PTR [rsp],0x0
  40ce96:	mov    edi,0xca
  40ce9b:	mov    rsi,rbx
  40ce9e:	mov    edx,0x80
  40cea3:	mov    ecx,DWORD PTR [rcx]
  40cea5:	xor    r8d,r8d
  40cea8:	xor    r9d,r9d
  40ceab:	xor    eax,eax
  40cead:	call   407070 <syscall@plt>
  40ceb2:	jmp    40ce70 <__swc_fn_fc36583a_000136_8c07c14b+0x60>
  40ceb4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ceba:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40cec0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40cec6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40cecc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ced2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ced8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40cede:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40cee7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40cef0:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40cef9:	add    rsp,0xc0
  40cf00:	pop    rsi
  40cf01:	pop    rdi
  40cf02:	pop    rbx
  40cf03:	ret
	...

000000000040cf10 <__swc_fn_fc36583a_000139_055b38a4>:
  40cf10:	sub    rsp,0x8
  40cf14:	call   4106c0 <__swc_fn_fc36583a_000137_715e84ff>
  40cf19:	add    rsp,0x8
  40cf1d:	ret
	...

000000000040cf20 <__swc_fn_fc36583a_000142_d299b428>:
  40cf20:	push   rdi
  40cf21:	push   rsi
  40cf22:	sub    rsp,0xa8
  40cf29:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cf2f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cf35:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cf3b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cf41:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cf47:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cf4d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cf53:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cf59:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cf62:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cf6b:	mov    edi,0x28
  40cf70:	xor    eax,eax
  40cf72:	call   4070d0 <malloc@plt>
  40cf77:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cf7d:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cf83:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cf89:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cf8f:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cf95:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cf9b:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cfa1:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cfa7:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cfb0:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cfb9:	add    rsp,0xa8
  40cfc0:	pop    rsi
  40cfc1:	pop    rdi
  40cfc2:	ret
	...

000000000040cfd0 <__swc_fn_fc36583a_000145_162f363d>:
  40cfd0:	mov    QWORD PTR [r8],0x0
  40cfd7:	cmp    rdx,0x10
  40cfdb:	jae    40cfe0 <__swc_fn_fc36583a_000145_162f363d+0x10>
  40cfdd:	xor    eax,eax
  40cfdf:	ret
  40cfe0:	mov    eax,DWORD PTR [rcx]
  40cfe2:	cmp    eax,0x42445753
  40cfe8:	jne    40cff2 <__swc_fn_fc36583a_000145_162f363d+0x22>
  40cfea:	mov    eax,DWORD PTR [rcx+0x4]
  40cfed:	cmp    eax,0x1
  40cff0:	je     40cff5 <__swc_fn_fc36583a_000145_162f363d+0x25>
  40cff2:	xor    eax,eax
  40cff4:	ret
  40cff5:	mov    QWORD PTR [r8],rdx
  40cff8:	mov    rax,rcx
  40cffb:	ret
  40cffc:	add    BYTE PTR [rax],al
	...

000000000040d000 <__swc_fn_fc36583a_000148_2eb804cc>:
  40d000:	push   rbx
  40d001:	sub    rsp,0xe0
  40d008:	lea    rbx,[rsp+0x8]
  40d00d:	vxorps xmm0,xmm0,xmm0
  40d011:	vmovups YMMWORD PTR [rbx],ymm0
  40d015:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40d01a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40d01f:	vzeroupper
  40d022:	mov    DWORD PTR [rbx+0x60],0x0
  40d029:	mov    r8,rbx
  40d02c:	mov    rdx,rcx
  40d02f:	nop
  40d030:	mov    r9,rdx
  40d033:	movabs rdx,0x6666666666666667
  40d03d:	mov    rax,r9
  40d040:	imul   rdx
  40d043:	sar    rdx,0x2
  40d047:	mov    r10,rdx
  40d04a:	shr    rdx,0x3f
  40d04e:	add    r10,rdx
  40d051:	mov    rdx,r10
  40d054:	imul   r11,r10,0xa
  40d058:	sub    r9,r11
  40d05b:	mov    r11,QWORD PTR [rip+0x65ae]        # 413610 <__swc_rdata_base_fc36583a+0x500>
  40d062:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40d067:	mov    BYTE PTR [r8],r9b
  40d06a:	lea    r9,[r8+0x1]
  40d06e:	mov    r8,r9
  40d071:	test   r10,r10
  40d074:	jne    40d030 <__swc_fn_fc36583a_000148_2eb804cc+0x30>
  40d076:	test   rcx,rcx
  40d079:	jge    40d083 <__swc_fn_fc36583a_000148_2eb804cc+0x83>
  40d07b:	mov    BYTE PTR [r9],0x2d
  40d07f:	add    r8,0x1
  40d083:	mov    BYTE PTR [r8],0x0
  40d087:	sub    r8,0x1
  40d08b:	mov    rax,rbx
  40d08e:	cmp    rax,r8
  40d091:	jae    40d0b6 <__swc_fn_fc36583a_000148_2eb804cc+0xb6>
  40d093:	cs nop WORD PTR [rax+rax*1+0x0]
  40d09d:	nop    DWORD PTR [rax]
  40d0a0:	mov    cl,BYTE PTR [r8]
  40d0a3:	mov    dl,BYTE PTR [rax]
  40d0a5:	mov    BYTE PTR [r8],dl
  40d0a8:	sub    r8,0x1
  40d0ac:	mov    BYTE PTR [rax],cl
  40d0ae:	inc    rax
  40d0b1:	cmp    rax,r8
  40d0b4:	jb     40d0a0 <__swc_fn_fc36583a_000148_2eb804cc+0xa0>
  40d0b6:	xor    eax,eax
  40d0b8:	test   rbx,rbx
  40d0bb:	je     40d0de <__swc_fn_fc36583a_000148_2eb804cc+0xde>
  40d0bd:	mov    rcx,rbx
  40d0c0:	mov    dl,BYTE PTR [rcx]
  40d0c2:	test   dl,dl
  40d0c4:	je     40d0de <__swc_fn_fc36583a_000148_2eb804cc+0xde>
  40d0c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40d0d0:	add    rcx,0x1
  40d0d4:	add    rax,0x1
  40d0d8:	mov    dl,BYTE PTR [rcx]
  40d0da:	test   dl,dl
  40d0dc:	jne    40d0d0 <__swc_fn_fc36583a_000148_2eb804cc+0xd0>
  40d0de:	mov    QWORD PTR [rbx+0xa8],rbx
  40d0e5:	mov    QWORD PTR [rbx+0xb0],rax
  40d0ec:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d0f4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d0fc:	lea    rcx,[rbx+0xb8]
  40d103:	call   410210 <__swc_fn_fc36583a_000119_2648f149>
  40d108:	add    rsp,0xe0
  40d10f:	pop    rbx
  40d110:	ret
	...

000000000040d120 <__swc_fn_fc36583a_000151_86f1d437>:
  40d120:	vxorps xmm0,xmm0,xmm0
  40d124:	vmovups XMMWORD PTR [rcx],xmm0
  40d128:	mov    QWORD PTR [rcx+0x10],0x0
  40d130:	ret
	...

000000000040d140 <__swc_fn_fc36583a_000154_86f1d437>:
  40d140:	vxorps xmm0,xmm0,xmm0
  40d144:	vmovups XMMWORD PTR [rcx],xmm0
  40d148:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d14d:	vxorps xmm0,xmm0,xmm0
  40d151:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d156:	vmovups xmm0,XMMWORD PTR [rip+0x65aa]        # 413708 <__swc_rdata_base_fc36583a+0x5f8>
  40d15e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d163:	vxorps xmm0,xmm0,xmm0
  40d167:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d16c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d171:	mov    QWORD PTR [rcx+0x60],0x0
  40d179:	ret
  40d17a:	add    BYTE PTR [rax],al
  40d17c:	add    BYTE PTR [rax],al
	...

000000000040d180 <__swc_fn_fc36583a_000157_86f1d437>:
  40d180:	vxorps xmm0,xmm0,xmm0
  40d184:	vmovups XMMWORD PTR [rcx],xmm0
  40d188:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d18d:	vxorps xmm0,xmm0,xmm0
  40d191:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d196:	vmovups xmm0,XMMWORD PTR [rip+0x6692]        # 413830 <__swc_rdata_base_fc36583a+0x720>
  40d19e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d1a3:	vxorps xmm0,xmm0,xmm0
  40d1a7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d1ac:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d1b1:	vxorps xmm0,xmm0,xmm0
  40d1b5:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40d1ba:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40d1bf:	vxorps xmm0,xmm0,xmm0
  40d1c3:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40d1cb:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40d1d3:	vxorps xmm0,xmm0,xmm0
  40d1d7:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40d1df:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40d1e7:	vxorps xmm0,xmm0,xmm0
  40d1eb:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40d1f3:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40d1fb:	mov    QWORD PTR [rcx+0xe0],0x0
  40d206:	ret
	...

000000000040d210 <__swc_fn_fc36583a_000160_13ead2ff>:
  40d210:	push   rbx
  40d211:	mov    rbx,rcx
  40d214:	call   411c50 <__swc_fn_fc36583a_000161_e36363a8>
  40d219:	mov    rax,QWORD PTR [rbx+0x10]
  40d21d:	test   rax,rax
  40d220:	je     40d231 <__swc_fn_fc36583a_000160_13ead2ff+0x21>
  40d222:	mov    rcx,rbx
  40d225:	mov    rdx,rax
  40d228:	mov    r8,QWORD PTR [rbx+0x18]
  40d22c:	call   409f30 <__swc_fn_fc36583a_000159_47b270e1>
  40d231:	vxorps xmm0,xmm0,xmm0
  40d235:	vmovups XMMWORD PTR [rbx],xmm0
  40d239:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d23e:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d243:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d248:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d24d:	mov    QWORD PTR [rbx+0x50],0x0
  40d255:	pop    rbx
  40d256:	ret
	...

000000000040d260 <__swc_fn_fc36583a_000163_72795826>:
  40d260:	sub    rsp,0x10
  40d264:	mov    eax,r8d
  40d267:	mov    r8d,r9d
  40d26a:	test   r9d,r9d
  40d26d:	jne    40d286 <__swc_fn_fc36583a_000163_72795826+0x26>
  40d26f:	vmovups xmm0,XMMWORD PTR [rip+0x6671]        # 4138e8 <__swc_rdata_base_fc36583a+0x7d8>
  40d277:	vmovups XMMWORD PTR [r10],xmm0
  40d27c:	mov    eax,0x1
  40d281:	add    rsp,0x10
  40d285:	ret
  40d286:	mov    r9,r8
  40d289:	cmp    r8,rax
  40d28c:	jb     40d293 <__swc_fn_fc36583a_000163_72795826+0x33>
  40d28e:	cmp    r9,rdx
  40d291:	jb     40d29a <__swc_fn_fc36583a_000163_72795826+0x3a>
  40d293:	xor    eax,eax
  40d295:	add    rsp,0x10
  40d299:	ret
  40d29a:	xor    eax,eax
  40d29c:	lea    r8,[r9+rax*1]
  40d2a0:	cmp    r8,rdx
  40d2a3:	jae    40d2d3 <__swc_fn_fc36583a_000163_72795826+0x73>
  40d2a5:	cs nop WORD PTR [rax+rax*1+0x0]
  40d2af:	cs nop WORD PTR [rax+rax*1+0x0]
  40d2b9:	nop    DWORD PTR [rax+0x0]
  40d2c0:	cmp    BYTE PTR [rcx+r8*1],0x0
  40d2c5:	je     40d2d3 <__swc_fn_fc36583a_000163_72795826+0x73>
  40d2c7:	inc    rax
  40d2ca:	lea    r8,[r9+rax*1]
  40d2ce:	cmp    r8,rdx
  40d2d1:	jb     40d2c0 <__swc_fn_fc36583a_000163_72795826+0x60>
  40d2d3:	cmp    r8,rdx
  40d2d6:	jne    40d2df <__swc_fn_fc36583a_000163_72795826+0x7f>
  40d2d8:	xor    eax,eax
  40d2da:	add    rsp,0x10
  40d2de:	ret
  40d2df:	add    rcx,r9
  40d2e2:	mov    QWORD PTR [rsp],rcx
  40d2e6:	mov    QWORD PTR [rsp+0x8],rax
  40d2eb:	vmovups xmm0,XMMWORD PTR [rsp]
  40d2f0:	vmovups XMMWORD PTR [r10],xmm0
  40d2f5:	mov    eax,0x1
  40d2fa:	add    rsp,0x10
  40d2fe:	ret
	...

000000000040d300 <__swc_fn_fc36583a_000166_bcc835b8>:
  40d300:	push   rbp
  40d301:	push   rbx
  40d302:	push   rsi
  40d303:	push   rdi
  40d304:	push   r12
  40d306:	push   r13
  40d308:	push   r14
  40d30a:	push   r15
  40d30c:	sub    rsp,0x10
  40d310:	mov    rbp,rsp
  40d313:	vmovups XMMWORD PTR [rsp],xmm6
  40d318:	sub    rsp,0x50
  40d31c:	mov    rbx,rsp
  40d31f:	mov    rsi,r8
  40d322:	mov    QWORD PTR [rsp+0x30],r8
  40d327:	mov    rdi,rcx
  40d32a:	mov    QWORD PTR [rsp+0x38],rcx
  40d32f:	mov    r12,rdx
  40d332:	xor    r13b,r13b
  40d335:	mov    r14,QWORD PTR [rdi+0x8]
  40d339:	mov    QWORD PTR [rsp+0x40],r14
  40d33e:	xor    r15d,r15d
  40d341:	test   r14,r14
  40d344:	jbe    40d59e <__swc_fn_fc36583a_000166_bcc835b8+0x29e>
  40d34a:	mov    r14,QWORD PTR [rdi]
  40d34d:	mov    rax,QWORD PTR [rsp+0x40]
  40d352:	mov    QWORD PTR [rsp+0x48],r14
  40d357:	vmovups xmm6,XMMWORD PTR [rip+0x61a9]        # 413508 <__swc_rdata_base_fc36583a+0x3f8>
  40d35f:	nop
  40d360:	cmp    QWORD PTR [r14+r15*8],0x0
  40d365:	jne    40d36f <__swc_fn_fc36583a_000166_bcc835b8+0x6f>
  40d367:	mov    r14,rax
  40d36a:	jmp    40d57e <__swc_fn_fc36583a_000166_bcc835b8+0x27e>
  40d36f:	mov    rcx,QWORD PTR [rdi]
  40d372:	mov    rdx,QWORD PTR [rcx+r15*8]
  40d376:	mov    rdi,rbx
  40d379:	mov    rcx,rdi
  40d37c:	sub    rsp,0x8
  40d380:	mov    r14,rax
  40d383:	call   409fb0 <__swc_fn_fc36583a_000165_cc119975>
  40d388:	add    rsp,0x8
  40d38c:	mov    al,BYTE PTR [rbx]
  40d38e:	test   al,al
  40d390:	je     40d57e <__swc_fn_fc36583a_000166_bcc835b8+0x27e>
  40d396:	mov    al,BYTE PTR [rbx+0x1]
  40d399:	test   al,al
  40d39b:	jne    40d3a6 <__swc_fn_fc36583a_000166_bcc835b8+0xa6>
  40d39d:	test   sil,sil
  40d3a0:	je     40d57e <__swc_fn_fc36583a_000166_bcc835b8+0x27e>
  40d3a6:	test   r13b,r13b
  40d3a9:	jne    40d467 <__swc_fn_fc36583a_000166_bcc835b8+0x167>
  40d3af:	test   r12,r12
  40d3b2:	je     40d467 <__swc_fn_fc36583a_000166_bcc835b8+0x167>
  40d3b8:	mov    al,BYTE PTR [rbx+0x1]
  40d3bb:	test   al,al
  40d3bd:	je     40d57e <__swc_fn_fc36583a_000166_bcc835b8+0x27e>
  40d3c3:	mov    eax,DWORD PTR [rbx+0x28]
  40d3c6:	cmp    DWORD PTR [r12+0x20],eax
  40d3cb:	jne    40d57e <__swc_fn_fc36583a_000166_bcc835b8+0x27e>
  40d3d1:	mov    rax,QWORD PTR [r12]
  40d3d5:	mov    rcx,QWORD PTR [r12+0x8]
  40d3da:	cmp    QWORD PTR [rbx+0x20],rcx
  40d3de:	jne    40d57e <__swc_fn_fc36583a_000166_bcc835b8+0x27e>
  40d3e4:	mov    cl,0x1
  40d3e6:	test   rax,rax
  40d3e9:	je     40d452 <__swc_fn_fc36583a_000166_bcc835b8+0x152>
  40d3ef:	mov    rdx,QWORD PTR [rbx+0x20]
  40d3f3:	xor    r8d,r8d
  40d3f6:	test   rdx,rdx
  40d3f9:	jbe    40d452 <__swc_fn_fc36583a_000166_bcc835b8+0x152>
  40d3fb:	mov    r9,QWORD PTR [rbx+0x18]
  40d3ff:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40d404:	cs nop WORD PTR [rax+rax*1+0x0]
  40d40e:	xchg   ax,ax
  40d410:	mov    r10b,BYTE PTR [rax+r8*1]
  40d414:	cmp    BYTE PTR [r9+r8*1],r10b
  40d418:	je     40d449 <__swc_fn_fc36583a_000166_bcc835b8+0x149>
  40d41a:	vmovq  r10,xmm0
  40d41f:	cmp    BYTE PTR [r10+r8*1],0x5c
  40d424:	jne    40d42d <__swc_fn_fc36583a_000166_bcc835b8+0x12d>
  40d426:	cmp    BYTE PTR [rax+r8*1],0x2f
  40d42b:	je     40d449 <__swc_fn_fc36583a_000166_bcc835b8+0x149>
  40d42d:	vmovq  r10,xmm0
  40d432:	cmp    BYTE PTR [r10+r8*1],0x2f
  40d437:	jne    40d440 <__swc_fn_fc36583a_000166_bcc835b8+0x140>
  40d439:	cmp    BYTE PTR [rax+r8*1],0x5c
  40d43e:	je     40d449 <__swc_fn_fc36583a_000166_bcc835b8+0x149>
  40d440:	xor    eax,eax
  40d442:	movzx  eax,al
  40d445:	mov    cl,al
  40d447:	jmp    40d452 <__swc_fn_fc36583a_000166_bcc835b8+0x152>
  40d449:	add    r8,0x1
  40d44d:	cmp    r8,rdx
  40d450:	jb     40d410 <__swc_fn_fc36583a_000166_bcc835b8+0x110>
  40d452:	test   cl,cl
  40d454:	je     40d57e <__swc_fn_fc36583a_000166_bcc835b8+0x27e>
  40d45a:	mov    eax,0x1
  40d45f:	mov    r13b,al
  40d462:	jmp    40d57e <__swc_fn_fc36583a_000166_bcc835b8+0x27e>
  40d467:	mov    r13b,0x1
  40d46a:	sub    rsp,0x20
  40d46e:	mov    rax,rsp
  40d471:	lea    rcx,[rdi+0x8]
  40d475:	mov    QWORD PTR [rax],rcx
  40d478:	lea    rsi,[rip+0x5cb1]        # 413130 <__swc_rdata_base_fc36583a+0x20>
  40d47f:	mov    QWORD PTR [rax+0x8],rsi
  40d483:	mov    QWORD PTR [rax+0x10],rsp
  40d487:	mov    QWORD PTR [rax+0x18],0x1
  40d48f:	lea    rcx,[rsp+0x10]
  40d494:	sub    rsp,0x8
  40d498:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  40d49d:	add    rsp,0x8
  40d4a1:	add    rsp,0x20
  40d4a5:	mov    al,BYTE PTR [rbx+0x1]
  40d4a8:	test   al,al
  40d4aa:	je     40d547 <__swc_fn_fc36583a_000166_bcc835b8+0x247>
  40d4b0:	lea    rax,[rip+0x64d1]        # 413988 <__swc_rdata_base_fc36583a+0x878>
  40d4b7:	sub    rsp,0x20
  40d4bb:	mov    rcx,rsp
  40d4be:	mov    QWORD PTR [rcx],rax
  40d4c1:	mov    QWORD PTR [rcx+0x8],rsi
  40d4c5:	mov    QWORD PTR [rcx+0x10],rsp
  40d4c9:	mov    QWORD PTR [rcx+0x18],0x1
  40d4d1:	lea    rcx,[rsp+0x10]
  40d4d6:	sub    rsp,0x8
  40d4da:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  40d4df:	add    rsp,0x8
  40d4e3:	add    rsp,0x20
  40d4e7:	mov    eax,DWORD PTR [rbx+0x28]
  40d4ea:	sub    rsp,0x60
  40d4ee:	mov    rcx,rsp
  40d4f1:	lea    rdx,[rdi+0x18]
  40d4f5:	mov    QWORD PTR [rcx+0x18],rdx
  40d4f9:	mov    QWORD PTR [rcx+0x20],rsi
  40d4fd:	vmovups XMMWORD PTR [rcx],xmm6
  40d501:	mov    QWORD PTR [rcx+0x28],rsp
  40d505:	mov    QWORD PTR [rcx+0x30],rsi
  40d509:	mov    DWORD PTR [rcx+0x10],eax
  40d50c:	lea    rax,[rsp+0x10]
  40d511:	mov    QWORD PTR [rcx+0x38],rax
  40d515:	lea    rax,[rip+0x5f84]        # 4134a0 <__swc_rdata_base_fc36583a+0x390>
  40d51c:	mov    QWORD PTR [rcx+0x40],rax
  40d520:	lea    rax,[rsp+0x18]
  40d525:	mov    QWORD PTR [rcx+0x48],rax
  40d529:	mov    QWORD PTR [rcx+0x50],0x3
  40d531:	lea    rcx,[rsp+0x48]
  40d536:	sub    rsp,0x8
  40d53a:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  40d53f:	add    rsp,0x8
  40d543:	add    rsp,0x60
  40d547:	lea    rax,[rip+0x5bd2]        # 413120 <__swc_rdata_base_fc36583a+0x10>
  40d54e:	sub    rsp,0x20
  40d552:	mov    rcx,rsp
  40d555:	mov    QWORD PTR [rcx],rax
  40d558:	mov    QWORD PTR [rcx+0x8],rsi
  40d55c:	mov    QWORD PTR [rcx+0x10],rsp
  40d560:	mov    QWORD PTR [rcx+0x18],0x1
  40d568:	lea    rcx,[rsp+0x10]
  40d56d:	sub    rsp,0x8
  40d571:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  40d576:	add    rsp,0x8
  40d57a:	add    rsp,0x20
  40d57e:	add    r15,0x1
  40d582:	cmp    r15,r14
  40d585:	jae    40d59e <__swc_fn_fc36583a_000166_bcc835b8+0x29e>
  40d587:	mov    rsi,QWORD PTR [rsp+0x30]
  40d58c:	mov    rdi,QWORD PTR [rsp+0x38]
  40d591:	mov    rax,r14
  40d594:	mov    r14,QWORD PTR [rsp+0x48]
  40d599:	jmp    40d360 <__swc_fn_fc36583a_000166_bcc835b8+0x60>
  40d59e:	add    rsp,0x50
  40d5a2:	vmovups xmm6,XMMWORD PTR [rsp]
  40d5a7:	add    rsp,0x10
  40d5ab:	pop    r15
  40d5ad:	pop    r14
  40d5af:	pop    r13
  40d5b1:	pop    r12
  40d5b3:	pop    rdi
  40d5b4:	pop    rsi
  40d5b5:	pop    rbx
  40d5b6:	pop    rbp
  40d5b7:	ret
	...

000000000040d5c0 <__swc_fn_fc36583a_000169_646fdf20>:
  40d5c0:	sub    rsp,0x8
  40d5c4:	call   410490 <__swc_fn_fc36583a_000128_4bbe3f14>
  40d5c9:	add    rsp,0x8
  40d5cd:	ret
	...

000000000040d5d0 <__swc_fn_fc36583a_000172_1e0ea8cf>:
  40d5d0:	push   rsi
  40d5d1:	sub    rsp,0x30
  40d5d5:	lea    rsi,[rip+0x197bc]        # 426d98 <__swc_bss_base_fc36583a+0x2d58>
  40d5dc:	mov    rax,QWORD PTR [rsi]
  40d5df:	test   rax,rax
  40d5e2:	je     40d5ea <__swc_fn_fc36583a_000172_1e0ea8cf+0x1a>
  40d5e4:	add    rsp,0x30
  40d5e8:	pop    rsi
  40d5e9:	ret
  40d5ea:	mov    ecx,0x2
  40d5ef:	mov    edx,0x8020
  40d5f4:	call   40fb30 <__swc_fn_fc36583a_000110_6814119b>
  40d5f9:	test   rax,rax
  40d5fc:	jne    40d60d <__swc_fn_fc36583a_000172_1e0ea8cf+0x3d>
  40d5fe:	mov    QWORD PTR [rsp+0x18],rax
  40d603:	call   40ca70 <__swc_fn_fc36583a_000121_be2e2f68>
  40d608:	mov    rax,QWORD PTR [rsp+0x18]
  40d60d:	mov    rcx,rax
  40d610:	xchg   QWORD PTR [rsi],rcx
  40d613:	add    rsp,0x30
  40d617:	pop    rsi
  40d618:	ret
  40d619:	add    BYTE PTR [rax],al
  40d61b:	add    BYTE PTR [rax],al
  40d61d:	add    BYTE PTR [rax],al
	...

000000000040d620 <__swc_fn_fc36583a_000175_4de704de>:
  40d620:	push   rsi
  40d621:	test   r8,r8
  40d624:	jne    40d628 <__swc_fn_fc36583a_000175_4de704de+0x8>
  40d626:	pop    rsi
  40d627:	ret
  40d628:	lea    rax,[rcx+0x18]
  40d62c:	mov    r10,QWORD PTR [rax]
  40d62f:	lea    r11,[r10+0x1]
  40d633:	mov    QWORD PTR [rax],r11
  40d636:	mov    r11,rdx
  40d639:	not    rdx
  40d63c:	lea    rsi,[r8-0x1]
  40d640:	cmp    rsi,rdx
  40d643:	ja     40d663 <__swc_fn_fc36583a_000175_4de704de+0x43>
  40d645:	lea    rdx,[r11+r8*1]
  40d649:	dec    rdx
  40d64c:	shr    rdx,0x6
  40d650:	mov    r8,r11
  40d653:	shr    r8,0x6
  40d657:	mov    rsi,rdx
  40d65a:	sub    rsi,r8
  40d65d:	cmp    rsi,0x8
  40d661:	jb     40d679 <__swc_fn_fc36583a_000175_4de704de+0x59>
  40d663:	lea    rcx,[rcx+0x10]
  40d667:	mov    rdx,QWORD PTR [rcx]
  40d66a:	add    rdx,r9
  40d66d:	mov    QWORD PTR [rcx],rdx
  40d670:	lea    rcx,[r10+0x2]
  40d674:	mov    QWORD PTR [rax],rcx
  40d677:	pop    rsi
  40d678:	ret
  40d679:	shr    r11,0x6
  40d67d:	nop    DWORD PTR [rax]
  40d680:	cmp    r11,rdx
  40d683:	ja     40d6c3 <__swc_fn_fc36583a_000175_4de704de+0xa3>
  40d685:	jmp    40d696 <__swc_fn_fc36583a_000175_4de704de+0x76>
  40d687:	nop    WORD PTR [rax+rax*1+0x0]
  40d690:	add    r11,0x1
  40d694:	jmp    40d680 <__swc_fn_fc36583a_000175_4de704de+0x60>
  40d696:	mov    r8,r11
  40d699:	shr    r8,0xc
  40d69d:	mov    rsi,r11
  40d6a0:	xor    rsi,r8
  40d6a3:	mov    r8,r11
  40d6a6:	shr    r8,0x18
  40d6aa:	xor    rsi,r8
  40d6ad:	and    esi,0xfff
  40d6b3:	lea    r8,[rcx+rsi*8+0x20]
  40d6b8:	mov    rsi,QWORD PTR [r8]
  40d6bb:	add    rsi,r9
  40d6be:	mov    QWORD PTR [r8],rsi
  40d6c1:	jmp    40d690 <__swc_fn_fc36583a_000175_4de704de+0x70>
  40d6c3:	lea    rcx,[r10+0x2]
  40d6c7:	mov    QWORD PTR [rax],rcx
  40d6ca:	pop    rsi
  40d6cb:	ret
	...

000000000040d6e0 <__swc_fn_fc36583a_000002_aa67484d>:
  40d6e0:	push   rbp
  40d6e1:	push   rbx
  40d6e2:	push   r15
  40d6e4:	push   rsi
  40d6e5:	push   rdi
  40d6e6:	push   r12
  40d6e8:	push   r14
  40d6ea:	push   r13
  40d6ec:	sub    rsp,0x10
  40d6f0:	mov    rbp,rsp
  40d6f3:	vmovups XMMWORD PTR [rsp],xmm6
  40d6f8:	sub    rsp,0x610
  40d6ff:	mov    rbx,rsp
  40d702:	mov    ecx,0x17700
  40d707:	sub    rsp,0x8
  40d70b:	call   407270 <__swc_fn_fc36583a_000000_2744b483>
  40d710:	add    rsp,0x8
  40d714:	mov    QWORD PTR [rip+0x1692d],rax        # 424048 <__swc_bss_base_fc36583a+0x8>
  40d71b:	mov    ecx,0xbb80
  40d720:	sub    rsp,0x8
  40d724:	call   407270 <__swc_fn_fc36583a_000000_2744b483>
  40d729:	add    rsp,0x8
  40d72d:	mov    QWORD PTR [rip+0x1691c],rax        # 424050 <__swc_bss_base_fc36583a+0x10>
  40d734:	mov    ecx,0xbb80
  40d739:	sub    rsp,0x8
  40d73d:	call   407270 <__swc_fn_fc36583a_000000_2744b483>
  40d742:	add    rsp,0x8
  40d746:	mov    QWORD PTR [rip+0x1690b],rax        # 424058 <__swc_bss_base_fc36583a+0x18>
  40d74d:	xor    ecx,ecx
  40d74f:	xor    r8d,r8d
  40d752:	cs nop WORD PTR [rax+rax*1+0x0]
  40d75c:	cs nop WORD PTR [rax+rax*1+0x0]
  40d766:	cs nop WORD PTR [rax+rax*1+0x0]
  40d770:	lea    r9,[r8+0x1]
  40d774:	mov    r10,r9
  40d777:	movabs rdx,0x2492492492492493
  40d781:	mov    r15,rax
  40d784:	mov    rax,r8
  40d787:	mul    rdx
  40d78a:	mov    r11,rdx
  40d78d:	mov    rax,r15
  40d790:	mov    rdx,r8
  40d793:	sub    rdx,r11
  40d796:	shr    rdx,1
  40d799:	add    rdx,r11
  40d79c:	shr    rdx,0x2
  40d7a0:	imul   r11,rdx,0x7
  40d7a4:	mov    rdx,r8
  40d7a7:	sub    rdx,r11
  40d7aa:	lea    r11,[rdx+0x4]
  40d7ae:	mov    rdx,QWORD PTR [rip+0x1689b]        # 424050 <__swc_bss_base_fc36583a+0x10>
  40d7b5:	mov    QWORD PTR [rdx+r8*8],rcx
  40d7b9:	mov    rdx,QWORD PTR [rip+0x16898]        # 424058 <__swc_bss_base_fc36583a+0x18>
  40d7c0:	mov    QWORD PTR [rdx+r8*8],r11
  40d7c4:	xor    r8d,r8d
  40d7c7:	test   r11,r11
  40d7ca:	jbe    40d834 <__swc_fn_fc36583a_000002_aa67484d+0x154>
  40d7d0:	xor    esi,esi
  40d7d2:	mov    rdi,QWORD PTR [rip+0x1686f]        # 424048 <__swc_bss_base_fc36583a+0x8>
  40d7d9:	cs nop WORD PTR [rax+rax*1+0x0]
  40d7e3:	cs nop WORD PTR [rax+rax*1+0x0]
  40d7ed:	nop    DWORD PTR [rax]
  40d7f0:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40d7fa:	mov    r15,rax
  40d7fd:	mov    rax,r10
  40d800:	mul    rdx
  40d803:	mov    r12,rdx
  40d806:	mov    rax,r15
  40d809:	shr    r12,0x3
  40d80d:	imul   r12,r12,0x1a
  40d811:	sub    r10,r12
  40d814:	lea    r10,[r10+0x61]
  40d818:	mov    BYTE PTR [rdi+rcx*1],r10b
  40d81c:	inc    rcx
  40d81f:	shr    rdx,0x3
  40d823:	lea    r10,[rdx+rsi*1]
  40d827:	add    r8,0x1
  40d82b:	add    rsi,0x7
  40d82f:	cmp    r8,r11
  40d832:	jb     40d7f0 <__swc_fn_fc36583a_000002_aa67484d+0x110>
  40d834:	mov    r8,r9
  40d837:	cmp    r9,0x1770
  40d83e:	jb     40d770 <__swc_fn_fc36583a_000002_aa67484d+0x90>
  40d844:	mov    ecx,0x500
  40d849:	sub    rsp,0x8
  40d84d:	call   407270 <__swc_fn_fc36583a_000000_2744b483>
  40d852:	add    rsp,0x8
  40d856:	mov    QWORD PTR [rip+0x16803],rax        # 424060 <__swc_bss_base_fc36583a+0x20>
  40d85d:	mov    ecx,0x140
  40d862:	sub    rsp,0x8
  40d866:	call   407270 <__swc_fn_fc36583a_000000_2744b483>
  40d86b:	add    rsp,0x8
  40d86f:	mov    QWORD PTR [rip+0x167f2],rax        # 424068 <__swc_bss_base_fc36583a+0x28>
  40d876:	mov    ecx,0x140
  40d87b:	sub    rsp,0x8
  40d87f:	call   407270 <__swc_fn_fc36583a_000000_2744b483>
  40d884:	add    rsp,0x8
  40d888:	mov    QWORD PTR [rip+0x167e1],rax        # 424070 <__swc_bss_base_fc36583a+0x30>
  40d88f:	xor    ecx,ecx
  40d891:	xor    r8d,r8d
  40d894:	lea    r9,[rbx+0x68]
  40d898:	vxorps xmm0,xmm0,xmm0
  40d89c:	cs nop WORD PTR [rax+rax*1+0x0]
  40d8a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40d8b0:	vmovups XMMWORD PTR [rbx+0x68],xmm0
  40d8b5:	vmovups XMMWORD PTR [rbx+0x78],xmm0
  40d8ba:	mov    r10,QWORD PTR [rip+0x1473f]        # 422000 <__swc_data_base_fc36583a>
  40d8c1:	imul   r10,r10,0x41a7
  40d8c8:	movabs rdx,0x200000005
  40d8d2:	mov    r15,rax
  40d8d5:	mov    rax,r10
  40d8d8:	mul    rdx
  40d8db:	mov    r11,rdx
  40d8de:	mov    rdx,r10
  40d8e1:	sub    rdx,r11
  40d8e4:	shr    rdx,1
  40d8e7:	add    rdx,r11
  40d8ea:	shr    rdx,0x1e
  40d8ee:	imul   r11,rdx,0x7fffffff
  40d8f5:	sub    r10,r11
  40d8f8:	mov    QWORD PTR [rip+0x14701],r10        # 422000 <__swc_data_base_fc36583a>
  40d8ff:	movabs rdx,0xaec33e1f671529a5
  40d909:	mov    rax,r10
  40d90c:	mul    rdx
  40d90f:	mov    rax,r15
  40d912:	shr    rdx,0xc
  40d916:	imul   rdx,rdx,0x1770
  40d91d:	sub    r10,rdx
  40d920:	mov    rdx,QWORD PTR [rip+0x16731]        # 424058 <__swc_bss_base_fc36583a+0x18>
  40d927:	mov    rdx,QWORD PTR [rdx+r10*8]
  40d92b:	mov    r11,rdx
  40d92e:	xor    esi,esi
  40d930:	test   rdx,rdx
  40d933:	jbe    40d968 <__swc_fn_fc36583a_000002_aa67484d+0x288>
  40d935:	mov    rdi,QWORD PTR [rip+0x16714]        # 424050 <__swc_bss_base_fc36583a+0x10>
  40d93c:	mov    r12,QWORD PTR [rip+0x16705]        # 424048 <__swc_bss_base_fc36583a+0x8>
  40d943:	cs nop WORD PTR [rax+rax*1+0x0]
  40d94d:	nop    DWORD PTR [rax]
  40d950:	mov    r13,QWORD PTR [rdi+r10*8]
  40d954:	add    r13,rsi
  40d957:	mov    r13b,BYTE PTR [r12+r13*1]
  40d95b:	mov    BYTE PTR [r9+rsi*1],r13b
  40d95f:	add    rsi,0x1
  40d963:	cmp    rsi,rdx
  40d966:	jb     40d950 <__swc_fn_fc36583a_000002_aa67484d+0x270>
  40d968:	xor    r10d,r10d
  40d96b:	nop    DWORD PTR [rax+rax*1+0x0]
  40d970:	mov    rsi,QWORD PTR [rip+0x14689]        # 422000 <__swc_data_base_fc36583a>
  40d977:	imul   rsi,rsi,0x41a7
  40d97e:	movabs r12,0x200000005
  40d988:	mov    r14,rax
  40d98b:	mov    rax,rsi
  40d98e:	mul    r12
  40d991:	mov    r12,rsi
  40d994:	sub    r12,rdx
  40d997:	shr    r12,1
  40d99a:	add    r12,rdx
  40d99d:	shr    r12,0x1e
  40d9a1:	imul   rdi,r12,0x7fffffff
  40d9a8:	sub    rsi,rdi
  40d9ab:	mov    QWORD PTR [rip+0x1464e],rsi        # 422000 <__swc_data_base_fc36583a>
  40d9b2:	mov    rax,rsi
  40d9b5:	xor    edx,edx
  40d9b7:	div    r11
  40d9ba:	mov    rax,rdx
  40d9bd:	mov    r12,rax
  40d9c0:	imul   rsi,rsi,0x41a7
  40d9c7:	movabs rdx,0x200000005
  40d9d1:	mov    r15,r14
  40d9d4:	mov    rax,rsi
  40d9d7:	mul    rdx
  40d9da:	mov    rdi,rdx
  40d9dd:	mov    rdx,rsi
  40d9e0:	sub    rdx,rdi
  40d9e3:	shr    rdx,1
  40d9e6:	add    rdx,rdi
  40d9e9:	shr    rdx,0x1e
  40d9ed:	imul   rdi,rdx,0x7fffffff
  40d9f4:	sub    rsi,rdi
  40d9f7:	mov    QWORD PTR [rip+0x14602],rsi        # 422000 <__swc_data_base_fc36583a>
  40d9fe:	movabs rdx,0xaaaaaaaaaaaaaaab
  40da08:	mov    rax,rsi
  40da0b:	mul    rdx
  40da0e:	shr    rdx,1
  40da11:	lea    rdx,[rdx+rdx*2]
  40da15:	mov    r13,rsi
  40da18:	sub    r13,rdx
  40da1b:	imul   rsi,rsi,0x41a7
  40da22:	movabs rdx,0x200000005
  40da2c:	mov    rax,rsi
  40da2f:	mul    rdx
  40da32:	mov    rdi,rdx
  40da35:	mov    rdx,rsi
  40da38:	sub    rdx,rdi
  40da3b:	shr    rdx,1
  40da3e:	add    rdx,rdi
  40da41:	shr    rdx,0x1e
  40da45:	imul   rdi,rdx,0x7fffffff
  40da4c:	sub    rsi,rdi
  40da4f:	mov    QWORD PTR [rip+0x145aa],rsi        # 422000 <__swc_data_base_fc36583a>
  40da56:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40da60:	mov    rax,rsi
  40da63:	mul    rdx
  40da66:	mov    rax,r15
  40da69:	shr    rdx,0x3
  40da6d:	imul   rdx,rdx,0x1a
  40da71:	sub    rsi,rdx
  40da74:	lea    rdx,[rsi+0x61]
  40da78:	test   r13,r13
  40da7b:	jne    40da86 <__swc_fn_fc36583a_000002_aa67484d+0x3a6>
  40da7d:	mov    BYTE PTR [r9+r12*1],dl
  40da81:	jmp    40daf9 <__swc_fn_fc36583a_000002_aa67484d+0x419>
  40da86:	cmp    r13,0x1
  40da8a:	jne    40daba <__swc_fn_fc36583a_000002_aa67484d+0x3da>
  40da8c:	cmp    r11,0x2
  40da90:	jbe    40daf9 <__swc_fn_fc36583a_000002_aa67484d+0x419>
  40da96:	lea    rdx,[r12+0x1]
  40da9b:	cmp    rdx,r11
  40da9e:	jae    40dab4 <__swc_fn_fc36583a_000002_aa67484d+0x3d4>
  40daa0:	mov    sil,BYTE PTR [r9+r12*1+0x1]
  40daa5:	mov    BYTE PTR [r9+r12*1],sil
  40daa9:	mov    r12,rdx
  40daac:	inc    rdx
  40daaf:	cmp    rdx,r11
  40dab2:	jb     40daa0 <__swc_fn_fc36583a_000002_aa67484d+0x3c0>
  40dab4:	sub    r11,0x1
  40dab8:	jmp    40daf9 <__swc_fn_fc36583a_000002_aa67484d+0x419>
  40daba:	mov    rsi,r11
  40dabd:	cmp    rsi,r12
  40dac0:	jbe    40daf1 <__swc_fn_fc36583a_000002_aa67484d+0x411>
  40dac2:	cs nop WORD PTR [rax+rax*1+0x0]
  40dacc:	cs nop WORD PTR [rax+rax*1+0x0]
  40dad6:	cs nop WORD PTR [rax+rax*1+0x0]
  40dae0:	mov    dil,BYTE PTR [r9+rsi*1-0x1]
  40dae5:	mov    BYTE PTR [r9+rsi*1],dil
  40dae9:	dec    rsi
  40daec:	cmp    rsi,r12
  40daef:	ja     40dae0 <__swc_fn_fc36583a_000002_aa67484d+0x400>
  40daf1:	mov    BYTE PTR [r9+r12*1],dl
  40daf5:	add    r11,0x1
  40daf9:	add    r10,0x1
  40dafd:	cmp    r10,0x2
  40db01:	jb     40d970 <__swc_fn_fc36583a_000002_aa67484d+0x290>
  40db07:	mov    rdx,QWORD PTR [rip+0x1655a]        # 424068 <__swc_bss_base_fc36583a+0x28>
  40db0e:	mov    QWORD PTR [rdx+r8*8],rcx
  40db12:	mov    rdx,QWORD PTR [rip+0x16557]        # 424070 <__swc_bss_base_fc36583a+0x30>
  40db19:	mov    QWORD PTR [rdx+r8*8],r11
  40db1d:	xor    edx,edx
  40db1f:	test   r11,r11
  40db22:	jbe    40db54 <__swc_fn_fc36583a_000002_aa67484d+0x474>
  40db24:	mov    r10,QWORD PTR [rip+0x16535]        # 424060 <__swc_bss_base_fc36583a+0x20>
  40db2b:	cs nop WORD PTR [rax+rax*1+0x0]
  40db35:	cs nop WORD PTR [rax+rax*1+0x0]
  40db3f:	nop
  40db40:	mov    sil,BYTE PTR [r9+rdx*1]
  40db44:	mov    BYTE PTR [r10+rcx*1],sil
  40db48:	inc    rcx
  40db4b:	add    rdx,0x1
  40db4f:	cmp    rdx,r11
  40db52:	jb     40db40 <__swc_fn_fc36583a_000002_aa67484d+0x460>
  40db54:	add    r8,0x1
  40db58:	cmp    r8,0x28
  40db5c:	jb     40d8b0 <__swc_fn_fc36583a_000002_aa67484d+0x1d0>
  40db62:	sub    rsp,0x8
  40db66:	call   40a400 <__swc_fn_fc36583a_000001_1ca87929>
  40db6b:	add    rsp,0x8
  40db6f:	vmovups xmm6,xmm0
  40db73:	lea    rax,[rbx+0xf8]
  40db7a:	vxorps xmm0,xmm0,xmm0
  40db7e:	xor    ecx,ecx
  40db80:	vmovdqu XMMWORD PTR [rax+rcx*1],xmm0
  40db85:	add    rcx,0x10
  40db89:	cmp    rcx,0x200
  40db90:	jne    40db80 <__swc_fn_fc36583a_000002_aa67484d+0x4a0>
  40db92:	lea    rcx,[rbx+0x2f8]
  40db99:	vxorps xmm0,xmm0,xmm0
  40db9d:	xor    edx,edx
  40db9f:	nop
  40dba0:	vmovdqu XMMWORD PTR [rcx+rdx*1],xmm0
  40dba5:	add    rdx,0x10
  40dba9:	cmp    rdx,0x200
  40dbb0:	jne    40dba0 <__swc_fn_fc36583a_000002_aa67484d+0x4c0>
  40dbb2:	xor    edx,edx
  40dbb4:	mov    r8,QWORD PTR [rip+0x164ad]        # 424068 <__swc_bss_base_fc36583a+0x28>
  40dbbb:	mov    QWORD PTR [rsp+0x5b0],r8
  40dbc3:	mov    r9,QWORD PTR [rip+0x164a6]        # 424070 <__swc_bss_base_fc36583a+0x30>
  40dbca:	mov    QWORD PTR [rsp+0x5b8],r9
  40dbd2:	mov    r10,QWORD PTR [rip+0x16477]        # 424050 <__swc_bss_base_fc36583a+0x10>
  40dbd9:	mov    QWORD PTR [rsp+0x5a0],0x0
  40dbe5:	mov    QWORD PTR [rsp+0x5c0],r10
  40dbed:	mov    r11,QWORD PTR [rip+0x16464]        # 424058 <__swc_bss_base_fc36583a+0x18>
  40dbf4:	mov    QWORD PTR [rsp+0x5c8],r11
  40dbfc:	jmp    40dc38 <__swc_fn_fc36583a_000002_aa67484d+0x558>
  40dbfe:	cs nop WORD PTR [rax+rax*1+0x0]
  40dc08:	nop    DWORD PTR [rax+rax*1+0x0]
  40dc10:	mov    QWORD PTR [rsp+0x5a0],rsi
  40dc18:	mov    r8,QWORD PTR [rsp+0x5b0]
  40dc20:	mov    r9,QWORD PTR [rsp+0x5b8]
  40dc28:	mov    r10,QWORD PTR [rsp+0x5c0]
  40dc30:	mov    r11,QWORD PTR [rsp+0x5c8]
  40dc38:	mov    rdi,QWORD PTR [r8+rdx*8]
  40dc3c:	mov    QWORD PTR [rsp+0x5d0],rdi
  40dc44:	mov    r12,QWORD PTR [r9+rdx*8]
  40dc48:	mov    QWORD PTR [rsp+0x5d8],r12
  40dc50:	mov    r13d,0x40000000
  40dc56:	mov    r14,0xffffffffffffffff
  40dc5d:	xor    r15d,r15d
  40dc60:	mov    QWORD PTR [rsp+0x5a8],rdx
  40dc68:	vmovq  xmm3,r13
  40dc6d:	vmovq  xmm4,r14
  40dc72:	vmovq  xmm5,r15
  40dc77:	jmp    40dca2 <__swc_fn_fc36583a_000002_aa67484d+0x5c2>
  40dc79:	nop    DWORD PTR [rax+0x0]
  40dc80:	mov    r10,QWORD PTR [rsp+0x5c0]
  40dc88:	mov    r11,QWORD PTR [rsp+0x5c8]
  40dc90:	mov    rdi,QWORD PTR [rsp+0x5d0]
  40dc98:	vmovq  xmm3,r13
  40dc9d:	vmovq  xmm4,r14
  40dca2:	mov    r8,QWORD PTR [r10+r15*8]
  40dca6:	mov    QWORD PTR [rsp+0x5f8],r8
  40dcae:	mov    r9,QWORD PTR [r11+r15*8]
  40dcb2:	mov    rdx,r9
  40dcb5:	sub    rdx,r12
  40dcb8:	mov    rsi,r12
  40dcbb:	sub    rsi,r9
  40dcbe:	cmovbe rsi,rdx
  40dcc2:	cmp    rsi,0x3
  40dcc6:	jbe    40dcd7 <__swc_fn_fc36583a_000002_aa67484d+0x5f7>
  40dcc8:	vmovq  r13,xmm3
  40dccd:	vmovq  r14,xmm4
  40dcd2:	jmp    40de4b <__swc_fn_fc36583a_000002_aa67484d+0x76b>
  40dcd7:	lea    rdx,[r9+0x1]
  40dcdb:	xor    esi,esi
  40dcdd:	test   rdx,rdx
  40dce0:	jbe    40dcfd <__swc_fn_fc36583a_000002_aa67484d+0x61d>
  40dce2:	cs nop WORD PTR [rax+rax*1+0x0]
  40dcec:	nop    DWORD PTR [rax+0x0]
  40dcf0:	mov    QWORD PTR [rax+rsi*8],rsi
  40dcf4:	add    rsi,0x1
  40dcf8:	cmp    rsi,rdx
  40dcfb:	jb     40dcf0 <__swc_fn_fc36583a_000002_aa67484d+0x610>
  40dcfd:	xor    esi,esi
  40dcff:	test   r12,r12
  40dd02:	jbe    40de2d <__swc_fn_fc36583a_000002_aa67484d+0x74d>
  40dd08:	mov    r10,QWORD PTR [rip+0x16351]        # 424060 <__swc_bss_base_fc36583a+0x20>
  40dd0f:	add    r10,rdi
  40dd12:	vmovsd xmm0,QWORD PTR [rsp+0x5d8]
  40dd1b:	vmovsd xmm1,QWORD PTR [rsp+0x5f8]
  40dd24:	vmovq  xmm2,r10
  40dd29:	nop    DWORD PTR [rax+0x0]
  40dd30:	lea    r11,[rsi+0x1]
  40dd34:	mov    QWORD PTR [rbx+0x2f8],r11
  40dd3b:	mov    sil,BYTE PTR [r10+rsi*1]
  40dd3f:	xor    edi,edi
  40dd41:	test   r9,r9
  40dd44:	jbe    40dd96 <__swc_fn_fc36583a_000002_aa67484d+0x6b6>
  40dd46:	mov    r14,QWORD PTR [rip+0x162fb]        # 424048 <__swc_bss_base_fc36583a+0x8>
  40dd4d:	add    r14,r8
  40dd50:	mov    r15,QWORD PTR [rbx+0xf8]
  40dd57:	mov    r13,r11
  40dd5a:	nop    WORD PTR [rax+rax*1+0x0]
  40dd60:	xor    r8d,r8d
  40dd63:	cmp    BYTE PTR [r14+rdi*1],sil
  40dd67:	setne  r8b
  40dd6b:	add    r8,r15
  40dd6e:	mov    r15,QWORD PTR [rax+rdi*8+0x8]
  40dd73:	lea    r10,[r15+0x1]
  40dd77:	cmp    r10,r8
  40dd7a:	cmovb  r8,r10
  40dd7e:	inc    r13
  40dd81:	cmp    r13,r8
  40dd84:	cmovae r13,r8
  40dd88:	mov    QWORD PTR [rcx+rdi*8+0x8],r13
  40dd8d:	add    rdi,0x1
  40dd91:	cmp    rdi,r9
  40dd94:	jb     40dd60 <__swc_fn_fc36583a_000002_aa67484d+0x680>
  40dd96:	xor    r8d,r8d
  40dd99:	test   rdx,rdx
  40dd9c:	jbe    40de11 <__swc_fn_fc36583a_000002_aa67484d+0x731>
  40dda2:	cmp    rdx,0x4
  40dda6:	jb     40de00 <__swc_fn_fc36583a_000002_aa67484d+0x720>
  40dda8:	lea    r10,[rdx-0x3]
  40ddac:	nop    DWORD PTR [rax+0x0]
  40ddb0:	mov    rsi,QWORD PTR [rcx+r8*8]
  40ddb4:	mov    QWORD PTR [rax+r8*8],rsi
  40ddb8:	mov    rsi,QWORD PTR [rcx+r8*8+0x8]
  40ddbd:	mov    QWORD PTR [rax+r8*8+0x8],rsi
  40ddc2:	mov    rsi,QWORD PTR [rcx+r8*8+0x10]
  40ddc7:	mov    QWORD PTR [rax+r8*8+0x10],rsi
  40ddcc:	mov    rsi,QWORD PTR [rcx+r8*8+0x18]
  40ddd1:	mov    QWORD PTR [rax+r8*8+0x18],rsi
  40ddd6:	add    r8,0x4
  40ddda:	cmp    r8,r10
  40dddd:	jb     40ddb0 <__swc_fn_fc36583a_000002_aa67484d+0x6d0>
  40dddf:	cmp    r8,rdx
  40dde2:	jae    40de11 <__swc_fn_fc36583a_000002_aa67484d+0x731>
  40dde4:	cs nop WORD PTR [rax+rax*1+0x0]
  40ddee:	cs nop WORD PTR [rax+rax*1+0x0]
  40ddf8:	nop    DWORD PTR [rax+rax*1+0x0]
  40de00:	mov    rsi,QWORD PTR [rcx+r8*8]
  40de04:	mov    QWORD PTR [rax+r8*8],rsi
  40de08:	add    r8,0x1
  40de0c:	cmp    r8,rdx
  40de0f:	jb     40de00 <__swc_fn_fc36583a_000002_aa67484d+0x720>
  40de11:	mov    rsi,r11
  40de14:	vmovq  r12,xmm0
  40de19:	cmp    r11,r12
  40de1c:	jae    40de2d <__swc_fn_fc36583a_000002_aa67484d+0x74d>
  40de1e:	vmovq  r8,xmm1
  40de23:	vmovq  r10,xmm2
  40de28:	jmp    40dd30 <__swc_fn_fc36583a_000002_aa67484d+0x650>
  40de2d:	mov    rdx,QWORD PTR [rax+r9*8]
  40de31:	vmovq  r13,xmm3
  40de36:	cmp    rdx,r13
  40de39:	cmovb  r13,rdx
  40de3d:	vmovq  r14,xmm4
  40de42:	vmovq  r15,xmm5
  40de47:	cmovb  r14,r15
  40de4b:	add    r15,0x1
  40de4f:	vmovq  xmm5,r15
  40de54:	cmp    r15,0x1770
  40de5b:	jb     40dc80 <__swc_fn_fc36583a_000002_aa67484d+0x5a0>
  40de61:	imul   r13,r13,0x1f
  40de65:	add    r13,r14
  40de68:	mov    rsi,QWORD PTR [rsp+0x5a0]
  40de70:	add    rsi,r13
  40de73:	mov    rdx,QWORD PTR [rsp+0x5a8]
  40de7b:	add    rdx,0x1
  40de7f:	cmp    rdx,0x28
  40de83:	jb     40dc10 <__swc_fn_fc36583a_000002_aa67484d+0x530>
  40de89:	sub    rsp,0x8
  40de8d:	call   40a400 <__swc_fn_fc36583a_000001_1ca87929>
  40de92:	add    rsp,0x8
  40de96:	vsubsd xmm0,xmm0,xmm6
  40de9a:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x5386]        # 413228 <__swc_rdata_base_fc36583a+0x118>
  40dea2:	lea    rax,[rip+0x5277]        # 413120 <__swc_rdata_base_fc36583a+0x10>
  40dea9:	sub    rsp,0x90
  40deb0:	mov    rcx,rsp
  40deb3:	vmovups xmm1,XMMWORD PTR [rip+0x534d]        # 413208 <__swc_rdata_base_fc36583a+0xf8>
  40debb:	vmovups XMMWORD PTR [rcx],xmm1
  40debf:	mov    QWORD PTR [rcx+0x30],rsp
  40dec3:	lea    rdx,[rip+0x5266]        # 413130 <__swc_rdata_base_fc36583a+0x20>
  40deca:	mov    QWORD PTR [rcx+0x38],rdx
  40dece:	mov    QWORD PTR [rcx+0x10],rsi
  40ded2:	lea    r8,[rsp+0x10]
  40ded7:	mov    QWORD PTR [rcx+0x40],r8
  40dedb:	lea    r8,[rip+0x5296]        # 413178 <__swc_rdata_base_fc36583a+0x68>
  40dee2:	mov    QWORD PTR [rcx+0x48],r8
  40dee6:	vmovups xmm1,XMMWORD PTR [rip+0x532a]        # 413218 <__swc_rdata_base_fc36583a+0x108>
  40deee:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40def3:	lea    r8,[rsp+0x18]
  40def8:	mov    QWORD PTR [rcx+0x50],r8
  40defc:	mov    QWORD PTR [rcx+0x58],rdx
  40df00:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40df05:	lea    r8,[rcx+0x28]
  40df09:	mov    QWORD PTR [rcx+0x60],r8
  40df0d:	lea    r8,[rip+0x52ac]        # 4131c0 <__swc_rdata_base_fc36583a+0xb0>
  40df14:	mov    QWORD PTR [rcx+0x68],r8
  40df18:	mov    QWORD PTR [rcx+0x70],rax
  40df1c:	mov    QWORD PTR [rcx+0x78],rdx
  40df20:	lea    rax,[rcx+0x30]
  40df24:	mov    QWORD PTR [rcx+0x80],rax
  40df2b:	mov    QWORD PTR [rcx+0x88],0x5
  40df36:	lea    rcx,[rcx+0x80]
  40df3d:	sub    rsp,0x8
  40df41:	call   410a80 <__swc_fn_fc36583a_000149_6203dca2>
  40df46:	add    rsp,0x6a8
  40df4d:	vmovups xmm6,XMMWORD PTR [rsp]
  40df52:	add    rsp,0x10
  40df56:	pop    r13
  40df58:	pop    r14
  40df5a:	pop    r12
  40df5c:	pop    rdi
  40df5d:	pop    rsi
  40df5e:	pop    r15
  40df60:	pop    rbx
  40df61:	pop    rbp
  40df62:	ret
	...

000000000040df70 <__swc_fn_fc36583a_000005_81d2e1e9>:
  40df70:	sub    rsp,0x8
  40df74:	call   40c6c0 <__swc_fn_fc36583a_000112_6b799b8d>
  40df79:	mov    rcx,rax
  40df7c:	test   rax,rax
  40df7f:	je     40dfa6 <__swc_fn_fc36583a_000005_81d2e1e9+0x36>
  40df81:	lea    rdx,[rip+0x160f0]        # 424078 <__swc_bss_base_fc36583a+0x38>
  40df88:	mov    r8,QWORD PTR [rip+0x160e9]        # 424078 <__swc_bss_base_fc36583a+0x38>
  40df8f:	nop
  40df90:	lea    r9,[r8+0x1]
  40df94:	mov    rax,r8
  40df97:	lock cmpxchg QWORD PTR [rdx],r9
  40df9c:	cmp    rax,r8
  40df9f:	je     40dfa6 <__swc_fn_fc36583a_000005_81d2e1e9+0x36>
  40dfa1:	mov    r8,rax
  40dfa4:	jmp    40df90 <__swc_fn_fc36583a_000005_81d2e1e9+0x20>
  40dfa6:	mov    rax,rcx
  40dfa9:	add    rsp,0x8
  40dfad:	ret
	...

000000000040dfb0 <__swc_fn_fc36583a_000008_065ed5b1>:
  40dfb0:	mov    r8d,edx
  40dfb3:	xor    eax,eax
  40dfb5:	tzcnt  eax,edx
  40dfb9:	shrx   r9d,edx,eax
  40dfbe:	mov    DWORD PTR [rcx+0x2c],edx
  40dfc1:	xor    eax,eax
  40dfc3:	tzcnt  eax,edx
  40dfc7:	mov    BYTE PTR [rcx+0x38],al
  40dfca:	mov    eax,0xffffffff
  40dfcf:	xor    edx,edx
  40dfd1:	div    r8d
  40dfd4:	mov    DWORD PTR [rcx+0x34],eax
  40dfd7:	mov    eax,r9d
  40dfda:	mov    edx,r9d
  40dfdd:	imul   edx,r9d
  40dfe1:	mov    r8d,0x2
  40dfe7:	sub    r8d,edx
  40dfea:	imul   eax,r8d
  40dfee:	mov    edx,r9d
  40dff1:	imul   edx,eax
  40dff4:	mov    r8d,0x2
  40dffa:	sub    r8d,edx
  40dffd:	imul   eax,r8d
  40e001:	mov    edx,r9d
  40e004:	imul   edx,eax
  40e007:	mov    r8d,0x2
  40e00d:	sub    r8d,edx
  40e010:	imul   eax,r8d
  40e014:	mov    edx,r9d
  40e017:	imul   edx,eax
  40e01a:	mov    r8d,0x2
  40e020:	sub    r8d,edx
  40e023:	imul   eax,r8d
  40e027:	imul   r9d,eax
  40e02b:	mov    edx,0x2
  40e030:	sub    edx,r9d
  40e033:	imul   eax,edx
  40e036:	mov    DWORD PTR [rcx+0x30],eax
  40e039:	ret
  40e03a:	add    BYTE PTR [rax],al
  40e03c:	add    BYTE PTR [rax],al
	...

000000000040e040 <__swc_fn_fc36583a_000011_861b8b62>:
  40e040:	xor    eax,eax
  40e042:	mov    DWORD PTR [rcx+0x68],eax
  40e045:	ret
	...

000000000040e050 <__swc_fn_fc36583a_000014_9dea5065>:
  40e050:	mov    eax,DWORD PTR [rcx+0x28]
  40e053:	shlx   eax,edx,eax
  40e058:	shl    rax,0x10
  40e05c:	lea    rdx,[rcx+rax*1]
  40e060:	lea    rax,[rcx+0x3000]
  40e067:	cmp    rdx,rax
  40e06a:	cmovae rax,rdx
  40e06e:	ret
	...

000000000040e070 <__swc_fn_fc36583a_000017_283e2b5e>:
  40e070:	push   rsi
  40e071:	push   rdi
  40e072:	push   r12
  40e074:	push   r13
  40e076:	push   r14
  40e078:	mov    rsi,rdx
  40e07b:	mov    rdi,rcx
  40e07e:	rex mov dl,BYTE PTR [rsi+0x3a]
  40e082:	mov    ecx,DWORD PTR [rdi+0x28]
  40e085:	shr    dl,cl
  40e087:	mov    r12d,0x1
  40e08d:	mov    ecx,edx
  40e08f:	shl    r12,cl
  40e092:	mov    r13d,DWORD PTR [rsi+0x3c]
  40e096:	rex mov BYTE PTR [rsi+0x3b],0x0
  40e09b:	mov    QWORD PTR [rsi+0x40],0x0
  40e0a3:	mov    QWORD PTR [rsi],0x0
  40e0aa:	mov    rax,QWORD PTR [rsi+0x10]
  40e0ae:	mov    QWORD PTR [rsi+0x20],rax
  40e0b2:	lea    r14,[rip+0x15fc7]        # 424080 <__swc_bss_base_fc36583a+0x40>
  40e0b9:	mov    rax,QWORD PTR [r14]
  40e0bc:	shr    rax,0x2
  40e0c0:	mov    rcx,rax
  40e0c3:	cmp    rax,0x800000
  40e0ca:	mov    eax,0x800000
  40e0cf:	cmovb  rcx,rax
  40e0d3:	lea    r8,[rip+0x15fb6]        # 424090 <__swc_bss_base_fc36583a+0x50>
  40e0da:	mov    rax,QWORD PTR [r8]
  40e0dd:	mov    r9,rax
  40e0e0:	lea    r10,[r9+r13*1]
  40e0e4:	cmp    r10,rcx
  40e0e7:	ja     40e10b <__swc_fn_fc36583a_000017_283e2b5e+0x9b>
  40e0e9:	mov    rax,r9
  40e0ec:	lock cmpxchg QWORD PTR [r8],r10
  40e0f1:	cmp    rax,r9
  40e0f4:	je     40e0fb <__swc_fn_fc36583a_000017_283e2b5e+0x8b>
  40e0f6:	mov    r9,rax
  40e0f9:	jmp    40e0e0 <__swc_fn_fc36583a_000017_283e2b5e+0x70>
  40e0fb:	mov    rcx,rdi
  40e0fe:	mov    rdx,r12
  40e101:	call   40a7f0 <__swc_fn_fc36583a_000019_de02dbdf>
  40e106:	jmp    40e18d <__swc_fn_fc36583a_000017_283e2b5e+0x11d>
  40e10b:	mov    rcx,rdi
  40e10e:	movzx  edx,dl
  40e111:	call   40e050 <__swc_fn_fc36583a_000014_9dea5065>
  40e116:	test   r13,r13
  40e119:	je     40e186 <__swc_fn_fc36583a_000017_283e2b5e+0x116>
  40e11f:	mov    rcx,rax
  40e122:	mov    rdx,r13
  40e125:	call   40c840 <__swc_fn_fc36583a_000115_e9fc0224>
  40e12a:	mov    rcx,QWORD PTR [rip+0x15f4f]        # 424080 <__swc_bss_base_fc36583a+0x40>
  40e131:	cs nop WORD PTR [rax+rax*1+0x0]
  40e13b:	nop    DWORD PTR [rax+rax*1+0x0]
  40e140:	mov    rdx,rcx
  40e143:	sub    rdx,r13
  40e146:	mov    rax,rcx
  40e149:	lock cmpxchg QWORD PTR [r14],rdx
  40e14e:	cmp    rax,rcx
  40e151:	je     40e158 <__swc_fn_fc36583a_000017_283e2b5e+0xe8>
  40e153:	mov    rcx,rax
  40e156:	jmp    40e140 <__swc_fn_fc36583a_000017_283e2b5e+0xd0>
  40e158:	lea    rcx,[rip+0x15f39]        # 424098 <__swc_bss_base_fc36583a+0x58>
  40e15f:	mov    rdx,QWORD PTR [rip+0x15f32]        # 424098 <__swc_bss_base_fc36583a+0x58>
  40e166:	cs nop WORD PTR [rax+rax*1+0x0]
  40e170:	lea    r8,[rdx+0x1]
  40e174:	mov    rax,rdx
  40e177:	lock cmpxchg QWORD PTR [rcx],r8
  40e17c:	cmp    rax,rdx
  40e17f:	je     40e186 <__swc_fn_fc36583a_000017_283e2b5e+0x116>
  40e181:	mov    rdx,rax
  40e184:	jmp    40e170 <__swc_fn_fc36583a_000017_283e2b5e+0x100>
  40e186:	mov    DWORD PTR [rsi+0x3c],0x0
  40e18d:	mov    rcx,rdi
  40e190:	mov    rdx,r12
  40e193:	call   4076a0 <__swc_fn_fc36583a_000021_c8f5f27c>
  40e198:	pop    r14
  40e19a:	pop    r13
  40e19c:	pop    r12
  40e19e:	pop    rdi
  40e19f:	pop    rsi
  40e1a0:	ret
	...

000000000040e1b0 <__swc_fn_fc36583a_000020_fd2b165c>:
  40e1b0:	mov    r8,QWORD PTR [rcx+0x48]
  40e1b4:	test   r8,rdx
  40e1b7:	je     40e1e8 <__swc_fn_fc36583a_000020_fd2b165c+0x38>
  40e1b9:	nop    DWORD PTR [rax+0x0]
  40e1c0:	mov    rax,rdx
  40e1c3:	not    rax
  40e1c6:	mov    r9,r8
  40e1c9:	and    r9,rax
  40e1cc:	mov    rax,r8
  40e1cf:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40e1d5:	cmp    rax,r8
  40e1d8:	jne    40e1e0 <__swc_fn_fc36583a_000020_fd2b165c+0x30>
  40e1da:	mov    eax,0x1
  40e1df:	ret
  40e1e0:	mov    r8,rax
  40e1e3:	test   rax,rdx
  40e1e6:	jne    40e1c0 <__swc_fn_fc36583a_000020_fd2b165c+0x10>
  40e1e8:	xor    eax,eax
  40e1ea:	ret
  40e1eb:	add    BYTE PTR [rax],al
  40e1ed:	add    BYTE PTR [rax],al
	...

000000000040e1f0 <__swc_fn_fc36583a_000023_2685aade>:
  40e1f0:	push   rsi
  40e1f1:	push   rdi
  40e1f2:	push   r12
  40e1f4:	push   r13
  40e1f6:	sub    rsp,0x8
  40e1fa:	mov    rsi,rdx
  40e1fd:	mov    rdi,rcx
  40e200:	lea    r12,[rip+0x16021]        # 424228 <__swc_bss_base_fc36583a+0x1e8>
  40e207:	mov    rcx,r12
  40e20a:	call   409940 <__swc_fn_fc36583a_000138_86bb0f90>
  40e20f:	xor    eax,eax
  40e211:	mov    rcx,QWORD PTR [rip+0x16018]        # 424230 <__swc_bss_base_fc36583a+0x1f0>
  40e218:	mov    r13,rcx
  40e21b:	test   r13,r13
  40e21e:	je     40e26b <__swc_fn_fc36583a_000023_2685aade+0x7b>
  40e220:	mov    rcx,QWORD PTR [r13+0x10]
  40e224:	cmp    DWORD PTR [r13+0x28],esi
  40e228:	jne    40e260 <__swc_fn_fc36583a_000023_2685aade+0x70>
  40e22a:	test   rax,rax
  40e22d:	jne    40e238 <__swc_fn_fc36583a_000023_2685aade+0x48>
  40e22f:	mov    QWORD PTR [rip+0x15ffa],rcx        # 424230 <__swc_bss_base_fc36583a+0x1f0>
  40e236:	jmp    40e23c <__swc_fn_fc36583a_000023_2685aade+0x4c>
  40e238:	mov    QWORD PTR [rax+0x10],rcx
  40e23c:	vxorps xmm0,xmm0,xmm0
  40e240:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40e246:	mov    QWORD PTR [r13+0x8],rdi
  40e24a:	mov    rcx,r12
  40e24d:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  40e252:	mov    rax,r13
  40e255:	add    rsp,0x8
  40e259:	pop    r13
  40e25b:	pop    r12
  40e25d:	pop    rdi
  40e25e:	pop    rsi
  40e25f:	ret
  40e260:	mov    rax,r13
  40e263:	mov    r13,rcx
  40e266:	test   rcx,rcx
  40e269:	jne    40e220 <__swc_fn_fc36583a_000023_2685aade+0x30>
  40e26b:	mov    ecx,esi
  40e26d:	call   40a820 <__swc_fn_fc36583a_000022_2d0fcd2c>
  40e272:	mov    rsi,rax
  40e275:	test   rax,rax
  40e278:	jne    40e28f <__swc_fn_fc36583a_000023_2685aade+0x9f>
  40e27a:	mov    rcx,r12
  40e27d:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  40e282:	xor    eax,eax
  40e284:	add    rsp,0x8
  40e288:	pop    r13
  40e28a:	pop    r12
  40e28c:	pop    rdi
  40e28d:	pop    rsi
  40e28e:	ret
  40e28f:	mov    QWORD PTR [rsi+0x8],rdi
  40e293:	mov    rcx,r12
  40e296:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  40e29b:	mov    rax,rsi
  40e29e:	add    rsp,0x8
  40e2a2:	pop    r13
  40e2a4:	pop    r12
  40e2a6:	pop    rdi
  40e2a7:	pop    rsi
  40e2a8:	ret
	...

000000000040e2c0 <__swc_fn_fc36583a_000026_9798fb47>:
  40e2c0:	vxorps xmm0,xmm0,xmm0
  40e2c4:	xor    eax,eax
  40e2c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40e2d0:	cs nop WORD PTR [rax+rax*1+0x0]
  40e2da:	nop    WORD PTR [rax+rax*1+0x0]
  40e2e0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40e2e5:	add    rax,0x10
  40e2e9:	cmp    rax,0x2b00
  40e2f0:	jne    40e2e0 <__swc_fn_fc36583a_000026_9798fb47+0x20>
  40e2f2:	ret
	...

000000000040e300 <__swc_fn_fc36583a_000029_9798fb47>:
  40e300:	vxorps xmm0,xmm0,xmm0
  40e304:	vmovups XMMWORD PTR [rcx],xmm0
  40e308:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e30d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e312:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e317:	ret
	...

000000000040e320 <__swc_fn_fc36583a_000032_9798fb47>:
  40e320:	vxorps xmm0,xmm0,xmm0
  40e324:	vmovups XMMWORD PTR [rcx],xmm0
  40e328:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e32d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e332:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e337:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40e33c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40e341:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40e346:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40e34b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40e353:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40e35b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40e363:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40e36b:	mov    QWORD PTR [rcx+0xc0],0x0
  40e376:	ret
	...

000000000040e380 <__swc_fn_fc36583a_000035_92d9bbff>:
  40e380:	push   rsi
  40e381:	push   rdi
  40e382:	sub    rsp,0x8
  40e386:	mov    rsi,rcx
  40e389:	lea    rdi,[rip+0x13c78]        # 422008 <__swc_data_base_fc36583a+0x8>
  40e390:	mov    rax,QWORD PTR [rdi]
  40e393:	cmp    rax,0xffffffffffffffff
  40e397:	je     40e39e <__swc_fn_fc36583a_000035_92d9bbff+0x1e>
  40e399:	mov    rdi,rax
  40e39c:	jmp    40e3cb <__swc_fn_fc36583a_000035_92d9bbff+0x4b>
  40e39e:	call   409620 <__swc_fn_fc36583a_000126_58f0f391>
  40e3a3:	mov    rcx,rax
  40e3a6:	cmp    rax,0xffffffffffffffff
  40e3aa:	je     40e3dc <__swc_fn_fc36583a_000035_92d9bbff+0x5c>
  40e3ac:	mov    rax,0xffffffffffffffff
  40e3b3:	lock cmpxchg QWORD PTR [rdi],rcx
  40e3b8:	cmp    rax,0xffffffffffffffff
  40e3bc:	je     40e3c8 <__swc_fn_fc36583a_000035_92d9bbff+0x48>
  40e3be:	mov    rdi,rax
  40e3c1:	call   40cc10 <__swc_fn_fc36583a_000127_a481cb88>
  40e3c6:	jmp    40e3cb <__swc_fn_fc36583a_000035_92d9bbff+0x4b>
  40e3c8:	mov    rdi,rcx
  40e3cb:	cmp    rdi,0xffffffffffffffff
  40e3cf:	je     40e3dc <__swc_fn_fc36583a_000035_92d9bbff+0x5c>
  40e3d1:	mov    rcx,rdi
  40e3d4:	mov    rdx,rsi
  40e3d7:	call   410490 <__swc_fn_fc36583a_000128_4bbe3f14>
  40e3dc:	add    rsp,0x8
  40e3e0:	pop    rdi
  40e3e1:	pop    rsi
  40e3e2:	ret
	...

000000000040e3f0 <__swc_fn_fc36583a_000038_03f1bf9a>:
  40e3f0:	sub    rsp,0x38
  40e3f4:	mov    rax,rdx
  40e3f7:	test   dl,dl
  40e3f9:	jne    40e411 <__swc_fn_fc36583a_000038_03f1bf9a+0x21>
  40e3fb:	mov    rax,r8
  40e3fe:	test   r8b,r8b
  40e401:	cmove  eax,r9d
  40e405:	test   al,al
  40e407:	cmove  eax,r10d
  40e40b:	test   al,al
  40e40d:	cmove  eax,r11d
  40e411:	test   al,al
  40e413:	jne    40e41a <__swc_fn_fc36583a_000038_03f1bf9a+0x2a>
  40e415:	add    rsp,0x38
  40e419:	ret
  40e41a:	lea    rcx,[rip+0x4e17]        # 413238 <__swc_rdata_base_fc36583a+0x128>
  40e421:	vmovups xmm0,XMMWORD PTR [rip+0x4e1f]        # 413248 <__swc_rdata_base_fc36583a+0x138>
  40e429:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e42f:	vmovups xmm0,XMMWORD PTR [rip+0x4e21]        # 413258 <__swc_rdata_base_fc36583a+0x148>
  40e437:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e43d:	vmovups xmm0,XMMWORD PTR [rip+0x4e23]        # 413268 <__swc_rdata_base_fc36583a+0x158>
  40e445:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e44b:	lea    rdx,[rsp+0x8]
  40e450:	call   40c440 <__swc_fn_fc36583a_000106_90faaa26>
  40e455:	jmp    40e415 <__swc_fn_fc36583a_000038_03f1bf9a+0x25>
	...

000000000040e460 <__swc_fn_fc36583a_000041_facd3e17>:
  40e460:	sub    rsp,0x8
  40e464:	mov    eax,0x1000
  40e469:	test   eax,eax
  40e46b:	mov    r8d,0x8
  40e471:	cmove  eax,r8d
  40e475:	dec    rax
  40e478:	mov    r8,0xffffffffffffffff
  40e47f:	sub    r8,rax
  40e482:	cmp    rdx,r8
  40e485:	ja     40e495 <__swc_fn_fc36583a_000041_facd3e17+0x35>
  40e487:	add    rdx,rax
  40e48a:	not    rax
  40e48d:	mov    r8,rdx
  40e490:	and    r8,rax
  40e493:	jne    40e49c <__swc_fn_fc36583a_000041_facd3e17+0x3c>
  40e495:	xor    eax,eax
  40e497:	add    rsp,0x8
  40e49b:	ret
  40e49c:	mov    rdx,r8
  40e49f:	call   40ab40 <__swc_fn_fc36583a_000040_c90d80c1>
  40e4a4:	add    rsp,0x8
  40e4a8:	ret
  40e4a9:	add    BYTE PTR [rax],al
  40e4ab:	add    BYTE PTR [rax],al
  40e4ad:	add    BYTE PTR [rax],al
	...

000000000040e4b0 <__swc_fn_fc36583a_000044_d8bd27c3>:
  40e4b0:	push   rsi
  40e4b1:	push   rdi
  40e4b2:	sub    rsp,0x8
  40e4b6:	mov    rsi,rdx
  40e4b9:	mov    rdi,rcx
  40e4bc:	test   rdx,rdx
  40e4bf:	je     40e4db <__swc_fn_fc36583a_000044_d8bd27c3+0x2b>
  40e4c1:	xor    ecx,ecx
  40e4c3:	call   4077c0 <__swc_fn_fc36583a_000036_28d0e998>
  40e4c8:	mov    rax,QWORD PTR [rsi]
  40e4cb:	test   rax,rax
  40e4ce:	je     40e4db <__swc_fn_fc36583a_000044_d8bd27c3+0x2b>
  40e4d0:	mov    rcx,rax
  40e4d3:	mov    rdx,rsi
  40e4d6:	call   4078e0 <__swc_fn_fc36583a_000045_b30433d0>
  40e4db:	mov    rcx,rdi
  40e4de:	call   40aba0 <__swc_fn_fc36583a_000043_a78ae66b>
  40e4e3:	mov    rsi,rax
  40e4e6:	test   rax,rax
  40e4e9:	jne    40e4f4 <__swc_fn_fc36583a_000044_d8bd27c3+0x44>
  40e4eb:	xor    eax,eax
  40e4ed:	add    rsp,0x8
  40e4f1:	pop    rdi
  40e4f2:	pop    rsi
  40e4f3:	ret
  40e4f4:	mov    rcx,rsi
  40e4f7:	call   4077c0 <__swc_fn_fc36583a_000036_28d0e998>
  40e4fc:	mov    rax,rsi
  40e4ff:	add    rsp,0x8
  40e503:	pop    rdi
  40e504:	pop    rsi
  40e505:	ret
	...

000000000040e510 <__swc_fn_fc36583a_000047_137687bb>:
  40e510:	movzx  eax,BYTE PTR [r8+0x39]
  40e515:	lea    rax,[rax+rax*4]
  40e519:	lea    rax,[rdx+rax*8+0x28]
  40e51e:	mov    ecx,DWORD PTR [r8+0x6c]
  40e522:	test   ecx,ecx
  40e524:	je     40e55d <__swc_fn_fc36583a_000047_137687bb+0x4d>
  40e526:	mov    rcx,QWORD PTR [r8+0x50]
  40e52a:	test   rcx,rcx
  40e52d:	je     40e539 <__swc_fn_fc36583a_000047_137687bb+0x29>
  40e52f:	mov    rax,QWORD PTR [r8+0x48]
  40e533:	mov    QWORD PTR [rcx+0x48],rax
  40e537:	jmp    40e541 <__swc_fn_fc36583a_000047_137687bb+0x31>
  40e539:	mov    rcx,QWORD PTR [r8+0x48]
  40e53d:	mov    QWORD PTR [rax+0x18],rcx
  40e541:	mov    rax,QWORD PTR [r8+0x48]
  40e545:	test   rax,rax
  40e548:	je     40e552 <__swc_fn_fc36583a_000047_137687bb+0x42>
  40e54a:	mov    rcx,QWORD PTR [r8+0x50]
  40e54e:	mov    QWORD PTR [rax+0x50],rcx
  40e552:	vxorps xmm0,xmm0,xmm0
  40e556:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e55c:	ret
  40e55d:	mov    rcx,QWORD PTR [r8+0x50]
  40e561:	test   rcx,rcx
  40e564:	je     40e570 <__swc_fn_fc36583a_000047_137687bb+0x60>
  40e566:	mov    rdx,QWORD PTR [r8+0x48]
  40e56a:	mov    QWORD PTR [rcx+0x48],rdx
  40e56e:	jmp    40e578 <__swc_fn_fc36583a_000047_137687bb+0x68>
  40e570:	mov    rcx,QWORD PTR [r8+0x48]
  40e574:	mov    QWORD PTR [rax+0x8],rcx
  40e578:	mov    rcx,QWORD PTR [r8+0x48]
  40e57c:	test   rcx,rcx
  40e57f:	je     40e58b <__swc_fn_fc36583a_000047_137687bb+0x7b>
  40e581:	mov    rdx,QWORD PTR [r8+0x50]
  40e585:	mov    QWORD PTR [rcx+0x50],rdx
  40e589:	jmp    40e593 <__swc_fn_fc36583a_000047_137687bb+0x83>
  40e58b:	mov    rcx,QWORD PTR [r8+0x50]
  40e58f:	mov    QWORD PTR [rax+0x10],rcx
  40e593:	cmp    QWORD PTR [rax],r8
  40e596:	jne    40e59f <__swc_fn_fc36583a_000047_137687bb+0x8f>
  40e598:	mov    QWORD PTR [rax],0x0
  40e59f:	vxorps xmm0,xmm0,xmm0
  40e5a3:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e5a9:	ret
  40e5aa:	add    BYTE PTR [rax],al
  40e5ac:	add    BYTE PTR [rax],al
	...

000000000040e5b0 <__swc_fn_fc36583a_000050_e072b516>:
  40e5b0:	sub    rsp,0x8
  40e5b4:	mov    r9,r8
  40e5b7:	mov    r10,rdx
  40e5ba:	call   40e510 <__swc_fn_fc36583a_000047_137687bb>
  40e5bf:	mov    DWORD PTR [r9+0x6c],0x0
  40e5c7:	movzx  eax,BYTE PTR [r9+0x39]
  40e5cc:	lea    rax,[rax+rax*4]
  40e5d0:	lea    rax,[r10+rax*8+0x28]
  40e5d5:	mov    rcx,QWORD PTR [rax+0x10]
  40e5d9:	mov    QWORD PTR [r9+0x50],rcx
  40e5dd:	mov    QWORD PTR [r9+0x48],0x0
  40e5e5:	mov    rcx,QWORD PTR [rax+0x10]
  40e5e9:	test   rcx,rcx
  40e5ec:	je     40e5f4 <__swc_fn_fc36583a_000050_e072b516+0x44>
  40e5ee:	mov    QWORD PTR [rcx+0x48],r9
  40e5f2:	jmp    40e5f8 <__swc_fn_fc36583a_000050_e072b516+0x48>
  40e5f4:	mov    QWORD PTR [rax+0x8],r9
  40e5f8:	mov    QWORD PTR [rax+0x10],r9
  40e5fc:	add    rsp,0x8
  40e600:	ret
	...

000000000040e620 <__swc_fn_fc36583a_000053_faa92dcc>:
  40e620:	push   rsi
  40e621:	push   rdi
  40e622:	push   r12
  40e624:	push   r13
  40e626:	push   r14
  40e628:	push   r15
  40e62a:	sub    rsp,0x1f8
  40e631:	mov    esi,r8d
  40e634:	mov    QWORD PTR [rsp+0x1e8],rsi
  40e63c:	mov    rdi,rcx
  40e63f:	mov    r12,rdx
  40e642:	lea    r13,[rsi+rsi*4]
  40e646:	lea    r13,[rdx+r13*8+0x28]
  40e64b:	call   407d40 <__swc_fn_fc36583a_000051_d846b172>
  40e650:	add    DWORD PTR [r12+0x24],0x1
  40e656:	test   BYTE PTR [r12+0x24],0x3f
  40e65c:	jne    40e666 <__swc_fn_fc36583a_000053_faa92dcc+0x46>
  40e65e:	mov    rcx,rdi
  40e661:	call   40ad20 <__swc_fn_fc36583a_000052_3af34d7f>
  40e666:	mov    rax,QWORD PTR [r13+0x8]
  40e66a:	mov    r14,rax
  40e66d:	nop    DWORD PTR [rax]
  40e670:	test   r14,r14
  40e673:	jne    40e682 <__swc_fn_fc36583a_000053_faa92dcc+0x62>
  40e675:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40e67d:	jmp    40e789 <__swc_fn_fc36583a_000053_faa92dcc+0x169>
  40e682:	mov    r15,QWORD PTR [r14+0x48]
  40e686:	mov    rcx,r14
  40e689:	call   407490 <__swc_fn_fc36583a_000012_e4b0ddfc>
  40e68e:	mov    rax,QWORD PTR [r14]
  40e691:	test   rax,rax
  40e694:	je     40e6a6 <__swc_fn_fc36583a_000053_faa92dcc+0x86>
  40e696:	mov    rcx,QWORD PTR [rax]
  40e699:	mov    QWORD PTR [r14],rcx
  40e69c:	add    DWORD PTR [r14+0x28],0x1
  40e6a1:	mov    rsi,rax
  40e6a4:	jmp    40e6c5 <__swc_fn_fc36583a_000053_faa92dcc+0xa5>
  40e6a6:	mov    rax,QWORD PTR [r14+0x18]
  40e6aa:	cmp    QWORD PTR [r14+0x20],rax
  40e6ae:	jae    40e6c3 <__swc_fn_fc36583a_000053_faa92dcc+0xa3>
  40e6b0:	mov    rsi,QWORD PTR [r14+0x20]
  40e6b4:	mov    eax,DWORD PTR [r14+0x2c]
  40e6b8:	add    QWORD PTR [r14+0x20],rax
  40e6bc:	add    DWORD PTR [r14+0x28],0x1
  40e6c1:	jmp    40e6c5 <__swc_fn_fc36583a_000053_faa92dcc+0xa5>
  40e6c3:	xor    esi,esi
  40e6c5:	test   rsi,rsi
  40e6c8:	jne    40e70d <__swc_fn_fc36583a_000053_faa92dcc+0xed>
  40e6ca:	mov    rcx,r14
  40e6cd:	call   4073c0 <__swc_fn_fc36583a_000009_24a20786>
  40e6d2:	test   al,al
  40e6d4:	je     40e70d <__swc_fn_fc36583a_000053_faa92dcc+0xed>
  40e6d6:	mov    rax,QWORD PTR [r14]
  40e6d9:	test   rax,rax
  40e6dc:	je     40e6eb <__swc_fn_fc36583a_000053_faa92dcc+0xcb>
  40e6de:	mov    rcx,QWORD PTR [rax]
  40e6e1:	mov    QWORD PTR [r14],rcx
  40e6e4:	add    DWORD PTR [r14+0x28],0x1
  40e6e9:	jmp    40e70a <__swc_fn_fc36583a_000053_faa92dcc+0xea>
  40e6eb:	mov    rax,QWORD PTR [r14+0x18]
  40e6ef:	cmp    QWORD PTR [r14+0x20],rax
  40e6f3:	jae    40e708 <__swc_fn_fc36583a_000053_faa92dcc+0xe8>
  40e6f5:	mov    rax,QWORD PTR [r14+0x20]
  40e6f9:	mov    ecx,DWORD PTR [r14+0x2c]
  40e6fd:	add    QWORD PTR [r14+0x20],rcx
  40e701:	add    DWORD PTR [r14+0x28],0x1
  40e706:	jmp    40e70a <__swc_fn_fc36583a_000053_faa92dcc+0xea>
  40e708:	xor    eax,eax
  40e70a:	mov    rsi,rax
  40e70d:	test   rsi,rsi
  40e710:	jne    40e763 <__swc_fn_fc36583a_000053_faa92dcc+0x143>
  40e712:	mov    rcx,rdi
  40e715:	mov    rdx,r12
  40e718:	mov    r8,r14
  40e71b:	call   40ac80 <__swc_fn_fc36583a_000049_129b9bf4>
  40e720:	test   al,al
  40e722:	jne    40e763 <__swc_fn_fc36583a_000053_faa92dcc+0x143>
  40e724:	mov    rcx,r14
  40e727:	call   407490 <__swc_fn_fc36583a_000012_e4b0ddfc>
  40e72c:	mov    rax,QWORD PTR [r14]
  40e72f:	test   rax,rax
  40e732:	je     40e741 <__swc_fn_fc36583a_000053_faa92dcc+0x121>
  40e734:	mov    rcx,QWORD PTR [rax]
  40e737:	mov    QWORD PTR [r14],rcx
  40e73a:	add    DWORD PTR [r14+0x28],0x1
  40e73f:	jmp    40e760 <__swc_fn_fc36583a_000053_faa92dcc+0x140>
  40e741:	mov    rax,QWORD PTR [r14+0x18]
  40e745:	cmp    QWORD PTR [r14+0x20],rax
  40e749:	jae    40e75e <__swc_fn_fc36583a_000053_faa92dcc+0x13e>
  40e74b:	mov    rax,QWORD PTR [r14+0x20]
  40e74f:	mov    ecx,DWORD PTR [r14+0x2c]
  40e753:	add    QWORD PTR [r14+0x20],rcx
  40e757:	add    DWORD PTR [r14+0x28],0x1
  40e75c:	jmp    40e760 <__swc_fn_fc36583a_000053_faa92dcc+0x140>
  40e75e:	xor    eax,eax
  40e760:	mov    rsi,rax
  40e763:	test   rsi,rsi
  40e766:	je     40e781 <__swc_fn_fc36583a_000053_faa92dcc+0x161>
  40e768:	mov    QWORD PTR [r13+0x0],r14
  40e76c:	mov    rax,rsi
  40e76f:	add    rsp,0x1f8
  40e776:	pop    r15
  40e778:	pop    r14
  40e77a:	pop    r13
  40e77c:	pop    r12
  40e77e:	pop    rdi
  40e77f:	pop    rsi
  40e780:	ret
  40e781:	mov    r14,r15
  40e784:	jmp    40e670 <__swc_fn_fc36583a_000053_faa92dcc+0x50>
  40e789:	cs nop WORD PTR [rax+rax*1+0x0]
  40e793:	cs nop WORD PTR [rax+rax*1+0x0]
  40e79d:	nop    DWORD PTR [rax]
  40e7a0:	mov    rcx,rdi
  40e7a3:	mov    rdx,r12
  40e7a6:	mov    r8d,esi
  40e7a9:	call   407a80 <__swc_fn_fc36583a_000048_ad48ec88>
  40e7ae:	mov    r14,rax
  40e7b1:	test   rax,rax
  40e7b4:	jne    40e7ca <__swc_fn_fc36583a_000053_faa92dcc+0x1aa>
  40e7b6:	xor    eax,eax
  40e7b8:	add    rsp,0x1f8
  40e7bf:	pop    r15
  40e7c1:	pop    r14
  40e7c3:	pop    r13
  40e7c5:	pop    r12
  40e7c7:	pop    rdi
  40e7c8:	pop    rsi
  40e7c9:	ret
  40e7ca:	mov    QWORD PTR [r13+0x0],r14
  40e7ce:	mov    rax,QWORD PTR [r14]
  40e7d1:	test   rax,rax
  40e7d4:	je     40e7e6 <__swc_fn_fc36583a_000053_faa92dcc+0x1c6>
  40e7d6:	mov    rcx,QWORD PTR [rax]
  40e7d9:	mov    QWORD PTR [r14],rcx
  40e7dc:	add    DWORD PTR [r14+0x28],0x1
  40e7e1:	mov    r15,rax
  40e7e4:	jmp    40e806 <__swc_fn_fc36583a_000053_faa92dcc+0x1e6>
  40e7e6:	mov    rax,QWORD PTR [r14+0x18]
  40e7ea:	cmp    QWORD PTR [r14+0x20],rax
  40e7ee:	jae    40e803 <__swc_fn_fc36583a_000053_faa92dcc+0x1e3>
  40e7f0:	mov    r15,QWORD PTR [r14+0x20]
  40e7f4:	mov    eax,DWORD PTR [r14+0x2c]
  40e7f8:	add    QWORD PTR [r14+0x20],rax
  40e7fc:	add    DWORD PTR [r14+0x28],0x1
  40e801:	jmp    40e806 <__swc_fn_fc36583a_000053_faa92dcc+0x1e6>
  40e803:	xor    r15d,r15d
  40e806:	test   r15,r15
  40e809:	jne    40e84e <__swc_fn_fc36583a_000053_faa92dcc+0x22e>
  40e80b:	mov    rcx,r14
  40e80e:	call   4073c0 <__swc_fn_fc36583a_000009_24a20786>
  40e813:	test   al,al
  40e815:	je     40e84e <__swc_fn_fc36583a_000053_faa92dcc+0x22e>
  40e817:	mov    rax,QWORD PTR [r14]
  40e81a:	test   rax,rax
  40e81d:	je     40e82c <__swc_fn_fc36583a_000053_faa92dcc+0x20c>
  40e81f:	mov    rcx,QWORD PTR [rax]
  40e822:	mov    QWORD PTR [r14],rcx
  40e825:	add    DWORD PTR [r14+0x28],0x1
  40e82a:	jmp    40e84b <__swc_fn_fc36583a_000053_faa92dcc+0x22b>
  40e82c:	mov    rax,QWORD PTR [r14+0x18]
  40e830:	cmp    QWORD PTR [r14+0x20],rax
  40e834:	jae    40e849 <__swc_fn_fc36583a_000053_faa92dcc+0x229>
  40e836:	mov    rax,QWORD PTR [r14+0x20]
  40e83a:	mov    ecx,DWORD PTR [r14+0x2c]
  40e83e:	add    QWORD PTR [r14+0x20],rcx
  40e842:	add    DWORD PTR [r14+0x28],0x1
  40e847:	jmp    40e84b <__swc_fn_fc36583a_000053_faa92dcc+0x22b>
  40e849:	xor    eax,eax
  40e84b:	mov    r15,rax
  40e84e:	test   r15,r15
  40e851:	je     40e7a0 <__swc_fn_fc36583a_000053_faa92dcc+0x180>
  40e857:	mov    rax,r15
  40e85a:	add    rsp,0x1f8
  40e861:	pop    r15
  40e863:	pop    r14
  40e865:	pop    r13
  40e867:	pop    r12
  40e869:	pop    rdi
  40e86a:	pop    rsi
  40e86b:	ret
  40e86c:	add    BYTE PTR [rax],al
	...

000000000040e870 <__swc_fn_fc36583a_000056_7e1dbcb0>:
  40e870:	push   rsi
  40e871:	push   rdi
  40e872:	push   r12
  40e874:	mov    rsi,rdx
  40e877:	mov    rax,rdx
  40e87a:	shr    rax,0xc
  40e87e:	movabs rdx,0x9e3779b97f4a7c15
  40e888:	imul   rax,rdx
  40e88c:	shr    rax,0x20
  40e890:	lea    rax,[rax*8+0x0]
  40e898:	shr    rax,0x20
  40e89c:	lea    rax,[rax*8+0x0]
  40e8a4:	lea    rax,[rcx+rax*8+0x40]
  40e8a9:	xor    edx,edx
  40e8ab:	test   dl,dl
  40e8ad:	lea    rdi,[rcx+0x8]
  40e8b1:	cmove  rdi,rax
  40e8b5:	xor    edx,edx
  40e8b7:	test   dl,dl
  40e8b9:	lea    r12,[rcx+0x30]
  40e8bd:	lea    rax,[rax+0x8]
  40e8c1:	cmove  r12,rax
  40e8c5:	mov    rcx,rdi
  40e8c8:	call   409940 <__swc_fn_fc36583a_000138_86bb0f90>
  40e8cd:	mov    QWORD PTR [rsi+0x30],0x0
  40e8d5:	mov    rax,QWORD PTR [r12]
  40e8d9:	mov    QWORD PTR [rsi+0x38],rax
  40e8dd:	test   rax,rax
  40e8e0:	je     40e8ea <__swc_fn_fc36583a_000056_7e1dbcb0+0x7a>
  40e8e2:	mov    rax,QWORD PTR [rsi+0x38]
  40e8e6:	mov    QWORD PTR [rax+0x30],rsi
  40e8ea:	mov    QWORD PTR [r12],rsi
  40e8ee:	mov    rcx,rdi
  40e8f1:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  40e8f6:	pop    r12
  40e8f8:	pop    rdi
  40e8f9:	pop    rsi
  40e8fa:	ret
  40e8fb:	add    BYTE PTR [rax],al
  40e8fd:	add    BYTE PTR [rax],al
	...

000000000040e900 <__swc_fn_fc36583a_000059_15c28ca7>:
  40e900:	lea    rax,[rdx+rdx*4]
  40e904:	lea    rax,[rcx+rax*8+0x268]
  40e90c:	mov    rdx,QWORD PTR [rax+0x10]
  40e910:	sub    QWORD PTR [rcx+0x2a68],rdx
  40e917:	sub    QWORD PTR [rcx+0x2a70],0x1
  40e91f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40e926:	lea    rdx,[rdx+rdx*4]
  40e92a:	lea    rdx,[rcx+rdx*8+0x268]
  40e932:	vmovups xmm0,XMMWORD PTR [rdx]
  40e936:	vmovups XMMWORD PTR [rax],xmm0
  40e93a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40e93f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e944:	mov    rcx,QWORD PTR [rdx+0x20]
  40e948:	mov    QWORD PTR [rax+0x20],rcx
  40e94c:	ret
  40e94d:	add    BYTE PTR [rax],al
	...

000000000040e950 <__swc_fn_fc36583a_000062_dea90857>:
  40e950:	push   rsi
  40e951:	push   rdi
  40e952:	push   r12
  40e954:	push   r13
  40e956:	sub    rsp,0x8
  40e95a:	mov    rsi,r8
  40e95d:	mov    rdi,rcx
  40e960:	mov    r12,rdx
  40e963:	xor    r13d,r13d
  40e966:	cs nop WORD PTR [rax+rax*1+0x0]
  40e970:	mov    eax,DWORD PTR [r12+0x730]
  40e978:	cmp    r13d,eax
  40e97b:	jae    40e9e1 <__swc_fn_fc36583a_000062_dea90857+0x91>
  40e97d:	lea    rax,[r13+r13*4+0x0]
  40e982:	lea    rax,[r12+rax*8+0x738]
  40e98a:	mov    rdx,QWORD PTR [rax]
  40e98d:	mov    r8,QWORD PTR [rax+0x8]
  40e991:	mov    r9,QWORD PTR [rax+0x10]
  40e995:	cmp    QWORD PTR [rax+0x20],rsi
  40e999:	jb     40e9a0 <__swc_fn_fc36583a_000062_dea90857+0x50>
  40e99b:	inc    r13d
  40e99e:	jmp    40e970 <__swc_fn_fc36583a_000062_dea90857+0x20>
  40e9a0:	sub    DWORD PTR [r12+0x730],0x1
  40e9a9:	mov    ecx,DWORD PTR [r12+0x730]
  40e9b1:	lea    rcx,[rcx+rcx*4]
  40e9b5:	lea    rcx,[r12+rcx*8+0x738]
  40e9bd:	vmovups xmm0,XMMWORD PTR [rcx]
  40e9c1:	vmovups XMMWORD PTR [rax],xmm0
  40e9c5:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40e9ca:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e9cf:	mov    rcx,QWORD PTR [rcx+0x20]
  40e9d3:	mov    QWORD PTR [rax+0x20],rcx
  40e9d7:	mov    rcx,rdi
  40e9da:	call   4077f0 <__swc_fn_fc36583a_000042_d3c2ab54>
  40e9df:	jmp    40e970 <__swc_fn_fc36583a_000062_dea90857+0x20>
  40e9e1:	add    rsp,0x8
  40e9e5:	pop    r13
  40e9e7:	pop    r12
  40e9e9:	pop    rdi
  40e9ea:	pop    rsi
  40e9eb:	ret
  40e9ec:	add    BYTE PTR [rax],al
	...

000000000040e9f0 <__swc_fn_fc36583a_000065_de167e8d>:
  40e9f0:	push   rsi
  40e9f1:	push   rdi
  40e9f2:	push   r12
  40e9f4:	push   r13
  40e9f6:	push   r14
  40e9f8:	mov    rsi,rcx
  40e9fb:	mov    rdi,rdx
  40e9fe:	mov    r12,QWORD PTR [rdi]
  40ea01:	mov    r13,QWORD PTR [rdi+0x18]
  40ea05:	mov    rax,r12
  40ea08:	add    rax,QWORD PTR [rdi+0x8]
  40ea0c:	sub    rax,r13
  40ea0f:	cmp    r8,rax
  40ea12:	jbe    40ea1d <__swc_fn_fc36583a_000065_de167e8d+0x2d>
  40ea14:	pop    r14
  40ea16:	pop    r13
  40ea18:	pop    r12
  40ea1a:	pop    rdi
  40ea1b:	pop    rsi
  40ea1c:	ret
  40ea1d:	lea    rax,[r13+r8*1+0x0]
  40ea22:	sub    rax,r12
  40ea25:	mov    ecx,0x1000
  40ea2a:	test   ecx,ecx
  40ea2c:	mov    edx,0x8
  40ea31:	cmove  ecx,edx
  40ea34:	dec    rcx
  40ea37:	mov    rdx,0xffffffffffffffff
  40ea3e:	sub    rdx,rcx
  40ea41:	cmp    rax,rdx
  40ea44:	jbe    40ea4b <__swc_fn_fc36583a_000065_de167e8d+0x5b>
  40ea46:	xor    r14d,r14d
  40ea49:	jmp    40ea56 <__swc_fn_fc36583a_000065_de167e8d+0x66>
  40ea4b:	add    rax,rcx
  40ea4e:	andn   rax,rcx,rax
  40ea53:	mov    r14,rax
  40ea56:	mov    rax,QWORD PTR [rdi+0x10]
  40ea5a:	cmp    r14,rax
  40ea5d:	ja     40ea68 <__swc_fn_fc36583a_000065_de167e8d+0x78>
  40ea5f:	pop    r14
  40ea61:	pop    r13
  40ea63:	pop    r12
  40ea65:	pop    rdi
  40ea66:	pop    rsi
  40ea67:	ret
  40ea68:	mov    rax,r12
  40ea6b:	add    rax,QWORD PTR [rdi+0x10]
  40ea6f:	mov    rdx,r14
  40ea72:	sub    rdx,QWORD PTR [rdi+0x10]
  40ea76:	mov    rcx,rax
  40ea79:	call   407340 <__swc_fn_fc36583a_000006_f7acedb0>
  40ea7e:	test   al,al
  40ea80:	jne    40ea8b <__swc_fn_fc36583a_000065_de167e8d+0x9b>
  40ea82:	pop    r14
  40ea84:	pop    r13
  40ea86:	pop    r12
  40ea88:	pop    rdi
  40ea89:	pop    rsi
  40ea8a:	ret
  40ea8b:	add    r12,r14
  40ea8e:	sub    r12,r13
  40ea91:	mov    rcx,r12
  40ea94:	sub    rcx,QWORD PTR [rdi+0x28]
  40ea98:	mov    rdx,QWORD PTR [rsi+0x250]
  40ea9f:	nop
  40eaa0:	lea    r8,[rdx+rcx*1]
  40eaa4:	mov    rax,rdx
  40eaa7:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40eab0:	cmp    rax,rdx
  40eab3:	je     40eaba <__swc_fn_fc36583a_000065_de167e8d+0xca>
  40eab5:	mov    rdx,rax
  40eab8:	jmp    40eaa0 <__swc_fn_fc36583a_000065_de167e8d+0xb0>
  40eaba:	mov    QWORD PTR [rdi+0x10],r14
  40eabe:	mov    QWORD PTR [rdi+0x28],r12
  40eac2:	pop    r14
  40eac4:	pop    r13
  40eac6:	pop    r12
  40eac8:	pop    rdi
  40eac9:	pop    rsi
  40eaca:	ret
  40eacb:	add    BYTE PTR [rax],al
  40eacd:	add    BYTE PTR [rax],al
	...

000000000040ead0 <__swc_fn_fc36583a_000068_7130736e>:
  40ead0:	push   rbx
  40ead1:	push   rsi
  40ead2:	push   rdi
  40ead3:	push   r12
  40ead5:	push   r13
  40ead7:	sub    rsp,0xe0
  40eade:	mov    rbx,rdx
  40eae1:	mov    rsi,rcx
  40eae4:	cmp    DWORD PTR [rbx+0x58],0x0
  40eae8:	je     40eb0c <__swc_fn_fc36583a_000068_7130736e+0x3c>
  40eaea:	mov    eax,DWORD PTR [rbx+0x58]
  40eaed:	sub    eax,0x1
  40eaf0:	test   DWORD PTR [rbx+0x58],eax
  40eaf3:	je     40eb0c <__swc_fn_fc36583a_000068_7130736e+0x3c>
  40eaf5:	mov    QWORD PTR [rbx+0x40],0x0
  40eafd:	add    rsp,0xe0
  40eb04:	pop    r13
  40eb06:	pop    r12
  40eb08:	pop    rdi
  40eb09:	pop    rsi
  40eb0a:	pop    rbx
  40eb0b:	ret
  40eb0c:	mov    rax,QWORD PTR [rbx+0x40]
  40eb10:	test   rax,rax
  40eb13:	jne    40eb2f <__swc_fn_fc36583a_000068_7130736e+0x5f>
  40eb15:	mov    rcx,rsi
  40eb18:	mov    rdx,rbx
  40eb1b:	call   40b930 <__swc_fn_fc36583a_000067_f3aa21af>
  40eb20:	add    rsp,0xe0
  40eb27:	pop    r13
  40eb29:	pop    r12
  40eb2b:	pop    rdi
  40eb2c:	pop    rsi
  40eb2d:	pop    rbx
  40eb2e:	ret
  40eb2f:	cmp    QWORD PTR [rbx+0x48],0x0
  40eb34:	jne    40eb50 <__swc_fn_fc36583a_000068_7130736e+0x80>
  40eb36:	mov    rcx,rsi
  40eb39:	mov    rdx,rbx
  40eb3c:	call   408030 <__swc_fn_fc36583a_000069_97813b89>
  40eb41:	add    rsp,0xe0
  40eb48:	pop    r13
  40eb4a:	pop    r12
  40eb4c:	pop    rdi
  40eb4d:	pop    rsi
  40eb4e:	pop    rbx
  40eb4f:	ret
  40eb50:	mov    rdi,QWORD PTR [rbx+0x40]
  40eb54:	lea    rax,[rip+0x1554d]        # 4240a8 <__swc_bss_base_fc36583a+0x68>
  40eb5b:	mov    rcx,rdi
  40eb5e:	sub    rcx,QWORD PTR [rax+0x8]
  40eb62:	mov    rax,QWORD PTR [rip+0x1554f]        # 4240b8 <__swc_bss_base_fc36583a+0x78>
  40eb69:	cmp    rcx,rax
  40eb6c:	jae    40eb98 <__swc_fn_fc36583a_000068_7130736e+0xc8>
  40eb6e:	mov    rax,rdi
  40eb71:	and    rax,0xffffffffffc00000
  40eb78:	mov    rcx,rdi
  40eb7b:	shr    rcx,0x10
  40eb7f:	and    ecx,0x3f
  40eb82:	mov    edx,DWORD PTR [rax+0x28]
  40eb85:	shrx   ecx,ecx,edx
  40eb8a:	shl    rcx,0x4
  40eb8e:	lea    r12,[rax+rcx*8+0x80]
  40eb96:	jmp    40eba3 <__swc_fn_fc36583a_000068_7130736e+0xd3>
  40eb98:	mov    rcx,rdi
  40eb9b:	call   40a9b0 <__swc_fn_fc36583a_000025_bcdc5519>
  40eba0:	mov    r12,rax
  40eba3:	test   r12,r12
  40eba6:	je     40ebb5 <__swc_fn_fc36583a_000068_7130736e+0xe5>
  40eba8:	mov    eax,DWORD PTR [r12+0x2c]
  40ebad:	mov    r9d,eax
  40ebb0:	mov    r13,rax
  40ebb3:	jmp    40ec34 <__swc_fn_fc36583a_000068_7130736e+0x164>
  40ebb5:	mov    rcx,rsi
  40ebb8:	mov    rdx,rdi
  40ebbb:	call   40afc0 <__swc_fn_fc36583a_000055_df0696cd>
  40ebc0:	mov    rcx,QWORD PTR [rax+0x28]
  40ebc4:	mov    r9,rcx
  40ebc7:	mov    rdx,QWORD PTR [rax+0x20]
  40ebcb:	mov    r13,rdx
  40ebce:	cmp    QWORD PTR [rbx+0x48],rcx
  40ebd2:	jbe    40ec0b <__swc_fn_fc36583a_000068_7130736e+0x13b>
  40ebd4:	mov    ecx,DWORD PTR [rax+0x48]
  40ebd7:	cmp    DWORD PTR [rbx+0x58],ecx
  40ebda:	ja     40ec0b <__swc_fn_fc36583a_000068_7130736e+0x13b>
  40ebdc:	mov    rcx,rsi
  40ebdf:	mov    rdx,rax
  40ebe2:	mov    r8,QWORD PTR [rbx+0x48]
  40ebe6:	mov    QWORD PTR [rsp+0xc8],r9
  40ebee:	mov    QWORD PTR [rsp+0xd0],rax
  40ebf6:	call   40e9f0 <__swc_fn_fc36583a_000065_de167e8d>
  40ebfb:	mov    r9,QWORD PTR [rsp+0xc8]
  40ec03:	mov    rax,QWORD PTR [rsp+0xd0]
  40ec0b:	mov    rcx,QWORD PTR [rax+0x28]
  40ec0f:	cmp    QWORD PTR [rbx+0x48],rcx
  40ec13:	ja     40ec34 <__swc_fn_fc36583a_000068_7130736e+0x164>
  40ec15:	mov    ecx,DWORD PTR [rax+0x48]
  40ec18:	cmp    DWORD PTR [rbx+0x58],ecx
  40ec1b:	ja     40ec34 <__swc_fn_fc36583a_000068_7130736e+0x164>
  40ec1d:	mov    rcx,QWORD PTR [rbx+0x48]
  40ec21:	mov    QWORD PTR [rax+0x20],rcx
  40ec25:	add    rsp,0xe0
  40ec2c:	pop    r13
  40ec2e:	pop    r12
  40ec30:	pop    rdi
  40ec31:	pop    rsi
  40ec32:	pop    rbx
  40ec33:	ret
  40ec34:	test   r12,r12
  40ec37:	je     40ec69 <__swc_fn_fc36583a_000068_7130736e+0x199>
  40ec39:	cmp    QWORD PTR [rbx+0x48],r9
  40ec3d:	ja     40ec69 <__swc_fn_fc36583a_000068_7130736e+0x199>
  40ec3f:	cmp    DWORD PTR [rbx+0x58],0x40
  40ec43:	ja     40ec69 <__swc_fn_fc36583a_000068_7130736e+0x199>
  40ec45:	cmp    DWORD PTR [rbx+0x58],0x0
  40ec49:	je     40ec56 <__swc_fn_fc36583a_000068_7130736e+0x186>
  40ec4b:	mov    ecx,DWORD PTR [rbx+0x58]
  40ec4e:	dec    rcx
  40ec51:	test   rdi,rcx
  40ec54:	jne    40ec69 <__swc_fn_fc36583a_000068_7130736e+0x199>
  40ec56:	mov    QWORD PTR [rbx+0x40],rdi
  40ec5a:	add    rsp,0xe0
  40ec61:	pop    r13
  40ec63:	pop    r12
  40ec65:	pop    rdi
  40ec66:	pop    rsi
  40ec67:	pop    rbx
  40ec68:	ret
  40ec69:	vmovups xmm0,XMMWORD PTR [rbx]
  40ec6d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ec73:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40ec78:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40ec7e:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40ec83:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40ec89:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40ec8e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40ec94:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40ec99:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40ec9f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40eca4:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40ecaa:	mov    QWORD PTR [rsp+0x48],0x0
  40ecb3:	mov    rcx,rsi
  40ecb6:	lea    rdx,[rsp+0x8]
  40ecbb:	call   40b930 <__swc_fn_fc36583a_000067_f3aa21af>
  40ecc0:	mov    rax,QWORD PTR [rsp+0x48]
  40ecc5:	test   rax,rax
  40ecc8:	jne    40ece1 <__swc_fn_fc36583a_000068_7130736e+0x211>
  40ecca:	mov    QWORD PTR [rbx+0x40],0x0
  40ecd2:	add    rsp,0xe0
  40ecd9:	pop    r13
  40ecdb:	pop    r12
  40ecdd:	pop    rdi
  40ecde:	pop    rsi
  40ecdf:	pop    rbx
  40ece0:	ret
  40ece1:	mov    rax,QWORD PTR [rbx+0x48]
  40ece5:	cmp    r13,rax
  40ece8:	cmovbe rax,r13
  40ecec:	mov    rcx,QWORD PTR [rsp+0x48]
  40ecf1:	mov    rdx,rdi
  40ecf4:	mov    r8,rax
  40ecf7:	call   409180 <__swc_fn_fc36583a_000108_7c204aac>
  40ecfc:	vmovups xmm0,XMMWORD PTR [rbx]
  40ed00:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40ed06:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40ed0b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40ed11:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40ed16:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40ed1f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40ed24:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40ed2d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40ed32:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40ed3b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40ed40:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40ed49:	mov    QWORD PTR [rsp+0xa8],rdi
  40ed51:	mov    rcx,rsi
  40ed54:	lea    rdx,[rsp+0x68]
  40ed59:	call   408030 <__swc_fn_fc36583a_000069_97813b89>
  40ed5e:	mov    rax,QWORD PTR [rsp+0x48]
  40ed63:	mov    QWORD PTR [rbx+0x40],rax
  40ed67:	add    rsp,0xe0
  40ed6e:	pop    r13
  40ed70:	pop    r12
  40ed72:	pop    rdi
  40ed73:	pop    rsi
  40ed74:	pop    rbx
  40ed75:	ret
	...

000000000040ed80 <__swc_fn_fc36583a_000071_61e60aab>:
  40ed80:	push   r12
  40ed82:	push   rdi
  40ed83:	push   rsi
  40ed84:	push   r13
  40ed86:	push   r14
  40ed88:	sub    rsp,0x190
  40ed8f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40ed98:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40eda1:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40edaa:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40edb3:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40edbc:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40edc5:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40edce:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40edd7:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40ede0:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40ede9:	mov    r12,rcx
  40edec:	lea    rax,[rip+0x13215]        # 422008 <__swc_data_base_fc36583a+0x8>
  40edf3:	mov    rax,QWORD PTR [rax]
  40edf6:	cmp    rax,0xffffffffffffffff
  40edfa:	je     40ee09 <__swc_fn_fc36583a_000071_61e60aab+0x89>
  40edfc:	mov    eax,eax
  40edfe:	mov    edi,eax
  40ee00:	xor    eax,eax
  40ee02:	call   407000 <pthread_getspecific@plt>
  40ee07:	jmp    40ee0b <__swc_fn_fc36583a_000071_61e60aab+0x8b>
  40ee09:	xor    eax,eax
  40ee0b:	test   rax,rax
  40ee0e:	jne    40ee1d <__swc_fn_fc36583a_000071_61e60aab+0x9d>
  40ee10:	call   40aa80 <__swc_fn_fc36583a_000034_cd1a4e8c>
  40ee15:	mov    rcx,rax
  40ee18:	call   410540 <__swc_fn_fc36583a_000131_5f757033>
  40ee1d:	test   rax,rax
  40ee20:	je     40ee46 <__swc_fn_fc36583a_000071_61e60aab+0xc6>
  40ee22:	cmp    QWORD PTR [rax],r12
  40ee25:	jne    40ee46 <__swc_fn_fc36583a_000071_61e60aab+0xc6>
  40ee27:	xor    ecx,ecx
  40ee29:	mov    QWORD PTR [rsp+0xc8],rax
  40ee31:	call   4077c0 <__swc_fn_fc36583a_000036_28d0e998>
  40ee36:	mov    rdx,QWORD PTR [rsp+0xc8]
  40ee3e:	mov    rcx,r12
  40ee41:	call   4078e0 <__swc_fn_fc36583a_000045_b30433d0>
  40ee46:	lea    rsi,[r12+0x10]
  40ee4b:	mov    rcx,rsi
  40ee4e:	call   409940 <__swc_fn_fc36583a_000138_86bb0f90>
  40ee53:	mov    rdi,QWORD PTR [r12+0x20]
  40ee58:	test   rdi,rdi
  40ee5b:	je     40ee9e <__swc_fn_fc36583a_000071_61e60aab+0x11e>
  40ee5d:	nop    DWORD PTR [rax]
  40ee60:	mov    rcx,r12
  40ee63:	mov    rdx,rdi
  40ee66:	call   40ac40 <__swc_fn_fc36583a_000046_6e7a8d58>
  40ee6b:	mov    rcx,r12
  40ee6e:	mov    rdx,rdi
  40ee71:	mov    r8,0xffffffffffffffff
  40ee78:	call   40e950 <__swc_fn_fc36583a_000062_dea90857>
  40ee7d:	mov    rcx,r12
  40ee80:	mov    rdx,rdi
  40ee83:	mov    r8d,0x9b8
  40ee89:	mov    r9d,0x9b8
  40ee8f:	call   4077f0 <__swc_fn_fc36583a_000042_d3c2ab54>
  40ee94:	mov    rdi,QWORD PTR [r12+0x20]
  40ee99:	test   rdi,rdi
  40ee9c:	jne    40ee60 <__swc_fn_fc36583a_000071_61e60aab+0xe0>
  40ee9e:	xor    eax,eax
  40eea0:	xchg   QWORD PTR [r12+0x2a80],rax
  40eea8:	test   rax,rax
  40eeab:	je     40eed1 <__swc_fn_fc36583a_000071_61e60aab+0x151>
  40eead:	cs nop WORD PTR [rax+rax*1+0x0]
  40eeb7:	nop    WORD PTR [rax+rax*1+0x0]
  40eec0:	mov    rcx,rax
  40eec3:	mov    rax,QWORD PTR [rax+0x78]
  40eec7:	xor    edx,edx
  40eec9:	xchg   DWORD PTR [rcx+0x70],edx
  40eecc:	test   rax,rax
  40eecf:	jne    40eec0 <__swc_fn_fc36583a_000071_61e60aab+0x140>
  40eed1:	mov    rax,QWORD PTR [r12+0x18]
  40eed6:	mov    rdi,rax
  40eed9:	test   rdi,rdi
  40eedc:	je     40ef71 <__swc_fn_fc36583a_000071_61e60aab+0x1f1>
  40eee2:	cs nop WORD PTR [rax+rax*1+0x0]
  40eeec:	nop    DWORD PTR [rax+0x0]
  40eef0:	mov    rax,QWORD PTR [rdi+0x10]
  40eef4:	mov    r8d,DWORD PTR [rdi+0x2c]
  40eef8:	xor    r9d,r9d
  40eefb:	test   r8,r8
  40eefe:	jbe    40ef5d <__swc_fn_fc36583a_000071_61e60aab+0x1dd>
  40ef00:	mov    ecx,r9d
  40ef03:	shl    rcx,0x4
  40ef07:	lea    rdx,[rdi+rcx*8+0x80]
  40ef0f:	cmp    BYTE PTR [rdx+0x3b],0x0
  40ef13:	je     40ef54 <__swc_fn_fc36583a_000071_61e60aab+0x1d4>
  40ef15:	mov    DWORD PTR [rdx+0x28],0x0
  40ef1c:	mov    rcx,rdi
  40ef1f:	mov    QWORD PTR [rsp+0xd0],rax
  40ef27:	mov    QWORD PTR [rsp+0xd8],r8
  40ef2f:	mov    QWORD PTR [rsp+0xe0],r9
  40ef37:	call   40e070 <__swc_fn_fc36583a_000017_283e2b5e>
  40ef3c:	mov    rax,QWORD PTR [rsp+0xd0]
  40ef44:	mov    r8,QWORD PTR [rsp+0xd8]
  40ef4c:	mov    r9,QWORD PTR [rsp+0xe0]
  40ef54:	add    r9,0x1
  40ef58:	cmp    r9,r8
  40ef5b:	jb     40ef00 <__swc_fn_fc36583a_000071_61e60aab+0x180>
  40ef5d:	mov    rcx,rdi
  40ef60:	mov    rdi,rax
  40ef63:	call   4076d0 <__swc_fn_fc36583a_000024_aa910677>
  40ef68:	test   rdi,rdi
  40ef6b:	jne    40eef0 <__swc_fn_fc36583a_000071_61e60aab+0x170>
  40ef71:	mov    QWORD PTR [r12+0x18],0x0
  40ef7a:	mov    QWORD PTR [r12+0x28],0x0
  40ef83:	mov    rcx,rsi
  40ef86:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  40ef8b:	mov    esi,0x8
  40ef90:	xor    edi,edi
  40ef92:	test   rsi,rsi
  40ef95:	je     40eff2 <__swc_fn_fc36583a_000071_61e60aab+0x272>
  40ef9b:	nop    DWORD PTR [rax+rax*1+0x0]
  40efa0:	lea    r13,[rdi*8+0x0]
  40efa8:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40efad:	test   r14,r14
  40efb0:	je     40efe8 <__swc_fn_fc36583a_000071_61e60aab+0x268>
  40efb2:	cs nop WORD PTR [rax+rax*1+0x0]
  40efbc:	nop    DWORD PTR [rax+0x0]
  40efc0:	mov    rcx,r12
  40efc3:	mov    rdx,r14
  40efc6:	call   407e90 <__swc_fn_fc36583a_000057_1bb23e77>
  40efcb:	mov    rcx,r12
  40efce:	mov    rdx,QWORD PTR [r14]
  40efd1:	mov    r8,QWORD PTR [r14+0x8]
  40efd5:	mov    r9,QWORD PTR [r14+0x10]
  40efd9:	call   4077f0 <__swc_fn_fc36583a_000042_d3c2ab54>
  40efde:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40efe3:	test   r14,r14
  40efe6:	jne    40efc0 <__swc_fn_fc36583a_000071_61e60aab+0x240>
  40efe8:	add    rdi,0x1
  40efec:	sub    rsi,0x1
  40eff0:	jne    40efa0 <__swc_fn_fc36583a_000071_61e60aab+0x220>
  40eff2:	mov    rcx,r12
  40eff5:	call   407f60 <__swc_fn_fc36583a_000063_ffcd96eb>
  40effa:	lea    rcx,[r12+0x250]
  40f002:	mov    rdx,QWORD PTR [rcx]
  40f005:	mov    r8,QWORD PTR [r12+0x250]
  40f00d:	nop    DWORD PTR [rax]
  40f010:	mov    r9,r8
  40f013:	sub    r9,rdx
  40f016:	mov    rax,r8
  40f019:	lock cmpxchg QWORD PTR [rcx],r9
  40f01e:	cmp    rax,r8
  40f021:	je     40f028 <__swc_fn_fc36583a_000071_61e60aab+0x2a8>
  40f023:	mov    r8,rax
  40f026:	jmp    40f010 <__swc_fn_fc36583a_000071_61e60aab+0x290>
  40f028:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40f031:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40f03a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40f043:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40f04c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40f055:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40f05e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40f067:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40f070:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40f079:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40f082:	add    rsp,0x190
  40f089:	pop    r14
  40f08b:	pop    r13
  40f08d:	pop    rsi
  40f08e:	pop    rdi
  40f08f:	pop    r12
  40f091:	ret
	...

000000000040f0a0 <__swc_fn_fc36583a_000074_64d36d78>:
  40f0a0:	sub    rsp,0x8
  40f0a4:	mov    QWORD PTR [rdx+0x40],0x0
  40f0ac:	call   40b930 <__swc_fn_fc36583a_000067_f3aa21af>
  40f0b1:	add    rsp,0x8
  40f0b5:	ret
	...

000000000040f0c0 <__swc_fn_fc36583a_000077_1966ae2e>:
  40f0c0:	sub    rsp,0x8
  40f0c4:	call   408030 <__swc_fn_fc36583a_000069_97813b89>
  40f0c9:	add    rsp,0x8
  40f0cd:	ret
	...

000000000040f0d0 <__swc_fn_fc36583a_000080_5cc7acfc>:
  40f0d0:	push   rbx
  40f0d1:	push   rsi
  40f0d2:	push   rdi
  40f0d3:	push   r12
  40f0d5:	push   r13
  40f0d7:	push   r14
  40f0d9:	push   r15
  40f0db:	sub    rsp,0x20
  40f0df:	mov    rbx,r11
  40f0e2:	mov    rsi,rcx
  40f0e5:	mov    rdi,rdx
  40f0e8:	mov    r12,r8
  40f0eb:	mov    r13,r9
  40f0ee:	mov    r14,r10
  40f0f1:	mov    rcx,QWORD PTR [rip+0x14f48]        # 424040 <__swc_bss_base_fc36583a>
  40f0f8:	test   rcx,rcx
  40f0fb:	jne    40f10d <__swc_fn_fc36583a_000080_5cc7acfc+0x3d>
  40f0fd:	call   40a240 <__swc_fn_fc36583a_000168_994c8876>
  40f102:	lea    rcx,[rax+0x1]
  40f106:	mov    QWORD PTR [rip+0x14f33],rcx        # 424040 <__swc_bss_base_fc36583a>
  40f10d:	dec    rcx
  40f110:	call   411fc0 <__swc_fn_fc36583a_000170_360af05d>
  40f115:	mov    r15,rax
  40f118:	lea    r11,[rip+0x15121]        # 424240 <__swc_bss_base_fc36583a+0x200>
  40f11f:	mov    rcx,r11
  40f122:	call   4077e0 <__swc_fn_fc36583a_000039_eb6108f2>
  40f127:	test   al,al
  40f129:	jne    40f13a <__swc_fn_fc36583a_000080_5cc7acfc+0x6a>
  40f12b:	mov    rcx,r11
  40f12e:	call   40aae0 <__swc_fn_fc36583a_000037_14f56618>
  40f133:	lea    r11,[rip+0x15106]        # 424240 <__swc_bss_base_fc36583a+0x200>
  40f13a:	mov    rcx,r11
  40f13d:	mov    rdx,rsi
  40f140:	mov    r8,rdi
  40f143:	mov    r9,r12
  40f146:	mov    r10,r13
  40f149:	mov    rsi,r11
  40f14c:	mov    r11,r14
  40f14f:	call   40e3f0 <__swc_fn_fc36583a_000038_03f1bf9a>
  40f154:	test   bl,bl
  40f156:	je     40f17d <__swc_fn_fc36583a_000080_5cc7acfc+0xad>
  40f158:	mov    QWORD PTR [rsp+0x8],rsi
  40f15d:	lea    rax,[rip+0x4114]        # 413278 <__swc_rdata_base_fc36583a+0x168>
  40f164:	mov    QWORD PTR [rsp+0x10],rax
  40f169:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f16f:	vmovups XMMWORD PTR [r15],xmm0
  40f174:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40f17d:	mov    rax,rsi
  40f180:	add    rsp,0x20
  40f184:	pop    r15
  40f186:	pop    r14
  40f188:	pop    r13
  40f18a:	pop    r12
  40f18c:	pop    rdi
  40f18d:	pop    rsi
  40f18e:	pop    rbx
  40f18f:	ret

000000000040f190 <__swc_fn_fc36583a_000083_cf82995a>:
  40f190:	sub    rsp,0x8
  40f194:	mov    rax,rcx
  40f197:	test   rcx,rcx
  40f19a:	jne    40f1a1 <__swc_fn_fc36583a_000083_cf82995a+0x11>
  40f19c:	add    rsp,0x8
  40f1a0:	ret
  40f1a1:	lea    rcx,[rax-0x10]
  40f1a5:	mov    rax,QWORD PTR [rax-0x10]
  40f1a9:	mov    rdx,rax
  40f1ac:	call   4101f0 <__swc_fn_fc36583a_000116_ed2d8fed>
  40f1b1:	add    rsp,0x8
  40f1b5:	ret
	...

000000000040f1c0 <__swc_fn_fc36583a_000086_ef55f6e4>:
  40f1c0:	sub    rsp,0x8
  40f1c4:	xor    r11d,r11d
  40f1c7:	call   4082f0 <__swc_fn_fc36583a_000087_0d280354>
  40f1cc:	add    rsp,0x8
  40f1d0:	ret
	...

000000000040f1e0 <__swc_fn_fc36583a_000089_23214800>:
  40f1e0:	push   rsi
  40f1e1:	push   rdi
  40f1e2:	push   r12
  40f1e4:	push   r13
  40f1e6:	push   r14
  40f1e8:	push   r15
  40f1ea:	sub    rsp,0x68
  40f1ee:	mov    rsi,r9
  40f1f1:	mov    rdi,rcx
  40f1f4:	mov    r12,rdx
  40f1f7:	mov    r13,r8
  40f1fa:	cmp    r8,r9
  40f1fd:	jne    40f225 <__swc_fn_fc36583a_000089_23214800+0x45>
  40f1ff:	mov    rcx,rdi
  40f202:	mov    rdx,r12
  40f205:	xor    r8d,r8d
  40f208:	call   408640 <__swc_fn_fc36583a_000093_63c1827b>
  40f20d:	test   al,al
  40f20f:	je     40f225 <__swc_fn_fc36583a_000089_23214800+0x45>
  40f211:	mov    eax,0x1
  40f216:	add    rsp,0x68
  40f21a:	pop    r15
  40f21c:	pop    r14
  40f21e:	pop    r13
  40f220:	pop    r12
  40f222:	pop    rdi
  40f223:	pop    rsi
  40f224:	ret
  40f225:	cmp    BYTE PTR [r12+0x2c],0xe
  40f22b:	je     40f23e <__swc_fn_fc36583a_000089_23214800+0x5e>
  40f22d:	xor    eax,eax
  40f22f:	add    rsp,0x68
  40f233:	pop    r15
  40f235:	pop    r14
  40f237:	pop    r13
  40f239:	pop    r12
  40f23b:	pop    rdi
  40f23c:	pop    rsi
  40f23d:	ret
  40f23e:	mov    r14,QWORD PTR [r12+0x98]
  40f246:	mov    rax,QWORD PTR [r12+0xa0]
  40f24e:	mov    r12,rax
  40f251:	xor    r15d,r15d
  40f254:	test   r12,r12
  40f257:	je     40f2bf <__swc_fn_fc36583a_000089_23214800+0xdf>
  40f259:	nop    DWORD PTR [rax+0x0]
  40f260:	mov    QWORD PTR [rsp+0x58],r12
  40f265:	lea    r12,[r15*8+0x0]
  40f26d:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40f272:	mov    rcx,rax
  40f275:	call   40c0c0 <__swc_fn_fc36583a_000085_3953ef98>
  40f27a:	cmp    BYTE PTR [rax+0x2c],0xe
  40f27e:	jne    40f2b0 <__swc_fn_fc36583a_000089_23214800+0xd0>
  40f280:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40f285:	lea    r8,[r13+rcx*1+0x0]
  40f28a:	mov    rcx,rdi
  40f28d:	mov    rdx,rax
  40f290:	mov    r9,rsi
  40f293:	call   40f1e0 <__swc_fn_fc36583a_000089_23214800>
  40f298:	test   al,al
  40f29a:	je     40f2b0 <__swc_fn_fc36583a_000089_23214800+0xd0>
  40f29c:	mov    eax,0x1
  40f2a1:	add    rsp,0x68
  40f2a5:	pop    r15
  40f2a7:	pop    r14
  40f2a9:	pop    r13
  40f2ab:	pop    r12
  40f2ad:	pop    rdi
  40f2ae:	pop    rsi
  40f2af:	ret
  40f2b0:	add    r15,0x1
  40f2b4:	mov    r12,QWORD PTR [rsp+0x58]
  40f2b9:	sub    r12,0x1
  40f2bd:	jne    40f260 <__swc_fn_fc36583a_000089_23214800+0x80>
  40f2bf:	xor    eax,eax
  40f2c1:	add    rsp,0x68
  40f2c5:	pop    r15
  40f2c7:	pop    r14
  40f2c9:	pop    r13
  40f2cb:	pop    r12
  40f2cd:	pop    rdi
  40f2ce:	pop    rsi
  40f2cf:	ret

000000000040f2d0 <__swc_fn_fc36583a_000092_c2567a3b>:
  40f2d0:	push   rbp
  40f2d1:	push   rbx
  40f2d2:	push   rsi
  40f2d3:	push   rdi
  40f2d4:	push   r12
  40f2d6:	push   r13
  40f2d8:	push   r14
  40f2da:	push   r15
  40f2dc:	sub    rsp,0x38
  40f2e0:	mov    rbp,rsp
  40f2e3:	mov    rbx,r11
  40f2e6:	mov    rsi,rdx
  40f2e9:	mov    rdi,r8
  40f2ec:	mov    r12,r9
  40f2ef:	mov    QWORD PTR [rsp+0x18],r9
  40f2f4:	mov    r13,r10
  40f2f7:	movzx  r14d,BYTE PTR [rbp+0x80]
  40f2ff:	movzx  r15d,BYTE PTR [rbp+0x88]
  40f307:	test   r11,r11
  40f30a:	je     40f310 <__swc_fn_fc36583a_000092_c2567a3b+0x40>
  40f30c:	xor    eax,eax
  40f30e:	mov    BYTE PTR [rbx],al
  40f310:	test   r12,r12
  40f313:	je     40f31e <__swc_fn_fc36583a_000092_c2567a3b+0x4e>
  40f315:	mov    QWORD PTR [r12+0x8],0x0
  40f31e:	test   rcx,rcx
  40f321:	je     40f328 <__swc_fn_fc36583a_000092_c2567a3b+0x58>
  40f323:	test   rsi,rsi
  40f326:	jne    40f33b <__swc_fn_fc36583a_000092_c2567a3b+0x6b>
  40f328:	xor    eax,eax
  40f32a:	add    rsp,0x38
  40f32e:	pop    r15
  40f330:	pop    r14
  40f332:	pop    r13
  40f334:	pop    r12
  40f336:	pop    rdi
  40f337:	pop    rsi
  40f338:	pop    rbx
  40f339:	pop    rbp
  40f33a:	ret
  40f33b:	call   40c0c0 <__swc_fn_fc36583a_000085_3953ef98>
  40f340:	mov    r12,rax
  40f343:	mov    al,r15b
  40f346:	test   r15b,r15b
  40f349:	jne    40f359 <__swc_fn_fc36583a_000092_c2567a3b+0x89>
  40f34b:	mov    eax,DWORD PTR [r12+0x28]
  40f350:	and    eax,0x10000
  40f356:	setne  al
  40f359:	lea    r15,[rsp+0x8]
  40f35e:	mov    QWORD PTR [rsp+0x20],r15
  40f363:	rex mov BYTE PTR [rsp+0x8],al
  40f368:	test   DWORD PTR [rsi+0x28],0x400000
  40f36f:	je     40f3a7 <__swc_fn_fc36583a_000092_c2567a3b+0xd7>
  40f371:	test   rsi,rsi
  40f374:	je     40f394 <__swc_fn_fc36583a_000092_c2567a3b+0xc4>
  40f376:	mov    rax,QWORD PTR [rsi+0x38]
  40f37a:	cmp    QWORD PTR [rax+0x10],rsi
  40f37e:	jne    40f394 <__swc_fn_fc36583a_000092_c2567a3b+0xc4>
  40f380:	rex mov al,BYTE PTR [rsp+0x8]
  40f385:	test   al,al
  40f387:	sete   al
  40f38a:	test   r14b,r14b
  40f38d:	sete   cl
  40f390:	test   al,cl
  40f392:	je     40f3a7 <__swc_fn_fc36583a_000092_c2567a3b+0xd7>
  40f394:	xor    eax,eax
  40f396:	add    rsp,0x38
  40f39a:	pop    r15
  40f39c:	pop    r14
  40f39e:	pop    r13
  40f3a0:	pop    r12
  40f3a2:	pop    rdi
  40f3a3:	pop    rsi
  40f3a4:	pop    rbx
  40f3a5:	pop    rbp
  40f3a6:	ret
  40f3a7:	mov    r15,r12
  40f3aa:	test   r14b,r14b
  40f3ad:	jne    40f3c4 <__swc_fn_fc36583a_000092_c2567a3b+0xf4>
  40f3af:	cmp    BYTE PTR [r12+0x2c],0x6
  40f3b5:	jne    40f3c4 <__swc_fn_fc36583a_000092_c2567a3b+0xf4>
  40f3b7:	mov    rcx,QWORD PTR [r12+0x40]
  40f3bc:	call   40c0c0 <__swc_fn_fc36583a_000085_3953ef98>
  40f3c1:	mov    r15,rax
  40f3c4:	test   r14b,r14b
  40f3c7:	je     40f3cd <__swc_fn_fc36583a_000092_c2567a3b+0xfd>
  40f3c9:	mov    r15,QWORD PTR [r15+0x30]
  40f3cd:	mov    rcx,rsi
  40f3d0:	call   40c0c0 <__swc_fn_fc36583a_000085_3953ef98>
  40f3d5:	mov    rsi,rax
  40f3d8:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f3dd:	je     40f414 <__swc_fn_fc36583a_000092_c2567a3b+0x144>
  40f3df:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f3e4:	je     40f414 <__swc_fn_fc36583a_000092_c2567a3b+0x144>
  40f3e6:	mov    eax,DWORD PTR [rsi+0x28]
  40f3e9:	and    eax,0x10000
  40f3ef:	je     40f414 <__swc_fn_fc36583a_000092_c2567a3b+0x144>
  40f3f1:	rex mov al,BYTE PTR [rsp+0x8]
  40f3f6:	test   al,al
  40f3f8:	jne    40f40d <__swc_fn_fc36583a_000092_c2567a3b+0x13d>
  40f3fa:	xor    eax,eax
  40f3fc:	add    rsp,0x38
  40f400:	pop    r15
  40f402:	pop    r14
  40f404:	pop    r13
  40f406:	pop    r12
  40f408:	pop    rdi
  40f409:	pop    rsi
  40f40a:	pop    rbx
  40f40b:	pop    rbp
  40f40c:	ret
  40f40d:	mov    rax,QWORD PTR [rsi+0x30]
  40f411:	mov    rsi,rax
  40f414:	mov    r14b,r13b
  40f417:	test   rbx,rbx
  40f41a:	je     40f450 <__swc_fn_fc36583a_000092_c2567a3b+0x180>
  40f41c:	cmp    BYTE PTR [r12+0x2c],0x6
  40f422:	jne    40f450 <__swc_fn_fc36583a_000092_c2567a3b+0x180>
  40f424:	lea    rdx,[rip+0x3e7d]        # 4132a8 <__swc_rdata_base_fc36583a+0x198>
  40f42b:	mov    rcx,rsi
  40f42e:	xor    r8d,r8d
  40f431:	call   408640 <__swc_fn_fc36583a_000093_63c1827b>
  40f436:	test   al,al
  40f438:	je     40f450 <__swc_fn_fc36583a_000092_c2567a3b+0x180>
  40f43a:	mov    BYTE PTR [rbx],0x1
  40f43d:	xor    eax,eax
  40f43f:	add    rsp,0x38
  40f443:	pop    r15
  40f445:	pop    r14
  40f447:	pop    r13
  40f449:	pop    r12
  40f44b:	pop    rdi
  40f44c:	pop    rsi
  40f44d:	pop    rbx
  40f44e:	pop    rbp
  40f44f:	ret
  40f450:	test   rdi,rdi
  40f453:	jne    40f46d <__swc_fn_fc36583a_000092_c2567a3b+0x19d>
  40f455:	test   r13b,r13b
  40f458:	jne    40f46d <__swc_fn_fc36583a_000092_c2567a3b+0x19d>
  40f45a:	xor    eax,eax
  40f45c:	add    rsp,0x38
  40f460:	pop    r15
  40f462:	pop    r14
  40f464:	pop    r13
  40f466:	pop    r12
  40f468:	pop    rdi
  40f469:	pop    rsi
  40f46a:	pop    rbx
  40f46b:	pop    rbp
  40f46c:	ret
  40f46d:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f472:	jne    40f528 <__swc_fn_fc36583a_000092_c2567a3b+0x258>
  40f478:	mov    rcx,r15
  40f47b:	mov    rdx,rsi
  40f47e:	xor    r8d,r8d
  40f481:	call   408640 <__swc_fn_fc36583a_000093_63c1827b>
  40f486:	test   al,al
  40f488:	jne    40f528 <__swc_fn_fc36583a_000092_c2567a3b+0x258>
  40f48e:	test   DWORD PTR [rsi+0x28],0x10000
  40f495:	je     40f4b3 <__swc_fn_fc36583a_000092_c2567a3b+0x1e3>
  40f497:	rex mov al,BYTE PTR [rsp+0x8]
  40f49c:	test   al,al
  40f49e:	jne    40f4b3 <__swc_fn_fc36583a_000092_c2567a3b+0x1e3>
  40f4a0:	xor    eax,eax
  40f4a2:	add    rsp,0x38
  40f4a6:	pop    r15
  40f4a8:	pop    r14
  40f4aa:	pop    r13
  40f4ac:	pop    r12
  40f4ae:	pop    rdi
  40f4af:	pop    rsi
  40f4b0:	pop    rbx
  40f4b1:	pop    rbp
  40f4b2:	ret
  40f4b3:	test   rdi,rdi
  40f4b6:	jne    40f4cb <__swc_fn_fc36583a_000092_c2567a3b+0x1fb>
  40f4b8:	xor    eax,eax
  40f4ba:	add    rsp,0x38
  40f4be:	pop    r15
  40f4c0:	pop    r14
  40f4c2:	pop    r13
  40f4c4:	pop    r12
  40f4c6:	pop    rdi
  40f4c7:	pop    rsi
  40f4c8:	pop    rbx
  40f4c9:	pop    rbp
  40f4ca:	ret
  40f4cb:	mov    rcx,QWORD PTR [rsi+0x40]
  40f4cf:	call   40c0c0 <__swc_fn_fc36583a_000085_3953ef98>
  40f4d4:	mov    rsi,rax
  40f4d7:	mov    rax,QWORD PTR [rdi]
  40f4da:	mov    rdi,rax
  40f4dd:	test   rax,rax
  40f4e0:	jne    40f523 <__swc_fn_fc36583a_000092_c2567a3b+0x253>
  40f4e2:	test   rbx,rbx
  40f4e5:	je     40f523 <__swc_fn_fc36583a_000092_c2567a3b+0x253>
  40f4e7:	mov    rcx,r15
  40f4ea:	mov    rdx,rsi
  40f4ed:	xor    r8d,r8d
  40f4f0:	call   408640 <__swc_fn_fc36583a_000093_63c1827b>
  40f4f5:	mov    rcx,rax
  40f4f8:	test   al,al
  40f4fa:	jne    40f51c <__swc_fn_fc36583a_000092_c2567a3b+0x24c>
  40f4fc:	mov    rcx,r15
  40f4ff:	mov    rdx,rsi
  40f502:	call   40c100 <__swc_fn_fc36583a_000088_d182c4dc>
  40f507:	mov    rcx,rax
  40f50a:	test   al,al
  40f50c:	jne    40f51c <__swc_fn_fc36583a_000092_c2567a3b+0x24c>
  40f50e:	mov    rcx,rsi
  40f511:	mov    rdx,r15
  40f514:	call   40c100 <__swc_fn_fc36583a_000088_d182c4dc>
  40f519:	mov    rcx,rax
  40f51c:	test   cl,cl
  40f51e:	setne  al
  40f521:	mov    BYTE PTR [rbx],al
  40f523:	xor    eax,eax
  40f525:	mov    r14b,al
  40f528:	test   rdi,rdi
  40f52b:	jne    40f545 <__swc_fn_fc36583a_000092_c2567a3b+0x275>
  40f52d:	test   r14b,r14b
  40f530:	jne    40f545 <__swc_fn_fc36583a_000092_c2567a3b+0x275>
  40f532:	xor    eax,eax
  40f534:	add    rsp,0x38
  40f538:	pop    r15
  40f53a:	pop    r14
  40f53c:	pop    r13
  40f53e:	pop    r12
  40f540:	pop    rdi
  40f541:	pop    rsi
  40f542:	pop    rbx
  40f543:	pop    rbp
  40f544:	ret
  40f545:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f54a:	je     40f556 <__swc_fn_fc36583a_000092_c2567a3b+0x286>
  40f54c:	mov    r12,QWORD PTR [rsp+0x18]
  40f551:	jmp    40f5de <__swc_fn_fc36583a_000092_c2567a3b+0x30e>
  40f556:	mov    r12,QWORD PTR [rsp+0x18]
  40f55b:	test   r12,r12
  40f55e:	jne    40f572 <__swc_fn_fc36583a_000092_c2567a3b+0x2a2>
  40f560:	mov    rcx,r15
  40f563:	mov    rdx,rsi
  40f566:	xor    r8d,r8d
  40f569:	call   408640 <__swc_fn_fc36583a_000093_63c1827b>
  40f56e:	test   al,al
  40f570:	jne    40f5de <__swc_fn_fc36583a_000092_c2567a3b+0x30e>
  40f572:	test   DWORD PTR [rsi+0x28],0x10000
  40f579:	je     40f597 <__swc_fn_fc36583a_000092_c2567a3b+0x2c7>
  40f57b:	rex mov al,BYTE PTR [rsp+0x8]
  40f580:	test   al,al
  40f582:	jne    40f597 <__swc_fn_fc36583a_000092_c2567a3b+0x2c7>
  40f584:	xor    eax,eax
  40f586:	add    rsp,0x38
  40f58a:	pop    r15
  40f58c:	pop    r14
  40f58e:	pop    r13
  40f590:	pop    r12
  40f592:	pop    rdi
  40f593:	pop    rsi
  40f594:	pop    rbx
  40f595:	pop    rbp
  40f596:	ret
  40f597:	test   rdi,rdi
  40f59a:	jne    40f5af <__swc_fn_fc36583a_000092_c2567a3b+0x2df>
  40f59c:	xor    eax,eax
  40f59e:	add    rsp,0x38
  40f5a2:	pop    r15
  40f5a4:	pop    r14
  40f5a6:	pop    r13
  40f5a8:	pop    r12
  40f5aa:	pop    rdi
  40f5ab:	pop    rsi
  40f5ac:	pop    rbx
  40f5ad:	pop    rbp
  40f5ae:	ret
  40f5af:	cmp    QWORD PTR [rdi+0x8],0x0
  40f5b4:	jne    40f5c9 <__swc_fn_fc36583a_000092_c2567a3b+0x2f9>
  40f5b6:	xor    eax,eax
  40f5b8:	add    rsp,0x38
  40f5bc:	pop    r15
  40f5be:	pop    r14
  40f5c0:	pop    r13
  40f5c2:	pop    r12
  40f5c4:	pop    rdi
  40f5c5:	pop    rsi
  40f5c6:	pop    rbx
  40f5c7:	pop    rbp
  40f5c8:	ret
  40f5c9:	mov    rax,QWORD PTR [rdi+0x8]
  40f5cd:	mov    rax,QWORD PTR [rax]
  40f5d0:	mov    rsi,rax
  40f5d3:	mov    rdi,QWORD PTR [rdi]
  40f5d6:	mov    eax,0x1
  40f5db:	mov    r14b,al
  40f5de:	test   rdi,rdi
  40f5e1:	mov    rbx,QWORD PTR [rsp+0x20]
  40f5e6:	jne    40f630 <__swc_fn_fc36583a_000092_c2567a3b+0x360>
  40f5e8:	test   r14b,r14b
  40f5eb:	je     40f61d <__swc_fn_fc36583a_000092_c2567a3b+0x34d>
  40f5ed:	test   r12,r12
  40f5f0:	je     40f61d <__swc_fn_fc36583a_000092_c2567a3b+0x34d>
  40f5f2:	mov    rcx,r15
  40f5f5:	mov    rdx,rsi
  40f5f8:	xor    r8d,r8d
  40f5fb:	mov    r9,r12
  40f5fe:	mov    rbx,QWORD PTR [rsp+0x20]
  40f603:	movzx  r10d,BYTE PTR [rbx]
  40f607:	call   40f1c0 <__swc_fn_fc36583a_000086_ef55f6e4>
  40f60c:	add    rsp,0x38
  40f610:	pop    r15
  40f612:	pop    r14
  40f614:	pop    r13
  40f616:	pop    r12
  40f618:	pop    rdi
  40f619:	pop    rsi
  40f61a:	pop    rbx
  40f61b:	pop    rbp
  40f61c:	ret
  40f61d:	xor    eax,eax
  40f61f:	add    rsp,0x38
  40f623:	pop    r15
  40f625:	pop    r14
  40f627:	pop    r13
  40f629:	pop    r12
  40f62b:	pop    rdi
  40f62c:	pop    rsi
  40f62d:	pop    rbx
  40f62e:	pop    rbp
  40f62f:	ret
  40f630:	mov    r13,rsi
  40f633:	mov    QWORD PTR [rsp+0x28],rdi
  40f638:	cmp    BYTE PTR [r15+0x2c],0xe
  40f63d:	sete   al
  40f640:	mov    r14b,al
  40f643:	jne    40f657 <__swc_fn_fc36583a_000092_c2567a3b+0x387>
  40f645:	mov    rcx,rsi
  40f648:	mov    rdx,r15
  40f64b:	call   40c100 <__swc_fn_fc36583a_000088_d182c4dc>
  40f650:	mov    r14b,al
  40f653:	test   al,al
  40f655:	jne    40f68c <__swc_fn_fc36583a_000092_c2567a3b+0x3bc>
  40f657:	cmp    BYTE PTR [r15+0x2c],0x12
  40f65c:	je     40f68c <__swc_fn_fc36583a_000092_c2567a3b+0x3bc>
  40f65e:	mov    rcx,r15
  40f661:	mov    rdx,rsi
  40f664:	mov    r8,rdi
  40f667:	mov    r9,r12
  40f66a:	mov    rax,rbx
  40f66d:	movzx  r10d,BYTE PTR [rax]
  40f671:	call   40f1c0 <__swc_fn_fc36583a_000086_ef55f6e4>
  40f676:	test   rax,rax
  40f679:	je     40f68c <__swc_fn_fc36583a_000092_c2567a3b+0x3bc>
  40f67b:	add    rsp,0x38
  40f67f:	pop    r15
  40f681:	pop    r14
  40f683:	pop    r13
  40f685:	pop    r12
  40f687:	pop    rdi
  40f688:	pop    rsi
  40f689:	pop    rbx
  40f68a:	pop    rbp
  40f68b:	ret
  40f68c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40f691:	jne    40f6b0 <__swc_fn_fc36583a_000092_c2567a3b+0x3e0>
  40f693:	mov    rax,QWORD PTR [rsi+0xd8]
  40f69a:	test   rax,rax
  40f69d:	je     40f6b0 <__swc_fn_fc36583a_000092_c2567a3b+0x3e0>
  40f69f:	add    rdi,QWORD PTR [rax+0x8]
  40f6a3:	mov    rax,QWORD PTR [rdi]
  40f6a6:	sub    rdi,QWORD PTR [rax+0x8]
  40f6aa:	mov    rax,QWORD PTR [rax]
  40f6ad:	mov    rsi,rax
  40f6b0:	test   r14b,r14b
  40f6b3:	je     40f6df <__swc_fn_fc36583a_000092_c2567a3b+0x40f>
  40f6b5:	mov    rcx,r15
  40f6b8:	mov    rdx,rsi
  40f6bb:	mov    r8,rdi
  40f6be:	mov    r9,r13
  40f6c1:	mov    r14,QWORD PTR [rsp+0x28]
  40f6c6:	mov    r10,r14
  40f6c9:	call   408520 <__swc_fn_fc36583a_000090_c1c9085b>
  40f6ce:	add    rsp,0x38
  40f6d2:	pop    r15
  40f6d4:	pop    r14
  40f6d6:	pop    r13
  40f6d8:	pop    r12
  40f6da:	pop    rdi
  40f6db:	pop    rsi
  40f6dc:	pop    rbx
  40f6dd:	pop    rbp
  40f6de:	ret
  40f6df:	mov    rcx,r15
  40f6e2:	mov    rdx,rsi
  40f6e5:	mov    r8,rdi
  40f6e8:	mov    r9,r12
  40f6eb:	movzx  r10d,BYTE PTR [rbx]
  40f6ef:	call   40f1c0 <__swc_fn_fc36583a_000086_ef55f6e4>
  40f6f4:	add    rsp,0x38
  40f6f8:	pop    r15
  40f6fa:	pop    r14
  40f6fc:	pop    r13
  40f6fe:	pop    r12
  40f700:	pop    rdi
  40f701:	pop    rsi
  40f702:	pop    rbx
  40f703:	pop    rbp
  40f704:	ret
	...

000000000040f710 <__swc_fn_fc36583a_000095_93bfe675>:
  40f710:	push   rbx
  40f711:	push   rsi
  40f712:	sub    rsp,0x18
  40f716:	mov    rbx,rcx
  40f719:	mov    rcx,QWORD PTR [rip+0x14920]        # 424040 <__swc_bss_base_fc36583a>
  40f720:	test   rcx,rcx
  40f723:	jne    40f735 <__swc_fn_fc36583a_000095_93bfe675+0x25>
  40f725:	call   40a240 <__swc_fn_fc36583a_000168_994c8876>
  40f72a:	lea    rcx,[rax+0x1]
  40f72e:	mov    QWORD PTR [rip+0x1490b],rcx        # 424040 <__swc_bss_base_fc36583a>
  40f735:	dec    rcx
  40f738:	call   411fc0 <__swc_fn_fc36583a_000170_360af05d>
  40f73d:	mov    rsi,rax
  40f740:	mov    rax,QWORD PTR [rsi+0x8]
  40f744:	test   rax,rax
  40f747:	jne    40f797 <__swc_fn_fc36583a_000095_93bfe675+0x87>
  40f749:	call   40c1f0 <__swc_fn_fc36583a_000094_ad13d15c>
  40f74e:	test   al,al
  40f750:	jne    40f797 <__swc_fn_fc36583a_000095_93bfe675+0x87>
  40f752:	lea    rdx,[rip+0x14ae7]        # 424240 <__swc_bss_base_fc36583a+0x200>
  40f759:	mov    rcx,rdx
  40f75c:	call   4077e0 <__swc_fn_fc36583a_000039_eb6108f2>
  40f761:	test   al,al
  40f763:	jne    40f774 <__swc_fn_fc36583a_000095_93bfe675+0x64>
  40f765:	mov    rcx,rdx
  40f768:	call   40aae0 <__swc_fn_fc36583a_000037_14f56618>
  40f76d:	lea    rdx,[rip+0x14acc]        # 424240 <__swc_bss_base_fc36583a+0x200>
  40f774:	mov    QWORD PTR [rsp+0x8],rdx
  40f779:	lea    rax,[rip+0x3af8]        # 413278 <__swc_rdata_base_fc36583a+0x168>
  40f780:	mov    QWORD PTR [rsp+0x10],rax
  40f785:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f78b:	vmovups XMMWORD PTR [rsi],xmm0
  40f78f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40f797:	vmovups xmm0,XMMWORD PTR [rsi]
  40f79b:	vmovups XMMWORD PTR [rbx],xmm0
  40f79f:	mov    rax,rbx
  40f7a2:	add    rsp,0x18
  40f7a6:	pop    rsi
  40f7a7:	pop    rbx
  40f7a8:	ret
  40f7a9:	add    BYTE PTR [rax],al
  40f7ab:	add    BYTE PTR [rax],al
  40f7ad:	add    BYTE PTR [rax],al
	...

000000000040f7b0 <__swc_fn_fc36583a_000098_65137b72>:
  40f7b0:	sub    rsp,0x8
  40f7b4:	call   4093e0 <__swc_fn_fc36583a_000120_0a5fa85a>
  40f7b9:	add    rsp,0x8
  40f7bd:	ret
	...

000000000040f7c0 <__swc_fn_fc36583a_000101_e34f54dc>:
  40f7c0:	push   rbx
  40f7c1:	push   rsi
  40f7c2:	sub    rsp,0x28
  40f7c6:	mov    rbx,rcx
  40f7c9:	xor    esi,esi
  40f7cb:	jmp    40f7e0 <__swc_fn_fc36583a_000101_e34f54dc+0x20>
  40f7cd:	nop    DWORD PTR [rax]
  40f7d0:	mov    QWORD PTR [rbx+0x28],rsi
  40f7d4:	mov    rsi,rbx
  40f7d7:	mov    rbx,rax
  40f7da:	nop    WORD PTR [rax+rax*1+0x0]
  40f7e0:	test   rbx,rbx
  40f7e3:	je     40f843 <__swc_fn_fc36583a_000101_e34f54dc+0x83>
  40f7e5:	mov    rcx,rbx
  40f7e8:	mov    edx,0x1
  40f7ed:	call   4082a0 <__swc_fn_fc36583a_000081_63a67586>
  40f7f2:	cmp    rax,0x1
  40f7f6:	jne    40f843 <__swc_fn_fc36583a_000101_e34f54dc+0x83>
  40f7f8:	mov    r10,QWORD PTR [rbx+0x18]
  40f7fc:	mov    rcx,r10
  40f7ff:	mov    edx,0x1
  40f804:	call   4082a0 <__swc_fn_fc36583a_000081_63a67586>
  40f809:	cmp    rax,0x1
  40f80d:	jne    40f81c <__swc_fn_fc36583a_000101_e34f54dc+0x5c>
  40f80f:	mov    rcx,r10
  40f812:	call   40c390 <__swc_fn_fc36583a_000100_d0b19c14>
  40f817:	test   rax,rax
  40f81a:	jne    40f7d0 <__swc_fn_fc36583a_000101_e34f54dc+0x10>
  40f81c:	mov    rax,QWORD PTR [rbx+0x20]
  40f820:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40f825:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f82b:	lea    rcx,[rsp+0x8]
  40f830:	mov    rdx,rbx
  40f833:	mov    r8d,0x30
  40f839:	mov    rbx,rax
  40f83c:	call   408a00 <__swc_fn_fc36583a_000099_d4bdcaa4>
  40f841:	jmp    40f7e0 <__swc_fn_fc36583a_000101_e34f54dc+0x20>
  40f843:	test   rsi,rsi
  40f846:	jne    40f84f <__swc_fn_fc36583a_000101_e34f54dc+0x8f>
  40f848:	add    rsp,0x28
  40f84c:	pop    rsi
  40f84d:	pop    rbx
  40f84e:	ret
  40f84f:	mov    rax,rsi
  40f852:	mov    rsi,QWORD PTR [rsi+0x28]
  40f856:	mov    rbx,QWORD PTR [rax+0x20]
  40f85a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40f85f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f865:	lea    rcx,[rsp+0x18]
  40f86a:	mov    rdx,rax
  40f86d:	mov    r8d,0x30
  40f873:	call   408a00 <__swc_fn_fc36583a_000099_d4bdcaa4>
  40f878:	jmp    40f7e0 <__swc_fn_fc36583a_000101_e34f54dc+0x20>
  40f87d:	add    BYTE PTR [rax],al
	...

000000000040f880 <__swc_fn_fc36583a_000104_5a85fcf5>:
  40f880:	push   rbx
  40f881:	push   rsi
  40f882:	push   rdi
  40f883:	push   r12
  40f885:	push   r13
  40f887:	sub    rsp,0x20
  40f88b:	mov    rbx,rcx
  40f88e:	lea    rsi,[rcx+0x6f8]
  40f895:	mov    edi,0x4
  40f89a:	mov    r12,rsi
  40f89d:	test   rdi,rdi
  40f8a0:	je     40f8ea <__swc_fn_fc36583a_000104_5a85fcf5+0x6a>
  40f8a2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f8ac:	nop    DWORD PTR [rax+0x0]
  40f8b0:	mov    rcx,QWORD PTR [r12+0x10]
  40f8b5:	mov    QWORD PTR [r12+0x10],0x0
  40f8be:	vxorps xmm0,xmm0,xmm0
  40f8c2:	vmovups XMMWORD PTR [r12],xmm0
  40f8c8:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40f8cf:	mov    DWORD PTR [r12+0x20],0x0
  40f8d8:	call   408a50 <__swc_fn_fc36583a_000102_2fdd2c61>
  40f8dd:	add    r12,0x90
  40f8e4:	sub    rdi,0x1
  40f8e8:	jne    40f8b0 <__swc_fn_fc36583a_000104_5a85fcf5+0x30>
  40f8ea:	mov    rax,QWORD PTR [rbx+0x938]
  40f8f1:	mov    rdi,rax
  40f8f4:	test   rdi,rdi
  40f8f7:	je     40f951 <__swc_fn_fc36583a_000104_5a85fcf5+0xd1>
  40f8f9:	nop    DWORD PTR [rax+0x0]
  40f900:	mov    r12d,0x10
  40f906:	lea    r13,[rdi+0x18]
  40f90a:	test   r12,r12
  40f90d:	je     40f946 <__swc_fn_fc36583a_000104_5a85fcf5+0xc6>
  40f90f:	nop
  40f910:	mov    rcx,QWORD PTR [r13+0x10]
  40f914:	mov    QWORD PTR [r13+0x10],0x0
  40f91c:	vxorps xmm0,xmm0,xmm0
  40f920:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40f926:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40f92c:	mov    DWORD PTR [r13+0x20],0x0
  40f934:	call   408a50 <__swc_fn_fc36583a_000102_2fdd2c61>
  40f939:	add    r13,0x90
  40f940:	sub    r12,0x1
  40f944:	jne    40f910 <__swc_fn_fc36583a_000104_5a85fcf5+0x90>
  40f946:	mov    rax,QWORD PTR [rdi]
  40f949:	mov    rdi,rax
  40f94c:	test   rax,rax
  40f94f:	jne    40f900 <__swc_fn_fc36583a_000104_5a85fcf5+0x80>
  40f951:	vxorps xmm0,xmm0,xmm0
  40f955:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40f95d:	mov    DWORD PTR [rbx+0x9b0],0x0
  40f967:	mov    DWORD PTR [rbx+0x9a8],0x0
  40f971:	mov    edi,0x4
  40f976:	mov    r12,rsi
  40f979:	lea    rsi,[rsi+0x38]
  40f97d:	test   rdi,rdi
  40f980:	je     40f9ac <__swc_fn_fc36583a_000104_5a85fcf5+0x12c>
  40f982:	cs nop WORD PTR [rax+rax*1+0x0]
  40f98c:	nop    DWORD PTR [rax+0x0]
  40f990:	mov    rcx,rsi
  40f993:	call   40d210 <__swc_fn_fc36583a_000160_13ead2ff>
  40f998:	add    rsi,0x90
  40f99f:	add    r12,0x90
  40f9a6:	sub    rdi,0x1
  40f9aa:	jne    40f990 <__swc_fn_fc36583a_000104_5a85fcf5+0x110>
  40f9ac:	mov    rax,QWORD PTR [rbx+0x938]
  40f9b3:	mov    rdi,rax
  40f9b6:	mov    QWORD PTR [rbx+0x938],0x0
  40f9c1:	test   rdi,rdi
  40f9c4:	je     40fa35 <__swc_fn_fc36583a_000104_5a85fcf5+0x1b5>
  40f9ca:	nop    WORD PTR [rax+rax*1+0x0]
  40f9d0:	mov    esi,0x10
  40f9d5:	lea    r12,[rdi+0x18]
  40f9d9:	lea    r13,[rdi+0x50]
  40f9dd:	test   rsi,rsi
  40f9e0:	je     40fa0c <__swc_fn_fc36583a_000104_5a85fcf5+0x18c>
  40f9e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f9ec:	nop    DWORD PTR [rax+0x0]
  40f9f0:	mov    rcx,r13
  40f9f3:	call   40d210 <__swc_fn_fc36583a_000160_13ead2ff>
  40f9f8:	add    r13,0x90
  40f9ff:	add    r12,0x90
  40fa06:	sub    rsi,0x1
  40fa0a:	jne    40f9f0 <__swc_fn_fc36583a_000104_5a85fcf5+0x170>
  40fa0c:	mov    rax,QWORD PTR [rdi]
  40fa0f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40fa14:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40fa1a:	lea    rcx,[rsp+0x8]
  40fa1f:	mov    rdx,rdi
  40fa22:	mov    r8d,0x918
  40fa28:	mov    rdi,rax
  40fa2b:	call   408a00 <__swc_fn_fc36583a_000099_d4bdcaa4>
  40fa30:	test   rdi,rdi
  40fa33:	jne    40f9d0 <__swc_fn_fc36583a_000104_5a85fcf5+0x150>
  40fa35:	lea    rcx,[rbx+0x68]
  40fa39:	call   40d210 <__swc_fn_fc36583a_000160_13ead2ff>
  40fa3e:	add    rsp,0x20
  40fa42:	pop    r13
  40fa44:	pop    r12
  40fa46:	pop    rdi
  40fa47:	pop    rsi
  40fa48:	pop    rbx
  40fa49:	ret
  40fa4a:	add    BYTE PTR [rax],al
  40fa4c:	add    BYTE PTR [rax],al
	...

000000000040fa50 <__swc_fn_fc36583a_000107_c51c3158>:
  40fa50:	xor    eax,eax
  40fa52:	cs nop WORD PTR [rax+rax*1+0x0]
  40fa5c:	nop    DWORD PTR [rax+0x0]
  40fa60:	mov    r9,r8
  40fa63:	sub    r9,rax
  40fa66:	cmp    r9,0x40
  40fa6a:	jb     40faa8 <__swc_fn_fc36583a_000107_c51c3158+0x58>
  40fa6c:	lea    r9,[rcx+rax*1]
  40fa70:	lea    r10,[rdx+rax*1]
  40fa74:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40fa7a:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40fa80:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40fa86:	vmovups xmm3,XMMWORD PTR [r10]
  40fa8b:	vmovups XMMWORD PTR [r9],xmm3
  40fa90:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40fa96:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40fa9c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40faa2:	lea    rax,[rax+0x40]
  40faa6:	jmp    40fa60 <__swc_fn_fc36583a_000107_c51c3158+0x10>
  40faa8:	nop    DWORD PTR [rax+rax*1+0x0]
  40fab0:	mov    r9,r8
  40fab3:	sub    r9,rax
  40fab6:	cmp    r9,0x10
  40faba:	jb     40fad4 <__swc_fn_fc36583a_000107_c51c3158+0x84>
  40fabc:	lea    r9,[rdx+rax*1]
  40fac0:	lea    r10,[rcx+rax*1]
  40fac4:	vmovups xmm0,XMMWORD PTR [r9]
  40fac9:	vmovups XMMWORD PTR [r10],xmm0
  40face:	lea    rax,[rax+0x10]
  40fad2:	jmp    40fab0 <__swc_fn_fc36583a_000107_c51c3158+0x60>
  40fad4:	cs nop WORD PTR [rax+rax*1+0x0]
  40fade:	xchg   ax,ax
  40fae0:	mov    r9,r8
  40fae3:	sub    r9,rax
  40fae6:	cmp    r9,0x8
  40faea:	jb     40fafd <__swc_fn_fc36583a_000107_c51c3158+0xad>
  40faec:	lea    r9,[rcx+rax*1]
  40faf0:	mov    r10,QWORD PTR [rdx+rax*1]
  40faf4:	mov    QWORD PTR [r9],r10
  40faf7:	lea    rax,[rax+0x8]
  40fafb:	jmp    40fae0 <__swc_fn_fc36583a_000107_c51c3158+0x90>
  40fafd:	cmp    rax,r8
  40fb00:	jae    40fb20 <__swc_fn_fc36583a_000107_c51c3158+0xd0>
  40fb02:	cs nop WORD PTR [rax+rax*1+0x0]
  40fb0c:	nop    DWORD PTR [rax+0x0]
  40fb10:	mov    r9b,BYTE PTR [rdx+rax*1]
  40fb14:	mov    BYTE PTR [rcx+rax*1],r9b
  40fb18:	inc    rax
  40fb1b:	cmp    rax,r8
  40fb1e:	jb     40fb10 <__swc_fn_fc36583a_000107_c51c3158+0xc0>
  40fb20:	ret
	...

000000000040fb30 <__swc_fn_fc36583a_000110_6814119b>:
  40fb30:	push   rbx
  40fb31:	push   r12
  40fb33:	push   rdi
  40fb34:	push   rsi
  40fb35:	push   r13
  40fb37:	push   r14
  40fb39:	push   r15
  40fb3b:	sub    rsp,0x170
  40fb42:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40fb4b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40fb54:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40fb5d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40fb66:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40fb6f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40fb78:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40fb81:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40fb8a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40fb93:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40fb9c:	mov    ebx,edx
  40fb9e:	mov    QWORD PTR [rsp+0xa8],rbx
  40fba6:	mov    r12d,ecx
  40fba9:	test   edx,edx
  40fbab:	jne    40fbc2 <__swc_fn_fc36583a_000110_6814119b+0x92>
  40fbad:	xor    eax,eax
  40fbaf:	add    rsp,0x170
  40fbb6:	pop    r15
  40fbb8:	pop    r14
  40fbba:	pop    r13
  40fbbc:	pop    rsi
  40fbbd:	pop    rdi
  40fbbe:	pop    r12
  40fbc0:	pop    rbx
  40fbc1:	ret
  40fbc2:	lea    rdi,[rip+0x39b7]        # 413580 <__swc_rdata_base_fc36583a+0x470>
  40fbc9:	mov    esi,0x90000
  40fbce:	xor    eax,eax
  40fbd0:	call   407090 <open@plt>
  40fbd5:	mov    r13,rax
  40fbd8:	mov    QWORD PTR [rsp+0xb0],rax
  40fbe0:	test   eax,eax
  40fbe2:	jge    40fbeb <__swc_fn_fc36583a_000110_6814119b+0xbb>
  40fbe4:	xor    eax,eax
  40fbe6:	jmp    4100e6 <__swc_fn_fc36583a_000110_6814119b+0x5b6>
  40fbeb:	nop    DWORD PTR [rax+rax*1+0x0]
  40fbf0:	movsxd rdi,r13d
  40fbf3:	mov    esi,0x2
  40fbf8:	xor    eax,eax
  40fbfa:	call   407120 <flock@plt>
  40fbff:	test   eax,eax
  40fc01:	je     40fc20 <__swc_fn_fc36583a_000110_6814119b+0xf0>
  40fc03:	xor    eax,eax
  40fc05:	call   407130 <__errno_location@plt>
  40fc0a:	cmp    DWORD PTR [rax],0x4
  40fc0d:	je     40fbf0 <__swc_fn_fc36583a_000110_6814119b+0xc0>
  40fc0f:	movsxd rdi,r13d
  40fc12:	xor    eax,eax
  40fc14:	call   4070b0 <close@plt>
  40fc19:	xor    eax,eax
  40fc1b:	jmp    4100e6 <__swc_fn_fc36583a_000110_6814119b+0x5b6>
  40fc20:	lea    r14,[rsp+0x8]
  40fc25:	mov    QWORD PTR [rsp+0xb8],r14
  40fc2d:	vxorps xmm0,xmm0,xmm0
  40fc31:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40fc37:	mov    QWORD PTR [rsp+0x18],0x0
  40fc40:	mov    WORD PTR [rsp+0x20],0x0
  40fc47:	mov    DWORD PTR [r14],0x67617753
  40fc4e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40fc56:	xor    eax,eax
  40fc58:	call   407010 <getpid@plt>
  40fc5d:	mov    ecx,eax
  40fc5f:	mov    eax,0x1c
  40fc64:	shrx   eax,ecx,eax
  40fc69:	and    eax,0xf
  40fc6c:	mov    rdx,QWORD PTR [rip+0x392d]        # 4135a0 <__swc_rdata_base_fc36583a+0x490>
  40fc73:	mov    al,BYTE PTR [rdx+rax*1]
  40fc76:	rex mov BYTE PTR [rsp+0x10],al
  40fc7b:	mov    eax,0x1c
  40fc80:	shrx   eax,r12d,eax
  40fc85:	and    eax,0xf
  40fc88:	mov    al,BYTE PTR [rdx+rax*1]
  40fc8b:	rex mov BYTE PTR [rsp+0x19],al
  40fc90:	mov    eax,0x18
  40fc95:	shrx   eax,ecx,eax
  40fc9a:	and    eax,0xf
  40fc9d:	mov    al,BYTE PTR [rdx+rax*1]
  40fca0:	rex mov BYTE PTR [rsp+0x11],al
  40fca5:	mov    eax,0x18
  40fcaa:	shrx   eax,r12d,eax
  40fcaf:	and    eax,0xf
  40fcb2:	mov    al,BYTE PTR [rdx+rax*1]
  40fcb5:	rex mov BYTE PTR [rsp+0x1a],al
  40fcba:	mov    eax,0x14
  40fcbf:	shrx   eax,ecx,eax
  40fcc4:	and    eax,0xf
  40fcc7:	mov    al,BYTE PTR [rdx+rax*1]
  40fcca:	rex mov BYTE PTR [rsp+0x12],al
  40fccf:	mov    eax,0x14
  40fcd4:	shrx   eax,r12d,eax
  40fcd9:	and    eax,0xf
  40fcdc:	mov    al,BYTE PTR [rdx+rax*1]
  40fcdf:	rex mov BYTE PTR [rsp+0x1b],al
  40fce4:	mov    eax,0x10
  40fce9:	shrx   eax,ecx,eax
  40fcee:	and    eax,0xf
  40fcf1:	mov    al,BYTE PTR [rdx+rax*1]
  40fcf4:	rex mov BYTE PTR [rsp+0x13],al
  40fcf9:	mov    eax,0x10
  40fcfe:	shrx   eax,r12d,eax
  40fd03:	and    eax,0xf
  40fd06:	mov    al,BYTE PTR [rdx+rax*1]
  40fd09:	rex mov BYTE PTR [rsp+0x1c],al
  40fd0e:	mov    eax,0xc
  40fd13:	shrx   eax,ecx,eax
  40fd18:	and    eax,0xf
  40fd1b:	mov    al,BYTE PTR [rdx+rax*1]
  40fd1e:	rex mov BYTE PTR [rsp+0x14],al
  40fd23:	mov    eax,0xc
  40fd28:	shrx   eax,r12d,eax
  40fd2d:	and    eax,0xf
  40fd30:	mov    al,BYTE PTR [rdx+rax*1]
  40fd33:	rex mov BYTE PTR [rsp+0x1d],al
  40fd38:	mov    eax,0x8
  40fd3d:	shrx   eax,ecx,eax
  40fd42:	and    eax,0xf
  40fd45:	mov    al,BYTE PTR [rdx+rax*1]
  40fd48:	rex mov BYTE PTR [rsp+0x15],al
  40fd4d:	mov    eax,0x8
  40fd52:	shrx   eax,r12d,eax
  40fd57:	and    eax,0xf
  40fd5a:	mov    al,BYTE PTR [rdx+rax*1]
  40fd5d:	rex mov BYTE PTR [rsp+0x1e],al
  40fd62:	mov    eax,0x4
  40fd67:	shrx   eax,ecx,eax
  40fd6c:	and    eax,0xf
  40fd6f:	mov    al,BYTE PTR [rdx+rax*1]
  40fd72:	rex mov BYTE PTR [rsp+0x16],al
  40fd77:	mov    eax,0x4
  40fd7c:	shrx   eax,r12d,eax
  40fd81:	and    eax,0xf
  40fd84:	mov    al,BYTE PTR [rdx+rax*1]
  40fd87:	rex mov BYTE PTR [rsp+0x1f],al
  40fd8c:	xor    eax,eax
  40fd8e:	shrx   eax,ecx,eax
  40fd93:	and    eax,0xf
  40fd96:	mov    al,BYTE PTR [rdx+rax*1]
  40fd99:	rex mov BYTE PTR [rsp+0x17],al
  40fd9e:	xor    eax,eax
  40fda0:	shrx   eax,r12d,eax
  40fda5:	and    eax,0xf
  40fda8:	mov    al,BYTE PTR [rdx+rax*1]
  40fdab:	rex mov BYTE PTR [rsp+0x20],al
  40fdb0:	mov    BYTE PTR [r14+0x10],0x2e
  40fdb5:	lea    r12,[rsp+0x22]
  40fdba:	vxorps xmm0,xmm0,xmm0
  40fdbe:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40fdc4:	mov    DWORD PTR [r12],0x6d656d2f
  40fdcc:	mov    WORD PTR [r12+0x4],0x6466
  40fdd4:	mov    BYTE PTR [r12+0x6],0x3a
  40fdda:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40fde0:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40fde6:	mov    rax,QWORD PTR [rsp+0x18]
  40fdeb:	mov    QWORD PTR [rsp+0x39],rax
  40fdf0:	rex mov al,BYTE PTR [rsp+0x20]
  40fdf5:	rex mov BYTE PTR [rsp+0x41],al
  40fdfa:	mov    DWORD PTR [r12+0x20],0x65642820
  40fe03:	mov    DWORD PTR [r12+0x24],0x6574656c
  40fe0c:	mov    WORD PTR [r12+0x28],0x2964
  40fe14:	lea    rdi,[rip+0x3770]        # 41358b <__swc_rdata_base_fc36583a+0x47b>
  40fe1b:	xor    eax,eax
  40fe1d:	call   407140 <opendir@plt>
  40fe22:	mov    r15,rax
  40fe25:	test   rax,rax
  40fe28:	jne    40fe3b <__swc_fn_fc36583a_000110_6814119b+0x30b>
  40fe2a:	movsxd rdi,r13d
  40fe2d:	xor    eax,eax
  40fe2f:	call   4070b0 <close@plt>
  40fe34:	xor    eax,eax
  40fe36:	jmp    4100e6 <__swc_fn_fc36583a_000110_6814119b+0x5b6>
  40fe3b:	mov    rdi,r15
  40fe3e:	xor    eax,eax
  40fe40:	call   407150 <dirfd@plt>
  40fe45:	lea    r14,[rsp+0x54]
  40fe4a:	mov    DWORD PTR [rsp+0x54],eax
  40fe4e:	lea    rbx,[rsp+0x58]
  40fe53:	cs nop WORD PTR [rax+rax*1+0x0]
  40fe5d:	nop    DWORD PTR [rax]
  40fe60:	mov    rdi,r15
  40fe63:	xor    eax,eax
  40fe65:	call   407160 <readdir@plt>
  40fe6a:	test   rax,rax
  40fe6d:	jne    40fe84 <__swc_fn_fc36583a_000110_6814119b+0x354>
  40fe6f:	mov    r12,QWORD PTR [rsp+0xa8]
  40fe77:	mov    r13,QWORD PTR [rsp+0xb0]
  40fe7f:	jmp    41000a <__swc_fn_fc36583a_000110_6814119b+0x4da>
  40fe84:	vxorps xmm0,xmm0,xmm0
  40fe88:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  40fe8e:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  40fe94:	vzeroupper
  40fe97:	lea    r13,[rax+0x13]
  40fe9b:	mov    rax,r14
  40fe9e:	movsxd rdi,DWORD PTR [rax]
  40fea1:	mov    rsi,r13
  40fea4:	mov    rdx,rbx
  40fea7:	mov    ecx,0x40
  40feac:	xor    eax,eax
  40feae:	call   407170 <readlinkat@plt>
  40feb3:	cmp    rax,0x2a
  40feb7:	jne    40fe60 <__swc_fn_fc36583a_000110_6814119b+0x330>
  40feb9:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40febf:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40fec5:	vptest xmm0,xmm0
  40feca:	jne    40fefa <__swc_fn_fc36583a_000110_6814119b+0x3ca>
  40fecc:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40fed2:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40fed8:	vptest xmm0,xmm0
  40fedd:	jne    40fefa <__swc_fn_fc36583a_000110_6814119b+0x3ca>
  40fedf:	mov    rcx,QWORD PTR [rsp+0x42]
  40fee4:	cmp    QWORD PTR [rsp+0x78],rcx
  40fee9:	jne    40fefa <__swc_fn_fc36583a_000110_6814119b+0x3ca>
  40feeb:	mov    cx,WORD PTR [rsp+0x4a]
  40fef0:	cmp    WORD PTR [rsp+0x80],cx
  40fef8:	je     40ff24 <__swc_fn_fc36583a_000110_6814119b+0x3f4>
  40fefa:	mov    rax,rbx
  40fefd:	mov    rcx,r12
  40ff00:	movzx  edx,BYTE PTR [rax]
  40ff03:	movzx  r8d,BYTE PTR [rcx]
  40ff07:	cmp    rdx,r8
  40ff0a:	jne    40ff16 <__swc_fn_fc36583a_000110_6814119b+0x3e6>
  40ff0c:	add    rax,0x1
  40ff10:	add    rcx,0x1
  40ff14:	jmp    40ff00 <__swc_fn_fc36583a_000110_6814119b+0x3d0>
  40ff16:	mov    rax,rdx
  40ff19:	sub    rax,r8
  40ff1c:	test   eax,eax
  40ff1e:	jne    40fe60 <__swc_fn_fc36583a_000110_6814119b+0x330>
  40ff24:	movsxd rdi,DWORD PTR [r14]
  40ff27:	mov    rsi,r13
  40ff2a:	mov    edx,0x80002
  40ff2f:	xor    eax,eax
  40ff31:	call   407180 <openat@plt>
  40ff36:	lea    rbx,[rsp+0x98]
  40ff3e:	mov    DWORD PTR [rsp+0x98],eax
  40ff45:	test   eax,eax
  40ff47:	mov    r13,QWORD PTR [rsp+0xb0]
  40ff4f:	jge    40ff74 <__swc_fn_fc36583a_000110_6814119b+0x444>
  40ff51:	mov    rdi,r15
  40ff54:	xor    eax,eax
  40ff56:	call   407190 <closedir@plt>
  40ff5b:	mov    r13,QWORD PTR [rsp+0xb0]
  40ff63:	movsxd rdi,r13d
  40ff66:	xor    eax,eax
  40ff68:	call   4070b0 <close@plt>
  40ff6d:	xor    eax,eax
  40ff6f:	jmp    4100e6 <__swc_fn_fc36583a_000110_6814119b+0x5b6>
  40ff74:	mov    rax,rbx
  40ff77:	movsxd rdi,DWORD PTR [rax]
  40ff7a:	xor    esi,esi
  40ff7c:	mov    edx,0x2
  40ff81:	xor    eax,eax
  40ff83:	call   4070a0 <lseek@plt>
  40ff88:	mov    r12,QWORD PTR [rsp+0xa8]
  40ff90:	cmp    rax,r12
  40ff93:	je     40ffba <__swc_fn_fc36583a_000110_6814119b+0x48a>
  40ff95:	movsxd rdi,DWORD PTR [rbx]
  40ff98:	xor    eax,eax
  40ff9a:	call   4070b0 <close@plt>
  40ff9f:	mov    rdi,r15
  40ffa2:	xor    eax,eax
  40ffa4:	call   407190 <closedir@plt>
  40ffa9:	movsxd rdi,r13d
  40ffac:	xor    eax,eax
  40ffae:	call   4070b0 <close@plt>
  40ffb3:	xor    eax,eax
  40ffb5:	jmp    4100e6 <__swc_fn_fc36583a_000110_6814119b+0x5b6>
  40ffba:	xor    edi,edi
  40ffbc:	mov    rsi,r12
  40ffbf:	mov    edx,0x3
  40ffc4:	mov    ecx,0x1
  40ffc9:	mov    rax,rbx
  40ffcc:	movsxd r8,DWORD PTR [rax]
  40ffcf:	xor    r9d,r9d
  40ffd2:	xor    eax,eax
  40ffd4:	call   4070c0 <mmap@plt>
  40ffd9:	xor    r12d,r12d
  40ffdc:	cmp    rax,0xffffffffffffffff
  40ffe0:	cmovne r12,rax
  40ffe4:	movsxd rdi,DWORD PTR [rbx]
  40ffe7:	xor    eax,eax
  40ffe9:	call   4070b0 <close@plt>
  40ffee:	mov    rdi,r15
  40fff1:	xor    eax,eax
  40fff3:	call   407190 <closedir@plt>
  40fff8:	movsxd rdi,r13d
  40fffb:	xor    eax,eax
  40fffd:	call   4070b0 <close@plt>
  410002:	mov    rax,r12
  410005:	jmp    4100e6 <__swc_fn_fc36583a_000110_6814119b+0x5b6>
  41000a:	mov    r14,QWORD PTR [rsp+0xb8]
  410012:	mov    rdi,r14
  410015:	mov    esi,0x1
  41001a:	xor    eax,eax
  41001c:	call   4071a0 <memfd_create@plt>
  410021:	lea    rbx,[rsp+0x9c]
  410029:	mov    DWORD PTR [rsp+0x9c],eax
  410030:	test   eax,eax
  410032:	jge    41004f <__swc_fn_fc36583a_000110_6814119b+0x51f>
  410034:	mov    rdi,r15
  410037:	xor    eax,eax
  410039:	call   407190 <closedir@plt>
  41003e:	movsxd rdi,r13d
  410041:	xor    eax,eax
  410043:	call   4070b0 <close@plt>
  410048:	xor    eax,eax
  41004a:	jmp    4100e6 <__swc_fn_fc36583a_000110_6814119b+0x5b6>
  41004f:	mov    rax,rbx
  410052:	movsxd rdi,DWORD PTR [rax]
  410055:	mov    rsi,r12
  410058:	xor    eax,eax
  41005a:	call   4071b0 <ftruncate@plt>
  41005f:	test   eax,eax
  410061:	je     410085 <__swc_fn_fc36583a_000110_6814119b+0x555>
  410063:	movsxd rdi,DWORD PTR [rbx]
  410066:	xor    eax,eax
  410068:	call   4070b0 <close@plt>
  41006d:	mov    rdi,r15
  410070:	xor    eax,eax
  410072:	call   407190 <closedir@plt>
  410077:	movsxd rdi,r13d
  41007a:	xor    eax,eax
  41007c:	call   4070b0 <close@plt>
  410081:	xor    eax,eax
  410083:	jmp    4100e6 <__swc_fn_fc36583a_000110_6814119b+0x5b6>
  410085:	xor    edi,edi
  410087:	mov    rsi,r12
  41008a:	mov    edx,0x3
  41008f:	mov    ecx,0x1
  410094:	mov    rax,rbx
  410097:	movsxd r8,DWORD PTR [rax]
  41009a:	xor    r9d,r9d
  41009d:	xor    eax,eax
  41009f:	call   4070c0 <mmap@plt>
  4100a4:	mov    r12,rax
  4100a7:	cmp    rax,0xffffffffffffffff
  4100ab:	jne    4100cf <__swc_fn_fc36583a_000110_6814119b+0x59f>
  4100ad:	movsxd rdi,DWORD PTR [rbx]
  4100b0:	xor    eax,eax
  4100b2:	call   4070b0 <close@plt>
  4100b7:	mov    rdi,r15
  4100ba:	xor    eax,eax
  4100bc:	call   407190 <closedir@plt>
  4100c1:	movsxd rdi,r13d
  4100c4:	xor    eax,eax
  4100c6:	call   4070b0 <close@plt>
  4100cb:	xor    eax,eax
  4100cd:	jmp    4100e6 <__swc_fn_fc36583a_000110_6814119b+0x5b6>
  4100cf:	mov    rdi,r15
  4100d2:	xor    eax,eax
  4100d4:	call   407190 <closedir@plt>
  4100d9:	movsxd rdi,r13d
  4100dc:	xor    eax,eax
  4100de:	call   4070b0 <close@plt>
  4100e3:	mov    rax,r12
  4100e6:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  4100ef:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  4100f8:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  410101:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  41010a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  410113:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  41011c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  410125:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  41012e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  410137:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  410140:	add    rsp,0x170
  410147:	pop    r15
  410149:	pop    r14
  41014b:	pop    r13
  41014d:	pop    rsi
  41014e:	pop    rdi
  41014f:	pop    r12
  410151:	pop    rbx
  410152:	ret
	...

0000000000410160 <__swc_fn_fc36583a_000113_5f48311c>:
  410160:	push   rsi
  410161:	push   rdi
  410162:	push   r12
  410164:	push   r13
  410166:	sub    rsp,0x8
  41016a:	mov    rsi,r8
  41016d:	mov    rdi,rcx
  410170:	mov    r12,rdx
  410173:	call   4091a0 <__swc_fn_fc36583a_000111_126150d1>
  410178:	mov    r13,rax
  41017b:	test   rax,rax
  41017e:	jne    41018b <__swc_fn_fc36583a_000113_5f48311c+0x2b>
  410180:	add    rsp,0x8
  410184:	pop    r13
  410186:	pop    r12
  410188:	pop    rdi
  410189:	pop    rsi
  41018a:	ret
  41018b:	mov    rcx,r13
  41018e:	call   40ce10 <__swc_fn_fc36583a_000136_8c07c14b>
  410193:	mov    rax,QWORD PTR [r13+0x8]
  410197:	test   rax,rax
  41019a:	je     4101d9 <__swc_fn_fc36583a_000113_5f48311c+0x79>
  41019c:	nop    DWORD PTR [rax+0x0]
  4101a0:	lea    rcx,[rax+0x1000]
  4101a7:	cmp    rdi,rcx
  4101aa:	jne    4101d1 <__swc_fn_fc36583a_000113_5f48311c+0x71>
  4101ac:	cmp    r12,0x1000
  4101b3:	jb     4101d1 <__swc_fn_fc36583a_000113_5f48311c+0x71>
  4101b5:	test   sil,sil
  4101b8:	setne  cl
  4101bb:	mov    BYTE PTR [rax+0x10],cl
  4101be:	mov    rcx,r13
  4101c1:	call   4106c0 <__swc_fn_fc36583a_000137_715e84ff>
  4101c6:	add    rsp,0x8
  4101ca:	pop    r13
  4101cc:	pop    r12
  4101ce:	pop    rdi
  4101cf:	pop    rsi
  4101d0:	ret
  4101d1:	mov    rax,QWORD PTR [rax]
  4101d4:	test   rax,rax
  4101d7:	jne    4101a0 <__swc_fn_fc36583a_000113_5f48311c+0x40>
  4101d9:	mov    rcx,r13
  4101dc:	call   4106c0 <__swc_fn_fc36583a_000137_715e84ff>
  4101e1:	add    rsp,0x8
  4101e5:	pop    r13
  4101e7:	pop    r12
  4101e9:	pop    rdi
  4101ea:	pop    rsi
  4101eb:	ret
  4101ec:	add    BYTE PTR [rax],al
	...

00000000004101f0 <__swc_fn_fc36583a_000116_ed2d8fed>:
  4101f0:	sub    rsp,0x8
  4101f4:	test   rcx,rcx
  4101f7:	jne    4101fe <__swc_fn_fc36583a_000116_ed2d8fed+0xe>
  4101f9:	add    rsp,0x8
  4101fd:	ret
  4101fe:	call   40c920 <__swc_fn_fc36583a_000118_d3318640>
  410203:	add    rsp,0x8
  410207:	ret
	...

0000000000410210 <__swc_fn_fc36583a_000119_2648f149>:
  410210:	push   r12
  410212:	push   r13
  410214:	push   r14
  410216:	push   rdi
  410217:	push   rsi
  410218:	sub    rsp,0xc0
  41021f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  410225:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  41022b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  410231:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410237:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  41023d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  410243:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410249:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  410252:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  41025b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  410264:	mov    r12,QWORD PTR [rcx]
  410267:	test   r12,r12
  41026a:	jne    41027c <__swc_fn_fc36583a_000119_2648f149+0x6c>
  41026c:	add    rsp,0xc0
  410273:	pop    rsi
  410274:	pop    rdi
  410275:	pop    r14
  410277:	pop    r13
  410279:	pop    r12
  41027b:	ret
  41027c:	xor    r13d,r13d
  41027f:	mov    r14,QWORD PTR [rcx+0x8]
  410283:	cs nop WORD PTR [rax+rax*1+0x0]
  41028d:	nop    DWORD PTR [rax]
  410290:	cmp    r13,r14
  410293:	jae    4102cb <__swc_fn_fc36583a_000119_2648f149+0xbb>
  410295:	lea    rax,[r12+r13*1]
  410299:	mov    rcx,r14
  41029c:	sub    rcx,r13
  41029f:	mov    edi,0x1
  4102a4:	mov    rsi,rax
  4102a7:	mov    rdx,rcx
  4102aa:	xor    eax,eax
  4102ac:	call   4071c0 <write@plt>
  4102b1:	test   rax,rax
  4102b4:	jle    4102bb <__swc_fn_fc36583a_000119_2648f149+0xab>
  4102b6:	add    r13,rax
  4102b9:	jmp    410290 <__swc_fn_fc36583a_000119_2648f149+0x80>
  4102bb:	je     4102c9 <__swc_fn_fc36583a_000119_2648f149+0xb9>
  4102bd:	xor    eax,eax
  4102bf:	call   407130 <__errno_location@plt>
  4102c4:	cmp    DWORD PTR [rax],0x4
  4102c7:	je     410290 <__swc_fn_fc36583a_000119_2648f149+0x80>
  4102c9:	jmp    4102cb <__swc_fn_fc36583a_000119_2648f149+0xbb>
  4102cb:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4102d1:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4102d7:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4102dd:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4102e3:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4102e9:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4102ef:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4102f5:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4102fe:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  410307:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410310:	add    rsp,0xc0
  410317:	pop    rsi
  410318:	pop    rdi
  410319:	pop    r14
  41031b:	pop    r13
  41031d:	pop    r12
  41031f:	ret

0000000000410320 <__swc_fn_fc36583a_000122_4f256d58>:
  410320:	push   rbx
  410321:	push   r12
  410323:	push   rdi
  410324:	push   rsi
  410325:	sub    rsp,0x4a8
  41032c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  410335:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  41033e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  410347:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  410350:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  410359:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  410362:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  41036b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  410374:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  41037d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  410386:	mov    rbx,rdx
  410389:	mov    r12d,ecx
  41038c:	vxorps xmm0,xmm0,xmm0
  410390:	xor    eax,eax
  410392:	cs nop WORD PTR [rax+rax*1+0x0]
  41039c:	nop    DWORD PTR [rax+0x0]
  4103a0:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  4103a6:	add    rax,0x10
  4103aa:	cmp    rax,0x400
  4103b1:	jne    4103a0 <__swc_fn_fc36583a_000122_4f256d58+0x80>
  4103b3:	lea    rdi,[rsp+0x8]
  4103b8:	mov    esi,0x80
  4103bd:	xor    eax,eax
  4103bf:	call   4071d0 <backtrace@plt>
  4103c4:	test   eax,eax
  4103c6:	jle    4103d5 <__swc_fn_fc36583a_000122_4f256d58+0xb5>
  4103c8:	movsxd rax,eax
  4103cb:	lea    rcx,[r12+0x1]
  4103d0:	cmp    rcx,rax
  4103d3:	jb     4103d9 <__swc_fn_fc36583a_000122_4f256d58+0xb9>
  4103d5:	xor    eax,eax
  4103d7:	jmp    41040a <__swc_fn_fc36583a_000122_4f256d58+0xea>
  4103d9:	mov    rcx,QWORD PTR [rbx+0x8]
  4103dd:	sub    rax,r12
  4103e0:	lea    rsi,[rax-0x1]
  4103e4:	cmp    rcx,rsi
  4103e7:	cmovbe rsi,rcx
  4103eb:	lea    eax,[r12+0x1]
  4103f0:	lea    rax,[rsp+rax*8+0x8]
  4103f5:	mov    rcx,QWORD PTR [rbx]
  4103f8:	mov    rdx,rax
  4103fb:	lea    r8,[rsi*8+0x0]
  410403:	call   409180 <__swc_fn_fc36583a_000108_7c204aac>
  410408:	mov    eax,esi
  41040a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  410413:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  41041c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  410425:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  41042e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  410437:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  410440:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  410449:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  410452:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  41045b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  410464:	add    rsp,0x4a8
  41046b:	pop    rsi
  41046c:	pop    rdi
  41046d:	pop    r12
  41046f:	pop    rbx
  410470:	ret
	...

0000000000410480 <__swc_fn_fc36583a_000125_fcd5a289>:
  410480:	mov    QWORD PTR [rcx],0x0
  410487:	ret
	...

0000000000410490 <__swc_fn_fc36583a_000128_4bbe3f14>:
  410490:	push   rdi
  410491:	push   rsi
  410492:	sub    rsp,0xa8
  410499:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41049f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4104a5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4104ab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4104b1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4104b7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4104bd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4104c3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4104c9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4104d2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4104db:	mov    edi,ecx
  4104dd:	mov    rsi,rdx
  4104e0:	xor    eax,eax
  4104e2:	call   407060 <pthread_setspecific@plt>
  4104e7:	test   eax,eax
  4104e9:	sete   al
  4104ec:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4104f2:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4104f8:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4104fe:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410504:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  41050a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410510:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410516:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  41051c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410525:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41052e:	add    rsp,0xa8
  410535:	pop    rsi
  410536:	pop    rdi
  410537:	ret
	...

0000000000410540 <__swc_fn_fc36583a_000131_5f757033>:
  410540:	push   rdi
  410541:	push   rsi
  410542:	sub    rsp,0xa8
  410549:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41054f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410555:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41055b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410561:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410567:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41056d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410573:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410579:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410582:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41058b:	test   rcx,rcx
  41058e:	je     4105a1 <__swc_fn_fc36583a_000131_5f757033+0x61>
  410590:	lea    rax,[rcx-0x1]
  410594:	mov    eax,eax
  410596:	mov    edi,eax
  410598:	xor    eax,eax
  41059a:	call   407000 <pthread_getspecific@plt>
  41059f:	jmp    4105a3 <__swc_fn_fc36583a_000131_5f757033+0x63>
  4105a1:	xor    eax,eax
  4105a3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4105a9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4105af:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4105b5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4105bb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4105c1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4105c7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4105cd:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4105d3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4105dc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4105e5:	add    rsp,0xa8
  4105ec:	pop    rsi
  4105ed:	pop    rdi
  4105ee:	ret
	...

00000000004105f0 <__swc_fn_fc36583a_000134_07d76562>:
  4105f0:	push   rdi
  4105f1:	push   rsi
  4105f2:	sub    rsp,0xb8
  4105f9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4105ff:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410605:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41060b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410611:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410617:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41061d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410623:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41062c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410635:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41063e:	vxorps xmm0,xmm0,xmm0
  410642:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410648:	mov    edi,0x1
  41064d:	lea    rsi,[rsp+0x8]
  410652:	xor    eax,eax
  410654:	call   4070e0 <clock_gettime@plt>
  410659:	mov    rax,QWORD PTR [rsp+0x8]
  41065e:	imul   rax,rax,0x3b9aca00
  410665:	add    rax,QWORD PTR [rsp+0x10]
  41066a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410670:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  410676:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  41067c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  410682:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410688:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  41068e:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  410694:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  41069d:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4106a6:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4106af:	add    rsp,0xb8
  4106b6:	pop    rsi
  4106b7:	pop    rdi
  4106b8:	ret
  4106b9:	add    BYTE PTR [rax],al
  4106bb:	add    BYTE PTR [rax],al
  4106bd:	add    BYTE PTR [rax],al
	...

00000000004106c0 <__swc_fn_fc36583a_000137_715e84ff>:
  4106c0:	sub    rsp,0x8
  4106c4:	xor    eax,eax
  4106c6:	mov    DWORD PTR [rcx],eax
  4106c8:	mov    edx,0x7fffffff
  4106cd:	call   409880 <__swc_fn_fc36583a_000135_865f5106>
  4106d2:	add    rsp,0x8
  4106d6:	ret
	...

00000000004106e0 <__swc_fn_fc36583a_000140_519fdf94>:
  4106e0:	push   rdi
  4106e1:	push   rsi
  4106e2:	sub    rsp,0xb8
  4106e9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4106ef:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4106f5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4106fb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410701:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410707:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41070d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410713:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41071c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410725:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41072e:	mov    edi,0x1
  410733:	xor    eax,eax
  410735:	call   4071e0 <__x86_get_cpuid_feature_leaf@plt>
  41073a:	mov    eax,DWORD PTR [rax+0x14]
  41073d:	and    eax,0x20
  410740:	setne  al
  410743:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410749:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  41074f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410755:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41075b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410761:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  410767:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41076d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  410776:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  41077f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410788:	add    rsp,0xb8
  41078f:	pop    rsi
  410790:	pop    rdi
  410791:	ret
	...

00000000004107a0 <__swc_fn_fc36583a_000143_d5d4d43f>:
  4107a0:	push   rsi
  4107a1:	push   rdi
  4107a2:	push   r12
  4107a4:	push   r13
  4107a6:	push   r14
  4107a8:	push   r15
  4107aa:	cmp    rdx,0x40
  4107ae:	jae    4107bd <__swc_fn_fc36583a_000143_d5d4d43f+0x1d>
  4107b0:	xor    eax,eax
  4107b2:	pop    r15
  4107b4:	pop    r14
  4107b6:	pop    r13
  4107b8:	pop    r12
  4107ba:	pop    rdi
  4107bb:	pop    rsi
  4107bc:	ret
  4107bd:	cmp    BYTE PTR [rcx],0x7f
  4107c0:	jne    410804 <__swc_fn_fc36583a_000143_d5d4d43f+0x64>
  4107c2:	movzx  eax,BYTE PTR [rcx+0x1]
  4107c6:	cmp    eax,0x45
  4107c9:	setne  al
  4107cc:	jne    410800 <__swc_fn_fc36583a_000143_d5d4d43f+0x60>
  4107ce:	movzx  eax,BYTE PTR [rcx+0x2]
  4107d2:	cmp    eax,0x4c
  4107d5:	setne  al
  4107d8:	jne    410800 <__swc_fn_fc36583a_000143_d5d4d43f+0x60>
  4107da:	movzx  eax,BYTE PTR [rcx+0x3]
  4107de:	cmp    eax,0x46
  4107e1:	setne  al
  4107e4:	jne    410800 <__swc_fn_fc36583a_000143_d5d4d43f+0x60>
  4107e6:	cmp    BYTE PTR [rcx+0x4],0x2
  4107ea:	setne  al
  4107ed:	jne    410800 <__swc_fn_fc36583a_000143_d5d4d43f+0x60>
  4107ef:	cmp    BYTE PTR [rcx+0x5],0x1
  4107f3:	setne  al
  4107f6:	jne    410800 <__swc_fn_fc36583a_000143_d5d4d43f+0x60>
  4107f8:	cmp    WORD PTR [rcx+0x12],0x3e
  4107fd:	setne  al
  410800:	test   al,al
  410802:	je     410811 <__swc_fn_fc36583a_000143_d5d4d43f+0x71>
  410804:	xor    eax,eax
  410806:	pop    r15
  410808:	pop    r14
  41080a:	pop    r13
  41080c:	pop    r12
  41080e:	pop    rdi
  41080f:	pop    rsi
  410810:	ret
  410811:	cmp    WORD PTR [rcx+0x3a],0x40
  410816:	jne    410831 <__swc_fn_fc36583a_000143_d5d4d43f+0x91>
  410818:	cmp    WORD PTR [rcx+0x3c],0x0
  41081d:	sete   al
  410820:	je     41082d <__swc_fn_fc36583a_000143_d5d4d43f+0x8d>
  410822:	mov    ax,WORD PTR [rcx+0x3c]
  410826:	cmp    WORD PTR [rcx+0x3e],ax
  41082a:	setae  al
  41082d:	test   al,al
  41082f:	je     41083e <__swc_fn_fc36583a_000143_d5d4d43f+0x9e>
  410831:	xor    eax,eax
  410833:	pop    r15
  410835:	pop    r14
  410837:	pop    r13
  410839:	pop    r12
  41083b:	pop    rdi
  41083c:	pop    rsi
  41083d:	ret
  41083e:	movzx  eax,WORD PTR [rcx+0x3c]
  410842:	shl    rax,0x6
  410846:	cmp    rax,rdx
  410849:	ja     410857 <__swc_fn_fc36583a_000143_d5d4d43f+0xb7>
  41084b:	mov    r9,rdx
  41084e:	sub    r9,rax
  410851:	cmp    QWORD PTR [rcx+0x28],r9
  410855:	jbe    410864 <__swc_fn_fc36583a_000143_d5d4d43f+0xc4>
  410857:	xor    eax,eax
  410859:	pop    r15
  41085b:	pop    r14
  41085d:	pop    r13
  41085f:	pop    r12
  410861:	pop    rdi
  410862:	pop    rsi
  410863:	ret
  410864:	mov    rax,QWORD PTR [rcx+0x28]
  410868:	add    rax,rcx
  41086b:	movzx  r9d,WORD PTR [rcx+0x3e]
  410870:	lea    r9,[r9*8+0x0]
  410878:	lea    r10,[rax+r9*8]
  41087c:	cmp    QWORD PTR [r10+0x20],rdx
  410880:	ja     4108a2 <__swc_fn_fc36583a_000143_d5d4d43f+0x102>
  410882:	mov    r11,rdx
  410885:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  41088a:	cmp    QWORD PTR [r10+0x18],r11
  41088e:	seta   r9b
  410892:	ja     41089d <__swc_fn_fc36583a_000143_d5d4d43f+0xfd>
  410894:	cmp    QWORD PTR [r10+0x20],0x9
  410899:	setb   r9b
  41089d:	test   r9b,r9b
  4108a0:	je     4108af <__swc_fn_fc36583a_000143_d5d4d43f+0x10f>
  4108a2:	xor    eax,eax
  4108a4:	pop    r15
  4108a6:	pop    r14
  4108a8:	pop    r13
  4108aa:	pop    r12
  4108ac:	pop    rdi
  4108ad:	pop    rsi
  4108ae:	ret
  4108af:	movzx  r9d,WORD PTR [rcx+0x3c]
  4108b4:	xor    r11d,r11d
  4108b7:	test   r9,r9
  4108ba:	jbe    4109b5 <__swc_fn_fc36583a_000143_d5d4d43f+0x215>
  4108c0:	mov    rsi,QWORD PTR [r10+0x20]
  4108c4:	sub    rsi,0x9
  4108c8:	cs nop WORD PTR [rax+rax*1+0x0]
  4108d2:	cs nop WORD PTR [rax+rax*1+0x0]
  4108dc:	nop    DWORD PTR [rax+0x0]
  4108e0:	movzx  edi,r11w
  4108e4:	lea    rdi,[rdi*8+0x0]
  4108ec:	lea    r12,[rax+rdi*8]
  4108f0:	rex mov edi,DWORD PTR [rax+rdi*8]
  4108f4:	cmp    rdi,rsi
  4108f7:	ja     4109a8 <__swc_fn_fc36583a_000143_d5d4d43f+0x208>
  4108fd:	mov    r13,QWORD PTR [r10+0x18]
  410901:	add    r13,rdi
  410904:	lea    rdi,[rcx+r13*1]
  410908:	lea    r13,[rip+0x2cf1]        # 413600 <__swc_rdata_base_fc36583a+0x4f0>
  41090f:	movabs r14,0x676264676177732e
  410919:	cmp    QWORD PTR [rdi],r14
  41091c:	jne    410925 <__swc_fn_fc36583a_000143_d5d4d43f+0x185>
  41091e:	rex cmp BYTE PTR [rdi+0x8],0x0
  410923:	je     410952 <__swc_fn_fc36583a_000143_d5d4d43f+0x1b2>
  410925:	cs nop WORD PTR [rax+rax*1+0x0]
  41092f:	nop
  410930:	movzx  r14d,BYTE PTR [rdi]
  410934:	movzx  r15d,BYTE PTR [r13+0x0]
  410939:	cmp    r14,r15
  41093c:	jne    410948 <__swc_fn_fc36583a_000143_d5d4d43f+0x1a8>
  41093e:	add    rdi,0x1
  410942:	add    r13,0x1
  410946:	jmp    410930 <__swc_fn_fc36583a_000143_d5d4d43f+0x190>
  410948:	mov    rdi,r14
  41094b:	sub    rdi,r15
  41094e:	test   edi,edi
  410950:	jne    4109a8 <__swc_fn_fc36583a_000143_d5d4d43f+0x208>
  410952:	cmp    DWORD PTR [r12+0x4],0x1
  410958:	jne    410980 <__swc_fn_fc36583a_000143_d5d4d43f+0x1e0>
  41095a:	cmp    QWORD PTR [r12+0x20],0x10
  410960:	setb   al
  410963:	jb     41097c <__swc_fn_fc36583a_000143_d5d4d43f+0x1dc>
  410965:	cmp    QWORD PTR [r12+0x20],rdx
  41096a:	seta   al
  41096d:	ja     41097c <__swc_fn_fc36583a_000143_d5d4d43f+0x1dc>
  41096f:	sub    rdx,QWORD PTR [r12+0x20]
  410974:	cmp    QWORD PTR [r12+0x18],rdx
  410979:	seta   al
  41097c:	test   al,al
  41097e:	je     41098d <__swc_fn_fc36583a_000143_d5d4d43f+0x1ed>
  410980:	xor    eax,eax
  410982:	pop    r15
  410984:	pop    r14
  410986:	pop    r13
  410988:	pop    r12
  41098a:	pop    rdi
  41098b:	pop    rsi
  41098c:	ret
  41098d:	mov    rax,QWORD PTR [r12+0x20]
  410992:	mov    QWORD PTR [r8],rax
  410995:	mov    rax,QWORD PTR [r12+0x18]
  41099a:	add    rax,rcx
  41099d:	pop    r15
  41099f:	pop    r14
  4109a1:	pop    r13
  4109a3:	pop    r12
  4109a5:	pop    rdi
  4109a6:	pop    rsi
  4109a7:	ret
  4109a8:	add    r11,0x1
  4109ac:	cmp    r11,r9
  4109af:	jb     4108e0 <__swc_fn_fc36583a_000143_d5d4d43f+0x140>
  4109b5:	xor    eax,eax
  4109b7:	pop    r15
  4109b9:	pop    r14
  4109bb:	pop    r13
  4109bd:	pop    r12
  4109bf:	pop    rdi
  4109c0:	pop    rsi
  4109c1:	ret
	...

00000000004109d0 <__swc_fn_fc36583a_000146_d7edc04f>:
  4109d0:	push   rdi
  4109d1:	push   rsi
  4109d2:	sub    rsp,0xa8
  4109d9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4109df:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4109e5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4109eb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4109f1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4109f7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4109fd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410a03:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410a09:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410a12:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  410a1b:	mov    rdi,rcx
  410a1e:	xor    eax,eax
  410a20:	call   4071f0 <free@plt>
  410a25:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410a2b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410a31:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410a37:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410a3d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410a43:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410a49:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410a4f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410a55:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410a5e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410a67:	add    rsp,0xa8
  410a6e:	pop    rsi
  410a6f:	pop    rdi
  410a70:	ret
	...

0000000000410a80 <__swc_fn_fc36583a_000149_6203dca2>:
  410a80:	push   rbx
  410a81:	push   rsi
  410a82:	push   rdi
  410a83:	push   r12
  410a85:	push   r13
  410a87:	push   r15
  410a89:	sub    rsp,0x4e8
  410a90:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  410a99:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  410aa2:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  410aab:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  410ab4:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  410abd:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  410ac6:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  410acf:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  410ad8:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  410ae1:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  410aea:	mov    rbx,QWORD PTR [rcx]
  410aed:	mov    rcx,QWORD PTR [rcx+0x8]
  410af1:	mov    rsi,rcx
  410af4:	xor    edi,edi
  410af6:	vmovsd xmm6,QWORD PTR [rip+0x2b62]        # 413660 <__swc_rdata_base_fc36583a+0x550>
  410afe:	vmovsd xmm7,QWORD PTR [rip+0x2b63]        # 413669 <__swc_rdata_base_fc36583a+0x559>
  410b06:	vmovsd xmm8,QWORD PTR [rip+0x2b64]        # 413672 <__swc_rdata_base_fc36583a+0x562>
  410b0e:	vmovsd xmm9,QWORD PTR [rip+0x2b65]        # 41367b <__swc_rdata_base_fc36583a+0x56b>
  410b16:	vmovsd xmm10,QWORD PTR [rip+0x2b66]        # 413684 <__swc_rdata_base_fc36583a+0x574>
  410b1e:	vmovups xmm11,xmm6
  410b22:	vmovsd QWORD PTR [rsp+0x418],xmm7
  410b2b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  410b34:	vmovsd QWORD PTR [rsp+0x428],xmm9
  410b3d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  410b46:	vmovsd xmm15,QWORD PTR [rip+0x2b3f]        # 41368d <__swc_rdata_base_fc36583a+0x57d>
  410b4e:	vmovups xmm14,xmm15
  410b53:	vmovups xmm0,xmm9
  410b58:	vmovsd QWORD PTR [rsp+0x438],xmm15
  410b61:	vmovups xmm13,xmm8
  410b66:	vmovsd QWORD PTR [rsp+0x440],xmm15
  410b6f:	test   rsi,rsi
  410b72:	je     411b63 <__swc_fn_fc36583a_000149_6203dca2+0x10e3>
  410b78:	cs nop WORD PTR [rax+rax*1+0x0]
  410b82:	cs nop WORD PTR [rax+rax*1+0x0]
  410b8c:	nop    DWORD PTR [rax+0x0]
  410b90:	lea    rcx,[rdi+rdi*1]
  410b94:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  410b99:	vpshufd xmm3,xmm2,0xee
  410b9e:	vmovq  rcx,xmm3
  410ba3:	test   rcx,rcx
  410ba6:	je     410bbc <__swc_fn_fc36583a_000149_6203dca2+0x13c>
  410ba8:	test   DWORD PTR [rcx+0x28],0x400000
  410baf:	je     410bbc <__swc_fn_fc36583a_000149_6203dca2+0x13c>
  410bb1:	mov    rdx,QWORD PTR [rcx+0x30]
  410bb5:	test   rdx,rdx
  410bb8:	cmovne rcx,rdx
  410bbc:	test   DWORD PTR [rcx+0x28],0x1000
  410bc3:	je     410be4 <__swc_fn_fc36583a_000149_6203dca2+0x164>
  410bc5:	mov    rdx,QWORD PTR [rcx+0x40]
  410bc9:	mov    rcx,rdx
  410bcc:	vmovq  r8,xmm2
  410bd1:	mov    r8,QWORD PTR [r8]
  410bd4:	mov    QWORD PTR [rsp+0x60],r8
  410bd9:	mov    QWORD PTR [rsp+0x68],rdx
  410bde:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  410be4:	test   BYTE PTR [rcx+0x28],0x1
  410be8:	jne    410bf0 <__swc_fn_fc36583a_000149_6203dca2+0x170>
  410bea:	vmovups xmm12,xmm0
  410bee:	jmp    410c0a <__swc_fn_fc36583a_000149_6203dca2+0x18a>
  410bf0:	vmovq  rax,xmm2
  410bf5:	mov    rax,QWORD PTR [rax]
  410bf8:	lea    rcx,[rax+0x10]
  410bfc:	vmovups xmm12,xmm0
  410c00:	call   410210 <__swc_fn_fc36583a_000119_2648f149>
  410c05:	jmp    411b45 <__swc_fn_fc36583a_000149_6203dca2+0x10c5>
  410c0a:	test   DWORD PTR [rcx+0x28],0x400
  410c11:	je     410c72 <__swc_fn_fc36583a_000149_6203dca2+0x1f2>
  410c13:	vmovq  rax,xmm2
  410c18:	mov    rax,QWORD PTR [rax]
  410c1b:	xor    ecx,ecx
  410c1d:	test   rax,rax
  410c20:	je     410c50 <__swc_fn_fc36583a_000149_6203dca2+0x1d0>
  410c22:	mov    rdx,rax
  410c25:	mov    r8b,BYTE PTR [rdx]
  410c28:	test   r8b,r8b
  410c2b:	je     410c50 <__swc_fn_fc36583a_000149_6203dca2+0x1d0>
  410c2d:	cs nop WORD PTR [rax+rax*1+0x0]
  410c37:	nop    WORD PTR [rax+rax*1+0x0]
  410c40:	add    rdx,0x1
  410c44:	add    rcx,0x1
  410c48:	mov    r8b,BYTE PTR [rdx]
  410c4b:	test   r8b,r8b
  410c4e:	jne    410c40 <__swc_fn_fc36583a_000149_6203dca2+0x1c0>
  410c50:	mov    QWORD PTR [rsp+0x88],rax
  410c58:	mov    QWORD PTR [rsp+0x90],rcx
  410c60:	lea    rcx,[rsp+0x88]
  410c68:	call   410210 <__swc_fn_fc36583a_000119_2648f149>
  410c6d:	jmp    411b45 <__swc_fn_fc36583a_000149_6203dca2+0x10c5>
  410c72:	cmp    BYTE PTR [rcx+0x2c],0x6
  410c76:	jne    410c8d <__swc_fn_fc36583a_000149_6203dca2+0x20d>
  410c78:	vmovq  rax,xmm2
  410c7d:	mov    rax,QWORD PTR [rax]
  410c80:	mov    rcx,rax
  410c83:	call   409d50 <__swc_fn_fc36583a_000147_43c96957>
  410c88:	jmp    411b45 <__swc_fn_fc36583a_000149_6203dca2+0x10c5>
  410c8d:	cmp    BYTE PTR [rcx+0x2c],0x1
  410c91:	jne    411b39 <__swc_fn_fc36583a_000149_6203dca2+0x10b9>
  410c97:	vmovq  rdx,xmm2
  410c9c:	mov    cl,BYTE PTR [rcx+0x40]
  410c9f:	cmp    cl,0x7
  410ca2:	jb     410ce5 <__swc_fn_fc36583a_000149_6203dca2+0x265>
  410ca4:	je     410d58 <__swc_fn_fc36583a_000149_6203dca2+0x2d8>
  410caa:	cmp    cl,0x8
  410cad:	je     410d64 <__swc_fn_fc36583a_000149_6203dca2+0x2e4>
  410cb3:	cmp    cl,0x9
  410cb6:	je     410d7d <__swc_fn_fc36583a_000149_6203dca2+0x2fd>
  410cbc:	cmp    cl,0xa
  410cbf:	je     411444 <__swc_fn_fc36583a_000149_6203dca2+0x9c4>
  410cc5:	cmp    cl,0xb
  410cc8:	je     411b0b <__swc_fn_fc36583a_000149_6203dca2+0x108b>
  410cce:	cmp    cl,0xc
  410cd1:	je     410d71 <__swc_fn_fc36583a_000149_6203dca2+0x2f1>
  410cd7:	cmp    cl,0xd
  410cda:	je     411b01 <__swc_fn_fc36583a_000149_6203dca2+0x1081>
  410ce0:	jmp    411b2b <__swc_fn_fc36583a_000149_6203dca2+0x10ab>
  410ce5:	cmp    cl,0x1
  410ce8:	je     410d08 <__swc_fn_fc36583a_000149_6203dca2+0x288>
  410cea:	cmp    cl,0x2
  410ced:	je     410d16 <__swc_fn_fc36583a_000149_6203dca2+0x296>
  410cef:	cmp    cl,0x3
  410cf2:	je     410d24 <__swc_fn_fc36583a_000149_6203dca2+0x2a4>
  410cf4:	cmp    cl,0x4
  410cf7:	je     410d31 <__swc_fn_fc36583a_000149_6203dca2+0x2b1>
  410cf9:	cmp    cl,0x5
  410cfc:	je     410d3e <__swc_fn_fc36583a_000149_6203dca2+0x2be>
  410cfe:	cmp    cl,0x6
  410d01:	je     410d4b <__swc_fn_fc36583a_000149_6203dca2+0x2cb>
  410d03:	jmp    411b2b <__swc_fn_fc36583a_000149_6203dca2+0x10ab>
  410d08:	movsx  rcx,BYTE PTR [rdx]
  410d0c:	call   40d000 <__swc_fn_fc36583a_000148_2eb804cc>
  410d11:	jmp    411b45 <__swc_fn_fc36583a_000149_6203dca2+0x10c5>
  410d16:	movsx  rcx,WORD PTR [rdx]
  410d1a:	call   40d000 <__swc_fn_fc36583a_000148_2eb804cc>
  410d1f:	jmp    411b45 <__swc_fn_fc36583a_000149_6203dca2+0x10c5>
  410d24:	movsxd rcx,DWORD PTR [rdx]
  410d27:	call   40d000 <__swc_fn_fc36583a_000148_2eb804cc>
  410d2c:	jmp    411b45 <__swc_fn_fc36583a_000149_6203dca2+0x10c5>
  410d31:	mov    rcx,QWORD PTR [rdx]
  410d34:	call   40d000 <__swc_fn_fc36583a_000148_2eb804cc>
  410d39:	jmp    411b45 <__swc_fn_fc36583a_000149_6203dca2+0x10c5>
  410d3e:	movzx  ecx,BYTE PTR [rdx]
  410d41:	call   409d50 <__swc_fn_fc36583a_000147_43c96957>
  410d46:	jmp    411b45 <__swc_fn_fc36583a_000149_6203dca2+0x10c5>
  410d4b:	movzx  ecx,WORD PTR [rdx]
  410d4e:	call   409d50 <__swc_fn_fc36583a_000147_43c96957>
  410d53:	jmp    411b45 <__swc_fn_fc36583a_000149_6203dca2+0x10c5>
  410d58:	mov    ecx,DWORD PTR [rdx]
  410d5a:	call   409d50 <__swc_fn_fc36583a_000147_43c96957>
  410d5f:	jmp    411b45 <__swc_fn_fc36583a_000149_6203dca2+0x10c5>
  410d64:	mov    rcx,QWORD PTR [rdx]
  410d67:	call   409d50 <__swc_fn_fc36583a_000147_43c96957>
  410d6c:	jmp    411b45 <__swc_fn_fc36583a_000149_6203dca2+0x10c5>
  410d71:	mov    ecx,DWORD PTR [rdx]
  410d73:	call   409d50 <__swc_fn_fc36583a_000147_43c96957>
  410d78:	jmp    411b45 <__swc_fn_fc36583a_000149_6203dca2+0x10c5>
  410d7d:	lea    rcx,[rsp+0xa8]
  410d85:	vxorps xmm0,xmm0,xmm0
  410d89:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  410d92:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  410d9b:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  410da4:	vzeroupper
  410da7:	mov    DWORD PTR [rsp+0x108],0x0
  410db2:	vxorpd xmm0,xmm0,xmm0
  410db6:	vmovss xmm1,DWORD PTR [rdx]
  410dba:	vcvtss2sd xmm0,xmm0,xmm1
  410dbe:	vmovsd xmm1,xmm1,xmm0
  410dc2:	vcomisd xmm0,xmm0
  410dc6:	setne  dl
  410dc9:	movzx  edx,dl
  410dcc:	setp   r8b
  410dd0:	movzx  r8d,r8b
  410dd4:	or     edx,r8d
  410dd7:	test   dl,dl
  410dd9:	je     410de6 <__swc_fn_fc36583a_000149_6203dca2+0x366>
  410ddb:	mov    DWORD PTR [rcx],0x6e616e
  410de1:	jmp    4113d8 <__swc_fn_fc36583a_000149_6203dca2+0x958>
  410de6:	vcomisd xmm1,xmm6
  410dea:	ja     410df2 <__swc_fn_fc36583a_000149_6203dca2+0x372>
  410dec:	vcomisd xmm7,xmm1
  410df0:	jbe    410e16 <__swc_fn_fc36583a_000149_6203dca2+0x396>
  410df2:	vxorpd xmm0,xmm0,xmm0
  410df6:	vcomisd xmm0,xmm1
  410dfa:	jbe    410e0b <__swc_fn_fc36583a_000149_6203dca2+0x38b>
  410dfc:	mov    DWORD PTR [rcx],0x666e692d
  410e02:	mov    BYTE PTR [rcx+0x4],0x0
  410e06:	jmp    4113d8 <__swc_fn_fc36583a_000149_6203dca2+0x958>
  410e0b:	mov    DWORD PTR [rcx],0x666e69
  410e11:	jmp    4113d8 <__swc_fn_fc36583a_000149_6203dca2+0x958>
  410e16:	vcomisd xmm1,xmm8
  410e1b:	jae    410e27 <__swc_fn_fc36583a_000149_6203dca2+0x3a7>
  410e1d:	vcomisd xmm9,xmm1
  410e21:	jbe    41119e <__swc_fn_fc36583a_000149_6203dca2+0x71e>
  410e27:	vmovups xmm0,xmm1
  410e2b:	vxorpd xmm2,xmm2,xmm2
  410e2f:	vcomisd xmm2,xmm1
  410e33:	jbe    410e43 <__swc_fn_fc36583a_000149_6203dca2+0x3c3>
  410e35:	vmovsd xmm1,xmm1,xmm0
  410e39:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x27df]        # 413620 <__swc_rdata_base_fc36583a+0x510>
  410e41:	jmp    410e47 <__swc_fn_fc36583a_000149_6203dca2+0x3c7>
  410e43:	vmovsd xmm1,xmm1,xmm0
  410e47:	xor    r8d,r8d
  410e4a:	vcomisd xmm1,xmm15
  410e4f:	jb     410e70 <__swc_fn_fc36583a_000149_6203dca2+0x3f0>
  410e51:	cs nop WORD PTR [rax+rax*1+0x0]
  410e5b:	nop    DWORD PTR [rax+rax*1+0x0]
  410e60:	vdivsd xmm1,xmm1,xmm15
  410e65:	add    r8,0x1
  410e69:	vcomisd xmm1,xmm15
  410e6e:	jae    410e60 <__swc_fn_fc36583a_000149_6203dca2+0x3e0>
  410e70:	mov    r9,rcx
  410e73:	vxorpd xmm2,xmm2,xmm2
  410e77:	vcomisd xmm2,xmm0
  410e7b:	jbe    410e84 <__swc_fn_fc36583a_000149_6203dca2+0x404>
  410e7d:	mov    BYTE PTR [rcx],0x2d
  410e80:	lea    r9,[rcx+0x1]
  410e84:	vcvttsd2si rdx,xmm1
  410e89:	mov    r10b,dl
  410e8c:	add    r10b,0x30
  410e90:	mov    BYTE PTR [r9],r10b
  410e93:	vxorpd xmm0,xmm0,xmm0
  410e97:	movzx  edx,dl
  410e9a:	vcvtsi2sd xmm0,xmm0,rdx
  410e9f:	vsubsd xmm0,xmm1,xmm0
  410ea3:	vmulsd xmm1,xmm0,xmm15
  410ea8:	mov    BYTE PTR [r9+0x1],0x2e
  410ead:	vcvttsd2si rdx,xmm1
  410eb2:	mov    r10b,dl
  410eb5:	add    r10b,0x30
  410eb9:	mov    BYTE PTR [r9+0x2],r10b
  410ebd:	vxorpd xmm0,xmm0,xmm0
  410ec1:	movzx  edx,dl
  410ec4:	vcvtsi2sd xmm0,xmm0,rdx
  410ec9:	vsubsd xmm0,xmm1,xmm0
  410ecd:	vmulsd xmm1,xmm0,xmm15
  410ed2:	vcvttsd2si rdx,xmm1
  410ed7:	mov    r10b,dl
  410eda:	add    r10b,0x30
  410ede:	mov    BYTE PTR [r9+0x3],r10b
  410ee2:	vxorpd xmm0,xmm0,xmm0
  410ee6:	movzx  edx,dl
  410ee9:	vcvtsi2sd xmm0,xmm0,rdx
  410eee:	vsubsd xmm0,xmm1,xmm0
  410ef2:	vmulsd xmm1,xmm0,xmm15
  410ef7:	vcvttsd2si rdx,xmm1
  410efc:	mov    r10b,dl
  410eff:	add    r10b,0x30
  410f03:	mov    BYTE PTR [r9+0x4],r10b
  410f07:	vxorpd xmm0,xmm0,xmm0
  410f0b:	movzx  edx,dl
  410f0e:	vcvtsi2sd xmm0,xmm0,rdx
  410f13:	vsubsd xmm0,xmm1,xmm0
  410f17:	vmulsd xmm1,xmm0,xmm15
  410f1c:	vcvttsd2si rdx,xmm1
  410f21:	mov    r10b,dl
  410f24:	add    r10b,0x30
  410f28:	mov    BYTE PTR [r9+0x5],r10b
  410f2c:	vxorpd xmm0,xmm0,xmm0
  410f30:	movzx  edx,dl
  410f33:	vcvtsi2sd xmm0,xmm0,rdx
  410f38:	vsubsd xmm0,xmm1,xmm0
  410f3c:	vmulsd xmm1,xmm0,xmm15
  410f41:	vcvttsd2si rdx,xmm1
  410f46:	mov    r10b,dl
  410f49:	add    r10b,0x30
  410f4d:	mov    BYTE PTR [r9+0x6],r10b
  410f51:	vxorpd xmm0,xmm0,xmm0
  410f55:	movzx  edx,dl
  410f58:	vcvtsi2sd xmm0,xmm0,rdx
  410f5d:	vsubsd xmm0,xmm1,xmm0
  410f61:	vmulsd xmm1,xmm0,xmm15
  410f66:	vcvttsd2si rdx,xmm1
  410f6b:	mov    r10b,dl
  410f6e:	add    r10b,0x30
  410f72:	mov    BYTE PTR [r9+0x7],r10b
  410f76:	vxorpd xmm0,xmm0,xmm0
  410f7a:	movzx  edx,dl
  410f7d:	vcvtsi2sd xmm0,xmm0,rdx
  410f82:	vsubsd xmm0,xmm1,xmm0
  410f86:	vmulsd xmm1,xmm0,xmm15
  410f8b:	vcvttsd2si rdx,xmm1
  410f90:	mov    r10b,dl
  410f93:	add    r10b,0x30
  410f97:	mov    BYTE PTR [r9+0x8],r10b
  410f9b:	vxorpd xmm0,xmm0,xmm0
  410f9f:	movzx  edx,dl
  410fa2:	vcvtsi2sd xmm0,xmm0,rdx
  410fa7:	vsubsd xmm0,xmm1,xmm0
  410fab:	vmulsd xmm1,xmm0,xmm15
  410fb0:	vcvttsd2si rdx,xmm1
  410fb5:	mov    r10b,dl
  410fb8:	add    r10b,0x30
  410fbc:	mov    BYTE PTR [r9+0x9],r10b
  410fc0:	vxorpd xmm0,xmm0,xmm0
  410fc4:	movzx  edx,dl
  410fc7:	vcvtsi2sd xmm0,xmm0,rdx
  410fcc:	vsubsd xmm0,xmm1,xmm0
  410fd0:	vmulsd xmm1,xmm0,xmm15
  410fd5:	vcvttsd2si rdx,xmm1
  410fda:	mov    r10b,dl
  410fdd:	add    r10b,0x30
  410fe1:	mov    BYTE PTR [r9+0xa],r10b
  410fe5:	vxorpd xmm0,xmm0,xmm0
  410fe9:	movzx  edx,dl
  410fec:	vcvtsi2sd xmm0,xmm0,rdx
  410ff1:	vsubsd xmm0,xmm1,xmm0
  410ff5:	vmulsd xmm1,xmm0,xmm15
  410ffa:	vcvttsd2si rdx,xmm1
  410fff:	mov    r10b,dl
  411002:	add    r10b,0x30
  411006:	mov    BYTE PTR [r9+0xb],r10b
  41100a:	lea    r10,[r9+0x4]
  41100e:	vxorpd xmm0,xmm0,xmm0
  411012:	movzx  edx,dl
  411015:	vcvtsi2sd xmm0,xmm0,rdx
  41101a:	vsubsd xmm0,xmm1,xmm0
  41101e:	vmulsd xmm1,xmm0,xmm15
  411023:	vcvttsd2si rdx,xmm1
  411028:	mov    r11b,dl
  41102b:	add    r11b,0x30
  41102f:	mov    BYTE PTR [r9+0xc],r11b
  411033:	vxorpd xmm0,xmm0,xmm0
  411037:	movzx  edx,dl
  41103a:	vcvtsi2sd xmm0,xmm0,rdx
  41103f:	vsubsd xmm0,xmm1,xmm0
  411043:	vmulsd xmm1,xmm0,xmm15
  411048:	vcvttsd2si rdx,xmm1
  41104d:	mov    r11b,dl
  411050:	add    r11b,0x30
  411054:	mov    BYTE PTR [r9+0xd],r11b
  411058:	lea    r10,[r10+0x2]
  41105c:	vxorpd xmm0,xmm0,xmm0
  411060:	movzx  edx,dl
  411063:	vcvtsi2sd xmm0,xmm0,rdx
  411068:	vsubsd xmm0,xmm1,xmm0
  41106c:	vmulsd xmm1,xmm0,xmm15
  411071:	vcvttsd2si rdx,xmm1
  411076:	mov    r11b,dl
  411079:	add    r11b,0x30
  41107d:	mov    BYTE PTR [r9+0xe],r11b
  411081:	vxorpd xmm0,xmm0,xmm0
  411085:	movzx  edx,dl
  411088:	vcvtsi2sd xmm0,xmm0,rdx
  41108d:	vsubsd xmm0,xmm1,xmm0
  411091:	vmulsd xmm1,xmm0,xmm15
  411096:	vcvttsd2si rdx,xmm1
  41109b:	mov    r11b,dl
  41109e:	add    r11b,0x30
  4110a2:	mov    BYTE PTR [r9+0xf],r11b
  4110a6:	lea    r10,[r10+0x2]
  4110aa:	lea    r10,[r10+0x2]
  4110ae:	lea    r10,[r10+0x2]
  4110b2:	lea    r10,[r10+0x2]
  4110b6:	lea    r10,[r10+0x2]
  4110ba:	vxorpd xmm0,xmm0,xmm0
  4110be:	movzx  edx,dl
  4110c1:	vcvtsi2sd xmm0,xmm0,rdx
  4110c6:	vsubsd xmm0,xmm1,xmm0
  4110ca:	vmulsd xmm1,xmm0,xmm15
  4110cf:	vcvttsd2si rdx,xmm1
  4110d4:	mov    r11b,dl
  4110d7:	add    r11b,0x30
  4110db:	mov    BYTE PTR [r9+0x10],r11b
  4110df:	vxorpd xmm0,xmm0,xmm0
  4110e3:	movzx  edx,dl
  4110e6:	vcvtsi2sd xmm0,xmm0,rdx
  4110eb:	vsubsd xmm0,xmm1,xmm0
  4110ef:	vmulsd xmm1,xmm0,xmm15
  4110f4:	vcvttsd2si rdx,xmm1
  4110f9:	add    dl,0x30
  4110fc:	mov    BYTE PTR [r9+0x11],dl
  411100:	mov    BYTE PTR [r10+0x2],0x65
  411105:	lea    r9,[r10+0x3]
  411109:	test   r8,r8
  41110c:	jl     411115 <__swc_fn_fc36583a_000149_6203dca2+0x695>
  41110e:	mov    BYTE PTR [r9],0x2b
  411112:	inc    r9
  411115:	mov    r10,r9
  411118:	mov    rdx,r8
  41111b:	nop    DWORD PTR [rax+rax*1+0x0]
  411120:	mov    r11,rdx
  411123:	movabs rdx,0x6666666666666667
  41112d:	mov    rax,r11
  411130:	imul   rdx
  411133:	sar    rdx,0x2
  411137:	mov    r12,rdx
  41113a:	shr    rdx,0x3f
  41113e:	add    r12,rdx
  411141:	mov    rdx,r12
  411144:	imul   r13,r12,0xa
  411148:	sub    r11,r13
  41114b:	mov    r13,QWORD PTR [rip+0x24be]        # 413610 <__swc_rdata_base_fc36583a+0x500>
  411152:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411157:	mov    BYTE PTR [r10],r11b
  41115a:	lea    r11,[r10+0x1]
  41115e:	mov    r10,r11
  411161:	test   r12,r12
  411164:	jne    411120 <__swc_fn_fc36583a_000149_6203dca2+0x6a0>
  411166:	test   r8,r8
  411169:	jge    411173 <__swc_fn_fc36583a_000149_6203dca2+0x6f3>
  41116b:	mov    BYTE PTR [r11],0x2d
  41116f:	lea    r10,[r11+0x1]
  411173:	mov    BYTE PTR [r10],0x0
  411177:	sub    r10,0x1
  41117b:	nop    DWORD PTR [rax+rax*1+0x0]
  411180:	cmp    r9,r10
  411183:	jae    4113d8 <__swc_fn_fc36583a_000149_6203dca2+0x958>
  411189:	mov    al,BYTE PTR [r10]
  41118c:	mov    dl,BYTE PTR [r9]
  41118f:	mov    BYTE PTR [r10],dl
  411192:	sub    r10,0x1
  411196:	mov    BYTE PTR [r9],al
  411199:	inc    r9
  41119c:	jmp    411180 <__swc_fn_fc36583a_000149_6203dca2+0x700>
  41119e:	vcvttsd2si rdx,xmm1
  4111a3:	mov    r8,rdx
  4111a6:	vxorpd xmm0,xmm0,xmm0
  4111aa:	vcvtsi2sd xmm0,xmm0,rdx
  4111af:	vsubsd xmm0,xmm1,xmm0
  4111b3:	mov    r9d,0x8
  4111b9:	vxorpd xmm2,xmm2,xmm2
  4111bd:	vcomisd xmm2,xmm0
  4111c1:	jbe    4111cb <__swc_fn_fc36583a_000149_6203dca2+0x74b>
  4111c3:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x2455]        # 413620 <__swc_rdata_base_fc36583a+0x510>
  4111cb:	test   r9d,r9d
  4111ce:	je     4111da <__swc_fn_fc36583a_000149_6203dca2+0x75a>
  4111d0:	vmulsd xmm0,xmm0,xmm14
  4111d5:	dec    r9d
  4111d8:	jne    4111d0 <__swc_fn_fc36583a_000149_6203dca2+0x750>
  4111da:	vcvttsd2si r9,xmm0
  4111df:	mov    r10,r9
  4111e2:	vxorpd xmm2,xmm2,xmm2
  4111e6:	vcvtsi2sd xmm2,xmm2,r9
  4111eb:	vsubsd xmm0,xmm0,xmm2
  4111ef:	vcomisd xmm0,xmm10
  4111f4:	lea    r9,[r9+0x1]
  4111f8:	cmova  r10,r9
  4111fc:	cmp    r10,0x5f5e100
  411203:	jne    41121c <__swc_fn_fc36583a_000149_6203dca2+0x79c>
  411205:	lea    r8,[rdx-0x1]
  411209:	vxorpd xmm0,xmm0,xmm0
  41120d:	vcomisd xmm0,xmm1
  411211:	lea    rdx,[rdx+0x1]
  411215:	cmovbe r8,rdx
  411219:	xor    r10d,r10d
  41121c:	mov    r9,rcx
  41121f:	test   r8,r8
  411222:	jne    411242 <__swc_fn_fc36583a_000149_6203dca2+0x7c2>
  411224:	vxorpd xmm0,xmm0,xmm0
  411228:	vcomisd xmm0,xmm1
  41122c:	jbe    411235 <__swc_fn_fc36583a_000149_6203dca2+0x7b5>
  41122e:	mov    BYTE PTR [rcx],0x2d
  411231:	lea    r9,[rcx+0x1]
  411235:	mov    BYTE PTR [r9],0x30
  411239:	add    r9,0x1
  41123d:	jmp    4112db <__swc_fn_fc36583a_000149_6203dca2+0x85b>
  411242:	mov    r9,rcx
  411245:	mov    rdx,r8
  411248:	nop    DWORD PTR [rax+rax*1+0x0]
  411250:	mov    r11,rdx
  411253:	movabs rdx,0x6666666666666667
  41125d:	mov    r15,rax
  411260:	mov    rax,r11
  411263:	imul   rdx
  411266:	mov    r12,rdx
  411269:	mov    rax,r15
  41126c:	sar    r12,0x2
  411270:	mov    rdx,r12
  411273:	shr    rdx,0x3f
  411277:	add    r12,rdx
  41127a:	mov    rdx,r12
  41127d:	imul   r13,r12,0xa
  411281:	sub    r11,r13
  411284:	mov    r13,QWORD PTR [rip+0x2385]        # 413610 <__swc_rdata_base_fc36583a+0x500>
  41128b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411290:	mov    BYTE PTR [r9],r11b
  411293:	lea    r11,[r9+0x1]
  411297:	mov    r9,r11
  41129a:	test   r12,r12
  41129d:	jne    411250 <__swc_fn_fc36583a_000149_6203dca2+0x7d0>
  41129f:	test   r8,r8
  4112a2:	jge    4112ac <__swc_fn_fc36583a_000149_6203dca2+0x82c>
  4112a4:	mov    BYTE PTR [r11],0x2d
  4112a8:	lea    r9,[r11+0x1]
  4112ac:	mov    rdx,r9
  4112af:	mov    BYTE PTR [r9],0x0
  4112b3:	sub    r9,0x1
  4112b7:	mov    r8,rcx
  4112ba:	cmp    r8,r9
  4112bd:	jae    4112d8 <__swc_fn_fc36583a_000149_6203dca2+0x858>
  4112bf:	nop
  4112c0:	mov    r11b,BYTE PTR [r9]
  4112c3:	mov    r12b,BYTE PTR [r8]
  4112c6:	mov    BYTE PTR [r9],r12b
  4112c9:	sub    r9,0x1
  4112cd:	mov    BYTE PTR [r8],r11b
  4112d0:	inc    r8
  4112d3:	cmp    r8,r9
  4112d6:	jb     4112c0 <__swc_fn_fc36583a_000149_6203dca2+0x840>
  4112d8:	mov    r9,rdx
  4112db:	mov    BYTE PTR [r9],0x2e
  4112df:	add    r9,0x1
  4112e3:	xor    r8d,r8d
  4112e6:	test   r10,r10
  4112e9:	je     41132f <__swc_fn_fc36583a_000149_6203dca2+0x8af>
  4112eb:	mov    r11d,0x989680
  4112f1:	cmp    r10,r11
  4112f4:	jge    41132f <__swc_fn_fc36583a_000149_6203dca2+0x8af>
  4112f6:	cs nop WORD PTR [rax+rax*1+0x0]
  411300:	inc    r8d
  411303:	movabs rdx,0x6666666666666667
  41130d:	mov    r15,rax
  411310:	mov    rax,r11
  411313:	imul   rdx
  411316:	mov    r11,rdx
  411319:	mov    rax,r15
  41131c:	sar    r11,0x2
  411320:	mov    rdx,r11
  411323:	shr    rdx,0x3f
  411327:	add    r11,rdx
  41132a:	cmp    r10,r11
  41132d:	jl     411300 <__swc_fn_fc36583a_000149_6203dca2+0x880>
  41132f:	test   r8d,r8d
  411332:	je     41134d <__swc_fn_fc36583a_000149_6203dca2+0x8cd>
  411334:	cs nop WORD PTR [rax+rax*1+0x0]
  41133e:	xchg   ax,ax
  411340:	mov    BYTE PTR [r9],0x30
  411344:	add    r9,0x1
  411348:	dec    r8d
  41134b:	jne    411340 <__swc_fn_fc36583a_000149_6203dca2+0x8c0>
  41134d:	mov    r8,r9
  411350:	mov    rdx,r10
  411353:	cs nop WORD PTR [rax+rax*1+0x0]
  41135d:	nop    DWORD PTR [rax]
  411360:	mov    r11,rdx
  411363:	movabs rdx,0x6666666666666667
  41136d:	mov    rax,r11
  411370:	imul   rdx
  411373:	sar    rdx,0x2
  411377:	mov    r12,rdx
  41137a:	shr    rdx,0x3f
  41137e:	add    r12,rdx
  411381:	mov    rdx,r12
  411384:	imul   r13,r12,0xa
  411388:	sub    r11,r13
  41138b:	mov    r13,QWORD PTR [rip+0x227e]        # 413610 <__swc_rdata_base_fc36583a+0x500>
  411392:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411397:	mov    BYTE PTR [r8],r11b
  41139a:	lea    r11,[r8+0x1]
  41139e:	mov    r8,r11
  4113a1:	test   r12,r12
  4113a4:	jne    411360 <__swc_fn_fc36583a_000149_6203dca2+0x8e0>
  4113a6:	test   r10,r10
  4113a9:	jge    4113b3 <__swc_fn_fc36583a_000149_6203dca2+0x933>
  4113ab:	mov    BYTE PTR [r11],0x2d
  4113af:	lea    r8,[r11+0x1]
  4113b3:	mov    BYTE PTR [r8],0x0
  4113b7:	sub    r8,0x1
  4113bb:	cmp    r9,r8
  4113be:	jae    4113d8 <__swc_fn_fc36583a_000149_6203dca2+0x958>
  4113c0:	mov    al,BYTE PTR [r8]
  4113c3:	mov    dl,BYTE PTR [r9]
  4113c6:	mov    BYTE PTR [r8],dl
  4113c9:	sub    r8,0x1
  4113cd:	mov    BYTE PTR [r9],al
  4113d0:	inc    r9
  4113d3:	cmp    r9,r8
  4113d6:	jb     4113c0 <__swc_fn_fc36583a_000149_6203dca2+0x940>
  4113d8:	xor    eax,eax
  4113da:	test   rcx,rcx
  4113dd:	je     411410 <__swc_fn_fc36583a_000149_6203dca2+0x990>
  4113df:	mov    rdx,rcx
  4113e2:	mov    r8b,BYTE PTR [rdx]
  4113e5:	test   r8b,r8b
  4113e8:	je     411410 <__swc_fn_fc36583a_000149_6203dca2+0x990>
  4113ea:	cs nop WORD PTR [rax+rax*1+0x0]
  4113f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4113fe:	xchg   ax,ax
  411400:	add    rdx,0x1
  411404:	add    rax,0x1
  411408:	mov    r8b,BYTE PTR [rdx]
  41140b:	test   r8b,r8b
  41140e:	jne    411400 <__swc_fn_fc36583a_000149_6203dca2+0x980>
  411410:	mov    QWORD PTR [rsp+0x240],rcx
  411418:	mov    QWORD PTR [rsp+0x248],rax
  411420:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  411429:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  411432:	lea    rcx,[rsp+0x250]
  41143a:	call   410210 <__swc_fn_fc36583a_000119_2648f149>
  41143f:	jmp    411b45 <__swc_fn_fc36583a_000149_6203dca2+0x10c5>
  411444:	lea    rcx,[rsp+0x260]
  41144c:	vxorps xmm0,xmm0,xmm0
  411450:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  411459:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  411462:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  41146b:	vzeroupper
  41146e:	mov    DWORD PTR [rsp+0x2c0],0x0
  411479:	vmovsd xmm0,QWORD PTR [rdx]
  41147d:	vcomisd xmm0,xmm0
  411481:	setne  dl
  411484:	movzx  edx,dl
  411487:	setp   r8b
  41148b:	movzx  r8d,r8b
  41148f:	or     edx,r8d
  411492:	test   dl,dl
  411494:	je     4114a1 <__swc_fn_fc36583a_000149_6203dca2+0xa21>
  411496:	mov    DWORD PTR [rcx],0x6e616e
  41149c:	jmp    411aa8 <__swc_fn_fc36583a_000149_6203dca2+0x1028>
  4114a1:	vcomisd xmm0,xmm11
  4114a6:	ja     4114b7 <__swc_fn_fc36583a_000149_6203dca2+0xa37>
  4114a8:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  4114b1:	vcomisd xmm6,xmm0
  4114b5:	jbe    4114db <__swc_fn_fc36583a_000149_6203dca2+0xa5b>
  4114b7:	vxorpd xmm1,xmm1,xmm1
  4114bb:	vcomisd xmm1,xmm0
  4114bf:	jbe    4114d0 <__swc_fn_fc36583a_000149_6203dca2+0xa50>
  4114c1:	mov    DWORD PTR [rcx],0x666e692d
  4114c7:	mov    BYTE PTR [rcx+0x4],0x0
  4114cb:	jmp    411aa8 <__swc_fn_fc36583a_000149_6203dca2+0x1028>
  4114d0:	mov    DWORD PTR [rcx],0x666e69
  4114d6:	jmp    411aa8 <__swc_fn_fc36583a_000149_6203dca2+0x1028>
  4114db:	vcomisd xmm0,xmm13
  4114e0:	jae    4114ec <__swc_fn_fc36583a_000149_6203dca2+0xa6c>
  4114e2:	vcomisd xmm12,xmm0
  4114e6:	jbe    41184e <__swc_fn_fc36583a_000149_6203dca2+0xdce>
  4114ec:	vmovups xmm1,xmm0
  4114f0:	vxorpd xmm2,xmm2,xmm2
  4114f4:	vcomisd xmm2,xmm0
  4114f8:	jbe    411508 <__swc_fn_fc36583a_000149_6203dca2+0xa88>
  4114fa:	vmovsd xmm0,xmm0,xmm1
  4114fe:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x211a]        # 413620 <__swc_rdata_base_fc36583a+0x510>
  411506:	jmp    41150c <__swc_fn_fc36583a_000149_6203dca2+0xa8c>
  411508:	vmovsd xmm0,xmm0,xmm1
  41150c:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  411515:	xor    r8d,r8d
  411518:	vcomisd xmm0,xmm6
  41151c:	jb     41152e <__swc_fn_fc36583a_000149_6203dca2+0xaae>
  41151e:	xchg   ax,ax
  411520:	vdivsd xmm0,xmm0,xmm6
  411524:	add    r8,0x1
  411528:	vcomisd xmm0,xmm6
  41152c:	jae    411520 <__swc_fn_fc36583a_000149_6203dca2+0xaa0>
  41152e:	mov    r9,rcx
  411531:	vxorpd xmm2,xmm2,xmm2
  411535:	vcomisd xmm2,xmm1
  411539:	jbe    411542 <__swc_fn_fc36583a_000149_6203dca2+0xac2>
  41153b:	mov    BYTE PTR [rcx],0x2d
  41153e:	lea    r9,[rcx+0x1]
  411542:	vcvttsd2si rdx,xmm0
  411547:	mov    r10b,dl
  41154a:	add    r10b,0x30
  41154e:	mov    BYTE PTR [r9],r10b
  411551:	vxorpd xmm1,xmm1,xmm1
  411555:	movzx  edx,dl
  411558:	vcvtsi2sd xmm1,xmm1,rdx
  41155d:	vsubsd xmm0,xmm0,xmm1
  411561:	vmulsd xmm0,xmm0,xmm6
  411565:	mov    BYTE PTR [r9+0x1],0x2e
  41156a:	vcvttsd2si rdx,xmm0
  41156f:	mov    r10b,dl
  411572:	add    r10b,0x30
  411576:	mov    BYTE PTR [r9+0x2],r10b
  41157a:	vxorpd xmm1,xmm1,xmm1
  41157e:	movzx  edx,dl
  411581:	vcvtsi2sd xmm1,xmm1,rdx
  411586:	vsubsd xmm0,xmm0,xmm1
  41158a:	vmulsd xmm0,xmm0,xmm6
  41158e:	vcvttsd2si rdx,xmm0
  411593:	mov    r10b,dl
  411596:	add    r10b,0x30
  41159a:	mov    BYTE PTR [r9+0x3],r10b
  41159e:	vxorpd xmm1,xmm1,xmm1
  4115a2:	movzx  edx,dl
  4115a5:	vcvtsi2sd xmm1,xmm1,rdx
  4115aa:	vsubsd xmm0,xmm0,xmm1
  4115ae:	vmulsd xmm0,xmm0,xmm6
  4115b2:	vcvttsd2si rdx,xmm0
  4115b7:	mov    r10b,dl
  4115ba:	add    r10b,0x30
  4115be:	mov    BYTE PTR [r9+0x4],r10b
  4115c2:	vxorpd xmm1,xmm1,xmm1
  4115c6:	movzx  edx,dl
  4115c9:	vcvtsi2sd xmm1,xmm1,rdx
  4115ce:	vsubsd xmm0,xmm0,xmm1
  4115d2:	vmulsd xmm0,xmm0,xmm6
  4115d6:	vcvttsd2si rdx,xmm0
  4115db:	mov    r10b,dl
  4115de:	add    r10b,0x30
  4115e2:	mov    BYTE PTR [r9+0x5],r10b
  4115e6:	vxorpd xmm1,xmm1,xmm1
  4115ea:	movzx  edx,dl
  4115ed:	vcvtsi2sd xmm1,xmm1,rdx
  4115f2:	vsubsd xmm0,xmm0,xmm1
  4115f6:	vmulsd xmm0,xmm0,xmm6
  4115fa:	vcvttsd2si rdx,xmm0
  4115ff:	mov    r10b,dl
  411602:	add    r10b,0x30
  411606:	mov    BYTE PTR [r9+0x6],r10b
  41160a:	vxorpd xmm1,xmm1,xmm1
  41160e:	movzx  edx,dl
  411611:	vcvtsi2sd xmm1,xmm1,rdx
  411616:	vsubsd xmm0,xmm0,xmm1
  41161a:	vmulsd xmm0,xmm0,xmm6
  41161e:	vcvttsd2si rdx,xmm0
  411623:	mov    r10b,dl
  411626:	add    r10b,0x30
  41162a:	mov    BYTE PTR [r9+0x7],r10b
  41162e:	vxorpd xmm1,xmm1,xmm1
  411632:	movzx  edx,dl
  411635:	vcvtsi2sd xmm1,xmm1,rdx
  41163a:	vsubsd xmm0,xmm0,xmm1
  41163e:	vmulsd xmm0,xmm0,xmm6
  411642:	vcvttsd2si rdx,xmm0
  411647:	mov    r10b,dl
  41164a:	add    r10b,0x30
  41164e:	mov    BYTE PTR [r9+0x8],r10b
  411652:	vxorpd xmm1,xmm1,xmm1
  411656:	movzx  edx,dl
  411659:	vcvtsi2sd xmm1,xmm1,rdx
  41165e:	vsubsd xmm0,xmm0,xmm1
  411662:	vmulsd xmm0,xmm0,xmm6
  411666:	vcvttsd2si rdx,xmm0
  41166b:	mov    r10b,dl
  41166e:	add    r10b,0x30
  411672:	mov    BYTE PTR [r9+0x9],r10b
  411676:	vxorpd xmm1,xmm1,xmm1
  41167a:	movzx  edx,dl
  41167d:	vcvtsi2sd xmm1,xmm1,rdx
  411682:	vsubsd xmm0,xmm0,xmm1
  411686:	vmulsd xmm0,xmm0,xmm6
  41168a:	vcvttsd2si rdx,xmm0
  41168f:	mov    r10b,dl
  411692:	add    r10b,0x30
  411696:	mov    BYTE PTR [r9+0xa],r10b
  41169a:	vxorpd xmm1,xmm1,xmm1
  41169e:	movzx  edx,dl
  4116a1:	vcvtsi2sd xmm1,xmm1,rdx
  4116a6:	vsubsd xmm0,xmm0,xmm1
  4116aa:	vmulsd xmm0,xmm0,xmm6
  4116ae:	vcvttsd2si rdx,xmm0
  4116b3:	mov    r10b,dl
  4116b6:	add    r10b,0x30
  4116ba:	mov    BYTE PTR [r9+0xb],r10b
  4116be:	lea    r10,[r9+0x4]
  4116c2:	vxorpd xmm1,xmm1,xmm1
  4116c6:	movzx  edx,dl
  4116c9:	vcvtsi2sd xmm1,xmm1,rdx
  4116ce:	vsubsd xmm0,xmm0,xmm1
  4116d2:	vmulsd xmm0,xmm0,xmm6
  4116d6:	vcvttsd2si rdx,xmm0
  4116db:	mov    r11b,dl
  4116de:	add    r11b,0x30
  4116e2:	mov    BYTE PTR [r9+0xc],r11b
  4116e6:	vxorpd xmm1,xmm1,xmm1
  4116ea:	movzx  edx,dl
  4116ed:	vcvtsi2sd xmm1,xmm1,rdx
  4116f2:	vsubsd xmm0,xmm0,xmm1
  4116f6:	vmulsd xmm0,xmm0,xmm6
  4116fa:	vcvttsd2si rdx,xmm0
  4116ff:	mov    r11b,dl
  411702:	add    r11b,0x30
  411706:	mov    BYTE PTR [r9+0xd],r11b
  41170a:	lea    r10,[r10+0x2]
  41170e:	vxorpd xmm1,xmm1,xmm1
  411712:	movzx  edx,dl
  411715:	vcvtsi2sd xmm1,xmm1,rdx
  41171a:	vsubsd xmm0,xmm0,xmm1
  41171e:	vmulsd xmm0,xmm0,xmm6
  411722:	vcvttsd2si rdx,xmm0
  411727:	mov    r11b,dl
  41172a:	add    r11b,0x30
  41172e:	mov    BYTE PTR [r9+0xe],r11b
  411732:	vxorpd xmm1,xmm1,xmm1
  411736:	movzx  edx,dl
  411739:	vcvtsi2sd xmm1,xmm1,rdx
  41173e:	vsubsd xmm0,xmm0,xmm1
  411742:	vmulsd xmm0,xmm0,xmm6
  411746:	vcvttsd2si rdx,xmm0
  41174b:	mov    r11b,dl
  41174e:	add    r11b,0x30
  411752:	mov    BYTE PTR [r9+0xf],r11b
  411756:	lea    r10,[r10+0x2]
  41175a:	lea    r10,[r10+0x2]
  41175e:	lea    r10,[r10+0x2]
  411762:	lea    r10,[r10+0x2]
  411766:	lea    r10,[r10+0x2]
  41176a:	vxorpd xmm1,xmm1,xmm1
  41176e:	movzx  edx,dl
  411771:	vcvtsi2sd xmm1,xmm1,rdx
  411776:	vsubsd xmm0,xmm0,xmm1
  41177a:	vmulsd xmm0,xmm0,xmm6
  41177e:	vcvttsd2si rdx,xmm0
  411783:	mov    r11b,dl
  411786:	add    r11b,0x30
  41178a:	mov    BYTE PTR [r9+0x10],r11b
  41178e:	vxorpd xmm1,xmm1,xmm1
  411792:	movzx  edx,dl
  411795:	vcvtsi2sd xmm1,xmm1,rdx
  41179a:	vsubsd xmm0,xmm0,xmm1
  41179e:	vmulsd xmm0,xmm0,xmm6
  4117a2:	vcvttsd2si rdx,xmm0
  4117a7:	add    dl,0x30
  4117aa:	mov    BYTE PTR [r9+0x11],dl
  4117ae:	mov    BYTE PTR [r10+0x2],0x65
  4117b3:	lea    r9,[r10+0x3]
  4117b7:	test   r8,r8
  4117ba:	jl     4117c3 <__swc_fn_fc36583a_000149_6203dca2+0xd43>
  4117bc:	mov    BYTE PTR [r9],0x2b
  4117c0:	inc    r9
  4117c3:	mov    r10,r9
  4117c6:	mov    rdx,r8
  4117c9:	nop    DWORD PTR [rax+0x0]
  4117d0:	mov    r11,rdx
  4117d3:	movabs rdx,0x6666666666666667
  4117dd:	mov    rax,r11
  4117e0:	imul   rdx
  4117e3:	sar    rdx,0x2
  4117e7:	mov    r12,rdx
  4117ea:	shr    rdx,0x3f
  4117ee:	add    r12,rdx
  4117f1:	mov    rdx,r12
  4117f4:	imul   r13,r12,0xa
  4117f8:	sub    r11,r13
  4117fb:	mov    r13,QWORD PTR [rip+0x1e0e]        # 413610 <__swc_rdata_base_fc36583a+0x500>
  411802:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411807:	mov    BYTE PTR [r10],r11b
  41180a:	lea    r11,[r10+0x1]
  41180e:	mov    r10,r11
  411811:	test   r12,r12
  411814:	jne    4117d0 <__swc_fn_fc36583a_000149_6203dca2+0xd50>
  411816:	test   r8,r8
  411819:	jge    411823 <__swc_fn_fc36583a_000149_6203dca2+0xda3>
  41181b:	mov    BYTE PTR [r11],0x2d
  41181f:	lea    r10,[r11+0x1]
  411823:	mov    BYTE PTR [r10],0x0
  411827:	sub    r10,0x1
  41182b:	nop    DWORD PTR [rax+rax*1+0x0]
  411830:	cmp    r9,r10
  411833:	jae    411aa8 <__swc_fn_fc36583a_000149_6203dca2+0x1028>
  411839:	mov    al,BYTE PTR [r10]
  41183c:	mov    dl,BYTE PTR [r9]
  41183f:	mov    BYTE PTR [r10],dl
  411842:	sub    r10,0x1
  411846:	mov    BYTE PTR [r9],al
  411849:	inc    r9
  41184c:	jmp    411830 <__swc_fn_fc36583a_000149_6203dca2+0xdb0>
  41184e:	vcvttsd2si rdx,xmm0
  411853:	mov    r8,rdx
  411856:	vxorpd xmm1,xmm1,xmm1
  41185a:	vcvtsi2sd xmm1,xmm1,rdx
  41185f:	vsubsd xmm1,xmm0,xmm1
  411863:	mov    r9d,0x8
  411869:	vxorpd xmm2,xmm2,xmm2
  41186d:	vcomisd xmm2,xmm1
  411871:	ja     41187e <__swc_fn_fc36583a_000149_6203dca2+0xdfe>
  411873:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41187c:	jmp    41188f <__swc_fn_fc36583a_000149_6203dca2+0xe0f>
  41187e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1d9a]        # 413620 <__swc_rdata_base_fc36583a+0x510>
  411886:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41188f:	test   r9d,r9d
  411892:	je     4118a9 <__swc_fn_fc36583a_000149_6203dca2+0xe29>
  411894:	cs nop WORD PTR [rax+rax*1+0x0]
  41189e:	xchg   ax,ax
  4118a0:	vmulsd xmm1,xmm1,xmm6
  4118a4:	dec    r9d
  4118a7:	jne    4118a0 <__swc_fn_fc36583a_000149_6203dca2+0xe20>
  4118a9:	vcvttsd2si r9,xmm1
  4118ae:	mov    r10,r9
  4118b1:	vxorpd xmm2,xmm2,xmm2
  4118b5:	vcvtsi2sd xmm2,xmm2,r9
  4118ba:	vsubsd xmm1,xmm1,xmm2
  4118be:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  4118c7:	vcomisd xmm1,xmm6
  4118cb:	lea    r9,[r9+0x1]
  4118cf:	cmova  r10,r9
  4118d3:	cmp    r10,0x5f5e100
  4118da:	jne    4118f3 <__swc_fn_fc36583a_000149_6203dca2+0xe73>
  4118dc:	lea    r8,[rdx-0x1]
  4118e0:	vxorpd xmm1,xmm1,xmm1
  4118e4:	vcomisd xmm1,xmm0
  4118e8:	lea    rdx,[rdx+0x1]
  4118ec:	cmovbe r8,rdx
  4118f0:	xor    r10d,r10d
  4118f3:	mov    r9,rcx
  4118f6:	test   r8,r8
  4118f9:	jne    411919 <__swc_fn_fc36583a_000149_6203dca2+0xe99>
  4118fb:	vxorpd xmm1,xmm1,xmm1
  4118ff:	vcomisd xmm1,xmm0
  411903:	jbe    41190c <__swc_fn_fc36583a_000149_6203dca2+0xe8c>
  411905:	mov    BYTE PTR [rcx],0x2d
  411908:	lea    r9,[rcx+0x1]
  41190c:	mov    BYTE PTR [r9],0x30
  411910:	add    r9,0x1
  411914:	jmp    4119ab <__swc_fn_fc36583a_000149_6203dca2+0xf2b>
  411919:	mov    r9,rcx
  41191c:	mov    rdx,r8
  41191f:	nop
  411920:	mov    r11,rdx
  411923:	movabs rdx,0x6666666666666667
  41192d:	mov    r15,rax
  411930:	mov    rax,r11
  411933:	imul   rdx
  411936:	mov    r12,rdx
  411939:	mov    rax,r15
  41193c:	sar    r12,0x2
  411940:	mov    rdx,r12
  411943:	shr    rdx,0x3f
  411947:	add    r12,rdx
  41194a:	mov    rdx,r12
  41194d:	imul   r13,r12,0xa
  411951:	sub    r11,r13
  411954:	mov    r13,QWORD PTR [rip+0x1cb5]        # 413610 <__swc_rdata_base_fc36583a+0x500>
  41195b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411960:	mov    BYTE PTR [r9],r11b
  411963:	lea    r11,[r9+0x1]
  411967:	mov    r9,r11
  41196a:	test   r12,r12
  41196d:	jne    411920 <__swc_fn_fc36583a_000149_6203dca2+0xea0>
  41196f:	test   r8,r8
  411972:	jge    41197c <__swc_fn_fc36583a_000149_6203dca2+0xefc>
  411974:	mov    BYTE PTR [r11],0x2d
  411978:	lea    r9,[r11+0x1]
  41197c:	mov    rdx,r9
  41197f:	mov    BYTE PTR [r9],0x0
  411983:	sub    r9,0x1
  411987:	mov    r8,rcx
  41198a:	cmp    r8,r9
  41198d:	jae    4119a8 <__swc_fn_fc36583a_000149_6203dca2+0xf28>
  41198f:	nop
  411990:	mov    r11b,BYTE PTR [r9]
  411993:	mov    r12b,BYTE PTR [r8]
  411996:	mov    BYTE PTR [r9],r12b
  411999:	sub    r9,0x1
  41199d:	mov    BYTE PTR [r8],r11b
  4119a0:	inc    r8
  4119a3:	cmp    r8,r9
  4119a6:	jb     411990 <__swc_fn_fc36583a_000149_6203dca2+0xf10>
  4119a8:	mov    r9,rdx
  4119ab:	mov    BYTE PTR [r9],0x2e
  4119af:	add    r9,0x1
  4119b3:	xor    r8d,r8d
  4119b6:	test   r10,r10
  4119b9:	je     4119ff <__swc_fn_fc36583a_000149_6203dca2+0xf7f>
  4119bb:	mov    r11d,0x989680
  4119c1:	cmp    r10,r11
  4119c4:	jge    4119ff <__swc_fn_fc36583a_000149_6203dca2+0xf7f>
  4119c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4119d0:	inc    r8d
  4119d3:	movabs rdx,0x6666666666666667
  4119dd:	mov    r15,rax
  4119e0:	mov    rax,r11
  4119e3:	imul   rdx
  4119e6:	mov    r11,rdx
  4119e9:	mov    rax,r15
  4119ec:	sar    r11,0x2
  4119f0:	mov    rdx,r11
  4119f3:	shr    rdx,0x3f
  4119f7:	add    r11,rdx
  4119fa:	cmp    r10,r11
  4119fd:	jl     4119d0 <__swc_fn_fc36583a_000149_6203dca2+0xf50>
  4119ff:	test   r8d,r8d
  411a02:	je     411a1d <__swc_fn_fc36583a_000149_6203dca2+0xf9d>
  411a04:	cs nop WORD PTR [rax+rax*1+0x0]
  411a0e:	xchg   ax,ax
  411a10:	mov    BYTE PTR [r9],0x30
  411a14:	add    r9,0x1
  411a18:	dec    r8d
  411a1b:	jne    411a10 <__swc_fn_fc36583a_000149_6203dca2+0xf90>
  411a1d:	mov    r8,r9
  411a20:	mov    rdx,r10
  411a23:	cs nop WORD PTR [rax+rax*1+0x0]
  411a2d:	nop    DWORD PTR [rax]
  411a30:	mov    r11,rdx
  411a33:	movabs rdx,0x6666666666666667
  411a3d:	mov    rax,r11
  411a40:	imul   rdx
  411a43:	sar    rdx,0x2
  411a47:	mov    r12,rdx
  411a4a:	shr    rdx,0x3f
  411a4e:	add    r12,rdx
  411a51:	mov    rdx,r12
  411a54:	imul   r13,r12,0xa
  411a58:	sub    r11,r13
  411a5b:	mov    r13,QWORD PTR [rip+0x1bae]        # 413610 <__swc_rdata_base_fc36583a+0x500>
  411a62:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411a67:	mov    BYTE PTR [r8],r11b
  411a6a:	lea    r11,[r8+0x1]
  411a6e:	mov    r8,r11
  411a71:	test   r12,r12
  411a74:	jne    411a30 <__swc_fn_fc36583a_000149_6203dca2+0xfb0>
  411a76:	test   r10,r10
  411a79:	jge    411a83 <__swc_fn_fc36583a_000149_6203dca2+0x1003>
  411a7b:	mov    BYTE PTR [r11],0x2d
  411a7f:	lea    r8,[r11+0x1]
  411a83:	mov    BYTE PTR [r8],0x0
  411a87:	sub    r8,0x1
  411a8b:	cmp    r9,r8
  411a8e:	jae    411aa8 <__swc_fn_fc36583a_000149_6203dca2+0x1028>
  411a90:	mov    al,BYTE PTR [r8]
  411a93:	mov    dl,BYTE PTR [r9]
  411a96:	mov    BYTE PTR [r8],dl
  411a99:	sub    r8,0x1
  411a9d:	mov    BYTE PTR [r9],al
  411aa0:	inc    r9
  411aa3:	cmp    r9,r8
  411aa6:	jb     411a90 <__swc_fn_fc36583a_000149_6203dca2+0x1010>
  411aa8:	xor    eax,eax
  411aaa:	test   rcx,rcx
  411aad:	je     411ad0 <__swc_fn_fc36583a_000149_6203dca2+0x1050>
  411aaf:	mov    rdx,rcx
  411ab2:	mov    r8b,BYTE PTR [rdx]
  411ab5:	test   r8b,r8b
  411ab8:	je     411ad0 <__swc_fn_fc36583a_000149_6203dca2+0x1050>
  411aba:	nop    WORD PTR [rax+rax*1+0x0]
  411ac0:	add    rdx,0x1
  411ac4:	add    rax,0x1
  411ac8:	mov    r8b,BYTE PTR [rdx]
  411acb:	test   r8b,r8b
  411ace:	jne    411ac0 <__swc_fn_fc36583a_000149_6203dca2+0x1040>
  411ad0:	mov    QWORD PTR [rsp+0x3f8],rcx
  411ad8:	mov    QWORD PTR [rsp+0x400],rax
  411ae0:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  411ae9:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  411af2:	lea    rcx,[rsp+0x408]
  411afa:	call   410210 <__swc_fn_fc36583a_000119_2648f149>
  411aff:	jmp    411b45 <__swc_fn_fc36583a_000149_6203dca2+0x10c5>
  411b01:	mov    rcx,rdx
  411b04:	call   410210 <__swc_fn_fc36583a_000119_2648f149>
  411b09:	jmp    411b45 <__swc_fn_fc36583a_000149_6203dca2+0x10c5>
  411b0b:	mov    al,BYTE PTR [rdx]
  411b0d:	test   al,al
  411b0f:	je     411b1a <__swc_fn_fc36583a_000149_6203dca2+0x109a>
  411b11:	lea    rax,[rip+0x1b18]        # 413630 <__swc_rdata_base_fc36583a+0x520>
  411b18:	jmp    411b21 <__swc_fn_fc36583a_000149_6203dca2+0x10a1>
  411b1a:	lea    rax,[rip+0x1b1f]        # 413640 <__swc_rdata_base_fc36583a+0x530>
  411b21:	mov    rcx,rax
  411b24:	call   410210 <__swc_fn_fc36583a_000119_2648f149>
  411b29:	jmp    411b45 <__swc_fn_fc36583a_000149_6203dca2+0x10c5>
  411b2b:	lea    rcx,[rip+0x1b1e]        # 413650 <__swc_rdata_base_fc36583a+0x540>
  411b32:	call   410210 <__swc_fn_fc36583a_000119_2648f149>
  411b37:	jmp    411b45 <__swc_fn_fc36583a_000149_6203dca2+0x10c5>
  411b39:	lea    rcx,[rip+0x1b10]        # 413650 <__swc_rdata_base_fc36583a+0x540>
  411b40:	call   410210 <__swc_fn_fc36583a_000119_2648f149>
  411b45:	add    rdi,0x1
  411b49:	sub    rsi,0x1
  411b4d:	vmovups xmm0,xmm12
  411b52:	vmovsd xmm6,QWORD PTR [rip+0x1b06]        # 413660 <__swc_rdata_base_fc36583a+0x550>
  411b5a:	test   rsi,rsi
  411b5d:	jne    410b90 <__swc_fn_fc36583a_000149_6203dca2+0x110>
  411b63:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  411b6c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  411b75:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  411b7e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411b87:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411b90:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411b99:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411ba2:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  411bab:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411bb4:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  411bbd:	add    rsp,0x4e8
  411bc4:	pop    r15
  411bc6:	pop    r13
  411bc8:	pop    r12
  411bca:	pop    rdi
  411bcb:	pop    rsi
  411bcc:	pop    rbx
  411bcd:	ret
	...

0000000000411bd0 <__swc_fn_fc36583a_000152_86f1d437>:
  411bd0:	vxorps xmm0,xmm0,xmm0
  411bd4:	vmovups XMMWORD PTR [rcx],xmm0
  411bd8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411bdd:	ret
	...

0000000000411be0 <__swc_fn_fc36583a_000155_86f1d437>:
  411be0:	vxorps xmm0,xmm0,xmm0
  411be4:	vmovups XMMWORD PTR [rcx],xmm0
  411be8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411bed:	vxorps xmm0,xmm0,xmm0
  411bf1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411bf6:	vmovups xmm0,XMMWORD PTR [rip+0x1b72]        # 413770 <__swc_rdata_base_fc36583a+0x660>
  411bfe:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411c03:	vxorps xmm0,xmm0,xmm0
  411c07:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411c0c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411c11:	vxorps xmm0,xmm0,xmm0
  411c15:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  411c1a:	mov    QWORD PTR [rcx+0x70],0x0
  411c22:	ret
	...

0000000000411c30 <__swc_fn_fc36583a_000158_86f1d437>:
  411c30:	vxorps xmm0,xmm0,xmm0
  411c34:	vmovups XMMWORD PTR [rcx],xmm0
  411c38:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411c3d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411c42:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411c47:	ret
	...

0000000000411c50 <__swc_fn_fc36583a_000161_e36363a8>:
  411c50:	push   rsi
  411c51:	push   rdi
  411c52:	sub    rsp,0x8
  411c56:	mov    rsi,rcx
  411c59:	mov    rdi,QWORD PTR [rsi+0x50]
  411c5d:	test   rdi,rdi
  411c60:	je     411c67 <__swc_fn_fc36583a_000161_e36363a8+0x17>
  411c62:	mov    rcx,rsi
  411c65:	call   rdi
  411c67:	mov    QWORD PTR [rsi+0x20],0x0
  411c6f:	mov    rax,QWORD PTR [rsi+0x30]
  411c73:	test   rax,rax
  411c76:	je     411ca4 <__swc_fn_fc36583a_000161_e36363a8+0x54>
  411c78:	nop    DWORD PTR [rax+rax*1+0x0]
  411c80:	mov    rdi,QWORD PTR [rax+0x8]
  411c84:	mov    rcx,rsi
  411c87:	mov    rdx,QWORD PTR [rax+0x10]
  411c8b:	mov    rax,QWORD PTR [rax+0x18]
  411c8f:	mov    r8,rax
  411c92:	call   409f30 <__swc_fn_fc36583a_000159_47b270e1>
  411c97:	mov    QWORD PTR [rsi+0x30],rdi
  411c9b:	mov    rax,QWORD PTR [rsi+0x30]
  411c9f:	test   rax,rax
  411ca2:	jne    411c80 <__swc_fn_fc36583a_000161_e36363a8+0x30>
  411ca4:	mov    QWORD PTR [rsi+0x38],0x0
  411cac:	add    rsp,0x8
  411cb0:	pop    rdi
  411cb1:	pop    rsi
  411cb2:	ret
	...

0000000000411cc0 <__swc_fn_fc36583a_000164_016ee66a>:
  411cc0:	push   rbx
  411cc1:	push   rsi
  411cc2:	push   rdi
  411cc3:	push   r12
  411cc5:	sub    rsp,0x188
  411ccc:	mov    rbx,rcx
  411ccf:	lea    rsi,[rip+0x150b2]        # 426d88 <__swc_bss_base_fc36583a+0x2d48>
  411cd6:	mov    rcx,rsi
  411cd9:	call   409940 <__swc_fn_fc36583a_000138_86bb0f90>
  411cde:	mov    rax,QWORD PTR [rip+0x150ab]        # 426d90 <__swc_bss_base_fc36583a+0x2d50>
  411ce5:	mov    rdi,rax
  411ce8:	test   rdi,rdi
  411ceb:	je     411d19 <__swc_fn_fc36583a_000164_016ee66a+0x59>
  411ced:	nop    DWORD PTR [rax]
  411cf0:	cmp    QWORD PTR [rdi+0x8],rbx
  411cf4:	jne    411d0e <__swc_fn_fc36583a_000164_016ee66a+0x4e>
  411cf6:	mov    rcx,rsi
  411cf9:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  411cfe:	mov    rax,rdi
  411d01:	add    rsp,0x188
  411d08:	pop    r12
  411d0a:	pop    rdi
  411d0b:	pop    rsi
  411d0c:	pop    rbx
  411d0d:	ret
  411d0e:	mov    rax,QWORD PTR [rdi]
  411d11:	mov    rdi,rax
  411d14:	test   rax,rax
  411d17:	jne    411cf0 <__swc_fn_fc36583a_000164_016ee66a+0x30>
  411d19:	call   40cf20 <__swc_fn_fc36583a_000142_d299b428>
  411d1e:	mov    rdi,rax
  411d21:	test   rax,rax
  411d24:	jne    411d3d <__swc_fn_fc36583a_000164_016ee66a+0x7d>
  411d26:	mov    rcx,rsi
  411d29:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  411d2e:	xor    eax,eax
  411d30:	add    rsp,0x188
  411d37:	pop    r12
  411d39:	pop    rdi
  411d3a:	pop    rsi
  411d3b:	pop    rbx
  411d3c:	ret
  411d3d:	lea    rax,[rsp+0x18]
  411d42:	mov    QWORD PTR [rax+0x10],0x0
  411d4a:	mov    QWORD PTR [rax+0x18],0x0
  411d52:	mov    DWORD PTR [rax+0x20],0x0
  411d59:	mov    BYTE PTR [rax+0x24],0x0
  411d5d:	mov    rax,QWORD PTR [rip+0x1502c]        # 426d90 <__swc_bss_base_fc36583a+0x2d50>
  411d64:	mov    QWORD PTR [rsp+0x18],rax
  411d69:	mov    QWORD PTR [rsp+0x20],rbx
  411d6e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411d74:	vmovups XMMWORD PTR [rdi],xmm0
  411d78:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  411d7e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  411d83:	mov    rax,QWORD PTR [rsp+0x38]
  411d88:	mov    QWORD PTR [rdi+0x20],rax
  411d8c:	mov    QWORD PTR [rip+0x14ffd],rdi        # 426d90 <__swc_bss_base_fc36583a+0x2d50>
  411d93:	lea    rax,[rsp+0x40]
  411d98:	mov    QWORD PTR [rax],0x0
  411d9f:	mov    rcx,rbx
  411da2:	mov    rdx,rax
  411da5:	call   409a20 <__swc_fn_fc36583a_000144_1534de9a>
  411daa:	mov    rbx,rax
  411dad:	test   rax,rax
  411db0:	jne    411dca <__swc_fn_fc36583a_000164_016ee66a+0x10a>
  411db2:	mov    rcx,rsi
  411db5:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  411dba:	mov    rax,rdi
  411dbd:	add    rsp,0x188
  411dc4:	pop    r12
  411dc6:	pop    rdi
  411dc7:	pop    rsi
  411dc8:	pop    rbx
  411dc9:	ret
  411dca:	lea    r12,[rsp+0x50]
  411dcf:	mov    QWORD PTR [r12],0x0
  411dd7:	mov    rcx,rbx
  411dda:	mov    rdx,QWORD PTR [rsp+0x40]
  411ddf:	mov    r8,r12
  411de2:	call   40cfd0 <__swc_fn_fc36583a_000145_162f363d>
  411de7:	test   rax,rax
  411dea:	jne    411e04 <__swc_fn_fc36583a_000164_016ee66a+0x144>
  411dec:	mov    rcx,rsi
  411def:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  411df4:	mov    rax,rdi
  411df7:	add    rsp,0x188
  411dfe:	pop    r12
  411e00:	pop    rdi
  411e01:	pop    rsi
  411e02:	pop    rbx
  411e03:	ret
  411e04:	cmp    QWORD PTR [r12],0x10
  411e09:	jb     411f0c <__swc_fn_fc36583a_000164_016ee66a+0x24c>
  411e0f:	mov    ecx,DWORD PTR [rax]
  411e11:	cmp    ecx,0x42445753
  411e17:	jne    411f0c <__swc_fn_fc36583a_000164_016ee66a+0x24c>
  411e1d:	mov    ecx,DWORD PTR [rax+0x4]
  411e20:	cmp    ecx,0x1
  411e23:	jne    411f0c <__swc_fn_fc36583a_000164_016ee66a+0x24c>
  411e29:	mov    ecx,DWORD PTR [rax+0x8]
  411e2c:	mov    edx,DWORD PTR [rax+0xc]
  411e2f:	imul   r8,rcx,0x14
  411e33:	mov    r9,QWORD PTR [rsp+0x50]
  411e38:	sub    r9,0x10
  411e3c:	cmp    r8,r9
  411e3f:	ja     411f0c <__swc_fn_fc36583a_000164_016ee66a+0x24c>
  411e45:	lea    r8,[r8+0x10]
  411e49:	cmp    rdx,r8
  411e4c:	jb     411f0c <__swc_fn_fc36583a_000164_016ee66a+0x24c>
  411e52:	mov    r8,QWORD PTR [rsp+0x50]
  411e57:	cmp    rdx,r8
  411e5a:	ja     411f0c <__swc_fn_fc36583a_000164_016ee66a+0x24c>
  411e60:	xor    r8d,r8d
  411e63:	test   rcx,rcx
  411e66:	jbe    411f32 <__swc_fn_fc36583a_000164_016ee66a+0x272>
  411e6c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  411e72:	cs nop WORD PTR [rax+rax*1+0x0]
  411e7c:	nop    DWORD PTR [rax+0x0]
  411e80:	imul   r9,r8,0x14
  411e84:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  411e89:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  411e8e:	add    r10,r11
  411e91:	movabs r11,0x100000000
  411e9b:	cmp    r10,r11
  411e9e:	ja     411f0c <__swc_fn_fc36583a_000164_016ee66a+0x24c>
  411ea0:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  411ea5:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  411eaa:	test   r10d,r10d
  411ead:	setne  r11b
  411eb1:	je     411ecb <__swc_fn_fc36583a_000164_016ee66a+0x20b>
  411eb3:	cmp    r10d,edx
  411eb6:	setb   r11b
  411eba:	jb     411ecb <__swc_fn_fc36583a_000164_016ee66a+0x20b>
  411ebc:	vmovq  r11,xmm1
  411ec1:	cmp    r10,r11
  411ec4:	setae  r10b
  411ec8:	mov    r11b,r10b
  411ecb:	mov    r10,r11
  411ece:	test   r11b,r11b
  411ed1:	jne    411ef8 <__swc_fn_fc36583a_000164_016ee66a+0x238>
  411ed3:	test   r9d,r9d
  411ed6:	setne  r10b
  411eda:	je     411ef8 <__swc_fn_fc36583a_000164_016ee66a+0x238>
  411edc:	cmp    r9d,edx
  411edf:	setb   r10b
  411ee3:	jb     411ef8 <__swc_fn_fc36583a_000164_016ee66a+0x238>
  411ee5:	vmovq  r10,xmm1
  411eea:	cmp    r9,r10
  411eed:	setae  r9b
  411ef1:	movzx  r9d,r9b
  411ef5:	mov    r10b,r9b
  411ef8:	test   r10b,r10b
  411efb:	jne    411f0c <__swc_fn_fc36583a_000164_016ee66a+0x24c>
  411efd:	add    r8,0x1
  411f01:	cmp    r8,rcx
  411f04:	jb     411e80 <__swc_fn_fc36583a_000164_016ee66a+0x1c0>
  411f0a:	jmp    411f32 <__swc_fn_fc36583a_000164_016ee66a+0x272>
  411f0c:	xor    ecx,ecx
  411f0e:	cmp    rax,rbx
  411f11:	cmovne rcx,rax
  411f15:	call   4109d0 <__swc_fn_fc36583a_000146_d7edc04f>
  411f1a:	mov    rcx,rsi
  411f1d:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  411f22:	mov    rax,rdi
  411f25:	add    rsp,0x188
  411f2c:	pop    r12
  411f2e:	pop    rdi
  411f2f:	pop    rsi
  411f30:	pop    rbx
  411f31:	ret
  411f32:	mov    QWORD PTR [rdi+0x10],rax
  411f36:	mov    rcx,QWORD PTR [rsp+0x50]
  411f3b:	mov    QWORD PTR [rdi+0x18],rcx
  411f3f:	mov    eax,DWORD PTR [rax+0x8]
  411f42:	mov    DWORD PTR [rdi+0x20],eax
  411f45:	rex mov BYTE PTR [rdi+0x24],0x1
  411f4a:	mov    rcx,rsi
  411f4d:	call   40cf10 <__swc_fn_fc36583a_000139_055b38a4>
  411f52:	mov    rax,rdi
  411f55:	add    rsp,0x188
  411f5c:	pop    r12
  411f5e:	pop    rdi
  411f5f:	pop    rsi
  411f60:	pop    rbx
  411f61:	ret
	...

0000000000411f70 <__swc_fn_fc36583a_000167_3459066f>:
  411f70:	push   rsi
  411f71:	push   rdi
  411f72:	push   r12
  411f74:	mov    rsi,rdx
  411f77:	mov    rdi,rcx
  411f7a:	mov    rcx,QWORD PTR [rip+0x120bf]        # 424040 <__swc_bss_base_fc36583a>
  411f81:	test   rcx,rcx
  411f84:	jne    411f96 <__swc_fn_fc36583a_000167_3459066f+0x26>
  411f86:	call   40a240 <__swc_fn_fc36583a_000168_994c8876>
  411f8b:	lea    rcx,[rax+0x1]
  411f8f:	mov    QWORD PTR [rip+0x120aa],rcx        # 424040 <__swc_bss_base_fc36583a>
  411f96:	dec    rcx
  411f99:	call   411fc0 <__swc_fn_fc36583a_000170_360af05d>
  411f9e:	mov    r12,QWORD PTR [rax+0xbe0]
  411fa5:	test   r12,r12
  411fa8:	setne  al
  411fab:	je     411fb6 <__swc_fn_fc36583a_000167_3459066f+0x46>
  411fad:	mov    rcx,rdi
  411fb0:	mov    rdx,rsi
  411fb3:	call   r12
  411fb6:	pop    r12
  411fb8:	pop    rdi
  411fb9:	pop    rsi
  411fba:	ret
  411fbb:	add    BYTE PTR [rax],al
  411fbd:	add    BYTE PTR [rax],al
	...

0000000000411fc0 <__swc_fn_fc36583a_000170_360af05d>:
  411fc0:	push   r12
  411fc2:	push   rdi
  411fc3:	push   rsi
  411fc4:	sub    rsp,0xd0
  411fcb:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  411fd1:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  411fd7:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  411fdd:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  411fe3:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  411fe9:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  411fef:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  411ff8:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  412001:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  41200a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  412013:	mov    r12,rcx
  412016:	mov    edi,ecx
  412018:	xor    eax,eax
  41201a:	call   407000 <pthread_getspecific@plt>
  41201f:	test   rax,rax
  412022:	je     412026 <__swc_fn_fc36583a_000170_360af05d+0x66>
  412024:	jmp    41202e <__swc_fn_fc36583a_000170_360af05d+0x6e>
  412026:	mov    rcx,r12
  412029:	call   40a2a0 <__swc_fn_fc36583a_000171_cbeff767>
  41202e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  412034:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  41203a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  412040:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  412046:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  41204c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  412052:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  41205b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  412064:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  41206d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  412076:	add    rsp,0xd0
  41207d:	pop    rsi
  41207e:	pop    rdi
  41207f:	pop    r12
  412081:	ret
	...

0000000000412090 <__swc_fn_fc36583a_000173_5eac0ab4>:
  412090:	push   rsi
  412091:	sub    rsp,0x30
  412095:	lea    rsi,[rip+0x14d04]        # 426da0 <__swc_bss_base_fc36583a+0x2d60>
  41209c:	mov    rax,QWORD PTR [rsi]
  41209f:	test   rax,rax
  4120a2:	je     4120aa <__swc_fn_fc36583a_000173_5eac0ab4+0x1a>
  4120a4:	add    rsp,0x30
  4120a8:	pop    rsi
  4120a9:	ret
  4120aa:	mov    ecx,0x3
  4120af:	mov    edx,0x10
  4120b4:	call   40fb30 <__swc_fn_fc36583a_000110_6814119b>
  4120b9:	test   rax,rax
  4120bc:	jne    4120cd <__swc_fn_fc36583a_000173_5eac0ab4+0x3d>
  4120be:	mov    QWORD PTR [rsp+0x18],rax
  4120c3:	call   40ca70 <__swc_fn_fc36583a_000121_be2e2f68>
  4120c8:	mov    rax,QWORD PTR [rsp+0x18]
  4120cd:	mov    rcx,rax
  4120d0:	xchg   QWORD PTR [rsi],rcx
  4120d3:	add    rsp,0x30
  4120d7:	pop    rsi
  4120d8:	ret
  4120d9:	add    BYTE PTR [rax],al
  4120db:	add    BYTE PTR [rax],al
  4120dd:	add    BYTE PTR [rax],al
	...

00000000004120e0 <__swc_fn_fc36583a_000176_cf4ffedd>:
  4120e0:	push   rsi
  4120e1:	push   rdi
  4120e2:	sub    rsp,0x8
  4120e6:	mov    rsi,rdx
  4120e9:	mov    rdi,rcx
  4120ec:	mov    rax,QWORD PTR [rsi+0x8]
  4120f0:	test   rax,rax
  4120f3:	je     4120fd <__swc_fn_fc36583a_000176_cf4ffedd+0x1d>
  4120f5:	mov    rcx,QWORD PTR [rsi]
  4120f8:	mov    QWORD PTR [rax],rcx
  4120fb:	jmp    412104 <__swc_fn_fc36583a_000176_cf4ffedd+0x24>
  4120fd:	mov    rax,QWORD PTR [rsi]
  412100:	mov    QWORD PTR [rdi+0x8],rax
  412104:	mov    rax,QWORD PTR [rsi]
  412107:	test   rax,rax
  41210a:	je     412114 <__swc_fn_fc36583a_000176_cf4ffedd+0x34>
  41210c:	mov    rcx,QWORD PTR [rsi+0x8]
  412110:	mov    QWORD PTR [rax+0x8],rcx
  412114:	mov    rcx,rdi
  412117:	mov    rdx,QWORD PTR [rsi+0x10]
  41211b:	mov    r8,QWORD PTR [rsi+0x18]
  41211f:	mov    r9,0xffffffffffffffff
  412126:	call   40d620 <__swc_fn_fc36583a_000175_4de704de>
  41212b:	mov    QWORD PTR [rsi+0x18],0x0
  412133:	mov    rax,QWORD PTR [rdi+0x8]
  412137:	test   rax,rax
  41213a:	jne    41214c <__swc_fn_fc36583a_000176_cf4ffedd+0x6c>
  41213c:	call   412090 <__swc_fn_fc36583a_000173_5eac0ab4>
  412141:	xor    ecx,ecx
  412143:	mov    QWORD PTR [rax+0x8],rcx
  412147:	xor    ecx,ecx
  412149:	mov    QWORD PTR [rax],rcx
  41214c:	add    rsp,0x8
  412150:	pop    rdi
  412151:	pop    rsi
  412152:	ret
