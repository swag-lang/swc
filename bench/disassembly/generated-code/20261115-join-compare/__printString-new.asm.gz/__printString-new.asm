
/workspace/prompt2-20261115/batch4-final-micro/new/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

0000000000410460 <__swc_fn_4fa09e82_000122_2648f149>:
  410460:	push   r12
  410462:	push   r13
  410464:	push   r14
  410466:	push   rdi
  410467:	push   rsi
  410468:	sub    rsp,0xc0
  41046f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  410475:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  41047b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  410481:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410487:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  41048d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  410493:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410499:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4104a2:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4104ab:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4104b4:	mov    r12,QWORD PTR [rcx]
  4104b7:	test   r12,r12
  4104ba:	jne    4104cc <__swc_fn_4fa09e82_000122_2648f149+0x6c>
  4104bc:	add    rsp,0xc0
  4104c3:	pop    rsi
  4104c4:	pop    rdi
  4104c5:	pop    r14
  4104c7:	pop    r13
  4104c9:	pop    r12
  4104cb:	ret
  4104cc:	xor    r13d,r13d
  4104cf:	mov    r14,QWORD PTR [rcx+0x8]
  4104d3:	cs nop WORD PTR [rax+rax*1+0x0]
  4104dd:	nop    DWORD PTR [rax]
  4104e0:	cmp    r13,r14
  4104e3:	jae    41051b <__swc_fn_4fa09e82_000122_2648f149+0xbb>
  4104e5:	lea    rax,[r12+r13*1]
  4104e9:	mov    rcx,r14
  4104ec:	sub    rcx,r13
  4104ef:	mov    edi,0x1
  4104f4:	mov    rsi,rax
  4104f7:	mov    rdx,rcx
  4104fa:	xor    eax,eax
  4104fc:	call   4071c0 <write@plt>
  410501:	test   rax,rax
  410504:	jle    41050b <__swc_fn_4fa09e82_000122_2648f149+0xab>
  410506:	add    r13,rax
  410509:	jmp    4104e0 <__swc_fn_4fa09e82_000122_2648f149+0x80>
  41050b:	je     410519 <__swc_fn_4fa09e82_000122_2648f149+0xb9>
  41050d:	xor    eax,eax
  41050f:	call   407130 <__errno_location@plt>
  410514:	cmp    DWORD PTR [rax],0x4
  410517:	je     4104e0 <__swc_fn_4fa09e82_000122_2648f149+0x80>
  410519:	jmp    41051b <__swc_fn_4fa09e82_000122_2648f149+0xbb>
  41051b:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410521:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  410527:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  41052d:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  410533:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410539:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  41053f:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  410545:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  41054e:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  410557:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410560:	add    rsp,0xc0
  410567:	pop    rsi
  410568:	pop    rdi
  410569:	pop    r14
  41056b:	pop    r13
  41056d:	pop    r12
  41056f:	ret
