
/workspace/prompt2-20261115/batch5-final-micro/new/chacha/chacha:     file format elf64-x86-64


Disassembly of section .text:

000000000040a630 <__swc_fn_3464c816_000159_47b270e1>:
  40a630:	push   rbx
  40a631:	sub    rsp,0x70
  40a635:	mov    rax,QWORD PTR [rcx]
  40a638:	mov    rbx,QWORD PTR [rcx+0x8]
  40a63c:	vxorps xmm0,xmm0,xmm0
  40a640:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40a646:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40a64c:	vzeroupper
  40a64f:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40a655:	mov    QWORD PTR [rsp+0x48],rdx
  40a65a:	mov    QWORD PTR [rsp+0x50],r8
  40a65f:	mov    rcx,rax
  40a662:	lea    rdx,[rsp+0x8]
  40a667:	mov    rbx,QWORD PTR [rbx+0x18]
  40a66b:	call   rbx
  40a66d:	add    rsp,0x70
  40a671:	pop    rbx
  40a672:	ret
