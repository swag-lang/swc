from pathlib import Path
import struct,subprocess,sys,json
root=Path(sys.argv[1]);task=sys.argv[2];wanted=sys.argv[3:];summary={}
for role in ['base','new']:
 p=root/role/task/task;data=p.read_bytes();shoff=struct.unpack_from('<Q',data,40)[0];num,idx=struct.unpack_from('<HH',data,60);ss=struct.unpack_from('<IIQQQQIIQQ',data,shoff+idx*64);names=data[ss[4]:ss[4]+ss[5]]
 for i in range(num):
  sh=struct.unpack_from('<IIQQQQIIQQ',data,shoff+i*64);name=names[sh[0]:names.index(b'\0',sh[0])]
  if name!=b'.swagdbg':continue
  d=data[sh[4]:sh[4]+sh[5]];magic,version,count,strings=struct.unpack_from('<IIII',d);assert magic==0x42445753 and version==1
  def text(o):return d[o:d.index(b'\0',o)].decode() if o else ''
  lines=[]
  for k in range(count):
   rva,size,fn,file,line=struct.unpack_from('<IIIII',d,16+k*20);fn=text(fn);lines.append(f'{0x400000+rva:016x} {size:08x} {fn} {text(file)}:{line}')
   if fn in wanted:
    asm=subprocess.check_output(['objdump','-d','-Mintel','--no-show-raw-insn',f'--start-address={0x400000+rva}',f'--stop-address={0x400000+rva+size}',str(p)],text=True);(p.parent/(fn+'.asm')).write_text(asm);summary.setdefault(fn,{})[role]={'address':hex(0x400000+rva),'bytes':size}
  (p.parent/'symbols.txt').write_text('\n'.join(lines)+'\n')
(root/(task+'-functions.json')).write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
