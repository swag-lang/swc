
/workspace/prompt2-20261115/batch5-final-micro/base/chacha/chacha:     file format elf64-x86-64


Disassembly of section .text:

000000000040cf80 <__swc_fn_3464c816_000145_140c84e9>:
  40cf80:	push   rbx
  40cf81:	sub    rsp,0xe0
  40cf88:	lea    rbx,[rsp+0x8]
  40cf8d:	vxorps xmm0,xmm0,xmm0
  40cf91:	vmovups XMMWORD PTR [rbx],xmm0
  40cf95:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40cf9a:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40cf9f:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40cfa4:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40cfa9:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  40cfae:	mov    DWORD PTR [rbx+0x60],0x0
  40cfb5:	mov    r8,rbx
  40cfb8:	mov    rdx,rcx
  40cfbb:	nop    DWORD PTR [rax+rax*1+0x0]
  40cfc0:	mov    r9,rdx
  40cfc3:	movabs rdx,0x6666666666666667
  40cfcd:	mov    rax,r9
  40cfd0:	imul   rdx
  40cfd3:	sar    rdx,0x2
  40cfd7:	mov    r10,rdx
  40cfda:	shr    rdx,0x3f
  40cfde:	add    r10,rdx
  40cfe1:	mov    rdx,r10
  40cfe4:	imul   r11,r10,0xa
  40cfe8:	sub    r9,r11
  40cfeb:	mov    r11,QWORD PTR [rip+0x654e]        # 413540 <__swc_rdata_base_3464c816+0x430>
  40cff2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40cff7:	mov    BYTE PTR [r8],r9b
  40cffa:	lea    r9,[r8+0x1]
  40cffe:	mov    r8,r9
  40d001:	test   r10,r10
  40d004:	jne    40cfc0 <__swc_fn_3464c816_000145_140c84e9+0x40>
  40d006:	test   rcx,rcx
  40d009:	jge    40d013 <__swc_fn_3464c816_000145_140c84e9+0x93>
  40d00b:	mov    BYTE PTR [r9],0x2d
  40d00f:	add    r8,0x1
  40d013:	mov    BYTE PTR [r8],0x0
  40d017:	sub    r8,0x1
  40d01b:	mov    rax,rbx
  40d01e:	cmp    rax,r8
  40d021:	jae    40d046 <__swc_fn_3464c816_000145_140c84e9+0xc6>
  40d023:	cs nop WORD PTR [rax+rax*1+0x0]
  40d02d:	nop    DWORD PTR [rax]
  40d030:	mov    cl,BYTE PTR [r8]
  40d033:	mov    dl,BYTE PTR [rax]
  40d035:	mov    BYTE PTR [r8],dl
  40d038:	sub    r8,0x1
  40d03c:	mov    BYTE PTR [rax],cl
  40d03e:	inc    rax
  40d041:	cmp    rax,r8
  40d044:	jb     40d030 <__swc_fn_3464c816_000145_140c84e9+0xb0>
  40d046:	xor    eax,eax
  40d048:	test   rbx,rbx
  40d04b:	je     40d06e <__swc_fn_3464c816_000145_140c84e9+0xee>
  40d04d:	mov    rcx,rbx
  40d050:	mov    dl,BYTE PTR [rcx]
  40d052:	test   dl,dl
  40d054:	je     40d06e <__swc_fn_3464c816_000145_140c84e9+0xee>
  40d056:	cs nop WORD PTR [rax+rax*1+0x0]
  40d060:	add    rcx,0x1
  40d064:	add    rax,0x1
  40d068:	mov    dl,BYTE PTR [rcx]
  40d06a:	test   dl,dl
  40d06c:	jne    40d060 <__swc_fn_3464c816_000145_140c84e9+0xe0>
  40d06e:	mov    QWORD PTR [rbx+0xa8],rbx
  40d075:	mov    QWORD PTR [rbx+0xb0],rax
  40d07c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d084:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d08c:	lea    rcx,[rbx+0xb8]
  40d093:	call   410100 <__swc_fn_3464c816_000116_18ca1307>
  40d098:	add    rsp,0xe0
  40d09f:	pop    rbx
  40d0a0:	ret
