
/workspace/prompt2-20261115/batch9-audited-micro/new/lz77/lz77:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <open@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <open@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <flock@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <flock@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <__errno_location@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <__errno_location@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <close@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <close@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <getpid@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <getpid@GLIBC_2.2.5>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <opendir@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <opendir@GLIBC_2.2.5>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <dirfd@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <dirfd@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <readdir@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <readdir@GLIBC_2.2.5>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <readlinkat@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <readlinkat@GLIBC_2.4>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <openat@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <openat@GLIBC_2.4>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <closedir@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <closedir@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <lseek@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <lseek@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <mmap@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <mmap@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <memfd_create@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf92]        # 413078 <memfd_create@GLIBC_2.27>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <ftruncate@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf8a]        # 413080 <ftruncate@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <write@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf82]        # 413088 <write@GLIBC_2.2.5>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <backtrace@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf7a]        # 413090 <backtrace@GLIBC_2.2.5>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <pthread_setspecific@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf72]        # 413098 <pthread_setspecific@GLIBC_2.34>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <clock_gettime@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf6a]        # 4130a0 <clock_gettime@GLIBC_2.17>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <__x86_get_cpuid_feature_leaf@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf62]        # 4130a8 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <free@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf5a]        # 4130b0 <free@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <munmap@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf52]        # 4130b8 <munmap@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <mprotect@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf4a]        # 4130c0 <mprotect@GLIBC_2.2.5>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <exit@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf42]        # 4130c8 <exit@GLIBC_2.2.5>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <pthread_key_create@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf3a]        # 4130d0 <pthread_key_create@GLIBC_2.34>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <syscall@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf32]        # 4130d8 <syscall@GLIBC_2.2.5>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <dladdr@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130e0 <dladdr@GLIBC_2.34>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <malloc@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf22]        # 4130e8 <malloc@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <madvise@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <madvise@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <pthread_key_delete@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <pthread_key_delete@GLIBC_2.34>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <gettid@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <gettid@GLIBC_2.30>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_23cea7fa_000176_4de704de+0xf00>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   411600 <__swc_fn_23cea7fa_000125_540bf7e8>
  40724e:	xor    ecx,ecx
  407250:	call   410d20 <__swc_fn_23cea7fa_000098_4f209617>
  407255:	call   407320 <__swc_fn_23cea7fa_000003_3a24e5ea>
  40725a:	call   4093d0 <__swc_fn_23cea7fa_000099_65137b72>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_23cea7fa_000000_2744b483>:
  407270:	push   rbx
  407271:	sub    rsp,0x70
  407275:	cmp    rcx,0xffffffffffffffef
  407279:	jbe    407283 <__swc_fn_23cea7fa_000000_2744b483+0x13>
  40727b:	xor    eax,eax
  40727d:	add    rsp,0x70
  407281:	pop    rbx
  407282:	ret
  407283:	vxorps xmm0,xmm0,xmm0
  407287:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40728d:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  407293:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  407299:	vzeroupper
  40729c:	lea    rax,[rcx+0x10]
  4072a0:	mov    QWORD PTR [rsp+0x50],rax
  4072a5:	mov    DWORD PTR [rsp+0x60],0x10
  4072ad:	mov    rcx,QWORD PTR [rip+0x1cd8c]        # 424040 <__swc_bss_base_23cea7fa>
  4072b4:	test   rcx,rcx
  4072b7:	jne    4072c9 <__swc_fn_23cea7fa_000000_2744b483+0x59>
  4072b9:	call   40ed20 <__swc_fn_23cea7fa_000169_994c8876>
  4072be:	lea    rcx,[rax+0x1]
  4072c2:	mov    QWORD PTR [rip+0x1cd77],rcx        # 424040 <__swc_bss_base_23cea7fa>
  4072c9:	dec    rcx
  4072cc:	call   40bbe0 <__swc_fn_23cea7fa_000171_360af05d>
  4072d1:	mov    rcx,QWORD PTR [rax]
  4072d4:	lea    rdx,[rsp+0x8]
  4072d9:	mov    rbx,QWORD PTR [rax+0x8]
  4072dd:	mov    rbx,QWORD PTR [rbx+0x8]
  4072e1:	call   rbx
  4072e3:	mov    rax,QWORD PTR [rsp+0x48]
  4072e8:	test   rax,rax
  4072eb:	jne    4072f5 <__swc_fn_23cea7fa_000000_2744b483+0x85>
  4072ed:	xor    eax,eax
  4072ef:	add    rsp,0x70
  4072f3:	pop    rbx
  4072f4:	ret
  4072f5:	mov    rcx,QWORD PTR [rsp+0x50]
  4072fa:	mov    QWORD PTR [rax],rcx
  4072fd:	mov    QWORD PTR [rax+0x8],0x0
  407305:	lea    rax,[rax+0x10]
  407309:	add    rsp,0x70
  40730d:	pop    rbx
  40730e:	ret
	...

0000000000407320 <__swc_fn_23cea7fa_000003_3a24e5ea>:
  407320:	push   rbp
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	push   r13
  407327:	push   r15
  407329:	push   r14
  40732b:	sub    rsp,0x18
  40732f:	mov    rbp,rsp
  407332:	vmovups XMMWORD PTR [rsp],xmm6
  407337:	sub    rsp,0x210
  40733e:	mov    ecx,0x1400
  407343:	sub    rsp,0x8
  407347:	call   407270 <__swc_fn_23cea7fa_000000_2744b483>
  40734c:	add    rsp,0x8
  407350:	mov    rsi,rax
  407353:	mov    QWORD PTR [rsp+0x1d0],rax
  40735b:	mov    ecx,0x1000
  407360:	sub    rsp,0x8
  407364:	call   407270 <__swc_fn_23cea7fa_000000_2744b483>
  407369:	add    rsp,0x8
  40736d:	mov    rdi,rax
  407370:	mov    QWORD PTR [rsp+0x1d8],rax
  407378:	mov    ecx,0x1000
  40737d:	sub    rsp,0x8
  407381:	call   407270 <__swc_fn_23cea7fa_000000_2744b483>
  407386:	add    rsp,0x8
  40738a:	mov    r12,rax
  40738d:	mov    QWORD PTR [rsp+0x1e0],rax
  407395:	xor    ecx,ecx
  407397:	xor    r8d,r8d
  40739a:	nop    WORD PTR [rax+rax*1+0x0]
  4073a0:	mov    r9,QWORD PTR [rip+0x1ac59]        # 422000 <__swc_data_base_23cea7fa>
  4073a7:	imul   r9,r9,0x41a7
  4073ae:	movabs rdx,0x200000005
  4073b8:	mov    r11,rax
  4073bb:	mov    rax,r9
  4073be:	mul    rdx
  4073c1:	mov    r10,rdx
  4073c4:	mov    rax,r11
  4073c7:	mov    rdx,r9
  4073ca:	sub    rdx,r10
  4073cd:	shr    rdx,1
  4073d0:	add    rdx,r10
  4073d3:	shr    rdx,0x1e
  4073d7:	imul   r10,rdx,0x7fffffff
  4073de:	sub    r9,r10
  4073e1:	mov    QWORD PTR [rip+0x1ac18],r9        # 422000 <__swc_data_base_23cea7fa>
  4073e8:	and    r9d,0x7
  4073ec:	lea    r9,[r9+0x2]
  4073f0:	mov    QWORD PTR [rdi+r8*8],rcx
  4073f4:	mov    QWORD PTR [r12+r8*8],r9
  4073f8:	xor    r10d,r10d
  4073fb:	test   r9,r9
  4073fe:	jbe    40748b <__swc_fn_23cea7fa_000003_3a24e5ea+0x16b>
  407404:	cs nop WORD PTR [rax+rax*1+0x0]
  40740e:	xchg   ax,ax
  407410:	lea    rdx,[rcx+r10*1]
  407414:	lea    r11,[rsi+rdx*1]
  407418:	mov    r13,QWORD PTR [rip+0x1abe1]        # 422000 <__swc_data_base_23cea7fa>
  40741f:	imul   r13,r13,0x41a7
  407426:	movabs rdx,0x200000005
  407430:	mov    r15,rax
  407433:	mov    rax,r13
  407436:	mul    rdx
  407439:	mov    r14,rdx
  40743c:	mov    rdx,r13
  40743f:	sub    rdx,r14
  407442:	shr    rdx,1
  407445:	add    rdx,r14
  407448:	shr    rdx,0x1e
  40744c:	imul   r14,rdx,0x7fffffff
  407453:	sub    r13,r14
  407456:	mov    QWORD PTR [rip+0x1aba3],r13        # 422000 <__swc_data_base_23cea7fa>
  40745d:	movabs rdx,0x4ec4ec4ec4ec4ec5
  407467:	mov    rax,r13
  40746a:	mul    rdx
  40746d:	mov    rax,r15
  407470:	shr    rdx,0x3
  407474:	imul   rdx,rdx,0x1a
  407478:	sub    r13,rdx
  40747b:	lea    rdx,[r13+0x61]
  40747f:	mov    BYTE PTR [r11],dl
  407482:	add    r10,0x1
  407486:	cmp    r10,r9
  407489:	jb     407410 <__swc_fn_23cea7fa_000003_3a24e5ea+0xf0>
  40748b:	add    rcx,r9
  40748e:	add    r8,0x1
  407492:	cmp    r8,0x200
  407499:	jb     4073a0 <__swc_fn_23cea7fa_000003_3a24e5ea+0x80>
  40749f:	mov    ecx,0x100000
  4074a4:	sub    rsp,0x8
  4074a8:	call   407270 <__swc_fn_23cea7fa_000000_2744b483>
  4074ad:	add    rsp,0x8
  4074b1:	mov    r13,rax
  4074b4:	xor    ecx,ecx
  4074b6:	cs nop WORD PTR [rax+rax*1+0x0]
  4074c0:	cs nop WORD PTR [rax+rax*1+0x0]
  4074ca:	nop    WORD PTR [rax+rax*1+0x0]
  4074d0:	cmp    rcx,0x100000
  4074d7:	jge    407583 <__swc_fn_23cea7fa_000003_3a24e5ea+0x263>
  4074dd:	mov    r8,QWORD PTR [rip+0x1ab1c]        # 422000 <__swc_data_base_23cea7fa>
  4074e4:	imul   r8,r8,0x41a7
  4074eb:	movabs rdx,0x200000005
  4074f5:	mov    rax,r8
  4074f8:	mul    rdx
  4074fb:	mov    r9,rdx
  4074fe:	mov    rdx,r8
  407501:	sub    rdx,r9
  407504:	shr    rdx,1
  407507:	add    rdx,r9
  40750a:	shr    rdx,0x1e
  40750e:	imul   r9,rdx,0x7fffffff
  407515:	sub    r8,r9
  407518:	mov    QWORD PTR [rip+0x1aae1],r8        # 422000 <__swc_data_base_23cea7fa>
  40751f:	and    r8d,0x1ff
  407526:	xor    edx,edx
  407528:	mov    r9,QWORD PTR [r12+r8*8]
  40752c:	cmp    rdx,r9
  40752f:	jae    407568 <__swc_fn_23cea7fa_000003_3a24e5ea+0x248>
  407531:	cs nop WORD PTR [rax+rax*1+0x0]
  40753b:	nop    DWORD PTR [rax+rax*1+0x0]
  407540:	cmp    rcx,0x100000
  407547:	jge    407568 <__swc_fn_23cea7fa_000003_3a24e5ea+0x248>
  407549:	mov    r9,QWORD PTR [rdi+r8*8]
  40754d:	add    r9,rdx
  407550:	mov    r9b,BYTE PTR [rsi+r9*1]
  407554:	mov    BYTE PTR [r13+rcx*1+0x0],r9b
  407559:	inc    rcx
  40755c:	inc    rdx
  40755f:	mov    r9,QWORD PTR [r12+r8*8]
  407563:	cmp    rdx,r9
  407566:	jb     407540 <__swc_fn_23cea7fa_000003_3a24e5ea+0x220>
  407568:	cmp    rcx,0x100000
  40756f:	jge    4074d0 <__swc_fn_23cea7fa_000003_3a24e5ea+0x1b0>
  407575:	mov    BYTE PTR [r13+rcx*1+0x0],0x20
  40757b:	inc    rcx
  40757e:	jmp    4074d0 <__swc_fn_23cea7fa_000003_3a24e5ea+0x1b0>
  407583:	sub    rsp,0x8
  407587:	call   40eee0 <__swc_fn_23cea7fa_000002_1ca87929>
  40758c:	add    rsp,0x8
  407590:	vmovups xmm6,xmm0
  407594:	mov    ecx,0x80000
  407599:	sub    rsp,0x8
  40759d:	call   407270 <__swc_fn_23cea7fa_000000_2744b483>
  4075a2:	add    rsp,0x8
  4075a6:	mov    r14,rax
  4075a9:	mov    QWORD PTR [rsp+0x1e8],rax
  4075b1:	mov    ecx,0x40000
  4075b6:	sub    rsp,0x8
  4075ba:	call   407270 <__swc_fn_23cea7fa_000000_2744b483>
  4075bf:	add    rsp,0x8
  4075c3:	mov    r15,rax
  4075c6:	xor    eax,eax
  4075c8:	cs nop WORD PTR [rax+rax*1+0x0]
  4075d2:	cs nop WORD PTR [rax+rax*1+0x0]
  4075dc:	nop    DWORD PTR [rax+0x0]
  4075e0:	mov    QWORD PTR [r14+rax*8],0xffffffffffffffff
  4075e8:	add    rax,0x1
  4075ec:	cmp    rax,0x10000
  4075f3:	jb     4075e0 <__swc_fn_23cea7fa_000003_3a24e5ea+0x2c0>
  4075f5:	xor    eax,eax
  4075f7:	nop    WORD PTR [rax+rax*1+0x0]
  407600:	mov    QWORD PTR [r15+rax*8],0xffffffffffffffff
  407608:	add    rax,0x1
  40760c:	cmp    rax,0x8000
  407613:	jl     407600 <__swc_fn_23cea7fa_000003_3a24e5ea+0x2e0>
  407615:	mov    ecx,0x200010
  40761a:	sub    rsp,0x8
  40761e:	call   407270 <__swc_fn_23cea7fa_000000_2744b483>
  407623:	add    rsp,0x8
  407627:	mov    QWORD PTR [rsp+0x1f0],rax
  40762f:	xor    edi,edi
  407631:	xor    eax,eax
  407633:	vmovq  xmm0,rdi
  407638:	vmovsd xmm2,QWORD PTR [rsp+0x1f0]
  407641:	vmovsd xmm3,QWORD PTR [rsp+0x1e8]
  40764a:	nop    WORD PTR [rax+rax*1+0x0]
  407650:	lea    rcx,[rax+0x4]
  407654:	cmp    rcx,0x100000
  40765b:	jle    40766f <__swc_fn_23cea7fa_000003_3a24e5ea+0x34f>
  40765d:	mov    rsi,QWORD PTR [rsp+0x1f0]
  407665:	vmovq  rdi,xmm0
  40766a:	jmp    4078e1 <__swc_fn_23cea7fa_000003_3a24e5ea+0x5c1>
  40766f:	xor    ecx,ecx
  407671:	xor    edx,edx
  407673:	mov    r8d,0x100000
  407679:	sub    r8,rax
  40767c:	mov    r9,r8
  40767f:	cmp    r8,0x102
  407686:	mov    r8d,0x102
  40768c:	cmovge r9,r8
  407690:	movzx  r8d,BYTE PTR [r13+rax*1+0x0]
  407696:	imul   r8,r8,0x8c61
  40769d:	movzx  r10d,BYTE PTR [r13+rax*1+0x1]
  4076a3:	imul   r10,r10,0x441
  4076aa:	add    r8,r10
  4076ad:	movzx  r10d,BYTE PTR [r13+rax*1+0x2]
  4076b3:	movzx  r12d,BYTE PTR [r13+rax*1+0x3]
  4076b9:	add    r12,r10
  4076bc:	shl    r10,0x5
  4076c0:	add    r10,r12
  4076c3:	add    r8,r10
  4076c6:	movzx  r8d,r8w
  4076ca:	vmovq  xmm1,r8
  4076cf:	mov    r10,QWORD PTR [r14+r8*8]
  4076d3:	xor    r11d,r11d
  4076d6:	lea    r12,[r13+rax*1+0x0]
  4076db:	test   r10,r10
  4076de:	jl     4077cd <__swc_fn_23cea7fa_000003_3a24e5ea+0x4ad>
  4076e4:	cs nop WORD PTR [rax+rax*1+0x0]
  4076ee:	xchg   ax,ax
  4076f0:	mov    rsi,rax
  4076f3:	sub    rsi,r10
  4076f6:	cmp    rsi,0x8000
  4076fd:	jge    4077cd <__swc_fn_23cea7fa_000003_3a24e5ea+0x4ad>
  407703:	cmp    r11,0x20
  407707:	jge    4077cd <__swc_fn_23cea7fa_000003_3a24e5ea+0x4ad>
  40770d:	xor    edi,edi
  40770f:	lea    r8,[r13+r10*1+0x0]
  407714:	cmp    rdi,r9
  407717:	jge    4077a3 <__swc_fn_23cea7fa_000003_3a24e5ea+0x483>
  40771d:	cs nop WORD PTR [rax+rax*1+0x0]
  407727:	nop    WORD PTR [rax+rax*1+0x0]
  407730:	mov    r14,r9
  407733:	sub    r14,rdi
  407736:	cmp    r14,0x4
  40773a:	jb     407770 <__swc_fn_23cea7fa_000003_3a24e5ea+0x450>
  40773c:	mov    r14b,BYTE PTR [r12+rdi*1]
  407740:	cmp    BYTE PTR [r8+rdi*1],r14b
  407744:	jne    4077a3 <__swc_fn_23cea7fa_000003_3a24e5ea+0x483>
  407746:	mov    r14b,BYTE PTR [r12+rdi*1+0x1]
  40774b:	cmp    BYTE PTR [r8+rdi*1+0x1],r14b
  407750:	jne    407794 <__swc_fn_23cea7fa_000003_3a24e5ea+0x474>
  407752:	mov    r14b,BYTE PTR [r12+rdi*1+0x2]
  407757:	cmp    BYTE PTR [r8+rdi*1+0x2],r14b
  40775c:	jne    407799 <__swc_fn_23cea7fa_000003_3a24e5ea+0x479>
  40775e:	mov    r14b,BYTE PTR [r12+rdi*1+0x3]
  407763:	cmp    BYTE PTR [r8+rdi*1+0x3],r14b
  407768:	jne    40779f <__swc_fn_23cea7fa_000003_3a24e5ea+0x47f>
  40776a:	lea    rdi,[rdi+0x4]
  40776e:	jmp    407730 <__swc_fn_23cea7fa_000003_3a24e5ea+0x410>
  407770:	cmp    rdi,r9
  407773:	jge    4077a3 <__swc_fn_23cea7fa_000003_3a24e5ea+0x483>
  407775:	cs nop WORD PTR [rax+rax*1+0x0]
  40777f:	nop
  407780:	mov    r14b,BYTE PTR [r12+rdi*1]
  407784:	cmp    BYTE PTR [r8+rdi*1],r14b
  407788:	jne    4077a3 <__swc_fn_23cea7fa_000003_3a24e5ea+0x483>
  40778a:	inc    rdi
  40778d:	cmp    rdi,r9
  407790:	jl     407780 <__swc_fn_23cea7fa_000003_3a24e5ea+0x460>
  407792:	jmp    4077a3 <__swc_fn_23cea7fa_000003_3a24e5ea+0x483>
  407794:	inc    rdi
  407797:	jmp    4077a3 <__swc_fn_23cea7fa_000003_3a24e5ea+0x483>
  407799:	lea    rdi,[rdi+0x2]
  40779d:	jmp    4077a3 <__swc_fn_23cea7fa_000003_3a24e5ea+0x483>
  40779f:	lea    rdi,[rdi+0x3]
  4077a3:	cmp    rdi,rcx
  4077a6:	jle    4077b3 <__swc_fn_23cea7fa_000003_3a24e5ea+0x493>
  4077a8:	mov    rcx,rdi
  4077ab:	mov    rdx,rsi
  4077ae:	cmp    rdi,r9
  4077b1:	je     4077cd <__swc_fn_23cea7fa_000003_3a24e5ea+0x4ad>
  4077b3:	and    r10d,0x7fff
  4077ba:	mov    r8,QWORD PTR [r15+r10*8]
  4077be:	mov    r10,r8
  4077c1:	inc    r11
  4077c4:	test   r8,r8
  4077c7:	jge    4076f0 <__swc_fn_23cea7fa_000003_3a24e5ea+0x3d0>
  4077cd:	mov    r8d,eax
  4077d0:	and    r8d,0x7fff
  4077d7:	vmovq  r14,xmm3
  4077dc:	vmovq  r9,xmm1
  4077e1:	mov    r10,QWORD PTR [r14+r9*8]
  4077e5:	mov    QWORD PTR [r15+r8*8],r10
  4077e9:	mov    QWORD PTR [r14+r9*8],rax
  4077ed:	cmp    rcx,0x4
  4077f1:	jge    407802 <__swc_fn_23cea7fa_000003_3a24e5ea+0x4e2>
  4077f3:	vmovq  rsi,xmm2
  4077f8:	vmovq  rdi,xmm0
  4077fd:	jmp    4078c2 <__swc_fn_23cea7fa_000003_3a24e5ea+0x5a2>
  407802:	vmovq  rsi,xmm2
  407807:	vmovq  rdi,xmm0
  40780c:	mov    BYTE PTR [rsi+rdi*1],0x1
  407810:	lea    r8,[rcx-0x4]
  407814:	mov    BYTE PTR [rsi+rdi*1+0x1],r8b
  407819:	dec    rdx
  40781c:	mov    BYTE PTR [rsi+rdi*1+0x2],dl
  407820:	lea    r8,[rdx+0xff]
  407827:	test   rdx,rdx
  40782a:	cmovge r8,rdx
  40782e:	sar    r8,0x8
  407832:	mov    BYTE PTR [rsi+rdi*1+0x3],r8b
  407837:	lea    rdi,[rdi+0x4]
  40783b:	lea    rdx,[rax+0x1]
  40783f:	lea    r8,[rax+rcx*1]
  407843:	mov    r9,rdx
  407846:	cmp    rdx,r8
  407849:	jge    4078b5 <__swc_fn_23cea7fa_000003_3a24e5ea+0x595>
  40784b:	nop    DWORD PTR [rax+rax*1+0x0]
  407850:	lea    rdx,[r9+0x4]
  407854:	cmp    rdx,0x100000
  40785b:	jg     4078ac <__swc_fn_23cea7fa_000003_3a24e5ea+0x58c>
  40785d:	movzx  edx,BYTE PTR [r13+r9*1+0x0]
  407863:	imul   rdx,rdx,0x8c61
  40786a:	movzx  r10d,BYTE PTR [r13+r9*1+0x1]
  407870:	imul   r10,r10,0x441
  407877:	add    rdx,r10
  40787a:	movzx  r10d,BYTE PTR [r13+r9*1+0x2]
  407880:	movzx  r12d,BYTE PTR [r13+r9*1+0x3]
  407886:	add    r12,r10
  407889:	shl    r10,0x5
  40788d:	add    r10,r12
  407890:	add    rdx,r10
  407893:	movzx  edx,dx
  407896:	mov    r10d,r9d
  407899:	and    r10d,0x7fff
  4078a0:	mov    r11,QWORD PTR [r14+rdx*8]
  4078a4:	mov    QWORD PTR [r15+r10*8],r11
  4078a8:	mov    QWORD PTR [r14+rdx*8],r9
  4078ac:	add    r9,0x1
  4078b0:	cmp    r9,r8
  4078b3:	jl     407850 <__swc_fn_23cea7fa_000003_3a24e5ea+0x530>
  4078b5:	add    rax,rcx
  4078b8:	vmovq  xmm0,rdi
  4078bd:	jmp    407650 <__swc_fn_23cea7fa_000003_3a24e5ea+0x330>
  4078c2:	mov    BYTE PTR [rsi+rdi*1],0x0
  4078c6:	mov    cl,BYTE PTR [r13+rax*1+0x0]
  4078cb:	mov    BYTE PTR [rsi+rdi*1+0x1],cl
  4078cf:	lea    rdi,[rdi+0x2]
  4078d3:	add    rax,0x1
  4078d7:	vmovq  xmm0,rdi
  4078dc:	jmp    407650 <__swc_fn_23cea7fa_000003_3a24e5ea+0x330>
  4078e1:	cmp    rax,0x100000
  4078e8:	jge    40790e <__swc_fn_23cea7fa_000003_3a24e5ea+0x5ee>
  4078ea:	nop    WORD PTR [rax+rax*1+0x0]
  4078f0:	mov    BYTE PTR [rsi+rdi*1],0x0
  4078f4:	mov    cl,BYTE PTR [r13+rax*1+0x0]
  4078f9:	mov    BYTE PTR [rsi+rdi*1+0x1],cl
  4078fd:	lea    rdi,[rdi+0x2]
  407901:	add    rax,0x1
  407905:	cmp    rax,0x100000
  40790c:	jl     4078f0 <__swc_fn_23cea7fa_000003_3a24e5ea+0x5d0>
  40790e:	mov    ecx,0x100000
  407913:	sub    rsp,0x8
  407917:	call   407270 <__swc_fn_23cea7fa_000000_2744b483>
  40791c:	add    rsp,0x8
  407920:	mov    r12,rax
  407923:	xor    eax,eax
  407925:	xor    ecx,ecx
  407927:	nop    WORD PTR [rax+rax*1+0x0]
  407930:	cmp    rcx,rdi
  407933:	jge    40799d <__swc_fn_23cea7fa_000003_3a24e5ea+0x67d>
  407939:	cmp    BYTE PTR [rsi+rcx*1],0x0
  40793d:	jne    407950 <__swc_fn_23cea7fa_000003_3a24e5ea+0x630>
  40793f:	mov    dl,BYTE PTR [rsi+rcx*1+0x1]
  407943:	mov    BYTE PTR [r12+rax*1],dl
  407947:	inc    rax
  40794a:	lea    rcx,[rcx+0x2]
  40794e:	jmp    407930 <__swc_fn_23cea7fa_000003_3a24e5ea+0x610>
  407950:	movzx  edx,BYTE PTR [rsi+rcx*1+0x1]
  407955:	lea    rdx,[rdx+0x4]
  407959:	movzx  r8d,BYTE PTR [rsi+rcx*1+0x2]
  40795f:	movzx  r9d,BYTE PTR [rsi+rcx*1+0x3]
  407965:	shl    r9,0x8
  407969:	lea    r8,[r8+r9*1+0x1]
  40796e:	xor    r9d,r9d
  407971:	test   rdx,rdx
  407974:	jle    407994 <__swc_fn_23cea7fa_000003_3a24e5ea+0x674>
  407976:	mov    r10,r12
  407979:	sub    r10,r8
  40797c:	nop    DWORD PTR [rax+0x0]
  407980:	mov    r8b,BYTE PTR [r10+rax*1]
  407984:	mov    BYTE PTR [r12+rax*1],r8b
  407988:	inc    rax
  40798b:	add    r9,0x1
  40798f:	cmp    r9,rdx
  407992:	jl     407980 <__swc_fn_23cea7fa_000003_3a24e5ea+0x660>
  407994:	lea    rcx,[rcx+0x4]
  407998:	jmp    407930 <__swc_fn_23cea7fa_000003_3a24e5ea+0x610>
  40799d:	cmp    rax,0x100000
  4079a4:	sete   al
  4079a7:	xor    ecx,ecx
  4079a9:	test   al,al
  4079ab:	je     4079cd <__swc_fn_23cea7fa_000003_3a24e5ea+0x6ad>
  4079ad:	nop    DWORD PTR [rax]
  4079b0:	cmp    rcx,0x100000
  4079b7:	jge    4079cd <__swc_fn_23cea7fa_000003_3a24e5ea+0x6ad>
  4079b9:	mov    dl,BYTE PTR [r13+rcx*1+0x0]
  4079be:	cmp    BYTE PTR [r12+rcx*1],dl
  4079c2:	je     4079c6 <__swc_fn_23cea7fa_000003_3a24e5ea+0x6a6>
  4079c4:	xor    eax,eax
  4079c6:	inc    rcx
  4079c9:	test   al,al
  4079cb:	jne    4079b0 <__swc_fn_23cea7fa_000003_3a24e5ea+0x690>
  4079cd:	xor    ecx,ecx
  4079cf:	xor    edx,edx
  4079d1:	test   rdi,rdi
  4079d4:	jle    407a10 <__swc_fn_23cea7fa_000003_3a24e5ea+0x6f0>
  4079d6:	cs nop WORD PTR [rax+rax*1+0x0]
  4079e0:	imul   rcx,rcx,0x1f
  4079e4:	movzx  r8d,BYTE PTR [rsi+rdx*1]
  4079e9:	add    rcx,r8
  4079ec:	mov    r8,rcx
  4079ef:	imul   rcx,rcx,0x218de8b
  4079f6:	shr    rcx,0x2d
  4079fa:	imul   rcx,rcx,0xf4243
  407a01:	sub    r8,rcx
  407a04:	mov    rcx,r8
  407a07:	add    rdx,0x1
  407a0b:	cmp    rdx,rdi
  407a0e:	jl     4079e0 <__swc_fn_23cea7fa_000003_3a24e5ea+0x6c0>
  407a10:	imul   rdi,rdi,0xf4243
  407a17:	add    rdi,rcx
  407a1a:	test   al,al
  407a1c:	mov    eax,0x0
  407a21:	cmove  rdi,rax
  407a25:	sub    rsp,0x8
  407a29:	call   40eee0 <__swc_fn_23cea7fa_000002_1ca87929>
  407a2e:	add    rsp,0x8
  407a32:	vsubsd xmm0,xmm0,xmm6
  407a36:	vmulsd xmm0,xmm0,QWORD PTR [rip+0xb7ea]        # 413228 <__swc_rdata_base_23cea7fa+0x118>
  407a3e:	lea    rax,[rip+0xb6db]        # 413120 <__swc_rdata_base_23cea7fa+0x10>
  407a45:	sub    rsp,0x90
  407a4c:	mov    rcx,rsp
  407a4f:	vmovups xmm1,XMMWORD PTR [rip+0xb7b1]        # 413208 <__swc_rdata_base_23cea7fa+0xf8>
  407a57:	vmovups XMMWORD PTR [rcx],xmm1
  407a5b:	mov    QWORD PTR [rcx+0x30],rsp
  407a5f:	lea    rdx,[rip+0xb6ca]        # 413130 <__swc_rdata_base_23cea7fa+0x20>
  407a66:	mov    QWORD PTR [rcx+0x38],rdx
  407a6a:	mov    QWORD PTR [rcx+0x10],rdi
  407a6e:	lea    r8,[rsp+0x10]
  407a73:	mov    QWORD PTR [rcx+0x40],r8
  407a77:	lea    r8,[rip+0xb6fa]        # 413178 <__swc_rdata_base_23cea7fa+0x68>
  407a7e:	mov    QWORD PTR [rcx+0x48],r8
  407a82:	vmovups xmm1,XMMWORD PTR [rip+0xb78e]        # 413218 <__swc_rdata_base_23cea7fa+0x108>
  407a8a:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  407a8f:	lea    r8,[rsp+0x18]
  407a94:	mov    QWORD PTR [rcx+0x50],r8
  407a98:	mov    QWORD PTR [rcx+0x58],rdx
  407a9c:	vmovsd QWORD PTR [rcx+0x28],xmm0
  407aa1:	lea    r8,[rcx+0x28]
  407aa5:	mov    QWORD PTR [rcx+0x60],r8
  407aa9:	lea    r8,[rip+0xb710]        # 4131c0 <__swc_rdata_base_23cea7fa+0xb0>
  407ab0:	mov    QWORD PTR [rcx+0x68],r8
  407ab4:	mov    QWORD PTR [rcx+0x70],rax
  407ab8:	mov    QWORD PTR [rcx+0x78],rdx
  407abc:	lea    rax,[rcx+0x30]
  407ac0:	mov    QWORD PTR [rcx+0x80],rax
  407ac7:	mov    QWORD PTR [rcx+0x88],0x5
  407ad2:	lea    rcx,[rcx+0x80]
  407ad9:	sub    rsp,0x8
  407add:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  407ae2:	add    rsp,0x8
  407ae6:	add    rsp,0x90
  407aed:	mov    rcx,r12
  407af0:	sub    rsp,0x8
  407af4:	call   40bd80 <__swc_fn_23cea7fa_000001_5d3d19bd>
  407af9:	add    rsp,0x8
  407afd:	mov    rcx,rsi
  407b00:	sub    rsp,0x8
  407b04:	call   40bd80 <__swc_fn_23cea7fa_000001_5d3d19bd>
  407b09:	add    rsp,0x8
  407b0d:	mov    rcx,r15
  407b10:	sub    rsp,0x8
  407b14:	call   40bd80 <__swc_fn_23cea7fa_000001_5d3d19bd>
  407b19:	add    rsp,0x8
  407b1d:	mov    rcx,r14
  407b20:	sub    rsp,0x8
  407b24:	call   40bd80 <__swc_fn_23cea7fa_000001_5d3d19bd>
  407b29:	add    rsp,0x8
  407b2d:	mov    rcx,r13
  407b30:	sub    rsp,0x8
  407b34:	call   40bd80 <__swc_fn_23cea7fa_000001_5d3d19bd>
  407b39:	add    rsp,0x8
  407b3d:	mov    r12,QWORD PTR [rsp+0x1e0]
  407b45:	mov    rcx,r12
  407b48:	sub    rsp,0x8
  407b4c:	call   40bd80 <__swc_fn_23cea7fa_000001_5d3d19bd>
  407b51:	add    rsp,0x8
  407b55:	mov    rdi,QWORD PTR [rsp+0x1d8]
  407b5d:	mov    rcx,rdi
  407b60:	sub    rsp,0x8
  407b64:	call   40bd80 <__swc_fn_23cea7fa_000001_5d3d19bd>
  407b69:	add    rsp,0x8
  407b6d:	mov    rsi,QWORD PTR [rsp+0x1d0]
  407b75:	mov    rcx,rsi
  407b78:	sub    rsp,0x8
  407b7c:	call   40bd80 <__swc_fn_23cea7fa_000001_5d3d19bd>
  407b81:	add    rsp,0x218
  407b88:	vmovups xmm6,XMMWORD PTR [rsp]
  407b8d:	add    rsp,0x18
  407b91:	pop    r14
  407b93:	pop    r15
  407b95:	pop    r13
  407b97:	pop    r12
  407b99:	pop    rdi
  407b9a:	pop    rsi
  407b9b:	pop    rbp
  407b9c:	ret
  407b9d:	add    BYTE PTR [rax],al
	...

0000000000407ba0 <__swc_fn_23cea7fa_000006_81d2e1e9>:
  407ba0:	sub    rsp,0x8
  407ba4:	call   4111a0 <__swc_fn_23cea7fa_000113_6b799b8d>
  407ba9:	mov    rcx,rax
  407bac:	test   rax,rax
  407baf:	je     407bd6 <__swc_fn_23cea7fa_000006_81d2e1e9+0x36>
  407bb1:	lea    rdx,[rip+0x1c490]        # 424048 <__swc_bss_base_23cea7fa+0x8>
  407bb8:	mov    r8,QWORD PTR [rip+0x1c489]        # 424048 <__swc_bss_base_23cea7fa+0x8>
  407bbf:	nop
  407bc0:	lea    r9,[r8+0x1]
  407bc4:	mov    rax,r8
  407bc7:	lock cmpxchg QWORD PTR [rdx],r9
  407bcc:	cmp    rax,r8
  407bcf:	je     407bd6 <__swc_fn_23cea7fa_000006_81d2e1e9+0x36>
  407bd1:	mov    r8,rax
  407bd4:	jmp    407bc0 <__swc_fn_23cea7fa_000006_81d2e1e9+0x20>
  407bd6:	mov    rax,rcx
  407bd9:	add    rsp,0x8
  407bdd:	ret
	...

0000000000407be0 <__swc_fn_23cea7fa_000009_065ed5b1>:
  407be0:	mov    r8d,edx
  407be3:	xor    eax,eax
  407be5:	tzcnt  eax,edx
  407be9:	shrx   r9d,edx,eax
  407bee:	mov    DWORD PTR [rcx+0x2c],edx
  407bf1:	xor    eax,eax
  407bf3:	tzcnt  eax,edx
  407bf7:	mov    BYTE PTR [rcx+0x38],al
  407bfa:	mov    eax,0xffffffff
  407bff:	xor    edx,edx
  407c01:	div    r8d
  407c04:	mov    DWORD PTR [rcx+0x34],eax
  407c07:	mov    eax,r9d
  407c0a:	mov    edx,r9d
  407c0d:	imul   edx,r9d
  407c11:	mov    r8d,0x2
  407c17:	sub    r8d,edx
  407c1a:	imul   eax,r8d
  407c1e:	mov    edx,r9d
  407c21:	imul   edx,eax
  407c24:	mov    r8d,0x2
  407c2a:	sub    r8d,edx
  407c2d:	imul   eax,r8d
  407c31:	mov    edx,r9d
  407c34:	imul   edx,eax
  407c37:	mov    r8d,0x2
  407c3d:	sub    r8d,edx
  407c40:	imul   eax,r8d
  407c44:	mov    edx,r9d
  407c47:	imul   edx,eax
  407c4a:	mov    r8d,0x2
  407c50:	sub    r8d,edx
  407c53:	imul   eax,r8d
  407c57:	imul   r9d,eax
  407c5b:	mov    edx,0x2
  407c60:	sub    edx,r9d
  407c63:	imul   eax,edx
  407c66:	mov    DWORD PTR [rcx+0x30],eax
  407c69:	ret
  407c6a:	add    BYTE PTR [rax],al
  407c6c:	add    BYTE PTR [rax],al
	...

0000000000407c70 <__swc_fn_23cea7fa_000012_861b8b62>:
  407c70:	xor    eax,eax
  407c72:	mov    DWORD PTR [rcx+0x68],eax
  407c75:	ret
	...

0000000000407c80 <__swc_fn_23cea7fa_000015_9dea5065>:
  407c80:	mov    eax,DWORD PTR [rcx+0x28]
  407c83:	shlx   eax,edx,eax
  407c88:	shl    rax,0x10
  407c8c:	lea    rdx,[rcx+rax*1]
  407c90:	lea    rax,[rcx+0x3000]
  407c97:	cmp    rdx,rax
  407c9a:	cmovae rax,rdx
  407c9e:	ret
	...

0000000000407ca0 <__swc_fn_23cea7fa_000018_283e2b5e>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	push   r13
  407ca6:	push   r14
  407ca8:	mov    rsi,rdx
  407cab:	mov    rdi,rcx
  407cae:	rex mov dl,BYTE PTR [rsi+0x3a]
  407cb2:	mov    ecx,DWORD PTR [rdi+0x28]
  407cb5:	shr    dl,cl
  407cb7:	mov    r12d,0x1
  407cbd:	mov    ecx,edx
  407cbf:	shl    r12,cl
  407cc2:	mov    r13d,DWORD PTR [rsi+0x3c]
  407cc6:	rex mov BYTE PTR [rsi+0x3b],0x0
  407ccb:	mov    QWORD PTR [rsi+0x40],0x0
  407cd3:	mov    QWORD PTR [rsi],0x0
  407cda:	mov    rax,QWORD PTR [rsi+0x10]
  407cde:	mov    QWORD PTR [rsi+0x20],rax
  407ce2:	lea    r14,[rip+0x1c367]        # 424050 <__swc_bss_base_23cea7fa+0x10>
  407ce9:	mov    rax,QWORD PTR [r14]
  407cec:	shr    rax,0x2
  407cf0:	mov    rcx,rax
  407cf3:	cmp    rax,0x800000
  407cfa:	mov    eax,0x800000
  407cff:	cmovb  rcx,rax
  407d03:	lea    r8,[rip+0x1c356]        # 424060 <__swc_bss_base_23cea7fa+0x20>
  407d0a:	mov    rax,QWORD PTR [r8]
  407d0d:	mov    r9,rax
  407d10:	lea    r10,[r9+r13*1]
  407d14:	cmp    r10,rcx
  407d17:	ja     407d3b <__swc_fn_23cea7fa_000018_283e2b5e+0x9b>
  407d19:	mov    rax,r9
  407d1c:	lock cmpxchg QWORD PTR [r8],r10
  407d21:	cmp    rax,r9
  407d24:	je     407d2b <__swc_fn_23cea7fa_000018_283e2b5e+0x8b>
  407d26:	mov    r9,rax
  407d29:	jmp    407d10 <__swc_fn_23cea7fa_000018_283e2b5e+0x70>
  407d2b:	mov    rcx,rdi
  407d2e:	mov    rdx,r12
  407d31:	call   40f2d0 <__swc_fn_23cea7fa_000020_de02dbdf>
  407d36:	jmp    407dbd <__swc_fn_23cea7fa_000018_283e2b5e+0x11d>
  407d3b:	mov    rcx,rdi
  407d3e:	movzx  edx,dl
  407d41:	call   407c80 <__swc_fn_23cea7fa_000015_9dea5065>
  407d46:	test   r13,r13
  407d49:	je     407db6 <__swc_fn_23cea7fa_000018_283e2b5e+0x116>
  407d4f:	mov    rcx,rax
  407d52:	mov    rdx,r13
  407d55:	call   411320 <__swc_fn_23cea7fa_000116_e9fc0224>
  407d5a:	mov    rcx,QWORD PTR [rip+0x1c2ef]        # 424050 <__swc_bss_base_23cea7fa+0x10>
  407d61:	cs nop WORD PTR [rax+rax*1+0x0]
  407d6b:	nop    DWORD PTR [rax+rax*1+0x0]
  407d70:	mov    rdx,rcx
  407d73:	sub    rdx,r13
  407d76:	mov    rax,rcx
  407d79:	lock cmpxchg QWORD PTR [r14],rdx
  407d7e:	cmp    rax,rcx
  407d81:	je     407d88 <__swc_fn_23cea7fa_000018_283e2b5e+0xe8>
  407d83:	mov    rcx,rax
  407d86:	jmp    407d70 <__swc_fn_23cea7fa_000018_283e2b5e+0xd0>
  407d88:	lea    rcx,[rip+0x1c2d9]        # 424068 <__swc_bss_base_23cea7fa+0x28>
  407d8f:	mov    rdx,QWORD PTR [rip+0x1c2d2]        # 424068 <__swc_bss_base_23cea7fa+0x28>
  407d96:	cs nop WORD PTR [rax+rax*1+0x0]
  407da0:	lea    r8,[rdx+0x1]
  407da4:	mov    rax,rdx
  407da7:	lock cmpxchg QWORD PTR [rcx],r8
  407dac:	cmp    rax,rdx
  407daf:	je     407db6 <__swc_fn_23cea7fa_000018_283e2b5e+0x116>
  407db1:	mov    rdx,rax
  407db4:	jmp    407da0 <__swc_fn_23cea7fa_000018_283e2b5e+0x100>
  407db6:	mov    DWORD PTR [rsi+0x3c],0x0
  407dbd:	mov    rcx,rdi
  407dc0:	mov    rdx,r12
  407dc3:	call   40c190 <__swc_fn_23cea7fa_000022_c8f5f27c>
  407dc8:	pop    r14
  407dca:	pop    r13
  407dcc:	pop    r12
  407dce:	pop    rdi
  407dcf:	pop    rsi
  407dd0:	ret
	...

0000000000407de0 <__swc_fn_23cea7fa_000021_fd2b165c>:
  407de0:	mov    r8,QWORD PTR [rcx+0x48]
  407de4:	test   r8,rdx
  407de7:	je     407e18 <__swc_fn_23cea7fa_000021_fd2b165c+0x38>
  407de9:	nop    DWORD PTR [rax+0x0]
  407df0:	mov    rax,rdx
  407df3:	not    rax
  407df6:	mov    r9,r8
  407df9:	and    r9,rax
  407dfc:	mov    rax,r8
  407dff:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  407e05:	cmp    rax,r8
  407e08:	jne    407e10 <__swc_fn_23cea7fa_000021_fd2b165c+0x30>
  407e0a:	mov    eax,0x1
  407e0f:	ret
  407e10:	mov    r8,rax
  407e13:	test   rax,rdx
  407e16:	jne    407df0 <__swc_fn_23cea7fa_000021_fd2b165c+0x10>
  407e18:	xor    eax,eax
  407e1a:	ret
  407e1b:	add    BYTE PTR [rax],al
  407e1d:	add    BYTE PTR [rax],al
	...

0000000000407e20 <__swc_fn_23cea7fa_000024_2685aade>:
  407e20:	push   rsi
  407e21:	push   rdi
  407e22:	push   r12
  407e24:	push   r13
  407e26:	sub    rsp,0x8
  407e2a:	mov    rsi,rdx
  407e2d:	mov    rdi,rcx
  407e30:	lea    r12,[rip+0x1c3c1]        # 4241f8 <__swc_bss_base_23cea7fa+0x1b8>
  407e37:	mov    rcx,r12
  407e3a:	call   40e420 <__swc_fn_23cea7fa_000139_86bb0f90>
  407e3f:	xor    eax,eax
  407e41:	mov    rcx,QWORD PTR [rip+0x1c3b8]        # 424200 <__swc_bss_base_23cea7fa+0x1c0>
  407e48:	mov    r13,rcx
  407e4b:	test   r13,r13
  407e4e:	je     407e9b <__swc_fn_23cea7fa_000024_2685aade+0x7b>
  407e50:	mov    rcx,QWORD PTR [r13+0x10]
  407e54:	cmp    DWORD PTR [r13+0x28],esi
  407e58:	jne    407e90 <__swc_fn_23cea7fa_000024_2685aade+0x70>
  407e5a:	test   rax,rax
  407e5d:	jne    407e68 <__swc_fn_23cea7fa_000024_2685aade+0x48>
  407e5f:	mov    QWORD PTR [rip+0x1c39a],rcx        # 424200 <__swc_bss_base_23cea7fa+0x1c0>
  407e66:	jmp    407e6c <__swc_fn_23cea7fa_000024_2685aade+0x4c>
  407e68:	mov    QWORD PTR [rax+0x10],rcx
  407e6c:	vxorps xmm0,xmm0,xmm0
  407e70:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407e76:	mov    QWORD PTR [r13+0x8],rdi
  407e7a:	mov    rcx,r12
  407e7d:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  407e82:	mov    rax,r13
  407e85:	add    rsp,0x8
  407e89:	pop    r13
  407e8b:	pop    r12
  407e8d:	pop    rdi
  407e8e:	pop    rsi
  407e8f:	ret
  407e90:	mov    rax,r13
  407e93:	mov    r13,rcx
  407e96:	test   rcx,rcx
  407e99:	jne    407e50 <__swc_fn_23cea7fa_000024_2685aade+0x30>
  407e9b:	mov    ecx,esi
  407e9d:	call   40f300 <__swc_fn_23cea7fa_000023_2d0fcd2c>
  407ea2:	mov    rsi,rax
  407ea5:	test   rax,rax
  407ea8:	jne    407ebf <__swc_fn_23cea7fa_000024_2685aade+0x9f>
  407eaa:	mov    rcx,r12
  407ead:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  407eb2:	xor    eax,eax
  407eb4:	add    rsp,0x8
  407eb8:	pop    r13
  407eba:	pop    r12
  407ebc:	pop    rdi
  407ebd:	pop    rsi
  407ebe:	ret
  407ebf:	mov    QWORD PTR [rsi+0x8],rdi
  407ec3:	mov    rcx,r12
  407ec6:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  407ecb:	mov    rax,rsi
  407ece:	add    rsp,0x8
  407ed2:	pop    r13
  407ed4:	pop    r12
  407ed6:	pop    rdi
  407ed7:	pop    rsi
  407ed8:	ret
  407ed9:	add    BYTE PTR [rax],al
  407edb:	add    BYTE PTR [rax],al
  407edd:	add    BYTE PTR [rax],al
	...

0000000000407ee0 <__swc_fn_23cea7fa_000027_9798fb47>:
  407ee0:	vxorps xmm0,xmm0,xmm0
  407ee4:	xor    eax,eax
  407ee6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ef0:	cs nop WORD PTR [rax+rax*1+0x0]
  407efa:	nop    WORD PTR [rax+rax*1+0x0]
  407f00:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  407f05:	add    rax,0x10
  407f09:	cmp    rax,0x2b00
  407f10:	jne    407f00 <__swc_fn_23cea7fa_000027_9798fb47+0x20>
  407f12:	ret
	...

0000000000407f20 <__swc_fn_23cea7fa_000030_9798fb47>:
  407f20:	vxorps xmm0,xmm0,xmm0
  407f24:	vmovups XMMWORD PTR [rcx],xmm0
  407f28:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  407f2d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407f32:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407f37:	ret
	...

0000000000407f40 <__swc_fn_23cea7fa_000033_9798fb47>:
  407f40:	vxorps xmm0,xmm0,xmm0
  407f44:	vmovups XMMWORD PTR [rcx],xmm0
  407f48:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  407f4d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407f52:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407f57:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  407f5c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407f61:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407f66:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  407f6b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  407f73:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  407f7b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  407f83:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  407f8b:	mov    QWORD PTR [rcx+0xc0],0x0
  407f96:	ret
	...

0000000000407fa0 <__swc_fn_23cea7fa_000036_92d9bbff>:
  407fa0:	push   rsi
  407fa1:	push   rdi
  407fa2:	sub    rsp,0x8
  407fa6:	mov    rsi,rcx
  407fa9:	lea    rdi,[rip+0x1a058]        # 422008 <__swc_data_base_23cea7fa+0x8>
  407fb0:	mov    rax,QWORD PTR [rdi]
  407fb3:	cmp    rax,0xffffffffffffffff
  407fb7:	je     407fbe <__swc_fn_23cea7fa_000036_92d9bbff+0x1e>
  407fb9:	mov    rdi,rax
  407fbc:	jmp    407feb <__swc_fn_23cea7fa_000036_92d9bbff+0x4b>
  407fbe:	call   40e100 <__swc_fn_23cea7fa_000127_58f0f391>
  407fc3:	mov    rcx,rax
  407fc6:	cmp    rax,0xffffffffffffffff
  407fca:	je     407ffc <__swc_fn_23cea7fa_000036_92d9bbff+0x5c>
  407fcc:	mov    rax,0xffffffffffffffff
  407fd3:	lock cmpxchg QWORD PTR [rdi],rcx
  407fd8:	cmp    rax,0xffffffffffffffff
  407fdc:	je     407fe8 <__swc_fn_23cea7fa_000036_92d9bbff+0x48>
  407fde:	mov    rdi,rax
  407fe1:	call   4116f0 <__swc_fn_23cea7fa_000128_a481cb88>
  407fe6:	jmp    407feb <__swc_fn_23cea7fa_000036_92d9bbff+0x4b>
  407fe8:	mov    rdi,rcx
  407feb:	cmp    rdi,0xffffffffffffffff
  407fef:	je     407ffc <__swc_fn_23cea7fa_000036_92d9bbff+0x5c>
  407ff1:	mov    rcx,rdi
  407ff4:	mov    rdx,rsi
  407ff7:	call   40a0b0 <__swc_fn_23cea7fa_000129_4bbe3f14>
  407ffc:	add    rsp,0x8
  408000:	pop    rdi
  408001:	pop    rsi
  408002:	ret
	...

0000000000408010 <__swc_fn_23cea7fa_000039_03f1bf9a>:
  408010:	sub    rsp,0x38
  408014:	mov    rax,rdx
  408017:	test   dl,dl
  408019:	jne    408031 <__swc_fn_23cea7fa_000039_03f1bf9a+0x21>
  40801b:	mov    rax,r8
  40801e:	test   r8b,r8b
  408021:	cmove  eax,r9d
  408025:	test   al,al
  408027:	cmove  eax,r10d
  40802b:	test   al,al
  40802d:	cmove  eax,r11d
  408031:	test   al,al
  408033:	jne    40803a <__swc_fn_23cea7fa_000039_03f1bf9a+0x2a>
  408035:	add    rsp,0x38
  408039:	ret
  40803a:	lea    rcx,[rip+0xb1f7]        # 413238 <__swc_rdata_base_23cea7fa+0x128>
  408041:	vmovups xmm0,XMMWORD PTR [rip+0xb1ff]        # 413248 <__swc_rdata_base_23cea7fa+0x138>
  408049:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40804f:	vmovups xmm0,XMMWORD PTR [rip+0xb201]        # 413258 <__swc_rdata_base_23cea7fa+0x148>
  408057:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40805d:	vmovups xmm0,XMMWORD PTR [rip+0xb203]        # 413268 <__swc_rdata_base_23cea7fa+0x158>
  408065:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40806b:	lea    rdx,[rsp+0x8]
  408070:	call   410f20 <__swc_fn_23cea7fa_000107_90faaa26>
  408075:	jmp    408035 <__swc_fn_23cea7fa_000039_03f1bf9a+0x25>
	...

0000000000408080 <__swc_fn_23cea7fa_000042_facd3e17>:
  408080:	sub    rsp,0x8
  408084:	mov    eax,0x1000
  408089:	test   eax,eax
  40808b:	mov    r8d,0x8
  408091:	cmove  eax,r8d
  408095:	dec    rax
  408098:	mov    r8,0xffffffffffffffff
  40809f:	sub    r8,rax
  4080a2:	cmp    rdx,r8
  4080a5:	ja     4080b5 <__swc_fn_23cea7fa_000042_facd3e17+0x35>
  4080a7:	add    rdx,rax
  4080aa:	not    rax
  4080ad:	mov    r8,rdx
  4080b0:	and    r8,rax
  4080b3:	jne    4080bc <__swc_fn_23cea7fa_000042_facd3e17+0x3c>
  4080b5:	xor    eax,eax
  4080b7:	add    rsp,0x8
  4080bb:	ret
  4080bc:	mov    rdx,r8
  4080bf:	call   40f620 <__swc_fn_23cea7fa_000041_c90d80c1>
  4080c4:	add    rsp,0x8
  4080c8:	ret
  4080c9:	add    BYTE PTR [rax],al
  4080cb:	add    BYTE PTR [rax],al
  4080cd:	add    BYTE PTR [rax],al
	...

00000000004080d0 <__swc_fn_23cea7fa_000045_d8bd27c3>:
  4080d0:	push   rsi
  4080d1:	push   rdi
  4080d2:	sub    rsp,0x8
  4080d6:	mov    rsi,rdx
  4080d9:	mov    rdi,rcx
  4080dc:	test   rdx,rdx
  4080df:	je     4080fb <__swc_fn_23cea7fa_000045_d8bd27c3+0x2b>
  4080e1:	xor    ecx,ecx
  4080e3:	call   40c2b0 <__swc_fn_23cea7fa_000037_28d0e998>
  4080e8:	mov    rax,QWORD PTR [rsi]
  4080eb:	test   rax,rax
  4080ee:	je     4080fb <__swc_fn_23cea7fa_000045_d8bd27c3+0x2b>
  4080f0:	mov    rcx,rax
  4080f3:	mov    rdx,rsi
  4080f6:	call   40c3c0 <__swc_fn_23cea7fa_000046_b30433d0>
  4080fb:	mov    rcx,rdi
  4080fe:	call   40f680 <__swc_fn_23cea7fa_000044_a78ae66b>
  408103:	mov    rsi,rax
  408106:	test   rax,rax
  408109:	jne    408114 <__swc_fn_23cea7fa_000045_d8bd27c3+0x44>
  40810b:	xor    eax,eax
  40810d:	add    rsp,0x8
  408111:	pop    rdi
  408112:	pop    rsi
  408113:	ret
  408114:	mov    rcx,rsi
  408117:	call   40c2b0 <__swc_fn_23cea7fa_000037_28d0e998>
  40811c:	mov    rax,rsi
  40811f:	add    rsp,0x8
  408123:	pop    rdi
  408124:	pop    rsi
  408125:	ret
	...

0000000000408130 <__swc_fn_23cea7fa_000048_137687bb>:
  408130:	movzx  eax,BYTE PTR [r8+0x39]
  408135:	lea    rax,[rax+rax*4]
  408139:	lea    rax,[rdx+rax*8+0x28]
  40813e:	mov    ecx,DWORD PTR [r8+0x6c]
  408142:	test   ecx,ecx
  408144:	je     40817d <__swc_fn_23cea7fa_000048_137687bb+0x4d>
  408146:	mov    rcx,QWORD PTR [r8+0x50]
  40814a:	test   rcx,rcx
  40814d:	je     408159 <__swc_fn_23cea7fa_000048_137687bb+0x29>
  40814f:	mov    rax,QWORD PTR [r8+0x48]
  408153:	mov    QWORD PTR [rcx+0x48],rax
  408157:	jmp    408161 <__swc_fn_23cea7fa_000048_137687bb+0x31>
  408159:	mov    rcx,QWORD PTR [r8+0x48]
  40815d:	mov    QWORD PTR [rax+0x18],rcx
  408161:	mov    rax,QWORD PTR [r8+0x48]
  408165:	test   rax,rax
  408168:	je     408172 <__swc_fn_23cea7fa_000048_137687bb+0x42>
  40816a:	mov    rcx,QWORD PTR [r8+0x50]
  40816e:	mov    QWORD PTR [rax+0x50],rcx
  408172:	vxorps xmm0,xmm0,xmm0
  408176:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40817c:	ret
  40817d:	mov    rcx,QWORD PTR [r8+0x50]
  408181:	test   rcx,rcx
  408184:	je     408190 <__swc_fn_23cea7fa_000048_137687bb+0x60>
  408186:	mov    rdx,QWORD PTR [r8+0x48]
  40818a:	mov    QWORD PTR [rcx+0x48],rdx
  40818e:	jmp    408198 <__swc_fn_23cea7fa_000048_137687bb+0x68>
  408190:	mov    rcx,QWORD PTR [r8+0x48]
  408194:	mov    QWORD PTR [rax+0x8],rcx
  408198:	mov    rcx,QWORD PTR [r8+0x48]
  40819c:	test   rcx,rcx
  40819f:	je     4081ab <__swc_fn_23cea7fa_000048_137687bb+0x7b>
  4081a1:	mov    rdx,QWORD PTR [r8+0x50]
  4081a5:	mov    QWORD PTR [rcx+0x50],rdx
  4081a9:	jmp    4081b3 <__swc_fn_23cea7fa_000048_137687bb+0x83>
  4081ab:	mov    rcx,QWORD PTR [r8+0x50]
  4081af:	mov    QWORD PTR [rax+0x10],rcx
  4081b3:	cmp    QWORD PTR [rax],r8
  4081b6:	jne    4081bf <__swc_fn_23cea7fa_000048_137687bb+0x8f>
  4081b8:	mov    QWORD PTR [rax],0x0
  4081bf:	vxorps xmm0,xmm0,xmm0
  4081c3:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  4081c9:	ret
  4081ca:	add    BYTE PTR [rax],al
  4081cc:	add    BYTE PTR [rax],al
	...

00000000004081d0 <__swc_fn_23cea7fa_000051_e072b516>:
  4081d0:	sub    rsp,0x8
  4081d4:	mov    r9,r8
  4081d7:	mov    r10,rdx
  4081da:	call   408130 <__swc_fn_23cea7fa_000048_137687bb>
  4081df:	mov    DWORD PTR [r9+0x6c],0x0
  4081e7:	movzx  eax,BYTE PTR [r9+0x39]
  4081ec:	lea    rax,[rax+rax*4]
  4081f0:	lea    rax,[r10+rax*8+0x28]
  4081f5:	mov    rcx,QWORD PTR [rax+0x10]
  4081f9:	mov    QWORD PTR [r9+0x50],rcx
  4081fd:	mov    QWORD PTR [r9+0x48],0x0
  408205:	mov    rcx,QWORD PTR [rax+0x10]
  408209:	test   rcx,rcx
  40820c:	je     408214 <__swc_fn_23cea7fa_000051_e072b516+0x44>
  40820e:	mov    QWORD PTR [rcx+0x48],r9
  408212:	jmp    408218 <__swc_fn_23cea7fa_000051_e072b516+0x48>
  408214:	mov    QWORD PTR [rax+0x8],r9
  408218:	mov    QWORD PTR [rax+0x10],r9
  40821c:	add    rsp,0x8
  408220:	ret
	...

0000000000408240 <__swc_fn_23cea7fa_000054_faa92dcc>:
  408240:	push   rsi
  408241:	push   rdi
  408242:	push   r12
  408244:	push   r13
  408246:	push   r14
  408248:	push   r15
  40824a:	sub    rsp,0x1f8
  408251:	mov    esi,r8d
  408254:	mov    QWORD PTR [rsp+0x1e8],rsi
  40825c:	mov    rdi,rcx
  40825f:	mov    r12,rdx
  408262:	lea    r13,[rsi+rsi*4]
  408266:	lea    r13,[rdx+r13*8+0x28]
  40826b:	call   40c820 <__swc_fn_23cea7fa_000052_d846b172>
  408270:	add    DWORD PTR [r12+0x24],0x1
  408276:	test   BYTE PTR [r12+0x24],0x3f
  40827c:	jne    408286 <__swc_fn_23cea7fa_000054_faa92dcc+0x46>
  40827e:	mov    rcx,rdi
  408281:	call   40f800 <__swc_fn_23cea7fa_000053_3af34d7f>
  408286:	mov    rax,QWORD PTR [r13+0x8]
  40828a:	mov    r14,rax
  40828d:	nop    DWORD PTR [rax]
  408290:	test   r14,r14
  408293:	jne    4082a2 <__swc_fn_23cea7fa_000054_faa92dcc+0x62>
  408295:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40829d:	jmp    4083a9 <__swc_fn_23cea7fa_000054_faa92dcc+0x169>
  4082a2:	mov    r15,QWORD PTR [r14+0x48]
  4082a6:	mov    rcx,r14
  4082a9:	call   40bf80 <__swc_fn_23cea7fa_000013_e4b0ddfc>
  4082ae:	mov    rax,QWORD PTR [r14]
  4082b1:	test   rax,rax
  4082b4:	je     4082c6 <__swc_fn_23cea7fa_000054_faa92dcc+0x86>
  4082b6:	mov    rcx,QWORD PTR [rax]
  4082b9:	mov    QWORD PTR [r14],rcx
  4082bc:	add    DWORD PTR [r14+0x28],0x1
  4082c1:	mov    rsi,rax
  4082c4:	jmp    4082e5 <__swc_fn_23cea7fa_000054_faa92dcc+0xa5>
  4082c6:	mov    rax,QWORD PTR [r14+0x18]
  4082ca:	cmp    QWORD PTR [r14+0x20],rax
  4082ce:	jae    4082e3 <__swc_fn_23cea7fa_000054_faa92dcc+0xa3>
  4082d0:	mov    rsi,QWORD PTR [r14+0x20]
  4082d4:	mov    eax,DWORD PTR [r14+0x2c]
  4082d8:	add    QWORD PTR [r14+0x20],rax
  4082dc:	add    DWORD PTR [r14+0x28],0x1
  4082e1:	jmp    4082e5 <__swc_fn_23cea7fa_000054_faa92dcc+0xa5>
  4082e3:	xor    esi,esi
  4082e5:	test   rsi,rsi
  4082e8:	jne    40832d <__swc_fn_23cea7fa_000054_faa92dcc+0xed>
  4082ea:	mov    rcx,r14
  4082ed:	call   40beb0 <__swc_fn_23cea7fa_000010_24a20786>
  4082f2:	test   al,al
  4082f4:	je     40832d <__swc_fn_23cea7fa_000054_faa92dcc+0xed>
  4082f6:	mov    rax,QWORD PTR [r14]
  4082f9:	test   rax,rax
  4082fc:	je     40830b <__swc_fn_23cea7fa_000054_faa92dcc+0xcb>
  4082fe:	mov    rcx,QWORD PTR [rax]
  408301:	mov    QWORD PTR [r14],rcx
  408304:	add    DWORD PTR [r14+0x28],0x1
  408309:	jmp    40832a <__swc_fn_23cea7fa_000054_faa92dcc+0xea>
  40830b:	mov    rax,QWORD PTR [r14+0x18]
  40830f:	cmp    QWORD PTR [r14+0x20],rax
  408313:	jae    408328 <__swc_fn_23cea7fa_000054_faa92dcc+0xe8>
  408315:	mov    rax,QWORD PTR [r14+0x20]
  408319:	mov    ecx,DWORD PTR [r14+0x2c]
  40831d:	add    QWORD PTR [r14+0x20],rcx
  408321:	add    DWORD PTR [r14+0x28],0x1
  408326:	jmp    40832a <__swc_fn_23cea7fa_000054_faa92dcc+0xea>
  408328:	xor    eax,eax
  40832a:	mov    rsi,rax
  40832d:	test   rsi,rsi
  408330:	jne    408383 <__swc_fn_23cea7fa_000054_faa92dcc+0x143>
  408332:	mov    rcx,rdi
  408335:	mov    rdx,r12
  408338:	mov    r8,r14
  40833b:	call   40f760 <__swc_fn_23cea7fa_000050_129b9bf4>
  408340:	test   al,al
  408342:	jne    408383 <__swc_fn_23cea7fa_000054_faa92dcc+0x143>
  408344:	mov    rcx,r14
  408347:	call   40bf80 <__swc_fn_23cea7fa_000013_e4b0ddfc>
  40834c:	mov    rax,QWORD PTR [r14]
  40834f:	test   rax,rax
  408352:	je     408361 <__swc_fn_23cea7fa_000054_faa92dcc+0x121>
  408354:	mov    rcx,QWORD PTR [rax]
  408357:	mov    QWORD PTR [r14],rcx
  40835a:	add    DWORD PTR [r14+0x28],0x1
  40835f:	jmp    408380 <__swc_fn_23cea7fa_000054_faa92dcc+0x140>
  408361:	mov    rax,QWORD PTR [r14+0x18]
  408365:	cmp    QWORD PTR [r14+0x20],rax
  408369:	jae    40837e <__swc_fn_23cea7fa_000054_faa92dcc+0x13e>
  40836b:	mov    rax,QWORD PTR [r14+0x20]
  40836f:	mov    ecx,DWORD PTR [r14+0x2c]
  408373:	add    QWORD PTR [r14+0x20],rcx
  408377:	add    DWORD PTR [r14+0x28],0x1
  40837c:	jmp    408380 <__swc_fn_23cea7fa_000054_faa92dcc+0x140>
  40837e:	xor    eax,eax
  408380:	mov    rsi,rax
  408383:	test   rsi,rsi
  408386:	je     4083a1 <__swc_fn_23cea7fa_000054_faa92dcc+0x161>
  408388:	mov    QWORD PTR [r13+0x0],r14
  40838c:	mov    rax,rsi
  40838f:	add    rsp,0x1f8
  408396:	pop    r15
  408398:	pop    r14
  40839a:	pop    r13
  40839c:	pop    r12
  40839e:	pop    rdi
  40839f:	pop    rsi
  4083a0:	ret
  4083a1:	mov    r14,r15
  4083a4:	jmp    408290 <__swc_fn_23cea7fa_000054_faa92dcc+0x50>
  4083a9:	cs nop WORD PTR [rax+rax*1+0x0]
  4083b3:	cs nop WORD PTR [rax+rax*1+0x0]
  4083bd:	nop    DWORD PTR [rax]
  4083c0:	mov    rcx,rdi
  4083c3:	mov    rdx,r12
  4083c6:	mov    r8d,esi
  4083c9:	call   40c560 <__swc_fn_23cea7fa_000049_ad48ec88>
  4083ce:	mov    r14,rax
  4083d1:	test   rax,rax
  4083d4:	jne    4083ea <__swc_fn_23cea7fa_000054_faa92dcc+0x1aa>
  4083d6:	xor    eax,eax
  4083d8:	add    rsp,0x1f8
  4083df:	pop    r15
  4083e1:	pop    r14
  4083e3:	pop    r13
  4083e5:	pop    r12
  4083e7:	pop    rdi
  4083e8:	pop    rsi
  4083e9:	ret
  4083ea:	mov    QWORD PTR [r13+0x0],r14
  4083ee:	mov    rax,QWORD PTR [r14]
  4083f1:	test   rax,rax
  4083f4:	je     408406 <__swc_fn_23cea7fa_000054_faa92dcc+0x1c6>
  4083f6:	mov    rcx,QWORD PTR [rax]
  4083f9:	mov    QWORD PTR [r14],rcx
  4083fc:	add    DWORD PTR [r14+0x28],0x1
  408401:	mov    r15,rax
  408404:	jmp    408426 <__swc_fn_23cea7fa_000054_faa92dcc+0x1e6>
  408406:	mov    rax,QWORD PTR [r14+0x18]
  40840a:	cmp    QWORD PTR [r14+0x20],rax
  40840e:	jae    408423 <__swc_fn_23cea7fa_000054_faa92dcc+0x1e3>
  408410:	mov    r15,QWORD PTR [r14+0x20]
  408414:	mov    eax,DWORD PTR [r14+0x2c]
  408418:	add    QWORD PTR [r14+0x20],rax
  40841c:	add    DWORD PTR [r14+0x28],0x1
  408421:	jmp    408426 <__swc_fn_23cea7fa_000054_faa92dcc+0x1e6>
  408423:	xor    r15d,r15d
  408426:	test   r15,r15
  408429:	jne    40846e <__swc_fn_23cea7fa_000054_faa92dcc+0x22e>
  40842b:	mov    rcx,r14
  40842e:	call   40beb0 <__swc_fn_23cea7fa_000010_24a20786>
  408433:	test   al,al
  408435:	je     40846e <__swc_fn_23cea7fa_000054_faa92dcc+0x22e>
  408437:	mov    rax,QWORD PTR [r14]
  40843a:	test   rax,rax
  40843d:	je     40844c <__swc_fn_23cea7fa_000054_faa92dcc+0x20c>
  40843f:	mov    rcx,QWORD PTR [rax]
  408442:	mov    QWORD PTR [r14],rcx
  408445:	add    DWORD PTR [r14+0x28],0x1
  40844a:	jmp    40846b <__swc_fn_23cea7fa_000054_faa92dcc+0x22b>
  40844c:	mov    rax,QWORD PTR [r14+0x18]
  408450:	cmp    QWORD PTR [r14+0x20],rax
  408454:	jae    408469 <__swc_fn_23cea7fa_000054_faa92dcc+0x229>
  408456:	mov    rax,QWORD PTR [r14+0x20]
  40845a:	mov    ecx,DWORD PTR [r14+0x2c]
  40845e:	add    QWORD PTR [r14+0x20],rcx
  408462:	add    DWORD PTR [r14+0x28],0x1
  408467:	jmp    40846b <__swc_fn_23cea7fa_000054_faa92dcc+0x22b>
  408469:	xor    eax,eax
  40846b:	mov    r15,rax
  40846e:	test   r15,r15
  408471:	je     4083c0 <__swc_fn_23cea7fa_000054_faa92dcc+0x180>
  408477:	mov    rax,r15
  40847a:	add    rsp,0x1f8
  408481:	pop    r15
  408483:	pop    r14
  408485:	pop    r13
  408487:	pop    r12
  408489:	pop    rdi
  40848a:	pop    rsi
  40848b:	ret
  40848c:	add    BYTE PTR [rax],al
	...

0000000000408490 <__swc_fn_23cea7fa_000057_7e1dbcb0>:
  408490:	push   rsi
  408491:	push   rdi
  408492:	push   r12
  408494:	mov    rsi,rdx
  408497:	mov    rax,rdx
  40849a:	shr    rax,0xc
  40849e:	movabs rdx,0x9e3779b97f4a7c15
  4084a8:	imul   rax,rdx
  4084ac:	shr    rax,0x20
  4084b0:	lea    rax,[rax*8+0x0]
  4084b8:	shr    rax,0x20
  4084bc:	lea    rax,[rax*8+0x0]
  4084c4:	lea    rax,[rcx+rax*8+0x40]
  4084c9:	xor    edx,edx
  4084cb:	test   dl,dl
  4084cd:	lea    rdi,[rcx+0x8]
  4084d1:	cmove  rdi,rax
  4084d5:	xor    edx,edx
  4084d7:	test   dl,dl
  4084d9:	lea    r12,[rcx+0x30]
  4084dd:	lea    rax,[rax+0x8]
  4084e1:	cmove  r12,rax
  4084e5:	mov    rcx,rdi
  4084e8:	call   40e420 <__swc_fn_23cea7fa_000139_86bb0f90>
  4084ed:	mov    QWORD PTR [rsi+0x30],0x0
  4084f5:	mov    rax,QWORD PTR [r12]
  4084f9:	mov    QWORD PTR [rsi+0x38],rax
  4084fd:	test   rax,rax
  408500:	je     40850a <__swc_fn_23cea7fa_000057_7e1dbcb0+0x7a>
  408502:	mov    rax,QWORD PTR [rsi+0x38]
  408506:	mov    QWORD PTR [rax+0x30],rsi
  40850a:	mov    QWORD PTR [r12],rsi
  40850e:	mov    rcx,rdi
  408511:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  408516:	pop    r12
  408518:	pop    rdi
  408519:	pop    rsi
  40851a:	ret
  40851b:	add    BYTE PTR [rax],al
  40851d:	add    BYTE PTR [rax],al
	...

0000000000408520 <__swc_fn_23cea7fa_000060_15c28ca7>:
  408520:	lea    rax,[rdx+rdx*4]
  408524:	lea    rax,[rcx+rax*8+0x268]
  40852c:	mov    rdx,QWORD PTR [rax+0x10]
  408530:	sub    QWORD PTR [rcx+0x2a68],rdx
  408537:	sub    QWORD PTR [rcx+0x2a70],0x1
  40853f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  408546:	lea    rdx,[rdx+rdx*4]
  40854a:	lea    rdx,[rcx+rdx*8+0x268]
  408552:	vmovups xmm0,XMMWORD PTR [rdx]
  408556:	vmovups XMMWORD PTR [rax],xmm0
  40855a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40855f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  408564:	mov    rcx,QWORD PTR [rdx+0x20]
  408568:	mov    QWORD PTR [rax+0x20],rcx
  40856c:	ret
  40856d:	add    BYTE PTR [rax],al
	...

0000000000408570 <__swc_fn_23cea7fa_000063_dea90857>:
  408570:	push   rsi
  408571:	push   rdi
  408572:	push   r12
  408574:	push   r13
  408576:	sub    rsp,0x8
  40857a:	mov    rsi,r8
  40857d:	mov    rdi,rcx
  408580:	mov    r12,rdx
  408583:	xor    r13d,r13d
  408586:	cs nop WORD PTR [rax+rax*1+0x0]
  408590:	mov    eax,DWORD PTR [r12+0x730]
  408598:	cmp    r13d,eax
  40859b:	jae    408601 <__swc_fn_23cea7fa_000063_dea90857+0x91>
  40859d:	lea    rax,[r13+r13*4+0x0]
  4085a2:	lea    rax,[r12+rax*8+0x738]
  4085aa:	mov    rdx,QWORD PTR [rax]
  4085ad:	mov    r8,QWORD PTR [rax+0x8]
  4085b1:	mov    r9,QWORD PTR [rax+0x10]
  4085b5:	cmp    QWORD PTR [rax+0x20],rsi
  4085b9:	jb     4085c0 <__swc_fn_23cea7fa_000063_dea90857+0x50>
  4085bb:	inc    r13d
  4085be:	jmp    408590 <__swc_fn_23cea7fa_000063_dea90857+0x20>
  4085c0:	sub    DWORD PTR [r12+0x730],0x1
  4085c9:	mov    ecx,DWORD PTR [r12+0x730]
  4085d1:	lea    rcx,[rcx+rcx*4]
  4085d5:	lea    rcx,[r12+rcx*8+0x738]
  4085dd:	vmovups xmm0,XMMWORD PTR [rcx]
  4085e1:	vmovups XMMWORD PTR [rax],xmm0
  4085e5:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  4085ea:	vmovups XMMWORD PTR [rax+0x10],xmm0
  4085ef:	mov    rcx,QWORD PTR [rcx+0x20]
  4085f3:	mov    QWORD PTR [rax+0x20],rcx
  4085f7:	mov    rcx,rdi
  4085fa:	call   40c2e0 <__swc_fn_23cea7fa_000043_d3c2ab54>
  4085ff:	jmp    408590 <__swc_fn_23cea7fa_000063_dea90857+0x20>
  408601:	add    rsp,0x8
  408605:	pop    r13
  408607:	pop    r12
  408609:	pop    rdi
  40860a:	pop    rsi
  40860b:	ret
  40860c:	add    BYTE PTR [rax],al
	...

0000000000408610 <__swc_fn_23cea7fa_000066_de167e8d>:
  408610:	push   rsi
  408611:	push   rdi
  408612:	push   r12
  408614:	push   r13
  408616:	push   r14
  408618:	mov    rsi,rcx
  40861b:	mov    rdi,rdx
  40861e:	mov    r12,QWORD PTR [rdi]
  408621:	mov    r13,QWORD PTR [rdi+0x18]
  408625:	mov    rax,r12
  408628:	add    rax,QWORD PTR [rdi+0x8]
  40862c:	sub    rax,r13
  40862f:	cmp    r8,rax
  408632:	jbe    40863d <__swc_fn_23cea7fa_000066_de167e8d+0x2d>
  408634:	pop    r14
  408636:	pop    r13
  408638:	pop    r12
  40863a:	pop    rdi
  40863b:	pop    rsi
  40863c:	ret
  40863d:	lea    rax,[r13+r8*1+0x0]
  408642:	sub    rax,r12
  408645:	mov    ecx,0x1000
  40864a:	test   ecx,ecx
  40864c:	mov    edx,0x8
  408651:	cmove  ecx,edx
  408654:	dec    rcx
  408657:	mov    rdx,0xffffffffffffffff
  40865e:	sub    rdx,rcx
  408661:	cmp    rax,rdx
  408664:	jbe    40866b <__swc_fn_23cea7fa_000066_de167e8d+0x5b>
  408666:	xor    r14d,r14d
  408669:	jmp    408676 <__swc_fn_23cea7fa_000066_de167e8d+0x66>
  40866b:	add    rax,rcx
  40866e:	andn   rax,rcx,rax
  408673:	mov    r14,rax
  408676:	mov    rax,QWORD PTR [rdi+0x10]
  40867a:	cmp    r14,rax
  40867d:	ja     408688 <__swc_fn_23cea7fa_000066_de167e8d+0x78>
  40867f:	pop    r14
  408681:	pop    r13
  408683:	pop    r12
  408685:	pop    rdi
  408686:	pop    rsi
  408687:	ret
  408688:	mov    rax,r12
  40868b:	add    rax,QWORD PTR [rdi+0x10]
  40868f:	mov    rdx,r14
  408692:	sub    rdx,QWORD PTR [rdi+0x10]
  408696:	mov    rcx,rax
  408699:	call   40be30 <__swc_fn_23cea7fa_000007_f7acedb0>
  40869e:	test   al,al
  4086a0:	jne    4086ab <__swc_fn_23cea7fa_000066_de167e8d+0x9b>
  4086a2:	pop    r14
  4086a4:	pop    r13
  4086a6:	pop    r12
  4086a8:	pop    rdi
  4086a9:	pop    rsi
  4086aa:	ret
  4086ab:	add    r12,r14
  4086ae:	sub    r12,r13
  4086b1:	mov    rcx,r12
  4086b4:	sub    rcx,QWORD PTR [rdi+0x28]
  4086b8:	mov    rdx,QWORD PTR [rsi+0x250]
  4086bf:	nop
  4086c0:	lea    r8,[rdx+rcx*1]
  4086c4:	mov    rax,rdx
  4086c7:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  4086d0:	cmp    rax,rdx
  4086d3:	je     4086da <__swc_fn_23cea7fa_000066_de167e8d+0xca>
  4086d5:	mov    rdx,rax
  4086d8:	jmp    4086c0 <__swc_fn_23cea7fa_000066_de167e8d+0xb0>
  4086da:	mov    QWORD PTR [rdi+0x10],r14
  4086de:	mov    QWORD PTR [rdi+0x28],r12
  4086e2:	pop    r14
  4086e4:	pop    r13
  4086e6:	pop    r12
  4086e8:	pop    rdi
  4086e9:	pop    rsi
  4086ea:	ret
  4086eb:	add    BYTE PTR [rax],al
  4086ed:	add    BYTE PTR [rax],al
	...

00000000004086f0 <__swc_fn_23cea7fa_000069_7130736e>:
  4086f0:	push   rbx
  4086f1:	push   rsi
  4086f2:	push   rdi
  4086f3:	push   r12
  4086f5:	push   r13
  4086f7:	sub    rsp,0xe0
  4086fe:	mov    rbx,rdx
  408701:	mov    rsi,rcx
  408704:	cmp    DWORD PTR [rbx+0x58],0x0
  408708:	je     40872c <__swc_fn_23cea7fa_000069_7130736e+0x3c>
  40870a:	mov    eax,DWORD PTR [rbx+0x58]
  40870d:	sub    eax,0x1
  408710:	test   DWORD PTR [rbx+0x58],eax
  408713:	je     40872c <__swc_fn_23cea7fa_000069_7130736e+0x3c>
  408715:	mov    QWORD PTR [rbx+0x40],0x0
  40871d:	add    rsp,0xe0
  408724:	pop    r13
  408726:	pop    r12
  408728:	pop    rdi
  408729:	pop    rsi
  40872a:	pop    rbx
  40872b:	ret
  40872c:	mov    rax,QWORD PTR [rbx+0x40]
  408730:	test   rax,rax
  408733:	jne    40874f <__swc_fn_23cea7fa_000069_7130736e+0x5f>
  408735:	mov    rcx,rsi
  408738:	mov    rdx,rbx
  40873b:	call   410410 <__swc_fn_23cea7fa_000068_f3aa21af>
  408740:	add    rsp,0xe0
  408747:	pop    r13
  408749:	pop    r12
  40874b:	pop    rdi
  40874c:	pop    rsi
  40874d:	pop    rbx
  40874e:	ret
  40874f:	cmp    QWORD PTR [rbx+0x48],0x0
  408754:	jne    408770 <__swc_fn_23cea7fa_000069_7130736e+0x80>
  408756:	mov    rcx,rsi
  408759:	mov    rdx,rbx
  40875c:	call   40cb10 <__swc_fn_23cea7fa_000070_97813b89>
  408761:	add    rsp,0xe0
  408768:	pop    r13
  40876a:	pop    r12
  40876c:	pop    rdi
  40876d:	pop    rsi
  40876e:	pop    rbx
  40876f:	ret
  408770:	mov    rdi,QWORD PTR [rbx+0x40]
  408774:	lea    rax,[rip+0x1b8fd]        # 424078 <__swc_bss_base_23cea7fa+0x38>
  40877b:	mov    rcx,rdi
  40877e:	sub    rcx,QWORD PTR [rax+0x8]
  408782:	mov    rax,QWORD PTR [rip+0x1b8ff]        # 424088 <__swc_bss_base_23cea7fa+0x48>
  408789:	cmp    rcx,rax
  40878c:	jae    4087b8 <__swc_fn_23cea7fa_000069_7130736e+0xc8>
  40878e:	mov    rax,rdi
  408791:	and    rax,0xffffffffffc00000
  408798:	mov    rcx,rdi
  40879b:	shr    rcx,0x10
  40879f:	and    ecx,0x3f
  4087a2:	mov    edx,DWORD PTR [rax+0x28]
  4087a5:	shrx   ecx,ecx,edx
  4087aa:	shl    rcx,0x4
  4087ae:	lea    r12,[rax+rcx*8+0x80]
  4087b6:	jmp    4087c3 <__swc_fn_23cea7fa_000069_7130736e+0xd3>
  4087b8:	mov    rcx,rdi
  4087bb:	call   40f490 <__swc_fn_23cea7fa_000026_bcdc5519>
  4087c0:	mov    r12,rax
  4087c3:	test   r12,r12
  4087c6:	je     4087d5 <__swc_fn_23cea7fa_000069_7130736e+0xe5>
  4087c8:	mov    eax,DWORD PTR [r12+0x2c]
  4087cd:	mov    r9d,eax
  4087d0:	mov    r13,rax
  4087d3:	jmp    408854 <__swc_fn_23cea7fa_000069_7130736e+0x164>
  4087d5:	mov    rcx,rsi
  4087d8:	mov    rdx,rdi
  4087db:	call   40faa0 <__swc_fn_23cea7fa_000056_df0696cd>
  4087e0:	mov    rcx,QWORD PTR [rax+0x28]
  4087e4:	mov    r9,rcx
  4087e7:	mov    rdx,QWORD PTR [rax+0x20]
  4087eb:	mov    r13,rdx
  4087ee:	cmp    QWORD PTR [rbx+0x48],rcx
  4087f2:	jbe    40882b <__swc_fn_23cea7fa_000069_7130736e+0x13b>
  4087f4:	mov    ecx,DWORD PTR [rax+0x48]
  4087f7:	cmp    DWORD PTR [rbx+0x58],ecx
  4087fa:	ja     40882b <__swc_fn_23cea7fa_000069_7130736e+0x13b>
  4087fc:	mov    rcx,rsi
  4087ff:	mov    rdx,rax
  408802:	mov    r8,QWORD PTR [rbx+0x48]
  408806:	mov    QWORD PTR [rsp+0xc8],r9
  40880e:	mov    QWORD PTR [rsp+0xd0],rax
  408816:	call   408610 <__swc_fn_23cea7fa_000066_de167e8d>
  40881b:	mov    r9,QWORD PTR [rsp+0xc8]
  408823:	mov    rax,QWORD PTR [rsp+0xd0]
  40882b:	mov    rcx,QWORD PTR [rax+0x28]
  40882f:	cmp    QWORD PTR [rbx+0x48],rcx
  408833:	ja     408854 <__swc_fn_23cea7fa_000069_7130736e+0x164>
  408835:	mov    ecx,DWORD PTR [rax+0x48]
  408838:	cmp    DWORD PTR [rbx+0x58],ecx
  40883b:	ja     408854 <__swc_fn_23cea7fa_000069_7130736e+0x164>
  40883d:	mov    rcx,QWORD PTR [rbx+0x48]
  408841:	mov    QWORD PTR [rax+0x20],rcx
  408845:	add    rsp,0xe0
  40884c:	pop    r13
  40884e:	pop    r12
  408850:	pop    rdi
  408851:	pop    rsi
  408852:	pop    rbx
  408853:	ret
  408854:	test   r12,r12
  408857:	je     408889 <__swc_fn_23cea7fa_000069_7130736e+0x199>
  408859:	cmp    QWORD PTR [rbx+0x48],r9
  40885d:	ja     408889 <__swc_fn_23cea7fa_000069_7130736e+0x199>
  40885f:	cmp    DWORD PTR [rbx+0x58],0x40
  408863:	ja     408889 <__swc_fn_23cea7fa_000069_7130736e+0x199>
  408865:	cmp    DWORD PTR [rbx+0x58],0x0
  408869:	je     408876 <__swc_fn_23cea7fa_000069_7130736e+0x186>
  40886b:	mov    ecx,DWORD PTR [rbx+0x58]
  40886e:	dec    rcx
  408871:	test   rdi,rcx
  408874:	jne    408889 <__swc_fn_23cea7fa_000069_7130736e+0x199>
  408876:	mov    QWORD PTR [rbx+0x40],rdi
  40887a:	add    rsp,0xe0
  408881:	pop    r13
  408883:	pop    r12
  408885:	pop    rdi
  408886:	pop    rsi
  408887:	pop    rbx
  408888:	ret
  408889:	vmovups xmm0,XMMWORD PTR [rbx]
  40888d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  408893:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  408898:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40889e:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  4088a3:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  4088a9:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  4088ae:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  4088b4:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  4088b9:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  4088bf:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  4088c4:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  4088ca:	mov    QWORD PTR [rsp+0x48],0x0
  4088d3:	mov    rcx,rsi
  4088d6:	lea    rdx,[rsp+0x8]
  4088db:	call   410410 <__swc_fn_23cea7fa_000068_f3aa21af>
  4088e0:	mov    rax,QWORD PTR [rsp+0x48]
  4088e5:	test   rax,rax
  4088e8:	jne    408901 <__swc_fn_23cea7fa_000069_7130736e+0x211>
  4088ea:	mov    QWORD PTR [rbx+0x40],0x0
  4088f2:	add    rsp,0xe0
  4088f9:	pop    r13
  4088fb:	pop    r12
  4088fd:	pop    rdi
  4088fe:	pop    rsi
  4088ff:	pop    rbx
  408900:	ret
  408901:	mov    rax,QWORD PTR [rbx+0x48]
  408905:	cmp    r13,rax
  408908:	cmovbe rax,r13
  40890c:	mov    rcx,QWORD PTR [rsp+0x48]
  408911:	mov    rdx,rdi
  408914:	mov    r8,rax
  408917:	call   40dc60 <__swc_fn_23cea7fa_000109_7c204aac>
  40891c:	vmovups xmm0,XMMWORD PTR [rbx]
  408920:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  408926:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40892b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  408931:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  408936:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40893f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  408944:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40894d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  408952:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40895b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  408960:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  408969:	mov    QWORD PTR [rsp+0xa8],rdi
  408971:	mov    rcx,rsi
  408974:	lea    rdx,[rsp+0x68]
  408979:	call   40cb10 <__swc_fn_23cea7fa_000070_97813b89>
  40897e:	mov    rax,QWORD PTR [rsp+0x48]
  408983:	mov    QWORD PTR [rbx+0x40],rax
  408987:	add    rsp,0xe0
  40898e:	pop    r13
  408990:	pop    r12
  408992:	pop    rdi
  408993:	pop    rsi
  408994:	pop    rbx
  408995:	ret
	...

00000000004089a0 <__swc_fn_23cea7fa_000072_61e60aab>:
  4089a0:	push   r12
  4089a2:	push   rdi
  4089a3:	push   rsi
  4089a4:	push   r13
  4089a6:	push   r14
  4089a8:	sub    rsp,0x190
  4089af:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  4089b8:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  4089c1:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  4089ca:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  4089d3:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  4089dc:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  4089e5:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  4089ee:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  4089f7:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  408a00:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  408a09:	mov    r12,rcx
  408a0c:	lea    rax,[rip+0x195f5]        # 422008 <__swc_data_base_23cea7fa+0x8>
  408a13:	mov    rax,QWORD PTR [rax]
  408a16:	cmp    rax,0xffffffffffffffff
  408a1a:	je     408a29 <__swc_fn_23cea7fa_000072_61e60aab+0x89>
  408a1c:	mov    eax,eax
  408a1e:	mov    edi,eax
  408a20:	xor    eax,eax
  408a22:	call   407000 <pthread_getspecific@plt>
  408a27:	jmp    408a2b <__swc_fn_23cea7fa_000072_61e60aab+0x8b>
  408a29:	xor    eax,eax
  408a2b:	test   rax,rax
  408a2e:	jne    408a3d <__swc_fn_23cea7fa_000072_61e60aab+0x9d>
  408a30:	call   40f560 <__swc_fn_23cea7fa_000035_cd1a4e8c>
  408a35:	mov    rcx,rax
  408a38:	call   40a160 <__swc_fn_23cea7fa_000132_5f757033>
  408a3d:	test   rax,rax
  408a40:	je     408a66 <__swc_fn_23cea7fa_000072_61e60aab+0xc6>
  408a42:	cmp    QWORD PTR [rax],r12
  408a45:	jne    408a66 <__swc_fn_23cea7fa_000072_61e60aab+0xc6>
  408a47:	xor    ecx,ecx
  408a49:	mov    QWORD PTR [rsp+0xc8],rax
  408a51:	call   40c2b0 <__swc_fn_23cea7fa_000037_28d0e998>
  408a56:	mov    rdx,QWORD PTR [rsp+0xc8]
  408a5e:	mov    rcx,r12
  408a61:	call   40c3c0 <__swc_fn_23cea7fa_000046_b30433d0>
  408a66:	lea    rsi,[r12+0x10]
  408a6b:	mov    rcx,rsi
  408a6e:	call   40e420 <__swc_fn_23cea7fa_000139_86bb0f90>
  408a73:	mov    rdi,QWORD PTR [r12+0x20]
  408a78:	test   rdi,rdi
  408a7b:	je     408abe <__swc_fn_23cea7fa_000072_61e60aab+0x11e>
  408a7d:	nop    DWORD PTR [rax]
  408a80:	mov    rcx,r12
  408a83:	mov    rdx,rdi
  408a86:	call   40f720 <__swc_fn_23cea7fa_000047_6e7a8d58>
  408a8b:	mov    rcx,r12
  408a8e:	mov    rdx,rdi
  408a91:	mov    r8,0xffffffffffffffff
  408a98:	call   408570 <__swc_fn_23cea7fa_000063_dea90857>
  408a9d:	mov    rcx,r12
  408aa0:	mov    rdx,rdi
  408aa3:	mov    r8d,0x9b8
  408aa9:	mov    r9d,0x9b8
  408aaf:	call   40c2e0 <__swc_fn_23cea7fa_000043_d3c2ab54>
  408ab4:	mov    rdi,QWORD PTR [r12+0x20]
  408ab9:	test   rdi,rdi
  408abc:	jne    408a80 <__swc_fn_23cea7fa_000072_61e60aab+0xe0>
  408abe:	xor    eax,eax
  408ac0:	xchg   QWORD PTR [r12+0x2a80],rax
  408ac8:	test   rax,rax
  408acb:	je     408af1 <__swc_fn_23cea7fa_000072_61e60aab+0x151>
  408acd:	cs nop WORD PTR [rax+rax*1+0x0]
  408ad7:	nop    WORD PTR [rax+rax*1+0x0]
  408ae0:	mov    rcx,rax
  408ae3:	mov    rax,QWORD PTR [rax+0x78]
  408ae7:	xor    edx,edx
  408ae9:	xchg   DWORD PTR [rcx+0x70],edx
  408aec:	test   rax,rax
  408aef:	jne    408ae0 <__swc_fn_23cea7fa_000072_61e60aab+0x140>
  408af1:	mov    rax,QWORD PTR [r12+0x18]
  408af6:	mov    rdi,rax
  408af9:	test   rdi,rdi
  408afc:	je     408b91 <__swc_fn_23cea7fa_000072_61e60aab+0x1f1>
  408b02:	cs nop WORD PTR [rax+rax*1+0x0]
  408b0c:	nop    DWORD PTR [rax+0x0]
  408b10:	mov    rax,QWORD PTR [rdi+0x10]
  408b14:	mov    r8d,DWORD PTR [rdi+0x2c]
  408b18:	xor    r9d,r9d
  408b1b:	test   r8,r8
  408b1e:	jbe    408b7d <__swc_fn_23cea7fa_000072_61e60aab+0x1dd>
  408b20:	mov    ecx,r9d
  408b23:	shl    rcx,0x4
  408b27:	lea    rdx,[rdi+rcx*8+0x80]
  408b2f:	cmp    BYTE PTR [rdx+0x3b],0x0
  408b33:	je     408b74 <__swc_fn_23cea7fa_000072_61e60aab+0x1d4>
  408b35:	mov    DWORD PTR [rdx+0x28],0x0
  408b3c:	mov    rcx,rdi
  408b3f:	mov    QWORD PTR [rsp+0xd0],rax
  408b47:	mov    QWORD PTR [rsp+0xd8],r8
  408b4f:	mov    QWORD PTR [rsp+0xe0],r9
  408b57:	call   407ca0 <__swc_fn_23cea7fa_000018_283e2b5e>
  408b5c:	mov    rax,QWORD PTR [rsp+0xd0]
  408b64:	mov    r8,QWORD PTR [rsp+0xd8]
  408b6c:	mov    r9,QWORD PTR [rsp+0xe0]
  408b74:	add    r9,0x1
  408b78:	cmp    r9,r8
  408b7b:	jb     408b20 <__swc_fn_23cea7fa_000072_61e60aab+0x180>
  408b7d:	mov    rcx,rdi
  408b80:	mov    rdi,rax
  408b83:	call   40c1c0 <__swc_fn_23cea7fa_000025_aa910677>
  408b88:	test   rdi,rdi
  408b8b:	jne    408b10 <__swc_fn_23cea7fa_000072_61e60aab+0x170>
  408b91:	mov    QWORD PTR [r12+0x18],0x0
  408b9a:	mov    QWORD PTR [r12+0x28],0x0
  408ba3:	mov    rcx,rsi
  408ba6:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  408bab:	mov    esi,0x8
  408bb0:	xor    edi,edi
  408bb2:	test   rsi,rsi
  408bb5:	je     408c12 <__swc_fn_23cea7fa_000072_61e60aab+0x272>
  408bbb:	nop    DWORD PTR [rax+rax*1+0x0]
  408bc0:	lea    r13,[rdi*8+0x0]
  408bc8:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  408bcd:	test   r14,r14
  408bd0:	je     408c08 <__swc_fn_23cea7fa_000072_61e60aab+0x268>
  408bd2:	cs nop WORD PTR [rax+rax*1+0x0]
  408bdc:	nop    DWORD PTR [rax+0x0]
  408be0:	mov    rcx,r12
  408be3:	mov    rdx,r14
  408be6:	call   40c970 <__swc_fn_23cea7fa_000058_1bb23e77>
  408beb:	mov    rcx,r12
  408bee:	mov    rdx,QWORD PTR [r14]
  408bf1:	mov    r8,QWORD PTR [r14+0x8]
  408bf5:	mov    r9,QWORD PTR [r14+0x10]
  408bf9:	call   40c2e0 <__swc_fn_23cea7fa_000043_d3c2ab54>
  408bfe:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  408c03:	test   r14,r14
  408c06:	jne    408be0 <__swc_fn_23cea7fa_000072_61e60aab+0x240>
  408c08:	add    rdi,0x1
  408c0c:	sub    rsi,0x1
  408c10:	jne    408bc0 <__swc_fn_23cea7fa_000072_61e60aab+0x220>
  408c12:	mov    rcx,r12
  408c15:	call   40ca40 <__swc_fn_23cea7fa_000064_ffcd96eb>
  408c1a:	lea    rcx,[r12+0x250]
  408c22:	mov    rdx,QWORD PTR [rcx]
  408c25:	mov    r8,QWORD PTR [r12+0x250]
  408c2d:	nop    DWORD PTR [rax]
  408c30:	mov    r9,r8
  408c33:	sub    r9,rdx
  408c36:	mov    rax,r8
  408c39:	lock cmpxchg QWORD PTR [rcx],r9
  408c3e:	cmp    rax,r8
  408c41:	je     408c48 <__swc_fn_23cea7fa_000072_61e60aab+0x2a8>
  408c43:	mov    r8,rax
  408c46:	jmp    408c30 <__swc_fn_23cea7fa_000072_61e60aab+0x290>
  408c48:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  408c51:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  408c5a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  408c63:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  408c6c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  408c75:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  408c7e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  408c87:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  408c90:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  408c99:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  408ca2:	add    rsp,0x190
  408ca9:	pop    r14
  408cab:	pop    r13
  408cad:	pop    rsi
  408cae:	pop    rdi
  408caf:	pop    r12
  408cb1:	ret
	...

0000000000408cc0 <__swc_fn_23cea7fa_000075_64d36d78>:
  408cc0:	sub    rsp,0x8
  408cc4:	mov    QWORD PTR [rdx+0x40],0x0
  408ccc:	call   410410 <__swc_fn_23cea7fa_000068_f3aa21af>
  408cd1:	add    rsp,0x8
  408cd5:	ret
	...

0000000000408ce0 <__swc_fn_23cea7fa_000078_1966ae2e>:
  408ce0:	sub    rsp,0x8
  408ce4:	call   40cb10 <__swc_fn_23cea7fa_000070_97813b89>
  408ce9:	add    rsp,0x8
  408ced:	ret
	...

0000000000408cf0 <__swc_fn_23cea7fa_000081_5cc7acfc>:
  408cf0:	push   rbx
  408cf1:	push   rsi
  408cf2:	push   rdi
  408cf3:	push   r12
  408cf5:	push   r13
  408cf7:	push   r14
  408cf9:	push   r15
  408cfb:	sub    rsp,0x20
  408cff:	mov    rbx,r11
  408d02:	mov    rsi,rcx
  408d05:	mov    rdi,rdx
  408d08:	mov    r12,r8
  408d0b:	mov    r13,r9
  408d0e:	mov    r14,r10
  408d11:	mov    rcx,QWORD PTR [rip+0x1b328]        # 424040 <__swc_bss_base_23cea7fa>
  408d18:	test   rcx,rcx
  408d1b:	jne    408d2d <__swc_fn_23cea7fa_000081_5cc7acfc+0x3d>
  408d1d:	call   40ed20 <__swc_fn_23cea7fa_000169_994c8876>
  408d22:	lea    rcx,[rax+0x1]
  408d26:	mov    QWORD PTR [rip+0x1b313],rcx        # 424040 <__swc_bss_base_23cea7fa>
  408d2d:	dec    rcx
  408d30:	call   40bbe0 <__swc_fn_23cea7fa_000171_360af05d>
  408d35:	mov    r15,rax
  408d38:	lea    r11,[rip+0x1b501]        # 424240 <__swc_bss_base_23cea7fa+0x200>
  408d3f:	mov    rcx,r11
  408d42:	call   40c2d0 <__swc_fn_23cea7fa_000040_eb6108f2>
  408d47:	test   al,al
  408d49:	jne    408d5a <__swc_fn_23cea7fa_000081_5cc7acfc+0x6a>
  408d4b:	mov    rcx,r11
  408d4e:	call   40f5c0 <__swc_fn_23cea7fa_000038_14f56618>
  408d53:	lea    r11,[rip+0x1b4e6]        # 424240 <__swc_bss_base_23cea7fa+0x200>
  408d5a:	mov    rcx,r11
  408d5d:	mov    rdx,rsi
  408d60:	mov    r8,rdi
  408d63:	mov    r9,r12
  408d66:	mov    r10,r13
  408d69:	mov    rsi,r11
  408d6c:	mov    r11,r14
  408d6f:	call   408010 <__swc_fn_23cea7fa_000039_03f1bf9a>
  408d74:	test   bl,bl
  408d76:	je     408d9d <__swc_fn_23cea7fa_000081_5cc7acfc+0xad>
  408d78:	mov    QWORD PTR [rsp+0x8],rsi
  408d7d:	lea    rax,[rip+0xa4f4]        # 413278 <__swc_rdata_base_23cea7fa+0x168>
  408d84:	mov    QWORD PTR [rsp+0x10],rax
  408d89:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  408d8f:	vmovups XMMWORD PTR [r15],xmm0
  408d94:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  408d9d:	mov    rax,rsi
  408da0:	add    rsp,0x20
  408da4:	pop    r15
  408da6:	pop    r14
  408da8:	pop    r13
  408daa:	pop    r12
  408dac:	pop    rdi
  408dad:	pop    rsi
  408dae:	pop    rbx
  408daf:	ret

0000000000408db0 <__swc_fn_23cea7fa_000084_cf82995a>:
  408db0:	sub    rsp,0x8
  408db4:	mov    rax,rcx
  408db7:	test   rcx,rcx
  408dba:	jne    408dc1 <__swc_fn_23cea7fa_000084_cf82995a+0x11>
  408dbc:	add    rsp,0x8
  408dc0:	ret
  408dc1:	lea    rcx,[rax-0x10]
  408dc5:	mov    rax,QWORD PTR [rax-0x10]
  408dc9:	mov    rdx,rax
  408dcc:	call   409e10 <__swc_fn_23cea7fa_000117_ed2d8fed>
  408dd1:	add    rsp,0x8
  408dd5:	ret
	...

0000000000408de0 <__swc_fn_23cea7fa_000087_ef55f6e4>:
  408de0:	sub    rsp,0x8
  408de4:	xor    r11d,r11d
  408de7:	call   40cdd0 <__swc_fn_23cea7fa_000088_0d280354>
  408dec:	add    rsp,0x8
  408df0:	ret
	...

0000000000408e00 <__swc_fn_23cea7fa_000090_23214800>:
  408e00:	push   rsi
  408e01:	push   rdi
  408e02:	push   r12
  408e04:	push   r13
  408e06:	push   r14
  408e08:	push   r15
  408e0a:	sub    rsp,0x68
  408e0e:	mov    rsi,r9
  408e11:	mov    rdi,rcx
  408e14:	mov    r12,rdx
  408e17:	mov    r13,r8
  408e1a:	cmp    r8,r9
  408e1d:	jne    408e45 <__swc_fn_23cea7fa_000090_23214800+0x45>
  408e1f:	mov    rcx,rdi
  408e22:	mov    rdx,r12
  408e25:	xor    r8d,r8d
  408e28:	call   40d120 <__swc_fn_23cea7fa_000094_63c1827b>
  408e2d:	test   al,al
  408e2f:	je     408e45 <__swc_fn_23cea7fa_000090_23214800+0x45>
  408e31:	mov    eax,0x1
  408e36:	add    rsp,0x68
  408e3a:	pop    r15
  408e3c:	pop    r14
  408e3e:	pop    r13
  408e40:	pop    r12
  408e42:	pop    rdi
  408e43:	pop    rsi
  408e44:	ret
  408e45:	cmp    BYTE PTR [r12+0x2c],0xe
  408e4b:	je     408e5e <__swc_fn_23cea7fa_000090_23214800+0x5e>
  408e4d:	xor    eax,eax
  408e4f:	add    rsp,0x68
  408e53:	pop    r15
  408e55:	pop    r14
  408e57:	pop    r13
  408e59:	pop    r12
  408e5b:	pop    rdi
  408e5c:	pop    rsi
  408e5d:	ret
  408e5e:	mov    r14,QWORD PTR [r12+0x98]
  408e66:	mov    rax,QWORD PTR [r12+0xa0]
  408e6e:	mov    r12,rax
  408e71:	xor    r15d,r15d
  408e74:	test   r12,r12
  408e77:	je     408edf <__swc_fn_23cea7fa_000090_23214800+0xdf>
  408e79:	nop    DWORD PTR [rax+0x0]
  408e80:	mov    QWORD PTR [rsp+0x58],r12
  408e85:	lea    r12,[r15*8+0x0]
  408e8d:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  408e92:	mov    rcx,rax
  408e95:	call   410ba0 <__swc_fn_23cea7fa_000086_3953ef98>
  408e9a:	cmp    BYTE PTR [rax+0x2c],0xe
  408e9e:	jne    408ed0 <__swc_fn_23cea7fa_000090_23214800+0xd0>
  408ea0:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  408ea5:	lea    r8,[r13+rcx*1+0x0]
  408eaa:	mov    rcx,rdi
  408ead:	mov    rdx,rax
  408eb0:	mov    r9,rsi
  408eb3:	call   408e00 <__swc_fn_23cea7fa_000090_23214800>
  408eb8:	test   al,al
  408eba:	je     408ed0 <__swc_fn_23cea7fa_000090_23214800+0xd0>
  408ebc:	mov    eax,0x1
  408ec1:	add    rsp,0x68
  408ec5:	pop    r15
  408ec7:	pop    r14
  408ec9:	pop    r13
  408ecb:	pop    r12
  408ecd:	pop    rdi
  408ece:	pop    rsi
  408ecf:	ret
  408ed0:	add    r15,0x1
  408ed4:	mov    r12,QWORD PTR [rsp+0x58]
  408ed9:	sub    r12,0x1
  408edd:	jne    408e80 <__swc_fn_23cea7fa_000090_23214800+0x80>
  408edf:	xor    eax,eax
  408ee1:	add    rsp,0x68
  408ee5:	pop    r15
  408ee7:	pop    r14
  408ee9:	pop    r13
  408eeb:	pop    r12
  408eed:	pop    rdi
  408eee:	pop    rsi
  408eef:	ret

0000000000408ef0 <__swc_fn_23cea7fa_000093_c2567a3b>:
  408ef0:	push   rbp
  408ef1:	push   rbx
  408ef2:	push   rsi
  408ef3:	push   rdi
  408ef4:	push   r12
  408ef6:	push   r13
  408ef8:	push   r14
  408efa:	push   r15
  408efc:	sub    rsp,0x38
  408f00:	mov    rbp,rsp
  408f03:	mov    rbx,r11
  408f06:	mov    rsi,rdx
  408f09:	mov    rdi,r8
  408f0c:	mov    r12,r9
  408f0f:	mov    QWORD PTR [rsp+0x18],r9
  408f14:	mov    r13,r10
  408f17:	movzx  r14d,BYTE PTR [rbp+0x80]
  408f1f:	movzx  r15d,BYTE PTR [rbp+0x88]
  408f27:	test   r11,r11
  408f2a:	je     408f30 <__swc_fn_23cea7fa_000093_c2567a3b+0x40>
  408f2c:	xor    eax,eax
  408f2e:	mov    BYTE PTR [rbx],al
  408f30:	test   r12,r12
  408f33:	je     408f3e <__swc_fn_23cea7fa_000093_c2567a3b+0x4e>
  408f35:	mov    QWORD PTR [r12+0x8],0x0
  408f3e:	test   rcx,rcx
  408f41:	je     408f48 <__swc_fn_23cea7fa_000093_c2567a3b+0x58>
  408f43:	test   rsi,rsi
  408f46:	jne    408f5b <__swc_fn_23cea7fa_000093_c2567a3b+0x6b>
  408f48:	xor    eax,eax
  408f4a:	add    rsp,0x38
  408f4e:	pop    r15
  408f50:	pop    r14
  408f52:	pop    r13
  408f54:	pop    r12
  408f56:	pop    rdi
  408f57:	pop    rsi
  408f58:	pop    rbx
  408f59:	pop    rbp
  408f5a:	ret
  408f5b:	call   410ba0 <__swc_fn_23cea7fa_000086_3953ef98>
  408f60:	mov    r12,rax
  408f63:	mov    al,r15b
  408f66:	test   r15b,r15b
  408f69:	jne    408f79 <__swc_fn_23cea7fa_000093_c2567a3b+0x89>
  408f6b:	mov    eax,DWORD PTR [r12+0x28]
  408f70:	and    eax,0x10000
  408f76:	setne  al
  408f79:	lea    r15,[rsp+0x8]
  408f7e:	mov    QWORD PTR [rsp+0x20],r15
  408f83:	rex mov BYTE PTR [rsp+0x8],al
  408f88:	test   DWORD PTR [rsi+0x28],0x400000
  408f8f:	je     408fc7 <__swc_fn_23cea7fa_000093_c2567a3b+0xd7>
  408f91:	test   rsi,rsi
  408f94:	je     408fb4 <__swc_fn_23cea7fa_000093_c2567a3b+0xc4>
  408f96:	mov    rax,QWORD PTR [rsi+0x38]
  408f9a:	cmp    QWORD PTR [rax+0x10],rsi
  408f9e:	jne    408fb4 <__swc_fn_23cea7fa_000093_c2567a3b+0xc4>
  408fa0:	rex mov al,BYTE PTR [rsp+0x8]
  408fa5:	test   al,al
  408fa7:	sete   al
  408faa:	test   r14b,r14b
  408fad:	sete   cl
  408fb0:	test   al,cl
  408fb2:	je     408fc7 <__swc_fn_23cea7fa_000093_c2567a3b+0xd7>
  408fb4:	xor    eax,eax
  408fb6:	add    rsp,0x38
  408fba:	pop    r15
  408fbc:	pop    r14
  408fbe:	pop    r13
  408fc0:	pop    r12
  408fc2:	pop    rdi
  408fc3:	pop    rsi
  408fc4:	pop    rbx
  408fc5:	pop    rbp
  408fc6:	ret
  408fc7:	mov    r15,r12
  408fca:	test   r14b,r14b
  408fcd:	jne    408fe4 <__swc_fn_23cea7fa_000093_c2567a3b+0xf4>
  408fcf:	cmp    BYTE PTR [r12+0x2c],0x6
  408fd5:	jne    408fe4 <__swc_fn_23cea7fa_000093_c2567a3b+0xf4>
  408fd7:	mov    rcx,QWORD PTR [r12+0x40]
  408fdc:	call   410ba0 <__swc_fn_23cea7fa_000086_3953ef98>
  408fe1:	mov    r15,rax
  408fe4:	test   r14b,r14b
  408fe7:	je     408fed <__swc_fn_23cea7fa_000093_c2567a3b+0xfd>
  408fe9:	mov    r15,QWORD PTR [r15+0x30]
  408fed:	mov    rcx,rsi
  408ff0:	call   410ba0 <__swc_fn_23cea7fa_000086_3953ef98>
  408ff5:	mov    rsi,rax
  408ff8:	rex cmp BYTE PTR [rsi+0x2c],0x6
  408ffd:	je     409034 <__swc_fn_23cea7fa_000093_c2567a3b+0x144>
  408fff:	rex cmp BYTE PTR [rsi+0x2c],0x12
  409004:	je     409034 <__swc_fn_23cea7fa_000093_c2567a3b+0x144>
  409006:	mov    eax,DWORD PTR [rsi+0x28]
  409009:	and    eax,0x10000
  40900f:	je     409034 <__swc_fn_23cea7fa_000093_c2567a3b+0x144>
  409011:	rex mov al,BYTE PTR [rsp+0x8]
  409016:	test   al,al
  409018:	jne    40902d <__swc_fn_23cea7fa_000093_c2567a3b+0x13d>
  40901a:	xor    eax,eax
  40901c:	add    rsp,0x38
  409020:	pop    r15
  409022:	pop    r14
  409024:	pop    r13
  409026:	pop    r12
  409028:	pop    rdi
  409029:	pop    rsi
  40902a:	pop    rbx
  40902b:	pop    rbp
  40902c:	ret
  40902d:	mov    rax,QWORD PTR [rsi+0x30]
  409031:	mov    rsi,rax
  409034:	mov    r14b,r13b
  409037:	test   rbx,rbx
  40903a:	je     409070 <__swc_fn_23cea7fa_000093_c2567a3b+0x180>
  40903c:	cmp    BYTE PTR [r12+0x2c],0x6
  409042:	jne    409070 <__swc_fn_23cea7fa_000093_c2567a3b+0x180>
  409044:	lea    rdx,[rip+0xa25d]        # 4132a8 <__swc_rdata_base_23cea7fa+0x198>
  40904b:	mov    rcx,rsi
  40904e:	xor    r8d,r8d
  409051:	call   40d120 <__swc_fn_23cea7fa_000094_63c1827b>
  409056:	test   al,al
  409058:	je     409070 <__swc_fn_23cea7fa_000093_c2567a3b+0x180>
  40905a:	mov    BYTE PTR [rbx],0x1
  40905d:	xor    eax,eax
  40905f:	add    rsp,0x38
  409063:	pop    r15
  409065:	pop    r14
  409067:	pop    r13
  409069:	pop    r12
  40906b:	pop    rdi
  40906c:	pop    rsi
  40906d:	pop    rbx
  40906e:	pop    rbp
  40906f:	ret
  409070:	test   rdi,rdi
  409073:	jne    40908d <__swc_fn_23cea7fa_000093_c2567a3b+0x19d>
  409075:	test   r13b,r13b
  409078:	jne    40908d <__swc_fn_23cea7fa_000093_c2567a3b+0x19d>
  40907a:	xor    eax,eax
  40907c:	add    rsp,0x38
  409080:	pop    r15
  409082:	pop    r14
  409084:	pop    r13
  409086:	pop    r12
  409088:	pop    rdi
  409089:	pop    rsi
  40908a:	pop    rbx
  40908b:	pop    rbp
  40908c:	ret
  40908d:	rex cmp BYTE PTR [rsi+0x2c],0x6
  409092:	jne    409148 <__swc_fn_23cea7fa_000093_c2567a3b+0x258>
  409098:	mov    rcx,r15
  40909b:	mov    rdx,rsi
  40909e:	xor    r8d,r8d
  4090a1:	call   40d120 <__swc_fn_23cea7fa_000094_63c1827b>
  4090a6:	test   al,al
  4090a8:	jne    409148 <__swc_fn_23cea7fa_000093_c2567a3b+0x258>
  4090ae:	test   DWORD PTR [rsi+0x28],0x10000
  4090b5:	je     4090d3 <__swc_fn_23cea7fa_000093_c2567a3b+0x1e3>
  4090b7:	rex mov al,BYTE PTR [rsp+0x8]
  4090bc:	test   al,al
  4090be:	jne    4090d3 <__swc_fn_23cea7fa_000093_c2567a3b+0x1e3>
  4090c0:	xor    eax,eax
  4090c2:	add    rsp,0x38
  4090c6:	pop    r15
  4090c8:	pop    r14
  4090ca:	pop    r13
  4090cc:	pop    r12
  4090ce:	pop    rdi
  4090cf:	pop    rsi
  4090d0:	pop    rbx
  4090d1:	pop    rbp
  4090d2:	ret
  4090d3:	test   rdi,rdi
  4090d6:	jne    4090eb <__swc_fn_23cea7fa_000093_c2567a3b+0x1fb>
  4090d8:	xor    eax,eax
  4090da:	add    rsp,0x38
  4090de:	pop    r15
  4090e0:	pop    r14
  4090e2:	pop    r13
  4090e4:	pop    r12
  4090e6:	pop    rdi
  4090e7:	pop    rsi
  4090e8:	pop    rbx
  4090e9:	pop    rbp
  4090ea:	ret
  4090eb:	mov    rcx,QWORD PTR [rsi+0x40]
  4090ef:	call   410ba0 <__swc_fn_23cea7fa_000086_3953ef98>
  4090f4:	mov    rsi,rax
  4090f7:	mov    rax,QWORD PTR [rdi]
  4090fa:	mov    rdi,rax
  4090fd:	test   rax,rax
  409100:	jne    409143 <__swc_fn_23cea7fa_000093_c2567a3b+0x253>
  409102:	test   rbx,rbx
  409105:	je     409143 <__swc_fn_23cea7fa_000093_c2567a3b+0x253>
  409107:	mov    rcx,r15
  40910a:	mov    rdx,rsi
  40910d:	xor    r8d,r8d
  409110:	call   40d120 <__swc_fn_23cea7fa_000094_63c1827b>
  409115:	mov    rcx,rax
  409118:	test   al,al
  40911a:	jne    40913c <__swc_fn_23cea7fa_000093_c2567a3b+0x24c>
  40911c:	mov    rcx,r15
  40911f:	mov    rdx,rsi
  409122:	call   410be0 <__swc_fn_23cea7fa_000089_d182c4dc>
  409127:	mov    rcx,rax
  40912a:	test   al,al
  40912c:	jne    40913c <__swc_fn_23cea7fa_000093_c2567a3b+0x24c>
  40912e:	mov    rcx,rsi
  409131:	mov    rdx,r15
  409134:	call   410be0 <__swc_fn_23cea7fa_000089_d182c4dc>
  409139:	mov    rcx,rax
  40913c:	test   cl,cl
  40913e:	setne  al
  409141:	mov    BYTE PTR [rbx],al
  409143:	xor    eax,eax
  409145:	mov    r14b,al
  409148:	test   rdi,rdi
  40914b:	jne    409165 <__swc_fn_23cea7fa_000093_c2567a3b+0x275>
  40914d:	test   r14b,r14b
  409150:	jne    409165 <__swc_fn_23cea7fa_000093_c2567a3b+0x275>
  409152:	xor    eax,eax
  409154:	add    rsp,0x38
  409158:	pop    r15
  40915a:	pop    r14
  40915c:	pop    r13
  40915e:	pop    r12
  409160:	pop    rdi
  409161:	pop    rsi
  409162:	pop    rbx
  409163:	pop    rbp
  409164:	ret
  409165:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40916a:	je     409176 <__swc_fn_23cea7fa_000093_c2567a3b+0x286>
  40916c:	mov    r12,QWORD PTR [rsp+0x18]
  409171:	jmp    4091fe <__swc_fn_23cea7fa_000093_c2567a3b+0x30e>
  409176:	mov    r12,QWORD PTR [rsp+0x18]
  40917b:	test   r12,r12
  40917e:	jne    409192 <__swc_fn_23cea7fa_000093_c2567a3b+0x2a2>
  409180:	mov    rcx,r15
  409183:	mov    rdx,rsi
  409186:	xor    r8d,r8d
  409189:	call   40d120 <__swc_fn_23cea7fa_000094_63c1827b>
  40918e:	test   al,al
  409190:	jne    4091fe <__swc_fn_23cea7fa_000093_c2567a3b+0x30e>
  409192:	test   DWORD PTR [rsi+0x28],0x10000
  409199:	je     4091b7 <__swc_fn_23cea7fa_000093_c2567a3b+0x2c7>
  40919b:	rex mov al,BYTE PTR [rsp+0x8]
  4091a0:	test   al,al
  4091a2:	jne    4091b7 <__swc_fn_23cea7fa_000093_c2567a3b+0x2c7>
  4091a4:	xor    eax,eax
  4091a6:	add    rsp,0x38
  4091aa:	pop    r15
  4091ac:	pop    r14
  4091ae:	pop    r13
  4091b0:	pop    r12
  4091b2:	pop    rdi
  4091b3:	pop    rsi
  4091b4:	pop    rbx
  4091b5:	pop    rbp
  4091b6:	ret
  4091b7:	test   rdi,rdi
  4091ba:	jne    4091cf <__swc_fn_23cea7fa_000093_c2567a3b+0x2df>
  4091bc:	xor    eax,eax
  4091be:	add    rsp,0x38
  4091c2:	pop    r15
  4091c4:	pop    r14
  4091c6:	pop    r13
  4091c8:	pop    r12
  4091ca:	pop    rdi
  4091cb:	pop    rsi
  4091cc:	pop    rbx
  4091cd:	pop    rbp
  4091ce:	ret
  4091cf:	cmp    QWORD PTR [rdi+0x8],0x0
  4091d4:	jne    4091e9 <__swc_fn_23cea7fa_000093_c2567a3b+0x2f9>
  4091d6:	xor    eax,eax
  4091d8:	add    rsp,0x38
  4091dc:	pop    r15
  4091de:	pop    r14
  4091e0:	pop    r13
  4091e2:	pop    r12
  4091e4:	pop    rdi
  4091e5:	pop    rsi
  4091e6:	pop    rbx
  4091e7:	pop    rbp
  4091e8:	ret
  4091e9:	mov    rax,QWORD PTR [rdi+0x8]
  4091ed:	mov    rax,QWORD PTR [rax]
  4091f0:	mov    rsi,rax
  4091f3:	mov    rdi,QWORD PTR [rdi]
  4091f6:	mov    eax,0x1
  4091fb:	mov    r14b,al
  4091fe:	test   rdi,rdi
  409201:	mov    rbx,QWORD PTR [rsp+0x20]
  409206:	jne    409250 <__swc_fn_23cea7fa_000093_c2567a3b+0x360>
  409208:	test   r14b,r14b
  40920b:	je     40923d <__swc_fn_23cea7fa_000093_c2567a3b+0x34d>
  40920d:	test   r12,r12
  409210:	je     40923d <__swc_fn_23cea7fa_000093_c2567a3b+0x34d>
  409212:	mov    rcx,r15
  409215:	mov    rdx,rsi
  409218:	xor    r8d,r8d
  40921b:	mov    r9,r12
  40921e:	mov    rbx,QWORD PTR [rsp+0x20]
  409223:	movzx  r10d,BYTE PTR [rbx]
  409227:	call   408de0 <__swc_fn_23cea7fa_000087_ef55f6e4>
  40922c:	add    rsp,0x38
  409230:	pop    r15
  409232:	pop    r14
  409234:	pop    r13
  409236:	pop    r12
  409238:	pop    rdi
  409239:	pop    rsi
  40923a:	pop    rbx
  40923b:	pop    rbp
  40923c:	ret
  40923d:	xor    eax,eax
  40923f:	add    rsp,0x38
  409243:	pop    r15
  409245:	pop    r14
  409247:	pop    r13
  409249:	pop    r12
  40924b:	pop    rdi
  40924c:	pop    rsi
  40924d:	pop    rbx
  40924e:	pop    rbp
  40924f:	ret
  409250:	mov    r13,rsi
  409253:	mov    QWORD PTR [rsp+0x28],rdi
  409258:	cmp    BYTE PTR [r15+0x2c],0xe
  40925d:	sete   al
  409260:	mov    r14b,al
  409263:	jne    409277 <__swc_fn_23cea7fa_000093_c2567a3b+0x387>
  409265:	mov    rcx,rsi
  409268:	mov    rdx,r15
  40926b:	call   410be0 <__swc_fn_23cea7fa_000089_d182c4dc>
  409270:	mov    r14b,al
  409273:	test   al,al
  409275:	jne    4092ac <__swc_fn_23cea7fa_000093_c2567a3b+0x3bc>
  409277:	cmp    BYTE PTR [r15+0x2c],0x12
  40927c:	je     4092ac <__swc_fn_23cea7fa_000093_c2567a3b+0x3bc>
  40927e:	mov    rcx,r15
  409281:	mov    rdx,rsi
  409284:	mov    r8,rdi
  409287:	mov    r9,r12
  40928a:	mov    rax,rbx
  40928d:	movzx  r10d,BYTE PTR [rax]
  409291:	call   408de0 <__swc_fn_23cea7fa_000087_ef55f6e4>
  409296:	test   rax,rax
  409299:	je     4092ac <__swc_fn_23cea7fa_000093_c2567a3b+0x3bc>
  40929b:	add    rsp,0x38
  40929f:	pop    r15
  4092a1:	pop    r14
  4092a3:	pop    r13
  4092a5:	pop    r12
  4092a7:	pop    rdi
  4092a8:	pop    rsi
  4092a9:	pop    rbx
  4092aa:	pop    rbp
  4092ab:	ret
  4092ac:	rex cmp BYTE PTR [rsi+0x2c],0xe
  4092b1:	jne    4092d0 <__swc_fn_23cea7fa_000093_c2567a3b+0x3e0>
  4092b3:	mov    rax,QWORD PTR [rsi+0xd8]
  4092ba:	test   rax,rax
  4092bd:	je     4092d0 <__swc_fn_23cea7fa_000093_c2567a3b+0x3e0>
  4092bf:	add    rdi,QWORD PTR [rax+0x8]
  4092c3:	mov    rax,QWORD PTR [rdi]
  4092c6:	sub    rdi,QWORD PTR [rax+0x8]
  4092ca:	mov    rax,QWORD PTR [rax]
  4092cd:	mov    rsi,rax
  4092d0:	test   r14b,r14b
  4092d3:	je     4092ff <__swc_fn_23cea7fa_000093_c2567a3b+0x40f>
  4092d5:	mov    rcx,r15
  4092d8:	mov    rdx,rsi
  4092db:	mov    r8,rdi
  4092de:	mov    r9,r13
  4092e1:	mov    r14,QWORD PTR [rsp+0x28]
  4092e6:	mov    r10,r14
  4092e9:	call   40d000 <__swc_fn_23cea7fa_000091_c1c9085b>
  4092ee:	add    rsp,0x38
  4092f2:	pop    r15
  4092f4:	pop    r14
  4092f6:	pop    r13
  4092f8:	pop    r12
  4092fa:	pop    rdi
  4092fb:	pop    rsi
  4092fc:	pop    rbx
  4092fd:	pop    rbp
  4092fe:	ret
  4092ff:	mov    rcx,r15
  409302:	mov    rdx,rsi
  409305:	mov    r8,rdi
  409308:	mov    r9,r12
  40930b:	movzx  r10d,BYTE PTR [rbx]
  40930f:	call   408de0 <__swc_fn_23cea7fa_000087_ef55f6e4>
  409314:	add    rsp,0x38
  409318:	pop    r15
  40931a:	pop    r14
  40931c:	pop    r13
  40931e:	pop    r12
  409320:	pop    rdi
  409321:	pop    rsi
  409322:	pop    rbx
  409323:	pop    rbp
  409324:	ret
	...

0000000000409330 <__swc_fn_23cea7fa_000096_93bfe675>:
  409330:	push   rbx
  409331:	push   rsi
  409332:	sub    rsp,0x18
  409336:	mov    rbx,rcx
  409339:	mov    rcx,QWORD PTR [rip+0x1ad00]        # 424040 <__swc_bss_base_23cea7fa>
  409340:	test   rcx,rcx
  409343:	jne    409355 <__swc_fn_23cea7fa_000096_93bfe675+0x25>
  409345:	call   40ed20 <__swc_fn_23cea7fa_000169_994c8876>
  40934a:	lea    rcx,[rax+0x1]
  40934e:	mov    QWORD PTR [rip+0x1aceb],rcx        # 424040 <__swc_bss_base_23cea7fa>
  409355:	dec    rcx
  409358:	call   40bbe0 <__swc_fn_23cea7fa_000171_360af05d>
  40935d:	mov    rsi,rax
  409360:	mov    rax,QWORD PTR [rsi+0x8]
  409364:	test   rax,rax
  409367:	jne    4093b7 <__swc_fn_23cea7fa_000096_93bfe675+0x87>
  409369:	call   410cd0 <__swc_fn_23cea7fa_000095_ad13d15c>
  40936e:	test   al,al
  409370:	jne    4093b7 <__swc_fn_23cea7fa_000096_93bfe675+0x87>
  409372:	lea    rdx,[rip+0x1aec7]        # 424240 <__swc_bss_base_23cea7fa+0x200>
  409379:	mov    rcx,rdx
  40937c:	call   40c2d0 <__swc_fn_23cea7fa_000040_eb6108f2>
  409381:	test   al,al
  409383:	jne    409394 <__swc_fn_23cea7fa_000096_93bfe675+0x64>
  409385:	mov    rcx,rdx
  409388:	call   40f5c0 <__swc_fn_23cea7fa_000038_14f56618>
  40938d:	lea    rdx,[rip+0x1aeac]        # 424240 <__swc_bss_base_23cea7fa+0x200>
  409394:	mov    QWORD PTR [rsp+0x8],rdx
  409399:	lea    rax,[rip+0x9ed8]        # 413278 <__swc_rdata_base_23cea7fa+0x168>
  4093a0:	mov    QWORD PTR [rsp+0x10],rax
  4093a5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4093ab:	vmovups XMMWORD PTR [rsi],xmm0
  4093af:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  4093b7:	vmovups xmm0,XMMWORD PTR [rsi]
  4093bb:	vmovups XMMWORD PTR [rbx],xmm0
  4093bf:	mov    rax,rbx
  4093c2:	add    rsp,0x18
  4093c6:	pop    rsi
  4093c7:	pop    rbx
  4093c8:	ret
  4093c9:	add    BYTE PTR [rax],al
  4093cb:	add    BYTE PTR [rax],al
  4093cd:	add    BYTE PTR [rax],al
	...

00000000004093d0 <__swc_fn_23cea7fa_000099_65137b72>:
  4093d0:	sub    rsp,0x8
  4093d4:	call   40dec0 <__swc_fn_23cea7fa_000121_0a5fa85a>
  4093d9:	add    rsp,0x8
  4093dd:	ret
	...

00000000004093e0 <__swc_fn_23cea7fa_000102_e34f54dc>:
  4093e0:	push   rbx
  4093e1:	push   rsi
  4093e2:	sub    rsp,0x28
  4093e6:	mov    rbx,rcx
  4093e9:	xor    esi,esi
  4093eb:	jmp    409400 <__swc_fn_23cea7fa_000102_e34f54dc+0x20>
  4093ed:	nop    DWORD PTR [rax]
  4093f0:	mov    QWORD PTR [rbx+0x28],rsi
  4093f4:	mov    rsi,rbx
  4093f7:	mov    rbx,rax
  4093fa:	nop    WORD PTR [rax+rax*1+0x0]
  409400:	test   rbx,rbx
  409403:	je     409463 <__swc_fn_23cea7fa_000102_e34f54dc+0x83>
  409405:	mov    rcx,rbx
  409408:	mov    edx,0x1
  40940d:	call   40cd80 <__swc_fn_23cea7fa_000082_63a67586>
  409412:	cmp    rax,0x1
  409416:	jne    409463 <__swc_fn_23cea7fa_000102_e34f54dc+0x83>
  409418:	mov    r10,QWORD PTR [rbx+0x18]
  40941c:	mov    rcx,r10
  40941f:	mov    edx,0x1
  409424:	call   40cd80 <__swc_fn_23cea7fa_000082_63a67586>
  409429:	cmp    rax,0x1
  40942d:	jne    40943c <__swc_fn_23cea7fa_000102_e34f54dc+0x5c>
  40942f:	mov    rcx,r10
  409432:	call   410e70 <__swc_fn_23cea7fa_000101_d0b19c14>
  409437:	test   rax,rax
  40943a:	jne    4093f0 <__swc_fn_23cea7fa_000102_e34f54dc+0x10>
  40943c:	mov    rax,QWORD PTR [rbx+0x20]
  409440:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  409445:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40944b:	lea    rcx,[rsp+0x8]
  409450:	mov    rdx,rbx
  409453:	mov    r8d,0x30
  409459:	mov    rbx,rax
  40945c:	call   40d4e0 <__swc_fn_23cea7fa_000100_d4bdcaa4>
  409461:	jmp    409400 <__swc_fn_23cea7fa_000102_e34f54dc+0x20>
  409463:	test   rsi,rsi
  409466:	jne    40946f <__swc_fn_23cea7fa_000102_e34f54dc+0x8f>
  409468:	add    rsp,0x28
  40946c:	pop    rsi
  40946d:	pop    rbx
  40946e:	ret
  40946f:	mov    rax,rsi
  409472:	mov    rsi,QWORD PTR [rsi+0x28]
  409476:	mov    rbx,QWORD PTR [rax+0x20]
  40947a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40947f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409485:	lea    rcx,[rsp+0x18]
  40948a:	mov    rdx,rax
  40948d:	mov    r8d,0x30
  409493:	call   40d4e0 <__swc_fn_23cea7fa_000100_d4bdcaa4>
  409498:	jmp    409400 <__swc_fn_23cea7fa_000102_e34f54dc+0x20>
  40949d:	add    BYTE PTR [rax],al
	...

00000000004094a0 <__swc_fn_23cea7fa_000105_5a85fcf5>:
  4094a0:	push   rbx
  4094a1:	push   rsi
  4094a2:	push   rdi
  4094a3:	push   r12
  4094a5:	push   r13
  4094a7:	sub    rsp,0x20
  4094ab:	mov    rbx,rcx
  4094ae:	lea    rsi,[rcx+0x6f8]
  4094b5:	mov    edi,0x4
  4094ba:	mov    r12,rsi
  4094bd:	test   rdi,rdi
  4094c0:	je     40950a <__swc_fn_23cea7fa_000105_5a85fcf5+0x6a>
  4094c2:	cs nop WORD PTR [rax+rax*1+0x0]
  4094cc:	nop    DWORD PTR [rax+0x0]
  4094d0:	mov    rcx,QWORD PTR [r12+0x10]
  4094d5:	mov    QWORD PTR [r12+0x10],0x0
  4094de:	vxorps xmm0,xmm0,xmm0
  4094e2:	vmovups XMMWORD PTR [r12],xmm0
  4094e8:	vmovups XMMWORD PTR [r12+0x28],xmm0
  4094ef:	mov    DWORD PTR [r12+0x20],0x0
  4094f8:	call   40d530 <__swc_fn_23cea7fa_000103_2fdd2c61>
  4094fd:	add    r12,0x90
  409504:	sub    rdi,0x1
  409508:	jne    4094d0 <__swc_fn_23cea7fa_000105_5a85fcf5+0x30>
  40950a:	mov    rax,QWORD PTR [rbx+0x938]
  409511:	mov    rdi,rax
  409514:	test   rdi,rdi
  409517:	je     409571 <__swc_fn_23cea7fa_000105_5a85fcf5+0xd1>
  409519:	nop    DWORD PTR [rax+0x0]
  409520:	mov    r12d,0x10
  409526:	lea    r13,[rdi+0x18]
  40952a:	test   r12,r12
  40952d:	je     409566 <__swc_fn_23cea7fa_000105_5a85fcf5+0xc6>
  40952f:	nop
  409530:	mov    rcx,QWORD PTR [r13+0x10]
  409534:	mov    QWORD PTR [r13+0x10],0x0
  40953c:	vxorps xmm0,xmm0,xmm0
  409540:	vmovups XMMWORD PTR [r13+0x0],xmm0
  409546:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40954c:	mov    DWORD PTR [r13+0x20],0x0
  409554:	call   40d530 <__swc_fn_23cea7fa_000103_2fdd2c61>
  409559:	add    r13,0x90
  409560:	sub    r12,0x1
  409564:	jne    409530 <__swc_fn_23cea7fa_000105_5a85fcf5+0x90>
  409566:	mov    rax,QWORD PTR [rdi]
  409569:	mov    rdi,rax
  40956c:	test   rax,rax
  40956f:	jne    409520 <__swc_fn_23cea7fa_000105_5a85fcf5+0x80>
  409571:	vxorps xmm0,xmm0,xmm0
  409575:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40957d:	mov    DWORD PTR [rbx+0x9b0],0x0
  409587:	mov    DWORD PTR [rbx+0x9a8],0x0
  409591:	mov    edi,0x4
  409596:	mov    r12,rsi
  409599:	lea    rsi,[rsi+0x38]
  40959d:	test   rdi,rdi
  4095a0:	je     4095cc <__swc_fn_23cea7fa_000105_5a85fcf5+0x12c>
  4095a2:	cs nop WORD PTR [rax+rax*1+0x0]
  4095ac:	nop    DWORD PTR [rax+0x0]
  4095b0:	mov    rcx,rsi
  4095b3:	call   411cf0 <__swc_fn_23cea7fa_000161_13ead2ff>
  4095b8:	add    rsi,0x90
  4095bf:	add    r12,0x90
  4095c6:	sub    rdi,0x1
  4095ca:	jne    4095b0 <__swc_fn_23cea7fa_000105_5a85fcf5+0x110>
  4095cc:	mov    rax,QWORD PTR [rbx+0x938]
  4095d3:	mov    rdi,rax
  4095d6:	mov    QWORD PTR [rbx+0x938],0x0
  4095e1:	test   rdi,rdi
  4095e4:	je     409655 <__swc_fn_23cea7fa_000105_5a85fcf5+0x1b5>
  4095ea:	nop    WORD PTR [rax+rax*1+0x0]
  4095f0:	mov    esi,0x10
  4095f5:	lea    r12,[rdi+0x18]
  4095f9:	lea    r13,[rdi+0x50]
  4095fd:	test   rsi,rsi
  409600:	je     40962c <__swc_fn_23cea7fa_000105_5a85fcf5+0x18c>
  409602:	cs nop WORD PTR [rax+rax*1+0x0]
  40960c:	nop    DWORD PTR [rax+0x0]
  409610:	mov    rcx,r13
  409613:	call   411cf0 <__swc_fn_23cea7fa_000161_13ead2ff>
  409618:	add    r13,0x90
  40961f:	add    r12,0x90
  409626:	sub    rsi,0x1
  40962a:	jne    409610 <__swc_fn_23cea7fa_000105_5a85fcf5+0x170>
  40962c:	mov    rax,QWORD PTR [rdi]
  40962f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  409634:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40963a:	lea    rcx,[rsp+0x8]
  40963f:	mov    rdx,rdi
  409642:	mov    r8d,0x918
  409648:	mov    rdi,rax
  40964b:	call   40d4e0 <__swc_fn_23cea7fa_000100_d4bdcaa4>
  409650:	test   rdi,rdi
  409653:	jne    4095f0 <__swc_fn_23cea7fa_000105_5a85fcf5+0x150>
  409655:	lea    rcx,[rbx+0x68]
  409659:	call   411cf0 <__swc_fn_23cea7fa_000161_13ead2ff>
  40965e:	add    rsp,0x20
  409662:	pop    r13
  409664:	pop    r12
  409666:	pop    rdi
  409667:	pop    rsi
  409668:	pop    rbx
  409669:	ret
  40966a:	add    BYTE PTR [rax],al
  40966c:	add    BYTE PTR [rax],al
	...

0000000000409670 <__swc_fn_23cea7fa_000108_c51c3158>:
  409670:	xor    eax,eax
  409672:	cs nop WORD PTR [rax+rax*1+0x0]
  40967c:	nop    DWORD PTR [rax+0x0]
  409680:	mov    r9,r8
  409683:	sub    r9,rax
  409686:	cmp    r9,0x40
  40968a:	jb     4096c8 <__swc_fn_23cea7fa_000108_c51c3158+0x58>
  40968c:	lea    r9,[rcx+rax*1]
  409690:	lea    r10,[rdx+rax*1]
  409694:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40969a:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  4096a0:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  4096a6:	vmovups xmm3,XMMWORD PTR [r10]
  4096ab:	vmovups XMMWORD PTR [r9],xmm3
  4096b0:	vmovups XMMWORD PTR [r9+0x10],xmm0
  4096b6:	vmovups XMMWORD PTR [r9+0x20],xmm1
  4096bc:	vmovups XMMWORD PTR [r9+0x30],xmm2
  4096c2:	lea    rax,[rax+0x40]
  4096c6:	jmp    409680 <__swc_fn_23cea7fa_000108_c51c3158+0x10>
  4096c8:	nop    DWORD PTR [rax+rax*1+0x0]
  4096d0:	mov    r9,r8
  4096d3:	sub    r9,rax
  4096d6:	cmp    r9,0x10
  4096da:	jb     4096f4 <__swc_fn_23cea7fa_000108_c51c3158+0x84>
  4096dc:	lea    r9,[rdx+rax*1]
  4096e0:	lea    r10,[rcx+rax*1]
  4096e4:	vmovups xmm0,XMMWORD PTR [r9]
  4096e9:	vmovups XMMWORD PTR [r10],xmm0
  4096ee:	lea    rax,[rax+0x10]
  4096f2:	jmp    4096d0 <__swc_fn_23cea7fa_000108_c51c3158+0x60>
  4096f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4096fe:	xchg   ax,ax
  409700:	mov    r9,r8
  409703:	sub    r9,rax
  409706:	cmp    r9,0x8
  40970a:	jb     40971d <__swc_fn_23cea7fa_000108_c51c3158+0xad>
  40970c:	lea    r9,[rcx+rax*1]
  409710:	mov    r10,QWORD PTR [rdx+rax*1]
  409714:	mov    QWORD PTR [r9],r10
  409717:	lea    rax,[rax+0x8]
  40971b:	jmp    409700 <__swc_fn_23cea7fa_000108_c51c3158+0x90>
  40971d:	cmp    rax,r8
  409720:	jae    409740 <__swc_fn_23cea7fa_000108_c51c3158+0xd0>
  409722:	cs nop WORD PTR [rax+rax*1+0x0]
  40972c:	nop    DWORD PTR [rax+0x0]
  409730:	mov    r9b,BYTE PTR [rdx+rax*1]
  409734:	mov    BYTE PTR [rcx+rax*1],r9b
  409738:	inc    rax
  40973b:	cmp    rax,r8
  40973e:	jb     409730 <__swc_fn_23cea7fa_000108_c51c3158+0xc0>
  409740:	ret
	...

0000000000409750 <__swc_fn_23cea7fa_000111_6814119b>:
  409750:	push   rbx
  409751:	push   r12
  409753:	push   rdi
  409754:	push   rsi
  409755:	push   r13
  409757:	push   r14
  409759:	push   r15
  40975b:	sub    rsp,0x170
  409762:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40976b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  409774:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40977d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  409786:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40978f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  409798:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  4097a1:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  4097aa:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  4097b3:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  4097bc:	mov    ebx,edx
  4097be:	mov    QWORD PTR [rsp+0xa8],rbx
  4097c6:	mov    r12d,ecx
  4097c9:	test   edx,edx
  4097cb:	jne    4097e2 <__swc_fn_23cea7fa_000111_6814119b+0x92>
  4097cd:	xor    eax,eax
  4097cf:	add    rsp,0x170
  4097d6:	pop    r15
  4097d8:	pop    r14
  4097da:	pop    r13
  4097dc:	pop    rsi
  4097dd:	pop    rdi
  4097de:	pop    r12
  4097e0:	pop    rbx
  4097e1:	ret
  4097e2:	lea    rdi,[rip+0x9d97]        # 413580 <__swc_rdata_base_23cea7fa+0x470>
  4097e9:	mov    esi,0x90000
  4097ee:	xor    eax,eax
  4097f0:	call   407010 <open@plt>
  4097f5:	mov    r13,rax
  4097f8:	mov    QWORD PTR [rsp+0xb0],rax
  409800:	test   eax,eax
  409802:	jge    40980b <__swc_fn_23cea7fa_000111_6814119b+0xbb>
  409804:	xor    eax,eax
  409806:	jmp    409d06 <__swc_fn_23cea7fa_000111_6814119b+0x5b6>
  40980b:	nop    DWORD PTR [rax+rax*1+0x0]
  409810:	movsxd rdi,r13d
  409813:	mov    esi,0x2
  409818:	xor    eax,eax
  40981a:	call   407020 <flock@plt>
  40981f:	test   eax,eax
  409821:	je     409840 <__swc_fn_23cea7fa_000111_6814119b+0xf0>
  409823:	xor    eax,eax
  409825:	call   407030 <__errno_location@plt>
  40982a:	cmp    DWORD PTR [rax],0x4
  40982d:	je     409810 <__swc_fn_23cea7fa_000111_6814119b+0xc0>
  40982f:	movsxd rdi,r13d
  409832:	xor    eax,eax
  409834:	call   407040 <close@plt>
  409839:	xor    eax,eax
  40983b:	jmp    409d06 <__swc_fn_23cea7fa_000111_6814119b+0x5b6>
  409840:	lea    r14,[rsp+0x8]
  409845:	mov    QWORD PTR [rsp+0xb8],r14
  40984d:	vxorps xmm0,xmm0,xmm0
  409851:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409857:	mov    QWORD PTR [rsp+0x18],0x0
  409860:	mov    WORD PTR [rsp+0x20],0x0
  409867:	mov    DWORD PTR [r14],0x67617753
  40986e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  409876:	xor    eax,eax
  409878:	call   407050 <getpid@plt>
  40987d:	mov    ecx,eax
  40987f:	mov    eax,0x1c
  409884:	shrx   eax,ecx,eax
  409889:	and    eax,0xf
  40988c:	mov    rdx,QWORD PTR [rip+0x9d0d]        # 4135a0 <__swc_rdata_base_23cea7fa+0x490>
  409893:	mov    al,BYTE PTR [rdx+rax*1]
  409896:	rex mov BYTE PTR [rsp+0x10],al
  40989b:	mov    eax,0x1c
  4098a0:	shrx   eax,r12d,eax
  4098a5:	and    eax,0xf
  4098a8:	mov    al,BYTE PTR [rdx+rax*1]
  4098ab:	rex mov BYTE PTR [rsp+0x19],al
  4098b0:	mov    eax,0x18
  4098b5:	shrx   eax,ecx,eax
  4098ba:	and    eax,0xf
  4098bd:	mov    al,BYTE PTR [rdx+rax*1]
  4098c0:	rex mov BYTE PTR [rsp+0x11],al
  4098c5:	mov    eax,0x18
  4098ca:	shrx   eax,r12d,eax
  4098cf:	and    eax,0xf
  4098d2:	mov    al,BYTE PTR [rdx+rax*1]
  4098d5:	rex mov BYTE PTR [rsp+0x1a],al
  4098da:	mov    eax,0x14
  4098df:	shrx   eax,ecx,eax
  4098e4:	and    eax,0xf
  4098e7:	mov    al,BYTE PTR [rdx+rax*1]
  4098ea:	rex mov BYTE PTR [rsp+0x12],al
  4098ef:	mov    eax,0x14
  4098f4:	shrx   eax,r12d,eax
  4098f9:	and    eax,0xf
  4098fc:	mov    al,BYTE PTR [rdx+rax*1]
  4098ff:	rex mov BYTE PTR [rsp+0x1b],al
  409904:	mov    eax,0x10
  409909:	shrx   eax,ecx,eax
  40990e:	and    eax,0xf
  409911:	mov    al,BYTE PTR [rdx+rax*1]
  409914:	rex mov BYTE PTR [rsp+0x13],al
  409919:	mov    eax,0x10
  40991e:	shrx   eax,r12d,eax
  409923:	and    eax,0xf
  409926:	mov    al,BYTE PTR [rdx+rax*1]
  409929:	rex mov BYTE PTR [rsp+0x1c],al
  40992e:	mov    eax,0xc
  409933:	shrx   eax,ecx,eax
  409938:	and    eax,0xf
  40993b:	mov    al,BYTE PTR [rdx+rax*1]
  40993e:	rex mov BYTE PTR [rsp+0x14],al
  409943:	mov    eax,0xc
  409948:	shrx   eax,r12d,eax
  40994d:	and    eax,0xf
  409950:	mov    al,BYTE PTR [rdx+rax*1]
  409953:	rex mov BYTE PTR [rsp+0x1d],al
  409958:	mov    eax,0x8
  40995d:	shrx   eax,ecx,eax
  409962:	and    eax,0xf
  409965:	mov    al,BYTE PTR [rdx+rax*1]
  409968:	rex mov BYTE PTR [rsp+0x15],al
  40996d:	mov    eax,0x8
  409972:	shrx   eax,r12d,eax
  409977:	and    eax,0xf
  40997a:	mov    al,BYTE PTR [rdx+rax*1]
  40997d:	rex mov BYTE PTR [rsp+0x1e],al
  409982:	mov    eax,0x4
  409987:	shrx   eax,ecx,eax
  40998c:	and    eax,0xf
  40998f:	mov    al,BYTE PTR [rdx+rax*1]
  409992:	rex mov BYTE PTR [rsp+0x16],al
  409997:	mov    eax,0x4
  40999c:	shrx   eax,r12d,eax
  4099a1:	and    eax,0xf
  4099a4:	mov    al,BYTE PTR [rdx+rax*1]
  4099a7:	rex mov BYTE PTR [rsp+0x1f],al
  4099ac:	xor    eax,eax
  4099ae:	shrx   eax,ecx,eax
  4099b3:	and    eax,0xf
  4099b6:	mov    al,BYTE PTR [rdx+rax*1]
  4099b9:	rex mov BYTE PTR [rsp+0x17],al
  4099be:	xor    eax,eax
  4099c0:	shrx   eax,r12d,eax
  4099c5:	and    eax,0xf
  4099c8:	mov    al,BYTE PTR [rdx+rax*1]
  4099cb:	rex mov BYTE PTR [rsp+0x20],al
  4099d0:	mov    BYTE PTR [r14+0x10],0x2e
  4099d5:	lea    r12,[rsp+0x22]
  4099da:	vxorps xmm0,xmm0,xmm0
  4099de:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  4099e4:	mov    DWORD PTR [r12],0x6d656d2f
  4099ec:	mov    WORD PTR [r12+0x4],0x6466
  4099f4:	mov    BYTE PTR [r12+0x6],0x3a
  4099fa:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409a00:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  409a06:	mov    rax,QWORD PTR [rsp+0x18]
  409a0b:	mov    QWORD PTR [rsp+0x39],rax
  409a10:	rex mov al,BYTE PTR [rsp+0x20]
  409a15:	rex mov BYTE PTR [rsp+0x41],al
  409a1a:	mov    DWORD PTR [r12+0x20],0x65642820
  409a23:	mov    DWORD PTR [r12+0x24],0x6574656c
  409a2c:	mov    WORD PTR [r12+0x28],0x2964
  409a34:	lea    rdi,[rip+0x9b50]        # 41358b <__swc_rdata_base_23cea7fa+0x47b>
  409a3b:	xor    eax,eax
  409a3d:	call   407060 <opendir@plt>
  409a42:	mov    r15,rax
  409a45:	test   rax,rax
  409a48:	jne    409a5b <__swc_fn_23cea7fa_000111_6814119b+0x30b>
  409a4a:	movsxd rdi,r13d
  409a4d:	xor    eax,eax
  409a4f:	call   407040 <close@plt>
  409a54:	xor    eax,eax
  409a56:	jmp    409d06 <__swc_fn_23cea7fa_000111_6814119b+0x5b6>
  409a5b:	mov    rdi,r15
  409a5e:	xor    eax,eax
  409a60:	call   407070 <dirfd@plt>
  409a65:	lea    r14,[rsp+0x54]
  409a6a:	mov    DWORD PTR [rsp+0x54],eax
  409a6e:	lea    rbx,[rsp+0x58]
  409a73:	cs nop WORD PTR [rax+rax*1+0x0]
  409a7d:	nop    DWORD PTR [rax]
  409a80:	mov    rdi,r15
  409a83:	xor    eax,eax
  409a85:	call   407080 <readdir@plt>
  409a8a:	test   rax,rax
  409a8d:	jne    409aa4 <__swc_fn_23cea7fa_000111_6814119b+0x354>
  409a8f:	mov    r12,QWORD PTR [rsp+0xa8]
  409a97:	mov    r13,QWORD PTR [rsp+0xb0]
  409a9f:	jmp    409c2a <__swc_fn_23cea7fa_000111_6814119b+0x4da>
  409aa4:	vxorps xmm0,xmm0,xmm0
  409aa8:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  409aae:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  409ab4:	vzeroupper
  409ab7:	lea    r13,[rax+0x13]
  409abb:	mov    rax,r14
  409abe:	movsxd rdi,DWORD PTR [rax]
  409ac1:	mov    rsi,r13
  409ac4:	mov    rdx,rbx
  409ac7:	mov    ecx,0x40
  409acc:	xor    eax,eax
  409ace:	call   407090 <readlinkat@plt>
  409ad3:	cmp    rax,0x2a
  409ad7:	jne    409a80 <__swc_fn_23cea7fa_000111_6814119b+0x330>
  409ad9:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  409adf:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  409ae5:	vptest xmm0,xmm0
  409aea:	jne    409b1a <__swc_fn_23cea7fa_000111_6814119b+0x3ca>
  409aec:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  409af2:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  409af8:	vptest xmm0,xmm0
  409afd:	jne    409b1a <__swc_fn_23cea7fa_000111_6814119b+0x3ca>
  409aff:	mov    rcx,QWORD PTR [rsp+0x42]
  409b04:	cmp    QWORD PTR [rsp+0x78],rcx
  409b09:	jne    409b1a <__swc_fn_23cea7fa_000111_6814119b+0x3ca>
  409b0b:	mov    cx,WORD PTR [rsp+0x4a]
  409b10:	cmp    WORD PTR [rsp+0x80],cx
  409b18:	je     409b44 <__swc_fn_23cea7fa_000111_6814119b+0x3f4>
  409b1a:	mov    rax,rbx
  409b1d:	mov    rcx,r12
  409b20:	movzx  edx,BYTE PTR [rax]
  409b23:	movzx  r8d,BYTE PTR [rcx]
  409b27:	cmp    rdx,r8
  409b2a:	jne    409b36 <__swc_fn_23cea7fa_000111_6814119b+0x3e6>
  409b2c:	add    rax,0x1
  409b30:	add    rcx,0x1
  409b34:	jmp    409b20 <__swc_fn_23cea7fa_000111_6814119b+0x3d0>
  409b36:	mov    rax,rdx
  409b39:	sub    rax,r8
  409b3c:	test   eax,eax
  409b3e:	jne    409a80 <__swc_fn_23cea7fa_000111_6814119b+0x330>
  409b44:	movsxd rdi,DWORD PTR [r14]
  409b47:	mov    rsi,r13
  409b4a:	mov    edx,0x80002
  409b4f:	xor    eax,eax
  409b51:	call   4070a0 <openat@plt>
  409b56:	lea    rbx,[rsp+0x98]
  409b5e:	mov    DWORD PTR [rsp+0x98],eax
  409b65:	test   eax,eax
  409b67:	mov    r13,QWORD PTR [rsp+0xb0]
  409b6f:	jge    409b94 <__swc_fn_23cea7fa_000111_6814119b+0x444>
  409b71:	mov    rdi,r15
  409b74:	xor    eax,eax
  409b76:	call   4070b0 <closedir@plt>
  409b7b:	mov    r13,QWORD PTR [rsp+0xb0]
  409b83:	movsxd rdi,r13d
  409b86:	xor    eax,eax
  409b88:	call   407040 <close@plt>
  409b8d:	xor    eax,eax
  409b8f:	jmp    409d06 <__swc_fn_23cea7fa_000111_6814119b+0x5b6>
  409b94:	mov    rax,rbx
  409b97:	movsxd rdi,DWORD PTR [rax]
  409b9a:	xor    esi,esi
  409b9c:	mov    edx,0x2
  409ba1:	xor    eax,eax
  409ba3:	call   4070c0 <lseek@plt>
  409ba8:	mov    r12,QWORD PTR [rsp+0xa8]
  409bb0:	cmp    rax,r12
  409bb3:	je     409bda <__swc_fn_23cea7fa_000111_6814119b+0x48a>
  409bb5:	movsxd rdi,DWORD PTR [rbx]
  409bb8:	xor    eax,eax
  409bba:	call   407040 <close@plt>
  409bbf:	mov    rdi,r15
  409bc2:	xor    eax,eax
  409bc4:	call   4070b0 <closedir@plt>
  409bc9:	movsxd rdi,r13d
  409bcc:	xor    eax,eax
  409bce:	call   407040 <close@plt>
  409bd3:	xor    eax,eax
  409bd5:	jmp    409d06 <__swc_fn_23cea7fa_000111_6814119b+0x5b6>
  409bda:	xor    edi,edi
  409bdc:	mov    rsi,r12
  409bdf:	mov    edx,0x3
  409be4:	mov    ecx,0x1
  409be9:	mov    rax,rbx
  409bec:	movsxd r8,DWORD PTR [rax]
  409bef:	xor    r9d,r9d
  409bf2:	xor    eax,eax
  409bf4:	call   4070d0 <mmap@plt>
  409bf9:	xor    r12d,r12d
  409bfc:	cmp    rax,0xffffffffffffffff
  409c00:	cmovne r12,rax
  409c04:	movsxd rdi,DWORD PTR [rbx]
  409c07:	xor    eax,eax
  409c09:	call   407040 <close@plt>
  409c0e:	mov    rdi,r15
  409c11:	xor    eax,eax
  409c13:	call   4070b0 <closedir@plt>
  409c18:	movsxd rdi,r13d
  409c1b:	xor    eax,eax
  409c1d:	call   407040 <close@plt>
  409c22:	mov    rax,r12
  409c25:	jmp    409d06 <__swc_fn_23cea7fa_000111_6814119b+0x5b6>
  409c2a:	mov    r14,QWORD PTR [rsp+0xb8]
  409c32:	mov    rdi,r14
  409c35:	mov    esi,0x1
  409c3a:	xor    eax,eax
  409c3c:	call   4070e0 <memfd_create@plt>
  409c41:	lea    rbx,[rsp+0x9c]
  409c49:	mov    DWORD PTR [rsp+0x9c],eax
  409c50:	test   eax,eax
  409c52:	jge    409c6f <__swc_fn_23cea7fa_000111_6814119b+0x51f>
  409c54:	mov    rdi,r15
  409c57:	xor    eax,eax
  409c59:	call   4070b0 <closedir@plt>
  409c5e:	movsxd rdi,r13d
  409c61:	xor    eax,eax
  409c63:	call   407040 <close@plt>
  409c68:	xor    eax,eax
  409c6a:	jmp    409d06 <__swc_fn_23cea7fa_000111_6814119b+0x5b6>
  409c6f:	mov    rax,rbx
  409c72:	movsxd rdi,DWORD PTR [rax]
  409c75:	mov    rsi,r12
  409c78:	xor    eax,eax
  409c7a:	call   4070f0 <ftruncate@plt>
  409c7f:	test   eax,eax
  409c81:	je     409ca5 <__swc_fn_23cea7fa_000111_6814119b+0x555>
  409c83:	movsxd rdi,DWORD PTR [rbx]
  409c86:	xor    eax,eax
  409c88:	call   407040 <close@plt>
  409c8d:	mov    rdi,r15
  409c90:	xor    eax,eax
  409c92:	call   4070b0 <closedir@plt>
  409c97:	movsxd rdi,r13d
  409c9a:	xor    eax,eax
  409c9c:	call   407040 <close@plt>
  409ca1:	xor    eax,eax
  409ca3:	jmp    409d06 <__swc_fn_23cea7fa_000111_6814119b+0x5b6>
  409ca5:	xor    edi,edi
  409ca7:	mov    rsi,r12
  409caa:	mov    edx,0x3
  409caf:	mov    ecx,0x1
  409cb4:	mov    rax,rbx
  409cb7:	movsxd r8,DWORD PTR [rax]
  409cba:	xor    r9d,r9d
  409cbd:	xor    eax,eax
  409cbf:	call   4070d0 <mmap@plt>
  409cc4:	mov    r12,rax
  409cc7:	cmp    rax,0xffffffffffffffff
  409ccb:	jne    409cef <__swc_fn_23cea7fa_000111_6814119b+0x59f>
  409ccd:	movsxd rdi,DWORD PTR [rbx]
  409cd0:	xor    eax,eax
  409cd2:	call   407040 <close@plt>
  409cd7:	mov    rdi,r15
  409cda:	xor    eax,eax
  409cdc:	call   4070b0 <closedir@plt>
  409ce1:	movsxd rdi,r13d
  409ce4:	xor    eax,eax
  409ce6:	call   407040 <close@plt>
  409ceb:	xor    eax,eax
  409ced:	jmp    409d06 <__swc_fn_23cea7fa_000111_6814119b+0x5b6>
  409cef:	mov    rdi,r15
  409cf2:	xor    eax,eax
  409cf4:	call   4070b0 <closedir@plt>
  409cf9:	movsxd rdi,r13d
  409cfc:	xor    eax,eax
  409cfe:	call   407040 <close@plt>
  409d03:	mov    rax,r12
  409d06:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  409d0f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  409d18:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  409d21:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  409d2a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  409d33:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  409d3c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  409d45:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  409d4e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  409d57:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  409d60:	add    rsp,0x170
  409d67:	pop    r15
  409d69:	pop    r14
  409d6b:	pop    r13
  409d6d:	pop    rsi
  409d6e:	pop    rdi
  409d6f:	pop    r12
  409d71:	pop    rbx
  409d72:	ret
	...

0000000000409d80 <__swc_fn_23cea7fa_000114_5f48311c>:
  409d80:	push   rsi
  409d81:	push   rdi
  409d82:	push   r12
  409d84:	push   r13
  409d86:	sub    rsp,0x8
  409d8a:	mov    rsi,r8
  409d8d:	mov    rdi,rcx
  409d90:	mov    r12,rdx
  409d93:	call   40dc80 <__swc_fn_23cea7fa_000112_126150d1>
  409d98:	mov    r13,rax
  409d9b:	test   rax,rax
  409d9e:	jne    409dab <__swc_fn_23cea7fa_000114_5f48311c+0x2b>
  409da0:	add    rsp,0x8
  409da4:	pop    r13
  409da6:	pop    r12
  409da8:	pop    rdi
  409da9:	pop    rsi
  409daa:	ret
  409dab:	mov    rcx,r13
  409dae:	call   4118f0 <__swc_fn_23cea7fa_000137_8c07c14b>
  409db3:	mov    rax,QWORD PTR [r13+0x8]
  409db7:	test   rax,rax
  409dba:	je     409df9 <__swc_fn_23cea7fa_000114_5f48311c+0x79>
  409dbc:	nop    DWORD PTR [rax+0x0]
  409dc0:	lea    rcx,[rax+0x1000]
  409dc7:	cmp    rdi,rcx
  409dca:	jne    409df1 <__swc_fn_23cea7fa_000114_5f48311c+0x71>
  409dcc:	cmp    r12,0x1000
  409dd3:	jb     409df1 <__swc_fn_23cea7fa_000114_5f48311c+0x71>
  409dd5:	test   sil,sil
  409dd8:	setne  cl
  409ddb:	mov    BYTE PTR [rax+0x10],cl
  409dde:	mov    rcx,r13
  409de1:	call   40a2e0 <__swc_fn_23cea7fa_000138_715e84ff>
  409de6:	add    rsp,0x8
  409dea:	pop    r13
  409dec:	pop    r12
  409dee:	pop    rdi
  409def:	pop    rsi
  409df0:	ret
  409df1:	mov    rax,QWORD PTR [rax]
  409df4:	test   rax,rax
  409df7:	jne    409dc0 <__swc_fn_23cea7fa_000114_5f48311c+0x40>
  409df9:	mov    rcx,r13
  409dfc:	call   40a2e0 <__swc_fn_23cea7fa_000138_715e84ff>
  409e01:	add    rsp,0x8
  409e05:	pop    r13
  409e07:	pop    r12
  409e09:	pop    rdi
  409e0a:	pop    rsi
  409e0b:	ret
  409e0c:	add    BYTE PTR [rax],al
	...

0000000000409e10 <__swc_fn_23cea7fa_000117_ed2d8fed>:
  409e10:	sub    rsp,0x8
  409e14:	test   rcx,rcx
  409e17:	jne    409e1e <__swc_fn_23cea7fa_000117_ed2d8fed+0xe>
  409e19:	add    rsp,0x8
  409e1d:	ret
  409e1e:	call   411400 <__swc_fn_23cea7fa_000119_d3318640>
  409e23:	add    rsp,0x8
  409e27:	ret
	...

0000000000409e30 <__swc_fn_23cea7fa_000120_2648f149>:
  409e30:	push   r12
  409e32:	push   r13
  409e34:	push   r14
  409e36:	push   rdi
  409e37:	push   rsi
  409e38:	sub    rsp,0xc0
  409e3f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409e45:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409e4b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409e51:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409e57:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409e5d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409e63:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409e69:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409e72:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409e7b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409e84:	mov    r12,QWORD PTR [rcx]
  409e87:	test   r12,r12
  409e8a:	jne    409e9c <__swc_fn_23cea7fa_000120_2648f149+0x6c>
  409e8c:	add    rsp,0xc0
  409e93:	pop    rsi
  409e94:	pop    rdi
  409e95:	pop    r14
  409e97:	pop    r13
  409e99:	pop    r12
  409e9b:	ret
  409e9c:	xor    r13d,r13d
  409e9f:	mov    r14,QWORD PTR [rcx+0x8]
  409ea3:	cs nop WORD PTR [rax+rax*1+0x0]
  409ead:	nop    DWORD PTR [rax]
  409eb0:	cmp    r13,r14
  409eb3:	jae    409eeb <__swc_fn_23cea7fa_000120_2648f149+0xbb>
  409eb5:	lea    rax,[r12+r13*1]
  409eb9:	mov    rcx,r14
  409ebc:	sub    rcx,r13
  409ebf:	mov    edi,0x1
  409ec4:	mov    rsi,rax
  409ec7:	mov    rdx,rcx
  409eca:	xor    eax,eax
  409ecc:	call   407100 <write@plt>
  409ed1:	test   rax,rax
  409ed4:	jle    409edb <__swc_fn_23cea7fa_000120_2648f149+0xab>
  409ed6:	add    r13,rax
  409ed9:	jmp    409eb0 <__swc_fn_23cea7fa_000120_2648f149+0x80>
  409edb:	je     409ee9 <__swc_fn_23cea7fa_000120_2648f149+0xb9>
  409edd:	xor    eax,eax
  409edf:	call   407030 <__errno_location@plt>
  409ee4:	cmp    DWORD PTR [rax],0x4
  409ee7:	je     409eb0 <__swc_fn_23cea7fa_000120_2648f149+0x80>
  409ee9:	jmp    409eeb <__swc_fn_23cea7fa_000120_2648f149+0xbb>
  409eeb:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409ef1:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409ef7:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409efd:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409f03:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409f09:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409f0f:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409f15:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409f1e:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409f27:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409f30:	add    rsp,0xc0
  409f37:	pop    rsi
  409f38:	pop    rdi
  409f39:	pop    r14
  409f3b:	pop    r13
  409f3d:	pop    r12
  409f3f:	ret

0000000000409f40 <__swc_fn_23cea7fa_000123_4f256d58>:
  409f40:	push   rbx
  409f41:	push   r12
  409f43:	push   rdi
  409f44:	push   rsi
  409f45:	sub    rsp,0x4a8
  409f4c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  409f55:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  409f5e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  409f67:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  409f70:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  409f79:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  409f82:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  409f8b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  409f94:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  409f9d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  409fa6:	mov    rbx,rdx
  409fa9:	mov    r12d,ecx
  409fac:	vxorps xmm0,xmm0,xmm0
  409fb0:	xor    eax,eax
  409fb2:	cs nop WORD PTR [rax+rax*1+0x0]
  409fbc:	nop    DWORD PTR [rax+0x0]
  409fc0:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  409fc6:	add    rax,0x10
  409fca:	cmp    rax,0x400
  409fd1:	jne    409fc0 <__swc_fn_23cea7fa_000123_4f256d58+0x80>
  409fd3:	lea    rdi,[rsp+0x8]
  409fd8:	mov    esi,0x80
  409fdd:	xor    eax,eax
  409fdf:	call   407110 <backtrace@plt>
  409fe4:	test   eax,eax
  409fe6:	jle    409ff5 <__swc_fn_23cea7fa_000123_4f256d58+0xb5>
  409fe8:	movsxd rax,eax
  409feb:	lea    rcx,[r12+0x1]
  409ff0:	cmp    rcx,rax
  409ff3:	jb     409ff9 <__swc_fn_23cea7fa_000123_4f256d58+0xb9>
  409ff5:	xor    eax,eax
  409ff7:	jmp    40a02a <__swc_fn_23cea7fa_000123_4f256d58+0xea>
  409ff9:	mov    rcx,QWORD PTR [rbx+0x8]
  409ffd:	sub    rax,r12
  40a000:	lea    rsi,[rax-0x1]
  40a004:	cmp    rcx,rsi
  40a007:	cmovbe rsi,rcx
  40a00b:	lea    eax,[r12+0x1]
  40a010:	lea    rax,[rsp+rax*8+0x8]
  40a015:	mov    rcx,QWORD PTR [rbx]
  40a018:	mov    rdx,rax
  40a01b:	lea    r8,[rsi*8+0x0]
  40a023:	call   40dc60 <__swc_fn_23cea7fa_000109_7c204aac>
  40a028:	mov    eax,esi
  40a02a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  40a033:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  40a03c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  40a045:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  40a04e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  40a057:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  40a060:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  40a069:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  40a072:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  40a07b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  40a084:	add    rsp,0x4a8
  40a08b:	pop    rsi
  40a08c:	pop    rdi
  40a08d:	pop    r12
  40a08f:	pop    rbx
  40a090:	ret
	...

000000000040a0a0 <__swc_fn_23cea7fa_000126_fcd5a289>:
  40a0a0:	mov    QWORD PTR [rcx],0x0
  40a0a7:	ret
	...

000000000040a0b0 <__swc_fn_23cea7fa_000129_4bbe3f14>:
  40a0b0:	push   rdi
  40a0b1:	push   rsi
  40a0b2:	sub    rsp,0xa8
  40a0b9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40a0bf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40a0c5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40a0cb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40a0d1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40a0d7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40a0dd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40a0e3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40a0e9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a0f2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a0fb:	mov    edi,ecx
  40a0fd:	mov    rsi,rdx
  40a100:	xor    eax,eax
  40a102:	call   407120 <pthread_setspecific@plt>
  40a107:	test   eax,eax
  40a109:	sete   al
  40a10c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a112:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a118:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a11e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a124:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a12a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a130:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a136:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a13c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a145:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a14e:	add    rsp,0xa8
  40a155:	pop    rsi
  40a156:	pop    rdi
  40a157:	ret
	...

000000000040a160 <__swc_fn_23cea7fa_000132_5f757033>:
  40a160:	push   rdi
  40a161:	push   rsi
  40a162:	sub    rsp,0xa8
  40a169:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40a16f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40a175:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40a17b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40a181:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40a187:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40a18d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40a193:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40a199:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a1a2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a1ab:	test   rcx,rcx
  40a1ae:	je     40a1c1 <__swc_fn_23cea7fa_000132_5f757033+0x61>
  40a1b0:	lea    rax,[rcx-0x1]
  40a1b4:	mov    eax,eax
  40a1b6:	mov    edi,eax
  40a1b8:	xor    eax,eax
  40a1ba:	call   407000 <pthread_getspecific@plt>
  40a1bf:	jmp    40a1c3 <__swc_fn_23cea7fa_000132_5f757033+0x63>
  40a1c1:	xor    eax,eax
  40a1c3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a1c9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a1cf:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a1d5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a1db:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a1e1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a1e7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a1ed:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a1f3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a1fc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a205:	add    rsp,0xa8
  40a20c:	pop    rsi
  40a20d:	pop    rdi
  40a20e:	ret
	...

000000000040a210 <__swc_fn_23cea7fa_000135_07d76562>:
  40a210:	push   rdi
  40a211:	push   rsi
  40a212:	sub    rsp,0xb8
  40a219:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40a21f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40a225:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40a22b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40a231:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40a237:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40a23d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40a243:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40a24c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40a255:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40a25e:	vxorps xmm0,xmm0,xmm0
  40a262:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a268:	mov    edi,0x1
  40a26d:	lea    rsi,[rsp+0x8]
  40a272:	xor    eax,eax
  40a274:	call   407130 <clock_gettime@plt>
  40a279:	mov    rax,QWORD PTR [rsp+0x8]
  40a27e:	imul   rax,rax,0x3b9aca00
  40a285:	add    rax,QWORD PTR [rsp+0x10]
  40a28a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40a290:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40a296:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40a29c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40a2a2:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40a2a8:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40a2ae:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40a2b4:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40a2bd:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40a2c6:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40a2cf:	add    rsp,0xb8
  40a2d6:	pop    rsi
  40a2d7:	pop    rdi
  40a2d8:	ret
  40a2d9:	add    BYTE PTR [rax],al
  40a2db:	add    BYTE PTR [rax],al
  40a2dd:	add    BYTE PTR [rax],al
	...

000000000040a2e0 <__swc_fn_23cea7fa_000138_715e84ff>:
  40a2e0:	sub    rsp,0x8
  40a2e4:	xor    eax,eax
  40a2e6:	mov    DWORD PTR [rcx],eax
  40a2e8:	mov    edx,0x7fffffff
  40a2ed:	call   40e360 <__swc_fn_23cea7fa_000136_865f5106>
  40a2f2:	add    rsp,0x8
  40a2f6:	ret
	...

000000000040a300 <__swc_fn_23cea7fa_000141_519fdf94>:
  40a300:	push   rdi
  40a301:	push   rsi
  40a302:	sub    rsp,0xb8
  40a309:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40a30f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40a315:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40a31b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40a321:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40a327:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40a32d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40a333:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40a33c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40a345:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40a34e:	mov    edi,0x1
  40a353:	xor    eax,eax
  40a355:	call   407140 <__x86_get_cpuid_feature_leaf@plt>
  40a35a:	mov    eax,DWORD PTR [rax+0x14]
  40a35d:	and    eax,0x20
  40a360:	setne  al
  40a363:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40a369:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40a36f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40a375:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40a37b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40a381:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40a387:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40a38d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40a396:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40a39f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40a3a8:	add    rsp,0xb8
  40a3af:	pop    rsi
  40a3b0:	pop    rdi
  40a3b1:	ret
	...

000000000040a3c0 <__swc_fn_23cea7fa_000144_d5d4d43f>:
  40a3c0:	push   rsi
  40a3c1:	push   rdi
  40a3c2:	push   r12
  40a3c4:	push   r13
  40a3c6:	push   r14
  40a3c8:	push   r15
  40a3ca:	cmp    rdx,0x40
  40a3ce:	jae    40a3dd <__swc_fn_23cea7fa_000144_d5d4d43f+0x1d>
  40a3d0:	xor    eax,eax
  40a3d2:	pop    r15
  40a3d4:	pop    r14
  40a3d6:	pop    r13
  40a3d8:	pop    r12
  40a3da:	pop    rdi
  40a3db:	pop    rsi
  40a3dc:	ret
  40a3dd:	cmp    BYTE PTR [rcx],0x7f
  40a3e0:	jne    40a424 <__swc_fn_23cea7fa_000144_d5d4d43f+0x64>
  40a3e2:	movzx  eax,BYTE PTR [rcx+0x1]
  40a3e6:	cmp    eax,0x45
  40a3e9:	setne  al
  40a3ec:	jne    40a420 <__swc_fn_23cea7fa_000144_d5d4d43f+0x60>
  40a3ee:	movzx  eax,BYTE PTR [rcx+0x2]
  40a3f2:	cmp    eax,0x4c
  40a3f5:	setne  al
  40a3f8:	jne    40a420 <__swc_fn_23cea7fa_000144_d5d4d43f+0x60>
  40a3fa:	movzx  eax,BYTE PTR [rcx+0x3]
  40a3fe:	cmp    eax,0x46
  40a401:	setne  al
  40a404:	jne    40a420 <__swc_fn_23cea7fa_000144_d5d4d43f+0x60>
  40a406:	cmp    BYTE PTR [rcx+0x4],0x2
  40a40a:	setne  al
  40a40d:	jne    40a420 <__swc_fn_23cea7fa_000144_d5d4d43f+0x60>
  40a40f:	cmp    BYTE PTR [rcx+0x5],0x1
  40a413:	setne  al
  40a416:	jne    40a420 <__swc_fn_23cea7fa_000144_d5d4d43f+0x60>
  40a418:	cmp    WORD PTR [rcx+0x12],0x3e
  40a41d:	setne  al
  40a420:	test   al,al
  40a422:	je     40a431 <__swc_fn_23cea7fa_000144_d5d4d43f+0x71>
  40a424:	xor    eax,eax
  40a426:	pop    r15
  40a428:	pop    r14
  40a42a:	pop    r13
  40a42c:	pop    r12
  40a42e:	pop    rdi
  40a42f:	pop    rsi
  40a430:	ret
  40a431:	cmp    WORD PTR [rcx+0x3a],0x40
  40a436:	jne    40a451 <__swc_fn_23cea7fa_000144_d5d4d43f+0x91>
  40a438:	cmp    WORD PTR [rcx+0x3c],0x0
  40a43d:	sete   al
  40a440:	je     40a44d <__swc_fn_23cea7fa_000144_d5d4d43f+0x8d>
  40a442:	mov    ax,WORD PTR [rcx+0x3c]
  40a446:	cmp    WORD PTR [rcx+0x3e],ax
  40a44a:	setae  al
  40a44d:	test   al,al
  40a44f:	je     40a45e <__swc_fn_23cea7fa_000144_d5d4d43f+0x9e>
  40a451:	xor    eax,eax
  40a453:	pop    r15
  40a455:	pop    r14
  40a457:	pop    r13
  40a459:	pop    r12
  40a45b:	pop    rdi
  40a45c:	pop    rsi
  40a45d:	ret
  40a45e:	movzx  eax,WORD PTR [rcx+0x3c]
  40a462:	shl    rax,0x6
  40a466:	cmp    rax,rdx
  40a469:	ja     40a477 <__swc_fn_23cea7fa_000144_d5d4d43f+0xb7>
  40a46b:	mov    r9,rdx
  40a46e:	sub    r9,rax
  40a471:	cmp    QWORD PTR [rcx+0x28],r9
  40a475:	jbe    40a484 <__swc_fn_23cea7fa_000144_d5d4d43f+0xc4>
  40a477:	xor    eax,eax
  40a479:	pop    r15
  40a47b:	pop    r14
  40a47d:	pop    r13
  40a47f:	pop    r12
  40a481:	pop    rdi
  40a482:	pop    rsi
  40a483:	ret
  40a484:	mov    rax,QWORD PTR [rcx+0x28]
  40a488:	add    rax,rcx
  40a48b:	movzx  r9d,WORD PTR [rcx+0x3e]
  40a490:	lea    r9,[r9*8+0x0]
  40a498:	lea    r10,[rax+r9*8]
  40a49c:	cmp    QWORD PTR [r10+0x20],rdx
  40a4a0:	ja     40a4c2 <__swc_fn_23cea7fa_000144_d5d4d43f+0x102>
  40a4a2:	mov    r11,rdx
  40a4a5:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  40a4aa:	cmp    QWORD PTR [r10+0x18],r11
  40a4ae:	seta   r9b
  40a4b2:	ja     40a4bd <__swc_fn_23cea7fa_000144_d5d4d43f+0xfd>
  40a4b4:	cmp    QWORD PTR [r10+0x20],0x9
  40a4b9:	setb   r9b
  40a4bd:	test   r9b,r9b
  40a4c0:	je     40a4cf <__swc_fn_23cea7fa_000144_d5d4d43f+0x10f>
  40a4c2:	xor    eax,eax
  40a4c4:	pop    r15
  40a4c6:	pop    r14
  40a4c8:	pop    r13
  40a4ca:	pop    r12
  40a4cc:	pop    rdi
  40a4cd:	pop    rsi
  40a4ce:	ret
  40a4cf:	movzx  r9d,WORD PTR [rcx+0x3c]
  40a4d4:	xor    r11d,r11d
  40a4d7:	test   r9,r9
  40a4da:	jbe    40a5d5 <__swc_fn_23cea7fa_000144_d5d4d43f+0x215>
  40a4e0:	mov    rsi,QWORD PTR [r10+0x20]
  40a4e4:	sub    rsi,0x9
  40a4e8:	cs nop WORD PTR [rax+rax*1+0x0]
  40a4f2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a4fc:	nop    DWORD PTR [rax+0x0]
  40a500:	movzx  edi,r11w
  40a504:	lea    rdi,[rdi*8+0x0]
  40a50c:	lea    r12,[rax+rdi*8]
  40a510:	rex mov edi,DWORD PTR [rax+rdi*8]
  40a514:	cmp    rdi,rsi
  40a517:	ja     40a5c8 <__swc_fn_23cea7fa_000144_d5d4d43f+0x208>
  40a51d:	mov    r13,QWORD PTR [r10+0x18]
  40a521:	add    r13,rdi
  40a524:	lea    rdi,[rcx+r13*1]
  40a528:	lea    r13,[rip+0x90d1]        # 413600 <__swc_rdata_base_23cea7fa+0x4f0>
  40a52f:	movabs r14,0x676264676177732e
  40a539:	cmp    QWORD PTR [rdi],r14
  40a53c:	jne    40a545 <__swc_fn_23cea7fa_000144_d5d4d43f+0x185>
  40a53e:	rex cmp BYTE PTR [rdi+0x8],0x0
  40a543:	je     40a572 <__swc_fn_23cea7fa_000144_d5d4d43f+0x1b2>
  40a545:	cs nop WORD PTR [rax+rax*1+0x0]
  40a54f:	nop
  40a550:	movzx  r14d,BYTE PTR [rdi]
  40a554:	movzx  r15d,BYTE PTR [r13+0x0]
  40a559:	cmp    r14,r15
  40a55c:	jne    40a568 <__swc_fn_23cea7fa_000144_d5d4d43f+0x1a8>
  40a55e:	add    rdi,0x1
  40a562:	add    r13,0x1
  40a566:	jmp    40a550 <__swc_fn_23cea7fa_000144_d5d4d43f+0x190>
  40a568:	mov    rdi,r14
  40a56b:	sub    rdi,r15
  40a56e:	test   edi,edi
  40a570:	jne    40a5c8 <__swc_fn_23cea7fa_000144_d5d4d43f+0x208>
  40a572:	cmp    DWORD PTR [r12+0x4],0x1
  40a578:	jne    40a5a0 <__swc_fn_23cea7fa_000144_d5d4d43f+0x1e0>
  40a57a:	cmp    QWORD PTR [r12+0x20],0x10
  40a580:	setb   al
  40a583:	jb     40a59c <__swc_fn_23cea7fa_000144_d5d4d43f+0x1dc>
  40a585:	cmp    QWORD PTR [r12+0x20],rdx
  40a58a:	seta   al
  40a58d:	ja     40a59c <__swc_fn_23cea7fa_000144_d5d4d43f+0x1dc>
  40a58f:	sub    rdx,QWORD PTR [r12+0x20]
  40a594:	cmp    QWORD PTR [r12+0x18],rdx
  40a599:	seta   al
  40a59c:	test   al,al
  40a59e:	je     40a5ad <__swc_fn_23cea7fa_000144_d5d4d43f+0x1ed>
  40a5a0:	xor    eax,eax
  40a5a2:	pop    r15
  40a5a4:	pop    r14
  40a5a6:	pop    r13
  40a5a8:	pop    r12
  40a5aa:	pop    rdi
  40a5ab:	pop    rsi
  40a5ac:	ret
  40a5ad:	mov    rax,QWORD PTR [r12+0x20]
  40a5b2:	mov    QWORD PTR [r8],rax
  40a5b5:	mov    rax,QWORD PTR [r12+0x18]
  40a5ba:	add    rax,rcx
  40a5bd:	pop    r15
  40a5bf:	pop    r14
  40a5c1:	pop    r13
  40a5c3:	pop    r12
  40a5c5:	pop    rdi
  40a5c6:	pop    rsi
  40a5c7:	ret
  40a5c8:	add    r11,0x1
  40a5cc:	cmp    r11,r9
  40a5cf:	jb     40a500 <__swc_fn_23cea7fa_000144_d5d4d43f+0x140>
  40a5d5:	xor    eax,eax
  40a5d7:	pop    r15
  40a5d9:	pop    r14
  40a5db:	pop    r13
  40a5dd:	pop    r12
  40a5df:	pop    rdi
  40a5e0:	pop    rsi
  40a5e1:	ret
	...

000000000040a5f0 <__swc_fn_23cea7fa_000147_d7edc04f>:
  40a5f0:	push   rdi
  40a5f1:	push   rsi
  40a5f2:	sub    rsp,0xa8
  40a5f9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40a5ff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40a605:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40a60b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40a611:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40a617:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40a61d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40a623:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40a629:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a632:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a63b:	mov    rdi,rcx
  40a63e:	xor    eax,eax
  40a640:	call   407150 <free@plt>
  40a645:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a64b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a651:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a657:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a65d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a663:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a669:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a66f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a675:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a67e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a687:	add    rsp,0xa8
  40a68e:	pop    rsi
  40a68f:	pop    rdi
  40a690:	ret
	...

000000000040a6a0 <__swc_fn_23cea7fa_000150_6203dca2>:
  40a6a0:	push   rbx
  40a6a1:	push   rsi
  40a6a2:	push   rdi
  40a6a3:	push   r12
  40a6a5:	push   r13
  40a6a7:	push   r15
  40a6a9:	sub    rsp,0x4e8
  40a6b0:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  40a6b9:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  40a6c2:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  40a6cb:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  40a6d4:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  40a6dd:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  40a6e6:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  40a6ef:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  40a6f8:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  40a701:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  40a70a:	mov    rbx,QWORD PTR [rcx]
  40a70d:	mov    rcx,QWORD PTR [rcx+0x8]
  40a711:	mov    rsi,rcx
  40a714:	xor    edi,edi
  40a716:	vmovsd xmm6,QWORD PTR [rip+0x8f42]        # 413660 <__swc_rdata_base_23cea7fa+0x550>
  40a71e:	vmovsd xmm7,QWORD PTR [rip+0x8f43]        # 413669 <__swc_rdata_base_23cea7fa+0x559>
  40a726:	vmovsd xmm8,QWORD PTR [rip+0x8f44]        # 413672 <__swc_rdata_base_23cea7fa+0x562>
  40a72e:	vmovsd xmm9,QWORD PTR [rip+0x8f45]        # 41367b <__swc_rdata_base_23cea7fa+0x56b>
  40a736:	vmovsd xmm10,QWORD PTR [rip+0x8f46]        # 413684 <__swc_rdata_base_23cea7fa+0x574>
  40a73e:	vmovups xmm11,xmm6
  40a742:	vmovsd QWORD PTR [rsp+0x418],xmm7
  40a74b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  40a754:	vmovsd QWORD PTR [rsp+0x428],xmm9
  40a75d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  40a766:	vmovsd xmm15,QWORD PTR [rip+0x8f1f]        # 41368d <__swc_rdata_base_23cea7fa+0x57d>
  40a76e:	vmovups xmm14,xmm15
  40a773:	vmovups xmm0,xmm9
  40a778:	vmovsd QWORD PTR [rsp+0x438],xmm15
  40a781:	vmovups xmm13,xmm8
  40a786:	vmovsd QWORD PTR [rsp+0x440],xmm15
  40a78f:	test   rsi,rsi
  40a792:	je     40b783 <__swc_fn_23cea7fa_000150_6203dca2+0x10e3>
  40a798:	cs nop WORD PTR [rax+rax*1+0x0]
  40a7a2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a7ac:	nop    DWORD PTR [rax+0x0]
  40a7b0:	lea    rcx,[rdi+rdi*1]
  40a7b4:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  40a7b9:	vpshufd xmm3,xmm2,0xee
  40a7be:	vmovq  rcx,xmm3
  40a7c3:	test   rcx,rcx
  40a7c6:	je     40a7dc <__swc_fn_23cea7fa_000150_6203dca2+0x13c>
  40a7c8:	test   DWORD PTR [rcx+0x28],0x400000
  40a7cf:	je     40a7dc <__swc_fn_23cea7fa_000150_6203dca2+0x13c>
  40a7d1:	mov    rdx,QWORD PTR [rcx+0x30]
  40a7d5:	test   rdx,rdx
  40a7d8:	cmovne rcx,rdx
  40a7dc:	test   DWORD PTR [rcx+0x28],0x1000
  40a7e3:	je     40a804 <__swc_fn_23cea7fa_000150_6203dca2+0x164>
  40a7e5:	mov    rdx,QWORD PTR [rcx+0x40]
  40a7e9:	mov    rcx,rdx
  40a7ec:	vmovq  r8,xmm2
  40a7f1:	mov    r8,QWORD PTR [r8]
  40a7f4:	mov    QWORD PTR [rsp+0x60],r8
  40a7f9:	mov    QWORD PTR [rsp+0x68],rdx
  40a7fe:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  40a804:	test   BYTE PTR [rcx+0x28],0x1
  40a808:	jne    40a810 <__swc_fn_23cea7fa_000150_6203dca2+0x170>
  40a80a:	vmovups xmm12,xmm0
  40a80e:	jmp    40a82a <__swc_fn_23cea7fa_000150_6203dca2+0x18a>
  40a810:	vmovq  rax,xmm2
  40a815:	mov    rax,QWORD PTR [rax]
  40a818:	lea    rcx,[rax+0x10]
  40a81c:	vmovups xmm12,xmm0
  40a820:	call   409e30 <__swc_fn_23cea7fa_000120_2648f149>
  40a825:	jmp    40b765 <__swc_fn_23cea7fa_000150_6203dca2+0x10c5>
  40a82a:	test   DWORD PTR [rcx+0x28],0x400
  40a831:	je     40a892 <__swc_fn_23cea7fa_000150_6203dca2+0x1f2>
  40a833:	vmovq  rax,xmm2
  40a838:	mov    rax,QWORD PTR [rax]
  40a83b:	xor    ecx,ecx
  40a83d:	test   rax,rax
  40a840:	je     40a870 <__swc_fn_23cea7fa_000150_6203dca2+0x1d0>
  40a842:	mov    rdx,rax
  40a845:	mov    r8b,BYTE PTR [rdx]
  40a848:	test   r8b,r8b
  40a84b:	je     40a870 <__swc_fn_23cea7fa_000150_6203dca2+0x1d0>
  40a84d:	cs nop WORD PTR [rax+rax*1+0x0]
  40a857:	nop    WORD PTR [rax+rax*1+0x0]
  40a860:	add    rdx,0x1
  40a864:	add    rcx,0x1
  40a868:	mov    r8b,BYTE PTR [rdx]
  40a86b:	test   r8b,r8b
  40a86e:	jne    40a860 <__swc_fn_23cea7fa_000150_6203dca2+0x1c0>
  40a870:	mov    QWORD PTR [rsp+0x88],rax
  40a878:	mov    QWORD PTR [rsp+0x90],rcx
  40a880:	lea    rcx,[rsp+0x88]
  40a888:	call   409e30 <__swc_fn_23cea7fa_000120_2648f149>
  40a88d:	jmp    40b765 <__swc_fn_23cea7fa_000150_6203dca2+0x10c5>
  40a892:	cmp    BYTE PTR [rcx+0x2c],0x6
  40a896:	jne    40a8ad <__swc_fn_23cea7fa_000150_6203dca2+0x20d>
  40a898:	vmovq  rax,xmm2
  40a89d:	mov    rax,QWORD PTR [rax]
  40a8a0:	mov    rcx,rax
  40a8a3:	call   40e830 <__swc_fn_23cea7fa_000148_43c96957>
  40a8a8:	jmp    40b765 <__swc_fn_23cea7fa_000150_6203dca2+0x10c5>
  40a8ad:	cmp    BYTE PTR [rcx+0x2c],0x1
  40a8b1:	jne    40b759 <__swc_fn_23cea7fa_000150_6203dca2+0x10b9>
  40a8b7:	vmovq  rdx,xmm2
  40a8bc:	mov    cl,BYTE PTR [rcx+0x40]
  40a8bf:	cmp    cl,0x7
  40a8c2:	jb     40a905 <__swc_fn_23cea7fa_000150_6203dca2+0x265>
  40a8c4:	je     40a978 <__swc_fn_23cea7fa_000150_6203dca2+0x2d8>
  40a8ca:	cmp    cl,0x8
  40a8cd:	je     40a984 <__swc_fn_23cea7fa_000150_6203dca2+0x2e4>
  40a8d3:	cmp    cl,0x9
  40a8d6:	je     40a99d <__swc_fn_23cea7fa_000150_6203dca2+0x2fd>
  40a8dc:	cmp    cl,0xa
  40a8df:	je     40b064 <__swc_fn_23cea7fa_000150_6203dca2+0x9c4>
  40a8e5:	cmp    cl,0xb
  40a8e8:	je     40b72b <__swc_fn_23cea7fa_000150_6203dca2+0x108b>
  40a8ee:	cmp    cl,0xc
  40a8f1:	je     40a991 <__swc_fn_23cea7fa_000150_6203dca2+0x2f1>
  40a8f7:	cmp    cl,0xd
  40a8fa:	je     40b721 <__swc_fn_23cea7fa_000150_6203dca2+0x1081>
  40a900:	jmp    40b74b <__swc_fn_23cea7fa_000150_6203dca2+0x10ab>
  40a905:	cmp    cl,0x1
  40a908:	je     40a928 <__swc_fn_23cea7fa_000150_6203dca2+0x288>
  40a90a:	cmp    cl,0x2
  40a90d:	je     40a936 <__swc_fn_23cea7fa_000150_6203dca2+0x296>
  40a90f:	cmp    cl,0x3
  40a912:	je     40a944 <__swc_fn_23cea7fa_000150_6203dca2+0x2a4>
  40a914:	cmp    cl,0x4
  40a917:	je     40a951 <__swc_fn_23cea7fa_000150_6203dca2+0x2b1>
  40a919:	cmp    cl,0x5
  40a91c:	je     40a95e <__swc_fn_23cea7fa_000150_6203dca2+0x2be>
  40a91e:	cmp    cl,0x6
  40a921:	je     40a96b <__swc_fn_23cea7fa_000150_6203dca2+0x2cb>
  40a923:	jmp    40b74b <__swc_fn_23cea7fa_000150_6203dca2+0x10ab>
  40a928:	movsx  rcx,BYTE PTR [rdx]
  40a92c:	call   411ae0 <__swc_fn_23cea7fa_000149_2eb804cc>
  40a931:	jmp    40b765 <__swc_fn_23cea7fa_000150_6203dca2+0x10c5>
  40a936:	movsx  rcx,WORD PTR [rdx]
  40a93a:	call   411ae0 <__swc_fn_23cea7fa_000149_2eb804cc>
  40a93f:	jmp    40b765 <__swc_fn_23cea7fa_000150_6203dca2+0x10c5>
  40a944:	movsxd rcx,DWORD PTR [rdx]
  40a947:	call   411ae0 <__swc_fn_23cea7fa_000149_2eb804cc>
  40a94c:	jmp    40b765 <__swc_fn_23cea7fa_000150_6203dca2+0x10c5>
  40a951:	mov    rcx,QWORD PTR [rdx]
  40a954:	call   411ae0 <__swc_fn_23cea7fa_000149_2eb804cc>
  40a959:	jmp    40b765 <__swc_fn_23cea7fa_000150_6203dca2+0x10c5>
  40a95e:	movzx  ecx,BYTE PTR [rdx]
  40a961:	call   40e830 <__swc_fn_23cea7fa_000148_43c96957>
  40a966:	jmp    40b765 <__swc_fn_23cea7fa_000150_6203dca2+0x10c5>
  40a96b:	movzx  ecx,WORD PTR [rdx]
  40a96e:	call   40e830 <__swc_fn_23cea7fa_000148_43c96957>
  40a973:	jmp    40b765 <__swc_fn_23cea7fa_000150_6203dca2+0x10c5>
  40a978:	mov    ecx,DWORD PTR [rdx]
  40a97a:	call   40e830 <__swc_fn_23cea7fa_000148_43c96957>
  40a97f:	jmp    40b765 <__swc_fn_23cea7fa_000150_6203dca2+0x10c5>
  40a984:	mov    rcx,QWORD PTR [rdx]
  40a987:	call   40e830 <__swc_fn_23cea7fa_000148_43c96957>
  40a98c:	jmp    40b765 <__swc_fn_23cea7fa_000150_6203dca2+0x10c5>
  40a991:	mov    ecx,DWORD PTR [rdx]
  40a993:	call   40e830 <__swc_fn_23cea7fa_000148_43c96957>
  40a998:	jmp    40b765 <__swc_fn_23cea7fa_000150_6203dca2+0x10c5>
  40a99d:	lea    rcx,[rsp+0xa8]
  40a9a5:	vxorps xmm0,xmm0,xmm0
  40a9a9:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  40a9b2:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  40a9bb:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  40a9c4:	vzeroupper
  40a9c7:	mov    DWORD PTR [rsp+0x108],0x0
  40a9d2:	vxorpd xmm0,xmm0,xmm0
  40a9d6:	vmovss xmm1,DWORD PTR [rdx]
  40a9da:	vcvtss2sd xmm0,xmm0,xmm1
  40a9de:	vmovsd xmm1,xmm1,xmm0
  40a9e2:	vcomisd xmm0,xmm0
  40a9e6:	setne  dl
  40a9e9:	movzx  edx,dl
  40a9ec:	setp   r8b
  40a9f0:	movzx  r8d,r8b
  40a9f4:	or     edx,r8d
  40a9f7:	test   dl,dl
  40a9f9:	je     40aa06 <__swc_fn_23cea7fa_000150_6203dca2+0x366>
  40a9fb:	mov    DWORD PTR [rcx],0x6e616e
  40aa01:	jmp    40aff8 <__swc_fn_23cea7fa_000150_6203dca2+0x958>
  40aa06:	vcomisd xmm1,xmm6
  40aa0a:	ja     40aa12 <__swc_fn_23cea7fa_000150_6203dca2+0x372>
  40aa0c:	vcomisd xmm7,xmm1
  40aa10:	jbe    40aa36 <__swc_fn_23cea7fa_000150_6203dca2+0x396>
  40aa12:	vxorpd xmm0,xmm0,xmm0
  40aa16:	vcomisd xmm0,xmm1
  40aa1a:	jbe    40aa2b <__swc_fn_23cea7fa_000150_6203dca2+0x38b>
  40aa1c:	mov    DWORD PTR [rcx],0x666e692d
  40aa22:	mov    BYTE PTR [rcx+0x4],0x0
  40aa26:	jmp    40aff8 <__swc_fn_23cea7fa_000150_6203dca2+0x958>
  40aa2b:	mov    DWORD PTR [rcx],0x666e69
  40aa31:	jmp    40aff8 <__swc_fn_23cea7fa_000150_6203dca2+0x958>
  40aa36:	vcomisd xmm1,xmm8
  40aa3b:	jae    40aa47 <__swc_fn_23cea7fa_000150_6203dca2+0x3a7>
  40aa3d:	vcomisd xmm9,xmm1
  40aa41:	jbe    40adbe <__swc_fn_23cea7fa_000150_6203dca2+0x71e>
  40aa47:	vmovups xmm0,xmm1
  40aa4b:	vxorpd xmm2,xmm2,xmm2
  40aa4f:	vcomisd xmm2,xmm1
  40aa53:	jbe    40aa63 <__swc_fn_23cea7fa_000150_6203dca2+0x3c3>
  40aa55:	vmovsd xmm1,xmm1,xmm0
  40aa59:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x8bbf]        # 413620 <__swc_rdata_base_23cea7fa+0x510>
  40aa61:	jmp    40aa67 <__swc_fn_23cea7fa_000150_6203dca2+0x3c7>
  40aa63:	vmovsd xmm1,xmm1,xmm0
  40aa67:	xor    r8d,r8d
  40aa6a:	vcomisd xmm1,xmm15
  40aa6f:	jb     40aa90 <__swc_fn_23cea7fa_000150_6203dca2+0x3f0>
  40aa71:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa7b:	nop    DWORD PTR [rax+rax*1+0x0]
  40aa80:	vdivsd xmm1,xmm1,xmm15
  40aa85:	add    r8,0x1
  40aa89:	vcomisd xmm1,xmm15
  40aa8e:	jae    40aa80 <__swc_fn_23cea7fa_000150_6203dca2+0x3e0>
  40aa90:	mov    r9,rcx
  40aa93:	vxorpd xmm2,xmm2,xmm2
  40aa97:	vcomisd xmm2,xmm0
  40aa9b:	jbe    40aaa4 <__swc_fn_23cea7fa_000150_6203dca2+0x404>
  40aa9d:	mov    BYTE PTR [rcx],0x2d
  40aaa0:	lea    r9,[rcx+0x1]
  40aaa4:	vcvttsd2si rdx,xmm1
  40aaa9:	mov    r10b,dl
  40aaac:	add    r10b,0x30
  40aab0:	mov    BYTE PTR [r9],r10b
  40aab3:	vxorpd xmm0,xmm0,xmm0
  40aab7:	movzx  edx,dl
  40aaba:	vcvtsi2sd xmm0,xmm0,rdx
  40aabf:	vsubsd xmm0,xmm1,xmm0
  40aac3:	vmulsd xmm1,xmm0,xmm15
  40aac8:	mov    BYTE PTR [r9+0x1],0x2e
  40aacd:	vcvttsd2si rdx,xmm1
  40aad2:	mov    r10b,dl
  40aad5:	add    r10b,0x30
  40aad9:	mov    BYTE PTR [r9+0x2],r10b
  40aadd:	vxorpd xmm0,xmm0,xmm0
  40aae1:	movzx  edx,dl
  40aae4:	vcvtsi2sd xmm0,xmm0,rdx
  40aae9:	vsubsd xmm0,xmm1,xmm0
  40aaed:	vmulsd xmm1,xmm0,xmm15
  40aaf2:	vcvttsd2si rdx,xmm1
  40aaf7:	mov    r10b,dl
  40aafa:	add    r10b,0x30
  40aafe:	mov    BYTE PTR [r9+0x3],r10b
  40ab02:	vxorpd xmm0,xmm0,xmm0
  40ab06:	movzx  edx,dl
  40ab09:	vcvtsi2sd xmm0,xmm0,rdx
  40ab0e:	vsubsd xmm0,xmm1,xmm0
  40ab12:	vmulsd xmm1,xmm0,xmm15
  40ab17:	vcvttsd2si rdx,xmm1
  40ab1c:	mov    r10b,dl
  40ab1f:	add    r10b,0x30
  40ab23:	mov    BYTE PTR [r9+0x4],r10b
  40ab27:	vxorpd xmm0,xmm0,xmm0
  40ab2b:	movzx  edx,dl
  40ab2e:	vcvtsi2sd xmm0,xmm0,rdx
  40ab33:	vsubsd xmm0,xmm1,xmm0
  40ab37:	vmulsd xmm1,xmm0,xmm15
  40ab3c:	vcvttsd2si rdx,xmm1
  40ab41:	mov    r10b,dl
  40ab44:	add    r10b,0x30
  40ab48:	mov    BYTE PTR [r9+0x5],r10b
  40ab4c:	vxorpd xmm0,xmm0,xmm0
  40ab50:	movzx  edx,dl
  40ab53:	vcvtsi2sd xmm0,xmm0,rdx
  40ab58:	vsubsd xmm0,xmm1,xmm0
  40ab5c:	vmulsd xmm1,xmm0,xmm15
  40ab61:	vcvttsd2si rdx,xmm1
  40ab66:	mov    r10b,dl
  40ab69:	add    r10b,0x30
  40ab6d:	mov    BYTE PTR [r9+0x6],r10b
  40ab71:	vxorpd xmm0,xmm0,xmm0
  40ab75:	movzx  edx,dl
  40ab78:	vcvtsi2sd xmm0,xmm0,rdx
  40ab7d:	vsubsd xmm0,xmm1,xmm0
  40ab81:	vmulsd xmm1,xmm0,xmm15
  40ab86:	vcvttsd2si rdx,xmm1
  40ab8b:	mov    r10b,dl
  40ab8e:	add    r10b,0x30
  40ab92:	mov    BYTE PTR [r9+0x7],r10b
  40ab96:	vxorpd xmm0,xmm0,xmm0
  40ab9a:	movzx  edx,dl
  40ab9d:	vcvtsi2sd xmm0,xmm0,rdx
  40aba2:	vsubsd xmm0,xmm1,xmm0
  40aba6:	vmulsd xmm1,xmm0,xmm15
  40abab:	vcvttsd2si rdx,xmm1
  40abb0:	mov    r10b,dl
  40abb3:	add    r10b,0x30
  40abb7:	mov    BYTE PTR [r9+0x8],r10b
  40abbb:	vxorpd xmm0,xmm0,xmm0
  40abbf:	movzx  edx,dl
  40abc2:	vcvtsi2sd xmm0,xmm0,rdx
  40abc7:	vsubsd xmm0,xmm1,xmm0
  40abcb:	vmulsd xmm1,xmm0,xmm15
  40abd0:	vcvttsd2si rdx,xmm1
  40abd5:	mov    r10b,dl
  40abd8:	add    r10b,0x30
  40abdc:	mov    BYTE PTR [r9+0x9],r10b
  40abe0:	vxorpd xmm0,xmm0,xmm0
  40abe4:	movzx  edx,dl
  40abe7:	vcvtsi2sd xmm0,xmm0,rdx
  40abec:	vsubsd xmm0,xmm1,xmm0
  40abf0:	vmulsd xmm1,xmm0,xmm15
  40abf5:	vcvttsd2si rdx,xmm1
  40abfa:	mov    r10b,dl
  40abfd:	add    r10b,0x30
  40ac01:	mov    BYTE PTR [r9+0xa],r10b
  40ac05:	vxorpd xmm0,xmm0,xmm0
  40ac09:	movzx  edx,dl
  40ac0c:	vcvtsi2sd xmm0,xmm0,rdx
  40ac11:	vsubsd xmm0,xmm1,xmm0
  40ac15:	vmulsd xmm1,xmm0,xmm15
  40ac1a:	vcvttsd2si rdx,xmm1
  40ac1f:	mov    r10b,dl
  40ac22:	add    r10b,0x30
  40ac26:	mov    BYTE PTR [r9+0xb],r10b
  40ac2a:	lea    r10,[r9+0x4]
  40ac2e:	vxorpd xmm0,xmm0,xmm0
  40ac32:	movzx  edx,dl
  40ac35:	vcvtsi2sd xmm0,xmm0,rdx
  40ac3a:	vsubsd xmm0,xmm1,xmm0
  40ac3e:	vmulsd xmm1,xmm0,xmm15
  40ac43:	vcvttsd2si rdx,xmm1
  40ac48:	mov    r11b,dl
  40ac4b:	add    r11b,0x30
  40ac4f:	mov    BYTE PTR [r9+0xc],r11b
  40ac53:	vxorpd xmm0,xmm0,xmm0
  40ac57:	movzx  edx,dl
  40ac5a:	vcvtsi2sd xmm0,xmm0,rdx
  40ac5f:	vsubsd xmm0,xmm1,xmm0
  40ac63:	vmulsd xmm1,xmm0,xmm15
  40ac68:	vcvttsd2si rdx,xmm1
  40ac6d:	mov    r11b,dl
  40ac70:	add    r11b,0x30
  40ac74:	mov    BYTE PTR [r9+0xd],r11b
  40ac78:	lea    r10,[r10+0x2]
  40ac7c:	vxorpd xmm0,xmm0,xmm0
  40ac80:	movzx  edx,dl
  40ac83:	vcvtsi2sd xmm0,xmm0,rdx
  40ac88:	vsubsd xmm0,xmm1,xmm0
  40ac8c:	vmulsd xmm1,xmm0,xmm15
  40ac91:	vcvttsd2si rdx,xmm1
  40ac96:	mov    r11b,dl
  40ac99:	add    r11b,0x30
  40ac9d:	mov    BYTE PTR [r9+0xe],r11b
  40aca1:	vxorpd xmm0,xmm0,xmm0
  40aca5:	movzx  edx,dl
  40aca8:	vcvtsi2sd xmm0,xmm0,rdx
  40acad:	vsubsd xmm0,xmm1,xmm0
  40acb1:	vmulsd xmm1,xmm0,xmm15
  40acb6:	vcvttsd2si rdx,xmm1
  40acbb:	mov    r11b,dl
  40acbe:	add    r11b,0x30
  40acc2:	mov    BYTE PTR [r9+0xf],r11b
  40acc6:	lea    r10,[r10+0x2]
  40acca:	lea    r10,[r10+0x2]
  40acce:	lea    r10,[r10+0x2]
  40acd2:	lea    r10,[r10+0x2]
  40acd6:	lea    r10,[r10+0x2]
  40acda:	vxorpd xmm0,xmm0,xmm0
  40acde:	movzx  edx,dl
  40ace1:	vcvtsi2sd xmm0,xmm0,rdx
  40ace6:	vsubsd xmm0,xmm1,xmm0
  40acea:	vmulsd xmm1,xmm0,xmm15
  40acef:	vcvttsd2si rdx,xmm1
  40acf4:	mov    r11b,dl
  40acf7:	add    r11b,0x30
  40acfb:	mov    BYTE PTR [r9+0x10],r11b
  40acff:	vxorpd xmm0,xmm0,xmm0
  40ad03:	movzx  edx,dl
  40ad06:	vcvtsi2sd xmm0,xmm0,rdx
  40ad0b:	vsubsd xmm0,xmm1,xmm0
  40ad0f:	vmulsd xmm1,xmm0,xmm15
  40ad14:	vcvttsd2si rdx,xmm1
  40ad19:	add    dl,0x30
  40ad1c:	mov    BYTE PTR [r9+0x11],dl
  40ad20:	mov    BYTE PTR [r10+0x2],0x65
  40ad25:	lea    r9,[r10+0x3]
  40ad29:	test   r8,r8
  40ad2c:	jl     40ad35 <__swc_fn_23cea7fa_000150_6203dca2+0x695>
  40ad2e:	mov    BYTE PTR [r9],0x2b
  40ad32:	inc    r9
  40ad35:	mov    r10,r9
  40ad38:	mov    rdx,r8
  40ad3b:	nop    DWORD PTR [rax+rax*1+0x0]
  40ad40:	mov    r11,rdx
  40ad43:	movabs rdx,0x6666666666666667
  40ad4d:	mov    rax,r11
  40ad50:	imul   rdx
  40ad53:	sar    rdx,0x2
  40ad57:	mov    r12,rdx
  40ad5a:	shr    rdx,0x3f
  40ad5e:	add    r12,rdx
  40ad61:	mov    rdx,r12
  40ad64:	imul   r13,r12,0xa
  40ad68:	sub    r11,r13
  40ad6b:	mov    r13,QWORD PTR [rip+0x889e]        # 413610 <__swc_rdata_base_23cea7fa+0x500>
  40ad72:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40ad77:	mov    BYTE PTR [r10],r11b
  40ad7a:	lea    r11,[r10+0x1]
  40ad7e:	mov    r10,r11
  40ad81:	test   r12,r12
  40ad84:	jne    40ad40 <__swc_fn_23cea7fa_000150_6203dca2+0x6a0>
  40ad86:	test   r8,r8
  40ad89:	jge    40ad93 <__swc_fn_23cea7fa_000150_6203dca2+0x6f3>
  40ad8b:	mov    BYTE PTR [r11],0x2d
  40ad8f:	lea    r10,[r11+0x1]
  40ad93:	mov    BYTE PTR [r10],0x0
  40ad97:	sub    r10,0x1
  40ad9b:	nop    DWORD PTR [rax+rax*1+0x0]
  40ada0:	cmp    r9,r10
  40ada3:	jae    40aff8 <__swc_fn_23cea7fa_000150_6203dca2+0x958>
  40ada9:	mov    al,BYTE PTR [r10]
  40adac:	mov    dl,BYTE PTR [r9]
  40adaf:	mov    BYTE PTR [r10],dl
  40adb2:	sub    r10,0x1
  40adb6:	mov    BYTE PTR [r9],al
  40adb9:	inc    r9
  40adbc:	jmp    40ada0 <__swc_fn_23cea7fa_000150_6203dca2+0x700>
  40adbe:	vcvttsd2si rdx,xmm1
  40adc3:	mov    r8,rdx
  40adc6:	vxorpd xmm0,xmm0,xmm0
  40adca:	vcvtsi2sd xmm0,xmm0,rdx
  40adcf:	vsubsd xmm0,xmm1,xmm0
  40add3:	mov    r9d,0x8
  40add9:	vxorpd xmm2,xmm2,xmm2
  40addd:	vcomisd xmm2,xmm0
  40ade1:	jbe    40adeb <__swc_fn_23cea7fa_000150_6203dca2+0x74b>
  40ade3:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x8835]        # 413620 <__swc_rdata_base_23cea7fa+0x510>
  40adeb:	test   r9d,r9d
  40adee:	je     40adfa <__swc_fn_23cea7fa_000150_6203dca2+0x75a>
  40adf0:	vmulsd xmm0,xmm0,xmm14
  40adf5:	dec    r9d
  40adf8:	jne    40adf0 <__swc_fn_23cea7fa_000150_6203dca2+0x750>
  40adfa:	vcvttsd2si r9,xmm0
  40adff:	mov    r10,r9
  40ae02:	vxorpd xmm2,xmm2,xmm2
  40ae06:	vcvtsi2sd xmm2,xmm2,r9
  40ae0b:	vsubsd xmm0,xmm0,xmm2
  40ae0f:	vcomisd xmm0,xmm10
  40ae14:	lea    r9,[r9+0x1]
  40ae18:	cmova  r10,r9
  40ae1c:	cmp    r10,0x5f5e100
  40ae23:	jne    40ae3c <__swc_fn_23cea7fa_000150_6203dca2+0x79c>
  40ae25:	lea    r8,[rdx-0x1]
  40ae29:	vxorpd xmm0,xmm0,xmm0
  40ae2d:	vcomisd xmm0,xmm1
  40ae31:	lea    rdx,[rdx+0x1]
  40ae35:	cmovbe r8,rdx
  40ae39:	xor    r10d,r10d
  40ae3c:	mov    r9,rcx
  40ae3f:	test   r8,r8
  40ae42:	jne    40ae62 <__swc_fn_23cea7fa_000150_6203dca2+0x7c2>
  40ae44:	vxorpd xmm0,xmm0,xmm0
  40ae48:	vcomisd xmm0,xmm1
  40ae4c:	jbe    40ae55 <__swc_fn_23cea7fa_000150_6203dca2+0x7b5>
  40ae4e:	mov    BYTE PTR [rcx],0x2d
  40ae51:	lea    r9,[rcx+0x1]
  40ae55:	mov    BYTE PTR [r9],0x30
  40ae59:	add    r9,0x1
  40ae5d:	jmp    40aefb <__swc_fn_23cea7fa_000150_6203dca2+0x85b>
  40ae62:	mov    r9,rcx
  40ae65:	mov    rdx,r8
  40ae68:	nop    DWORD PTR [rax+rax*1+0x0]
  40ae70:	mov    r11,rdx
  40ae73:	movabs rdx,0x6666666666666667
  40ae7d:	mov    r15,rax
  40ae80:	mov    rax,r11
  40ae83:	imul   rdx
  40ae86:	mov    r12,rdx
  40ae89:	mov    rax,r15
  40ae8c:	sar    r12,0x2
  40ae90:	mov    rdx,r12
  40ae93:	shr    rdx,0x3f
  40ae97:	add    r12,rdx
  40ae9a:	mov    rdx,r12
  40ae9d:	imul   r13,r12,0xa
  40aea1:	sub    r11,r13
  40aea4:	mov    r13,QWORD PTR [rip+0x8765]        # 413610 <__swc_rdata_base_23cea7fa+0x500>
  40aeab:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40aeb0:	mov    BYTE PTR [r9],r11b
  40aeb3:	lea    r11,[r9+0x1]
  40aeb7:	mov    r9,r11
  40aeba:	test   r12,r12
  40aebd:	jne    40ae70 <__swc_fn_23cea7fa_000150_6203dca2+0x7d0>
  40aebf:	test   r8,r8
  40aec2:	jge    40aecc <__swc_fn_23cea7fa_000150_6203dca2+0x82c>
  40aec4:	mov    BYTE PTR [r11],0x2d
  40aec8:	lea    r9,[r11+0x1]
  40aecc:	mov    rdx,r9
  40aecf:	mov    BYTE PTR [r9],0x0
  40aed3:	sub    r9,0x1
  40aed7:	mov    r8,rcx
  40aeda:	cmp    r8,r9
  40aedd:	jae    40aef8 <__swc_fn_23cea7fa_000150_6203dca2+0x858>
  40aedf:	nop
  40aee0:	mov    r11b,BYTE PTR [r9]
  40aee3:	mov    r12b,BYTE PTR [r8]
  40aee6:	mov    BYTE PTR [r9],r12b
  40aee9:	sub    r9,0x1
  40aeed:	mov    BYTE PTR [r8],r11b
  40aef0:	inc    r8
  40aef3:	cmp    r8,r9
  40aef6:	jb     40aee0 <__swc_fn_23cea7fa_000150_6203dca2+0x840>
  40aef8:	mov    r9,rdx
  40aefb:	mov    BYTE PTR [r9],0x2e
  40aeff:	add    r9,0x1
  40af03:	xor    r8d,r8d
  40af06:	test   r10,r10
  40af09:	je     40af4f <__swc_fn_23cea7fa_000150_6203dca2+0x8af>
  40af0b:	mov    r11d,0x989680
  40af11:	cmp    r10,r11
  40af14:	jge    40af4f <__swc_fn_23cea7fa_000150_6203dca2+0x8af>
  40af16:	cs nop WORD PTR [rax+rax*1+0x0]
  40af20:	inc    r8d
  40af23:	movabs rdx,0x6666666666666667
  40af2d:	mov    r15,rax
  40af30:	mov    rax,r11
  40af33:	imul   rdx
  40af36:	mov    r11,rdx
  40af39:	mov    rax,r15
  40af3c:	sar    r11,0x2
  40af40:	mov    rdx,r11
  40af43:	shr    rdx,0x3f
  40af47:	add    r11,rdx
  40af4a:	cmp    r10,r11
  40af4d:	jl     40af20 <__swc_fn_23cea7fa_000150_6203dca2+0x880>
  40af4f:	test   r8d,r8d
  40af52:	je     40af6d <__swc_fn_23cea7fa_000150_6203dca2+0x8cd>
  40af54:	cs nop WORD PTR [rax+rax*1+0x0]
  40af5e:	xchg   ax,ax
  40af60:	mov    BYTE PTR [r9],0x30
  40af64:	add    r9,0x1
  40af68:	dec    r8d
  40af6b:	jne    40af60 <__swc_fn_23cea7fa_000150_6203dca2+0x8c0>
  40af6d:	mov    r8,r9
  40af70:	mov    rdx,r10
  40af73:	cs nop WORD PTR [rax+rax*1+0x0]
  40af7d:	nop    DWORD PTR [rax]
  40af80:	mov    r11,rdx
  40af83:	movabs rdx,0x6666666666666667
  40af8d:	mov    rax,r11
  40af90:	imul   rdx
  40af93:	sar    rdx,0x2
  40af97:	mov    r12,rdx
  40af9a:	shr    rdx,0x3f
  40af9e:	add    r12,rdx
  40afa1:	mov    rdx,r12
  40afa4:	imul   r13,r12,0xa
  40afa8:	sub    r11,r13
  40afab:	mov    r13,QWORD PTR [rip+0x865e]        # 413610 <__swc_rdata_base_23cea7fa+0x500>
  40afb2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40afb7:	mov    BYTE PTR [r8],r11b
  40afba:	lea    r11,[r8+0x1]
  40afbe:	mov    r8,r11
  40afc1:	test   r12,r12
  40afc4:	jne    40af80 <__swc_fn_23cea7fa_000150_6203dca2+0x8e0>
  40afc6:	test   r10,r10
  40afc9:	jge    40afd3 <__swc_fn_23cea7fa_000150_6203dca2+0x933>
  40afcb:	mov    BYTE PTR [r11],0x2d
  40afcf:	lea    r8,[r11+0x1]
  40afd3:	mov    BYTE PTR [r8],0x0
  40afd7:	sub    r8,0x1
  40afdb:	cmp    r9,r8
  40afde:	jae    40aff8 <__swc_fn_23cea7fa_000150_6203dca2+0x958>
  40afe0:	mov    al,BYTE PTR [r8]
  40afe3:	mov    dl,BYTE PTR [r9]
  40afe6:	mov    BYTE PTR [r8],dl
  40afe9:	sub    r8,0x1
  40afed:	mov    BYTE PTR [r9],al
  40aff0:	inc    r9
  40aff3:	cmp    r9,r8
  40aff6:	jb     40afe0 <__swc_fn_23cea7fa_000150_6203dca2+0x940>
  40aff8:	xor    eax,eax
  40affa:	test   rcx,rcx
  40affd:	je     40b030 <__swc_fn_23cea7fa_000150_6203dca2+0x990>
  40afff:	mov    rdx,rcx
  40b002:	mov    r8b,BYTE PTR [rdx]
  40b005:	test   r8b,r8b
  40b008:	je     40b030 <__swc_fn_23cea7fa_000150_6203dca2+0x990>
  40b00a:	cs nop WORD PTR [rax+rax*1+0x0]
  40b014:	cs nop WORD PTR [rax+rax*1+0x0]
  40b01e:	xchg   ax,ax
  40b020:	add    rdx,0x1
  40b024:	add    rax,0x1
  40b028:	mov    r8b,BYTE PTR [rdx]
  40b02b:	test   r8b,r8b
  40b02e:	jne    40b020 <__swc_fn_23cea7fa_000150_6203dca2+0x980>
  40b030:	mov    QWORD PTR [rsp+0x240],rcx
  40b038:	mov    QWORD PTR [rsp+0x248],rax
  40b040:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  40b049:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  40b052:	lea    rcx,[rsp+0x250]
  40b05a:	call   409e30 <__swc_fn_23cea7fa_000120_2648f149>
  40b05f:	jmp    40b765 <__swc_fn_23cea7fa_000150_6203dca2+0x10c5>
  40b064:	lea    rcx,[rsp+0x260]
  40b06c:	vxorps xmm0,xmm0,xmm0
  40b070:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  40b079:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  40b082:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  40b08b:	vzeroupper
  40b08e:	mov    DWORD PTR [rsp+0x2c0],0x0
  40b099:	vmovsd xmm0,QWORD PTR [rdx]
  40b09d:	vcomisd xmm0,xmm0
  40b0a1:	setne  dl
  40b0a4:	movzx  edx,dl
  40b0a7:	setp   r8b
  40b0ab:	movzx  r8d,r8b
  40b0af:	or     edx,r8d
  40b0b2:	test   dl,dl
  40b0b4:	je     40b0c1 <__swc_fn_23cea7fa_000150_6203dca2+0xa21>
  40b0b6:	mov    DWORD PTR [rcx],0x6e616e
  40b0bc:	jmp    40b6c8 <__swc_fn_23cea7fa_000150_6203dca2+0x1028>
  40b0c1:	vcomisd xmm0,xmm11
  40b0c6:	ja     40b0d7 <__swc_fn_23cea7fa_000150_6203dca2+0xa37>
  40b0c8:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  40b0d1:	vcomisd xmm6,xmm0
  40b0d5:	jbe    40b0fb <__swc_fn_23cea7fa_000150_6203dca2+0xa5b>
  40b0d7:	vxorpd xmm1,xmm1,xmm1
  40b0db:	vcomisd xmm1,xmm0
  40b0df:	jbe    40b0f0 <__swc_fn_23cea7fa_000150_6203dca2+0xa50>
  40b0e1:	mov    DWORD PTR [rcx],0x666e692d
  40b0e7:	mov    BYTE PTR [rcx+0x4],0x0
  40b0eb:	jmp    40b6c8 <__swc_fn_23cea7fa_000150_6203dca2+0x1028>
  40b0f0:	mov    DWORD PTR [rcx],0x666e69
  40b0f6:	jmp    40b6c8 <__swc_fn_23cea7fa_000150_6203dca2+0x1028>
  40b0fb:	vcomisd xmm0,xmm13
  40b100:	jae    40b10c <__swc_fn_23cea7fa_000150_6203dca2+0xa6c>
  40b102:	vcomisd xmm12,xmm0
  40b106:	jbe    40b46e <__swc_fn_23cea7fa_000150_6203dca2+0xdce>
  40b10c:	vmovups xmm1,xmm0
  40b110:	vxorpd xmm2,xmm2,xmm2
  40b114:	vcomisd xmm2,xmm0
  40b118:	jbe    40b128 <__swc_fn_23cea7fa_000150_6203dca2+0xa88>
  40b11a:	vmovsd xmm0,xmm0,xmm1
  40b11e:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x84fa]        # 413620 <__swc_rdata_base_23cea7fa+0x510>
  40b126:	jmp    40b12c <__swc_fn_23cea7fa_000150_6203dca2+0xa8c>
  40b128:	vmovsd xmm0,xmm0,xmm1
  40b12c:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  40b135:	xor    r8d,r8d
  40b138:	vcomisd xmm0,xmm6
  40b13c:	jb     40b14e <__swc_fn_23cea7fa_000150_6203dca2+0xaae>
  40b13e:	xchg   ax,ax
  40b140:	vdivsd xmm0,xmm0,xmm6
  40b144:	add    r8,0x1
  40b148:	vcomisd xmm0,xmm6
  40b14c:	jae    40b140 <__swc_fn_23cea7fa_000150_6203dca2+0xaa0>
  40b14e:	mov    r9,rcx
  40b151:	vxorpd xmm2,xmm2,xmm2
  40b155:	vcomisd xmm2,xmm1
  40b159:	jbe    40b162 <__swc_fn_23cea7fa_000150_6203dca2+0xac2>
  40b15b:	mov    BYTE PTR [rcx],0x2d
  40b15e:	lea    r9,[rcx+0x1]
  40b162:	vcvttsd2si rdx,xmm0
  40b167:	mov    r10b,dl
  40b16a:	add    r10b,0x30
  40b16e:	mov    BYTE PTR [r9],r10b
  40b171:	vxorpd xmm1,xmm1,xmm1
  40b175:	movzx  edx,dl
  40b178:	vcvtsi2sd xmm1,xmm1,rdx
  40b17d:	vsubsd xmm0,xmm0,xmm1
  40b181:	vmulsd xmm0,xmm0,xmm6
  40b185:	mov    BYTE PTR [r9+0x1],0x2e
  40b18a:	vcvttsd2si rdx,xmm0
  40b18f:	mov    r10b,dl
  40b192:	add    r10b,0x30
  40b196:	mov    BYTE PTR [r9+0x2],r10b
  40b19a:	vxorpd xmm1,xmm1,xmm1
  40b19e:	movzx  edx,dl
  40b1a1:	vcvtsi2sd xmm1,xmm1,rdx
  40b1a6:	vsubsd xmm0,xmm0,xmm1
  40b1aa:	vmulsd xmm0,xmm0,xmm6
  40b1ae:	vcvttsd2si rdx,xmm0
  40b1b3:	mov    r10b,dl
  40b1b6:	add    r10b,0x30
  40b1ba:	mov    BYTE PTR [r9+0x3],r10b
  40b1be:	vxorpd xmm1,xmm1,xmm1
  40b1c2:	movzx  edx,dl
  40b1c5:	vcvtsi2sd xmm1,xmm1,rdx
  40b1ca:	vsubsd xmm0,xmm0,xmm1
  40b1ce:	vmulsd xmm0,xmm0,xmm6
  40b1d2:	vcvttsd2si rdx,xmm0
  40b1d7:	mov    r10b,dl
  40b1da:	add    r10b,0x30
  40b1de:	mov    BYTE PTR [r9+0x4],r10b
  40b1e2:	vxorpd xmm1,xmm1,xmm1
  40b1e6:	movzx  edx,dl
  40b1e9:	vcvtsi2sd xmm1,xmm1,rdx
  40b1ee:	vsubsd xmm0,xmm0,xmm1
  40b1f2:	vmulsd xmm0,xmm0,xmm6
  40b1f6:	vcvttsd2si rdx,xmm0
  40b1fb:	mov    r10b,dl
  40b1fe:	add    r10b,0x30
  40b202:	mov    BYTE PTR [r9+0x5],r10b
  40b206:	vxorpd xmm1,xmm1,xmm1
  40b20a:	movzx  edx,dl
  40b20d:	vcvtsi2sd xmm1,xmm1,rdx
  40b212:	vsubsd xmm0,xmm0,xmm1
  40b216:	vmulsd xmm0,xmm0,xmm6
  40b21a:	vcvttsd2si rdx,xmm0
  40b21f:	mov    r10b,dl
  40b222:	add    r10b,0x30
  40b226:	mov    BYTE PTR [r9+0x6],r10b
  40b22a:	vxorpd xmm1,xmm1,xmm1
  40b22e:	movzx  edx,dl
  40b231:	vcvtsi2sd xmm1,xmm1,rdx
  40b236:	vsubsd xmm0,xmm0,xmm1
  40b23a:	vmulsd xmm0,xmm0,xmm6
  40b23e:	vcvttsd2si rdx,xmm0
  40b243:	mov    r10b,dl
  40b246:	add    r10b,0x30
  40b24a:	mov    BYTE PTR [r9+0x7],r10b
  40b24e:	vxorpd xmm1,xmm1,xmm1
  40b252:	movzx  edx,dl
  40b255:	vcvtsi2sd xmm1,xmm1,rdx
  40b25a:	vsubsd xmm0,xmm0,xmm1
  40b25e:	vmulsd xmm0,xmm0,xmm6
  40b262:	vcvttsd2si rdx,xmm0
  40b267:	mov    r10b,dl
  40b26a:	add    r10b,0x30
  40b26e:	mov    BYTE PTR [r9+0x8],r10b
  40b272:	vxorpd xmm1,xmm1,xmm1
  40b276:	movzx  edx,dl
  40b279:	vcvtsi2sd xmm1,xmm1,rdx
  40b27e:	vsubsd xmm0,xmm0,xmm1
  40b282:	vmulsd xmm0,xmm0,xmm6
  40b286:	vcvttsd2si rdx,xmm0
  40b28b:	mov    r10b,dl
  40b28e:	add    r10b,0x30
  40b292:	mov    BYTE PTR [r9+0x9],r10b
  40b296:	vxorpd xmm1,xmm1,xmm1
  40b29a:	movzx  edx,dl
  40b29d:	vcvtsi2sd xmm1,xmm1,rdx
  40b2a2:	vsubsd xmm0,xmm0,xmm1
  40b2a6:	vmulsd xmm0,xmm0,xmm6
  40b2aa:	vcvttsd2si rdx,xmm0
  40b2af:	mov    r10b,dl
  40b2b2:	add    r10b,0x30
  40b2b6:	mov    BYTE PTR [r9+0xa],r10b
  40b2ba:	vxorpd xmm1,xmm1,xmm1
  40b2be:	movzx  edx,dl
  40b2c1:	vcvtsi2sd xmm1,xmm1,rdx
  40b2c6:	vsubsd xmm0,xmm0,xmm1
  40b2ca:	vmulsd xmm0,xmm0,xmm6
  40b2ce:	vcvttsd2si rdx,xmm0
  40b2d3:	mov    r10b,dl
  40b2d6:	add    r10b,0x30
  40b2da:	mov    BYTE PTR [r9+0xb],r10b
  40b2de:	lea    r10,[r9+0x4]
  40b2e2:	vxorpd xmm1,xmm1,xmm1
  40b2e6:	movzx  edx,dl
  40b2e9:	vcvtsi2sd xmm1,xmm1,rdx
  40b2ee:	vsubsd xmm0,xmm0,xmm1
  40b2f2:	vmulsd xmm0,xmm0,xmm6
  40b2f6:	vcvttsd2si rdx,xmm0
  40b2fb:	mov    r11b,dl
  40b2fe:	add    r11b,0x30
  40b302:	mov    BYTE PTR [r9+0xc],r11b
  40b306:	vxorpd xmm1,xmm1,xmm1
  40b30a:	movzx  edx,dl
  40b30d:	vcvtsi2sd xmm1,xmm1,rdx
  40b312:	vsubsd xmm0,xmm0,xmm1
  40b316:	vmulsd xmm0,xmm0,xmm6
  40b31a:	vcvttsd2si rdx,xmm0
  40b31f:	mov    r11b,dl
  40b322:	add    r11b,0x30
  40b326:	mov    BYTE PTR [r9+0xd],r11b
  40b32a:	lea    r10,[r10+0x2]
  40b32e:	vxorpd xmm1,xmm1,xmm1
  40b332:	movzx  edx,dl
  40b335:	vcvtsi2sd xmm1,xmm1,rdx
  40b33a:	vsubsd xmm0,xmm0,xmm1
  40b33e:	vmulsd xmm0,xmm0,xmm6
  40b342:	vcvttsd2si rdx,xmm0
  40b347:	mov    r11b,dl
  40b34a:	add    r11b,0x30
  40b34e:	mov    BYTE PTR [r9+0xe],r11b
  40b352:	vxorpd xmm1,xmm1,xmm1
  40b356:	movzx  edx,dl
  40b359:	vcvtsi2sd xmm1,xmm1,rdx
  40b35e:	vsubsd xmm0,xmm0,xmm1
  40b362:	vmulsd xmm0,xmm0,xmm6
  40b366:	vcvttsd2si rdx,xmm0
  40b36b:	mov    r11b,dl
  40b36e:	add    r11b,0x30
  40b372:	mov    BYTE PTR [r9+0xf],r11b
  40b376:	lea    r10,[r10+0x2]
  40b37a:	lea    r10,[r10+0x2]
  40b37e:	lea    r10,[r10+0x2]
  40b382:	lea    r10,[r10+0x2]
  40b386:	lea    r10,[r10+0x2]
  40b38a:	vxorpd xmm1,xmm1,xmm1
  40b38e:	movzx  edx,dl
  40b391:	vcvtsi2sd xmm1,xmm1,rdx
  40b396:	vsubsd xmm0,xmm0,xmm1
  40b39a:	vmulsd xmm0,xmm0,xmm6
  40b39e:	vcvttsd2si rdx,xmm0
  40b3a3:	mov    r11b,dl
  40b3a6:	add    r11b,0x30
  40b3aa:	mov    BYTE PTR [r9+0x10],r11b
  40b3ae:	vxorpd xmm1,xmm1,xmm1
  40b3b2:	movzx  edx,dl
  40b3b5:	vcvtsi2sd xmm1,xmm1,rdx
  40b3ba:	vsubsd xmm0,xmm0,xmm1
  40b3be:	vmulsd xmm0,xmm0,xmm6
  40b3c2:	vcvttsd2si rdx,xmm0
  40b3c7:	add    dl,0x30
  40b3ca:	mov    BYTE PTR [r9+0x11],dl
  40b3ce:	mov    BYTE PTR [r10+0x2],0x65
  40b3d3:	lea    r9,[r10+0x3]
  40b3d7:	test   r8,r8
  40b3da:	jl     40b3e3 <__swc_fn_23cea7fa_000150_6203dca2+0xd43>
  40b3dc:	mov    BYTE PTR [r9],0x2b
  40b3e0:	inc    r9
  40b3e3:	mov    r10,r9
  40b3e6:	mov    rdx,r8
  40b3e9:	nop    DWORD PTR [rax+0x0]
  40b3f0:	mov    r11,rdx
  40b3f3:	movabs rdx,0x6666666666666667
  40b3fd:	mov    rax,r11
  40b400:	imul   rdx
  40b403:	sar    rdx,0x2
  40b407:	mov    r12,rdx
  40b40a:	shr    rdx,0x3f
  40b40e:	add    r12,rdx
  40b411:	mov    rdx,r12
  40b414:	imul   r13,r12,0xa
  40b418:	sub    r11,r13
  40b41b:	mov    r13,QWORD PTR [rip+0x81ee]        # 413610 <__swc_rdata_base_23cea7fa+0x500>
  40b422:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b427:	mov    BYTE PTR [r10],r11b
  40b42a:	lea    r11,[r10+0x1]
  40b42e:	mov    r10,r11
  40b431:	test   r12,r12
  40b434:	jne    40b3f0 <__swc_fn_23cea7fa_000150_6203dca2+0xd50>
  40b436:	test   r8,r8
  40b439:	jge    40b443 <__swc_fn_23cea7fa_000150_6203dca2+0xda3>
  40b43b:	mov    BYTE PTR [r11],0x2d
  40b43f:	lea    r10,[r11+0x1]
  40b443:	mov    BYTE PTR [r10],0x0
  40b447:	sub    r10,0x1
  40b44b:	nop    DWORD PTR [rax+rax*1+0x0]
  40b450:	cmp    r9,r10
  40b453:	jae    40b6c8 <__swc_fn_23cea7fa_000150_6203dca2+0x1028>
  40b459:	mov    al,BYTE PTR [r10]
  40b45c:	mov    dl,BYTE PTR [r9]
  40b45f:	mov    BYTE PTR [r10],dl
  40b462:	sub    r10,0x1
  40b466:	mov    BYTE PTR [r9],al
  40b469:	inc    r9
  40b46c:	jmp    40b450 <__swc_fn_23cea7fa_000150_6203dca2+0xdb0>
  40b46e:	vcvttsd2si rdx,xmm0
  40b473:	mov    r8,rdx
  40b476:	vxorpd xmm1,xmm1,xmm1
  40b47a:	vcvtsi2sd xmm1,xmm1,rdx
  40b47f:	vsubsd xmm1,xmm0,xmm1
  40b483:	mov    r9d,0x8
  40b489:	vxorpd xmm2,xmm2,xmm2
  40b48d:	vcomisd xmm2,xmm1
  40b491:	ja     40b49e <__swc_fn_23cea7fa_000150_6203dca2+0xdfe>
  40b493:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40b49c:	jmp    40b4af <__swc_fn_23cea7fa_000150_6203dca2+0xe0f>
  40b49e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x817a]        # 413620 <__swc_rdata_base_23cea7fa+0x510>
  40b4a6:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40b4af:	test   r9d,r9d
  40b4b2:	je     40b4c9 <__swc_fn_23cea7fa_000150_6203dca2+0xe29>
  40b4b4:	cs nop WORD PTR [rax+rax*1+0x0]
  40b4be:	xchg   ax,ax
  40b4c0:	vmulsd xmm1,xmm1,xmm6
  40b4c4:	dec    r9d
  40b4c7:	jne    40b4c0 <__swc_fn_23cea7fa_000150_6203dca2+0xe20>
  40b4c9:	vcvttsd2si r9,xmm1
  40b4ce:	mov    r10,r9
  40b4d1:	vxorpd xmm2,xmm2,xmm2
  40b4d5:	vcvtsi2sd xmm2,xmm2,r9
  40b4da:	vsubsd xmm1,xmm1,xmm2
  40b4de:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  40b4e7:	vcomisd xmm1,xmm6
  40b4eb:	lea    r9,[r9+0x1]
  40b4ef:	cmova  r10,r9
  40b4f3:	cmp    r10,0x5f5e100
  40b4fa:	jne    40b513 <__swc_fn_23cea7fa_000150_6203dca2+0xe73>
  40b4fc:	lea    r8,[rdx-0x1]
  40b500:	vxorpd xmm1,xmm1,xmm1
  40b504:	vcomisd xmm1,xmm0
  40b508:	lea    rdx,[rdx+0x1]
  40b50c:	cmovbe r8,rdx
  40b510:	xor    r10d,r10d
  40b513:	mov    r9,rcx
  40b516:	test   r8,r8
  40b519:	jne    40b539 <__swc_fn_23cea7fa_000150_6203dca2+0xe99>
  40b51b:	vxorpd xmm1,xmm1,xmm1
  40b51f:	vcomisd xmm1,xmm0
  40b523:	jbe    40b52c <__swc_fn_23cea7fa_000150_6203dca2+0xe8c>
  40b525:	mov    BYTE PTR [rcx],0x2d
  40b528:	lea    r9,[rcx+0x1]
  40b52c:	mov    BYTE PTR [r9],0x30
  40b530:	add    r9,0x1
  40b534:	jmp    40b5cb <__swc_fn_23cea7fa_000150_6203dca2+0xf2b>
  40b539:	mov    r9,rcx
  40b53c:	mov    rdx,r8
  40b53f:	nop
  40b540:	mov    r11,rdx
  40b543:	movabs rdx,0x6666666666666667
  40b54d:	mov    r15,rax
  40b550:	mov    rax,r11
  40b553:	imul   rdx
  40b556:	mov    r12,rdx
  40b559:	mov    rax,r15
  40b55c:	sar    r12,0x2
  40b560:	mov    rdx,r12
  40b563:	shr    rdx,0x3f
  40b567:	add    r12,rdx
  40b56a:	mov    rdx,r12
  40b56d:	imul   r13,r12,0xa
  40b571:	sub    r11,r13
  40b574:	mov    r13,QWORD PTR [rip+0x8095]        # 413610 <__swc_rdata_base_23cea7fa+0x500>
  40b57b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b580:	mov    BYTE PTR [r9],r11b
  40b583:	lea    r11,[r9+0x1]
  40b587:	mov    r9,r11
  40b58a:	test   r12,r12
  40b58d:	jne    40b540 <__swc_fn_23cea7fa_000150_6203dca2+0xea0>
  40b58f:	test   r8,r8
  40b592:	jge    40b59c <__swc_fn_23cea7fa_000150_6203dca2+0xefc>
  40b594:	mov    BYTE PTR [r11],0x2d
  40b598:	lea    r9,[r11+0x1]
  40b59c:	mov    rdx,r9
  40b59f:	mov    BYTE PTR [r9],0x0
  40b5a3:	sub    r9,0x1
  40b5a7:	mov    r8,rcx
  40b5aa:	cmp    r8,r9
  40b5ad:	jae    40b5c8 <__swc_fn_23cea7fa_000150_6203dca2+0xf28>
  40b5af:	nop
  40b5b0:	mov    r11b,BYTE PTR [r9]
  40b5b3:	mov    r12b,BYTE PTR [r8]
  40b5b6:	mov    BYTE PTR [r9],r12b
  40b5b9:	sub    r9,0x1
  40b5bd:	mov    BYTE PTR [r8],r11b
  40b5c0:	inc    r8
  40b5c3:	cmp    r8,r9
  40b5c6:	jb     40b5b0 <__swc_fn_23cea7fa_000150_6203dca2+0xf10>
  40b5c8:	mov    r9,rdx
  40b5cb:	mov    BYTE PTR [r9],0x2e
  40b5cf:	add    r9,0x1
  40b5d3:	xor    r8d,r8d
  40b5d6:	test   r10,r10
  40b5d9:	je     40b61f <__swc_fn_23cea7fa_000150_6203dca2+0xf7f>
  40b5db:	mov    r11d,0x989680
  40b5e1:	cmp    r10,r11
  40b5e4:	jge    40b61f <__swc_fn_23cea7fa_000150_6203dca2+0xf7f>
  40b5e6:	cs nop WORD PTR [rax+rax*1+0x0]
  40b5f0:	inc    r8d
  40b5f3:	movabs rdx,0x6666666666666667
  40b5fd:	mov    r15,rax
  40b600:	mov    rax,r11
  40b603:	imul   rdx
  40b606:	mov    r11,rdx
  40b609:	mov    rax,r15
  40b60c:	sar    r11,0x2
  40b610:	mov    rdx,r11
  40b613:	shr    rdx,0x3f
  40b617:	add    r11,rdx
  40b61a:	cmp    r10,r11
  40b61d:	jl     40b5f0 <__swc_fn_23cea7fa_000150_6203dca2+0xf50>
  40b61f:	test   r8d,r8d
  40b622:	je     40b63d <__swc_fn_23cea7fa_000150_6203dca2+0xf9d>
  40b624:	cs nop WORD PTR [rax+rax*1+0x0]
  40b62e:	xchg   ax,ax
  40b630:	mov    BYTE PTR [r9],0x30
  40b634:	add    r9,0x1
  40b638:	dec    r8d
  40b63b:	jne    40b630 <__swc_fn_23cea7fa_000150_6203dca2+0xf90>
  40b63d:	mov    r8,r9
  40b640:	mov    rdx,r10
  40b643:	cs nop WORD PTR [rax+rax*1+0x0]
  40b64d:	nop    DWORD PTR [rax]
  40b650:	mov    r11,rdx
  40b653:	movabs rdx,0x6666666666666667
  40b65d:	mov    rax,r11
  40b660:	imul   rdx
  40b663:	sar    rdx,0x2
  40b667:	mov    r12,rdx
  40b66a:	shr    rdx,0x3f
  40b66e:	add    r12,rdx
  40b671:	mov    rdx,r12
  40b674:	imul   r13,r12,0xa
  40b678:	sub    r11,r13
  40b67b:	mov    r13,QWORD PTR [rip+0x7f8e]        # 413610 <__swc_rdata_base_23cea7fa+0x500>
  40b682:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b687:	mov    BYTE PTR [r8],r11b
  40b68a:	lea    r11,[r8+0x1]
  40b68e:	mov    r8,r11
  40b691:	test   r12,r12
  40b694:	jne    40b650 <__swc_fn_23cea7fa_000150_6203dca2+0xfb0>
  40b696:	test   r10,r10
  40b699:	jge    40b6a3 <__swc_fn_23cea7fa_000150_6203dca2+0x1003>
  40b69b:	mov    BYTE PTR [r11],0x2d
  40b69f:	lea    r8,[r11+0x1]
  40b6a3:	mov    BYTE PTR [r8],0x0
  40b6a7:	sub    r8,0x1
  40b6ab:	cmp    r9,r8
  40b6ae:	jae    40b6c8 <__swc_fn_23cea7fa_000150_6203dca2+0x1028>
  40b6b0:	mov    al,BYTE PTR [r8]
  40b6b3:	mov    dl,BYTE PTR [r9]
  40b6b6:	mov    BYTE PTR [r8],dl
  40b6b9:	sub    r8,0x1
  40b6bd:	mov    BYTE PTR [r9],al
  40b6c0:	inc    r9
  40b6c3:	cmp    r9,r8
  40b6c6:	jb     40b6b0 <__swc_fn_23cea7fa_000150_6203dca2+0x1010>
  40b6c8:	xor    eax,eax
  40b6ca:	test   rcx,rcx
  40b6cd:	je     40b6f0 <__swc_fn_23cea7fa_000150_6203dca2+0x1050>
  40b6cf:	mov    rdx,rcx
  40b6d2:	mov    r8b,BYTE PTR [rdx]
  40b6d5:	test   r8b,r8b
  40b6d8:	je     40b6f0 <__swc_fn_23cea7fa_000150_6203dca2+0x1050>
  40b6da:	nop    WORD PTR [rax+rax*1+0x0]
  40b6e0:	add    rdx,0x1
  40b6e4:	add    rax,0x1
  40b6e8:	mov    r8b,BYTE PTR [rdx]
  40b6eb:	test   r8b,r8b
  40b6ee:	jne    40b6e0 <__swc_fn_23cea7fa_000150_6203dca2+0x1040>
  40b6f0:	mov    QWORD PTR [rsp+0x3f8],rcx
  40b6f8:	mov    QWORD PTR [rsp+0x400],rax
  40b700:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  40b709:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  40b712:	lea    rcx,[rsp+0x408]
  40b71a:	call   409e30 <__swc_fn_23cea7fa_000120_2648f149>
  40b71f:	jmp    40b765 <__swc_fn_23cea7fa_000150_6203dca2+0x10c5>
  40b721:	mov    rcx,rdx
  40b724:	call   409e30 <__swc_fn_23cea7fa_000120_2648f149>
  40b729:	jmp    40b765 <__swc_fn_23cea7fa_000150_6203dca2+0x10c5>
  40b72b:	mov    al,BYTE PTR [rdx]
  40b72d:	test   al,al
  40b72f:	je     40b73a <__swc_fn_23cea7fa_000150_6203dca2+0x109a>
  40b731:	lea    rax,[rip+0x7ef8]        # 413630 <__swc_rdata_base_23cea7fa+0x520>
  40b738:	jmp    40b741 <__swc_fn_23cea7fa_000150_6203dca2+0x10a1>
  40b73a:	lea    rax,[rip+0x7eff]        # 413640 <__swc_rdata_base_23cea7fa+0x530>
  40b741:	mov    rcx,rax
  40b744:	call   409e30 <__swc_fn_23cea7fa_000120_2648f149>
  40b749:	jmp    40b765 <__swc_fn_23cea7fa_000150_6203dca2+0x10c5>
  40b74b:	lea    rcx,[rip+0x7efe]        # 413650 <__swc_rdata_base_23cea7fa+0x540>
  40b752:	call   409e30 <__swc_fn_23cea7fa_000120_2648f149>
  40b757:	jmp    40b765 <__swc_fn_23cea7fa_000150_6203dca2+0x10c5>
  40b759:	lea    rcx,[rip+0x7ef0]        # 413650 <__swc_rdata_base_23cea7fa+0x540>
  40b760:	call   409e30 <__swc_fn_23cea7fa_000120_2648f149>
  40b765:	add    rdi,0x1
  40b769:	sub    rsi,0x1
  40b76d:	vmovups xmm0,xmm12
  40b772:	vmovsd xmm6,QWORD PTR [rip+0x7ee6]        # 413660 <__swc_rdata_base_23cea7fa+0x550>
  40b77a:	test   rsi,rsi
  40b77d:	jne    40a7b0 <__swc_fn_23cea7fa_000150_6203dca2+0x110>
  40b783:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  40b78c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  40b795:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  40b79e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  40b7a7:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  40b7b0:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  40b7b9:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  40b7c2:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  40b7cb:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  40b7d4:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  40b7dd:	add    rsp,0x4e8
  40b7e4:	pop    r15
  40b7e6:	pop    r13
  40b7e8:	pop    r12
  40b7ea:	pop    rdi
  40b7eb:	pop    rsi
  40b7ec:	pop    rbx
  40b7ed:	ret
	...

000000000040b7f0 <__swc_fn_23cea7fa_000153_86f1d437>:
  40b7f0:	vxorps xmm0,xmm0,xmm0
  40b7f4:	vmovups XMMWORD PTR [rcx],xmm0
  40b7f8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b7fd:	ret
	...

000000000040b800 <__swc_fn_23cea7fa_000156_86f1d437>:
  40b800:	vxorps xmm0,xmm0,xmm0
  40b804:	vmovups XMMWORD PTR [rcx],xmm0
  40b808:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b80d:	vxorps xmm0,xmm0,xmm0
  40b811:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b816:	vmovups xmm0,XMMWORD PTR [rip+0x7f52]        # 413770 <__swc_rdata_base_23cea7fa+0x660>
  40b81e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b823:	vxorps xmm0,xmm0,xmm0
  40b827:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40b82c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40b831:	vxorps xmm0,xmm0,xmm0
  40b835:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40b83a:	mov    QWORD PTR [rcx+0x70],0x0
  40b842:	ret
	...

000000000040b850 <__swc_fn_23cea7fa_000159_86f1d437>:
  40b850:	vxorps xmm0,xmm0,xmm0
  40b854:	vmovups XMMWORD PTR [rcx],xmm0
  40b858:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b85d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b862:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b867:	ret
	...

000000000040b870 <__swc_fn_23cea7fa_000162_e36363a8>:
  40b870:	push   rsi
  40b871:	push   rdi
  40b872:	sub    rsp,0x8
  40b876:	mov    rsi,rcx
  40b879:	mov    rdi,QWORD PTR [rsi+0x50]
  40b87d:	test   rdi,rdi
  40b880:	je     40b887 <__swc_fn_23cea7fa_000162_e36363a8+0x17>
  40b882:	mov    rcx,rsi
  40b885:	call   rdi
  40b887:	mov    QWORD PTR [rsi+0x20],0x0
  40b88f:	mov    rax,QWORD PTR [rsi+0x30]
  40b893:	test   rax,rax
  40b896:	je     40b8c4 <__swc_fn_23cea7fa_000162_e36363a8+0x54>
  40b898:	nop    DWORD PTR [rax+rax*1+0x0]
  40b8a0:	mov    rdi,QWORD PTR [rax+0x8]
  40b8a4:	mov    rcx,rsi
  40b8a7:	mov    rdx,QWORD PTR [rax+0x10]
  40b8ab:	mov    rax,QWORD PTR [rax+0x18]
  40b8af:	mov    r8,rax
  40b8b2:	call   40ea10 <__swc_fn_23cea7fa_000160_47b270e1>
  40b8b7:	mov    QWORD PTR [rsi+0x30],rdi
  40b8bb:	mov    rax,QWORD PTR [rsi+0x30]
  40b8bf:	test   rax,rax
  40b8c2:	jne    40b8a0 <__swc_fn_23cea7fa_000162_e36363a8+0x30>
  40b8c4:	mov    QWORD PTR [rsi+0x38],0x0
  40b8cc:	add    rsp,0x8
  40b8d0:	pop    rdi
  40b8d1:	pop    rsi
  40b8d2:	ret
	...

000000000040b8e0 <__swc_fn_23cea7fa_000165_016ee66a>:
  40b8e0:	push   rbx
  40b8e1:	push   rsi
  40b8e2:	push   rdi
  40b8e3:	push   r12
  40b8e5:	sub    rsp,0x188
  40b8ec:	mov    rbx,rcx
  40b8ef:	lea    rsi,[rip+0x1b492]        # 426d88 <__swc_bss_base_23cea7fa+0x2d48>
  40b8f6:	mov    rcx,rsi
  40b8f9:	call   40e420 <__swc_fn_23cea7fa_000139_86bb0f90>
  40b8fe:	mov    rax,QWORD PTR [rip+0x1b48b]        # 426d90 <__swc_bss_base_23cea7fa+0x2d50>
  40b905:	mov    rdi,rax
  40b908:	test   rdi,rdi
  40b90b:	je     40b939 <__swc_fn_23cea7fa_000165_016ee66a+0x59>
  40b90d:	nop    DWORD PTR [rax]
  40b910:	cmp    QWORD PTR [rdi+0x8],rbx
  40b914:	jne    40b92e <__swc_fn_23cea7fa_000165_016ee66a+0x4e>
  40b916:	mov    rcx,rsi
  40b919:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40b91e:	mov    rax,rdi
  40b921:	add    rsp,0x188
  40b928:	pop    r12
  40b92a:	pop    rdi
  40b92b:	pop    rsi
  40b92c:	pop    rbx
  40b92d:	ret
  40b92e:	mov    rax,QWORD PTR [rdi]
  40b931:	mov    rdi,rax
  40b934:	test   rax,rax
  40b937:	jne    40b910 <__swc_fn_23cea7fa_000165_016ee66a+0x30>
  40b939:	call   411a00 <__swc_fn_23cea7fa_000143_d299b428>
  40b93e:	mov    rdi,rax
  40b941:	test   rax,rax
  40b944:	jne    40b95d <__swc_fn_23cea7fa_000165_016ee66a+0x7d>
  40b946:	mov    rcx,rsi
  40b949:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40b94e:	xor    eax,eax
  40b950:	add    rsp,0x188
  40b957:	pop    r12
  40b959:	pop    rdi
  40b95a:	pop    rsi
  40b95b:	pop    rbx
  40b95c:	ret
  40b95d:	lea    rax,[rsp+0x18]
  40b962:	mov    QWORD PTR [rax+0x10],0x0
  40b96a:	mov    QWORD PTR [rax+0x18],0x0
  40b972:	mov    DWORD PTR [rax+0x20],0x0
  40b979:	mov    BYTE PTR [rax+0x24],0x0
  40b97d:	mov    rax,QWORD PTR [rip+0x1b40c]        # 426d90 <__swc_bss_base_23cea7fa+0x2d50>
  40b984:	mov    QWORD PTR [rsp+0x18],rax
  40b989:	mov    QWORD PTR [rsp+0x20],rbx
  40b98e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40b994:	vmovups XMMWORD PTR [rdi],xmm0
  40b998:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40b99e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  40b9a3:	mov    rax,QWORD PTR [rsp+0x38]
  40b9a8:	mov    QWORD PTR [rdi+0x20],rax
  40b9ac:	mov    QWORD PTR [rip+0x1b3dd],rdi        # 426d90 <__swc_bss_base_23cea7fa+0x2d50>
  40b9b3:	lea    rax,[rsp+0x40]
  40b9b8:	mov    QWORD PTR [rax],0x0
  40b9bf:	mov    rcx,rbx
  40b9c2:	mov    rdx,rax
  40b9c5:	call   40e500 <__swc_fn_23cea7fa_000145_1534de9a>
  40b9ca:	mov    rbx,rax
  40b9cd:	test   rax,rax
  40b9d0:	jne    40b9ea <__swc_fn_23cea7fa_000165_016ee66a+0x10a>
  40b9d2:	mov    rcx,rsi
  40b9d5:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40b9da:	mov    rax,rdi
  40b9dd:	add    rsp,0x188
  40b9e4:	pop    r12
  40b9e6:	pop    rdi
  40b9e7:	pop    rsi
  40b9e8:	pop    rbx
  40b9e9:	ret
  40b9ea:	lea    r12,[rsp+0x50]
  40b9ef:	mov    QWORD PTR [r12],0x0
  40b9f7:	mov    rcx,rbx
  40b9fa:	mov    rdx,QWORD PTR [rsp+0x40]
  40b9ff:	mov    r8,r12
  40ba02:	call   411ab0 <__swc_fn_23cea7fa_000146_162f363d>
  40ba07:	test   rax,rax
  40ba0a:	jne    40ba24 <__swc_fn_23cea7fa_000165_016ee66a+0x144>
  40ba0c:	mov    rcx,rsi
  40ba0f:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40ba14:	mov    rax,rdi
  40ba17:	add    rsp,0x188
  40ba1e:	pop    r12
  40ba20:	pop    rdi
  40ba21:	pop    rsi
  40ba22:	pop    rbx
  40ba23:	ret
  40ba24:	cmp    QWORD PTR [r12],0x10
  40ba29:	jb     40bb2c <__swc_fn_23cea7fa_000165_016ee66a+0x24c>
  40ba2f:	mov    ecx,DWORD PTR [rax]
  40ba31:	cmp    ecx,0x42445753
  40ba37:	jne    40bb2c <__swc_fn_23cea7fa_000165_016ee66a+0x24c>
  40ba3d:	mov    ecx,DWORD PTR [rax+0x4]
  40ba40:	cmp    ecx,0x1
  40ba43:	jne    40bb2c <__swc_fn_23cea7fa_000165_016ee66a+0x24c>
  40ba49:	mov    ecx,DWORD PTR [rax+0x8]
  40ba4c:	mov    edx,DWORD PTR [rax+0xc]
  40ba4f:	imul   r8,rcx,0x14
  40ba53:	mov    r9,QWORD PTR [rsp+0x50]
  40ba58:	sub    r9,0x10
  40ba5c:	cmp    r8,r9
  40ba5f:	ja     40bb2c <__swc_fn_23cea7fa_000165_016ee66a+0x24c>
  40ba65:	lea    r8,[r8+0x10]
  40ba69:	cmp    rdx,r8
  40ba6c:	jb     40bb2c <__swc_fn_23cea7fa_000165_016ee66a+0x24c>
  40ba72:	mov    r8,QWORD PTR [rsp+0x50]
  40ba77:	cmp    rdx,r8
  40ba7a:	ja     40bb2c <__swc_fn_23cea7fa_000165_016ee66a+0x24c>
  40ba80:	xor    r8d,r8d
  40ba83:	test   rcx,rcx
  40ba86:	jbe    40bb52 <__swc_fn_23cea7fa_000165_016ee66a+0x272>
  40ba8c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  40ba92:	cs nop WORD PTR [rax+rax*1+0x0]
  40ba9c:	nop    DWORD PTR [rax+0x0]
  40baa0:	imul   r9,r8,0x14
  40baa4:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  40baa9:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  40baae:	add    r10,r11
  40bab1:	movabs r11,0x100000000
  40babb:	cmp    r10,r11
  40babe:	ja     40bb2c <__swc_fn_23cea7fa_000165_016ee66a+0x24c>
  40bac0:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  40bac5:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  40baca:	test   r10d,r10d
  40bacd:	setne  r11b
  40bad1:	je     40baeb <__swc_fn_23cea7fa_000165_016ee66a+0x20b>
  40bad3:	cmp    r10d,edx
  40bad6:	setb   r11b
  40bada:	jb     40baeb <__swc_fn_23cea7fa_000165_016ee66a+0x20b>
  40badc:	vmovq  r11,xmm1
  40bae1:	cmp    r10,r11
  40bae4:	setae  r10b
  40bae8:	mov    r11b,r10b
  40baeb:	mov    r10,r11
  40baee:	test   r11b,r11b
  40baf1:	jne    40bb18 <__swc_fn_23cea7fa_000165_016ee66a+0x238>
  40baf3:	test   r9d,r9d
  40baf6:	setne  r10b
  40bafa:	je     40bb18 <__swc_fn_23cea7fa_000165_016ee66a+0x238>
  40bafc:	cmp    r9d,edx
  40baff:	setb   r10b
  40bb03:	jb     40bb18 <__swc_fn_23cea7fa_000165_016ee66a+0x238>
  40bb05:	vmovq  r10,xmm1
  40bb0a:	cmp    r9,r10
  40bb0d:	setae  r9b
  40bb11:	movzx  r9d,r9b
  40bb15:	mov    r10b,r9b
  40bb18:	test   r10b,r10b
  40bb1b:	jne    40bb2c <__swc_fn_23cea7fa_000165_016ee66a+0x24c>
  40bb1d:	add    r8,0x1
  40bb21:	cmp    r8,rcx
  40bb24:	jb     40baa0 <__swc_fn_23cea7fa_000165_016ee66a+0x1c0>
  40bb2a:	jmp    40bb52 <__swc_fn_23cea7fa_000165_016ee66a+0x272>
  40bb2c:	xor    ecx,ecx
  40bb2e:	cmp    rax,rbx
  40bb31:	cmovne rcx,rax
  40bb35:	call   40a5f0 <__swc_fn_23cea7fa_000147_d7edc04f>
  40bb3a:	mov    rcx,rsi
  40bb3d:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40bb42:	mov    rax,rdi
  40bb45:	add    rsp,0x188
  40bb4c:	pop    r12
  40bb4e:	pop    rdi
  40bb4f:	pop    rsi
  40bb50:	pop    rbx
  40bb51:	ret
  40bb52:	mov    QWORD PTR [rdi+0x10],rax
  40bb56:	mov    rcx,QWORD PTR [rsp+0x50]
  40bb5b:	mov    QWORD PTR [rdi+0x18],rcx
  40bb5f:	mov    eax,DWORD PTR [rax+0x8]
  40bb62:	mov    DWORD PTR [rdi+0x20],eax
  40bb65:	rex mov BYTE PTR [rdi+0x24],0x1
  40bb6a:	mov    rcx,rsi
  40bb6d:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40bb72:	mov    rax,rdi
  40bb75:	add    rsp,0x188
  40bb7c:	pop    r12
  40bb7e:	pop    rdi
  40bb7f:	pop    rsi
  40bb80:	pop    rbx
  40bb81:	ret
	...

000000000040bb90 <__swc_fn_23cea7fa_000168_3459066f>:
  40bb90:	push   rsi
  40bb91:	push   rdi
  40bb92:	push   r12
  40bb94:	mov    rsi,rdx
  40bb97:	mov    rdi,rcx
  40bb9a:	mov    rcx,QWORD PTR [rip+0x1849f]        # 424040 <__swc_bss_base_23cea7fa>
  40bba1:	test   rcx,rcx
  40bba4:	jne    40bbb6 <__swc_fn_23cea7fa_000168_3459066f+0x26>
  40bba6:	call   40ed20 <__swc_fn_23cea7fa_000169_994c8876>
  40bbab:	lea    rcx,[rax+0x1]
  40bbaf:	mov    QWORD PTR [rip+0x1848a],rcx        # 424040 <__swc_bss_base_23cea7fa>
  40bbb6:	dec    rcx
  40bbb9:	call   40bbe0 <__swc_fn_23cea7fa_000171_360af05d>
  40bbbe:	mov    r12,QWORD PTR [rax+0xbe0]
  40bbc5:	test   r12,r12
  40bbc8:	setne  al
  40bbcb:	je     40bbd6 <__swc_fn_23cea7fa_000168_3459066f+0x46>
  40bbcd:	mov    rcx,rdi
  40bbd0:	mov    rdx,rsi
  40bbd3:	call   r12
  40bbd6:	pop    r12
  40bbd8:	pop    rdi
  40bbd9:	pop    rsi
  40bbda:	ret
  40bbdb:	add    BYTE PTR [rax],al
  40bbdd:	add    BYTE PTR [rax],al
	...

000000000040bbe0 <__swc_fn_23cea7fa_000171_360af05d>:
  40bbe0:	push   r12
  40bbe2:	push   rdi
  40bbe3:	push   rsi
  40bbe4:	sub    rsp,0xd0
  40bbeb:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40bbf1:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40bbf7:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40bbfd:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40bc03:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40bc09:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40bc0f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40bc18:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40bc21:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40bc2a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40bc33:	mov    r12,rcx
  40bc36:	mov    edi,ecx
  40bc38:	xor    eax,eax
  40bc3a:	call   407000 <pthread_getspecific@plt>
  40bc3f:	test   rax,rax
  40bc42:	je     40bc46 <__swc_fn_23cea7fa_000171_360af05d+0x66>
  40bc44:	jmp    40bc4e <__swc_fn_23cea7fa_000171_360af05d+0x6e>
  40bc46:	mov    rcx,r12
  40bc49:	call   40ed80 <__swc_fn_23cea7fa_000172_cbeff767>
  40bc4e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40bc54:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40bc5a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40bc60:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40bc66:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40bc6c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40bc72:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40bc7b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40bc84:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40bc8d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40bc96:	add    rsp,0xd0
  40bc9d:	pop    rsi
  40bc9e:	pop    rdi
  40bc9f:	pop    r12
  40bca1:	ret
	...

000000000040bcb0 <__swc_fn_23cea7fa_000174_5eac0ab4>:
  40bcb0:	push   rsi
  40bcb1:	sub    rsp,0x30
  40bcb5:	lea    rsi,[rip+0x1b0e4]        # 426da0 <__swc_bss_base_23cea7fa+0x2d60>
  40bcbc:	mov    rax,QWORD PTR [rsi]
  40bcbf:	test   rax,rax
  40bcc2:	je     40bcca <__swc_fn_23cea7fa_000174_5eac0ab4+0x1a>
  40bcc4:	add    rsp,0x30
  40bcc8:	pop    rsi
  40bcc9:	ret
  40bcca:	mov    ecx,0x3
  40bccf:	mov    edx,0x10
  40bcd4:	call   409750 <__swc_fn_23cea7fa_000111_6814119b>
  40bcd9:	test   rax,rax
  40bcdc:	jne    40bced <__swc_fn_23cea7fa_000174_5eac0ab4+0x3d>
  40bcde:	mov    QWORD PTR [rsp+0x18],rax
  40bce3:	call   411550 <__swc_fn_23cea7fa_000122_be2e2f68>
  40bce8:	mov    rax,QWORD PTR [rsp+0x18]
  40bced:	mov    rcx,rax
  40bcf0:	xchg   QWORD PTR [rsi],rcx
  40bcf3:	add    rsp,0x30
  40bcf7:	pop    rsi
  40bcf8:	ret
  40bcf9:	add    BYTE PTR [rax],al
  40bcfb:	add    BYTE PTR [rax],al
  40bcfd:	add    BYTE PTR [rax],al
	...

000000000040bd00 <__swc_fn_23cea7fa_000177_cf4ffedd>:
  40bd00:	push   rsi
  40bd01:	push   rdi
  40bd02:	sub    rsp,0x8
  40bd06:	mov    rsi,rdx
  40bd09:	mov    rdi,rcx
  40bd0c:	mov    rax,QWORD PTR [rsi+0x8]
  40bd10:	test   rax,rax
  40bd13:	je     40bd1d <__swc_fn_23cea7fa_000177_cf4ffedd+0x1d>
  40bd15:	mov    rcx,QWORD PTR [rsi]
  40bd18:	mov    QWORD PTR [rax],rcx
  40bd1b:	jmp    40bd24 <__swc_fn_23cea7fa_000177_cf4ffedd+0x24>
  40bd1d:	mov    rax,QWORD PTR [rsi]
  40bd20:	mov    QWORD PTR [rdi+0x8],rax
  40bd24:	mov    rax,QWORD PTR [rsi]
  40bd27:	test   rax,rax
  40bd2a:	je     40bd34 <__swc_fn_23cea7fa_000177_cf4ffedd+0x34>
  40bd2c:	mov    rcx,QWORD PTR [rsi+0x8]
  40bd30:	mov    QWORD PTR [rax+0x8],rcx
  40bd34:	mov    rcx,rdi
  40bd37:	mov    rdx,QWORD PTR [rsi+0x10]
  40bd3b:	mov    r8,QWORD PTR [rsi+0x18]
  40bd3f:	mov    r9,0xffffffffffffffff
  40bd46:	call   412100 <__swc_fn_23cea7fa_000176_4de704de>
  40bd4b:	mov    QWORD PTR [rsi+0x18],0x0
  40bd53:	mov    rax,QWORD PTR [rdi+0x8]
  40bd57:	test   rax,rax
  40bd5a:	jne    40bd6c <__swc_fn_23cea7fa_000177_cf4ffedd+0x6c>
  40bd5c:	call   40bcb0 <__swc_fn_23cea7fa_000174_5eac0ab4>
  40bd61:	xor    ecx,ecx
  40bd63:	mov    QWORD PTR [rax+0x8],rcx
  40bd67:	xor    ecx,ecx
  40bd69:	mov    QWORD PTR [rax],rcx
  40bd6c:	add    rsp,0x8
  40bd70:	pop    rdi
  40bd71:	pop    rsi
  40bd72:	ret
	...

000000000040bd80 <__swc_fn_23cea7fa_000001_5d3d19bd>:
  40bd80:	push   rbx
  40bd81:	sub    rsp,0x70
  40bd85:	test   rcx,rcx
  40bd88:	jne    40bd90 <__swc_fn_23cea7fa_000001_5d3d19bd+0x10>
  40bd8a:	add    rsp,0x70
  40bd8e:	pop    rbx
  40bd8f:	ret
  40bd90:	vxorps xmm0,xmm0,xmm0
  40bd94:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40bd9a:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40bda0:	vzeroupper
  40bda3:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40bda9:	lea    rax,[rcx-0x10]
  40bdad:	mov    QWORD PTR [rsp+0x48],rax
  40bdb2:	mov    rax,QWORD PTR [rcx-0x10]
  40bdb6:	mov    QWORD PTR [rsp+0x50],rax
  40bdbb:	mov    rcx,QWORD PTR [rip+0x1827e]        # 424040 <__swc_bss_base_23cea7fa>
  40bdc2:	test   rcx,rcx
  40bdc5:	jne    40bdd7 <__swc_fn_23cea7fa_000001_5d3d19bd+0x57>
  40bdc7:	call   40ed20 <__swc_fn_23cea7fa_000169_994c8876>
  40bdcc:	lea    rcx,[rax+0x1]
  40bdd0:	mov    QWORD PTR [rip+0x18269],rcx        # 424040 <__swc_bss_base_23cea7fa>
  40bdd7:	dec    rcx
  40bdda:	call   40bbe0 <__swc_fn_23cea7fa_000171_360af05d>
  40bddf:	mov    rcx,QWORD PTR [rax]
  40bde2:	lea    rdx,[rsp+0x8]
  40bde7:	mov    rbx,QWORD PTR [rax+0x8]
  40bdeb:	mov    rbx,QWORD PTR [rbx+0x18]
  40bdef:	call   rbx
  40bdf1:	add    rsp,0x70
  40bdf5:	pop    rbx
  40bdf6:	ret
	...

000000000040be00 <__swc_fn_23cea7fa_000004_9ee35b18>:
  40be00:	vxorps xmm0,xmm0,xmm0
  40be04:	vmovups XMMWORD PTR [rcx],xmm0
  40be08:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40be0d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40be12:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40be17:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40be1c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40be21:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40be26:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40be2b:	ret
  40be2c:	add    BYTE PTR [rax],al
	...

000000000040be30 <__swc_fn_23cea7fa_000007_f7acedb0>:
  40be30:	push   rsi
  40be31:	mov    rsi,rdx
  40be34:	test   rdx,rdx
  40be37:	jne    40be40 <__swc_fn_23cea7fa_000007_f7acedb0+0x10>
  40be39:	mov    eax,0x1
  40be3e:	pop    rsi
  40be3f:	ret
  40be40:	mov    rdx,rsi
  40be43:	call   40ddc0 <__swc_fn_23cea7fa_000115_36905703>
  40be48:	test   al,al
  40be4a:	jne    40be50 <__swc_fn_23cea7fa_000007_f7acedb0+0x20>
  40be4c:	xor    eax,eax
  40be4e:	pop    rsi
  40be4f:	ret
  40be50:	lea    rcx,[rip+0x181f9]        # 424050 <__swc_bss_base_23cea7fa+0x10>
  40be57:	mov    rdx,QWORD PTR [rip+0x181f2]        # 424050 <__swc_bss_base_23cea7fa+0x10>
  40be5e:	xchg   ax,ax
  40be60:	lea    r8,[rdx+rsi*1]
  40be64:	mov    rax,rdx
  40be67:	lock cmpxchg QWORD PTR [rcx],r8
  40be6c:	cmp    rax,rdx
  40be6f:	je     40be76 <__swc_fn_23cea7fa_000007_f7acedb0+0x46>
  40be71:	mov    rdx,rax
  40be74:	jmp    40be60 <__swc_fn_23cea7fa_000007_f7acedb0+0x30>
  40be76:	lea    rcx,[rip+0x181db]        # 424058 <__swc_bss_base_23cea7fa+0x18>
  40be7d:	mov    rdx,QWORD PTR [rip+0x181d4]        # 424058 <__swc_bss_base_23cea7fa+0x18>
  40be84:	cs nop WORD PTR [rax+rax*1+0x0]
  40be8e:	xchg   ax,ax
  40be90:	lea    r8,[rdx+0x1]
  40be94:	mov    rax,rdx
  40be97:	lock cmpxchg QWORD PTR [rcx],r8
  40be9c:	cmp    rax,rdx
  40be9f:	je     40bea6 <__swc_fn_23cea7fa_000007_f7acedb0+0x76>
  40bea1:	mov    rdx,rax
  40bea4:	jmp    40be90 <__swc_fn_23cea7fa_000007_f7acedb0+0x60>
  40bea6:	mov    eax,0x1
  40beab:	pop    rsi
  40beac:	ret
  40bead:	add    BYTE PTR [rax],al
	...

000000000040beb0 <__swc_fn_23cea7fa_000010_24a20786>:
  40beb0:	push   rbx
  40beb1:	push   rsi
  40beb2:	push   rdi
  40beb3:	push   r12
  40beb5:	sub    rsp,0x18
  40beb9:	mov    rbx,rcx
  40bebc:	mov    rsi,rcx
  40bebf:	and    rsi,0xffffffffffc00000
  40bec6:	movzx  eax,BYTE PTR [rbx+0x3a]
  40beca:	mov    ecx,DWORD PTR [rsi+0x28]
  40becd:	shrx   eax,eax,ecx
  40bed2:	lea    rdi,[rsp+0x8]
  40bed7:	mov    DWORD PTR [rsp+0x8],eax
  40bedb:	mov    rcx,rsi
  40bede:	mov    rax,rdi
  40bee1:	mov    edx,DWORD PTR [rax]
  40bee3:	call   407c80 <__swc_fn_23cea7fa_000015_9dea5065>
  40bee8:	mov    r12,rax
  40beeb:	mov    rcx,rsi
  40beee:	mov    edx,DWORD PTR [rdi]
  40bef0:	call   40bfe0 <__swc_fn_23cea7fa_000016_9afb7cfb>
  40bef5:	mov    rcx,r12
  40bef8:	mov    edx,DWORD PTR [rbx+0x3c]
  40befb:	add    rcx,rdx
  40befe:	cmp    rcx,rax
  40bf01:	jb     40bf0f <__swc_fn_23cea7fa_000010_24a20786+0x5f>
  40bf03:	xor    eax,eax
  40bf05:	add    rsp,0x18
  40bf09:	pop    r12
  40bf0b:	pop    rdi
  40bf0c:	pop    rsi
  40bf0d:	pop    rbx
  40bf0e:	ret
  40bf0f:	mov    rdx,QWORD PTR [rbx+0x20]
  40bf13:	mov    r8d,DWORD PTR [rbx+0x2c]
  40bf17:	add    rdx,r8
  40bf1a:	lea    rsi,[rdx+0xffff]
  40bf21:	and    rsi,0xffffffffffff0000
  40bf28:	cmp    rax,rsi
  40bf2b:	cmovbe rsi,rax
  40bf2f:	mov    rax,rsi
  40bf32:	sub    rax,rcx
  40bf35:	mov    rdx,rax
  40bf38:	call   40be30 <__swc_fn_23cea7fa_000007_f7acedb0>
  40bf3d:	test   al,al
  40bf3f:	jne    40bf4d <__swc_fn_23cea7fa_000010_24a20786+0x9d>
  40bf41:	xor    eax,eax
  40bf43:	add    rsp,0x18
  40bf47:	pop    r12
  40bf49:	pop    rdi
  40bf4a:	pop    rsi
  40bf4b:	pop    rbx
  40bf4c:	ret
  40bf4d:	sub    rsi,r12
  40bf50:	mov    DWORD PTR [rbx+0x3c],esi
  40bf53:	mov    ecx,DWORD PTR [rbx+0x2c]
  40bf56:	mov    rax,rsi
  40bf59:	xor    edx,edx
  40bf5b:	div    rcx
  40bf5e:	imul   rax,rcx
  40bf62:	add    r12,rax
  40bf65:	mov    QWORD PTR [rbx+0x18],r12
  40bf69:	mov    eax,0x1
  40bf6e:	add    rsp,0x18
  40bf72:	pop    r12
  40bf74:	pop    rdi
  40bf75:	pop    rsi
  40bf76:	pop    rbx
  40bf77:	ret
	...

000000000040bf80 <__swc_fn_23cea7fa_000013_e4b0ddfc>:
  40bf80:	sub    rsp,0x8
  40bf84:	mov    rdx,rcx
  40bf87:	lea    r9,[rcx+0x60]
  40bf8b:	mov    rax,QWORD PTR [r9]
  40bf8e:	test   rax,rax
  40bf91:	jne    40bf98 <__swc_fn_23cea7fa_000013_e4b0ddfc+0x18>
  40bf93:	add    rsp,0x8
  40bf97:	ret
  40bf98:	mov    rcx,rdx
  40bf9b:	call   40f0b0 <__swc_fn_23cea7fa_000011_c3647f66>
  40bfa0:	xor    eax,eax
  40bfa2:	xchg   QWORD PTR [r9],rax
  40bfa5:	mov    r8,rax
  40bfa8:	mov    rcx,rdx
  40bfab:	call   407c70 <__swc_fn_23cea7fa_000012_861b8b62>
  40bfb0:	xor    eax,eax
  40bfb2:	test   r8,r8
  40bfb5:	je     40bfd6 <__swc_fn_23cea7fa_000013_e4b0ddfc+0x56>
  40bfb7:	nop    WORD PTR [rax+rax*1+0x0]
  40bfc0:	mov    rcx,QWORD PTR [r8]
  40bfc3:	mov    r9,QWORD PTR [rdx]
  40bfc6:	mov    QWORD PTR [r8],r9
  40bfc9:	mov    QWORD PTR [rdx],r8
  40bfcc:	mov    r8,rcx
  40bfcf:	inc    eax
  40bfd1:	test   rcx,rcx
  40bfd4:	jne    40bfc0 <__swc_fn_23cea7fa_000013_e4b0ddfc+0x40>
  40bfd6:	sub    DWORD PTR [rdx+0x28],eax
  40bfd9:	add    rsp,0x8
  40bfdd:	ret
	...

000000000040bfe0 <__swc_fn_23cea7fa_000016_9afb7cfb>:
  40bfe0:	lea    eax,[rdx+0x1]
  40bfe3:	mov    edx,DWORD PTR [rcx+0x28]
  40bfe6:	shlx   eax,eax,edx
  40bfeb:	shl    rax,0x10
  40bfef:	add    rax,rcx
  40bff2:	ret
	...

000000000040c000 <__swc_fn_23cea7fa_000019_adca76cf>:
  40c000:	push   rbx
  40c001:	push   rsi
  40c002:	push   rdi
  40c003:	push   r12
  40c005:	push   r13
  40c007:	push   r14
  40c009:	push   r15
  40c00b:	sub    rsp,0x30
  40c00f:	mov    rbx,rcx
  40c012:	lea    rsi,[rcx+0x48]
  40c016:	mov    QWORD PTR [rsp+0x18],rsi
  40c01b:	mov    rax,QWORD PTR [rsi]
  40c01e:	mov    rdi,rax
  40c021:	lea    r12,[rsp+0x8]
  40c026:	lea    r13,[rcx+0x40]
  40c02a:	nop    WORD PTR [rax+rax*1+0x0]
  40c030:	test   rdi,rdi
  40c033:	je     40c173 <__swc_fn_23cea7fa_000019_adca76cf+0x173>
  40c039:	xor    eax,eax
  40c03b:	tzcnt  rax,rdi
  40c040:	mov    DWORD PTR [rsp+0x8],eax
  40c044:	mov    r14d,0x1
  40c04a:	mov    ecx,eax
  40c04c:	shl    r14,cl
  40c04f:	andn   rdi,r14,rdi
  40c054:	mov    rcx,QWORD PTR [r13+0x0]
  40c058:	test   rcx,r14
  40c05b:	jne    40c030 <__swc_fn_23cea7fa_000019_adca76cf+0x30>
  40c05d:	mov    rdx,rcx
  40c060:	or     rdx,r14
  40c063:	mov    rax,rcx
  40c066:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  40c06c:	cmp    rax,rcx
  40c06f:	je     40c079 <__swc_fn_23cea7fa_000019_adca76cf+0x79>
  40c071:	mov    rax,QWORD PTR [rsi]
  40c074:	mov    rdi,rax
  40c077:	jmp    40c030 <__swc_fn_23cea7fa_000019_adca76cf+0x30>
  40c079:	mov    rcx,rbx
  40c07c:	mov    rdx,r14
  40c07f:	call   407de0 <__swc_fn_23cea7fa_000021_fd2b165c>
  40c084:	test   al,al
  40c086:	je     40c15e <__swc_fn_23cea7fa_000019_adca76cf+0x15e>
  40c08c:	mov    eax,DWORD PTR [r12]
  40c090:	shl    rax,0x4
  40c094:	lea    r15,[rbx+rax*8+0x80]
  40c09c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  40c0a4:	lea    rcx,[rip+0x17fb5]        # 424060 <__swc_bss_base_23cea7fa+0x20>
  40c0ab:	mov    rdx,QWORD PTR [rip+0x17fae]        # 424060 <__swc_bss_base_23cea7fa+0x20>
  40c0b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0bc:	nop    DWORD PTR [rax+0x0]
  40c0c0:	mov    r8,rdx
  40c0c3:	sub    r8,rsi
  40c0c6:	mov    rax,rdx
  40c0c9:	lock cmpxchg QWORD PTR [rcx],r8
  40c0ce:	cmp    rax,rdx
  40c0d1:	je     40c0d8 <__swc_fn_23cea7fa_000019_adca76cf+0xd8>
  40c0d3:	mov    rdx,rax
  40c0d6:	jmp    40c0c0 <__swc_fn_23cea7fa_000019_adca76cf+0xc0>
  40c0d8:	mov    rcx,rbx
  40c0db:	mov    rax,r12
  40c0de:	mov    edx,DWORD PTR [rax]
  40c0e0:	call   407c80 <__swc_fn_23cea7fa_000015_9dea5065>
  40c0e5:	test   rsi,rsi
  40c0e8:	je     40c156 <__swc_fn_23cea7fa_000019_adca76cf+0x156>
  40c0ee:	mov    rcx,rax
  40c0f1:	mov    rdx,rsi
  40c0f4:	call   411320 <__swc_fn_23cea7fa_000116_e9fc0224>
  40c0f9:	lea    rcx,[rip+0x17f50]        # 424050 <__swc_bss_base_23cea7fa+0x10>
  40c100:	mov    rdx,QWORD PTR [rip+0x17f49]        # 424050 <__swc_bss_base_23cea7fa+0x10>
  40c107:	nop    WORD PTR [rax+rax*1+0x0]
  40c110:	mov    r8,rdx
  40c113:	sub    r8,rsi
  40c116:	mov    rax,rdx
  40c119:	lock cmpxchg QWORD PTR [rcx],r8
  40c11e:	cmp    rax,rdx
  40c121:	je     40c128 <__swc_fn_23cea7fa_000019_adca76cf+0x128>
  40c123:	mov    rdx,rax
  40c126:	jmp    40c110 <__swc_fn_23cea7fa_000019_adca76cf+0x110>
  40c128:	lea    rcx,[rip+0x17f39]        # 424068 <__swc_bss_base_23cea7fa+0x28>
  40c12f:	mov    rdx,QWORD PTR [rip+0x17f32]        # 424068 <__swc_bss_base_23cea7fa+0x28>
  40c136:	cs nop WORD PTR [rax+rax*1+0x0]
  40c140:	lea    r8,[rdx+0x1]
  40c144:	mov    rax,rdx
  40c147:	lock cmpxchg QWORD PTR [rcx],r8
  40c14c:	cmp    rax,rdx
  40c14f:	je     40c156 <__swc_fn_23cea7fa_000019_adca76cf+0x156>
  40c151:	mov    rdx,rax
  40c154:	jmp    40c140 <__swc_fn_23cea7fa_000019_adca76cf+0x140>
  40c156:	mov    DWORD PTR [r15+0x3c],0x0
  40c15e:	mov    rcx,rbx
  40c161:	mov    rdx,r14
  40c164:	call   40c190 <__swc_fn_23cea7fa_000022_c8f5f27c>
  40c169:	mov    rsi,QWORD PTR [rsp+0x18]
  40c16e:	jmp    40c030 <__swc_fn_23cea7fa_000019_adca76cf+0x30>
  40c173:	add    rsp,0x30
  40c177:	pop    r15
  40c179:	pop    r14
  40c17b:	pop    r13
  40c17d:	pop    r12
  40c17f:	pop    rdi
  40c180:	pop    rsi
  40c181:	pop    rbx
  40c182:	ret
	...

000000000040c190 <__swc_fn_23cea7fa_000022_c8f5f27c>:
  40c190:	mov    r8,QWORD PTR [rcx+0x40]
  40c194:	cs nop WORD PTR [rax+rax*1+0x0]
  40c19e:	xchg   ax,ax
  40c1a0:	mov    rax,rdx
  40c1a3:	not    rax
  40c1a6:	mov    r9,r8
  40c1a9:	and    r9,rax
  40c1ac:	mov    rax,r8
  40c1af:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  40c1b5:	cmp    rax,r8
  40c1b8:	jne    40c1bb <__swc_fn_23cea7fa_000022_c8f5f27c+0x2b>
  40c1ba:	ret
  40c1bb:	mov    r8,rax
  40c1be:	jmp    40c1a0 <__swc_fn_23cea7fa_000022_c8f5f27c+0x10>

000000000040c1c0 <__swc_fn_23cea7fa_000025_aa910677>:
  40c1c0:	push   rsi
  40c1c1:	push   rdi
  40c1c2:	sub    rsp,0x8
  40c1c6:	mov    rsi,rcx
  40c1c9:	call   40c000 <__swc_fn_23cea7fa_000019_adca76cf>
  40c1ce:	lea    rdi,[rip+0x18023]        # 4241f8 <__swc_bss_base_23cea7fa+0x1b8>
  40c1d5:	mov    rcx,rdi
  40c1d8:	call   40e420 <__swc_fn_23cea7fa_000139_86bb0f90>
  40c1dd:	mov    QWORD PTR [rsi+0x8],0x0
  40c1e5:	mov    QWORD PTR [rsi+0x18],0x0
  40c1ed:	mov    rax,QWORD PTR [rip+0x1800c]        # 424200 <__swc_bss_base_23cea7fa+0x1c0>
  40c1f4:	mov    QWORD PTR [rsi+0x10],rax
  40c1f8:	mov    QWORD PTR [rip+0x18001],rsi        # 424200 <__swc_bss_base_23cea7fa+0x1c0>
  40c1ff:	mov    rcx,rdi
  40c202:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40c207:	add    rsp,0x8
  40c20b:	pop    rdi
  40c20c:	pop    rsi
  40c20d:	ret
	...

000000000040c210 <__swc_fn_23cea7fa_000028_9798fb47>:
  40c210:	vxorps xmm0,xmm0,xmm0
  40c214:	vmovups XMMWORD PTR [rcx],xmm0
  40c218:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40c21d:	mov    QWORD PTR [rcx+0x20],0x0
  40c225:	ret
	...

000000000040c230 <__swc_fn_23cea7fa_000031_9798fb47>:
  40c230:	vxorps xmm0,xmm0,xmm0
  40c234:	vmovups XMMWORD PTR [rcx],xmm0
  40c238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40c23d:	mov    QWORD PTR [rcx+0x20],0x0
  40c245:	ret
	...

000000000040c250 <__swc_fn_23cea7fa_000034_9128bcf9>:
  40c250:	push   r12
  40c252:	mov    r12,rdi
  40c255:	test   rdi,rdi
  40c258:	jne    40c25d <__swc_fn_23cea7fa_000034_9128bcf9+0xd>
  40c25a:	pop    r12
  40c25c:	ret
  40c25d:	lea    rax,[rip+0x15da4]        # 422008 <__swc_data_base_23cea7fa+0x8>
  40c264:	mov    rax,QWORD PTR [rax]
  40c267:	cmp    rax,0xffffffffffffffff
  40c26b:	je     40c27a <__swc_fn_23cea7fa_000034_9128bcf9+0x2a>
  40c26d:	mov    eax,eax
  40c26f:	mov    edi,eax
  40c271:	xor    eax,eax
  40c273:	call   407000 <pthread_getspecific@plt>
  40c278:	jmp    40c27c <__swc_fn_23cea7fa_000034_9128bcf9+0x2c>
  40c27a:	xor    eax,eax
  40c27c:	cmp    rax,r12
  40c27f:	jne    40c288 <__swc_fn_23cea7fa_000034_9128bcf9+0x38>
  40c281:	xor    ecx,ecx
  40c283:	call   407fa0 <__swc_fn_23cea7fa_000036_92d9bbff>
  40c288:	mov    rdx,QWORD PTR [r12]
  40c28c:	test   rdx,rdx
  40c28f:	je     40c2a8 <__swc_fn_23cea7fa_000034_9128bcf9+0x58>
  40c291:	mov    rcx,rdx
  40c294:	call   40c2d0 <__swc_fn_23cea7fa_000040_eb6108f2>
  40c299:	test   al,al
  40c29b:	je     40c2a8 <__swc_fn_23cea7fa_000034_9128bcf9+0x58>
  40c29d:	mov    rcx,rdx
  40c2a0:	mov    rdx,r12
  40c2a3:	call   40c3c0 <__swc_fn_23cea7fa_000046_b30433d0>
  40c2a8:	pop    r12
  40c2aa:	ret
  40c2ab:	add    BYTE PTR [rax],al
  40c2ad:	add    BYTE PTR [rax],al
	...

000000000040c2b0 <__swc_fn_23cea7fa_000037_28d0e998>:
  40c2b0:	push   rsi
  40c2b1:	mov    rsi,rcx
  40c2b4:	call   40f560 <__swc_fn_23cea7fa_000035_cd1a4e8c>
  40c2b9:	mov    rcx,rax
  40c2bc:	mov    rdx,rsi
  40c2bf:	call   40e2a0 <__swc_fn_23cea7fa_000133_ae5891af>
  40c2c4:	mov    rcx,rsi
  40c2c7:	call   407fa0 <__swc_fn_23cea7fa_000036_92d9bbff>
  40c2cc:	pop    rsi
  40c2cd:	ret
	...

000000000040c2d0 <__swc_fn_23cea7fa_000040_eb6108f2>:
  40c2d0:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40c2da:	sete   al
  40c2dd:	ret
	...

000000000040c2e0 <__swc_fn_23cea7fa_000043_d3c2ab54>:
  40c2e0:	push   rsi
  40c2e1:	test   rdx,rdx
  40c2e4:	jne    40c2e8 <__swc_fn_23cea7fa_000043_d3c2ab54+0x8>
  40c2e6:	pop    rsi
  40c2e7:	ret
  40c2e8:	mov    rax,r8
  40c2eb:	mov    ecx,0x1000
  40c2f0:	test   ecx,ecx
  40c2f2:	mov    r10d,0x8
  40c2f8:	cmove  ecx,r10d
  40c2fc:	dec    rcx
  40c2ff:	mov    r10,0xffffffffffffffff
  40c306:	sub    r10,rcx
  40c309:	cmp    r8,r10
  40c30c:	jbe    40c312 <__swc_fn_23cea7fa_000043_d3c2ab54+0x32>
  40c30e:	xor    eax,eax
  40c310:	jmp    40c31a <__swc_fn_23cea7fa_000043_d3c2ab54+0x3a>
  40c312:	add    rax,rcx
  40c315:	andn   rax,rcx,rax
  40c31a:	mov    ecx,0x1000
  40c31f:	test   ecx,ecx
  40c321:	mov    r8d,0x8
  40c327:	cmove  ecx,r8d
  40c32b:	dec    rcx
  40c32e:	mov    r8,0xffffffffffffffff
  40c335:	sub    r8,rcx
  40c338:	cmp    r9,r8
  40c33b:	jbe    40c341 <__swc_fn_23cea7fa_000043_d3c2ab54+0x61>
  40c33d:	xor    esi,esi
  40c33f:	jmp    40c34c <__swc_fn_23cea7fa_000043_d3c2ab54+0x6c>
  40c341:	add    r9,rcx
  40c344:	andn   r9,rcx,r9
  40c349:	mov    rsi,r9
  40c34c:	mov    rcx,rdx
  40c34f:	mov    rdx,rax
  40c352:	mov    r8,rsi
  40c355:	call   40dea0 <__swc_fn_23cea7fa_000118_5208f471>
  40c35a:	lea    rcx,[rip+0x17cef]        # 424050 <__swc_bss_base_23cea7fa+0x10>
  40c361:	mov    rdx,QWORD PTR [rip+0x17ce8]        # 424050 <__swc_bss_base_23cea7fa+0x10>
  40c368:	nop    DWORD PTR [rax+rax*1+0x0]
  40c370:	mov    r8,rdx
  40c373:	sub    r8,rsi
  40c376:	mov    rax,rdx
  40c379:	lock cmpxchg QWORD PTR [rcx],r8
  40c37e:	cmp    rax,rdx
  40c381:	je     40c388 <__swc_fn_23cea7fa_000043_d3c2ab54+0xa8>
  40c383:	mov    rdx,rax
  40c386:	jmp    40c370 <__swc_fn_23cea7fa_000043_d3c2ab54+0x90>
  40c388:	lea    rcx,[rip+0x17cd9]        # 424068 <__swc_bss_base_23cea7fa+0x28>
  40c38f:	mov    rdx,QWORD PTR [rip+0x17cd2]        # 424068 <__swc_bss_base_23cea7fa+0x28>
  40c396:	cs nop WORD PTR [rax+rax*1+0x0]
  40c3a0:	lea    r8,[rdx+0x1]
  40c3a4:	mov    rax,rdx
  40c3a7:	lock cmpxchg QWORD PTR [rcx],r8
  40c3ac:	cmp    rax,rdx
  40c3af:	je     40c3b6 <__swc_fn_23cea7fa_000043_d3c2ab54+0xd6>
  40c3b1:	mov    rdx,rax
  40c3b4:	jmp    40c3a0 <__swc_fn_23cea7fa_000043_d3c2ab54+0xc0>
  40c3b6:	pop    rsi
  40c3b7:	ret
	...

000000000040c3c0 <__swc_fn_23cea7fa_000046_b30433d0>:
  40c3c0:	push   rbx
  40c3c1:	push   rsi
  40c3c2:	push   rdi
  40c3c3:	push   r12
  40c3c5:	push   r13
  40c3c7:	push   r14
  40c3c9:	push   r15
  40c3cb:	sub    rsp,0x30
  40c3cf:	mov    rbx,rdx
  40c3d2:	mov    QWORD PTR [rsp+0x18],rdx
  40c3d7:	mov    rsi,rcx
  40c3da:	mov    eax,0x1
  40c3df:	xchg   DWORD PTR [rbx+0x20],eax
  40c3e2:	test   eax,eax
  40c3e4:	je     40c3f6 <__swc_fn_23cea7fa_000046_b30433d0+0x36>
  40c3e6:	add    rsp,0x30
  40c3ea:	pop    r15
  40c3ec:	pop    r14
  40c3ee:	pop    r13
  40c3f0:	pop    r12
  40c3f2:	pop    rdi
  40c3f3:	pop    rsi
  40c3f4:	pop    rbx
  40c3f5:	ret
  40c3f6:	mov    rcx,rsi
  40c3f9:	mov    rdx,rbx
  40c3fc:	mov    r8,0xffffffffffffffff
  40c403:	call   408570 <__swc_fn_23cea7fa_000063_dea90857>
  40c408:	lea    rdi,[rsi+0x10]
  40c40c:	mov    QWORD PTR [rsp+0x20],rdi
  40c411:	mov    rcx,rdi
  40c414:	call   40e420 <__swc_fn_23cea7fa_000139_86bb0f90>
  40c419:	xor    r12d,r12d
  40c41c:	cs nop WORD PTR [rax+rax*1+0x0]
  40c426:	cs nop WORD PTR [rax+rax*1+0x0]
  40c430:	mov    eax,r12d
  40c433:	lea    r13,[rax+rax*4]
  40c437:	lea    r13,[rbx+r13*8+0x28]
  40c43c:	mov    rax,QWORD PTR [r13+0x8]
  40c440:	mov    QWORD PTR [rsp+0x8],rax
  40c445:	mov    rax,QWORD PTR [r13+0x18]
  40c449:	mov    QWORD PTR [rsp+0x10],rax
  40c44e:	mov    r14d,0x2
  40c454:	xor    r15d,r15d
  40c457:	test   r14,r14
  40c45a:	je     40c4d7 <__swc_fn_23cea7fa_000046_b30433d0+0x117>
  40c460:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  40c465:	mov    rdi,rax
  40c468:	test   rdi,rdi
  40c46b:	je     40c4c9 <__swc_fn_23cea7fa_000046_b30433d0+0x109>
  40c46d:	nop    DWORD PTR [rax]
  40c470:	mov    rbx,QWORD PTR [rdi+0x48]
  40c474:	mov    DWORD PTR [rdi+0x6c],0x0
  40c47b:	mov    rcx,rdi
  40c47e:	call   40bf80 <__swc_fn_23cea7fa_000013_e4b0ddfc>
  40c483:	cmp    DWORD PTR [rdi+0x28],0x0
  40c487:	jne    40c4a0 <__swc_fn_23cea7fa_000046_b30433d0+0xe0>
  40c489:	mov    rax,rdi
  40c48c:	and    rax,0xffffffffffc00000
  40c493:	mov    rcx,rax
  40c496:	mov    rdx,rdi
  40c499:	call   407ca0 <__swc_fn_23cea7fa_000018_283e2b5e>
  40c49e:	jmp    40c4c1 <__swc_fn_23cea7fa_000046_b30433d0+0x101>
  40c4a0:	mov    QWORD PTR [rdi+0x40],0x0
  40c4a8:	rex mov BYTE PTR [rdi+0x3b],0x2
  40c4ad:	mov    QWORD PTR [rdi+0x50],0x0
  40c4b5:	mov    rax,QWORD PTR [rsi+0x28]
  40c4b9:	mov    QWORD PTR [rdi+0x48],rax
  40c4bd:	mov    QWORD PTR [rsi+0x28],rdi
  40c4c1:	mov    rdi,rbx
  40c4c4:	test   rbx,rbx
  40c4c7:	jne    40c470 <__swc_fn_23cea7fa_000046_b30433d0+0xb0>
  40c4c9:	add    r15,0x1
  40c4cd:	sub    r14,0x1
  40c4d1:	jne    40c460 <__swc_fn_23cea7fa_000046_b30433d0+0xa0>
  40c4d7:	vxorps xmm0,xmm0,xmm0
  40c4db:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  40c4e1:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40c4e7:	mov    QWORD PTR [r13+0x20],0x0
  40c4ef:	add    r12,0x1
  40c4f3:	cmp    r12,0x2d
  40c4f7:	mov    rbx,QWORD PTR [rsp+0x18]
  40c4fc:	jb     40c430 <__swc_fn_23cea7fa_000046_b30433d0+0x70>
  40c502:	mov    rcx,rsi
  40c505:	mov    rbx,QWORD PTR [rsp+0x18]
  40c50a:	mov    rdx,rbx
  40c50d:	mov    rdi,QWORD PTR [rsp+0x20]
  40c512:	call   40f720 <__swc_fn_23cea7fa_000047_6e7a8d58>
  40c517:	mov    rcx,rdi
  40c51a:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40c51f:	mov    rcx,rsi
  40c522:	mov    rdx,rbx
  40c525:	mov    r8d,0x9b8
  40c52b:	mov    r9d,0x9b8
  40c531:	call   40c2e0 <__swc_fn_23cea7fa_000043_d3c2ab54>
  40c536:	add    rsp,0x30
  40c53a:	pop    r15
  40c53c:	pop    r14
  40c53e:	pop    r13
  40c540:	pop    r12
  40c542:	pop    rdi
  40c543:	pop    rsi
  40c544:	pop    rbx
  40c545:	ret
	...

000000000040c560 <__swc_fn_23cea7fa_000049_ad48ec88>:
  40c560:	push   rbx
  40c561:	push   rsi
  40c562:	push   rdi
  40c563:	push   r12
  40c565:	push   r13
  40c567:	push   r14
  40c569:	push   r15
  40c56b:	sub    rsp,0x30
  40c56f:	mov    ebx,r8d
  40c572:	mov    rsi,rcx
  40c575:	mov    rdi,rdx
  40c578:	test   r8d,r8d
  40c57b:	jne    40c584 <__swc_fn_23cea7fa_000049_ad48ec88+0x24>
  40c57d:	mov    eax,0x8
  40c582:	jmp    40c5ab <__swc_fn_23cea7fa_000049_ad48ec88+0x4b>
  40c584:	cmp    ebx,0x8
  40c587:	ja     40c592 <__swc_fn_23cea7fa_000049_ad48ec88+0x32>
  40c589:	mov    rax,rbx
  40c58c:	shl    rax,0x4
  40c590:	jmp    40c5ab <__swc_fn_23cea7fa_000049_ad48ec88+0x4b>
  40c592:	lea    eax,[rbx-0x9]
  40c595:	mov    ecx,eax
  40c597:	shr    ecx,0x2
  40c59a:	and    eax,0x3
  40c59d:	lea    ecx,[rcx+0x7]
  40c5a0:	lea    ecx,[rcx-0x2]
  40c5a3:	lea    eax,[rax+0x5]
  40c5a6:	shlx   rax,rax,rcx
  40c5ab:	lea    r12,[rsp+0x8]
  40c5b0:	mov    DWORD PTR [rsp+0x8],eax
  40c5b4:	lea    r13,[rsp+0xc]
  40c5b9:	mov    QWORD PTR [rsp+0x18],r13
  40c5be:	xor    eax,eax
  40c5c0:	cmp    ebx,0x21
  40c5c3:	setae  al
  40c5c6:	lea    eax,[rax+rax*2]
  40c5c9:	mov    DWORD PTR [rsp+0xc],eax
  40c5cd:	lea    r14,[rsi+0x10]
  40c5d1:	mov    rcx,r14
  40c5d4:	call   40e420 <__swc_fn_23cea7fa_000139_86bb0f90>
  40c5d9:	xor    eax,eax
  40c5db:	mov    rcx,QWORD PTR [rsi+0x28]
  40c5df:	mov    r15,rcx
  40c5e2:	test   r15,r15
  40c5e5:	je     40c696 <__swc_fn_23cea7fa_000049_ad48ec88+0x136>
  40c5eb:	cs nop WORD PTR [rax+rax*1+0x0]
  40c5f5:	cs nop WORD PTR [rax+rax*1+0x0]
  40c5ff:	nop
  40c600:	mov    rcx,QWORD PTR [r15+0x48]
  40c604:	movzx  edx,BYTE PTR [r15+0x39]
  40c609:	cmp    edx,ebx
  40c60b:	jne    40c687 <__swc_fn_23cea7fa_000049_ad48ec88+0x127>
  40c60d:	test   rax,rax
  40c610:	jne    40c618 <__swc_fn_23cea7fa_000049_ad48ec88+0xb8>
  40c612:	mov    QWORD PTR [rsi+0x28],rcx
  40c616:	jmp    40c61c <__swc_fn_23cea7fa_000049_ad48ec88+0xbc>
  40c618:	mov    QWORD PTR [rax+0x48],rcx
  40c61c:	vxorps xmm0,xmm0,xmm0
  40c620:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  40c626:	mov    BYTE PTR [r15+0x3b],0x1
  40c62b:	mov    QWORD PTR [r15+0x40],rdi
  40c62f:	mov    rcx,r15
  40c632:	call   40bf80 <__swc_fn_23cea7fa_000013_e4b0ddfc>
  40c637:	movzx  eax,BYTE PTR [r15+0x39]
  40c63c:	lea    rax,[rax+rax*4]
  40c640:	lea    rax,[rdi+rax*8+0x28]
  40c645:	mov    rcx,QWORD PTR [rax+0x10]
  40c649:	mov    QWORD PTR [r15+0x50],rcx
  40c64d:	mov    QWORD PTR [r15+0x48],0x0
  40c655:	mov    rcx,QWORD PTR [rax+0x10]
  40c659:	test   rcx,rcx
  40c65c:	je     40c664 <__swc_fn_23cea7fa_000049_ad48ec88+0x104>
  40c65e:	mov    QWORD PTR [rcx+0x48],r15
  40c662:	jmp    40c668 <__swc_fn_23cea7fa_000049_ad48ec88+0x108>
  40c664:	mov    QWORD PTR [rax+0x8],r15
  40c668:	mov    QWORD PTR [rax+0x10],r15
  40c66c:	mov    rcx,r14
  40c66f:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40c674:	mov    rax,r15
  40c677:	add    rsp,0x30
  40c67b:	pop    r15
  40c67d:	pop    r14
  40c67f:	pop    r13
  40c681:	pop    r12
  40c683:	pop    rdi
  40c684:	pop    rsi
  40c685:	pop    rbx
  40c686:	ret
  40c687:	mov    rax,r15
  40c68a:	mov    r15,rcx
  40c68d:	test   rcx,rcx
  40c690:	jne    40c600 <__swc_fn_23cea7fa_000049_ad48ec88+0xa0>
  40c696:	mov    rax,QWORD PTR [rsi+0x18]
  40c69a:	mov    r15,rax
  40c69d:	test   r15,r15
  40c6a0:	je     40c736 <__swc_fn_23cea7fa_000049_ad48ec88+0x1d6>
  40c6a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40c6b0:	mov    eax,DWORD PTR [rsp+0xc]
  40c6b4:	cmp    DWORD PTR [r15+0x28],eax
  40c6b8:	jne    40c726 <__swc_fn_23cea7fa_000049_ad48ec88+0x1c6>
  40c6ba:	mov    rcx,r15
  40c6bd:	mov    edx,ebx
  40c6bf:	mov    rax,r12
  40c6c2:	mov    r8d,DWORD PTR [rax]
  40c6c5:	call   40f160 <__swc_fn_23cea7fa_000017_efc44797>
  40c6ca:	mov    r13,rax
  40c6cd:	test   rax,rax
  40c6d0:	je     40c726 <__swc_fn_23cea7fa_000049_ad48ec88+0x1c6>
  40c6d2:	mov    QWORD PTR [r13+0x40],rdi
  40c6d6:	movzx  eax,BYTE PTR [r13+0x39]
  40c6db:	lea    rax,[rax+rax*4]
  40c6df:	lea    rax,[rdi+rax*8+0x28]
  40c6e4:	mov    rcx,QWORD PTR [rax+0x10]
  40c6e8:	mov    QWORD PTR [r13+0x50],rcx
  40c6ec:	mov    QWORD PTR [r13+0x48],0x0
  40c6f4:	mov    rcx,QWORD PTR [rax+0x10]
  40c6f8:	test   rcx,rcx
  40c6fb:	je     40c703 <__swc_fn_23cea7fa_000049_ad48ec88+0x1a3>
  40c6fd:	mov    QWORD PTR [rcx+0x48],r13
  40c701:	jmp    40c707 <__swc_fn_23cea7fa_000049_ad48ec88+0x1a7>
  40c703:	mov    QWORD PTR [rax+0x8],r13
  40c707:	mov    QWORD PTR [rax+0x10],r13
  40c70b:	mov    rcx,r14
  40c70e:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40c713:	mov    rax,r13
  40c716:	add    rsp,0x30
  40c71a:	pop    r15
  40c71c:	pop    r14
  40c71e:	pop    r13
  40c720:	pop    r12
  40c722:	pop    rdi
  40c723:	pop    rsi
  40c724:	pop    rbx
  40c725:	ret
  40c726:	mov    rax,QWORD PTR [r15+0x10]
  40c72a:	mov    r15,rax
  40c72d:	test   rax,rax
  40c730:	jne    40c6b0 <__swc_fn_23cea7fa_000049_ad48ec88+0x150>
  40c736:	mov    rcx,rsi
  40c739:	mov    r13,QWORD PTR [rsp+0x18]
  40c73e:	mov    edx,DWORD PTR [r13+0x0]
  40c742:	call   407e20 <__swc_fn_23cea7fa_000024_2685aade>
  40c747:	mov    r13,rax
  40c74a:	test   rax,rax
  40c74d:	jne    40c769 <__swc_fn_23cea7fa_000049_ad48ec88+0x209>
  40c74f:	mov    rcx,r14
  40c752:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40c757:	xor    eax,eax
  40c759:	add    rsp,0x30
  40c75d:	pop    r15
  40c75f:	pop    r14
  40c761:	pop    r13
  40c763:	pop    r12
  40c765:	pop    rdi
  40c766:	pop    rsi
  40c767:	pop    rbx
  40c768:	ret
  40c769:	mov    rcx,r13
  40c76c:	mov    edx,ebx
  40c76e:	mov    r8d,DWORD PTR [r12]
  40c772:	call   40f160 <__swc_fn_23cea7fa_000017_efc44797>
  40c777:	mov    rbx,rax
  40c77a:	test   rax,rax
  40c77d:	jne    40c7a1 <__swc_fn_23cea7fa_000049_ad48ec88+0x241>
  40c77f:	mov    rcx,r13
  40c782:	call   40c1c0 <__swc_fn_23cea7fa_000025_aa910677>
  40c787:	mov    rcx,r14
  40c78a:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40c78f:	xor    eax,eax
  40c791:	add    rsp,0x30
  40c795:	pop    r15
  40c797:	pop    r14
  40c799:	pop    r13
  40c79b:	pop    r12
  40c79d:	pop    rdi
  40c79e:	pop    rsi
  40c79f:	pop    rbx
  40c7a0:	ret
  40c7a1:	mov    rax,QWORD PTR [rsi+0x18]
  40c7a5:	mov    QWORD PTR [r13+0x10],rax
  40c7a9:	mov    rax,QWORD PTR [rsi+0x18]
  40c7ad:	test   rax,rax
  40c7b0:	je     40c7b6 <__swc_fn_23cea7fa_000049_ad48ec88+0x256>
  40c7b2:	mov    QWORD PTR [rax+0x18],r13
  40c7b6:	mov    QWORD PTR [rsi+0x18],r13
  40c7ba:	mov    QWORD PTR [rbx+0x40],rdi
  40c7be:	movzx  eax,BYTE PTR [rbx+0x39]
  40c7c2:	lea    rax,[rax+rax*4]
  40c7c6:	lea    rax,[rdi+rax*8+0x28]
  40c7cb:	mov    rcx,QWORD PTR [rax+0x10]
  40c7cf:	mov    QWORD PTR [rbx+0x50],rcx
  40c7d3:	mov    QWORD PTR [rbx+0x48],0x0
  40c7db:	mov    rcx,QWORD PTR [rax+0x10]
  40c7df:	test   rcx,rcx
  40c7e2:	je     40c7ea <__swc_fn_23cea7fa_000049_ad48ec88+0x28a>
  40c7e4:	mov    QWORD PTR [rcx+0x48],rbx
  40c7e8:	jmp    40c7ee <__swc_fn_23cea7fa_000049_ad48ec88+0x28e>
  40c7ea:	mov    QWORD PTR [rax+0x8],rbx
  40c7ee:	mov    QWORD PTR [rax+0x10],rbx
  40c7f2:	mov    rcx,r14
  40c7f5:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40c7fa:	mov    rax,rbx
  40c7fd:	add    rsp,0x30
  40c801:	pop    r15
  40c803:	pop    r14
  40c805:	pop    r13
  40c807:	pop    r12
  40c809:	pop    rdi
  40c80a:	pop    rsi
  40c80b:	pop    rbx
  40c80c:	ret
	...

000000000040c820 <__swc_fn_23cea7fa_000052_d846b172>:
  40c820:	push   rsi
  40c821:	push   rdi
  40c822:	push   r12
  40c824:	mov    rsi,rdx
  40c827:	mov    rdi,rcx
  40c82a:	lea    rax,[rcx+0x2a80]
  40c831:	mov    rcx,QWORD PTR [rax]
  40c834:	test   rcx,rcx
  40c837:	jne    40c83e <__swc_fn_23cea7fa_000052_d846b172+0x1e>
  40c839:	pop    r12
  40c83b:	pop    rdi
  40c83c:	pop    rsi
  40c83d:	ret
  40c83e:	xor    ecx,ecx
  40c840:	xchg   QWORD PTR [rax],rcx
  40c843:	mov    r12,rcx
  40c846:	cs nop WORD PTR [rax+rax*1+0x0]
  40c850:	cs nop WORD PTR [rax+rax*1+0x0]
  40c85a:	nop    WORD PTR [rax+rax*1+0x0]
  40c860:	test   r12,r12
  40c863:	je     40c8fa <__swc_fn_23cea7fa_000052_d846b172+0xda>
  40c869:	mov    r8,r12
  40c86c:	mov    r12,QWORD PTR [r12+0x78]
  40c871:	lea    rcx,[r8+0x70]
  40c875:	xor    eax,eax
  40c877:	xchg   DWORD PTR [r8+0x70],eax
  40c87b:	cmp    QWORD PTR [r8+0x40],rsi
  40c87f:	jne    40c896 <__swc_fn_23cea7fa_000052_d846b172+0x76>
  40c881:	mov    eax,DWORD PTR [r8+0x6c]
  40c885:	test   eax,eax
  40c887:	je     40c860 <__swc_fn_23cea7fa_000052_d846b172+0x40>
  40c889:	mov    rcx,rdi
  40c88c:	mov    rdx,rsi
  40c88f:	call   4081d0 <__swc_fn_23cea7fa_000051_e072b516>
  40c894:	jmp    40c860 <__swc_fn_23cea7fa_000052_d846b172+0x40>
  40c896:	mov    rax,QWORD PTR [r8+0x40]
  40c89a:	test   rax,rax
  40c89d:	je     40c860 <__swc_fn_23cea7fa_000052_d846b172+0x40>
  40c89f:	mov    eax,DWORD PTR [r8+0x6c]
  40c8a3:	test   eax,eax
  40c8a5:	je     40c860 <__swc_fn_23cea7fa_000052_d846b172+0x40>
  40c8a7:	mov    r9d,0x1
  40c8ad:	xor    eax,eax
  40c8af:	lock cmpxchg DWORD PTR [rcx],r9d
  40c8b4:	test   eax,eax
  40c8b6:	jne    40c860 <__swc_fn_23cea7fa_000052_d846b172+0x40>
  40c8b8:	mov    rax,r8
  40c8bb:	and    rax,0xffffffffffc00000
  40c8c2:	mov    rax,QWORD PTR [rax+0x8]
  40c8c6:	test   rax,rax
  40c8c9:	jne    40c8d1 <__swc_fn_23cea7fa_000052_d846b172+0xb1>
  40c8cb:	xor    eax,eax
  40c8cd:	xchg   DWORD PTR [rcx],eax
  40c8cf:	jmp    40c860 <__swc_fn_23cea7fa_000052_d846b172+0x40>
  40c8d1:	lea    rcx,[rax+0x2a80]
  40c8d8:	mov    rax,QWORD PTR [rcx]
  40c8db:	mov    rdx,rax
  40c8de:	xchg   ax,ax
  40c8e0:	mov    QWORD PTR [r8+0x78],rdx
  40c8e4:	mov    rax,rdx
  40c8e7:	lock cmpxchg QWORD PTR [rcx],r8
  40c8ec:	cmp    rax,rdx
  40c8ef:	je     40c860 <__swc_fn_23cea7fa_000052_d846b172+0x40>
  40c8f5:	mov    rdx,rax
  40c8f8:	jmp    40c8e0 <__swc_fn_23cea7fa_000052_d846b172+0xc0>
  40c8fa:	pop    r12
  40c8fc:	pop    rdi
  40c8fd:	pop    rsi
  40c8fe:	ret
	...

000000000040c900 <__swc_fn_23cea7fa_000055_2e3450f7>:
  40c900:	sub    rsp,0x8
  40c904:	mov    r9,r8
  40c907:	movzx  eax,BYTE PTR [r9+0x39]
  40c90c:	lea    rax,[rax+rax*4]
  40c910:	lea    rax,[rdx+rax*8+0x28]
  40c915:	cmp    QWORD PTR [rax],r9
  40c918:	je     40c920 <__swc_fn_23cea7fa_000055_2e3450f7+0x20>
  40c91a:	cmp    QWORD PTR [rax+0x20],r9
  40c91e:	jne    40c925 <__swc_fn_23cea7fa_000055_2e3450f7+0x25>
  40c920:	add    rsp,0x8
  40c924:	ret
  40c925:	cmp    QWORD PTR [rax+0x20],0x0
  40c92a:	je     40c937 <__swc_fn_23cea7fa_000055_2e3450f7+0x37>
  40c92c:	mov    r8,QWORD PTR [rax+0x20]
  40c930:	cmp    DWORD PTR [r8+0x28],0x0
  40c935:	je     40c940 <__swc_fn_23cea7fa_000055_2e3450f7+0x40>
  40c937:	mov    QWORD PTR [rax+0x20],r9
  40c93b:	add    rsp,0x8
  40c93f:	ret
  40c940:	mov    r8,r9
  40c943:	call   408130 <__swc_fn_23cea7fa_000048_137687bb>
  40c948:	mov    rax,r9
  40c94b:	and    rax,0xffffffffffc00000
  40c952:	mov    rcx,rax
  40c955:	mov    rdx,r9
  40c958:	call   407ca0 <__swc_fn_23cea7fa_000018_283e2b5e>
  40c95d:	add    rsp,0x8
  40c961:	ret
	...

000000000040c970 <__swc_fn_23cea7fa_000058_1bb23e77>:
  40c970:	push   rsi
  40c971:	push   rdi
  40c972:	push   r12
  40c974:	mov    rsi,rdx
  40c977:	mov    rax,rdx
  40c97a:	shr    rax,0xc
  40c97e:	movabs rdx,0x9e3779b97f4a7c15
  40c988:	imul   rax,rdx
  40c98c:	shr    rax,0x20
  40c990:	lea    rax,[rax*8+0x0]
  40c998:	shr    rax,0x20
  40c99c:	lea    rax,[rax*8+0x0]
  40c9a4:	lea    rax,[rcx+rax*8+0x40]
  40c9a9:	xor    edx,edx
  40c9ab:	test   dl,dl
  40c9ad:	lea    rdi,[rcx+0x8]
  40c9b1:	cmove  rdi,rax
  40c9b5:	xor    edx,edx
  40c9b7:	test   dl,dl
  40c9b9:	lea    r12,[rcx+0x30]
  40c9bd:	lea    rax,[rax+0x8]
  40c9c1:	cmove  r12,rax
  40c9c5:	mov    rcx,rdi
  40c9c8:	call   40e420 <__swc_fn_23cea7fa_000139_86bb0f90>
  40c9cd:	mov    rax,QWORD PTR [rsi+0x30]
  40c9d1:	test   rax,rax
  40c9d4:	jne    40c9e0 <__swc_fn_23cea7fa_000058_1bb23e77+0x70>
  40c9d6:	mov    rax,QWORD PTR [rsi+0x38]
  40c9da:	mov    QWORD PTR [r12],rax
  40c9de:	jmp    40c9e8 <__swc_fn_23cea7fa_000058_1bb23e77+0x78>
  40c9e0:	mov    rcx,QWORD PTR [rsi+0x38]
  40c9e4:	mov    QWORD PTR [rax+0x38],rcx
  40c9e8:	mov    rax,QWORD PTR [rsi+0x38]
  40c9ec:	test   rax,rax
  40c9ef:	je     40c9f9 <__swc_fn_23cea7fa_000058_1bb23e77+0x89>
  40c9f1:	mov    rcx,QWORD PTR [rsi+0x30]
  40c9f5:	mov    QWORD PTR [rax+0x30],rcx
  40c9f9:	vxorps xmm0,xmm0,xmm0
  40c9fd:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  40ca02:	mov    rcx,rdi
  40ca05:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40ca0a:	pop    r12
  40ca0c:	pop    rdi
  40ca0d:	pop    rsi
  40ca0e:	ret
	...

000000000040ca10 <__swc_fn_23cea7fa_000061_ad030a10>:
  40ca10:	mov    rax,QWORD PTR [rcx+0x250]
  40ca17:	mov    rcx,rax
  40ca1a:	cmp    rax,0x1000000
  40ca21:	mov    eax,0x1000000
  40ca26:	cmovb  rcx,rax
  40ca2a:	mov    rax,rcx
  40ca2d:	cmp    rcx,0x10000000
  40ca34:	mov    ecx,0x10000000
  40ca39:	cmova  rax,rcx
  40ca3d:	ret
	...

000000000040ca40 <__swc_fn_23cea7fa_000064_ffcd96eb>:
  40ca40:	push   rsi
  40ca41:	push   rdi
  40ca42:	push   r12
  40ca44:	mov    rsi,rcx
  40ca47:	mov    rdi,QWORD PTR [rsi+0x2a70]
  40ca4e:	xor    r12d,r12d
  40ca51:	test   rdi,rdi
  40ca54:	jbe    40ca8b <__swc_fn_23cea7fa_000064_ffcd96eb+0x4b>
  40ca56:	cs nop WORD PTR [rax+rax*1+0x0]
  40ca60:	lea    rax,[r12+r12*4]
  40ca64:	lea    rax,[rsi+rax*8+0x268]
  40ca6c:	mov    rcx,rsi
  40ca6f:	mov    rdx,QWORD PTR [rax]
  40ca72:	mov    r8,QWORD PTR [rax+0x8]
  40ca76:	mov    rax,QWORD PTR [rax+0x10]
  40ca7a:	mov    r9,rax
  40ca7d:	call   40c2e0 <__swc_fn_23cea7fa_000043_d3c2ab54>
  40ca82:	add    r12,0x1
  40ca86:	cmp    r12,rdi
  40ca89:	jb     40ca60 <__swc_fn_23cea7fa_000064_ffcd96eb+0x20>
  40ca8b:	vxorps xmm0,xmm0,xmm0
  40ca8f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  40ca97:	pop    r12
  40ca99:	pop    rdi
  40ca9a:	pop    rsi
  40ca9b:	ret
  40ca9c:	add    BYTE PTR [rax],al
	...

000000000040caa0 <__swc_fn_23cea7fa_000067_8c7d044b>:
  40caa0:	push   rsi
  40caa1:	push   rdi
  40caa2:	sub    rsp,0x8
  40caa6:	mov    rsi,rcx
  40caa9:	call   40faa0 <__swc_fn_23cea7fa_000056_df0696cd>
  40caae:	mov    rdi,rax
  40cab1:	mov    rcx,rsi
  40cab4:	mov    rdx,rax
  40cab7:	call   40c970 <__swc_fn_23cea7fa_000058_1bb23e77>
  40cabc:	mov    rcx,QWORD PTR [rdi+0x28]
  40cac0:	mov    rdx,QWORD PTR [rsi+0x250]
  40cac7:	nop    WORD PTR [rax+rax*1+0x0]
  40cad0:	mov    r8,rdx
  40cad3:	sub    r8,rcx
  40cad6:	mov    rax,rdx
  40cad9:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40cae2:	cmp    rax,rdx
  40cae5:	je     40caec <__swc_fn_23cea7fa_000067_8c7d044b+0x4c>
  40cae7:	mov    rdx,rax
  40caea:	jmp    40cad0 <__swc_fn_23cea7fa_000067_8c7d044b+0x30>
  40caec:	mov    rcx,rsi
  40caef:	mov    rdx,QWORD PTR [rdi]
  40caf2:	mov    r8,QWORD PTR [rdi+0x8]
  40caf6:	mov    r9,QWORD PTR [rdi+0x10]
  40cafa:	call   40fbc0 <__swc_fn_23cea7fa_000062_b304235a>
  40caff:	mov    rcx,rsi
  40cb02:	call   40f800 <__swc_fn_23cea7fa_000053_3af34d7f>
  40cb07:	add    rsp,0x8
  40cb0b:	pop    rdi
  40cb0c:	pop    rsi
  40cb0d:	ret
	...

000000000040cb10 <__swc_fn_23cea7fa_000070_97813b89>:
  40cb10:	push   r12
  40cb12:	push   r13
  40cb14:	push   r14
  40cb16:	push   rdi
  40cb17:	push   rsi
  40cb18:	sub    rsp,0x1b0
  40cb1f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  40cb28:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  40cb31:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  40cb3a:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  40cb43:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  40cb4c:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  40cb55:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  40cb5e:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  40cb67:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  40cb70:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  40cb79:	mov    r8,rdx
  40cb7c:	mov    r12,rcx
  40cb7f:	mov    r13,QWORD PTR [r8+0x40]
  40cb83:	test   r13,r13
  40cb86:	jne    40cb98 <__swc_fn_23cea7fa_000070_97813b89+0x88>
  40cb88:	add    rsp,0x1b0
  40cb8f:	pop    rsi
  40cb90:	pop    rdi
  40cb91:	pop    r14
  40cb93:	pop    r13
  40cb95:	pop    r12
  40cb97:	ret
  40cb98:	mov    QWORD PTR [r8+0x40],0x0
  40cba0:	lea    rax,[rip+0x174d1]        # 424078 <__swc_bss_base_23cea7fa+0x38>
  40cba7:	mov    rcx,r13
  40cbaa:	sub    rcx,QWORD PTR [rax+0x8]
  40cbae:	mov    rax,QWORD PTR [rip+0x174d3]        # 424088 <__swc_bss_base_23cea7fa+0x48>
  40cbb5:	cmp    rcx,rax
  40cbb8:	jae    40cbe4 <__swc_fn_23cea7fa_000070_97813b89+0xd4>
  40cbba:	mov    rax,r13
  40cbbd:	and    rax,0xffffffffffc00000
  40cbc4:	mov    rcx,r13
  40cbc7:	shr    rcx,0x10
  40cbcb:	and    ecx,0x3f
  40cbce:	mov    edx,DWORD PTR [rax+0x28]
  40cbd1:	shrx   ecx,ecx,edx
  40cbd6:	shl    rcx,0x4
  40cbda:	lea    r14,[rax+rcx*8+0x80]
  40cbe2:	jmp    40cbff <__swc_fn_23cea7fa_000070_97813b89+0xef>
  40cbe4:	mov    rcx,r13
  40cbe7:	mov    QWORD PTR [rsp+0xf8],r8
  40cbef:	call   40f490 <__swc_fn_23cea7fa_000026_bcdc5519>
  40cbf4:	mov    r8,QWORD PTR [rsp+0xf8]
  40cbfc:	mov    r14,rax
  40cbff:	test   r14,r14
  40cc02:	jne    40cc14 <__swc_fn_23cea7fa_000070_97813b89+0x104>
  40cc04:	mov    rcx,r12
  40cc07:	mov    rdx,r13
  40cc0a:	call   40caa0 <__swc_fn_23cea7fa_000067_8c7d044b>
  40cc0f:	jmp    40cca2 <__swc_fn_23cea7fa_000070_97813b89+0x192>
  40cc14:	lea    rax,[rip+0x153ed]        # 422008 <__swc_data_base_23cea7fa+0x8>
  40cc1b:	mov    rax,QWORD PTR [rax]
  40cc1e:	cmp    rax,0xffffffffffffffff
  40cc22:	je     40cc31 <__swc_fn_23cea7fa_000070_97813b89+0x121>
  40cc24:	mov    eax,eax
  40cc26:	mov    edi,eax
  40cc28:	xor    eax,eax
  40cc2a:	call   407000 <pthread_getspecific@plt>
  40cc2f:	jmp    40cc33 <__swc_fn_23cea7fa_000070_97813b89+0x123>
  40cc31:	xor    eax,eax
  40cc33:	test   rax,rax
  40cc36:	jne    40cc45 <__swc_fn_23cea7fa_000070_97813b89+0x135>
  40cc38:	call   40f560 <__swc_fn_23cea7fa_000035_cd1a4e8c>
  40cc3d:	mov    rcx,rax
  40cc40:	call   40a160 <__swc_fn_23cea7fa_000132_5f757033>
  40cc45:	test   rax,rax
  40cc48:	je     40cc97 <__swc_fn_23cea7fa_000070_97813b89+0x187>
  40cc4a:	cmp    QWORD PTR [r14+0x40],rax
  40cc4e:	jne    40cc97 <__swc_fn_23cea7fa_000070_97813b89+0x187>
  40cc50:	mov    ecx,DWORD PTR [r14+0x6c]
  40cc54:	test   ecx,ecx
  40cc56:	je     40cc76 <__swc_fn_23cea7fa_000070_97813b89+0x166>
  40cc58:	mov    rcx,r12
  40cc5b:	mov    rdx,rax
  40cc5e:	mov    r8,r14
  40cc61:	mov    QWORD PTR [rsp+0x100],rax
  40cc69:	call   4081d0 <__swc_fn_23cea7fa_000051_e072b516>
  40cc6e:	mov    rax,QWORD PTR [rsp+0x100]
  40cc76:	mov    rcx,QWORD PTR [r14]
  40cc79:	mov    QWORD PTR [r13+0x0],rcx
  40cc7d:	mov    QWORD PTR [r14],r13
  40cc80:	sub    DWORD PTR [r14+0x28],0x1
  40cc85:	jne    40cca2 <__swc_fn_23cea7fa_000070_97813b89+0x192>
  40cc87:	mov    rcx,r12
  40cc8a:	mov    rdx,rax
  40cc8d:	mov    r8,r14
  40cc90:	call   40c900 <__swc_fn_23cea7fa_000055_2e3450f7>
  40cc95:	jmp    40cca2 <__swc_fn_23cea7fa_000070_97813b89+0x192>
  40cc97:	mov    rcx,r14
  40cc9a:	mov    rdx,r13
  40cc9d:	call   40f0d0 <__swc_fn_23cea7fa_000014_524c1f23>
  40cca2:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40ccab:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  40ccb4:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40ccbd:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  40ccc6:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40cccf:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  40ccd8:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  40cce1:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40ccea:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  40ccf3:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40ccfc:	add    rsp,0x1b0
  40cd03:	pop    rsi
  40cd04:	pop    rdi
  40cd05:	pop    r14
  40cd07:	pop    r13
  40cd09:	pop    r12
  40cd0b:	ret
  40cd0c:	add    BYTE PTR [rax],al
	...

000000000040cd10 <__swc_fn_23cea7fa_000073_9c99bf04>:
  40cd10:	push   rsi
  40cd11:	mov    rsi,rcx
  40cd14:	call   40c2d0 <__swc_fn_23cea7fa_000040_eb6108f2>
  40cd19:	test   al,al
  40cd1b:	jne    40cd1f <__swc_fn_23cea7fa_000073_9c99bf04+0xf>
  40cd1d:	pop    rsi
  40cd1e:	ret
  40cd1f:	lea    rax,[rip+0x1751a]        # 424240 <__swc_bss_base_23cea7fa+0x200>
  40cd26:	cmp    rsi,rax
  40cd29:	jne    40cd2d <__swc_fn_23cea7fa_000073_9c99bf04+0x1d>
  40cd2b:	pop    rsi
  40cd2c:	ret
  40cd2d:	mov    rcx,rsi
  40cd30:	call   40e420 <__swc_fn_23cea7fa_000139_86bb0f90>
  40cd35:	mov    rcx,rsi
  40cd38:	call   4089a0 <__swc_fn_23cea7fa_000072_61e60aab>
  40cd3d:	mov    rcx,rsi
  40cd40:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40cd45:	pop    rsi
  40cd46:	ret
	...

000000000040cd50 <__swc_fn_23cea7fa_000076_15bd096c>:
  40cd50:	sub    rsp,0x8
  40cd54:	call   4086f0 <__swc_fn_23cea7fa_000069_7130736e>
  40cd59:	add    rsp,0x8
  40cd5d:	ret
	...

000000000040cd60 <__swc_fn_23cea7fa_000079_a5fd3362>:
  40cd60:	push   rsi
  40cd61:	mov    rsi,rdx
  40cd64:	call   4089a0 <__swc_fn_23cea7fa_000072_61e60aab>
  40cd69:	mov    QWORD PTR [rsi+0x40],0x0
  40cd71:	pop    rsi
  40cd72:	ret
	...

000000000040cd80 <__swc_fn_23cea7fa_000082_63a67586>:
  40cd80:	mov    r8,rcx
  40cd83:	mov    rcx,QWORD PTR [rcx]
  40cd86:	cs nop WORD PTR [rax+rax*1+0x0]
  40cd90:	mov    r9,rcx
  40cd93:	sub    r9,rdx
  40cd96:	mov    rax,rcx
  40cd99:	lock cmpxchg QWORD PTR [r8],r9
  40cd9e:	cmp    rax,rcx
  40cda1:	je     40cda8 <__swc_fn_23cea7fa_000082_63a67586+0x28>
  40cda3:	mov    rcx,rax
  40cda6:	jmp    40cd90 <__swc_fn_23cea7fa_000082_63a67586+0x10>
  40cda8:	mov    rax,rcx
  40cdab:	ret
  40cdac:	add    BYTE PTR [rax],al
	...

000000000040cdb0 <__swc_fn_23cea7fa_000085_c618ff58>:
  40cdb0:	vxorps xmm0,xmm0,xmm0
  40cdb4:	vmovups XMMWORD PTR [rcx],xmm0
  40cdb8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40cdbd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40cdc2:	ret
	...

000000000040cdd0 <__swc_fn_23cea7fa_000088_0d280354>:
  40cdd0:	push   rsi
  40cdd1:	push   rdi
  40cdd2:	push   r12
  40cdd4:	push   r13
  40cdd6:	push   r15
  40cdd8:	push   r14
  40cdda:	push   rbx
  40cddb:	sub    rsp,0x60
  40cddf:	mov    QWORD PTR [rsp+0x28],r11
  40cde4:	mov    rsi,rcx
  40cde7:	mov    rdi,rdx
  40cdea:	mov    QWORD PTR [rsp+0x30],rdx
  40cdef:	mov    r12,r8
  40cdf2:	mov    r13,r9
  40cdf5:	mov    QWORD PTR [rsp+0x38],r10
  40cdfa:	xor    r8d,r8d
  40cdfd:	call   40d120 <__swc_fn_23cea7fa_000094_63c1827b>
  40ce02:	test   al,al
  40ce04:	je     40ce19 <__swc_fn_23cea7fa_000088_0d280354+0x49>
  40ce06:	mov    rax,r12
  40ce09:	add    rsp,0x60
  40ce0d:	pop    rbx
  40ce0e:	pop    r14
  40ce10:	pop    r15
  40ce12:	pop    r13
  40ce14:	pop    r12
  40ce16:	pop    rdi
  40ce17:	pop    rsi
  40ce18:	ret
  40ce19:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40ce1e:	je     40ce32 <__swc_fn_23cea7fa_000088_0d280354+0x62>
  40ce20:	xor    eax,eax
  40ce22:	add    rsp,0x60
  40ce26:	pop    rbx
  40ce27:	pop    r14
  40ce29:	pop    r15
  40ce2b:	pop    r13
  40ce2d:	pop    r12
  40ce2f:	pop    rdi
  40ce30:	pop    rsi
  40ce31:	ret
  40ce32:	mov    r15,rdi
  40ce35:	mov    QWORD PTR [rsp+0x40],rdi
  40ce3a:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40ce3f:	jne    40ceaf <__swc_fn_23cea7fa_000088_0d280354+0xdf>
  40ce41:	mov    r14,QWORD PTR [r15+0xb8]
  40ce48:	mov    rax,QWORD PTR [r15+0xc0]
  40ce4f:	mov    r15,rax
  40ce52:	xor    edi,edi
  40ce54:	test   r15,r15
  40ce57:	je     40ceaf <__swc_fn_23cea7fa_000088_0d280354+0xdf>
  40ce59:	nop    DWORD PTR [rax+0x0]
  40ce60:	lea    rbx,[rdi*8+0x0]
  40ce68:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  40ce6d:	mov    rcx,rax
  40ce70:	mov    rdx,rsi
  40ce73:	xor    r8d,r8d
  40ce76:	call   40d120 <__swc_fn_23cea7fa_000094_63c1827b>
  40ce7b:	test   al,al
  40ce7d:	je     40cea5 <__swc_fn_23cea7fa_000088_0d280354+0xd5>
  40ce7f:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  40ce84:	test   rax,rax
  40ce87:	je     40cea5 <__swc_fn_23cea7fa_000088_0d280354+0xd5>
  40ce89:	test   r13,r13
  40ce8c:	je     40ce92 <__swc_fn_23cea7fa_000088_0d280354+0xc2>
  40ce8e:	mov    QWORD PTR [r13+0x8],rax
  40ce92:	mov    rax,r12
  40ce95:	add    rsp,0x60
  40ce99:	pop    rbx
  40ce9a:	pop    r14
  40ce9c:	pop    r15
  40ce9e:	pop    r13
  40cea0:	pop    r12
  40cea2:	pop    rdi
  40cea3:	pop    rsi
  40cea4:	ret
  40cea5:	add    rdi,0x1
  40cea9:	sub    r15,0x1
  40cead:	jne    40ce60 <__swc_fn_23cea7fa_000088_0d280354+0x90>
  40ceaf:	test   r12,r12
  40ceb2:	jne    40cec6 <__swc_fn_23cea7fa_000088_0d280354+0xf6>
  40ceb4:	xor    eax,eax
  40ceb6:	add    rsp,0x60
  40ceba:	pop    rbx
  40cebb:	pop    r14
  40cebd:	pop    r15
  40cebf:	pop    r13
  40cec1:	pop    r12
  40cec3:	pop    rdi
  40cec4:	pop    rsi
  40cec5:	ret
  40cec6:	mov    rbx,QWORD PTR [rsp+0x28]
  40cecb:	mov    rdi,QWORD PTR [rsp+0x30]
  40ced0:	mov    rax,rbx
  40ced3:	test   rax,rax
  40ced6:	je     40cf06 <__swc_fn_23cea7fa_000088_0d280354+0x136>
  40ced8:	nop    DWORD PTR [rax+rax*1+0x0]
  40cee0:	cmp    QWORD PTR [rax+0x8],r12
  40cee4:	jne    40cefd <__swc_fn_23cea7fa_000088_0d280354+0x12d>
  40cee6:	cmp    QWORD PTR [rax],rdi
  40cee9:	jne    40cefd <__swc_fn_23cea7fa_000088_0d280354+0x12d>
  40ceeb:	xor    eax,eax
  40ceed:	add    rsp,0x60
  40cef1:	pop    rbx
  40cef2:	pop    r14
  40cef4:	pop    r15
  40cef6:	pop    r13
  40cef8:	pop    r12
  40cefa:	pop    rdi
  40cefb:	pop    rsi
  40cefc:	ret
  40cefd:	mov    rax,QWORD PTR [rax+0x10]
  40cf01:	test   rax,rax
  40cf04:	jne    40cee0 <__swc_fn_23cea7fa_000088_0d280354+0x110>
  40cf06:	lea    r14,[rsp+0x8]
  40cf0b:	mov    QWORD PTR [rsp+0x48],r14
  40cf10:	mov    QWORD PTR [rsp+0x8],rdi
  40cf15:	mov    QWORD PTR [rsp+0x10],r12
  40cf1a:	mov    QWORD PTR [rsp+0x18],rbx
  40cf1f:	mov    r15,QWORD PTR [rsp+0x40]
  40cf24:	mov    rbx,QWORD PTR [r15+0x98]
  40cf2b:	mov    rax,QWORD PTR [r15+0xa0]
  40cf32:	mov    rdi,rax
  40cf35:	mov    r15,QWORD PTR [rsp+0x38]
  40cf3a:	xor    r14d,r14d
  40cf3d:	test   rdi,rdi
  40cf40:	je     40cfea <__swc_fn_23cea7fa_000088_0d280354+0x21a>
  40cf46:	cs nop WORD PTR [rax+rax*1+0x0]
  40cf50:	mov    QWORD PTR [rsp+0x50],rdi
  40cf55:	lea    rdi,[r14*8+0x0]
  40cf5d:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  40cf62:	mov    rcx,rax
  40cf65:	call   410ba0 <__swc_fn_23cea7fa_000086_3953ef98>
  40cf6a:	test   DWORD PTR [rax+0x28],0x10000
  40cf71:	je     40cf78 <__swc_fn_23cea7fa_000088_0d280354+0x1a8>
  40cf73:	test   r15b,r15b
  40cf76:	je     40cfd1 <__swc_fn_23cea7fa_000088_0d280354+0x201>
  40cf78:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  40cf7c:	lea    rdi,[r12+rcx*1]
  40cf80:	cmp    BYTE PTR [rax+0x2c],0x6
  40cf84:	jne    40cf98 <__swc_fn_23cea7fa_000088_0d280354+0x1c8>
  40cf86:	mov    rax,QWORD PTR [rax+0x40]
  40cf8a:	mov    rcx,rax
  40cf8d:	call   410ba0 <__swc_fn_23cea7fa_000086_3953ef98>
  40cf92:	mov    rcx,QWORD PTR [rdi]
  40cf95:	mov    rdi,rcx
  40cf98:	test   rdi,rdi
  40cf9b:	je     40cfd1 <__swc_fn_23cea7fa_000088_0d280354+0x201>
  40cf9d:	mov    rcx,rsi
  40cfa0:	mov    rdx,rax
  40cfa3:	mov    r8,rdi
  40cfa6:	mov    r9,r13
  40cfa9:	mov    al,r15b
  40cfac:	mov    r10,rax
  40cfaf:	mov    rdi,QWORD PTR [rsp+0x48]
  40cfb4:	mov    r11,rdi
  40cfb7:	call   40cdd0 <__swc_fn_23cea7fa_000088_0d280354>
  40cfbc:	test   rax,rax
  40cfbf:	je     40cfd1 <__swc_fn_23cea7fa_000088_0d280354+0x201>
  40cfc1:	add    rsp,0x60
  40cfc5:	pop    rbx
  40cfc6:	pop    r14
  40cfc8:	pop    r15
  40cfca:	pop    r13
  40cfcc:	pop    r12
  40cfce:	pop    rdi
  40cfcf:	pop    rsi
  40cfd0:	ret
  40cfd1:	add    r14,0x1
  40cfd5:	mov    rax,QWORD PTR [rsp+0x50]
  40cfda:	sub    rax,0x1
  40cfde:	mov    rdi,rax
  40cfe1:	test   rax,rax
  40cfe4:	jne    40cf50 <__swc_fn_23cea7fa_000088_0d280354+0x180>
  40cfea:	xor    eax,eax
  40cfec:	add    rsp,0x60
  40cff0:	pop    rbx
  40cff1:	pop    r14
  40cff3:	pop    r15
  40cff5:	pop    r13
  40cff7:	pop    r12
  40cff9:	pop    rdi
  40cffa:	pop    rsi
  40cffb:	ret
  40cffc:	add    BYTE PTR [rax],al
	...

000000000040d000 <__swc_fn_23cea7fa_000091_c1c9085b>:
  40d000:	push   rsi
  40d001:	push   rdi
  40d002:	push   r12
  40d004:	push   r13
  40d006:	push   r14
  40d008:	push   r15
  40d00a:	sub    rsp,0x78
  40d00e:	mov    rsi,r10
  40d011:	mov    QWORD PTR [rsp+0x68],r10
  40d016:	mov    rdi,rcx
  40d019:	mov    r12,rdx
  40d01c:	mov    r13,r8
  40d01f:	mov    r14,r9
  40d022:	xor    r8d,r8d
  40d025:	call   40d120 <__swc_fn_23cea7fa_000094_63c1827b>
  40d02a:	test   al,al
  40d02c:	je     40d055 <__swc_fn_23cea7fa_000091_c1c9085b+0x55>
  40d02e:	mov    rcx,r14
  40d031:	mov    rdx,r12
  40d034:	mov    r8,r13
  40d037:	mov    r9,rsi
  40d03a:	call   408e00 <__swc_fn_23cea7fa_000090_23214800>
  40d03f:	test   al,al
  40d041:	je     40d055 <__swc_fn_23cea7fa_000091_c1c9085b+0x55>
  40d043:	mov    rax,r13
  40d046:	add    rsp,0x78
  40d04a:	pop    r15
  40d04c:	pop    r14
  40d04e:	pop    r13
  40d050:	pop    r12
  40d052:	pop    rdi
  40d053:	pop    rsi
  40d054:	ret
  40d055:	cmp    BYTE PTR [r12+0x2c],0xe
  40d05b:	je     40d06e <__swc_fn_23cea7fa_000091_c1c9085b+0x6e>
  40d05d:	xor    eax,eax
  40d05f:	add    rsp,0x78
  40d063:	pop    r15
  40d065:	pop    r14
  40d067:	pop    r13
  40d069:	pop    r12
  40d06b:	pop    rdi
  40d06c:	pop    rsi
  40d06d:	ret
  40d06e:	mov    r15,QWORD PTR [r12+0x98]
  40d076:	mov    rax,QWORD PTR [r12+0xa0]
  40d07e:	mov    r12,rax
  40d081:	xor    esi,esi
  40d083:	test   r12,r12
  40d086:	je     40d0f9 <__swc_fn_23cea7fa_000091_c1c9085b+0xf9>
  40d088:	nop    DWORD PTR [rax+rax*1+0x0]
  40d090:	mov    QWORD PTR [rsp+0x70],r12
  40d095:	lea    r12,[rsi*8+0x0]
  40d09d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  40d0a2:	mov    rcx,rax
  40d0a5:	call   410ba0 <__swc_fn_23cea7fa_000086_3953ef98>
  40d0aa:	cmp    BYTE PTR [rax+0x2c],0xe
  40d0ae:	jne    40d0e4 <__swc_fn_23cea7fa_000091_c1c9085b+0xe4>
  40d0b0:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  40d0b5:	lea    r8,[r13+rcx*1+0x0]
  40d0ba:	mov    rcx,rdi
  40d0bd:	mov    rdx,rax
  40d0c0:	mov    r9,r14
  40d0c3:	mov    r12,QWORD PTR [rsp+0x68]
  40d0c8:	mov    r10,r12
  40d0cb:	call   40d000 <__swc_fn_23cea7fa_000091_c1c9085b>
  40d0d0:	test   rax,rax
  40d0d3:	je     40d0e4 <__swc_fn_23cea7fa_000091_c1c9085b+0xe4>
  40d0d5:	add    rsp,0x78
  40d0d9:	pop    r15
  40d0db:	pop    r14
  40d0dd:	pop    r13
  40d0df:	pop    r12
  40d0e1:	pop    rdi
  40d0e2:	pop    rsi
  40d0e3:	ret
  40d0e4:	add    rsi,0x1
  40d0e8:	mov    rax,QWORD PTR [rsp+0x70]
  40d0ed:	sub    rax,0x1
  40d0f1:	mov    r12,rax
  40d0f4:	test   rax,rax
  40d0f7:	jne    40d090 <__swc_fn_23cea7fa_000091_c1c9085b+0x90>
  40d0f9:	xor    eax,eax
  40d0fb:	add    rsp,0x78
  40d0ff:	pop    r15
  40d101:	pop    r14
  40d103:	pop    r13
  40d105:	pop    r12
  40d107:	pop    rdi
  40d108:	pop    rsi
  40d109:	ret
	...

000000000040d120 <__swc_fn_23cea7fa_000094_63c1827b>:
  40d120:	push   rbx
  40d121:	push   rsi
  40d122:	push   rdi
  40d123:	push   r12
  40d125:	push   r13
  40d127:	push   r14
  40d129:	push   r15
  40d12b:	sub    rsp,0x120
  40d132:	mov    rbx,r8
  40d135:	mov    rsi,rdx
  40d138:	test   rcx,rcx
  40d13b:	jne    40d15a <__swc_fn_23cea7fa_000094_63c1827b+0x3a>
  40d13d:	test   rsi,rsi
  40d140:	jne    40d15a <__swc_fn_23cea7fa_000094_63c1827b+0x3a>
  40d142:	mov    eax,0x1
  40d147:	add    rsp,0x120
  40d14e:	pop    r15
  40d150:	pop    r14
  40d152:	pop    r13
  40d154:	pop    r12
  40d156:	pop    rdi
  40d157:	pop    rsi
  40d158:	pop    rbx
  40d159:	ret
  40d15a:	test   rcx,rcx
  40d15d:	je     40d164 <__swc_fn_23cea7fa_000094_63c1827b+0x44>
  40d15f:	test   rsi,rsi
  40d162:	jne    40d179 <__swc_fn_23cea7fa_000094_63c1827b+0x59>
  40d164:	xor    eax,eax
  40d166:	add    rsp,0x120
  40d16d:	pop    r15
  40d16f:	pop    r14
  40d171:	pop    r13
  40d173:	pop    r12
  40d175:	pop    rdi
  40d176:	pop    rsi
  40d177:	pop    rbx
  40d178:	ret
  40d179:	call   410ba0 <__swc_fn_23cea7fa_000086_3953ef98>
  40d17e:	mov    rdi,rax
  40d181:	mov    rcx,rsi
  40d184:	call   410ba0 <__swc_fn_23cea7fa_000086_3953ef98>
  40d189:	test   bl,0x1
  40d18c:	je     40d1ca <__swc_fn_23cea7fa_000094_63c1827b+0xaa>
  40d18e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  40d193:	jne    40d1ca <__swc_fn_23cea7fa_000094_63c1827b+0xaa>
  40d195:	mov    ecx,DWORD PTR [rdi+0x28]
  40d198:	test   ecx,0x1000
  40d19e:	je     40d1ca <__swc_fn_23cea7fa_000094_63c1827b+0xaa>
  40d1a0:	test   ecx,0x10000
  40d1a6:	je     40d1ca <__swc_fn_23cea7fa_000094_63c1827b+0xaa>
  40d1a8:	mov    rcx,QWORD PTR [rdi+0x40]
  40d1ac:	mov    rdx,rax
  40d1af:	mov    r8d,ebx
  40d1b2:	call   40d120 <__swc_fn_23cea7fa_000094_63c1827b>
  40d1b7:	add    rsp,0x120
  40d1be:	pop    r15
  40d1c0:	pop    r14
  40d1c2:	pop    r13
  40d1c4:	pop    r12
  40d1c6:	pop    rdi
  40d1c7:	pop    rsi
  40d1c8:	pop    rbx
  40d1c9:	ret
  40d1ca:	mov    cl,BYTE PTR [rax+0x2c]
  40d1cd:	rex cmp BYTE PTR [rdi+0x2c],cl
  40d1d1:	jne    40d1db <__swc_fn_23cea7fa_000094_63c1827b+0xbb>
  40d1d3:	mov    ecx,DWORD PTR [rax+0x20]
  40d1d6:	cmp    DWORD PTR [rdi+0x20],ecx
  40d1d9:	je     40d1f0 <__swc_fn_23cea7fa_000094_63c1827b+0xd0>
  40d1db:	xor    eax,eax
  40d1dd:	add    rsp,0x120
  40d1e4:	pop    r15
  40d1e6:	pop    r14
  40d1e8:	pop    r13
  40d1ea:	pop    r12
  40d1ec:	pop    rdi
  40d1ed:	pop    rsi
  40d1ee:	pop    rbx
  40d1ef:	ret
  40d1f0:	mov    ecx,DWORD PTR [rdi+0x28]
  40d1f3:	and    ecx,0xffb5ffff
  40d1f9:	mov    edx,DWORD PTR [rax+0x28]
  40d1fc:	and    edx,0xffb5ffff
  40d202:	cmp    ecx,edx
  40d204:	je     40d21b <__swc_fn_23cea7fa_000094_63c1827b+0xfb>
  40d206:	xor    eax,eax
  40d208:	add    rsp,0x120
  40d20f:	pop    r15
  40d211:	pop    r14
  40d213:	pop    r13
  40d215:	pop    r12
  40d217:	pop    rdi
  40d218:	pop    rsi
  40d219:	pop    rbx
  40d21a:	ret
  40d21b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  40d220:	jne    40d275 <__swc_fn_23cea7fa_000094_63c1827b+0x155>
  40d222:	mov    cl,BYTE PTR [rax+0x40]
  40d225:	rex cmp BYTE PTR [rdi+0x40],cl
  40d229:	je     40d240 <__swc_fn_23cea7fa_000094_63c1827b+0x120>
  40d22b:	xor    eax,eax
  40d22d:	add    rsp,0x120
  40d234:	pop    r15
  40d236:	pop    r14
  40d238:	pop    r13
  40d23a:	pop    r12
  40d23c:	pop    rdi
  40d23d:	pop    rsi
  40d23e:	pop    rbx
  40d23f:	ret
  40d240:	rex cmp BYTE PTR [rdi+0x40],0xd
  40d245:	je     40d25d <__swc_fn_23cea7fa_000094_63c1827b+0x13d>
  40d247:	rex cmp BYTE PTR [rdi+0x40],0xf
  40d24c:	sete   cl
  40d24f:	je     40d259 <__swc_fn_23cea7fa_000094_63c1827b+0x139>
  40d251:	rex cmp BYTE PTR [rdi+0x40],0xe
  40d256:	sete   cl
  40d259:	test   cl,cl
  40d25b:	je     40d275 <__swc_fn_23cea7fa_000094_63c1827b+0x155>
  40d25d:	mov    eax,0x1
  40d262:	add    rsp,0x120
  40d269:	pop    r15
  40d26b:	pop    r14
  40d26d:	pop    r13
  40d26f:	pop    r12
  40d271:	pop    rdi
  40d272:	pop    rsi
  40d273:	pop    rbx
  40d274:	ret
  40d275:	test   DWORD PTR [rdi+0x28],0x200200
  40d27c:	je     40d42f <__swc_fn_23cea7fa_000094_63c1827b+0x30f>
  40d282:	mov    rsi,QWORD PTR [rdi+0x88]
  40d289:	mov    rdi,QWORD PTR [rdi+0x90]
  40d290:	mov    r12,QWORD PTR [rax+0x88]
  40d297:	mov    rax,QWORD PTR [rax+0x90]
  40d29e:	cmp    rdi,rax
  40d2a1:	je     40d2b8 <__swc_fn_23cea7fa_000094_63c1827b+0x198>
  40d2a3:	xor    eax,eax
  40d2a5:	add    rsp,0x120
  40d2ac:	pop    r15
  40d2ae:	pop    r14
  40d2b0:	pop    r13
  40d2b2:	pop    r12
  40d2b4:	pop    rdi
  40d2b5:	pop    rsi
  40d2b6:	pop    rbx
  40d2b7:	ret
  40d2b8:	test   rsi,rsi
  40d2bb:	je     40d2c2 <__swc_fn_23cea7fa_000094_63c1827b+0x1a2>
  40d2bd:	test   r12,r12
  40d2c0:	jne    40d2da <__swc_fn_23cea7fa_000094_63c1827b+0x1ba>
  40d2c2:	mov    eax,0x1
  40d2c7:	add    rsp,0x120
  40d2ce:	pop    r15
  40d2d0:	pop    r14
  40d2d2:	pop    r13
  40d2d4:	pop    r12
  40d2d6:	pop    rdi
  40d2d7:	pop    rsi
  40d2d8:	pop    rbx
  40d2d9:	ret
  40d2da:	xor    r13d,r13d
  40d2dd:	test   rdi,rdi
  40d2e0:	jbe    40d417 <__swc_fn_23cea7fa_000094_63c1827b+0x2f7>
  40d2e6:	lea    r14,[rsp+0x78]
  40d2eb:	lea    r15,[rsp+0xb8]
  40d2f3:	cs nop WORD PTR [rax+rax*1+0x0]
  40d2fd:	cs nop WORD PTR [rax+rax*1+0x0]
  40d307:	nop    WORD PTR [rax+rax*1+0x0]
  40d310:	lea    rax,[r13*8+0x0]
  40d318:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40d31d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40d323:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  40d329:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40d332:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  40d338:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40d341:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  40d347:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40d350:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  40d356:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40d35f:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  40d366:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  40d36f:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  40d376:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  40d37f:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  40d386:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40d38f:	xor    al,al
  40d391:	rex test BYTE PTR [rsp+0xb0],0x1
  40d39a:	je     40d3a1 <__swc_fn_23cea7fa_000094_63c1827b+0x281>
  40d39c:	mov    eax,0x1
  40d3a1:	rex test BYTE PTR [rsp+0xf0],0x1
  40d3aa:	je     40d3b1 <__swc_fn_23cea7fa_000094_63c1827b+0x291>
  40d3ac:	mov    eax,0x1
  40d3b1:	test   al,al
  40d3b3:	jne    40d3d9 <__swc_fn_23cea7fa_000094_63c1827b+0x2b9>
  40d3b5:	mov    rcx,r14
  40d3b8:	mov    rdx,r15
  40d3bb:	call   40e930 <__swc_fn_23cea7fa_000151_6fb05988>
  40d3c0:	test   al,al
  40d3c2:	jne    40d3d9 <__swc_fn_23cea7fa_000094_63c1827b+0x2b9>
  40d3c4:	xor    eax,eax
  40d3c6:	add    rsp,0x120
  40d3cd:	pop    r15
  40d3cf:	pop    r14
  40d3d1:	pop    r13
  40d3d3:	pop    r12
  40d3d5:	pop    rdi
  40d3d6:	pop    rsi
  40d3d7:	pop    rbx
  40d3d8:	ret
  40d3d9:	mov    rcx,QWORD PTR [rsp+0x88]
  40d3e1:	mov    rdx,QWORD PTR [rsp+0xc8]
  40d3e9:	mov    r8d,ebx
  40d3ec:	call   40d120 <__swc_fn_23cea7fa_000094_63c1827b>
  40d3f1:	test   al,al
  40d3f3:	jne    40d40a <__swc_fn_23cea7fa_000094_63c1827b+0x2ea>
  40d3f5:	xor    eax,eax
  40d3f7:	add    rsp,0x120
  40d3fe:	pop    r15
  40d400:	pop    r14
  40d402:	pop    r13
  40d404:	pop    r12
  40d406:	pop    rdi
  40d407:	pop    rsi
  40d408:	pop    rbx
  40d409:	ret
  40d40a:	add    r13,0x1
  40d40e:	cmp    r13,rdi
  40d411:	jb     40d310 <__swc_fn_23cea7fa_000094_63c1827b+0x1f0>
  40d417:	mov    eax,0x1
  40d41c:	add    rsp,0x120
  40d423:	pop    r15
  40d425:	pop    r14
  40d427:	pop    r13
  40d429:	pop    r12
  40d42b:	pop    rdi
  40d42c:	pop    rsi
  40d42d:	pop    rbx
  40d42e:	ret
  40d42f:	test   bl,0x2
  40d432:	je     40d454 <__swc_fn_23cea7fa_000094_63c1827b+0x334>
  40d434:	lea    rcx,[rdi+0x10]
  40d438:	lea    rdx,[rax+0x10]
  40d43c:	call   40e930 <__swc_fn_23cea7fa_000151_6fb05988>
  40d441:	add    rsp,0x120
  40d448:	pop    r15
  40d44a:	pop    r14
  40d44c:	pop    r13
  40d44e:	pop    r12
  40d450:	pop    rdi
  40d451:	pop    rsi
  40d452:	pop    rbx
  40d453:	ret
  40d454:	mov    rcx,rdi
  40d457:	mov    rdx,rax
  40d45a:	call   40e930 <__swc_fn_23cea7fa_000151_6fb05988>
  40d45f:	add    rsp,0x120
  40d466:	pop    r15
  40d468:	pop    r14
  40d46a:	pop    r13
  40d46c:	pop    r12
  40d46e:	pop    rdi
  40d46f:	pop    rsi
  40d470:	pop    rbx
  40d471:	ret
	...

000000000040d480 <__swc_fn_23cea7fa_000097_4185993f>:
  40d480:	push   rbx
  40d481:	mov    rbx,rcx
  40d484:	call   410cd0 <__swc_fn_23cea7fa_000095_ad13d15c>
  40d489:	movzx  r11d,al
  40d48d:	mov    r8b,r11b
  40d490:	test   r8b,r8b
  40d493:	jne    40d4ad <__swc_fn_23cea7fa_000097_4185993f+0x2d>
  40d495:	mov    r11d,0x1
  40d49b:	mov    r10,rbx
  40d49e:	mov    r9,r11
  40d4a1:	and    r10,r11
  40d4a4:	test   r10,r10
  40d4a7:	setne  dl
  40d4aa:	mov    r8b,dl
  40d4ad:	mov    r10b,r8b
  40d4b0:	test   r10b,r10b
  40d4b3:	je     40d4b7 <__swc_fn_23cea7fa_000097_4185993f+0x37>
  40d4b5:	pop    rbx
  40d4b6:	ret
  40d4b7:	call   40a300 <__swc_fn_23cea7fa_000141_519fdf94>
  40d4bc:	movzx  r10d,al
  40d4c0:	test   r10b,r10b
  40d4c3:	je     40d4c7 <__swc_fn_23cea7fa_000097_4185993f+0x47>
  40d4c5:	pop    rbx
  40d4c6:	ret
  40d4c7:	lea    r10,[rip+0x5e1a]        # 4132e8 <__swc_rdata_base_23cea7fa+0x1d8>
  40d4ce:	mov    rax,r10
  40d4d1:	mov    rcx,rax
  40d4d4:	call   409e30 <__swc_fn_23cea7fa_000120_2648f149>
  40d4d9:	call   411550 <__swc_fn_23cea7fa_000122_be2e2f68>
  40d4de:	pop    rbx
  40d4df:	ret

000000000040d4e0 <__swc_fn_23cea7fa_000100_d4bdcaa4>:
  40d4e0:	push   rbx
  40d4e1:	sub    rsp,0x70
  40d4e5:	vxorps xmm0,xmm0,xmm0
  40d4e9:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40d4ef:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40d4f5:	vzeroupper
  40d4f8:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40d4fe:	mov    QWORD PTR [rsp+0x48],rdx
  40d503:	mov    rax,r8
  40d506:	cmp    r8,0x1
  40d50a:	mov    edx,0x1
  40d50f:	cmovb  rax,rdx
  40d513:	mov    QWORD PTR [rsp+0x50],rax
  40d518:	mov    rbx,QWORD PTR [rcx+0x8]
  40d51c:	mov    rbx,QWORD PTR [rbx+0x18]
  40d520:	mov    rcx,QWORD PTR [rcx]
  40d523:	lea    rdx,[rsp+0x8]
  40d528:	call   rbx
  40d52a:	add    rsp,0x70
  40d52e:	pop    rbx
  40d52f:	ret

000000000040d530 <__swc_fn_23cea7fa_000103_2fdd2c61>:
  40d530:	push   rbx
  40d531:	push   rsi
  40d532:	push   rdi
  40d533:	sub    rsp,0x30
  40d537:	mov    rbx,rcx
  40d53a:	test   rcx,rcx
  40d53d:	je     40d552 <__swc_fn_23cea7fa_000103_2fdd2c61+0x22>
  40d53f:	mov    rcx,rbx
  40d542:	mov    edx,0x1
  40d547:	call   40cd80 <__swc_fn_23cea7fa_000082_63a67586>
  40d54c:	cmp    rax,0x1
  40d550:	je     40d55a <__swc_fn_23cea7fa_000103_2fdd2c61+0x2a>
  40d552:	add    rsp,0x30
  40d556:	pop    rdi
  40d557:	pop    rsi
  40d558:	pop    rbx
  40d559:	ret
  40d55a:	lea    rsi,[rsp+0x8]
  40d55f:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40d564:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40d56a:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  40d56f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40d575:	mov    rax,QWORD PTR [rsp+0x20]
  40d57a:	test   rax,rax
  40d57d:	je     40d593 <__swc_fn_23cea7fa_000103_2fdd2c61+0x63>
  40d57f:	test   DWORD PTR [rax+0x28],0x400000
  40d586:	je     40d593 <__swc_fn_23cea7fa_000103_2fdd2c61+0x63>
  40d588:	mov    rcx,QWORD PTR [rax+0x30]
  40d58c:	test   rcx,rcx
  40d58f:	cmovne rax,rcx
  40d593:	mov    edi,DWORD PTR [rax+0x20]
  40d596:	lea    rcx,[rsp+0x18]
  40d59b:	call   410eb0 <__swc_fn_23cea7fa_000104_3c3b96fb>
  40d5a0:	mov    rcx,rsi
  40d5a3:	mov    rdx,QWORD PTR [rsp+0x18]
  40d5a8:	mov    r8,rdi
  40d5ab:	call   40d4e0 <__swc_fn_23cea7fa_000100_d4bdcaa4>
  40d5b0:	mov    rcx,QWORD PTR [rbx+0x28]
  40d5b4:	call   4093e0 <__swc_fn_23cea7fa_000102_e34f54dc>
  40d5b9:	mov    rcx,rsi
  40d5bc:	mov    rdx,rbx
  40d5bf:	mov    r8d,0x30
  40d5c5:	call   40d4e0 <__swc_fn_23cea7fa_000100_d4bdcaa4>
  40d5ca:	add    rsp,0x30
  40d5ce:	pop    rdi
  40d5cf:	pop    rsi
  40d5d0:	pop    rbx
  40d5d1:	ret
	...

000000000040d5e0 <__swc_fn_23cea7fa_000106_ffe51047>:
  40d5e0:	push   rbp
  40d5e1:	push   rbx
  40d5e2:	push   rsi
  40d5e3:	push   rdi
  40d5e4:	push   r12
  40d5e6:	push   r13
  40d5e8:	push   r14
  40d5ea:	push   r15
  40d5ec:	sub    rsp,0x500
  40d5f3:	mov    rbp,rsp
  40d5f6:	mov    rbx,rsp
  40d5f9:	mov    rsi,rdx
  40d5fc:	mov    rdi,rcx
  40d5ff:	mov    rcx,QWORD PTR [rip+0x16a3a]        # 424040 <__swc_bss_base_23cea7fa>
  40d606:	test   rcx,rcx
  40d609:	jne    40d623 <__swc_fn_23cea7fa_000106_ffe51047+0x43>
  40d60b:	sub    rsp,0x8
  40d60f:	call   40ed20 <__swc_fn_23cea7fa_000169_994c8876>
  40d614:	add    rsp,0x8
  40d618:	lea    rcx,[rax+0x1]
  40d61c:	mov    QWORD PTR [rip+0x16a1d],rcx        # 424040 <__swc_bss_base_23cea7fa>
  40d623:	dec    rcx
  40d626:	sub    rsp,0x8
  40d62a:	call   40bbe0 <__swc_fn_23cea7fa_000171_360af05d>
  40d62f:	add    rsp,0x8
  40d633:	mov    r12,rax
  40d636:	mov    QWORD PTR [rsp+0x4f0],rax
  40d63e:	lea    rax,[rip+0x5de3]        # 413428 <__swc_rdata_base_23cea7fa+0x318>
  40d645:	sub    rsp,0x20
  40d649:	mov    rcx,rsp
  40d64c:	mov    QWORD PTR [rcx],rax
  40d64f:	lea    r13,[rip+0x5ada]        # 413130 <__swc_rdata_base_23cea7fa+0x20>
  40d656:	mov    QWORD PTR [rcx+0x8],r13
  40d65a:	mov    QWORD PTR [rcx+0x10],rsp
  40d65e:	mov    QWORD PTR [rcx+0x18],0x1
  40d666:	lea    rcx,[rsp+0x10]
  40d66b:	sub    rsp,0x8
  40d66f:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  40d674:	add    rsp,0x8
  40d678:	add    rsp,0x20
  40d67c:	lea    rax,[rip+0x5db5]        # 413438 <__swc_rdata_base_23cea7fa+0x328>
  40d683:	sub    rsp,0x20
  40d687:	mov    rcx,rsp
  40d68a:	mov    QWORD PTR [rcx],rax
  40d68d:	mov    QWORD PTR [rcx+0x8],r13
  40d691:	mov    QWORD PTR [rcx+0x10],rsp
  40d695:	mov    QWORD PTR [rcx+0x18],0x1
  40d69d:	lea    rcx,[rsp+0x10]
  40d6a2:	sub    rsp,0x8
  40d6a6:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  40d6ab:	add    rsp,0x8
  40d6af:	add    rsp,0x20
  40d6b3:	lea    r14,[rip+0x5a66]        # 413120 <__swc_rdata_base_23cea7fa+0x10>
  40d6ba:	sub    rsp,0x50
  40d6be:	mov    rax,rsp
  40d6c1:	vmovups xmm0,XMMWORD PTR [rip+0x5ea7]        # 413570 <__swc_rdata_base_23cea7fa+0x460>
  40d6c9:	vmovups XMMWORD PTR [rax],xmm0
  40d6cd:	mov    QWORD PTR [rax+0x10],rsp
  40d6d1:	mov    QWORD PTR [rax+0x18],r13
  40d6d5:	mov    QWORD PTR [rax+0x20],rdi
  40d6d9:	lea    rdi,[rip+0x5d68]        # 413448 <__swc_rdata_base_23cea7fa+0x338>
  40d6e0:	mov    QWORD PTR [rax+0x28],rdi
  40d6e4:	mov    QWORD PTR [rax+0x30],r14
  40d6e8:	mov    QWORD PTR [rax+0x38],r13
  40d6ec:	lea    rcx,[rsp+0x10]
  40d6f1:	mov    QWORD PTR [rax+0x40],rcx
  40d6f5:	mov    QWORD PTR [rax+0x48],0x3
  40d6fd:	lea    rcx,[rsp+0x40]
  40d702:	sub    rsp,0x8
  40d706:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  40d70b:	add    rsp,0x8
  40d70f:	add    rsp,0x50
  40d713:	lea    rax,[rip+0x5d76]        # 413490 <__swc_rdata_base_23cea7fa+0x380>
  40d71a:	sub    rsp,0x20
  40d71e:	mov    rcx,rsp
  40d721:	mov    QWORD PTR [rcx],rax
  40d724:	mov    QWORD PTR [rcx+0x8],r13
  40d728:	mov    QWORD PTR [rcx+0x10],rsp
  40d72c:	mov    QWORD PTR [rcx+0x18],0x1
  40d734:	lea    rcx,[rsp+0x10]
  40d739:	sub    rsp,0x8
  40d73d:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  40d742:	add    rsp,0x8
  40d746:	add    rsp,0x20
  40d74a:	mov    eax,DWORD PTR [rsi+0x20]
  40d74d:	mov    ecx,DWORD PTR [rsi+0x24]
  40d750:	sub    rsp,0xa0
  40d757:	mov    rdx,rsp
  40d75a:	mov    QWORD PTR [rdx+0x30],rsi
  40d75e:	mov    QWORD PTR [rdx+0x38],rdi
  40d762:	vmovups xmm0,XMMWORD PTR [rip+0x5d9e]        # 413508 <__swc_rdata_base_23cea7fa+0x3f8>
  40d76a:	vmovups XMMWORD PTR [rdx],xmm0
  40d76e:	mov    QWORD PTR [rdx+0x40],rsp
  40d772:	mov    QWORD PTR [rdx+0x48],r13
  40d776:	mov    DWORD PTR [rdx+0x10],eax
  40d779:	lea    rax,[rsp+0x10]
  40d77e:	mov    QWORD PTR [rdx+0x50],rax
  40d782:	lea    rax,[rip+0x5d17]        # 4134a0 <__swc_rdata_base_23cea7fa+0x390>
  40d789:	mov    QWORD PTR [rdx+0x58],rax
  40d78d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  40d792:	lea    r8,[rsp+0x18]
  40d797:	mov    QWORD PTR [rdx+0x60],r8
  40d79b:	mov    QWORD PTR [rdx+0x68],r13
  40d79f:	mov    DWORD PTR [rdx+0x28],ecx
  40d7a2:	lea    rcx,[rdx+0x28]
  40d7a6:	mov    QWORD PTR [rdx+0x70],rcx
  40d7aa:	mov    QWORD PTR [rdx+0x78],rax
  40d7ae:	mov    QWORD PTR [rdx+0x80],r14
  40d7b5:	mov    QWORD PTR [rdx+0x88],r13
  40d7bc:	lea    rax,[rdx+0x30]
  40d7c0:	mov    QWORD PTR [rdx+0x90],rax
  40d7c7:	mov    QWORD PTR [rdx+0x98],0x6
  40d7d2:	lea    rcx,[rdx+0x90]
  40d7d9:	sub    rsp,0x8
  40d7dd:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  40d7e2:	add    rsp,0x8
  40d7e6:	add    rsp,0xa0
  40d7ed:	sub    rsp,0x20
  40d7f1:	mov    rax,rsp
  40d7f4:	mov    QWORD PTR [rax],r14
  40d7f7:	mov    QWORD PTR [rax+0x8],r13
  40d7fb:	mov    QWORD PTR [rax+0x10],rsp
  40d7ff:	mov    QWORD PTR [rax+0x18],0x1
  40d807:	lea    rcx,[rsp+0x10]
  40d80c:	sub    rsp,0x8
  40d810:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  40d815:	add    rsp,0x8
  40d819:	add    rsp,0x20
  40d81d:	mov    eax,DWORD PTR [r12+0x9ac]
  40d825:	test   eax,eax
  40d827:	je     40da60 <__swc_fn_23cea7fa_000106_ffe51047+0x480>
  40d82d:	lea    rax,[rip+0x5cb4]        # 4134e8 <__swc_rdata_base_23cea7fa+0x3d8>
  40d834:	sub    rsp,0x20
  40d838:	mov    rcx,rsp
  40d83b:	mov    QWORD PTR [rcx],rax
  40d83e:	mov    QWORD PTR [rcx+0x8],r13
  40d842:	mov    QWORD PTR [rcx+0x10],rsp
  40d846:	mov    QWORD PTR [rcx+0x18],0x1
  40d84e:	lea    rcx,[rsp+0x10]
  40d853:	sub    rsp,0x8
  40d857:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  40d85c:	add    rsp,0x8
  40d860:	add    rsp,0x20
  40d864:	mov    eax,DWORD PTR [r12+0x9ac]
  40d86c:	dec    eax
  40d86e:	mov    esi,eax
  40d870:	test   esi,esi
  40d872:	jl     40da30 <__swc_fn_23cea7fa_000106_ffe51047+0x450>
  40d878:	jmp    40d884 <__swc_fn_23cea7fa_000106_ffe51047+0x2a4>
  40d87a:	nop    WORD PTR [rax+rax*1+0x0]
  40d880:	dec    esi
  40d882:	jmp    40d870 <__swc_fn_23cea7fa_000106_ffe51047+0x290>
  40d884:	lea    rax,[rip+0x5c6d]        # 4134f8 <__swc_rdata_base_23cea7fa+0x3e8>
  40d88b:	sub    rsp,0x20
  40d88f:	mov    rcx,rsp
  40d892:	mov    QWORD PTR [rcx],rax
  40d895:	mov    QWORD PTR [rcx+0x8],r13
  40d899:	mov    QWORD PTR [rcx+0x10],rsp
  40d89d:	mov    QWORD PTR [rcx+0x18],0x1
  40d8a5:	lea    rcx,[rsp+0x10]
  40d8aa:	sub    rsp,0x8
  40d8ae:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  40d8b3:	add    rsp,0x8
  40d8b7:	add    rsp,0x20
  40d8bb:	movsxd rax,esi
  40d8be:	imul   r15,rax,0x30
  40d8c2:	add    r15,r12
  40d8c5:	add    r15,0xf8
  40d8cc:	sub    rsp,0x20
  40d8d0:	mov    rax,rsp
  40d8d3:	mov    QWORD PTR [rax],r15
  40d8d6:	mov    QWORD PTR [rax+0x8],rdi
  40d8da:	mov    QWORD PTR [rax+0x10],rsp
  40d8de:	mov    QWORD PTR [rax+0x18],0x1
  40d8e6:	lea    rcx,[rsp+0x10]
  40d8eb:	sub    rsp,0x8
  40d8ef:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  40d8f4:	add    rsp,0x8
  40d8f8:	add    rsp,0x20
  40d8fc:	mov    QWORD PTR [rsp+0x4f8],rsi
  40d904:	lea    rsi,[rip+0x5bfd]        # 413508 <__swc_rdata_base_23cea7fa+0x3f8>
  40d90b:	sub    rsp,0x20
  40d90f:	mov    rax,rsp
  40d912:	mov    QWORD PTR [rax],rsi
  40d915:	mov    QWORD PTR [rax+0x8],r13
  40d919:	mov    QWORD PTR [rax+0x10],rsp
  40d91d:	mov    QWORD PTR [rax+0x18],0x1
  40d925:	lea    rcx,[rsp+0x10]
  40d92a:	sub    rsp,0x8
  40d92e:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  40d933:	add    rsp,0x8
  40d937:	add    rsp,0x20
  40d93b:	sub    rsp,0x30
  40d93f:	mov    rax,rsp
  40d942:	mov    ecx,DWORD PTR [r15+0x20]
  40d946:	mov    QWORD PTR [rax],rcx
  40d949:	mov    QWORD PTR [rax+0x8],rsp
  40d94d:	lea    rdi,[rip+0x5bc4]        # 413518 <__swc_rdata_base_23cea7fa+0x408>
  40d954:	mov    QWORD PTR [rax+0x10],rdi
  40d958:	lea    rcx,[rsp+0x8]
  40d95d:	mov    QWORD PTR [rax+0x18],rcx
  40d961:	mov    QWORD PTR [rax+0x20],0x1
  40d969:	lea    rcx,[rsp+0x18]
  40d96e:	sub    rsp,0x8
  40d972:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  40d977:	add    rsp,0x8
  40d97b:	add    rsp,0x30
  40d97f:	sub    rsp,0x20
  40d983:	mov    rax,rsp
  40d986:	mov    QWORD PTR [rax],rsi
  40d989:	mov    QWORD PTR [rax+0x8],r13
  40d98d:	mov    QWORD PTR [rax+0x10],rsp
  40d991:	mov    QWORD PTR [rax+0x18],0x1
  40d999:	lea    rcx,[rsp+0x10]
  40d99e:	sub    rsp,0x8
  40d9a2:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  40d9a7:	add    rsp,0x8
  40d9ab:	add    rsp,0x20
  40d9af:	sub    rsp,0x30
  40d9b3:	mov    rax,rsp
  40d9b6:	mov    ecx,DWORD PTR [r15+0x24]
  40d9ba:	mov    QWORD PTR [rax],rcx
  40d9bd:	mov    QWORD PTR [rax+0x8],rsp
  40d9c1:	mov    QWORD PTR [rax+0x10],rdi
  40d9c5:	lea    rcx,[rsp+0x8]
  40d9ca:	mov    QWORD PTR [rax+0x18],rcx
  40d9ce:	mov    QWORD PTR [rax+0x20],0x1
  40d9d6:	lea    rcx,[rsp+0x18]
  40d9db:	sub    rsp,0x8
  40d9df:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  40d9e4:	add    rsp,0x8
  40d9e8:	add    rsp,0x30
  40d9ec:	sub    rsp,0x20
  40d9f0:	mov    rax,rsp
  40d9f3:	mov    QWORD PTR [rax],r14
  40d9f6:	mov    QWORD PTR [rax+0x8],r13
  40d9fa:	mov    QWORD PTR [rax+0x10],rsp
  40d9fe:	mov    QWORD PTR [rax+0x18],0x1
  40da06:	lea    rcx,[rsp+0x10]
  40da0b:	sub    rsp,0x8
  40da0f:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  40da14:	add    rsp,0x8
  40da18:	add    rsp,0x20
  40da1c:	lea    rdi,[rip+0x5a25]        # 413448 <__swc_rdata_base_23cea7fa+0x338>
  40da23:	mov    rsi,QWORD PTR [rsp+0x4f8]
  40da2b:	jmp    40d880 <__swc_fn_23cea7fa_000106_ffe51047+0x2a0>
  40da30:	sub    rsp,0x20
  40da34:	mov    rax,rsp
  40da37:	mov    QWORD PTR [rax],r14
  40da3a:	mov    QWORD PTR [rax+0x8],r13
  40da3e:	mov    QWORD PTR [rax+0x10],rsp
  40da42:	mov    QWORD PTR [rax+0x18],0x1
  40da4a:	lea    rcx,[rsp+0x10]
  40da4f:	sub    rsp,0x8
  40da53:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  40da58:	add    rsp,0x8
  40da5c:	add    rsp,0x20
  40da60:	lea    rax,[rbx+0x28]
  40da64:	mov    rcx,rax
  40da67:	mov    QWORD PTR [rbx+0x28],0x0
  40da6f:	mov    QWORD PTR [rbx+0x30],0x0
  40da77:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  40da7c:	add    rcx,0x10
  40da80:	mov    edx,0x1f
  40da85:	cs nop WORD PTR [rax+rax*1+0x0]
  40da8f:	nop
  40da90:	vmovups XMMWORD PTR [rcx],xmm0
  40da94:	add    rcx,0x10
  40da98:	sub    rdx,0x1
  40da9c:	jne    40da90 <__swc_fn_23cea7fa_000106_ffe51047+0x4b0>
  40da9e:	lea    rsi,[rbx+0x228]
  40daa5:	xor    ecx,ecx
  40daa7:	cs nop WORD PTR [rax+rax*1+0x0]
  40dab1:	cs nop WORD PTR [rax+rax*1+0x0]
  40dabb:	nop    DWORD PTR [rax+rax*1+0x0]
  40dac0:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  40dac5:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  40daca:	add    rcx,0x10
  40dace:	cmp    rcx,0x200
  40dad5:	jne    40dac0 <__swc_fn_23cea7fa_000106_ffe51047+0x4e0>
  40dad7:	mov    eax,DWORD PTR [r12+0xbc8]
  40dadf:	lea    rcx,[r12+0x9c8]
  40dae7:	mov    QWORD PTR [rbx+0x428],rcx
  40daee:	mov    QWORD PTR [rbx+0x430],rax
  40daf5:	lea    rdi,[rbx+0x438]
  40dafc:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  40db04:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  40db0c:	mov    eax,DWORD PTR [r12+0xbc8]
  40db14:	test   eax,eax
  40db16:	jne    40db63 <__swc_fn_23cea7fa_000106_ffe51047+0x583>
  40db18:	lea    rax,[rbx+0x448]
  40db1f:	mov    QWORD PTR [rbx+0x448],rsi
  40db26:	mov    QWORD PTR [rax+0x8],0x40
  40db2e:	mov    ecx,0x1
  40db33:	mov    rdx,rax
  40db36:	sub    rsp,0x8
  40db3a:	call   409f40 <__swc_fn_23cea7fa_000123_4f256d58>
  40db3f:	add    rsp,0x8
  40db43:	mov    QWORD PTR [rbx+0x460],rsi
  40db4a:	mov    ecx,eax
  40db4c:	mov    QWORD PTR [rbx+0x468],rcx
  40db53:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  40db5b:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  40db63:	mov    rsi,QWORD PTR [rbx+0x438]
  40db6a:	mov    rax,QWORD PTR [rbx+0x440]
  40db71:	mov    r15,rax
  40db74:	xor    r12d,r12d
  40db77:	test   r15,r15
  40db7a:	je     40dc30 <__swc_fn_23cea7fa_000106_ffe51047+0x650>
  40db80:	mov    rax,QWORD PTR [rsi+r12*8]
  40db84:	test   rax,rax
  40db87:	je     40dba6 <__swc_fn_23cea7fa_000106_ffe51047+0x5c6>
  40db89:	lea    rcx,[rbx+0x4b8]
  40db90:	mov    rdx,rax
  40db93:	sub    rsp,0x8
  40db97:	call   40ea90 <__swc_fn_23cea7fa_000166_cc119975>
  40db9c:	add    rsp,0x8
  40dba0:	mov    al,BYTE PTR [rax]
  40dba2:	test   al,al
  40dba4:	jne    40dbb2 <__swc_fn_23cea7fa_000106_ffe51047+0x5d2>
  40dba6:	add    r12,0x1
  40dbaa:	sub    r15,0x1
  40dbae:	jne    40db80 <__swc_fn_23cea7fa_000106_ffe51047+0x5a0>
  40dbb0:	jmp    40dc30 <__swc_fn_23cea7fa_000106_ffe51047+0x650>
  40dbb2:	lea    rax,[rip+0x59a7]        # 413560 <__swc_rdata_base_23cea7fa+0x450>
  40dbb9:	sub    rsp,0x20
  40dbbd:	mov    rcx,rsp
  40dbc0:	mov    QWORD PTR [rcx],rax
  40dbc3:	mov    QWORD PTR [rcx+0x8],r13
  40dbc7:	mov    QWORD PTR [rcx+0x10],rsp
  40dbcb:	mov    QWORD PTR [rcx+0x18],0x1
  40dbd3:	lea    rcx,[rsp+0x10]
  40dbd8:	sub    rsp,0x8
  40dbdc:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  40dbe1:	add    rsp,0x8
  40dbe5:	add    rsp,0x20
  40dbe9:	mov    rcx,rdi
  40dbec:	xor    edx,edx
  40dbee:	mov    al,0x1
  40dbf0:	mov    r8,rax
  40dbf3:	sub    rsp,0x8
  40dbf7:	call   411de0 <__swc_fn_23cea7fa_000167_bcc835b8>
  40dbfc:	add    rsp,0x8
  40dc00:	sub    rsp,0x20
  40dc04:	mov    rax,rsp
  40dc07:	mov    QWORD PTR [rax],r14
  40dc0a:	mov    QWORD PTR [rax+0x8],r13
  40dc0e:	mov    QWORD PTR [rax+0x10],rsp
  40dc12:	mov    QWORD PTR [rax+0x18],0x1
  40dc1a:	lea    rcx,[rsp+0x10]
  40dc1f:	sub    rsp,0x8
  40dc23:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  40dc28:	add    rsp,0x8
  40dc2c:	add    rsp,0x20
  40dc30:	mov    r12,QWORD PTR [rsp+0x4f0]
  40dc38:	mov    DWORD PTR [r12+0xbc8],0x0
  40dc44:	add    rsp,0x500
  40dc4b:	pop    r15
  40dc4d:	pop    r14
  40dc4f:	pop    r13
  40dc51:	pop    r12
  40dc53:	pop    rdi
  40dc54:	pop    rsi
  40dc55:	pop    rbx
  40dc56:	pop    rbp
  40dc57:	ret
	...

000000000040dc60 <__swc_fn_23cea7fa_000109_7c204aac>:
  40dc60:	sub    rsp,0x8
  40dc64:	test   r8,r8
  40dc67:	je     40dc6e <__swc_fn_23cea7fa_000109_7c204aac+0xe>
  40dc69:	call   409670 <__swc_fn_23cea7fa_000108_c51c3158>
  40dc6e:	add    rsp,0x8
  40dc72:	ret
	...

000000000040dc80 <__swc_fn_23cea7fa_000112_126150d1>:
  40dc80:	push   rsi
  40dc81:	push   rdi
  40dc82:	push   r12
  40dc84:	push   r13
  40dc86:	sub    rsp,0xd8
  40dc8d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40dc93:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40dc99:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40dc9f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40dca5:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40dcab:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40dcb4:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40dcbd:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40dcc6:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40dccf:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40dcd8:	xor    eax,eax
  40dcda:	call   407050 <getpid@plt>
  40dcdf:	mov    rsi,rax
  40dce2:	lea    rdi,[rip+0x19057]        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  40dce9:	mov    r12,QWORD PTR [rdi]
  40dcec:	test   r12,r12
  40dcef:	je     40dcfd <__swc_fn_23cea7fa_000112_126150d1+0x7d>
  40dcf1:	cmp    DWORD PTR [r12+0x10],esi
  40dcf6:	jne    40dcfd <__swc_fn_23cea7fa_000112_126150d1+0x7d>
  40dcf8:	mov    rax,r12
  40dcfb:	jmp    40dd60 <__swc_fn_23cea7fa_000112_126150d1+0xe0>
  40dcfd:	mov    ecx,0x4
  40dd02:	mov    edx,0x18
  40dd07:	call   409750 <__swc_fn_23cea7fa_000111_6814119b>
  40dd0c:	mov    rcx,rax
  40dd0f:	test   rax,rax
  40dd12:	jne    40dd18 <__swc_fn_23cea7fa_000112_126150d1+0x98>
  40dd14:	xor    eax,eax
  40dd16:	jmp    40dd60 <__swc_fn_23cea7fa_000112_126150d1+0xe0>
  40dd18:	mov    DWORD PTR [rcx+0x10],esi
  40dd1b:	mov    rax,r12
  40dd1e:	lock cmpxchg QWORD PTR [rdi],rcx
  40dd23:	mov    r13,rax
  40dd26:	cmp    rax,r12
  40dd29:	je     40dd3f <__swc_fn_23cea7fa_000112_126150d1+0xbf>
  40dd2b:	mov    rdi,rcx
  40dd2e:	mov    esi,0x18
  40dd33:	xor    eax,eax
  40dd35:	call   407160 <munmap@plt>
  40dd3a:	mov    rax,r13
  40dd3d:	jmp    40dd60 <__swc_fn_23cea7fa_000112_126150d1+0xe0>
  40dd3f:	test   r12,r12
  40dd42:	je     40dd5d <__swc_fn_23cea7fa_000112_126150d1+0xdd>
  40dd44:	mov    rdi,r12
  40dd47:	mov    esi,0x18
  40dd4c:	xor    eax,eax
  40dd4e:	mov    QWORD PTR [rsp+0x28],rcx
  40dd53:	call   407160 <munmap@plt>
  40dd58:	mov    rcx,QWORD PTR [rsp+0x28]
  40dd5d:	mov    rax,rcx
  40dd60:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40dd66:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40dd6c:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40dd72:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40dd78:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40dd7e:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40dd87:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40dd90:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40dd99:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40dda2:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40ddab:	add    rsp,0xd8
  40ddb2:	pop    r13
  40ddb4:	pop    r12
  40ddb6:	pop    rdi
  40ddb7:	pop    rsi
  40ddb8:	ret
  40ddb9:	add    BYTE PTR [rax],al
  40ddbb:	add    BYTE PTR [rax],al
  40ddbd:	add    BYTE PTR [rax],al
	...

000000000040ddc0 <__swc_fn_23cea7fa_000115_36905703>:
  40ddc0:	push   rbx
  40ddc1:	push   r12
  40ddc3:	push   rdi
  40ddc4:	push   rsi
  40ddc5:	sub    rsp,0xa8
  40ddcc:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ddd2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ddd8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ddde:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40dde4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40ddea:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40ddf0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ddf6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ddfc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40de05:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40de0e:	mov    rbx,rdx
  40de11:	mov    r12,rcx
  40de14:	mov    rdi,rcx
  40de17:	mov    rsi,rdx
  40de1a:	mov    edx,0x3
  40de1f:	xor    eax,eax
  40de21:	call   407170 <mprotect@plt>
  40de26:	test   eax,eax
  40de28:	je     40de2e <__swc_fn_23cea7fa_000115_36905703+0x6e>
  40de2a:	xor    eax,eax
  40de2c:	jmp    40de43 <__swc_fn_23cea7fa_000115_36905703+0x83>
  40de2e:	mov    rcx,r12
  40de31:	mov    rdx,rbx
  40de34:	mov    al,0x1
  40de36:	mov    r8,rax
  40de39:	call   409d80 <__swc_fn_23cea7fa_000114_5f48311c>
  40de3e:	mov    eax,0x1
  40de43:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40de49:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40de4f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40de55:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40de5b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40de61:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40de67:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40de6d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40de73:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40de7c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40de85:	add    rsp,0xa8
  40de8c:	pop    rsi
  40de8d:	pop    rdi
  40de8e:	pop    r12
  40de90:	pop    rbx
  40de91:	ret
	...

000000000040dea0 <__swc_fn_23cea7fa_000118_5208f471>:
  40dea0:	sub    rsp,0x8
  40dea4:	test   rcx,rcx
  40dea7:	jne    40deae <__swc_fn_23cea7fa_000118_5208f471+0xe>
  40dea9:	add    rsp,0x8
  40dead:	ret
  40deae:	call   411400 <__swc_fn_23cea7fa_000119_d3318640>
  40deb3:	add    rsp,0x8
  40deb7:	ret
	...

000000000040dec0 <__swc_fn_23cea7fa_000121_0a5fa85a>:
  40dec0:	push   rdi
  40dec1:	push   rsi
  40dec2:	sub    rsp,0xa8
  40dec9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40decf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ded5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40dedb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40dee1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40dee7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40deed:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40def3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40def9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40df02:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40df0b:	xor    edi,edi
  40df0d:	xor    eax,eax
  40df0f:	call   407180 <exit@plt>
  40df14:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40df1a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40df20:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40df26:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40df2c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40df32:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40df38:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40df3e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40df44:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40df4d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40df56:	add    rsp,0xa8
  40df5d:	pop    rsi
  40df5e:	pop    rdi
  40df5f:	ret

000000000040df60 <__swc_fn_23cea7fa_000124_83db7238>:
  40df60:	push   rbx
  40df61:	push   rsi
  40df62:	push   rdi
  40df63:	push   r12
  40df65:	sub    rsp,0x18
  40df69:	mov    rbx,r8
  40df6c:	mov    rsi,rcx
  40df6f:	mov    rdi,rdx
  40df72:	mov    rcx,QWORD PTR [rip+0x160c7]        # 424040 <__swc_bss_base_23cea7fa>
  40df79:	test   rcx,rcx
  40df7c:	jne    40df8e <__swc_fn_23cea7fa_000124_83db7238+0x2e>
  40df7e:	call   40ed20 <__swc_fn_23cea7fa_000169_994c8876>
  40df83:	lea    rcx,[rax+0x1]
  40df87:	mov    QWORD PTR [rip+0x160b2],rcx        # 424040 <__swc_bss_base_23cea7fa>
  40df8e:	dec    rcx
  40df91:	call   40bbe0 <__swc_fn_23cea7fa_000171_360af05d>
  40df96:	mov    r12,rax
  40df99:	cmp    ebx,0x3
  40df9c:	jne    40dfaf <__swc_fn_23cea7fa_000124_83db7238+0x4f>
  40df9e:	mov    rax,QWORD PTR [r12+0xbd0]
  40dfa6:	test   rax,rax
  40dfa9:	jne    40e0ec <__swc_fn_23cea7fa_000124_83db7238+0x18c>
  40dfaf:	cmp    ebx,0x5
  40dfb2:	jne    40dfd6 <__swc_fn_23cea7fa_000124_83db7238+0x76>
  40dfb4:	call   410cd0 <__swc_fn_23cea7fa_000095_ad13d15c>
  40dfb9:	test   al,al
  40dfbb:	jne    40dfd6 <__swc_fn_23cea7fa_000124_83db7238+0x76>
  40dfbd:	mov    rcx,rsi
  40dfc0:	mov    rdx,rdi
  40dfc3:	call   40bb90 <__swc_fn_23cea7fa_000168_3459066f>
  40dfc8:	test   al,al
  40dfca:	je     40dfd6 <__swc_fn_23cea7fa_000124_83db7238+0x76>
  40dfcc:	add    rsp,0x18
  40dfd0:	pop    r12
  40dfd2:	pop    rdi
  40dfd3:	pop    rsi
  40dfd4:	pop    rbx
  40dfd5:	ret
  40dfd6:	call   410cd0 <__swc_fn_23cea7fa_000095_ad13d15c>
  40dfdb:	test   al,al
  40dfdd:	jne    40e04f <__swc_fn_23cea7fa_000124_83db7238+0xef>
  40dfdf:	vmovups xmm0,XMMWORD PTR [rsi]
  40dfe3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dfe9:	mov    rax,QWORD PTR [rsp+0x8]
  40dfee:	test   rax,rax
  40dff1:	jne    40e042 <__swc_fn_23cea7fa_000124_83db7238+0xe2>
  40dff3:	cmp    ebx,0x3
  40dff6:	je     40e004 <__swc_fn_23cea7fa_000124_83db7238+0xa4>
  40dff8:	cmp    ebx,0x4
  40dffb:	je     40e014 <__swc_fn_23cea7fa_000124_83db7238+0xb4>
  40dffd:	cmp    ebx,0x5
  40e000:	je     40e024 <__swc_fn_23cea7fa_000124_83db7238+0xc4>
  40e002:	jmp    40e034 <__swc_fn_23cea7fa_000124_83db7238+0xd4>
  40e004:	vmovups xmm0,XMMWORD PTR [rip+0x55a4]        # 4135b0 <__swc_rdata_base_23cea7fa+0x4a0>
  40e00c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e012:	jmp    40e042 <__swc_fn_23cea7fa_000124_83db7238+0xe2>
  40e014:	vmovups xmm0,XMMWORD PTR [rip+0x55a4]        # 4135c0 <__swc_rdata_base_23cea7fa+0x4b0>
  40e01c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e022:	jmp    40e042 <__swc_fn_23cea7fa_000124_83db7238+0xe2>
  40e024:	vmovups xmm0,XMMWORD PTR [rip+0x55a4]        # 4135d0 <__swc_rdata_base_23cea7fa+0x4c0>
  40e02c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e032:	jmp    40e042 <__swc_fn_23cea7fa_000124_83db7238+0xe2>
  40e034:	vmovups xmm0,XMMWORD PTR [rip+0x55a4]        # 4135e0 <__swc_rdata_base_23cea7fa+0x4d0>
  40e03c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e042:	lea    rcx,[rsp+0x8]
  40e047:	mov    rdx,rdi
  40e04a:	call   410f20 <__swc_fn_23cea7fa_000107_90faaa26>
  40e04f:	vmovups xmm0,XMMWORD PTR [rdi]
  40e053:	vmovups XMMWORD PTR [r12+0x940],xmm0
  40e05d:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  40e062:	vmovups XMMWORD PTR [r12+0x950],xmm0
  40e06c:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  40e071:	vmovups XMMWORD PTR [r12+0x960],xmm0
  40e07b:	lea    rax,[r12+0x940]
  40e083:	mov    QWORD PTR [r12+0x970],rax
  40e08b:	mov    rax,QWORD PTR [rsi]
  40e08e:	mov    QWORD PTR [r12+0x978],rax
  40e096:	mov    rax,QWORD PTR [rsi+0x8]
  40e09a:	mov    QWORD PTR [r12+0x980],rax
  40e0a2:	movsxd rax,ebx
  40e0a5:	mov    QWORD PTR [r12+0x988],rax
  40e0ad:	cmp    ebx,0x5
  40e0b0:	je     40e0b9 <__swc_fn_23cea7fa_000124_83db7238+0x159>
  40e0b2:	xor    ecx,ecx
  40e0b4:	call   40ee50 <__swc_fn_23cea7fa_000178_718d7b54>
  40e0b9:	mov    rbx,QWORD PTR [r12+0xbe8]
  40e0c1:	test   rbx,rbx
  40e0c4:	je     40e0d5 <__swc_fn_23cea7fa_000124_83db7238+0x175>
  40e0c6:	mov    rcx,r12
  40e0c9:	call   rbx
  40e0cb:	add    rsp,0x18
  40e0cf:	pop    r12
  40e0d1:	pop    rdi
  40e0d2:	pop    rsi
  40e0d3:	pop    rbx
  40e0d4:	ret
  40e0d5:	mov    rcx,rsi
  40e0d8:	call   409e30 <__swc_fn_23cea7fa_000120_2648f149>
  40e0dd:	call   411550 <__swc_fn_23cea7fa_000122_be2e2f68>
  40e0e2:	add    rsp,0x18
  40e0e6:	pop    r12
  40e0e8:	pop    rdi
  40e0e9:	pop    rsi
  40e0ea:	pop    rbx
  40e0eb:	ret
  40e0ec:	mov    rcx,rsi
  40e0ef:	mov    rdx,rdi
  40e0f2:	call   410f20 <__swc_fn_23cea7fa_000107_90faaa26>
  40e0f7:	jmp    40dfaf <__swc_fn_23cea7fa_000124_83db7238+0x4f>
  40e0fc:	add    BYTE PTR [rax],al
	...

000000000040e100 <__swc_fn_23cea7fa_000127_58f0f391>:
  40e100:	push   rdi
  40e101:	push   rsi
  40e102:	sub    rsp,0xb8
  40e109:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40e10f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40e115:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40e11b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40e121:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40e127:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40e12d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40e133:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40e13c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40e145:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40e14e:	mov    DWORD PTR [rsp+0x8],0x0
  40e156:	lea    rdi,[rsp+0x8]
  40e15b:	xor    esi,esi
  40e15d:	xor    eax,eax
  40e15f:	call   407190 <pthread_key_create@plt>
  40e164:	test   eax,eax
  40e166:	jne    40e16e <__swc_fn_23cea7fa_000127_58f0f391+0x6e>
  40e168:	mov    eax,DWORD PTR [rsp+0x8]
  40e16c:	jmp    40e175 <__swc_fn_23cea7fa_000127_58f0f391+0x75>
  40e16e:	mov    rax,0xffffffffffffffff
  40e175:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40e17b:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40e181:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40e187:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40e18d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40e193:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40e199:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40e19f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40e1a8:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40e1b1:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40e1ba:	add    rsp,0xb8
  40e1c1:	pop    rsi
  40e1c2:	pop    rdi
  40e1c3:	ret
	...

000000000040e1d0 <__swc_fn_23cea7fa_000130_4a82cdf6>:
  40e1d0:	push   rdi
  40e1d1:	push   rsi
  40e1d2:	sub    rsp,0xb8
  40e1d9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40e1df:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40e1e5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40e1eb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40e1f1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40e1f7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40e1fd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40e203:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40e20c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40e215:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40e21e:	mov    DWORD PTR [rsp+0x8],0x0
  40e226:	lea    rdi,[rsp+0x8]
  40e22b:	mov    rsi,rcx
  40e22e:	xor    eax,eax
  40e230:	call   407190 <pthread_key_create@plt>
  40e235:	test   eax,eax
  40e237:	jne    40e242 <__swc_fn_23cea7fa_000130_4a82cdf6+0x72>
  40e239:	mov    eax,DWORD PTR [rsp+0x8]
  40e23d:	inc    rax
  40e240:	jmp    40e244 <__swc_fn_23cea7fa_000130_4a82cdf6+0x74>
  40e242:	xor    eax,eax
  40e244:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40e24a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40e250:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40e256:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40e25c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40e262:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40e268:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40e26e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40e277:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40e280:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40e289:	add    rsp,0xb8
  40e290:	pop    rsi
  40e291:	pop    rdi
  40e292:	ret
	...

000000000040e2a0 <__swc_fn_23cea7fa_000133_ae5891af>:
  40e2a0:	push   rdi
  40e2a1:	push   rsi
  40e2a2:	sub    rsp,0xa8
  40e2a9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e2af:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e2b5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e2bb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e2c1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e2c7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e2cd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e2d3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e2d9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e2e2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e2eb:	test   rcx,rcx
  40e2ee:	setne  al
  40e2f1:	je     40e30a <__swc_fn_23cea7fa_000133_ae5891af+0x6a>
  40e2f3:	lea    rax,[rcx-0x1]
  40e2f7:	mov    eax,eax
  40e2f9:	mov    edi,eax
  40e2fb:	mov    rsi,rdx
  40e2fe:	xor    eax,eax
  40e300:	call   407120 <pthread_setspecific@plt>
  40e305:	test   eax,eax
  40e307:	sete   al
  40e30a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e310:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e316:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e31c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e322:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e328:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e32e:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e334:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e33a:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e343:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e34c:	add    rsp,0xa8
  40e353:	pop    rsi
  40e354:	pop    rdi
  40e355:	ret
	...

000000000040e360 <__swc_fn_23cea7fa_000136_865f5106>:
  40e360:	push   rdi
  40e361:	push   rsi
  40e362:	sub    rsp,0xa8
  40e369:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e36f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e375:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e37b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e381:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e387:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e38d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e393:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e399:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e3a2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e3ab:	mov    rax,rdx
  40e3ae:	mov    QWORD PTR [rsp],0x0
  40e3b6:	mov    edi,0xca
  40e3bb:	mov    rsi,rcx
  40e3be:	mov    edx,0x81
  40e3c3:	mov    eax,eax
  40e3c5:	mov    ecx,eax
  40e3c7:	xor    r8d,r8d
  40e3ca:	xor    r9d,r9d
  40e3cd:	xor    eax,eax
  40e3cf:	call   4071a0 <syscall@plt>
  40e3d4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e3da:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e3e0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e3e6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e3ec:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e3f2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e3f8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e3fe:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e404:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e40d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e416:	add    rsp,0xa8
  40e41d:	pop    rsi
  40e41e:	pop    rdi
  40e41f:	ret

000000000040e420 <__swc_fn_23cea7fa_000139_86bb0f90>:
  40e420:	sub    rsp,0x8
  40e424:	call   4118f0 <__swc_fn_23cea7fa_000137_8c07c14b>
  40e429:	add    rsp,0x8
  40e42d:	ret
	...

000000000040e430 <__swc_fn_23cea7fa_000142_be4c2719>:
  40e430:	push   rdi
  40e431:	push   rsi
  40e432:	sub    rsp,0xc8
  40e439:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40e43f:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40e445:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40e44b:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40e451:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40e457:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40e45d:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40e466:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40e46f:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40e478:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40e481:	vxorps xmm0,xmm0,xmm0
  40e485:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e48b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e491:	mov    rdi,rcx
  40e494:	lea    rsi,[rsp+0x8]
  40e499:	xor    eax,eax
  40e49b:	call   4071b0 <dladdr@plt>
  40e4a0:	xor    ecx,ecx
  40e4a2:	test   eax,eax
  40e4a4:	je     40e4ab <__swc_fn_23cea7fa_000142_be4c2719+0x7b>
  40e4a6:	mov    rcx,QWORD PTR [rsp+0x10]
  40e4ab:	mov    rax,rcx
  40e4ae:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40e4b4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40e4ba:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40e4c0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40e4c6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40e4cc:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40e4d2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40e4db:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40e4e4:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40e4ed:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40e4f6:	add    rsp,0xc8
  40e4fd:	pop    rsi
  40e4fe:	pop    rdi
  40e4ff:	ret

000000000040e500 <__swc_fn_23cea7fa_000145_1534de9a>:
  40e500:	push   rbx
  40e501:	push   r12
  40e503:	push   r13
  40e505:	push   rdi
  40e506:	push   rsi
  40e507:	push   r14
  40e509:	push   r15
  40e50b:	sub    rsp,0x150
  40e512:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40e51b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40e524:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40e52d:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40e536:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40e53f:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40e548:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40e551:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40e55a:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40e563:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40e56c:	mov    rbx,rdx
  40e56f:	mov    QWORD PTR [rsp+0x98],rdx
  40e577:	mov    r12,rcx
  40e57a:	mov    QWORD PTR [rsp+0xa0],rcx
  40e582:	mov    QWORD PTR [rbx],0x0
  40e589:	lea    r13,[rip+0x187e8]        # 426d78 <__swc_bss_base_23cea7fa+0x2d38>
  40e590:	mov    rcx,r13
  40e593:	call   40e420 <__swc_fn_23cea7fa_000139_86bb0f90>
  40e598:	mov    rax,QWORD PTR [rip+0x187e1]        # 426d80 <__swc_bss_base_23cea7fa+0x2d40>
  40e59f:	test   rax,rax
  40e5a2:	je     40e5d9 <__swc_fn_23cea7fa_000145_1534de9a+0xd9>
  40e5a4:	cs nop WORD PTR [rax+rax*1+0x0]
  40e5ae:	xchg   ax,ax
  40e5b0:	cmp    QWORD PTR [rax+0x8],r12
  40e5b4:	jne    40e5d1 <__swc_fn_23cea7fa_000145_1534de9a+0xd1>
  40e5b6:	mov    rcx,QWORD PTR [rax+0x18]
  40e5ba:	mov    QWORD PTR [rbx],rcx
  40e5bd:	mov    rbx,QWORD PTR [rax+0x10]
  40e5c1:	mov    rcx,r13
  40e5c4:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40e5c9:	mov    rax,rbx
  40e5cc:	jmp    40e7bb <__swc_fn_23cea7fa_000145_1534de9a+0x2bb>
  40e5d1:	mov    rax,QWORD PTR [rax]
  40e5d4:	test   rax,rax
  40e5d7:	jne    40e5b0 <__swc_fn_23cea7fa_000145_1534de9a+0xb0>
  40e5d9:	vxorps xmm0,xmm0,xmm0
  40e5dd:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  40e5e3:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  40e5e9:	mov    rdi,r12
  40e5ec:	lea    rsi,[rsp+0x10]
  40e5f1:	xor    eax,eax
  40e5f3:	call   4071b0 <dladdr@plt>
  40e5f8:	test   eax,eax
  40e5fa:	sete   al
  40e5fd:	je     40e60a <__swc_fn_23cea7fa_000145_1534de9a+0x10a>
  40e5ff:	mov    rax,QWORD PTR [rsp+0x10]
  40e604:	test   rax,rax
  40e607:	sete   al
  40e60a:	test   al,al
  40e60c:	je     40e61d <__swc_fn_23cea7fa_000145_1534de9a+0x11d>
  40e60e:	mov    rcx,r13
  40e611:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40e616:	xor    eax,eax
  40e618:	jmp    40e7bb <__swc_fn_23cea7fa_000145_1534de9a+0x2bb>
  40e61d:	mov    rdi,QWORD PTR [rsp+0x10]
  40e622:	mov    esi,0x80000
  40e627:	xor    eax,eax
  40e629:	call   407010 <open@plt>
  40e62e:	lea    r14,[rsp+0x30]
  40e633:	mov    DWORD PTR [rsp+0x30],eax
  40e637:	cmp    DWORD PTR [r14],0x0
  40e63b:	jge    40e64c <__swc_fn_23cea7fa_000145_1534de9a+0x14c>
  40e63d:	mov    rcx,r13
  40e640:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40e645:	xor    eax,eax
  40e647:	jmp    40e7bb <__swc_fn_23cea7fa_000145_1534de9a+0x2bb>
  40e64c:	mov    rax,r14
  40e64f:	movsxd rdi,DWORD PTR [rax]
  40e652:	xor    esi,esi
  40e654:	mov    edx,0x2
  40e659:	xor    eax,eax
  40e65b:	call   4070c0 <lseek@plt>
  40e660:	mov    r15,rax
  40e663:	test   rax,rax
  40e666:	jg     40e681 <__swc_fn_23cea7fa_000145_1534de9a+0x181>
  40e668:	movsxd rdi,DWORD PTR [r14]
  40e66b:	xor    eax,eax
  40e66d:	call   407040 <close@plt>
  40e672:	mov    rcx,r13
  40e675:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40e67a:	xor    eax,eax
  40e67c:	jmp    40e7bb <__swc_fn_23cea7fa_000145_1534de9a+0x2bb>
  40e681:	xor    edi,edi
  40e683:	mov    rsi,r15
  40e686:	mov    edx,0x1
  40e68b:	mov    ecx,0x2
  40e690:	mov    rax,r14
  40e693:	movsxd r8,DWORD PTR [rax]
  40e696:	xor    r9d,r9d
  40e699:	xor    eax,eax
  40e69b:	call   4070d0 <mmap@plt>
  40e6a0:	mov    rbx,rax
  40e6a3:	test   rax,rax
  40e6a6:	sete   al
  40e6a9:	cmp    rbx,0xffffffffffffffff
  40e6ad:	sete   cl
  40e6b0:	or     al,cl
  40e6b2:	je     40e6cd <__swc_fn_23cea7fa_000145_1534de9a+0x1cd>
  40e6b4:	movsxd rdi,DWORD PTR [r14]
  40e6b7:	xor    eax,eax
  40e6b9:	call   407040 <close@plt>
  40e6be:	mov    rcx,r13
  40e6c1:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40e6c6:	xor    eax,eax
  40e6c8:	jmp    40e7bb <__swc_fn_23cea7fa_000145_1534de9a+0x2bb>
  40e6cd:	lea    rax,[rsp+0x50]
  40e6d2:	mov    QWORD PTR [rax],0x0
  40e6d9:	mov    rcx,rbx
  40e6dc:	mov    rdx,r15
  40e6df:	mov    r8,rax
  40e6e2:	call   40a3c0 <__swc_fn_23cea7fa_000144_d5d4d43f>
  40e6e7:	mov    r12,rax
  40e6ea:	test   rax,rax
  40e6ed:	jne    40e715 <__swc_fn_23cea7fa_000145_1534de9a+0x215>
  40e6ef:	mov    rdi,rbx
  40e6f2:	mov    rsi,r15
  40e6f5:	xor    eax,eax
  40e6f7:	call   407160 <munmap@plt>
  40e6fc:	movsxd rdi,DWORD PTR [r14]
  40e6ff:	xor    eax,eax
  40e701:	call   407040 <close@plt>
  40e706:	mov    rcx,r13
  40e709:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40e70e:	xor    eax,eax
  40e710:	jmp    40e7bb <__swc_fn_23cea7fa_000145_1534de9a+0x2bb>
  40e715:	mov    edi,0x20
  40e71a:	xor    eax,eax
  40e71c:	call   4071c0 <malloc@plt>
  40e721:	test   rax,rax
  40e724:	jne    40e749 <__swc_fn_23cea7fa_000145_1534de9a+0x249>
  40e726:	mov    rdi,rbx
  40e729:	mov    rsi,r15
  40e72c:	xor    eax,eax
  40e72e:	call   407160 <munmap@plt>
  40e733:	movsxd rdi,DWORD PTR [r14]
  40e736:	xor    eax,eax
  40e738:	call   407040 <close@plt>
  40e73d:	mov    rcx,r13
  40e740:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40e745:	xor    eax,eax
  40e747:	jmp    40e7bb <__swc_fn_23cea7fa_000145_1534de9a+0x2bb>
  40e749:	mov    rcx,QWORD PTR [rip+0x18630]        # 426d80 <__swc_bss_base_23cea7fa+0x2d40>
  40e750:	mov    QWORD PTR [rsp+0x70],rcx
  40e755:	mov    rcx,QWORD PTR [rsp+0xa0]
  40e75d:	mov    QWORD PTR [rsp+0x78],rcx
  40e762:	mov    QWORD PTR [rsp+0x80],r12
  40e76a:	mov    rcx,QWORD PTR [rsp+0x50]
  40e76f:	mov    QWORD PTR [rsp+0x88],rcx
  40e777:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  40e77d:	vmovups XMMWORD PTR [rax],xmm0
  40e781:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  40e78a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e78f:	mov    QWORD PTR [rip+0x185ea],rax        # 426d80 <__swc_bss_base_23cea7fa+0x2d40>
  40e796:	mov    rax,QWORD PTR [rsp+0x50]
  40e79b:	mov    rbx,QWORD PTR [rsp+0x98]
  40e7a3:	mov    QWORD PTR [rbx],rax
  40e7a6:	movsxd rdi,DWORD PTR [r14]
  40e7a9:	xor    eax,eax
  40e7ab:	call   407040 <close@plt>
  40e7b0:	mov    rcx,r13
  40e7b3:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40e7b8:	mov    rax,r12
  40e7bb:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40e7c4:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40e7cd:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40e7d6:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40e7df:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40e7e8:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40e7f1:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40e7fa:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40e803:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40e80c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40e815:	add    rsp,0x150
  40e81c:	pop    r15
  40e81e:	pop    r14
  40e820:	pop    rsi
  40e821:	pop    rdi
  40e822:	pop    r13
  40e824:	pop    r12
  40e826:	pop    rbx
  40e827:	ret
	...

000000000040e830 <__swc_fn_23cea7fa_000148_43c96957>:
  40e830:	push   rbx
  40e831:	sub    rsp,0xe0
  40e838:	lea    rbx,[rsp+0x8]
  40e83d:	vxorps xmm0,xmm0,xmm0
  40e841:	vmovups YMMWORD PTR [rbx],ymm0
  40e845:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40e84a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40e84f:	vzeroupper
  40e852:	mov    DWORD PTR [rbx+0x60],0x0
  40e859:	mov    r8,rbx
  40e85c:	nop    DWORD PTR [rax+0x0]
  40e860:	mov    r9,rcx
  40e863:	movabs rcx,0xcccccccccccccccd
  40e86d:	mov    rax,r9
  40e870:	mul    rcx
  40e873:	mov    r10,rdx
  40e876:	shr    r10,0x3
  40e87a:	mov    rcx,r10
  40e87d:	imul   rdx,r10,0xa
  40e881:	sub    r9,rdx
  40e884:	mov    rdx,QWORD PTR [rip+0x4d85]        # 413610 <__swc_rdata_base_23cea7fa+0x500>
  40e88b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  40e890:	mov    BYTE PTR [r8],dl
  40e893:	lea    rdx,[r8+0x1]
  40e897:	mov    r8,rdx
  40e89a:	test   r10,r10
  40e89d:	jne    40e860 <__swc_fn_23cea7fa_000148_43c96957+0x30>
  40e89f:	mov    BYTE PTR [rdx],0x0
  40e8a2:	sub    r8,0x1
  40e8a6:	mov    rax,rbx
  40e8a9:	cmp    rax,r8
  40e8ac:	jae    40e8c6 <__swc_fn_23cea7fa_000148_43c96957+0x96>
  40e8ae:	xchg   ax,ax
  40e8b0:	mov    cl,BYTE PTR [r8]
  40e8b3:	mov    dl,BYTE PTR [rax]
  40e8b5:	mov    BYTE PTR [r8],dl
  40e8b8:	sub    r8,0x1
  40e8bc:	mov    BYTE PTR [rax],cl
  40e8be:	inc    rax
  40e8c1:	cmp    rax,r8
  40e8c4:	jb     40e8b0 <__swc_fn_23cea7fa_000148_43c96957+0x80>
  40e8c6:	xor    eax,eax
  40e8c8:	test   rbx,rbx
  40e8cb:	je     40e8ee <__swc_fn_23cea7fa_000148_43c96957+0xbe>
  40e8cd:	mov    rcx,rbx
  40e8d0:	mov    dl,BYTE PTR [rcx]
  40e8d2:	test   dl,dl
  40e8d4:	je     40e8ee <__swc_fn_23cea7fa_000148_43c96957+0xbe>
  40e8d6:	cs nop WORD PTR [rax+rax*1+0x0]
  40e8e0:	add    rcx,0x1
  40e8e4:	add    rax,0x1
  40e8e8:	mov    dl,BYTE PTR [rcx]
  40e8ea:	test   dl,dl
  40e8ec:	jne    40e8e0 <__swc_fn_23cea7fa_000148_43c96957+0xb0>
  40e8ee:	mov    QWORD PTR [rbx+0xa8],rbx
  40e8f5:	mov    QWORD PTR [rbx+0xb0],rax
  40e8fc:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40e904:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40e90c:	lea    rcx,[rbx+0xb8]
  40e913:	call   409e30 <__swc_fn_23cea7fa_000120_2648f149>
  40e918:	add    rsp,0xe0
  40e91f:	pop    rbx
  40e920:	ret
	...

000000000040e930 <__swc_fn_23cea7fa_000151_6fb05988>:
  40e930:	sub    rsp,0x8
  40e934:	mov    rax,QWORD PTR [rcx+0x8]
  40e938:	mov    r8,QWORD PTR [rdx+0x8]
  40e93c:	cmp    rax,r8
  40e93f:	je     40e948 <__swc_fn_23cea7fa_000151_6fb05988+0x18>
  40e941:	xor    eax,eax
  40e943:	add    rsp,0x8
  40e947:	ret
  40e948:	test   rax,rax
  40e94b:	jne    40e95c <__swc_fn_23cea7fa_000151_6fb05988+0x2c>
  40e94d:	test   r8,r8
  40e950:	jne    40e95c <__swc_fn_23cea7fa_000151_6fb05988+0x2c>
  40e952:	mov    eax,0x1
  40e957:	add    rsp,0x8
  40e95b:	ret
  40e95c:	mov    rcx,QWORD PTR [rcx]
  40e95f:	mov    rdx,QWORD PTR [rdx]
  40e962:	test   rcx,rcx
  40e965:	sete   r8b
  40e969:	test   rdx,rdx
  40e96c:	sete   r9b
  40e970:	or     r8b,r9b
  40e973:	je     40e980 <__swc_fn_23cea7fa_000151_6fb05988+0x50>
  40e975:	cmp    rcx,rdx
  40e978:	sete   al
  40e97b:	add    rsp,0x8
  40e97f:	ret
  40e980:	cmp    rcx,rdx
  40e983:	jne    40e98f <__swc_fn_23cea7fa_000151_6fb05988+0x5f>
  40e985:	mov    eax,0x1
  40e98a:	add    rsp,0x8
  40e98e:	ret
  40e98f:	mov    r8,rax
  40e992:	call   410fe0 <__swc_fn_23cea7fa_000110_3dc01326>
  40e997:	test   eax,eax
  40e999:	sete   al
  40e99c:	add    rsp,0x8
  40e9a0:	ret
	...

000000000040e9b0 <__swc_fn_23cea7fa_000154_86f1d437>:
  40e9b0:	vxorps xmm0,xmm0,xmm0
  40e9b4:	vmovups XMMWORD PTR [rcx],xmm0
  40e9b8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e9bd:	vxorps xmm0,xmm0,xmm0
  40e9c1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e9c6:	vmovups xmm0,XMMWORD PTR [rip+0x4cfa]        # 4136c8 <__swc_rdata_base_23cea7fa+0x5b8>
  40e9ce:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e9d3:	ret
	...

000000000040e9e0 <__swc_fn_23cea7fa_000157_86f1d437>:
  40e9e0:	vxorps xmm0,xmm0,xmm0
  40e9e4:	vmovups XMMWORD PTR [rcx],xmm0
  40e9e8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e9ed:	vxorps xmm0,xmm0,xmm0
  40e9f1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e9f6:	vmovups xmm0,XMMWORD PTR [rip+0x4dea]        # 4137e8 <__swc_rdata_base_23cea7fa+0x6d8>
  40e9fe:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40ea03:	mov    QWORD PTR [rcx+0x40],0x0
  40ea0b:	ret
  40ea0c:	add    BYTE PTR [rax],al
	...

000000000040ea10 <__swc_fn_23cea7fa_000160_47b270e1>:
  40ea10:	push   rbx
  40ea11:	sub    rsp,0x70
  40ea15:	mov    rax,QWORD PTR [rcx]
  40ea18:	mov    rbx,QWORD PTR [rcx+0x8]
  40ea1c:	vxorps xmm0,xmm0,xmm0
  40ea20:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40ea26:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40ea2c:	vzeroupper
  40ea2f:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40ea35:	mov    QWORD PTR [rsp+0x48],rdx
  40ea3a:	mov    QWORD PTR [rsp+0x50],r8
  40ea3f:	mov    rcx,rax
  40ea42:	lea    rdx,[rsp+0x8]
  40ea47:	mov    rbx,QWORD PTR [rbx+0x18]
  40ea4b:	call   rbx
  40ea4d:	add    rsp,0x70
  40ea51:	pop    rbx
  40ea52:	ret
	...

000000000040ea60 <__swc_fn_23cea7fa_000163_8a3d304f>:
  40ea60:	push   rbx
  40ea61:	push   rsi
  40ea62:	push   rdi
  40ea63:	mov    rbx,r8
  40ea66:	mov    rsi,rcx
  40ea69:	mov    rdi,rdx
  40ea6c:	call   411cf0 <__swc_fn_23cea7fa_000161_13ead2ff>
  40ea71:	vmovups xmm0,XMMWORD PTR [rbx]
  40ea75:	vmovups XMMWORD PTR [rsi],xmm0
  40ea79:	mov    QWORD PTR [rsi+0x18],rdi
  40ea7d:	pop    rdi
  40ea7e:	pop    rsi
  40ea7f:	pop    rbx
  40ea80:	ret
	...

000000000040ea90 <__swc_fn_23cea7fa_000166_cc119975>:
  40ea90:	push   rbx
  40ea91:	push   rsi
  40ea92:	push   rdi
  40ea93:	push   r12
  40ea95:	push   r13
  40ea97:	sub    rsp,0x50
  40ea9b:	mov    rbx,rcx
  40ea9e:	mov    rsi,rdx
  40eaa1:	vmovups xmm0,XMMWORD PTR [rip+0x4e4f]        # 4138f8 <__swc_rdata_base_23cea7fa+0x7e8>
  40eaa9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40eaaf:	vmovups xmm0,XMMWORD PTR [rip+0x4e51]        # 413908 <__swc_rdata_base_23cea7fa+0x7f8>
  40eab7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40eabd:	vxorps xmm0,xmm0,xmm0
  40eac1:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40eac7:	mov    rcx,rdx
  40eaca:	call   40e430 <__swc_fn_23cea7fa_000142_be4c2719>
  40eacf:	mov    rdi,rax
  40ead2:	test   rax,rax
  40ead5:	jne    40eb06 <__swc_fn_23cea7fa_000166_cc119975+0x76>
  40ead7:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40eadd:	vmovups XMMWORD PTR [rbx],xmm0
  40eae1:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40eae7:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40eaec:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40eaf2:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40eaf7:	mov    rax,rbx
  40eafa:	add    rsp,0x50
  40eafe:	pop    r13
  40eb00:	pop    r12
  40eb02:	pop    rdi
  40eb03:	pop    rsi
  40eb04:	pop    rbx
  40eb05:	ret
  40eb06:	mov    rcx,rdi
  40eb09:	call   40b8e0 <__swc_fn_23cea7fa_000165_016ee66a>
  40eb0e:	mov    r11,rax
  40eb11:	test   rax,rax
  40eb14:	je     40eb1e <__swc_fn_23cea7fa_000166_cc119975+0x8e>
  40eb16:	mov    al,BYTE PTR [r11+0x24]
  40eb1a:	test   al,al
  40eb1c:	jne    40eb4d <__swc_fn_23cea7fa_000166_cc119975+0xbd>
  40eb1e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40eb24:	vmovups XMMWORD PTR [rbx],xmm0
  40eb28:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40eb2e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40eb33:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40eb39:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40eb3e:	mov    rax,rbx
  40eb41:	add    rsp,0x50
  40eb45:	pop    r13
  40eb47:	pop    r12
  40eb49:	pop    rdi
  40eb4a:	pop    rsi
  40eb4b:	pop    rbx
  40eb4c:	ret
  40eb4d:	sub    rsi,rdi
  40eb50:	mov    eax,0xffffffff
  40eb55:	cmp    rsi,rax
  40eb58:	jbe    40eb89 <__swc_fn_23cea7fa_000166_cc119975+0xf9>
  40eb5a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40eb60:	vmovups XMMWORD PTR [rbx],xmm0
  40eb64:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40eb6a:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40eb6f:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40eb75:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40eb7a:	mov    rax,rbx
  40eb7d:	add    rsp,0x50
  40eb81:	pop    r13
  40eb83:	pop    r12
  40eb85:	pop    rdi
  40eb86:	pop    rsi
  40eb87:	pop    rbx
  40eb88:	ret
  40eb89:	mov    rdi,QWORD PTR [r11+0x10]
  40eb8d:	mov    eax,DWORD PTR [r11+0x20]
  40eb91:	xor    ecx,ecx
  40eb93:	test   rax,rax
  40eb96:	jbe    40ece8 <__swc_fn_23cea7fa_000166_cc119975+0x258>
  40eb9c:	nop    DWORD PTR [rax+0x0]
  40eba0:	mov    edx,ecx
  40eba2:	imul   r12,rdx,0x14
  40eba6:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40ebab:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40ebb0:	mov    r9d,esi
  40ebb3:	cmp    r9,rdx
  40ebb6:	jb     40ecdb <__swc_fn_23cea7fa_000166_cc119975+0x24b>
  40ebbc:	add    rdx,r8
  40ebbf:	mov    r8d,esi
  40ebc2:	cmp    r8,rdx
  40ebc5:	jae    40ecdb <__swc_fn_23cea7fa_000166_cc119975+0x24b>
  40ebcb:	lea    rsi,[rsp+0x38]
  40ebd0:	mov    eax,DWORD PTR [rdi+0xc]
  40ebd3:	mov    DWORD PTR [rsp+0x38],eax
  40ebd7:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40ebdc:	mov    rcx,rdi
  40ebdf:	mov    rdx,QWORD PTR [r11+0x18]
  40ebe3:	mov    r8,rsi
  40ebe6:	mov    r8d,DWORD PTR [r8]
  40ebe9:	mov    r9,rax
  40ebec:	lea    r10,[rsp+0x10]
  40ebf1:	call   411d40 <__swc_fn_23cea7fa_000164_72795826>
  40ebf6:	test   al,al
  40ebf8:	jne    40ec2b <__swc_fn_23cea7fa_000166_cc119975+0x19b>
  40ebfa:	vmovups xmm0,XMMWORD PTR [rip+0x4d26]        # 413928 <__swc_rdata_base_23cea7fa+0x818>
  40ec02:	vmovups XMMWORD PTR [rbx],xmm0
  40ec06:	vmovups xmm0,XMMWORD PTR [rip+0x4d2a]        # 413938 <__swc_rdata_base_23cea7fa+0x828>
  40ec0e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ec13:	vxorps xmm0,xmm0,xmm0
  40ec17:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ec1c:	mov    rax,rbx
  40ec1f:	add    rsp,0x50
  40ec23:	pop    r13
  40ec25:	pop    r12
  40ec27:	pop    rdi
  40ec28:	pop    rsi
  40ec29:	pop    rbx
  40ec2a:	ret
  40ec2b:	lea    r13,[rsp+0x3c]
  40ec30:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40ec35:	mov    DWORD PTR [rsp+0x3c],eax
  40ec39:	test   eax,eax
  40ec3b:	je     40ec8c <__swc_fn_23cea7fa_000166_cc119975+0x1fc>
  40ec3d:	mov    rcx,rdi
  40ec40:	mov    rdx,QWORD PTR [r11+0x18]
  40ec44:	mov    r8d,DWORD PTR [rsi]
  40ec47:	mov    rax,r13
  40ec4a:	mov    r9d,DWORD PTR [rax]
  40ec4d:	lea    r10,[rsp+0x20]
  40ec52:	call   411d40 <__swc_fn_23cea7fa_000164_72795826>
  40ec57:	test   al,al
  40ec59:	jne    40ec8c <__swc_fn_23cea7fa_000166_cc119975+0x1fc>
  40ec5b:	vmovups xmm0,XMMWORD PTR [rip+0x4cf5]        # 413958 <__swc_rdata_base_23cea7fa+0x848>
  40ec63:	vmovups XMMWORD PTR [rbx],xmm0
  40ec67:	vmovups xmm0,XMMWORD PTR [rip+0x4cf9]        # 413968 <__swc_rdata_base_23cea7fa+0x858>
  40ec6f:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ec74:	vxorps xmm0,xmm0,xmm0
  40ec78:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ec7d:	mov    rax,rbx
  40ec80:	add    rsp,0x50
  40ec84:	pop    r13
  40ec86:	pop    r12
  40ec88:	pop    rdi
  40ec89:	pop    rsi
  40ec8a:	pop    rbx
  40ec8b:	ret
  40ec8c:	mov    eax,0x1
  40ec91:	rex mov BYTE PTR [rsp+0x8],al
  40ec96:	cmp    DWORD PTR [r13+0x0],0x0
  40ec9b:	je     40ecac <__swc_fn_23cea7fa_000166_cc119975+0x21c>
  40ec9d:	rex mov BYTE PTR [rsp+0x9],0x1
  40eca3:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40eca8:	mov    DWORD PTR [rsp+0x30],eax
  40ecac:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ecb2:	vmovups XMMWORD PTR [rbx],xmm0
  40ecb6:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40ecbc:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ecc1:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40ecc7:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40eccc:	mov    rax,rbx
  40eccf:	add    rsp,0x50
  40ecd3:	pop    r13
  40ecd5:	pop    r12
  40ecd7:	pop    rdi
  40ecd8:	pop    rsi
  40ecd9:	pop    rbx
  40ecda:	ret
  40ecdb:	add    rcx,0x1
  40ecdf:	cmp    rcx,rax
  40ece2:	jb     40eba0 <__swc_fn_23cea7fa_000166_cc119975+0x110>
  40ece8:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ecee:	vmovups XMMWORD PTR [rbx],xmm0
  40ecf2:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40ecf8:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ecfd:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40ed03:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ed08:	mov    rax,rbx
  40ed0b:	add    rsp,0x50
  40ed0f:	pop    r13
  40ed11:	pop    r12
  40ed13:	pop    rdi
  40ed14:	pop    rsi
  40ed15:	pop    rbx
  40ed16:	ret
	...

000000000040ed20 <__swc_fn_23cea7fa_000169_994c8876>:
  40ed20:	sub    rsp,0x48
  40ed24:	call   40e100 <__swc_fn_23cea7fa_000127_58f0f391>
  40ed29:	cmp    rax,0xffffffffffffffff
  40ed2d:	je     40ed34 <__swc_fn_23cea7fa_000169_994c8876+0x14>
  40ed2f:	add    rsp,0x48
  40ed33:	ret
  40ed34:	lea    rcx,[rip+0x4c5d]        # 413998 <__swc_rdata_base_23cea7fa+0x888>
  40ed3b:	vmovups xmm0,XMMWORD PTR [rip+0x4c65]        # 4139a8 <__swc_rdata_base_23cea7fa+0x898>
  40ed43:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ed49:	vmovups xmm0,XMMWORD PTR [rip+0x4c67]        # 4139b8 <__swc_rdata_base_23cea7fa+0x8a8>
  40ed51:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40ed57:	vmovups xmm0,XMMWORD PTR [rip+0x4c69]        # 4139c8 <__swc_rdata_base_23cea7fa+0x8b8>
  40ed5f:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40ed65:	lea    rdx,[rsp+0x8]
  40ed6a:	mov    QWORD PTR [rsp+0x38],rax
  40ed6f:	call   410f20 <__swc_fn_23cea7fa_000107_90faaa26>
  40ed74:	mov    rax,QWORD PTR [rsp+0x38]
  40ed79:	jmp    40ed2f <__swc_fn_23cea7fa_000169_994c8876+0xf>
  40ed7b:	add    BYTE PTR [rax],al
  40ed7d:	add    BYTE PTR [rax],al
	...

000000000040ed80 <__swc_fn_23cea7fa_000172_cbeff767>:
  40ed80:	push   rbx
  40ed81:	push   rsi
  40ed82:	sub    rsp,0x28
  40ed86:	mov    rbx,rcx
  40ed89:	mov    DWORD PTR [rsp+0x8],0xbf0
  40ed91:	mov    ecx,0xbf0
  40ed96:	call   410b10 <__swc_fn_23cea7fa_000083_4a10c7e7>
  40ed9b:	mov    rsi,rax
  40ed9e:	test   rax,rax
  40eda1:	jne    40edac <__swc_fn_23cea7fa_000172_cbeff767+0x2c>
  40eda3:	xor    eax,eax
  40eda5:	add    rsp,0x28
  40eda9:	pop    rsi
  40edaa:	pop    rbx
  40edab:	ret
  40edac:	vxorps xmm0,xmm0,xmm0
  40edb0:	xor    eax,eax
  40edb2:	cs nop WORD PTR [rax+rax*1+0x0]
  40edbc:	nop    DWORD PTR [rax+0x0]
  40edc0:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40edc5:	add    rax,0x10
  40edc9:	cmp    rax,0xbf0
  40edd0:	jne    40edc0 <__swc_fn_23cea7fa_000172_cbeff767+0x40>
  40edd2:	lea    rax,[rbx+0x1]
  40edd6:	mov    QWORD PTR [rsi+0x9c0],rax
  40eddd:	mov    rcx,rbx
  40ede0:	mov    rdx,rsi
  40ede3:	call   4120a0 <__swc_fn_23cea7fa_000170_646fdf20>
  40ede8:	test   al,al
  40edea:	jne    40edfd <__swc_fn_23cea7fa_000172_cbeff767+0x7d>
  40edec:	mov    rcx,rsi
  40edef:	call   408db0 <__swc_fn_23cea7fa_000084_cf82995a>
  40edf4:	xor    eax,eax
  40edf6:	add    rsp,0x28
  40edfa:	pop    rsi
  40edfb:	pop    rbx
  40edfc:	ret
  40edfd:	lea    rcx,[rsp+0x18]
  40ee02:	call   409330 <__swc_fn_23cea7fa_000096_93bfe675>
  40ee07:	mov    rax,rsi
  40ee0a:	add    rsp,0x28
  40ee0e:	pop    rsi
  40ee0f:	pop    rbx
  40ee10:	ret
	...

000000000040ee20 <__swc_fn_23cea7fa_000175_e09f8b62>:
  40ee20:	xor    eax,eax
  40ee22:	mov    edx,0x1
  40ee27:	lock cmpxchg QWORD PTR [rcx],rdx
  40ee2c:	test   rax,rax
  40ee2f:	jne    40ee32 <__swc_fn_23cea7fa_000175_e09f8b62+0x12>
  40ee31:	ret
  40ee32:	cs nop WORD PTR [rax+rax*1+0x0]
  40ee3c:	nop    DWORD PTR [rax+0x0]
  40ee40:	mov    rax,QWORD PTR [rcx]
  40ee43:	test   rax,rax
  40ee46:	je     40ee20 <__swc_fn_23cea7fa_000175_e09f8b62>
  40ee48:	jmp    40ee40 <__swc_fn_23cea7fa_000175_e09f8b62+0x20>
  40ee4a:	add    BYTE PTR [rax],al
  40ee4c:	add    BYTE PTR [rax],al
	...

000000000040ee50 <__swc_fn_23cea7fa_000178_718d7b54>:
  40ee50:	push   rsi
  40ee51:	push   rdi
  40ee52:	sub    rsp,0x38
  40ee56:	mov    rsi,rcx
  40ee59:	call   4120b0 <__swc_fn_23cea7fa_000173_1e0ea8cf>
  40ee5e:	mov    rdi,rax
  40ee61:	call   411840 <__swc_fn_23cea7fa_000134_a9c1c700>
  40ee66:	mov    r8,rax
  40ee69:	mov    rcx,rdi
  40ee6c:	call   40ee20 <__swc_fn_23cea7fa_000175_e09f8b62>
  40ee71:	mov    rax,QWORD PTR [rdi+0x8]
  40ee75:	test   rax,rax
  40ee78:	je     40eeb5 <__swc_fn_23cea7fa_000178_718d7b54+0x65>
  40ee7a:	nop    WORD PTR [rax+rax*1+0x0]
  40ee80:	cmp    rax,rsi
  40ee83:	je     40eeb5 <__swc_fn_23cea7fa_000178_718d7b54+0x65>
  40ee85:	mov    r9,QWORD PTR [rax]
  40ee88:	cmp    QWORD PTR [rax+0x20],r8
  40ee8c:	jne    40eead <__swc_fn_23cea7fa_000178_718d7b54+0x5d>
  40ee8e:	mov    rcx,rdi
  40ee91:	mov    rdx,rax
  40ee94:	mov    QWORD PTR [rsp+0x28],r8
  40ee99:	mov    QWORD PTR [rsp+0x30],r9
  40ee9e:	call   40bd00 <__swc_fn_23cea7fa_000177_cf4ffedd>
  40eea3:	mov    r8,QWORD PTR [rsp+0x28]
  40eea8:	mov    r9,QWORD PTR [rsp+0x30]
  40eead:	mov    rax,r9
  40eeb0:	test   r9,r9
  40eeb3:	jne    40ee80 <__swc_fn_23cea7fa_000178_718d7b54+0x30>
  40eeb5:	xor    eax,eax
  40eeb7:	mov    QWORD PTR [rdi],rax
  40eeba:	add    rsp,0x38
  40eebe:	pop    rdi
  40eebf:	pop    rsi
  40eec0:	ret
	...

000000000040eee0 <__swc_fn_23cea7fa_000002_1ca87929>:
  40eee0:	push   rdi
  40eee1:	push   rsi
  40eee2:	sub    rsp,0xb8
  40eee9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40eeef:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40eef5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40eefb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40ef01:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40ef07:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40ef0d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40ef13:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40ef1c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40ef25:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40ef2e:	vxorps xmm0,xmm0,xmm0
  40ef32:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ef38:	mov    edi,0x1
  40ef3d:	lea    rsi,[rsp+0x8]
  40ef42:	xor    eax,eax
  40ef44:	call   407130 <clock_gettime@plt>
  40ef49:	vxorpd xmm0,xmm0,xmm0
  40ef4d:	mov    rax,QWORD PTR [rsp+0x8]
  40ef52:	vcvtsi2sd xmm0,xmm0,rax
  40ef57:	vxorpd xmm1,xmm1,xmm1
  40ef5b:	mov    rax,QWORD PTR [rsp+0x10]
  40ef60:	vcvtsi2sd xmm1,xmm1,rax
  40ef65:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x41a3]        # 413110 <__swc_rdata_base_23cea7fa>
  40ef6d:	vaddsd xmm0,xmm0,xmm1
  40ef71:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ef77:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40ef7d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40ef83:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ef89:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ef8f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ef95:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ef9b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40efa4:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40efad:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40efb6:	add    rsp,0xb8
  40efbd:	pop    rsi
  40efbe:	pop    rdi
  40efbf:	ret

000000000040efc0 <__swc_fn_23cea7fa_000005_9ee35b18>:
  40efc0:	vxorps xmm0,xmm0,xmm0
  40efc4:	xor    eax,eax
  40efc6:	cs nop WORD PTR [rax+rax*1+0x0]
  40efd0:	cs nop WORD PTR [rax+rax*1+0x0]
  40efda:	nop    WORD PTR [rax+rax*1+0x0]
  40efe0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40efe5:	add    rax,0x10
  40efe9:	cmp    rax,0x2080
  40eff0:	jne    40efe0 <__swc_fn_23cea7fa_000005_9ee35b18+0x20>
  40eff2:	ret
	...

000000000040f000 <__swc_fn_23cea7fa_000008_d64b2baa>:
  40f000:	push   rsi
  40f001:	push   rdi
  40f002:	push   r12
  40f004:	push   r13
  40f006:	push   r14
  40f008:	mov    rsi,rcx
  40f00b:	mov    edi,r10d
  40f00e:	mov    r12,rcx
  40f011:	mov    r13,r9
  40f014:	mov    ecx,DWORD PTR [rdx+0x28]
  40f017:	shlx   r14d,r8d,ecx
  40f01c:	mov    rcx,rdx
  40f01f:	mov    edx,r8d
  40f022:	call   407c80 <__swc_fn_23cea7fa_000015_9dea5065>
  40f027:	mov    rcx,rax
  40f02a:	mov    eax,DWORD PTR [r12+0x3c]
  40f02f:	xor    edx,edx
  40f031:	div    rdi
  40f034:	vxorps xmm0,xmm0,xmm0
  40f038:	vmovdqu XMMWORD PTR [rsi],xmm0
  40f03c:	mov    QWORD PTR [r12+0x60],0x0
  40f045:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40f04a:	mov    QWORD PTR [r12+0x10],rcx
  40f04f:	imul   rax,rdi
  40f053:	lea    rdx,[rcx+rax*1]
  40f057:	mov    QWORD PTR [r12+0x18],rdx
  40f05c:	mov    QWORD PTR [r12+0x20],rcx
  40f061:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40f066:	mov    DWORD PTR [r12+0x28],0x0
  40f06f:	mov    DWORD PTR [r12+0x68],0x0
  40f078:	mov    BYTE PTR [r12+0x39],r13b
  40f07d:	mov    BYTE PTR [r12+0x3a],r14b
  40f082:	mov    BYTE PTR [r12+0x3b],0x1
  40f088:	mov    DWORD PTR [r12+0x6c],0x0
  40f091:	mov    rcx,r12
  40f094:	mov    edx,edi
  40f096:	call   407be0 <__swc_fn_23cea7fa_000009_065ed5b1>
  40f09b:	pop    r14
  40f09d:	pop    r13
  40f09f:	pop    r12
  40f0a1:	pop    rdi
  40f0a2:	pop    rsi
  40f0a3:	ret
	...

000000000040f0b0 <__swc_fn_23cea7fa_000011_c3647f66>:
  40f0b0:	mov    r8d,0x1
  40f0b6:	xor    eax,eax
  40f0b8:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40f0be:	test   eax,eax
  40f0c0:	jne    40f0b0 <__swc_fn_23cea7fa_000011_c3647f66>
  40f0c2:	ret
	...

000000000040f0d0 <__swc_fn_23cea7fa_000014_524c1f23>:
  40f0d0:	lea    r8,[rcx+0x60]
  40f0d4:	mov    rax,QWORD PTR [r8]
  40f0d7:	mov    r9,rax
  40f0da:	nop    WORD PTR [rax+rax*1+0x0]
  40f0e0:	mov    QWORD PTR [rdx],r9
  40f0e3:	mov    rax,r9
  40f0e6:	lock cmpxchg QWORD PTR [r8],rdx
  40f0eb:	cmp    rax,r9
  40f0ee:	jne    40f157 <__swc_fn_23cea7fa_000014_524c1f23+0x87>
  40f0f0:	mov    eax,DWORD PTR [rcx+0x6c]
  40f0f3:	test   eax,eax
  40f0f5:	je     40f156 <__swc_fn_23cea7fa_000014_524c1f23+0x86>
  40f0f7:	lea    rdx,[rcx+0x70]
  40f0fb:	mov    r9d,0x1
  40f101:	xor    eax,eax
  40f103:	lock cmpxchg DWORD PTR [rdx],r9d
  40f108:	test   eax,eax
  40f10a:	jne    40f156 <__swc_fn_23cea7fa_000014_524c1f23+0x86>
  40f10c:	mov    rax,rcx
  40f10f:	and    rax,0xffffffffffc00000
  40f116:	mov    rax,QWORD PTR [rax+0x8]
  40f11a:	test   rax,rax
  40f11d:	jne    40f125 <__swc_fn_23cea7fa_000014_524c1f23+0x55>
  40f11f:	xor    eax,eax
  40f121:	xchg   DWORD PTR [rdx],eax
  40f123:	jmp    40f156 <__swc_fn_23cea7fa_000014_524c1f23+0x86>
  40f125:	lea    rdx,[rax+0x2a80]
  40f12c:	mov    rax,QWORD PTR [rdx]
  40f12f:	mov    r8,rax
  40f132:	cs nop WORD PTR [rax+rax*1+0x0]
  40f13c:	nop    DWORD PTR [rax+0x0]
  40f140:	mov    QWORD PTR [rcx+0x78],r8
  40f144:	mov    rax,r8
  40f147:	lock cmpxchg QWORD PTR [rdx],rcx
  40f14c:	cmp    rax,r8
  40f14f:	je     40f156 <__swc_fn_23cea7fa_000014_524c1f23+0x86>
  40f151:	mov    r8,rax
  40f154:	jmp    40f140 <__swc_fn_23cea7fa_000014_524c1f23+0x70>
  40f156:	ret
  40f157:	mov    r9,rax
  40f15a:	jmp    40f0e0 <__swc_fn_23cea7fa_000014_524c1f23+0x10>
	...

000000000040f160 <__swc_fn_23cea7fa_000017_efc44797>:
  40f160:	push   rsi
  40f161:	push   rdi
  40f162:	push   r12
  40f164:	push   r13
  40f166:	push   r14
  40f168:	push   r15
  40f16a:	push   rbx
  40f16b:	sub    rsp,0x30
  40f16f:	mov    QWORD PTR [rsp+0x18],r8
  40f174:	mov    rsi,rcx
  40f177:	mov    rdi,rdx
  40f17a:	mov    rdx,QWORD PTR [rsi+0x40]
  40f17e:	xchg   ax,ax
  40f180:	mov    rax,rdx
  40f183:	not    rax
  40f186:	and    rax,QWORD PTR [rsi+0x20]
  40f18a:	test   rax,rax
  40f18d:	jne    40f1a1 <__swc_fn_23cea7fa_000017_efc44797+0x41>
  40f18f:	xor    eax,eax
  40f191:	add    rsp,0x30
  40f195:	pop    rbx
  40f196:	pop    r15
  40f198:	pop    r14
  40f19a:	pop    r13
  40f19c:	pop    r12
  40f19e:	pop    rdi
  40f19f:	pop    rsi
  40f1a0:	ret
  40f1a1:	xor    ecx,ecx
  40f1a3:	tzcnt  rcx,rax
  40f1a8:	lea    r12,[rsp+0x8]
  40f1ad:	mov    DWORD PTR [rsp+0x8],ecx
  40f1b1:	mov    r13d,0x1
  40f1b7:	shl    r13,cl
  40f1ba:	mov    rcx,rdx
  40f1bd:	or     rcx,r13
  40f1c0:	mov    rax,rdx
  40f1c3:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40f1c9:	cmp    rax,rdx
  40f1cc:	je     40f1d3 <__swc_fn_23cea7fa_000017_efc44797+0x73>
  40f1ce:	mov    rdx,rax
  40f1d1:	jmp    40f180 <__swc_fn_23cea7fa_000017_efc44797+0x20>
  40f1d3:	mov    eax,DWORD PTR [r12]
  40f1d7:	shl    rax,0x4
  40f1db:	lea    r14,[rsi+rax*8+0x80]
  40f1e3:	mov    rcx,rsi
  40f1e6:	mov    rax,r12
  40f1e9:	mov    edx,DWORD PTR [rax]
  40f1eb:	call   407c80 <__swc_fn_23cea7fa_000015_9dea5065>
  40f1f0:	mov    r15,rax
  40f1f3:	mov    rcx,rsi
  40f1f6:	mov    rdx,r13
  40f1f9:	call   407de0 <__swc_fn_23cea7fa_000021_fd2b165c>
  40f1fe:	test   al,al
  40f200:	je     40f238 <__swc_fn_23cea7fa_000017_efc44797+0xd8>
  40f202:	mov    ecx,DWORD PTR [r14+0x3c]
  40f206:	lea    rdx,[rip+0x14e53]        # 424060 <__swc_bss_base_23cea7fa+0x20>
  40f20d:	mov    r8,QWORD PTR [rip+0x14e4c]        # 424060 <__swc_bss_base_23cea7fa+0x20>
  40f214:	cs nop WORD PTR [rax+rax*1+0x0]
  40f21e:	xchg   ax,ax
  40f220:	mov    r9,r8
  40f223:	sub    r9,rcx
  40f226:	mov    rax,r8
  40f229:	lock cmpxchg QWORD PTR [rdx],r9
  40f22e:	cmp    rax,r8
  40f231:	je     40f299 <__swc_fn_23cea7fa_000017_efc44797+0x139>
  40f233:	mov    r8,rax
  40f236:	jmp    40f220 <__swc_fn_23cea7fa_000017_efc44797+0xc0>
  40f238:	mov    rcx,rsi
  40f23b:	mov    rax,r12
  40f23e:	mov    edx,DWORD PTR [rax]
  40f240:	call   40bfe0 <__swc_fn_23cea7fa_000016_9afb7cfb>
  40f245:	mov    rcx,r15
  40f248:	and    rcx,0xffffffffffff0000
  40f24f:	lea    rcx,[rcx+0x10000]
  40f256:	mov    rbx,rax
  40f259:	cmp    rax,rcx
  40f25c:	cmova  rbx,rcx
  40f260:	mov    rax,rbx
  40f263:	sub    rax,r15
  40f266:	mov    rcx,r15
  40f269:	mov    rdx,rax
  40f26c:	call   40be30 <__swc_fn_23cea7fa_000007_f7acedb0>
  40f271:	test   al,al
  40f273:	jne    40f292 <__swc_fn_23cea7fa_000017_efc44797+0x132>
  40f275:	mov    rcx,rsi
  40f278:	mov    rdx,r13
  40f27b:	call   40c190 <__swc_fn_23cea7fa_000022_c8f5f27c>
  40f280:	xor    eax,eax
  40f282:	add    rsp,0x30
  40f286:	pop    rbx
  40f287:	pop    r15
  40f289:	pop    r14
  40f28b:	pop    r13
  40f28d:	pop    r12
  40f28f:	pop    rdi
  40f290:	pop    rsi
  40f291:	ret
  40f292:	sub    rbx,r15
  40f295:	mov    DWORD PTR [r14+0x3c],ebx
  40f299:	mov    rcx,r14
  40f29c:	mov    rdx,rsi
  40f29f:	mov    r8d,DWORD PTR [r12]
  40f2a3:	mov    r9d,edi
  40f2a6:	mov    rbx,QWORD PTR [rsp+0x18]
  40f2ab:	mov    r10d,ebx
  40f2ae:	call   40f000 <__swc_fn_23cea7fa_000008_d64b2baa>
  40f2b3:	mov    rax,r14
  40f2b6:	add    rsp,0x30
  40f2ba:	pop    rbx
  40f2bb:	pop    r15
  40f2bd:	pop    r14
  40f2bf:	pop    r13
  40f2c1:	pop    r12
  40f2c3:	pop    rdi
  40f2c4:	pop    rsi
  40f2c5:	ret
	...

000000000040f2d0 <__swc_fn_23cea7fa_000020_de02dbdf>:
  40f2d0:	mov    r8,QWORD PTR [rcx+0x48]
  40f2d4:	cs nop WORD PTR [rax+rax*1+0x0]
  40f2de:	xchg   ax,ax
  40f2e0:	mov    r9,r8
  40f2e3:	or     r9,rdx
  40f2e6:	mov    rax,r8
  40f2e9:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40f2ef:	cmp    rax,r8
  40f2f2:	jne    40f2f5 <__swc_fn_23cea7fa_000020_de02dbdf+0x25>
  40f2f4:	ret
  40f2f5:	mov    r8,rax
  40f2f8:	jmp    40f2e0 <__swc_fn_23cea7fa_000020_de02dbdf+0x10>
  40f2fa:	add    BYTE PTR [rax],al
  40f2fc:	add    BYTE PTR [rax],al
	...

000000000040f300 <__swc_fn_23cea7fa_000023_2d0fcd2c>:
  40f300:	push   rsi
  40f301:	push   rdi
  40f302:	push   r12
  40f304:	mov    rsi,rcx
  40f307:	xor    edi,edi
  40f309:	lea    r12,[rip+0x14d60]        # 424070 <__swc_bss_base_23cea7fa+0x30>
  40f310:	mov    eax,DWORD PTR [r12]
  40f314:	xor    ecx,ecx
  40f316:	test   rax,rax
  40f319:	jbe    40f354 <__swc_fn_23cea7fa_000023_2d0fcd2c+0x54>
  40f31b:	nop    DWORD PTR [rax+rax*1+0x0]
  40f320:	lea    rdx,[rip+0x14d51]        # 424078 <__swc_bss_base_23cea7fa+0x38>
  40f327:	mov    r8d,ecx
  40f32a:	lea    r8,[r8+r8*2]
  40f32e:	lea    r8,[rdx+r8*8]
  40f332:	mov    rdx,QWORD PTR [r8+0x10]
  40f336:	add    rdx,0x400000
  40f33d:	cmp    rdx,0x40000000
  40f344:	ja     40f34b <__swc_fn_23cea7fa_000023_2d0fcd2c+0x4b>
  40f346:	mov    rdi,r8
  40f349:	jmp    40f354 <__swc_fn_23cea7fa_000023_2d0fcd2c+0x54>
  40f34b:	add    rcx,0x1
  40f34f:	cmp    rcx,rax
  40f352:	jb     40f320 <__swc_fn_23cea7fa_000023_2d0fcd2c+0x20>
  40f354:	test   rdi,rdi
  40f357:	jne    40f3e3 <__swc_fn_23cea7fa_000023_2d0fcd2c+0xe3>
  40f35d:	cmp    DWORD PTR [r12],0x10
  40f362:	jae    40f3cb <__swc_fn_23cea7fa_000023_2d0fcd2c+0xcb>
  40f364:	mov    ecx,0x40400000
  40f369:	call   407ba0 <__swc_fn_23cea7fa_000006_81d2e1e9>
  40f36e:	test   rax,rax
  40f371:	je     40f3cb <__swc_fn_23cea7fa_000023_2d0fcd2c+0xcb>
  40f373:	lea    rcx,[rip+0x14cfe]        # 424078 <__swc_bss_base_23cea7fa+0x38>
  40f37a:	mov    edx,DWORD PTR [r12]
  40f37e:	lea    rdx,[rdx+rdx*2]
  40f382:	lea    rdx,[rcx+rdx*8]
  40f386:	mov    QWORD PTR [rdx],rax
  40f389:	lea    rax,[rax+0x3fffff]
  40f390:	and    rax,0xffffffffffc00000
  40f397:	mov    QWORD PTR [rdx+0x8],rax
  40f39b:	mov    QWORD PTR [rdx+0x10],0x0
  40f3a3:	mov    edx,DWORD PTR [rip+0x14cc7]        # 424070 <__swc_bss_base_23cea7fa+0x30>
  40f3a9:	nop    DWORD PTR [rax+0x0]
  40f3b0:	lea    r9d,[rdx+0x1]
  40f3b4:	mov    rax,rdx
  40f3b7:	lock cmpxchg DWORD PTR [r12],r9d
  40f3bd:	mov    r8d,eax
  40f3c0:	cmp    eax,edx
  40f3c2:	je     40f3d2 <__swc_fn_23cea7fa_000023_2d0fcd2c+0xd2>
  40f3c4:	mov    rdx,r8
  40f3c7:	jmp    40f3b0 <__swc_fn_23cea7fa_000023_2d0fcd2c+0xb0>
  40f3c9:	jmp    40f3d2 <__swc_fn_23cea7fa_000023_2d0fcd2c+0xd2>
  40f3cb:	xor    eax,eax
  40f3cd:	pop    r12
  40f3cf:	pop    rdi
  40f3d0:	pop    rsi
  40f3d1:	ret
  40f3d2:	mov    eax,DWORD PTR [rip+0x14c98]        # 424070 <__swc_bss_base_23cea7fa+0x30>
  40f3d8:	sub    eax,0x1
  40f3db:	lea    rdi,[rax+rax*2]
  40f3df:	lea    rdi,[rcx+rdi*8]
  40f3e3:	mov    r12,QWORD PTR [rdi+0x8]
  40f3e7:	add    r12,QWORD PTR [rdi+0x10]
  40f3eb:	mov    rcx,r12
  40f3ee:	mov    edx,0x3000
  40f3f3:	call   40be30 <__swc_fn_23cea7fa_000007_f7acedb0>
  40f3f8:	test   al,al
  40f3fa:	jne    40f403 <__swc_fn_23cea7fa_000023_2d0fcd2c+0x103>
  40f3fc:	xor    eax,eax
  40f3fe:	pop    r12
  40f400:	pop    rdi
  40f401:	pop    rsi
  40f402:	ret
  40f403:	vxorps xmm0,xmm0,xmm0
  40f407:	xor    eax,eax
  40f409:	cs nop WORD PTR [rax+rax*1+0x0]
  40f413:	cs nop WORD PTR [rax+rax*1+0x0]
  40f41d:	nop    DWORD PTR [rax]
  40f420:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40f426:	add    rax,0x10
  40f42a:	cmp    rax,0x3000
  40f431:	jne    40f420 <__swc_fn_23cea7fa_000023_2d0fcd2c+0x120>
  40f433:	mov    DWORD PTR [r12+0x28],esi
  40f438:	mov    eax,0x40
  40f43d:	mov    ecx,esi
  40f43f:	shr    eax,cl
  40f441:	mov    DWORD PTR [r12+0x2c],eax
  40f446:	cmp    DWORD PTR [r12+0x2c],0x40
  40f44c:	jb     40f457 <__swc_fn_23cea7fa_000023_2d0fcd2c+0x157>
  40f44e:	mov    rax,0xffffffffffffffff
  40f455:	jmp    40f467 <__swc_fn_23cea7fa_000023_2d0fcd2c+0x167>
  40f457:	mov    eax,0x1
  40f45c:	mov    ecx,DWORD PTR [r12+0x2c]
  40f461:	shl    rax,cl
  40f464:	dec    rax
  40f467:	mov    QWORD PTR [r12+0x20],rax
  40f46c:	mov    DWORD PTR [r12],0x4e540001
  40f474:	mov    DWORD PTR [r12+0x4],0x53474d45
  40f47d:	add    QWORD PTR [rdi+0x10],0x400000
  40f485:	mov    rax,r12
  40f488:	pop    r12
  40f48a:	pop    rdi
  40f48b:	pop    rsi
  40f48c:	ret
  40f48d:	add    BYTE PTR [rax],al
	...

000000000040f490 <__swc_fn_23cea7fa_000026_bcdc5519>:
  40f490:	mov    eax,0x1
  40f495:	mov    edx,DWORD PTR [rip+0x14bd5]        # 424070 <__swc_bss_base_23cea7fa+0x30>
  40f49b:	cmp    eax,edx
  40f49d:	jae    40f4eb <__swc_fn_23cea7fa_000026_bcdc5519+0x5b>
  40f49f:	nop
  40f4a0:	lea    r8,[rip+0x14bd1]        # 424078 <__swc_bss_base_23cea7fa+0x38>
  40f4a7:	lea    r9,[rax+rax*2]
  40f4ab:	lea    r9,[r8+r9*8]
  40f4af:	mov    r8,rcx
  40f4b2:	sub    r8,QWORD PTR [r9+0x8]
  40f4b6:	mov    r9,QWORD PTR [r9+0x10]
  40f4ba:	cmp    r8,r9
  40f4bd:	jae    40f4e5 <__swc_fn_23cea7fa_000026_bcdc5519+0x55>
  40f4bf:	mov    rax,rcx
  40f4c2:	and    rax,0xffffffffffc00000
  40f4c9:	shr    rcx,0x10
  40f4cd:	and    ecx,0x3f
  40f4d0:	mov    edx,DWORD PTR [rax+0x28]
  40f4d3:	shrx   ecx,ecx,edx
  40f4d8:	shl    rcx,0x4
  40f4dc:	lea    rax,[rax+rcx*8+0x80]
  40f4e4:	ret
  40f4e5:	inc    eax
  40f4e7:	cmp    eax,edx
  40f4e9:	jb     40f4a0 <__swc_fn_23cea7fa_000026_bcdc5519+0x10>
  40f4eb:	xor    eax,eax
  40f4ed:	ret
	...

000000000040f4f0 <__swc_fn_23cea7fa_000029_9798fb47>:
  40f4f0:	vxorps xmm0,xmm0,xmm0
  40f4f4:	vmovups XMMWORD PTR [rcx],xmm0
  40f4f8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f4fd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40f502:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40f507:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40f50c:	mov    QWORD PTR [rcx+0x50],0x0
  40f514:	ret
	...

000000000040f520 <__swc_fn_23cea7fa_000032_9798fb47>:
  40f520:	vxorps xmm0,xmm0,xmm0
  40f524:	xor    eax,eax
  40f526:	cs nop WORD PTR [rax+rax*1+0x0]
  40f530:	cs nop WORD PTR [rax+rax*1+0x0]
  40f53a:	nop    WORD PTR [rax+rax*1+0x0]
  40f540:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40f545:	add    rax,0x10
  40f549:	cmp    rax,0x9b0
  40f550:	jne    40f540 <__swc_fn_23cea7fa_000032_9798fb47+0x20>
  40f552:	mov    QWORD PTR [rcx+0x9b0],0x0
  40f55d:	ret
	...

000000000040f560 <__swc_fn_23cea7fa_000035_cd1a4e8c>:
  40f560:	push   rsi
  40f561:	push   rdi
  40f562:	sub    rsp,0x8
  40f566:	lea    rsi,[rip+0x12aa3]        # 422010 <__swc_data_base_23cea7fa+0x10>
  40f56d:	mov    rax,QWORD PTR [rsi]
  40f570:	mov    ecx,0xffffffff
  40f575:	cmp    rax,rcx
  40f578:	je     40f581 <__swc_fn_23cea7fa_000035_cd1a4e8c+0x21>
  40f57a:	add    rsp,0x8
  40f57e:	pop    rdi
  40f57f:	pop    rsi
  40f580:	ret
  40f581:	mov    rcx,QWORD PTR [rip+0x3b68]        # 4130f0 <__swc_fn_23cea7fa_000176_4de704de+0xff0>
  40f588:	call   40e1d0 <__swc_fn_23cea7fa_000130_4a82cdf6>
  40f58d:	mov    rcx,rax
  40f590:	mov    eax,0xffffffff
  40f595:	lock cmpxchg QWORD PTR [rsi],rcx
  40f59a:	mov    rdi,rax
  40f59d:	mov    eax,0xffffffff
  40f5a2:	cmp    rdi,rax
  40f5a5:	je     40f5b6 <__swc_fn_23cea7fa_000035_cd1a4e8c+0x56>
  40f5a7:	call   411790 <__swc_fn_23cea7fa_000131_a611b8c4>
  40f5ac:	mov    rax,rdi
  40f5af:	add    rsp,0x8
  40f5b3:	pop    rdi
  40f5b4:	pop    rsi
  40f5b5:	ret
  40f5b6:	mov    rax,rcx
  40f5b9:	add    rsp,0x8
  40f5bd:	pop    rdi
  40f5be:	pop    rsi
  40f5bf:	ret

000000000040f5c0 <__swc_fn_23cea7fa_000038_14f56618>:
  40f5c0:	sub    rsp,0x8
  40f5c4:	vxorps xmm0,xmm0,xmm0
  40f5c8:	xor    eax,eax
  40f5ca:	cs nop WORD PTR [rax+rax*1+0x0]
  40f5d4:	cs nop WORD PTR [rax+rax*1+0x0]
  40f5de:	xchg   ax,ax
  40f5e0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40f5e5:	add    rax,0x10
  40f5e9:	cmp    rax,0x2b00
  40f5f0:	jne    40f5e0 <__swc_fn_23cea7fa_000038_14f56618+0x20>
  40f5f2:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40f5fc:	xor    al,al
  40f5fe:	mov    rdx,rax
  40f601:	xor    al,al
  40f603:	mov    r8,rax
  40f606:	xor    al,al
  40f608:	mov    r9,rax
  40f60b:	xor    al,al
  40f60d:	mov    r10,rax
  40f610:	xor    al,al
  40f612:	mov    r11,rax
  40f615:	call   408010 <__swc_fn_23cea7fa_000039_03f1bf9a>
  40f61a:	add    rsp,0x8
  40f61e:	ret
	...

000000000040f620 <__swc_fn_23cea7fa_000041_c90d80c1>:
  40f620:	push   rsi
  40f621:	push   rdi
  40f622:	push   r12
  40f624:	mov    rsi,r8
  40f627:	mov    rdi,rdx
  40f62a:	mov    rcx,rdx
  40f62d:	call   407ba0 <__swc_fn_23cea7fa_000006_81d2e1e9>
  40f632:	mov    r12,rax
  40f635:	test   rax,rax
  40f638:	jne    40f641 <__swc_fn_23cea7fa_000041_c90d80c1+0x21>
  40f63a:	xor    eax,eax
  40f63c:	pop    r12
  40f63e:	pop    rdi
  40f63f:	pop    rsi
  40f640:	ret
  40f641:	mov    rcx,r12
  40f644:	mov    rdx,rsi
  40f647:	call   40be30 <__swc_fn_23cea7fa_000007_f7acedb0>
  40f64c:	test   al,al
  40f64e:	jne    40f662 <__swc_fn_23cea7fa_000041_c90d80c1+0x42>
  40f650:	mov    rcx,r12
  40f653:	mov    rdx,rdi
  40f656:	call   409e10 <__swc_fn_23cea7fa_000117_ed2d8fed>
  40f65b:	xor    eax,eax
  40f65d:	pop    r12
  40f65f:	pop    rdi
  40f660:	pop    rsi
  40f661:	ret
  40f662:	mov    rax,r12
  40f665:	pop    r12
  40f667:	pop    rdi
  40f668:	pop    rsi
  40f669:	ret
	...

000000000040f680 <__swc_fn_23cea7fa_000044_a78ae66b>:
  40f680:	push   rsi
  40f681:	push   rdi
  40f682:	push   r12
  40f684:	mov    rsi,rcx
  40f687:	mov    edx,0x9b8
  40f68c:	call   408080 <__swc_fn_23cea7fa_000042_facd3e17>
  40f691:	mov    rdi,rax
  40f694:	test   rax,rax
  40f697:	jne    40f6a0 <__swc_fn_23cea7fa_000044_a78ae66b+0x20>
  40f699:	xor    eax,eax
  40f69b:	pop    r12
  40f69d:	pop    rdi
  40f69e:	pop    rsi
  40f69f:	ret
  40f6a0:	vxorps xmm0,xmm0,xmm0
  40f6a4:	xor    eax,eax
  40f6a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40f6b0:	cs nop WORD PTR [rax+rax*1+0x0]
  40f6ba:	nop    WORD PTR [rax+rax*1+0x0]
  40f6c0:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40f6c5:	add    rax,0x10
  40f6c9:	cmp    rax,0x9b0
  40f6d0:	jne    40f6c0 <__swc_fn_23cea7fa_000044_a78ae66b+0x40>
  40f6d2:	mov    QWORD PTR [rdi+0x9b0],0x0
  40f6dd:	mov    QWORD PTR [rdi],rsi
  40f6e0:	call   411840 <__swc_fn_23cea7fa_000134_a9c1c700>
  40f6e5:	mov    QWORD PTR [rdi+0x18],rax
  40f6e9:	lea    r12,[rsi+0x10]
  40f6ed:	mov    rcx,r12
  40f6f0:	call   40e420 <__swc_fn_23cea7fa_000139_86bb0f90>
  40f6f5:	mov    rax,QWORD PTR [rsi+0x20]
  40f6f9:	mov    QWORD PTR [rdi+0x8],rax
  40f6fd:	mov    rax,QWORD PTR [rsi+0x20]
  40f701:	test   rax,rax
  40f704:	je     40f70a <__swc_fn_23cea7fa_000044_a78ae66b+0x8a>
  40f706:	mov    QWORD PTR [rax+0x10],rdi
  40f70a:	mov    QWORD PTR [rsi+0x20],rdi
  40f70e:	mov    rcx,r12
  40f711:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40f716:	mov    rax,rdi
  40f719:	pop    r12
  40f71b:	pop    rdi
  40f71c:	pop    rsi
  40f71d:	ret
	...

000000000040f720 <__swc_fn_23cea7fa_000047_6e7a8d58>:
  40f720:	mov    rax,QWORD PTR [rdx+0x10]
  40f724:	test   rax,rax
  40f727:	je     40f733 <__swc_fn_23cea7fa_000047_6e7a8d58+0x13>
  40f729:	mov    rcx,QWORD PTR [rdx+0x8]
  40f72d:	mov    QWORD PTR [rax+0x8],rcx
  40f731:	jmp    40f73b <__swc_fn_23cea7fa_000047_6e7a8d58+0x1b>
  40f733:	mov    rax,QWORD PTR [rdx+0x8]
  40f737:	mov    QWORD PTR [rcx+0x20],rax
  40f73b:	mov    rax,QWORD PTR [rdx+0x8]
  40f73f:	test   rax,rax
  40f742:	je     40f74c <__swc_fn_23cea7fa_000047_6e7a8d58+0x2c>
  40f744:	mov    rcx,QWORD PTR [rdx+0x10]
  40f748:	mov    QWORD PTR [rax+0x10],rcx
  40f74c:	vxorps xmm0,xmm0,xmm0
  40f750:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40f755:	ret
	...

000000000040f760 <__swc_fn_23cea7fa_000050_129b9bf4>:
  40f760:	sub    rsp,0x8
  40f764:	mov    r9,r8
  40f767:	mov    r10,rdx
  40f76a:	call   408130 <__swc_fn_23cea7fa_000048_137687bb>
  40f76f:	mov    eax,0x1
  40f774:	xchg   DWORD PTR [r9+0x6c],eax
  40f778:	mov    rax,QWORD PTR [r9+0x60]
  40f77c:	test   rax,rax
  40f77f:	je     40f7c3 <__swc_fn_23cea7fa_000050_129b9bf4+0x63>
  40f781:	xor    eax,eax
  40f783:	xchg   DWORD PTR [r9+0x6c],eax
  40f787:	movzx  eax,BYTE PTR [r9+0x39]
  40f78c:	lea    rax,[rax+rax*4]
  40f790:	lea    rax,[r10+rax*8+0x28]
  40f795:	mov    QWORD PTR [r9+0x50],0x0
  40f79d:	mov    rcx,QWORD PTR [rax+0x8]
  40f7a1:	mov    QWORD PTR [r9+0x48],rcx
  40f7a5:	mov    rcx,QWORD PTR [rax+0x8]
  40f7a9:	test   rcx,rcx
  40f7ac:	je     40f7b4 <__swc_fn_23cea7fa_000050_129b9bf4+0x54>
  40f7ae:	mov    QWORD PTR [rcx+0x50],r9
  40f7b2:	jmp    40f7b8 <__swc_fn_23cea7fa_000050_129b9bf4+0x58>
  40f7b4:	mov    QWORD PTR [rax+0x10],r9
  40f7b8:	mov    QWORD PTR [rax+0x8],r9
  40f7bc:	xor    eax,eax
  40f7be:	add    rsp,0x8
  40f7c2:	ret
  40f7c3:	movzx  eax,BYTE PTR [r9+0x39]
  40f7c8:	lea    rax,[rax+rax*4]
  40f7cc:	lea    rax,[r10+rax*8+0x28]
  40f7d1:	mov    QWORD PTR [r9+0x50],0x0
  40f7d9:	mov    rcx,QWORD PTR [rax+0x18]
  40f7dd:	mov    QWORD PTR [r9+0x48],rcx
  40f7e1:	mov    rcx,QWORD PTR [rax+0x18]
  40f7e5:	test   rcx,rcx
  40f7e8:	je     40f7ee <__swc_fn_23cea7fa_000050_129b9bf4+0x8e>
  40f7ea:	mov    QWORD PTR [rcx+0x50],r9
  40f7ee:	mov    QWORD PTR [rax+0x18],r9
  40f7f2:	mov    eax,0x1
  40f7f7:	add    rsp,0x8
  40f7fb:	ret
  40f7fc:	add    BYTE PTR [rax],al
	...

000000000040f800 <__swc_fn_23cea7fa_000053_3af34d7f>:
  40f800:	push   r12
  40f802:	push   r13
  40f804:	push   rdi
  40f805:	push   rsi
  40f806:	push   r14
  40f808:	push   r15
  40f80a:	sub    rsp,0x178
  40f811:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40f81a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40f823:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40f82c:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40f835:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40f83e:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40f847:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40f850:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40f859:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40f862:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40f86b:	mov    r12,rcx
  40f86e:	lea    rax,[rip+0x14993]        # 424208 <__swc_bss_base_23cea7fa+0x1c8>
  40f875:	mov    rcx,QWORD PTR [rax]
  40f878:	mov    r13,rcx
  40f87b:	test   rcx,rcx
  40f87e:	jne    40f88e <__swc_fn_23cea7fa_000053_3af34d7f+0x8e>
  40f880:	mov    r13d,0x1dcd6500
  40f886:	mov    ecx,0x1dcd6500
  40f88b:	xchg   QWORD PTR [rax],rcx
  40f88e:	lea    rax,[rip+0x12773]        # 422008 <__swc_data_base_23cea7fa+0x8>
  40f895:	mov    rax,QWORD PTR [rax]
  40f898:	cmp    rax,0xffffffffffffffff
  40f89c:	je     40f8ab <__swc_fn_23cea7fa_000053_3af34d7f+0xab>
  40f89e:	mov    eax,eax
  40f8a0:	mov    edi,eax
  40f8a2:	xor    eax,eax
  40f8a4:	call   407000 <pthread_getspecific@plt>
  40f8a9:	jmp    40f8ad <__swc_fn_23cea7fa_000053_3af34d7f+0xad>
  40f8ab:	xor    eax,eax
  40f8ad:	test   rax,rax
  40f8b0:	jne    40f8bf <__swc_fn_23cea7fa_000053_3af34d7f+0xbf>
  40f8b2:	call   40f560 <__swc_fn_23cea7fa_000035_cd1a4e8c>
  40f8b7:	mov    rcx,rax
  40f8ba:	call   40a160 <__swc_fn_23cea7fa_000132_5f757033>
  40f8bf:	test   rax,rax
  40f8c2:	je     40f8d4 <__swc_fn_23cea7fa_000053_3af34d7f+0xd4>
  40f8c4:	cmp    QWORD PTR [rax],r12
  40f8c7:	jne    40f8d4 <__swc_fn_23cea7fa_000053_3af34d7f+0xd4>
  40f8c9:	cmp    DWORD PTR [rax+0x20],0x0
  40f8cd:	jne    40f8d4 <__swc_fn_23cea7fa_000053_3af34d7f+0xd4>
  40f8cf:	mov    rsi,rax
  40f8d2:	jmp    40f8d6 <__swc_fn_23cea7fa_000053_3af34d7f+0xd6>
  40f8d4:	xor    esi,esi
  40f8d6:	lea    rdi,[r12+0x2a88]
  40f8de:	mov    r14,QWORD PTR [rdi]
  40f8e1:	test   r14,r14
  40f8e4:	jne    40f933 <__swc_fn_23cea7fa_000053_3af34d7f+0x133>
  40f8e6:	lea    rax,[rip+0x14773]        # 424060 <__swc_bss_base_23cea7fa+0x20>
  40f8ed:	mov    rax,QWORD PTR [rax]
  40f8f0:	test   rax,rax
  40f8f3:	setne  al
  40f8f6:	jne    40f91a <__swc_fn_23cea7fa_000053_3af34d7f+0x11a>
  40f8f8:	mov    rax,QWORD PTR [r12+0x2a70]
  40f900:	test   rax,rax
  40f903:	setne  al
  40f906:	jne    40f91a <__swc_fn_23cea7fa_000053_3af34d7f+0x11a>
  40f908:	test   rsi,rsi
  40f90b:	setne  al
  40f90e:	je     40f91a <__swc_fn_23cea7fa_000053_3af34d7f+0x11a>
  40f910:	cmp    DWORD PTR [rsi+0x730],0x0
  40f917:	setne  al
  40f91a:	test   al,al
  40f91c:	je     40f92e <__swc_fn_23cea7fa_000053_3af34d7f+0x12e>
  40f91e:	call   40a210 <__swc_fn_23cea7fa_000135_07d76562>
  40f923:	lea    rcx,[rax+r13*1]
  40f927:	xor    eax,eax
  40f929:	lock cmpxchg QWORD PTR [rdi],rcx
  40f92e:	jmp    40fa33 <__swc_fn_23cea7fa_000053_3af34d7f+0x233>
  40f933:	call   40a210 <__swc_fn_23cea7fa_000135_07d76562>
  40f938:	mov    r15,rax
  40f93b:	cmp    rax,r14
  40f93e:	jb     40f94f <__swc_fn_23cea7fa_000053_3af34d7f+0x14f>
  40f940:	xor    ecx,ecx
  40f942:	mov    rax,r14
  40f945:	lock cmpxchg QWORD PTR [rdi],rcx
  40f94a:	cmp    rax,r14
  40f94d:	je     40f954 <__swc_fn_23cea7fa_000053_3af34d7f+0x154>
  40f94f:	jmp    40fa33 <__swc_fn_23cea7fa_000053_3af34d7f+0x233>
  40f954:	test   rsi,rsi
  40f957:	je     40f972 <__swc_fn_23cea7fa_000053_3af34d7f+0x172>
  40f959:	cmp    r15,r13
  40f95c:	jb     40f972 <__swc_fn_23cea7fa_000053_3af34d7f+0x172>
  40f95e:	mov    rax,r15
  40f961:	sub    rax,r13
  40f964:	mov    rcx,r12
  40f967:	mov    rdx,rsi
  40f96a:	mov    r8,rax
  40f96d:	call   408570 <__swc_fn_23cea7fa_000063_dea90857>
  40f972:	lea    rsi,[r12+0x10]
  40f977:	mov    rcx,rsi
  40f97a:	call   40e420 <__swc_fn_23cea7fa_000139_86bb0f90>
  40f97f:	mov    rax,QWORD PTR [r12+0x18]
  40f984:	mov    rdi,rax
  40f987:	test   rdi,rdi
  40f98a:	je     40f9b4 <__swc_fn_23cea7fa_000053_3af34d7f+0x1b4>
  40f98c:	cs nop WORD PTR [rax+rax*1+0x0]
  40f996:	cs nop WORD PTR [rax+rax*1+0x0]
  40f9a0:	mov    rcx,rdi
  40f9a3:	call   40c000 <__swc_fn_23cea7fa_000019_adca76cf>
  40f9a8:	mov    rax,QWORD PTR [rdi+0x10]
  40f9ac:	mov    rdi,rax
  40f9af:	test   rax,rax
  40f9b2:	jne    40f9a0 <__swc_fn_23cea7fa_000053_3af34d7f+0x1a0>
  40f9b4:	mov    rcx,rsi
  40f9b7:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40f9bc:	mov    rcx,r12
  40f9bf:	call   40e420 <__swc_fn_23cea7fa_000139_86bb0f90>
  40f9c4:	xor    esi,esi
  40f9c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40f9d0:	mov    rax,QWORD PTR [r12+0x2a70]
  40f9d8:	cmp    rsi,rax
  40f9db:	jae    40fa2b <__swc_fn_23cea7fa_000053_3af34d7f+0x22b>
  40f9dd:	lea    rax,[rsi+rsi*4]
  40f9e1:	lea    rax,[r12+rax*8+0x268]
  40f9e9:	mov    r8,QWORD PTR [rax]
  40f9ec:	mov    r9,QWORD PTR [rax+0x8]
  40f9f0:	mov    r10,QWORD PTR [rax+0x10]
  40f9f4:	mov    rax,QWORD PTR [rax+0x20]
  40f9f8:	cmp    rax,r15
  40f9fb:	jae    40fa08 <__swc_fn_23cea7fa_000053_3af34d7f+0x208>
  40f9fd:	mov    rcx,r15
  40fa00:	sub    rcx,rax
  40fa03:	cmp    rcx,r13
  40fa06:	jae    40fa0d <__swc_fn_23cea7fa_000053_3af34d7f+0x20d>
  40fa08:	inc    rsi
  40fa0b:	jmp    40f9d0 <__swc_fn_23cea7fa_000053_3af34d7f+0x1d0>
  40fa0d:	mov    rcx,r12
  40fa10:	mov    rdx,rsi
  40fa13:	call   408520 <__swc_fn_23cea7fa_000060_15c28ca7>
  40fa18:	mov    rcx,r12
  40fa1b:	mov    rdx,r8
  40fa1e:	mov    r8,r9
  40fa21:	mov    r9,r10
  40fa24:	call   40c2e0 <__swc_fn_23cea7fa_000043_d3c2ab54>
  40fa29:	jmp    40f9d0 <__swc_fn_23cea7fa_000053_3af34d7f+0x1d0>
  40fa2b:	mov    rcx,r12
  40fa2e:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40fa33:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40fa3c:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40fa45:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40fa4e:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40fa57:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40fa60:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40fa69:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40fa72:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40fa7b:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40fa84:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40fa8d:	add    rsp,0x178
  40fa94:	pop    r15
  40fa96:	pop    r14
  40fa98:	pop    rsi
  40fa99:	pop    rdi
  40fa9a:	pop    r13
  40fa9c:	pop    r12
  40fa9e:	ret
	...

000000000040faa0 <__swc_fn_23cea7fa_000056_df0696cd>:
  40faa0:	lea    rax,[rdx-0x58]
  40faa4:	ret
	...

000000000040fab0 <__swc_fn_23cea7fa_000059_2ca0cb05>:
  40fab0:	push   rsi
  40fab1:	push   rdi
  40fab2:	push   r12
  40fab4:	push   r13
  40fab6:	sub    rsp,0x68
  40faba:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40fac0:	mov    rsi,r9
  40fac3:	mov    rdi,rcx
  40fac6:	mov    r12,rdx
  40fac9:	mov    r13,r8
  40facc:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40fad4:	jne    40fae3 <__swc_fn_23cea7fa_000059_2ca0cb05+0x33>
  40fad6:	xor    eax,eax
  40fad8:	add    rsp,0x68
  40fadc:	pop    r13
  40fade:	pop    r12
  40fae0:	pop    rdi
  40fae1:	pop    rsi
  40fae2:	ret
  40fae3:	mov    rcx,rdi
  40fae6:	call   40e420 <__swc_fn_23cea7fa_000139_86bb0f90>
  40faeb:	movabs rax,0x7fffffffffffffff
  40faf5:	cmp    r12,rax
  40faf8:	mov    rax,0xffffffffffffffff
  40faff:	lea    rcx,[r12+r12*1]
  40fb03:	cmovbe rax,rcx
  40fb07:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40fb0e:	mov    rdx,rcx
  40fb11:	sub    rax,r12
  40fb14:	inc    rax
  40fb17:	xor    r8d,r8d
  40fb1a:	test   rcx,rcx
  40fb1d:	jbe    40fb48 <__swc_fn_23cea7fa_000059_2ca0cb05+0x98>
  40fb1f:	nop
  40fb20:	lea    r9,[r8+r8*4]
  40fb24:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40fb2c:	sub    r9,r12
  40fb2f:	cmp    r9,rax
  40fb32:	jae    40fb3f <__swc_fn_23cea7fa_000059_2ca0cb05+0x8f>
  40fb34:	mov    rdx,r8
  40fb37:	mov    rax,r9
  40fb3a:	test   r9,r9
  40fb3d:	je     40fb48 <__swc_fn_23cea7fa_000059_2ca0cb05+0x98>
  40fb3f:	add    r8,0x1
  40fb43:	cmp    r8,rcx
  40fb46:	jb     40fb20 <__swc_fn_23cea7fa_000059_2ca0cb05+0x70>
  40fb48:	mov    rax,QWORD PTR [rdi+0x2a70]
  40fb4f:	cmp    rdx,rax
  40fb52:	jne    40fb6f <__swc_fn_23cea7fa_000059_2ca0cb05+0xbf>
  40fb54:	mov    rcx,rdi
  40fb57:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40fb5c:	xor    eax,eax
  40fb5e:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40fb64:	add    rsp,0x68
  40fb68:	pop    r13
  40fb6a:	pop    r12
  40fb6c:	pop    rdi
  40fb6d:	pop    rsi
  40fb6e:	ret
  40fb6f:	lea    rax,[rdx+rdx*4]
  40fb73:	lea    rax,[rdi+rax*8+0x268]
  40fb7b:	vmovups xmm6,XMMWORD PTR [rax]
  40fb7f:	mov    r8,QWORD PTR [rax+0x10]
  40fb83:	mov    rcx,rdi
  40fb86:	call   408520 <__swc_fn_23cea7fa_000060_15c28ca7>
  40fb8b:	vpshufd xmm0,xmm6,0xee
  40fb90:	vmovsd QWORD PTR [r13+0x0],xmm0
  40fb96:	mov    QWORD PTR [rsi],r8
  40fb99:	mov    rcx,rdi
  40fb9c:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40fba1:	vmovq  rax,xmm6
  40fba6:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40fbac:	add    rsp,0x68
  40fbb0:	pop    r13
  40fbb2:	pop    r12
  40fbb4:	pop    rdi
  40fbb5:	pop    rsi
  40fbb6:	ret
	...

000000000040fbc0 <__swc_fn_23cea7fa_000062_b304235a>:
  40fbc0:	push   r12
  40fbc2:	push   r13
  40fbc4:	push   r14
  40fbc6:	push   r15
  40fbc8:	push   rdi
  40fbc9:	push   rsi
  40fbca:	sub    rsp,0x148
  40fbd1:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40fbda:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40fbe3:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40fbec:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40fbf5:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40fbfe:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40fc07:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40fc10:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40fc19:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40fc22:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40fc2b:	mov    r12,r9
  40fc2e:	mov    r13,rcx
  40fc31:	mov    r14,rdx
  40fc34:	mov    r15,r8
  40fc37:	test   rdx,rdx
  40fc3a:	jne    40fc4e <__swc_fn_23cea7fa_000062_b304235a+0x8e>
  40fc3c:	add    rsp,0x148
  40fc43:	pop    rsi
  40fc44:	pop    rdi
  40fc45:	pop    r15
  40fc47:	pop    r14
  40fc49:	pop    r13
  40fc4b:	pop    r12
  40fc4d:	ret
  40fc4e:	cmp    r12,0x200000
  40fc55:	ja     40fce7 <__swc_fn_23cea7fa_000062_b304235a+0x127>
  40fc5b:	lea    rax,[rip+0x123a6]        # 422008 <__swc_data_base_23cea7fa+0x8>
  40fc62:	mov    rax,QWORD PTR [rax]
  40fc65:	cmp    rax,0xffffffffffffffff
  40fc69:	je     40fc78 <__swc_fn_23cea7fa_000062_b304235a+0xb8>
  40fc6b:	mov    eax,eax
  40fc6d:	mov    edi,eax
  40fc6f:	xor    eax,eax
  40fc71:	call   407000 <pthread_getspecific@plt>
  40fc76:	jmp    40fc7a <__swc_fn_23cea7fa_000062_b304235a+0xba>
  40fc78:	xor    eax,eax
  40fc7a:	test   rax,rax
  40fc7d:	je     40fc84 <__swc_fn_23cea7fa_000062_b304235a+0xc4>
  40fc7f:	mov    rsi,rax
  40fc82:	jmp    40fc94 <__swc_fn_23cea7fa_000062_b304235a+0xd4>
  40fc84:	call   40f560 <__swc_fn_23cea7fa_000035_cd1a4e8c>
  40fc89:	mov    rcx,rax
  40fc8c:	call   40a160 <__swc_fn_23cea7fa_000132_5f757033>
  40fc91:	mov    rsi,rax
  40fc94:	test   rsi,rsi
  40fc97:	je     40fce7 <__swc_fn_23cea7fa_000062_b304235a+0x127>
  40fc99:	cmp    QWORD PTR [rsi],r13
  40fc9c:	jne    40fce7 <__swc_fn_23cea7fa_000062_b304235a+0x127>
  40fc9e:	cmp    DWORD PTR [rsi+0x20],0x0
  40fca2:	jne    40fce7 <__swc_fn_23cea7fa_000062_b304235a+0x127>
  40fca4:	cmp    DWORD PTR [rsi+0x730],0x10
  40fcab:	jae    40fce7 <__swc_fn_23cea7fa_000062_b304235a+0x127>
  40fcad:	mov    eax,DWORD PTR [rsi+0x730]
  40fcb3:	lea    rdi,[rax+rax*4]
  40fcb7:	lea    rdi,[rsi+rdi*8+0x738]
  40fcbf:	mov    QWORD PTR [rdi],r14
  40fcc2:	mov    QWORD PTR [rdi+0x8],r15
  40fcc6:	mov    QWORD PTR [rdi+0x10],r12
  40fcca:	mov    QWORD PTR [rdi+0x18],0x0
  40fcd2:	call   40a210 <__swc_fn_23cea7fa_000135_07d76562>
  40fcd7:	mov    QWORD PTR [rdi+0x20],rax
  40fcdb:	add    DWORD PTR [rsi+0x730],0x1
  40fce2:	jmp    40fe46 <__swc_fn_23cea7fa_000062_b304235a+0x286>
  40fce7:	mov    rcx,r13
  40fcea:	call   40ca10 <__swc_fn_23cea7fa_000061_ad030a10>
  40fcef:	mov    rsi,rax
  40fcf2:	cmp    r12,rax
  40fcf5:	jbe    40fd2a <__swc_fn_23cea7fa_000062_b304235a+0x16a>
  40fcf7:	cmp    r12,0x10000000
  40fcfe:	seta   al
  40fd01:	ja     40fd10 <__swc_fn_23cea7fa_000062_b304235a+0x150>
  40fd03:	mov    rax,QWORD PTR [r13+0x2a70]
  40fd0a:	test   rax,rax
  40fd0d:	setne  al
  40fd10:	test   al,al
  40fd12:	je     40fd2a <__swc_fn_23cea7fa_000062_b304235a+0x16a>
  40fd14:	mov    rcx,r13
  40fd17:	mov    rdx,r14
  40fd1a:	mov    r8,r15
  40fd1d:	mov    r9,r12
  40fd20:	call   40c2e0 <__swc_fn_23cea7fa_000043_d3c2ab54>
  40fd25:	jmp    40fe46 <__swc_fn_23cea7fa_000062_b304235a+0x286>
  40fd2a:	call   40a210 <__swc_fn_23cea7fa_000135_07d76562>
  40fd2f:	mov    rdi,rax
  40fd32:	mov    rcx,r13
  40fd35:	call   40e420 <__swc_fn_23cea7fa_000139_86bb0f90>
  40fd3a:	cmp    QWORD PTR [r13+0x2a70],0x0
  40fd42:	je     40fdfa <__swc_fn_23cea7fa_000062_b304235a+0x23a>
  40fd48:	nop    DWORD PTR [rax+rax*1+0x0]
  40fd50:	cmp    QWORD PTR [r13+0x2a70],0x100
  40fd5b:	jae    40fd70 <__swc_fn_23cea7fa_000062_b304235a+0x1b0>
  40fd5d:	mov    rax,QWORD PTR [r13+0x2a68]
  40fd64:	add    rax,r12
  40fd67:	cmp    rax,rsi
  40fd6a:	jbe    40fdfa <__swc_fn_23cea7fa_000062_b304235a+0x23a>
  40fd70:	xor    eax,eax
  40fd72:	mov    rcx,QWORD PTR [r13+0x2a70]
  40fd79:	mov    edx,0x1
  40fd7e:	cmp    rcx,0x1
  40fd82:	jbe    40fdb9 <__swc_fn_23cea7fa_000062_b304235a+0x1f9>
  40fd84:	cs nop WORD PTR [rax+rax*1+0x0]
  40fd8e:	xchg   ax,ax
  40fd90:	lea    r8,[rdx+rdx*4]
  40fd94:	lea    r8,[r13+r8*8+0x268]
  40fd9c:	lea    r9,[rax+rax*4]
  40fda0:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40fda8:	cmp    QWORD PTR [r8+0x18],r9
  40fdac:	cmovb  rax,rdx
  40fdb0:	add    rdx,0x1
  40fdb4:	cmp    rdx,rcx
  40fdb7:	jb     40fd90 <__swc_fn_23cea7fa_000062_b304235a+0x1d0>
  40fdb9:	lea    rcx,[rax+rax*4]
  40fdbd:	lea    rcx,[r13+rcx*8+0x268]
  40fdc5:	mov    r8,QWORD PTR [rcx]
  40fdc8:	mov    r9,QWORD PTR [rcx+0x8]
  40fdcc:	mov    r10,QWORD PTR [rcx+0x10]
  40fdd0:	mov    rcx,r13
  40fdd3:	mov    rdx,rax
  40fdd6:	call   408520 <__swc_fn_23cea7fa_000060_15c28ca7>
  40fddb:	mov    rcx,r13
  40fdde:	mov    rdx,r8
  40fde1:	mov    r8,r9
  40fde4:	mov    r9,r10
  40fde7:	call   40c2e0 <__swc_fn_23cea7fa_000043_d3c2ab54>
  40fdec:	cmp    QWORD PTR [r13+0x2a70],0x0
  40fdf4:	jne    40fd50 <__swc_fn_23cea7fa_000062_b304235a+0x190>
  40fdfa:	add    QWORD PTR [r13+0x2a78],0x1
  40fe02:	mov    rax,QWORD PTR [r13+0x2a70]
  40fe09:	lea    rax,[rax+rax*4]
  40fe0d:	lea    rax,[r13+rax*8+0x268]
  40fe15:	mov    QWORD PTR [rax],r14
  40fe18:	mov    QWORD PTR [rax+0x8],r15
  40fe1c:	mov    QWORD PTR [rax+0x10],r12
  40fe20:	mov    rcx,QWORD PTR [r13+0x2a78]
  40fe27:	mov    QWORD PTR [rax+0x18],rcx
  40fe2b:	mov    QWORD PTR [rax+0x20],rdi
  40fe2f:	add    QWORD PTR [r13+0x2a68],r12
  40fe36:	add    QWORD PTR [r13+0x2a70],0x1
  40fe3e:	mov    rcx,r13
  40fe41:	call   4119f0 <__swc_fn_23cea7fa_000140_055b38a4>
  40fe46:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40fe4f:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40fe58:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40fe61:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40fe6a:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40fe73:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40fe7c:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40fe85:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40fe8e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40fe97:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40fea0:	add    rsp,0x148
  40fea7:	pop    rsi
  40fea8:	pop    rdi
  40fea9:	pop    r15
  40feab:	pop    r14
  40fead:	pop    r13
  40feaf:	pop    r12
  40feb1:	ret
	...

000000000040fec0 <__swc_fn_23cea7fa_000065_d9ee99ea>:
  40fec0:	push   rbx
  40fec1:	push   r12
  40fec3:	push   r13
  40fec5:	push   r14
  40fec7:	push   r15
  40fec9:	push   rdi
  40feca:	push   rsi
  40fecb:	sub    rsp,0xf0
  40fed2:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40fed8:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40fede:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40fee4:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40feea:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40fef3:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40fefc:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40ff05:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40ff0e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40ff17:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40ff20:	mov    eax,r8d
  40ff23:	mov    rbx,rcx
  40ff26:	mov    r12,rdx
  40ff29:	mov    QWORD PTR [rsp+0x18],rdx
  40ff2e:	mov    ecx,DWORD PTR [r12+0x58]
  40ff33:	mov    r13d,ecx
  40ff36:	cmp    ecx,0x10
  40ff39:	mov    ecx,0x10
  40ff3e:	cmovb  r13d,ecx
  40ff42:	test   r13d,r13d
  40ff45:	mov    rcx,r13
  40ff48:	mov    edx,0x8
  40ff4d:	cmove  ecx,edx
  40ff50:	dec    rcx
  40ff53:	mov    rdx,0xffffffffffffffff
  40ff5a:	sub    rdx,rcx
  40ff5d:	xor    r14d,r14d
  40ff60:	mov    r8,rcx
  40ff63:	not    r8
  40ff66:	lea    rcx,[rcx+0x58]
  40ff6a:	and    rcx,r8
  40ff6d:	cmp    rdx,0x58
  40ff71:	cmovae r14,rcx
  40ff75:	cmp    eax,0xffffffff
  40ff78:	jne    40ff81 <__swc_fn_23cea7fa_000065_d9ee99ea+0xc1>
  40ff7a:	mov    r15,QWORD PTR [r12+0x48]
  40ff7f:	jmp    40ffb3 <__swc_fn_23cea7fa_000065_d9ee99ea+0xf3>
  40ff81:	test   eax,eax
  40ff83:	jne    40ff8c <__swc_fn_23cea7fa_000065_d9ee99ea+0xcc>
  40ff85:	mov    eax,0x8
  40ff8a:	jmp    40ffb0 <__swc_fn_23cea7fa_000065_d9ee99ea+0xf0>
  40ff8c:	cmp    eax,0x8
  40ff8f:	ja     40ff97 <__swc_fn_23cea7fa_000065_d9ee99ea+0xd7>
  40ff91:	shl    rax,0x4
  40ff95:	jmp    40ffb0 <__swc_fn_23cea7fa_000065_d9ee99ea+0xf0>
  40ff97:	lea    eax,[rax-0x9]
  40ff9a:	mov    ecx,eax
  40ff9c:	shr    ecx,0x2
  40ff9f:	and    eax,0x3
  40ffa2:	lea    ecx,[rcx+0x7]
  40ffa5:	lea    ecx,[rcx-0x2]
  40ffa8:	lea    eax,[rax+0x5]
  40ffab:	shlx   rax,rax,rcx
  40ffb0:	mov    r15,rax
  40ffb3:	lea    rax,[r14+r13*1]
  40ffb7:	mov    rcx,0xffffffffffffffff
  40ffbe:	sub    rcx,rax
  40ffc1:	cmp    r15,rcx
  40ffc4:	jbe    40ffd4 <__swc_fn_23cea7fa_000065_d9ee99ea+0x114>
  40ffc6:	mov    QWORD PTR [r12+0x40],0x0
  40ffcf:	jmp    4103a6 <__swc_fn_23cea7fa_000065_d9ee99ea+0x4e6>
  40ffd4:	mov    QWORD PTR [rsp+0x20],r13
  40ffd9:	lea    r13,[rsp+0x8]
  40ffde:	add    rax,r15
  40ffe1:	mov    ecx,0x1000
  40ffe6:	test   ecx,ecx
  40ffe8:	mov    edx,0x8
  40ffed:	cmove  ecx,edx
  40fff0:	dec    rcx
  40fff3:	mov    rdx,0xffffffffffffffff
  40fffa:	sub    rdx,rcx
  40fffd:	cmp    rax,rdx
  410000:	jbe    41000c <__swc_fn_23cea7fa_000065_d9ee99ea+0x14c>
  410002:	mov    QWORD PTR [r13+0x0],0x0
  41000a:	jmp    410019 <__swc_fn_23cea7fa_000065_d9ee99ea+0x159>
  41000c:	add    rax,rcx
  41000f:	andn   rax,rcx,rax
  410014:	mov    QWORD PTR [rsp+0x8],rax
  410019:	cmp    QWORD PTR [r13+0x0],0x0
  41001e:	jne    41002e <__swc_fn_23cea7fa_000065_d9ee99ea+0x16e>
  410020:	mov    QWORD PTR [r12+0x40],0x0
  410029:	jmp    4103a6 <__swc_fn_23cea7fa_000065_d9ee99ea+0x4e6>
  41002e:	mov    QWORD PTR [rsp+0x30],r15
  410033:	xor    r15d,r15d
  410036:	mov    QWORD PTR [rsp+0x38],0x0
  41003f:	lea    r12,[rsp+0x10]
  410044:	mov    QWORD PTR [rsp+0x28],r14
  410049:	mov    r14,QWORD PTR [rsp+0x8]
  41004e:	mov    QWORD PTR [rsp+0x10],r14
  410053:	cmp    r14,0x10000
  41005a:	ja     410061 <__swc_fn_23cea7fa_000065_d9ee99ea+0x1a1>
  41005c:	mov    rax,r14
  41005f:	jmp    4100b2 <__swc_fn_23cea7fa_000065_d9ee99ea+0x1f2>
  410061:	xor    eax,eax
  410063:	lea    rcx,[r14-0x1]
  410067:	lzcnt  rax,rcx
  41006c:	mov    ecx,0x3f
  410071:	sub    rcx,rax
  410074:	mov    eax,0x1
  410079:	lea    rcx,[rcx-0x3]
  41007d:	shl    rax,cl
  410080:	mov    rcx,rax
  410083:	cmp    rax,0x1000
  41008a:	mov    eax,0x1000
  41008f:	cmovb  rcx,rax
  410093:	mov    rdx,0xffffffffffffffff
  41009a:	sub    rdx,rcx
  41009d:	mov    rax,r14
  4100a0:	lea    r8,[r14+rcx*1-0x1]
  4100a5:	neg    rcx
  4100a8:	and    r8,rcx
  4100ab:	cmp    r14,rdx
  4100ae:	cmovbe rax,r8
  4100b2:	mov    QWORD PTR [rsp+0x8],rax
  4100b7:	lea    rax,[rip+0x11f4a]        # 422008 <__swc_data_base_23cea7fa+0x8>
  4100be:	mov    rax,QWORD PTR [rax]
  4100c1:	cmp    rax,0xffffffffffffffff
  4100c5:	je     4100d4 <__swc_fn_23cea7fa_000065_d9ee99ea+0x214>
  4100c7:	mov    eax,eax
  4100c9:	mov    edi,eax
  4100cb:	xor    eax,eax
  4100cd:	call   407000 <pthread_getspecific@plt>
  4100d2:	jmp    4100d6 <__swc_fn_23cea7fa_000065_d9ee99ea+0x216>
  4100d4:	xor    eax,eax
  4100d6:	test   rax,rax
  4100d9:	jne    4100e8 <__swc_fn_23cea7fa_000065_d9ee99ea+0x228>
  4100db:	call   40f560 <__swc_fn_23cea7fa_000035_cd1a4e8c>
  4100e0:	mov    rcx,rax
  4100e3:	call   40a160 <__swc_fn_23cea7fa_000132_5f757033>
  4100e8:	test   rax,rax
  4100eb:	je     4101dc <__swc_fn_23cea7fa_000065_d9ee99ea+0x31c>
  4100f1:	cmp    QWORD PTR [rax],rbx
  4100f4:	jne    4101dc <__swc_fn_23cea7fa_000065_d9ee99ea+0x31c>
  4100fa:	cmp    DWORD PTR [rax+0x20],0x0
  4100fe:	jne    4101dc <__swc_fn_23cea7fa_000065_d9ee99ea+0x31c>
  410104:	mov    rcx,QWORD PTR [rsp+0x8]
  410109:	movabs rdx,0x7fffffffffffffff
  410113:	cmp    rcx,rdx
  410116:	mov    rdx,0xffffffffffffffff
  41011d:	lea    r8,[rcx+rcx*1]
  410121:	cmovbe rdx,r8
  410125:	mov    r8d,DWORD PTR [rax+0x730]
  41012c:	mov    r9d,r8d
  41012f:	sub    rdx,rcx
  410132:	inc    rdx
  410135:	xor    r10d,r10d
  410138:	test   r8,r8
  41013b:	jbe    41016b <__swc_fn_23cea7fa_000065_d9ee99ea+0x2ab>
  41013d:	nop    DWORD PTR [rax]
  410140:	mov    r11d,r10d
  410143:	lea    r11,[r11+r11*4]
  410147:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  41014f:	sub    r11,rcx
  410152:	cmp    r11,rdx
  410155:	jae    410162 <__swc_fn_23cea7fa_000065_d9ee99ea+0x2a2>
  410157:	mov    r9d,r10d
  41015a:	mov    rdx,r11
  41015d:	test   r11,r11
  410160:	je     41016b <__swc_fn_23cea7fa_000065_d9ee99ea+0x2ab>
  410162:	add    r10,0x1
  410166:	cmp    r10,r8
  410169:	jb     410140 <__swc_fn_23cea7fa_000065_d9ee99ea+0x280>
  41016b:	mov    ecx,DWORD PTR [rax+0x730]
  410171:	cmp    r9d,ecx
  410174:	jne    41017a <__swc_fn_23cea7fa_000065_d9ee99ea+0x2ba>
  410176:	xor    eax,eax
  410178:	jmp    4101d9 <__swc_fn_23cea7fa_000065_d9ee99ea+0x319>
  41017a:	lea    rcx,[r9+r9*4]
  41017e:	lea    rcx,[rax+rcx*8+0x738]
  410186:	vmovups xmm0,XMMWORD PTR [rcx]
  41018a:	mov    rdx,QWORD PTR [rcx+0x10]
  41018e:	sub    DWORD PTR [rax+0x730],0x1
  410195:	mov    r8d,DWORD PTR [rax+0x730]
  41019c:	lea    r8,[r8+r8*4]
  4101a0:	lea    r8,[rax+r8*8+0x738]
  4101a8:	vmovups xmm1,XMMWORD PTR [r8]
  4101ad:	vmovups XMMWORD PTR [rcx],xmm1
  4101b1:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  4101b7:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  4101bc:	mov    rax,QWORD PTR [r8+0x20]
  4101c0:	mov    QWORD PTR [rcx+0x20],rax
  4101c4:	vpshufd xmm1,xmm0,0xee
  4101c9:	vmovsd QWORD PTR [rsp+0x8],xmm1
  4101cf:	mov    QWORD PTR [rsp+0x10],rdx
  4101d4:	vmovq  rax,xmm0
  4101d9:	mov    r15,rax
  4101dc:	test   r15,r15
  4101df:	jne    4101f7 <__swc_fn_23cea7fa_000065_d9ee99ea+0x337>
  4101e1:	mov    rcx,rbx
  4101e4:	mov    rdx,QWORD PTR [rsp+0x8]
  4101e9:	mov    r8,r13
  4101ec:	mov    r9,r12
  4101ef:	call   40fab0 <__swc_fn_23cea7fa_000059_2ca0cb05>
  4101f4:	mov    r15,rax
  4101f7:	test   r15,r15
  4101fa:	je     41023b <__swc_fn_23cea7fa_000065_d9ee99ea+0x37b>
  4101fc:	cmp    QWORD PTR [r12],r14
  410200:	jae    41023b <__swc_fn_23cea7fa_000065_d9ee99ea+0x37b>
  410202:	mov    rax,r15
  410205:	add    rax,QWORD PTR [r12]
  410209:	mov    rdx,r14
  41020c:	sub    rdx,QWORD PTR [r12]
  410210:	mov    rcx,rax
  410213:	call   40be30 <__swc_fn_23cea7fa_000007_f7acedb0>
  410218:	test   al,al
  41021a:	je     410223 <__swc_fn_23cea7fa_000065_d9ee99ea+0x363>
  41021c:	mov    QWORD PTR [rsp+0x10],r14
  410221:	jmp    41023b <__swc_fn_23cea7fa_000065_d9ee99ea+0x37b>
  410223:	mov    rcx,rbx
  410226:	mov    rdx,r15
  410229:	mov    r8,QWORD PTR [rsp+0x8]
  41022e:	mov    r9,QWORD PTR [rsp+0x10]
  410233:	call   40fbc0 <__swc_fn_23cea7fa_000062_b304235a>
  410238:	xor    r15d,r15d
  41023b:	test   r15,r15
  41023e:	jne    4102ba <__swc_fn_23cea7fa_000065_d9ee99ea+0x3fa>
  410240:	cmp    r14,0x10000
  410247:	ja     41024e <__swc_fn_23cea7fa_000065_d9ee99ea+0x38e>
  410249:	mov    rax,r14
  41024c:	jmp    41029f <__swc_fn_23cea7fa_000065_d9ee99ea+0x3df>
  41024e:	xor    eax,eax
  410250:	lea    rcx,[r14-0x1]
  410254:	lzcnt  rax,rcx
  410259:	mov    ecx,0x3f
  41025e:	sub    rcx,rax
  410261:	mov    eax,0x1
  410266:	lea    rcx,[rcx-0x3]
  41026a:	shl    rax,cl
  41026d:	mov    rcx,rax
  410270:	cmp    rax,0x1000
  410277:	mov    eax,0x1000
  41027c:	cmovb  rcx,rax
  410280:	mov    rdx,0xffffffffffffffff
  410287:	sub    rdx,rcx
  41028a:	mov    rax,r14
  41028d:	lea    r8,[r14+rcx*1-0x1]
  410292:	neg    rcx
  410295:	and    r8,rcx
  410298:	cmp    r14,rdx
  41029b:	cmovbe rax,r8
  41029f:	mov    QWORD PTR [rsp+0x8],rax
  4102a4:	mov    QWORD PTR [rsp+0x10],r14
  4102a9:	mov    rcx,rbx
  4102ac:	mov    rdx,rax
  4102af:	mov    r8,r14
  4102b2:	call   40f620 <__swc_fn_23cea7fa_000041_c90d80c1>
  4102b7:	mov    r15,rax
  4102ba:	test   r15,r15
  4102bd:	jne    4102cb <__swc_fn_23cea7fa_000065_d9ee99ea+0x40b>
  4102bf:	mov    r13,QWORD PTR [rsp+0x20]
  4102c4:	mov    rsi,QWORD PTR [rsp+0x38]
  4102c9:	jmp    410307 <__swc_fn_23cea7fa_000065_d9ee99ea+0x447>
  4102cb:	mov    rax,r15
  4102ce:	add    rax,QWORD PTR [rsp+0x28]
  4102d3:	mov    r13,QWORD PTR [rsp+0x20]
  4102d8:	test   r13d,r13d
  4102db:	mov    rcx,r13
  4102de:	mov    edx,0x8
  4102e3:	cmove  ecx,edx
  4102e6:	dec    rcx
  4102e9:	mov    rdx,0xffffffffffffffff
  4102f0:	sub    rdx,rcx
  4102f3:	cmp    rax,rdx
  4102f6:	jbe    4102fc <__swc_fn_23cea7fa_000065_d9ee99ea+0x43c>
  4102f8:	xor    eax,eax
  4102fa:	jmp    410304 <__swc_fn_23cea7fa_000065_d9ee99ea+0x444>
  4102fc:	add    rax,rcx
  4102ff:	andn   rax,rcx,rax
  410304:	mov    rsi,rax
  410307:	mov    rax,QWORD PTR [rsp+0x8]
  41030c:	test   r15,r15
  41030f:	je     410318 <__swc_fn_23cea7fa_000065_d9ee99ea+0x458>
  410311:	mov    rdi,QWORD PTR [rsp+0x18]
  410316:	jmp    41032a <__swc_fn_23cea7fa_000065_d9ee99ea+0x46a>
  410318:	mov    rdi,QWORD PTR [rsp+0x18]
  41031d:	mov    QWORD PTR [rdi+0x40],0x0
  410325:	jmp    4103a6 <__swc_fn_23cea7fa_000065_d9ee99ea+0x4e6>
  41032a:	lea    rdx,[rsi-0x58]
  41032e:	mov    QWORD PTR [rsi-0x58],r15
  410332:	mov    QWORD PTR [rsi-0x50],rax
  410336:	mov    rax,QWORD PTR [rsp+0x10]
  41033b:	mov    QWORD PTR [rsi-0x48],rax
  41033f:	mov    QWORD PTR [rsi-0x40],rsi
  410343:	mov    rax,QWORD PTR [rdi+0x48]
  410347:	mov    QWORD PTR [rsi-0x38],rax
  41034b:	mov    rax,QWORD PTR [rsp+0x30]
  410350:	mov    QWORD PTR [rsi-0x30],rax
  410354:	mov    DWORD PTR [rsi-0x10],r13d
  410358:	mov    QWORD PTR [rsi-0x28],0x0
  410360:	mov    QWORD PTR [rsi-0x20],0x0
  410368:	add    r15,QWORD PTR [r12]
  41036c:	sub    r15,rsi
  41036f:	mov    QWORD PTR [rsi-0x30],r15
  410373:	mov    rcx,QWORD PTR [rbx+0x250]
  41037a:	nop    WORD PTR [rax+rax*1+0x0]
  410380:	lea    r8,[rcx+r15*1]
  410384:	mov    rax,rcx
  410387:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  410390:	cmp    rax,rcx
  410393:	je     41039a <__swc_fn_23cea7fa_000065_d9ee99ea+0x4da>
  410395:	mov    rcx,rax
  410398:	jmp    410380 <__swc_fn_23cea7fa_000065_d9ee99ea+0x4c0>
  41039a:	mov    rcx,rbx
  41039d:	call   408490 <__swc_fn_23cea7fa_000057_7e1dbcb0>
  4103a2:	mov    QWORD PTR [rdi+0x40],rsi
  4103a6:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  4103ac:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  4103b2:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  4103b8:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  4103be:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  4103c7:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  4103d0:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  4103d9:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  4103e2:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  4103eb:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  4103f4:	add    rsp,0xf0
  4103fb:	pop    rsi
  4103fc:	pop    rdi
  4103fd:	pop    r15
  4103ff:	pop    r14
  410401:	pop    r13
  410403:	pop    r12
  410405:	pop    rbx
  410406:	ret
	...

0000000000410410 <__swc_fn_23cea7fa_000068_f3aa21af>:
  410410:	push   rbx
  410411:	push   r12
  410413:	push   rdi
  410414:	push   rsi
  410415:	sub    rsp,0xb8
  41041c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  410422:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410428:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41042e:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410434:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  41043a:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  410440:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410446:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41044f:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410458:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  410461:	mov    rbx,rdx
  410464:	mov    r12,rcx
  410467:	cmp    DWORD PTR [rbx+0x58],0x0
  41046b:	je     410485 <__swc_fn_23cea7fa_000068_f3aa21af+0x75>
  41046d:	mov    eax,DWORD PTR [rbx+0x58]
  410470:	sub    eax,0x1
  410473:	test   DWORD PTR [rbx+0x58],eax
  410476:	je     410485 <__swc_fn_23cea7fa_000068_f3aa21af+0x75>
  410478:	mov    QWORD PTR [rbx+0x40],0x0
  410480:	jmp    410697 <__swc_fn_23cea7fa_000068_f3aa21af+0x287>
  410485:	cmp    QWORD PTR [rbx+0x48],0x0
  41048a:	jne    410499 <__swc_fn_23cea7fa_000068_f3aa21af+0x89>
  41048c:	mov    QWORD PTR [rbx+0x40],0x0
  410494:	jmp    410697 <__swc_fn_23cea7fa_000068_f3aa21af+0x287>
  410499:	lea    rax,[rsp+0x8]
  41049e:	mov    rcx,QWORD PTR [rbx+0x48]
  4104a2:	cmp    rcx,0x8
  4104a6:	ja     4104b0 <__swc_fn_23cea7fa_000068_f3aa21af+0xa0>
  4104a8:	mov    DWORD PTR [rax],0x0
  4104ae:	jmp    41050b <__swc_fn_23cea7fa_000068_f3aa21af+0xfb>
  4104b0:	cmp    rcx,0x80
  4104b7:	ja     4104c7 <__swc_fn_23cea7fa_000068_f3aa21af+0xb7>
  4104b9:	lea    rcx,[rcx+0xf]
  4104bd:	shr    rcx,0x4
  4104c1:	mov    DWORD PTR [rsp+0x8],ecx
  4104c5:	jmp    41050b <__swc_fn_23cea7fa_000068_f3aa21af+0xfb>
  4104c7:	cmp    rcx,0x10000
  4104ce:	jbe    4104d8 <__swc_fn_23cea7fa_000068_f3aa21af+0xc8>
  4104d0:	mov    DWORD PTR [rax],0xffffffff
  4104d6:	jmp    41050b <__swc_fn_23cea7fa_000068_f3aa21af+0xfb>
  4104d8:	dec    rcx
  4104db:	xor    edx,edx
  4104dd:	lzcnt  rdx,rcx
  4104e2:	mov    r8d,0x3f
  4104e8:	sub    r8d,edx
  4104eb:	lea    edx,[r8-0x2]
  4104ef:	shrx   rcx,rcx,rdx
  4104f4:	and    ecx,0x3
  4104f7:	lea    edx,[r8-0x7]
  4104fb:	lea    edx,[rdx*4+0x0]
  410502:	lea    edx,[rdx+0x9]
  410505:	add    edx,ecx
  410507:	mov    DWORD PTR [rsp+0x8],edx
  41050b:	cmp    DWORD PTR [rax],0x0
  41050e:	jne    41051e <__swc_fn_23cea7fa_000068_f3aa21af+0x10e>
  410510:	cmp    DWORD PTR [rbx+0x58],0x8
  410514:	jbe    41051e <__swc_fn_23cea7fa_000068_f3aa21af+0x10e>
  410516:	mov    DWORD PTR [rsp+0x8],0x1
  41051e:	cmp    DWORD PTR [rbx+0x58],0x10
  410522:	jbe    4105a1 <__swc_fn_23cea7fa_000068_f3aa21af+0x191>
  410528:	cmp    DWORD PTR [rbx+0x58],0x40
  41052c:	ja     4105a1 <__swc_fn_23cea7fa_000068_f3aa21af+0x191>
  41052e:	cmp    DWORD PTR [rax],0xffffffff
  410531:	je     4105a1 <__swc_fn_23cea7fa_000068_f3aa21af+0x191>
  410533:	mov    ecx,DWORD PTR [rsp+0x8]
  410537:	mov    edx,DWORD PTR [rbx+0x58]
  41053a:	dec    rdx
  41053d:	cmp    ecx,0x2d
  410540:	jae    410598 <__swc_fn_23cea7fa_000068_f3aa21af+0x188>
  410542:	cs nop WORD PTR [rax+rax*1+0x0]
  41054c:	nop    DWORD PTR [rax+0x0]
  410550:	mov    r8d,ecx
  410553:	test   ecx,ecx
  410555:	jne    41055f <__swc_fn_23cea7fa_000068_f3aa21af+0x14f>
  410557:	mov    r8d,0x8
  41055d:	jmp    41058b <__swc_fn_23cea7fa_000068_f3aa21af+0x17b>
  41055f:	cmp    r8d,0x8
  410563:	ja     41056b <__swc_fn_23cea7fa_000068_f3aa21af+0x15b>
  410565:	shl    r8,0x4
  410569:	jmp    41058b <__swc_fn_23cea7fa_000068_f3aa21af+0x17b>
  41056b:	lea    r8d,[r8-0x9]
  41056f:	mov    r9d,r8d
  410572:	shr    r9d,0x2
  410576:	and    r8d,0x3
  41057a:	lea    r9d,[r9+0x7]
  41057e:	lea    r9d,[r9-0x2]
  410582:	lea    r8d,[r8+0x5]
  410586:	shlx   r8,r8,r9
  41058b:	test   r8,rdx
  41058e:	je     41059d <__swc_fn_23cea7fa_000068_f3aa21af+0x18d>
  410590:	add    ecx,0x1
  410593:	cmp    ecx,0x2d
  410596:	jb     410550 <__swc_fn_23cea7fa_000068_f3aa21af+0x140>
  410598:	mov    ecx,0xffffffff
  41059d:	mov    DWORD PTR [rsp+0x8],ecx
  4105a1:	mov    ecx,DWORD PTR [rsp+0x8]
  4105a5:	cmp    ecx,0xffffffff
  4105a8:	je     4105b0 <__swc_fn_23cea7fa_000068_f3aa21af+0x1a0>
  4105aa:	cmp    DWORD PTR [rbx+0x58],0x40
  4105ae:	jbe    4105c3 <__swc_fn_23cea7fa_000068_f3aa21af+0x1b3>
  4105b0:	mov    rcx,r12
  4105b3:	mov    rdx,rbx
  4105b6:	mov    r8d,DWORD PTR [rax]
  4105b9:	call   40fec0 <__swc_fn_23cea7fa_000065_d9ee99ea>
  4105be:	jmp    410697 <__swc_fn_23cea7fa_000068_f3aa21af+0x287>
  4105c3:	lea    rax,[rip+0x11a3e]        # 422008 <__swc_data_base_23cea7fa+0x8>
  4105ca:	mov    rax,QWORD PTR [rax]
  4105cd:	cmp    rax,0xffffffffffffffff
  4105d1:	je     4105e0 <__swc_fn_23cea7fa_000068_f3aa21af+0x1d0>
  4105d3:	mov    eax,eax
  4105d5:	mov    edi,eax
  4105d7:	xor    eax,eax
  4105d9:	call   407000 <pthread_getspecific@plt>
  4105de:	jmp    4105e2 <__swc_fn_23cea7fa_000068_f3aa21af+0x1d2>
  4105e0:	xor    eax,eax
  4105e2:	test   rax,rax
  4105e5:	jne    4105f4 <__swc_fn_23cea7fa_000068_f3aa21af+0x1e4>
  4105e7:	call   40f560 <__swc_fn_23cea7fa_000035_cd1a4e8c>
  4105ec:	mov    rcx,rax
  4105ef:	call   40a160 <__swc_fn_23cea7fa_000132_5f757033>
  4105f4:	test   rax,rax
  4105f7:	je     410604 <__swc_fn_23cea7fa_000068_f3aa21af+0x1f4>
  4105f9:	cmp    QWORD PTR [rax],r12
  4105fc:	jne    410604 <__swc_fn_23cea7fa_000068_f3aa21af+0x1f4>
  4105fe:	cmp    DWORD PTR [rax+0x20],0x0
  410602:	je     41060f <__swc_fn_23cea7fa_000068_f3aa21af+0x1ff>
  410604:	mov    rcx,r12
  410607:	mov    rdx,rax
  41060a:	call   4080d0 <__swc_fn_23cea7fa_000045_d8bd27c3>
  41060f:	test   rax,rax
  410612:	jne    41061e <__swc_fn_23cea7fa_000068_f3aa21af+0x20e>
  410614:	mov    QWORD PTR [rbx+0x40],0x0
  41061c:	jmp    410697 <__swc_fn_23cea7fa_000068_f3aa21af+0x287>
  41061e:	lea    r8,[rsp+0xc]
  410623:	mov    ecx,DWORD PTR [rsp+0x8]
  410627:	mov    DWORD PTR [rsp+0xc],ecx
  41062b:	mov    ecx,DWORD PTR [r8]
  41062e:	lea    rcx,[rcx+rcx*4]
  410632:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  410637:	test   rcx,rcx
  41063a:	je     410673 <__swc_fn_23cea7fa_000068_f3aa21af+0x263>
  41063c:	mov    rdx,QWORD PTR [rcx]
  41063f:	test   rdx,rdx
  410642:	je     410650 <__swc_fn_23cea7fa_000068_f3aa21af+0x240>
  410644:	mov    r9,QWORD PTR [rdx]
  410647:	mov    QWORD PTR [rcx],r9
  41064a:	add    DWORD PTR [rcx+0x28],0x1
  41064e:	jmp    41066e <__swc_fn_23cea7fa_000068_f3aa21af+0x25e>
  410650:	mov    rdx,QWORD PTR [rcx+0x18]
  410654:	cmp    QWORD PTR [rcx+0x20],rdx
  410658:	jae    41066c <__swc_fn_23cea7fa_000068_f3aa21af+0x25c>
  41065a:	mov    rdx,QWORD PTR [rcx+0x20]
  41065e:	mov    r9d,DWORD PTR [rcx+0x2c]
  410662:	add    QWORD PTR [rcx+0x20],r9
  410666:	add    DWORD PTR [rcx+0x28],0x1
  41066a:	jmp    41066e <__swc_fn_23cea7fa_000068_f3aa21af+0x25e>
  41066c:	xor    edx,edx
  41066e:	test   rdx,rdx
  410671:	jne    410684 <__swc_fn_23cea7fa_000068_f3aa21af+0x274>
  410673:	mov    rcx,r12
  410676:	mov    rdx,rax
  410679:	mov    r8d,DWORD PTR [r8]
  41067c:	call   408240 <__swc_fn_23cea7fa_000054_faa92dcc>
  410681:	mov    rdx,rax
  410684:	test   rdx,rdx
  410687:	jne    410693 <__swc_fn_23cea7fa_000068_f3aa21af+0x283>
  410689:	mov    QWORD PTR [rbx+0x40],0x0
  410691:	jmp    410697 <__swc_fn_23cea7fa_000068_f3aa21af+0x287>
  410693:	mov    QWORD PTR [rbx+0x40],rdx
  410697:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  41069d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4106a3:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4106a9:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4106af:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4106b5:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4106bb:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4106c1:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4106ca:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4106d3:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4106dc:	add    rsp,0xb8
  4106e3:	pop    rsi
  4106e4:	pop    rdi
  4106e5:	pop    r12
  4106e7:	pop    rbx
  4106e8:	ret
  4106e9:	add    BYTE PTR [rax],al
  4106eb:	add    BYTE PTR [rax],al
  4106ed:	add    BYTE PTR [rax],al
	...

00000000004106f0 <__swc_fn_23cea7fa_000071_b3d7b28e>:
  4106f0:	ret
	...

0000000000410700 <__swc_fn_23cea7fa_000074_042643a3>:
  410700:	push   r12
  410702:	push   r13
  410704:	push   r14
  410706:	push   rdi
  410707:	push   rsi
  410708:	sub    rsp,0x1a0
  41070f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  410718:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  410721:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  41072a:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  410733:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  41073c:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  410745:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  41074e:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  410757:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  410760:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  410769:	mov    r12,rdx
  41076c:	mov    r13,rcx
  41076f:	mov    rax,QWORD PTR [r12+0x48]
  410774:	mov    ecx,DWORD PTR [r12+0x58]
  410779:	lea    rdx,[rax-0x1]
  41077d:	cmp    rdx,0x10000
  410784:	jae    41087e <__swc_fn_23cea7fa_000074_042643a3+0x17e>
  41078a:	cmp    rax,0x8
  41078e:	ja     410795 <__swc_fn_23cea7fa_000074_042643a3+0x95>
  410790:	xor    r14d,r14d
  410793:	jmp    4107e7 <__swc_fn_23cea7fa_000074_042643a3+0xe7>
  410795:	cmp    rax,0x80
  41079c:	ja     4107a8 <__swc_fn_23cea7fa_000074_042643a3+0xa8>
  41079e:	lea    r14,[rax+0xf]
  4107a2:	shr    r14,0x4
  4107a6:	jmp    4107e7 <__swc_fn_23cea7fa_000074_042643a3+0xe7>
  4107a8:	cmp    rax,0x10000
  4107af:	jbe    4107b9 <__swc_fn_23cea7fa_000074_042643a3+0xb9>
  4107b1:	mov    r14d,0xffffffff
  4107b7:	jmp    4107e7 <__swc_fn_23cea7fa_000074_042643a3+0xe7>
  4107b9:	xor    eax,eax
  4107bb:	lzcnt  rax,rdx
  4107c0:	mov    r8d,0x3f
  4107c6:	sub    r8d,eax
  4107c9:	lea    eax,[r8-0x2]
  4107cd:	shrx   rax,rdx,rax
  4107d2:	and    eax,0x3
  4107d5:	lea    edx,[r8-0x7]
  4107d9:	lea    edx,[rdx*4+0x0]
  4107e0:	lea    edx,[rdx+0x9]
  4107e3:	lea    r14d,[rdx+rax*1]
  4107e7:	cmp    ecx,0x8
  4107ea:	jbe    410803 <__swc_fn_23cea7fa_000074_042643a3+0x103>
  4107ec:	cmp    ecx,0x10
  4107ef:	jne    41087e <__swc_fn_23cea7fa_000074_042643a3+0x17e>
  4107f5:	test   r14d,r14d
  4107f8:	mov    eax,0x1
  4107fd:	cmove  r14d,eax
  410801:	jmp    41080a <__swc_fn_23cea7fa_000074_042643a3+0x10a>
  410803:	lea    eax,[rcx-0x1]
  410806:	test   eax,ecx
  410808:	jne    41087e <__swc_fn_23cea7fa_000074_042643a3+0x17e>
  41080a:	lea    rax,[rip+0x117f7]        # 422008 <__swc_data_base_23cea7fa+0x8>
  410811:	mov    rax,QWORD PTR [rax]
  410814:	cmp    rax,0xffffffffffffffff
  410818:	je     410827 <__swc_fn_23cea7fa_000074_042643a3+0x127>
  41081a:	mov    eax,eax
  41081c:	mov    edi,eax
  41081e:	xor    eax,eax
  410820:	call   407000 <pthread_getspecific@plt>
  410825:	jmp    410829 <__swc_fn_23cea7fa_000074_042643a3+0x129>
  410827:	xor    eax,eax
  410829:	test   rax,rax
  41082c:	je     41087e <__swc_fn_23cea7fa_000074_042643a3+0x17e>
  41082e:	cmp    QWORD PTR [rax],r13
  410831:	jne    41087e <__swc_fn_23cea7fa_000074_042643a3+0x17e>
  410833:	lea    rcx,[r14+r14*4]
  410837:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  41083c:	test   rax,rax
  41083f:	je     41087e <__swc_fn_23cea7fa_000074_042643a3+0x17e>
  410841:	mov    rcx,QWORD PTR [rax]
  410844:	test   rcx,rcx
  410847:	je     410855 <__swc_fn_23cea7fa_000074_042643a3+0x155>
  410849:	mov    rdx,QWORD PTR [rcx]
  41084c:	mov    QWORD PTR [rax],rdx
  41084f:	add    DWORD PTR [rax+0x28],0x1
  410853:	jmp    410872 <__swc_fn_23cea7fa_000074_042643a3+0x172>
  410855:	mov    rcx,QWORD PTR [rax+0x18]
  410859:	cmp    QWORD PTR [rax+0x20],rcx
  41085d:	jae    410870 <__swc_fn_23cea7fa_000074_042643a3+0x170>
  41085f:	mov    rcx,QWORD PTR [rax+0x20]
  410863:	mov    edx,DWORD PTR [rax+0x2c]
  410866:	add    QWORD PTR [rax+0x20],rdx
  41086a:	add    DWORD PTR [rax+0x28],0x1
  41086e:	jmp    410872 <__swc_fn_23cea7fa_000074_042643a3+0x172>
  410870:	xor    ecx,ecx
  410872:	test   rcx,rcx
  410875:	je     41087e <__swc_fn_23cea7fa_000074_042643a3+0x17e>
  410877:	mov    QWORD PTR [r12+0x40],rcx
  41087c:	jmp    410889 <__swc_fn_23cea7fa_000074_042643a3+0x189>
  41087e:	mov    rcx,r13
  410881:	mov    rdx,r12
  410884:	call   408cc0 <__swc_fn_23cea7fa_000075_64d36d78>
  410889:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  410892:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  41089b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  4108a4:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  4108ad:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  4108b6:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  4108bf:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  4108c8:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  4108d1:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  4108da:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  4108e3:	add    rsp,0x1a0
  4108ea:	pop    rsi
  4108eb:	pop    rdi
  4108ec:	pop    r14
  4108ee:	pop    r13
  4108f0:	pop    r12
  4108f2:	ret
	...

0000000000410900 <__swc_fn_23cea7fa_000077_7b195156>:
  410900:	push   r12
  410902:	push   r13
  410904:	push   r14
  410906:	push   r15
  410908:	push   rdi
  410909:	push   rsi
  41090a:	sub    rsp,0x188
  410911:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  41091a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  410923:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  41092c:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  410935:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  41093e:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  410947:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  410950:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  410959:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  410962:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  41096b:	mov    r12,rdx
  41096e:	mov    r13,rcx
  410971:	mov    r14,QWORD PTR [r12+0x40]
  410976:	lea    rax,[rip+0x136fb]        # 424078 <__swc_bss_base_23cea7fa+0x38>
  41097d:	mov    rcx,r14
  410980:	sub    rcx,QWORD PTR [rax+0x8]
  410984:	mov    rax,QWORD PTR [rip+0x136fd]        # 424088 <__swc_bss_base_23cea7fa+0x48>
  41098b:	cmp    rcx,rax
  41098e:	jae    4109ba <__swc_fn_23cea7fa_000077_7b195156+0xba>
  410990:	mov    rax,r14
  410993:	and    rax,0xffffffffffc00000
  41099a:	mov    rcx,r14
  41099d:	shr    rcx,0x10
  4109a1:	and    ecx,0x3f
  4109a4:	mov    edx,DWORD PTR [rax+0x28]
  4109a7:	shrx   ecx,ecx,edx
  4109ac:	shl    rcx,0x4
  4109b0:	lea    r15,[rax+rcx*8+0x80]
  4109b8:	jmp    4109c5 <__swc_fn_23cea7fa_000077_7b195156+0xc5>
  4109ba:	mov    rcx,r14
  4109bd:	call   40f490 <__swc_fn_23cea7fa_000026_bcdc5519>
  4109c2:	mov    r15,rax
  4109c5:	test   r15,r15
  4109c8:	je     410a6f <__swc_fn_23cea7fa_000077_7b195156+0x16f>
  4109ce:	lea    rax,[rip+0x11633]        # 422008 <__swc_data_base_23cea7fa+0x8>
  4109d5:	mov    rax,QWORD PTR [rax]
  4109d8:	cmp    rax,0xffffffffffffffff
  4109dc:	je     4109eb <__swc_fn_23cea7fa_000077_7b195156+0xeb>
  4109de:	mov    eax,eax
  4109e0:	mov    edi,eax
  4109e2:	xor    eax,eax
  4109e4:	call   407000 <pthread_getspecific@plt>
  4109e9:	jmp    4109ed <__swc_fn_23cea7fa_000077_7b195156+0xed>
  4109eb:	xor    eax,eax
  4109ed:	mov    rcx,QWORD PTR [r15+0x40]
  4109f1:	cmp    rcx,rax
  4109f4:	jne    410a54 <__swc_fn_23cea7fa_000077_7b195156+0x154>
  4109f6:	test   rax,rax
  4109f9:	je     410a6f <__swc_fn_23cea7fa_000077_7b195156+0x16f>
  4109fb:	mov    ecx,DWORD PTR [r15+0x6c]
  4109ff:	test   ecx,ecx
  410a01:	je     410a21 <__swc_fn_23cea7fa_000077_7b195156+0x121>
  410a03:	mov    rcx,r13
  410a06:	mov    rdx,rax
  410a09:	mov    r8,r15
  410a0c:	mov    QWORD PTR [rsp+0xd8],rax
  410a14:	call   4081d0 <__swc_fn_23cea7fa_000051_e072b516>
  410a19:	mov    rax,QWORD PTR [rsp+0xd8]
  410a21:	mov    rcx,QWORD PTR [r15]
  410a24:	mov    QWORD PTR [r14],rcx
  410a27:	mov    QWORD PTR [r15],r14
  410a2a:	sub    DWORD PTR [r15+0x28],0x1
  410a2f:	jne    410a64 <__swc_fn_23cea7fa_000077_7b195156+0x164>
  410a31:	movzx  ecx,BYTE PTR [r15+0x39]
  410a36:	lea    rcx,[rcx+rcx*4]
  410a3a:	lea    rcx,[rax+rcx*8+0x28]
  410a3f:	cmp    QWORD PTR [rcx],r15
  410a42:	je     410a64 <__swc_fn_23cea7fa_000077_7b195156+0x164>
  410a44:	mov    rcx,r13
  410a47:	mov    rdx,rax
  410a4a:	mov    r8,r15
  410a4d:	call   40c900 <__swc_fn_23cea7fa_000055_2e3450f7>
  410a52:	jmp    410a64 <__swc_fn_23cea7fa_000077_7b195156+0x164>
  410a54:	test   rcx,rcx
  410a57:	je     410a6f <__swc_fn_23cea7fa_000077_7b195156+0x16f>
  410a59:	mov    rcx,r15
  410a5c:	mov    rdx,r14
  410a5f:	call   40f0d0 <__swc_fn_23cea7fa_000014_524c1f23>
  410a64:	mov    QWORD PTR [r12+0x40],0x0
  410a6d:	jmp    410a7a <__swc_fn_23cea7fa_000077_7b195156+0x17a>
  410a6f:	mov    rcx,r13
  410a72:	mov    rdx,r12
  410a75:	call   408ce0 <__swc_fn_23cea7fa_000078_1966ae2e>
  410a7a:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  410a83:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  410a8c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  410a95:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  410a9e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  410aa7:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  410ab0:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  410ab9:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  410ac2:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  410acb:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  410ad4:	add    rsp,0x188
  410adb:	pop    rsi
  410adc:	pop    rdi
  410add:	pop    r15
  410adf:	pop    r14
  410ae1:	pop    r13
  410ae3:	pop    r12
  410ae5:	ret
	...

0000000000410af0 <__swc_fn_23cea7fa_000080_d2cd17e2>:
  410af0:	sub    rsp,0x8
  410af4:	mov    rax,rdx
  410af7:	mov    rdx,QWORD PTR [rax+0x40]
  410afb:	mov    r8,rax
  410afe:	call   4106f0 <__swc_fn_23cea7fa_000071_b3d7b28e>
  410b03:	add    rsp,0x8
  410b07:	ret
	...

0000000000410b10 <__swc_fn_23cea7fa_000083_4a10c7e7>:
  410b10:	push   rsi
  410b11:	push   rdi
  410b12:	sub    rsp,0x8
  410b16:	cmp    rcx,0xffffffffffffffef
  410b1a:	ja     410b40 <__swc_fn_23cea7fa_000083_4a10c7e7+0x30>
  410b1c:	xor    esi,esi
  410b1e:	lea    rax,[rcx+0x100f]
  410b25:	and    rax,0xfffffffffffff000
  410b2c:	lea    rcx,[rcx+0x10]
  410b30:	cmp    rcx,0xfffffffffffff000
  410b37:	cmovbe rsi,rax
  410b3b:	test   rsi,rsi
  410b3e:	jne    410b49 <__swc_fn_23cea7fa_000083_4a10c7e7+0x39>
  410b40:	xor    eax,eax
  410b42:	add    rsp,0x8
  410b46:	pop    rdi
  410b47:	pop    rsi
  410b48:	ret
  410b49:	mov    rcx,rsi
  410b4c:	call   4111a0 <__swc_fn_23cea7fa_000113_6b799b8d>
  410b51:	mov    rdi,rax
  410b54:	test   rax,rax
  410b57:	jne    410b62 <__swc_fn_23cea7fa_000083_4a10c7e7+0x52>
  410b59:	xor    eax,eax
  410b5b:	add    rsp,0x8
  410b5f:	pop    rdi
  410b60:	pop    rsi
  410b61:	ret
  410b62:	mov    rcx,rdi
  410b65:	mov    rdx,rsi
  410b68:	call   40ddc0 <__swc_fn_23cea7fa_000115_36905703>
  410b6d:	test   al,al
  410b6f:	jne    410b85 <__swc_fn_23cea7fa_000083_4a10c7e7+0x75>
  410b71:	mov    rcx,rdi
  410b74:	mov    rdx,rsi
  410b77:	call   409e10 <__swc_fn_23cea7fa_000117_ed2d8fed>
  410b7c:	xor    eax,eax
  410b7e:	add    rsp,0x8
  410b82:	pop    rdi
  410b83:	pop    rsi
  410b84:	ret
  410b85:	mov    QWORD PTR [rdi],rsi
  410b88:	mov    QWORD PTR [rdi+0x8],0x0
  410b90:	lea    rax,[rdi+0x10]
  410b94:	add    rsp,0x8
  410b98:	pop    rdi
  410b99:	pop    rsi
  410b9a:	ret
  410b9b:	add    BYTE PTR [rax],al
  410b9d:	add    BYTE PTR [rax],al
	...

0000000000410ba0 <__swc_fn_23cea7fa_000086_3953ef98>:
  410ba0:	sub    rsp,0x8
  410ba4:	cmp    BYTE PTR [rcx+0x2c],0x10
  410ba8:	jne    410bb3 <__swc_fn_23cea7fa_000086_3953ef98+0x13>
  410baa:	test   DWORD PTR [rcx+0x28],0x80
  410bb1:	je     410bbb <__swc_fn_23cea7fa_000086_3953ef98+0x1b>
  410bb3:	mov    rax,rcx
  410bb6:	add    rsp,0x8
  410bba:	ret
  410bbb:	mov    rcx,QWORD PTR [rcx+0x40]
  410bbf:	call   410ba0 <__swc_fn_23cea7fa_000086_3953ef98>
  410bc4:	add    rsp,0x8
  410bc8:	ret
	...

0000000000410be0 <__swc_fn_23cea7fa_000089_d182c4dc>:
  410be0:	push   rsi
  410be1:	push   rdi
  410be2:	push   r12
  410be4:	push   r13
  410be6:	sub    rsp,0x8
  410bea:	mov    rsi,rdx
  410bed:	mov    rdi,rcx
  410bf0:	xor    r8d,r8d
  410bf3:	call   40d120 <__swc_fn_23cea7fa_000094_63c1827b>
  410bf8:	test   al,al
  410bfa:	je     410c0c <__swc_fn_23cea7fa_000089_d182c4dc+0x2c>
  410bfc:	mov    eax,0x1
  410c01:	add    rsp,0x8
  410c05:	pop    r13
  410c07:	pop    r12
  410c09:	pop    rdi
  410c0a:	pop    rsi
  410c0b:	ret
  410c0c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  410c11:	je     410c20 <__swc_fn_23cea7fa_000089_d182c4dc+0x40>
  410c13:	xor    eax,eax
  410c15:	add    rsp,0x8
  410c19:	pop    r13
  410c1b:	pop    r12
  410c1d:	pop    rdi
  410c1e:	pop    rsi
  410c1f:	ret
  410c20:	mov    r12,QWORD PTR [rsi+0x98]
  410c27:	mov    rax,QWORD PTR [rsi+0xa0]
  410c2e:	mov    rsi,rax
  410c31:	xor    r13d,r13d
  410c34:	test   rsi,rsi
  410c37:	je     410c94 <__swc_fn_23cea7fa_000089_d182c4dc+0xb4>
  410c39:	cs nop WORD PTR [rax+rax*1+0x0]
  410c43:	cs nop WORD PTR [rax+rax*1+0x0]
  410c4d:	nop    DWORD PTR [rax]
  410c50:	lea    rax,[r13*8+0x0]
  410c58:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  410c5d:	mov    rcx,rax
  410c60:	call   410ba0 <__swc_fn_23cea7fa_000086_3953ef98>
  410c65:	cmp    BYTE PTR [rax+0x2c],0xe
  410c69:	jne    410c8a <__swc_fn_23cea7fa_000089_d182c4dc+0xaa>
  410c6b:	mov    rcx,rdi
  410c6e:	mov    rdx,rax
  410c71:	call   410be0 <__swc_fn_23cea7fa_000089_d182c4dc>
  410c76:	test   al,al
  410c78:	je     410c8a <__swc_fn_23cea7fa_000089_d182c4dc+0xaa>
  410c7a:	mov    eax,0x1
  410c7f:	add    rsp,0x8
  410c83:	pop    r13
  410c85:	pop    r12
  410c87:	pop    rdi
  410c88:	pop    rsi
  410c89:	ret
  410c8a:	add    r13,0x1
  410c8e:	sub    rsi,0x1
  410c92:	jne    410c50 <__swc_fn_23cea7fa_000089_d182c4dc+0x70>
  410c94:	xor    eax,eax
  410c96:	add    rsp,0x8
  410c9a:	pop    r13
  410c9c:	pop    r12
  410c9e:	pop    rdi
  410c9f:	pop    rsi
  410ca0:	ret
	...

0000000000410cb0 <__swc_fn_23cea7fa_000092_14c65203>:
  410cb0:	sub    rsp,0x18
  410cb4:	vxorps xmm0,xmm0,xmm0
  410cb8:	vmovdqu XMMWORD PTR [rsp],xmm0
  410cbd:	call   408ef0 <__swc_fn_23cea7fa_000093_c2567a3b>
  410cc2:	add    rsp,0x18
  410cc6:	ret
	...

0000000000410cd0 <__swc_fn_23cea7fa_000095_ad13d15c>:
  410cd0:	sub    rsp,0x8
  410cd4:	mov    rcx,QWORD PTR [rip+0x13365]        # 424040 <__swc_bss_base_23cea7fa>
  410cdb:	test   rcx,rcx
  410cde:	jne    410cf0 <__swc_fn_23cea7fa_000095_ad13d15c+0x20>
  410ce0:	call   40ed20 <__swc_fn_23cea7fa_000169_994c8876>
  410ce5:	lea    rcx,[rax+0x1]
  410ce9:	mov    QWORD PTR [rip+0x13350],rcx        # 424040 <__swc_bss_base_23cea7fa>
  410cf0:	dec    rcx
  410cf3:	call   40bbe0 <__swc_fn_23cea7fa_000171_360af05d>
  410cf8:	mov    rax,QWORD PTR [rax+0xc0]
  410cff:	and    eax,0x1
  410d02:	setne  al
  410d05:	add    rsp,0x8
  410d09:	ret
	...

0000000000410d20 <__swc_fn_23cea7fa_000098_4f209617>:
  410d20:	push   rbx
  410d21:	push   rsi
  410d22:	push   rdi
  410d23:	push   r12
  410d25:	sub    rsp,0x28
  410d29:	mov    rbx,rcx
  410d2c:	call   40d480 <__swc_fn_23cea7fa_000097_4185993f>
  410d31:	mov    rcx,QWORD PTR [rip+0x13308]        # 424040 <__swc_bss_base_23cea7fa>
  410d38:	test   rcx,rcx
  410d3b:	jne    410d4d <__swc_fn_23cea7fa_000098_4f209617+0x2d>
  410d3d:	call   40ed20 <__swc_fn_23cea7fa_000169_994c8876>
  410d42:	lea    rcx,[rax+0x1]
  410d46:	mov    QWORD PTR [rip+0x132f3],rcx        # 424040 <__swc_bss_base_23cea7fa>
  410d4d:	dec    rcx
  410d50:	call   40bbe0 <__swc_fn_23cea7fa_000171_360af05d>
  410d55:	mov    rsi,rax
  410d58:	lea    rcx,[rsp+0x8]
  410d5d:	call   409330 <__swc_fn_23cea7fa_000096_93bfe675>
  410d62:	mov    rdi,QWORD PTR [rsi+0x9c0]
  410d69:	mov    r12,QWORD PTR [rsi+0xbe8]
  410d70:	lea    rcx,[rsi+0x10]
  410d74:	call   411cf0 <__swc_fn_23cea7fa_000161_13ead2ff>
  410d79:	mov    rcx,rsi
  410d7c:	call   4094a0 <__swc_fn_23cea7fa_000105_5a85fcf5>
  410d81:	vxorps xmm0,xmm0,xmm0
  410d85:	xor    eax,eax
  410d87:	cs nop WORD PTR [rax+rax*1+0x0]
  410d91:	cs nop WORD PTR [rax+rax*1+0x0]
  410d9b:	nop    DWORD PTR [rax+rax*1+0x0]
  410da0:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  410da5:	add    rax,0x10
  410da9:	cmp    rax,0xbf0
  410db0:	jne    410da0 <__swc_fn_23cea7fa_000098_4f209617+0x80>
  410db2:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  410db8:	vmovups XMMWORD PTR [rsi],xmm0
  410dbc:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  410dc2:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  410dca:	mov    QWORD PTR [rsi+0x9c0],rdi
  410dd1:	mov    QWORD PTR [rsi+0xbe8],r12
  410dd8:	mov    rcx,QWORD PTR [rip+0x13261]        # 424040 <__swc_bss_base_23cea7fa>
  410ddf:	test   rcx,rcx
  410de2:	jne    410df4 <__swc_fn_23cea7fa_000098_4f209617+0xd4>
  410de4:	call   40ed20 <__swc_fn_23cea7fa_000169_994c8876>
  410de9:	lea    rcx,[rax+0x1]
  410ded:	mov    QWORD PTR [rip+0x1324c],rcx        # 424040 <__swc_bss_base_23cea7fa>
  410df4:	dec    rcx
  410df7:	call   40bbe0 <__swc_fn_23cea7fa_000171_360af05d>
  410dfc:	mov    rsi,rax
  410dff:	mov    QWORD PTR [rsi+0xc0],rbx
  410e06:	and    ebx,0x1
  410e09:	jne    410e0d <__swc_fn_23cea7fa_000098_4f209617+0xed>
  410e0b:	xor    eax,eax
  410e0d:	test   rbx,rbx
  410e10:	sete   al
  410e13:	xor    cl,cl
  410e15:	xor    dl,dl
  410e17:	xor    r8b,r8b
  410e1a:	xor    r9b,r9b
  410e1d:	xor    r10b,r10b
  410e20:	mov    r11,rax
  410e23:	call   408cf0 <__swc_fn_23cea7fa_000081_5cc7acfc>
  410e28:	lea    rbx,[rsp+0x18]
  410e2d:	mov    rcx,rbx
  410e30:	call   409330 <__swc_fn_23cea7fa_000096_93bfe675>
  410e35:	lea    rcx,[rsi+0x10]
  410e39:	mov    edx,0x400000
  410e3e:	mov    r8,rbx
  410e41:	call   40ea60 <__swc_fn_23cea7fa_000163_8a3d304f>
  410e46:	lea    rcx,[rsi+0x68]
  410e4a:	mov    edx,0x4000
  410e4f:	mov    r8,rbx
  410e52:	call   40ea60 <__swc_fn_23cea7fa_000163_8a3d304f>
  410e57:	add    rsp,0x28
  410e5b:	pop    r12
  410e5d:	pop    rdi
  410e5e:	pop    rsi
  410e5f:	pop    rbx
  410e60:	ret
	...

0000000000410e70 <__swc_fn_23cea7fa_000101_d0b19c14>:
  410e70:	push   rbx
  410e71:	push   rsi
  410e72:	sub    rsp,0x18
  410e76:	mov    rbx,rcx
  410e79:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  410e7e:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410e84:	mov    rsi,QWORD PTR [rbx+0x70]
  410e88:	lea    rcx,[rcx+0x18]
  410e8c:	call   411cf0 <__swc_fn_23cea7fa_000161_13ead2ff>
  410e91:	lea    rcx,[rsp+0x8]
  410e96:	mov    rdx,rbx
  410e99:	mov    r8d,0x78
  410e9f:	call   40d4e0 <__swc_fn_23cea7fa_000100_d4bdcaa4>
  410ea4:	mov    rax,rsi
  410ea7:	add    rsp,0x18
  410eab:	pop    rsi
  410eac:	pop    rbx
  410ead:	ret
	...

0000000000410eb0 <__swc_fn_23cea7fa_000104_3c3b96fb>:
  410eb0:	push   rsi
  410eb1:	push   rdi
  410eb2:	sub    rsp,0x8
  410eb6:	cmp    QWORD PTR [rcx],0x0
  410eba:	jne    410ec3 <__swc_fn_23cea7fa_000104_3c3b96fb+0x13>
  410ebc:	add    rsp,0x8
  410ec0:	pop    rdi
  410ec1:	pop    rsi
  410ec2:	ret
  410ec3:	mov    rsi,QWORD PTR [rcx]
  410ec6:	mov    rax,QWORD PTR [rcx+0x8]
  410eca:	test   rax,rax
  410ecd:	je     410ee3 <__swc_fn_23cea7fa_000104_3c3b96fb+0x33>
  410ecf:	test   DWORD PTR [rax+0x28],0x400000
  410ed6:	je     410ee3 <__swc_fn_23cea7fa_000104_3c3b96fb+0x33>
  410ed8:	mov    rcx,QWORD PTR [rax+0x30]
  410edc:	test   rcx,rcx
  410edf:	cmovne rax,rcx
  410ee3:	lea    rdx,[rip+0x240e]        # 4132f8 <__swc_rdata_base_23cea7fa+0x1e8>
  410eea:	lea    rcx,[rip+0x24ef]        # 4133e0 <__swc_rdata_base_23cea7fa+0x2d0>
  410ef1:	mov    r8,rax
  410ef4:	xor    r9d,r9d
  410ef7:	xor    al,al
  410ef9:	mov    r10,rax
  410efc:	xor    r11d,r11d
  410eff:	call   410cb0 <__swc_fn_23cea7fa_000092_14c65203>
  410f04:	test   rax,rax
  410f07:	je     410f17 <__swc_fn_23cea7fa_000104_3c3b96fb+0x67>
  410f09:	mov    rdi,QWORD PTR [rax+0x48]
  410f0d:	test   rdi,rdi
  410f10:	je     410f17 <__swc_fn_23cea7fa_000104_3c3b96fb+0x67>
  410f12:	mov    rcx,rsi
  410f15:	call   rdi
  410f17:	add    rsp,0x8
  410f1b:	pop    rdi
  410f1c:	pop    rsi
  410f1d:	ret
	...

0000000000410f20 <__swc_fn_23cea7fa_000107_90faaa26>:
  410f20:	push   rbx
  410f21:	push   rsi
  410f22:	push   rdi
  410f23:	sub    rsp,0x20
  410f27:	mov    rbx,rdx
  410f2a:	mov    rsi,rcx
  410f2d:	mov    rcx,QWORD PTR [rip+0x1310c]        # 424040 <__swc_bss_base_23cea7fa>
  410f34:	test   rcx,rcx
  410f37:	jne    410f49 <__swc_fn_23cea7fa_000107_90faaa26+0x29>
  410f39:	call   40ed20 <__swc_fn_23cea7fa_000169_994c8876>
  410f3e:	lea    rcx,[rax+0x1]
  410f42:	mov    QWORD PTR [rip+0x130f7],rcx        # 424040 <__swc_bss_base_23cea7fa>
  410f49:	dec    rcx
  410f4c:	call   40bbe0 <__swc_fn_23cea7fa_000171_360af05d>
  410f51:	mov    rdi,rax
  410f54:	mov    rax,QWORD PTR [rdi+0xbd0]
  410f5b:	xor    ecx,ecx
  410f5d:	test   rax,rax
  410f60:	je     410f65 <__swc_fn_23cea7fa_000107_90faaa26+0x45>
  410f62:	mov    rcx,QWORD PTR [rax]
  410f65:	call   40ee50 <__swc_fn_23cea7fa_000178_718d7b54>
  410f6a:	lea    rax,[rsp+0x8]
  410f6f:	lea    rcx,[rdi+0x9c8]
  410f76:	mov    QWORD PTR [rsp+0x8],rcx
  410f7b:	mov    QWORD PTR [rax+0x8],0x40
  410f83:	xor    ecx,ecx
  410f85:	mov    rdx,rax
  410f88:	call   409f40 <__swc_fn_23cea7fa_000123_4f256d58>
  410f8d:	mov    DWORD PTR [rdi+0xbc8],eax
  410f93:	mov    rdi,QWORD PTR [rdi+0x990]
  410f9a:	test   rdi,rdi
  410f9d:	je     410fa7 <__swc_fn_23cea7fa_000107_90faaa26+0x87>
  410f9f:	mov    rcx,rsi
  410fa2:	mov    rdx,rbx
  410fa5:	call   rdi
  410fa7:	call   410cd0 <__swc_fn_23cea7fa_000095_ad13d15c>
  410fac:	test   al,al
  410fae:	je     410fbe <__swc_fn_23cea7fa_000107_90faaa26+0x9e>
  410fb0:	mov    rcx,rsi
  410fb3:	mov    rdx,rbx
  410fb6:	xor    r8d,r8d
  410fb9:	call   40df60 <__swc_fn_23cea7fa_000124_83db7238>
  410fbe:	mov    rcx,rsi
  410fc1:	mov    rdx,rbx
  410fc4:	call   40d5e0 <__swc_fn_23cea7fa_000106_ffe51047>
  410fc9:	call   411550 <__swc_fn_23cea7fa_000122_be2e2f68>
  410fce:	add    rsp,0x20
  410fd2:	pop    rdi
  410fd3:	pop    rsi
  410fd4:	pop    rbx
  410fd5:	ret
	...

0000000000410fe0 <__swc_fn_23cea7fa_000110_3dc01326>:
  410fe0:	test   r8,r8
  410fe3:	jne    410fe8 <__swc_fn_23cea7fa_000110_3dc01326+0x8>
  410fe5:	xor    eax,eax
  410fe7:	ret
  410fe8:	xor    eax,eax
  410fea:	nop    WORD PTR [rax+rax*1+0x0]
  410ff0:	mov    r9,r8
  410ff3:	sub    r9,rax
  410ff6:	cmp    r9,0x10
  410ffa:	jb     411044 <__swc_fn_23cea7fa_000110_3dc01326+0x64>
  410ffc:	lea    r9,[rcx+rax*1]
  411000:	lea    r10,[rdx+rax*1]
  411004:	vmovups xmm0,XMMWORD PTR [r10]
  411009:	vmovups xmm1,XMMWORD PTR [r9]
  41100e:	vpcmpeqb xmm0,xmm1,xmm0
  411012:	vpmovmskb r9d,xmm0
  411016:	cmp    r9d,0xffff
  41101d:	je     41103e <__swc_fn_23cea7fa_000110_3dc01326+0x5e>
  41101f:	not    r9d
  411022:	xor    r8d,r8d
  411025:	movzx  r9d,r9w
  411029:	tzcnt  r8d,r9d
  41102e:	add    rax,r8
  411031:	movzx  ecx,BYTE PTR [rcx+rax*1]
  411035:	movzx  eax,BYTE PTR [rdx+rax*1]
  411039:	sub    ecx,eax
  41103b:	mov    eax,ecx
  41103d:	ret
  41103e:	lea    rax,[rax+0x10]
  411042:	jmp    410ff0 <__swc_fn_23cea7fa_000110_3dc01326+0x10>
  411044:	cmp    r9,0x8
  411048:	jb     4110bb <__swc_fn_23cea7fa_000110_3dc01326+0xdb>
  41104a:	lea    r9,[rcx+rax*1]
  41104e:	lea    r10,[rdx+rax*1]
  411052:	mov    r9,QWORD PTR [r9]
  411055:	xor    r9,QWORD PTR [r10]
  411058:	test   r9,r9
  41105b:	je     411079 <__swc_fn_23cea7fa_000110_3dc01326+0x99>
  41105d:	xor    r8d,r8d
  411060:	tzcnt  r8,r9
  411065:	shr    r8,0x3
  411069:	add    rax,r8
  41106c:	movzx  ecx,BYTE PTR [rcx+rax*1]
  411070:	movzx  eax,BYTE PTR [rdx+rax*1]
  411074:	sub    ecx,eax
  411076:	mov    eax,ecx
  411078:	ret
  411079:	lea    rax,[rax+0x8]
  41107d:	cmp    rax,r8
  411080:	jne    411085 <__swc_fn_23cea7fa_000110_3dc01326+0xa5>
  411082:	xor    eax,eax
  411084:	ret
  411085:	lea    rax,[r8-0x8]
  411089:	lea    r8,[rcx+rax*1]
  41108d:	lea    r9,[rdx+rax*1]
  411091:	mov    r8,QWORD PTR [r8]
  411094:	xor    r8,QWORD PTR [r9]
  411097:	test   r8,r8
  41109a:	je     4110b8 <__swc_fn_23cea7fa_000110_3dc01326+0xd8>
  41109c:	xor    r9d,r9d
  41109f:	tzcnt  r9,r8
  4110a4:	shr    r9,0x3
  4110a8:	add    rax,r9
  4110ab:	movzx  ecx,BYTE PTR [rcx+rax*1]
  4110af:	movzx  eax,BYTE PTR [rdx+rax*1]
  4110b3:	sub    ecx,eax
  4110b5:	mov    eax,ecx
  4110b7:	ret
  4110b8:	xor    eax,eax
  4110ba:	ret
  4110bb:	cmp    r9,0x4
  4110bf:	jb     411132 <__swc_fn_23cea7fa_000110_3dc01326+0x152>
  4110c1:	lea    r9,[rcx+rax*1]
  4110c5:	lea    r10,[rdx+rax*1]
  4110c9:	mov    r9d,DWORD PTR [r9]
  4110cc:	xor    r9d,DWORD PTR [r10]
  4110cf:	test   r9d,r9d
  4110d2:	je     4110f0 <__swc_fn_23cea7fa_000110_3dc01326+0x110>
  4110d4:	xor    r8d,r8d
  4110d7:	tzcnt  r8,r9
  4110dc:	shr    r8,0x3
  4110e0:	add    rax,r8
  4110e3:	movzx  ecx,BYTE PTR [rcx+rax*1]
  4110e7:	movzx  eax,BYTE PTR [rdx+rax*1]
  4110eb:	sub    ecx,eax
  4110ed:	mov    eax,ecx
  4110ef:	ret
  4110f0:	lea    rax,[rax+0x4]
  4110f4:	cmp    rax,r8
  4110f7:	jne    4110fc <__swc_fn_23cea7fa_000110_3dc01326+0x11c>
  4110f9:	xor    eax,eax
  4110fb:	ret
  4110fc:	lea    rax,[r8-0x4]
  411100:	lea    r8,[rcx+rax*1]
  411104:	lea    r9,[rdx+rax*1]
  411108:	mov    r8d,DWORD PTR [r8]
  41110b:	xor    r8d,DWORD PTR [r9]
  41110e:	test   r8d,r8d
  411111:	je     41112f <__swc_fn_23cea7fa_000110_3dc01326+0x14f>
  411113:	xor    r9d,r9d
  411116:	tzcnt  r9,r8
  41111b:	shr    r9,0x3
  41111f:	add    rax,r9
  411122:	movzx  ecx,BYTE PTR [rcx+rax*1]
  411126:	movzx  eax,BYTE PTR [rdx+rax*1]
  41112a:	sub    ecx,eax
  41112c:	mov    eax,ecx
  41112e:	ret
  41112f:	xor    eax,eax
  411131:	ret
  411132:	cmp    r9,0x2
  411136:	jb     411189 <__swc_fn_23cea7fa_000110_3dc01326+0x1a9>
  411138:	lea    r9,[rcx+rax*1]
  41113c:	lea    r10,[rdx+rax*1]
  411140:	mov    r9w,WORD PTR [r9]
  411144:	xor    r9w,WORD PTR [r10]
  411148:	test   r9w,r9w
  41114c:	je     41116e <__swc_fn_23cea7fa_000110_3dc01326+0x18e>
  41114e:	xor    r8d,r8d
  411151:	movzx  r9d,r9w
  411155:	tzcnt  r8,r9
  41115a:	shr    r8,0x3
  41115e:	add    rax,r8
  411161:	movzx  ecx,BYTE PTR [rcx+rax*1]
  411165:	movzx  eax,BYTE PTR [rdx+rax*1]
  411169:	sub    ecx,eax
  41116b:	mov    eax,ecx
  41116d:	ret
  41116e:	lea    rax,[rax+0x2]
  411172:	cmp    rax,r8
  411175:	jne    41117a <__swc_fn_23cea7fa_000110_3dc01326+0x19a>
  411177:	xor    eax,eax
  411179:	ret
  41117a:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  411180:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  411186:	sub    eax,ecx
  411188:	ret
  411189:	test   r9,r9
  41118c:	je     41119b <__swc_fn_23cea7fa_000110_3dc01326+0x1bb>
  41118e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  411192:	movzx  eax,BYTE PTR [rdx+rax*1]
  411196:	sub    ecx,eax
  411198:	mov    eax,ecx
  41119a:	ret
  41119b:	xor    eax,eax
  41119d:	ret
	...

00000000004111a0 <__swc_fn_23cea7fa_000113_6b799b8d>:
  4111a0:	push   r12
  4111a2:	push   r13
  4111a4:	push   r14
  4111a6:	push   rdi
  4111a7:	push   rsi
  4111a8:	push   r15
  4111aa:	sub    rsp,0xd8
  4111b1:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  4111b7:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  4111bd:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  4111c3:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  4111c9:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  4111cf:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  4111d8:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  4111e1:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  4111ea:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  4111f3:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  4111fc:	mov    r12,rcx
  4111ff:	test   rcx,rcx
  411202:	je     41121e <__swc_fn_23cea7fa_000113_6b799b8d+0x7e>
  411204:	mov    eax,r12d
  411207:	and    eax,0xfff
  41120d:	setne  al
  411210:	cmp    r12,0xffffffffffffefff
  411217:	seta   cl
  41121a:	or     al,cl
  41121c:	je     411225 <__swc_fn_23cea7fa_000113_6b799b8d+0x85>
  41121e:	xor    eax,eax
  411220:	jmp    4112bb <__swc_fn_23cea7fa_000113_6b799b8d+0x11b>
  411225:	call   40dc80 <__swc_fn_23cea7fa_000112_126150d1>
  41122a:	mov    r13,rax
  41122d:	test   rax,rax
  411230:	jne    411239 <__swc_fn_23cea7fa_000113_6b799b8d+0x99>
  411232:	xor    eax,eax
  411234:	jmp    4112bb <__swc_fn_23cea7fa_000113_6b799b8d+0x11b>
  411239:	lea    r14,[r12+0x1000]
  411241:	xor    edi,edi
  411243:	mov    rsi,r14
  411246:	xor    edx,edx
  411248:	mov    ecx,0x22
  41124d:	mov    eax,0xffffffff
  411252:	movsxd r8,eax
  411255:	xor    r9d,r9d
  411258:	xor    eax,eax
  41125a:	call   4070d0 <mmap@plt>
  41125f:	mov    r15,rax
  411262:	cmp    rax,0xffffffffffffffff
  411266:	jne    41126c <__swc_fn_23cea7fa_000113_6b799b8d+0xcc>
  411268:	xor    eax,eax
  41126a:	jmp    4112bb <__swc_fn_23cea7fa_000113_6b799b8d+0x11b>
  41126c:	mov    rdi,r15
  41126f:	mov    esi,0x1000
  411274:	mov    edx,0x3
  411279:	xor    eax,eax
  41127b:	call   407170 <mprotect@plt>
  411280:	test   eax,eax
  411282:	je     411295 <__swc_fn_23cea7fa_000113_6b799b8d+0xf5>
  411284:	mov    rdi,r15
  411287:	mov    rsi,r14
  41128a:	xor    eax,eax
  41128c:	call   407160 <munmap@plt>
  411291:	xor    eax,eax
  411293:	jmp    4112bb <__swc_fn_23cea7fa_000113_6b799b8d+0x11b>
  411295:	mov    QWORD PTR [r15+0x8],r12
  411299:	mov    rcx,r13
  41129c:	call   4118f0 <__swc_fn_23cea7fa_000137_8c07c14b>
  4112a1:	mov    rax,QWORD PTR [r13+0x8]
  4112a5:	mov    QWORD PTR [r15],rax
  4112a8:	mov    QWORD PTR [r13+0x8],r15
  4112ac:	mov    rcx,r13
  4112af:	call   40a2e0 <__swc_fn_23cea7fa_000138_715e84ff>
  4112b4:	lea    rax,[r15+0x1000]
  4112bb:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  4112c1:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  4112c7:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  4112cd:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  4112d3:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  4112d9:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  4112e2:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  4112eb:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  4112f4:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  4112fd:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  411306:	add    rsp,0xd8
  41130d:	pop    r15
  41130f:	pop    rsi
  411310:	pop    rdi
  411311:	pop    r14
  411313:	pop    r13
  411315:	pop    r12
  411317:	ret
	...

0000000000411320 <__swc_fn_23cea7fa_000116_e9fc0224>:
  411320:	push   rbx
  411321:	push   r12
  411323:	push   rdi
  411324:	push   rsi
  411325:	sub    rsp,0xa8
  41132c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  411332:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411338:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41133e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411344:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  41134a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  411350:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411356:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  41135c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411365:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41136e:	mov    rbx,rdx
  411371:	mov    r12,rcx
  411374:	mov    rdi,rcx
  411377:	mov    rsi,rdx
  41137a:	xor    edx,edx
  41137c:	xor    eax,eax
  41137e:	call   407170 <mprotect@plt>
  411383:	test   eax,eax
  411385:	jne    4113a9 <__swc_fn_23cea7fa_000116_e9fc0224+0x89>
  411387:	mov    rcx,r12
  41138a:	mov    rdx,rbx
  41138d:	xor    al,al
  41138f:	mov    r8,rax
  411392:	call   409d80 <__swc_fn_23cea7fa_000114_5f48311c>
  411397:	mov    rdi,r12
  41139a:	mov    rsi,rbx
  41139d:	mov    edx,0x4
  4113a2:	xor    eax,eax
  4113a4:	call   4071d0 <madvise@plt>
  4113a9:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4113af:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4113b5:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4113bb:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4113c1:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4113c7:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4113cd:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4113d3:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4113d9:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4113e2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4113eb:	add    rsp,0xa8
  4113f2:	pop    rsi
  4113f3:	pop    rdi
  4113f4:	pop    r12
  4113f6:	pop    rbx
  4113f7:	ret
	...

0000000000411400 <__swc_fn_23cea7fa_000119_d3318640>:
  411400:	push   rsi
  411401:	push   rdi
  411402:	push   r12
  411404:	push   r13
  411406:	push   r14
  411408:	sub    rsp,0xe0
  41140f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  411415:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  41141b:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  411421:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  411427:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  41142d:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  411436:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  41143f:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  411448:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  411451:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  41145a:	mov    rsi,rdx
  41145d:	mov    rdi,rcx
  411460:	call   40dc80 <__swc_fn_23cea7fa_000112_126150d1>
  411465:	mov    r12,rax
  411468:	test   rax,rax
  41146b:	jne    411472 <__swc_fn_23cea7fa_000119_d3318640+0x72>
  41146d:	jmp    4114e6 <__swc_fn_23cea7fa_000119_d3318640+0xe6>
  411472:	mov    rcx,r12
  411475:	call   4118f0 <__swc_fn_23cea7fa_000137_8c07c14b>
  41147a:	lea    r13,[r12+0x8]
  41147f:	mov    rax,QWORD PTR [r13+0x0]
  411483:	test   rax,rax
  411486:	je     4114de <__swc_fn_23cea7fa_000119_d3318640+0xde>
  411488:	nop    DWORD PTR [rax+rax*1+0x0]
  411490:	lea    rcx,[rax+0x1000]
  411497:	cmp    rcx,rdi
  41149a:	jne    4114d2 <__swc_fn_23cea7fa_000119_d3318640+0xd2>
  41149c:	cmp    QWORD PTR [rax+0x8],rsi
  4114a0:	je     4114ac <__swc_fn_23cea7fa_000119_d3318640+0xac>
  4114a2:	mov    rcx,r12
  4114a5:	call   40a2e0 <__swc_fn_23cea7fa_000138_715e84ff>
  4114aa:	jmp    4114e6 <__swc_fn_23cea7fa_000119_d3318640+0xe6>
  4114ac:	mov    r14,QWORD PTR [rax]
  4114af:	mov    rdi,rax
  4114b2:	lea    rsi,[rsi+0x1000]
  4114b9:	xor    eax,eax
  4114bb:	call   407160 <munmap@plt>
  4114c0:	test   eax,eax
  4114c2:	jne    4114c8 <__swc_fn_23cea7fa_000119_d3318640+0xc8>
  4114c4:	mov    QWORD PTR [r13+0x0],r14
  4114c8:	mov    rcx,r12
  4114cb:	call   40a2e0 <__swc_fn_23cea7fa_000138_715e84ff>
  4114d0:	jmp    4114e6 <__swc_fn_23cea7fa_000119_d3318640+0xe6>
  4114d2:	mov    r13,rax
  4114d5:	mov    rax,QWORD PTR [r13+0x0]
  4114d9:	test   rax,rax
  4114dc:	jne    411490 <__swc_fn_23cea7fa_000119_d3318640+0x90>
  4114de:	mov    rcx,r12
  4114e1:	call   40a2e0 <__swc_fn_23cea7fa_000138_715e84ff>
  4114e6:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  4114ec:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  4114f2:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  4114f8:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  4114fe:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  411504:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  41150d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  411516:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  41151f:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  411528:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  411531:	add    rsp,0xe0
  411538:	pop    r14
  41153a:	pop    r13
  41153c:	pop    r12
  41153e:	pop    rdi
  41153f:	pop    rsi
  411540:	ret
	...

0000000000411550 <__swc_fn_23cea7fa_000122_be2e2f68>:
  411550:	push   rdi
  411551:	push   rsi
  411552:	sub    rsp,0xa8
  411559:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41155f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411565:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41156b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411571:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411577:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41157d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411583:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411589:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411592:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41159b:	mov    rdi,0xfffffffffffffd66
  4115a2:	xor    eax,eax
  4115a4:	call   407180 <exit@plt>
  4115a9:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4115af:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4115b5:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4115bb:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4115c1:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4115c7:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4115cd:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4115d3:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4115d9:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4115e2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4115eb:	add    rsp,0xa8
  4115f2:	pop    rsi
  4115f3:	pop    rdi
  4115f4:	ret
	...

0000000000411600 <__swc_fn_23cea7fa_000125_540bf7e8>:
  411600:	push   rbx
  411601:	push   rsi
  411602:	push   rdi
  411603:	sub    rsp,0x30
  411607:	mov    rbx,rdx
  41160a:	mov    esi,ecx
  41160c:	test   ecx,ecx
  41160e:	je     4116e3 <__swc_fn_23cea7fa_000125_540bf7e8+0xe3>
  411614:	mov    rcx,rsi
  411617:	shl    rcx,0x4
  41161b:	call   410b10 <__swc_fn_23cea7fa_000083_4a10c7e7>
  411620:	test   rax,rax
  411623:	je     4116d2 <__swc_fn_23cea7fa_000125_540bf7e8+0xd2>
  411629:	mov    rcx,rsi
  41162c:	xor    edx,edx
  41162e:	test   rsi,rsi
  411631:	jbe    4116b2 <__swc_fn_23cea7fa_000125_540bf7e8+0xb2>
  411637:	nop    WORD PTR [rax+rax*1+0x0]
  411640:	mov    r8d,edx
  411643:	mov    r9,QWORD PTR [rbx+r8*8]
  411647:	add    r8,r8
  41164a:	lea    r8,[rax+r8*8]
  41164e:	xor    r10d,r10d
  411651:	test   r9,r9
  411654:	je     411690 <__swc_fn_23cea7fa_000125_540bf7e8+0x90>
  411656:	mov    r11,r9
  411659:	mov    dil,BYTE PTR [r11]
  41165c:	test   dil,dil
  41165f:	je     411690 <__swc_fn_23cea7fa_000125_540bf7e8+0x90>
  411661:	cs nop WORD PTR [rax+rax*1+0x0]
  41166b:	cs nop WORD PTR [rax+rax*1+0x0]
  411675:	cs nop WORD PTR [rax+rax*1+0x0]
  41167f:	nop
  411680:	add    r11,0x1
  411684:	add    r10,0x1
  411688:	mov    dil,BYTE PTR [r11]
  41168b:	test   dil,dil
  41168e:	jne    411680 <__swc_fn_23cea7fa_000125_540bf7e8+0x80>
  411690:	mov    QWORD PTR [rsp+0x18],r9
  411695:	mov    QWORD PTR [rsp+0x20],r10
  41169a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  4116a0:	vmovups XMMWORD PTR [r8],xmm0
  4116a5:	add    rdx,0x1
  4116a9:	cmp    rdx,rcx
  4116ac:	jb     411640 <__swc_fn_23cea7fa_000125_540bf7e8+0x40>
  4116b2:	lea    rcx,[rip+0x1568f]        # 426d48 <__swc_bss_base_23cea7fa+0x2d08>
  4116b9:	mov    QWORD PTR [rsp+0x8],rax
  4116be:	mov    esi,esi
  4116c0:	mov    QWORD PTR [rsp+0x10],rsi
  4116c5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4116cb:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4116d0:	jmp    4116e3 <__swc_fn_23cea7fa_000125_540bf7e8+0xe3>
  4116d2:	lea    rcx,[rip+0x1f17]        # 4135f0 <__swc_rdata_base_23cea7fa+0x4e0>
  4116d9:	call   409e30 <__swc_fn_23cea7fa_000120_2648f149>
  4116de:	call   411550 <__swc_fn_23cea7fa_000122_be2e2f68>
  4116e3:	add    rsp,0x30
  4116e7:	pop    rdi
  4116e8:	pop    rsi
  4116e9:	pop    rbx
  4116ea:	ret
  4116eb:	add    BYTE PTR [rax],al
  4116ed:	add    BYTE PTR [rax],al
	...

00000000004116f0 <__swc_fn_23cea7fa_000128_a481cb88>:
  4116f0:	push   rdi
  4116f1:	push   rsi
  4116f2:	sub    rsp,0xa8
  4116f9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4116ff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411705:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41170b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411711:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411717:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41171d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411723:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411729:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411732:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41173b:	mov    edi,ecx
  41173d:	xor    eax,eax
  41173f:	call   4071e0 <pthread_key_delete@plt>
  411744:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41174a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411750:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411756:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41175c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411762:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411768:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41176e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411774:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41177d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411786:	add    rsp,0xa8
  41178d:	pop    rsi
  41178e:	pop    rdi
  41178f:	ret

0000000000411790 <__swc_fn_23cea7fa_000131_a611b8c4>:
  411790:	push   rdi
  411791:	push   rsi
  411792:	sub    rsp,0xa8
  411799:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41179f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4117a5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4117ab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4117b1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4117b7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4117bd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4117c3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4117c9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4117d2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4117db:	test   rcx,rcx
  4117de:	je     4117ef <__swc_fn_23cea7fa_000131_a611b8c4+0x5f>
  4117e0:	lea    rax,[rcx-0x1]
  4117e4:	mov    eax,eax
  4117e6:	mov    edi,eax
  4117e8:	xor    eax,eax
  4117ea:	call   4071e0 <pthread_key_delete@plt>
  4117ef:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4117f5:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4117fb:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411801:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411807:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  41180d:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411813:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411819:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  41181f:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411828:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411831:	add    rsp,0xa8
  411838:	pop    rsi
  411839:	pop    rdi
  41183a:	ret
  41183b:	add    BYTE PTR [rax],al
  41183d:	add    BYTE PTR [rax],al
	...

0000000000411840 <__swc_fn_23cea7fa_000134_a9c1c700>:
  411840:	push   rsi
  411841:	push   rdi
  411842:	sub    rsp,0xa8
  411849:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41184f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411855:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41185b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411861:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411867:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41186d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411873:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411879:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411882:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41188b:	xor    eax,eax
  41188d:	call   4071f0 <gettid@plt>
  411892:	movsxd rax,eax
  411895:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41189b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4118a1:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4118a7:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4118ad:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4118b3:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4118b9:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4118bf:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4118c5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4118ce:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4118d7:	add    rsp,0xa8
  4118de:	pop    rdi
  4118df:	pop    rsi
  4118e0:	ret
	...

00000000004118f0 <__swc_fn_23cea7fa_000137_8c07c14b>:
  4118f0:	push   rbx
  4118f1:	push   rdi
  4118f2:	push   rsi
  4118f3:	sub    rsp,0xc0
  4118fa:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  411900:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  411906:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41190c:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  411912:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  411918:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41191e:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  411924:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41192d:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  411936:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41193f:	mov    rbx,rcx
  411942:	cs nop WORD PTR [rax+rax*1+0x0]
  41194c:	nop    DWORD PTR [rax+0x0]
  411950:	mov    edx,0x80000000
  411955:	xor    eax,eax
  411957:	lock cmpxchg DWORD PTR [rbx],edx
  41195b:	test   eax,eax
  41195d:	je     411994 <__swc_fn_23cea7fa_000137_8c07c14b+0xa4>
  41195f:	mov    eax,DWORD PTR [rbx]
  411961:	lea    rcx,[rsp+0x14]
  411966:	mov    DWORD PTR [rsp+0x14],eax
  41196a:	test   eax,eax
  41196c:	je     411950 <__swc_fn_23cea7fa_000137_8c07c14b+0x60>
  41196e:	mov    QWORD PTR [rsp],0x0
  411976:	mov    edi,0xca
  41197b:	mov    rsi,rbx
  41197e:	mov    edx,0x80
  411983:	mov    ecx,DWORD PTR [rcx]
  411985:	xor    r8d,r8d
  411988:	xor    r9d,r9d
  41198b:	xor    eax,eax
  41198d:	call   4071a0 <syscall@plt>
  411992:	jmp    411950 <__swc_fn_23cea7fa_000137_8c07c14b+0x60>
  411994:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  41199a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4119a0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4119a6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4119ac:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4119b2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4119b8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4119be:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4119c7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4119d0:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4119d9:	add    rsp,0xc0
  4119e0:	pop    rsi
  4119e1:	pop    rdi
  4119e2:	pop    rbx
  4119e3:	ret
	...

00000000004119f0 <__swc_fn_23cea7fa_000140_055b38a4>:
  4119f0:	sub    rsp,0x8
  4119f4:	call   40a2e0 <__swc_fn_23cea7fa_000138_715e84ff>
  4119f9:	add    rsp,0x8
  4119fd:	ret
	...

0000000000411a00 <__swc_fn_23cea7fa_000143_d299b428>:
  411a00:	push   rdi
  411a01:	push   rsi
  411a02:	sub    rsp,0xa8
  411a09:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  411a0f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411a15:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  411a1b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411a21:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411a27:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  411a2d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411a33:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411a39:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411a42:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  411a4b:	mov    edi,0x28
  411a50:	xor    eax,eax
  411a52:	call   4071c0 <malloc@plt>
  411a57:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  411a5d:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411a63:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411a69:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411a6f:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411a75:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411a7b:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411a81:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411a87:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411a90:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411a99:	add    rsp,0xa8
  411aa0:	pop    rsi
  411aa1:	pop    rdi
  411aa2:	ret
	...

0000000000411ab0 <__swc_fn_23cea7fa_000146_162f363d>:
  411ab0:	mov    QWORD PTR [r8],0x0
  411ab7:	cmp    rdx,0x10
  411abb:	jae    411ac0 <__swc_fn_23cea7fa_000146_162f363d+0x10>
  411abd:	xor    eax,eax
  411abf:	ret
  411ac0:	mov    eax,DWORD PTR [rcx]
  411ac2:	cmp    eax,0x42445753
  411ac8:	jne    411ad2 <__swc_fn_23cea7fa_000146_162f363d+0x22>
  411aca:	mov    eax,DWORD PTR [rcx+0x4]
  411acd:	cmp    eax,0x1
  411ad0:	je     411ad5 <__swc_fn_23cea7fa_000146_162f363d+0x25>
  411ad2:	xor    eax,eax
  411ad4:	ret
  411ad5:	mov    QWORD PTR [r8],rdx
  411ad8:	mov    rax,rcx
  411adb:	ret
  411adc:	add    BYTE PTR [rax],al
	...

0000000000411ae0 <__swc_fn_23cea7fa_000149_2eb804cc>:
  411ae0:	push   rbx
  411ae1:	sub    rsp,0xe0
  411ae8:	lea    rbx,[rsp+0x8]
  411aed:	vxorps xmm0,xmm0,xmm0
  411af1:	vmovups YMMWORD PTR [rbx],ymm0
  411af5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  411afa:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  411aff:	vzeroupper
  411b02:	mov    DWORD PTR [rbx+0x60],0x0
  411b09:	mov    r8,rbx
  411b0c:	mov    rdx,rcx
  411b0f:	nop
  411b10:	mov    r9,rdx
  411b13:	movabs rdx,0x6666666666666667
  411b1d:	mov    rax,r9
  411b20:	imul   rdx
  411b23:	sar    rdx,0x2
  411b27:	mov    r10,rdx
  411b2a:	shr    rdx,0x3f
  411b2e:	add    r10,rdx
  411b31:	mov    rdx,r10
  411b34:	imul   r11,r10,0xa
  411b38:	sub    r9,r11
  411b3b:	mov    r11,QWORD PTR [rip+0x1ace]        # 413610 <__swc_rdata_base_23cea7fa+0x500>
  411b42:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  411b47:	mov    BYTE PTR [r8],r9b
  411b4a:	lea    r9,[r8+0x1]
  411b4e:	mov    r8,r9
  411b51:	test   r10,r10
  411b54:	jne    411b10 <__swc_fn_23cea7fa_000149_2eb804cc+0x30>
  411b56:	test   rcx,rcx
  411b59:	jge    411b63 <__swc_fn_23cea7fa_000149_2eb804cc+0x83>
  411b5b:	mov    BYTE PTR [r9],0x2d
  411b5f:	add    r8,0x1
  411b63:	mov    BYTE PTR [r8],0x0
  411b67:	sub    r8,0x1
  411b6b:	mov    rax,rbx
  411b6e:	cmp    rax,r8
  411b71:	jae    411b96 <__swc_fn_23cea7fa_000149_2eb804cc+0xb6>
  411b73:	cs nop WORD PTR [rax+rax*1+0x0]
  411b7d:	nop    DWORD PTR [rax]
  411b80:	mov    cl,BYTE PTR [r8]
  411b83:	mov    dl,BYTE PTR [rax]
  411b85:	mov    BYTE PTR [r8],dl
  411b88:	sub    r8,0x1
  411b8c:	mov    BYTE PTR [rax],cl
  411b8e:	inc    rax
  411b91:	cmp    rax,r8
  411b94:	jb     411b80 <__swc_fn_23cea7fa_000149_2eb804cc+0xa0>
  411b96:	xor    eax,eax
  411b98:	test   rbx,rbx
  411b9b:	je     411bbe <__swc_fn_23cea7fa_000149_2eb804cc+0xde>
  411b9d:	mov    rcx,rbx
  411ba0:	mov    dl,BYTE PTR [rcx]
  411ba2:	test   dl,dl
  411ba4:	je     411bbe <__swc_fn_23cea7fa_000149_2eb804cc+0xde>
  411ba6:	cs nop WORD PTR [rax+rax*1+0x0]
  411bb0:	add    rcx,0x1
  411bb4:	add    rax,0x1
  411bb8:	mov    dl,BYTE PTR [rcx]
  411bba:	test   dl,dl
  411bbc:	jne    411bb0 <__swc_fn_23cea7fa_000149_2eb804cc+0xd0>
  411bbe:	mov    QWORD PTR [rbx+0xa8],rbx
  411bc5:	mov    QWORD PTR [rbx+0xb0],rax
  411bcc:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  411bd4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  411bdc:	lea    rcx,[rbx+0xb8]
  411be3:	call   409e30 <__swc_fn_23cea7fa_000120_2648f149>
  411be8:	add    rsp,0xe0
  411bef:	pop    rbx
  411bf0:	ret
	...

0000000000411c00 <__swc_fn_23cea7fa_000152_86f1d437>:
  411c00:	vxorps xmm0,xmm0,xmm0
  411c04:	vmovups XMMWORD PTR [rcx],xmm0
  411c08:	mov    QWORD PTR [rcx+0x10],0x0
  411c10:	ret
	...

0000000000411c20 <__swc_fn_23cea7fa_000155_86f1d437>:
  411c20:	vxorps xmm0,xmm0,xmm0
  411c24:	vmovups XMMWORD PTR [rcx],xmm0
  411c28:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411c2d:	vxorps xmm0,xmm0,xmm0
  411c31:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411c36:	vmovups xmm0,XMMWORD PTR [rip+0x1aca]        # 413708 <__swc_rdata_base_23cea7fa+0x5f8>
  411c3e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411c43:	vxorps xmm0,xmm0,xmm0
  411c47:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411c4c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411c51:	mov    QWORD PTR [rcx+0x60],0x0
  411c59:	ret
  411c5a:	add    BYTE PTR [rax],al
  411c5c:	add    BYTE PTR [rax],al
	...

0000000000411c60 <__swc_fn_23cea7fa_000158_86f1d437>:
  411c60:	vxorps xmm0,xmm0,xmm0
  411c64:	vmovups XMMWORD PTR [rcx],xmm0
  411c68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411c6d:	vxorps xmm0,xmm0,xmm0
  411c71:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411c76:	vmovups xmm0,XMMWORD PTR [rip+0x1bb2]        # 413830 <__swc_rdata_base_23cea7fa+0x720>
  411c7e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411c83:	vxorps xmm0,xmm0,xmm0
  411c87:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411c8c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411c91:	vxorps xmm0,xmm0,xmm0
  411c95:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  411c9a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  411c9f:	vxorps xmm0,xmm0,xmm0
  411ca3:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  411cab:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  411cb3:	vxorps xmm0,xmm0,xmm0
  411cb7:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  411cbf:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  411cc7:	vxorps xmm0,xmm0,xmm0
  411ccb:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  411cd3:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  411cdb:	mov    QWORD PTR [rcx+0xe0],0x0
  411ce6:	ret
	...

0000000000411cf0 <__swc_fn_23cea7fa_000161_13ead2ff>:
  411cf0:	push   rbx
  411cf1:	mov    rbx,rcx
  411cf4:	call   40b870 <__swc_fn_23cea7fa_000162_e36363a8>
  411cf9:	mov    rax,QWORD PTR [rbx+0x10]
  411cfd:	test   rax,rax
  411d00:	je     411d11 <__swc_fn_23cea7fa_000161_13ead2ff+0x21>
  411d02:	mov    rcx,rbx
  411d05:	mov    rdx,rax
  411d08:	mov    r8,QWORD PTR [rbx+0x18]
  411d0c:	call   40ea10 <__swc_fn_23cea7fa_000160_47b270e1>
  411d11:	vxorps xmm0,xmm0,xmm0
  411d15:	vmovups XMMWORD PTR [rbx],xmm0
  411d19:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  411d1e:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  411d23:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  411d28:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  411d2d:	mov    QWORD PTR [rbx+0x50],0x0
  411d35:	pop    rbx
  411d36:	ret
	...

0000000000411d40 <__swc_fn_23cea7fa_000164_72795826>:
  411d40:	sub    rsp,0x10
  411d44:	mov    eax,r8d
  411d47:	mov    r8d,r9d
  411d4a:	test   r9d,r9d
  411d4d:	jne    411d66 <__swc_fn_23cea7fa_000164_72795826+0x26>
  411d4f:	vmovups xmm0,XMMWORD PTR [rip+0x1b91]        # 4138e8 <__swc_rdata_base_23cea7fa+0x7d8>
  411d57:	vmovups XMMWORD PTR [r10],xmm0
  411d5c:	mov    eax,0x1
  411d61:	add    rsp,0x10
  411d65:	ret
  411d66:	mov    r9,r8
  411d69:	cmp    r8,rax
  411d6c:	jb     411d73 <__swc_fn_23cea7fa_000164_72795826+0x33>
  411d6e:	cmp    r9,rdx
  411d71:	jb     411d7a <__swc_fn_23cea7fa_000164_72795826+0x3a>
  411d73:	xor    eax,eax
  411d75:	add    rsp,0x10
  411d79:	ret
  411d7a:	xor    eax,eax
  411d7c:	lea    r8,[r9+rax*1]
  411d80:	cmp    r8,rdx
  411d83:	jae    411db3 <__swc_fn_23cea7fa_000164_72795826+0x73>
  411d85:	cs nop WORD PTR [rax+rax*1+0x0]
  411d8f:	cs nop WORD PTR [rax+rax*1+0x0]
  411d99:	nop    DWORD PTR [rax+0x0]
  411da0:	cmp    BYTE PTR [rcx+r8*1],0x0
  411da5:	je     411db3 <__swc_fn_23cea7fa_000164_72795826+0x73>
  411da7:	inc    rax
  411daa:	lea    r8,[r9+rax*1]
  411dae:	cmp    r8,rdx
  411db1:	jb     411da0 <__swc_fn_23cea7fa_000164_72795826+0x60>
  411db3:	cmp    r8,rdx
  411db6:	jne    411dbf <__swc_fn_23cea7fa_000164_72795826+0x7f>
  411db8:	xor    eax,eax
  411dba:	add    rsp,0x10
  411dbe:	ret
  411dbf:	add    rcx,r9
  411dc2:	mov    QWORD PTR [rsp],rcx
  411dc6:	mov    QWORD PTR [rsp+0x8],rax
  411dcb:	vmovups xmm0,XMMWORD PTR [rsp]
  411dd0:	vmovups XMMWORD PTR [r10],xmm0
  411dd5:	mov    eax,0x1
  411dda:	add    rsp,0x10
  411dde:	ret
	...

0000000000411de0 <__swc_fn_23cea7fa_000167_bcc835b8>:
  411de0:	push   rbp
  411de1:	push   rbx
  411de2:	push   rsi
  411de3:	push   rdi
  411de4:	push   r12
  411de6:	push   r13
  411de8:	push   r14
  411dea:	push   r15
  411dec:	sub    rsp,0x10
  411df0:	mov    rbp,rsp
  411df3:	vmovups XMMWORD PTR [rsp],xmm6
  411df8:	sub    rsp,0x50
  411dfc:	mov    rbx,rsp
  411dff:	mov    rsi,r8
  411e02:	mov    QWORD PTR [rsp+0x30],r8
  411e07:	mov    rdi,rcx
  411e0a:	mov    QWORD PTR [rsp+0x38],rcx
  411e0f:	mov    r12,rdx
  411e12:	xor    r13b,r13b
  411e15:	mov    r14,QWORD PTR [rdi+0x8]
  411e19:	mov    QWORD PTR [rsp+0x40],r14
  411e1e:	xor    r15d,r15d
  411e21:	test   r14,r14
  411e24:	jbe    41207e <__swc_fn_23cea7fa_000167_bcc835b8+0x29e>
  411e2a:	mov    r14,QWORD PTR [rdi]
  411e2d:	mov    rax,QWORD PTR [rsp+0x40]
  411e32:	mov    QWORD PTR [rsp+0x48],r14
  411e37:	vmovups xmm6,XMMWORD PTR [rip+0x16c9]        # 413508 <__swc_rdata_base_23cea7fa+0x3f8>
  411e3f:	nop
  411e40:	cmp    QWORD PTR [r14+r15*8],0x0
  411e45:	jne    411e4f <__swc_fn_23cea7fa_000167_bcc835b8+0x6f>
  411e47:	mov    r14,rax
  411e4a:	jmp    41205e <__swc_fn_23cea7fa_000167_bcc835b8+0x27e>
  411e4f:	mov    rcx,QWORD PTR [rdi]
  411e52:	mov    rdx,QWORD PTR [rcx+r15*8]
  411e56:	mov    rdi,rbx
  411e59:	mov    rcx,rdi
  411e5c:	sub    rsp,0x8
  411e60:	mov    r14,rax
  411e63:	call   40ea90 <__swc_fn_23cea7fa_000166_cc119975>
  411e68:	add    rsp,0x8
  411e6c:	mov    al,BYTE PTR [rbx]
  411e6e:	test   al,al
  411e70:	je     41205e <__swc_fn_23cea7fa_000167_bcc835b8+0x27e>
  411e76:	mov    al,BYTE PTR [rbx+0x1]
  411e79:	test   al,al
  411e7b:	jne    411e86 <__swc_fn_23cea7fa_000167_bcc835b8+0xa6>
  411e7d:	test   sil,sil
  411e80:	je     41205e <__swc_fn_23cea7fa_000167_bcc835b8+0x27e>
  411e86:	test   r13b,r13b
  411e89:	jne    411f47 <__swc_fn_23cea7fa_000167_bcc835b8+0x167>
  411e8f:	test   r12,r12
  411e92:	je     411f47 <__swc_fn_23cea7fa_000167_bcc835b8+0x167>
  411e98:	mov    al,BYTE PTR [rbx+0x1]
  411e9b:	test   al,al
  411e9d:	je     41205e <__swc_fn_23cea7fa_000167_bcc835b8+0x27e>
  411ea3:	mov    eax,DWORD PTR [rbx+0x28]
  411ea6:	cmp    DWORD PTR [r12+0x20],eax
  411eab:	jne    41205e <__swc_fn_23cea7fa_000167_bcc835b8+0x27e>
  411eb1:	mov    rax,QWORD PTR [r12]
  411eb5:	mov    rcx,QWORD PTR [r12+0x8]
  411eba:	cmp    QWORD PTR [rbx+0x20],rcx
  411ebe:	jne    41205e <__swc_fn_23cea7fa_000167_bcc835b8+0x27e>
  411ec4:	mov    cl,0x1
  411ec6:	test   rax,rax
  411ec9:	je     411f32 <__swc_fn_23cea7fa_000167_bcc835b8+0x152>
  411ecf:	mov    rdx,QWORD PTR [rbx+0x20]
  411ed3:	xor    r8d,r8d
  411ed6:	test   rdx,rdx
  411ed9:	jbe    411f32 <__swc_fn_23cea7fa_000167_bcc835b8+0x152>
  411edb:	mov    r9,QWORD PTR [rbx+0x18]
  411edf:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  411ee4:	cs nop WORD PTR [rax+rax*1+0x0]
  411eee:	xchg   ax,ax
  411ef0:	mov    r10b,BYTE PTR [rax+r8*1]
  411ef4:	cmp    BYTE PTR [r9+r8*1],r10b
  411ef8:	je     411f29 <__swc_fn_23cea7fa_000167_bcc835b8+0x149>
  411efa:	vmovq  r10,xmm0
  411eff:	cmp    BYTE PTR [r10+r8*1],0x5c
  411f04:	jne    411f0d <__swc_fn_23cea7fa_000167_bcc835b8+0x12d>
  411f06:	cmp    BYTE PTR [rax+r8*1],0x2f
  411f0b:	je     411f29 <__swc_fn_23cea7fa_000167_bcc835b8+0x149>
  411f0d:	vmovq  r10,xmm0
  411f12:	cmp    BYTE PTR [r10+r8*1],0x2f
  411f17:	jne    411f20 <__swc_fn_23cea7fa_000167_bcc835b8+0x140>
  411f19:	cmp    BYTE PTR [rax+r8*1],0x5c
  411f1e:	je     411f29 <__swc_fn_23cea7fa_000167_bcc835b8+0x149>
  411f20:	xor    eax,eax
  411f22:	movzx  eax,al
  411f25:	mov    cl,al
  411f27:	jmp    411f32 <__swc_fn_23cea7fa_000167_bcc835b8+0x152>
  411f29:	add    r8,0x1
  411f2d:	cmp    r8,rdx
  411f30:	jb     411ef0 <__swc_fn_23cea7fa_000167_bcc835b8+0x110>
  411f32:	test   cl,cl
  411f34:	je     41205e <__swc_fn_23cea7fa_000167_bcc835b8+0x27e>
  411f3a:	mov    eax,0x1
  411f3f:	mov    r13b,al
  411f42:	jmp    41205e <__swc_fn_23cea7fa_000167_bcc835b8+0x27e>
  411f47:	mov    r13b,0x1
  411f4a:	sub    rsp,0x20
  411f4e:	mov    rax,rsp
  411f51:	lea    rcx,[rdi+0x8]
  411f55:	mov    QWORD PTR [rax],rcx
  411f58:	lea    rsi,[rip+0x11d1]        # 413130 <__swc_rdata_base_23cea7fa+0x20>
  411f5f:	mov    QWORD PTR [rax+0x8],rsi
  411f63:	mov    QWORD PTR [rax+0x10],rsp
  411f67:	mov    QWORD PTR [rax+0x18],0x1
  411f6f:	lea    rcx,[rsp+0x10]
  411f74:	sub    rsp,0x8
  411f78:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  411f7d:	add    rsp,0x8
  411f81:	add    rsp,0x20
  411f85:	mov    al,BYTE PTR [rbx+0x1]
  411f88:	test   al,al
  411f8a:	je     412027 <__swc_fn_23cea7fa_000167_bcc835b8+0x247>
  411f90:	lea    rax,[rip+0x19f1]        # 413988 <__swc_rdata_base_23cea7fa+0x878>
  411f97:	sub    rsp,0x20
  411f9b:	mov    rcx,rsp
  411f9e:	mov    QWORD PTR [rcx],rax
  411fa1:	mov    QWORD PTR [rcx+0x8],rsi
  411fa5:	mov    QWORD PTR [rcx+0x10],rsp
  411fa9:	mov    QWORD PTR [rcx+0x18],0x1
  411fb1:	lea    rcx,[rsp+0x10]
  411fb6:	sub    rsp,0x8
  411fba:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  411fbf:	add    rsp,0x8
  411fc3:	add    rsp,0x20
  411fc7:	mov    eax,DWORD PTR [rbx+0x28]
  411fca:	sub    rsp,0x60
  411fce:	mov    rcx,rsp
  411fd1:	lea    rdx,[rdi+0x18]
  411fd5:	mov    QWORD PTR [rcx+0x18],rdx
  411fd9:	mov    QWORD PTR [rcx+0x20],rsi
  411fdd:	vmovups XMMWORD PTR [rcx],xmm6
  411fe1:	mov    QWORD PTR [rcx+0x28],rsp
  411fe5:	mov    QWORD PTR [rcx+0x30],rsi
  411fe9:	mov    DWORD PTR [rcx+0x10],eax
  411fec:	lea    rax,[rsp+0x10]
  411ff1:	mov    QWORD PTR [rcx+0x38],rax
  411ff5:	lea    rax,[rip+0x14a4]        # 4134a0 <__swc_rdata_base_23cea7fa+0x390>
  411ffc:	mov    QWORD PTR [rcx+0x40],rax
  412000:	lea    rax,[rsp+0x18]
  412005:	mov    QWORD PTR [rcx+0x48],rax
  412009:	mov    QWORD PTR [rcx+0x50],0x3
  412011:	lea    rcx,[rsp+0x48]
  412016:	sub    rsp,0x8
  41201a:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  41201f:	add    rsp,0x8
  412023:	add    rsp,0x60
  412027:	lea    rax,[rip+0x10f2]        # 413120 <__swc_rdata_base_23cea7fa+0x10>
  41202e:	sub    rsp,0x20
  412032:	mov    rcx,rsp
  412035:	mov    QWORD PTR [rcx],rax
  412038:	mov    QWORD PTR [rcx+0x8],rsi
  41203c:	mov    QWORD PTR [rcx+0x10],rsp
  412040:	mov    QWORD PTR [rcx+0x18],0x1
  412048:	lea    rcx,[rsp+0x10]
  41204d:	sub    rsp,0x8
  412051:	call   40a6a0 <__swc_fn_23cea7fa_000150_6203dca2>
  412056:	add    rsp,0x8
  41205a:	add    rsp,0x20
  41205e:	add    r15,0x1
  412062:	cmp    r15,r14
  412065:	jae    41207e <__swc_fn_23cea7fa_000167_bcc835b8+0x29e>
  412067:	mov    rsi,QWORD PTR [rsp+0x30]
  41206c:	mov    rdi,QWORD PTR [rsp+0x38]
  412071:	mov    rax,r14
  412074:	mov    r14,QWORD PTR [rsp+0x48]
  412079:	jmp    411e40 <__swc_fn_23cea7fa_000167_bcc835b8+0x60>
  41207e:	add    rsp,0x50
  412082:	vmovups xmm6,XMMWORD PTR [rsp]
  412087:	add    rsp,0x10
  41208b:	pop    r15
  41208d:	pop    r14
  41208f:	pop    r13
  412091:	pop    r12
  412093:	pop    rdi
  412094:	pop    rsi
  412095:	pop    rbx
  412096:	pop    rbp
  412097:	ret
	...

00000000004120a0 <__swc_fn_23cea7fa_000170_646fdf20>:
  4120a0:	sub    rsp,0x8
  4120a4:	call   40a0b0 <__swc_fn_23cea7fa_000129_4bbe3f14>
  4120a9:	add    rsp,0x8
  4120ad:	ret
	...

00000000004120b0 <__swc_fn_23cea7fa_000173_1e0ea8cf>:
  4120b0:	push   rsi
  4120b1:	sub    rsp,0x30
  4120b5:	lea    rsi,[rip+0x14cdc]        # 426d98 <__swc_bss_base_23cea7fa+0x2d58>
  4120bc:	mov    rax,QWORD PTR [rsi]
  4120bf:	test   rax,rax
  4120c2:	je     4120ca <__swc_fn_23cea7fa_000173_1e0ea8cf+0x1a>
  4120c4:	add    rsp,0x30
  4120c8:	pop    rsi
  4120c9:	ret
  4120ca:	mov    ecx,0x2
  4120cf:	mov    edx,0x8020
  4120d4:	call   409750 <__swc_fn_23cea7fa_000111_6814119b>
  4120d9:	test   rax,rax
  4120dc:	jne    4120ed <__swc_fn_23cea7fa_000173_1e0ea8cf+0x3d>
  4120de:	mov    QWORD PTR [rsp+0x18],rax
  4120e3:	call   411550 <__swc_fn_23cea7fa_000122_be2e2f68>
  4120e8:	mov    rax,QWORD PTR [rsp+0x18]
  4120ed:	mov    rcx,rax
  4120f0:	xchg   QWORD PTR [rsi],rcx
  4120f3:	add    rsp,0x30
  4120f7:	pop    rsi
  4120f8:	ret
  4120f9:	add    BYTE PTR [rax],al
  4120fb:	add    BYTE PTR [rax],al
  4120fd:	add    BYTE PTR [rax],al
	...

0000000000412100 <__swc_fn_23cea7fa_000176_4de704de>:
  412100:	push   rsi
  412101:	test   r8,r8
  412104:	jne    412108 <__swc_fn_23cea7fa_000176_4de704de+0x8>
  412106:	pop    rsi
  412107:	ret
  412108:	lea    rax,[rcx+0x18]
  41210c:	mov    r10,QWORD PTR [rax]
  41210f:	lea    r11,[r10+0x1]
  412113:	mov    QWORD PTR [rax],r11
  412116:	mov    r11,rdx
  412119:	not    rdx
  41211c:	lea    rsi,[r8-0x1]
  412120:	cmp    rsi,rdx
  412123:	ja     412143 <__swc_fn_23cea7fa_000176_4de704de+0x43>
  412125:	lea    rdx,[r11+r8*1]
  412129:	dec    rdx
  41212c:	shr    rdx,0x6
  412130:	mov    r8,r11
  412133:	shr    r8,0x6
  412137:	mov    rsi,rdx
  41213a:	sub    rsi,r8
  41213d:	cmp    rsi,0x8
  412141:	jb     412159 <__swc_fn_23cea7fa_000176_4de704de+0x59>
  412143:	lea    rcx,[rcx+0x10]
  412147:	mov    rdx,QWORD PTR [rcx]
  41214a:	add    rdx,r9
  41214d:	mov    QWORD PTR [rcx],rdx
  412150:	lea    rcx,[r10+0x2]
  412154:	mov    QWORD PTR [rax],rcx
  412157:	pop    rsi
  412158:	ret
  412159:	shr    r11,0x6
  41215d:	nop    DWORD PTR [rax]
  412160:	cmp    r11,rdx
  412163:	ja     4121a3 <__swc_fn_23cea7fa_000176_4de704de+0xa3>
  412165:	jmp    412176 <__swc_fn_23cea7fa_000176_4de704de+0x76>
  412167:	nop    WORD PTR [rax+rax*1+0x0]
  412170:	add    r11,0x1
  412174:	jmp    412160 <__swc_fn_23cea7fa_000176_4de704de+0x60>
  412176:	mov    r8,r11
  412179:	shr    r8,0xc
  41217d:	mov    rsi,r11
  412180:	xor    rsi,r8
  412183:	mov    r8,r11
  412186:	shr    r8,0x18
  41218a:	xor    rsi,r8
  41218d:	and    esi,0xfff
  412193:	lea    r8,[rcx+rsi*8+0x20]
  412198:	mov    rsi,QWORD PTR [r8]
  41219b:	add    rsi,r9
  41219e:	mov    QWORD PTR [r8],rsi
  4121a1:	jmp    412170 <__swc_fn_23cea7fa_000176_4de704de+0x70>
  4121a3:	lea    rcx,[r10+0x2]
  4121a7:	mov    QWORD PTR [rax],rcx
  4121aa:	pop    rsi
  4121ab:	ret
