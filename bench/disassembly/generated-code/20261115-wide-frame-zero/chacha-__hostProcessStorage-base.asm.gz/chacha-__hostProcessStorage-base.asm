
/workspace/prompt2-20261115/batch5-final-micro/base/chacha/chacha:     file format elf64-x86-64


Disassembly of section .text:

000000000040fa00 <__swc_fn_3464c816_000107_4f8da17c>:
  40fa00:	push   rbx
  40fa01:	push   r12
  40fa03:	push   rdi
  40fa04:	push   rsi
  40fa05:	push   r13
  40fa07:	push   r14
  40fa09:	push   r15
  40fa0b:	sub    rsp,0x170
  40fa12:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40fa1b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40fa24:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40fa2d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40fa36:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40fa3f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40fa48:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40fa51:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40fa5a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40fa63:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40fa6c:	mov    ebx,edx
  40fa6e:	mov    QWORD PTR [rsp+0xa8],rbx
  40fa76:	mov    r12d,ecx
  40fa79:	test   edx,edx
  40fa7b:	jne    40fa92 <__swc_fn_3464c816_000107_4f8da17c+0x92>
  40fa7d:	xor    eax,eax
  40fa7f:	add    rsp,0x170
  40fa86:	pop    r15
  40fa88:	pop    r14
  40fa8a:	pop    r13
  40fa8c:	pop    rsi
  40fa8d:	pop    rdi
  40fa8e:	pop    r12
  40fa90:	pop    rbx
  40fa91:	ret
  40fa92:	lea    rdi,[rip+0x3a17]        # 4134b0 <__swc_rdata_base_3464c816+0x3a0>
  40fa99:	mov    esi,0x90000
  40fa9e:	xor    eax,eax
  40faa0:	call   407090 <open@plt>
  40faa5:	mov    r13,rax
  40faa8:	mov    QWORD PTR [rsp+0xb0],rax
  40fab0:	test   eax,eax
  40fab2:	jge    40fabb <__swc_fn_3464c816_000107_4f8da17c+0xbb>
  40fab4:	xor    eax,eax
  40fab6:	jmp    40ffd6 <__swc_fn_3464c816_000107_4f8da17c+0x5d6>
  40fabb:	nop    DWORD PTR [rax+rax*1+0x0]
  40fac0:	movsxd rdi,r13d
  40fac3:	mov    esi,0x2
  40fac8:	xor    eax,eax
  40faca:	call   407120 <flock@plt>
  40facf:	test   eax,eax
  40fad1:	je     40faf0 <__swc_fn_3464c816_000107_4f8da17c+0xf0>
  40fad3:	xor    eax,eax
  40fad5:	call   407130 <__errno_location@plt>
  40fada:	cmp    DWORD PTR [rax],0x4
  40fadd:	je     40fac0 <__swc_fn_3464c816_000107_4f8da17c+0xc0>
  40fadf:	movsxd rdi,r13d
  40fae2:	xor    eax,eax
  40fae4:	call   4070b0 <close@plt>
  40fae9:	xor    eax,eax
  40faeb:	jmp    40ffd6 <__swc_fn_3464c816_000107_4f8da17c+0x5d6>
  40faf0:	lea    r14,[rsp+0x8]
  40faf5:	mov    QWORD PTR [rsp+0xb8],r14
  40fafd:	vxorps xmm0,xmm0,xmm0
  40fb01:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40fb07:	mov    QWORD PTR [rsp+0x18],0x0
  40fb10:	mov    WORD PTR [rsp+0x20],0x0
  40fb17:	mov    DWORD PTR [r14],0x67617753
  40fb1e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40fb26:	xor    eax,eax
  40fb28:	call   407010 <getpid@plt>
  40fb2d:	mov    ecx,eax
  40fb2f:	mov    eax,0x1c
  40fb34:	shrx   eax,ecx,eax
  40fb39:	and    eax,0xf
  40fb3c:	mov    rdx,QWORD PTR [rip+0x398d]        # 4134d0 <__swc_rdata_base_3464c816+0x3c0>
  40fb43:	mov    al,BYTE PTR [rdx+rax*1]
  40fb46:	rex mov BYTE PTR [rsp+0x10],al
  40fb4b:	mov    eax,0x1c
  40fb50:	shrx   eax,r12d,eax
  40fb55:	and    eax,0xf
  40fb58:	mov    al,BYTE PTR [rdx+rax*1]
  40fb5b:	rex mov BYTE PTR [rsp+0x19],al
  40fb60:	mov    eax,0x18
  40fb65:	shrx   eax,ecx,eax
  40fb6a:	and    eax,0xf
  40fb6d:	mov    al,BYTE PTR [rdx+rax*1]
  40fb70:	rex mov BYTE PTR [rsp+0x11],al
  40fb75:	mov    eax,0x18
  40fb7a:	shrx   eax,r12d,eax
  40fb7f:	and    eax,0xf
  40fb82:	mov    al,BYTE PTR [rdx+rax*1]
  40fb85:	rex mov BYTE PTR [rsp+0x1a],al
  40fb8a:	mov    eax,0x14
  40fb8f:	shrx   eax,ecx,eax
  40fb94:	and    eax,0xf
  40fb97:	mov    al,BYTE PTR [rdx+rax*1]
  40fb9a:	rex mov BYTE PTR [rsp+0x12],al
  40fb9f:	mov    eax,0x14
  40fba4:	shrx   eax,r12d,eax
  40fba9:	and    eax,0xf
  40fbac:	mov    al,BYTE PTR [rdx+rax*1]
  40fbaf:	rex mov BYTE PTR [rsp+0x1b],al
  40fbb4:	mov    eax,0x10
  40fbb9:	shrx   eax,ecx,eax
  40fbbe:	and    eax,0xf
  40fbc1:	mov    al,BYTE PTR [rdx+rax*1]
  40fbc4:	rex mov BYTE PTR [rsp+0x13],al
  40fbc9:	mov    eax,0x10
  40fbce:	shrx   eax,r12d,eax
  40fbd3:	and    eax,0xf
  40fbd6:	mov    al,BYTE PTR [rdx+rax*1]
  40fbd9:	rex mov BYTE PTR [rsp+0x1c],al
  40fbde:	mov    eax,0xc
  40fbe3:	shrx   eax,ecx,eax
  40fbe8:	and    eax,0xf
  40fbeb:	mov    al,BYTE PTR [rdx+rax*1]
  40fbee:	rex mov BYTE PTR [rsp+0x14],al
  40fbf3:	mov    eax,0xc
  40fbf8:	shrx   eax,r12d,eax
  40fbfd:	and    eax,0xf
  40fc00:	mov    al,BYTE PTR [rdx+rax*1]
  40fc03:	rex mov BYTE PTR [rsp+0x1d],al
  40fc08:	mov    eax,0x8
  40fc0d:	shrx   eax,ecx,eax
  40fc12:	and    eax,0xf
  40fc15:	mov    al,BYTE PTR [rdx+rax*1]
  40fc18:	rex mov BYTE PTR [rsp+0x15],al
  40fc1d:	mov    eax,0x8
  40fc22:	shrx   eax,r12d,eax
  40fc27:	and    eax,0xf
  40fc2a:	mov    al,BYTE PTR [rdx+rax*1]
  40fc2d:	rex mov BYTE PTR [rsp+0x1e],al
  40fc32:	mov    eax,0x4
  40fc37:	shrx   eax,ecx,eax
  40fc3c:	and    eax,0xf
  40fc3f:	mov    al,BYTE PTR [rdx+rax*1]
  40fc42:	rex mov BYTE PTR [rsp+0x16],al
  40fc47:	mov    eax,0x4
  40fc4c:	shrx   eax,r12d,eax
  40fc51:	and    eax,0xf
  40fc54:	mov    al,BYTE PTR [rdx+rax*1]
  40fc57:	rex mov BYTE PTR [rsp+0x1f],al
  40fc5c:	xor    eax,eax
  40fc5e:	shrx   eax,ecx,eax
  40fc63:	and    eax,0xf
  40fc66:	mov    al,BYTE PTR [rdx+rax*1]
  40fc69:	rex mov BYTE PTR [rsp+0x17],al
  40fc6e:	xor    eax,eax
  40fc70:	shrx   eax,r12d,eax
  40fc75:	and    eax,0xf
  40fc78:	mov    al,BYTE PTR [rdx+rax*1]
  40fc7b:	rex mov BYTE PTR [rsp+0x20],al
  40fc80:	mov    BYTE PTR [r14+0x10],0x2e
  40fc85:	lea    r12,[rsp+0x22]
  40fc8a:	vxorps xmm0,xmm0,xmm0
  40fc8e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40fc94:	mov    DWORD PTR [r12],0x6d656d2f
  40fc9c:	mov    WORD PTR [r12+0x4],0x6466
  40fca4:	mov    BYTE PTR [r12+0x6],0x3a
  40fcaa:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40fcb0:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40fcb6:	mov    rax,QWORD PTR [rsp+0x18]
  40fcbb:	mov    QWORD PTR [rsp+0x39],rax
  40fcc0:	rex mov al,BYTE PTR [rsp+0x20]
  40fcc5:	rex mov BYTE PTR [rsp+0x41],al
  40fcca:	mov    DWORD PTR [r12+0x20],0x65642820
  40fcd3:	mov    DWORD PTR [r12+0x24],0x6574656c
  40fcdc:	mov    WORD PTR [r12+0x28],0x2964
  40fce4:	lea    rdi,[rip+0x37d0]        # 4134bb <__swc_rdata_base_3464c816+0x3ab>
  40fceb:	xor    eax,eax
  40fced:	call   407140 <opendir@plt>
  40fcf2:	mov    r15,rax
  40fcf5:	test   rax,rax
  40fcf8:	jne    40fd0b <__swc_fn_3464c816_000107_4f8da17c+0x30b>
  40fcfa:	movsxd rdi,r13d
  40fcfd:	xor    eax,eax
  40fcff:	call   4070b0 <close@plt>
  40fd04:	xor    eax,eax
  40fd06:	jmp    40ffd6 <__swc_fn_3464c816_000107_4f8da17c+0x5d6>
  40fd0b:	mov    rdi,r15
  40fd0e:	xor    eax,eax
  40fd10:	call   407150 <dirfd@plt>
  40fd15:	lea    r14,[rsp+0x54]
  40fd1a:	mov    DWORD PTR [rsp+0x54],eax
  40fd1e:	lea    rbx,[rsp+0x58]
  40fd23:	cs nop WORD PTR [rax+rax*1+0x0]
  40fd2d:	cs nop WORD PTR [rax+rax*1+0x0]
  40fd37:	nop    WORD PTR [rax+rax*1+0x0]
  40fd40:	mov    rdi,r15
  40fd43:	xor    eax,eax
  40fd45:	call   407160 <readdir@plt>
  40fd4a:	test   rax,rax
  40fd4d:	jne    40fd64 <__swc_fn_3464c816_000107_4f8da17c+0x364>
  40fd4f:	mov    r12,QWORD PTR [rsp+0xa8]
  40fd57:	mov    r13,QWORD PTR [rsp+0xb0]
  40fd5f:	jmp    40fefa <__swc_fn_3464c816_000107_4f8da17c+0x4fa>
  40fd64:	vxorps xmm0,xmm0,xmm0
  40fd68:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40fd6e:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40fd74:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40fd7a:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40fd83:	lea    r13,[rax+0x13]
  40fd87:	mov    rax,r14
  40fd8a:	movsxd rdi,DWORD PTR [rax]
  40fd8d:	mov    rsi,r13
  40fd90:	mov    rdx,rbx
  40fd93:	mov    ecx,0x40
  40fd98:	xor    eax,eax
  40fd9a:	call   407170 <readlinkat@plt>
  40fd9f:	cmp    rax,0x2a
  40fda3:	jne    40fd40 <__swc_fn_3464c816_000107_4f8da17c+0x340>
  40fda5:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40fdab:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40fdb1:	vptest xmm0,xmm0
  40fdb6:	jne    40fde6 <__swc_fn_3464c816_000107_4f8da17c+0x3e6>
  40fdb8:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40fdbe:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40fdc4:	vptest xmm0,xmm0
  40fdc9:	jne    40fde6 <__swc_fn_3464c816_000107_4f8da17c+0x3e6>
  40fdcb:	mov    rcx,QWORD PTR [rsp+0x42]
  40fdd0:	cmp    QWORD PTR [rsp+0x78],rcx
  40fdd5:	jne    40fde6 <__swc_fn_3464c816_000107_4f8da17c+0x3e6>
  40fdd7:	mov    cx,WORD PTR [rsp+0x4a]
  40fddc:	cmp    WORD PTR [rsp+0x80],cx
  40fde4:	je     40fe14 <__swc_fn_3464c816_000107_4f8da17c+0x414>
  40fde6:	mov    rax,rbx
  40fde9:	mov    rcx,r12
  40fdec:	nop    DWORD PTR [rax+0x0]
  40fdf0:	movzx  edx,BYTE PTR [rax]
  40fdf3:	movzx  r8d,BYTE PTR [rcx]
  40fdf7:	cmp    rdx,r8
  40fdfa:	jne    40fe06 <__swc_fn_3464c816_000107_4f8da17c+0x406>
  40fdfc:	add    rax,0x1
  40fe00:	add    rcx,0x1
  40fe04:	jmp    40fdf0 <__swc_fn_3464c816_000107_4f8da17c+0x3f0>
  40fe06:	mov    rax,rdx
  40fe09:	sub    rax,r8
  40fe0c:	test   eax,eax
  40fe0e:	jne    40fd40 <__swc_fn_3464c816_000107_4f8da17c+0x340>
  40fe14:	movsxd rdi,DWORD PTR [r14]
  40fe17:	mov    rsi,r13
  40fe1a:	mov    edx,0x80002
  40fe1f:	xor    eax,eax
  40fe21:	call   407180 <openat@plt>
  40fe26:	lea    rbx,[rsp+0x98]
  40fe2e:	mov    DWORD PTR [rsp+0x98],eax
  40fe35:	test   eax,eax
  40fe37:	mov    r13,QWORD PTR [rsp+0xb0]
  40fe3f:	jge    40fe64 <__swc_fn_3464c816_000107_4f8da17c+0x464>
  40fe41:	mov    rdi,r15
  40fe44:	xor    eax,eax
  40fe46:	call   407190 <closedir@plt>
  40fe4b:	mov    r13,QWORD PTR [rsp+0xb0]
  40fe53:	movsxd rdi,r13d
  40fe56:	xor    eax,eax
  40fe58:	call   4070b0 <close@plt>
  40fe5d:	xor    eax,eax
  40fe5f:	jmp    40ffd6 <__swc_fn_3464c816_000107_4f8da17c+0x5d6>
  40fe64:	mov    rax,rbx
  40fe67:	movsxd rdi,DWORD PTR [rax]
  40fe6a:	xor    esi,esi
  40fe6c:	mov    edx,0x2
  40fe71:	xor    eax,eax
  40fe73:	call   4070a0 <lseek@plt>
  40fe78:	mov    r12,QWORD PTR [rsp+0xa8]
  40fe80:	cmp    rax,r12
  40fe83:	je     40feaa <__swc_fn_3464c816_000107_4f8da17c+0x4aa>
  40fe85:	movsxd rdi,DWORD PTR [rbx]
  40fe88:	xor    eax,eax
  40fe8a:	call   4070b0 <close@plt>
  40fe8f:	mov    rdi,r15
  40fe92:	xor    eax,eax
  40fe94:	call   407190 <closedir@plt>
  40fe99:	movsxd rdi,r13d
  40fe9c:	xor    eax,eax
  40fe9e:	call   4070b0 <close@plt>
  40fea3:	xor    eax,eax
  40fea5:	jmp    40ffd6 <__swc_fn_3464c816_000107_4f8da17c+0x5d6>
  40feaa:	xor    edi,edi
  40feac:	mov    rsi,r12
  40feaf:	mov    edx,0x3
  40feb4:	mov    ecx,0x1
  40feb9:	mov    rax,rbx
  40febc:	movsxd r8,DWORD PTR [rax]
  40febf:	xor    r9d,r9d
  40fec2:	xor    eax,eax
  40fec4:	call   4070c0 <mmap@plt>
  40fec9:	xor    r12d,r12d
  40fecc:	cmp    rax,0xffffffffffffffff
  40fed0:	cmovne r12,rax
  40fed4:	movsxd rdi,DWORD PTR [rbx]
  40fed7:	xor    eax,eax
  40fed9:	call   4070b0 <close@plt>
  40fede:	mov    rdi,r15
  40fee1:	xor    eax,eax
  40fee3:	call   407190 <closedir@plt>
  40fee8:	movsxd rdi,r13d
  40feeb:	xor    eax,eax
  40feed:	call   4070b0 <close@plt>
  40fef2:	mov    rax,r12
  40fef5:	jmp    40ffd6 <__swc_fn_3464c816_000107_4f8da17c+0x5d6>
  40fefa:	mov    r14,QWORD PTR [rsp+0xb8]
  40ff02:	mov    rdi,r14
  40ff05:	mov    esi,0x1
  40ff0a:	xor    eax,eax
  40ff0c:	call   4071a0 <memfd_create@plt>
  40ff11:	lea    rbx,[rsp+0x9c]
  40ff19:	mov    DWORD PTR [rsp+0x9c],eax
  40ff20:	test   eax,eax
  40ff22:	jge    40ff3f <__swc_fn_3464c816_000107_4f8da17c+0x53f>
  40ff24:	mov    rdi,r15
  40ff27:	xor    eax,eax
  40ff29:	call   407190 <closedir@plt>
  40ff2e:	movsxd rdi,r13d
  40ff31:	xor    eax,eax
  40ff33:	call   4070b0 <close@plt>
  40ff38:	xor    eax,eax
  40ff3a:	jmp    40ffd6 <__swc_fn_3464c816_000107_4f8da17c+0x5d6>
  40ff3f:	mov    rax,rbx
  40ff42:	movsxd rdi,DWORD PTR [rax]
  40ff45:	mov    rsi,r12
  40ff48:	xor    eax,eax
  40ff4a:	call   4071b0 <ftruncate@plt>
  40ff4f:	test   eax,eax
  40ff51:	je     40ff75 <__swc_fn_3464c816_000107_4f8da17c+0x575>
  40ff53:	movsxd rdi,DWORD PTR [rbx]
  40ff56:	xor    eax,eax
  40ff58:	call   4070b0 <close@plt>
  40ff5d:	mov    rdi,r15
  40ff60:	xor    eax,eax
  40ff62:	call   407190 <closedir@plt>
  40ff67:	movsxd rdi,r13d
  40ff6a:	xor    eax,eax
  40ff6c:	call   4070b0 <close@plt>
  40ff71:	xor    eax,eax
  40ff73:	jmp    40ffd6 <__swc_fn_3464c816_000107_4f8da17c+0x5d6>
  40ff75:	xor    edi,edi
  40ff77:	mov    rsi,r12
  40ff7a:	mov    edx,0x3
  40ff7f:	mov    ecx,0x1
  40ff84:	mov    rax,rbx
  40ff87:	movsxd r8,DWORD PTR [rax]
  40ff8a:	xor    r9d,r9d
  40ff8d:	xor    eax,eax
  40ff8f:	call   4070c0 <mmap@plt>
  40ff94:	mov    r12,rax
  40ff97:	cmp    rax,0xffffffffffffffff
  40ff9b:	jne    40ffbf <__swc_fn_3464c816_000107_4f8da17c+0x5bf>
  40ff9d:	movsxd rdi,DWORD PTR [rbx]
  40ffa0:	xor    eax,eax
  40ffa2:	call   4070b0 <close@plt>
  40ffa7:	mov    rdi,r15
  40ffaa:	xor    eax,eax
  40ffac:	call   407190 <closedir@plt>
  40ffb1:	movsxd rdi,r13d
  40ffb4:	xor    eax,eax
  40ffb6:	call   4070b0 <close@plt>
  40ffbb:	xor    eax,eax
  40ffbd:	jmp    40ffd6 <__swc_fn_3464c816_000107_4f8da17c+0x5d6>
  40ffbf:	mov    rdi,r15
  40ffc2:	xor    eax,eax
  40ffc4:	call   407190 <closedir@plt>
  40ffc9:	movsxd rdi,r13d
  40ffcc:	xor    eax,eax
  40ffce:	call   4070b0 <close@plt>
  40ffd3:	mov    rax,r12
  40ffd6:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40ffdf:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40ffe8:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40fff1:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40fffa:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  410003:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  41000c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  410015:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  41001e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  410027:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  410030:	add    rsp,0x170
  410037:	pop    r15
  410039:	pop    r14
  41003b:	pop    r13
  41003d:	pop    rsi
  41003e:	pop    rdi
  41003f:	pop    r12
  410041:	pop    rbx
  410042:	ret
