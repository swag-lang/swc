
/workspace/prompt2-20261115/session-combined-micro/base/raytrace/raytrace:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <getpid@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <getpid@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <munmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <munmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <exit@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <exit@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <pthread_key_create@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <pthread_key_create@GLIBC_2.34>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_setspecific@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <pthread_setspecific@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <syscall@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <syscall@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dladdr@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <dladdr@GLIBC_2.34>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <open@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <open@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <lseek@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <lseek@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <close@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <close@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <mmap@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <mmap@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <malloc@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <malloc@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <madvise@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf9a]        # 413080 <madvise@GLIBC_2.2.5>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <pthread_key_delete@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf92]        # 413088 <pthread_key_delete@GLIBC_2.34>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <gettid@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf8a]        # 413090 <gettid@GLIBC_2.30>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <clock_gettime@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf82]        # 413098 <clock_gettime@GLIBC_2.17>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <flock@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf7a]        # 4130a0 <flock@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <__errno_location@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf72]        # 4130a8 <__errno_location@GLIBC_2.2.5>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <opendir@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf6a]        # 4130b0 <opendir@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <dirfd@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf62]        # 4130b8 <dirfd@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <readdir@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <readdir@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <readlinkat@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <readlinkat@GLIBC_2.4>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <openat@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <openat@GLIBC_2.4>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <closedir@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <closedir@GLIBC_2.2.5>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <memfd_create@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <memfd_create@GLIBC_2.27>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <ftruncate@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <ftruncate@GLIBC_2.2.5>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <write@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <write@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <backtrace@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <backtrace@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <__x86_get_cpuid_feature_leaf@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <free@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <free@GLIBC_2.2.5>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_0a4ed24b_000176_0d61c738+0x1120>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40cd00 <__swc_fn_0a4ed24b_000121_12b4ed22>
  40724e:	xor    ecx,ecx
  407250:	call   40c420 <__swc_fn_0a4ed24b_000094_14db3cf9>
  407255:	call   40d9c0 <__swc_fn_0a4ed24b_000178_a483827c>
  40725a:	call   40f4b0 <__swc_fn_0a4ed24b_000095_337e587a>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_0a4ed24b_000000_46f18a51>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_0a4ed24b_000003_7ab4792e>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_0a4ed24b_000003_7ab4792e+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   409260 <__swc_fn_0a4ed24b_000111_b25e3a45>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_0a4ed24b_000003_7ab4792e+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1cd81]        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1cd7a]        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_0a4ed24b_000003_7ab4792e+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_0a4ed24b_000003_7ab4792e+0x30>
  4072e6:	lea    rcx,[rip+0x1cd63]        # 424050 <__swc_bss_base_0a4ed24b+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1cd5c]        # 424050 <__swc_bss_base_0a4ed24b+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_0a4ed24b_000003_7ab4792e+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_0a4ed24b_000003_7ab4792e+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_0a4ed24b_000006_a23dca5f>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40dd60 <__swc_fn_0a4ed24b_000011_6493fbbc>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_0a4ed24b_000012_c7df5d22>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_0a4ed24b_000006_a23dca5f+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_0a4ed24b_000003_7ab4792e>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_0a4ed24b_000006_a23dca5f+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_0a4ed24b_000009_d7e2bb25>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_0a4ed24b_000009_d7e2bb25+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40a7b0 <__swc_fn_0a4ed24b_000007_614a4804>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40dd50 <__swc_fn_0a4ed24b_000008_4e857afc>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_0a4ed24b_000009_d7e2bb25+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_0a4ed24b_000009_d7e2bb25+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_0a4ed24b_000012_c7df5d22>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_0a4ed24b_000015_07eb9884>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_0a4ed24b_000015_07eb9884+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_0a4ed24b_000015_07eb9884+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_0a4ed24b_000015_07eb9884+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_0a4ed24b_000015_07eb9884+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40dec0 <__swc_fn_0a4ed24b_000017_4df2d1a0>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_0a4ed24b_000015_07eb9884+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1cb3d]        # 424058 <__swc_bss_base_0a4ed24b+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1cb36]        # 424058 <__swc_bss_base_0a4ed24b+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_0a4ed24b_000015_07eb9884+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_0a4ed24b_000015_07eb9884+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40dd60 <__swc_fn_0a4ed24b_000011_6493fbbc>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_0a4ed24b_000015_07eb9884+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   40ca20 <__swc_fn_0a4ed24b_000112_759e9ceb>
  407569:	lea    rcx,[rip+0x1cad8]        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1cad1]        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_0a4ed24b_000015_07eb9884+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_0a4ed24b_000015_07eb9884+0x110>
  407598:	lea    rcx,[rip+0x1cac1]        # 424060 <__swc_bss_base_0a4ed24b+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1caba]        # 424060 <__swc_bss_base_0a4ed24b+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_0a4ed24b_000015_07eb9884+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_0a4ed24b_000015_07eb9884+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_0a4ed24b_000018_7d1e8a10>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_0a4ed24b_000015_07eb9884+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_0a4ed24b_000018_7d1e8a10>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_0a4ed24b_000018_7d1e8a10+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_0a4ed24b_000018_7d1e8a10+0x10>

0000000000407630 <__swc_fn_0a4ed24b_000021_491ac000>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_0a4ed24b_000015_07eb9884>
  40763e:	lea    rdi,[rip+0x1cbab]        # 4241f0 <__swc_bss_base_0a4ed24b+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   4098c0 <__swc_fn_0a4ed24b_000135_e3032dc2>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1cb94]        # 4241f8 <__swc_bss_base_0a4ed24b+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1cb89],rsi        # 4241f8 <__swc_bss_base_0a4ed24b+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_0a4ed24b_000024_4aca8b9e>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_0a4ed24b_000027_4aca8b9e>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_0a4ed24b_000030_06a93956>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_0a4ed24b_000030_06a93956+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1a92c]        # 422000 <__swc_data_base_0a4ed24b>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_0a4ed24b_000030_06a93956+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_0a4ed24b_000030_06a93956+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_0a4ed24b_000030_06a93956+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40e080 <__swc_fn_0a4ed24b_000032_84881cd8>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_0a4ed24b_000030_06a93956+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_0a4ed24b_000036_8d895ba1>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_0a4ed24b_000030_06a93956+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_0a4ed24b_000042_bab03645>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_0a4ed24b_000033_7ca1566d>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40ac60 <__swc_fn_0a4ed24b_000031_90860ff2>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   409740 <__swc_fn_0a4ed24b_000129_74b163fe>
  407734:	mov    rcx,rsi
  407737:	call   40e080 <__swc_fn_0a4ed24b_000032_84881cd8>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_0a4ed24b_000036_8d895ba1>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_0a4ed24b_000039_40d1e569>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_0a4ed24b_000039_40d1e569+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_0a4ed24b_000039_40d1e569+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_0a4ed24b_000039_40d1e569+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_0a4ed24b_000039_40d1e569+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_0a4ed24b_000039_40d1e569+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   409340 <__swc_fn_0a4ed24b_000114_27d95464>
  4077ca:	lea    rcx,[rip+0x1c877]        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1c870]        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_0a4ed24b_000039_40d1e569+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_0a4ed24b_000039_40d1e569+0x90>
  4077f8:	lea    rcx,[rip+0x1c861]        # 424060 <__swc_bss_base_0a4ed24b+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1c85a]        # 424060 <__swc_bss_base_0a4ed24b+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_0a4ed24b_000039_40d1e569+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_0a4ed24b_000039_40d1e569+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_0a4ed24b_000042_bab03645>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_0a4ed24b_000042_bab03645+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40e650 <__swc_fn_0a4ed24b_000059_3ca3ac64>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   4098c0 <__swc_fn_0a4ed24b_000135_e3032dc2>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_0a4ed24b_000042_bab03645+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_0a4ed24b_000042_bab03645+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_0a4ed24b_000009_d7e2bb25>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_0a4ed24b_000042_bab03645+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40dd80 <__swc_fn_0a4ed24b_000014_afb279e2>
  40791e:	jmp    407941 <__swc_fn_0a4ed24b_000042_bab03645+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_0a4ed24b_000042_bab03645+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_0a4ed24b_000042_bab03645+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_0a4ed24b_000042_bab03645+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40ae20 <__swc_fn_0a4ed24b_000043_957e4917>
  407997:	mov    rcx,rdi
  40799a:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_0a4ed24b_000039_40d1e569>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_0a4ed24b_000045_1fe0f4e2>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_0a4ed24b_000045_1fe0f4e2+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_0a4ed24b_000045_1fe0f4e2+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_0a4ed24b_000045_1fe0f4e2+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_0a4ed24b_000045_1fe0f4e2+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   4098c0 <__swc_fn_0a4ed24b_000135_e3032dc2>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_0a4ed24b_000045_1fe0f4e2+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_0a4ed24b_000045_1fe0f4e2+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_0a4ed24b_000045_1fe0f4e2+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_0a4ed24b_000045_1fe0f4e2+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_0a4ed24b_000009_d7e2bb25>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_0a4ed24b_000045_1fe0f4e2+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_0a4ed24b_000045_1fe0f4e2+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_0a4ed24b_000045_1fe0f4e2+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_0a4ed24b_000045_1fe0f4e2+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_0a4ed24b_000045_1fe0f4e2+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40a860 <__swc_fn_0a4ed24b_000013_9ba72deb>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_0a4ed24b_000045_1fe0f4e2+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_0a4ed24b_000045_1fe0f4e2+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_0a4ed24b_000045_1fe0f4e2+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_0a4ed24b_000045_1fe0f4e2+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40df00 <__swc_fn_0a4ed24b_000020_a66e8b97>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_0a4ed24b_000045_1fe0f4e2+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40a860 <__swc_fn_0a4ed24b_000013_9ba72deb>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_0a4ed24b_000045_1fe0f4e2+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_0a4ed24b_000021_491ac000>
  407c07:	mov    rcx,r14
  407c0a:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_0a4ed24b_000045_1fe0f4e2+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_0a4ed24b_000045_1fe0f4e2+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_0a4ed24b_000045_1fe0f4e2+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_0a4ed24b_000048_c877e9d2>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_0a4ed24b_000048_c877e9d2+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_0a4ed24b_000048_c877e9d2+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_0a4ed24b_000048_c877e9d2+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_0a4ed24b_000048_c877e9d2+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40e2b0 <__swc_fn_0a4ed24b_000047_bc5ec610>
  407d14:	jmp    407ce0 <__swc_fn_0a4ed24b_000048_c877e9d2+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_0a4ed24b_000048_c877e9d2+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_0a4ed24b_000048_c877e9d2+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_0a4ed24b_000048_c877e9d2+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_0a4ed24b_000048_c877e9d2+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_0a4ed24b_000048_c877e9d2+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_0a4ed24b_000048_c877e9d2+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_0a4ed24b_000048_c877e9d2+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_0a4ed24b_000051_f7021588>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_0a4ed24b_000051_f7021588+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_0a4ed24b_000051_f7021588+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_0a4ed24b_000051_f7021588+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_0a4ed24b_000051_f7021588+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40e210 <__swc_fn_0a4ed24b_000044_9c2ade9b>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40dd80 <__swc_fn_0a4ed24b_000014_afb279e2>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_0a4ed24b_000054_ae20ea33>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   4098c0 <__swc_fn_0a4ed24b_000135_e3032dc2>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_0a4ed24b_000054_ae20ea33+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_0a4ed24b_000054_ae20ea33+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_0a4ed24b_000054_ae20ea33+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_0a4ed24b_000057_5b81d8b6>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_0a4ed24b_000060_e6407a0a>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_0a4ed24b_000060_e6407a0a+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_0a4ed24b_000039_40d1e569>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_0a4ed24b_000060_e6407a0a+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_0a4ed24b_000063_c8a062d6>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40b1a0 <__swc_fn_0a4ed24b_000052_c7484fb0>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_0a4ed24b_000054_ae20ea33>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_0a4ed24b_000063_c8a062d6+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_0a4ed24b_000063_c8a062d6+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40b2c0 <__swc_fn_0a4ed24b_000058_8bd8d1d5>
  407f7f:	mov    rcx,rsi
  407f82:	call   40af00 <__swc_fn_0a4ed24b_000049_2ff013cc>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_0a4ed24b_000066_254b71af>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_0a4ed24b_000066_254b71af+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1c049]        # 424070 <__swc_bss_base_0a4ed24b+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1c04b]        # 424080 <__swc_bss_base_0a4ed24b+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_0a4ed24b_000066_254b71af+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_0a4ed24b_000066_254b71af+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40ab90 <__swc_fn_0a4ed24b_000022_3a2e2048>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_0a4ed24b_000066_254b71af+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_0a4ed24b_000063_c8a062d6>
  40808f:	jmp    408122 <__swc_fn_0a4ed24b_000066_254b71af+0x192>
  408094:	lea    rax,[rip+0x19f65]        # 422000 <__swc_data_base_0a4ed24b>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_0a4ed24b_000066_254b71af+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_0a4ed24b_000066_254b71af+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_0a4ed24b_000066_254b71af+0x135>
  4080b8:	call   40ac60 <__swc_fn_0a4ed24b_000031_90860ff2>
  4080bd:	mov    rcx,rax
  4080c0:	call   410280 <__swc_fn_0a4ed24b_000128_41c3251c>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_0a4ed24b_000066_254b71af+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_0a4ed24b_000066_254b71af+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_0a4ed24b_000066_254b71af+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40e2b0 <__swc_fn_0a4ed24b_000047_bc5ec610>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_0a4ed24b_000066_254b71af+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_0a4ed24b_000051_f7021588>
  408115:	jmp    408122 <__swc_fn_0a4ed24b_000066_254b71af+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40a7d0 <__swc_fn_0a4ed24b_000010_395bb04b>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_0a4ed24b_000069_e681a956>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_0a4ed24b_000036_8d895ba1>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_0a4ed24b_000069_e681a956+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1c09a]        # 424240 <__swc_bss_base_0a4ed24b+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_0a4ed24b_000069_e681a956+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   4098c0 <__swc_fn_0a4ed24b_000135_e3032dc2>
  4081b5:	mov    rcx,rsi
  4081b8:	call   40ea80 <__swc_fn_0a4ed24b_000068_7d4c42bf>
  4081bd:	mov    rcx,rsi
  4081c0:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_0a4ed24b_000072_bfa08900>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40e7d0 <__swc_fn_0a4ed24b_000065_f9f4b610>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_0a4ed24b_000075_524b0734>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   40ea80 <__swc_fn_0a4ed24b_000068_7d4c42bf>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_0a4ed24b_000078_a120bd2b>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_0a4ed24b_000078_a120bd2b+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_0a4ed24b_000078_a120bd2b+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_0a4ed24b_000081_c25a0e73>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_0a4ed24b_000084_ddf2b8a1>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_0a4ed24b_000090_a2d50c23>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_0a4ed24b_000084_ddf2b8a1+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_0a4ed24b_000084_ddf2b8a1+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_0a4ed24b_000084_ddf2b8a1+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_0a4ed24b_000084_ddf2b8a1+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_0a4ed24b_000090_a2d50c23>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_0a4ed24b_000084_ddf2b8a1+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_0a4ed24b_000084_ddf2b8a1+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_0a4ed24b_000084_ddf2b8a1+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_0a4ed24b_000084_ddf2b8a1+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_0a4ed24b_000084_ddf2b8a1+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_0a4ed24b_000084_ddf2b8a1+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_0a4ed24b_000084_ddf2b8a1+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_0a4ed24b_000084_ddf2b8a1+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_0a4ed24b_000084_ddf2b8a1+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_0a4ed24b_000084_ddf2b8a1+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40c2a0 <__swc_fn_0a4ed24b_000082_754dcd57>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_0a4ed24b_000084_ddf2b8a1+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_0a4ed24b_000084_ddf2b8a1+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_0a4ed24b_000084_ddf2b8a1+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40c2a0 <__swc_fn_0a4ed24b_000082_754dcd57>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_0a4ed24b_000084_ddf2b8a1+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_0a4ed24b_000084_ddf2b8a1>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_0a4ed24b_000084_ddf2b8a1+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_0a4ed24b_000084_ddf2b8a1+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_0a4ed24b_000087_ea575bb3>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_0a4ed24b_000090_a2d50c23>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_0a4ed24b_000087_ea575bb3+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   40eee0 <__swc_fn_0a4ed24b_000086_c45095aa>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_0a4ed24b_000087_ea575bb3+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_0a4ed24b_000087_ea575bb3+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_0a4ed24b_000087_ea575bb3+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40c2a0 <__swc_fn_0a4ed24b_000082_754dcd57>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_0a4ed24b_000087_ea575bb3+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_0a4ed24b_000087_ea575bb3>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_0a4ed24b_000087_ea575bb3+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_0a4ed24b_000087_ea575bb3+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_0a4ed24b_000090_a2d50c23>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_0a4ed24b_000090_a2d50c23+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_0a4ed24b_000090_a2d50c23+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_0a4ed24b_000090_a2d50c23+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_0a4ed24b_000090_a2d50c23+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40c2a0 <__swc_fn_0a4ed24b_000082_754dcd57>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40c2a0 <__swc_fn_0a4ed24b_000082_754dcd57>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_0a4ed24b_000090_a2d50c23+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_0a4ed24b_000090_a2d50c23+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_0a4ed24b_000090_a2d50c23+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_0a4ed24b_000090_a2d50c23+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_0a4ed24b_000090_a2d50c23>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_0a4ed24b_000090_a2d50c23+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_0a4ed24b_000090_a2d50c23+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_0a4ed24b_000090_a2d50c23+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_0a4ed24b_000090_a2d50c23+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_0a4ed24b_000090_a2d50c23+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_0a4ed24b_000090_a2d50c23+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_0a4ed24b_000090_a2d50c23+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_0a4ed24b_000090_a2d50c23+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_0a4ed24b_000090_a2d50c23+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_0a4ed24b_000090_a2d50c23+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_0a4ed24b_000090_a2d50c23+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_0a4ed24b_000090_a2d50c23+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_0a4ed24b_000090_a2d50c23+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_0a4ed24b_000090_a2d50c23+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_0a4ed24b_000090_a2d50c23+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_0a4ed24b_000090_a2d50c23+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   409de0 <__swc_fn_0a4ed24b_000147_32a497f3>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_0a4ed24b_000090_a2d50c23+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_0a4ed24b_000090_a2d50c23>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_0a4ed24b_000090_a2d50c23+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_0a4ed24b_000090_a2d50c23+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_0a4ed24b_000090_a2d50c23+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   409de0 <__swc_fn_0a4ed24b_000147_32a497f3>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   409de0 <__swc_fn_0a4ed24b_000147_32a497f3>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_0a4ed24b_000093_f8c16535>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40c3d0 <__swc_fn_0a4ed24b_000091_3d2f5a0d>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_0a4ed24b_000093_f8c16535+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_0a4ed24b_000093_f8c16535+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   410420 <__swc_fn_0a4ed24b_000137_a4ba10ed>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_0a4ed24b_000093_f8c16535+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0xa872]        # 4131c0 <__swc_rdata_base_0a4ed24b+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   40ff40 <__swc_fn_0a4ed24b_000116_035d76a1>
  408959:	call   40cc50 <__swc_fn_0a4ed24b_000118_7f430081>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_0a4ed24b_000096_ad982b35>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40896f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408975:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40897b:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  408981:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  408987:	mov    QWORD PTR [rsp+0x48],rdx
  40898c:	mov    rax,r8
  40898f:	cmp    r8,0x1
  408993:	mov    edx,0x1
  408998:	cmovb  rax,rdx
  40899c:	mov    QWORD PTR [rsp+0x50],rax
  4089a1:	mov    rbx,QWORD PTR [rcx+0x8]
  4089a5:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a9:	mov    rcx,QWORD PTR [rcx]
  4089ac:	lea    rdx,[rsp+0x8]
  4089b1:	call   rbx
  4089b3:	add    rsp,0x70
  4089b7:	pop    rbx
  4089b8:	ret
  4089b9:	add    BYTE PTR [rax],al
  4089bb:	add    BYTE PTR [rax],al
  4089bd:	add    BYTE PTR [rax],al
	...

00000000004089c0 <__swc_fn_0a4ed24b_000099_b4c6da83>:
  4089c0:	push   rbx
  4089c1:	push   rsi
  4089c2:	push   rdi
  4089c3:	sub    rsp,0x30
  4089c7:	mov    rbx,rcx
  4089ca:	test   rcx,rcx
  4089cd:	je     4089e2 <__swc_fn_0a4ed24b_000099_b4c6da83+0x22>
  4089cf:	mov    rcx,rbx
  4089d2:	mov    edx,0x1
  4089d7:	call   408200 <__swc_fn_0a4ed24b_000078_a120bd2b>
  4089dc:	cmp    rax,0x1
  4089e0:	je     4089ea <__swc_fn_0a4ed24b_000099_b4c6da83+0x2a>
  4089e2:	add    rsp,0x30
  4089e6:	pop    rdi
  4089e7:	pop    rsi
  4089e8:	pop    rbx
  4089e9:	ret
  4089ea:	lea    rsi,[rsp+0x8]
  4089ef:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089f4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089fa:	lea    rax,[rsp+0x18]
  4089ff:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  408a04:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408a0a:	mov    rcx,QWORD PTR [rsp+0x20]
  408a0f:	test   rcx,rcx
  408a12:	je     408a28 <__swc_fn_0a4ed24b_000099_b4c6da83+0x68>
  408a14:	test   DWORD PTR [rcx+0x28],0x400000
  408a1b:	je     408a28 <__swc_fn_0a4ed24b_000099_b4c6da83+0x68>
  408a1d:	mov    rdx,QWORD PTR [rcx+0x30]
  408a21:	test   rdx,rdx
  408a24:	cmovne rcx,rdx
  408a28:	mov    edi,DWORD PTR [rcx+0x20]
  408a2b:	mov    rcx,rax
  408a2e:	call   40c5b0 <__swc_fn_0a4ed24b_000100_3ed08774>
  408a33:	mov    rcx,rsi
  408a36:	mov    rdx,QWORD PTR [rsp+0x18]
  408a3b:	mov    r8,rdi
  408a3e:	call   408960 <__swc_fn_0a4ed24b_000096_ad982b35>
  408a43:	mov    rcx,QWORD PTR [rbx+0x28]
  408a47:	call   40f4c0 <__swc_fn_0a4ed24b_000098_00f01091>
  408a4c:	mov    rcx,rsi
  408a4f:	mov    rdx,rbx
  408a52:	mov    r8d,0x30
  408a58:	call   408960 <__swc_fn_0a4ed24b_000096_ad982b35>
  408a5d:	add    rsp,0x30
  408a61:	pop    rdi
  408a62:	pop    rsi
  408a63:	pop    rbx
  408a64:	ret
	...

0000000000408a80 <__swc_fn_0a4ed24b_000102_e9fdc18e>:
  408a80:	push   rbp
  408a81:	push   rbx
  408a82:	push   rsi
  408a83:	push   rdi
  408a84:	push   r12
  408a86:	push   r13
  408a88:	push   r14
  408a8a:	push   r15
  408a8c:	sub    rsp,0x500
  408a93:	mov    rbp,rsp
  408a96:	mov    rbx,rsp
  408a99:	mov    rsi,rdx
  408a9c:	mov    rdi,rcx
  408a9f:	mov    rcx,QWORD PTR [rip+0x1e29a]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  408aa6:	test   rcx,rcx
  408aa9:	jne    408ac3 <__swc_fn_0a4ed24b_000102_e9fdc18e+0x43>
  408aab:	sub    rsp,0x8
  408aaf:	call   40a1d0 <__swc_fn_0a4ed24b_000165_cf398896>
  408ab4:	add    rsp,0x8
  408ab8:	lea    rcx,[rax+0x1]
  408abc:	mov    QWORD PTR [rip+0x1e27d],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  408ac3:	dec    rcx
  408ac6:	sub    rsp,0x8
  408aca:	call   411d40 <__swc_fn_0a4ed24b_000167_fce60b2b>
  408acf:	add    rsp,0x8
  408ad3:	mov    r12,rax
  408ad6:	mov    QWORD PTR [rsp+0x4f0],rax
  408ade:	lea    rax,[rip+0xa81b]        # 413300 <__swc_rdata_base_0a4ed24b+0x1f0>
  408ae5:	sub    rsp,0x20
  408ae9:	mov    rcx,rsp
  408aec:	mov    QWORD PTR [rcx],rax
  408aef:	lea    r13,[rip+0xa81a]        # 413310 <__swc_rdata_base_0a4ed24b+0x200>
  408af6:	mov    QWORD PTR [rcx+0x8],r13
  408afa:	mov    QWORD PTR [rcx+0x10],rsp
  408afe:	mov    QWORD PTR [rcx+0x18],0x1
  408b06:	lea    rcx,[rsp+0x10]
  408b0b:	sub    rsp,0x8
  408b0f:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  408b14:	add    rsp,0x8
  408b18:	add    rsp,0x20
  408b1c:	lea    rax,[rip+0xa835]        # 413358 <__swc_rdata_base_0a4ed24b+0x248>
  408b23:	sub    rsp,0x20
  408b27:	mov    rcx,rsp
  408b2a:	mov    QWORD PTR [rcx],rax
  408b2d:	mov    QWORD PTR [rcx+0x8],r13
  408b31:	mov    QWORD PTR [rcx+0x10],rsp
  408b35:	mov    QWORD PTR [rcx+0x18],0x1
  408b3d:	lea    rcx,[rsp+0x10]
  408b42:	sub    rsp,0x8
  408b46:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  408b4b:	add    rsp,0x8
  408b4f:	add    rsp,0x20
  408b53:	lea    r14,[rip+0xa80e]        # 413368 <__swc_rdata_base_0a4ed24b+0x258>
  408b5a:	sub    rsp,0x50
  408b5e:	mov    rax,rsp
  408b61:	vmovups xmm0,XMMWORD PTR [rip+0xa937]        # 4134a0 <__swc_rdata_base_0a4ed24b+0x390>
  408b69:	vmovups XMMWORD PTR [rax],xmm0
  408b6d:	mov    QWORD PTR [rax+0x10],rsp
  408b71:	mov    QWORD PTR [rax+0x18],r13
  408b75:	mov    QWORD PTR [rax+0x20],rdi
  408b79:	lea    rdi,[rip+0xa7f8]        # 413378 <__swc_rdata_base_0a4ed24b+0x268>
  408b80:	mov    QWORD PTR [rax+0x28],rdi
  408b84:	mov    QWORD PTR [rax+0x30],r14
  408b88:	mov    QWORD PTR [rax+0x38],r13
  408b8c:	lea    rcx,[rsp+0x10]
  408b91:	mov    QWORD PTR [rax+0x40],rcx
  408b95:	mov    QWORD PTR [rax+0x48],0x3
  408b9d:	lea    rcx,[rsp+0x40]
  408ba2:	sub    rsp,0x8
  408ba6:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  408bab:	add    rsp,0x8
  408baf:	add    rsp,0x50
  408bb3:	lea    rax,[rip+0xa806]        # 4133c0 <__swc_rdata_base_0a4ed24b+0x2b0>
  408bba:	sub    rsp,0x20
  408bbe:	mov    rcx,rsp
  408bc1:	mov    QWORD PTR [rcx],rax
  408bc4:	mov    QWORD PTR [rcx+0x8],r13
  408bc8:	mov    QWORD PTR [rcx+0x10],rsp
  408bcc:	mov    QWORD PTR [rcx+0x18],0x1
  408bd4:	lea    rcx,[rsp+0x10]
  408bd9:	sub    rsp,0x8
  408bdd:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  408be2:	add    rsp,0x8
  408be6:	add    rsp,0x20
  408bea:	mov    eax,DWORD PTR [rsi+0x20]
  408bed:	mov    ecx,DWORD PTR [rsi+0x24]
  408bf0:	sub    rsp,0xa0
  408bf7:	mov    rdx,rsp
  408bfa:	mov    QWORD PTR [rdx+0x30],rsi
  408bfe:	mov    QWORD PTR [rdx+0x38],rdi
  408c02:	vmovups xmm0,XMMWORD PTR [rip+0xa82e]        # 413438 <__swc_rdata_base_0a4ed24b+0x328>
  408c0a:	vmovups XMMWORD PTR [rdx],xmm0
  408c0e:	mov    QWORD PTR [rdx+0x40],rsp
  408c12:	mov    QWORD PTR [rdx+0x48],r13
  408c16:	mov    DWORD PTR [rdx+0x10],eax
  408c19:	lea    rax,[rsp+0x10]
  408c1e:	mov    QWORD PTR [rdx+0x50],rax
  408c22:	lea    rax,[rip+0xa7a7]        # 4133d0 <__swc_rdata_base_0a4ed24b+0x2c0>
  408c29:	mov    QWORD PTR [rdx+0x58],rax
  408c2d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c32:	lea    r8,[rsp+0x18]
  408c37:	mov    QWORD PTR [rdx+0x60],r8
  408c3b:	mov    QWORD PTR [rdx+0x68],r13
  408c3f:	mov    DWORD PTR [rdx+0x28],ecx
  408c42:	lea    rcx,[rdx+0x28]
  408c46:	mov    QWORD PTR [rdx+0x70],rcx
  408c4a:	mov    QWORD PTR [rdx+0x78],rax
  408c4e:	mov    QWORD PTR [rdx+0x80],r14
  408c55:	mov    QWORD PTR [rdx+0x88],r13
  408c5c:	lea    rax,[rdx+0x30]
  408c60:	mov    QWORD PTR [rdx+0x90],rax
  408c67:	mov    QWORD PTR [rdx+0x98],0x6
  408c72:	lea    rcx,[rdx+0x90]
  408c79:	sub    rsp,0x8
  408c7d:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  408c82:	add    rsp,0x8
  408c86:	add    rsp,0xa0
  408c8d:	sub    rsp,0x20
  408c91:	mov    rax,rsp
  408c94:	mov    QWORD PTR [rax],r14
  408c97:	mov    QWORD PTR [rax+0x8],r13
  408c9b:	mov    QWORD PTR [rax+0x10],rsp
  408c9f:	mov    QWORD PTR [rax+0x18],0x1
  408ca7:	lea    rcx,[rsp+0x10]
  408cac:	sub    rsp,0x8
  408cb0:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  408cb5:	add    rsp,0x8
  408cb9:	add    rsp,0x20
  408cbd:	mov    eax,DWORD PTR [r12+0x9ac]
  408cc5:	test   eax,eax
  408cc7:	je     408f00 <__swc_fn_0a4ed24b_000102_e9fdc18e+0x480>
  408ccd:	lea    rax,[rip+0xa744]        # 413418 <__swc_rdata_base_0a4ed24b+0x308>
  408cd4:	sub    rsp,0x20
  408cd8:	mov    rcx,rsp
  408cdb:	mov    QWORD PTR [rcx],rax
  408cde:	mov    QWORD PTR [rcx+0x8],r13
  408ce2:	mov    QWORD PTR [rcx+0x10],rsp
  408ce6:	mov    QWORD PTR [rcx+0x18],0x1
  408cee:	lea    rcx,[rsp+0x10]
  408cf3:	sub    rsp,0x8
  408cf7:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  408cfc:	add    rsp,0x8
  408d00:	add    rsp,0x20
  408d04:	mov    eax,DWORD PTR [r12+0x9ac]
  408d0c:	dec    eax
  408d0e:	mov    esi,eax
  408d10:	test   esi,esi
  408d12:	jl     408ed0 <__swc_fn_0a4ed24b_000102_e9fdc18e+0x450>
  408d18:	jmp    408d24 <__swc_fn_0a4ed24b_000102_e9fdc18e+0x2a4>
  408d1a:	nop    WORD PTR [rax+rax*1+0x0]
  408d20:	dec    esi
  408d22:	jmp    408d10 <__swc_fn_0a4ed24b_000102_e9fdc18e+0x290>
  408d24:	lea    rax,[rip+0xa6fd]        # 413428 <__swc_rdata_base_0a4ed24b+0x318>
  408d2b:	sub    rsp,0x20
  408d2f:	mov    rcx,rsp
  408d32:	mov    QWORD PTR [rcx],rax
  408d35:	mov    QWORD PTR [rcx+0x8],r13
  408d39:	mov    QWORD PTR [rcx+0x10],rsp
  408d3d:	mov    QWORD PTR [rcx+0x18],0x1
  408d45:	lea    rcx,[rsp+0x10]
  408d4a:	sub    rsp,0x8
  408d4e:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  408d53:	add    rsp,0x8
  408d57:	add    rsp,0x20
  408d5b:	movsxd rax,esi
  408d5e:	imul   r15,rax,0x30
  408d62:	add    r15,r12
  408d65:	add    r15,0xf8
  408d6c:	sub    rsp,0x20
  408d70:	mov    rax,rsp
  408d73:	mov    QWORD PTR [rax],r15
  408d76:	mov    QWORD PTR [rax+0x8],rdi
  408d7a:	mov    QWORD PTR [rax+0x10],rsp
  408d7e:	mov    QWORD PTR [rax+0x18],0x1
  408d86:	lea    rcx,[rsp+0x10]
  408d8b:	sub    rsp,0x8
  408d8f:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  408d94:	add    rsp,0x8
  408d98:	add    rsp,0x20
  408d9c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408da4:	lea    rsi,[rip+0xa68d]        # 413438 <__swc_rdata_base_0a4ed24b+0x328>
  408dab:	sub    rsp,0x20
  408daf:	mov    rax,rsp
  408db2:	mov    QWORD PTR [rax],rsi
  408db5:	mov    QWORD PTR [rax+0x8],r13
  408db9:	mov    QWORD PTR [rax+0x10],rsp
  408dbd:	mov    QWORD PTR [rax+0x18],0x1
  408dc5:	lea    rcx,[rsp+0x10]
  408dca:	sub    rsp,0x8
  408dce:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  408dd3:	add    rsp,0x8
  408dd7:	add    rsp,0x20
  408ddb:	sub    rsp,0x30
  408ddf:	mov    rax,rsp
  408de2:	mov    ecx,DWORD PTR [r15+0x20]
  408de6:	mov    QWORD PTR [rax],rcx
  408de9:	mov    QWORD PTR [rax+0x8],rsp
  408ded:	lea    rdi,[rip+0xa654]        # 413448 <__swc_rdata_base_0a4ed24b+0x338>
  408df4:	mov    QWORD PTR [rax+0x10],rdi
  408df8:	lea    rcx,[rsp+0x8]
  408dfd:	mov    QWORD PTR [rax+0x18],rcx
  408e01:	mov    QWORD PTR [rax+0x20],0x1
  408e09:	lea    rcx,[rsp+0x18]
  408e0e:	sub    rsp,0x8
  408e12:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  408e17:	add    rsp,0x8
  408e1b:	add    rsp,0x30
  408e1f:	sub    rsp,0x20
  408e23:	mov    rax,rsp
  408e26:	mov    QWORD PTR [rax],rsi
  408e29:	mov    QWORD PTR [rax+0x8],r13
  408e2d:	mov    QWORD PTR [rax+0x10],rsp
  408e31:	mov    QWORD PTR [rax+0x18],0x1
  408e39:	lea    rcx,[rsp+0x10]
  408e3e:	sub    rsp,0x8
  408e42:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  408e47:	add    rsp,0x8
  408e4b:	add    rsp,0x20
  408e4f:	sub    rsp,0x30
  408e53:	mov    rax,rsp
  408e56:	mov    ecx,DWORD PTR [r15+0x24]
  408e5a:	mov    QWORD PTR [rax],rcx
  408e5d:	mov    QWORD PTR [rax+0x8],rsp
  408e61:	mov    QWORD PTR [rax+0x10],rdi
  408e65:	lea    rcx,[rsp+0x8]
  408e6a:	mov    QWORD PTR [rax+0x18],rcx
  408e6e:	mov    QWORD PTR [rax+0x20],0x1
  408e76:	lea    rcx,[rsp+0x18]
  408e7b:	sub    rsp,0x8
  408e7f:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  408e84:	add    rsp,0x8
  408e88:	add    rsp,0x30
  408e8c:	sub    rsp,0x20
  408e90:	mov    rax,rsp
  408e93:	mov    QWORD PTR [rax],r14
  408e96:	mov    QWORD PTR [rax+0x8],r13
  408e9a:	mov    QWORD PTR [rax+0x10],rsp
  408e9e:	mov    QWORD PTR [rax+0x18],0x1
  408ea6:	lea    rcx,[rsp+0x10]
  408eab:	sub    rsp,0x8
  408eaf:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  408eb4:	add    rsp,0x8
  408eb8:	add    rsp,0x20
  408ebc:	lea    rdi,[rip+0xa4b5]        # 413378 <__swc_rdata_base_0a4ed24b+0x268>
  408ec3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408ecb:	jmp    408d20 <__swc_fn_0a4ed24b_000102_e9fdc18e+0x2a0>
  408ed0:	sub    rsp,0x20
  408ed4:	mov    rax,rsp
  408ed7:	mov    QWORD PTR [rax],r14
  408eda:	mov    QWORD PTR [rax+0x8],r13
  408ede:	mov    QWORD PTR [rax+0x10],rsp
  408ee2:	mov    QWORD PTR [rax+0x18],0x1
  408eea:	lea    rcx,[rsp+0x10]
  408eef:	sub    rsp,0x8
  408ef3:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  408ef8:	add    rsp,0x8
  408efc:	add    rsp,0x20
  408f00:	lea    rax,[rbx+0x28]
  408f04:	mov    rcx,rax
  408f07:	mov    QWORD PTR [rbx+0x28],0x0
  408f0f:	mov    QWORD PTR [rbx+0x30],0x0
  408f17:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408f1c:	add    rcx,0x10
  408f20:	mov    edx,0x1f
  408f25:	cs nop WORD PTR [rax+rax*1+0x0]
  408f2f:	nop
  408f30:	vmovups XMMWORD PTR [rcx],xmm0
  408f34:	add    rcx,0x10
  408f38:	sub    rdx,0x1
  408f3c:	jne    408f30 <__swc_fn_0a4ed24b_000102_e9fdc18e+0x4b0>
  408f3e:	lea    rsi,[rbx+0x228]
  408f45:	xor    ecx,ecx
  408f47:	cs nop WORD PTR [rax+rax*1+0x0]
  408f51:	cs nop WORD PTR [rax+rax*1+0x0]
  408f5b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f60:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f65:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f6a:	add    rcx,0x10
  408f6e:	cmp    rcx,0x200
  408f75:	jne    408f60 <__swc_fn_0a4ed24b_000102_e9fdc18e+0x4e0>
  408f77:	mov    eax,DWORD PTR [r12+0xbc8]
  408f7f:	lea    rcx,[r12+0x9c8]
  408f87:	mov    QWORD PTR [rbx+0x428],rcx
  408f8e:	mov    QWORD PTR [rbx+0x430],rax
  408f95:	lea    rdi,[rbx+0x438]
  408f9c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408fa4:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fac:	mov    eax,DWORD PTR [r12+0xbc8]
  408fb4:	test   eax,eax
  408fb6:	jne    409003 <__swc_fn_0a4ed24b_000102_e9fdc18e+0x583>
  408fb8:	lea    rax,[rbx+0x448]
  408fbf:	mov    QWORD PTR [rbx+0x448],rsi
  408fc6:	mov    QWORD PTR [rax+0x8],0x40
  408fce:	mov    ecx,0x1
  408fd3:	mov    rdx,rax
  408fd6:	sub    rsp,0x8
  408fda:	call   410060 <__swc_fn_0a4ed24b_000119_9175a56a>
  408fdf:	add    rsp,0x8
  408fe3:	mov    QWORD PTR [rbx+0x460],rsi
  408fea:	mov    ecx,eax
  408fec:	mov    QWORD PTR [rbx+0x468],rcx
  408ff3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408ffb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  409003:	mov    rsi,QWORD PTR [rbx+0x438]
  40900a:	mov    rax,QWORD PTR [rbx+0x440]
  409011:	mov    r15,rax
  409014:	xor    r12d,r12d
  409017:	test   r15,r15
  40901a:	je     4090d0 <__swc_fn_0a4ed24b_000102_e9fdc18e+0x650>
  409020:	mov    rax,QWORD PTR [rsi+r12*8]
  409024:	test   rax,rax
  409027:	je     409046 <__swc_fn_0a4ed24b_000102_e9fdc18e+0x5c6>
  409029:	lea    rcx,[rbx+0x4b8]
  409030:	mov    rdx,rax
  409033:	sub    rsp,0x8
  409037:	call   409f40 <__swc_fn_0a4ed24b_000162_60216e69>
  40903c:	add    rsp,0x8
  409040:	mov    al,BYTE PTR [rax]
  409042:	test   al,al
  409044:	jne    409052 <__swc_fn_0a4ed24b_000102_e9fdc18e+0x5d2>
  409046:	add    r12,0x1
  40904a:	sub    r15,0x1
  40904e:	jne    409020 <__swc_fn_0a4ed24b_000102_e9fdc18e+0x5a0>
  409050:	jmp    4090d0 <__swc_fn_0a4ed24b_000102_e9fdc18e+0x650>
  409052:	lea    rax,[rip+0xa437]        # 413490 <__swc_rdata_base_0a4ed24b+0x380>
  409059:	sub    rsp,0x20
  40905d:	mov    rcx,rsp
  409060:	mov    QWORD PTR [rcx],rax
  409063:	mov    QWORD PTR [rcx+0x8],r13
  409067:	mov    QWORD PTR [rcx+0x10],rsp
  40906b:	mov    QWORD PTR [rcx+0x18],0x1
  409073:	lea    rcx,[rsp+0x10]
  409078:	sub    rsp,0x8
  40907c:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  409081:	add    rsp,0x8
  409085:	add    rsp,0x20
  409089:	mov    rcx,rdi
  40908c:	xor    edx,edx
  40908e:	mov    al,0x1
  409090:	mov    r8,rax
  409093:	sub    rsp,0x8
  409097:	call   40d500 <__swc_fn_0a4ed24b_000163_8e41797b>
  40909c:	add    rsp,0x8
  4090a0:	sub    rsp,0x20
  4090a4:	mov    rax,rsp
  4090a7:	mov    QWORD PTR [rax],r14
  4090aa:	mov    QWORD PTR [rax+0x8],r13
  4090ae:	mov    QWORD PTR [rax+0x10],rsp
  4090b2:	mov    QWORD PTR [rax+0x18],0x1
  4090ba:	lea    rcx,[rsp+0x10]
  4090bf:	sub    rsp,0x8
  4090c3:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  4090c8:	add    rsp,0x8
  4090cc:	add    rsp,0x20
  4090d0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090d8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090e4:	add    rsp,0x500
  4090eb:	pop    r15
  4090ed:	pop    r14
  4090ef:	pop    r13
  4090f1:	pop    r12
  4090f3:	pop    rdi
  4090f4:	pop    rsi
  4090f5:	pop    rbx
  4090f6:	pop    rbp
  4090f7:	ret
	...

0000000000409100 <__swc_fn_0a4ed24b_000105_6fd80914>:
  409100:	sub    rsp,0x8
  409104:	test   r8,r8
  409107:	je     40910e <__swc_fn_0a4ed24b_000105_6fd80914+0xe>
  409109:	call   40f750 <__swc_fn_0a4ed24b_000104_5589fdbd>
  40910e:	add    rsp,0x8
  409112:	ret
	...

0000000000409120 <__swc_fn_0a4ed24b_000108_84af7666>:
  409120:	push   rsi
  409121:	push   rdi
  409122:	push   r12
  409124:	push   r13
  409126:	sub    rsp,0xd8
  40912d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409133:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  409139:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40913f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  409145:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40914b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  409154:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40915d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  409166:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40916f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  409178:	xor    eax,eax
  40917a:	call   407010 <getpid@plt>
  40917f:	mov    rsi,rax
  409182:	lea    rdi,[rip+0x1dbbf]        # 426d48 <__swc_bss_base_0a4ed24b+0x2d08>
  409189:	mov    r12,QWORD PTR [rdi]
  40918c:	test   r12,r12
  40918f:	je     40919d <__swc_fn_0a4ed24b_000108_84af7666+0x7d>
  409191:	cmp    DWORD PTR [r12+0x10],esi
  409196:	jne    40919d <__swc_fn_0a4ed24b_000108_84af7666+0x7d>
  409198:	mov    rax,r12
  40919b:	jmp    409200 <__swc_fn_0a4ed24b_000108_84af7666+0xe0>
  40919d:	mov    ecx,0x4
  4091a2:	mov    edx,0x18
  4091a7:	call   40f840 <__swc_fn_0a4ed24b_000107_4796e893>
  4091ac:	mov    rcx,rax
  4091af:	test   rax,rax
  4091b2:	jne    4091b8 <__swc_fn_0a4ed24b_000108_84af7666+0x98>
  4091b4:	xor    eax,eax
  4091b6:	jmp    409200 <__swc_fn_0a4ed24b_000108_84af7666+0xe0>
  4091b8:	mov    DWORD PTR [rcx+0x10],esi
  4091bb:	mov    rax,r12
  4091be:	lock cmpxchg QWORD PTR [rdi],rcx
  4091c3:	mov    r13,rax
  4091c6:	cmp    rax,r12
  4091c9:	je     4091df <__swc_fn_0a4ed24b_000108_84af7666+0xbf>
  4091cb:	mov    rdi,rcx
  4091ce:	mov    esi,0x18
  4091d3:	xor    eax,eax
  4091d5:	call   407020 <munmap@plt>
  4091da:	mov    rax,r13
  4091dd:	jmp    409200 <__swc_fn_0a4ed24b_000108_84af7666+0xe0>
  4091df:	test   r12,r12
  4091e2:	je     4091fd <__swc_fn_0a4ed24b_000108_84af7666+0xdd>
  4091e4:	mov    rdi,r12
  4091e7:	mov    esi,0x18
  4091ec:	xor    eax,eax
  4091ee:	mov    QWORD PTR [rsp+0x28],rcx
  4091f3:	call   407020 <munmap@plt>
  4091f8:	mov    rcx,QWORD PTR [rsp+0x28]
  4091fd:	mov    rax,rcx
  409200:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  409206:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40920c:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  409212:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  409218:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40921e:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409227:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  409230:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409239:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  409242:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40924b:	add    rsp,0xd8
  409252:	pop    r13
  409254:	pop    r12
  409256:	pop    rdi
  409257:	pop    rsi
  409258:	ret
  409259:	add    BYTE PTR [rax],al
  40925b:	add    BYTE PTR [rax],al
  40925d:	add    BYTE PTR [rax],al
	...

0000000000409260 <__swc_fn_0a4ed24b_000111_b25e3a45>:
  409260:	push   rbx
  409261:	push   r12
  409263:	push   rdi
  409264:	push   rsi
  409265:	sub    rsp,0xa8
  40926c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409272:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409278:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40927e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409284:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40928a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409290:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409296:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40929c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4092a5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4092ae:	mov    rbx,rdx
  4092b1:	mov    r12,rcx
  4092b4:	mov    rdi,rcx
  4092b7:	mov    rsi,rdx
  4092ba:	mov    edx,0x3
  4092bf:	xor    eax,eax
  4092c1:	call   407030 <mprotect@plt>
  4092c6:	test   eax,eax
  4092c8:	je     4092ce <__swc_fn_0a4ed24b_000111_b25e3a45+0x6e>
  4092ca:	xor    eax,eax
  4092cc:	jmp    4092e3 <__swc_fn_0a4ed24b_000111_b25e3a45+0x83>
  4092ce:	mov    rcx,r12
  4092d1:	mov    rdx,rbx
  4092d4:	mov    al,0x1
  4092d6:	mov    r8,rax
  4092d9:	call   40fe90 <__swc_fn_0a4ed24b_000110_a808fe76>
  4092de:	mov    eax,0x1
  4092e3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4092e9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4092ef:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4092f5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4092fb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409301:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409307:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40930d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409313:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40931c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409325:	add    rsp,0xa8
  40932c:	pop    rsi
  40932d:	pop    rdi
  40932e:	pop    r12
  409330:	pop    rbx
  409331:	ret
	...

0000000000409340 <__swc_fn_0a4ed24b_000114_27d95464>:
  409340:	sub    rsp,0x8
  409344:	test   rcx,rcx
  409347:	jne    40934e <__swc_fn_0a4ed24b_000114_27d95464+0xe>
  409349:	add    rsp,0x8
  40934d:	ret
  40934e:	call   40cb00 <__swc_fn_0a4ed24b_000115_1ba33335>
  409353:	add    rsp,0x8
  409357:	ret
	...

0000000000409360 <__swc_fn_0a4ed24b_000117_86a7fb9e>:
  409360:	push   rdi
  409361:	push   rsi
  409362:	sub    rsp,0xa8
  409369:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40936f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409375:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40937b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409381:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409387:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40938d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409393:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409399:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4093a2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4093ab:	xor    edi,edi
  4093ad:	xor    eax,eax
  4093af:	call   407040 <exit@plt>
  4093b4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4093ba:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4093c0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4093c6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4093cc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4093d2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4093d8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4093de:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4093e4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4093ed:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4093f6:	add    rsp,0xa8
  4093fd:	pop    rsi
  4093fe:	pop    rdi
  4093ff:	ret

0000000000409400 <__swc_fn_0a4ed24b_000120_ea68f292>:
  409400:	push   rbx
  409401:	push   rsi
  409402:	push   rdi
  409403:	push   r12
  409405:	sub    rsp,0x18
  409409:	mov    rbx,r8
  40940c:	mov    rsi,rcx
  40940f:	mov    rdi,rdx
  409412:	mov    rcx,QWORD PTR [rip+0x1d927]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  409419:	test   rcx,rcx
  40941c:	jne    40942e <__swc_fn_0a4ed24b_000120_ea68f292+0x2e>
  40941e:	call   40a1d0 <__swc_fn_0a4ed24b_000165_cf398896>
  409423:	lea    rcx,[rax+0x1]
  409427:	mov    QWORD PTR [rip+0x1d912],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40942e:	dec    rcx
  409431:	call   411d40 <__swc_fn_0a4ed24b_000167_fce60b2b>
  409436:	mov    r12,rax
  409439:	cmp    ebx,0x3
  40943c:	jne    40944f <__swc_fn_0a4ed24b_000120_ea68f292+0x4f>
  40943e:	mov    rax,QWORD PTR [r12+0xbd0]
  409446:	test   rax,rax
  409449:	jne    40958f <__swc_fn_0a4ed24b_000120_ea68f292+0x18f>
  40944f:	cmp    ebx,0x5
  409452:	jne    409476 <__swc_fn_0a4ed24b_000120_ea68f292+0x76>
  409454:	call   40c3d0 <__swc_fn_0a4ed24b_000091_3d2f5a0d>
  409459:	test   al,al
  40945b:	jne    409476 <__swc_fn_0a4ed24b_000120_ea68f292+0x76>
  40945d:	mov    rcx,rsi
  409460:	mov    rdx,rdi
  409463:	call   411cf0 <__swc_fn_0a4ed24b_000164_1962e12a>
  409468:	test   al,al
  40946a:	je     409476 <__swc_fn_0a4ed24b_000120_ea68f292+0x76>
  40946c:	add    rsp,0x18
  409470:	pop    r12
  409472:	pop    rdi
  409473:	pop    rsi
  409474:	pop    rbx
  409475:	ret
  409476:	call   40c3d0 <__swc_fn_0a4ed24b_000091_3d2f5a0d>
  40947b:	test   al,al
  40947d:	jne    4094f2 <__swc_fn_0a4ed24b_000120_ea68f292+0xf2>
  40947f:	lea    rax,[rsp+0x8]
  409484:	vmovups xmm0,XMMWORD PTR [rsi]
  409488:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40948e:	mov    rcx,QWORD PTR [rsp+0x8]
  409493:	test   rcx,rcx
  409496:	jne    4094e7 <__swc_fn_0a4ed24b_000120_ea68f292+0xe7>
  409498:	cmp    ebx,0x3
  40949b:	je     4094a9 <__swc_fn_0a4ed24b_000120_ea68f292+0xa9>
  40949d:	cmp    ebx,0x4
  4094a0:	je     4094b9 <__swc_fn_0a4ed24b_000120_ea68f292+0xb9>
  4094a2:	cmp    ebx,0x5
  4094a5:	je     4094c9 <__swc_fn_0a4ed24b_000120_ea68f292+0xc9>
  4094a7:	jmp    4094d9 <__swc_fn_0a4ed24b_000120_ea68f292+0xd9>
  4094a9:	vmovups xmm0,XMMWORD PTR [rip+0xa02f]        # 4134e0 <__swc_rdata_base_0a4ed24b+0x3d0>
  4094b1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094b7:	jmp    4094e7 <__swc_fn_0a4ed24b_000120_ea68f292+0xe7>
  4094b9:	vmovups xmm0,XMMWORD PTR [rip+0xa02f]        # 4134f0 <__swc_rdata_base_0a4ed24b+0x3e0>
  4094c1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094c7:	jmp    4094e7 <__swc_fn_0a4ed24b_000120_ea68f292+0xe7>
  4094c9:	vmovups xmm0,XMMWORD PTR [rip+0xa02f]        # 413500 <__swc_rdata_base_0a4ed24b+0x3f0>
  4094d1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094d7:	jmp    4094e7 <__swc_fn_0a4ed24b_000120_ea68f292+0xe7>
  4094d9:	vmovups xmm0,XMMWORD PTR [rip+0xa02f]        # 413510 <__swc_rdata_base_0a4ed24b+0x400>
  4094e1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094e7:	mov    rcx,rax
  4094ea:	mov    rdx,rdi
  4094ed:	call   40c620 <__swc_fn_0a4ed24b_000103_67100064>
  4094f2:	vmovups xmm0,XMMWORD PTR [rdi]
  4094f6:	vmovups XMMWORD PTR [r12+0x940],xmm0
  409500:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  409505:	vmovups XMMWORD PTR [r12+0x950],xmm0
  40950f:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  409514:	vmovups XMMWORD PTR [r12+0x960],xmm0
  40951e:	lea    rax,[r12+0x940]
  409526:	mov    QWORD PTR [r12+0x970],rax
  40952e:	mov    rax,QWORD PTR [rsi]
  409531:	mov    QWORD PTR [r12+0x978],rax
  409539:	mov    rax,QWORD PTR [rsi+0x8]
  40953d:	mov    QWORD PTR [r12+0x980],rax
  409545:	movsxd rax,ebx
  409548:	mov    QWORD PTR [r12+0x988],rax
  409550:	cmp    ebx,0x5
  409553:	je     40955c <__swc_fn_0a4ed24b_000120_ea68f292+0x15c>
  409555:	xor    ecx,ecx
  409557:	call   40a300 <__swc_fn_0a4ed24b_000174_176517f9>
  40955c:	mov    rbx,QWORD PTR [r12+0xbe8]
  409564:	test   rbx,rbx
  409567:	je     409578 <__swc_fn_0a4ed24b_000120_ea68f292+0x178>
  409569:	mov    rcx,r12
  40956c:	call   rbx
  40956e:	add    rsp,0x18
  409572:	pop    r12
  409574:	pop    rdi
  409575:	pop    rsi
  409576:	pop    rbx
  409577:	ret
  409578:	mov    rcx,rsi
  40957b:	call   40ff40 <__swc_fn_0a4ed24b_000116_035d76a1>
  409580:	call   40cc50 <__swc_fn_0a4ed24b_000118_7f430081>
  409585:	add    rsp,0x18
  409589:	pop    r12
  40958b:	pop    rdi
  40958c:	pop    rsi
  40958d:	pop    rbx
  40958e:	ret
  40958f:	mov    rcx,rsi
  409592:	mov    rdx,rdi
  409595:	call   40c620 <__swc_fn_0a4ed24b_000103_67100064>
  40959a:	jmp    40944f <__swc_fn_0a4ed24b_000120_ea68f292+0x4f>
	...

00000000004095a0 <__swc_fn_0a4ed24b_000123_9d2cbd72>:
  4095a0:	push   rdi
  4095a1:	push   rsi
  4095a2:	sub    rsp,0xb8
  4095a9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4095af:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4095b5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4095bb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4095c1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4095c7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4095cd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4095d3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4095dc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4095e5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4095ee:	mov    DWORD PTR [rsp+0x8],0x0
  4095f6:	lea    rdi,[rsp+0x8]
  4095fb:	xor    esi,esi
  4095fd:	xor    eax,eax
  4095ff:	call   407050 <pthread_key_create@plt>
  409604:	test   eax,eax
  409606:	jne    40960e <__swc_fn_0a4ed24b_000123_9d2cbd72+0x6e>
  409608:	mov    eax,DWORD PTR [rsp+0x8]
  40960c:	jmp    409615 <__swc_fn_0a4ed24b_000123_9d2cbd72+0x75>
  40960e:	mov    rax,0xffffffffffffffff
  409615:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40961b:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409621:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409627:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40962d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409633:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409639:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40963f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409648:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409651:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40965a:	add    rsp,0xb8
  409661:	pop    rsi
  409662:	pop    rdi
  409663:	ret
	...

0000000000409670 <__swc_fn_0a4ed24b_000126_102fe7b9>:
  409670:	push   rdi
  409671:	push   rsi
  409672:	sub    rsp,0xb8
  409679:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40967f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409685:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40968b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409691:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409697:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40969d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4096a3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4096ac:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4096b5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4096be:	mov    DWORD PTR [rsp+0x8],0x0
  4096c6:	lea    rdi,[rsp+0x8]
  4096cb:	mov    rsi,rcx
  4096ce:	xor    eax,eax
  4096d0:	call   407050 <pthread_key_create@plt>
  4096d5:	test   eax,eax
  4096d7:	jne    4096e2 <__swc_fn_0a4ed24b_000126_102fe7b9+0x72>
  4096d9:	mov    eax,DWORD PTR [rsp+0x8]
  4096dd:	inc    rax
  4096e0:	jmp    4096e4 <__swc_fn_0a4ed24b_000126_102fe7b9+0x74>
  4096e2:	xor    eax,eax
  4096e4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4096ea:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4096f0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4096f6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4096fc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409702:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409708:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40970e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409717:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409720:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409729:	add    rsp,0xb8
  409730:	pop    rsi
  409731:	pop    rdi
  409732:	ret
	...

0000000000409740 <__swc_fn_0a4ed24b_000129_74b163fe>:
  409740:	push   rdi
  409741:	push   rsi
  409742:	sub    rsp,0xa8
  409749:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40974f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409755:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40975b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409761:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409767:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40976d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409773:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409779:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409782:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40978b:	test   rcx,rcx
  40978e:	setne  al
  409791:	je     4097aa <__swc_fn_0a4ed24b_000129_74b163fe+0x6a>
  409793:	lea    rax,[rcx-0x1]
  409797:	mov    eax,eax
  409799:	mov    edi,eax
  40979b:	mov    rsi,rdx
  40979e:	xor    eax,eax
  4097a0:	call   407060 <pthread_setspecific@plt>
  4097a5:	test   eax,eax
  4097a7:	sete   al
  4097aa:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4097b0:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4097b6:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4097bc:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4097c2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4097c8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4097ce:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4097d4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4097da:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4097e3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4097ec:	add    rsp,0xa8
  4097f3:	pop    rsi
  4097f4:	pop    rdi
  4097f5:	ret
	...

0000000000409800 <__swc_fn_0a4ed24b_000132_f908e7f9>:
  409800:	push   rdi
  409801:	push   rsi
  409802:	sub    rsp,0xa8
  409809:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40980f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409815:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40981b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409821:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409827:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40982d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409833:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409839:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409842:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40984b:	mov    rax,rdx
  40984e:	mov    QWORD PTR [rsp],0x0
  409856:	mov    edi,0xca
  40985b:	mov    rsi,rcx
  40985e:	mov    edx,0x81
  409863:	mov    eax,eax
  409865:	mov    ecx,eax
  409867:	xor    r8d,r8d
  40986a:	xor    r9d,r9d
  40986d:	xor    eax,eax
  40986f:	call   407070 <syscall@plt>
  409874:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40987a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409880:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409886:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40988c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409892:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409898:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40989e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4098a4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4098ad:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4098b6:	add    rsp,0xa8
  4098bd:	pop    rsi
  4098be:	pop    rdi
  4098bf:	ret

00000000004098c0 <__swc_fn_0a4ed24b_000135_e3032dc2>:
  4098c0:	sub    rsp,0x8
  4098c4:	call   40cff0 <__swc_fn_0a4ed24b_000133_4b2af8da>
  4098c9:	add    rsp,0x8
  4098cd:	ret
	...

00000000004098d0 <__swc_fn_0a4ed24b_000138_0c00232f>:
  4098d0:	push   rdi
  4098d1:	push   rsi
  4098d2:	sub    rsp,0xc8
  4098d9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4098df:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4098e5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4098eb:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4098f1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4098f7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4098fd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  409906:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40990f:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  409918:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  409921:	vxorps xmm0,xmm0,xmm0
  409925:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40992b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409931:	mov    rdi,rcx
  409934:	lea    rsi,[rsp+0x8]
  409939:	xor    eax,eax
  40993b:	call   407080 <dladdr@plt>
  409940:	xor    ecx,ecx
  409942:	test   eax,eax
  409944:	je     40994b <__swc_fn_0a4ed24b_000138_0c00232f+0x7b>
  409946:	mov    rcx,QWORD PTR [rsp+0x10]
  40994b:	mov    rax,rcx
  40994e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  409954:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40995a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  409960:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  409966:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40996c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  409972:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40997b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  409984:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40998d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  409996:	add    rsp,0xc8
  40999d:	pop    rsi
  40999e:	pop    rdi
  40999f:	ret

00000000004099a0 <__swc_fn_0a4ed24b_000141_2ce79e3b>:
  4099a0:	push   rbx
  4099a1:	push   r12
  4099a3:	push   r13
  4099a5:	push   rdi
  4099a6:	push   rsi
  4099a7:	push   r14
  4099a9:	push   r15
  4099ab:	sub    rsp,0x150
  4099b2:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  4099bb:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  4099c4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  4099cd:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  4099d6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  4099df:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4099e8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4099f1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4099fa:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  409a03:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  409a0c:	mov    rbx,rdx
  409a0f:	mov    QWORD PTR [rsp+0x98],rdx
  409a17:	mov    r12,rcx
  409a1a:	mov    QWORD PTR [rsp+0xa0],rcx
  409a22:	mov    QWORD PTR [rbx],0x0
  409a29:	lea    r13,[rip+0x1d350]        # 426d80 <__swc_bss_base_0a4ed24b+0x2d40>
  409a30:	mov    rcx,r13
  409a33:	call   4098c0 <__swc_fn_0a4ed24b_000135_e3032dc2>
  409a38:	mov    rax,QWORD PTR [rip+0x1d349]        # 426d88 <__swc_bss_base_0a4ed24b+0x2d48>
  409a3f:	test   rax,rax
  409a42:	je     409a79 <__swc_fn_0a4ed24b_000141_2ce79e3b+0xd9>
  409a44:	cs nop WORD PTR [rax+rax*1+0x0]
  409a4e:	xchg   ax,ax
  409a50:	cmp    QWORD PTR [rax+0x8],r12
  409a54:	jne    409a71 <__swc_fn_0a4ed24b_000141_2ce79e3b+0xd1>
  409a56:	mov    rcx,QWORD PTR [rax+0x18]
  409a5a:	mov    QWORD PTR [rbx],rcx
  409a5d:	mov    rbx,QWORD PTR [rax+0x10]
  409a61:	mov    rcx,r13
  409a64:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  409a69:	mov    rax,rbx
  409a6c:	jmp    409c5b <__swc_fn_0a4ed24b_000141_2ce79e3b+0x2bb>
  409a71:	mov    rax,QWORD PTR [rax]
  409a74:	test   rax,rax
  409a77:	jne    409a50 <__swc_fn_0a4ed24b_000141_2ce79e3b+0xb0>
  409a79:	vxorps xmm0,xmm0,xmm0
  409a7d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  409a83:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  409a89:	mov    rdi,r12
  409a8c:	lea    rsi,[rsp+0x10]
  409a91:	xor    eax,eax
  409a93:	call   407080 <dladdr@plt>
  409a98:	test   eax,eax
  409a9a:	sete   al
  409a9d:	je     409aaa <__swc_fn_0a4ed24b_000141_2ce79e3b+0x10a>
  409a9f:	mov    rax,QWORD PTR [rsp+0x10]
  409aa4:	test   rax,rax
  409aa7:	sete   al
  409aaa:	test   al,al
  409aac:	je     409abd <__swc_fn_0a4ed24b_000141_2ce79e3b+0x11d>
  409aae:	mov    rcx,r13
  409ab1:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  409ab6:	xor    eax,eax
  409ab8:	jmp    409c5b <__swc_fn_0a4ed24b_000141_2ce79e3b+0x2bb>
  409abd:	mov    rdi,QWORD PTR [rsp+0x10]
  409ac2:	mov    esi,0x80000
  409ac7:	xor    eax,eax
  409ac9:	call   407090 <open@plt>
  409ace:	lea    r14,[rsp+0x30]
  409ad3:	mov    DWORD PTR [rsp+0x30],eax
  409ad7:	cmp    DWORD PTR [r14],0x0
  409adb:	jge    409aec <__swc_fn_0a4ed24b_000141_2ce79e3b+0x14c>
  409add:	mov    rcx,r13
  409ae0:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  409ae5:	xor    eax,eax
  409ae7:	jmp    409c5b <__swc_fn_0a4ed24b_000141_2ce79e3b+0x2bb>
  409aec:	mov    rax,r14
  409aef:	movsxd rdi,DWORD PTR [rax]
  409af2:	xor    esi,esi
  409af4:	mov    edx,0x2
  409af9:	xor    eax,eax
  409afb:	call   4070a0 <lseek@plt>
  409b00:	mov    r15,rax
  409b03:	test   rax,rax
  409b06:	jg     409b21 <__swc_fn_0a4ed24b_000141_2ce79e3b+0x181>
  409b08:	movsxd rdi,DWORD PTR [r14]
  409b0b:	xor    eax,eax
  409b0d:	call   4070b0 <close@plt>
  409b12:	mov    rcx,r13
  409b15:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  409b1a:	xor    eax,eax
  409b1c:	jmp    409c5b <__swc_fn_0a4ed24b_000141_2ce79e3b+0x2bb>
  409b21:	xor    edi,edi
  409b23:	mov    rsi,r15
  409b26:	mov    edx,0x1
  409b2b:	mov    ecx,0x2
  409b30:	mov    rax,r14
  409b33:	movsxd r8,DWORD PTR [rax]
  409b36:	xor    r9d,r9d
  409b39:	xor    eax,eax
  409b3b:	call   4070c0 <mmap@plt>
  409b40:	mov    rbx,rax
  409b43:	test   rax,rax
  409b46:	sete   al
  409b49:	cmp    rbx,0xffffffffffffffff
  409b4d:	sete   cl
  409b50:	or     al,cl
  409b52:	je     409b6d <__swc_fn_0a4ed24b_000141_2ce79e3b+0x1cd>
  409b54:	movsxd rdi,DWORD PTR [r14]
  409b57:	xor    eax,eax
  409b59:	call   4070b0 <close@plt>
  409b5e:	mov    rcx,r13
  409b61:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  409b66:	xor    eax,eax
  409b68:	jmp    409c5b <__swc_fn_0a4ed24b_000141_2ce79e3b+0x2bb>
  409b6d:	lea    rax,[rsp+0x50]
  409b72:	mov    QWORD PTR [rax],0x0
  409b79:	mov    rcx,rbx
  409b7c:	mov    rdx,r15
  409b7f:	mov    r8,rax
  409b82:	call   4104e0 <__swc_fn_0a4ed24b_000140_c6b99a56>
  409b87:	mov    r12,rax
  409b8a:	test   rax,rax
  409b8d:	jne    409bb5 <__swc_fn_0a4ed24b_000141_2ce79e3b+0x215>
  409b8f:	mov    rdi,rbx
  409b92:	mov    rsi,r15
  409b95:	xor    eax,eax
  409b97:	call   407020 <munmap@plt>
  409b9c:	movsxd rdi,DWORD PTR [r14]
  409b9f:	xor    eax,eax
  409ba1:	call   4070b0 <close@plt>
  409ba6:	mov    rcx,r13
  409ba9:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  409bae:	xor    eax,eax
  409bb0:	jmp    409c5b <__swc_fn_0a4ed24b_000141_2ce79e3b+0x2bb>
  409bb5:	mov    edi,0x20
  409bba:	xor    eax,eax
  409bbc:	call   4070d0 <malloc@plt>
  409bc1:	test   rax,rax
  409bc4:	jne    409be9 <__swc_fn_0a4ed24b_000141_2ce79e3b+0x249>
  409bc6:	mov    rdi,rbx
  409bc9:	mov    rsi,r15
  409bcc:	xor    eax,eax
  409bce:	call   407020 <munmap@plt>
  409bd3:	movsxd rdi,DWORD PTR [r14]
  409bd6:	xor    eax,eax
  409bd8:	call   4070b0 <close@plt>
  409bdd:	mov    rcx,r13
  409be0:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  409be5:	xor    eax,eax
  409be7:	jmp    409c5b <__swc_fn_0a4ed24b_000141_2ce79e3b+0x2bb>
  409be9:	mov    rcx,QWORD PTR [rip+0x1d198]        # 426d88 <__swc_bss_base_0a4ed24b+0x2d48>
  409bf0:	mov    QWORD PTR [rsp+0x70],rcx
  409bf5:	mov    rcx,QWORD PTR [rsp+0xa0]
  409bfd:	mov    QWORD PTR [rsp+0x78],rcx
  409c02:	mov    QWORD PTR [rsp+0x80],r12
  409c0a:	mov    rcx,QWORD PTR [rsp+0x50]
  409c0f:	mov    QWORD PTR [rsp+0x88],rcx
  409c17:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  409c1d:	vmovups XMMWORD PTR [rax],xmm0
  409c21:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  409c2a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  409c2f:	mov    QWORD PTR [rip+0x1d152],rax        # 426d88 <__swc_bss_base_0a4ed24b+0x2d48>
  409c36:	mov    rax,QWORD PTR [rsp+0x50]
  409c3b:	mov    rbx,QWORD PTR [rsp+0x98]
  409c43:	mov    QWORD PTR [rbx],rax
  409c46:	movsxd rdi,DWORD PTR [r14]
  409c49:	xor    eax,eax
  409c4b:	call   4070b0 <close@plt>
  409c50:	mov    rcx,r13
  409c53:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  409c58:	mov    rax,r12
  409c5b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  409c64:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  409c6d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  409c76:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  409c7f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  409c88:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  409c91:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  409c9a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  409ca3:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  409cac:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  409cb5:	add    rsp,0x150
  409cbc:	pop    r15
  409cbe:	pop    r14
  409cc0:	pop    rsi
  409cc1:	pop    rdi
  409cc2:	pop    r13
  409cc4:	pop    r12
  409cc6:	pop    rbx
  409cc7:	ret
	...

0000000000409cd0 <__swc_fn_0a4ed24b_000144_72996a5b>:
  409cd0:	push   rbx
  409cd1:	sub    rsp,0xe0
  409cd8:	lea    rbx,[rsp+0x8]
  409cdd:	vxorps xmm0,xmm0,xmm0
  409ce1:	vmovups XMMWORD PTR [rbx],xmm0
  409ce5:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409cea:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409cef:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  409cf4:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  409cf9:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  409cfe:	mov    DWORD PTR [rbx+0x60],0x0
  409d05:	mov    r8,rbx
  409d08:	nop    DWORD PTR [rax+rax*1+0x0]
  409d10:	mov    r9,rcx
  409d13:	movabs rcx,0xcccccccccccccccd
  409d1d:	mov    rax,r9
  409d20:	mul    rcx
  409d23:	mov    r10,rdx
  409d26:	shr    r10,0x3
  409d2a:	mov    rcx,r10
  409d2d:	imul   rdx,r10,0xa
  409d31:	sub    r9,rdx
  409d34:	mov    rdx,QWORD PTR [rip+0x9805]        # 413540 <__swc_rdata_base_0a4ed24b+0x430>
  409d3b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  409d40:	mov    BYTE PTR [r8],dl
  409d43:	lea    rdx,[r8+0x1]
  409d47:	mov    r8,rdx
  409d4a:	test   r10,r10
  409d4d:	jne    409d10 <__swc_fn_0a4ed24b_000144_72996a5b+0x40>
  409d4f:	mov    BYTE PTR [rdx],0x0
  409d52:	sub    r8,0x1
  409d56:	mov    rax,rbx
  409d59:	cmp    rax,r8
  409d5c:	jae    409d76 <__swc_fn_0a4ed24b_000144_72996a5b+0xa6>
  409d5e:	xchg   ax,ax
  409d60:	mov    cl,BYTE PTR [r8]
  409d63:	mov    dl,BYTE PTR [rax]
  409d65:	mov    BYTE PTR [r8],dl
  409d68:	sub    r8,0x1
  409d6c:	mov    BYTE PTR [rax],cl
  409d6e:	inc    rax
  409d71:	cmp    rax,r8
  409d74:	jb     409d60 <__swc_fn_0a4ed24b_000144_72996a5b+0x90>
  409d76:	xor    eax,eax
  409d78:	test   rbx,rbx
  409d7b:	je     409d9e <__swc_fn_0a4ed24b_000144_72996a5b+0xce>
  409d7d:	mov    rcx,rbx
  409d80:	mov    dl,BYTE PTR [rcx]
  409d82:	test   dl,dl
  409d84:	je     409d9e <__swc_fn_0a4ed24b_000144_72996a5b+0xce>
  409d86:	cs nop WORD PTR [rax+rax*1+0x0]
  409d90:	add    rcx,0x1
  409d94:	add    rax,0x1
  409d98:	mov    dl,BYTE PTR [rcx]
  409d9a:	test   dl,dl
  409d9c:	jne    409d90 <__swc_fn_0a4ed24b_000144_72996a5b+0xc0>
  409d9e:	mov    QWORD PTR [rbx+0xa8],rbx
  409da5:	mov    QWORD PTR [rbx+0xb0],rax
  409dac:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  409db4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  409dbc:	lea    rcx,[rbx+0xb8]
  409dc3:	call   40ff40 <__swc_fn_0a4ed24b_000116_035d76a1>
  409dc8:	add    rsp,0xe0
  409dcf:	pop    rbx
  409dd0:	ret
	...

0000000000409de0 <__swc_fn_0a4ed24b_000147_32a497f3>:
  409de0:	sub    rsp,0x8
  409de4:	mov    rax,QWORD PTR [rcx+0x8]
  409de8:	mov    r8,QWORD PTR [rdx+0x8]
  409dec:	cmp    rax,r8
  409def:	je     409df8 <__swc_fn_0a4ed24b_000147_32a497f3+0x18>
  409df1:	xor    eax,eax
  409df3:	add    rsp,0x8
  409df7:	ret
  409df8:	test   rax,rax
  409dfb:	jne    409e0c <__swc_fn_0a4ed24b_000147_32a497f3+0x2c>
  409dfd:	test   r8,r8
  409e00:	jne    409e0c <__swc_fn_0a4ed24b_000147_32a497f3+0x2c>
  409e02:	mov    eax,0x1
  409e07:	add    rsp,0x8
  409e0b:	ret
  409e0c:	mov    rcx,QWORD PTR [rcx]
  409e0f:	mov    rdx,QWORD PTR [rdx]
  409e12:	test   rcx,rcx
  409e15:	sete   r8b
  409e19:	test   rdx,rdx
  409e1c:	sete   r9b
  409e20:	or     r8b,r9b
  409e23:	je     409e30 <__swc_fn_0a4ed24b_000147_32a497f3+0x50>
  409e25:	cmp    rcx,rdx
  409e28:	sete   al
  409e2b:	add    rsp,0x8
  409e2f:	ret
  409e30:	cmp    rcx,rdx
  409e33:	jne    409e3f <__swc_fn_0a4ed24b_000147_32a497f3+0x5f>
  409e35:	mov    eax,0x1
  409e3a:	add    rsp,0x8
  409e3e:	ret
  409e3f:	mov    r8,rax
  409e42:	call   40c6e0 <__swc_fn_0a4ed24b_000106_ed4b1681>
  409e47:	test   eax,eax
  409e49:	sete   al
  409e4c:	add    rsp,0x8
  409e50:	ret
	...

0000000000409e60 <__swc_fn_0a4ed24b_000150_9e4bc402>:
  409e60:	vxorps xmm0,xmm0,xmm0
  409e64:	vmovups XMMWORD PTR [rcx],xmm0
  409e68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e6d:	vxorps xmm0,xmm0,xmm0
  409e71:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e76:	vmovups xmm0,XMMWORD PTR [rip+0x977a]        # 4135f8 <__swc_rdata_base_0a4ed24b+0x4e8>
  409e7e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e83:	ret
	...

0000000000409e90 <__swc_fn_0a4ed24b_000153_9e4bc402>:
  409e90:	vxorps xmm0,xmm0,xmm0
  409e94:	vmovups XMMWORD PTR [rcx],xmm0
  409e98:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e9d:	vxorps xmm0,xmm0,xmm0
  409ea1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409ea6:	vmovups xmm0,XMMWORD PTR [rip+0x986a]        # 413718 <__swc_rdata_base_0a4ed24b+0x608>
  409eae:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409eb3:	mov    QWORD PTR [rcx+0x40],0x0
  409ebb:	ret
  409ebc:	add    BYTE PTR [rax],al
	...

0000000000409ec0 <__swc_fn_0a4ed24b_000156_2745c4a5>:
  409ec0:	push   rbx
  409ec1:	sub    rsp,0x70
  409ec5:	mov    rax,QWORD PTR [rcx]
  409ec8:	mov    rbx,QWORD PTR [rcx+0x8]
  409ecc:	vxorps xmm0,xmm0,xmm0
  409ed0:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409ed6:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409edc:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409ee2:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  409ee8:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  409eee:	mov    QWORD PTR [rsp+0x48],rdx
  409ef3:	mov    QWORD PTR [rsp+0x50],r8
  409ef8:	mov    rcx,rax
  409efb:	lea    rdx,[rsp+0x8]
  409f00:	mov    rbx,QWORD PTR [rbx+0x18]
  409f04:	call   rbx
  409f06:	add    rsp,0x70
  409f0a:	pop    rbx
  409f0b:	ret
  409f0c:	add    BYTE PTR [rax],al
	...

0000000000409f10 <__swc_fn_0a4ed24b_000159_d8afac28>:
  409f10:	push   rbx
  409f11:	push   rsi
  409f12:	push   rdi
  409f13:	mov    rbx,r8
  409f16:	mov    rsi,rcx
  409f19:	mov    rdi,rdx
  409f1c:	call   40d400 <__swc_fn_0a4ed24b_000157_232ffa22>
  409f21:	vmovups xmm0,XMMWORD PTR [rbx]
  409f25:	vmovups XMMWORD PTR [rsi],xmm0
  409f29:	mov    QWORD PTR [rsi+0x18],rdi
  409f2d:	pop    rdi
  409f2e:	pop    rsi
  409f2f:	pop    rbx
  409f30:	ret
	...

0000000000409f40 <__swc_fn_0a4ed24b_000162_60216e69>:
  409f40:	push   rbx
  409f41:	push   rsi
  409f42:	push   rdi
  409f43:	push   r12
  409f45:	push   r13
  409f47:	sub    rsp,0x50
  409f4b:	mov    rbx,rcx
  409f4e:	mov    rsi,rdx
  409f51:	vmovups xmm0,XMMWORD PTR [rip+0x98cf]        # 413828 <__swc_rdata_base_0a4ed24b+0x718>
  409f59:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409f5f:	vmovups xmm0,XMMWORD PTR [rip+0x98d1]        # 413838 <__swc_rdata_base_0a4ed24b+0x728>
  409f67:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409f6d:	vxorps xmm0,xmm0,xmm0
  409f71:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409f77:	mov    rcx,rdx
  409f7a:	call   4098d0 <__swc_fn_0a4ed24b_000138_0c00232f>
  409f7f:	mov    rdi,rax
  409f82:	test   rax,rax
  409f85:	jne    409fb6 <__swc_fn_0a4ed24b_000162_60216e69+0x76>
  409f87:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409f8d:	vmovups XMMWORD PTR [rbx],xmm0
  409f91:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409f97:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409f9c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fa2:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fa7:	mov    rax,rbx
  409faa:	add    rsp,0x50
  409fae:	pop    r13
  409fb0:	pop    r12
  409fb2:	pop    rdi
  409fb3:	pop    rsi
  409fb4:	pop    rbx
  409fb5:	ret
  409fb6:	mov    rcx,rdi
  409fb9:	call   411a40 <__swc_fn_0a4ed24b_000161_b5a9d657>
  409fbe:	mov    r11,rax
  409fc1:	test   rax,rax
  409fc4:	je     409fce <__swc_fn_0a4ed24b_000162_60216e69+0x8e>
  409fc6:	mov    al,BYTE PTR [r11+0x24]
  409fca:	test   al,al
  409fcc:	jne    409ffd <__swc_fn_0a4ed24b_000162_60216e69+0xbd>
  409fce:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fd4:	vmovups XMMWORD PTR [rbx],xmm0
  409fd8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fde:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fe3:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fe9:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fee:	mov    rax,rbx
  409ff1:	add    rsp,0x50
  409ff5:	pop    r13
  409ff7:	pop    r12
  409ff9:	pop    rdi
  409ffa:	pop    rsi
  409ffb:	pop    rbx
  409ffc:	ret
  409ffd:	sub    rsi,rdi
  40a000:	mov    eax,0xffffffff
  40a005:	cmp    rsi,rax
  40a008:	jbe    40a039 <__swc_fn_0a4ed24b_000162_60216e69+0xf9>
  40a00a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a010:	vmovups XMMWORD PTR [rbx],xmm0
  40a014:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a01a:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a01f:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a025:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a02a:	mov    rax,rbx
  40a02d:	add    rsp,0x50
  40a031:	pop    r13
  40a033:	pop    r12
  40a035:	pop    rdi
  40a036:	pop    rsi
  40a037:	pop    rbx
  40a038:	ret
  40a039:	mov    rdi,QWORD PTR [r11+0x10]
  40a03d:	mov    eax,DWORD PTR [r11+0x20]
  40a041:	xor    ecx,ecx
  40a043:	test   rax,rax
  40a046:	jbe    40a198 <__swc_fn_0a4ed24b_000162_60216e69+0x258>
  40a04c:	nop    DWORD PTR [rax+0x0]
  40a050:	mov    edx,ecx
  40a052:	imul   r12,rdx,0x14
  40a056:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40a05b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40a060:	mov    r9d,esi
  40a063:	cmp    r9,rdx
  40a066:	jb     40a18b <__swc_fn_0a4ed24b_000162_60216e69+0x24b>
  40a06c:	add    rdx,r8
  40a06f:	mov    r8d,esi
  40a072:	cmp    r8,rdx
  40a075:	jae    40a18b <__swc_fn_0a4ed24b_000162_60216e69+0x24b>
  40a07b:	lea    rsi,[rsp+0x38]
  40a080:	mov    eax,DWORD PTR [rdi+0xc]
  40a083:	mov    DWORD PTR [rsp+0x38],eax
  40a087:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40a08c:	mov    rcx,rdi
  40a08f:	mov    rdx,QWORD PTR [r11+0x18]
  40a093:	mov    r8,rsi
  40a096:	mov    r8d,DWORD PTR [r8]
  40a099:	mov    r9,rax
  40a09c:	lea    r10,[rsp+0x10]
  40a0a1:	call   40d460 <__swc_fn_0a4ed24b_000160_01cbb887>
  40a0a6:	test   al,al
  40a0a8:	jne    40a0db <__swc_fn_0a4ed24b_000162_60216e69+0x19b>
  40a0aa:	vmovups xmm0,XMMWORD PTR [rip+0x97a6]        # 413858 <__swc_rdata_base_0a4ed24b+0x748>
  40a0b2:	vmovups XMMWORD PTR [rbx],xmm0
  40a0b6:	vmovups xmm0,XMMWORD PTR [rip+0x97aa]        # 413868 <__swc_rdata_base_0a4ed24b+0x758>
  40a0be:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a0c3:	vxorps xmm0,xmm0,xmm0
  40a0c7:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a0cc:	mov    rax,rbx
  40a0cf:	add    rsp,0x50
  40a0d3:	pop    r13
  40a0d5:	pop    r12
  40a0d7:	pop    rdi
  40a0d8:	pop    rsi
  40a0d9:	pop    rbx
  40a0da:	ret
  40a0db:	lea    r13,[rsp+0x3c]
  40a0e0:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40a0e5:	mov    DWORD PTR [rsp+0x3c],eax
  40a0e9:	test   eax,eax
  40a0eb:	je     40a13c <__swc_fn_0a4ed24b_000162_60216e69+0x1fc>
  40a0ed:	mov    rcx,rdi
  40a0f0:	mov    rdx,QWORD PTR [r11+0x18]
  40a0f4:	mov    r8d,DWORD PTR [rsi]
  40a0f7:	mov    rax,r13
  40a0fa:	mov    r9d,DWORD PTR [rax]
  40a0fd:	lea    r10,[rsp+0x20]
  40a102:	call   40d460 <__swc_fn_0a4ed24b_000160_01cbb887>
  40a107:	test   al,al
  40a109:	jne    40a13c <__swc_fn_0a4ed24b_000162_60216e69+0x1fc>
  40a10b:	vmovups xmm0,XMMWORD PTR [rip+0x9775]        # 413888 <__swc_rdata_base_0a4ed24b+0x778>
  40a113:	vmovups XMMWORD PTR [rbx],xmm0
  40a117:	vmovups xmm0,XMMWORD PTR [rip+0x9779]        # 413898 <__swc_rdata_base_0a4ed24b+0x788>
  40a11f:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a124:	vxorps xmm0,xmm0,xmm0
  40a128:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a12d:	mov    rax,rbx
  40a130:	add    rsp,0x50
  40a134:	pop    r13
  40a136:	pop    r12
  40a138:	pop    rdi
  40a139:	pop    rsi
  40a13a:	pop    rbx
  40a13b:	ret
  40a13c:	mov    eax,0x1
  40a141:	rex mov BYTE PTR [rsp+0x8],al
  40a146:	cmp    DWORD PTR [r13+0x0],0x0
  40a14b:	je     40a15c <__swc_fn_0a4ed24b_000162_60216e69+0x21c>
  40a14d:	rex mov BYTE PTR [rsp+0x9],0x1
  40a153:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40a158:	mov    DWORD PTR [rsp+0x30],eax
  40a15c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a162:	vmovups XMMWORD PTR [rbx],xmm0
  40a166:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a16c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a171:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a177:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a17c:	mov    rax,rbx
  40a17f:	add    rsp,0x50
  40a183:	pop    r13
  40a185:	pop    r12
  40a187:	pop    rdi
  40a188:	pop    rsi
  40a189:	pop    rbx
  40a18a:	ret
  40a18b:	add    rcx,0x1
  40a18f:	cmp    rcx,rax
  40a192:	jb     40a050 <__swc_fn_0a4ed24b_000162_60216e69+0x110>
  40a198:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a19e:	vmovups XMMWORD PTR [rbx],xmm0
  40a1a2:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a1a8:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a1ad:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a1b3:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a1b8:	mov    rax,rbx
  40a1bb:	add    rsp,0x50
  40a1bf:	pop    r13
  40a1c1:	pop    r12
  40a1c3:	pop    rdi
  40a1c4:	pop    rsi
  40a1c5:	pop    rbx
  40a1c6:	ret
	...

000000000040a1d0 <__swc_fn_0a4ed24b_000165_cf398896>:
  40a1d0:	sub    rsp,0x48
  40a1d4:	call   4095a0 <__swc_fn_0a4ed24b_000123_9d2cbd72>
  40a1d9:	cmp    rax,0xffffffffffffffff
  40a1dd:	je     40a1e4 <__swc_fn_0a4ed24b_000165_cf398896+0x14>
  40a1df:	add    rsp,0x48
  40a1e3:	ret
  40a1e4:	lea    rcx,[rip+0x96dd]        # 4138c8 <__swc_rdata_base_0a4ed24b+0x7b8>
  40a1eb:	vmovups xmm0,XMMWORD PTR [rip+0x96e5]        # 4138d8 <__swc_rdata_base_0a4ed24b+0x7c8>
  40a1f3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a1f9:	vmovups xmm0,XMMWORD PTR [rip+0x96e7]        # 4138e8 <__swc_rdata_base_0a4ed24b+0x7d8>
  40a201:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a207:	vmovups xmm0,XMMWORD PTR [rip+0x96e9]        # 4138f8 <__swc_rdata_base_0a4ed24b+0x7e8>
  40a20f:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a215:	lea    rdx,[rsp+0x8]
  40a21a:	mov    QWORD PTR [rsp+0x38],rax
  40a21f:	call   40c620 <__swc_fn_0a4ed24b_000103_67100064>
  40a224:	mov    rax,QWORD PTR [rsp+0x38]
  40a229:	jmp    40a1df <__swc_fn_0a4ed24b_000165_cf398896+0xf>
  40a22b:	add    BYTE PTR [rax],al
  40a22d:	add    BYTE PTR [rax],al
	...

000000000040a230 <__swc_fn_0a4ed24b_000168_92b7d63c>:
  40a230:	push   rbx
  40a231:	push   rsi
  40a232:	sub    rsp,0x28
  40a236:	mov    rbx,rcx
  40a239:	mov    DWORD PTR [rsp+0x8],0xbf0
  40a241:	mov    ecx,0xbf0
  40a246:	call   40c210 <__swc_fn_0a4ed24b_000079_34776ded>
  40a24b:	mov    rsi,rax
  40a24e:	test   rax,rax
  40a251:	jne    40a25c <__swc_fn_0a4ed24b_000168_92b7d63c+0x2c>
  40a253:	xor    eax,eax
  40a255:	add    rsp,0x28
  40a259:	pop    rsi
  40a25a:	pop    rbx
  40a25b:	ret
  40a25c:	vxorps xmm0,xmm0,xmm0
  40a260:	xor    eax,eax
  40a262:	cs nop WORD PTR [rax+rax*1+0x0]
  40a26c:	nop    DWORD PTR [rax+0x0]
  40a270:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40a275:	add    rax,0x10
  40a279:	cmp    rax,0xbf0
  40a280:	jne    40a270 <__swc_fn_0a4ed24b_000168_92b7d63c+0x40>
  40a282:	lea    rax,[rbx+0x1]
  40a286:	mov    QWORD PTR [rsi+0x9c0],rax
  40a28d:	mov    rcx,rbx
  40a290:	mov    rdx,rsi
  40a293:	call   40d7c0 <__swc_fn_0a4ed24b_000166_f6173642>
  40a298:	test   al,al
  40a29a:	jne    40a2ad <__swc_fn_0a4ed24b_000168_92b7d63c+0x7d>
  40a29c:	mov    rcx,rsi
  40a29f:	call   40ee90 <__swc_fn_0a4ed24b_000080_c1514492>
  40a2a4:	xor    eax,eax
  40a2a6:	add    rsp,0x28
  40a2aa:	pop    rsi
  40a2ab:	pop    rbx
  40a2ac:	ret
  40a2ad:	lea    rcx,[rsp+0x18]
  40a2b2:	call   40f410 <__swc_fn_0a4ed24b_000092_8252f8c0>
  40a2b7:	mov    rax,rsi
  40a2ba:	add    rsp,0x28
  40a2be:	pop    rsi
  40a2bf:	pop    rbx
  40a2c0:	ret
	...

000000000040a2d0 <__swc_fn_0a4ed24b_000171_c0e8acb1>:
  40a2d0:	xor    eax,eax
  40a2d2:	mov    edx,0x1
  40a2d7:	lock cmpxchg QWORD PTR [rcx],rdx
  40a2dc:	test   rax,rax
  40a2df:	jne    40a2e2 <__swc_fn_0a4ed24b_000171_c0e8acb1+0x12>
  40a2e1:	ret
  40a2e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2ec:	nop    DWORD PTR [rax+0x0]
  40a2f0:	mov    rax,QWORD PTR [rcx]
  40a2f3:	test   rax,rax
  40a2f6:	je     40a2d0 <__swc_fn_0a4ed24b_000171_c0e8acb1>
  40a2f8:	jmp    40a2f0 <__swc_fn_0a4ed24b_000171_c0e8acb1+0x20>
  40a2fa:	add    BYTE PTR [rax],al
  40a2fc:	add    BYTE PTR [rax],al
	...

000000000040a300 <__swc_fn_0a4ed24b_000174_176517f9>:
  40a300:	push   rsi
  40a301:	push   rdi
  40a302:	sub    rsp,0x38
  40a306:	mov    rsi,rcx
  40a309:	call   40d7d0 <__swc_fn_0a4ed24b_000169_4579a84c>
  40a30e:	mov    rdi,rax
  40a311:	call   40cf40 <__swc_fn_0a4ed24b_000130_c1196dfb>
  40a316:	mov    r8,rax
  40a319:	mov    rcx,rdi
  40a31c:	call   40a2d0 <__swc_fn_0a4ed24b_000171_c0e8acb1>
  40a321:	mov    rax,QWORD PTR [rdi+0x8]
  40a325:	test   rax,rax
  40a328:	je     40a365 <__swc_fn_0a4ed24b_000174_176517f9+0x65>
  40a32a:	nop    WORD PTR [rax+rax*1+0x0]
  40a330:	cmp    rax,rsi
  40a333:	je     40a365 <__swc_fn_0a4ed24b_000174_176517f9+0x65>
  40a335:	mov    r9,QWORD PTR [rax]
  40a338:	cmp    QWORD PTR [rax+0x20],r8
  40a33c:	jne    40a35d <__swc_fn_0a4ed24b_000174_176517f9+0x5d>
  40a33e:	mov    rcx,rdi
  40a341:	mov    rdx,rax
  40a344:	mov    QWORD PTR [rsp+0x28],r8
  40a349:	mov    QWORD PTR [rsp+0x30],r9
  40a34e:	call   411e60 <__swc_fn_0a4ed24b_000173_f69b1f05>
  40a353:	mov    r8,QWORD PTR [rsp+0x28]
  40a358:	mov    r9,QWORD PTR [rsp+0x30]
  40a35d:	mov    rax,r9
  40a360:	test   r9,r9
  40a363:	jne    40a330 <__swc_fn_0a4ed24b_000174_176517f9+0x30>
  40a365:	xor    eax,eax
  40a367:	mov    QWORD PTR [rdi],rax
  40a36a:	add    rsp,0x38
  40a36e:	pop    rdi
  40a36f:	pop    rsi
  40a370:	ret
	...

000000000040a380 <__swc_fn_0a4ed24b_000177_3634f827>:
  40a380:	sub    rsp,0x168
  40a387:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40a390:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40a399:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40a3a2:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40a3ab:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40a3b4:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40a3bd:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40a3c6:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40a3cf:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40a3d8:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40a3e1:	vmovups xmm6,xmm5
  40a3e5:	vmovups xmm7,xmm0
  40a3e9:	vmovups xmm8,xmm1
  40a3ed:	vmovups xmm9,xmm2
  40a3f1:	vmovups xmm10,xmm3
  40a3f5:	vmovups xmm11,xmm4
  40a3f9:	vmovsd xmm0,QWORD PTR [rip+0x966f]        # 413a70 <__swc_rdata_base_0a4ed24b+0x960>
  40a401:	vmovsd QWORD PTR [rsp],xmm0
  40a406:	vmovups xmm0,xmm7
  40a40a:	call   411ee0 <__swc_fn_0a4ed24b_000176_0d61c738>
  40a40f:	mov    eax,DWORD PTR [rip+0x17bfb]        # 422010 <__swc_data_base_0a4ed24b+0x10>
  40a415:	test   eax,eax
  40a417:	jge    40a44e <__swc_fn_0a4ed24b_000177_3634f827+0xce>
  40a419:	vmovsd xmm0,QWORD PTR [rip+0x9658]        # 413a79 <__swc_rdata_base_0a4ed24b+0x969>
  40a421:	vmovsd QWORD PTR [rip+0x1c98f],xmm0        # 426db8 <__swc_bss_base_0a4ed24b+0x2d78>
  40a429:	vmovsd xmm0,QWORD PTR [rip+0x9651]        # 413a82 <__swc_rdata_base_0a4ed24b+0x972>
  40a431:	vmovsd QWORD PTR [rip+0x1c987],xmm0        # 426dc0 <__swc_bss_base_0a4ed24b+0x2d80>
  40a439:	vmovsd xmm0,QWORD PTR [rip+0x964a]        # 413a8b <__swc_rdata_base_0a4ed24b+0x97b>
  40a441:	vmovsd QWORD PTR [rip+0x1c97f],xmm0        # 426dc8 <__swc_bss_base_0a4ed24b+0x2d88>
  40a449:	jmp    40a640 <__swc_fn_0a4ed24b_000177_3634f827+0x2c0>
  40a44e:	vmovsd xmm0,QWORD PTR [rip+0x1c95a]        # 426db0 <__swc_bss_base_0a4ed24b+0x2d70>
  40a456:	movsxd rdx,eax
  40a459:	vfmadd231sd xmm7,xmm10,xmm0
  40a45e:	vfmadd231sd xmm8,xmm11,xmm0
  40a463:	vfmadd231sd xmm9,xmm6,xmm0
  40a468:	vmovsd QWORD PTR [rsp+0xb8],xmm9
  40a471:	vmovsd xmm12,QWORD PTR [rip+0x94b3]        # 41392c <__swc_rdata_base_0a4ed24b+0x81c>
  40a479:	lea    rax,[rip+0x94f0]        # 413970 <__swc_rdata_base_0a4ed24b+0x860>
  40a480:	vdivsd xmm0,xmm12,QWORD PTR [rax+rdx*8]
  40a485:	lea    rax,[rip+0x9504]        # 413990 <__swc_rdata_base_0a4ed24b+0x880>
  40a48c:	vsubsd xmm1,xmm7,QWORD PTR [rax+rdx*8]
  40a491:	vmulsd xmm13,xmm1,xmm0
  40a495:	lea    rax,[rip+0x9514]        # 4139b0 <__swc_rdata_base_0a4ed24b+0x8a0>
  40a49c:	vsubsd xmm1,xmm8,QWORD PTR [rax+rdx*8]
  40a4a1:	vmulsd xmm14,xmm1,xmm0
  40a4a5:	lea    rax,[rip+0x9524]        # 4139d0 <__swc_rdata_base_0a4ed24b+0x8c0>
  40a4ac:	vsubsd xmm1,xmm9,QWORD PTR [rax+rdx*8]
  40a4b1:	vmulsd xmm15,xmm1,xmm0
  40a4b5:	vmovsd xmm0,QWORD PTR [rip+0x95d7]        # 413a94 <__swc_rdata_base_0a4ed24b+0x984>
  40a4bd:	vsubsd xmm3,xmm0,xmm7
  40a4c1:	vsubsd xmm4,xmm0,xmm8
  40a4c6:	vmovsd xmm0,QWORD PTR [rip+0x95cf]        # 413a9d <__swc_rdata_base_0a4ed24b+0x98d>
  40a4ce:	vsubsd xmm5,xmm0,xmm9
  40a4d3:	vmulsd xmm0,xmm3,xmm3
  40a4d7:	vfmadd231sd xmm0,xmm4,xmm4
  40a4dc:	vfmadd231sd xmm0,xmm5,xmm5
  40a4e1:	vsqrtsd xmm0,xmm0,xmm0
  40a4e5:	vdivsd xmm0,xmm12,xmm0
  40a4e9:	vmulsd xmm3,xmm3,xmm0
  40a4ed:	vmulsd xmm4,xmm4,xmm0
  40a4f1:	vmulsd xmm5,xmm5,xmm0
  40a4f5:	vmulsd xmm0,xmm13,xmm3
  40a4f9:	vfmadd231sd xmm0,xmm14,xmm4
  40a4fe:	vmulsd xmm1,xmm15,xmm5
  40a502:	vaddsd xmm2,xmm0,xmm1
  40a506:	vxorpd xmm0,xmm0,xmm0
  40a50a:	vcomisd xmm0,xmm2
  40a50e:	jbe    40a517 <__swc_fn_0a4ed24b_000177_3634f827+0x197>
  40a510:	vxorpd xmm12,xmm12,xmm12
  40a515:	jmp    40a553 <__swc_fn_0a4ed24b_000177_3634f827+0x1d3>
  40a517:	vmovsd xmm0,QWORD PTR [rip+0x9587]        # 413aa6 <__swc_rdata_base_0a4ed24b+0x996>
  40a51f:	vmovsd QWORD PTR [rsp],xmm0
  40a524:	vmovups xmm0,xmm7
  40a528:	vmovups xmm1,xmm8
  40a52d:	vmovsd QWORD PTR [rsp+0xc0],xmm2
  40a536:	vmovups xmm12,xmm2
  40a53a:	vmovups xmm2,xmm9
  40a53f:	call   411ee0 <__swc_fn_0a4ed24b_000176_0d61c738>
  40a544:	mov    eax,DWORD PTR [rip+0x17ac6]        # 422010 <__swc_data_base_0a4ed24b+0x10>
  40a54a:	test   eax,eax
  40a54c:	jl     40a553 <__swc_fn_0a4ed24b_000177_3634f827+0x1d3>
  40a54e:	vxorpd xmm12,xmm12,xmm12
  40a553:	vmulsd xmm0,xmm12,QWORD PTR [rip+0x9554]        # 413aaf <__swc_rdata_base_0a4ed24b+0x99f>
  40a55b:	vaddsd xmm0,xmm0,QWORD PTR [rip+0x9528]        # 413a8b <__swc_rdata_base_0a4ed24b+0x97b>
  40a563:	lea    rax,[rip+0x9486]        # 4139f0 <__swc_rdata_base_0a4ed24b+0x8e0>
  40a56a:	vmulsd xmm9,xmm0,QWORD PTR [rax+rdx*8]
  40a56f:	lea    rax,[rip+0x949a]        # 413a10 <__swc_rdata_base_0a4ed24b+0x900>
  40a576:	vmulsd xmm12,xmm0,QWORD PTR [rax+rdx*8]
  40a57b:	lea    rax,[rip+0x94ae]        # 413a30 <__swc_rdata_base_0a4ed24b+0x920>
  40a582:	vmulsd xmm5,xmm0,QWORD PTR [rax+rdx*8]
  40a587:	lea    rax,[rip+0x94c2]        # 413a50 <__swc_rdata_base_0a4ed24b+0x940>
  40a58e:	vmovq  xmm4,QWORD PTR [rax+rdx*8]
  40a593:	cmp    ecx,0x2
  40a596:	jl     40a5a1 <__swc_fn_0a4ed24b_000177_3634f827+0x221>
  40a598:	vmovups xmm8,xmm5
  40a59c:	jmp    40a628 <__swc_fn_0a4ed24b_000177_3634f827+0x2a8>
  40a5a1:	vmulsd xmm0,xmm10,xmm13
  40a5a6:	vfmadd231sd xmm0,xmm11,xmm14
  40a5ab:	vfmadd231sd xmm0,xmm6,xmm15
  40a5b0:	vaddsd xmm0,xmm0,xmm0
  40a5b4:	vmulsd xmm1,xmm0,xmm13
  40a5b9:	vsubsd xmm3,xmm10,xmm1
  40a5bd:	vmulsd xmm1,xmm0,xmm14
  40a5c2:	vsubsd xmm10,xmm11,xmm1
  40a5c6:	vfnmadd231sd xmm6,xmm0,xmm15
  40a5cb:	vmovups xmm0,xmm7
  40a5cf:	vmovups xmm1,xmm8
  40a5d4:	vmovsd xmm2,QWORD PTR [rsp+0xb8]
  40a5dd:	vmovups xmm7,xmm4
  40a5e1:	vmovups xmm4,xmm10
  40a5e6:	vmovups xmm8,xmm5
  40a5ea:	vmovups xmm5,xmm6
  40a5ee:	inc    ecx
  40a5f0:	call   40a380 <__swc_fn_0a4ed24b_000177_3634f827>
  40a5f5:	vmovsd xmm0,QWORD PTR [rip+0x932f]        # 41392c <__swc_rdata_base_0a4ed24b+0x81c>
  40a5fd:	vsubsd xmm0,xmm0,xmm7
  40a601:	vmulsd xmm2,xmm7,QWORD PTR [rip+0x1c7af]        # 426db8 <__swc_bss_base_0a4ed24b+0x2d78>
  40a609:	vfmadd213sd xmm9,xmm0,xmm2
  40a60e:	vmulsd xmm2,xmm7,QWORD PTR [rip+0x1c7aa]        # 426dc0 <__swc_bss_base_0a4ed24b+0x2d80>
  40a616:	vfmadd213sd xmm12,xmm0,xmm2
  40a61b:	vmulsd xmm1,xmm7,QWORD PTR [rip+0x1c7a5]        # 426dc8 <__swc_bss_base_0a4ed24b+0x2d88>
  40a623:	vfmadd213sd xmm8,xmm0,xmm1
  40a628:	vmovsd QWORD PTR [rip+0x1c788],xmm9        # 426db8 <__swc_bss_base_0a4ed24b+0x2d78>
  40a630:	vmovsd QWORD PTR [rip+0x1c788],xmm12        # 426dc0 <__swc_bss_base_0a4ed24b+0x2d80>
  40a638:	vmovsd QWORD PTR [rip+0x1c788],xmm8        # 426dc8 <__swc_bss_base_0a4ed24b+0x2d88>
  40a640:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40a649:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40a652:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40a65b:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40a664:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  40a66d:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40a676:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  40a67f:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40a688:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  40a691:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  40a69a:	add    rsp,0x168
  40a6a1:	ret
	...

000000000040a6c0 <__swc_fn_0a4ed24b_000001_46f18a51>:
  40a6c0:	vxorps xmm0,xmm0,xmm0
  40a6c4:	xor    eax,eax
  40a6c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a6d0:	cs nop WORD PTR [rax+rax*1+0x0]
  40a6da:	nop    WORD PTR [rax+rax*1+0x0]
  40a6e0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a6e5:	add    rax,0x10
  40a6e9:	cmp    rax,0x2080
  40a6f0:	jne    40a6e0 <__swc_fn_0a4ed24b_000001_46f18a51+0x20>
  40a6f2:	ret
	...

000000000040a700 <__swc_fn_0a4ed24b_000004_1acc36a6>:
  40a700:	push   rsi
  40a701:	push   rdi
  40a702:	push   r12
  40a704:	push   r13
  40a706:	push   r14
  40a708:	mov    rsi,rcx
  40a70b:	mov    edi,r10d
  40a70e:	mov    r12,rcx
  40a711:	mov    r13,r9
  40a714:	mov    ecx,DWORD PTR [rdx+0x28]
  40a717:	shlx   r14d,r8d,ecx
  40a71c:	mov    rcx,rdx
  40a71f:	mov    edx,r8d
  40a722:	call   40dd60 <__swc_fn_0a4ed24b_000011_6493fbbc>
  40a727:	mov    rcx,rax
  40a72a:	mov    eax,DWORD PTR [r12+0x3c]
  40a72f:	xor    edx,edx
  40a731:	div    rdi
  40a734:	vxorps xmm0,xmm0,xmm0
  40a738:	vmovdqu XMMWORD PTR [rsi],xmm0
  40a73c:	mov    QWORD PTR [r12+0x60],0x0
  40a745:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40a74a:	mov    QWORD PTR [r12+0x10],rcx
  40a74f:	imul   rax,rdi
  40a753:	lea    rdx,[rcx+rax*1]
  40a757:	mov    QWORD PTR [r12+0x18],rdx
  40a75c:	mov    QWORD PTR [r12+0x20],rcx
  40a761:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40a766:	mov    DWORD PTR [r12+0x28],0x0
  40a76f:	mov    DWORD PTR [r12+0x68],0x0
  40a778:	mov    BYTE PTR [r12+0x39],r13b
  40a77d:	mov    BYTE PTR [r12+0x3a],r14b
  40a782:	mov    BYTE PTR [r12+0x3b],0x1
  40a788:	mov    DWORD PTR [r12+0x6c],0x0
  40a791:	mov    rcx,r12
  40a794:	mov    edx,edi
  40a796:	call   40dcc0 <__swc_fn_0a4ed24b_000005_b2240b56>
  40a79b:	pop    r14
  40a79d:	pop    r13
  40a79f:	pop    r12
  40a7a1:	pop    rdi
  40a7a2:	pop    rsi
  40a7a3:	ret
	...

000000000040a7b0 <__swc_fn_0a4ed24b_000007_614a4804>:
  40a7b0:	mov    r8d,0x1
  40a7b6:	xor    eax,eax
  40a7b8:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40a7be:	test   eax,eax
  40a7c0:	jne    40a7b0 <__swc_fn_0a4ed24b_000007_614a4804>
  40a7c2:	ret
	...

000000000040a7d0 <__swc_fn_0a4ed24b_000010_395bb04b>:
  40a7d0:	lea    r8,[rcx+0x60]
  40a7d4:	mov    rax,QWORD PTR [r8]
  40a7d7:	mov    r9,rax
  40a7da:	nop    WORD PTR [rax+rax*1+0x0]
  40a7e0:	mov    QWORD PTR [rdx],r9
  40a7e3:	mov    rax,r9
  40a7e6:	lock cmpxchg QWORD PTR [r8],rdx
  40a7eb:	cmp    rax,r9
  40a7ee:	jne    40a857 <__swc_fn_0a4ed24b_000010_395bb04b+0x87>
  40a7f0:	mov    eax,DWORD PTR [rcx+0x6c]
  40a7f3:	test   eax,eax
  40a7f5:	je     40a856 <__swc_fn_0a4ed24b_000010_395bb04b+0x86>
  40a7f7:	lea    rdx,[rcx+0x70]
  40a7fb:	mov    r9d,0x1
  40a801:	xor    eax,eax
  40a803:	lock cmpxchg DWORD PTR [rdx],r9d
  40a808:	test   eax,eax
  40a80a:	jne    40a856 <__swc_fn_0a4ed24b_000010_395bb04b+0x86>
  40a80c:	mov    rax,rcx
  40a80f:	and    rax,0xffffffffffc00000
  40a816:	mov    rax,QWORD PTR [rax+0x8]
  40a81a:	test   rax,rax
  40a81d:	jne    40a825 <__swc_fn_0a4ed24b_000010_395bb04b+0x55>
  40a81f:	xor    eax,eax
  40a821:	xchg   DWORD PTR [rdx],eax
  40a823:	jmp    40a856 <__swc_fn_0a4ed24b_000010_395bb04b+0x86>
  40a825:	lea    rdx,[rax+0x2a80]
  40a82c:	mov    rax,QWORD PTR [rdx]
  40a82f:	mov    r8,rax
  40a832:	cs nop WORD PTR [rax+rax*1+0x0]
  40a83c:	nop    DWORD PTR [rax+0x0]
  40a840:	mov    QWORD PTR [rcx+0x78],r8
  40a844:	mov    rax,r8
  40a847:	lock cmpxchg QWORD PTR [rdx],rcx
  40a84c:	cmp    rax,r8
  40a84f:	je     40a856 <__swc_fn_0a4ed24b_000010_395bb04b+0x86>
  40a851:	mov    r8,rax
  40a854:	jmp    40a840 <__swc_fn_0a4ed24b_000010_395bb04b+0x70>
  40a856:	ret
  40a857:	mov    r9,rax
  40a85a:	jmp    40a7e0 <__swc_fn_0a4ed24b_000010_395bb04b+0x10>
	...

000000000040a860 <__swc_fn_0a4ed24b_000013_9ba72deb>:
  40a860:	push   rsi
  40a861:	push   rdi
  40a862:	push   r12
  40a864:	push   r13
  40a866:	push   r14
  40a868:	push   r15
  40a86a:	push   rbx
  40a86b:	sub    rsp,0x30
  40a86f:	mov    QWORD PTR [rsp+0x18],r8
  40a874:	mov    rsi,rcx
  40a877:	mov    rdi,rdx
  40a87a:	mov    rdx,QWORD PTR [rsi+0x40]
  40a87e:	xchg   ax,ax
  40a880:	mov    rax,rdx
  40a883:	not    rax
  40a886:	and    rax,QWORD PTR [rsi+0x20]
  40a88a:	test   rax,rax
  40a88d:	jne    40a8a1 <__swc_fn_0a4ed24b_000013_9ba72deb+0x41>
  40a88f:	xor    eax,eax
  40a891:	add    rsp,0x30
  40a895:	pop    rbx
  40a896:	pop    r15
  40a898:	pop    r14
  40a89a:	pop    r13
  40a89c:	pop    r12
  40a89e:	pop    rdi
  40a89f:	pop    rsi
  40a8a0:	ret
  40a8a1:	xor    ecx,ecx
  40a8a3:	tzcnt  rcx,rax
  40a8a8:	lea    r12,[rsp+0x8]
  40a8ad:	mov    DWORD PTR [rsp+0x8],ecx
  40a8b1:	mov    r13d,0x1
  40a8b7:	shl    r13,cl
  40a8ba:	mov    rcx,rdx
  40a8bd:	or     rcx,r13
  40a8c0:	mov    rax,rdx
  40a8c3:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40a8c9:	cmp    rax,rdx
  40a8cc:	je     40a8d3 <__swc_fn_0a4ed24b_000013_9ba72deb+0x73>
  40a8ce:	mov    rdx,rax
  40a8d1:	jmp    40a880 <__swc_fn_0a4ed24b_000013_9ba72deb+0x20>
  40a8d3:	mov    eax,DWORD PTR [r12]
  40a8d7:	shl    rax,0x4
  40a8db:	lea    r14,[rsi+rax*8+0x80]
  40a8e3:	mov    rcx,rsi
  40a8e6:	mov    rax,r12
  40a8e9:	mov    edx,DWORD PTR [rax]
  40a8eb:	call   40dd60 <__swc_fn_0a4ed24b_000011_6493fbbc>
  40a8f0:	mov    r15,rax
  40a8f3:	mov    rcx,rsi
  40a8f6:	mov    rdx,r13
  40a8f9:	call   40dec0 <__swc_fn_0a4ed24b_000017_4df2d1a0>
  40a8fe:	test   al,al
  40a900:	je     40a938 <__swc_fn_0a4ed24b_000013_9ba72deb+0xd8>
  40a902:	mov    ecx,DWORD PTR [r14+0x3c]
  40a906:	lea    rdx,[rip+0x1974b]        # 424058 <__swc_bss_base_0a4ed24b+0x18>
  40a90d:	mov    r8,QWORD PTR [rip+0x19744]        # 424058 <__swc_bss_base_0a4ed24b+0x18>
  40a914:	cs nop WORD PTR [rax+rax*1+0x0]
  40a91e:	xchg   ax,ax
  40a920:	mov    r9,r8
  40a923:	sub    r9,rcx
  40a926:	mov    rax,r8
  40a929:	lock cmpxchg QWORD PTR [rdx],r9
  40a92e:	cmp    rax,r8
  40a931:	je     40a999 <__swc_fn_0a4ed24b_000013_9ba72deb+0x139>
  40a933:	mov    r8,rax
  40a936:	jmp    40a920 <__swc_fn_0a4ed24b_000013_9ba72deb+0xc0>
  40a938:	mov    rcx,rsi
  40a93b:	mov    rax,r12
  40a93e:	mov    edx,DWORD PTR [rax]
  40a940:	call   407450 <__swc_fn_0a4ed24b_000012_c7df5d22>
  40a945:	mov    rcx,r15
  40a948:	and    rcx,0xffffffffffff0000
  40a94f:	lea    rcx,[rcx+0x10000]
  40a956:	mov    rbx,rax
  40a959:	cmp    rax,rcx
  40a95c:	cmova  rbx,rcx
  40a960:	mov    rax,rbx
  40a963:	sub    rax,r15
  40a966:	mov    rcx,r15
  40a969:	mov    rdx,rax
  40a96c:	call   4072a0 <__swc_fn_0a4ed24b_000003_7ab4792e>
  40a971:	test   al,al
  40a973:	jne    40a992 <__swc_fn_0a4ed24b_000013_9ba72deb+0x132>
  40a975:	mov    rcx,rsi
  40a978:	mov    rdx,r13
  40a97b:	call   407600 <__swc_fn_0a4ed24b_000018_7d1e8a10>
  40a980:	xor    eax,eax
  40a982:	add    rsp,0x30
  40a986:	pop    rbx
  40a987:	pop    r15
  40a989:	pop    r14
  40a98b:	pop    r13
  40a98d:	pop    r12
  40a98f:	pop    rdi
  40a990:	pop    rsi
  40a991:	ret
  40a992:	sub    rbx,r15
  40a995:	mov    DWORD PTR [r14+0x3c],ebx
  40a999:	mov    rcx,r14
  40a99c:	mov    rdx,rsi
  40a99f:	mov    r8d,DWORD PTR [r12]
  40a9a3:	mov    r9d,edi
  40a9a6:	mov    rbx,QWORD PTR [rsp+0x18]
  40a9ab:	mov    r10d,ebx
  40a9ae:	call   40a700 <__swc_fn_0a4ed24b_000004_1acc36a6>
  40a9b3:	mov    rax,r14
  40a9b6:	add    rsp,0x30
  40a9ba:	pop    rbx
  40a9bb:	pop    r15
  40a9bd:	pop    r14
  40a9bf:	pop    r13
  40a9c1:	pop    r12
  40a9c3:	pop    rdi
  40a9c4:	pop    rsi
  40a9c5:	ret
	...

000000000040a9d0 <__swc_fn_0a4ed24b_000016_4b207b58>:
  40a9d0:	mov    r8,QWORD PTR [rcx+0x48]
  40a9d4:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9de:	xchg   ax,ax
  40a9e0:	mov    r9,r8
  40a9e3:	or     r9,rdx
  40a9e6:	mov    rax,r8
  40a9e9:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40a9ef:	cmp    rax,r8
  40a9f2:	jne    40a9f5 <__swc_fn_0a4ed24b_000016_4b207b58+0x25>
  40a9f4:	ret
  40a9f5:	mov    r8,rax
  40a9f8:	jmp    40a9e0 <__swc_fn_0a4ed24b_000016_4b207b58+0x10>
  40a9fa:	add    BYTE PTR [rax],al
  40a9fc:	add    BYTE PTR [rax],al
	...

000000000040aa00 <__swc_fn_0a4ed24b_000019_2cc1532c>:
  40aa00:	push   rsi
  40aa01:	push   rdi
  40aa02:	push   r12
  40aa04:	mov    rsi,rcx
  40aa07:	xor    edi,edi
  40aa09:	lea    r12,[rip+0x19658]        # 424068 <__swc_bss_base_0a4ed24b+0x28>
  40aa10:	mov    eax,DWORD PTR [r12]
  40aa14:	xor    ecx,ecx
  40aa16:	test   rax,rax
  40aa19:	jbe    40aa54 <__swc_fn_0a4ed24b_000019_2cc1532c+0x54>
  40aa1b:	nop    DWORD PTR [rax+rax*1+0x0]
  40aa20:	lea    rdx,[rip+0x19649]        # 424070 <__swc_bss_base_0a4ed24b+0x30>
  40aa27:	mov    r8d,ecx
  40aa2a:	lea    r8,[r8+r8*2]
  40aa2e:	lea    r8,[rdx+r8*8]
  40aa32:	mov    rdx,QWORD PTR [r8+0x10]
  40aa36:	add    rdx,0x400000
  40aa3d:	cmp    rdx,0x40000000
  40aa44:	ja     40aa4b <__swc_fn_0a4ed24b_000019_2cc1532c+0x4b>
  40aa46:	mov    rdi,r8
  40aa49:	jmp    40aa54 <__swc_fn_0a4ed24b_000019_2cc1532c+0x54>
  40aa4b:	add    rcx,0x1
  40aa4f:	cmp    rcx,rax
  40aa52:	jb     40aa20 <__swc_fn_0a4ed24b_000019_2cc1532c+0x20>
  40aa54:	test   rdi,rdi
  40aa57:	jne    40aae3 <__swc_fn_0a4ed24b_000019_2cc1532c+0xe3>
  40aa5d:	cmp    DWORD PTR [r12],0x10
  40aa62:	jae    40aacb <__swc_fn_0a4ed24b_000019_2cc1532c+0xcb>
  40aa64:	mov    ecx,0x40400000
  40aa69:	call   40dc80 <__swc_fn_0a4ed24b_000002_884bb5c0>
  40aa6e:	test   rax,rax
  40aa71:	je     40aacb <__swc_fn_0a4ed24b_000019_2cc1532c+0xcb>
  40aa73:	lea    rcx,[rip+0x195f6]        # 424070 <__swc_bss_base_0a4ed24b+0x30>
  40aa7a:	mov    edx,DWORD PTR [r12]
  40aa7e:	lea    rdx,[rdx+rdx*2]
  40aa82:	lea    rdx,[rcx+rdx*8]
  40aa86:	mov    QWORD PTR [rdx],rax
  40aa89:	lea    rax,[rax+0x3fffff]
  40aa90:	and    rax,0xffffffffffc00000
  40aa97:	mov    QWORD PTR [rdx+0x8],rax
  40aa9b:	mov    QWORD PTR [rdx+0x10],0x0
  40aaa3:	mov    edx,DWORD PTR [rip+0x195bf]        # 424068 <__swc_bss_base_0a4ed24b+0x28>
  40aaa9:	nop    DWORD PTR [rax+0x0]
  40aab0:	lea    r9d,[rdx+0x1]
  40aab4:	mov    rax,rdx
  40aab7:	lock cmpxchg DWORD PTR [r12],r9d
  40aabd:	mov    r8d,eax
  40aac0:	cmp    eax,edx
  40aac2:	je     40aad2 <__swc_fn_0a4ed24b_000019_2cc1532c+0xd2>
  40aac4:	mov    rdx,r8
  40aac7:	jmp    40aab0 <__swc_fn_0a4ed24b_000019_2cc1532c+0xb0>
  40aac9:	jmp    40aad2 <__swc_fn_0a4ed24b_000019_2cc1532c+0xd2>
  40aacb:	xor    eax,eax
  40aacd:	pop    r12
  40aacf:	pop    rdi
  40aad0:	pop    rsi
  40aad1:	ret
  40aad2:	mov    eax,DWORD PTR [rip+0x19590]        # 424068 <__swc_bss_base_0a4ed24b+0x28>
  40aad8:	sub    eax,0x1
  40aadb:	lea    rdi,[rax+rax*2]
  40aadf:	lea    rdi,[rcx+rdi*8]
  40aae3:	mov    r12,QWORD PTR [rdi+0x8]
  40aae7:	add    r12,QWORD PTR [rdi+0x10]
  40aaeb:	mov    rcx,r12
  40aaee:	mov    edx,0x3000
  40aaf3:	call   4072a0 <__swc_fn_0a4ed24b_000003_7ab4792e>
  40aaf8:	test   al,al
  40aafa:	jne    40ab03 <__swc_fn_0a4ed24b_000019_2cc1532c+0x103>
  40aafc:	xor    eax,eax
  40aafe:	pop    r12
  40ab00:	pop    rdi
  40ab01:	pop    rsi
  40ab02:	ret
  40ab03:	vxorps xmm0,xmm0,xmm0
  40ab07:	xor    eax,eax
  40ab09:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab13:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab1d:	nop    DWORD PTR [rax]
  40ab20:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40ab26:	add    rax,0x10
  40ab2a:	cmp    rax,0x3000
  40ab31:	jne    40ab20 <__swc_fn_0a4ed24b_000019_2cc1532c+0x120>
  40ab33:	mov    DWORD PTR [r12+0x28],esi
  40ab38:	mov    eax,0x40
  40ab3d:	mov    ecx,esi
  40ab3f:	shr    eax,cl
  40ab41:	mov    DWORD PTR [r12+0x2c],eax
  40ab46:	cmp    DWORD PTR [r12+0x2c],0x40
  40ab4c:	jb     40ab57 <__swc_fn_0a4ed24b_000019_2cc1532c+0x157>
  40ab4e:	mov    rax,0xffffffffffffffff
  40ab55:	jmp    40ab67 <__swc_fn_0a4ed24b_000019_2cc1532c+0x167>
  40ab57:	mov    eax,0x1
  40ab5c:	mov    ecx,DWORD PTR [r12+0x2c]
  40ab61:	shl    rax,cl
  40ab64:	dec    rax
  40ab67:	mov    QWORD PTR [r12+0x20],rax
  40ab6c:	mov    DWORD PTR [r12],0x4e540001
  40ab74:	mov    DWORD PTR [r12+0x4],0x53474d45
  40ab7d:	add    QWORD PTR [rdi+0x10],0x400000
  40ab85:	mov    rax,r12
  40ab88:	pop    r12
  40ab8a:	pop    rdi
  40ab8b:	pop    rsi
  40ab8c:	ret
  40ab8d:	add    BYTE PTR [rax],al
	...

000000000040ab90 <__swc_fn_0a4ed24b_000022_3a2e2048>:
  40ab90:	mov    eax,0x1
  40ab95:	mov    edx,DWORD PTR [rip+0x194cd]        # 424068 <__swc_bss_base_0a4ed24b+0x28>
  40ab9b:	cmp    eax,edx
  40ab9d:	jae    40abeb <__swc_fn_0a4ed24b_000022_3a2e2048+0x5b>
  40ab9f:	nop
  40aba0:	lea    r8,[rip+0x194c9]        # 424070 <__swc_bss_base_0a4ed24b+0x30>
  40aba7:	lea    r9,[rax+rax*2]
  40abab:	lea    r9,[r8+r9*8]
  40abaf:	mov    r8,rcx
  40abb2:	sub    r8,QWORD PTR [r9+0x8]
  40abb6:	mov    r9,QWORD PTR [r9+0x10]
  40abba:	cmp    r8,r9
  40abbd:	jae    40abe5 <__swc_fn_0a4ed24b_000022_3a2e2048+0x55>
  40abbf:	mov    rax,rcx
  40abc2:	and    rax,0xffffffffffc00000
  40abc9:	shr    rcx,0x10
  40abcd:	and    ecx,0x3f
  40abd0:	mov    edx,DWORD PTR [rax+0x28]
  40abd3:	shrx   ecx,ecx,edx
  40abd8:	shl    rcx,0x4
  40abdc:	lea    rax,[rax+rcx*8+0x80]
  40abe4:	ret
  40abe5:	inc    eax
  40abe7:	cmp    eax,edx
  40abe9:	jb     40aba0 <__swc_fn_0a4ed24b_000022_3a2e2048+0x10>
  40abeb:	xor    eax,eax
  40abed:	ret
	...

000000000040abf0 <__swc_fn_0a4ed24b_000025_4aca8b9e>:
  40abf0:	vxorps xmm0,xmm0,xmm0
  40abf4:	vmovups XMMWORD PTR [rcx],xmm0
  40abf8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40abfd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40ac02:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40ac07:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40ac0c:	mov    QWORD PTR [rcx+0x50],0x0
  40ac14:	ret
	...

000000000040ac20 <__swc_fn_0a4ed24b_000028_4aca8b9e>:
  40ac20:	vxorps xmm0,xmm0,xmm0
  40ac24:	xor    eax,eax
  40ac26:	cs nop WORD PTR [rax+rax*1+0x0]
  40ac30:	cs nop WORD PTR [rax+rax*1+0x0]
  40ac3a:	nop    WORD PTR [rax+rax*1+0x0]
  40ac40:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40ac45:	add    rax,0x10
  40ac49:	cmp    rax,0x9b0
  40ac50:	jne    40ac40 <__swc_fn_0a4ed24b_000028_4aca8b9e+0x20>
  40ac52:	mov    QWORD PTR [rcx+0x9b0],0x0
  40ac5d:	ret
	...

000000000040ac60 <__swc_fn_0a4ed24b_000031_90860ff2>:
  40ac60:	push   rsi
  40ac61:	push   rdi
  40ac62:	sub    rsp,0x8
  40ac66:	lea    rsi,[rip+0x1739b]        # 422008 <__swc_data_base_0a4ed24b+0x8>
  40ac6d:	mov    rax,QWORD PTR [rsi]
  40ac70:	mov    ecx,0xffffffff
  40ac75:	cmp    rax,rcx
  40ac78:	je     40ac81 <__swc_fn_0a4ed24b_000031_90860ff2+0x21>
  40ac7a:	add    rsp,0x8
  40ac7e:	pop    rdi
  40ac7f:	pop    rsi
  40ac80:	ret
  40ac81:	mov    rcx,QWORD PTR [rip+0x83f0]        # 413078 <__swc_fn_0a4ed24b_000176_0d61c738+0x1198>
  40ac88:	call   409670 <__swc_fn_0a4ed24b_000126_102fe7b9>
  40ac8d:	mov    rcx,rax
  40ac90:	mov    eax,0xffffffff
  40ac95:	lock cmpxchg QWORD PTR [rsi],rcx
  40ac9a:	mov    rdi,rax
  40ac9d:	mov    eax,0xffffffff
  40aca2:	cmp    rdi,rax
  40aca5:	je     40acb6 <__swc_fn_0a4ed24b_000031_90860ff2+0x56>
  40aca7:	call   40ce90 <__swc_fn_0a4ed24b_000127_8dffa290>
  40acac:	mov    rax,rdi
  40acaf:	add    rsp,0x8
  40acb3:	pop    rdi
  40acb4:	pop    rsi
  40acb5:	ret
  40acb6:	mov    rax,rcx
  40acb9:	add    rsp,0x8
  40acbd:	pop    rdi
  40acbe:	pop    rsi
  40acbf:	ret

000000000040acc0 <__swc_fn_0a4ed24b_000034_25f19556>:
  40acc0:	sub    rsp,0x8
  40acc4:	vxorps xmm0,xmm0,xmm0
  40acc8:	xor    eax,eax
  40acca:	cs nop WORD PTR [rax+rax*1+0x0]
  40acd4:	cs nop WORD PTR [rax+rax*1+0x0]
  40acde:	xchg   ax,ax
  40ace0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40ace5:	add    rax,0x10
  40ace9:	cmp    rax,0x2b00
  40acf0:	jne    40ace0 <__swc_fn_0a4ed24b_000034_25f19556+0x20>
  40acf2:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40acfc:	xor    al,al
  40acfe:	mov    rdx,rax
  40ad01:	xor    al,al
  40ad03:	mov    r8,rax
  40ad06:	xor    al,al
  40ad08:	mov    r9,rax
  40ad0b:	xor    al,al
  40ad0d:	mov    r10,rax
  40ad10:	xor    al,al
  40ad12:	mov    r11,rax
  40ad15:	call   40e0f0 <__swc_fn_0a4ed24b_000035_95622a2b>
  40ad1a:	add    rsp,0x8
  40ad1e:	ret
	...

000000000040ad20 <__swc_fn_0a4ed24b_000037_b4982903>:
  40ad20:	push   rsi
  40ad21:	push   rdi
  40ad22:	push   r12
  40ad24:	mov    rsi,r8
  40ad27:	mov    rdi,rdx
  40ad2a:	mov    rcx,rdx
  40ad2d:	call   40dc80 <__swc_fn_0a4ed24b_000002_884bb5c0>
  40ad32:	mov    r12,rax
  40ad35:	test   rax,rax
  40ad38:	jne    40ad41 <__swc_fn_0a4ed24b_000037_b4982903+0x21>
  40ad3a:	xor    eax,eax
  40ad3c:	pop    r12
  40ad3e:	pop    rdi
  40ad3f:	pop    rsi
  40ad40:	ret
  40ad41:	mov    rcx,r12
  40ad44:	mov    rdx,rsi
  40ad47:	call   4072a0 <__swc_fn_0a4ed24b_000003_7ab4792e>
  40ad4c:	test   al,al
  40ad4e:	jne    40ad62 <__swc_fn_0a4ed24b_000037_b4982903+0x42>
  40ad50:	mov    rcx,r12
  40ad53:	mov    rdx,rdi
  40ad56:	call   40ff20 <__swc_fn_0a4ed24b_000113_49b378a9>
  40ad5b:	xor    eax,eax
  40ad5d:	pop    r12
  40ad5f:	pop    rdi
  40ad60:	pop    rsi
  40ad61:	ret
  40ad62:	mov    rax,r12
  40ad65:	pop    r12
  40ad67:	pop    rdi
  40ad68:	pop    rsi
  40ad69:	ret
	...

000000000040ad80 <__swc_fn_0a4ed24b_000040_6895916d>:
  40ad80:	push   rsi
  40ad81:	push   rdi
  40ad82:	push   r12
  40ad84:	mov    rsi,rcx
  40ad87:	mov    edx,0x9b8
  40ad8c:	call   40e160 <__swc_fn_0a4ed24b_000038_788ceb38>
  40ad91:	mov    rdi,rax
  40ad94:	test   rax,rax
  40ad97:	jne    40ada0 <__swc_fn_0a4ed24b_000040_6895916d+0x20>
  40ad99:	xor    eax,eax
  40ad9b:	pop    r12
  40ad9d:	pop    rdi
  40ad9e:	pop    rsi
  40ad9f:	ret
  40ada0:	vxorps xmm0,xmm0,xmm0
  40ada4:	xor    eax,eax
  40ada6:	cs nop WORD PTR [rax+rax*1+0x0]
  40adb0:	cs nop WORD PTR [rax+rax*1+0x0]
  40adba:	nop    WORD PTR [rax+rax*1+0x0]
  40adc0:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40adc5:	add    rax,0x10
  40adc9:	cmp    rax,0x9b0
  40add0:	jne    40adc0 <__swc_fn_0a4ed24b_000040_6895916d+0x40>
  40add2:	mov    QWORD PTR [rdi+0x9b0],0x0
  40addd:	mov    QWORD PTR [rdi],rsi
  40ade0:	call   40cf40 <__swc_fn_0a4ed24b_000130_c1196dfb>
  40ade5:	mov    QWORD PTR [rdi+0x18],rax
  40ade9:	lea    r12,[rsi+0x10]
  40aded:	mov    rcx,r12
  40adf0:	call   4098c0 <__swc_fn_0a4ed24b_000135_e3032dc2>
  40adf5:	mov    rax,QWORD PTR [rsi+0x20]
  40adf9:	mov    QWORD PTR [rdi+0x8],rax
  40adfd:	mov    rax,QWORD PTR [rsi+0x20]
  40ae01:	test   rax,rax
  40ae04:	je     40ae0a <__swc_fn_0a4ed24b_000040_6895916d+0x8a>
  40ae06:	mov    QWORD PTR [rax+0x10],rdi
  40ae0a:	mov    QWORD PTR [rsi+0x20],rdi
  40ae0e:	mov    rcx,r12
  40ae11:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  40ae16:	mov    rax,rdi
  40ae19:	pop    r12
  40ae1b:	pop    rdi
  40ae1c:	pop    rsi
  40ae1d:	ret
	...

000000000040ae20 <__swc_fn_0a4ed24b_000043_957e4917>:
  40ae20:	mov    rax,QWORD PTR [rdx+0x10]
  40ae24:	test   rax,rax
  40ae27:	je     40ae33 <__swc_fn_0a4ed24b_000043_957e4917+0x13>
  40ae29:	mov    rcx,QWORD PTR [rdx+0x8]
  40ae2d:	mov    QWORD PTR [rax+0x8],rcx
  40ae31:	jmp    40ae3b <__swc_fn_0a4ed24b_000043_957e4917+0x1b>
  40ae33:	mov    rax,QWORD PTR [rdx+0x8]
  40ae37:	mov    QWORD PTR [rcx+0x20],rax
  40ae3b:	mov    rax,QWORD PTR [rdx+0x8]
  40ae3f:	test   rax,rax
  40ae42:	je     40ae4c <__swc_fn_0a4ed24b_000043_957e4917+0x2c>
  40ae44:	mov    rcx,QWORD PTR [rdx+0x10]
  40ae48:	mov    QWORD PTR [rax+0x10],rcx
  40ae4c:	vxorps xmm0,xmm0,xmm0
  40ae50:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40ae55:	ret
	...

000000000040ae60 <__swc_fn_0a4ed24b_000046_88f44774>:
  40ae60:	sub    rsp,0x8
  40ae64:	mov    r9,r8
  40ae67:	mov    r10,rdx
  40ae6a:	call   40e210 <__swc_fn_0a4ed24b_000044_9c2ade9b>
  40ae6f:	mov    eax,0x1
  40ae74:	xchg   DWORD PTR [r9+0x6c],eax
  40ae78:	mov    rax,QWORD PTR [r9+0x60]
  40ae7c:	test   rax,rax
  40ae7f:	je     40aec3 <__swc_fn_0a4ed24b_000046_88f44774+0x63>
  40ae81:	xor    eax,eax
  40ae83:	xchg   DWORD PTR [r9+0x6c],eax
  40ae87:	movzx  eax,BYTE PTR [r9+0x39]
  40ae8c:	lea    rax,[rax+rax*4]
  40ae90:	lea    rax,[r10+rax*8+0x28]
  40ae95:	mov    QWORD PTR [r9+0x50],0x0
  40ae9d:	mov    rcx,QWORD PTR [rax+0x8]
  40aea1:	mov    QWORD PTR [r9+0x48],rcx
  40aea5:	mov    rcx,QWORD PTR [rax+0x8]
  40aea9:	test   rcx,rcx
  40aeac:	je     40aeb4 <__swc_fn_0a4ed24b_000046_88f44774+0x54>
  40aeae:	mov    QWORD PTR [rcx+0x50],r9
  40aeb2:	jmp    40aeb8 <__swc_fn_0a4ed24b_000046_88f44774+0x58>
  40aeb4:	mov    QWORD PTR [rax+0x10],r9
  40aeb8:	mov    QWORD PTR [rax+0x8],r9
  40aebc:	xor    eax,eax
  40aebe:	add    rsp,0x8
  40aec2:	ret
  40aec3:	movzx  eax,BYTE PTR [r9+0x39]
  40aec8:	lea    rax,[rax+rax*4]
  40aecc:	lea    rax,[r10+rax*8+0x28]
  40aed1:	mov    QWORD PTR [r9+0x50],0x0
  40aed9:	mov    rcx,QWORD PTR [rax+0x18]
  40aedd:	mov    QWORD PTR [r9+0x48],rcx
  40aee1:	mov    rcx,QWORD PTR [rax+0x18]
  40aee5:	test   rcx,rcx
  40aee8:	je     40aeee <__swc_fn_0a4ed24b_000046_88f44774+0x8e>
  40aeea:	mov    QWORD PTR [rcx+0x50],r9
  40aeee:	mov    QWORD PTR [rax+0x18],r9
  40aef2:	mov    eax,0x1
  40aef7:	add    rsp,0x8
  40aefb:	ret
  40aefc:	add    BYTE PTR [rax],al
	...

000000000040af00 <__swc_fn_0a4ed24b_000049_2ff013cc>:
  40af00:	push   r12
  40af02:	push   r13
  40af04:	push   rdi
  40af05:	push   rsi
  40af06:	push   r14
  40af08:	push   r15
  40af0a:	sub    rsp,0x178
  40af11:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40af1a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40af23:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40af2c:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40af35:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40af3e:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40af47:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40af50:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40af59:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40af62:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40af6b:	mov    r12,rcx
  40af6e:	lea    rax,[rip+0x1928b]        # 424200 <__swc_bss_base_0a4ed24b+0x1c0>
  40af75:	mov    rcx,QWORD PTR [rax]
  40af78:	mov    r13,rcx
  40af7b:	test   rcx,rcx
  40af7e:	jne    40af8e <__swc_fn_0a4ed24b_000049_2ff013cc+0x8e>
  40af80:	mov    r13d,0x1dcd6500
  40af86:	mov    ecx,0x1dcd6500
  40af8b:	xchg   QWORD PTR [rax],rcx
  40af8e:	lea    rax,[rip+0x1706b]        # 422000 <__swc_data_base_0a4ed24b>
  40af95:	mov    rax,QWORD PTR [rax]
  40af98:	cmp    rax,0xffffffffffffffff
  40af9c:	je     40afab <__swc_fn_0a4ed24b_000049_2ff013cc+0xab>
  40af9e:	mov    eax,eax
  40afa0:	mov    edi,eax
  40afa2:	xor    eax,eax
  40afa4:	call   407000 <pthread_getspecific@plt>
  40afa9:	jmp    40afad <__swc_fn_0a4ed24b_000049_2ff013cc+0xad>
  40afab:	xor    eax,eax
  40afad:	test   rax,rax
  40afb0:	jne    40afbf <__swc_fn_0a4ed24b_000049_2ff013cc+0xbf>
  40afb2:	call   40ac60 <__swc_fn_0a4ed24b_000031_90860ff2>
  40afb7:	mov    rcx,rax
  40afba:	call   410280 <__swc_fn_0a4ed24b_000128_41c3251c>
  40afbf:	test   rax,rax
  40afc2:	je     40afd4 <__swc_fn_0a4ed24b_000049_2ff013cc+0xd4>
  40afc4:	cmp    QWORD PTR [rax],r12
  40afc7:	jne    40afd4 <__swc_fn_0a4ed24b_000049_2ff013cc+0xd4>
  40afc9:	cmp    DWORD PTR [rax+0x20],0x0
  40afcd:	jne    40afd4 <__swc_fn_0a4ed24b_000049_2ff013cc+0xd4>
  40afcf:	mov    rsi,rax
  40afd2:	jmp    40afd6 <__swc_fn_0a4ed24b_000049_2ff013cc+0xd6>
  40afd4:	xor    esi,esi
  40afd6:	lea    rdi,[r12+0x2a88]
  40afde:	mov    r14,QWORD PTR [rdi]
  40afe1:	test   r14,r14
  40afe4:	jne    40b033 <__swc_fn_0a4ed24b_000049_2ff013cc+0x133>
  40afe6:	lea    rax,[rip+0x1906b]        # 424058 <__swc_bss_base_0a4ed24b+0x18>
  40afed:	mov    rax,QWORD PTR [rax]
  40aff0:	test   rax,rax
  40aff3:	setne  al
  40aff6:	jne    40b01a <__swc_fn_0a4ed24b_000049_2ff013cc+0x11a>
  40aff8:	mov    rax,QWORD PTR [r12+0x2a70]
  40b000:	test   rax,rax
  40b003:	setne  al
  40b006:	jne    40b01a <__swc_fn_0a4ed24b_000049_2ff013cc+0x11a>
  40b008:	test   rsi,rsi
  40b00b:	setne  al
  40b00e:	je     40b01a <__swc_fn_0a4ed24b_000049_2ff013cc+0x11a>
  40b010:	cmp    DWORD PTR [rsi+0x730],0x0
  40b017:	setne  al
  40b01a:	test   al,al
  40b01c:	je     40b02e <__swc_fn_0a4ed24b_000049_2ff013cc+0x12e>
  40b01e:	call   410330 <__swc_fn_0a4ed24b_000131_944f555b>
  40b023:	lea    rcx,[rax+r13*1]
  40b027:	xor    eax,eax
  40b029:	lock cmpxchg QWORD PTR [rdi],rcx
  40b02e:	jmp    40b133 <__swc_fn_0a4ed24b_000049_2ff013cc+0x233>
  40b033:	call   410330 <__swc_fn_0a4ed24b_000131_944f555b>
  40b038:	mov    r15,rax
  40b03b:	cmp    rax,r14
  40b03e:	jb     40b04f <__swc_fn_0a4ed24b_000049_2ff013cc+0x14f>
  40b040:	xor    ecx,ecx
  40b042:	mov    rax,r14
  40b045:	lock cmpxchg QWORD PTR [rdi],rcx
  40b04a:	cmp    rax,r14
  40b04d:	je     40b054 <__swc_fn_0a4ed24b_000049_2ff013cc+0x154>
  40b04f:	jmp    40b133 <__swc_fn_0a4ed24b_000049_2ff013cc+0x233>
  40b054:	test   rsi,rsi
  40b057:	je     40b072 <__swc_fn_0a4ed24b_000049_2ff013cc+0x172>
  40b059:	cmp    r15,r13
  40b05c:	jb     40b072 <__swc_fn_0a4ed24b_000049_2ff013cc+0x172>
  40b05e:	mov    rax,r15
  40b061:	sub    rax,r13
  40b064:	mov    rcx,r12
  40b067:	mov    rdx,rsi
  40b06a:	mov    r8,rax
  40b06d:	call   40e650 <__swc_fn_0a4ed24b_000059_3ca3ac64>
  40b072:	lea    rsi,[r12+0x10]
  40b077:	mov    rcx,rsi
  40b07a:	call   4098c0 <__swc_fn_0a4ed24b_000135_e3032dc2>
  40b07f:	mov    rax,QWORD PTR [r12+0x18]
  40b084:	mov    rdi,rax
  40b087:	test   rdi,rdi
  40b08a:	je     40b0b4 <__swc_fn_0a4ed24b_000049_2ff013cc+0x1b4>
  40b08c:	cs nop WORD PTR [rax+rax*1+0x0]
  40b096:	cs nop WORD PTR [rax+rax*1+0x0]
  40b0a0:	mov    rcx,rdi
  40b0a3:	call   407470 <__swc_fn_0a4ed24b_000015_07eb9884>
  40b0a8:	mov    rax,QWORD PTR [rdi+0x10]
  40b0ac:	mov    rdi,rax
  40b0af:	test   rax,rax
  40b0b2:	jne    40b0a0 <__swc_fn_0a4ed24b_000049_2ff013cc+0x1a0>
  40b0b4:	mov    rcx,rsi
  40b0b7:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  40b0bc:	mov    rcx,r12
  40b0bf:	call   4098c0 <__swc_fn_0a4ed24b_000135_e3032dc2>
  40b0c4:	xor    esi,esi
  40b0c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40b0d0:	mov    rax,QWORD PTR [r12+0x2a70]
  40b0d8:	cmp    rsi,rax
  40b0db:	jae    40b12b <__swc_fn_0a4ed24b_000049_2ff013cc+0x22b>
  40b0dd:	lea    rax,[rsi+rsi*4]
  40b0e1:	lea    rax,[r12+rax*8+0x268]
  40b0e9:	mov    r8,QWORD PTR [rax]
  40b0ec:	mov    r9,QWORD PTR [rax+0x8]
  40b0f0:	mov    r10,QWORD PTR [rax+0x10]
  40b0f4:	mov    rax,QWORD PTR [rax+0x20]
  40b0f8:	cmp    rax,r15
  40b0fb:	jae    40b108 <__swc_fn_0a4ed24b_000049_2ff013cc+0x208>
  40b0fd:	mov    rcx,r15
  40b100:	sub    rcx,rax
  40b103:	cmp    rcx,r13
  40b106:	jae    40b10d <__swc_fn_0a4ed24b_000049_2ff013cc+0x20d>
  40b108:	inc    rsi
  40b10b:	jmp    40b0d0 <__swc_fn_0a4ed24b_000049_2ff013cc+0x1d0>
  40b10d:	mov    rcx,r12
  40b110:	mov    rdx,rsi
  40b113:	call   40e600 <__swc_fn_0a4ed24b_000056_38b21f11>
  40b118:	mov    rcx,r12
  40b11b:	mov    rdx,r8
  40b11e:	mov    r8,r9
  40b121:	mov    r9,r10
  40b124:	call   407750 <__swc_fn_0a4ed24b_000039_40d1e569>
  40b129:	jmp    40b0d0 <__swc_fn_0a4ed24b_000049_2ff013cc+0x1d0>
  40b12b:	mov    rcx,r12
  40b12e:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  40b133:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40b13c:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40b145:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40b14e:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40b157:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40b160:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40b169:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40b172:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40b17b:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40b184:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40b18d:	add    rsp,0x178
  40b194:	pop    r15
  40b196:	pop    r14
  40b198:	pop    rsi
  40b199:	pop    rdi
  40b19a:	pop    r13
  40b19c:	pop    r12
  40b19e:	ret
	...

000000000040b1a0 <__swc_fn_0a4ed24b_000052_c7484fb0>:
  40b1a0:	lea    rax,[rdx-0x58]
  40b1a4:	ret
	...

000000000040b1b0 <__swc_fn_0a4ed24b_000055_81f7713d>:
  40b1b0:	push   rsi
  40b1b1:	push   rdi
  40b1b2:	push   r12
  40b1b4:	push   r13
  40b1b6:	sub    rsp,0x68
  40b1ba:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40b1c0:	mov    rsi,r9
  40b1c3:	mov    rdi,rcx
  40b1c6:	mov    r12,rdx
  40b1c9:	mov    r13,r8
  40b1cc:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40b1d4:	jne    40b1e3 <__swc_fn_0a4ed24b_000055_81f7713d+0x33>
  40b1d6:	xor    eax,eax
  40b1d8:	add    rsp,0x68
  40b1dc:	pop    r13
  40b1de:	pop    r12
  40b1e0:	pop    rdi
  40b1e1:	pop    rsi
  40b1e2:	ret
  40b1e3:	mov    rcx,rdi
  40b1e6:	call   4098c0 <__swc_fn_0a4ed24b_000135_e3032dc2>
  40b1eb:	movabs rax,0x7fffffffffffffff
  40b1f5:	cmp    r12,rax
  40b1f8:	mov    rax,0xffffffffffffffff
  40b1ff:	lea    rcx,[r12+r12*1]
  40b203:	cmovbe rax,rcx
  40b207:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40b20e:	mov    rdx,rcx
  40b211:	sub    rax,r12
  40b214:	inc    rax
  40b217:	xor    r8d,r8d
  40b21a:	test   rcx,rcx
  40b21d:	jbe    40b248 <__swc_fn_0a4ed24b_000055_81f7713d+0x98>
  40b21f:	nop
  40b220:	lea    r9,[r8+r8*4]
  40b224:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40b22c:	sub    r9,r12
  40b22f:	cmp    r9,rax
  40b232:	jae    40b23f <__swc_fn_0a4ed24b_000055_81f7713d+0x8f>
  40b234:	mov    rdx,r8
  40b237:	mov    rax,r9
  40b23a:	test   r9,r9
  40b23d:	je     40b248 <__swc_fn_0a4ed24b_000055_81f7713d+0x98>
  40b23f:	add    r8,0x1
  40b243:	cmp    r8,rcx
  40b246:	jb     40b220 <__swc_fn_0a4ed24b_000055_81f7713d+0x70>
  40b248:	mov    rax,QWORD PTR [rdi+0x2a70]
  40b24f:	cmp    rdx,rax
  40b252:	jne    40b26f <__swc_fn_0a4ed24b_000055_81f7713d+0xbf>
  40b254:	mov    rcx,rdi
  40b257:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  40b25c:	xor    eax,eax
  40b25e:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b264:	add    rsp,0x68
  40b268:	pop    r13
  40b26a:	pop    r12
  40b26c:	pop    rdi
  40b26d:	pop    rsi
  40b26e:	ret
  40b26f:	lea    rax,[rdx+rdx*4]
  40b273:	lea    rax,[rdi+rax*8+0x268]
  40b27b:	vmovups xmm6,XMMWORD PTR [rax]
  40b27f:	mov    r8,QWORD PTR [rax+0x10]
  40b283:	mov    rcx,rdi
  40b286:	call   40e600 <__swc_fn_0a4ed24b_000056_38b21f11>
  40b28b:	vpshufd xmm0,xmm6,0xee
  40b290:	vmovsd QWORD PTR [r13+0x0],xmm0
  40b296:	mov    QWORD PTR [rsi],r8
  40b299:	mov    rcx,rdi
  40b29c:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  40b2a1:	vmovq  rax,xmm6
  40b2a6:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b2ac:	add    rsp,0x68
  40b2b0:	pop    r13
  40b2b2:	pop    r12
  40b2b4:	pop    rdi
  40b2b5:	pop    rsi
  40b2b6:	ret
	...

000000000040b2c0 <__swc_fn_0a4ed24b_000058_8bd8d1d5>:
  40b2c0:	push   r12
  40b2c2:	push   r13
  40b2c4:	push   r14
  40b2c6:	push   r15
  40b2c8:	push   rdi
  40b2c9:	push   rsi
  40b2ca:	sub    rsp,0x148
  40b2d1:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40b2da:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40b2e3:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40b2ec:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40b2f5:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40b2fe:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40b307:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40b310:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40b319:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40b322:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40b32b:	mov    r12,r9
  40b32e:	mov    r13,rcx
  40b331:	mov    r14,rdx
  40b334:	mov    r15,r8
  40b337:	test   rdx,rdx
  40b33a:	jne    40b34e <__swc_fn_0a4ed24b_000058_8bd8d1d5+0x8e>
  40b33c:	add    rsp,0x148
  40b343:	pop    rsi
  40b344:	pop    rdi
  40b345:	pop    r15
  40b347:	pop    r14
  40b349:	pop    r13
  40b34b:	pop    r12
  40b34d:	ret
  40b34e:	cmp    r12,0x200000
  40b355:	ja     40b3e7 <__swc_fn_0a4ed24b_000058_8bd8d1d5+0x127>
  40b35b:	lea    rax,[rip+0x16c9e]        # 422000 <__swc_data_base_0a4ed24b>
  40b362:	mov    rax,QWORD PTR [rax]
  40b365:	cmp    rax,0xffffffffffffffff
  40b369:	je     40b378 <__swc_fn_0a4ed24b_000058_8bd8d1d5+0xb8>
  40b36b:	mov    eax,eax
  40b36d:	mov    edi,eax
  40b36f:	xor    eax,eax
  40b371:	call   407000 <pthread_getspecific@plt>
  40b376:	jmp    40b37a <__swc_fn_0a4ed24b_000058_8bd8d1d5+0xba>
  40b378:	xor    eax,eax
  40b37a:	test   rax,rax
  40b37d:	je     40b384 <__swc_fn_0a4ed24b_000058_8bd8d1d5+0xc4>
  40b37f:	mov    rsi,rax
  40b382:	jmp    40b394 <__swc_fn_0a4ed24b_000058_8bd8d1d5+0xd4>
  40b384:	call   40ac60 <__swc_fn_0a4ed24b_000031_90860ff2>
  40b389:	mov    rcx,rax
  40b38c:	call   410280 <__swc_fn_0a4ed24b_000128_41c3251c>
  40b391:	mov    rsi,rax
  40b394:	test   rsi,rsi
  40b397:	je     40b3e7 <__swc_fn_0a4ed24b_000058_8bd8d1d5+0x127>
  40b399:	cmp    QWORD PTR [rsi],r13
  40b39c:	jne    40b3e7 <__swc_fn_0a4ed24b_000058_8bd8d1d5+0x127>
  40b39e:	cmp    DWORD PTR [rsi+0x20],0x0
  40b3a2:	jne    40b3e7 <__swc_fn_0a4ed24b_000058_8bd8d1d5+0x127>
  40b3a4:	cmp    DWORD PTR [rsi+0x730],0x10
  40b3ab:	jae    40b3e7 <__swc_fn_0a4ed24b_000058_8bd8d1d5+0x127>
  40b3ad:	mov    eax,DWORD PTR [rsi+0x730]
  40b3b3:	lea    rdi,[rax+rax*4]
  40b3b7:	lea    rdi,[rsi+rdi*8+0x738]
  40b3bf:	mov    QWORD PTR [rdi],r14
  40b3c2:	mov    QWORD PTR [rdi+0x8],r15
  40b3c6:	mov    QWORD PTR [rdi+0x10],r12
  40b3ca:	mov    QWORD PTR [rdi+0x18],0x0
  40b3d2:	call   410330 <__swc_fn_0a4ed24b_000131_944f555b>
  40b3d7:	mov    QWORD PTR [rdi+0x20],rax
  40b3db:	add    DWORD PTR [rsi+0x730],0x1
  40b3e2:	jmp    40b546 <__swc_fn_0a4ed24b_000058_8bd8d1d5+0x286>
  40b3e7:	mov    rcx,r13
  40b3ea:	call   407e90 <__swc_fn_0a4ed24b_000057_5b81d8b6>
  40b3ef:	mov    rsi,rax
  40b3f2:	cmp    r12,rax
  40b3f5:	jbe    40b42a <__swc_fn_0a4ed24b_000058_8bd8d1d5+0x16a>
  40b3f7:	cmp    r12,0x10000000
  40b3fe:	seta   al
  40b401:	ja     40b410 <__swc_fn_0a4ed24b_000058_8bd8d1d5+0x150>
  40b403:	mov    rax,QWORD PTR [r13+0x2a70]
  40b40a:	test   rax,rax
  40b40d:	setne  al
  40b410:	test   al,al
  40b412:	je     40b42a <__swc_fn_0a4ed24b_000058_8bd8d1d5+0x16a>
  40b414:	mov    rcx,r13
  40b417:	mov    rdx,r14
  40b41a:	mov    r8,r15
  40b41d:	mov    r9,r12
  40b420:	call   407750 <__swc_fn_0a4ed24b_000039_40d1e569>
  40b425:	jmp    40b546 <__swc_fn_0a4ed24b_000058_8bd8d1d5+0x286>
  40b42a:	call   410330 <__swc_fn_0a4ed24b_000131_944f555b>
  40b42f:	mov    rdi,rax
  40b432:	mov    rcx,r13
  40b435:	call   4098c0 <__swc_fn_0a4ed24b_000135_e3032dc2>
  40b43a:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b442:	je     40b4fa <__swc_fn_0a4ed24b_000058_8bd8d1d5+0x23a>
  40b448:	nop    DWORD PTR [rax+rax*1+0x0]
  40b450:	cmp    QWORD PTR [r13+0x2a70],0x100
  40b45b:	jae    40b470 <__swc_fn_0a4ed24b_000058_8bd8d1d5+0x1b0>
  40b45d:	mov    rax,QWORD PTR [r13+0x2a68]
  40b464:	add    rax,r12
  40b467:	cmp    rax,rsi
  40b46a:	jbe    40b4fa <__swc_fn_0a4ed24b_000058_8bd8d1d5+0x23a>
  40b470:	xor    eax,eax
  40b472:	mov    rcx,QWORD PTR [r13+0x2a70]
  40b479:	mov    edx,0x1
  40b47e:	cmp    rcx,0x1
  40b482:	jbe    40b4b9 <__swc_fn_0a4ed24b_000058_8bd8d1d5+0x1f9>
  40b484:	cs nop WORD PTR [rax+rax*1+0x0]
  40b48e:	xchg   ax,ax
  40b490:	lea    r8,[rdx+rdx*4]
  40b494:	lea    r8,[r13+r8*8+0x268]
  40b49c:	lea    r9,[rax+rax*4]
  40b4a0:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40b4a8:	cmp    QWORD PTR [r8+0x18],r9
  40b4ac:	cmovb  rax,rdx
  40b4b0:	add    rdx,0x1
  40b4b4:	cmp    rdx,rcx
  40b4b7:	jb     40b490 <__swc_fn_0a4ed24b_000058_8bd8d1d5+0x1d0>
  40b4b9:	lea    rcx,[rax+rax*4]
  40b4bd:	lea    rcx,[r13+rcx*8+0x268]
  40b4c5:	mov    r8,QWORD PTR [rcx]
  40b4c8:	mov    r9,QWORD PTR [rcx+0x8]
  40b4cc:	mov    r10,QWORD PTR [rcx+0x10]
  40b4d0:	mov    rcx,r13
  40b4d3:	mov    rdx,rax
  40b4d6:	call   40e600 <__swc_fn_0a4ed24b_000056_38b21f11>
  40b4db:	mov    rcx,r13
  40b4de:	mov    rdx,r8
  40b4e1:	mov    r8,r9
  40b4e4:	mov    r9,r10
  40b4e7:	call   407750 <__swc_fn_0a4ed24b_000039_40d1e569>
  40b4ec:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b4f4:	jne    40b450 <__swc_fn_0a4ed24b_000058_8bd8d1d5+0x190>
  40b4fa:	add    QWORD PTR [r13+0x2a78],0x1
  40b502:	mov    rax,QWORD PTR [r13+0x2a70]
  40b509:	lea    rax,[rax+rax*4]
  40b50d:	lea    rax,[r13+rax*8+0x268]
  40b515:	mov    QWORD PTR [rax],r14
  40b518:	mov    QWORD PTR [rax+0x8],r15
  40b51c:	mov    QWORD PTR [rax+0x10],r12
  40b520:	mov    rcx,QWORD PTR [r13+0x2a78]
  40b527:	mov    QWORD PTR [rax+0x18],rcx
  40b52b:	mov    QWORD PTR [rax+0x20],rdi
  40b52f:	add    QWORD PTR [r13+0x2a68],r12
  40b536:	add    QWORD PTR [r13+0x2a70],0x1
  40b53e:	mov    rcx,r13
  40b541:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  40b546:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40b54f:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40b558:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40b561:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40b56a:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40b573:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40b57c:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40b585:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40b58e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40b597:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40b5a0:	add    rsp,0x148
  40b5a7:	pop    rsi
  40b5a8:	pop    rdi
  40b5a9:	pop    r15
  40b5ab:	pop    r14
  40b5ad:	pop    r13
  40b5af:	pop    r12
  40b5b1:	ret
	...

000000000040b5c0 <__swc_fn_0a4ed24b_000061_0a7f67d9>:
  40b5c0:	push   rbx
  40b5c1:	push   r12
  40b5c3:	push   r13
  40b5c5:	push   r14
  40b5c7:	push   r15
  40b5c9:	push   rdi
  40b5ca:	push   rsi
  40b5cb:	sub    rsp,0xf0
  40b5d2:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40b5d8:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40b5de:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40b5e4:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40b5ea:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40b5f3:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40b5fc:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40b605:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40b60e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40b617:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40b620:	mov    eax,r8d
  40b623:	mov    rbx,rcx
  40b626:	mov    r12,rdx
  40b629:	mov    QWORD PTR [rsp+0x18],rdx
  40b62e:	mov    ecx,DWORD PTR [r12+0x58]
  40b633:	mov    r13d,ecx
  40b636:	cmp    ecx,0x10
  40b639:	mov    ecx,0x10
  40b63e:	cmovb  r13d,ecx
  40b642:	test   r13d,r13d
  40b645:	mov    rcx,r13
  40b648:	mov    edx,0x8
  40b64d:	cmove  ecx,edx
  40b650:	dec    rcx
  40b653:	mov    rdx,0xffffffffffffffff
  40b65a:	sub    rdx,rcx
  40b65d:	xor    r14d,r14d
  40b660:	mov    r8,rcx
  40b663:	not    r8
  40b666:	lea    rcx,[rcx+0x58]
  40b66a:	and    rcx,r8
  40b66d:	cmp    rdx,0x58
  40b671:	cmovae r14,rcx
  40b675:	cmp    eax,0xffffffff
  40b678:	jne    40b681 <__swc_fn_0a4ed24b_000061_0a7f67d9+0xc1>
  40b67a:	mov    r15,QWORD PTR [r12+0x48]
  40b67f:	jmp    40b6b3 <__swc_fn_0a4ed24b_000061_0a7f67d9+0xf3>
  40b681:	test   eax,eax
  40b683:	jne    40b68c <__swc_fn_0a4ed24b_000061_0a7f67d9+0xcc>
  40b685:	mov    eax,0x8
  40b68a:	jmp    40b6b0 <__swc_fn_0a4ed24b_000061_0a7f67d9+0xf0>
  40b68c:	cmp    eax,0x8
  40b68f:	ja     40b697 <__swc_fn_0a4ed24b_000061_0a7f67d9+0xd7>
  40b691:	shl    rax,0x4
  40b695:	jmp    40b6b0 <__swc_fn_0a4ed24b_000061_0a7f67d9+0xf0>
  40b697:	lea    eax,[rax-0x9]
  40b69a:	mov    ecx,eax
  40b69c:	shr    ecx,0x2
  40b69f:	and    eax,0x3
  40b6a2:	lea    ecx,[rcx+0x7]
  40b6a5:	lea    ecx,[rcx-0x2]
  40b6a8:	lea    eax,[rax+0x5]
  40b6ab:	shlx   rax,rax,rcx
  40b6b0:	mov    r15,rax
  40b6b3:	lea    rax,[r14+r13*1]
  40b6b7:	mov    rcx,0xffffffffffffffff
  40b6be:	sub    rcx,rax
  40b6c1:	cmp    r15,rcx
  40b6c4:	jbe    40b6d4 <__swc_fn_0a4ed24b_000061_0a7f67d9+0x114>
  40b6c6:	mov    QWORD PTR [r12+0x40],0x0
  40b6cf:	jmp    40baa6 <__swc_fn_0a4ed24b_000061_0a7f67d9+0x4e6>
  40b6d4:	mov    QWORD PTR [rsp+0x20],r13
  40b6d9:	lea    r13,[rsp+0x8]
  40b6de:	add    rax,r15
  40b6e1:	mov    ecx,0x1000
  40b6e6:	test   ecx,ecx
  40b6e8:	mov    edx,0x8
  40b6ed:	cmove  ecx,edx
  40b6f0:	dec    rcx
  40b6f3:	mov    rdx,0xffffffffffffffff
  40b6fa:	sub    rdx,rcx
  40b6fd:	cmp    rax,rdx
  40b700:	jbe    40b70c <__swc_fn_0a4ed24b_000061_0a7f67d9+0x14c>
  40b702:	mov    QWORD PTR [r13+0x0],0x0
  40b70a:	jmp    40b719 <__swc_fn_0a4ed24b_000061_0a7f67d9+0x159>
  40b70c:	add    rax,rcx
  40b70f:	andn   rax,rcx,rax
  40b714:	mov    QWORD PTR [rsp+0x8],rax
  40b719:	cmp    QWORD PTR [r13+0x0],0x0
  40b71e:	jne    40b72e <__swc_fn_0a4ed24b_000061_0a7f67d9+0x16e>
  40b720:	mov    QWORD PTR [r12+0x40],0x0
  40b729:	jmp    40baa6 <__swc_fn_0a4ed24b_000061_0a7f67d9+0x4e6>
  40b72e:	mov    QWORD PTR [rsp+0x30],r15
  40b733:	xor    r15d,r15d
  40b736:	mov    QWORD PTR [rsp+0x38],0x0
  40b73f:	lea    r12,[rsp+0x10]
  40b744:	mov    QWORD PTR [rsp+0x28],r14
  40b749:	mov    r14,QWORD PTR [rsp+0x8]
  40b74e:	mov    QWORD PTR [rsp+0x10],r14
  40b753:	cmp    r14,0x10000
  40b75a:	ja     40b761 <__swc_fn_0a4ed24b_000061_0a7f67d9+0x1a1>
  40b75c:	mov    rax,r14
  40b75f:	jmp    40b7b2 <__swc_fn_0a4ed24b_000061_0a7f67d9+0x1f2>
  40b761:	xor    eax,eax
  40b763:	lea    rcx,[r14-0x1]
  40b767:	lzcnt  rax,rcx
  40b76c:	mov    ecx,0x3f
  40b771:	sub    rcx,rax
  40b774:	mov    eax,0x1
  40b779:	lea    rcx,[rcx-0x3]
  40b77d:	shl    rax,cl
  40b780:	mov    rcx,rax
  40b783:	cmp    rax,0x1000
  40b78a:	mov    eax,0x1000
  40b78f:	cmovb  rcx,rax
  40b793:	mov    rdx,0xffffffffffffffff
  40b79a:	sub    rdx,rcx
  40b79d:	mov    rax,r14
  40b7a0:	lea    r8,[r14+rcx*1-0x1]
  40b7a5:	neg    rcx
  40b7a8:	and    r8,rcx
  40b7ab:	cmp    r14,rdx
  40b7ae:	cmovbe rax,r8
  40b7b2:	mov    QWORD PTR [rsp+0x8],rax
  40b7b7:	lea    rax,[rip+0x16842]        # 422000 <__swc_data_base_0a4ed24b>
  40b7be:	mov    rax,QWORD PTR [rax]
  40b7c1:	cmp    rax,0xffffffffffffffff
  40b7c5:	je     40b7d4 <__swc_fn_0a4ed24b_000061_0a7f67d9+0x214>
  40b7c7:	mov    eax,eax
  40b7c9:	mov    edi,eax
  40b7cb:	xor    eax,eax
  40b7cd:	call   407000 <pthread_getspecific@plt>
  40b7d2:	jmp    40b7d6 <__swc_fn_0a4ed24b_000061_0a7f67d9+0x216>
  40b7d4:	xor    eax,eax
  40b7d6:	test   rax,rax
  40b7d9:	jne    40b7e8 <__swc_fn_0a4ed24b_000061_0a7f67d9+0x228>
  40b7db:	call   40ac60 <__swc_fn_0a4ed24b_000031_90860ff2>
  40b7e0:	mov    rcx,rax
  40b7e3:	call   410280 <__swc_fn_0a4ed24b_000128_41c3251c>
  40b7e8:	test   rax,rax
  40b7eb:	je     40b8dc <__swc_fn_0a4ed24b_000061_0a7f67d9+0x31c>
  40b7f1:	cmp    QWORD PTR [rax],rbx
  40b7f4:	jne    40b8dc <__swc_fn_0a4ed24b_000061_0a7f67d9+0x31c>
  40b7fa:	cmp    DWORD PTR [rax+0x20],0x0
  40b7fe:	jne    40b8dc <__swc_fn_0a4ed24b_000061_0a7f67d9+0x31c>
  40b804:	mov    rcx,QWORD PTR [rsp+0x8]
  40b809:	movabs rdx,0x7fffffffffffffff
  40b813:	cmp    rcx,rdx
  40b816:	mov    rdx,0xffffffffffffffff
  40b81d:	lea    r8,[rcx+rcx*1]
  40b821:	cmovbe rdx,r8
  40b825:	mov    r8d,DWORD PTR [rax+0x730]
  40b82c:	mov    r9d,r8d
  40b82f:	sub    rdx,rcx
  40b832:	inc    rdx
  40b835:	xor    r10d,r10d
  40b838:	test   r8,r8
  40b83b:	jbe    40b86b <__swc_fn_0a4ed24b_000061_0a7f67d9+0x2ab>
  40b83d:	nop    DWORD PTR [rax]
  40b840:	mov    r11d,r10d
  40b843:	lea    r11,[r11+r11*4]
  40b847:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40b84f:	sub    r11,rcx
  40b852:	cmp    r11,rdx
  40b855:	jae    40b862 <__swc_fn_0a4ed24b_000061_0a7f67d9+0x2a2>
  40b857:	mov    r9d,r10d
  40b85a:	mov    rdx,r11
  40b85d:	test   r11,r11
  40b860:	je     40b86b <__swc_fn_0a4ed24b_000061_0a7f67d9+0x2ab>
  40b862:	add    r10,0x1
  40b866:	cmp    r10,r8
  40b869:	jb     40b840 <__swc_fn_0a4ed24b_000061_0a7f67d9+0x280>
  40b86b:	mov    ecx,DWORD PTR [rax+0x730]
  40b871:	cmp    r9d,ecx
  40b874:	jne    40b87a <__swc_fn_0a4ed24b_000061_0a7f67d9+0x2ba>
  40b876:	xor    eax,eax
  40b878:	jmp    40b8d9 <__swc_fn_0a4ed24b_000061_0a7f67d9+0x319>
  40b87a:	lea    rcx,[r9+r9*4]
  40b87e:	lea    rcx,[rax+rcx*8+0x738]
  40b886:	vmovups xmm0,XMMWORD PTR [rcx]
  40b88a:	mov    rdx,QWORD PTR [rcx+0x10]
  40b88e:	sub    DWORD PTR [rax+0x730],0x1
  40b895:	mov    r8d,DWORD PTR [rax+0x730]
  40b89c:	lea    r8,[r8+r8*4]
  40b8a0:	lea    r8,[rax+r8*8+0x738]
  40b8a8:	vmovups xmm1,XMMWORD PTR [r8]
  40b8ad:	vmovups XMMWORD PTR [rcx],xmm1
  40b8b1:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40b8b7:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40b8bc:	mov    rax,QWORD PTR [r8+0x20]
  40b8c0:	mov    QWORD PTR [rcx+0x20],rax
  40b8c4:	vpshufd xmm1,xmm0,0xee
  40b8c9:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40b8cf:	mov    QWORD PTR [rsp+0x10],rdx
  40b8d4:	vmovq  rax,xmm0
  40b8d9:	mov    r15,rax
  40b8dc:	test   r15,r15
  40b8df:	jne    40b8f7 <__swc_fn_0a4ed24b_000061_0a7f67d9+0x337>
  40b8e1:	mov    rcx,rbx
  40b8e4:	mov    rdx,QWORD PTR [rsp+0x8]
  40b8e9:	mov    r8,r13
  40b8ec:	mov    r9,r12
  40b8ef:	call   40b1b0 <__swc_fn_0a4ed24b_000055_81f7713d>
  40b8f4:	mov    r15,rax
  40b8f7:	test   r15,r15
  40b8fa:	je     40b93b <__swc_fn_0a4ed24b_000061_0a7f67d9+0x37b>
  40b8fc:	cmp    QWORD PTR [r12],r14
  40b900:	jae    40b93b <__swc_fn_0a4ed24b_000061_0a7f67d9+0x37b>
  40b902:	mov    rax,r15
  40b905:	add    rax,QWORD PTR [r12]
  40b909:	mov    rdx,r14
  40b90c:	sub    rdx,QWORD PTR [r12]
  40b910:	mov    rcx,rax
  40b913:	call   4072a0 <__swc_fn_0a4ed24b_000003_7ab4792e>
  40b918:	test   al,al
  40b91a:	je     40b923 <__swc_fn_0a4ed24b_000061_0a7f67d9+0x363>
  40b91c:	mov    QWORD PTR [rsp+0x10],r14
  40b921:	jmp    40b93b <__swc_fn_0a4ed24b_000061_0a7f67d9+0x37b>
  40b923:	mov    rcx,rbx
  40b926:	mov    rdx,r15
  40b929:	mov    r8,QWORD PTR [rsp+0x8]
  40b92e:	mov    r9,QWORD PTR [rsp+0x10]
  40b933:	call   40b2c0 <__swc_fn_0a4ed24b_000058_8bd8d1d5>
  40b938:	xor    r15d,r15d
  40b93b:	test   r15,r15
  40b93e:	jne    40b9ba <__swc_fn_0a4ed24b_000061_0a7f67d9+0x3fa>
  40b940:	cmp    r14,0x10000
  40b947:	ja     40b94e <__swc_fn_0a4ed24b_000061_0a7f67d9+0x38e>
  40b949:	mov    rax,r14
  40b94c:	jmp    40b99f <__swc_fn_0a4ed24b_000061_0a7f67d9+0x3df>
  40b94e:	xor    eax,eax
  40b950:	lea    rcx,[r14-0x1]
  40b954:	lzcnt  rax,rcx
  40b959:	mov    ecx,0x3f
  40b95e:	sub    rcx,rax
  40b961:	mov    eax,0x1
  40b966:	lea    rcx,[rcx-0x3]
  40b96a:	shl    rax,cl
  40b96d:	mov    rcx,rax
  40b970:	cmp    rax,0x1000
  40b977:	mov    eax,0x1000
  40b97c:	cmovb  rcx,rax
  40b980:	mov    rdx,0xffffffffffffffff
  40b987:	sub    rdx,rcx
  40b98a:	mov    rax,r14
  40b98d:	lea    r8,[r14+rcx*1-0x1]
  40b992:	neg    rcx
  40b995:	and    r8,rcx
  40b998:	cmp    r14,rdx
  40b99b:	cmovbe rax,r8
  40b99f:	mov    QWORD PTR [rsp+0x8],rax
  40b9a4:	mov    QWORD PTR [rsp+0x10],r14
  40b9a9:	mov    rcx,rbx
  40b9ac:	mov    rdx,rax
  40b9af:	mov    r8,r14
  40b9b2:	call   40ad20 <__swc_fn_0a4ed24b_000037_b4982903>
  40b9b7:	mov    r15,rax
  40b9ba:	test   r15,r15
  40b9bd:	jne    40b9cb <__swc_fn_0a4ed24b_000061_0a7f67d9+0x40b>
  40b9bf:	mov    r13,QWORD PTR [rsp+0x20]
  40b9c4:	mov    rsi,QWORD PTR [rsp+0x38]
  40b9c9:	jmp    40ba07 <__swc_fn_0a4ed24b_000061_0a7f67d9+0x447>
  40b9cb:	mov    rax,r15
  40b9ce:	add    rax,QWORD PTR [rsp+0x28]
  40b9d3:	mov    r13,QWORD PTR [rsp+0x20]
  40b9d8:	test   r13d,r13d
  40b9db:	mov    rcx,r13
  40b9de:	mov    edx,0x8
  40b9e3:	cmove  ecx,edx
  40b9e6:	dec    rcx
  40b9e9:	mov    rdx,0xffffffffffffffff
  40b9f0:	sub    rdx,rcx
  40b9f3:	cmp    rax,rdx
  40b9f6:	jbe    40b9fc <__swc_fn_0a4ed24b_000061_0a7f67d9+0x43c>
  40b9f8:	xor    eax,eax
  40b9fa:	jmp    40ba04 <__swc_fn_0a4ed24b_000061_0a7f67d9+0x444>
  40b9fc:	add    rax,rcx
  40b9ff:	andn   rax,rcx,rax
  40ba04:	mov    rsi,rax
  40ba07:	mov    rax,QWORD PTR [rsp+0x8]
  40ba0c:	test   r15,r15
  40ba0f:	je     40ba18 <__swc_fn_0a4ed24b_000061_0a7f67d9+0x458>
  40ba11:	mov    rdi,QWORD PTR [rsp+0x18]
  40ba16:	jmp    40ba2a <__swc_fn_0a4ed24b_000061_0a7f67d9+0x46a>
  40ba18:	mov    rdi,QWORD PTR [rsp+0x18]
  40ba1d:	mov    QWORD PTR [rdi+0x40],0x0
  40ba25:	jmp    40baa6 <__swc_fn_0a4ed24b_000061_0a7f67d9+0x4e6>
  40ba2a:	lea    rdx,[rsi-0x58]
  40ba2e:	mov    QWORD PTR [rsi-0x58],r15
  40ba32:	mov    QWORD PTR [rsi-0x50],rax
  40ba36:	mov    rax,QWORD PTR [rsp+0x10]
  40ba3b:	mov    QWORD PTR [rsi-0x48],rax
  40ba3f:	mov    QWORD PTR [rsi-0x40],rsi
  40ba43:	mov    rax,QWORD PTR [rdi+0x48]
  40ba47:	mov    QWORD PTR [rsi-0x38],rax
  40ba4b:	mov    rax,QWORD PTR [rsp+0x30]
  40ba50:	mov    QWORD PTR [rsi-0x30],rax
  40ba54:	mov    DWORD PTR [rsi-0x10],r13d
  40ba58:	mov    QWORD PTR [rsi-0x28],0x0
  40ba60:	mov    QWORD PTR [rsi-0x20],0x0
  40ba68:	add    r15,QWORD PTR [r12]
  40ba6c:	sub    r15,rsi
  40ba6f:	mov    QWORD PTR [rsi-0x30],r15
  40ba73:	mov    rcx,QWORD PTR [rbx+0x250]
  40ba7a:	nop    WORD PTR [rax+rax*1+0x0]
  40ba80:	lea    r8,[rcx+r15*1]
  40ba84:	mov    rax,rcx
  40ba87:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40ba90:	cmp    rax,rcx
  40ba93:	je     40ba9a <__swc_fn_0a4ed24b_000061_0a7f67d9+0x4da>
  40ba95:	mov    rcx,rax
  40ba98:	jmp    40ba80 <__swc_fn_0a4ed24b_000061_0a7f67d9+0x4c0>
  40ba9a:	mov    rcx,rbx
  40ba9d:	call   40e570 <__swc_fn_0a4ed24b_000053_82546d94>
  40baa2:	mov    QWORD PTR [rdi+0x40],rsi
  40baa6:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40baac:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40bab2:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40bab8:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40babe:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40bac7:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40bad0:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40bad9:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40bae2:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40baeb:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40baf4:	add    rsp,0xf0
  40bafb:	pop    rsi
  40bafc:	pop    rdi
  40bafd:	pop    r15
  40baff:	pop    r14
  40bb01:	pop    r13
  40bb03:	pop    r12
  40bb05:	pop    rbx
  40bb06:	ret
	...

000000000040bb10 <__swc_fn_0a4ed24b_000064_b0d63361>:
  40bb10:	push   rbx
  40bb11:	push   r12
  40bb13:	push   rdi
  40bb14:	push   rsi
  40bb15:	sub    rsp,0xb8
  40bb1c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40bb22:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40bb28:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40bb2e:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40bb34:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40bb3a:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40bb40:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40bb46:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40bb4f:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40bb58:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40bb61:	mov    rbx,rdx
  40bb64:	mov    r12,rcx
  40bb67:	cmp    DWORD PTR [rbx+0x58],0x0
  40bb6b:	je     40bb85 <__swc_fn_0a4ed24b_000064_b0d63361+0x75>
  40bb6d:	mov    eax,DWORD PTR [rbx+0x58]
  40bb70:	sub    eax,0x1
  40bb73:	test   DWORD PTR [rbx+0x58],eax
  40bb76:	je     40bb85 <__swc_fn_0a4ed24b_000064_b0d63361+0x75>
  40bb78:	mov    QWORD PTR [rbx+0x40],0x0
  40bb80:	jmp    40bd97 <__swc_fn_0a4ed24b_000064_b0d63361+0x287>
  40bb85:	cmp    QWORD PTR [rbx+0x48],0x0
  40bb8a:	jne    40bb99 <__swc_fn_0a4ed24b_000064_b0d63361+0x89>
  40bb8c:	mov    QWORD PTR [rbx+0x40],0x0
  40bb94:	jmp    40bd97 <__swc_fn_0a4ed24b_000064_b0d63361+0x287>
  40bb99:	lea    rax,[rsp+0x8]
  40bb9e:	mov    rcx,QWORD PTR [rbx+0x48]
  40bba2:	cmp    rcx,0x8
  40bba6:	ja     40bbb0 <__swc_fn_0a4ed24b_000064_b0d63361+0xa0>
  40bba8:	mov    DWORD PTR [rax],0x0
  40bbae:	jmp    40bc0b <__swc_fn_0a4ed24b_000064_b0d63361+0xfb>
  40bbb0:	cmp    rcx,0x80
  40bbb7:	ja     40bbc7 <__swc_fn_0a4ed24b_000064_b0d63361+0xb7>
  40bbb9:	lea    rcx,[rcx+0xf]
  40bbbd:	shr    rcx,0x4
  40bbc1:	mov    DWORD PTR [rsp+0x8],ecx
  40bbc5:	jmp    40bc0b <__swc_fn_0a4ed24b_000064_b0d63361+0xfb>
  40bbc7:	cmp    rcx,0x10000
  40bbce:	jbe    40bbd8 <__swc_fn_0a4ed24b_000064_b0d63361+0xc8>
  40bbd0:	mov    DWORD PTR [rax],0xffffffff
  40bbd6:	jmp    40bc0b <__swc_fn_0a4ed24b_000064_b0d63361+0xfb>
  40bbd8:	dec    rcx
  40bbdb:	xor    edx,edx
  40bbdd:	lzcnt  rdx,rcx
  40bbe2:	mov    r8d,0x3f
  40bbe8:	sub    r8d,edx
  40bbeb:	lea    edx,[r8-0x2]
  40bbef:	shrx   rcx,rcx,rdx
  40bbf4:	and    ecx,0x3
  40bbf7:	lea    edx,[r8-0x7]
  40bbfb:	lea    edx,[rdx*4+0x0]
  40bc02:	lea    edx,[rdx+0x9]
  40bc05:	add    edx,ecx
  40bc07:	mov    DWORD PTR [rsp+0x8],edx
  40bc0b:	cmp    DWORD PTR [rax],0x0
  40bc0e:	jne    40bc1e <__swc_fn_0a4ed24b_000064_b0d63361+0x10e>
  40bc10:	cmp    DWORD PTR [rbx+0x58],0x8
  40bc14:	jbe    40bc1e <__swc_fn_0a4ed24b_000064_b0d63361+0x10e>
  40bc16:	mov    DWORD PTR [rsp+0x8],0x1
  40bc1e:	cmp    DWORD PTR [rbx+0x58],0x10
  40bc22:	jbe    40bca1 <__swc_fn_0a4ed24b_000064_b0d63361+0x191>
  40bc28:	cmp    DWORD PTR [rbx+0x58],0x40
  40bc2c:	ja     40bca1 <__swc_fn_0a4ed24b_000064_b0d63361+0x191>
  40bc2e:	cmp    DWORD PTR [rax],0xffffffff
  40bc31:	je     40bca1 <__swc_fn_0a4ed24b_000064_b0d63361+0x191>
  40bc33:	mov    ecx,DWORD PTR [rsp+0x8]
  40bc37:	mov    edx,DWORD PTR [rbx+0x58]
  40bc3a:	dec    rdx
  40bc3d:	cmp    ecx,0x2d
  40bc40:	jae    40bc98 <__swc_fn_0a4ed24b_000064_b0d63361+0x188>
  40bc42:	cs nop WORD PTR [rax+rax*1+0x0]
  40bc4c:	nop    DWORD PTR [rax+0x0]
  40bc50:	mov    r8d,ecx
  40bc53:	test   ecx,ecx
  40bc55:	jne    40bc5f <__swc_fn_0a4ed24b_000064_b0d63361+0x14f>
  40bc57:	mov    r8d,0x8
  40bc5d:	jmp    40bc8b <__swc_fn_0a4ed24b_000064_b0d63361+0x17b>
  40bc5f:	cmp    r8d,0x8
  40bc63:	ja     40bc6b <__swc_fn_0a4ed24b_000064_b0d63361+0x15b>
  40bc65:	shl    r8,0x4
  40bc69:	jmp    40bc8b <__swc_fn_0a4ed24b_000064_b0d63361+0x17b>
  40bc6b:	lea    r8d,[r8-0x9]
  40bc6f:	mov    r9d,r8d
  40bc72:	shr    r9d,0x2
  40bc76:	and    r8d,0x3
  40bc7a:	lea    r9d,[r9+0x7]
  40bc7e:	lea    r9d,[r9-0x2]
  40bc82:	lea    r8d,[r8+0x5]
  40bc86:	shlx   r8,r8,r9
  40bc8b:	test   r8,rdx
  40bc8e:	je     40bc9d <__swc_fn_0a4ed24b_000064_b0d63361+0x18d>
  40bc90:	add    ecx,0x1
  40bc93:	cmp    ecx,0x2d
  40bc96:	jb     40bc50 <__swc_fn_0a4ed24b_000064_b0d63361+0x140>
  40bc98:	mov    ecx,0xffffffff
  40bc9d:	mov    DWORD PTR [rsp+0x8],ecx
  40bca1:	mov    ecx,DWORD PTR [rsp+0x8]
  40bca5:	cmp    ecx,0xffffffff
  40bca8:	je     40bcb0 <__swc_fn_0a4ed24b_000064_b0d63361+0x1a0>
  40bcaa:	cmp    DWORD PTR [rbx+0x58],0x40
  40bcae:	jbe    40bcc3 <__swc_fn_0a4ed24b_000064_b0d63361+0x1b3>
  40bcb0:	mov    rcx,r12
  40bcb3:	mov    rdx,rbx
  40bcb6:	mov    r8d,DWORD PTR [rax]
  40bcb9:	call   40b5c0 <__swc_fn_0a4ed24b_000061_0a7f67d9>
  40bcbe:	jmp    40bd97 <__swc_fn_0a4ed24b_000064_b0d63361+0x287>
  40bcc3:	lea    rax,[rip+0x16336]        # 422000 <__swc_data_base_0a4ed24b>
  40bcca:	mov    rax,QWORD PTR [rax]
  40bccd:	cmp    rax,0xffffffffffffffff
  40bcd1:	je     40bce0 <__swc_fn_0a4ed24b_000064_b0d63361+0x1d0>
  40bcd3:	mov    eax,eax
  40bcd5:	mov    edi,eax
  40bcd7:	xor    eax,eax
  40bcd9:	call   407000 <pthread_getspecific@plt>
  40bcde:	jmp    40bce2 <__swc_fn_0a4ed24b_000064_b0d63361+0x1d2>
  40bce0:	xor    eax,eax
  40bce2:	test   rax,rax
  40bce5:	jne    40bcf4 <__swc_fn_0a4ed24b_000064_b0d63361+0x1e4>
  40bce7:	call   40ac60 <__swc_fn_0a4ed24b_000031_90860ff2>
  40bcec:	mov    rcx,rax
  40bcef:	call   410280 <__swc_fn_0a4ed24b_000128_41c3251c>
  40bcf4:	test   rax,rax
  40bcf7:	je     40bd04 <__swc_fn_0a4ed24b_000064_b0d63361+0x1f4>
  40bcf9:	cmp    QWORD PTR [rax],r12
  40bcfc:	jne    40bd04 <__swc_fn_0a4ed24b_000064_b0d63361+0x1f4>
  40bcfe:	cmp    DWORD PTR [rax+0x20],0x0
  40bd02:	je     40bd0f <__swc_fn_0a4ed24b_000064_b0d63361+0x1ff>
  40bd04:	mov    rcx,r12
  40bd07:	mov    rdx,rax
  40bd0a:	call   40e1b0 <__swc_fn_0a4ed24b_000041_414cc921>
  40bd0f:	test   rax,rax
  40bd12:	jne    40bd1e <__swc_fn_0a4ed24b_000064_b0d63361+0x20e>
  40bd14:	mov    QWORD PTR [rbx+0x40],0x0
  40bd1c:	jmp    40bd97 <__swc_fn_0a4ed24b_000064_b0d63361+0x287>
  40bd1e:	lea    r8,[rsp+0xc]
  40bd23:	mov    ecx,DWORD PTR [rsp+0x8]
  40bd27:	mov    DWORD PTR [rsp+0xc],ecx
  40bd2b:	mov    ecx,DWORD PTR [r8]
  40bd2e:	lea    rcx,[rcx+rcx*4]
  40bd32:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40bd37:	test   rcx,rcx
  40bd3a:	je     40bd73 <__swc_fn_0a4ed24b_000064_b0d63361+0x263>
  40bd3c:	mov    rdx,QWORD PTR [rcx]
  40bd3f:	test   rdx,rdx
  40bd42:	je     40bd50 <__swc_fn_0a4ed24b_000064_b0d63361+0x240>
  40bd44:	mov    r9,QWORD PTR [rdx]
  40bd47:	mov    QWORD PTR [rcx],r9
  40bd4a:	add    DWORD PTR [rcx+0x28],0x1
  40bd4e:	jmp    40bd6e <__swc_fn_0a4ed24b_000064_b0d63361+0x25e>
  40bd50:	mov    rdx,QWORD PTR [rcx+0x18]
  40bd54:	cmp    QWORD PTR [rcx+0x20],rdx
  40bd58:	jae    40bd6c <__swc_fn_0a4ed24b_000064_b0d63361+0x25c>
  40bd5a:	mov    rdx,QWORD PTR [rcx+0x20]
  40bd5e:	mov    r9d,DWORD PTR [rcx+0x2c]
  40bd62:	add    QWORD PTR [rcx+0x20],r9
  40bd66:	add    DWORD PTR [rcx+0x28],0x1
  40bd6a:	jmp    40bd6e <__swc_fn_0a4ed24b_000064_b0d63361+0x25e>
  40bd6c:	xor    edx,edx
  40bd6e:	test   rdx,rdx
  40bd71:	jne    40bd84 <__swc_fn_0a4ed24b_000064_b0d63361+0x274>
  40bd73:	mov    rcx,r12
  40bd76:	mov    rdx,rax
  40bd79:	mov    r8d,DWORD PTR [r8]
  40bd7c:	call   40e320 <__swc_fn_0a4ed24b_000050_ab8077df>
  40bd81:	mov    rdx,rax
  40bd84:	test   rdx,rdx
  40bd87:	jne    40bd93 <__swc_fn_0a4ed24b_000064_b0d63361+0x283>
  40bd89:	mov    QWORD PTR [rbx+0x40],0x0
  40bd91:	jmp    40bd97 <__swc_fn_0a4ed24b_000064_b0d63361+0x287>
  40bd93:	mov    QWORD PTR [rbx+0x40],rdx
  40bd97:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40bd9d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40bda3:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40bda9:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40bdaf:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40bdb5:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40bdbb:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40bdc1:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40bdca:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40bdd3:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40bddc:	add    rsp,0xb8
  40bde3:	pop    rsi
  40bde4:	pop    rdi
  40bde5:	pop    r12
  40bde7:	pop    rbx
  40bde8:	ret
  40bde9:	add    BYTE PTR [rax],al
  40bdeb:	add    BYTE PTR [rax],al
  40bded:	add    BYTE PTR [rax],al
	...

000000000040bdf0 <__swc_fn_0a4ed24b_000067_94a51053>:
  40bdf0:	ret
	...

000000000040be00 <__swc_fn_0a4ed24b_000070_3181d86c>:
  40be00:	push   r12
  40be02:	push   r13
  40be04:	push   r14
  40be06:	push   rdi
  40be07:	push   rsi
  40be08:	sub    rsp,0x1a0
  40be0f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40be18:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40be21:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40be2a:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40be33:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40be3c:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40be45:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40be4e:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40be57:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40be60:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40be69:	mov    r12,rdx
  40be6c:	mov    r13,rcx
  40be6f:	mov    rax,QWORD PTR [r12+0x48]
  40be74:	mov    ecx,DWORD PTR [r12+0x58]
  40be79:	lea    rdx,[rax-0x1]
  40be7d:	cmp    rdx,0x10000
  40be84:	jae    40bf7e <__swc_fn_0a4ed24b_000070_3181d86c+0x17e>
  40be8a:	cmp    rax,0x8
  40be8e:	ja     40be95 <__swc_fn_0a4ed24b_000070_3181d86c+0x95>
  40be90:	xor    r14d,r14d
  40be93:	jmp    40bee7 <__swc_fn_0a4ed24b_000070_3181d86c+0xe7>
  40be95:	cmp    rax,0x80
  40be9c:	ja     40bea8 <__swc_fn_0a4ed24b_000070_3181d86c+0xa8>
  40be9e:	lea    r14,[rax+0xf]
  40bea2:	shr    r14,0x4
  40bea6:	jmp    40bee7 <__swc_fn_0a4ed24b_000070_3181d86c+0xe7>
  40bea8:	cmp    rax,0x10000
  40beaf:	jbe    40beb9 <__swc_fn_0a4ed24b_000070_3181d86c+0xb9>
  40beb1:	mov    r14d,0xffffffff
  40beb7:	jmp    40bee7 <__swc_fn_0a4ed24b_000070_3181d86c+0xe7>
  40beb9:	xor    eax,eax
  40bebb:	lzcnt  rax,rdx
  40bec0:	mov    r8d,0x3f
  40bec6:	sub    r8d,eax
  40bec9:	lea    eax,[r8-0x2]
  40becd:	shrx   rax,rdx,rax
  40bed2:	and    eax,0x3
  40bed5:	lea    edx,[r8-0x7]
  40bed9:	lea    edx,[rdx*4+0x0]
  40bee0:	lea    edx,[rdx+0x9]
  40bee3:	lea    r14d,[rdx+rax*1]
  40bee7:	cmp    ecx,0x8
  40beea:	jbe    40bf03 <__swc_fn_0a4ed24b_000070_3181d86c+0x103>
  40beec:	cmp    ecx,0x10
  40beef:	jne    40bf7e <__swc_fn_0a4ed24b_000070_3181d86c+0x17e>
  40bef5:	test   r14d,r14d
  40bef8:	mov    eax,0x1
  40befd:	cmove  r14d,eax
  40bf01:	jmp    40bf0a <__swc_fn_0a4ed24b_000070_3181d86c+0x10a>
  40bf03:	lea    eax,[rcx-0x1]
  40bf06:	test   eax,ecx
  40bf08:	jne    40bf7e <__swc_fn_0a4ed24b_000070_3181d86c+0x17e>
  40bf0a:	lea    rax,[rip+0x160ef]        # 422000 <__swc_data_base_0a4ed24b>
  40bf11:	mov    rax,QWORD PTR [rax]
  40bf14:	cmp    rax,0xffffffffffffffff
  40bf18:	je     40bf27 <__swc_fn_0a4ed24b_000070_3181d86c+0x127>
  40bf1a:	mov    eax,eax
  40bf1c:	mov    edi,eax
  40bf1e:	xor    eax,eax
  40bf20:	call   407000 <pthread_getspecific@plt>
  40bf25:	jmp    40bf29 <__swc_fn_0a4ed24b_000070_3181d86c+0x129>
  40bf27:	xor    eax,eax
  40bf29:	test   rax,rax
  40bf2c:	je     40bf7e <__swc_fn_0a4ed24b_000070_3181d86c+0x17e>
  40bf2e:	cmp    QWORD PTR [rax],r13
  40bf31:	jne    40bf7e <__swc_fn_0a4ed24b_000070_3181d86c+0x17e>
  40bf33:	lea    rcx,[r14+r14*4]
  40bf37:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40bf3c:	test   rax,rax
  40bf3f:	je     40bf7e <__swc_fn_0a4ed24b_000070_3181d86c+0x17e>
  40bf41:	mov    rcx,QWORD PTR [rax]
  40bf44:	test   rcx,rcx
  40bf47:	je     40bf55 <__swc_fn_0a4ed24b_000070_3181d86c+0x155>
  40bf49:	mov    rdx,QWORD PTR [rcx]
  40bf4c:	mov    QWORD PTR [rax],rdx
  40bf4f:	add    DWORD PTR [rax+0x28],0x1
  40bf53:	jmp    40bf72 <__swc_fn_0a4ed24b_000070_3181d86c+0x172>
  40bf55:	mov    rcx,QWORD PTR [rax+0x18]
  40bf59:	cmp    QWORD PTR [rax+0x20],rcx
  40bf5d:	jae    40bf70 <__swc_fn_0a4ed24b_000070_3181d86c+0x170>
  40bf5f:	mov    rcx,QWORD PTR [rax+0x20]
  40bf63:	mov    edx,DWORD PTR [rax+0x2c]
  40bf66:	add    QWORD PTR [rax+0x20],rdx
  40bf6a:	add    DWORD PTR [rax+0x28],0x1
  40bf6e:	jmp    40bf72 <__swc_fn_0a4ed24b_000070_3181d86c+0x172>
  40bf70:	xor    ecx,ecx
  40bf72:	test   rcx,rcx
  40bf75:	je     40bf7e <__swc_fn_0a4ed24b_000070_3181d86c+0x17e>
  40bf77:	mov    QWORD PTR [r12+0x40],rcx
  40bf7c:	jmp    40bf89 <__swc_fn_0a4ed24b_000070_3181d86c+0x189>
  40bf7e:	mov    rcx,r13
  40bf81:	mov    rdx,r12
  40bf84:	call   40eda0 <__swc_fn_0a4ed24b_000071_0d1ef36f>
  40bf89:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40bf92:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40bf9b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40bfa4:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40bfad:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40bfb6:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40bfbf:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40bfc8:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40bfd1:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40bfda:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40bfe3:	add    rsp,0x1a0
  40bfea:	pop    rsi
  40bfeb:	pop    rdi
  40bfec:	pop    r14
  40bfee:	pop    r13
  40bff0:	pop    r12
  40bff2:	ret
	...

000000000040c000 <__swc_fn_0a4ed24b_000073_c6c71bf7>:
  40c000:	push   r12
  40c002:	push   r13
  40c004:	push   r14
  40c006:	push   r15
  40c008:	push   rdi
  40c009:	push   rsi
  40c00a:	sub    rsp,0x188
  40c011:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40c01a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40c023:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40c02c:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40c035:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40c03e:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40c047:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40c050:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40c059:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40c062:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40c06b:	mov    r12,rdx
  40c06e:	mov    r13,rcx
  40c071:	mov    r14,QWORD PTR [r12+0x40]
  40c076:	lea    rax,[rip+0x17ff3]        # 424070 <__swc_bss_base_0a4ed24b+0x30>
  40c07d:	mov    rcx,r14
  40c080:	sub    rcx,QWORD PTR [rax+0x8]
  40c084:	mov    rax,QWORD PTR [rip+0x17ff5]        # 424080 <__swc_bss_base_0a4ed24b+0x40>
  40c08b:	cmp    rcx,rax
  40c08e:	jae    40c0ba <__swc_fn_0a4ed24b_000073_c6c71bf7+0xba>
  40c090:	mov    rax,r14
  40c093:	and    rax,0xffffffffffc00000
  40c09a:	mov    rcx,r14
  40c09d:	shr    rcx,0x10
  40c0a1:	and    ecx,0x3f
  40c0a4:	mov    edx,DWORD PTR [rax+0x28]
  40c0a7:	shrx   ecx,ecx,edx
  40c0ac:	shl    rcx,0x4
  40c0b0:	lea    r15,[rax+rcx*8+0x80]
  40c0b8:	jmp    40c0c5 <__swc_fn_0a4ed24b_000073_c6c71bf7+0xc5>
  40c0ba:	mov    rcx,r14
  40c0bd:	call   40ab90 <__swc_fn_0a4ed24b_000022_3a2e2048>
  40c0c2:	mov    r15,rax
  40c0c5:	test   r15,r15
  40c0c8:	je     40c16f <__swc_fn_0a4ed24b_000073_c6c71bf7+0x16f>
  40c0ce:	lea    rax,[rip+0x15f2b]        # 422000 <__swc_data_base_0a4ed24b>
  40c0d5:	mov    rax,QWORD PTR [rax]
  40c0d8:	cmp    rax,0xffffffffffffffff
  40c0dc:	je     40c0eb <__swc_fn_0a4ed24b_000073_c6c71bf7+0xeb>
  40c0de:	mov    eax,eax
  40c0e0:	mov    edi,eax
  40c0e2:	xor    eax,eax
  40c0e4:	call   407000 <pthread_getspecific@plt>
  40c0e9:	jmp    40c0ed <__swc_fn_0a4ed24b_000073_c6c71bf7+0xed>
  40c0eb:	xor    eax,eax
  40c0ed:	mov    rcx,QWORD PTR [r15+0x40]
  40c0f1:	cmp    rcx,rax
  40c0f4:	jne    40c154 <__swc_fn_0a4ed24b_000073_c6c71bf7+0x154>
  40c0f6:	test   rax,rax
  40c0f9:	je     40c16f <__swc_fn_0a4ed24b_000073_c6c71bf7+0x16f>
  40c0fb:	mov    ecx,DWORD PTR [r15+0x6c]
  40c0ff:	test   ecx,ecx
  40c101:	je     40c121 <__swc_fn_0a4ed24b_000073_c6c71bf7+0x121>
  40c103:	mov    rcx,r13
  40c106:	mov    rdx,rax
  40c109:	mov    r8,r15
  40c10c:	mov    QWORD PTR [rsp+0xd8],rax
  40c114:	call   40e2b0 <__swc_fn_0a4ed24b_000047_bc5ec610>
  40c119:	mov    rax,QWORD PTR [rsp+0xd8]
  40c121:	mov    rcx,QWORD PTR [r15]
  40c124:	mov    QWORD PTR [r14],rcx
  40c127:	mov    QWORD PTR [r15],r14
  40c12a:	sub    DWORD PTR [r15+0x28],0x1
  40c12f:	jne    40c164 <__swc_fn_0a4ed24b_000073_c6c71bf7+0x164>
  40c131:	movzx  ecx,BYTE PTR [r15+0x39]
  40c136:	lea    rcx,[rcx+rcx*4]
  40c13a:	lea    rcx,[rax+rcx*8+0x28]
  40c13f:	cmp    QWORD PTR [rcx],r15
  40c142:	je     40c164 <__swc_fn_0a4ed24b_000073_c6c71bf7+0x164>
  40c144:	mov    rcx,r13
  40c147:	mov    rdx,rax
  40c14a:	mov    r8,r15
  40c14d:	call   407d80 <__swc_fn_0a4ed24b_000051_f7021588>
  40c152:	jmp    40c164 <__swc_fn_0a4ed24b_000073_c6c71bf7+0x164>
  40c154:	test   rcx,rcx
  40c157:	je     40c16f <__swc_fn_0a4ed24b_000073_c6c71bf7+0x16f>
  40c159:	mov    rcx,r15
  40c15c:	mov    rdx,r14
  40c15f:	call   40a7d0 <__swc_fn_0a4ed24b_000010_395bb04b>
  40c164:	mov    QWORD PTR [r12+0x40],0x0
  40c16d:	jmp    40c17a <__swc_fn_0a4ed24b_000073_c6c71bf7+0x17a>
  40c16f:	mov    rcx,r13
  40c172:	mov    rdx,r12
  40c175:	call   40edc0 <__swc_fn_0a4ed24b_000074_518516c2>
  40c17a:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40c183:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40c18c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40c195:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40c19e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40c1a7:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40c1b0:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40c1b9:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40c1c2:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40c1cb:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40c1d4:	add    rsp,0x188
  40c1db:	pop    rsi
  40c1dc:	pop    rdi
  40c1dd:	pop    r15
  40c1df:	pop    r14
  40c1e1:	pop    r13
  40c1e3:	pop    r12
  40c1e5:	ret
	...

000000000040c1f0 <__swc_fn_0a4ed24b_000076_9f0c6acf>:
  40c1f0:	sub    rsp,0x8
  40c1f4:	mov    rax,rdx
  40c1f7:	mov    rdx,QWORD PTR [rax+0x40]
  40c1fb:	mov    r8,rax
  40c1fe:	call   40bdf0 <__swc_fn_0a4ed24b_000067_94a51053>
  40c203:	add    rsp,0x8
  40c207:	ret
	...

000000000040c210 <__swc_fn_0a4ed24b_000079_34776ded>:
  40c210:	push   rsi
  40c211:	push   rdi
  40c212:	sub    rsp,0x8
  40c216:	cmp    rcx,0xffffffffffffffef
  40c21a:	ja     40c240 <__swc_fn_0a4ed24b_000079_34776ded+0x30>
  40c21c:	xor    esi,esi
  40c21e:	lea    rax,[rcx+0x100f]
  40c225:	and    rax,0xfffffffffffff000
  40c22c:	lea    rcx,[rcx+0x10]
  40c230:	cmp    rcx,0xfffffffffffff000
  40c237:	cmovbe rsi,rax
  40c23b:	test   rsi,rsi
  40c23e:	jne    40c249 <__swc_fn_0a4ed24b_000079_34776ded+0x39>
  40c240:	xor    eax,eax
  40c242:	add    rsp,0x8
  40c246:	pop    rdi
  40c247:	pop    rsi
  40c248:	ret
  40c249:	mov    rcx,rsi
  40c24c:	call   40c8a0 <__swc_fn_0a4ed24b_000109_8d425bd3>
  40c251:	mov    rdi,rax
  40c254:	test   rax,rax
  40c257:	jne    40c262 <__swc_fn_0a4ed24b_000079_34776ded+0x52>
  40c259:	xor    eax,eax
  40c25b:	add    rsp,0x8
  40c25f:	pop    rdi
  40c260:	pop    rsi
  40c261:	ret
  40c262:	mov    rcx,rdi
  40c265:	mov    rdx,rsi
  40c268:	call   409260 <__swc_fn_0a4ed24b_000111_b25e3a45>
  40c26d:	test   al,al
  40c26f:	jne    40c285 <__swc_fn_0a4ed24b_000079_34776ded+0x75>
  40c271:	mov    rcx,rdi
  40c274:	mov    rdx,rsi
  40c277:	call   40ff20 <__swc_fn_0a4ed24b_000113_49b378a9>
  40c27c:	xor    eax,eax
  40c27e:	add    rsp,0x8
  40c282:	pop    rdi
  40c283:	pop    rsi
  40c284:	ret
  40c285:	mov    QWORD PTR [rdi],rsi
  40c288:	mov    QWORD PTR [rdi+0x8],0x0
  40c290:	lea    rax,[rdi+0x10]
  40c294:	add    rsp,0x8
  40c298:	pop    rdi
  40c299:	pop    rsi
  40c29a:	ret
  40c29b:	add    BYTE PTR [rax],al
  40c29d:	add    BYTE PTR [rax],al
	...

000000000040c2a0 <__swc_fn_0a4ed24b_000082_754dcd57>:
  40c2a0:	sub    rsp,0x8
  40c2a4:	cmp    BYTE PTR [rcx+0x2c],0x10
  40c2a8:	jne    40c2b3 <__swc_fn_0a4ed24b_000082_754dcd57+0x13>
  40c2aa:	test   DWORD PTR [rcx+0x28],0x80
  40c2b1:	je     40c2bb <__swc_fn_0a4ed24b_000082_754dcd57+0x1b>
  40c2b3:	mov    rax,rcx
  40c2b6:	add    rsp,0x8
  40c2ba:	ret
  40c2bb:	mov    rcx,QWORD PTR [rcx+0x40]
  40c2bf:	call   40c2a0 <__swc_fn_0a4ed24b_000082_754dcd57>
  40c2c4:	add    rsp,0x8
  40c2c8:	ret
	...

000000000040c2e0 <__swc_fn_0a4ed24b_000085_1edf7c76>:
  40c2e0:	push   rsi
  40c2e1:	push   rdi
  40c2e2:	push   r12
  40c2e4:	push   r13
  40c2e6:	sub    rsp,0x8
  40c2ea:	mov    rsi,rdx
  40c2ed:	mov    rdi,rcx
  40c2f0:	xor    r8d,r8d
  40c2f3:	call   4085a0 <__swc_fn_0a4ed24b_000090_a2d50c23>
  40c2f8:	test   al,al
  40c2fa:	je     40c30c <__swc_fn_0a4ed24b_000085_1edf7c76+0x2c>
  40c2fc:	mov    eax,0x1
  40c301:	add    rsp,0x8
  40c305:	pop    r13
  40c307:	pop    r12
  40c309:	pop    rdi
  40c30a:	pop    rsi
  40c30b:	ret
  40c30c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40c311:	je     40c320 <__swc_fn_0a4ed24b_000085_1edf7c76+0x40>
  40c313:	xor    eax,eax
  40c315:	add    rsp,0x8
  40c319:	pop    r13
  40c31b:	pop    r12
  40c31d:	pop    rdi
  40c31e:	pop    rsi
  40c31f:	ret
  40c320:	mov    r12,QWORD PTR [rsi+0x98]
  40c327:	mov    rax,QWORD PTR [rsi+0xa0]
  40c32e:	mov    rsi,rax
  40c331:	xor    r13d,r13d
  40c334:	test   rsi,rsi
  40c337:	je     40c394 <__swc_fn_0a4ed24b_000085_1edf7c76+0xb4>
  40c339:	cs nop WORD PTR [rax+rax*1+0x0]
  40c343:	cs nop WORD PTR [rax+rax*1+0x0]
  40c34d:	nop    DWORD PTR [rax]
  40c350:	lea    rax,[r13*8+0x0]
  40c358:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40c35d:	mov    rcx,rax
  40c360:	call   40c2a0 <__swc_fn_0a4ed24b_000082_754dcd57>
  40c365:	cmp    BYTE PTR [rax+0x2c],0xe
  40c369:	jne    40c38a <__swc_fn_0a4ed24b_000085_1edf7c76+0xaa>
  40c36b:	mov    rcx,rdi
  40c36e:	mov    rdx,rax
  40c371:	call   40c2e0 <__swc_fn_0a4ed24b_000085_1edf7c76>
  40c376:	test   al,al
  40c378:	je     40c38a <__swc_fn_0a4ed24b_000085_1edf7c76+0xaa>
  40c37a:	mov    eax,0x1
  40c37f:	add    rsp,0x8
  40c383:	pop    r13
  40c385:	pop    r12
  40c387:	pop    rdi
  40c388:	pop    rsi
  40c389:	ret
  40c38a:	add    r13,0x1
  40c38e:	sub    rsi,0x1
  40c392:	jne    40c350 <__swc_fn_0a4ed24b_000085_1edf7c76+0x70>
  40c394:	xor    eax,eax
  40c396:	add    rsp,0x8
  40c39a:	pop    r13
  40c39c:	pop    r12
  40c39e:	pop    rdi
  40c39f:	pop    rsi
  40c3a0:	ret
	...

000000000040c3b0 <__swc_fn_0a4ed24b_000088_fcb34f6a>:
  40c3b0:	sub    rsp,0x18
  40c3b4:	vxorps xmm0,xmm0,xmm0
  40c3b8:	vmovdqu XMMWORD PTR [rsp],xmm0
  40c3bd:	call   40efd0 <__swc_fn_0a4ed24b_000089_386582f3>
  40c3c2:	add    rsp,0x18
  40c3c6:	ret
	...

000000000040c3d0 <__swc_fn_0a4ed24b_000091_3d2f5a0d>:
  40c3d0:	sub    rsp,0x8
  40c3d4:	mov    rcx,QWORD PTR [rip+0x1a965]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40c3db:	test   rcx,rcx
  40c3de:	jne    40c3f0 <__swc_fn_0a4ed24b_000091_3d2f5a0d+0x20>
  40c3e0:	call   40a1d0 <__swc_fn_0a4ed24b_000165_cf398896>
  40c3e5:	lea    rcx,[rax+0x1]
  40c3e9:	mov    QWORD PTR [rip+0x1a950],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40c3f0:	dec    rcx
  40c3f3:	call   411d40 <__swc_fn_0a4ed24b_000167_fce60b2b>
  40c3f8:	mov    rax,QWORD PTR [rax+0xc0]
  40c3ff:	and    eax,0x1
  40c402:	setne  al
  40c405:	add    rsp,0x8
  40c409:	ret
	...

000000000040c420 <__swc_fn_0a4ed24b_000094_14db3cf9>:
  40c420:	push   rbx
  40c421:	push   rsi
  40c422:	push   rdi
  40c423:	push   r12
  40c425:	sub    rsp,0x28
  40c429:	mov    rbx,rcx
  40c42c:	call   408900 <__swc_fn_0a4ed24b_000093_f8c16535>
  40c431:	mov    rcx,QWORD PTR [rip+0x1a908]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40c438:	test   rcx,rcx
  40c43b:	jne    40c44d <__swc_fn_0a4ed24b_000094_14db3cf9+0x2d>
  40c43d:	call   40a1d0 <__swc_fn_0a4ed24b_000165_cf398896>
  40c442:	lea    rcx,[rax+0x1]
  40c446:	mov    QWORD PTR [rip+0x1a8f3],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40c44d:	dec    rcx
  40c450:	call   411d40 <__swc_fn_0a4ed24b_000167_fce60b2b>
  40c455:	mov    rsi,rax
  40c458:	lea    rcx,[rsp+0x8]
  40c45d:	call   40f410 <__swc_fn_0a4ed24b_000092_8252f8c0>
  40c462:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40c469:	mov    r12,QWORD PTR [rsi+0xbe8]
  40c470:	lea    rcx,[rsi+0x10]
  40c474:	call   40d400 <__swc_fn_0a4ed24b_000157_232ffa22>
  40c479:	mov    rcx,rsi
  40c47c:	call   40f580 <__swc_fn_0a4ed24b_000101_eab3874f>
  40c481:	vxorps xmm0,xmm0,xmm0
  40c485:	xor    eax,eax
  40c487:	cs nop WORD PTR [rax+rax*1+0x0]
  40c491:	cs nop WORD PTR [rax+rax*1+0x0]
  40c49b:	nop    DWORD PTR [rax+rax*1+0x0]
  40c4a0:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40c4a5:	add    rax,0x10
  40c4a9:	cmp    rax,0xbf0
  40c4b0:	jne    40c4a0 <__swc_fn_0a4ed24b_000094_14db3cf9+0x80>
  40c4b2:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c4b8:	vmovups XMMWORD PTR [rsi],xmm0
  40c4bc:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c4c2:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40c4ca:	mov    QWORD PTR [rsi+0x9c0],rdi
  40c4d1:	mov    QWORD PTR [rsi+0xbe8],r12
  40c4d8:	mov    rcx,QWORD PTR [rip+0x1a861]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40c4df:	test   rcx,rcx
  40c4e2:	jne    40c4f4 <__swc_fn_0a4ed24b_000094_14db3cf9+0xd4>
  40c4e4:	call   40a1d0 <__swc_fn_0a4ed24b_000165_cf398896>
  40c4e9:	lea    rcx,[rax+0x1]
  40c4ed:	mov    QWORD PTR [rip+0x1a84c],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40c4f4:	dec    rcx
  40c4f7:	call   411d40 <__swc_fn_0a4ed24b_000167_fce60b2b>
  40c4fc:	mov    rsi,rax
  40c4ff:	mov    QWORD PTR [rsi+0xc0],rbx
  40c506:	and    ebx,0x1
  40c509:	jne    40c50d <__swc_fn_0a4ed24b_000094_14db3cf9+0xed>
  40c50b:	xor    eax,eax
  40c50d:	test   rbx,rbx
  40c510:	sete   al
  40c513:	xor    cl,cl
  40c515:	xor    dl,dl
  40c517:	xor    r8b,r8b
  40c51a:	xor    r9b,r9b
  40c51d:	xor    r10b,r10b
  40c520:	mov    r11,rax
  40c523:	call   40edd0 <__swc_fn_0a4ed24b_000077_8b8614a7>
  40c528:	lea    rbx,[rsp+0x18]
  40c52d:	mov    rcx,rbx
  40c530:	call   40f410 <__swc_fn_0a4ed24b_000092_8252f8c0>
  40c535:	lea    rcx,[rsi+0x10]
  40c539:	mov    edx,0x400000
  40c53e:	mov    r8,rbx
  40c541:	call   409f10 <__swc_fn_0a4ed24b_000159_d8afac28>
  40c546:	lea    rcx,[rsi+0x68]
  40c54a:	mov    edx,0x4000
  40c54f:	mov    r8,rbx
  40c552:	call   409f10 <__swc_fn_0a4ed24b_000159_d8afac28>
  40c557:	add    rsp,0x28
  40c55b:	pop    r12
  40c55d:	pop    rdi
  40c55e:	pop    rsi
  40c55f:	pop    rbx
  40c560:	ret
	...

000000000040c570 <__swc_fn_0a4ed24b_000097_4c97e0db>:
  40c570:	push   rbx
  40c571:	push   rsi
  40c572:	sub    rsp,0x18
  40c576:	mov    rbx,rcx
  40c579:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40c57e:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c584:	mov    rsi,QWORD PTR [rbx+0x70]
  40c588:	lea    rcx,[rcx+0x18]
  40c58c:	call   40d400 <__swc_fn_0a4ed24b_000157_232ffa22>
  40c591:	lea    rcx,[rsp+0x8]
  40c596:	mov    rdx,rbx
  40c599:	mov    r8d,0x78
  40c59f:	call   408960 <__swc_fn_0a4ed24b_000096_ad982b35>
  40c5a4:	mov    rax,rsi
  40c5a7:	add    rsp,0x18
  40c5ab:	pop    rsi
  40c5ac:	pop    rbx
  40c5ad:	ret
	...

000000000040c5b0 <__swc_fn_0a4ed24b_000100_3ed08774>:
  40c5b0:	push   rsi
  40c5b1:	push   rdi
  40c5b2:	sub    rsp,0x8
  40c5b6:	cmp    QWORD PTR [rcx],0x0
  40c5ba:	jne    40c5c3 <__swc_fn_0a4ed24b_000100_3ed08774+0x13>
  40c5bc:	add    rsp,0x8
  40c5c0:	pop    rdi
  40c5c1:	pop    rsi
  40c5c2:	ret
  40c5c3:	mov    rsi,QWORD PTR [rcx]
  40c5c6:	mov    rax,QWORD PTR [rcx+0x8]
  40c5ca:	test   rax,rax
  40c5cd:	je     40c5e3 <__swc_fn_0a4ed24b_000100_3ed08774+0x33>
  40c5cf:	test   DWORD PTR [rax+0x28],0x400000
  40c5d6:	je     40c5e3 <__swc_fn_0a4ed24b_000100_3ed08774+0x33>
  40c5d8:	mov    rcx,QWORD PTR [rax+0x30]
  40c5dc:	test   rcx,rcx
  40c5df:	cmovne rax,rcx
  40c5e3:	lea    rdx,[rip+0x6be6]        # 4131d0 <__swc_rdata_base_0a4ed24b+0xc0>
  40c5ea:	lea    rcx,[rip+0x6cc7]        # 4132b8 <__swc_rdata_base_0a4ed24b+0x1a8>
  40c5f1:	mov    r8,rax
  40c5f4:	xor    r9d,r9d
  40c5f7:	xor    al,al
  40c5f9:	mov    r10,rax
  40c5fc:	xor    r11d,r11d
  40c5ff:	call   40c3b0 <__swc_fn_0a4ed24b_000088_fcb34f6a>
  40c604:	test   rax,rax
  40c607:	je     40c617 <__swc_fn_0a4ed24b_000100_3ed08774+0x67>
  40c609:	mov    rdi,QWORD PTR [rax+0x48]
  40c60d:	test   rdi,rdi
  40c610:	je     40c617 <__swc_fn_0a4ed24b_000100_3ed08774+0x67>
  40c612:	mov    rcx,rsi
  40c615:	call   rdi
  40c617:	add    rsp,0x8
  40c61b:	pop    rdi
  40c61c:	pop    rsi
  40c61d:	ret
	...

000000000040c620 <__swc_fn_0a4ed24b_000103_67100064>:
  40c620:	push   rbx
  40c621:	push   rsi
  40c622:	push   rdi
  40c623:	sub    rsp,0x20
  40c627:	mov    rbx,rdx
  40c62a:	mov    rsi,rcx
  40c62d:	mov    rcx,QWORD PTR [rip+0x1a70c]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40c634:	test   rcx,rcx
  40c637:	jne    40c649 <__swc_fn_0a4ed24b_000103_67100064+0x29>
  40c639:	call   40a1d0 <__swc_fn_0a4ed24b_000165_cf398896>
  40c63e:	lea    rcx,[rax+0x1]
  40c642:	mov    QWORD PTR [rip+0x1a6f7],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40c649:	dec    rcx
  40c64c:	call   411d40 <__swc_fn_0a4ed24b_000167_fce60b2b>
  40c651:	mov    rdi,rax
  40c654:	mov    rax,QWORD PTR [rdi+0xbd0]
  40c65b:	xor    ecx,ecx
  40c65d:	test   rax,rax
  40c660:	je     40c665 <__swc_fn_0a4ed24b_000103_67100064+0x45>
  40c662:	mov    rcx,QWORD PTR [rax]
  40c665:	call   40a300 <__swc_fn_0a4ed24b_000174_176517f9>
  40c66a:	lea    rax,[rsp+0x8]
  40c66f:	lea    rcx,[rdi+0x9c8]
  40c676:	mov    QWORD PTR [rsp+0x8],rcx
  40c67b:	mov    QWORD PTR [rax+0x8],0x40
  40c683:	xor    ecx,ecx
  40c685:	mov    rdx,rax
  40c688:	call   410060 <__swc_fn_0a4ed24b_000119_9175a56a>
  40c68d:	mov    DWORD PTR [rdi+0xbc8],eax
  40c693:	mov    rdi,QWORD PTR [rdi+0x990]
  40c69a:	test   rdi,rdi
  40c69d:	je     40c6a7 <__swc_fn_0a4ed24b_000103_67100064+0x87>
  40c69f:	mov    rcx,rsi
  40c6a2:	mov    rdx,rbx
  40c6a5:	call   rdi
  40c6a7:	call   40c3d0 <__swc_fn_0a4ed24b_000091_3d2f5a0d>
  40c6ac:	test   al,al
  40c6ae:	je     40c6be <__swc_fn_0a4ed24b_000103_67100064+0x9e>
  40c6b0:	mov    rcx,rsi
  40c6b3:	mov    rdx,rbx
  40c6b6:	xor    r8d,r8d
  40c6b9:	call   409400 <__swc_fn_0a4ed24b_000120_ea68f292>
  40c6be:	mov    rcx,rsi
  40c6c1:	mov    rdx,rbx
  40c6c4:	call   408a80 <__swc_fn_0a4ed24b_000102_e9fdc18e>
  40c6c9:	call   40cc50 <__swc_fn_0a4ed24b_000118_7f430081>
  40c6ce:	add    rsp,0x20
  40c6d2:	pop    rdi
  40c6d3:	pop    rsi
  40c6d4:	pop    rbx
  40c6d5:	ret
	...

000000000040c6e0 <__swc_fn_0a4ed24b_000106_ed4b1681>:
  40c6e0:	test   r8,r8
  40c6e3:	jne    40c6e8 <__swc_fn_0a4ed24b_000106_ed4b1681+0x8>
  40c6e5:	xor    eax,eax
  40c6e7:	ret
  40c6e8:	xor    eax,eax
  40c6ea:	nop    WORD PTR [rax+rax*1+0x0]
  40c6f0:	mov    r9,r8
  40c6f3:	sub    r9,rax
  40c6f6:	cmp    r9,0x10
  40c6fa:	jb     40c744 <__swc_fn_0a4ed24b_000106_ed4b1681+0x64>
  40c6fc:	lea    r9,[rcx+rax*1]
  40c700:	lea    r10,[rdx+rax*1]
  40c704:	vmovups xmm0,XMMWORD PTR [r10]
  40c709:	vmovups xmm1,XMMWORD PTR [r9]
  40c70e:	vpcmpeqb xmm0,xmm1,xmm0
  40c712:	vpmovmskb r9d,xmm0
  40c716:	cmp    r9d,0xffff
  40c71d:	je     40c73e <__swc_fn_0a4ed24b_000106_ed4b1681+0x5e>
  40c71f:	not    r9d
  40c722:	xor    r8d,r8d
  40c725:	movzx  r9d,r9w
  40c729:	tzcnt  r8d,r9d
  40c72e:	add    rax,r8
  40c731:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c735:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c739:	sub    ecx,eax
  40c73b:	mov    eax,ecx
  40c73d:	ret
  40c73e:	lea    rax,[rax+0x10]
  40c742:	jmp    40c6f0 <__swc_fn_0a4ed24b_000106_ed4b1681+0x10>
  40c744:	cmp    r9,0x8
  40c748:	jb     40c7bb <__swc_fn_0a4ed24b_000106_ed4b1681+0xdb>
  40c74a:	lea    r9,[rcx+rax*1]
  40c74e:	lea    r10,[rdx+rax*1]
  40c752:	mov    r9,QWORD PTR [r9]
  40c755:	xor    r9,QWORD PTR [r10]
  40c758:	test   r9,r9
  40c75b:	je     40c779 <__swc_fn_0a4ed24b_000106_ed4b1681+0x99>
  40c75d:	xor    r8d,r8d
  40c760:	tzcnt  r8,r9
  40c765:	shr    r8,0x3
  40c769:	add    rax,r8
  40c76c:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c770:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c774:	sub    ecx,eax
  40c776:	mov    eax,ecx
  40c778:	ret
  40c779:	lea    rax,[rax+0x8]
  40c77d:	cmp    rax,r8
  40c780:	jne    40c785 <__swc_fn_0a4ed24b_000106_ed4b1681+0xa5>
  40c782:	xor    eax,eax
  40c784:	ret
  40c785:	lea    rax,[r8-0x8]
  40c789:	lea    r8,[rcx+rax*1]
  40c78d:	lea    r9,[rdx+rax*1]
  40c791:	mov    r8,QWORD PTR [r8]
  40c794:	xor    r8,QWORD PTR [r9]
  40c797:	test   r8,r8
  40c79a:	je     40c7b8 <__swc_fn_0a4ed24b_000106_ed4b1681+0xd8>
  40c79c:	xor    r9d,r9d
  40c79f:	tzcnt  r9,r8
  40c7a4:	shr    r9,0x3
  40c7a8:	add    rax,r9
  40c7ab:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c7af:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c7b3:	sub    ecx,eax
  40c7b5:	mov    eax,ecx
  40c7b7:	ret
  40c7b8:	xor    eax,eax
  40c7ba:	ret
  40c7bb:	cmp    r9,0x4
  40c7bf:	jb     40c832 <__swc_fn_0a4ed24b_000106_ed4b1681+0x152>
  40c7c1:	lea    r9,[rcx+rax*1]
  40c7c5:	lea    r10,[rdx+rax*1]
  40c7c9:	mov    r9d,DWORD PTR [r9]
  40c7cc:	xor    r9d,DWORD PTR [r10]
  40c7cf:	test   r9d,r9d
  40c7d2:	je     40c7f0 <__swc_fn_0a4ed24b_000106_ed4b1681+0x110>
  40c7d4:	xor    r8d,r8d
  40c7d7:	tzcnt  r8,r9
  40c7dc:	shr    r8,0x3
  40c7e0:	add    rax,r8
  40c7e3:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c7e7:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c7eb:	sub    ecx,eax
  40c7ed:	mov    eax,ecx
  40c7ef:	ret
  40c7f0:	lea    rax,[rax+0x4]
  40c7f4:	cmp    rax,r8
  40c7f7:	jne    40c7fc <__swc_fn_0a4ed24b_000106_ed4b1681+0x11c>
  40c7f9:	xor    eax,eax
  40c7fb:	ret
  40c7fc:	lea    rax,[r8-0x4]
  40c800:	lea    r8,[rcx+rax*1]
  40c804:	lea    r9,[rdx+rax*1]
  40c808:	mov    r8d,DWORD PTR [r8]
  40c80b:	xor    r8d,DWORD PTR [r9]
  40c80e:	test   r8d,r8d
  40c811:	je     40c82f <__swc_fn_0a4ed24b_000106_ed4b1681+0x14f>
  40c813:	xor    r9d,r9d
  40c816:	tzcnt  r9,r8
  40c81b:	shr    r9,0x3
  40c81f:	add    rax,r9
  40c822:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c826:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c82a:	sub    ecx,eax
  40c82c:	mov    eax,ecx
  40c82e:	ret
  40c82f:	xor    eax,eax
  40c831:	ret
  40c832:	cmp    r9,0x2
  40c836:	jb     40c889 <__swc_fn_0a4ed24b_000106_ed4b1681+0x1a9>
  40c838:	lea    r9,[rcx+rax*1]
  40c83c:	lea    r10,[rdx+rax*1]
  40c840:	mov    r9w,WORD PTR [r9]
  40c844:	xor    r9w,WORD PTR [r10]
  40c848:	test   r9w,r9w
  40c84c:	je     40c86e <__swc_fn_0a4ed24b_000106_ed4b1681+0x18e>
  40c84e:	xor    r8d,r8d
  40c851:	movzx  r9d,r9w
  40c855:	tzcnt  r8,r9
  40c85a:	shr    r8,0x3
  40c85e:	add    rax,r8
  40c861:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c865:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c869:	sub    ecx,eax
  40c86b:	mov    eax,ecx
  40c86d:	ret
  40c86e:	lea    rax,[rax+0x2]
  40c872:	cmp    rax,r8
  40c875:	jne    40c87a <__swc_fn_0a4ed24b_000106_ed4b1681+0x19a>
  40c877:	xor    eax,eax
  40c879:	ret
  40c87a:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40c880:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40c886:	sub    eax,ecx
  40c888:	ret
  40c889:	test   r9,r9
  40c88c:	je     40c89b <__swc_fn_0a4ed24b_000106_ed4b1681+0x1bb>
  40c88e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c892:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c896:	sub    ecx,eax
  40c898:	mov    eax,ecx
  40c89a:	ret
  40c89b:	xor    eax,eax
  40c89d:	ret
	...

000000000040c8a0 <__swc_fn_0a4ed24b_000109_8d425bd3>:
  40c8a0:	push   r12
  40c8a2:	push   r13
  40c8a4:	push   r14
  40c8a6:	push   rdi
  40c8a7:	push   rsi
  40c8a8:	push   r15
  40c8aa:	sub    rsp,0xd8
  40c8b1:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c8b7:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c8bd:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c8c3:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c8c9:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c8cf:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c8d8:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c8e1:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c8ea:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c8f3:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c8fc:	mov    r12,rcx
  40c8ff:	test   rcx,rcx
  40c902:	je     40c91e <__swc_fn_0a4ed24b_000109_8d425bd3+0x7e>
  40c904:	mov    eax,r12d
  40c907:	and    eax,0xfff
  40c90d:	setne  al
  40c910:	cmp    r12,0xffffffffffffefff
  40c917:	seta   cl
  40c91a:	or     al,cl
  40c91c:	je     40c925 <__swc_fn_0a4ed24b_000109_8d425bd3+0x85>
  40c91e:	xor    eax,eax
  40c920:	jmp    40c9bb <__swc_fn_0a4ed24b_000109_8d425bd3+0x11b>
  40c925:	call   409120 <__swc_fn_0a4ed24b_000108_84af7666>
  40c92a:	mov    r13,rax
  40c92d:	test   rax,rax
  40c930:	jne    40c939 <__swc_fn_0a4ed24b_000109_8d425bd3+0x99>
  40c932:	xor    eax,eax
  40c934:	jmp    40c9bb <__swc_fn_0a4ed24b_000109_8d425bd3+0x11b>
  40c939:	lea    r14,[r12+0x1000]
  40c941:	xor    edi,edi
  40c943:	mov    rsi,r14
  40c946:	xor    edx,edx
  40c948:	mov    ecx,0x22
  40c94d:	mov    eax,0xffffffff
  40c952:	movsxd r8,eax
  40c955:	xor    r9d,r9d
  40c958:	xor    eax,eax
  40c95a:	call   4070c0 <mmap@plt>
  40c95f:	mov    r15,rax
  40c962:	cmp    rax,0xffffffffffffffff
  40c966:	jne    40c96c <__swc_fn_0a4ed24b_000109_8d425bd3+0xcc>
  40c968:	xor    eax,eax
  40c96a:	jmp    40c9bb <__swc_fn_0a4ed24b_000109_8d425bd3+0x11b>
  40c96c:	mov    rdi,r15
  40c96f:	mov    esi,0x1000
  40c974:	mov    edx,0x3
  40c979:	xor    eax,eax
  40c97b:	call   407030 <mprotect@plt>
  40c980:	test   eax,eax
  40c982:	je     40c995 <__swc_fn_0a4ed24b_000109_8d425bd3+0xf5>
  40c984:	mov    rdi,r15
  40c987:	mov    rsi,r14
  40c98a:	xor    eax,eax
  40c98c:	call   407020 <munmap@plt>
  40c991:	xor    eax,eax
  40c993:	jmp    40c9bb <__swc_fn_0a4ed24b_000109_8d425bd3+0x11b>
  40c995:	mov    QWORD PTR [r15+0x8],r12
  40c999:	mov    rcx,r13
  40c99c:	call   40cff0 <__swc_fn_0a4ed24b_000133_4b2af8da>
  40c9a1:	mov    rax,QWORD PTR [r13+0x8]
  40c9a5:	mov    QWORD PTR [r15],rax
  40c9a8:	mov    QWORD PTR [r13+0x8],r15
  40c9ac:	mov    rcx,r13
  40c9af:	call   410400 <__swc_fn_0a4ed24b_000134_29412410>
  40c9b4:	lea    rax,[r15+0x1000]
  40c9bb:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c9c1:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c9c7:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c9cd:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c9d3:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c9d9:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c9e2:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c9eb:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c9f4:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c9fd:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40ca06:	add    rsp,0xd8
  40ca0d:	pop    r15
  40ca0f:	pop    rsi
  40ca10:	pop    rdi
  40ca11:	pop    r14
  40ca13:	pop    r13
  40ca15:	pop    r12
  40ca17:	ret
	...

000000000040ca20 <__swc_fn_0a4ed24b_000112_759e9ceb>:
  40ca20:	push   rbx
  40ca21:	push   r12
  40ca23:	push   rdi
  40ca24:	push   rsi
  40ca25:	sub    rsp,0xa8
  40ca2c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ca32:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ca38:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ca3e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40ca44:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40ca4a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40ca50:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ca56:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ca5c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ca65:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ca6e:	mov    rbx,rdx
  40ca71:	mov    r12,rcx
  40ca74:	mov    rdi,rcx
  40ca77:	mov    rsi,rdx
  40ca7a:	xor    edx,edx
  40ca7c:	xor    eax,eax
  40ca7e:	call   407030 <mprotect@plt>
  40ca83:	test   eax,eax
  40ca85:	jne    40caa9 <__swc_fn_0a4ed24b_000112_759e9ceb+0x89>
  40ca87:	mov    rcx,r12
  40ca8a:	mov    rdx,rbx
  40ca8d:	xor    al,al
  40ca8f:	mov    r8,rax
  40ca92:	call   40fe90 <__swc_fn_0a4ed24b_000110_a808fe76>
  40ca97:	mov    rdi,r12
  40ca9a:	mov    rsi,rbx
  40ca9d:	mov    edx,0x4
  40caa2:	xor    eax,eax
  40caa4:	call   4070e0 <madvise@plt>
  40caa9:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40caaf:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cab5:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cabb:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cac1:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cac7:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cacd:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cad3:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cad9:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cae2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40caeb:	add    rsp,0xa8
  40caf2:	pop    rsi
  40caf3:	pop    rdi
  40caf4:	pop    r12
  40caf6:	pop    rbx
  40caf7:	ret
	...

000000000040cb00 <__swc_fn_0a4ed24b_000115_1ba33335>:
  40cb00:	push   rsi
  40cb01:	push   rdi
  40cb02:	push   r12
  40cb04:	push   r13
  40cb06:	push   r14
  40cb08:	sub    rsp,0xe0
  40cb0f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40cb15:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40cb1b:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40cb21:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40cb27:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40cb2d:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40cb36:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40cb3f:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40cb48:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40cb51:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40cb5a:	mov    rsi,rdx
  40cb5d:	mov    rdi,rcx
  40cb60:	call   409120 <__swc_fn_0a4ed24b_000108_84af7666>
  40cb65:	mov    r12,rax
  40cb68:	test   rax,rax
  40cb6b:	jne    40cb72 <__swc_fn_0a4ed24b_000115_1ba33335+0x72>
  40cb6d:	jmp    40cbe6 <__swc_fn_0a4ed24b_000115_1ba33335+0xe6>
  40cb72:	mov    rcx,r12
  40cb75:	call   40cff0 <__swc_fn_0a4ed24b_000133_4b2af8da>
  40cb7a:	lea    r13,[r12+0x8]
  40cb7f:	mov    rax,QWORD PTR [r13+0x0]
  40cb83:	test   rax,rax
  40cb86:	je     40cbde <__swc_fn_0a4ed24b_000115_1ba33335+0xde>
  40cb88:	nop    DWORD PTR [rax+rax*1+0x0]
  40cb90:	lea    rcx,[rax+0x1000]
  40cb97:	cmp    rcx,rdi
  40cb9a:	jne    40cbd2 <__swc_fn_0a4ed24b_000115_1ba33335+0xd2>
  40cb9c:	cmp    QWORD PTR [rax+0x8],rsi
  40cba0:	je     40cbac <__swc_fn_0a4ed24b_000115_1ba33335+0xac>
  40cba2:	mov    rcx,r12
  40cba5:	call   410400 <__swc_fn_0a4ed24b_000134_29412410>
  40cbaa:	jmp    40cbe6 <__swc_fn_0a4ed24b_000115_1ba33335+0xe6>
  40cbac:	mov    r14,QWORD PTR [rax]
  40cbaf:	mov    rdi,rax
  40cbb2:	lea    rsi,[rsi+0x1000]
  40cbb9:	xor    eax,eax
  40cbbb:	call   407020 <munmap@plt>
  40cbc0:	test   eax,eax
  40cbc2:	jne    40cbc8 <__swc_fn_0a4ed24b_000115_1ba33335+0xc8>
  40cbc4:	mov    QWORD PTR [r13+0x0],r14
  40cbc8:	mov    rcx,r12
  40cbcb:	call   410400 <__swc_fn_0a4ed24b_000134_29412410>
  40cbd0:	jmp    40cbe6 <__swc_fn_0a4ed24b_000115_1ba33335+0xe6>
  40cbd2:	mov    r13,rax
  40cbd5:	mov    rax,QWORD PTR [r13+0x0]
  40cbd9:	test   rax,rax
  40cbdc:	jne    40cb90 <__swc_fn_0a4ed24b_000115_1ba33335+0x90>
  40cbde:	mov    rcx,r12
  40cbe1:	call   410400 <__swc_fn_0a4ed24b_000134_29412410>
  40cbe6:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40cbec:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40cbf2:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40cbf8:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40cbfe:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40cc04:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40cc0d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40cc16:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40cc1f:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40cc28:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40cc31:	add    rsp,0xe0
  40cc38:	pop    r14
  40cc3a:	pop    r13
  40cc3c:	pop    r12
  40cc3e:	pop    rdi
  40cc3f:	pop    rsi
  40cc40:	ret
	...

000000000040cc50 <__swc_fn_0a4ed24b_000118_7f430081>:
  40cc50:	push   rdi
  40cc51:	push   rsi
  40cc52:	sub    rsp,0xa8
  40cc59:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cc5f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cc65:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cc6b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cc71:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cc77:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cc7d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cc83:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cc89:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cc92:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cc9b:	mov    rdi,0xfffffffffffffd66
  40cca2:	xor    eax,eax
  40cca4:	call   407040 <exit@plt>
  40cca9:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ccaf:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ccb5:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ccbb:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ccc1:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ccc7:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cccd:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ccd3:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ccd9:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cce2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cceb:	add    rsp,0xa8
  40ccf2:	pop    rsi
  40ccf3:	pop    rdi
  40ccf4:	ret
	...

000000000040cd00 <__swc_fn_0a4ed24b_000121_12b4ed22>:
  40cd00:	push   rbx
  40cd01:	push   rsi
  40cd02:	push   rdi
  40cd03:	sub    rsp,0x30
  40cd07:	mov    rbx,rdx
  40cd0a:	mov    esi,ecx
  40cd0c:	test   ecx,ecx
  40cd0e:	je     40cde3 <__swc_fn_0a4ed24b_000121_12b4ed22+0xe3>
  40cd14:	mov    rcx,rsi
  40cd17:	shl    rcx,0x4
  40cd1b:	call   40c210 <__swc_fn_0a4ed24b_000079_34776ded>
  40cd20:	test   rax,rax
  40cd23:	je     40cdd2 <__swc_fn_0a4ed24b_000121_12b4ed22+0xd2>
  40cd29:	mov    rcx,rsi
  40cd2c:	xor    edx,edx
  40cd2e:	test   rsi,rsi
  40cd31:	jbe    40cdb2 <__swc_fn_0a4ed24b_000121_12b4ed22+0xb2>
  40cd37:	nop    WORD PTR [rax+rax*1+0x0]
  40cd40:	mov    r8d,edx
  40cd43:	mov    r9,QWORD PTR [rbx+r8*8]
  40cd47:	add    r8,r8
  40cd4a:	lea    r8,[rax+r8*8]
  40cd4e:	xor    r10d,r10d
  40cd51:	test   r9,r9
  40cd54:	je     40cd90 <__swc_fn_0a4ed24b_000121_12b4ed22+0x90>
  40cd56:	mov    r11,r9
  40cd59:	mov    dil,BYTE PTR [r11]
  40cd5c:	test   dil,dil
  40cd5f:	je     40cd90 <__swc_fn_0a4ed24b_000121_12b4ed22+0x90>
  40cd61:	cs nop WORD PTR [rax+rax*1+0x0]
  40cd6b:	cs nop WORD PTR [rax+rax*1+0x0]
  40cd75:	cs nop WORD PTR [rax+rax*1+0x0]
  40cd7f:	nop
  40cd80:	add    r11,0x1
  40cd84:	add    r10,0x1
  40cd88:	mov    dil,BYTE PTR [r11]
  40cd8b:	test   dil,dil
  40cd8e:	jne    40cd80 <__swc_fn_0a4ed24b_000121_12b4ed22+0x80>
  40cd90:	mov    QWORD PTR [rsp+0x18],r9
  40cd95:	mov    QWORD PTR [rsp+0x20],r10
  40cd9a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40cda0:	vmovups XMMWORD PTR [r8],xmm0
  40cda5:	add    rdx,0x1
  40cda9:	cmp    rdx,rcx
  40cdac:	jb     40cd40 <__swc_fn_0a4ed24b_000121_12b4ed22+0x40>
  40cdb2:	lea    rcx,[rip+0x19f97]        # 426d50 <__swc_bss_base_0a4ed24b+0x2d10>
  40cdb9:	mov    QWORD PTR [rsp+0x8],rax
  40cdbe:	mov    esi,esi
  40cdc0:	mov    QWORD PTR [rsp+0x10],rsi
  40cdc5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40cdcb:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40cdd0:	jmp    40cde3 <__swc_fn_0a4ed24b_000121_12b4ed22+0xe3>
  40cdd2:	lea    rcx,[rip+0x6747]        # 413520 <__swc_rdata_base_0a4ed24b+0x410>
  40cdd9:	call   40ff40 <__swc_fn_0a4ed24b_000116_035d76a1>
  40cdde:	call   40cc50 <__swc_fn_0a4ed24b_000118_7f430081>
  40cde3:	add    rsp,0x30
  40cde7:	pop    rdi
  40cde8:	pop    rsi
  40cde9:	pop    rbx
  40cdea:	ret
  40cdeb:	add    BYTE PTR [rax],al
  40cded:	add    BYTE PTR [rax],al
	...

000000000040cdf0 <__swc_fn_0a4ed24b_000124_667fbf24>:
  40cdf0:	push   rdi
  40cdf1:	push   rsi
  40cdf2:	sub    rsp,0xa8
  40cdf9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cdff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ce05:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ce0b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40ce11:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40ce17:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40ce1d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ce23:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ce29:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ce32:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ce3b:	mov    edi,ecx
  40ce3d:	xor    eax,eax
  40ce3f:	call   4070f0 <pthread_key_delete@plt>
  40ce44:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ce4a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ce50:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ce56:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ce5c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ce62:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ce68:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ce6e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ce74:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ce7d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ce86:	add    rsp,0xa8
  40ce8d:	pop    rsi
  40ce8e:	pop    rdi
  40ce8f:	ret

000000000040ce90 <__swc_fn_0a4ed24b_000127_8dffa290>:
  40ce90:	push   rdi
  40ce91:	push   rsi
  40ce92:	sub    rsp,0xa8
  40ce99:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ce9f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cea5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ceab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40ceb1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40ceb7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cebd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cec3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cec9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ced2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cedb:	test   rcx,rcx
  40cede:	je     40ceef <__swc_fn_0a4ed24b_000127_8dffa290+0x5f>
  40cee0:	lea    rax,[rcx-0x1]
  40cee4:	mov    eax,eax
  40cee6:	mov    edi,eax
  40cee8:	xor    eax,eax
  40ceea:	call   4070f0 <pthread_key_delete@plt>
  40ceef:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cef5:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cefb:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cf01:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cf07:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cf0d:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cf13:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cf19:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cf1f:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cf28:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cf31:	add    rsp,0xa8
  40cf38:	pop    rsi
  40cf39:	pop    rdi
  40cf3a:	ret
  40cf3b:	add    BYTE PTR [rax],al
  40cf3d:	add    BYTE PTR [rax],al
	...

000000000040cf40 <__swc_fn_0a4ed24b_000130_c1196dfb>:
  40cf40:	push   rsi
  40cf41:	push   rdi
  40cf42:	sub    rsp,0xa8
  40cf49:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cf4f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cf55:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cf5b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cf61:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cf67:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cf6d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cf73:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cf79:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cf82:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cf8b:	xor    eax,eax
  40cf8d:	call   407100 <gettid@plt>
  40cf92:	movsxd rax,eax
  40cf95:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cf9b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cfa1:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cfa7:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cfad:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cfb3:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cfb9:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cfbf:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cfc5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cfce:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cfd7:	add    rsp,0xa8
  40cfde:	pop    rdi
  40cfdf:	pop    rsi
  40cfe0:	ret
	...

000000000040cff0 <__swc_fn_0a4ed24b_000133_4b2af8da>:
  40cff0:	push   rbx
  40cff1:	push   rdi
  40cff2:	push   rsi
  40cff3:	sub    rsp,0xc0
  40cffa:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40d000:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40d006:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40d00c:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40d012:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40d018:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40d01e:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40d024:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40d02d:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40d036:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40d03f:	mov    rbx,rcx
  40d042:	cs nop WORD PTR [rax+rax*1+0x0]
  40d04c:	nop    DWORD PTR [rax+0x0]
  40d050:	mov    edx,0x80000000
  40d055:	xor    eax,eax
  40d057:	lock cmpxchg DWORD PTR [rbx],edx
  40d05b:	test   eax,eax
  40d05d:	je     40d094 <__swc_fn_0a4ed24b_000133_4b2af8da+0xa4>
  40d05f:	mov    eax,DWORD PTR [rbx]
  40d061:	lea    rcx,[rsp+0x14]
  40d066:	mov    DWORD PTR [rsp+0x14],eax
  40d06a:	test   eax,eax
  40d06c:	je     40d050 <__swc_fn_0a4ed24b_000133_4b2af8da+0x60>
  40d06e:	mov    QWORD PTR [rsp],0x0
  40d076:	mov    edi,0xca
  40d07b:	mov    rsi,rbx
  40d07e:	mov    edx,0x80
  40d083:	mov    ecx,DWORD PTR [rcx]
  40d085:	xor    r8d,r8d
  40d088:	xor    r9d,r9d
  40d08b:	xor    eax,eax
  40d08d:	call   407070 <syscall@plt>
  40d092:	jmp    40d050 <__swc_fn_0a4ed24b_000133_4b2af8da+0x60>
  40d094:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40d09a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40d0a0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40d0a6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40d0ac:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40d0b2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40d0b8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40d0be:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40d0c7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40d0d0:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40d0d9:	add    rsp,0xc0
  40d0e0:	pop    rsi
  40d0e1:	pop    rdi
  40d0e2:	pop    rbx
  40d0e3:	ret
	...

000000000040d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>:
  40d0f0:	sub    rsp,0x8
  40d0f4:	call   410400 <__swc_fn_0a4ed24b_000134_29412410>
  40d0f9:	add    rsp,0x8
  40d0fd:	ret
	...

000000000040d100 <__swc_fn_0a4ed24b_000139_7c02fe26>:
  40d100:	push   rdi
  40d101:	push   rsi
  40d102:	sub    rsp,0xa8
  40d109:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d10f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d115:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d11b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d121:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d127:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d12d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d133:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d139:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d142:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d14b:	mov    edi,0x28
  40d150:	xor    eax,eax
  40d152:	call   4070d0 <malloc@plt>
  40d157:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d15d:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d163:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d169:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d16f:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d175:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d17b:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d181:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d187:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d190:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d199:	add    rsp,0xa8
  40d1a0:	pop    rsi
  40d1a1:	pop    rdi
  40d1a2:	ret
	...

000000000040d1b0 <__swc_fn_0a4ed24b_000142_56e56812>:
  40d1b0:	mov    QWORD PTR [r8],0x0
  40d1b7:	cmp    rdx,0x10
  40d1bb:	jae    40d1c0 <__swc_fn_0a4ed24b_000142_56e56812+0x10>
  40d1bd:	xor    eax,eax
  40d1bf:	ret
  40d1c0:	mov    eax,DWORD PTR [rcx]
  40d1c2:	cmp    eax,0x42445753
  40d1c8:	jne    40d1d2 <__swc_fn_0a4ed24b_000142_56e56812+0x22>
  40d1ca:	mov    eax,DWORD PTR [rcx+0x4]
  40d1cd:	cmp    eax,0x1
  40d1d0:	je     40d1d5 <__swc_fn_0a4ed24b_000142_56e56812+0x25>
  40d1d2:	xor    eax,eax
  40d1d4:	ret
  40d1d5:	mov    QWORD PTR [r8],rdx
  40d1d8:	mov    rax,rcx
  40d1db:	ret
  40d1dc:	add    BYTE PTR [rax],al
	...

000000000040d1e0 <__swc_fn_0a4ed24b_000145_863755b5>:
  40d1e0:	push   rbx
  40d1e1:	sub    rsp,0xe0
  40d1e8:	lea    rbx,[rsp+0x8]
  40d1ed:	vxorps xmm0,xmm0,xmm0
  40d1f1:	vmovups XMMWORD PTR [rbx],xmm0
  40d1f5:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d1fa:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d1ff:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d204:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d209:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  40d20e:	mov    DWORD PTR [rbx+0x60],0x0
  40d215:	mov    r8,rbx
  40d218:	mov    rdx,rcx
  40d21b:	nop    DWORD PTR [rax+rax*1+0x0]
  40d220:	mov    r9,rdx
  40d223:	movabs rdx,0x6666666666666667
  40d22d:	mov    rax,r9
  40d230:	imul   rdx
  40d233:	sar    rdx,0x2
  40d237:	mov    r10,rdx
  40d23a:	shr    rdx,0x3f
  40d23e:	add    r10,rdx
  40d241:	mov    rdx,r10
  40d244:	imul   r11,r10,0xa
  40d248:	sub    r9,r11
  40d24b:	mov    r11,QWORD PTR [rip+0x62ee]        # 413540 <__swc_rdata_base_0a4ed24b+0x430>
  40d252:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40d257:	mov    BYTE PTR [r8],r9b
  40d25a:	lea    r9,[r8+0x1]
  40d25e:	mov    r8,r9
  40d261:	test   r10,r10
  40d264:	jne    40d220 <__swc_fn_0a4ed24b_000145_863755b5+0x40>
  40d266:	test   rcx,rcx
  40d269:	jge    40d273 <__swc_fn_0a4ed24b_000145_863755b5+0x93>
  40d26b:	mov    BYTE PTR [r9],0x2d
  40d26f:	add    r8,0x1
  40d273:	mov    BYTE PTR [r8],0x0
  40d277:	sub    r8,0x1
  40d27b:	mov    rax,rbx
  40d27e:	cmp    rax,r8
  40d281:	jae    40d2a6 <__swc_fn_0a4ed24b_000145_863755b5+0xc6>
  40d283:	cs nop WORD PTR [rax+rax*1+0x0]
  40d28d:	nop    DWORD PTR [rax]
  40d290:	mov    cl,BYTE PTR [r8]
  40d293:	mov    dl,BYTE PTR [rax]
  40d295:	mov    BYTE PTR [r8],dl
  40d298:	sub    r8,0x1
  40d29c:	mov    BYTE PTR [rax],cl
  40d29e:	inc    rax
  40d2a1:	cmp    rax,r8
  40d2a4:	jb     40d290 <__swc_fn_0a4ed24b_000145_863755b5+0xb0>
  40d2a6:	xor    eax,eax
  40d2a8:	test   rbx,rbx
  40d2ab:	je     40d2ce <__swc_fn_0a4ed24b_000145_863755b5+0xee>
  40d2ad:	mov    rcx,rbx
  40d2b0:	mov    dl,BYTE PTR [rcx]
  40d2b2:	test   dl,dl
  40d2b4:	je     40d2ce <__swc_fn_0a4ed24b_000145_863755b5+0xee>
  40d2b6:	cs nop WORD PTR [rax+rax*1+0x0]
  40d2c0:	add    rcx,0x1
  40d2c4:	add    rax,0x1
  40d2c8:	mov    dl,BYTE PTR [rcx]
  40d2ca:	test   dl,dl
  40d2cc:	jne    40d2c0 <__swc_fn_0a4ed24b_000145_863755b5+0xe0>
  40d2ce:	mov    QWORD PTR [rbx+0xa8],rbx
  40d2d5:	mov    QWORD PTR [rbx+0xb0],rax
  40d2dc:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d2e4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d2ec:	lea    rcx,[rbx+0xb8]
  40d2f3:	call   40ff40 <__swc_fn_0a4ed24b_000116_035d76a1>
  40d2f8:	add    rsp,0xe0
  40d2ff:	pop    rbx
  40d300:	ret
	...

000000000040d310 <__swc_fn_0a4ed24b_000148_9e4bc402>:
  40d310:	vxorps xmm0,xmm0,xmm0
  40d314:	vmovups XMMWORD PTR [rcx],xmm0
  40d318:	mov    QWORD PTR [rcx+0x10],0x0
  40d320:	ret
	...

000000000040d330 <__swc_fn_0a4ed24b_000151_9e4bc402>:
  40d330:	vxorps xmm0,xmm0,xmm0
  40d334:	vmovups XMMWORD PTR [rcx],xmm0
  40d338:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d33d:	vxorps xmm0,xmm0,xmm0
  40d341:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d346:	vmovups xmm0,XMMWORD PTR [rip+0x62ea]        # 413638 <__swc_rdata_base_0a4ed24b+0x528>
  40d34e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d353:	vxorps xmm0,xmm0,xmm0
  40d357:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d35c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d361:	mov    QWORD PTR [rcx+0x60],0x0
  40d369:	ret
  40d36a:	add    BYTE PTR [rax],al
  40d36c:	add    BYTE PTR [rax],al
	...

000000000040d370 <__swc_fn_0a4ed24b_000154_9e4bc402>:
  40d370:	vxorps xmm0,xmm0,xmm0
  40d374:	vmovups XMMWORD PTR [rcx],xmm0
  40d378:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d37d:	vxorps xmm0,xmm0,xmm0
  40d381:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d386:	vmovups xmm0,XMMWORD PTR [rip+0x63d2]        # 413760 <__swc_rdata_base_0a4ed24b+0x650>
  40d38e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d393:	vxorps xmm0,xmm0,xmm0
  40d397:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d39c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d3a1:	vxorps xmm0,xmm0,xmm0
  40d3a5:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40d3aa:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40d3af:	vxorps xmm0,xmm0,xmm0
  40d3b3:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40d3bb:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40d3c3:	vxorps xmm0,xmm0,xmm0
  40d3c7:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40d3cf:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40d3d7:	vxorps xmm0,xmm0,xmm0
  40d3db:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40d3e3:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40d3eb:	mov    QWORD PTR [rcx+0xe0],0x0
  40d3f6:	ret
	...

000000000040d400 <__swc_fn_0a4ed24b_000157_232ffa22>:
  40d400:	push   rbx
  40d401:	mov    rbx,rcx
  40d404:	call   4119d0 <__swc_fn_0a4ed24b_000158_b43b2f96>
  40d409:	mov    rax,QWORD PTR [rbx+0x10]
  40d40d:	test   rax,rax
  40d410:	je     40d421 <__swc_fn_0a4ed24b_000157_232ffa22+0x21>
  40d412:	mov    rcx,rbx
  40d415:	mov    rdx,rax
  40d418:	mov    r8,QWORD PTR [rbx+0x18]
  40d41c:	call   409ec0 <__swc_fn_0a4ed24b_000156_2745c4a5>
  40d421:	vxorps xmm0,xmm0,xmm0
  40d425:	vmovups XMMWORD PTR [rbx],xmm0
  40d429:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d42e:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d433:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d438:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d43d:	mov    QWORD PTR [rbx+0x50],0x0
  40d445:	pop    rbx
  40d446:	ret
	...

000000000040d460 <__swc_fn_0a4ed24b_000160_01cbb887>:
  40d460:	sub    rsp,0x10
  40d464:	mov    eax,r8d
  40d467:	mov    r8d,r9d
  40d46a:	test   r9d,r9d
  40d46d:	jne    40d486 <__swc_fn_0a4ed24b_000160_01cbb887+0x26>
  40d46f:	vmovups xmm0,XMMWORD PTR [rip+0x63a1]        # 413818 <__swc_rdata_base_0a4ed24b+0x708>
  40d477:	vmovups XMMWORD PTR [r10],xmm0
  40d47c:	mov    eax,0x1
  40d481:	add    rsp,0x10
  40d485:	ret
  40d486:	mov    r9,r8
  40d489:	cmp    r8,rax
  40d48c:	jb     40d493 <__swc_fn_0a4ed24b_000160_01cbb887+0x33>
  40d48e:	cmp    r9,rdx
  40d491:	jb     40d49a <__swc_fn_0a4ed24b_000160_01cbb887+0x3a>
  40d493:	xor    eax,eax
  40d495:	add    rsp,0x10
  40d499:	ret
  40d49a:	xor    eax,eax
  40d49c:	lea    r8,[r9+rax*1]
  40d4a0:	cmp    r8,rdx
  40d4a3:	jae    40d4d3 <__swc_fn_0a4ed24b_000160_01cbb887+0x73>
  40d4a5:	cs nop WORD PTR [rax+rax*1+0x0]
  40d4af:	cs nop WORD PTR [rax+rax*1+0x0]
  40d4b9:	nop    DWORD PTR [rax+0x0]
  40d4c0:	cmp    BYTE PTR [rcx+r8*1],0x0
  40d4c5:	je     40d4d3 <__swc_fn_0a4ed24b_000160_01cbb887+0x73>
  40d4c7:	inc    rax
  40d4ca:	lea    r8,[r9+rax*1]
  40d4ce:	cmp    r8,rdx
  40d4d1:	jb     40d4c0 <__swc_fn_0a4ed24b_000160_01cbb887+0x60>
  40d4d3:	cmp    r8,rdx
  40d4d6:	jne    40d4df <__swc_fn_0a4ed24b_000160_01cbb887+0x7f>
  40d4d8:	xor    eax,eax
  40d4da:	add    rsp,0x10
  40d4de:	ret
  40d4df:	add    rcx,r9
  40d4e2:	mov    QWORD PTR [rsp],rcx
  40d4e6:	mov    QWORD PTR [rsp+0x8],rax
  40d4eb:	vmovups xmm0,XMMWORD PTR [rsp]
  40d4f0:	vmovups XMMWORD PTR [r10],xmm0
  40d4f5:	mov    eax,0x1
  40d4fa:	add    rsp,0x10
  40d4fe:	ret
	...

000000000040d500 <__swc_fn_0a4ed24b_000163_8e41797b>:
  40d500:	push   rbp
  40d501:	push   rbx
  40d502:	push   rsi
  40d503:	push   rdi
  40d504:	push   r12
  40d506:	push   r13
  40d508:	push   r14
  40d50a:	push   r15
  40d50c:	sub    rsp,0x10
  40d510:	mov    rbp,rsp
  40d513:	vmovups XMMWORD PTR [rsp],xmm6
  40d518:	sub    rsp,0x50
  40d51c:	mov    rbx,rsp
  40d51f:	mov    rsi,r8
  40d522:	mov    QWORD PTR [rsp+0x30],r8
  40d527:	mov    rdi,rcx
  40d52a:	mov    QWORD PTR [rsp+0x38],rcx
  40d52f:	mov    r12,rdx
  40d532:	xor    r13b,r13b
  40d535:	mov    r14,QWORD PTR [rdi+0x8]
  40d539:	mov    QWORD PTR [rsp+0x40],r14
  40d53e:	xor    r15d,r15d
  40d541:	test   r14,r14
  40d544:	jbe    40d79e <__swc_fn_0a4ed24b_000163_8e41797b+0x29e>
  40d54a:	mov    r14,QWORD PTR [rdi]
  40d54d:	mov    rax,QWORD PTR [rsp+0x40]
  40d552:	mov    QWORD PTR [rsp+0x48],r14
  40d557:	vmovups xmm6,XMMWORD PTR [rip+0x5ed9]        # 413438 <__swc_rdata_base_0a4ed24b+0x328>
  40d55f:	nop
  40d560:	cmp    QWORD PTR [r14+r15*8],0x0
  40d565:	jne    40d56f <__swc_fn_0a4ed24b_000163_8e41797b+0x6f>
  40d567:	mov    r14,rax
  40d56a:	jmp    40d77e <__swc_fn_0a4ed24b_000163_8e41797b+0x27e>
  40d56f:	mov    rcx,QWORD PTR [rdi]
  40d572:	mov    rdx,QWORD PTR [rcx+r15*8]
  40d576:	mov    rdi,rbx
  40d579:	mov    rcx,rdi
  40d57c:	sub    rsp,0x8
  40d580:	mov    r14,rax
  40d583:	call   409f40 <__swc_fn_0a4ed24b_000162_60216e69>
  40d588:	add    rsp,0x8
  40d58c:	mov    al,BYTE PTR [rbx]
  40d58e:	test   al,al
  40d590:	je     40d77e <__swc_fn_0a4ed24b_000163_8e41797b+0x27e>
  40d596:	mov    al,BYTE PTR [rbx+0x1]
  40d599:	test   al,al
  40d59b:	jne    40d5a6 <__swc_fn_0a4ed24b_000163_8e41797b+0xa6>
  40d59d:	test   sil,sil
  40d5a0:	je     40d77e <__swc_fn_0a4ed24b_000163_8e41797b+0x27e>
  40d5a6:	test   r13b,r13b
  40d5a9:	jne    40d667 <__swc_fn_0a4ed24b_000163_8e41797b+0x167>
  40d5af:	test   r12,r12
  40d5b2:	je     40d667 <__swc_fn_0a4ed24b_000163_8e41797b+0x167>
  40d5b8:	mov    al,BYTE PTR [rbx+0x1]
  40d5bb:	test   al,al
  40d5bd:	je     40d77e <__swc_fn_0a4ed24b_000163_8e41797b+0x27e>
  40d5c3:	mov    eax,DWORD PTR [rbx+0x28]
  40d5c6:	cmp    DWORD PTR [r12+0x20],eax
  40d5cb:	jne    40d77e <__swc_fn_0a4ed24b_000163_8e41797b+0x27e>
  40d5d1:	mov    rax,QWORD PTR [r12]
  40d5d5:	mov    rcx,QWORD PTR [r12+0x8]
  40d5da:	cmp    QWORD PTR [rbx+0x20],rcx
  40d5de:	jne    40d77e <__swc_fn_0a4ed24b_000163_8e41797b+0x27e>
  40d5e4:	mov    cl,0x1
  40d5e6:	test   rax,rax
  40d5e9:	je     40d652 <__swc_fn_0a4ed24b_000163_8e41797b+0x152>
  40d5ef:	mov    rdx,QWORD PTR [rbx+0x20]
  40d5f3:	xor    r8d,r8d
  40d5f6:	test   rdx,rdx
  40d5f9:	jbe    40d652 <__swc_fn_0a4ed24b_000163_8e41797b+0x152>
  40d5fb:	mov    r9,QWORD PTR [rbx+0x18]
  40d5ff:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40d604:	cs nop WORD PTR [rax+rax*1+0x0]
  40d60e:	xchg   ax,ax
  40d610:	mov    r10b,BYTE PTR [rax+r8*1]
  40d614:	cmp    BYTE PTR [r9+r8*1],r10b
  40d618:	je     40d649 <__swc_fn_0a4ed24b_000163_8e41797b+0x149>
  40d61a:	vmovq  r10,xmm0
  40d61f:	cmp    BYTE PTR [r10+r8*1],0x5c
  40d624:	jne    40d62d <__swc_fn_0a4ed24b_000163_8e41797b+0x12d>
  40d626:	cmp    BYTE PTR [rax+r8*1],0x2f
  40d62b:	je     40d649 <__swc_fn_0a4ed24b_000163_8e41797b+0x149>
  40d62d:	vmovq  r10,xmm0
  40d632:	cmp    BYTE PTR [r10+r8*1],0x2f
  40d637:	jne    40d640 <__swc_fn_0a4ed24b_000163_8e41797b+0x140>
  40d639:	cmp    BYTE PTR [rax+r8*1],0x5c
  40d63e:	je     40d649 <__swc_fn_0a4ed24b_000163_8e41797b+0x149>
  40d640:	xor    eax,eax
  40d642:	movzx  eax,al
  40d645:	mov    cl,al
  40d647:	jmp    40d652 <__swc_fn_0a4ed24b_000163_8e41797b+0x152>
  40d649:	add    r8,0x1
  40d64d:	cmp    r8,rdx
  40d650:	jb     40d610 <__swc_fn_0a4ed24b_000163_8e41797b+0x110>
  40d652:	test   cl,cl
  40d654:	je     40d77e <__swc_fn_0a4ed24b_000163_8e41797b+0x27e>
  40d65a:	mov    eax,0x1
  40d65f:	mov    r13b,al
  40d662:	jmp    40d77e <__swc_fn_0a4ed24b_000163_8e41797b+0x27e>
  40d667:	mov    r13b,0x1
  40d66a:	sub    rsp,0x20
  40d66e:	mov    rax,rsp
  40d671:	lea    rcx,[rdi+0x8]
  40d675:	mov    QWORD PTR [rax],rcx
  40d678:	lea    rsi,[rip+0x5c91]        # 413310 <__swc_rdata_base_0a4ed24b+0x200>
  40d67f:	mov    QWORD PTR [rax+0x8],rsi
  40d683:	mov    QWORD PTR [rax+0x10],rsp
  40d687:	mov    QWORD PTR [rax+0x18],0x1
  40d68f:	lea    rcx,[rsp+0x10]
  40d694:	sub    rsp,0x8
  40d698:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  40d69d:	add    rsp,0x8
  40d6a1:	add    rsp,0x20
  40d6a5:	mov    al,BYTE PTR [rbx+0x1]
  40d6a8:	test   al,al
  40d6aa:	je     40d747 <__swc_fn_0a4ed24b_000163_8e41797b+0x247>
  40d6b0:	lea    rax,[rip+0x6201]        # 4138b8 <__swc_rdata_base_0a4ed24b+0x7a8>
  40d6b7:	sub    rsp,0x20
  40d6bb:	mov    rcx,rsp
  40d6be:	mov    QWORD PTR [rcx],rax
  40d6c1:	mov    QWORD PTR [rcx+0x8],rsi
  40d6c5:	mov    QWORD PTR [rcx+0x10],rsp
  40d6c9:	mov    QWORD PTR [rcx+0x18],0x1
  40d6d1:	lea    rcx,[rsp+0x10]
  40d6d6:	sub    rsp,0x8
  40d6da:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  40d6df:	add    rsp,0x8
  40d6e3:	add    rsp,0x20
  40d6e7:	mov    eax,DWORD PTR [rbx+0x28]
  40d6ea:	sub    rsp,0x60
  40d6ee:	mov    rcx,rsp
  40d6f1:	lea    rdx,[rdi+0x18]
  40d6f5:	mov    QWORD PTR [rcx+0x18],rdx
  40d6f9:	mov    QWORD PTR [rcx+0x20],rsi
  40d6fd:	vmovups XMMWORD PTR [rcx],xmm6
  40d701:	mov    QWORD PTR [rcx+0x28],rsp
  40d705:	mov    QWORD PTR [rcx+0x30],rsi
  40d709:	mov    DWORD PTR [rcx+0x10],eax
  40d70c:	lea    rax,[rsp+0x10]
  40d711:	mov    QWORD PTR [rcx+0x38],rax
  40d715:	lea    rax,[rip+0x5cb4]        # 4133d0 <__swc_rdata_base_0a4ed24b+0x2c0>
  40d71c:	mov    QWORD PTR [rcx+0x40],rax
  40d720:	lea    rax,[rsp+0x18]
  40d725:	mov    QWORD PTR [rcx+0x48],rax
  40d729:	mov    QWORD PTR [rcx+0x50],0x3
  40d731:	lea    rcx,[rsp+0x48]
  40d736:	sub    rsp,0x8
  40d73a:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  40d73f:	add    rsp,0x8
  40d743:	add    rsp,0x60
  40d747:	lea    rax,[rip+0x5c1a]        # 413368 <__swc_rdata_base_0a4ed24b+0x258>
  40d74e:	sub    rsp,0x20
  40d752:	mov    rcx,rsp
  40d755:	mov    QWORD PTR [rcx],rax
  40d758:	mov    QWORD PTR [rcx+0x8],rsi
  40d75c:	mov    QWORD PTR [rcx+0x10],rsp
  40d760:	mov    QWORD PTR [rcx+0x18],0x1
  40d768:	lea    rcx,[rsp+0x10]
  40d76d:	sub    rsp,0x8
  40d771:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  40d776:	add    rsp,0x8
  40d77a:	add    rsp,0x20
  40d77e:	add    r15,0x1
  40d782:	cmp    r15,r14
  40d785:	jae    40d79e <__swc_fn_0a4ed24b_000163_8e41797b+0x29e>
  40d787:	mov    rsi,QWORD PTR [rsp+0x30]
  40d78c:	mov    rdi,QWORD PTR [rsp+0x38]
  40d791:	mov    rax,r14
  40d794:	mov    r14,QWORD PTR [rsp+0x48]
  40d799:	jmp    40d560 <__swc_fn_0a4ed24b_000163_8e41797b+0x60>
  40d79e:	add    rsp,0x50
  40d7a2:	vmovups xmm6,XMMWORD PTR [rsp]
  40d7a7:	add    rsp,0x10
  40d7ab:	pop    r15
  40d7ad:	pop    r14
  40d7af:	pop    r13
  40d7b1:	pop    r12
  40d7b3:	pop    rdi
  40d7b4:	pop    rsi
  40d7b5:	pop    rbx
  40d7b6:	pop    rbp
  40d7b7:	ret
	...

000000000040d7c0 <__swc_fn_0a4ed24b_000166_f6173642>:
  40d7c0:	sub    rsp,0x8
  40d7c4:	call   4101d0 <__swc_fn_0a4ed24b_000125_ce762363>
  40d7c9:	add    rsp,0x8
  40d7cd:	ret
	...

000000000040d7d0 <__swc_fn_0a4ed24b_000169_4579a84c>:
  40d7d0:	push   rsi
  40d7d1:	sub    rsp,0x30
  40d7d5:	lea    rsi,[rip+0x195c4]        # 426da0 <__swc_bss_base_0a4ed24b+0x2d60>
  40d7dc:	mov    rax,QWORD PTR [rsi]
  40d7df:	test   rax,rax
  40d7e2:	je     40d7ea <__swc_fn_0a4ed24b_000169_4579a84c+0x1a>
  40d7e4:	add    rsp,0x30
  40d7e8:	pop    rsi
  40d7e9:	ret
  40d7ea:	mov    ecx,0x2
  40d7ef:	mov    edx,0x8020
  40d7f4:	call   40f840 <__swc_fn_0a4ed24b_000107_4796e893>
  40d7f9:	test   rax,rax
  40d7fc:	jne    40d80d <__swc_fn_0a4ed24b_000169_4579a84c+0x3d>
  40d7fe:	mov    QWORD PTR [rsp+0x18],rax
  40d803:	call   40cc50 <__swc_fn_0a4ed24b_000118_7f430081>
  40d808:	mov    rax,QWORD PTR [rsp+0x18]
  40d80d:	mov    rcx,rax
  40d810:	xchg   QWORD PTR [rsi],rcx
  40d813:	add    rsp,0x30
  40d817:	pop    rsi
  40d818:	ret
  40d819:	add    BYTE PTR [rax],al
  40d81b:	add    BYTE PTR [rax],al
  40d81d:	add    BYTE PTR [rax],al
	...

000000000040d820 <__swc_fn_0a4ed24b_000172_97fbc432>:
  40d820:	push   rsi
  40d821:	test   r8,r8
  40d824:	jne    40d828 <__swc_fn_0a4ed24b_000172_97fbc432+0x8>
  40d826:	pop    rsi
  40d827:	ret
  40d828:	lea    rax,[rcx+0x18]
  40d82c:	mov    r10,QWORD PTR [rax]
  40d82f:	lea    r11,[r10+0x1]
  40d833:	mov    QWORD PTR [rax],r11
  40d836:	mov    r11,rdx
  40d839:	not    rdx
  40d83c:	lea    rsi,[r8-0x1]
  40d840:	cmp    rsi,rdx
  40d843:	ja     40d863 <__swc_fn_0a4ed24b_000172_97fbc432+0x43>
  40d845:	lea    rdx,[r11+r8*1]
  40d849:	dec    rdx
  40d84c:	shr    rdx,0x6
  40d850:	mov    r8,r11
  40d853:	shr    r8,0x6
  40d857:	mov    rsi,rdx
  40d85a:	sub    rsi,r8
  40d85d:	cmp    rsi,0x8
  40d861:	jb     40d879 <__swc_fn_0a4ed24b_000172_97fbc432+0x59>
  40d863:	lea    rcx,[rcx+0x10]
  40d867:	mov    rdx,QWORD PTR [rcx]
  40d86a:	add    rdx,r9
  40d86d:	mov    QWORD PTR [rcx],rdx
  40d870:	lea    rcx,[r10+0x2]
  40d874:	mov    QWORD PTR [rax],rcx
  40d877:	pop    rsi
  40d878:	ret
  40d879:	shr    r11,0x6
  40d87d:	nop    DWORD PTR [rax]
  40d880:	cmp    r11,rdx
  40d883:	ja     40d8c3 <__swc_fn_0a4ed24b_000172_97fbc432+0xa3>
  40d885:	jmp    40d896 <__swc_fn_0a4ed24b_000172_97fbc432+0x76>
  40d887:	nop    WORD PTR [rax+rax*1+0x0]
  40d890:	add    r11,0x1
  40d894:	jmp    40d880 <__swc_fn_0a4ed24b_000172_97fbc432+0x60>
  40d896:	mov    r8,r11
  40d899:	shr    r8,0xc
  40d89d:	mov    rsi,r11
  40d8a0:	xor    rsi,r8
  40d8a3:	mov    r8,r11
  40d8a6:	shr    r8,0x18
  40d8aa:	xor    rsi,r8
  40d8ad:	and    esi,0xfff
  40d8b3:	lea    r8,[rcx+rsi*8+0x20]
  40d8b8:	mov    rsi,QWORD PTR [r8]
  40d8bb:	add    rsi,r9
  40d8be:	mov    QWORD PTR [r8],rsi
  40d8c1:	jmp    40d890 <__swc_fn_0a4ed24b_000172_97fbc432+0x70>
  40d8c3:	lea    rcx,[r10+0x2]
  40d8c7:	mov    QWORD PTR [rax],rcx
  40d8ca:	pop    rsi
  40d8cb:	ret
  40d8cc:	add    BYTE PTR [rax],al
	...

000000000040d8d0 <__swc_fn_0a4ed24b_000175_1ca87929>:
  40d8d0:	push   rdi
  40d8d1:	push   rsi
  40d8d2:	sub    rsp,0xb8
  40d8d9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40d8df:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40d8e5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40d8eb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40d8f1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40d8f7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40d8fd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40d903:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40d90c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40d915:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40d91e:	vxorps xmm0,xmm0,xmm0
  40d922:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40d928:	mov    edi,0x1
  40d92d:	lea    rsi,[rsp+0x8]
  40d932:	xor    eax,eax
  40d934:	call   407110 <clock_gettime@plt>
  40d939:	vxorpd xmm0,xmm0,xmm0
  40d93d:	mov    rax,QWORD PTR [rsp+0x8]
  40d942:	vcvtsi2sd xmm0,xmm0,rax
  40d947:	vxorpd xmm1,xmm1,xmm1
  40d94b:	mov    rax,QWORD PTR [rsp+0x10]
  40d950:	vcvtsi2sd xmm1,xmm1,rax
  40d955:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x5fab]        # 413908 <__swc_rdata_base_0a4ed24b+0x7f8>
  40d95d:	vaddsd xmm0,xmm0,xmm1
  40d961:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40d967:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40d96d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40d973:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40d979:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40d97f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40d985:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40d98b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40d994:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40d99d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40d9a6:	add    rsp,0xb8
  40d9ad:	pop    rsi
  40d9ae:	pop    rdi
  40d9af:	ret
	...

000000000040d9c0 <__swc_fn_0a4ed24b_000178_a483827c>:
  40d9c0:	push   rbp
  40d9c1:	push   rsi
  40d9c2:	push   rdi
  40d9c3:	push   r12
  40d9c5:	sub    rsp,0x90
  40d9cc:	mov    rbp,rsp
  40d9cf:	vmovups XMMWORD PTR [rsp],xmm6
  40d9d4:	vmovups XMMWORD PTR [rsp+0x10],xmm7
  40d9da:	vmovups XMMWORD PTR [rsp+0x20],xmm8
  40d9e0:	vmovups XMMWORD PTR [rsp+0x30],xmm9
  40d9e6:	vmovups XMMWORD PTR [rsp+0x40],xmm10
  40d9ec:	vmovups XMMWORD PTR [rsp+0x50],xmm11
  40d9f2:	vmovups XMMWORD PTR [rsp+0x60],xmm12
  40d9f8:	vmovups XMMWORD PTR [rsp+0x70],xmm13
  40d9fe:	vmovups XMMWORD PTR [rsp+0x80],xmm14
  40da07:	sub    rsp,0x68
  40da0b:	call   40d8d0 <__swc_fn_0a4ed24b_000175_1ca87929>
  40da10:	add    rsp,0x8
  40da14:	vmovups xmm6,xmm0
  40da18:	xor    esi,esi
  40da1a:	xor    edi,edi
  40da1c:	vmovsd xmm7,QWORD PTR [rip+0x5b90]        # 4135b4 <__swc_rdata_base_0a4ed24b+0x4a4>
  40da24:	vmovsd xmm8,QWORD PTR [rip+0x613c]        # 413b68 <__swc_rdata_base_0a4ed24b+0xa58>
  40da2c:	vmovsd xmm9,QWORD PTR [rip+0x5ef8]        # 41392c <__swc_rdata_base_0a4ed24b+0x81c>
  40da34:	vmovsd xmm10,QWORD PTR [rip+0x6135]        # 413b71 <__swc_rdata_base_0a4ed24b+0xa61>
  40da3c:	vmovsd xmm11,QWORD PTR [rip+0x6136]        # 413b7a <__swc_rdata_base_0a4ed24b+0xa6a>
  40da44:	vmovsd xmm12,QWORD PTR [rip+0x6137]        # 413b83 <__swc_rdata_base_0a4ed24b+0xa73>
  40da4c:	sub    rsp,0x8
  40da50:	xor    r12d,r12d
  40da53:	vxorpd xmm0,xmm0,xmm0
  40da57:	vcvtsi2sd xmm0,xmm0,edi
  40da5b:	vaddsd xmm0,xmm0,xmm7
  40da5f:	vdivsd xmm0,xmm0,xmm11
  40da64:	vaddsd xmm0,xmm0,xmm0
  40da68:	vsubsd xmm13,xmm9,xmm0
  40da6c:	vmulsd xmm14,xmm13,xmm13
  40da71:	cs nop WORD PTR [rax+rax*1+0x0]
  40da7b:	cs nop WORD PTR [rax+rax*1+0x0]
  40da85:	cs nop WORD PTR [rax+rax*1+0x0]
  40da8f:	nop
  40da90:	vxorpd xmm0,xmm0,xmm0
  40da94:	vcvtsi2sd xmm0,xmm0,r12d
  40da99:	vaddsd xmm0,xmm0,xmm7
  40da9d:	vdivsd xmm0,xmm0,xmm8
  40daa2:	vaddsd xmm0,xmm0,xmm0
  40daa6:	vsubsd xmm0,xmm0,xmm9
  40daab:	vmulsd xmm0,xmm0,xmm10
  40dab0:	vmulsd xmm1,xmm0,xmm0
  40dab4:	vaddsd xmm1,xmm1,xmm14
  40dab9:	vaddsd xmm1,xmm1,xmm9
  40dabe:	vsqrtsd xmm1,xmm1,xmm1
  40dac2:	vdivsd xmm5,xmm9,xmm1
  40dac6:	vmulsd xmm3,xmm0,xmm5
  40daca:	vmulsd xmm4,xmm13,xmm5
  40dace:	vxorpd xmm0,xmm0,xmm0
  40dad2:	vxorpd xmm1,xmm1,xmm1
  40dad6:	vxorpd xmm2,xmm2,xmm2
  40dada:	xor    ecx,ecx
  40dadc:	call   40a380 <__swc_fn_0a4ed24b_000177_3634f827>
  40dae1:	vmovsd xmm0,QWORD PTR [rip+0x192cf]        # 426db8 <__swc_bss_base_0a4ed24b+0x2d78>
  40dae9:	vmulsd xmm0,xmm0,xmm12
  40daee:	vcvttsd2si rcx,xmm0
  40daf3:	vmovsd xmm0,QWORD PTR [rip+0x192c5]        # 426dc0 <__swc_bss_base_0a4ed24b+0x2d80>
  40dafb:	vmulsd xmm0,xmm0,xmm12
  40db00:	vcvttsd2si r8,xmm0
  40db05:	vmovsd xmm0,QWORD PTR [rip+0x192bb]        # 426dc8 <__swc_bss_base_0a4ed24b+0x2d88>
  40db0d:	vmulsd xmm0,xmm0,xmm12
  40db12:	vcvttsd2si r10,xmm0
  40db17:	cmp    rcx,0xff
  40db1e:	mov    eax,0xff
  40db23:	cmovg  rcx,rax
  40db27:	cmp    r8,0xff
  40db2e:	cmovg  r8,rax
  40db32:	cmp    r10,0xff
  40db39:	cmovg  r10,rax
  40db3d:	lea    rcx,[rcx+r8*2]
  40db41:	lea    rax,[r10+r10*2]
  40db45:	add    rcx,rax
  40db48:	add    rsi,rcx
  40db4b:	add    r12,0x1
  40db4f:	cmp    r12,0x1e0
  40db56:	jl     40da90 <__swc_fn_0a4ed24b_000178_a483827c+0xd0>
  40db5c:	add    rdi,0x1
  40db60:	cmp    rdi,0x168
  40db67:	jl     40da50 <__swc_fn_0a4ed24b_000178_a483827c+0x90>
  40db6d:	add    rsp,0x8
  40db71:	sub    rsp,0x8
  40db75:	call   40d8d0 <__swc_fn_0a4ed24b_000175_1ca87929>
  40db7a:	add    rsp,0x8
  40db7e:	vsubsd xmm0,xmm0,xmm6
  40db82:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x6002]        # 413b8c <__swc_rdata_base_0a4ed24b+0xa7c>
  40db8a:	lea    rax,[rip+0x57d7]        # 413368 <__swc_rdata_base_0a4ed24b+0x258>
  40db91:	sub    rsp,0x90
  40db98:	mov    rcx,rsp
  40db9b:	vmovups xmm1,XMMWORD PTR [rip+0x5fa5]        # 413b48 <__swc_rdata_base_0a4ed24b+0xa38>
  40dba3:	vmovups XMMWORD PTR [rcx],xmm1
  40dba7:	mov    QWORD PTR [rcx+0x30],rsp
  40dbab:	lea    rdx,[rip+0x575e]        # 413310 <__swc_rdata_base_0a4ed24b+0x200>
  40dbb2:	mov    QWORD PTR [rcx+0x38],rdx
  40dbb6:	mov    QWORD PTR [rcx+0x10],rsi
  40dbba:	lea    r8,[rsp+0x10]
  40dbbf:	mov    QWORD PTR [rcx+0x40],r8
  40dbc3:	lea    r8,[rip+0x5eee]        # 413ab8 <__swc_rdata_base_0a4ed24b+0x9a8>
  40dbca:	mov    QWORD PTR [rcx+0x48],r8
  40dbce:	vmovups xmm1,XMMWORD PTR [rip+0x5f82]        # 413b58 <__swc_rdata_base_0a4ed24b+0xa48>
  40dbd6:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40dbdb:	lea    r8,[rsp+0x18]
  40dbe0:	mov    QWORD PTR [rcx+0x50],r8
  40dbe4:	mov    QWORD PTR [rcx+0x58],rdx
  40dbe8:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40dbed:	lea    r8,[rcx+0x28]
  40dbf1:	mov    QWORD PTR [rcx+0x60],r8
  40dbf5:	lea    r8,[rip+0x5f04]        # 413b00 <__swc_rdata_base_0a4ed24b+0x9f0>
  40dbfc:	mov    QWORD PTR [rcx+0x68],r8
  40dc00:	mov    QWORD PTR [rcx+0x70],rax
  40dc04:	mov    QWORD PTR [rcx+0x78],rdx
  40dc08:	lea    rax,[rcx+0x30]
  40dc0c:	mov    QWORD PTR [rcx+0x80],rax
  40dc13:	mov    QWORD PTR [rcx+0x88],0x5
  40dc1e:	lea    rcx,[rcx+0x80]
  40dc25:	sub    rsp,0x8
  40dc29:	call   4107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>
  40dc2e:	add    rsp,0xf8
  40dc35:	vmovups xmm6,XMMWORD PTR [rsp]
  40dc3a:	vmovups xmm7,XMMWORD PTR [rsp+0x10]
  40dc40:	vmovups xmm8,XMMWORD PTR [rsp+0x20]
  40dc46:	vmovups xmm9,XMMWORD PTR [rsp+0x30]
  40dc4c:	vmovups xmm10,XMMWORD PTR [rsp+0x40]
  40dc52:	vmovups xmm11,XMMWORD PTR [rsp+0x50]
  40dc58:	vmovups xmm12,XMMWORD PTR [rsp+0x60]
  40dc5e:	vmovups xmm13,XMMWORD PTR [rsp+0x70]
  40dc64:	vmovups xmm14,XMMWORD PTR [rsp+0x80]
  40dc6d:	add    rsp,0x90
  40dc74:	pop    r12
  40dc76:	pop    rdi
  40dc77:	pop    rsi
  40dc78:	pop    rbp
  40dc79:	ret
  40dc7a:	add    BYTE PTR [rax],al
  40dc7c:	add    BYTE PTR [rax],al
	...

000000000040dc80 <__swc_fn_0a4ed24b_000002_884bb5c0>:
  40dc80:	sub    rsp,0x8
  40dc84:	call   40c8a0 <__swc_fn_0a4ed24b_000109_8d425bd3>
  40dc89:	mov    rcx,rax
  40dc8c:	test   rax,rax
  40dc8f:	je     40dcb6 <__swc_fn_0a4ed24b_000002_884bb5c0+0x36>
  40dc91:	lea    rdx,[rip+0x163a8]        # 424040 <__swc_bss_base_0a4ed24b>
  40dc98:	mov    r8,QWORD PTR [rip+0x163a1]        # 424040 <__swc_bss_base_0a4ed24b>
  40dc9f:	nop
  40dca0:	lea    r9,[r8+0x1]
  40dca4:	mov    rax,r8
  40dca7:	lock cmpxchg QWORD PTR [rdx],r9
  40dcac:	cmp    rax,r8
  40dcaf:	je     40dcb6 <__swc_fn_0a4ed24b_000002_884bb5c0+0x36>
  40dcb1:	mov    r8,rax
  40dcb4:	jmp    40dca0 <__swc_fn_0a4ed24b_000002_884bb5c0+0x20>
  40dcb6:	mov    rax,rcx
  40dcb9:	add    rsp,0x8
  40dcbd:	ret
	...

000000000040dcc0 <__swc_fn_0a4ed24b_000005_b2240b56>:
  40dcc0:	mov    r8d,edx
  40dcc3:	xor    eax,eax
  40dcc5:	tzcnt  eax,edx
  40dcc9:	shrx   r9d,edx,eax
  40dcce:	mov    DWORD PTR [rcx+0x2c],edx
  40dcd1:	xor    eax,eax
  40dcd3:	tzcnt  eax,edx
  40dcd7:	mov    BYTE PTR [rcx+0x38],al
  40dcda:	mov    eax,0xffffffff
  40dcdf:	xor    edx,edx
  40dce1:	div    r8d
  40dce4:	mov    DWORD PTR [rcx+0x34],eax
  40dce7:	mov    eax,r9d
  40dcea:	mov    edx,r9d
  40dced:	imul   edx,r9d
  40dcf1:	mov    r8d,0x2
  40dcf7:	sub    r8d,edx
  40dcfa:	imul   eax,r8d
  40dcfe:	mov    edx,r9d
  40dd01:	imul   edx,eax
  40dd04:	mov    r8d,0x2
  40dd0a:	sub    r8d,edx
  40dd0d:	imul   eax,r8d
  40dd11:	mov    edx,r9d
  40dd14:	imul   edx,eax
  40dd17:	mov    r8d,0x2
  40dd1d:	sub    r8d,edx
  40dd20:	imul   eax,r8d
  40dd24:	mov    edx,r9d
  40dd27:	imul   edx,eax
  40dd2a:	mov    r8d,0x2
  40dd30:	sub    r8d,edx
  40dd33:	imul   eax,r8d
  40dd37:	imul   r9d,eax
  40dd3b:	mov    edx,0x2
  40dd40:	sub    edx,r9d
  40dd43:	imul   eax,edx
  40dd46:	mov    DWORD PTR [rcx+0x30],eax
  40dd49:	ret
  40dd4a:	add    BYTE PTR [rax],al
  40dd4c:	add    BYTE PTR [rax],al
	...

000000000040dd50 <__swc_fn_0a4ed24b_000008_4e857afc>:
  40dd50:	xor    eax,eax
  40dd52:	mov    DWORD PTR [rcx+0x68],eax
  40dd55:	ret
	...

000000000040dd60 <__swc_fn_0a4ed24b_000011_6493fbbc>:
  40dd60:	mov    eax,DWORD PTR [rcx+0x28]
  40dd63:	shlx   eax,edx,eax
  40dd68:	shl    rax,0x10
  40dd6c:	lea    rdx,[rcx+rax*1]
  40dd70:	lea    rax,[rcx+0x3000]
  40dd77:	cmp    rdx,rax
  40dd7a:	cmovae rax,rdx
  40dd7e:	ret
	...

000000000040dd80 <__swc_fn_0a4ed24b_000014_afb279e2>:
  40dd80:	push   rsi
  40dd81:	push   rdi
  40dd82:	push   r12
  40dd84:	push   r13
  40dd86:	push   r14
  40dd88:	mov    rsi,rdx
  40dd8b:	mov    rdi,rcx
  40dd8e:	rex mov dl,BYTE PTR [rsi+0x3a]
  40dd92:	mov    ecx,DWORD PTR [rdi+0x28]
  40dd95:	shr    dl,cl
  40dd97:	mov    r12d,0x1
  40dd9d:	mov    ecx,edx
  40dd9f:	shl    r12,cl
  40dda2:	mov    r13d,DWORD PTR [rsi+0x3c]
  40dda6:	rex mov BYTE PTR [rsi+0x3b],0x0
  40ddab:	mov    QWORD PTR [rsi+0x40],0x0
  40ddb3:	mov    QWORD PTR [rsi],0x0
  40ddba:	mov    rax,QWORD PTR [rsi+0x10]
  40ddbe:	mov    QWORD PTR [rsi+0x20],rax
  40ddc2:	lea    r14,[rip+0x1627f]        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  40ddc9:	mov    rax,QWORD PTR [r14]
  40ddcc:	shr    rax,0x2
  40ddd0:	mov    rcx,rax
  40ddd3:	cmp    rax,0x800000
  40ddda:	mov    eax,0x800000
  40dddf:	cmovb  rcx,rax
  40dde3:	lea    r8,[rip+0x1626e]        # 424058 <__swc_bss_base_0a4ed24b+0x18>
  40ddea:	mov    rax,QWORD PTR [r8]
  40dded:	mov    r9,rax
  40ddf0:	lea    r10,[r9+r13*1]
  40ddf4:	cmp    r10,rcx
  40ddf7:	ja     40de1b <__swc_fn_0a4ed24b_000014_afb279e2+0x9b>
  40ddf9:	mov    rax,r9
  40ddfc:	lock cmpxchg QWORD PTR [r8],r10
  40de01:	cmp    rax,r9
  40de04:	je     40de0b <__swc_fn_0a4ed24b_000014_afb279e2+0x8b>
  40de06:	mov    r9,rax
  40de09:	jmp    40ddf0 <__swc_fn_0a4ed24b_000014_afb279e2+0x70>
  40de0b:	mov    rcx,rdi
  40de0e:	mov    rdx,r12
  40de11:	call   40a9d0 <__swc_fn_0a4ed24b_000016_4b207b58>
  40de16:	jmp    40de9d <__swc_fn_0a4ed24b_000014_afb279e2+0x11d>
  40de1b:	mov    rcx,rdi
  40de1e:	movzx  edx,dl
  40de21:	call   40dd60 <__swc_fn_0a4ed24b_000011_6493fbbc>
  40de26:	test   r13,r13
  40de29:	je     40de96 <__swc_fn_0a4ed24b_000014_afb279e2+0x116>
  40de2f:	mov    rcx,rax
  40de32:	mov    rdx,r13
  40de35:	call   40ca20 <__swc_fn_0a4ed24b_000112_759e9ceb>
  40de3a:	mov    rcx,QWORD PTR [rip+0x16207]        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  40de41:	cs nop WORD PTR [rax+rax*1+0x0]
  40de4b:	nop    DWORD PTR [rax+rax*1+0x0]
  40de50:	mov    rdx,rcx
  40de53:	sub    rdx,r13
  40de56:	mov    rax,rcx
  40de59:	lock cmpxchg QWORD PTR [r14],rdx
  40de5e:	cmp    rax,rcx
  40de61:	je     40de68 <__swc_fn_0a4ed24b_000014_afb279e2+0xe8>
  40de63:	mov    rcx,rax
  40de66:	jmp    40de50 <__swc_fn_0a4ed24b_000014_afb279e2+0xd0>
  40de68:	lea    rcx,[rip+0x161f1]        # 424060 <__swc_bss_base_0a4ed24b+0x20>
  40de6f:	mov    rdx,QWORD PTR [rip+0x161ea]        # 424060 <__swc_bss_base_0a4ed24b+0x20>
  40de76:	cs nop WORD PTR [rax+rax*1+0x0]
  40de80:	lea    r8,[rdx+0x1]
  40de84:	mov    rax,rdx
  40de87:	lock cmpxchg QWORD PTR [rcx],r8
  40de8c:	cmp    rax,rdx
  40de8f:	je     40de96 <__swc_fn_0a4ed24b_000014_afb279e2+0x116>
  40de91:	mov    rdx,rax
  40de94:	jmp    40de80 <__swc_fn_0a4ed24b_000014_afb279e2+0x100>
  40de96:	mov    DWORD PTR [rsi+0x3c],0x0
  40de9d:	mov    rcx,rdi
  40dea0:	mov    rdx,r12
  40dea3:	call   407600 <__swc_fn_0a4ed24b_000018_7d1e8a10>
  40dea8:	pop    r14
  40deaa:	pop    r13
  40deac:	pop    r12
  40deae:	pop    rdi
  40deaf:	pop    rsi
  40deb0:	ret
	...

000000000040dec0 <__swc_fn_0a4ed24b_000017_4df2d1a0>:
  40dec0:	mov    r8,QWORD PTR [rcx+0x48]
  40dec4:	test   r8,rdx
  40dec7:	je     40def8 <__swc_fn_0a4ed24b_000017_4df2d1a0+0x38>
  40dec9:	nop    DWORD PTR [rax+0x0]
  40ded0:	mov    rax,rdx
  40ded3:	not    rax
  40ded6:	mov    r9,r8
  40ded9:	and    r9,rax
  40dedc:	mov    rax,r8
  40dedf:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40dee5:	cmp    rax,r8
  40dee8:	jne    40def0 <__swc_fn_0a4ed24b_000017_4df2d1a0+0x30>
  40deea:	mov    eax,0x1
  40deef:	ret
  40def0:	mov    r8,rax
  40def3:	test   rax,rdx
  40def6:	jne    40ded0 <__swc_fn_0a4ed24b_000017_4df2d1a0+0x10>
  40def8:	xor    eax,eax
  40defa:	ret
  40defb:	add    BYTE PTR [rax],al
  40defd:	add    BYTE PTR [rax],al
	...

000000000040df00 <__swc_fn_0a4ed24b_000020_a66e8b97>:
  40df00:	push   rsi
  40df01:	push   rdi
  40df02:	push   r12
  40df04:	push   r13
  40df06:	sub    rsp,0x8
  40df0a:	mov    rsi,rdx
  40df0d:	mov    rdi,rcx
  40df10:	lea    r12,[rip+0x162d9]        # 4241f0 <__swc_bss_base_0a4ed24b+0x1b0>
  40df17:	mov    rcx,r12
  40df1a:	call   4098c0 <__swc_fn_0a4ed24b_000135_e3032dc2>
  40df1f:	xor    eax,eax
  40df21:	mov    rcx,QWORD PTR [rip+0x162d0]        # 4241f8 <__swc_bss_base_0a4ed24b+0x1b8>
  40df28:	mov    r13,rcx
  40df2b:	test   r13,r13
  40df2e:	je     40df7b <__swc_fn_0a4ed24b_000020_a66e8b97+0x7b>
  40df30:	mov    rcx,QWORD PTR [r13+0x10]
  40df34:	cmp    DWORD PTR [r13+0x28],esi
  40df38:	jne    40df70 <__swc_fn_0a4ed24b_000020_a66e8b97+0x70>
  40df3a:	test   rax,rax
  40df3d:	jne    40df48 <__swc_fn_0a4ed24b_000020_a66e8b97+0x48>
  40df3f:	mov    QWORD PTR [rip+0x162b2],rcx        # 4241f8 <__swc_bss_base_0a4ed24b+0x1b8>
  40df46:	jmp    40df4c <__swc_fn_0a4ed24b_000020_a66e8b97+0x4c>
  40df48:	mov    QWORD PTR [rax+0x10],rcx
  40df4c:	vxorps xmm0,xmm0,xmm0
  40df50:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40df56:	mov    QWORD PTR [r13+0x8],rdi
  40df5a:	mov    rcx,r12
  40df5d:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  40df62:	mov    rax,r13
  40df65:	add    rsp,0x8
  40df69:	pop    r13
  40df6b:	pop    r12
  40df6d:	pop    rdi
  40df6e:	pop    rsi
  40df6f:	ret
  40df70:	mov    rax,r13
  40df73:	mov    r13,rcx
  40df76:	test   rcx,rcx
  40df79:	jne    40df30 <__swc_fn_0a4ed24b_000020_a66e8b97+0x30>
  40df7b:	mov    ecx,esi
  40df7d:	call   40aa00 <__swc_fn_0a4ed24b_000019_2cc1532c>
  40df82:	mov    rsi,rax
  40df85:	test   rax,rax
  40df88:	jne    40df9f <__swc_fn_0a4ed24b_000020_a66e8b97+0x9f>
  40df8a:	mov    rcx,r12
  40df8d:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  40df92:	xor    eax,eax
  40df94:	add    rsp,0x8
  40df98:	pop    r13
  40df9a:	pop    r12
  40df9c:	pop    rdi
  40df9d:	pop    rsi
  40df9e:	ret
  40df9f:	mov    QWORD PTR [rsi+0x8],rdi
  40dfa3:	mov    rcx,r12
  40dfa6:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  40dfab:	mov    rax,rsi
  40dfae:	add    rsp,0x8
  40dfb2:	pop    r13
  40dfb4:	pop    r12
  40dfb6:	pop    rdi
  40dfb7:	pop    rsi
  40dfb8:	ret
  40dfb9:	add    BYTE PTR [rax],al
  40dfbb:	add    BYTE PTR [rax],al
  40dfbd:	add    BYTE PTR [rax],al
	...

000000000040dfc0 <__swc_fn_0a4ed24b_000023_4aca8b9e>:
  40dfc0:	vxorps xmm0,xmm0,xmm0
  40dfc4:	xor    eax,eax
  40dfc6:	cs nop WORD PTR [rax+rax*1+0x0]
  40dfd0:	cs nop WORD PTR [rax+rax*1+0x0]
  40dfda:	nop    WORD PTR [rax+rax*1+0x0]
  40dfe0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40dfe5:	add    rax,0x10
  40dfe9:	cmp    rax,0x2b00
  40dff0:	jne    40dfe0 <__swc_fn_0a4ed24b_000023_4aca8b9e+0x20>
  40dff2:	ret
	...

000000000040e000 <__swc_fn_0a4ed24b_000026_4aca8b9e>:
  40e000:	vxorps xmm0,xmm0,xmm0
  40e004:	vmovups XMMWORD PTR [rcx],xmm0
  40e008:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e00d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e012:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e017:	ret
	...

000000000040e020 <__swc_fn_0a4ed24b_000029_4aca8b9e>:
  40e020:	vxorps xmm0,xmm0,xmm0
  40e024:	vmovups XMMWORD PTR [rcx],xmm0
  40e028:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e02d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e032:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e037:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40e03c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40e041:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40e046:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40e04b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40e053:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40e05b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40e063:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40e06b:	mov    QWORD PTR [rcx+0xc0],0x0
  40e076:	ret
	...

000000000040e080 <__swc_fn_0a4ed24b_000032_84881cd8>:
  40e080:	push   rsi
  40e081:	push   rdi
  40e082:	sub    rsp,0x8
  40e086:	mov    rsi,rcx
  40e089:	lea    rdi,[rip+0x13f70]        # 422000 <__swc_data_base_0a4ed24b>
  40e090:	mov    rax,QWORD PTR [rdi]
  40e093:	cmp    rax,0xffffffffffffffff
  40e097:	je     40e09e <__swc_fn_0a4ed24b_000032_84881cd8+0x1e>
  40e099:	mov    rdi,rax
  40e09c:	jmp    40e0cb <__swc_fn_0a4ed24b_000032_84881cd8+0x4b>
  40e09e:	call   4095a0 <__swc_fn_0a4ed24b_000123_9d2cbd72>
  40e0a3:	mov    rcx,rax
  40e0a6:	cmp    rax,0xffffffffffffffff
  40e0aa:	je     40e0dc <__swc_fn_0a4ed24b_000032_84881cd8+0x5c>
  40e0ac:	mov    rax,0xffffffffffffffff
  40e0b3:	lock cmpxchg QWORD PTR [rdi],rcx
  40e0b8:	cmp    rax,0xffffffffffffffff
  40e0bc:	je     40e0c8 <__swc_fn_0a4ed24b_000032_84881cd8+0x48>
  40e0be:	mov    rdi,rax
  40e0c1:	call   40cdf0 <__swc_fn_0a4ed24b_000124_667fbf24>
  40e0c6:	jmp    40e0cb <__swc_fn_0a4ed24b_000032_84881cd8+0x4b>
  40e0c8:	mov    rdi,rcx
  40e0cb:	cmp    rdi,0xffffffffffffffff
  40e0cf:	je     40e0dc <__swc_fn_0a4ed24b_000032_84881cd8+0x5c>
  40e0d1:	mov    rcx,rdi
  40e0d4:	mov    rdx,rsi
  40e0d7:	call   4101d0 <__swc_fn_0a4ed24b_000125_ce762363>
  40e0dc:	add    rsp,0x8
  40e0e0:	pop    rdi
  40e0e1:	pop    rsi
  40e0e2:	ret
	...

000000000040e0f0 <__swc_fn_0a4ed24b_000035_95622a2b>:
  40e0f0:	sub    rsp,0x38
  40e0f4:	mov    rax,rdx
  40e0f7:	test   dl,dl
  40e0f9:	jne    40e111 <__swc_fn_0a4ed24b_000035_95622a2b+0x21>
  40e0fb:	mov    rax,r8
  40e0fe:	test   r8b,r8b
  40e101:	cmove  eax,r9d
  40e105:	test   al,al
  40e107:	cmove  eax,r10d
  40e10b:	test   al,al
  40e10d:	cmove  eax,r11d
  40e111:	test   al,al
  40e113:	jne    40e11a <__swc_fn_0a4ed24b_000035_95622a2b+0x2a>
  40e115:	add    rsp,0x38
  40e119:	ret
  40e11a:	lea    rcx,[rip+0x4fef]        # 413110 <__swc_rdata_base_0a4ed24b>
  40e121:	vmovups xmm0,XMMWORD PTR [rip+0x4ff7]        # 413120 <__swc_rdata_base_0a4ed24b+0x10>
  40e129:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e12f:	vmovups xmm0,XMMWORD PTR [rip+0x4ff9]        # 413130 <__swc_rdata_base_0a4ed24b+0x20>
  40e137:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e13d:	vmovups xmm0,XMMWORD PTR [rip+0x4ffb]        # 413140 <__swc_rdata_base_0a4ed24b+0x30>
  40e145:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e14b:	lea    rdx,[rsp+0x8]
  40e150:	call   40c620 <__swc_fn_0a4ed24b_000103_67100064>
  40e155:	jmp    40e115 <__swc_fn_0a4ed24b_000035_95622a2b+0x25>
	...

000000000040e160 <__swc_fn_0a4ed24b_000038_788ceb38>:
  40e160:	sub    rsp,0x8
  40e164:	mov    eax,0x1000
  40e169:	test   eax,eax
  40e16b:	mov    r8d,0x8
  40e171:	cmove  eax,r8d
  40e175:	dec    rax
  40e178:	mov    r8,0xffffffffffffffff
  40e17f:	sub    r8,rax
  40e182:	cmp    rdx,r8
  40e185:	ja     40e195 <__swc_fn_0a4ed24b_000038_788ceb38+0x35>
  40e187:	add    rdx,rax
  40e18a:	not    rax
  40e18d:	mov    r8,rdx
  40e190:	and    r8,rax
  40e193:	jne    40e19c <__swc_fn_0a4ed24b_000038_788ceb38+0x3c>
  40e195:	xor    eax,eax
  40e197:	add    rsp,0x8
  40e19b:	ret
  40e19c:	mov    rdx,r8
  40e19f:	call   40ad20 <__swc_fn_0a4ed24b_000037_b4982903>
  40e1a4:	add    rsp,0x8
  40e1a8:	ret
  40e1a9:	add    BYTE PTR [rax],al
  40e1ab:	add    BYTE PTR [rax],al
  40e1ad:	add    BYTE PTR [rax],al
	...

000000000040e1b0 <__swc_fn_0a4ed24b_000041_414cc921>:
  40e1b0:	push   rsi
  40e1b1:	push   rdi
  40e1b2:	sub    rsp,0x8
  40e1b6:	mov    rsi,rdx
  40e1b9:	mov    rdi,rcx
  40e1bc:	test   rdx,rdx
  40e1bf:	je     40e1db <__swc_fn_0a4ed24b_000041_414cc921+0x2b>
  40e1c1:	xor    ecx,ecx
  40e1c3:	call   407720 <__swc_fn_0a4ed24b_000033_7ca1566d>
  40e1c8:	mov    rax,QWORD PTR [rsi]
  40e1cb:	test   rax,rax
  40e1ce:	je     40e1db <__swc_fn_0a4ed24b_000041_414cc921+0x2b>
  40e1d0:	mov    rcx,rax
  40e1d3:	mov    rdx,rsi
  40e1d6:	call   407840 <__swc_fn_0a4ed24b_000042_bab03645>
  40e1db:	mov    rcx,rdi
  40e1de:	call   40ad80 <__swc_fn_0a4ed24b_000040_6895916d>
  40e1e3:	mov    rsi,rax
  40e1e6:	test   rax,rax
  40e1e9:	jne    40e1f4 <__swc_fn_0a4ed24b_000041_414cc921+0x44>
  40e1eb:	xor    eax,eax
  40e1ed:	add    rsp,0x8
  40e1f1:	pop    rdi
  40e1f2:	pop    rsi
  40e1f3:	ret
  40e1f4:	mov    rcx,rsi
  40e1f7:	call   407720 <__swc_fn_0a4ed24b_000033_7ca1566d>
  40e1fc:	mov    rax,rsi
  40e1ff:	add    rsp,0x8
  40e203:	pop    rdi
  40e204:	pop    rsi
  40e205:	ret
	...

000000000040e210 <__swc_fn_0a4ed24b_000044_9c2ade9b>:
  40e210:	movzx  eax,BYTE PTR [r8+0x39]
  40e215:	lea    rax,[rax+rax*4]
  40e219:	lea    rax,[rdx+rax*8+0x28]
  40e21e:	mov    ecx,DWORD PTR [r8+0x6c]
  40e222:	test   ecx,ecx
  40e224:	je     40e25d <__swc_fn_0a4ed24b_000044_9c2ade9b+0x4d>
  40e226:	mov    rcx,QWORD PTR [r8+0x50]
  40e22a:	test   rcx,rcx
  40e22d:	je     40e239 <__swc_fn_0a4ed24b_000044_9c2ade9b+0x29>
  40e22f:	mov    rax,QWORD PTR [r8+0x48]
  40e233:	mov    QWORD PTR [rcx+0x48],rax
  40e237:	jmp    40e241 <__swc_fn_0a4ed24b_000044_9c2ade9b+0x31>
  40e239:	mov    rcx,QWORD PTR [r8+0x48]
  40e23d:	mov    QWORD PTR [rax+0x18],rcx
  40e241:	mov    rax,QWORD PTR [r8+0x48]
  40e245:	test   rax,rax
  40e248:	je     40e252 <__swc_fn_0a4ed24b_000044_9c2ade9b+0x42>
  40e24a:	mov    rcx,QWORD PTR [r8+0x50]
  40e24e:	mov    QWORD PTR [rax+0x50],rcx
  40e252:	vxorps xmm0,xmm0,xmm0
  40e256:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e25c:	ret
  40e25d:	mov    rcx,QWORD PTR [r8+0x50]
  40e261:	test   rcx,rcx
  40e264:	je     40e270 <__swc_fn_0a4ed24b_000044_9c2ade9b+0x60>
  40e266:	mov    rdx,QWORD PTR [r8+0x48]
  40e26a:	mov    QWORD PTR [rcx+0x48],rdx
  40e26e:	jmp    40e278 <__swc_fn_0a4ed24b_000044_9c2ade9b+0x68>
  40e270:	mov    rcx,QWORD PTR [r8+0x48]
  40e274:	mov    QWORD PTR [rax+0x8],rcx
  40e278:	mov    rcx,QWORD PTR [r8+0x48]
  40e27c:	test   rcx,rcx
  40e27f:	je     40e28b <__swc_fn_0a4ed24b_000044_9c2ade9b+0x7b>
  40e281:	mov    rdx,QWORD PTR [r8+0x50]
  40e285:	mov    QWORD PTR [rcx+0x50],rdx
  40e289:	jmp    40e293 <__swc_fn_0a4ed24b_000044_9c2ade9b+0x83>
  40e28b:	mov    rcx,QWORD PTR [r8+0x50]
  40e28f:	mov    QWORD PTR [rax+0x10],rcx
  40e293:	cmp    QWORD PTR [rax],r8
  40e296:	jne    40e29f <__swc_fn_0a4ed24b_000044_9c2ade9b+0x8f>
  40e298:	mov    QWORD PTR [rax],0x0
  40e29f:	vxorps xmm0,xmm0,xmm0
  40e2a3:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e2a9:	ret
  40e2aa:	add    BYTE PTR [rax],al
  40e2ac:	add    BYTE PTR [rax],al
	...

000000000040e2b0 <__swc_fn_0a4ed24b_000047_bc5ec610>:
  40e2b0:	sub    rsp,0x8
  40e2b4:	mov    r9,r8
  40e2b7:	mov    r10,rdx
  40e2ba:	call   40e210 <__swc_fn_0a4ed24b_000044_9c2ade9b>
  40e2bf:	mov    DWORD PTR [r9+0x6c],0x0
  40e2c7:	movzx  eax,BYTE PTR [r9+0x39]
  40e2cc:	lea    rax,[rax+rax*4]
  40e2d0:	lea    rax,[r10+rax*8+0x28]
  40e2d5:	mov    rcx,QWORD PTR [rax+0x10]
  40e2d9:	mov    QWORD PTR [r9+0x50],rcx
  40e2dd:	mov    QWORD PTR [r9+0x48],0x0
  40e2e5:	mov    rcx,QWORD PTR [rax+0x10]
  40e2e9:	test   rcx,rcx
  40e2ec:	je     40e2f4 <__swc_fn_0a4ed24b_000047_bc5ec610+0x44>
  40e2ee:	mov    QWORD PTR [rcx+0x48],r9
  40e2f2:	jmp    40e2f8 <__swc_fn_0a4ed24b_000047_bc5ec610+0x48>
  40e2f4:	mov    QWORD PTR [rax+0x8],r9
  40e2f8:	mov    QWORD PTR [rax+0x10],r9
  40e2fc:	add    rsp,0x8
  40e300:	ret
	...

000000000040e320 <__swc_fn_0a4ed24b_000050_ab8077df>:
  40e320:	push   rsi
  40e321:	push   rdi
  40e322:	push   r12
  40e324:	push   r13
  40e326:	push   r14
  40e328:	push   r15
  40e32a:	sub    rsp,0x1f8
  40e331:	mov    esi,r8d
  40e334:	mov    QWORD PTR [rsp+0x1e8],rsi
  40e33c:	mov    rdi,rcx
  40e33f:	mov    r12,rdx
  40e342:	lea    r13,[rsi+rsi*4]
  40e346:	lea    r13,[rdx+r13*8+0x28]
  40e34b:	call   407ca0 <__swc_fn_0a4ed24b_000048_c877e9d2>
  40e350:	add    DWORD PTR [r12+0x24],0x1
  40e356:	test   BYTE PTR [r12+0x24],0x3f
  40e35c:	jne    40e366 <__swc_fn_0a4ed24b_000050_ab8077df+0x46>
  40e35e:	mov    rcx,rdi
  40e361:	call   40af00 <__swc_fn_0a4ed24b_000049_2ff013cc>
  40e366:	mov    rax,QWORD PTR [r13+0x8]
  40e36a:	mov    r14,rax
  40e36d:	nop    DWORD PTR [rax]
  40e370:	test   r14,r14
  40e373:	jne    40e382 <__swc_fn_0a4ed24b_000050_ab8077df+0x62>
  40e375:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40e37d:	jmp    40e489 <__swc_fn_0a4ed24b_000050_ab8077df+0x169>
  40e382:	mov    r15,QWORD PTR [r14+0x48]
  40e386:	mov    rcx,r14
  40e389:	call   4073f0 <__swc_fn_0a4ed24b_000009_d7e2bb25>
  40e38e:	mov    rax,QWORD PTR [r14]
  40e391:	test   rax,rax
  40e394:	je     40e3a6 <__swc_fn_0a4ed24b_000050_ab8077df+0x86>
  40e396:	mov    rcx,QWORD PTR [rax]
  40e399:	mov    QWORD PTR [r14],rcx
  40e39c:	add    DWORD PTR [r14+0x28],0x1
  40e3a1:	mov    rsi,rax
  40e3a4:	jmp    40e3c5 <__swc_fn_0a4ed24b_000050_ab8077df+0xa5>
  40e3a6:	mov    rax,QWORD PTR [r14+0x18]
  40e3aa:	cmp    QWORD PTR [r14+0x20],rax
  40e3ae:	jae    40e3c3 <__swc_fn_0a4ed24b_000050_ab8077df+0xa3>
  40e3b0:	mov    rsi,QWORD PTR [r14+0x20]
  40e3b4:	mov    eax,DWORD PTR [r14+0x2c]
  40e3b8:	add    QWORD PTR [r14+0x20],rax
  40e3bc:	add    DWORD PTR [r14+0x28],0x1
  40e3c1:	jmp    40e3c5 <__swc_fn_0a4ed24b_000050_ab8077df+0xa5>
  40e3c3:	xor    esi,esi
  40e3c5:	test   rsi,rsi
  40e3c8:	jne    40e40d <__swc_fn_0a4ed24b_000050_ab8077df+0xed>
  40e3ca:	mov    rcx,r14
  40e3cd:	call   407320 <__swc_fn_0a4ed24b_000006_a23dca5f>
  40e3d2:	test   al,al
  40e3d4:	je     40e40d <__swc_fn_0a4ed24b_000050_ab8077df+0xed>
  40e3d6:	mov    rax,QWORD PTR [r14]
  40e3d9:	test   rax,rax
  40e3dc:	je     40e3eb <__swc_fn_0a4ed24b_000050_ab8077df+0xcb>
  40e3de:	mov    rcx,QWORD PTR [rax]
  40e3e1:	mov    QWORD PTR [r14],rcx
  40e3e4:	add    DWORD PTR [r14+0x28],0x1
  40e3e9:	jmp    40e40a <__swc_fn_0a4ed24b_000050_ab8077df+0xea>
  40e3eb:	mov    rax,QWORD PTR [r14+0x18]
  40e3ef:	cmp    QWORD PTR [r14+0x20],rax
  40e3f3:	jae    40e408 <__swc_fn_0a4ed24b_000050_ab8077df+0xe8>
  40e3f5:	mov    rax,QWORD PTR [r14+0x20]
  40e3f9:	mov    ecx,DWORD PTR [r14+0x2c]
  40e3fd:	add    QWORD PTR [r14+0x20],rcx
  40e401:	add    DWORD PTR [r14+0x28],0x1
  40e406:	jmp    40e40a <__swc_fn_0a4ed24b_000050_ab8077df+0xea>
  40e408:	xor    eax,eax
  40e40a:	mov    rsi,rax
  40e40d:	test   rsi,rsi
  40e410:	jne    40e463 <__swc_fn_0a4ed24b_000050_ab8077df+0x143>
  40e412:	mov    rcx,rdi
  40e415:	mov    rdx,r12
  40e418:	mov    r8,r14
  40e41b:	call   40ae60 <__swc_fn_0a4ed24b_000046_88f44774>
  40e420:	test   al,al
  40e422:	jne    40e463 <__swc_fn_0a4ed24b_000050_ab8077df+0x143>
  40e424:	mov    rcx,r14
  40e427:	call   4073f0 <__swc_fn_0a4ed24b_000009_d7e2bb25>
  40e42c:	mov    rax,QWORD PTR [r14]
  40e42f:	test   rax,rax
  40e432:	je     40e441 <__swc_fn_0a4ed24b_000050_ab8077df+0x121>
  40e434:	mov    rcx,QWORD PTR [rax]
  40e437:	mov    QWORD PTR [r14],rcx
  40e43a:	add    DWORD PTR [r14+0x28],0x1
  40e43f:	jmp    40e460 <__swc_fn_0a4ed24b_000050_ab8077df+0x140>
  40e441:	mov    rax,QWORD PTR [r14+0x18]
  40e445:	cmp    QWORD PTR [r14+0x20],rax
  40e449:	jae    40e45e <__swc_fn_0a4ed24b_000050_ab8077df+0x13e>
  40e44b:	mov    rax,QWORD PTR [r14+0x20]
  40e44f:	mov    ecx,DWORD PTR [r14+0x2c]
  40e453:	add    QWORD PTR [r14+0x20],rcx
  40e457:	add    DWORD PTR [r14+0x28],0x1
  40e45c:	jmp    40e460 <__swc_fn_0a4ed24b_000050_ab8077df+0x140>
  40e45e:	xor    eax,eax
  40e460:	mov    rsi,rax
  40e463:	test   rsi,rsi
  40e466:	je     40e481 <__swc_fn_0a4ed24b_000050_ab8077df+0x161>
  40e468:	mov    QWORD PTR [r13+0x0],r14
  40e46c:	mov    rax,rsi
  40e46f:	add    rsp,0x1f8
  40e476:	pop    r15
  40e478:	pop    r14
  40e47a:	pop    r13
  40e47c:	pop    r12
  40e47e:	pop    rdi
  40e47f:	pop    rsi
  40e480:	ret
  40e481:	mov    r14,r15
  40e484:	jmp    40e370 <__swc_fn_0a4ed24b_000050_ab8077df+0x50>
  40e489:	cs nop WORD PTR [rax+rax*1+0x0]
  40e493:	cs nop WORD PTR [rax+rax*1+0x0]
  40e49d:	nop    DWORD PTR [rax]
  40e4a0:	mov    rcx,rdi
  40e4a3:	mov    rdx,r12
  40e4a6:	mov    r8d,esi
  40e4a9:	call   4079e0 <__swc_fn_0a4ed24b_000045_1fe0f4e2>
  40e4ae:	mov    r14,rax
  40e4b1:	test   rax,rax
  40e4b4:	jne    40e4ca <__swc_fn_0a4ed24b_000050_ab8077df+0x1aa>
  40e4b6:	xor    eax,eax
  40e4b8:	add    rsp,0x1f8
  40e4bf:	pop    r15
  40e4c1:	pop    r14
  40e4c3:	pop    r13
  40e4c5:	pop    r12
  40e4c7:	pop    rdi
  40e4c8:	pop    rsi
  40e4c9:	ret
  40e4ca:	mov    QWORD PTR [r13+0x0],r14
  40e4ce:	mov    rax,QWORD PTR [r14]
  40e4d1:	test   rax,rax
  40e4d4:	je     40e4e6 <__swc_fn_0a4ed24b_000050_ab8077df+0x1c6>
  40e4d6:	mov    rcx,QWORD PTR [rax]
  40e4d9:	mov    QWORD PTR [r14],rcx
  40e4dc:	add    DWORD PTR [r14+0x28],0x1
  40e4e1:	mov    r15,rax
  40e4e4:	jmp    40e506 <__swc_fn_0a4ed24b_000050_ab8077df+0x1e6>
  40e4e6:	mov    rax,QWORD PTR [r14+0x18]
  40e4ea:	cmp    QWORD PTR [r14+0x20],rax
  40e4ee:	jae    40e503 <__swc_fn_0a4ed24b_000050_ab8077df+0x1e3>
  40e4f0:	mov    r15,QWORD PTR [r14+0x20]
  40e4f4:	mov    eax,DWORD PTR [r14+0x2c]
  40e4f8:	add    QWORD PTR [r14+0x20],rax
  40e4fc:	add    DWORD PTR [r14+0x28],0x1
  40e501:	jmp    40e506 <__swc_fn_0a4ed24b_000050_ab8077df+0x1e6>
  40e503:	xor    r15d,r15d
  40e506:	test   r15,r15
  40e509:	jne    40e54e <__swc_fn_0a4ed24b_000050_ab8077df+0x22e>
  40e50b:	mov    rcx,r14
  40e50e:	call   407320 <__swc_fn_0a4ed24b_000006_a23dca5f>
  40e513:	test   al,al
  40e515:	je     40e54e <__swc_fn_0a4ed24b_000050_ab8077df+0x22e>
  40e517:	mov    rax,QWORD PTR [r14]
  40e51a:	test   rax,rax
  40e51d:	je     40e52c <__swc_fn_0a4ed24b_000050_ab8077df+0x20c>
  40e51f:	mov    rcx,QWORD PTR [rax]
  40e522:	mov    QWORD PTR [r14],rcx
  40e525:	add    DWORD PTR [r14+0x28],0x1
  40e52a:	jmp    40e54b <__swc_fn_0a4ed24b_000050_ab8077df+0x22b>
  40e52c:	mov    rax,QWORD PTR [r14+0x18]
  40e530:	cmp    QWORD PTR [r14+0x20],rax
  40e534:	jae    40e549 <__swc_fn_0a4ed24b_000050_ab8077df+0x229>
  40e536:	mov    rax,QWORD PTR [r14+0x20]
  40e53a:	mov    ecx,DWORD PTR [r14+0x2c]
  40e53e:	add    QWORD PTR [r14+0x20],rcx
  40e542:	add    DWORD PTR [r14+0x28],0x1
  40e547:	jmp    40e54b <__swc_fn_0a4ed24b_000050_ab8077df+0x22b>
  40e549:	xor    eax,eax
  40e54b:	mov    r15,rax
  40e54e:	test   r15,r15
  40e551:	je     40e4a0 <__swc_fn_0a4ed24b_000050_ab8077df+0x180>
  40e557:	mov    rax,r15
  40e55a:	add    rsp,0x1f8
  40e561:	pop    r15
  40e563:	pop    r14
  40e565:	pop    r13
  40e567:	pop    r12
  40e569:	pop    rdi
  40e56a:	pop    rsi
  40e56b:	ret
  40e56c:	add    BYTE PTR [rax],al
	...

000000000040e570 <__swc_fn_0a4ed24b_000053_82546d94>:
  40e570:	push   rsi
  40e571:	push   rdi
  40e572:	push   r12
  40e574:	mov    rsi,rdx
  40e577:	mov    rax,rdx
  40e57a:	shr    rax,0xc
  40e57e:	movabs rdx,0x9e3779b97f4a7c15
  40e588:	imul   rax,rdx
  40e58c:	shr    rax,0x20
  40e590:	lea    rax,[rax*8+0x0]
  40e598:	shr    rax,0x20
  40e59c:	lea    rax,[rax*8+0x0]
  40e5a4:	lea    rax,[rcx+rax*8+0x40]
  40e5a9:	xor    edx,edx
  40e5ab:	test   dl,dl
  40e5ad:	lea    rdi,[rcx+0x8]
  40e5b1:	cmove  rdi,rax
  40e5b5:	xor    edx,edx
  40e5b7:	test   dl,dl
  40e5b9:	lea    r12,[rcx+0x30]
  40e5bd:	lea    rax,[rax+0x8]
  40e5c1:	cmove  r12,rax
  40e5c5:	mov    rcx,rdi
  40e5c8:	call   4098c0 <__swc_fn_0a4ed24b_000135_e3032dc2>
  40e5cd:	mov    QWORD PTR [rsi+0x30],0x0
  40e5d5:	mov    rax,QWORD PTR [r12]
  40e5d9:	mov    QWORD PTR [rsi+0x38],rax
  40e5dd:	test   rax,rax
  40e5e0:	je     40e5ea <__swc_fn_0a4ed24b_000053_82546d94+0x7a>
  40e5e2:	mov    rax,QWORD PTR [rsi+0x38]
  40e5e6:	mov    QWORD PTR [rax+0x30],rsi
  40e5ea:	mov    QWORD PTR [r12],rsi
  40e5ee:	mov    rcx,rdi
  40e5f1:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  40e5f6:	pop    r12
  40e5f8:	pop    rdi
  40e5f9:	pop    rsi
  40e5fa:	ret
  40e5fb:	add    BYTE PTR [rax],al
  40e5fd:	add    BYTE PTR [rax],al
	...

000000000040e600 <__swc_fn_0a4ed24b_000056_38b21f11>:
  40e600:	lea    rax,[rdx+rdx*4]
  40e604:	lea    rax,[rcx+rax*8+0x268]
  40e60c:	mov    rdx,QWORD PTR [rax+0x10]
  40e610:	sub    QWORD PTR [rcx+0x2a68],rdx
  40e617:	sub    QWORD PTR [rcx+0x2a70],0x1
  40e61f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40e626:	lea    rdx,[rdx+rdx*4]
  40e62a:	lea    rdx,[rcx+rdx*8+0x268]
  40e632:	vmovups xmm0,XMMWORD PTR [rdx]
  40e636:	vmovups XMMWORD PTR [rax],xmm0
  40e63a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40e63f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e644:	mov    rcx,QWORD PTR [rdx+0x20]
  40e648:	mov    QWORD PTR [rax+0x20],rcx
  40e64c:	ret
  40e64d:	add    BYTE PTR [rax],al
	...

000000000040e650 <__swc_fn_0a4ed24b_000059_3ca3ac64>:
  40e650:	push   rsi
  40e651:	push   rdi
  40e652:	push   r12
  40e654:	push   r13
  40e656:	sub    rsp,0x8
  40e65a:	mov    rsi,r8
  40e65d:	mov    rdi,rcx
  40e660:	mov    r12,rdx
  40e663:	xor    r13d,r13d
  40e666:	cs nop WORD PTR [rax+rax*1+0x0]
  40e670:	mov    eax,DWORD PTR [r12+0x730]
  40e678:	cmp    r13d,eax
  40e67b:	jae    40e6e1 <__swc_fn_0a4ed24b_000059_3ca3ac64+0x91>
  40e67d:	lea    rax,[r13+r13*4+0x0]
  40e682:	lea    rax,[r12+rax*8+0x738]
  40e68a:	mov    rdx,QWORD PTR [rax]
  40e68d:	mov    r8,QWORD PTR [rax+0x8]
  40e691:	mov    r9,QWORD PTR [rax+0x10]
  40e695:	cmp    QWORD PTR [rax+0x20],rsi
  40e699:	jb     40e6a0 <__swc_fn_0a4ed24b_000059_3ca3ac64+0x50>
  40e69b:	inc    r13d
  40e69e:	jmp    40e670 <__swc_fn_0a4ed24b_000059_3ca3ac64+0x20>
  40e6a0:	sub    DWORD PTR [r12+0x730],0x1
  40e6a9:	mov    ecx,DWORD PTR [r12+0x730]
  40e6b1:	lea    rcx,[rcx+rcx*4]
  40e6b5:	lea    rcx,[r12+rcx*8+0x738]
  40e6bd:	vmovups xmm0,XMMWORD PTR [rcx]
  40e6c1:	vmovups XMMWORD PTR [rax],xmm0
  40e6c5:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40e6ca:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e6cf:	mov    rcx,QWORD PTR [rcx+0x20]
  40e6d3:	mov    QWORD PTR [rax+0x20],rcx
  40e6d7:	mov    rcx,rdi
  40e6da:	call   407750 <__swc_fn_0a4ed24b_000039_40d1e569>
  40e6df:	jmp    40e670 <__swc_fn_0a4ed24b_000059_3ca3ac64+0x20>
  40e6e1:	add    rsp,0x8
  40e6e5:	pop    r13
  40e6e7:	pop    r12
  40e6e9:	pop    rdi
  40e6ea:	pop    rsi
  40e6eb:	ret
  40e6ec:	add    BYTE PTR [rax],al
	...

000000000040e6f0 <__swc_fn_0a4ed24b_000062_7e482c5f>:
  40e6f0:	push   rsi
  40e6f1:	push   rdi
  40e6f2:	push   r12
  40e6f4:	push   r13
  40e6f6:	push   r14
  40e6f8:	mov    rsi,rcx
  40e6fb:	mov    rdi,rdx
  40e6fe:	mov    r12,QWORD PTR [rdi]
  40e701:	mov    r13,QWORD PTR [rdi+0x18]
  40e705:	mov    rax,r12
  40e708:	add    rax,QWORD PTR [rdi+0x8]
  40e70c:	sub    rax,r13
  40e70f:	cmp    r8,rax
  40e712:	jbe    40e71d <__swc_fn_0a4ed24b_000062_7e482c5f+0x2d>
  40e714:	pop    r14
  40e716:	pop    r13
  40e718:	pop    r12
  40e71a:	pop    rdi
  40e71b:	pop    rsi
  40e71c:	ret
  40e71d:	lea    rax,[r13+r8*1+0x0]
  40e722:	sub    rax,r12
  40e725:	mov    ecx,0x1000
  40e72a:	test   ecx,ecx
  40e72c:	mov    edx,0x8
  40e731:	cmove  ecx,edx
  40e734:	dec    rcx
  40e737:	mov    rdx,0xffffffffffffffff
  40e73e:	sub    rdx,rcx
  40e741:	cmp    rax,rdx
  40e744:	jbe    40e74b <__swc_fn_0a4ed24b_000062_7e482c5f+0x5b>
  40e746:	xor    r14d,r14d
  40e749:	jmp    40e756 <__swc_fn_0a4ed24b_000062_7e482c5f+0x66>
  40e74b:	add    rax,rcx
  40e74e:	andn   rax,rcx,rax
  40e753:	mov    r14,rax
  40e756:	mov    rax,QWORD PTR [rdi+0x10]
  40e75a:	cmp    r14,rax
  40e75d:	ja     40e768 <__swc_fn_0a4ed24b_000062_7e482c5f+0x78>
  40e75f:	pop    r14
  40e761:	pop    r13
  40e763:	pop    r12
  40e765:	pop    rdi
  40e766:	pop    rsi
  40e767:	ret
  40e768:	mov    rax,r12
  40e76b:	add    rax,QWORD PTR [rdi+0x10]
  40e76f:	mov    rdx,r14
  40e772:	sub    rdx,QWORD PTR [rdi+0x10]
  40e776:	mov    rcx,rax
  40e779:	call   4072a0 <__swc_fn_0a4ed24b_000003_7ab4792e>
  40e77e:	test   al,al
  40e780:	jne    40e78b <__swc_fn_0a4ed24b_000062_7e482c5f+0x9b>
  40e782:	pop    r14
  40e784:	pop    r13
  40e786:	pop    r12
  40e788:	pop    rdi
  40e789:	pop    rsi
  40e78a:	ret
  40e78b:	add    r12,r14
  40e78e:	sub    r12,r13
  40e791:	mov    rcx,r12
  40e794:	sub    rcx,QWORD PTR [rdi+0x28]
  40e798:	mov    rdx,QWORD PTR [rsi+0x250]
  40e79f:	nop
  40e7a0:	lea    r8,[rdx+rcx*1]
  40e7a4:	mov    rax,rdx
  40e7a7:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40e7b0:	cmp    rax,rdx
  40e7b3:	je     40e7ba <__swc_fn_0a4ed24b_000062_7e482c5f+0xca>
  40e7b5:	mov    rdx,rax
  40e7b8:	jmp    40e7a0 <__swc_fn_0a4ed24b_000062_7e482c5f+0xb0>
  40e7ba:	mov    QWORD PTR [rdi+0x10],r14
  40e7be:	mov    QWORD PTR [rdi+0x28],r12
  40e7c2:	pop    r14
  40e7c4:	pop    r13
  40e7c6:	pop    r12
  40e7c8:	pop    rdi
  40e7c9:	pop    rsi
  40e7ca:	ret
  40e7cb:	add    BYTE PTR [rax],al
  40e7cd:	add    BYTE PTR [rax],al
	...

000000000040e7d0 <__swc_fn_0a4ed24b_000065_f9f4b610>:
  40e7d0:	push   rbx
  40e7d1:	push   rsi
  40e7d2:	push   rdi
  40e7d3:	push   r12
  40e7d5:	push   r13
  40e7d7:	sub    rsp,0xe0
  40e7de:	mov    rbx,rdx
  40e7e1:	mov    rsi,rcx
  40e7e4:	cmp    DWORD PTR [rbx+0x58],0x0
  40e7e8:	je     40e80c <__swc_fn_0a4ed24b_000065_f9f4b610+0x3c>
  40e7ea:	mov    eax,DWORD PTR [rbx+0x58]
  40e7ed:	sub    eax,0x1
  40e7f0:	test   DWORD PTR [rbx+0x58],eax
  40e7f3:	je     40e80c <__swc_fn_0a4ed24b_000065_f9f4b610+0x3c>
  40e7f5:	mov    QWORD PTR [rbx+0x40],0x0
  40e7fd:	add    rsp,0xe0
  40e804:	pop    r13
  40e806:	pop    r12
  40e808:	pop    rdi
  40e809:	pop    rsi
  40e80a:	pop    rbx
  40e80b:	ret
  40e80c:	mov    rax,QWORD PTR [rbx+0x40]
  40e810:	test   rax,rax
  40e813:	jne    40e82f <__swc_fn_0a4ed24b_000065_f9f4b610+0x5f>
  40e815:	mov    rcx,rsi
  40e818:	mov    rdx,rbx
  40e81b:	call   40bb10 <__swc_fn_0a4ed24b_000064_b0d63361>
  40e820:	add    rsp,0xe0
  40e827:	pop    r13
  40e829:	pop    r12
  40e82b:	pop    rdi
  40e82c:	pop    rsi
  40e82d:	pop    rbx
  40e82e:	ret
  40e82f:	cmp    QWORD PTR [rbx+0x48],0x0
  40e834:	jne    40e850 <__swc_fn_0a4ed24b_000065_f9f4b610+0x80>
  40e836:	mov    rcx,rsi
  40e839:	mov    rdx,rbx
  40e83c:	call   407f90 <__swc_fn_0a4ed24b_000066_254b71af>
  40e841:	add    rsp,0xe0
  40e848:	pop    r13
  40e84a:	pop    r12
  40e84c:	pop    rdi
  40e84d:	pop    rsi
  40e84e:	pop    rbx
  40e84f:	ret
  40e850:	mov    rdi,QWORD PTR [rbx+0x40]
  40e854:	lea    rax,[rip+0x15815]        # 424070 <__swc_bss_base_0a4ed24b+0x30>
  40e85b:	mov    rcx,rdi
  40e85e:	sub    rcx,QWORD PTR [rax+0x8]
  40e862:	mov    rax,QWORD PTR [rip+0x15817]        # 424080 <__swc_bss_base_0a4ed24b+0x40>
  40e869:	cmp    rcx,rax
  40e86c:	jae    40e898 <__swc_fn_0a4ed24b_000065_f9f4b610+0xc8>
  40e86e:	mov    rax,rdi
  40e871:	and    rax,0xffffffffffc00000
  40e878:	mov    rcx,rdi
  40e87b:	shr    rcx,0x10
  40e87f:	and    ecx,0x3f
  40e882:	mov    edx,DWORD PTR [rax+0x28]
  40e885:	shrx   ecx,ecx,edx
  40e88a:	shl    rcx,0x4
  40e88e:	lea    r12,[rax+rcx*8+0x80]
  40e896:	jmp    40e8a3 <__swc_fn_0a4ed24b_000065_f9f4b610+0xd3>
  40e898:	mov    rcx,rdi
  40e89b:	call   40ab90 <__swc_fn_0a4ed24b_000022_3a2e2048>
  40e8a0:	mov    r12,rax
  40e8a3:	test   r12,r12
  40e8a6:	je     40e8b5 <__swc_fn_0a4ed24b_000065_f9f4b610+0xe5>
  40e8a8:	mov    eax,DWORD PTR [r12+0x2c]
  40e8ad:	mov    r9d,eax
  40e8b0:	mov    r13,rax
  40e8b3:	jmp    40e934 <__swc_fn_0a4ed24b_000065_f9f4b610+0x164>
  40e8b5:	mov    rcx,rsi
  40e8b8:	mov    rdx,rdi
  40e8bb:	call   40b1a0 <__swc_fn_0a4ed24b_000052_c7484fb0>
  40e8c0:	mov    rcx,QWORD PTR [rax+0x28]
  40e8c4:	mov    r9,rcx
  40e8c7:	mov    rdx,QWORD PTR [rax+0x20]
  40e8cb:	mov    r13,rdx
  40e8ce:	cmp    QWORD PTR [rbx+0x48],rcx
  40e8d2:	jbe    40e90b <__swc_fn_0a4ed24b_000065_f9f4b610+0x13b>
  40e8d4:	mov    ecx,DWORD PTR [rax+0x48]
  40e8d7:	cmp    DWORD PTR [rbx+0x58],ecx
  40e8da:	ja     40e90b <__swc_fn_0a4ed24b_000065_f9f4b610+0x13b>
  40e8dc:	mov    rcx,rsi
  40e8df:	mov    rdx,rax
  40e8e2:	mov    r8,QWORD PTR [rbx+0x48]
  40e8e6:	mov    QWORD PTR [rsp+0xc8],r9
  40e8ee:	mov    QWORD PTR [rsp+0xd0],rax
  40e8f6:	call   40e6f0 <__swc_fn_0a4ed24b_000062_7e482c5f>
  40e8fb:	mov    r9,QWORD PTR [rsp+0xc8]
  40e903:	mov    rax,QWORD PTR [rsp+0xd0]
  40e90b:	mov    rcx,QWORD PTR [rax+0x28]
  40e90f:	cmp    QWORD PTR [rbx+0x48],rcx
  40e913:	ja     40e934 <__swc_fn_0a4ed24b_000065_f9f4b610+0x164>
  40e915:	mov    ecx,DWORD PTR [rax+0x48]
  40e918:	cmp    DWORD PTR [rbx+0x58],ecx
  40e91b:	ja     40e934 <__swc_fn_0a4ed24b_000065_f9f4b610+0x164>
  40e91d:	mov    rcx,QWORD PTR [rbx+0x48]
  40e921:	mov    QWORD PTR [rax+0x20],rcx
  40e925:	add    rsp,0xe0
  40e92c:	pop    r13
  40e92e:	pop    r12
  40e930:	pop    rdi
  40e931:	pop    rsi
  40e932:	pop    rbx
  40e933:	ret
  40e934:	test   r12,r12
  40e937:	je     40e969 <__swc_fn_0a4ed24b_000065_f9f4b610+0x199>
  40e939:	cmp    QWORD PTR [rbx+0x48],r9
  40e93d:	ja     40e969 <__swc_fn_0a4ed24b_000065_f9f4b610+0x199>
  40e93f:	cmp    DWORD PTR [rbx+0x58],0x40
  40e943:	ja     40e969 <__swc_fn_0a4ed24b_000065_f9f4b610+0x199>
  40e945:	cmp    DWORD PTR [rbx+0x58],0x0
  40e949:	je     40e956 <__swc_fn_0a4ed24b_000065_f9f4b610+0x186>
  40e94b:	mov    ecx,DWORD PTR [rbx+0x58]
  40e94e:	dec    rcx
  40e951:	test   rdi,rcx
  40e954:	jne    40e969 <__swc_fn_0a4ed24b_000065_f9f4b610+0x199>
  40e956:	mov    QWORD PTR [rbx+0x40],rdi
  40e95a:	add    rsp,0xe0
  40e961:	pop    r13
  40e963:	pop    r12
  40e965:	pop    rdi
  40e966:	pop    rsi
  40e967:	pop    rbx
  40e968:	ret
  40e969:	vmovups xmm0,XMMWORD PTR [rbx]
  40e96d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e973:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40e978:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e97e:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40e983:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e989:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40e98e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40e994:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40e999:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40e99f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40e9a4:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40e9aa:	mov    QWORD PTR [rsp+0x48],0x0
  40e9b3:	mov    rcx,rsi
  40e9b6:	lea    rdx,[rsp+0x8]
  40e9bb:	call   40bb10 <__swc_fn_0a4ed24b_000064_b0d63361>
  40e9c0:	mov    rax,QWORD PTR [rsp+0x48]
  40e9c5:	test   rax,rax
  40e9c8:	jne    40e9e1 <__swc_fn_0a4ed24b_000065_f9f4b610+0x211>
  40e9ca:	mov    QWORD PTR [rbx+0x40],0x0
  40e9d2:	add    rsp,0xe0
  40e9d9:	pop    r13
  40e9db:	pop    r12
  40e9dd:	pop    rdi
  40e9de:	pop    rsi
  40e9df:	pop    rbx
  40e9e0:	ret
  40e9e1:	mov    rax,QWORD PTR [rbx+0x48]
  40e9e5:	cmp    r13,rax
  40e9e8:	cmovbe rax,r13
  40e9ec:	mov    rcx,QWORD PTR [rsp+0x48]
  40e9f1:	mov    rdx,rdi
  40e9f4:	mov    r8,rax
  40e9f7:	call   409100 <__swc_fn_0a4ed24b_000105_6fd80914>
  40e9fc:	vmovups xmm0,XMMWORD PTR [rbx]
  40ea00:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40ea06:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40ea0b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40ea11:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40ea16:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40ea1f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40ea24:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40ea2d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40ea32:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40ea3b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40ea40:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40ea49:	mov    QWORD PTR [rsp+0xa8],rdi
  40ea51:	mov    rcx,rsi
  40ea54:	lea    rdx,[rsp+0x68]
  40ea59:	call   407f90 <__swc_fn_0a4ed24b_000066_254b71af>
  40ea5e:	mov    rax,QWORD PTR [rsp+0x48]
  40ea63:	mov    QWORD PTR [rbx+0x40],rax
  40ea67:	add    rsp,0xe0
  40ea6e:	pop    r13
  40ea70:	pop    r12
  40ea72:	pop    rdi
  40ea73:	pop    rsi
  40ea74:	pop    rbx
  40ea75:	ret
	...

000000000040ea80 <__swc_fn_0a4ed24b_000068_7d4c42bf>:
  40ea80:	push   r12
  40ea82:	push   rdi
  40ea83:	push   rsi
  40ea84:	push   r13
  40ea86:	push   r14
  40ea88:	sub    rsp,0x190
  40ea8f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40ea98:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40eaa1:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40eaaa:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40eab3:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40eabc:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40eac5:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40eace:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40ead7:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40eae0:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40eae9:	mov    r12,rcx
  40eaec:	lea    rax,[rip+0x1350d]        # 422000 <__swc_data_base_0a4ed24b>
  40eaf3:	mov    rax,QWORD PTR [rax]
  40eaf6:	cmp    rax,0xffffffffffffffff
  40eafa:	je     40eb09 <__swc_fn_0a4ed24b_000068_7d4c42bf+0x89>
  40eafc:	mov    eax,eax
  40eafe:	mov    edi,eax
  40eb00:	xor    eax,eax
  40eb02:	call   407000 <pthread_getspecific@plt>
  40eb07:	jmp    40eb0b <__swc_fn_0a4ed24b_000068_7d4c42bf+0x8b>
  40eb09:	xor    eax,eax
  40eb0b:	test   rax,rax
  40eb0e:	jne    40eb1d <__swc_fn_0a4ed24b_000068_7d4c42bf+0x9d>
  40eb10:	call   40ac60 <__swc_fn_0a4ed24b_000031_90860ff2>
  40eb15:	mov    rcx,rax
  40eb18:	call   410280 <__swc_fn_0a4ed24b_000128_41c3251c>
  40eb1d:	test   rax,rax
  40eb20:	je     40eb46 <__swc_fn_0a4ed24b_000068_7d4c42bf+0xc6>
  40eb22:	cmp    QWORD PTR [rax],r12
  40eb25:	jne    40eb46 <__swc_fn_0a4ed24b_000068_7d4c42bf+0xc6>
  40eb27:	xor    ecx,ecx
  40eb29:	mov    QWORD PTR [rsp+0xc8],rax
  40eb31:	call   407720 <__swc_fn_0a4ed24b_000033_7ca1566d>
  40eb36:	mov    rdx,QWORD PTR [rsp+0xc8]
  40eb3e:	mov    rcx,r12
  40eb41:	call   407840 <__swc_fn_0a4ed24b_000042_bab03645>
  40eb46:	lea    rsi,[r12+0x10]
  40eb4b:	mov    rcx,rsi
  40eb4e:	call   4098c0 <__swc_fn_0a4ed24b_000135_e3032dc2>
  40eb53:	mov    rdi,QWORD PTR [r12+0x20]
  40eb58:	test   rdi,rdi
  40eb5b:	je     40eb9e <__swc_fn_0a4ed24b_000068_7d4c42bf+0x11e>
  40eb5d:	nop    DWORD PTR [rax]
  40eb60:	mov    rcx,r12
  40eb63:	mov    rdx,rdi
  40eb66:	call   40ae20 <__swc_fn_0a4ed24b_000043_957e4917>
  40eb6b:	mov    rcx,r12
  40eb6e:	mov    rdx,rdi
  40eb71:	mov    r8,0xffffffffffffffff
  40eb78:	call   40e650 <__swc_fn_0a4ed24b_000059_3ca3ac64>
  40eb7d:	mov    rcx,r12
  40eb80:	mov    rdx,rdi
  40eb83:	mov    r8d,0x9b8
  40eb89:	mov    r9d,0x9b8
  40eb8f:	call   407750 <__swc_fn_0a4ed24b_000039_40d1e569>
  40eb94:	mov    rdi,QWORD PTR [r12+0x20]
  40eb99:	test   rdi,rdi
  40eb9c:	jne    40eb60 <__swc_fn_0a4ed24b_000068_7d4c42bf+0xe0>
  40eb9e:	xor    eax,eax
  40eba0:	xchg   QWORD PTR [r12+0x2a80],rax
  40eba8:	test   rax,rax
  40ebab:	je     40ebd1 <__swc_fn_0a4ed24b_000068_7d4c42bf+0x151>
  40ebad:	cs nop WORD PTR [rax+rax*1+0x0]
  40ebb7:	nop    WORD PTR [rax+rax*1+0x0]
  40ebc0:	mov    rcx,rax
  40ebc3:	mov    rax,QWORD PTR [rax+0x78]
  40ebc7:	xor    edx,edx
  40ebc9:	xchg   DWORD PTR [rcx+0x70],edx
  40ebcc:	test   rax,rax
  40ebcf:	jne    40ebc0 <__swc_fn_0a4ed24b_000068_7d4c42bf+0x140>
  40ebd1:	mov    rax,QWORD PTR [r12+0x18]
  40ebd6:	mov    rdi,rax
  40ebd9:	test   rdi,rdi
  40ebdc:	je     40ec71 <__swc_fn_0a4ed24b_000068_7d4c42bf+0x1f1>
  40ebe2:	cs nop WORD PTR [rax+rax*1+0x0]
  40ebec:	nop    DWORD PTR [rax+0x0]
  40ebf0:	mov    rax,QWORD PTR [rdi+0x10]
  40ebf4:	mov    r8d,DWORD PTR [rdi+0x2c]
  40ebf8:	xor    r9d,r9d
  40ebfb:	test   r8,r8
  40ebfe:	jbe    40ec5d <__swc_fn_0a4ed24b_000068_7d4c42bf+0x1dd>
  40ec00:	mov    ecx,r9d
  40ec03:	shl    rcx,0x4
  40ec07:	lea    rdx,[rdi+rcx*8+0x80]
  40ec0f:	cmp    BYTE PTR [rdx+0x3b],0x0
  40ec13:	je     40ec54 <__swc_fn_0a4ed24b_000068_7d4c42bf+0x1d4>
  40ec15:	mov    DWORD PTR [rdx+0x28],0x0
  40ec1c:	mov    rcx,rdi
  40ec1f:	mov    QWORD PTR [rsp+0xd0],rax
  40ec27:	mov    QWORD PTR [rsp+0xd8],r8
  40ec2f:	mov    QWORD PTR [rsp+0xe0],r9
  40ec37:	call   40dd80 <__swc_fn_0a4ed24b_000014_afb279e2>
  40ec3c:	mov    rax,QWORD PTR [rsp+0xd0]
  40ec44:	mov    r8,QWORD PTR [rsp+0xd8]
  40ec4c:	mov    r9,QWORD PTR [rsp+0xe0]
  40ec54:	add    r9,0x1
  40ec58:	cmp    r9,r8
  40ec5b:	jb     40ec00 <__swc_fn_0a4ed24b_000068_7d4c42bf+0x180>
  40ec5d:	mov    rcx,rdi
  40ec60:	mov    rdi,rax
  40ec63:	call   407630 <__swc_fn_0a4ed24b_000021_491ac000>
  40ec68:	test   rdi,rdi
  40ec6b:	jne    40ebf0 <__swc_fn_0a4ed24b_000068_7d4c42bf+0x170>
  40ec71:	mov    QWORD PTR [r12+0x18],0x0
  40ec7a:	mov    QWORD PTR [r12+0x28],0x0
  40ec83:	mov    rcx,rsi
  40ec86:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  40ec8b:	mov    esi,0x8
  40ec90:	xor    edi,edi
  40ec92:	test   rsi,rsi
  40ec95:	je     40ecf2 <__swc_fn_0a4ed24b_000068_7d4c42bf+0x272>
  40ec9b:	nop    DWORD PTR [rax+rax*1+0x0]
  40eca0:	lea    r13,[rdi*8+0x0]
  40eca8:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40ecad:	test   r14,r14
  40ecb0:	je     40ece8 <__swc_fn_0a4ed24b_000068_7d4c42bf+0x268>
  40ecb2:	cs nop WORD PTR [rax+rax*1+0x0]
  40ecbc:	nop    DWORD PTR [rax+0x0]
  40ecc0:	mov    rcx,r12
  40ecc3:	mov    rdx,r14
  40ecc6:	call   407df0 <__swc_fn_0a4ed24b_000054_ae20ea33>
  40eccb:	mov    rcx,r12
  40ecce:	mov    rdx,QWORD PTR [r14]
  40ecd1:	mov    r8,QWORD PTR [r14+0x8]
  40ecd5:	mov    r9,QWORD PTR [r14+0x10]
  40ecd9:	call   407750 <__swc_fn_0a4ed24b_000039_40d1e569>
  40ecde:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40ece3:	test   r14,r14
  40ece6:	jne    40ecc0 <__swc_fn_0a4ed24b_000068_7d4c42bf+0x240>
  40ece8:	add    rdi,0x1
  40ecec:	sub    rsi,0x1
  40ecf0:	jne    40eca0 <__swc_fn_0a4ed24b_000068_7d4c42bf+0x220>
  40ecf2:	mov    rcx,r12
  40ecf5:	call   407ec0 <__swc_fn_0a4ed24b_000060_e6407a0a>
  40ecfa:	lea    rcx,[r12+0x250]
  40ed02:	mov    rdx,QWORD PTR [rcx]
  40ed05:	mov    r8,QWORD PTR [r12+0x250]
  40ed0d:	nop    DWORD PTR [rax]
  40ed10:	mov    r9,r8
  40ed13:	sub    r9,rdx
  40ed16:	mov    rax,r8
  40ed19:	lock cmpxchg QWORD PTR [rcx],r9
  40ed1e:	cmp    rax,r8
  40ed21:	je     40ed28 <__swc_fn_0a4ed24b_000068_7d4c42bf+0x2a8>
  40ed23:	mov    r8,rax
  40ed26:	jmp    40ed10 <__swc_fn_0a4ed24b_000068_7d4c42bf+0x290>
  40ed28:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40ed31:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40ed3a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40ed43:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40ed4c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40ed55:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40ed5e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40ed67:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40ed70:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40ed79:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40ed82:	add    rsp,0x190
  40ed89:	pop    r14
  40ed8b:	pop    r13
  40ed8d:	pop    rsi
  40ed8e:	pop    rdi
  40ed8f:	pop    r12
  40ed91:	ret
	...

000000000040eda0 <__swc_fn_0a4ed24b_000071_0d1ef36f>:
  40eda0:	sub    rsp,0x8
  40eda4:	mov    QWORD PTR [rdx+0x40],0x0
  40edac:	call   40bb10 <__swc_fn_0a4ed24b_000064_b0d63361>
  40edb1:	add    rsp,0x8
  40edb5:	ret
	...

000000000040edc0 <__swc_fn_0a4ed24b_000074_518516c2>:
  40edc0:	sub    rsp,0x8
  40edc4:	call   407f90 <__swc_fn_0a4ed24b_000066_254b71af>
  40edc9:	add    rsp,0x8
  40edcd:	ret
	...

000000000040edd0 <__swc_fn_0a4ed24b_000077_8b8614a7>:
  40edd0:	push   rbx
  40edd1:	push   rsi
  40edd2:	push   rdi
  40edd3:	push   r12
  40edd5:	push   r13
  40edd7:	push   r14
  40edd9:	push   r15
  40eddb:	sub    rsp,0x20
  40eddf:	mov    rbx,r11
  40ede2:	mov    rsi,rcx
  40ede5:	mov    rdi,rdx
  40ede8:	mov    r12,r8
  40edeb:	mov    r13,r9
  40edee:	mov    r14,r10
  40edf1:	mov    rcx,QWORD PTR [rip+0x17f48]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40edf8:	test   rcx,rcx
  40edfb:	jne    40ee0d <__swc_fn_0a4ed24b_000077_8b8614a7+0x3d>
  40edfd:	call   40a1d0 <__swc_fn_0a4ed24b_000165_cf398896>
  40ee02:	lea    rcx,[rax+0x1]
  40ee06:	mov    QWORD PTR [rip+0x17f33],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40ee0d:	dec    rcx
  40ee10:	call   411d40 <__swc_fn_0a4ed24b_000167_fce60b2b>
  40ee15:	mov    r15,rax
  40ee18:	lea    r11,[rip+0x15421]        # 424240 <__swc_bss_base_0a4ed24b+0x200>
  40ee1f:	mov    rcx,r11
  40ee22:	call   407740 <__swc_fn_0a4ed24b_000036_8d895ba1>
  40ee27:	test   al,al
  40ee29:	jne    40ee3a <__swc_fn_0a4ed24b_000077_8b8614a7+0x6a>
  40ee2b:	mov    rcx,r11
  40ee2e:	call   40acc0 <__swc_fn_0a4ed24b_000034_25f19556>
  40ee33:	lea    r11,[rip+0x15406]        # 424240 <__swc_bss_base_0a4ed24b+0x200>
  40ee3a:	mov    rcx,r11
  40ee3d:	mov    rdx,rsi
  40ee40:	mov    r8,rdi
  40ee43:	mov    r9,r12
  40ee46:	mov    r10,r13
  40ee49:	mov    rsi,r11
  40ee4c:	mov    r11,r14
  40ee4f:	call   40e0f0 <__swc_fn_0a4ed24b_000035_95622a2b>
  40ee54:	test   bl,bl
  40ee56:	je     40ee7d <__swc_fn_0a4ed24b_000077_8b8614a7+0xad>
  40ee58:	mov    QWORD PTR [rsp+0x8],rsi
  40ee5d:	lea    rax,[rip+0x42ec]        # 413150 <__swc_rdata_base_0a4ed24b+0x40>
  40ee64:	mov    QWORD PTR [rsp+0x10],rax
  40ee69:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ee6f:	vmovups XMMWORD PTR [r15],xmm0
  40ee74:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40ee7d:	mov    rax,rsi
  40ee80:	add    rsp,0x20
  40ee84:	pop    r15
  40ee86:	pop    r14
  40ee88:	pop    r13
  40ee8a:	pop    r12
  40ee8c:	pop    rdi
  40ee8d:	pop    rsi
  40ee8e:	pop    rbx
  40ee8f:	ret

000000000040ee90 <__swc_fn_0a4ed24b_000080_c1514492>:
  40ee90:	sub    rsp,0x8
  40ee94:	mov    rax,rcx
  40ee97:	test   rcx,rcx
  40ee9a:	jne    40eea1 <__swc_fn_0a4ed24b_000080_c1514492+0x11>
  40ee9c:	add    rsp,0x8
  40eea0:	ret
  40eea1:	lea    rcx,[rax-0x10]
  40eea5:	mov    rax,QWORD PTR [rax-0x10]
  40eea9:	mov    rdx,rax
  40eeac:	call   40ff20 <__swc_fn_0a4ed24b_000113_49b378a9>
  40eeb1:	add    rsp,0x8
  40eeb5:	ret
	...

000000000040eec0 <__swc_fn_0a4ed24b_000083_31b501f2>:
  40eec0:	sub    rsp,0x8
  40eec4:	xor    r11d,r11d
  40eec7:	call   408250 <__swc_fn_0a4ed24b_000084_ddf2b8a1>
  40eecc:	add    rsp,0x8
  40eed0:	ret
	...

000000000040eee0 <__swc_fn_0a4ed24b_000086_c45095aa>:
  40eee0:	push   rsi
  40eee1:	push   rdi
  40eee2:	push   r12
  40eee4:	push   r13
  40eee6:	push   r14
  40eee8:	push   r15
  40eeea:	sub    rsp,0x68
  40eeee:	mov    rsi,r9
  40eef1:	mov    rdi,rcx
  40eef4:	mov    r12,rdx
  40eef7:	mov    r13,r8
  40eefa:	cmp    r8,r9
  40eefd:	jne    40ef25 <__swc_fn_0a4ed24b_000086_c45095aa+0x45>
  40eeff:	mov    rcx,rdi
  40ef02:	mov    rdx,r12
  40ef05:	xor    r8d,r8d
  40ef08:	call   4085a0 <__swc_fn_0a4ed24b_000090_a2d50c23>
  40ef0d:	test   al,al
  40ef0f:	je     40ef25 <__swc_fn_0a4ed24b_000086_c45095aa+0x45>
  40ef11:	mov    eax,0x1
  40ef16:	add    rsp,0x68
  40ef1a:	pop    r15
  40ef1c:	pop    r14
  40ef1e:	pop    r13
  40ef20:	pop    r12
  40ef22:	pop    rdi
  40ef23:	pop    rsi
  40ef24:	ret
  40ef25:	cmp    BYTE PTR [r12+0x2c],0xe
  40ef2b:	je     40ef3e <__swc_fn_0a4ed24b_000086_c45095aa+0x5e>
  40ef2d:	xor    eax,eax
  40ef2f:	add    rsp,0x68
  40ef33:	pop    r15
  40ef35:	pop    r14
  40ef37:	pop    r13
  40ef39:	pop    r12
  40ef3b:	pop    rdi
  40ef3c:	pop    rsi
  40ef3d:	ret
  40ef3e:	mov    r14,QWORD PTR [r12+0x98]
  40ef46:	mov    rax,QWORD PTR [r12+0xa0]
  40ef4e:	mov    r12,rax
  40ef51:	xor    r15d,r15d
  40ef54:	test   r12,r12
  40ef57:	je     40efbf <__swc_fn_0a4ed24b_000086_c45095aa+0xdf>
  40ef59:	nop    DWORD PTR [rax+0x0]
  40ef60:	mov    QWORD PTR [rsp+0x58],r12
  40ef65:	lea    r12,[r15*8+0x0]
  40ef6d:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40ef72:	mov    rcx,rax
  40ef75:	call   40c2a0 <__swc_fn_0a4ed24b_000082_754dcd57>
  40ef7a:	cmp    BYTE PTR [rax+0x2c],0xe
  40ef7e:	jne    40efb0 <__swc_fn_0a4ed24b_000086_c45095aa+0xd0>
  40ef80:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40ef85:	lea    r8,[r13+rcx*1+0x0]
  40ef8a:	mov    rcx,rdi
  40ef8d:	mov    rdx,rax
  40ef90:	mov    r9,rsi
  40ef93:	call   40eee0 <__swc_fn_0a4ed24b_000086_c45095aa>
  40ef98:	test   al,al
  40ef9a:	je     40efb0 <__swc_fn_0a4ed24b_000086_c45095aa+0xd0>
  40ef9c:	mov    eax,0x1
  40efa1:	add    rsp,0x68
  40efa5:	pop    r15
  40efa7:	pop    r14
  40efa9:	pop    r13
  40efab:	pop    r12
  40efad:	pop    rdi
  40efae:	pop    rsi
  40efaf:	ret
  40efb0:	add    r15,0x1
  40efb4:	mov    r12,QWORD PTR [rsp+0x58]
  40efb9:	sub    r12,0x1
  40efbd:	jne    40ef60 <__swc_fn_0a4ed24b_000086_c45095aa+0x80>
  40efbf:	xor    eax,eax
  40efc1:	add    rsp,0x68
  40efc5:	pop    r15
  40efc7:	pop    r14
  40efc9:	pop    r13
  40efcb:	pop    r12
  40efcd:	pop    rdi
  40efce:	pop    rsi
  40efcf:	ret

000000000040efd0 <__swc_fn_0a4ed24b_000089_386582f3>:
  40efd0:	push   rbp
  40efd1:	push   rbx
  40efd2:	push   rsi
  40efd3:	push   rdi
  40efd4:	push   r12
  40efd6:	push   r13
  40efd8:	push   r14
  40efda:	push   r15
  40efdc:	sub    rsp,0x38
  40efe0:	mov    rbp,rsp
  40efe3:	mov    rbx,r11
  40efe6:	mov    rsi,rdx
  40efe9:	mov    rdi,r8
  40efec:	mov    r12,r9
  40efef:	mov    QWORD PTR [rsp+0x18],r9
  40eff4:	mov    r13,r10
  40eff7:	movzx  r14d,BYTE PTR [rbp+0x80]
  40efff:	movzx  r15d,BYTE PTR [rbp+0x88]
  40f007:	test   r11,r11
  40f00a:	je     40f010 <__swc_fn_0a4ed24b_000089_386582f3+0x40>
  40f00c:	xor    eax,eax
  40f00e:	mov    BYTE PTR [rbx],al
  40f010:	test   r12,r12
  40f013:	je     40f01e <__swc_fn_0a4ed24b_000089_386582f3+0x4e>
  40f015:	mov    QWORD PTR [r12+0x8],0x0
  40f01e:	test   rcx,rcx
  40f021:	je     40f028 <__swc_fn_0a4ed24b_000089_386582f3+0x58>
  40f023:	test   rsi,rsi
  40f026:	jne    40f03b <__swc_fn_0a4ed24b_000089_386582f3+0x6b>
  40f028:	xor    eax,eax
  40f02a:	add    rsp,0x38
  40f02e:	pop    r15
  40f030:	pop    r14
  40f032:	pop    r13
  40f034:	pop    r12
  40f036:	pop    rdi
  40f037:	pop    rsi
  40f038:	pop    rbx
  40f039:	pop    rbp
  40f03a:	ret
  40f03b:	call   40c2a0 <__swc_fn_0a4ed24b_000082_754dcd57>
  40f040:	mov    r12,rax
  40f043:	mov    al,r15b
  40f046:	test   r15b,r15b
  40f049:	jne    40f059 <__swc_fn_0a4ed24b_000089_386582f3+0x89>
  40f04b:	mov    eax,DWORD PTR [r12+0x28]
  40f050:	and    eax,0x10000
  40f056:	setne  al
  40f059:	lea    r15,[rsp+0x8]
  40f05e:	mov    QWORD PTR [rsp+0x20],r15
  40f063:	rex mov BYTE PTR [rsp+0x8],al
  40f068:	test   DWORD PTR [rsi+0x28],0x400000
  40f06f:	je     40f0a7 <__swc_fn_0a4ed24b_000089_386582f3+0xd7>
  40f071:	test   rsi,rsi
  40f074:	je     40f094 <__swc_fn_0a4ed24b_000089_386582f3+0xc4>
  40f076:	mov    rax,QWORD PTR [rsi+0x38]
  40f07a:	cmp    QWORD PTR [rax+0x10],rsi
  40f07e:	jne    40f094 <__swc_fn_0a4ed24b_000089_386582f3+0xc4>
  40f080:	rex mov al,BYTE PTR [rsp+0x8]
  40f085:	test   al,al
  40f087:	sete   al
  40f08a:	test   r14b,r14b
  40f08d:	sete   cl
  40f090:	test   al,cl
  40f092:	je     40f0a7 <__swc_fn_0a4ed24b_000089_386582f3+0xd7>
  40f094:	xor    eax,eax
  40f096:	add    rsp,0x38
  40f09a:	pop    r15
  40f09c:	pop    r14
  40f09e:	pop    r13
  40f0a0:	pop    r12
  40f0a2:	pop    rdi
  40f0a3:	pop    rsi
  40f0a4:	pop    rbx
  40f0a5:	pop    rbp
  40f0a6:	ret
  40f0a7:	mov    r15,r12
  40f0aa:	test   r14b,r14b
  40f0ad:	jne    40f0c4 <__swc_fn_0a4ed24b_000089_386582f3+0xf4>
  40f0af:	cmp    BYTE PTR [r12+0x2c],0x6
  40f0b5:	jne    40f0c4 <__swc_fn_0a4ed24b_000089_386582f3+0xf4>
  40f0b7:	mov    rcx,QWORD PTR [r12+0x40]
  40f0bc:	call   40c2a0 <__swc_fn_0a4ed24b_000082_754dcd57>
  40f0c1:	mov    r15,rax
  40f0c4:	test   r14b,r14b
  40f0c7:	je     40f0cd <__swc_fn_0a4ed24b_000089_386582f3+0xfd>
  40f0c9:	mov    r15,QWORD PTR [r15+0x30]
  40f0cd:	mov    rcx,rsi
  40f0d0:	call   40c2a0 <__swc_fn_0a4ed24b_000082_754dcd57>
  40f0d5:	mov    rsi,rax
  40f0d8:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f0dd:	je     40f114 <__swc_fn_0a4ed24b_000089_386582f3+0x144>
  40f0df:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f0e4:	je     40f114 <__swc_fn_0a4ed24b_000089_386582f3+0x144>
  40f0e6:	mov    eax,DWORD PTR [rsi+0x28]
  40f0e9:	and    eax,0x10000
  40f0ef:	je     40f114 <__swc_fn_0a4ed24b_000089_386582f3+0x144>
  40f0f1:	rex mov al,BYTE PTR [rsp+0x8]
  40f0f6:	test   al,al
  40f0f8:	jne    40f10d <__swc_fn_0a4ed24b_000089_386582f3+0x13d>
  40f0fa:	xor    eax,eax
  40f0fc:	add    rsp,0x38
  40f100:	pop    r15
  40f102:	pop    r14
  40f104:	pop    r13
  40f106:	pop    r12
  40f108:	pop    rdi
  40f109:	pop    rsi
  40f10a:	pop    rbx
  40f10b:	pop    rbp
  40f10c:	ret
  40f10d:	mov    rax,QWORD PTR [rsi+0x30]
  40f111:	mov    rsi,rax
  40f114:	mov    r14b,r13b
  40f117:	test   rbx,rbx
  40f11a:	je     40f150 <__swc_fn_0a4ed24b_000089_386582f3+0x180>
  40f11c:	cmp    BYTE PTR [r12+0x2c],0x6
  40f122:	jne    40f150 <__swc_fn_0a4ed24b_000089_386582f3+0x180>
  40f124:	lea    rdx,[rip+0x4055]        # 413180 <__swc_rdata_base_0a4ed24b+0x70>
  40f12b:	mov    rcx,rsi
  40f12e:	xor    r8d,r8d
  40f131:	call   4085a0 <__swc_fn_0a4ed24b_000090_a2d50c23>
  40f136:	test   al,al
  40f138:	je     40f150 <__swc_fn_0a4ed24b_000089_386582f3+0x180>
  40f13a:	mov    BYTE PTR [rbx],0x1
  40f13d:	xor    eax,eax
  40f13f:	add    rsp,0x38
  40f143:	pop    r15
  40f145:	pop    r14
  40f147:	pop    r13
  40f149:	pop    r12
  40f14b:	pop    rdi
  40f14c:	pop    rsi
  40f14d:	pop    rbx
  40f14e:	pop    rbp
  40f14f:	ret
  40f150:	test   rdi,rdi
  40f153:	jne    40f16d <__swc_fn_0a4ed24b_000089_386582f3+0x19d>
  40f155:	test   r13b,r13b
  40f158:	jne    40f16d <__swc_fn_0a4ed24b_000089_386582f3+0x19d>
  40f15a:	xor    eax,eax
  40f15c:	add    rsp,0x38
  40f160:	pop    r15
  40f162:	pop    r14
  40f164:	pop    r13
  40f166:	pop    r12
  40f168:	pop    rdi
  40f169:	pop    rsi
  40f16a:	pop    rbx
  40f16b:	pop    rbp
  40f16c:	ret
  40f16d:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f172:	jne    40f228 <__swc_fn_0a4ed24b_000089_386582f3+0x258>
  40f178:	mov    rcx,r15
  40f17b:	mov    rdx,rsi
  40f17e:	xor    r8d,r8d
  40f181:	call   4085a0 <__swc_fn_0a4ed24b_000090_a2d50c23>
  40f186:	test   al,al
  40f188:	jne    40f228 <__swc_fn_0a4ed24b_000089_386582f3+0x258>
  40f18e:	test   DWORD PTR [rsi+0x28],0x10000
  40f195:	je     40f1b3 <__swc_fn_0a4ed24b_000089_386582f3+0x1e3>
  40f197:	rex mov al,BYTE PTR [rsp+0x8]
  40f19c:	test   al,al
  40f19e:	jne    40f1b3 <__swc_fn_0a4ed24b_000089_386582f3+0x1e3>
  40f1a0:	xor    eax,eax
  40f1a2:	add    rsp,0x38
  40f1a6:	pop    r15
  40f1a8:	pop    r14
  40f1aa:	pop    r13
  40f1ac:	pop    r12
  40f1ae:	pop    rdi
  40f1af:	pop    rsi
  40f1b0:	pop    rbx
  40f1b1:	pop    rbp
  40f1b2:	ret
  40f1b3:	test   rdi,rdi
  40f1b6:	jne    40f1cb <__swc_fn_0a4ed24b_000089_386582f3+0x1fb>
  40f1b8:	xor    eax,eax
  40f1ba:	add    rsp,0x38
  40f1be:	pop    r15
  40f1c0:	pop    r14
  40f1c2:	pop    r13
  40f1c4:	pop    r12
  40f1c6:	pop    rdi
  40f1c7:	pop    rsi
  40f1c8:	pop    rbx
  40f1c9:	pop    rbp
  40f1ca:	ret
  40f1cb:	mov    rcx,QWORD PTR [rsi+0x40]
  40f1cf:	call   40c2a0 <__swc_fn_0a4ed24b_000082_754dcd57>
  40f1d4:	mov    rsi,rax
  40f1d7:	mov    rax,QWORD PTR [rdi]
  40f1da:	mov    rdi,rax
  40f1dd:	test   rax,rax
  40f1e0:	jne    40f223 <__swc_fn_0a4ed24b_000089_386582f3+0x253>
  40f1e2:	test   rbx,rbx
  40f1e5:	je     40f223 <__swc_fn_0a4ed24b_000089_386582f3+0x253>
  40f1e7:	mov    rcx,r15
  40f1ea:	mov    rdx,rsi
  40f1ed:	xor    r8d,r8d
  40f1f0:	call   4085a0 <__swc_fn_0a4ed24b_000090_a2d50c23>
  40f1f5:	mov    rcx,rax
  40f1f8:	test   al,al
  40f1fa:	jne    40f21c <__swc_fn_0a4ed24b_000089_386582f3+0x24c>
  40f1fc:	mov    rcx,r15
  40f1ff:	mov    rdx,rsi
  40f202:	call   40c2e0 <__swc_fn_0a4ed24b_000085_1edf7c76>
  40f207:	mov    rcx,rax
  40f20a:	test   al,al
  40f20c:	jne    40f21c <__swc_fn_0a4ed24b_000089_386582f3+0x24c>
  40f20e:	mov    rcx,rsi
  40f211:	mov    rdx,r15
  40f214:	call   40c2e0 <__swc_fn_0a4ed24b_000085_1edf7c76>
  40f219:	mov    rcx,rax
  40f21c:	test   cl,cl
  40f21e:	setne  al
  40f221:	mov    BYTE PTR [rbx],al
  40f223:	xor    eax,eax
  40f225:	mov    r14b,al
  40f228:	test   rdi,rdi
  40f22b:	jne    40f245 <__swc_fn_0a4ed24b_000089_386582f3+0x275>
  40f22d:	test   r14b,r14b
  40f230:	jne    40f245 <__swc_fn_0a4ed24b_000089_386582f3+0x275>
  40f232:	xor    eax,eax
  40f234:	add    rsp,0x38
  40f238:	pop    r15
  40f23a:	pop    r14
  40f23c:	pop    r13
  40f23e:	pop    r12
  40f240:	pop    rdi
  40f241:	pop    rsi
  40f242:	pop    rbx
  40f243:	pop    rbp
  40f244:	ret
  40f245:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f24a:	je     40f256 <__swc_fn_0a4ed24b_000089_386582f3+0x286>
  40f24c:	mov    r12,QWORD PTR [rsp+0x18]
  40f251:	jmp    40f2de <__swc_fn_0a4ed24b_000089_386582f3+0x30e>
  40f256:	mov    r12,QWORD PTR [rsp+0x18]
  40f25b:	test   r12,r12
  40f25e:	jne    40f272 <__swc_fn_0a4ed24b_000089_386582f3+0x2a2>
  40f260:	mov    rcx,r15
  40f263:	mov    rdx,rsi
  40f266:	xor    r8d,r8d
  40f269:	call   4085a0 <__swc_fn_0a4ed24b_000090_a2d50c23>
  40f26e:	test   al,al
  40f270:	jne    40f2de <__swc_fn_0a4ed24b_000089_386582f3+0x30e>
  40f272:	test   DWORD PTR [rsi+0x28],0x10000
  40f279:	je     40f297 <__swc_fn_0a4ed24b_000089_386582f3+0x2c7>
  40f27b:	rex mov al,BYTE PTR [rsp+0x8]
  40f280:	test   al,al
  40f282:	jne    40f297 <__swc_fn_0a4ed24b_000089_386582f3+0x2c7>
  40f284:	xor    eax,eax
  40f286:	add    rsp,0x38
  40f28a:	pop    r15
  40f28c:	pop    r14
  40f28e:	pop    r13
  40f290:	pop    r12
  40f292:	pop    rdi
  40f293:	pop    rsi
  40f294:	pop    rbx
  40f295:	pop    rbp
  40f296:	ret
  40f297:	test   rdi,rdi
  40f29a:	jne    40f2af <__swc_fn_0a4ed24b_000089_386582f3+0x2df>
  40f29c:	xor    eax,eax
  40f29e:	add    rsp,0x38
  40f2a2:	pop    r15
  40f2a4:	pop    r14
  40f2a6:	pop    r13
  40f2a8:	pop    r12
  40f2aa:	pop    rdi
  40f2ab:	pop    rsi
  40f2ac:	pop    rbx
  40f2ad:	pop    rbp
  40f2ae:	ret
  40f2af:	cmp    QWORD PTR [rdi+0x8],0x0
  40f2b4:	jne    40f2c9 <__swc_fn_0a4ed24b_000089_386582f3+0x2f9>
  40f2b6:	xor    eax,eax
  40f2b8:	add    rsp,0x38
  40f2bc:	pop    r15
  40f2be:	pop    r14
  40f2c0:	pop    r13
  40f2c2:	pop    r12
  40f2c4:	pop    rdi
  40f2c5:	pop    rsi
  40f2c6:	pop    rbx
  40f2c7:	pop    rbp
  40f2c8:	ret
  40f2c9:	mov    rax,QWORD PTR [rdi+0x8]
  40f2cd:	mov    rax,QWORD PTR [rax]
  40f2d0:	mov    rsi,rax
  40f2d3:	mov    rdi,QWORD PTR [rdi]
  40f2d6:	mov    eax,0x1
  40f2db:	mov    r14b,al
  40f2de:	test   rdi,rdi
  40f2e1:	mov    rbx,QWORD PTR [rsp+0x20]
  40f2e6:	jne    40f330 <__swc_fn_0a4ed24b_000089_386582f3+0x360>
  40f2e8:	test   r14b,r14b
  40f2eb:	je     40f31d <__swc_fn_0a4ed24b_000089_386582f3+0x34d>
  40f2ed:	test   r12,r12
  40f2f0:	je     40f31d <__swc_fn_0a4ed24b_000089_386582f3+0x34d>
  40f2f2:	mov    rcx,r15
  40f2f5:	mov    rdx,rsi
  40f2f8:	xor    r8d,r8d
  40f2fb:	mov    r9,r12
  40f2fe:	mov    rbx,QWORD PTR [rsp+0x20]
  40f303:	movzx  r10d,BYTE PTR [rbx]
  40f307:	call   40eec0 <__swc_fn_0a4ed24b_000083_31b501f2>
  40f30c:	add    rsp,0x38
  40f310:	pop    r15
  40f312:	pop    r14
  40f314:	pop    r13
  40f316:	pop    r12
  40f318:	pop    rdi
  40f319:	pop    rsi
  40f31a:	pop    rbx
  40f31b:	pop    rbp
  40f31c:	ret
  40f31d:	xor    eax,eax
  40f31f:	add    rsp,0x38
  40f323:	pop    r15
  40f325:	pop    r14
  40f327:	pop    r13
  40f329:	pop    r12
  40f32b:	pop    rdi
  40f32c:	pop    rsi
  40f32d:	pop    rbx
  40f32e:	pop    rbp
  40f32f:	ret
  40f330:	mov    r13,rsi
  40f333:	mov    QWORD PTR [rsp+0x28],rdi
  40f338:	cmp    BYTE PTR [r15+0x2c],0xe
  40f33d:	sete   al
  40f340:	mov    r14b,al
  40f343:	jne    40f357 <__swc_fn_0a4ed24b_000089_386582f3+0x387>
  40f345:	mov    rcx,rsi
  40f348:	mov    rdx,r15
  40f34b:	call   40c2e0 <__swc_fn_0a4ed24b_000085_1edf7c76>
  40f350:	mov    r14b,al
  40f353:	test   al,al
  40f355:	jne    40f38c <__swc_fn_0a4ed24b_000089_386582f3+0x3bc>
  40f357:	cmp    BYTE PTR [r15+0x2c],0x12
  40f35c:	je     40f38c <__swc_fn_0a4ed24b_000089_386582f3+0x3bc>
  40f35e:	mov    rcx,r15
  40f361:	mov    rdx,rsi
  40f364:	mov    r8,rdi
  40f367:	mov    r9,r12
  40f36a:	mov    rax,rbx
  40f36d:	movzx  r10d,BYTE PTR [rax]
  40f371:	call   40eec0 <__swc_fn_0a4ed24b_000083_31b501f2>
  40f376:	test   rax,rax
  40f379:	je     40f38c <__swc_fn_0a4ed24b_000089_386582f3+0x3bc>
  40f37b:	add    rsp,0x38
  40f37f:	pop    r15
  40f381:	pop    r14
  40f383:	pop    r13
  40f385:	pop    r12
  40f387:	pop    rdi
  40f388:	pop    rsi
  40f389:	pop    rbx
  40f38a:	pop    rbp
  40f38b:	ret
  40f38c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40f391:	jne    40f3b0 <__swc_fn_0a4ed24b_000089_386582f3+0x3e0>
  40f393:	mov    rax,QWORD PTR [rsi+0xd8]
  40f39a:	test   rax,rax
  40f39d:	je     40f3b0 <__swc_fn_0a4ed24b_000089_386582f3+0x3e0>
  40f39f:	add    rdi,QWORD PTR [rax+0x8]
  40f3a3:	mov    rax,QWORD PTR [rdi]
  40f3a6:	sub    rdi,QWORD PTR [rax+0x8]
  40f3aa:	mov    rax,QWORD PTR [rax]
  40f3ad:	mov    rsi,rax
  40f3b0:	test   r14b,r14b
  40f3b3:	je     40f3df <__swc_fn_0a4ed24b_000089_386582f3+0x40f>
  40f3b5:	mov    rcx,r15
  40f3b8:	mov    rdx,rsi
  40f3bb:	mov    r8,rdi
  40f3be:	mov    r9,r13
  40f3c1:	mov    r14,QWORD PTR [rsp+0x28]
  40f3c6:	mov    r10,r14
  40f3c9:	call   408480 <__swc_fn_0a4ed24b_000087_ea575bb3>
  40f3ce:	add    rsp,0x38
  40f3d2:	pop    r15
  40f3d4:	pop    r14
  40f3d6:	pop    r13
  40f3d8:	pop    r12
  40f3da:	pop    rdi
  40f3db:	pop    rsi
  40f3dc:	pop    rbx
  40f3dd:	pop    rbp
  40f3de:	ret
  40f3df:	mov    rcx,r15
  40f3e2:	mov    rdx,rsi
  40f3e5:	mov    r8,rdi
  40f3e8:	mov    r9,r12
  40f3eb:	movzx  r10d,BYTE PTR [rbx]
  40f3ef:	call   40eec0 <__swc_fn_0a4ed24b_000083_31b501f2>
  40f3f4:	add    rsp,0x38
  40f3f8:	pop    r15
  40f3fa:	pop    r14
  40f3fc:	pop    r13
  40f3fe:	pop    r12
  40f400:	pop    rdi
  40f401:	pop    rsi
  40f402:	pop    rbx
  40f403:	pop    rbp
  40f404:	ret
	...

000000000040f410 <__swc_fn_0a4ed24b_000092_8252f8c0>:
  40f410:	push   rbx
  40f411:	push   rsi
  40f412:	sub    rsp,0x18
  40f416:	mov    rbx,rcx
  40f419:	mov    rcx,QWORD PTR [rip+0x17920]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40f420:	test   rcx,rcx
  40f423:	jne    40f435 <__swc_fn_0a4ed24b_000092_8252f8c0+0x25>
  40f425:	call   40a1d0 <__swc_fn_0a4ed24b_000165_cf398896>
  40f42a:	lea    rcx,[rax+0x1]
  40f42e:	mov    QWORD PTR [rip+0x1790b],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40f435:	dec    rcx
  40f438:	call   411d40 <__swc_fn_0a4ed24b_000167_fce60b2b>
  40f43d:	mov    rsi,rax
  40f440:	mov    rax,QWORD PTR [rsi+0x8]
  40f444:	test   rax,rax
  40f447:	jne    40f497 <__swc_fn_0a4ed24b_000092_8252f8c0+0x87>
  40f449:	call   40c3d0 <__swc_fn_0a4ed24b_000091_3d2f5a0d>
  40f44e:	test   al,al
  40f450:	jne    40f497 <__swc_fn_0a4ed24b_000092_8252f8c0+0x87>
  40f452:	lea    rdx,[rip+0x14de7]        # 424240 <__swc_bss_base_0a4ed24b+0x200>
  40f459:	mov    rcx,rdx
  40f45c:	call   407740 <__swc_fn_0a4ed24b_000036_8d895ba1>
  40f461:	test   al,al
  40f463:	jne    40f474 <__swc_fn_0a4ed24b_000092_8252f8c0+0x64>
  40f465:	mov    rcx,rdx
  40f468:	call   40acc0 <__swc_fn_0a4ed24b_000034_25f19556>
  40f46d:	lea    rdx,[rip+0x14dcc]        # 424240 <__swc_bss_base_0a4ed24b+0x200>
  40f474:	mov    QWORD PTR [rsp+0x8],rdx
  40f479:	lea    rax,[rip+0x3cd0]        # 413150 <__swc_rdata_base_0a4ed24b+0x40>
  40f480:	mov    QWORD PTR [rsp+0x10],rax
  40f485:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f48b:	vmovups XMMWORD PTR [rsi],xmm0
  40f48f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40f497:	vmovups xmm0,XMMWORD PTR [rsi]
  40f49b:	vmovups XMMWORD PTR [rbx],xmm0
  40f49f:	mov    rax,rbx
  40f4a2:	add    rsp,0x18
  40f4a6:	pop    rsi
  40f4a7:	pop    rbx
  40f4a8:	ret
  40f4a9:	add    BYTE PTR [rax],al
  40f4ab:	add    BYTE PTR [rax],al
  40f4ad:	add    BYTE PTR [rax],al
	...

000000000040f4b0 <__swc_fn_0a4ed24b_000095_337e587a>:
  40f4b0:	sub    rsp,0x8
  40f4b4:	call   409360 <__swc_fn_0a4ed24b_000117_86a7fb9e>
  40f4b9:	add    rsp,0x8
  40f4bd:	ret
	...

000000000040f4c0 <__swc_fn_0a4ed24b_000098_00f01091>:
  40f4c0:	push   rbx
  40f4c1:	push   rsi
  40f4c2:	sub    rsp,0x28
  40f4c6:	mov    rbx,rcx
  40f4c9:	xor    esi,esi
  40f4cb:	jmp    40f4e0 <__swc_fn_0a4ed24b_000098_00f01091+0x20>
  40f4cd:	nop    DWORD PTR [rax]
  40f4d0:	mov    QWORD PTR [rbx+0x28],rsi
  40f4d4:	mov    rsi,rbx
  40f4d7:	mov    rbx,rax
  40f4da:	nop    WORD PTR [rax+rax*1+0x0]
  40f4e0:	test   rbx,rbx
  40f4e3:	je     40f543 <__swc_fn_0a4ed24b_000098_00f01091+0x83>
  40f4e5:	mov    rcx,rbx
  40f4e8:	mov    edx,0x1
  40f4ed:	call   408200 <__swc_fn_0a4ed24b_000078_a120bd2b>
  40f4f2:	cmp    rax,0x1
  40f4f6:	jne    40f543 <__swc_fn_0a4ed24b_000098_00f01091+0x83>
  40f4f8:	mov    r10,QWORD PTR [rbx+0x18]
  40f4fc:	mov    rcx,r10
  40f4ff:	mov    edx,0x1
  40f504:	call   408200 <__swc_fn_0a4ed24b_000078_a120bd2b>
  40f509:	cmp    rax,0x1
  40f50d:	jne    40f51c <__swc_fn_0a4ed24b_000098_00f01091+0x5c>
  40f50f:	mov    rcx,r10
  40f512:	call   40c570 <__swc_fn_0a4ed24b_000097_4c97e0db>
  40f517:	test   rax,rax
  40f51a:	jne    40f4d0 <__swc_fn_0a4ed24b_000098_00f01091+0x10>
  40f51c:	mov    rax,QWORD PTR [rbx+0x20]
  40f520:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40f525:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f52b:	lea    rcx,[rsp+0x8]
  40f530:	mov    rdx,rbx
  40f533:	mov    r8d,0x30
  40f539:	mov    rbx,rax
  40f53c:	call   408960 <__swc_fn_0a4ed24b_000096_ad982b35>
  40f541:	jmp    40f4e0 <__swc_fn_0a4ed24b_000098_00f01091+0x20>
  40f543:	test   rsi,rsi
  40f546:	jne    40f54f <__swc_fn_0a4ed24b_000098_00f01091+0x8f>
  40f548:	add    rsp,0x28
  40f54c:	pop    rsi
  40f54d:	pop    rbx
  40f54e:	ret
  40f54f:	mov    rax,rsi
  40f552:	mov    rsi,QWORD PTR [rsi+0x28]
  40f556:	mov    rbx,QWORD PTR [rax+0x20]
  40f55a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40f55f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f565:	lea    rcx,[rsp+0x18]
  40f56a:	mov    rdx,rax
  40f56d:	mov    r8d,0x30
  40f573:	call   408960 <__swc_fn_0a4ed24b_000096_ad982b35>
  40f578:	jmp    40f4e0 <__swc_fn_0a4ed24b_000098_00f01091+0x20>
  40f57d:	add    BYTE PTR [rax],al
	...

000000000040f580 <__swc_fn_0a4ed24b_000101_eab3874f>:
  40f580:	push   rbx
  40f581:	push   rsi
  40f582:	push   rdi
  40f583:	push   r12
  40f585:	push   r13
  40f587:	sub    rsp,0x20
  40f58b:	mov    rbx,rcx
  40f58e:	lea    rsi,[rcx+0x6f8]
  40f595:	mov    edi,0x4
  40f59a:	mov    r12,rsi
  40f59d:	test   rdi,rdi
  40f5a0:	je     40f5ea <__swc_fn_0a4ed24b_000101_eab3874f+0x6a>
  40f5a2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f5ac:	nop    DWORD PTR [rax+0x0]
  40f5b0:	mov    rcx,QWORD PTR [r12+0x10]
  40f5b5:	mov    QWORD PTR [r12+0x10],0x0
  40f5be:	vxorps xmm0,xmm0,xmm0
  40f5c2:	vmovups XMMWORD PTR [r12],xmm0
  40f5c8:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40f5cf:	mov    DWORD PTR [r12+0x20],0x0
  40f5d8:	call   4089c0 <__swc_fn_0a4ed24b_000099_b4c6da83>
  40f5dd:	add    r12,0x90
  40f5e4:	sub    rdi,0x1
  40f5e8:	jne    40f5b0 <__swc_fn_0a4ed24b_000101_eab3874f+0x30>
  40f5ea:	mov    rax,QWORD PTR [rbx+0x938]
  40f5f1:	mov    rdi,rax
  40f5f4:	test   rdi,rdi
  40f5f7:	je     40f651 <__swc_fn_0a4ed24b_000101_eab3874f+0xd1>
  40f5f9:	nop    DWORD PTR [rax+0x0]
  40f600:	mov    r12d,0x10
  40f606:	lea    r13,[rdi+0x18]
  40f60a:	test   r12,r12
  40f60d:	je     40f646 <__swc_fn_0a4ed24b_000101_eab3874f+0xc6>
  40f60f:	nop
  40f610:	mov    rcx,QWORD PTR [r13+0x10]
  40f614:	mov    QWORD PTR [r13+0x10],0x0
  40f61c:	vxorps xmm0,xmm0,xmm0
  40f620:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40f626:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40f62c:	mov    DWORD PTR [r13+0x20],0x0
  40f634:	call   4089c0 <__swc_fn_0a4ed24b_000099_b4c6da83>
  40f639:	add    r13,0x90
  40f640:	sub    r12,0x1
  40f644:	jne    40f610 <__swc_fn_0a4ed24b_000101_eab3874f+0x90>
  40f646:	mov    rax,QWORD PTR [rdi]
  40f649:	mov    rdi,rax
  40f64c:	test   rax,rax
  40f64f:	jne    40f600 <__swc_fn_0a4ed24b_000101_eab3874f+0x80>
  40f651:	vxorps xmm0,xmm0,xmm0
  40f655:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40f65d:	mov    DWORD PTR [rbx+0x9b0],0x0
  40f667:	mov    DWORD PTR [rbx+0x9a8],0x0
  40f671:	mov    edi,0x4
  40f676:	mov    r12,rsi
  40f679:	lea    rsi,[rsi+0x38]
  40f67d:	test   rdi,rdi
  40f680:	je     40f6ac <__swc_fn_0a4ed24b_000101_eab3874f+0x12c>
  40f682:	cs nop WORD PTR [rax+rax*1+0x0]
  40f68c:	nop    DWORD PTR [rax+0x0]
  40f690:	mov    rcx,rsi
  40f693:	call   40d400 <__swc_fn_0a4ed24b_000157_232ffa22>
  40f698:	add    rsi,0x90
  40f69f:	add    r12,0x90
  40f6a6:	sub    rdi,0x1
  40f6aa:	jne    40f690 <__swc_fn_0a4ed24b_000101_eab3874f+0x110>
  40f6ac:	mov    rax,QWORD PTR [rbx+0x938]
  40f6b3:	mov    rdi,rax
  40f6b6:	mov    QWORD PTR [rbx+0x938],0x0
  40f6c1:	test   rdi,rdi
  40f6c4:	je     40f735 <__swc_fn_0a4ed24b_000101_eab3874f+0x1b5>
  40f6ca:	nop    WORD PTR [rax+rax*1+0x0]
  40f6d0:	mov    esi,0x10
  40f6d5:	lea    r12,[rdi+0x18]
  40f6d9:	lea    r13,[rdi+0x50]
  40f6dd:	test   rsi,rsi
  40f6e0:	je     40f70c <__swc_fn_0a4ed24b_000101_eab3874f+0x18c>
  40f6e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f6ec:	nop    DWORD PTR [rax+0x0]
  40f6f0:	mov    rcx,r13
  40f6f3:	call   40d400 <__swc_fn_0a4ed24b_000157_232ffa22>
  40f6f8:	add    r13,0x90
  40f6ff:	add    r12,0x90
  40f706:	sub    rsi,0x1
  40f70a:	jne    40f6f0 <__swc_fn_0a4ed24b_000101_eab3874f+0x170>
  40f70c:	mov    rax,QWORD PTR [rdi]
  40f70f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40f714:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f71a:	lea    rcx,[rsp+0x8]
  40f71f:	mov    rdx,rdi
  40f722:	mov    r8d,0x918
  40f728:	mov    rdi,rax
  40f72b:	call   408960 <__swc_fn_0a4ed24b_000096_ad982b35>
  40f730:	test   rdi,rdi
  40f733:	jne    40f6d0 <__swc_fn_0a4ed24b_000101_eab3874f+0x150>
  40f735:	lea    rcx,[rbx+0x68]
  40f739:	call   40d400 <__swc_fn_0a4ed24b_000157_232ffa22>
  40f73e:	add    rsp,0x20
  40f742:	pop    r13
  40f744:	pop    r12
  40f746:	pop    rdi
  40f747:	pop    rsi
  40f748:	pop    rbx
  40f749:	ret
  40f74a:	add    BYTE PTR [rax],al
  40f74c:	add    BYTE PTR [rax],al
	...

000000000040f750 <__swc_fn_0a4ed24b_000104_5589fdbd>:
  40f750:	xor    eax,eax
  40f752:	cs nop WORD PTR [rax+rax*1+0x0]
  40f75c:	nop    DWORD PTR [rax+0x0]
  40f760:	mov    r9,r8
  40f763:	sub    r9,rax
  40f766:	cmp    r9,0x40
  40f76a:	jb     40f7a8 <__swc_fn_0a4ed24b_000104_5589fdbd+0x58>
  40f76c:	lea    r9,[rcx+rax*1]
  40f770:	lea    r10,[rdx+rax*1]
  40f774:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40f77a:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40f780:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40f786:	vmovups xmm3,XMMWORD PTR [r10]
  40f78b:	vmovups XMMWORD PTR [r9],xmm3
  40f790:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40f796:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40f79c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40f7a2:	lea    rax,[rax+0x40]
  40f7a6:	jmp    40f760 <__swc_fn_0a4ed24b_000104_5589fdbd+0x10>
  40f7a8:	nop    DWORD PTR [rax+rax*1+0x0]
  40f7b0:	mov    r9,r8
  40f7b3:	sub    r9,rax
  40f7b6:	cmp    r9,0x10
  40f7ba:	jb     40f7d4 <__swc_fn_0a4ed24b_000104_5589fdbd+0x84>
  40f7bc:	lea    r9,[rdx+rax*1]
  40f7c0:	lea    r10,[rcx+rax*1]
  40f7c4:	vmovups xmm0,XMMWORD PTR [r9]
  40f7c9:	vmovups XMMWORD PTR [r10],xmm0
  40f7ce:	lea    rax,[rax+0x10]
  40f7d2:	jmp    40f7b0 <__swc_fn_0a4ed24b_000104_5589fdbd+0x60>
  40f7d4:	cs nop WORD PTR [rax+rax*1+0x0]
  40f7de:	xchg   ax,ax
  40f7e0:	mov    r9,r8
  40f7e3:	sub    r9,rax
  40f7e6:	cmp    r9,0x8
  40f7ea:	jb     40f7fd <__swc_fn_0a4ed24b_000104_5589fdbd+0xad>
  40f7ec:	lea    r9,[rcx+rax*1]
  40f7f0:	mov    r10,QWORD PTR [rdx+rax*1]
  40f7f4:	mov    QWORD PTR [r9],r10
  40f7f7:	lea    rax,[rax+0x8]
  40f7fb:	jmp    40f7e0 <__swc_fn_0a4ed24b_000104_5589fdbd+0x90>
  40f7fd:	cmp    rax,r8
  40f800:	jae    40f820 <__swc_fn_0a4ed24b_000104_5589fdbd+0xd0>
  40f802:	cs nop WORD PTR [rax+rax*1+0x0]
  40f80c:	nop    DWORD PTR [rax+0x0]
  40f810:	mov    r9b,BYTE PTR [rdx+rax*1]
  40f814:	mov    BYTE PTR [rcx+rax*1],r9b
  40f818:	inc    rax
  40f81b:	cmp    rax,r8
  40f81e:	jb     40f810 <__swc_fn_0a4ed24b_000104_5589fdbd+0xc0>
  40f820:	ret
	...

000000000040f840 <__swc_fn_0a4ed24b_000107_4796e893>:
  40f840:	push   rbx
  40f841:	push   r12
  40f843:	push   rdi
  40f844:	push   rsi
  40f845:	push   r13
  40f847:	push   r14
  40f849:	push   r15
  40f84b:	sub    rsp,0x170
  40f852:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40f85b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40f864:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40f86d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40f876:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40f87f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40f888:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40f891:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40f89a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40f8a3:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40f8ac:	mov    ebx,edx
  40f8ae:	mov    QWORD PTR [rsp+0xa8],rbx
  40f8b6:	mov    r12d,ecx
  40f8b9:	test   edx,edx
  40f8bb:	jne    40f8d2 <__swc_fn_0a4ed24b_000107_4796e893+0x92>
  40f8bd:	xor    eax,eax
  40f8bf:	add    rsp,0x170
  40f8c6:	pop    r15
  40f8c8:	pop    r14
  40f8ca:	pop    r13
  40f8cc:	pop    rsi
  40f8cd:	pop    rdi
  40f8ce:	pop    r12
  40f8d0:	pop    rbx
  40f8d1:	ret
  40f8d2:	lea    rdi,[rip+0x3bd7]        # 4134b0 <__swc_rdata_base_0a4ed24b+0x3a0>
  40f8d9:	mov    esi,0x90000
  40f8de:	xor    eax,eax
  40f8e0:	call   407090 <open@plt>
  40f8e5:	mov    r13,rax
  40f8e8:	mov    QWORD PTR [rsp+0xb0],rax
  40f8f0:	test   eax,eax
  40f8f2:	jge    40f8fb <__swc_fn_0a4ed24b_000107_4796e893+0xbb>
  40f8f4:	xor    eax,eax
  40f8f6:	jmp    40fe16 <__swc_fn_0a4ed24b_000107_4796e893+0x5d6>
  40f8fb:	nop    DWORD PTR [rax+rax*1+0x0]
  40f900:	movsxd rdi,r13d
  40f903:	mov    esi,0x2
  40f908:	xor    eax,eax
  40f90a:	call   407120 <flock@plt>
  40f90f:	test   eax,eax
  40f911:	je     40f930 <__swc_fn_0a4ed24b_000107_4796e893+0xf0>
  40f913:	xor    eax,eax
  40f915:	call   407130 <__errno_location@plt>
  40f91a:	cmp    DWORD PTR [rax],0x4
  40f91d:	je     40f900 <__swc_fn_0a4ed24b_000107_4796e893+0xc0>
  40f91f:	movsxd rdi,r13d
  40f922:	xor    eax,eax
  40f924:	call   4070b0 <close@plt>
  40f929:	xor    eax,eax
  40f92b:	jmp    40fe16 <__swc_fn_0a4ed24b_000107_4796e893+0x5d6>
  40f930:	lea    r14,[rsp+0x8]
  40f935:	mov    QWORD PTR [rsp+0xb8],r14
  40f93d:	vxorps xmm0,xmm0,xmm0
  40f941:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f947:	mov    QWORD PTR [rsp+0x18],0x0
  40f950:	mov    WORD PTR [rsp+0x20],0x0
  40f957:	mov    DWORD PTR [r14],0x67617753
  40f95e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40f966:	xor    eax,eax
  40f968:	call   407010 <getpid@plt>
  40f96d:	mov    ecx,eax
  40f96f:	mov    eax,0x1c
  40f974:	shrx   eax,ecx,eax
  40f979:	and    eax,0xf
  40f97c:	mov    rdx,QWORD PTR [rip+0x3b4d]        # 4134d0 <__swc_rdata_base_0a4ed24b+0x3c0>
  40f983:	mov    al,BYTE PTR [rdx+rax*1]
  40f986:	rex mov BYTE PTR [rsp+0x10],al
  40f98b:	mov    eax,0x1c
  40f990:	shrx   eax,r12d,eax
  40f995:	and    eax,0xf
  40f998:	mov    al,BYTE PTR [rdx+rax*1]
  40f99b:	rex mov BYTE PTR [rsp+0x19],al
  40f9a0:	mov    eax,0x18
  40f9a5:	shrx   eax,ecx,eax
  40f9aa:	and    eax,0xf
  40f9ad:	mov    al,BYTE PTR [rdx+rax*1]
  40f9b0:	rex mov BYTE PTR [rsp+0x11],al
  40f9b5:	mov    eax,0x18
  40f9ba:	shrx   eax,r12d,eax
  40f9bf:	and    eax,0xf
  40f9c2:	mov    al,BYTE PTR [rdx+rax*1]
  40f9c5:	rex mov BYTE PTR [rsp+0x1a],al
  40f9ca:	mov    eax,0x14
  40f9cf:	shrx   eax,ecx,eax
  40f9d4:	and    eax,0xf
  40f9d7:	mov    al,BYTE PTR [rdx+rax*1]
  40f9da:	rex mov BYTE PTR [rsp+0x12],al
  40f9df:	mov    eax,0x14
  40f9e4:	shrx   eax,r12d,eax
  40f9e9:	and    eax,0xf
  40f9ec:	mov    al,BYTE PTR [rdx+rax*1]
  40f9ef:	rex mov BYTE PTR [rsp+0x1b],al
  40f9f4:	mov    eax,0x10
  40f9f9:	shrx   eax,ecx,eax
  40f9fe:	and    eax,0xf
  40fa01:	mov    al,BYTE PTR [rdx+rax*1]
  40fa04:	rex mov BYTE PTR [rsp+0x13],al
  40fa09:	mov    eax,0x10
  40fa0e:	shrx   eax,r12d,eax
  40fa13:	and    eax,0xf
  40fa16:	mov    al,BYTE PTR [rdx+rax*1]
  40fa19:	rex mov BYTE PTR [rsp+0x1c],al
  40fa1e:	mov    eax,0xc
  40fa23:	shrx   eax,ecx,eax
  40fa28:	and    eax,0xf
  40fa2b:	mov    al,BYTE PTR [rdx+rax*1]
  40fa2e:	rex mov BYTE PTR [rsp+0x14],al
  40fa33:	mov    eax,0xc
  40fa38:	shrx   eax,r12d,eax
  40fa3d:	and    eax,0xf
  40fa40:	mov    al,BYTE PTR [rdx+rax*1]
  40fa43:	rex mov BYTE PTR [rsp+0x1d],al
  40fa48:	mov    eax,0x8
  40fa4d:	shrx   eax,ecx,eax
  40fa52:	and    eax,0xf
  40fa55:	mov    al,BYTE PTR [rdx+rax*1]
  40fa58:	rex mov BYTE PTR [rsp+0x15],al
  40fa5d:	mov    eax,0x8
  40fa62:	shrx   eax,r12d,eax
  40fa67:	and    eax,0xf
  40fa6a:	mov    al,BYTE PTR [rdx+rax*1]
  40fa6d:	rex mov BYTE PTR [rsp+0x1e],al
  40fa72:	mov    eax,0x4
  40fa77:	shrx   eax,ecx,eax
  40fa7c:	and    eax,0xf
  40fa7f:	mov    al,BYTE PTR [rdx+rax*1]
  40fa82:	rex mov BYTE PTR [rsp+0x16],al
  40fa87:	mov    eax,0x4
  40fa8c:	shrx   eax,r12d,eax
  40fa91:	and    eax,0xf
  40fa94:	mov    al,BYTE PTR [rdx+rax*1]
  40fa97:	rex mov BYTE PTR [rsp+0x1f],al
  40fa9c:	xor    eax,eax
  40fa9e:	shrx   eax,ecx,eax
  40faa3:	and    eax,0xf
  40faa6:	mov    al,BYTE PTR [rdx+rax*1]
  40faa9:	rex mov BYTE PTR [rsp+0x17],al
  40faae:	xor    eax,eax
  40fab0:	shrx   eax,r12d,eax
  40fab5:	and    eax,0xf
  40fab8:	mov    al,BYTE PTR [rdx+rax*1]
  40fabb:	rex mov BYTE PTR [rsp+0x20],al
  40fac0:	mov    BYTE PTR [r14+0x10],0x2e
  40fac5:	lea    r12,[rsp+0x22]
  40faca:	vxorps xmm0,xmm0,xmm0
  40face:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40fad4:	mov    DWORD PTR [r12],0x6d656d2f
  40fadc:	mov    WORD PTR [r12+0x4],0x6466
  40fae4:	mov    BYTE PTR [r12+0x6],0x3a
  40faea:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40faf0:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40faf6:	mov    rax,QWORD PTR [rsp+0x18]
  40fafb:	mov    QWORD PTR [rsp+0x39],rax
  40fb00:	rex mov al,BYTE PTR [rsp+0x20]
  40fb05:	rex mov BYTE PTR [rsp+0x41],al
  40fb0a:	mov    DWORD PTR [r12+0x20],0x65642820
  40fb13:	mov    DWORD PTR [r12+0x24],0x6574656c
  40fb1c:	mov    WORD PTR [r12+0x28],0x2964
  40fb24:	lea    rdi,[rip+0x3990]        # 4134bb <__swc_rdata_base_0a4ed24b+0x3ab>
  40fb2b:	xor    eax,eax
  40fb2d:	call   407140 <opendir@plt>
  40fb32:	mov    r15,rax
  40fb35:	test   rax,rax
  40fb38:	jne    40fb4b <__swc_fn_0a4ed24b_000107_4796e893+0x30b>
  40fb3a:	movsxd rdi,r13d
  40fb3d:	xor    eax,eax
  40fb3f:	call   4070b0 <close@plt>
  40fb44:	xor    eax,eax
  40fb46:	jmp    40fe16 <__swc_fn_0a4ed24b_000107_4796e893+0x5d6>
  40fb4b:	mov    rdi,r15
  40fb4e:	xor    eax,eax
  40fb50:	call   407150 <dirfd@plt>
  40fb55:	lea    r14,[rsp+0x54]
  40fb5a:	mov    DWORD PTR [rsp+0x54],eax
  40fb5e:	lea    rbx,[rsp+0x58]
  40fb63:	cs nop WORD PTR [rax+rax*1+0x0]
  40fb6d:	cs nop WORD PTR [rax+rax*1+0x0]
  40fb77:	nop    WORD PTR [rax+rax*1+0x0]
  40fb80:	mov    rdi,r15
  40fb83:	xor    eax,eax
  40fb85:	call   407160 <readdir@plt>
  40fb8a:	test   rax,rax
  40fb8d:	jne    40fba4 <__swc_fn_0a4ed24b_000107_4796e893+0x364>
  40fb8f:	mov    r12,QWORD PTR [rsp+0xa8]
  40fb97:	mov    r13,QWORD PTR [rsp+0xb0]
  40fb9f:	jmp    40fd3a <__swc_fn_0a4ed24b_000107_4796e893+0x4fa>
  40fba4:	vxorps xmm0,xmm0,xmm0
  40fba8:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40fbae:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40fbb4:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40fbba:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40fbc3:	lea    r13,[rax+0x13]
  40fbc7:	mov    rax,r14
  40fbca:	movsxd rdi,DWORD PTR [rax]
  40fbcd:	mov    rsi,r13
  40fbd0:	mov    rdx,rbx
  40fbd3:	mov    ecx,0x40
  40fbd8:	xor    eax,eax
  40fbda:	call   407170 <readlinkat@plt>
  40fbdf:	cmp    rax,0x2a
  40fbe3:	jne    40fb80 <__swc_fn_0a4ed24b_000107_4796e893+0x340>
  40fbe5:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40fbeb:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40fbf1:	vptest xmm0,xmm0
  40fbf6:	jne    40fc26 <__swc_fn_0a4ed24b_000107_4796e893+0x3e6>
  40fbf8:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40fbfe:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40fc04:	vptest xmm0,xmm0
  40fc09:	jne    40fc26 <__swc_fn_0a4ed24b_000107_4796e893+0x3e6>
  40fc0b:	mov    rcx,QWORD PTR [rsp+0x42]
  40fc10:	cmp    QWORD PTR [rsp+0x78],rcx
  40fc15:	jne    40fc26 <__swc_fn_0a4ed24b_000107_4796e893+0x3e6>
  40fc17:	mov    cx,WORD PTR [rsp+0x4a]
  40fc1c:	cmp    WORD PTR [rsp+0x80],cx
  40fc24:	je     40fc54 <__swc_fn_0a4ed24b_000107_4796e893+0x414>
  40fc26:	mov    rax,rbx
  40fc29:	mov    rcx,r12
  40fc2c:	nop    DWORD PTR [rax+0x0]
  40fc30:	movzx  edx,BYTE PTR [rax]
  40fc33:	movzx  r8d,BYTE PTR [rcx]
  40fc37:	cmp    rdx,r8
  40fc3a:	jne    40fc46 <__swc_fn_0a4ed24b_000107_4796e893+0x406>
  40fc3c:	add    rax,0x1
  40fc40:	add    rcx,0x1
  40fc44:	jmp    40fc30 <__swc_fn_0a4ed24b_000107_4796e893+0x3f0>
  40fc46:	mov    rax,rdx
  40fc49:	sub    rax,r8
  40fc4c:	test   eax,eax
  40fc4e:	jne    40fb80 <__swc_fn_0a4ed24b_000107_4796e893+0x340>
  40fc54:	movsxd rdi,DWORD PTR [r14]
  40fc57:	mov    rsi,r13
  40fc5a:	mov    edx,0x80002
  40fc5f:	xor    eax,eax
  40fc61:	call   407180 <openat@plt>
  40fc66:	lea    rbx,[rsp+0x98]
  40fc6e:	mov    DWORD PTR [rsp+0x98],eax
  40fc75:	test   eax,eax
  40fc77:	mov    r13,QWORD PTR [rsp+0xb0]
  40fc7f:	jge    40fca4 <__swc_fn_0a4ed24b_000107_4796e893+0x464>
  40fc81:	mov    rdi,r15
  40fc84:	xor    eax,eax
  40fc86:	call   407190 <closedir@plt>
  40fc8b:	mov    r13,QWORD PTR [rsp+0xb0]
  40fc93:	movsxd rdi,r13d
  40fc96:	xor    eax,eax
  40fc98:	call   4070b0 <close@plt>
  40fc9d:	xor    eax,eax
  40fc9f:	jmp    40fe16 <__swc_fn_0a4ed24b_000107_4796e893+0x5d6>
  40fca4:	mov    rax,rbx
  40fca7:	movsxd rdi,DWORD PTR [rax]
  40fcaa:	xor    esi,esi
  40fcac:	mov    edx,0x2
  40fcb1:	xor    eax,eax
  40fcb3:	call   4070a0 <lseek@plt>
  40fcb8:	mov    r12,QWORD PTR [rsp+0xa8]
  40fcc0:	cmp    rax,r12
  40fcc3:	je     40fcea <__swc_fn_0a4ed24b_000107_4796e893+0x4aa>
  40fcc5:	movsxd rdi,DWORD PTR [rbx]
  40fcc8:	xor    eax,eax
  40fcca:	call   4070b0 <close@plt>
  40fccf:	mov    rdi,r15
  40fcd2:	xor    eax,eax
  40fcd4:	call   407190 <closedir@plt>
  40fcd9:	movsxd rdi,r13d
  40fcdc:	xor    eax,eax
  40fcde:	call   4070b0 <close@plt>
  40fce3:	xor    eax,eax
  40fce5:	jmp    40fe16 <__swc_fn_0a4ed24b_000107_4796e893+0x5d6>
  40fcea:	xor    edi,edi
  40fcec:	mov    rsi,r12
  40fcef:	mov    edx,0x3
  40fcf4:	mov    ecx,0x1
  40fcf9:	mov    rax,rbx
  40fcfc:	movsxd r8,DWORD PTR [rax]
  40fcff:	xor    r9d,r9d
  40fd02:	xor    eax,eax
  40fd04:	call   4070c0 <mmap@plt>
  40fd09:	xor    r12d,r12d
  40fd0c:	cmp    rax,0xffffffffffffffff
  40fd10:	cmovne r12,rax
  40fd14:	movsxd rdi,DWORD PTR [rbx]
  40fd17:	xor    eax,eax
  40fd19:	call   4070b0 <close@plt>
  40fd1e:	mov    rdi,r15
  40fd21:	xor    eax,eax
  40fd23:	call   407190 <closedir@plt>
  40fd28:	movsxd rdi,r13d
  40fd2b:	xor    eax,eax
  40fd2d:	call   4070b0 <close@plt>
  40fd32:	mov    rax,r12
  40fd35:	jmp    40fe16 <__swc_fn_0a4ed24b_000107_4796e893+0x5d6>
  40fd3a:	mov    r14,QWORD PTR [rsp+0xb8]
  40fd42:	mov    rdi,r14
  40fd45:	mov    esi,0x1
  40fd4a:	xor    eax,eax
  40fd4c:	call   4071a0 <memfd_create@plt>
  40fd51:	lea    rbx,[rsp+0x9c]
  40fd59:	mov    DWORD PTR [rsp+0x9c],eax
  40fd60:	test   eax,eax
  40fd62:	jge    40fd7f <__swc_fn_0a4ed24b_000107_4796e893+0x53f>
  40fd64:	mov    rdi,r15
  40fd67:	xor    eax,eax
  40fd69:	call   407190 <closedir@plt>
  40fd6e:	movsxd rdi,r13d
  40fd71:	xor    eax,eax
  40fd73:	call   4070b0 <close@plt>
  40fd78:	xor    eax,eax
  40fd7a:	jmp    40fe16 <__swc_fn_0a4ed24b_000107_4796e893+0x5d6>
  40fd7f:	mov    rax,rbx
  40fd82:	movsxd rdi,DWORD PTR [rax]
  40fd85:	mov    rsi,r12
  40fd88:	xor    eax,eax
  40fd8a:	call   4071b0 <ftruncate@plt>
  40fd8f:	test   eax,eax
  40fd91:	je     40fdb5 <__swc_fn_0a4ed24b_000107_4796e893+0x575>
  40fd93:	movsxd rdi,DWORD PTR [rbx]
  40fd96:	xor    eax,eax
  40fd98:	call   4070b0 <close@plt>
  40fd9d:	mov    rdi,r15
  40fda0:	xor    eax,eax
  40fda2:	call   407190 <closedir@plt>
  40fda7:	movsxd rdi,r13d
  40fdaa:	xor    eax,eax
  40fdac:	call   4070b0 <close@plt>
  40fdb1:	xor    eax,eax
  40fdb3:	jmp    40fe16 <__swc_fn_0a4ed24b_000107_4796e893+0x5d6>
  40fdb5:	xor    edi,edi
  40fdb7:	mov    rsi,r12
  40fdba:	mov    edx,0x3
  40fdbf:	mov    ecx,0x1
  40fdc4:	mov    rax,rbx
  40fdc7:	movsxd r8,DWORD PTR [rax]
  40fdca:	xor    r9d,r9d
  40fdcd:	xor    eax,eax
  40fdcf:	call   4070c0 <mmap@plt>
  40fdd4:	mov    r12,rax
  40fdd7:	cmp    rax,0xffffffffffffffff
  40fddb:	jne    40fdff <__swc_fn_0a4ed24b_000107_4796e893+0x5bf>
  40fddd:	movsxd rdi,DWORD PTR [rbx]
  40fde0:	xor    eax,eax
  40fde2:	call   4070b0 <close@plt>
  40fde7:	mov    rdi,r15
  40fdea:	xor    eax,eax
  40fdec:	call   407190 <closedir@plt>
  40fdf1:	movsxd rdi,r13d
  40fdf4:	xor    eax,eax
  40fdf6:	call   4070b0 <close@plt>
  40fdfb:	xor    eax,eax
  40fdfd:	jmp    40fe16 <__swc_fn_0a4ed24b_000107_4796e893+0x5d6>
  40fdff:	mov    rdi,r15
  40fe02:	xor    eax,eax
  40fe04:	call   407190 <closedir@plt>
  40fe09:	movsxd rdi,r13d
  40fe0c:	xor    eax,eax
  40fe0e:	call   4070b0 <close@plt>
  40fe13:	mov    rax,r12
  40fe16:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40fe1f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40fe28:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40fe31:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40fe3a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  40fe43:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40fe4c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  40fe55:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40fe5e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  40fe67:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  40fe70:	add    rsp,0x170
  40fe77:	pop    r15
  40fe79:	pop    r14
  40fe7b:	pop    r13
  40fe7d:	pop    rsi
  40fe7e:	pop    rdi
  40fe7f:	pop    r12
  40fe81:	pop    rbx
  40fe82:	ret
	...

000000000040fe90 <__swc_fn_0a4ed24b_000110_a808fe76>:
  40fe90:	push   rsi
  40fe91:	push   rdi
  40fe92:	push   r12
  40fe94:	push   r13
  40fe96:	sub    rsp,0x8
  40fe9a:	mov    rsi,r8
  40fe9d:	mov    rdi,rcx
  40fea0:	mov    r12,rdx
  40fea3:	call   409120 <__swc_fn_0a4ed24b_000108_84af7666>
  40fea8:	mov    r13,rax
  40feab:	test   rax,rax
  40feae:	jne    40febb <__swc_fn_0a4ed24b_000110_a808fe76+0x2b>
  40feb0:	add    rsp,0x8
  40feb4:	pop    r13
  40feb6:	pop    r12
  40feb8:	pop    rdi
  40feb9:	pop    rsi
  40feba:	ret
  40febb:	mov    rcx,r13
  40febe:	call   40cff0 <__swc_fn_0a4ed24b_000133_4b2af8da>
  40fec3:	mov    rax,QWORD PTR [r13+0x8]
  40fec7:	test   rax,rax
  40feca:	je     40ff09 <__swc_fn_0a4ed24b_000110_a808fe76+0x79>
  40fecc:	nop    DWORD PTR [rax+0x0]
  40fed0:	lea    rcx,[rax+0x1000]
  40fed7:	cmp    rdi,rcx
  40feda:	jne    40ff01 <__swc_fn_0a4ed24b_000110_a808fe76+0x71>
  40fedc:	cmp    r12,0x1000
  40fee3:	jb     40ff01 <__swc_fn_0a4ed24b_000110_a808fe76+0x71>
  40fee5:	test   sil,sil
  40fee8:	setne  cl
  40feeb:	mov    BYTE PTR [rax+0x10],cl
  40feee:	mov    rcx,r13
  40fef1:	call   410400 <__swc_fn_0a4ed24b_000134_29412410>
  40fef6:	add    rsp,0x8
  40fefa:	pop    r13
  40fefc:	pop    r12
  40fefe:	pop    rdi
  40feff:	pop    rsi
  40ff00:	ret
  40ff01:	mov    rax,QWORD PTR [rax]
  40ff04:	test   rax,rax
  40ff07:	jne    40fed0 <__swc_fn_0a4ed24b_000110_a808fe76+0x40>
  40ff09:	mov    rcx,r13
  40ff0c:	call   410400 <__swc_fn_0a4ed24b_000134_29412410>
  40ff11:	add    rsp,0x8
  40ff15:	pop    r13
  40ff17:	pop    r12
  40ff19:	pop    rdi
  40ff1a:	pop    rsi
  40ff1b:	ret
  40ff1c:	add    BYTE PTR [rax],al
	...

000000000040ff20 <__swc_fn_0a4ed24b_000113_49b378a9>:
  40ff20:	sub    rsp,0x8
  40ff24:	test   rcx,rcx
  40ff27:	jne    40ff2e <__swc_fn_0a4ed24b_000113_49b378a9+0xe>
  40ff29:	add    rsp,0x8
  40ff2d:	ret
  40ff2e:	call   40cb00 <__swc_fn_0a4ed24b_000115_1ba33335>
  40ff33:	add    rsp,0x8
  40ff37:	ret
	...

000000000040ff40 <__swc_fn_0a4ed24b_000116_035d76a1>:
  40ff40:	push   r12
  40ff42:	push   r13
  40ff44:	push   r14
  40ff46:	push   rdi
  40ff47:	push   rsi
  40ff48:	sub    rsp,0xc0
  40ff4f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40ff55:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40ff5b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40ff61:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40ff67:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40ff6d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40ff73:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40ff79:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40ff82:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40ff8b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40ff94:	mov    r12,QWORD PTR [rcx]
  40ff97:	test   r12,r12
  40ff9a:	jne    40ffac <__swc_fn_0a4ed24b_000116_035d76a1+0x6c>
  40ff9c:	add    rsp,0xc0
  40ffa3:	pop    rsi
  40ffa4:	pop    rdi
  40ffa5:	pop    r14
  40ffa7:	pop    r13
  40ffa9:	pop    r12
  40ffab:	ret
  40ffac:	xor    r13d,r13d
  40ffaf:	mov    r14,QWORD PTR [rcx+0x8]
  40ffb3:	cs nop WORD PTR [rax+rax*1+0x0]
  40ffbd:	nop    DWORD PTR [rax]
  40ffc0:	cmp    r13,r14
  40ffc3:	jae    40fffe <__swc_fn_0a4ed24b_000116_035d76a1+0xbe>
  40ffc5:	lea    rax,[r12+r13*1]
  40ffc9:	mov    rcx,r14
  40ffcc:	sub    rcx,r13
  40ffcf:	mov    edi,0x1
  40ffd4:	mov    rsi,rax
  40ffd7:	mov    rdx,rcx
  40ffda:	xor    eax,eax
  40ffdc:	call   4071c0 <write@plt>
  40ffe1:	test   rax,rax
  40ffe4:	jle    40ffeb <__swc_fn_0a4ed24b_000116_035d76a1+0xab>
  40ffe6:	add    r13,rax
  40ffe9:	jmp    40ffc0 <__swc_fn_0a4ed24b_000116_035d76a1+0x80>
  40ffeb:	test   rax,rax
  40ffee:	je     40fffc <__swc_fn_0a4ed24b_000116_035d76a1+0xbc>
  40fff0:	xor    eax,eax
  40fff2:	call   407130 <__errno_location@plt>
  40fff7:	cmp    DWORD PTR [rax],0x4
  40fffa:	je     40ffc0 <__swc_fn_0a4ed24b_000116_035d76a1+0x80>
  40fffc:	jmp    40fffe <__swc_fn_0a4ed24b_000116_035d76a1+0xbe>
  40fffe:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410004:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  41000a:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410010:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  410016:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  41001c:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  410022:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  410028:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  410031:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  41003a:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410043:	add    rsp,0xc0
  41004a:	pop    rsi
  41004b:	pop    rdi
  41004c:	pop    r14
  41004e:	pop    r13
  410050:	pop    r12
  410052:	ret
	...

0000000000410060 <__swc_fn_0a4ed24b_000119_9175a56a>:
  410060:	push   rbx
  410061:	push   r12
  410063:	push   rdi
  410064:	push   rsi
  410065:	sub    rsp,0x4a8
  41006c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  410075:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  41007e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  410087:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  410090:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  410099:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  4100a2:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  4100ab:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  4100b4:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  4100bd:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  4100c6:	mov    rbx,rdx
  4100c9:	mov    r12d,ecx
  4100cc:	vxorps xmm0,xmm0,xmm0
  4100d0:	xor    eax,eax
  4100d2:	cs nop WORD PTR [rax+rax*1+0x0]
  4100dc:	nop    DWORD PTR [rax+0x0]
  4100e0:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  4100e6:	add    rax,0x10
  4100ea:	cmp    rax,0x400
  4100f1:	jne    4100e0 <__swc_fn_0a4ed24b_000119_9175a56a+0x80>
  4100f3:	lea    rdi,[rsp+0x8]
  4100f8:	mov    esi,0x80
  4100fd:	xor    eax,eax
  4100ff:	call   4071d0 <backtrace@plt>
  410104:	test   eax,eax
  410106:	jle    410115 <__swc_fn_0a4ed24b_000119_9175a56a+0xb5>
  410108:	movsxd rax,eax
  41010b:	lea    rcx,[r12+0x1]
  410110:	cmp    rcx,rax
  410113:	jb     410119 <__swc_fn_0a4ed24b_000119_9175a56a+0xb9>
  410115:	xor    eax,eax
  410117:	jmp    41014a <__swc_fn_0a4ed24b_000119_9175a56a+0xea>
  410119:	mov    rcx,QWORD PTR [rbx+0x8]
  41011d:	sub    rax,r12
  410120:	lea    rsi,[rax-0x1]
  410124:	cmp    rcx,rsi
  410127:	cmovbe rsi,rcx
  41012b:	lea    eax,[r12+0x1]
  410130:	lea    rax,[rsp+rax*8+0x8]
  410135:	mov    rcx,QWORD PTR [rbx]
  410138:	mov    rdx,rax
  41013b:	lea    r8,[rsi*8+0x0]
  410143:	call   409100 <__swc_fn_0a4ed24b_000105_6fd80914>
  410148:	mov    eax,esi
  41014a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  410153:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  41015c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  410165:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  41016e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  410177:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  410180:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  410189:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  410192:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  41019b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  4101a4:	add    rsp,0x4a8
  4101ab:	pop    rsi
  4101ac:	pop    rdi
  4101ad:	pop    r12
  4101af:	pop    rbx
  4101b0:	ret
	...

00000000004101c0 <__swc_fn_0a4ed24b_000122_e09461fd>:
  4101c0:	mov    QWORD PTR [rcx],0x0
  4101c7:	ret
	...

00000000004101d0 <__swc_fn_0a4ed24b_000125_ce762363>:
  4101d0:	push   rdi
  4101d1:	push   rsi
  4101d2:	sub    rsp,0xa8
  4101d9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4101df:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4101e5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4101eb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4101f1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4101f7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4101fd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410203:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410209:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410212:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41021b:	mov    edi,ecx
  41021d:	mov    rsi,rdx
  410220:	xor    eax,eax
  410222:	call   407060 <pthread_setspecific@plt>
  410227:	test   eax,eax
  410229:	sete   al
  41022c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410232:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410238:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41023e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410244:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  41024a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410250:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410256:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  41025c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410265:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41026e:	add    rsp,0xa8
  410275:	pop    rsi
  410276:	pop    rdi
  410277:	ret
	...

0000000000410280 <__swc_fn_0a4ed24b_000128_41c3251c>:
  410280:	push   rdi
  410281:	push   rsi
  410282:	sub    rsp,0xa8
  410289:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41028f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410295:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41029b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4102a1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4102a7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4102ad:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4102b3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4102b9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4102c2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4102cb:	test   rcx,rcx
  4102ce:	je     4102e1 <__swc_fn_0a4ed24b_000128_41c3251c+0x61>
  4102d0:	lea    rax,[rcx-0x1]
  4102d4:	mov    eax,eax
  4102d6:	mov    edi,eax
  4102d8:	xor    eax,eax
  4102da:	call   407000 <pthread_getspecific@plt>
  4102df:	jmp    4102e3 <__swc_fn_0a4ed24b_000128_41c3251c+0x63>
  4102e1:	xor    eax,eax
  4102e3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4102e9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4102ef:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4102f5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4102fb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410301:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410307:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41030d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410313:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41031c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410325:	add    rsp,0xa8
  41032c:	pop    rsi
  41032d:	pop    rdi
  41032e:	ret
	...

0000000000410330 <__swc_fn_0a4ed24b_000131_944f555b>:
  410330:	push   rdi
  410331:	push   rsi
  410332:	sub    rsp,0xb8
  410339:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41033f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410345:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41034b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410351:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410357:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41035d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410363:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41036c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410375:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41037e:	vxorps xmm0,xmm0,xmm0
  410382:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410388:	mov    edi,0x1
  41038d:	lea    rsi,[rsp+0x8]
  410392:	xor    eax,eax
  410394:	call   407110 <clock_gettime@plt>
  410399:	mov    rax,QWORD PTR [rsp+0x8]
  41039e:	imul   rax,rax,0x3b9aca00
  4103a5:	add    rax,QWORD PTR [rsp+0x10]
  4103aa:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4103b0:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4103b6:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4103bc:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4103c2:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4103c8:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4103ce:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4103d4:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4103dd:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4103e6:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4103ef:	add    rsp,0xb8
  4103f6:	pop    rsi
  4103f7:	pop    rdi
  4103f8:	ret
  4103f9:	add    BYTE PTR [rax],al
  4103fb:	add    BYTE PTR [rax],al
  4103fd:	add    BYTE PTR [rax],al
	...

0000000000410400 <__swc_fn_0a4ed24b_000134_29412410>:
  410400:	sub    rsp,0x8
  410404:	xor    eax,eax
  410406:	mov    DWORD PTR [rcx],eax
  410408:	mov    edx,0x7fffffff
  41040d:	call   409800 <__swc_fn_0a4ed24b_000132_f908e7f9>
  410412:	add    rsp,0x8
  410416:	ret
	...

0000000000410420 <__swc_fn_0a4ed24b_000137_a4ba10ed>:
  410420:	push   rdi
  410421:	push   rsi
  410422:	sub    rsp,0xb8
  410429:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41042f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410435:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41043b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410441:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410447:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41044d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410453:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41045c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410465:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41046e:	mov    edi,0x1
  410473:	xor    eax,eax
  410475:	call   4071e0 <__x86_get_cpuid_feature_leaf@plt>
  41047a:	mov    eax,DWORD PTR [rax+0x14]
  41047d:	and    eax,0x20
  410480:	setne  al
  410483:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410489:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  41048f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410495:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41049b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4104a1:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4104a7:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4104ad:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4104b6:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4104bf:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4104c8:	add    rsp,0xb8
  4104cf:	pop    rsi
  4104d0:	pop    rdi
  4104d1:	ret
	...

00000000004104e0 <__swc_fn_0a4ed24b_000140_c6b99a56>:
  4104e0:	push   rsi
  4104e1:	push   rdi
  4104e2:	push   r12
  4104e4:	push   r13
  4104e6:	push   r14
  4104e8:	push   r15
  4104ea:	cmp    rdx,0x40
  4104ee:	jae    4104fd <__swc_fn_0a4ed24b_000140_c6b99a56+0x1d>
  4104f0:	xor    eax,eax
  4104f2:	pop    r15
  4104f4:	pop    r14
  4104f6:	pop    r13
  4104f8:	pop    r12
  4104fa:	pop    rdi
  4104fb:	pop    rsi
  4104fc:	ret
  4104fd:	cmp    BYTE PTR [rcx],0x7f
  410500:	jne    410544 <__swc_fn_0a4ed24b_000140_c6b99a56+0x64>
  410502:	movzx  eax,BYTE PTR [rcx+0x1]
  410506:	cmp    eax,0x45
  410509:	setne  al
  41050c:	jne    410540 <__swc_fn_0a4ed24b_000140_c6b99a56+0x60>
  41050e:	movzx  eax,BYTE PTR [rcx+0x2]
  410512:	cmp    eax,0x4c
  410515:	setne  al
  410518:	jne    410540 <__swc_fn_0a4ed24b_000140_c6b99a56+0x60>
  41051a:	movzx  eax,BYTE PTR [rcx+0x3]
  41051e:	cmp    eax,0x46
  410521:	setne  al
  410524:	jne    410540 <__swc_fn_0a4ed24b_000140_c6b99a56+0x60>
  410526:	cmp    BYTE PTR [rcx+0x4],0x2
  41052a:	setne  al
  41052d:	jne    410540 <__swc_fn_0a4ed24b_000140_c6b99a56+0x60>
  41052f:	cmp    BYTE PTR [rcx+0x5],0x1
  410533:	setne  al
  410536:	jne    410540 <__swc_fn_0a4ed24b_000140_c6b99a56+0x60>
  410538:	cmp    WORD PTR [rcx+0x12],0x3e
  41053d:	setne  al
  410540:	test   al,al
  410542:	je     410551 <__swc_fn_0a4ed24b_000140_c6b99a56+0x71>
  410544:	xor    eax,eax
  410546:	pop    r15
  410548:	pop    r14
  41054a:	pop    r13
  41054c:	pop    r12
  41054e:	pop    rdi
  41054f:	pop    rsi
  410550:	ret
  410551:	cmp    WORD PTR [rcx+0x3a],0x40
  410556:	jne    410571 <__swc_fn_0a4ed24b_000140_c6b99a56+0x91>
  410558:	cmp    WORD PTR [rcx+0x3c],0x0
  41055d:	sete   al
  410560:	je     41056d <__swc_fn_0a4ed24b_000140_c6b99a56+0x8d>
  410562:	mov    ax,WORD PTR [rcx+0x3c]
  410566:	cmp    WORD PTR [rcx+0x3e],ax
  41056a:	setae  al
  41056d:	test   al,al
  41056f:	je     41057e <__swc_fn_0a4ed24b_000140_c6b99a56+0x9e>
  410571:	xor    eax,eax
  410573:	pop    r15
  410575:	pop    r14
  410577:	pop    r13
  410579:	pop    r12
  41057b:	pop    rdi
  41057c:	pop    rsi
  41057d:	ret
  41057e:	movzx  eax,WORD PTR [rcx+0x3c]
  410582:	shl    rax,0x6
  410586:	cmp    rax,rdx
  410589:	ja     410597 <__swc_fn_0a4ed24b_000140_c6b99a56+0xb7>
  41058b:	mov    r9,rdx
  41058e:	sub    r9,rax
  410591:	cmp    QWORD PTR [rcx+0x28],r9
  410595:	jbe    4105a4 <__swc_fn_0a4ed24b_000140_c6b99a56+0xc4>
  410597:	xor    eax,eax
  410599:	pop    r15
  41059b:	pop    r14
  41059d:	pop    r13
  41059f:	pop    r12
  4105a1:	pop    rdi
  4105a2:	pop    rsi
  4105a3:	ret
  4105a4:	mov    rax,QWORD PTR [rcx+0x28]
  4105a8:	add    rax,rcx
  4105ab:	movzx  r9d,WORD PTR [rcx+0x3e]
  4105b0:	lea    r9,[r9*8+0x0]
  4105b8:	lea    r10,[rax+r9*8]
  4105bc:	cmp    QWORD PTR [r10+0x20],rdx
  4105c0:	ja     4105e2 <__swc_fn_0a4ed24b_000140_c6b99a56+0x102>
  4105c2:	mov    r11,rdx
  4105c5:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  4105ca:	cmp    QWORD PTR [r10+0x18],r11
  4105ce:	seta   r9b
  4105d2:	ja     4105dd <__swc_fn_0a4ed24b_000140_c6b99a56+0xfd>
  4105d4:	cmp    QWORD PTR [r10+0x20],0x9
  4105d9:	setb   r9b
  4105dd:	test   r9b,r9b
  4105e0:	je     4105ef <__swc_fn_0a4ed24b_000140_c6b99a56+0x10f>
  4105e2:	xor    eax,eax
  4105e4:	pop    r15
  4105e6:	pop    r14
  4105e8:	pop    r13
  4105ea:	pop    r12
  4105ec:	pop    rdi
  4105ed:	pop    rsi
  4105ee:	ret
  4105ef:	movzx  r9d,WORD PTR [rcx+0x3c]
  4105f4:	xor    r11d,r11d
  4105f7:	test   r9,r9
  4105fa:	jbe    4106f5 <__swc_fn_0a4ed24b_000140_c6b99a56+0x215>
  410600:	mov    rsi,QWORD PTR [r10+0x20]
  410604:	sub    rsi,0x9
  410608:	cs nop WORD PTR [rax+rax*1+0x0]
  410612:	cs nop WORD PTR [rax+rax*1+0x0]
  41061c:	nop    DWORD PTR [rax+0x0]
  410620:	movzx  edi,r11w
  410624:	lea    rdi,[rdi*8+0x0]
  41062c:	lea    r12,[rax+rdi*8]
  410630:	rex mov edi,DWORD PTR [rax+rdi*8]
  410634:	cmp    rdi,rsi
  410637:	ja     4106e8 <__swc_fn_0a4ed24b_000140_c6b99a56+0x208>
  41063d:	mov    r13,QWORD PTR [r10+0x18]
  410641:	add    r13,rdi
  410644:	lea    rdi,[rcx+r13*1]
  410648:	lea    r13,[rip+0x2ee1]        # 413530 <__swc_rdata_base_0a4ed24b+0x420>
  41064f:	movabs r14,0x676264676177732e
  410659:	cmp    QWORD PTR [rdi],r14
  41065c:	jne    410665 <__swc_fn_0a4ed24b_000140_c6b99a56+0x185>
  41065e:	rex cmp BYTE PTR [rdi+0x8],0x0
  410663:	je     410692 <__swc_fn_0a4ed24b_000140_c6b99a56+0x1b2>
  410665:	cs nop WORD PTR [rax+rax*1+0x0]
  41066f:	nop
  410670:	movzx  r14d,BYTE PTR [rdi]
  410674:	movzx  r15d,BYTE PTR [r13+0x0]
  410679:	cmp    r14,r15
  41067c:	jne    410688 <__swc_fn_0a4ed24b_000140_c6b99a56+0x1a8>
  41067e:	add    rdi,0x1
  410682:	add    r13,0x1
  410686:	jmp    410670 <__swc_fn_0a4ed24b_000140_c6b99a56+0x190>
  410688:	mov    rdi,r14
  41068b:	sub    rdi,r15
  41068e:	test   edi,edi
  410690:	jne    4106e8 <__swc_fn_0a4ed24b_000140_c6b99a56+0x208>
  410692:	cmp    DWORD PTR [r12+0x4],0x1
  410698:	jne    4106c0 <__swc_fn_0a4ed24b_000140_c6b99a56+0x1e0>
  41069a:	cmp    QWORD PTR [r12+0x20],0x10
  4106a0:	setb   al
  4106a3:	jb     4106bc <__swc_fn_0a4ed24b_000140_c6b99a56+0x1dc>
  4106a5:	cmp    QWORD PTR [r12+0x20],rdx
  4106aa:	seta   al
  4106ad:	ja     4106bc <__swc_fn_0a4ed24b_000140_c6b99a56+0x1dc>
  4106af:	sub    rdx,QWORD PTR [r12+0x20]
  4106b4:	cmp    QWORD PTR [r12+0x18],rdx
  4106b9:	seta   al
  4106bc:	test   al,al
  4106be:	je     4106cd <__swc_fn_0a4ed24b_000140_c6b99a56+0x1ed>
  4106c0:	xor    eax,eax
  4106c2:	pop    r15
  4106c4:	pop    r14
  4106c6:	pop    r13
  4106c8:	pop    r12
  4106ca:	pop    rdi
  4106cb:	pop    rsi
  4106cc:	ret
  4106cd:	mov    rax,QWORD PTR [r12+0x20]
  4106d2:	mov    QWORD PTR [r8],rax
  4106d5:	mov    rax,QWORD PTR [r12+0x18]
  4106da:	add    rax,rcx
  4106dd:	pop    r15
  4106df:	pop    r14
  4106e1:	pop    r13
  4106e3:	pop    r12
  4106e5:	pop    rdi
  4106e6:	pop    rsi
  4106e7:	ret
  4106e8:	add    r11,0x1
  4106ec:	cmp    r11,r9
  4106ef:	jb     410620 <__swc_fn_0a4ed24b_000140_c6b99a56+0x140>
  4106f5:	xor    eax,eax
  4106f7:	pop    r15
  4106f9:	pop    r14
  4106fb:	pop    r13
  4106fd:	pop    r12
  4106ff:	pop    rdi
  410700:	pop    rsi
  410701:	ret
	...

0000000000410710 <__swc_fn_0a4ed24b_000143_81c0d993>:
  410710:	push   rdi
  410711:	push   rsi
  410712:	sub    rsp,0xa8
  410719:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41071f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410725:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41072b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410731:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410737:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41073d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410743:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410749:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410752:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41075b:	mov    rdi,rcx
  41075e:	xor    eax,eax
  410760:	call   4071f0 <free@plt>
  410765:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41076b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410771:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410777:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41077d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410783:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410789:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41078f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410795:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41079e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4107a7:	add    rsp,0xa8
  4107ae:	pop    rsi
  4107af:	pop    rdi
  4107b0:	ret
	...

00000000004107c0 <__swc_fn_0a4ed24b_000146_43f4fdca>:
  4107c0:	push   rbx
  4107c1:	push   rsi
  4107c2:	push   rdi
  4107c3:	push   r12
  4107c5:	push   r13
  4107c7:	push   r15
  4107c9:	sub    rsp,0x4e8
  4107d0:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  4107d9:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  4107e2:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  4107eb:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  4107f4:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  4107fd:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  410806:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  41080f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  410818:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  410821:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  41082a:	mov    rbx,QWORD PTR [rcx]
  41082d:	mov    rcx,QWORD PTR [rcx+0x8]
  410831:	mov    rsi,rcx
  410834:	xor    edi,edi
  410836:	vmovsd xmm6,QWORD PTR [rip+0x2d52]        # 413590 <__swc_rdata_base_0a4ed24b+0x480>
  41083e:	vmovsd xmm7,QWORD PTR [rip+0x2d53]        # 413599 <__swc_rdata_base_0a4ed24b+0x489>
  410846:	vmovsd xmm8,QWORD PTR [rip+0x2d54]        # 4135a2 <__swc_rdata_base_0a4ed24b+0x492>
  41084e:	vmovsd xmm9,QWORD PTR [rip+0x2d55]        # 4135ab <__swc_rdata_base_0a4ed24b+0x49b>
  410856:	vmovsd xmm10,QWORD PTR [rip+0x2d56]        # 4135b4 <__swc_rdata_base_0a4ed24b+0x4a4>
  41085e:	vmovups xmm11,xmm6
  410862:	vmovsd QWORD PTR [rsp+0x418],xmm7
  41086b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  410874:	vmovsd QWORD PTR [rsp+0x428],xmm9
  41087d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  410886:	vmovsd xmm15,QWORD PTR [rip+0x2d2f]        # 4135bd <__swc_rdata_base_0a4ed24b+0x4ad>
  41088e:	vmovups xmm14,xmm15
  410893:	vmovups xmm0,xmm9
  410898:	vmovsd QWORD PTR [rsp+0x438],xmm15
  4108a1:	vmovups xmm13,xmm8
  4108a6:	vmovsd QWORD PTR [rsp+0x440],xmm15
  4108af:	test   rsi,rsi
  4108b2:	je     4118e3 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1123>
  4108b8:	cs nop WORD PTR [rax+rax*1+0x0]
  4108c2:	cs nop WORD PTR [rax+rax*1+0x0]
  4108cc:	nop    DWORD PTR [rax+0x0]
  4108d0:	lea    rcx,[rdi+rdi*1]
  4108d4:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  4108d9:	vpshufd xmm3,xmm2,0xee
  4108de:	vmovq  rcx,xmm3
  4108e3:	test   rcx,rcx
  4108e6:	je     4108fc <__swc_fn_0a4ed24b_000146_43f4fdca+0x13c>
  4108e8:	test   DWORD PTR [rcx+0x28],0x400000
  4108ef:	je     4108fc <__swc_fn_0a4ed24b_000146_43f4fdca+0x13c>
  4108f1:	mov    rdx,QWORD PTR [rcx+0x30]
  4108f5:	test   rdx,rdx
  4108f8:	cmovne rcx,rdx
  4108fc:	test   DWORD PTR [rcx+0x28],0x1000
  410903:	je     410924 <__swc_fn_0a4ed24b_000146_43f4fdca+0x164>
  410905:	mov    rdx,QWORD PTR [rcx+0x40]
  410909:	mov    rcx,rdx
  41090c:	vmovq  r8,xmm2
  410911:	mov    r8,QWORD PTR [r8]
  410914:	mov    QWORD PTR [rsp+0x60],r8
  410919:	mov    QWORD PTR [rsp+0x68],rdx
  41091e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  410924:	test   BYTE PTR [rcx+0x28],0x1
  410928:	jne    410930 <__swc_fn_0a4ed24b_000146_43f4fdca+0x170>
  41092a:	vmovups xmm12,xmm0
  41092e:	jmp    41094a <__swc_fn_0a4ed24b_000146_43f4fdca+0x18a>
  410930:	vmovq  rax,xmm2
  410935:	mov    rax,QWORD PTR [rax]
  410938:	lea    rcx,[rax+0x10]
  41093c:	vmovups xmm12,xmm0
  410940:	call   40ff40 <__swc_fn_0a4ed24b_000116_035d76a1>
  410945:	jmp    4118c5 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1105>
  41094a:	test   DWORD PTR [rcx+0x28],0x400
  410951:	je     4109b2 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1f2>
  410953:	vmovq  rax,xmm2
  410958:	mov    rax,QWORD PTR [rax]
  41095b:	xor    ecx,ecx
  41095d:	test   rax,rax
  410960:	je     410990 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1d0>
  410962:	mov    rdx,rax
  410965:	mov    r8b,BYTE PTR [rdx]
  410968:	test   r8b,r8b
  41096b:	je     410990 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1d0>
  41096d:	cs nop WORD PTR [rax+rax*1+0x0]
  410977:	nop    WORD PTR [rax+rax*1+0x0]
  410980:	add    rdx,0x1
  410984:	add    rcx,0x1
  410988:	mov    r8b,BYTE PTR [rdx]
  41098b:	test   r8b,r8b
  41098e:	jne    410980 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1c0>
  410990:	mov    QWORD PTR [rsp+0x88],rax
  410998:	mov    QWORD PTR [rsp+0x90],rcx
  4109a0:	lea    rcx,[rsp+0x88]
  4109a8:	call   40ff40 <__swc_fn_0a4ed24b_000116_035d76a1>
  4109ad:	jmp    4118c5 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1105>
  4109b2:	cmp    BYTE PTR [rcx+0x2c],0x6
  4109b6:	jne    4109cd <__swc_fn_0a4ed24b_000146_43f4fdca+0x20d>
  4109b8:	vmovq  rax,xmm2
  4109bd:	mov    rax,QWORD PTR [rax]
  4109c0:	mov    rcx,rax
  4109c3:	call   409cd0 <__swc_fn_0a4ed24b_000144_72996a5b>
  4109c8:	jmp    4118c5 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1105>
  4109cd:	cmp    BYTE PTR [rcx+0x2c],0x1
  4109d1:	jne    4118b9 <__swc_fn_0a4ed24b_000146_43f4fdca+0x10f9>
  4109d7:	vmovq  rdx,xmm2
  4109dc:	mov    cl,BYTE PTR [rcx+0x40]
  4109df:	cmp    cl,0x7
  4109e2:	jb     410a25 <__swc_fn_0a4ed24b_000146_43f4fdca+0x265>
  4109e4:	je     410a98 <__swc_fn_0a4ed24b_000146_43f4fdca+0x2d8>
  4109ea:	cmp    cl,0x8
  4109ed:	je     410aa4 <__swc_fn_0a4ed24b_000146_43f4fdca+0x2e4>
  4109f3:	cmp    cl,0x9
  4109f6:	je     410abd <__swc_fn_0a4ed24b_000146_43f4fdca+0x2fd>
  4109fc:	cmp    cl,0xa
  4109ff:	je     4111a4 <__swc_fn_0a4ed24b_000146_43f4fdca+0x9e4>
  410a05:	cmp    cl,0xb
  410a08:	je     41188b <__swc_fn_0a4ed24b_000146_43f4fdca+0x10cb>
  410a0e:	cmp    cl,0xc
  410a11:	je     410ab1 <__swc_fn_0a4ed24b_000146_43f4fdca+0x2f1>
  410a17:	cmp    cl,0xd
  410a1a:	je     411881 <__swc_fn_0a4ed24b_000146_43f4fdca+0x10c1>
  410a20:	jmp    4118ab <__swc_fn_0a4ed24b_000146_43f4fdca+0x10eb>
  410a25:	cmp    cl,0x1
  410a28:	je     410a48 <__swc_fn_0a4ed24b_000146_43f4fdca+0x288>
  410a2a:	cmp    cl,0x2
  410a2d:	je     410a56 <__swc_fn_0a4ed24b_000146_43f4fdca+0x296>
  410a2f:	cmp    cl,0x3
  410a32:	je     410a64 <__swc_fn_0a4ed24b_000146_43f4fdca+0x2a4>
  410a34:	cmp    cl,0x4
  410a37:	je     410a71 <__swc_fn_0a4ed24b_000146_43f4fdca+0x2b1>
  410a39:	cmp    cl,0x5
  410a3c:	je     410a7e <__swc_fn_0a4ed24b_000146_43f4fdca+0x2be>
  410a3e:	cmp    cl,0x6
  410a41:	je     410a8b <__swc_fn_0a4ed24b_000146_43f4fdca+0x2cb>
  410a43:	jmp    4118ab <__swc_fn_0a4ed24b_000146_43f4fdca+0x10eb>
  410a48:	movsx  rcx,BYTE PTR [rdx]
  410a4c:	call   40d1e0 <__swc_fn_0a4ed24b_000145_863755b5>
  410a51:	jmp    4118c5 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1105>
  410a56:	movsx  rcx,WORD PTR [rdx]
  410a5a:	call   40d1e0 <__swc_fn_0a4ed24b_000145_863755b5>
  410a5f:	jmp    4118c5 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1105>
  410a64:	movsxd rcx,DWORD PTR [rdx]
  410a67:	call   40d1e0 <__swc_fn_0a4ed24b_000145_863755b5>
  410a6c:	jmp    4118c5 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1105>
  410a71:	mov    rcx,QWORD PTR [rdx]
  410a74:	call   40d1e0 <__swc_fn_0a4ed24b_000145_863755b5>
  410a79:	jmp    4118c5 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1105>
  410a7e:	movzx  ecx,BYTE PTR [rdx]
  410a81:	call   409cd0 <__swc_fn_0a4ed24b_000144_72996a5b>
  410a86:	jmp    4118c5 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1105>
  410a8b:	movzx  ecx,WORD PTR [rdx]
  410a8e:	call   409cd0 <__swc_fn_0a4ed24b_000144_72996a5b>
  410a93:	jmp    4118c5 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1105>
  410a98:	mov    ecx,DWORD PTR [rdx]
  410a9a:	call   409cd0 <__swc_fn_0a4ed24b_000144_72996a5b>
  410a9f:	jmp    4118c5 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1105>
  410aa4:	mov    rcx,QWORD PTR [rdx]
  410aa7:	call   409cd0 <__swc_fn_0a4ed24b_000144_72996a5b>
  410aac:	jmp    4118c5 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1105>
  410ab1:	mov    ecx,DWORD PTR [rdx]
  410ab3:	call   409cd0 <__swc_fn_0a4ed24b_000144_72996a5b>
  410ab8:	jmp    4118c5 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1105>
  410abd:	lea    rcx,[rsp+0xa8]
  410ac5:	vxorps xmm0,xmm0,xmm0
  410ac9:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  410ad2:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  410adb:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  410ae4:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  410aed:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  410af6:	vmovups XMMWORD PTR [rsp+0xf8],xmm0
  410aff:	mov    DWORD PTR [rsp+0x108],0x0
  410b0a:	vxorpd xmm0,xmm0,xmm0
  410b0e:	vmovss xmm1,DWORD PTR [rdx]
  410b12:	vcvtss2sd xmm0,xmm0,xmm1
  410b16:	vmovsd xmm1,xmm1,xmm0
  410b1a:	vcomisd xmm0,xmm0
  410b1e:	setne  dl
  410b21:	movzx  edx,dl
  410b24:	setp   r8b
  410b28:	movzx  r8d,r8b
  410b2c:	or     edx,r8d
  410b2f:	test   dl,dl
  410b31:	je     410b3e <__swc_fn_0a4ed24b_000146_43f4fdca+0x37e>
  410b33:	mov    DWORD PTR [rcx],0x6e616e
  410b39:	jmp    411138 <__swc_fn_0a4ed24b_000146_43f4fdca+0x978>
  410b3e:	vcomisd xmm1,xmm6
  410b42:	ja     410b4a <__swc_fn_0a4ed24b_000146_43f4fdca+0x38a>
  410b44:	vcomisd xmm7,xmm1
  410b48:	jbe    410b6e <__swc_fn_0a4ed24b_000146_43f4fdca+0x3ae>
  410b4a:	vxorpd xmm0,xmm0,xmm0
  410b4e:	vcomisd xmm0,xmm1
  410b52:	jbe    410b63 <__swc_fn_0a4ed24b_000146_43f4fdca+0x3a3>
  410b54:	mov    DWORD PTR [rcx],0x666e692d
  410b5a:	mov    BYTE PTR [rcx+0x4],0x0
  410b5e:	jmp    411138 <__swc_fn_0a4ed24b_000146_43f4fdca+0x978>
  410b63:	mov    DWORD PTR [rcx],0x666e69
  410b69:	jmp    411138 <__swc_fn_0a4ed24b_000146_43f4fdca+0x978>
  410b6e:	vcomisd xmm1,xmm8
  410b73:	jae    410b7f <__swc_fn_0a4ed24b_000146_43f4fdca+0x3bf>
  410b75:	vcomisd xmm9,xmm1
  410b79:	jbe    410efe <__swc_fn_0a4ed24b_000146_43f4fdca+0x73e>
  410b7f:	vmovups xmm0,xmm1
  410b83:	vxorpd xmm2,xmm2,xmm2
  410b87:	vcomisd xmm2,xmm1
  410b8b:	jbe    410b9b <__swc_fn_0a4ed24b_000146_43f4fdca+0x3db>
  410b8d:	vmovsd xmm1,xmm1,xmm0
  410b91:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x29b7]        # 413550 <__swc_rdata_base_0a4ed24b+0x440>
  410b99:	jmp    410b9f <__swc_fn_0a4ed24b_000146_43f4fdca+0x3df>
  410b9b:	vmovsd xmm1,xmm1,xmm0
  410b9f:	xor    r8d,r8d
  410ba2:	vcomisd xmm1,xmm15
  410ba7:	jb     410bd0 <__swc_fn_0a4ed24b_000146_43f4fdca+0x410>
  410ba9:	cs nop WORD PTR [rax+rax*1+0x0]
  410bb3:	cs nop WORD PTR [rax+rax*1+0x0]
  410bbd:	nop    DWORD PTR [rax]
  410bc0:	vdivsd xmm1,xmm1,xmm15
  410bc5:	add    r8,0x1
  410bc9:	vcomisd xmm1,xmm15
  410bce:	jae    410bc0 <__swc_fn_0a4ed24b_000146_43f4fdca+0x400>
  410bd0:	mov    r9,rcx
  410bd3:	vxorpd xmm2,xmm2,xmm2
  410bd7:	vcomisd xmm2,xmm0
  410bdb:	jbe    410be4 <__swc_fn_0a4ed24b_000146_43f4fdca+0x424>
  410bdd:	mov    BYTE PTR [rcx],0x2d
  410be0:	lea    r9,[rcx+0x1]
  410be4:	vcvttsd2si rdx,xmm1
  410be9:	mov    r10b,dl
  410bec:	add    r10b,0x30
  410bf0:	mov    BYTE PTR [r9],r10b
  410bf3:	vxorpd xmm0,xmm0,xmm0
  410bf7:	movzx  edx,dl
  410bfa:	vcvtsi2sd xmm0,xmm0,rdx
  410bff:	vsubsd xmm0,xmm1,xmm0
  410c03:	vmulsd xmm1,xmm0,xmm15
  410c08:	mov    BYTE PTR [r9+0x1],0x2e
  410c0d:	vcvttsd2si rdx,xmm1
  410c12:	mov    r10b,dl
  410c15:	add    r10b,0x30
  410c19:	mov    BYTE PTR [r9+0x2],r10b
  410c1d:	vxorpd xmm0,xmm0,xmm0
  410c21:	movzx  edx,dl
  410c24:	vcvtsi2sd xmm0,xmm0,rdx
  410c29:	vsubsd xmm0,xmm1,xmm0
  410c2d:	vmulsd xmm1,xmm0,xmm15
  410c32:	vcvttsd2si rdx,xmm1
  410c37:	mov    r10b,dl
  410c3a:	add    r10b,0x30
  410c3e:	mov    BYTE PTR [r9+0x3],r10b
  410c42:	vxorpd xmm0,xmm0,xmm0
  410c46:	movzx  edx,dl
  410c49:	vcvtsi2sd xmm0,xmm0,rdx
  410c4e:	vsubsd xmm0,xmm1,xmm0
  410c52:	vmulsd xmm1,xmm0,xmm15
  410c57:	vcvttsd2si rdx,xmm1
  410c5c:	mov    r10b,dl
  410c5f:	add    r10b,0x30
  410c63:	mov    BYTE PTR [r9+0x4],r10b
  410c67:	vxorpd xmm0,xmm0,xmm0
  410c6b:	movzx  edx,dl
  410c6e:	vcvtsi2sd xmm0,xmm0,rdx
  410c73:	vsubsd xmm0,xmm1,xmm0
  410c77:	vmulsd xmm1,xmm0,xmm15
  410c7c:	vcvttsd2si rdx,xmm1
  410c81:	mov    r10b,dl
  410c84:	add    r10b,0x30
  410c88:	mov    BYTE PTR [r9+0x5],r10b
  410c8c:	vxorpd xmm0,xmm0,xmm0
  410c90:	movzx  edx,dl
  410c93:	vcvtsi2sd xmm0,xmm0,rdx
  410c98:	vsubsd xmm0,xmm1,xmm0
  410c9c:	vmulsd xmm1,xmm0,xmm15
  410ca1:	vcvttsd2si rdx,xmm1
  410ca6:	mov    r10b,dl
  410ca9:	add    r10b,0x30
  410cad:	mov    BYTE PTR [r9+0x6],r10b
  410cb1:	vxorpd xmm0,xmm0,xmm0
  410cb5:	movzx  edx,dl
  410cb8:	vcvtsi2sd xmm0,xmm0,rdx
  410cbd:	vsubsd xmm0,xmm1,xmm0
  410cc1:	vmulsd xmm1,xmm0,xmm15
  410cc6:	vcvttsd2si rdx,xmm1
  410ccb:	mov    r10b,dl
  410cce:	add    r10b,0x30
  410cd2:	mov    BYTE PTR [r9+0x7],r10b
  410cd6:	vxorpd xmm0,xmm0,xmm0
  410cda:	movzx  edx,dl
  410cdd:	vcvtsi2sd xmm0,xmm0,rdx
  410ce2:	vsubsd xmm0,xmm1,xmm0
  410ce6:	vmulsd xmm1,xmm0,xmm15
  410ceb:	vcvttsd2si rdx,xmm1
  410cf0:	mov    r10b,dl
  410cf3:	add    r10b,0x30
  410cf7:	mov    BYTE PTR [r9+0x8],r10b
  410cfb:	vxorpd xmm0,xmm0,xmm0
  410cff:	movzx  edx,dl
  410d02:	vcvtsi2sd xmm0,xmm0,rdx
  410d07:	vsubsd xmm0,xmm1,xmm0
  410d0b:	vmulsd xmm1,xmm0,xmm15
  410d10:	vcvttsd2si rdx,xmm1
  410d15:	mov    r10b,dl
  410d18:	add    r10b,0x30
  410d1c:	mov    BYTE PTR [r9+0x9],r10b
  410d20:	vxorpd xmm0,xmm0,xmm0
  410d24:	movzx  edx,dl
  410d27:	vcvtsi2sd xmm0,xmm0,rdx
  410d2c:	vsubsd xmm0,xmm1,xmm0
  410d30:	vmulsd xmm1,xmm0,xmm15
  410d35:	vcvttsd2si rdx,xmm1
  410d3a:	mov    r10b,dl
  410d3d:	add    r10b,0x30
  410d41:	mov    BYTE PTR [r9+0xa],r10b
  410d45:	vxorpd xmm0,xmm0,xmm0
  410d49:	movzx  edx,dl
  410d4c:	vcvtsi2sd xmm0,xmm0,rdx
  410d51:	vsubsd xmm0,xmm1,xmm0
  410d55:	vmulsd xmm1,xmm0,xmm15
  410d5a:	vcvttsd2si rdx,xmm1
  410d5f:	mov    r10b,dl
  410d62:	add    r10b,0x30
  410d66:	mov    BYTE PTR [r9+0xb],r10b
  410d6a:	lea    r10,[r9+0x4]
  410d6e:	vxorpd xmm0,xmm0,xmm0
  410d72:	movzx  edx,dl
  410d75:	vcvtsi2sd xmm0,xmm0,rdx
  410d7a:	vsubsd xmm0,xmm1,xmm0
  410d7e:	vmulsd xmm1,xmm0,xmm15
  410d83:	vcvttsd2si rdx,xmm1
  410d88:	mov    r11b,dl
  410d8b:	add    r11b,0x30
  410d8f:	mov    BYTE PTR [r9+0xc],r11b
  410d93:	vxorpd xmm0,xmm0,xmm0
  410d97:	movzx  edx,dl
  410d9a:	vcvtsi2sd xmm0,xmm0,rdx
  410d9f:	vsubsd xmm0,xmm1,xmm0
  410da3:	vmulsd xmm1,xmm0,xmm15
  410da8:	vcvttsd2si rdx,xmm1
  410dad:	mov    r11b,dl
  410db0:	add    r11b,0x30
  410db4:	mov    BYTE PTR [r9+0xd],r11b
  410db8:	lea    r10,[r10+0x2]
  410dbc:	vxorpd xmm0,xmm0,xmm0
  410dc0:	movzx  edx,dl
  410dc3:	vcvtsi2sd xmm0,xmm0,rdx
  410dc8:	vsubsd xmm0,xmm1,xmm0
  410dcc:	vmulsd xmm1,xmm0,xmm15
  410dd1:	vcvttsd2si rdx,xmm1
  410dd6:	mov    r11b,dl
  410dd9:	add    r11b,0x30
  410ddd:	mov    BYTE PTR [r9+0xe],r11b
  410de1:	vxorpd xmm0,xmm0,xmm0
  410de5:	movzx  edx,dl
  410de8:	vcvtsi2sd xmm0,xmm0,rdx
  410ded:	vsubsd xmm0,xmm1,xmm0
  410df1:	vmulsd xmm1,xmm0,xmm15
  410df6:	vcvttsd2si rdx,xmm1
  410dfb:	mov    r11b,dl
  410dfe:	add    r11b,0x30
  410e02:	mov    BYTE PTR [r9+0xf],r11b
  410e06:	lea    r10,[r10+0x2]
  410e0a:	lea    r10,[r10+0x2]
  410e0e:	lea    r10,[r10+0x2]
  410e12:	lea    r10,[r10+0x2]
  410e16:	lea    r10,[r10+0x2]
  410e1a:	vxorpd xmm0,xmm0,xmm0
  410e1e:	movzx  edx,dl
  410e21:	vcvtsi2sd xmm0,xmm0,rdx
  410e26:	vsubsd xmm0,xmm1,xmm0
  410e2a:	vmulsd xmm1,xmm0,xmm15
  410e2f:	vcvttsd2si rdx,xmm1
  410e34:	mov    r11b,dl
  410e37:	add    r11b,0x30
  410e3b:	mov    BYTE PTR [r9+0x10],r11b
  410e3f:	vxorpd xmm0,xmm0,xmm0
  410e43:	movzx  edx,dl
  410e46:	vcvtsi2sd xmm0,xmm0,rdx
  410e4b:	vsubsd xmm0,xmm1,xmm0
  410e4f:	vmulsd xmm1,xmm0,xmm15
  410e54:	vcvttsd2si rdx,xmm1
  410e59:	add    dl,0x30
  410e5c:	mov    BYTE PTR [r9+0x11],dl
  410e60:	mov    BYTE PTR [r10+0x2],0x65
  410e65:	lea    r9,[r10+0x3]
  410e69:	test   r8,r8
  410e6c:	jl     410e75 <__swc_fn_0a4ed24b_000146_43f4fdca+0x6b5>
  410e6e:	mov    BYTE PTR [r9],0x2b
  410e72:	inc    r9
  410e75:	mov    r10,r9
  410e78:	mov    rdx,r8
  410e7b:	nop    DWORD PTR [rax+rax*1+0x0]
  410e80:	mov    r11,rdx
  410e83:	movabs rdx,0x6666666666666667
  410e8d:	mov    rax,r11
  410e90:	imul   rdx
  410e93:	sar    rdx,0x2
  410e97:	mov    r12,rdx
  410e9a:	shr    rdx,0x3f
  410e9e:	add    r12,rdx
  410ea1:	mov    rdx,r12
  410ea4:	imul   r13,r12,0xa
  410ea8:	sub    r11,r13
  410eab:	mov    r13,QWORD PTR [rip+0x268e]        # 413540 <__swc_rdata_base_0a4ed24b+0x430>
  410eb2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410eb7:	mov    BYTE PTR [r10],r11b
  410eba:	lea    r11,[r10+0x1]
  410ebe:	mov    r10,r11
  410ec1:	test   r12,r12
  410ec4:	jne    410e80 <__swc_fn_0a4ed24b_000146_43f4fdca+0x6c0>
  410ec6:	test   r8,r8
  410ec9:	jge    410ed3 <__swc_fn_0a4ed24b_000146_43f4fdca+0x713>
  410ecb:	mov    BYTE PTR [r11],0x2d
  410ecf:	lea    r10,[r11+0x1]
  410ed3:	mov    BYTE PTR [r10],0x0
  410ed7:	sub    r10,0x1
  410edb:	nop    DWORD PTR [rax+rax*1+0x0]
  410ee0:	cmp    r9,r10
  410ee3:	jae    411138 <__swc_fn_0a4ed24b_000146_43f4fdca+0x978>
  410ee9:	mov    al,BYTE PTR [r10]
  410eec:	mov    dl,BYTE PTR [r9]
  410eef:	mov    BYTE PTR [r10],dl
  410ef2:	sub    r10,0x1
  410ef6:	mov    BYTE PTR [r9],al
  410ef9:	inc    r9
  410efc:	jmp    410ee0 <__swc_fn_0a4ed24b_000146_43f4fdca+0x720>
  410efe:	vcvttsd2si rdx,xmm1
  410f03:	mov    r8,rdx
  410f06:	vxorpd xmm0,xmm0,xmm0
  410f0a:	vcvtsi2sd xmm0,xmm0,rdx
  410f0f:	vsubsd xmm0,xmm1,xmm0
  410f13:	mov    r9d,0x8
  410f19:	vxorpd xmm2,xmm2,xmm2
  410f1d:	vcomisd xmm2,xmm0
  410f21:	jbe    410f2b <__swc_fn_0a4ed24b_000146_43f4fdca+0x76b>
  410f23:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x2625]        # 413550 <__swc_rdata_base_0a4ed24b+0x440>
  410f2b:	test   r9d,r9d
  410f2e:	je     410f3a <__swc_fn_0a4ed24b_000146_43f4fdca+0x77a>
  410f30:	vmulsd xmm0,xmm0,xmm14
  410f35:	dec    r9d
  410f38:	jne    410f30 <__swc_fn_0a4ed24b_000146_43f4fdca+0x770>
  410f3a:	vcvttsd2si r9,xmm0
  410f3f:	mov    r10,r9
  410f42:	vxorpd xmm2,xmm2,xmm2
  410f46:	vcvtsi2sd xmm2,xmm2,r9
  410f4b:	vsubsd xmm0,xmm0,xmm2
  410f4f:	vcomisd xmm0,xmm10
  410f54:	lea    r9,[r9+0x1]
  410f58:	cmova  r10,r9
  410f5c:	cmp    r10,0x5f5e100
  410f63:	jne    410f7c <__swc_fn_0a4ed24b_000146_43f4fdca+0x7bc>
  410f65:	lea    r8,[rdx-0x1]
  410f69:	vxorpd xmm0,xmm0,xmm0
  410f6d:	vcomisd xmm0,xmm1
  410f71:	lea    rdx,[rdx+0x1]
  410f75:	cmovbe r8,rdx
  410f79:	xor    r10d,r10d
  410f7c:	mov    r9,rcx
  410f7f:	test   r8,r8
  410f82:	jne    410fa2 <__swc_fn_0a4ed24b_000146_43f4fdca+0x7e2>
  410f84:	vxorpd xmm0,xmm0,xmm0
  410f88:	vcomisd xmm0,xmm1
  410f8c:	jbe    410f95 <__swc_fn_0a4ed24b_000146_43f4fdca+0x7d5>
  410f8e:	mov    BYTE PTR [rcx],0x2d
  410f91:	lea    r9,[rcx+0x1]
  410f95:	mov    BYTE PTR [r9],0x30
  410f99:	add    r9,0x1
  410f9d:	jmp    41103b <__swc_fn_0a4ed24b_000146_43f4fdca+0x87b>
  410fa2:	mov    r9,rcx
  410fa5:	mov    rdx,r8
  410fa8:	nop    DWORD PTR [rax+rax*1+0x0]
  410fb0:	mov    r11,rdx
  410fb3:	movabs rdx,0x6666666666666667
  410fbd:	mov    r15,rax
  410fc0:	mov    rax,r11
  410fc3:	imul   rdx
  410fc6:	mov    r12,rdx
  410fc9:	mov    rax,r15
  410fcc:	sar    r12,0x2
  410fd0:	mov    rdx,r12
  410fd3:	shr    rdx,0x3f
  410fd7:	add    r12,rdx
  410fda:	mov    rdx,r12
  410fdd:	imul   r13,r12,0xa
  410fe1:	sub    r11,r13
  410fe4:	mov    r13,QWORD PTR [rip+0x2555]        # 413540 <__swc_rdata_base_0a4ed24b+0x430>
  410feb:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410ff0:	mov    BYTE PTR [r9],r11b
  410ff3:	lea    r11,[r9+0x1]
  410ff7:	mov    r9,r11
  410ffa:	test   r12,r12
  410ffd:	jne    410fb0 <__swc_fn_0a4ed24b_000146_43f4fdca+0x7f0>
  410fff:	test   r8,r8
  411002:	jge    41100c <__swc_fn_0a4ed24b_000146_43f4fdca+0x84c>
  411004:	mov    BYTE PTR [r11],0x2d
  411008:	lea    r9,[r11+0x1]
  41100c:	mov    rdx,r9
  41100f:	mov    BYTE PTR [r9],0x0
  411013:	sub    r9,0x1
  411017:	mov    r8,rcx
  41101a:	cmp    r8,r9
  41101d:	jae    411038 <__swc_fn_0a4ed24b_000146_43f4fdca+0x878>
  41101f:	nop
  411020:	mov    r11b,BYTE PTR [r9]
  411023:	mov    r12b,BYTE PTR [r8]
  411026:	mov    BYTE PTR [r9],r12b
  411029:	sub    r9,0x1
  41102d:	mov    BYTE PTR [r8],r11b
  411030:	inc    r8
  411033:	cmp    r8,r9
  411036:	jb     411020 <__swc_fn_0a4ed24b_000146_43f4fdca+0x860>
  411038:	mov    r9,rdx
  41103b:	mov    BYTE PTR [r9],0x2e
  41103f:	add    r9,0x1
  411043:	xor    r8d,r8d
  411046:	test   r10,r10
  411049:	je     41108f <__swc_fn_0a4ed24b_000146_43f4fdca+0x8cf>
  41104b:	mov    r11d,0x989680
  411051:	cmp    r10,r11
  411054:	jge    41108f <__swc_fn_0a4ed24b_000146_43f4fdca+0x8cf>
  411056:	cs nop WORD PTR [rax+rax*1+0x0]
  411060:	inc    r8d
  411063:	movabs rdx,0x6666666666666667
  41106d:	mov    r15,rax
  411070:	mov    rax,r11
  411073:	imul   rdx
  411076:	mov    r11,rdx
  411079:	mov    rax,r15
  41107c:	sar    r11,0x2
  411080:	mov    rdx,r11
  411083:	shr    rdx,0x3f
  411087:	add    r11,rdx
  41108a:	cmp    r10,r11
  41108d:	jl     411060 <__swc_fn_0a4ed24b_000146_43f4fdca+0x8a0>
  41108f:	test   r8d,r8d
  411092:	je     4110ad <__swc_fn_0a4ed24b_000146_43f4fdca+0x8ed>
  411094:	cs nop WORD PTR [rax+rax*1+0x0]
  41109e:	xchg   ax,ax
  4110a0:	mov    BYTE PTR [r9],0x30
  4110a4:	add    r9,0x1
  4110a8:	dec    r8d
  4110ab:	jne    4110a0 <__swc_fn_0a4ed24b_000146_43f4fdca+0x8e0>
  4110ad:	mov    r8,r9
  4110b0:	mov    rdx,r10
  4110b3:	cs nop WORD PTR [rax+rax*1+0x0]
  4110bd:	nop    DWORD PTR [rax]
  4110c0:	mov    r11,rdx
  4110c3:	movabs rdx,0x6666666666666667
  4110cd:	mov    rax,r11
  4110d0:	imul   rdx
  4110d3:	sar    rdx,0x2
  4110d7:	mov    r12,rdx
  4110da:	shr    rdx,0x3f
  4110de:	add    r12,rdx
  4110e1:	mov    rdx,r12
  4110e4:	imul   r13,r12,0xa
  4110e8:	sub    r11,r13
  4110eb:	mov    r13,QWORD PTR [rip+0x244e]        # 413540 <__swc_rdata_base_0a4ed24b+0x430>
  4110f2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4110f7:	mov    BYTE PTR [r8],r11b
  4110fa:	lea    r11,[r8+0x1]
  4110fe:	mov    r8,r11
  411101:	test   r12,r12
  411104:	jne    4110c0 <__swc_fn_0a4ed24b_000146_43f4fdca+0x900>
  411106:	test   r10,r10
  411109:	jge    411113 <__swc_fn_0a4ed24b_000146_43f4fdca+0x953>
  41110b:	mov    BYTE PTR [r11],0x2d
  41110f:	lea    r8,[r11+0x1]
  411113:	mov    BYTE PTR [r8],0x0
  411117:	sub    r8,0x1
  41111b:	cmp    r9,r8
  41111e:	jae    411138 <__swc_fn_0a4ed24b_000146_43f4fdca+0x978>
  411120:	mov    al,BYTE PTR [r8]
  411123:	mov    dl,BYTE PTR [r9]
  411126:	mov    BYTE PTR [r8],dl
  411129:	sub    r8,0x1
  41112d:	mov    BYTE PTR [r9],al
  411130:	inc    r9
  411133:	cmp    r9,r8
  411136:	jb     411120 <__swc_fn_0a4ed24b_000146_43f4fdca+0x960>
  411138:	xor    eax,eax
  41113a:	test   rcx,rcx
  41113d:	je     411170 <__swc_fn_0a4ed24b_000146_43f4fdca+0x9b0>
  41113f:	mov    rdx,rcx
  411142:	mov    r8b,BYTE PTR [rdx]
  411145:	test   r8b,r8b
  411148:	je     411170 <__swc_fn_0a4ed24b_000146_43f4fdca+0x9b0>
  41114a:	cs nop WORD PTR [rax+rax*1+0x0]
  411154:	cs nop WORD PTR [rax+rax*1+0x0]
  41115e:	xchg   ax,ax
  411160:	add    rdx,0x1
  411164:	add    rax,0x1
  411168:	mov    r8b,BYTE PTR [rdx]
  41116b:	test   r8b,r8b
  41116e:	jne    411160 <__swc_fn_0a4ed24b_000146_43f4fdca+0x9a0>
  411170:	mov    QWORD PTR [rsp+0x240],rcx
  411178:	mov    QWORD PTR [rsp+0x248],rax
  411180:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  411189:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  411192:	lea    rcx,[rsp+0x250]
  41119a:	call   40ff40 <__swc_fn_0a4ed24b_000116_035d76a1>
  41119f:	jmp    4118c5 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1105>
  4111a4:	lea    rcx,[rsp+0x260]
  4111ac:	vxorps xmm0,xmm0,xmm0
  4111b0:	vmovups XMMWORD PTR [rsp+0x260],xmm0
  4111b9:	vmovups XMMWORD PTR [rsp+0x270],xmm0
  4111c2:	vmovups XMMWORD PTR [rsp+0x280],xmm0
  4111cb:	vmovups XMMWORD PTR [rsp+0x290],xmm0
  4111d4:	vmovups XMMWORD PTR [rsp+0x2a0],xmm0
  4111dd:	vmovups XMMWORD PTR [rsp+0x2b0],xmm0
  4111e6:	mov    DWORD PTR [rsp+0x2c0],0x0
  4111f1:	vmovsd xmm0,QWORD PTR [rdx]
  4111f5:	vcomisd xmm0,xmm0
  4111f9:	setne  dl
  4111fc:	movzx  edx,dl
  4111ff:	setp   r8b
  411203:	movzx  r8d,r8b
  411207:	or     edx,r8d
  41120a:	test   dl,dl
  41120c:	je     411219 <__swc_fn_0a4ed24b_000146_43f4fdca+0xa59>
  41120e:	mov    DWORD PTR [rcx],0x6e616e
  411214:	jmp    411828 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1068>
  411219:	vcomisd xmm0,xmm11
  41121e:	ja     41122f <__swc_fn_0a4ed24b_000146_43f4fdca+0xa6f>
  411220:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  411229:	vcomisd xmm6,xmm0
  41122d:	jbe    411253 <__swc_fn_0a4ed24b_000146_43f4fdca+0xa93>
  41122f:	vxorpd xmm1,xmm1,xmm1
  411233:	vcomisd xmm1,xmm0
  411237:	jbe    411248 <__swc_fn_0a4ed24b_000146_43f4fdca+0xa88>
  411239:	mov    DWORD PTR [rcx],0x666e692d
  41123f:	mov    BYTE PTR [rcx+0x4],0x0
  411243:	jmp    411828 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1068>
  411248:	mov    DWORD PTR [rcx],0x666e69
  41124e:	jmp    411828 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1068>
  411253:	vcomisd xmm0,xmm13
  411258:	jae    411264 <__swc_fn_0a4ed24b_000146_43f4fdca+0xaa4>
  41125a:	vcomisd xmm12,xmm0
  41125e:	jbe    4115ce <__swc_fn_0a4ed24b_000146_43f4fdca+0xe0e>
  411264:	vmovups xmm1,xmm0
  411268:	vxorpd xmm2,xmm2,xmm2
  41126c:	vcomisd xmm2,xmm0
  411270:	jbe    411280 <__swc_fn_0a4ed24b_000146_43f4fdca+0xac0>
  411272:	vmovsd xmm0,xmm0,xmm1
  411276:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x22d2]        # 413550 <__swc_rdata_base_0a4ed24b+0x440>
  41127e:	jmp    411284 <__swc_fn_0a4ed24b_000146_43f4fdca+0xac4>
  411280:	vmovsd xmm0,xmm0,xmm1
  411284:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  41128d:	xor    r8d,r8d
  411290:	vcomisd xmm0,xmm6
  411294:	jb     4112ae <__swc_fn_0a4ed24b_000146_43f4fdca+0xaee>
  411296:	cs nop WORD PTR [rax+rax*1+0x0]
  4112a0:	vdivsd xmm0,xmm0,xmm6
  4112a4:	add    r8,0x1
  4112a8:	vcomisd xmm0,xmm6
  4112ac:	jae    4112a0 <__swc_fn_0a4ed24b_000146_43f4fdca+0xae0>
  4112ae:	mov    r9,rcx
  4112b1:	vxorpd xmm2,xmm2,xmm2
  4112b5:	vcomisd xmm2,xmm1
  4112b9:	jbe    4112c2 <__swc_fn_0a4ed24b_000146_43f4fdca+0xb02>
  4112bb:	mov    BYTE PTR [rcx],0x2d
  4112be:	lea    r9,[rcx+0x1]
  4112c2:	vcvttsd2si rdx,xmm0
  4112c7:	mov    r10b,dl
  4112ca:	add    r10b,0x30
  4112ce:	mov    BYTE PTR [r9],r10b
  4112d1:	vxorpd xmm1,xmm1,xmm1
  4112d5:	movzx  edx,dl
  4112d8:	vcvtsi2sd xmm1,xmm1,rdx
  4112dd:	vsubsd xmm0,xmm0,xmm1
  4112e1:	vmulsd xmm0,xmm0,xmm6
  4112e5:	mov    BYTE PTR [r9+0x1],0x2e
  4112ea:	vcvttsd2si rdx,xmm0
  4112ef:	mov    r10b,dl
  4112f2:	add    r10b,0x30
  4112f6:	mov    BYTE PTR [r9+0x2],r10b
  4112fa:	vxorpd xmm1,xmm1,xmm1
  4112fe:	movzx  edx,dl
  411301:	vcvtsi2sd xmm1,xmm1,rdx
  411306:	vsubsd xmm0,xmm0,xmm1
  41130a:	vmulsd xmm0,xmm0,xmm6
  41130e:	vcvttsd2si rdx,xmm0
  411313:	mov    r10b,dl
  411316:	add    r10b,0x30
  41131a:	mov    BYTE PTR [r9+0x3],r10b
  41131e:	vxorpd xmm1,xmm1,xmm1
  411322:	movzx  edx,dl
  411325:	vcvtsi2sd xmm1,xmm1,rdx
  41132a:	vsubsd xmm0,xmm0,xmm1
  41132e:	vmulsd xmm0,xmm0,xmm6
  411332:	vcvttsd2si rdx,xmm0
  411337:	mov    r10b,dl
  41133a:	add    r10b,0x30
  41133e:	mov    BYTE PTR [r9+0x4],r10b
  411342:	vxorpd xmm1,xmm1,xmm1
  411346:	movzx  edx,dl
  411349:	vcvtsi2sd xmm1,xmm1,rdx
  41134e:	vsubsd xmm0,xmm0,xmm1
  411352:	vmulsd xmm0,xmm0,xmm6
  411356:	vcvttsd2si rdx,xmm0
  41135b:	mov    r10b,dl
  41135e:	add    r10b,0x30
  411362:	mov    BYTE PTR [r9+0x5],r10b
  411366:	vxorpd xmm1,xmm1,xmm1
  41136a:	movzx  edx,dl
  41136d:	vcvtsi2sd xmm1,xmm1,rdx
  411372:	vsubsd xmm0,xmm0,xmm1
  411376:	vmulsd xmm0,xmm0,xmm6
  41137a:	vcvttsd2si rdx,xmm0
  41137f:	mov    r10b,dl
  411382:	add    r10b,0x30
  411386:	mov    BYTE PTR [r9+0x6],r10b
  41138a:	vxorpd xmm1,xmm1,xmm1
  41138e:	movzx  edx,dl
  411391:	vcvtsi2sd xmm1,xmm1,rdx
  411396:	vsubsd xmm0,xmm0,xmm1
  41139a:	vmulsd xmm0,xmm0,xmm6
  41139e:	vcvttsd2si rdx,xmm0
  4113a3:	mov    r10b,dl
  4113a6:	add    r10b,0x30
  4113aa:	mov    BYTE PTR [r9+0x7],r10b
  4113ae:	vxorpd xmm1,xmm1,xmm1
  4113b2:	movzx  edx,dl
  4113b5:	vcvtsi2sd xmm1,xmm1,rdx
  4113ba:	vsubsd xmm0,xmm0,xmm1
  4113be:	vmulsd xmm0,xmm0,xmm6
  4113c2:	vcvttsd2si rdx,xmm0
  4113c7:	mov    r10b,dl
  4113ca:	add    r10b,0x30
  4113ce:	mov    BYTE PTR [r9+0x8],r10b
  4113d2:	vxorpd xmm1,xmm1,xmm1
  4113d6:	movzx  edx,dl
  4113d9:	vcvtsi2sd xmm1,xmm1,rdx
  4113de:	vsubsd xmm0,xmm0,xmm1
  4113e2:	vmulsd xmm0,xmm0,xmm6
  4113e6:	vcvttsd2si rdx,xmm0
  4113eb:	mov    r10b,dl
  4113ee:	add    r10b,0x30
  4113f2:	mov    BYTE PTR [r9+0x9],r10b
  4113f6:	vxorpd xmm1,xmm1,xmm1
  4113fa:	movzx  edx,dl
  4113fd:	vcvtsi2sd xmm1,xmm1,rdx
  411402:	vsubsd xmm0,xmm0,xmm1
  411406:	vmulsd xmm0,xmm0,xmm6
  41140a:	vcvttsd2si rdx,xmm0
  41140f:	mov    r10b,dl
  411412:	add    r10b,0x30
  411416:	mov    BYTE PTR [r9+0xa],r10b
  41141a:	vxorpd xmm1,xmm1,xmm1
  41141e:	movzx  edx,dl
  411421:	vcvtsi2sd xmm1,xmm1,rdx
  411426:	vsubsd xmm0,xmm0,xmm1
  41142a:	vmulsd xmm0,xmm0,xmm6
  41142e:	vcvttsd2si rdx,xmm0
  411433:	mov    r10b,dl
  411436:	add    r10b,0x30
  41143a:	mov    BYTE PTR [r9+0xb],r10b
  41143e:	lea    r10,[r9+0x4]
  411442:	vxorpd xmm1,xmm1,xmm1
  411446:	movzx  edx,dl
  411449:	vcvtsi2sd xmm1,xmm1,rdx
  41144e:	vsubsd xmm0,xmm0,xmm1
  411452:	vmulsd xmm0,xmm0,xmm6
  411456:	vcvttsd2si rdx,xmm0
  41145b:	mov    r11b,dl
  41145e:	add    r11b,0x30
  411462:	mov    BYTE PTR [r9+0xc],r11b
  411466:	vxorpd xmm1,xmm1,xmm1
  41146a:	movzx  edx,dl
  41146d:	vcvtsi2sd xmm1,xmm1,rdx
  411472:	vsubsd xmm0,xmm0,xmm1
  411476:	vmulsd xmm0,xmm0,xmm6
  41147a:	vcvttsd2si rdx,xmm0
  41147f:	mov    r11b,dl
  411482:	add    r11b,0x30
  411486:	mov    BYTE PTR [r9+0xd],r11b
  41148a:	lea    r10,[r10+0x2]
  41148e:	vxorpd xmm1,xmm1,xmm1
  411492:	movzx  edx,dl
  411495:	vcvtsi2sd xmm1,xmm1,rdx
  41149a:	vsubsd xmm0,xmm0,xmm1
  41149e:	vmulsd xmm0,xmm0,xmm6
  4114a2:	vcvttsd2si rdx,xmm0
  4114a7:	mov    r11b,dl
  4114aa:	add    r11b,0x30
  4114ae:	mov    BYTE PTR [r9+0xe],r11b
  4114b2:	vxorpd xmm1,xmm1,xmm1
  4114b6:	movzx  edx,dl
  4114b9:	vcvtsi2sd xmm1,xmm1,rdx
  4114be:	vsubsd xmm0,xmm0,xmm1
  4114c2:	vmulsd xmm0,xmm0,xmm6
  4114c6:	vcvttsd2si rdx,xmm0
  4114cb:	mov    r11b,dl
  4114ce:	add    r11b,0x30
  4114d2:	mov    BYTE PTR [r9+0xf],r11b
  4114d6:	lea    r10,[r10+0x2]
  4114da:	lea    r10,[r10+0x2]
  4114de:	lea    r10,[r10+0x2]
  4114e2:	lea    r10,[r10+0x2]
  4114e6:	lea    r10,[r10+0x2]
  4114ea:	vxorpd xmm1,xmm1,xmm1
  4114ee:	movzx  edx,dl
  4114f1:	vcvtsi2sd xmm1,xmm1,rdx
  4114f6:	vsubsd xmm0,xmm0,xmm1
  4114fa:	vmulsd xmm0,xmm0,xmm6
  4114fe:	vcvttsd2si rdx,xmm0
  411503:	mov    r11b,dl
  411506:	add    r11b,0x30
  41150a:	mov    BYTE PTR [r9+0x10],r11b
  41150e:	vxorpd xmm1,xmm1,xmm1
  411512:	movzx  edx,dl
  411515:	vcvtsi2sd xmm1,xmm1,rdx
  41151a:	vsubsd xmm0,xmm0,xmm1
  41151e:	vmulsd xmm0,xmm0,xmm6
  411522:	vcvttsd2si rdx,xmm0
  411527:	add    dl,0x30
  41152a:	mov    BYTE PTR [r9+0x11],dl
  41152e:	mov    BYTE PTR [r10+0x2],0x65
  411533:	lea    r9,[r10+0x3]
  411537:	test   r8,r8
  41153a:	jl     411543 <__swc_fn_0a4ed24b_000146_43f4fdca+0xd83>
  41153c:	mov    BYTE PTR [r9],0x2b
  411540:	inc    r9
  411543:	mov    r10,r9
  411546:	mov    rdx,r8
  411549:	nop    DWORD PTR [rax+0x0]
  411550:	mov    r11,rdx
  411553:	movabs rdx,0x6666666666666667
  41155d:	mov    rax,r11
  411560:	imul   rdx
  411563:	sar    rdx,0x2
  411567:	mov    r12,rdx
  41156a:	shr    rdx,0x3f
  41156e:	add    r12,rdx
  411571:	mov    rdx,r12
  411574:	imul   r13,r12,0xa
  411578:	sub    r11,r13
  41157b:	mov    r13,QWORD PTR [rip+0x1fbe]        # 413540 <__swc_rdata_base_0a4ed24b+0x430>
  411582:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411587:	mov    BYTE PTR [r10],r11b
  41158a:	lea    r11,[r10+0x1]
  41158e:	mov    r10,r11
  411591:	test   r12,r12
  411594:	jne    411550 <__swc_fn_0a4ed24b_000146_43f4fdca+0xd90>
  411596:	test   r8,r8
  411599:	jge    4115a3 <__swc_fn_0a4ed24b_000146_43f4fdca+0xde3>
  41159b:	mov    BYTE PTR [r11],0x2d
  41159f:	lea    r10,[r11+0x1]
  4115a3:	mov    BYTE PTR [r10],0x0
  4115a7:	sub    r10,0x1
  4115ab:	nop    DWORD PTR [rax+rax*1+0x0]
  4115b0:	cmp    r9,r10
  4115b3:	jae    411828 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1068>
  4115b9:	mov    al,BYTE PTR [r10]
  4115bc:	mov    dl,BYTE PTR [r9]
  4115bf:	mov    BYTE PTR [r10],dl
  4115c2:	sub    r10,0x1
  4115c6:	mov    BYTE PTR [r9],al
  4115c9:	inc    r9
  4115cc:	jmp    4115b0 <__swc_fn_0a4ed24b_000146_43f4fdca+0xdf0>
  4115ce:	vcvttsd2si rdx,xmm0
  4115d3:	mov    r8,rdx
  4115d6:	vxorpd xmm1,xmm1,xmm1
  4115da:	vcvtsi2sd xmm1,xmm1,rdx
  4115df:	vsubsd xmm1,xmm0,xmm1
  4115e3:	mov    r9d,0x8
  4115e9:	vxorpd xmm2,xmm2,xmm2
  4115ed:	vcomisd xmm2,xmm1
  4115f1:	ja     4115fe <__swc_fn_0a4ed24b_000146_43f4fdca+0xe3e>
  4115f3:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  4115fc:	jmp    41160f <__swc_fn_0a4ed24b_000146_43f4fdca+0xe4f>
  4115fe:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1f4a]        # 413550 <__swc_rdata_base_0a4ed24b+0x440>
  411606:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41160f:	test   r9d,r9d
  411612:	je     411629 <__swc_fn_0a4ed24b_000146_43f4fdca+0xe69>
  411614:	cs nop WORD PTR [rax+rax*1+0x0]
  41161e:	xchg   ax,ax
  411620:	vmulsd xmm1,xmm1,xmm6
  411624:	dec    r9d
  411627:	jne    411620 <__swc_fn_0a4ed24b_000146_43f4fdca+0xe60>
  411629:	vcvttsd2si r9,xmm1
  41162e:	mov    r10,r9
  411631:	vxorpd xmm2,xmm2,xmm2
  411635:	vcvtsi2sd xmm2,xmm2,r9
  41163a:	vsubsd xmm1,xmm1,xmm2
  41163e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  411647:	vcomisd xmm1,xmm6
  41164b:	lea    r9,[r9+0x1]
  41164f:	cmova  r10,r9
  411653:	cmp    r10,0x5f5e100
  41165a:	jne    411673 <__swc_fn_0a4ed24b_000146_43f4fdca+0xeb3>
  41165c:	lea    r8,[rdx-0x1]
  411660:	vxorpd xmm1,xmm1,xmm1
  411664:	vcomisd xmm1,xmm0
  411668:	lea    rdx,[rdx+0x1]
  41166c:	cmovbe r8,rdx
  411670:	xor    r10d,r10d
  411673:	mov    r9,rcx
  411676:	test   r8,r8
  411679:	jne    411699 <__swc_fn_0a4ed24b_000146_43f4fdca+0xed9>
  41167b:	vxorpd xmm1,xmm1,xmm1
  41167f:	vcomisd xmm1,xmm0
  411683:	jbe    41168c <__swc_fn_0a4ed24b_000146_43f4fdca+0xecc>
  411685:	mov    BYTE PTR [rcx],0x2d
  411688:	lea    r9,[rcx+0x1]
  41168c:	mov    BYTE PTR [r9],0x30
  411690:	add    r9,0x1
  411694:	jmp    41172b <__swc_fn_0a4ed24b_000146_43f4fdca+0xf6b>
  411699:	mov    r9,rcx
  41169c:	mov    rdx,r8
  41169f:	nop
  4116a0:	mov    r11,rdx
  4116a3:	movabs rdx,0x6666666666666667
  4116ad:	mov    r15,rax
  4116b0:	mov    rax,r11
  4116b3:	imul   rdx
  4116b6:	mov    r12,rdx
  4116b9:	mov    rax,r15
  4116bc:	sar    r12,0x2
  4116c0:	mov    rdx,r12
  4116c3:	shr    rdx,0x3f
  4116c7:	add    r12,rdx
  4116ca:	mov    rdx,r12
  4116cd:	imul   r13,r12,0xa
  4116d1:	sub    r11,r13
  4116d4:	mov    r13,QWORD PTR [rip+0x1e65]        # 413540 <__swc_rdata_base_0a4ed24b+0x430>
  4116db:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4116e0:	mov    BYTE PTR [r9],r11b
  4116e3:	lea    r11,[r9+0x1]
  4116e7:	mov    r9,r11
  4116ea:	test   r12,r12
  4116ed:	jne    4116a0 <__swc_fn_0a4ed24b_000146_43f4fdca+0xee0>
  4116ef:	test   r8,r8
  4116f2:	jge    4116fc <__swc_fn_0a4ed24b_000146_43f4fdca+0xf3c>
  4116f4:	mov    BYTE PTR [r11],0x2d
  4116f8:	lea    r9,[r11+0x1]
  4116fc:	mov    rdx,r9
  4116ff:	mov    BYTE PTR [r9],0x0
  411703:	sub    r9,0x1
  411707:	mov    r8,rcx
  41170a:	cmp    r8,r9
  41170d:	jae    411728 <__swc_fn_0a4ed24b_000146_43f4fdca+0xf68>
  41170f:	nop
  411710:	mov    r11b,BYTE PTR [r9]
  411713:	mov    r12b,BYTE PTR [r8]
  411716:	mov    BYTE PTR [r9],r12b
  411719:	sub    r9,0x1
  41171d:	mov    BYTE PTR [r8],r11b
  411720:	inc    r8
  411723:	cmp    r8,r9
  411726:	jb     411710 <__swc_fn_0a4ed24b_000146_43f4fdca+0xf50>
  411728:	mov    r9,rdx
  41172b:	mov    BYTE PTR [r9],0x2e
  41172f:	add    r9,0x1
  411733:	xor    r8d,r8d
  411736:	test   r10,r10
  411739:	je     41177f <__swc_fn_0a4ed24b_000146_43f4fdca+0xfbf>
  41173b:	mov    r11d,0x989680
  411741:	cmp    r10,r11
  411744:	jge    41177f <__swc_fn_0a4ed24b_000146_43f4fdca+0xfbf>
  411746:	cs nop WORD PTR [rax+rax*1+0x0]
  411750:	inc    r8d
  411753:	movabs rdx,0x6666666666666667
  41175d:	mov    r15,rax
  411760:	mov    rax,r11
  411763:	imul   rdx
  411766:	mov    r11,rdx
  411769:	mov    rax,r15
  41176c:	sar    r11,0x2
  411770:	mov    rdx,r11
  411773:	shr    rdx,0x3f
  411777:	add    r11,rdx
  41177a:	cmp    r10,r11
  41177d:	jl     411750 <__swc_fn_0a4ed24b_000146_43f4fdca+0xf90>
  41177f:	test   r8d,r8d
  411782:	je     41179d <__swc_fn_0a4ed24b_000146_43f4fdca+0xfdd>
  411784:	cs nop WORD PTR [rax+rax*1+0x0]
  41178e:	xchg   ax,ax
  411790:	mov    BYTE PTR [r9],0x30
  411794:	add    r9,0x1
  411798:	dec    r8d
  41179b:	jne    411790 <__swc_fn_0a4ed24b_000146_43f4fdca+0xfd0>
  41179d:	mov    r8,r9
  4117a0:	mov    rdx,r10
  4117a3:	cs nop WORD PTR [rax+rax*1+0x0]
  4117ad:	nop    DWORD PTR [rax]
  4117b0:	mov    r11,rdx
  4117b3:	movabs rdx,0x6666666666666667
  4117bd:	mov    rax,r11
  4117c0:	imul   rdx
  4117c3:	sar    rdx,0x2
  4117c7:	mov    r12,rdx
  4117ca:	shr    rdx,0x3f
  4117ce:	add    r12,rdx
  4117d1:	mov    rdx,r12
  4117d4:	imul   r13,r12,0xa
  4117d8:	sub    r11,r13
  4117db:	mov    r13,QWORD PTR [rip+0x1d5e]        # 413540 <__swc_rdata_base_0a4ed24b+0x430>
  4117e2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4117e7:	mov    BYTE PTR [r8],r11b
  4117ea:	lea    r11,[r8+0x1]
  4117ee:	mov    r8,r11
  4117f1:	test   r12,r12
  4117f4:	jne    4117b0 <__swc_fn_0a4ed24b_000146_43f4fdca+0xff0>
  4117f6:	test   r10,r10
  4117f9:	jge    411803 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1043>
  4117fb:	mov    BYTE PTR [r11],0x2d
  4117ff:	lea    r8,[r11+0x1]
  411803:	mov    BYTE PTR [r8],0x0
  411807:	sub    r8,0x1
  41180b:	cmp    r9,r8
  41180e:	jae    411828 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1068>
  411810:	mov    al,BYTE PTR [r8]
  411813:	mov    dl,BYTE PTR [r9]
  411816:	mov    BYTE PTR [r8],dl
  411819:	sub    r8,0x1
  41181d:	mov    BYTE PTR [r9],al
  411820:	inc    r9
  411823:	cmp    r9,r8
  411826:	jb     411810 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1050>
  411828:	xor    eax,eax
  41182a:	test   rcx,rcx
  41182d:	je     411850 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1090>
  41182f:	mov    rdx,rcx
  411832:	mov    r8b,BYTE PTR [rdx]
  411835:	test   r8b,r8b
  411838:	je     411850 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1090>
  41183a:	nop    WORD PTR [rax+rax*1+0x0]
  411840:	add    rdx,0x1
  411844:	add    rax,0x1
  411848:	mov    r8b,BYTE PTR [rdx]
  41184b:	test   r8b,r8b
  41184e:	jne    411840 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1080>
  411850:	mov    QWORD PTR [rsp+0x3f8],rcx
  411858:	mov    QWORD PTR [rsp+0x400],rax
  411860:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  411869:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  411872:	lea    rcx,[rsp+0x408]
  41187a:	call   40ff40 <__swc_fn_0a4ed24b_000116_035d76a1>
  41187f:	jmp    4118c5 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1105>
  411881:	mov    rcx,rdx
  411884:	call   40ff40 <__swc_fn_0a4ed24b_000116_035d76a1>
  411889:	jmp    4118c5 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1105>
  41188b:	mov    al,BYTE PTR [rdx]
  41188d:	test   al,al
  41188f:	je     41189a <__swc_fn_0a4ed24b_000146_43f4fdca+0x10da>
  411891:	lea    rax,[rip+0x1cc8]        # 413560 <__swc_rdata_base_0a4ed24b+0x450>
  411898:	jmp    4118a1 <__swc_fn_0a4ed24b_000146_43f4fdca+0x10e1>
  41189a:	lea    rax,[rip+0x1ccf]        # 413570 <__swc_rdata_base_0a4ed24b+0x460>
  4118a1:	mov    rcx,rax
  4118a4:	call   40ff40 <__swc_fn_0a4ed24b_000116_035d76a1>
  4118a9:	jmp    4118c5 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1105>
  4118ab:	lea    rcx,[rip+0x1cce]        # 413580 <__swc_rdata_base_0a4ed24b+0x470>
  4118b2:	call   40ff40 <__swc_fn_0a4ed24b_000116_035d76a1>
  4118b7:	jmp    4118c5 <__swc_fn_0a4ed24b_000146_43f4fdca+0x1105>
  4118b9:	lea    rcx,[rip+0x1cc0]        # 413580 <__swc_rdata_base_0a4ed24b+0x470>
  4118c0:	call   40ff40 <__swc_fn_0a4ed24b_000116_035d76a1>
  4118c5:	add    rdi,0x1
  4118c9:	sub    rsi,0x1
  4118cd:	vmovups xmm0,xmm12
  4118d2:	vmovsd xmm6,QWORD PTR [rip+0x1cb6]        # 413590 <__swc_rdata_base_0a4ed24b+0x480>
  4118da:	test   rsi,rsi
  4118dd:	jne    4108d0 <__swc_fn_0a4ed24b_000146_43f4fdca+0x110>
  4118e3:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  4118ec:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  4118f5:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  4118fe:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411907:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411910:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411919:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411922:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  41192b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411934:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  41193d:	add    rsp,0x4e8
  411944:	pop    r15
  411946:	pop    r13
  411948:	pop    r12
  41194a:	pop    rdi
  41194b:	pop    rsi
  41194c:	pop    rbx
  41194d:	ret
	...

0000000000411950 <__swc_fn_0a4ed24b_000149_9e4bc402>:
  411950:	vxorps xmm0,xmm0,xmm0
  411954:	vmovups XMMWORD PTR [rcx],xmm0
  411958:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41195d:	ret
	...

0000000000411960 <__swc_fn_0a4ed24b_000152_9e4bc402>:
  411960:	vxorps xmm0,xmm0,xmm0
  411964:	vmovups XMMWORD PTR [rcx],xmm0
  411968:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41196d:	vxorps xmm0,xmm0,xmm0
  411971:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411976:	vmovups xmm0,XMMWORD PTR [rip+0x1d22]        # 4136a0 <__swc_rdata_base_0a4ed24b+0x590>
  41197e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411983:	vxorps xmm0,xmm0,xmm0
  411987:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  41198c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411991:	vxorps xmm0,xmm0,xmm0
  411995:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  41199a:	mov    QWORD PTR [rcx+0x70],0x0
  4119a2:	ret
	...

00000000004119b0 <__swc_fn_0a4ed24b_000155_9e4bc402>:
  4119b0:	vxorps xmm0,xmm0,xmm0
  4119b4:	vmovups XMMWORD PTR [rcx],xmm0
  4119b8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4119bd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4119c2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4119c7:	ret
	...

00000000004119d0 <__swc_fn_0a4ed24b_000158_b43b2f96>:
  4119d0:	push   rsi
  4119d1:	push   rdi
  4119d2:	sub    rsp,0x8
  4119d6:	mov    rsi,rcx
  4119d9:	mov    rdi,QWORD PTR [rsi+0x50]
  4119dd:	test   rdi,rdi
  4119e0:	je     4119e7 <__swc_fn_0a4ed24b_000158_b43b2f96+0x17>
  4119e2:	mov    rcx,rsi
  4119e5:	call   rdi
  4119e7:	mov    QWORD PTR [rsi+0x20],0x0
  4119ef:	mov    rax,QWORD PTR [rsi+0x30]
  4119f3:	test   rax,rax
  4119f6:	je     411a24 <__swc_fn_0a4ed24b_000158_b43b2f96+0x54>
  4119f8:	nop    DWORD PTR [rax+rax*1+0x0]
  411a00:	mov    rdi,QWORD PTR [rax+0x8]
  411a04:	mov    rcx,rsi
  411a07:	mov    rdx,QWORD PTR [rax+0x10]
  411a0b:	mov    rax,QWORD PTR [rax+0x18]
  411a0f:	mov    r8,rax
  411a12:	call   409ec0 <__swc_fn_0a4ed24b_000156_2745c4a5>
  411a17:	mov    QWORD PTR [rsi+0x30],rdi
  411a1b:	mov    rax,QWORD PTR [rsi+0x30]
  411a1f:	test   rax,rax
  411a22:	jne    411a00 <__swc_fn_0a4ed24b_000158_b43b2f96+0x30>
  411a24:	mov    QWORD PTR [rsi+0x38],0x0
  411a2c:	add    rsp,0x8
  411a30:	pop    rdi
  411a31:	pop    rsi
  411a32:	ret
	...

0000000000411a40 <__swc_fn_0a4ed24b_000161_b5a9d657>:
  411a40:	push   rbx
  411a41:	push   rsi
  411a42:	push   rdi
  411a43:	push   r12
  411a45:	sub    rsp,0x188
  411a4c:	mov    rbx,rcx
  411a4f:	lea    rsi,[rip+0x1533a]        # 426d90 <__swc_bss_base_0a4ed24b+0x2d50>
  411a56:	mov    rcx,rsi
  411a59:	call   4098c0 <__swc_fn_0a4ed24b_000135_e3032dc2>
  411a5e:	mov    rax,QWORD PTR [rip+0x15333]        # 426d98 <__swc_bss_base_0a4ed24b+0x2d58>
  411a65:	mov    rdi,rax
  411a68:	test   rdi,rdi
  411a6b:	je     411a99 <__swc_fn_0a4ed24b_000161_b5a9d657+0x59>
  411a6d:	nop    DWORD PTR [rax]
  411a70:	cmp    QWORD PTR [rdi+0x8],rbx
  411a74:	jne    411a8e <__swc_fn_0a4ed24b_000161_b5a9d657+0x4e>
  411a76:	mov    rcx,rsi
  411a79:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  411a7e:	mov    rax,rdi
  411a81:	add    rsp,0x188
  411a88:	pop    r12
  411a8a:	pop    rdi
  411a8b:	pop    rsi
  411a8c:	pop    rbx
  411a8d:	ret
  411a8e:	mov    rax,QWORD PTR [rdi]
  411a91:	mov    rdi,rax
  411a94:	test   rax,rax
  411a97:	jne    411a70 <__swc_fn_0a4ed24b_000161_b5a9d657+0x30>
  411a99:	call   40d100 <__swc_fn_0a4ed24b_000139_7c02fe26>
  411a9e:	mov    rdi,rax
  411aa1:	test   rax,rax
  411aa4:	jne    411abd <__swc_fn_0a4ed24b_000161_b5a9d657+0x7d>
  411aa6:	mov    rcx,rsi
  411aa9:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  411aae:	xor    eax,eax
  411ab0:	add    rsp,0x188
  411ab7:	pop    r12
  411ab9:	pop    rdi
  411aba:	pop    rsi
  411abb:	pop    rbx
  411abc:	ret
  411abd:	lea    rax,[rsp+0x18]
  411ac2:	mov    QWORD PTR [rax+0x10],0x0
  411aca:	mov    QWORD PTR [rax+0x18],0x0
  411ad2:	mov    DWORD PTR [rax+0x20],0x0
  411ad9:	mov    BYTE PTR [rax+0x24],0x0
  411add:	mov    rax,QWORD PTR [rip+0x152b4]        # 426d98 <__swc_bss_base_0a4ed24b+0x2d58>
  411ae4:	mov    QWORD PTR [rsp+0x18],rax
  411ae9:	mov    QWORD PTR [rsp+0x20],rbx
  411aee:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411af4:	vmovups XMMWORD PTR [rdi],xmm0
  411af8:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  411afe:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  411b03:	mov    rax,QWORD PTR [rsp+0x38]
  411b08:	mov    QWORD PTR [rdi+0x20],rax
  411b0c:	mov    QWORD PTR [rip+0x15285],rdi        # 426d98 <__swc_bss_base_0a4ed24b+0x2d58>
  411b13:	lea    rax,[rsp+0x40]
  411b18:	mov    QWORD PTR [rax],0x0
  411b1f:	mov    rcx,rbx
  411b22:	mov    rdx,rax
  411b25:	call   4099a0 <__swc_fn_0a4ed24b_000141_2ce79e3b>
  411b2a:	mov    rbx,rax
  411b2d:	test   rax,rax
  411b30:	jne    411b4a <__swc_fn_0a4ed24b_000161_b5a9d657+0x10a>
  411b32:	mov    rcx,rsi
  411b35:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  411b3a:	mov    rax,rdi
  411b3d:	add    rsp,0x188
  411b44:	pop    r12
  411b46:	pop    rdi
  411b47:	pop    rsi
  411b48:	pop    rbx
  411b49:	ret
  411b4a:	lea    r12,[rsp+0x50]
  411b4f:	mov    QWORD PTR [r12],0x0
  411b57:	mov    rcx,rbx
  411b5a:	mov    rdx,QWORD PTR [rsp+0x40]
  411b5f:	mov    r8,r12
  411b62:	call   40d1b0 <__swc_fn_0a4ed24b_000142_56e56812>
  411b67:	test   rax,rax
  411b6a:	jne    411b84 <__swc_fn_0a4ed24b_000161_b5a9d657+0x144>
  411b6c:	mov    rcx,rsi
  411b6f:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  411b74:	mov    rax,rdi
  411b77:	add    rsp,0x188
  411b7e:	pop    r12
  411b80:	pop    rdi
  411b81:	pop    rsi
  411b82:	pop    rbx
  411b83:	ret
  411b84:	cmp    QWORD PTR [r12],0x10
  411b89:	jb     411c8c <__swc_fn_0a4ed24b_000161_b5a9d657+0x24c>
  411b8f:	mov    ecx,DWORD PTR [rax]
  411b91:	cmp    ecx,0x42445753
  411b97:	jne    411c8c <__swc_fn_0a4ed24b_000161_b5a9d657+0x24c>
  411b9d:	mov    ecx,DWORD PTR [rax+0x4]
  411ba0:	cmp    ecx,0x1
  411ba3:	jne    411c8c <__swc_fn_0a4ed24b_000161_b5a9d657+0x24c>
  411ba9:	mov    ecx,DWORD PTR [rax+0x8]
  411bac:	mov    edx,DWORD PTR [rax+0xc]
  411baf:	imul   r8,rcx,0x14
  411bb3:	mov    r9,QWORD PTR [rsp+0x50]
  411bb8:	sub    r9,0x10
  411bbc:	cmp    r8,r9
  411bbf:	ja     411c8c <__swc_fn_0a4ed24b_000161_b5a9d657+0x24c>
  411bc5:	lea    r8,[r8+0x10]
  411bc9:	cmp    rdx,r8
  411bcc:	jb     411c8c <__swc_fn_0a4ed24b_000161_b5a9d657+0x24c>
  411bd2:	mov    r8,QWORD PTR [rsp+0x50]
  411bd7:	cmp    rdx,r8
  411bda:	ja     411c8c <__swc_fn_0a4ed24b_000161_b5a9d657+0x24c>
  411be0:	xor    r8d,r8d
  411be3:	test   rcx,rcx
  411be6:	jbe    411cb2 <__swc_fn_0a4ed24b_000161_b5a9d657+0x272>
  411bec:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  411bf2:	cs nop WORD PTR [rax+rax*1+0x0]
  411bfc:	nop    DWORD PTR [rax+0x0]
  411c00:	imul   r9,r8,0x14
  411c04:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  411c09:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  411c0e:	add    r10,r11
  411c11:	movabs r11,0x100000000
  411c1b:	cmp    r10,r11
  411c1e:	ja     411c8c <__swc_fn_0a4ed24b_000161_b5a9d657+0x24c>
  411c20:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  411c25:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  411c2a:	test   r10d,r10d
  411c2d:	setne  r11b
  411c31:	je     411c4b <__swc_fn_0a4ed24b_000161_b5a9d657+0x20b>
  411c33:	cmp    r10d,edx
  411c36:	setb   r11b
  411c3a:	jb     411c4b <__swc_fn_0a4ed24b_000161_b5a9d657+0x20b>
  411c3c:	vmovq  r11,xmm1
  411c41:	cmp    r10,r11
  411c44:	setae  r10b
  411c48:	mov    r11b,r10b
  411c4b:	mov    r10,r11
  411c4e:	test   r11b,r11b
  411c51:	jne    411c78 <__swc_fn_0a4ed24b_000161_b5a9d657+0x238>
  411c53:	test   r9d,r9d
  411c56:	setne  r10b
  411c5a:	je     411c78 <__swc_fn_0a4ed24b_000161_b5a9d657+0x238>
  411c5c:	cmp    r9d,edx
  411c5f:	setb   r10b
  411c63:	jb     411c78 <__swc_fn_0a4ed24b_000161_b5a9d657+0x238>
  411c65:	vmovq  r10,xmm1
  411c6a:	cmp    r9,r10
  411c6d:	setae  r9b
  411c71:	movzx  r9d,r9b
  411c75:	mov    r10b,r9b
  411c78:	test   r10b,r10b
  411c7b:	jne    411c8c <__swc_fn_0a4ed24b_000161_b5a9d657+0x24c>
  411c7d:	add    r8,0x1
  411c81:	cmp    r8,rcx
  411c84:	jb     411c00 <__swc_fn_0a4ed24b_000161_b5a9d657+0x1c0>
  411c8a:	jmp    411cb2 <__swc_fn_0a4ed24b_000161_b5a9d657+0x272>
  411c8c:	xor    ecx,ecx
  411c8e:	cmp    rax,rbx
  411c91:	cmovne rcx,rax
  411c95:	call   410710 <__swc_fn_0a4ed24b_000143_81c0d993>
  411c9a:	mov    rcx,rsi
  411c9d:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  411ca2:	mov    rax,rdi
  411ca5:	add    rsp,0x188
  411cac:	pop    r12
  411cae:	pop    rdi
  411caf:	pop    rsi
  411cb0:	pop    rbx
  411cb1:	ret
  411cb2:	mov    QWORD PTR [rdi+0x10],rax
  411cb6:	mov    rcx,QWORD PTR [rsp+0x50]
  411cbb:	mov    QWORD PTR [rdi+0x18],rcx
  411cbf:	mov    eax,DWORD PTR [rax+0x8]
  411cc2:	mov    DWORD PTR [rdi+0x20],eax
  411cc5:	rex mov BYTE PTR [rdi+0x24],0x1
  411cca:	mov    rcx,rsi
  411ccd:	call   40d0f0 <__swc_fn_0a4ed24b_000136_3e875c27>
  411cd2:	mov    rax,rdi
  411cd5:	add    rsp,0x188
  411cdc:	pop    r12
  411cde:	pop    rdi
  411cdf:	pop    rsi
  411ce0:	pop    rbx
  411ce1:	ret
	...

0000000000411cf0 <__swc_fn_0a4ed24b_000164_1962e12a>:
  411cf0:	push   rsi
  411cf1:	push   rdi
  411cf2:	push   r12
  411cf4:	mov    rsi,rdx
  411cf7:	mov    rdi,rcx
  411cfa:	mov    rcx,QWORD PTR [rip+0x1503f]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  411d01:	test   rcx,rcx
  411d04:	jne    411d16 <__swc_fn_0a4ed24b_000164_1962e12a+0x26>
  411d06:	call   40a1d0 <__swc_fn_0a4ed24b_000165_cf398896>
  411d0b:	lea    rcx,[rax+0x1]
  411d0f:	mov    QWORD PTR [rip+0x1502a],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  411d16:	dec    rcx
  411d19:	call   411d40 <__swc_fn_0a4ed24b_000167_fce60b2b>
  411d1e:	mov    r12,QWORD PTR [rax+0xbe0]
  411d25:	test   r12,r12
  411d28:	setne  al
  411d2b:	je     411d36 <__swc_fn_0a4ed24b_000164_1962e12a+0x46>
  411d2d:	mov    rcx,rdi
  411d30:	mov    rdx,rsi
  411d33:	call   r12
  411d36:	pop    r12
  411d38:	pop    rdi
  411d39:	pop    rsi
  411d3a:	ret
  411d3b:	add    BYTE PTR [rax],al
  411d3d:	add    BYTE PTR [rax],al
	...

0000000000411d40 <__swc_fn_0a4ed24b_000167_fce60b2b>:
  411d40:	push   r12
  411d42:	push   rdi
  411d43:	push   rsi
  411d44:	sub    rsp,0xd0
  411d4b:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  411d51:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  411d57:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  411d5d:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  411d63:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  411d69:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  411d6f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  411d78:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  411d81:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  411d8a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  411d93:	mov    r12,rcx
  411d96:	mov    edi,ecx
  411d98:	xor    eax,eax
  411d9a:	call   407000 <pthread_getspecific@plt>
  411d9f:	test   rax,rax
  411da2:	je     411da6 <__swc_fn_0a4ed24b_000167_fce60b2b+0x66>
  411da4:	jmp    411dae <__swc_fn_0a4ed24b_000167_fce60b2b+0x6e>
  411da6:	mov    rcx,r12
  411da9:	call   40a230 <__swc_fn_0a4ed24b_000168_92b7d63c>
  411dae:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  411db4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  411dba:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  411dc0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  411dc6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  411dcc:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  411dd2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  411ddb:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  411de4:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  411ded:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  411df6:	add    rsp,0xd0
  411dfd:	pop    rsi
  411dfe:	pop    rdi
  411dff:	pop    r12
  411e01:	ret
	...

0000000000411e10 <__swc_fn_0a4ed24b_000170_fa3003e2>:
  411e10:	push   rsi
  411e11:	sub    rsp,0x30
  411e15:	lea    rsi,[rip+0x14f8c]        # 426da8 <__swc_bss_base_0a4ed24b+0x2d68>
  411e1c:	mov    rax,QWORD PTR [rsi]
  411e1f:	test   rax,rax
  411e22:	je     411e2a <__swc_fn_0a4ed24b_000170_fa3003e2+0x1a>
  411e24:	add    rsp,0x30
  411e28:	pop    rsi
  411e29:	ret
  411e2a:	mov    ecx,0x3
  411e2f:	mov    edx,0x10
  411e34:	call   40f840 <__swc_fn_0a4ed24b_000107_4796e893>
  411e39:	test   rax,rax
  411e3c:	jne    411e4d <__swc_fn_0a4ed24b_000170_fa3003e2+0x3d>
  411e3e:	mov    QWORD PTR [rsp+0x18],rax
  411e43:	call   40cc50 <__swc_fn_0a4ed24b_000118_7f430081>
  411e48:	mov    rax,QWORD PTR [rsp+0x18]
  411e4d:	mov    rcx,rax
  411e50:	xchg   QWORD PTR [rsi],rcx
  411e53:	add    rsp,0x30
  411e57:	pop    rsi
  411e58:	ret
  411e59:	add    BYTE PTR [rax],al
  411e5b:	add    BYTE PTR [rax],al
  411e5d:	add    BYTE PTR [rax],al
	...

0000000000411e60 <__swc_fn_0a4ed24b_000173_f69b1f05>:
  411e60:	push   rsi
  411e61:	push   rdi
  411e62:	sub    rsp,0x8
  411e66:	mov    rsi,rdx
  411e69:	mov    rdi,rcx
  411e6c:	mov    rax,QWORD PTR [rsi+0x8]
  411e70:	test   rax,rax
  411e73:	je     411e7d <__swc_fn_0a4ed24b_000173_f69b1f05+0x1d>
  411e75:	mov    rcx,QWORD PTR [rsi]
  411e78:	mov    QWORD PTR [rax],rcx
  411e7b:	jmp    411e84 <__swc_fn_0a4ed24b_000173_f69b1f05+0x24>
  411e7d:	mov    rax,QWORD PTR [rsi]
  411e80:	mov    QWORD PTR [rdi+0x8],rax
  411e84:	mov    rax,QWORD PTR [rsi]
  411e87:	test   rax,rax
  411e8a:	je     411e94 <__swc_fn_0a4ed24b_000173_f69b1f05+0x34>
  411e8c:	mov    rcx,QWORD PTR [rsi+0x8]
  411e90:	mov    QWORD PTR [rax+0x8],rcx
  411e94:	mov    rcx,rdi
  411e97:	mov    rdx,QWORD PTR [rsi+0x10]
  411e9b:	mov    r8,QWORD PTR [rsi+0x18]
  411e9f:	mov    r9,0xffffffffffffffff
  411ea6:	call   40d820 <__swc_fn_0a4ed24b_000172_97fbc432>
  411eab:	mov    QWORD PTR [rsi+0x18],0x0
  411eb3:	mov    rax,QWORD PTR [rdi+0x8]
  411eb7:	test   rax,rax
  411eba:	jne    411ecc <__swc_fn_0a4ed24b_000173_f69b1f05+0x6c>
  411ebc:	call   411e10 <__swc_fn_0a4ed24b_000170_fa3003e2>
  411ec1:	xor    ecx,ecx
  411ec3:	mov    QWORD PTR [rax+0x8],rcx
  411ec7:	xor    ecx,ecx
  411ec9:	mov    QWORD PTR [rax],rcx
  411ecc:	add    rsp,0x8
  411ed0:	pop    rdi
  411ed1:	pop    rsi
  411ed2:	ret
	...

0000000000411ee0 <__swc_fn_0a4ed24b_000176_0d61c738>:
  411ee0:	push   rbp
  411ee1:	sub    rsp,0x108
  411ee8:	mov    rbp,rsp
  411eeb:	vmovups XMMWORD PTR [rsp+0x60],xmm6
  411ef1:	vmovups XMMWORD PTR [rsp+0x70],xmm7
  411ef7:	vmovups XMMWORD PTR [rsp+0x80],xmm8
  411f00:	vmovups XMMWORD PTR [rsp+0x90],xmm9
  411f09:	vmovups XMMWORD PTR [rsp+0xa0],xmm10
  411f12:	vmovups XMMWORD PTR [rsp+0xb0],xmm12
  411f1b:	vmovups XMMWORD PTR [rsp+0xc0],xmm13
  411f24:	vmovups XMMWORD PTR [rsp+0xd0],xmm14
  411f2d:	vmovups XMMWORD PTR [rsp+0xe0],xmm15
  411f36:	vmovups XMMWORD PTR [rsp+0xf0],xmm11
  411f3f:	vmovups xmm6,xmm5
  411f43:	vmovups xmm7,xmm0
  411f47:	vmovups xmm0,xmm1
  411f4b:	vmovups xmm1,xmm2
  411f4f:	vmovups xmm2,xmm3
  411f53:	vmovups xmm3,xmm4
  411f57:	vmovsd QWORD PTR [rsp+0x50],xmm4
  411f5d:	vmovsd xmm4,QWORD PTR [rbp+0x118]
  411f65:	vmovsd xmm5,QWORD PTR [rip+0x19a4]        # 413911 <__swc_rdata_base_0a4ed24b+0x801>
  411f6d:	mov    eax,0xffffffff
  411f72:	vsubsd xmm8,xmm0,QWORD PTR [rip+0x19a0]        # 41391a <__swc_rdata_base_0a4ed24b+0x80a>
  411f7a:	vsubsd xmm9,xmm1,QWORD PTR [rip+0x19a1]        # 413923 <__swc_rdata_base_0a4ed24b+0x813>
  411f82:	vmulsd xmm10,xmm7,xmm2
  411f86:	vfmadd231sd xmm10,xmm8,xmm3
  411f8b:	vfmadd231sd xmm10,xmm9,xmm6
  411f90:	vaddsd xmm10,xmm10,xmm10
  411f95:	vmulsd xmm12,xmm7,xmm7
  411f99:	vfmadd213sd xmm8,xmm8,xmm12
  411f9e:	vfmadd231sd xmm8,xmm9,xmm9
  411fa3:	vmovsd xmm14,QWORD PTR [rip+0x1981]        # 41392c <__swc_rdata_base_0a4ed24b+0x81c>
  411fab:	vsubsd xmm8,xmm8,xmm14
  411fb0:	vmulsd xmm9,xmm10,xmm10
  411fb5:	vmovsd xmm15,QWORD PTR [rip+0x1978]        # 413935 <__swc_rdata_base_0a4ed24b+0x825>
  411fbd:	vfnmadd213sd xmm8,xmm15,xmm9
  411fc2:	vxorpd xmm9,xmm9,xmm9
  411fc7:	vcomisd xmm9,xmm8
  411fcc:	ja     412017 <__swc_fn_0a4ed24b_000176_0d61c738+0x137>
  411fce:	vsqrtsd xmm9,xmm8,xmm8
  411fd3:	vxorpd xmm10,xmm10,XMMWORD PTR [rip+0x1575]        # 413550 <__swc_rdata_base_0a4ed24b+0x440>
  411fdb:	vsubsd xmm8,xmm10,xmm9
  411fe0:	vmovsd xmm12,QWORD PTR [rip+0x15cc]        # 4135b4 <__swc_rdata_base_0a4ed24b+0x4a4>
  411fe8:	vmulsd xmm8,xmm8,xmm12
  411fed:	vmovups xmm11,xmm8
  411ff2:	vcomisd xmm4,xmm8
  411ff7:	jbe    412003 <__swc_fn_0a4ed24b_000176_0d61c738+0x123>
  411ff9:	vaddsd xmm8,xmm10,xmm9
  411ffe:	vmulsd xmm11,xmm8,xmm12
  412003:	vcomisd xmm11,xmm4
  412007:	jb     412017 <__swc_fn_0a4ed24b_000176_0d61c738+0x137>
  412009:	vcomisd xmm5,xmm11
  41200e:	jbe    412017 <__swc_fn_0a4ed24b_000176_0d61c738+0x137>
  412010:	vmovups xmm5,xmm11
  412015:	xor    eax,eax
  412017:	vsubsd xmm13,xmm7,QWORD PTR [rip+0x191f]        # 41393e <__swc_rdata_base_0a4ed24b+0x82e>
  41201f:	vsubsd xmm9,xmm1,QWORD PTR [rip+0x1920]        # 413947 <__swc_rdata_base_0a4ed24b+0x837>
  412027:	vmulsd xmm10,xmm13,xmm2
  41202b:	vmulsd xmm11,xmm0,xmm3
  41202f:	vaddsd xmm10,xmm10,xmm11
  412034:	vfmadd231sd xmm10,xmm9,xmm6
  412039:	vaddsd xmm10,xmm10,xmm10
  41203e:	vmulsd xmm12,xmm13,xmm13
  412043:	vmulsd xmm13,xmm0,xmm0
  412047:	vaddsd xmm8,xmm12,xmm13
  41204c:	vfmadd231sd xmm8,xmm9,xmm9
  412051:	vsubsd xmm8,xmm8,xmm14
  412056:	vmulsd xmm9,xmm10,xmm10
  41205b:	vfnmadd213sd xmm8,xmm15,xmm9
  412060:	vxorpd xmm9,xmm9,xmm9
  412065:	vcomisd xmm9,xmm8
  41206a:	ja     4120b6 <__swc_fn_0a4ed24b_000176_0d61c738+0x1d6>
  41206c:	vsqrtsd xmm9,xmm8,xmm8
  412071:	vxorpd xmm10,xmm10,XMMWORD PTR [rip+0x14d7]        # 413550 <__swc_rdata_base_0a4ed24b+0x440>
  412079:	vsubsd xmm8,xmm10,xmm9
  41207e:	vmovsd xmm12,QWORD PTR [rip+0x152e]        # 4135b4 <__swc_rdata_base_0a4ed24b+0x4a4>
  412086:	vmulsd xmm8,xmm8,xmm12
  41208b:	vmovups xmm3,xmm8
  412090:	vcomisd xmm4,xmm8
  412095:	jbe    4120a1 <__swc_fn_0a4ed24b_000176_0d61c738+0x1c1>
  412097:	vaddsd xmm8,xmm10,xmm9
  41209c:	vmulsd xmm3,xmm8,xmm12
  4120a1:	vcomisd xmm3,xmm4
  4120a5:	jb     4120b6 <__swc_fn_0a4ed24b_000176_0d61c738+0x1d6>
  4120a7:	vcomisd xmm5,xmm3
  4120ab:	jbe    4120b6 <__swc_fn_0a4ed24b_000176_0d61c738+0x1d6>
  4120ad:	vmovups xmm5,xmm3
  4120b1:	mov    eax,0x1
  4120b6:	vsubsd xmm3,xmm7,QWORD PTR [rip+0x1892]        # 413950 <__swc_rdata_base_0a4ed24b+0x840>
  4120be:	vsubsd xmm9,xmm1,QWORD PTR [rip+0x186f]        # 413935 <__swc_rdata_base_0a4ed24b+0x825>
  4120c6:	vmulsd xmm10,xmm3,xmm2
  4120ca:	vaddsd xmm10,xmm10,xmm11
  4120cf:	vfmadd231sd xmm10,xmm9,xmm6
  4120d4:	vaddsd xmm10,xmm10,xmm10
  4120d9:	vmulsd xmm12,xmm3,xmm3
  4120dd:	vaddsd xmm8,xmm12,xmm13
  4120e2:	vfmadd231sd xmm8,xmm9,xmm9
  4120e7:	vsubsd xmm8,xmm8,xmm14
  4120ec:	vmulsd xmm9,xmm10,xmm10
  4120f1:	vfnmadd213sd xmm8,xmm15,xmm9
  4120f6:	vxorpd xmm9,xmm9,xmm9
  4120fb:	vcomisd xmm9,xmm8
  412100:	ja     41214c <__swc_fn_0a4ed24b_000176_0d61c738+0x26c>
  412102:	vsqrtsd xmm9,xmm8,xmm8
  412107:	vxorpd xmm10,xmm10,XMMWORD PTR [rip+0x1441]        # 413550 <__swc_rdata_base_0a4ed24b+0x440>
  41210f:	vsubsd xmm8,xmm10,xmm9
  412114:	vmovsd xmm12,QWORD PTR [rip+0x1498]        # 4135b4 <__swc_rdata_base_0a4ed24b+0x4a4>
  41211c:	vmulsd xmm8,xmm8,xmm12
  412121:	vmovups xmm3,xmm8
  412126:	vcomisd xmm4,xmm8
  41212b:	jbe    412137 <__swc_fn_0a4ed24b_000176_0d61c738+0x257>
  41212d:	vaddsd xmm8,xmm10,xmm9
  412132:	vmulsd xmm3,xmm8,xmm12
  412137:	vcomisd xmm3,xmm4
  41213b:	jb     41214c <__swc_fn_0a4ed24b_000176_0d61c738+0x26c>
  41213d:	vcomisd xmm5,xmm3
  412141:	jbe    41214c <__swc_fn_0a4ed24b_000176_0d61c738+0x26c>
  412143:	vmovups xmm5,xmm3
  412147:	mov    eax,0x2
  41214c:	vsubsd xmm8,xmm0,QWORD PTR [rip+0x1805]        # 413959 <__swc_rdata_base_0a4ed24b+0x849>
  412154:	vmulsd xmm10,xmm7,xmm2
  412158:	vfmadd231sd xmm10,xmm8,QWORD PTR [rsp+0x50]
  41215f:	vfmadd231sd xmm10,xmm1,xmm6
  412164:	vaddsd xmm10,xmm10,xmm10
  412169:	vmulsd xmm12,xmm7,xmm7
  41216d:	vfmadd213sd xmm8,xmm8,xmm12
  412172:	vfmadd231sd xmm8,xmm1,xmm1
  412177:	vsubsd xmm8,xmm8,QWORD PTR [rip+0x17e3]        # 413962 <__swc_rdata_base_0a4ed24b+0x852>
  41217f:	vmulsd xmm9,xmm10,xmm10
  412184:	vfnmadd213sd xmm8,xmm15,xmm9
  412189:	vxorpd xmm9,xmm9,xmm9
  41218e:	vcomisd xmm9,xmm8
  412193:	ja     4121df <__swc_fn_0a4ed24b_000176_0d61c738+0x2ff>
  412195:	vsqrtsd xmm9,xmm8,xmm8
  41219a:	vxorpd xmm10,xmm10,XMMWORD PTR [rip+0x13ae]        # 413550 <__swc_rdata_base_0a4ed24b+0x440>
  4121a2:	vsubsd xmm8,xmm10,xmm9
  4121a7:	vmovsd xmm12,QWORD PTR [rip+0x1405]        # 4135b4 <__swc_rdata_base_0a4ed24b+0x4a4>
  4121af:	vmulsd xmm8,xmm8,xmm12
  4121b4:	vmovups xmm3,xmm8
  4121b9:	vcomisd xmm4,xmm8
  4121be:	jbe    4121ca <__swc_fn_0a4ed24b_000176_0d61c738+0x2ea>
  4121c0:	vaddsd xmm8,xmm10,xmm9
  4121c5:	vmulsd xmm3,xmm8,xmm12
  4121ca:	vcomisd xmm3,xmm4
  4121ce:	jb     4121df <__swc_fn_0a4ed24b_000176_0d61c738+0x2ff>
  4121d0:	vcomisd xmm5,xmm3
  4121d4:	jbe    4121df <__swc_fn_0a4ed24b_000176_0d61c738+0x2ff>
  4121d6:	vmovups xmm5,xmm3
  4121da:	mov    eax,0x3
  4121df:	vmovsd QWORD PTR [rip+0x14bc9],xmm5        # 426db0 <__swc_bss_base_0a4ed24b+0x2d70>
  4121e7:	mov    DWORD PTR [rip+0xfe23],eax        # 422010 <__swc_data_base_0a4ed24b+0x10>
  4121ed:	vmovups xmm6,XMMWORD PTR [rsp+0x60]
  4121f3:	vmovups xmm7,XMMWORD PTR [rsp+0x70]
  4121f9:	vmovups xmm8,XMMWORD PTR [rsp+0x80]
  412202:	vmovups xmm9,XMMWORD PTR [rsp+0x90]
  41220b:	vmovups xmm10,XMMWORD PTR [rsp+0xa0]
  412214:	vmovups xmm12,XMMWORD PTR [rsp+0xb0]
  41221d:	vmovups xmm13,XMMWORD PTR [rsp+0xc0]
  412226:	vmovups xmm14,XMMWORD PTR [rsp+0xd0]
  41222f:	vmovups xmm15,XMMWORD PTR [rsp+0xe0]
  412238:	vmovups xmm11,XMMWORD PTR [rsp+0xf0]
  412241:	add    rsp,0x108
  412248:	pop    rbp
  412249:	ret
