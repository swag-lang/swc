
/workspace/prompt2-20261115/batch7-placement-micro/base/lz77/lz77:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <getpid@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <getpid@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <munmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <munmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <exit@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <exit@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <pthread_key_create@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <pthread_key_create@GLIBC_2.34>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_setspecific@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <pthread_setspecific@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <syscall@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <syscall@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dladdr@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <dladdr@GLIBC_2.34>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <open@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <open@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <lseek@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <lseek@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <close@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <close@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <mmap@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <mmap@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <malloc@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <malloc@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <clock_gettime@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf92]        # 413078 <clock_gettime@GLIBC_2.17>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <madvise@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf92]        # 413088 <madvise@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <pthread_key_delete@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf8a]        # 413090 <pthread_key_delete@GLIBC_2.34>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <gettid@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf82]        # 413098 <gettid@GLIBC_2.30>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <flock@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf7a]        # 4130a0 <flock@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <__errno_location@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf72]        # 4130a8 <__errno_location@GLIBC_2.2.5>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <opendir@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf6a]        # 4130b0 <opendir@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <dirfd@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf62]        # 4130b8 <dirfd@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <readdir@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <readdir@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <readlinkat@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <readlinkat@GLIBC_2.4>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <openat@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <openat@GLIBC_2.4>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <closedir@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <closedir@GLIBC_2.2.5>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <memfd_create@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <memfd_create@GLIBC_2.27>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <ftruncate@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <ftruncate@GLIBC_2.2.5>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <write@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <write@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <backtrace@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <backtrace@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <__x86_get_cpuid_feature_leaf@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <free@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <free@GLIBC_2.2.5>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_23cea7fa_000176_5d3d19bd+0xec0>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40ca80 <__swc_fn_23cea7fa_000121_1c5e75b6>
  40724e:	xor    ecx,ecx
  407250:	call   40c1a0 <__swc_fn_23cea7fa_000094_383a814c>
  407255:	call   40d6e0 <__swc_fn_23cea7fa_000178_3a24e5ea>
  40725a:	call   40f790 <__swc_fn_23cea7fa_000095_8cc4b392>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_23cea7fa_000000_0e26756e>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_23cea7fa_000003_81215399>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_23cea7fa_000003_81215399+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   409240 <__swc_fn_23cea7fa_000111_f9e19033>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_23cea7fa_000003_81215399+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1cd81]        # 424048 <__swc_bss_base_23cea7fa+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1cd7a]        # 424048 <__swc_bss_base_23cea7fa+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_23cea7fa_000003_81215399+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_23cea7fa_000003_81215399+0x30>
  4072e6:	lea    rcx,[rip+0x1cd63]        # 424050 <__swc_bss_base_23cea7fa+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1cd5c]        # 424050 <__swc_bss_base_23cea7fa+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_23cea7fa_000003_81215399+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_23cea7fa_000003_81215399+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_23cea7fa_000006_7b253ae1>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40e040 <__swc_fn_23cea7fa_000011_71c91685>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_23cea7fa_000012_be38a1a2>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_23cea7fa_000006_7b253ae1+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_23cea7fa_000003_81215399>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_23cea7fa_000006_7b253ae1+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_23cea7fa_000009_4c3ebf16>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_23cea7fa_000009_4c3ebf16+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40a530 <__swc_fn_23cea7fa_000007_a7bfb091>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40e030 <__swc_fn_23cea7fa_000008_b2f73e0d>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_23cea7fa_000009_4c3ebf16+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_23cea7fa_000009_4c3ebf16+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_23cea7fa_000012_be38a1a2>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_23cea7fa_000015_96cb1311>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_23cea7fa_000015_96cb1311+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_23cea7fa_000015_96cb1311+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_23cea7fa_000015_96cb1311+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_23cea7fa_000015_96cb1311+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40e1a0 <__swc_fn_23cea7fa_000017_f003fc47>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_23cea7fa_000015_96cb1311+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1cb3d]        # 424058 <__swc_bss_base_23cea7fa+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1cb36]        # 424058 <__swc_bss_base_23cea7fa+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_23cea7fa_000015_96cb1311+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_23cea7fa_000015_96cb1311+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40e040 <__swc_fn_23cea7fa_000011_71c91685>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_23cea7fa_000015_96cb1311+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   40c7a0 <__swc_fn_23cea7fa_000112_2f7f9346>
  407569:	lea    rcx,[rip+0x1cad8]        # 424048 <__swc_bss_base_23cea7fa+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1cad1]        # 424048 <__swc_bss_base_23cea7fa+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_23cea7fa_000015_96cb1311+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_23cea7fa_000015_96cb1311+0x110>
  407598:	lea    rcx,[rip+0x1cac1]        # 424060 <__swc_bss_base_23cea7fa+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1caba]        # 424060 <__swc_bss_base_23cea7fa+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_23cea7fa_000015_96cb1311+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_23cea7fa_000015_96cb1311+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_23cea7fa_000018_77ece227>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_23cea7fa_000015_96cb1311+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_23cea7fa_000018_77ece227>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_23cea7fa_000018_77ece227+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_23cea7fa_000018_77ece227+0x10>

0000000000407630 <__swc_fn_23cea7fa_000021_9cf87641>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_23cea7fa_000015_96cb1311>
  40763e:	lea    rdi,[rip+0x1cbab]        # 4241f0 <__swc_bss_base_23cea7fa+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   4098a0 <__swc_fn_23cea7fa_000135_db32cc57>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1cb94]        # 4241f8 <__swc_bss_base_23cea7fa+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1cb89],rsi        # 4241f8 <__swc_bss_base_23cea7fa+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_23cea7fa_000024_e876734d>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_23cea7fa_000027_e876734d>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_23cea7fa_000030_650caec0>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_23cea7fa_000030_650caec0+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1a92c]        # 422000 <__swc_data_base_23cea7fa>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_23cea7fa_000030_650caec0+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_23cea7fa_000030_650caec0+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_23cea7fa_000030_650caec0+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40e360 <__swc_fn_23cea7fa_000032_f1940e30>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_23cea7fa_000030_650caec0+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_23cea7fa_000036_290a131c>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_23cea7fa_000030_650caec0+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_23cea7fa_000042_0573444d>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_23cea7fa_000033_d15eb4ea>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40a9e0 <__swc_fn_23cea7fa_000031_3c3e930e>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   409720 <__swc_fn_23cea7fa_000129_bc477461>
  407734:	mov    rcx,rsi
  407737:	call   40e360 <__swc_fn_23cea7fa_000032_f1940e30>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_23cea7fa_000036_290a131c>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_23cea7fa_000039_9ae4348f>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_23cea7fa_000039_9ae4348f+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_23cea7fa_000039_9ae4348f+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_23cea7fa_000039_9ae4348f+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_23cea7fa_000039_9ae4348f+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_23cea7fa_000039_9ae4348f+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   409320 <__swc_fn_23cea7fa_000114_cc486df9>
  4077ca:	lea    rcx,[rip+0x1c877]        # 424048 <__swc_bss_base_23cea7fa+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1c870]        # 424048 <__swc_bss_base_23cea7fa+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_23cea7fa_000039_9ae4348f+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_23cea7fa_000039_9ae4348f+0x90>
  4077f8:	lea    rcx,[rip+0x1c861]        # 424060 <__swc_bss_base_23cea7fa+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1c85a]        # 424060 <__swc_bss_base_23cea7fa+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_23cea7fa_000039_9ae4348f+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_23cea7fa_000039_9ae4348f+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_23cea7fa_000042_0573444d>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_23cea7fa_000042_0573444d+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40e930 <__swc_fn_23cea7fa_000059_ee6a254c>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   4098a0 <__swc_fn_23cea7fa_000135_db32cc57>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_23cea7fa_000042_0573444d+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_23cea7fa_000042_0573444d+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_23cea7fa_000009_4c3ebf16>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_23cea7fa_000042_0573444d+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40e060 <__swc_fn_23cea7fa_000014_be17798c>
  40791e:	jmp    407941 <__swc_fn_23cea7fa_000042_0573444d+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_23cea7fa_000042_0573444d+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_23cea7fa_000042_0573444d+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_23cea7fa_000042_0573444d+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40aba0 <__swc_fn_23cea7fa_000043_47ff6d9b>
  407997:	mov    rcx,rdi
  40799a:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_23cea7fa_000039_9ae4348f>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_23cea7fa_000045_bb688d37>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_23cea7fa_000045_bb688d37+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_23cea7fa_000045_bb688d37+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_23cea7fa_000045_bb688d37+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_23cea7fa_000045_bb688d37+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   4098a0 <__swc_fn_23cea7fa_000135_db32cc57>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_23cea7fa_000045_bb688d37+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_23cea7fa_000045_bb688d37+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_23cea7fa_000045_bb688d37+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_23cea7fa_000045_bb688d37+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_23cea7fa_000009_4c3ebf16>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_23cea7fa_000045_bb688d37+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_23cea7fa_000045_bb688d37+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_23cea7fa_000045_bb688d37+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_23cea7fa_000045_bb688d37+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_23cea7fa_000045_bb688d37+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40a5e0 <__swc_fn_23cea7fa_000013_7b85dbab>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_23cea7fa_000045_bb688d37+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_23cea7fa_000045_bb688d37+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_23cea7fa_000045_bb688d37+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_23cea7fa_000045_bb688d37+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40e1e0 <__swc_fn_23cea7fa_000020_4285d9c5>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_23cea7fa_000045_bb688d37+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40a5e0 <__swc_fn_23cea7fa_000013_7b85dbab>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_23cea7fa_000045_bb688d37+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_23cea7fa_000021_9cf87641>
  407c07:	mov    rcx,r14
  407c0a:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_23cea7fa_000045_bb688d37+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_23cea7fa_000045_bb688d37+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_23cea7fa_000045_bb688d37+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_23cea7fa_000048_8e68f77b>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_23cea7fa_000048_8e68f77b+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_23cea7fa_000048_8e68f77b+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_23cea7fa_000048_8e68f77b+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_23cea7fa_000048_8e68f77b+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40e590 <__swc_fn_23cea7fa_000047_e7fd8d42>
  407d14:	jmp    407ce0 <__swc_fn_23cea7fa_000048_8e68f77b+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_23cea7fa_000048_8e68f77b+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_23cea7fa_000048_8e68f77b+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_23cea7fa_000048_8e68f77b+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_23cea7fa_000048_8e68f77b+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_23cea7fa_000048_8e68f77b+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_23cea7fa_000048_8e68f77b+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_23cea7fa_000048_8e68f77b+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_23cea7fa_000051_27d2a35f>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_23cea7fa_000051_27d2a35f+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_23cea7fa_000051_27d2a35f+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_23cea7fa_000051_27d2a35f+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_23cea7fa_000051_27d2a35f+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40e4f0 <__swc_fn_23cea7fa_000044_fe6bbfdb>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40e060 <__swc_fn_23cea7fa_000014_be17798c>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_23cea7fa_000054_e8e85c01>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   4098a0 <__swc_fn_23cea7fa_000135_db32cc57>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_23cea7fa_000054_e8e85c01+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_23cea7fa_000054_e8e85c01+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_23cea7fa_000054_e8e85c01+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_23cea7fa_000057_01c75a1d>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_23cea7fa_000060_6818d0d1>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_23cea7fa_000060_6818d0d1+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_23cea7fa_000039_9ae4348f>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_23cea7fa_000060_6818d0d1+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_23cea7fa_000063_db6d2425>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40af20 <__swc_fn_23cea7fa_000052_92b016ae>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_23cea7fa_000054_e8e85c01>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_23cea7fa_000063_db6d2425+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_23cea7fa_000063_db6d2425+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40b040 <__swc_fn_23cea7fa_000058_01964a17>
  407f7f:	mov    rcx,rsi
  407f82:	call   40ac80 <__swc_fn_23cea7fa_000049_f6a485a2>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_23cea7fa_000066_918d3875>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_23cea7fa_000066_918d3875+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1c049]        # 424070 <__swc_bss_base_23cea7fa+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1c04b]        # 424080 <__swc_bss_base_23cea7fa+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_23cea7fa_000066_918d3875+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_23cea7fa_000066_918d3875+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40a910 <__swc_fn_23cea7fa_000022_53fc00d2>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_23cea7fa_000066_918d3875+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_23cea7fa_000063_db6d2425>
  40808f:	jmp    408122 <__swc_fn_23cea7fa_000066_918d3875+0x192>
  408094:	lea    rax,[rip+0x19f65]        # 422000 <__swc_data_base_23cea7fa>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_23cea7fa_000066_918d3875+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_23cea7fa_000066_918d3875+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_23cea7fa_000066_918d3875+0x135>
  4080b8:	call   40a9e0 <__swc_fn_23cea7fa_000031_3c3e930e>
  4080bd:	mov    rcx,rax
  4080c0:	call   410520 <__swc_fn_23cea7fa_000128_8d8a7dd2>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_23cea7fa_000066_918d3875+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_23cea7fa_000066_918d3875+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_23cea7fa_000066_918d3875+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40e590 <__swc_fn_23cea7fa_000047_e7fd8d42>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_23cea7fa_000066_918d3875+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_23cea7fa_000051_27d2a35f>
  408115:	jmp    408122 <__swc_fn_23cea7fa_000066_918d3875+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40a550 <__swc_fn_23cea7fa_000010_0569f799>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_23cea7fa_000069_34b04ef2>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_23cea7fa_000036_290a131c>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_23cea7fa_000069_34b04ef2+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1c09a]        # 424240 <__swc_bss_base_23cea7fa+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_23cea7fa_000069_34b04ef2+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   4098a0 <__swc_fn_23cea7fa_000135_db32cc57>
  4081b5:	mov    rcx,rsi
  4081b8:	call   40ed60 <__swc_fn_23cea7fa_000068_f501e74b>
  4081bd:	mov    rcx,rsi
  4081c0:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_23cea7fa_000072_bf7b5562>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40eab0 <__swc_fn_23cea7fa_000065_0b20477c>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_23cea7fa_000075_41334281>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   40ed60 <__swc_fn_23cea7fa_000068_f501e74b>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_23cea7fa_000078_140918ec>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_23cea7fa_000078_140918ec+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_23cea7fa_000078_140918ec+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_23cea7fa_000081_f4f506c7>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_23cea7fa_000084_5ed30bd6>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_23cea7fa_000090_14cf59b2>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_23cea7fa_000084_5ed30bd6+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_23cea7fa_000084_5ed30bd6+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_23cea7fa_000084_5ed30bd6+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_23cea7fa_000084_5ed30bd6+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_23cea7fa_000090_14cf59b2>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_23cea7fa_000084_5ed30bd6+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_23cea7fa_000084_5ed30bd6+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_23cea7fa_000084_5ed30bd6+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_23cea7fa_000084_5ed30bd6+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_23cea7fa_000084_5ed30bd6+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_23cea7fa_000084_5ed30bd6+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_23cea7fa_000084_5ed30bd6+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_23cea7fa_000084_5ed30bd6+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_23cea7fa_000084_5ed30bd6+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_23cea7fa_000084_5ed30bd6+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40c020 <__swc_fn_23cea7fa_000082_ff7d1455>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_23cea7fa_000084_5ed30bd6+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_23cea7fa_000084_5ed30bd6+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_23cea7fa_000084_5ed30bd6+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40c020 <__swc_fn_23cea7fa_000082_ff7d1455>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_23cea7fa_000084_5ed30bd6+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_23cea7fa_000084_5ed30bd6>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_23cea7fa_000084_5ed30bd6+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_23cea7fa_000084_5ed30bd6+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_23cea7fa_000087_693f118e>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_23cea7fa_000090_14cf59b2>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_23cea7fa_000087_693f118e+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   40f1c0 <__swc_fn_23cea7fa_000086_d9243de4>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_23cea7fa_000087_693f118e+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_23cea7fa_000087_693f118e+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_23cea7fa_000087_693f118e+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40c020 <__swc_fn_23cea7fa_000082_ff7d1455>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_23cea7fa_000087_693f118e+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_23cea7fa_000087_693f118e>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_23cea7fa_000087_693f118e+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_23cea7fa_000087_693f118e+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_23cea7fa_000090_14cf59b2>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_23cea7fa_000090_14cf59b2+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_23cea7fa_000090_14cf59b2+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_23cea7fa_000090_14cf59b2+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_23cea7fa_000090_14cf59b2+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40c020 <__swc_fn_23cea7fa_000082_ff7d1455>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40c020 <__swc_fn_23cea7fa_000082_ff7d1455>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_23cea7fa_000090_14cf59b2+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_23cea7fa_000090_14cf59b2+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_23cea7fa_000090_14cf59b2+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_23cea7fa_000090_14cf59b2+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_23cea7fa_000090_14cf59b2>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_23cea7fa_000090_14cf59b2+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_23cea7fa_000090_14cf59b2+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_23cea7fa_000090_14cf59b2+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_23cea7fa_000090_14cf59b2+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_23cea7fa_000090_14cf59b2+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_23cea7fa_000090_14cf59b2+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_23cea7fa_000090_14cf59b2+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_23cea7fa_000090_14cf59b2+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_23cea7fa_000090_14cf59b2+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_23cea7fa_000090_14cf59b2+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_23cea7fa_000090_14cf59b2+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_23cea7fa_000090_14cf59b2+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_23cea7fa_000090_14cf59b2+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_23cea7fa_000090_14cf59b2+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_23cea7fa_000090_14cf59b2+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_23cea7fa_000090_14cf59b2+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   409db0 <__swc_fn_23cea7fa_000147_e7bfe29e>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_23cea7fa_000090_14cf59b2+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_23cea7fa_000090_14cf59b2>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_23cea7fa_000090_14cf59b2+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_23cea7fa_000090_14cf59b2+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_23cea7fa_000090_14cf59b2+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   409db0 <__swc_fn_23cea7fa_000147_e7bfe29e>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   409db0 <__swc_fn_23cea7fa_000147_e7bfe29e>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_23cea7fa_000093_0c97fc6c>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40c150 <__swc_fn_23cea7fa_000091_f21926ed>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_23cea7fa_000093_0c97fc6c+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_23cea7fa_000093_0c97fc6c+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   4106c0 <__swc_fn_23cea7fa_000137_2d595cc7>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_23cea7fa_000093_0c97fc6c+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0xa872]        # 4131c0 <__swc_rdata_base_23cea7fa+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   4101f0 <__swc_fn_23cea7fa_000116_3f5cfdef>
  408959:	call   40c9d0 <__swc_fn_23cea7fa_000118_591530fe>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_23cea7fa_000096_a4baaa40>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40896f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  408975:	vzeroupper
  408978:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40897e:	mov    QWORD PTR [rsp+0x48],rdx
  408983:	mov    rax,r8
  408986:	cmp    r8,0x1
  40898a:	mov    edx,0x1
  40898f:	cmovb  rax,rdx
  408993:	mov    QWORD PTR [rsp+0x50],rax
  408998:	mov    rbx,QWORD PTR [rcx+0x8]
  40899c:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a0:	mov    rcx,QWORD PTR [rcx]
  4089a3:	lea    rdx,[rsp+0x8]
  4089a8:	call   rbx
  4089aa:	add    rsp,0x70
  4089ae:	pop    rbx
  4089af:	ret

00000000004089b0 <__swc_fn_23cea7fa_000099_5232b57d>:
  4089b0:	push   rbx
  4089b1:	push   rsi
  4089b2:	push   rdi
  4089b3:	sub    rsp,0x30
  4089b7:	mov    rbx,rcx
  4089ba:	test   rcx,rcx
  4089bd:	je     4089d2 <__swc_fn_23cea7fa_000099_5232b57d+0x22>
  4089bf:	mov    rcx,rbx
  4089c2:	mov    edx,0x1
  4089c7:	call   408200 <__swc_fn_23cea7fa_000078_140918ec>
  4089cc:	cmp    rax,0x1
  4089d0:	je     4089da <__swc_fn_23cea7fa_000099_5232b57d+0x2a>
  4089d2:	add    rsp,0x30
  4089d6:	pop    rdi
  4089d7:	pop    rsi
  4089d8:	pop    rbx
  4089d9:	ret
  4089da:	lea    rsi,[rsp+0x8]
  4089df:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089e4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089ea:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  4089ef:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4089f5:	mov    rax,QWORD PTR [rsp+0x20]
  4089fa:	test   rax,rax
  4089fd:	je     408a13 <__swc_fn_23cea7fa_000099_5232b57d+0x63>
  4089ff:	test   DWORD PTR [rax+0x28],0x400000
  408a06:	je     408a13 <__swc_fn_23cea7fa_000099_5232b57d+0x63>
  408a08:	mov    rcx,QWORD PTR [rax+0x30]
  408a0c:	test   rcx,rcx
  408a0f:	cmovne rax,rcx
  408a13:	mov    edi,DWORD PTR [rax+0x20]
  408a16:	lea    rcx,[rsp+0x18]
  408a1b:	call   40c330 <__swc_fn_23cea7fa_000100_5714513e>
  408a20:	mov    rcx,rsi
  408a23:	mov    rdx,QWORD PTR [rsp+0x18]
  408a28:	mov    r8,rdi
  408a2b:	call   408960 <__swc_fn_23cea7fa_000096_a4baaa40>
  408a30:	mov    rcx,QWORD PTR [rbx+0x28]
  408a34:	call   40f7a0 <__swc_fn_23cea7fa_000098_f82a1ed3>
  408a39:	mov    rcx,rsi
  408a3c:	mov    rdx,rbx
  408a3f:	mov    r8d,0x30
  408a45:	call   408960 <__swc_fn_23cea7fa_000096_a4baaa40>
  408a4a:	add    rsp,0x30
  408a4e:	pop    rdi
  408a4f:	pop    rsi
  408a50:	pop    rbx
  408a51:	ret
	...

0000000000408a60 <__swc_fn_23cea7fa_000102_14986ec5>:
  408a60:	push   rbp
  408a61:	push   rbx
  408a62:	push   rsi
  408a63:	push   rdi
  408a64:	push   r12
  408a66:	push   r13
  408a68:	push   r14
  408a6a:	push   r15
  408a6c:	sub    rsp,0x500
  408a73:	mov    rbp,rsp
  408a76:	mov    rbx,rsp
  408a79:	mov    rsi,rdx
  408a7c:	mov    rdi,rcx
  408a7f:	mov    rcx,QWORD PTR [rip+0x1e2ba]        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  408a86:	test   rcx,rcx
  408a89:	jne    408aa3 <__swc_fn_23cea7fa_000102_14986ec5+0x43>
  408a8b:	sub    rsp,0x8
  408a8f:	call   40a1a0 <__swc_fn_23cea7fa_000165_56054fe7>
  408a94:	add    rsp,0x8
  408a98:	lea    rcx,[rax+0x1]
  408a9c:	mov    QWORD PTR [rip+0x1e29d],rcx        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  408aa3:	dec    rcx
  408aa6:	sub    rsp,0x8
  408aaa:	call   411fa0 <__swc_fn_23cea7fa_000167_39c041ad>
  408aaf:	add    rsp,0x8
  408ab3:	mov    r12,rax
  408ab6:	mov    QWORD PTR [rsp+0x4f0],rax
  408abe:	lea    rax,[rip+0xa83b]        # 413300 <__swc_rdata_base_23cea7fa+0x1f0>
  408ac5:	sub    rsp,0x20
  408ac9:	mov    rcx,rsp
  408acc:	mov    QWORD PTR [rcx],rax
  408acf:	lea    r13,[rip+0xa83a]        # 413310 <__swc_rdata_base_23cea7fa+0x200>
  408ad6:	mov    QWORD PTR [rcx+0x8],r13
  408ada:	mov    QWORD PTR [rcx+0x10],rsp
  408ade:	mov    QWORD PTR [rcx+0x18],0x1
  408ae6:	lea    rcx,[rsp+0x10]
  408aeb:	sub    rsp,0x8
  408aef:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  408af4:	add    rsp,0x8
  408af8:	add    rsp,0x20
  408afc:	lea    rax,[rip+0xa855]        # 413358 <__swc_rdata_base_23cea7fa+0x248>
  408b03:	sub    rsp,0x20
  408b07:	mov    rcx,rsp
  408b0a:	mov    QWORD PTR [rcx],rax
  408b0d:	mov    QWORD PTR [rcx+0x8],r13
  408b11:	mov    QWORD PTR [rcx+0x10],rsp
  408b15:	mov    QWORD PTR [rcx+0x18],0x1
  408b1d:	lea    rcx,[rsp+0x10]
  408b22:	sub    rsp,0x8
  408b26:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  408b2b:	add    rsp,0x8
  408b2f:	add    rsp,0x20
  408b33:	lea    r14,[rip+0xa82e]        # 413368 <__swc_rdata_base_23cea7fa+0x258>
  408b3a:	sub    rsp,0x50
  408b3e:	mov    rax,rsp
  408b41:	vmovups xmm0,XMMWORD PTR [rip+0xa957]        # 4134a0 <__swc_rdata_base_23cea7fa+0x390>
  408b49:	vmovups XMMWORD PTR [rax],xmm0
  408b4d:	mov    QWORD PTR [rax+0x10],rsp
  408b51:	mov    QWORD PTR [rax+0x18],r13
  408b55:	mov    QWORD PTR [rax+0x20],rdi
  408b59:	lea    rdi,[rip+0xa818]        # 413378 <__swc_rdata_base_23cea7fa+0x268>
  408b60:	mov    QWORD PTR [rax+0x28],rdi
  408b64:	mov    QWORD PTR [rax+0x30],r14
  408b68:	mov    QWORD PTR [rax+0x38],r13
  408b6c:	lea    rcx,[rsp+0x10]
  408b71:	mov    QWORD PTR [rax+0x40],rcx
  408b75:	mov    QWORD PTR [rax+0x48],0x3
  408b7d:	lea    rcx,[rsp+0x40]
  408b82:	sub    rsp,0x8
  408b86:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  408b8b:	add    rsp,0x8
  408b8f:	add    rsp,0x50
  408b93:	lea    rax,[rip+0xa826]        # 4133c0 <__swc_rdata_base_23cea7fa+0x2b0>
  408b9a:	sub    rsp,0x20
  408b9e:	mov    rcx,rsp
  408ba1:	mov    QWORD PTR [rcx],rax
  408ba4:	mov    QWORD PTR [rcx+0x8],r13
  408ba8:	mov    QWORD PTR [rcx+0x10],rsp
  408bac:	mov    QWORD PTR [rcx+0x18],0x1
  408bb4:	lea    rcx,[rsp+0x10]
  408bb9:	sub    rsp,0x8
  408bbd:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  408bc2:	add    rsp,0x8
  408bc6:	add    rsp,0x20
  408bca:	mov    eax,DWORD PTR [rsi+0x20]
  408bcd:	mov    ecx,DWORD PTR [rsi+0x24]
  408bd0:	sub    rsp,0xa0
  408bd7:	mov    rdx,rsp
  408bda:	mov    QWORD PTR [rdx+0x30],rsi
  408bde:	mov    QWORD PTR [rdx+0x38],rdi
  408be2:	vmovups xmm0,XMMWORD PTR [rip+0xa84e]        # 413438 <__swc_rdata_base_23cea7fa+0x328>
  408bea:	vmovups XMMWORD PTR [rdx],xmm0
  408bee:	mov    QWORD PTR [rdx+0x40],rsp
  408bf2:	mov    QWORD PTR [rdx+0x48],r13
  408bf6:	mov    DWORD PTR [rdx+0x10],eax
  408bf9:	lea    rax,[rsp+0x10]
  408bfe:	mov    QWORD PTR [rdx+0x50],rax
  408c02:	lea    rax,[rip+0xa7c7]        # 4133d0 <__swc_rdata_base_23cea7fa+0x2c0>
  408c09:	mov    QWORD PTR [rdx+0x58],rax
  408c0d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c12:	lea    r8,[rsp+0x18]
  408c17:	mov    QWORD PTR [rdx+0x60],r8
  408c1b:	mov    QWORD PTR [rdx+0x68],r13
  408c1f:	mov    DWORD PTR [rdx+0x28],ecx
  408c22:	lea    rcx,[rdx+0x28]
  408c26:	mov    QWORD PTR [rdx+0x70],rcx
  408c2a:	mov    QWORD PTR [rdx+0x78],rax
  408c2e:	mov    QWORD PTR [rdx+0x80],r14
  408c35:	mov    QWORD PTR [rdx+0x88],r13
  408c3c:	lea    rax,[rdx+0x30]
  408c40:	mov    QWORD PTR [rdx+0x90],rax
  408c47:	mov    QWORD PTR [rdx+0x98],0x6
  408c52:	lea    rcx,[rdx+0x90]
  408c59:	sub    rsp,0x8
  408c5d:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  408c62:	add    rsp,0x8
  408c66:	add    rsp,0xa0
  408c6d:	sub    rsp,0x20
  408c71:	mov    rax,rsp
  408c74:	mov    QWORD PTR [rax],r14
  408c77:	mov    QWORD PTR [rax+0x8],r13
  408c7b:	mov    QWORD PTR [rax+0x10],rsp
  408c7f:	mov    QWORD PTR [rax+0x18],0x1
  408c87:	lea    rcx,[rsp+0x10]
  408c8c:	sub    rsp,0x8
  408c90:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  408c95:	add    rsp,0x8
  408c99:	add    rsp,0x20
  408c9d:	mov    eax,DWORD PTR [r12+0x9ac]
  408ca5:	test   eax,eax
  408ca7:	je     408ee0 <__swc_fn_23cea7fa_000102_14986ec5+0x480>
  408cad:	lea    rax,[rip+0xa764]        # 413418 <__swc_rdata_base_23cea7fa+0x308>
  408cb4:	sub    rsp,0x20
  408cb8:	mov    rcx,rsp
  408cbb:	mov    QWORD PTR [rcx],rax
  408cbe:	mov    QWORD PTR [rcx+0x8],r13
  408cc2:	mov    QWORD PTR [rcx+0x10],rsp
  408cc6:	mov    QWORD PTR [rcx+0x18],0x1
  408cce:	lea    rcx,[rsp+0x10]
  408cd3:	sub    rsp,0x8
  408cd7:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  408cdc:	add    rsp,0x8
  408ce0:	add    rsp,0x20
  408ce4:	mov    eax,DWORD PTR [r12+0x9ac]
  408cec:	dec    eax
  408cee:	mov    esi,eax
  408cf0:	test   esi,esi
  408cf2:	jl     408eb0 <__swc_fn_23cea7fa_000102_14986ec5+0x450>
  408cf8:	jmp    408d04 <__swc_fn_23cea7fa_000102_14986ec5+0x2a4>
  408cfa:	nop    WORD PTR [rax+rax*1+0x0]
  408d00:	dec    esi
  408d02:	jmp    408cf0 <__swc_fn_23cea7fa_000102_14986ec5+0x290>
  408d04:	lea    rax,[rip+0xa71d]        # 413428 <__swc_rdata_base_23cea7fa+0x318>
  408d0b:	sub    rsp,0x20
  408d0f:	mov    rcx,rsp
  408d12:	mov    QWORD PTR [rcx],rax
  408d15:	mov    QWORD PTR [rcx+0x8],r13
  408d19:	mov    QWORD PTR [rcx+0x10],rsp
  408d1d:	mov    QWORD PTR [rcx+0x18],0x1
  408d25:	lea    rcx,[rsp+0x10]
  408d2a:	sub    rsp,0x8
  408d2e:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  408d33:	add    rsp,0x8
  408d37:	add    rsp,0x20
  408d3b:	movsxd rax,esi
  408d3e:	imul   r15,rax,0x30
  408d42:	add    r15,r12
  408d45:	add    r15,0xf8
  408d4c:	sub    rsp,0x20
  408d50:	mov    rax,rsp
  408d53:	mov    QWORD PTR [rax],r15
  408d56:	mov    QWORD PTR [rax+0x8],rdi
  408d5a:	mov    QWORD PTR [rax+0x10],rsp
  408d5e:	mov    QWORD PTR [rax+0x18],0x1
  408d66:	lea    rcx,[rsp+0x10]
  408d6b:	sub    rsp,0x8
  408d6f:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  408d74:	add    rsp,0x8
  408d78:	add    rsp,0x20
  408d7c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408d84:	lea    rsi,[rip+0xa6ad]        # 413438 <__swc_rdata_base_23cea7fa+0x328>
  408d8b:	sub    rsp,0x20
  408d8f:	mov    rax,rsp
  408d92:	mov    QWORD PTR [rax],rsi
  408d95:	mov    QWORD PTR [rax+0x8],r13
  408d99:	mov    QWORD PTR [rax+0x10],rsp
  408d9d:	mov    QWORD PTR [rax+0x18],0x1
  408da5:	lea    rcx,[rsp+0x10]
  408daa:	sub    rsp,0x8
  408dae:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  408db3:	add    rsp,0x8
  408db7:	add    rsp,0x20
  408dbb:	sub    rsp,0x30
  408dbf:	mov    rax,rsp
  408dc2:	mov    ecx,DWORD PTR [r15+0x20]
  408dc6:	mov    QWORD PTR [rax],rcx
  408dc9:	mov    QWORD PTR [rax+0x8],rsp
  408dcd:	lea    rdi,[rip+0xa674]        # 413448 <__swc_rdata_base_23cea7fa+0x338>
  408dd4:	mov    QWORD PTR [rax+0x10],rdi
  408dd8:	lea    rcx,[rsp+0x8]
  408ddd:	mov    QWORD PTR [rax+0x18],rcx
  408de1:	mov    QWORD PTR [rax+0x20],0x1
  408de9:	lea    rcx,[rsp+0x18]
  408dee:	sub    rsp,0x8
  408df2:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  408df7:	add    rsp,0x8
  408dfb:	add    rsp,0x30
  408dff:	sub    rsp,0x20
  408e03:	mov    rax,rsp
  408e06:	mov    QWORD PTR [rax],rsi
  408e09:	mov    QWORD PTR [rax+0x8],r13
  408e0d:	mov    QWORD PTR [rax+0x10],rsp
  408e11:	mov    QWORD PTR [rax+0x18],0x1
  408e19:	lea    rcx,[rsp+0x10]
  408e1e:	sub    rsp,0x8
  408e22:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  408e27:	add    rsp,0x8
  408e2b:	add    rsp,0x20
  408e2f:	sub    rsp,0x30
  408e33:	mov    rax,rsp
  408e36:	mov    ecx,DWORD PTR [r15+0x24]
  408e3a:	mov    QWORD PTR [rax],rcx
  408e3d:	mov    QWORD PTR [rax+0x8],rsp
  408e41:	mov    QWORD PTR [rax+0x10],rdi
  408e45:	lea    rcx,[rsp+0x8]
  408e4a:	mov    QWORD PTR [rax+0x18],rcx
  408e4e:	mov    QWORD PTR [rax+0x20],0x1
  408e56:	lea    rcx,[rsp+0x18]
  408e5b:	sub    rsp,0x8
  408e5f:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  408e64:	add    rsp,0x8
  408e68:	add    rsp,0x30
  408e6c:	sub    rsp,0x20
  408e70:	mov    rax,rsp
  408e73:	mov    QWORD PTR [rax],r14
  408e76:	mov    QWORD PTR [rax+0x8],r13
  408e7a:	mov    QWORD PTR [rax+0x10],rsp
  408e7e:	mov    QWORD PTR [rax+0x18],0x1
  408e86:	lea    rcx,[rsp+0x10]
  408e8b:	sub    rsp,0x8
  408e8f:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  408e94:	add    rsp,0x8
  408e98:	add    rsp,0x20
  408e9c:	lea    rdi,[rip+0xa4d5]        # 413378 <__swc_rdata_base_23cea7fa+0x268>
  408ea3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408eab:	jmp    408d00 <__swc_fn_23cea7fa_000102_14986ec5+0x2a0>
  408eb0:	sub    rsp,0x20
  408eb4:	mov    rax,rsp
  408eb7:	mov    QWORD PTR [rax],r14
  408eba:	mov    QWORD PTR [rax+0x8],r13
  408ebe:	mov    QWORD PTR [rax+0x10],rsp
  408ec2:	mov    QWORD PTR [rax+0x18],0x1
  408eca:	lea    rcx,[rsp+0x10]
  408ecf:	sub    rsp,0x8
  408ed3:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  408ed8:	add    rsp,0x8
  408edc:	add    rsp,0x20
  408ee0:	lea    rax,[rbx+0x28]
  408ee4:	mov    rcx,rax
  408ee7:	mov    QWORD PTR [rbx+0x28],0x0
  408eef:	mov    QWORD PTR [rbx+0x30],0x0
  408ef7:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408efc:	add    rcx,0x10
  408f00:	mov    edx,0x1f
  408f05:	cs nop WORD PTR [rax+rax*1+0x0]
  408f0f:	nop
  408f10:	vmovups XMMWORD PTR [rcx],xmm0
  408f14:	add    rcx,0x10
  408f18:	sub    rdx,0x1
  408f1c:	jne    408f10 <__swc_fn_23cea7fa_000102_14986ec5+0x4b0>
  408f1e:	lea    rsi,[rbx+0x228]
  408f25:	xor    ecx,ecx
  408f27:	cs nop WORD PTR [rax+rax*1+0x0]
  408f31:	cs nop WORD PTR [rax+rax*1+0x0]
  408f3b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f40:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f45:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f4a:	add    rcx,0x10
  408f4e:	cmp    rcx,0x200
  408f55:	jne    408f40 <__swc_fn_23cea7fa_000102_14986ec5+0x4e0>
  408f57:	mov    eax,DWORD PTR [r12+0xbc8]
  408f5f:	lea    rcx,[r12+0x9c8]
  408f67:	mov    QWORD PTR [rbx+0x428],rcx
  408f6e:	mov    QWORD PTR [rbx+0x430],rax
  408f75:	lea    rdi,[rbx+0x438]
  408f7c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408f84:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408f8c:	mov    eax,DWORD PTR [r12+0xbc8]
  408f94:	test   eax,eax
  408f96:	jne    408fe3 <__swc_fn_23cea7fa_000102_14986ec5+0x583>
  408f98:	lea    rax,[rbx+0x448]
  408f9f:	mov    QWORD PTR [rbx+0x448],rsi
  408fa6:	mov    QWORD PTR [rax+0x8],0x40
  408fae:	mov    ecx,0x1
  408fb3:	mov    rdx,rax
  408fb6:	sub    rsp,0x8
  408fba:	call   410300 <__swc_fn_23cea7fa_000119_2d9caf16>
  408fbf:	add    rsp,0x8
  408fc3:	mov    QWORD PTR [rbx+0x460],rsi
  408fca:	mov    ecx,eax
  408fcc:	mov    QWORD PTR [rbx+0x468],rcx
  408fd3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408fdb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fe3:	mov    rsi,QWORD PTR [rbx+0x438]
  408fea:	mov    rax,QWORD PTR [rbx+0x440]
  408ff1:	mov    r15,rax
  408ff4:	xor    r12d,r12d
  408ff7:	test   r15,r15
  408ffa:	je     4090b0 <__swc_fn_23cea7fa_000102_14986ec5+0x650>
  409000:	mov    rax,QWORD PTR [rsi+r12*8]
  409004:	test   rax,rax
  409007:	je     409026 <__swc_fn_23cea7fa_000102_14986ec5+0x5c6>
  409009:	lea    rcx,[rbx+0x4b8]
  409010:	mov    rdx,rax
  409013:	sub    rsp,0x8
  409017:	call   409f10 <__swc_fn_23cea7fa_000162_61e293bf>
  40901c:	add    rsp,0x8
  409020:	mov    al,BYTE PTR [rax]
  409022:	test   al,al
  409024:	jne    409032 <__swc_fn_23cea7fa_000102_14986ec5+0x5d2>
  409026:	add    r12,0x1
  40902a:	sub    r15,0x1
  40902e:	jne    409000 <__swc_fn_23cea7fa_000102_14986ec5+0x5a0>
  409030:	jmp    4090b0 <__swc_fn_23cea7fa_000102_14986ec5+0x650>
  409032:	lea    rax,[rip+0xa457]        # 413490 <__swc_rdata_base_23cea7fa+0x380>
  409039:	sub    rsp,0x20
  40903d:	mov    rcx,rsp
  409040:	mov    QWORD PTR [rcx],rax
  409043:	mov    QWORD PTR [rcx+0x8],r13
  409047:	mov    QWORD PTR [rcx+0x10],rsp
  40904b:	mov    QWORD PTR [rcx+0x18],0x1
  409053:	lea    rcx,[rsp+0x10]
  409058:	sub    rsp,0x8
  40905c:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  409061:	add    rsp,0x8
  409065:	add    rsp,0x20
  409069:	mov    rcx,rdi
  40906c:	xor    edx,edx
  40906e:	mov    al,0x1
  409070:	mov    r8,rax
  409073:	sub    rsp,0x8
  409077:	call   40d260 <__swc_fn_23cea7fa_000163_3a7aae74>
  40907c:	add    rsp,0x8
  409080:	sub    rsp,0x20
  409084:	mov    rax,rsp
  409087:	mov    QWORD PTR [rax],r14
  40908a:	mov    QWORD PTR [rax+0x8],r13
  40908e:	mov    QWORD PTR [rax+0x10],rsp
  409092:	mov    QWORD PTR [rax+0x18],0x1
  40909a:	lea    rcx,[rsp+0x10]
  40909f:	sub    rsp,0x8
  4090a3:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  4090a8:	add    rsp,0x8
  4090ac:	add    rsp,0x20
  4090b0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090b8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090c4:	add    rsp,0x500
  4090cb:	pop    r15
  4090cd:	pop    r14
  4090cf:	pop    r13
  4090d1:	pop    r12
  4090d3:	pop    rdi
  4090d4:	pop    rsi
  4090d5:	pop    rbx
  4090d6:	pop    rbp
  4090d7:	ret
	...

00000000004090e0 <__swc_fn_23cea7fa_000105_83487ba1>:
  4090e0:	sub    rsp,0x8
  4090e4:	test   r8,r8
  4090e7:	je     4090ee <__swc_fn_23cea7fa_000105_83487ba1+0xe>
  4090e9:	call   40fa30 <__swc_fn_23cea7fa_000104_04d1a8be>
  4090ee:	add    rsp,0x8
  4090f2:	ret
	...

0000000000409100 <__swc_fn_23cea7fa_000108_b8f4bd15>:
  409100:	push   rsi
  409101:	push   rdi
  409102:	push   r12
  409104:	push   r13
  409106:	sub    rsp,0xd8
  40910d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409113:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  409119:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40911f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  409125:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40912b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  409134:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40913d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  409146:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40914f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  409158:	xor    eax,eax
  40915a:	call   407010 <getpid@plt>
  40915f:	mov    rsi,rax
  409162:	lea    rdi,[rip+0x1dbdf]        # 426d48 <__swc_bss_base_23cea7fa+0x2d08>
  409169:	mov    r12,QWORD PTR [rdi]
  40916c:	test   r12,r12
  40916f:	je     40917d <__swc_fn_23cea7fa_000108_b8f4bd15+0x7d>
  409171:	cmp    DWORD PTR [r12+0x10],esi
  409176:	jne    40917d <__swc_fn_23cea7fa_000108_b8f4bd15+0x7d>
  409178:	mov    rax,r12
  40917b:	jmp    4091e0 <__swc_fn_23cea7fa_000108_b8f4bd15+0xe0>
  40917d:	mov    ecx,0x4
  409182:	mov    edx,0x18
  409187:	call   40fb10 <__swc_fn_23cea7fa_000107_c8d4a68e>
  40918c:	mov    rcx,rax
  40918f:	test   rax,rax
  409192:	jne    409198 <__swc_fn_23cea7fa_000108_b8f4bd15+0x98>
  409194:	xor    eax,eax
  409196:	jmp    4091e0 <__swc_fn_23cea7fa_000108_b8f4bd15+0xe0>
  409198:	mov    DWORD PTR [rcx+0x10],esi
  40919b:	mov    rax,r12
  40919e:	lock cmpxchg QWORD PTR [rdi],rcx
  4091a3:	mov    r13,rax
  4091a6:	cmp    rax,r12
  4091a9:	je     4091bf <__swc_fn_23cea7fa_000108_b8f4bd15+0xbf>
  4091ab:	mov    rdi,rcx
  4091ae:	mov    esi,0x18
  4091b3:	xor    eax,eax
  4091b5:	call   407020 <munmap@plt>
  4091ba:	mov    rax,r13
  4091bd:	jmp    4091e0 <__swc_fn_23cea7fa_000108_b8f4bd15+0xe0>
  4091bf:	test   r12,r12
  4091c2:	je     4091dd <__swc_fn_23cea7fa_000108_b8f4bd15+0xdd>
  4091c4:	mov    rdi,r12
  4091c7:	mov    esi,0x18
  4091cc:	xor    eax,eax
  4091ce:	mov    QWORD PTR [rsp+0x28],rcx
  4091d3:	call   407020 <munmap@plt>
  4091d8:	mov    rcx,QWORD PTR [rsp+0x28]
  4091dd:	mov    rax,rcx
  4091e0:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  4091e6:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  4091ec:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  4091f2:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  4091f8:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  4091fe:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409207:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  409210:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409219:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  409222:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40922b:	add    rsp,0xd8
  409232:	pop    r13
  409234:	pop    r12
  409236:	pop    rdi
  409237:	pop    rsi
  409238:	ret
  409239:	add    BYTE PTR [rax],al
  40923b:	add    BYTE PTR [rax],al
  40923d:	add    BYTE PTR [rax],al
	...

0000000000409240 <__swc_fn_23cea7fa_000111_f9e19033>:
  409240:	push   rbx
  409241:	push   r12
  409243:	push   rdi
  409244:	push   rsi
  409245:	sub    rsp,0xa8
  40924c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409252:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409258:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40925e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409264:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40926a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409270:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409276:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40927c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409285:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40928e:	mov    rbx,rdx
  409291:	mov    r12,rcx
  409294:	mov    rdi,rcx
  409297:	mov    rsi,rdx
  40929a:	mov    edx,0x3
  40929f:	xor    eax,eax
  4092a1:	call   407030 <mprotect@plt>
  4092a6:	test   eax,eax
  4092a8:	je     4092ae <__swc_fn_23cea7fa_000111_f9e19033+0x6e>
  4092aa:	xor    eax,eax
  4092ac:	jmp    4092c3 <__swc_fn_23cea7fa_000111_f9e19033+0x83>
  4092ae:	mov    rcx,r12
  4092b1:	mov    rdx,rbx
  4092b4:	mov    al,0x1
  4092b6:	mov    r8,rax
  4092b9:	call   410140 <__swc_fn_23cea7fa_000110_918d5a21>
  4092be:	mov    eax,0x1
  4092c3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4092c9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4092cf:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4092d5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4092db:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4092e1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4092e7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4092ed:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4092f3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4092fc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409305:	add    rsp,0xa8
  40930c:	pop    rsi
  40930d:	pop    rdi
  40930e:	pop    r12
  409310:	pop    rbx
  409311:	ret
	...

0000000000409320 <__swc_fn_23cea7fa_000114_cc486df9>:
  409320:	sub    rsp,0x8
  409324:	test   rcx,rcx
  409327:	jne    40932e <__swc_fn_23cea7fa_000114_cc486df9+0xe>
  409329:	add    rsp,0x8
  40932d:	ret
  40932e:	call   40c880 <__swc_fn_23cea7fa_000115_3f6af4b1>
  409333:	add    rsp,0x8
  409337:	ret
	...

0000000000409340 <__swc_fn_23cea7fa_000117_5aba1420>:
  409340:	push   rdi
  409341:	push   rsi
  409342:	sub    rsp,0xa8
  409349:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40934f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409355:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40935b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409361:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409367:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40936d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409373:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409379:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409382:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40938b:	xor    edi,edi
  40938d:	xor    eax,eax
  40938f:	call   407040 <exit@plt>
  409394:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40939a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4093a0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4093a6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4093ac:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4093b2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4093b8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4093be:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4093c4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4093cd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4093d6:	add    rsp,0xa8
  4093dd:	pop    rsi
  4093de:	pop    rdi
  4093df:	ret

00000000004093e0 <__swc_fn_23cea7fa_000120_1e032ef6>:
  4093e0:	push   rbx
  4093e1:	push   rsi
  4093e2:	push   rdi
  4093e3:	push   r12
  4093e5:	sub    rsp,0x18
  4093e9:	mov    rbx,r8
  4093ec:	mov    rsi,rcx
  4093ef:	mov    rdi,rdx
  4093f2:	mov    rcx,QWORD PTR [rip+0x1d947]        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  4093f9:	test   rcx,rcx
  4093fc:	jne    40940e <__swc_fn_23cea7fa_000120_1e032ef6+0x2e>
  4093fe:	call   40a1a0 <__swc_fn_23cea7fa_000165_56054fe7>
  409403:	lea    rcx,[rax+0x1]
  409407:	mov    QWORD PTR [rip+0x1d932],rcx        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  40940e:	dec    rcx
  409411:	call   411fa0 <__swc_fn_23cea7fa_000167_39c041ad>
  409416:	mov    r12,rax
  409419:	cmp    ebx,0x3
  40941c:	jne    40942f <__swc_fn_23cea7fa_000120_1e032ef6+0x4f>
  40941e:	mov    rax,QWORD PTR [r12+0xbd0]
  409426:	test   rax,rax
  409429:	jne    40956c <__swc_fn_23cea7fa_000120_1e032ef6+0x18c>
  40942f:	cmp    ebx,0x5
  409432:	jne    409456 <__swc_fn_23cea7fa_000120_1e032ef6+0x76>
  409434:	call   40c150 <__swc_fn_23cea7fa_000091_f21926ed>
  409439:	test   al,al
  40943b:	jne    409456 <__swc_fn_23cea7fa_000120_1e032ef6+0x76>
  40943d:	mov    rcx,rsi
  409440:	mov    rdx,rdi
  409443:	call   411f50 <__swc_fn_23cea7fa_000164_d25850aa>
  409448:	test   al,al
  40944a:	je     409456 <__swc_fn_23cea7fa_000120_1e032ef6+0x76>
  40944c:	add    rsp,0x18
  409450:	pop    r12
  409452:	pop    rdi
  409453:	pop    rsi
  409454:	pop    rbx
  409455:	ret
  409456:	call   40c150 <__swc_fn_23cea7fa_000091_f21926ed>
  40945b:	test   al,al
  40945d:	jne    4094cf <__swc_fn_23cea7fa_000120_1e032ef6+0xef>
  40945f:	vmovups xmm0,XMMWORD PTR [rsi]
  409463:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409469:	mov    rax,QWORD PTR [rsp+0x8]
  40946e:	test   rax,rax
  409471:	jne    4094c2 <__swc_fn_23cea7fa_000120_1e032ef6+0xe2>
  409473:	cmp    ebx,0x3
  409476:	je     409484 <__swc_fn_23cea7fa_000120_1e032ef6+0xa4>
  409478:	cmp    ebx,0x4
  40947b:	je     409494 <__swc_fn_23cea7fa_000120_1e032ef6+0xb4>
  40947d:	cmp    ebx,0x5
  409480:	je     4094a4 <__swc_fn_23cea7fa_000120_1e032ef6+0xc4>
  409482:	jmp    4094b4 <__swc_fn_23cea7fa_000120_1e032ef6+0xd4>
  409484:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 4134e0 <__swc_rdata_base_23cea7fa+0x3d0>
  40948c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409492:	jmp    4094c2 <__swc_fn_23cea7fa_000120_1e032ef6+0xe2>
  409494:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 4134f0 <__swc_rdata_base_23cea7fa+0x3e0>
  40949c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094a2:	jmp    4094c2 <__swc_fn_23cea7fa_000120_1e032ef6+0xe2>
  4094a4:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 413500 <__swc_rdata_base_23cea7fa+0x3f0>
  4094ac:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094b2:	jmp    4094c2 <__swc_fn_23cea7fa_000120_1e032ef6+0xe2>
  4094b4:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 413510 <__swc_rdata_base_23cea7fa+0x400>
  4094bc:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094c2:	lea    rcx,[rsp+0x8]
  4094c7:	mov    rdx,rdi
  4094ca:	call   40c3a0 <__swc_fn_23cea7fa_000103_0d4cc079>
  4094cf:	vmovups xmm0,XMMWORD PTR [rdi]
  4094d3:	vmovups XMMWORD PTR [r12+0x940],xmm0
  4094dd:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  4094e2:	vmovups XMMWORD PTR [r12+0x950],xmm0
  4094ec:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  4094f1:	vmovups XMMWORD PTR [r12+0x960],xmm0
  4094fb:	lea    rax,[r12+0x940]
  409503:	mov    QWORD PTR [r12+0x970],rax
  40950b:	mov    rax,QWORD PTR [rsi]
  40950e:	mov    QWORD PTR [r12+0x978],rax
  409516:	mov    rax,QWORD PTR [rsi+0x8]
  40951a:	mov    QWORD PTR [r12+0x980],rax
  409522:	movsxd rax,ebx
  409525:	mov    QWORD PTR [r12+0x988],rax
  40952d:	cmp    ebx,0x5
  409530:	je     409539 <__swc_fn_23cea7fa_000120_1e032ef6+0x159>
  409532:	xor    ecx,ecx
  409534:	call   40a2d0 <__swc_fn_23cea7fa_000174_02e645b4>
  409539:	mov    rbx,QWORD PTR [r12+0xbe8]
  409541:	test   rbx,rbx
  409544:	je     409555 <__swc_fn_23cea7fa_000120_1e032ef6+0x175>
  409546:	mov    rcx,r12
  409549:	call   rbx
  40954b:	add    rsp,0x18
  40954f:	pop    r12
  409551:	pop    rdi
  409552:	pop    rsi
  409553:	pop    rbx
  409554:	ret
  409555:	mov    rcx,rsi
  409558:	call   4101f0 <__swc_fn_23cea7fa_000116_3f5cfdef>
  40955d:	call   40c9d0 <__swc_fn_23cea7fa_000118_591530fe>
  409562:	add    rsp,0x18
  409566:	pop    r12
  409568:	pop    rdi
  409569:	pop    rsi
  40956a:	pop    rbx
  40956b:	ret
  40956c:	mov    rcx,rsi
  40956f:	mov    rdx,rdi
  409572:	call   40c3a0 <__swc_fn_23cea7fa_000103_0d4cc079>
  409577:	jmp    40942f <__swc_fn_23cea7fa_000120_1e032ef6+0x4f>
  40957c:	add    BYTE PTR [rax],al
	...

0000000000409580 <__swc_fn_23cea7fa_000123_e4107ade>:
  409580:	push   rdi
  409581:	push   rsi
  409582:	sub    rsp,0xb8
  409589:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40958f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409595:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40959b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4095a1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4095a7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4095ad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4095b3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4095bc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4095c5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4095ce:	mov    DWORD PTR [rsp+0x8],0x0
  4095d6:	lea    rdi,[rsp+0x8]
  4095db:	xor    esi,esi
  4095dd:	xor    eax,eax
  4095df:	call   407050 <pthread_key_create@plt>
  4095e4:	test   eax,eax
  4095e6:	jne    4095ee <__swc_fn_23cea7fa_000123_e4107ade+0x6e>
  4095e8:	mov    eax,DWORD PTR [rsp+0x8]
  4095ec:	jmp    4095f5 <__swc_fn_23cea7fa_000123_e4107ade+0x75>
  4095ee:	mov    rax,0xffffffffffffffff
  4095f5:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4095fb:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409601:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409607:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40960d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409613:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409619:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40961f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409628:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409631:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40963a:	add    rsp,0xb8
  409641:	pop    rsi
  409642:	pop    rdi
  409643:	ret
	...

0000000000409650 <__swc_fn_23cea7fa_000126_9e9697c7>:
  409650:	push   rdi
  409651:	push   rsi
  409652:	sub    rsp,0xb8
  409659:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40965f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409665:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40966b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409671:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409677:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40967d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409683:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40968c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409695:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40969e:	mov    DWORD PTR [rsp+0x8],0x0
  4096a6:	lea    rdi,[rsp+0x8]
  4096ab:	mov    rsi,rcx
  4096ae:	xor    eax,eax
  4096b0:	call   407050 <pthread_key_create@plt>
  4096b5:	test   eax,eax
  4096b7:	jne    4096c2 <__swc_fn_23cea7fa_000126_9e9697c7+0x72>
  4096b9:	mov    eax,DWORD PTR [rsp+0x8]
  4096bd:	inc    rax
  4096c0:	jmp    4096c4 <__swc_fn_23cea7fa_000126_9e9697c7+0x74>
  4096c2:	xor    eax,eax
  4096c4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4096ca:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4096d0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4096d6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4096dc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4096e2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4096e8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4096ee:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4096f7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409700:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409709:	add    rsp,0xb8
  409710:	pop    rsi
  409711:	pop    rdi
  409712:	ret
	...

0000000000409720 <__swc_fn_23cea7fa_000129_bc477461>:
  409720:	push   rdi
  409721:	push   rsi
  409722:	sub    rsp,0xa8
  409729:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40972f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409735:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40973b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409741:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409747:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40974d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409753:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409759:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409762:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40976b:	test   rcx,rcx
  40976e:	setne  al
  409771:	je     40978a <__swc_fn_23cea7fa_000129_bc477461+0x6a>
  409773:	lea    rax,[rcx-0x1]
  409777:	mov    eax,eax
  409779:	mov    edi,eax
  40977b:	mov    rsi,rdx
  40977e:	xor    eax,eax
  409780:	call   407060 <pthread_setspecific@plt>
  409785:	test   eax,eax
  409787:	sete   al
  40978a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409790:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409796:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40979c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4097a2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4097a8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4097ae:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4097b4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4097ba:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4097c3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4097cc:	add    rsp,0xa8
  4097d3:	pop    rsi
  4097d4:	pop    rdi
  4097d5:	ret
	...

00000000004097e0 <__swc_fn_23cea7fa_000132_51cc49e7>:
  4097e0:	push   rdi
  4097e1:	push   rsi
  4097e2:	sub    rsp,0xa8
  4097e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4097ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4097f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4097fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409801:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409807:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40980d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409813:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409819:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409822:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40982b:	mov    rax,rdx
  40982e:	mov    QWORD PTR [rsp],0x0
  409836:	mov    edi,0xca
  40983b:	mov    rsi,rcx
  40983e:	mov    edx,0x81
  409843:	mov    eax,eax
  409845:	mov    ecx,eax
  409847:	xor    r8d,r8d
  40984a:	xor    r9d,r9d
  40984d:	xor    eax,eax
  40984f:	call   407070 <syscall@plt>
  409854:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40985a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409860:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409866:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40986c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409872:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409878:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40987e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409884:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40988d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409896:	add    rsp,0xa8
  40989d:	pop    rsi
  40989e:	pop    rdi
  40989f:	ret

00000000004098a0 <__swc_fn_23cea7fa_000135_db32cc57>:
  4098a0:	sub    rsp,0x8
  4098a4:	call   40cd70 <__swc_fn_23cea7fa_000133_807fd51d>
  4098a9:	add    rsp,0x8
  4098ad:	ret
	...

00000000004098b0 <__swc_fn_23cea7fa_000138_22d6573c>:
  4098b0:	push   rdi
  4098b1:	push   rsi
  4098b2:	sub    rsp,0xc8
  4098b9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4098bf:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4098c5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4098cb:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4098d1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4098d7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4098dd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  4098e6:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  4098ef:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  4098f8:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  409901:	vxorps xmm0,xmm0,xmm0
  409905:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40990b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409911:	mov    rdi,rcx
  409914:	lea    rsi,[rsp+0x8]
  409919:	xor    eax,eax
  40991b:	call   407080 <dladdr@plt>
  409920:	xor    ecx,ecx
  409922:	test   eax,eax
  409924:	je     40992b <__swc_fn_23cea7fa_000138_22d6573c+0x7b>
  409926:	mov    rcx,QWORD PTR [rsp+0x10]
  40992b:	mov    rax,rcx
  40992e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  409934:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40993a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  409940:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  409946:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40994c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  409952:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40995b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  409964:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40996d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  409976:	add    rsp,0xc8
  40997d:	pop    rsi
  40997e:	pop    rdi
  40997f:	ret

0000000000409980 <__swc_fn_23cea7fa_000141_5e493395>:
  409980:	push   rbx
  409981:	push   r12
  409983:	push   r13
  409985:	push   rdi
  409986:	push   rsi
  409987:	push   r14
  409989:	push   r15
  40998b:	sub    rsp,0x150
  409992:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40999b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  4099a4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  4099ad:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  4099b6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  4099bf:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4099c8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4099d1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4099da:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  4099e3:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  4099ec:	mov    rbx,rdx
  4099ef:	mov    QWORD PTR [rsp+0x98],rdx
  4099f7:	mov    r12,rcx
  4099fa:	mov    QWORD PTR [rsp+0xa0],rcx
  409a02:	mov    QWORD PTR [rbx],0x0
  409a09:	lea    r13,[rip+0x1d370]        # 426d80 <__swc_bss_base_23cea7fa+0x2d40>
  409a10:	mov    rcx,r13
  409a13:	call   4098a0 <__swc_fn_23cea7fa_000135_db32cc57>
  409a18:	mov    rax,QWORD PTR [rip+0x1d369]        # 426d88 <__swc_bss_base_23cea7fa+0x2d48>
  409a1f:	test   rax,rax
  409a22:	je     409a59 <__swc_fn_23cea7fa_000141_5e493395+0xd9>
  409a24:	cs nop WORD PTR [rax+rax*1+0x0]
  409a2e:	xchg   ax,ax
  409a30:	cmp    QWORD PTR [rax+0x8],r12
  409a34:	jne    409a51 <__swc_fn_23cea7fa_000141_5e493395+0xd1>
  409a36:	mov    rcx,QWORD PTR [rax+0x18]
  409a3a:	mov    QWORD PTR [rbx],rcx
  409a3d:	mov    rbx,QWORD PTR [rax+0x10]
  409a41:	mov    rcx,r13
  409a44:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  409a49:	mov    rax,rbx
  409a4c:	jmp    409c3b <__swc_fn_23cea7fa_000141_5e493395+0x2bb>
  409a51:	mov    rax,QWORD PTR [rax]
  409a54:	test   rax,rax
  409a57:	jne    409a30 <__swc_fn_23cea7fa_000141_5e493395+0xb0>
  409a59:	vxorps xmm0,xmm0,xmm0
  409a5d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  409a63:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  409a69:	mov    rdi,r12
  409a6c:	lea    rsi,[rsp+0x10]
  409a71:	xor    eax,eax
  409a73:	call   407080 <dladdr@plt>
  409a78:	test   eax,eax
  409a7a:	sete   al
  409a7d:	je     409a8a <__swc_fn_23cea7fa_000141_5e493395+0x10a>
  409a7f:	mov    rax,QWORD PTR [rsp+0x10]
  409a84:	test   rax,rax
  409a87:	sete   al
  409a8a:	test   al,al
  409a8c:	je     409a9d <__swc_fn_23cea7fa_000141_5e493395+0x11d>
  409a8e:	mov    rcx,r13
  409a91:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  409a96:	xor    eax,eax
  409a98:	jmp    409c3b <__swc_fn_23cea7fa_000141_5e493395+0x2bb>
  409a9d:	mov    rdi,QWORD PTR [rsp+0x10]
  409aa2:	mov    esi,0x80000
  409aa7:	xor    eax,eax
  409aa9:	call   407090 <open@plt>
  409aae:	lea    r14,[rsp+0x30]
  409ab3:	mov    DWORD PTR [rsp+0x30],eax
  409ab7:	cmp    DWORD PTR [r14],0x0
  409abb:	jge    409acc <__swc_fn_23cea7fa_000141_5e493395+0x14c>
  409abd:	mov    rcx,r13
  409ac0:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  409ac5:	xor    eax,eax
  409ac7:	jmp    409c3b <__swc_fn_23cea7fa_000141_5e493395+0x2bb>
  409acc:	mov    rax,r14
  409acf:	movsxd rdi,DWORD PTR [rax]
  409ad2:	xor    esi,esi
  409ad4:	mov    edx,0x2
  409ad9:	xor    eax,eax
  409adb:	call   4070a0 <lseek@plt>
  409ae0:	mov    r15,rax
  409ae3:	test   rax,rax
  409ae6:	jg     409b01 <__swc_fn_23cea7fa_000141_5e493395+0x181>
  409ae8:	movsxd rdi,DWORD PTR [r14]
  409aeb:	xor    eax,eax
  409aed:	call   4070b0 <close@plt>
  409af2:	mov    rcx,r13
  409af5:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  409afa:	xor    eax,eax
  409afc:	jmp    409c3b <__swc_fn_23cea7fa_000141_5e493395+0x2bb>
  409b01:	xor    edi,edi
  409b03:	mov    rsi,r15
  409b06:	mov    edx,0x1
  409b0b:	mov    ecx,0x2
  409b10:	mov    rax,r14
  409b13:	movsxd r8,DWORD PTR [rax]
  409b16:	xor    r9d,r9d
  409b19:	xor    eax,eax
  409b1b:	call   4070c0 <mmap@plt>
  409b20:	mov    rbx,rax
  409b23:	test   rax,rax
  409b26:	sete   al
  409b29:	cmp    rbx,0xffffffffffffffff
  409b2d:	sete   cl
  409b30:	or     al,cl
  409b32:	je     409b4d <__swc_fn_23cea7fa_000141_5e493395+0x1cd>
  409b34:	movsxd rdi,DWORD PTR [r14]
  409b37:	xor    eax,eax
  409b39:	call   4070b0 <close@plt>
  409b3e:	mov    rcx,r13
  409b41:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  409b46:	xor    eax,eax
  409b48:	jmp    409c3b <__swc_fn_23cea7fa_000141_5e493395+0x2bb>
  409b4d:	lea    rax,[rsp+0x50]
  409b52:	mov    QWORD PTR [rax],0x0
  409b59:	mov    rcx,rbx
  409b5c:	mov    rdx,r15
  409b5f:	mov    r8,rax
  409b62:	call   410780 <__swc_fn_23cea7fa_000140_55003b6d>
  409b67:	mov    r12,rax
  409b6a:	test   rax,rax
  409b6d:	jne    409b95 <__swc_fn_23cea7fa_000141_5e493395+0x215>
  409b6f:	mov    rdi,rbx
  409b72:	mov    rsi,r15
  409b75:	xor    eax,eax
  409b77:	call   407020 <munmap@plt>
  409b7c:	movsxd rdi,DWORD PTR [r14]
  409b7f:	xor    eax,eax
  409b81:	call   4070b0 <close@plt>
  409b86:	mov    rcx,r13
  409b89:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  409b8e:	xor    eax,eax
  409b90:	jmp    409c3b <__swc_fn_23cea7fa_000141_5e493395+0x2bb>
  409b95:	mov    edi,0x20
  409b9a:	xor    eax,eax
  409b9c:	call   4070d0 <malloc@plt>
  409ba1:	test   rax,rax
  409ba4:	jne    409bc9 <__swc_fn_23cea7fa_000141_5e493395+0x249>
  409ba6:	mov    rdi,rbx
  409ba9:	mov    rsi,r15
  409bac:	xor    eax,eax
  409bae:	call   407020 <munmap@plt>
  409bb3:	movsxd rdi,DWORD PTR [r14]
  409bb6:	xor    eax,eax
  409bb8:	call   4070b0 <close@plt>
  409bbd:	mov    rcx,r13
  409bc0:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  409bc5:	xor    eax,eax
  409bc7:	jmp    409c3b <__swc_fn_23cea7fa_000141_5e493395+0x2bb>
  409bc9:	mov    rcx,QWORD PTR [rip+0x1d1b8]        # 426d88 <__swc_bss_base_23cea7fa+0x2d48>
  409bd0:	mov    QWORD PTR [rsp+0x70],rcx
  409bd5:	mov    rcx,QWORD PTR [rsp+0xa0]
  409bdd:	mov    QWORD PTR [rsp+0x78],rcx
  409be2:	mov    QWORD PTR [rsp+0x80],r12
  409bea:	mov    rcx,QWORD PTR [rsp+0x50]
  409bef:	mov    QWORD PTR [rsp+0x88],rcx
  409bf7:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  409bfd:	vmovups XMMWORD PTR [rax],xmm0
  409c01:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  409c0a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  409c0f:	mov    QWORD PTR [rip+0x1d172],rax        # 426d88 <__swc_bss_base_23cea7fa+0x2d48>
  409c16:	mov    rax,QWORD PTR [rsp+0x50]
  409c1b:	mov    rbx,QWORD PTR [rsp+0x98]
  409c23:	mov    QWORD PTR [rbx],rax
  409c26:	movsxd rdi,DWORD PTR [r14]
  409c29:	xor    eax,eax
  409c2b:	call   4070b0 <close@plt>
  409c30:	mov    rcx,r13
  409c33:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  409c38:	mov    rax,r12
  409c3b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  409c44:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  409c4d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  409c56:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  409c5f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  409c68:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  409c71:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  409c7a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  409c83:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  409c8c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  409c95:	add    rsp,0x150
  409c9c:	pop    r15
  409c9e:	pop    r14
  409ca0:	pop    rsi
  409ca1:	pop    rdi
  409ca2:	pop    r13
  409ca4:	pop    r12
  409ca6:	pop    rbx
  409ca7:	ret
	...

0000000000409cb0 <__swc_fn_23cea7fa_000144_c3e86ca0>:
  409cb0:	push   rbx
  409cb1:	sub    rsp,0xe0
  409cb8:	lea    rbx,[rsp+0x8]
  409cbd:	vxorps xmm0,xmm0,xmm0
  409cc1:	vmovups YMMWORD PTR [rbx],ymm0
  409cc5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  409cca:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  409ccf:	vzeroupper
  409cd2:	mov    DWORD PTR [rbx+0x60],0x0
  409cd9:	mov    r8,rbx
  409cdc:	nop    DWORD PTR [rax+0x0]
  409ce0:	mov    r9,rcx
  409ce3:	movabs rcx,0xcccccccccccccccd
  409ced:	mov    rax,r9
  409cf0:	mul    rcx
  409cf3:	mov    r10,rdx
  409cf6:	shr    r10,0x3
  409cfa:	mov    rcx,r10
  409cfd:	imul   rdx,r10,0xa
  409d01:	sub    r9,rdx
  409d04:	mov    rdx,QWORD PTR [rip+0x9835]        # 413540 <__swc_rdata_base_23cea7fa+0x430>
  409d0b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  409d10:	mov    BYTE PTR [r8],dl
  409d13:	lea    rdx,[r8+0x1]
  409d17:	mov    r8,rdx
  409d1a:	test   r10,r10
  409d1d:	jne    409ce0 <__swc_fn_23cea7fa_000144_c3e86ca0+0x30>
  409d1f:	mov    BYTE PTR [rdx],0x0
  409d22:	sub    r8,0x1
  409d26:	mov    rax,rbx
  409d29:	cmp    rax,r8
  409d2c:	jae    409d46 <__swc_fn_23cea7fa_000144_c3e86ca0+0x96>
  409d2e:	xchg   ax,ax
  409d30:	mov    cl,BYTE PTR [r8]
  409d33:	mov    dl,BYTE PTR [rax]
  409d35:	mov    BYTE PTR [r8],dl
  409d38:	sub    r8,0x1
  409d3c:	mov    BYTE PTR [rax],cl
  409d3e:	inc    rax
  409d41:	cmp    rax,r8
  409d44:	jb     409d30 <__swc_fn_23cea7fa_000144_c3e86ca0+0x80>
  409d46:	xor    eax,eax
  409d48:	test   rbx,rbx
  409d4b:	je     409d6e <__swc_fn_23cea7fa_000144_c3e86ca0+0xbe>
  409d4d:	mov    rcx,rbx
  409d50:	mov    dl,BYTE PTR [rcx]
  409d52:	test   dl,dl
  409d54:	je     409d6e <__swc_fn_23cea7fa_000144_c3e86ca0+0xbe>
  409d56:	cs nop WORD PTR [rax+rax*1+0x0]
  409d60:	add    rcx,0x1
  409d64:	add    rax,0x1
  409d68:	mov    dl,BYTE PTR [rcx]
  409d6a:	test   dl,dl
  409d6c:	jne    409d60 <__swc_fn_23cea7fa_000144_c3e86ca0+0xb0>
  409d6e:	mov    QWORD PTR [rbx+0xa8],rbx
  409d75:	mov    QWORD PTR [rbx+0xb0],rax
  409d7c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  409d84:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  409d8c:	lea    rcx,[rbx+0xb8]
  409d93:	call   4101f0 <__swc_fn_23cea7fa_000116_3f5cfdef>
  409d98:	add    rsp,0xe0
  409d9f:	pop    rbx
  409da0:	ret
	...

0000000000409db0 <__swc_fn_23cea7fa_000147_e7bfe29e>:
  409db0:	sub    rsp,0x8
  409db4:	mov    rax,QWORD PTR [rcx+0x8]
  409db8:	mov    r8,QWORD PTR [rdx+0x8]
  409dbc:	cmp    rax,r8
  409dbf:	je     409dc8 <__swc_fn_23cea7fa_000147_e7bfe29e+0x18>
  409dc1:	xor    eax,eax
  409dc3:	add    rsp,0x8
  409dc7:	ret
  409dc8:	test   rax,rax
  409dcb:	jne    409ddc <__swc_fn_23cea7fa_000147_e7bfe29e+0x2c>
  409dcd:	test   r8,r8
  409dd0:	jne    409ddc <__swc_fn_23cea7fa_000147_e7bfe29e+0x2c>
  409dd2:	mov    eax,0x1
  409dd7:	add    rsp,0x8
  409ddb:	ret
  409ddc:	mov    rcx,QWORD PTR [rcx]
  409ddf:	mov    rdx,QWORD PTR [rdx]
  409de2:	test   rcx,rcx
  409de5:	sete   r8b
  409de9:	test   rdx,rdx
  409dec:	sete   r9b
  409df0:	or     r8b,r9b
  409df3:	je     409e00 <__swc_fn_23cea7fa_000147_e7bfe29e+0x50>
  409df5:	cmp    rcx,rdx
  409df8:	sete   al
  409dfb:	add    rsp,0x8
  409dff:	ret
  409e00:	cmp    rcx,rdx
  409e03:	jne    409e0f <__swc_fn_23cea7fa_000147_e7bfe29e+0x5f>
  409e05:	mov    eax,0x1
  409e0a:	add    rsp,0x8
  409e0e:	ret
  409e0f:	mov    r8,rax
  409e12:	call   40c460 <__swc_fn_23cea7fa_000106_aba05410>
  409e17:	test   eax,eax
  409e19:	sete   al
  409e1c:	add    rsp,0x8
  409e20:	ret
	...

0000000000409e30 <__swc_fn_23cea7fa_000150_365b4daf>:
  409e30:	vxorps xmm0,xmm0,xmm0
  409e34:	vmovups XMMWORD PTR [rcx],xmm0
  409e38:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e3d:	vxorps xmm0,xmm0,xmm0
  409e41:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e46:	vmovups xmm0,XMMWORD PTR [rip+0x97aa]        # 4135f8 <__swc_rdata_base_23cea7fa+0x4e8>
  409e4e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e53:	ret
	...

0000000000409e60 <__swc_fn_23cea7fa_000153_365b4daf>:
  409e60:	vxorps xmm0,xmm0,xmm0
  409e64:	vmovups XMMWORD PTR [rcx],xmm0
  409e68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e6d:	vxorps xmm0,xmm0,xmm0
  409e71:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e76:	vmovups xmm0,XMMWORD PTR [rip+0x989a]        # 413718 <__swc_rdata_base_23cea7fa+0x608>
  409e7e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e83:	mov    QWORD PTR [rcx+0x40],0x0
  409e8b:	ret
  409e8c:	add    BYTE PTR [rax],al
	...

0000000000409e90 <__swc_fn_23cea7fa_000156_9e2052d6>:
  409e90:	push   rbx
  409e91:	sub    rsp,0x70
  409e95:	mov    rax,QWORD PTR [rcx]
  409e98:	mov    rbx,QWORD PTR [rcx+0x8]
  409e9c:	vxorps xmm0,xmm0,xmm0
  409ea0:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  409ea6:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  409eac:	vzeroupper
  409eaf:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  409eb5:	mov    QWORD PTR [rsp+0x48],rdx
  409eba:	mov    QWORD PTR [rsp+0x50],r8
  409ebf:	mov    rcx,rax
  409ec2:	lea    rdx,[rsp+0x8]
  409ec7:	mov    rbx,QWORD PTR [rbx+0x18]
  409ecb:	call   rbx
  409ecd:	add    rsp,0x70
  409ed1:	pop    rbx
  409ed2:	ret
	...

0000000000409ee0 <__swc_fn_23cea7fa_000159_6861d596>:
  409ee0:	push   rbx
  409ee1:	push   rsi
  409ee2:	push   rdi
  409ee3:	mov    rbx,r8
  409ee6:	mov    rsi,rcx
  409ee9:	mov    rdi,rdx
  409eec:	call   40d170 <__swc_fn_23cea7fa_000157_3495a3ca>
  409ef1:	vmovups xmm0,XMMWORD PTR [rbx]
  409ef5:	vmovups XMMWORD PTR [rsi],xmm0
  409ef9:	mov    QWORD PTR [rsi+0x18],rdi
  409efd:	pop    rdi
  409efe:	pop    rsi
  409eff:	pop    rbx
  409f00:	ret
	...

0000000000409f10 <__swc_fn_23cea7fa_000162_61e293bf>:
  409f10:	push   rbx
  409f11:	push   rsi
  409f12:	push   rdi
  409f13:	push   r12
  409f15:	push   r13
  409f17:	sub    rsp,0x50
  409f1b:	mov    rbx,rcx
  409f1e:	mov    rsi,rdx
  409f21:	vmovups xmm0,XMMWORD PTR [rip+0x98ff]        # 413828 <__swc_rdata_base_23cea7fa+0x718>
  409f29:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409f2f:	vmovups xmm0,XMMWORD PTR [rip+0x9901]        # 413838 <__swc_rdata_base_23cea7fa+0x728>
  409f37:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409f3d:	vxorps xmm0,xmm0,xmm0
  409f41:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409f47:	mov    rcx,rdx
  409f4a:	call   4098b0 <__swc_fn_23cea7fa_000138_22d6573c>
  409f4f:	mov    rdi,rax
  409f52:	test   rax,rax
  409f55:	jne    409f86 <__swc_fn_23cea7fa_000162_61e293bf+0x76>
  409f57:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409f5d:	vmovups XMMWORD PTR [rbx],xmm0
  409f61:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409f67:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409f6c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409f72:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409f77:	mov    rax,rbx
  409f7a:	add    rsp,0x50
  409f7e:	pop    r13
  409f80:	pop    r12
  409f82:	pop    rdi
  409f83:	pop    rsi
  409f84:	pop    rbx
  409f85:	ret
  409f86:	mov    rcx,rdi
  409f89:	call   411ca0 <__swc_fn_23cea7fa_000161_b553c03d>
  409f8e:	mov    r11,rax
  409f91:	test   rax,rax
  409f94:	je     409f9e <__swc_fn_23cea7fa_000162_61e293bf+0x8e>
  409f96:	mov    al,BYTE PTR [r11+0x24]
  409f9a:	test   al,al
  409f9c:	jne    409fcd <__swc_fn_23cea7fa_000162_61e293bf+0xbd>
  409f9e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fa4:	vmovups XMMWORD PTR [rbx],xmm0
  409fa8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fae:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fb3:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fb9:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fbe:	mov    rax,rbx
  409fc1:	add    rsp,0x50
  409fc5:	pop    r13
  409fc7:	pop    r12
  409fc9:	pop    rdi
  409fca:	pop    rsi
  409fcb:	pop    rbx
  409fcc:	ret
  409fcd:	sub    rsi,rdi
  409fd0:	mov    eax,0xffffffff
  409fd5:	cmp    rsi,rax
  409fd8:	jbe    40a009 <__swc_fn_23cea7fa_000162_61e293bf+0xf9>
  409fda:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fe0:	vmovups XMMWORD PTR [rbx],xmm0
  409fe4:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fea:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fef:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409ff5:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409ffa:	mov    rax,rbx
  409ffd:	add    rsp,0x50
  40a001:	pop    r13
  40a003:	pop    r12
  40a005:	pop    rdi
  40a006:	pop    rsi
  40a007:	pop    rbx
  40a008:	ret
  40a009:	mov    rdi,QWORD PTR [r11+0x10]
  40a00d:	mov    eax,DWORD PTR [r11+0x20]
  40a011:	xor    ecx,ecx
  40a013:	test   rax,rax
  40a016:	jbe    40a168 <__swc_fn_23cea7fa_000162_61e293bf+0x258>
  40a01c:	nop    DWORD PTR [rax+0x0]
  40a020:	mov    edx,ecx
  40a022:	imul   r12,rdx,0x14
  40a026:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40a02b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40a030:	mov    r9d,esi
  40a033:	cmp    r9,rdx
  40a036:	jb     40a15b <__swc_fn_23cea7fa_000162_61e293bf+0x24b>
  40a03c:	add    rdx,r8
  40a03f:	mov    r8d,esi
  40a042:	cmp    r8,rdx
  40a045:	jae    40a15b <__swc_fn_23cea7fa_000162_61e293bf+0x24b>
  40a04b:	lea    rsi,[rsp+0x38]
  40a050:	mov    eax,DWORD PTR [rdi+0xc]
  40a053:	mov    DWORD PTR [rsp+0x38],eax
  40a057:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40a05c:	mov    rcx,rdi
  40a05f:	mov    rdx,QWORD PTR [r11+0x18]
  40a063:	mov    r8,rsi
  40a066:	mov    r8d,DWORD PTR [r8]
  40a069:	mov    r9,rax
  40a06c:	lea    r10,[rsp+0x10]
  40a071:	call   40d1c0 <__swc_fn_23cea7fa_000160_dfca9093>
  40a076:	test   al,al
  40a078:	jne    40a0ab <__swc_fn_23cea7fa_000162_61e293bf+0x19b>
  40a07a:	vmovups xmm0,XMMWORD PTR [rip+0x97d6]        # 413858 <__swc_rdata_base_23cea7fa+0x748>
  40a082:	vmovups XMMWORD PTR [rbx],xmm0
  40a086:	vmovups xmm0,XMMWORD PTR [rip+0x97da]        # 413868 <__swc_rdata_base_23cea7fa+0x758>
  40a08e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a093:	vxorps xmm0,xmm0,xmm0
  40a097:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a09c:	mov    rax,rbx
  40a09f:	add    rsp,0x50
  40a0a3:	pop    r13
  40a0a5:	pop    r12
  40a0a7:	pop    rdi
  40a0a8:	pop    rsi
  40a0a9:	pop    rbx
  40a0aa:	ret
  40a0ab:	lea    r13,[rsp+0x3c]
  40a0b0:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40a0b5:	mov    DWORD PTR [rsp+0x3c],eax
  40a0b9:	test   eax,eax
  40a0bb:	je     40a10c <__swc_fn_23cea7fa_000162_61e293bf+0x1fc>
  40a0bd:	mov    rcx,rdi
  40a0c0:	mov    rdx,QWORD PTR [r11+0x18]
  40a0c4:	mov    r8d,DWORD PTR [rsi]
  40a0c7:	mov    rax,r13
  40a0ca:	mov    r9d,DWORD PTR [rax]
  40a0cd:	lea    r10,[rsp+0x20]
  40a0d2:	call   40d1c0 <__swc_fn_23cea7fa_000160_dfca9093>
  40a0d7:	test   al,al
  40a0d9:	jne    40a10c <__swc_fn_23cea7fa_000162_61e293bf+0x1fc>
  40a0db:	vmovups xmm0,XMMWORD PTR [rip+0x97a5]        # 413888 <__swc_rdata_base_23cea7fa+0x778>
  40a0e3:	vmovups XMMWORD PTR [rbx],xmm0
  40a0e7:	vmovups xmm0,XMMWORD PTR [rip+0x97a9]        # 413898 <__swc_rdata_base_23cea7fa+0x788>
  40a0ef:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a0f4:	vxorps xmm0,xmm0,xmm0
  40a0f8:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a0fd:	mov    rax,rbx
  40a100:	add    rsp,0x50
  40a104:	pop    r13
  40a106:	pop    r12
  40a108:	pop    rdi
  40a109:	pop    rsi
  40a10a:	pop    rbx
  40a10b:	ret
  40a10c:	mov    eax,0x1
  40a111:	rex mov BYTE PTR [rsp+0x8],al
  40a116:	cmp    DWORD PTR [r13+0x0],0x0
  40a11b:	je     40a12c <__swc_fn_23cea7fa_000162_61e293bf+0x21c>
  40a11d:	rex mov BYTE PTR [rsp+0x9],0x1
  40a123:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40a128:	mov    DWORD PTR [rsp+0x30],eax
  40a12c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a132:	vmovups XMMWORD PTR [rbx],xmm0
  40a136:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a13c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a141:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a147:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a14c:	mov    rax,rbx
  40a14f:	add    rsp,0x50
  40a153:	pop    r13
  40a155:	pop    r12
  40a157:	pop    rdi
  40a158:	pop    rsi
  40a159:	pop    rbx
  40a15a:	ret
  40a15b:	add    rcx,0x1
  40a15f:	cmp    rcx,rax
  40a162:	jb     40a020 <__swc_fn_23cea7fa_000162_61e293bf+0x110>
  40a168:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a16e:	vmovups XMMWORD PTR [rbx],xmm0
  40a172:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a178:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a17d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a183:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a188:	mov    rax,rbx
  40a18b:	add    rsp,0x50
  40a18f:	pop    r13
  40a191:	pop    r12
  40a193:	pop    rdi
  40a194:	pop    rsi
  40a195:	pop    rbx
  40a196:	ret
	...

000000000040a1a0 <__swc_fn_23cea7fa_000165_56054fe7>:
  40a1a0:	sub    rsp,0x48
  40a1a4:	call   409580 <__swc_fn_23cea7fa_000123_e4107ade>
  40a1a9:	cmp    rax,0xffffffffffffffff
  40a1ad:	je     40a1b4 <__swc_fn_23cea7fa_000165_56054fe7+0x14>
  40a1af:	add    rsp,0x48
  40a1b3:	ret
  40a1b4:	lea    rcx,[rip+0x970d]        # 4138c8 <__swc_rdata_base_23cea7fa+0x7b8>
  40a1bb:	vmovups xmm0,XMMWORD PTR [rip+0x9715]        # 4138d8 <__swc_rdata_base_23cea7fa+0x7c8>
  40a1c3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a1c9:	vmovups xmm0,XMMWORD PTR [rip+0x9717]        # 4138e8 <__swc_rdata_base_23cea7fa+0x7d8>
  40a1d1:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a1d7:	vmovups xmm0,XMMWORD PTR [rip+0x9719]        # 4138f8 <__swc_rdata_base_23cea7fa+0x7e8>
  40a1df:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a1e5:	lea    rdx,[rsp+0x8]
  40a1ea:	mov    QWORD PTR [rsp+0x38],rax
  40a1ef:	call   40c3a0 <__swc_fn_23cea7fa_000103_0d4cc079>
  40a1f4:	mov    rax,QWORD PTR [rsp+0x38]
  40a1f9:	jmp    40a1af <__swc_fn_23cea7fa_000165_56054fe7+0xf>
  40a1fb:	add    BYTE PTR [rax],al
  40a1fd:	add    BYTE PTR [rax],al
	...

000000000040a200 <__swc_fn_23cea7fa_000168_0ad81c51>:
  40a200:	push   rbx
  40a201:	push   rsi
  40a202:	sub    rsp,0x28
  40a206:	mov    rbx,rcx
  40a209:	mov    DWORD PTR [rsp+0x8],0xbf0
  40a211:	mov    ecx,0xbf0
  40a216:	call   40bf90 <__swc_fn_23cea7fa_000079_633af784>
  40a21b:	mov    rsi,rax
  40a21e:	test   rax,rax
  40a221:	jne    40a22c <__swc_fn_23cea7fa_000168_0ad81c51+0x2c>
  40a223:	xor    eax,eax
  40a225:	add    rsp,0x28
  40a229:	pop    rsi
  40a22a:	pop    rbx
  40a22b:	ret
  40a22c:	vxorps xmm0,xmm0,xmm0
  40a230:	xor    eax,eax
  40a232:	cs nop WORD PTR [rax+rax*1+0x0]
  40a23c:	nop    DWORD PTR [rax+0x0]
  40a240:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40a245:	add    rax,0x10
  40a249:	cmp    rax,0xbf0
  40a250:	jne    40a240 <__swc_fn_23cea7fa_000168_0ad81c51+0x40>
  40a252:	lea    rax,[rbx+0x1]
  40a256:	mov    QWORD PTR [rsi+0x9c0],rax
  40a25d:	mov    rcx,rbx
  40a260:	mov    rdx,rsi
  40a263:	call   40d520 <__swc_fn_23cea7fa_000166_c370e18e>
  40a268:	test   al,al
  40a26a:	jne    40a27d <__swc_fn_23cea7fa_000168_0ad81c51+0x7d>
  40a26c:	mov    rcx,rsi
  40a26f:	call   40f170 <__swc_fn_23cea7fa_000080_207908fe>
  40a274:	xor    eax,eax
  40a276:	add    rsp,0x28
  40a27a:	pop    rsi
  40a27b:	pop    rbx
  40a27c:	ret
  40a27d:	lea    rcx,[rsp+0x18]
  40a282:	call   40f6f0 <__swc_fn_23cea7fa_000092_809deff5>
  40a287:	mov    rax,rsi
  40a28a:	add    rsp,0x28
  40a28e:	pop    rsi
  40a28f:	pop    rbx
  40a290:	ret
	...

000000000040a2a0 <__swc_fn_23cea7fa_000171_8c19aea5>:
  40a2a0:	xor    eax,eax
  40a2a2:	mov    edx,0x1
  40a2a7:	lock cmpxchg QWORD PTR [rcx],rdx
  40a2ac:	test   rax,rax
  40a2af:	jne    40a2b2 <__swc_fn_23cea7fa_000171_8c19aea5+0x12>
  40a2b1:	ret
  40a2b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2bc:	nop    DWORD PTR [rax+0x0]
  40a2c0:	mov    rax,QWORD PTR [rcx]
  40a2c3:	test   rax,rax
  40a2c6:	je     40a2a0 <__swc_fn_23cea7fa_000171_8c19aea5>
  40a2c8:	jmp    40a2c0 <__swc_fn_23cea7fa_000171_8c19aea5+0x20>
  40a2ca:	add    BYTE PTR [rax],al
  40a2cc:	add    BYTE PTR [rax],al
	...

000000000040a2d0 <__swc_fn_23cea7fa_000174_02e645b4>:
  40a2d0:	push   rsi
  40a2d1:	push   rdi
  40a2d2:	sub    rsp,0x38
  40a2d6:	mov    rsi,rcx
  40a2d9:	call   40d530 <__swc_fn_23cea7fa_000169_4694b8ad>
  40a2de:	mov    rdi,rax
  40a2e1:	call   40ccc0 <__swc_fn_23cea7fa_000130_375c7357>
  40a2e6:	mov    r8,rax
  40a2e9:	mov    rcx,rdi
  40a2ec:	call   40a2a0 <__swc_fn_23cea7fa_000171_8c19aea5>
  40a2f1:	mov    rax,QWORD PTR [rdi+0x8]
  40a2f5:	test   rax,rax
  40a2f8:	je     40a335 <__swc_fn_23cea7fa_000174_02e645b4+0x65>
  40a2fa:	nop    WORD PTR [rax+rax*1+0x0]
  40a300:	cmp    rax,rsi
  40a303:	je     40a335 <__swc_fn_23cea7fa_000174_02e645b4+0x65>
  40a305:	mov    r9,QWORD PTR [rax]
  40a308:	cmp    QWORD PTR [rax+0x20],r8
  40a30c:	jne    40a32d <__swc_fn_23cea7fa_000174_02e645b4+0x5d>
  40a30e:	mov    rcx,rdi
  40a311:	mov    rdx,rax
  40a314:	mov    QWORD PTR [rsp+0x28],r8
  40a319:	mov    QWORD PTR [rsp+0x30],r9
  40a31e:	call   4120c0 <__swc_fn_23cea7fa_000173_e17a224b>
  40a323:	mov    r8,QWORD PTR [rsp+0x28]
  40a328:	mov    r9,QWORD PTR [rsp+0x30]
  40a32d:	mov    rax,r9
  40a330:	test   r9,r9
  40a333:	jne    40a300 <__swc_fn_23cea7fa_000174_02e645b4+0x30>
  40a335:	xor    eax,eax
  40a337:	mov    QWORD PTR [rdi],rax
  40a33a:	add    rsp,0x38
  40a33e:	pop    rdi
  40a33f:	pop    rsi
  40a340:	ret
	...

000000000040a350 <__swc_fn_23cea7fa_000177_1ca87929>:
  40a350:	push   rdi
  40a351:	push   rsi
  40a352:	sub    rsp,0xb8
  40a359:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40a35f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40a365:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40a36b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40a371:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40a377:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40a37d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40a383:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40a38c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40a395:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40a39e:	vxorps xmm0,xmm0,xmm0
  40a3a2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a3a8:	mov    edi,0x1
  40a3ad:	lea    rsi,[rsp+0x8]
  40a3b2:	xor    eax,eax
  40a3b4:	call   4070e0 <clock_gettime@plt>
  40a3b9:	vxorpd xmm0,xmm0,xmm0
  40a3bd:	mov    rax,QWORD PTR [rsp+0x8]
  40a3c2:	vcvtsi2sd xmm0,xmm0,rax
  40a3c7:	vxorpd xmm1,xmm1,xmm1
  40a3cb:	mov    rax,QWORD PTR [rsp+0x10]
  40a3d0:	vcvtsi2sd xmm1,xmm1,rax
  40a3d5:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x952b]        # 413908 <__swc_rdata_base_23cea7fa+0x7f8>
  40a3dd:	vaddsd xmm0,xmm0,xmm1
  40a3e1:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40a3e7:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40a3ed:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40a3f3:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40a3f9:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40a3ff:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40a405:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40a40b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40a414:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40a41d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40a426:	add    rsp,0xb8
  40a42d:	pop    rsi
  40a42e:	pop    rdi
  40a42f:	ret
	...

000000000040a440 <__swc_fn_23cea7fa_000001_0e26756e>:
  40a440:	vxorps xmm0,xmm0,xmm0
  40a444:	xor    eax,eax
  40a446:	cs nop WORD PTR [rax+rax*1+0x0]
  40a450:	cs nop WORD PTR [rax+rax*1+0x0]
  40a45a:	nop    WORD PTR [rax+rax*1+0x0]
  40a460:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a465:	add    rax,0x10
  40a469:	cmp    rax,0x2080
  40a470:	jne    40a460 <__swc_fn_23cea7fa_000001_0e26756e+0x20>
  40a472:	ret
	...

000000000040a480 <__swc_fn_23cea7fa_000004_3deb8b54>:
  40a480:	push   rsi
  40a481:	push   rdi
  40a482:	push   r12
  40a484:	push   r13
  40a486:	push   r14
  40a488:	mov    rsi,rcx
  40a48b:	mov    edi,r10d
  40a48e:	mov    r12,rcx
  40a491:	mov    r13,r9
  40a494:	mov    ecx,DWORD PTR [rdx+0x28]
  40a497:	shlx   r14d,r8d,ecx
  40a49c:	mov    rcx,rdx
  40a49f:	mov    edx,r8d
  40a4a2:	call   40e040 <__swc_fn_23cea7fa_000011_71c91685>
  40a4a7:	mov    rcx,rax
  40a4aa:	mov    eax,DWORD PTR [r12+0x3c]
  40a4af:	xor    edx,edx
  40a4b1:	div    rdi
  40a4b4:	vxorps xmm0,xmm0,xmm0
  40a4b8:	vmovdqu XMMWORD PTR [rsi],xmm0
  40a4bc:	mov    QWORD PTR [r12+0x60],0x0
  40a4c5:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40a4ca:	mov    QWORD PTR [r12+0x10],rcx
  40a4cf:	imul   rax,rdi
  40a4d3:	lea    rdx,[rcx+rax*1]
  40a4d7:	mov    QWORD PTR [r12+0x18],rdx
  40a4dc:	mov    QWORD PTR [r12+0x20],rcx
  40a4e1:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40a4e6:	mov    DWORD PTR [r12+0x28],0x0
  40a4ef:	mov    DWORD PTR [r12+0x68],0x0
  40a4f8:	mov    BYTE PTR [r12+0x39],r13b
  40a4fd:	mov    BYTE PTR [r12+0x3a],r14b
  40a502:	mov    BYTE PTR [r12+0x3b],0x1
  40a508:	mov    DWORD PTR [r12+0x6c],0x0
  40a511:	mov    rcx,r12
  40a514:	mov    edx,edi
  40a516:	call   40dfa0 <__swc_fn_23cea7fa_000005_6a556171>
  40a51b:	pop    r14
  40a51d:	pop    r13
  40a51f:	pop    r12
  40a521:	pop    rdi
  40a522:	pop    rsi
  40a523:	ret
	...

000000000040a530 <__swc_fn_23cea7fa_000007_a7bfb091>:
  40a530:	mov    r8d,0x1
  40a536:	xor    eax,eax
  40a538:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40a53e:	test   eax,eax
  40a540:	jne    40a530 <__swc_fn_23cea7fa_000007_a7bfb091>
  40a542:	ret
	...

000000000040a550 <__swc_fn_23cea7fa_000010_0569f799>:
  40a550:	lea    r8,[rcx+0x60]
  40a554:	mov    rax,QWORD PTR [r8]
  40a557:	mov    r9,rax
  40a55a:	nop    WORD PTR [rax+rax*1+0x0]
  40a560:	mov    QWORD PTR [rdx],r9
  40a563:	mov    rax,r9
  40a566:	lock cmpxchg QWORD PTR [r8],rdx
  40a56b:	cmp    rax,r9
  40a56e:	jne    40a5d7 <__swc_fn_23cea7fa_000010_0569f799+0x87>
  40a570:	mov    eax,DWORD PTR [rcx+0x6c]
  40a573:	test   eax,eax
  40a575:	je     40a5d6 <__swc_fn_23cea7fa_000010_0569f799+0x86>
  40a577:	lea    rdx,[rcx+0x70]
  40a57b:	mov    r9d,0x1
  40a581:	xor    eax,eax
  40a583:	lock cmpxchg DWORD PTR [rdx],r9d
  40a588:	test   eax,eax
  40a58a:	jne    40a5d6 <__swc_fn_23cea7fa_000010_0569f799+0x86>
  40a58c:	mov    rax,rcx
  40a58f:	and    rax,0xffffffffffc00000
  40a596:	mov    rax,QWORD PTR [rax+0x8]
  40a59a:	test   rax,rax
  40a59d:	jne    40a5a5 <__swc_fn_23cea7fa_000010_0569f799+0x55>
  40a59f:	xor    eax,eax
  40a5a1:	xchg   DWORD PTR [rdx],eax
  40a5a3:	jmp    40a5d6 <__swc_fn_23cea7fa_000010_0569f799+0x86>
  40a5a5:	lea    rdx,[rax+0x2a80]
  40a5ac:	mov    rax,QWORD PTR [rdx]
  40a5af:	mov    r8,rax
  40a5b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5bc:	nop    DWORD PTR [rax+0x0]
  40a5c0:	mov    QWORD PTR [rcx+0x78],r8
  40a5c4:	mov    rax,r8
  40a5c7:	lock cmpxchg QWORD PTR [rdx],rcx
  40a5cc:	cmp    rax,r8
  40a5cf:	je     40a5d6 <__swc_fn_23cea7fa_000010_0569f799+0x86>
  40a5d1:	mov    r8,rax
  40a5d4:	jmp    40a5c0 <__swc_fn_23cea7fa_000010_0569f799+0x70>
  40a5d6:	ret
  40a5d7:	mov    r9,rax
  40a5da:	jmp    40a560 <__swc_fn_23cea7fa_000010_0569f799+0x10>
	...

000000000040a5e0 <__swc_fn_23cea7fa_000013_7b85dbab>:
  40a5e0:	push   rsi
  40a5e1:	push   rdi
  40a5e2:	push   r12
  40a5e4:	push   r13
  40a5e6:	push   r14
  40a5e8:	push   r15
  40a5ea:	push   rbx
  40a5eb:	sub    rsp,0x30
  40a5ef:	mov    QWORD PTR [rsp+0x18],r8
  40a5f4:	mov    rsi,rcx
  40a5f7:	mov    rdi,rdx
  40a5fa:	mov    rdx,QWORD PTR [rsi+0x40]
  40a5fe:	xchg   ax,ax
  40a600:	mov    rax,rdx
  40a603:	not    rax
  40a606:	and    rax,QWORD PTR [rsi+0x20]
  40a60a:	test   rax,rax
  40a60d:	jne    40a621 <__swc_fn_23cea7fa_000013_7b85dbab+0x41>
  40a60f:	xor    eax,eax
  40a611:	add    rsp,0x30
  40a615:	pop    rbx
  40a616:	pop    r15
  40a618:	pop    r14
  40a61a:	pop    r13
  40a61c:	pop    r12
  40a61e:	pop    rdi
  40a61f:	pop    rsi
  40a620:	ret
  40a621:	xor    ecx,ecx
  40a623:	tzcnt  rcx,rax
  40a628:	lea    r12,[rsp+0x8]
  40a62d:	mov    DWORD PTR [rsp+0x8],ecx
  40a631:	mov    r13d,0x1
  40a637:	shl    r13,cl
  40a63a:	mov    rcx,rdx
  40a63d:	or     rcx,r13
  40a640:	mov    rax,rdx
  40a643:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40a649:	cmp    rax,rdx
  40a64c:	je     40a653 <__swc_fn_23cea7fa_000013_7b85dbab+0x73>
  40a64e:	mov    rdx,rax
  40a651:	jmp    40a600 <__swc_fn_23cea7fa_000013_7b85dbab+0x20>
  40a653:	mov    eax,DWORD PTR [r12]
  40a657:	shl    rax,0x4
  40a65b:	lea    r14,[rsi+rax*8+0x80]
  40a663:	mov    rcx,rsi
  40a666:	mov    rax,r12
  40a669:	mov    edx,DWORD PTR [rax]
  40a66b:	call   40e040 <__swc_fn_23cea7fa_000011_71c91685>
  40a670:	mov    r15,rax
  40a673:	mov    rcx,rsi
  40a676:	mov    rdx,r13
  40a679:	call   40e1a0 <__swc_fn_23cea7fa_000017_f003fc47>
  40a67e:	test   al,al
  40a680:	je     40a6b8 <__swc_fn_23cea7fa_000013_7b85dbab+0xd8>
  40a682:	mov    ecx,DWORD PTR [r14+0x3c]
  40a686:	lea    rdx,[rip+0x199cb]        # 424058 <__swc_bss_base_23cea7fa+0x18>
  40a68d:	mov    r8,QWORD PTR [rip+0x199c4]        # 424058 <__swc_bss_base_23cea7fa+0x18>
  40a694:	cs nop WORD PTR [rax+rax*1+0x0]
  40a69e:	xchg   ax,ax
  40a6a0:	mov    r9,r8
  40a6a3:	sub    r9,rcx
  40a6a6:	mov    rax,r8
  40a6a9:	lock cmpxchg QWORD PTR [rdx],r9
  40a6ae:	cmp    rax,r8
  40a6b1:	je     40a719 <__swc_fn_23cea7fa_000013_7b85dbab+0x139>
  40a6b3:	mov    r8,rax
  40a6b6:	jmp    40a6a0 <__swc_fn_23cea7fa_000013_7b85dbab+0xc0>
  40a6b8:	mov    rcx,rsi
  40a6bb:	mov    rax,r12
  40a6be:	mov    edx,DWORD PTR [rax]
  40a6c0:	call   407450 <__swc_fn_23cea7fa_000012_be38a1a2>
  40a6c5:	mov    rcx,r15
  40a6c8:	and    rcx,0xffffffffffff0000
  40a6cf:	lea    rcx,[rcx+0x10000]
  40a6d6:	mov    rbx,rax
  40a6d9:	cmp    rax,rcx
  40a6dc:	cmova  rbx,rcx
  40a6e0:	mov    rax,rbx
  40a6e3:	sub    rax,r15
  40a6e6:	mov    rcx,r15
  40a6e9:	mov    rdx,rax
  40a6ec:	call   4072a0 <__swc_fn_23cea7fa_000003_81215399>
  40a6f1:	test   al,al
  40a6f3:	jne    40a712 <__swc_fn_23cea7fa_000013_7b85dbab+0x132>
  40a6f5:	mov    rcx,rsi
  40a6f8:	mov    rdx,r13
  40a6fb:	call   407600 <__swc_fn_23cea7fa_000018_77ece227>
  40a700:	xor    eax,eax
  40a702:	add    rsp,0x30
  40a706:	pop    rbx
  40a707:	pop    r15
  40a709:	pop    r14
  40a70b:	pop    r13
  40a70d:	pop    r12
  40a70f:	pop    rdi
  40a710:	pop    rsi
  40a711:	ret
  40a712:	sub    rbx,r15
  40a715:	mov    DWORD PTR [r14+0x3c],ebx
  40a719:	mov    rcx,r14
  40a71c:	mov    rdx,rsi
  40a71f:	mov    r8d,DWORD PTR [r12]
  40a723:	mov    r9d,edi
  40a726:	mov    rbx,QWORD PTR [rsp+0x18]
  40a72b:	mov    r10d,ebx
  40a72e:	call   40a480 <__swc_fn_23cea7fa_000004_3deb8b54>
  40a733:	mov    rax,r14
  40a736:	add    rsp,0x30
  40a73a:	pop    rbx
  40a73b:	pop    r15
  40a73d:	pop    r14
  40a73f:	pop    r13
  40a741:	pop    r12
  40a743:	pop    rdi
  40a744:	pop    rsi
  40a745:	ret
	...

000000000040a750 <__swc_fn_23cea7fa_000016_a0b588d0>:
  40a750:	mov    r8,QWORD PTR [rcx+0x48]
  40a754:	cs nop WORD PTR [rax+rax*1+0x0]
  40a75e:	xchg   ax,ax
  40a760:	mov    r9,r8
  40a763:	or     r9,rdx
  40a766:	mov    rax,r8
  40a769:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40a76f:	cmp    rax,r8
  40a772:	jne    40a775 <__swc_fn_23cea7fa_000016_a0b588d0+0x25>
  40a774:	ret
  40a775:	mov    r8,rax
  40a778:	jmp    40a760 <__swc_fn_23cea7fa_000016_a0b588d0+0x10>
  40a77a:	add    BYTE PTR [rax],al
  40a77c:	add    BYTE PTR [rax],al
	...

000000000040a780 <__swc_fn_23cea7fa_000019_447bb610>:
  40a780:	push   rsi
  40a781:	push   rdi
  40a782:	push   r12
  40a784:	mov    rsi,rcx
  40a787:	xor    edi,edi
  40a789:	lea    r12,[rip+0x198d8]        # 424068 <__swc_bss_base_23cea7fa+0x28>
  40a790:	mov    eax,DWORD PTR [r12]
  40a794:	xor    ecx,ecx
  40a796:	test   rax,rax
  40a799:	jbe    40a7d4 <__swc_fn_23cea7fa_000019_447bb610+0x54>
  40a79b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a7a0:	lea    rdx,[rip+0x198c9]        # 424070 <__swc_bss_base_23cea7fa+0x30>
  40a7a7:	mov    r8d,ecx
  40a7aa:	lea    r8,[r8+r8*2]
  40a7ae:	lea    r8,[rdx+r8*8]
  40a7b2:	mov    rdx,QWORD PTR [r8+0x10]
  40a7b6:	add    rdx,0x400000
  40a7bd:	cmp    rdx,0x40000000
  40a7c4:	ja     40a7cb <__swc_fn_23cea7fa_000019_447bb610+0x4b>
  40a7c6:	mov    rdi,r8
  40a7c9:	jmp    40a7d4 <__swc_fn_23cea7fa_000019_447bb610+0x54>
  40a7cb:	add    rcx,0x1
  40a7cf:	cmp    rcx,rax
  40a7d2:	jb     40a7a0 <__swc_fn_23cea7fa_000019_447bb610+0x20>
  40a7d4:	test   rdi,rdi
  40a7d7:	jne    40a863 <__swc_fn_23cea7fa_000019_447bb610+0xe3>
  40a7dd:	cmp    DWORD PTR [r12],0x10
  40a7e2:	jae    40a84b <__swc_fn_23cea7fa_000019_447bb610+0xcb>
  40a7e4:	mov    ecx,0x40400000
  40a7e9:	call   40df60 <__swc_fn_23cea7fa_000002_102336c4>
  40a7ee:	test   rax,rax
  40a7f1:	je     40a84b <__swc_fn_23cea7fa_000019_447bb610+0xcb>
  40a7f3:	lea    rcx,[rip+0x19876]        # 424070 <__swc_bss_base_23cea7fa+0x30>
  40a7fa:	mov    edx,DWORD PTR [r12]
  40a7fe:	lea    rdx,[rdx+rdx*2]
  40a802:	lea    rdx,[rcx+rdx*8]
  40a806:	mov    QWORD PTR [rdx],rax
  40a809:	lea    rax,[rax+0x3fffff]
  40a810:	and    rax,0xffffffffffc00000
  40a817:	mov    QWORD PTR [rdx+0x8],rax
  40a81b:	mov    QWORD PTR [rdx+0x10],0x0
  40a823:	mov    edx,DWORD PTR [rip+0x1983f]        # 424068 <__swc_bss_base_23cea7fa+0x28>
  40a829:	nop    DWORD PTR [rax+0x0]
  40a830:	lea    r9d,[rdx+0x1]
  40a834:	mov    rax,rdx
  40a837:	lock cmpxchg DWORD PTR [r12],r9d
  40a83d:	mov    r8d,eax
  40a840:	cmp    eax,edx
  40a842:	je     40a852 <__swc_fn_23cea7fa_000019_447bb610+0xd2>
  40a844:	mov    rdx,r8
  40a847:	jmp    40a830 <__swc_fn_23cea7fa_000019_447bb610+0xb0>
  40a849:	jmp    40a852 <__swc_fn_23cea7fa_000019_447bb610+0xd2>
  40a84b:	xor    eax,eax
  40a84d:	pop    r12
  40a84f:	pop    rdi
  40a850:	pop    rsi
  40a851:	ret
  40a852:	mov    eax,DWORD PTR [rip+0x19810]        # 424068 <__swc_bss_base_23cea7fa+0x28>
  40a858:	sub    eax,0x1
  40a85b:	lea    rdi,[rax+rax*2]
  40a85f:	lea    rdi,[rcx+rdi*8]
  40a863:	mov    r12,QWORD PTR [rdi+0x8]
  40a867:	add    r12,QWORD PTR [rdi+0x10]
  40a86b:	mov    rcx,r12
  40a86e:	mov    edx,0x3000
  40a873:	call   4072a0 <__swc_fn_23cea7fa_000003_81215399>
  40a878:	test   al,al
  40a87a:	jne    40a883 <__swc_fn_23cea7fa_000019_447bb610+0x103>
  40a87c:	xor    eax,eax
  40a87e:	pop    r12
  40a880:	pop    rdi
  40a881:	pop    rsi
  40a882:	ret
  40a883:	vxorps xmm0,xmm0,xmm0
  40a887:	xor    eax,eax
  40a889:	cs nop WORD PTR [rax+rax*1+0x0]
  40a893:	cs nop WORD PTR [rax+rax*1+0x0]
  40a89d:	nop    DWORD PTR [rax]
  40a8a0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40a8a6:	add    rax,0x10
  40a8aa:	cmp    rax,0x3000
  40a8b1:	jne    40a8a0 <__swc_fn_23cea7fa_000019_447bb610+0x120>
  40a8b3:	mov    DWORD PTR [r12+0x28],esi
  40a8b8:	mov    eax,0x40
  40a8bd:	mov    ecx,esi
  40a8bf:	shr    eax,cl
  40a8c1:	mov    DWORD PTR [r12+0x2c],eax
  40a8c6:	cmp    DWORD PTR [r12+0x2c],0x40
  40a8cc:	jb     40a8d7 <__swc_fn_23cea7fa_000019_447bb610+0x157>
  40a8ce:	mov    rax,0xffffffffffffffff
  40a8d5:	jmp    40a8e7 <__swc_fn_23cea7fa_000019_447bb610+0x167>
  40a8d7:	mov    eax,0x1
  40a8dc:	mov    ecx,DWORD PTR [r12+0x2c]
  40a8e1:	shl    rax,cl
  40a8e4:	dec    rax
  40a8e7:	mov    QWORD PTR [r12+0x20],rax
  40a8ec:	mov    DWORD PTR [r12],0x4e540001
  40a8f4:	mov    DWORD PTR [r12+0x4],0x53474d45
  40a8fd:	add    QWORD PTR [rdi+0x10],0x400000
  40a905:	mov    rax,r12
  40a908:	pop    r12
  40a90a:	pop    rdi
  40a90b:	pop    rsi
  40a90c:	ret
  40a90d:	add    BYTE PTR [rax],al
	...

000000000040a910 <__swc_fn_23cea7fa_000022_53fc00d2>:
  40a910:	mov    eax,0x1
  40a915:	mov    edx,DWORD PTR [rip+0x1974d]        # 424068 <__swc_bss_base_23cea7fa+0x28>
  40a91b:	cmp    eax,edx
  40a91d:	jae    40a96b <__swc_fn_23cea7fa_000022_53fc00d2+0x5b>
  40a91f:	nop
  40a920:	lea    r8,[rip+0x19749]        # 424070 <__swc_bss_base_23cea7fa+0x30>
  40a927:	lea    r9,[rax+rax*2]
  40a92b:	lea    r9,[r8+r9*8]
  40a92f:	mov    r8,rcx
  40a932:	sub    r8,QWORD PTR [r9+0x8]
  40a936:	mov    r9,QWORD PTR [r9+0x10]
  40a93a:	cmp    r8,r9
  40a93d:	jae    40a965 <__swc_fn_23cea7fa_000022_53fc00d2+0x55>
  40a93f:	mov    rax,rcx
  40a942:	and    rax,0xffffffffffc00000
  40a949:	shr    rcx,0x10
  40a94d:	and    ecx,0x3f
  40a950:	mov    edx,DWORD PTR [rax+0x28]
  40a953:	shrx   ecx,ecx,edx
  40a958:	shl    rcx,0x4
  40a95c:	lea    rax,[rax+rcx*8+0x80]
  40a964:	ret
  40a965:	inc    eax
  40a967:	cmp    eax,edx
  40a969:	jb     40a920 <__swc_fn_23cea7fa_000022_53fc00d2+0x10>
  40a96b:	xor    eax,eax
  40a96d:	ret
	...

000000000040a970 <__swc_fn_23cea7fa_000025_e876734d>:
  40a970:	vxorps xmm0,xmm0,xmm0
  40a974:	vmovups XMMWORD PTR [rcx],xmm0
  40a978:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a97d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a982:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a987:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40a98c:	mov    QWORD PTR [rcx+0x50],0x0
  40a994:	ret
	...

000000000040a9a0 <__swc_fn_23cea7fa_000028_e876734d>:
  40a9a0:	vxorps xmm0,xmm0,xmm0
  40a9a4:	xor    eax,eax
  40a9a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9b0:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9ba:	nop    WORD PTR [rax+rax*1+0x0]
  40a9c0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a9c5:	add    rax,0x10
  40a9c9:	cmp    rax,0x9b0
  40a9d0:	jne    40a9c0 <__swc_fn_23cea7fa_000028_e876734d+0x20>
  40a9d2:	mov    QWORD PTR [rcx+0x9b0],0x0
  40a9dd:	ret
	...

000000000040a9e0 <__swc_fn_23cea7fa_000031_3c3e930e>:
  40a9e0:	push   rsi
  40a9e1:	push   rdi
  40a9e2:	sub    rsp,0x8
  40a9e6:	lea    rsi,[rip+0x1761b]        # 422008 <__swc_data_base_23cea7fa+0x8>
  40a9ed:	mov    rax,QWORD PTR [rsi]
  40a9f0:	mov    ecx,0xffffffff
  40a9f5:	cmp    rax,rcx
  40a9f8:	je     40aa01 <__swc_fn_23cea7fa_000031_3c3e930e+0x21>
  40a9fa:	add    rsp,0x8
  40a9fe:	pop    rdi
  40a9ff:	pop    rsi
  40aa00:	ret
  40aa01:	mov    rcx,QWORD PTR [rip+0x8678]        # 413080 <__swc_fn_23cea7fa_000176_5d3d19bd+0xf40>
  40aa08:	call   409650 <__swc_fn_23cea7fa_000126_9e9697c7>
  40aa0d:	mov    rcx,rax
  40aa10:	mov    eax,0xffffffff
  40aa15:	lock cmpxchg QWORD PTR [rsi],rcx
  40aa1a:	mov    rdi,rax
  40aa1d:	mov    eax,0xffffffff
  40aa22:	cmp    rdi,rax
  40aa25:	je     40aa36 <__swc_fn_23cea7fa_000031_3c3e930e+0x56>
  40aa27:	call   40cc10 <__swc_fn_23cea7fa_000127_f163135d>
  40aa2c:	mov    rax,rdi
  40aa2f:	add    rsp,0x8
  40aa33:	pop    rdi
  40aa34:	pop    rsi
  40aa35:	ret
  40aa36:	mov    rax,rcx
  40aa39:	add    rsp,0x8
  40aa3d:	pop    rdi
  40aa3e:	pop    rsi
  40aa3f:	ret

000000000040aa40 <__swc_fn_23cea7fa_000034_cf5ba7bd>:
  40aa40:	sub    rsp,0x8
  40aa44:	vxorps xmm0,xmm0,xmm0
  40aa48:	xor    eax,eax
  40aa4a:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa54:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa5e:	xchg   ax,ax
  40aa60:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40aa65:	add    rax,0x10
  40aa69:	cmp    rax,0x2b00
  40aa70:	jne    40aa60 <__swc_fn_23cea7fa_000034_cf5ba7bd+0x20>
  40aa72:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40aa7c:	xor    al,al
  40aa7e:	mov    rdx,rax
  40aa81:	xor    al,al
  40aa83:	mov    r8,rax
  40aa86:	xor    al,al
  40aa88:	mov    r9,rax
  40aa8b:	xor    al,al
  40aa8d:	mov    r10,rax
  40aa90:	xor    al,al
  40aa92:	mov    r11,rax
  40aa95:	call   40e3d0 <__swc_fn_23cea7fa_000035_ab2e8c35>
  40aa9a:	add    rsp,0x8
  40aa9e:	ret
	...

000000000040aaa0 <__swc_fn_23cea7fa_000037_1e381f55>:
  40aaa0:	push   rsi
  40aaa1:	push   rdi
  40aaa2:	push   r12
  40aaa4:	mov    rsi,r8
  40aaa7:	mov    rdi,rdx
  40aaaa:	mov    rcx,rdx
  40aaad:	call   40df60 <__swc_fn_23cea7fa_000002_102336c4>
  40aab2:	mov    r12,rax
  40aab5:	test   rax,rax
  40aab8:	jne    40aac1 <__swc_fn_23cea7fa_000037_1e381f55+0x21>
  40aaba:	xor    eax,eax
  40aabc:	pop    r12
  40aabe:	pop    rdi
  40aabf:	pop    rsi
  40aac0:	ret
  40aac1:	mov    rcx,r12
  40aac4:	mov    rdx,rsi
  40aac7:	call   4072a0 <__swc_fn_23cea7fa_000003_81215399>
  40aacc:	test   al,al
  40aace:	jne    40aae2 <__swc_fn_23cea7fa_000037_1e381f55+0x42>
  40aad0:	mov    rcx,r12
  40aad3:	mov    rdx,rdi
  40aad6:	call   4101d0 <__swc_fn_23cea7fa_000113_4e83a03a>
  40aadb:	xor    eax,eax
  40aadd:	pop    r12
  40aadf:	pop    rdi
  40aae0:	pop    rsi
  40aae1:	ret
  40aae2:	mov    rax,r12
  40aae5:	pop    r12
  40aae7:	pop    rdi
  40aae8:	pop    rsi
  40aae9:	ret
	...

000000000040ab00 <__swc_fn_23cea7fa_000040_8029566e>:
  40ab00:	push   rsi
  40ab01:	push   rdi
  40ab02:	push   r12
  40ab04:	mov    rsi,rcx
  40ab07:	mov    edx,0x9b8
  40ab0c:	call   40e440 <__swc_fn_23cea7fa_000038_292d55e5>
  40ab11:	mov    rdi,rax
  40ab14:	test   rax,rax
  40ab17:	jne    40ab20 <__swc_fn_23cea7fa_000040_8029566e+0x20>
  40ab19:	xor    eax,eax
  40ab1b:	pop    r12
  40ab1d:	pop    rdi
  40ab1e:	pop    rsi
  40ab1f:	ret
  40ab20:	vxorps xmm0,xmm0,xmm0
  40ab24:	xor    eax,eax
  40ab26:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab30:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab3a:	nop    WORD PTR [rax+rax*1+0x0]
  40ab40:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40ab45:	add    rax,0x10
  40ab49:	cmp    rax,0x9b0
  40ab50:	jne    40ab40 <__swc_fn_23cea7fa_000040_8029566e+0x40>
  40ab52:	mov    QWORD PTR [rdi+0x9b0],0x0
  40ab5d:	mov    QWORD PTR [rdi],rsi
  40ab60:	call   40ccc0 <__swc_fn_23cea7fa_000130_375c7357>
  40ab65:	mov    QWORD PTR [rdi+0x18],rax
  40ab69:	lea    r12,[rsi+0x10]
  40ab6d:	mov    rcx,r12
  40ab70:	call   4098a0 <__swc_fn_23cea7fa_000135_db32cc57>
  40ab75:	mov    rax,QWORD PTR [rsi+0x20]
  40ab79:	mov    QWORD PTR [rdi+0x8],rax
  40ab7d:	mov    rax,QWORD PTR [rsi+0x20]
  40ab81:	test   rax,rax
  40ab84:	je     40ab8a <__swc_fn_23cea7fa_000040_8029566e+0x8a>
  40ab86:	mov    QWORD PTR [rax+0x10],rdi
  40ab8a:	mov    QWORD PTR [rsi+0x20],rdi
  40ab8e:	mov    rcx,r12
  40ab91:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  40ab96:	mov    rax,rdi
  40ab99:	pop    r12
  40ab9b:	pop    rdi
  40ab9c:	pop    rsi
  40ab9d:	ret
	...

000000000040aba0 <__swc_fn_23cea7fa_000043_47ff6d9b>:
  40aba0:	mov    rax,QWORD PTR [rdx+0x10]
  40aba4:	test   rax,rax
  40aba7:	je     40abb3 <__swc_fn_23cea7fa_000043_47ff6d9b+0x13>
  40aba9:	mov    rcx,QWORD PTR [rdx+0x8]
  40abad:	mov    QWORD PTR [rax+0x8],rcx
  40abb1:	jmp    40abbb <__swc_fn_23cea7fa_000043_47ff6d9b+0x1b>
  40abb3:	mov    rax,QWORD PTR [rdx+0x8]
  40abb7:	mov    QWORD PTR [rcx+0x20],rax
  40abbb:	mov    rax,QWORD PTR [rdx+0x8]
  40abbf:	test   rax,rax
  40abc2:	je     40abcc <__swc_fn_23cea7fa_000043_47ff6d9b+0x2c>
  40abc4:	mov    rcx,QWORD PTR [rdx+0x10]
  40abc8:	mov    QWORD PTR [rax+0x10],rcx
  40abcc:	vxorps xmm0,xmm0,xmm0
  40abd0:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40abd5:	ret
	...

000000000040abe0 <__swc_fn_23cea7fa_000046_b28a6ee7>:
  40abe0:	sub    rsp,0x8
  40abe4:	mov    r9,r8
  40abe7:	mov    r10,rdx
  40abea:	call   40e4f0 <__swc_fn_23cea7fa_000044_fe6bbfdb>
  40abef:	mov    eax,0x1
  40abf4:	xchg   DWORD PTR [r9+0x6c],eax
  40abf8:	mov    rax,QWORD PTR [r9+0x60]
  40abfc:	test   rax,rax
  40abff:	je     40ac43 <__swc_fn_23cea7fa_000046_b28a6ee7+0x63>
  40ac01:	xor    eax,eax
  40ac03:	xchg   DWORD PTR [r9+0x6c],eax
  40ac07:	movzx  eax,BYTE PTR [r9+0x39]
  40ac0c:	lea    rax,[rax+rax*4]
  40ac10:	lea    rax,[r10+rax*8+0x28]
  40ac15:	mov    QWORD PTR [r9+0x50],0x0
  40ac1d:	mov    rcx,QWORD PTR [rax+0x8]
  40ac21:	mov    QWORD PTR [r9+0x48],rcx
  40ac25:	mov    rcx,QWORD PTR [rax+0x8]
  40ac29:	test   rcx,rcx
  40ac2c:	je     40ac34 <__swc_fn_23cea7fa_000046_b28a6ee7+0x54>
  40ac2e:	mov    QWORD PTR [rcx+0x50],r9
  40ac32:	jmp    40ac38 <__swc_fn_23cea7fa_000046_b28a6ee7+0x58>
  40ac34:	mov    QWORD PTR [rax+0x10],r9
  40ac38:	mov    QWORD PTR [rax+0x8],r9
  40ac3c:	xor    eax,eax
  40ac3e:	add    rsp,0x8
  40ac42:	ret
  40ac43:	movzx  eax,BYTE PTR [r9+0x39]
  40ac48:	lea    rax,[rax+rax*4]
  40ac4c:	lea    rax,[r10+rax*8+0x28]
  40ac51:	mov    QWORD PTR [r9+0x50],0x0
  40ac59:	mov    rcx,QWORD PTR [rax+0x18]
  40ac5d:	mov    QWORD PTR [r9+0x48],rcx
  40ac61:	mov    rcx,QWORD PTR [rax+0x18]
  40ac65:	test   rcx,rcx
  40ac68:	je     40ac6e <__swc_fn_23cea7fa_000046_b28a6ee7+0x8e>
  40ac6a:	mov    QWORD PTR [rcx+0x50],r9
  40ac6e:	mov    QWORD PTR [rax+0x18],r9
  40ac72:	mov    eax,0x1
  40ac77:	add    rsp,0x8
  40ac7b:	ret
  40ac7c:	add    BYTE PTR [rax],al
	...

000000000040ac80 <__swc_fn_23cea7fa_000049_f6a485a2>:
  40ac80:	push   r12
  40ac82:	push   r13
  40ac84:	push   rdi
  40ac85:	push   rsi
  40ac86:	push   r14
  40ac88:	push   r15
  40ac8a:	sub    rsp,0x178
  40ac91:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40ac9a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40aca3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40acac:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40acb5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40acbe:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40acc7:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40acd0:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40acd9:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40ace2:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40aceb:	mov    r12,rcx
  40acee:	lea    rax,[rip+0x1950b]        # 424200 <__swc_bss_base_23cea7fa+0x1c0>
  40acf5:	mov    rcx,QWORD PTR [rax]
  40acf8:	mov    r13,rcx
  40acfb:	test   rcx,rcx
  40acfe:	jne    40ad0e <__swc_fn_23cea7fa_000049_f6a485a2+0x8e>
  40ad00:	mov    r13d,0x1dcd6500
  40ad06:	mov    ecx,0x1dcd6500
  40ad0b:	xchg   QWORD PTR [rax],rcx
  40ad0e:	lea    rax,[rip+0x172eb]        # 422000 <__swc_data_base_23cea7fa>
  40ad15:	mov    rax,QWORD PTR [rax]
  40ad18:	cmp    rax,0xffffffffffffffff
  40ad1c:	je     40ad2b <__swc_fn_23cea7fa_000049_f6a485a2+0xab>
  40ad1e:	mov    eax,eax
  40ad20:	mov    edi,eax
  40ad22:	xor    eax,eax
  40ad24:	call   407000 <pthread_getspecific@plt>
  40ad29:	jmp    40ad2d <__swc_fn_23cea7fa_000049_f6a485a2+0xad>
  40ad2b:	xor    eax,eax
  40ad2d:	test   rax,rax
  40ad30:	jne    40ad3f <__swc_fn_23cea7fa_000049_f6a485a2+0xbf>
  40ad32:	call   40a9e0 <__swc_fn_23cea7fa_000031_3c3e930e>
  40ad37:	mov    rcx,rax
  40ad3a:	call   410520 <__swc_fn_23cea7fa_000128_8d8a7dd2>
  40ad3f:	test   rax,rax
  40ad42:	je     40ad54 <__swc_fn_23cea7fa_000049_f6a485a2+0xd4>
  40ad44:	cmp    QWORD PTR [rax],r12
  40ad47:	jne    40ad54 <__swc_fn_23cea7fa_000049_f6a485a2+0xd4>
  40ad49:	cmp    DWORD PTR [rax+0x20],0x0
  40ad4d:	jne    40ad54 <__swc_fn_23cea7fa_000049_f6a485a2+0xd4>
  40ad4f:	mov    rsi,rax
  40ad52:	jmp    40ad56 <__swc_fn_23cea7fa_000049_f6a485a2+0xd6>
  40ad54:	xor    esi,esi
  40ad56:	lea    rdi,[r12+0x2a88]
  40ad5e:	mov    r14,QWORD PTR [rdi]
  40ad61:	test   r14,r14
  40ad64:	jne    40adb3 <__swc_fn_23cea7fa_000049_f6a485a2+0x133>
  40ad66:	lea    rax,[rip+0x192eb]        # 424058 <__swc_bss_base_23cea7fa+0x18>
  40ad6d:	mov    rax,QWORD PTR [rax]
  40ad70:	test   rax,rax
  40ad73:	setne  al
  40ad76:	jne    40ad9a <__swc_fn_23cea7fa_000049_f6a485a2+0x11a>
  40ad78:	mov    rax,QWORD PTR [r12+0x2a70]
  40ad80:	test   rax,rax
  40ad83:	setne  al
  40ad86:	jne    40ad9a <__swc_fn_23cea7fa_000049_f6a485a2+0x11a>
  40ad88:	test   rsi,rsi
  40ad8b:	setne  al
  40ad8e:	je     40ad9a <__swc_fn_23cea7fa_000049_f6a485a2+0x11a>
  40ad90:	cmp    DWORD PTR [rsi+0x730],0x0
  40ad97:	setne  al
  40ad9a:	test   al,al
  40ad9c:	je     40adae <__swc_fn_23cea7fa_000049_f6a485a2+0x12e>
  40ad9e:	call   4105d0 <__swc_fn_23cea7fa_000131_91db8856>
  40ada3:	lea    rcx,[rax+r13*1]
  40ada7:	xor    eax,eax
  40ada9:	lock cmpxchg QWORD PTR [rdi],rcx
  40adae:	jmp    40aeb3 <__swc_fn_23cea7fa_000049_f6a485a2+0x233>
  40adb3:	call   4105d0 <__swc_fn_23cea7fa_000131_91db8856>
  40adb8:	mov    r15,rax
  40adbb:	cmp    rax,r14
  40adbe:	jb     40adcf <__swc_fn_23cea7fa_000049_f6a485a2+0x14f>
  40adc0:	xor    ecx,ecx
  40adc2:	mov    rax,r14
  40adc5:	lock cmpxchg QWORD PTR [rdi],rcx
  40adca:	cmp    rax,r14
  40adcd:	je     40add4 <__swc_fn_23cea7fa_000049_f6a485a2+0x154>
  40adcf:	jmp    40aeb3 <__swc_fn_23cea7fa_000049_f6a485a2+0x233>
  40add4:	test   rsi,rsi
  40add7:	je     40adf2 <__swc_fn_23cea7fa_000049_f6a485a2+0x172>
  40add9:	cmp    r15,r13
  40addc:	jb     40adf2 <__swc_fn_23cea7fa_000049_f6a485a2+0x172>
  40adde:	mov    rax,r15
  40ade1:	sub    rax,r13
  40ade4:	mov    rcx,r12
  40ade7:	mov    rdx,rsi
  40adea:	mov    r8,rax
  40aded:	call   40e930 <__swc_fn_23cea7fa_000059_ee6a254c>
  40adf2:	lea    rsi,[r12+0x10]
  40adf7:	mov    rcx,rsi
  40adfa:	call   4098a0 <__swc_fn_23cea7fa_000135_db32cc57>
  40adff:	mov    rax,QWORD PTR [r12+0x18]
  40ae04:	mov    rdi,rax
  40ae07:	test   rdi,rdi
  40ae0a:	je     40ae34 <__swc_fn_23cea7fa_000049_f6a485a2+0x1b4>
  40ae0c:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae16:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae20:	mov    rcx,rdi
  40ae23:	call   407470 <__swc_fn_23cea7fa_000015_96cb1311>
  40ae28:	mov    rax,QWORD PTR [rdi+0x10]
  40ae2c:	mov    rdi,rax
  40ae2f:	test   rax,rax
  40ae32:	jne    40ae20 <__swc_fn_23cea7fa_000049_f6a485a2+0x1a0>
  40ae34:	mov    rcx,rsi
  40ae37:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  40ae3c:	mov    rcx,r12
  40ae3f:	call   4098a0 <__swc_fn_23cea7fa_000135_db32cc57>
  40ae44:	xor    esi,esi
  40ae46:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae50:	mov    rax,QWORD PTR [r12+0x2a70]
  40ae58:	cmp    rsi,rax
  40ae5b:	jae    40aeab <__swc_fn_23cea7fa_000049_f6a485a2+0x22b>
  40ae5d:	lea    rax,[rsi+rsi*4]
  40ae61:	lea    rax,[r12+rax*8+0x268]
  40ae69:	mov    r8,QWORD PTR [rax]
  40ae6c:	mov    r9,QWORD PTR [rax+0x8]
  40ae70:	mov    r10,QWORD PTR [rax+0x10]
  40ae74:	mov    rax,QWORD PTR [rax+0x20]
  40ae78:	cmp    rax,r15
  40ae7b:	jae    40ae88 <__swc_fn_23cea7fa_000049_f6a485a2+0x208>
  40ae7d:	mov    rcx,r15
  40ae80:	sub    rcx,rax
  40ae83:	cmp    rcx,r13
  40ae86:	jae    40ae8d <__swc_fn_23cea7fa_000049_f6a485a2+0x20d>
  40ae88:	inc    rsi
  40ae8b:	jmp    40ae50 <__swc_fn_23cea7fa_000049_f6a485a2+0x1d0>
  40ae8d:	mov    rcx,r12
  40ae90:	mov    rdx,rsi
  40ae93:	call   40e8e0 <__swc_fn_23cea7fa_000056_87dc216f>
  40ae98:	mov    rcx,r12
  40ae9b:	mov    rdx,r8
  40ae9e:	mov    r8,r9
  40aea1:	mov    r9,r10
  40aea4:	call   407750 <__swc_fn_23cea7fa_000039_9ae4348f>
  40aea9:	jmp    40ae50 <__swc_fn_23cea7fa_000049_f6a485a2+0x1d0>
  40aeab:	mov    rcx,r12
  40aeae:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  40aeb3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40aebc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40aec5:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40aece:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40aed7:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40aee0:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40aee9:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40aef2:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40aefb:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40af04:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40af0d:	add    rsp,0x178
  40af14:	pop    r15
  40af16:	pop    r14
  40af18:	pop    rsi
  40af19:	pop    rdi
  40af1a:	pop    r13
  40af1c:	pop    r12
  40af1e:	ret
	...

000000000040af20 <__swc_fn_23cea7fa_000052_92b016ae>:
  40af20:	lea    rax,[rdx-0x58]
  40af24:	ret
	...

000000000040af30 <__swc_fn_23cea7fa_000055_ddf32775>:
  40af30:	push   rsi
  40af31:	push   rdi
  40af32:	push   r12
  40af34:	push   r13
  40af36:	sub    rsp,0x68
  40af3a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40af40:	mov    rsi,r9
  40af43:	mov    rdi,rcx
  40af46:	mov    r12,rdx
  40af49:	mov    r13,r8
  40af4c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40af54:	jne    40af63 <__swc_fn_23cea7fa_000055_ddf32775+0x33>
  40af56:	xor    eax,eax
  40af58:	add    rsp,0x68
  40af5c:	pop    r13
  40af5e:	pop    r12
  40af60:	pop    rdi
  40af61:	pop    rsi
  40af62:	ret
  40af63:	mov    rcx,rdi
  40af66:	call   4098a0 <__swc_fn_23cea7fa_000135_db32cc57>
  40af6b:	movabs rax,0x7fffffffffffffff
  40af75:	cmp    r12,rax
  40af78:	mov    rax,0xffffffffffffffff
  40af7f:	lea    rcx,[r12+r12*1]
  40af83:	cmovbe rax,rcx
  40af87:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40af8e:	mov    rdx,rcx
  40af91:	sub    rax,r12
  40af94:	inc    rax
  40af97:	xor    r8d,r8d
  40af9a:	test   rcx,rcx
  40af9d:	jbe    40afc8 <__swc_fn_23cea7fa_000055_ddf32775+0x98>
  40af9f:	nop
  40afa0:	lea    r9,[r8+r8*4]
  40afa4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40afac:	sub    r9,r12
  40afaf:	cmp    r9,rax
  40afb2:	jae    40afbf <__swc_fn_23cea7fa_000055_ddf32775+0x8f>
  40afb4:	mov    rdx,r8
  40afb7:	mov    rax,r9
  40afba:	test   r9,r9
  40afbd:	je     40afc8 <__swc_fn_23cea7fa_000055_ddf32775+0x98>
  40afbf:	add    r8,0x1
  40afc3:	cmp    r8,rcx
  40afc6:	jb     40afa0 <__swc_fn_23cea7fa_000055_ddf32775+0x70>
  40afc8:	mov    rax,QWORD PTR [rdi+0x2a70]
  40afcf:	cmp    rdx,rax
  40afd2:	jne    40afef <__swc_fn_23cea7fa_000055_ddf32775+0xbf>
  40afd4:	mov    rcx,rdi
  40afd7:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  40afdc:	xor    eax,eax
  40afde:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40afe4:	add    rsp,0x68
  40afe8:	pop    r13
  40afea:	pop    r12
  40afec:	pop    rdi
  40afed:	pop    rsi
  40afee:	ret
  40afef:	lea    rax,[rdx+rdx*4]
  40aff3:	lea    rax,[rdi+rax*8+0x268]
  40affb:	vmovups xmm6,XMMWORD PTR [rax]
  40afff:	mov    r8,QWORD PTR [rax+0x10]
  40b003:	mov    rcx,rdi
  40b006:	call   40e8e0 <__swc_fn_23cea7fa_000056_87dc216f>
  40b00b:	vpshufd xmm0,xmm6,0xee
  40b010:	vmovsd QWORD PTR [r13+0x0],xmm0
  40b016:	mov    QWORD PTR [rsi],r8
  40b019:	mov    rcx,rdi
  40b01c:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  40b021:	vmovq  rax,xmm6
  40b026:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b02c:	add    rsp,0x68
  40b030:	pop    r13
  40b032:	pop    r12
  40b034:	pop    rdi
  40b035:	pop    rsi
  40b036:	ret
	...

000000000040b040 <__swc_fn_23cea7fa_000058_01964a17>:
  40b040:	push   r12
  40b042:	push   r13
  40b044:	push   r14
  40b046:	push   r15
  40b048:	push   rdi
  40b049:	push   rsi
  40b04a:	sub    rsp,0x148
  40b051:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40b05a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40b063:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40b06c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40b075:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40b07e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40b087:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40b090:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40b099:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40b0a2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40b0ab:	mov    r12,r9
  40b0ae:	mov    r13,rcx
  40b0b1:	mov    r14,rdx
  40b0b4:	mov    r15,r8
  40b0b7:	test   rdx,rdx
  40b0ba:	jne    40b0ce <__swc_fn_23cea7fa_000058_01964a17+0x8e>
  40b0bc:	add    rsp,0x148
  40b0c3:	pop    rsi
  40b0c4:	pop    rdi
  40b0c5:	pop    r15
  40b0c7:	pop    r14
  40b0c9:	pop    r13
  40b0cb:	pop    r12
  40b0cd:	ret
  40b0ce:	cmp    r12,0x200000
  40b0d5:	ja     40b167 <__swc_fn_23cea7fa_000058_01964a17+0x127>
  40b0db:	lea    rax,[rip+0x16f1e]        # 422000 <__swc_data_base_23cea7fa>
  40b0e2:	mov    rax,QWORD PTR [rax]
  40b0e5:	cmp    rax,0xffffffffffffffff
  40b0e9:	je     40b0f8 <__swc_fn_23cea7fa_000058_01964a17+0xb8>
  40b0eb:	mov    eax,eax
  40b0ed:	mov    edi,eax
  40b0ef:	xor    eax,eax
  40b0f1:	call   407000 <pthread_getspecific@plt>
  40b0f6:	jmp    40b0fa <__swc_fn_23cea7fa_000058_01964a17+0xba>
  40b0f8:	xor    eax,eax
  40b0fa:	test   rax,rax
  40b0fd:	je     40b104 <__swc_fn_23cea7fa_000058_01964a17+0xc4>
  40b0ff:	mov    rsi,rax
  40b102:	jmp    40b114 <__swc_fn_23cea7fa_000058_01964a17+0xd4>
  40b104:	call   40a9e0 <__swc_fn_23cea7fa_000031_3c3e930e>
  40b109:	mov    rcx,rax
  40b10c:	call   410520 <__swc_fn_23cea7fa_000128_8d8a7dd2>
  40b111:	mov    rsi,rax
  40b114:	test   rsi,rsi
  40b117:	je     40b167 <__swc_fn_23cea7fa_000058_01964a17+0x127>
  40b119:	cmp    QWORD PTR [rsi],r13
  40b11c:	jne    40b167 <__swc_fn_23cea7fa_000058_01964a17+0x127>
  40b11e:	cmp    DWORD PTR [rsi+0x20],0x0
  40b122:	jne    40b167 <__swc_fn_23cea7fa_000058_01964a17+0x127>
  40b124:	cmp    DWORD PTR [rsi+0x730],0x10
  40b12b:	jae    40b167 <__swc_fn_23cea7fa_000058_01964a17+0x127>
  40b12d:	mov    eax,DWORD PTR [rsi+0x730]
  40b133:	lea    rdi,[rax+rax*4]
  40b137:	lea    rdi,[rsi+rdi*8+0x738]
  40b13f:	mov    QWORD PTR [rdi],r14
  40b142:	mov    QWORD PTR [rdi+0x8],r15
  40b146:	mov    QWORD PTR [rdi+0x10],r12
  40b14a:	mov    QWORD PTR [rdi+0x18],0x0
  40b152:	call   4105d0 <__swc_fn_23cea7fa_000131_91db8856>
  40b157:	mov    QWORD PTR [rdi+0x20],rax
  40b15b:	add    DWORD PTR [rsi+0x730],0x1
  40b162:	jmp    40b2c6 <__swc_fn_23cea7fa_000058_01964a17+0x286>
  40b167:	mov    rcx,r13
  40b16a:	call   407e90 <__swc_fn_23cea7fa_000057_01c75a1d>
  40b16f:	mov    rsi,rax
  40b172:	cmp    r12,rax
  40b175:	jbe    40b1aa <__swc_fn_23cea7fa_000058_01964a17+0x16a>
  40b177:	cmp    r12,0x10000000
  40b17e:	seta   al
  40b181:	ja     40b190 <__swc_fn_23cea7fa_000058_01964a17+0x150>
  40b183:	mov    rax,QWORD PTR [r13+0x2a70]
  40b18a:	test   rax,rax
  40b18d:	setne  al
  40b190:	test   al,al
  40b192:	je     40b1aa <__swc_fn_23cea7fa_000058_01964a17+0x16a>
  40b194:	mov    rcx,r13
  40b197:	mov    rdx,r14
  40b19a:	mov    r8,r15
  40b19d:	mov    r9,r12
  40b1a0:	call   407750 <__swc_fn_23cea7fa_000039_9ae4348f>
  40b1a5:	jmp    40b2c6 <__swc_fn_23cea7fa_000058_01964a17+0x286>
  40b1aa:	call   4105d0 <__swc_fn_23cea7fa_000131_91db8856>
  40b1af:	mov    rdi,rax
  40b1b2:	mov    rcx,r13
  40b1b5:	call   4098a0 <__swc_fn_23cea7fa_000135_db32cc57>
  40b1ba:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b1c2:	je     40b27a <__swc_fn_23cea7fa_000058_01964a17+0x23a>
  40b1c8:	nop    DWORD PTR [rax+rax*1+0x0]
  40b1d0:	cmp    QWORD PTR [r13+0x2a70],0x100
  40b1db:	jae    40b1f0 <__swc_fn_23cea7fa_000058_01964a17+0x1b0>
  40b1dd:	mov    rax,QWORD PTR [r13+0x2a68]
  40b1e4:	add    rax,r12
  40b1e7:	cmp    rax,rsi
  40b1ea:	jbe    40b27a <__swc_fn_23cea7fa_000058_01964a17+0x23a>
  40b1f0:	xor    eax,eax
  40b1f2:	mov    rcx,QWORD PTR [r13+0x2a70]
  40b1f9:	mov    edx,0x1
  40b1fe:	cmp    rcx,0x1
  40b202:	jbe    40b239 <__swc_fn_23cea7fa_000058_01964a17+0x1f9>
  40b204:	cs nop WORD PTR [rax+rax*1+0x0]
  40b20e:	xchg   ax,ax
  40b210:	lea    r8,[rdx+rdx*4]
  40b214:	lea    r8,[r13+r8*8+0x268]
  40b21c:	lea    r9,[rax+rax*4]
  40b220:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40b228:	cmp    QWORD PTR [r8+0x18],r9
  40b22c:	cmovb  rax,rdx
  40b230:	add    rdx,0x1
  40b234:	cmp    rdx,rcx
  40b237:	jb     40b210 <__swc_fn_23cea7fa_000058_01964a17+0x1d0>
  40b239:	lea    rcx,[rax+rax*4]
  40b23d:	lea    rcx,[r13+rcx*8+0x268]
  40b245:	mov    r8,QWORD PTR [rcx]
  40b248:	mov    r9,QWORD PTR [rcx+0x8]
  40b24c:	mov    r10,QWORD PTR [rcx+0x10]
  40b250:	mov    rcx,r13
  40b253:	mov    rdx,rax
  40b256:	call   40e8e0 <__swc_fn_23cea7fa_000056_87dc216f>
  40b25b:	mov    rcx,r13
  40b25e:	mov    rdx,r8
  40b261:	mov    r8,r9
  40b264:	mov    r9,r10
  40b267:	call   407750 <__swc_fn_23cea7fa_000039_9ae4348f>
  40b26c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b274:	jne    40b1d0 <__swc_fn_23cea7fa_000058_01964a17+0x190>
  40b27a:	add    QWORD PTR [r13+0x2a78],0x1
  40b282:	mov    rax,QWORD PTR [r13+0x2a70]
  40b289:	lea    rax,[rax+rax*4]
  40b28d:	lea    rax,[r13+rax*8+0x268]
  40b295:	mov    QWORD PTR [rax],r14
  40b298:	mov    QWORD PTR [rax+0x8],r15
  40b29c:	mov    QWORD PTR [rax+0x10],r12
  40b2a0:	mov    rcx,QWORD PTR [r13+0x2a78]
  40b2a7:	mov    QWORD PTR [rax+0x18],rcx
  40b2ab:	mov    QWORD PTR [rax+0x20],rdi
  40b2af:	add    QWORD PTR [r13+0x2a68],r12
  40b2b6:	add    QWORD PTR [r13+0x2a70],0x1
  40b2be:	mov    rcx,r13
  40b2c1:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  40b2c6:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40b2cf:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40b2d8:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40b2e1:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40b2ea:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40b2f3:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40b2fc:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40b305:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40b30e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40b317:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40b320:	add    rsp,0x148
  40b327:	pop    rsi
  40b328:	pop    rdi
  40b329:	pop    r15
  40b32b:	pop    r14
  40b32d:	pop    r13
  40b32f:	pop    r12
  40b331:	ret
	...

000000000040b340 <__swc_fn_23cea7fa_000061_73a9baa2>:
  40b340:	push   rbx
  40b341:	push   r12
  40b343:	push   r13
  40b345:	push   r14
  40b347:	push   r15
  40b349:	push   rdi
  40b34a:	push   rsi
  40b34b:	sub    rsp,0xf0
  40b352:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40b358:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40b35e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40b364:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40b36a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40b373:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40b37c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40b385:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40b38e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40b397:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40b3a0:	mov    eax,r8d
  40b3a3:	mov    rbx,rcx
  40b3a6:	mov    r12,rdx
  40b3a9:	mov    QWORD PTR [rsp+0x18],rdx
  40b3ae:	mov    ecx,DWORD PTR [r12+0x58]
  40b3b3:	mov    r13d,ecx
  40b3b6:	cmp    ecx,0x10
  40b3b9:	mov    ecx,0x10
  40b3be:	cmovb  r13d,ecx
  40b3c2:	test   r13d,r13d
  40b3c5:	mov    rcx,r13
  40b3c8:	mov    edx,0x8
  40b3cd:	cmove  ecx,edx
  40b3d0:	dec    rcx
  40b3d3:	mov    rdx,0xffffffffffffffff
  40b3da:	sub    rdx,rcx
  40b3dd:	xor    r14d,r14d
  40b3e0:	mov    r8,rcx
  40b3e3:	not    r8
  40b3e6:	lea    rcx,[rcx+0x58]
  40b3ea:	and    rcx,r8
  40b3ed:	cmp    rdx,0x58
  40b3f1:	cmovae r14,rcx
  40b3f5:	cmp    eax,0xffffffff
  40b3f8:	jne    40b401 <__swc_fn_23cea7fa_000061_73a9baa2+0xc1>
  40b3fa:	mov    r15,QWORD PTR [r12+0x48]
  40b3ff:	jmp    40b433 <__swc_fn_23cea7fa_000061_73a9baa2+0xf3>
  40b401:	test   eax,eax
  40b403:	jne    40b40c <__swc_fn_23cea7fa_000061_73a9baa2+0xcc>
  40b405:	mov    eax,0x8
  40b40a:	jmp    40b430 <__swc_fn_23cea7fa_000061_73a9baa2+0xf0>
  40b40c:	cmp    eax,0x8
  40b40f:	ja     40b417 <__swc_fn_23cea7fa_000061_73a9baa2+0xd7>
  40b411:	shl    rax,0x4
  40b415:	jmp    40b430 <__swc_fn_23cea7fa_000061_73a9baa2+0xf0>
  40b417:	lea    eax,[rax-0x9]
  40b41a:	mov    ecx,eax
  40b41c:	shr    ecx,0x2
  40b41f:	and    eax,0x3
  40b422:	lea    ecx,[rcx+0x7]
  40b425:	lea    ecx,[rcx-0x2]
  40b428:	lea    eax,[rax+0x5]
  40b42b:	shlx   rax,rax,rcx
  40b430:	mov    r15,rax
  40b433:	lea    rax,[r14+r13*1]
  40b437:	mov    rcx,0xffffffffffffffff
  40b43e:	sub    rcx,rax
  40b441:	cmp    r15,rcx
  40b444:	jbe    40b454 <__swc_fn_23cea7fa_000061_73a9baa2+0x114>
  40b446:	mov    QWORD PTR [r12+0x40],0x0
  40b44f:	jmp    40b826 <__swc_fn_23cea7fa_000061_73a9baa2+0x4e6>
  40b454:	mov    QWORD PTR [rsp+0x20],r13
  40b459:	lea    r13,[rsp+0x8]
  40b45e:	add    rax,r15
  40b461:	mov    ecx,0x1000
  40b466:	test   ecx,ecx
  40b468:	mov    edx,0x8
  40b46d:	cmove  ecx,edx
  40b470:	dec    rcx
  40b473:	mov    rdx,0xffffffffffffffff
  40b47a:	sub    rdx,rcx
  40b47d:	cmp    rax,rdx
  40b480:	jbe    40b48c <__swc_fn_23cea7fa_000061_73a9baa2+0x14c>
  40b482:	mov    QWORD PTR [r13+0x0],0x0
  40b48a:	jmp    40b499 <__swc_fn_23cea7fa_000061_73a9baa2+0x159>
  40b48c:	add    rax,rcx
  40b48f:	andn   rax,rcx,rax
  40b494:	mov    QWORD PTR [rsp+0x8],rax
  40b499:	cmp    QWORD PTR [r13+0x0],0x0
  40b49e:	jne    40b4ae <__swc_fn_23cea7fa_000061_73a9baa2+0x16e>
  40b4a0:	mov    QWORD PTR [r12+0x40],0x0
  40b4a9:	jmp    40b826 <__swc_fn_23cea7fa_000061_73a9baa2+0x4e6>
  40b4ae:	mov    QWORD PTR [rsp+0x30],r15
  40b4b3:	xor    r15d,r15d
  40b4b6:	mov    QWORD PTR [rsp+0x38],0x0
  40b4bf:	lea    r12,[rsp+0x10]
  40b4c4:	mov    QWORD PTR [rsp+0x28],r14
  40b4c9:	mov    r14,QWORD PTR [rsp+0x8]
  40b4ce:	mov    QWORD PTR [rsp+0x10],r14
  40b4d3:	cmp    r14,0x10000
  40b4da:	ja     40b4e1 <__swc_fn_23cea7fa_000061_73a9baa2+0x1a1>
  40b4dc:	mov    rax,r14
  40b4df:	jmp    40b532 <__swc_fn_23cea7fa_000061_73a9baa2+0x1f2>
  40b4e1:	xor    eax,eax
  40b4e3:	lea    rcx,[r14-0x1]
  40b4e7:	lzcnt  rax,rcx
  40b4ec:	mov    ecx,0x3f
  40b4f1:	sub    rcx,rax
  40b4f4:	mov    eax,0x1
  40b4f9:	lea    rcx,[rcx-0x3]
  40b4fd:	shl    rax,cl
  40b500:	mov    rcx,rax
  40b503:	cmp    rax,0x1000
  40b50a:	mov    eax,0x1000
  40b50f:	cmovb  rcx,rax
  40b513:	mov    rdx,0xffffffffffffffff
  40b51a:	sub    rdx,rcx
  40b51d:	mov    rax,r14
  40b520:	lea    r8,[r14+rcx*1-0x1]
  40b525:	neg    rcx
  40b528:	and    r8,rcx
  40b52b:	cmp    r14,rdx
  40b52e:	cmovbe rax,r8
  40b532:	mov    QWORD PTR [rsp+0x8],rax
  40b537:	lea    rax,[rip+0x16ac2]        # 422000 <__swc_data_base_23cea7fa>
  40b53e:	mov    rax,QWORD PTR [rax]
  40b541:	cmp    rax,0xffffffffffffffff
  40b545:	je     40b554 <__swc_fn_23cea7fa_000061_73a9baa2+0x214>
  40b547:	mov    eax,eax
  40b549:	mov    edi,eax
  40b54b:	xor    eax,eax
  40b54d:	call   407000 <pthread_getspecific@plt>
  40b552:	jmp    40b556 <__swc_fn_23cea7fa_000061_73a9baa2+0x216>
  40b554:	xor    eax,eax
  40b556:	test   rax,rax
  40b559:	jne    40b568 <__swc_fn_23cea7fa_000061_73a9baa2+0x228>
  40b55b:	call   40a9e0 <__swc_fn_23cea7fa_000031_3c3e930e>
  40b560:	mov    rcx,rax
  40b563:	call   410520 <__swc_fn_23cea7fa_000128_8d8a7dd2>
  40b568:	test   rax,rax
  40b56b:	je     40b65c <__swc_fn_23cea7fa_000061_73a9baa2+0x31c>
  40b571:	cmp    QWORD PTR [rax],rbx
  40b574:	jne    40b65c <__swc_fn_23cea7fa_000061_73a9baa2+0x31c>
  40b57a:	cmp    DWORD PTR [rax+0x20],0x0
  40b57e:	jne    40b65c <__swc_fn_23cea7fa_000061_73a9baa2+0x31c>
  40b584:	mov    rcx,QWORD PTR [rsp+0x8]
  40b589:	movabs rdx,0x7fffffffffffffff
  40b593:	cmp    rcx,rdx
  40b596:	mov    rdx,0xffffffffffffffff
  40b59d:	lea    r8,[rcx+rcx*1]
  40b5a1:	cmovbe rdx,r8
  40b5a5:	mov    r8d,DWORD PTR [rax+0x730]
  40b5ac:	mov    r9d,r8d
  40b5af:	sub    rdx,rcx
  40b5b2:	inc    rdx
  40b5b5:	xor    r10d,r10d
  40b5b8:	test   r8,r8
  40b5bb:	jbe    40b5eb <__swc_fn_23cea7fa_000061_73a9baa2+0x2ab>
  40b5bd:	nop    DWORD PTR [rax]
  40b5c0:	mov    r11d,r10d
  40b5c3:	lea    r11,[r11+r11*4]
  40b5c7:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40b5cf:	sub    r11,rcx
  40b5d2:	cmp    r11,rdx
  40b5d5:	jae    40b5e2 <__swc_fn_23cea7fa_000061_73a9baa2+0x2a2>
  40b5d7:	mov    r9d,r10d
  40b5da:	mov    rdx,r11
  40b5dd:	test   r11,r11
  40b5e0:	je     40b5eb <__swc_fn_23cea7fa_000061_73a9baa2+0x2ab>
  40b5e2:	add    r10,0x1
  40b5e6:	cmp    r10,r8
  40b5e9:	jb     40b5c0 <__swc_fn_23cea7fa_000061_73a9baa2+0x280>
  40b5eb:	mov    ecx,DWORD PTR [rax+0x730]
  40b5f1:	cmp    r9d,ecx
  40b5f4:	jne    40b5fa <__swc_fn_23cea7fa_000061_73a9baa2+0x2ba>
  40b5f6:	xor    eax,eax
  40b5f8:	jmp    40b659 <__swc_fn_23cea7fa_000061_73a9baa2+0x319>
  40b5fa:	lea    rcx,[r9+r9*4]
  40b5fe:	lea    rcx,[rax+rcx*8+0x738]
  40b606:	vmovups xmm0,XMMWORD PTR [rcx]
  40b60a:	mov    rdx,QWORD PTR [rcx+0x10]
  40b60e:	sub    DWORD PTR [rax+0x730],0x1
  40b615:	mov    r8d,DWORD PTR [rax+0x730]
  40b61c:	lea    r8,[r8+r8*4]
  40b620:	lea    r8,[rax+r8*8+0x738]
  40b628:	vmovups xmm1,XMMWORD PTR [r8]
  40b62d:	vmovups XMMWORD PTR [rcx],xmm1
  40b631:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40b637:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40b63c:	mov    rax,QWORD PTR [r8+0x20]
  40b640:	mov    QWORD PTR [rcx+0x20],rax
  40b644:	vpshufd xmm1,xmm0,0xee
  40b649:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40b64f:	mov    QWORD PTR [rsp+0x10],rdx
  40b654:	vmovq  rax,xmm0
  40b659:	mov    r15,rax
  40b65c:	test   r15,r15
  40b65f:	jne    40b677 <__swc_fn_23cea7fa_000061_73a9baa2+0x337>
  40b661:	mov    rcx,rbx
  40b664:	mov    rdx,QWORD PTR [rsp+0x8]
  40b669:	mov    r8,r13
  40b66c:	mov    r9,r12
  40b66f:	call   40af30 <__swc_fn_23cea7fa_000055_ddf32775>
  40b674:	mov    r15,rax
  40b677:	test   r15,r15
  40b67a:	je     40b6bb <__swc_fn_23cea7fa_000061_73a9baa2+0x37b>
  40b67c:	cmp    QWORD PTR [r12],r14
  40b680:	jae    40b6bb <__swc_fn_23cea7fa_000061_73a9baa2+0x37b>
  40b682:	mov    rax,r15
  40b685:	add    rax,QWORD PTR [r12]
  40b689:	mov    rdx,r14
  40b68c:	sub    rdx,QWORD PTR [r12]
  40b690:	mov    rcx,rax
  40b693:	call   4072a0 <__swc_fn_23cea7fa_000003_81215399>
  40b698:	test   al,al
  40b69a:	je     40b6a3 <__swc_fn_23cea7fa_000061_73a9baa2+0x363>
  40b69c:	mov    QWORD PTR [rsp+0x10],r14
  40b6a1:	jmp    40b6bb <__swc_fn_23cea7fa_000061_73a9baa2+0x37b>
  40b6a3:	mov    rcx,rbx
  40b6a6:	mov    rdx,r15
  40b6a9:	mov    r8,QWORD PTR [rsp+0x8]
  40b6ae:	mov    r9,QWORD PTR [rsp+0x10]
  40b6b3:	call   40b040 <__swc_fn_23cea7fa_000058_01964a17>
  40b6b8:	xor    r15d,r15d
  40b6bb:	test   r15,r15
  40b6be:	jne    40b73a <__swc_fn_23cea7fa_000061_73a9baa2+0x3fa>
  40b6c0:	cmp    r14,0x10000
  40b6c7:	ja     40b6ce <__swc_fn_23cea7fa_000061_73a9baa2+0x38e>
  40b6c9:	mov    rax,r14
  40b6cc:	jmp    40b71f <__swc_fn_23cea7fa_000061_73a9baa2+0x3df>
  40b6ce:	xor    eax,eax
  40b6d0:	lea    rcx,[r14-0x1]
  40b6d4:	lzcnt  rax,rcx
  40b6d9:	mov    ecx,0x3f
  40b6de:	sub    rcx,rax
  40b6e1:	mov    eax,0x1
  40b6e6:	lea    rcx,[rcx-0x3]
  40b6ea:	shl    rax,cl
  40b6ed:	mov    rcx,rax
  40b6f0:	cmp    rax,0x1000
  40b6f7:	mov    eax,0x1000
  40b6fc:	cmovb  rcx,rax
  40b700:	mov    rdx,0xffffffffffffffff
  40b707:	sub    rdx,rcx
  40b70a:	mov    rax,r14
  40b70d:	lea    r8,[r14+rcx*1-0x1]
  40b712:	neg    rcx
  40b715:	and    r8,rcx
  40b718:	cmp    r14,rdx
  40b71b:	cmovbe rax,r8
  40b71f:	mov    QWORD PTR [rsp+0x8],rax
  40b724:	mov    QWORD PTR [rsp+0x10],r14
  40b729:	mov    rcx,rbx
  40b72c:	mov    rdx,rax
  40b72f:	mov    r8,r14
  40b732:	call   40aaa0 <__swc_fn_23cea7fa_000037_1e381f55>
  40b737:	mov    r15,rax
  40b73a:	test   r15,r15
  40b73d:	jne    40b74b <__swc_fn_23cea7fa_000061_73a9baa2+0x40b>
  40b73f:	mov    r13,QWORD PTR [rsp+0x20]
  40b744:	mov    rsi,QWORD PTR [rsp+0x38]
  40b749:	jmp    40b787 <__swc_fn_23cea7fa_000061_73a9baa2+0x447>
  40b74b:	mov    rax,r15
  40b74e:	add    rax,QWORD PTR [rsp+0x28]
  40b753:	mov    r13,QWORD PTR [rsp+0x20]
  40b758:	test   r13d,r13d
  40b75b:	mov    rcx,r13
  40b75e:	mov    edx,0x8
  40b763:	cmove  ecx,edx
  40b766:	dec    rcx
  40b769:	mov    rdx,0xffffffffffffffff
  40b770:	sub    rdx,rcx
  40b773:	cmp    rax,rdx
  40b776:	jbe    40b77c <__swc_fn_23cea7fa_000061_73a9baa2+0x43c>
  40b778:	xor    eax,eax
  40b77a:	jmp    40b784 <__swc_fn_23cea7fa_000061_73a9baa2+0x444>
  40b77c:	add    rax,rcx
  40b77f:	andn   rax,rcx,rax
  40b784:	mov    rsi,rax
  40b787:	mov    rax,QWORD PTR [rsp+0x8]
  40b78c:	test   r15,r15
  40b78f:	je     40b798 <__swc_fn_23cea7fa_000061_73a9baa2+0x458>
  40b791:	mov    rdi,QWORD PTR [rsp+0x18]
  40b796:	jmp    40b7aa <__swc_fn_23cea7fa_000061_73a9baa2+0x46a>
  40b798:	mov    rdi,QWORD PTR [rsp+0x18]
  40b79d:	mov    QWORD PTR [rdi+0x40],0x0
  40b7a5:	jmp    40b826 <__swc_fn_23cea7fa_000061_73a9baa2+0x4e6>
  40b7aa:	lea    rdx,[rsi-0x58]
  40b7ae:	mov    QWORD PTR [rsi-0x58],r15
  40b7b2:	mov    QWORD PTR [rsi-0x50],rax
  40b7b6:	mov    rax,QWORD PTR [rsp+0x10]
  40b7bb:	mov    QWORD PTR [rsi-0x48],rax
  40b7bf:	mov    QWORD PTR [rsi-0x40],rsi
  40b7c3:	mov    rax,QWORD PTR [rdi+0x48]
  40b7c7:	mov    QWORD PTR [rsi-0x38],rax
  40b7cb:	mov    rax,QWORD PTR [rsp+0x30]
  40b7d0:	mov    QWORD PTR [rsi-0x30],rax
  40b7d4:	mov    DWORD PTR [rsi-0x10],r13d
  40b7d8:	mov    QWORD PTR [rsi-0x28],0x0
  40b7e0:	mov    QWORD PTR [rsi-0x20],0x0
  40b7e8:	add    r15,QWORD PTR [r12]
  40b7ec:	sub    r15,rsi
  40b7ef:	mov    QWORD PTR [rsi-0x30],r15
  40b7f3:	mov    rcx,QWORD PTR [rbx+0x250]
  40b7fa:	nop    WORD PTR [rax+rax*1+0x0]
  40b800:	lea    r8,[rcx+r15*1]
  40b804:	mov    rax,rcx
  40b807:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40b810:	cmp    rax,rcx
  40b813:	je     40b81a <__swc_fn_23cea7fa_000061_73a9baa2+0x4da>
  40b815:	mov    rcx,rax
  40b818:	jmp    40b800 <__swc_fn_23cea7fa_000061_73a9baa2+0x4c0>
  40b81a:	mov    rcx,rbx
  40b81d:	call   40e850 <__swc_fn_23cea7fa_000053_9aa81fa7>
  40b822:	mov    QWORD PTR [rdi+0x40],rsi
  40b826:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40b82c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40b832:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40b838:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40b83e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40b847:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40b850:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40b859:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40b862:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40b86b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40b874:	add    rsp,0xf0
  40b87b:	pop    rsi
  40b87c:	pop    rdi
  40b87d:	pop    r15
  40b87f:	pop    r14
  40b881:	pop    r13
  40b883:	pop    r12
  40b885:	pop    rbx
  40b886:	ret
	...

000000000040b890 <__swc_fn_23cea7fa_000064_20100e91>:
  40b890:	push   rbx
  40b891:	push   r12
  40b893:	push   rdi
  40b894:	push   rsi
  40b895:	sub    rsp,0xb8
  40b89c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40b8a2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40b8a8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40b8ae:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40b8b4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40b8ba:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40b8c0:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40b8c6:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40b8cf:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40b8d8:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40b8e1:	mov    rbx,rdx
  40b8e4:	mov    r12,rcx
  40b8e7:	cmp    DWORD PTR [rbx+0x58],0x0
  40b8eb:	je     40b905 <__swc_fn_23cea7fa_000064_20100e91+0x75>
  40b8ed:	mov    eax,DWORD PTR [rbx+0x58]
  40b8f0:	sub    eax,0x1
  40b8f3:	test   DWORD PTR [rbx+0x58],eax
  40b8f6:	je     40b905 <__swc_fn_23cea7fa_000064_20100e91+0x75>
  40b8f8:	mov    QWORD PTR [rbx+0x40],0x0
  40b900:	jmp    40bb17 <__swc_fn_23cea7fa_000064_20100e91+0x287>
  40b905:	cmp    QWORD PTR [rbx+0x48],0x0
  40b90a:	jne    40b919 <__swc_fn_23cea7fa_000064_20100e91+0x89>
  40b90c:	mov    QWORD PTR [rbx+0x40],0x0
  40b914:	jmp    40bb17 <__swc_fn_23cea7fa_000064_20100e91+0x287>
  40b919:	lea    rax,[rsp+0x8]
  40b91e:	mov    rcx,QWORD PTR [rbx+0x48]
  40b922:	cmp    rcx,0x8
  40b926:	ja     40b930 <__swc_fn_23cea7fa_000064_20100e91+0xa0>
  40b928:	mov    DWORD PTR [rax],0x0
  40b92e:	jmp    40b98b <__swc_fn_23cea7fa_000064_20100e91+0xfb>
  40b930:	cmp    rcx,0x80
  40b937:	ja     40b947 <__swc_fn_23cea7fa_000064_20100e91+0xb7>
  40b939:	lea    rcx,[rcx+0xf]
  40b93d:	shr    rcx,0x4
  40b941:	mov    DWORD PTR [rsp+0x8],ecx
  40b945:	jmp    40b98b <__swc_fn_23cea7fa_000064_20100e91+0xfb>
  40b947:	cmp    rcx,0x10000
  40b94e:	jbe    40b958 <__swc_fn_23cea7fa_000064_20100e91+0xc8>
  40b950:	mov    DWORD PTR [rax],0xffffffff
  40b956:	jmp    40b98b <__swc_fn_23cea7fa_000064_20100e91+0xfb>
  40b958:	dec    rcx
  40b95b:	xor    edx,edx
  40b95d:	lzcnt  rdx,rcx
  40b962:	mov    r8d,0x3f
  40b968:	sub    r8d,edx
  40b96b:	lea    edx,[r8-0x2]
  40b96f:	shrx   rcx,rcx,rdx
  40b974:	and    ecx,0x3
  40b977:	lea    edx,[r8-0x7]
  40b97b:	lea    edx,[rdx*4+0x0]
  40b982:	lea    edx,[rdx+0x9]
  40b985:	add    edx,ecx
  40b987:	mov    DWORD PTR [rsp+0x8],edx
  40b98b:	cmp    DWORD PTR [rax],0x0
  40b98e:	jne    40b99e <__swc_fn_23cea7fa_000064_20100e91+0x10e>
  40b990:	cmp    DWORD PTR [rbx+0x58],0x8
  40b994:	jbe    40b99e <__swc_fn_23cea7fa_000064_20100e91+0x10e>
  40b996:	mov    DWORD PTR [rsp+0x8],0x1
  40b99e:	cmp    DWORD PTR [rbx+0x58],0x10
  40b9a2:	jbe    40ba21 <__swc_fn_23cea7fa_000064_20100e91+0x191>
  40b9a8:	cmp    DWORD PTR [rbx+0x58],0x40
  40b9ac:	ja     40ba21 <__swc_fn_23cea7fa_000064_20100e91+0x191>
  40b9ae:	cmp    DWORD PTR [rax],0xffffffff
  40b9b1:	je     40ba21 <__swc_fn_23cea7fa_000064_20100e91+0x191>
  40b9b3:	mov    ecx,DWORD PTR [rsp+0x8]
  40b9b7:	mov    edx,DWORD PTR [rbx+0x58]
  40b9ba:	dec    rdx
  40b9bd:	cmp    ecx,0x2d
  40b9c0:	jae    40ba18 <__swc_fn_23cea7fa_000064_20100e91+0x188>
  40b9c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40b9cc:	nop    DWORD PTR [rax+0x0]
  40b9d0:	mov    r8d,ecx
  40b9d3:	test   ecx,ecx
  40b9d5:	jne    40b9df <__swc_fn_23cea7fa_000064_20100e91+0x14f>
  40b9d7:	mov    r8d,0x8
  40b9dd:	jmp    40ba0b <__swc_fn_23cea7fa_000064_20100e91+0x17b>
  40b9df:	cmp    r8d,0x8
  40b9e3:	ja     40b9eb <__swc_fn_23cea7fa_000064_20100e91+0x15b>
  40b9e5:	shl    r8,0x4
  40b9e9:	jmp    40ba0b <__swc_fn_23cea7fa_000064_20100e91+0x17b>
  40b9eb:	lea    r8d,[r8-0x9]
  40b9ef:	mov    r9d,r8d
  40b9f2:	shr    r9d,0x2
  40b9f6:	and    r8d,0x3
  40b9fa:	lea    r9d,[r9+0x7]
  40b9fe:	lea    r9d,[r9-0x2]
  40ba02:	lea    r8d,[r8+0x5]
  40ba06:	shlx   r8,r8,r9
  40ba0b:	test   r8,rdx
  40ba0e:	je     40ba1d <__swc_fn_23cea7fa_000064_20100e91+0x18d>
  40ba10:	add    ecx,0x1
  40ba13:	cmp    ecx,0x2d
  40ba16:	jb     40b9d0 <__swc_fn_23cea7fa_000064_20100e91+0x140>
  40ba18:	mov    ecx,0xffffffff
  40ba1d:	mov    DWORD PTR [rsp+0x8],ecx
  40ba21:	mov    ecx,DWORD PTR [rsp+0x8]
  40ba25:	cmp    ecx,0xffffffff
  40ba28:	je     40ba30 <__swc_fn_23cea7fa_000064_20100e91+0x1a0>
  40ba2a:	cmp    DWORD PTR [rbx+0x58],0x40
  40ba2e:	jbe    40ba43 <__swc_fn_23cea7fa_000064_20100e91+0x1b3>
  40ba30:	mov    rcx,r12
  40ba33:	mov    rdx,rbx
  40ba36:	mov    r8d,DWORD PTR [rax]
  40ba39:	call   40b340 <__swc_fn_23cea7fa_000061_73a9baa2>
  40ba3e:	jmp    40bb17 <__swc_fn_23cea7fa_000064_20100e91+0x287>
  40ba43:	lea    rax,[rip+0x165b6]        # 422000 <__swc_data_base_23cea7fa>
  40ba4a:	mov    rax,QWORD PTR [rax]
  40ba4d:	cmp    rax,0xffffffffffffffff
  40ba51:	je     40ba60 <__swc_fn_23cea7fa_000064_20100e91+0x1d0>
  40ba53:	mov    eax,eax
  40ba55:	mov    edi,eax
  40ba57:	xor    eax,eax
  40ba59:	call   407000 <pthread_getspecific@plt>
  40ba5e:	jmp    40ba62 <__swc_fn_23cea7fa_000064_20100e91+0x1d2>
  40ba60:	xor    eax,eax
  40ba62:	test   rax,rax
  40ba65:	jne    40ba74 <__swc_fn_23cea7fa_000064_20100e91+0x1e4>
  40ba67:	call   40a9e0 <__swc_fn_23cea7fa_000031_3c3e930e>
  40ba6c:	mov    rcx,rax
  40ba6f:	call   410520 <__swc_fn_23cea7fa_000128_8d8a7dd2>
  40ba74:	test   rax,rax
  40ba77:	je     40ba84 <__swc_fn_23cea7fa_000064_20100e91+0x1f4>
  40ba79:	cmp    QWORD PTR [rax],r12
  40ba7c:	jne    40ba84 <__swc_fn_23cea7fa_000064_20100e91+0x1f4>
  40ba7e:	cmp    DWORD PTR [rax+0x20],0x0
  40ba82:	je     40ba8f <__swc_fn_23cea7fa_000064_20100e91+0x1ff>
  40ba84:	mov    rcx,r12
  40ba87:	mov    rdx,rax
  40ba8a:	call   40e490 <__swc_fn_23cea7fa_000041_41400651>
  40ba8f:	test   rax,rax
  40ba92:	jne    40ba9e <__swc_fn_23cea7fa_000064_20100e91+0x20e>
  40ba94:	mov    QWORD PTR [rbx+0x40],0x0
  40ba9c:	jmp    40bb17 <__swc_fn_23cea7fa_000064_20100e91+0x287>
  40ba9e:	lea    r8,[rsp+0xc]
  40baa3:	mov    ecx,DWORD PTR [rsp+0x8]
  40baa7:	mov    DWORD PTR [rsp+0xc],ecx
  40baab:	mov    ecx,DWORD PTR [r8]
  40baae:	lea    rcx,[rcx+rcx*4]
  40bab2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40bab7:	test   rcx,rcx
  40baba:	je     40baf3 <__swc_fn_23cea7fa_000064_20100e91+0x263>
  40babc:	mov    rdx,QWORD PTR [rcx]
  40babf:	test   rdx,rdx
  40bac2:	je     40bad0 <__swc_fn_23cea7fa_000064_20100e91+0x240>
  40bac4:	mov    r9,QWORD PTR [rdx]
  40bac7:	mov    QWORD PTR [rcx],r9
  40baca:	add    DWORD PTR [rcx+0x28],0x1
  40bace:	jmp    40baee <__swc_fn_23cea7fa_000064_20100e91+0x25e>
  40bad0:	mov    rdx,QWORD PTR [rcx+0x18]
  40bad4:	cmp    QWORD PTR [rcx+0x20],rdx
  40bad8:	jae    40baec <__swc_fn_23cea7fa_000064_20100e91+0x25c>
  40bada:	mov    rdx,QWORD PTR [rcx+0x20]
  40bade:	mov    r9d,DWORD PTR [rcx+0x2c]
  40bae2:	add    QWORD PTR [rcx+0x20],r9
  40bae6:	add    DWORD PTR [rcx+0x28],0x1
  40baea:	jmp    40baee <__swc_fn_23cea7fa_000064_20100e91+0x25e>
  40baec:	xor    edx,edx
  40baee:	test   rdx,rdx
  40baf1:	jne    40bb04 <__swc_fn_23cea7fa_000064_20100e91+0x274>
  40baf3:	mov    rcx,r12
  40baf6:	mov    rdx,rax
  40baf9:	mov    r8d,DWORD PTR [r8]
  40bafc:	call   40e600 <__swc_fn_23cea7fa_000050_5e919db9>
  40bb01:	mov    rdx,rax
  40bb04:	test   rdx,rdx
  40bb07:	jne    40bb13 <__swc_fn_23cea7fa_000064_20100e91+0x283>
  40bb09:	mov    QWORD PTR [rbx+0x40],0x0
  40bb11:	jmp    40bb17 <__swc_fn_23cea7fa_000064_20100e91+0x287>
  40bb13:	mov    QWORD PTR [rbx+0x40],rdx
  40bb17:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40bb1d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40bb23:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40bb29:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40bb2f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40bb35:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40bb3b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40bb41:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40bb4a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40bb53:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40bb5c:	add    rsp,0xb8
  40bb63:	pop    rsi
  40bb64:	pop    rdi
  40bb65:	pop    r12
  40bb67:	pop    rbx
  40bb68:	ret
  40bb69:	add    BYTE PTR [rax],al
  40bb6b:	add    BYTE PTR [rax],al
  40bb6d:	add    BYTE PTR [rax],al
	...

000000000040bb70 <__swc_fn_23cea7fa_000067_0145abfc>:
  40bb70:	ret
	...

000000000040bb80 <__swc_fn_23cea7fa_000070_357c932c>:
  40bb80:	push   r12
  40bb82:	push   r13
  40bb84:	push   r14
  40bb86:	push   rdi
  40bb87:	push   rsi
  40bb88:	sub    rsp,0x1a0
  40bb8f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40bb98:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40bba1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40bbaa:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40bbb3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40bbbc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40bbc5:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40bbce:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40bbd7:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40bbe0:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40bbe9:	mov    r12,rdx
  40bbec:	mov    r13,rcx
  40bbef:	mov    rax,QWORD PTR [r12+0x48]
  40bbf4:	mov    ecx,DWORD PTR [r12+0x58]
  40bbf9:	lea    rdx,[rax-0x1]
  40bbfd:	cmp    rdx,0x10000
  40bc04:	jae    40bcfe <__swc_fn_23cea7fa_000070_357c932c+0x17e>
  40bc0a:	cmp    rax,0x8
  40bc0e:	ja     40bc15 <__swc_fn_23cea7fa_000070_357c932c+0x95>
  40bc10:	xor    r14d,r14d
  40bc13:	jmp    40bc67 <__swc_fn_23cea7fa_000070_357c932c+0xe7>
  40bc15:	cmp    rax,0x80
  40bc1c:	ja     40bc28 <__swc_fn_23cea7fa_000070_357c932c+0xa8>
  40bc1e:	lea    r14,[rax+0xf]
  40bc22:	shr    r14,0x4
  40bc26:	jmp    40bc67 <__swc_fn_23cea7fa_000070_357c932c+0xe7>
  40bc28:	cmp    rax,0x10000
  40bc2f:	jbe    40bc39 <__swc_fn_23cea7fa_000070_357c932c+0xb9>
  40bc31:	mov    r14d,0xffffffff
  40bc37:	jmp    40bc67 <__swc_fn_23cea7fa_000070_357c932c+0xe7>
  40bc39:	xor    eax,eax
  40bc3b:	lzcnt  rax,rdx
  40bc40:	mov    r8d,0x3f
  40bc46:	sub    r8d,eax
  40bc49:	lea    eax,[r8-0x2]
  40bc4d:	shrx   rax,rdx,rax
  40bc52:	and    eax,0x3
  40bc55:	lea    edx,[r8-0x7]
  40bc59:	lea    edx,[rdx*4+0x0]
  40bc60:	lea    edx,[rdx+0x9]
  40bc63:	lea    r14d,[rdx+rax*1]
  40bc67:	cmp    ecx,0x8
  40bc6a:	jbe    40bc83 <__swc_fn_23cea7fa_000070_357c932c+0x103>
  40bc6c:	cmp    ecx,0x10
  40bc6f:	jne    40bcfe <__swc_fn_23cea7fa_000070_357c932c+0x17e>
  40bc75:	test   r14d,r14d
  40bc78:	mov    eax,0x1
  40bc7d:	cmove  r14d,eax
  40bc81:	jmp    40bc8a <__swc_fn_23cea7fa_000070_357c932c+0x10a>
  40bc83:	lea    eax,[rcx-0x1]
  40bc86:	test   eax,ecx
  40bc88:	jne    40bcfe <__swc_fn_23cea7fa_000070_357c932c+0x17e>
  40bc8a:	lea    rax,[rip+0x1636f]        # 422000 <__swc_data_base_23cea7fa>
  40bc91:	mov    rax,QWORD PTR [rax]
  40bc94:	cmp    rax,0xffffffffffffffff
  40bc98:	je     40bca7 <__swc_fn_23cea7fa_000070_357c932c+0x127>
  40bc9a:	mov    eax,eax
  40bc9c:	mov    edi,eax
  40bc9e:	xor    eax,eax
  40bca0:	call   407000 <pthread_getspecific@plt>
  40bca5:	jmp    40bca9 <__swc_fn_23cea7fa_000070_357c932c+0x129>
  40bca7:	xor    eax,eax
  40bca9:	test   rax,rax
  40bcac:	je     40bcfe <__swc_fn_23cea7fa_000070_357c932c+0x17e>
  40bcae:	cmp    QWORD PTR [rax],r13
  40bcb1:	jne    40bcfe <__swc_fn_23cea7fa_000070_357c932c+0x17e>
  40bcb3:	lea    rcx,[r14+r14*4]
  40bcb7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40bcbc:	test   rax,rax
  40bcbf:	je     40bcfe <__swc_fn_23cea7fa_000070_357c932c+0x17e>
  40bcc1:	mov    rcx,QWORD PTR [rax]
  40bcc4:	test   rcx,rcx
  40bcc7:	je     40bcd5 <__swc_fn_23cea7fa_000070_357c932c+0x155>
  40bcc9:	mov    rdx,QWORD PTR [rcx]
  40bccc:	mov    QWORD PTR [rax],rdx
  40bccf:	add    DWORD PTR [rax+0x28],0x1
  40bcd3:	jmp    40bcf2 <__swc_fn_23cea7fa_000070_357c932c+0x172>
  40bcd5:	mov    rcx,QWORD PTR [rax+0x18]
  40bcd9:	cmp    QWORD PTR [rax+0x20],rcx
  40bcdd:	jae    40bcf0 <__swc_fn_23cea7fa_000070_357c932c+0x170>
  40bcdf:	mov    rcx,QWORD PTR [rax+0x20]
  40bce3:	mov    edx,DWORD PTR [rax+0x2c]
  40bce6:	add    QWORD PTR [rax+0x20],rdx
  40bcea:	add    DWORD PTR [rax+0x28],0x1
  40bcee:	jmp    40bcf2 <__swc_fn_23cea7fa_000070_357c932c+0x172>
  40bcf0:	xor    ecx,ecx
  40bcf2:	test   rcx,rcx
  40bcf5:	je     40bcfe <__swc_fn_23cea7fa_000070_357c932c+0x17e>
  40bcf7:	mov    QWORD PTR [r12+0x40],rcx
  40bcfc:	jmp    40bd09 <__swc_fn_23cea7fa_000070_357c932c+0x189>
  40bcfe:	mov    rcx,r13
  40bd01:	mov    rdx,r12
  40bd04:	call   40f080 <__swc_fn_23cea7fa_000071_1e1e3bf8>
  40bd09:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40bd12:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40bd1b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40bd24:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40bd2d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40bd36:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40bd3f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40bd48:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40bd51:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40bd5a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40bd63:	add    rsp,0x1a0
  40bd6a:	pop    rsi
  40bd6b:	pop    rdi
  40bd6c:	pop    r14
  40bd6e:	pop    r13
  40bd70:	pop    r12
  40bd72:	ret
	...

000000000040bd80 <__swc_fn_23cea7fa_000073_cdd57f51>:
  40bd80:	push   r12
  40bd82:	push   r13
  40bd84:	push   r14
  40bd86:	push   r15
  40bd88:	push   rdi
  40bd89:	push   rsi
  40bd8a:	sub    rsp,0x188
  40bd91:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40bd9a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40bda3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40bdac:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40bdb5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40bdbe:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40bdc7:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40bdd0:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40bdd9:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40bde2:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40bdeb:	mov    r12,rdx
  40bdee:	mov    r13,rcx
  40bdf1:	mov    r14,QWORD PTR [r12+0x40]
  40bdf6:	lea    rax,[rip+0x18273]        # 424070 <__swc_bss_base_23cea7fa+0x30>
  40bdfd:	mov    rcx,r14
  40be00:	sub    rcx,QWORD PTR [rax+0x8]
  40be04:	mov    rax,QWORD PTR [rip+0x18275]        # 424080 <__swc_bss_base_23cea7fa+0x40>
  40be0b:	cmp    rcx,rax
  40be0e:	jae    40be3a <__swc_fn_23cea7fa_000073_cdd57f51+0xba>
  40be10:	mov    rax,r14
  40be13:	and    rax,0xffffffffffc00000
  40be1a:	mov    rcx,r14
  40be1d:	shr    rcx,0x10
  40be21:	and    ecx,0x3f
  40be24:	mov    edx,DWORD PTR [rax+0x28]
  40be27:	shrx   ecx,ecx,edx
  40be2c:	shl    rcx,0x4
  40be30:	lea    r15,[rax+rcx*8+0x80]
  40be38:	jmp    40be45 <__swc_fn_23cea7fa_000073_cdd57f51+0xc5>
  40be3a:	mov    rcx,r14
  40be3d:	call   40a910 <__swc_fn_23cea7fa_000022_53fc00d2>
  40be42:	mov    r15,rax
  40be45:	test   r15,r15
  40be48:	je     40beef <__swc_fn_23cea7fa_000073_cdd57f51+0x16f>
  40be4e:	lea    rax,[rip+0x161ab]        # 422000 <__swc_data_base_23cea7fa>
  40be55:	mov    rax,QWORD PTR [rax]
  40be58:	cmp    rax,0xffffffffffffffff
  40be5c:	je     40be6b <__swc_fn_23cea7fa_000073_cdd57f51+0xeb>
  40be5e:	mov    eax,eax
  40be60:	mov    edi,eax
  40be62:	xor    eax,eax
  40be64:	call   407000 <pthread_getspecific@plt>
  40be69:	jmp    40be6d <__swc_fn_23cea7fa_000073_cdd57f51+0xed>
  40be6b:	xor    eax,eax
  40be6d:	mov    rcx,QWORD PTR [r15+0x40]
  40be71:	cmp    rcx,rax
  40be74:	jne    40bed4 <__swc_fn_23cea7fa_000073_cdd57f51+0x154>
  40be76:	test   rax,rax
  40be79:	je     40beef <__swc_fn_23cea7fa_000073_cdd57f51+0x16f>
  40be7b:	mov    ecx,DWORD PTR [r15+0x6c]
  40be7f:	test   ecx,ecx
  40be81:	je     40bea1 <__swc_fn_23cea7fa_000073_cdd57f51+0x121>
  40be83:	mov    rcx,r13
  40be86:	mov    rdx,rax
  40be89:	mov    r8,r15
  40be8c:	mov    QWORD PTR [rsp+0xd8],rax
  40be94:	call   40e590 <__swc_fn_23cea7fa_000047_e7fd8d42>
  40be99:	mov    rax,QWORD PTR [rsp+0xd8]
  40bea1:	mov    rcx,QWORD PTR [r15]
  40bea4:	mov    QWORD PTR [r14],rcx
  40bea7:	mov    QWORD PTR [r15],r14
  40beaa:	sub    DWORD PTR [r15+0x28],0x1
  40beaf:	jne    40bee4 <__swc_fn_23cea7fa_000073_cdd57f51+0x164>
  40beb1:	movzx  ecx,BYTE PTR [r15+0x39]
  40beb6:	lea    rcx,[rcx+rcx*4]
  40beba:	lea    rcx,[rax+rcx*8+0x28]
  40bebf:	cmp    QWORD PTR [rcx],r15
  40bec2:	je     40bee4 <__swc_fn_23cea7fa_000073_cdd57f51+0x164>
  40bec4:	mov    rcx,r13
  40bec7:	mov    rdx,rax
  40beca:	mov    r8,r15
  40becd:	call   407d80 <__swc_fn_23cea7fa_000051_27d2a35f>
  40bed2:	jmp    40bee4 <__swc_fn_23cea7fa_000073_cdd57f51+0x164>
  40bed4:	test   rcx,rcx
  40bed7:	je     40beef <__swc_fn_23cea7fa_000073_cdd57f51+0x16f>
  40bed9:	mov    rcx,r15
  40bedc:	mov    rdx,r14
  40bedf:	call   40a550 <__swc_fn_23cea7fa_000010_0569f799>
  40bee4:	mov    QWORD PTR [r12+0x40],0x0
  40beed:	jmp    40befa <__swc_fn_23cea7fa_000073_cdd57f51+0x17a>
  40beef:	mov    rcx,r13
  40bef2:	mov    rdx,r12
  40bef5:	call   40f0a0 <__swc_fn_23cea7fa_000074_30b8696a>
  40befa:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40bf03:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40bf0c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40bf15:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40bf1e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40bf27:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40bf30:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40bf39:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40bf42:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40bf4b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40bf54:	add    rsp,0x188
  40bf5b:	pop    rsi
  40bf5c:	pop    rdi
  40bf5d:	pop    r15
  40bf5f:	pop    r14
  40bf61:	pop    r13
  40bf63:	pop    r12
  40bf65:	ret
	...

000000000040bf70 <__swc_fn_23cea7fa_000076_c3ad0fb4>:
  40bf70:	sub    rsp,0x8
  40bf74:	mov    rax,rdx
  40bf77:	mov    rdx,QWORD PTR [rax+0x40]
  40bf7b:	mov    r8,rax
  40bf7e:	call   40bb70 <__swc_fn_23cea7fa_000067_0145abfc>
  40bf83:	add    rsp,0x8
  40bf87:	ret
	...

000000000040bf90 <__swc_fn_23cea7fa_000079_633af784>:
  40bf90:	push   rsi
  40bf91:	push   rdi
  40bf92:	sub    rsp,0x8
  40bf96:	cmp    rcx,0xffffffffffffffef
  40bf9a:	ja     40bfc0 <__swc_fn_23cea7fa_000079_633af784+0x30>
  40bf9c:	xor    esi,esi
  40bf9e:	lea    rax,[rcx+0x100f]
  40bfa5:	and    rax,0xfffffffffffff000
  40bfac:	lea    rcx,[rcx+0x10]
  40bfb0:	cmp    rcx,0xfffffffffffff000
  40bfb7:	cmovbe rsi,rax
  40bfbb:	test   rsi,rsi
  40bfbe:	jne    40bfc9 <__swc_fn_23cea7fa_000079_633af784+0x39>
  40bfc0:	xor    eax,eax
  40bfc2:	add    rsp,0x8
  40bfc6:	pop    rdi
  40bfc7:	pop    rsi
  40bfc8:	ret
  40bfc9:	mov    rcx,rsi
  40bfcc:	call   40c620 <__swc_fn_23cea7fa_000109_9f5af8ae>
  40bfd1:	mov    rdi,rax
  40bfd4:	test   rax,rax
  40bfd7:	jne    40bfe2 <__swc_fn_23cea7fa_000079_633af784+0x52>
  40bfd9:	xor    eax,eax
  40bfdb:	add    rsp,0x8
  40bfdf:	pop    rdi
  40bfe0:	pop    rsi
  40bfe1:	ret
  40bfe2:	mov    rcx,rdi
  40bfe5:	mov    rdx,rsi
  40bfe8:	call   409240 <__swc_fn_23cea7fa_000111_f9e19033>
  40bfed:	test   al,al
  40bfef:	jne    40c005 <__swc_fn_23cea7fa_000079_633af784+0x75>
  40bff1:	mov    rcx,rdi
  40bff4:	mov    rdx,rsi
  40bff7:	call   4101d0 <__swc_fn_23cea7fa_000113_4e83a03a>
  40bffc:	xor    eax,eax
  40bffe:	add    rsp,0x8
  40c002:	pop    rdi
  40c003:	pop    rsi
  40c004:	ret
  40c005:	mov    QWORD PTR [rdi],rsi
  40c008:	mov    QWORD PTR [rdi+0x8],0x0
  40c010:	lea    rax,[rdi+0x10]
  40c014:	add    rsp,0x8
  40c018:	pop    rdi
  40c019:	pop    rsi
  40c01a:	ret
  40c01b:	add    BYTE PTR [rax],al
  40c01d:	add    BYTE PTR [rax],al
	...

000000000040c020 <__swc_fn_23cea7fa_000082_ff7d1455>:
  40c020:	sub    rsp,0x8
  40c024:	cmp    BYTE PTR [rcx+0x2c],0x10
  40c028:	jne    40c033 <__swc_fn_23cea7fa_000082_ff7d1455+0x13>
  40c02a:	test   DWORD PTR [rcx+0x28],0x80
  40c031:	je     40c03b <__swc_fn_23cea7fa_000082_ff7d1455+0x1b>
  40c033:	mov    rax,rcx
  40c036:	add    rsp,0x8
  40c03a:	ret
  40c03b:	mov    rcx,QWORD PTR [rcx+0x40]
  40c03f:	call   40c020 <__swc_fn_23cea7fa_000082_ff7d1455>
  40c044:	add    rsp,0x8
  40c048:	ret
	...

000000000040c060 <__swc_fn_23cea7fa_000085_e24ecd12>:
  40c060:	push   rsi
  40c061:	push   rdi
  40c062:	push   r12
  40c064:	push   r13
  40c066:	sub    rsp,0x8
  40c06a:	mov    rsi,rdx
  40c06d:	mov    rdi,rcx
  40c070:	xor    r8d,r8d
  40c073:	call   4085a0 <__swc_fn_23cea7fa_000090_14cf59b2>
  40c078:	test   al,al
  40c07a:	je     40c08c <__swc_fn_23cea7fa_000085_e24ecd12+0x2c>
  40c07c:	mov    eax,0x1
  40c081:	add    rsp,0x8
  40c085:	pop    r13
  40c087:	pop    r12
  40c089:	pop    rdi
  40c08a:	pop    rsi
  40c08b:	ret
  40c08c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40c091:	je     40c0a0 <__swc_fn_23cea7fa_000085_e24ecd12+0x40>
  40c093:	xor    eax,eax
  40c095:	add    rsp,0x8
  40c099:	pop    r13
  40c09b:	pop    r12
  40c09d:	pop    rdi
  40c09e:	pop    rsi
  40c09f:	ret
  40c0a0:	mov    r12,QWORD PTR [rsi+0x98]
  40c0a7:	mov    rax,QWORD PTR [rsi+0xa0]
  40c0ae:	mov    rsi,rax
  40c0b1:	xor    r13d,r13d
  40c0b4:	test   rsi,rsi
  40c0b7:	je     40c114 <__swc_fn_23cea7fa_000085_e24ecd12+0xb4>
  40c0b9:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0c3:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0cd:	nop    DWORD PTR [rax]
  40c0d0:	lea    rax,[r13*8+0x0]
  40c0d8:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40c0dd:	mov    rcx,rax
  40c0e0:	call   40c020 <__swc_fn_23cea7fa_000082_ff7d1455>
  40c0e5:	cmp    BYTE PTR [rax+0x2c],0xe
  40c0e9:	jne    40c10a <__swc_fn_23cea7fa_000085_e24ecd12+0xaa>
  40c0eb:	mov    rcx,rdi
  40c0ee:	mov    rdx,rax
  40c0f1:	call   40c060 <__swc_fn_23cea7fa_000085_e24ecd12>
  40c0f6:	test   al,al
  40c0f8:	je     40c10a <__swc_fn_23cea7fa_000085_e24ecd12+0xaa>
  40c0fa:	mov    eax,0x1
  40c0ff:	add    rsp,0x8
  40c103:	pop    r13
  40c105:	pop    r12
  40c107:	pop    rdi
  40c108:	pop    rsi
  40c109:	ret
  40c10a:	add    r13,0x1
  40c10e:	sub    rsi,0x1
  40c112:	jne    40c0d0 <__swc_fn_23cea7fa_000085_e24ecd12+0x70>
  40c114:	xor    eax,eax
  40c116:	add    rsp,0x8
  40c11a:	pop    r13
  40c11c:	pop    r12
  40c11e:	pop    rdi
  40c11f:	pop    rsi
  40c120:	ret
	...

000000000040c130 <__swc_fn_23cea7fa_000088_ab2f35d8>:
  40c130:	sub    rsp,0x18
  40c134:	vxorps xmm0,xmm0,xmm0
  40c138:	vmovdqu XMMWORD PTR [rsp],xmm0
  40c13d:	call   40f2b0 <__swc_fn_23cea7fa_000089_3c530920>
  40c142:	add    rsp,0x18
  40c146:	ret
	...

000000000040c150 <__swc_fn_23cea7fa_000091_f21926ed>:
  40c150:	sub    rsp,0x8
  40c154:	mov    rcx,QWORD PTR [rip+0x1abe5]        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  40c15b:	test   rcx,rcx
  40c15e:	jne    40c170 <__swc_fn_23cea7fa_000091_f21926ed+0x20>
  40c160:	call   40a1a0 <__swc_fn_23cea7fa_000165_56054fe7>
  40c165:	lea    rcx,[rax+0x1]
  40c169:	mov    QWORD PTR [rip+0x1abd0],rcx        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  40c170:	dec    rcx
  40c173:	call   411fa0 <__swc_fn_23cea7fa_000167_39c041ad>
  40c178:	mov    rax,QWORD PTR [rax+0xc0]
  40c17f:	and    eax,0x1
  40c182:	setne  al
  40c185:	add    rsp,0x8
  40c189:	ret
	...

000000000040c1a0 <__swc_fn_23cea7fa_000094_383a814c>:
  40c1a0:	push   rbx
  40c1a1:	push   rsi
  40c1a2:	push   rdi
  40c1a3:	push   r12
  40c1a5:	sub    rsp,0x28
  40c1a9:	mov    rbx,rcx
  40c1ac:	call   408900 <__swc_fn_23cea7fa_000093_0c97fc6c>
  40c1b1:	mov    rcx,QWORD PTR [rip+0x1ab88]        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  40c1b8:	test   rcx,rcx
  40c1bb:	jne    40c1cd <__swc_fn_23cea7fa_000094_383a814c+0x2d>
  40c1bd:	call   40a1a0 <__swc_fn_23cea7fa_000165_56054fe7>
  40c1c2:	lea    rcx,[rax+0x1]
  40c1c6:	mov    QWORD PTR [rip+0x1ab73],rcx        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  40c1cd:	dec    rcx
  40c1d0:	call   411fa0 <__swc_fn_23cea7fa_000167_39c041ad>
  40c1d5:	mov    rsi,rax
  40c1d8:	lea    rcx,[rsp+0x8]
  40c1dd:	call   40f6f0 <__swc_fn_23cea7fa_000092_809deff5>
  40c1e2:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40c1e9:	mov    r12,QWORD PTR [rsi+0xbe8]
  40c1f0:	lea    rcx,[rsi+0x10]
  40c1f4:	call   40d170 <__swc_fn_23cea7fa_000157_3495a3ca>
  40c1f9:	mov    rcx,rsi
  40c1fc:	call   40f860 <__swc_fn_23cea7fa_000101_afcb7774>
  40c201:	vxorps xmm0,xmm0,xmm0
  40c205:	xor    eax,eax
  40c207:	cs nop WORD PTR [rax+rax*1+0x0]
  40c211:	cs nop WORD PTR [rax+rax*1+0x0]
  40c21b:	nop    DWORD PTR [rax+rax*1+0x0]
  40c220:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40c225:	add    rax,0x10
  40c229:	cmp    rax,0xbf0
  40c230:	jne    40c220 <__swc_fn_23cea7fa_000094_383a814c+0x80>
  40c232:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c238:	vmovups XMMWORD PTR [rsi],xmm0
  40c23c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c242:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40c24a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40c251:	mov    QWORD PTR [rsi+0xbe8],r12
  40c258:	mov    rcx,QWORD PTR [rip+0x1aae1]        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  40c25f:	test   rcx,rcx
  40c262:	jne    40c274 <__swc_fn_23cea7fa_000094_383a814c+0xd4>
  40c264:	call   40a1a0 <__swc_fn_23cea7fa_000165_56054fe7>
  40c269:	lea    rcx,[rax+0x1]
  40c26d:	mov    QWORD PTR [rip+0x1aacc],rcx        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  40c274:	dec    rcx
  40c277:	call   411fa0 <__swc_fn_23cea7fa_000167_39c041ad>
  40c27c:	mov    rsi,rax
  40c27f:	mov    QWORD PTR [rsi+0xc0],rbx
  40c286:	and    ebx,0x1
  40c289:	jne    40c28d <__swc_fn_23cea7fa_000094_383a814c+0xed>
  40c28b:	xor    eax,eax
  40c28d:	test   rbx,rbx
  40c290:	sete   al
  40c293:	xor    cl,cl
  40c295:	xor    dl,dl
  40c297:	xor    r8b,r8b
  40c29a:	xor    r9b,r9b
  40c29d:	xor    r10b,r10b
  40c2a0:	mov    r11,rax
  40c2a3:	call   40f0b0 <__swc_fn_23cea7fa_000077_948ef603>
  40c2a8:	lea    rbx,[rsp+0x18]
  40c2ad:	mov    rcx,rbx
  40c2b0:	call   40f6f0 <__swc_fn_23cea7fa_000092_809deff5>
  40c2b5:	lea    rcx,[rsi+0x10]
  40c2b9:	mov    edx,0x400000
  40c2be:	mov    r8,rbx
  40c2c1:	call   409ee0 <__swc_fn_23cea7fa_000159_6861d596>
  40c2c6:	lea    rcx,[rsi+0x68]
  40c2ca:	mov    edx,0x4000
  40c2cf:	mov    r8,rbx
  40c2d2:	call   409ee0 <__swc_fn_23cea7fa_000159_6861d596>
  40c2d7:	add    rsp,0x28
  40c2db:	pop    r12
  40c2dd:	pop    rdi
  40c2de:	pop    rsi
  40c2df:	pop    rbx
  40c2e0:	ret
	...

000000000040c2f0 <__swc_fn_23cea7fa_000097_96d6739a>:
  40c2f0:	push   rbx
  40c2f1:	push   rsi
  40c2f2:	sub    rsp,0x18
  40c2f6:	mov    rbx,rcx
  40c2f9:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40c2fe:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c304:	mov    rsi,QWORD PTR [rbx+0x70]
  40c308:	lea    rcx,[rcx+0x18]
  40c30c:	call   40d170 <__swc_fn_23cea7fa_000157_3495a3ca>
  40c311:	lea    rcx,[rsp+0x8]
  40c316:	mov    rdx,rbx
  40c319:	mov    r8d,0x78
  40c31f:	call   408960 <__swc_fn_23cea7fa_000096_a4baaa40>
  40c324:	mov    rax,rsi
  40c327:	add    rsp,0x18
  40c32b:	pop    rsi
  40c32c:	pop    rbx
  40c32d:	ret
	...

000000000040c330 <__swc_fn_23cea7fa_000100_5714513e>:
  40c330:	push   rsi
  40c331:	push   rdi
  40c332:	sub    rsp,0x8
  40c336:	cmp    QWORD PTR [rcx],0x0
  40c33a:	jne    40c343 <__swc_fn_23cea7fa_000100_5714513e+0x13>
  40c33c:	add    rsp,0x8
  40c340:	pop    rdi
  40c341:	pop    rsi
  40c342:	ret
  40c343:	mov    rsi,QWORD PTR [rcx]
  40c346:	mov    rax,QWORD PTR [rcx+0x8]
  40c34a:	test   rax,rax
  40c34d:	je     40c363 <__swc_fn_23cea7fa_000100_5714513e+0x33>
  40c34f:	test   DWORD PTR [rax+0x28],0x400000
  40c356:	je     40c363 <__swc_fn_23cea7fa_000100_5714513e+0x33>
  40c358:	mov    rcx,QWORD PTR [rax+0x30]
  40c35c:	test   rcx,rcx
  40c35f:	cmovne rax,rcx
  40c363:	lea    rdx,[rip+0x6e66]        # 4131d0 <__swc_rdata_base_23cea7fa+0xc0>
  40c36a:	lea    rcx,[rip+0x6f47]        # 4132b8 <__swc_rdata_base_23cea7fa+0x1a8>
  40c371:	mov    r8,rax
  40c374:	xor    r9d,r9d
  40c377:	xor    al,al
  40c379:	mov    r10,rax
  40c37c:	xor    r11d,r11d
  40c37f:	call   40c130 <__swc_fn_23cea7fa_000088_ab2f35d8>
  40c384:	test   rax,rax
  40c387:	je     40c397 <__swc_fn_23cea7fa_000100_5714513e+0x67>
  40c389:	mov    rdi,QWORD PTR [rax+0x48]
  40c38d:	test   rdi,rdi
  40c390:	je     40c397 <__swc_fn_23cea7fa_000100_5714513e+0x67>
  40c392:	mov    rcx,rsi
  40c395:	call   rdi
  40c397:	add    rsp,0x8
  40c39b:	pop    rdi
  40c39c:	pop    rsi
  40c39d:	ret
	...

000000000040c3a0 <__swc_fn_23cea7fa_000103_0d4cc079>:
  40c3a0:	push   rbx
  40c3a1:	push   rsi
  40c3a2:	push   rdi
  40c3a3:	sub    rsp,0x20
  40c3a7:	mov    rbx,rdx
  40c3aa:	mov    rsi,rcx
  40c3ad:	mov    rcx,QWORD PTR [rip+0x1a98c]        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  40c3b4:	test   rcx,rcx
  40c3b7:	jne    40c3c9 <__swc_fn_23cea7fa_000103_0d4cc079+0x29>
  40c3b9:	call   40a1a0 <__swc_fn_23cea7fa_000165_56054fe7>
  40c3be:	lea    rcx,[rax+0x1]
  40c3c2:	mov    QWORD PTR [rip+0x1a977],rcx        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  40c3c9:	dec    rcx
  40c3cc:	call   411fa0 <__swc_fn_23cea7fa_000167_39c041ad>
  40c3d1:	mov    rdi,rax
  40c3d4:	mov    rax,QWORD PTR [rdi+0xbd0]
  40c3db:	xor    ecx,ecx
  40c3dd:	test   rax,rax
  40c3e0:	je     40c3e5 <__swc_fn_23cea7fa_000103_0d4cc079+0x45>
  40c3e2:	mov    rcx,QWORD PTR [rax]
  40c3e5:	call   40a2d0 <__swc_fn_23cea7fa_000174_02e645b4>
  40c3ea:	lea    rax,[rsp+0x8]
  40c3ef:	lea    rcx,[rdi+0x9c8]
  40c3f6:	mov    QWORD PTR [rsp+0x8],rcx
  40c3fb:	mov    QWORD PTR [rax+0x8],0x40
  40c403:	xor    ecx,ecx
  40c405:	mov    rdx,rax
  40c408:	call   410300 <__swc_fn_23cea7fa_000119_2d9caf16>
  40c40d:	mov    DWORD PTR [rdi+0xbc8],eax
  40c413:	mov    rdi,QWORD PTR [rdi+0x990]
  40c41a:	test   rdi,rdi
  40c41d:	je     40c427 <__swc_fn_23cea7fa_000103_0d4cc079+0x87>
  40c41f:	mov    rcx,rsi
  40c422:	mov    rdx,rbx
  40c425:	call   rdi
  40c427:	call   40c150 <__swc_fn_23cea7fa_000091_f21926ed>
  40c42c:	test   al,al
  40c42e:	je     40c43e <__swc_fn_23cea7fa_000103_0d4cc079+0x9e>
  40c430:	mov    rcx,rsi
  40c433:	mov    rdx,rbx
  40c436:	xor    r8d,r8d
  40c439:	call   4093e0 <__swc_fn_23cea7fa_000120_1e032ef6>
  40c43e:	mov    rcx,rsi
  40c441:	mov    rdx,rbx
  40c444:	call   408a60 <__swc_fn_23cea7fa_000102_14986ec5>
  40c449:	call   40c9d0 <__swc_fn_23cea7fa_000118_591530fe>
  40c44e:	add    rsp,0x20
  40c452:	pop    rdi
  40c453:	pop    rsi
  40c454:	pop    rbx
  40c455:	ret
	...

000000000040c460 <__swc_fn_23cea7fa_000106_aba05410>:
  40c460:	test   r8,r8
  40c463:	jne    40c468 <__swc_fn_23cea7fa_000106_aba05410+0x8>
  40c465:	xor    eax,eax
  40c467:	ret
  40c468:	xor    eax,eax
  40c46a:	nop    WORD PTR [rax+rax*1+0x0]
  40c470:	mov    r9,r8
  40c473:	sub    r9,rax
  40c476:	cmp    r9,0x10
  40c47a:	jb     40c4c4 <__swc_fn_23cea7fa_000106_aba05410+0x64>
  40c47c:	lea    r9,[rcx+rax*1]
  40c480:	lea    r10,[rdx+rax*1]
  40c484:	vmovups xmm0,XMMWORD PTR [r10]
  40c489:	vmovups xmm1,XMMWORD PTR [r9]
  40c48e:	vpcmpeqb xmm0,xmm1,xmm0
  40c492:	vpmovmskb r9d,xmm0
  40c496:	cmp    r9d,0xffff
  40c49d:	je     40c4be <__swc_fn_23cea7fa_000106_aba05410+0x5e>
  40c49f:	not    r9d
  40c4a2:	xor    r8d,r8d
  40c4a5:	movzx  r9d,r9w
  40c4a9:	tzcnt  r8d,r9d
  40c4ae:	add    rax,r8
  40c4b1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4b5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4b9:	sub    ecx,eax
  40c4bb:	mov    eax,ecx
  40c4bd:	ret
  40c4be:	lea    rax,[rax+0x10]
  40c4c2:	jmp    40c470 <__swc_fn_23cea7fa_000106_aba05410+0x10>
  40c4c4:	cmp    r9,0x8
  40c4c8:	jb     40c53b <__swc_fn_23cea7fa_000106_aba05410+0xdb>
  40c4ca:	lea    r9,[rcx+rax*1]
  40c4ce:	lea    r10,[rdx+rax*1]
  40c4d2:	mov    r9,QWORD PTR [r9]
  40c4d5:	xor    r9,QWORD PTR [r10]
  40c4d8:	test   r9,r9
  40c4db:	je     40c4f9 <__swc_fn_23cea7fa_000106_aba05410+0x99>
  40c4dd:	xor    r8d,r8d
  40c4e0:	tzcnt  r8,r9
  40c4e5:	shr    r8,0x3
  40c4e9:	add    rax,r8
  40c4ec:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4f0:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4f4:	sub    ecx,eax
  40c4f6:	mov    eax,ecx
  40c4f8:	ret
  40c4f9:	lea    rax,[rax+0x8]
  40c4fd:	cmp    rax,r8
  40c500:	jne    40c505 <__swc_fn_23cea7fa_000106_aba05410+0xa5>
  40c502:	xor    eax,eax
  40c504:	ret
  40c505:	lea    rax,[r8-0x8]
  40c509:	lea    r8,[rcx+rax*1]
  40c50d:	lea    r9,[rdx+rax*1]
  40c511:	mov    r8,QWORD PTR [r8]
  40c514:	xor    r8,QWORD PTR [r9]
  40c517:	test   r8,r8
  40c51a:	je     40c538 <__swc_fn_23cea7fa_000106_aba05410+0xd8>
  40c51c:	xor    r9d,r9d
  40c51f:	tzcnt  r9,r8
  40c524:	shr    r9,0x3
  40c528:	add    rax,r9
  40c52b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c52f:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c533:	sub    ecx,eax
  40c535:	mov    eax,ecx
  40c537:	ret
  40c538:	xor    eax,eax
  40c53a:	ret
  40c53b:	cmp    r9,0x4
  40c53f:	jb     40c5b2 <__swc_fn_23cea7fa_000106_aba05410+0x152>
  40c541:	lea    r9,[rcx+rax*1]
  40c545:	lea    r10,[rdx+rax*1]
  40c549:	mov    r9d,DWORD PTR [r9]
  40c54c:	xor    r9d,DWORD PTR [r10]
  40c54f:	test   r9d,r9d
  40c552:	je     40c570 <__swc_fn_23cea7fa_000106_aba05410+0x110>
  40c554:	xor    r8d,r8d
  40c557:	tzcnt  r8,r9
  40c55c:	shr    r8,0x3
  40c560:	add    rax,r8
  40c563:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c567:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c56b:	sub    ecx,eax
  40c56d:	mov    eax,ecx
  40c56f:	ret
  40c570:	lea    rax,[rax+0x4]
  40c574:	cmp    rax,r8
  40c577:	jne    40c57c <__swc_fn_23cea7fa_000106_aba05410+0x11c>
  40c579:	xor    eax,eax
  40c57b:	ret
  40c57c:	lea    rax,[r8-0x4]
  40c580:	lea    r8,[rcx+rax*1]
  40c584:	lea    r9,[rdx+rax*1]
  40c588:	mov    r8d,DWORD PTR [r8]
  40c58b:	xor    r8d,DWORD PTR [r9]
  40c58e:	test   r8d,r8d
  40c591:	je     40c5af <__swc_fn_23cea7fa_000106_aba05410+0x14f>
  40c593:	xor    r9d,r9d
  40c596:	tzcnt  r9,r8
  40c59b:	shr    r9,0x3
  40c59f:	add    rax,r9
  40c5a2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c5a6:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c5aa:	sub    ecx,eax
  40c5ac:	mov    eax,ecx
  40c5ae:	ret
  40c5af:	xor    eax,eax
  40c5b1:	ret
  40c5b2:	cmp    r9,0x2
  40c5b6:	jb     40c609 <__swc_fn_23cea7fa_000106_aba05410+0x1a9>
  40c5b8:	lea    r9,[rcx+rax*1]
  40c5bc:	lea    r10,[rdx+rax*1]
  40c5c0:	mov    r9w,WORD PTR [r9]
  40c5c4:	xor    r9w,WORD PTR [r10]
  40c5c8:	test   r9w,r9w
  40c5cc:	je     40c5ee <__swc_fn_23cea7fa_000106_aba05410+0x18e>
  40c5ce:	xor    r8d,r8d
  40c5d1:	movzx  r9d,r9w
  40c5d5:	tzcnt  r8,r9
  40c5da:	shr    r8,0x3
  40c5de:	add    rax,r8
  40c5e1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c5e5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c5e9:	sub    ecx,eax
  40c5eb:	mov    eax,ecx
  40c5ed:	ret
  40c5ee:	lea    rax,[rax+0x2]
  40c5f2:	cmp    rax,r8
  40c5f5:	jne    40c5fa <__swc_fn_23cea7fa_000106_aba05410+0x19a>
  40c5f7:	xor    eax,eax
  40c5f9:	ret
  40c5fa:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40c600:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40c606:	sub    eax,ecx
  40c608:	ret
  40c609:	test   r9,r9
  40c60c:	je     40c61b <__swc_fn_23cea7fa_000106_aba05410+0x1bb>
  40c60e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c612:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c616:	sub    ecx,eax
  40c618:	mov    eax,ecx
  40c61a:	ret
  40c61b:	xor    eax,eax
  40c61d:	ret
	...

000000000040c620 <__swc_fn_23cea7fa_000109_9f5af8ae>:
  40c620:	push   r12
  40c622:	push   r13
  40c624:	push   r14
  40c626:	push   rdi
  40c627:	push   rsi
  40c628:	push   r15
  40c62a:	sub    rsp,0xd8
  40c631:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c637:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c63d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c643:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c649:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c64f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c658:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c661:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c66a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c673:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c67c:	mov    r12,rcx
  40c67f:	test   rcx,rcx
  40c682:	je     40c69e <__swc_fn_23cea7fa_000109_9f5af8ae+0x7e>
  40c684:	mov    eax,r12d
  40c687:	and    eax,0xfff
  40c68d:	setne  al
  40c690:	cmp    r12,0xffffffffffffefff
  40c697:	seta   cl
  40c69a:	or     al,cl
  40c69c:	je     40c6a5 <__swc_fn_23cea7fa_000109_9f5af8ae+0x85>
  40c69e:	xor    eax,eax
  40c6a0:	jmp    40c73b <__swc_fn_23cea7fa_000109_9f5af8ae+0x11b>
  40c6a5:	call   409100 <__swc_fn_23cea7fa_000108_b8f4bd15>
  40c6aa:	mov    r13,rax
  40c6ad:	test   rax,rax
  40c6b0:	jne    40c6b9 <__swc_fn_23cea7fa_000109_9f5af8ae+0x99>
  40c6b2:	xor    eax,eax
  40c6b4:	jmp    40c73b <__swc_fn_23cea7fa_000109_9f5af8ae+0x11b>
  40c6b9:	lea    r14,[r12+0x1000]
  40c6c1:	xor    edi,edi
  40c6c3:	mov    rsi,r14
  40c6c6:	xor    edx,edx
  40c6c8:	mov    ecx,0x22
  40c6cd:	mov    eax,0xffffffff
  40c6d2:	movsxd r8,eax
  40c6d5:	xor    r9d,r9d
  40c6d8:	xor    eax,eax
  40c6da:	call   4070c0 <mmap@plt>
  40c6df:	mov    r15,rax
  40c6e2:	cmp    rax,0xffffffffffffffff
  40c6e6:	jne    40c6ec <__swc_fn_23cea7fa_000109_9f5af8ae+0xcc>
  40c6e8:	xor    eax,eax
  40c6ea:	jmp    40c73b <__swc_fn_23cea7fa_000109_9f5af8ae+0x11b>
  40c6ec:	mov    rdi,r15
  40c6ef:	mov    esi,0x1000
  40c6f4:	mov    edx,0x3
  40c6f9:	xor    eax,eax
  40c6fb:	call   407030 <mprotect@plt>
  40c700:	test   eax,eax
  40c702:	je     40c715 <__swc_fn_23cea7fa_000109_9f5af8ae+0xf5>
  40c704:	mov    rdi,r15
  40c707:	mov    rsi,r14
  40c70a:	xor    eax,eax
  40c70c:	call   407020 <munmap@plt>
  40c711:	xor    eax,eax
  40c713:	jmp    40c73b <__swc_fn_23cea7fa_000109_9f5af8ae+0x11b>
  40c715:	mov    QWORD PTR [r15+0x8],r12
  40c719:	mov    rcx,r13
  40c71c:	call   40cd70 <__swc_fn_23cea7fa_000133_807fd51d>
  40c721:	mov    rax,QWORD PTR [r13+0x8]
  40c725:	mov    QWORD PTR [r15],rax
  40c728:	mov    QWORD PTR [r13+0x8],r15
  40c72c:	mov    rcx,r13
  40c72f:	call   4106a0 <__swc_fn_23cea7fa_000134_10472836>
  40c734:	lea    rax,[r15+0x1000]
  40c73b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c741:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c747:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c74d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c753:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c759:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c762:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c76b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c774:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c77d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c786:	add    rsp,0xd8
  40c78d:	pop    r15
  40c78f:	pop    rsi
  40c790:	pop    rdi
  40c791:	pop    r14
  40c793:	pop    r13
  40c795:	pop    r12
  40c797:	ret
	...

000000000040c7a0 <__swc_fn_23cea7fa_000112_2f7f9346>:
  40c7a0:	push   rbx
  40c7a1:	push   r12
  40c7a3:	push   rdi
  40c7a4:	push   rsi
  40c7a5:	sub    rsp,0xa8
  40c7ac:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c7b2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c7b8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c7be:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c7c4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c7ca:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c7d0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40c7d6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40c7dc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40c7e5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40c7ee:	mov    rbx,rdx
  40c7f1:	mov    r12,rcx
  40c7f4:	mov    rdi,rcx
  40c7f7:	mov    rsi,rdx
  40c7fa:	xor    edx,edx
  40c7fc:	xor    eax,eax
  40c7fe:	call   407030 <mprotect@plt>
  40c803:	test   eax,eax
  40c805:	jne    40c829 <__swc_fn_23cea7fa_000112_2f7f9346+0x89>
  40c807:	mov    rcx,r12
  40c80a:	mov    rdx,rbx
  40c80d:	xor    al,al
  40c80f:	mov    r8,rax
  40c812:	call   410140 <__swc_fn_23cea7fa_000110_918d5a21>
  40c817:	mov    rdi,r12
  40c81a:	mov    rsi,rbx
  40c81d:	mov    edx,0x4
  40c822:	xor    eax,eax
  40c824:	call   4070f0 <madvise@plt>
  40c829:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40c82f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40c835:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40c83b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40c841:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40c847:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40c84d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40c853:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40c859:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40c862:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40c86b:	add    rsp,0xa8
  40c872:	pop    rsi
  40c873:	pop    rdi
  40c874:	pop    r12
  40c876:	pop    rbx
  40c877:	ret
	...

000000000040c880 <__swc_fn_23cea7fa_000115_3f6af4b1>:
  40c880:	push   rsi
  40c881:	push   rdi
  40c882:	push   r12
  40c884:	push   r13
  40c886:	push   r14
  40c888:	sub    rsp,0xe0
  40c88f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c895:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c89b:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c8a1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c8a7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c8ad:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c8b6:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c8bf:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c8c8:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c8d1:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c8da:	mov    rsi,rdx
  40c8dd:	mov    rdi,rcx
  40c8e0:	call   409100 <__swc_fn_23cea7fa_000108_b8f4bd15>
  40c8e5:	mov    r12,rax
  40c8e8:	test   rax,rax
  40c8eb:	jne    40c8f2 <__swc_fn_23cea7fa_000115_3f6af4b1+0x72>
  40c8ed:	jmp    40c966 <__swc_fn_23cea7fa_000115_3f6af4b1+0xe6>
  40c8f2:	mov    rcx,r12
  40c8f5:	call   40cd70 <__swc_fn_23cea7fa_000133_807fd51d>
  40c8fa:	lea    r13,[r12+0x8]
  40c8ff:	mov    rax,QWORD PTR [r13+0x0]
  40c903:	test   rax,rax
  40c906:	je     40c95e <__swc_fn_23cea7fa_000115_3f6af4b1+0xde>
  40c908:	nop    DWORD PTR [rax+rax*1+0x0]
  40c910:	lea    rcx,[rax+0x1000]
  40c917:	cmp    rcx,rdi
  40c91a:	jne    40c952 <__swc_fn_23cea7fa_000115_3f6af4b1+0xd2>
  40c91c:	cmp    QWORD PTR [rax+0x8],rsi
  40c920:	je     40c92c <__swc_fn_23cea7fa_000115_3f6af4b1+0xac>
  40c922:	mov    rcx,r12
  40c925:	call   4106a0 <__swc_fn_23cea7fa_000134_10472836>
  40c92a:	jmp    40c966 <__swc_fn_23cea7fa_000115_3f6af4b1+0xe6>
  40c92c:	mov    r14,QWORD PTR [rax]
  40c92f:	mov    rdi,rax
  40c932:	lea    rsi,[rsi+0x1000]
  40c939:	xor    eax,eax
  40c93b:	call   407020 <munmap@plt>
  40c940:	test   eax,eax
  40c942:	jne    40c948 <__swc_fn_23cea7fa_000115_3f6af4b1+0xc8>
  40c944:	mov    QWORD PTR [r13+0x0],r14
  40c948:	mov    rcx,r12
  40c94b:	call   4106a0 <__swc_fn_23cea7fa_000134_10472836>
  40c950:	jmp    40c966 <__swc_fn_23cea7fa_000115_3f6af4b1+0xe6>
  40c952:	mov    r13,rax
  40c955:	mov    rax,QWORD PTR [r13+0x0]
  40c959:	test   rax,rax
  40c95c:	jne    40c910 <__swc_fn_23cea7fa_000115_3f6af4b1+0x90>
  40c95e:	mov    rcx,r12
  40c961:	call   4106a0 <__swc_fn_23cea7fa_000134_10472836>
  40c966:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c96c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c972:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c978:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c97e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c984:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c98d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c996:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c99f:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c9a8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c9b1:	add    rsp,0xe0
  40c9b8:	pop    r14
  40c9ba:	pop    r13
  40c9bc:	pop    r12
  40c9be:	pop    rdi
  40c9bf:	pop    rsi
  40c9c0:	ret
	...

000000000040c9d0 <__swc_fn_23cea7fa_000118_591530fe>:
  40c9d0:	push   rdi
  40c9d1:	push   rsi
  40c9d2:	sub    rsp,0xa8
  40c9d9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c9df:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c9e5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c9eb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c9f1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c9f7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c9fd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ca03:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ca09:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ca12:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ca1b:	mov    rdi,0xfffffffffffffd66
  40ca22:	xor    eax,eax
  40ca24:	call   407040 <exit@plt>
  40ca29:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ca2f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ca35:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ca3b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ca41:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ca47:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ca4d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ca53:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ca59:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ca62:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ca6b:	add    rsp,0xa8
  40ca72:	pop    rsi
  40ca73:	pop    rdi
  40ca74:	ret
	...

000000000040ca80 <__swc_fn_23cea7fa_000121_1c5e75b6>:
  40ca80:	push   rbx
  40ca81:	push   rsi
  40ca82:	push   rdi
  40ca83:	sub    rsp,0x30
  40ca87:	mov    rbx,rdx
  40ca8a:	mov    esi,ecx
  40ca8c:	test   ecx,ecx
  40ca8e:	je     40cb63 <__swc_fn_23cea7fa_000121_1c5e75b6+0xe3>
  40ca94:	mov    rcx,rsi
  40ca97:	shl    rcx,0x4
  40ca9b:	call   40bf90 <__swc_fn_23cea7fa_000079_633af784>
  40caa0:	test   rax,rax
  40caa3:	je     40cb52 <__swc_fn_23cea7fa_000121_1c5e75b6+0xd2>
  40caa9:	mov    rcx,rsi
  40caac:	xor    edx,edx
  40caae:	test   rsi,rsi
  40cab1:	jbe    40cb32 <__swc_fn_23cea7fa_000121_1c5e75b6+0xb2>
  40cab7:	nop    WORD PTR [rax+rax*1+0x0]
  40cac0:	mov    r8d,edx
  40cac3:	mov    r9,QWORD PTR [rbx+r8*8]
  40cac7:	add    r8,r8
  40caca:	lea    r8,[rax+r8*8]
  40cace:	xor    r10d,r10d
  40cad1:	test   r9,r9
  40cad4:	je     40cb10 <__swc_fn_23cea7fa_000121_1c5e75b6+0x90>
  40cad6:	mov    r11,r9
  40cad9:	mov    dil,BYTE PTR [r11]
  40cadc:	test   dil,dil
  40cadf:	je     40cb10 <__swc_fn_23cea7fa_000121_1c5e75b6+0x90>
  40cae1:	cs nop WORD PTR [rax+rax*1+0x0]
  40caeb:	cs nop WORD PTR [rax+rax*1+0x0]
  40caf5:	cs nop WORD PTR [rax+rax*1+0x0]
  40caff:	nop
  40cb00:	add    r11,0x1
  40cb04:	add    r10,0x1
  40cb08:	mov    dil,BYTE PTR [r11]
  40cb0b:	test   dil,dil
  40cb0e:	jne    40cb00 <__swc_fn_23cea7fa_000121_1c5e75b6+0x80>
  40cb10:	mov    QWORD PTR [rsp+0x18],r9
  40cb15:	mov    QWORD PTR [rsp+0x20],r10
  40cb1a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40cb20:	vmovups XMMWORD PTR [r8],xmm0
  40cb25:	add    rdx,0x1
  40cb29:	cmp    rdx,rcx
  40cb2c:	jb     40cac0 <__swc_fn_23cea7fa_000121_1c5e75b6+0x40>
  40cb32:	lea    rcx,[rip+0x1a217]        # 426d50 <__swc_bss_base_23cea7fa+0x2d10>
  40cb39:	mov    QWORD PTR [rsp+0x8],rax
  40cb3e:	mov    esi,esi
  40cb40:	mov    QWORD PTR [rsp+0x10],rsi
  40cb45:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40cb4b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40cb50:	jmp    40cb63 <__swc_fn_23cea7fa_000121_1c5e75b6+0xe3>
  40cb52:	lea    rcx,[rip+0x69c7]        # 413520 <__swc_rdata_base_23cea7fa+0x410>
  40cb59:	call   4101f0 <__swc_fn_23cea7fa_000116_3f5cfdef>
  40cb5e:	call   40c9d0 <__swc_fn_23cea7fa_000118_591530fe>
  40cb63:	add    rsp,0x30
  40cb67:	pop    rdi
  40cb68:	pop    rsi
  40cb69:	pop    rbx
  40cb6a:	ret
  40cb6b:	add    BYTE PTR [rax],al
  40cb6d:	add    BYTE PTR [rax],al
	...

000000000040cb70 <__swc_fn_23cea7fa_000124_37eaf452>:
  40cb70:	push   rdi
  40cb71:	push   rsi
  40cb72:	sub    rsp,0xa8
  40cb79:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cb7f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cb85:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cb8b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cb91:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cb97:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cb9d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cba3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cba9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cbb2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cbbb:	mov    edi,ecx
  40cbbd:	xor    eax,eax
  40cbbf:	call   407100 <pthread_key_delete@plt>
  40cbc4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cbca:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cbd0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cbd6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cbdc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cbe2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cbe8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cbee:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cbf4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cbfd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cc06:	add    rsp,0xa8
  40cc0d:	pop    rsi
  40cc0e:	pop    rdi
  40cc0f:	ret

000000000040cc10 <__swc_fn_23cea7fa_000127_f163135d>:
  40cc10:	push   rdi
  40cc11:	push   rsi
  40cc12:	sub    rsp,0xa8
  40cc19:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cc1f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cc25:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cc2b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cc31:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cc37:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cc3d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cc43:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cc49:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cc52:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cc5b:	test   rcx,rcx
  40cc5e:	je     40cc6f <__swc_fn_23cea7fa_000127_f163135d+0x5f>
  40cc60:	lea    rax,[rcx-0x1]
  40cc64:	mov    eax,eax
  40cc66:	mov    edi,eax
  40cc68:	xor    eax,eax
  40cc6a:	call   407100 <pthread_key_delete@plt>
  40cc6f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cc75:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cc7b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cc81:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cc87:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cc8d:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cc93:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cc99:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cc9f:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cca8:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ccb1:	add    rsp,0xa8
  40ccb8:	pop    rsi
  40ccb9:	pop    rdi
  40ccba:	ret
  40ccbb:	add    BYTE PTR [rax],al
  40ccbd:	add    BYTE PTR [rax],al
	...

000000000040ccc0 <__swc_fn_23cea7fa_000130_375c7357>:
  40ccc0:	push   rsi
  40ccc1:	push   rdi
  40ccc2:	sub    rsp,0xa8
  40ccc9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cccf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ccd5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ccdb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cce1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cce7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cced:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ccf3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ccf9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cd02:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cd0b:	xor    eax,eax
  40cd0d:	call   407110 <gettid@plt>
  40cd12:	movsxd rax,eax
  40cd15:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cd1b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cd21:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cd27:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cd2d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cd33:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cd39:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cd3f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cd45:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cd4e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cd57:	add    rsp,0xa8
  40cd5e:	pop    rdi
  40cd5f:	pop    rsi
  40cd60:	ret
	...

000000000040cd70 <__swc_fn_23cea7fa_000133_807fd51d>:
  40cd70:	push   rbx
  40cd71:	push   rdi
  40cd72:	push   rsi
  40cd73:	sub    rsp,0xc0
  40cd7a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40cd80:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40cd86:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40cd8c:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40cd92:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40cd98:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40cd9e:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40cda4:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40cdad:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40cdb6:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40cdbf:	mov    rbx,rcx
  40cdc2:	cs nop WORD PTR [rax+rax*1+0x0]
  40cdcc:	nop    DWORD PTR [rax+0x0]
  40cdd0:	mov    edx,0x80000000
  40cdd5:	xor    eax,eax
  40cdd7:	lock cmpxchg DWORD PTR [rbx],edx
  40cddb:	test   eax,eax
  40cddd:	je     40ce14 <__swc_fn_23cea7fa_000133_807fd51d+0xa4>
  40cddf:	mov    eax,DWORD PTR [rbx]
  40cde1:	lea    rcx,[rsp+0x14]
  40cde6:	mov    DWORD PTR [rsp+0x14],eax
  40cdea:	test   eax,eax
  40cdec:	je     40cdd0 <__swc_fn_23cea7fa_000133_807fd51d+0x60>
  40cdee:	mov    QWORD PTR [rsp],0x0
  40cdf6:	mov    edi,0xca
  40cdfb:	mov    rsi,rbx
  40cdfe:	mov    edx,0x80
  40ce03:	mov    ecx,DWORD PTR [rcx]
  40ce05:	xor    r8d,r8d
  40ce08:	xor    r9d,r9d
  40ce0b:	xor    eax,eax
  40ce0d:	call   407070 <syscall@plt>
  40ce12:	jmp    40cdd0 <__swc_fn_23cea7fa_000133_807fd51d+0x60>
  40ce14:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ce1a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40ce20:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40ce26:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ce2c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ce32:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ce38:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ce3e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ce47:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ce50:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ce59:	add    rsp,0xc0
  40ce60:	pop    rsi
  40ce61:	pop    rdi
  40ce62:	pop    rbx
  40ce63:	ret
	...

000000000040ce70 <__swc_fn_23cea7fa_000136_d579ef75>:
  40ce70:	sub    rsp,0x8
  40ce74:	call   4106a0 <__swc_fn_23cea7fa_000134_10472836>
  40ce79:	add    rsp,0x8
  40ce7d:	ret
	...

000000000040ce80 <__swc_fn_23cea7fa_000139_e4a7a8b1>:
  40ce80:	push   rdi
  40ce81:	push   rsi
  40ce82:	sub    rsp,0xa8
  40ce89:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ce8f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ce95:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ce9b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cea1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cea7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cead:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ceb3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ceb9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cec2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cecb:	mov    edi,0x28
  40ced0:	xor    eax,eax
  40ced2:	call   4070d0 <malloc@plt>
  40ced7:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cedd:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cee3:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cee9:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ceef:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cef5:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cefb:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cf01:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cf07:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cf10:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cf19:	add    rsp,0xa8
  40cf20:	pop    rsi
  40cf21:	pop    rdi
  40cf22:	ret
	...

000000000040cf30 <__swc_fn_23cea7fa_000142_89a6ef72>:
  40cf30:	mov    QWORD PTR [r8],0x0
  40cf37:	cmp    rdx,0x10
  40cf3b:	jae    40cf40 <__swc_fn_23cea7fa_000142_89a6ef72+0x10>
  40cf3d:	xor    eax,eax
  40cf3f:	ret
  40cf40:	mov    eax,DWORD PTR [rcx]
  40cf42:	cmp    eax,0x42445753
  40cf48:	jne    40cf52 <__swc_fn_23cea7fa_000142_89a6ef72+0x22>
  40cf4a:	mov    eax,DWORD PTR [rcx+0x4]
  40cf4d:	cmp    eax,0x1
  40cf50:	je     40cf55 <__swc_fn_23cea7fa_000142_89a6ef72+0x25>
  40cf52:	xor    eax,eax
  40cf54:	ret
  40cf55:	mov    QWORD PTR [r8],rdx
  40cf58:	mov    rax,rcx
  40cf5b:	ret
  40cf5c:	add    BYTE PTR [rax],al
	...

000000000040cf60 <__swc_fn_23cea7fa_000145_32a1d6a2>:
  40cf60:	push   rbx
  40cf61:	sub    rsp,0xe0
  40cf68:	lea    rbx,[rsp+0x8]
  40cf6d:	vxorps xmm0,xmm0,xmm0
  40cf71:	vmovups YMMWORD PTR [rbx],ymm0
  40cf75:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40cf7a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40cf7f:	vzeroupper
  40cf82:	mov    DWORD PTR [rbx+0x60],0x0
  40cf89:	mov    r8,rbx
  40cf8c:	mov    rdx,rcx
  40cf8f:	nop
  40cf90:	mov    r9,rdx
  40cf93:	movabs rdx,0x6666666666666667
  40cf9d:	mov    rax,r9
  40cfa0:	imul   rdx
  40cfa3:	sar    rdx,0x2
  40cfa7:	mov    r10,rdx
  40cfaa:	shr    rdx,0x3f
  40cfae:	add    r10,rdx
  40cfb1:	mov    rdx,r10
  40cfb4:	imul   r11,r10,0xa
  40cfb8:	sub    r9,r11
  40cfbb:	mov    r11,QWORD PTR [rip+0x657e]        # 413540 <__swc_rdata_base_23cea7fa+0x430>
  40cfc2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40cfc7:	mov    BYTE PTR [r8],r9b
  40cfca:	lea    r9,[r8+0x1]
  40cfce:	mov    r8,r9
  40cfd1:	test   r10,r10
  40cfd4:	jne    40cf90 <__swc_fn_23cea7fa_000145_32a1d6a2+0x30>
  40cfd6:	test   rcx,rcx
  40cfd9:	jge    40cfe3 <__swc_fn_23cea7fa_000145_32a1d6a2+0x83>
  40cfdb:	mov    BYTE PTR [r9],0x2d
  40cfdf:	add    r8,0x1
  40cfe3:	mov    BYTE PTR [r8],0x0
  40cfe7:	sub    r8,0x1
  40cfeb:	mov    rax,rbx
  40cfee:	cmp    rax,r8
  40cff1:	jae    40d016 <__swc_fn_23cea7fa_000145_32a1d6a2+0xb6>
  40cff3:	cs nop WORD PTR [rax+rax*1+0x0]
  40cffd:	nop    DWORD PTR [rax]
  40d000:	mov    cl,BYTE PTR [r8]
  40d003:	mov    dl,BYTE PTR [rax]
  40d005:	mov    BYTE PTR [r8],dl
  40d008:	sub    r8,0x1
  40d00c:	mov    BYTE PTR [rax],cl
  40d00e:	inc    rax
  40d011:	cmp    rax,r8
  40d014:	jb     40d000 <__swc_fn_23cea7fa_000145_32a1d6a2+0xa0>
  40d016:	xor    eax,eax
  40d018:	test   rbx,rbx
  40d01b:	je     40d03e <__swc_fn_23cea7fa_000145_32a1d6a2+0xde>
  40d01d:	mov    rcx,rbx
  40d020:	mov    dl,BYTE PTR [rcx]
  40d022:	test   dl,dl
  40d024:	je     40d03e <__swc_fn_23cea7fa_000145_32a1d6a2+0xde>
  40d026:	cs nop WORD PTR [rax+rax*1+0x0]
  40d030:	add    rcx,0x1
  40d034:	add    rax,0x1
  40d038:	mov    dl,BYTE PTR [rcx]
  40d03a:	test   dl,dl
  40d03c:	jne    40d030 <__swc_fn_23cea7fa_000145_32a1d6a2+0xd0>
  40d03e:	mov    QWORD PTR [rbx+0xa8],rbx
  40d045:	mov    QWORD PTR [rbx+0xb0],rax
  40d04c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d054:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d05c:	lea    rcx,[rbx+0xb8]
  40d063:	call   4101f0 <__swc_fn_23cea7fa_000116_3f5cfdef>
  40d068:	add    rsp,0xe0
  40d06f:	pop    rbx
  40d070:	ret
	...

000000000040d080 <__swc_fn_23cea7fa_000148_365b4daf>:
  40d080:	vxorps xmm0,xmm0,xmm0
  40d084:	vmovups XMMWORD PTR [rcx],xmm0
  40d088:	mov    QWORD PTR [rcx+0x10],0x0
  40d090:	ret
	...

000000000040d0a0 <__swc_fn_23cea7fa_000151_365b4daf>:
  40d0a0:	vxorps xmm0,xmm0,xmm0
  40d0a4:	vmovups XMMWORD PTR [rcx],xmm0
  40d0a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d0ad:	vxorps xmm0,xmm0,xmm0
  40d0b1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d0b6:	vmovups xmm0,XMMWORD PTR [rip+0x657a]        # 413638 <__swc_rdata_base_23cea7fa+0x528>
  40d0be:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d0c3:	vxorps xmm0,xmm0,xmm0
  40d0c7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d0cc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d0d1:	mov    QWORD PTR [rcx+0x60],0x0
  40d0d9:	ret
  40d0da:	add    BYTE PTR [rax],al
  40d0dc:	add    BYTE PTR [rax],al
	...

000000000040d0e0 <__swc_fn_23cea7fa_000154_365b4daf>:
  40d0e0:	vxorps xmm0,xmm0,xmm0
  40d0e4:	vmovups XMMWORD PTR [rcx],xmm0
  40d0e8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d0ed:	vxorps xmm0,xmm0,xmm0
  40d0f1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d0f6:	vmovups xmm0,XMMWORD PTR [rip+0x6662]        # 413760 <__swc_rdata_base_23cea7fa+0x650>
  40d0fe:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d103:	vxorps xmm0,xmm0,xmm0
  40d107:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d10c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d111:	vxorps xmm0,xmm0,xmm0
  40d115:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40d11a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40d11f:	vxorps xmm0,xmm0,xmm0
  40d123:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40d12b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40d133:	vxorps xmm0,xmm0,xmm0
  40d137:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40d13f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40d147:	vxorps xmm0,xmm0,xmm0
  40d14b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40d153:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40d15b:	mov    QWORD PTR [rcx+0xe0],0x0
  40d166:	ret
	...

000000000040d170 <__swc_fn_23cea7fa_000157_3495a3ca>:
  40d170:	push   rbx
  40d171:	mov    rbx,rcx
  40d174:	call   411c30 <__swc_fn_23cea7fa_000158_31e09513>
  40d179:	mov    rax,QWORD PTR [rbx+0x10]
  40d17d:	test   rax,rax
  40d180:	je     40d191 <__swc_fn_23cea7fa_000157_3495a3ca+0x21>
  40d182:	mov    rcx,rbx
  40d185:	mov    rdx,rax
  40d188:	mov    r8,QWORD PTR [rbx+0x18]
  40d18c:	call   409e90 <__swc_fn_23cea7fa_000156_9e2052d6>
  40d191:	vxorps xmm0,xmm0,xmm0
  40d195:	vmovups XMMWORD PTR [rbx],xmm0
  40d199:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d19e:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d1a3:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d1a8:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d1ad:	mov    QWORD PTR [rbx+0x50],0x0
  40d1b5:	pop    rbx
  40d1b6:	ret
	...

000000000040d1c0 <__swc_fn_23cea7fa_000160_dfca9093>:
  40d1c0:	sub    rsp,0x10
  40d1c4:	mov    eax,r8d
  40d1c7:	mov    r8d,r9d
  40d1ca:	test   r9d,r9d
  40d1cd:	jne    40d1e6 <__swc_fn_23cea7fa_000160_dfca9093+0x26>
  40d1cf:	vmovups xmm0,XMMWORD PTR [rip+0x6641]        # 413818 <__swc_rdata_base_23cea7fa+0x708>
  40d1d7:	vmovups XMMWORD PTR [r10],xmm0
  40d1dc:	mov    eax,0x1
  40d1e1:	add    rsp,0x10
  40d1e5:	ret
  40d1e6:	mov    r9,r8
  40d1e9:	cmp    r8,rax
  40d1ec:	jb     40d1f3 <__swc_fn_23cea7fa_000160_dfca9093+0x33>
  40d1ee:	cmp    r9,rdx
  40d1f1:	jb     40d1fa <__swc_fn_23cea7fa_000160_dfca9093+0x3a>
  40d1f3:	xor    eax,eax
  40d1f5:	add    rsp,0x10
  40d1f9:	ret
  40d1fa:	xor    eax,eax
  40d1fc:	lea    r8,[r9+rax*1]
  40d200:	cmp    r8,rdx
  40d203:	jae    40d233 <__swc_fn_23cea7fa_000160_dfca9093+0x73>
  40d205:	cs nop WORD PTR [rax+rax*1+0x0]
  40d20f:	cs nop WORD PTR [rax+rax*1+0x0]
  40d219:	nop    DWORD PTR [rax+0x0]
  40d220:	cmp    BYTE PTR [rcx+r8*1],0x0
  40d225:	je     40d233 <__swc_fn_23cea7fa_000160_dfca9093+0x73>
  40d227:	inc    rax
  40d22a:	lea    r8,[r9+rax*1]
  40d22e:	cmp    r8,rdx
  40d231:	jb     40d220 <__swc_fn_23cea7fa_000160_dfca9093+0x60>
  40d233:	cmp    r8,rdx
  40d236:	jne    40d23f <__swc_fn_23cea7fa_000160_dfca9093+0x7f>
  40d238:	xor    eax,eax
  40d23a:	add    rsp,0x10
  40d23e:	ret
  40d23f:	add    rcx,r9
  40d242:	mov    QWORD PTR [rsp],rcx
  40d246:	mov    QWORD PTR [rsp+0x8],rax
  40d24b:	vmovups xmm0,XMMWORD PTR [rsp]
  40d250:	vmovups XMMWORD PTR [r10],xmm0
  40d255:	mov    eax,0x1
  40d25a:	add    rsp,0x10
  40d25e:	ret
	...

000000000040d260 <__swc_fn_23cea7fa_000163_3a7aae74>:
  40d260:	push   rbp
  40d261:	push   rbx
  40d262:	push   rsi
  40d263:	push   rdi
  40d264:	push   r12
  40d266:	push   r13
  40d268:	push   r14
  40d26a:	push   r15
  40d26c:	sub    rsp,0x10
  40d270:	mov    rbp,rsp
  40d273:	vmovups XMMWORD PTR [rsp],xmm6
  40d278:	sub    rsp,0x50
  40d27c:	mov    rbx,rsp
  40d27f:	mov    rsi,r8
  40d282:	mov    QWORD PTR [rsp+0x30],r8
  40d287:	mov    rdi,rcx
  40d28a:	mov    QWORD PTR [rsp+0x38],rcx
  40d28f:	mov    r12,rdx
  40d292:	xor    r13b,r13b
  40d295:	mov    r14,QWORD PTR [rdi+0x8]
  40d299:	mov    QWORD PTR [rsp+0x40],r14
  40d29e:	xor    r15d,r15d
  40d2a1:	test   r14,r14
  40d2a4:	jbe    40d4fe <__swc_fn_23cea7fa_000163_3a7aae74+0x29e>
  40d2aa:	mov    r14,QWORD PTR [rdi]
  40d2ad:	mov    rax,QWORD PTR [rsp+0x40]
  40d2b2:	mov    QWORD PTR [rsp+0x48],r14
  40d2b7:	vmovups xmm6,XMMWORD PTR [rip+0x6179]        # 413438 <__swc_rdata_base_23cea7fa+0x328>
  40d2bf:	nop
  40d2c0:	cmp    QWORD PTR [r14+r15*8],0x0
  40d2c5:	jne    40d2cf <__swc_fn_23cea7fa_000163_3a7aae74+0x6f>
  40d2c7:	mov    r14,rax
  40d2ca:	jmp    40d4de <__swc_fn_23cea7fa_000163_3a7aae74+0x27e>
  40d2cf:	mov    rcx,QWORD PTR [rdi]
  40d2d2:	mov    rdx,QWORD PTR [rcx+r15*8]
  40d2d6:	mov    rdi,rbx
  40d2d9:	mov    rcx,rdi
  40d2dc:	sub    rsp,0x8
  40d2e0:	mov    r14,rax
  40d2e3:	call   409f10 <__swc_fn_23cea7fa_000162_61e293bf>
  40d2e8:	add    rsp,0x8
  40d2ec:	mov    al,BYTE PTR [rbx]
  40d2ee:	test   al,al
  40d2f0:	je     40d4de <__swc_fn_23cea7fa_000163_3a7aae74+0x27e>
  40d2f6:	mov    al,BYTE PTR [rbx+0x1]
  40d2f9:	test   al,al
  40d2fb:	jne    40d306 <__swc_fn_23cea7fa_000163_3a7aae74+0xa6>
  40d2fd:	test   sil,sil
  40d300:	je     40d4de <__swc_fn_23cea7fa_000163_3a7aae74+0x27e>
  40d306:	test   r13b,r13b
  40d309:	jne    40d3c7 <__swc_fn_23cea7fa_000163_3a7aae74+0x167>
  40d30f:	test   r12,r12
  40d312:	je     40d3c7 <__swc_fn_23cea7fa_000163_3a7aae74+0x167>
  40d318:	mov    al,BYTE PTR [rbx+0x1]
  40d31b:	test   al,al
  40d31d:	je     40d4de <__swc_fn_23cea7fa_000163_3a7aae74+0x27e>
  40d323:	mov    eax,DWORD PTR [rbx+0x28]
  40d326:	cmp    DWORD PTR [r12+0x20],eax
  40d32b:	jne    40d4de <__swc_fn_23cea7fa_000163_3a7aae74+0x27e>
  40d331:	mov    rax,QWORD PTR [r12]
  40d335:	mov    rcx,QWORD PTR [r12+0x8]
  40d33a:	cmp    QWORD PTR [rbx+0x20],rcx
  40d33e:	jne    40d4de <__swc_fn_23cea7fa_000163_3a7aae74+0x27e>
  40d344:	mov    cl,0x1
  40d346:	test   rax,rax
  40d349:	je     40d3b2 <__swc_fn_23cea7fa_000163_3a7aae74+0x152>
  40d34f:	mov    rdx,QWORD PTR [rbx+0x20]
  40d353:	xor    r8d,r8d
  40d356:	test   rdx,rdx
  40d359:	jbe    40d3b2 <__swc_fn_23cea7fa_000163_3a7aae74+0x152>
  40d35b:	mov    r9,QWORD PTR [rbx+0x18]
  40d35f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40d364:	cs nop WORD PTR [rax+rax*1+0x0]
  40d36e:	xchg   ax,ax
  40d370:	mov    r10b,BYTE PTR [rax+r8*1]
  40d374:	cmp    BYTE PTR [r9+r8*1],r10b
  40d378:	je     40d3a9 <__swc_fn_23cea7fa_000163_3a7aae74+0x149>
  40d37a:	vmovq  r10,xmm0
  40d37f:	cmp    BYTE PTR [r10+r8*1],0x5c
  40d384:	jne    40d38d <__swc_fn_23cea7fa_000163_3a7aae74+0x12d>
  40d386:	cmp    BYTE PTR [rax+r8*1],0x2f
  40d38b:	je     40d3a9 <__swc_fn_23cea7fa_000163_3a7aae74+0x149>
  40d38d:	vmovq  r10,xmm0
  40d392:	cmp    BYTE PTR [r10+r8*1],0x2f
  40d397:	jne    40d3a0 <__swc_fn_23cea7fa_000163_3a7aae74+0x140>
  40d399:	cmp    BYTE PTR [rax+r8*1],0x5c
  40d39e:	je     40d3a9 <__swc_fn_23cea7fa_000163_3a7aae74+0x149>
  40d3a0:	xor    eax,eax
  40d3a2:	movzx  eax,al
  40d3a5:	mov    cl,al
  40d3a7:	jmp    40d3b2 <__swc_fn_23cea7fa_000163_3a7aae74+0x152>
  40d3a9:	add    r8,0x1
  40d3ad:	cmp    r8,rdx
  40d3b0:	jb     40d370 <__swc_fn_23cea7fa_000163_3a7aae74+0x110>
  40d3b2:	test   cl,cl
  40d3b4:	je     40d4de <__swc_fn_23cea7fa_000163_3a7aae74+0x27e>
  40d3ba:	mov    eax,0x1
  40d3bf:	mov    r13b,al
  40d3c2:	jmp    40d4de <__swc_fn_23cea7fa_000163_3a7aae74+0x27e>
  40d3c7:	mov    r13b,0x1
  40d3ca:	sub    rsp,0x20
  40d3ce:	mov    rax,rsp
  40d3d1:	lea    rcx,[rdi+0x8]
  40d3d5:	mov    QWORD PTR [rax],rcx
  40d3d8:	lea    rsi,[rip+0x5f31]        # 413310 <__swc_rdata_base_23cea7fa+0x200>
  40d3df:	mov    QWORD PTR [rax+0x8],rsi
  40d3e3:	mov    QWORD PTR [rax+0x10],rsp
  40d3e7:	mov    QWORD PTR [rax+0x18],0x1
  40d3ef:	lea    rcx,[rsp+0x10]
  40d3f4:	sub    rsp,0x8
  40d3f8:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  40d3fd:	add    rsp,0x8
  40d401:	add    rsp,0x20
  40d405:	mov    al,BYTE PTR [rbx+0x1]
  40d408:	test   al,al
  40d40a:	je     40d4a7 <__swc_fn_23cea7fa_000163_3a7aae74+0x247>
  40d410:	lea    rax,[rip+0x64a1]        # 4138b8 <__swc_rdata_base_23cea7fa+0x7a8>
  40d417:	sub    rsp,0x20
  40d41b:	mov    rcx,rsp
  40d41e:	mov    QWORD PTR [rcx],rax
  40d421:	mov    QWORD PTR [rcx+0x8],rsi
  40d425:	mov    QWORD PTR [rcx+0x10],rsp
  40d429:	mov    QWORD PTR [rcx+0x18],0x1
  40d431:	lea    rcx,[rsp+0x10]
  40d436:	sub    rsp,0x8
  40d43a:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  40d43f:	add    rsp,0x8
  40d443:	add    rsp,0x20
  40d447:	mov    eax,DWORD PTR [rbx+0x28]
  40d44a:	sub    rsp,0x60
  40d44e:	mov    rcx,rsp
  40d451:	lea    rdx,[rdi+0x18]
  40d455:	mov    QWORD PTR [rcx+0x18],rdx
  40d459:	mov    QWORD PTR [rcx+0x20],rsi
  40d45d:	vmovups XMMWORD PTR [rcx],xmm6
  40d461:	mov    QWORD PTR [rcx+0x28],rsp
  40d465:	mov    QWORD PTR [rcx+0x30],rsi
  40d469:	mov    DWORD PTR [rcx+0x10],eax
  40d46c:	lea    rax,[rsp+0x10]
  40d471:	mov    QWORD PTR [rcx+0x38],rax
  40d475:	lea    rax,[rip+0x5f54]        # 4133d0 <__swc_rdata_base_23cea7fa+0x2c0>
  40d47c:	mov    QWORD PTR [rcx+0x40],rax
  40d480:	lea    rax,[rsp+0x18]
  40d485:	mov    QWORD PTR [rcx+0x48],rax
  40d489:	mov    QWORD PTR [rcx+0x50],0x3
  40d491:	lea    rcx,[rsp+0x48]
  40d496:	sub    rsp,0x8
  40d49a:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  40d49f:	add    rsp,0x8
  40d4a3:	add    rsp,0x60
  40d4a7:	lea    rax,[rip+0x5eba]        # 413368 <__swc_rdata_base_23cea7fa+0x258>
  40d4ae:	sub    rsp,0x20
  40d4b2:	mov    rcx,rsp
  40d4b5:	mov    QWORD PTR [rcx],rax
  40d4b8:	mov    QWORD PTR [rcx+0x8],rsi
  40d4bc:	mov    QWORD PTR [rcx+0x10],rsp
  40d4c0:	mov    QWORD PTR [rcx+0x18],0x1
  40d4c8:	lea    rcx,[rsp+0x10]
  40d4cd:	sub    rsp,0x8
  40d4d1:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  40d4d6:	add    rsp,0x8
  40d4da:	add    rsp,0x20
  40d4de:	add    r15,0x1
  40d4e2:	cmp    r15,r14
  40d4e5:	jae    40d4fe <__swc_fn_23cea7fa_000163_3a7aae74+0x29e>
  40d4e7:	mov    rsi,QWORD PTR [rsp+0x30]
  40d4ec:	mov    rdi,QWORD PTR [rsp+0x38]
  40d4f1:	mov    rax,r14
  40d4f4:	mov    r14,QWORD PTR [rsp+0x48]
  40d4f9:	jmp    40d2c0 <__swc_fn_23cea7fa_000163_3a7aae74+0x60>
  40d4fe:	add    rsp,0x50
  40d502:	vmovups xmm6,XMMWORD PTR [rsp]
  40d507:	add    rsp,0x10
  40d50b:	pop    r15
  40d50d:	pop    r14
  40d50f:	pop    r13
  40d511:	pop    r12
  40d513:	pop    rdi
  40d514:	pop    rsi
  40d515:	pop    rbx
  40d516:	pop    rbp
  40d517:	ret
	...

000000000040d520 <__swc_fn_23cea7fa_000166_c370e18e>:
  40d520:	sub    rsp,0x8
  40d524:	call   410470 <__swc_fn_23cea7fa_000125_7a81492f>
  40d529:	add    rsp,0x8
  40d52d:	ret
	...

000000000040d530 <__swc_fn_23cea7fa_000169_4694b8ad>:
  40d530:	push   rsi
  40d531:	sub    rsp,0x30
  40d535:	lea    rsi,[rip+0x19864]        # 426da0 <__swc_bss_base_23cea7fa+0x2d60>
  40d53c:	mov    rax,QWORD PTR [rsi]
  40d53f:	test   rax,rax
  40d542:	je     40d54a <__swc_fn_23cea7fa_000169_4694b8ad+0x1a>
  40d544:	add    rsp,0x30
  40d548:	pop    rsi
  40d549:	ret
  40d54a:	mov    ecx,0x2
  40d54f:	mov    edx,0x8020
  40d554:	call   40fb10 <__swc_fn_23cea7fa_000107_c8d4a68e>
  40d559:	test   rax,rax
  40d55c:	jne    40d56d <__swc_fn_23cea7fa_000169_4694b8ad+0x3d>
  40d55e:	mov    QWORD PTR [rsp+0x18],rax
  40d563:	call   40c9d0 <__swc_fn_23cea7fa_000118_591530fe>
  40d568:	mov    rax,QWORD PTR [rsp+0x18]
  40d56d:	mov    rcx,rax
  40d570:	xchg   QWORD PTR [rsi],rcx
  40d573:	add    rsp,0x30
  40d577:	pop    rsi
  40d578:	ret
  40d579:	add    BYTE PTR [rax],al
  40d57b:	add    BYTE PTR [rax],al
  40d57d:	add    BYTE PTR [rax],al
	...

000000000040d580 <__swc_fn_23cea7fa_000172_1751ecdd>:
  40d580:	push   rsi
  40d581:	test   r8,r8
  40d584:	jne    40d588 <__swc_fn_23cea7fa_000172_1751ecdd+0x8>
  40d586:	pop    rsi
  40d587:	ret
  40d588:	lea    rax,[rcx+0x18]
  40d58c:	mov    r10,QWORD PTR [rax]
  40d58f:	lea    r11,[r10+0x1]
  40d593:	mov    QWORD PTR [rax],r11
  40d596:	mov    r11,rdx
  40d599:	not    rdx
  40d59c:	lea    rsi,[r8-0x1]
  40d5a0:	cmp    rsi,rdx
  40d5a3:	ja     40d5c3 <__swc_fn_23cea7fa_000172_1751ecdd+0x43>
  40d5a5:	lea    rdx,[r11+r8*1]
  40d5a9:	dec    rdx
  40d5ac:	shr    rdx,0x6
  40d5b0:	mov    r8,r11
  40d5b3:	shr    r8,0x6
  40d5b7:	mov    rsi,rdx
  40d5ba:	sub    rsi,r8
  40d5bd:	cmp    rsi,0x8
  40d5c1:	jb     40d5d9 <__swc_fn_23cea7fa_000172_1751ecdd+0x59>
  40d5c3:	lea    rcx,[rcx+0x10]
  40d5c7:	mov    rdx,QWORD PTR [rcx]
  40d5ca:	add    rdx,r9
  40d5cd:	mov    QWORD PTR [rcx],rdx
  40d5d0:	lea    rcx,[r10+0x2]
  40d5d4:	mov    QWORD PTR [rax],rcx
  40d5d7:	pop    rsi
  40d5d8:	ret
  40d5d9:	shr    r11,0x6
  40d5dd:	nop    DWORD PTR [rax]
  40d5e0:	cmp    r11,rdx
  40d5e3:	ja     40d623 <__swc_fn_23cea7fa_000172_1751ecdd+0xa3>
  40d5e5:	jmp    40d5f6 <__swc_fn_23cea7fa_000172_1751ecdd+0x76>
  40d5e7:	nop    WORD PTR [rax+rax*1+0x0]
  40d5f0:	add    r11,0x1
  40d5f4:	jmp    40d5e0 <__swc_fn_23cea7fa_000172_1751ecdd+0x60>
  40d5f6:	mov    r8,r11
  40d5f9:	shr    r8,0xc
  40d5fd:	mov    rsi,r11
  40d600:	xor    rsi,r8
  40d603:	mov    r8,r11
  40d606:	shr    r8,0x18
  40d60a:	xor    rsi,r8
  40d60d:	and    esi,0xfff
  40d613:	lea    r8,[rcx+rsi*8+0x20]
  40d618:	mov    rsi,QWORD PTR [r8]
  40d61b:	add    rsi,r9
  40d61e:	mov    QWORD PTR [r8],rsi
  40d621:	jmp    40d5f0 <__swc_fn_23cea7fa_000172_1751ecdd+0x70>
  40d623:	lea    rcx,[r10+0x2]
  40d627:	mov    QWORD PTR [rax],rcx
  40d62a:	pop    rsi
  40d62b:	ret
  40d62c:	add    BYTE PTR [rax],al
	...

000000000040d630 <__swc_fn_23cea7fa_000175_2744b483>:
  40d630:	push   rbx
  40d631:	sub    rsp,0x70
  40d635:	cmp    rcx,0xffffffffffffffef
  40d639:	jbe    40d643 <__swc_fn_23cea7fa_000175_2744b483+0x13>
  40d63b:	xor    eax,eax
  40d63d:	add    rsp,0x70
  40d641:	pop    rbx
  40d642:	ret
  40d643:	vxorps xmm0,xmm0,xmm0
  40d647:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40d64d:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40d653:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  40d659:	vzeroupper
  40d65c:	lea    rax,[rcx+0x10]
  40d660:	mov    QWORD PTR [rsp+0x50],rax
  40d665:	mov    DWORD PTR [rsp+0x60],0x10
  40d66d:	mov    rcx,QWORD PTR [rip+0x196cc]        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  40d674:	test   rcx,rcx
  40d677:	jne    40d689 <__swc_fn_23cea7fa_000175_2744b483+0x59>
  40d679:	call   40a1a0 <__swc_fn_23cea7fa_000165_56054fe7>
  40d67e:	lea    rcx,[rax+0x1]
  40d682:	mov    QWORD PTR [rip+0x196b7],rcx        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  40d689:	dec    rcx
  40d68c:	call   411fa0 <__swc_fn_23cea7fa_000167_39c041ad>
  40d691:	mov    rcx,QWORD PTR [rax]
  40d694:	lea    rdx,[rsp+0x8]
  40d699:	mov    rbx,QWORD PTR [rax+0x8]
  40d69d:	mov    rbx,QWORD PTR [rbx+0x8]
  40d6a1:	call   rbx
  40d6a3:	mov    rax,QWORD PTR [rsp+0x48]
  40d6a8:	test   rax,rax
  40d6ab:	jne    40d6b5 <__swc_fn_23cea7fa_000175_2744b483+0x85>
  40d6ad:	xor    eax,eax
  40d6af:	add    rsp,0x70
  40d6b3:	pop    rbx
  40d6b4:	ret
  40d6b5:	mov    rcx,QWORD PTR [rsp+0x50]
  40d6ba:	mov    QWORD PTR [rax],rcx
  40d6bd:	mov    QWORD PTR [rax+0x8],0x0
  40d6c5:	lea    rax,[rax+0x10]
  40d6c9:	add    rsp,0x70
  40d6cd:	pop    rbx
  40d6ce:	ret
	...

000000000040d6e0 <__swc_fn_23cea7fa_000178_3a24e5ea>:
  40d6e0:	push   rbp
  40d6e1:	push   rsi
  40d6e2:	push   rdi
  40d6e3:	push   r12
  40d6e5:	push   r13
  40d6e7:	push   r15
  40d6e9:	push   r14
  40d6eb:	sub    rsp,0x18
  40d6ef:	mov    rbp,rsp
  40d6f2:	vmovups XMMWORD PTR [rsp],xmm6
  40d6f7:	sub    rsp,0x210
  40d6fe:	mov    ecx,0x1400
  40d703:	sub    rsp,0x8
  40d707:	call   40d630 <__swc_fn_23cea7fa_000175_2744b483>
  40d70c:	add    rsp,0x8
  40d710:	mov    rsi,rax
  40d713:	mov    QWORD PTR [rsp+0x1d0],rax
  40d71b:	mov    ecx,0x1000
  40d720:	sub    rsp,0x8
  40d724:	call   40d630 <__swc_fn_23cea7fa_000175_2744b483>
  40d729:	add    rsp,0x8
  40d72d:	mov    rdi,rax
  40d730:	mov    QWORD PTR [rsp+0x1d8],rax
  40d738:	mov    ecx,0x1000
  40d73d:	sub    rsp,0x8
  40d741:	call   40d630 <__swc_fn_23cea7fa_000175_2744b483>
  40d746:	add    rsp,0x8
  40d74a:	mov    r12,rax
  40d74d:	mov    QWORD PTR [rsp+0x1e0],rax
  40d755:	xor    ecx,ecx
  40d757:	xor    r8d,r8d
  40d75a:	nop    WORD PTR [rax+rax*1+0x0]
  40d760:	mov    r9,QWORD PTR [rip+0x148a9]        # 422010 <__swc_data_base_23cea7fa+0x10>
  40d767:	imul   r9,r9,0x41a7
  40d76e:	movabs rdx,0x200000005
  40d778:	mov    r11,rax
  40d77b:	mov    rax,r9
  40d77e:	mul    rdx
  40d781:	mov    r10,rdx
  40d784:	mov    rax,r11
  40d787:	mov    rdx,r9
  40d78a:	sub    rdx,r10
  40d78d:	shr    rdx,1
  40d790:	add    rdx,r10
  40d793:	shr    rdx,0x1e
  40d797:	imul   r10,rdx,0x7fffffff
  40d79e:	sub    r9,r10
  40d7a1:	mov    QWORD PTR [rip+0x14868],r9        # 422010 <__swc_data_base_23cea7fa+0x10>
  40d7a8:	and    r9d,0x7
  40d7ac:	lea    r9,[r9+0x2]
  40d7b0:	mov    QWORD PTR [rdi+r8*8],rcx
  40d7b4:	mov    QWORD PTR [r12+r8*8],r9
  40d7b8:	xor    r10d,r10d
  40d7bb:	test   r9,r9
  40d7be:	jbe    40d84b <__swc_fn_23cea7fa_000178_3a24e5ea+0x16b>
  40d7c4:	cs nop WORD PTR [rax+rax*1+0x0]
  40d7ce:	xchg   ax,ax
  40d7d0:	lea    rdx,[rcx+r10*1]
  40d7d4:	lea    r11,[rsi+rdx*1]
  40d7d8:	mov    r13,QWORD PTR [rip+0x14831]        # 422010 <__swc_data_base_23cea7fa+0x10>
  40d7df:	imul   r13,r13,0x41a7
  40d7e6:	movabs rdx,0x200000005
  40d7f0:	mov    r15,rax
  40d7f3:	mov    rax,r13
  40d7f6:	mul    rdx
  40d7f9:	mov    r14,rdx
  40d7fc:	mov    rdx,r13
  40d7ff:	sub    rdx,r14
  40d802:	shr    rdx,1
  40d805:	add    rdx,r14
  40d808:	shr    rdx,0x1e
  40d80c:	imul   r14,rdx,0x7fffffff
  40d813:	sub    r13,r14
  40d816:	mov    QWORD PTR [rip+0x147f3],r13        # 422010 <__swc_data_base_23cea7fa+0x10>
  40d81d:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40d827:	mov    rax,r13
  40d82a:	mul    rdx
  40d82d:	mov    rax,r15
  40d830:	shr    rdx,0x3
  40d834:	imul   rdx,rdx,0x1a
  40d838:	sub    r13,rdx
  40d83b:	lea    rdx,[r13+0x61]
  40d83f:	mov    BYTE PTR [r11],dl
  40d842:	add    r10,0x1
  40d846:	cmp    r10,r9
  40d849:	jb     40d7d0 <__swc_fn_23cea7fa_000178_3a24e5ea+0xf0>
  40d84b:	add    rcx,r9
  40d84e:	add    r8,0x1
  40d852:	cmp    r8,0x200
  40d859:	jb     40d760 <__swc_fn_23cea7fa_000178_3a24e5ea+0x80>
  40d85f:	mov    ecx,0x100000
  40d864:	sub    rsp,0x8
  40d868:	call   40d630 <__swc_fn_23cea7fa_000175_2744b483>
  40d86d:	add    rsp,0x8
  40d871:	mov    r13,rax
  40d874:	xor    ecx,ecx
  40d876:	cs nop WORD PTR [rax+rax*1+0x0]
  40d880:	cs nop WORD PTR [rax+rax*1+0x0]
  40d88a:	nop    WORD PTR [rax+rax*1+0x0]
  40d890:	cmp    rcx,0x100000
  40d897:	jge    40d943 <__swc_fn_23cea7fa_000178_3a24e5ea+0x263>
  40d89d:	mov    r8,QWORD PTR [rip+0x1476c]        # 422010 <__swc_data_base_23cea7fa+0x10>
  40d8a4:	imul   r8,r8,0x41a7
  40d8ab:	movabs rdx,0x200000005
  40d8b5:	mov    rax,r8
  40d8b8:	mul    rdx
  40d8bb:	mov    r9,rdx
  40d8be:	mov    rdx,r8
  40d8c1:	sub    rdx,r9
  40d8c4:	shr    rdx,1
  40d8c7:	add    rdx,r9
  40d8ca:	shr    rdx,0x1e
  40d8ce:	imul   r9,rdx,0x7fffffff
  40d8d5:	sub    r8,r9
  40d8d8:	mov    QWORD PTR [rip+0x14731],r8        # 422010 <__swc_data_base_23cea7fa+0x10>
  40d8df:	and    r8d,0x1ff
  40d8e6:	xor    edx,edx
  40d8e8:	mov    r9,QWORD PTR [r12+r8*8]
  40d8ec:	cmp    rdx,r9
  40d8ef:	jae    40d928 <__swc_fn_23cea7fa_000178_3a24e5ea+0x248>
  40d8f1:	cs nop WORD PTR [rax+rax*1+0x0]
  40d8fb:	nop    DWORD PTR [rax+rax*1+0x0]
  40d900:	cmp    rcx,0x100000
  40d907:	jge    40d928 <__swc_fn_23cea7fa_000178_3a24e5ea+0x248>
  40d909:	mov    r9,QWORD PTR [rdi+r8*8]
  40d90d:	add    r9,rdx
  40d910:	mov    r9b,BYTE PTR [rsi+r9*1]
  40d914:	mov    BYTE PTR [r13+rcx*1+0x0],r9b
  40d919:	inc    rcx
  40d91c:	inc    rdx
  40d91f:	mov    r9,QWORD PTR [r12+r8*8]
  40d923:	cmp    rdx,r9
  40d926:	jb     40d900 <__swc_fn_23cea7fa_000178_3a24e5ea+0x220>
  40d928:	cmp    rcx,0x100000
  40d92f:	jge    40d890 <__swc_fn_23cea7fa_000178_3a24e5ea+0x1b0>
  40d935:	mov    BYTE PTR [r13+rcx*1+0x0],0x20
  40d93b:	inc    rcx
  40d93e:	jmp    40d890 <__swc_fn_23cea7fa_000178_3a24e5ea+0x1b0>
  40d943:	sub    rsp,0x8
  40d947:	call   40a350 <__swc_fn_23cea7fa_000177_1ca87929>
  40d94c:	add    rsp,0x8
  40d950:	vmovups xmm6,xmm0
  40d954:	mov    ecx,0x80000
  40d959:	sub    rsp,0x8
  40d95d:	call   40d630 <__swc_fn_23cea7fa_000175_2744b483>
  40d962:	add    rsp,0x8
  40d966:	mov    r14,rax
  40d969:	mov    QWORD PTR [rsp+0x1e8],rax
  40d971:	mov    ecx,0x40000
  40d976:	sub    rsp,0x8
  40d97a:	call   40d630 <__swc_fn_23cea7fa_000175_2744b483>
  40d97f:	add    rsp,0x8
  40d983:	mov    r15,rax
  40d986:	xor    eax,eax
  40d988:	cs nop WORD PTR [rax+rax*1+0x0]
  40d992:	cs nop WORD PTR [rax+rax*1+0x0]
  40d99c:	nop    DWORD PTR [rax+0x0]
  40d9a0:	mov    QWORD PTR [r14+rax*8],0xffffffffffffffff
  40d9a8:	add    rax,0x1
  40d9ac:	cmp    rax,0x10000
  40d9b3:	jb     40d9a0 <__swc_fn_23cea7fa_000178_3a24e5ea+0x2c0>
  40d9b5:	xor    eax,eax
  40d9b7:	nop    WORD PTR [rax+rax*1+0x0]
  40d9c0:	mov    QWORD PTR [r15+rax*8],0xffffffffffffffff
  40d9c8:	add    rax,0x1
  40d9cc:	cmp    rax,0x8000
  40d9d3:	jl     40d9c0 <__swc_fn_23cea7fa_000178_3a24e5ea+0x2e0>
  40d9d5:	mov    ecx,0x200010
  40d9da:	sub    rsp,0x8
  40d9de:	call   40d630 <__swc_fn_23cea7fa_000175_2744b483>
  40d9e3:	add    rsp,0x8
  40d9e7:	mov    QWORD PTR [rsp+0x1f0],rax
  40d9ef:	xor    edi,edi
  40d9f1:	xor    eax,eax
  40d9f3:	vmovq  xmm0,rdi
  40d9f8:	vmovsd xmm2,QWORD PTR [rsp+0x1f0]
  40da01:	vmovsd xmm3,QWORD PTR [rsp+0x1e8]
  40da0a:	nop    WORD PTR [rax+rax*1+0x0]
  40da10:	lea    rcx,[rax+0x4]
  40da14:	cmp    rcx,0x100000
  40da1b:	jle    40da2f <__swc_fn_23cea7fa_000178_3a24e5ea+0x34f>
  40da1d:	mov    rsi,QWORD PTR [rsp+0x1f0]
  40da25:	vmovq  rdi,xmm0
  40da2a:	jmp    40dca1 <__swc_fn_23cea7fa_000178_3a24e5ea+0x5c1>
  40da2f:	xor    ecx,ecx
  40da31:	xor    edx,edx
  40da33:	mov    r8d,0x100000
  40da39:	sub    r8,rax
  40da3c:	mov    r9,r8
  40da3f:	cmp    r8,0x102
  40da46:	mov    r8d,0x102
  40da4c:	cmovge r9,r8
  40da50:	movzx  r8d,BYTE PTR [r13+rax*1+0x0]
  40da56:	imul   r8,r8,0x8c61
  40da5d:	movzx  r10d,BYTE PTR [r13+rax*1+0x1]
  40da63:	imul   r10,r10,0x441
  40da6a:	add    r8,r10
  40da6d:	movzx  r10d,BYTE PTR [r13+rax*1+0x2]
  40da73:	movzx  r12d,BYTE PTR [r13+rax*1+0x3]
  40da79:	add    r12,r10
  40da7c:	shl    r10,0x5
  40da80:	add    r10,r12
  40da83:	add    r8,r10
  40da86:	movzx  r8d,r8w
  40da8a:	vmovq  xmm1,r8
  40da8f:	mov    r10,QWORD PTR [r14+r8*8]
  40da93:	xor    r11d,r11d
  40da96:	lea    r12,[r13+rax*1+0x0]
  40da9b:	test   r10,r10
  40da9e:	jl     40db8d <__swc_fn_23cea7fa_000178_3a24e5ea+0x4ad>
  40daa4:	cs nop WORD PTR [rax+rax*1+0x0]
  40daae:	xchg   ax,ax
  40dab0:	mov    rsi,rax
  40dab3:	sub    rsi,r10
  40dab6:	cmp    rsi,0x8000
  40dabd:	jge    40db8d <__swc_fn_23cea7fa_000178_3a24e5ea+0x4ad>
  40dac3:	cmp    r11,0x20
  40dac7:	jge    40db8d <__swc_fn_23cea7fa_000178_3a24e5ea+0x4ad>
  40dacd:	xor    edi,edi
  40dacf:	lea    r8,[r13+r10*1+0x0]
  40dad4:	cmp    rdi,r9
  40dad7:	jge    40db63 <__swc_fn_23cea7fa_000178_3a24e5ea+0x483>
  40dadd:	cs nop WORD PTR [rax+rax*1+0x0]
  40dae7:	nop    WORD PTR [rax+rax*1+0x0]
  40daf0:	mov    r14,r9
  40daf3:	sub    r14,rdi
  40daf6:	cmp    r14,0x4
  40dafa:	jb     40db30 <__swc_fn_23cea7fa_000178_3a24e5ea+0x450>
  40dafc:	mov    r14b,BYTE PTR [r12+rdi*1]
  40db00:	cmp    BYTE PTR [r8+rdi*1],r14b
  40db04:	jne    40db63 <__swc_fn_23cea7fa_000178_3a24e5ea+0x483>
  40db06:	mov    r14b,BYTE PTR [r12+rdi*1+0x1]
  40db0b:	cmp    BYTE PTR [r8+rdi*1+0x1],r14b
  40db10:	jne    40db54 <__swc_fn_23cea7fa_000178_3a24e5ea+0x474>
  40db12:	mov    r14b,BYTE PTR [r12+rdi*1+0x2]
  40db17:	cmp    BYTE PTR [r8+rdi*1+0x2],r14b
  40db1c:	jne    40db59 <__swc_fn_23cea7fa_000178_3a24e5ea+0x479>
  40db1e:	mov    r14b,BYTE PTR [r12+rdi*1+0x3]
  40db23:	cmp    BYTE PTR [r8+rdi*1+0x3],r14b
  40db28:	jne    40db5f <__swc_fn_23cea7fa_000178_3a24e5ea+0x47f>
  40db2a:	lea    rdi,[rdi+0x4]
  40db2e:	jmp    40daf0 <__swc_fn_23cea7fa_000178_3a24e5ea+0x410>
  40db30:	cmp    rdi,r9
  40db33:	jge    40db63 <__swc_fn_23cea7fa_000178_3a24e5ea+0x483>
  40db35:	cs nop WORD PTR [rax+rax*1+0x0]
  40db3f:	nop
  40db40:	mov    r14b,BYTE PTR [r12+rdi*1]
  40db44:	cmp    BYTE PTR [r8+rdi*1],r14b
  40db48:	jne    40db63 <__swc_fn_23cea7fa_000178_3a24e5ea+0x483>
  40db4a:	inc    rdi
  40db4d:	cmp    rdi,r9
  40db50:	jl     40db40 <__swc_fn_23cea7fa_000178_3a24e5ea+0x460>
  40db52:	jmp    40db63 <__swc_fn_23cea7fa_000178_3a24e5ea+0x483>
  40db54:	inc    rdi
  40db57:	jmp    40db63 <__swc_fn_23cea7fa_000178_3a24e5ea+0x483>
  40db59:	lea    rdi,[rdi+0x2]
  40db5d:	jmp    40db63 <__swc_fn_23cea7fa_000178_3a24e5ea+0x483>
  40db5f:	lea    rdi,[rdi+0x3]
  40db63:	cmp    rdi,rcx
  40db66:	jle    40db73 <__swc_fn_23cea7fa_000178_3a24e5ea+0x493>
  40db68:	mov    rcx,rdi
  40db6b:	mov    rdx,rsi
  40db6e:	cmp    rdi,r9
  40db71:	je     40db8d <__swc_fn_23cea7fa_000178_3a24e5ea+0x4ad>
  40db73:	and    r10d,0x7fff
  40db7a:	mov    r8,QWORD PTR [r15+r10*8]
  40db7e:	mov    r10,r8
  40db81:	inc    r11
  40db84:	test   r8,r8
  40db87:	jge    40dab0 <__swc_fn_23cea7fa_000178_3a24e5ea+0x3d0>
  40db8d:	mov    r8d,eax
  40db90:	and    r8d,0x7fff
  40db97:	vmovq  r14,xmm3
  40db9c:	vmovq  r9,xmm1
  40dba1:	mov    r10,QWORD PTR [r14+r9*8]
  40dba5:	mov    QWORD PTR [r15+r8*8],r10
  40dba9:	mov    QWORD PTR [r14+r9*8],rax
  40dbad:	cmp    rcx,0x4
  40dbb1:	jge    40dbc2 <__swc_fn_23cea7fa_000178_3a24e5ea+0x4e2>
  40dbb3:	vmovq  rsi,xmm2
  40dbb8:	vmovq  rdi,xmm0
  40dbbd:	jmp    40dc82 <__swc_fn_23cea7fa_000178_3a24e5ea+0x5a2>
  40dbc2:	vmovq  rsi,xmm2
  40dbc7:	vmovq  rdi,xmm0
  40dbcc:	mov    BYTE PTR [rsi+rdi*1],0x1
  40dbd0:	lea    r8,[rcx-0x4]
  40dbd4:	mov    BYTE PTR [rsi+rdi*1+0x1],r8b
  40dbd9:	dec    rdx
  40dbdc:	mov    BYTE PTR [rsi+rdi*1+0x2],dl
  40dbe0:	lea    r8,[rdx+0xff]
  40dbe7:	test   rdx,rdx
  40dbea:	cmovge r8,rdx
  40dbee:	sar    r8,0x8
  40dbf2:	mov    BYTE PTR [rsi+rdi*1+0x3],r8b
  40dbf7:	lea    rdi,[rdi+0x4]
  40dbfb:	lea    rdx,[rax+0x1]
  40dbff:	lea    r8,[rax+rcx*1]
  40dc03:	mov    r9,rdx
  40dc06:	cmp    rdx,r8
  40dc09:	jge    40dc75 <__swc_fn_23cea7fa_000178_3a24e5ea+0x595>
  40dc0b:	nop    DWORD PTR [rax+rax*1+0x0]
  40dc10:	lea    rdx,[r9+0x4]
  40dc14:	cmp    rdx,0x100000
  40dc1b:	jg     40dc6c <__swc_fn_23cea7fa_000178_3a24e5ea+0x58c>
  40dc1d:	movzx  edx,BYTE PTR [r13+r9*1+0x0]
  40dc23:	imul   rdx,rdx,0x8c61
  40dc2a:	movzx  r10d,BYTE PTR [r13+r9*1+0x1]
  40dc30:	imul   r10,r10,0x441
  40dc37:	add    rdx,r10
  40dc3a:	movzx  r10d,BYTE PTR [r13+r9*1+0x2]
  40dc40:	movzx  r12d,BYTE PTR [r13+r9*1+0x3]
  40dc46:	add    r12,r10
  40dc49:	shl    r10,0x5
  40dc4d:	add    r10,r12
  40dc50:	add    rdx,r10
  40dc53:	movzx  edx,dx
  40dc56:	mov    r10d,r9d
  40dc59:	and    r10d,0x7fff
  40dc60:	mov    r11,QWORD PTR [r14+rdx*8]
  40dc64:	mov    QWORD PTR [r15+r10*8],r11
  40dc68:	mov    QWORD PTR [r14+rdx*8],r9
  40dc6c:	add    r9,0x1
  40dc70:	cmp    r9,r8
  40dc73:	jl     40dc10 <__swc_fn_23cea7fa_000178_3a24e5ea+0x530>
  40dc75:	add    rax,rcx
  40dc78:	vmovq  xmm0,rdi
  40dc7d:	jmp    40da10 <__swc_fn_23cea7fa_000178_3a24e5ea+0x330>
  40dc82:	mov    BYTE PTR [rsi+rdi*1],0x0
  40dc86:	mov    cl,BYTE PTR [r13+rax*1+0x0]
  40dc8b:	mov    BYTE PTR [rsi+rdi*1+0x1],cl
  40dc8f:	lea    rdi,[rdi+0x2]
  40dc93:	add    rax,0x1
  40dc97:	vmovq  xmm0,rdi
  40dc9c:	jmp    40da10 <__swc_fn_23cea7fa_000178_3a24e5ea+0x330>
  40dca1:	cmp    rax,0x100000
  40dca8:	jge    40dcce <__swc_fn_23cea7fa_000178_3a24e5ea+0x5ee>
  40dcaa:	nop    WORD PTR [rax+rax*1+0x0]
  40dcb0:	mov    BYTE PTR [rsi+rdi*1],0x0
  40dcb4:	mov    cl,BYTE PTR [r13+rax*1+0x0]
  40dcb9:	mov    BYTE PTR [rsi+rdi*1+0x1],cl
  40dcbd:	lea    rdi,[rdi+0x2]
  40dcc1:	add    rax,0x1
  40dcc5:	cmp    rax,0x100000
  40dccc:	jl     40dcb0 <__swc_fn_23cea7fa_000178_3a24e5ea+0x5d0>
  40dcce:	mov    ecx,0x100000
  40dcd3:	sub    rsp,0x8
  40dcd7:	call   40d630 <__swc_fn_23cea7fa_000175_2744b483>
  40dcdc:	add    rsp,0x8
  40dce0:	mov    r12,rax
  40dce3:	xor    eax,eax
  40dce5:	xor    ecx,ecx
  40dce7:	nop    WORD PTR [rax+rax*1+0x0]
  40dcf0:	cmp    rcx,rdi
  40dcf3:	jge    40dd5d <__swc_fn_23cea7fa_000178_3a24e5ea+0x67d>
  40dcf9:	cmp    BYTE PTR [rsi+rcx*1],0x0
  40dcfd:	jne    40dd10 <__swc_fn_23cea7fa_000178_3a24e5ea+0x630>
  40dcff:	mov    dl,BYTE PTR [rsi+rcx*1+0x1]
  40dd03:	mov    BYTE PTR [r12+rax*1],dl
  40dd07:	inc    rax
  40dd0a:	lea    rcx,[rcx+0x2]
  40dd0e:	jmp    40dcf0 <__swc_fn_23cea7fa_000178_3a24e5ea+0x610>
  40dd10:	movzx  edx,BYTE PTR [rsi+rcx*1+0x1]
  40dd15:	lea    rdx,[rdx+0x4]
  40dd19:	movzx  r8d,BYTE PTR [rsi+rcx*1+0x2]
  40dd1f:	movzx  r9d,BYTE PTR [rsi+rcx*1+0x3]
  40dd25:	shl    r9,0x8
  40dd29:	lea    r8,[r8+r9*1+0x1]
  40dd2e:	xor    r9d,r9d
  40dd31:	test   rdx,rdx
  40dd34:	jle    40dd54 <__swc_fn_23cea7fa_000178_3a24e5ea+0x674>
  40dd36:	mov    r10,r12
  40dd39:	sub    r10,r8
  40dd3c:	nop    DWORD PTR [rax+0x0]
  40dd40:	mov    r8b,BYTE PTR [r10+rax*1]
  40dd44:	mov    BYTE PTR [r12+rax*1],r8b
  40dd48:	inc    rax
  40dd4b:	add    r9,0x1
  40dd4f:	cmp    r9,rdx
  40dd52:	jl     40dd40 <__swc_fn_23cea7fa_000178_3a24e5ea+0x660>
  40dd54:	lea    rcx,[rcx+0x4]
  40dd58:	jmp    40dcf0 <__swc_fn_23cea7fa_000178_3a24e5ea+0x610>
  40dd5d:	cmp    rax,0x100000
  40dd64:	sete   al
  40dd67:	xor    ecx,ecx
  40dd69:	test   al,al
  40dd6b:	je     40dd8d <__swc_fn_23cea7fa_000178_3a24e5ea+0x6ad>
  40dd6d:	nop    DWORD PTR [rax]
  40dd70:	cmp    rcx,0x100000
  40dd77:	jge    40dd8d <__swc_fn_23cea7fa_000178_3a24e5ea+0x6ad>
  40dd79:	mov    dl,BYTE PTR [r13+rcx*1+0x0]
  40dd7e:	cmp    BYTE PTR [r12+rcx*1],dl
  40dd82:	je     40dd86 <__swc_fn_23cea7fa_000178_3a24e5ea+0x6a6>
  40dd84:	xor    eax,eax
  40dd86:	inc    rcx
  40dd89:	test   al,al
  40dd8b:	jne    40dd70 <__swc_fn_23cea7fa_000178_3a24e5ea+0x690>
  40dd8d:	xor    ecx,ecx
  40dd8f:	xor    edx,edx
  40dd91:	test   rdi,rdi
  40dd94:	jle    40ddd0 <__swc_fn_23cea7fa_000178_3a24e5ea+0x6f0>
  40dd96:	cs nop WORD PTR [rax+rax*1+0x0]
  40dda0:	imul   rcx,rcx,0x1f
  40dda4:	movzx  r8d,BYTE PTR [rsi+rdx*1]
  40dda9:	add    rcx,r8
  40ddac:	mov    r8,rcx
  40ddaf:	imul   rcx,rcx,0x218de8b
  40ddb6:	shr    rcx,0x2d
  40ddba:	imul   rcx,rcx,0xf4243
  40ddc1:	sub    r8,rcx
  40ddc4:	mov    rcx,r8
  40ddc7:	add    rdx,0x1
  40ddcb:	cmp    rdx,rdi
  40ddce:	jl     40dda0 <__swc_fn_23cea7fa_000178_3a24e5ea+0x6c0>
  40ddd0:	imul   rdi,rdi,0xf4243
  40ddd7:	add    rdi,rcx
  40ddda:	test   al,al
  40dddc:	mov    eax,0x0
  40dde1:	cmove  rdi,rax
  40dde5:	sub    rsp,0x8
  40dde9:	call   40a350 <__swc_fn_23cea7fa_000177_1ca87929>
  40ddee:	add    rsp,0x8
  40ddf2:	vsubsd xmm0,xmm0,xmm6
  40ddf6:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x5bca]        # 4139c8 <__swc_rdata_base_23cea7fa+0x8b8>
  40ddfe:	lea    rax,[rip+0x5563]        # 413368 <__swc_rdata_base_23cea7fa+0x258>
  40de05:	sub    rsp,0x90
  40de0c:	mov    rcx,rsp
  40de0f:	vmovups xmm1,XMMWORD PTR [rip+0x5b91]        # 4139a8 <__swc_rdata_base_23cea7fa+0x898>
  40de17:	vmovups XMMWORD PTR [rcx],xmm1
  40de1b:	mov    QWORD PTR [rcx+0x30],rsp
  40de1f:	lea    rdx,[rip+0x54ea]        # 413310 <__swc_rdata_base_23cea7fa+0x200>
  40de26:	mov    QWORD PTR [rcx+0x38],rdx
  40de2a:	mov    QWORD PTR [rcx+0x10],rdi
  40de2e:	lea    r8,[rsp+0x10]
  40de33:	mov    QWORD PTR [rcx+0x40],r8
  40de37:	lea    r8,[rip+0x5ada]        # 413918 <__swc_rdata_base_23cea7fa+0x808>
  40de3e:	mov    QWORD PTR [rcx+0x48],r8
  40de42:	vmovups xmm1,XMMWORD PTR [rip+0x5b6e]        # 4139b8 <__swc_rdata_base_23cea7fa+0x8a8>
  40de4a:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40de4f:	lea    r8,[rsp+0x18]
  40de54:	mov    QWORD PTR [rcx+0x50],r8
  40de58:	mov    QWORD PTR [rcx+0x58],rdx
  40de5c:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40de61:	lea    r8,[rcx+0x28]
  40de65:	mov    QWORD PTR [rcx+0x60],r8
  40de69:	lea    r8,[rip+0x5af0]        # 413960 <__swc_rdata_base_23cea7fa+0x850>
  40de70:	mov    QWORD PTR [rcx+0x68],r8
  40de74:	mov    QWORD PTR [rcx+0x70],rax
  40de78:	mov    QWORD PTR [rcx+0x78],rdx
  40de7c:	lea    rax,[rcx+0x30]
  40de80:	mov    QWORD PTR [rcx+0x80],rax
  40de87:	mov    QWORD PTR [rcx+0x88],0x5
  40de92:	lea    rcx,[rcx+0x80]
  40de99:	sub    rsp,0x8
  40de9d:	call   410a60 <__swc_fn_23cea7fa_000146_d2097256>
  40dea2:	add    rsp,0x8
  40dea6:	add    rsp,0x90
  40dead:	mov    rcx,r12
  40deb0:	sub    rsp,0x8
  40deb4:	call   412140 <__swc_fn_23cea7fa_000176_5d3d19bd>
  40deb9:	add    rsp,0x8
  40debd:	mov    rcx,rsi
  40dec0:	sub    rsp,0x8
  40dec4:	call   412140 <__swc_fn_23cea7fa_000176_5d3d19bd>
  40dec9:	add    rsp,0x8
  40decd:	mov    rcx,r15
  40ded0:	sub    rsp,0x8
  40ded4:	call   412140 <__swc_fn_23cea7fa_000176_5d3d19bd>
  40ded9:	add    rsp,0x8
  40dedd:	mov    rcx,r14
  40dee0:	sub    rsp,0x8
  40dee4:	call   412140 <__swc_fn_23cea7fa_000176_5d3d19bd>
  40dee9:	add    rsp,0x8
  40deed:	mov    rcx,r13
  40def0:	sub    rsp,0x8
  40def4:	call   412140 <__swc_fn_23cea7fa_000176_5d3d19bd>
  40def9:	add    rsp,0x8
  40defd:	mov    r12,QWORD PTR [rsp+0x1e0]
  40df05:	mov    rcx,r12
  40df08:	sub    rsp,0x8
  40df0c:	call   412140 <__swc_fn_23cea7fa_000176_5d3d19bd>
  40df11:	add    rsp,0x8
  40df15:	mov    rdi,QWORD PTR [rsp+0x1d8]
  40df1d:	mov    rcx,rdi
  40df20:	sub    rsp,0x8
  40df24:	call   412140 <__swc_fn_23cea7fa_000176_5d3d19bd>
  40df29:	add    rsp,0x8
  40df2d:	mov    rsi,QWORD PTR [rsp+0x1d0]
  40df35:	mov    rcx,rsi
  40df38:	sub    rsp,0x8
  40df3c:	call   412140 <__swc_fn_23cea7fa_000176_5d3d19bd>
  40df41:	add    rsp,0x218
  40df48:	vmovups xmm6,XMMWORD PTR [rsp]
  40df4d:	add    rsp,0x18
  40df51:	pop    r14
  40df53:	pop    r15
  40df55:	pop    r13
  40df57:	pop    r12
  40df59:	pop    rdi
  40df5a:	pop    rsi
  40df5b:	pop    rbp
  40df5c:	ret
  40df5d:	add    BYTE PTR [rax],al
	...

000000000040df60 <__swc_fn_23cea7fa_000002_102336c4>:
  40df60:	sub    rsp,0x8
  40df64:	call   40c620 <__swc_fn_23cea7fa_000109_9f5af8ae>
  40df69:	mov    rcx,rax
  40df6c:	test   rax,rax
  40df6f:	je     40df96 <__swc_fn_23cea7fa_000002_102336c4+0x36>
  40df71:	lea    rdx,[rip+0x160c8]        # 424040 <__swc_bss_base_23cea7fa>
  40df78:	mov    r8,QWORD PTR [rip+0x160c1]        # 424040 <__swc_bss_base_23cea7fa>
  40df7f:	nop
  40df80:	lea    r9,[r8+0x1]
  40df84:	mov    rax,r8
  40df87:	lock cmpxchg QWORD PTR [rdx],r9
  40df8c:	cmp    rax,r8
  40df8f:	je     40df96 <__swc_fn_23cea7fa_000002_102336c4+0x36>
  40df91:	mov    r8,rax
  40df94:	jmp    40df80 <__swc_fn_23cea7fa_000002_102336c4+0x20>
  40df96:	mov    rax,rcx
  40df99:	add    rsp,0x8
  40df9d:	ret
	...

000000000040dfa0 <__swc_fn_23cea7fa_000005_6a556171>:
  40dfa0:	mov    r8d,edx
  40dfa3:	xor    eax,eax
  40dfa5:	tzcnt  eax,edx
  40dfa9:	shrx   r9d,edx,eax
  40dfae:	mov    DWORD PTR [rcx+0x2c],edx
  40dfb1:	xor    eax,eax
  40dfb3:	tzcnt  eax,edx
  40dfb7:	mov    BYTE PTR [rcx+0x38],al
  40dfba:	mov    eax,0xffffffff
  40dfbf:	xor    edx,edx
  40dfc1:	div    r8d
  40dfc4:	mov    DWORD PTR [rcx+0x34],eax
  40dfc7:	mov    eax,r9d
  40dfca:	mov    edx,r9d
  40dfcd:	imul   edx,r9d
  40dfd1:	mov    r8d,0x2
  40dfd7:	sub    r8d,edx
  40dfda:	imul   eax,r8d
  40dfde:	mov    edx,r9d
  40dfe1:	imul   edx,eax
  40dfe4:	mov    r8d,0x2
  40dfea:	sub    r8d,edx
  40dfed:	imul   eax,r8d
  40dff1:	mov    edx,r9d
  40dff4:	imul   edx,eax
  40dff7:	mov    r8d,0x2
  40dffd:	sub    r8d,edx
  40e000:	imul   eax,r8d
  40e004:	mov    edx,r9d
  40e007:	imul   edx,eax
  40e00a:	mov    r8d,0x2
  40e010:	sub    r8d,edx
  40e013:	imul   eax,r8d
  40e017:	imul   r9d,eax
  40e01b:	mov    edx,0x2
  40e020:	sub    edx,r9d
  40e023:	imul   eax,edx
  40e026:	mov    DWORD PTR [rcx+0x30],eax
  40e029:	ret
  40e02a:	add    BYTE PTR [rax],al
  40e02c:	add    BYTE PTR [rax],al
	...

000000000040e030 <__swc_fn_23cea7fa_000008_b2f73e0d>:
  40e030:	xor    eax,eax
  40e032:	mov    DWORD PTR [rcx+0x68],eax
  40e035:	ret
	...

000000000040e040 <__swc_fn_23cea7fa_000011_71c91685>:
  40e040:	mov    eax,DWORD PTR [rcx+0x28]
  40e043:	shlx   eax,edx,eax
  40e048:	shl    rax,0x10
  40e04c:	lea    rdx,[rcx+rax*1]
  40e050:	lea    rax,[rcx+0x3000]
  40e057:	cmp    rdx,rax
  40e05a:	cmovae rax,rdx
  40e05e:	ret
	...

000000000040e060 <__swc_fn_23cea7fa_000014_be17798c>:
  40e060:	push   rsi
  40e061:	push   rdi
  40e062:	push   r12
  40e064:	push   r13
  40e066:	push   r14
  40e068:	mov    rsi,rdx
  40e06b:	mov    rdi,rcx
  40e06e:	rex mov dl,BYTE PTR [rsi+0x3a]
  40e072:	mov    ecx,DWORD PTR [rdi+0x28]
  40e075:	shr    dl,cl
  40e077:	mov    r12d,0x1
  40e07d:	mov    ecx,edx
  40e07f:	shl    r12,cl
  40e082:	mov    r13d,DWORD PTR [rsi+0x3c]
  40e086:	rex mov BYTE PTR [rsi+0x3b],0x0
  40e08b:	mov    QWORD PTR [rsi+0x40],0x0
  40e093:	mov    QWORD PTR [rsi],0x0
  40e09a:	mov    rax,QWORD PTR [rsi+0x10]
  40e09e:	mov    QWORD PTR [rsi+0x20],rax
  40e0a2:	lea    r14,[rip+0x15f9f]        # 424048 <__swc_bss_base_23cea7fa+0x8>
  40e0a9:	mov    rax,QWORD PTR [r14]
  40e0ac:	shr    rax,0x2
  40e0b0:	mov    rcx,rax
  40e0b3:	cmp    rax,0x800000
  40e0ba:	mov    eax,0x800000
  40e0bf:	cmovb  rcx,rax
  40e0c3:	lea    r8,[rip+0x15f8e]        # 424058 <__swc_bss_base_23cea7fa+0x18>
  40e0ca:	mov    rax,QWORD PTR [r8]
  40e0cd:	mov    r9,rax
  40e0d0:	lea    r10,[r9+r13*1]
  40e0d4:	cmp    r10,rcx
  40e0d7:	ja     40e0fb <__swc_fn_23cea7fa_000014_be17798c+0x9b>
  40e0d9:	mov    rax,r9
  40e0dc:	lock cmpxchg QWORD PTR [r8],r10
  40e0e1:	cmp    rax,r9
  40e0e4:	je     40e0eb <__swc_fn_23cea7fa_000014_be17798c+0x8b>
  40e0e6:	mov    r9,rax
  40e0e9:	jmp    40e0d0 <__swc_fn_23cea7fa_000014_be17798c+0x70>
  40e0eb:	mov    rcx,rdi
  40e0ee:	mov    rdx,r12
  40e0f1:	call   40a750 <__swc_fn_23cea7fa_000016_a0b588d0>
  40e0f6:	jmp    40e17d <__swc_fn_23cea7fa_000014_be17798c+0x11d>
  40e0fb:	mov    rcx,rdi
  40e0fe:	movzx  edx,dl
  40e101:	call   40e040 <__swc_fn_23cea7fa_000011_71c91685>
  40e106:	test   r13,r13
  40e109:	je     40e176 <__swc_fn_23cea7fa_000014_be17798c+0x116>
  40e10f:	mov    rcx,rax
  40e112:	mov    rdx,r13
  40e115:	call   40c7a0 <__swc_fn_23cea7fa_000112_2f7f9346>
  40e11a:	mov    rcx,QWORD PTR [rip+0x15f27]        # 424048 <__swc_bss_base_23cea7fa+0x8>
  40e121:	cs nop WORD PTR [rax+rax*1+0x0]
  40e12b:	nop    DWORD PTR [rax+rax*1+0x0]
  40e130:	mov    rdx,rcx
  40e133:	sub    rdx,r13
  40e136:	mov    rax,rcx
  40e139:	lock cmpxchg QWORD PTR [r14],rdx
  40e13e:	cmp    rax,rcx
  40e141:	je     40e148 <__swc_fn_23cea7fa_000014_be17798c+0xe8>
  40e143:	mov    rcx,rax
  40e146:	jmp    40e130 <__swc_fn_23cea7fa_000014_be17798c+0xd0>
  40e148:	lea    rcx,[rip+0x15f11]        # 424060 <__swc_bss_base_23cea7fa+0x20>
  40e14f:	mov    rdx,QWORD PTR [rip+0x15f0a]        # 424060 <__swc_bss_base_23cea7fa+0x20>
  40e156:	cs nop WORD PTR [rax+rax*1+0x0]
  40e160:	lea    r8,[rdx+0x1]
  40e164:	mov    rax,rdx
  40e167:	lock cmpxchg QWORD PTR [rcx],r8
  40e16c:	cmp    rax,rdx
  40e16f:	je     40e176 <__swc_fn_23cea7fa_000014_be17798c+0x116>
  40e171:	mov    rdx,rax
  40e174:	jmp    40e160 <__swc_fn_23cea7fa_000014_be17798c+0x100>
  40e176:	mov    DWORD PTR [rsi+0x3c],0x0
  40e17d:	mov    rcx,rdi
  40e180:	mov    rdx,r12
  40e183:	call   407600 <__swc_fn_23cea7fa_000018_77ece227>
  40e188:	pop    r14
  40e18a:	pop    r13
  40e18c:	pop    r12
  40e18e:	pop    rdi
  40e18f:	pop    rsi
  40e190:	ret
	...

000000000040e1a0 <__swc_fn_23cea7fa_000017_f003fc47>:
  40e1a0:	mov    r8,QWORD PTR [rcx+0x48]
  40e1a4:	test   r8,rdx
  40e1a7:	je     40e1d8 <__swc_fn_23cea7fa_000017_f003fc47+0x38>
  40e1a9:	nop    DWORD PTR [rax+0x0]
  40e1b0:	mov    rax,rdx
  40e1b3:	not    rax
  40e1b6:	mov    r9,r8
  40e1b9:	and    r9,rax
  40e1bc:	mov    rax,r8
  40e1bf:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40e1c5:	cmp    rax,r8
  40e1c8:	jne    40e1d0 <__swc_fn_23cea7fa_000017_f003fc47+0x30>
  40e1ca:	mov    eax,0x1
  40e1cf:	ret
  40e1d0:	mov    r8,rax
  40e1d3:	test   rax,rdx
  40e1d6:	jne    40e1b0 <__swc_fn_23cea7fa_000017_f003fc47+0x10>
  40e1d8:	xor    eax,eax
  40e1da:	ret
  40e1db:	add    BYTE PTR [rax],al
  40e1dd:	add    BYTE PTR [rax],al
	...

000000000040e1e0 <__swc_fn_23cea7fa_000020_4285d9c5>:
  40e1e0:	push   rsi
  40e1e1:	push   rdi
  40e1e2:	push   r12
  40e1e4:	push   r13
  40e1e6:	sub    rsp,0x8
  40e1ea:	mov    rsi,rdx
  40e1ed:	mov    rdi,rcx
  40e1f0:	lea    r12,[rip+0x15ff9]        # 4241f0 <__swc_bss_base_23cea7fa+0x1b0>
  40e1f7:	mov    rcx,r12
  40e1fa:	call   4098a0 <__swc_fn_23cea7fa_000135_db32cc57>
  40e1ff:	xor    eax,eax
  40e201:	mov    rcx,QWORD PTR [rip+0x15ff0]        # 4241f8 <__swc_bss_base_23cea7fa+0x1b8>
  40e208:	mov    r13,rcx
  40e20b:	test   r13,r13
  40e20e:	je     40e25b <__swc_fn_23cea7fa_000020_4285d9c5+0x7b>
  40e210:	mov    rcx,QWORD PTR [r13+0x10]
  40e214:	cmp    DWORD PTR [r13+0x28],esi
  40e218:	jne    40e250 <__swc_fn_23cea7fa_000020_4285d9c5+0x70>
  40e21a:	test   rax,rax
  40e21d:	jne    40e228 <__swc_fn_23cea7fa_000020_4285d9c5+0x48>
  40e21f:	mov    QWORD PTR [rip+0x15fd2],rcx        # 4241f8 <__swc_bss_base_23cea7fa+0x1b8>
  40e226:	jmp    40e22c <__swc_fn_23cea7fa_000020_4285d9c5+0x4c>
  40e228:	mov    QWORD PTR [rax+0x10],rcx
  40e22c:	vxorps xmm0,xmm0,xmm0
  40e230:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40e236:	mov    QWORD PTR [r13+0x8],rdi
  40e23a:	mov    rcx,r12
  40e23d:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  40e242:	mov    rax,r13
  40e245:	add    rsp,0x8
  40e249:	pop    r13
  40e24b:	pop    r12
  40e24d:	pop    rdi
  40e24e:	pop    rsi
  40e24f:	ret
  40e250:	mov    rax,r13
  40e253:	mov    r13,rcx
  40e256:	test   rcx,rcx
  40e259:	jne    40e210 <__swc_fn_23cea7fa_000020_4285d9c5+0x30>
  40e25b:	mov    ecx,esi
  40e25d:	call   40a780 <__swc_fn_23cea7fa_000019_447bb610>
  40e262:	mov    rsi,rax
  40e265:	test   rax,rax
  40e268:	jne    40e27f <__swc_fn_23cea7fa_000020_4285d9c5+0x9f>
  40e26a:	mov    rcx,r12
  40e26d:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  40e272:	xor    eax,eax
  40e274:	add    rsp,0x8
  40e278:	pop    r13
  40e27a:	pop    r12
  40e27c:	pop    rdi
  40e27d:	pop    rsi
  40e27e:	ret
  40e27f:	mov    QWORD PTR [rsi+0x8],rdi
  40e283:	mov    rcx,r12
  40e286:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  40e28b:	mov    rax,rsi
  40e28e:	add    rsp,0x8
  40e292:	pop    r13
  40e294:	pop    r12
  40e296:	pop    rdi
  40e297:	pop    rsi
  40e298:	ret
  40e299:	add    BYTE PTR [rax],al
  40e29b:	add    BYTE PTR [rax],al
  40e29d:	add    BYTE PTR [rax],al
	...

000000000040e2a0 <__swc_fn_23cea7fa_000023_e876734d>:
  40e2a0:	vxorps xmm0,xmm0,xmm0
  40e2a4:	xor    eax,eax
  40e2a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40e2b0:	cs nop WORD PTR [rax+rax*1+0x0]
  40e2ba:	nop    WORD PTR [rax+rax*1+0x0]
  40e2c0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40e2c5:	add    rax,0x10
  40e2c9:	cmp    rax,0x2b00
  40e2d0:	jne    40e2c0 <__swc_fn_23cea7fa_000023_e876734d+0x20>
  40e2d2:	ret
	...

000000000040e2e0 <__swc_fn_23cea7fa_000026_e876734d>:
  40e2e0:	vxorps xmm0,xmm0,xmm0
  40e2e4:	vmovups XMMWORD PTR [rcx],xmm0
  40e2e8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e2ed:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e2f2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e2f7:	ret
	...

000000000040e300 <__swc_fn_23cea7fa_000029_e876734d>:
  40e300:	vxorps xmm0,xmm0,xmm0
  40e304:	vmovups XMMWORD PTR [rcx],xmm0
  40e308:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e30d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e312:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e317:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40e31c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40e321:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40e326:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40e32b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40e333:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40e33b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40e343:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40e34b:	mov    QWORD PTR [rcx+0xc0],0x0
  40e356:	ret
	...

000000000040e360 <__swc_fn_23cea7fa_000032_f1940e30>:
  40e360:	push   rsi
  40e361:	push   rdi
  40e362:	sub    rsp,0x8
  40e366:	mov    rsi,rcx
  40e369:	lea    rdi,[rip+0x13c90]        # 422000 <__swc_data_base_23cea7fa>
  40e370:	mov    rax,QWORD PTR [rdi]
  40e373:	cmp    rax,0xffffffffffffffff
  40e377:	je     40e37e <__swc_fn_23cea7fa_000032_f1940e30+0x1e>
  40e379:	mov    rdi,rax
  40e37c:	jmp    40e3ab <__swc_fn_23cea7fa_000032_f1940e30+0x4b>
  40e37e:	call   409580 <__swc_fn_23cea7fa_000123_e4107ade>
  40e383:	mov    rcx,rax
  40e386:	cmp    rax,0xffffffffffffffff
  40e38a:	je     40e3bc <__swc_fn_23cea7fa_000032_f1940e30+0x5c>
  40e38c:	mov    rax,0xffffffffffffffff
  40e393:	lock cmpxchg QWORD PTR [rdi],rcx
  40e398:	cmp    rax,0xffffffffffffffff
  40e39c:	je     40e3a8 <__swc_fn_23cea7fa_000032_f1940e30+0x48>
  40e39e:	mov    rdi,rax
  40e3a1:	call   40cb70 <__swc_fn_23cea7fa_000124_37eaf452>
  40e3a6:	jmp    40e3ab <__swc_fn_23cea7fa_000032_f1940e30+0x4b>
  40e3a8:	mov    rdi,rcx
  40e3ab:	cmp    rdi,0xffffffffffffffff
  40e3af:	je     40e3bc <__swc_fn_23cea7fa_000032_f1940e30+0x5c>
  40e3b1:	mov    rcx,rdi
  40e3b4:	mov    rdx,rsi
  40e3b7:	call   410470 <__swc_fn_23cea7fa_000125_7a81492f>
  40e3bc:	add    rsp,0x8
  40e3c0:	pop    rdi
  40e3c1:	pop    rsi
  40e3c2:	ret
	...

000000000040e3d0 <__swc_fn_23cea7fa_000035_ab2e8c35>:
  40e3d0:	sub    rsp,0x38
  40e3d4:	mov    rax,rdx
  40e3d7:	test   dl,dl
  40e3d9:	jne    40e3f1 <__swc_fn_23cea7fa_000035_ab2e8c35+0x21>
  40e3db:	mov    rax,r8
  40e3de:	test   r8b,r8b
  40e3e1:	cmove  eax,r9d
  40e3e5:	test   al,al
  40e3e7:	cmove  eax,r10d
  40e3eb:	test   al,al
  40e3ed:	cmove  eax,r11d
  40e3f1:	test   al,al
  40e3f3:	jne    40e3fa <__swc_fn_23cea7fa_000035_ab2e8c35+0x2a>
  40e3f5:	add    rsp,0x38
  40e3f9:	ret
  40e3fa:	lea    rcx,[rip+0x4d0f]        # 413110 <__swc_rdata_base_23cea7fa>
  40e401:	vmovups xmm0,XMMWORD PTR [rip+0x4d17]        # 413120 <__swc_rdata_base_23cea7fa+0x10>
  40e409:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e40f:	vmovups xmm0,XMMWORD PTR [rip+0x4d19]        # 413130 <__swc_rdata_base_23cea7fa+0x20>
  40e417:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e41d:	vmovups xmm0,XMMWORD PTR [rip+0x4d1b]        # 413140 <__swc_rdata_base_23cea7fa+0x30>
  40e425:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e42b:	lea    rdx,[rsp+0x8]
  40e430:	call   40c3a0 <__swc_fn_23cea7fa_000103_0d4cc079>
  40e435:	jmp    40e3f5 <__swc_fn_23cea7fa_000035_ab2e8c35+0x25>
	...

000000000040e440 <__swc_fn_23cea7fa_000038_292d55e5>:
  40e440:	sub    rsp,0x8
  40e444:	mov    eax,0x1000
  40e449:	test   eax,eax
  40e44b:	mov    r8d,0x8
  40e451:	cmove  eax,r8d
  40e455:	dec    rax
  40e458:	mov    r8,0xffffffffffffffff
  40e45f:	sub    r8,rax
  40e462:	cmp    rdx,r8
  40e465:	ja     40e475 <__swc_fn_23cea7fa_000038_292d55e5+0x35>
  40e467:	add    rdx,rax
  40e46a:	not    rax
  40e46d:	mov    r8,rdx
  40e470:	and    r8,rax
  40e473:	jne    40e47c <__swc_fn_23cea7fa_000038_292d55e5+0x3c>
  40e475:	xor    eax,eax
  40e477:	add    rsp,0x8
  40e47b:	ret
  40e47c:	mov    rdx,r8
  40e47f:	call   40aaa0 <__swc_fn_23cea7fa_000037_1e381f55>
  40e484:	add    rsp,0x8
  40e488:	ret
  40e489:	add    BYTE PTR [rax],al
  40e48b:	add    BYTE PTR [rax],al
  40e48d:	add    BYTE PTR [rax],al
	...

000000000040e490 <__swc_fn_23cea7fa_000041_41400651>:
  40e490:	push   rsi
  40e491:	push   rdi
  40e492:	sub    rsp,0x8
  40e496:	mov    rsi,rdx
  40e499:	mov    rdi,rcx
  40e49c:	test   rdx,rdx
  40e49f:	je     40e4bb <__swc_fn_23cea7fa_000041_41400651+0x2b>
  40e4a1:	xor    ecx,ecx
  40e4a3:	call   407720 <__swc_fn_23cea7fa_000033_d15eb4ea>
  40e4a8:	mov    rax,QWORD PTR [rsi]
  40e4ab:	test   rax,rax
  40e4ae:	je     40e4bb <__swc_fn_23cea7fa_000041_41400651+0x2b>
  40e4b0:	mov    rcx,rax
  40e4b3:	mov    rdx,rsi
  40e4b6:	call   407840 <__swc_fn_23cea7fa_000042_0573444d>
  40e4bb:	mov    rcx,rdi
  40e4be:	call   40ab00 <__swc_fn_23cea7fa_000040_8029566e>
  40e4c3:	mov    rsi,rax
  40e4c6:	test   rax,rax
  40e4c9:	jne    40e4d4 <__swc_fn_23cea7fa_000041_41400651+0x44>
  40e4cb:	xor    eax,eax
  40e4cd:	add    rsp,0x8
  40e4d1:	pop    rdi
  40e4d2:	pop    rsi
  40e4d3:	ret
  40e4d4:	mov    rcx,rsi
  40e4d7:	call   407720 <__swc_fn_23cea7fa_000033_d15eb4ea>
  40e4dc:	mov    rax,rsi
  40e4df:	add    rsp,0x8
  40e4e3:	pop    rdi
  40e4e4:	pop    rsi
  40e4e5:	ret
	...

000000000040e4f0 <__swc_fn_23cea7fa_000044_fe6bbfdb>:
  40e4f0:	movzx  eax,BYTE PTR [r8+0x39]
  40e4f5:	lea    rax,[rax+rax*4]
  40e4f9:	lea    rax,[rdx+rax*8+0x28]
  40e4fe:	mov    ecx,DWORD PTR [r8+0x6c]
  40e502:	test   ecx,ecx
  40e504:	je     40e53d <__swc_fn_23cea7fa_000044_fe6bbfdb+0x4d>
  40e506:	mov    rcx,QWORD PTR [r8+0x50]
  40e50a:	test   rcx,rcx
  40e50d:	je     40e519 <__swc_fn_23cea7fa_000044_fe6bbfdb+0x29>
  40e50f:	mov    rax,QWORD PTR [r8+0x48]
  40e513:	mov    QWORD PTR [rcx+0x48],rax
  40e517:	jmp    40e521 <__swc_fn_23cea7fa_000044_fe6bbfdb+0x31>
  40e519:	mov    rcx,QWORD PTR [r8+0x48]
  40e51d:	mov    QWORD PTR [rax+0x18],rcx
  40e521:	mov    rax,QWORD PTR [r8+0x48]
  40e525:	test   rax,rax
  40e528:	je     40e532 <__swc_fn_23cea7fa_000044_fe6bbfdb+0x42>
  40e52a:	mov    rcx,QWORD PTR [r8+0x50]
  40e52e:	mov    QWORD PTR [rax+0x50],rcx
  40e532:	vxorps xmm0,xmm0,xmm0
  40e536:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e53c:	ret
  40e53d:	mov    rcx,QWORD PTR [r8+0x50]
  40e541:	test   rcx,rcx
  40e544:	je     40e550 <__swc_fn_23cea7fa_000044_fe6bbfdb+0x60>
  40e546:	mov    rdx,QWORD PTR [r8+0x48]
  40e54a:	mov    QWORD PTR [rcx+0x48],rdx
  40e54e:	jmp    40e558 <__swc_fn_23cea7fa_000044_fe6bbfdb+0x68>
  40e550:	mov    rcx,QWORD PTR [r8+0x48]
  40e554:	mov    QWORD PTR [rax+0x8],rcx
  40e558:	mov    rcx,QWORD PTR [r8+0x48]
  40e55c:	test   rcx,rcx
  40e55f:	je     40e56b <__swc_fn_23cea7fa_000044_fe6bbfdb+0x7b>
  40e561:	mov    rdx,QWORD PTR [r8+0x50]
  40e565:	mov    QWORD PTR [rcx+0x50],rdx
  40e569:	jmp    40e573 <__swc_fn_23cea7fa_000044_fe6bbfdb+0x83>
  40e56b:	mov    rcx,QWORD PTR [r8+0x50]
  40e56f:	mov    QWORD PTR [rax+0x10],rcx
  40e573:	cmp    QWORD PTR [rax],r8
  40e576:	jne    40e57f <__swc_fn_23cea7fa_000044_fe6bbfdb+0x8f>
  40e578:	mov    QWORD PTR [rax],0x0
  40e57f:	vxorps xmm0,xmm0,xmm0
  40e583:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e589:	ret
  40e58a:	add    BYTE PTR [rax],al
  40e58c:	add    BYTE PTR [rax],al
	...

000000000040e590 <__swc_fn_23cea7fa_000047_e7fd8d42>:
  40e590:	sub    rsp,0x8
  40e594:	mov    r9,r8
  40e597:	mov    r10,rdx
  40e59a:	call   40e4f0 <__swc_fn_23cea7fa_000044_fe6bbfdb>
  40e59f:	mov    DWORD PTR [r9+0x6c],0x0
  40e5a7:	movzx  eax,BYTE PTR [r9+0x39]
  40e5ac:	lea    rax,[rax+rax*4]
  40e5b0:	lea    rax,[r10+rax*8+0x28]
  40e5b5:	mov    rcx,QWORD PTR [rax+0x10]
  40e5b9:	mov    QWORD PTR [r9+0x50],rcx
  40e5bd:	mov    QWORD PTR [r9+0x48],0x0
  40e5c5:	mov    rcx,QWORD PTR [rax+0x10]
  40e5c9:	test   rcx,rcx
  40e5cc:	je     40e5d4 <__swc_fn_23cea7fa_000047_e7fd8d42+0x44>
  40e5ce:	mov    QWORD PTR [rcx+0x48],r9
  40e5d2:	jmp    40e5d8 <__swc_fn_23cea7fa_000047_e7fd8d42+0x48>
  40e5d4:	mov    QWORD PTR [rax+0x8],r9
  40e5d8:	mov    QWORD PTR [rax+0x10],r9
  40e5dc:	add    rsp,0x8
  40e5e0:	ret
	...

000000000040e600 <__swc_fn_23cea7fa_000050_5e919db9>:
  40e600:	push   rsi
  40e601:	push   rdi
  40e602:	push   r12
  40e604:	push   r13
  40e606:	push   r14
  40e608:	push   r15
  40e60a:	sub    rsp,0x1f8
  40e611:	mov    esi,r8d
  40e614:	mov    QWORD PTR [rsp+0x1e8],rsi
  40e61c:	mov    rdi,rcx
  40e61f:	mov    r12,rdx
  40e622:	lea    r13,[rsi+rsi*4]
  40e626:	lea    r13,[rdx+r13*8+0x28]
  40e62b:	call   407ca0 <__swc_fn_23cea7fa_000048_8e68f77b>
  40e630:	add    DWORD PTR [r12+0x24],0x1
  40e636:	test   BYTE PTR [r12+0x24],0x3f
  40e63c:	jne    40e646 <__swc_fn_23cea7fa_000050_5e919db9+0x46>
  40e63e:	mov    rcx,rdi
  40e641:	call   40ac80 <__swc_fn_23cea7fa_000049_f6a485a2>
  40e646:	mov    rax,QWORD PTR [r13+0x8]
  40e64a:	mov    r14,rax
  40e64d:	nop    DWORD PTR [rax]
  40e650:	test   r14,r14
  40e653:	jne    40e662 <__swc_fn_23cea7fa_000050_5e919db9+0x62>
  40e655:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40e65d:	jmp    40e769 <__swc_fn_23cea7fa_000050_5e919db9+0x169>
  40e662:	mov    r15,QWORD PTR [r14+0x48]
  40e666:	mov    rcx,r14
  40e669:	call   4073f0 <__swc_fn_23cea7fa_000009_4c3ebf16>
  40e66e:	mov    rax,QWORD PTR [r14]
  40e671:	test   rax,rax
  40e674:	je     40e686 <__swc_fn_23cea7fa_000050_5e919db9+0x86>
  40e676:	mov    rcx,QWORD PTR [rax]
  40e679:	mov    QWORD PTR [r14],rcx
  40e67c:	add    DWORD PTR [r14+0x28],0x1
  40e681:	mov    rsi,rax
  40e684:	jmp    40e6a5 <__swc_fn_23cea7fa_000050_5e919db9+0xa5>
  40e686:	mov    rax,QWORD PTR [r14+0x18]
  40e68a:	cmp    QWORD PTR [r14+0x20],rax
  40e68e:	jae    40e6a3 <__swc_fn_23cea7fa_000050_5e919db9+0xa3>
  40e690:	mov    rsi,QWORD PTR [r14+0x20]
  40e694:	mov    eax,DWORD PTR [r14+0x2c]
  40e698:	add    QWORD PTR [r14+0x20],rax
  40e69c:	add    DWORD PTR [r14+0x28],0x1
  40e6a1:	jmp    40e6a5 <__swc_fn_23cea7fa_000050_5e919db9+0xa5>
  40e6a3:	xor    esi,esi
  40e6a5:	test   rsi,rsi
  40e6a8:	jne    40e6ed <__swc_fn_23cea7fa_000050_5e919db9+0xed>
  40e6aa:	mov    rcx,r14
  40e6ad:	call   407320 <__swc_fn_23cea7fa_000006_7b253ae1>
  40e6b2:	test   al,al
  40e6b4:	je     40e6ed <__swc_fn_23cea7fa_000050_5e919db9+0xed>
  40e6b6:	mov    rax,QWORD PTR [r14]
  40e6b9:	test   rax,rax
  40e6bc:	je     40e6cb <__swc_fn_23cea7fa_000050_5e919db9+0xcb>
  40e6be:	mov    rcx,QWORD PTR [rax]
  40e6c1:	mov    QWORD PTR [r14],rcx
  40e6c4:	add    DWORD PTR [r14+0x28],0x1
  40e6c9:	jmp    40e6ea <__swc_fn_23cea7fa_000050_5e919db9+0xea>
  40e6cb:	mov    rax,QWORD PTR [r14+0x18]
  40e6cf:	cmp    QWORD PTR [r14+0x20],rax
  40e6d3:	jae    40e6e8 <__swc_fn_23cea7fa_000050_5e919db9+0xe8>
  40e6d5:	mov    rax,QWORD PTR [r14+0x20]
  40e6d9:	mov    ecx,DWORD PTR [r14+0x2c]
  40e6dd:	add    QWORD PTR [r14+0x20],rcx
  40e6e1:	add    DWORD PTR [r14+0x28],0x1
  40e6e6:	jmp    40e6ea <__swc_fn_23cea7fa_000050_5e919db9+0xea>
  40e6e8:	xor    eax,eax
  40e6ea:	mov    rsi,rax
  40e6ed:	test   rsi,rsi
  40e6f0:	jne    40e743 <__swc_fn_23cea7fa_000050_5e919db9+0x143>
  40e6f2:	mov    rcx,rdi
  40e6f5:	mov    rdx,r12
  40e6f8:	mov    r8,r14
  40e6fb:	call   40abe0 <__swc_fn_23cea7fa_000046_b28a6ee7>
  40e700:	test   al,al
  40e702:	jne    40e743 <__swc_fn_23cea7fa_000050_5e919db9+0x143>
  40e704:	mov    rcx,r14
  40e707:	call   4073f0 <__swc_fn_23cea7fa_000009_4c3ebf16>
  40e70c:	mov    rax,QWORD PTR [r14]
  40e70f:	test   rax,rax
  40e712:	je     40e721 <__swc_fn_23cea7fa_000050_5e919db9+0x121>
  40e714:	mov    rcx,QWORD PTR [rax]
  40e717:	mov    QWORD PTR [r14],rcx
  40e71a:	add    DWORD PTR [r14+0x28],0x1
  40e71f:	jmp    40e740 <__swc_fn_23cea7fa_000050_5e919db9+0x140>
  40e721:	mov    rax,QWORD PTR [r14+0x18]
  40e725:	cmp    QWORD PTR [r14+0x20],rax
  40e729:	jae    40e73e <__swc_fn_23cea7fa_000050_5e919db9+0x13e>
  40e72b:	mov    rax,QWORD PTR [r14+0x20]
  40e72f:	mov    ecx,DWORD PTR [r14+0x2c]
  40e733:	add    QWORD PTR [r14+0x20],rcx
  40e737:	add    DWORD PTR [r14+0x28],0x1
  40e73c:	jmp    40e740 <__swc_fn_23cea7fa_000050_5e919db9+0x140>
  40e73e:	xor    eax,eax
  40e740:	mov    rsi,rax
  40e743:	test   rsi,rsi
  40e746:	je     40e761 <__swc_fn_23cea7fa_000050_5e919db9+0x161>
  40e748:	mov    QWORD PTR [r13+0x0],r14
  40e74c:	mov    rax,rsi
  40e74f:	add    rsp,0x1f8
  40e756:	pop    r15
  40e758:	pop    r14
  40e75a:	pop    r13
  40e75c:	pop    r12
  40e75e:	pop    rdi
  40e75f:	pop    rsi
  40e760:	ret
  40e761:	mov    r14,r15
  40e764:	jmp    40e650 <__swc_fn_23cea7fa_000050_5e919db9+0x50>
  40e769:	cs nop WORD PTR [rax+rax*1+0x0]
  40e773:	cs nop WORD PTR [rax+rax*1+0x0]
  40e77d:	nop    DWORD PTR [rax]
  40e780:	mov    rcx,rdi
  40e783:	mov    rdx,r12
  40e786:	mov    r8d,esi
  40e789:	call   4079e0 <__swc_fn_23cea7fa_000045_bb688d37>
  40e78e:	mov    r14,rax
  40e791:	test   rax,rax
  40e794:	jne    40e7aa <__swc_fn_23cea7fa_000050_5e919db9+0x1aa>
  40e796:	xor    eax,eax
  40e798:	add    rsp,0x1f8
  40e79f:	pop    r15
  40e7a1:	pop    r14
  40e7a3:	pop    r13
  40e7a5:	pop    r12
  40e7a7:	pop    rdi
  40e7a8:	pop    rsi
  40e7a9:	ret
  40e7aa:	mov    QWORD PTR [r13+0x0],r14
  40e7ae:	mov    rax,QWORD PTR [r14]
  40e7b1:	test   rax,rax
  40e7b4:	je     40e7c6 <__swc_fn_23cea7fa_000050_5e919db9+0x1c6>
  40e7b6:	mov    rcx,QWORD PTR [rax]
  40e7b9:	mov    QWORD PTR [r14],rcx
  40e7bc:	add    DWORD PTR [r14+0x28],0x1
  40e7c1:	mov    r15,rax
  40e7c4:	jmp    40e7e6 <__swc_fn_23cea7fa_000050_5e919db9+0x1e6>
  40e7c6:	mov    rax,QWORD PTR [r14+0x18]
  40e7ca:	cmp    QWORD PTR [r14+0x20],rax
  40e7ce:	jae    40e7e3 <__swc_fn_23cea7fa_000050_5e919db9+0x1e3>
  40e7d0:	mov    r15,QWORD PTR [r14+0x20]
  40e7d4:	mov    eax,DWORD PTR [r14+0x2c]
  40e7d8:	add    QWORD PTR [r14+0x20],rax
  40e7dc:	add    DWORD PTR [r14+0x28],0x1
  40e7e1:	jmp    40e7e6 <__swc_fn_23cea7fa_000050_5e919db9+0x1e6>
  40e7e3:	xor    r15d,r15d
  40e7e6:	test   r15,r15
  40e7e9:	jne    40e82e <__swc_fn_23cea7fa_000050_5e919db9+0x22e>
  40e7eb:	mov    rcx,r14
  40e7ee:	call   407320 <__swc_fn_23cea7fa_000006_7b253ae1>
  40e7f3:	test   al,al
  40e7f5:	je     40e82e <__swc_fn_23cea7fa_000050_5e919db9+0x22e>
  40e7f7:	mov    rax,QWORD PTR [r14]
  40e7fa:	test   rax,rax
  40e7fd:	je     40e80c <__swc_fn_23cea7fa_000050_5e919db9+0x20c>
  40e7ff:	mov    rcx,QWORD PTR [rax]
  40e802:	mov    QWORD PTR [r14],rcx
  40e805:	add    DWORD PTR [r14+0x28],0x1
  40e80a:	jmp    40e82b <__swc_fn_23cea7fa_000050_5e919db9+0x22b>
  40e80c:	mov    rax,QWORD PTR [r14+0x18]
  40e810:	cmp    QWORD PTR [r14+0x20],rax
  40e814:	jae    40e829 <__swc_fn_23cea7fa_000050_5e919db9+0x229>
  40e816:	mov    rax,QWORD PTR [r14+0x20]
  40e81a:	mov    ecx,DWORD PTR [r14+0x2c]
  40e81e:	add    QWORD PTR [r14+0x20],rcx
  40e822:	add    DWORD PTR [r14+0x28],0x1
  40e827:	jmp    40e82b <__swc_fn_23cea7fa_000050_5e919db9+0x22b>
  40e829:	xor    eax,eax
  40e82b:	mov    r15,rax
  40e82e:	test   r15,r15
  40e831:	je     40e780 <__swc_fn_23cea7fa_000050_5e919db9+0x180>
  40e837:	mov    rax,r15
  40e83a:	add    rsp,0x1f8
  40e841:	pop    r15
  40e843:	pop    r14
  40e845:	pop    r13
  40e847:	pop    r12
  40e849:	pop    rdi
  40e84a:	pop    rsi
  40e84b:	ret
  40e84c:	add    BYTE PTR [rax],al
	...

000000000040e850 <__swc_fn_23cea7fa_000053_9aa81fa7>:
  40e850:	push   rsi
  40e851:	push   rdi
  40e852:	push   r12
  40e854:	mov    rsi,rdx
  40e857:	mov    rax,rdx
  40e85a:	shr    rax,0xc
  40e85e:	movabs rdx,0x9e3779b97f4a7c15
  40e868:	imul   rax,rdx
  40e86c:	shr    rax,0x20
  40e870:	lea    rax,[rax*8+0x0]
  40e878:	shr    rax,0x20
  40e87c:	lea    rax,[rax*8+0x0]
  40e884:	lea    rax,[rcx+rax*8+0x40]
  40e889:	xor    edx,edx
  40e88b:	test   dl,dl
  40e88d:	lea    rdi,[rcx+0x8]
  40e891:	cmove  rdi,rax
  40e895:	xor    edx,edx
  40e897:	test   dl,dl
  40e899:	lea    r12,[rcx+0x30]
  40e89d:	lea    rax,[rax+0x8]
  40e8a1:	cmove  r12,rax
  40e8a5:	mov    rcx,rdi
  40e8a8:	call   4098a0 <__swc_fn_23cea7fa_000135_db32cc57>
  40e8ad:	mov    QWORD PTR [rsi+0x30],0x0
  40e8b5:	mov    rax,QWORD PTR [r12]
  40e8b9:	mov    QWORD PTR [rsi+0x38],rax
  40e8bd:	test   rax,rax
  40e8c0:	je     40e8ca <__swc_fn_23cea7fa_000053_9aa81fa7+0x7a>
  40e8c2:	mov    rax,QWORD PTR [rsi+0x38]
  40e8c6:	mov    QWORD PTR [rax+0x30],rsi
  40e8ca:	mov    QWORD PTR [r12],rsi
  40e8ce:	mov    rcx,rdi
  40e8d1:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  40e8d6:	pop    r12
  40e8d8:	pop    rdi
  40e8d9:	pop    rsi
  40e8da:	ret
  40e8db:	add    BYTE PTR [rax],al
  40e8dd:	add    BYTE PTR [rax],al
	...

000000000040e8e0 <__swc_fn_23cea7fa_000056_87dc216f>:
  40e8e0:	lea    rax,[rdx+rdx*4]
  40e8e4:	lea    rax,[rcx+rax*8+0x268]
  40e8ec:	mov    rdx,QWORD PTR [rax+0x10]
  40e8f0:	sub    QWORD PTR [rcx+0x2a68],rdx
  40e8f7:	sub    QWORD PTR [rcx+0x2a70],0x1
  40e8ff:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40e906:	lea    rdx,[rdx+rdx*4]
  40e90a:	lea    rdx,[rcx+rdx*8+0x268]
  40e912:	vmovups xmm0,XMMWORD PTR [rdx]
  40e916:	vmovups XMMWORD PTR [rax],xmm0
  40e91a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40e91f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e924:	mov    rcx,QWORD PTR [rdx+0x20]
  40e928:	mov    QWORD PTR [rax+0x20],rcx
  40e92c:	ret
  40e92d:	add    BYTE PTR [rax],al
	...

000000000040e930 <__swc_fn_23cea7fa_000059_ee6a254c>:
  40e930:	push   rsi
  40e931:	push   rdi
  40e932:	push   r12
  40e934:	push   r13
  40e936:	sub    rsp,0x8
  40e93a:	mov    rsi,r8
  40e93d:	mov    rdi,rcx
  40e940:	mov    r12,rdx
  40e943:	xor    r13d,r13d
  40e946:	cs nop WORD PTR [rax+rax*1+0x0]
  40e950:	mov    eax,DWORD PTR [r12+0x730]
  40e958:	cmp    r13d,eax
  40e95b:	jae    40e9c1 <__swc_fn_23cea7fa_000059_ee6a254c+0x91>
  40e95d:	lea    rax,[r13+r13*4+0x0]
  40e962:	lea    rax,[r12+rax*8+0x738]
  40e96a:	mov    rdx,QWORD PTR [rax]
  40e96d:	mov    r8,QWORD PTR [rax+0x8]
  40e971:	mov    r9,QWORD PTR [rax+0x10]
  40e975:	cmp    QWORD PTR [rax+0x20],rsi
  40e979:	jb     40e980 <__swc_fn_23cea7fa_000059_ee6a254c+0x50>
  40e97b:	inc    r13d
  40e97e:	jmp    40e950 <__swc_fn_23cea7fa_000059_ee6a254c+0x20>
  40e980:	sub    DWORD PTR [r12+0x730],0x1
  40e989:	mov    ecx,DWORD PTR [r12+0x730]
  40e991:	lea    rcx,[rcx+rcx*4]
  40e995:	lea    rcx,[r12+rcx*8+0x738]
  40e99d:	vmovups xmm0,XMMWORD PTR [rcx]
  40e9a1:	vmovups XMMWORD PTR [rax],xmm0
  40e9a5:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40e9aa:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e9af:	mov    rcx,QWORD PTR [rcx+0x20]
  40e9b3:	mov    QWORD PTR [rax+0x20],rcx
  40e9b7:	mov    rcx,rdi
  40e9ba:	call   407750 <__swc_fn_23cea7fa_000039_9ae4348f>
  40e9bf:	jmp    40e950 <__swc_fn_23cea7fa_000059_ee6a254c+0x20>
  40e9c1:	add    rsp,0x8
  40e9c5:	pop    r13
  40e9c7:	pop    r12
  40e9c9:	pop    rdi
  40e9ca:	pop    rsi
  40e9cb:	ret
  40e9cc:	add    BYTE PTR [rax],al
	...

000000000040e9d0 <__swc_fn_23cea7fa_000062_0a65f1d5>:
  40e9d0:	push   rsi
  40e9d1:	push   rdi
  40e9d2:	push   r12
  40e9d4:	push   r13
  40e9d6:	push   r14
  40e9d8:	mov    rsi,rcx
  40e9db:	mov    rdi,rdx
  40e9de:	mov    r12,QWORD PTR [rdi]
  40e9e1:	mov    r13,QWORD PTR [rdi+0x18]
  40e9e5:	mov    rax,r12
  40e9e8:	add    rax,QWORD PTR [rdi+0x8]
  40e9ec:	sub    rax,r13
  40e9ef:	cmp    r8,rax
  40e9f2:	jbe    40e9fd <__swc_fn_23cea7fa_000062_0a65f1d5+0x2d>
  40e9f4:	pop    r14
  40e9f6:	pop    r13
  40e9f8:	pop    r12
  40e9fa:	pop    rdi
  40e9fb:	pop    rsi
  40e9fc:	ret
  40e9fd:	lea    rax,[r13+r8*1+0x0]
  40ea02:	sub    rax,r12
  40ea05:	mov    ecx,0x1000
  40ea0a:	test   ecx,ecx
  40ea0c:	mov    edx,0x8
  40ea11:	cmove  ecx,edx
  40ea14:	dec    rcx
  40ea17:	mov    rdx,0xffffffffffffffff
  40ea1e:	sub    rdx,rcx
  40ea21:	cmp    rax,rdx
  40ea24:	jbe    40ea2b <__swc_fn_23cea7fa_000062_0a65f1d5+0x5b>
  40ea26:	xor    r14d,r14d
  40ea29:	jmp    40ea36 <__swc_fn_23cea7fa_000062_0a65f1d5+0x66>
  40ea2b:	add    rax,rcx
  40ea2e:	andn   rax,rcx,rax
  40ea33:	mov    r14,rax
  40ea36:	mov    rax,QWORD PTR [rdi+0x10]
  40ea3a:	cmp    r14,rax
  40ea3d:	ja     40ea48 <__swc_fn_23cea7fa_000062_0a65f1d5+0x78>
  40ea3f:	pop    r14
  40ea41:	pop    r13
  40ea43:	pop    r12
  40ea45:	pop    rdi
  40ea46:	pop    rsi
  40ea47:	ret
  40ea48:	mov    rax,r12
  40ea4b:	add    rax,QWORD PTR [rdi+0x10]
  40ea4f:	mov    rdx,r14
  40ea52:	sub    rdx,QWORD PTR [rdi+0x10]
  40ea56:	mov    rcx,rax
  40ea59:	call   4072a0 <__swc_fn_23cea7fa_000003_81215399>
  40ea5e:	test   al,al
  40ea60:	jne    40ea6b <__swc_fn_23cea7fa_000062_0a65f1d5+0x9b>
  40ea62:	pop    r14
  40ea64:	pop    r13
  40ea66:	pop    r12
  40ea68:	pop    rdi
  40ea69:	pop    rsi
  40ea6a:	ret
  40ea6b:	add    r12,r14
  40ea6e:	sub    r12,r13
  40ea71:	mov    rcx,r12
  40ea74:	sub    rcx,QWORD PTR [rdi+0x28]
  40ea78:	mov    rdx,QWORD PTR [rsi+0x250]
  40ea7f:	nop
  40ea80:	lea    r8,[rdx+rcx*1]
  40ea84:	mov    rax,rdx
  40ea87:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40ea90:	cmp    rax,rdx
  40ea93:	je     40ea9a <__swc_fn_23cea7fa_000062_0a65f1d5+0xca>
  40ea95:	mov    rdx,rax
  40ea98:	jmp    40ea80 <__swc_fn_23cea7fa_000062_0a65f1d5+0xb0>
  40ea9a:	mov    QWORD PTR [rdi+0x10],r14
  40ea9e:	mov    QWORD PTR [rdi+0x28],r12
  40eaa2:	pop    r14
  40eaa4:	pop    r13
  40eaa6:	pop    r12
  40eaa8:	pop    rdi
  40eaa9:	pop    rsi
  40eaaa:	ret
  40eaab:	add    BYTE PTR [rax],al
  40eaad:	add    BYTE PTR [rax],al
	...

000000000040eab0 <__swc_fn_23cea7fa_000065_0b20477c>:
  40eab0:	push   rbx
  40eab1:	push   rsi
  40eab2:	push   rdi
  40eab3:	push   r12
  40eab5:	push   r13
  40eab7:	sub    rsp,0xe0
  40eabe:	mov    rbx,rdx
  40eac1:	mov    rsi,rcx
  40eac4:	cmp    DWORD PTR [rbx+0x58],0x0
  40eac8:	je     40eaec <__swc_fn_23cea7fa_000065_0b20477c+0x3c>
  40eaca:	mov    eax,DWORD PTR [rbx+0x58]
  40eacd:	sub    eax,0x1
  40ead0:	test   DWORD PTR [rbx+0x58],eax
  40ead3:	je     40eaec <__swc_fn_23cea7fa_000065_0b20477c+0x3c>
  40ead5:	mov    QWORD PTR [rbx+0x40],0x0
  40eadd:	add    rsp,0xe0
  40eae4:	pop    r13
  40eae6:	pop    r12
  40eae8:	pop    rdi
  40eae9:	pop    rsi
  40eaea:	pop    rbx
  40eaeb:	ret
  40eaec:	mov    rax,QWORD PTR [rbx+0x40]
  40eaf0:	test   rax,rax
  40eaf3:	jne    40eb0f <__swc_fn_23cea7fa_000065_0b20477c+0x5f>
  40eaf5:	mov    rcx,rsi
  40eaf8:	mov    rdx,rbx
  40eafb:	call   40b890 <__swc_fn_23cea7fa_000064_20100e91>
  40eb00:	add    rsp,0xe0
  40eb07:	pop    r13
  40eb09:	pop    r12
  40eb0b:	pop    rdi
  40eb0c:	pop    rsi
  40eb0d:	pop    rbx
  40eb0e:	ret
  40eb0f:	cmp    QWORD PTR [rbx+0x48],0x0
  40eb14:	jne    40eb30 <__swc_fn_23cea7fa_000065_0b20477c+0x80>
  40eb16:	mov    rcx,rsi
  40eb19:	mov    rdx,rbx
  40eb1c:	call   407f90 <__swc_fn_23cea7fa_000066_918d3875>
  40eb21:	add    rsp,0xe0
  40eb28:	pop    r13
  40eb2a:	pop    r12
  40eb2c:	pop    rdi
  40eb2d:	pop    rsi
  40eb2e:	pop    rbx
  40eb2f:	ret
  40eb30:	mov    rdi,QWORD PTR [rbx+0x40]
  40eb34:	lea    rax,[rip+0x15535]        # 424070 <__swc_bss_base_23cea7fa+0x30>
  40eb3b:	mov    rcx,rdi
  40eb3e:	sub    rcx,QWORD PTR [rax+0x8]
  40eb42:	mov    rax,QWORD PTR [rip+0x15537]        # 424080 <__swc_bss_base_23cea7fa+0x40>
  40eb49:	cmp    rcx,rax
  40eb4c:	jae    40eb78 <__swc_fn_23cea7fa_000065_0b20477c+0xc8>
  40eb4e:	mov    rax,rdi
  40eb51:	and    rax,0xffffffffffc00000
  40eb58:	mov    rcx,rdi
  40eb5b:	shr    rcx,0x10
  40eb5f:	and    ecx,0x3f
  40eb62:	mov    edx,DWORD PTR [rax+0x28]
  40eb65:	shrx   ecx,ecx,edx
  40eb6a:	shl    rcx,0x4
  40eb6e:	lea    r12,[rax+rcx*8+0x80]
  40eb76:	jmp    40eb83 <__swc_fn_23cea7fa_000065_0b20477c+0xd3>
  40eb78:	mov    rcx,rdi
  40eb7b:	call   40a910 <__swc_fn_23cea7fa_000022_53fc00d2>
  40eb80:	mov    r12,rax
  40eb83:	test   r12,r12
  40eb86:	je     40eb95 <__swc_fn_23cea7fa_000065_0b20477c+0xe5>
  40eb88:	mov    eax,DWORD PTR [r12+0x2c]
  40eb8d:	mov    r9d,eax
  40eb90:	mov    r13,rax
  40eb93:	jmp    40ec14 <__swc_fn_23cea7fa_000065_0b20477c+0x164>
  40eb95:	mov    rcx,rsi
  40eb98:	mov    rdx,rdi
  40eb9b:	call   40af20 <__swc_fn_23cea7fa_000052_92b016ae>
  40eba0:	mov    rcx,QWORD PTR [rax+0x28]
  40eba4:	mov    r9,rcx
  40eba7:	mov    rdx,QWORD PTR [rax+0x20]
  40ebab:	mov    r13,rdx
  40ebae:	cmp    QWORD PTR [rbx+0x48],rcx
  40ebb2:	jbe    40ebeb <__swc_fn_23cea7fa_000065_0b20477c+0x13b>
  40ebb4:	mov    ecx,DWORD PTR [rax+0x48]
  40ebb7:	cmp    DWORD PTR [rbx+0x58],ecx
  40ebba:	ja     40ebeb <__swc_fn_23cea7fa_000065_0b20477c+0x13b>
  40ebbc:	mov    rcx,rsi
  40ebbf:	mov    rdx,rax
  40ebc2:	mov    r8,QWORD PTR [rbx+0x48]
  40ebc6:	mov    QWORD PTR [rsp+0xc8],r9
  40ebce:	mov    QWORD PTR [rsp+0xd0],rax
  40ebd6:	call   40e9d0 <__swc_fn_23cea7fa_000062_0a65f1d5>
  40ebdb:	mov    r9,QWORD PTR [rsp+0xc8]
  40ebe3:	mov    rax,QWORD PTR [rsp+0xd0]
  40ebeb:	mov    rcx,QWORD PTR [rax+0x28]
  40ebef:	cmp    QWORD PTR [rbx+0x48],rcx
  40ebf3:	ja     40ec14 <__swc_fn_23cea7fa_000065_0b20477c+0x164>
  40ebf5:	mov    ecx,DWORD PTR [rax+0x48]
  40ebf8:	cmp    DWORD PTR [rbx+0x58],ecx
  40ebfb:	ja     40ec14 <__swc_fn_23cea7fa_000065_0b20477c+0x164>
  40ebfd:	mov    rcx,QWORD PTR [rbx+0x48]
  40ec01:	mov    QWORD PTR [rax+0x20],rcx
  40ec05:	add    rsp,0xe0
  40ec0c:	pop    r13
  40ec0e:	pop    r12
  40ec10:	pop    rdi
  40ec11:	pop    rsi
  40ec12:	pop    rbx
  40ec13:	ret
  40ec14:	test   r12,r12
  40ec17:	je     40ec49 <__swc_fn_23cea7fa_000065_0b20477c+0x199>
  40ec19:	cmp    QWORD PTR [rbx+0x48],r9
  40ec1d:	ja     40ec49 <__swc_fn_23cea7fa_000065_0b20477c+0x199>
  40ec1f:	cmp    DWORD PTR [rbx+0x58],0x40
  40ec23:	ja     40ec49 <__swc_fn_23cea7fa_000065_0b20477c+0x199>
  40ec25:	cmp    DWORD PTR [rbx+0x58],0x0
  40ec29:	je     40ec36 <__swc_fn_23cea7fa_000065_0b20477c+0x186>
  40ec2b:	mov    ecx,DWORD PTR [rbx+0x58]
  40ec2e:	dec    rcx
  40ec31:	test   rdi,rcx
  40ec34:	jne    40ec49 <__swc_fn_23cea7fa_000065_0b20477c+0x199>
  40ec36:	mov    QWORD PTR [rbx+0x40],rdi
  40ec3a:	add    rsp,0xe0
  40ec41:	pop    r13
  40ec43:	pop    r12
  40ec45:	pop    rdi
  40ec46:	pop    rsi
  40ec47:	pop    rbx
  40ec48:	ret
  40ec49:	vmovups xmm0,XMMWORD PTR [rbx]
  40ec4d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ec53:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40ec58:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40ec5e:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40ec63:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40ec69:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40ec6e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40ec74:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40ec79:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40ec7f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40ec84:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40ec8a:	mov    QWORD PTR [rsp+0x48],0x0
  40ec93:	mov    rcx,rsi
  40ec96:	lea    rdx,[rsp+0x8]
  40ec9b:	call   40b890 <__swc_fn_23cea7fa_000064_20100e91>
  40eca0:	mov    rax,QWORD PTR [rsp+0x48]
  40eca5:	test   rax,rax
  40eca8:	jne    40ecc1 <__swc_fn_23cea7fa_000065_0b20477c+0x211>
  40ecaa:	mov    QWORD PTR [rbx+0x40],0x0
  40ecb2:	add    rsp,0xe0
  40ecb9:	pop    r13
  40ecbb:	pop    r12
  40ecbd:	pop    rdi
  40ecbe:	pop    rsi
  40ecbf:	pop    rbx
  40ecc0:	ret
  40ecc1:	mov    rax,QWORD PTR [rbx+0x48]
  40ecc5:	cmp    r13,rax
  40ecc8:	cmovbe rax,r13
  40eccc:	mov    rcx,QWORD PTR [rsp+0x48]
  40ecd1:	mov    rdx,rdi
  40ecd4:	mov    r8,rax
  40ecd7:	call   4090e0 <__swc_fn_23cea7fa_000105_83487ba1>
  40ecdc:	vmovups xmm0,XMMWORD PTR [rbx]
  40ece0:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40ece6:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40eceb:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40ecf1:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40ecf6:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40ecff:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40ed04:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40ed0d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40ed12:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40ed1b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40ed20:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40ed29:	mov    QWORD PTR [rsp+0xa8],rdi
  40ed31:	mov    rcx,rsi
  40ed34:	lea    rdx,[rsp+0x68]
  40ed39:	call   407f90 <__swc_fn_23cea7fa_000066_918d3875>
  40ed3e:	mov    rax,QWORD PTR [rsp+0x48]
  40ed43:	mov    QWORD PTR [rbx+0x40],rax
  40ed47:	add    rsp,0xe0
  40ed4e:	pop    r13
  40ed50:	pop    r12
  40ed52:	pop    rdi
  40ed53:	pop    rsi
  40ed54:	pop    rbx
  40ed55:	ret
	...

000000000040ed60 <__swc_fn_23cea7fa_000068_f501e74b>:
  40ed60:	push   r12
  40ed62:	push   rdi
  40ed63:	push   rsi
  40ed64:	push   r13
  40ed66:	push   r14
  40ed68:	sub    rsp,0x190
  40ed6f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40ed78:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40ed81:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40ed8a:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40ed93:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40ed9c:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40eda5:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40edae:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40edb7:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40edc0:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40edc9:	mov    r12,rcx
  40edcc:	lea    rax,[rip+0x1322d]        # 422000 <__swc_data_base_23cea7fa>
  40edd3:	mov    rax,QWORD PTR [rax]
  40edd6:	cmp    rax,0xffffffffffffffff
  40edda:	je     40ede9 <__swc_fn_23cea7fa_000068_f501e74b+0x89>
  40eddc:	mov    eax,eax
  40edde:	mov    edi,eax
  40ede0:	xor    eax,eax
  40ede2:	call   407000 <pthread_getspecific@plt>
  40ede7:	jmp    40edeb <__swc_fn_23cea7fa_000068_f501e74b+0x8b>
  40ede9:	xor    eax,eax
  40edeb:	test   rax,rax
  40edee:	jne    40edfd <__swc_fn_23cea7fa_000068_f501e74b+0x9d>
  40edf0:	call   40a9e0 <__swc_fn_23cea7fa_000031_3c3e930e>
  40edf5:	mov    rcx,rax
  40edf8:	call   410520 <__swc_fn_23cea7fa_000128_8d8a7dd2>
  40edfd:	test   rax,rax
  40ee00:	je     40ee26 <__swc_fn_23cea7fa_000068_f501e74b+0xc6>
  40ee02:	cmp    QWORD PTR [rax],r12
  40ee05:	jne    40ee26 <__swc_fn_23cea7fa_000068_f501e74b+0xc6>
  40ee07:	xor    ecx,ecx
  40ee09:	mov    QWORD PTR [rsp+0xc8],rax
  40ee11:	call   407720 <__swc_fn_23cea7fa_000033_d15eb4ea>
  40ee16:	mov    rdx,QWORD PTR [rsp+0xc8]
  40ee1e:	mov    rcx,r12
  40ee21:	call   407840 <__swc_fn_23cea7fa_000042_0573444d>
  40ee26:	lea    rsi,[r12+0x10]
  40ee2b:	mov    rcx,rsi
  40ee2e:	call   4098a0 <__swc_fn_23cea7fa_000135_db32cc57>
  40ee33:	mov    rdi,QWORD PTR [r12+0x20]
  40ee38:	test   rdi,rdi
  40ee3b:	je     40ee7e <__swc_fn_23cea7fa_000068_f501e74b+0x11e>
  40ee3d:	nop    DWORD PTR [rax]
  40ee40:	mov    rcx,r12
  40ee43:	mov    rdx,rdi
  40ee46:	call   40aba0 <__swc_fn_23cea7fa_000043_47ff6d9b>
  40ee4b:	mov    rcx,r12
  40ee4e:	mov    rdx,rdi
  40ee51:	mov    r8,0xffffffffffffffff
  40ee58:	call   40e930 <__swc_fn_23cea7fa_000059_ee6a254c>
  40ee5d:	mov    rcx,r12
  40ee60:	mov    rdx,rdi
  40ee63:	mov    r8d,0x9b8
  40ee69:	mov    r9d,0x9b8
  40ee6f:	call   407750 <__swc_fn_23cea7fa_000039_9ae4348f>
  40ee74:	mov    rdi,QWORD PTR [r12+0x20]
  40ee79:	test   rdi,rdi
  40ee7c:	jne    40ee40 <__swc_fn_23cea7fa_000068_f501e74b+0xe0>
  40ee7e:	xor    eax,eax
  40ee80:	xchg   QWORD PTR [r12+0x2a80],rax
  40ee88:	test   rax,rax
  40ee8b:	je     40eeb1 <__swc_fn_23cea7fa_000068_f501e74b+0x151>
  40ee8d:	cs nop WORD PTR [rax+rax*1+0x0]
  40ee97:	nop    WORD PTR [rax+rax*1+0x0]
  40eea0:	mov    rcx,rax
  40eea3:	mov    rax,QWORD PTR [rax+0x78]
  40eea7:	xor    edx,edx
  40eea9:	xchg   DWORD PTR [rcx+0x70],edx
  40eeac:	test   rax,rax
  40eeaf:	jne    40eea0 <__swc_fn_23cea7fa_000068_f501e74b+0x140>
  40eeb1:	mov    rax,QWORD PTR [r12+0x18]
  40eeb6:	mov    rdi,rax
  40eeb9:	test   rdi,rdi
  40eebc:	je     40ef51 <__swc_fn_23cea7fa_000068_f501e74b+0x1f1>
  40eec2:	cs nop WORD PTR [rax+rax*1+0x0]
  40eecc:	nop    DWORD PTR [rax+0x0]
  40eed0:	mov    rax,QWORD PTR [rdi+0x10]
  40eed4:	mov    r8d,DWORD PTR [rdi+0x2c]
  40eed8:	xor    r9d,r9d
  40eedb:	test   r8,r8
  40eede:	jbe    40ef3d <__swc_fn_23cea7fa_000068_f501e74b+0x1dd>
  40eee0:	mov    ecx,r9d
  40eee3:	shl    rcx,0x4
  40eee7:	lea    rdx,[rdi+rcx*8+0x80]
  40eeef:	cmp    BYTE PTR [rdx+0x3b],0x0
  40eef3:	je     40ef34 <__swc_fn_23cea7fa_000068_f501e74b+0x1d4>
  40eef5:	mov    DWORD PTR [rdx+0x28],0x0
  40eefc:	mov    rcx,rdi
  40eeff:	mov    QWORD PTR [rsp+0xd0],rax
  40ef07:	mov    QWORD PTR [rsp+0xd8],r8
  40ef0f:	mov    QWORD PTR [rsp+0xe0],r9
  40ef17:	call   40e060 <__swc_fn_23cea7fa_000014_be17798c>
  40ef1c:	mov    rax,QWORD PTR [rsp+0xd0]
  40ef24:	mov    r8,QWORD PTR [rsp+0xd8]
  40ef2c:	mov    r9,QWORD PTR [rsp+0xe0]
  40ef34:	add    r9,0x1
  40ef38:	cmp    r9,r8
  40ef3b:	jb     40eee0 <__swc_fn_23cea7fa_000068_f501e74b+0x180>
  40ef3d:	mov    rcx,rdi
  40ef40:	mov    rdi,rax
  40ef43:	call   407630 <__swc_fn_23cea7fa_000021_9cf87641>
  40ef48:	test   rdi,rdi
  40ef4b:	jne    40eed0 <__swc_fn_23cea7fa_000068_f501e74b+0x170>
  40ef51:	mov    QWORD PTR [r12+0x18],0x0
  40ef5a:	mov    QWORD PTR [r12+0x28],0x0
  40ef63:	mov    rcx,rsi
  40ef66:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  40ef6b:	mov    esi,0x8
  40ef70:	xor    edi,edi
  40ef72:	test   rsi,rsi
  40ef75:	je     40efd2 <__swc_fn_23cea7fa_000068_f501e74b+0x272>
  40ef7b:	nop    DWORD PTR [rax+rax*1+0x0]
  40ef80:	lea    r13,[rdi*8+0x0]
  40ef88:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40ef8d:	test   r14,r14
  40ef90:	je     40efc8 <__swc_fn_23cea7fa_000068_f501e74b+0x268>
  40ef92:	cs nop WORD PTR [rax+rax*1+0x0]
  40ef9c:	nop    DWORD PTR [rax+0x0]
  40efa0:	mov    rcx,r12
  40efa3:	mov    rdx,r14
  40efa6:	call   407df0 <__swc_fn_23cea7fa_000054_e8e85c01>
  40efab:	mov    rcx,r12
  40efae:	mov    rdx,QWORD PTR [r14]
  40efb1:	mov    r8,QWORD PTR [r14+0x8]
  40efb5:	mov    r9,QWORD PTR [r14+0x10]
  40efb9:	call   407750 <__swc_fn_23cea7fa_000039_9ae4348f>
  40efbe:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40efc3:	test   r14,r14
  40efc6:	jne    40efa0 <__swc_fn_23cea7fa_000068_f501e74b+0x240>
  40efc8:	add    rdi,0x1
  40efcc:	sub    rsi,0x1
  40efd0:	jne    40ef80 <__swc_fn_23cea7fa_000068_f501e74b+0x220>
  40efd2:	mov    rcx,r12
  40efd5:	call   407ec0 <__swc_fn_23cea7fa_000060_6818d0d1>
  40efda:	lea    rcx,[r12+0x250]
  40efe2:	mov    rdx,QWORD PTR [rcx]
  40efe5:	mov    r8,QWORD PTR [r12+0x250]
  40efed:	nop    DWORD PTR [rax]
  40eff0:	mov    r9,r8
  40eff3:	sub    r9,rdx
  40eff6:	mov    rax,r8
  40eff9:	lock cmpxchg QWORD PTR [rcx],r9
  40effe:	cmp    rax,r8
  40f001:	je     40f008 <__swc_fn_23cea7fa_000068_f501e74b+0x2a8>
  40f003:	mov    r8,rax
  40f006:	jmp    40eff0 <__swc_fn_23cea7fa_000068_f501e74b+0x290>
  40f008:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40f011:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40f01a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40f023:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40f02c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40f035:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40f03e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40f047:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40f050:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40f059:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40f062:	add    rsp,0x190
  40f069:	pop    r14
  40f06b:	pop    r13
  40f06d:	pop    rsi
  40f06e:	pop    rdi
  40f06f:	pop    r12
  40f071:	ret
	...

000000000040f080 <__swc_fn_23cea7fa_000071_1e1e3bf8>:
  40f080:	sub    rsp,0x8
  40f084:	mov    QWORD PTR [rdx+0x40],0x0
  40f08c:	call   40b890 <__swc_fn_23cea7fa_000064_20100e91>
  40f091:	add    rsp,0x8
  40f095:	ret
	...

000000000040f0a0 <__swc_fn_23cea7fa_000074_30b8696a>:
  40f0a0:	sub    rsp,0x8
  40f0a4:	call   407f90 <__swc_fn_23cea7fa_000066_918d3875>
  40f0a9:	add    rsp,0x8
  40f0ad:	ret
	...

000000000040f0b0 <__swc_fn_23cea7fa_000077_948ef603>:
  40f0b0:	push   rbx
  40f0b1:	push   rsi
  40f0b2:	push   rdi
  40f0b3:	push   r12
  40f0b5:	push   r13
  40f0b7:	push   r14
  40f0b9:	push   r15
  40f0bb:	sub    rsp,0x20
  40f0bf:	mov    rbx,r11
  40f0c2:	mov    rsi,rcx
  40f0c5:	mov    rdi,rdx
  40f0c8:	mov    r12,r8
  40f0cb:	mov    r13,r9
  40f0ce:	mov    r14,r10
  40f0d1:	mov    rcx,QWORD PTR [rip+0x17c68]        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  40f0d8:	test   rcx,rcx
  40f0db:	jne    40f0ed <__swc_fn_23cea7fa_000077_948ef603+0x3d>
  40f0dd:	call   40a1a0 <__swc_fn_23cea7fa_000165_56054fe7>
  40f0e2:	lea    rcx,[rax+0x1]
  40f0e6:	mov    QWORD PTR [rip+0x17c53],rcx        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  40f0ed:	dec    rcx
  40f0f0:	call   411fa0 <__swc_fn_23cea7fa_000167_39c041ad>
  40f0f5:	mov    r15,rax
  40f0f8:	lea    r11,[rip+0x15141]        # 424240 <__swc_bss_base_23cea7fa+0x200>
  40f0ff:	mov    rcx,r11
  40f102:	call   407740 <__swc_fn_23cea7fa_000036_290a131c>
  40f107:	test   al,al
  40f109:	jne    40f11a <__swc_fn_23cea7fa_000077_948ef603+0x6a>
  40f10b:	mov    rcx,r11
  40f10e:	call   40aa40 <__swc_fn_23cea7fa_000034_cf5ba7bd>
  40f113:	lea    r11,[rip+0x15126]        # 424240 <__swc_bss_base_23cea7fa+0x200>
  40f11a:	mov    rcx,r11
  40f11d:	mov    rdx,rsi
  40f120:	mov    r8,rdi
  40f123:	mov    r9,r12
  40f126:	mov    r10,r13
  40f129:	mov    rsi,r11
  40f12c:	mov    r11,r14
  40f12f:	call   40e3d0 <__swc_fn_23cea7fa_000035_ab2e8c35>
  40f134:	test   bl,bl
  40f136:	je     40f15d <__swc_fn_23cea7fa_000077_948ef603+0xad>
  40f138:	mov    QWORD PTR [rsp+0x8],rsi
  40f13d:	lea    rax,[rip+0x400c]        # 413150 <__swc_rdata_base_23cea7fa+0x40>
  40f144:	mov    QWORD PTR [rsp+0x10],rax
  40f149:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f14f:	vmovups XMMWORD PTR [r15],xmm0
  40f154:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40f15d:	mov    rax,rsi
  40f160:	add    rsp,0x20
  40f164:	pop    r15
  40f166:	pop    r14
  40f168:	pop    r13
  40f16a:	pop    r12
  40f16c:	pop    rdi
  40f16d:	pop    rsi
  40f16e:	pop    rbx
  40f16f:	ret

000000000040f170 <__swc_fn_23cea7fa_000080_207908fe>:
  40f170:	sub    rsp,0x8
  40f174:	mov    rax,rcx
  40f177:	test   rcx,rcx
  40f17a:	jne    40f181 <__swc_fn_23cea7fa_000080_207908fe+0x11>
  40f17c:	add    rsp,0x8
  40f180:	ret
  40f181:	lea    rcx,[rax-0x10]
  40f185:	mov    rax,QWORD PTR [rax-0x10]
  40f189:	mov    rdx,rax
  40f18c:	call   4101d0 <__swc_fn_23cea7fa_000113_4e83a03a>
  40f191:	add    rsp,0x8
  40f195:	ret
	...

000000000040f1a0 <__swc_fn_23cea7fa_000083_f2d93dad>:
  40f1a0:	sub    rsp,0x8
  40f1a4:	xor    r11d,r11d
  40f1a7:	call   408250 <__swc_fn_23cea7fa_000084_5ed30bd6>
  40f1ac:	add    rsp,0x8
  40f1b0:	ret
	...

000000000040f1c0 <__swc_fn_23cea7fa_000086_d9243de4>:
  40f1c0:	push   rsi
  40f1c1:	push   rdi
  40f1c2:	push   r12
  40f1c4:	push   r13
  40f1c6:	push   r14
  40f1c8:	push   r15
  40f1ca:	sub    rsp,0x68
  40f1ce:	mov    rsi,r9
  40f1d1:	mov    rdi,rcx
  40f1d4:	mov    r12,rdx
  40f1d7:	mov    r13,r8
  40f1da:	cmp    r8,r9
  40f1dd:	jne    40f205 <__swc_fn_23cea7fa_000086_d9243de4+0x45>
  40f1df:	mov    rcx,rdi
  40f1e2:	mov    rdx,r12
  40f1e5:	xor    r8d,r8d
  40f1e8:	call   4085a0 <__swc_fn_23cea7fa_000090_14cf59b2>
  40f1ed:	test   al,al
  40f1ef:	je     40f205 <__swc_fn_23cea7fa_000086_d9243de4+0x45>
  40f1f1:	mov    eax,0x1
  40f1f6:	add    rsp,0x68
  40f1fa:	pop    r15
  40f1fc:	pop    r14
  40f1fe:	pop    r13
  40f200:	pop    r12
  40f202:	pop    rdi
  40f203:	pop    rsi
  40f204:	ret
  40f205:	cmp    BYTE PTR [r12+0x2c],0xe
  40f20b:	je     40f21e <__swc_fn_23cea7fa_000086_d9243de4+0x5e>
  40f20d:	xor    eax,eax
  40f20f:	add    rsp,0x68
  40f213:	pop    r15
  40f215:	pop    r14
  40f217:	pop    r13
  40f219:	pop    r12
  40f21b:	pop    rdi
  40f21c:	pop    rsi
  40f21d:	ret
  40f21e:	mov    r14,QWORD PTR [r12+0x98]
  40f226:	mov    rax,QWORD PTR [r12+0xa0]
  40f22e:	mov    r12,rax
  40f231:	xor    r15d,r15d
  40f234:	test   r12,r12
  40f237:	je     40f29f <__swc_fn_23cea7fa_000086_d9243de4+0xdf>
  40f239:	nop    DWORD PTR [rax+0x0]
  40f240:	mov    QWORD PTR [rsp+0x58],r12
  40f245:	lea    r12,[r15*8+0x0]
  40f24d:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40f252:	mov    rcx,rax
  40f255:	call   40c020 <__swc_fn_23cea7fa_000082_ff7d1455>
  40f25a:	cmp    BYTE PTR [rax+0x2c],0xe
  40f25e:	jne    40f290 <__swc_fn_23cea7fa_000086_d9243de4+0xd0>
  40f260:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40f265:	lea    r8,[r13+rcx*1+0x0]
  40f26a:	mov    rcx,rdi
  40f26d:	mov    rdx,rax
  40f270:	mov    r9,rsi
  40f273:	call   40f1c0 <__swc_fn_23cea7fa_000086_d9243de4>
  40f278:	test   al,al
  40f27a:	je     40f290 <__swc_fn_23cea7fa_000086_d9243de4+0xd0>
  40f27c:	mov    eax,0x1
  40f281:	add    rsp,0x68
  40f285:	pop    r15
  40f287:	pop    r14
  40f289:	pop    r13
  40f28b:	pop    r12
  40f28d:	pop    rdi
  40f28e:	pop    rsi
  40f28f:	ret
  40f290:	add    r15,0x1
  40f294:	mov    r12,QWORD PTR [rsp+0x58]
  40f299:	sub    r12,0x1
  40f29d:	jne    40f240 <__swc_fn_23cea7fa_000086_d9243de4+0x80>
  40f29f:	xor    eax,eax
  40f2a1:	add    rsp,0x68
  40f2a5:	pop    r15
  40f2a7:	pop    r14
  40f2a9:	pop    r13
  40f2ab:	pop    r12
  40f2ad:	pop    rdi
  40f2ae:	pop    rsi
  40f2af:	ret

000000000040f2b0 <__swc_fn_23cea7fa_000089_3c530920>:
  40f2b0:	push   rbp
  40f2b1:	push   rbx
  40f2b2:	push   rsi
  40f2b3:	push   rdi
  40f2b4:	push   r12
  40f2b6:	push   r13
  40f2b8:	push   r14
  40f2ba:	push   r15
  40f2bc:	sub    rsp,0x38
  40f2c0:	mov    rbp,rsp
  40f2c3:	mov    rbx,r11
  40f2c6:	mov    rsi,rdx
  40f2c9:	mov    rdi,r8
  40f2cc:	mov    r12,r9
  40f2cf:	mov    QWORD PTR [rsp+0x18],r9
  40f2d4:	mov    r13,r10
  40f2d7:	movzx  r14d,BYTE PTR [rbp+0x80]
  40f2df:	movzx  r15d,BYTE PTR [rbp+0x88]
  40f2e7:	test   r11,r11
  40f2ea:	je     40f2f0 <__swc_fn_23cea7fa_000089_3c530920+0x40>
  40f2ec:	xor    eax,eax
  40f2ee:	mov    BYTE PTR [rbx],al
  40f2f0:	test   r12,r12
  40f2f3:	je     40f2fe <__swc_fn_23cea7fa_000089_3c530920+0x4e>
  40f2f5:	mov    QWORD PTR [r12+0x8],0x0
  40f2fe:	test   rcx,rcx
  40f301:	je     40f308 <__swc_fn_23cea7fa_000089_3c530920+0x58>
  40f303:	test   rsi,rsi
  40f306:	jne    40f31b <__swc_fn_23cea7fa_000089_3c530920+0x6b>
  40f308:	xor    eax,eax
  40f30a:	add    rsp,0x38
  40f30e:	pop    r15
  40f310:	pop    r14
  40f312:	pop    r13
  40f314:	pop    r12
  40f316:	pop    rdi
  40f317:	pop    rsi
  40f318:	pop    rbx
  40f319:	pop    rbp
  40f31a:	ret
  40f31b:	call   40c020 <__swc_fn_23cea7fa_000082_ff7d1455>
  40f320:	mov    r12,rax
  40f323:	mov    al,r15b
  40f326:	test   r15b,r15b
  40f329:	jne    40f339 <__swc_fn_23cea7fa_000089_3c530920+0x89>
  40f32b:	mov    eax,DWORD PTR [r12+0x28]
  40f330:	and    eax,0x10000
  40f336:	setne  al
  40f339:	lea    r15,[rsp+0x8]
  40f33e:	mov    QWORD PTR [rsp+0x20],r15
  40f343:	rex mov BYTE PTR [rsp+0x8],al
  40f348:	test   DWORD PTR [rsi+0x28],0x400000
  40f34f:	je     40f387 <__swc_fn_23cea7fa_000089_3c530920+0xd7>
  40f351:	test   rsi,rsi
  40f354:	je     40f374 <__swc_fn_23cea7fa_000089_3c530920+0xc4>
  40f356:	mov    rax,QWORD PTR [rsi+0x38]
  40f35a:	cmp    QWORD PTR [rax+0x10],rsi
  40f35e:	jne    40f374 <__swc_fn_23cea7fa_000089_3c530920+0xc4>
  40f360:	rex mov al,BYTE PTR [rsp+0x8]
  40f365:	test   al,al
  40f367:	sete   al
  40f36a:	test   r14b,r14b
  40f36d:	sete   cl
  40f370:	test   al,cl
  40f372:	je     40f387 <__swc_fn_23cea7fa_000089_3c530920+0xd7>
  40f374:	xor    eax,eax
  40f376:	add    rsp,0x38
  40f37a:	pop    r15
  40f37c:	pop    r14
  40f37e:	pop    r13
  40f380:	pop    r12
  40f382:	pop    rdi
  40f383:	pop    rsi
  40f384:	pop    rbx
  40f385:	pop    rbp
  40f386:	ret
  40f387:	mov    r15,r12
  40f38a:	test   r14b,r14b
  40f38d:	jne    40f3a4 <__swc_fn_23cea7fa_000089_3c530920+0xf4>
  40f38f:	cmp    BYTE PTR [r12+0x2c],0x6
  40f395:	jne    40f3a4 <__swc_fn_23cea7fa_000089_3c530920+0xf4>
  40f397:	mov    rcx,QWORD PTR [r12+0x40]
  40f39c:	call   40c020 <__swc_fn_23cea7fa_000082_ff7d1455>
  40f3a1:	mov    r15,rax
  40f3a4:	test   r14b,r14b
  40f3a7:	je     40f3ad <__swc_fn_23cea7fa_000089_3c530920+0xfd>
  40f3a9:	mov    r15,QWORD PTR [r15+0x30]
  40f3ad:	mov    rcx,rsi
  40f3b0:	call   40c020 <__swc_fn_23cea7fa_000082_ff7d1455>
  40f3b5:	mov    rsi,rax
  40f3b8:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f3bd:	je     40f3f4 <__swc_fn_23cea7fa_000089_3c530920+0x144>
  40f3bf:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f3c4:	je     40f3f4 <__swc_fn_23cea7fa_000089_3c530920+0x144>
  40f3c6:	mov    eax,DWORD PTR [rsi+0x28]
  40f3c9:	and    eax,0x10000
  40f3cf:	je     40f3f4 <__swc_fn_23cea7fa_000089_3c530920+0x144>
  40f3d1:	rex mov al,BYTE PTR [rsp+0x8]
  40f3d6:	test   al,al
  40f3d8:	jne    40f3ed <__swc_fn_23cea7fa_000089_3c530920+0x13d>
  40f3da:	xor    eax,eax
  40f3dc:	add    rsp,0x38
  40f3e0:	pop    r15
  40f3e2:	pop    r14
  40f3e4:	pop    r13
  40f3e6:	pop    r12
  40f3e8:	pop    rdi
  40f3e9:	pop    rsi
  40f3ea:	pop    rbx
  40f3eb:	pop    rbp
  40f3ec:	ret
  40f3ed:	mov    rax,QWORD PTR [rsi+0x30]
  40f3f1:	mov    rsi,rax
  40f3f4:	mov    r14b,r13b
  40f3f7:	test   rbx,rbx
  40f3fa:	je     40f430 <__swc_fn_23cea7fa_000089_3c530920+0x180>
  40f3fc:	cmp    BYTE PTR [r12+0x2c],0x6
  40f402:	jne    40f430 <__swc_fn_23cea7fa_000089_3c530920+0x180>
  40f404:	lea    rdx,[rip+0x3d75]        # 413180 <__swc_rdata_base_23cea7fa+0x70>
  40f40b:	mov    rcx,rsi
  40f40e:	xor    r8d,r8d
  40f411:	call   4085a0 <__swc_fn_23cea7fa_000090_14cf59b2>
  40f416:	test   al,al
  40f418:	je     40f430 <__swc_fn_23cea7fa_000089_3c530920+0x180>
  40f41a:	mov    BYTE PTR [rbx],0x1
  40f41d:	xor    eax,eax
  40f41f:	add    rsp,0x38
  40f423:	pop    r15
  40f425:	pop    r14
  40f427:	pop    r13
  40f429:	pop    r12
  40f42b:	pop    rdi
  40f42c:	pop    rsi
  40f42d:	pop    rbx
  40f42e:	pop    rbp
  40f42f:	ret
  40f430:	test   rdi,rdi
  40f433:	jne    40f44d <__swc_fn_23cea7fa_000089_3c530920+0x19d>
  40f435:	test   r13b,r13b
  40f438:	jne    40f44d <__swc_fn_23cea7fa_000089_3c530920+0x19d>
  40f43a:	xor    eax,eax
  40f43c:	add    rsp,0x38
  40f440:	pop    r15
  40f442:	pop    r14
  40f444:	pop    r13
  40f446:	pop    r12
  40f448:	pop    rdi
  40f449:	pop    rsi
  40f44a:	pop    rbx
  40f44b:	pop    rbp
  40f44c:	ret
  40f44d:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f452:	jne    40f508 <__swc_fn_23cea7fa_000089_3c530920+0x258>
  40f458:	mov    rcx,r15
  40f45b:	mov    rdx,rsi
  40f45e:	xor    r8d,r8d
  40f461:	call   4085a0 <__swc_fn_23cea7fa_000090_14cf59b2>
  40f466:	test   al,al
  40f468:	jne    40f508 <__swc_fn_23cea7fa_000089_3c530920+0x258>
  40f46e:	test   DWORD PTR [rsi+0x28],0x10000
  40f475:	je     40f493 <__swc_fn_23cea7fa_000089_3c530920+0x1e3>
  40f477:	rex mov al,BYTE PTR [rsp+0x8]
  40f47c:	test   al,al
  40f47e:	jne    40f493 <__swc_fn_23cea7fa_000089_3c530920+0x1e3>
  40f480:	xor    eax,eax
  40f482:	add    rsp,0x38
  40f486:	pop    r15
  40f488:	pop    r14
  40f48a:	pop    r13
  40f48c:	pop    r12
  40f48e:	pop    rdi
  40f48f:	pop    rsi
  40f490:	pop    rbx
  40f491:	pop    rbp
  40f492:	ret
  40f493:	test   rdi,rdi
  40f496:	jne    40f4ab <__swc_fn_23cea7fa_000089_3c530920+0x1fb>
  40f498:	xor    eax,eax
  40f49a:	add    rsp,0x38
  40f49e:	pop    r15
  40f4a0:	pop    r14
  40f4a2:	pop    r13
  40f4a4:	pop    r12
  40f4a6:	pop    rdi
  40f4a7:	pop    rsi
  40f4a8:	pop    rbx
  40f4a9:	pop    rbp
  40f4aa:	ret
  40f4ab:	mov    rcx,QWORD PTR [rsi+0x40]
  40f4af:	call   40c020 <__swc_fn_23cea7fa_000082_ff7d1455>
  40f4b4:	mov    rsi,rax
  40f4b7:	mov    rax,QWORD PTR [rdi]
  40f4ba:	mov    rdi,rax
  40f4bd:	test   rax,rax
  40f4c0:	jne    40f503 <__swc_fn_23cea7fa_000089_3c530920+0x253>
  40f4c2:	test   rbx,rbx
  40f4c5:	je     40f503 <__swc_fn_23cea7fa_000089_3c530920+0x253>
  40f4c7:	mov    rcx,r15
  40f4ca:	mov    rdx,rsi
  40f4cd:	xor    r8d,r8d
  40f4d0:	call   4085a0 <__swc_fn_23cea7fa_000090_14cf59b2>
  40f4d5:	mov    rcx,rax
  40f4d8:	test   al,al
  40f4da:	jne    40f4fc <__swc_fn_23cea7fa_000089_3c530920+0x24c>
  40f4dc:	mov    rcx,r15
  40f4df:	mov    rdx,rsi
  40f4e2:	call   40c060 <__swc_fn_23cea7fa_000085_e24ecd12>
  40f4e7:	mov    rcx,rax
  40f4ea:	test   al,al
  40f4ec:	jne    40f4fc <__swc_fn_23cea7fa_000089_3c530920+0x24c>
  40f4ee:	mov    rcx,rsi
  40f4f1:	mov    rdx,r15
  40f4f4:	call   40c060 <__swc_fn_23cea7fa_000085_e24ecd12>
  40f4f9:	mov    rcx,rax
  40f4fc:	test   cl,cl
  40f4fe:	setne  al
  40f501:	mov    BYTE PTR [rbx],al
  40f503:	xor    eax,eax
  40f505:	mov    r14b,al
  40f508:	test   rdi,rdi
  40f50b:	jne    40f525 <__swc_fn_23cea7fa_000089_3c530920+0x275>
  40f50d:	test   r14b,r14b
  40f510:	jne    40f525 <__swc_fn_23cea7fa_000089_3c530920+0x275>
  40f512:	xor    eax,eax
  40f514:	add    rsp,0x38
  40f518:	pop    r15
  40f51a:	pop    r14
  40f51c:	pop    r13
  40f51e:	pop    r12
  40f520:	pop    rdi
  40f521:	pop    rsi
  40f522:	pop    rbx
  40f523:	pop    rbp
  40f524:	ret
  40f525:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f52a:	je     40f536 <__swc_fn_23cea7fa_000089_3c530920+0x286>
  40f52c:	mov    r12,QWORD PTR [rsp+0x18]
  40f531:	jmp    40f5be <__swc_fn_23cea7fa_000089_3c530920+0x30e>
  40f536:	mov    r12,QWORD PTR [rsp+0x18]
  40f53b:	test   r12,r12
  40f53e:	jne    40f552 <__swc_fn_23cea7fa_000089_3c530920+0x2a2>
  40f540:	mov    rcx,r15
  40f543:	mov    rdx,rsi
  40f546:	xor    r8d,r8d
  40f549:	call   4085a0 <__swc_fn_23cea7fa_000090_14cf59b2>
  40f54e:	test   al,al
  40f550:	jne    40f5be <__swc_fn_23cea7fa_000089_3c530920+0x30e>
  40f552:	test   DWORD PTR [rsi+0x28],0x10000
  40f559:	je     40f577 <__swc_fn_23cea7fa_000089_3c530920+0x2c7>
  40f55b:	rex mov al,BYTE PTR [rsp+0x8]
  40f560:	test   al,al
  40f562:	jne    40f577 <__swc_fn_23cea7fa_000089_3c530920+0x2c7>
  40f564:	xor    eax,eax
  40f566:	add    rsp,0x38
  40f56a:	pop    r15
  40f56c:	pop    r14
  40f56e:	pop    r13
  40f570:	pop    r12
  40f572:	pop    rdi
  40f573:	pop    rsi
  40f574:	pop    rbx
  40f575:	pop    rbp
  40f576:	ret
  40f577:	test   rdi,rdi
  40f57a:	jne    40f58f <__swc_fn_23cea7fa_000089_3c530920+0x2df>
  40f57c:	xor    eax,eax
  40f57e:	add    rsp,0x38
  40f582:	pop    r15
  40f584:	pop    r14
  40f586:	pop    r13
  40f588:	pop    r12
  40f58a:	pop    rdi
  40f58b:	pop    rsi
  40f58c:	pop    rbx
  40f58d:	pop    rbp
  40f58e:	ret
  40f58f:	cmp    QWORD PTR [rdi+0x8],0x0
  40f594:	jne    40f5a9 <__swc_fn_23cea7fa_000089_3c530920+0x2f9>
  40f596:	xor    eax,eax
  40f598:	add    rsp,0x38
  40f59c:	pop    r15
  40f59e:	pop    r14
  40f5a0:	pop    r13
  40f5a2:	pop    r12
  40f5a4:	pop    rdi
  40f5a5:	pop    rsi
  40f5a6:	pop    rbx
  40f5a7:	pop    rbp
  40f5a8:	ret
  40f5a9:	mov    rax,QWORD PTR [rdi+0x8]
  40f5ad:	mov    rax,QWORD PTR [rax]
  40f5b0:	mov    rsi,rax
  40f5b3:	mov    rdi,QWORD PTR [rdi]
  40f5b6:	mov    eax,0x1
  40f5bb:	mov    r14b,al
  40f5be:	test   rdi,rdi
  40f5c1:	mov    rbx,QWORD PTR [rsp+0x20]
  40f5c6:	jne    40f610 <__swc_fn_23cea7fa_000089_3c530920+0x360>
  40f5c8:	test   r14b,r14b
  40f5cb:	je     40f5fd <__swc_fn_23cea7fa_000089_3c530920+0x34d>
  40f5cd:	test   r12,r12
  40f5d0:	je     40f5fd <__swc_fn_23cea7fa_000089_3c530920+0x34d>
  40f5d2:	mov    rcx,r15
  40f5d5:	mov    rdx,rsi
  40f5d8:	xor    r8d,r8d
  40f5db:	mov    r9,r12
  40f5de:	mov    rbx,QWORD PTR [rsp+0x20]
  40f5e3:	movzx  r10d,BYTE PTR [rbx]
  40f5e7:	call   40f1a0 <__swc_fn_23cea7fa_000083_f2d93dad>
  40f5ec:	add    rsp,0x38
  40f5f0:	pop    r15
  40f5f2:	pop    r14
  40f5f4:	pop    r13
  40f5f6:	pop    r12
  40f5f8:	pop    rdi
  40f5f9:	pop    rsi
  40f5fa:	pop    rbx
  40f5fb:	pop    rbp
  40f5fc:	ret
  40f5fd:	xor    eax,eax
  40f5ff:	add    rsp,0x38
  40f603:	pop    r15
  40f605:	pop    r14
  40f607:	pop    r13
  40f609:	pop    r12
  40f60b:	pop    rdi
  40f60c:	pop    rsi
  40f60d:	pop    rbx
  40f60e:	pop    rbp
  40f60f:	ret
  40f610:	mov    r13,rsi
  40f613:	mov    QWORD PTR [rsp+0x28],rdi
  40f618:	cmp    BYTE PTR [r15+0x2c],0xe
  40f61d:	sete   al
  40f620:	mov    r14b,al
  40f623:	jne    40f637 <__swc_fn_23cea7fa_000089_3c530920+0x387>
  40f625:	mov    rcx,rsi
  40f628:	mov    rdx,r15
  40f62b:	call   40c060 <__swc_fn_23cea7fa_000085_e24ecd12>
  40f630:	mov    r14b,al
  40f633:	test   al,al
  40f635:	jne    40f66c <__swc_fn_23cea7fa_000089_3c530920+0x3bc>
  40f637:	cmp    BYTE PTR [r15+0x2c],0x12
  40f63c:	je     40f66c <__swc_fn_23cea7fa_000089_3c530920+0x3bc>
  40f63e:	mov    rcx,r15
  40f641:	mov    rdx,rsi
  40f644:	mov    r8,rdi
  40f647:	mov    r9,r12
  40f64a:	mov    rax,rbx
  40f64d:	movzx  r10d,BYTE PTR [rax]
  40f651:	call   40f1a0 <__swc_fn_23cea7fa_000083_f2d93dad>
  40f656:	test   rax,rax
  40f659:	je     40f66c <__swc_fn_23cea7fa_000089_3c530920+0x3bc>
  40f65b:	add    rsp,0x38
  40f65f:	pop    r15
  40f661:	pop    r14
  40f663:	pop    r13
  40f665:	pop    r12
  40f667:	pop    rdi
  40f668:	pop    rsi
  40f669:	pop    rbx
  40f66a:	pop    rbp
  40f66b:	ret
  40f66c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40f671:	jne    40f690 <__swc_fn_23cea7fa_000089_3c530920+0x3e0>
  40f673:	mov    rax,QWORD PTR [rsi+0xd8]
  40f67a:	test   rax,rax
  40f67d:	je     40f690 <__swc_fn_23cea7fa_000089_3c530920+0x3e0>
  40f67f:	add    rdi,QWORD PTR [rax+0x8]
  40f683:	mov    rax,QWORD PTR [rdi]
  40f686:	sub    rdi,QWORD PTR [rax+0x8]
  40f68a:	mov    rax,QWORD PTR [rax]
  40f68d:	mov    rsi,rax
  40f690:	test   r14b,r14b
  40f693:	je     40f6bf <__swc_fn_23cea7fa_000089_3c530920+0x40f>
  40f695:	mov    rcx,r15
  40f698:	mov    rdx,rsi
  40f69b:	mov    r8,rdi
  40f69e:	mov    r9,r13
  40f6a1:	mov    r14,QWORD PTR [rsp+0x28]
  40f6a6:	mov    r10,r14
  40f6a9:	call   408480 <__swc_fn_23cea7fa_000087_693f118e>
  40f6ae:	add    rsp,0x38
  40f6b2:	pop    r15
  40f6b4:	pop    r14
  40f6b6:	pop    r13
  40f6b8:	pop    r12
  40f6ba:	pop    rdi
  40f6bb:	pop    rsi
  40f6bc:	pop    rbx
  40f6bd:	pop    rbp
  40f6be:	ret
  40f6bf:	mov    rcx,r15
  40f6c2:	mov    rdx,rsi
  40f6c5:	mov    r8,rdi
  40f6c8:	mov    r9,r12
  40f6cb:	movzx  r10d,BYTE PTR [rbx]
  40f6cf:	call   40f1a0 <__swc_fn_23cea7fa_000083_f2d93dad>
  40f6d4:	add    rsp,0x38
  40f6d8:	pop    r15
  40f6da:	pop    r14
  40f6dc:	pop    r13
  40f6de:	pop    r12
  40f6e0:	pop    rdi
  40f6e1:	pop    rsi
  40f6e2:	pop    rbx
  40f6e3:	pop    rbp
  40f6e4:	ret
	...

000000000040f6f0 <__swc_fn_23cea7fa_000092_809deff5>:
  40f6f0:	push   rbx
  40f6f1:	push   rsi
  40f6f2:	sub    rsp,0x18
  40f6f6:	mov    rbx,rcx
  40f6f9:	mov    rcx,QWORD PTR [rip+0x17640]        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  40f700:	test   rcx,rcx
  40f703:	jne    40f715 <__swc_fn_23cea7fa_000092_809deff5+0x25>
  40f705:	call   40a1a0 <__swc_fn_23cea7fa_000165_56054fe7>
  40f70a:	lea    rcx,[rax+0x1]
  40f70e:	mov    QWORD PTR [rip+0x1762b],rcx        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  40f715:	dec    rcx
  40f718:	call   411fa0 <__swc_fn_23cea7fa_000167_39c041ad>
  40f71d:	mov    rsi,rax
  40f720:	mov    rax,QWORD PTR [rsi+0x8]
  40f724:	test   rax,rax
  40f727:	jne    40f777 <__swc_fn_23cea7fa_000092_809deff5+0x87>
  40f729:	call   40c150 <__swc_fn_23cea7fa_000091_f21926ed>
  40f72e:	test   al,al
  40f730:	jne    40f777 <__swc_fn_23cea7fa_000092_809deff5+0x87>
  40f732:	lea    rdx,[rip+0x14b07]        # 424240 <__swc_bss_base_23cea7fa+0x200>
  40f739:	mov    rcx,rdx
  40f73c:	call   407740 <__swc_fn_23cea7fa_000036_290a131c>
  40f741:	test   al,al
  40f743:	jne    40f754 <__swc_fn_23cea7fa_000092_809deff5+0x64>
  40f745:	mov    rcx,rdx
  40f748:	call   40aa40 <__swc_fn_23cea7fa_000034_cf5ba7bd>
  40f74d:	lea    rdx,[rip+0x14aec]        # 424240 <__swc_bss_base_23cea7fa+0x200>
  40f754:	mov    QWORD PTR [rsp+0x8],rdx
  40f759:	lea    rax,[rip+0x39f0]        # 413150 <__swc_rdata_base_23cea7fa+0x40>
  40f760:	mov    QWORD PTR [rsp+0x10],rax
  40f765:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f76b:	vmovups XMMWORD PTR [rsi],xmm0
  40f76f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40f777:	vmovups xmm0,XMMWORD PTR [rsi]
  40f77b:	vmovups XMMWORD PTR [rbx],xmm0
  40f77f:	mov    rax,rbx
  40f782:	add    rsp,0x18
  40f786:	pop    rsi
  40f787:	pop    rbx
  40f788:	ret
  40f789:	add    BYTE PTR [rax],al
  40f78b:	add    BYTE PTR [rax],al
  40f78d:	add    BYTE PTR [rax],al
	...

000000000040f790 <__swc_fn_23cea7fa_000095_8cc4b392>:
  40f790:	sub    rsp,0x8
  40f794:	call   409340 <__swc_fn_23cea7fa_000117_5aba1420>
  40f799:	add    rsp,0x8
  40f79d:	ret
	...

000000000040f7a0 <__swc_fn_23cea7fa_000098_f82a1ed3>:
  40f7a0:	push   rbx
  40f7a1:	push   rsi
  40f7a2:	sub    rsp,0x28
  40f7a6:	mov    rbx,rcx
  40f7a9:	xor    esi,esi
  40f7ab:	jmp    40f7c0 <__swc_fn_23cea7fa_000098_f82a1ed3+0x20>
  40f7ad:	nop    DWORD PTR [rax]
  40f7b0:	mov    QWORD PTR [rbx+0x28],rsi
  40f7b4:	mov    rsi,rbx
  40f7b7:	mov    rbx,rax
  40f7ba:	nop    WORD PTR [rax+rax*1+0x0]
  40f7c0:	test   rbx,rbx
  40f7c3:	je     40f823 <__swc_fn_23cea7fa_000098_f82a1ed3+0x83>
  40f7c5:	mov    rcx,rbx
  40f7c8:	mov    edx,0x1
  40f7cd:	call   408200 <__swc_fn_23cea7fa_000078_140918ec>
  40f7d2:	cmp    rax,0x1
  40f7d6:	jne    40f823 <__swc_fn_23cea7fa_000098_f82a1ed3+0x83>
  40f7d8:	mov    r10,QWORD PTR [rbx+0x18]
  40f7dc:	mov    rcx,r10
  40f7df:	mov    edx,0x1
  40f7e4:	call   408200 <__swc_fn_23cea7fa_000078_140918ec>
  40f7e9:	cmp    rax,0x1
  40f7ed:	jne    40f7fc <__swc_fn_23cea7fa_000098_f82a1ed3+0x5c>
  40f7ef:	mov    rcx,r10
  40f7f2:	call   40c2f0 <__swc_fn_23cea7fa_000097_96d6739a>
  40f7f7:	test   rax,rax
  40f7fa:	jne    40f7b0 <__swc_fn_23cea7fa_000098_f82a1ed3+0x10>
  40f7fc:	mov    rax,QWORD PTR [rbx+0x20]
  40f800:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40f805:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f80b:	lea    rcx,[rsp+0x8]
  40f810:	mov    rdx,rbx
  40f813:	mov    r8d,0x30
  40f819:	mov    rbx,rax
  40f81c:	call   408960 <__swc_fn_23cea7fa_000096_a4baaa40>
  40f821:	jmp    40f7c0 <__swc_fn_23cea7fa_000098_f82a1ed3+0x20>
  40f823:	test   rsi,rsi
  40f826:	jne    40f82f <__swc_fn_23cea7fa_000098_f82a1ed3+0x8f>
  40f828:	add    rsp,0x28
  40f82c:	pop    rsi
  40f82d:	pop    rbx
  40f82e:	ret
  40f82f:	mov    rax,rsi
  40f832:	mov    rsi,QWORD PTR [rsi+0x28]
  40f836:	mov    rbx,QWORD PTR [rax+0x20]
  40f83a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40f83f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f845:	lea    rcx,[rsp+0x18]
  40f84a:	mov    rdx,rax
  40f84d:	mov    r8d,0x30
  40f853:	call   408960 <__swc_fn_23cea7fa_000096_a4baaa40>
  40f858:	jmp    40f7c0 <__swc_fn_23cea7fa_000098_f82a1ed3+0x20>
  40f85d:	add    BYTE PTR [rax],al
	...

000000000040f860 <__swc_fn_23cea7fa_000101_afcb7774>:
  40f860:	push   rbx
  40f861:	push   rsi
  40f862:	push   rdi
  40f863:	push   r12
  40f865:	push   r13
  40f867:	sub    rsp,0x20
  40f86b:	mov    rbx,rcx
  40f86e:	lea    rsi,[rcx+0x6f8]
  40f875:	mov    edi,0x4
  40f87a:	mov    r12,rsi
  40f87d:	test   rdi,rdi
  40f880:	je     40f8ca <__swc_fn_23cea7fa_000101_afcb7774+0x6a>
  40f882:	cs nop WORD PTR [rax+rax*1+0x0]
  40f88c:	nop    DWORD PTR [rax+0x0]
  40f890:	mov    rcx,QWORD PTR [r12+0x10]
  40f895:	mov    QWORD PTR [r12+0x10],0x0
  40f89e:	vxorps xmm0,xmm0,xmm0
  40f8a2:	vmovups XMMWORD PTR [r12],xmm0
  40f8a8:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40f8af:	mov    DWORD PTR [r12+0x20],0x0
  40f8b8:	call   4089b0 <__swc_fn_23cea7fa_000099_5232b57d>
  40f8bd:	add    r12,0x90
  40f8c4:	sub    rdi,0x1
  40f8c8:	jne    40f890 <__swc_fn_23cea7fa_000101_afcb7774+0x30>
  40f8ca:	mov    rax,QWORD PTR [rbx+0x938]
  40f8d1:	mov    rdi,rax
  40f8d4:	test   rdi,rdi
  40f8d7:	je     40f931 <__swc_fn_23cea7fa_000101_afcb7774+0xd1>
  40f8d9:	nop    DWORD PTR [rax+0x0]
  40f8e0:	mov    r12d,0x10
  40f8e6:	lea    r13,[rdi+0x18]
  40f8ea:	test   r12,r12
  40f8ed:	je     40f926 <__swc_fn_23cea7fa_000101_afcb7774+0xc6>
  40f8ef:	nop
  40f8f0:	mov    rcx,QWORD PTR [r13+0x10]
  40f8f4:	mov    QWORD PTR [r13+0x10],0x0
  40f8fc:	vxorps xmm0,xmm0,xmm0
  40f900:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40f906:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40f90c:	mov    DWORD PTR [r13+0x20],0x0
  40f914:	call   4089b0 <__swc_fn_23cea7fa_000099_5232b57d>
  40f919:	add    r13,0x90
  40f920:	sub    r12,0x1
  40f924:	jne    40f8f0 <__swc_fn_23cea7fa_000101_afcb7774+0x90>
  40f926:	mov    rax,QWORD PTR [rdi]
  40f929:	mov    rdi,rax
  40f92c:	test   rax,rax
  40f92f:	jne    40f8e0 <__swc_fn_23cea7fa_000101_afcb7774+0x80>
  40f931:	vxorps xmm0,xmm0,xmm0
  40f935:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40f93d:	mov    DWORD PTR [rbx+0x9b0],0x0
  40f947:	mov    DWORD PTR [rbx+0x9a8],0x0
  40f951:	mov    edi,0x4
  40f956:	mov    r12,rsi
  40f959:	lea    rsi,[rsi+0x38]
  40f95d:	test   rdi,rdi
  40f960:	je     40f98c <__swc_fn_23cea7fa_000101_afcb7774+0x12c>
  40f962:	cs nop WORD PTR [rax+rax*1+0x0]
  40f96c:	nop    DWORD PTR [rax+0x0]
  40f970:	mov    rcx,rsi
  40f973:	call   40d170 <__swc_fn_23cea7fa_000157_3495a3ca>
  40f978:	add    rsi,0x90
  40f97f:	add    r12,0x90
  40f986:	sub    rdi,0x1
  40f98a:	jne    40f970 <__swc_fn_23cea7fa_000101_afcb7774+0x110>
  40f98c:	mov    rax,QWORD PTR [rbx+0x938]
  40f993:	mov    rdi,rax
  40f996:	mov    QWORD PTR [rbx+0x938],0x0
  40f9a1:	test   rdi,rdi
  40f9a4:	je     40fa15 <__swc_fn_23cea7fa_000101_afcb7774+0x1b5>
  40f9aa:	nop    WORD PTR [rax+rax*1+0x0]
  40f9b0:	mov    esi,0x10
  40f9b5:	lea    r12,[rdi+0x18]
  40f9b9:	lea    r13,[rdi+0x50]
  40f9bd:	test   rsi,rsi
  40f9c0:	je     40f9ec <__swc_fn_23cea7fa_000101_afcb7774+0x18c>
  40f9c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f9cc:	nop    DWORD PTR [rax+0x0]
  40f9d0:	mov    rcx,r13
  40f9d3:	call   40d170 <__swc_fn_23cea7fa_000157_3495a3ca>
  40f9d8:	add    r13,0x90
  40f9df:	add    r12,0x90
  40f9e6:	sub    rsi,0x1
  40f9ea:	jne    40f9d0 <__swc_fn_23cea7fa_000101_afcb7774+0x170>
  40f9ec:	mov    rax,QWORD PTR [rdi]
  40f9ef:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40f9f4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f9fa:	lea    rcx,[rsp+0x8]
  40f9ff:	mov    rdx,rdi
  40fa02:	mov    r8d,0x918
  40fa08:	mov    rdi,rax
  40fa0b:	call   408960 <__swc_fn_23cea7fa_000096_a4baaa40>
  40fa10:	test   rdi,rdi
  40fa13:	jne    40f9b0 <__swc_fn_23cea7fa_000101_afcb7774+0x150>
  40fa15:	lea    rcx,[rbx+0x68]
  40fa19:	call   40d170 <__swc_fn_23cea7fa_000157_3495a3ca>
  40fa1e:	add    rsp,0x20
  40fa22:	pop    r13
  40fa24:	pop    r12
  40fa26:	pop    rdi
  40fa27:	pop    rsi
  40fa28:	pop    rbx
  40fa29:	ret
  40fa2a:	add    BYTE PTR [rax],al
  40fa2c:	add    BYTE PTR [rax],al
	...

000000000040fa30 <__swc_fn_23cea7fa_000104_04d1a8be>:
  40fa30:	xor    eax,eax
  40fa32:	cs nop WORD PTR [rax+rax*1+0x0]
  40fa3c:	nop    DWORD PTR [rax+0x0]
  40fa40:	mov    r9,r8
  40fa43:	sub    r9,rax
  40fa46:	cmp    r9,0x40
  40fa4a:	jb     40fa88 <__swc_fn_23cea7fa_000104_04d1a8be+0x58>
  40fa4c:	lea    r9,[rcx+rax*1]
  40fa50:	lea    r10,[rdx+rax*1]
  40fa54:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40fa5a:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40fa60:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40fa66:	vmovups xmm3,XMMWORD PTR [r10]
  40fa6b:	vmovups XMMWORD PTR [r9],xmm3
  40fa70:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40fa76:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40fa7c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40fa82:	lea    rax,[rax+0x40]
  40fa86:	jmp    40fa40 <__swc_fn_23cea7fa_000104_04d1a8be+0x10>
  40fa88:	nop    DWORD PTR [rax+rax*1+0x0]
  40fa90:	mov    r9,r8
  40fa93:	sub    r9,rax
  40fa96:	cmp    r9,0x10
  40fa9a:	jb     40fab4 <__swc_fn_23cea7fa_000104_04d1a8be+0x84>
  40fa9c:	lea    r9,[rdx+rax*1]
  40faa0:	lea    r10,[rcx+rax*1]
  40faa4:	vmovups xmm0,XMMWORD PTR [r9]
  40faa9:	vmovups XMMWORD PTR [r10],xmm0
  40faae:	lea    rax,[rax+0x10]
  40fab2:	jmp    40fa90 <__swc_fn_23cea7fa_000104_04d1a8be+0x60>
  40fab4:	cs nop WORD PTR [rax+rax*1+0x0]
  40fabe:	xchg   ax,ax
  40fac0:	mov    r9,r8
  40fac3:	sub    r9,rax
  40fac6:	cmp    r9,0x8
  40faca:	jb     40fadd <__swc_fn_23cea7fa_000104_04d1a8be+0xad>
  40facc:	lea    r9,[rcx+rax*1]
  40fad0:	mov    r10,QWORD PTR [rdx+rax*1]
  40fad4:	mov    QWORD PTR [r9],r10
  40fad7:	lea    rax,[rax+0x8]
  40fadb:	jmp    40fac0 <__swc_fn_23cea7fa_000104_04d1a8be+0x90>
  40fadd:	cmp    rax,r8
  40fae0:	jae    40fb00 <__swc_fn_23cea7fa_000104_04d1a8be+0xd0>
  40fae2:	cs nop WORD PTR [rax+rax*1+0x0]
  40faec:	nop    DWORD PTR [rax+0x0]
  40faf0:	mov    r9b,BYTE PTR [rdx+rax*1]
  40faf4:	mov    BYTE PTR [rcx+rax*1],r9b
  40faf8:	inc    rax
  40fafb:	cmp    rax,r8
  40fafe:	jb     40faf0 <__swc_fn_23cea7fa_000104_04d1a8be+0xc0>
  40fb00:	ret
	...

000000000040fb10 <__swc_fn_23cea7fa_000107_c8d4a68e>:
  40fb10:	push   rbx
  40fb11:	push   r12
  40fb13:	push   rdi
  40fb14:	push   rsi
  40fb15:	push   r13
  40fb17:	push   r14
  40fb19:	push   r15
  40fb1b:	sub    rsp,0x170
  40fb22:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40fb2b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40fb34:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40fb3d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40fb46:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40fb4f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40fb58:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40fb61:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40fb6a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40fb73:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40fb7c:	mov    ebx,edx
  40fb7e:	mov    QWORD PTR [rsp+0xa8],rbx
  40fb86:	mov    r12d,ecx
  40fb89:	test   edx,edx
  40fb8b:	jne    40fba2 <__swc_fn_23cea7fa_000107_c8d4a68e+0x92>
  40fb8d:	xor    eax,eax
  40fb8f:	add    rsp,0x170
  40fb96:	pop    r15
  40fb98:	pop    r14
  40fb9a:	pop    r13
  40fb9c:	pop    rsi
  40fb9d:	pop    rdi
  40fb9e:	pop    r12
  40fba0:	pop    rbx
  40fba1:	ret
  40fba2:	lea    rdi,[rip+0x3907]        # 4134b0 <__swc_rdata_base_23cea7fa+0x3a0>
  40fba9:	mov    esi,0x90000
  40fbae:	xor    eax,eax
  40fbb0:	call   407090 <open@plt>
  40fbb5:	mov    r13,rax
  40fbb8:	mov    QWORD PTR [rsp+0xb0],rax
  40fbc0:	test   eax,eax
  40fbc2:	jge    40fbcb <__swc_fn_23cea7fa_000107_c8d4a68e+0xbb>
  40fbc4:	xor    eax,eax
  40fbc6:	jmp    4100c6 <__swc_fn_23cea7fa_000107_c8d4a68e+0x5b6>
  40fbcb:	nop    DWORD PTR [rax+rax*1+0x0]
  40fbd0:	movsxd rdi,r13d
  40fbd3:	mov    esi,0x2
  40fbd8:	xor    eax,eax
  40fbda:	call   407120 <flock@plt>
  40fbdf:	test   eax,eax
  40fbe1:	je     40fc00 <__swc_fn_23cea7fa_000107_c8d4a68e+0xf0>
  40fbe3:	xor    eax,eax
  40fbe5:	call   407130 <__errno_location@plt>
  40fbea:	cmp    DWORD PTR [rax],0x4
  40fbed:	je     40fbd0 <__swc_fn_23cea7fa_000107_c8d4a68e+0xc0>
  40fbef:	movsxd rdi,r13d
  40fbf2:	xor    eax,eax
  40fbf4:	call   4070b0 <close@plt>
  40fbf9:	xor    eax,eax
  40fbfb:	jmp    4100c6 <__swc_fn_23cea7fa_000107_c8d4a68e+0x5b6>
  40fc00:	lea    r14,[rsp+0x8]
  40fc05:	mov    QWORD PTR [rsp+0xb8],r14
  40fc0d:	vxorps xmm0,xmm0,xmm0
  40fc11:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40fc17:	mov    QWORD PTR [rsp+0x18],0x0
  40fc20:	mov    WORD PTR [rsp+0x20],0x0
  40fc27:	mov    DWORD PTR [r14],0x67617753
  40fc2e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40fc36:	xor    eax,eax
  40fc38:	call   407010 <getpid@plt>
  40fc3d:	mov    ecx,eax
  40fc3f:	mov    eax,0x1c
  40fc44:	shrx   eax,ecx,eax
  40fc49:	and    eax,0xf
  40fc4c:	mov    rdx,QWORD PTR [rip+0x387d]        # 4134d0 <__swc_rdata_base_23cea7fa+0x3c0>
  40fc53:	mov    al,BYTE PTR [rdx+rax*1]
  40fc56:	rex mov BYTE PTR [rsp+0x10],al
  40fc5b:	mov    eax,0x1c
  40fc60:	shrx   eax,r12d,eax
  40fc65:	and    eax,0xf
  40fc68:	mov    al,BYTE PTR [rdx+rax*1]
  40fc6b:	rex mov BYTE PTR [rsp+0x19],al
  40fc70:	mov    eax,0x18
  40fc75:	shrx   eax,ecx,eax
  40fc7a:	and    eax,0xf
  40fc7d:	mov    al,BYTE PTR [rdx+rax*1]
  40fc80:	rex mov BYTE PTR [rsp+0x11],al
  40fc85:	mov    eax,0x18
  40fc8a:	shrx   eax,r12d,eax
  40fc8f:	and    eax,0xf
  40fc92:	mov    al,BYTE PTR [rdx+rax*1]
  40fc95:	rex mov BYTE PTR [rsp+0x1a],al
  40fc9a:	mov    eax,0x14
  40fc9f:	shrx   eax,ecx,eax
  40fca4:	and    eax,0xf
  40fca7:	mov    al,BYTE PTR [rdx+rax*1]
  40fcaa:	rex mov BYTE PTR [rsp+0x12],al
  40fcaf:	mov    eax,0x14
  40fcb4:	shrx   eax,r12d,eax
  40fcb9:	and    eax,0xf
  40fcbc:	mov    al,BYTE PTR [rdx+rax*1]
  40fcbf:	rex mov BYTE PTR [rsp+0x1b],al
  40fcc4:	mov    eax,0x10
  40fcc9:	shrx   eax,ecx,eax
  40fcce:	and    eax,0xf
  40fcd1:	mov    al,BYTE PTR [rdx+rax*1]
  40fcd4:	rex mov BYTE PTR [rsp+0x13],al
  40fcd9:	mov    eax,0x10
  40fcde:	shrx   eax,r12d,eax
  40fce3:	and    eax,0xf
  40fce6:	mov    al,BYTE PTR [rdx+rax*1]
  40fce9:	rex mov BYTE PTR [rsp+0x1c],al
  40fcee:	mov    eax,0xc
  40fcf3:	shrx   eax,ecx,eax
  40fcf8:	and    eax,0xf
  40fcfb:	mov    al,BYTE PTR [rdx+rax*1]
  40fcfe:	rex mov BYTE PTR [rsp+0x14],al
  40fd03:	mov    eax,0xc
  40fd08:	shrx   eax,r12d,eax
  40fd0d:	and    eax,0xf
  40fd10:	mov    al,BYTE PTR [rdx+rax*1]
  40fd13:	rex mov BYTE PTR [rsp+0x1d],al
  40fd18:	mov    eax,0x8
  40fd1d:	shrx   eax,ecx,eax
  40fd22:	and    eax,0xf
  40fd25:	mov    al,BYTE PTR [rdx+rax*1]
  40fd28:	rex mov BYTE PTR [rsp+0x15],al
  40fd2d:	mov    eax,0x8
  40fd32:	shrx   eax,r12d,eax
  40fd37:	and    eax,0xf
  40fd3a:	mov    al,BYTE PTR [rdx+rax*1]
  40fd3d:	rex mov BYTE PTR [rsp+0x1e],al
  40fd42:	mov    eax,0x4
  40fd47:	shrx   eax,ecx,eax
  40fd4c:	and    eax,0xf
  40fd4f:	mov    al,BYTE PTR [rdx+rax*1]
  40fd52:	rex mov BYTE PTR [rsp+0x16],al
  40fd57:	mov    eax,0x4
  40fd5c:	shrx   eax,r12d,eax
  40fd61:	and    eax,0xf
  40fd64:	mov    al,BYTE PTR [rdx+rax*1]
  40fd67:	rex mov BYTE PTR [rsp+0x1f],al
  40fd6c:	xor    eax,eax
  40fd6e:	shrx   eax,ecx,eax
  40fd73:	and    eax,0xf
  40fd76:	mov    al,BYTE PTR [rdx+rax*1]
  40fd79:	rex mov BYTE PTR [rsp+0x17],al
  40fd7e:	xor    eax,eax
  40fd80:	shrx   eax,r12d,eax
  40fd85:	and    eax,0xf
  40fd88:	mov    al,BYTE PTR [rdx+rax*1]
  40fd8b:	rex mov BYTE PTR [rsp+0x20],al
  40fd90:	mov    BYTE PTR [r14+0x10],0x2e
  40fd95:	lea    r12,[rsp+0x22]
  40fd9a:	vxorps xmm0,xmm0,xmm0
  40fd9e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40fda4:	mov    DWORD PTR [r12],0x6d656d2f
  40fdac:	mov    WORD PTR [r12+0x4],0x6466
  40fdb4:	mov    BYTE PTR [r12+0x6],0x3a
  40fdba:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40fdc0:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40fdc6:	mov    rax,QWORD PTR [rsp+0x18]
  40fdcb:	mov    QWORD PTR [rsp+0x39],rax
  40fdd0:	rex mov al,BYTE PTR [rsp+0x20]
  40fdd5:	rex mov BYTE PTR [rsp+0x41],al
  40fdda:	mov    DWORD PTR [r12+0x20],0x65642820
  40fde3:	mov    DWORD PTR [r12+0x24],0x6574656c
  40fdec:	mov    WORD PTR [r12+0x28],0x2964
  40fdf4:	lea    rdi,[rip+0x36c0]        # 4134bb <__swc_rdata_base_23cea7fa+0x3ab>
  40fdfb:	xor    eax,eax
  40fdfd:	call   407140 <opendir@plt>
  40fe02:	mov    r15,rax
  40fe05:	test   rax,rax
  40fe08:	jne    40fe1b <__swc_fn_23cea7fa_000107_c8d4a68e+0x30b>
  40fe0a:	movsxd rdi,r13d
  40fe0d:	xor    eax,eax
  40fe0f:	call   4070b0 <close@plt>
  40fe14:	xor    eax,eax
  40fe16:	jmp    4100c6 <__swc_fn_23cea7fa_000107_c8d4a68e+0x5b6>
  40fe1b:	mov    rdi,r15
  40fe1e:	xor    eax,eax
  40fe20:	call   407150 <dirfd@plt>
  40fe25:	lea    r14,[rsp+0x54]
  40fe2a:	mov    DWORD PTR [rsp+0x54],eax
  40fe2e:	lea    rbx,[rsp+0x58]
  40fe33:	cs nop WORD PTR [rax+rax*1+0x0]
  40fe3d:	nop    DWORD PTR [rax]
  40fe40:	mov    rdi,r15
  40fe43:	xor    eax,eax
  40fe45:	call   407160 <readdir@plt>
  40fe4a:	test   rax,rax
  40fe4d:	jne    40fe64 <__swc_fn_23cea7fa_000107_c8d4a68e+0x354>
  40fe4f:	mov    r12,QWORD PTR [rsp+0xa8]
  40fe57:	mov    r13,QWORD PTR [rsp+0xb0]
  40fe5f:	jmp    40ffea <__swc_fn_23cea7fa_000107_c8d4a68e+0x4da>
  40fe64:	vxorps xmm0,xmm0,xmm0
  40fe68:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  40fe6e:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  40fe74:	vzeroupper
  40fe77:	lea    r13,[rax+0x13]
  40fe7b:	mov    rax,r14
  40fe7e:	movsxd rdi,DWORD PTR [rax]
  40fe81:	mov    rsi,r13
  40fe84:	mov    rdx,rbx
  40fe87:	mov    ecx,0x40
  40fe8c:	xor    eax,eax
  40fe8e:	call   407170 <readlinkat@plt>
  40fe93:	cmp    rax,0x2a
  40fe97:	jne    40fe40 <__swc_fn_23cea7fa_000107_c8d4a68e+0x330>
  40fe99:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40fe9f:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40fea5:	vptest xmm0,xmm0
  40feaa:	jne    40feda <__swc_fn_23cea7fa_000107_c8d4a68e+0x3ca>
  40feac:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40feb2:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40feb8:	vptest xmm0,xmm0
  40febd:	jne    40feda <__swc_fn_23cea7fa_000107_c8d4a68e+0x3ca>
  40febf:	mov    rcx,QWORD PTR [rsp+0x42]
  40fec4:	cmp    QWORD PTR [rsp+0x78],rcx
  40fec9:	jne    40feda <__swc_fn_23cea7fa_000107_c8d4a68e+0x3ca>
  40fecb:	mov    cx,WORD PTR [rsp+0x4a]
  40fed0:	cmp    WORD PTR [rsp+0x80],cx
  40fed8:	je     40ff04 <__swc_fn_23cea7fa_000107_c8d4a68e+0x3f4>
  40feda:	mov    rax,rbx
  40fedd:	mov    rcx,r12
  40fee0:	movzx  edx,BYTE PTR [rax]
  40fee3:	movzx  r8d,BYTE PTR [rcx]
  40fee7:	cmp    rdx,r8
  40feea:	jne    40fef6 <__swc_fn_23cea7fa_000107_c8d4a68e+0x3e6>
  40feec:	add    rax,0x1
  40fef0:	add    rcx,0x1
  40fef4:	jmp    40fee0 <__swc_fn_23cea7fa_000107_c8d4a68e+0x3d0>
  40fef6:	mov    rax,rdx
  40fef9:	sub    rax,r8
  40fefc:	test   eax,eax
  40fefe:	jne    40fe40 <__swc_fn_23cea7fa_000107_c8d4a68e+0x330>
  40ff04:	movsxd rdi,DWORD PTR [r14]
  40ff07:	mov    rsi,r13
  40ff0a:	mov    edx,0x80002
  40ff0f:	xor    eax,eax
  40ff11:	call   407180 <openat@plt>
  40ff16:	lea    rbx,[rsp+0x98]
  40ff1e:	mov    DWORD PTR [rsp+0x98],eax
  40ff25:	test   eax,eax
  40ff27:	mov    r13,QWORD PTR [rsp+0xb0]
  40ff2f:	jge    40ff54 <__swc_fn_23cea7fa_000107_c8d4a68e+0x444>
  40ff31:	mov    rdi,r15
  40ff34:	xor    eax,eax
  40ff36:	call   407190 <closedir@plt>
  40ff3b:	mov    r13,QWORD PTR [rsp+0xb0]
  40ff43:	movsxd rdi,r13d
  40ff46:	xor    eax,eax
  40ff48:	call   4070b0 <close@plt>
  40ff4d:	xor    eax,eax
  40ff4f:	jmp    4100c6 <__swc_fn_23cea7fa_000107_c8d4a68e+0x5b6>
  40ff54:	mov    rax,rbx
  40ff57:	movsxd rdi,DWORD PTR [rax]
  40ff5a:	xor    esi,esi
  40ff5c:	mov    edx,0x2
  40ff61:	xor    eax,eax
  40ff63:	call   4070a0 <lseek@plt>
  40ff68:	mov    r12,QWORD PTR [rsp+0xa8]
  40ff70:	cmp    rax,r12
  40ff73:	je     40ff9a <__swc_fn_23cea7fa_000107_c8d4a68e+0x48a>
  40ff75:	movsxd rdi,DWORD PTR [rbx]
  40ff78:	xor    eax,eax
  40ff7a:	call   4070b0 <close@plt>
  40ff7f:	mov    rdi,r15
  40ff82:	xor    eax,eax
  40ff84:	call   407190 <closedir@plt>
  40ff89:	movsxd rdi,r13d
  40ff8c:	xor    eax,eax
  40ff8e:	call   4070b0 <close@plt>
  40ff93:	xor    eax,eax
  40ff95:	jmp    4100c6 <__swc_fn_23cea7fa_000107_c8d4a68e+0x5b6>
  40ff9a:	xor    edi,edi
  40ff9c:	mov    rsi,r12
  40ff9f:	mov    edx,0x3
  40ffa4:	mov    ecx,0x1
  40ffa9:	mov    rax,rbx
  40ffac:	movsxd r8,DWORD PTR [rax]
  40ffaf:	xor    r9d,r9d
  40ffb2:	xor    eax,eax
  40ffb4:	call   4070c0 <mmap@plt>
  40ffb9:	xor    r12d,r12d
  40ffbc:	cmp    rax,0xffffffffffffffff
  40ffc0:	cmovne r12,rax
  40ffc4:	movsxd rdi,DWORD PTR [rbx]
  40ffc7:	xor    eax,eax
  40ffc9:	call   4070b0 <close@plt>
  40ffce:	mov    rdi,r15
  40ffd1:	xor    eax,eax
  40ffd3:	call   407190 <closedir@plt>
  40ffd8:	movsxd rdi,r13d
  40ffdb:	xor    eax,eax
  40ffdd:	call   4070b0 <close@plt>
  40ffe2:	mov    rax,r12
  40ffe5:	jmp    4100c6 <__swc_fn_23cea7fa_000107_c8d4a68e+0x5b6>
  40ffea:	mov    r14,QWORD PTR [rsp+0xb8]
  40fff2:	mov    rdi,r14
  40fff5:	mov    esi,0x1
  40fffa:	xor    eax,eax
  40fffc:	call   4071a0 <memfd_create@plt>
  410001:	lea    rbx,[rsp+0x9c]
  410009:	mov    DWORD PTR [rsp+0x9c],eax
  410010:	test   eax,eax
  410012:	jge    41002f <__swc_fn_23cea7fa_000107_c8d4a68e+0x51f>
  410014:	mov    rdi,r15
  410017:	xor    eax,eax
  410019:	call   407190 <closedir@plt>
  41001e:	movsxd rdi,r13d
  410021:	xor    eax,eax
  410023:	call   4070b0 <close@plt>
  410028:	xor    eax,eax
  41002a:	jmp    4100c6 <__swc_fn_23cea7fa_000107_c8d4a68e+0x5b6>
  41002f:	mov    rax,rbx
  410032:	movsxd rdi,DWORD PTR [rax]
  410035:	mov    rsi,r12
  410038:	xor    eax,eax
  41003a:	call   4071b0 <ftruncate@plt>
  41003f:	test   eax,eax
  410041:	je     410065 <__swc_fn_23cea7fa_000107_c8d4a68e+0x555>
  410043:	movsxd rdi,DWORD PTR [rbx]
  410046:	xor    eax,eax
  410048:	call   4070b0 <close@plt>
  41004d:	mov    rdi,r15
  410050:	xor    eax,eax
  410052:	call   407190 <closedir@plt>
  410057:	movsxd rdi,r13d
  41005a:	xor    eax,eax
  41005c:	call   4070b0 <close@plt>
  410061:	xor    eax,eax
  410063:	jmp    4100c6 <__swc_fn_23cea7fa_000107_c8d4a68e+0x5b6>
  410065:	xor    edi,edi
  410067:	mov    rsi,r12
  41006a:	mov    edx,0x3
  41006f:	mov    ecx,0x1
  410074:	mov    rax,rbx
  410077:	movsxd r8,DWORD PTR [rax]
  41007a:	xor    r9d,r9d
  41007d:	xor    eax,eax
  41007f:	call   4070c0 <mmap@plt>
  410084:	mov    r12,rax
  410087:	cmp    rax,0xffffffffffffffff
  41008b:	jne    4100af <__swc_fn_23cea7fa_000107_c8d4a68e+0x59f>
  41008d:	movsxd rdi,DWORD PTR [rbx]
  410090:	xor    eax,eax
  410092:	call   4070b0 <close@plt>
  410097:	mov    rdi,r15
  41009a:	xor    eax,eax
  41009c:	call   407190 <closedir@plt>
  4100a1:	movsxd rdi,r13d
  4100a4:	xor    eax,eax
  4100a6:	call   4070b0 <close@plt>
  4100ab:	xor    eax,eax
  4100ad:	jmp    4100c6 <__swc_fn_23cea7fa_000107_c8d4a68e+0x5b6>
  4100af:	mov    rdi,r15
  4100b2:	xor    eax,eax
  4100b4:	call   407190 <closedir@plt>
  4100b9:	movsxd rdi,r13d
  4100bc:	xor    eax,eax
  4100be:	call   4070b0 <close@plt>
  4100c3:	mov    rax,r12
  4100c6:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  4100cf:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  4100d8:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  4100e1:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  4100ea:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  4100f3:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  4100fc:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  410105:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  41010e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  410117:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  410120:	add    rsp,0x170
  410127:	pop    r15
  410129:	pop    r14
  41012b:	pop    r13
  41012d:	pop    rsi
  41012e:	pop    rdi
  41012f:	pop    r12
  410131:	pop    rbx
  410132:	ret
	...

0000000000410140 <__swc_fn_23cea7fa_000110_918d5a21>:
  410140:	push   rsi
  410141:	push   rdi
  410142:	push   r12
  410144:	push   r13
  410146:	sub    rsp,0x8
  41014a:	mov    rsi,r8
  41014d:	mov    rdi,rcx
  410150:	mov    r12,rdx
  410153:	call   409100 <__swc_fn_23cea7fa_000108_b8f4bd15>
  410158:	mov    r13,rax
  41015b:	test   rax,rax
  41015e:	jne    41016b <__swc_fn_23cea7fa_000110_918d5a21+0x2b>
  410160:	add    rsp,0x8
  410164:	pop    r13
  410166:	pop    r12
  410168:	pop    rdi
  410169:	pop    rsi
  41016a:	ret
  41016b:	mov    rcx,r13
  41016e:	call   40cd70 <__swc_fn_23cea7fa_000133_807fd51d>
  410173:	mov    rax,QWORD PTR [r13+0x8]
  410177:	test   rax,rax
  41017a:	je     4101b9 <__swc_fn_23cea7fa_000110_918d5a21+0x79>
  41017c:	nop    DWORD PTR [rax+0x0]
  410180:	lea    rcx,[rax+0x1000]
  410187:	cmp    rdi,rcx
  41018a:	jne    4101b1 <__swc_fn_23cea7fa_000110_918d5a21+0x71>
  41018c:	cmp    r12,0x1000
  410193:	jb     4101b1 <__swc_fn_23cea7fa_000110_918d5a21+0x71>
  410195:	test   sil,sil
  410198:	setne  cl
  41019b:	mov    BYTE PTR [rax+0x10],cl
  41019e:	mov    rcx,r13
  4101a1:	call   4106a0 <__swc_fn_23cea7fa_000134_10472836>
  4101a6:	add    rsp,0x8
  4101aa:	pop    r13
  4101ac:	pop    r12
  4101ae:	pop    rdi
  4101af:	pop    rsi
  4101b0:	ret
  4101b1:	mov    rax,QWORD PTR [rax]
  4101b4:	test   rax,rax
  4101b7:	jne    410180 <__swc_fn_23cea7fa_000110_918d5a21+0x40>
  4101b9:	mov    rcx,r13
  4101bc:	call   4106a0 <__swc_fn_23cea7fa_000134_10472836>
  4101c1:	add    rsp,0x8
  4101c5:	pop    r13
  4101c7:	pop    r12
  4101c9:	pop    rdi
  4101ca:	pop    rsi
  4101cb:	ret
  4101cc:	add    BYTE PTR [rax],al
	...

00000000004101d0 <__swc_fn_23cea7fa_000113_4e83a03a>:
  4101d0:	sub    rsp,0x8
  4101d4:	test   rcx,rcx
  4101d7:	jne    4101de <__swc_fn_23cea7fa_000113_4e83a03a+0xe>
  4101d9:	add    rsp,0x8
  4101dd:	ret
  4101de:	call   40c880 <__swc_fn_23cea7fa_000115_3f6af4b1>
  4101e3:	add    rsp,0x8
  4101e7:	ret
	...

00000000004101f0 <__swc_fn_23cea7fa_000116_3f5cfdef>:
  4101f0:	push   r12
  4101f2:	push   r13
  4101f4:	push   r14
  4101f6:	push   rdi
  4101f7:	push   rsi
  4101f8:	sub    rsp,0xc0
  4101ff:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  410205:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  41020b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  410211:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410217:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  41021d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  410223:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410229:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  410232:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  41023b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  410244:	mov    r12,QWORD PTR [rcx]
  410247:	test   r12,r12
  41024a:	jne    41025c <__swc_fn_23cea7fa_000116_3f5cfdef+0x6c>
  41024c:	add    rsp,0xc0
  410253:	pop    rsi
  410254:	pop    rdi
  410255:	pop    r14
  410257:	pop    r13
  410259:	pop    r12
  41025b:	ret
  41025c:	xor    r13d,r13d
  41025f:	mov    r14,QWORD PTR [rcx+0x8]
  410263:	cs nop WORD PTR [rax+rax*1+0x0]
  41026d:	nop    DWORD PTR [rax]
  410270:	cmp    r13,r14
  410273:	jae    4102ab <__swc_fn_23cea7fa_000116_3f5cfdef+0xbb>
  410275:	lea    rax,[r12+r13*1]
  410279:	mov    rcx,r14
  41027c:	sub    rcx,r13
  41027f:	mov    edi,0x1
  410284:	mov    rsi,rax
  410287:	mov    rdx,rcx
  41028a:	xor    eax,eax
  41028c:	call   4071c0 <write@plt>
  410291:	test   rax,rax
  410294:	jle    41029b <__swc_fn_23cea7fa_000116_3f5cfdef+0xab>
  410296:	add    r13,rax
  410299:	jmp    410270 <__swc_fn_23cea7fa_000116_3f5cfdef+0x80>
  41029b:	je     4102a9 <__swc_fn_23cea7fa_000116_3f5cfdef+0xb9>
  41029d:	xor    eax,eax
  41029f:	call   407130 <__errno_location@plt>
  4102a4:	cmp    DWORD PTR [rax],0x4
  4102a7:	je     410270 <__swc_fn_23cea7fa_000116_3f5cfdef+0x80>
  4102a9:	jmp    4102ab <__swc_fn_23cea7fa_000116_3f5cfdef+0xbb>
  4102ab:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4102b1:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4102b7:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4102bd:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4102c3:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4102c9:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4102cf:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4102d5:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4102de:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4102e7:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4102f0:	add    rsp,0xc0
  4102f7:	pop    rsi
  4102f8:	pop    rdi
  4102f9:	pop    r14
  4102fb:	pop    r13
  4102fd:	pop    r12
  4102ff:	ret

0000000000410300 <__swc_fn_23cea7fa_000119_2d9caf16>:
  410300:	push   rbx
  410301:	push   r12
  410303:	push   rdi
  410304:	push   rsi
  410305:	sub    rsp,0x4a8
  41030c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  410315:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  41031e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  410327:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  410330:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  410339:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  410342:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  41034b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  410354:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  41035d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  410366:	mov    rbx,rdx
  410369:	mov    r12d,ecx
  41036c:	vxorps xmm0,xmm0,xmm0
  410370:	xor    eax,eax
  410372:	cs nop WORD PTR [rax+rax*1+0x0]
  41037c:	nop    DWORD PTR [rax+0x0]
  410380:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  410386:	add    rax,0x10
  41038a:	cmp    rax,0x400
  410391:	jne    410380 <__swc_fn_23cea7fa_000119_2d9caf16+0x80>
  410393:	lea    rdi,[rsp+0x8]
  410398:	mov    esi,0x80
  41039d:	xor    eax,eax
  41039f:	call   4071d0 <backtrace@plt>
  4103a4:	test   eax,eax
  4103a6:	jle    4103b5 <__swc_fn_23cea7fa_000119_2d9caf16+0xb5>
  4103a8:	movsxd rax,eax
  4103ab:	lea    rcx,[r12+0x1]
  4103b0:	cmp    rcx,rax
  4103b3:	jb     4103b9 <__swc_fn_23cea7fa_000119_2d9caf16+0xb9>
  4103b5:	xor    eax,eax
  4103b7:	jmp    4103ea <__swc_fn_23cea7fa_000119_2d9caf16+0xea>
  4103b9:	mov    rcx,QWORD PTR [rbx+0x8]
  4103bd:	sub    rax,r12
  4103c0:	lea    rsi,[rax-0x1]
  4103c4:	cmp    rcx,rsi
  4103c7:	cmovbe rsi,rcx
  4103cb:	lea    eax,[r12+0x1]
  4103d0:	lea    rax,[rsp+rax*8+0x8]
  4103d5:	mov    rcx,QWORD PTR [rbx]
  4103d8:	mov    rdx,rax
  4103db:	lea    r8,[rsi*8+0x0]
  4103e3:	call   4090e0 <__swc_fn_23cea7fa_000105_83487ba1>
  4103e8:	mov    eax,esi
  4103ea:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  4103f3:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  4103fc:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  410405:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  41040e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  410417:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  410420:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  410429:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  410432:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  41043b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  410444:	add    rsp,0x4a8
  41044b:	pop    rsi
  41044c:	pop    rdi
  41044d:	pop    r12
  41044f:	pop    rbx
  410450:	ret
	...

0000000000410460 <__swc_fn_23cea7fa_000122_66e5d2a9>:
  410460:	mov    QWORD PTR [rcx],0x0
  410467:	ret
	...

0000000000410470 <__swc_fn_23cea7fa_000125_7a81492f>:
  410470:	push   rdi
  410471:	push   rsi
  410472:	sub    rsp,0xa8
  410479:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41047f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410485:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41048b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410491:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410497:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41049d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4104a3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4104a9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4104b2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4104bb:	mov    edi,ecx
  4104bd:	mov    rsi,rdx
  4104c0:	xor    eax,eax
  4104c2:	call   407060 <pthread_setspecific@plt>
  4104c7:	test   eax,eax
  4104c9:	sete   al
  4104cc:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4104d2:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4104d8:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4104de:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4104e4:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4104ea:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4104f0:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4104f6:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4104fc:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410505:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41050e:	add    rsp,0xa8
  410515:	pop    rsi
  410516:	pop    rdi
  410517:	ret
	...

0000000000410520 <__swc_fn_23cea7fa_000128_8d8a7dd2>:
  410520:	push   rdi
  410521:	push   rsi
  410522:	sub    rsp,0xa8
  410529:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41052f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410535:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41053b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410541:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410547:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41054d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410553:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410559:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410562:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41056b:	test   rcx,rcx
  41056e:	je     410581 <__swc_fn_23cea7fa_000128_8d8a7dd2+0x61>
  410570:	lea    rax,[rcx-0x1]
  410574:	mov    eax,eax
  410576:	mov    edi,eax
  410578:	xor    eax,eax
  41057a:	call   407000 <pthread_getspecific@plt>
  41057f:	jmp    410583 <__swc_fn_23cea7fa_000128_8d8a7dd2+0x63>
  410581:	xor    eax,eax
  410583:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410589:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  41058f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410595:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41059b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4105a1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4105a7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4105ad:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4105b3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4105bc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4105c5:	add    rsp,0xa8
  4105cc:	pop    rsi
  4105cd:	pop    rdi
  4105ce:	ret
	...

00000000004105d0 <__swc_fn_23cea7fa_000131_91db8856>:
  4105d0:	push   rdi
  4105d1:	push   rsi
  4105d2:	sub    rsp,0xb8
  4105d9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4105df:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4105e5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4105eb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4105f1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4105f7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4105fd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410603:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41060c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410615:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41061e:	vxorps xmm0,xmm0,xmm0
  410622:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410628:	mov    edi,0x1
  41062d:	lea    rsi,[rsp+0x8]
  410632:	xor    eax,eax
  410634:	call   4070e0 <clock_gettime@plt>
  410639:	mov    rax,QWORD PTR [rsp+0x8]
  41063e:	imul   rax,rax,0x3b9aca00
  410645:	add    rax,QWORD PTR [rsp+0x10]
  41064a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410650:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  410656:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  41065c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  410662:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410668:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  41066e:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  410674:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  41067d:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  410686:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  41068f:	add    rsp,0xb8
  410696:	pop    rsi
  410697:	pop    rdi
  410698:	ret
  410699:	add    BYTE PTR [rax],al
  41069b:	add    BYTE PTR [rax],al
  41069d:	add    BYTE PTR [rax],al
	...

00000000004106a0 <__swc_fn_23cea7fa_000134_10472836>:
  4106a0:	sub    rsp,0x8
  4106a4:	xor    eax,eax
  4106a6:	mov    DWORD PTR [rcx],eax
  4106a8:	mov    edx,0x7fffffff
  4106ad:	call   4097e0 <__swc_fn_23cea7fa_000132_51cc49e7>
  4106b2:	add    rsp,0x8
  4106b6:	ret
	...

00000000004106c0 <__swc_fn_23cea7fa_000137_2d595cc7>:
  4106c0:	push   rdi
  4106c1:	push   rsi
  4106c2:	sub    rsp,0xb8
  4106c9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4106cf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4106d5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4106db:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4106e1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4106e7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4106ed:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4106f3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4106fc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410705:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41070e:	mov    edi,0x1
  410713:	xor    eax,eax
  410715:	call   4071e0 <__x86_get_cpuid_feature_leaf@plt>
  41071a:	mov    eax,DWORD PTR [rax+0x14]
  41071d:	and    eax,0x20
  410720:	setne  al
  410723:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410729:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  41072f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410735:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41073b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410741:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  410747:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41074d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  410756:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  41075f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410768:	add    rsp,0xb8
  41076f:	pop    rsi
  410770:	pop    rdi
  410771:	ret
	...

0000000000410780 <__swc_fn_23cea7fa_000140_55003b6d>:
  410780:	push   rsi
  410781:	push   rdi
  410782:	push   r12
  410784:	push   r13
  410786:	push   r14
  410788:	push   r15
  41078a:	cmp    rdx,0x40
  41078e:	jae    41079d <__swc_fn_23cea7fa_000140_55003b6d+0x1d>
  410790:	xor    eax,eax
  410792:	pop    r15
  410794:	pop    r14
  410796:	pop    r13
  410798:	pop    r12
  41079a:	pop    rdi
  41079b:	pop    rsi
  41079c:	ret
  41079d:	cmp    BYTE PTR [rcx],0x7f
  4107a0:	jne    4107e4 <__swc_fn_23cea7fa_000140_55003b6d+0x64>
  4107a2:	movzx  eax,BYTE PTR [rcx+0x1]
  4107a6:	cmp    eax,0x45
  4107a9:	setne  al
  4107ac:	jne    4107e0 <__swc_fn_23cea7fa_000140_55003b6d+0x60>
  4107ae:	movzx  eax,BYTE PTR [rcx+0x2]
  4107b2:	cmp    eax,0x4c
  4107b5:	setne  al
  4107b8:	jne    4107e0 <__swc_fn_23cea7fa_000140_55003b6d+0x60>
  4107ba:	movzx  eax,BYTE PTR [rcx+0x3]
  4107be:	cmp    eax,0x46
  4107c1:	setne  al
  4107c4:	jne    4107e0 <__swc_fn_23cea7fa_000140_55003b6d+0x60>
  4107c6:	cmp    BYTE PTR [rcx+0x4],0x2
  4107ca:	setne  al
  4107cd:	jne    4107e0 <__swc_fn_23cea7fa_000140_55003b6d+0x60>
  4107cf:	cmp    BYTE PTR [rcx+0x5],0x1
  4107d3:	setne  al
  4107d6:	jne    4107e0 <__swc_fn_23cea7fa_000140_55003b6d+0x60>
  4107d8:	cmp    WORD PTR [rcx+0x12],0x3e
  4107dd:	setne  al
  4107e0:	test   al,al
  4107e2:	je     4107f1 <__swc_fn_23cea7fa_000140_55003b6d+0x71>
  4107e4:	xor    eax,eax
  4107e6:	pop    r15
  4107e8:	pop    r14
  4107ea:	pop    r13
  4107ec:	pop    r12
  4107ee:	pop    rdi
  4107ef:	pop    rsi
  4107f0:	ret
  4107f1:	cmp    WORD PTR [rcx+0x3a],0x40
  4107f6:	jne    410811 <__swc_fn_23cea7fa_000140_55003b6d+0x91>
  4107f8:	cmp    WORD PTR [rcx+0x3c],0x0
  4107fd:	sete   al
  410800:	je     41080d <__swc_fn_23cea7fa_000140_55003b6d+0x8d>
  410802:	mov    ax,WORD PTR [rcx+0x3c]
  410806:	cmp    WORD PTR [rcx+0x3e],ax
  41080a:	setae  al
  41080d:	test   al,al
  41080f:	je     41081e <__swc_fn_23cea7fa_000140_55003b6d+0x9e>
  410811:	xor    eax,eax
  410813:	pop    r15
  410815:	pop    r14
  410817:	pop    r13
  410819:	pop    r12
  41081b:	pop    rdi
  41081c:	pop    rsi
  41081d:	ret
  41081e:	movzx  eax,WORD PTR [rcx+0x3c]
  410822:	shl    rax,0x6
  410826:	cmp    rax,rdx
  410829:	ja     410837 <__swc_fn_23cea7fa_000140_55003b6d+0xb7>
  41082b:	mov    r9,rdx
  41082e:	sub    r9,rax
  410831:	cmp    QWORD PTR [rcx+0x28],r9
  410835:	jbe    410844 <__swc_fn_23cea7fa_000140_55003b6d+0xc4>
  410837:	xor    eax,eax
  410839:	pop    r15
  41083b:	pop    r14
  41083d:	pop    r13
  41083f:	pop    r12
  410841:	pop    rdi
  410842:	pop    rsi
  410843:	ret
  410844:	mov    rax,QWORD PTR [rcx+0x28]
  410848:	add    rax,rcx
  41084b:	movzx  r9d,WORD PTR [rcx+0x3e]
  410850:	lea    r9,[r9*8+0x0]
  410858:	lea    r10,[rax+r9*8]
  41085c:	cmp    QWORD PTR [r10+0x20],rdx
  410860:	ja     410882 <__swc_fn_23cea7fa_000140_55003b6d+0x102>
  410862:	mov    r11,rdx
  410865:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  41086a:	cmp    QWORD PTR [r10+0x18],r11
  41086e:	seta   r9b
  410872:	ja     41087d <__swc_fn_23cea7fa_000140_55003b6d+0xfd>
  410874:	cmp    QWORD PTR [r10+0x20],0x9
  410879:	setb   r9b
  41087d:	test   r9b,r9b
  410880:	je     41088f <__swc_fn_23cea7fa_000140_55003b6d+0x10f>
  410882:	xor    eax,eax
  410884:	pop    r15
  410886:	pop    r14
  410888:	pop    r13
  41088a:	pop    r12
  41088c:	pop    rdi
  41088d:	pop    rsi
  41088e:	ret
  41088f:	movzx  r9d,WORD PTR [rcx+0x3c]
  410894:	xor    r11d,r11d
  410897:	test   r9,r9
  41089a:	jbe    410995 <__swc_fn_23cea7fa_000140_55003b6d+0x215>
  4108a0:	mov    rsi,QWORD PTR [r10+0x20]
  4108a4:	sub    rsi,0x9
  4108a8:	cs nop WORD PTR [rax+rax*1+0x0]
  4108b2:	cs nop WORD PTR [rax+rax*1+0x0]
  4108bc:	nop    DWORD PTR [rax+0x0]
  4108c0:	movzx  edi,r11w
  4108c4:	lea    rdi,[rdi*8+0x0]
  4108cc:	lea    r12,[rax+rdi*8]
  4108d0:	rex mov edi,DWORD PTR [rax+rdi*8]
  4108d4:	cmp    rdi,rsi
  4108d7:	ja     410988 <__swc_fn_23cea7fa_000140_55003b6d+0x208>
  4108dd:	mov    r13,QWORD PTR [r10+0x18]
  4108e1:	add    r13,rdi
  4108e4:	lea    rdi,[rcx+r13*1]
  4108e8:	lea    r13,[rip+0x2c41]        # 413530 <__swc_rdata_base_23cea7fa+0x420>
  4108ef:	movabs r14,0x676264676177732e
  4108f9:	cmp    QWORD PTR [rdi],r14
  4108fc:	jne    410905 <__swc_fn_23cea7fa_000140_55003b6d+0x185>
  4108fe:	rex cmp BYTE PTR [rdi+0x8],0x0
  410903:	je     410932 <__swc_fn_23cea7fa_000140_55003b6d+0x1b2>
  410905:	cs nop WORD PTR [rax+rax*1+0x0]
  41090f:	nop
  410910:	movzx  r14d,BYTE PTR [rdi]
  410914:	movzx  r15d,BYTE PTR [r13+0x0]
  410919:	cmp    r14,r15
  41091c:	jne    410928 <__swc_fn_23cea7fa_000140_55003b6d+0x1a8>
  41091e:	add    rdi,0x1
  410922:	add    r13,0x1
  410926:	jmp    410910 <__swc_fn_23cea7fa_000140_55003b6d+0x190>
  410928:	mov    rdi,r14
  41092b:	sub    rdi,r15
  41092e:	test   edi,edi
  410930:	jne    410988 <__swc_fn_23cea7fa_000140_55003b6d+0x208>
  410932:	cmp    DWORD PTR [r12+0x4],0x1
  410938:	jne    410960 <__swc_fn_23cea7fa_000140_55003b6d+0x1e0>
  41093a:	cmp    QWORD PTR [r12+0x20],0x10
  410940:	setb   al
  410943:	jb     41095c <__swc_fn_23cea7fa_000140_55003b6d+0x1dc>
  410945:	cmp    QWORD PTR [r12+0x20],rdx
  41094a:	seta   al
  41094d:	ja     41095c <__swc_fn_23cea7fa_000140_55003b6d+0x1dc>
  41094f:	sub    rdx,QWORD PTR [r12+0x20]
  410954:	cmp    QWORD PTR [r12+0x18],rdx
  410959:	seta   al
  41095c:	test   al,al
  41095e:	je     41096d <__swc_fn_23cea7fa_000140_55003b6d+0x1ed>
  410960:	xor    eax,eax
  410962:	pop    r15
  410964:	pop    r14
  410966:	pop    r13
  410968:	pop    r12
  41096a:	pop    rdi
  41096b:	pop    rsi
  41096c:	ret
  41096d:	mov    rax,QWORD PTR [r12+0x20]
  410972:	mov    QWORD PTR [r8],rax
  410975:	mov    rax,QWORD PTR [r12+0x18]
  41097a:	add    rax,rcx
  41097d:	pop    r15
  41097f:	pop    r14
  410981:	pop    r13
  410983:	pop    r12
  410985:	pop    rdi
  410986:	pop    rsi
  410987:	ret
  410988:	add    r11,0x1
  41098c:	cmp    r11,r9
  41098f:	jb     4108c0 <__swc_fn_23cea7fa_000140_55003b6d+0x140>
  410995:	xor    eax,eax
  410997:	pop    r15
  410999:	pop    r14
  41099b:	pop    r13
  41099d:	pop    r12
  41099f:	pop    rdi
  4109a0:	pop    rsi
  4109a1:	ret
	...

00000000004109b0 <__swc_fn_23cea7fa_000143_b7ad855f>:
  4109b0:	push   rdi
  4109b1:	push   rsi
  4109b2:	sub    rsp,0xa8
  4109b9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4109bf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4109c5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4109cb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4109d1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4109d7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4109dd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4109e3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4109e9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4109f2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4109fb:	mov    rdi,rcx
  4109fe:	xor    eax,eax
  410a00:	call   4071f0 <free@plt>
  410a05:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410a0b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410a11:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410a17:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410a1d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410a23:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410a29:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410a2f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410a35:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410a3e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410a47:	add    rsp,0xa8
  410a4e:	pop    rsi
  410a4f:	pop    rdi
  410a50:	ret
	...

0000000000410a60 <__swc_fn_23cea7fa_000146_d2097256>:
  410a60:	push   rbx
  410a61:	push   rsi
  410a62:	push   rdi
  410a63:	push   r12
  410a65:	push   r13
  410a67:	push   r15
  410a69:	sub    rsp,0x4e8
  410a70:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  410a79:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  410a82:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  410a8b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  410a94:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  410a9d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  410aa6:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  410aaf:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  410ab8:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  410ac1:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  410aca:	mov    rbx,QWORD PTR [rcx]
  410acd:	mov    rcx,QWORD PTR [rcx+0x8]
  410ad1:	mov    rsi,rcx
  410ad4:	xor    edi,edi
  410ad6:	vmovsd xmm6,QWORD PTR [rip+0x2ab2]        # 413590 <__swc_rdata_base_23cea7fa+0x480>
  410ade:	vmovsd xmm7,QWORD PTR [rip+0x2ab3]        # 413599 <__swc_rdata_base_23cea7fa+0x489>
  410ae6:	vmovsd xmm8,QWORD PTR [rip+0x2ab4]        # 4135a2 <__swc_rdata_base_23cea7fa+0x492>
  410aee:	vmovsd xmm9,QWORD PTR [rip+0x2ab5]        # 4135ab <__swc_rdata_base_23cea7fa+0x49b>
  410af6:	vmovsd xmm10,QWORD PTR [rip+0x2ab6]        # 4135b4 <__swc_rdata_base_23cea7fa+0x4a4>
  410afe:	vmovups xmm11,xmm6
  410b02:	vmovsd QWORD PTR [rsp+0x418],xmm7
  410b0b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  410b14:	vmovsd QWORD PTR [rsp+0x428],xmm9
  410b1d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  410b26:	vmovsd xmm15,QWORD PTR [rip+0x2a8f]        # 4135bd <__swc_rdata_base_23cea7fa+0x4ad>
  410b2e:	vmovups xmm14,xmm15
  410b33:	vmovups xmm0,xmm9
  410b38:	vmovsd QWORD PTR [rsp+0x438],xmm15
  410b41:	vmovups xmm13,xmm8
  410b46:	vmovsd QWORD PTR [rsp+0x440],xmm15
  410b4f:	test   rsi,rsi
  410b52:	je     411b43 <__swc_fn_23cea7fa_000146_d2097256+0x10e3>
  410b58:	cs nop WORD PTR [rax+rax*1+0x0]
  410b62:	cs nop WORD PTR [rax+rax*1+0x0]
  410b6c:	nop    DWORD PTR [rax+0x0]
  410b70:	lea    rcx,[rdi+rdi*1]
  410b74:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  410b79:	vpshufd xmm3,xmm2,0xee
  410b7e:	vmovq  rcx,xmm3
  410b83:	test   rcx,rcx
  410b86:	je     410b9c <__swc_fn_23cea7fa_000146_d2097256+0x13c>
  410b88:	test   DWORD PTR [rcx+0x28],0x400000
  410b8f:	je     410b9c <__swc_fn_23cea7fa_000146_d2097256+0x13c>
  410b91:	mov    rdx,QWORD PTR [rcx+0x30]
  410b95:	test   rdx,rdx
  410b98:	cmovne rcx,rdx
  410b9c:	test   DWORD PTR [rcx+0x28],0x1000
  410ba3:	je     410bc4 <__swc_fn_23cea7fa_000146_d2097256+0x164>
  410ba5:	mov    rdx,QWORD PTR [rcx+0x40]
  410ba9:	mov    rcx,rdx
  410bac:	vmovq  r8,xmm2
  410bb1:	mov    r8,QWORD PTR [r8]
  410bb4:	mov    QWORD PTR [rsp+0x60],r8
  410bb9:	mov    QWORD PTR [rsp+0x68],rdx
  410bbe:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  410bc4:	test   BYTE PTR [rcx+0x28],0x1
  410bc8:	jne    410bd0 <__swc_fn_23cea7fa_000146_d2097256+0x170>
  410bca:	vmovups xmm12,xmm0
  410bce:	jmp    410bea <__swc_fn_23cea7fa_000146_d2097256+0x18a>
  410bd0:	vmovq  rax,xmm2
  410bd5:	mov    rax,QWORD PTR [rax]
  410bd8:	lea    rcx,[rax+0x10]
  410bdc:	vmovups xmm12,xmm0
  410be0:	call   4101f0 <__swc_fn_23cea7fa_000116_3f5cfdef>
  410be5:	jmp    411b25 <__swc_fn_23cea7fa_000146_d2097256+0x10c5>
  410bea:	test   DWORD PTR [rcx+0x28],0x400
  410bf1:	je     410c52 <__swc_fn_23cea7fa_000146_d2097256+0x1f2>
  410bf3:	vmovq  rax,xmm2
  410bf8:	mov    rax,QWORD PTR [rax]
  410bfb:	xor    ecx,ecx
  410bfd:	test   rax,rax
  410c00:	je     410c30 <__swc_fn_23cea7fa_000146_d2097256+0x1d0>
  410c02:	mov    rdx,rax
  410c05:	mov    r8b,BYTE PTR [rdx]
  410c08:	test   r8b,r8b
  410c0b:	je     410c30 <__swc_fn_23cea7fa_000146_d2097256+0x1d0>
  410c0d:	cs nop WORD PTR [rax+rax*1+0x0]
  410c17:	nop    WORD PTR [rax+rax*1+0x0]
  410c20:	add    rdx,0x1
  410c24:	add    rcx,0x1
  410c28:	mov    r8b,BYTE PTR [rdx]
  410c2b:	test   r8b,r8b
  410c2e:	jne    410c20 <__swc_fn_23cea7fa_000146_d2097256+0x1c0>
  410c30:	mov    QWORD PTR [rsp+0x88],rax
  410c38:	mov    QWORD PTR [rsp+0x90],rcx
  410c40:	lea    rcx,[rsp+0x88]
  410c48:	call   4101f0 <__swc_fn_23cea7fa_000116_3f5cfdef>
  410c4d:	jmp    411b25 <__swc_fn_23cea7fa_000146_d2097256+0x10c5>
  410c52:	cmp    BYTE PTR [rcx+0x2c],0x6
  410c56:	jne    410c6d <__swc_fn_23cea7fa_000146_d2097256+0x20d>
  410c58:	vmovq  rax,xmm2
  410c5d:	mov    rax,QWORD PTR [rax]
  410c60:	mov    rcx,rax
  410c63:	call   409cb0 <__swc_fn_23cea7fa_000144_c3e86ca0>
  410c68:	jmp    411b25 <__swc_fn_23cea7fa_000146_d2097256+0x10c5>
  410c6d:	cmp    BYTE PTR [rcx+0x2c],0x1
  410c71:	jne    411b19 <__swc_fn_23cea7fa_000146_d2097256+0x10b9>
  410c77:	vmovq  rdx,xmm2
  410c7c:	mov    cl,BYTE PTR [rcx+0x40]
  410c7f:	cmp    cl,0x7
  410c82:	jb     410cc5 <__swc_fn_23cea7fa_000146_d2097256+0x265>
  410c84:	je     410d38 <__swc_fn_23cea7fa_000146_d2097256+0x2d8>
  410c8a:	cmp    cl,0x8
  410c8d:	je     410d44 <__swc_fn_23cea7fa_000146_d2097256+0x2e4>
  410c93:	cmp    cl,0x9
  410c96:	je     410d5d <__swc_fn_23cea7fa_000146_d2097256+0x2fd>
  410c9c:	cmp    cl,0xa
  410c9f:	je     411424 <__swc_fn_23cea7fa_000146_d2097256+0x9c4>
  410ca5:	cmp    cl,0xb
  410ca8:	je     411aeb <__swc_fn_23cea7fa_000146_d2097256+0x108b>
  410cae:	cmp    cl,0xc
  410cb1:	je     410d51 <__swc_fn_23cea7fa_000146_d2097256+0x2f1>
  410cb7:	cmp    cl,0xd
  410cba:	je     411ae1 <__swc_fn_23cea7fa_000146_d2097256+0x1081>
  410cc0:	jmp    411b0b <__swc_fn_23cea7fa_000146_d2097256+0x10ab>
  410cc5:	cmp    cl,0x1
  410cc8:	je     410ce8 <__swc_fn_23cea7fa_000146_d2097256+0x288>
  410cca:	cmp    cl,0x2
  410ccd:	je     410cf6 <__swc_fn_23cea7fa_000146_d2097256+0x296>
  410ccf:	cmp    cl,0x3
  410cd2:	je     410d04 <__swc_fn_23cea7fa_000146_d2097256+0x2a4>
  410cd4:	cmp    cl,0x4
  410cd7:	je     410d11 <__swc_fn_23cea7fa_000146_d2097256+0x2b1>
  410cd9:	cmp    cl,0x5
  410cdc:	je     410d1e <__swc_fn_23cea7fa_000146_d2097256+0x2be>
  410cde:	cmp    cl,0x6
  410ce1:	je     410d2b <__swc_fn_23cea7fa_000146_d2097256+0x2cb>
  410ce3:	jmp    411b0b <__swc_fn_23cea7fa_000146_d2097256+0x10ab>
  410ce8:	movsx  rcx,BYTE PTR [rdx]
  410cec:	call   40cf60 <__swc_fn_23cea7fa_000145_32a1d6a2>
  410cf1:	jmp    411b25 <__swc_fn_23cea7fa_000146_d2097256+0x10c5>
  410cf6:	movsx  rcx,WORD PTR [rdx]
  410cfa:	call   40cf60 <__swc_fn_23cea7fa_000145_32a1d6a2>
  410cff:	jmp    411b25 <__swc_fn_23cea7fa_000146_d2097256+0x10c5>
  410d04:	movsxd rcx,DWORD PTR [rdx]
  410d07:	call   40cf60 <__swc_fn_23cea7fa_000145_32a1d6a2>
  410d0c:	jmp    411b25 <__swc_fn_23cea7fa_000146_d2097256+0x10c5>
  410d11:	mov    rcx,QWORD PTR [rdx]
  410d14:	call   40cf60 <__swc_fn_23cea7fa_000145_32a1d6a2>
  410d19:	jmp    411b25 <__swc_fn_23cea7fa_000146_d2097256+0x10c5>
  410d1e:	movzx  ecx,BYTE PTR [rdx]
  410d21:	call   409cb0 <__swc_fn_23cea7fa_000144_c3e86ca0>
  410d26:	jmp    411b25 <__swc_fn_23cea7fa_000146_d2097256+0x10c5>
  410d2b:	movzx  ecx,WORD PTR [rdx]
  410d2e:	call   409cb0 <__swc_fn_23cea7fa_000144_c3e86ca0>
  410d33:	jmp    411b25 <__swc_fn_23cea7fa_000146_d2097256+0x10c5>
  410d38:	mov    ecx,DWORD PTR [rdx]
  410d3a:	call   409cb0 <__swc_fn_23cea7fa_000144_c3e86ca0>
  410d3f:	jmp    411b25 <__swc_fn_23cea7fa_000146_d2097256+0x10c5>
  410d44:	mov    rcx,QWORD PTR [rdx]
  410d47:	call   409cb0 <__swc_fn_23cea7fa_000144_c3e86ca0>
  410d4c:	jmp    411b25 <__swc_fn_23cea7fa_000146_d2097256+0x10c5>
  410d51:	mov    ecx,DWORD PTR [rdx]
  410d53:	call   409cb0 <__swc_fn_23cea7fa_000144_c3e86ca0>
  410d58:	jmp    411b25 <__swc_fn_23cea7fa_000146_d2097256+0x10c5>
  410d5d:	lea    rcx,[rsp+0xa8]
  410d65:	vxorps xmm0,xmm0,xmm0
  410d69:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  410d72:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  410d7b:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  410d84:	vzeroupper
  410d87:	mov    DWORD PTR [rsp+0x108],0x0
  410d92:	vxorpd xmm0,xmm0,xmm0
  410d96:	vmovss xmm1,DWORD PTR [rdx]
  410d9a:	vcvtss2sd xmm0,xmm0,xmm1
  410d9e:	vmovsd xmm1,xmm1,xmm0
  410da2:	vcomisd xmm0,xmm0
  410da6:	setne  dl
  410da9:	movzx  edx,dl
  410dac:	setp   r8b
  410db0:	movzx  r8d,r8b
  410db4:	or     edx,r8d
  410db7:	test   dl,dl
  410db9:	je     410dc6 <__swc_fn_23cea7fa_000146_d2097256+0x366>
  410dbb:	mov    DWORD PTR [rcx],0x6e616e
  410dc1:	jmp    4113b8 <__swc_fn_23cea7fa_000146_d2097256+0x958>
  410dc6:	vcomisd xmm1,xmm6
  410dca:	ja     410dd2 <__swc_fn_23cea7fa_000146_d2097256+0x372>
  410dcc:	vcomisd xmm7,xmm1
  410dd0:	jbe    410df6 <__swc_fn_23cea7fa_000146_d2097256+0x396>
  410dd2:	vxorpd xmm0,xmm0,xmm0
  410dd6:	vcomisd xmm0,xmm1
  410dda:	jbe    410deb <__swc_fn_23cea7fa_000146_d2097256+0x38b>
  410ddc:	mov    DWORD PTR [rcx],0x666e692d
  410de2:	mov    BYTE PTR [rcx+0x4],0x0
  410de6:	jmp    4113b8 <__swc_fn_23cea7fa_000146_d2097256+0x958>
  410deb:	mov    DWORD PTR [rcx],0x666e69
  410df1:	jmp    4113b8 <__swc_fn_23cea7fa_000146_d2097256+0x958>
  410df6:	vcomisd xmm1,xmm8
  410dfb:	jae    410e07 <__swc_fn_23cea7fa_000146_d2097256+0x3a7>
  410dfd:	vcomisd xmm9,xmm1
  410e01:	jbe    41117e <__swc_fn_23cea7fa_000146_d2097256+0x71e>
  410e07:	vmovups xmm0,xmm1
  410e0b:	vxorpd xmm2,xmm2,xmm2
  410e0f:	vcomisd xmm2,xmm1
  410e13:	jbe    410e23 <__swc_fn_23cea7fa_000146_d2097256+0x3c3>
  410e15:	vmovsd xmm1,xmm1,xmm0
  410e19:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x272f]        # 413550 <__swc_rdata_base_23cea7fa+0x440>
  410e21:	jmp    410e27 <__swc_fn_23cea7fa_000146_d2097256+0x3c7>
  410e23:	vmovsd xmm1,xmm1,xmm0
  410e27:	xor    r8d,r8d
  410e2a:	vcomisd xmm1,xmm15
  410e2f:	jb     410e50 <__swc_fn_23cea7fa_000146_d2097256+0x3f0>
  410e31:	cs nop WORD PTR [rax+rax*1+0x0]
  410e3b:	nop    DWORD PTR [rax+rax*1+0x0]
  410e40:	vdivsd xmm1,xmm1,xmm15
  410e45:	add    r8,0x1
  410e49:	vcomisd xmm1,xmm15
  410e4e:	jae    410e40 <__swc_fn_23cea7fa_000146_d2097256+0x3e0>
  410e50:	mov    r9,rcx
  410e53:	vxorpd xmm2,xmm2,xmm2
  410e57:	vcomisd xmm2,xmm0
  410e5b:	jbe    410e64 <__swc_fn_23cea7fa_000146_d2097256+0x404>
  410e5d:	mov    BYTE PTR [rcx],0x2d
  410e60:	lea    r9,[rcx+0x1]
  410e64:	vcvttsd2si rdx,xmm1
  410e69:	mov    r10b,dl
  410e6c:	add    r10b,0x30
  410e70:	mov    BYTE PTR [r9],r10b
  410e73:	vxorpd xmm0,xmm0,xmm0
  410e77:	movzx  edx,dl
  410e7a:	vcvtsi2sd xmm0,xmm0,rdx
  410e7f:	vsubsd xmm0,xmm1,xmm0
  410e83:	vmulsd xmm1,xmm0,xmm15
  410e88:	mov    BYTE PTR [r9+0x1],0x2e
  410e8d:	vcvttsd2si rdx,xmm1
  410e92:	mov    r10b,dl
  410e95:	add    r10b,0x30
  410e99:	mov    BYTE PTR [r9+0x2],r10b
  410e9d:	vxorpd xmm0,xmm0,xmm0
  410ea1:	movzx  edx,dl
  410ea4:	vcvtsi2sd xmm0,xmm0,rdx
  410ea9:	vsubsd xmm0,xmm1,xmm0
  410ead:	vmulsd xmm1,xmm0,xmm15
  410eb2:	vcvttsd2si rdx,xmm1
  410eb7:	mov    r10b,dl
  410eba:	add    r10b,0x30
  410ebe:	mov    BYTE PTR [r9+0x3],r10b
  410ec2:	vxorpd xmm0,xmm0,xmm0
  410ec6:	movzx  edx,dl
  410ec9:	vcvtsi2sd xmm0,xmm0,rdx
  410ece:	vsubsd xmm0,xmm1,xmm0
  410ed2:	vmulsd xmm1,xmm0,xmm15
  410ed7:	vcvttsd2si rdx,xmm1
  410edc:	mov    r10b,dl
  410edf:	add    r10b,0x30
  410ee3:	mov    BYTE PTR [r9+0x4],r10b
  410ee7:	vxorpd xmm0,xmm0,xmm0
  410eeb:	movzx  edx,dl
  410eee:	vcvtsi2sd xmm0,xmm0,rdx
  410ef3:	vsubsd xmm0,xmm1,xmm0
  410ef7:	vmulsd xmm1,xmm0,xmm15
  410efc:	vcvttsd2si rdx,xmm1
  410f01:	mov    r10b,dl
  410f04:	add    r10b,0x30
  410f08:	mov    BYTE PTR [r9+0x5],r10b
  410f0c:	vxorpd xmm0,xmm0,xmm0
  410f10:	movzx  edx,dl
  410f13:	vcvtsi2sd xmm0,xmm0,rdx
  410f18:	vsubsd xmm0,xmm1,xmm0
  410f1c:	vmulsd xmm1,xmm0,xmm15
  410f21:	vcvttsd2si rdx,xmm1
  410f26:	mov    r10b,dl
  410f29:	add    r10b,0x30
  410f2d:	mov    BYTE PTR [r9+0x6],r10b
  410f31:	vxorpd xmm0,xmm0,xmm0
  410f35:	movzx  edx,dl
  410f38:	vcvtsi2sd xmm0,xmm0,rdx
  410f3d:	vsubsd xmm0,xmm1,xmm0
  410f41:	vmulsd xmm1,xmm0,xmm15
  410f46:	vcvttsd2si rdx,xmm1
  410f4b:	mov    r10b,dl
  410f4e:	add    r10b,0x30
  410f52:	mov    BYTE PTR [r9+0x7],r10b
  410f56:	vxorpd xmm0,xmm0,xmm0
  410f5a:	movzx  edx,dl
  410f5d:	vcvtsi2sd xmm0,xmm0,rdx
  410f62:	vsubsd xmm0,xmm1,xmm0
  410f66:	vmulsd xmm1,xmm0,xmm15
  410f6b:	vcvttsd2si rdx,xmm1
  410f70:	mov    r10b,dl
  410f73:	add    r10b,0x30
  410f77:	mov    BYTE PTR [r9+0x8],r10b
  410f7b:	vxorpd xmm0,xmm0,xmm0
  410f7f:	movzx  edx,dl
  410f82:	vcvtsi2sd xmm0,xmm0,rdx
  410f87:	vsubsd xmm0,xmm1,xmm0
  410f8b:	vmulsd xmm1,xmm0,xmm15
  410f90:	vcvttsd2si rdx,xmm1
  410f95:	mov    r10b,dl
  410f98:	add    r10b,0x30
  410f9c:	mov    BYTE PTR [r9+0x9],r10b
  410fa0:	vxorpd xmm0,xmm0,xmm0
  410fa4:	movzx  edx,dl
  410fa7:	vcvtsi2sd xmm0,xmm0,rdx
  410fac:	vsubsd xmm0,xmm1,xmm0
  410fb0:	vmulsd xmm1,xmm0,xmm15
  410fb5:	vcvttsd2si rdx,xmm1
  410fba:	mov    r10b,dl
  410fbd:	add    r10b,0x30
  410fc1:	mov    BYTE PTR [r9+0xa],r10b
  410fc5:	vxorpd xmm0,xmm0,xmm0
  410fc9:	movzx  edx,dl
  410fcc:	vcvtsi2sd xmm0,xmm0,rdx
  410fd1:	vsubsd xmm0,xmm1,xmm0
  410fd5:	vmulsd xmm1,xmm0,xmm15
  410fda:	vcvttsd2si rdx,xmm1
  410fdf:	mov    r10b,dl
  410fe2:	add    r10b,0x30
  410fe6:	mov    BYTE PTR [r9+0xb],r10b
  410fea:	lea    r10,[r9+0x4]
  410fee:	vxorpd xmm0,xmm0,xmm0
  410ff2:	movzx  edx,dl
  410ff5:	vcvtsi2sd xmm0,xmm0,rdx
  410ffa:	vsubsd xmm0,xmm1,xmm0
  410ffe:	vmulsd xmm1,xmm0,xmm15
  411003:	vcvttsd2si rdx,xmm1
  411008:	mov    r11b,dl
  41100b:	add    r11b,0x30
  41100f:	mov    BYTE PTR [r9+0xc],r11b
  411013:	vxorpd xmm0,xmm0,xmm0
  411017:	movzx  edx,dl
  41101a:	vcvtsi2sd xmm0,xmm0,rdx
  41101f:	vsubsd xmm0,xmm1,xmm0
  411023:	vmulsd xmm1,xmm0,xmm15
  411028:	vcvttsd2si rdx,xmm1
  41102d:	mov    r11b,dl
  411030:	add    r11b,0x30
  411034:	mov    BYTE PTR [r9+0xd],r11b
  411038:	lea    r10,[r10+0x2]
  41103c:	vxorpd xmm0,xmm0,xmm0
  411040:	movzx  edx,dl
  411043:	vcvtsi2sd xmm0,xmm0,rdx
  411048:	vsubsd xmm0,xmm1,xmm0
  41104c:	vmulsd xmm1,xmm0,xmm15
  411051:	vcvttsd2si rdx,xmm1
  411056:	mov    r11b,dl
  411059:	add    r11b,0x30
  41105d:	mov    BYTE PTR [r9+0xe],r11b
  411061:	vxorpd xmm0,xmm0,xmm0
  411065:	movzx  edx,dl
  411068:	vcvtsi2sd xmm0,xmm0,rdx
  41106d:	vsubsd xmm0,xmm1,xmm0
  411071:	vmulsd xmm1,xmm0,xmm15
  411076:	vcvttsd2si rdx,xmm1
  41107b:	mov    r11b,dl
  41107e:	add    r11b,0x30
  411082:	mov    BYTE PTR [r9+0xf],r11b
  411086:	lea    r10,[r10+0x2]
  41108a:	lea    r10,[r10+0x2]
  41108e:	lea    r10,[r10+0x2]
  411092:	lea    r10,[r10+0x2]
  411096:	lea    r10,[r10+0x2]
  41109a:	vxorpd xmm0,xmm0,xmm0
  41109e:	movzx  edx,dl
  4110a1:	vcvtsi2sd xmm0,xmm0,rdx
  4110a6:	vsubsd xmm0,xmm1,xmm0
  4110aa:	vmulsd xmm1,xmm0,xmm15
  4110af:	vcvttsd2si rdx,xmm1
  4110b4:	mov    r11b,dl
  4110b7:	add    r11b,0x30
  4110bb:	mov    BYTE PTR [r9+0x10],r11b
  4110bf:	vxorpd xmm0,xmm0,xmm0
  4110c3:	movzx  edx,dl
  4110c6:	vcvtsi2sd xmm0,xmm0,rdx
  4110cb:	vsubsd xmm0,xmm1,xmm0
  4110cf:	vmulsd xmm1,xmm0,xmm15
  4110d4:	vcvttsd2si rdx,xmm1
  4110d9:	add    dl,0x30
  4110dc:	mov    BYTE PTR [r9+0x11],dl
  4110e0:	mov    BYTE PTR [r10+0x2],0x65
  4110e5:	lea    r9,[r10+0x3]
  4110e9:	test   r8,r8
  4110ec:	jl     4110f5 <__swc_fn_23cea7fa_000146_d2097256+0x695>
  4110ee:	mov    BYTE PTR [r9],0x2b
  4110f2:	inc    r9
  4110f5:	mov    r10,r9
  4110f8:	mov    rdx,r8
  4110fb:	nop    DWORD PTR [rax+rax*1+0x0]
  411100:	mov    r11,rdx
  411103:	movabs rdx,0x6666666666666667
  41110d:	mov    rax,r11
  411110:	imul   rdx
  411113:	sar    rdx,0x2
  411117:	mov    r12,rdx
  41111a:	shr    rdx,0x3f
  41111e:	add    r12,rdx
  411121:	mov    rdx,r12
  411124:	imul   r13,r12,0xa
  411128:	sub    r11,r13
  41112b:	mov    r13,QWORD PTR [rip+0x240e]        # 413540 <__swc_rdata_base_23cea7fa+0x430>
  411132:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411137:	mov    BYTE PTR [r10],r11b
  41113a:	lea    r11,[r10+0x1]
  41113e:	mov    r10,r11
  411141:	test   r12,r12
  411144:	jne    411100 <__swc_fn_23cea7fa_000146_d2097256+0x6a0>
  411146:	test   r8,r8
  411149:	jge    411153 <__swc_fn_23cea7fa_000146_d2097256+0x6f3>
  41114b:	mov    BYTE PTR [r11],0x2d
  41114f:	lea    r10,[r11+0x1]
  411153:	mov    BYTE PTR [r10],0x0
  411157:	sub    r10,0x1
  41115b:	nop    DWORD PTR [rax+rax*1+0x0]
  411160:	cmp    r9,r10
  411163:	jae    4113b8 <__swc_fn_23cea7fa_000146_d2097256+0x958>
  411169:	mov    al,BYTE PTR [r10]
  41116c:	mov    dl,BYTE PTR [r9]
  41116f:	mov    BYTE PTR [r10],dl
  411172:	sub    r10,0x1
  411176:	mov    BYTE PTR [r9],al
  411179:	inc    r9
  41117c:	jmp    411160 <__swc_fn_23cea7fa_000146_d2097256+0x700>
  41117e:	vcvttsd2si rdx,xmm1
  411183:	mov    r8,rdx
  411186:	vxorpd xmm0,xmm0,xmm0
  41118a:	vcvtsi2sd xmm0,xmm0,rdx
  41118f:	vsubsd xmm0,xmm1,xmm0
  411193:	mov    r9d,0x8
  411199:	vxorpd xmm2,xmm2,xmm2
  41119d:	vcomisd xmm2,xmm0
  4111a1:	jbe    4111ab <__swc_fn_23cea7fa_000146_d2097256+0x74b>
  4111a3:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x23a5]        # 413550 <__swc_rdata_base_23cea7fa+0x440>
  4111ab:	test   r9d,r9d
  4111ae:	je     4111ba <__swc_fn_23cea7fa_000146_d2097256+0x75a>
  4111b0:	vmulsd xmm0,xmm0,xmm14
  4111b5:	dec    r9d
  4111b8:	jne    4111b0 <__swc_fn_23cea7fa_000146_d2097256+0x750>
  4111ba:	vcvttsd2si r9,xmm0
  4111bf:	mov    r10,r9
  4111c2:	vxorpd xmm2,xmm2,xmm2
  4111c6:	vcvtsi2sd xmm2,xmm2,r9
  4111cb:	vsubsd xmm0,xmm0,xmm2
  4111cf:	vcomisd xmm0,xmm10
  4111d4:	lea    r9,[r9+0x1]
  4111d8:	cmova  r10,r9
  4111dc:	cmp    r10,0x5f5e100
  4111e3:	jne    4111fc <__swc_fn_23cea7fa_000146_d2097256+0x79c>
  4111e5:	lea    r8,[rdx-0x1]
  4111e9:	vxorpd xmm0,xmm0,xmm0
  4111ed:	vcomisd xmm0,xmm1
  4111f1:	lea    rdx,[rdx+0x1]
  4111f5:	cmovbe r8,rdx
  4111f9:	xor    r10d,r10d
  4111fc:	mov    r9,rcx
  4111ff:	test   r8,r8
  411202:	jne    411222 <__swc_fn_23cea7fa_000146_d2097256+0x7c2>
  411204:	vxorpd xmm0,xmm0,xmm0
  411208:	vcomisd xmm0,xmm1
  41120c:	jbe    411215 <__swc_fn_23cea7fa_000146_d2097256+0x7b5>
  41120e:	mov    BYTE PTR [rcx],0x2d
  411211:	lea    r9,[rcx+0x1]
  411215:	mov    BYTE PTR [r9],0x30
  411219:	add    r9,0x1
  41121d:	jmp    4112bb <__swc_fn_23cea7fa_000146_d2097256+0x85b>
  411222:	mov    r9,rcx
  411225:	mov    rdx,r8
  411228:	nop    DWORD PTR [rax+rax*1+0x0]
  411230:	mov    r11,rdx
  411233:	movabs rdx,0x6666666666666667
  41123d:	mov    r15,rax
  411240:	mov    rax,r11
  411243:	imul   rdx
  411246:	mov    r12,rdx
  411249:	mov    rax,r15
  41124c:	sar    r12,0x2
  411250:	mov    rdx,r12
  411253:	shr    rdx,0x3f
  411257:	add    r12,rdx
  41125a:	mov    rdx,r12
  41125d:	imul   r13,r12,0xa
  411261:	sub    r11,r13
  411264:	mov    r13,QWORD PTR [rip+0x22d5]        # 413540 <__swc_rdata_base_23cea7fa+0x430>
  41126b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411270:	mov    BYTE PTR [r9],r11b
  411273:	lea    r11,[r9+0x1]
  411277:	mov    r9,r11
  41127a:	test   r12,r12
  41127d:	jne    411230 <__swc_fn_23cea7fa_000146_d2097256+0x7d0>
  41127f:	test   r8,r8
  411282:	jge    41128c <__swc_fn_23cea7fa_000146_d2097256+0x82c>
  411284:	mov    BYTE PTR [r11],0x2d
  411288:	lea    r9,[r11+0x1]
  41128c:	mov    rdx,r9
  41128f:	mov    BYTE PTR [r9],0x0
  411293:	sub    r9,0x1
  411297:	mov    r8,rcx
  41129a:	cmp    r8,r9
  41129d:	jae    4112b8 <__swc_fn_23cea7fa_000146_d2097256+0x858>
  41129f:	nop
  4112a0:	mov    r11b,BYTE PTR [r9]
  4112a3:	mov    r12b,BYTE PTR [r8]
  4112a6:	mov    BYTE PTR [r9],r12b
  4112a9:	sub    r9,0x1
  4112ad:	mov    BYTE PTR [r8],r11b
  4112b0:	inc    r8
  4112b3:	cmp    r8,r9
  4112b6:	jb     4112a0 <__swc_fn_23cea7fa_000146_d2097256+0x840>
  4112b8:	mov    r9,rdx
  4112bb:	mov    BYTE PTR [r9],0x2e
  4112bf:	add    r9,0x1
  4112c3:	xor    r8d,r8d
  4112c6:	test   r10,r10
  4112c9:	je     41130f <__swc_fn_23cea7fa_000146_d2097256+0x8af>
  4112cb:	mov    r11d,0x989680
  4112d1:	cmp    r10,r11
  4112d4:	jge    41130f <__swc_fn_23cea7fa_000146_d2097256+0x8af>
  4112d6:	cs nop WORD PTR [rax+rax*1+0x0]
  4112e0:	inc    r8d
  4112e3:	movabs rdx,0x6666666666666667
  4112ed:	mov    r15,rax
  4112f0:	mov    rax,r11
  4112f3:	imul   rdx
  4112f6:	mov    r11,rdx
  4112f9:	mov    rax,r15
  4112fc:	sar    r11,0x2
  411300:	mov    rdx,r11
  411303:	shr    rdx,0x3f
  411307:	add    r11,rdx
  41130a:	cmp    r10,r11
  41130d:	jl     4112e0 <__swc_fn_23cea7fa_000146_d2097256+0x880>
  41130f:	test   r8d,r8d
  411312:	je     41132d <__swc_fn_23cea7fa_000146_d2097256+0x8cd>
  411314:	cs nop WORD PTR [rax+rax*1+0x0]
  41131e:	xchg   ax,ax
  411320:	mov    BYTE PTR [r9],0x30
  411324:	add    r9,0x1
  411328:	dec    r8d
  41132b:	jne    411320 <__swc_fn_23cea7fa_000146_d2097256+0x8c0>
  41132d:	mov    r8,r9
  411330:	mov    rdx,r10
  411333:	cs nop WORD PTR [rax+rax*1+0x0]
  41133d:	nop    DWORD PTR [rax]
  411340:	mov    r11,rdx
  411343:	movabs rdx,0x6666666666666667
  41134d:	mov    rax,r11
  411350:	imul   rdx
  411353:	sar    rdx,0x2
  411357:	mov    r12,rdx
  41135a:	shr    rdx,0x3f
  41135e:	add    r12,rdx
  411361:	mov    rdx,r12
  411364:	imul   r13,r12,0xa
  411368:	sub    r11,r13
  41136b:	mov    r13,QWORD PTR [rip+0x21ce]        # 413540 <__swc_rdata_base_23cea7fa+0x430>
  411372:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411377:	mov    BYTE PTR [r8],r11b
  41137a:	lea    r11,[r8+0x1]
  41137e:	mov    r8,r11
  411381:	test   r12,r12
  411384:	jne    411340 <__swc_fn_23cea7fa_000146_d2097256+0x8e0>
  411386:	test   r10,r10
  411389:	jge    411393 <__swc_fn_23cea7fa_000146_d2097256+0x933>
  41138b:	mov    BYTE PTR [r11],0x2d
  41138f:	lea    r8,[r11+0x1]
  411393:	mov    BYTE PTR [r8],0x0
  411397:	sub    r8,0x1
  41139b:	cmp    r9,r8
  41139e:	jae    4113b8 <__swc_fn_23cea7fa_000146_d2097256+0x958>
  4113a0:	mov    al,BYTE PTR [r8]
  4113a3:	mov    dl,BYTE PTR [r9]
  4113a6:	mov    BYTE PTR [r8],dl
  4113a9:	sub    r8,0x1
  4113ad:	mov    BYTE PTR [r9],al
  4113b0:	inc    r9
  4113b3:	cmp    r9,r8
  4113b6:	jb     4113a0 <__swc_fn_23cea7fa_000146_d2097256+0x940>
  4113b8:	xor    eax,eax
  4113ba:	test   rcx,rcx
  4113bd:	je     4113f0 <__swc_fn_23cea7fa_000146_d2097256+0x990>
  4113bf:	mov    rdx,rcx
  4113c2:	mov    r8b,BYTE PTR [rdx]
  4113c5:	test   r8b,r8b
  4113c8:	je     4113f0 <__swc_fn_23cea7fa_000146_d2097256+0x990>
  4113ca:	cs nop WORD PTR [rax+rax*1+0x0]
  4113d4:	cs nop WORD PTR [rax+rax*1+0x0]
  4113de:	xchg   ax,ax
  4113e0:	add    rdx,0x1
  4113e4:	add    rax,0x1
  4113e8:	mov    r8b,BYTE PTR [rdx]
  4113eb:	test   r8b,r8b
  4113ee:	jne    4113e0 <__swc_fn_23cea7fa_000146_d2097256+0x980>
  4113f0:	mov    QWORD PTR [rsp+0x240],rcx
  4113f8:	mov    QWORD PTR [rsp+0x248],rax
  411400:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  411409:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  411412:	lea    rcx,[rsp+0x250]
  41141a:	call   4101f0 <__swc_fn_23cea7fa_000116_3f5cfdef>
  41141f:	jmp    411b25 <__swc_fn_23cea7fa_000146_d2097256+0x10c5>
  411424:	lea    rcx,[rsp+0x260]
  41142c:	vxorps xmm0,xmm0,xmm0
  411430:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  411439:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  411442:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  41144b:	vzeroupper
  41144e:	mov    DWORD PTR [rsp+0x2c0],0x0
  411459:	vmovsd xmm0,QWORD PTR [rdx]
  41145d:	vcomisd xmm0,xmm0
  411461:	setne  dl
  411464:	movzx  edx,dl
  411467:	setp   r8b
  41146b:	movzx  r8d,r8b
  41146f:	or     edx,r8d
  411472:	test   dl,dl
  411474:	je     411481 <__swc_fn_23cea7fa_000146_d2097256+0xa21>
  411476:	mov    DWORD PTR [rcx],0x6e616e
  41147c:	jmp    411a88 <__swc_fn_23cea7fa_000146_d2097256+0x1028>
  411481:	vcomisd xmm0,xmm11
  411486:	ja     411497 <__swc_fn_23cea7fa_000146_d2097256+0xa37>
  411488:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  411491:	vcomisd xmm6,xmm0
  411495:	jbe    4114bb <__swc_fn_23cea7fa_000146_d2097256+0xa5b>
  411497:	vxorpd xmm1,xmm1,xmm1
  41149b:	vcomisd xmm1,xmm0
  41149f:	jbe    4114b0 <__swc_fn_23cea7fa_000146_d2097256+0xa50>
  4114a1:	mov    DWORD PTR [rcx],0x666e692d
  4114a7:	mov    BYTE PTR [rcx+0x4],0x0
  4114ab:	jmp    411a88 <__swc_fn_23cea7fa_000146_d2097256+0x1028>
  4114b0:	mov    DWORD PTR [rcx],0x666e69
  4114b6:	jmp    411a88 <__swc_fn_23cea7fa_000146_d2097256+0x1028>
  4114bb:	vcomisd xmm0,xmm13
  4114c0:	jae    4114cc <__swc_fn_23cea7fa_000146_d2097256+0xa6c>
  4114c2:	vcomisd xmm12,xmm0
  4114c6:	jbe    41182e <__swc_fn_23cea7fa_000146_d2097256+0xdce>
  4114cc:	vmovups xmm1,xmm0
  4114d0:	vxorpd xmm2,xmm2,xmm2
  4114d4:	vcomisd xmm2,xmm0
  4114d8:	jbe    4114e8 <__swc_fn_23cea7fa_000146_d2097256+0xa88>
  4114da:	vmovsd xmm0,xmm0,xmm1
  4114de:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x206a]        # 413550 <__swc_rdata_base_23cea7fa+0x440>
  4114e6:	jmp    4114ec <__swc_fn_23cea7fa_000146_d2097256+0xa8c>
  4114e8:	vmovsd xmm0,xmm0,xmm1
  4114ec:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  4114f5:	xor    r8d,r8d
  4114f8:	vcomisd xmm0,xmm6
  4114fc:	jb     41150e <__swc_fn_23cea7fa_000146_d2097256+0xaae>
  4114fe:	xchg   ax,ax
  411500:	vdivsd xmm0,xmm0,xmm6
  411504:	add    r8,0x1
  411508:	vcomisd xmm0,xmm6
  41150c:	jae    411500 <__swc_fn_23cea7fa_000146_d2097256+0xaa0>
  41150e:	mov    r9,rcx
  411511:	vxorpd xmm2,xmm2,xmm2
  411515:	vcomisd xmm2,xmm1
  411519:	jbe    411522 <__swc_fn_23cea7fa_000146_d2097256+0xac2>
  41151b:	mov    BYTE PTR [rcx],0x2d
  41151e:	lea    r9,[rcx+0x1]
  411522:	vcvttsd2si rdx,xmm0
  411527:	mov    r10b,dl
  41152a:	add    r10b,0x30
  41152e:	mov    BYTE PTR [r9],r10b
  411531:	vxorpd xmm1,xmm1,xmm1
  411535:	movzx  edx,dl
  411538:	vcvtsi2sd xmm1,xmm1,rdx
  41153d:	vsubsd xmm0,xmm0,xmm1
  411541:	vmulsd xmm0,xmm0,xmm6
  411545:	mov    BYTE PTR [r9+0x1],0x2e
  41154a:	vcvttsd2si rdx,xmm0
  41154f:	mov    r10b,dl
  411552:	add    r10b,0x30
  411556:	mov    BYTE PTR [r9+0x2],r10b
  41155a:	vxorpd xmm1,xmm1,xmm1
  41155e:	movzx  edx,dl
  411561:	vcvtsi2sd xmm1,xmm1,rdx
  411566:	vsubsd xmm0,xmm0,xmm1
  41156a:	vmulsd xmm0,xmm0,xmm6
  41156e:	vcvttsd2si rdx,xmm0
  411573:	mov    r10b,dl
  411576:	add    r10b,0x30
  41157a:	mov    BYTE PTR [r9+0x3],r10b
  41157e:	vxorpd xmm1,xmm1,xmm1
  411582:	movzx  edx,dl
  411585:	vcvtsi2sd xmm1,xmm1,rdx
  41158a:	vsubsd xmm0,xmm0,xmm1
  41158e:	vmulsd xmm0,xmm0,xmm6
  411592:	vcvttsd2si rdx,xmm0
  411597:	mov    r10b,dl
  41159a:	add    r10b,0x30
  41159e:	mov    BYTE PTR [r9+0x4],r10b
  4115a2:	vxorpd xmm1,xmm1,xmm1
  4115a6:	movzx  edx,dl
  4115a9:	vcvtsi2sd xmm1,xmm1,rdx
  4115ae:	vsubsd xmm0,xmm0,xmm1
  4115b2:	vmulsd xmm0,xmm0,xmm6
  4115b6:	vcvttsd2si rdx,xmm0
  4115bb:	mov    r10b,dl
  4115be:	add    r10b,0x30
  4115c2:	mov    BYTE PTR [r9+0x5],r10b
  4115c6:	vxorpd xmm1,xmm1,xmm1
  4115ca:	movzx  edx,dl
  4115cd:	vcvtsi2sd xmm1,xmm1,rdx
  4115d2:	vsubsd xmm0,xmm0,xmm1
  4115d6:	vmulsd xmm0,xmm0,xmm6
  4115da:	vcvttsd2si rdx,xmm0
  4115df:	mov    r10b,dl
  4115e2:	add    r10b,0x30
  4115e6:	mov    BYTE PTR [r9+0x6],r10b
  4115ea:	vxorpd xmm1,xmm1,xmm1
  4115ee:	movzx  edx,dl
  4115f1:	vcvtsi2sd xmm1,xmm1,rdx
  4115f6:	vsubsd xmm0,xmm0,xmm1
  4115fa:	vmulsd xmm0,xmm0,xmm6
  4115fe:	vcvttsd2si rdx,xmm0
  411603:	mov    r10b,dl
  411606:	add    r10b,0x30
  41160a:	mov    BYTE PTR [r9+0x7],r10b
  41160e:	vxorpd xmm1,xmm1,xmm1
  411612:	movzx  edx,dl
  411615:	vcvtsi2sd xmm1,xmm1,rdx
  41161a:	vsubsd xmm0,xmm0,xmm1
  41161e:	vmulsd xmm0,xmm0,xmm6
  411622:	vcvttsd2si rdx,xmm0
  411627:	mov    r10b,dl
  41162a:	add    r10b,0x30
  41162e:	mov    BYTE PTR [r9+0x8],r10b
  411632:	vxorpd xmm1,xmm1,xmm1
  411636:	movzx  edx,dl
  411639:	vcvtsi2sd xmm1,xmm1,rdx
  41163e:	vsubsd xmm0,xmm0,xmm1
  411642:	vmulsd xmm0,xmm0,xmm6
  411646:	vcvttsd2si rdx,xmm0
  41164b:	mov    r10b,dl
  41164e:	add    r10b,0x30
  411652:	mov    BYTE PTR [r9+0x9],r10b
  411656:	vxorpd xmm1,xmm1,xmm1
  41165a:	movzx  edx,dl
  41165d:	vcvtsi2sd xmm1,xmm1,rdx
  411662:	vsubsd xmm0,xmm0,xmm1
  411666:	vmulsd xmm0,xmm0,xmm6
  41166a:	vcvttsd2si rdx,xmm0
  41166f:	mov    r10b,dl
  411672:	add    r10b,0x30
  411676:	mov    BYTE PTR [r9+0xa],r10b
  41167a:	vxorpd xmm1,xmm1,xmm1
  41167e:	movzx  edx,dl
  411681:	vcvtsi2sd xmm1,xmm1,rdx
  411686:	vsubsd xmm0,xmm0,xmm1
  41168a:	vmulsd xmm0,xmm0,xmm6
  41168e:	vcvttsd2si rdx,xmm0
  411693:	mov    r10b,dl
  411696:	add    r10b,0x30
  41169a:	mov    BYTE PTR [r9+0xb],r10b
  41169e:	lea    r10,[r9+0x4]
  4116a2:	vxorpd xmm1,xmm1,xmm1
  4116a6:	movzx  edx,dl
  4116a9:	vcvtsi2sd xmm1,xmm1,rdx
  4116ae:	vsubsd xmm0,xmm0,xmm1
  4116b2:	vmulsd xmm0,xmm0,xmm6
  4116b6:	vcvttsd2si rdx,xmm0
  4116bb:	mov    r11b,dl
  4116be:	add    r11b,0x30
  4116c2:	mov    BYTE PTR [r9+0xc],r11b
  4116c6:	vxorpd xmm1,xmm1,xmm1
  4116ca:	movzx  edx,dl
  4116cd:	vcvtsi2sd xmm1,xmm1,rdx
  4116d2:	vsubsd xmm0,xmm0,xmm1
  4116d6:	vmulsd xmm0,xmm0,xmm6
  4116da:	vcvttsd2si rdx,xmm0
  4116df:	mov    r11b,dl
  4116e2:	add    r11b,0x30
  4116e6:	mov    BYTE PTR [r9+0xd],r11b
  4116ea:	lea    r10,[r10+0x2]
  4116ee:	vxorpd xmm1,xmm1,xmm1
  4116f2:	movzx  edx,dl
  4116f5:	vcvtsi2sd xmm1,xmm1,rdx
  4116fa:	vsubsd xmm0,xmm0,xmm1
  4116fe:	vmulsd xmm0,xmm0,xmm6
  411702:	vcvttsd2si rdx,xmm0
  411707:	mov    r11b,dl
  41170a:	add    r11b,0x30
  41170e:	mov    BYTE PTR [r9+0xe],r11b
  411712:	vxorpd xmm1,xmm1,xmm1
  411716:	movzx  edx,dl
  411719:	vcvtsi2sd xmm1,xmm1,rdx
  41171e:	vsubsd xmm0,xmm0,xmm1
  411722:	vmulsd xmm0,xmm0,xmm6
  411726:	vcvttsd2si rdx,xmm0
  41172b:	mov    r11b,dl
  41172e:	add    r11b,0x30
  411732:	mov    BYTE PTR [r9+0xf],r11b
  411736:	lea    r10,[r10+0x2]
  41173a:	lea    r10,[r10+0x2]
  41173e:	lea    r10,[r10+0x2]
  411742:	lea    r10,[r10+0x2]
  411746:	lea    r10,[r10+0x2]
  41174a:	vxorpd xmm1,xmm1,xmm1
  41174e:	movzx  edx,dl
  411751:	vcvtsi2sd xmm1,xmm1,rdx
  411756:	vsubsd xmm0,xmm0,xmm1
  41175a:	vmulsd xmm0,xmm0,xmm6
  41175e:	vcvttsd2si rdx,xmm0
  411763:	mov    r11b,dl
  411766:	add    r11b,0x30
  41176a:	mov    BYTE PTR [r9+0x10],r11b
  41176e:	vxorpd xmm1,xmm1,xmm1
  411772:	movzx  edx,dl
  411775:	vcvtsi2sd xmm1,xmm1,rdx
  41177a:	vsubsd xmm0,xmm0,xmm1
  41177e:	vmulsd xmm0,xmm0,xmm6
  411782:	vcvttsd2si rdx,xmm0
  411787:	add    dl,0x30
  41178a:	mov    BYTE PTR [r9+0x11],dl
  41178e:	mov    BYTE PTR [r10+0x2],0x65
  411793:	lea    r9,[r10+0x3]
  411797:	test   r8,r8
  41179a:	jl     4117a3 <__swc_fn_23cea7fa_000146_d2097256+0xd43>
  41179c:	mov    BYTE PTR [r9],0x2b
  4117a0:	inc    r9
  4117a3:	mov    r10,r9
  4117a6:	mov    rdx,r8
  4117a9:	nop    DWORD PTR [rax+0x0]
  4117b0:	mov    r11,rdx
  4117b3:	movabs rdx,0x6666666666666667
  4117bd:	mov    rax,r11
  4117c0:	imul   rdx
  4117c3:	sar    rdx,0x2
  4117c7:	mov    r12,rdx
  4117ca:	shr    rdx,0x3f
  4117ce:	add    r12,rdx
  4117d1:	mov    rdx,r12
  4117d4:	imul   r13,r12,0xa
  4117d8:	sub    r11,r13
  4117db:	mov    r13,QWORD PTR [rip+0x1d5e]        # 413540 <__swc_rdata_base_23cea7fa+0x430>
  4117e2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4117e7:	mov    BYTE PTR [r10],r11b
  4117ea:	lea    r11,[r10+0x1]
  4117ee:	mov    r10,r11
  4117f1:	test   r12,r12
  4117f4:	jne    4117b0 <__swc_fn_23cea7fa_000146_d2097256+0xd50>
  4117f6:	test   r8,r8
  4117f9:	jge    411803 <__swc_fn_23cea7fa_000146_d2097256+0xda3>
  4117fb:	mov    BYTE PTR [r11],0x2d
  4117ff:	lea    r10,[r11+0x1]
  411803:	mov    BYTE PTR [r10],0x0
  411807:	sub    r10,0x1
  41180b:	nop    DWORD PTR [rax+rax*1+0x0]
  411810:	cmp    r9,r10
  411813:	jae    411a88 <__swc_fn_23cea7fa_000146_d2097256+0x1028>
  411819:	mov    al,BYTE PTR [r10]
  41181c:	mov    dl,BYTE PTR [r9]
  41181f:	mov    BYTE PTR [r10],dl
  411822:	sub    r10,0x1
  411826:	mov    BYTE PTR [r9],al
  411829:	inc    r9
  41182c:	jmp    411810 <__swc_fn_23cea7fa_000146_d2097256+0xdb0>
  41182e:	vcvttsd2si rdx,xmm0
  411833:	mov    r8,rdx
  411836:	vxorpd xmm1,xmm1,xmm1
  41183a:	vcvtsi2sd xmm1,xmm1,rdx
  41183f:	vsubsd xmm1,xmm0,xmm1
  411843:	mov    r9d,0x8
  411849:	vxorpd xmm2,xmm2,xmm2
  41184d:	vcomisd xmm2,xmm1
  411851:	ja     41185e <__swc_fn_23cea7fa_000146_d2097256+0xdfe>
  411853:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41185c:	jmp    41186f <__swc_fn_23cea7fa_000146_d2097256+0xe0f>
  41185e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1cea]        # 413550 <__swc_rdata_base_23cea7fa+0x440>
  411866:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41186f:	test   r9d,r9d
  411872:	je     411889 <__swc_fn_23cea7fa_000146_d2097256+0xe29>
  411874:	cs nop WORD PTR [rax+rax*1+0x0]
  41187e:	xchg   ax,ax
  411880:	vmulsd xmm1,xmm1,xmm6
  411884:	dec    r9d
  411887:	jne    411880 <__swc_fn_23cea7fa_000146_d2097256+0xe20>
  411889:	vcvttsd2si r9,xmm1
  41188e:	mov    r10,r9
  411891:	vxorpd xmm2,xmm2,xmm2
  411895:	vcvtsi2sd xmm2,xmm2,r9
  41189a:	vsubsd xmm1,xmm1,xmm2
  41189e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  4118a7:	vcomisd xmm1,xmm6
  4118ab:	lea    r9,[r9+0x1]
  4118af:	cmova  r10,r9
  4118b3:	cmp    r10,0x5f5e100
  4118ba:	jne    4118d3 <__swc_fn_23cea7fa_000146_d2097256+0xe73>
  4118bc:	lea    r8,[rdx-0x1]
  4118c0:	vxorpd xmm1,xmm1,xmm1
  4118c4:	vcomisd xmm1,xmm0
  4118c8:	lea    rdx,[rdx+0x1]
  4118cc:	cmovbe r8,rdx
  4118d0:	xor    r10d,r10d
  4118d3:	mov    r9,rcx
  4118d6:	test   r8,r8
  4118d9:	jne    4118f9 <__swc_fn_23cea7fa_000146_d2097256+0xe99>
  4118db:	vxorpd xmm1,xmm1,xmm1
  4118df:	vcomisd xmm1,xmm0
  4118e3:	jbe    4118ec <__swc_fn_23cea7fa_000146_d2097256+0xe8c>
  4118e5:	mov    BYTE PTR [rcx],0x2d
  4118e8:	lea    r9,[rcx+0x1]
  4118ec:	mov    BYTE PTR [r9],0x30
  4118f0:	add    r9,0x1
  4118f4:	jmp    41198b <__swc_fn_23cea7fa_000146_d2097256+0xf2b>
  4118f9:	mov    r9,rcx
  4118fc:	mov    rdx,r8
  4118ff:	nop
  411900:	mov    r11,rdx
  411903:	movabs rdx,0x6666666666666667
  41190d:	mov    r15,rax
  411910:	mov    rax,r11
  411913:	imul   rdx
  411916:	mov    r12,rdx
  411919:	mov    rax,r15
  41191c:	sar    r12,0x2
  411920:	mov    rdx,r12
  411923:	shr    rdx,0x3f
  411927:	add    r12,rdx
  41192a:	mov    rdx,r12
  41192d:	imul   r13,r12,0xa
  411931:	sub    r11,r13
  411934:	mov    r13,QWORD PTR [rip+0x1c05]        # 413540 <__swc_rdata_base_23cea7fa+0x430>
  41193b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411940:	mov    BYTE PTR [r9],r11b
  411943:	lea    r11,[r9+0x1]
  411947:	mov    r9,r11
  41194a:	test   r12,r12
  41194d:	jne    411900 <__swc_fn_23cea7fa_000146_d2097256+0xea0>
  41194f:	test   r8,r8
  411952:	jge    41195c <__swc_fn_23cea7fa_000146_d2097256+0xefc>
  411954:	mov    BYTE PTR [r11],0x2d
  411958:	lea    r9,[r11+0x1]
  41195c:	mov    rdx,r9
  41195f:	mov    BYTE PTR [r9],0x0
  411963:	sub    r9,0x1
  411967:	mov    r8,rcx
  41196a:	cmp    r8,r9
  41196d:	jae    411988 <__swc_fn_23cea7fa_000146_d2097256+0xf28>
  41196f:	nop
  411970:	mov    r11b,BYTE PTR [r9]
  411973:	mov    r12b,BYTE PTR [r8]
  411976:	mov    BYTE PTR [r9],r12b
  411979:	sub    r9,0x1
  41197d:	mov    BYTE PTR [r8],r11b
  411980:	inc    r8
  411983:	cmp    r8,r9
  411986:	jb     411970 <__swc_fn_23cea7fa_000146_d2097256+0xf10>
  411988:	mov    r9,rdx
  41198b:	mov    BYTE PTR [r9],0x2e
  41198f:	add    r9,0x1
  411993:	xor    r8d,r8d
  411996:	test   r10,r10
  411999:	je     4119df <__swc_fn_23cea7fa_000146_d2097256+0xf7f>
  41199b:	mov    r11d,0x989680
  4119a1:	cmp    r10,r11
  4119a4:	jge    4119df <__swc_fn_23cea7fa_000146_d2097256+0xf7f>
  4119a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4119b0:	inc    r8d
  4119b3:	movabs rdx,0x6666666666666667
  4119bd:	mov    r15,rax
  4119c0:	mov    rax,r11
  4119c3:	imul   rdx
  4119c6:	mov    r11,rdx
  4119c9:	mov    rax,r15
  4119cc:	sar    r11,0x2
  4119d0:	mov    rdx,r11
  4119d3:	shr    rdx,0x3f
  4119d7:	add    r11,rdx
  4119da:	cmp    r10,r11
  4119dd:	jl     4119b0 <__swc_fn_23cea7fa_000146_d2097256+0xf50>
  4119df:	test   r8d,r8d
  4119e2:	je     4119fd <__swc_fn_23cea7fa_000146_d2097256+0xf9d>
  4119e4:	cs nop WORD PTR [rax+rax*1+0x0]
  4119ee:	xchg   ax,ax
  4119f0:	mov    BYTE PTR [r9],0x30
  4119f4:	add    r9,0x1
  4119f8:	dec    r8d
  4119fb:	jne    4119f0 <__swc_fn_23cea7fa_000146_d2097256+0xf90>
  4119fd:	mov    r8,r9
  411a00:	mov    rdx,r10
  411a03:	cs nop WORD PTR [rax+rax*1+0x0]
  411a0d:	nop    DWORD PTR [rax]
  411a10:	mov    r11,rdx
  411a13:	movabs rdx,0x6666666666666667
  411a1d:	mov    rax,r11
  411a20:	imul   rdx
  411a23:	sar    rdx,0x2
  411a27:	mov    r12,rdx
  411a2a:	shr    rdx,0x3f
  411a2e:	add    r12,rdx
  411a31:	mov    rdx,r12
  411a34:	imul   r13,r12,0xa
  411a38:	sub    r11,r13
  411a3b:	mov    r13,QWORD PTR [rip+0x1afe]        # 413540 <__swc_rdata_base_23cea7fa+0x430>
  411a42:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411a47:	mov    BYTE PTR [r8],r11b
  411a4a:	lea    r11,[r8+0x1]
  411a4e:	mov    r8,r11
  411a51:	test   r12,r12
  411a54:	jne    411a10 <__swc_fn_23cea7fa_000146_d2097256+0xfb0>
  411a56:	test   r10,r10
  411a59:	jge    411a63 <__swc_fn_23cea7fa_000146_d2097256+0x1003>
  411a5b:	mov    BYTE PTR [r11],0x2d
  411a5f:	lea    r8,[r11+0x1]
  411a63:	mov    BYTE PTR [r8],0x0
  411a67:	sub    r8,0x1
  411a6b:	cmp    r9,r8
  411a6e:	jae    411a88 <__swc_fn_23cea7fa_000146_d2097256+0x1028>
  411a70:	mov    al,BYTE PTR [r8]
  411a73:	mov    dl,BYTE PTR [r9]
  411a76:	mov    BYTE PTR [r8],dl
  411a79:	sub    r8,0x1
  411a7d:	mov    BYTE PTR [r9],al
  411a80:	inc    r9
  411a83:	cmp    r9,r8
  411a86:	jb     411a70 <__swc_fn_23cea7fa_000146_d2097256+0x1010>
  411a88:	xor    eax,eax
  411a8a:	test   rcx,rcx
  411a8d:	je     411ab0 <__swc_fn_23cea7fa_000146_d2097256+0x1050>
  411a8f:	mov    rdx,rcx
  411a92:	mov    r8b,BYTE PTR [rdx]
  411a95:	test   r8b,r8b
  411a98:	je     411ab0 <__swc_fn_23cea7fa_000146_d2097256+0x1050>
  411a9a:	nop    WORD PTR [rax+rax*1+0x0]
  411aa0:	add    rdx,0x1
  411aa4:	add    rax,0x1
  411aa8:	mov    r8b,BYTE PTR [rdx]
  411aab:	test   r8b,r8b
  411aae:	jne    411aa0 <__swc_fn_23cea7fa_000146_d2097256+0x1040>
  411ab0:	mov    QWORD PTR [rsp+0x3f8],rcx
  411ab8:	mov    QWORD PTR [rsp+0x400],rax
  411ac0:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  411ac9:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  411ad2:	lea    rcx,[rsp+0x408]
  411ada:	call   4101f0 <__swc_fn_23cea7fa_000116_3f5cfdef>
  411adf:	jmp    411b25 <__swc_fn_23cea7fa_000146_d2097256+0x10c5>
  411ae1:	mov    rcx,rdx
  411ae4:	call   4101f0 <__swc_fn_23cea7fa_000116_3f5cfdef>
  411ae9:	jmp    411b25 <__swc_fn_23cea7fa_000146_d2097256+0x10c5>
  411aeb:	mov    al,BYTE PTR [rdx]
  411aed:	test   al,al
  411aef:	je     411afa <__swc_fn_23cea7fa_000146_d2097256+0x109a>
  411af1:	lea    rax,[rip+0x1a68]        # 413560 <__swc_rdata_base_23cea7fa+0x450>
  411af8:	jmp    411b01 <__swc_fn_23cea7fa_000146_d2097256+0x10a1>
  411afa:	lea    rax,[rip+0x1a6f]        # 413570 <__swc_rdata_base_23cea7fa+0x460>
  411b01:	mov    rcx,rax
  411b04:	call   4101f0 <__swc_fn_23cea7fa_000116_3f5cfdef>
  411b09:	jmp    411b25 <__swc_fn_23cea7fa_000146_d2097256+0x10c5>
  411b0b:	lea    rcx,[rip+0x1a6e]        # 413580 <__swc_rdata_base_23cea7fa+0x470>
  411b12:	call   4101f0 <__swc_fn_23cea7fa_000116_3f5cfdef>
  411b17:	jmp    411b25 <__swc_fn_23cea7fa_000146_d2097256+0x10c5>
  411b19:	lea    rcx,[rip+0x1a60]        # 413580 <__swc_rdata_base_23cea7fa+0x470>
  411b20:	call   4101f0 <__swc_fn_23cea7fa_000116_3f5cfdef>
  411b25:	add    rdi,0x1
  411b29:	sub    rsi,0x1
  411b2d:	vmovups xmm0,xmm12
  411b32:	vmovsd xmm6,QWORD PTR [rip+0x1a56]        # 413590 <__swc_rdata_base_23cea7fa+0x480>
  411b3a:	test   rsi,rsi
  411b3d:	jne    410b70 <__swc_fn_23cea7fa_000146_d2097256+0x110>
  411b43:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  411b4c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  411b55:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  411b5e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411b67:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411b70:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411b79:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411b82:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  411b8b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411b94:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  411b9d:	add    rsp,0x4e8
  411ba4:	pop    r15
  411ba6:	pop    r13
  411ba8:	pop    r12
  411baa:	pop    rdi
  411bab:	pop    rsi
  411bac:	pop    rbx
  411bad:	ret
	...

0000000000411bb0 <__swc_fn_23cea7fa_000149_365b4daf>:
  411bb0:	vxorps xmm0,xmm0,xmm0
  411bb4:	vmovups XMMWORD PTR [rcx],xmm0
  411bb8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411bbd:	ret
	...

0000000000411bc0 <__swc_fn_23cea7fa_000152_365b4daf>:
  411bc0:	vxorps xmm0,xmm0,xmm0
  411bc4:	vmovups XMMWORD PTR [rcx],xmm0
  411bc8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411bcd:	vxorps xmm0,xmm0,xmm0
  411bd1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411bd6:	vmovups xmm0,XMMWORD PTR [rip+0x1ac2]        # 4136a0 <__swc_rdata_base_23cea7fa+0x590>
  411bde:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411be3:	vxorps xmm0,xmm0,xmm0
  411be7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411bec:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411bf1:	vxorps xmm0,xmm0,xmm0
  411bf5:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  411bfa:	mov    QWORD PTR [rcx+0x70],0x0
  411c02:	ret
	...

0000000000411c10 <__swc_fn_23cea7fa_000155_365b4daf>:
  411c10:	vxorps xmm0,xmm0,xmm0
  411c14:	vmovups XMMWORD PTR [rcx],xmm0
  411c18:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411c1d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411c22:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411c27:	ret
	...

0000000000411c30 <__swc_fn_23cea7fa_000158_31e09513>:
  411c30:	push   rsi
  411c31:	push   rdi
  411c32:	sub    rsp,0x8
  411c36:	mov    rsi,rcx
  411c39:	mov    rdi,QWORD PTR [rsi+0x50]
  411c3d:	test   rdi,rdi
  411c40:	je     411c47 <__swc_fn_23cea7fa_000158_31e09513+0x17>
  411c42:	mov    rcx,rsi
  411c45:	call   rdi
  411c47:	mov    QWORD PTR [rsi+0x20],0x0
  411c4f:	mov    rax,QWORD PTR [rsi+0x30]
  411c53:	test   rax,rax
  411c56:	je     411c84 <__swc_fn_23cea7fa_000158_31e09513+0x54>
  411c58:	nop    DWORD PTR [rax+rax*1+0x0]
  411c60:	mov    rdi,QWORD PTR [rax+0x8]
  411c64:	mov    rcx,rsi
  411c67:	mov    rdx,QWORD PTR [rax+0x10]
  411c6b:	mov    rax,QWORD PTR [rax+0x18]
  411c6f:	mov    r8,rax
  411c72:	call   409e90 <__swc_fn_23cea7fa_000156_9e2052d6>
  411c77:	mov    QWORD PTR [rsi+0x30],rdi
  411c7b:	mov    rax,QWORD PTR [rsi+0x30]
  411c7f:	test   rax,rax
  411c82:	jne    411c60 <__swc_fn_23cea7fa_000158_31e09513+0x30>
  411c84:	mov    QWORD PTR [rsi+0x38],0x0
  411c8c:	add    rsp,0x8
  411c90:	pop    rdi
  411c91:	pop    rsi
  411c92:	ret
	...

0000000000411ca0 <__swc_fn_23cea7fa_000161_b553c03d>:
  411ca0:	push   rbx
  411ca1:	push   rsi
  411ca2:	push   rdi
  411ca3:	push   r12
  411ca5:	sub    rsp,0x188
  411cac:	mov    rbx,rcx
  411caf:	lea    rsi,[rip+0x150da]        # 426d90 <__swc_bss_base_23cea7fa+0x2d50>
  411cb6:	mov    rcx,rsi
  411cb9:	call   4098a0 <__swc_fn_23cea7fa_000135_db32cc57>
  411cbe:	mov    rax,QWORD PTR [rip+0x150d3]        # 426d98 <__swc_bss_base_23cea7fa+0x2d58>
  411cc5:	mov    rdi,rax
  411cc8:	test   rdi,rdi
  411ccb:	je     411cf9 <__swc_fn_23cea7fa_000161_b553c03d+0x59>
  411ccd:	nop    DWORD PTR [rax]
  411cd0:	cmp    QWORD PTR [rdi+0x8],rbx
  411cd4:	jne    411cee <__swc_fn_23cea7fa_000161_b553c03d+0x4e>
  411cd6:	mov    rcx,rsi
  411cd9:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  411cde:	mov    rax,rdi
  411ce1:	add    rsp,0x188
  411ce8:	pop    r12
  411cea:	pop    rdi
  411ceb:	pop    rsi
  411cec:	pop    rbx
  411ced:	ret
  411cee:	mov    rax,QWORD PTR [rdi]
  411cf1:	mov    rdi,rax
  411cf4:	test   rax,rax
  411cf7:	jne    411cd0 <__swc_fn_23cea7fa_000161_b553c03d+0x30>
  411cf9:	call   40ce80 <__swc_fn_23cea7fa_000139_e4a7a8b1>
  411cfe:	mov    rdi,rax
  411d01:	test   rax,rax
  411d04:	jne    411d1d <__swc_fn_23cea7fa_000161_b553c03d+0x7d>
  411d06:	mov    rcx,rsi
  411d09:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  411d0e:	xor    eax,eax
  411d10:	add    rsp,0x188
  411d17:	pop    r12
  411d19:	pop    rdi
  411d1a:	pop    rsi
  411d1b:	pop    rbx
  411d1c:	ret
  411d1d:	lea    rax,[rsp+0x18]
  411d22:	mov    QWORD PTR [rax+0x10],0x0
  411d2a:	mov    QWORD PTR [rax+0x18],0x0
  411d32:	mov    DWORD PTR [rax+0x20],0x0
  411d39:	mov    BYTE PTR [rax+0x24],0x0
  411d3d:	mov    rax,QWORD PTR [rip+0x15054]        # 426d98 <__swc_bss_base_23cea7fa+0x2d58>
  411d44:	mov    QWORD PTR [rsp+0x18],rax
  411d49:	mov    QWORD PTR [rsp+0x20],rbx
  411d4e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411d54:	vmovups XMMWORD PTR [rdi],xmm0
  411d58:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  411d5e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  411d63:	mov    rax,QWORD PTR [rsp+0x38]
  411d68:	mov    QWORD PTR [rdi+0x20],rax
  411d6c:	mov    QWORD PTR [rip+0x15025],rdi        # 426d98 <__swc_bss_base_23cea7fa+0x2d58>
  411d73:	lea    rax,[rsp+0x40]
  411d78:	mov    QWORD PTR [rax],0x0
  411d7f:	mov    rcx,rbx
  411d82:	mov    rdx,rax
  411d85:	call   409980 <__swc_fn_23cea7fa_000141_5e493395>
  411d8a:	mov    rbx,rax
  411d8d:	test   rax,rax
  411d90:	jne    411daa <__swc_fn_23cea7fa_000161_b553c03d+0x10a>
  411d92:	mov    rcx,rsi
  411d95:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  411d9a:	mov    rax,rdi
  411d9d:	add    rsp,0x188
  411da4:	pop    r12
  411da6:	pop    rdi
  411da7:	pop    rsi
  411da8:	pop    rbx
  411da9:	ret
  411daa:	lea    r12,[rsp+0x50]
  411daf:	mov    QWORD PTR [r12],0x0
  411db7:	mov    rcx,rbx
  411dba:	mov    rdx,QWORD PTR [rsp+0x40]
  411dbf:	mov    r8,r12
  411dc2:	call   40cf30 <__swc_fn_23cea7fa_000142_89a6ef72>
  411dc7:	test   rax,rax
  411dca:	jne    411de4 <__swc_fn_23cea7fa_000161_b553c03d+0x144>
  411dcc:	mov    rcx,rsi
  411dcf:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  411dd4:	mov    rax,rdi
  411dd7:	add    rsp,0x188
  411dde:	pop    r12
  411de0:	pop    rdi
  411de1:	pop    rsi
  411de2:	pop    rbx
  411de3:	ret
  411de4:	cmp    QWORD PTR [r12],0x10
  411de9:	jb     411eec <__swc_fn_23cea7fa_000161_b553c03d+0x24c>
  411def:	mov    ecx,DWORD PTR [rax]
  411df1:	cmp    ecx,0x42445753
  411df7:	jne    411eec <__swc_fn_23cea7fa_000161_b553c03d+0x24c>
  411dfd:	mov    ecx,DWORD PTR [rax+0x4]
  411e00:	cmp    ecx,0x1
  411e03:	jne    411eec <__swc_fn_23cea7fa_000161_b553c03d+0x24c>
  411e09:	mov    ecx,DWORD PTR [rax+0x8]
  411e0c:	mov    edx,DWORD PTR [rax+0xc]
  411e0f:	imul   r8,rcx,0x14
  411e13:	mov    r9,QWORD PTR [rsp+0x50]
  411e18:	sub    r9,0x10
  411e1c:	cmp    r8,r9
  411e1f:	ja     411eec <__swc_fn_23cea7fa_000161_b553c03d+0x24c>
  411e25:	lea    r8,[r8+0x10]
  411e29:	cmp    rdx,r8
  411e2c:	jb     411eec <__swc_fn_23cea7fa_000161_b553c03d+0x24c>
  411e32:	mov    r8,QWORD PTR [rsp+0x50]
  411e37:	cmp    rdx,r8
  411e3a:	ja     411eec <__swc_fn_23cea7fa_000161_b553c03d+0x24c>
  411e40:	xor    r8d,r8d
  411e43:	test   rcx,rcx
  411e46:	jbe    411f12 <__swc_fn_23cea7fa_000161_b553c03d+0x272>
  411e4c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  411e52:	cs nop WORD PTR [rax+rax*1+0x0]
  411e5c:	nop    DWORD PTR [rax+0x0]
  411e60:	imul   r9,r8,0x14
  411e64:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  411e69:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  411e6e:	add    r10,r11
  411e71:	movabs r11,0x100000000
  411e7b:	cmp    r10,r11
  411e7e:	ja     411eec <__swc_fn_23cea7fa_000161_b553c03d+0x24c>
  411e80:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  411e85:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  411e8a:	test   r10d,r10d
  411e8d:	setne  r11b
  411e91:	je     411eab <__swc_fn_23cea7fa_000161_b553c03d+0x20b>
  411e93:	cmp    r10d,edx
  411e96:	setb   r11b
  411e9a:	jb     411eab <__swc_fn_23cea7fa_000161_b553c03d+0x20b>
  411e9c:	vmovq  r11,xmm1
  411ea1:	cmp    r10,r11
  411ea4:	setae  r10b
  411ea8:	mov    r11b,r10b
  411eab:	mov    r10,r11
  411eae:	test   r11b,r11b
  411eb1:	jne    411ed8 <__swc_fn_23cea7fa_000161_b553c03d+0x238>
  411eb3:	test   r9d,r9d
  411eb6:	setne  r10b
  411eba:	je     411ed8 <__swc_fn_23cea7fa_000161_b553c03d+0x238>
  411ebc:	cmp    r9d,edx
  411ebf:	setb   r10b
  411ec3:	jb     411ed8 <__swc_fn_23cea7fa_000161_b553c03d+0x238>
  411ec5:	vmovq  r10,xmm1
  411eca:	cmp    r9,r10
  411ecd:	setae  r9b
  411ed1:	movzx  r9d,r9b
  411ed5:	mov    r10b,r9b
  411ed8:	test   r10b,r10b
  411edb:	jne    411eec <__swc_fn_23cea7fa_000161_b553c03d+0x24c>
  411edd:	add    r8,0x1
  411ee1:	cmp    r8,rcx
  411ee4:	jb     411e60 <__swc_fn_23cea7fa_000161_b553c03d+0x1c0>
  411eea:	jmp    411f12 <__swc_fn_23cea7fa_000161_b553c03d+0x272>
  411eec:	xor    ecx,ecx
  411eee:	cmp    rax,rbx
  411ef1:	cmovne rcx,rax
  411ef5:	call   4109b0 <__swc_fn_23cea7fa_000143_b7ad855f>
  411efa:	mov    rcx,rsi
  411efd:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  411f02:	mov    rax,rdi
  411f05:	add    rsp,0x188
  411f0c:	pop    r12
  411f0e:	pop    rdi
  411f0f:	pop    rsi
  411f10:	pop    rbx
  411f11:	ret
  411f12:	mov    QWORD PTR [rdi+0x10],rax
  411f16:	mov    rcx,QWORD PTR [rsp+0x50]
  411f1b:	mov    QWORD PTR [rdi+0x18],rcx
  411f1f:	mov    eax,DWORD PTR [rax+0x8]
  411f22:	mov    DWORD PTR [rdi+0x20],eax
  411f25:	rex mov BYTE PTR [rdi+0x24],0x1
  411f2a:	mov    rcx,rsi
  411f2d:	call   40ce70 <__swc_fn_23cea7fa_000136_d579ef75>
  411f32:	mov    rax,rdi
  411f35:	add    rsp,0x188
  411f3c:	pop    r12
  411f3e:	pop    rdi
  411f3f:	pop    rsi
  411f40:	pop    rbx
  411f41:	ret
	...

0000000000411f50 <__swc_fn_23cea7fa_000164_d25850aa>:
  411f50:	push   rsi
  411f51:	push   rdi
  411f52:	push   r12
  411f54:	mov    rsi,rdx
  411f57:	mov    rdi,rcx
  411f5a:	mov    rcx,QWORD PTR [rip+0x14ddf]        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  411f61:	test   rcx,rcx
  411f64:	jne    411f76 <__swc_fn_23cea7fa_000164_d25850aa+0x26>
  411f66:	call   40a1a0 <__swc_fn_23cea7fa_000165_56054fe7>
  411f6b:	lea    rcx,[rax+0x1]
  411f6f:	mov    QWORD PTR [rip+0x14dca],rcx        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  411f76:	dec    rcx
  411f79:	call   411fa0 <__swc_fn_23cea7fa_000167_39c041ad>
  411f7e:	mov    r12,QWORD PTR [rax+0xbe0]
  411f85:	test   r12,r12
  411f88:	setne  al
  411f8b:	je     411f96 <__swc_fn_23cea7fa_000164_d25850aa+0x46>
  411f8d:	mov    rcx,rdi
  411f90:	mov    rdx,rsi
  411f93:	call   r12
  411f96:	pop    r12
  411f98:	pop    rdi
  411f99:	pop    rsi
  411f9a:	ret
  411f9b:	add    BYTE PTR [rax],al
  411f9d:	add    BYTE PTR [rax],al
	...

0000000000411fa0 <__swc_fn_23cea7fa_000167_39c041ad>:
  411fa0:	push   r12
  411fa2:	push   rdi
  411fa3:	push   rsi
  411fa4:	sub    rsp,0xd0
  411fab:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  411fb1:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  411fb7:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  411fbd:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  411fc3:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  411fc9:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  411fcf:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  411fd8:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  411fe1:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  411fea:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  411ff3:	mov    r12,rcx
  411ff6:	mov    edi,ecx
  411ff8:	xor    eax,eax
  411ffa:	call   407000 <pthread_getspecific@plt>
  411fff:	test   rax,rax
  412002:	je     412006 <__swc_fn_23cea7fa_000167_39c041ad+0x66>
  412004:	jmp    41200e <__swc_fn_23cea7fa_000167_39c041ad+0x6e>
  412006:	mov    rcx,r12
  412009:	call   40a200 <__swc_fn_23cea7fa_000168_0ad81c51>
  41200e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  412014:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  41201a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  412020:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  412026:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  41202c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  412032:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  41203b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  412044:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  41204d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  412056:	add    rsp,0xd0
  41205d:	pop    rsi
  41205e:	pop    rdi
  41205f:	pop    r12
  412061:	ret
	...

0000000000412070 <__swc_fn_23cea7fa_000170_4dbacba0>:
  412070:	push   rsi
  412071:	sub    rsp,0x30
  412075:	lea    rsi,[rip+0x14d2c]        # 426da8 <__swc_bss_base_23cea7fa+0x2d68>
  41207c:	mov    rax,QWORD PTR [rsi]
  41207f:	test   rax,rax
  412082:	je     41208a <__swc_fn_23cea7fa_000170_4dbacba0+0x1a>
  412084:	add    rsp,0x30
  412088:	pop    rsi
  412089:	ret
  41208a:	mov    ecx,0x3
  41208f:	mov    edx,0x10
  412094:	call   40fb10 <__swc_fn_23cea7fa_000107_c8d4a68e>
  412099:	test   rax,rax
  41209c:	jne    4120ad <__swc_fn_23cea7fa_000170_4dbacba0+0x3d>
  41209e:	mov    QWORD PTR [rsp+0x18],rax
  4120a3:	call   40c9d0 <__swc_fn_23cea7fa_000118_591530fe>
  4120a8:	mov    rax,QWORD PTR [rsp+0x18]
  4120ad:	mov    rcx,rax
  4120b0:	xchg   QWORD PTR [rsi],rcx
  4120b3:	add    rsp,0x30
  4120b7:	pop    rsi
  4120b8:	ret
  4120b9:	add    BYTE PTR [rax],al
  4120bb:	add    BYTE PTR [rax],al
  4120bd:	add    BYTE PTR [rax],al
	...

00000000004120c0 <__swc_fn_23cea7fa_000173_e17a224b>:
  4120c0:	push   rsi
  4120c1:	push   rdi
  4120c2:	sub    rsp,0x8
  4120c6:	mov    rsi,rdx
  4120c9:	mov    rdi,rcx
  4120cc:	mov    rax,QWORD PTR [rsi+0x8]
  4120d0:	test   rax,rax
  4120d3:	je     4120dd <__swc_fn_23cea7fa_000173_e17a224b+0x1d>
  4120d5:	mov    rcx,QWORD PTR [rsi]
  4120d8:	mov    QWORD PTR [rax],rcx
  4120db:	jmp    4120e4 <__swc_fn_23cea7fa_000173_e17a224b+0x24>
  4120dd:	mov    rax,QWORD PTR [rsi]
  4120e0:	mov    QWORD PTR [rdi+0x8],rax
  4120e4:	mov    rax,QWORD PTR [rsi]
  4120e7:	test   rax,rax
  4120ea:	je     4120f4 <__swc_fn_23cea7fa_000173_e17a224b+0x34>
  4120ec:	mov    rcx,QWORD PTR [rsi+0x8]
  4120f0:	mov    QWORD PTR [rax+0x8],rcx
  4120f4:	mov    rcx,rdi
  4120f7:	mov    rdx,QWORD PTR [rsi+0x10]
  4120fb:	mov    r8,QWORD PTR [rsi+0x18]
  4120ff:	mov    r9,0xffffffffffffffff
  412106:	call   40d580 <__swc_fn_23cea7fa_000172_1751ecdd>
  41210b:	mov    QWORD PTR [rsi+0x18],0x0
  412113:	mov    rax,QWORD PTR [rdi+0x8]
  412117:	test   rax,rax
  41211a:	jne    41212c <__swc_fn_23cea7fa_000173_e17a224b+0x6c>
  41211c:	call   412070 <__swc_fn_23cea7fa_000170_4dbacba0>
  412121:	xor    ecx,ecx
  412123:	mov    QWORD PTR [rax+0x8],rcx
  412127:	xor    ecx,ecx
  412129:	mov    QWORD PTR [rax],rcx
  41212c:	add    rsp,0x8
  412130:	pop    rdi
  412131:	pop    rsi
  412132:	ret
	...

0000000000412140 <__swc_fn_23cea7fa_000176_5d3d19bd>:
  412140:	push   rbx
  412141:	sub    rsp,0x70
  412145:	test   rcx,rcx
  412148:	jne    412150 <__swc_fn_23cea7fa_000176_5d3d19bd+0x10>
  41214a:	add    rsp,0x70
  41214e:	pop    rbx
  41214f:	ret
  412150:	vxorps xmm0,xmm0,xmm0
  412154:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  41215a:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  412160:	vzeroupper
  412163:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  412169:	lea    rax,[rcx-0x10]
  41216d:	mov    QWORD PTR [rsp+0x48],rax
  412172:	mov    rax,QWORD PTR [rcx-0x10]
  412176:	mov    QWORD PTR [rsp+0x50],rax
  41217b:	mov    rcx,QWORD PTR [rip+0x14bbe]        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  412182:	test   rcx,rcx
  412185:	jne    412197 <__swc_fn_23cea7fa_000176_5d3d19bd+0x57>
  412187:	call   40a1a0 <__swc_fn_23cea7fa_000165_56054fe7>
  41218c:	lea    rcx,[rax+0x1]
  412190:	mov    QWORD PTR [rip+0x14ba9],rcx        # 426d40 <__swc_bss_base_23cea7fa+0x2d00>
  412197:	dec    rcx
  41219a:	call   411fa0 <__swc_fn_23cea7fa_000167_39c041ad>
  41219f:	mov    rcx,QWORD PTR [rax]
  4121a2:	lea    rdx,[rsp+0x8]
  4121a7:	mov    rbx,QWORD PTR [rax+0x8]
  4121ab:	mov    rbx,QWORD PTR [rbx+0x18]
  4121af:	call   rbx
  4121b1:	add    rsp,0x70
  4121b5:	pop    rbx
  4121b6:	ret
