
/workspace/prompt2-20261115/batch5-final-micro/new/chacha/chacha:     file format elf64-x86-64


Disassembly of section .text:

0000000000410980 <__swc_fn_3464c816_000149_6203dca2>:
  410980:	push   rbx
  410981:	push   rsi
  410982:	push   rdi
  410983:	push   r12
  410985:	push   r13
  410987:	push   r15
  410989:	sub    rsp,0x4e8
  410990:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  410999:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  4109a2:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  4109ab:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  4109b4:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  4109bd:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  4109c6:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  4109cf:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  4109d8:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  4109e1:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  4109ea:	mov    rbx,QWORD PTR [rcx]
  4109ed:	mov    rcx,QWORD PTR [rcx+0x8]
  4109f1:	mov    rsi,rcx
  4109f4:	xor    edi,edi
  4109f6:	vmovsd xmm6,QWORD PTR [rip+0x2c92]        # 413690 <__swc_rdata_base_3464c816+0x580>
  4109fe:	vmovsd xmm7,QWORD PTR [rip+0x2c93]        # 413699 <__swc_rdata_base_3464c816+0x589>
  410a06:	vmovsd xmm8,QWORD PTR [rip+0x2c94]        # 4136a2 <__swc_rdata_base_3464c816+0x592>
  410a0e:	vmovsd xmm9,QWORD PTR [rip+0x2c95]        # 4136ab <__swc_rdata_base_3464c816+0x59b>
  410a16:	vmovsd xmm10,QWORD PTR [rip+0x2c96]        # 4136b4 <__swc_rdata_base_3464c816+0x5a4>
  410a1e:	vmovups xmm11,xmm6
  410a22:	vmovsd QWORD PTR [rsp+0x418],xmm7
  410a2b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  410a34:	vmovsd QWORD PTR [rsp+0x428],xmm9
  410a3d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  410a46:	vmovsd xmm15,QWORD PTR [rip+0x2c6f]        # 4136bd <__swc_rdata_base_3464c816+0x5ad>
  410a4e:	vmovups xmm14,xmm15
  410a53:	vmovups xmm0,xmm9
  410a58:	vmovsd QWORD PTR [rsp+0x438],xmm15
  410a61:	vmovups xmm13,xmm8
  410a66:	vmovsd QWORD PTR [rsp+0x440],xmm15
  410a6f:	test   rsi,rsi
  410a72:	je     411a63 <__swc_fn_3464c816_000149_6203dca2+0x10e3>
  410a78:	cs nop WORD PTR [rax+rax*1+0x0]
  410a82:	cs nop WORD PTR [rax+rax*1+0x0]
  410a8c:	nop    DWORD PTR [rax+0x0]
  410a90:	lea    rcx,[rdi+rdi*1]
  410a94:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  410a99:	vpshufd xmm3,xmm2,0xee
  410a9e:	vmovq  rcx,xmm3
  410aa3:	test   rcx,rcx
  410aa6:	je     410abc <__swc_fn_3464c816_000149_6203dca2+0x13c>
  410aa8:	test   DWORD PTR [rcx+0x28],0x400000
  410aaf:	je     410abc <__swc_fn_3464c816_000149_6203dca2+0x13c>
  410ab1:	mov    rdx,QWORD PTR [rcx+0x30]
  410ab5:	test   rdx,rdx
  410ab8:	cmovne rcx,rdx
  410abc:	test   DWORD PTR [rcx+0x28],0x1000
  410ac3:	je     410ae4 <__swc_fn_3464c816_000149_6203dca2+0x164>
  410ac5:	mov    rdx,QWORD PTR [rcx+0x40]
  410ac9:	mov    rcx,rdx
  410acc:	vmovq  r8,xmm2
  410ad1:	mov    r8,QWORD PTR [r8]
  410ad4:	mov    QWORD PTR [rsp+0x60],r8
  410ad9:	mov    QWORD PTR [rsp+0x68],rdx
  410ade:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  410ae4:	test   BYTE PTR [rcx+0x28],0x1
  410ae8:	jne    410af0 <__swc_fn_3464c816_000149_6203dca2+0x170>
  410aea:	vmovups xmm12,xmm0
  410aee:	jmp    410b0a <__swc_fn_3464c816_000149_6203dca2+0x18a>
  410af0:	vmovq  rax,xmm2
  410af5:	mov    rax,QWORD PTR [rax]
  410af8:	lea    rcx,[rax+0x10]
  410afc:	vmovups xmm12,xmm0
  410b00:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  410b05:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410b0a:	test   DWORD PTR [rcx+0x28],0x400
  410b11:	je     410b72 <__swc_fn_3464c816_000149_6203dca2+0x1f2>
  410b13:	vmovq  rax,xmm2
  410b18:	mov    rax,QWORD PTR [rax]
  410b1b:	xor    ecx,ecx
  410b1d:	test   rax,rax
  410b20:	je     410b50 <__swc_fn_3464c816_000149_6203dca2+0x1d0>
  410b22:	mov    rdx,rax
  410b25:	mov    r8b,BYTE PTR [rdx]
  410b28:	test   r8b,r8b
  410b2b:	je     410b50 <__swc_fn_3464c816_000149_6203dca2+0x1d0>
  410b2d:	cs nop WORD PTR [rax+rax*1+0x0]
  410b37:	nop    WORD PTR [rax+rax*1+0x0]
  410b40:	add    rdx,0x1
  410b44:	add    rcx,0x1
  410b48:	mov    r8b,BYTE PTR [rdx]
  410b4b:	test   r8b,r8b
  410b4e:	jne    410b40 <__swc_fn_3464c816_000149_6203dca2+0x1c0>
  410b50:	mov    QWORD PTR [rsp+0x88],rax
  410b58:	mov    QWORD PTR [rsp+0x90],rcx
  410b60:	lea    rcx,[rsp+0x88]
  410b68:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  410b6d:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410b72:	cmp    BYTE PTR [rcx+0x2c],0x6
  410b76:	jne    410b8d <__swc_fn_3464c816_000149_6203dca2+0x20d>
  410b78:	vmovq  rax,xmm2
  410b7d:	mov    rax,QWORD PTR [rax]
  410b80:	mov    rcx,rax
  410b83:	call   40a450 <__swc_fn_3464c816_000147_43c96957>
  410b88:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410b8d:	cmp    BYTE PTR [rcx+0x2c],0x1
  410b91:	jne    411a39 <__swc_fn_3464c816_000149_6203dca2+0x10b9>
  410b97:	vmovq  rdx,xmm2
  410b9c:	mov    cl,BYTE PTR [rcx+0x40]
  410b9f:	cmp    cl,0x7
  410ba2:	jb     410be5 <__swc_fn_3464c816_000149_6203dca2+0x265>
  410ba4:	je     410c58 <__swc_fn_3464c816_000149_6203dca2+0x2d8>
  410baa:	cmp    cl,0x8
  410bad:	je     410c64 <__swc_fn_3464c816_000149_6203dca2+0x2e4>
  410bb3:	cmp    cl,0x9
  410bb6:	je     410c7d <__swc_fn_3464c816_000149_6203dca2+0x2fd>
  410bbc:	cmp    cl,0xa
  410bbf:	je     411344 <__swc_fn_3464c816_000149_6203dca2+0x9c4>
  410bc5:	cmp    cl,0xb
  410bc8:	je     411a0b <__swc_fn_3464c816_000149_6203dca2+0x108b>
  410bce:	cmp    cl,0xc
  410bd1:	je     410c71 <__swc_fn_3464c816_000149_6203dca2+0x2f1>
  410bd7:	cmp    cl,0xd
  410bda:	je     411a01 <__swc_fn_3464c816_000149_6203dca2+0x1081>
  410be0:	jmp    411a2b <__swc_fn_3464c816_000149_6203dca2+0x10ab>
  410be5:	cmp    cl,0x1
  410be8:	je     410c08 <__swc_fn_3464c816_000149_6203dca2+0x288>
  410bea:	cmp    cl,0x2
  410bed:	je     410c16 <__swc_fn_3464c816_000149_6203dca2+0x296>
  410bef:	cmp    cl,0x3
  410bf2:	je     410c24 <__swc_fn_3464c816_000149_6203dca2+0x2a4>
  410bf4:	cmp    cl,0x4
  410bf7:	je     410c31 <__swc_fn_3464c816_000149_6203dca2+0x2b1>
  410bf9:	cmp    cl,0x5
  410bfc:	je     410c3e <__swc_fn_3464c816_000149_6203dca2+0x2be>
  410bfe:	cmp    cl,0x6
  410c01:	je     410c4b <__swc_fn_3464c816_000149_6203dca2+0x2cb>
  410c03:	jmp    411a2b <__swc_fn_3464c816_000149_6203dca2+0x10ab>
  410c08:	movsx  rcx,BYTE PTR [rdx]
  410c0c:	call   40d6c0 <__swc_fn_3464c816_000148_2eb804cc>
  410c11:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410c16:	movsx  rcx,WORD PTR [rdx]
  410c1a:	call   40d6c0 <__swc_fn_3464c816_000148_2eb804cc>
  410c1f:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410c24:	movsxd rcx,DWORD PTR [rdx]
  410c27:	call   40d6c0 <__swc_fn_3464c816_000148_2eb804cc>
  410c2c:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410c31:	mov    rcx,QWORD PTR [rdx]
  410c34:	call   40d6c0 <__swc_fn_3464c816_000148_2eb804cc>
  410c39:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410c3e:	movzx  ecx,BYTE PTR [rdx]
  410c41:	call   40a450 <__swc_fn_3464c816_000147_43c96957>
  410c46:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410c4b:	movzx  ecx,WORD PTR [rdx]
  410c4e:	call   40a450 <__swc_fn_3464c816_000147_43c96957>
  410c53:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410c58:	mov    ecx,DWORD PTR [rdx]
  410c5a:	call   40a450 <__swc_fn_3464c816_000147_43c96957>
  410c5f:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410c64:	mov    rcx,QWORD PTR [rdx]
  410c67:	call   40a450 <__swc_fn_3464c816_000147_43c96957>
  410c6c:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410c71:	mov    ecx,DWORD PTR [rdx]
  410c73:	call   40a450 <__swc_fn_3464c816_000147_43c96957>
  410c78:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  410c7d:	lea    rcx,[rsp+0xa8]
  410c85:	vxorps xmm0,xmm0,xmm0
  410c89:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  410c92:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  410c9b:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  410ca4:	vzeroupper
  410ca7:	mov    DWORD PTR [rsp+0x108],0x0
  410cb2:	vxorpd xmm0,xmm0,xmm0
  410cb6:	vmovss xmm1,DWORD PTR [rdx]
  410cba:	vcvtss2sd xmm0,xmm0,xmm1
  410cbe:	vmovsd xmm1,xmm1,xmm0
  410cc2:	vcomisd xmm0,xmm0
  410cc6:	setne  dl
  410cc9:	movzx  edx,dl
  410ccc:	setp   r8b
  410cd0:	movzx  r8d,r8b
  410cd4:	or     edx,r8d
  410cd7:	test   dl,dl
  410cd9:	je     410ce6 <__swc_fn_3464c816_000149_6203dca2+0x366>
  410cdb:	mov    DWORD PTR [rcx],0x6e616e
  410ce1:	jmp    4112d8 <__swc_fn_3464c816_000149_6203dca2+0x958>
  410ce6:	vcomisd xmm1,xmm6
  410cea:	ja     410cf2 <__swc_fn_3464c816_000149_6203dca2+0x372>
  410cec:	vcomisd xmm7,xmm1
  410cf0:	jbe    410d16 <__swc_fn_3464c816_000149_6203dca2+0x396>
  410cf2:	vxorpd xmm0,xmm0,xmm0
  410cf6:	vcomisd xmm0,xmm1
  410cfa:	jbe    410d0b <__swc_fn_3464c816_000149_6203dca2+0x38b>
  410cfc:	mov    DWORD PTR [rcx],0x666e692d
  410d02:	mov    BYTE PTR [rcx+0x4],0x0
  410d06:	jmp    4112d8 <__swc_fn_3464c816_000149_6203dca2+0x958>
  410d0b:	mov    DWORD PTR [rcx],0x666e69
  410d11:	jmp    4112d8 <__swc_fn_3464c816_000149_6203dca2+0x958>
  410d16:	vcomisd xmm1,xmm8
  410d1b:	jae    410d27 <__swc_fn_3464c816_000149_6203dca2+0x3a7>
  410d1d:	vcomisd xmm9,xmm1
  410d21:	jbe    41109e <__swc_fn_3464c816_000149_6203dca2+0x71e>
  410d27:	vmovups xmm0,xmm1
  410d2b:	vxorpd xmm2,xmm2,xmm2
  410d2f:	vcomisd xmm2,xmm1
  410d33:	jbe    410d43 <__swc_fn_3464c816_000149_6203dca2+0x3c3>
  410d35:	vmovsd xmm1,xmm1,xmm0
  410d39:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x290f]        # 413650 <__swc_rdata_base_3464c816+0x540>
  410d41:	jmp    410d47 <__swc_fn_3464c816_000149_6203dca2+0x3c7>
  410d43:	vmovsd xmm1,xmm1,xmm0
  410d47:	xor    r8d,r8d
  410d4a:	vcomisd xmm1,xmm15
  410d4f:	jb     410d70 <__swc_fn_3464c816_000149_6203dca2+0x3f0>
  410d51:	cs nop WORD PTR [rax+rax*1+0x0]
  410d5b:	nop    DWORD PTR [rax+rax*1+0x0]
  410d60:	vdivsd xmm1,xmm1,xmm15
  410d65:	add    r8,0x1
  410d69:	vcomisd xmm1,xmm15
  410d6e:	jae    410d60 <__swc_fn_3464c816_000149_6203dca2+0x3e0>
  410d70:	mov    r9,rcx
  410d73:	vxorpd xmm2,xmm2,xmm2
  410d77:	vcomisd xmm2,xmm0
  410d7b:	jbe    410d84 <__swc_fn_3464c816_000149_6203dca2+0x404>
  410d7d:	mov    BYTE PTR [rcx],0x2d
  410d80:	lea    r9,[rcx+0x1]
  410d84:	vcvttsd2si rdx,xmm1
  410d89:	mov    r10b,dl
  410d8c:	add    r10b,0x30
  410d90:	mov    BYTE PTR [r9],r10b
  410d93:	vxorpd xmm0,xmm0,xmm0
  410d97:	movzx  edx,dl
  410d9a:	vcvtsi2sd xmm0,xmm0,rdx
  410d9f:	vsubsd xmm0,xmm1,xmm0
  410da3:	vmulsd xmm1,xmm0,xmm15
  410da8:	mov    BYTE PTR [r9+0x1],0x2e
  410dad:	vcvttsd2si rdx,xmm1
  410db2:	mov    r10b,dl
  410db5:	add    r10b,0x30
  410db9:	mov    BYTE PTR [r9+0x2],r10b
  410dbd:	vxorpd xmm0,xmm0,xmm0
  410dc1:	movzx  edx,dl
  410dc4:	vcvtsi2sd xmm0,xmm0,rdx
  410dc9:	vsubsd xmm0,xmm1,xmm0
  410dcd:	vmulsd xmm1,xmm0,xmm15
  410dd2:	vcvttsd2si rdx,xmm1
  410dd7:	mov    r10b,dl
  410dda:	add    r10b,0x30
  410dde:	mov    BYTE PTR [r9+0x3],r10b
  410de2:	vxorpd xmm0,xmm0,xmm0
  410de6:	movzx  edx,dl
  410de9:	vcvtsi2sd xmm0,xmm0,rdx
  410dee:	vsubsd xmm0,xmm1,xmm0
  410df2:	vmulsd xmm1,xmm0,xmm15
  410df7:	vcvttsd2si rdx,xmm1
  410dfc:	mov    r10b,dl
  410dff:	add    r10b,0x30
  410e03:	mov    BYTE PTR [r9+0x4],r10b
  410e07:	vxorpd xmm0,xmm0,xmm0
  410e0b:	movzx  edx,dl
  410e0e:	vcvtsi2sd xmm0,xmm0,rdx
  410e13:	vsubsd xmm0,xmm1,xmm0
  410e17:	vmulsd xmm1,xmm0,xmm15
  410e1c:	vcvttsd2si rdx,xmm1
  410e21:	mov    r10b,dl
  410e24:	add    r10b,0x30
  410e28:	mov    BYTE PTR [r9+0x5],r10b
  410e2c:	vxorpd xmm0,xmm0,xmm0
  410e30:	movzx  edx,dl
  410e33:	vcvtsi2sd xmm0,xmm0,rdx
  410e38:	vsubsd xmm0,xmm1,xmm0
  410e3c:	vmulsd xmm1,xmm0,xmm15
  410e41:	vcvttsd2si rdx,xmm1
  410e46:	mov    r10b,dl
  410e49:	add    r10b,0x30
  410e4d:	mov    BYTE PTR [r9+0x6],r10b
  410e51:	vxorpd xmm0,xmm0,xmm0
  410e55:	movzx  edx,dl
  410e58:	vcvtsi2sd xmm0,xmm0,rdx
  410e5d:	vsubsd xmm0,xmm1,xmm0
  410e61:	vmulsd xmm1,xmm0,xmm15
  410e66:	vcvttsd2si rdx,xmm1
  410e6b:	mov    r10b,dl
  410e6e:	add    r10b,0x30
  410e72:	mov    BYTE PTR [r9+0x7],r10b
  410e76:	vxorpd xmm0,xmm0,xmm0
  410e7a:	movzx  edx,dl
  410e7d:	vcvtsi2sd xmm0,xmm0,rdx
  410e82:	vsubsd xmm0,xmm1,xmm0
  410e86:	vmulsd xmm1,xmm0,xmm15
  410e8b:	vcvttsd2si rdx,xmm1
  410e90:	mov    r10b,dl
  410e93:	add    r10b,0x30
  410e97:	mov    BYTE PTR [r9+0x8],r10b
  410e9b:	vxorpd xmm0,xmm0,xmm0
  410e9f:	movzx  edx,dl
  410ea2:	vcvtsi2sd xmm0,xmm0,rdx
  410ea7:	vsubsd xmm0,xmm1,xmm0
  410eab:	vmulsd xmm1,xmm0,xmm15
  410eb0:	vcvttsd2si rdx,xmm1
  410eb5:	mov    r10b,dl
  410eb8:	add    r10b,0x30
  410ebc:	mov    BYTE PTR [r9+0x9],r10b
  410ec0:	vxorpd xmm0,xmm0,xmm0
  410ec4:	movzx  edx,dl
  410ec7:	vcvtsi2sd xmm0,xmm0,rdx
  410ecc:	vsubsd xmm0,xmm1,xmm0
  410ed0:	vmulsd xmm1,xmm0,xmm15
  410ed5:	vcvttsd2si rdx,xmm1
  410eda:	mov    r10b,dl
  410edd:	add    r10b,0x30
  410ee1:	mov    BYTE PTR [r9+0xa],r10b
  410ee5:	vxorpd xmm0,xmm0,xmm0
  410ee9:	movzx  edx,dl
  410eec:	vcvtsi2sd xmm0,xmm0,rdx
  410ef1:	vsubsd xmm0,xmm1,xmm0
  410ef5:	vmulsd xmm1,xmm0,xmm15
  410efa:	vcvttsd2si rdx,xmm1
  410eff:	mov    r10b,dl
  410f02:	add    r10b,0x30
  410f06:	mov    BYTE PTR [r9+0xb],r10b
  410f0a:	lea    r10,[r9+0x4]
  410f0e:	vxorpd xmm0,xmm0,xmm0
  410f12:	movzx  edx,dl
  410f15:	vcvtsi2sd xmm0,xmm0,rdx
  410f1a:	vsubsd xmm0,xmm1,xmm0
  410f1e:	vmulsd xmm1,xmm0,xmm15
  410f23:	vcvttsd2si rdx,xmm1
  410f28:	mov    r11b,dl
  410f2b:	add    r11b,0x30
  410f2f:	mov    BYTE PTR [r9+0xc],r11b
  410f33:	vxorpd xmm0,xmm0,xmm0
  410f37:	movzx  edx,dl
  410f3a:	vcvtsi2sd xmm0,xmm0,rdx
  410f3f:	vsubsd xmm0,xmm1,xmm0
  410f43:	vmulsd xmm1,xmm0,xmm15
  410f48:	vcvttsd2si rdx,xmm1
  410f4d:	mov    r11b,dl
  410f50:	add    r11b,0x30
  410f54:	mov    BYTE PTR [r9+0xd],r11b
  410f58:	lea    r10,[r10+0x2]
  410f5c:	vxorpd xmm0,xmm0,xmm0
  410f60:	movzx  edx,dl
  410f63:	vcvtsi2sd xmm0,xmm0,rdx
  410f68:	vsubsd xmm0,xmm1,xmm0
  410f6c:	vmulsd xmm1,xmm0,xmm15
  410f71:	vcvttsd2si rdx,xmm1
  410f76:	mov    r11b,dl
  410f79:	add    r11b,0x30
  410f7d:	mov    BYTE PTR [r9+0xe],r11b
  410f81:	vxorpd xmm0,xmm0,xmm0
  410f85:	movzx  edx,dl
  410f88:	vcvtsi2sd xmm0,xmm0,rdx
  410f8d:	vsubsd xmm0,xmm1,xmm0
  410f91:	vmulsd xmm1,xmm0,xmm15
  410f96:	vcvttsd2si rdx,xmm1
  410f9b:	mov    r11b,dl
  410f9e:	add    r11b,0x30
  410fa2:	mov    BYTE PTR [r9+0xf],r11b
  410fa6:	lea    r10,[r10+0x2]
  410faa:	lea    r10,[r10+0x2]
  410fae:	lea    r10,[r10+0x2]
  410fb2:	lea    r10,[r10+0x2]
  410fb6:	lea    r10,[r10+0x2]
  410fba:	vxorpd xmm0,xmm0,xmm0
  410fbe:	movzx  edx,dl
  410fc1:	vcvtsi2sd xmm0,xmm0,rdx
  410fc6:	vsubsd xmm0,xmm1,xmm0
  410fca:	vmulsd xmm1,xmm0,xmm15
  410fcf:	vcvttsd2si rdx,xmm1
  410fd4:	mov    r11b,dl
  410fd7:	add    r11b,0x30
  410fdb:	mov    BYTE PTR [r9+0x10],r11b
  410fdf:	vxorpd xmm0,xmm0,xmm0
  410fe3:	movzx  edx,dl
  410fe6:	vcvtsi2sd xmm0,xmm0,rdx
  410feb:	vsubsd xmm0,xmm1,xmm0
  410fef:	vmulsd xmm1,xmm0,xmm15
  410ff4:	vcvttsd2si rdx,xmm1
  410ff9:	add    dl,0x30
  410ffc:	mov    BYTE PTR [r9+0x11],dl
  411000:	mov    BYTE PTR [r10+0x2],0x65
  411005:	lea    r9,[r10+0x3]
  411009:	test   r8,r8
  41100c:	jl     411015 <__swc_fn_3464c816_000149_6203dca2+0x695>
  41100e:	mov    BYTE PTR [r9],0x2b
  411012:	inc    r9
  411015:	mov    r10,r9
  411018:	mov    rdx,r8
  41101b:	nop    DWORD PTR [rax+rax*1+0x0]
  411020:	mov    r11,rdx
  411023:	movabs rdx,0x6666666666666667
  41102d:	mov    rax,r11
  411030:	imul   rdx
  411033:	sar    rdx,0x2
  411037:	mov    r12,rdx
  41103a:	shr    rdx,0x3f
  41103e:	add    r12,rdx
  411041:	mov    rdx,r12
  411044:	imul   r13,r12,0xa
  411048:	sub    r11,r13
  41104b:	mov    r13,QWORD PTR [rip+0x25ee]        # 413640 <__swc_rdata_base_3464c816+0x530>
  411052:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411057:	mov    BYTE PTR [r10],r11b
  41105a:	lea    r11,[r10+0x1]
  41105e:	mov    r10,r11
  411061:	test   r12,r12
  411064:	jne    411020 <__swc_fn_3464c816_000149_6203dca2+0x6a0>
  411066:	test   r8,r8
  411069:	jge    411073 <__swc_fn_3464c816_000149_6203dca2+0x6f3>
  41106b:	mov    BYTE PTR [r11],0x2d
  41106f:	lea    r10,[r11+0x1]
  411073:	mov    BYTE PTR [r10],0x0
  411077:	sub    r10,0x1
  41107b:	nop    DWORD PTR [rax+rax*1+0x0]
  411080:	cmp    r9,r10
  411083:	jae    4112d8 <__swc_fn_3464c816_000149_6203dca2+0x958>
  411089:	mov    al,BYTE PTR [r10]
  41108c:	mov    dl,BYTE PTR [r9]
  41108f:	mov    BYTE PTR [r10],dl
  411092:	sub    r10,0x1
  411096:	mov    BYTE PTR [r9],al
  411099:	inc    r9
  41109c:	jmp    411080 <__swc_fn_3464c816_000149_6203dca2+0x700>
  41109e:	vcvttsd2si rdx,xmm1
  4110a3:	mov    r8,rdx
  4110a6:	vxorpd xmm0,xmm0,xmm0
  4110aa:	vcvtsi2sd xmm0,xmm0,rdx
  4110af:	vsubsd xmm0,xmm1,xmm0
  4110b3:	mov    r9d,0x8
  4110b9:	vxorpd xmm2,xmm2,xmm2
  4110bd:	vcomisd xmm2,xmm0
  4110c1:	jbe    4110cb <__swc_fn_3464c816_000149_6203dca2+0x74b>
  4110c3:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x2585]        # 413650 <__swc_rdata_base_3464c816+0x540>
  4110cb:	test   r9d,r9d
  4110ce:	je     4110da <__swc_fn_3464c816_000149_6203dca2+0x75a>
  4110d0:	vmulsd xmm0,xmm0,xmm14
  4110d5:	dec    r9d
  4110d8:	jne    4110d0 <__swc_fn_3464c816_000149_6203dca2+0x750>
  4110da:	vcvttsd2si r9,xmm0
  4110df:	mov    r10,r9
  4110e2:	vxorpd xmm2,xmm2,xmm2
  4110e6:	vcvtsi2sd xmm2,xmm2,r9
  4110eb:	vsubsd xmm0,xmm0,xmm2
  4110ef:	vcomisd xmm0,xmm10
  4110f4:	lea    r9,[r9+0x1]
  4110f8:	cmova  r10,r9
  4110fc:	cmp    r10,0x5f5e100
  411103:	jne    41111c <__swc_fn_3464c816_000149_6203dca2+0x79c>
  411105:	lea    r8,[rdx-0x1]
  411109:	vxorpd xmm0,xmm0,xmm0
  41110d:	vcomisd xmm0,xmm1
  411111:	lea    rdx,[rdx+0x1]
  411115:	cmovbe r8,rdx
  411119:	xor    r10d,r10d
  41111c:	mov    r9,rcx
  41111f:	test   r8,r8
  411122:	jne    411142 <__swc_fn_3464c816_000149_6203dca2+0x7c2>
  411124:	vxorpd xmm0,xmm0,xmm0
  411128:	vcomisd xmm0,xmm1
  41112c:	jbe    411135 <__swc_fn_3464c816_000149_6203dca2+0x7b5>
  41112e:	mov    BYTE PTR [rcx],0x2d
  411131:	lea    r9,[rcx+0x1]
  411135:	mov    BYTE PTR [r9],0x30
  411139:	add    r9,0x1
  41113d:	jmp    4111db <__swc_fn_3464c816_000149_6203dca2+0x85b>
  411142:	mov    r9,rcx
  411145:	mov    rdx,r8
  411148:	nop    DWORD PTR [rax+rax*1+0x0]
  411150:	mov    r11,rdx
  411153:	movabs rdx,0x6666666666666667
  41115d:	mov    r15,rax
  411160:	mov    rax,r11
  411163:	imul   rdx
  411166:	mov    r12,rdx
  411169:	mov    rax,r15
  41116c:	sar    r12,0x2
  411170:	mov    rdx,r12
  411173:	shr    rdx,0x3f
  411177:	add    r12,rdx
  41117a:	mov    rdx,r12
  41117d:	imul   r13,r12,0xa
  411181:	sub    r11,r13
  411184:	mov    r13,QWORD PTR [rip+0x24b5]        # 413640 <__swc_rdata_base_3464c816+0x530>
  41118b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411190:	mov    BYTE PTR [r9],r11b
  411193:	lea    r11,[r9+0x1]
  411197:	mov    r9,r11
  41119a:	test   r12,r12
  41119d:	jne    411150 <__swc_fn_3464c816_000149_6203dca2+0x7d0>
  41119f:	test   r8,r8
  4111a2:	jge    4111ac <__swc_fn_3464c816_000149_6203dca2+0x82c>
  4111a4:	mov    BYTE PTR [r11],0x2d
  4111a8:	lea    r9,[r11+0x1]
  4111ac:	mov    rdx,r9
  4111af:	mov    BYTE PTR [r9],0x0
  4111b3:	sub    r9,0x1
  4111b7:	mov    r8,rcx
  4111ba:	cmp    r8,r9
  4111bd:	jae    4111d8 <__swc_fn_3464c816_000149_6203dca2+0x858>
  4111bf:	nop
  4111c0:	mov    r11b,BYTE PTR [r9]
  4111c3:	mov    r12b,BYTE PTR [r8]
  4111c6:	mov    BYTE PTR [r9],r12b
  4111c9:	sub    r9,0x1
  4111cd:	mov    BYTE PTR [r8],r11b
  4111d0:	inc    r8
  4111d3:	cmp    r8,r9
  4111d6:	jb     4111c0 <__swc_fn_3464c816_000149_6203dca2+0x840>
  4111d8:	mov    r9,rdx
  4111db:	mov    BYTE PTR [r9],0x2e
  4111df:	add    r9,0x1
  4111e3:	xor    r8d,r8d
  4111e6:	test   r10,r10
  4111e9:	je     41122f <__swc_fn_3464c816_000149_6203dca2+0x8af>
  4111eb:	mov    r11d,0x989680
  4111f1:	cmp    r10,r11
  4111f4:	jge    41122f <__swc_fn_3464c816_000149_6203dca2+0x8af>
  4111f6:	cs nop WORD PTR [rax+rax*1+0x0]
  411200:	inc    r8d
  411203:	movabs rdx,0x6666666666666667
  41120d:	mov    r15,rax
  411210:	mov    rax,r11
  411213:	imul   rdx
  411216:	mov    r11,rdx
  411219:	mov    rax,r15
  41121c:	sar    r11,0x2
  411220:	mov    rdx,r11
  411223:	shr    rdx,0x3f
  411227:	add    r11,rdx
  41122a:	cmp    r10,r11
  41122d:	jl     411200 <__swc_fn_3464c816_000149_6203dca2+0x880>
  41122f:	test   r8d,r8d
  411232:	je     41124d <__swc_fn_3464c816_000149_6203dca2+0x8cd>
  411234:	cs nop WORD PTR [rax+rax*1+0x0]
  41123e:	xchg   ax,ax
  411240:	mov    BYTE PTR [r9],0x30
  411244:	add    r9,0x1
  411248:	dec    r8d
  41124b:	jne    411240 <__swc_fn_3464c816_000149_6203dca2+0x8c0>
  41124d:	mov    r8,r9
  411250:	mov    rdx,r10
  411253:	cs nop WORD PTR [rax+rax*1+0x0]
  41125d:	nop    DWORD PTR [rax]
  411260:	mov    r11,rdx
  411263:	movabs rdx,0x6666666666666667
  41126d:	mov    rax,r11
  411270:	imul   rdx
  411273:	sar    rdx,0x2
  411277:	mov    r12,rdx
  41127a:	shr    rdx,0x3f
  41127e:	add    r12,rdx
  411281:	mov    rdx,r12
  411284:	imul   r13,r12,0xa
  411288:	sub    r11,r13
  41128b:	mov    r13,QWORD PTR [rip+0x23ae]        # 413640 <__swc_rdata_base_3464c816+0x530>
  411292:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411297:	mov    BYTE PTR [r8],r11b
  41129a:	lea    r11,[r8+0x1]
  41129e:	mov    r8,r11
  4112a1:	test   r12,r12
  4112a4:	jne    411260 <__swc_fn_3464c816_000149_6203dca2+0x8e0>
  4112a6:	test   r10,r10
  4112a9:	jge    4112b3 <__swc_fn_3464c816_000149_6203dca2+0x933>
  4112ab:	mov    BYTE PTR [r11],0x2d
  4112af:	lea    r8,[r11+0x1]
  4112b3:	mov    BYTE PTR [r8],0x0
  4112b7:	sub    r8,0x1
  4112bb:	cmp    r9,r8
  4112be:	jae    4112d8 <__swc_fn_3464c816_000149_6203dca2+0x958>
  4112c0:	mov    al,BYTE PTR [r8]
  4112c3:	mov    dl,BYTE PTR [r9]
  4112c6:	mov    BYTE PTR [r8],dl
  4112c9:	sub    r8,0x1
  4112cd:	mov    BYTE PTR [r9],al
  4112d0:	inc    r9
  4112d3:	cmp    r9,r8
  4112d6:	jb     4112c0 <__swc_fn_3464c816_000149_6203dca2+0x940>
  4112d8:	xor    eax,eax
  4112da:	test   rcx,rcx
  4112dd:	je     411310 <__swc_fn_3464c816_000149_6203dca2+0x990>
  4112df:	mov    rdx,rcx
  4112e2:	mov    r8b,BYTE PTR [rdx]
  4112e5:	test   r8b,r8b
  4112e8:	je     411310 <__swc_fn_3464c816_000149_6203dca2+0x990>
  4112ea:	cs nop WORD PTR [rax+rax*1+0x0]
  4112f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4112fe:	xchg   ax,ax
  411300:	add    rdx,0x1
  411304:	add    rax,0x1
  411308:	mov    r8b,BYTE PTR [rdx]
  41130b:	test   r8b,r8b
  41130e:	jne    411300 <__swc_fn_3464c816_000149_6203dca2+0x980>
  411310:	mov    QWORD PTR [rsp+0x240],rcx
  411318:	mov    QWORD PTR [rsp+0x248],rax
  411320:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  411329:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  411332:	lea    rcx,[rsp+0x250]
  41133a:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  41133f:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  411344:	lea    rcx,[rsp+0x260]
  41134c:	vxorps xmm0,xmm0,xmm0
  411350:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  411359:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  411362:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  41136b:	vzeroupper
  41136e:	mov    DWORD PTR [rsp+0x2c0],0x0
  411379:	vmovsd xmm0,QWORD PTR [rdx]
  41137d:	vcomisd xmm0,xmm0
  411381:	setne  dl
  411384:	movzx  edx,dl
  411387:	setp   r8b
  41138b:	movzx  r8d,r8b
  41138f:	or     edx,r8d
  411392:	test   dl,dl
  411394:	je     4113a1 <__swc_fn_3464c816_000149_6203dca2+0xa21>
  411396:	mov    DWORD PTR [rcx],0x6e616e
  41139c:	jmp    4119a8 <__swc_fn_3464c816_000149_6203dca2+0x1028>
  4113a1:	vcomisd xmm0,xmm11
  4113a6:	ja     4113b7 <__swc_fn_3464c816_000149_6203dca2+0xa37>
  4113a8:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  4113b1:	vcomisd xmm6,xmm0
  4113b5:	jbe    4113db <__swc_fn_3464c816_000149_6203dca2+0xa5b>
  4113b7:	vxorpd xmm1,xmm1,xmm1
  4113bb:	vcomisd xmm1,xmm0
  4113bf:	jbe    4113d0 <__swc_fn_3464c816_000149_6203dca2+0xa50>
  4113c1:	mov    DWORD PTR [rcx],0x666e692d
  4113c7:	mov    BYTE PTR [rcx+0x4],0x0
  4113cb:	jmp    4119a8 <__swc_fn_3464c816_000149_6203dca2+0x1028>
  4113d0:	mov    DWORD PTR [rcx],0x666e69
  4113d6:	jmp    4119a8 <__swc_fn_3464c816_000149_6203dca2+0x1028>
  4113db:	vcomisd xmm0,xmm13
  4113e0:	jae    4113ec <__swc_fn_3464c816_000149_6203dca2+0xa6c>
  4113e2:	vcomisd xmm12,xmm0
  4113e6:	jbe    41174e <__swc_fn_3464c816_000149_6203dca2+0xdce>
  4113ec:	vmovups xmm1,xmm0
  4113f0:	vxorpd xmm2,xmm2,xmm2
  4113f4:	vcomisd xmm2,xmm0
  4113f8:	jbe    411408 <__swc_fn_3464c816_000149_6203dca2+0xa88>
  4113fa:	vmovsd xmm0,xmm0,xmm1
  4113fe:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x224a]        # 413650 <__swc_rdata_base_3464c816+0x540>
  411406:	jmp    41140c <__swc_fn_3464c816_000149_6203dca2+0xa8c>
  411408:	vmovsd xmm0,xmm0,xmm1
  41140c:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  411415:	xor    r8d,r8d
  411418:	vcomisd xmm0,xmm6
  41141c:	jb     41142e <__swc_fn_3464c816_000149_6203dca2+0xaae>
  41141e:	xchg   ax,ax
  411420:	vdivsd xmm0,xmm0,xmm6
  411424:	add    r8,0x1
  411428:	vcomisd xmm0,xmm6
  41142c:	jae    411420 <__swc_fn_3464c816_000149_6203dca2+0xaa0>
  41142e:	mov    r9,rcx
  411431:	vxorpd xmm2,xmm2,xmm2
  411435:	vcomisd xmm2,xmm1
  411439:	jbe    411442 <__swc_fn_3464c816_000149_6203dca2+0xac2>
  41143b:	mov    BYTE PTR [rcx],0x2d
  41143e:	lea    r9,[rcx+0x1]
  411442:	vcvttsd2si rdx,xmm0
  411447:	mov    r10b,dl
  41144a:	add    r10b,0x30
  41144e:	mov    BYTE PTR [r9],r10b
  411451:	vxorpd xmm1,xmm1,xmm1
  411455:	movzx  edx,dl
  411458:	vcvtsi2sd xmm1,xmm1,rdx
  41145d:	vsubsd xmm0,xmm0,xmm1
  411461:	vmulsd xmm0,xmm0,xmm6
  411465:	mov    BYTE PTR [r9+0x1],0x2e
  41146a:	vcvttsd2si rdx,xmm0
  41146f:	mov    r10b,dl
  411472:	add    r10b,0x30
  411476:	mov    BYTE PTR [r9+0x2],r10b
  41147a:	vxorpd xmm1,xmm1,xmm1
  41147e:	movzx  edx,dl
  411481:	vcvtsi2sd xmm1,xmm1,rdx
  411486:	vsubsd xmm0,xmm0,xmm1
  41148a:	vmulsd xmm0,xmm0,xmm6
  41148e:	vcvttsd2si rdx,xmm0
  411493:	mov    r10b,dl
  411496:	add    r10b,0x30
  41149a:	mov    BYTE PTR [r9+0x3],r10b
  41149e:	vxorpd xmm1,xmm1,xmm1
  4114a2:	movzx  edx,dl
  4114a5:	vcvtsi2sd xmm1,xmm1,rdx
  4114aa:	vsubsd xmm0,xmm0,xmm1
  4114ae:	vmulsd xmm0,xmm0,xmm6
  4114b2:	vcvttsd2si rdx,xmm0
  4114b7:	mov    r10b,dl
  4114ba:	add    r10b,0x30
  4114be:	mov    BYTE PTR [r9+0x4],r10b
  4114c2:	vxorpd xmm1,xmm1,xmm1
  4114c6:	movzx  edx,dl
  4114c9:	vcvtsi2sd xmm1,xmm1,rdx
  4114ce:	vsubsd xmm0,xmm0,xmm1
  4114d2:	vmulsd xmm0,xmm0,xmm6
  4114d6:	vcvttsd2si rdx,xmm0
  4114db:	mov    r10b,dl
  4114de:	add    r10b,0x30
  4114e2:	mov    BYTE PTR [r9+0x5],r10b
  4114e6:	vxorpd xmm1,xmm1,xmm1
  4114ea:	movzx  edx,dl
  4114ed:	vcvtsi2sd xmm1,xmm1,rdx
  4114f2:	vsubsd xmm0,xmm0,xmm1
  4114f6:	vmulsd xmm0,xmm0,xmm6
  4114fa:	vcvttsd2si rdx,xmm0
  4114ff:	mov    r10b,dl
  411502:	add    r10b,0x30
  411506:	mov    BYTE PTR [r9+0x6],r10b
  41150a:	vxorpd xmm1,xmm1,xmm1
  41150e:	movzx  edx,dl
  411511:	vcvtsi2sd xmm1,xmm1,rdx
  411516:	vsubsd xmm0,xmm0,xmm1
  41151a:	vmulsd xmm0,xmm0,xmm6
  41151e:	vcvttsd2si rdx,xmm0
  411523:	mov    r10b,dl
  411526:	add    r10b,0x30
  41152a:	mov    BYTE PTR [r9+0x7],r10b
  41152e:	vxorpd xmm1,xmm1,xmm1
  411532:	movzx  edx,dl
  411535:	vcvtsi2sd xmm1,xmm1,rdx
  41153a:	vsubsd xmm0,xmm0,xmm1
  41153e:	vmulsd xmm0,xmm0,xmm6
  411542:	vcvttsd2si rdx,xmm0
  411547:	mov    r10b,dl
  41154a:	add    r10b,0x30
  41154e:	mov    BYTE PTR [r9+0x8],r10b
  411552:	vxorpd xmm1,xmm1,xmm1
  411556:	movzx  edx,dl
  411559:	vcvtsi2sd xmm1,xmm1,rdx
  41155e:	vsubsd xmm0,xmm0,xmm1
  411562:	vmulsd xmm0,xmm0,xmm6
  411566:	vcvttsd2si rdx,xmm0
  41156b:	mov    r10b,dl
  41156e:	add    r10b,0x30
  411572:	mov    BYTE PTR [r9+0x9],r10b
  411576:	vxorpd xmm1,xmm1,xmm1
  41157a:	movzx  edx,dl
  41157d:	vcvtsi2sd xmm1,xmm1,rdx
  411582:	vsubsd xmm0,xmm0,xmm1
  411586:	vmulsd xmm0,xmm0,xmm6
  41158a:	vcvttsd2si rdx,xmm0
  41158f:	mov    r10b,dl
  411592:	add    r10b,0x30
  411596:	mov    BYTE PTR [r9+0xa],r10b
  41159a:	vxorpd xmm1,xmm1,xmm1
  41159e:	movzx  edx,dl
  4115a1:	vcvtsi2sd xmm1,xmm1,rdx
  4115a6:	vsubsd xmm0,xmm0,xmm1
  4115aa:	vmulsd xmm0,xmm0,xmm6
  4115ae:	vcvttsd2si rdx,xmm0
  4115b3:	mov    r10b,dl
  4115b6:	add    r10b,0x30
  4115ba:	mov    BYTE PTR [r9+0xb],r10b
  4115be:	lea    r10,[r9+0x4]
  4115c2:	vxorpd xmm1,xmm1,xmm1
  4115c6:	movzx  edx,dl
  4115c9:	vcvtsi2sd xmm1,xmm1,rdx
  4115ce:	vsubsd xmm0,xmm0,xmm1
  4115d2:	vmulsd xmm0,xmm0,xmm6
  4115d6:	vcvttsd2si rdx,xmm0
  4115db:	mov    r11b,dl
  4115de:	add    r11b,0x30
  4115e2:	mov    BYTE PTR [r9+0xc],r11b
  4115e6:	vxorpd xmm1,xmm1,xmm1
  4115ea:	movzx  edx,dl
  4115ed:	vcvtsi2sd xmm1,xmm1,rdx
  4115f2:	vsubsd xmm0,xmm0,xmm1
  4115f6:	vmulsd xmm0,xmm0,xmm6
  4115fa:	vcvttsd2si rdx,xmm0
  4115ff:	mov    r11b,dl
  411602:	add    r11b,0x30
  411606:	mov    BYTE PTR [r9+0xd],r11b
  41160a:	lea    r10,[r10+0x2]
  41160e:	vxorpd xmm1,xmm1,xmm1
  411612:	movzx  edx,dl
  411615:	vcvtsi2sd xmm1,xmm1,rdx
  41161a:	vsubsd xmm0,xmm0,xmm1
  41161e:	vmulsd xmm0,xmm0,xmm6
  411622:	vcvttsd2si rdx,xmm0
  411627:	mov    r11b,dl
  41162a:	add    r11b,0x30
  41162e:	mov    BYTE PTR [r9+0xe],r11b
  411632:	vxorpd xmm1,xmm1,xmm1
  411636:	movzx  edx,dl
  411639:	vcvtsi2sd xmm1,xmm1,rdx
  41163e:	vsubsd xmm0,xmm0,xmm1
  411642:	vmulsd xmm0,xmm0,xmm6
  411646:	vcvttsd2si rdx,xmm0
  41164b:	mov    r11b,dl
  41164e:	add    r11b,0x30
  411652:	mov    BYTE PTR [r9+0xf],r11b
  411656:	lea    r10,[r10+0x2]
  41165a:	lea    r10,[r10+0x2]
  41165e:	lea    r10,[r10+0x2]
  411662:	lea    r10,[r10+0x2]
  411666:	lea    r10,[r10+0x2]
  41166a:	vxorpd xmm1,xmm1,xmm1
  41166e:	movzx  edx,dl
  411671:	vcvtsi2sd xmm1,xmm1,rdx
  411676:	vsubsd xmm0,xmm0,xmm1
  41167a:	vmulsd xmm0,xmm0,xmm6
  41167e:	vcvttsd2si rdx,xmm0
  411683:	mov    r11b,dl
  411686:	add    r11b,0x30
  41168a:	mov    BYTE PTR [r9+0x10],r11b
  41168e:	vxorpd xmm1,xmm1,xmm1
  411692:	movzx  edx,dl
  411695:	vcvtsi2sd xmm1,xmm1,rdx
  41169a:	vsubsd xmm0,xmm0,xmm1
  41169e:	vmulsd xmm0,xmm0,xmm6
  4116a2:	vcvttsd2si rdx,xmm0
  4116a7:	add    dl,0x30
  4116aa:	mov    BYTE PTR [r9+0x11],dl
  4116ae:	mov    BYTE PTR [r10+0x2],0x65
  4116b3:	lea    r9,[r10+0x3]
  4116b7:	test   r8,r8
  4116ba:	jl     4116c3 <__swc_fn_3464c816_000149_6203dca2+0xd43>
  4116bc:	mov    BYTE PTR [r9],0x2b
  4116c0:	inc    r9
  4116c3:	mov    r10,r9
  4116c6:	mov    rdx,r8
  4116c9:	nop    DWORD PTR [rax+0x0]
  4116d0:	mov    r11,rdx
  4116d3:	movabs rdx,0x6666666666666667
  4116dd:	mov    rax,r11
  4116e0:	imul   rdx
  4116e3:	sar    rdx,0x2
  4116e7:	mov    r12,rdx
  4116ea:	shr    rdx,0x3f
  4116ee:	add    r12,rdx
  4116f1:	mov    rdx,r12
  4116f4:	imul   r13,r12,0xa
  4116f8:	sub    r11,r13
  4116fb:	mov    r13,QWORD PTR [rip+0x1f3e]        # 413640 <__swc_rdata_base_3464c816+0x530>
  411702:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411707:	mov    BYTE PTR [r10],r11b
  41170a:	lea    r11,[r10+0x1]
  41170e:	mov    r10,r11
  411711:	test   r12,r12
  411714:	jne    4116d0 <__swc_fn_3464c816_000149_6203dca2+0xd50>
  411716:	test   r8,r8
  411719:	jge    411723 <__swc_fn_3464c816_000149_6203dca2+0xda3>
  41171b:	mov    BYTE PTR [r11],0x2d
  41171f:	lea    r10,[r11+0x1]
  411723:	mov    BYTE PTR [r10],0x0
  411727:	sub    r10,0x1
  41172b:	nop    DWORD PTR [rax+rax*1+0x0]
  411730:	cmp    r9,r10
  411733:	jae    4119a8 <__swc_fn_3464c816_000149_6203dca2+0x1028>
  411739:	mov    al,BYTE PTR [r10]
  41173c:	mov    dl,BYTE PTR [r9]
  41173f:	mov    BYTE PTR [r10],dl
  411742:	sub    r10,0x1
  411746:	mov    BYTE PTR [r9],al
  411749:	inc    r9
  41174c:	jmp    411730 <__swc_fn_3464c816_000149_6203dca2+0xdb0>
  41174e:	vcvttsd2si rdx,xmm0
  411753:	mov    r8,rdx
  411756:	vxorpd xmm1,xmm1,xmm1
  41175a:	vcvtsi2sd xmm1,xmm1,rdx
  41175f:	vsubsd xmm1,xmm0,xmm1
  411763:	mov    r9d,0x8
  411769:	vxorpd xmm2,xmm2,xmm2
  41176d:	vcomisd xmm2,xmm1
  411771:	ja     41177e <__swc_fn_3464c816_000149_6203dca2+0xdfe>
  411773:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41177c:	jmp    41178f <__swc_fn_3464c816_000149_6203dca2+0xe0f>
  41177e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1eca]        # 413650 <__swc_rdata_base_3464c816+0x540>
  411786:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41178f:	test   r9d,r9d
  411792:	je     4117a9 <__swc_fn_3464c816_000149_6203dca2+0xe29>
  411794:	cs nop WORD PTR [rax+rax*1+0x0]
  41179e:	xchg   ax,ax
  4117a0:	vmulsd xmm1,xmm1,xmm6
  4117a4:	dec    r9d
  4117a7:	jne    4117a0 <__swc_fn_3464c816_000149_6203dca2+0xe20>
  4117a9:	vcvttsd2si r9,xmm1
  4117ae:	mov    r10,r9
  4117b1:	vxorpd xmm2,xmm2,xmm2
  4117b5:	vcvtsi2sd xmm2,xmm2,r9
  4117ba:	vsubsd xmm1,xmm1,xmm2
  4117be:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  4117c7:	vcomisd xmm1,xmm6
  4117cb:	lea    r9,[r9+0x1]
  4117cf:	cmova  r10,r9
  4117d3:	cmp    r10,0x5f5e100
  4117da:	jne    4117f3 <__swc_fn_3464c816_000149_6203dca2+0xe73>
  4117dc:	lea    r8,[rdx-0x1]
  4117e0:	vxorpd xmm1,xmm1,xmm1
  4117e4:	vcomisd xmm1,xmm0
  4117e8:	lea    rdx,[rdx+0x1]
  4117ec:	cmovbe r8,rdx
  4117f0:	xor    r10d,r10d
  4117f3:	mov    r9,rcx
  4117f6:	test   r8,r8
  4117f9:	jne    411819 <__swc_fn_3464c816_000149_6203dca2+0xe99>
  4117fb:	vxorpd xmm1,xmm1,xmm1
  4117ff:	vcomisd xmm1,xmm0
  411803:	jbe    41180c <__swc_fn_3464c816_000149_6203dca2+0xe8c>
  411805:	mov    BYTE PTR [rcx],0x2d
  411808:	lea    r9,[rcx+0x1]
  41180c:	mov    BYTE PTR [r9],0x30
  411810:	add    r9,0x1
  411814:	jmp    4118ab <__swc_fn_3464c816_000149_6203dca2+0xf2b>
  411819:	mov    r9,rcx
  41181c:	mov    rdx,r8
  41181f:	nop
  411820:	mov    r11,rdx
  411823:	movabs rdx,0x6666666666666667
  41182d:	mov    r15,rax
  411830:	mov    rax,r11
  411833:	imul   rdx
  411836:	mov    r12,rdx
  411839:	mov    rax,r15
  41183c:	sar    r12,0x2
  411840:	mov    rdx,r12
  411843:	shr    rdx,0x3f
  411847:	add    r12,rdx
  41184a:	mov    rdx,r12
  41184d:	imul   r13,r12,0xa
  411851:	sub    r11,r13
  411854:	mov    r13,QWORD PTR [rip+0x1de5]        # 413640 <__swc_rdata_base_3464c816+0x530>
  41185b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411860:	mov    BYTE PTR [r9],r11b
  411863:	lea    r11,[r9+0x1]
  411867:	mov    r9,r11
  41186a:	test   r12,r12
  41186d:	jne    411820 <__swc_fn_3464c816_000149_6203dca2+0xea0>
  41186f:	test   r8,r8
  411872:	jge    41187c <__swc_fn_3464c816_000149_6203dca2+0xefc>
  411874:	mov    BYTE PTR [r11],0x2d
  411878:	lea    r9,[r11+0x1]
  41187c:	mov    rdx,r9
  41187f:	mov    BYTE PTR [r9],0x0
  411883:	sub    r9,0x1
  411887:	mov    r8,rcx
  41188a:	cmp    r8,r9
  41188d:	jae    4118a8 <__swc_fn_3464c816_000149_6203dca2+0xf28>
  41188f:	nop
  411890:	mov    r11b,BYTE PTR [r9]
  411893:	mov    r12b,BYTE PTR [r8]
  411896:	mov    BYTE PTR [r9],r12b
  411899:	sub    r9,0x1
  41189d:	mov    BYTE PTR [r8],r11b
  4118a0:	inc    r8
  4118a3:	cmp    r8,r9
  4118a6:	jb     411890 <__swc_fn_3464c816_000149_6203dca2+0xf10>
  4118a8:	mov    r9,rdx
  4118ab:	mov    BYTE PTR [r9],0x2e
  4118af:	add    r9,0x1
  4118b3:	xor    r8d,r8d
  4118b6:	test   r10,r10
  4118b9:	je     4118ff <__swc_fn_3464c816_000149_6203dca2+0xf7f>
  4118bb:	mov    r11d,0x989680
  4118c1:	cmp    r10,r11
  4118c4:	jge    4118ff <__swc_fn_3464c816_000149_6203dca2+0xf7f>
  4118c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4118d0:	inc    r8d
  4118d3:	movabs rdx,0x6666666666666667
  4118dd:	mov    r15,rax
  4118e0:	mov    rax,r11
  4118e3:	imul   rdx
  4118e6:	mov    r11,rdx
  4118e9:	mov    rax,r15
  4118ec:	sar    r11,0x2
  4118f0:	mov    rdx,r11
  4118f3:	shr    rdx,0x3f
  4118f7:	add    r11,rdx
  4118fa:	cmp    r10,r11
  4118fd:	jl     4118d0 <__swc_fn_3464c816_000149_6203dca2+0xf50>
  4118ff:	test   r8d,r8d
  411902:	je     41191d <__swc_fn_3464c816_000149_6203dca2+0xf9d>
  411904:	cs nop WORD PTR [rax+rax*1+0x0]
  41190e:	xchg   ax,ax
  411910:	mov    BYTE PTR [r9],0x30
  411914:	add    r9,0x1
  411918:	dec    r8d
  41191b:	jne    411910 <__swc_fn_3464c816_000149_6203dca2+0xf90>
  41191d:	mov    r8,r9
  411920:	mov    rdx,r10
  411923:	cs nop WORD PTR [rax+rax*1+0x0]
  41192d:	nop    DWORD PTR [rax]
  411930:	mov    r11,rdx
  411933:	movabs rdx,0x6666666666666667
  41193d:	mov    rax,r11
  411940:	imul   rdx
  411943:	sar    rdx,0x2
  411947:	mov    r12,rdx
  41194a:	shr    rdx,0x3f
  41194e:	add    r12,rdx
  411951:	mov    rdx,r12
  411954:	imul   r13,r12,0xa
  411958:	sub    r11,r13
  41195b:	mov    r13,QWORD PTR [rip+0x1cde]        # 413640 <__swc_rdata_base_3464c816+0x530>
  411962:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411967:	mov    BYTE PTR [r8],r11b
  41196a:	lea    r11,[r8+0x1]
  41196e:	mov    r8,r11
  411971:	test   r12,r12
  411974:	jne    411930 <__swc_fn_3464c816_000149_6203dca2+0xfb0>
  411976:	test   r10,r10
  411979:	jge    411983 <__swc_fn_3464c816_000149_6203dca2+0x1003>
  41197b:	mov    BYTE PTR [r11],0x2d
  41197f:	lea    r8,[r11+0x1]
  411983:	mov    BYTE PTR [r8],0x0
  411987:	sub    r8,0x1
  41198b:	cmp    r9,r8
  41198e:	jae    4119a8 <__swc_fn_3464c816_000149_6203dca2+0x1028>
  411990:	mov    al,BYTE PTR [r8]
  411993:	mov    dl,BYTE PTR [r9]
  411996:	mov    BYTE PTR [r8],dl
  411999:	sub    r8,0x1
  41199d:	mov    BYTE PTR [r9],al
  4119a0:	inc    r9
  4119a3:	cmp    r9,r8
  4119a6:	jb     411990 <__swc_fn_3464c816_000149_6203dca2+0x1010>
  4119a8:	xor    eax,eax
  4119aa:	test   rcx,rcx
  4119ad:	je     4119d0 <__swc_fn_3464c816_000149_6203dca2+0x1050>
  4119af:	mov    rdx,rcx
  4119b2:	mov    r8b,BYTE PTR [rdx]
  4119b5:	test   r8b,r8b
  4119b8:	je     4119d0 <__swc_fn_3464c816_000149_6203dca2+0x1050>
  4119ba:	nop    WORD PTR [rax+rax*1+0x0]
  4119c0:	add    rdx,0x1
  4119c4:	add    rax,0x1
  4119c8:	mov    r8b,BYTE PTR [rdx]
  4119cb:	test   r8b,r8b
  4119ce:	jne    4119c0 <__swc_fn_3464c816_000149_6203dca2+0x1040>
  4119d0:	mov    QWORD PTR [rsp+0x3f8],rcx
  4119d8:	mov    QWORD PTR [rsp+0x400],rax
  4119e0:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  4119e9:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  4119f2:	lea    rcx,[rsp+0x408]
  4119fa:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  4119ff:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  411a01:	mov    rcx,rdx
  411a04:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  411a09:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  411a0b:	mov    al,BYTE PTR [rdx]
  411a0d:	test   al,al
  411a0f:	je     411a1a <__swc_fn_3464c816_000149_6203dca2+0x109a>
  411a11:	lea    rax,[rip+0x1c48]        # 413660 <__swc_rdata_base_3464c816+0x550>
  411a18:	jmp    411a21 <__swc_fn_3464c816_000149_6203dca2+0x10a1>
  411a1a:	lea    rax,[rip+0x1c4f]        # 413670 <__swc_rdata_base_3464c816+0x560>
  411a21:	mov    rcx,rax
  411a24:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  411a29:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  411a2b:	lea    rcx,[rip+0x1c4e]        # 413680 <__swc_rdata_base_3464c816+0x570>
  411a32:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  411a37:	jmp    411a45 <__swc_fn_3464c816_000149_6203dca2+0x10c5>
  411a39:	lea    rcx,[rip+0x1c40]        # 413680 <__swc_rdata_base_3464c816+0x570>
  411a40:	call   410110 <__swc_fn_3464c816_000119_2648f149>
  411a45:	add    rdi,0x1
  411a49:	sub    rsi,0x1
  411a4d:	vmovups xmm0,xmm12
  411a52:	vmovsd xmm6,QWORD PTR [rip+0x1c36]        # 413690 <__swc_rdata_base_3464c816+0x580>
  411a5a:	test   rsi,rsi
  411a5d:	jne    410a90 <__swc_fn_3464c816_000149_6203dca2+0x110>
  411a63:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  411a6c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  411a75:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  411a7e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411a87:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411a90:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411a99:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411aa2:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  411aab:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411ab4:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  411abd:	add    rsp,0x4e8
  411ac4:	pop    r15
  411ac6:	pop    r13
  411ac8:	pop    r12
  411aca:	pop    rdi
  411acb:	pop    rsi
  411acc:	pop    rbx
  411acd:	ret
