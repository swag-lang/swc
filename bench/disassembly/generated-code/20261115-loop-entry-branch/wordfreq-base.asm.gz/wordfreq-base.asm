
/workspace/prompt2-20261115/batch7-placement-micro/base/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <open@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <open@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <flock@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <flock@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <__errno_location@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <__errno_location@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <close@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <close@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <getpid@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <getpid@GLIBC_2.2.5>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <opendir@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <opendir@GLIBC_2.2.5>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <dirfd@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <dirfd@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <readdir@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <readdir@GLIBC_2.2.5>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <readlinkat@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <readlinkat@GLIBC_2.4>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <openat@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <openat@GLIBC_2.4>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <closedir@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <closedir@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <lseek@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <lseek@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <mmap@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <mmap@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <memfd_create@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf92]        # 413078 <memfd_create@GLIBC_2.27>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <ftruncate@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf8a]        # 413080 <ftruncate@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <write@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf82]        # 413088 <write@GLIBC_2.2.5>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <backtrace@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf7a]        # 413090 <backtrace@GLIBC_2.2.5>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <pthread_setspecific@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf72]        # 413098 <pthread_setspecific@GLIBC_2.34>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <clock_gettime@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf6a]        # 4130a0 <clock_gettime@GLIBC_2.17>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <__x86_get_cpuid_feature_leaf@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf62]        # 4130a8 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <free@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf5a]        # 4130b0 <free@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <munmap@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <munmap@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <mprotect@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <mprotect@GLIBC_2.2.5>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <exit@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <exit@GLIBC_2.2.5>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <pthread_key_create@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <pthread_key_create@GLIBC_2.34>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <syscall@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <syscall@GLIBC_2.2.5>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <dladdr@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <dladdr@GLIBC_2.34>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <malloc@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <malloc@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <madvise@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <madvise@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <pthread_key_delete@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <pthread_key_delete@GLIBC_2.34>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <gettid@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <gettid@GLIBC_2.30>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_4fa09e82_000179_6937fe70+0xf30>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   4114a0 <__swc_fn_4fa09e82_000122_1c5e75b6>
  40724e:	xor    ecx,ecx
  407250:	call   40dca0 <__swc_fn_4fa09e82_000094_383a814c>
  407255:	call   40b860 <__swc_fn_4fa09e82_000180_913db40c>
  40725a:	call   410af0 <__swc_fn_4fa09e82_000095_8cc4b392>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_4fa09e82_000000_0e26756e>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_4fa09e82_000003_81215399>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_4fa09e82_000003_81215399+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   40e0c0 <__swc_fn_4fa09e82_000112_f9e19033>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_4fa09e82_000003_81215399+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1cd81]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1cd7a]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_4fa09e82_000003_81215399+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_4fa09e82_000003_81215399+0x30>
  4072e6:	lea    rcx,[rip+0x1cd63]        # 424050 <__swc_bss_base_4fa09e82+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1cd5c]        # 424050 <__swc_bss_base_4fa09e82+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_4fa09e82_000003_81215399+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_4fa09e82_000003_81215399+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_4fa09e82_000006_7b253ae1>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40f3a0 <__swc_fn_4fa09e82_000011_71c91685>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_4fa09e82_000012_be38a1a2>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_4fa09e82_000006_7b253ae1+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_4fa09e82_000003_81215399>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_4fa09e82_000006_7b253ae1+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_4fa09e82_000009_4c3ebf16>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_4fa09e82_000009_4c3ebf16+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40c030 <__swc_fn_4fa09e82_000007_a7bfb091>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40f390 <__swc_fn_4fa09e82_000008_b2f73e0d>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_4fa09e82_000009_4c3ebf16+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_4fa09e82_000009_4c3ebf16+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_4fa09e82_000012_be38a1a2>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_4fa09e82_000015_96cb1311>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_4fa09e82_000015_96cb1311+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_4fa09e82_000015_96cb1311+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_4fa09e82_000015_96cb1311+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_4fa09e82_000015_96cb1311+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40f500 <__swc_fn_4fa09e82_000017_f003fc47>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_4fa09e82_000015_96cb1311+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1cb3d]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1cb36]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_4fa09e82_000015_96cb1311+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_4fa09e82_000015_96cb1311+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40f3a0 <__swc_fn_4fa09e82_000011_71c91685>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_4fa09e82_000015_96cb1311+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   4111b0 <__swc_fn_4fa09e82_000113_2f7f9346>
  407569:	lea    rcx,[rip+0x1cad8]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1cad1]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_4fa09e82_000015_96cb1311+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_4fa09e82_000015_96cb1311+0x110>
  407598:	lea    rcx,[rip+0x1cac1]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1caba]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_4fa09e82_000015_96cb1311+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_4fa09e82_000015_96cb1311+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_4fa09e82_000018_77ece227>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_4fa09e82_000015_96cb1311+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_4fa09e82_000018_77ece227>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_4fa09e82_000018_77ece227+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_4fa09e82_000018_77ece227+0x10>

0000000000407630 <__swc_fn_4fa09e82_000021_9cf87641>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_4fa09e82_000015_96cb1311>
  40763e:	lea    rdi,[rip+0x1cbab]        # 4241f0 <__swc_bss_base_4fa09e82+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   40e720 <__swc_fn_4fa09e82_000136_db32cc57>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1cb94]        # 4241f8 <__swc_bss_base_4fa09e82+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1cb89],rsi        # 4241f8 <__swc_bss_base_4fa09e82+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_4fa09e82_000024_e876734d>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_4fa09e82_000027_e876734d>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_4fa09e82_000030_650caec0>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_4fa09e82_000030_650caec0+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1a92c]        # 422000 <__swc_data_base_4fa09e82>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_4fa09e82_000030_650caec0+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_4fa09e82_000030_650caec0+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_4fa09e82_000030_650caec0+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40f6c0 <__swc_fn_4fa09e82_000032_f1940e30>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_4fa09e82_000030_650caec0+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_4fa09e82_000036_290a131c>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_4fa09e82_000030_650caec0+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_4fa09e82_000042_0573444d>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_4fa09e82_000033_d15eb4ea>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40c4e0 <__swc_fn_4fa09e82_000031_3c3e930e>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   40e5a0 <__swc_fn_4fa09e82_000130_bc477461>
  407734:	mov    rcx,rsi
  407737:	call   40f6c0 <__swc_fn_4fa09e82_000032_f1940e30>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_4fa09e82_000036_290a131c>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_4fa09e82_000039_9ae4348f>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_4fa09e82_000039_9ae4348f+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_4fa09e82_000039_9ae4348f+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_4fa09e82_000039_9ae4348f+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_4fa09e82_000039_9ae4348f+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_4fa09e82_000039_9ae4348f+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   40e1a0 <__swc_fn_4fa09e82_000115_cc486df9>
  4077ca:	lea    rcx,[rip+0x1c877]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1c870]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_4fa09e82_000039_9ae4348f+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_4fa09e82_000039_9ae4348f+0x90>
  4077f8:	lea    rcx,[rip+0x1c861]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1c85a]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_4fa09e82_000039_9ae4348f+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_4fa09e82_000039_9ae4348f+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_4fa09e82_000042_0573444d>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_4fa09e82_000042_0573444d+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40fc90 <__swc_fn_4fa09e82_000059_ee6a254c>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   40e720 <__swc_fn_4fa09e82_000136_db32cc57>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_4fa09e82_000042_0573444d+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_4fa09e82_000042_0573444d+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_4fa09e82_000009_4c3ebf16>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_4fa09e82_000042_0573444d+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40f3c0 <__swc_fn_4fa09e82_000014_be17798c>
  40791e:	jmp    407941 <__swc_fn_4fa09e82_000042_0573444d+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_4fa09e82_000042_0573444d+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_4fa09e82_000042_0573444d+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_4fa09e82_000042_0573444d+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40c6a0 <__swc_fn_4fa09e82_000043_47ff6d9b>
  407997:	mov    rcx,rdi
  40799a:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_4fa09e82_000039_9ae4348f>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_4fa09e82_000045_bb688d37>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_4fa09e82_000045_bb688d37+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_4fa09e82_000045_bb688d37+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_4fa09e82_000045_bb688d37+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_4fa09e82_000045_bb688d37+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   40e720 <__swc_fn_4fa09e82_000136_db32cc57>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_4fa09e82_000045_bb688d37+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_4fa09e82_000045_bb688d37+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_4fa09e82_000045_bb688d37+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_4fa09e82_000045_bb688d37+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_4fa09e82_000009_4c3ebf16>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_4fa09e82_000045_bb688d37+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_4fa09e82_000045_bb688d37+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_4fa09e82_000045_bb688d37+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_4fa09e82_000045_bb688d37+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_4fa09e82_000045_bb688d37+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40c0e0 <__swc_fn_4fa09e82_000013_7b85dbab>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_4fa09e82_000045_bb688d37+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_4fa09e82_000045_bb688d37+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_4fa09e82_000045_bb688d37+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_4fa09e82_000045_bb688d37+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40f540 <__swc_fn_4fa09e82_000020_4285d9c5>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_4fa09e82_000045_bb688d37+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40c0e0 <__swc_fn_4fa09e82_000013_7b85dbab>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_4fa09e82_000045_bb688d37+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_4fa09e82_000021_9cf87641>
  407c07:	mov    rcx,r14
  407c0a:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_4fa09e82_000045_bb688d37+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_4fa09e82_000045_bb688d37+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_4fa09e82_000045_bb688d37+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_4fa09e82_000048_8e68f77b>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_4fa09e82_000048_8e68f77b+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_4fa09e82_000048_8e68f77b+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_4fa09e82_000048_8e68f77b+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_4fa09e82_000048_8e68f77b+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40f8f0 <__swc_fn_4fa09e82_000047_e7fd8d42>
  407d14:	jmp    407ce0 <__swc_fn_4fa09e82_000048_8e68f77b+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_4fa09e82_000048_8e68f77b+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_4fa09e82_000048_8e68f77b+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_4fa09e82_000048_8e68f77b+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_4fa09e82_000048_8e68f77b+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_4fa09e82_000048_8e68f77b+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_4fa09e82_000048_8e68f77b+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_4fa09e82_000048_8e68f77b+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_4fa09e82_000051_27d2a35f>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_4fa09e82_000051_27d2a35f+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_4fa09e82_000051_27d2a35f+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_4fa09e82_000051_27d2a35f+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_4fa09e82_000051_27d2a35f+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40f850 <__swc_fn_4fa09e82_000044_fe6bbfdb>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40f3c0 <__swc_fn_4fa09e82_000014_be17798c>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_4fa09e82_000054_e8e85c01>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   40e720 <__swc_fn_4fa09e82_000136_db32cc57>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_4fa09e82_000054_e8e85c01+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_4fa09e82_000054_e8e85c01+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_4fa09e82_000054_e8e85c01+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_4fa09e82_000057_01c75a1d>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_4fa09e82_000060_6818d0d1>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_4fa09e82_000060_6818d0d1+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_4fa09e82_000039_9ae4348f>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_4fa09e82_000060_6818d0d1+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_4fa09e82_000063_db6d2425>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40ca20 <__swc_fn_4fa09e82_000052_92b016ae>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_4fa09e82_000054_e8e85c01>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_4fa09e82_000063_db6d2425+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_4fa09e82_000063_db6d2425+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40cb40 <__swc_fn_4fa09e82_000058_01964a17>
  407f7f:	mov    rcx,rsi
  407f82:	call   40c780 <__swc_fn_4fa09e82_000049_f6a485a2>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_4fa09e82_000066_918d3875>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_4fa09e82_000066_918d3875+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1c049]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1c04b]        # 424080 <__swc_bss_base_4fa09e82+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_4fa09e82_000066_918d3875+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_4fa09e82_000066_918d3875+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40c410 <__swc_fn_4fa09e82_000022_53fc00d2>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_4fa09e82_000066_918d3875+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_4fa09e82_000063_db6d2425>
  40808f:	jmp    408122 <__swc_fn_4fa09e82_000066_918d3875+0x192>
  408094:	lea    rax,[rip+0x19f65]        # 422000 <__swc_data_base_4fa09e82>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_4fa09e82_000066_918d3875+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_4fa09e82_000066_918d3875+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_4fa09e82_000066_918d3875+0x135>
  4080b8:	call   40c4e0 <__swc_fn_4fa09e82_000031_3c3e930e>
  4080bd:	mov    rcx,rax
  4080c0:	call   409ba0 <__swc_fn_4fa09e82_000129_8d8a7dd2>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_4fa09e82_000066_918d3875+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_4fa09e82_000066_918d3875+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_4fa09e82_000066_918d3875+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40f8f0 <__swc_fn_4fa09e82_000047_e7fd8d42>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_4fa09e82_000066_918d3875+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_4fa09e82_000051_27d2a35f>
  408115:	jmp    408122 <__swc_fn_4fa09e82_000066_918d3875+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40c050 <__swc_fn_4fa09e82_000010_0569f799>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_4fa09e82_000069_34b04ef2>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_4fa09e82_000036_290a131c>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_4fa09e82_000069_34b04ef2+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1c09a]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_4fa09e82_000069_34b04ef2+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   40e720 <__swc_fn_4fa09e82_000136_db32cc57>
  4081b5:	mov    rcx,rsi
  4081b8:	call   4100c0 <__swc_fn_4fa09e82_000068_f501e74b>
  4081bd:	mov    rcx,rsi
  4081c0:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_4fa09e82_000072_bf7b5562>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40fe10 <__swc_fn_4fa09e82_000065_0b20477c>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_4fa09e82_000075_41334281>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   4100c0 <__swc_fn_4fa09e82_000068_f501e74b>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_4fa09e82_000078_140918ec>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_4fa09e82_000078_140918ec+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_4fa09e82_000078_140918ec+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_4fa09e82_000081_f4f506c7>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_4fa09e82_000084_5ed30bd6>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_4fa09e82_000090_14cf59b2>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_4fa09e82_000084_5ed30bd6+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_4fa09e82_000084_5ed30bd6+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_4fa09e82_000084_5ed30bd6+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_4fa09e82_000084_5ed30bd6+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_4fa09e82_000090_14cf59b2>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_4fa09e82_000084_5ed30bd6+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_4fa09e82_000084_5ed30bd6+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_4fa09e82_000084_5ed30bd6+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_4fa09e82_000084_5ed30bd6+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_4fa09e82_000084_5ed30bd6+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_4fa09e82_000084_5ed30bd6+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_4fa09e82_000084_5ed30bd6+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_4fa09e82_000084_5ed30bd6+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_4fa09e82_000084_5ed30bd6+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_4fa09e82_000084_5ed30bd6+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40db20 <__swc_fn_4fa09e82_000082_ff7d1455>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_4fa09e82_000084_5ed30bd6+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_4fa09e82_000084_5ed30bd6+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_4fa09e82_000084_5ed30bd6+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40db20 <__swc_fn_4fa09e82_000082_ff7d1455>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_4fa09e82_000084_5ed30bd6+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_4fa09e82_000084_5ed30bd6>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_4fa09e82_000084_5ed30bd6+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_4fa09e82_000084_5ed30bd6+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_4fa09e82_000087_693f118e>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_4fa09e82_000090_14cf59b2>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_4fa09e82_000087_693f118e+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   410520 <__swc_fn_4fa09e82_000086_d9243de4>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_4fa09e82_000087_693f118e+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_4fa09e82_000087_693f118e+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_4fa09e82_000087_693f118e+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40db20 <__swc_fn_4fa09e82_000082_ff7d1455>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_4fa09e82_000087_693f118e+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_4fa09e82_000087_693f118e>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_4fa09e82_000087_693f118e+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_4fa09e82_000087_693f118e+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_4fa09e82_000090_14cf59b2>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_4fa09e82_000090_14cf59b2+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_4fa09e82_000090_14cf59b2+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_4fa09e82_000090_14cf59b2+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_4fa09e82_000090_14cf59b2+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40db20 <__swc_fn_4fa09e82_000082_ff7d1455>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40db20 <__swc_fn_4fa09e82_000082_ff7d1455>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_4fa09e82_000090_14cf59b2+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_4fa09e82_000090_14cf59b2+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_4fa09e82_000090_14cf59b2+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_4fa09e82_000090_14cf59b2+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_4fa09e82_000090_14cf59b2>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_4fa09e82_000090_14cf59b2+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_4fa09e82_000090_14cf59b2+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_4fa09e82_000090_14cf59b2+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_4fa09e82_000090_14cf59b2+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_4fa09e82_000090_14cf59b2+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_4fa09e82_000090_14cf59b2+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_4fa09e82_000090_14cf59b2+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_4fa09e82_000090_14cf59b2+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_4fa09e82_000090_14cf59b2+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_4fa09e82_000090_14cf59b2+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_4fa09e82_000090_14cf59b2+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_4fa09e82_000090_14cf59b2+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_4fa09e82_000090_14cf59b2+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_4fa09e82_000090_14cf59b2+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_4fa09e82_000090_14cf59b2+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_4fa09e82_000090_14cf59b2+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   40ec30 <__swc_fn_4fa09e82_000148_e7bfe29e>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_4fa09e82_000090_14cf59b2+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_4fa09e82_000090_14cf59b2>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_4fa09e82_000090_14cf59b2+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_4fa09e82_000090_14cf59b2+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_4fa09e82_000090_14cf59b2+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   40ec30 <__swc_fn_4fa09e82_000148_e7bfe29e>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   40ec30 <__swc_fn_4fa09e82_000148_e7bfe29e>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_4fa09e82_000093_0c97fc6c>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40dc50 <__swc_fn_4fa09e82_000091_f21926ed>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_4fa09e82_000093_0c97fc6c+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_4fa09e82_000093_0c97fc6c+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   409d40 <__swc_fn_4fa09e82_000138_2d595cc7>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_4fa09e82_000093_0c97fc6c+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0xa872]        # 4131c0 <__swc_rdata_base_4fa09e82+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   409870 <__swc_fn_4fa09e82_000117_3f5cfdef>
  408959:	call   4113e0 <__swc_fn_4fa09e82_000119_591530fe>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_4fa09e82_000096_a4baaa40>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40896f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  408975:	vzeroupper
  408978:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40897e:	mov    QWORD PTR [rsp+0x48],rdx
  408983:	mov    rax,r8
  408986:	cmp    r8,0x1
  40898a:	mov    edx,0x1
  40898f:	cmovb  rax,rdx
  408993:	mov    QWORD PTR [rsp+0x50],rax
  408998:	mov    rbx,QWORD PTR [rcx+0x8]
  40899c:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a0:	mov    rcx,QWORD PTR [rcx]
  4089a3:	lea    rdx,[rsp+0x8]
  4089a8:	call   rbx
  4089aa:	add    rsp,0x70
  4089ae:	pop    rbx
  4089af:	ret

00000000004089b0 <__swc_fn_4fa09e82_000099_5232b57d>:
  4089b0:	push   rbx
  4089b1:	push   rsi
  4089b2:	push   rdi
  4089b3:	sub    rsp,0x30
  4089b7:	mov    rbx,rcx
  4089ba:	test   rcx,rcx
  4089bd:	je     4089d2 <__swc_fn_4fa09e82_000099_5232b57d+0x22>
  4089bf:	mov    rcx,rbx
  4089c2:	mov    edx,0x1
  4089c7:	call   408200 <__swc_fn_4fa09e82_000078_140918ec>
  4089cc:	cmp    rax,0x1
  4089d0:	je     4089da <__swc_fn_4fa09e82_000099_5232b57d+0x2a>
  4089d2:	add    rsp,0x30
  4089d6:	pop    rdi
  4089d7:	pop    rsi
  4089d8:	pop    rbx
  4089d9:	ret
  4089da:	lea    rsi,[rsp+0x8]
  4089df:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089e4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089ea:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  4089ef:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4089f5:	mov    rax,QWORD PTR [rsp+0x20]
  4089fa:	test   rax,rax
  4089fd:	je     408a13 <__swc_fn_4fa09e82_000099_5232b57d+0x63>
  4089ff:	test   DWORD PTR [rax+0x28],0x400000
  408a06:	je     408a13 <__swc_fn_4fa09e82_000099_5232b57d+0x63>
  408a08:	mov    rcx,QWORD PTR [rax+0x30]
  408a0c:	test   rcx,rcx
  408a0f:	cmovne rax,rcx
  408a13:	mov    edi,DWORD PTR [rax+0x20]
  408a16:	lea    rcx,[rsp+0x18]
  408a1b:	call   40de30 <__swc_fn_4fa09e82_000100_5714513e>
  408a20:	mov    rcx,rsi
  408a23:	mov    rdx,QWORD PTR [rsp+0x18]
  408a28:	mov    r8,rdi
  408a2b:	call   408960 <__swc_fn_4fa09e82_000096_a4baaa40>
  408a30:	mov    rcx,QWORD PTR [rbx+0x28]
  408a34:	call   410b00 <__swc_fn_4fa09e82_000098_f82a1ed3>
  408a39:	mov    rcx,rsi
  408a3c:	mov    rdx,rbx
  408a3f:	mov    r8d,0x30
  408a45:	call   408960 <__swc_fn_4fa09e82_000096_a4baaa40>
  408a4a:	add    rsp,0x30
  408a4e:	pop    rdi
  408a4f:	pop    rsi
  408a50:	pop    rbx
  408a51:	ret
	...

0000000000408a60 <__swc_fn_4fa09e82_000102_14986ec5>:
  408a60:	push   rbp
  408a61:	push   rbx
  408a62:	push   rsi
  408a63:	push   rdi
  408a64:	push   r12
  408a66:	push   r13
  408a68:	push   r14
  408a6a:	push   r15
  408a6c:	sub    rsp,0x500
  408a73:	mov    rbp,rsp
  408a76:	mov    rbx,rsp
  408a79:	mov    rsi,rdx
  408a7c:	mov    rdi,rcx
  408a7f:	mov    rcx,QWORD PTR [rip+0x1e2ba]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  408a86:	test   rcx,rcx
  408a89:	jne    408aa3 <__swc_fn_4fa09e82_000102_14986ec5+0x43>
  408a8b:	sub    rsp,0x8
  408a8f:	call   40f020 <__swc_fn_4fa09e82_000166_56054fe7>
  408a94:	add    rsp,0x8
  408a98:	lea    rcx,[rax+0x1]
  408a9c:	mov    QWORD PTR [rip+0x1e29d],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  408aa3:	dec    rcx
  408aa6:	sub    rsp,0x8
  408aaa:	call   40b620 <__swc_fn_4fa09e82_000168_39c041ad>
  408aaf:	add    rsp,0x8
  408ab3:	mov    r12,rax
  408ab6:	mov    QWORD PTR [rsp+0x4f0],rax
  408abe:	lea    rax,[rip+0xa83b]        # 413300 <__swc_rdata_base_4fa09e82+0x1f0>
  408ac5:	sub    rsp,0x20
  408ac9:	mov    rcx,rsp
  408acc:	mov    QWORD PTR [rcx],rax
  408acf:	lea    r13,[rip+0xa83a]        # 413310 <__swc_rdata_base_4fa09e82+0x200>
  408ad6:	mov    QWORD PTR [rcx+0x8],r13
  408ada:	mov    QWORD PTR [rcx+0x10],rsp
  408ade:	mov    QWORD PTR [rcx+0x18],0x1
  408ae6:	lea    rcx,[rsp+0x10]
  408aeb:	sub    rsp,0x8
  408aef:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  408af4:	add    rsp,0x8
  408af8:	add    rsp,0x20
  408afc:	lea    rax,[rip+0xa855]        # 413358 <__swc_rdata_base_4fa09e82+0x248>
  408b03:	sub    rsp,0x20
  408b07:	mov    rcx,rsp
  408b0a:	mov    QWORD PTR [rcx],rax
  408b0d:	mov    QWORD PTR [rcx+0x8],r13
  408b11:	mov    QWORD PTR [rcx+0x10],rsp
  408b15:	mov    QWORD PTR [rcx+0x18],0x1
  408b1d:	lea    rcx,[rsp+0x10]
  408b22:	sub    rsp,0x8
  408b26:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  408b2b:	add    rsp,0x8
  408b2f:	add    rsp,0x20
  408b33:	lea    r14,[rip+0xa82e]        # 413368 <__swc_rdata_base_4fa09e82+0x258>
  408b3a:	sub    rsp,0x50
  408b3e:	mov    rax,rsp
  408b41:	vmovups xmm0,XMMWORD PTR [rip+0xa957]        # 4134a0 <__swc_rdata_base_4fa09e82+0x390>
  408b49:	vmovups XMMWORD PTR [rax],xmm0
  408b4d:	mov    QWORD PTR [rax+0x10],rsp
  408b51:	mov    QWORD PTR [rax+0x18],r13
  408b55:	mov    QWORD PTR [rax+0x20],rdi
  408b59:	lea    rdi,[rip+0xa818]        # 413378 <__swc_rdata_base_4fa09e82+0x268>
  408b60:	mov    QWORD PTR [rax+0x28],rdi
  408b64:	mov    QWORD PTR [rax+0x30],r14
  408b68:	mov    QWORD PTR [rax+0x38],r13
  408b6c:	lea    rcx,[rsp+0x10]
  408b71:	mov    QWORD PTR [rax+0x40],rcx
  408b75:	mov    QWORD PTR [rax+0x48],0x3
  408b7d:	lea    rcx,[rsp+0x40]
  408b82:	sub    rsp,0x8
  408b86:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  408b8b:	add    rsp,0x8
  408b8f:	add    rsp,0x50
  408b93:	lea    rax,[rip+0xa826]        # 4133c0 <__swc_rdata_base_4fa09e82+0x2b0>
  408b9a:	sub    rsp,0x20
  408b9e:	mov    rcx,rsp
  408ba1:	mov    QWORD PTR [rcx],rax
  408ba4:	mov    QWORD PTR [rcx+0x8],r13
  408ba8:	mov    QWORD PTR [rcx+0x10],rsp
  408bac:	mov    QWORD PTR [rcx+0x18],0x1
  408bb4:	lea    rcx,[rsp+0x10]
  408bb9:	sub    rsp,0x8
  408bbd:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  408bc2:	add    rsp,0x8
  408bc6:	add    rsp,0x20
  408bca:	mov    eax,DWORD PTR [rsi+0x20]
  408bcd:	mov    ecx,DWORD PTR [rsi+0x24]
  408bd0:	sub    rsp,0xa0
  408bd7:	mov    rdx,rsp
  408bda:	mov    QWORD PTR [rdx+0x30],rsi
  408bde:	mov    QWORD PTR [rdx+0x38],rdi
  408be2:	vmovups xmm0,XMMWORD PTR [rip+0xa84e]        # 413438 <__swc_rdata_base_4fa09e82+0x328>
  408bea:	vmovups XMMWORD PTR [rdx],xmm0
  408bee:	mov    QWORD PTR [rdx+0x40],rsp
  408bf2:	mov    QWORD PTR [rdx+0x48],r13
  408bf6:	mov    DWORD PTR [rdx+0x10],eax
  408bf9:	lea    rax,[rsp+0x10]
  408bfe:	mov    QWORD PTR [rdx+0x50],rax
  408c02:	lea    rax,[rip+0xa7c7]        # 4133d0 <__swc_rdata_base_4fa09e82+0x2c0>
  408c09:	mov    QWORD PTR [rdx+0x58],rax
  408c0d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c12:	lea    r8,[rsp+0x18]
  408c17:	mov    QWORD PTR [rdx+0x60],r8
  408c1b:	mov    QWORD PTR [rdx+0x68],r13
  408c1f:	mov    DWORD PTR [rdx+0x28],ecx
  408c22:	lea    rcx,[rdx+0x28]
  408c26:	mov    QWORD PTR [rdx+0x70],rcx
  408c2a:	mov    QWORD PTR [rdx+0x78],rax
  408c2e:	mov    QWORD PTR [rdx+0x80],r14
  408c35:	mov    QWORD PTR [rdx+0x88],r13
  408c3c:	lea    rax,[rdx+0x30]
  408c40:	mov    QWORD PTR [rdx+0x90],rax
  408c47:	mov    QWORD PTR [rdx+0x98],0x6
  408c52:	lea    rcx,[rdx+0x90]
  408c59:	sub    rsp,0x8
  408c5d:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  408c62:	add    rsp,0x8
  408c66:	add    rsp,0xa0
  408c6d:	sub    rsp,0x20
  408c71:	mov    rax,rsp
  408c74:	mov    QWORD PTR [rax],r14
  408c77:	mov    QWORD PTR [rax+0x8],r13
  408c7b:	mov    QWORD PTR [rax+0x10],rsp
  408c7f:	mov    QWORD PTR [rax+0x18],0x1
  408c87:	lea    rcx,[rsp+0x10]
  408c8c:	sub    rsp,0x8
  408c90:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  408c95:	add    rsp,0x8
  408c99:	add    rsp,0x20
  408c9d:	mov    eax,DWORD PTR [r12+0x9ac]
  408ca5:	test   eax,eax
  408ca7:	je     408ee0 <__swc_fn_4fa09e82_000102_14986ec5+0x480>
  408cad:	lea    rax,[rip+0xa764]        # 413418 <__swc_rdata_base_4fa09e82+0x308>
  408cb4:	sub    rsp,0x20
  408cb8:	mov    rcx,rsp
  408cbb:	mov    QWORD PTR [rcx],rax
  408cbe:	mov    QWORD PTR [rcx+0x8],r13
  408cc2:	mov    QWORD PTR [rcx+0x10],rsp
  408cc6:	mov    QWORD PTR [rcx+0x18],0x1
  408cce:	lea    rcx,[rsp+0x10]
  408cd3:	sub    rsp,0x8
  408cd7:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  408cdc:	add    rsp,0x8
  408ce0:	add    rsp,0x20
  408ce4:	mov    eax,DWORD PTR [r12+0x9ac]
  408cec:	dec    eax
  408cee:	mov    esi,eax
  408cf0:	test   esi,esi
  408cf2:	jl     408eb0 <__swc_fn_4fa09e82_000102_14986ec5+0x450>
  408cf8:	jmp    408d04 <__swc_fn_4fa09e82_000102_14986ec5+0x2a4>
  408cfa:	nop    WORD PTR [rax+rax*1+0x0]
  408d00:	dec    esi
  408d02:	jmp    408cf0 <__swc_fn_4fa09e82_000102_14986ec5+0x290>
  408d04:	lea    rax,[rip+0xa71d]        # 413428 <__swc_rdata_base_4fa09e82+0x318>
  408d0b:	sub    rsp,0x20
  408d0f:	mov    rcx,rsp
  408d12:	mov    QWORD PTR [rcx],rax
  408d15:	mov    QWORD PTR [rcx+0x8],r13
  408d19:	mov    QWORD PTR [rcx+0x10],rsp
  408d1d:	mov    QWORD PTR [rcx+0x18],0x1
  408d25:	lea    rcx,[rsp+0x10]
  408d2a:	sub    rsp,0x8
  408d2e:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  408d33:	add    rsp,0x8
  408d37:	add    rsp,0x20
  408d3b:	movsxd rax,esi
  408d3e:	imul   r15,rax,0x30
  408d42:	add    r15,r12
  408d45:	add    r15,0xf8
  408d4c:	sub    rsp,0x20
  408d50:	mov    rax,rsp
  408d53:	mov    QWORD PTR [rax],r15
  408d56:	mov    QWORD PTR [rax+0x8],rdi
  408d5a:	mov    QWORD PTR [rax+0x10],rsp
  408d5e:	mov    QWORD PTR [rax+0x18],0x1
  408d66:	lea    rcx,[rsp+0x10]
  408d6b:	sub    rsp,0x8
  408d6f:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  408d74:	add    rsp,0x8
  408d78:	add    rsp,0x20
  408d7c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408d84:	lea    rsi,[rip+0xa6ad]        # 413438 <__swc_rdata_base_4fa09e82+0x328>
  408d8b:	sub    rsp,0x20
  408d8f:	mov    rax,rsp
  408d92:	mov    QWORD PTR [rax],rsi
  408d95:	mov    QWORD PTR [rax+0x8],r13
  408d99:	mov    QWORD PTR [rax+0x10],rsp
  408d9d:	mov    QWORD PTR [rax+0x18],0x1
  408da5:	lea    rcx,[rsp+0x10]
  408daa:	sub    rsp,0x8
  408dae:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  408db3:	add    rsp,0x8
  408db7:	add    rsp,0x20
  408dbb:	sub    rsp,0x30
  408dbf:	mov    rax,rsp
  408dc2:	mov    ecx,DWORD PTR [r15+0x20]
  408dc6:	mov    QWORD PTR [rax],rcx
  408dc9:	mov    QWORD PTR [rax+0x8],rsp
  408dcd:	lea    rdi,[rip+0xa674]        # 413448 <__swc_rdata_base_4fa09e82+0x338>
  408dd4:	mov    QWORD PTR [rax+0x10],rdi
  408dd8:	lea    rcx,[rsp+0x8]
  408ddd:	mov    QWORD PTR [rax+0x18],rcx
  408de1:	mov    QWORD PTR [rax+0x20],0x1
  408de9:	lea    rcx,[rsp+0x18]
  408dee:	sub    rsp,0x8
  408df2:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  408df7:	add    rsp,0x8
  408dfb:	add    rsp,0x30
  408dff:	sub    rsp,0x20
  408e03:	mov    rax,rsp
  408e06:	mov    QWORD PTR [rax],rsi
  408e09:	mov    QWORD PTR [rax+0x8],r13
  408e0d:	mov    QWORD PTR [rax+0x10],rsp
  408e11:	mov    QWORD PTR [rax+0x18],0x1
  408e19:	lea    rcx,[rsp+0x10]
  408e1e:	sub    rsp,0x8
  408e22:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  408e27:	add    rsp,0x8
  408e2b:	add    rsp,0x20
  408e2f:	sub    rsp,0x30
  408e33:	mov    rax,rsp
  408e36:	mov    ecx,DWORD PTR [r15+0x24]
  408e3a:	mov    QWORD PTR [rax],rcx
  408e3d:	mov    QWORD PTR [rax+0x8],rsp
  408e41:	mov    QWORD PTR [rax+0x10],rdi
  408e45:	lea    rcx,[rsp+0x8]
  408e4a:	mov    QWORD PTR [rax+0x18],rcx
  408e4e:	mov    QWORD PTR [rax+0x20],0x1
  408e56:	lea    rcx,[rsp+0x18]
  408e5b:	sub    rsp,0x8
  408e5f:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  408e64:	add    rsp,0x8
  408e68:	add    rsp,0x30
  408e6c:	sub    rsp,0x20
  408e70:	mov    rax,rsp
  408e73:	mov    QWORD PTR [rax],r14
  408e76:	mov    QWORD PTR [rax+0x8],r13
  408e7a:	mov    QWORD PTR [rax+0x10],rsp
  408e7e:	mov    QWORD PTR [rax+0x18],0x1
  408e86:	lea    rcx,[rsp+0x10]
  408e8b:	sub    rsp,0x8
  408e8f:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  408e94:	add    rsp,0x8
  408e98:	add    rsp,0x20
  408e9c:	lea    rdi,[rip+0xa4d5]        # 413378 <__swc_rdata_base_4fa09e82+0x268>
  408ea3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408eab:	jmp    408d00 <__swc_fn_4fa09e82_000102_14986ec5+0x2a0>
  408eb0:	sub    rsp,0x20
  408eb4:	mov    rax,rsp
  408eb7:	mov    QWORD PTR [rax],r14
  408eba:	mov    QWORD PTR [rax+0x8],r13
  408ebe:	mov    QWORD PTR [rax+0x10],rsp
  408ec2:	mov    QWORD PTR [rax+0x18],0x1
  408eca:	lea    rcx,[rsp+0x10]
  408ecf:	sub    rsp,0x8
  408ed3:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  408ed8:	add    rsp,0x8
  408edc:	add    rsp,0x20
  408ee0:	lea    rax,[rbx+0x28]
  408ee4:	mov    rcx,rax
  408ee7:	mov    QWORD PTR [rbx+0x28],0x0
  408eef:	mov    QWORD PTR [rbx+0x30],0x0
  408ef7:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408efc:	add    rcx,0x10
  408f00:	mov    edx,0x1f
  408f05:	cs nop WORD PTR [rax+rax*1+0x0]
  408f0f:	nop
  408f10:	vmovups XMMWORD PTR [rcx],xmm0
  408f14:	add    rcx,0x10
  408f18:	sub    rdx,0x1
  408f1c:	jne    408f10 <__swc_fn_4fa09e82_000102_14986ec5+0x4b0>
  408f1e:	lea    rsi,[rbx+0x228]
  408f25:	xor    ecx,ecx
  408f27:	cs nop WORD PTR [rax+rax*1+0x0]
  408f31:	cs nop WORD PTR [rax+rax*1+0x0]
  408f3b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f40:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f45:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f4a:	add    rcx,0x10
  408f4e:	cmp    rcx,0x200
  408f55:	jne    408f40 <__swc_fn_4fa09e82_000102_14986ec5+0x4e0>
  408f57:	mov    eax,DWORD PTR [r12+0xbc8]
  408f5f:	lea    rcx,[r12+0x9c8]
  408f67:	mov    QWORD PTR [rbx+0x428],rcx
  408f6e:	mov    QWORD PTR [rbx+0x430],rax
  408f75:	lea    rdi,[rbx+0x438]
  408f7c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408f84:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408f8c:	mov    eax,DWORD PTR [r12+0xbc8]
  408f94:	test   eax,eax
  408f96:	jne    408fe3 <__swc_fn_4fa09e82_000102_14986ec5+0x583>
  408f98:	lea    rax,[rbx+0x448]
  408f9f:	mov    QWORD PTR [rbx+0x448],rsi
  408fa6:	mov    QWORD PTR [rax+0x8],0x40
  408fae:	mov    ecx,0x1
  408fb3:	mov    rdx,rax
  408fb6:	sub    rsp,0x8
  408fba:	call   409980 <__swc_fn_4fa09e82_000120_2d9caf16>
  408fbf:	add    rsp,0x8
  408fc3:	mov    QWORD PTR [rbx+0x460],rsi
  408fca:	mov    ecx,eax
  408fcc:	mov    QWORD PTR [rbx+0x468],rcx
  408fd3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408fdb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fe3:	mov    rsi,QWORD PTR [rbx+0x438]
  408fea:	mov    rax,QWORD PTR [rbx+0x440]
  408ff1:	mov    r15,rax
  408ff4:	xor    r12d,r12d
  408ff7:	test   r15,r15
  408ffa:	je     4090b0 <__swc_fn_4fa09e82_000102_14986ec5+0x650>
  409000:	mov    rax,QWORD PTR [rsi+r12*8]
  409004:	test   rax,rax
  409007:	je     409026 <__swc_fn_4fa09e82_000102_14986ec5+0x5c6>
  409009:	lea    rcx,[rbx+0x4b8]
  409010:	mov    rdx,rax
  409013:	sub    rsp,0x8
  409017:	call   40ed90 <__swc_fn_4fa09e82_000163_61e293bf>
  40901c:	add    rsp,0x8
  409020:	mov    al,BYTE PTR [rax]
  409022:	test   al,al
  409024:	jne    409032 <__swc_fn_4fa09e82_000102_14986ec5+0x5d2>
  409026:	add    r12,0x1
  40902a:	sub    r15,0x1
  40902e:	jne    409000 <__swc_fn_4fa09e82_000102_14986ec5+0x5a0>
  409030:	jmp    4090b0 <__swc_fn_4fa09e82_000102_14986ec5+0x650>
  409032:	lea    rax,[rip+0xa457]        # 413490 <__swc_rdata_base_4fa09e82+0x380>
  409039:	sub    rsp,0x20
  40903d:	mov    rcx,rsp
  409040:	mov    QWORD PTR [rcx],rax
  409043:	mov    QWORD PTR [rcx+0x8],r13
  409047:	mov    QWORD PTR [rcx+0x10],rsp
  40904b:	mov    QWORD PTR [rcx+0x18],0x1
  409053:	lea    rcx,[rsp+0x10]
  409058:	sub    rsp,0x8
  40905c:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  409061:	add    rsp,0x8
  409065:	add    rsp,0x20
  409069:	mov    rcx,rdi
  40906c:	xor    edx,edx
  40906e:	mov    al,0x1
  409070:	mov    r8,rax
  409073:	sub    rsp,0x8
  409077:	call   411c80 <__swc_fn_4fa09e82_000164_3a7aae74>
  40907c:	add    rsp,0x8
  409080:	sub    rsp,0x20
  409084:	mov    rax,rsp
  409087:	mov    QWORD PTR [rax],r14
  40908a:	mov    QWORD PTR [rax+0x8],r13
  40908e:	mov    QWORD PTR [rax+0x10],rsp
  409092:	mov    QWORD PTR [rax+0x18],0x1
  40909a:	lea    rcx,[rsp+0x10]
  40909f:	sub    rsp,0x8
  4090a3:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  4090a8:	add    rsp,0x8
  4090ac:	add    rsp,0x20
  4090b0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090b8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090c4:	add    rsp,0x500
  4090cb:	pop    r15
  4090cd:	pop    r14
  4090cf:	pop    r13
  4090d1:	pop    r12
  4090d3:	pop    rdi
  4090d4:	pop    rsi
  4090d5:	pop    rbx
  4090d6:	pop    rbp
  4090d7:	ret
	...

00000000004090e0 <__swc_fn_4fa09e82_000105_7e71bba2>:
  4090e0:	test   r8,r8
  4090e3:	jne    4090e6 <__swc_fn_4fa09e82_000105_7e71bba2+0x6>
  4090e5:	ret
  4090e6:	xor    eax,eax
  4090e8:	movzx  r9d,dl
  4090ec:	movabs r10,0x101010101010101
  4090f6:	imul   r9,r10
  4090fa:	vmovq  xmm0,r9
  4090ff:	vpshufd xmm0,xmm0,0x44
  409104:	cs nop WORD PTR [rax+rax*1+0x0]
  40910e:	xchg   ax,ax
  409110:	mov    r10,r8
  409113:	sub    r10,rax
  409116:	cmp    r10,0x40
  40911a:	jb     40913d <__swc_fn_4fa09e82_000105_7e71bba2+0x5d>
  40911c:	lea    r10,[rcx+rax*1]
  409120:	vmovups XMMWORD PTR [r10],xmm0
  409125:	vmovups XMMWORD PTR [r10+0x10],xmm0
  40912b:	vmovups XMMWORD PTR [r10+0x20],xmm0
  409131:	vmovups XMMWORD PTR [r10+0x30],xmm0
  409137:	lea    rax,[rax+0x40]
  40913b:	jmp    409110 <__swc_fn_4fa09e82_000105_7e71bba2+0x30>
  40913d:	nop    DWORD PTR [rax]
  409140:	mov    r10,r8
  409143:	sub    r10,rax
  409146:	cmp    r10,0x10
  40914a:	jb     40915b <__swc_fn_4fa09e82_000105_7e71bba2+0x7b>
  40914c:	lea    r10,[rcx+rax*1]
  409150:	vmovups XMMWORD PTR [r10],xmm0
  409155:	lea    rax,[rax+0x10]
  409159:	jmp    409140 <__swc_fn_4fa09e82_000105_7e71bba2+0x60>
  40915b:	nop    DWORD PTR [rax+rax*1+0x0]
  409160:	mov    r10,r8
  409163:	sub    r10,rax
  409166:	cmp    r10,0x8
  40916a:	jb     409179 <__swc_fn_4fa09e82_000105_7e71bba2+0x99>
  40916c:	lea    r10,[rcx+rax*1]
  409170:	mov    QWORD PTR [r10],r9
  409173:	lea    rax,[rax+0x8]
  409177:	jmp    409160 <__swc_fn_4fa09e82_000105_7e71bba2+0x80>
  409179:	cmp    rax,r8
  40917c:	jae    40918b <__swc_fn_4fa09e82_000105_7e71bba2+0xab>
  40917e:	xchg   ax,ax
  409180:	mov    BYTE PTR [rcx+rax*1],dl
  409183:	inc    rax
  409186:	cmp    rax,r8
  409189:	jb     409180 <__swc_fn_4fa09e82_000105_7e71bba2+0xa0>
  40918b:	ret
  40918c:	add    BYTE PTR [rax],al
	...

0000000000409190 <__swc_fn_4fa09e82_000108_c8d4a68e>:
  409190:	push   rbx
  409191:	push   r12
  409193:	push   rdi
  409194:	push   rsi
  409195:	push   r13
  409197:	push   r14
  409199:	push   r15
  40919b:	sub    rsp,0x170
  4091a2:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  4091ab:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  4091b4:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  4091bd:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  4091c6:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  4091cf:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  4091d8:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  4091e1:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  4091ea:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  4091f3:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  4091fc:	mov    ebx,edx
  4091fe:	mov    QWORD PTR [rsp+0xa8],rbx
  409206:	mov    r12d,ecx
  409209:	test   edx,edx
  40920b:	jne    409222 <__swc_fn_4fa09e82_000108_c8d4a68e+0x92>
  40920d:	xor    eax,eax
  40920f:	add    rsp,0x170
  409216:	pop    r15
  409218:	pop    r14
  40921a:	pop    r13
  40921c:	pop    rsi
  40921d:	pop    rdi
  40921e:	pop    r12
  409220:	pop    rbx
  409221:	ret
  409222:	lea    rdi,[rip+0xa287]        # 4134b0 <__swc_rdata_base_4fa09e82+0x3a0>
  409229:	mov    esi,0x90000
  40922e:	xor    eax,eax
  409230:	call   407010 <open@plt>
  409235:	mov    r13,rax
  409238:	mov    QWORD PTR [rsp+0xb0],rax
  409240:	test   eax,eax
  409242:	jge    40924b <__swc_fn_4fa09e82_000108_c8d4a68e+0xbb>
  409244:	xor    eax,eax
  409246:	jmp    409746 <__swc_fn_4fa09e82_000108_c8d4a68e+0x5b6>
  40924b:	nop    DWORD PTR [rax+rax*1+0x0]
  409250:	movsxd rdi,r13d
  409253:	mov    esi,0x2
  409258:	xor    eax,eax
  40925a:	call   407020 <flock@plt>
  40925f:	test   eax,eax
  409261:	je     409280 <__swc_fn_4fa09e82_000108_c8d4a68e+0xf0>
  409263:	xor    eax,eax
  409265:	call   407030 <__errno_location@plt>
  40926a:	cmp    DWORD PTR [rax],0x4
  40926d:	je     409250 <__swc_fn_4fa09e82_000108_c8d4a68e+0xc0>
  40926f:	movsxd rdi,r13d
  409272:	xor    eax,eax
  409274:	call   407040 <close@plt>
  409279:	xor    eax,eax
  40927b:	jmp    409746 <__swc_fn_4fa09e82_000108_c8d4a68e+0x5b6>
  409280:	lea    r14,[rsp+0x8]
  409285:	mov    QWORD PTR [rsp+0xb8],r14
  40928d:	vxorps xmm0,xmm0,xmm0
  409291:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409297:	mov    QWORD PTR [rsp+0x18],0x0
  4092a0:	mov    WORD PTR [rsp+0x20],0x0
  4092a7:	mov    DWORD PTR [r14],0x67617753
  4092ae:	mov    DWORD PTR [r14+0x4],0x2e74522e
  4092b6:	xor    eax,eax
  4092b8:	call   407050 <getpid@plt>
  4092bd:	mov    ecx,eax
  4092bf:	mov    eax,0x1c
  4092c4:	shrx   eax,ecx,eax
  4092c9:	and    eax,0xf
  4092cc:	mov    rdx,QWORD PTR [rip+0xa1fd]        # 4134d0 <__swc_rdata_base_4fa09e82+0x3c0>
  4092d3:	mov    al,BYTE PTR [rdx+rax*1]
  4092d6:	rex mov BYTE PTR [rsp+0x10],al
  4092db:	mov    eax,0x1c
  4092e0:	shrx   eax,r12d,eax
  4092e5:	and    eax,0xf
  4092e8:	mov    al,BYTE PTR [rdx+rax*1]
  4092eb:	rex mov BYTE PTR [rsp+0x19],al
  4092f0:	mov    eax,0x18
  4092f5:	shrx   eax,ecx,eax
  4092fa:	and    eax,0xf
  4092fd:	mov    al,BYTE PTR [rdx+rax*1]
  409300:	rex mov BYTE PTR [rsp+0x11],al
  409305:	mov    eax,0x18
  40930a:	shrx   eax,r12d,eax
  40930f:	and    eax,0xf
  409312:	mov    al,BYTE PTR [rdx+rax*1]
  409315:	rex mov BYTE PTR [rsp+0x1a],al
  40931a:	mov    eax,0x14
  40931f:	shrx   eax,ecx,eax
  409324:	and    eax,0xf
  409327:	mov    al,BYTE PTR [rdx+rax*1]
  40932a:	rex mov BYTE PTR [rsp+0x12],al
  40932f:	mov    eax,0x14
  409334:	shrx   eax,r12d,eax
  409339:	and    eax,0xf
  40933c:	mov    al,BYTE PTR [rdx+rax*1]
  40933f:	rex mov BYTE PTR [rsp+0x1b],al
  409344:	mov    eax,0x10
  409349:	shrx   eax,ecx,eax
  40934e:	and    eax,0xf
  409351:	mov    al,BYTE PTR [rdx+rax*1]
  409354:	rex mov BYTE PTR [rsp+0x13],al
  409359:	mov    eax,0x10
  40935e:	shrx   eax,r12d,eax
  409363:	and    eax,0xf
  409366:	mov    al,BYTE PTR [rdx+rax*1]
  409369:	rex mov BYTE PTR [rsp+0x1c],al
  40936e:	mov    eax,0xc
  409373:	shrx   eax,ecx,eax
  409378:	and    eax,0xf
  40937b:	mov    al,BYTE PTR [rdx+rax*1]
  40937e:	rex mov BYTE PTR [rsp+0x14],al
  409383:	mov    eax,0xc
  409388:	shrx   eax,r12d,eax
  40938d:	and    eax,0xf
  409390:	mov    al,BYTE PTR [rdx+rax*1]
  409393:	rex mov BYTE PTR [rsp+0x1d],al
  409398:	mov    eax,0x8
  40939d:	shrx   eax,ecx,eax
  4093a2:	and    eax,0xf
  4093a5:	mov    al,BYTE PTR [rdx+rax*1]
  4093a8:	rex mov BYTE PTR [rsp+0x15],al
  4093ad:	mov    eax,0x8
  4093b2:	shrx   eax,r12d,eax
  4093b7:	and    eax,0xf
  4093ba:	mov    al,BYTE PTR [rdx+rax*1]
  4093bd:	rex mov BYTE PTR [rsp+0x1e],al
  4093c2:	mov    eax,0x4
  4093c7:	shrx   eax,ecx,eax
  4093cc:	and    eax,0xf
  4093cf:	mov    al,BYTE PTR [rdx+rax*1]
  4093d2:	rex mov BYTE PTR [rsp+0x16],al
  4093d7:	mov    eax,0x4
  4093dc:	shrx   eax,r12d,eax
  4093e1:	and    eax,0xf
  4093e4:	mov    al,BYTE PTR [rdx+rax*1]
  4093e7:	rex mov BYTE PTR [rsp+0x1f],al
  4093ec:	xor    eax,eax
  4093ee:	shrx   eax,ecx,eax
  4093f3:	and    eax,0xf
  4093f6:	mov    al,BYTE PTR [rdx+rax*1]
  4093f9:	rex mov BYTE PTR [rsp+0x17],al
  4093fe:	xor    eax,eax
  409400:	shrx   eax,r12d,eax
  409405:	and    eax,0xf
  409408:	mov    al,BYTE PTR [rdx+rax*1]
  40940b:	rex mov BYTE PTR [rsp+0x20],al
  409410:	mov    BYTE PTR [r14+0x10],0x2e
  409415:	lea    r12,[rsp+0x22]
  40941a:	vxorps xmm0,xmm0,xmm0
  40941e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  409424:	mov    DWORD PTR [r12],0x6d656d2f
  40942c:	mov    WORD PTR [r12+0x4],0x6466
  409434:	mov    BYTE PTR [r12+0x6],0x3a
  40943a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409440:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  409446:	mov    rax,QWORD PTR [rsp+0x18]
  40944b:	mov    QWORD PTR [rsp+0x39],rax
  409450:	rex mov al,BYTE PTR [rsp+0x20]
  409455:	rex mov BYTE PTR [rsp+0x41],al
  40945a:	mov    DWORD PTR [r12+0x20],0x65642820
  409463:	mov    DWORD PTR [r12+0x24],0x6574656c
  40946c:	mov    WORD PTR [r12+0x28],0x2964
  409474:	lea    rdi,[rip+0xa040]        # 4134bb <__swc_rdata_base_4fa09e82+0x3ab>
  40947b:	xor    eax,eax
  40947d:	call   407060 <opendir@plt>
  409482:	mov    r15,rax
  409485:	test   rax,rax
  409488:	jne    40949b <__swc_fn_4fa09e82_000108_c8d4a68e+0x30b>
  40948a:	movsxd rdi,r13d
  40948d:	xor    eax,eax
  40948f:	call   407040 <close@plt>
  409494:	xor    eax,eax
  409496:	jmp    409746 <__swc_fn_4fa09e82_000108_c8d4a68e+0x5b6>
  40949b:	mov    rdi,r15
  40949e:	xor    eax,eax
  4094a0:	call   407070 <dirfd@plt>
  4094a5:	lea    r14,[rsp+0x54]
  4094aa:	mov    DWORD PTR [rsp+0x54],eax
  4094ae:	lea    rbx,[rsp+0x58]
  4094b3:	cs nop WORD PTR [rax+rax*1+0x0]
  4094bd:	nop    DWORD PTR [rax]
  4094c0:	mov    rdi,r15
  4094c3:	xor    eax,eax
  4094c5:	call   407080 <readdir@plt>
  4094ca:	test   rax,rax
  4094cd:	jne    4094e4 <__swc_fn_4fa09e82_000108_c8d4a68e+0x354>
  4094cf:	mov    r12,QWORD PTR [rsp+0xa8]
  4094d7:	mov    r13,QWORD PTR [rsp+0xb0]
  4094df:	jmp    40966a <__swc_fn_4fa09e82_000108_c8d4a68e+0x4da>
  4094e4:	vxorps xmm0,xmm0,xmm0
  4094e8:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  4094ee:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  4094f4:	vzeroupper
  4094f7:	lea    r13,[rax+0x13]
  4094fb:	mov    rax,r14
  4094fe:	movsxd rdi,DWORD PTR [rax]
  409501:	mov    rsi,r13
  409504:	mov    rdx,rbx
  409507:	mov    ecx,0x40
  40950c:	xor    eax,eax
  40950e:	call   407090 <readlinkat@plt>
  409513:	cmp    rax,0x2a
  409517:	jne    4094c0 <__swc_fn_4fa09e82_000108_c8d4a68e+0x330>
  409519:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40951f:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  409525:	vptest xmm0,xmm0
  40952a:	jne    40955a <__swc_fn_4fa09e82_000108_c8d4a68e+0x3ca>
  40952c:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  409532:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  409538:	vptest xmm0,xmm0
  40953d:	jne    40955a <__swc_fn_4fa09e82_000108_c8d4a68e+0x3ca>
  40953f:	mov    rcx,QWORD PTR [rsp+0x42]
  409544:	cmp    QWORD PTR [rsp+0x78],rcx
  409549:	jne    40955a <__swc_fn_4fa09e82_000108_c8d4a68e+0x3ca>
  40954b:	mov    cx,WORD PTR [rsp+0x4a]
  409550:	cmp    WORD PTR [rsp+0x80],cx
  409558:	je     409584 <__swc_fn_4fa09e82_000108_c8d4a68e+0x3f4>
  40955a:	mov    rax,rbx
  40955d:	mov    rcx,r12
  409560:	movzx  edx,BYTE PTR [rax]
  409563:	movzx  r8d,BYTE PTR [rcx]
  409567:	cmp    rdx,r8
  40956a:	jne    409576 <__swc_fn_4fa09e82_000108_c8d4a68e+0x3e6>
  40956c:	add    rax,0x1
  409570:	add    rcx,0x1
  409574:	jmp    409560 <__swc_fn_4fa09e82_000108_c8d4a68e+0x3d0>
  409576:	mov    rax,rdx
  409579:	sub    rax,r8
  40957c:	test   eax,eax
  40957e:	jne    4094c0 <__swc_fn_4fa09e82_000108_c8d4a68e+0x330>
  409584:	movsxd rdi,DWORD PTR [r14]
  409587:	mov    rsi,r13
  40958a:	mov    edx,0x80002
  40958f:	xor    eax,eax
  409591:	call   4070a0 <openat@plt>
  409596:	lea    rbx,[rsp+0x98]
  40959e:	mov    DWORD PTR [rsp+0x98],eax
  4095a5:	test   eax,eax
  4095a7:	mov    r13,QWORD PTR [rsp+0xb0]
  4095af:	jge    4095d4 <__swc_fn_4fa09e82_000108_c8d4a68e+0x444>
  4095b1:	mov    rdi,r15
  4095b4:	xor    eax,eax
  4095b6:	call   4070b0 <closedir@plt>
  4095bb:	mov    r13,QWORD PTR [rsp+0xb0]
  4095c3:	movsxd rdi,r13d
  4095c6:	xor    eax,eax
  4095c8:	call   407040 <close@plt>
  4095cd:	xor    eax,eax
  4095cf:	jmp    409746 <__swc_fn_4fa09e82_000108_c8d4a68e+0x5b6>
  4095d4:	mov    rax,rbx
  4095d7:	movsxd rdi,DWORD PTR [rax]
  4095da:	xor    esi,esi
  4095dc:	mov    edx,0x2
  4095e1:	xor    eax,eax
  4095e3:	call   4070c0 <lseek@plt>
  4095e8:	mov    r12,QWORD PTR [rsp+0xa8]
  4095f0:	cmp    rax,r12
  4095f3:	je     40961a <__swc_fn_4fa09e82_000108_c8d4a68e+0x48a>
  4095f5:	movsxd rdi,DWORD PTR [rbx]
  4095f8:	xor    eax,eax
  4095fa:	call   407040 <close@plt>
  4095ff:	mov    rdi,r15
  409602:	xor    eax,eax
  409604:	call   4070b0 <closedir@plt>
  409609:	movsxd rdi,r13d
  40960c:	xor    eax,eax
  40960e:	call   407040 <close@plt>
  409613:	xor    eax,eax
  409615:	jmp    409746 <__swc_fn_4fa09e82_000108_c8d4a68e+0x5b6>
  40961a:	xor    edi,edi
  40961c:	mov    rsi,r12
  40961f:	mov    edx,0x3
  409624:	mov    ecx,0x1
  409629:	mov    rax,rbx
  40962c:	movsxd r8,DWORD PTR [rax]
  40962f:	xor    r9d,r9d
  409632:	xor    eax,eax
  409634:	call   4070d0 <mmap@plt>
  409639:	xor    r12d,r12d
  40963c:	cmp    rax,0xffffffffffffffff
  409640:	cmovne r12,rax
  409644:	movsxd rdi,DWORD PTR [rbx]
  409647:	xor    eax,eax
  409649:	call   407040 <close@plt>
  40964e:	mov    rdi,r15
  409651:	xor    eax,eax
  409653:	call   4070b0 <closedir@plt>
  409658:	movsxd rdi,r13d
  40965b:	xor    eax,eax
  40965d:	call   407040 <close@plt>
  409662:	mov    rax,r12
  409665:	jmp    409746 <__swc_fn_4fa09e82_000108_c8d4a68e+0x5b6>
  40966a:	mov    r14,QWORD PTR [rsp+0xb8]
  409672:	mov    rdi,r14
  409675:	mov    esi,0x1
  40967a:	xor    eax,eax
  40967c:	call   4070e0 <memfd_create@plt>
  409681:	lea    rbx,[rsp+0x9c]
  409689:	mov    DWORD PTR [rsp+0x9c],eax
  409690:	test   eax,eax
  409692:	jge    4096af <__swc_fn_4fa09e82_000108_c8d4a68e+0x51f>
  409694:	mov    rdi,r15
  409697:	xor    eax,eax
  409699:	call   4070b0 <closedir@plt>
  40969e:	movsxd rdi,r13d
  4096a1:	xor    eax,eax
  4096a3:	call   407040 <close@plt>
  4096a8:	xor    eax,eax
  4096aa:	jmp    409746 <__swc_fn_4fa09e82_000108_c8d4a68e+0x5b6>
  4096af:	mov    rax,rbx
  4096b2:	movsxd rdi,DWORD PTR [rax]
  4096b5:	mov    rsi,r12
  4096b8:	xor    eax,eax
  4096ba:	call   4070f0 <ftruncate@plt>
  4096bf:	test   eax,eax
  4096c1:	je     4096e5 <__swc_fn_4fa09e82_000108_c8d4a68e+0x555>
  4096c3:	movsxd rdi,DWORD PTR [rbx]
  4096c6:	xor    eax,eax
  4096c8:	call   407040 <close@plt>
  4096cd:	mov    rdi,r15
  4096d0:	xor    eax,eax
  4096d2:	call   4070b0 <closedir@plt>
  4096d7:	movsxd rdi,r13d
  4096da:	xor    eax,eax
  4096dc:	call   407040 <close@plt>
  4096e1:	xor    eax,eax
  4096e3:	jmp    409746 <__swc_fn_4fa09e82_000108_c8d4a68e+0x5b6>
  4096e5:	xor    edi,edi
  4096e7:	mov    rsi,r12
  4096ea:	mov    edx,0x3
  4096ef:	mov    ecx,0x1
  4096f4:	mov    rax,rbx
  4096f7:	movsxd r8,DWORD PTR [rax]
  4096fa:	xor    r9d,r9d
  4096fd:	xor    eax,eax
  4096ff:	call   4070d0 <mmap@plt>
  409704:	mov    r12,rax
  409707:	cmp    rax,0xffffffffffffffff
  40970b:	jne    40972f <__swc_fn_4fa09e82_000108_c8d4a68e+0x59f>
  40970d:	movsxd rdi,DWORD PTR [rbx]
  409710:	xor    eax,eax
  409712:	call   407040 <close@plt>
  409717:	mov    rdi,r15
  40971a:	xor    eax,eax
  40971c:	call   4070b0 <closedir@plt>
  409721:	movsxd rdi,r13d
  409724:	xor    eax,eax
  409726:	call   407040 <close@plt>
  40972b:	xor    eax,eax
  40972d:	jmp    409746 <__swc_fn_4fa09e82_000108_c8d4a68e+0x5b6>
  40972f:	mov    rdi,r15
  409732:	xor    eax,eax
  409734:	call   4070b0 <closedir@plt>
  409739:	movsxd rdi,r13d
  40973c:	xor    eax,eax
  40973e:	call   407040 <close@plt>
  409743:	mov    rax,r12
  409746:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40974f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  409758:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  409761:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40976a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  409773:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40977c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  409785:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40978e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  409797:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  4097a0:	add    rsp,0x170
  4097a7:	pop    r15
  4097a9:	pop    r14
  4097ab:	pop    r13
  4097ad:	pop    rsi
  4097ae:	pop    rdi
  4097af:	pop    r12
  4097b1:	pop    rbx
  4097b2:	ret
	...

00000000004097c0 <__swc_fn_4fa09e82_000111_918d5a21>:
  4097c0:	push   rsi
  4097c1:	push   rdi
  4097c2:	push   r12
  4097c4:	push   r13
  4097c6:	sub    rsp,0x8
  4097ca:	mov    rsi,r8
  4097cd:	mov    rdi,rcx
  4097d0:	mov    r12,rdx
  4097d3:	call   40df80 <__swc_fn_4fa09e82_000109_b8f4bd15>
  4097d8:	mov    r13,rax
  4097db:	test   rax,rax
  4097de:	jne    4097eb <__swc_fn_4fa09e82_000111_918d5a21+0x2b>
  4097e0:	add    rsp,0x8
  4097e4:	pop    r13
  4097e6:	pop    r12
  4097e8:	pop    rdi
  4097e9:	pop    rsi
  4097ea:	ret
  4097eb:	mov    rcx,r13
  4097ee:	call   411790 <__swc_fn_4fa09e82_000134_807fd51d>
  4097f3:	mov    rax,QWORD PTR [r13+0x8]
  4097f7:	test   rax,rax
  4097fa:	je     409839 <__swc_fn_4fa09e82_000111_918d5a21+0x79>
  4097fc:	nop    DWORD PTR [rax+0x0]
  409800:	lea    rcx,[rax+0x1000]
  409807:	cmp    rdi,rcx
  40980a:	jne    409831 <__swc_fn_4fa09e82_000111_918d5a21+0x71>
  40980c:	cmp    r12,0x1000
  409813:	jb     409831 <__swc_fn_4fa09e82_000111_918d5a21+0x71>
  409815:	test   sil,sil
  409818:	setne  cl
  40981b:	mov    BYTE PTR [rax+0x10],cl
  40981e:	mov    rcx,r13
  409821:	call   409d20 <__swc_fn_4fa09e82_000135_10472836>
  409826:	add    rsp,0x8
  40982a:	pop    r13
  40982c:	pop    r12
  40982e:	pop    rdi
  40982f:	pop    rsi
  409830:	ret
  409831:	mov    rax,QWORD PTR [rax]
  409834:	test   rax,rax
  409837:	jne    409800 <__swc_fn_4fa09e82_000111_918d5a21+0x40>
  409839:	mov    rcx,r13
  40983c:	call   409d20 <__swc_fn_4fa09e82_000135_10472836>
  409841:	add    rsp,0x8
  409845:	pop    r13
  409847:	pop    r12
  409849:	pop    rdi
  40984a:	pop    rsi
  40984b:	ret
  40984c:	add    BYTE PTR [rax],al
	...

0000000000409850 <__swc_fn_4fa09e82_000114_4e83a03a>:
  409850:	sub    rsp,0x8
  409854:	test   rcx,rcx
  409857:	jne    40985e <__swc_fn_4fa09e82_000114_4e83a03a+0xe>
  409859:	add    rsp,0x8
  40985d:	ret
  40985e:	call   411290 <__swc_fn_4fa09e82_000116_3f6af4b1>
  409863:	add    rsp,0x8
  409867:	ret
	...

0000000000409870 <__swc_fn_4fa09e82_000117_3f5cfdef>:
  409870:	push   r12
  409872:	push   r13
  409874:	push   r14
  409876:	push   rdi
  409877:	push   rsi
  409878:	sub    rsp,0xc0
  40987f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409885:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40988b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409891:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409897:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40989d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4098a3:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4098a9:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4098b2:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4098bb:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4098c4:	mov    r12,QWORD PTR [rcx]
  4098c7:	test   r12,r12
  4098ca:	jne    4098dc <__swc_fn_4fa09e82_000117_3f5cfdef+0x6c>
  4098cc:	add    rsp,0xc0
  4098d3:	pop    rsi
  4098d4:	pop    rdi
  4098d5:	pop    r14
  4098d7:	pop    r13
  4098d9:	pop    r12
  4098db:	ret
  4098dc:	xor    r13d,r13d
  4098df:	mov    r14,QWORD PTR [rcx+0x8]
  4098e3:	cs nop WORD PTR [rax+rax*1+0x0]
  4098ed:	nop    DWORD PTR [rax]
  4098f0:	cmp    r13,r14
  4098f3:	jae    40992b <__swc_fn_4fa09e82_000117_3f5cfdef+0xbb>
  4098f5:	lea    rax,[r12+r13*1]
  4098f9:	mov    rcx,r14
  4098fc:	sub    rcx,r13
  4098ff:	mov    edi,0x1
  409904:	mov    rsi,rax
  409907:	mov    rdx,rcx
  40990a:	xor    eax,eax
  40990c:	call   407100 <write@plt>
  409911:	test   rax,rax
  409914:	jle    40991b <__swc_fn_4fa09e82_000117_3f5cfdef+0xab>
  409916:	add    r13,rax
  409919:	jmp    4098f0 <__swc_fn_4fa09e82_000117_3f5cfdef+0x80>
  40991b:	je     409929 <__swc_fn_4fa09e82_000117_3f5cfdef+0xb9>
  40991d:	xor    eax,eax
  40991f:	call   407030 <__errno_location@plt>
  409924:	cmp    DWORD PTR [rax],0x4
  409927:	je     4098f0 <__swc_fn_4fa09e82_000117_3f5cfdef+0x80>
  409929:	jmp    40992b <__swc_fn_4fa09e82_000117_3f5cfdef+0xbb>
  40992b:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409931:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409937:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40993d:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409943:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409949:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40994f:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409955:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40995e:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409967:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409970:	add    rsp,0xc0
  409977:	pop    rsi
  409978:	pop    rdi
  409979:	pop    r14
  40997b:	pop    r13
  40997d:	pop    r12
  40997f:	ret

0000000000409980 <__swc_fn_4fa09e82_000120_2d9caf16>:
  409980:	push   rbx
  409981:	push   r12
  409983:	push   rdi
  409984:	push   rsi
  409985:	sub    rsp,0x4a8
  40998c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  409995:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  40999e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  4099a7:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  4099b0:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  4099b9:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  4099c2:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  4099cb:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  4099d4:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  4099dd:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  4099e6:	mov    rbx,rdx
  4099e9:	mov    r12d,ecx
  4099ec:	vxorps xmm0,xmm0,xmm0
  4099f0:	xor    eax,eax
  4099f2:	cs nop WORD PTR [rax+rax*1+0x0]
  4099fc:	nop    DWORD PTR [rax+0x0]
  409a00:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  409a06:	add    rax,0x10
  409a0a:	cmp    rax,0x400
  409a11:	jne    409a00 <__swc_fn_4fa09e82_000120_2d9caf16+0x80>
  409a13:	lea    rdi,[rsp+0x8]
  409a18:	mov    esi,0x80
  409a1d:	xor    eax,eax
  409a1f:	call   407110 <backtrace@plt>
  409a24:	test   eax,eax
  409a26:	jle    409a35 <__swc_fn_4fa09e82_000120_2d9caf16+0xb5>
  409a28:	movsxd rax,eax
  409a2b:	lea    rcx,[r12+0x1]
  409a30:	cmp    rcx,rax
  409a33:	jb     409a39 <__swc_fn_4fa09e82_000120_2d9caf16+0xb9>
  409a35:	xor    eax,eax
  409a37:	jmp    409a6a <__swc_fn_4fa09e82_000120_2d9caf16+0xea>
  409a39:	mov    rcx,QWORD PTR [rbx+0x8]
  409a3d:	sub    rax,r12
  409a40:	lea    rsi,[rax-0x1]
  409a44:	cmp    rcx,rsi
  409a47:	cmovbe rsi,rcx
  409a4b:	lea    eax,[r12+0x1]
  409a50:	lea    rax,[rsp+rax*8+0x8]
  409a55:	mov    rcx,QWORD PTR [rbx]
  409a58:	mov    rdx,rax
  409a5b:	lea    r8,[rsi*8+0x0]
  409a63:	call   40df60 <__swc_fn_4fa09e82_000106_83487ba1>
  409a68:	mov    eax,esi
  409a6a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  409a73:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  409a7c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  409a85:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  409a8e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  409a97:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  409aa0:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  409aa9:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  409ab2:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  409abb:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  409ac4:	add    rsp,0x4a8
  409acb:	pop    rsi
  409acc:	pop    rdi
  409acd:	pop    r12
  409acf:	pop    rbx
  409ad0:	ret
	...

0000000000409ae0 <__swc_fn_4fa09e82_000123_66e5d2a9>:
  409ae0:	mov    QWORD PTR [rcx],0x0
  409ae7:	ret
	...

0000000000409af0 <__swc_fn_4fa09e82_000126_7a81492f>:
  409af0:	push   rdi
  409af1:	push   rsi
  409af2:	sub    rsp,0xa8
  409af9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409aff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409b05:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409b0b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409b11:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409b17:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409b1d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409b23:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409b29:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409b32:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409b3b:	mov    edi,ecx
  409b3d:	mov    rsi,rdx
  409b40:	xor    eax,eax
  409b42:	call   407120 <pthread_setspecific@plt>
  409b47:	test   eax,eax
  409b49:	sete   al
  409b4c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409b52:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409b58:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409b5e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409b64:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409b6a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409b70:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409b76:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409b7c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409b85:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409b8e:	add    rsp,0xa8
  409b95:	pop    rsi
  409b96:	pop    rdi
  409b97:	ret
	...

0000000000409ba0 <__swc_fn_4fa09e82_000129_8d8a7dd2>:
  409ba0:	push   rdi
  409ba1:	push   rsi
  409ba2:	sub    rsp,0xa8
  409ba9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409baf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409bb5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409bbb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409bc1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409bc7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409bcd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409bd3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409bd9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409be2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409beb:	test   rcx,rcx
  409bee:	je     409c01 <__swc_fn_4fa09e82_000129_8d8a7dd2+0x61>
  409bf0:	lea    rax,[rcx-0x1]
  409bf4:	mov    eax,eax
  409bf6:	mov    edi,eax
  409bf8:	xor    eax,eax
  409bfa:	call   407000 <pthread_getspecific@plt>
  409bff:	jmp    409c03 <__swc_fn_4fa09e82_000129_8d8a7dd2+0x63>
  409c01:	xor    eax,eax
  409c03:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409c09:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409c0f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409c15:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409c1b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409c21:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409c27:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409c2d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409c33:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409c3c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409c45:	add    rsp,0xa8
  409c4c:	pop    rsi
  409c4d:	pop    rdi
  409c4e:	ret
	...

0000000000409c50 <__swc_fn_4fa09e82_000132_91db8856>:
  409c50:	push   rdi
  409c51:	push   rsi
  409c52:	sub    rsp,0xb8
  409c59:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409c5f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409c65:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409c6b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409c71:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409c77:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409c7d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409c83:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409c8c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409c95:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409c9e:	vxorps xmm0,xmm0,xmm0
  409ca2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409ca8:	mov    edi,0x1
  409cad:	lea    rsi,[rsp+0x8]
  409cb2:	xor    eax,eax
  409cb4:	call   407130 <clock_gettime@plt>
  409cb9:	mov    rax,QWORD PTR [rsp+0x8]
  409cbe:	imul   rax,rax,0x3b9aca00
  409cc5:	add    rax,QWORD PTR [rsp+0x10]
  409cca:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409cd0:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409cd6:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409cdc:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409ce2:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409ce8:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409cee:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409cf4:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409cfd:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409d06:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409d0f:	add    rsp,0xb8
  409d16:	pop    rsi
  409d17:	pop    rdi
  409d18:	ret
  409d19:	add    BYTE PTR [rax],al
  409d1b:	add    BYTE PTR [rax],al
  409d1d:	add    BYTE PTR [rax],al
	...

0000000000409d20 <__swc_fn_4fa09e82_000135_10472836>:
  409d20:	sub    rsp,0x8
  409d24:	xor    eax,eax
  409d26:	mov    DWORD PTR [rcx],eax
  409d28:	mov    edx,0x7fffffff
  409d2d:	call   40e660 <__swc_fn_4fa09e82_000133_51cc49e7>
  409d32:	add    rsp,0x8
  409d36:	ret
	...

0000000000409d40 <__swc_fn_4fa09e82_000138_2d595cc7>:
  409d40:	push   rdi
  409d41:	push   rsi
  409d42:	sub    rsp,0xb8
  409d49:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409d4f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409d55:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409d5b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409d61:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409d67:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409d6d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409d73:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409d7c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409d85:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409d8e:	mov    edi,0x1
  409d93:	xor    eax,eax
  409d95:	call   407140 <__x86_get_cpuid_feature_leaf@plt>
  409d9a:	mov    eax,DWORD PTR [rax+0x14]
  409d9d:	and    eax,0x20
  409da0:	setne  al
  409da3:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409da9:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409daf:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409db5:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409dbb:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409dc1:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409dc7:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409dcd:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409dd6:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409ddf:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409de8:	add    rsp,0xb8
  409def:	pop    rsi
  409df0:	pop    rdi
  409df1:	ret
	...

0000000000409e00 <__swc_fn_4fa09e82_000141_55003b6d>:
  409e00:	push   rsi
  409e01:	push   rdi
  409e02:	push   r12
  409e04:	push   r13
  409e06:	push   r14
  409e08:	push   r15
  409e0a:	cmp    rdx,0x40
  409e0e:	jae    409e1d <__swc_fn_4fa09e82_000141_55003b6d+0x1d>
  409e10:	xor    eax,eax
  409e12:	pop    r15
  409e14:	pop    r14
  409e16:	pop    r13
  409e18:	pop    r12
  409e1a:	pop    rdi
  409e1b:	pop    rsi
  409e1c:	ret
  409e1d:	cmp    BYTE PTR [rcx],0x7f
  409e20:	jne    409e64 <__swc_fn_4fa09e82_000141_55003b6d+0x64>
  409e22:	movzx  eax,BYTE PTR [rcx+0x1]
  409e26:	cmp    eax,0x45
  409e29:	setne  al
  409e2c:	jne    409e60 <__swc_fn_4fa09e82_000141_55003b6d+0x60>
  409e2e:	movzx  eax,BYTE PTR [rcx+0x2]
  409e32:	cmp    eax,0x4c
  409e35:	setne  al
  409e38:	jne    409e60 <__swc_fn_4fa09e82_000141_55003b6d+0x60>
  409e3a:	movzx  eax,BYTE PTR [rcx+0x3]
  409e3e:	cmp    eax,0x46
  409e41:	setne  al
  409e44:	jne    409e60 <__swc_fn_4fa09e82_000141_55003b6d+0x60>
  409e46:	cmp    BYTE PTR [rcx+0x4],0x2
  409e4a:	setne  al
  409e4d:	jne    409e60 <__swc_fn_4fa09e82_000141_55003b6d+0x60>
  409e4f:	cmp    BYTE PTR [rcx+0x5],0x1
  409e53:	setne  al
  409e56:	jne    409e60 <__swc_fn_4fa09e82_000141_55003b6d+0x60>
  409e58:	cmp    WORD PTR [rcx+0x12],0x3e
  409e5d:	setne  al
  409e60:	test   al,al
  409e62:	je     409e71 <__swc_fn_4fa09e82_000141_55003b6d+0x71>
  409e64:	xor    eax,eax
  409e66:	pop    r15
  409e68:	pop    r14
  409e6a:	pop    r13
  409e6c:	pop    r12
  409e6e:	pop    rdi
  409e6f:	pop    rsi
  409e70:	ret
  409e71:	cmp    WORD PTR [rcx+0x3a],0x40
  409e76:	jne    409e91 <__swc_fn_4fa09e82_000141_55003b6d+0x91>
  409e78:	cmp    WORD PTR [rcx+0x3c],0x0
  409e7d:	sete   al
  409e80:	je     409e8d <__swc_fn_4fa09e82_000141_55003b6d+0x8d>
  409e82:	mov    ax,WORD PTR [rcx+0x3c]
  409e86:	cmp    WORD PTR [rcx+0x3e],ax
  409e8a:	setae  al
  409e8d:	test   al,al
  409e8f:	je     409e9e <__swc_fn_4fa09e82_000141_55003b6d+0x9e>
  409e91:	xor    eax,eax
  409e93:	pop    r15
  409e95:	pop    r14
  409e97:	pop    r13
  409e99:	pop    r12
  409e9b:	pop    rdi
  409e9c:	pop    rsi
  409e9d:	ret
  409e9e:	movzx  eax,WORD PTR [rcx+0x3c]
  409ea2:	shl    rax,0x6
  409ea6:	cmp    rax,rdx
  409ea9:	ja     409eb7 <__swc_fn_4fa09e82_000141_55003b6d+0xb7>
  409eab:	mov    r9,rdx
  409eae:	sub    r9,rax
  409eb1:	cmp    QWORD PTR [rcx+0x28],r9
  409eb5:	jbe    409ec4 <__swc_fn_4fa09e82_000141_55003b6d+0xc4>
  409eb7:	xor    eax,eax
  409eb9:	pop    r15
  409ebb:	pop    r14
  409ebd:	pop    r13
  409ebf:	pop    r12
  409ec1:	pop    rdi
  409ec2:	pop    rsi
  409ec3:	ret
  409ec4:	mov    rax,QWORD PTR [rcx+0x28]
  409ec8:	add    rax,rcx
  409ecb:	movzx  r9d,WORD PTR [rcx+0x3e]
  409ed0:	lea    r9,[r9*8+0x0]
  409ed8:	lea    r10,[rax+r9*8]
  409edc:	cmp    QWORD PTR [r10+0x20],rdx
  409ee0:	ja     409f02 <__swc_fn_4fa09e82_000141_55003b6d+0x102>
  409ee2:	mov    r11,rdx
  409ee5:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  409eea:	cmp    QWORD PTR [r10+0x18],r11
  409eee:	seta   r9b
  409ef2:	ja     409efd <__swc_fn_4fa09e82_000141_55003b6d+0xfd>
  409ef4:	cmp    QWORD PTR [r10+0x20],0x9
  409ef9:	setb   r9b
  409efd:	test   r9b,r9b
  409f00:	je     409f0f <__swc_fn_4fa09e82_000141_55003b6d+0x10f>
  409f02:	xor    eax,eax
  409f04:	pop    r15
  409f06:	pop    r14
  409f08:	pop    r13
  409f0a:	pop    r12
  409f0c:	pop    rdi
  409f0d:	pop    rsi
  409f0e:	ret
  409f0f:	movzx  r9d,WORD PTR [rcx+0x3c]
  409f14:	xor    r11d,r11d
  409f17:	test   r9,r9
  409f1a:	jbe    40a015 <__swc_fn_4fa09e82_000141_55003b6d+0x215>
  409f20:	mov    rsi,QWORD PTR [r10+0x20]
  409f24:	sub    rsi,0x9
  409f28:	cs nop WORD PTR [rax+rax*1+0x0]
  409f32:	cs nop WORD PTR [rax+rax*1+0x0]
  409f3c:	nop    DWORD PTR [rax+0x0]
  409f40:	movzx  edi,r11w
  409f44:	lea    rdi,[rdi*8+0x0]
  409f4c:	lea    r12,[rax+rdi*8]
  409f50:	rex mov edi,DWORD PTR [rax+rdi*8]
  409f54:	cmp    rdi,rsi
  409f57:	ja     40a008 <__swc_fn_4fa09e82_000141_55003b6d+0x208>
  409f5d:	mov    r13,QWORD PTR [r10+0x18]
  409f61:	add    r13,rdi
  409f64:	lea    rdi,[rcx+r13*1]
  409f68:	lea    r13,[rip+0x95c1]        # 413530 <__swc_rdata_base_4fa09e82+0x420>
  409f6f:	movabs r14,0x676264676177732e
  409f79:	cmp    QWORD PTR [rdi],r14
  409f7c:	jne    409f85 <__swc_fn_4fa09e82_000141_55003b6d+0x185>
  409f7e:	rex cmp BYTE PTR [rdi+0x8],0x0
  409f83:	je     409fb2 <__swc_fn_4fa09e82_000141_55003b6d+0x1b2>
  409f85:	cs nop WORD PTR [rax+rax*1+0x0]
  409f8f:	nop
  409f90:	movzx  r14d,BYTE PTR [rdi]
  409f94:	movzx  r15d,BYTE PTR [r13+0x0]
  409f99:	cmp    r14,r15
  409f9c:	jne    409fa8 <__swc_fn_4fa09e82_000141_55003b6d+0x1a8>
  409f9e:	add    rdi,0x1
  409fa2:	add    r13,0x1
  409fa6:	jmp    409f90 <__swc_fn_4fa09e82_000141_55003b6d+0x190>
  409fa8:	mov    rdi,r14
  409fab:	sub    rdi,r15
  409fae:	test   edi,edi
  409fb0:	jne    40a008 <__swc_fn_4fa09e82_000141_55003b6d+0x208>
  409fb2:	cmp    DWORD PTR [r12+0x4],0x1
  409fb8:	jne    409fe0 <__swc_fn_4fa09e82_000141_55003b6d+0x1e0>
  409fba:	cmp    QWORD PTR [r12+0x20],0x10
  409fc0:	setb   al
  409fc3:	jb     409fdc <__swc_fn_4fa09e82_000141_55003b6d+0x1dc>
  409fc5:	cmp    QWORD PTR [r12+0x20],rdx
  409fca:	seta   al
  409fcd:	ja     409fdc <__swc_fn_4fa09e82_000141_55003b6d+0x1dc>
  409fcf:	sub    rdx,QWORD PTR [r12+0x20]
  409fd4:	cmp    QWORD PTR [r12+0x18],rdx
  409fd9:	seta   al
  409fdc:	test   al,al
  409fde:	je     409fed <__swc_fn_4fa09e82_000141_55003b6d+0x1ed>
  409fe0:	xor    eax,eax
  409fe2:	pop    r15
  409fe4:	pop    r14
  409fe6:	pop    r13
  409fe8:	pop    r12
  409fea:	pop    rdi
  409feb:	pop    rsi
  409fec:	ret
  409fed:	mov    rax,QWORD PTR [r12+0x20]
  409ff2:	mov    QWORD PTR [r8],rax
  409ff5:	mov    rax,QWORD PTR [r12+0x18]
  409ffa:	add    rax,rcx
  409ffd:	pop    r15
  409fff:	pop    r14
  40a001:	pop    r13
  40a003:	pop    r12
  40a005:	pop    rdi
  40a006:	pop    rsi
  40a007:	ret
  40a008:	add    r11,0x1
  40a00c:	cmp    r11,r9
  40a00f:	jb     409f40 <__swc_fn_4fa09e82_000141_55003b6d+0x140>
  40a015:	xor    eax,eax
  40a017:	pop    r15
  40a019:	pop    r14
  40a01b:	pop    r13
  40a01d:	pop    r12
  40a01f:	pop    rdi
  40a020:	pop    rsi
  40a021:	ret
	...

000000000040a030 <__swc_fn_4fa09e82_000144_b7ad855f>:
  40a030:	push   rdi
  40a031:	push   rsi
  40a032:	sub    rsp,0xa8
  40a039:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40a03f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40a045:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40a04b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40a051:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40a057:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40a05d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40a063:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40a069:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a072:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a07b:	mov    rdi,rcx
  40a07e:	xor    eax,eax
  40a080:	call   407150 <free@plt>
  40a085:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a08b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a091:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a097:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a09d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a0a3:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a0a9:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a0af:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a0b5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a0be:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a0c7:	add    rsp,0xa8
  40a0ce:	pop    rsi
  40a0cf:	pop    rdi
  40a0d0:	ret
	...

000000000040a0e0 <__swc_fn_4fa09e82_000147_d2097256>:
  40a0e0:	push   rbx
  40a0e1:	push   rsi
  40a0e2:	push   rdi
  40a0e3:	push   r12
  40a0e5:	push   r13
  40a0e7:	push   r15
  40a0e9:	sub    rsp,0x4e8
  40a0f0:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  40a0f9:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  40a102:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  40a10b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  40a114:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  40a11d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  40a126:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  40a12f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  40a138:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  40a141:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  40a14a:	mov    rbx,QWORD PTR [rcx]
  40a14d:	mov    rcx,QWORD PTR [rcx+0x8]
  40a151:	mov    rsi,rcx
  40a154:	xor    edi,edi
  40a156:	vmovsd xmm6,QWORD PTR [rip+0x9432]        # 413590 <__swc_rdata_base_4fa09e82+0x480>
  40a15e:	vmovsd xmm7,QWORD PTR [rip+0x9433]        # 413599 <__swc_rdata_base_4fa09e82+0x489>
  40a166:	vmovsd xmm8,QWORD PTR [rip+0x9434]        # 4135a2 <__swc_rdata_base_4fa09e82+0x492>
  40a16e:	vmovsd xmm9,QWORD PTR [rip+0x9435]        # 4135ab <__swc_rdata_base_4fa09e82+0x49b>
  40a176:	vmovsd xmm10,QWORD PTR [rip+0x9436]        # 4135b4 <__swc_rdata_base_4fa09e82+0x4a4>
  40a17e:	vmovups xmm11,xmm6
  40a182:	vmovsd QWORD PTR [rsp+0x418],xmm7
  40a18b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  40a194:	vmovsd QWORD PTR [rsp+0x428],xmm9
  40a19d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  40a1a6:	vmovsd xmm15,QWORD PTR [rip+0x940f]        # 4135bd <__swc_rdata_base_4fa09e82+0x4ad>
  40a1ae:	vmovups xmm14,xmm15
  40a1b3:	vmovups xmm0,xmm9
  40a1b8:	vmovsd QWORD PTR [rsp+0x438],xmm15
  40a1c1:	vmovups xmm13,xmm8
  40a1c6:	vmovsd QWORD PTR [rsp+0x440],xmm15
  40a1cf:	test   rsi,rsi
  40a1d2:	je     40b1c3 <__swc_fn_4fa09e82_000147_d2097256+0x10e3>
  40a1d8:	cs nop WORD PTR [rax+rax*1+0x0]
  40a1e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a1ec:	nop    DWORD PTR [rax+0x0]
  40a1f0:	lea    rcx,[rdi+rdi*1]
  40a1f4:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  40a1f9:	vpshufd xmm3,xmm2,0xee
  40a1fe:	vmovq  rcx,xmm3
  40a203:	test   rcx,rcx
  40a206:	je     40a21c <__swc_fn_4fa09e82_000147_d2097256+0x13c>
  40a208:	test   DWORD PTR [rcx+0x28],0x400000
  40a20f:	je     40a21c <__swc_fn_4fa09e82_000147_d2097256+0x13c>
  40a211:	mov    rdx,QWORD PTR [rcx+0x30]
  40a215:	test   rdx,rdx
  40a218:	cmovne rcx,rdx
  40a21c:	test   DWORD PTR [rcx+0x28],0x1000
  40a223:	je     40a244 <__swc_fn_4fa09e82_000147_d2097256+0x164>
  40a225:	mov    rdx,QWORD PTR [rcx+0x40]
  40a229:	mov    rcx,rdx
  40a22c:	vmovq  r8,xmm2
  40a231:	mov    r8,QWORD PTR [r8]
  40a234:	mov    QWORD PTR [rsp+0x60],r8
  40a239:	mov    QWORD PTR [rsp+0x68],rdx
  40a23e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  40a244:	test   BYTE PTR [rcx+0x28],0x1
  40a248:	jne    40a250 <__swc_fn_4fa09e82_000147_d2097256+0x170>
  40a24a:	vmovups xmm12,xmm0
  40a24e:	jmp    40a26a <__swc_fn_4fa09e82_000147_d2097256+0x18a>
  40a250:	vmovq  rax,xmm2
  40a255:	mov    rax,QWORD PTR [rax]
  40a258:	lea    rcx,[rax+0x10]
  40a25c:	vmovups xmm12,xmm0
  40a260:	call   409870 <__swc_fn_4fa09e82_000117_3f5cfdef>
  40a265:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_d2097256+0x10c5>
  40a26a:	test   DWORD PTR [rcx+0x28],0x400
  40a271:	je     40a2d2 <__swc_fn_4fa09e82_000147_d2097256+0x1f2>
  40a273:	vmovq  rax,xmm2
  40a278:	mov    rax,QWORD PTR [rax]
  40a27b:	xor    ecx,ecx
  40a27d:	test   rax,rax
  40a280:	je     40a2b0 <__swc_fn_4fa09e82_000147_d2097256+0x1d0>
  40a282:	mov    rdx,rax
  40a285:	mov    r8b,BYTE PTR [rdx]
  40a288:	test   r8b,r8b
  40a28b:	je     40a2b0 <__swc_fn_4fa09e82_000147_d2097256+0x1d0>
  40a28d:	cs nop WORD PTR [rax+rax*1+0x0]
  40a297:	nop    WORD PTR [rax+rax*1+0x0]
  40a2a0:	add    rdx,0x1
  40a2a4:	add    rcx,0x1
  40a2a8:	mov    r8b,BYTE PTR [rdx]
  40a2ab:	test   r8b,r8b
  40a2ae:	jne    40a2a0 <__swc_fn_4fa09e82_000147_d2097256+0x1c0>
  40a2b0:	mov    QWORD PTR [rsp+0x88],rax
  40a2b8:	mov    QWORD PTR [rsp+0x90],rcx
  40a2c0:	lea    rcx,[rsp+0x88]
  40a2c8:	call   409870 <__swc_fn_4fa09e82_000117_3f5cfdef>
  40a2cd:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_d2097256+0x10c5>
  40a2d2:	cmp    BYTE PTR [rcx+0x2c],0x6
  40a2d6:	jne    40a2ed <__swc_fn_4fa09e82_000147_d2097256+0x20d>
  40a2d8:	vmovq  rax,xmm2
  40a2dd:	mov    rax,QWORD PTR [rax]
  40a2e0:	mov    rcx,rax
  40a2e3:	call   40eb30 <__swc_fn_4fa09e82_000145_c3e86ca0>
  40a2e8:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_d2097256+0x10c5>
  40a2ed:	cmp    BYTE PTR [rcx+0x2c],0x1
  40a2f1:	jne    40b199 <__swc_fn_4fa09e82_000147_d2097256+0x10b9>
  40a2f7:	vmovq  rdx,xmm2
  40a2fc:	mov    cl,BYTE PTR [rcx+0x40]
  40a2ff:	cmp    cl,0x7
  40a302:	jb     40a345 <__swc_fn_4fa09e82_000147_d2097256+0x265>
  40a304:	je     40a3b8 <__swc_fn_4fa09e82_000147_d2097256+0x2d8>
  40a30a:	cmp    cl,0x8
  40a30d:	je     40a3c4 <__swc_fn_4fa09e82_000147_d2097256+0x2e4>
  40a313:	cmp    cl,0x9
  40a316:	je     40a3dd <__swc_fn_4fa09e82_000147_d2097256+0x2fd>
  40a31c:	cmp    cl,0xa
  40a31f:	je     40aaa4 <__swc_fn_4fa09e82_000147_d2097256+0x9c4>
  40a325:	cmp    cl,0xb
  40a328:	je     40b16b <__swc_fn_4fa09e82_000147_d2097256+0x108b>
  40a32e:	cmp    cl,0xc
  40a331:	je     40a3d1 <__swc_fn_4fa09e82_000147_d2097256+0x2f1>
  40a337:	cmp    cl,0xd
  40a33a:	je     40b161 <__swc_fn_4fa09e82_000147_d2097256+0x1081>
  40a340:	jmp    40b18b <__swc_fn_4fa09e82_000147_d2097256+0x10ab>
  40a345:	cmp    cl,0x1
  40a348:	je     40a368 <__swc_fn_4fa09e82_000147_d2097256+0x288>
  40a34a:	cmp    cl,0x2
  40a34d:	je     40a376 <__swc_fn_4fa09e82_000147_d2097256+0x296>
  40a34f:	cmp    cl,0x3
  40a352:	je     40a384 <__swc_fn_4fa09e82_000147_d2097256+0x2a4>
  40a354:	cmp    cl,0x4
  40a357:	je     40a391 <__swc_fn_4fa09e82_000147_d2097256+0x2b1>
  40a359:	cmp    cl,0x5
  40a35c:	je     40a39e <__swc_fn_4fa09e82_000147_d2097256+0x2be>
  40a35e:	cmp    cl,0x6
  40a361:	je     40a3ab <__swc_fn_4fa09e82_000147_d2097256+0x2cb>
  40a363:	jmp    40b18b <__swc_fn_4fa09e82_000147_d2097256+0x10ab>
  40a368:	movsx  rcx,BYTE PTR [rdx]
  40a36c:	call   411980 <__swc_fn_4fa09e82_000146_32a1d6a2>
  40a371:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_d2097256+0x10c5>
  40a376:	movsx  rcx,WORD PTR [rdx]
  40a37a:	call   411980 <__swc_fn_4fa09e82_000146_32a1d6a2>
  40a37f:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_d2097256+0x10c5>
  40a384:	movsxd rcx,DWORD PTR [rdx]
  40a387:	call   411980 <__swc_fn_4fa09e82_000146_32a1d6a2>
  40a38c:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_d2097256+0x10c5>
  40a391:	mov    rcx,QWORD PTR [rdx]
  40a394:	call   411980 <__swc_fn_4fa09e82_000146_32a1d6a2>
  40a399:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_d2097256+0x10c5>
  40a39e:	movzx  ecx,BYTE PTR [rdx]
  40a3a1:	call   40eb30 <__swc_fn_4fa09e82_000145_c3e86ca0>
  40a3a6:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_d2097256+0x10c5>
  40a3ab:	movzx  ecx,WORD PTR [rdx]
  40a3ae:	call   40eb30 <__swc_fn_4fa09e82_000145_c3e86ca0>
  40a3b3:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_d2097256+0x10c5>
  40a3b8:	mov    ecx,DWORD PTR [rdx]
  40a3ba:	call   40eb30 <__swc_fn_4fa09e82_000145_c3e86ca0>
  40a3bf:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_d2097256+0x10c5>
  40a3c4:	mov    rcx,QWORD PTR [rdx]
  40a3c7:	call   40eb30 <__swc_fn_4fa09e82_000145_c3e86ca0>
  40a3cc:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_d2097256+0x10c5>
  40a3d1:	mov    ecx,DWORD PTR [rdx]
  40a3d3:	call   40eb30 <__swc_fn_4fa09e82_000145_c3e86ca0>
  40a3d8:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_d2097256+0x10c5>
  40a3dd:	lea    rcx,[rsp+0xa8]
  40a3e5:	vxorps xmm0,xmm0,xmm0
  40a3e9:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  40a3f2:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  40a3fb:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  40a404:	vzeroupper
  40a407:	mov    DWORD PTR [rsp+0x108],0x0
  40a412:	vxorpd xmm0,xmm0,xmm0
  40a416:	vmovss xmm1,DWORD PTR [rdx]
  40a41a:	vcvtss2sd xmm0,xmm0,xmm1
  40a41e:	vmovsd xmm1,xmm1,xmm0
  40a422:	vcomisd xmm0,xmm0
  40a426:	setne  dl
  40a429:	movzx  edx,dl
  40a42c:	setp   r8b
  40a430:	movzx  r8d,r8b
  40a434:	or     edx,r8d
  40a437:	test   dl,dl
  40a439:	je     40a446 <__swc_fn_4fa09e82_000147_d2097256+0x366>
  40a43b:	mov    DWORD PTR [rcx],0x6e616e
  40a441:	jmp    40aa38 <__swc_fn_4fa09e82_000147_d2097256+0x958>
  40a446:	vcomisd xmm1,xmm6
  40a44a:	ja     40a452 <__swc_fn_4fa09e82_000147_d2097256+0x372>
  40a44c:	vcomisd xmm7,xmm1
  40a450:	jbe    40a476 <__swc_fn_4fa09e82_000147_d2097256+0x396>
  40a452:	vxorpd xmm0,xmm0,xmm0
  40a456:	vcomisd xmm0,xmm1
  40a45a:	jbe    40a46b <__swc_fn_4fa09e82_000147_d2097256+0x38b>
  40a45c:	mov    DWORD PTR [rcx],0x666e692d
  40a462:	mov    BYTE PTR [rcx+0x4],0x0
  40a466:	jmp    40aa38 <__swc_fn_4fa09e82_000147_d2097256+0x958>
  40a46b:	mov    DWORD PTR [rcx],0x666e69
  40a471:	jmp    40aa38 <__swc_fn_4fa09e82_000147_d2097256+0x958>
  40a476:	vcomisd xmm1,xmm8
  40a47b:	jae    40a487 <__swc_fn_4fa09e82_000147_d2097256+0x3a7>
  40a47d:	vcomisd xmm9,xmm1
  40a481:	jbe    40a7fe <__swc_fn_4fa09e82_000147_d2097256+0x71e>
  40a487:	vmovups xmm0,xmm1
  40a48b:	vxorpd xmm2,xmm2,xmm2
  40a48f:	vcomisd xmm2,xmm1
  40a493:	jbe    40a4a3 <__swc_fn_4fa09e82_000147_d2097256+0x3c3>
  40a495:	vmovsd xmm1,xmm1,xmm0
  40a499:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x90af]        # 413550 <__swc_rdata_base_4fa09e82+0x440>
  40a4a1:	jmp    40a4a7 <__swc_fn_4fa09e82_000147_d2097256+0x3c7>
  40a4a3:	vmovsd xmm1,xmm1,xmm0
  40a4a7:	xor    r8d,r8d
  40a4aa:	vcomisd xmm1,xmm15
  40a4af:	jb     40a4d0 <__swc_fn_4fa09e82_000147_d2097256+0x3f0>
  40a4b1:	cs nop WORD PTR [rax+rax*1+0x0]
  40a4bb:	nop    DWORD PTR [rax+rax*1+0x0]
  40a4c0:	vdivsd xmm1,xmm1,xmm15
  40a4c5:	add    r8,0x1
  40a4c9:	vcomisd xmm1,xmm15
  40a4ce:	jae    40a4c0 <__swc_fn_4fa09e82_000147_d2097256+0x3e0>
  40a4d0:	mov    r9,rcx
  40a4d3:	vxorpd xmm2,xmm2,xmm2
  40a4d7:	vcomisd xmm2,xmm0
  40a4db:	jbe    40a4e4 <__swc_fn_4fa09e82_000147_d2097256+0x404>
  40a4dd:	mov    BYTE PTR [rcx],0x2d
  40a4e0:	lea    r9,[rcx+0x1]
  40a4e4:	vcvttsd2si rdx,xmm1
  40a4e9:	mov    r10b,dl
  40a4ec:	add    r10b,0x30
  40a4f0:	mov    BYTE PTR [r9],r10b
  40a4f3:	vxorpd xmm0,xmm0,xmm0
  40a4f7:	movzx  edx,dl
  40a4fa:	vcvtsi2sd xmm0,xmm0,rdx
  40a4ff:	vsubsd xmm0,xmm1,xmm0
  40a503:	vmulsd xmm1,xmm0,xmm15
  40a508:	mov    BYTE PTR [r9+0x1],0x2e
  40a50d:	vcvttsd2si rdx,xmm1
  40a512:	mov    r10b,dl
  40a515:	add    r10b,0x30
  40a519:	mov    BYTE PTR [r9+0x2],r10b
  40a51d:	vxorpd xmm0,xmm0,xmm0
  40a521:	movzx  edx,dl
  40a524:	vcvtsi2sd xmm0,xmm0,rdx
  40a529:	vsubsd xmm0,xmm1,xmm0
  40a52d:	vmulsd xmm1,xmm0,xmm15
  40a532:	vcvttsd2si rdx,xmm1
  40a537:	mov    r10b,dl
  40a53a:	add    r10b,0x30
  40a53e:	mov    BYTE PTR [r9+0x3],r10b
  40a542:	vxorpd xmm0,xmm0,xmm0
  40a546:	movzx  edx,dl
  40a549:	vcvtsi2sd xmm0,xmm0,rdx
  40a54e:	vsubsd xmm0,xmm1,xmm0
  40a552:	vmulsd xmm1,xmm0,xmm15
  40a557:	vcvttsd2si rdx,xmm1
  40a55c:	mov    r10b,dl
  40a55f:	add    r10b,0x30
  40a563:	mov    BYTE PTR [r9+0x4],r10b
  40a567:	vxorpd xmm0,xmm0,xmm0
  40a56b:	movzx  edx,dl
  40a56e:	vcvtsi2sd xmm0,xmm0,rdx
  40a573:	vsubsd xmm0,xmm1,xmm0
  40a577:	vmulsd xmm1,xmm0,xmm15
  40a57c:	vcvttsd2si rdx,xmm1
  40a581:	mov    r10b,dl
  40a584:	add    r10b,0x30
  40a588:	mov    BYTE PTR [r9+0x5],r10b
  40a58c:	vxorpd xmm0,xmm0,xmm0
  40a590:	movzx  edx,dl
  40a593:	vcvtsi2sd xmm0,xmm0,rdx
  40a598:	vsubsd xmm0,xmm1,xmm0
  40a59c:	vmulsd xmm1,xmm0,xmm15
  40a5a1:	vcvttsd2si rdx,xmm1
  40a5a6:	mov    r10b,dl
  40a5a9:	add    r10b,0x30
  40a5ad:	mov    BYTE PTR [r9+0x6],r10b
  40a5b1:	vxorpd xmm0,xmm0,xmm0
  40a5b5:	movzx  edx,dl
  40a5b8:	vcvtsi2sd xmm0,xmm0,rdx
  40a5bd:	vsubsd xmm0,xmm1,xmm0
  40a5c1:	vmulsd xmm1,xmm0,xmm15
  40a5c6:	vcvttsd2si rdx,xmm1
  40a5cb:	mov    r10b,dl
  40a5ce:	add    r10b,0x30
  40a5d2:	mov    BYTE PTR [r9+0x7],r10b
  40a5d6:	vxorpd xmm0,xmm0,xmm0
  40a5da:	movzx  edx,dl
  40a5dd:	vcvtsi2sd xmm0,xmm0,rdx
  40a5e2:	vsubsd xmm0,xmm1,xmm0
  40a5e6:	vmulsd xmm1,xmm0,xmm15
  40a5eb:	vcvttsd2si rdx,xmm1
  40a5f0:	mov    r10b,dl
  40a5f3:	add    r10b,0x30
  40a5f7:	mov    BYTE PTR [r9+0x8],r10b
  40a5fb:	vxorpd xmm0,xmm0,xmm0
  40a5ff:	movzx  edx,dl
  40a602:	vcvtsi2sd xmm0,xmm0,rdx
  40a607:	vsubsd xmm0,xmm1,xmm0
  40a60b:	vmulsd xmm1,xmm0,xmm15
  40a610:	vcvttsd2si rdx,xmm1
  40a615:	mov    r10b,dl
  40a618:	add    r10b,0x30
  40a61c:	mov    BYTE PTR [r9+0x9],r10b
  40a620:	vxorpd xmm0,xmm0,xmm0
  40a624:	movzx  edx,dl
  40a627:	vcvtsi2sd xmm0,xmm0,rdx
  40a62c:	vsubsd xmm0,xmm1,xmm0
  40a630:	vmulsd xmm1,xmm0,xmm15
  40a635:	vcvttsd2si rdx,xmm1
  40a63a:	mov    r10b,dl
  40a63d:	add    r10b,0x30
  40a641:	mov    BYTE PTR [r9+0xa],r10b
  40a645:	vxorpd xmm0,xmm0,xmm0
  40a649:	movzx  edx,dl
  40a64c:	vcvtsi2sd xmm0,xmm0,rdx
  40a651:	vsubsd xmm0,xmm1,xmm0
  40a655:	vmulsd xmm1,xmm0,xmm15
  40a65a:	vcvttsd2si rdx,xmm1
  40a65f:	mov    r10b,dl
  40a662:	add    r10b,0x30
  40a666:	mov    BYTE PTR [r9+0xb],r10b
  40a66a:	lea    r10,[r9+0x4]
  40a66e:	vxorpd xmm0,xmm0,xmm0
  40a672:	movzx  edx,dl
  40a675:	vcvtsi2sd xmm0,xmm0,rdx
  40a67a:	vsubsd xmm0,xmm1,xmm0
  40a67e:	vmulsd xmm1,xmm0,xmm15
  40a683:	vcvttsd2si rdx,xmm1
  40a688:	mov    r11b,dl
  40a68b:	add    r11b,0x30
  40a68f:	mov    BYTE PTR [r9+0xc],r11b
  40a693:	vxorpd xmm0,xmm0,xmm0
  40a697:	movzx  edx,dl
  40a69a:	vcvtsi2sd xmm0,xmm0,rdx
  40a69f:	vsubsd xmm0,xmm1,xmm0
  40a6a3:	vmulsd xmm1,xmm0,xmm15
  40a6a8:	vcvttsd2si rdx,xmm1
  40a6ad:	mov    r11b,dl
  40a6b0:	add    r11b,0x30
  40a6b4:	mov    BYTE PTR [r9+0xd],r11b
  40a6b8:	lea    r10,[r10+0x2]
  40a6bc:	vxorpd xmm0,xmm0,xmm0
  40a6c0:	movzx  edx,dl
  40a6c3:	vcvtsi2sd xmm0,xmm0,rdx
  40a6c8:	vsubsd xmm0,xmm1,xmm0
  40a6cc:	vmulsd xmm1,xmm0,xmm15
  40a6d1:	vcvttsd2si rdx,xmm1
  40a6d6:	mov    r11b,dl
  40a6d9:	add    r11b,0x30
  40a6dd:	mov    BYTE PTR [r9+0xe],r11b
  40a6e1:	vxorpd xmm0,xmm0,xmm0
  40a6e5:	movzx  edx,dl
  40a6e8:	vcvtsi2sd xmm0,xmm0,rdx
  40a6ed:	vsubsd xmm0,xmm1,xmm0
  40a6f1:	vmulsd xmm1,xmm0,xmm15
  40a6f6:	vcvttsd2si rdx,xmm1
  40a6fb:	mov    r11b,dl
  40a6fe:	add    r11b,0x30
  40a702:	mov    BYTE PTR [r9+0xf],r11b
  40a706:	lea    r10,[r10+0x2]
  40a70a:	lea    r10,[r10+0x2]
  40a70e:	lea    r10,[r10+0x2]
  40a712:	lea    r10,[r10+0x2]
  40a716:	lea    r10,[r10+0x2]
  40a71a:	vxorpd xmm0,xmm0,xmm0
  40a71e:	movzx  edx,dl
  40a721:	vcvtsi2sd xmm0,xmm0,rdx
  40a726:	vsubsd xmm0,xmm1,xmm0
  40a72a:	vmulsd xmm1,xmm0,xmm15
  40a72f:	vcvttsd2si rdx,xmm1
  40a734:	mov    r11b,dl
  40a737:	add    r11b,0x30
  40a73b:	mov    BYTE PTR [r9+0x10],r11b
  40a73f:	vxorpd xmm0,xmm0,xmm0
  40a743:	movzx  edx,dl
  40a746:	vcvtsi2sd xmm0,xmm0,rdx
  40a74b:	vsubsd xmm0,xmm1,xmm0
  40a74f:	vmulsd xmm1,xmm0,xmm15
  40a754:	vcvttsd2si rdx,xmm1
  40a759:	add    dl,0x30
  40a75c:	mov    BYTE PTR [r9+0x11],dl
  40a760:	mov    BYTE PTR [r10+0x2],0x65
  40a765:	lea    r9,[r10+0x3]
  40a769:	test   r8,r8
  40a76c:	jl     40a775 <__swc_fn_4fa09e82_000147_d2097256+0x695>
  40a76e:	mov    BYTE PTR [r9],0x2b
  40a772:	inc    r9
  40a775:	mov    r10,r9
  40a778:	mov    rdx,r8
  40a77b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a780:	mov    r11,rdx
  40a783:	movabs rdx,0x6666666666666667
  40a78d:	mov    rax,r11
  40a790:	imul   rdx
  40a793:	sar    rdx,0x2
  40a797:	mov    r12,rdx
  40a79a:	shr    rdx,0x3f
  40a79e:	add    r12,rdx
  40a7a1:	mov    rdx,r12
  40a7a4:	imul   r13,r12,0xa
  40a7a8:	sub    r11,r13
  40a7ab:	mov    r13,QWORD PTR [rip+0x8d8e]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40a7b2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40a7b7:	mov    BYTE PTR [r10],r11b
  40a7ba:	lea    r11,[r10+0x1]
  40a7be:	mov    r10,r11
  40a7c1:	test   r12,r12
  40a7c4:	jne    40a780 <__swc_fn_4fa09e82_000147_d2097256+0x6a0>
  40a7c6:	test   r8,r8
  40a7c9:	jge    40a7d3 <__swc_fn_4fa09e82_000147_d2097256+0x6f3>
  40a7cb:	mov    BYTE PTR [r11],0x2d
  40a7cf:	lea    r10,[r11+0x1]
  40a7d3:	mov    BYTE PTR [r10],0x0
  40a7d7:	sub    r10,0x1
  40a7db:	nop    DWORD PTR [rax+rax*1+0x0]
  40a7e0:	cmp    r9,r10
  40a7e3:	jae    40aa38 <__swc_fn_4fa09e82_000147_d2097256+0x958>
  40a7e9:	mov    al,BYTE PTR [r10]
  40a7ec:	mov    dl,BYTE PTR [r9]
  40a7ef:	mov    BYTE PTR [r10],dl
  40a7f2:	sub    r10,0x1
  40a7f6:	mov    BYTE PTR [r9],al
  40a7f9:	inc    r9
  40a7fc:	jmp    40a7e0 <__swc_fn_4fa09e82_000147_d2097256+0x700>
  40a7fe:	vcvttsd2si rdx,xmm1
  40a803:	mov    r8,rdx
  40a806:	vxorpd xmm0,xmm0,xmm0
  40a80a:	vcvtsi2sd xmm0,xmm0,rdx
  40a80f:	vsubsd xmm0,xmm1,xmm0
  40a813:	mov    r9d,0x8
  40a819:	vxorpd xmm2,xmm2,xmm2
  40a81d:	vcomisd xmm2,xmm0
  40a821:	jbe    40a82b <__swc_fn_4fa09e82_000147_d2097256+0x74b>
  40a823:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x8d25]        # 413550 <__swc_rdata_base_4fa09e82+0x440>
  40a82b:	test   r9d,r9d
  40a82e:	je     40a83a <__swc_fn_4fa09e82_000147_d2097256+0x75a>
  40a830:	vmulsd xmm0,xmm0,xmm14
  40a835:	dec    r9d
  40a838:	jne    40a830 <__swc_fn_4fa09e82_000147_d2097256+0x750>
  40a83a:	vcvttsd2si r9,xmm0
  40a83f:	mov    r10,r9
  40a842:	vxorpd xmm2,xmm2,xmm2
  40a846:	vcvtsi2sd xmm2,xmm2,r9
  40a84b:	vsubsd xmm0,xmm0,xmm2
  40a84f:	vcomisd xmm0,xmm10
  40a854:	lea    r9,[r9+0x1]
  40a858:	cmova  r10,r9
  40a85c:	cmp    r10,0x5f5e100
  40a863:	jne    40a87c <__swc_fn_4fa09e82_000147_d2097256+0x79c>
  40a865:	lea    r8,[rdx-0x1]
  40a869:	vxorpd xmm0,xmm0,xmm0
  40a86d:	vcomisd xmm0,xmm1
  40a871:	lea    rdx,[rdx+0x1]
  40a875:	cmovbe r8,rdx
  40a879:	xor    r10d,r10d
  40a87c:	mov    r9,rcx
  40a87f:	test   r8,r8
  40a882:	jne    40a8a2 <__swc_fn_4fa09e82_000147_d2097256+0x7c2>
  40a884:	vxorpd xmm0,xmm0,xmm0
  40a888:	vcomisd xmm0,xmm1
  40a88c:	jbe    40a895 <__swc_fn_4fa09e82_000147_d2097256+0x7b5>
  40a88e:	mov    BYTE PTR [rcx],0x2d
  40a891:	lea    r9,[rcx+0x1]
  40a895:	mov    BYTE PTR [r9],0x30
  40a899:	add    r9,0x1
  40a89d:	jmp    40a93b <__swc_fn_4fa09e82_000147_d2097256+0x85b>
  40a8a2:	mov    r9,rcx
  40a8a5:	mov    rdx,r8
  40a8a8:	nop    DWORD PTR [rax+rax*1+0x0]
  40a8b0:	mov    r11,rdx
  40a8b3:	movabs rdx,0x6666666666666667
  40a8bd:	mov    r15,rax
  40a8c0:	mov    rax,r11
  40a8c3:	imul   rdx
  40a8c6:	mov    r12,rdx
  40a8c9:	mov    rax,r15
  40a8cc:	sar    r12,0x2
  40a8d0:	mov    rdx,r12
  40a8d3:	shr    rdx,0x3f
  40a8d7:	add    r12,rdx
  40a8da:	mov    rdx,r12
  40a8dd:	imul   r13,r12,0xa
  40a8e1:	sub    r11,r13
  40a8e4:	mov    r13,QWORD PTR [rip+0x8c55]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40a8eb:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40a8f0:	mov    BYTE PTR [r9],r11b
  40a8f3:	lea    r11,[r9+0x1]
  40a8f7:	mov    r9,r11
  40a8fa:	test   r12,r12
  40a8fd:	jne    40a8b0 <__swc_fn_4fa09e82_000147_d2097256+0x7d0>
  40a8ff:	test   r8,r8
  40a902:	jge    40a90c <__swc_fn_4fa09e82_000147_d2097256+0x82c>
  40a904:	mov    BYTE PTR [r11],0x2d
  40a908:	lea    r9,[r11+0x1]
  40a90c:	mov    rdx,r9
  40a90f:	mov    BYTE PTR [r9],0x0
  40a913:	sub    r9,0x1
  40a917:	mov    r8,rcx
  40a91a:	cmp    r8,r9
  40a91d:	jae    40a938 <__swc_fn_4fa09e82_000147_d2097256+0x858>
  40a91f:	nop
  40a920:	mov    r11b,BYTE PTR [r9]
  40a923:	mov    r12b,BYTE PTR [r8]
  40a926:	mov    BYTE PTR [r9],r12b
  40a929:	sub    r9,0x1
  40a92d:	mov    BYTE PTR [r8],r11b
  40a930:	inc    r8
  40a933:	cmp    r8,r9
  40a936:	jb     40a920 <__swc_fn_4fa09e82_000147_d2097256+0x840>
  40a938:	mov    r9,rdx
  40a93b:	mov    BYTE PTR [r9],0x2e
  40a93f:	add    r9,0x1
  40a943:	xor    r8d,r8d
  40a946:	test   r10,r10
  40a949:	je     40a98f <__swc_fn_4fa09e82_000147_d2097256+0x8af>
  40a94b:	mov    r11d,0x989680
  40a951:	cmp    r10,r11
  40a954:	jge    40a98f <__swc_fn_4fa09e82_000147_d2097256+0x8af>
  40a956:	cs nop WORD PTR [rax+rax*1+0x0]
  40a960:	inc    r8d
  40a963:	movabs rdx,0x6666666666666667
  40a96d:	mov    r15,rax
  40a970:	mov    rax,r11
  40a973:	imul   rdx
  40a976:	mov    r11,rdx
  40a979:	mov    rax,r15
  40a97c:	sar    r11,0x2
  40a980:	mov    rdx,r11
  40a983:	shr    rdx,0x3f
  40a987:	add    r11,rdx
  40a98a:	cmp    r10,r11
  40a98d:	jl     40a960 <__swc_fn_4fa09e82_000147_d2097256+0x880>
  40a98f:	test   r8d,r8d
  40a992:	je     40a9ad <__swc_fn_4fa09e82_000147_d2097256+0x8cd>
  40a994:	cs nop WORD PTR [rax+rax*1+0x0]
  40a99e:	xchg   ax,ax
  40a9a0:	mov    BYTE PTR [r9],0x30
  40a9a4:	add    r9,0x1
  40a9a8:	dec    r8d
  40a9ab:	jne    40a9a0 <__swc_fn_4fa09e82_000147_d2097256+0x8c0>
  40a9ad:	mov    r8,r9
  40a9b0:	mov    rdx,r10
  40a9b3:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9bd:	nop    DWORD PTR [rax]
  40a9c0:	mov    r11,rdx
  40a9c3:	movabs rdx,0x6666666666666667
  40a9cd:	mov    rax,r11
  40a9d0:	imul   rdx
  40a9d3:	sar    rdx,0x2
  40a9d7:	mov    r12,rdx
  40a9da:	shr    rdx,0x3f
  40a9de:	add    r12,rdx
  40a9e1:	mov    rdx,r12
  40a9e4:	imul   r13,r12,0xa
  40a9e8:	sub    r11,r13
  40a9eb:	mov    r13,QWORD PTR [rip+0x8b4e]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40a9f2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40a9f7:	mov    BYTE PTR [r8],r11b
  40a9fa:	lea    r11,[r8+0x1]
  40a9fe:	mov    r8,r11
  40aa01:	test   r12,r12
  40aa04:	jne    40a9c0 <__swc_fn_4fa09e82_000147_d2097256+0x8e0>
  40aa06:	test   r10,r10
  40aa09:	jge    40aa13 <__swc_fn_4fa09e82_000147_d2097256+0x933>
  40aa0b:	mov    BYTE PTR [r11],0x2d
  40aa0f:	lea    r8,[r11+0x1]
  40aa13:	mov    BYTE PTR [r8],0x0
  40aa17:	sub    r8,0x1
  40aa1b:	cmp    r9,r8
  40aa1e:	jae    40aa38 <__swc_fn_4fa09e82_000147_d2097256+0x958>
  40aa20:	mov    al,BYTE PTR [r8]
  40aa23:	mov    dl,BYTE PTR [r9]
  40aa26:	mov    BYTE PTR [r8],dl
  40aa29:	sub    r8,0x1
  40aa2d:	mov    BYTE PTR [r9],al
  40aa30:	inc    r9
  40aa33:	cmp    r9,r8
  40aa36:	jb     40aa20 <__swc_fn_4fa09e82_000147_d2097256+0x940>
  40aa38:	xor    eax,eax
  40aa3a:	test   rcx,rcx
  40aa3d:	je     40aa70 <__swc_fn_4fa09e82_000147_d2097256+0x990>
  40aa3f:	mov    rdx,rcx
  40aa42:	mov    r8b,BYTE PTR [rdx]
  40aa45:	test   r8b,r8b
  40aa48:	je     40aa70 <__swc_fn_4fa09e82_000147_d2097256+0x990>
  40aa4a:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa54:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa5e:	xchg   ax,ax
  40aa60:	add    rdx,0x1
  40aa64:	add    rax,0x1
  40aa68:	mov    r8b,BYTE PTR [rdx]
  40aa6b:	test   r8b,r8b
  40aa6e:	jne    40aa60 <__swc_fn_4fa09e82_000147_d2097256+0x980>
  40aa70:	mov    QWORD PTR [rsp+0x240],rcx
  40aa78:	mov    QWORD PTR [rsp+0x248],rax
  40aa80:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  40aa89:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  40aa92:	lea    rcx,[rsp+0x250]
  40aa9a:	call   409870 <__swc_fn_4fa09e82_000117_3f5cfdef>
  40aa9f:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_d2097256+0x10c5>
  40aaa4:	lea    rcx,[rsp+0x260]
  40aaac:	vxorps xmm0,xmm0,xmm0
  40aab0:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  40aab9:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  40aac2:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  40aacb:	vzeroupper
  40aace:	mov    DWORD PTR [rsp+0x2c0],0x0
  40aad9:	vmovsd xmm0,QWORD PTR [rdx]
  40aadd:	vcomisd xmm0,xmm0
  40aae1:	setne  dl
  40aae4:	movzx  edx,dl
  40aae7:	setp   r8b
  40aaeb:	movzx  r8d,r8b
  40aaef:	or     edx,r8d
  40aaf2:	test   dl,dl
  40aaf4:	je     40ab01 <__swc_fn_4fa09e82_000147_d2097256+0xa21>
  40aaf6:	mov    DWORD PTR [rcx],0x6e616e
  40aafc:	jmp    40b108 <__swc_fn_4fa09e82_000147_d2097256+0x1028>
  40ab01:	vcomisd xmm0,xmm11
  40ab06:	ja     40ab17 <__swc_fn_4fa09e82_000147_d2097256+0xa37>
  40ab08:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  40ab11:	vcomisd xmm6,xmm0
  40ab15:	jbe    40ab3b <__swc_fn_4fa09e82_000147_d2097256+0xa5b>
  40ab17:	vxorpd xmm1,xmm1,xmm1
  40ab1b:	vcomisd xmm1,xmm0
  40ab1f:	jbe    40ab30 <__swc_fn_4fa09e82_000147_d2097256+0xa50>
  40ab21:	mov    DWORD PTR [rcx],0x666e692d
  40ab27:	mov    BYTE PTR [rcx+0x4],0x0
  40ab2b:	jmp    40b108 <__swc_fn_4fa09e82_000147_d2097256+0x1028>
  40ab30:	mov    DWORD PTR [rcx],0x666e69
  40ab36:	jmp    40b108 <__swc_fn_4fa09e82_000147_d2097256+0x1028>
  40ab3b:	vcomisd xmm0,xmm13
  40ab40:	jae    40ab4c <__swc_fn_4fa09e82_000147_d2097256+0xa6c>
  40ab42:	vcomisd xmm12,xmm0
  40ab46:	jbe    40aeae <__swc_fn_4fa09e82_000147_d2097256+0xdce>
  40ab4c:	vmovups xmm1,xmm0
  40ab50:	vxorpd xmm2,xmm2,xmm2
  40ab54:	vcomisd xmm2,xmm0
  40ab58:	jbe    40ab68 <__swc_fn_4fa09e82_000147_d2097256+0xa88>
  40ab5a:	vmovsd xmm0,xmm0,xmm1
  40ab5e:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x89ea]        # 413550 <__swc_rdata_base_4fa09e82+0x440>
  40ab66:	jmp    40ab6c <__swc_fn_4fa09e82_000147_d2097256+0xa8c>
  40ab68:	vmovsd xmm0,xmm0,xmm1
  40ab6c:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  40ab75:	xor    r8d,r8d
  40ab78:	vcomisd xmm0,xmm6
  40ab7c:	jb     40ab8e <__swc_fn_4fa09e82_000147_d2097256+0xaae>
  40ab7e:	xchg   ax,ax
  40ab80:	vdivsd xmm0,xmm0,xmm6
  40ab84:	add    r8,0x1
  40ab88:	vcomisd xmm0,xmm6
  40ab8c:	jae    40ab80 <__swc_fn_4fa09e82_000147_d2097256+0xaa0>
  40ab8e:	mov    r9,rcx
  40ab91:	vxorpd xmm2,xmm2,xmm2
  40ab95:	vcomisd xmm2,xmm1
  40ab99:	jbe    40aba2 <__swc_fn_4fa09e82_000147_d2097256+0xac2>
  40ab9b:	mov    BYTE PTR [rcx],0x2d
  40ab9e:	lea    r9,[rcx+0x1]
  40aba2:	vcvttsd2si rdx,xmm0
  40aba7:	mov    r10b,dl
  40abaa:	add    r10b,0x30
  40abae:	mov    BYTE PTR [r9],r10b
  40abb1:	vxorpd xmm1,xmm1,xmm1
  40abb5:	movzx  edx,dl
  40abb8:	vcvtsi2sd xmm1,xmm1,rdx
  40abbd:	vsubsd xmm0,xmm0,xmm1
  40abc1:	vmulsd xmm0,xmm0,xmm6
  40abc5:	mov    BYTE PTR [r9+0x1],0x2e
  40abca:	vcvttsd2si rdx,xmm0
  40abcf:	mov    r10b,dl
  40abd2:	add    r10b,0x30
  40abd6:	mov    BYTE PTR [r9+0x2],r10b
  40abda:	vxorpd xmm1,xmm1,xmm1
  40abde:	movzx  edx,dl
  40abe1:	vcvtsi2sd xmm1,xmm1,rdx
  40abe6:	vsubsd xmm0,xmm0,xmm1
  40abea:	vmulsd xmm0,xmm0,xmm6
  40abee:	vcvttsd2si rdx,xmm0
  40abf3:	mov    r10b,dl
  40abf6:	add    r10b,0x30
  40abfa:	mov    BYTE PTR [r9+0x3],r10b
  40abfe:	vxorpd xmm1,xmm1,xmm1
  40ac02:	movzx  edx,dl
  40ac05:	vcvtsi2sd xmm1,xmm1,rdx
  40ac0a:	vsubsd xmm0,xmm0,xmm1
  40ac0e:	vmulsd xmm0,xmm0,xmm6
  40ac12:	vcvttsd2si rdx,xmm0
  40ac17:	mov    r10b,dl
  40ac1a:	add    r10b,0x30
  40ac1e:	mov    BYTE PTR [r9+0x4],r10b
  40ac22:	vxorpd xmm1,xmm1,xmm1
  40ac26:	movzx  edx,dl
  40ac29:	vcvtsi2sd xmm1,xmm1,rdx
  40ac2e:	vsubsd xmm0,xmm0,xmm1
  40ac32:	vmulsd xmm0,xmm0,xmm6
  40ac36:	vcvttsd2si rdx,xmm0
  40ac3b:	mov    r10b,dl
  40ac3e:	add    r10b,0x30
  40ac42:	mov    BYTE PTR [r9+0x5],r10b
  40ac46:	vxorpd xmm1,xmm1,xmm1
  40ac4a:	movzx  edx,dl
  40ac4d:	vcvtsi2sd xmm1,xmm1,rdx
  40ac52:	vsubsd xmm0,xmm0,xmm1
  40ac56:	vmulsd xmm0,xmm0,xmm6
  40ac5a:	vcvttsd2si rdx,xmm0
  40ac5f:	mov    r10b,dl
  40ac62:	add    r10b,0x30
  40ac66:	mov    BYTE PTR [r9+0x6],r10b
  40ac6a:	vxorpd xmm1,xmm1,xmm1
  40ac6e:	movzx  edx,dl
  40ac71:	vcvtsi2sd xmm1,xmm1,rdx
  40ac76:	vsubsd xmm0,xmm0,xmm1
  40ac7a:	vmulsd xmm0,xmm0,xmm6
  40ac7e:	vcvttsd2si rdx,xmm0
  40ac83:	mov    r10b,dl
  40ac86:	add    r10b,0x30
  40ac8a:	mov    BYTE PTR [r9+0x7],r10b
  40ac8e:	vxorpd xmm1,xmm1,xmm1
  40ac92:	movzx  edx,dl
  40ac95:	vcvtsi2sd xmm1,xmm1,rdx
  40ac9a:	vsubsd xmm0,xmm0,xmm1
  40ac9e:	vmulsd xmm0,xmm0,xmm6
  40aca2:	vcvttsd2si rdx,xmm0
  40aca7:	mov    r10b,dl
  40acaa:	add    r10b,0x30
  40acae:	mov    BYTE PTR [r9+0x8],r10b
  40acb2:	vxorpd xmm1,xmm1,xmm1
  40acb6:	movzx  edx,dl
  40acb9:	vcvtsi2sd xmm1,xmm1,rdx
  40acbe:	vsubsd xmm0,xmm0,xmm1
  40acc2:	vmulsd xmm0,xmm0,xmm6
  40acc6:	vcvttsd2si rdx,xmm0
  40accb:	mov    r10b,dl
  40acce:	add    r10b,0x30
  40acd2:	mov    BYTE PTR [r9+0x9],r10b
  40acd6:	vxorpd xmm1,xmm1,xmm1
  40acda:	movzx  edx,dl
  40acdd:	vcvtsi2sd xmm1,xmm1,rdx
  40ace2:	vsubsd xmm0,xmm0,xmm1
  40ace6:	vmulsd xmm0,xmm0,xmm6
  40acea:	vcvttsd2si rdx,xmm0
  40acef:	mov    r10b,dl
  40acf2:	add    r10b,0x30
  40acf6:	mov    BYTE PTR [r9+0xa],r10b
  40acfa:	vxorpd xmm1,xmm1,xmm1
  40acfe:	movzx  edx,dl
  40ad01:	vcvtsi2sd xmm1,xmm1,rdx
  40ad06:	vsubsd xmm0,xmm0,xmm1
  40ad0a:	vmulsd xmm0,xmm0,xmm6
  40ad0e:	vcvttsd2si rdx,xmm0
  40ad13:	mov    r10b,dl
  40ad16:	add    r10b,0x30
  40ad1a:	mov    BYTE PTR [r9+0xb],r10b
  40ad1e:	lea    r10,[r9+0x4]
  40ad22:	vxorpd xmm1,xmm1,xmm1
  40ad26:	movzx  edx,dl
  40ad29:	vcvtsi2sd xmm1,xmm1,rdx
  40ad2e:	vsubsd xmm0,xmm0,xmm1
  40ad32:	vmulsd xmm0,xmm0,xmm6
  40ad36:	vcvttsd2si rdx,xmm0
  40ad3b:	mov    r11b,dl
  40ad3e:	add    r11b,0x30
  40ad42:	mov    BYTE PTR [r9+0xc],r11b
  40ad46:	vxorpd xmm1,xmm1,xmm1
  40ad4a:	movzx  edx,dl
  40ad4d:	vcvtsi2sd xmm1,xmm1,rdx
  40ad52:	vsubsd xmm0,xmm0,xmm1
  40ad56:	vmulsd xmm0,xmm0,xmm6
  40ad5a:	vcvttsd2si rdx,xmm0
  40ad5f:	mov    r11b,dl
  40ad62:	add    r11b,0x30
  40ad66:	mov    BYTE PTR [r9+0xd],r11b
  40ad6a:	lea    r10,[r10+0x2]
  40ad6e:	vxorpd xmm1,xmm1,xmm1
  40ad72:	movzx  edx,dl
  40ad75:	vcvtsi2sd xmm1,xmm1,rdx
  40ad7a:	vsubsd xmm0,xmm0,xmm1
  40ad7e:	vmulsd xmm0,xmm0,xmm6
  40ad82:	vcvttsd2si rdx,xmm0
  40ad87:	mov    r11b,dl
  40ad8a:	add    r11b,0x30
  40ad8e:	mov    BYTE PTR [r9+0xe],r11b
  40ad92:	vxorpd xmm1,xmm1,xmm1
  40ad96:	movzx  edx,dl
  40ad99:	vcvtsi2sd xmm1,xmm1,rdx
  40ad9e:	vsubsd xmm0,xmm0,xmm1
  40ada2:	vmulsd xmm0,xmm0,xmm6
  40ada6:	vcvttsd2si rdx,xmm0
  40adab:	mov    r11b,dl
  40adae:	add    r11b,0x30
  40adb2:	mov    BYTE PTR [r9+0xf],r11b
  40adb6:	lea    r10,[r10+0x2]
  40adba:	lea    r10,[r10+0x2]
  40adbe:	lea    r10,[r10+0x2]
  40adc2:	lea    r10,[r10+0x2]
  40adc6:	lea    r10,[r10+0x2]
  40adca:	vxorpd xmm1,xmm1,xmm1
  40adce:	movzx  edx,dl
  40add1:	vcvtsi2sd xmm1,xmm1,rdx
  40add6:	vsubsd xmm0,xmm0,xmm1
  40adda:	vmulsd xmm0,xmm0,xmm6
  40adde:	vcvttsd2si rdx,xmm0
  40ade3:	mov    r11b,dl
  40ade6:	add    r11b,0x30
  40adea:	mov    BYTE PTR [r9+0x10],r11b
  40adee:	vxorpd xmm1,xmm1,xmm1
  40adf2:	movzx  edx,dl
  40adf5:	vcvtsi2sd xmm1,xmm1,rdx
  40adfa:	vsubsd xmm0,xmm0,xmm1
  40adfe:	vmulsd xmm0,xmm0,xmm6
  40ae02:	vcvttsd2si rdx,xmm0
  40ae07:	add    dl,0x30
  40ae0a:	mov    BYTE PTR [r9+0x11],dl
  40ae0e:	mov    BYTE PTR [r10+0x2],0x65
  40ae13:	lea    r9,[r10+0x3]
  40ae17:	test   r8,r8
  40ae1a:	jl     40ae23 <__swc_fn_4fa09e82_000147_d2097256+0xd43>
  40ae1c:	mov    BYTE PTR [r9],0x2b
  40ae20:	inc    r9
  40ae23:	mov    r10,r9
  40ae26:	mov    rdx,r8
  40ae29:	nop    DWORD PTR [rax+0x0]
  40ae30:	mov    r11,rdx
  40ae33:	movabs rdx,0x6666666666666667
  40ae3d:	mov    rax,r11
  40ae40:	imul   rdx
  40ae43:	sar    rdx,0x2
  40ae47:	mov    r12,rdx
  40ae4a:	shr    rdx,0x3f
  40ae4e:	add    r12,rdx
  40ae51:	mov    rdx,r12
  40ae54:	imul   r13,r12,0xa
  40ae58:	sub    r11,r13
  40ae5b:	mov    r13,QWORD PTR [rip+0x86de]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40ae62:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40ae67:	mov    BYTE PTR [r10],r11b
  40ae6a:	lea    r11,[r10+0x1]
  40ae6e:	mov    r10,r11
  40ae71:	test   r12,r12
  40ae74:	jne    40ae30 <__swc_fn_4fa09e82_000147_d2097256+0xd50>
  40ae76:	test   r8,r8
  40ae79:	jge    40ae83 <__swc_fn_4fa09e82_000147_d2097256+0xda3>
  40ae7b:	mov    BYTE PTR [r11],0x2d
  40ae7f:	lea    r10,[r11+0x1]
  40ae83:	mov    BYTE PTR [r10],0x0
  40ae87:	sub    r10,0x1
  40ae8b:	nop    DWORD PTR [rax+rax*1+0x0]
  40ae90:	cmp    r9,r10
  40ae93:	jae    40b108 <__swc_fn_4fa09e82_000147_d2097256+0x1028>
  40ae99:	mov    al,BYTE PTR [r10]
  40ae9c:	mov    dl,BYTE PTR [r9]
  40ae9f:	mov    BYTE PTR [r10],dl
  40aea2:	sub    r10,0x1
  40aea6:	mov    BYTE PTR [r9],al
  40aea9:	inc    r9
  40aeac:	jmp    40ae90 <__swc_fn_4fa09e82_000147_d2097256+0xdb0>
  40aeae:	vcvttsd2si rdx,xmm0
  40aeb3:	mov    r8,rdx
  40aeb6:	vxorpd xmm1,xmm1,xmm1
  40aeba:	vcvtsi2sd xmm1,xmm1,rdx
  40aebf:	vsubsd xmm1,xmm0,xmm1
  40aec3:	mov    r9d,0x8
  40aec9:	vxorpd xmm2,xmm2,xmm2
  40aecd:	vcomisd xmm2,xmm1
  40aed1:	ja     40aede <__swc_fn_4fa09e82_000147_d2097256+0xdfe>
  40aed3:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40aedc:	jmp    40aeef <__swc_fn_4fa09e82_000147_d2097256+0xe0f>
  40aede:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x866a]        # 413550 <__swc_rdata_base_4fa09e82+0x440>
  40aee6:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40aeef:	test   r9d,r9d
  40aef2:	je     40af09 <__swc_fn_4fa09e82_000147_d2097256+0xe29>
  40aef4:	cs nop WORD PTR [rax+rax*1+0x0]
  40aefe:	xchg   ax,ax
  40af00:	vmulsd xmm1,xmm1,xmm6
  40af04:	dec    r9d
  40af07:	jne    40af00 <__swc_fn_4fa09e82_000147_d2097256+0xe20>
  40af09:	vcvttsd2si r9,xmm1
  40af0e:	mov    r10,r9
  40af11:	vxorpd xmm2,xmm2,xmm2
  40af15:	vcvtsi2sd xmm2,xmm2,r9
  40af1a:	vsubsd xmm1,xmm1,xmm2
  40af1e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  40af27:	vcomisd xmm1,xmm6
  40af2b:	lea    r9,[r9+0x1]
  40af2f:	cmova  r10,r9
  40af33:	cmp    r10,0x5f5e100
  40af3a:	jne    40af53 <__swc_fn_4fa09e82_000147_d2097256+0xe73>
  40af3c:	lea    r8,[rdx-0x1]
  40af40:	vxorpd xmm1,xmm1,xmm1
  40af44:	vcomisd xmm1,xmm0
  40af48:	lea    rdx,[rdx+0x1]
  40af4c:	cmovbe r8,rdx
  40af50:	xor    r10d,r10d
  40af53:	mov    r9,rcx
  40af56:	test   r8,r8
  40af59:	jne    40af79 <__swc_fn_4fa09e82_000147_d2097256+0xe99>
  40af5b:	vxorpd xmm1,xmm1,xmm1
  40af5f:	vcomisd xmm1,xmm0
  40af63:	jbe    40af6c <__swc_fn_4fa09e82_000147_d2097256+0xe8c>
  40af65:	mov    BYTE PTR [rcx],0x2d
  40af68:	lea    r9,[rcx+0x1]
  40af6c:	mov    BYTE PTR [r9],0x30
  40af70:	add    r9,0x1
  40af74:	jmp    40b00b <__swc_fn_4fa09e82_000147_d2097256+0xf2b>
  40af79:	mov    r9,rcx
  40af7c:	mov    rdx,r8
  40af7f:	nop
  40af80:	mov    r11,rdx
  40af83:	movabs rdx,0x6666666666666667
  40af8d:	mov    r15,rax
  40af90:	mov    rax,r11
  40af93:	imul   rdx
  40af96:	mov    r12,rdx
  40af99:	mov    rax,r15
  40af9c:	sar    r12,0x2
  40afa0:	mov    rdx,r12
  40afa3:	shr    rdx,0x3f
  40afa7:	add    r12,rdx
  40afaa:	mov    rdx,r12
  40afad:	imul   r13,r12,0xa
  40afb1:	sub    r11,r13
  40afb4:	mov    r13,QWORD PTR [rip+0x8585]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40afbb:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40afc0:	mov    BYTE PTR [r9],r11b
  40afc3:	lea    r11,[r9+0x1]
  40afc7:	mov    r9,r11
  40afca:	test   r12,r12
  40afcd:	jne    40af80 <__swc_fn_4fa09e82_000147_d2097256+0xea0>
  40afcf:	test   r8,r8
  40afd2:	jge    40afdc <__swc_fn_4fa09e82_000147_d2097256+0xefc>
  40afd4:	mov    BYTE PTR [r11],0x2d
  40afd8:	lea    r9,[r11+0x1]
  40afdc:	mov    rdx,r9
  40afdf:	mov    BYTE PTR [r9],0x0
  40afe3:	sub    r9,0x1
  40afe7:	mov    r8,rcx
  40afea:	cmp    r8,r9
  40afed:	jae    40b008 <__swc_fn_4fa09e82_000147_d2097256+0xf28>
  40afef:	nop
  40aff0:	mov    r11b,BYTE PTR [r9]
  40aff3:	mov    r12b,BYTE PTR [r8]
  40aff6:	mov    BYTE PTR [r9],r12b
  40aff9:	sub    r9,0x1
  40affd:	mov    BYTE PTR [r8],r11b
  40b000:	inc    r8
  40b003:	cmp    r8,r9
  40b006:	jb     40aff0 <__swc_fn_4fa09e82_000147_d2097256+0xf10>
  40b008:	mov    r9,rdx
  40b00b:	mov    BYTE PTR [r9],0x2e
  40b00f:	add    r9,0x1
  40b013:	xor    r8d,r8d
  40b016:	test   r10,r10
  40b019:	je     40b05f <__swc_fn_4fa09e82_000147_d2097256+0xf7f>
  40b01b:	mov    r11d,0x989680
  40b021:	cmp    r10,r11
  40b024:	jge    40b05f <__swc_fn_4fa09e82_000147_d2097256+0xf7f>
  40b026:	cs nop WORD PTR [rax+rax*1+0x0]
  40b030:	inc    r8d
  40b033:	movabs rdx,0x6666666666666667
  40b03d:	mov    r15,rax
  40b040:	mov    rax,r11
  40b043:	imul   rdx
  40b046:	mov    r11,rdx
  40b049:	mov    rax,r15
  40b04c:	sar    r11,0x2
  40b050:	mov    rdx,r11
  40b053:	shr    rdx,0x3f
  40b057:	add    r11,rdx
  40b05a:	cmp    r10,r11
  40b05d:	jl     40b030 <__swc_fn_4fa09e82_000147_d2097256+0xf50>
  40b05f:	test   r8d,r8d
  40b062:	je     40b07d <__swc_fn_4fa09e82_000147_d2097256+0xf9d>
  40b064:	cs nop WORD PTR [rax+rax*1+0x0]
  40b06e:	xchg   ax,ax
  40b070:	mov    BYTE PTR [r9],0x30
  40b074:	add    r9,0x1
  40b078:	dec    r8d
  40b07b:	jne    40b070 <__swc_fn_4fa09e82_000147_d2097256+0xf90>
  40b07d:	mov    r8,r9
  40b080:	mov    rdx,r10
  40b083:	cs nop WORD PTR [rax+rax*1+0x0]
  40b08d:	nop    DWORD PTR [rax]
  40b090:	mov    r11,rdx
  40b093:	movabs rdx,0x6666666666666667
  40b09d:	mov    rax,r11
  40b0a0:	imul   rdx
  40b0a3:	sar    rdx,0x2
  40b0a7:	mov    r12,rdx
  40b0aa:	shr    rdx,0x3f
  40b0ae:	add    r12,rdx
  40b0b1:	mov    rdx,r12
  40b0b4:	imul   r13,r12,0xa
  40b0b8:	sub    r11,r13
  40b0bb:	mov    r13,QWORD PTR [rip+0x847e]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40b0c2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b0c7:	mov    BYTE PTR [r8],r11b
  40b0ca:	lea    r11,[r8+0x1]
  40b0ce:	mov    r8,r11
  40b0d1:	test   r12,r12
  40b0d4:	jne    40b090 <__swc_fn_4fa09e82_000147_d2097256+0xfb0>
  40b0d6:	test   r10,r10
  40b0d9:	jge    40b0e3 <__swc_fn_4fa09e82_000147_d2097256+0x1003>
  40b0db:	mov    BYTE PTR [r11],0x2d
  40b0df:	lea    r8,[r11+0x1]
  40b0e3:	mov    BYTE PTR [r8],0x0
  40b0e7:	sub    r8,0x1
  40b0eb:	cmp    r9,r8
  40b0ee:	jae    40b108 <__swc_fn_4fa09e82_000147_d2097256+0x1028>
  40b0f0:	mov    al,BYTE PTR [r8]
  40b0f3:	mov    dl,BYTE PTR [r9]
  40b0f6:	mov    BYTE PTR [r8],dl
  40b0f9:	sub    r8,0x1
  40b0fd:	mov    BYTE PTR [r9],al
  40b100:	inc    r9
  40b103:	cmp    r9,r8
  40b106:	jb     40b0f0 <__swc_fn_4fa09e82_000147_d2097256+0x1010>
  40b108:	xor    eax,eax
  40b10a:	test   rcx,rcx
  40b10d:	je     40b130 <__swc_fn_4fa09e82_000147_d2097256+0x1050>
  40b10f:	mov    rdx,rcx
  40b112:	mov    r8b,BYTE PTR [rdx]
  40b115:	test   r8b,r8b
  40b118:	je     40b130 <__swc_fn_4fa09e82_000147_d2097256+0x1050>
  40b11a:	nop    WORD PTR [rax+rax*1+0x0]
  40b120:	add    rdx,0x1
  40b124:	add    rax,0x1
  40b128:	mov    r8b,BYTE PTR [rdx]
  40b12b:	test   r8b,r8b
  40b12e:	jne    40b120 <__swc_fn_4fa09e82_000147_d2097256+0x1040>
  40b130:	mov    QWORD PTR [rsp+0x3f8],rcx
  40b138:	mov    QWORD PTR [rsp+0x400],rax
  40b140:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  40b149:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  40b152:	lea    rcx,[rsp+0x408]
  40b15a:	call   409870 <__swc_fn_4fa09e82_000117_3f5cfdef>
  40b15f:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_d2097256+0x10c5>
  40b161:	mov    rcx,rdx
  40b164:	call   409870 <__swc_fn_4fa09e82_000117_3f5cfdef>
  40b169:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_d2097256+0x10c5>
  40b16b:	mov    al,BYTE PTR [rdx]
  40b16d:	test   al,al
  40b16f:	je     40b17a <__swc_fn_4fa09e82_000147_d2097256+0x109a>
  40b171:	lea    rax,[rip+0x83e8]        # 413560 <__swc_rdata_base_4fa09e82+0x450>
  40b178:	jmp    40b181 <__swc_fn_4fa09e82_000147_d2097256+0x10a1>
  40b17a:	lea    rax,[rip+0x83ef]        # 413570 <__swc_rdata_base_4fa09e82+0x460>
  40b181:	mov    rcx,rax
  40b184:	call   409870 <__swc_fn_4fa09e82_000117_3f5cfdef>
  40b189:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_d2097256+0x10c5>
  40b18b:	lea    rcx,[rip+0x83ee]        # 413580 <__swc_rdata_base_4fa09e82+0x470>
  40b192:	call   409870 <__swc_fn_4fa09e82_000117_3f5cfdef>
  40b197:	jmp    40b1a5 <__swc_fn_4fa09e82_000147_d2097256+0x10c5>
  40b199:	lea    rcx,[rip+0x83e0]        # 413580 <__swc_rdata_base_4fa09e82+0x470>
  40b1a0:	call   409870 <__swc_fn_4fa09e82_000117_3f5cfdef>
  40b1a5:	add    rdi,0x1
  40b1a9:	sub    rsi,0x1
  40b1ad:	vmovups xmm0,xmm12
  40b1b2:	vmovsd xmm6,QWORD PTR [rip+0x83d6]        # 413590 <__swc_rdata_base_4fa09e82+0x480>
  40b1ba:	test   rsi,rsi
  40b1bd:	jne    40a1f0 <__swc_fn_4fa09e82_000147_d2097256+0x110>
  40b1c3:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  40b1cc:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  40b1d5:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  40b1de:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  40b1e7:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  40b1f0:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  40b1f9:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  40b202:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  40b20b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  40b214:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  40b21d:	add    rsp,0x4e8
  40b224:	pop    r15
  40b226:	pop    r13
  40b228:	pop    r12
  40b22a:	pop    rdi
  40b22b:	pop    rsi
  40b22c:	pop    rbx
  40b22d:	ret
	...

000000000040b230 <__swc_fn_4fa09e82_000150_365b4daf>:
  40b230:	vxorps xmm0,xmm0,xmm0
  40b234:	vmovups XMMWORD PTR [rcx],xmm0
  40b238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b23d:	ret
	...

000000000040b240 <__swc_fn_4fa09e82_000153_365b4daf>:
  40b240:	vxorps xmm0,xmm0,xmm0
  40b244:	vmovups XMMWORD PTR [rcx],xmm0
  40b248:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b24d:	vxorps xmm0,xmm0,xmm0
  40b251:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b256:	vmovups xmm0,XMMWORD PTR [rip+0x8442]        # 4136a0 <__swc_rdata_base_4fa09e82+0x590>
  40b25e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b263:	vxorps xmm0,xmm0,xmm0
  40b267:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40b26c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40b271:	vxorps xmm0,xmm0,xmm0
  40b275:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40b27a:	mov    QWORD PTR [rcx+0x70],0x0
  40b282:	ret
	...

000000000040b290 <__swc_fn_4fa09e82_000156_365b4daf>:
  40b290:	vxorps xmm0,xmm0,xmm0
  40b294:	vmovups XMMWORD PTR [rcx],xmm0
  40b298:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b29d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b2a2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b2a7:	ret
	...

000000000040b2b0 <__swc_fn_4fa09e82_000159_31e09513>:
  40b2b0:	push   rsi
  40b2b1:	push   rdi
  40b2b2:	sub    rsp,0x8
  40b2b6:	mov    rsi,rcx
  40b2b9:	mov    rdi,QWORD PTR [rsi+0x50]
  40b2bd:	test   rdi,rdi
  40b2c0:	je     40b2c7 <__swc_fn_4fa09e82_000159_31e09513+0x17>
  40b2c2:	mov    rcx,rsi
  40b2c5:	call   rdi
  40b2c7:	mov    QWORD PTR [rsi+0x20],0x0
  40b2cf:	mov    rax,QWORD PTR [rsi+0x30]
  40b2d3:	test   rax,rax
  40b2d6:	je     40b304 <__swc_fn_4fa09e82_000159_31e09513+0x54>
  40b2d8:	nop    DWORD PTR [rax+rax*1+0x0]
  40b2e0:	mov    rdi,QWORD PTR [rax+0x8]
  40b2e4:	mov    rcx,rsi
  40b2e7:	mov    rdx,QWORD PTR [rax+0x10]
  40b2eb:	mov    rax,QWORD PTR [rax+0x18]
  40b2ef:	mov    r8,rax
  40b2f2:	call   40ed10 <__swc_fn_4fa09e82_000157_9e2052d6>
  40b2f7:	mov    QWORD PTR [rsi+0x30],rdi
  40b2fb:	mov    rax,QWORD PTR [rsi+0x30]
  40b2ff:	test   rax,rax
  40b302:	jne    40b2e0 <__swc_fn_4fa09e82_000159_31e09513+0x30>
  40b304:	mov    QWORD PTR [rsi+0x38],0x0
  40b30c:	add    rsp,0x8
  40b310:	pop    rdi
  40b311:	pop    rsi
  40b312:	ret
	...

000000000040b320 <__swc_fn_4fa09e82_000162_b553c03d>:
  40b320:	push   rbx
  40b321:	push   rsi
  40b322:	push   rdi
  40b323:	push   r12
  40b325:	sub    rsp,0x188
  40b32c:	mov    rbx,rcx
  40b32f:	lea    rsi,[rip+0x1ba5a]        # 426d90 <__swc_bss_base_4fa09e82+0x2d50>
  40b336:	mov    rcx,rsi
  40b339:	call   40e720 <__swc_fn_4fa09e82_000136_db32cc57>
  40b33e:	mov    rax,QWORD PTR [rip+0x1ba53]        # 426d98 <__swc_bss_base_4fa09e82+0x2d58>
  40b345:	mov    rdi,rax
  40b348:	test   rdi,rdi
  40b34b:	je     40b379 <__swc_fn_4fa09e82_000162_b553c03d+0x59>
  40b34d:	nop    DWORD PTR [rax]
  40b350:	cmp    QWORD PTR [rdi+0x8],rbx
  40b354:	jne    40b36e <__swc_fn_4fa09e82_000162_b553c03d+0x4e>
  40b356:	mov    rcx,rsi
  40b359:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40b35e:	mov    rax,rdi
  40b361:	add    rsp,0x188
  40b368:	pop    r12
  40b36a:	pop    rdi
  40b36b:	pop    rsi
  40b36c:	pop    rbx
  40b36d:	ret
  40b36e:	mov    rax,QWORD PTR [rdi]
  40b371:	mov    rdi,rax
  40b374:	test   rax,rax
  40b377:	jne    40b350 <__swc_fn_4fa09e82_000162_b553c03d+0x30>
  40b379:	call   4118a0 <__swc_fn_4fa09e82_000140_e4a7a8b1>
  40b37e:	mov    rdi,rax
  40b381:	test   rax,rax
  40b384:	jne    40b39d <__swc_fn_4fa09e82_000162_b553c03d+0x7d>
  40b386:	mov    rcx,rsi
  40b389:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40b38e:	xor    eax,eax
  40b390:	add    rsp,0x188
  40b397:	pop    r12
  40b399:	pop    rdi
  40b39a:	pop    rsi
  40b39b:	pop    rbx
  40b39c:	ret
  40b39d:	lea    rax,[rsp+0x18]
  40b3a2:	mov    QWORD PTR [rax+0x10],0x0
  40b3aa:	mov    QWORD PTR [rax+0x18],0x0
  40b3b2:	mov    DWORD PTR [rax+0x20],0x0
  40b3b9:	mov    BYTE PTR [rax+0x24],0x0
  40b3bd:	mov    rax,QWORD PTR [rip+0x1b9d4]        # 426d98 <__swc_bss_base_4fa09e82+0x2d58>
  40b3c4:	mov    QWORD PTR [rsp+0x18],rax
  40b3c9:	mov    QWORD PTR [rsp+0x20],rbx
  40b3ce:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40b3d4:	vmovups XMMWORD PTR [rdi],xmm0
  40b3d8:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40b3de:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  40b3e3:	mov    rax,QWORD PTR [rsp+0x38]
  40b3e8:	mov    QWORD PTR [rdi+0x20],rax
  40b3ec:	mov    QWORD PTR [rip+0x1b9a5],rdi        # 426d98 <__swc_bss_base_4fa09e82+0x2d58>
  40b3f3:	lea    rax,[rsp+0x40]
  40b3f8:	mov    QWORD PTR [rax],0x0
  40b3ff:	mov    rcx,rbx
  40b402:	mov    rdx,rax
  40b405:	call   40e800 <__swc_fn_4fa09e82_000142_5e493395>
  40b40a:	mov    rbx,rax
  40b40d:	test   rax,rax
  40b410:	jne    40b42a <__swc_fn_4fa09e82_000162_b553c03d+0x10a>
  40b412:	mov    rcx,rsi
  40b415:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40b41a:	mov    rax,rdi
  40b41d:	add    rsp,0x188
  40b424:	pop    r12
  40b426:	pop    rdi
  40b427:	pop    rsi
  40b428:	pop    rbx
  40b429:	ret
  40b42a:	lea    r12,[rsp+0x50]
  40b42f:	mov    QWORD PTR [r12],0x0
  40b437:	mov    rcx,rbx
  40b43a:	mov    rdx,QWORD PTR [rsp+0x40]
  40b43f:	mov    r8,r12
  40b442:	call   411950 <__swc_fn_4fa09e82_000143_89a6ef72>
  40b447:	test   rax,rax
  40b44a:	jne    40b464 <__swc_fn_4fa09e82_000162_b553c03d+0x144>
  40b44c:	mov    rcx,rsi
  40b44f:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40b454:	mov    rax,rdi
  40b457:	add    rsp,0x188
  40b45e:	pop    r12
  40b460:	pop    rdi
  40b461:	pop    rsi
  40b462:	pop    rbx
  40b463:	ret
  40b464:	cmp    QWORD PTR [r12],0x10
  40b469:	jb     40b56c <__swc_fn_4fa09e82_000162_b553c03d+0x24c>
  40b46f:	mov    ecx,DWORD PTR [rax]
  40b471:	cmp    ecx,0x42445753
  40b477:	jne    40b56c <__swc_fn_4fa09e82_000162_b553c03d+0x24c>
  40b47d:	mov    ecx,DWORD PTR [rax+0x4]
  40b480:	cmp    ecx,0x1
  40b483:	jne    40b56c <__swc_fn_4fa09e82_000162_b553c03d+0x24c>
  40b489:	mov    ecx,DWORD PTR [rax+0x8]
  40b48c:	mov    edx,DWORD PTR [rax+0xc]
  40b48f:	imul   r8,rcx,0x14
  40b493:	mov    r9,QWORD PTR [rsp+0x50]
  40b498:	sub    r9,0x10
  40b49c:	cmp    r8,r9
  40b49f:	ja     40b56c <__swc_fn_4fa09e82_000162_b553c03d+0x24c>
  40b4a5:	lea    r8,[r8+0x10]
  40b4a9:	cmp    rdx,r8
  40b4ac:	jb     40b56c <__swc_fn_4fa09e82_000162_b553c03d+0x24c>
  40b4b2:	mov    r8,QWORD PTR [rsp+0x50]
  40b4b7:	cmp    rdx,r8
  40b4ba:	ja     40b56c <__swc_fn_4fa09e82_000162_b553c03d+0x24c>
  40b4c0:	xor    r8d,r8d
  40b4c3:	test   rcx,rcx
  40b4c6:	jbe    40b592 <__swc_fn_4fa09e82_000162_b553c03d+0x272>
  40b4cc:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  40b4d2:	cs nop WORD PTR [rax+rax*1+0x0]
  40b4dc:	nop    DWORD PTR [rax+0x0]
  40b4e0:	imul   r9,r8,0x14
  40b4e4:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  40b4e9:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  40b4ee:	add    r10,r11
  40b4f1:	movabs r11,0x100000000
  40b4fb:	cmp    r10,r11
  40b4fe:	ja     40b56c <__swc_fn_4fa09e82_000162_b553c03d+0x24c>
  40b500:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  40b505:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  40b50a:	test   r10d,r10d
  40b50d:	setne  r11b
  40b511:	je     40b52b <__swc_fn_4fa09e82_000162_b553c03d+0x20b>
  40b513:	cmp    r10d,edx
  40b516:	setb   r11b
  40b51a:	jb     40b52b <__swc_fn_4fa09e82_000162_b553c03d+0x20b>
  40b51c:	vmovq  r11,xmm1
  40b521:	cmp    r10,r11
  40b524:	setae  r10b
  40b528:	mov    r11b,r10b
  40b52b:	mov    r10,r11
  40b52e:	test   r11b,r11b
  40b531:	jne    40b558 <__swc_fn_4fa09e82_000162_b553c03d+0x238>
  40b533:	test   r9d,r9d
  40b536:	setne  r10b
  40b53a:	je     40b558 <__swc_fn_4fa09e82_000162_b553c03d+0x238>
  40b53c:	cmp    r9d,edx
  40b53f:	setb   r10b
  40b543:	jb     40b558 <__swc_fn_4fa09e82_000162_b553c03d+0x238>
  40b545:	vmovq  r10,xmm1
  40b54a:	cmp    r9,r10
  40b54d:	setae  r9b
  40b551:	movzx  r9d,r9b
  40b555:	mov    r10b,r9b
  40b558:	test   r10b,r10b
  40b55b:	jne    40b56c <__swc_fn_4fa09e82_000162_b553c03d+0x24c>
  40b55d:	add    r8,0x1
  40b561:	cmp    r8,rcx
  40b564:	jb     40b4e0 <__swc_fn_4fa09e82_000162_b553c03d+0x1c0>
  40b56a:	jmp    40b592 <__swc_fn_4fa09e82_000162_b553c03d+0x272>
  40b56c:	xor    ecx,ecx
  40b56e:	cmp    rax,rbx
  40b571:	cmovne rcx,rax
  40b575:	call   40a030 <__swc_fn_4fa09e82_000144_b7ad855f>
  40b57a:	mov    rcx,rsi
  40b57d:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40b582:	mov    rax,rdi
  40b585:	add    rsp,0x188
  40b58c:	pop    r12
  40b58e:	pop    rdi
  40b58f:	pop    rsi
  40b590:	pop    rbx
  40b591:	ret
  40b592:	mov    QWORD PTR [rdi+0x10],rax
  40b596:	mov    rcx,QWORD PTR [rsp+0x50]
  40b59b:	mov    QWORD PTR [rdi+0x18],rcx
  40b59f:	mov    eax,DWORD PTR [rax+0x8]
  40b5a2:	mov    DWORD PTR [rdi+0x20],eax
  40b5a5:	rex mov BYTE PTR [rdi+0x24],0x1
  40b5aa:	mov    rcx,rsi
  40b5ad:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40b5b2:	mov    rax,rdi
  40b5b5:	add    rsp,0x188
  40b5bc:	pop    r12
  40b5be:	pop    rdi
  40b5bf:	pop    rsi
  40b5c0:	pop    rbx
  40b5c1:	ret
	...

000000000040b5d0 <__swc_fn_4fa09e82_000165_d25850aa>:
  40b5d0:	push   rsi
  40b5d1:	push   rdi
  40b5d2:	push   r12
  40b5d4:	mov    rsi,rdx
  40b5d7:	mov    rdi,rcx
  40b5da:	mov    rcx,QWORD PTR [rip+0x1b75f]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40b5e1:	test   rcx,rcx
  40b5e4:	jne    40b5f6 <__swc_fn_4fa09e82_000165_d25850aa+0x26>
  40b5e6:	call   40f020 <__swc_fn_4fa09e82_000166_56054fe7>
  40b5eb:	lea    rcx,[rax+0x1]
  40b5ef:	mov    QWORD PTR [rip+0x1b74a],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40b5f6:	dec    rcx
  40b5f9:	call   40b620 <__swc_fn_4fa09e82_000168_39c041ad>
  40b5fe:	mov    r12,QWORD PTR [rax+0xbe0]
  40b605:	test   r12,r12
  40b608:	setne  al
  40b60b:	je     40b616 <__swc_fn_4fa09e82_000165_d25850aa+0x46>
  40b60d:	mov    rcx,rdi
  40b610:	mov    rdx,rsi
  40b613:	call   r12
  40b616:	pop    r12
  40b618:	pop    rdi
  40b619:	pop    rsi
  40b61a:	ret
  40b61b:	add    BYTE PTR [rax],al
  40b61d:	add    BYTE PTR [rax],al
	...

000000000040b620 <__swc_fn_4fa09e82_000168_39c041ad>:
  40b620:	push   r12
  40b622:	push   rdi
  40b623:	push   rsi
  40b624:	sub    rsp,0xd0
  40b62b:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40b631:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40b637:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40b63d:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40b643:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40b649:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40b64f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40b658:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40b661:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40b66a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40b673:	mov    r12,rcx
  40b676:	mov    edi,ecx
  40b678:	xor    eax,eax
  40b67a:	call   407000 <pthread_getspecific@plt>
  40b67f:	test   rax,rax
  40b682:	je     40b686 <__swc_fn_4fa09e82_000168_39c041ad+0x66>
  40b684:	jmp    40b68e <__swc_fn_4fa09e82_000168_39c041ad+0x6e>
  40b686:	mov    rcx,r12
  40b689:	call   40f080 <__swc_fn_4fa09e82_000169_0ad81c51>
  40b68e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40b694:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40b69a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40b6a0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40b6a6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40b6ac:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40b6b2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40b6bb:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40b6c4:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40b6cd:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40b6d6:	add    rsp,0xd0
  40b6dd:	pop    rsi
  40b6de:	pop    rdi
  40b6df:	pop    r12
  40b6e1:	ret
	...

000000000040b6f0 <__swc_fn_4fa09e82_000171_4dbacba0>:
  40b6f0:	push   rsi
  40b6f1:	sub    rsp,0x30
  40b6f5:	lea    rsi,[rip+0x1b6ac]        # 426da8 <__swc_bss_base_4fa09e82+0x2d68>
  40b6fc:	mov    rax,QWORD PTR [rsi]
  40b6ff:	test   rax,rax
  40b702:	je     40b70a <__swc_fn_4fa09e82_000171_4dbacba0+0x1a>
  40b704:	add    rsp,0x30
  40b708:	pop    rsi
  40b709:	ret
  40b70a:	mov    ecx,0x3
  40b70f:	mov    edx,0x10
  40b714:	call   409190 <__swc_fn_4fa09e82_000108_c8d4a68e>
  40b719:	test   rax,rax
  40b71c:	jne    40b72d <__swc_fn_4fa09e82_000171_4dbacba0+0x3d>
  40b71e:	mov    QWORD PTR [rsp+0x18],rax
  40b723:	call   4113e0 <__swc_fn_4fa09e82_000119_591530fe>
  40b728:	mov    rax,QWORD PTR [rsp+0x18]
  40b72d:	mov    rcx,rax
  40b730:	xchg   QWORD PTR [rsi],rcx
  40b733:	add    rsp,0x30
  40b737:	pop    rsi
  40b738:	ret
  40b739:	add    BYTE PTR [rax],al
  40b73b:	add    BYTE PTR [rax],al
  40b73d:	add    BYTE PTR [rax],al
	...

000000000040b740 <__swc_fn_4fa09e82_000174_e17a224b>:
  40b740:	push   rsi
  40b741:	push   rdi
  40b742:	sub    rsp,0x8
  40b746:	mov    rsi,rdx
  40b749:	mov    rdi,rcx
  40b74c:	mov    rax,QWORD PTR [rsi+0x8]
  40b750:	test   rax,rax
  40b753:	je     40b75d <__swc_fn_4fa09e82_000174_e17a224b+0x1d>
  40b755:	mov    rcx,QWORD PTR [rsi]
  40b758:	mov    QWORD PTR [rax],rcx
  40b75b:	jmp    40b764 <__swc_fn_4fa09e82_000174_e17a224b+0x24>
  40b75d:	mov    rax,QWORD PTR [rsi]
  40b760:	mov    QWORD PTR [rdi+0x8],rax
  40b764:	mov    rax,QWORD PTR [rsi]
  40b767:	test   rax,rax
  40b76a:	je     40b774 <__swc_fn_4fa09e82_000174_e17a224b+0x34>
  40b76c:	mov    rcx,QWORD PTR [rsi+0x8]
  40b770:	mov    QWORD PTR [rax+0x8],rcx
  40b774:	mov    rcx,rdi
  40b777:	mov    rdx,QWORD PTR [rsi+0x10]
  40b77b:	mov    r8,QWORD PTR [rsi+0x18]
  40b77f:	mov    r9,0xffffffffffffffff
  40b786:	call   411fa0 <__swc_fn_4fa09e82_000173_1751ecdd>
  40b78b:	mov    QWORD PTR [rsi+0x18],0x0
  40b793:	mov    rax,QWORD PTR [rdi+0x8]
  40b797:	test   rax,rax
  40b79a:	jne    40b7ac <__swc_fn_4fa09e82_000174_e17a224b+0x6c>
  40b79c:	call   40b6f0 <__swc_fn_4fa09e82_000171_4dbacba0>
  40b7a1:	xor    ecx,ecx
  40b7a3:	mov    QWORD PTR [rax+0x8],rcx
  40b7a7:	xor    ecx,ecx
  40b7a9:	mov    QWORD PTR [rax],rcx
  40b7ac:	add    rsp,0x8
  40b7b0:	pop    rdi
  40b7b1:	pop    rsi
  40b7b2:	ret
	...

000000000040b7c0 <__swc_fn_4fa09e82_000177_2744b483>:
  40b7c0:	push   rbx
  40b7c1:	sub    rsp,0x70
  40b7c5:	cmp    rcx,0xffffffffffffffef
  40b7c9:	jbe    40b7d3 <__swc_fn_4fa09e82_000177_2744b483+0x13>
  40b7cb:	xor    eax,eax
  40b7cd:	add    rsp,0x70
  40b7d1:	pop    rbx
  40b7d2:	ret
  40b7d3:	vxorps xmm0,xmm0,xmm0
  40b7d7:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40b7dd:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40b7e3:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  40b7e9:	vzeroupper
  40b7ec:	lea    rax,[rcx+0x10]
  40b7f0:	mov    QWORD PTR [rsp+0x50],rax
  40b7f5:	mov    DWORD PTR [rsp+0x60],0x10
  40b7fd:	mov    rcx,QWORD PTR [rip+0x1b53c]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40b804:	test   rcx,rcx
  40b807:	jne    40b819 <__swc_fn_4fa09e82_000177_2744b483+0x59>
  40b809:	call   40f020 <__swc_fn_4fa09e82_000166_56054fe7>
  40b80e:	lea    rcx,[rax+0x1]
  40b812:	mov    QWORD PTR [rip+0x1b527],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40b819:	dec    rcx
  40b81c:	call   40b620 <__swc_fn_4fa09e82_000168_39c041ad>
  40b821:	mov    rcx,QWORD PTR [rax]
  40b824:	lea    rdx,[rsp+0x8]
  40b829:	mov    rbx,QWORD PTR [rax+0x8]
  40b82d:	mov    rbx,QWORD PTR [rbx+0x8]
  40b831:	call   rbx
  40b833:	mov    rax,QWORD PTR [rsp+0x48]
  40b838:	test   rax,rax
  40b83b:	jne    40b845 <__swc_fn_4fa09e82_000177_2744b483+0x85>
  40b83d:	xor    eax,eax
  40b83f:	add    rsp,0x70
  40b843:	pop    rbx
  40b844:	ret
  40b845:	mov    rcx,QWORD PTR [rsp+0x50]
  40b84a:	mov    QWORD PTR [rax],rcx
  40b84d:	mov    QWORD PTR [rax+0x8],0x0
  40b855:	lea    rax,[rax+0x10]
  40b859:	add    rsp,0x70
  40b85d:	pop    rbx
  40b85e:	ret
	...

000000000040b860 <__swc_fn_4fa09e82_000180_913db40c>:
  40b860:	push   rbp
  40b861:	push   rbx
  40b862:	push   rsi
  40b863:	push   rdi
  40b864:	push   r12
  40b866:	push   r15
  40b868:	push   r13
  40b86a:	push   r14
  40b86c:	sub    rsp,0x10
  40b870:	mov    rbp,rsp
  40b873:	vmovups XMMWORD PTR [rsp],xmm6
  40b878:	sub    rsp,0x50
  40b87c:	mov    rbx,rsp
  40b87f:	sub    rsp,0x8
  40b883:	mov    ecx,0x13880
  40b888:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  40b88d:	mov    rsi,rax
  40b890:	mov    ecx,0x9c40
  40b895:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  40b89a:	mov    rdi,rax
  40b89d:	mov    ecx,0x9c40
  40b8a2:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  40b8a7:	mov    r12,rax
  40b8aa:	xor    ecx,ecx
  40b8ac:	xor    r8d,r8d
  40b8af:	cs nop WORD PTR [rax+rax*1+0x0]
  40b8b9:	nop    DWORD PTR [rax+0x0]
  40b8c0:	lea    r9,[r8+0x1]
  40b8c4:	mov    r10,r9
  40b8c7:	movabs rdx,0xaaaaaaaaaaaaaaab
  40b8d1:	mov    r15,rax
  40b8d4:	mov    rax,r8
  40b8d7:	mul    rdx
  40b8da:	mov    r11,rdx
  40b8dd:	mov    rax,r15
  40b8e0:	shr    r11,0x2
  40b8e4:	imul   r11,r11,0x6
  40b8e8:	mov    rdx,r8
  40b8eb:	sub    rdx,r11
  40b8ee:	lea    r11,[rdx+0x3]
  40b8f2:	mov    QWORD PTR [rdi+r8*8],rcx
  40b8f6:	mov    QWORD PTR [r12+r8*8],r11
  40b8fa:	xor    r8d,r8d
  40b8fd:	test   r11,r11
  40b900:	jbe    40b954 <__swc_fn_4fa09e82_000180_913db40c+0xf4>
  40b902:	xor    r13d,r13d
  40b905:	cs nop WORD PTR [rax+rax*1+0x0]
  40b90f:	nop
  40b910:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40b91a:	mov    r15,rax
  40b91d:	mov    rax,r10
  40b920:	mul    rdx
  40b923:	mov    r14,rdx
  40b926:	mov    rax,r15
  40b929:	shr    r14,0x3
  40b92d:	imul   r14,r14,0x1a
  40b931:	sub    r10,r14
  40b934:	lea    r10,[r10+0x61]
  40b938:	mov    BYTE PTR [rsi+rcx*1],r10b
  40b93c:	inc    rcx
  40b93f:	shr    rdx,0x3
  40b943:	lea    r10,[rdx+r13*1]
  40b947:	add    r8,0x1
  40b94b:	add    r13,0x7
  40b94f:	cmp    r8,r11
  40b952:	jb     40b910 <__swc_fn_4fa09e82_000180_913db40c+0xb0>
  40b954:	mov    r8,r9
  40b957:	cmp    r9,0x1388
  40b95e:	jb     40b8c0 <__swc_fn_4fa09e82_000180_913db40c+0x60>
  40b964:	mov    ecx,0x16e3600
  40b969:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  40b96e:	mov    QWORD PTR [rip+0x1b45b],rax        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40b975:	xor    ecx,ecx
  40b977:	xor    r8d,r8d
  40b97a:	nop    WORD PTR [rax+rax*1+0x0]
  40b980:	mov    r9,QWORD PTR [rip+0x16689]        # 422010 <__swc_data_base_4fa09e82+0x10>
  40b987:	imul   r9,r9,0x41a7
  40b98e:	movabs rdx,0x200000005
  40b998:	mov    r11,rax
  40b99b:	mov    rax,r9
  40b99e:	mul    rdx
  40b9a1:	mov    r10,rdx
  40b9a4:	mov    rdx,r9
  40b9a7:	sub    rdx,r10
  40b9aa:	shr    rdx,1
  40b9ad:	add    rdx,r10
  40b9b0:	shr    rdx,0x1e
  40b9b4:	imul   r10,rdx,0x7fffffff
  40b9bb:	sub    r9,r10
  40b9be:	mov    QWORD PTR [rip+0x1664b],r9        # 422010 <__swc_data_base_4fa09e82+0x10>
  40b9c5:	movabs rdx,0x346dc5d63886594b
  40b9cf:	mov    rax,r9
  40b9d2:	mul    rdx
  40b9d5:	mov    rax,r11
  40b9d8:	shr    rdx,0xa
  40b9dc:	imul   rdx,rdx,0x1388
  40b9e3:	sub    r9,rdx
  40b9e6:	mov    rdx,QWORD PTR [rdi+r9*8]
  40b9ea:	mov    r9,QWORD PTR [r12+r9*8]
  40b9ee:	xor    r10d,r10d
  40b9f1:	test   r9,r9
  40b9f4:	jbe    40ba14 <__swc_fn_4fa09e82_000180_913db40c+0x1b4>
  40b9f6:	mov    r11,QWORD PTR [rip+0x1b3d3]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40b9fd:	add    rdx,rsi
  40ba00:	mov    r13b,BYTE PTR [rdx+r10*1]
  40ba04:	mov    BYTE PTR [r11+rcx*1],r13b
  40ba08:	inc    rcx
  40ba0b:	add    r10,0x1
  40ba0f:	cmp    r10,r9
  40ba12:	jb     40ba00 <__swc_fn_4fa09e82_000180_913db40c+0x1a0>
  40ba14:	lea    r9,[r8+0x1]
  40ba18:	movabs rdx,0xaaaaaaaaaaaaaaab
  40ba22:	mov    r11,rax
  40ba25:	mov    rax,r9
  40ba28:	mul    rdx
  40ba2b:	mov    r8,rdx
  40ba2e:	mov    rax,r11
  40ba31:	shr    r8,0x3
  40ba35:	imul   r8,r8,0xc
  40ba39:	mov    rdx,r9
  40ba3c:	sub    rdx,r8
  40ba3f:	jne    40ba4e <__swc_fn_4fa09e82_000180_913db40c+0x1ee>
  40ba41:	mov    rdx,QWORD PTR [rip+0x1b388]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40ba48:	mov    BYTE PTR [rdx+rcx*1],0xa
  40ba4c:	jmp    40ba59 <__swc_fn_4fa09e82_000180_913db40c+0x1f9>
  40ba4e:	mov    rdx,QWORD PTR [rip+0x1b37b]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40ba55:	mov    BYTE PTR [rdx+rcx*1],0x20
  40ba59:	lea    r13,[rcx+0x1]
  40ba5d:	mov    r15,r13
  40ba60:	mov    rcx,r13
  40ba63:	mov    r8,r9
  40ba66:	cmp    r9,0x1e8480
  40ba6d:	jb     40b980 <__swc_fn_4fa09e82_000180_913db40c+0x120>
  40ba73:	mov    QWORD PTR [rsp+0x48],r15
  40ba78:	call   40f1d0 <__swc_fn_4fa09e82_000178_1ca87929>
  40ba7d:	vmovups xmm6,xmm0
  40ba81:	mov    rsi,rbx
  40ba84:	mov    QWORD PTR [rsp+0x50],rsi
  40ba89:	vxorps xmm0,xmm0,xmm0
  40ba8d:	vmovups XMMWORD PTR [rbx],xmm0
  40ba91:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ba96:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ba9b:	mov    QWORD PTR [rbx+0x30],0x0
  40baa3:	mov    r8,QWORD PTR [rip+0x1b326]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40baaa:	mov    rcx,rsi
  40baad:	mov    edx,0x4000
  40bab2:	call   412050 <__swc_fn_4fa09e82_000176_e7f0b636>
  40bab7:	xor    edi,edi
  40bab9:	xor    al,al
  40babb:	xor    r12d,r12d
  40babe:	cmp    r12,r13
  40bac1:	jae    40bc2f <__swc_fn_4fa09e82_000180_913db40c+0x3cf>
  40bac7:	nop    WORD PTR [rax+rax*1+0x0]
  40bad0:	mov    rcx,QWORD PTR [rip+0x1b2f9]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40bad7:	mov    cl,BYTE PTR [rcx+r12*1]
  40badb:	sub    cl,0x61
  40bade:	cmp    cl,0x19
  40bae1:	ja     40baf8 <__swc_fn_4fa09e82_000180_913db40c+0x298>
  40bae3:	test   al,al
  40bae5:	jne    40bc1e <__swc_fn_4fa09e82_000180_913db40c+0x3be>
  40baeb:	mov    rdi,r12
  40baee:	mov    eax,0x1
  40baf3:	jmp    40bc1e <__swc_fn_4fa09e82_000180_913db40c+0x3be>
  40baf8:	test   al,al
  40bafa:	je     40bc1e <__swc_fn_4fa09e82_000180_913db40c+0x3be>
  40bb00:	mov    r14,r12
  40bb03:	sub    r14,rdi
  40bb06:	mov    eax,0x811c9dc5
  40bb0b:	xor    ecx,ecx
  40bb0d:	test   r14,r14
  40bb10:	jbe    40bb92 <__swc_fn_4fa09e82_000180_913db40c+0x332>
  40bb16:	mov    rdx,QWORD PTR [rbx+0x20]
  40bb1a:	add    rdx,rdi
  40bb1d:	cmp    r14,0x4
  40bb21:	jb     40bb80 <__swc_fn_4fa09e82_000180_913db40c+0x320>
  40bb27:	lea    r8,[r14-0x3]
  40bb2b:	cs nop WORD PTR [rax+rax*1+0x0]
  40bb35:	cs nop WORD PTR [rax+rax*1+0x0]
  40bb3f:	nop
  40bb40:	xor    al,BYTE PTR [rdx+rcx*1]
  40bb43:	imul   eax,eax,0x1000193
  40bb49:	xor    al,BYTE PTR [rdx+rcx*1+0x1]
  40bb4d:	imul   eax,eax,0x1000193
  40bb53:	xor    al,BYTE PTR [rdx+rcx*1+0x2]
  40bb57:	imul   eax,eax,0x1000193
  40bb5d:	xor    al,BYTE PTR [rdx+rcx*1+0x3]
  40bb61:	imul   eax,eax,0x1000193
  40bb67:	add    rcx,0x4
  40bb6b:	cmp    rcx,r8
  40bb6e:	jb     40bb40 <__swc_fn_4fa09e82_000180_913db40c+0x2e0>
  40bb70:	cmp    rcx,r14
  40bb73:	jae    40bb92 <__swc_fn_4fa09e82_000180_913db40c+0x332>
  40bb75:	cs nop WORD PTR [rax+rax*1+0x0]
  40bb7f:	nop
  40bb80:	xor    al,BYTE PTR [rdx+rcx*1]
  40bb83:	imul   eax,eax,0x1000193
  40bb89:	add    rcx,0x1
  40bb8d:	cmp    rcx,r14
  40bb90:	jb     40bb80 <__swc_fn_4fa09e82_000180_913db40c+0x320>
  40bb92:	and    rax,QWORD PTR [rbx+0x28]
  40bb96:	mov    r15,rax
  40bb99:	mov    rsi,QWORD PTR [rbx+0x18]
  40bb9d:	mov    r13,QWORD PTR [rbx+0x8]
  40bba1:	cmp    BYTE PTR [rsi+r15*1],0x0
  40bba6:	je     40bbe6 <__swc_fn_4fa09e82_000180_913db40c+0x386>
  40bba8:	nop    DWORD PTR [rax+rax*1+0x0]
  40bbb0:	cmp    QWORD PTR [r13+r15*8+0x0],r14
  40bbb5:	jne    40bbd8 <__swc_fn_4fa09e82_000180_913db40c+0x378>
  40bbb7:	mov    rax,QWORD PTR [rbx]
  40bbba:	mov    rax,QWORD PTR [rax+r15*8]
  40bbbe:	mov    rcx,QWORD PTR [rbx+0x20]
  40bbc2:	add    rax,rcx
  40bbc5:	lea    rdx,[rcx+rdi*1]
  40bbc9:	mov    rcx,rax
  40bbcc:	mov    r8,r14
  40bbcf:	call   410e70 <__swc_fn_4fa09e82_000107_aba05410>
  40bbd4:	test   eax,eax
  40bbd6:	je     40bbe6 <__swc_fn_4fa09e82_000180_913db40c+0x386>
  40bbd8:	inc    r15
  40bbdb:	and    r15,QWORD PTR [rbx+0x28]
  40bbdf:	cmp    BYTE PTR [rsi+r15*1],0x0
  40bbe4:	jne    40bbb0 <__swc_fn_4fa09e82_000180_913db40c+0x350>
  40bbe6:	cmp    BYTE PTR [rsi+r15*1],0x0
  40bbeb:	jne    40bc14 <__swc_fn_4fa09e82_000180_913db40c+0x3b4>
  40bbed:	mov    BYTE PTR [rsi+r15*1],0x1
  40bbf2:	mov    rax,QWORD PTR [rbx]
  40bbf5:	mov    QWORD PTR [rax+r15*8],rdi
  40bbf9:	mov    rax,QWORD PTR [rbx+0x8]
  40bbfd:	mov    QWORD PTR [rax+r15*8],r14
  40bc01:	mov    rax,QWORD PTR [rbx+0x10]
  40bc05:	mov    QWORD PTR [rax+r15*8],0x1
  40bc0d:	add    QWORD PTR [rbx+0x30],0x1
  40bc12:	jmp    40bc1c <__swc_fn_4fa09e82_000180_913db40c+0x3bc>
  40bc14:	mov    rax,QWORD PTR [rbx+0x10]
  40bc18:	inc    QWORD PTR [rax+r15*8]
  40bc1c:	xor    eax,eax
  40bc1e:	inc    r12
  40bc21:	mov    r13,QWORD PTR [rsp+0x48]
  40bc26:	cmp    r12,r13
  40bc29:	jb     40bad0 <__swc_fn_4fa09e82_000180_913db40c+0x270>
  40bc2f:	test   al,al
  40bc31:	je     40bd5b <__swc_fn_4fa09e82_000180_913db40c+0x4fb>
  40bc37:	mov    r13,QWORD PTR [rsp+0x48]
  40bc3c:	sub    r13,rdi
  40bc3f:	mov    eax,0x811c9dc5
  40bc44:	xor    ecx,ecx
  40bc46:	test   r13,r13
  40bc49:	jbe    40bcd2 <__swc_fn_4fa09e82_000180_913db40c+0x472>
  40bc4f:	mov    rdx,QWORD PTR [rbx+0x20]
  40bc53:	add    rdx,rdi
  40bc56:	cmp    r13,0x4
  40bc5a:	jb     40bcc0 <__swc_fn_4fa09e82_000180_913db40c+0x460>
  40bc60:	lea    r8,[r13-0x3]
  40bc64:	cs nop WORD PTR [rax+rax*1+0x0]
  40bc6e:	cs nop WORD PTR [rax+rax*1+0x0]
  40bc78:	nop    DWORD PTR [rax+rax*1+0x0]
  40bc80:	xor    al,BYTE PTR [rdx+rcx*1]
  40bc83:	imul   eax,eax,0x1000193
  40bc89:	xor    al,BYTE PTR [rdx+rcx*1+0x1]
  40bc8d:	imul   eax,eax,0x1000193
  40bc93:	xor    al,BYTE PTR [rdx+rcx*1+0x2]
  40bc97:	imul   eax,eax,0x1000193
  40bc9d:	xor    al,BYTE PTR [rdx+rcx*1+0x3]
  40bca1:	imul   eax,eax,0x1000193
  40bca7:	add    rcx,0x4
  40bcab:	cmp    rcx,r8
  40bcae:	jb     40bc80 <__swc_fn_4fa09e82_000180_913db40c+0x420>
  40bcb0:	cmp    rcx,r13
  40bcb3:	jae    40bcd2 <__swc_fn_4fa09e82_000180_913db40c+0x472>
  40bcb5:	cs nop WORD PTR [rax+rax*1+0x0]
  40bcbf:	nop
  40bcc0:	xor    al,BYTE PTR [rdx+rcx*1]
  40bcc3:	imul   eax,eax,0x1000193
  40bcc9:	add    rcx,0x1
  40bccd:	cmp    rcx,r13
  40bcd0:	jb     40bcc0 <__swc_fn_4fa09e82_000180_913db40c+0x460>
  40bcd2:	mov    rsi,QWORD PTR [rsp+0x50]
  40bcd7:	and    rax,QWORD PTR [rsi+0x28]
  40bcdb:	mov    r12,rax
  40bcde:	mov    r14,QWORD PTR [rbx+0x18]
  40bce2:	mov    r15,QWORD PTR [rbx+0x8]
  40bce6:	cmp    BYTE PTR [r14+r12*1],0x0
  40bceb:	je     40bd25 <__swc_fn_4fa09e82_000180_913db40c+0x4c5>
  40bced:	nop    DWORD PTR [rax]
  40bcf0:	cmp    QWORD PTR [r15+r12*8],r13
  40bcf4:	jne    40bd17 <__swc_fn_4fa09e82_000180_913db40c+0x4b7>
  40bcf6:	mov    rax,QWORD PTR [rbx]
  40bcf9:	mov    rax,QWORD PTR [rax+r12*8]
  40bcfd:	mov    rcx,QWORD PTR [rbx+0x20]
  40bd01:	add    rax,rcx
  40bd04:	lea    rdx,[rcx+rdi*1]
  40bd08:	mov    rcx,rax
  40bd0b:	mov    r8,r13
  40bd0e:	call   410e70 <__swc_fn_4fa09e82_000107_aba05410>
  40bd13:	test   eax,eax
  40bd15:	je     40bd25 <__swc_fn_4fa09e82_000180_913db40c+0x4c5>
  40bd17:	inc    r12
  40bd1a:	and    r12,QWORD PTR [rbx+0x28]
  40bd1e:	cmp    BYTE PTR [r14+r12*1],0x0
  40bd23:	jne    40bcf0 <__swc_fn_4fa09e82_000180_913db40c+0x490>
  40bd25:	cmp    BYTE PTR [r14+r12*1],0x0
  40bd2a:	jne    40bd53 <__swc_fn_4fa09e82_000180_913db40c+0x4f3>
  40bd2c:	mov    BYTE PTR [r14+r12*1],0x1
  40bd31:	mov    rax,QWORD PTR [rbx]
  40bd34:	mov    QWORD PTR [rax+r12*8],rdi
  40bd38:	mov    rax,QWORD PTR [rbx+0x8]
  40bd3c:	mov    QWORD PTR [rax+r12*8],r13
  40bd40:	mov    rax,QWORD PTR [rbx+0x10]
  40bd44:	mov    QWORD PTR [rax+r12*8],0x1
  40bd4c:	add    QWORD PTR [rsi+0x30],0x1
  40bd51:	jmp    40bd5b <__swc_fn_4fa09e82_000180_913db40c+0x4fb>
  40bd53:	mov    rax,QWORD PTR [rbx+0x10]
  40bd57:	inc    QWORD PTR [rax+r12*8]
  40bd5b:	mov    rsi,QWORD PTR [rbx+0x30]
  40bd5f:	lea    rdi,[rsi*8+0x0]
  40bd67:	mov    rcx,rdi
  40bd6a:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  40bd6f:	mov    QWORD PTR [rip+0x1b042],rax        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  40bd76:	mov    rcx,rdi
  40bd79:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  40bd7e:	mov    QWORD PTR [rip+0x1b043],rax        # 426dc8 <__swc_bss_base_4fa09e82+0x2d88>
  40bd85:	mov    rcx,rdi
  40bd88:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  40bd8d:	mov    QWORD PTR [rip+0x1b02c],rax        # 426dc0 <__swc_bss_base_4fa09e82+0x2d80>
  40bd94:	mov    rcx,rdi
  40bd97:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  40bd9c:	mov    QWORD PTR [rip+0x1b00d],rax        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  40bda3:	xor    ecx,ecx
  40bda5:	xor    edx,edx
  40bda7:	mov    r8,QWORD PTR [rip+0x1b00a]        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  40bdae:	mov    r9,QWORD PTR [rip+0x1b013]        # 426dc8 <__swc_bss_base_4fa09e82+0x2d88>
  40bdb5:	mov    r10,QWORD PTR [rip+0x1b004]        # 426dc0 <__swc_bss_base_4fa09e82+0x2d80>
  40bdbc:	cs nop WORD PTR [rax+rax*1+0x0]
  40bdc6:	cs nop WORD PTR [rax+rax*1+0x0]
  40bdd0:	mov    r11,QWORD PTR [rbx+0x18]
  40bdd4:	cmp    BYTE PTR [r11+rdx*1],0x0
  40bdd9:	je     40be05 <__swc_fn_4fa09e82_000180_913db40c+0x5a5>
  40bddb:	mov    r11,QWORD PTR [rbx+0x10]
  40bddf:	mov    r11,QWORD PTR [r11+rdx*8]
  40bde3:	mov    QWORD PTR [r8+rcx*8],r11
  40bde7:	mov    r11,QWORD PTR [rbx]
  40bdea:	mov    r11,QWORD PTR [r11+rdx*8]
  40bdee:	mov    QWORD PTR [r9+rcx*8],r11
  40bdf2:	mov    r11,QWORD PTR [rbx+0x8]
  40bdf6:	mov    r11,QWORD PTR [r11+rdx*8]
  40bdfa:	mov    QWORD PTR [r10+rcx*8],r11
  40bdfe:	mov    QWORD PTR [rax+rcx*8],rcx
  40be02:	inc    rcx
  40be05:	add    rdx,0x1
  40be09:	cmp    rdx,0x4000
  40be10:	jb     40bdd0 <__swc_fn_4fa09e82_000180_913db40c+0x570>
  40be12:	xor    ecx,ecx
  40be14:	lea    rdx,[rsi-0x1]
  40be18:	call   4120d0 <__swc_fn_4fa09e82_000179_6937fe70>
  40be1d:	imul   rsi,rsi,0x7
  40be21:	xor    eax,eax
  40be23:	mov    rcx,QWORD PTR [rip+0x1af86]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  40be2a:	mov    rdx,QWORD PTR [rip+0x1af87]        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  40be31:	cs nop WORD PTR [rax+rax*1+0x0]
  40be3b:	nop    DWORD PTR [rax+rax*1+0x0]
  40be40:	lea    r8,[rax+0x1]
  40be44:	mov    rax,QWORD PTR [rcx+rax*8]
  40be48:	mov    r9,r8
  40be4b:	imul   r9,QWORD PTR [rdx+rax*8]
  40be50:	add    rsi,r9
  40be53:	mov    rax,r8
  40be56:	cmp    r8,0x14
  40be5a:	jb     40be40 <__swc_fn_4fa09e82_000180_913db40c+0x5e0>
  40be5c:	call   40f1d0 <__swc_fn_4fa09e82_000178_1ca87929>
  40be61:	vsubsd xmm0,xmm0,xmm6
  40be65:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x7b5b]        # 4139c8 <__swc_rdata_base_4fa09e82+0x8b8>
  40be6d:	lea    rax,[rip+0x74f4]        # 413368 <__swc_rdata_base_4fa09e82+0x258>
  40be74:	sub    rsp,0x88
  40be7b:	mov    rcx,rsp
  40be7e:	vmovups xmm1,XMMWORD PTR [rip+0x7b22]        # 4139a8 <__swc_rdata_base_4fa09e82+0x898>
  40be86:	vmovups XMMWORD PTR [rcx],xmm1
  40be8a:	mov    QWORD PTR [rcx+0x30],rsp
  40be8e:	lea    rdx,[rip+0x747b]        # 413310 <__swc_rdata_base_4fa09e82+0x200>
  40be95:	mov    QWORD PTR [rcx+0x38],rdx
  40be99:	mov    QWORD PTR [rcx+0x10],rsi
  40be9d:	lea    r8,[rsp+0x10]
  40bea2:	mov    QWORD PTR [rcx+0x40],r8
  40bea6:	lea    r8,[rip+0x7a6b]        # 413918 <__swc_rdata_base_4fa09e82+0x808>
  40bead:	mov    QWORD PTR [rcx+0x48],r8
  40beb1:	vmovups xmm1,XMMWORD PTR [rip+0x7aff]        # 4139b8 <__swc_rdata_base_4fa09e82+0x8a8>
  40beb9:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40bebe:	lea    r8,[rsp+0x18]
  40bec3:	mov    QWORD PTR [rcx+0x50],r8
  40bec7:	mov    QWORD PTR [rcx+0x58],rdx
  40becb:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40bed0:	lea    r8,[rcx+0x28]
  40bed4:	mov    QWORD PTR [rcx+0x60],r8
  40bed8:	lea    r8,[rip+0x7a81]        # 413960 <__swc_rdata_base_4fa09e82+0x850>
  40bedf:	mov    QWORD PTR [rcx+0x68],r8
  40bee3:	mov    QWORD PTR [rcx+0x70],rax
  40bee7:	mov    QWORD PTR [rcx+0x78],rdx
  40beeb:	lea    rax,[rcx+0x30]
  40beef:	mov    QWORD PTR [rcx+0x80],rax
  40bef6:	mov    QWORD PTR [rcx+0x88],0x5
  40bf01:	lea    rcx,[rcx+0x80]
  40bf08:	sub    rsp,0x8
  40bf0c:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  40bf11:	add    rsp,0xe8
  40bf18:	vmovups xmm6,XMMWORD PTR [rsp]
  40bf1d:	add    rsp,0x10
  40bf21:	pop    r14
  40bf23:	pop    r13
  40bf25:	pop    r15
  40bf27:	pop    r12
  40bf29:	pop    rdi
  40bf2a:	pop    rsi
  40bf2b:	pop    rbx
  40bf2c:	pop    rbp
  40bf2d:	ret
	...

000000000040bf40 <__swc_fn_4fa09e82_000001_0e26756e>:
  40bf40:	vxorps xmm0,xmm0,xmm0
  40bf44:	xor    eax,eax
  40bf46:	cs nop WORD PTR [rax+rax*1+0x0]
  40bf50:	cs nop WORD PTR [rax+rax*1+0x0]
  40bf5a:	nop    WORD PTR [rax+rax*1+0x0]
  40bf60:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40bf65:	add    rax,0x10
  40bf69:	cmp    rax,0x2080
  40bf70:	jne    40bf60 <__swc_fn_4fa09e82_000001_0e26756e+0x20>
  40bf72:	ret
	...

000000000040bf80 <__swc_fn_4fa09e82_000004_3deb8b54>:
  40bf80:	push   rsi
  40bf81:	push   rdi
  40bf82:	push   r12
  40bf84:	push   r13
  40bf86:	push   r14
  40bf88:	mov    rsi,rcx
  40bf8b:	mov    edi,r10d
  40bf8e:	mov    r12,rcx
  40bf91:	mov    r13,r9
  40bf94:	mov    ecx,DWORD PTR [rdx+0x28]
  40bf97:	shlx   r14d,r8d,ecx
  40bf9c:	mov    rcx,rdx
  40bf9f:	mov    edx,r8d
  40bfa2:	call   40f3a0 <__swc_fn_4fa09e82_000011_71c91685>
  40bfa7:	mov    rcx,rax
  40bfaa:	mov    eax,DWORD PTR [r12+0x3c]
  40bfaf:	xor    edx,edx
  40bfb1:	div    rdi
  40bfb4:	vxorps xmm0,xmm0,xmm0
  40bfb8:	vmovdqu XMMWORD PTR [rsi],xmm0
  40bfbc:	mov    QWORD PTR [r12+0x60],0x0
  40bfc5:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40bfca:	mov    QWORD PTR [r12+0x10],rcx
  40bfcf:	imul   rax,rdi
  40bfd3:	lea    rdx,[rcx+rax*1]
  40bfd7:	mov    QWORD PTR [r12+0x18],rdx
  40bfdc:	mov    QWORD PTR [r12+0x20],rcx
  40bfe1:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40bfe6:	mov    DWORD PTR [r12+0x28],0x0
  40bfef:	mov    DWORD PTR [r12+0x68],0x0
  40bff8:	mov    BYTE PTR [r12+0x39],r13b
  40bffd:	mov    BYTE PTR [r12+0x3a],r14b
  40c002:	mov    BYTE PTR [r12+0x3b],0x1
  40c008:	mov    DWORD PTR [r12+0x6c],0x0
  40c011:	mov    rcx,r12
  40c014:	mov    edx,edi
  40c016:	call   40f300 <__swc_fn_4fa09e82_000005_6a556171>
  40c01b:	pop    r14
  40c01d:	pop    r13
  40c01f:	pop    r12
  40c021:	pop    rdi
  40c022:	pop    rsi
  40c023:	ret
	...

000000000040c030 <__swc_fn_4fa09e82_000007_a7bfb091>:
  40c030:	mov    r8d,0x1
  40c036:	xor    eax,eax
  40c038:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40c03e:	test   eax,eax
  40c040:	jne    40c030 <__swc_fn_4fa09e82_000007_a7bfb091>
  40c042:	ret
	...

000000000040c050 <__swc_fn_4fa09e82_000010_0569f799>:
  40c050:	lea    r8,[rcx+0x60]
  40c054:	mov    rax,QWORD PTR [r8]
  40c057:	mov    r9,rax
  40c05a:	nop    WORD PTR [rax+rax*1+0x0]
  40c060:	mov    QWORD PTR [rdx],r9
  40c063:	mov    rax,r9
  40c066:	lock cmpxchg QWORD PTR [r8],rdx
  40c06b:	cmp    rax,r9
  40c06e:	jne    40c0d7 <__swc_fn_4fa09e82_000010_0569f799+0x87>
  40c070:	mov    eax,DWORD PTR [rcx+0x6c]
  40c073:	test   eax,eax
  40c075:	je     40c0d6 <__swc_fn_4fa09e82_000010_0569f799+0x86>
  40c077:	lea    rdx,[rcx+0x70]
  40c07b:	mov    r9d,0x1
  40c081:	xor    eax,eax
  40c083:	lock cmpxchg DWORD PTR [rdx],r9d
  40c088:	test   eax,eax
  40c08a:	jne    40c0d6 <__swc_fn_4fa09e82_000010_0569f799+0x86>
  40c08c:	mov    rax,rcx
  40c08f:	and    rax,0xffffffffffc00000
  40c096:	mov    rax,QWORD PTR [rax+0x8]
  40c09a:	test   rax,rax
  40c09d:	jne    40c0a5 <__swc_fn_4fa09e82_000010_0569f799+0x55>
  40c09f:	xor    eax,eax
  40c0a1:	xchg   DWORD PTR [rdx],eax
  40c0a3:	jmp    40c0d6 <__swc_fn_4fa09e82_000010_0569f799+0x86>
  40c0a5:	lea    rdx,[rax+0x2a80]
  40c0ac:	mov    rax,QWORD PTR [rdx]
  40c0af:	mov    r8,rax
  40c0b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0bc:	nop    DWORD PTR [rax+0x0]
  40c0c0:	mov    QWORD PTR [rcx+0x78],r8
  40c0c4:	mov    rax,r8
  40c0c7:	lock cmpxchg QWORD PTR [rdx],rcx
  40c0cc:	cmp    rax,r8
  40c0cf:	je     40c0d6 <__swc_fn_4fa09e82_000010_0569f799+0x86>
  40c0d1:	mov    r8,rax
  40c0d4:	jmp    40c0c0 <__swc_fn_4fa09e82_000010_0569f799+0x70>
  40c0d6:	ret
  40c0d7:	mov    r9,rax
  40c0da:	jmp    40c060 <__swc_fn_4fa09e82_000010_0569f799+0x10>
	...

000000000040c0e0 <__swc_fn_4fa09e82_000013_7b85dbab>:
  40c0e0:	push   rsi
  40c0e1:	push   rdi
  40c0e2:	push   r12
  40c0e4:	push   r13
  40c0e6:	push   r14
  40c0e8:	push   r15
  40c0ea:	push   rbx
  40c0eb:	sub    rsp,0x30
  40c0ef:	mov    QWORD PTR [rsp+0x18],r8
  40c0f4:	mov    rsi,rcx
  40c0f7:	mov    rdi,rdx
  40c0fa:	mov    rdx,QWORD PTR [rsi+0x40]
  40c0fe:	xchg   ax,ax
  40c100:	mov    rax,rdx
  40c103:	not    rax
  40c106:	and    rax,QWORD PTR [rsi+0x20]
  40c10a:	test   rax,rax
  40c10d:	jne    40c121 <__swc_fn_4fa09e82_000013_7b85dbab+0x41>
  40c10f:	xor    eax,eax
  40c111:	add    rsp,0x30
  40c115:	pop    rbx
  40c116:	pop    r15
  40c118:	pop    r14
  40c11a:	pop    r13
  40c11c:	pop    r12
  40c11e:	pop    rdi
  40c11f:	pop    rsi
  40c120:	ret
  40c121:	xor    ecx,ecx
  40c123:	tzcnt  rcx,rax
  40c128:	lea    r12,[rsp+0x8]
  40c12d:	mov    DWORD PTR [rsp+0x8],ecx
  40c131:	mov    r13d,0x1
  40c137:	shl    r13,cl
  40c13a:	mov    rcx,rdx
  40c13d:	or     rcx,r13
  40c140:	mov    rax,rdx
  40c143:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40c149:	cmp    rax,rdx
  40c14c:	je     40c153 <__swc_fn_4fa09e82_000013_7b85dbab+0x73>
  40c14e:	mov    rdx,rax
  40c151:	jmp    40c100 <__swc_fn_4fa09e82_000013_7b85dbab+0x20>
  40c153:	mov    eax,DWORD PTR [r12]
  40c157:	shl    rax,0x4
  40c15b:	lea    r14,[rsi+rax*8+0x80]
  40c163:	mov    rcx,rsi
  40c166:	mov    rax,r12
  40c169:	mov    edx,DWORD PTR [rax]
  40c16b:	call   40f3a0 <__swc_fn_4fa09e82_000011_71c91685>
  40c170:	mov    r15,rax
  40c173:	mov    rcx,rsi
  40c176:	mov    rdx,r13
  40c179:	call   40f500 <__swc_fn_4fa09e82_000017_f003fc47>
  40c17e:	test   al,al
  40c180:	je     40c1b8 <__swc_fn_4fa09e82_000013_7b85dbab+0xd8>
  40c182:	mov    ecx,DWORD PTR [r14+0x3c]
  40c186:	lea    rdx,[rip+0x17ecb]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40c18d:	mov    r8,QWORD PTR [rip+0x17ec4]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40c194:	cs nop WORD PTR [rax+rax*1+0x0]
  40c19e:	xchg   ax,ax
  40c1a0:	mov    r9,r8
  40c1a3:	sub    r9,rcx
  40c1a6:	mov    rax,r8
  40c1a9:	lock cmpxchg QWORD PTR [rdx],r9
  40c1ae:	cmp    rax,r8
  40c1b1:	je     40c219 <__swc_fn_4fa09e82_000013_7b85dbab+0x139>
  40c1b3:	mov    r8,rax
  40c1b6:	jmp    40c1a0 <__swc_fn_4fa09e82_000013_7b85dbab+0xc0>
  40c1b8:	mov    rcx,rsi
  40c1bb:	mov    rax,r12
  40c1be:	mov    edx,DWORD PTR [rax]
  40c1c0:	call   407450 <__swc_fn_4fa09e82_000012_be38a1a2>
  40c1c5:	mov    rcx,r15
  40c1c8:	and    rcx,0xffffffffffff0000
  40c1cf:	lea    rcx,[rcx+0x10000]
  40c1d6:	mov    rbx,rax
  40c1d9:	cmp    rax,rcx
  40c1dc:	cmova  rbx,rcx
  40c1e0:	mov    rax,rbx
  40c1e3:	sub    rax,r15
  40c1e6:	mov    rcx,r15
  40c1e9:	mov    rdx,rax
  40c1ec:	call   4072a0 <__swc_fn_4fa09e82_000003_81215399>
  40c1f1:	test   al,al
  40c1f3:	jne    40c212 <__swc_fn_4fa09e82_000013_7b85dbab+0x132>
  40c1f5:	mov    rcx,rsi
  40c1f8:	mov    rdx,r13
  40c1fb:	call   407600 <__swc_fn_4fa09e82_000018_77ece227>
  40c200:	xor    eax,eax
  40c202:	add    rsp,0x30
  40c206:	pop    rbx
  40c207:	pop    r15
  40c209:	pop    r14
  40c20b:	pop    r13
  40c20d:	pop    r12
  40c20f:	pop    rdi
  40c210:	pop    rsi
  40c211:	ret
  40c212:	sub    rbx,r15
  40c215:	mov    DWORD PTR [r14+0x3c],ebx
  40c219:	mov    rcx,r14
  40c21c:	mov    rdx,rsi
  40c21f:	mov    r8d,DWORD PTR [r12]
  40c223:	mov    r9d,edi
  40c226:	mov    rbx,QWORD PTR [rsp+0x18]
  40c22b:	mov    r10d,ebx
  40c22e:	call   40bf80 <__swc_fn_4fa09e82_000004_3deb8b54>
  40c233:	mov    rax,r14
  40c236:	add    rsp,0x30
  40c23a:	pop    rbx
  40c23b:	pop    r15
  40c23d:	pop    r14
  40c23f:	pop    r13
  40c241:	pop    r12
  40c243:	pop    rdi
  40c244:	pop    rsi
  40c245:	ret
	...

000000000040c250 <__swc_fn_4fa09e82_000016_a0b588d0>:
  40c250:	mov    r8,QWORD PTR [rcx+0x48]
  40c254:	cs nop WORD PTR [rax+rax*1+0x0]
  40c25e:	xchg   ax,ax
  40c260:	mov    r9,r8
  40c263:	or     r9,rdx
  40c266:	mov    rax,r8
  40c269:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40c26f:	cmp    rax,r8
  40c272:	jne    40c275 <__swc_fn_4fa09e82_000016_a0b588d0+0x25>
  40c274:	ret
  40c275:	mov    r8,rax
  40c278:	jmp    40c260 <__swc_fn_4fa09e82_000016_a0b588d0+0x10>
  40c27a:	add    BYTE PTR [rax],al
  40c27c:	add    BYTE PTR [rax],al
	...

000000000040c280 <__swc_fn_4fa09e82_000019_447bb610>:
  40c280:	push   rsi
  40c281:	push   rdi
  40c282:	push   r12
  40c284:	mov    rsi,rcx
  40c287:	xor    edi,edi
  40c289:	lea    r12,[rip+0x17dd8]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40c290:	mov    eax,DWORD PTR [r12]
  40c294:	xor    ecx,ecx
  40c296:	test   rax,rax
  40c299:	jbe    40c2d4 <__swc_fn_4fa09e82_000019_447bb610+0x54>
  40c29b:	nop    DWORD PTR [rax+rax*1+0x0]
  40c2a0:	lea    rdx,[rip+0x17dc9]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  40c2a7:	mov    r8d,ecx
  40c2aa:	lea    r8,[r8+r8*2]
  40c2ae:	lea    r8,[rdx+r8*8]
  40c2b2:	mov    rdx,QWORD PTR [r8+0x10]
  40c2b6:	add    rdx,0x400000
  40c2bd:	cmp    rdx,0x40000000
  40c2c4:	ja     40c2cb <__swc_fn_4fa09e82_000019_447bb610+0x4b>
  40c2c6:	mov    rdi,r8
  40c2c9:	jmp    40c2d4 <__swc_fn_4fa09e82_000019_447bb610+0x54>
  40c2cb:	add    rcx,0x1
  40c2cf:	cmp    rcx,rax
  40c2d2:	jb     40c2a0 <__swc_fn_4fa09e82_000019_447bb610+0x20>
  40c2d4:	test   rdi,rdi
  40c2d7:	jne    40c363 <__swc_fn_4fa09e82_000019_447bb610+0xe3>
  40c2dd:	cmp    DWORD PTR [r12],0x10
  40c2e2:	jae    40c34b <__swc_fn_4fa09e82_000019_447bb610+0xcb>
  40c2e4:	mov    ecx,0x40400000
  40c2e9:	call   40f2c0 <__swc_fn_4fa09e82_000002_102336c4>
  40c2ee:	test   rax,rax
  40c2f1:	je     40c34b <__swc_fn_4fa09e82_000019_447bb610+0xcb>
  40c2f3:	lea    rcx,[rip+0x17d76]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  40c2fa:	mov    edx,DWORD PTR [r12]
  40c2fe:	lea    rdx,[rdx+rdx*2]
  40c302:	lea    rdx,[rcx+rdx*8]
  40c306:	mov    QWORD PTR [rdx],rax
  40c309:	lea    rax,[rax+0x3fffff]
  40c310:	and    rax,0xffffffffffc00000
  40c317:	mov    QWORD PTR [rdx+0x8],rax
  40c31b:	mov    QWORD PTR [rdx+0x10],0x0
  40c323:	mov    edx,DWORD PTR [rip+0x17d3f]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40c329:	nop    DWORD PTR [rax+0x0]
  40c330:	lea    r9d,[rdx+0x1]
  40c334:	mov    rax,rdx
  40c337:	lock cmpxchg DWORD PTR [r12],r9d
  40c33d:	mov    r8d,eax
  40c340:	cmp    eax,edx
  40c342:	je     40c352 <__swc_fn_4fa09e82_000019_447bb610+0xd2>
  40c344:	mov    rdx,r8
  40c347:	jmp    40c330 <__swc_fn_4fa09e82_000019_447bb610+0xb0>
  40c349:	jmp    40c352 <__swc_fn_4fa09e82_000019_447bb610+0xd2>
  40c34b:	xor    eax,eax
  40c34d:	pop    r12
  40c34f:	pop    rdi
  40c350:	pop    rsi
  40c351:	ret
  40c352:	mov    eax,DWORD PTR [rip+0x17d10]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40c358:	sub    eax,0x1
  40c35b:	lea    rdi,[rax+rax*2]
  40c35f:	lea    rdi,[rcx+rdi*8]
  40c363:	mov    r12,QWORD PTR [rdi+0x8]
  40c367:	add    r12,QWORD PTR [rdi+0x10]
  40c36b:	mov    rcx,r12
  40c36e:	mov    edx,0x3000
  40c373:	call   4072a0 <__swc_fn_4fa09e82_000003_81215399>
  40c378:	test   al,al
  40c37a:	jne    40c383 <__swc_fn_4fa09e82_000019_447bb610+0x103>
  40c37c:	xor    eax,eax
  40c37e:	pop    r12
  40c380:	pop    rdi
  40c381:	pop    rsi
  40c382:	ret
  40c383:	vxorps xmm0,xmm0,xmm0
  40c387:	xor    eax,eax
  40c389:	cs nop WORD PTR [rax+rax*1+0x0]
  40c393:	cs nop WORD PTR [rax+rax*1+0x0]
  40c39d:	nop    DWORD PTR [rax]
  40c3a0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40c3a6:	add    rax,0x10
  40c3aa:	cmp    rax,0x3000
  40c3b1:	jne    40c3a0 <__swc_fn_4fa09e82_000019_447bb610+0x120>
  40c3b3:	mov    DWORD PTR [r12+0x28],esi
  40c3b8:	mov    eax,0x40
  40c3bd:	mov    ecx,esi
  40c3bf:	shr    eax,cl
  40c3c1:	mov    DWORD PTR [r12+0x2c],eax
  40c3c6:	cmp    DWORD PTR [r12+0x2c],0x40
  40c3cc:	jb     40c3d7 <__swc_fn_4fa09e82_000019_447bb610+0x157>
  40c3ce:	mov    rax,0xffffffffffffffff
  40c3d5:	jmp    40c3e7 <__swc_fn_4fa09e82_000019_447bb610+0x167>
  40c3d7:	mov    eax,0x1
  40c3dc:	mov    ecx,DWORD PTR [r12+0x2c]
  40c3e1:	shl    rax,cl
  40c3e4:	dec    rax
  40c3e7:	mov    QWORD PTR [r12+0x20],rax
  40c3ec:	mov    DWORD PTR [r12],0x4e540001
  40c3f4:	mov    DWORD PTR [r12+0x4],0x53474d45
  40c3fd:	add    QWORD PTR [rdi+0x10],0x400000
  40c405:	mov    rax,r12
  40c408:	pop    r12
  40c40a:	pop    rdi
  40c40b:	pop    rsi
  40c40c:	ret
  40c40d:	add    BYTE PTR [rax],al
	...

000000000040c410 <__swc_fn_4fa09e82_000022_53fc00d2>:
  40c410:	mov    eax,0x1
  40c415:	mov    edx,DWORD PTR [rip+0x17c4d]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40c41b:	cmp    eax,edx
  40c41d:	jae    40c46b <__swc_fn_4fa09e82_000022_53fc00d2+0x5b>
  40c41f:	nop
  40c420:	lea    r8,[rip+0x17c49]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  40c427:	lea    r9,[rax+rax*2]
  40c42b:	lea    r9,[r8+r9*8]
  40c42f:	mov    r8,rcx
  40c432:	sub    r8,QWORD PTR [r9+0x8]
  40c436:	mov    r9,QWORD PTR [r9+0x10]
  40c43a:	cmp    r8,r9
  40c43d:	jae    40c465 <__swc_fn_4fa09e82_000022_53fc00d2+0x55>
  40c43f:	mov    rax,rcx
  40c442:	and    rax,0xffffffffffc00000
  40c449:	shr    rcx,0x10
  40c44d:	and    ecx,0x3f
  40c450:	mov    edx,DWORD PTR [rax+0x28]
  40c453:	shrx   ecx,ecx,edx
  40c458:	shl    rcx,0x4
  40c45c:	lea    rax,[rax+rcx*8+0x80]
  40c464:	ret
  40c465:	inc    eax
  40c467:	cmp    eax,edx
  40c469:	jb     40c420 <__swc_fn_4fa09e82_000022_53fc00d2+0x10>
  40c46b:	xor    eax,eax
  40c46d:	ret
	...

000000000040c470 <__swc_fn_4fa09e82_000025_e876734d>:
  40c470:	vxorps xmm0,xmm0,xmm0
  40c474:	vmovups XMMWORD PTR [rcx],xmm0
  40c478:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40c47d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40c482:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40c487:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40c48c:	mov    QWORD PTR [rcx+0x50],0x0
  40c494:	ret
	...

000000000040c4a0 <__swc_fn_4fa09e82_000028_e876734d>:
  40c4a0:	vxorps xmm0,xmm0,xmm0
  40c4a4:	xor    eax,eax
  40c4a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40c4b0:	cs nop WORD PTR [rax+rax*1+0x0]
  40c4ba:	nop    WORD PTR [rax+rax*1+0x0]
  40c4c0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40c4c5:	add    rax,0x10
  40c4c9:	cmp    rax,0x9b0
  40c4d0:	jne    40c4c0 <__swc_fn_4fa09e82_000028_e876734d+0x20>
  40c4d2:	mov    QWORD PTR [rcx+0x9b0],0x0
  40c4dd:	ret
	...

000000000040c4e0 <__swc_fn_4fa09e82_000031_3c3e930e>:
  40c4e0:	push   rsi
  40c4e1:	push   rdi
  40c4e2:	sub    rsp,0x8
  40c4e6:	lea    rsi,[rip+0x15b1b]        # 422008 <__swc_data_base_4fa09e82+0x8>
  40c4ed:	mov    rax,QWORD PTR [rsi]
  40c4f0:	mov    ecx,0xffffffff
  40c4f5:	cmp    rax,rcx
  40c4f8:	je     40c501 <__swc_fn_4fa09e82_000031_3c3e930e+0x21>
  40c4fa:	add    rsp,0x8
  40c4fe:	pop    rdi
  40c4ff:	pop    rsi
  40c500:	ret
  40c501:	mov    rcx,QWORD PTR [rip+0x6bb0]        # 4130b8 <__swc_fn_4fa09e82_000179_6937fe70+0xfe8>
  40c508:	call   40e4d0 <__swc_fn_4fa09e82_000127_9e9697c7>
  40c50d:	mov    rcx,rax
  40c510:	mov    eax,0xffffffff
  40c515:	lock cmpxchg QWORD PTR [rsi],rcx
  40c51a:	mov    rdi,rax
  40c51d:	mov    eax,0xffffffff
  40c522:	cmp    rdi,rax
  40c525:	je     40c536 <__swc_fn_4fa09e82_000031_3c3e930e+0x56>
  40c527:	call   411630 <__swc_fn_4fa09e82_000128_f163135d>
  40c52c:	mov    rax,rdi
  40c52f:	add    rsp,0x8
  40c533:	pop    rdi
  40c534:	pop    rsi
  40c535:	ret
  40c536:	mov    rax,rcx
  40c539:	add    rsp,0x8
  40c53d:	pop    rdi
  40c53e:	pop    rsi
  40c53f:	ret

000000000040c540 <__swc_fn_4fa09e82_000034_cf5ba7bd>:
  40c540:	sub    rsp,0x8
  40c544:	vxorps xmm0,xmm0,xmm0
  40c548:	xor    eax,eax
  40c54a:	cs nop WORD PTR [rax+rax*1+0x0]
  40c554:	cs nop WORD PTR [rax+rax*1+0x0]
  40c55e:	xchg   ax,ax
  40c560:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40c565:	add    rax,0x10
  40c569:	cmp    rax,0x2b00
  40c570:	jne    40c560 <__swc_fn_4fa09e82_000034_cf5ba7bd+0x20>
  40c572:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40c57c:	xor    al,al
  40c57e:	mov    rdx,rax
  40c581:	xor    al,al
  40c583:	mov    r8,rax
  40c586:	xor    al,al
  40c588:	mov    r9,rax
  40c58b:	xor    al,al
  40c58d:	mov    r10,rax
  40c590:	xor    al,al
  40c592:	mov    r11,rax
  40c595:	call   40f730 <__swc_fn_4fa09e82_000035_ab2e8c35>
  40c59a:	add    rsp,0x8
  40c59e:	ret
	...

000000000040c5a0 <__swc_fn_4fa09e82_000037_1e381f55>:
  40c5a0:	push   rsi
  40c5a1:	push   rdi
  40c5a2:	push   r12
  40c5a4:	mov    rsi,r8
  40c5a7:	mov    rdi,rdx
  40c5aa:	mov    rcx,rdx
  40c5ad:	call   40f2c0 <__swc_fn_4fa09e82_000002_102336c4>
  40c5b2:	mov    r12,rax
  40c5b5:	test   rax,rax
  40c5b8:	jne    40c5c1 <__swc_fn_4fa09e82_000037_1e381f55+0x21>
  40c5ba:	xor    eax,eax
  40c5bc:	pop    r12
  40c5be:	pop    rdi
  40c5bf:	pop    rsi
  40c5c0:	ret
  40c5c1:	mov    rcx,r12
  40c5c4:	mov    rdx,rsi
  40c5c7:	call   4072a0 <__swc_fn_4fa09e82_000003_81215399>
  40c5cc:	test   al,al
  40c5ce:	jne    40c5e2 <__swc_fn_4fa09e82_000037_1e381f55+0x42>
  40c5d0:	mov    rcx,r12
  40c5d3:	mov    rdx,rdi
  40c5d6:	call   409850 <__swc_fn_4fa09e82_000114_4e83a03a>
  40c5db:	xor    eax,eax
  40c5dd:	pop    r12
  40c5df:	pop    rdi
  40c5e0:	pop    rsi
  40c5e1:	ret
  40c5e2:	mov    rax,r12
  40c5e5:	pop    r12
  40c5e7:	pop    rdi
  40c5e8:	pop    rsi
  40c5e9:	ret
	...

000000000040c600 <__swc_fn_4fa09e82_000040_8029566e>:
  40c600:	push   rsi
  40c601:	push   rdi
  40c602:	push   r12
  40c604:	mov    rsi,rcx
  40c607:	mov    edx,0x9b8
  40c60c:	call   40f7a0 <__swc_fn_4fa09e82_000038_292d55e5>
  40c611:	mov    rdi,rax
  40c614:	test   rax,rax
  40c617:	jne    40c620 <__swc_fn_4fa09e82_000040_8029566e+0x20>
  40c619:	xor    eax,eax
  40c61b:	pop    r12
  40c61d:	pop    rdi
  40c61e:	pop    rsi
  40c61f:	ret
  40c620:	vxorps xmm0,xmm0,xmm0
  40c624:	xor    eax,eax
  40c626:	cs nop WORD PTR [rax+rax*1+0x0]
  40c630:	cs nop WORD PTR [rax+rax*1+0x0]
  40c63a:	nop    WORD PTR [rax+rax*1+0x0]
  40c640:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40c645:	add    rax,0x10
  40c649:	cmp    rax,0x9b0
  40c650:	jne    40c640 <__swc_fn_4fa09e82_000040_8029566e+0x40>
  40c652:	mov    QWORD PTR [rdi+0x9b0],0x0
  40c65d:	mov    QWORD PTR [rdi],rsi
  40c660:	call   4116e0 <__swc_fn_4fa09e82_000131_375c7357>
  40c665:	mov    QWORD PTR [rdi+0x18],rax
  40c669:	lea    r12,[rsi+0x10]
  40c66d:	mov    rcx,r12
  40c670:	call   40e720 <__swc_fn_4fa09e82_000136_db32cc57>
  40c675:	mov    rax,QWORD PTR [rsi+0x20]
  40c679:	mov    QWORD PTR [rdi+0x8],rax
  40c67d:	mov    rax,QWORD PTR [rsi+0x20]
  40c681:	test   rax,rax
  40c684:	je     40c68a <__swc_fn_4fa09e82_000040_8029566e+0x8a>
  40c686:	mov    QWORD PTR [rax+0x10],rdi
  40c68a:	mov    QWORD PTR [rsi+0x20],rdi
  40c68e:	mov    rcx,r12
  40c691:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40c696:	mov    rax,rdi
  40c699:	pop    r12
  40c69b:	pop    rdi
  40c69c:	pop    rsi
  40c69d:	ret
	...

000000000040c6a0 <__swc_fn_4fa09e82_000043_47ff6d9b>:
  40c6a0:	mov    rax,QWORD PTR [rdx+0x10]
  40c6a4:	test   rax,rax
  40c6a7:	je     40c6b3 <__swc_fn_4fa09e82_000043_47ff6d9b+0x13>
  40c6a9:	mov    rcx,QWORD PTR [rdx+0x8]
  40c6ad:	mov    QWORD PTR [rax+0x8],rcx
  40c6b1:	jmp    40c6bb <__swc_fn_4fa09e82_000043_47ff6d9b+0x1b>
  40c6b3:	mov    rax,QWORD PTR [rdx+0x8]
  40c6b7:	mov    QWORD PTR [rcx+0x20],rax
  40c6bb:	mov    rax,QWORD PTR [rdx+0x8]
  40c6bf:	test   rax,rax
  40c6c2:	je     40c6cc <__swc_fn_4fa09e82_000043_47ff6d9b+0x2c>
  40c6c4:	mov    rcx,QWORD PTR [rdx+0x10]
  40c6c8:	mov    QWORD PTR [rax+0x10],rcx
  40c6cc:	vxorps xmm0,xmm0,xmm0
  40c6d0:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40c6d5:	ret
	...

000000000040c6e0 <__swc_fn_4fa09e82_000046_b28a6ee7>:
  40c6e0:	sub    rsp,0x8
  40c6e4:	mov    r9,r8
  40c6e7:	mov    r10,rdx
  40c6ea:	call   40f850 <__swc_fn_4fa09e82_000044_fe6bbfdb>
  40c6ef:	mov    eax,0x1
  40c6f4:	xchg   DWORD PTR [r9+0x6c],eax
  40c6f8:	mov    rax,QWORD PTR [r9+0x60]
  40c6fc:	test   rax,rax
  40c6ff:	je     40c743 <__swc_fn_4fa09e82_000046_b28a6ee7+0x63>
  40c701:	xor    eax,eax
  40c703:	xchg   DWORD PTR [r9+0x6c],eax
  40c707:	movzx  eax,BYTE PTR [r9+0x39]
  40c70c:	lea    rax,[rax+rax*4]
  40c710:	lea    rax,[r10+rax*8+0x28]
  40c715:	mov    QWORD PTR [r9+0x50],0x0
  40c71d:	mov    rcx,QWORD PTR [rax+0x8]
  40c721:	mov    QWORD PTR [r9+0x48],rcx
  40c725:	mov    rcx,QWORD PTR [rax+0x8]
  40c729:	test   rcx,rcx
  40c72c:	je     40c734 <__swc_fn_4fa09e82_000046_b28a6ee7+0x54>
  40c72e:	mov    QWORD PTR [rcx+0x50],r9
  40c732:	jmp    40c738 <__swc_fn_4fa09e82_000046_b28a6ee7+0x58>
  40c734:	mov    QWORD PTR [rax+0x10],r9
  40c738:	mov    QWORD PTR [rax+0x8],r9
  40c73c:	xor    eax,eax
  40c73e:	add    rsp,0x8
  40c742:	ret
  40c743:	movzx  eax,BYTE PTR [r9+0x39]
  40c748:	lea    rax,[rax+rax*4]
  40c74c:	lea    rax,[r10+rax*8+0x28]
  40c751:	mov    QWORD PTR [r9+0x50],0x0
  40c759:	mov    rcx,QWORD PTR [rax+0x18]
  40c75d:	mov    QWORD PTR [r9+0x48],rcx
  40c761:	mov    rcx,QWORD PTR [rax+0x18]
  40c765:	test   rcx,rcx
  40c768:	je     40c76e <__swc_fn_4fa09e82_000046_b28a6ee7+0x8e>
  40c76a:	mov    QWORD PTR [rcx+0x50],r9
  40c76e:	mov    QWORD PTR [rax+0x18],r9
  40c772:	mov    eax,0x1
  40c777:	add    rsp,0x8
  40c77b:	ret
  40c77c:	add    BYTE PTR [rax],al
	...

000000000040c780 <__swc_fn_4fa09e82_000049_f6a485a2>:
  40c780:	push   r12
  40c782:	push   r13
  40c784:	push   rdi
  40c785:	push   rsi
  40c786:	push   r14
  40c788:	push   r15
  40c78a:	sub    rsp,0x178
  40c791:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40c79a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40c7a3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40c7ac:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40c7b5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40c7be:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40c7c7:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40c7d0:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40c7d9:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40c7e2:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40c7eb:	mov    r12,rcx
  40c7ee:	lea    rax,[rip+0x17a0b]        # 424200 <__swc_bss_base_4fa09e82+0x1c0>
  40c7f5:	mov    rcx,QWORD PTR [rax]
  40c7f8:	mov    r13,rcx
  40c7fb:	test   rcx,rcx
  40c7fe:	jne    40c80e <__swc_fn_4fa09e82_000049_f6a485a2+0x8e>
  40c800:	mov    r13d,0x1dcd6500
  40c806:	mov    ecx,0x1dcd6500
  40c80b:	xchg   QWORD PTR [rax],rcx
  40c80e:	lea    rax,[rip+0x157eb]        # 422000 <__swc_data_base_4fa09e82>
  40c815:	mov    rax,QWORD PTR [rax]
  40c818:	cmp    rax,0xffffffffffffffff
  40c81c:	je     40c82b <__swc_fn_4fa09e82_000049_f6a485a2+0xab>
  40c81e:	mov    eax,eax
  40c820:	mov    edi,eax
  40c822:	xor    eax,eax
  40c824:	call   407000 <pthread_getspecific@plt>
  40c829:	jmp    40c82d <__swc_fn_4fa09e82_000049_f6a485a2+0xad>
  40c82b:	xor    eax,eax
  40c82d:	test   rax,rax
  40c830:	jne    40c83f <__swc_fn_4fa09e82_000049_f6a485a2+0xbf>
  40c832:	call   40c4e0 <__swc_fn_4fa09e82_000031_3c3e930e>
  40c837:	mov    rcx,rax
  40c83a:	call   409ba0 <__swc_fn_4fa09e82_000129_8d8a7dd2>
  40c83f:	test   rax,rax
  40c842:	je     40c854 <__swc_fn_4fa09e82_000049_f6a485a2+0xd4>
  40c844:	cmp    QWORD PTR [rax],r12
  40c847:	jne    40c854 <__swc_fn_4fa09e82_000049_f6a485a2+0xd4>
  40c849:	cmp    DWORD PTR [rax+0x20],0x0
  40c84d:	jne    40c854 <__swc_fn_4fa09e82_000049_f6a485a2+0xd4>
  40c84f:	mov    rsi,rax
  40c852:	jmp    40c856 <__swc_fn_4fa09e82_000049_f6a485a2+0xd6>
  40c854:	xor    esi,esi
  40c856:	lea    rdi,[r12+0x2a88]
  40c85e:	mov    r14,QWORD PTR [rdi]
  40c861:	test   r14,r14
  40c864:	jne    40c8b3 <__swc_fn_4fa09e82_000049_f6a485a2+0x133>
  40c866:	lea    rax,[rip+0x177eb]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40c86d:	mov    rax,QWORD PTR [rax]
  40c870:	test   rax,rax
  40c873:	setne  al
  40c876:	jne    40c89a <__swc_fn_4fa09e82_000049_f6a485a2+0x11a>
  40c878:	mov    rax,QWORD PTR [r12+0x2a70]
  40c880:	test   rax,rax
  40c883:	setne  al
  40c886:	jne    40c89a <__swc_fn_4fa09e82_000049_f6a485a2+0x11a>
  40c888:	test   rsi,rsi
  40c88b:	setne  al
  40c88e:	je     40c89a <__swc_fn_4fa09e82_000049_f6a485a2+0x11a>
  40c890:	cmp    DWORD PTR [rsi+0x730],0x0
  40c897:	setne  al
  40c89a:	test   al,al
  40c89c:	je     40c8ae <__swc_fn_4fa09e82_000049_f6a485a2+0x12e>
  40c89e:	call   409c50 <__swc_fn_4fa09e82_000132_91db8856>
  40c8a3:	lea    rcx,[rax+r13*1]
  40c8a7:	xor    eax,eax
  40c8a9:	lock cmpxchg QWORD PTR [rdi],rcx
  40c8ae:	jmp    40c9b3 <__swc_fn_4fa09e82_000049_f6a485a2+0x233>
  40c8b3:	call   409c50 <__swc_fn_4fa09e82_000132_91db8856>
  40c8b8:	mov    r15,rax
  40c8bb:	cmp    rax,r14
  40c8be:	jb     40c8cf <__swc_fn_4fa09e82_000049_f6a485a2+0x14f>
  40c8c0:	xor    ecx,ecx
  40c8c2:	mov    rax,r14
  40c8c5:	lock cmpxchg QWORD PTR [rdi],rcx
  40c8ca:	cmp    rax,r14
  40c8cd:	je     40c8d4 <__swc_fn_4fa09e82_000049_f6a485a2+0x154>
  40c8cf:	jmp    40c9b3 <__swc_fn_4fa09e82_000049_f6a485a2+0x233>
  40c8d4:	test   rsi,rsi
  40c8d7:	je     40c8f2 <__swc_fn_4fa09e82_000049_f6a485a2+0x172>
  40c8d9:	cmp    r15,r13
  40c8dc:	jb     40c8f2 <__swc_fn_4fa09e82_000049_f6a485a2+0x172>
  40c8de:	mov    rax,r15
  40c8e1:	sub    rax,r13
  40c8e4:	mov    rcx,r12
  40c8e7:	mov    rdx,rsi
  40c8ea:	mov    r8,rax
  40c8ed:	call   40fc90 <__swc_fn_4fa09e82_000059_ee6a254c>
  40c8f2:	lea    rsi,[r12+0x10]
  40c8f7:	mov    rcx,rsi
  40c8fa:	call   40e720 <__swc_fn_4fa09e82_000136_db32cc57>
  40c8ff:	mov    rax,QWORD PTR [r12+0x18]
  40c904:	mov    rdi,rax
  40c907:	test   rdi,rdi
  40c90a:	je     40c934 <__swc_fn_4fa09e82_000049_f6a485a2+0x1b4>
  40c90c:	cs nop WORD PTR [rax+rax*1+0x0]
  40c916:	cs nop WORD PTR [rax+rax*1+0x0]
  40c920:	mov    rcx,rdi
  40c923:	call   407470 <__swc_fn_4fa09e82_000015_96cb1311>
  40c928:	mov    rax,QWORD PTR [rdi+0x10]
  40c92c:	mov    rdi,rax
  40c92f:	test   rax,rax
  40c932:	jne    40c920 <__swc_fn_4fa09e82_000049_f6a485a2+0x1a0>
  40c934:	mov    rcx,rsi
  40c937:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40c93c:	mov    rcx,r12
  40c93f:	call   40e720 <__swc_fn_4fa09e82_000136_db32cc57>
  40c944:	xor    esi,esi
  40c946:	cs nop WORD PTR [rax+rax*1+0x0]
  40c950:	mov    rax,QWORD PTR [r12+0x2a70]
  40c958:	cmp    rsi,rax
  40c95b:	jae    40c9ab <__swc_fn_4fa09e82_000049_f6a485a2+0x22b>
  40c95d:	lea    rax,[rsi+rsi*4]
  40c961:	lea    rax,[r12+rax*8+0x268]
  40c969:	mov    r8,QWORD PTR [rax]
  40c96c:	mov    r9,QWORD PTR [rax+0x8]
  40c970:	mov    r10,QWORD PTR [rax+0x10]
  40c974:	mov    rax,QWORD PTR [rax+0x20]
  40c978:	cmp    rax,r15
  40c97b:	jae    40c988 <__swc_fn_4fa09e82_000049_f6a485a2+0x208>
  40c97d:	mov    rcx,r15
  40c980:	sub    rcx,rax
  40c983:	cmp    rcx,r13
  40c986:	jae    40c98d <__swc_fn_4fa09e82_000049_f6a485a2+0x20d>
  40c988:	inc    rsi
  40c98b:	jmp    40c950 <__swc_fn_4fa09e82_000049_f6a485a2+0x1d0>
  40c98d:	mov    rcx,r12
  40c990:	mov    rdx,rsi
  40c993:	call   40fc40 <__swc_fn_4fa09e82_000056_87dc216f>
  40c998:	mov    rcx,r12
  40c99b:	mov    rdx,r8
  40c99e:	mov    r8,r9
  40c9a1:	mov    r9,r10
  40c9a4:	call   407750 <__swc_fn_4fa09e82_000039_9ae4348f>
  40c9a9:	jmp    40c950 <__swc_fn_4fa09e82_000049_f6a485a2+0x1d0>
  40c9ab:	mov    rcx,r12
  40c9ae:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40c9b3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40c9bc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40c9c5:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40c9ce:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40c9d7:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40c9e0:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40c9e9:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40c9f2:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40c9fb:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40ca04:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40ca0d:	add    rsp,0x178
  40ca14:	pop    r15
  40ca16:	pop    r14
  40ca18:	pop    rsi
  40ca19:	pop    rdi
  40ca1a:	pop    r13
  40ca1c:	pop    r12
  40ca1e:	ret
	...

000000000040ca20 <__swc_fn_4fa09e82_000052_92b016ae>:
  40ca20:	lea    rax,[rdx-0x58]
  40ca24:	ret
	...

000000000040ca30 <__swc_fn_4fa09e82_000055_ddf32775>:
  40ca30:	push   rsi
  40ca31:	push   rdi
  40ca32:	push   r12
  40ca34:	push   r13
  40ca36:	sub    rsp,0x68
  40ca3a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40ca40:	mov    rsi,r9
  40ca43:	mov    rdi,rcx
  40ca46:	mov    r12,rdx
  40ca49:	mov    r13,r8
  40ca4c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40ca54:	jne    40ca63 <__swc_fn_4fa09e82_000055_ddf32775+0x33>
  40ca56:	xor    eax,eax
  40ca58:	add    rsp,0x68
  40ca5c:	pop    r13
  40ca5e:	pop    r12
  40ca60:	pop    rdi
  40ca61:	pop    rsi
  40ca62:	ret
  40ca63:	mov    rcx,rdi
  40ca66:	call   40e720 <__swc_fn_4fa09e82_000136_db32cc57>
  40ca6b:	movabs rax,0x7fffffffffffffff
  40ca75:	cmp    r12,rax
  40ca78:	mov    rax,0xffffffffffffffff
  40ca7f:	lea    rcx,[r12+r12*1]
  40ca83:	cmovbe rax,rcx
  40ca87:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40ca8e:	mov    rdx,rcx
  40ca91:	sub    rax,r12
  40ca94:	inc    rax
  40ca97:	xor    r8d,r8d
  40ca9a:	test   rcx,rcx
  40ca9d:	jbe    40cac8 <__swc_fn_4fa09e82_000055_ddf32775+0x98>
  40ca9f:	nop
  40caa0:	lea    r9,[r8+r8*4]
  40caa4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40caac:	sub    r9,r12
  40caaf:	cmp    r9,rax
  40cab2:	jae    40cabf <__swc_fn_4fa09e82_000055_ddf32775+0x8f>
  40cab4:	mov    rdx,r8
  40cab7:	mov    rax,r9
  40caba:	test   r9,r9
  40cabd:	je     40cac8 <__swc_fn_4fa09e82_000055_ddf32775+0x98>
  40cabf:	add    r8,0x1
  40cac3:	cmp    r8,rcx
  40cac6:	jb     40caa0 <__swc_fn_4fa09e82_000055_ddf32775+0x70>
  40cac8:	mov    rax,QWORD PTR [rdi+0x2a70]
  40cacf:	cmp    rdx,rax
  40cad2:	jne    40caef <__swc_fn_4fa09e82_000055_ddf32775+0xbf>
  40cad4:	mov    rcx,rdi
  40cad7:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40cadc:	xor    eax,eax
  40cade:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40cae4:	add    rsp,0x68
  40cae8:	pop    r13
  40caea:	pop    r12
  40caec:	pop    rdi
  40caed:	pop    rsi
  40caee:	ret
  40caef:	lea    rax,[rdx+rdx*4]
  40caf3:	lea    rax,[rdi+rax*8+0x268]
  40cafb:	vmovups xmm6,XMMWORD PTR [rax]
  40caff:	mov    r8,QWORD PTR [rax+0x10]
  40cb03:	mov    rcx,rdi
  40cb06:	call   40fc40 <__swc_fn_4fa09e82_000056_87dc216f>
  40cb0b:	vpshufd xmm0,xmm6,0xee
  40cb10:	vmovsd QWORD PTR [r13+0x0],xmm0
  40cb16:	mov    QWORD PTR [rsi],r8
  40cb19:	mov    rcx,rdi
  40cb1c:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40cb21:	vmovq  rax,xmm6
  40cb26:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40cb2c:	add    rsp,0x68
  40cb30:	pop    r13
  40cb32:	pop    r12
  40cb34:	pop    rdi
  40cb35:	pop    rsi
  40cb36:	ret
	...

000000000040cb40 <__swc_fn_4fa09e82_000058_01964a17>:
  40cb40:	push   r12
  40cb42:	push   r13
  40cb44:	push   r14
  40cb46:	push   r15
  40cb48:	push   rdi
  40cb49:	push   rsi
  40cb4a:	sub    rsp,0x148
  40cb51:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40cb5a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40cb63:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40cb6c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40cb75:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40cb7e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40cb87:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40cb90:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40cb99:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40cba2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40cbab:	mov    r12,r9
  40cbae:	mov    r13,rcx
  40cbb1:	mov    r14,rdx
  40cbb4:	mov    r15,r8
  40cbb7:	test   rdx,rdx
  40cbba:	jne    40cbce <__swc_fn_4fa09e82_000058_01964a17+0x8e>
  40cbbc:	add    rsp,0x148
  40cbc3:	pop    rsi
  40cbc4:	pop    rdi
  40cbc5:	pop    r15
  40cbc7:	pop    r14
  40cbc9:	pop    r13
  40cbcb:	pop    r12
  40cbcd:	ret
  40cbce:	cmp    r12,0x200000
  40cbd5:	ja     40cc67 <__swc_fn_4fa09e82_000058_01964a17+0x127>
  40cbdb:	lea    rax,[rip+0x1541e]        # 422000 <__swc_data_base_4fa09e82>
  40cbe2:	mov    rax,QWORD PTR [rax]
  40cbe5:	cmp    rax,0xffffffffffffffff
  40cbe9:	je     40cbf8 <__swc_fn_4fa09e82_000058_01964a17+0xb8>
  40cbeb:	mov    eax,eax
  40cbed:	mov    edi,eax
  40cbef:	xor    eax,eax
  40cbf1:	call   407000 <pthread_getspecific@plt>
  40cbf6:	jmp    40cbfa <__swc_fn_4fa09e82_000058_01964a17+0xba>
  40cbf8:	xor    eax,eax
  40cbfa:	test   rax,rax
  40cbfd:	je     40cc04 <__swc_fn_4fa09e82_000058_01964a17+0xc4>
  40cbff:	mov    rsi,rax
  40cc02:	jmp    40cc14 <__swc_fn_4fa09e82_000058_01964a17+0xd4>
  40cc04:	call   40c4e0 <__swc_fn_4fa09e82_000031_3c3e930e>
  40cc09:	mov    rcx,rax
  40cc0c:	call   409ba0 <__swc_fn_4fa09e82_000129_8d8a7dd2>
  40cc11:	mov    rsi,rax
  40cc14:	test   rsi,rsi
  40cc17:	je     40cc67 <__swc_fn_4fa09e82_000058_01964a17+0x127>
  40cc19:	cmp    QWORD PTR [rsi],r13
  40cc1c:	jne    40cc67 <__swc_fn_4fa09e82_000058_01964a17+0x127>
  40cc1e:	cmp    DWORD PTR [rsi+0x20],0x0
  40cc22:	jne    40cc67 <__swc_fn_4fa09e82_000058_01964a17+0x127>
  40cc24:	cmp    DWORD PTR [rsi+0x730],0x10
  40cc2b:	jae    40cc67 <__swc_fn_4fa09e82_000058_01964a17+0x127>
  40cc2d:	mov    eax,DWORD PTR [rsi+0x730]
  40cc33:	lea    rdi,[rax+rax*4]
  40cc37:	lea    rdi,[rsi+rdi*8+0x738]
  40cc3f:	mov    QWORD PTR [rdi],r14
  40cc42:	mov    QWORD PTR [rdi+0x8],r15
  40cc46:	mov    QWORD PTR [rdi+0x10],r12
  40cc4a:	mov    QWORD PTR [rdi+0x18],0x0
  40cc52:	call   409c50 <__swc_fn_4fa09e82_000132_91db8856>
  40cc57:	mov    QWORD PTR [rdi+0x20],rax
  40cc5b:	add    DWORD PTR [rsi+0x730],0x1
  40cc62:	jmp    40cdc6 <__swc_fn_4fa09e82_000058_01964a17+0x286>
  40cc67:	mov    rcx,r13
  40cc6a:	call   407e90 <__swc_fn_4fa09e82_000057_01c75a1d>
  40cc6f:	mov    rsi,rax
  40cc72:	cmp    r12,rax
  40cc75:	jbe    40ccaa <__swc_fn_4fa09e82_000058_01964a17+0x16a>
  40cc77:	cmp    r12,0x10000000
  40cc7e:	seta   al
  40cc81:	ja     40cc90 <__swc_fn_4fa09e82_000058_01964a17+0x150>
  40cc83:	mov    rax,QWORD PTR [r13+0x2a70]
  40cc8a:	test   rax,rax
  40cc8d:	setne  al
  40cc90:	test   al,al
  40cc92:	je     40ccaa <__swc_fn_4fa09e82_000058_01964a17+0x16a>
  40cc94:	mov    rcx,r13
  40cc97:	mov    rdx,r14
  40cc9a:	mov    r8,r15
  40cc9d:	mov    r9,r12
  40cca0:	call   407750 <__swc_fn_4fa09e82_000039_9ae4348f>
  40cca5:	jmp    40cdc6 <__swc_fn_4fa09e82_000058_01964a17+0x286>
  40ccaa:	call   409c50 <__swc_fn_4fa09e82_000132_91db8856>
  40ccaf:	mov    rdi,rax
  40ccb2:	mov    rcx,r13
  40ccb5:	call   40e720 <__swc_fn_4fa09e82_000136_db32cc57>
  40ccba:	cmp    QWORD PTR [r13+0x2a70],0x0
  40ccc2:	je     40cd7a <__swc_fn_4fa09e82_000058_01964a17+0x23a>
  40ccc8:	nop    DWORD PTR [rax+rax*1+0x0]
  40ccd0:	cmp    QWORD PTR [r13+0x2a70],0x100
  40ccdb:	jae    40ccf0 <__swc_fn_4fa09e82_000058_01964a17+0x1b0>
  40ccdd:	mov    rax,QWORD PTR [r13+0x2a68]
  40cce4:	add    rax,r12
  40cce7:	cmp    rax,rsi
  40ccea:	jbe    40cd7a <__swc_fn_4fa09e82_000058_01964a17+0x23a>
  40ccf0:	xor    eax,eax
  40ccf2:	mov    rcx,QWORD PTR [r13+0x2a70]
  40ccf9:	mov    edx,0x1
  40ccfe:	cmp    rcx,0x1
  40cd02:	jbe    40cd39 <__swc_fn_4fa09e82_000058_01964a17+0x1f9>
  40cd04:	cs nop WORD PTR [rax+rax*1+0x0]
  40cd0e:	xchg   ax,ax
  40cd10:	lea    r8,[rdx+rdx*4]
  40cd14:	lea    r8,[r13+r8*8+0x268]
  40cd1c:	lea    r9,[rax+rax*4]
  40cd20:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40cd28:	cmp    QWORD PTR [r8+0x18],r9
  40cd2c:	cmovb  rax,rdx
  40cd30:	add    rdx,0x1
  40cd34:	cmp    rdx,rcx
  40cd37:	jb     40cd10 <__swc_fn_4fa09e82_000058_01964a17+0x1d0>
  40cd39:	lea    rcx,[rax+rax*4]
  40cd3d:	lea    rcx,[r13+rcx*8+0x268]
  40cd45:	mov    r8,QWORD PTR [rcx]
  40cd48:	mov    r9,QWORD PTR [rcx+0x8]
  40cd4c:	mov    r10,QWORD PTR [rcx+0x10]
  40cd50:	mov    rcx,r13
  40cd53:	mov    rdx,rax
  40cd56:	call   40fc40 <__swc_fn_4fa09e82_000056_87dc216f>
  40cd5b:	mov    rcx,r13
  40cd5e:	mov    rdx,r8
  40cd61:	mov    r8,r9
  40cd64:	mov    r9,r10
  40cd67:	call   407750 <__swc_fn_4fa09e82_000039_9ae4348f>
  40cd6c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40cd74:	jne    40ccd0 <__swc_fn_4fa09e82_000058_01964a17+0x190>
  40cd7a:	add    QWORD PTR [r13+0x2a78],0x1
  40cd82:	mov    rax,QWORD PTR [r13+0x2a70]
  40cd89:	lea    rax,[rax+rax*4]
  40cd8d:	lea    rax,[r13+rax*8+0x268]
  40cd95:	mov    QWORD PTR [rax],r14
  40cd98:	mov    QWORD PTR [rax+0x8],r15
  40cd9c:	mov    QWORD PTR [rax+0x10],r12
  40cda0:	mov    rcx,QWORD PTR [r13+0x2a78]
  40cda7:	mov    QWORD PTR [rax+0x18],rcx
  40cdab:	mov    QWORD PTR [rax+0x20],rdi
  40cdaf:	add    QWORD PTR [r13+0x2a68],r12
  40cdb6:	add    QWORD PTR [r13+0x2a70],0x1
  40cdbe:	mov    rcx,r13
  40cdc1:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40cdc6:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40cdcf:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40cdd8:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40cde1:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40cdea:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40cdf3:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40cdfc:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40ce05:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40ce0e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40ce17:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40ce20:	add    rsp,0x148
  40ce27:	pop    rsi
  40ce28:	pop    rdi
  40ce29:	pop    r15
  40ce2b:	pop    r14
  40ce2d:	pop    r13
  40ce2f:	pop    r12
  40ce31:	ret
	...

000000000040ce40 <__swc_fn_4fa09e82_000061_73a9baa2>:
  40ce40:	push   rbx
  40ce41:	push   r12
  40ce43:	push   r13
  40ce45:	push   r14
  40ce47:	push   r15
  40ce49:	push   rdi
  40ce4a:	push   rsi
  40ce4b:	sub    rsp,0xf0
  40ce52:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40ce58:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40ce5e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40ce64:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40ce6a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40ce73:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40ce7c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40ce85:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40ce8e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40ce97:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40cea0:	mov    eax,r8d
  40cea3:	mov    rbx,rcx
  40cea6:	mov    r12,rdx
  40cea9:	mov    QWORD PTR [rsp+0x18],rdx
  40ceae:	mov    ecx,DWORD PTR [r12+0x58]
  40ceb3:	mov    r13d,ecx
  40ceb6:	cmp    ecx,0x10
  40ceb9:	mov    ecx,0x10
  40cebe:	cmovb  r13d,ecx
  40cec2:	test   r13d,r13d
  40cec5:	mov    rcx,r13
  40cec8:	mov    edx,0x8
  40cecd:	cmove  ecx,edx
  40ced0:	dec    rcx
  40ced3:	mov    rdx,0xffffffffffffffff
  40ceda:	sub    rdx,rcx
  40cedd:	xor    r14d,r14d
  40cee0:	mov    r8,rcx
  40cee3:	not    r8
  40cee6:	lea    rcx,[rcx+0x58]
  40ceea:	and    rcx,r8
  40ceed:	cmp    rdx,0x58
  40cef1:	cmovae r14,rcx
  40cef5:	cmp    eax,0xffffffff
  40cef8:	jne    40cf01 <__swc_fn_4fa09e82_000061_73a9baa2+0xc1>
  40cefa:	mov    r15,QWORD PTR [r12+0x48]
  40ceff:	jmp    40cf33 <__swc_fn_4fa09e82_000061_73a9baa2+0xf3>
  40cf01:	test   eax,eax
  40cf03:	jne    40cf0c <__swc_fn_4fa09e82_000061_73a9baa2+0xcc>
  40cf05:	mov    eax,0x8
  40cf0a:	jmp    40cf30 <__swc_fn_4fa09e82_000061_73a9baa2+0xf0>
  40cf0c:	cmp    eax,0x8
  40cf0f:	ja     40cf17 <__swc_fn_4fa09e82_000061_73a9baa2+0xd7>
  40cf11:	shl    rax,0x4
  40cf15:	jmp    40cf30 <__swc_fn_4fa09e82_000061_73a9baa2+0xf0>
  40cf17:	lea    eax,[rax-0x9]
  40cf1a:	mov    ecx,eax
  40cf1c:	shr    ecx,0x2
  40cf1f:	and    eax,0x3
  40cf22:	lea    ecx,[rcx+0x7]
  40cf25:	lea    ecx,[rcx-0x2]
  40cf28:	lea    eax,[rax+0x5]
  40cf2b:	shlx   rax,rax,rcx
  40cf30:	mov    r15,rax
  40cf33:	lea    rax,[r14+r13*1]
  40cf37:	mov    rcx,0xffffffffffffffff
  40cf3e:	sub    rcx,rax
  40cf41:	cmp    r15,rcx
  40cf44:	jbe    40cf54 <__swc_fn_4fa09e82_000061_73a9baa2+0x114>
  40cf46:	mov    QWORD PTR [r12+0x40],0x0
  40cf4f:	jmp    40d326 <__swc_fn_4fa09e82_000061_73a9baa2+0x4e6>
  40cf54:	mov    QWORD PTR [rsp+0x20],r13
  40cf59:	lea    r13,[rsp+0x8]
  40cf5e:	add    rax,r15
  40cf61:	mov    ecx,0x1000
  40cf66:	test   ecx,ecx
  40cf68:	mov    edx,0x8
  40cf6d:	cmove  ecx,edx
  40cf70:	dec    rcx
  40cf73:	mov    rdx,0xffffffffffffffff
  40cf7a:	sub    rdx,rcx
  40cf7d:	cmp    rax,rdx
  40cf80:	jbe    40cf8c <__swc_fn_4fa09e82_000061_73a9baa2+0x14c>
  40cf82:	mov    QWORD PTR [r13+0x0],0x0
  40cf8a:	jmp    40cf99 <__swc_fn_4fa09e82_000061_73a9baa2+0x159>
  40cf8c:	add    rax,rcx
  40cf8f:	andn   rax,rcx,rax
  40cf94:	mov    QWORD PTR [rsp+0x8],rax
  40cf99:	cmp    QWORD PTR [r13+0x0],0x0
  40cf9e:	jne    40cfae <__swc_fn_4fa09e82_000061_73a9baa2+0x16e>
  40cfa0:	mov    QWORD PTR [r12+0x40],0x0
  40cfa9:	jmp    40d326 <__swc_fn_4fa09e82_000061_73a9baa2+0x4e6>
  40cfae:	mov    QWORD PTR [rsp+0x30],r15
  40cfb3:	xor    r15d,r15d
  40cfb6:	mov    QWORD PTR [rsp+0x38],0x0
  40cfbf:	lea    r12,[rsp+0x10]
  40cfc4:	mov    QWORD PTR [rsp+0x28],r14
  40cfc9:	mov    r14,QWORD PTR [rsp+0x8]
  40cfce:	mov    QWORD PTR [rsp+0x10],r14
  40cfd3:	cmp    r14,0x10000
  40cfda:	ja     40cfe1 <__swc_fn_4fa09e82_000061_73a9baa2+0x1a1>
  40cfdc:	mov    rax,r14
  40cfdf:	jmp    40d032 <__swc_fn_4fa09e82_000061_73a9baa2+0x1f2>
  40cfe1:	xor    eax,eax
  40cfe3:	lea    rcx,[r14-0x1]
  40cfe7:	lzcnt  rax,rcx
  40cfec:	mov    ecx,0x3f
  40cff1:	sub    rcx,rax
  40cff4:	mov    eax,0x1
  40cff9:	lea    rcx,[rcx-0x3]
  40cffd:	shl    rax,cl
  40d000:	mov    rcx,rax
  40d003:	cmp    rax,0x1000
  40d00a:	mov    eax,0x1000
  40d00f:	cmovb  rcx,rax
  40d013:	mov    rdx,0xffffffffffffffff
  40d01a:	sub    rdx,rcx
  40d01d:	mov    rax,r14
  40d020:	lea    r8,[r14+rcx*1-0x1]
  40d025:	neg    rcx
  40d028:	and    r8,rcx
  40d02b:	cmp    r14,rdx
  40d02e:	cmovbe rax,r8
  40d032:	mov    QWORD PTR [rsp+0x8],rax
  40d037:	lea    rax,[rip+0x14fc2]        # 422000 <__swc_data_base_4fa09e82>
  40d03e:	mov    rax,QWORD PTR [rax]
  40d041:	cmp    rax,0xffffffffffffffff
  40d045:	je     40d054 <__swc_fn_4fa09e82_000061_73a9baa2+0x214>
  40d047:	mov    eax,eax
  40d049:	mov    edi,eax
  40d04b:	xor    eax,eax
  40d04d:	call   407000 <pthread_getspecific@plt>
  40d052:	jmp    40d056 <__swc_fn_4fa09e82_000061_73a9baa2+0x216>
  40d054:	xor    eax,eax
  40d056:	test   rax,rax
  40d059:	jne    40d068 <__swc_fn_4fa09e82_000061_73a9baa2+0x228>
  40d05b:	call   40c4e0 <__swc_fn_4fa09e82_000031_3c3e930e>
  40d060:	mov    rcx,rax
  40d063:	call   409ba0 <__swc_fn_4fa09e82_000129_8d8a7dd2>
  40d068:	test   rax,rax
  40d06b:	je     40d15c <__swc_fn_4fa09e82_000061_73a9baa2+0x31c>
  40d071:	cmp    QWORD PTR [rax],rbx
  40d074:	jne    40d15c <__swc_fn_4fa09e82_000061_73a9baa2+0x31c>
  40d07a:	cmp    DWORD PTR [rax+0x20],0x0
  40d07e:	jne    40d15c <__swc_fn_4fa09e82_000061_73a9baa2+0x31c>
  40d084:	mov    rcx,QWORD PTR [rsp+0x8]
  40d089:	movabs rdx,0x7fffffffffffffff
  40d093:	cmp    rcx,rdx
  40d096:	mov    rdx,0xffffffffffffffff
  40d09d:	lea    r8,[rcx+rcx*1]
  40d0a1:	cmovbe rdx,r8
  40d0a5:	mov    r8d,DWORD PTR [rax+0x730]
  40d0ac:	mov    r9d,r8d
  40d0af:	sub    rdx,rcx
  40d0b2:	inc    rdx
  40d0b5:	xor    r10d,r10d
  40d0b8:	test   r8,r8
  40d0bb:	jbe    40d0eb <__swc_fn_4fa09e82_000061_73a9baa2+0x2ab>
  40d0bd:	nop    DWORD PTR [rax]
  40d0c0:	mov    r11d,r10d
  40d0c3:	lea    r11,[r11+r11*4]
  40d0c7:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40d0cf:	sub    r11,rcx
  40d0d2:	cmp    r11,rdx
  40d0d5:	jae    40d0e2 <__swc_fn_4fa09e82_000061_73a9baa2+0x2a2>
  40d0d7:	mov    r9d,r10d
  40d0da:	mov    rdx,r11
  40d0dd:	test   r11,r11
  40d0e0:	je     40d0eb <__swc_fn_4fa09e82_000061_73a9baa2+0x2ab>
  40d0e2:	add    r10,0x1
  40d0e6:	cmp    r10,r8
  40d0e9:	jb     40d0c0 <__swc_fn_4fa09e82_000061_73a9baa2+0x280>
  40d0eb:	mov    ecx,DWORD PTR [rax+0x730]
  40d0f1:	cmp    r9d,ecx
  40d0f4:	jne    40d0fa <__swc_fn_4fa09e82_000061_73a9baa2+0x2ba>
  40d0f6:	xor    eax,eax
  40d0f8:	jmp    40d159 <__swc_fn_4fa09e82_000061_73a9baa2+0x319>
  40d0fa:	lea    rcx,[r9+r9*4]
  40d0fe:	lea    rcx,[rax+rcx*8+0x738]
  40d106:	vmovups xmm0,XMMWORD PTR [rcx]
  40d10a:	mov    rdx,QWORD PTR [rcx+0x10]
  40d10e:	sub    DWORD PTR [rax+0x730],0x1
  40d115:	mov    r8d,DWORD PTR [rax+0x730]
  40d11c:	lea    r8,[r8+r8*4]
  40d120:	lea    r8,[rax+r8*8+0x738]
  40d128:	vmovups xmm1,XMMWORD PTR [r8]
  40d12d:	vmovups XMMWORD PTR [rcx],xmm1
  40d131:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40d137:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40d13c:	mov    rax,QWORD PTR [r8+0x20]
  40d140:	mov    QWORD PTR [rcx+0x20],rax
  40d144:	vpshufd xmm1,xmm0,0xee
  40d149:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40d14f:	mov    QWORD PTR [rsp+0x10],rdx
  40d154:	vmovq  rax,xmm0
  40d159:	mov    r15,rax
  40d15c:	test   r15,r15
  40d15f:	jne    40d177 <__swc_fn_4fa09e82_000061_73a9baa2+0x337>
  40d161:	mov    rcx,rbx
  40d164:	mov    rdx,QWORD PTR [rsp+0x8]
  40d169:	mov    r8,r13
  40d16c:	mov    r9,r12
  40d16f:	call   40ca30 <__swc_fn_4fa09e82_000055_ddf32775>
  40d174:	mov    r15,rax
  40d177:	test   r15,r15
  40d17a:	je     40d1bb <__swc_fn_4fa09e82_000061_73a9baa2+0x37b>
  40d17c:	cmp    QWORD PTR [r12],r14
  40d180:	jae    40d1bb <__swc_fn_4fa09e82_000061_73a9baa2+0x37b>
  40d182:	mov    rax,r15
  40d185:	add    rax,QWORD PTR [r12]
  40d189:	mov    rdx,r14
  40d18c:	sub    rdx,QWORD PTR [r12]
  40d190:	mov    rcx,rax
  40d193:	call   4072a0 <__swc_fn_4fa09e82_000003_81215399>
  40d198:	test   al,al
  40d19a:	je     40d1a3 <__swc_fn_4fa09e82_000061_73a9baa2+0x363>
  40d19c:	mov    QWORD PTR [rsp+0x10],r14
  40d1a1:	jmp    40d1bb <__swc_fn_4fa09e82_000061_73a9baa2+0x37b>
  40d1a3:	mov    rcx,rbx
  40d1a6:	mov    rdx,r15
  40d1a9:	mov    r8,QWORD PTR [rsp+0x8]
  40d1ae:	mov    r9,QWORD PTR [rsp+0x10]
  40d1b3:	call   40cb40 <__swc_fn_4fa09e82_000058_01964a17>
  40d1b8:	xor    r15d,r15d
  40d1bb:	test   r15,r15
  40d1be:	jne    40d23a <__swc_fn_4fa09e82_000061_73a9baa2+0x3fa>
  40d1c0:	cmp    r14,0x10000
  40d1c7:	ja     40d1ce <__swc_fn_4fa09e82_000061_73a9baa2+0x38e>
  40d1c9:	mov    rax,r14
  40d1cc:	jmp    40d21f <__swc_fn_4fa09e82_000061_73a9baa2+0x3df>
  40d1ce:	xor    eax,eax
  40d1d0:	lea    rcx,[r14-0x1]
  40d1d4:	lzcnt  rax,rcx
  40d1d9:	mov    ecx,0x3f
  40d1de:	sub    rcx,rax
  40d1e1:	mov    eax,0x1
  40d1e6:	lea    rcx,[rcx-0x3]
  40d1ea:	shl    rax,cl
  40d1ed:	mov    rcx,rax
  40d1f0:	cmp    rax,0x1000
  40d1f7:	mov    eax,0x1000
  40d1fc:	cmovb  rcx,rax
  40d200:	mov    rdx,0xffffffffffffffff
  40d207:	sub    rdx,rcx
  40d20a:	mov    rax,r14
  40d20d:	lea    r8,[r14+rcx*1-0x1]
  40d212:	neg    rcx
  40d215:	and    r8,rcx
  40d218:	cmp    r14,rdx
  40d21b:	cmovbe rax,r8
  40d21f:	mov    QWORD PTR [rsp+0x8],rax
  40d224:	mov    QWORD PTR [rsp+0x10],r14
  40d229:	mov    rcx,rbx
  40d22c:	mov    rdx,rax
  40d22f:	mov    r8,r14
  40d232:	call   40c5a0 <__swc_fn_4fa09e82_000037_1e381f55>
  40d237:	mov    r15,rax
  40d23a:	test   r15,r15
  40d23d:	jne    40d24b <__swc_fn_4fa09e82_000061_73a9baa2+0x40b>
  40d23f:	mov    r13,QWORD PTR [rsp+0x20]
  40d244:	mov    rsi,QWORD PTR [rsp+0x38]
  40d249:	jmp    40d287 <__swc_fn_4fa09e82_000061_73a9baa2+0x447>
  40d24b:	mov    rax,r15
  40d24e:	add    rax,QWORD PTR [rsp+0x28]
  40d253:	mov    r13,QWORD PTR [rsp+0x20]
  40d258:	test   r13d,r13d
  40d25b:	mov    rcx,r13
  40d25e:	mov    edx,0x8
  40d263:	cmove  ecx,edx
  40d266:	dec    rcx
  40d269:	mov    rdx,0xffffffffffffffff
  40d270:	sub    rdx,rcx
  40d273:	cmp    rax,rdx
  40d276:	jbe    40d27c <__swc_fn_4fa09e82_000061_73a9baa2+0x43c>
  40d278:	xor    eax,eax
  40d27a:	jmp    40d284 <__swc_fn_4fa09e82_000061_73a9baa2+0x444>
  40d27c:	add    rax,rcx
  40d27f:	andn   rax,rcx,rax
  40d284:	mov    rsi,rax
  40d287:	mov    rax,QWORD PTR [rsp+0x8]
  40d28c:	test   r15,r15
  40d28f:	je     40d298 <__swc_fn_4fa09e82_000061_73a9baa2+0x458>
  40d291:	mov    rdi,QWORD PTR [rsp+0x18]
  40d296:	jmp    40d2aa <__swc_fn_4fa09e82_000061_73a9baa2+0x46a>
  40d298:	mov    rdi,QWORD PTR [rsp+0x18]
  40d29d:	mov    QWORD PTR [rdi+0x40],0x0
  40d2a5:	jmp    40d326 <__swc_fn_4fa09e82_000061_73a9baa2+0x4e6>
  40d2aa:	lea    rdx,[rsi-0x58]
  40d2ae:	mov    QWORD PTR [rsi-0x58],r15
  40d2b2:	mov    QWORD PTR [rsi-0x50],rax
  40d2b6:	mov    rax,QWORD PTR [rsp+0x10]
  40d2bb:	mov    QWORD PTR [rsi-0x48],rax
  40d2bf:	mov    QWORD PTR [rsi-0x40],rsi
  40d2c3:	mov    rax,QWORD PTR [rdi+0x48]
  40d2c7:	mov    QWORD PTR [rsi-0x38],rax
  40d2cb:	mov    rax,QWORD PTR [rsp+0x30]
  40d2d0:	mov    QWORD PTR [rsi-0x30],rax
  40d2d4:	mov    DWORD PTR [rsi-0x10],r13d
  40d2d8:	mov    QWORD PTR [rsi-0x28],0x0
  40d2e0:	mov    QWORD PTR [rsi-0x20],0x0
  40d2e8:	add    r15,QWORD PTR [r12]
  40d2ec:	sub    r15,rsi
  40d2ef:	mov    QWORD PTR [rsi-0x30],r15
  40d2f3:	mov    rcx,QWORD PTR [rbx+0x250]
  40d2fa:	nop    WORD PTR [rax+rax*1+0x0]
  40d300:	lea    r8,[rcx+r15*1]
  40d304:	mov    rax,rcx
  40d307:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40d310:	cmp    rax,rcx
  40d313:	je     40d31a <__swc_fn_4fa09e82_000061_73a9baa2+0x4da>
  40d315:	mov    rcx,rax
  40d318:	jmp    40d300 <__swc_fn_4fa09e82_000061_73a9baa2+0x4c0>
  40d31a:	mov    rcx,rbx
  40d31d:	call   40fbb0 <__swc_fn_4fa09e82_000053_9aa81fa7>
  40d322:	mov    QWORD PTR [rdi+0x40],rsi
  40d326:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40d32c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40d332:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40d338:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40d33e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40d347:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40d350:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40d359:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40d362:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40d36b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40d374:	add    rsp,0xf0
  40d37b:	pop    rsi
  40d37c:	pop    rdi
  40d37d:	pop    r15
  40d37f:	pop    r14
  40d381:	pop    r13
  40d383:	pop    r12
  40d385:	pop    rbx
  40d386:	ret
	...

000000000040d390 <__swc_fn_4fa09e82_000064_20100e91>:
  40d390:	push   rbx
  40d391:	push   r12
  40d393:	push   rdi
  40d394:	push   rsi
  40d395:	sub    rsp,0xb8
  40d39c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40d3a2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40d3a8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40d3ae:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40d3b4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40d3ba:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40d3c0:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40d3c6:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40d3cf:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40d3d8:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40d3e1:	mov    rbx,rdx
  40d3e4:	mov    r12,rcx
  40d3e7:	cmp    DWORD PTR [rbx+0x58],0x0
  40d3eb:	je     40d405 <__swc_fn_4fa09e82_000064_20100e91+0x75>
  40d3ed:	mov    eax,DWORD PTR [rbx+0x58]
  40d3f0:	sub    eax,0x1
  40d3f3:	test   DWORD PTR [rbx+0x58],eax
  40d3f6:	je     40d405 <__swc_fn_4fa09e82_000064_20100e91+0x75>
  40d3f8:	mov    QWORD PTR [rbx+0x40],0x0
  40d400:	jmp    40d617 <__swc_fn_4fa09e82_000064_20100e91+0x287>
  40d405:	cmp    QWORD PTR [rbx+0x48],0x0
  40d40a:	jne    40d419 <__swc_fn_4fa09e82_000064_20100e91+0x89>
  40d40c:	mov    QWORD PTR [rbx+0x40],0x0
  40d414:	jmp    40d617 <__swc_fn_4fa09e82_000064_20100e91+0x287>
  40d419:	lea    rax,[rsp+0x8]
  40d41e:	mov    rcx,QWORD PTR [rbx+0x48]
  40d422:	cmp    rcx,0x8
  40d426:	ja     40d430 <__swc_fn_4fa09e82_000064_20100e91+0xa0>
  40d428:	mov    DWORD PTR [rax],0x0
  40d42e:	jmp    40d48b <__swc_fn_4fa09e82_000064_20100e91+0xfb>
  40d430:	cmp    rcx,0x80
  40d437:	ja     40d447 <__swc_fn_4fa09e82_000064_20100e91+0xb7>
  40d439:	lea    rcx,[rcx+0xf]
  40d43d:	shr    rcx,0x4
  40d441:	mov    DWORD PTR [rsp+0x8],ecx
  40d445:	jmp    40d48b <__swc_fn_4fa09e82_000064_20100e91+0xfb>
  40d447:	cmp    rcx,0x10000
  40d44e:	jbe    40d458 <__swc_fn_4fa09e82_000064_20100e91+0xc8>
  40d450:	mov    DWORD PTR [rax],0xffffffff
  40d456:	jmp    40d48b <__swc_fn_4fa09e82_000064_20100e91+0xfb>
  40d458:	dec    rcx
  40d45b:	xor    edx,edx
  40d45d:	lzcnt  rdx,rcx
  40d462:	mov    r8d,0x3f
  40d468:	sub    r8d,edx
  40d46b:	lea    edx,[r8-0x2]
  40d46f:	shrx   rcx,rcx,rdx
  40d474:	and    ecx,0x3
  40d477:	lea    edx,[r8-0x7]
  40d47b:	lea    edx,[rdx*4+0x0]
  40d482:	lea    edx,[rdx+0x9]
  40d485:	add    edx,ecx
  40d487:	mov    DWORD PTR [rsp+0x8],edx
  40d48b:	cmp    DWORD PTR [rax],0x0
  40d48e:	jne    40d49e <__swc_fn_4fa09e82_000064_20100e91+0x10e>
  40d490:	cmp    DWORD PTR [rbx+0x58],0x8
  40d494:	jbe    40d49e <__swc_fn_4fa09e82_000064_20100e91+0x10e>
  40d496:	mov    DWORD PTR [rsp+0x8],0x1
  40d49e:	cmp    DWORD PTR [rbx+0x58],0x10
  40d4a2:	jbe    40d521 <__swc_fn_4fa09e82_000064_20100e91+0x191>
  40d4a8:	cmp    DWORD PTR [rbx+0x58],0x40
  40d4ac:	ja     40d521 <__swc_fn_4fa09e82_000064_20100e91+0x191>
  40d4ae:	cmp    DWORD PTR [rax],0xffffffff
  40d4b1:	je     40d521 <__swc_fn_4fa09e82_000064_20100e91+0x191>
  40d4b3:	mov    ecx,DWORD PTR [rsp+0x8]
  40d4b7:	mov    edx,DWORD PTR [rbx+0x58]
  40d4ba:	dec    rdx
  40d4bd:	cmp    ecx,0x2d
  40d4c0:	jae    40d518 <__swc_fn_4fa09e82_000064_20100e91+0x188>
  40d4c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40d4cc:	nop    DWORD PTR [rax+0x0]
  40d4d0:	mov    r8d,ecx
  40d4d3:	test   ecx,ecx
  40d4d5:	jne    40d4df <__swc_fn_4fa09e82_000064_20100e91+0x14f>
  40d4d7:	mov    r8d,0x8
  40d4dd:	jmp    40d50b <__swc_fn_4fa09e82_000064_20100e91+0x17b>
  40d4df:	cmp    r8d,0x8
  40d4e3:	ja     40d4eb <__swc_fn_4fa09e82_000064_20100e91+0x15b>
  40d4e5:	shl    r8,0x4
  40d4e9:	jmp    40d50b <__swc_fn_4fa09e82_000064_20100e91+0x17b>
  40d4eb:	lea    r8d,[r8-0x9]
  40d4ef:	mov    r9d,r8d
  40d4f2:	shr    r9d,0x2
  40d4f6:	and    r8d,0x3
  40d4fa:	lea    r9d,[r9+0x7]
  40d4fe:	lea    r9d,[r9-0x2]
  40d502:	lea    r8d,[r8+0x5]
  40d506:	shlx   r8,r8,r9
  40d50b:	test   r8,rdx
  40d50e:	je     40d51d <__swc_fn_4fa09e82_000064_20100e91+0x18d>
  40d510:	add    ecx,0x1
  40d513:	cmp    ecx,0x2d
  40d516:	jb     40d4d0 <__swc_fn_4fa09e82_000064_20100e91+0x140>
  40d518:	mov    ecx,0xffffffff
  40d51d:	mov    DWORD PTR [rsp+0x8],ecx
  40d521:	mov    ecx,DWORD PTR [rsp+0x8]
  40d525:	cmp    ecx,0xffffffff
  40d528:	je     40d530 <__swc_fn_4fa09e82_000064_20100e91+0x1a0>
  40d52a:	cmp    DWORD PTR [rbx+0x58],0x40
  40d52e:	jbe    40d543 <__swc_fn_4fa09e82_000064_20100e91+0x1b3>
  40d530:	mov    rcx,r12
  40d533:	mov    rdx,rbx
  40d536:	mov    r8d,DWORD PTR [rax]
  40d539:	call   40ce40 <__swc_fn_4fa09e82_000061_73a9baa2>
  40d53e:	jmp    40d617 <__swc_fn_4fa09e82_000064_20100e91+0x287>
  40d543:	lea    rax,[rip+0x14ab6]        # 422000 <__swc_data_base_4fa09e82>
  40d54a:	mov    rax,QWORD PTR [rax]
  40d54d:	cmp    rax,0xffffffffffffffff
  40d551:	je     40d560 <__swc_fn_4fa09e82_000064_20100e91+0x1d0>
  40d553:	mov    eax,eax
  40d555:	mov    edi,eax
  40d557:	xor    eax,eax
  40d559:	call   407000 <pthread_getspecific@plt>
  40d55e:	jmp    40d562 <__swc_fn_4fa09e82_000064_20100e91+0x1d2>
  40d560:	xor    eax,eax
  40d562:	test   rax,rax
  40d565:	jne    40d574 <__swc_fn_4fa09e82_000064_20100e91+0x1e4>
  40d567:	call   40c4e0 <__swc_fn_4fa09e82_000031_3c3e930e>
  40d56c:	mov    rcx,rax
  40d56f:	call   409ba0 <__swc_fn_4fa09e82_000129_8d8a7dd2>
  40d574:	test   rax,rax
  40d577:	je     40d584 <__swc_fn_4fa09e82_000064_20100e91+0x1f4>
  40d579:	cmp    QWORD PTR [rax],r12
  40d57c:	jne    40d584 <__swc_fn_4fa09e82_000064_20100e91+0x1f4>
  40d57e:	cmp    DWORD PTR [rax+0x20],0x0
  40d582:	je     40d58f <__swc_fn_4fa09e82_000064_20100e91+0x1ff>
  40d584:	mov    rcx,r12
  40d587:	mov    rdx,rax
  40d58a:	call   40f7f0 <__swc_fn_4fa09e82_000041_41400651>
  40d58f:	test   rax,rax
  40d592:	jne    40d59e <__swc_fn_4fa09e82_000064_20100e91+0x20e>
  40d594:	mov    QWORD PTR [rbx+0x40],0x0
  40d59c:	jmp    40d617 <__swc_fn_4fa09e82_000064_20100e91+0x287>
  40d59e:	lea    r8,[rsp+0xc]
  40d5a3:	mov    ecx,DWORD PTR [rsp+0x8]
  40d5a7:	mov    DWORD PTR [rsp+0xc],ecx
  40d5ab:	mov    ecx,DWORD PTR [r8]
  40d5ae:	lea    rcx,[rcx+rcx*4]
  40d5b2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40d5b7:	test   rcx,rcx
  40d5ba:	je     40d5f3 <__swc_fn_4fa09e82_000064_20100e91+0x263>
  40d5bc:	mov    rdx,QWORD PTR [rcx]
  40d5bf:	test   rdx,rdx
  40d5c2:	je     40d5d0 <__swc_fn_4fa09e82_000064_20100e91+0x240>
  40d5c4:	mov    r9,QWORD PTR [rdx]
  40d5c7:	mov    QWORD PTR [rcx],r9
  40d5ca:	add    DWORD PTR [rcx+0x28],0x1
  40d5ce:	jmp    40d5ee <__swc_fn_4fa09e82_000064_20100e91+0x25e>
  40d5d0:	mov    rdx,QWORD PTR [rcx+0x18]
  40d5d4:	cmp    QWORD PTR [rcx+0x20],rdx
  40d5d8:	jae    40d5ec <__swc_fn_4fa09e82_000064_20100e91+0x25c>
  40d5da:	mov    rdx,QWORD PTR [rcx+0x20]
  40d5de:	mov    r9d,DWORD PTR [rcx+0x2c]
  40d5e2:	add    QWORD PTR [rcx+0x20],r9
  40d5e6:	add    DWORD PTR [rcx+0x28],0x1
  40d5ea:	jmp    40d5ee <__swc_fn_4fa09e82_000064_20100e91+0x25e>
  40d5ec:	xor    edx,edx
  40d5ee:	test   rdx,rdx
  40d5f1:	jne    40d604 <__swc_fn_4fa09e82_000064_20100e91+0x274>
  40d5f3:	mov    rcx,r12
  40d5f6:	mov    rdx,rax
  40d5f9:	mov    r8d,DWORD PTR [r8]
  40d5fc:	call   40f960 <__swc_fn_4fa09e82_000050_5e919db9>
  40d601:	mov    rdx,rax
  40d604:	test   rdx,rdx
  40d607:	jne    40d613 <__swc_fn_4fa09e82_000064_20100e91+0x283>
  40d609:	mov    QWORD PTR [rbx+0x40],0x0
  40d611:	jmp    40d617 <__swc_fn_4fa09e82_000064_20100e91+0x287>
  40d613:	mov    QWORD PTR [rbx+0x40],rdx
  40d617:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40d61d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40d623:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40d629:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40d62f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40d635:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40d63b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40d641:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40d64a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40d653:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40d65c:	add    rsp,0xb8
  40d663:	pop    rsi
  40d664:	pop    rdi
  40d665:	pop    r12
  40d667:	pop    rbx
  40d668:	ret
  40d669:	add    BYTE PTR [rax],al
  40d66b:	add    BYTE PTR [rax],al
  40d66d:	add    BYTE PTR [rax],al
	...

000000000040d670 <__swc_fn_4fa09e82_000067_0145abfc>:
  40d670:	ret
	...

000000000040d680 <__swc_fn_4fa09e82_000070_357c932c>:
  40d680:	push   r12
  40d682:	push   r13
  40d684:	push   r14
  40d686:	push   rdi
  40d687:	push   rsi
  40d688:	sub    rsp,0x1a0
  40d68f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40d698:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40d6a1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40d6aa:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40d6b3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40d6bc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40d6c5:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40d6ce:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40d6d7:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40d6e0:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40d6e9:	mov    r12,rdx
  40d6ec:	mov    r13,rcx
  40d6ef:	mov    rax,QWORD PTR [r12+0x48]
  40d6f4:	mov    ecx,DWORD PTR [r12+0x58]
  40d6f9:	lea    rdx,[rax-0x1]
  40d6fd:	cmp    rdx,0x10000
  40d704:	jae    40d7fe <__swc_fn_4fa09e82_000070_357c932c+0x17e>
  40d70a:	cmp    rax,0x8
  40d70e:	ja     40d715 <__swc_fn_4fa09e82_000070_357c932c+0x95>
  40d710:	xor    r14d,r14d
  40d713:	jmp    40d767 <__swc_fn_4fa09e82_000070_357c932c+0xe7>
  40d715:	cmp    rax,0x80
  40d71c:	ja     40d728 <__swc_fn_4fa09e82_000070_357c932c+0xa8>
  40d71e:	lea    r14,[rax+0xf]
  40d722:	shr    r14,0x4
  40d726:	jmp    40d767 <__swc_fn_4fa09e82_000070_357c932c+0xe7>
  40d728:	cmp    rax,0x10000
  40d72f:	jbe    40d739 <__swc_fn_4fa09e82_000070_357c932c+0xb9>
  40d731:	mov    r14d,0xffffffff
  40d737:	jmp    40d767 <__swc_fn_4fa09e82_000070_357c932c+0xe7>
  40d739:	xor    eax,eax
  40d73b:	lzcnt  rax,rdx
  40d740:	mov    r8d,0x3f
  40d746:	sub    r8d,eax
  40d749:	lea    eax,[r8-0x2]
  40d74d:	shrx   rax,rdx,rax
  40d752:	and    eax,0x3
  40d755:	lea    edx,[r8-0x7]
  40d759:	lea    edx,[rdx*4+0x0]
  40d760:	lea    edx,[rdx+0x9]
  40d763:	lea    r14d,[rdx+rax*1]
  40d767:	cmp    ecx,0x8
  40d76a:	jbe    40d783 <__swc_fn_4fa09e82_000070_357c932c+0x103>
  40d76c:	cmp    ecx,0x10
  40d76f:	jne    40d7fe <__swc_fn_4fa09e82_000070_357c932c+0x17e>
  40d775:	test   r14d,r14d
  40d778:	mov    eax,0x1
  40d77d:	cmove  r14d,eax
  40d781:	jmp    40d78a <__swc_fn_4fa09e82_000070_357c932c+0x10a>
  40d783:	lea    eax,[rcx-0x1]
  40d786:	test   eax,ecx
  40d788:	jne    40d7fe <__swc_fn_4fa09e82_000070_357c932c+0x17e>
  40d78a:	lea    rax,[rip+0x1486f]        # 422000 <__swc_data_base_4fa09e82>
  40d791:	mov    rax,QWORD PTR [rax]
  40d794:	cmp    rax,0xffffffffffffffff
  40d798:	je     40d7a7 <__swc_fn_4fa09e82_000070_357c932c+0x127>
  40d79a:	mov    eax,eax
  40d79c:	mov    edi,eax
  40d79e:	xor    eax,eax
  40d7a0:	call   407000 <pthread_getspecific@plt>
  40d7a5:	jmp    40d7a9 <__swc_fn_4fa09e82_000070_357c932c+0x129>
  40d7a7:	xor    eax,eax
  40d7a9:	test   rax,rax
  40d7ac:	je     40d7fe <__swc_fn_4fa09e82_000070_357c932c+0x17e>
  40d7ae:	cmp    QWORD PTR [rax],r13
  40d7b1:	jne    40d7fe <__swc_fn_4fa09e82_000070_357c932c+0x17e>
  40d7b3:	lea    rcx,[r14+r14*4]
  40d7b7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40d7bc:	test   rax,rax
  40d7bf:	je     40d7fe <__swc_fn_4fa09e82_000070_357c932c+0x17e>
  40d7c1:	mov    rcx,QWORD PTR [rax]
  40d7c4:	test   rcx,rcx
  40d7c7:	je     40d7d5 <__swc_fn_4fa09e82_000070_357c932c+0x155>
  40d7c9:	mov    rdx,QWORD PTR [rcx]
  40d7cc:	mov    QWORD PTR [rax],rdx
  40d7cf:	add    DWORD PTR [rax+0x28],0x1
  40d7d3:	jmp    40d7f2 <__swc_fn_4fa09e82_000070_357c932c+0x172>
  40d7d5:	mov    rcx,QWORD PTR [rax+0x18]
  40d7d9:	cmp    QWORD PTR [rax+0x20],rcx
  40d7dd:	jae    40d7f0 <__swc_fn_4fa09e82_000070_357c932c+0x170>
  40d7df:	mov    rcx,QWORD PTR [rax+0x20]
  40d7e3:	mov    edx,DWORD PTR [rax+0x2c]
  40d7e6:	add    QWORD PTR [rax+0x20],rdx
  40d7ea:	add    DWORD PTR [rax+0x28],0x1
  40d7ee:	jmp    40d7f2 <__swc_fn_4fa09e82_000070_357c932c+0x172>
  40d7f0:	xor    ecx,ecx
  40d7f2:	test   rcx,rcx
  40d7f5:	je     40d7fe <__swc_fn_4fa09e82_000070_357c932c+0x17e>
  40d7f7:	mov    QWORD PTR [r12+0x40],rcx
  40d7fc:	jmp    40d809 <__swc_fn_4fa09e82_000070_357c932c+0x189>
  40d7fe:	mov    rcx,r13
  40d801:	mov    rdx,r12
  40d804:	call   4103e0 <__swc_fn_4fa09e82_000071_1e1e3bf8>
  40d809:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40d812:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40d81b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40d824:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40d82d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40d836:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40d83f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40d848:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40d851:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40d85a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40d863:	add    rsp,0x1a0
  40d86a:	pop    rsi
  40d86b:	pop    rdi
  40d86c:	pop    r14
  40d86e:	pop    r13
  40d870:	pop    r12
  40d872:	ret
	...

000000000040d880 <__swc_fn_4fa09e82_000073_cdd57f51>:
  40d880:	push   r12
  40d882:	push   r13
  40d884:	push   r14
  40d886:	push   r15
  40d888:	push   rdi
  40d889:	push   rsi
  40d88a:	sub    rsp,0x188
  40d891:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40d89a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40d8a3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40d8ac:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40d8b5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40d8be:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40d8c7:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40d8d0:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40d8d9:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40d8e2:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40d8eb:	mov    r12,rdx
  40d8ee:	mov    r13,rcx
  40d8f1:	mov    r14,QWORD PTR [r12+0x40]
  40d8f6:	lea    rax,[rip+0x16773]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  40d8fd:	mov    rcx,r14
  40d900:	sub    rcx,QWORD PTR [rax+0x8]
  40d904:	mov    rax,QWORD PTR [rip+0x16775]        # 424080 <__swc_bss_base_4fa09e82+0x40>
  40d90b:	cmp    rcx,rax
  40d90e:	jae    40d93a <__swc_fn_4fa09e82_000073_cdd57f51+0xba>
  40d910:	mov    rax,r14
  40d913:	and    rax,0xffffffffffc00000
  40d91a:	mov    rcx,r14
  40d91d:	shr    rcx,0x10
  40d921:	and    ecx,0x3f
  40d924:	mov    edx,DWORD PTR [rax+0x28]
  40d927:	shrx   ecx,ecx,edx
  40d92c:	shl    rcx,0x4
  40d930:	lea    r15,[rax+rcx*8+0x80]
  40d938:	jmp    40d945 <__swc_fn_4fa09e82_000073_cdd57f51+0xc5>
  40d93a:	mov    rcx,r14
  40d93d:	call   40c410 <__swc_fn_4fa09e82_000022_53fc00d2>
  40d942:	mov    r15,rax
  40d945:	test   r15,r15
  40d948:	je     40d9ef <__swc_fn_4fa09e82_000073_cdd57f51+0x16f>
  40d94e:	lea    rax,[rip+0x146ab]        # 422000 <__swc_data_base_4fa09e82>
  40d955:	mov    rax,QWORD PTR [rax]
  40d958:	cmp    rax,0xffffffffffffffff
  40d95c:	je     40d96b <__swc_fn_4fa09e82_000073_cdd57f51+0xeb>
  40d95e:	mov    eax,eax
  40d960:	mov    edi,eax
  40d962:	xor    eax,eax
  40d964:	call   407000 <pthread_getspecific@plt>
  40d969:	jmp    40d96d <__swc_fn_4fa09e82_000073_cdd57f51+0xed>
  40d96b:	xor    eax,eax
  40d96d:	mov    rcx,QWORD PTR [r15+0x40]
  40d971:	cmp    rcx,rax
  40d974:	jne    40d9d4 <__swc_fn_4fa09e82_000073_cdd57f51+0x154>
  40d976:	test   rax,rax
  40d979:	je     40d9ef <__swc_fn_4fa09e82_000073_cdd57f51+0x16f>
  40d97b:	mov    ecx,DWORD PTR [r15+0x6c]
  40d97f:	test   ecx,ecx
  40d981:	je     40d9a1 <__swc_fn_4fa09e82_000073_cdd57f51+0x121>
  40d983:	mov    rcx,r13
  40d986:	mov    rdx,rax
  40d989:	mov    r8,r15
  40d98c:	mov    QWORD PTR [rsp+0xd8],rax
  40d994:	call   40f8f0 <__swc_fn_4fa09e82_000047_e7fd8d42>
  40d999:	mov    rax,QWORD PTR [rsp+0xd8]
  40d9a1:	mov    rcx,QWORD PTR [r15]
  40d9a4:	mov    QWORD PTR [r14],rcx
  40d9a7:	mov    QWORD PTR [r15],r14
  40d9aa:	sub    DWORD PTR [r15+0x28],0x1
  40d9af:	jne    40d9e4 <__swc_fn_4fa09e82_000073_cdd57f51+0x164>
  40d9b1:	movzx  ecx,BYTE PTR [r15+0x39]
  40d9b6:	lea    rcx,[rcx+rcx*4]
  40d9ba:	lea    rcx,[rax+rcx*8+0x28]
  40d9bf:	cmp    QWORD PTR [rcx],r15
  40d9c2:	je     40d9e4 <__swc_fn_4fa09e82_000073_cdd57f51+0x164>
  40d9c4:	mov    rcx,r13
  40d9c7:	mov    rdx,rax
  40d9ca:	mov    r8,r15
  40d9cd:	call   407d80 <__swc_fn_4fa09e82_000051_27d2a35f>
  40d9d2:	jmp    40d9e4 <__swc_fn_4fa09e82_000073_cdd57f51+0x164>
  40d9d4:	test   rcx,rcx
  40d9d7:	je     40d9ef <__swc_fn_4fa09e82_000073_cdd57f51+0x16f>
  40d9d9:	mov    rcx,r15
  40d9dc:	mov    rdx,r14
  40d9df:	call   40c050 <__swc_fn_4fa09e82_000010_0569f799>
  40d9e4:	mov    QWORD PTR [r12+0x40],0x0
  40d9ed:	jmp    40d9fa <__swc_fn_4fa09e82_000073_cdd57f51+0x17a>
  40d9ef:	mov    rcx,r13
  40d9f2:	mov    rdx,r12
  40d9f5:	call   410400 <__swc_fn_4fa09e82_000074_30b8696a>
  40d9fa:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40da03:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40da0c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40da15:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40da1e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40da27:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40da30:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40da39:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40da42:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40da4b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40da54:	add    rsp,0x188
  40da5b:	pop    rsi
  40da5c:	pop    rdi
  40da5d:	pop    r15
  40da5f:	pop    r14
  40da61:	pop    r13
  40da63:	pop    r12
  40da65:	ret
	...

000000000040da70 <__swc_fn_4fa09e82_000076_c3ad0fb4>:
  40da70:	sub    rsp,0x8
  40da74:	mov    rax,rdx
  40da77:	mov    rdx,QWORD PTR [rax+0x40]
  40da7b:	mov    r8,rax
  40da7e:	call   40d670 <__swc_fn_4fa09e82_000067_0145abfc>
  40da83:	add    rsp,0x8
  40da87:	ret
	...

000000000040da90 <__swc_fn_4fa09e82_000079_633af784>:
  40da90:	push   rsi
  40da91:	push   rdi
  40da92:	sub    rsp,0x8
  40da96:	cmp    rcx,0xffffffffffffffef
  40da9a:	ja     40dac0 <__swc_fn_4fa09e82_000079_633af784+0x30>
  40da9c:	xor    esi,esi
  40da9e:	lea    rax,[rcx+0x100f]
  40daa5:	and    rax,0xfffffffffffff000
  40daac:	lea    rcx,[rcx+0x10]
  40dab0:	cmp    rcx,0xfffffffffffff000
  40dab7:	cmovbe rsi,rax
  40dabb:	test   rsi,rsi
  40dabe:	jne    40dac9 <__swc_fn_4fa09e82_000079_633af784+0x39>
  40dac0:	xor    eax,eax
  40dac2:	add    rsp,0x8
  40dac6:	pop    rdi
  40dac7:	pop    rsi
  40dac8:	ret
  40dac9:	mov    rcx,rsi
  40dacc:	call   411030 <__swc_fn_4fa09e82_000110_9f5af8ae>
  40dad1:	mov    rdi,rax
  40dad4:	test   rax,rax
  40dad7:	jne    40dae2 <__swc_fn_4fa09e82_000079_633af784+0x52>
  40dad9:	xor    eax,eax
  40dadb:	add    rsp,0x8
  40dadf:	pop    rdi
  40dae0:	pop    rsi
  40dae1:	ret
  40dae2:	mov    rcx,rdi
  40dae5:	mov    rdx,rsi
  40dae8:	call   40e0c0 <__swc_fn_4fa09e82_000112_f9e19033>
  40daed:	test   al,al
  40daef:	jne    40db05 <__swc_fn_4fa09e82_000079_633af784+0x75>
  40daf1:	mov    rcx,rdi
  40daf4:	mov    rdx,rsi
  40daf7:	call   409850 <__swc_fn_4fa09e82_000114_4e83a03a>
  40dafc:	xor    eax,eax
  40dafe:	add    rsp,0x8
  40db02:	pop    rdi
  40db03:	pop    rsi
  40db04:	ret
  40db05:	mov    QWORD PTR [rdi],rsi
  40db08:	mov    QWORD PTR [rdi+0x8],0x0
  40db10:	lea    rax,[rdi+0x10]
  40db14:	add    rsp,0x8
  40db18:	pop    rdi
  40db19:	pop    rsi
  40db1a:	ret
  40db1b:	add    BYTE PTR [rax],al
  40db1d:	add    BYTE PTR [rax],al
	...

000000000040db20 <__swc_fn_4fa09e82_000082_ff7d1455>:
  40db20:	sub    rsp,0x8
  40db24:	cmp    BYTE PTR [rcx+0x2c],0x10
  40db28:	jne    40db33 <__swc_fn_4fa09e82_000082_ff7d1455+0x13>
  40db2a:	test   DWORD PTR [rcx+0x28],0x80
  40db31:	je     40db3b <__swc_fn_4fa09e82_000082_ff7d1455+0x1b>
  40db33:	mov    rax,rcx
  40db36:	add    rsp,0x8
  40db3a:	ret
  40db3b:	mov    rcx,QWORD PTR [rcx+0x40]
  40db3f:	call   40db20 <__swc_fn_4fa09e82_000082_ff7d1455>
  40db44:	add    rsp,0x8
  40db48:	ret
	...

000000000040db60 <__swc_fn_4fa09e82_000085_e24ecd12>:
  40db60:	push   rsi
  40db61:	push   rdi
  40db62:	push   r12
  40db64:	push   r13
  40db66:	sub    rsp,0x8
  40db6a:	mov    rsi,rdx
  40db6d:	mov    rdi,rcx
  40db70:	xor    r8d,r8d
  40db73:	call   4085a0 <__swc_fn_4fa09e82_000090_14cf59b2>
  40db78:	test   al,al
  40db7a:	je     40db8c <__swc_fn_4fa09e82_000085_e24ecd12+0x2c>
  40db7c:	mov    eax,0x1
  40db81:	add    rsp,0x8
  40db85:	pop    r13
  40db87:	pop    r12
  40db89:	pop    rdi
  40db8a:	pop    rsi
  40db8b:	ret
  40db8c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40db91:	je     40dba0 <__swc_fn_4fa09e82_000085_e24ecd12+0x40>
  40db93:	xor    eax,eax
  40db95:	add    rsp,0x8
  40db99:	pop    r13
  40db9b:	pop    r12
  40db9d:	pop    rdi
  40db9e:	pop    rsi
  40db9f:	ret
  40dba0:	mov    r12,QWORD PTR [rsi+0x98]
  40dba7:	mov    rax,QWORD PTR [rsi+0xa0]
  40dbae:	mov    rsi,rax
  40dbb1:	xor    r13d,r13d
  40dbb4:	test   rsi,rsi
  40dbb7:	je     40dc14 <__swc_fn_4fa09e82_000085_e24ecd12+0xb4>
  40dbb9:	cs nop WORD PTR [rax+rax*1+0x0]
  40dbc3:	cs nop WORD PTR [rax+rax*1+0x0]
  40dbcd:	nop    DWORD PTR [rax]
  40dbd0:	lea    rax,[r13*8+0x0]
  40dbd8:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40dbdd:	mov    rcx,rax
  40dbe0:	call   40db20 <__swc_fn_4fa09e82_000082_ff7d1455>
  40dbe5:	cmp    BYTE PTR [rax+0x2c],0xe
  40dbe9:	jne    40dc0a <__swc_fn_4fa09e82_000085_e24ecd12+0xaa>
  40dbeb:	mov    rcx,rdi
  40dbee:	mov    rdx,rax
  40dbf1:	call   40db60 <__swc_fn_4fa09e82_000085_e24ecd12>
  40dbf6:	test   al,al
  40dbf8:	je     40dc0a <__swc_fn_4fa09e82_000085_e24ecd12+0xaa>
  40dbfa:	mov    eax,0x1
  40dbff:	add    rsp,0x8
  40dc03:	pop    r13
  40dc05:	pop    r12
  40dc07:	pop    rdi
  40dc08:	pop    rsi
  40dc09:	ret
  40dc0a:	add    r13,0x1
  40dc0e:	sub    rsi,0x1
  40dc12:	jne    40dbd0 <__swc_fn_4fa09e82_000085_e24ecd12+0x70>
  40dc14:	xor    eax,eax
  40dc16:	add    rsp,0x8
  40dc1a:	pop    r13
  40dc1c:	pop    r12
  40dc1e:	pop    rdi
  40dc1f:	pop    rsi
  40dc20:	ret
	...

000000000040dc30 <__swc_fn_4fa09e82_000088_ab2f35d8>:
  40dc30:	sub    rsp,0x18
  40dc34:	vxorps xmm0,xmm0,xmm0
  40dc38:	vmovdqu XMMWORD PTR [rsp],xmm0
  40dc3d:	call   410610 <__swc_fn_4fa09e82_000089_3c530920>
  40dc42:	add    rsp,0x18
  40dc46:	ret
	...

000000000040dc50 <__swc_fn_4fa09e82_000091_f21926ed>:
  40dc50:	sub    rsp,0x8
  40dc54:	mov    rcx,QWORD PTR [rip+0x190e5]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40dc5b:	test   rcx,rcx
  40dc5e:	jne    40dc70 <__swc_fn_4fa09e82_000091_f21926ed+0x20>
  40dc60:	call   40f020 <__swc_fn_4fa09e82_000166_56054fe7>
  40dc65:	lea    rcx,[rax+0x1]
  40dc69:	mov    QWORD PTR [rip+0x190d0],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40dc70:	dec    rcx
  40dc73:	call   40b620 <__swc_fn_4fa09e82_000168_39c041ad>
  40dc78:	mov    rax,QWORD PTR [rax+0xc0]
  40dc7f:	and    eax,0x1
  40dc82:	setne  al
  40dc85:	add    rsp,0x8
  40dc89:	ret
	...

000000000040dca0 <__swc_fn_4fa09e82_000094_383a814c>:
  40dca0:	push   rbx
  40dca1:	push   rsi
  40dca2:	push   rdi
  40dca3:	push   r12
  40dca5:	sub    rsp,0x28
  40dca9:	mov    rbx,rcx
  40dcac:	call   408900 <__swc_fn_4fa09e82_000093_0c97fc6c>
  40dcb1:	mov    rcx,QWORD PTR [rip+0x19088]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40dcb8:	test   rcx,rcx
  40dcbb:	jne    40dccd <__swc_fn_4fa09e82_000094_383a814c+0x2d>
  40dcbd:	call   40f020 <__swc_fn_4fa09e82_000166_56054fe7>
  40dcc2:	lea    rcx,[rax+0x1]
  40dcc6:	mov    QWORD PTR [rip+0x19073],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40dccd:	dec    rcx
  40dcd0:	call   40b620 <__swc_fn_4fa09e82_000168_39c041ad>
  40dcd5:	mov    rsi,rax
  40dcd8:	lea    rcx,[rsp+0x8]
  40dcdd:	call   410a50 <__swc_fn_4fa09e82_000092_809deff5>
  40dce2:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40dce9:	mov    r12,QWORD PTR [rsi+0xbe8]
  40dcf0:	lea    rcx,[rsi+0x10]
  40dcf4:	call   411b90 <__swc_fn_4fa09e82_000158_3495a3ca>
  40dcf9:	mov    rcx,rsi
  40dcfc:	call   410bc0 <__swc_fn_4fa09e82_000101_afcb7774>
  40dd01:	vxorps xmm0,xmm0,xmm0
  40dd05:	xor    eax,eax
  40dd07:	cs nop WORD PTR [rax+rax*1+0x0]
  40dd11:	cs nop WORD PTR [rax+rax*1+0x0]
  40dd1b:	nop    DWORD PTR [rax+rax*1+0x0]
  40dd20:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40dd25:	add    rax,0x10
  40dd29:	cmp    rax,0xbf0
  40dd30:	jne    40dd20 <__swc_fn_4fa09e82_000094_383a814c+0x80>
  40dd32:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40dd38:	vmovups XMMWORD PTR [rsi],xmm0
  40dd3c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40dd42:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40dd4a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40dd51:	mov    QWORD PTR [rsi+0xbe8],r12
  40dd58:	mov    rcx,QWORD PTR [rip+0x18fe1]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40dd5f:	test   rcx,rcx
  40dd62:	jne    40dd74 <__swc_fn_4fa09e82_000094_383a814c+0xd4>
  40dd64:	call   40f020 <__swc_fn_4fa09e82_000166_56054fe7>
  40dd69:	lea    rcx,[rax+0x1]
  40dd6d:	mov    QWORD PTR [rip+0x18fcc],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40dd74:	dec    rcx
  40dd77:	call   40b620 <__swc_fn_4fa09e82_000168_39c041ad>
  40dd7c:	mov    rsi,rax
  40dd7f:	mov    QWORD PTR [rsi+0xc0],rbx
  40dd86:	and    ebx,0x1
  40dd89:	jne    40dd8d <__swc_fn_4fa09e82_000094_383a814c+0xed>
  40dd8b:	xor    eax,eax
  40dd8d:	test   rbx,rbx
  40dd90:	sete   al
  40dd93:	xor    cl,cl
  40dd95:	xor    dl,dl
  40dd97:	xor    r8b,r8b
  40dd9a:	xor    r9b,r9b
  40dd9d:	xor    r10b,r10b
  40dda0:	mov    r11,rax
  40dda3:	call   410410 <__swc_fn_4fa09e82_000077_948ef603>
  40dda8:	lea    rbx,[rsp+0x18]
  40ddad:	mov    rcx,rbx
  40ddb0:	call   410a50 <__swc_fn_4fa09e82_000092_809deff5>
  40ddb5:	lea    rcx,[rsi+0x10]
  40ddb9:	mov    edx,0x400000
  40ddbe:	mov    r8,rbx
  40ddc1:	call   40ed60 <__swc_fn_4fa09e82_000160_6861d596>
  40ddc6:	lea    rcx,[rsi+0x68]
  40ddca:	mov    edx,0x4000
  40ddcf:	mov    r8,rbx
  40ddd2:	call   40ed60 <__swc_fn_4fa09e82_000160_6861d596>
  40ddd7:	add    rsp,0x28
  40dddb:	pop    r12
  40dddd:	pop    rdi
  40ddde:	pop    rsi
  40dddf:	pop    rbx
  40dde0:	ret
	...

000000000040ddf0 <__swc_fn_4fa09e82_000097_96d6739a>:
  40ddf0:	push   rbx
  40ddf1:	push   rsi
  40ddf2:	sub    rsp,0x18
  40ddf6:	mov    rbx,rcx
  40ddf9:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40ddfe:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40de04:	mov    rsi,QWORD PTR [rbx+0x70]
  40de08:	lea    rcx,[rcx+0x18]
  40de0c:	call   411b90 <__swc_fn_4fa09e82_000158_3495a3ca>
  40de11:	lea    rcx,[rsp+0x8]
  40de16:	mov    rdx,rbx
  40de19:	mov    r8d,0x78
  40de1f:	call   408960 <__swc_fn_4fa09e82_000096_a4baaa40>
  40de24:	mov    rax,rsi
  40de27:	add    rsp,0x18
  40de2b:	pop    rsi
  40de2c:	pop    rbx
  40de2d:	ret
	...

000000000040de30 <__swc_fn_4fa09e82_000100_5714513e>:
  40de30:	push   rsi
  40de31:	push   rdi
  40de32:	sub    rsp,0x8
  40de36:	cmp    QWORD PTR [rcx],0x0
  40de3a:	jne    40de43 <__swc_fn_4fa09e82_000100_5714513e+0x13>
  40de3c:	add    rsp,0x8
  40de40:	pop    rdi
  40de41:	pop    rsi
  40de42:	ret
  40de43:	mov    rsi,QWORD PTR [rcx]
  40de46:	mov    rax,QWORD PTR [rcx+0x8]
  40de4a:	test   rax,rax
  40de4d:	je     40de63 <__swc_fn_4fa09e82_000100_5714513e+0x33>
  40de4f:	test   DWORD PTR [rax+0x28],0x400000
  40de56:	je     40de63 <__swc_fn_4fa09e82_000100_5714513e+0x33>
  40de58:	mov    rcx,QWORD PTR [rax+0x30]
  40de5c:	test   rcx,rcx
  40de5f:	cmovne rax,rcx
  40de63:	lea    rdx,[rip+0x5366]        # 4131d0 <__swc_rdata_base_4fa09e82+0xc0>
  40de6a:	lea    rcx,[rip+0x5447]        # 4132b8 <__swc_rdata_base_4fa09e82+0x1a8>
  40de71:	mov    r8,rax
  40de74:	xor    r9d,r9d
  40de77:	xor    al,al
  40de79:	mov    r10,rax
  40de7c:	xor    r11d,r11d
  40de7f:	call   40dc30 <__swc_fn_4fa09e82_000088_ab2f35d8>
  40de84:	test   rax,rax
  40de87:	je     40de97 <__swc_fn_4fa09e82_000100_5714513e+0x67>
  40de89:	mov    rdi,QWORD PTR [rax+0x48]
  40de8d:	test   rdi,rdi
  40de90:	je     40de97 <__swc_fn_4fa09e82_000100_5714513e+0x67>
  40de92:	mov    rcx,rsi
  40de95:	call   rdi
  40de97:	add    rsp,0x8
  40de9b:	pop    rdi
  40de9c:	pop    rsi
  40de9d:	ret
	...

000000000040dea0 <__swc_fn_4fa09e82_000103_0d4cc079>:
  40dea0:	push   rbx
  40dea1:	push   rsi
  40dea2:	push   rdi
  40dea3:	sub    rsp,0x20
  40dea7:	mov    rbx,rdx
  40deaa:	mov    rsi,rcx
  40dead:	mov    rcx,QWORD PTR [rip+0x18e8c]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40deb4:	test   rcx,rcx
  40deb7:	jne    40dec9 <__swc_fn_4fa09e82_000103_0d4cc079+0x29>
  40deb9:	call   40f020 <__swc_fn_4fa09e82_000166_56054fe7>
  40debe:	lea    rcx,[rax+0x1]
  40dec2:	mov    QWORD PTR [rip+0x18e77],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40dec9:	dec    rcx
  40decc:	call   40b620 <__swc_fn_4fa09e82_000168_39c041ad>
  40ded1:	mov    rdi,rax
  40ded4:	mov    rax,QWORD PTR [rdi+0xbd0]
  40dedb:	xor    ecx,ecx
  40dedd:	test   rax,rax
  40dee0:	je     40dee5 <__swc_fn_4fa09e82_000103_0d4cc079+0x45>
  40dee2:	mov    rcx,QWORD PTR [rax]
  40dee5:	call   40f150 <__swc_fn_4fa09e82_000175_02e645b4>
  40deea:	lea    rax,[rsp+0x8]
  40deef:	lea    rcx,[rdi+0x9c8]
  40def6:	mov    QWORD PTR [rsp+0x8],rcx
  40defb:	mov    QWORD PTR [rax+0x8],0x40
  40df03:	xor    ecx,ecx
  40df05:	mov    rdx,rax
  40df08:	call   409980 <__swc_fn_4fa09e82_000120_2d9caf16>
  40df0d:	mov    DWORD PTR [rdi+0xbc8],eax
  40df13:	mov    rdi,QWORD PTR [rdi+0x990]
  40df1a:	test   rdi,rdi
  40df1d:	je     40df27 <__swc_fn_4fa09e82_000103_0d4cc079+0x87>
  40df1f:	mov    rcx,rsi
  40df22:	mov    rdx,rbx
  40df25:	call   rdi
  40df27:	call   40dc50 <__swc_fn_4fa09e82_000091_f21926ed>
  40df2c:	test   al,al
  40df2e:	je     40df3e <__swc_fn_4fa09e82_000103_0d4cc079+0x9e>
  40df30:	mov    rcx,rsi
  40df33:	mov    rdx,rbx
  40df36:	xor    r8d,r8d
  40df39:	call   40e260 <__swc_fn_4fa09e82_000121_1e032ef6>
  40df3e:	mov    rcx,rsi
  40df41:	mov    rdx,rbx
  40df44:	call   408a60 <__swc_fn_4fa09e82_000102_14986ec5>
  40df49:	call   4113e0 <__swc_fn_4fa09e82_000119_591530fe>
  40df4e:	add    rsp,0x20
  40df52:	pop    rdi
  40df53:	pop    rsi
  40df54:	pop    rbx
  40df55:	ret
	...

000000000040df60 <__swc_fn_4fa09e82_000106_83487ba1>:
  40df60:	sub    rsp,0x8
  40df64:	test   r8,r8
  40df67:	je     40df6e <__swc_fn_4fa09e82_000106_83487ba1+0xe>
  40df69:	call   410d90 <__swc_fn_4fa09e82_000104_04d1a8be>
  40df6e:	add    rsp,0x8
  40df72:	ret
	...

000000000040df80 <__swc_fn_4fa09e82_000109_b8f4bd15>:
  40df80:	push   rsi
  40df81:	push   rdi
  40df82:	push   r12
  40df84:	push   r13
  40df86:	sub    rsp,0xd8
  40df8d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40df93:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40df99:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40df9f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40dfa5:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40dfab:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40dfb4:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40dfbd:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40dfc6:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40dfcf:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40dfd8:	xor    eax,eax
  40dfda:	call   407050 <getpid@plt>
  40dfdf:	mov    rsi,rax
  40dfe2:	lea    rdi,[rip+0x18d5f]        # 426d48 <__swc_bss_base_4fa09e82+0x2d08>
  40dfe9:	mov    r12,QWORD PTR [rdi]
  40dfec:	test   r12,r12
  40dfef:	je     40dffd <__swc_fn_4fa09e82_000109_b8f4bd15+0x7d>
  40dff1:	cmp    DWORD PTR [r12+0x10],esi
  40dff6:	jne    40dffd <__swc_fn_4fa09e82_000109_b8f4bd15+0x7d>
  40dff8:	mov    rax,r12
  40dffb:	jmp    40e060 <__swc_fn_4fa09e82_000109_b8f4bd15+0xe0>
  40dffd:	mov    ecx,0x4
  40e002:	mov    edx,0x18
  40e007:	call   409190 <__swc_fn_4fa09e82_000108_c8d4a68e>
  40e00c:	mov    rcx,rax
  40e00f:	test   rax,rax
  40e012:	jne    40e018 <__swc_fn_4fa09e82_000109_b8f4bd15+0x98>
  40e014:	xor    eax,eax
  40e016:	jmp    40e060 <__swc_fn_4fa09e82_000109_b8f4bd15+0xe0>
  40e018:	mov    DWORD PTR [rcx+0x10],esi
  40e01b:	mov    rax,r12
  40e01e:	lock cmpxchg QWORD PTR [rdi],rcx
  40e023:	mov    r13,rax
  40e026:	cmp    rax,r12
  40e029:	je     40e03f <__swc_fn_4fa09e82_000109_b8f4bd15+0xbf>
  40e02b:	mov    rdi,rcx
  40e02e:	mov    esi,0x18
  40e033:	xor    eax,eax
  40e035:	call   407160 <munmap@plt>
  40e03a:	mov    rax,r13
  40e03d:	jmp    40e060 <__swc_fn_4fa09e82_000109_b8f4bd15+0xe0>
  40e03f:	test   r12,r12
  40e042:	je     40e05d <__swc_fn_4fa09e82_000109_b8f4bd15+0xdd>
  40e044:	mov    rdi,r12
  40e047:	mov    esi,0x18
  40e04c:	xor    eax,eax
  40e04e:	mov    QWORD PTR [rsp+0x28],rcx
  40e053:	call   407160 <munmap@plt>
  40e058:	mov    rcx,QWORD PTR [rsp+0x28]
  40e05d:	mov    rax,rcx
  40e060:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40e066:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40e06c:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40e072:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40e078:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40e07e:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40e087:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40e090:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40e099:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40e0a2:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40e0ab:	add    rsp,0xd8
  40e0b2:	pop    r13
  40e0b4:	pop    r12
  40e0b6:	pop    rdi
  40e0b7:	pop    rsi
  40e0b8:	ret
  40e0b9:	add    BYTE PTR [rax],al
  40e0bb:	add    BYTE PTR [rax],al
  40e0bd:	add    BYTE PTR [rax],al
	...

000000000040e0c0 <__swc_fn_4fa09e82_000112_f9e19033>:
  40e0c0:	push   rbx
  40e0c1:	push   r12
  40e0c3:	push   rdi
  40e0c4:	push   rsi
  40e0c5:	sub    rsp,0xa8
  40e0cc:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e0d2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e0d8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e0de:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e0e4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e0ea:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e0f0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e0f6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e0fc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e105:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e10e:	mov    rbx,rdx
  40e111:	mov    r12,rcx
  40e114:	mov    rdi,rcx
  40e117:	mov    rsi,rdx
  40e11a:	mov    edx,0x3
  40e11f:	xor    eax,eax
  40e121:	call   407170 <mprotect@plt>
  40e126:	test   eax,eax
  40e128:	je     40e12e <__swc_fn_4fa09e82_000112_f9e19033+0x6e>
  40e12a:	xor    eax,eax
  40e12c:	jmp    40e143 <__swc_fn_4fa09e82_000112_f9e19033+0x83>
  40e12e:	mov    rcx,r12
  40e131:	mov    rdx,rbx
  40e134:	mov    al,0x1
  40e136:	mov    r8,rax
  40e139:	call   4097c0 <__swc_fn_4fa09e82_000111_918d5a21>
  40e13e:	mov    eax,0x1
  40e143:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e149:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e14f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e155:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e15b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e161:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e167:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e16d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e173:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e17c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e185:	add    rsp,0xa8
  40e18c:	pop    rsi
  40e18d:	pop    rdi
  40e18e:	pop    r12
  40e190:	pop    rbx
  40e191:	ret
	...

000000000040e1a0 <__swc_fn_4fa09e82_000115_cc486df9>:
  40e1a0:	sub    rsp,0x8
  40e1a4:	test   rcx,rcx
  40e1a7:	jne    40e1ae <__swc_fn_4fa09e82_000115_cc486df9+0xe>
  40e1a9:	add    rsp,0x8
  40e1ad:	ret
  40e1ae:	call   411290 <__swc_fn_4fa09e82_000116_3f6af4b1>
  40e1b3:	add    rsp,0x8
  40e1b7:	ret
	...

000000000040e1c0 <__swc_fn_4fa09e82_000118_5aba1420>:
  40e1c0:	push   rdi
  40e1c1:	push   rsi
  40e1c2:	sub    rsp,0xa8
  40e1c9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e1cf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e1d5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e1db:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e1e1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e1e7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e1ed:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e1f3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e1f9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e202:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e20b:	xor    edi,edi
  40e20d:	xor    eax,eax
  40e20f:	call   407180 <exit@plt>
  40e214:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e21a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e220:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e226:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e22c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e232:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e238:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e23e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e244:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e24d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e256:	add    rsp,0xa8
  40e25d:	pop    rsi
  40e25e:	pop    rdi
  40e25f:	ret

000000000040e260 <__swc_fn_4fa09e82_000121_1e032ef6>:
  40e260:	push   rbx
  40e261:	push   rsi
  40e262:	push   rdi
  40e263:	push   r12
  40e265:	sub    rsp,0x18
  40e269:	mov    rbx,r8
  40e26c:	mov    rsi,rcx
  40e26f:	mov    rdi,rdx
  40e272:	mov    rcx,QWORD PTR [rip+0x18ac7]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40e279:	test   rcx,rcx
  40e27c:	jne    40e28e <__swc_fn_4fa09e82_000121_1e032ef6+0x2e>
  40e27e:	call   40f020 <__swc_fn_4fa09e82_000166_56054fe7>
  40e283:	lea    rcx,[rax+0x1]
  40e287:	mov    QWORD PTR [rip+0x18ab2],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40e28e:	dec    rcx
  40e291:	call   40b620 <__swc_fn_4fa09e82_000168_39c041ad>
  40e296:	mov    r12,rax
  40e299:	cmp    ebx,0x3
  40e29c:	jne    40e2af <__swc_fn_4fa09e82_000121_1e032ef6+0x4f>
  40e29e:	mov    rax,QWORD PTR [r12+0xbd0]
  40e2a6:	test   rax,rax
  40e2a9:	jne    40e3ec <__swc_fn_4fa09e82_000121_1e032ef6+0x18c>
  40e2af:	cmp    ebx,0x5
  40e2b2:	jne    40e2d6 <__swc_fn_4fa09e82_000121_1e032ef6+0x76>
  40e2b4:	call   40dc50 <__swc_fn_4fa09e82_000091_f21926ed>
  40e2b9:	test   al,al
  40e2bb:	jne    40e2d6 <__swc_fn_4fa09e82_000121_1e032ef6+0x76>
  40e2bd:	mov    rcx,rsi
  40e2c0:	mov    rdx,rdi
  40e2c3:	call   40b5d0 <__swc_fn_4fa09e82_000165_d25850aa>
  40e2c8:	test   al,al
  40e2ca:	je     40e2d6 <__swc_fn_4fa09e82_000121_1e032ef6+0x76>
  40e2cc:	add    rsp,0x18
  40e2d0:	pop    r12
  40e2d2:	pop    rdi
  40e2d3:	pop    rsi
  40e2d4:	pop    rbx
  40e2d5:	ret
  40e2d6:	call   40dc50 <__swc_fn_4fa09e82_000091_f21926ed>
  40e2db:	test   al,al
  40e2dd:	jne    40e34f <__swc_fn_4fa09e82_000121_1e032ef6+0xef>
  40e2df:	vmovups xmm0,XMMWORD PTR [rsi]
  40e2e3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e2e9:	mov    rax,QWORD PTR [rsp+0x8]
  40e2ee:	test   rax,rax
  40e2f1:	jne    40e342 <__swc_fn_4fa09e82_000121_1e032ef6+0xe2>
  40e2f3:	cmp    ebx,0x3
  40e2f6:	je     40e304 <__swc_fn_4fa09e82_000121_1e032ef6+0xa4>
  40e2f8:	cmp    ebx,0x4
  40e2fb:	je     40e314 <__swc_fn_4fa09e82_000121_1e032ef6+0xb4>
  40e2fd:	cmp    ebx,0x5
  40e300:	je     40e324 <__swc_fn_4fa09e82_000121_1e032ef6+0xc4>
  40e302:	jmp    40e334 <__swc_fn_4fa09e82_000121_1e032ef6+0xd4>
  40e304:	vmovups xmm0,XMMWORD PTR [rip+0x51d4]        # 4134e0 <__swc_rdata_base_4fa09e82+0x3d0>
  40e30c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e312:	jmp    40e342 <__swc_fn_4fa09e82_000121_1e032ef6+0xe2>
  40e314:	vmovups xmm0,XMMWORD PTR [rip+0x51d4]        # 4134f0 <__swc_rdata_base_4fa09e82+0x3e0>
  40e31c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e322:	jmp    40e342 <__swc_fn_4fa09e82_000121_1e032ef6+0xe2>
  40e324:	vmovups xmm0,XMMWORD PTR [rip+0x51d4]        # 413500 <__swc_rdata_base_4fa09e82+0x3f0>
  40e32c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e332:	jmp    40e342 <__swc_fn_4fa09e82_000121_1e032ef6+0xe2>
  40e334:	vmovups xmm0,XMMWORD PTR [rip+0x51d4]        # 413510 <__swc_rdata_base_4fa09e82+0x400>
  40e33c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e342:	lea    rcx,[rsp+0x8]
  40e347:	mov    rdx,rdi
  40e34a:	call   40dea0 <__swc_fn_4fa09e82_000103_0d4cc079>
  40e34f:	vmovups xmm0,XMMWORD PTR [rdi]
  40e353:	vmovups XMMWORD PTR [r12+0x940],xmm0
  40e35d:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  40e362:	vmovups XMMWORD PTR [r12+0x950],xmm0
  40e36c:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  40e371:	vmovups XMMWORD PTR [r12+0x960],xmm0
  40e37b:	lea    rax,[r12+0x940]
  40e383:	mov    QWORD PTR [r12+0x970],rax
  40e38b:	mov    rax,QWORD PTR [rsi]
  40e38e:	mov    QWORD PTR [r12+0x978],rax
  40e396:	mov    rax,QWORD PTR [rsi+0x8]
  40e39a:	mov    QWORD PTR [r12+0x980],rax
  40e3a2:	movsxd rax,ebx
  40e3a5:	mov    QWORD PTR [r12+0x988],rax
  40e3ad:	cmp    ebx,0x5
  40e3b0:	je     40e3b9 <__swc_fn_4fa09e82_000121_1e032ef6+0x159>
  40e3b2:	xor    ecx,ecx
  40e3b4:	call   40f150 <__swc_fn_4fa09e82_000175_02e645b4>
  40e3b9:	mov    rbx,QWORD PTR [r12+0xbe8]
  40e3c1:	test   rbx,rbx
  40e3c4:	je     40e3d5 <__swc_fn_4fa09e82_000121_1e032ef6+0x175>
  40e3c6:	mov    rcx,r12
  40e3c9:	call   rbx
  40e3cb:	add    rsp,0x18
  40e3cf:	pop    r12
  40e3d1:	pop    rdi
  40e3d2:	pop    rsi
  40e3d3:	pop    rbx
  40e3d4:	ret
  40e3d5:	mov    rcx,rsi
  40e3d8:	call   409870 <__swc_fn_4fa09e82_000117_3f5cfdef>
  40e3dd:	call   4113e0 <__swc_fn_4fa09e82_000119_591530fe>
  40e3e2:	add    rsp,0x18
  40e3e6:	pop    r12
  40e3e8:	pop    rdi
  40e3e9:	pop    rsi
  40e3ea:	pop    rbx
  40e3eb:	ret
  40e3ec:	mov    rcx,rsi
  40e3ef:	mov    rdx,rdi
  40e3f2:	call   40dea0 <__swc_fn_4fa09e82_000103_0d4cc079>
  40e3f7:	jmp    40e2af <__swc_fn_4fa09e82_000121_1e032ef6+0x4f>
  40e3fc:	add    BYTE PTR [rax],al
	...

000000000040e400 <__swc_fn_4fa09e82_000124_e4107ade>:
  40e400:	push   rdi
  40e401:	push   rsi
  40e402:	sub    rsp,0xb8
  40e409:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40e40f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40e415:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40e41b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40e421:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40e427:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40e42d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40e433:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40e43c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40e445:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40e44e:	mov    DWORD PTR [rsp+0x8],0x0
  40e456:	lea    rdi,[rsp+0x8]
  40e45b:	xor    esi,esi
  40e45d:	xor    eax,eax
  40e45f:	call   407190 <pthread_key_create@plt>
  40e464:	test   eax,eax
  40e466:	jne    40e46e <__swc_fn_4fa09e82_000124_e4107ade+0x6e>
  40e468:	mov    eax,DWORD PTR [rsp+0x8]
  40e46c:	jmp    40e475 <__swc_fn_4fa09e82_000124_e4107ade+0x75>
  40e46e:	mov    rax,0xffffffffffffffff
  40e475:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40e47b:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40e481:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40e487:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40e48d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40e493:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40e499:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40e49f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40e4a8:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40e4b1:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40e4ba:	add    rsp,0xb8
  40e4c1:	pop    rsi
  40e4c2:	pop    rdi
  40e4c3:	ret
	...

000000000040e4d0 <__swc_fn_4fa09e82_000127_9e9697c7>:
  40e4d0:	push   rdi
  40e4d1:	push   rsi
  40e4d2:	sub    rsp,0xb8
  40e4d9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40e4df:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40e4e5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40e4eb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40e4f1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40e4f7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40e4fd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40e503:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40e50c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40e515:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40e51e:	mov    DWORD PTR [rsp+0x8],0x0
  40e526:	lea    rdi,[rsp+0x8]
  40e52b:	mov    rsi,rcx
  40e52e:	xor    eax,eax
  40e530:	call   407190 <pthread_key_create@plt>
  40e535:	test   eax,eax
  40e537:	jne    40e542 <__swc_fn_4fa09e82_000127_9e9697c7+0x72>
  40e539:	mov    eax,DWORD PTR [rsp+0x8]
  40e53d:	inc    rax
  40e540:	jmp    40e544 <__swc_fn_4fa09e82_000127_9e9697c7+0x74>
  40e542:	xor    eax,eax
  40e544:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40e54a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40e550:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40e556:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40e55c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40e562:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40e568:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40e56e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40e577:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40e580:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40e589:	add    rsp,0xb8
  40e590:	pop    rsi
  40e591:	pop    rdi
  40e592:	ret
	...

000000000040e5a0 <__swc_fn_4fa09e82_000130_bc477461>:
  40e5a0:	push   rdi
  40e5a1:	push   rsi
  40e5a2:	sub    rsp,0xa8
  40e5a9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e5af:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e5b5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e5bb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e5c1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e5c7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e5cd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e5d3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e5d9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e5e2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e5eb:	test   rcx,rcx
  40e5ee:	setne  al
  40e5f1:	je     40e60a <__swc_fn_4fa09e82_000130_bc477461+0x6a>
  40e5f3:	lea    rax,[rcx-0x1]
  40e5f7:	mov    eax,eax
  40e5f9:	mov    edi,eax
  40e5fb:	mov    rsi,rdx
  40e5fe:	xor    eax,eax
  40e600:	call   407120 <pthread_setspecific@plt>
  40e605:	test   eax,eax
  40e607:	sete   al
  40e60a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e610:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e616:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e61c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e622:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e628:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e62e:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e634:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e63a:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e643:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e64c:	add    rsp,0xa8
  40e653:	pop    rsi
  40e654:	pop    rdi
  40e655:	ret
	...

000000000040e660 <__swc_fn_4fa09e82_000133_51cc49e7>:
  40e660:	push   rdi
  40e661:	push   rsi
  40e662:	sub    rsp,0xa8
  40e669:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e66f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e675:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e67b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e681:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e687:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e68d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e693:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e699:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e6a2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e6ab:	mov    rax,rdx
  40e6ae:	mov    QWORD PTR [rsp],0x0
  40e6b6:	mov    edi,0xca
  40e6bb:	mov    rsi,rcx
  40e6be:	mov    edx,0x81
  40e6c3:	mov    eax,eax
  40e6c5:	mov    ecx,eax
  40e6c7:	xor    r8d,r8d
  40e6ca:	xor    r9d,r9d
  40e6cd:	xor    eax,eax
  40e6cf:	call   4071a0 <syscall@plt>
  40e6d4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e6da:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e6e0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e6e6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e6ec:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e6f2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e6f8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e6fe:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e704:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e70d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e716:	add    rsp,0xa8
  40e71d:	pop    rsi
  40e71e:	pop    rdi
  40e71f:	ret

000000000040e720 <__swc_fn_4fa09e82_000136_db32cc57>:
  40e720:	sub    rsp,0x8
  40e724:	call   411790 <__swc_fn_4fa09e82_000134_807fd51d>
  40e729:	add    rsp,0x8
  40e72d:	ret
	...

000000000040e730 <__swc_fn_4fa09e82_000139_22d6573c>:
  40e730:	push   rdi
  40e731:	push   rsi
  40e732:	sub    rsp,0xc8
  40e739:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40e73f:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40e745:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40e74b:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40e751:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40e757:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40e75d:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40e766:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40e76f:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40e778:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40e781:	vxorps xmm0,xmm0,xmm0
  40e785:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e78b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e791:	mov    rdi,rcx
  40e794:	lea    rsi,[rsp+0x8]
  40e799:	xor    eax,eax
  40e79b:	call   4071b0 <dladdr@plt>
  40e7a0:	xor    ecx,ecx
  40e7a2:	test   eax,eax
  40e7a4:	je     40e7ab <__swc_fn_4fa09e82_000139_22d6573c+0x7b>
  40e7a6:	mov    rcx,QWORD PTR [rsp+0x10]
  40e7ab:	mov    rax,rcx
  40e7ae:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40e7b4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40e7ba:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40e7c0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40e7c6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40e7cc:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40e7d2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40e7db:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40e7e4:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40e7ed:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40e7f6:	add    rsp,0xc8
  40e7fd:	pop    rsi
  40e7fe:	pop    rdi
  40e7ff:	ret

000000000040e800 <__swc_fn_4fa09e82_000142_5e493395>:
  40e800:	push   rbx
  40e801:	push   r12
  40e803:	push   r13
  40e805:	push   rdi
  40e806:	push   rsi
  40e807:	push   r14
  40e809:	push   r15
  40e80b:	sub    rsp,0x150
  40e812:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40e81b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40e824:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40e82d:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40e836:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40e83f:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40e848:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40e851:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40e85a:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40e863:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40e86c:	mov    rbx,rdx
  40e86f:	mov    QWORD PTR [rsp+0x98],rdx
  40e877:	mov    r12,rcx
  40e87a:	mov    QWORD PTR [rsp+0xa0],rcx
  40e882:	mov    QWORD PTR [rbx],0x0
  40e889:	lea    r13,[rip+0x184f0]        # 426d80 <__swc_bss_base_4fa09e82+0x2d40>
  40e890:	mov    rcx,r13
  40e893:	call   40e720 <__swc_fn_4fa09e82_000136_db32cc57>
  40e898:	mov    rax,QWORD PTR [rip+0x184e9]        # 426d88 <__swc_bss_base_4fa09e82+0x2d48>
  40e89f:	test   rax,rax
  40e8a2:	je     40e8d9 <__swc_fn_4fa09e82_000142_5e493395+0xd9>
  40e8a4:	cs nop WORD PTR [rax+rax*1+0x0]
  40e8ae:	xchg   ax,ax
  40e8b0:	cmp    QWORD PTR [rax+0x8],r12
  40e8b4:	jne    40e8d1 <__swc_fn_4fa09e82_000142_5e493395+0xd1>
  40e8b6:	mov    rcx,QWORD PTR [rax+0x18]
  40e8ba:	mov    QWORD PTR [rbx],rcx
  40e8bd:	mov    rbx,QWORD PTR [rax+0x10]
  40e8c1:	mov    rcx,r13
  40e8c4:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40e8c9:	mov    rax,rbx
  40e8cc:	jmp    40eabb <__swc_fn_4fa09e82_000142_5e493395+0x2bb>
  40e8d1:	mov    rax,QWORD PTR [rax]
  40e8d4:	test   rax,rax
  40e8d7:	jne    40e8b0 <__swc_fn_4fa09e82_000142_5e493395+0xb0>
  40e8d9:	vxorps xmm0,xmm0,xmm0
  40e8dd:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  40e8e3:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  40e8e9:	mov    rdi,r12
  40e8ec:	lea    rsi,[rsp+0x10]
  40e8f1:	xor    eax,eax
  40e8f3:	call   4071b0 <dladdr@plt>
  40e8f8:	test   eax,eax
  40e8fa:	sete   al
  40e8fd:	je     40e90a <__swc_fn_4fa09e82_000142_5e493395+0x10a>
  40e8ff:	mov    rax,QWORD PTR [rsp+0x10]
  40e904:	test   rax,rax
  40e907:	sete   al
  40e90a:	test   al,al
  40e90c:	je     40e91d <__swc_fn_4fa09e82_000142_5e493395+0x11d>
  40e90e:	mov    rcx,r13
  40e911:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40e916:	xor    eax,eax
  40e918:	jmp    40eabb <__swc_fn_4fa09e82_000142_5e493395+0x2bb>
  40e91d:	mov    rdi,QWORD PTR [rsp+0x10]
  40e922:	mov    esi,0x80000
  40e927:	xor    eax,eax
  40e929:	call   407010 <open@plt>
  40e92e:	lea    r14,[rsp+0x30]
  40e933:	mov    DWORD PTR [rsp+0x30],eax
  40e937:	cmp    DWORD PTR [r14],0x0
  40e93b:	jge    40e94c <__swc_fn_4fa09e82_000142_5e493395+0x14c>
  40e93d:	mov    rcx,r13
  40e940:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40e945:	xor    eax,eax
  40e947:	jmp    40eabb <__swc_fn_4fa09e82_000142_5e493395+0x2bb>
  40e94c:	mov    rax,r14
  40e94f:	movsxd rdi,DWORD PTR [rax]
  40e952:	xor    esi,esi
  40e954:	mov    edx,0x2
  40e959:	xor    eax,eax
  40e95b:	call   4070c0 <lseek@plt>
  40e960:	mov    r15,rax
  40e963:	test   rax,rax
  40e966:	jg     40e981 <__swc_fn_4fa09e82_000142_5e493395+0x181>
  40e968:	movsxd rdi,DWORD PTR [r14]
  40e96b:	xor    eax,eax
  40e96d:	call   407040 <close@plt>
  40e972:	mov    rcx,r13
  40e975:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40e97a:	xor    eax,eax
  40e97c:	jmp    40eabb <__swc_fn_4fa09e82_000142_5e493395+0x2bb>
  40e981:	xor    edi,edi
  40e983:	mov    rsi,r15
  40e986:	mov    edx,0x1
  40e98b:	mov    ecx,0x2
  40e990:	mov    rax,r14
  40e993:	movsxd r8,DWORD PTR [rax]
  40e996:	xor    r9d,r9d
  40e999:	xor    eax,eax
  40e99b:	call   4070d0 <mmap@plt>
  40e9a0:	mov    rbx,rax
  40e9a3:	test   rax,rax
  40e9a6:	sete   al
  40e9a9:	cmp    rbx,0xffffffffffffffff
  40e9ad:	sete   cl
  40e9b0:	or     al,cl
  40e9b2:	je     40e9cd <__swc_fn_4fa09e82_000142_5e493395+0x1cd>
  40e9b4:	movsxd rdi,DWORD PTR [r14]
  40e9b7:	xor    eax,eax
  40e9b9:	call   407040 <close@plt>
  40e9be:	mov    rcx,r13
  40e9c1:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40e9c6:	xor    eax,eax
  40e9c8:	jmp    40eabb <__swc_fn_4fa09e82_000142_5e493395+0x2bb>
  40e9cd:	lea    rax,[rsp+0x50]
  40e9d2:	mov    QWORD PTR [rax],0x0
  40e9d9:	mov    rcx,rbx
  40e9dc:	mov    rdx,r15
  40e9df:	mov    r8,rax
  40e9e2:	call   409e00 <__swc_fn_4fa09e82_000141_55003b6d>
  40e9e7:	mov    r12,rax
  40e9ea:	test   rax,rax
  40e9ed:	jne    40ea15 <__swc_fn_4fa09e82_000142_5e493395+0x215>
  40e9ef:	mov    rdi,rbx
  40e9f2:	mov    rsi,r15
  40e9f5:	xor    eax,eax
  40e9f7:	call   407160 <munmap@plt>
  40e9fc:	movsxd rdi,DWORD PTR [r14]
  40e9ff:	xor    eax,eax
  40ea01:	call   407040 <close@plt>
  40ea06:	mov    rcx,r13
  40ea09:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40ea0e:	xor    eax,eax
  40ea10:	jmp    40eabb <__swc_fn_4fa09e82_000142_5e493395+0x2bb>
  40ea15:	mov    edi,0x20
  40ea1a:	xor    eax,eax
  40ea1c:	call   4071c0 <malloc@plt>
  40ea21:	test   rax,rax
  40ea24:	jne    40ea49 <__swc_fn_4fa09e82_000142_5e493395+0x249>
  40ea26:	mov    rdi,rbx
  40ea29:	mov    rsi,r15
  40ea2c:	xor    eax,eax
  40ea2e:	call   407160 <munmap@plt>
  40ea33:	movsxd rdi,DWORD PTR [r14]
  40ea36:	xor    eax,eax
  40ea38:	call   407040 <close@plt>
  40ea3d:	mov    rcx,r13
  40ea40:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40ea45:	xor    eax,eax
  40ea47:	jmp    40eabb <__swc_fn_4fa09e82_000142_5e493395+0x2bb>
  40ea49:	mov    rcx,QWORD PTR [rip+0x18338]        # 426d88 <__swc_bss_base_4fa09e82+0x2d48>
  40ea50:	mov    QWORD PTR [rsp+0x70],rcx
  40ea55:	mov    rcx,QWORD PTR [rsp+0xa0]
  40ea5d:	mov    QWORD PTR [rsp+0x78],rcx
  40ea62:	mov    QWORD PTR [rsp+0x80],r12
  40ea6a:	mov    rcx,QWORD PTR [rsp+0x50]
  40ea6f:	mov    QWORD PTR [rsp+0x88],rcx
  40ea77:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  40ea7d:	vmovups XMMWORD PTR [rax],xmm0
  40ea81:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  40ea8a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40ea8f:	mov    QWORD PTR [rip+0x182f2],rax        # 426d88 <__swc_bss_base_4fa09e82+0x2d48>
  40ea96:	mov    rax,QWORD PTR [rsp+0x50]
  40ea9b:	mov    rbx,QWORD PTR [rsp+0x98]
  40eaa3:	mov    QWORD PTR [rbx],rax
  40eaa6:	movsxd rdi,DWORD PTR [r14]
  40eaa9:	xor    eax,eax
  40eaab:	call   407040 <close@plt>
  40eab0:	mov    rcx,r13
  40eab3:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40eab8:	mov    rax,r12
  40eabb:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40eac4:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40eacd:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40ead6:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40eadf:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40eae8:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40eaf1:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40eafa:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40eb03:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40eb0c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40eb15:	add    rsp,0x150
  40eb1c:	pop    r15
  40eb1e:	pop    r14
  40eb20:	pop    rsi
  40eb21:	pop    rdi
  40eb22:	pop    r13
  40eb24:	pop    r12
  40eb26:	pop    rbx
  40eb27:	ret
	...

000000000040eb30 <__swc_fn_4fa09e82_000145_c3e86ca0>:
  40eb30:	push   rbx
  40eb31:	sub    rsp,0xe0
  40eb38:	lea    rbx,[rsp+0x8]
  40eb3d:	vxorps xmm0,xmm0,xmm0
  40eb41:	vmovups YMMWORD PTR [rbx],ymm0
  40eb45:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40eb4a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40eb4f:	vzeroupper
  40eb52:	mov    DWORD PTR [rbx+0x60],0x0
  40eb59:	mov    r8,rbx
  40eb5c:	nop    DWORD PTR [rax+0x0]
  40eb60:	mov    r9,rcx
  40eb63:	movabs rcx,0xcccccccccccccccd
  40eb6d:	mov    rax,r9
  40eb70:	mul    rcx
  40eb73:	mov    r10,rdx
  40eb76:	shr    r10,0x3
  40eb7a:	mov    rcx,r10
  40eb7d:	imul   rdx,r10,0xa
  40eb81:	sub    r9,rdx
  40eb84:	mov    rdx,QWORD PTR [rip+0x49b5]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40eb8b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  40eb90:	mov    BYTE PTR [r8],dl
  40eb93:	lea    rdx,[r8+0x1]
  40eb97:	mov    r8,rdx
  40eb9a:	test   r10,r10
  40eb9d:	jne    40eb60 <__swc_fn_4fa09e82_000145_c3e86ca0+0x30>
  40eb9f:	mov    BYTE PTR [rdx],0x0
  40eba2:	sub    r8,0x1
  40eba6:	mov    rax,rbx
  40eba9:	cmp    rax,r8
  40ebac:	jae    40ebc6 <__swc_fn_4fa09e82_000145_c3e86ca0+0x96>
  40ebae:	xchg   ax,ax
  40ebb0:	mov    cl,BYTE PTR [r8]
  40ebb3:	mov    dl,BYTE PTR [rax]
  40ebb5:	mov    BYTE PTR [r8],dl
  40ebb8:	sub    r8,0x1
  40ebbc:	mov    BYTE PTR [rax],cl
  40ebbe:	inc    rax
  40ebc1:	cmp    rax,r8
  40ebc4:	jb     40ebb0 <__swc_fn_4fa09e82_000145_c3e86ca0+0x80>
  40ebc6:	xor    eax,eax
  40ebc8:	test   rbx,rbx
  40ebcb:	je     40ebee <__swc_fn_4fa09e82_000145_c3e86ca0+0xbe>
  40ebcd:	mov    rcx,rbx
  40ebd0:	mov    dl,BYTE PTR [rcx]
  40ebd2:	test   dl,dl
  40ebd4:	je     40ebee <__swc_fn_4fa09e82_000145_c3e86ca0+0xbe>
  40ebd6:	cs nop WORD PTR [rax+rax*1+0x0]
  40ebe0:	add    rcx,0x1
  40ebe4:	add    rax,0x1
  40ebe8:	mov    dl,BYTE PTR [rcx]
  40ebea:	test   dl,dl
  40ebec:	jne    40ebe0 <__swc_fn_4fa09e82_000145_c3e86ca0+0xb0>
  40ebee:	mov    QWORD PTR [rbx+0xa8],rbx
  40ebf5:	mov    QWORD PTR [rbx+0xb0],rax
  40ebfc:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40ec04:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40ec0c:	lea    rcx,[rbx+0xb8]
  40ec13:	call   409870 <__swc_fn_4fa09e82_000117_3f5cfdef>
  40ec18:	add    rsp,0xe0
  40ec1f:	pop    rbx
  40ec20:	ret
	...

000000000040ec30 <__swc_fn_4fa09e82_000148_e7bfe29e>:
  40ec30:	sub    rsp,0x8
  40ec34:	mov    rax,QWORD PTR [rcx+0x8]
  40ec38:	mov    r8,QWORD PTR [rdx+0x8]
  40ec3c:	cmp    rax,r8
  40ec3f:	je     40ec48 <__swc_fn_4fa09e82_000148_e7bfe29e+0x18>
  40ec41:	xor    eax,eax
  40ec43:	add    rsp,0x8
  40ec47:	ret
  40ec48:	test   rax,rax
  40ec4b:	jne    40ec5c <__swc_fn_4fa09e82_000148_e7bfe29e+0x2c>
  40ec4d:	test   r8,r8
  40ec50:	jne    40ec5c <__swc_fn_4fa09e82_000148_e7bfe29e+0x2c>
  40ec52:	mov    eax,0x1
  40ec57:	add    rsp,0x8
  40ec5b:	ret
  40ec5c:	mov    rcx,QWORD PTR [rcx]
  40ec5f:	mov    rdx,QWORD PTR [rdx]
  40ec62:	test   rcx,rcx
  40ec65:	sete   r8b
  40ec69:	test   rdx,rdx
  40ec6c:	sete   r9b
  40ec70:	or     r8b,r9b
  40ec73:	je     40ec80 <__swc_fn_4fa09e82_000148_e7bfe29e+0x50>
  40ec75:	cmp    rcx,rdx
  40ec78:	sete   al
  40ec7b:	add    rsp,0x8
  40ec7f:	ret
  40ec80:	cmp    rcx,rdx
  40ec83:	jne    40ec8f <__swc_fn_4fa09e82_000148_e7bfe29e+0x5f>
  40ec85:	mov    eax,0x1
  40ec8a:	add    rsp,0x8
  40ec8e:	ret
  40ec8f:	mov    r8,rax
  40ec92:	call   410e70 <__swc_fn_4fa09e82_000107_aba05410>
  40ec97:	test   eax,eax
  40ec99:	sete   al
  40ec9c:	add    rsp,0x8
  40eca0:	ret
	...

000000000040ecb0 <__swc_fn_4fa09e82_000151_365b4daf>:
  40ecb0:	vxorps xmm0,xmm0,xmm0
  40ecb4:	vmovups XMMWORD PTR [rcx],xmm0
  40ecb8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40ecbd:	vxorps xmm0,xmm0,xmm0
  40ecc1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40ecc6:	vmovups xmm0,XMMWORD PTR [rip+0x492a]        # 4135f8 <__swc_rdata_base_4fa09e82+0x4e8>
  40ecce:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40ecd3:	ret
	...

000000000040ece0 <__swc_fn_4fa09e82_000154_365b4daf>:
  40ece0:	vxorps xmm0,xmm0,xmm0
  40ece4:	vmovups XMMWORD PTR [rcx],xmm0
  40ece8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40eced:	vxorps xmm0,xmm0,xmm0
  40ecf1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40ecf6:	vmovups xmm0,XMMWORD PTR [rip+0x4a1a]        # 413718 <__swc_rdata_base_4fa09e82+0x608>
  40ecfe:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40ed03:	mov    QWORD PTR [rcx+0x40],0x0
  40ed0b:	ret
  40ed0c:	add    BYTE PTR [rax],al
	...

000000000040ed10 <__swc_fn_4fa09e82_000157_9e2052d6>:
  40ed10:	push   rbx
  40ed11:	sub    rsp,0x70
  40ed15:	mov    rax,QWORD PTR [rcx]
  40ed18:	mov    rbx,QWORD PTR [rcx+0x8]
  40ed1c:	vxorps xmm0,xmm0,xmm0
  40ed20:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40ed26:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40ed2c:	vzeroupper
  40ed2f:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40ed35:	mov    QWORD PTR [rsp+0x48],rdx
  40ed3a:	mov    QWORD PTR [rsp+0x50],r8
  40ed3f:	mov    rcx,rax
  40ed42:	lea    rdx,[rsp+0x8]
  40ed47:	mov    rbx,QWORD PTR [rbx+0x18]
  40ed4b:	call   rbx
  40ed4d:	add    rsp,0x70
  40ed51:	pop    rbx
  40ed52:	ret
	...

000000000040ed60 <__swc_fn_4fa09e82_000160_6861d596>:
  40ed60:	push   rbx
  40ed61:	push   rsi
  40ed62:	push   rdi
  40ed63:	mov    rbx,r8
  40ed66:	mov    rsi,rcx
  40ed69:	mov    rdi,rdx
  40ed6c:	call   411b90 <__swc_fn_4fa09e82_000158_3495a3ca>
  40ed71:	vmovups xmm0,XMMWORD PTR [rbx]
  40ed75:	vmovups XMMWORD PTR [rsi],xmm0
  40ed79:	mov    QWORD PTR [rsi+0x18],rdi
  40ed7d:	pop    rdi
  40ed7e:	pop    rsi
  40ed7f:	pop    rbx
  40ed80:	ret
	...

000000000040ed90 <__swc_fn_4fa09e82_000163_61e293bf>:
  40ed90:	push   rbx
  40ed91:	push   rsi
  40ed92:	push   rdi
  40ed93:	push   r12
  40ed95:	push   r13
  40ed97:	sub    rsp,0x50
  40ed9b:	mov    rbx,rcx
  40ed9e:	mov    rsi,rdx
  40eda1:	vmovups xmm0,XMMWORD PTR [rip+0x4a7f]        # 413828 <__swc_rdata_base_4fa09e82+0x718>
  40eda9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40edaf:	vmovups xmm0,XMMWORD PTR [rip+0x4a81]        # 413838 <__swc_rdata_base_4fa09e82+0x728>
  40edb7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40edbd:	vxorps xmm0,xmm0,xmm0
  40edc1:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40edc7:	mov    rcx,rdx
  40edca:	call   40e730 <__swc_fn_4fa09e82_000139_22d6573c>
  40edcf:	mov    rdi,rax
  40edd2:	test   rax,rax
  40edd5:	jne    40ee06 <__swc_fn_4fa09e82_000163_61e293bf+0x76>
  40edd7:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40eddd:	vmovups XMMWORD PTR [rbx],xmm0
  40ede1:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40ede7:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40edec:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40edf2:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40edf7:	mov    rax,rbx
  40edfa:	add    rsp,0x50
  40edfe:	pop    r13
  40ee00:	pop    r12
  40ee02:	pop    rdi
  40ee03:	pop    rsi
  40ee04:	pop    rbx
  40ee05:	ret
  40ee06:	mov    rcx,rdi
  40ee09:	call   40b320 <__swc_fn_4fa09e82_000162_b553c03d>
  40ee0e:	mov    r11,rax
  40ee11:	test   rax,rax
  40ee14:	je     40ee1e <__swc_fn_4fa09e82_000163_61e293bf+0x8e>
  40ee16:	mov    al,BYTE PTR [r11+0x24]
  40ee1a:	test   al,al
  40ee1c:	jne    40ee4d <__swc_fn_4fa09e82_000163_61e293bf+0xbd>
  40ee1e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ee24:	vmovups XMMWORD PTR [rbx],xmm0
  40ee28:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40ee2e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ee33:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40ee39:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ee3e:	mov    rax,rbx
  40ee41:	add    rsp,0x50
  40ee45:	pop    r13
  40ee47:	pop    r12
  40ee49:	pop    rdi
  40ee4a:	pop    rsi
  40ee4b:	pop    rbx
  40ee4c:	ret
  40ee4d:	sub    rsi,rdi
  40ee50:	mov    eax,0xffffffff
  40ee55:	cmp    rsi,rax
  40ee58:	jbe    40ee89 <__swc_fn_4fa09e82_000163_61e293bf+0xf9>
  40ee5a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ee60:	vmovups XMMWORD PTR [rbx],xmm0
  40ee64:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40ee6a:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ee6f:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40ee75:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ee7a:	mov    rax,rbx
  40ee7d:	add    rsp,0x50
  40ee81:	pop    r13
  40ee83:	pop    r12
  40ee85:	pop    rdi
  40ee86:	pop    rsi
  40ee87:	pop    rbx
  40ee88:	ret
  40ee89:	mov    rdi,QWORD PTR [r11+0x10]
  40ee8d:	mov    eax,DWORD PTR [r11+0x20]
  40ee91:	xor    ecx,ecx
  40ee93:	test   rax,rax
  40ee96:	jbe    40efe8 <__swc_fn_4fa09e82_000163_61e293bf+0x258>
  40ee9c:	nop    DWORD PTR [rax+0x0]
  40eea0:	mov    edx,ecx
  40eea2:	imul   r12,rdx,0x14
  40eea6:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40eeab:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40eeb0:	mov    r9d,esi
  40eeb3:	cmp    r9,rdx
  40eeb6:	jb     40efdb <__swc_fn_4fa09e82_000163_61e293bf+0x24b>
  40eebc:	add    rdx,r8
  40eebf:	mov    r8d,esi
  40eec2:	cmp    r8,rdx
  40eec5:	jae    40efdb <__swc_fn_4fa09e82_000163_61e293bf+0x24b>
  40eecb:	lea    rsi,[rsp+0x38]
  40eed0:	mov    eax,DWORD PTR [rdi+0xc]
  40eed3:	mov    DWORD PTR [rsp+0x38],eax
  40eed7:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40eedc:	mov    rcx,rdi
  40eedf:	mov    rdx,QWORD PTR [r11+0x18]
  40eee3:	mov    r8,rsi
  40eee6:	mov    r8d,DWORD PTR [r8]
  40eee9:	mov    r9,rax
  40eeec:	lea    r10,[rsp+0x10]
  40eef1:	call   411be0 <__swc_fn_4fa09e82_000161_dfca9093>
  40eef6:	test   al,al
  40eef8:	jne    40ef2b <__swc_fn_4fa09e82_000163_61e293bf+0x19b>
  40eefa:	vmovups xmm0,XMMWORD PTR [rip+0x4956]        # 413858 <__swc_rdata_base_4fa09e82+0x748>
  40ef02:	vmovups XMMWORD PTR [rbx],xmm0
  40ef06:	vmovups xmm0,XMMWORD PTR [rip+0x495a]        # 413868 <__swc_rdata_base_4fa09e82+0x758>
  40ef0e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ef13:	vxorps xmm0,xmm0,xmm0
  40ef17:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ef1c:	mov    rax,rbx
  40ef1f:	add    rsp,0x50
  40ef23:	pop    r13
  40ef25:	pop    r12
  40ef27:	pop    rdi
  40ef28:	pop    rsi
  40ef29:	pop    rbx
  40ef2a:	ret
  40ef2b:	lea    r13,[rsp+0x3c]
  40ef30:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40ef35:	mov    DWORD PTR [rsp+0x3c],eax
  40ef39:	test   eax,eax
  40ef3b:	je     40ef8c <__swc_fn_4fa09e82_000163_61e293bf+0x1fc>
  40ef3d:	mov    rcx,rdi
  40ef40:	mov    rdx,QWORD PTR [r11+0x18]
  40ef44:	mov    r8d,DWORD PTR [rsi]
  40ef47:	mov    rax,r13
  40ef4a:	mov    r9d,DWORD PTR [rax]
  40ef4d:	lea    r10,[rsp+0x20]
  40ef52:	call   411be0 <__swc_fn_4fa09e82_000161_dfca9093>
  40ef57:	test   al,al
  40ef59:	jne    40ef8c <__swc_fn_4fa09e82_000163_61e293bf+0x1fc>
  40ef5b:	vmovups xmm0,XMMWORD PTR [rip+0x4925]        # 413888 <__swc_rdata_base_4fa09e82+0x778>
  40ef63:	vmovups XMMWORD PTR [rbx],xmm0
  40ef67:	vmovups xmm0,XMMWORD PTR [rip+0x4929]        # 413898 <__swc_rdata_base_4fa09e82+0x788>
  40ef6f:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ef74:	vxorps xmm0,xmm0,xmm0
  40ef78:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ef7d:	mov    rax,rbx
  40ef80:	add    rsp,0x50
  40ef84:	pop    r13
  40ef86:	pop    r12
  40ef88:	pop    rdi
  40ef89:	pop    rsi
  40ef8a:	pop    rbx
  40ef8b:	ret
  40ef8c:	mov    eax,0x1
  40ef91:	rex mov BYTE PTR [rsp+0x8],al
  40ef96:	cmp    DWORD PTR [r13+0x0],0x0
  40ef9b:	je     40efac <__swc_fn_4fa09e82_000163_61e293bf+0x21c>
  40ef9d:	rex mov BYTE PTR [rsp+0x9],0x1
  40efa3:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40efa8:	mov    DWORD PTR [rsp+0x30],eax
  40efac:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40efb2:	vmovups XMMWORD PTR [rbx],xmm0
  40efb6:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40efbc:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40efc1:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40efc7:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40efcc:	mov    rax,rbx
  40efcf:	add    rsp,0x50
  40efd3:	pop    r13
  40efd5:	pop    r12
  40efd7:	pop    rdi
  40efd8:	pop    rsi
  40efd9:	pop    rbx
  40efda:	ret
  40efdb:	add    rcx,0x1
  40efdf:	cmp    rcx,rax
  40efe2:	jb     40eea0 <__swc_fn_4fa09e82_000163_61e293bf+0x110>
  40efe8:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40efee:	vmovups XMMWORD PTR [rbx],xmm0
  40eff2:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40eff8:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40effd:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40f003:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40f008:	mov    rax,rbx
  40f00b:	add    rsp,0x50
  40f00f:	pop    r13
  40f011:	pop    r12
  40f013:	pop    rdi
  40f014:	pop    rsi
  40f015:	pop    rbx
  40f016:	ret
	...

000000000040f020 <__swc_fn_4fa09e82_000166_56054fe7>:
  40f020:	sub    rsp,0x48
  40f024:	call   40e400 <__swc_fn_4fa09e82_000124_e4107ade>
  40f029:	cmp    rax,0xffffffffffffffff
  40f02d:	je     40f034 <__swc_fn_4fa09e82_000166_56054fe7+0x14>
  40f02f:	add    rsp,0x48
  40f033:	ret
  40f034:	lea    rcx,[rip+0x488d]        # 4138c8 <__swc_rdata_base_4fa09e82+0x7b8>
  40f03b:	vmovups xmm0,XMMWORD PTR [rip+0x4895]        # 4138d8 <__swc_rdata_base_4fa09e82+0x7c8>
  40f043:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f049:	vmovups xmm0,XMMWORD PTR [rip+0x4897]        # 4138e8 <__swc_rdata_base_4fa09e82+0x7d8>
  40f051:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f057:	vmovups xmm0,XMMWORD PTR [rip+0x4899]        # 4138f8 <__swc_rdata_base_4fa09e82+0x7e8>
  40f05f:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40f065:	lea    rdx,[rsp+0x8]
  40f06a:	mov    QWORD PTR [rsp+0x38],rax
  40f06f:	call   40dea0 <__swc_fn_4fa09e82_000103_0d4cc079>
  40f074:	mov    rax,QWORD PTR [rsp+0x38]
  40f079:	jmp    40f02f <__swc_fn_4fa09e82_000166_56054fe7+0xf>
  40f07b:	add    BYTE PTR [rax],al
  40f07d:	add    BYTE PTR [rax],al
	...

000000000040f080 <__swc_fn_4fa09e82_000169_0ad81c51>:
  40f080:	push   rbx
  40f081:	push   rsi
  40f082:	sub    rsp,0x28
  40f086:	mov    rbx,rcx
  40f089:	mov    DWORD PTR [rsp+0x8],0xbf0
  40f091:	mov    ecx,0xbf0
  40f096:	call   40da90 <__swc_fn_4fa09e82_000079_633af784>
  40f09b:	mov    rsi,rax
  40f09e:	test   rax,rax
  40f0a1:	jne    40f0ac <__swc_fn_4fa09e82_000169_0ad81c51+0x2c>
  40f0a3:	xor    eax,eax
  40f0a5:	add    rsp,0x28
  40f0a9:	pop    rsi
  40f0aa:	pop    rbx
  40f0ab:	ret
  40f0ac:	vxorps xmm0,xmm0,xmm0
  40f0b0:	xor    eax,eax
  40f0b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f0bc:	nop    DWORD PTR [rax+0x0]
  40f0c0:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40f0c5:	add    rax,0x10
  40f0c9:	cmp    rax,0xbf0
  40f0d0:	jne    40f0c0 <__swc_fn_4fa09e82_000169_0ad81c51+0x40>
  40f0d2:	lea    rax,[rbx+0x1]
  40f0d6:	mov    QWORD PTR [rsi+0x9c0],rax
  40f0dd:	mov    rcx,rbx
  40f0e0:	mov    rdx,rsi
  40f0e3:	call   411f40 <__swc_fn_4fa09e82_000167_c370e18e>
  40f0e8:	test   al,al
  40f0ea:	jne    40f0fd <__swc_fn_4fa09e82_000169_0ad81c51+0x7d>
  40f0ec:	mov    rcx,rsi
  40f0ef:	call   4104d0 <__swc_fn_4fa09e82_000080_207908fe>
  40f0f4:	xor    eax,eax
  40f0f6:	add    rsp,0x28
  40f0fa:	pop    rsi
  40f0fb:	pop    rbx
  40f0fc:	ret
  40f0fd:	lea    rcx,[rsp+0x18]
  40f102:	call   410a50 <__swc_fn_4fa09e82_000092_809deff5>
  40f107:	mov    rax,rsi
  40f10a:	add    rsp,0x28
  40f10e:	pop    rsi
  40f10f:	pop    rbx
  40f110:	ret
	...

000000000040f120 <__swc_fn_4fa09e82_000172_8c19aea5>:
  40f120:	xor    eax,eax
  40f122:	mov    edx,0x1
  40f127:	lock cmpxchg QWORD PTR [rcx],rdx
  40f12c:	test   rax,rax
  40f12f:	jne    40f132 <__swc_fn_4fa09e82_000172_8c19aea5+0x12>
  40f131:	ret
  40f132:	cs nop WORD PTR [rax+rax*1+0x0]
  40f13c:	nop    DWORD PTR [rax+0x0]
  40f140:	mov    rax,QWORD PTR [rcx]
  40f143:	test   rax,rax
  40f146:	je     40f120 <__swc_fn_4fa09e82_000172_8c19aea5>
  40f148:	jmp    40f140 <__swc_fn_4fa09e82_000172_8c19aea5+0x20>
  40f14a:	add    BYTE PTR [rax],al
  40f14c:	add    BYTE PTR [rax],al
	...

000000000040f150 <__swc_fn_4fa09e82_000175_02e645b4>:
  40f150:	push   rsi
  40f151:	push   rdi
  40f152:	sub    rsp,0x38
  40f156:	mov    rsi,rcx
  40f159:	call   411f50 <__swc_fn_4fa09e82_000170_4694b8ad>
  40f15e:	mov    rdi,rax
  40f161:	call   4116e0 <__swc_fn_4fa09e82_000131_375c7357>
  40f166:	mov    r8,rax
  40f169:	mov    rcx,rdi
  40f16c:	call   40f120 <__swc_fn_4fa09e82_000172_8c19aea5>
  40f171:	mov    rax,QWORD PTR [rdi+0x8]
  40f175:	test   rax,rax
  40f178:	je     40f1b5 <__swc_fn_4fa09e82_000175_02e645b4+0x65>
  40f17a:	nop    WORD PTR [rax+rax*1+0x0]
  40f180:	cmp    rax,rsi
  40f183:	je     40f1b5 <__swc_fn_4fa09e82_000175_02e645b4+0x65>
  40f185:	mov    r9,QWORD PTR [rax]
  40f188:	cmp    QWORD PTR [rax+0x20],r8
  40f18c:	jne    40f1ad <__swc_fn_4fa09e82_000175_02e645b4+0x5d>
  40f18e:	mov    rcx,rdi
  40f191:	mov    rdx,rax
  40f194:	mov    QWORD PTR [rsp+0x28],r8
  40f199:	mov    QWORD PTR [rsp+0x30],r9
  40f19e:	call   40b740 <__swc_fn_4fa09e82_000174_e17a224b>
  40f1a3:	mov    r8,QWORD PTR [rsp+0x28]
  40f1a8:	mov    r9,QWORD PTR [rsp+0x30]
  40f1ad:	mov    rax,r9
  40f1b0:	test   r9,r9
  40f1b3:	jne    40f180 <__swc_fn_4fa09e82_000175_02e645b4+0x30>
  40f1b5:	xor    eax,eax
  40f1b7:	mov    QWORD PTR [rdi],rax
  40f1ba:	add    rsp,0x38
  40f1be:	pop    rdi
  40f1bf:	pop    rsi
  40f1c0:	ret
	...

000000000040f1d0 <__swc_fn_4fa09e82_000178_1ca87929>:
  40f1d0:	push   rdi
  40f1d1:	push   rsi
  40f1d2:	sub    rsp,0xb8
  40f1d9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40f1df:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40f1e5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40f1eb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40f1f1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40f1f7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40f1fd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40f203:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40f20c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40f215:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40f21e:	vxorps xmm0,xmm0,xmm0
  40f222:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f228:	mov    edi,0x1
  40f22d:	lea    rsi,[rsp+0x8]
  40f232:	xor    eax,eax
  40f234:	call   407130 <clock_gettime@plt>
  40f239:	vxorpd xmm0,xmm0,xmm0
  40f23d:	mov    rax,QWORD PTR [rsp+0x8]
  40f242:	vcvtsi2sd xmm0,xmm0,rax
  40f247:	vxorpd xmm1,xmm1,xmm1
  40f24b:	mov    rax,QWORD PTR [rsp+0x10]
  40f250:	vcvtsi2sd xmm1,xmm1,rax
  40f255:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x46ab]        # 413908 <__swc_rdata_base_4fa09e82+0x7f8>
  40f25d:	vaddsd xmm0,xmm0,xmm1
  40f261:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40f267:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40f26d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40f273:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40f279:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40f27f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40f285:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40f28b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40f294:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40f29d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40f2a6:	add    rsp,0xb8
  40f2ad:	pop    rsi
  40f2ae:	pop    rdi
  40f2af:	ret
	...

000000000040f2c0 <__swc_fn_4fa09e82_000002_102336c4>:
  40f2c0:	sub    rsp,0x8
  40f2c4:	call   411030 <__swc_fn_4fa09e82_000110_9f5af8ae>
  40f2c9:	mov    rcx,rax
  40f2cc:	test   rax,rax
  40f2cf:	je     40f2f6 <__swc_fn_4fa09e82_000002_102336c4+0x36>
  40f2d1:	lea    rdx,[rip+0x14d68]        # 424040 <__swc_bss_base_4fa09e82>
  40f2d8:	mov    r8,QWORD PTR [rip+0x14d61]        # 424040 <__swc_bss_base_4fa09e82>
  40f2df:	nop
  40f2e0:	lea    r9,[r8+0x1]
  40f2e4:	mov    rax,r8
  40f2e7:	lock cmpxchg QWORD PTR [rdx],r9
  40f2ec:	cmp    rax,r8
  40f2ef:	je     40f2f6 <__swc_fn_4fa09e82_000002_102336c4+0x36>
  40f2f1:	mov    r8,rax
  40f2f4:	jmp    40f2e0 <__swc_fn_4fa09e82_000002_102336c4+0x20>
  40f2f6:	mov    rax,rcx
  40f2f9:	add    rsp,0x8
  40f2fd:	ret
	...

000000000040f300 <__swc_fn_4fa09e82_000005_6a556171>:
  40f300:	mov    r8d,edx
  40f303:	xor    eax,eax
  40f305:	tzcnt  eax,edx
  40f309:	shrx   r9d,edx,eax
  40f30e:	mov    DWORD PTR [rcx+0x2c],edx
  40f311:	xor    eax,eax
  40f313:	tzcnt  eax,edx
  40f317:	mov    BYTE PTR [rcx+0x38],al
  40f31a:	mov    eax,0xffffffff
  40f31f:	xor    edx,edx
  40f321:	div    r8d
  40f324:	mov    DWORD PTR [rcx+0x34],eax
  40f327:	mov    eax,r9d
  40f32a:	mov    edx,r9d
  40f32d:	imul   edx,r9d
  40f331:	mov    r8d,0x2
  40f337:	sub    r8d,edx
  40f33a:	imul   eax,r8d
  40f33e:	mov    edx,r9d
  40f341:	imul   edx,eax
  40f344:	mov    r8d,0x2
  40f34a:	sub    r8d,edx
  40f34d:	imul   eax,r8d
  40f351:	mov    edx,r9d
  40f354:	imul   edx,eax
  40f357:	mov    r8d,0x2
  40f35d:	sub    r8d,edx
  40f360:	imul   eax,r8d
  40f364:	mov    edx,r9d
  40f367:	imul   edx,eax
  40f36a:	mov    r8d,0x2
  40f370:	sub    r8d,edx
  40f373:	imul   eax,r8d
  40f377:	imul   r9d,eax
  40f37b:	mov    edx,0x2
  40f380:	sub    edx,r9d
  40f383:	imul   eax,edx
  40f386:	mov    DWORD PTR [rcx+0x30],eax
  40f389:	ret
  40f38a:	add    BYTE PTR [rax],al
  40f38c:	add    BYTE PTR [rax],al
	...

000000000040f390 <__swc_fn_4fa09e82_000008_b2f73e0d>:
  40f390:	xor    eax,eax
  40f392:	mov    DWORD PTR [rcx+0x68],eax
  40f395:	ret
	...

000000000040f3a0 <__swc_fn_4fa09e82_000011_71c91685>:
  40f3a0:	mov    eax,DWORD PTR [rcx+0x28]
  40f3a3:	shlx   eax,edx,eax
  40f3a8:	shl    rax,0x10
  40f3ac:	lea    rdx,[rcx+rax*1]
  40f3b0:	lea    rax,[rcx+0x3000]
  40f3b7:	cmp    rdx,rax
  40f3ba:	cmovae rax,rdx
  40f3be:	ret
	...

000000000040f3c0 <__swc_fn_4fa09e82_000014_be17798c>:
  40f3c0:	push   rsi
  40f3c1:	push   rdi
  40f3c2:	push   r12
  40f3c4:	push   r13
  40f3c6:	push   r14
  40f3c8:	mov    rsi,rdx
  40f3cb:	mov    rdi,rcx
  40f3ce:	rex mov dl,BYTE PTR [rsi+0x3a]
  40f3d2:	mov    ecx,DWORD PTR [rdi+0x28]
  40f3d5:	shr    dl,cl
  40f3d7:	mov    r12d,0x1
  40f3dd:	mov    ecx,edx
  40f3df:	shl    r12,cl
  40f3e2:	mov    r13d,DWORD PTR [rsi+0x3c]
  40f3e6:	rex mov BYTE PTR [rsi+0x3b],0x0
  40f3eb:	mov    QWORD PTR [rsi+0x40],0x0
  40f3f3:	mov    QWORD PTR [rsi],0x0
  40f3fa:	mov    rax,QWORD PTR [rsi+0x10]
  40f3fe:	mov    QWORD PTR [rsi+0x20],rax
  40f402:	lea    r14,[rip+0x14c3f]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  40f409:	mov    rax,QWORD PTR [r14]
  40f40c:	shr    rax,0x2
  40f410:	mov    rcx,rax
  40f413:	cmp    rax,0x800000
  40f41a:	mov    eax,0x800000
  40f41f:	cmovb  rcx,rax
  40f423:	lea    r8,[rip+0x14c2e]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40f42a:	mov    rax,QWORD PTR [r8]
  40f42d:	mov    r9,rax
  40f430:	lea    r10,[r9+r13*1]
  40f434:	cmp    r10,rcx
  40f437:	ja     40f45b <__swc_fn_4fa09e82_000014_be17798c+0x9b>
  40f439:	mov    rax,r9
  40f43c:	lock cmpxchg QWORD PTR [r8],r10
  40f441:	cmp    rax,r9
  40f444:	je     40f44b <__swc_fn_4fa09e82_000014_be17798c+0x8b>
  40f446:	mov    r9,rax
  40f449:	jmp    40f430 <__swc_fn_4fa09e82_000014_be17798c+0x70>
  40f44b:	mov    rcx,rdi
  40f44e:	mov    rdx,r12
  40f451:	call   40c250 <__swc_fn_4fa09e82_000016_a0b588d0>
  40f456:	jmp    40f4dd <__swc_fn_4fa09e82_000014_be17798c+0x11d>
  40f45b:	mov    rcx,rdi
  40f45e:	movzx  edx,dl
  40f461:	call   40f3a0 <__swc_fn_4fa09e82_000011_71c91685>
  40f466:	test   r13,r13
  40f469:	je     40f4d6 <__swc_fn_4fa09e82_000014_be17798c+0x116>
  40f46f:	mov    rcx,rax
  40f472:	mov    rdx,r13
  40f475:	call   4111b0 <__swc_fn_4fa09e82_000113_2f7f9346>
  40f47a:	mov    rcx,QWORD PTR [rip+0x14bc7]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  40f481:	cs nop WORD PTR [rax+rax*1+0x0]
  40f48b:	nop    DWORD PTR [rax+rax*1+0x0]
  40f490:	mov    rdx,rcx
  40f493:	sub    rdx,r13
  40f496:	mov    rax,rcx
  40f499:	lock cmpxchg QWORD PTR [r14],rdx
  40f49e:	cmp    rax,rcx
  40f4a1:	je     40f4a8 <__swc_fn_4fa09e82_000014_be17798c+0xe8>
  40f4a3:	mov    rcx,rax
  40f4a6:	jmp    40f490 <__swc_fn_4fa09e82_000014_be17798c+0xd0>
  40f4a8:	lea    rcx,[rip+0x14bb1]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  40f4af:	mov    rdx,QWORD PTR [rip+0x14baa]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  40f4b6:	cs nop WORD PTR [rax+rax*1+0x0]
  40f4c0:	lea    r8,[rdx+0x1]
  40f4c4:	mov    rax,rdx
  40f4c7:	lock cmpxchg QWORD PTR [rcx],r8
  40f4cc:	cmp    rax,rdx
  40f4cf:	je     40f4d6 <__swc_fn_4fa09e82_000014_be17798c+0x116>
  40f4d1:	mov    rdx,rax
  40f4d4:	jmp    40f4c0 <__swc_fn_4fa09e82_000014_be17798c+0x100>
  40f4d6:	mov    DWORD PTR [rsi+0x3c],0x0
  40f4dd:	mov    rcx,rdi
  40f4e0:	mov    rdx,r12
  40f4e3:	call   407600 <__swc_fn_4fa09e82_000018_77ece227>
  40f4e8:	pop    r14
  40f4ea:	pop    r13
  40f4ec:	pop    r12
  40f4ee:	pop    rdi
  40f4ef:	pop    rsi
  40f4f0:	ret
	...

000000000040f500 <__swc_fn_4fa09e82_000017_f003fc47>:
  40f500:	mov    r8,QWORD PTR [rcx+0x48]
  40f504:	test   r8,rdx
  40f507:	je     40f538 <__swc_fn_4fa09e82_000017_f003fc47+0x38>
  40f509:	nop    DWORD PTR [rax+0x0]
  40f510:	mov    rax,rdx
  40f513:	not    rax
  40f516:	mov    r9,r8
  40f519:	and    r9,rax
  40f51c:	mov    rax,r8
  40f51f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40f525:	cmp    rax,r8
  40f528:	jne    40f530 <__swc_fn_4fa09e82_000017_f003fc47+0x30>
  40f52a:	mov    eax,0x1
  40f52f:	ret
  40f530:	mov    r8,rax
  40f533:	test   rax,rdx
  40f536:	jne    40f510 <__swc_fn_4fa09e82_000017_f003fc47+0x10>
  40f538:	xor    eax,eax
  40f53a:	ret
  40f53b:	add    BYTE PTR [rax],al
  40f53d:	add    BYTE PTR [rax],al
	...

000000000040f540 <__swc_fn_4fa09e82_000020_4285d9c5>:
  40f540:	push   rsi
  40f541:	push   rdi
  40f542:	push   r12
  40f544:	push   r13
  40f546:	sub    rsp,0x8
  40f54a:	mov    rsi,rdx
  40f54d:	mov    rdi,rcx
  40f550:	lea    r12,[rip+0x14c99]        # 4241f0 <__swc_bss_base_4fa09e82+0x1b0>
  40f557:	mov    rcx,r12
  40f55a:	call   40e720 <__swc_fn_4fa09e82_000136_db32cc57>
  40f55f:	xor    eax,eax
  40f561:	mov    rcx,QWORD PTR [rip+0x14c90]        # 4241f8 <__swc_bss_base_4fa09e82+0x1b8>
  40f568:	mov    r13,rcx
  40f56b:	test   r13,r13
  40f56e:	je     40f5bb <__swc_fn_4fa09e82_000020_4285d9c5+0x7b>
  40f570:	mov    rcx,QWORD PTR [r13+0x10]
  40f574:	cmp    DWORD PTR [r13+0x28],esi
  40f578:	jne    40f5b0 <__swc_fn_4fa09e82_000020_4285d9c5+0x70>
  40f57a:	test   rax,rax
  40f57d:	jne    40f588 <__swc_fn_4fa09e82_000020_4285d9c5+0x48>
  40f57f:	mov    QWORD PTR [rip+0x14c72],rcx        # 4241f8 <__swc_bss_base_4fa09e82+0x1b8>
  40f586:	jmp    40f58c <__swc_fn_4fa09e82_000020_4285d9c5+0x4c>
  40f588:	mov    QWORD PTR [rax+0x10],rcx
  40f58c:	vxorps xmm0,xmm0,xmm0
  40f590:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40f596:	mov    QWORD PTR [r13+0x8],rdi
  40f59a:	mov    rcx,r12
  40f59d:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40f5a2:	mov    rax,r13
  40f5a5:	add    rsp,0x8
  40f5a9:	pop    r13
  40f5ab:	pop    r12
  40f5ad:	pop    rdi
  40f5ae:	pop    rsi
  40f5af:	ret
  40f5b0:	mov    rax,r13
  40f5b3:	mov    r13,rcx
  40f5b6:	test   rcx,rcx
  40f5b9:	jne    40f570 <__swc_fn_4fa09e82_000020_4285d9c5+0x30>
  40f5bb:	mov    ecx,esi
  40f5bd:	call   40c280 <__swc_fn_4fa09e82_000019_447bb610>
  40f5c2:	mov    rsi,rax
  40f5c5:	test   rax,rax
  40f5c8:	jne    40f5df <__swc_fn_4fa09e82_000020_4285d9c5+0x9f>
  40f5ca:	mov    rcx,r12
  40f5cd:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40f5d2:	xor    eax,eax
  40f5d4:	add    rsp,0x8
  40f5d8:	pop    r13
  40f5da:	pop    r12
  40f5dc:	pop    rdi
  40f5dd:	pop    rsi
  40f5de:	ret
  40f5df:	mov    QWORD PTR [rsi+0x8],rdi
  40f5e3:	mov    rcx,r12
  40f5e6:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40f5eb:	mov    rax,rsi
  40f5ee:	add    rsp,0x8
  40f5f2:	pop    r13
  40f5f4:	pop    r12
  40f5f6:	pop    rdi
  40f5f7:	pop    rsi
  40f5f8:	ret
  40f5f9:	add    BYTE PTR [rax],al
  40f5fb:	add    BYTE PTR [rax],al
  40f5fd:	add    BYTE PTR [rax],al
	...

000000000040f600 <__swc_fn_4fa09e82_000023_e876734d>:
  40f600:	vxorps xmm0,xmm0,xmm0
  40f604:	xor    eax,eax
  40f606:	cs nop WORD PTR [rax+rax*1+0x0]
  40f610:	cs nop WORD PTR [rax+rax*1+0x0]
  40f61a:	nop    WORD PTR [rax+rax*1+0x0]
  40f620:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40f625:	add    rax,0x10
  40f629:	cmp    rax,0x2b00
  40f630:	jne    40f620 <__swc_fn_4fa09e82_000023_e876734d+0x20>
  40f632:	ret
	...

000000000040f640 <__swc_fn_4fa09e82_000026_e876734d>:
  40f640:	vxorps xmm0,xmm0,xmm0
  40f644:	vmovups XMMWORD PTR [rcx],xmm0
  40f648:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f64d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40f652:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40f657:	ret
	...

000000000040f660 <__swc_fn_4fa09e82_000029_e876734d>:
  40f660:	vxorps xmm0,xmm0,xmm0
  40f664:	vmovups XMMWORD PTR [rcx],xmm0
  40f668:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f66d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40f672:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40f677:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40f67c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40f681:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40f686:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40f68b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40f693:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40f69b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40f6a3:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40f6ab:	mov    QWORD PTR [rcx+0xc0],0x0
  40f6b6:	ret
	...

000000000040f6c0 <__swc_fn_4fa09e82_000032_f1940e30>:
  40f6c0:	push   rsi
  40f6c1:	push   rdi
  40f6c2:	sub    rsp,0x8
  40f6c6:	mov    rsi,rcx
  40f6c9:	lea    rdi,[rip+0x12930]        # 422000 <__swc_data_base_4fa09e82>
  40f6d0:	mov    rax,QWORD PTR [rdi]
  40f6d3:	cmp    rax,0xffffffffffffffff
  40f6d7:	je     40f6de <__swc_fn_4fa09e82_000032_f1940e30+0x1e>
  40f6d9:	mov    rdi,rax
  40f6dc:	jmp    40f70b <__swc_fn_4fa09e82_000032_f1940e30+0x4b>
  40f6de:	call   40e400 <__swc_fn_4fa09e82_000124_e4107ade>
  40f6e3:	mov    rcx,rax
  40f6e6:	cmp    rax,0xffffffffffffffff
  40f6ea:	je     40f71c <__swc_fn_4fa09e82_000032_f1940e30+0x5c>
  40f6ec:	mov    rax,0xffffffffffffffff
  40f6f3:	lock cmpxchg QWORD PTR [rdi],rcx
  40f6f8:	cmp    rax,0xffffffffffffffff
  40f6fc:	je     40f708 <__swc_fn_4fa09e82_000032_f1940e30+0x48>
  40f6fe:	mov    rdi,rax
  40f701:	call   411590 <__swc_fn_4fa09e82_000125_37eaf452>
  40f706:	jmp    40f70b <__swc_fn_4fa09e82_000032_f1940e30+0x4b>
  40f708:	mov    rdi,rcx
  40f70b:	cmp    rdi,0xffffffffffffffff
  40f70f:	je     40f71c <__swc_fn_4fa09e82_000032_f1940e30+0x5c>
  40f711:	mov    rcx,rdi
  40f714:	mov    rdx,rsi
  40f717:	call   409af0 <__swc_fn_4fa09e82_000126_7a81492f>
  40f71c:	add    rsp,0x8
  40f720:	pop    rdi
  40f721:	pop    rsi
  40f722:	ret
	...

000000000040f730 <__swc_fn_4fa09e82_000035_ab2e8c35>:
  40f730:	sub    rsp,0x38
  40f734:	mov    rax,rdx
  40f737:	test   dl,dl
  40f739:	jne    40f751 <__swc_fn_4fa09e82_000035_ab2e8c35+0x21>
  40f73b:	mov    rax,r8
  40f73e:	test   r8b,r8b
  40f741:	cmove  eax,r9d
  40f745:	test   al,al
  40f747:	cmove  eax,r10d
  40f74b:	test   al,al
  40f74d:	cmove  eax,r11d
  40f751:	test   al,al
  40f753:	jne    40f75a <__swc_fn_4fa09e82_000035_ab2e8c35+0x2a>
  40f755:	add    rsp,0x38
  40f759:	ret
  40f75a:	lea    rcx,[rip+0x39af]        # 413110 <__swc_rdata_base_4fa09e82>
  40f761:	vmovups xmm0,XMMWORD PTR [rip+0x39b7]        # 413120 <__swc_rdata_base_4fa09e82+0x10>
  40f769:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f76f:	vmovups xmm0,XMMWORD PTR [rip+0x39b9]        # 413130 <__swc_rdata_base_4fa09e82+0x20>
  40f777:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f77d:	vmovups xmm0,XMMWORD PTR [rip+0x39bb]        # 413140 <__swc_rdata_base_4fa09e82+0x30>
  40f785:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40f78b:	lea    rdx,[rsp+0x8]
  40f790:	call   40dea0 <__swc_fn_4fa09e82_000103_0d4cc079>
  40f795:	jmp    40f755 <__swc_fn_4fa09e82_000035_ab2e8c35+0x25>
	...

000000000040f7a0 <__swc_fn_4fa09e82_000038_292d55e5>:
  40f7a0:	sub    rsp,0x8
  40f7a4:	mov    eax,0x1000
  40f7a9:	test   eax,eax
  40f7ab:	mov    r8d,0x8
  40f7b1:	cmove  eax,r8d
  40f7b5:	dec    rax
  40f7b8:	mov    r8,0xffffffffffffffff
  40f7bf:	sub    r8,rax
  40f7c2:	cmp    rdx,r8
  40f7c5:	ja     40f7d5 <__swc_fn_4fa09e82_000038_292d55e5+0x35>
  40f7c7:	add    rdx,rax
  40f7ca:	not    rax
  40f7cd:	mov    r8,rdx
  40f7d0:	and    r8,rax
  40f7d3:	jne    40f7dc <__swc_fn_4fa09e82_000038_292d55e5+0x3c>
  40f7d5:	xor    eax,eax
  40f7d7:	add    rsp,0x8
  40f7db:	ret
  40f7dc:	mov    rdx,r8
  40f7df:	call   40c5a0 <__swc_fn_4fa09e82_000037_1e381f55>
  40f7e4:	add    rsp,0x8
  40f7e8:	ret
  40f7e9:	add    BYTE PTR [rax],al
  40f7eb:	add    BYTE PTR [rax],al
  40f7ed:	add    BYTE PTR [rax],al
	...

000000000040f7f0 <__swc_fn_4fa09e82_000041_41400651>:
  40f7f0:	push   rsi
  40f7f1:	push   rdi
  40f7f2:	sub    rsp,0x8
  40f7f6:	mov    rsi,rdx
  40f7f9:	mov    rdi,rcx
  40f7fc:	test   rdx,rdx
  40f7ff:	je     40f81b <__swc_fn_4fa09e82_000041_41400651+0x2b>
  40f801:	xor    ecx,ecx
  40f803:	call   407720 <__swc_fn_4fa09e82_000033_d15eb4ea>
  40f808:	mov    rax,QWORD PTR [rsi]
  40f80b:	test   rax,rax
  40f80e:	je     40f81b <__swc_fn_4fa09e82_000041_41400651+0x2b>
  40f810:	mov    rcx,rax
  40f813:	mov    rdx,rsi
  40f816:	call   407840 <__swc_fn_4fa09e82_000042_0573444d>
  40f81b:	mov    rcx,rdi
  40f81e:	call   40c600 <__swc_fn_4fa09e82_000040_8029566e>
  40f823:	mov    rsi,rax
  40f826:	test   rax,rax
  40f829:	jne    40f834 <__swc_fn_4fa09e82_000041_41400651+0x44>
  40f82b:	xor    eax,eax
  40f82d:	add    rsp,0x8
  40f831:	pop    rdi
  40f832:	pop    rsi
  40f833:	ret
  40f834:	mov    rcx,rsi
  40f837:	call   407720 <__swc_fn_4fa09e82_000033_d15eb4ea>
  40f83c:	mov    rax,rsi
  40f83f:	add    rsp,0x8
  40f843:	pop    rdi
  40f844:	pop    rsi
  40f845:	ret
	...

000000000040f850 <__swc_fn_4fa09e82_000044_fe6bbfdb>:
  40f850:	movzx  eax,BYTE PTR [r8+0x39]
  40f855:	lea    rax,[rax+rax*4]
  40f859:	lea    rax,[rdx+rax*8+0x28]
  40f85e:	mov    ecx,DWORD PTR [r8+0x6c]
  40f862:	test   ecx,ecx
  40f864:	je     40f89d <__swc_fn_4fa09e82_000044_fe6bbfdb+0x4d>
  40f866:	mov    rcx,QWORD PTR [r8+0x50]
  40f86a:	test   rcx,rcx
  40f86d:	je     40f879 <__swc_fn_4fa09e82_000044_fe6bbfdb+0x29>
  40f86f:	mov    rax,QWORD PTR [r8+0x48]
  40f873:	mov    QWORD PTR [rcx+0x48],rax
  40f877:	jmp    40f881 <__swc_fn_4fa09e82_000044_fe6bbfdb+0x31>
  40f879:	mov    rcx,QWORD PTR [r8+0x48]
  40f87d:	mov    QWORD PTR [rax+0x18],rcx
  40f881:	mov    rax,QWORD PTR [r8+0x48]
  40f885:	test   rax,rax
  40f888:	je     40f892 <__swc_fn_4fa09e82_000044_fe6bbfdb+0x42>
  40f88a:	mov    rcx,QWORD PTR [r8+0x50]
  40f88e:	mov    QWORD PTR [rax+0x50],rcx
  40f892:	vxorps xmm0,xmm0,xmm0
  40f896:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40f89c:	ret
  40f89d:	mov    rcx,QWORD PTR [r8+0x50]
  40f8a1:	test   rcx,rcx
  40f8a4:	je     40f8b0 <__swc_fn_4fa09e82_000044_fe6bbfdb+0x60>
  40f8a6:	mov    rdx,QWORD PTR [r8+0x48]
  40f8aa:	mov    QWORD PTR [rcx+0x48],rdx
  40f8ae:	jmp    40f8b8 <__swc_fn_4fa09e82_000044_fe6bbfdb+0x68>
  40f8b0:	mov    rcx,QWORD PTR [r8+0x48]
  40f8b4:	mov    QWORD PTR [rax+0x8],rcx
  40f8b8:	mov    rcx,QWORD PTR [r8+0x48]
  40f8bc:	test   rcx,rcx
  40f8bf:	je     40f8cb <__swc_fn_4fa09e82_000044_fe6bbfdb+0x7b>
  40f8c1:	mov    rdx,QWORD PTR [r8+0x50]
  40f8c5:	mov    QWORD PTR [rcx+0x50],rdx
  40f8c9:	jmp    40f8d3 <__swc_fn_4fa09e82_000044_fe6bbfdb+0x83>
  40f8cb:	mov    rcx,QWORD PTR [r8+0x50]
  40f8cf:	mov    QWORD PTR [rax+0x10],rcx
  40f8d3:	cmp    QWORD PTR [rax],r8
  40f8d6:	jne    40f8df <__swc_fn_4fa09e82_000044_fe6bbfdb+0x8f>
  40f8d8:	mov    QWORD PTR [rax],0x0
  40f8df:	vxorps xmm0,xmm0,xmm0
  40f8e3:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40f8e9:	ret
  40f8ea:	add    BYTE PTR [rax],al
  40f8ec:	add    BYTE PTR [rax],al
	...

000000000040f8f0 <__swc_fn_4fa09e82_000047_e7fd8d42>:
  40f8f0:	sub    rsp,0x8
  40f8f4:	mov    r9,r8
  40f8f7:	mov    r10,rdx
  40f8fa:	call   40f850 <__swc_fn_4fa09e82_000044_fe6bbfdb>
  40f8ff:	mov    DWORD PTR [r9+0x6c],0x0
  40f907:	movzx  eax,BYTE PTR [r9+0x39]
  40f90c:	lea    rax,[rax+rax*4]
  40f910:	lea    rax,[r10+rax*8+0x28]
  40f915:	mov    rcx,QWORD PTR [rax+0x10]
  40f919:	mov    QWORD PTR [r9+0x50],rcx
  40f91d:	mov    QWORD PTR [r9+0x48],0x0
  40f925:	mov    rcx,QWORD PTR [rax+0x10]
  40f929:	test   rcx,rcx
  40f92c:	je     40f934 <__swc_fn_4fa09e82_000047_e7fd8d42+0x44>
  40f92e:	mov    QWORD PTR [rcx+0x48],r9
  40f932:	jmp    40f938 <__swc_fn_4fa09e82_000047_e7fd8d42+0x48>
  40f934:	mov    QWORD PTR [rax+0x8],r9
  40f938:	mov    QWORD PTR [rax+0x10],r9
  40f93c:	add    rsp,0x8
  40f940:	ret
	...

000000000040f960 <__swc_fn_4fa09e82_000050_5e919db9>:
  40f960:	push   rsi
  40f961:	push   rdi
  40f962:	push   r12
  40f964:	push   r13
  40f966:	push   r14
  40f968:	push   r15
  40f96a:	sub    rsp,0x1f8
  40f971:	mov    esi,r8d
  40f974:	mov    QWORD PTR [rsp+0x1e8],rsi
  40f97c:	mov    rdi,rcx
  40f97f:	mov    r12,rdx
  40f982:	lea    r13,[rsi+rsi*4]
  40f986:	lea    r13,[rdx+r13*8+0x28]
  40f98b:	call   407ca0 <__swc_fn_4fa09e82_000048_8e68f77b>
  40f990:	add    DWORD PTR [r12+0x24],0x1
  40f996:	test   BYTE PTR [r12+0x24],0x3f
  40f99c:	jne    40f9a6 <__swc_fn_4fa09e82_000050_5e919db9+0x46>
  40f99e:	mov    rcx,rdi
  40f9a1:	call   40c780 <__swc_fn_4fa09e82_000049_f6a485a2>
  40f9a6:	mov    rax,QWORD PTR [r13+0x8]
  40f9aa:	mov    r14,rax
  40f9ad:	nop    DWORD PTR [rax]
  40f9b0:	test   r14,r14
  40f9b3:	jne    40f9c2 <__swc_fn_4fa09e82_000050_5e919db9+0x62>
  40f9b5:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40f9bd:	jmp    40fac9 <__swc_fn_4fa09e82_000050_5e919db9+0x169>
  40f9c2:	mov    r15,QWORD PTR [r14+0x48]
  40f9c6:	mov    rcx,r14
  40f9c9:	call   4073f0 <__swc_fn_4fa09e82_000009_4c3ebf16>
  40f9ce:	mov    rax,QWORD PTR [r14]
  40f9d1:	test   rax,rax
  40f9d4:	je     40f9e6 <__swc_fn_4fa09e82_000050_5e919db9+0x86>
  40f9d6:	mov    rcx,QWORD PTR [rax]
  40f9d9:	mov    QWORD PTR [r14],rcx
  40f9dc:	add    DWORD PTR [r14+0x28],0x1
  40f9e1:	mov    rsi,rax
  40f9e4:	jmp    40fa05 <__swc_fn_4fa09e82_000050_5e919db9+0xa5>
  40f9e6:	mov    rax,QWORD PTR [r14+0x18]
  40f9ea:	cmp    QWORD PTR [r14+0x20],rax
  40f9ee:	jae    40fa03 <__swc_fn_4fa09e82_000050_5e919db9+0xa3>
  40f9f0:	mov    rsi,QWORD PTR [r14+0x20]
  40f9f4:	mov    eax,DWORD PTR [r14+0x2c]
  40f9f8:	add    QWORD PTR [r14+0x20],rax
  40f9fc:	add    DWORD PTR [r14+0x28],0x1
  40fa01:	jmp    40fa05 <__swc_fn_4fa09e82_000050_5e919db9+0xa5>
  40fa03:	xor    esi,esi
  40fa05:	test   rsi,rsi
  40fa08:	jne    40fa4d <__swc_fn_4fa09e82_000050_5e919db9+0xed>
  40fa0a:	mov    rcx,r14
  40fa0d:	call   407320 <__swc_fn_4fa09e82_000006_7b253ae1>
  40fa12:	test   al,al
  40fa14:	je     40fa4d <__swc_fn_4fa09e82_000050_5e919db9+0xed>
  40fa16:	mov    rax,QWORD PTR [r14]
  40fa19:	test   rax,rax
  40fa1c:	je     40fa2b <__swc_fn_4fa09e82_000050_5e919db9+0xcb>
  40fa1e:	mov    rcx,QWORD PTR [rax]
  40fa21:	mov    QWORD PTR [r14],rcx
  40fa24:	add    DWORD PTR [r14+0x28],0x1
  40fa29:	jmp    40fa4a <__swc_fn_4fa09e82_000050_5e919db9+0xea>
  40fa2b:	mov    rax,QWORD PTR [r14+0x18]
  40fa2f:	cmp    QWORD PTR [r14+0x20],rax
  40fa33:	jae    40fa48 <__swc_fn_4fa09e82_000050_5e919db9+0xe8>
  40fa35:	mov    rax,QWORD PTR [r14+0x20]
  40fa39:	mov    ecx,DWORD PTR [r14+0x2c]
  40fa3d:	add    QWORD PTR [r14+0x20],rcx
  40fa41:	add    DWORD PTR [r14+0x28],0x1
  40fa46:	jmp    40fa4a <__swc_fn_4fa09e82_000050_5e919db9+0xea>
  40fa48:	xor    eax,eax
  40fa4a:	mov    rsi,rax
  40fa4d:	test   rsi,rsi
  40fa50:	jne    40faa3 <__swc_fn_4fa09e82_000050_5e919db9+0x143>
  40fa52:	mov    rcx,rdi
  40fa55:	mov    rdx,r12
  40fa58:	mov    r8,r14
  40fa5b:	call   40c6e0 <__swc_fn_4fa09e82_000046_b28a6ee7>
  40fa60:	test   al,al
  40fa62:	jne    40faa3 <__swc_fn_4fa09e82_000050_5e919db9+0x143>
  40fa64:	mov    rcx,r14
  40fa67:	call   4073f0 <__swc_fn_4fa09e82_000009_4c3ebf16>
  40fa6c:	mov    rax,QWORD PTR [r14]
  40fa6f:	test   rax,rax
  40fa72:	je     40fa81 <__swc_fn_4fa09e82_000050_5e919db9+0x121>
  40fa74:	mov    rcx,QWORD PTR [rax]
  40fa77:	mov    QWORD PTR [r14],rcx
  40fa7a:	add    DWORD PTR [r14+0x28],0x1
  40fa7f:	jmp    40faa0 <__swc_fn_4fa09e82_000050_5e919db9+0x140>
  40fa81:	mov    rax,QWORD PTR [r14+0x18]
  40fa85:	cmp    QWORD PTR [r14+0x20],rax
  40fa89:	jae    40fa9e <__swc_fn_4fa09e82_000050_5e919db9+0x13e>
  40fa8b:	mov    rax,QWORD PTR [r14+0x20]
  40fa8f:	mov    ecx,DWORD PTR [r14+0x2c]
  40fa93:	add    QWORD PTR [r14+0x20],rcx
  40fa97:	add    DWORD PTR [r14+0x28],0x1
  40fa9c:	jmp    40faa0 <__swc_fn_4fa09e82_000050_5e919db9+0x140>
  40fa9e:	xor    eax,eax
  40faa0:	mov    rsi,rax
  40faa3:	test   rsi,rsi
  40faa6:	je     40fac1 <__swc_fn_4fa09e82_000050_5e919db9+0x161>
  40faa8:	mov    QWORD PTR [r13+0x0],r14
  40faac:	mov    rax,rsi
  40faaf:	add    rsp,0x1f8
  40fab6:	pop    r15
  40fab8:	pop    r14
  40faba:	pop    r13
  40fabc:	pop    r12
  40fabe:	pop    rdi
  40fabf:	pop    rsi
  40fac0:	ret
  40fac1:	mov    r14,r15
  40fac4:	jmp    40f9b0 <__swc_fn_4fa09e82_000050_5e919db9+0x50>
  40fac9:	cs nop WORD PTR [rax+rax*1+0x0]
  40fad3:	cs nop WORD PTR [rax+rax*1+0x0]
  40fadd:	nop    DWORD PTR [rax]
  40fae0:	mov    rcx,rdi
  40fae3:	mov    rdx,r12
  40fae6:	mov    r8d,esi
  40fae9:	call   4079e0 <__swc_fn_4fa09e82_000045_bb688d37>
  40faee:	mov    r14,rax
  40faf1:	test   rax,rax
  40faf4:	jne    40fb0a <__swc_fn_4fa09e82_000050_5e919db9+0x1aa>
  40faf6:	xor    eax,eax
  40faf8:	add    rsp,0x1f8
  40faff:	pop    r15
  40fb01:	pop    r14
  40fb03:	pop    r13
  40fb05:	pop    r12
  40fb07:	pop    rdi
  40fb08:	pop    rsi
  40fb09:	ret
  40fb0a:	mov    QWORD PTR [r13+0x0],r14
  40fb0e:	mov    rax,QWORD PTR [r14]
  40fb11:	test   rax,rax
  40fb14:	je     40fb26 <__swc_fn_4fa09e82_000050_5e919db9+0x1c6>
  40fb16:	mov    rcx,QWORD PTR [rax]
  40fb19:	mov    QWORD PTR [r14],rcx
  40fb1c:	add    DWORD PTR [r14+0x28],0x1
  40fb21:	mov    r15,rax
  40fb24:	jmp    40fb46 <__swc_fn_4fa09e82_000050_5e919db9+0x1e6>
  40fb26:	mov    rax,QWORD PTR [r14+0x18]
  40fb2a:	cmp    QWORD PTR [r14+0x20],rax
  40fb2e:	jae    40fb43 <__swc_fn_4fa09e82_000050_5e919db9+0x1e3>
  40fb30:	mov    r15,QWORD PTR [r14+0x20]
  40fb34:	mov    eax,DWORD PTR [r14+0x2c]
  40fb38:	add    QWORD PTR [r14+0x20],rax
  40fb3c:	add    DWORD PTR [r14+0x28],0x1
  40fb41:	jmp    40fb46 <__swc_fn_4fa09e82_000050_5e919db9+0x1e6>
  40fb43:	xor    r15d,r15d
  40fb46:	test   r15,r15
  40fb49:	jne    40fb8e <__swc_fn_4fa09e82_000050_5e919db9+0x22e>
  40fb4b:	mov    rcx,r14
  40fb4e:	call   407320 <__swc_fn_4fa09e82_000006_7b253ae1>
  40fb53:	test   al,al
  40fb55:	je     40fb8e <__swc_fn_4fa09e82_000050_5e919db9+0x22e>
  40fb57:	mov    rax,QWORD PTR [r14]
  40fb5a:	test   rax,rax
  40fb5d:	je     40fb6c <__swc_fn_4fa09e82_000050_5e919db9+0x20c>
  40fb5f:	mov    rcx,QWORD PTR [rax]
  40fb62:	mov    QWORD PTR [r14],rcx
  40fb65:	add    DWORD PTR [r14+0x28],0x1
  40fb6a:	jmp    40fb8b <__swc_fn_4fa09e82_000050_5e919db9+0x22b>
  40fb6c:	mov    rax,QWORD PTR [r14+0x18]
  40fb70:	cmp    QWORD PTR [r14+0x20],rax
  40fb74:	jae    40fb89 <__swc_fn_4fa09e82_000050_5e919db9+0x229>
  40fb76:	mov    rax,QWORD PTR [r14+0x20]
  40fb7a:	mov    ecx,DWORD PTR [r14+0x2c]
  40fb7e:	add    QWORD PTR [r14+0x20],rcx
  40fb82:	add    DWORD PTR [r14+0x28],0x1
  40fb87:	jmp    40fb8b <__swc_fn_4fa09e82_000050_5e919db9+0x22b>
  40fb89:	xor    eax,eax
  40fb8b:	mov    r15,rax
  40fb8e:	test   r15,r15
  40fb91:	je     40fae0 <__swc_fn_4fa09e82_000050_5e919db9+0x180>
  40fb97:	mov    rax,r15
  40fb9a:	add    rsp,0x1f8
  40fba1:	pop    r15
  40fba3:	pop    r14
  40fba5:	pop    r13
  40fba7:	pop    r12
  40fba9:	pop    rdi
  40fbaa:	pop    rsi
  40fbab:	ret
  40fbac:	add    BYTE PTR [rax],al
	...

000000000040fbb0 <__swc_fn_4fa09e82_000053_9aa81fa7>:
  40fbb0:	push   rsi
  40fbb1:	push   rdi
  40fbb2:	push   r12
  40fbb4:	mov    rsi,rdx
  40fbb7:	mov    rax,rdx
  40fbba:	shr    rax,0xc
  40fbbe:	movabs rdx,0x9e3779b97f4a7c15
  40fbc8:	imul   rax,rdx
  40fbcc:	shr    rax,0x20
  40fbd0:	lea    rax,[rax*8+0x0]
  40fbd8:	shr    rax,0x20
  40fbdc:	lea    rax,[rax*8+0x0]
  40fbe4:	lea    rax,[rcx+rax*8+0x40]
  40fbe9:	xor    edx,edx
  40fbeb:	test   dl,dl
  40fbed:	lea    rdi,[rcx+0x8]
  40fbf1:	cmove  rdi,rax
  40fbf5:	xor    edx,edx
  40fbf7:	test   dl,dl
  40fbf9:	lea    r12,[rcx+0x30]
  40fbfd:	lea    rax,[rax+0x8]
  40fc01:	cmove  r12,rax
  40fc05:	mov    rcx,rdi
  40fc08:	call   40e720 <__swc_fn_4fa09e82_000136_db32cc57>
  40fc0d:	mov    QWORD PTR [rsi+0x30],0x0
  40fc15:	mov    rax,QWORD PTR [r12]
  40fc19:	mov    QWORD PTR [rsi+0x38],rax
  40fc1d:	test   rax,rax
  40fc20:	je     40fc2a <__swc_fn_4fa09e82_000053_9aa81fa7+0x7a>
  40fc22:	mov    rax,QWORD PTR [rsi+0x38]
  40fc26:	mov    QWORD PTR [rax+0x30],rsi
  40fc2a:	mov    QWORD PTR [r12],rsi
  40fc2e:	mov    rcx,rdi
  40fc31:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  40fc36:	pop    r12
  40fc38:	pop    rdi
  40fc39:	pop    rsi
  40fc3a:	ret
  40fc3b:	add    BYTE PTR [rax],al
  40fc3d:	add    BYTE PTR [rax],al
	...

000000000040fc40 <__swc_fn_4fa09e82_000056_87dc216f>:
  40fc40:	lea    rax,[rdx+rdx*4]
  40fc44:	lea    rax,[rcx+rax*8+0x268]
  40fc4c:	mov    rdx,QWORD PTR [rax+0x10]
  40fc50:	sub    QWORD PTR [rcx+0x2a68],rdx
  40fc57:	sub    QWORD PTR [rcx+0x2a70],0x1
  40fc5f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40fc66:	lea    rdx,[rdx+rdx*4]
  40fc6a:	lea    rdx,[rcx+rdx*8+0x268]
  40fc72:	vmovups xmm0,XMMWORD PTR [rdx]
  40fc76:	vmovups XMMWORD PTR [rax],xmm0
  40fc7a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40fc7f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40fc84:	mov    rcx,QWORD PTR [rdx+0x20]
  40fc88:	mov    QWORD PTR [rax+0x20],rcx
  40fc8c:	ret
  40fc8d:	add    BYTE PTR [rax],al
	...

000000000040fc90 <__swc_fn_4fa09e82_000059_ee6a254c>:
  40fc90:	push   rsi
  40fc91:	push   rdi
  40fc92:	push   r12
  40fc94:	push   r13
  40fc96:	sub    rsp,0x8
  40fc9a:	mov    rsi,r8
  40fc9d:	mov    rdi,rcx
  40fca0:	mov    r12,rdx
  40fca3:	xor    r13d,r13d
  40fca6:	cs nop WORD PTR [rax+rax*1+0x0]
  40fcb0:	mov    eax,DWORD PTR [r12+0x730]
  40fcb8:	cmp    r13d,eax
  40fcbb:	jae    40fd21 <__swc_fn_4fa09e82_000059_ee6a254c+0x91>
  40fcbd:	lea    rax,[r13+r13*4+0x0]
  40fcc2:	lea    rax,[r12+rax*8+0x738]
  40fcca:	mov    rdx,QWORD PTR [rax]
  40fccd:	mov    r8,QWORD PTR [rax+0x8]
  40fcd1:	mov    r9,QWORD PTR [rax+0x10]
  40fcd5:	cmp    QWORD PTR [rax+0x20],rsi
  40fcd9:	jb     40fce0 <__swc_fn_4fa09e82_000059_ee6a254c+0x50>
  40fcdb:	inc    r13d
  40fcde:	jmp    40fcb0 <__swc_fn_4fa09e82_000059_ee6a254c+0x20>
  40fce0:	sub    DWORD PTR [r12+0x730],0x1
  40fce9:	mov    ecx,DWORD PTR [r12+0x730]
  40fcf1:	lea    rcx,[rcx+rcx*4]
  40fcf5:	lea    rcx,[r12+rcx*8+0x738]
  40fcfd:	vmovups xmm0,XMMWORD PTR [rcx]
  40fd01:	vmovups XMMWORD PTR [rax],xmm0
  40fd05:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40fd0a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40fd0f:	mov    rcx,QWORD PTR [rcx+0x20]
  40fd13:	mov    QWORD PTR [rax+0x20],rcx
  40fd17:	mov    rcx,rdi
  40fd1a:	call   407750 <__swc_fn_4fa09e82_000039_9ae4348f>
  40fd1f:	jmp    40fcb0 <__swc_fn_4fa09e82_000059_ee6a254c+0x20>
  40fd21:	add    rsp,0x8
  40fd25:	pop    r13
  40fd27:	pop    r12
  40fd29:	pop    rdi
  40fd2a:	pop    rsi
  40fd2b:	ret
  40fd2c:	add    BYTE PTR [rax],al
	...

000000000040fd30 <__swc_fn_4fa09e82_000062_0a65f1d5>:
  40fd30:	push   rsi
  40fd31:	push   rdi
  40fd32:	push   r12
  40fd34:	push   r13
  40fd36:	push   r14
  40fd38:	mov    rsi,rcx
  40fd3b:	mov    rdi,rdx
  40fd3e:	mov    r12,QWORD PTR [rdi]
  40fd41:	mov    r13,QWORD PTR [rdi+0x18]
  40fd45:	mov    rax,r12
  40fd48:	add    rax,QWORD PTR [rdi+0x8]
  40fd4c:	sub    rax,r13
  40fd4f:	cmp    r8,rax
  40fd52:	jbe    40fd5d <__swc_fn_4fa09e82_000062_0a65f1d5+0x2d>
  40fd54:	pop    r14
  40fd56:	pop    r13
  40fd58:	pop    r12
  40fd5a:	pop    rdi
  40fd5b:	pop    rsi
  40fd5c:	ret
  40fd5d:	lea    rax,[r13+r8*1+0x0]
  40fd62:	sub    rax,r12
  40fd65:	mov    ecx,0x1000
  40fd6a:	test   ecx,ecx
  40fd6c:	mov    edx,0x8
  40fd71:	cmove  ecx,edx
  40fd74:	dec    rcx
  40fd77:	mov    rdx,0xffffffffffffffff
  40fd7e:	sub    rdx,rcx
  40fd81:	cmp    rax,rdx
  40fd84:	jbe    40fd8b <__swc_fn_4fa09e82_000062_0a65f1d5+0x5b>
  40fd86:	xor    r14d,r14d
  40fd89:	jmp    40fd96 <__swc_fn_4fa09e82_000062_0a65f1d5+0x66>
  40fd8b:	add    rax,rcx
  40fd8e:	andn   rax,rcx,rax
  40fd93:	mov    r14,rax
  40fd96:	mov    rax,QWORD PTR [rdi+0x10]
  40fd9a:	cmp    r14,rax
  40fd9d:	ja     40fda8 <__swc_fn_4fa09e82_000062_0a65f1d5+0x78>
  40fd9f:	pop    r14
  40fda1:	pop    r13
  40fda3:	pop    r12
  40fda5:	pop    rdi
  40fda6:	pop    rsi
  40fda7:	ret
  40fda8:	mov    rax,r12
  40fdab:	add    rax,QWORD PTR [rdi+0x10]
  40fdaf:	mov    rdx,r14
  40fdb2:	sub    rdx,QWORD PTR [rdi+0x10]
  40fdb6:	mov    rcx,rax
  40fdb9:	call   4072a0 <__swc_fn_4fa09e82_000003_81215399>
  40fdbe:	test   al,al
  40fdc0:	jne    40fdcb <__swc_fn_4fa09e82_000062_0a65f1d5+0x9b>
  40fdc2:	pop    r14
  40fdc4:	pop    r13
  40fdc6:	pop    r12
  40fdc8:	pop    rdi
  40fdc9:	pop    rsi
  40fdca:	ret
  40fdcb:	add    r12,r14
  40fdce:	sub    r12,r13
  40fdd1:	mov    rcx,r12
  40fdd4:	sub    rcx,QWORD PTR [rdi+0x28]
  40fdd8:	mov    rdx,QWORD PTR [rsi+0x250]
  40fddf:	nop
  40fde0:	lea    r8,[rdx+rcx*1]
  40fde4:	mov    rax,rdx
  40fde7:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40fdf0:	cmp    rax,rdx
  40fdf3:	je     40fdfa <__swc_fn_4fa09e82_000062_0a65f1d5+0xca>
  40fdf5:	mov    rdx,rax
  40fdf8:	jmp    40fde0 <__swc_fn_4fa09e82_000062_0a65f1d5+0xb0>
  40fdfa:	mov    QWORD PTR [rdi+0x10],r14
  40fdfe:	mov    QWORD PTR [rdi+0x28],r12
  40fe02:	pop    r14
  40fe04:	pop    r13
  40fe06:	pop    r12
  40fe08:	pop    rdi
  40fe09:	pop    rsi
  40fe0a:	ret
  40fe0b:	add    BYTE PTR [rax],al
  40fe0d:	add    BYTE PTR [rax],al
	...

000000000040fe10 <__swc_fn_4fa09e82_000065_0b20477c>:
  40fe10:	push   rbx
  40fe11:	push   rsi
  40fe12:	push   rdi
  40fe13:	push   r12
  40fe15:	push   r13
  40fe17:	sub    rsp,0xe0
  40fe1e:	mov    rbx,rdx
  40fe21:	mov    rsi,rcx
  40fe24:	cmp    DWORD PTR [rbx+0x58],0x0
  40fe28:	je     40fe4c <__swc_fn_4fa09e82_000065_0b20477c+0x3c>
  40fe2a:	mov    eax,DWORD PTR [rbx+0x58]
  40fe2d:	sub    eax,0x1
  40fe30:	test   DWORD PTR [rbx+0x58],eax
  40fe33:	je     40fe4c <__swc_fn_4fa09e82_000065_0b20477c+0x3c>
  40fe35:	mov    QWORD PTR [rbx+0x40],0x0
  40fe3d:	add    rsp,0xe0
  40fe44:	pop    r13
  40fe46:	pop    r12
  40fe48:	pop    rdi
  40fe49:	pop    rsi
  40fe4a:	pop    rbx
  40fe4b:	ret
  40fe4c:	mov    rax,QWORD PTR [rbx+0x40]
  40fe50:	test   rax,rax
  40fe53:	jne    40fe6f <__swc_fn_4fa09e82_000065_0b20477c+0x5f>
  40fe55:	mov    rcx,rsi
  40fe58:	mov    rdx,rbx
  40fe5b:	call   40d390 <__swc_fn_4fa09e82_000064_20100e91>
  40fe60:	add    rsp,0xe0
  40fe67:	pop    r13
  40fe69:	pop    r12
  40fe6b:	pop    rdi
  40fe6c:	pop    rsi
  40fe6d:	pop    rbx
  40fe6e:	ret
  40fe6f:	cmp    QWORD PTR [rbx+0x48],0x0
  40fe74:	jne    40fe90 <__swc_fn_4fa09e82_000065_0b20477c+0x80>
  40fe76:	mov    rcx,rsi
  40fe79:	mov    rdx,rbx
  40fe7c:	call   407f90 <__swc_fn_4fa09e82_000066_918d3875>
  40fe81:	add    rsp,0xe0
  40fe88:	pop    r13
  40fe8a:	pop    r12
  40fe8c:	pop    rdi
  40fe8d:	pop    rsi
  40fe8e:	pop    rbx
  40fe8f:	ret
  40fe90:	mov    rdi,QWORD PTR [rbx+0x40]
  40fe94:	lea    rax,[rip+0x141d5]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  40fe9b:	mov    rcx,rdi
  40fe9e:	sub    rcx,QWORD PTR [rax+0x8]
  40fea2:	mov    rax,QWORD PTR [rip+0x141d7]        # 424080 <__swc_bss_base_4fa09e82+0x40>
  40fea9:	cmp    rcx,rax
  40feac:	jae    40fed8 <__swc_fn_4fa09e82_000065_0b20477c+0xc8>
  40feae:	mov    rax,rdi
  40feb1:	and    rax,0xffffffffffc00000
  40feb8:	mov    rcx,rdi
  40febb:	shr    rcx,0x10
  40febf:	and    ecx,0x3f
  40fec2:	mov    edx,DWORD PTR [rax+0x28]
  40fec5:	shrx   ecx,ecx,edx
  40feca:	shl    rcx,0x4
  40fece:	lea    r12,[rax+rcx*8+0x80]
  40fed6:	jmp    40fee3 <__swc_fn_4fa09e82_000065_0b20477c+0xd3>
  40fed8:	mov    rcx,rdi
  40fedb:	call   40c410 <__swc_fn_4fa09e82_000022_53fc00d2>
  40fee0:	mov    r12,rax
  40fee3:	test   r12,r12
  40fee6:	je     40fef5 <__swc_fn_4fa09e82_000065_0b20477c+0xe5>
  40fee8:	mov    eax,DWORD PTR [r12+0x2c]
  40feed:	mov    r9d,eax
  40fef0:	mov    r13,rax
  40fef3:	jmp    40ff74 <__swc_fn_4fa09e82_000065_0b20477c+0x164>
  40fef5:	mov    rcx,rsi
  40fef8:	mov    rdx,rdi
  40fefb:	call   40ca20 <__swc_fn_4fa09e82_000052_92b016ae>
  40ff00:	mov    rcx,QWORD PTR [rax+0x28]
  40ff04:	mov    r9,rcx
  40ff07:	mov    rdx,QWORD PTR [rax+0x20]
  40ff0b:	mov    r13,rdx
  40ff0e:	cmp    QWORD PTR [rbx+0x48],rcx
  40ff12:	jbe    40ff4b <__swc_fn_4fa09e82_000065_0b20477c+0x13b>
  40ff14:	mov    ecx,DWORD PTR [rax+0x48]
  40ff17:	cmp    DWORD PTR [rbx+0x58],ecx
  40ff1a:	ja     40ff4b <__swc_fn_4fa09e82_000065_0b20477c+0x13b>
  40ff1c:	mov    rcx,rsi
  40ff1f:	mov    rdx,rax
  40ff22:	mov    r8,QWORD PTR [rbx+0x48]
  40ff26:	mov    QWORD PTR [rsp+0xc8],r9
  40ff2e:	mov    QWORD PTR [rsp+0xd0],rax
  40ff36:	call   40fd30 <__swc_fn_4fa09e82_000062_0a65f1d5>
  40ff3b:	mov    r9,QWORD PTR [rsp+0xc8]
  40ff43:	mov    rax,QWORD PTR [rsp+0xd0]
  40ff4b:	mov    rcx,QWORD PTR [rax+0x28]
  40ff4f:	cmp    QWORD PTR [rbx+0x48],rcx
  40ff53:	ja     40ff74 <__swc_fn_4fa09e82_000065_0b20477c+0x164>
  40ff55:	mov    ecx,DWORD PTR [rax+0x48]
  40ff58:	cmp    DWORD PTR [rbx+0x58],ecx
  40ff5b:	ja     40ff74 <__swc_fn_4fa09e82_000065_0b20477c+0x164>
  40ff5d:	mov    rcx,QWORD PTR [rbx+0x48]
  40ff61:	mov    QWORD PTR [rax+0x20],rcx
  40ff65:	add    rsp,0xe0
  40ff6c:	pop    r13
  40ff6e:	pop    r12
  40ff70:	pop    rdi
  40ff71:	pop    rsi
  40ff72:	pop    rbx
  40ff73:	ret
  40ff74:	test   r12,r12
  40ff77:	je     40ffa9 <__swc_fn_4fa09e82_000065_0b20477c+0x199>
  40ff79:	cmp    QWORD PTR [rbx+0x48],r9
  40ff7d:	ja     40ffa9 <__swc_fn_4fa09e82_000065_0b20477c+0x199>
  40ff7f:	cmp    DWORD PTR [rbx+0x58],0x40
  40ff83:	ja     40ffa9 <__swc_fn_4fa09e82_000065_0b20477c+0x199>
  40ff85:	cmp    DWORD PTR [rbx+0x58],0x0
  40ff89:	je     40ff96 <__swc_fn_4fa09e82_000065_0b20477c+0x186>
  40ff8b:	mov    ecx,DWORD PTR [rbx+0x58]
  40ff8e:	dec    rcx
  40ff91:	test   rdi,rcx
  40ff94:	jne    40ffa9 <__swc_fn_4fa09e82_000065_0b20477c+0x199>
  40ff96:	mov    QWORD PTR [rbx+0x40],rdi
  40ff9a:	add    rsp,0xe0
  40ffa1:	pop    r13
  40ffa3:	pop    r12
  40ffa5:	pop    rdi
  40ffa6:	pop    rsi
  40ffa7:	pop    rbx
  40ffa8:	ret
  40ffa9:	vmovups xmm0,XMMWORD PTR [rbx]
  40ffad:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ffb3:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40ffb8:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40ffbe:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40ffc3:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40ffc9:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40ffce:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40ffd4:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40ffd9:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40ffdf:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40ffe4:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40ffea:	mov    QWORD PTR [rsp+0x48],0x0
  40fff3:	mov    rcx,rsi
  40fff6:	lea    rdx,[rsp+0x8]
  40fffb:	call   40d390 <__swc_fn_4fa09e82_000064_20100e91>
  410000:	mov    rax,QWORD PTR [rsp+0x48]
  410005:	test   rax,rax
  410008:	jne    410021 <__swc_fn_4fa09e82_000065_0b20477c+0x211>
  41000a:	mov    QWORD PTR [rbx+0x40],0x0
  410012:	add    rsp,0xe0
  410019:	pop    r13
  41001b:	pop    r12
  41001d:	pop    rdi
  41001e:	pop    rsi
  41001f:	pop    rbx
  410020:	ret
  410021:	mov    rax,QWORD PTR [rbx+0x48]
  410025:	cmp    r13,rax
  410028:	cmovbe rax,r13
  41002c:	mov    rcx,QWORD PTR [rsp+0x48]
  410031:	mov    rdx,rdi
  410034:	mov    r8,rax
  410037:	call   40df60 <__swc_fn_4fa09e82_000106_83487ba1>
  41003c:	vmovups xmm0,XMMWORD PTR [rbx]
  410040:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  410046:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  41004b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  410051:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  410056:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  41005f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  410064:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  41006d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  410072:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  41007b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  410080:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  410089:	mov    QWORD PTR [rsp+0xa8],rdi
  410091:	mov    rcx,rsi
  410094:	lea    rdx,[rsp+0x68]
  410099:	call   407f90 <__swc_fn_4fa09e82_000066_918d3875>
  41009e:	mov    rax,QWORD PTR [rsp+0x48]
  4100a3:	mov    QWORD PTR [rbx+0x40],rax
  4100a7:	add    rsp,0xe0
  4100ae:	pop    r13
  4100b0:	pop    r12
  4100b2:	pop    rdi
  4100b3:	pop    rsi
  4100b4:	pop    rbx
  4100b5:	ret
	...

00000000004100c0 <__swc_fn_4fa09e82_000068_f501e74b>:
  4100c0:	push   r12
  4100c2:	push   rdi
  4100c3:	push   rsi
  4100c4:	push   r13
  4100c6:	push   r14
  4100c8:	sub    rsp,0x190
  4100cf:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  4100d8:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  4100e1:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  4100ea:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  4100f3:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  4100fc:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  410105:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  41010e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  410117:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  410120:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  410129:	mov    r12,rcx
  41012c:	lea    rax,[rip+0x11ecd]        # 422000 <__swc_data_base_4fa09e82>
  410133:	mov    rax,QWORD PTR [rax]
  410136:	cmp    rax,0xffffffffffffffff
  41013a:	je     410149 <__swc_fn_4fa09e82_000068_f501e74b+0x89>
  41013c:	mov    eax,eax
  41013e:	mov    edi,eax
  410140:	xor    eax,eax
  410142:	call   407000 <pthread_getspecific@plt>
  410147:	jmp    41014b <__swc_fn_4fa09e82_000068_f501e74b+0x8b>
  410149:	xor    eax,eax
  41014b:	test   rax,rax
  41014e:	jne    41015d <__swc_fn_4fa09e82_000068_f501e74b+0x9d>
  410150:	call   40c4e0 <__swc_fn_4fa09e82_000031_3c3e930e>
  410155:	mov    rcx,rax
  410158:	call   409ba0 <__swc_fn_4fa09e82_000129_8d8a7dd2>
  41015d:	test   rax,rax
  410160:	je     410186 <__swc_fn_4fa09e82_000068_f501e74b+0xc6>
  410162:	cmp    QWORD PTR [rax],r12
  410165:	jne    410186 <__swc_fn_4fa09e82_000068_f501e74b+0xc6>
  410167:	xor    ecx,ecx
  410169:	mov    QWORD PTR [rsp+0xc8],rax
  410171:	call   407720 <__swc_fn_4fa09e82_000033_d15eb4ea>
  410176:	mov    rdx,QWORD PTR [rsp+0xc8]
  41017e:	mov    rcx,r12
  410181:	call   407840 <__swc_fn_4fa09e82_000042_0573444d>
  410186:	lea    rsi,[r12+0x10]
  41018b:	mov    rcx,rsi
  41018e:	call   40e720 <__swc_fn_4fa09e82_000136_db32cc57>
  410193:	mov    rdi,QWORD PTR [r12+0x20]
  410198:	test   rdi,rdi
  41019b:	je     4101de <__swc_fn_4fa09e82_000068_f501e74b+0x11e>
  41019d:	nop    DWORD PTR [rax]
  4101a0:	mov    rcx,r12
  4101a3:	mov    rdx,rdi
  4101a6:	call   40c6a0 <__swc_fn_4fa09e82_000043_47ff6d9b>
  4101ab:	mov    rcx,r12
  4101ae:	mov    rdx,rdi
  4101b1:	mov    r8,0xffffffffffffffff
  4101b8:	call   40fc90 <__swc_fn_4fa09e82_000059_ee6a254c>
  4101bd:	mov    rcx,r12
  4101c0:	mov    rdx,rdi
  4101c3:	mov    r8d,0x9b8
  4101c9:	mov    r9d,0x9b8
  4101cf:	call   407750 <__swc_fn_4fa09e82_000039_9ae4348f>
  4101d4:	mov    rdi,QWORD PTR [r12+0x20]
  4101d9:	test   rdi,rdi
  4101dc:	jne    4101a0 <__swc_fn_4fa09e82_000068_f501e74b+0xe0>
  4101de:	xor    eax,eax
  4101e0:	xchg   QWORD PTR [r12+0x2a80],rax
  4101e8:	test   rax,rax
  4101eb:	je     410211 <__swc_fn_4fa09e82_000068_f501e74b+0x151>
  4101ed:	cs nop WORD PTR [rax+rax*1+0x0]
  4101f7:	nop    WORD PTR [rax+rax*1+0x0]
  410200:	mov    rcx,rax
  410203:	mov    rax,QWORD PTR [rax+0x78]
  410207:	xor    edx,edx
  410209:	xchg   DWORD PTR [rcx+0x70],edx
  41020c:	test   rax,rax
  41020f:	jne    410200 <__swc_fn_4fa09e82_000068_f501e74b+0x140>
  410211:	mov    rax,QWORD PTR [r12+0x18]
  410216:	mov    rdi,rax
  410219:	test   rdi,rdi
  41021c:	je     4102b1 <__swc_fn_4fa09e82_000068_f501e74b+0x1f1>
  410222:	cs nop WORD PTR [rax+rax*1+0x0]
  41022c:	nop    DWORD PTR [rax+0x0]
  410230:	mov    rax,QWORD PTR [rdi+0x10]
  410234:	mov    r8d,DWORD PTR [rdi+0x2c]
  410238:	xor    r9d,r9d
  41023b:	test   r8,r8
  41023e:	jbe    41029d <__swc_fn_4fa09e82_000068_f501e74b+0x1dd>
  410240:	mov    ecx,r9d
  410243:	shl    rcx,0x4
  410247:	lea    rdx,[rdi+rcx*8+0x80]
  41024f:	cmp    BYTE PTR [rdx+0x3b],0x0
  410253:	je     410294 <__swc_fn_4fa09e82_000068_f501e74b+0x1d4>
  410255:	mov    DWORD PTR [rdx+0x28],0x0
  41025c:	mov    rcx,rdi
  41025f:	mov    QWORD PTR [rsp+0xd0],rax
  410267:	mov    QWORD PTR [rsp+0xd8],r8
  41026f:	mov    QWORD PTR [rsp+0xe0],r9
  410277:	call   40f3c0 <__swc_fn_4fa09e82_000014_be17798c>
  41027c:	mov    rax,QWORD PTR [rsp+0xd0]
  410284:	mov    r8,QWORD PTR [rsp+0xd8]
  41028c:	mov    r9,QWORD PTR [rsp+0xe0]
  410294:	add    r9,0x1
  410298:	cmp    r9,r8
  41029b:	jb     410240 <__swc_fn_4fa09e82_000068_f501e74b+0x180>
  41029d:	mov    rcx,rdi
  4102a0:	mov    rdi,rax
  4102a3:	call   407630 <__swc_fn_4fa09e82_000021_9cf87641>
  4102a8:	test   rdi,rdi
  4102ab:	jne    410230 <__swc_fn_4fa09e82_000068_f501e74b+0x170>
  4102b1:	mov    QWORD PTR [r12+0x18],0x0
  4102ba:	mov    QWORD PTR [r12+0x28],0x0
  4102c3:	mov    rcx,rsi
  4102c6:	call   411890 <__swc_fn_4fa09e82_000137_d579ef75>
  4102cb:	mov    esi,0x8
  4102d0:	xor    edi,edi
  4102d2:	test   rsi,rsi
  4102d5:	je     410332 <__swc_fn_4fa09e82_000068_f501e74b+0x272>
  4102db:	nop    DWORD PTR [rax+rax*1+0x0]
  4102e0:	lea    r13,[rdi*8+0x0]
  4102e8:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  4102ed:	test   r14,r14
  4102f0:	je     410328 <__swc_fn_4fa09e82_000068_f501e74b+0x268>
  4102f2:	cs nop WORD PTR [rax+rax*1+0x0]
  4102fc:	nop    DWORD PTR [rax+0x0]
  410300:	mov    rcx,r12
  410303:	mov    rdx,r14
  410306:	call   407df0 <__swc_fn_4fa09e82_000054_e8e85c01>
  41030b:	mov    rcx,r12
  41030e:	mov    rdx,QWORD PTR [r14]
  410311:	mov    r8,QWORD PTR [r14+0x8]
  410315:	mov    r9,QWORD PTR [r14+0x10]
  410319:	call   407750 <__swc_fn_4fa09e82_000039_9ae4348f>
  41031e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  410323:	test   r14,r14
  410326:	jne    410300 <__swc_fn_4fa09e82_000068_f501e74b+0x240>
  410328:	add    rdi,0x1
  41032c:	sub    rsi,0x1
  410330:	jne    4102e0 <__swc_fn_4fa09e82_000068_f501e74b+0x220>
  410332:	mov    rcx,r12
  410335:	call   407ec0 <__swc_fn_4fa09e82_000060_6818d0d1>
  41033a:	lea    rcx,[r12+0x250]
  410342:	mov    rdx,QWORD PTR [rcx]
  410345:	mov    r8,QWORD PTR [r12+0x250]
  41034d:	nop    DWORD PTR [rax]
  410350:	mov    r9,r8
  410353:	sub    r9,rdx
  410356:	mov    rax,r8
  410359:	lock cmpxchg QWORD PTR [rcx],r9
  41035e:	cmp    rax,r8
  410361:	je     410368 <__swc_fn_4fa09e82_000068_f501e74b+0x2a8>
  410363:	mov    r8,rax
  410366:	jmp    410350 <__swc_fn_4fa09e82_000068_f501e74b+0x290>
  410368:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  410371:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  41037a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  410383:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  41038c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  410395:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  41039e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  4103a7:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  4103b0:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  4103b9:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  4103c2:	add    rsp,0x190
  4103c9:	pop    r14
  4103cb:	pop    r13
  4103cd:	pop    rsi
  4103ce:	pop    rdi
  4103cf:	pop    r12
  4103d1:	ret
	...

00000000004103e0 <__swc_fn_4fa09e82_000071_1e1e3bf8>:
  4103e0:	sub    rsp,0x8
  4103e4:	mov    QWORD PTR [rdx+0x40],0x0
  4103ec:	call   40d390 <__swc_fn_4fa09e82_000064_20100e91>
  4103f1:	add    rsp,0x8
  4103f5:	ret
	...

0000000000410400 <__swc_fn_4fa09e82_000074_30b8696a>:
  410400:	sub    rsp,0x8
  410404:	call   407f90 <__swc_fn_4fa09e82_000066_918d3875>
  410409:	add    rsp,0x8
  41040d:	ret
	...

0000000000410410 <__swc_fn_4fa09e82_000077_948ef603>:
  410410:	push   rbx
  410411:	push   rsi
  410412:	push   rdi
  410413:	push   r12
  410415:	push   r13
  410417:	push   r14
  410419:	push   r15
  41041b:	sub    rsp,0x20
  41041f:	mov    rbx,r11
  410422:	mov    rsi,rcx
  410425:	mov    rdi,rdx
  410428:	mov    r12,r8
  41042b:	mov    r13,r9
  41042e:	mov    r14,r10
  410431:	mov    rcx,QWORD PTR [rip+0x16908]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  410438:	test   rcx,rcx
  41043b:	jne    41044d <__swc_fn_4fa09e82_000077_948ef603+0x3d>
  41043d:	call   40f020 <__swc_fn_4fa09e82_000166_56054fe7>
  410442:	lea    rcx,[rax+0x1]
  410446:	mov    QWORD PTR [rip+0x168f3],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  41044d:	dec    rcx
  410450:	call   40b620 <__swc_fn_4fa09e82_000168_39c041ad>
  410455:	mov    r15,rax
  410458:	lea    r11,[rip+0x13de1]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  41045f:	mov    rcx,r11
  410462:	call   407740 <__swc_fn_4fa09e82_000036_290a131c>
  410467:	test   al,al
  410469:	jne    41047a <__swc_fn_4fa09e82_000077_948ef603+0x6a>
  41046b:	mov    rcx,r11
  41046e:	call   40c540 <__swc_fn_4fa09e82_000034_cf5ba7bd>
  410473:	lea    r11,[rip+0x13dc6]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  41047a:	mov    rcx,r11
  41047d:	mov    rdx,rsi
  410480:	mov    r8,rdi
  410483:	mov    r9,r12
  410486:	mov    r10,r13
  410489:	mov    rsi,r11
  41048c:	mov    r11,r14
  41048f:	call   40f730 <__swc_fn_4fa09e82_000035_ab2e8c35>
  410494:	test   bl,bl
  410496:	je     4104bd <__swc_fn_4fa09e82_000077_948ef603+0xad>
  410498:	mov    QWORD PTR [rsp+0x8],rsi
  41049d:	lea    rax,[rip+0x2cac]        # 413150 <__swc_rdata_base_4fa09e82+0x40>
  4104a4:	mov    QWORD PTR [rsp+0x10],rax
  4104a9:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4104af:	vmovups XMMWORD PTR [r15],xmm0
  4104b4:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  4104bd:	mov    rax,rsi
  4104c0:	add    rsp,0x20
  4104c4:	pop    r15
  4104c6:	pop    r14
  4104c8:	pop    r13
  4104ca:	pop    r12
  4104cc:	pop    rdi
  4104cd:	pop    rsi
  4104ce:	pop    rbx
  4104cf:	ret

00000000004104d0 <__swc_fn_4fa09e82_000080_207908fe>:
  4104d0:	sub    rsp,0x8
  4104d4:	mov    rax,rcx
  4104d7:	test   rcx,rcx
  4104da:	jne    4104e1 <__swc_fn_4fa09e82_000080_207908fe+0x11>
  4104dc:	add    rsp,0x8
  4104e0:	ret
  4104e1:	lea    rcx,[rax-0x10]
  4104e5:	mov    rax,QWORD PTR [rax-0x10]
  4104e9:	mov    rdx,rax
  4104ec:	call   409850 <__swc_fn_4fa09e82_000114_4e83a03a>
  4104f1:	add    rsp,0x8
  4104f5:	ret
	...

0000000000410500 <__swc_fn_4fa09e82_000083_f2d93dad>:
  410500:	sub    rsp,0x8
  410504:	xor    r11d,r11d
  410507:	call   408250 <__swc_fn_4fa09e82_000084_5ed30bd6>
  41050c:	add    rsp,0x8
  410510:	ret
	...

0000000000410520 <__swc_fn_4fa09e82_000086_d9243de4>:
  410520:	push   rsi
  410521:	push   rdi
  410522:	push   r12
  410524:	push   r13
  410526:	push   r14
  410528:	push   r15
  41052a:	sub    rsp,0x68
  41052e:	mov    rsi,r9
  410531:	mov    rdi,rcx
  410534:	mov    r12,rdx
  410537:	mov    r13,r8
  41053a:	cmp    r8,r9
  41053d:	jne    410565 <__swc_fn_4fa09e82_000086_d9243de4+0x45>
  41053f:	mov    rcx,rdi
  410542:	mov    rdx,r12
  410545:	xor    r8d,r8d
  410548:	call   4085a0 <__swc_fn_4fa09e82_000090_14cf59b2>
  41054d:	test   al,al
  41054f:	je     410565 <__swc_fn_4fa09e82_000086_d9243de4+0x45>
  410551:	mov    eax,0x1
  410556:	add    rsp,0x68
  41055a:	pop    r15
  41055c:	pop    r14
  41055e:	pop    r13
  410560:	pop    r12
  410562:	pop    rdi
  410563:	pop    rsi
  410564:	ret
  410565:	cmp    BYTE PTR [r12+0x2c],0xe
  41056b:	je     41057e <__swc_fn_4fa09e82_000086_d9243de4+0x5e>
  41056d:	xor    eax,eax
  41056f:	add    rsp,0x68
  410573:	pop    r15
  410575:	pop    r14
  410577:	pop    r13
  410579:	pop    r12
  41057b:	pop    rdi
  41057c:	pop    rsi
  41057d:	ret
  41057e:	mov    r14,QWORD PTR [r12+0x98]
  410586:	mov    rax,QWORD PTR [r12+0xa0]
  41058e:	mov    r12,rax
  410591:	xor    r15d,r15d
  410594:	test   r12,r12
  410597:	je     4105ff <__swc_fn_4fa09e82_000086_d9243de4+0xdf>
  410599:	nop    DWORD PTR [rax+0x0]
  4105a0:	mov    QWORD PTR [rsp+0x58],r12
  4105a5:	lea    r12,[r15*8+0x0]
  4105ad:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  4105b2:	mov    rcx,rax
  4105b5:	call   40db20 <__swc_fn_4fa09e82_000082_ff7d1455>
  4105ba:	cmp    BYTE PTR [rax+0x2c],0xe
  4105be:	jne    4105f0 <__swc_fn_4fa09e82_000086_d9243de4+0xd0>
  4105c0:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  4105c5:	lea    r8,[r13+rcx*1+0x0]
  4105ca:	mov    rcx,rdi
  4105cd:	mov    rdx,rax
  4105d0:	mov    r9,rsi
  4105d3:	call   410520 <__swc_fn_4fa09e82_000086_d9243de4>
  4105d8:	test   al,al
  4105da:	je     4105f0 <__swc_fn_4fa09e82_000086_d9243de4+0xd0>
  4105dc:	mov    eax,0x1
  4105e1:	add    rsp,0x68
  4105e5:	pop    r15
  4105e7:	pop    r14
  4105e9:	pop    r13
  4105eb:	pop    r12
  4105ed:	pop    rdi
  4105ee:	pop    rsi
  4105ef:	ret
  4105f0:	add    r15,0x1
  4105f4:	mov    r12,QWORD PTR [rsp+0x58]
  4105f9:	sub    r12,0x1
  4105fd:	jne    4105a0 <__swc_fn_4fa09e82_000086_d9243de4+0x80>
  4105ff:	xor    eax,eax
  410601:	add    rsp,0x68
  410605:	pop    r15
  410607:	pop    r14
  410609:	pop    r13
  41060b:	pop    r12
  41060d:	pop    rdi
  41060e:	pop    rsi
  41060f:	ret

0000000000410610 <__swc_fn_4fa09e82_000089_3c530920>:
  410610:	push   rbp
  410611:	push   rbx
  410612:	push   rsi
  410613:	push   rdi
  410614:	push   r12
  410616:	push   r13
  410618:	push   r14
  41061a:	push   r15
  41061c:	sub    rsp,0x38
  410620:	mov    rbp,rsp
  410623:	mov    rbx,r11
  410626:	mov    rsi,rdx
  410629:	mov    rdi,r8
  41062c:	mov    r12,r9
  41062f:	mov    QWORD PTR [rsp+0x18],r9
  410634:	mov    r13,r10
  410637:	movzx  r14d,BYTE PTR [rbp+0x80]
  41063f:	movzx  r15d,BYTE PTR [rbp+0x88]
  410647:	test   r11,r11
  41064a:	je     410650 <__swc_fn_4fa09e82_000089_3c530920+0x40>
  41064c:	xor    eax,eax
  41064e:	mov    BYTE PTR [rbx],al
  410650:	test   r12,r12
  410653:	je     41065e <__swc_fn_4fa09e82_000089_3c530920+0x4e>
  410655:	mov    QWORD PTR [r12+0x8],0x0
  41065e:	test   rcx,rcx
  410661:	je     410668 <__swc_fn_4fa09e82_000089_3c530920+0x58>
  410663:	test   rsi,rsi
  410666:	jne    41067b <__swc_fn_4fa09e82_000089_3c530920+0x6b>
  410668:	xor    eax,eax
  41066a:	add    rsp,0x38
  41066e:	pop    r15
  410670:	pop    r14
  410672:	pop    r13
  410674:	pop    r12
  410676:	pop    rdi
  410677:	pop    rsi
  410678:	pop    rbx
  410679:	pop    rbp
  41067a:	ret
  41067b:	call   40db20 <__swc_fn_4fa09e82_000082_ff7d1455>
  410680:	mov    r12,rax
  410683:	mov    al,r15b
  410686:	test   r15b,r15b
  410689:	jne    410699 <__swc_fn_4fa09e82_000089_3c530920+0x89>
  41068b:	mov    eax,DWORD PTR [r12+0x28]
  410690:	and    eax,0x10000
  410696:	setne  al
  410699:	lea    r15,[rsp+0x8]
  41069e:	mov    QWORD PTR [rsp+0x20],r15
  4106a3:	rex mov BYTE PTR [rsp+0x8],al
  4106a8:	test   DWORD PTR [rsi+0x28],0x400000
  4106af:	je     4106e7 <__swc_fn_4fa09e82_000089_3c530920+0xd7>
  4106b1:	test   rsi,rsi
  4106b4:	je     4106d4 <__swc_fn_4fa09e82_000089_3c530920+0xc4>
  4106b6:	mov    rax,QWORD PTR [rsi+0x38]
  4106ba:	cmp    QWORD PTR [rax+0x10],rsi
  4106be:	jne    4106d4 <__swc_fn_4fa09e82_000089_3c530920+0xc4>
  4106c0:	rex mov al,BYTE PTR [rsp+0x8]
  4106c5:	test   al,al
  4106c7:	sete   al
  4106ca:	test   r14b,r14b
  4106cd:	sete   cl
  4106d0:	test   al,cl
  4106d2:	je     4106e7 <__swc_fn_4fa09e82_000089_3c530920+0xd7>
  4106d4:	xor    eax,eax
  4106d6:	add    rsp,0x38
  4106da:	pop    r15
  4106dc:	pop    r14
  4106de:	pop    r13
  4106e0:	pop    r12
  4106e2:	pop    rdi
  4106e3:	pop    rsi
  4106e4:	pop    rbx
  4106e5:	pop    rbp
  4106e6:	ret
  4106e7:	mov    r15,r12
  4106ea:	test   r14b,r14b
  4106ed:	jne    410704 <__swc_fn_4fa09e82_000089_3c530920+0xf4>
  4106ef:	cmp    BYTE PTR [r12+0x2c],0x6
  4106f5:	jne    410704 <__swc_fn_4fa09e82_000089_3c530920+0xf4>
  4106f7:	mov    rcx,QWORD PTR [r12+0x40]
  4106fc:	call   40db20 <__swc_fn_4fa09e82_000082_ff7d1455>
  410701:	mov    r15,rax
  410704:	test   r14b,r14b
  410707:	je     41070d <__swc_fn_4fa09e82_000089_3c530920+0xfd>
  410709:	mov    r15,QWORD PTR [r15+0x30]
  41070d:	mov    rcx,rsi
  410710:	call   40db20 <__swc_fn_4fa09e82_000082_ff7d1455>
  410715:	mov    rsi,rax
  410718:	rex cmp BYTE PTR [rsi+0x2c],0x6
  41071d:	je     410754 <__swc_fn_4fa09e82_000089_3c530920+0x144>
  41071f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  410724:	je     410754 <__swc_fn_4fa09e82_000089_3c530920+0x144>
  410726:	mov    eax,DWORD PTR [rsi+0x28]
  410729:	and    eax,0x10000
  41072f:	je     410754 <__swc_fn_4fa09e82_000089_3c530920+0x144>
  410731:	rex mov al,BYTE PTR [rsp+0x8]
  410736:	test   al,al
  410738:	jne    41074d <__swc_fn_4fa09e82_000089_3c530920+0x13d>
  41073a:	xor    eax,eax
  41073c:	add    rsp,0x38
  410740:	pop    r15
  410742:	pop    r14
  410744:	pop    r13
  410746:	pop    r12
  410748:	pop    rdi
  410749:	pop    rsi
  41074a:	pop    rbx
  41074b:	pop    rbp
  41074c:	ret
  41074d:	mov    rax,QWORD PTR [rsi+0x30]
  410751:	mov    rsi,rax
  410754:	mov    r14b,r13b
  410757:	test   rbx,rbx
  41075a:	je     410790 <__swc_fn_4fa09e82_000089_3c530920+0x180>
  41075c:	cmp    BYTE PTR [r12+0x2c],0x6
  410762:	jne    410790 <__swc_fn_4fa09e82_000089_3c530920+0x180>
  410764:	lea    rdx,[rip+0x2a15]        # 413180 <__swc_rdata_base_4fa09e82+0x70>
  41076b:	mov    rcx,rsi
  41076e:	xor    r8d,r8d
  410771:	call   4085a0 <__swc_fn_4fa09e82_000090_14cf59b2>
  410776:	test   al,al
  410778:	je     410790 <__swc_fn_4fa09e82_000089_3c530920+0x180>
  41077a:	mov    BYTE PTR [rbx],0x1
  41077d:	xor    eax,eax
  41077f:	add    rsp,0x38
  410783:	pop    r15
  410785:	pop    r14
  410787:	pop    r13
  410789:	pop    r12
  41078b:	pop    rdi
  41078c:	pop    rsi
  41078d:	pop    rbx
  41078e:	pop    rbp
  41078f:	ret
  410790:	test   rdi,rdi
  410793:	jne    4107ad <__swc_fn_4fa09e82_000089_3c530920+0x19d>
  410795:	test   r13b,r13b
  410798:	jne    4107ad <__swc_fn_4fa09e82_000089_3c530920+0x19d>
  41079a:	xor    eax,eax
  41079c:	add    rsp,0x38
  4107a0:	pop    r15
  4107a2:	pop    r14
  4107a4:	pop    r13
  4107a6:	pop    r12
  4107a8:	pop    rdi
  4107a9:	pop    rsi
  4107aa:	pop    rbx
  4107ab:	pop    rbp
  4107ac:	ret
  4107ad:	rex cmp BYTE PTR [rsi+0x2c],0x6
  4107b2:	jne    410868 <__swc_fn_4fa09e82_000089_3c530920+0x258>
  4107b8:	mov    rcx,r15
  4107bb:	mov    rdx,rsi
  4107be:	xor    r8d,r8d
  4107c1:	call   4085a0 <__swc_fn_4fa09e82_000090_14cf59b2>
  4107c6:	test   al,al
  4107c8:	jne    410868 <__swc_fn_4fa09e82_000089_3c530920+0x258>
  4107ce:	test   DWORD PTR [rsi+0x28],0x10000
  4107d5:	je     4107f3 <__swc_fn_4fa09e82_000089_3c530920+0x1e3>
  4107d7:	rex mov al,BYTE PTR [rsp+0x8]
  4107dc:	test   al,al
  4107de:	jne    4107f3 <__swc_fn_4fa09e82_000089_3c530920+0x1e3>
  4107e0:	xor    eax,eax
  4107e2:	add    rsp,0x38
  4107e6:	pop    r15
  4107e8:	pop    r14
  4107ea:	pop    r13
  4107ec:	pop    r12
  4107ee:	pop    rdi
  4107ef:	pop    rsi
  4107f0:	pop    rbx
  4107f1:	pop    rbp
  4107f2:	ret
  4107f3:	test   rdi,rdi
  4107f6:	jne    41080b <__swc_fn_4fa09e82_000089_3c530920+0x1fb>
  4107f8:	xor    eax,eax
  4107fa:	add    rsp,0x38
  4107fe:	pop    r15
  410800:	pop    r14
  410802:	pop    r13
  410804:	pop    r12
  410806:	pop    rdi
  410807:	pop    rsi
  410808:	pop    rbx
  410809:	pop    rbp
  41080a:	ret
  41080b:	mov    rcx,QWORD PTR [rsi+0x40]
  41080f:	call   40db20 <__swc_fn_4fa09e82_000082_ff7d1455>
  410814:	mov    rsi,rax
  410817:	mov    rax,QWORD PTR [rdi]
  41081a:	mov    rdi,rax
  41081d:	test   rax,rax
  410820:	jne    410863 <__swc_fn_4fa09e82_000089_3c530920+0x253>
  410822:	test   rbx,rbx
  410825:	je     410863 <__swc_fn_4fa09e82_000089_3c530920+0x253>
  410827:	mov    rcx,r15
  41082a:	mov    rdx,rsi
  41082d:	xor    r8d,r8d
  410830:	call   4085a0 <__swc_fn_4fa09e82_000090_14cf59b2>
  410835:	mov    rcx,rax
  410838:	test   al,al
  41083a:	jne    41085c <__swc_fn_4fa09e82_000089_3c530920+0x24c>
  41083c:	mov    rcx,r15
  41083f:	mov    rdx,rsi
  410842:	call   40db60 <__swc_fn_4fa09e82_000085_e24ecd12>
  410847:	mov    rcx,rax
  41084a:	test   al,al
  41084c:	jne    41085c <__swc_fn_4fa09e82_000089_3c530920+0x24c>
  41084e:	mov    rcx,rsi
  410851:	mov    rdx,r15
  410854:	call   40db60 <__swc_fn_4fa09e82_000085_e24ecd12>
  410859:	mov    rcx,rax
  41085c:	test   cl,cl
  41085e:	setne  al
  410861:	mov    BYTE PTR [rbx],al
  410863:	xor    eax,eax
  410865:	mov    r14b,al
  410868:	test   rdi,rdi
  41086b:	jne    410885 <__swc_fn_4fa09e82_000089_3c530920+0x275>
  41086d:	test   r14b,r14b
  410870:	jne    410885 <__swc_fn_4fa09e82_000089_3c530920+0x275>
  410872:	xor    eax,eax
  410874:	add    rsp,0x38
  410878:	pop    r15
  41087a:	pop    r14
  41087c:	pop    r13
  41087e:	pop    r12
  410880:	pop    rdi
  410881:	pop    rsi
  410882:	pop    rbx
  410883:	pop    rbp
  410884:	ret
  410885:	rex cmp BYTE PTR [rsi+0x2c],0x12
  41088a:	je     410896 <__swc_fn_4fa09e82_000089_3c530920+0x286>
  41088c:	mov    r12,QWORD PTR [rsp+0x18]
  410891:	jmp    41091e <__swc_fn_4fa09e82_000089_3c530920+0x30e>
  410896:	mov    r12,QWORD PTR [rsp+0x18]
  41089b:	test   r12,r12
  41089e:	jne    4108b2 <__swc_fn_4fa09e82_000089_3c530920+0x2a2>
  4108a0:	mov    rcx,r15
  4108a3:	mov    rdx,rsi
  4108a6:	xor    r8d,r8d
  4108a9:	call   4085a0 <__swc_fn_4fa09e82_000090_14cf59b2>
  4108ae:	test   al,al
  4108b0:	jne    41091e <__swc_fn_4fa09e82_000089_3c530920+0x30e>
  4108b2:	test   DWORD PTR [rsi+0x28],0x10000
  4108b9:	je     4108d7 <__swc_fn_4fa09e82_000089_3c530920+0x2c7>
  4108bb:	rex mov al,BYTE PTR [rsp+0x8]
  4108c0:	test   al,al
  4108c2:	jne    4108d7 <__swc_fn_4fa09e82_000089_3c530920+0x2c7>
  4108c4:	xor    eax,eax
  4108c6:	add    rsp,0x38
  4108ca:	pop    r15
  4108cc:	pop    r14
  4108ce:	pop    r13
  4108d0:	pop    r12
  4108d2:	pop    rdi
  4108d3:	pop    rsi
  4108d4:	pop    rbx
  4108d5:	pop    rbp
  4108d6:	ret
  4108d7:	test   rdi,rdi
  4108da:	jne    4108ef <__swc_fn_4fa09e82_000089_3c530920+0x2df>
  4108dc:	xor    eax,eax
  4108de:	add    rsp,0x38
  4108e2:	pop    r15
  4108e4:	pop    r14
  4108e6:	pop    r13
  4108e8:	pop    r12
  4108ea:	pop    rdi
  4108eb:	pop    rsi
  4108ec:	pop    rbx
  4108ed:	pop    rbp
  4108ee:	ret
  4108ef:	cmp    QWORD PTR [rdi+0x8],0x0
  4108f4:	jne    410909 <__swc_fn_4fa09e82_000089_3c530920+0x2f9>
  4108f6:	xor    eax,eax
  4108f8:	add    rsp,0x38
  4108fc:	pop    r15
  4108fe:	pop    r14
  410900:	pop    r13
  410902:	pop    r12
  410904:	pop    rdi
  410905:	pop    rsi
  410906:	pop    rbx
  410907:	pop    rbp
  410908:	ret
  410909:	mov    rax,QWORD PTR [rdi+0x8]
  41090d:	mov    rax,QWORD PTR [rax]
  410910:	mov    rsi,rax
  410913:	mov    rdi,QWORD PTR [rdi]
  410916:	mov    eax,0x1
  41091b:	mov    r14b,al
  41091e:	test   rdi,rdi
  410921:	mov    rbx,QWORD PTR [rsp+0x20]
  410926:	jne    410970 <__swc_fn_4fa09e82_000089_3c530920+0x360>
  410928:	test   r14b,r14b
  41092b:	je     41095d <__swc_fn_4fa09e82_000089_3c530920+0x34d>
  41092d:	test   r12,r12
  410930:	je     41095d <__swc_fn_4fa09e82_000089_3c530920+0x34d>
  410932:	mov    rcx,r15
  410935:	mov    rdx,rsi
  410938:	xor    r8d,r8d
  41093b:	mov    r9,r12
  41093e:	mov    rbx,QWORD PTR [rsp+0x20]
  410943:	movzx  r10d,BYTE PTR [rbx]
  410947:	call   410500 <__swc_fn_4fa09e82_000083_f2d93dad>
  41094c:	add    rsp,0x38
  410950:	pop    r15
  410952:	pop    r14
  410954:	pop    r13
  410956:	pop    r12
  410958:	pop    rdi
  410959:	pop    rsi
  41095a:	pop    rbx
  41095b:	pop    rbp
  41095c:	ret
  41095d:	xor    eax,eax
  41095f:	add    rsp,0x38
  410963:	pop    r15
  410965:	pop    r14
  410967:	pop    r13
  410969:	pop    r12
  41096b:	pop    rdi
  41096c:	pop    rsi
  41096d:	pop    rbx
  41096e:	pop    rbp
  41096f:	ret
  410970:	mov    r13,rsi
  410973:	mov    QWORD PTR [rsp+0x28],rdi
  410978:	cmp    BYTE PTR [r15+0x2c],0xe
  41097d:	sete   al
  410980:	mov    r14b,al
  410983:	jne    410997 <__swc_fn_4fa09e82_000089_3c530920+0x387>
  410985:	mov    rcx,rsi
  410988:	mov    rdx,r15
  41098b:	call   40db60 <__swc_fn_4fa09e82_000085_e24ecd12>
  410990:	mov    r14b,al
  410993:	test   al,al
  410995:	jne    4109cc <__swc_fn_4fa09e82_000089_3c530920+0x3bc>
  410997:	cmp    BYTE PTR [r15+0x2c],0x12
  41099c:	je     4109cc <__swc_fn_4fa09e82_000089_3c530920+0x3bc>
  41099e:	mov    rcx,r15
  4109a1:	mov    rdx,rsi
  4109a4:	mov    r8,rdi
  4109a7:	mov    r9,r12
  4109aa:	mov    rax,rbx
  4109ad:	movzx  r10d,BYTE PTR [rax]
  4109b1:	call   410500 <__swc_fn_4fa09e82_000083_f2d93dad>
  4109b6:	test   rax,rax
  4109b9:	je     4109cc <__swc_fn_4fa09e82_000089_3c530920+0x3bc>
  4109bb:	add    rsp,0x38
  4109bf:	pop    r15
  4109c1:	pop    r14
  4109c3:	pop    r13
  4109c5:	pop    r12
  4109c7:	pop    rdi
  4109c8:	pop    rsi
  4109c9:	pop    rbx
  4109ca:	pop    rbp
  4109cb:	ret
  4109cc:	rex cmp BYTE PTR [rsi+0x2c],0xe
  4109d1:	jne    4109f0 <__swc_fn_4fa09e82_000089_3c530920+0x3e0>
  4109d3:	mov    rax,QWORD PTR [rsi+0xd8]
  4109da:	test   rax,rax
  4109dd:	je     4109f0 <__swc_fn_4fa09e82_000089_3c530920+0x3e0>
  4109df:	add    rdi,QWORD PTR [rax+0x8]
  4109e3:	mov    rax,QWORD PTR [rdi]
  4109e6:	sub    rdi,QWORD PTR [rax+0x8]
  4109ea:	mov    rax,QWORD PTR [rax]
  4109ed:	mov    rsi,rax
  4109f0:	test   r14b,r14b
  4109f3:	je     410a1f <__swc_fn_4fa09e82_000089_3c530920+0x40f>
  4109f5:	mov    rcx,r15
  4109f8:	mov    rdx,rsi
  4109fb:	mov    r8,rdi
  4109fe:	mov    r9,r13
  410a01:	mov    r14,QWORD PTR [rsp+0x28]
  410a06:	mov    r10,r14
  410a09:	call   408480 <__swc_fn_4fa09e82_000087_693f118e>
  410a0e:	add    rsp,0x38
  410a12:	pop    r15
  410a14:	pop    r14
  410a16:	pop    r13
  410a18:	pop    r12
  410a1a:	pop    rdi
  410a1b:	pop    rsi
  410a1c:	pop    rbx
  410a1d:	pop    rbp
  410a1e:	ret
  410a1f:	mov    rcx,r15
  410a22:	mov    rdx,rsi
  410a25:	mov    r8,rdi
  410a28:	mov    r9,r12
  410a2b:	movzx  r10d,BYTE PTR [rbx]
  410a2f:	call   410500 <__swc_fn_4fa09e82_000083_f2d93dad>
  410a34:	add    rsp,0x38
  410a38:	pop    r15
  410a3a:	pop    r14
  410a3c:	pop    r13
  410a3e:	pop    r12
  410a40:	pop    rdi
  410a41:	pop    rsi
  410a42:	pop    rbx
  410a43:	pop    rbp
  410a44:	ret
	...

0000000000410a50 <__swc_fn_4fa09e82_000092_809deff5>:
  410a50:	push   rbx
  410a51:	push   rsi
  410a52:	sub    rsp,0x18
  410a56:	mov    rbx,rcx
  410a59:	mov    rcx,QWORD PTR [rip+0x162e0]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  410a60:	test   rcx,rcx
  410a63:	jne    410a75 <__swc_fn_4fa09e82_000092_809deff5+0x25>
  410a65:	call   40f020 <__swc_fn_4fa09e82_000166_56054fe7>
  410a6a:	lea    rcx,[rax+0x1]
  410a6e:	mov    QWORD PTR [rip+0x162cb],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  410a75:	dec    rcx
  410a78:	call   40b620 <__swc_fn_4fa09e82_000168_39c041ad>
  410a7d:	mov    rsi,rax
  410a80:	mov    rax,QWORD PTR [rsi+0x8]
  410a84:	test   rax,rax
  410a87:	jne    410ad7 <__swc_fn_4fa09e82_000092_809deff5+0x87>
  410a89:	call   40dc50 <__swc_fn_4fa09e82_000091_f21926ed>
  410a8e:	test   al,al
  410a90:	jne    410ad7 <__swc_fn_4fa09e82_000092_809deff5+0x87>
  410a92:	lea    rdx,[rip+0x137a7]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  410a99:	mov    rcx,rdx
  410a9c:	call   407740 <__swc_fn_4fa09e82_000036_290a131c>
  410aa1:	test   al,al
  410aa3:	jne    410ab4 <__swc_fn_4fa09e82_000092_809deff5+0x64>
  410aa5:	mov    rcx,rdx
  410aa8:	call   40c540 <__swc_fn_4fa09e82_000034_cf5ba7bd>
  410aad:	lea    rdx,[rip+0x1378c]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  410ab4:	mov    QWORD PTR [rsp+0x8],rdx
  410ab9:	lea    rax,[rip+0x2690]        # 413150 <__swc_rdata_base_4fa09e82+0x40>
  410ac0:	mov    QWORD PTR [rsp+0x10],rax
  410ac5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  410acb:	vmovups XMMWORD PTR [rsi],xmm0
  410acf:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  410ad7:	vmovups xmm0,XMMWORD PTR [rsi]
  410adb:	vmovups XMMWORD PTR [rbx],xmm0
  410adf:	mov    rax,rbx
  410ae2:	add    rsp,0x18
  410ae6:	pop    rsi
  410ae7:	pop    rbx
  410ae8:	ret
  410ae9:	add    BYTE PTR [rax],al
  410aeb:	add    BYTE PTR [rax],al
  410aed:	add    BYTE PTR [rax],al
	...

0000000000410af0 <__swc_fn_4fa09e82_000095_8cc4b392>:
  410af0:	sub    rsp,0x8
  410af4:	call   40e1c0 <__swc_fn_4fa09e82_000118_5aba1420>
  410af9:	add    rsp,0x8
  410afd:	ret
	...

0000000000410b00 <__swc_fn_4fa09e82_000098_f82a1ed3>:
  410b00:	push   rbx
  410b01:	push   rsi
  410b02:	sub    rsp,0x28
  410b06:	mov    rbx,rcx
  410b09:	xor    esi,esi
  410b0b:	jmp    410b20 <__swc_fn_4fa09e82_000098_f82a1ed3+0x20>
  410b0d:	nop    DWORD PTR [rax]
  410b10:	mov    QWORD PTR [rbx+0x28],rsi
  410b14:	mov    rsi,rbx
  410b17:	mov    rbx,rax
  410b1a:	nop    WORD PTR [rax+rax*1+0x0]
  410b20:	test   rbx,rbx
  410b23:	je     410b83 <__swc_fn_4fa09e82_000098_f82a1ed3+0x83>
  410b25:	mov    rcx,rbx
  410b28:	mov    edx,0x1
  410b2d:	call   408200 <__swc_fn_4fa09e82_000078_140918ec>
  410b32:	cmp    rax,0x1
  410b36:	jne    410b83 <__swc_fn_4fa09e82_000098_f82a1ed3+0x83>
  410b38:	mov    r10,QWORD PTR [rbx+0x18]
  410b3c:	mov    rcx,r10
  410b3f:	mov    edx,0x1
  410b44:	call   408200 <__swc_fn_4fa09e82_000078_140918ec>
  410b49:	cmp    rax,0x1
  410b4d:	jne    410b5c <__swc_fn_4fa09e82_000098_f82a1ed3+0x5c>
  410b4f:	mov    rcx,r10
  410b52:	call   40ddf0 <__swc_fn_4fa09e82_000097_96d6739a>
  410b57:	test   rax,rax
  410b5a:	jne    410b10 <__swc_fn_4fa09e82_000098_f82a1ed3+0x10>
  410b5c:	mov    rax,QWORD PTR [rbx+0x20]
  410b60:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  410b65:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410b6b:	lea    rcx,[rsp+0x8]
  410b70:	mov    rdx,rbx
  410b73:	mov    r8d,0x30
  410b79:	mov    rbx,rax
  410b7c:	call   408960 <__swc_fn_4fa09e82_000096_a4baaa40>
  410b81:	jmp    410b20 <__swc_fn_4fa09e82_000098_f82a1ed3+0x20>
  410b83:	test   rsi,rsi
  410b86:	jne    410b8f <__swc_fn_4fa09e82_000098_f82a1ed3+0x8f>
  410b88:	add    rsp,0x28
  410b8c:	pop    rsi
  410b8d:	pop    rbx
  410b8e:	ret
  410b8f:	mov    rax,rsi
  410b92:	mov    rsi,QWORD PTR [rsi+0x28]
  410b96:	mov    rbx,QWORD PTR [rax+0x20]
  410b9a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  410b9f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  410ba5:	lea    rcx,[rsp+0x18]
  410baa:	mov    rdx,rax
  410bad:	mov    r8d,0x30
  410bb3:	call   408960 <__swc_fn_4fa09e82_000096_a4baaa40>
  410bb8:	jmp    410b20 <__swc_fn_4fa09e82_000098_f82a1ed3+0x20>
  410bbd:	add    BYTE PTR [rax],al
	...

0000000000410bc0 <__swc_fn_4fa09e82_000101_afcb7774>:
  410bc0:	push   rbx
  410bc1:	push   rsi
  410bc2:	push   rdi
  410bc3:	push   r12
  410bc5:	push   r13
  410bc7:	sub    rsp,0x20
  410bcb:	mov    rbx,rcx
  410bce:	lea    rsi,[rcx+0x6f8]
  410bd5:	mov    edi,0x4
  410bda:	mov    r12,rsi
  410bdd:	test   rdi,rdi
  410be0:	je     410c2a <__swc_fn_4fa09e82_000101_afcb7774+0x6a>
  410be2:	cs nop WORD PTR [rax+rax*1+0x0]
  410bec:	nop    DWORD PTR [rax+0x0]
  410bf0:	mov    rcx,QWORD PTR [r12+0x10]
  410bf5:	mov    QWORD PTR [r12+0x10],0x0
  410bfe:	vxorps xmm0,xmm0,xmm0
  410c02:	vmovups XMMWORD PTR [r12],xmm0
  410c08:	vmovups XMMWORD PTR [r12+0x28],xmm0
  410c0f:	mov    DWORD PTR [r12+0x20],0x0
  410c18:	call   4089b0 <__swc_fn_4fa09e82_000099_5232b57d>
  410c1d:	add    r12,0x90
  410c24:	sub    rdi,0x1
  410c28:	jne    410bf0 <__swc_fn_4fa09e82_000101_afcb7774+0x30>
  410c2a:	mov    rax,QWORD PTR [rbx+0x938]
  410c31:	mov    rdi,rax
  410c34:	test   rdi,rdi
  410c37:	je     410c91 <__swc_fn_4fa09e82_000101_afcb7774+0xd1>
  410c39:	nop    DWORD PTR [rax+0x0]
  410c40:	mov    r12d,0x10
  410c46:	lea    r13,[rdi+0x18]
  410c4a:	test   r12,r12
  410c4d:	je     410c86 <__swc_fn_4fa09e82_000101_afcb7774+0xc6>
  410c4f:	nop
  410c50:	mov    rcx,QWORD PTR [r13+0x10]
  410c54:	mov    QWORD PTR [r13+0x10],0x0
  410c5c:	vxorps xmm0,xmm0,xmm0
  410c60:	vmovups XMMWORD PTR [r13+0x0],xmm0
  410c66:	vmovups XMMWORD PTR [r13+0x28],xmm0
  410c6c:	mov    DWORD PTR [r13+0x20],0x0
  410c74:	call   4089b0 <__swc_fn_4fa09e82_000099_5232b57d>
  410c79:	add    r13,0x90
  410c80:	sub    r12,0x1
  410c84:	jne    410c50 <__swc_fn_4fa09e82_000101_afcb7774+0x90>
  410c86:	mov    rax,QWORD PTR [rdi]
  410c89:	mov    rdi,rax
  410c8c:	test   rax,rax
  410c8f:	jne    410c40 <__swc_fn_4fa09e82_000101_afcb7774+0x80>
  410c91:	vxorps xmm0,xmm0,xmm0
  410c95:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  410c9d:	mov    DWORD PTR [rbx+0x9b0],0x0
  410ca7:	mov    DWORD PTR [rbx+0x9a8],0x0
  410cb1:	mov    edi,0x4
  410cb6:	mov    r12,rsi
  410cb9:	lea    rsi,[rsi+0x38]
  410cbd:	test   rdi,rdi
  410cc0:	je     410cec <__swc_fn_4fa09e82_000101_afcb7774+0x12c>
  410cc2:	cs nop WORD PTR [rax+rax*1+0x0]
  410ccc:	nop    DWORD PTR [rax+0x0]
  410cd0:	mov    rcx,rsi
  410cd3:	call   411b90 <__swc_fn_4fa09e82_000158_3495a3ca>
  410cd8:	add    rsi,0x90
  410cdf:	add    r12,0x90
  410ce6:	sub    rdi,0x1
  410cea:	jne    410cd0 <__swc_fn_4fa09e82_000101_afcb7774+0x110>
  410cec:	mov    rax,QWORD PTR [rbx+0x938]
  410cf3:	mov    rdi,rax
  410cf6:	mov    QWORD PTR [rbx+0x938],0x0
  410d01:	test   rdi,rdi
  410d04:	je     410d75 <__swc_fn_4fa09e82_000101_afcb7774+0x1b5>
  410d0a:	nop    WORD PTR [rax+rax*1+0x0]
  410d10:	mov    esi,0x10
  410d15:	lea    r12,[rdi+0x18]
  410d19:	lea    r13,[rdi+0x50]
  410d1d:	test   rsi,rsi
  410d20:	je     410d4c <__swc_fn_4fa09e82_000101_afcb7774+0x18c>
  410d22:	cs nop WORD PTR [rax+rax*1+0x0]
  410d2c:	nop    DWORD PTR [rax+0x0]
  410d30:	mov    rcx,r13
  410d33:	call   411b90 <__swc_fn_4fa09e82_000158_3495a3ca>
  410d38:	add    r13,0x90
  410d3f:	add    r12,0x90
  410d46:	sub    rsi,0x1
  410d4a:	jne    410d30 <__swc_fn_4fa09e82_000101_afcb7774+0x170>
  410d4c:	mov    rax,QWORD PTR [rdi]
  410d4f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  410d54:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410d5a:	lea    rcx,[rsp+0x8]
  410d5f:	mov    rdx,rdi
  410d62:	mov    r8d,0x918
  410d68:	mov    rdi,rax
  410d6b:	call   408960 <__swc_fn_4fa09e82_000096_a4baaa40>
  410d70:	test   rdi,rdi
  410d73:	jne    410d10 <__swc_fn_4fa09e82_000101_afcb7774+0x150>
  410d75:	lea    rcx,[rbx+0x68]
  410d79:	call   411b90 <__swc_fn_4fa09e82_000158_3495a3ca>
  410d7e:	add    rsp,0x20
  410d82:	pop    r13
  410d84:	pop    r12
  410d86:	pop    rdi
  410d87:	pop    rsi
  410d88:	pop    rbx
  410d89:	ret
  410d8a:	add    BYTE PTR [rax],al
  410d8c:	add    BYTE PTR [rax],al
	...

0000000000410d90 <__swc_fn_4fa09e82_000104_04d1a8be>:
  410d90:	xor    eax,eax
  410d92:	cs nop WORD PTR [rax+rax*1+0x0]
  410d9c:	nop    DWORD PTR [rax+0x0]
  410da0:	mov    r9,r8
  410da3:	sub    r9,rax
  410da6:	cmp    r9,0x40
  410daa:	jb     410de8 <__swc_fn_4fa09e82_000104_04d1a8be+0x58>
  410dac:	lea    r9,[rcx+rax*1]
  410db0:	lea    r10,[rdx+rax*1]
  410db4:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  410dba:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  410dc0:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  410dc6:	vmovups xmm3,XMMWORD PTR [r10]
  410dcb:	vmovups XMMWORD PTR [r9],xmm3
  410dd0:	vmovups XMMWORD PTR [r9+0x10],xmm0
  410dd6:	vmovups XMMWORD PTR [r9+0x20],xmm1
  410ddc:	vmovups XMMWORD PTR [r9+0x30],xmm2
  410de2:	lea    rax,[rax+0x40]
  410de6:	jmp    410da0 <__swc_fn_4fa09e82_000104_04d1a8be+0x10>
  410de8:	nop    DWORD PTR [rax+rax*1+0x0]
  410df0:	mov    r9,r8
  410df3:	sub    r9,rax
  410df6:	cmp    r9,0x10
  410dfa:	jb     410e14 <__swc_fn_4fa09e82_000104_04d1a8be+0x84>
  410dfc:	lea    r9,[rdx+rax*1]
  410e00:	lea    r10,[rcx+rax*1]
  410e04:	vmovups xmm0,XMMWORD PTR [r9]
  410e09:	vmovups XMMWORD PTR [r10],xmm0
  410e0e:	lea    rax,[rax+0x10]
  410e12:	jmp    410df0 <__swc_fn_4fa09e82_000104_04d1a8be+0x60>
  410e14:	cs nop WORD PTR [rax+rax*1+0x0]
  410e1e:	xchg   ax,ax
  410e20:	mov    r9,r8
  410e23:	sub    r9,rax
  410e26:	cmp    r9,0x8
  410e2a:	jb     410e3d <__swc_fn_4fa09e82_000104_04d1a8be+0xad>
  410e2c:	lea    r9,[rcx+rax*1]
  410e30:	mov    r10,QWORD PTR [rdx+rax*1]
  410e34:	mov    QWORD PTR [r9],r10
  410e37:	lea    rax,[rax+0x8]
  410e3b:	jmp    410e20 <__swc_fn_4fa09e82_000104_04d1a8be+0x90>
  410e3d:	cmp    rax,r8
  410e40:	jae    410e60 <__swc_fn_4fa09e82_000104_04d1a8be+0xd0>
  410e42:	cs nop WORD PTR [rax+rax*1+0x0]
  410e4c:	nop    DWORD PTR [rax+0x0]
  410e50:	mov    r9b,BYTE PTR [rdx+rax*1]
  410e54:	mov    BYTE PTR [rcx+rax*1],r9b
  410e58:	inc    rax
  410e5b:	cmp    rax,r8
  410e5e:	jb     410e50 <__swc_fn_4fa09e82_000104_04d1a8be+0xc0>
  410e60:	ret
	...

0000000000410e70 <__swc_fn_4fa09e82_000107_aba05410>:
  410e70:	test   r8,r8
  410e73:	jne    410e78 <__swc_fn_4fa09e82_000107_aba05410+0x8>
  410e75:	xor    eax,eax
  410e77:	ret
  410e78:	xor    eax,eax
  410e7a:	nop    WORD PTR [rax+rax*1+0x0]
  410e80:	mov    r9,r8
  410e83:	sub    r9,rax
  410e86:	cmp    r9,0x10
  410e8a:	jb     410ed4 <__swc_fn_4fa09e82_000107_aba05410+0x64>
  410e8c:	lea    r9,[rcx+rax*1]
  410e90:	lea    r10,[rdx+rax*1]
  410e94:	vmovups xmm0,XMMWORD PTR [r10]
  410e99:	vmovups xmm1,XMMWORD PTR [r9]
  410e9e:	vpcmpeqb xmm0,xmm1,xmm0
  410ea2:	vpmovmskb r9d,xmm0
  410ea6:	cmp    r9d,0xffff
  410ead:	je     410ece <__swc_fn_4fa09e82_000107_aba05410+0x5e>
  410eaf:	not    r9d
  410eb2:	xor    r8d,r8d
  410eb5:	movzx  r9d,r9w
  410eb9:	tzcnt  r8d,r9d
  410ebe:	add    rax,r8
  410ec1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410ec5:	movzx  eax,BYTE PTR [rdx+rax*1]
  410ec9:	sub    ecx,eax
  410ecb:	mov    eax,ecx
  410ecd:	ret
  410ece:	lea    rax,[rax+0x10]
  410ed2:	jmp    410e80 <__swc_fn_4fa09e82_000107_aba05410+0x10>
  410ed4:	cmp    r9,0x8
  410ed8:	jb     410f4b <__swc_fn_4fa09e82_000107_aba05410+0xdb>
  410eda:	lea    r9,[rcx+rax*1]
  410ede:	lea    r10,[rdx+rax*1]
  410ee2:	mov    r9,QWORD PTR [r9]
  410ee5:	xor    r9,QWORD PTR [r10]
  410ee8:	test   r9,r9
  410eeb:	je     410f09 <__swc_fn_4fa09e82_000107_aba05410+0x99>
  410eed:	xor    r8d,r8d
  410ef0:	tzcnt  r8,r9
  410ef5:	shr    r8,0x3
  410ef9:	add    rax,r8
  410efc:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410f00:	movzx  eax,BYTE PTR [rdx+rax*1]
  410f04:	sub    ecx,eax
  410f06:	mov    eax,ecx
  410f08:	ret
  410f09:	lea    rax,[rax+0x8]
  410f0d:	cmp    rax,r8
  410f10:	jne    410f15 <__swc_fn_4fa09e82_000107_aba05410+0xa5>
  410f12:	xor    eax,eax
  410f14:	ret
  410f15:	lea    rax,[r8-0x8]
  410f19:	lea    r8,[rcx+rax*1]
  410f1d:	lea    r9,[rdx+rax*1]
  410f21:	mov    r8,QWORD PTR [r8]
  410f24:	xor    r8,QWORD PTR [r9]
  410f27:	test   r8,r8
  410f2a:	je     410f48 <__swc_fn_4fa09e82_000107_aba05410+0xd8>
  410f2c:	xor    r9d,r9d
  410f2f:	tzcnt  r9,r8
  410f34:	shr    r9,0x3
  410f38:	add    rax,r9
  410f3b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410f3f:	movzx  eax,BYTE PTR [rdx+rax*1]
  410f43:	sub    ecx,eax
  410f45:	mov    eax,ecx
  410f47:	ret
  410f48:	xor    eax,eax
  410f4a:	ret
  410f4b:	cmp    r9,0x4
  410f4f:	jb     410fc2 <__swc_fn_4fa09e82_000107_aba05410+0x152>
  410f51:	lea    r9,[rcx+rax*1]
  410f55:	lea    r10,[rdx+rax*1]
  410f59:	mov    r9d,DWORD PTR [r9]
  410f5c:	xor    r9d,DWORD PTR [r10]
  410f5f:	test   r9d,r9d
  410f62:	je     410f80 <__swc_fn_4fa09e82_000107_aba05410+0x110>
  410f64:	xor    r8d,r8d
  410f67:	tzcnt  r8,r9
  410f6c:	shr    r8,0x3
  410f70:	add    rax,r8
  410f73:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410f77:	movzx  eax,BYTE PTR [rdx+rax*1]
  410f7b:	sub    ecx,eax
  410f7d:	mov    eax,ecx
  410f7f:	ret
  410f80:	lea    rax,[rax+0x4]
  410f84:	cmp    rax,r8
  410f87:	jne    410f8c <__swc_fn_4fa09e82_000107_aba05410+0x11c>
  410f89:	xor    eax,eax
  410f8b:	ret
  410f8c:	lea    rax,[r8-0x4]
  410f90:	lea    r8,[rcx+rax*1]
  410f94:	lea    r9,[rdx+rax*1]
  410f98:	mov    r8d,DWORD PTR [r8]
  410f9b:	xor    r8d,DWORD PTR [r9]
  410f9e:	test   r8d,r8d
  410fa1:	je     410fbf <__swc_fn_4fa09e82_000107_aba05410+0x14f>
  410fa3:	xor    r9d,r9d
  410fa6:	tzcnt  r9,r8
  410fab:	shr    r9,0x3
  410faf:	add    rax,r9
  410fb2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410fb6:	movzx  eax,BYTE PTR [rdx+rax*1]
  410fba:	sub    ecx,eax
  410fbc:	mov    eax,ecx
  410fbe:	ret
  410fbf:	xor    eax,eax
  410fc1:	ret
  410fc2:	cmp    r9,0x2
  410fc6:	jb     411019 <__swc_fn_4fa09e82_000107_aba05410+0x1a9>
  410fc8:	lea    r9,[rcx+rax*1]
  410fcc:	lea    r10,[rdx+rax*1]
  410fd0:	mov    r9w,WORD PTR [r9]
  410fd4:	xor    r9w,WORD PTR [r10]
  410fd8:	test   r9w,r9w
  410fdc:	je     410ffe <__swc_fn_4fa09e82_000107_aba05410+0x18e>
  410fde:	xor    r8d,r8d
  410fe1:	movzx  r9d,r9w
  410fe5:	tzcnt  r8,r9
  410fea:	shr    r8,0x3
  410fee:	add    rax,r8
  410ff1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410ff5:	movzx  eax,BYTE PTR [rdx+rax*1]
  410ff9:	sub    ecx,eax
  410ffb:	mov    eax,ecx
  410ffd:	ret
  410ffe:	lea    rax,[rax+0x2]
  411002:	cmp    rax,r8
  411005:	jne    41100a <__swc_fn_4fa09e82_000107_aba05410+0x19a>
  411007:	xor    eax,eax
  411009:	ret
  41100a:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  411010:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  411016:	sub    eax,ecx
  411018:	ret
  411019:	test   r9,r9
  41101c:	je     41102b <__swc_fn_4fa09e82_000107_aba05410+0x1bb>
  41101e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  411022:	movzx  eax,BYTE PTR [rdx+rax*1]
  411026:	sub    ecx,eax
  411028:	mov    eax,ecx
  41102a:	ret
  41102b:	xor    eax,eax
  41102d:	ret
	...

0000000000411030 <__swc_fn_4fa09e82_000110_9f5af8ae>:
  411030:	push   r12
  411032:	push   r13
  411034:	push   r14
  411036:	push   rdi
  411037:	push   rsi
  411038:	push   r15
  41103a:	sub    rsp,0xd8
  411041:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  411047:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  41104d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  411053:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  411059:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  41105f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  411068:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  411071:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  41107a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  411083:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  41108c:	mov    r12,rcx
  41108f:	test   rcx,rcx
  411092:	je     4110ae <__swc_fn_4fa09e82_000110_9f5af8ae+0x7e>
  411094:	mov    eax,r12d
  411097:	and    eax,0xfff
  41109d:	setne  al
  4110a0:	cmp    r12,0xffffffffffffefff
  4110a7:	seta   cl
  4110aa:	or     al,cl
  4110ac:	je     4110b5 <__swc_fn_4fa09e82_000110_9f5af8ae+0x85>
  4110ae:	xor    eax,eax
  4110b0:	jmp    41114b <__swc_fn_4fa09e82_000110_9f5af8ae+0x11b>
  4110b5:	call   40df80 <__swc_fn_4fa09e82_000109_b8f4bd15>
  4110ba:	mov    r13,rax
  4110bd:	test   rax,rax
  4110c0:	jne    4110c9 <__swc_fn_4fa09e82_000110_9f5af8ae+0x99>
  4110c2:	xor    eax,eax
  4110c4:	jmp    41114b <__swc_fn_4fa09e82_000110_9f5af8ae+0x11b>
  4110c9:	lea    r14,[r12+0x1000]
  4110d1:	xor    edi,edi
  4110d3:	mov    rsi,r14
  4110d6:	xor    edx,edx
  4110d8:	mov    ecx,0x22
  4110dd:	mov    eax,0xffffffff
  4110e2:	movsxd r8,eax
  4110e5:	xor    r9d,r9d
  4110e8:	xor    eax,eax
  4110ea:	call   4070d0 <mmap@plt>
  4110ef:	mov    r15,rax
  4110f2:	cmp    rax,0xffffffffffffffff
  4110f6:	jne    4110fc <__swc_fn_4fa09e82_000110_9f5af8ae+0xcc>
  4110f8:	xor    eax,eax
  4110fa:	jmp    41114b <__swc_fn_4fa09e82_000110_9f5af8ae+0x11b>
  4110fc:	mov    rdi,r15
  4110ff:	mov    esi,0x1000
  411104:	mov    edx,0x3
  411109:	xor    eax,eax
  41110b:	call   407170 <mprotect@plt>
  411110:	test   eax,eax
  411112:	je     411125 <__swc_fn_4fa09e82_000110_9f5af8ae+0xf5>
  411114:	mov    rdi,r15
  411117:	mov    rsi,r14
  41111a:	xor    eax,eax
  41111c:	call   407160 <munmap@plt>
  411121:	xor    eax,eax
  411123:	jmp    41114b <__swc_fn_4fa09e82_000110_9f5af8ae+0x11b>
  411125:	mov    QWORD PTR [r15+0x8],r12
  411129:	mov    rcx,r13
  41112c:	call   411790 <__swc_fn_4fa09e82_000134_807fd51d>
  411131:	mov    rax,QWORD PTR [r13+0x8]
  411135:	mov    QWORD PTR [r15],rax
  411138:	mov    QWORD PTR [r13+0x8],r15
  41113c:	mov    rcx,r13
  41113f:	call   409d20 <__swc_fn_4fa09e82_000135_10472836>
  411144:	lea    rax,[r15+0x1000]
  41114b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  411151:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  411157:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  41115d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  411163:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  411169:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  411172:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  41117b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  411184:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  41118d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  411196:	add    rsp,0xd8
  41119d:	pop    r15
  41119f:	pop    rsi
  4111a0:	pop    rdi
  4111a1:	pop    r14
  4111a3:	pop    r13
  4111a5:	pop    r12
  4111a7:	ret
	...

00000000004111b0 <__swc_fn_4fa09e82_000113_2f7f9346>:
  4111b0:	push   rbx
  4111b1:	push   r12
  4111b3:	push   rdi
  4111b4:	push   rsi
  4111b5:	sub    rsp,0xa8
  4111bc:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4111c2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4111c8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4111ce:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4111d4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4111da:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4111e0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4111e6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4111ec:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4111f5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4111fe:	mov    rbx,rdx
  411201:	mov    r12,rcx
  411204:	mov    rdi,rcx
  411207:	mov    rsi,rdx
  41120a:	xor    edx,edx
  41120c:	xor    eax,eax
  41120e:	call   407170 <mprotect@plt>
  411213:	test   eax,eax
  411215:	jne    411239 <__swc_fn_4fa09e82_000113_2f7f9346+0x89>
  411217:	mov    rcx,r12
  41121a:	mov    rdx,rbx
  41121d:	xor    al,al
  41121f:	mov    r8,rax
  411222:	call   4097c0 <__swc_fn_4fa09e82_000111_918d5a21>
  411227:	mov    rdi,r12
  41122a:	mov    rsi,rbx
  41122d:	mov    edx,0x4
  411232:	xor    eax,eax
  411234:	call   4071d0 <madvise@plt>
  411239:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41123f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411245:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41124b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411251:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411257:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  41125d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411263:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411269:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411272:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41127b:	add    rsp,0xa8
  411282:	pop    rsi
  411283:	pop    rdi
  411284:	pop    r12
  411286:	pop    rbx
  411287:	ret
	...

0000000000411290 <__swc_fn_4fa09e82_000116_3f6af4b1>:
  411290:	push   rsi
  411291:	push   rdi
  411292:	push   r12
  411294:	push   r13
  411296:	push   r14
  411298:	sub    rsp,0xe0
  41129f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  4112a5:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  4112ab:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  4112b1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  4112b7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  4112bd:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  4112c6:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  4112cf:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  4112d8:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  4112e1:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  4112ea:	mov    rsi,rdx
  4112ed:	mov    rdi,rcx
  4112f0:	call   40df80 <__swc_fn_4fa09e82_000109_b8f4bd15>
  4112f5:	mov    r12,rax
  4112f8:	test   rax,rax
  4112fb:	jne    411302 <__swc_fn_4fa09e82_000116_3f6af4b1+0x72>
  4112fd:	jmp    411376 <__swc_fn_4fa09e82_000116_3f6af4b1+0xe6>
  411302:	mov    rcx,r12
  411305:	call   411790 <__swc_fn_4fa09e82_000134_807fd51d>
  41130a:	lea    r13,[r12+0x8]
  41130f:	mov    rax,QWORD PTR [r13+0x0]
  411313:	test   rax,rax
  411316:	je     41136e <__swc_fn_4fa09e82_000116_3f6af4b1+0xde>
  411318:	nop    DWORD PTR [rax+rax*1+0x0]
  411320:	lea    rcx,[rax+0x1000]
  411327:	cmp    rcx,rdi
  41132a:	jne    411362 <__swc_fn_4fa09e82_000116_3f6af4b1+0xd2>
  41132c:	cmp    QWORD PTR [rax+0x8],rsi
  411330:	je     41133c <__swc_fn_4fa09e82_000116_3f6af4b1+0xac>
  411332:	mov    rcx,r12
  411335:	call   409d20 <__swc_fn_4fa09e82_000135_10472836>
  41133a:	jmp    411376 <__swc_fn_4fa09e82_000116_3f6af4b1+0xe6>
  41133c:	mov    r14,QWORD PTR [rax]
  41133f:	mov    rdi,rax
  411342:	lea    rsi,[rsi+0x1000]
  411349:	xor    eax,eax
  41134b:	call   407160 <munmap@plt>
  411350:	test   eax,eax
  411352:	jne    411358 <__swc_fn_4fa09e82_000116_3f6af4b1+0xc8>
  411354:	mov    QWORD PTR [r13+0x0],r14
  411358:	mov    rcx,r12
  41135b:	call   409d20 <__swc_fn_4fa09e82_000135_10472836>
  411360:	jmp    411376 <__swc_fn_4fa09e82_000116_3f6af4b1+0xe6>
  411362:	mov    r13,rax
  411365:	mov    rax,QWORD PTR [r13+0x0]
  411369:	test   rax,rax
  41136c:	jne    411320 <__swc_fn_4fa09e82_000116_3f6af4b1+0x90>
  41136e:	mov    rcx,r12
  411371:	call   409d20 <__swc_fn_4fa09e82_000135_10472836>
  411376:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  41137c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  411382:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  411388:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  41138e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  411394:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  41139d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  4113a6:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  4113af:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  4113b8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  4113c1:	add    rsp,0xe0
  4113c8:	pop    r14
  4113ca:	pop    r13
  4113cc:	pop    r12
  4113ce:	pop    rdi
  4113cf:	pop    rsi
  4113d0:	ret
	...

00000000004113e0 <__swc_fn_4fa09e82_000119_591530fe>:
  4113e0:	push   rdi
  4113e1:	push   rsi
  4113e2:	sub    rsp,0xa8
  4113e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4113ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4113f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4113fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411401:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411407:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41140d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411413:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411419:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411422:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41142b:	mov    rdi,0xfffffffffffffd66
  411432:	xor    eax,eax
  411434:	call   407180 <exit@plt>
  411439:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41143f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411445:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41144b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411451:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411457:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  41145d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411463:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411469:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411472:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41147b:	add    rsp,0xa8
  411482:	pop    rsi
  411483:	pop    rdi
  411484:	ret
	...

00000000004114a0 <__swc_fn_4fa09e82_000122_1c5e75b6>:
  4114a0:	push   rbx
  4114a1:	push   rsi
  4114a2:	push   rdi
  4114a3:	sub    rsp,0x30
  4114a7:	mov    rbx,rdx
  4114aa:	mov    esi,ecx
  4114ac:	test   ecx,ecx
  4114ae:	je     411583 <__swc_fn_4fa09e82_000122_1c5e75b6+0xe3>
  4114b4:	mov    rcx,rsi
  4114b7:	shl    rcx,0x4
  4114bb:	call   40da90 <__swc_fn_4fa09e82_000079_633af784>
  4114c0:	test   rax,rax
  4114c3:	je     411572 <__swc_fn_4fa09e82_000122_1c5e75b6+0xd2>
  4114c9:	mov    rcx,rsi
  4114cc:	xor    edx,edx
  4114ce:	test   rsi,rsi
  4114d1:	jbe    411552 <__swc_fn_4fa09e82_000122_1c5e75b6+0xb2>
  4114d7:	nop    WORD PTR [rax+rax*1+0x0]
  4114e0:	mov    r8d,edx
  4114e3:	mov    r9,QWORD PTR [rbx+r8*8]
  4114e7:	add    r8,r8
  4114ea:	lea    r8,[rax+r8*8]
  4114ee:	xor    r10d,r10d
  4114f1:	test   r9,r9
  4114f4:	je     411530 <__swc_fn_4fa09e82_000122_1c5e75b6+0x90>
  4114f6:	mov    r11,r9
  4114f9:	mov    dil,BYTE PTR [r11]
  4114fc:	test   dil,dil
  4114ff:	je     411530 <__swc_fn_4fa09e82_000122_1c5e75b6+0x90>
  411501:	cs nop WORD PTR [rax+rax*1+0x0]
  41150b:	cs nop WORD PTR [rax+rax*1+0x0]
  411515:	cs nop WORD PTR [rax+rax*1+0x0]
  41151f:	nop
  411520:	add    r11,0x1
  411524:	add    r10,0x1
  411528:	mov    dil,BYTE PTR [r11]
  41152b:	test   dil,dil
  41152e:	jne    411520 <__swc_fn_4fa09e82_000122_1c5e75b6+0x80>
  411530:	mov    QWORD PTR [rsp+0x18],r9
  411535:	mov    QWORD PTR [rsp+0x20],r10
  41153a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411540:	vmovups XMMWORD PTR [r8],xmm0
  411545:	add    rdx,0x1
  411549:	cmp    rdx,rcx
  41154c:	jb     4114e0 <__swc_fn_4fa09e82_000122_1c5e75b6+0x40>
  411552:	lea    rcx,[rip+0x157f7]        # 426d50 <__swc_bss_base_4fa09e82+0x2d10>
  411559:	mov    QWORD PTR [rsp+0x8],rax
  41155e:	mov    esi,esi
  411560:	mov    QWORD PTR [rsp+0x10],rsi
  411565:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  41156b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411570:	jmp    411583 <__swc_fn_4fa09e82_000122_1c5e75b6+0xe3>
  411572:	lea    rcx,[rip+0x1fa7]        # 413520 <__swc_rdata_base_4fa09e82+0x410>
  411579:	call   409870 <__swc_fn_4fa09e82_000117_3f5cfdef>
  41157e:	call   4113e0 <__swc_fn_4fa09e82_000119_591530fe>
  411583:	add    rsp,0x30
  411587:	pop    rdi
  411588:	pop    rsi
  411589:	pop    rbx
  41158a:	ret
  41158b:	add    BYTE PTR [rax],al
  41158d:	add    BYTE PTR [rax],al
	...

0000000000411590 <__swc_fn_4fa09e82_000125_37eaf452>:
  411590:	push   rdi
  411591:	push   rsi
  411592:	sub    rsp,0xa8
  411599:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41159f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4115a5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4115ab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4115b1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4115b7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4115bd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4115c3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4115c9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4115d2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4115db:	mov    edi,ecx
  4115dd:	xor    eax,eax
  4115df:	call   4071e0 <pthread_key_delete@plt>
  4115e4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4115ea:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4115f0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4115f6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4115fc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411602:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411608:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41160e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411614:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41161d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411626:	add    rsp,0xa8
  41162d:	pop    rsi
  41162e:	pop    rdi
  41162f:	ret

0000000000411630 <__swc_fn_4fa09e82_000128_f163135d>:
  411630:	push   rdi
  411631:	push   rsi
  411632:	sub    rsp,0xa8
  411639:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41163f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411645:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41164b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411651:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411657:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41165d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411663:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411669:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411672:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41167b:	test   rcx,rcx
  41167e:	je     41168f <__swc_fn_4fa09e82_000128_f163135d+0x5f>
  411680:	lea    rax,[rcx-0x1]
  411684:	mov    eax,eax
  411686:	mov    edi,eax
  411688:	xor    eax,eax
  41168a:	call   4071e0 <pthread_key_delete@plt>
  41168f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  411695:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  41169b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4116a1:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4116a7:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4116ad:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4116b3:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4116b9:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4116bf:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4116c8:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4116d1:	add    rsp,0xa8
  4116d8:	pop    rsi
  4116d9:	pop    rdi
  4116da:	ret
  4116db:	add    BYTE PTR [rax],al
  4116dd:	add    BYTE PTR [rax],al
	...

00000000004116e0 <__swc_fn_4fa09e82_000131_375c7357>:
  4116e0:	push   rsi
  4116e1:	push   rdi
  4116e2:	sub    rsp,0xa8
  4116e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4116ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4116f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4116fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411701:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411707:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41170d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411713:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411719:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411722:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41172b:	xor    eax,eax
  41172d:	call   4071f0 <gettid@plt>
  411732:	movsxd rax,eax
  411735:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41173b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411741:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411747:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41174d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411753:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411759:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41175f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411765:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41176e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411777:	add    rsp,0xa8
  41177e:	pop    rdi
  41177f:	pop    rsi
  411780:	ret
	...

0000000000411790 <__swc_fn_4fa09e82_000134_807fd51d>:
  411790:	push   rbx
  411791:	push   rdi
  411792:	push   rsi
  411793:	sub    rsp,0xc0
  41179a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4117a0:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4117a6:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4117ac:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4117b2:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4117b8:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4117be:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4117c4:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4117cd:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4117d6:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4117df:	mov    rbx,rcx
  4117e2:	cs nop WORD PTR [rax+rax*1+0x0]
  4117ec:	nop    DWORD PTR [rax+0x0]
  4117f0:	mov    edx,0x80000000
  4117f5:	xor    eax,eax
  4117f7:	lock cmpxchg DWORD PTR [rbx],edx
  4117fb:	test   eax,eax
  4117fd:	je     411834 <__swc_fn_4fa09e82_000134_807fd51d+0xa4>
  4117ff:	mov    eax,DWORD PTR [rbx]
  411801:	lea    rcx,[rsp+0x14]
  411806:	mov    DWORD PTR [rsp+0x14],eax
  41180a:	test   eax,eax
  41180c:	je     4117f0 <__swc_fn_4fa09e82_000134_807fd51d+0x60>
  41180e:	mov    QWORD PTR [rsp],0x0
  411816:	mov    edi,0xca
  41181b:	mov    rsi,rbx
  41181e:	mov    edx,0x80
  411823:	mov    ecx,DWORD PTR [rcx]
  411825:	xor    r8d,r8d
  411828:	xor    r9d,r9d
  41182b:	xor    eax,eax
  41182d:	call   4071a0 <syscall@plt>
  411832:	jmp    4117f0 <__swc_fn_4fa09e82_000134_807fd51d+0x60>
  411834:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  41183a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  411840:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  411846:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41184c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  411852:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  411858:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41185e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  411867:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  411870:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  411879:	add    rsp,0xc0
  411880:	pop    rsi
  411881:	pop    rdi
  411882:	pop    rbx
  411883:	ret
	...

0000000000411890 <__swc_fn_4fa09e82_000137_d579ef75>:
  411890:	sub    rsp,0x8
  411894:	call   409d20 <__swc_fn_4fa09e82_000135_10472836>
  411899:	add    rsp,0x8
  41189d:	ret
	...

00000000004118a0 <__swc_fn_4fa09e82_000140_e4a7a8b1>:
  4118a0:	push   rdi
  4118a1:	push   rsi
  4118a2:	sub    rsp,0xa8
  4118a9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4118af:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4118b5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4118bb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4118c1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4118c7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4118cd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4118d3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4118d9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4118e2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4118eb:	mov    edi,0x28
  4118f0:	xor    eax,eax
  4118f2:	call   4071c0 <malloc@plt>
  4118f7:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4118fd:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411903:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411909:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41190f:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411915:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  41191b:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411921:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411927:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411930:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411939:	add    rsp,0xa8
  411940:	pop    rsi
  411941:	pop    rdi
  411942:	ret
	...

0000000000411950 <__swc_fn_4fa09e82_000143_89a6ef72>:
  411950:	mov    QWORD PTR [r8],0x0
  411957:	cmp    rdx,0x10
  41195b:	jae    411960 <__swc_fn_4fa09e82_000143_89a6ef72+0x10>
  41195d:	xor    eax,eax
  41195f:	ret
  411960:	mov    eax,DWORD PTR [rcx]
  411962:	cmp    eax,0x42445753
  411968:	jne    411972 <__swc_fn_4fa09e82_000143_89a6ef72+0x22>
  41196a:	mov    eax,DWORD PTR [rcx+0x4]
  41196d:	cmp    eax,0x1
  411970:	je     411975 <__swc_fn_4fa09e82_000143_89a6ef72+0x25>
  411972:	xor    eax,eax
  411974:	ret
  411975:	mov    QWORD PTR [r8],rdx
  411978:	mov    rax,rcx
  41197b:	ret
  41197c:	add    BYTE PTR [rax],al
	...

0000000000411980 <__swc_fn_4fa09e82_000146_32a1d6a2>:
  411980:	push   rbx
  411981:	sub    rsp,0xe0
  411988:	lea    rbx,[rsp+0x8]
  41198d:	vxorps xmm0,xmm0,xmm0
  411991:	vmovups YMMWORD PTR [rbx],ymm0
  411995:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  41199a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  41199f:	vzeroupper
  4119a2:	mov    DWORD PTR [rbx+0x60],0x0
  4119a9:	mov    r8,rbx
  4119ac:	mov    rdx,rcx
  4119af:	nop
  4119b0:	mov    r9,rdx
  4119b3:	movabs rdx,0x6666666666666667
  4119bd:	mov    rax,r9
  4119c0:	imul   rdx
  4119c3:	sar    rdx,0x2
  4119c7:	mov    r10,rdx
  4119ca:	shr    rdx,0x3f
  4119ce:	add    r10,rdx
  4119d1:	mov    rdx,r10
  4119d4:	imul   r11,r10,0xa
  4119d8:	sub    r9,r11
  4119db:	mov    r11,QWORD PTR [rip+0x1b5e]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  4119e2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  4119e7:	mov    BYTE PTR [r8],r9b
  4119ea:	lea    r9,[r8+0x1]
  4119ee:	mov    r8,r9
  4119f1:	test   r10,r10
  4119f4:	jne    4119b0 <__swc_fn_4fa09e82_000146_32a1d6a2+0x30>
  4119f6:	test   rcx,rcx
  4119f9:	jge    411a03 <__swc_fn_4fa09e82_000146_32a1d6a2+0x83>
  4119fb:	mov    BYTE PTR [r9],0x2d
  4119ff:	add    r8,0x1
  411a03:	mov    BYTE PTR [r8],0x0
  411a07:	sub    r8,0x1
  411a0b:	mov    rax,rbx
  411a0e:	cmp    rax,r8
  411a11:	jae    411a36 <__swc_fn_4fa09e82_000146_32a1d6a2+0xb6>
  411a13:	cs nop WORD PTR [rax+rax*1+0x0]
  411a1d:	nop    DWORD PTR [rax]
  411a20:	mov    cl,BYTE PTR [r8]
  411a23:	mov    dl,BYTE PTR [rax]
  411a25:	mov    BYTE PTR [r8],dl
  411a28:	sub    r8,0x1
  411a2c:	mov    BYTE PTR [rax],cl
  411a2e:	inc    rax
  411a31:	cmp    rax,r8
  411a34:	jb     411a20 <__swc_fn_4fa09e82_000146_32a1d6a2+0xa0>
  411a36:	xor    eax,eax
  411a38:	test   rbx,rbx
  411a3b:	je     411a5e <__swc_fn_4fa09e82_000146_32a1d6a2+0xde>
  411a3d:	mov    rcx,rbx
  411a40:	mov    dl,BYTE PTR [rcx]
  411a42:	test   dl,dl
  411a44:	je     411a5e <__swc_fn_4fa09e82_000146_32a1d6a2+0xde>
  411a46:	cs nop WORD PTR [rax+rax*1+0x0]
  411a50:	add    rcx,0x1
  411a54:	add    rax,0x1
  411a58:	mov    dl,BYTE PTR [rcx]
  411a5a:	test   dl,dl
  411a5c:	jne    411a50 <__swc_fn_4fa09e82_000146_32a1d6a2+0xd0>
  411a5e:	mov    QWORD PTR [rbx+0xa8],rbx
  411a65:	mov    QWORD PTR [rbx+0xb0],rax
  411a6c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  411a74:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  411a7c:	lea    rcx,[rbx+0xb8]
  411a83:	call   409870 <__swc_fn_4fa09e82_000117_3f5cfdef>
  411a88:	add    rsp,0xe0
  411a8f:	pop    rbx
  411a90:	ret
	...

0000000000411aa0 <__swc_fn_4fa09e82_000149_365b4daf>:
  411aa0:	vxorps xmm0,xmm0,xmm0
  411aa4:	vmovups XMMWORD PTR [rcx],xmm0
  411aa8:	mov    QWORD PTR [rcx+0x10],0x0
  411ab0:	ret
	...

0000000000411ac0 <__swc_fn_4fa09e82_000152_365b4daf>:
  411ac0:	vxorps xmm0,xmm0,xmm0
  411ac4:	vmovups XMMWORD PTR [rcx],xmm0
  411ac8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411acd:	vxorps xmm0,xmm0,xmm0
  411ad1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411ad6:	vmovups xmm0,XMMWORD PTR [rip+0x1b5a]        # 413638 <__swc_rdata_base_4fa09e82+0x528>
  411ade:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411ae3:	vxorps xmm0,xmm0,xmm0
  411ae7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411aec:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411af1:	mov    QWORD PTR [rcx+0x60],0x0
  411af9:	ret
  411afa:	add    BYTE PTR [rax],al
  411afc:	add    BYTE PTR [rax],al
	...

0000000000411b00 <__swc_fn_4fa09e82_000155_365b4daf>:
  411b00:	vxorps xmm0,xmm0,xmm0
  411b04:	vmovups XMMWORD PTR [rcx],xmm0
  411b08:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411b0d:	vxorps xmm0,xmm0,xmm0
  411b11:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411b16:	vmovups xmm0,XMMWORD PTR [rip+0x1c42]        # 413760 <__swc_rdata_base_4fa09e82+0x650>
  411b1e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411b23:	vxorps xmm0,xmm0,xmm0
  411b27:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411b2c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411b31:	vxorps xmm0,xmm0,xmm0
  411b35:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  411b3a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  411b3f:	vxorps xmm0,xmm0,xmm0
  411b43:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  411b4b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  411b53:	vxorps xmm0,xmm0,xmm0
  411b57:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  411b5f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  411b67:	vxorps xmm0,xmm0,xmm0
  411b6b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  411b73:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  411b7b:	mov    QWORD PTR [rcx+0xe0],0x0
  411b86:	ret
	...

0000000000411b90 <__swc_fn_4fa09e82_000158_3495a3ca>:
  411b90:	push   rbx
  411b91:	mov    rbx,rcx
  411b94:	call   40b2b0 <__swc_fn_4fa09e82_000159_31e09513>
  411b99:	mov    rax,QWORD PTR [rbx+0x10]
  411b9d:	test   rax,rax
  411ba0:	je     411bb1 <__swc_fn_4fa09e82_000158_3495a3ca+0x21>
  411ba2:	mov    rcx,rbx
  411ba5:	mov    rdx,rax
  411ba8:	mov    r8,QWORD PTR [rbx+0x18]
  411bac:	call   40ed10 <__swc_fn_4fa09e82_000157_9e2052d6>
  411bb1:	vxorps xmm0,xmm0,xmm0
  411bb5:	vmovups XMMWORD PTR [rbx],xmm0
  411bb9:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  411bbe:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  411bc3:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  411bc8:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  411bcd:	mov    QWORD PTR [rbx+0x50],0x0
  411bd5:	pop    rbx
  411bd6:	ret
	...

0000000000411be0 <__swc_fn_4fa09e82_000161_dfca9093>:
  411be0:	sub    rsp,0x10
  411be4:	mov    eax,r8d
  411be7:	mov    r8d,r9d
  411bea:	test   r9d,r9d
  411bed:	jne    411c06 <__swc_fn_4fa09e82_000161_dfca9093+0x26>
  411bef:	vmovups xmm0,XMMWORD PTR [rip+0x1c21]        # 413818 <__swc_rdata_base_4fa09e82+0x708>
  411bf7:	vmovups XMMWORD PTR [r10],xmm0
  411bfc:	mov    eax,0x1
  411c01:	add    rsp,0x10
  411c05:	ret
  411c06:	mov    r9,r8
  411c09:	cmp    r8,rax
  411c0c:	jb     411c13 <__swc_fn_4fa09e82_000161_dfca9093+0x33>
  411c0e:	cmp    r9,rdx
  411c11:	jb     411c1a <__swc_fn_4fa09e82_000161_dfca9093+0x3a>
  411c13:	xor    eax,eax
  411c15:	add    rsp,0x10
  411c19:	ret
  411c1a:	xor    eax,eax
  411c1c:	lea    r8,[r9+rax*1]
  411c20:	cmp    r8,rdx
  411c23:	jae    411c53 <__swc_fn_4fa09e82_000161_dfca9093+0x73>
  411c25:	cs nop WORD PTR [rax+rax*1+0x0]
  411c2f:	cs nop WORD PTR [rax+rax*1+0x0]
  411c39:	nop    DWORD PTR [rax+0x0]
  411c40:	cmp    BYTE PTR [rcx+r8*1],0x0
  411c45:	je     411c53 <__swc_fn_4fa09e82_000161_dfca9093+0x73>
  411c47:	inc    rax
  411c4a:	lea    r8,[r9+rax*1]
  411c4e:	cmp    r8,rdx
  411c51:	jb     411c40 <__swc_fn_4fa09e82_000161_dfca9093+0x60>
  411c53:	cmp    r8,rdx
  411c56:	jne    411c5f <__swc_fn_4fa09e82_000161_dfca9093+0x7f>
  411c58:	xor    eax,eax
  411c5a:	add    rsp,0x10
  411c5e:	ret
  411c5f:	add    rcx,r9
  411c62:	mov    QWORD PTR [rsp],rcx
  411c66:	mov    QWORD PTR [rsp+0x8],rax
  411c6b:	vmovups xmm0,XMMWORD PTR [rsp]
  411c70:	vmovups XMMWORD PTR [r10],xmm0
  411c75:	mov    eax,0x1
  411c7a:	add    rsp,0x10
  411c7e:	ret
	...

0000000000411c80 <__swc_fn_4fa09e82_000164_3a7aae74>:
  411c80:	push   rbp
  411c81:	push   rbx
  411c82:	push   rsi
  411c83:	push   rdi
  411c84:	push   r12
  411c86:	push   r13
  411c88:	push   r14
  411c8a:	push   r15
  411c8c:	sub    rsp,0x10
  411c90:	mov    rbp,rsp
  411c93:	vmovups XMMWORD PTR [rsp],xmm6
  411c98:	sub    rsp,0x50
  411c9c:	mov    rbx,rsp
  411c9f:	mov    rsi,r8
  411ca2:	mov    QWORD PTR [rsp+0x30],r8
  411ca7:	mov    rdi,rcx
  411caa:	mov    QWORD PTR [rsp+0x38],rcx
  411caf:	mov    r12,rdx
  411cb2:	xor    r13b,r13b
  411cb5:	mov    r14,QWORD PTR [rdi+0x8]
  411cb9:	mov    QWORD PTR [rsp+0x40],r14
  411cbe:	xor    r15d,r15d
  411cc1:	test   r14,r14
  411cc4:	jbe    411f1e <__swc_fn_4fa09e82_000164_3a7aae74+0x29e>
  411cca:	mov    r14,QWORD PTR [rdi]
  411ccd:	mov    rax,QWORD PTR [rsp+0x40]
  411cd2:	mov    QWORD PTR [rsp+0x48],r14
  411cd7:	vmovups xmm6,XMMWORD PTR [rip+0x1759]        # 413438 <__swc_rdata_base_4fa09e82+0x328>
  411cdf:	nop
  411ce0:	cmp    QWORD PTR [r14+r15*8],0x0
  411ce5:	jne    411cef <__swc_fn_4fa09e82_000164_3a7aae74+0x6f>
  411ce7:	mov    r14,rax
  411cea:	jmp    411efe <__swc_fn_4fa09e82_000164_3a7aae74+0x27e>
  411cef:	mov    rcx,QWORD PTR [rdi]
  411cf2:	mov    rdx,QWORD PTR [rcx+r15*8]
  411cf6:	mov    rdi,rbx
  411cf9:	mov    rcx,rdi
  411cfc:	sub    rsp,0x8
  411d00:	mov    r14,rax
  411d03:	call   40ed90 <__swc_fn_4fa09e82_000163_61e293bf>
  411d08:	add    rsp,0x8
  411d0c:	mov    al,BYTE PTR [rbx]
  411d0e:	test   al,al
  411d10:	je     411efe <__swc_fn_4fa09e82_000164_3a7aae74+0x27e>
  411d16:	mov    al,BYTE PTR [rbx+0x1]
  411d19:	test   al,al
  411d1b:	jne    411d26 <__swc_fn_4fa09e82_000164_3a7aae74+0xa6>
  411d1d:	test   sil,sil
  411d20:	je     411efe <__swc_fn_4fa09e82_000164_3a7aae74+0x27e>
  411d26:	test   r13b,r13b
  411d29:	jne    411de7 <__swc_fn_4fa09e82_000164_3a7aae74+0x167>
  411d2f:	test   r12,r12
  411d32:	je     411de7 <__swc_fn_4fa09e82_000164_3a7aae74+0x167>
  411d38:	mov    al,BYTE PTR [rbx+0x1]
  411d3b:	test   al,al
  411d3d:	je     411efe <__swc_fn_4fa09e82_000164_3a7aae74+0x27e>
  411d43:	mov    eax,DWORD PTR [rbx+0x28]
  411d46:	cmp    DWORD PTR [r12+0x20],eax
  411d4b:	jne    411efe <__swc_fn_4fa09e82_000164_3a7aae74+0x27e>
  411d51:	mov    rax,QWORD PTR [r12]
  411d55:	mov    rcx,QWORD PTR [r12+0x8]
  411d5a:	cmp    QWORD PTR [rbx+0x20],rcx
  411d5e:	jne    411efe <__swc_fn_4fa09e82_000164_3a7aae74+0x27e>
  411d64:	mov    cl,0x1
  411d66:	test   rax,rax
  411d69:	je     411dd2 <__swc_fn_4fa09e82_000164_3a7aae74+0x152>
  411d6f:	mov    rdx,QWORD PTR [rbx+0x20]
  411d73:	xor    r8d,r8d
  411d76:	test   rdx,rdx
  411d79:	jbe    411dd2 <__swc_fn_4fa09e82_000164_3a7aae74+0x152>
  411d7b:	mov    r9,QWORD PTR [rbx+0x18]
  411d7f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  411d84:	cs nop WORD PTR [rax+rax*1+0x0]
  411d8e:	xchg   ax,ax
  411d90:	mov    r10b,BYTE PTR [rax+r8*1]
  411d94:	cmp    BYTE PTR [r9+r8*1],r10b
  411d98:	je     411dc9 <__swc_fn_4fa09e82_000164_3a7aae74+0x149>
  411d9a:	vmovq  r10,xmm0
  411d9f:	cmp    BYTE PTR [r10+r8*1],0x5c
  411da4:	jne    411dad <__swc_fn_4fa09e82_000164_3a7aae74+0x12d>
  411da6:	cmp    BYTE PTR [rax+r8*1],0x2f
  411dab:	je     411dc9 <__swc_fn_4fa09e82_000164_3a7aae74+0x149>
  411dad:	vmovq  r10,xmm0
  411db2:	cmp    BYTE PTR [r10+r8*1],0x2f
  411db7:	jne    411dc0 <__swc_fn_4fa09e82_000164_3a7aae74+0x140>
  411db9:	cmp    BYTE PTR [rax+r8*1],0x5c
  411dbe:	je     411dc9 <__swc_fn_4fa09e82_000164_3a7aae74+0x149>
  411dc0:	xor    eax,eax
  411dc2:	movzx  eax,al
  411dc5:	mov    cl,al
  411dc7:	jmp    411dd2 <__swc_fn_4fa09e82_000164_3a7aae74+0x152>
  411dc9:	add    r8,0x1
  411dcd:	cmp    r8,rdx
  411dd0:	jb     411d90 <__swc_fn_4fa09e82_000164_3a7aae74+0x110>
  411dd2:	test   cl,cl
  411dd4:	je     411efe <__swc_fn_4fa09e82_000164_3a7aae74+0x27e>
  411dda:	mov    eax,0x1
  411ddf:	mov    r13b,al
  411de2:	jmp    411efe <__swc_fn_4fa09e82_000164_3a7aae74+0x27e>
  411de7:	mov    r13b,0x1
  411dea:	sub    rsp,0x20
  411dee:	mov    rax,rsp
  411df1:	lea    rcx,[rdi+0x8]
  411df5:	mov    QWORD PTR [rax],rcx
  411df8:	lea    rsi,[rip+0x1511]        # 413310 <__swc_rdata_base_4fa09e82+0x200>
  411dff:	mov    QWORD PTR [rax+0x8],rsi
  411e03:	mov    QWORD PTR [rax+0x10],rsp
  411e07:	mov    QWORD PTR [rax+0x18],0x1
  411e0f:	lea    rcx,[rsp+0x10]
  411e14:	sub    rsp,0x8
  411e18:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  411e1d:	add    rsp,0x8
  411e21:	add    rsp,0x20
  411e25:	mov    al,BYTE PTR [rbx+0x1]
  411e28:	test   al,al
  411e2a:	je     411ec7 <__swc_fn_4fa09e82_000164_3a7aae74+0x247>
  411e30:	lea    rax,[rip+0x1a81]        # 4138b8 <__swc_rdata_base_4fa09e82+0x7a8>
  411e37:	sub    rsp,0x20
  411e3b:	mov    rcx,rsp
  411e3e:	mov    QWORD PTR [rcx],rax
  411e41:	mov    QWORD PTR [rcx+0x8],rsi
  411e45:	mov    QWORD PTR [rcx+0x10],rsp
  411e49:	mov    QWORD PTR [rcx+0x18],0x1
  411e51:	lea    rcx,[rsp+0x10]
  411e56:	sub    rsp,0x8
  411e5a:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  411e5f:	add    rsp,0x8
  411e63:	add    rsp,0x20
  411e67:	mov    eax,DWORD PTR [rbx+0x28]
  411e6a:	sub    rsp,0x60
  411e6e:	mov    rcx,rsp
  411e71:	lea    rdx,[rdi+0x18]
  411e75:	mov    QWORD PTR [rcx+0x18],rdx
  411e79:	mov    QWORD PTR [rcx+0x20],rsi
  411e7d:	vmovups XMMWORD PTR [rcx],xmm6
  411e81:	mov    QWORD PTR [rcx+0x28],rsp
  411e85:	mov    QWORD PTR [rcx+0x30],rsi
  411e89:	mov    DWORD PTR [rcx+0x10],eax
  411e8c:	lea    rax,[rsp+0x10]
  411e91:	mov    QWORD PTR [rcx+0x38],rax
  411e95:	lea    rax,[rip+0x1534]        # 4133d0 <__swc_rdata_base_4fa09e82+0x2c0>
  411e9c:	mov    QWORD PTR [rcx+0x40],rax
  411ea0:	lea    rax,[rsp+0x18]
  411ea5:	mov    QWORD PTR [rcx+0x48],rax
  411ea9:	mov    QWORD PTR [rcx+0x50],0x3
  411eb1:	lea    rcx,[rsp+0x48]
  411eb6:	sub    rsp,0x8
  411eba:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  411ebf:	add    rsp,0x8
  411ec3:	add    rsp,0x60
  411ec7:	lea    rax,[rip+0x149a]        # 413368 <__swc_rdata_base_4fa09e82+0x258>
  411ece:	sub    rsp,0x20
  411ed2:	mov    rcx,rsp
  411ed5:	mov    QWORD PTR [rcx],rax
  411ed8:	mov    QWORD PTR [rcx+0x8],rsi
  411edc:	mov    QWORD PTR [rcx+0x10],rsp
  411ee0:	mov    QWORD PTR [rcx+0x18],0x1
  411ee8:	lea    rcx,[rsp+0x10]
  411eed:	sub    rsp,0x8
  411ef1:	call   40a0e0 <__swc_fn_4fa09e82_000147_d2097256>
  411ef6:	add    rsp,0x8
  411efa:	add    rsp,0x20
  411efe:	add    r15,0x1
  411f02:	cmp    r15,r14
  411f05:	jae    411f1e <__swc_fn_4fa09e82_000164_3a7aae74+0x29e>
  411f07:	mov    rsi,QWORD PTR [rsp+0x30]
  411f0c:	mov    rdi,QWORD PTR [rsp+0x38]
  411f11:	mov    rax,r14
  411f14:	mov    r14,QWORD PTR [rsp+0x48]
  411f19:	jmp    411ce0 <__swc_fn_4fa09e82_000164_3a7aae74+0x60>
  411f1e:	add    rsp,0x50
  411f22:	vmovups xmm6,XMMWORD PTR [rsp]
  411f27:	add    rsp,0x10
  411f2b:	pop    r15
  411f2d:	pop    r14
  411f2f:	pop    r13
  411f31:	pop    r12
  411f33:	pop    rdi
  411f34:	pop    rsi
  411f35:	pop    rbx
  411f36:	pop    rbp
  411f37:	ret
	...

0000000000411f40 <__swc_fn_4fa09e82_000167_c370e18e>:
  411f40:	sub    rsp,0x8
  411f44:	call   409af0 <__swc_fn_4fa09e82_000126_7a81492f>
  411f49:	add    rsp,0x8
  411f4d:	ret
	...

0000000000411f50 <__swc_fn_4fa09e82_000170_4694b8ad>:
  411f50:	push   rsi
  411f51:	sub    rsp,0x30
  411f55:	lea    rsi,[rip+0x14e44]        # 426da0 <__swc_bss_base_4fa09e82+0x2d60>
  411f5c:	mov    rax,QWORD PTR [rsi]
  411f5f:	test   rax,rax
  411f62:	je     411f6a <__swc_fn_4fa09e82_000170_4694b8ad+0x1a>
  411f64:	add    rsp,0x30
  411f68:	pop    rsi
  411f69:	ret
  411f6a:	mov    ecx,0x2
  411f6f:	mov    edx,0x8020
  411f74:	call   409190 <__swc_fn_4fa09e82_000108_c8d4a68e>
  411f79:	test   rax,rax
  411f7c:	jne    411f8d <__swc_fn_4fa09e82_000170_4694b8ad+0x3d>
  411f7e:	mov    QWORD PTR [rsp+0x18],rax
  411f83:	call   4113e0 <__swc_fn_4fa09e82_000119_591530fe>
  411f88:	mov    rax,QWORD PTR [rsp+0x18]
  411f8d:	mov    rcx,rax
  411f90:	xchg   QWORD PTR [rsi],rcx
  411f93:	add    rsp,0x30
  411f97:	pop    rsi
  411f98:	ret
  411f99:	add    BYTE PTR [rax],al
  411f9b:	add    BYTE PTR [rax],al
  411f9d:	add    BYTE PTR [rax],al
	...

0000000000411fa0 <__swc_fn_4fa09e82_000173_1751ecdd>:
  411fa0:	push   rsi
  411fa1:	test   r8,r8
  411fa4:	jne    411fa8 <__swc_fn_4fa09e82_000173_1751ecdd+0x8>
  411fa6:	pop    rsi
  411fa7:	ret
  411fa8:	lea    rax,[rcx+0x18]
  411fac:	mov    r10,QWORD PTR [rax]
  411faf:	lea    r11,[r10+0x1]
  411fb3:	mov    QWORD PTR [rax],r11
  411fb6:	mov    r11,rdx
  411fb9:	not    rdx
  411fbc:	lea    rsi,[r8-0x1]
  411fc0:	cmp    rsi,rdx
  411fc3:	ja     411fe3 <__swc_fn_4fa09e82_000173_1751ecdd+0x43>
  411fc5:	lea    rdx,[r11+r8*1]
  411fc9:	dec    rdx
  411fcc:	shr    rdx,0x6
  411fd0:	mov    r8,r11
  411fd3:	shr    r8,0x6
  411fd7:	mov    rsi,rdx
  411fda:	sub    rsi,r8
  411fdd:	cmp    rsi,0x8
  411fe1:	jb     411ff9 <__swc_fn_4fa09e82_000173_1751ecdd+0x59>
  411fe3:	lea    rcx,[rcx+0x10]
  411fe7:	mov    rdx,QWORD PTR [rcx]
  411fea:	add    rdx,r9
  411fed:	mov    QWORD PTR [rcx],rdx
  411ff0:	lea    rcx,[r10+0x2]
  411ff4:	mov    QWORD PTR [rax],rcx
  411ff7:	pop    rsi
  411ff8:	ret
  411ff9:	shr    r11,0x6
  411ffd:	nop    DWORD PTR [rax]
  412000:	cmp    r11,rdx
  412003:	ja     412043 <__swc_fn_4fa09e82_000173_1751ecdd+0xa3>
  412005:	jmp    412016 <__swc_fn_4fa09e82_000173_1751ecdd+0x76>
  412007:	nop    WORD PTR [rax+rax*1+0x0]
  412010:	add    r11,0x1
  412014:	jmp    412000 <__swc_fn_4fa09e82_000173_1751ecdd+0x60>
  412016:	mov    r8,r11
  412019:	shr    r8,0xc
  41201d:	mov    rsi,r11
  412020:	xor    rsi,r8
  412023:	mov    r8,r11
  412026:	shr    r8,0x18
  41202a:	xor    rsi,r8
  41202d:	and    esi,0xfff
  412033:	lea    r8,[rcx+rsi*8+0x20]
  412038:	mov    rsi,QWORD PTR [r8]
  41203b:	add    rsi,r9
  41203e:	mov    QWORD PTR [r8],rsi
  412041:	jmp    412010 <__swc_fn_4fa09e82_000173_1751ecdd+0x70>
  412043:	lea    rcx,[r10+0x2]
  412047:	mov    QWORD PTR [rax],rcx
  41204a:	pop    rsi
  41204b:	ret
  41204c:	add    BYTE PTR [rax],al
	...

0000000000412050 <__swc_fn_4fa09e82_000176_e7f0b636>:
  412050:	push   rsi
  412051:	push   rdi
  412052:	push   r12
  412054:	mov    rsi,r8
  412057:	mov    rdi,rcx
  41205a:	mov    r12,rdx
  41205d:	lea    rcx,[rdx*8+0x0]
  412065:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  41206a:	mov    QWORD PTR [rdi],rax
  41206d:	lea    rcx,[r12*8+0x0]
  412075:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  41207a:	mov    QWORD PTR [rdi+0x8],rax
  41207e:	lea    rcx,[r12*8+0x0]
  412086:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  41208b:	mov    QWORD PTR [rdi+0x10],rax
  41208f:	mov    rcx,r12
  412092:	call   40b7c0 <__swc_fn_4fa09e82_000177_2744b483>
  412097:	mov    QWORD PTR [rdi+0x18],rax
  41209b:	mov    rcx,rax
  41209e:	xor    al,al
  4120a0:	mov    rdx,rax
  4120a3:	mov    r8,r12
  4120a6:	call   4090e0 <__swc_fn_4fa09e82_000105_7e71bba2>
  4120ab:	mov    QWORD PTR [rdi+0x20],rsi
  4120af:	lea    rax,[r12-0x1]
  4120b4:	mov    QWORD PTR [rdi+0x28],rax
  4120b8:	mov    QWORD PTR [rdi+0x30],0x0
  4120c0:	pop    r12
  4120c2:	pop    rdi
  4120c3:	pop    rsi
  4120c4:	ret
	...

00000000004120d0 <__swc_fn_4fa09e82_000179_6937fe70>:
  4120d0:	push   rsi
  4120d1:	push   rdi
  4120d2:	push   r12
  4120d4:	push   r13
  4120d6:	push   r14
  4120d8:	push   r15
  4120da:	sub    rsp,0xd8
  4120e1:	mov    rsi,rdx
  4120e4:	mov    QWORD PTR [rsp+0x88],rdx
  4120ec:	mov    rdi,rcx
  4120ef:	cmp    rdi,rsi
  4120f2:	jge    412309 <__swc_fn_4fa09e82_000179_6937fe70+0x239>
  4120f8:	nop    DWORD PTR [rax+rax*1+0x0]
  412100:	lea    rax,[rdi+rsi*1]
  412104:	mov    rcx,rax
  412107:	shr    rax,0x3f
  41210b:	add    rcx,rax
  41210e:	sar    rcx,1
  412111:	mov    rax,QWORD PTR [rip+0x14c98]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  412118:	mov    r12,QWORD PTR [rax+rcx*8]
  41211c:	mov    r13,rdi
  41211f:	mov    QWORD PTR [rsp+0x90],rdi
  412127:	mov    r14,rsi
  41212a:	nop    WORD PTR [rax+rax*1+0x0]
  412130:	cmp    r13,r14
  412133:	jle    412140 <__swc_fn_4fa09e82_000179_6937fe70+0x70>
  412135:	mov    rax,r13
  412138:	mov    r13,r14
  41213b:	jmp    4122e5 <__swc_fn_4fa09e82_000179_6937fe70+0x215>
  412140:	mov    r15,QWORD PTR [rip+0x14c69]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  412147:	mov    rsi,QWORD PTR [rip+0x14c6a]        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  41214e:	mov    QWORD PTR [rsp+0xa8],rsi
  412156:	mov    rdi,QWORD PTR [rsi+r12*8]
  41215a:	mov    QWORD PTR [rsp+0xa0],r14
  412162:	mov    r14,QWORD PTR [rip+0x14c57]        # 426dc0 <__swc_bss_base_4fa09e82+0x2d80>
  412169:	mov    rax,QWORD PTR [rip+0x14c58]        # 426dc8 <__swc_bss_base_4fa09e82+0x2d88>
  412170:	mov    QWORD PTR [rsp+0xb0],rax
  412178:	mov    r9,QWORD PTR [rip+0x14c51]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  41217f:	mov    QWORD PTR [rsp+0xb8],r9
  412187:	nop    WORD PTR [rax+rax*1+0x0]
  412190:	mov    r10,QWORD PTR [r15+r13*8]
  412194:	cmp    QWORD PTR [rsi+r10*8],rdi
  412198:	je     41219e <__swc_fn_4fa09e82_000179_6937fe70+0xce>
  41219a:	ja     4121d5 <__swc_fn_4fa09e82_000179_6937fe70+0x105>
  41219c:	jmp    4121f2 <__swc_fn_4fa09e82_000179_6937fe70+0x122>
  41219e:	mov    rcx,QWORD PTR [r14+r10*8]
  4121a2:	mov    r8,QWORD PTR [r14+r12*8]
  4121a6:	cmp    r8,rcx
  4121a9:	cmovae r8,rcx
  4121ad:	mov    rcx,QWORD PTR [rax+r10*8]
  4121b1:	add    rcx,r9
  4121b4:	mov    rdx,QWORD PTR [rax+r12*8]
  4121b8:	add    rdx,r9
  4121bb:	mov    rsi,r10
  4121be:	call   410e70 <__swc_fn_4fa09e82_000107_aba05410>
  4121c3:	test   eax,eax
  4121c5:	je     4121cb <__swc_fn_4fa09e82_000179_6937fe70+0xfb>
  4121c7:	jl     4121d5 <__swc_fn_4fa09e82_000179_6937fe70+0x105>
  4121c9:	jmp    4121f2 <__swc_fn_4fa09e82_000179_6937fe70+0x122>
  4121cb:	mov    rax,QWORD PTR [r14+r12*8]
  4121cf:	cmp    QWORD PTR [r14+rsi*8],rax
  4121d3:	jae    4121f2 <__swc_fn_4fa09e82_000179_6937fe70+0x122>
  4121d5:	inc    r13
  4121d8:	mov    rsi,QWORD PTR [rsp+0xa8]
  4121e0:	mov    rax,QWORD PTR [rsp+0xb0]
  4121e8:	mov    r9,QWORD PTR [rsp+0xb8]
  4121f0:	jmp    412190 <__swc_fn_4fa09e82_000179_6937fe70+0xc0>
  4121f2:	mov    rsi,QWORD PTR [rip+0x14bb7]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  4121f9:	mov    QWORD PTR [rsp+0xc0],rsi
  412201:	mov    rdi,QWORD PTR [rip+0x14bb0]        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  412208:	mov    r14,QWORD PTR [rip+0x14bb1]        # 426dc0 <__swc_bss_base_4fa09e82+0x2d80>
  41220f:	mov    r15,QWORD PTR [rip+0x14bb2]        # 426dc8 <__swc_bss_base_4fa09e82+0x2d88>
  412216:	mov    QWORD PTR [rsp+0x98],r13
  41221e:	mov    r13,QWORD PTR [rsp+0xa0]
  412226:	mov    rax,QWORD PTR [rip+0x14ba3]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  41222d:	mov    QWORD PTR [rsp+0xc8],rax
  412235:	cs nop WORD PTR [rax+rax*1+0x0]
  41223f:	nop
  412240:	mov    r9,QWORD PTR [rsi+r13*8]
  412244:	mov    rcx,QWORD PTR [rdi+r9*8]
  412248:	cmp    QWORD PTR [rdi+r12*8],rcx
  41224c:	je     412252 <__swc_fn_4fa09e82_000179_6937fe70+0x182>
  41224e:	ja     412289 <__swc_fn_4fa09e82_000179_6937fe70+0x1b9>
  412250:	jmp    41229e <__swc_fn_4fa09e82_000179_6937fe70+0x1ce>
  412252:	mov    rcx,QWORD PTR [r14+r12*8]
  412256:	mov    r8,QWORD PTR [r14+r9*8]
  41225a:	cmp    r8,rcx
  41225d:	cmovae r8,rcx
  412261:	mov    rcx,QWORD PTR [r15+r12*8]
  412265:	add    rcx,rax
  412268:	mov    rdx,QWORD PTR [r15+r9*8]
  41226c:	add    rdx,rax
  41226f:	mov    rsi,r9
  412272:	call   410e70 <__swc_fn_4fa09e82_000107_aba05410>
  412277:	test   eax,eax
  412279:	je     41227f <__swc_fn_4fa09e82_000179_6937fe70+0x1af>
  41227b:	jl     412289 <__swc_fn_4fa09e82_000179_6937fe70+0x1b9>
  41227d:	jmp    41229e <__swc_fn_4fa09e82_000179_6937fe70+0x1ce>
  41227f:	mov    rax,QWORD PTR [r14+rsi*8]
  412283:	cmp    QWORD PTR [r14+r12*8],rax
  412287:	jae    41229e <__swc_fn_4fa09e82_000179_6937fe70+0x1ce>
  412289:	dec    r13
  41228c:	mov    rsi,QWORD PTR [rsp+0xc0]
  412294:	mov    rax,QWORD PTR [rsp+0xc8]
  41229c:	jmp    412240 <__swc_fn_4fa09e82_000179_6937fe70+0x170>
  41229e:	mov    rax,QWORD PTR [rsp+0x98]
  4122a6:	cmp    rax,r13
  4122a9:	jle    4122b6 <__swc_fn_4fa09e82_000179_6937fe70+0x1e6>
  4122ab:	mov    r14,r13
  4122ae:	mov    r13,rax
  4122b1:	jmp    412130 <__swc_fn_4fa09e82_000179_6937fe70+0x60>
  4122b6:	mov    rcx,QWORD PTR [rip+0x14af3]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  4122bd:	mov    rdx,QWORD PTR [rcx+rax*8]
  4122c1:	mov    r8,QWORD PTR [rcx+r13*8]
  4122c5:	mov    QWORD PTR [rcx+rax*8],r8
  4122c9:	mov    rcx,QWORD PTR [rip+0x14ae0]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  4122d0:	mov    QWORD PTR [rcx+r13*8],rdx
  4122d4:	inc    rax
  4122d7:	dec    r13
  4122da:	mov    r14,r13
  4122dd:	mov    r13,rax
  4122e0:	jmp    412130 <__swc_fn_4fa09e82_000179_6937fe70+0x60>
  4122e5:	mov    rcx,QWORD PTR [rsp+0x90]
  4122ed:	mov    rdx,r13
  4122f0:	mov    rdi,rax
  4122f3:	call   4120d0 <__swc_fn_4fa09e82_000179_6937fe70>
  4122f8:	mov    rsi,QWORD PTR [rsp+0x88]
  412300:	cmp    rdi,rsi
  412303:	jl     412100 <__swc_fn_4fa09e82_000179_6937fe70+0x30>
  412309:	add    rsp,0xd8
  412310:	pop    r15
  412312:	pop    r14
  412314:	pop    r13
  412316:	pop    r12
  412318:	pop    rdi
  412319:	pop    rsi
  41231a:	ret
