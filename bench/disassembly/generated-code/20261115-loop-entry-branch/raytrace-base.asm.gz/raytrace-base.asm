
/workspace/prompt2-20261115/batch7-placement-micro/base/raytrace/raytrace:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <getpid@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <getpid@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <munmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <munmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <exit@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <exit@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <pthread_key_create@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <pthread_key_create@GLIBC_2.34>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_setspecific@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <pthread_setspecific@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <syscall@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <syscall@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dladdr@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <dladdr@GLIBC_2.34>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <open@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <open@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <lseek@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <lseek@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <close@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <close@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <mmap@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <mmap@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <malloc@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <malloc@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <madvise@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf9a]        # 413080 <madvise@GLIBC_2.2.5>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <pthread_key_delete@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf92]        # 413088 <pthread_key_delete@GLIBC_2.34>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <gettid@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf8a]        # 413090 <gettid@GLIBC_2.30>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <clock_gettime@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf82]        # 413098 <clock_gettime@GLIBC_2.17>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <flock@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf7a]        # 4130a0 <flock@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <__errno_location@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf72]        # 4130a8 <__errno_location@GLIBC_2.2.5>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <opendir@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf6a]        # 4130b0 <opendir@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <dirfd@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf62]        # 4130b8 <dirfd@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <readdir@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <readdir@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <readlinkat@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <readlinkat@GLIBC_2.4>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <openat@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <openat@GLIBC_2.4>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <closedir@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <closedir@GLIBC_2.2.5>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <memfd_create@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <memfd_create@GLIBC_2.27>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <ftruncate@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <ftruncate@GLIBC_2.2.5>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <write@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <write@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <backtrace@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <backtrace@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <__x86_get_cpuid_feature_leaf@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <free@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <free@GLIBC_2.2.5>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_0a4ed24b_000176_0d61c738+0x1200>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40ccc0 <__swc_fn_0a4ed24b_000121_1c5e75b6>
  40724e:	xor    ecx,ecx
  407250:	call   40c3e0 <__swc_fn_0a4ed24b_000094_383a814c>
  407255:	call   40d960 <__swc_fn_0a4ed24b_000178_a483827c>
  40725a:	call   40f450 <__swc_fn_0a4ed24b_000095_8cc4b392>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_0a4ed24b_000000_0e26756e>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_0a4ed24b_000003_81215399>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_0a4ed24b_000003_81215399+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   409240 <__swc_fn_0a4ed24b_000111_f9e19033>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_0a4ed24b_000003_81215399+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1cd81]        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1cd7a]        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_0a4ed24b_000003_81215399+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_0a4ed24b_000003_81215399+0x30>
  4072e6:	lea    rcx,[rip+0x1cd63]        # 424050 <__swc_bss_base_0a4ed24b+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1cd5c]        # 424050 <__swc_bss_base_0a4ed24b+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_0a4ed24b_000003_81215399+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_0a4ed24b_000003_81215399+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_0a4ed24b_000006_7b253ae1>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40dd00 <__swc_fn_0a4ed24b_000011_71c91685>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_0a4ed24b_000012_be38a1a2>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_0a4ed24b_000006_7b253ae1+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_0a4ed24b_000003_81215399>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_0a4ed24b_000006_7b253ae1+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_0a4ed24b_000009_4c3ebf16>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_0a4ed24b_000009_4c3ebf16+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40a770 <__swc_fn_0a4ed24b_000007_a7bfb091>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40dcf0 <__swc_fn_0a4ed24b_000008_b2f73e0d>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_0a4ed24b_000009_4c3ebf16+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_0a4ed24b_000009_4c3ebf16+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_0a4ed24b_000012_be38a1a2>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_0a4ed24b_000015_96cb1311>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_0a4ed24b_000015_96cb1311+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_0a4ed24b_000015_96cb1311+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_0a4ed24b_000015_96cb1311+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_0a4ed24b_000015_96cb1311+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40de60 <__swc_fn_0a4ed24b_000017_f003fc47>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_0a4ed24b_000015_96cb1311+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1cb3d]        # 424058 <__swc_bss_base_0a4ed24b+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1cb36]        # 424058 <__swc_bss_base_0a4ed24b+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_0a4ed24b_000015_96cb1311+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_0a4ed24b_000015_96cb1311+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40dd00 <__swc_fn_0a4ed24b_000011_71c91685>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_0a4ed24b_000015_96cb1311+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   40c9e0 <__swc_fn_0a4ed24b_000112_2f7f9346>
  407569:	lea    rcx,[rip+0x1cad8]        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1cad1]        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_0a4ed24b_000015_96cb1311+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_0a4ed24b_000015_96cb1311+0x110>
  407598:	lea    rcx,[rip+0x1cac1]        # 424060 <__swc_bss_base_0a4ed24b+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1caba]        # 424060 <__swc_bss_base_0a4ed24b+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_0a4ed24b_000015_96cb1311+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_0a4ed24b_000015_96cb1311+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_0a4ed24b_000018_77ece227>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_0a4ed24b_000015_96cb1311+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_0a4ed24b_000018_77ece227>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_0a4ed24b_000018_77ece227+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_0a4ed24b_000018_77ece227+0x10>

0000000000407630 <__swc_fn_0a4ed24b_000021_9cf87641>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_0a4ed24b_000015_96cb1311>
  40763e:	lea    rdi,[rip+0x1cbab]        # 4241f0 <__swc_bss_base_0a4ed24b+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   4098a0 <__swc_fn_0a4ed24b_000135_db32cc57>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1cb94]        # 4241f8 <__swc_bss_base_0a4ed24b+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1cb89],rsi        # 4241f8 <__swc_bss_base_0a4ed24b+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_0a4ed24b_000024_e876734d>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_0a4ed24b_000027_e876734d>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_0a4ed24b_000030_650caec0>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_0a4ed24b_000030_650caec0+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1a92c]        # 422000 <__swc_data_base_0a4ed24b>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_0a4ed24b_000030_650caec0+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_0a4ed24b_000030_650caec0+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_0a4ed24b_000030_650caec0+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40e020 <__swc_fn_0a4ed24b_000032_f1940e30>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_0a4ed24b_000030_650caec0+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_0a4ed24b_000036_290a131c>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_0a4ed24b_000030_650caec0+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_0a4ed24b_000042_0573444d>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_0a4ed24b_000033_d15eb4ea>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40ac20 <__swc_fn_0a4ed24b_000031_3c3e930e>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   409720 <__swc_fn_0a4ed24b_000129_bc477461>
  407734:	mov    rcx,rsi
  407737:	call   40e020 <__swc_fn_0a4ed24b_000032_f1940e30>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_0a4ed24b_000036_290a131c>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_0a4ed24b_000039_9ae4348f>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_0a4ed24b_000039_9ae4348f+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_0a4ed24b_000039_9ae4348f+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_0a4ed24b_000039_9ae4348f+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_0a4ed24b_000039_9ae4348f+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_0a4ed24b_000039_9ae4348f+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   409320 <__swc_fn_0a4ed24b_000114_cc486df9>
  4077ca:	lea    rcx,[rip+0x1c877]        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1c870]        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_0a4ed24b_000039_9ae4348f+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_0a4ed24b_000039_9ae4348f+0x90>
  4077f8:	lea    rcx,[rip+0x1c861]        # 424060 <__swc_bss_base_0a4ed24b+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1c85a]        # 424060 <__swc_bss_base_0a4ed24b+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_0a4ed24b_000039_9ae4348f+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_0a4ed24b_000039_9ae4348f+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_0a4ed24b_000042_0573444d>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_0a4ed24b_000042_0573444d+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40e5f0 <__swc_fn_0a4ed24b_000059_ee6a254c>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   4098a0 <__swc_fn_0a4ed24b_000135_db32cc57>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_0a4ed24b_000042_0573444d+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_0a4ed24b_000042_0573444d+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_0a4ed24b_000009_4c3ebf16>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_0a4ed24b_000042_0573444d+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40dd20 <__swc_fn_0a4ed24b_000014_be17798c>
  40791e:	jmp    407941 <__swc_fn_0a4ed24b_000042_0573444d+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_0a4ed24b_000042_0573444d+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_0a4ed24b_000042_0573444d+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_0a4ed24b_000042_0573444d+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40ade0 <__swc_fn_0a4ed24b_000043_47ff6d9b>
  407997:	mov    rcx,rdi
  40799a:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_0a4ed24b_000039_9ae4348f>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_0a4ed24b_000045_bb688d37>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_0a4ed24b_000045_bb688d37+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_0a4ed24b_000045_bb688d37+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_0a4ed24b_000045_bb688d37+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_0a4ed24b_000045_bb688d37+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   4098a0 <__swc_fn_0a4ed24b_000135_db32cc57>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_0a4ed24b_000045_bb688d37+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_0a4ed24b_000045_bb688d37+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_0a4ed24b_000045_bb688d37+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_0a4ed24b_000045_bb688d37+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_0a4ed24b_000009_4c3ebf16>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_0a4ed24b_000045_bb688d37+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_0a4ed24b_000045_bb688d37+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_0a4ed24b_000045_bb688d37+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_0a4ed24b_000045_bb688d37+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_0a4ed24b_000045_bb688d37+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40a820 <__swc_fn_0a4ed24b_000013_7b85dbab>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_0a4ed24b_000045_bb688d37+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_0a4ed24b_000045_bb688d37+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_0a4ed24b_000045_bb688d37+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_0a4ed24b_000045_bb688d37+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40dea0 <__swc_fn_0a4ed24b_000020_4285d9c5>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_0a4ed24b_000045_bb688d37+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40a820 <__swc_fn_0a4ed24b_000013_7b85dbab>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_0a4ed24b_000045_bb688d37+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_0a4ed24b_000021_9cf87641>
  407c07:	mov    rcx,r14
  407c0a:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_0a4ed24b_000045_bb688d37+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_0a4ed24b_000045_bb688d37+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_0a4ed24b_000045_bb688d37+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_0a4ed24b_000048_8e68f77b>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_0a4ed24b_000048_8e68f77b+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_0a4ed24b_000048_8e68f77b+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_0a4ed24b_000048_8e68f77b+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_0a4ed24b_000048_8e68f77b+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40e250 <__swc_fn_0a4ed24b_000047_e7fd8d42>
  407d14:	jmp    407ce0 <__swc_fn_0a4ed24b_000048_8e68f77b+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_0a4ed24b_000048_8e68f77b+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_0a4ed24b_000048_8e68f77b+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_0a4ed24b_000048_8e68f77b+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_0a4ed24b_000048_8e68f77b+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_0a4ed24b_000048_8e68f77b+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_0a4ed24b_000048_8e68f77b+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_0a4ed24b_000048_8e68f77b+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_0a4ed24b_000051_27d2a35f>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_0a4ed24b_000051_27d2a35f+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_0a4ed24b_000051_27d2a35f+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_0a4ed24b_000051_27d2a35f+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_0a4ed24b_000051_27d2a35f+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40e1b0 <__swc_fn_0a4ed24b_000044_fe6bbfdb>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40dd20 <__swc_fn_0a4ed24b_000014_be17798c>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_0a4ed24b_000054_e8e85c01>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   4098a0 <__swc_fn_0a4ed24b_000135_db32cc57>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_0a4ed24b_000054_e8e85c01+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_0a4ed24b_000054_e8e85c01+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_0a4ed24b_000054_e8e85c01+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_0a4ed24b_000057_01c75a1d>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_0a4ed24b_000060_6818d0d1>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_0a4ed24b_000060_6818d0d1+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_0a4ed24b_000039_9ae4348f>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_0a4ed24b_000060_6818d0d1+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_0a4ed24b_000063_db6d2425>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40b160 <__swc_fn_0a4ed24b_000052_92b016ae>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_0a4ed24b_000054_e8e85c01>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_0a4ed24b_000063_db6d2425+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_0a4ed24b_000063_db6d2425+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40b280 <__swc_fn_0a4ed24b_000058_01964a17>
  407f7f:	mov    rcx,rsi
  407f82:	call   40aec0 <__swc_fn_0a4ed24b_000049_f6a485a2>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_0a4ed24b_000066_918d3875>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_0a4ed24b_000066_918d3875+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1c049]        # 424070 <__swc_bss_base_0a4ed24b+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1c04b]        # 424080 <__swc_bss_base_0a4ed24b+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_0a4ed24b_000066_918d3875+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_0a4ed24b_000066_918d3875+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40ab50 <__swc_fn_0a4ed24b_000022_53fc00d2>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_0a4ed24b_000066_918d3875+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_0a4ed24b_000063_db6d2425>
  40808f:	jmp    408122 <__swc_fn_0a4ed24b_000066_918d3875+0x192>
  408094:	lea    rax,[rip+0x19f65]        # 422000 <__swc_data_base_0a4ed24b>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_0a4ed24b_000066_918d3875+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_0a4ed24b_000066_918d3875+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_0a4ed24b_000066_918d3875+0x135>
  4080b8:	call   40ac20 <__swc_fn_0a4ed24b_000031_3c3e930e>
  4080bd:	mov    rcx,rax
  4080c0:	call   4101e0 <__swc_fn_0a4ed24b_000128_8d8a7dd2>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_0a4ed24b_000066_918d3875+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_0a4ed24b_000066_918d3875+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_0a4ed24b_000066_918d3875+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40e250 <__swc_fn_0a4ed24b_000047_e7fd8d42>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_0a4ed24b_000066_918d3875+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_0a4ed24b_000051_27d2a35f>
  408115:	jmp    408122 <__swc_fn_0a4ed24b_000066_918d3875+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40a790 <__swc_fn_0a4ed24b_000010_0569f799>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_0a4ed24b_000069_34b04ef2>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_0a4ed24b_000036_290a131c>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_0a4ed24b_000069_34b04ef2+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1c09a]        # 424240 <__swc_bss_base_0a4ed24b+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_0a4ed24b_000069_34b04ef2+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   4098a0 <__swc_fn_0a4ed24b_000135_db32cc57>
  4081b5:	mov    rcx,rsi
  4081b8:	call   40ea20 <__swc_fn_0a4ed24b_000068_f501e74b>
  4081bd:	mov    rcx,rsi
  4081c0:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_0a4ed24b_000072_bf7b5562>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40e770 <__swc_fn_0a4ed24b_000065_0b20477c>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_0a4ed24b_000075_41334281>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   40ea20 <__swc_fn_0a4ed24b_000068_f501e74b>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_0a4ed24b_000078_140918ec>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_0a4ed24b_000078_140918ec+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_0a4ed24b_000078_140918ec+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_0a4ed24b_000081_f4f506c7>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_0a4ed24b_000084_5ed30bd6>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_0a4ed24b_000090_14cf59b2>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_0a4ed24b_000084_5ed30bd6+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_0a4ed24b_000084_5ed30bd6+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_0a4ed24b_000084_5ed30bd6+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_0a4ed24b_000084_5ed30bd6+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_0a4ed24b_000090_14cf59b2>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_0a4ed24b_000084_5ed30bd6+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_0a4ed24b_000084_5ed30bd6+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_0a4ed24b_000084_5ed30bd6+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_0a4ed24b_000084_5ed30bd6+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_0a4ed24b_000084_5ed30bd6+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_0a4ed24b_000084_5ed30bd6+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_0a4ed24b_000084_5ed30bd6+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_0a4ed24b_000084_5ed30bd6+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_0a4ed24b_000084_5ed30bd6+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_0a4ed24b_000084_5ed30bd6+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40c260 <__swc_fn_0a4ed24b_000082_ff7d1455>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_0a4ed24b_000084_5ed30bd6+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_0a4ed24b_000084_5ed30bd6+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_0a4ed24b_000084_5ed30bd6+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40c260 <__swc_fn_0a4ed24b_000082_ff7d1455>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_0a4ed24b_000084_5ed30bd6+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_0a4ed24b_000084_5ed30bd6>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_0a4ed24b_000084_5ed30bd6+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_0a4ed24b_000084_5ed30bd6+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_0a4ed24b_000087_693f118e>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_0a4ed24b_000090_14cf59b2>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_0a4ed24b_000087_693f118e+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   40ee80 <__swc_fn_0a4ed24b_000086_d9243de4>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_0a4ed24b_000087_693f118e+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_0a4ed24b_000087_693f118e+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_0a4ed24b_000087_693f118e+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40c260 <__swc_fn_0a4ed24b_000082_ff7d1455>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_0a4ed24b_000087_693f118e+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_0a4ed24b_000087_693f118e>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_0a4ed24b_000087_693f118e+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_0a4ed24b_000087_693f118e+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_0a4ed24b_000090_14cf59b2>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_0a4ed24b_000090_14cf59b2+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_0a4ed24b_000090_14cf59b2+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_0a4ed24b_000090_14cf59b2+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_0a4ed24b_000090_14cf59b2+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40c260 <__swc_fn_0a4ed24b_000082_ff7d1455>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40c260 <__swc_fn_0a4ed24b_000082_ff7d1455>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_0a4ed24b_000090_14cf59b2+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_0a4ed24b_000090_14cf59b2+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_0a4ed24b_000090_14cf59b2+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_0a4ed24b_000090_14cf59b2+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_0a4ed24b_000090_14cf59b2>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_0a4ed24b_000090_14cf59b2+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_0a4ed24b_000090_14cf59b2+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_0a4ed24b_000090_14cf59b2+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_0a4ed24b_000090_14cf59b2+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_0a4ed24b_000090_14cf59b2+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_0a4ed24b_000090_14cf59b2+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_0a4ed24b_000090_14cf59b2+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_0a4ed24b_000090_14cf59b2+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_0a4ed24b_000090_14cf59b2+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_0a4ed24b_000090_14cf59b2+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_0a4ed24b_000090_14cf59b2+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_0a4ed24b_000090_14cf59b2+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_0a4ed24b_000090_14cf59b2+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_0a4ed24b_000090_14cf59b2+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_0a4ed24b_000090_14cf59b2+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_0a4ed24b_000090_14cf59b2+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   409db0 <__swc_fn_0a4ed24b_000147_e7bfe29e>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_0a4ed24b_000090_14cf59b2+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_0a4ed24b_000090_14cf59b2>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_0a4ed24b_000090_14cf59b2+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_0a4ed24b_000090_14cf59b2+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_0a4ed24b_000090_14cf59b2+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   409db0 <__swc_fn_0a4ed24b_000147_e7bfe29e>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   409db0 <__swc_fn_0a4ed24b_000147_e7bfe29e>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_0a4ed24b_000093_0c97fc6c>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40c390 <__swc_fn_0a4ed24b_000091_f21926ed>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_0a4ed24b_000093_0c97fc6c+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_0a4ed24b_000093_0c97fc6c+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   410380 <__swc_fn_0a4ed24b_000137_2d595cc7>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_0a4ed24b_000093_0c97fc6c+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0xa872]        # 4131c0 <__swc_rdata_base_0a4ed24b+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   40feb0 <__swc_fn_0a4ed24b_000116_3f5cfdef>
  408959:	call   40cc10 <__swc_fn_0a4ed24b_000118_591530fe>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_0a4ed24b_000096_a4baaa40>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40896f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  408975:	vzeroupper
  408978:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40897e:	mov    QWORD PTR [rsp+0x48],rdx
  408983:	mov    rax,r8
  408986:	cmp    r8,0x1
  40898a:	mov    edx,0x1
  40898f:	cmovb  rax,rdx
  408993:	mov    QWORD PTR [rsp+0x50],rax
  408998:	mov    rbx,QWORD PTR [rcx+0x8]
  40899c:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a0:	mov    rcx,QWORD PTR [rcx]
  4089a3:	lea    rdx,[rsp+0x8]
  4089a8:	call   rbx
  4089aa:	add    rsp,0x70
  4089ae:	pop    rbx
  4089af:	ret

00000000004089b0 <__swc_fn_0a4ed24b_000099_5232b57d>:
  4089b0:	push   rbx
  4089b1:	push   rsi
  4089b2:	push   rdi
  4089b3:	sub    rsp,0x30
  4089b7:	mov    rbx,rcx
  4089ba:	test   rcx,rcx
  4089bd:	je     4089d2 <__swc_fn_0a4ed24b_000099_5232b57d+0x22>
  4089bf:	mov    rcx,rbx
  4089c2:	mov    edx,0x1
  4089c7:	call   408200 <__swc_fn_0a4ed24b_000078_140918ec>
  4089cc:	cmp    rax,0x1
  4089d0:	je     4089da <__swc_fn_0a4ed24b_000099_5232b57d+0x2a>
  4089d2:	add    rsp,0x30
  4089d6:	pop    rdi
  4089d7:	pop    rsi
  4089d8:	pop    rbx
  4089d9:	ret
  4089da:	lea    rsi,[rsp+0x8]
  4089df:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089e4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089ea:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  4089ef:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4089f5:	mov    rax,QWORD PTR [rsp+0x20]
  4089fa:	test   rax,rax
  4089fd:	je     408a13 <__swc_fn_0a4ed24b_000099_5232b57d+0x63>
  4089ff:	test   DWORD PTR [rax+0x28],0x400000
  408a06:	je     408a13 <__swc_fn_0a4ed24b_000099_5232b57d+0x63>
  408a08:	mov    rcx,QWORD PTR [rax+0x30]
  408a0c:	test   rcx,rcx
  408a0f:	cmovne rax,rcx
  408a13:	mov    edi,DWORD PTR [rax+0x20]
  408a16:	lea    rcx,[rsp+0x18]
  408a1b:	call   40c570 <__swc_fn_0a4ed24b_000100_5714513e>
  408a20:	mov    rcx,rsi
  408a23:	mov    rdx,QWORD PTR [rsp+0x18]
  408a28:	mov    r8,rdi
  408a2b:	call   408960 <__swc_fn_0a4ed24b_000096_a4baaa40>
  408a30:	mov    rcx,QWORD PTR [rbx+0x28]
  408a34:	call   40f460 <__swc_fn_0a4ed24b_000098_f82a1ed3>
  408a39:	mov    rcx,rsi
  408a3c:	mov    rdx,rbx
  408a3f:	mov    r8d,0x30
  408a45:	call   408960 <__swc_fn_0a4ed24b_000096_a4baaa40>
  408a4a:	add    rsp,0x30
  408a4e:	pop    rdi
  408a4f:	pop    rsi
  408a50:	pop    rbx
  408a51:	ret
	...

0000000000408a60 <__swc_fn_0a4ed24b_000102_14986ec5>:
  408a60:	push   rbp
  408a61:	push   rbx
  408a62:	push   rsi
  408a63:	push   rdi
  408a64:	push   r12
  408a66:	push   r13
  408a68:	push   r14
  408a6a:	push   r15
  408a6c:	sub    rsp,0x500
  408a73:	mov    rbp,rsp
  408a76:	mov    rbx,rsp
  408a79:	mov    rsi,rdx
  408a7c:	mov    rdi,rcx
  408a7f:	mov    rcx,QWORD PTR [rip+0x1e2ba]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  408a86:	test   rcx,rcx
  408a89:	jne    408aa3 <__swc_fn_0a4ed24b_000102_14986ec5+0x43>
  408a8b:	sub    rsp,0x8
  408a8f:	call   40a1a0 <__swc_fn_0a4ed24b_000165_56054fe7>
  408a94:	add    rsp,0x8
  408a98:	lea    rcx,[rax+0x1]
  408a9c:	mov    QWORD PTR [rip+0x1e29d],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  408aa3:	dec    rcx
  408aa6:	sub    rsp,0x8
  408aaa:	call   411c60 <__swc_fn_0a4ed24b_000167_39c041ad>
  408aaf:	add    rsp,0x8
  408ab3:	mov    r12,rax
  408ab6:	mov    QWORD PTR [rsp+0x4f0],rax
  408abe:	lea    rax,[rip+0xa83b]        # 413300 <__swc_rdata_base_0a4ed24b+0x1f0>
  408ac5:	sub    rsp,0x20
  408ac9:	mov    rcx,rsp
  408acc:	mov    QWORD PTR [rcx],rax
  408acf:	lea    r13,[rip+0xa83a]        # 413310 <__swc_rdata_base_0a4ed24b+0x200>
  408ad6:	mov    QWORD PTR [rcx+0x8],r13
  408ada:	mov    QWORD PTR [rcx+0x10],rsp
  408ade:	mov    QWORD PTR [rcx+0x18],0x1
  408ae6:	lea    rcx,[rsp+0x10]
  408aeb:	sub    rsp,0x8
  408aef:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  408af4:	add    rsp,0x8
  408af8:	add    rsp,0x20
  408afc:	lea    rax,[rip+0xa855]        # 413358 <__swc_rdata_base_0a4ed24b+0x248>
  408b03:	sub    rsp,0x20
  408b07:	mov    rcx,rsp
  408b0a:	mov    QWORD PTR [rcx],rax
  408b0d:	mov    QWORD PTR [rcx+0x8],r13
  408b11:	mov    QWORD PTR [rcx+0x10],rsp
  408b15:	mov    QWORD PTR [rcx+0x18],0x1
  408b1d:	lea    rcx,[rsp+0x10]
  408b22:	sub    rsp,0x8
  408b26:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  408b2b:	add    rsp,0x8
  408b2f:	add    rsp,0x20
  408b33:	lea    r14,[rip+0xa82e]        # 413368 <__swc_rdata_base_0a4ed24b+0x258>
  408b3a:	sub    rsp,0x50
  408b3e:	mov    rax,rsp
  408b41:	vmovups xmm0,XMMWORD PTR [rip+0xa957]        # 4134a0 <__swc_rdata_base_0a4ed24b+0x390>
  408b49:	vmovups XMMWORD PTR [rax],xmm0
  408b4d:	mov    QWORD PTR [rax+0x10],rsp
  408b51:	mov    QWORD PTR [rax+0x18],r13
  408b55:	mov    QWORD PTR [rax+0x20],rdi
  408b59:	lea    rdi,[rip+0xa818]        # 413378 <__swc_rdata_base_0a4ed24b+0x268>
  408b60:	mov    QWORD PTR [rax+0x28],rdi
  408b64:	mov    QWORD PTR [rax+0x30],r14
  408b68:	mov    QWORD PTR [rax+0x38],r13
  408b6c:	lea    rcx,[rsp+0x10]
  408b71:	mov    QWORD PTR [rax+0x40],rcx
  408b75:	mov    QWORD PTR [rax+0x48],0x3
  408b7d:	lea    rcx,[rsp+0x40]
  408b82:	sub    rsp,0x8
  408b86:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  408b8b:	add    rsp,0x8
  408b8f:	add    rsp,0x50
  408b93:	lea    rax,[rip+0xa826]        # 4133c0 <__swc_rdata_base_0a4ed24b+0x2b0>
  408b9a:	sub    rsp,0x20
  408b9e:	mov    rcx,rsp
  408ba1:	mov    QWORD PTR [rcx],rax
  408ba4:	mov    QWORD PTR [rcx+0x8],r13
  408ba8:	mov    QWORD PTR [rcx+0x10],rsp
  408bac:	mov    QWORD PTR [rcx+0x18],0x1
  408bb4:	lea    rcx,[rsp+0x10]
  408bb9:	sub    rsp,0x8
  408bbd:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  408bc2:	add    rsp,0x8
  408bc6:	add    rsp,0x20
  408bca:	mov    eax,DWORD PTR [rsi+0x20]
  408bcd:	mov    ecx,DWORD PTR [rsi+0x24]
  408bd0:	sub    rsp,0xa0
  408bd7:	mov    rdx,rsp
  408bda:	mov    QWORD PTR [rdx+0x30],rsi
  408bde:	mov    QWORD PTR [rdx+0x38],rdi
  408be2:	vmovups xmm0,XMMWORD PTR [rip+0xa84e]        # 413438 <__swc_rdata_base_0a4ed24b+0x328>
  408bea:	vmovups XMMWORD PTR [rdx],xmm0
  408bee:	mov    QWORD PTR [rdx+0x40],rsp
  408bf2:	mov    QWORD PTR [rdx+0x48],r13
  408bf6:	mov    DWORD PTR [rdx+0x10],eax
  408bf9:	lea    rax,[rsp+0x10]
  408bfe:	mov    QWORD PTR [rdx+0x50],rax
  408c02:	lea    rax,[rip+0xa7c7]        # 4133d0 <__swc_rdata_base_0a4ed24b+0x2c0>
  408c09:	mov    QWORD PTR [rdx+0x58],rax
  408c0d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c12:	lea    r8,[rsp+0x18]
  408c17:	mov    QWORD PTR [rdx+0x60],r8
  408c1b:	mov    QWORD PTR [rdx+0x68],r13
  408c1f:	mov    DWORD PTR [rdx+0x28],ecx
  408c22:	lea    rcx,[rdx+0x28]
  408c26:	mov    QWORD PTR [rdx+0x70],rcx
  408c2a:	mov    QWORD PTR [rdx+0x78],rax
  408c2e:	mov    QWORD PTR [rdx+0x80],r14
  408c35:	mov    QWORD PTR [rdx+0x88],r13
  408c3c:	lea    rax,[rdx+0x30]
  408c40:	mov    QWORD PTR [rdx+0x90],rax
  408c47:	mov    QWORD PTR [rdx+0x98],0x6
  408c52:	lea    rcx,[rdx+0x90]
  408c59:	sub    rsp,0x8
  408c5d:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  408c62:	add    rsp,0x8
  408c66:	add    rsp,0xa0
  408c6d:	sub    rsp,0x20
  408c71:	mov    rax,rsp
  408c74:	mov    QWORD PTR [rax],r14
  408c77:	mov    QWORD PTR [rax+0x8],r13
  408c7b:	mov    QWORD PTR [rax+0x10],rsp
  408c7f:	mov    QWORD PTR [rax+0x18],0x1
  408c87:	lea    rcx,[rsp+0x10]
  408c8c:	sub    rsp,0x8
  408c90:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  408c95:	add    rsp,0x8
  408c99:	add    rsp,0x20
  408c9d:	mov    eax,DWORD PTR [r12+0x9ac]
  408ca5:	test   eax,eax
  408ca7:	je     408ee0 <__swc_fn_0a4ed24b_000102_14986ec5+0x480>
  408cad:	lea    rax,[rip+0xa764]        # 413418 <__swc_rdata_base_0a4ed24b+0x308>
  408cb4:	sub    rsp,0x20
  408cb8:	mov    rcx,rsp
  408cbb:	mov    QWORD PTR [rcx],rax
  408cbe:	mov    QWORD PTR [rcx+0x8],r13
  408cc2:	mov    QWORD PTR [rcx+0x10],rsp
  408cc6:	mov    QWORD PTR [rcx+0x18],0x1
  408cce:	lea    rcx,[rsp+0x10]
  408cd3:	sub    rsp,0x8
  408cd7:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  408cdc:	add    rsp,0x8
  408ce0:	add    rsp,0x20
  408ce4:	mov    eax,DWORD PTR [r12+0x9ac]
  408cec:	dec    eax
  408cee:	mov    esi,eax
  408cf0:	test   esi,esi
  408cf2:	jl     408eb0 <__swc_fn_0a4ed24b_000102_14986ec5+0x450>
  408cf8:	jmp    408d04 <__swc_fn_0a4ed24b_000102_14986ec5+0x2a4>
  408cfa:	nop    WORD PTR [rax+rax*1+0x0]
  408d00:	dec    esi
  408d02:	jmp    408cf0 <__swc_fn_0a4ed24b_000102_14986ec5+0x290>
  408d04:	lea    rax,[rip+0xa71d]        # 413428 <__swc_rdata_base_0a4ed24b+0x318>
  408d0b:	sub    rsp,0x20
  408d0f:	mov    rcx,rsp
  408d12:	mov    QWORD PTR [rcx],rax
  408d15:	mov    QWORD PTR [rcx+0x8],r13
  408d19:	mov    QWORD PTR [rcx+0x10],rsp
  408d1d:	mov    QWORD PTR [rcx+0x18],0x1
  408d25:	lea    rcx,[rsp+0x10]
  408d2a:	sub    rsp,0x8
  408d2e:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  408d33:	add    rsp,0x8
  408d37:	add    rsp,0x20
  408d3b:	movsxd rax,esi
  408d3e:	imul   r15,rax,0x30
  408d42:	add    r15,r12
  408d45:	add    r15,0xf8
  408d4c:	sub    rsp,0x20
  408d50:	mov    rax,rsp
  408d53:	mov    QWORD PTR [rax],r15
  408d56:	mov    QWORD PTR [rax+0x8],rdi
  408d5a:	mov    QWORD PTR [rax+0x10],rsp
  408d5e:	mov    QWORD PTR [rax+0x18],0x1
  408d66:	lea    rcx,[rsp+0x10]
  408d6b:	sub    rsp,0x8
  408d6f:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  408d74:	add    rsp,0x8
  408d78:	add    rsp,0x20
  408d7c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408d84:	lea    rsi,[rip+0xa6ad]        # 413438 <__swc_rdata_base_0a4ed24b+0x328>
  408d8b:	sub    rsp,0x20
  408d8f:	mov    rax,rsp
  408d92:	mov    QWORD PTR [rax],rsi
  408d95:	mov    QWORD PTR [rax+0x8],r13
  408d99:	mov    QWORD PTR [rax+0x10],rsp
  408d9d:	mov    QWORD PTR [rax+0x18],0x1
  408da5:	lea    rcx,[rsp+0x10]
  408daa:	sub    rsp,0x8
  408dae:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  408db3:	add    rsp,0x8
  408db7:	add    rsp,0x20
  408dbb:	sub    rsp,0x30
  408dbf:	mov    rax,rsp
  408dc2:	mov    ecx,DWORD PTR [r15+0x20]
  408dc6:	mov    QWORD PTR [rax],rcx
  408dc9:	mov    QWORD PTR [rax+0x8],rsp
  408dcd:	lea    rdi,[rip+0xa674]        # 413448 <__swc_rdata_base_0a4ed24b+0x338>
  408dd4:	mov    QWORD PTR [rax+0x10],rdi
  408dd8:	lea    rcx,[rsp+0x8]
  408ddd:	mov    QWORD PTR [rax+0x18],rcx
  408de1:	mov    QWORD PTR [rax+0x20],0x1
  408de9:	lea    rcx,[rsp+0x18]
  408dee:	sub    rsp,0x8
  408df2:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  408df7:	add    rsp,0x8
  408dfb:	add    rsp,0x30
  408dff:	sub    rsp,0x20
  408e03:	mov    rax,rsp
  408e06:	mov    QWORD PTR [rax],rsi
  408e09:	mov    QWORD PTR [rax+0x8],r13
  408e0d:	mov    QWORD PTR [rax+0x10],rsp
  408e11:	mov    QWORD PTR [rax+0x18],0x1
  408e19:	lea    rcx,[rsp+0x10]
  408e1e:	sub    rsp,0x8
  408e22:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  408e27:	add    rsp,0x8
  408e2b:	add    rsp,0x20
  408e2f:	sub    rsp,0x30
  408e33:	mov    rax,rsp
  408e36:	mov    ecx,DWORD PTR [r15+0x24]
  408e3a:	mov    QWORD PTR [rax],rcx
  408e3d:	mov    QWORD PTR [rax+0x8],rsp
  408e41:	mov    QWORD PTR [rax+0x10],rdi
  408e45:	lea    rcx,[rsp+0x8]
  408e4a:	mov    QWORD PTR [rax+0x18],rcx
  408e4e:	mov    QWORD PTR [rax+0x20],0x1
  408e56:	lea    rcx,[rsp+0x18]
  408e5b:	sub    rsp,0x8
  408e5f:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  408e64:	add    rsp,0x8
  408e68:	add    rsp,0x30
  408e6c:	sub    rsp,0x20
  408e70:	mov    rax,rsp
  408e73:	mov    QWORD PTR [rax],r14
  408e76:	mov    QWORD PTR [rax+0x8],r13
  408e7a:	mov    QWORD PTR [rax+0x10],rsp
  408e7e:	mov    QWORD PTR [rax+0x18],0x1
  408e86:	lea    rcx,[rsp+0x10]
  408e8b:	sub    rsp,0x8
  408e8f:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  408e94:	add    rsp,0x8
  408e98:	add    rsp,0x20
  408e9c:	lea    rdi,[rip+0xa4d5]        # 413378 <__swc_rdata_base_0a4ed24b+0x268>
  408ea3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408eab:	jmp    408d00 <__swc_fn_0a4ed24b_000102_14986ec5+0x2a0>
  408eb0:	sub    rsp,0x20
  408eb4:	mov    rax,rsp
  408eb7:	mov    QWORD PTR [rax],r14
  408eba:	mov    QWORD PTR [rax+0x8],r13
  408ebe:	mov    QWORD PTR [rax+0x10],rsp
  408ec2:	mov    QWORD PTR [rax+0x18],0x1
  408eca:	lea    rcx,[rsp+0x10]
  408ecf:	sub    rsp,0x8
  408ed3:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  408ed8:	add    rsp,0x8
  408edc:	add    rsp,0x20
  408ee0:	lea    rax,[rbx+0x28]
  408ee4:	mov    rcx,rax
  408ee7:	mov    QWORD PTR [rbx+0x28],0x0
  408eef:	mov    QWORD PTR [rbx+0x30],0x0
  408ef7:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408efc:	add    rcx,0x10
  408f00:	mov    edx,0x1f
  408f05:	cs nop WORD PTR [rax+rax*1+0x0]
  408f0f:	nop
  408f10:	vmovups XMMWORD PTR [rcx],xmm0
  408f14:	add    rcx,0x10
  408f18:	sub    rdx,0x1
  408f1c:	jne    408f10 <__swc_fn_0a4ed24b_000102_14986ec5+0x4b0>
  408f1e:	lea    rsi,[rbx+0x228]
  408f25:	xor    ecx,ecx
  408f27:	cs nop WORD PTR [rax+rax*1+0x0]
  408f31:	cs nop WORD PTR [rax+rax*1+0x0]
  408f3b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f40:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f45:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f4a:	add    rcx,0x10
  408f4e:	cmp    rcx,0x200
  408f55:	jne    408f40 <__swc_fn_0a4ed24b_000102_14986ec5+0x4e0>
  408f57:	mov    eax,DWORD PTR [r12+0xbc8]
  408f5f:	lea    rcx,[r12+0x9c8]
  408f67:	mov    QWORD PTR [rbx+0x428],rcx
  408f6e:	mov    QWORD PTR [rbx+0x430],rax
  408f75:	lea    rdi,[rbx+0x438]
  408f7c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408f84:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408f8c:	mov    eax,DWORD PTR [r12+0xbc8]
  408f94:	test   eax,eax
  408f96:	jne    408fe3 <__swc_fn_0a4ed24b_000102_14986ec5+0x583>
  408f98:	lea    rax,[rbx+0x448]
  408f9f:	mov    QWORD PTR [rbx+0x448],rsi
  408fa6:	mov    QWORD PTR [rax+0x8],0x40
  408fae:	mov    ecx,0x1
  408fb3:	mov    rdx,rax
  408fb6:	sub    rsp,0x8
  408fba:	call   40ffc0 <__swc_fn_0a4ed24b_000119_2d9caf16>
  408fbf:	add    rsp,0x8
  408fc3:	mov    QWORD PTR [rbx+0x460],rsi
  408fca:	mov    ecx,eax
  408fcc:	mov    QWORD PTR [rbx+0x468],rcx
  408fd3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408fdb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fe3:	mov    rsi,QWORD PTR [rbx+0x438]
  408fea:	mov    rax,QWORD PTR [rbx+0x440]
  408ff1:	mov    r15,rax
  408ff4:	xor    r12d,r12d
  408ff7:	test   r15,r15
  408ffa:	je     4090b0 <__swc_fn_0a4ed24b_000102_14986ec5+0x650>
  409000:	mov    rax,QWORD PTR [rsi+r12*8]
  409004:	test   rax,rax
  409007:	je     409026 <__swc_fn_0a4ed24b_000102_14986ec5+0x5c6>
  409009:	lea    rcx,[rbx+0x4b8]
  409010:	mov    rdx,rax
  409013:	sub    rsp,0x8
  409017:	call   409f10 <__swc_fn_0a4ed24b_000162_61e293bf>
  40901c:	add    rsp,0x8
  409020:	mov    al,BYTE PTR [rax]
  409022:	test   al,al
  409024:	jne    409032 <__swc_fn_0a4ed24b_000102_14986ec5+0x5d2>
  409026:	add    r12,0x1
  40902a:	sub    r15,0x1
  40902e:	jne    409000 <__swc_fn_0a4ed24b_000102_14986ec5+0x5a0>
  409030:	jmp    4090b0 <__swc_fn_0a4ed24b_000102_14986ec5+0x650>
  409032:	lea    rax,[rip+0xa457]        # 413490 <__swc_rdata_base_0a4ed24b+0x380>
  409039:	sub    rsp,0x20
  40903d:	mov    rcx,rsp
  409040:	mov    QWORD PTR [rcx],rax
  409043:	mov    QWORD PTR [rcx+0x8],r13
  409047:	mov    QWORD PTR [rcx+0x10],rsp
  40904b:	mov    QWORD PTR [rcx+0x18],0x1
  409053:	lea    rcx,[rsp+0x10]
  409058:	sub    rsp,0x8
  40905c:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  409061:	add    rsp,0x8
  409065:	add    rsp,0x20
  409069:	mov    rcx,rdi
  40906c:	xor    edx,edx
  40906e:	mov    al,0x1
  409070:	mov    r8,rax
  409073:	sub    rsp,0x8
  409077:	call   40d4a0 <__swc_fn_0a4ed24b_000163_3a7aae74>
  40907c:	add    rsp,0x8
  409080:	sub    rsp,0x20
  409084:	mov    rax,rsp
  409087:	mov    QWORD PTR [rax],r14
  40908a:	mov    QWORD PTR [rax+0x8],r13
  40908e:	mov    QWORD PTR [rax+0x10],rsp
  409092:	mov    QWORD PTR [rax+0x18],0x1
  40909a:	lea    rcx,[rsp+0x10]
  40909f:	sub    rsp,0x8
  4090a3:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  4090a8:	add    rsp,0x8
  4090ac:	add    rsp,0x20
  4090b0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090b8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090c4:	add    rsp,0x500
  4090cb:	pop    r15
  4090cd:	pop    r14
  4090cf:	pop    r13
  4090d1:	pop    r12
  4090d3:	pop    rdi
  4090d4:	pop    rsi
  4090d5:	pop    rbx
  4090d6:	pop    rbp
  4090d7:	ret
	...

00000000004090e0 <__swc_fn_0a4ed24b_000105_83487ba1>:
  4090e0:	sub    rsp,0x8
  4090e4:	test   r8,r8
  4090e7:	je     4090ee <__swc_fn_0a4ed24b_000105_83487ba1+0xe>
  4090e9:	call   40f6f0 <__swc_fn_0a4ed24b_000104_04d1a8be>
  4090ee:	add    rsp,0x8
  4090f2:	ret
	...

0000000000409100 <__swc_fn_0a4ed24b_000108_b8f4bd15>:
  409100:	push   rsi
  409101:	push   rdi
  409102:	push   r12
  409104:	push   r13
  409106:	sub    rsp,0xd8
  40910d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409113:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  409119:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40911f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  409125:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40912b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  409134:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40913d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  409146:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40914f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  409158:	xor    eax,eax
  40915a:	call   407010 <getpid@plt>
  40915f:	mov    rsi,rax
  409162:	lea    rdi,[rip+0x1dbdf]        # 426d48 <__swc_bss_base_0a4ed24b+0x2d08>
  409169:	mov    r12,QWORD PTR [rdi]
  40916c:	test   r12,r12
  40916f:	je     40917d <__swc_fn_0a4ed24b_000108_b8f4bd15+0x7d>
  409171:	cmp    DWORD PTR [r12+0x10],esi
  409176:	jne    40917d <__swc_fn_0a4ed24b_000108_b8f4bd15+0x7d>
  409178:	mov    rax,r12
  40917b:	jmp    4091e0 <__swc_fn_0a4ed24b_000108_b8f4bd15+0xe0>
  40917d:	mov    ecx,0x4
  409182:	mov    edx,0x18
  409187:	call   40f7d0 <__swc_fn_0a4ed24b_000107_c8d4a68e>
  40918c:	mov    rcx,rax
  40918f:	test   rax,rax
  409192:	jne    409198 <__swc_fn_0a4ed24b_000108_b8f4bd15+0x98>
  409194:	xor    eax,eax
  409196:	jmp    4091e0 <__swc_fn_0a4ed24b_000108_b8f4bd15+0xe0>
  409198:	mov    DWORD PTR [rcx+0x10],esi
  40919b:	mov    rax,r12
  40919e:	lock cmpxchg QWORD PTR [rdi],rcx
  4091a3:	mov    r13,rax
  4091a6:	cmp    rax,r12
  4091a9:	je     4091bf <__swc_fn_0a4ed24b_000108_b8f4bd15+0xbf>
  4091ab:	mov    rdi,rcx
  4091ae:	mov    esi,0x18
  4091b3:	xor    eax,eax
  4091b5:	call   407020 <munmap@plt>
  4091ba:	mov    rax,r13
  4091bd:	jmp    4091e0 <__swc_fn_0a4ed24b_000108_b8f4bd15+0xe0>
  4091bf:	test   r12,r12
  4091c2:	je     4091dd <__swc_fn_0a4ed24b_000108_b8f4bd15+0xdd>
  4091c4:	mov    rdi,r12
  4091c7:	mov    esi,0x18
  4091cc:	xor    eax,eax
  4091ce:	mov    QWORD PTR [rsp+0x28],rcx
  4091d3:	call   407020 <munmap@plt>
  4091d8:	mov    rcx,QWORD PTR [rsp+0x28]
  4091dd:	mov    rax,rcx
  4091e0:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  4091e6:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  4091ec:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  4091f2:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  4091f8:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  4091fe:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409207:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  409210:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409219:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  409222:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40922b:	add    rsp,0xd8
  409232:	pop    r13
  409234:	pop    r12
  409236:	pop    rdi
  409237:	pop    rsi
  409238:	ret
  409239:	add    BYTE PTR [rax],al
  40923b:	add    BYTE PTR [rax],al
  40923d:	add    BYTE PTR [rax],al
	...

0000000000409240 <__swc_fn_0a4ed24b_000111_f9e19033>:
  409240:	push   rbx
  409241:	push   r12
  409243:	push   rdi
  409244:	push   rsi
  409245:	sub    rsp,0xa8
  40924c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409252:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409258:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40925e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409264:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40926a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409270:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409276:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40927c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409285:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40928e:	mov    rbx,rdx
  409291:	mov    r12,rcx
  409294:	mov    rdi,rcx
  409297:	mov    rsi,rdx
  40929a:	mov    edx,0x3
  40929f:	xor    eax,eax
  4092a1:	call   407030 <mprotect@plt>
  4092a6:	test   eax,eax
  4092a8:	je     4092ae <__swc_fn_0a4ed24b_000111_f9e19033+0x6e>
  4092aa:	xor    eax,eax
  4092ac:	jmp    4092c3 <__swc_fn_0a4ed24b_000111_f9e19033+0x83>
  4092ae:	mov    rcx,r12
  4092b1:	mov    rdx,rbx
  4092b4:	mov    al,0x1
  4092b6:	mov    r8,rax
  4092b9:	call   40fe00 <__swc_fn_0a4ed24b_000110_918d5a21>
  4092be:	mov    eax,0x1
  4092c3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4092c9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4092cf:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4092d5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4092db:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4092e1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4092e7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4092ed:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4092f3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4092fc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409305:	add    rsp,0xa8
  40930c:	pop    rsi
  40930d:	pop    rdi
  40930e:	pop    r12
  409310:	pop    rbx
  409311:	ret
	...

0000000000409320 <__swc_fn_0a4ed24b_000114_cc486df9>:
  409320:	sub    rsp,0x8
  409324:	test   rcx,rcx
  409327:	jne    40932e <__swc_fn_0a4ed24b_000114_cc486df9+0xe>
  409329:	add    rsp,0x8
  40932d:	ret
  40932e:	call   40cac0 <__swc_fn_0a4ed24b_000115_3f6af4b1>
  409333:	add    rsp,0x8
  409337:	ret
	...

0000000000409340 <__swc_fn_0a4ed24b_000117_5aba1420>:
  409340:	push   rdi
  409341:	push   rsi
  409342:	sub    rsp,0xa8
  409349:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40934f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409355:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40935b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409361:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409367:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40936d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409373:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409379:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409382:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40938b:	xor    edi,edi
  40938d:	xor    eax,eax
  40938f:	call   407040 <exit@plt>
  409394:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40939a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4093a0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4093a6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4093ac:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4093b2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4093b8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4093be:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4093c4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4093cd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4093d6:	add    rsp,0xa8
  4093dd:	pop    rsi
  4093de:	pop    rdi
  4093df:	ret

00000000004093e0 <__swc_fn_0a4ed24b_000120_1e032ef6>:
  4093e0:	push   rbx
  4093e1:	push   rsi
  4093e2:	push   rdi
  4093e3:	push   r12
  4093e5:	sub    rsp,0x18
  4093e9:	mov    rbx,r8
  4093ec:	mov    rsi,rcx
  4093ef:	mov    rdi,rdx
  4093f2:	mov    rcx,QWORD PTR [rip+0x1d947]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  4093f9:	test   rcx,rcx
  4093fc:	jne    40940e <__swc_fn_0a4ed24b_000120_1e032ef6+0x2e>
  4093fe:	call   40a1a0 <__swc_fn_0a4ed24b_000165_56054fe7>
  409403:	lea    rcx,[rax+0x1]
  409407:	mov    QWORD PTR [rip+0x1d932],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40940e:	dec    rcx
  409411:	call   411c60 <__swc_fn_0a4ed24b_000167_39c041ad>
  409416:	mov    r12,rax
  409419:	cmp    ebx,0x3
  40941c:	jne    40942f <__swc_fn_0a4ed24b_000120_1e032ef6+0x4f>
  40941e:	mov    rax,QWORD PTR [r12+0xbd0]
  409426:	test   rax,rax
  409429:	jne    40956c <__swc_fn_0a4ed24b_000120_1e032ef6+0x18c>
  40942f:	cmp    ebx,0x5
  409432:	jne    409456 <__swc_fn_0a4ed24b_000120_1e032ef6+0x76>
  409434:	call   40c390 <__swc_fn_0a4ed24b_000091_f21926ed>
  409439:	test   al,al
  40943b:	jne    409456 <__swc_fn_0a4ed24b_000120_1e032ef6+0x76>
  40943d:	mov    rcx,rsi
  409440:	mov    rdx,rdi
  409443:	call   411c10 <__swc_fn_0a4ed24b_000164_d25850aa>
  409448:	test   al,al
  40944a:	je     409456 <__swc_fn_0a4ed24b_000120_1e032ef6+0x76>
  40944c:	add    rsp,0x18
  409450:	pop    r12
  409452:	pop    rdi
  409453:	pop    rsi
  409454:	pop    rbx
  409455:	ret
  409456:	call   40c390 <__swc_fn_0a4ed24b_000091_f21926ed>
  40945b:	test   al,al
  40945d:	jne    4094cf <__swc_fn_0a4ed24b_000120_1e032ef6+0xef>
  40945f:	vmovups xmm0,XMMWORD PTR [rsi]
  409463:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409469:	mov    rax,QWORD PTR [rsp+0x8]
  40946e:	test   rax,rax
  409471:	jne    4094c2 <__swc_fn_0a4ed24b_000120_1e032ef6+0xe2>
  409473:	cmp    ebx,0x3
  409476:	je     409484 <__swc_fn_0a4ed24b_000120_1e032ef6+0xa4>
  409478:	cmp    ebx,0x4
  40947b:	je     409494 <__swc_fn_0a4ed24b_000120_1e032ef6+0xb4>
  40947d:	cmp    ebx,0x5
  409480:	je     4094a4 <__swc_fn_0a4ed24b_000120_1e032ef6+0xc4>
  409482:	jmp    4094b4 <__swc_fn_0a4ed24b_000120_1e032ef6+0xd4>
  409484:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 4134e0 <__swc_rdata_base_0a4ed24b+0x3d0>
  40948c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409492:	jmp    4094c2 <__swc_fn_0a4ed24b_000120_1e032ef6+0xe2>
  409494:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 4134f0 <__swc_rdata_base_0a4ed24b+0x3e0>
  40949c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094a2:	jmp    4094c2 <__swc_fn_0a4ed24b_000120_1e032ef6+0xe2>
  4094a4:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 413500 <__swc_rdata_base_0a4ed24b+0x3f0>
  4094ac:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094b2:	jmp    4094c2 <__swc_fn_0a4ed24b_000120_1e032ef6+0xe2>
  4094b4:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 413510 <__swc_rdata_base_0a4ed24b+0x400>
  4094bc:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094c2:	lea    rcx,[rsp+0x8]
  4094c7:	mov    rdx,rdi
  4094ca:	call   40c5e0 <__swc_fn_0a4ed24b_000103_0d4cc079>
  4094cf:	vmovups xmm0,XMMWORD PTR [rdi]
  4094d3:	vmovups XMMWORD PTR [r12+0x940],xmm0
  4094dd:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  4094e2:	vmovups XMMWORD PTR [r12+0x950],xmm0
  4094ec:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  4094f1:	vmovups XMMWORD PTR [r12+0x960],xmm0
  4094fb:	lea    rax,[r12+0x940]
  409503:	mov    QWORD PTR [r12+0x970],rax
  40950b:	mov    rax,QWORD PTR [rsi]
  40950e:	mov    QWORD PTR [r12+0x978],rax
  409516:	mov    rax,QWORD PTR [rsi+0x8]
  40951a:	mov    QWORD PTR [r12+0x980],rax
  409522:	movsxd rax,ebx
  409525:	mov    QWORD PTR [r12+0x988],rax
  40952d:	cmp    ebx,0x5
  409530:	je     409539 <__swc_fn_0a4ed24b_000120_1e032ef6+0x159>
  409532:	xor    ecx,ecx
  409534:	call   40a2d0 <__swc_fn_0a4ed24b_000174_02e645b4>
  409539:	mov    rbx,QWORD PTR [r12+0xbe8]
  409541:	test   rbx,rbx
  409544:	je     409555 <__swc_fn_0a4ed24b_000120_1e032ef6+0x175>
  409546:	mov    rcx,r12
  409549:	call   rbx
  40954b:	add    rsp,0x18
  40954f:	pop    r12
  409551:	pop    rdi
  409552:	pop    rsi
  409553:	pop    rbx
  409554:	ret
  409555:	mov    rcx,rsi
  409558:	call   40feb0 <__swc_fn_0a4ed24b_000116_3f5cfdef>
  40955d:	call   40cc10 <__swc_fn_0a4ed24b_000118_591530fe>
  409562:	add    rsp,0x18
  409566:	pop    r12
  409568:	pop    rdi
  409569:	pop    rsi
  40956a:	pop    rbx
  40956b:	ret
  40956c:	mov    rcx,rsi
  40956f:	mov    rdx,rdi
  409572:	call   40c5e0 <__swc_fn_0a4ed24b_000103_0d4cc079>
  409577:	jmp    40942f <__swc_fn_0a4ed24b_000120_1e032ef6+0x4f>
  40957c:	add    BYTE PTR [rax],al
	...

0000000000409580 <__swc_fn_0a4ed24b_000123_e4107ade>:
  409580:	push   rdi
  409581:	push   rsi
  409582:	sub    rsp,0xb8
  409589:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40958f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409595:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40959b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4095a1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4095a7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4095ad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4095b3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4095bc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4095c5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4095ce:	mov    DWORD PTR [rsp+0x8],0x0
  4095d6:	lea    rdi,[rsp+0x8]
  4095db:	xor    esi,esi
  4095dd:	xor    eax,eax
  4095df:	call   407050 <pthread_key_create@plt>
  4095e4:	test   eax,eax
  4095e6:	jne    4095ee <__swc_fn_0a4ed24b_000123_e4107ade+0x6e>
  4095e8:	mov    eax,DWORD PTR [rsp+0x8]
  4095ec:	jmp    4095f5 <__swc_fn_0a4ed24b_000123_e4107ade+0x75>
  4095ee:	mov    rax,0xffffffffffffffff
  4095f5:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4095fb:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409601:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409607:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40960d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409613:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409619:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40961f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409628:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409631:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40963a:	add    rsp,0xb8
  409641:	pop    rsi
  409642:	pop    rdi
  409643:	ret
	...

0000000000409650 <__swc_fn_0a4ed24b_000126_9e9697c7>:
  409650:	push   rdi
  409651:	push   rsi
  409652:	sub    rsp,0xb8
  409659:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40965f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409665:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40966b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409671:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409677:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40967d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409683:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40968c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409695:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40969e:	mov    DWORD PTR [rsp+0x8],0x0
  4096a6:	lea    rdi,[rsp+0x8]
  4096ab:	mov    rsi,rcx
  4096ae:	xor    eax,eax
  4096b0:	call   407050 <pthread_key_create@plt>
  4096b5:	test   eax,eax
  4096b7:	jne    4096c2 <__swc_fn_0a4ed24b_000126_9e9697c7+0x72>
  4096b9:	mov    eax,DWORD PTR [rsp+0x8]
  4096bd:	inc    rax
  4096c0:	jmp    4096c4 <__swc_fn_0a4ed24b_000126_9e9697c7+0x74>
  4096c2:	xor    eax,eax
  4096c4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4096ca:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4096d0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4096d6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4096dc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4096e2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4096e8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4096ee:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4096f7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409700:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409709:	add    rsp,0xb8
  409710:	pop    rsi
  409711:	pop    rdi
  409712:	ret
	...

0000000000409720 <__swc_fn_0a4ed24b_000129_bc477461>:
  409720:	push   rdi
  409721:	push   rsi
  409722:	sub    rsp,0xa8
  409729:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40972f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409735:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40973b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409741:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409747:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40974d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409753:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409759:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409762:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40976b:	test   rcx,rcx
  40976e:	setne  al
  409771:	je     40978a <__swc_fn_0a4ed24b_000129_bc477461+0x6a>
  409773:	lea    rax,[rcx-0x1]
  409777:	mov    eax,eax
  409779:	mov    edi,eax
  40977b:	mov    rsi,rdx
  40977e:	xor    eax,eax
  409780:	call   407060 <pthread_setspecific@plt>
  409785:	test   eax,eax
  409787:	sete   al
  40978a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409790:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409796:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40979c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4097a2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4097a8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4097ae:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4097b4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4097ba:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4097c3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4097cc:	add    rsp,0xa8
  4097d3:	pop    rsi
  4097d4:	pop    rdi
  4097d5:	ret
	...

00000000004097e0 <__swc_fn_0a4ed24b_000132_51cc49e7>:
  4097e0:	push   rdi
  4097e1:	push   rsi
  4097e2:	sub    rsp,0xa8
  4097e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4097ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4097f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4097fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409801:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409807:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40980d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409813:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409819:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409822:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40982b:	mov    rax,rdx
  40982e:	mov    QWORD PTR [rsp],0x0
  409836:	mov    edi,0xca
  40983b:	mov    rsi,rcx
  40983e:	mov    edx,0x81
  409843:	mov    eax,eax
  409845:	mov    ecx,eax
  409847:	xor    r8d,r8d
  40984a:	xor    r9d,r9d
  40984d:	xor    eax,eax
  40984f:	call   407070 <syscall@plt>
  409854:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40985a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409860:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409866:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40986c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409872:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409878:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40987e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409884:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40988d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409896:	add    rsp,0xa8
  40989d:	pop    rsi
  40989e:	pop    rdi
  40989f:	ret

00000000004098a0 <__swc_fn_0a4ed24b_000135_db32cc57>:
  4098a0:	sub    rsp,0x8
  4098a4:	call   40cfb0 <__swc_fn_0a4ed24b_000133_807fd51d>
  4098a9:	add    rsp,0x8
  4098ad:	ret
	...

00000000004098b0 <__swc_fn_0a4ed24b_000138_22d6573c>:
  4098b0:	push   rdi
  4098b1:	push   rsi
  4098b2:	sub    rsp,0xc8
  4098b9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4098bf:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4098c5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4098cb:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4098d1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4098d7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4098dd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  4098e6:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  4098ef:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  4098f8:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  409901:	vxorps xmm0,xmm0,xmm0
  409905:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40990b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409911:	mov    rdi,rcx
  409914:	lea    rsi,[rsp+0x8]
  409919:	xor    eax,eax
  40991b:	call   407080 <dladdr@plt>
  409920:	xor    ecx,ecx
  409922:	test   eax,eax
  409924:	je     40992b <__swc_fn_0a4ed24b_000138_22d6573c+0x7b>
  409926:	mov    rcx,QWORD PTR [rsp+0x10]
  40992b:	mov    rax,rcx
  40992e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  409934:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40993a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  409940:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  409946:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40994c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  409952:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40995b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  409964:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40996d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  409976:	add    rsp,0xc8
  40997d:	pop    rsi
  40997e:	pop    rdi
  40997f:	ret

0000000000409980 <__swc_fn_0a4ed24b_000141_5e493395>:
  409980:	push   rbx
  409981:	push   r12
  409983:	push   r13
  409985:	push   rdi
  409986:	push   rsi
  409987:	push   r14
  409989:	push   r15
  40998b:	sub    rsp,0x150
  409992:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40999b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  4099a4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  4099ad:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  4099b6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  4099bf:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4099c8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4099d1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4099da:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  4099e3:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  4099ec:	mov    rbx,rdx
  4099ef:	mov    QWORD PTR [rsp+0x98],rdx
  4099f7:	mov    r12,rcx
  4099fa:	mov    QWORD PTR [rsp+0xa0],rcx
  409a02:	mov    QWORD PTR [rbx],0x0
  409a09:	lea    r13,[rip+0x1d370]        # 426d80 <__swc_bss_base_0a4ed24b+0x2d40>
  409a10:	mov    rcx,r13
  409a13:	call   4098a0 <__swc_fn_0a4ed24b_000135_db32cc57>
  409a18:	mov    rax,QWORD PTR [rip+0x1d369]        # 426d88 <__swc_bss_base_0a4ed24b+0x2d48>
  409a1f:	test   rax,rax
  409a22:	je     409a59 <__swc_fn_0a4ed24b_000141_5e493395+0xd9>
  409a24:	cs nop WORD PTR [rax+rax*1+0x0]
  409a2e:	xchg   ax,ax
  409a30:	cmp    QWORD PTR [rax+0x8],r12
  409a34:	jne    409a51 <__swc_fn_0a4ed24b_000141_5e493395+0xd1>
  409a36:	mov    rcx,QWORD PTR [rax+0x18]
  409a3a:	mov    QWORD PTR [rbx],rcx
  409a3d:	mov    rbx,QWORD PTR [rax+0x10]
  409a41:	mov    rcx,r13
  409a44:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  409a49:	mov    rax,rbx
  409a4c:	jmp    409c3b <__swc_fn_0a4ed24b_000141_5e493395+0x2bb>
  409a51:	mov    rax,QWORD PTR [rax]
  409a54:	test   rax,rax
  409a57:	jne    409a30 <__swc_fn_0a4ed24b_000141_5e493395+0xb0>
  409a59:	vxorps xmm0,xmm0,xmm0
  409a5d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  409a63:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  409a69:	mov    rdi,r12
  409a6c:	lea    rsi,[rsp+0x10]
  409a71:	xor    eax,eax
  409a73:	call   407080 <dladdr@plt>
  409a78:	test   eax,eax
  409a7a:	sete   al
  409a7d:	je     409a8a <__swc_fn_0a4ed24b_000141_5e493395+0x10a>
  409a7f:	mov    rax,QWORD PTR [rsp+0x10]
  409a84:	test   rax,rax
  409a87:	sete   al
  409a8a:	test   al,al
  409a8c:	je     409a9d <__swc_fn_0a4ed24b_000141_5e493395+0x11d>
  409a8e:	mov    rcx,r13
  409a91:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  409a96:	xor    eax,eax
  409a98:	jmp    409c3b <__swc_fn_0a4ed24b_000141_5e493395+0x2bb>
  409a9d:	mov    rdi,QWORD PTR [rsp+0x10]
  409aa2:	mov    esi,0x80000
  409aa7:	xor    eax,eax
  409aa9:	call   407090 <open@plt>
  409aae:	lea    r14,[rsp+0x30]
  409ab3:	mov    DWORD PTR [rsp+0x30],eax
  409ab7:	cmp    DWORD PTR [r14],0x0
  409abb:	jge    409acc <__swc_fn_0a4ed24b_000141_5e493395+0x14c>
  409abd:	mov    rcx,r13
  409ac0:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  409ac5:	xor    eax,eax
  409ac7:	jmp    409c3b <__swc_fn_0a4ed24b_000141_5e493395+0x2bb>
  409acc:	mov    rax,r14
  409acf:	movsxd rdi,DWORD PTR [rax]
  409ad2:	xor    esi,esi
  409ad4:	mov    edx,0x2
  409ad9:	xor    eax,eax
  409adb:	call   4070a0 <lseek@plt>
  409ae0:	mov    r15,rax
  409ae3:	test   rax,rax
  409ae6:	jg     409b01 <__swc_fn_0a4ed24b_000141_5e493395+0x181>
  409ae8:	movsxd rdi,DWORD PTR [r14]
  409aeb:	xor    eax,eax
  409aed:	call   4070b0 <close@plt>
  409af2:	mov    rcx,r13
  409af5:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  409afa:	xor    eax,eax
  409afc:	jmp    409c3b <__swc_fn_0a4ed24b_000141_5e493395+0x2bb>
  409b01:	xor    edi,edi
  409b03:	mov    rsi,r15
  409b06:	mov    edx,0x1
  409b0b:	mov    ecx,0x2
  409b10:	mov    rax,r14
  409b13:	movsxd r8,DWORD PTR [rax]
  409b16:	xor    r9d,r9d
  409b19:	xor    eax,eax
  409b1b:	call   4070c0 <mmap@plt>
  409b20:	mov    rbx,rax
  409b23:	test   rax,rax
  409b26:	sete   al
  409b29:	cmp    rbx,0xffffffffffffffff
  409b2d:	sete   cl
  409b30:	or     al,cl
  409b32:	je     409b4d <__swc_fn_0a4ed24b_000141_5e493395+0x1cd>
  409b34:	movsxd rdi,DWORD PTR [r14]
  409b37:	xor    eax,eax
  409b39:	call   4070b0 <close@plt>
  409b3e:	mov    rcx,r13
  409b41:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  409b46:	xor    eax,eax
  409b48:	jmp    409c3b <__swc_fn_0a4ed24b_000141_5e493395+0x2bb>
  409b4d:	lea    rax,[rsp+0x50]
  409b52:	mov    QWORD PTR [rax],0x0
  409b59:	mov    rcx,rbx
  409b5c:	mov    rdx,r15
  409b5f:	mov    r8,rax
  409b62:	call   410440 <__swc_fn_0a4ed24b_000140_55003b6d>
  409b67:	mov    r12,rax
  409b6a:	test   rax,rax
  409b6d:	jne    409b95 <__swc_fn_0a4ed24b_000141_5e493395+0x215>
  409b6f:	mov    rdi,rbx
  409b72:	mov    rsi,r15
  409b75:	xor    eax,eax
  409b77:	call   407020 <munmap@plt>
  409b7c:	movsxd rdi,DWORD PTR [r14]
  409b7f:	xor    eax,eax
  409b81:	call   4070b0 <close@plt>
  409b86:	mov    rcx,r13
  409b89:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  409b8e:	xor    eax,eax
  409b90:	jmp    409c3b <__swc_fn_0a4ed24b_000141_5e493395+0x2bb>
  409b95:	mov    edi,0x20
  409b9a:	xor    eax,eax
  409b9c:	call   4070d0 <malloc@plt>
  409ba1:	test   rax,rax
  409ba4:	jne    409bc9 <__swc_fn_0a4ed24b_000141_5e493395+0x249>
  409ba6:	mov    rdi,rbx
  409ba9:	mov    rsi,r15
  409bac:	xor    eax,eax
  409bae:	call   407020 <munmap@plt>
  409bb3:	movsxd rdi,DWORD PTR [r14]
  409bb6:	xor    eax,eax
  409bb8:	call   4070b0 <close@plt>
  409bbd:	mov    rcx,r13
  409bc0:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  409bc5:	xor    eax,eax
  409bc7:	jmp    409c3b <__swc_fn_0a4ed24b_000141_5e493395+0x2bb>
  409bc9:	mov    rcx,QWORD PTR [rip+0x1d1b8]        # 426d88 <__swc_bss_base_0a4ed24b+0x2d48>
  409bd0:	mov    QWORD PTR [rsp+0x70],rcx
  409bd5:	mov    rcx,QWORD PTR [rsp+0xa0]
  409bdd:	mov    QWORD PTR [rsp+0x78],rcx
  409be2:	mov    QWORD PTR [rsp+0x80],r12
  409bea:	mov    rcx,QWORD PTR [rsp+0x50]
  409bef:	mov    QWORD PTR [rsp+0x88],rcx
  409bf7:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  409bfd:	vmovups XMMWORD PTR [rax],xmm0
  409c01:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  409c0a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  409c0f:	mov    QWORD PTR [rip+0x1d172],rax        # 426d88 <__swc_bss_base_0a4ed24b+0x2d48>
  409c16:	mov    rax,QWORD PTR [rsp+0x50]
  409c1b:	mov    rbx,QWORD PTR [rsp+0x98]
  409c23:	mov    QWORD PTR [rbx],rax
  409c26:	movsxd rdi,DWORD PTR [r14]
  409c29:	xor    eax,eax
  409c2b:	call   4070b0 <close@plt>
  409c30:	mov    rcx,r13
  409c33:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  409c38:	mov    rax,r12
  409c3b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  409c44:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  409c4d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  409c56:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  409c5f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  409c68:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  409c71:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  409c7a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  409c83:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  409c8c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  409c95:	add    rsp,0x150
  409c9c:	pop    r15
  409c9e:	pop    r14
  409ca0:	pop    rsi
  409ca1:	pop    rdi
  409ca2:	pop    r13
  409ca4:	pop    r12
  409ca6:	pop    rbx
  409ca7:	ret
	...

0000000000409cb0 <__swc_fn_0a4ed24b_000144_c3e86ca0>:
  409cb0:	push   rbx
  409cb1:	sub    rsp,0xe0
  409cb8:	lea    rbx,[rsp+0x8]
  409cbd:	vxorps xmm0,xmm0,xmm0
  409cc1:	vmovups YMMWORD PTR [rbx],ymm0
  409cc5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  409cca:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  409ccf:	vzeroupper
  409cd2:	mov    DWORD PTR [rbx+0x60],0x0
  409cd9:	mov    r8,rbx
  409cdc:	nop    DWORD PTR [rax+0x0]
  409ce0:	mov    r9,rcx
  409ce3:	movabs rcx,0xcccccccccccccccd
  409ced:	mov    rax,r9
  409cf0:	mul    rcx
  409cf3:	mov    r10,rdx
  409cf6:	shr    r10,0x3
  409cfa:	mov    rcx,r10
  409cfd:	imul   rdx,r10,0xa
  409d01:	sub    r9,rdx
  409d04:	mov    rdx,QWORD PTR [rip+0x9835]        # 413540 <__swc_rdata_base_0a4ed24b+0x430>
  409d0b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  409d10:	mov    BYTE PTR [r8],dl
  409d13:	lea    rdx,[r8+0x1]
  409d17:	mov    r8,rdx
  409d1a:	test   r10,r10
  409d1d:	jne    409ce0 <__swc_fn_0a4ed24b_000144_c3e86ca0+0x30>
  409d1f:	mov    BYTE PTR [rdx],0x0
  409d22:	sub    r8,0x1
  409d26:	mov    rax,rbx
  409d29:	cmp    rax,r8
  409d2c:	jae    409d46 <__swc_fn_0a4ed24b_000144_c3e86ca0+0x96>
  409d2e:	xchg   ax,ax
  409d30:	mov    cl,BYTE PTR [r8]
  409d33:	mov    dl,BYTE PTR [rax]
  409d35:	mov    BYTE PTR [r8],dl
  409d38:	sub    r8,0x1
  409d3c:	mov    BYTE PTR [rax],cl
  409d3e:	inc    rax
  409d41:	cmp    rax,r8
  409d44:	jb     409d30 <__swc_fn_0a4ed24b_000144_c3e86ca0+0x80>
  409d46:	xor    eax,eax
  409d48:	test   rbx,rbx
  409d4b:	je     409d6e <__swc_fn_0a4ed24b_000144_c3e86ca0+0xbe>
  409d4d:	mov    rcx,rbx
  409d50:	mov    dl,BYTE PTR [rcx]
  409d52:	test   dl,dl
  409d54:	je     409d6e <__swc_fn_0a4ed24b_000144_c3e86ca0+0xbe>
  409d56:	cs nop WORD PTR [rax+rax*1+0x0]
  409d60:	add    rcx,0x1
  409d64:	add    rax,0x1
  409d68:	mov    dl,BYTE PTR [rcx]
  409d6a:	test   dl,dl
  409d6c:	jne    409d60 <__swc_fn_0a4ed24b_000144_c3e86ca0+0xb0>
  409d6e:	mov    QWORD PTR [rbx+0xa8],rbx
  409d75:	mov    QWORD PTR [rbx+0xb0],rax
  409d7c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  409d84:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  409d8c:	lea    rcx,[rbx+0xb8]
  409d93:	call   40feb0 <__swc_fn_0a4ed24b_000116_3f5cfdef>
  409d98:	add    rsp,0xe0
  409d9f:	pop    rbx
  409da0:	ret
	...

0000000000409db0 <__swc_fn_0a4ed24b_000147_e7bfe29e>:
  409db0:	sub    rsp,0x8
  409db4:	mov    rax,QWORD PTR [rcx+0x8]
  409db8:	mov    r8,QWORD PTR [rdx+0x8]
  409dbc:	cmp    rax,r8
  409dbf:	je     409dc8 <__swc_fn_0a4ed24b_000147_e7bfe29e+0x18>
  409dc1:	xor    eax,eax
  409dc3:	add    rsp,0x8
  409dc7:	ret
  409dc8:	test   rax,rax
  409dcb:	jne    409ddc <__swc_fn_0a4ed24b_000147_e7bfe29e+0x2c>
  409dcd:	test   r8,r8
  409dd0:	jne    409ddc <__swc_fn_0a4ed24b_000147_e7bfe29e+0x2c>
  409dd2:	mov    eax,0x1
  409dd7:	add    rsp,0x8
  409ddb:	ret
  409ddc:	mov    rcx,QWORD PTR [rcx]
  409ddf:	mov    rdx,QWORD PTR [rdx]
  409de2:	test   rcx,rcx
  409de5:	sete   r8b
  409de9:	test   rdx,rdx
  409dec:	sete   r9b
  409df0:	or     r8b,r9b
  409df3:	je     409e00 <__swc_fn_0a4ed24b_000147_e7bfe29e+0x50>
  409df5:	cmp    rcx,rdx
  409df8:	sete   al
  409dfb:	add    rsp,0x8
  409dff:	ret
  409e00:	cmp    rcx,rdx
  409e03:	jne    409e0f <__swc_fn_0a4ed24b_000147_e7bfe29e+0x5f>
  409e05:	mov    eax,0x1
  409e0a:	add    rsp,0x8
  409e0e:	ret
  409e0f:	mov    r8,rax
  409e12:	call   40c6a0 <__swc_fn_0a4ed24b_000106_aba05410>
  409e17:	test   eax,eax
  409e19:	sete   al
  409e1c:	add    rsp,0x8
  409e20:	ret
	...

0000000000409e30 <__swc_fn_0a4ed24b_000150_365b4daf>:
  409e30:	vxorps xmm0,xmm0,xmm0
  409e34:	vmovups XMMWORD PTR [rcx],xmm0
  409e38:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e3d:	vxorps xmm0,xmm0,xmm0
  409e41:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e46:	vmovups xmm0,XMMWORD PTR [rip+0x97aa]        # 4135f8 <__swc_rdata_base_0a4ed24b+0x4e8>
  409e4e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e53:	ret
	...

0000000000409e60 <__swc_fn_0a4ed24b_000153_365b4daf>:
  409e60:	vxorps xmm0,xmm0,xmm0
  409e64:	vmovups XMMWORD PTR [rcx],xmm0
  409e68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e6d:	vxorps xmm0,xmm0,xmm0
  409e71:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e76:	vmovups xmm0,XMMWORD PTR [rip+0x989a]        # 413718 <__swc_rdata_base_0a4ed24b+0x608>
  409e7e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e83:	mov    QWORD PTR [rcx+0x40],0x0
  409e8b:	ret
  409e8c:	add    BYTE PTR [rax],al
	...

0000000000409e90 <__swc_fn_0a4ed24b_000156_9e2052d6>:
  409e90:	push   rbx
  409e91:	sub    rsp,0x70
  409e95:	mov    rax,QWORD PTR [rcx]
  409e98:	mov    rbx,QWORD PTR [rcx+0x8]
  409e9c:	vxorps xmm0,xmm0,xmm0
  409ea0:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  409ea6:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  409eac:	vzeroupper
  409eaf:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  409eb5:	mov    QWORD PTR [rsp+0x48],rdx
  409eba:	mov    QWORD PTR [rsp+0x50],r8
  409ebf:	mov    rcx,rax
  409ec2:	lea    rdx,[rsp+0x8]
  409ec7:	mov    rbx,QWORD PTR [rbx+0x18]
  409ecb:	call   rbx
  409ecd:	add    rsp,0x70
  409ed1:	pop    rbx
  409ed2:	ret
	...

0000000000409ee0 <__swc_fn_0a4ed24b_000159_6861d596>:
  409ee0:	push   rbx
  409ee1:	push   rsi
  409ee2:	push   rdi
  409ee3:	mov    rbx,r8
  409ee6:	mov    rsi,rcx
  409ee9:	mov    rdi,rdx
  409eec:	call   40d3b0 <__swc_fn_0a4ed24b_000157_3495a3ca>
  409ef1:	vmovups xmm0,XMMWORD PTR [rbx]
  409ef5:	vmovups XMMWORD PTR [rsi],xmm0
  409ef9:	mov    QWORD PTR [rsi+0x18],rdi
  409efd:	pop    rdi
  409efe:	pop    rsi
  409eff:	pop    rbx
  409f00:	ret
	...

0000000000409f10 <__swc_fn_0a4ed24b_000162_61e293bf>:
  409f10:	push   rbx
  409f11:	push   rsi
  409f12:	push   rdi
  409f13:	push   r12
  409f15:	push   r13
  409f17:	sub    rsp,0x50
  409f1b:	mov    rbx,rcx
  409f1e:	mov    rsi,rdx
  409f21:	vmovups xmm0,XMMWORD PTR [rip+0x98ff]        # 413828 <__swc_rdata_base_0a4ed24b+0x718>
  409f29:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409f2f:	vmovups xmm0,XMMWORD PTR [rip+0x9901]        # 413838 <__swc_rdata_base_0a4ed24b+0x728>
  409f37:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409f3d:	vxorps xmm0,xmm0,xmm0
  409f41:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409f47:	mov    rcx,rdx
  409f4a:	call   4098b0 <__swc_fn_0a4ed24b_000138_22d6573c>
  409f4f:	mov    rdi,rax
  409f52:	test   rax,rax
  409f55:	jne    409f86 <__swc_fn_0a4ed24b_000162_61e293bf+0x76>
  409f57:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409f5d:	vmovups XMMWORD PTR [rbx],xmm0
  409f61:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409f67:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409f6c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409f72:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409f77:	mov    rax,rbx
  409f7a:	add    rsp,0x50
  409f7e:	pop    r13
  409f80:	pop    r12
  409f82:	pop    rdi
  409f83:	pop    rsi
  409f84:	pop    rbx
  409f85:	ret
  409f86:	mov    rcx,rdi
  409f89:	call   411960 <__swc_fn_0a4ed24b_000161_b553c03d>
  409f8e:	mov    r11,rax
  409f91:	test   rax,rax
  409f94:	je     409f9e <__swc_fn_0a4ed24b_000162_61e293bf+0x8e>
  409f96:	mov    al,BYTE PTR [r11+0x24]
  409f9a:	test   al,al
  409f9c:	jne    409fcd <__swc_fn_0a4ed24b_000162_61e293bf+0xbd>
  409f9e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fa4:	vmovups XMMWORD PTR [rbx],xmm0
  409fa8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fae:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fb3:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fb9:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fbe:	mov    rax,rbx
  409fc1:	add    rsp,0x50
  409fc5:	pop    r13
  409fc7:	pop    r12
  409fc9:	pop    rdi
  409fca:	pop    rsi
  409fcb:	pop    rbx
  409fcc:	ret
  409fcd:	sub    rsi,rdi
  409fd0:	mov    eax,0xffffffff
  409fd5:	cmp    rsi,rax
  409fd8:	jbe    40a009 <__swc_fn_0a4ed24b_000162_61e293bf+0xf9>
  409fda:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fe0:	vmovups XMMWORD PTR [rbx],xmm0
  409fe4:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fea:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fef:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409ff5:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409ffa:	mov    rax,rbx
  409ffd:	add    rsp,0x50
  40a001:	pop    r13
  40a003:	pop    r12
  40a005:	pop    rdi
  40a006:	pop    rsi
  40a007:	pop    rbx
  40a008:	ret
  40a009:	mov    rdi,QWORD PTR [r11+0x10]
  40a00d:	mov    eax,DWORD PTR [r11+0x20]
  40a011:	xor    ecx,ecx
  40a013:	test   rax,rax
  40a016:	jbe    40a168 <__swc_fn_0a4ed24b_000162_61e293bf+0x258>
  40a01c:	nop    DWORD PTR [rax+0x0]
  40a020:	mov    edx,ecx
  40a022:	imul   r12,rdx,0x14
  40a026:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40a02b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40a030:	mov    r9d,esi
  40a033:	cmp    r9,rdx
  40a036:	jb     40a15b <__swc_fn_0a4ed24b_000162_61e293bf+0x24b>
  40a03c:	add    rdx,r8
  40a03f:	mov    r8d,esi
  40a042:	cmp    r8,rdx
  40a045:	jae    40a15b <__swc_fn_0a4ed24b_000162_61e293bf+0x24b>
  40a04b:	lea    rsi,[rsp+0x38]
  40a050:	mov    eax,DWORD PTR [rdi+0xc]
  40a053:	mov    DWORD PTR [rsp+0x38],eax
  40a057:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40a05c:	mov    rcx,rdi
  40a05f:	mov    rdx,QWORD PTR [r11+0x18]
  40a063:	mov    r8,rsi
  40a066:	mov    r8d,DWORD PTR [r8]
  40a069:	mov    r9,rax
  40a06c:	lea    r10,[rsp+0x10]
  40a071:	call   40d400 <__swc_fn_0a4ed24b_000160_dfca9093>
  40a076:	test   al,al
  40a078:	jne    40a0ab <__swc_fn_0a4ed24b_000162_61e293bf+0x19b>
  40a07a:	vmovups xmm0,XMMWORD PTR [rip+0x97d6]        # 413858 <__swc_rdata_base_0a4ed24b+0x748>
  40a082:	vmovups XMMWORD PTR [rbx],xmm0
  40a086:	vmovups xmm0,XMMWORD PTR [rip+0x97da]        # 413868 <__swc_rdata_base_0a4ed24b+0x758>
  40a08e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a093:	vxorps xmm0,xmm0,xmm0
  40a097:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a09c:	mov    rax,rbx
  40a09f:	add    rsp,0x50
  40a0a3:	pop    r13
  40a0a5:	pop    r12
  40a0a7:	pop    rdi
  40a0a8:	pop    rsi
  40a0a9:	pop    rbx
  40a0aa:	ret
  40a0ab:	lea    r13,[rsp+0x3c]
  40a0b0:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40a0b5:	mov    DWORD PTR [rsp+0x3c],eax
  40a0b9:	test   eax,eax
  40a0bb:	je     40a10c <__swc_fn_0a4ed24b_000162_61e293bf+0x1fc>
  40a0bd:	mov    rcx,rdi
  40a0c0:	mov    rdx,QWORD PTR [r11+0x18]
  40a0c4:	mov    r8d,DWORD PTR [rsi]
  40a0c7:	mov    rax,r13
  40a0ca:	mov    r9d,DWORD PTR [rax]
  40a0cd:	lea    r10,[rsp+0x20]
  40a0d2:	call   40d400 <__swc_fn_0a4ed24b_000160_dfca9093>
  40a0d7:	test   al,al
  40a0d9:	jne    40a10c <__swc_fn_0a4ed24b_000162_61e293bf+0x1fc>
  40a0db:	vmovups xmm0,XMMWORD PTR [rip+0x97a5]        # 413888 <__swc_rdata_base_0a4ed24b+0x778>
  40a0e3:	vmovups XMMWORD PTR [rbx],xmm0
  40a0e7:	vmovups xmm0,XMMWORD PTR [rip+0x97a9]        # 413898 <__swc_rdata_base_0a4ed24b+0x788>
  40a0ef:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a0f4:	vxorps xmm0,xmm0,xmm0
  40a0f8:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a0fd:	mov    rax,rbx
  40a100:	add    rsp,0x50
  40a104:	pop    r13
  40a106:	pop    r12
  40a108:	pop    rdi
  40a109:	pop    rsi
  40a10a:	pop    rbx
  40a10b:	ret
  40a10c:	mov    eax,0x1
  40a111:	rex mov BYTE PTR [rsp+0x8],al
  40a116:	cmp    DWORD PTR [r13+0x0],0x0
  40a11b:	je     40a12c <__swc_fn_0a4ed24b_000162_61e293bf+0x21c>
  40a11d:	rex mov BYTE PTR [rsp+0x9],0x1
  40a123:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40a128:	mov    DWORD PTR [rsp+0x30],eax
  40a12c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a132:	vmovups XMMWORD PTR [rbx],xmm0
  40a136:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a13c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a141:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a147:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a14c:	mov    rax,rbx
  40a14f:	add    rsp,0x50
  40a153:	pop    r13
  40a155:	pop    r12
  40a157:	pop    rdi
  40a158:	pop    rsi
  40a159:	pop    rbx
  40a15a:	ret
  40a15b:	add    rcx,0x1
  40a15f:	cmp    rcx,rax
  40a162:	jb     40a020 <__swc_fn_0a4ed24b_000162_61e293bf+0x110>
  40a168:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a16e:	vmovups XMMWORD PTR [rbx],xmm0
  40a172:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a178:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a17d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a183:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a188:	mov    rax,rbx
  40a18b:	add    rsp,0x50
  40a18f:	pop    r13
  40a191:	pop    r12
  40a193:	pop    rdi
  40a194:	pop    rsi
  40a195:	pop    rbx
  40a196:	ret
	...

000000000040a1a0 <__swc_fn_0a4ed24b_000165_56054fe7>:
  40a1a0:	sub    rsp,0x48
  40a1a4:	call   409580 <__swc_fn_0a4ed24b_000123_e4107ade>
  40a1a9:	cmp    rax,0xffffffffffffffff
  40a1ad:	je     40a1b4 <__swc_fn_0a4ed24b_000165_56054fe7+0x14>
  40a1af:	add    rsp,0x48
  40a1b3:	ret
  40a1b4:	lea    rcx,[rip+0x970d]        # 4138c8 <__swc_rdata_base_0a4ed24b+0x7b8>
  40a1bb:	vmovups xmm0,XMMWORD PTR [rip+0x9715]        # 4138d8 <__swc_rdata_base_0a4ed24b+0x7c8>
  40a1c3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a1c9:	vmovups xmm0,XMMWORD PTR [rip+0x9717]        # 4138e8 <__swc_rdata_base_0a4ed24b+0x7d8>
  40a1d1:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a1d7:	vmovups xmm0,XMMWORD PTR [rip+0x9719]        # 4138f8 <__swc_rdata_base_0a4ed24b+0x7e8>
  40a1df:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a1e5:	lea    rdx,[rsp+0x8]
  40a1ea:	mov    QWORD PTR [rsp+0x38],rax
  40a1ef:	call   40c5e0 <__swc_fn_0a4ed24b_000103_0d4cc079>
  40a1f4:	mov    rax,QWORD PTR [rsp+0x38]
  40a1f9:	jmp    40a1af <__swc_fn_0a4ed24b_000165_56054fe7+0xf>
  40a1fb:	add    BYTE PTR [rax],al
  40a1fd:	add    BYTE PTR [rax],al
	...

000000000040a200 <__swc_fn_0a4ed24b_000168_0ad81c51>:
  40a200:	push   rbx
  40a201:	push   rsi
  40a202:	sub    rsp,0x28
  40a206:	mov    rbx,rcx
  40a209:	mov    DWORD PTR [rsp+0x8],0xbf0
  40a211:	mov    ecx,0xbf0
  40a216:	call   40c1d0 <__swc_fn_0a4ed24b_000079_633af784>
  40a21b:	mov    rsi,rax
  40a21e:	test   rax,rax
  40a221:	jne    40a22c <__swc_fn_0a4ed24b_000168_0ad81c51+0x2c>
  40a223:	xor    eax,eax
  40a225:	add    rsp,0x28
  40a229:	pop    rsi
  40a22a:	pop    rbx
  40a22b:	ret
  40a22c:	vxorps xmm0,xmm0,xmm0
  40a230:	xor    eax,eax
  40a232:	cs nop WORD PTR [rax+rax*1+0x0]
  40a23c:	nop    DWORD PTR [rax+0x0]
  40a240:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40a245:	add    rax,0x10
  40a249:	cmp    rax,0xbf0
  40a250:	jne    40a240 <__swc_fn_0a4ed24b_000168_0ad81c51+0x40>
  40a252:	lea    rax,[rbx+0x1]
  40a256:	mov    QWORD PTR [rsi+0x9c0],rax
  40a25d:	mov    rcx,rbx
  40a260:	mov    rdx,rsi
  40a263:	call   40d760 <__swc_fn_0a4ed24b_000166_c370e18e>
  40a268:	test   al,al
  40a26a:	jne    40a27d <__swc_fn_0a4ed24b_000168_0ad81c51+0x7d>
  40a26c:	mov    rcx,rsi
  40a26f:	call   40ee30 <__swc_fn_0a4ed24b_000080_207908fe>
  40a274:	xor    eax,eax
  40a276:	add    rsp,0x28
  40a27a:	pop    rsi
  40a27b:	pop    rbx
  40a27c:	ret
  40a27d:	lea    rcx,[rsp+0x18]
  40a282:	call   40f3b0 <__swc_fn_0a4ed24b_000092_809deff5>
  40a287:	mov    rax,rsi
  40a28a:	add    rsp,0x28
  40a28e:	pop    rsi
  40a28f:	pop    rbx
  40a290:	ret
	...

000000000040a2a0 <__swc_fn_0a4ed24b_000171_8c19aea5>:
  40a2a0:	xor    eax,eax
  40a2a2:	mov    edx,0x1
  40a2a7:	lock cmpxchg QWORD PTR [rcx],rdx
  40a2ac:	test   rax,rax
  40a2af:	jne    40a2b2 <__swc_fn_0a4ed24b_000171_8c19aea5+0x12>
  40a2b1:	ret
  40a2b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2bc:	nop    DWORD PTR [rax+0x0]
  40a2c0:	mov    rax,QWORD PTR [rcx]
  40a2c3:	test   rax,rax
  40a2c6:	je     40a2a0 <__swc_fn_0a4ed24b_000171_8c19aea5>
  40a2c8:	jmp    40a2c0 <__swc_fn_0a4ed24b_000171_8c19aea5+0x20>
  40a2ca:	add    BYTE PTR [rax],al
  40a2cc:	add    BYTE PTR [rax],al
	...

000000000040a2d0 <__swc_fn_0a4ed24b_000174_02e645b4>:
  40a2d0:	push   rsi
  40a2d1:	push   rdi
  40a2d2:	sub    rsp,0x38
  40a2d6:	mov    rsi,rcx
  40a2d9:	call   40d770 <__swc_fn_0a4ed24b_000169_4694b8ad>
  40a2de:	mov    rdi,rax
  40a2e1:	call   40cf00 <__swc_fn_0a4ed24b_000130_375c7357>
  40a2e6:	mov    r8,rax
  40a2e9:	mov    rcx,rdi
  40a2ec:	call   40a2a0 <__swc_fn_0a4ed24b_000171_8c19aea5>
  40a2f1:	mov    rax,QWORD PTR [rdi+0x8]
  40a2f5:	test   rax,rax
  40a2f8:	je     40a335 <__swc_fn_0a4ed24b_000174_02e645b4+0x65>
  40a2fa:	nop    WORD PTR [rax+rax*1+0x0]
  40a300:	cmp    rax,rsi
  40a303:	je     40a335 <__swc_fn_0a4ed24b_000174_02e645b4+0x65>
  40a305:	mov    r9,QWORD PTR [rax]
  40a308:	cmp    QWORD PTR [rax+0x20],r8
  40a30c:	jne    40a32d <__swc_fn_0a4ed24b_000174_02e645b4+0x5d>
  40a30e:	mov    rcx,rdi
  40a311:	mov    rdx,rax
  40a314:	mov    QWORD PTR [rsp+0x28],r8
  40a319:	mov    QWORD PTR [rsp+0x30],r9
  40a31e:	call   411d80 <__swc_fn_0a4ed24b_000173_e17a224b>
  40a323:	mov    r8,QWORD PTR [rsp+0x28]
  40a328:	mov    r9,QWORD PTR [rsp+0x30]
  40a32d:	mov    rax,r9
  40a330:	test   r9,r9
  40a333:	jne    40a300 <__swc_fn_0a4ed24b_000174_02e645b4+0x30>
  40a335:	xor    eax,eax
  40a337:	mov    QWORD PTR [rdi],rax
  40a33a:	add    rsp,0x38
  40a33e:	pop    rdi
  40a33f:	pop    rsi
  40a340:	ret
	...

000000000040a350 <__swc_fn_0a4ed24b_000177_3634f827>:
  40a350:	sub    rsp,0x168
  40a357:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40a360:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40a369:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40a372:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40a37b:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40a384:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40a38d:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40a396:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40a39f:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40a3a8:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40a3b1:	vmovups xmm6,xmm5
  40a3b5:	vmovups xmm7,xmm0
  40a3b9:	vmovups xmm8,xmm1
  40a3bd:	vmovups xmm9,xmm2
  40a3c1:	vmovups xmm10,xmm3
  40a3c5:	vmovups xmm11,xmm4
  40a3c9:	vmovsd xmm0,QWORD PTR [rip+0x969f]        # 413a70 <__swc_rdata_base_0a4ed24b+0x960>
  40a3d1:	vmovsd QWORD PTR [rsp],xmm0
  40a3d6:	vmovups xmm0,xmm7
  40a3da:	call   411e00 <__swc_fn_0a4ed24b_000176_0d61c738>
  40a3df:	mov    eax,DWORD PTR [rip+0x17c2b]        # 422010 <__swc_data_base_0a4ed24b+0x10>
  40a3e5:	test   eax,eax
  40a3e7:	jge    40a41e <__swc_fn_0a4ed24b_000177_3634f827+0xce>
  40a3e9:	vmovsd xmm0,QWORD PTR [rip+0x9688]        # 413a79 <__swc_rdata_base_0a4ed24b+0x969>
  40a3f1:	vmovsd QWORD PTR [rip+0x1c9bf],xmm0        # 426db8 <__swc_bss_base_0a4ed24b+0x2d78>
  40a3f9:	vmovsd xmm0,QWORD PTR [rip+0x9681]        # 413a82 <__swc_rdata_base_0a4ed24b+0x972>
  40a401:	vmovsd QWORD PTR [rip+0x1c9b7],xmm0        # 426dc0 <__swc_bss_base_0a4ed24b+0x2d80>
  40a409:	vmovsd xmm0,QWORD PTR [rip+0x967a]        # 413a8b <__swc_rdata_base_0a4ed24b+0x97b>
  40a411:	vmovsd QWORD PTR [rip+0x1c9af],xmm0        # 426dc8 <__swc_bss_base_0a4ed24b+0x2d88>
  40a419:	jmp    40a610 <__swc_fn_0a4ed24b_000177_3634f827+0x2c0>
  40a41e:	vmovsd xmm0,QWORD PTR [rip+0x1c98a]        # 426db0 <__swc_bss_base_0a4ed24b+0x2d70>
  40a426:	movsxd rdx,eax
  40a429:	vfmadd231sd xmm7,xmm10,xmm0
  40a42e:	vfmadd231sd xmm8,xmm11,xmm0
  40a433:	vfmadd231sd xmm9,xmm6,xmm0
  40a438:	vmovsd QWORD PTR [rsp+0xb8],xmm9
  40a441:	vmovsd xmm12,QWORD PTR [rip+0x94e3]        # 41392c <__swc_rdata_base_0a4ed24b+0x81c>
  40a449:	lea    rax,[rip+0x9520]        # 413970 <__swc_rdata_base_0a4ed24b+0x860>
  40a450:	vdivsd xmm0,xmm12,QWORD PTR [rax+rdx*8]
  40a455:	lea    rax,[rip+0x9534]        # 413990 <__swc_rdata_base_0a4ed24b+0x880>
  40a45c:	vsubsd xmm1,xmm7,QWORD PTR [rax+rdx*8]
  40a461:	vmulsd xmm13,xmm1,xmm0
  40a465:	lea    rax,[rip+0x9544]        # 4139b0 <__swc_rdata_base_0a4ed24b+0x8a0>
  40a46c:	vsubsd xmm1,xmm8,QWORD PTR [rax+rdx*8]
  40a471:	vmulsd xmm14,xmm1,xmm0
  40a475:	lea    rax,[rip+0x9554]        # 4139d0 <__swc_rdata_base_0a4ed24b+0x8c0>
  40a47c:	vsubsd xmm1,xmm9,QWORD PTR [rax+rdx*8]
  40a481:	vmulsd xmm15,xmm1,xmm0
  40a485:	vmovsd xmm0,QWORD PTR [rip+0x9607]        # 413a94 <__swc_rdata_base_0a4ed24b+0x984>
  40a48d:	vsubsd xmm3,xmm0,xmm7
  40a491:	vsubsd xmm4,xmm0,xmm8
  40a496:	vmovsd xmm0,QWORD PTR [rip+0x95ff]        # 413a9d <__swc_rdata_base_0a4ed24b+0x98d>
  40a49e:	vsubsd xmm5,xmm0,xmm9
  40a4a3:	vmulsd xmm0,xmm3,xmm3
  40a4a7:	vfmadd231sd xmm0,xmm4,xmm4
  40a4ac:	vfmadd231sd xmm0,xmm5,xmm5
  40a4b1:	vsqrtsd xmm0,xmm0,xmm0
  40a4b5:	vdivsd xmm0,xmm12,xmm0
  40a4b9:	vmulsd xmm3,xmm3,xmm0
  40a4bd:	vmulsd xmm4,xmm4,xmm0
  40a4c1:	vmulsd xmm5,xmm5,xmm0
  40a4c5:	vmulsd xmm0,xmm13,xmm3
  40a4c9:	vfmadd231sd xmm0,xmm14,xmm4
  40a4ce:	vmulsd xmm1,xmm15,xmm5
  40a4d2:	vaddsd xmm2,xmm0,xmm1
  40a4d6:	vxorpd xmm0,xmm0,xmm0
  40a4da:	vcomisd xmm0,xmm2
  40a4de:	jbe    40a4e7 <__swc_fn_0a4ed24b_000177_3634f827+0x197>
  40a4e0:	vxorpd xmm12,xmm12,xmm12
  40a4e5:	jmp    40a523 <__swc_fn_0a4ed24b_000177_3634f827+0x1d3>
  40a4e7:	vmovsd xmm0,QWORD PTR [rip+0x95b7]        # 413aa6 <__swc_rdata_base_0a4ed24b+0x996>
  40a4ef:	vmovsd QWORD PTR [rsp],xmm0
  40a4f4:	vmovups xmm0,xmm7
  40a4f8:	vmovups xmm1,xmm8
  40a4fd:	vmovsd QWORD PTR [rsp+0xc0],xmm2
  40a506:	vmovups xmm12,xmm2
  40a50a:	vmovups xmm2,xmm9
  40a50f:	call   411e00 <__swc_fn_0a4ed24b_000176_0d61c738>
  40a514:	mov    eax,DWORD PTR [rip+0x17af6]        # 422010 <__swc_data_base_0a4ed24b+0x10>
  40a51a:	test   eax,eax
  40a51c:	jl     40a523 <__swc_fn_0a4ed24b_000177_3634f827+0x1d3>
  40a51e:	vxorpd xmm12,xmm12,xmm12
  40a523:	vmulsd xmm0,xmm12,QWORD PTR [rip+0x9584]        # 413aaf <__swc_rdata_base_0a4ed24b+0x99f>
  40a52b:	vaddsd xmm0,xmm0,QWORD PTR [rip+0x9558]        # 413a8b <__swc_rdata_base_0a4ed24b+0x97b>
  40a533:	lea    rax,[rip+0x94b6]        # 4139f0 <__swc_rdata_base_0a4ed24b+0x8e0>
  40a53a:	vmulsd xmm9,xmm0,QWORD PTR [rax+rdx*8]
  40a53f:	lea    rax,[rip+0x94ca]        # 413a10 <__swc_rdata_base_0a4ed24b+0x900>
  40a546:	vmulsd xmm12,xmm0,QWORD PTR [rax+rdx*8]
  40a54b:	lea    rax,[rip+0x94de]        # 413a30 <__swc_rdata_base_0a4ed24b+0x920>
  40a552:	vmulsd xmm5,xmm0,QWORD PTR [rax+rdx*8]
  40a557:	lea    rax,[rip+0x94f2]        # 413a50 <__swc_rdata_base_0a4ed24b+0x940>
  40a55e:	vmovq  xmm4,QWORD PTR [rax+rdx*8]
  40a563:	cmp    ecx,0x2
  40a566:	jl     40a571 <__swc_fn_0a4ed24b_000177_3634f827+0x221>
  40a568:	vmovups xmm8,xmm5
  40a56c:	jmp    40a5f8 <__swc_fn_0a4ed24b_000177_3634f827+0x2a8>
  40a571:	vmulsd xmm0,xmm10,xmm13
  40a576:	vfmadd231sd xmm0,xmm11,xmm14
  40a57b:	vfmadd231sd xmm0,xmm6,xmm15
  40a580:	vaddsd xmm0,xmm0,xmm0
  40a584:	vmulsd xmm1,xmm0,xmm13
  40a589:	vsubsd xmm3,xmm10,xmm1
  40a58d:	vmulsd xmm1,xmm0,xmm14
  40a592:	vsubsd xmm10,xmm11,xmm1
  40a596:	vfnmadd231sd xmm6,xmm0,xmm15
  40a59b:	vmovups xmm0,xmm7
  40a59f:	vmovups xmm1,xmm8
  40a5a4:	vmovsd xmm2,QWORD PTR [rsp+0xb8]
  40a5ad:	vmovups xmm7,xmm4
  40a5b1:	vmovups xmm4,xmm10
  40a5b6:	vmovups xmm8,xmm5
  40a5ba:	vmovups xmm5,xmm6
  40a5be:	inc    ecx
  40a5c0:	call   40a350 <__swc_fn_0a4ed24b_000177_3634f827>
  40a5c5:	vmovsd xmm0,QWORD PTR [rip+0x935f]        # 41392c <__swc_rdata_base_0a4ed24b+0x81c>
  40a5cd:	vsubsd xmm0,xmm0,xmm7
  40a5d1:	vmulsd xmm2,xmm7,QWORD PTR [rip+0x1c7df]        # 426db8 <__swc_bss_base_0a4ed24b+0x2d78>
  40a5d9:	vfmadd213sd xmm9,xmm0,xmm2
  40a5de:	vmulsd xmm2,xmm7,QWORD PTR [rip+0x1c7da]        # 426dc0 <__swc_bss_base_0a4ed24b+0x2d80>
  40a5e6:	vfmadd213sd xmm12,xmm0,xmm2
  40a5eb:	vmulsd xmm1,xmm7,QWORD PTR [rip+0x1c7d5]        # 426dc8 <__swc_bss_base_0a4ed24b+0x2d88>
  40a5f3:	vfmadd213sd xmm8,xmm0,xmm1
  40a5f8:	vmovsd QWORD PTR [rip+0x1c7b8],xmm9        # 426db8 <__swc_bss_base_0a4ed24b+0x2d78>
  40a600:	vmovsd QWORD PTR [rip+0x1c7b8],xmm12        # 426dc0 <__swc_bss_base_0a4ed24b+0x2d80>
  40a608:	vmovsd QWORD PTR [rip+0x1c7b8],xmm8        # 426dc8 <__swc_bss_base_0a4ed24b+0x2d88>
  40a610:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40a619:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40a622:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40a62b:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40a634:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  40a63d:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40a646:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  40a64f:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40a658:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  40a661:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  40a66a:	add    rsp,0x168
  40a671:	ret
	...

000000000040a680 <__swc_fn_0a4ed24b_000001_0e26756e>:
  40a680:	vxorps xmm0,xmm0,xmm0
  40a684:	xor    eax,eax
  40a686:	cs nop WORD PTR [rax+rax*1+0x0]
  40a690:	cs nop WORD PTR [rax+rax*1+0x0]
  40a69a:	nop    WORD PTR [rax+rax*1+0x0]
  40a6a0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a6a5:	add    rax,0x10
  40a6a9:	cmp    rax,0x2080
  40a6b0:	jne    40a6a0 <__swc_fn_0a4ed24b_000001_0e26756e+0x20>
  40a6b2:	ret
	...

000000000040a6c0 <__swc_fn_0a4ed24b_000004_3deb8b54>:
  40a6c0:	push   rsi
  40a6c1:	push   rdi
  40a6c2:	push   r12
  40a6c4:	push   r13
  40a6c6:	push   r14
  40a6c8:	mov    rsi,rcx
  40a6cb:	mov    edi,r10d
  40a6ce:	mov    r12,rcx
  40a6d1:	mov    r13,r9
  40a6d4:	mov    ecx,DWORD PTR [rdx+0x28]
  40a6d7:	shlx   r14d,r8d,ecx
  40a6dc:	mov    rcx,rdx
  40a6df:	mov    edx,r8d
  40a6e2:	call   40dd00 <__swc_fn_0a4ed24b_000011_71c91685>
  40a6e7:	mov    rcx,rax
  40a6ea:	mov    eax,DWORD PTR [r12+0x3c]
  40a6ef:	xor    edx,edx
  40a6f1:	div    rdi
  40a6f4:	vxorps xmm0,xmm0,xmm0
  40a6f8:	vmovdqu XMMWORD PTR [rsi],xmm0
  40a6fc:	mov    QWORD PTR [r12+0x60],0x0
  40a705:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40a70a:	mov    QWORD PTR [r12+0x10],rcx
  40a70f:	imul   rax,rdi
  40a713:	lea    rdx,[rcx+rax*1]
  40a717:	mov    QWORD PTR [r12+0x18],rdx
  40a71c:	mov    QWORD PTR [r12+0x20],rcx
  40a721:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40a726:	mov    DWORD PTR [r12+0x28],0x0
  40a72f:	mov    DWORD PTR [r12+0x68],0x0
  40a738:	mov    BYTE PTR [r12+0x39],r13b
  40a73d:	mov    BYTE PTR [r12+0x3a],r14b
  40a742:	mov    BYTE PTR [r12+0x3b],0x1
  40a748:	mov    DWORD PTR [r12+0x6c],0x0
  40a751:	mov    rcx,r12
  40a754:	mov    edx,edi
  40a756:	call   40dc60 <__swc_fn_0a4ed24b_000005_6a556171>
  40a75b:	pop    r14
  40a75d:	pop    r13
  40a75f:	pop    r12
  40a761:	pop    rdi
  40a762:	pop    rsi
  40a763:	ret
	...

000000000040a770 <__swc_fn_0a4ed24b_000007_a7bfb091>:
  40a770:	mov    r8d,0x1
  40a776:	xor    eax,eax
  40a778:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40a77e:	test   eax,eax
  40a780:	jne    40a770 <__swc_fn_0a4ed24b_000007_a7bfb091>
  40a782:	ret
	...

000000000040a790 <__swc_fn_0a4ed24b_000010_0569f799>:
  40a790:	lea    r8,[rcx+0x60]
  40a794:	mov    rax,QWORD PTR [r8]
  40a797:	mov    r9,rax
  40a79a:	nop    WORD PTR [rax+rax*1+0x0]
  40a7a0:	mov    QWORD PTR [rdx],r9
  40a7a3:	mov    rax,r9
  40a7a6:	lock cmpxchg QWORD PTR [r8],rdx
  40a7ab:	cmp    rax,r9
  40a7ae:	jne    40a817 <__swc_fn_0a4ed24b_000010_0569f799+0x87>
  40a7b0:	mov    eax,DWORD PTR [rcx+0x6c]
  40a7b3:	test   eax,eax
  40a7b5:	je     40a816 <__swc_fn_0a4ed24b_000010_0569f799+0x86>
  40a7b7:	lea    rdx,[rcx+0x70]
  40a7bb:	mov    r9d,0x1
  40a7c1:	xor    eax,eax
  40a7c3:	lock cmpxchg DWORD PTR [rdx],r9d
  40a7c8:	test   eax,eax
  40a7ca:	jne    40a816 <__swc_fn_0a4ed24b_000010_0569f799+0x86>
  40a7cc:	mov    rax,rcx
  40a7cf:	and    rax,0xffffffffffc00000
  40a7d6:	mov    rax,QWORD PTR [rax+0x8]
  40a7da:	test   rax,rax
  40a7dd:	jne    40a7e5 <__swc_fn_0a4ed24b_000010_0569f799+0x55>
  40a7df:	xor    eax,eax
  40a7e1:	xchg   DWORD PTR [rdx],eax
  40a7e3:	jmp    40a816 <__swc_fn_0a4ed24b_000010_0569f799+0x86>
  40a7e5:	lea    rdx,[rax+0x2a80]
  40a7ec:	mov    rax,QWORD PTR [rdx]
  40a7ef:	mov    r8,rax
  40a7f2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a7fc:	nop    DWORD PTR [rax+0x0]
  40a800:	mov    QWORD PTR [rcx+0x78],r8
  40a804:	mov    rax,r8
  40a807:	lock cmpxchg QWORD PTR [rdx],rcx
  40a80c:	cmp    rax,r8
  40a80f:	je     40a816 <__swc_fn_0a4ed24b_000010_0569f799+0x86>
  40a811:	mov    r8,rax
  40a814:	jmp    40a800 <__swc_fn_0a4ed24b_000010_0569f799+0x70>
  40a816:	ret
  40a817:	mov    r9,rax
  40a81a:	jmp    40a7a0 <__swc_fn_0a4ed24b_000010_0569f799+0x10>
	...

000000000040a820 <__swc_fn_0a4ed24b_000013_7b85dbab>:
  40a820:	push   rsi
  40a821:	push   rdi
  40a822:	push   r12
  40a824:	push   r13
  40a826:	push   r14
  40a828:	push   r15
  40a82a:	push   rbx
  40a82b:	sub    rsp,0x30
  40a82f:	mov    QWORD PTR [rsp+0x18],r8
  40a834:	mov    rsi,rcx
  40a837:	mov    rdi,rdx
  40a83a:	mov    rdx,QWORD PTR [rsi+0x40]
  40a83e:	xchg   ax,ax
  40a840:	mov    rax,rdx
  40a843:	not    rax
  40a846:	and    rax,QWORD PTR [rsi+0x20]
  40a84a:	test   rax,rax
  40a84d:	jne    40a861 <__swc_fn_0a4ed24b_000013_7b85dbab+0x41>
  40a84f:	xor    eax,eax
  40a851:	add    rsp,0x30
  40a855:	pop    rbx
  40a856:	pop    r15
  40a858:	pop    r14
  40a85a:	pop    r13
  40a85c:	pop    r12
  40a85e:	pop    rdi
  40a85f:	pop    rsi
  40a860:	ret
  40a861:	xor    ecx,ecx
  40a863:	tzcnt  rcx,rax
  40a868:	lea    r12,[rsp+0x8]
  40a86d:	mov    DWORD PTR [rsp+0x8],ecx
  40a871:	mov    r13d,0x1
  40a877:	shl    r13,cl
  40a87a:	mov    rcx,rdx
  40a87d:	or     rcx,r13
  40a880:	mov    rax,rdx
  40a883:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40a889:	cmp    rax,rdx
  40a88c:	je     40a893 <__swc_fn_0a4ed24b_000013_7b85dbab+0x73>
  40a88e:	mov    rdx,rax
  40a891:	jmp    40a840 <__swc_fn_0a4ed24b_000013_7b85dbab+0x20>
  40a893:	mov    eax,DWORD PTR [r12]
  40a897:	shl    rax,0x4
  40a89b:	lea    r14,[rsi+rax*8+0x80]
  40a8a3:	mov    rcx,rsi
  40a8a6:	mov    rax,r12
  40a8a9:	mov    edx,DWORD PTR [rax]
  40a8ab:	call   40dd00 <__swc_fn_0a4ed24b_000011_71c91685>
  40a8b0:	mov    r15,rax
  40a8b3:	mov    rcx,rsi
  40a8b6:	mov    rdx,r13
  40a8b9:	call   40de60 <__swc_fn_0a4ed24b_000017_f003fc47>
  40a8be:	test   al,al
  40a8c0:	je     40a8f8 <__swc_fn_0a4ed24b_000013_7b85dbab+0xd8>
  40a8c2:	mov    ecx,DWORD PTR [r14+0x3c]
  40a8c6:	lea    rdx,[rip+0x1978b]        # 424058 <__swc_bss_base_0a4ed24b+0x18>
  40a8cd:	mov    r8,QWORD PTR [rip+0x19784]        # 424058 <__swc_bss_base_0a4ed24b+0x18>
  40a8d4:	cs nop WORD PTR [rax+rax*1+0x0]
  40a8de:	xchg   ax,ax
  40a8e0:	mov    r9,r8
  40a8e3:	sub    r9,rcx
  40a8e6:	mov    rax,r8
  40a8e9:	lock cmpxchg QWORD PTR [rdx],r9
  40a8ee:	cmp    rax,r8
  40a8f1:	je     40a959 <__swc_fn_0a4ed24b_000013_7b85dbab+0x139>
  40a8f3:	mov    r8,rax
  40a8f6:	jmp    40a8e0 <__swc_fn_0a4ed24b_000013_7b85dbab+0xc0>
  40a8f8:	mov    rcx,rsi
  40a8fb:	mov    rax,r12
  40a8fe:	mov    edx,DWORD PTR [rax]
  40a900:	call   407450 <__swc_fn_0a4ed24b_000012_be38a1a2>
  40a905:	mov    rcx,r15
  40a908:	and    rcx,0xffffffffffff0000
  40a90f:	lea    rcx,[rcx+0x10000]
  40a916:	mov    rbx,rax
  40a919:	cmp    rax,rcx
  40a91c:	cmova  rbx,rcx
  40a920:	mov    rax,rbx
  40a923:	sub    rax,r15
  40a926:	mov    rcx,r15
  40a929:	mov    rdx,rax
  40a92c:	call   4072a0 <__swc_fn_0a4ed24b_000003_81215399>
  40a931:	test   al,al
  40a933:	jne    40a952 <__swc_fn_0a4ed24b_000013_7b85dbab+0x132>
  40a935:	mov    rcx,rsi
  40a938:	mov    rdx,r13
  40a93b:	call   407600 <__swc_fn_0a4ed24b_000018_77ece227>
  40a940:	xor    eax,eax
  40a942:	add    rsp,0x30
  40a946:	pop    rbx
  40a947:	pop    r15
  40a949:	pop    r14
  40a94b:	pop    r13
  40a94d:	pop    r12
  40a94f:	pop    rdi
  40a950:	pop    rsi
  40a951:	ret
  40a952:	sub    rbx,r15
  40a955:	mov    DWORD PTR [r14+0x3c],ebx
  40a959:	mov    rcx,r14
  40a95c:	mov    rdx,rsi
  40a95f:	mov    r8d,DWORD PTR [r12]
  40a963:	mov    r9d,edi
  40a966:	mov    rbx,QWORD PTR [rsp+0x18]
  40a96b:	mov    r10d,ebx
  40a96e:	call   40a6c0 <__swc_fn_0a4ed24b_000004_3deb8b54>
  40a973:	mov    rax,r14
  40a976:	add    rsp,0x30
  40a97a:	pop    rbx
  40a97b:	pop    r15
  40a97d:	pop    r14
  40a97f:	pop    r13
  40a981:	pop    r12
  40a983:	pop    rdi
  40a984:	pop    rsi
  40a985:	ret
	...

000000000040a990 <__swc_fn_0a4ed24b_000016_a0b588d0>:
  40a990:	mov    r8,QWORD PTR [rcx+0x48]
  40a994:	cs nop WORD PTR [rax+rax*1+0x0]
  40a99e:	xchg   ax,ax
  40a9a0:	mov    r9,r8
  40a9a3:	or     r9,rdx
  40a9a6:	mov    rax,r8
  40a9a9:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40a9af:	cmp    rax,r8
  40a9b2:	jne    40a9b5 <__swc_fn_0a4ed24b_000016_a0b588d0+0x25>
  40a9b4:	ret
  40a9b5:	mov    r8,rax
  40a9b8:	jmp    40a9a0 <__swc_fn_0a4ed24b_000016_a0b588d0+0x10>
  40a9ba:	add    BYTE PTR [rax],al
  40a9bc:	add    BYTE PTR [rax],al
	...

000000000040a9c0 <__swc_fn_0a4ed24b_000019_447bb610>:
  40a9c0:	push   rsi
  40a9c1:	push   rdi
  40a9c2:	push   r12
  40a9c4:	mov    rsi,rcx
  40a9c7:	xor    edi,edi
  40a9c9:	lea    r12,[rip+0x19698]        # 424068 <__swc_bss_base_0a4ed24b+0x28>
  40a9d0:	mov    eax,DWORD PTR [r12]
  40a9d4:	xor    ecx,ecx
  40a9d6:	test   rax,rax
  40a9d9:	jbe    40aa14 <__swc_fn_0a4ed24b_000019_447bb610+0x54>
  40a9db:	nop    DWORD PTR [rax+rax*1+0x0]
  40a9e0:	lea    rdx,[rip+0x19689]        # 424070 <__swc_bss_base_0a4ed24b+0x30>
  40a9e7:	mov    r8d,ecx
  40a9ea:	lea    r8,[r8+r8*2]
  40a9ee:	lea    r8,[rdx+r8*8]
  40a9f2:	mov    rdx,QWORD PTR [r8+0x10]
  40a9f6:	add    rdx,0x400000
  40a9fd:	cmp    rdx,0x40000000
  40aa04:	ja     40aa0b <__swc_fn_0a4ed24b_000019_447bb610+0x4b>
  40aa06:	mov    rdi,r8
  40aa09:	jmp    40aa14 <__swc_fn_0a4ed24b_000019_447bb610+0x54>
  40aa0b:	add    rcx,0x1
  40aa0f:	cmp    rcx,rax
  40aa12:	jb     40a9e0 <__swc_fn_0a4ed24b_000019_447bb610+0x20>
  40aa14:	test   rdi,rdi
  40aa17:	jne    40aaa3 <__swc_fn_0a4ed24b_000019_447bb610+0xe3>
  40aa1d:	cmp    DWORD PTR [r12],0x10
  40aa22:	jae    40aa8b <__swc_fn_0a4ed24b_000019_447bb610+0xcb>
  40aa24:	mov    ecx,0x40400000
  40aa29:	call   40dc20 <__swc_fn_0a4ed24b_000002_102336c4>
  40aa2e:	test   rax,rax
  40aa31:	je     40aa8b <__swc_fn_0a4ed24b_000019_447bb610+0xcb>
  40aa33:	lea    rcx,[rip+0x19636]        # 424070 <__swc_bss_base_0a4ed24b+0x30>
  40aa3a:	mov    edx,DWORD PTR [r12]
  40aa3e:	lea    rdx,[rdx+rdx*2]
  40aa42:	lea    rdx,[rcx+rdx*8]
  40aa46:	mov    QWORD PTR [rdx],rax
  40aa49:	lea    rax,[rax+0x3fffff]
  40aa50:	and    rax,0xffffffffffc00000
  40aa57:	mov    QWORD PTR [rdx+0x8],rax
  40aa5b:	mov    QWORD PTR [rdx+0x10],0x0
  40aa63:	mov    edx,DWORD PTR [rip+0x195ff]        # 424068 <__swc_bss_base_0a4ed24b+0x28>
  40aa69:	nop    DWORD PTR [rax+0x0]
  40aa70:	lea    r9d,[rdx+0x1]
  40aa74:	mov    rax,rdx
  40aa77:	lock cmpxchg DWORD PTR [r12],r9d
  40aa7d:	mov    r8d,eax
  40aa80:	cmp    eax,edx
  40aa82:	je     40aa92 <__swc_fn_0a4ed24b_000019_447bb610+0xd2>
  40aa84:	mov    rdx,r8
  40aa87:	jmp    40aa70 <__swc_fn_0a4ed24b_000019_447bb610+0xb0>
  40aa89:	jmp    40aa92 <__swc_fn_0a4ed24b_000019_447bb610+0xd2>
  40aa8b:	xor    eax,eax
  40aa8d:	pop    r12
  40aa8f:	pop    rdi
  40aa90:	pop    rsi
  40aa91:	ret
  40aa92:	mov    eax,DWORD PTR [rip+0x195d0]        # 424068 <__swc_bss_base_0a4ed24b+0x28>
  40aa98:	sub    eax,0x1
  40aa9b:	lea    rdi,[rax+rax*2]
  40aa9f:	lea    rdi,[rcx+rdi*8]
  40aaa3:	mov    r12,QWORD PTR [rdi+0x8]
  40aaa7:	add    r12,QWORD PTR [rdi+0x10]
  40aaab:	mov    rcx,r12
  40aaae:	mov    edx,0x3000
  40aab3:	call   4072a0 <__swc_fn_0a4ed24b_000003_81215399>
  40aab8:	test   al,al
  40aaba:	jne    40aac3 <__swc_fn_0a4ed24b_000019_447bb610+0x103>
  40aabc:	xor    eax,eax
  40aabe:	pop    r12
  40aac0:	pop    rdi
  40aac1:	pop    rsi
  40aac2:	ret
  40aac3:	vxorps xmm0,xmm0,xmm0
  40aac7:	xor    eax,eax
  40aac9:	cs nop WORD PTR [rax+rax*1+0x0]
  40aad3:	cs nop WORD PTR [rax+rax*1+0x0]
  40aadd:	nop    DWORD PTR [rax]
  40aae0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40aae6:	add    rax,0x10
  40aaea:	cmp    rax,0x3000
  40aaf1:	jne    40aae0 <__swc_fn_0a4ed24b_000019_447bb610+0x120>
  40aaf3:	mov    DWORD PTR [r12+0x28],esi
  40aaf8:	mov    eax,0x40
  40aafd:	mov    ecx,esi
  40aaff:	shr    eax,cl
  40ab01:	mov    DWORD PTR [r12+0x2c],eax
  40ab06:	cmp    DWORD PTR [r12+0x2c],0x40
  40ab0c:	jb     40ab17 <__swc_fn_0a4ed24b_000019_447bb610+0x157>
  40ab0e:	mov    rax,0xffffffffffffffff
  40ab15:	jmp    40ab27 <__swc_fn_0a4ed24b_000019_447bb610+0x167>
  40ab17:	mov    eax,0x1
  40ab1c:	mov    ecx,DWORD PTR [r12+0x2c]
  40ab21:	shl    rax,cl
  40ab24:	dec    rax
  40ab27:	mov    QWORD PTR [r12+0x20],rax
  40ab2c:	mov    DWORD PTR [r12],0x4e540001
  40ab34:	mov    DWORD PTR [r12+0x4],0x53474d45
  40ab3d:	add    QWORD PTR [rdi+0x10],0x400000
  40ab45:	mov    rax,r12
  40ab48:	pop    r12
  40ab4a:	pop    rdi
  40ab4b:	pop    rsi
  40ab4c:	ret
  40ab4d:	add    BYTE PTR [rax],al
	...

000000000040ab50 <__swc_fn_0a4ed24b_000022_53fc00d2>:
  40ab50:	mov    eax,0x1
  40ab55:	mov    edx,DWORD PTR [rip+0x1950d]        # 424068 <__swc_bss_base_0a4ed24b+0x28>
  40ab5b:	cmp    eax,edx
  40ab5d:	jae    40abab <__swc_fn_0a4ed24b_000022_53fc00d2+0x5b>
  40ab5f:	nop
  40ab60:	lea    r8,[rip+0x19509]        # 424070 <__swc_bss_base_0a4ed24b+0x30>
  40ab67:	lea    r9,[rax+rax*2]
  40ab6b:	lea    r9,[r8+r9*8]
  40ab6f:	mov    r8,rcx
  40ab72:	sub    r8,QWORD PTR [r9+0x8]
  40ab76:	mov    r9,QWORD PTR [r9+0x10]
  40ab7a:	cmp    r8,r9
  40ab7d:	jae    40aba5 <__swc_fn_0a4ed24b_000022_53fc00d2+0x55>
  40ab7f:	mov    rax,rcx
  40ab82:	and    rax,0xffffffffffc00000
  40ab89:	shr    rcx,0x10
  40ab8d:	and    ecx,0x3f
  40ab90:	mov    edx,DWORD PTR [rax+0x28]
  40ab93:	shrx   ecx,ecx,edx
  40ab98:	shl    rcx,0x4
  40ab9c:	lea    rax,[rax+rcx*8+0x80]
  40aba4:	ret
  40aba5:	inc    eax
  40aba7:	cmp    eax,edx
  40aba9:	jb     40ab60 <__swc_fn_0a4ed24b_000022_53fc00d2+0x10>
  40abab:	xor    eax,eax
  40abad:	ret
	...

000000000040abb0 <__swc_fn_0a4ed24b_000025_e876734d>:
  40abb0:	vxorps xmm0,xmm0,xmm0
  40abb4:	vmovups XMMWORD PTR [rcx],xmm0
  40abb8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40abbd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40abc2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40abc7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40abcc:	mov    QWORD PTR [rcx+0x50],0x0
  40abd4:	ret
	...

000000000040abe0 <__swc_fn_0a4ed24b_000028_e876734d>:
  40abe0:	vxorps xmm0,xmm0,xmm0
  40abe4:	xor    eax,eax
  40abe6:	cs nop WORD PTR [rax+rax*1+0x0]
  40abf0:	cs nop WORD PTR [rax+rax*1+0x0]
  40abfa:	nop    WORD PTR [rax+rax*1+0x0]
  40ac00:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40ac05:	add    rax,0x10
  40ac09:	cmp    rax,0x9b0
  40ac10:	jne    40ac00 <__swc_fn_0a4ed24b_000028_e876734d+0x20>
  40ac12:	mov    QWORD PTR [rcx+0x9b0],0x0
  40ac1d:	ret
	...

000000000040ac20 <__swc_fn_0a4ed24b_000031_3c3e930e>:
  40ac20:	push   rsi
  40ac21:	push   rdi
  40ac22:	sub    rsp,0x8
  40ac26:	lea    rsi,[rip+0x173db]        # 422008 <__swc_data_base_0a4ed24b+0x8>
  40ac2d:	mov    rax,QWORD PTR [rsi]
  40ac30:	mov    ecx,0xffffffff
  40ac35:	cmp    rax,rcx
  40ac38:	je     40ac41 <__swc_fn_0a4ed24b_000031_3c3e930e+0x21>
  40ac3a:	add    rsp,0x8
  40ac3e:	pop    rdi
  40ac3f:	pop    rsi
  40ac40:	ret
  40ac41:	mov    rcx,QWORD PTR [rip+0x8430]        # 413078 <__swc_fn_0a4ed24b_000176_0d61c738+0x1278>
  40ac48:	call   409650 <__swc_fn_0a4ed24b_000126_9e9697c7>
  40ac4d:	mov    rcx,rax
  40ac50:	mov    eax,0xffffffff
  40ac55:	lock cmpxchg QWORD PTR [rsi],rcx
  40ac5a:	mov    rdi,rax
  40ac5d:	mov    eax,0xffffffff
  40ac62:	cmp    rdi,rax
  40ac65:	je     40ac76 <__swc_fn_0a4ed24b_000031_3c3e930e+0x56>
  40ac67:	call   40ce50 <__swc_fn_0a4ed24b_000127_f163135d>
  40ac6c:	mov    rax,rdi
  40ac6f:	add    rsp,0x8
  40ac73:	pop    rdi
  40ac74:	pop    rsi
  40ac75:	ret
  40ac76:	mov    rax,rcx
  40ac79:	add    rsp,0x8
  40ac7d:	pop    rdi
  40ac7e:	pop    rsi
  40ac7f:	ret

000000000040ac80 <__swc_fn_0a4ed24b_000034_cf5ba7bd>:
  40ac80:	sub    rsp,0x8
  40ac84:	vxorps xmm0,xmm0,xmm0
  40ac88:	xor    eax,eax
  40ac8a:	cs nop WORD PTR [rax+rax*1+0x0]
  40ac94:	cs nop WORD PTR [rax+rax*1+0x0]
  40ac9e:	xchg   ax,ax
  40aca0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40aca5:	add    rax,0x10
  40aca9:	cmp    rax,0x2b00
  40acb0:	jne    40aca0 <__swc_fn_0a4ed24b_000034_cf5ba7bd+0x20>
  40acb2:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40acbc:	xor    al,al
  40acbe:	mov    rdx,rax
  40acc1:	xor    al,al
  40acc3:	mov    r8,rax
  40acc6:	xor    al,al
  40acc8:	mov    r9,rax
  40accb:	xor    al,al
  40accd:	mov    r10,rax
  40acd0:	xor    al,al
  40acd2:	mov    r11,rax
  40acd5:	call   40e090 <__swc_fn_0a4ed24b_000035_ab2e8c35>
  40acda:	add    rsp,0x8
  40acde:	ret
	...

000000000040ace0 <__swc_fn_0a4ed24b_000037_1e381f55>:
  40ace0:	push   rsi
  40ace1:	push   rdi
  40ace2:	push   r12
  40ace4:	mov    rsi,r8
  40ace7:	mov    rdi,rdx
  40acea:	mov    rcx,rdx
  40aced:	call   40dc20 <__swc_fn_0a4ed24b_000002_102336c4>
  40acf2:	mov    r12,rax
  40acf5:	test   rax,rax
  40acf8:	jne    40ad01 <__swc_fn_0a4ed24b_000037_1e381f55+0x21>
  40acfa:	xor    eax,eax
  40acfc:	pop    r12
  40acfe:	pop    rdi
  40acff:	pop    rsi
  40ad00:	ret
  40ad01:	mov    rcx,r12
  40ad04:	mov    rdx,rsi
  40ad07:	call   4072a0 <__swc_fn_0a4ed24b_000003_81215399>
  40ad0c:	test   al,al
  40ad0e:	jne    40ad22 <__swc_fn_0a4ed24b_000037_1e381f55+0x42>
  40ad10:	mov    rcx,r12
  40ad13:	mov    rdx,rdi
  40ad16:	call   40fe90 <__swc_fn_0a4ed24b_000113_4e83a03a>
  40ad1b:	xor    eax,eax
  40ad1d:	pop    r12
  40ad1f:	pop    rdi
  40ad20:	pop    rsi
  40ad21:	ret
  40ad22:	mov    rax,r12
  40ad25:	pop    r12
  40ad27:	pop    rdi
  40ad28:	pop    rsi
  40ad29:	ret
	...

000000000040ad40 <__swc_fn_0a4ed24b_000040_8029566e>:
  40ad40:	push   rsi
  40ad41:	push   rdi
  40ad42:	push   r12
  40ad44:	mov    rsi,rcx
  40ad47:	mov    edx,0x9b8
  40ad4c:	call   40e100 <__swc_fn_0a4ed24b_000038_292d55e5>
  40ad51:	mov    rdi,rax
  40ad54:	test   rax,rax
  40ad57:	jne    40ad60 <__swc_fn_0a4ed24b_000040_8029566e+0x20>
  40ad59:	xor    eax,eax
  40ad5b:	pop    r12
  40ad5d:	pop    rdi
  40ad5e:	pop    rsi
  40ad5f:	ret
  40ad60:	vxorps xmm0,xmm0,xmm0
  40ad64:	xor    eax,eax
  40ad66:	cs nop WORD PTR [rax+rax*1+0x0]
  40ad70:	cs nop WORD PTR [rax+rax*1+0x0]
  40ad7a:	nop    WORD PTR [rax+rax*1+0x0]
  40ad80:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40ad85:	add    rax,0x10
  40ad89:	cmp    rax,0x9b0
  40ad90:	jne    40ad80 <__swc_fn_0a4ed24b_000040_8029566e+0x40>
  40ad92:	mov    QWORD PTR [rdi+0x9b0],0x0
  40ad9d:	mov    QWORD PTR [rdi],rsi
  40ada0:	call   40cf00 <__swc_fn_0a4ed24b_000130_375c7357>
  40ada5:	mov    QWORD PTR [rdi+0x18],rax
  40ada9:	lea    r12,[rsi+0x10]
  40adad:	mov    rcx,r12
  40adb0:	call   4098a0 <__swc_fn_0a4ed24b_000135_db32cc57>
  40adb5:	mov    rax,QWORD PTR [rsi+0x20]
  40adb9:	mov    QWORD PTR [rdi+0x8],rax
  40adbd:	mov    rax,QWORD PTR [rsi+0x20]
  40adc1:	test   rax,rax
  40adc4:	je     40adca <__swc_fn_0a4ed24b_000040_8029566e+0x8a>
  40adc6:	mov    QWORD PTR [rax+0x10],rdi
  40adca:	mov    QWORD PTR [rsi+0x20],rdi
  40adce:	mov    rcx,r12
  40add1:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  40add6:	mov    rax,rdi
  40add9:	pop    r12
  40addb:	pop    rdi
  40addc:	pop    rsi
  40addd:	ret
	...

000000000040ade0 <__swc_fn_0a4ed24b_000043_47ff6d9b>:
  40ade0:	mov    rax,QWORD PTR [rdx+0x10]
  40ade4:	test   rax,rax
  40ade7:	je     40adf3 <__swc_fn_0a4ed24b_000043_47ff6d9b+0x13>
  40ade9:	mov    rcx,QWORD PTR [rdx+0x8]
  40aded:	mov    QWORD PTR [rax+0x8],rcx
  40adf1:	jmp    40adfb <__swc_fn_0a4ed24b_000043_47ff6d9b+0x1b>
  40adf3:	mov    rax,QWORD PTR [rdx+0x8]
  40adf7:	mov    QWORD PTR [rcx+0x20],rax
  40adfb:	mov    rax,QWORD PTR [rdx+0x8]
  40adff:	test   rax,rax
  40ae02:	je     40ae0c <__swc_fn_0a4ed24b_000043_47ff6d9b+0x2c>
  40ae04:	mov    rcx,QWORD PTR [rdx+0x10]
  40ae08:	mov    QWORD PTR [rax+0x10],rcx
  40ae0c:	vxorps xmm0,xmm0,xmm0
  40ae10:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40ae15:	ret
	...

000000000040ae20 <__swc_fn_0a4ed24b_000046_b28a6ee7>:
  40ae20:	sub    rsp,0x8
  40ae24:	mov    r9,r8
  40ae27:	mov    r10,rdx
  40ae2a:	call   40e1b0 <__swc_fn_0a4ed24b_000044_fe6bbfdb>
  40ae2f:	mov    eax,0x1
  40ae34:	xchg   DWORD PTR [r9+0x6c],eax
  40ae38:	mov    rax,QWORD PTR [r9+0x60]
  40ae3c:	test   rax,rax
  40ae3f:	je     40ae83 <__swc_fn_0a4ed24b_000046_b28a6ee7+0x63>
  40ae41:	xor    eax,eax
  40ae43:	xchg   DWORD PTR [r9+0x6c],eax
  40ae47:	movzx  eax,BYTE PTR [r9+0x39]
  40ae4c:	lea    rax,[rax+rax*4]
  40ae50:	lea    rax,[r10+rax*8+0x28]
  40ae55:	mov    QWORD PTR [r9+0x50],0x0
  40ae5d:	mov    rcx,QWORD PTR [rax+0x8]
  40ae61:	mov    QWORD PTR [r9+0x48],rcx
  40ae65:	mov    rcx,QWORD PTR [rax+0x8]
  40ae69:	test   rcx,rcx
  40ae6c:	je     40ae74 <__swc_fn_0a4ed24b_000046_b28a6ee7+0x54>
  40ae6e:	mov    QWORD PTR [rcx+0x50],r9
  40ae72:	jmp    40ae78 <__swc_fn_0a4ed24b_000046_b28a6ee7+0x58>
  40ae74:	mov    QWORD PTR [rax+0x10],r9
  40ae78:	mov    QWORD PTR [rax+0x8],r9
  40ae7c:	xor    eax,eax
  40ae7e:	add    rsp,0x8
  40ae82:	ret
  40ae83:	movzx  eax,BYTE PTR [r9+0x39]
  40ae88:	lea    rax,[rax+rax*4]
  40ae8c:	lea    rax,[r10+rax*8+0x28]
  40ae91:	mov    QWORD PTR [r9+0x50],0x0
  40ae99:	mov    rcx,QWORD PTR [rax+0x18]
  40ae9d:	mov    QWORD PTR [r9+0x48],rcx
  40aea1:	mov    rcx,QWORD PTR [rax+0x18]
  40aea5:	test   rcx,rcx
  40aea8:	je     40aeae <__swc_fn_0a4ed24b_000046_b28a6ee7+0x8e>
  40aeaa:	mov    QWORD PTR [rcx+0x50],r9
  40aeae:	mov    QWORD PTR [rax+0x18],r9
  40aeb2:	mov    eax,0x1
  40aeb7:	add    rsp,0x8
  40aebb:	ret
  40aebc:	add    BYTE PTR [rax],al
	...

000000000040aec0 <__swc_fn_0a4ed24b_000049_f6a485a2>:
  40aec0:	push   r12
  40aec2:	push   r13
  40aec4:	push   rdi
  40aec5:	push   rsi
  40aec6:	push   r14
  40aec8:	push   r15
  40aeca:	sub    rsp,0x178
  40aed1:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40aeda:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40aee3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40aeec:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40aef5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40aefe:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40af07:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40af10:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40af19:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40af22:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40af2b:	mov    r12,rcx
  40af2e:	lea    rax,[rip+0x192cb]        # 424200 <__swc_bss_base_0a4ed24b+0x1c0>
  40af35:	mov    rcx,QWORD PTR [rax]
  40af38:	mov    r13,rcx
  40af3b:	test   rcx,rcx
  40af3e:	jne    40af4e <__swc_fn_0a4ed24b_000049_f6a485a2+0x8e>
  40af40:	mov    r13d,0x1dcd6500
  40af46:	mov    ecx,0x1dcd6500
  40af4b:	xchg   QWORD PTR [rax],rcx
  40af4e:	lea    rax,[rip+0x170ab]        # 422000 <__swc_data_base_0a4ed24b>
  40af55:	mov    rax,QWORD PTR [rax]
  40af58:	cmp    rax,0xffffffffffffffff
  40af5c:	je     40af6b <__swc_fn_0a4ed24b_000049_f6a485a2+0xab>
  40af5e:	mov    eax,eax
  40af60:	mov    edi,eax
  40af62:	xor    eax,eax
  40af64:	call   407000 <pthread_getspecific@plt>
  40af69:	jmp    40af6d <__swc_fn_0a4ed24b_000049_f6a485a2+0xad>
  40af6b:	xor    eax,eax
  40af6d:	test   rax,rax
  40af70:	jne    40af7f <__swc_fn_0a4ed24b_000049_f6a485a2+0xbf>
  40af72:	call   40ac20 <__swc_fn_0a4ed24b_000031_3c3e930e>
  40af77:	mov    rcx,rax
  40af7a:	call   4101e0 <__swc_fn_0a4ed24b_000128_8d8a7dd2>
  40af7f:	test   rax,rax
  40af82:	je     40af94 <__swc_fn_0a4ed24b_000049_f6a485a2+0xd4>
  40af84:	cmp    QWORD PTR [rax],r12
  40af87:	jne    40af94 <__swc_fn_0a4ed24b_000049_f6a485a2+0xd4>
  40af89:	cmp    DWORD PTR [rax+0x20],0x0
  40af8d:	jne    40af94 <__swc_fn_0a4ed24b_000049_f6a485a2+0xd4>
  40af8f:	mov    rsi,rax
  40af92:	jmp    40af96 <__swc_fn_0a4ed24b_000049_f6a485a2+0xd6>
  40af94:	xor    esi,esi
  40af96:	lea    rdi,[r12+0x2a88]
  40af9e:	mov    r14,QWORD PTR [rdi]
  40afa1:	test   r14,r14
  40afa4:	jne    40aff3 <__swc_fn_0a4ed24b_000049_f6a485a2+0x133>
  40afa6:	lea    rax,[rip+0x190ab]        # 424058 <__swc_bss_base_0a4ed24b+0x18>
  40afad:	mov    rax,QWORD PTR [rax]
  40afb0:	test   rax,rax
  40afb3:	setne  al
  40afb6:	jne    40afda <__swc_fn_0a4ed24b_000049_f6a485a2+0x11a>
  40afb8:	mov    rax,QWORD PTR [r12+0x2a70]
  40afc0:	test   rax,rax
  40afc3:	setne  al
  40afc6:	jne    40afda <__swc_fn_0a4ed24b_000049_f6a485a2+0x11a>
  40afc8:	test   rsi,rsi
  40afcb:	setne  al
  40afce:	je     40afda <__swc_fn_0a4ed24b_000049_f6a485a2+0x11a>
  40afd0:	cmp    DWORD PTR [rsi+0x730],0x0
  40afd7:	setne  al
  40afda:	test   al,al
  40afdc:	je     40afee <__swc_fn_0a4ed24b_000049_f6a485a2+0x12e>
  40afde:	call   410290 <__swc_fn_0a4ed24b_000131_91db8856>
  40afe3:	lea    rcx,[rax+r13*1]
  40afe7:	xor    eax,eax
  40afe9:	lock cmpxchg QWORD PTR [rdi],rcx
  40afee:	jmp    40b0f3 <__swc_fn_0a4ed24b_000049_f6a485a2+0x233>
  40aff3:	call   410290 <__swc_fn_0a4ed24b_000131_91db8856>
  40aff8:	mov    r15,rax
  40affb:	cmp    rax,r14
  40affe:	jb     40b00f <__swc_fn_0a4ed24b_000049_f6a485a2+0x14f>
  40b000:	xor    ecx,ecx
  40b002:	mov    rax,r14
  40b005:	lock cmpxchg QWORD PTR [rdi],rcx
  40b00a:	cmp    rax,r14
  40b00d:	je     40b014 <__swc_fn_0a4ed24b_000049_f6a485a2+0x154>
  40b00f:	jmp    40b0f3 <__swc_fn_0a4ed24b_000049_f6a485a2+0x233>
  40b014:	test   rsi,rsi
  40b017:	je     40b032 <__swc_fn_0a4ed24b_000049_f6a485a2+0x172>
  40b019:	cmp    r15,r13
  40b01c:	jb     40b032 <__swc_fn_0a4ed24b_000049_f6a485a2+0x172>
  40b01e:	mov    rax,r15
  40b021:	sub    rax,r13
  40b024:	mov    rcx,r12
  40b027:	mov    rdx,rsi
  40b02a:	mov    r8,rax
  40b02d:	call   40e5f0 <__swc_fn_0a4ed24b_000059_ee6a254c>
  40b032:	lea    rsi,[r12+0x10]
  40b037:	mov    rcx,rsi
  40b03a:	call   4098a0 <__swc_fn_0a4ed24b_000135_db32cc57>
  40b03f:	mov    rax,QWORD PTR [r12+0x18]
  40b044:	mov    rdi,rax
  40b047:	test   rdi,rdi
  40b04a:	je     40b074 <__swc_fn_0a4ed24b_000049_f6a485a2+0x1b4>
  40b04c:	cs nop WORD PTR [rax+rax*1+0x0]
  40b056:	cs nop WORD PTR [rax+rax*1+0x0]
  40b060:	mov    rcx,rdi
  40b063:	call   407470 <__swc_fn_0a4ed24b_000015_96cb1311>
  40b068:	mov    rax,QWORD PTR [rdi+0x10]
  40b06c:	mov    rdi,rax
  40b06f:	test   rax,rax
  40b072:	jne    40b060 <__swc_fn_0a4ed24b_000049_f6a485a2+0x1a0>
  40b074:	mov    rcx,rsi
  40b077:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  40b07c:	mov    rcx,r12
  40b07f:	call   4098a0 <__swc_fn_0a4ed24b_000135_db32cc57>
  40b084:	xor    esi,esi
  40b086:	cs nop WORD PTR [rax+rax*1+0x0]
  40b090:	mov    rax,QWORD PTR [r12+0x2a70]
  40b098:	cmp    rsi,rax
  40b09b:	jae    40b0eb <__swc_fn_0a4ed24b_000049_f6a485a2+0x22b>
  40b09d:	lea    rax,[rsi+rsi*4]
  40b0a1:	lea    rax,[r12+rax*8+0x268]
  40b0a9:	mov    r8,QWORD PTR [rax]
  40b0ac:	mov    r9,QWORD PTR [rax+0x8]
  40b0b0:	mov    r10,QWORD PTR [rax+0x10]
  40b0b4:	mov    rax,QWORD PTR [rax+0x20]
  40b0b8:	cmp    rax,r15
  40b0bb:	jae    40b0c8 <__swc_fn_0a4ed24b_000049_f6a485a2+0x208>
  40b0bd:	mov    rcx,r15
  40b0c0:	sub    rcx,rax
  40b0c3:	cmp    rcx,r13
  40b0c6:	jae    40b0cd <__swc_fn_0a4ed24b_000049_f6a485a2+0x20d>
  40b0c8:	inc    rsi
  40b0cb:	jmp    40b090 <__swc_fn_0a4ed24b_000049_f6a485a2+0x1d0>
  40b0cd:	mov    rcx,r12
  40b0d0:	mov    rdx,rsi
  40b0d3:	call   40e5a0 <__swc_fn_0a4ed24b_000056_87dc216f>
  40b0d8:	mov    rcx,r12
  40b0db:	mov    rdx,r8
  40b0de:	mov    r8,r9
  40b0e1:	mov    r9,r10
  40b0e4:	call   407750 <__swc_fn_0a4ed24b_000039_9ae4348f>
  40b0e9:	jmp    40b090 <__swc_fn_0a4ed24b_000049_f6a485a2+0x1d0>
  40b0eb:	mov    rcx,r12
  40b0ee:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  40b0f3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40b0fc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40b105:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40b10e:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40b117:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40b120:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40b129:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40b132:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40b13b:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40b144:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40b14d:	add    rsp,0x178
  40b154:	pop    r15
  40b156:	pop    r14
  40b158:	pop    rsi
  40b159:	pop    rdi
  40b15a:	pop    r13
  40b15c:	pop    r12
  40b15e:	ret
	...

000000000040b160 <__swc_fn_0a4ed24b_000052_92b016ae>:
  40b160:	lea    rax,[rdx-0x58]
  40b164:	ret
	...

000000000040b170 <__swc_fn_0a4ed24b_000055_ddf32775>:
  40b170:	push   rsi
  40b171:	push   rdi
  40b172:	push   r12
  40b174:	push   r13
  40b176:	sub    rsp,0x68
  40b17a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40b180:	mov    rsi,r9
  40b183:	mov    rdi,rcx
  40b186:	mov    r12,rdx
  40b189:	mov    r13,r8
  40b18c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40b194:	jne    40b1a3 <__swc_fn_0a4ed24b_000055_ddf32775+0x33>
  40b196:	xor    eax,eax
  40b198:	add    rsp,0x68
  40b19c:	pop    r13
  40b19e:	pop    r12
  40b1a0:	pop    rdi
  40b1a1:	pop    rsi
  40b1a2:	ret
  40b1a3:	mov    rcx,rdi
  40b1a6:	call   4098a0 <__swc_fn_0a4ed24b_000135_db32cc57>
  40b1ab:	movabs rax,0x7fffffffffffffff
  40b1b5:	cmp    r12,rax
  40b1b8:	mov    rax,0xffffffffffffffff
  40b1bf:	lea    rcx,[r12+r12*1]
  40b1c3:	cmovbe rax,rcx
  40b1c7:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40b1ce:	mov    rdx,rcx
  40b1d1:	sub    rax,r12
  40b1d4:	inc    rax
  40b1d7:	xor    r8d,r8d
  40b1da:	test   rcx,rcx
  40b1dd:	jbe    40b208 <__swc_fn_0a4ed24b_000055_ddf32775+0x98>
  40b1df:	nop
  40b1e0:	lea    r9,[r8+r8*4]
  40b1e4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40b1ec:	sub    r9,r12
  40b1ef:	cmp    r9,rax
  40b1f2:	jae    40b1ff <__swc_fn_0a4ed24b_000055_ddf32775+0x8f>
  40b1f4:	mov    rdx,r8
  40b1f7:	mov    rax,r9
  40b1fa:	test   r9,r9
  40b1fd:	je     40b208 <__swc_fn_0a4ed24b_000055_ddf32775+0x98>
  40b1ff:	add    r8,0x1
  40b203:	cmp    r8,rcx
  40b206:	jb     40b1e0 <__swc_fn_0a4ed24b_000055_ddf32775+0x70>
  40b208:	mov    rax,QWORD PTR [rdi+0x2a70]
  40b20f:	cmp    rdx,rax
  40b212:	jne    40b22f <__swc_fn_0a4ed24b_000055_ddf32775+0xbf>
  40b214:	mov    rcx,rdi
  40b217:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  40b21c:	xor    eax,eax
  40b21e:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b224:	add    rsp,0x68
  40b228:	pop    r13
  40b22a:	pop    r12
  40b22c:	pop    rdi
  40b22d:	pop    rsi
  40b22e:	ret
  40b22f:	lea    rax,[rdx+rdx*4]
  40b233:	lea    rax,[rdi+rax*8+0x268]
  40b23b:	vmovups xmm6,XMMWORD PTR [rax]
  40b23f:	mov    r8,QWORD PTR [rax+0x10]
  40b243:	mov    rcx,rdi
  40b246:	call   40e5a0 <__swc_fn_0a4ed24b_000056_87dc216f>
  40b24b:	vpshufd xmm0,xmm6,0xee
  40b250:	vmovsd QWORD PTR [r13+0x0],xmm0
  40b256:	mov    QWORD PTR [rsi],r8
  40b259:	mov    rcx,rdi
  40b25c:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  40b261:	vmovq  rax,xmm6
  40b266:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b26c:	add    rsp,0x68
  40b270:	pop    r13
  40b272:	pop    r12
  40b274:	pop    rdi
  40b275:	pop    rsi
  40b276:	ret
	...

000000000040b280 <__swc_fn_0a4ed24b_000058_01964a17>:
  40b280:	push   r12
  40b282:	push   r13
  40b284:	push   r14
  40b286:	push   r15
  40b288:	push   rdi
  40b289:	push   rsi
  40b28a:	sub    rsp,0x148
  40b291:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40b29a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40b2a3:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40b2ac:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40b2b5:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40b2be:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40b2c7:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40b2d0:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40b2d9:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40b2e2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40b2eb:	mov    r12,r9
  40b2ee:	mov    r13,rcx
  40b2f1:	mov    r14,rdx
  40b2f4:	mov    r15,r8
  40b2f7:	test   rdx,rdx
  40b2fa:	jne    40b30e <__swc_fn_0a4ed24b_000058_01964a17+0x8e>
  40b2fc:	add    rsp,0x148
  40b303:	pop    rsi
  40b304:	pop    rdi
  40b305:	pop    r15
  40b307:	pop    r14
  40b309:	pop    r13
  40b30b:	pop    r12
  40b30d:	ret
  40b30e:	cmp    r12,0x200000
  40b315:	ja     40b3a7 <__swc_fn_0a4ed24b_000058_01964a17+0x127>
  40b31b:	lea    rax,[rip+0x16cde]        # 422000 <__swc_data_base_0a4ed24b>
  40b322:	mov    rax,QWORD PTR [rax]
  40b325:	cmp    rax,0xffffffffffffffff
  40b329:	je     40b338 <__swc_fn_0a4ed24b_000058_01964a17+0xb8>
  40b32b:	mov    eax,eax
  40b32d:	mov    edi,eax
  40b32f:	xor    eax,eax
  40b331:	call   407000 <pthread_getspecific@plt>
  40b336:	jmp    40b33a <__swc_fn_0a4ed24b_000058_01964a17+0xba>
  40b338:	xor    eax,eax
  40b33a:	test   rax,rax
  40b33d:	je     40b344 <__swc_fn_0a4ed24b_000058_01964a17+0xc4>
  40b33f:	mov    rsi,rax
  40b342:	jmp    40b354 <__swc_fn_0a4ed24b_000058_01964a17+0xd4>
  40b344:	call   40ac20 <__swc_fn_0a4ed24b_000031_3c3e930e>
  40b349:	mov    rcx,rax
  40b34c:	call   4101e0 <__swc_fn_0a4ed24b_000128_8d8a7dd2>
  40b351:	mov    rsi,rax
  40b354:	test   rsi,rsi
  40b357:	je     40b3a7 <__swc_fn_0a4ed24b_000058_01964a17+0x127>
  40b359:	cmp    QWORD PTR [rsi],r13
  40b35c:	jne    40b3a7 <__swc_fn_0a4ed24b_000058_01964a17+0x127>
  40b35e:	cmp    DWORD PTR [rsi+0x20],0x0
  40b362:	jne    40b3a7 <__swc_fn_0a4ed24b_000058_01964a17+0x127>
  40b364:	cmp    DWORD PTR [rsi+0x730],0x10
  40b36b:	jae    40b3a7 <__swc_fn_0a4ed24b_000058_01964a17+0x127>
  40b36d:	mov    eax,DWORD PTR [rsi+0x730]
  40b373:	lea    rdi,[rax+rax*4]
  40b377:	lea    rdi,[rsi+rdi*8+0x738]
  40b37f:	mov    QWORD PTR [rdi],r14
  40b382:	mov    QWORD PTR [rdi+0x8],r15
  40b386:	mov    QWORD PTR [rdi+0x10],r12
  40b38a:	mov    QWORD PTR [rdi+0x18],0x0
  40b392:	call   410290 <__swc_fn_0a4ed24b_000131_91db8856>
  40b397:	mov    QWORD PTR [rdi+0x20],rax
  40b39b:	add    DWORD PTR [rsi+0x730],0x1
  40b3a2:	jmp    40b506 <__swc_fn_0a4ed24b_000058_01964a17+0x286>
  40b3a7:	mov    rcx,r13
  40b3aa:	call   407e90 <__swc_fn_0a4ed24b_000057_01c75a1d>
  40b3af:	mov    rsi,rax
  40b3b2:	cmp    r12,rax
  40b3b5:	jbe    40b3ea <__swc_fn_0a4ed24b_000058_01964a17+0x16a>
  40b3b7:	cmp    r12,0x10000000
  40b3be:	seta   al
  40b3c1:	ja     40b3d0 <__swc_fn_0a4ed24b_000058_01964a17+0x150>
  40b3c3:	mov    rax,QWORD PTR [r13+0x2a70]
  40b3ca:	test   rax,rax
  40b3cd:	setne  al
  40b3d0:	test   al,al
  40b3d2:	je     40b3ea <__swc_fn_0a4ed24b_000058_01964a17+0x16a>
  40b3d4:	mov    rcx,r13
  40b3d7:	mov    rdx,r14
  40b3da:	mov    r8,r15
  40b3dd:	mov    r9,r12
  40b3e0:	call   407750 <__swc_fn_0a4ed24b_000039_9ae4348f>
  40b3e5:	jmp    40b506 <__swc_fn_0a4ed24b_000058_01964a17+0x286>
  40b3ea:	call   410290 <__swc_fn_0a4ed24b_000131_91db8856>
  40b3ef:	mov    rdi,rax
  40b3f2:	mov    rcx,r13
  40b3f5:	call   4098a0 <__swc_fn_0a4ed24b_000135_db32cc57>
  40b3fa:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b402:	je     40b4ba <__swc_fn_0a4ed24b_000058_01964a17+0x23a>
  40b408:	nop    DWORD PTR [rax+rax*1+0x0]
  40b410:	cmp    QWORD PTR [r13+0x2a70],0x100
  40b41b:	jae    40b430 <__swc_fn_0a4ed24b_000058_01964a17+0x1b0>
  40b41d:	mov    rax,QWORD PTR [r13+0x2a68]
  40b424:	add    rax,r12
  40b427:	cmp    rax,rsi
  40b42a:	jbe    40b4ba <__swc_fn_0a4ed24b_000058_01964a17+0x23a>
  40b430:	xor    eax,eax
  40b432:	mov    rcx,QWORD PTR [r13+0x2a70]
  40b439:	mov    edx,0x1
  40b43e:	cmp    rcx,0x1
  40b442:	jbe    40b479 <__swc_fn_0a4ed24b_000058_01964a17+0x1f9>
  40b444:	cs nop WORD PTR [rax+rax*1+0x0]
  40b44e:	xchg   ax,ax
  40b450:	lea    r8,[rdx+rdx*4]
  40b454:	lea    r8,[r13+r8*8+0x268]
  40b45c:	lea    r9,[rax+rax*4]
  40b460:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40b468:	cmp    QWORD PTR [r8+0x18],r9
  40b46c:	cmovb  rax,rdx
  40b470:	add    rdx,0x1
  40b474:	cmp    rdx,rcx
  40b477:	jb     40b450 <__swc_fn_0a4ed24b_000058_01964a17+0x1d0>
  40b479:	lea    rcx,[rax+rax*4]
  40b47d:	lea    rcx,[r13+rcx*8+0x268]
  40b485:	mov    r8,QWORD PTR [rcx]
  40b488:	mov    r9,QWORD PTR [rcx+0x8]
  40b48c:	mov    r10,QWORD PTR [rcx+0x10]
  40b490:	mov    rcx,r13
  40b493:	mov    rdx,rax
  40b496:	call   40e5a0 <__swc_fn_0a4ed24b_000056_87dc216f>
  40b49b:	mov    rcx,r13
  40b49e:	mov    rdx,r8
  40b4a1:	mov    r8,r9
  40b4a4:	mov    r9,r10
  40b4a7:	call   407750 <__swc_fn_0a4ed24b_000039_9ae4348f>
  40b4ac:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b4b4:	jne    40b410 <__swc_fn_0a4ed24b_000058_01964a17+0x190>
  40b4ba:	add    QWORD PTR [r13+0x2a78],0x1
  40b4c2:	mov    rax,QWORD PTR [r13+0x2a70]
  40b4c9:	lea    rax,[rax+rax*4]
  40b4cd:	lea    rax,[r13+rax*8+0x268]
  40b4d5:	mov    QWORD PTR [rax],r14
  40b4d8:	mov    QWORD PTR [rax+0x8],r15
  40b4dc:	mov    QWORD PTR [rax+0x10],r12
  40b4e0:	mov    rcx,QWORD PTR [r13+0x2a78]
  40b4e7:	mov    QWORD PTR [rax+0x18],rcx
  40b4eb:	mov    QWORD PTR [rax+0x20],rdi
  40b4ef:	add    QWORD PTR [r13+0x2a68],r12
  40b4f6:	add    QWORD PTR [r13+0x2a70],0x1
  40b4fe:	mov    rcx,r13
  40b501:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  40b506:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40b50f:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40b518:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40b521:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40b52a:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40b533:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40b53c:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40b545:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40b54e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40b557:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40b560:	add    rsp,0x148
  40b567:	pop    rsi
  40b568:	pop    rdi
  40b569:	pop    r15
  40b56b:	pop    r14
  40b56d:	pop    r13
  40b56f:	pop    r12
  40b571:	ret
	...

000000000040b580 <__swc_fn_0a4ed24b_000061_73a9baa2>:
  40b580:	push   rbx
  40b581:	push   r12
  40b583:	push   r13
  40b585:	push   r14
  40b587:	push   r15
  40b589:	push   rdi
  40b58a:	push   rsi
  40b58b:	sub    rsp,0xf0
  40b592:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40b598:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40b59e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40b5a4:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40b5aa:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40b5b3:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40b5bc:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40b5c5:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40b5ce:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40b5d7:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40b5e0:	mov    eax,r8d
  40b5e3:	mov    rbx,rcx
  40b5e6:	mov    r12,rdx
  40b5e9:	mov    QWORD PTR [rsp+0x18],rdx
  40b5ee:	mov    ecx,DWORD PTR [r12+0x58]
  40b5f3:	mov    r13d,ecx
  40b5f6:	cmp    ecx,0x10
  40b5f9:	mov    ecx,0x10
  40b5fe:	cmovb  r13d,ecx
  40b602:	test   r13d,r13d
  40b605:	mov    rcx,r13
  40b608:	mov    edx,0x8
  40b60d:	cmove  ecx,edx
  40b610:	dec    rcx
  40b613:	mov    rdx,0xffffffffffffffff
  40b61a:	sub    rdx,rcx
  40b61d:	xor    r14d,r14d
  40b620:	mov    r8,rcx
  40b623:	not    r8
  40b626:	lea    rcx,[rcx+0x58]
  40b62a:	and    rcx,r8
  40b62d:	cmp    rdx,0x58
  40b631:	cmovae r14,rcx
  40b635:	cmp    eax,0xffffffff
  40b638:	jne    40b641 <__swc_fn_0a4ed24b_000061_73a9baa2+0xc1>
  40b63a:	mov    r15,QWORD PTR [r12+0x48]
  40b63f:	jmp    40b673 <__swc_fn_0a4ed24b_000061_73a9baa2+0xf3>
  40b641:	test   eax,eax
  40b643:	jne    40b64c <__swc_fn_0a4ed24b_000061_73a9baa2+0xcc>
  40b645:	mov    eax,0x8
  40b64a:	jmp    40b670 <__swc_fn_0a4ed24b_000061_73a9baa2+0xf0>
  40b64c:	cmp    eax,0x8
  40b64f:	ja     40b657 <__swc_fn_0a4ed24b_000061_73a9baa2+0xd7>
  40b651:	shl    rax,0x4
  40b655:	jmp    40b670 <__swc_fn_0a4ed24b_000061_73a9baa2+0xf0>
  40b657:	lea    eax,[rax-0x9]
  40b65a:	mov    ecx,eax
  40b65c:	shr    ecx,0x2
  40b65f:	and    eax,0x3
  40b662:	lea    ecx,[rcx+0x7]
  40b665:	lea    ecx,[rcx-0x2]
  40b668:	lea    eax,[rax+0x5]
  40b66b:	shlx   rax,rax,rcx
  40b670:	mov    r15,rax
  40b673:	lea    rax,[r14+r13*1]
  40b677:	mov    rcx,0xffffffffffffffff
  40b67e:	sub    rcx,rax
  40b681:	cmp    r15,rcx
  40b684:	jbe    40b694 <__swc_fn_0a4ed24b_000061_73a9baa2+0x114>
  40b686:	mov    QWORD PTR [r12+0x40],0x0
  40b68f:	jmp    40ba66 <__swc_fn_0a4ed24b_000061_73a9baa2+0x4e6>
  40b694:	mov    QWORD PTR [rsp+0x20],r13
  40b699:	lea    r13,[rsp+0x8]
  40b69e:	add    rax,r15
  40b6a1:	mov    ecx,0x1000
  40b6a6:	test   ecx,ecx
  40b6a8:	mov    edx,0x8
  40b6ad:	cmove  ecx,edx
  40b6b0:	dec    rcx
  40b6b3:	mov    rdx,0xffffffffffffffff
  40b6ba:	sub    rdx,rcx
  40b6bd:	cmp    rax,rdx
  40b6c0:	jbe    40b6cc <__swc_fn_0a4ed24b_000061_73a9baa2+0x14c>
  40b6c2:	mov    QWORD PTR [r13+0x0],0x0
  40b6ca:	jmp    40b6d9 <__swc_fn_0a4ed24b_000061_73a9baa2+0x159>
  40b6cc:	add    rax,rcx
  40b6cf:	andn   rax,rcx,rax
  40b6d4:	mov    QWORD PTR [rsp+0x8],rax
  40b6d9:	cmp    QWORD PTR [r13+0x0],0x0
  40b6de:	jne    40b6ee <__swc_fn_0a4ed24b_000061_73a9baa2+0x16e>
  40b6e0:	mov    QWORD PTR [r12+0x40],0x0
  40b6e9:	jmp    40ba66 <__swc_fn_0a4ed24b_000061_73a9baa2+0x4e6>
  40b6ee:	mov    QWORD PTR [rsp+0x30],r15
  40b6f3:	xor    r15d,r15d
  40b6f6:	mov    QWORD PTR [rsp+0x38],0x0
  40b6ff:	lea    r12,[rsp+0x10]
  40b704:	mov    QWORD PTR [rsp+0x28],r14
  40b709:	mov    r14,QWORD PTR [rsp+0x8]
  40b70e:	mov    QWORD PTR [rsp+0x10],r14
  40b713:	cmp    r14,0x10000
  40b71a:	ja     40b721 <__swc_fn_0a4ed24b_000061_73a9baa2+0x1a1>
  40b71c:	mov    rax,r14
  40b71f:	jmp    40b772 <__swc_fn_0a4ed24b_000061_73a9baa2+0x1f2>
  40b721:	xor    eax,eax
  40b723:	lea    rcx,[r14-0x1]
  40b727:	lzcnt  rax,rcx
  40b72c:	mov    ecx,0x3f
  40b731:	sub    rcx,rax
  40b734:	mov    eax,0x1
  40b739:	lea    rcx,[rcx-0x3]
  40b73d:	shl    rax,cl
  40b740:	mov    rcx,rax
  40b743:	cmp    rax,0x1000
  40b74a:	mov    eax,0x1000
  40b74f:	cmovb  rcx,rax
  40b753:	mov    rdx,0xffffffffffffffff
  40b75a:	sub    rdx,rcx
  40b75d:	mov    rax,r14
  40b760:	lea    r8,[r14+rcx*1-0x1]
  40b765:	neg    rcx
  40b768:	and    r8,rcx
  40b76b:	cmp    r14,rdx
  40b76e:	cmovbe rax,r8
  40b772:	mov    QWORD PTR [rsp+0x8],rax
  40b777:	lea    rax,[rip+0x16882]        # 422000 <__swc_data_base_0a4ed24b>
  40b77e:	mov    rax,QWORD PTR [rax]
  40b781:	cmp    rax,0xffffffffffffffff
  40b785:	je     40b794 <__swc_fn_0a4ed24b_000061_73a9baa2+0x214>
  40b787:	mov    eax,eax
  40b789:	mov    edi,eax
  40b78b:	xor    eax,eax
  40b78d:	call   407000 <pthread_getspecific@plt>
  40b792:	jmp    40b796 <__swc_fn_0a4ed24b_000061_73a9baa2+0x216>
  40b794:	xor    eax,eax
  40b796:	test   rax,rax
  40b799:	jne    40b7a8 <__swc_fn_0a4ed24b_000061_73a9baa2+0x228>
  40b79b:	call   40ac20 <__swc_fn_0a4ed24b_000031_3c3e930e>
  40b7a0:	mov    rcx,rax
  40b7a3:	call   4101e0 <__swc_fn_0a4ed24b_000128_8d8a7dd2>
  40b7a8:	test   rax,rax
  40b7ab:	je     40b89c <__swc_fn_0a4ed24b_000061_73a9baa2+0x31c>
  40b7b1:	cmp    QWORD PTR [rax],rbx
  40b7b4:	jne    40b89c <__swc_fn_0a4ed24b_000061_73a9baa2+0x31c>
  40b7ba:	cmp    DWORD PTR [rax+0x20],0x0
  40b7be:	jne    40b89c <__swc_fn_0a4ed24b_000061_73a9baa2+0x31c>
  40b7c4:	mov    rcx,QWORD PTR [rsp+0x8]
  40b7c9:	movabs rdx,0x7fffffffffffffff
  40b7d3:	cmp    rcx,rdx
  40b7d6:	mov    rdx,0xffffffffffffffff
  40b7dd:	lea    r8,[rcx+rcx*1]
  40b7e1:	cmovbe rdx,r8
  40b7e5:	mov    r8d,DWORD PTR [rax+0x730]
  40b7ec:	mov    r9d,r8d
  40b7ef:	sub    rdx,rcx
  40b7f2:	inc    rdx
  40b7f5:	xor    r10d,r10d
  40b7f8:	test   r8,r8
  40b7fb:	jbe    40b82b <__swc_fn_0a4ed24b_000061_73a9baa2+0x2ab>
  40b7fd:	nop    DWORD PTR [rax]
  40b800:	mov    r11d,r10d
  40b803:	lea    r11,[r11+r11*4]
  40b807:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40b80f:	sub    r11,rcx
  40b812:	cmp    r11,rdx
  40b815:	jae    40b822 <__swc_fn_0a4ed24b_000061_73a9baa2+0x2a2>
  40b817:	mov    r9d,r10d
  40b81a:	mov    rdx,r11
  40b81d:	test   r11,r11
  40b820:	je     40b82b <__swc_fn_0a4ed24b_000061_73a9baa2+0x2ab>
  40b822:	add    r10,0x1
  40b826:	cmp    r10,r8
  40b829:	jb     40b800 <__swc_fn_0a4ed24b_000061_73a9baa2+0x280>
  40b82b:	mov    ecx,DWORD PTR [rax+0x730]
  40b831:	cmp    r9d,ecx
  40b834:	jne    40b83a <__swc_fn_0a4ed24b_000061_73a9baa2+0x2ba>
  40b836:	xor    eax,eax
  40b838:	jmp    40b899 <__swc_fn_0a4ed24b_000061_73a9baa2+0x319>
  40b83a:	lea    rcx,[r9+r9*4]
  40b83e:	lea    rcx,[rax+rcx*8+0x738]
  40b846:	vmovups xmm0,XMMWORD PTR [rcx]
  40b84a:	mov    rdx,QWORD PTR [rcx+0x10]
  40b84e:	sub    DWORD PTR [rax+0x730],0x1
  40b855:	mov    r8d,DWORD PTR [rax+0x730]
  40b85c:	lea    r8,[r8+r8*4]
  40b860:	lea    r8,[rax+r8*8+0x738]
  40b868:	vmovups xmm1,XMMWORD PTR [r8]
  40b86d:	vmovups XMMWORD PTR [rcx],xmm1
  40b871:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40b877:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40b87c:	mov    rax,QWORD PTR [r8+0x20]
  40b880:	mov    QWORD PTR [rcx+0x20],rax
  40b884:	vpshufd xmm1,xmm0,0xee
  40b889:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40b88f:	mov    QWORD PTR [rsp+0x10],rdx
  40b894:	vmovq  rax,xmm0
  40b899:	mov    r15,rax
  40b89c:	test   r15,r15
  40b89f:	jne    40b8b7 <__swc_fn_0a4ed24b_000061_73a9baa2+0x337>
  40b8a1:	mov    rcx,rbx
  40b8a4:	mov    rdx,QWORD PTR [rsp+0x8]
  40b8a9:	mov    r8,r13
  40b8ac:	mov    r9,r12
  40b8af:	call   40b170 <__swc_fn_0a4ed24b_000055_ddf32775>
  40b8b4:	mov    r15,rax
  40b8b7:	test   r15,r15
  40b8ba:	je     40b8fb <__swc_fn_0a4ed24b_000061_73a9baa2+0x37b>
  40b8bc:	cmp    QWORD PTR [r12],r14
  40b8c0:	jae    40b8fb <__swc_fn_0a4ed24b_000061_73a9baa2+0x37b>
  40b8c2:	mov    rax,r15
  40b8c5:	add    rax,QWORD PTR [r12]
  40b8c9:	mov    rdx,r14
  40b8cc:	sub    rdx,QWORD PTR [r12]
  40b8d0:	mov    rcx,rax
  40b8d3:	call   4072a0 <__swc_fn_0a4ed24b_000003_81215399>
  40b8d8:	test   al,al
  40b8da:	je     40b8e3 <__swc_fn_0a4ed24b_000061_73a9baa2+0x363>
  40b8dc:	mov    QWORD PTR [rsp+0x10],r14
  40b8e1:	jmp    40b8fb <__swc_fn_0a4ed24b_000061_73a9baa2+0x37b>
  40b8e3:	mov    rcx,rbx
  40b8e6:	mov    rdx,r15
  40b8e9:	mov    r8,QWORD PTR [rsp+0x8]
  40b8ee:	mov    r9,QWORD PTR [rsp+0x10]
  40b8f3:	call   40b280 <__swc_fn_0a4ed24b_000058_01964a17>
  40b8f8:	xor    r15d,r15d
  40b8fb:	test   r15,r15
  40b8fe:	jne    40b97a <__swc_fn_0a4ed24b_000061_73a9baa2+0x3fa>
  40b900:	cmp    r14,0x10000
  40b907:	ja     40b90e <__swc_fn_0a4ed24b_000061_73a9baa2+0x38e>
  40b909:	mov    rax,r14
  40b90c:	jmp    40b95f <__swc_fn_0a4ed24b_000061_73a9baa2+0x3df>
  40b90e:	xor    eax,eax
  40b910:	lea    rcx,[r14-0x1]
  40b914:	lzcnt  rax,rcx
  40b919:	mov    ecx,0x3f
  40b91e:	sub    rcx,rax
  40b921:	mov    eax,0x1
  40b926:	lea    rcx,[rcx-0x3]
  40b92a:	shl    rax,cl
  40b92d:	mov    rcx,rax
  40b930:	cmp    rax,0x1000
  40b937:	mov    eax,0x1000
  40b93c:	cmovb  rcx,rax
  40b940:	mov    rdx,0xffffffffffffffff
  40b947:	sub    rdx,rcx
  40b94a:	mov    rax,r14
  40b94d:	lea    r8,[r14+rcx*1-0x1]
  40b952:	neg    rcx
  40b955:	and    r8,rcx
  40b958:	cmp    r14,rdx
  40b95b:	cmovbe rax,r8
  40b95f:	mov    QWORD PTR [rsp+0x8],rax
  40b964:	mov    QWORD PTR [rsp+0x10],r14
  40b969:	mov    rcx,rbx
  40b96c:	mov    rdx,rax
  40b96f:	mov    r8,r14
  40b972:	call   40ace0 <__swc_fn_0a4ed24b_000037_1e381f55>
  40b977:	mov    r15,rax
  40b97a:	test   r15,r15
  40b97d:	jne    40b98b <__swc_fn_0a4ed24b_000061_73a9baa2+0x40b>
  40b97f:	mov    r13,QWORD PTR [rsp+0x20]
  40b984:	mov    rsi,QWORD PTR [rsp+0x38]
  40b989:	jmp    40b9c7 <__swc_fn_0a4ed24b_000061_73a9baa2+0x447>
  40b98b:	mov    rax,r15
  40b98e:	add    rax,QWORD PTR [rsp+0x28]
  40b993:	mov    r13,QWORD PTR [rsp+0x20]
  40b998:	test   r13d,r13d
  40b99b:	mov    rcx,r13
  40b99e:	mov    edx,0x8
  40b9a3:	cmove  ecx,edx
  40b9a6:	dec    rcx
  40b9a9:	mov    rdx,0xffffffffffffffff
  40b9b0:	sub    rdx,rcx
  40b9b3:	cmp    rax,rdx
  40b9b6:	jbe    40b9bc <__swc_fn_0a4ed24b_000061_73a9baa2+0x43c>
  40b9b8:	xor    eax,eax
  40b9ba:	jmp    40b9c4 <__swc_fn_0a4ed24b_000061_73a9baa2+0x444>
  40b9bc:	add    rax,rcx
  40b9bf:	andn   rax,rcx,rax
  40b9c4:	mov    rsi,rax
  40b9c7:	mov    rax,QWORD PTR [rsp+0x8]
  40b9cc:	test   r15,r15
  40b9cf:	je     40b9d8 <__swc_fn_0a4ed24b_000061_73a9baa2+0x458>
  40b9d1:	mov    rdi,QWORD PTR [rsp+0x18]
  40b9d6:	jmp    40b9ea <__swc_fn_0a4ed24b_000061_73a9baa2+0x46a>
  40b9d8:	mov    rdi,QWORD PTR [rsp+0x18]
  40b9dd:	mov    QWORD PTR [rdi+0x40],0x0
  40b9e5:	jmp    40ba66 <__swc_fn_0a4ed24b_000061_73a9baa2+0x4e6>
  40b9ea:	lea    rdx,[rsi-0x58]
  40b9ee:	mov    QWORD PTR [rsi-0x58],r15
  40b9f2:	mov    QWORD PTR [rsi-0x50],rax
  40b9f6:	mov    rax,QWORD PTR [rsp+0x10]
  40b9fb:	mov    QWORD PTR [rsi-0x48],rax
  40b9ff:	mov    QWORD PTR [rsi-0x40],rsi
  40ba03:	mov    rax,QWORD PTR [rdi+0x48]
  40ba07:	mov    QWORD PTR [rsi-0x38],rax
  40ba0b:	mov    rax,QWORD PTR [rsp+0x30]
  40ba10:	mov    QWORD PTR [rsi-0x30],rax
  40ba14:	mov    DWORD PTR [rsi-0x10],r13d
  40ba18:	mov    QWORD PTR [rsi-0x28],0x0
  40ba20:	mov    QWORD PTR [rsi-0x20],0x0
  40ba28:	add    r15,QWORD PTR [r12]
  40ba2c:	sub    r15,rsi
  40ba2f:	mov    QWORD PTR [rsi-0x30],r15
  40ba33:	mov    rcx,QWORD PTR [rbx+0x250]
  40ba3a:	nop    WORD PTR [rax+rax*1+0x0]
  40ba40:	lea    r8,[rcx+r15*1]
  40ba44:	mov    rax,rcx
  40ba47:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40ba50:	cmp    rax,rcx
  40ba53:	je     40ba5a <__swc_fn_0a4ed24b_000061_73a9baa2+0x4da>
  40ba55:	mov    rcx,rax
  40ba58:	jmp    40ba40 <__swc_fn_0a4ed24b_000061_73a9baa2+0x4c0>
  40ba5a:	mov    rcx,rbx
  40ba5d:	call   40e510 <__swc_fn_0a4ed24b_000053_9aa81fa7>
  40ba62:	mov    QWORD PTR [rdi+0x40],rsi
  40ba66:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40ba6c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40ba72:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40ba78:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40ba7e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40ba87:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40ba90:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40ba99:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40baa2:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40baab:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40bab4:	add    rsp,0xf0
  40babb:	pop    rsi
  40babc:	pop    rdi
  40babd:	pop    r15
  40babf:	pop    r14
  40bac1:	pop    r13
  40bac3:	pop    r12
  40bac5:	pop    rbx
  40bac6:	ret
	...

000000000040bad0 <__swc_fn_0a4ed24b_000064_20100e91>:
  40bad0:	push   rbx
  40bad1:	push   r12
  40bad3:	push   rdi
  40bad4:	push   rsi
  40bad5:	sub    rsp,0xb8
  40badc:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40bae2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40bae8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40baee:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40baf4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40bafa:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40bb00:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40bb06:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40bb0f:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40bb18:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40bb21:	mov    rbx,rdx
  40bb24:	mov    r12,rcx
  40bb27:	cmp    DWORD PTR [rbx+0x58],0x0
  40bb2b:	je     40bb45 <__swc_fn_0a4ed24b_000064_20100e91+0x75>
  40bb2d:	mov    eax,DWORD PTR [rbx+0x58]
  40bb30:	sub    eax,0x1
  40bb33:	test   DWORD PTR [rbx+0x58],eax
  40bb36:	je     40bb45 <__swc_fn_0a4ed24b_000064_20100e91+0x75>
  40bb38:	mov    QWORD PTR [rbx+0x40],0x0
  40bb40:	jmp    40bd57 <__swc_fn_0a4ed24b_000064_20100e91+0x287>
  40bb45:	cmp    QWORD PTR [rbx+0x48],0x0
  40bb4a:	jne    40bb59 <__swc_fn_0a4ed24b_000064_20100e91+0x89>
  40bb4c:	mov    QWORD PTR [rbx+0x40],0x0
  40bb54:	jmp    40bd57 <__swc_fn_0a4ed24b_000064_20100e91+0x287>
  40bb59:	lea    rax,[rsp+0x8]
  40bb5e:	mov    rcx,QWORD PTR [rbx+0x48]
  40bb62:	cmp    rcx,0x8
  40bb66:	ja     40bb70 <__swc_fn_0a4ed24b_000064_20100e91+0xa0>
  40bb68:	mov    DWORD PTR [rax],0x0
  40bb6e:	jmp    40bbcb <__swc_fn_0a4ed24b_000064_20100e91+0xfb>
  40bb70:	cmp    rcx,0x80
  40bb77:	ja     40bb87 <__swc_fn_0a4ed24b_000064_20100e91+0xb7>
  40bb79:	lea    rcx,[rcx+0xf]
  40bb7d:	shr    rcx,0x4
  40bb81:	mov    DWORD PTR [rsp+0x8],ecx
  40bb85:	jmp    40bbcb <__swc_fn_0a4ed24b_000064_20100e91+0xfb>
  40bb87:	cmp    rcx,0x10000
  40bb8e:	jbe    40bb98 <__swc_fn_0a4ed24b_000064_20100e91+0xc8>
  40bb90:	mov    DWORD PTR [rax],0xffffffff
  40bb96:	jmp    40bbcb <__swc_fn_0a4ed24b_000064_20100e91+0xfb>
  40bb98:	dec    rcx
  40bb9b:	xor    edx,edx
  40bb9d:	lzcnt  rdx,rcx
  40bba2:	mov    r8d,0x3f
  40bba8:	sub    r8d,edx
  40bbab:	lea    edx,[r8-0x2]
  40bbaf:	shrx   rcx,rcx,rdx
  40bbb4:	and    ecx,0x3
  40bbb7:	lea    edx,[r8-0x7]
  40bbbb:	lea    edx,[rdx*4+0x0]
  40bbc2:	lea    edx,[rdx+0x9]
  40bbc5:	add    edx,ecx
  40bbc7:	mov    DWORD PTR [rsp+0x8],edx
  40bbcb:	cmp    DWORD PTR [rax],0x0
  40bbce:	jne    40bbde <__swc_fn_0a4ed24b_000064_20100e91+0x10e>
  40bbd0:	cmp    DWORD PTR [rbx+0x58],0x8
  40bbd4:	jbe    40bbde <__swc_fn_0a4ed24b_000064_20100e91+0x10e>
  40bbd6:	mov    DWORD PTR [rsp+0x8],0x1
  40bbde:	cmp    DWORD PTR [rbx+0x58],0x10
  40bbe2:	jbe    40bc61 <__swc_fn_0a4ed24b_000064_20100e91+0x191>
  40bbe8:	cmp    DWORD PTR [rbx+0x58],0x40
  40bbec:	ja     40bc61 <__swc_fn_0a4ed24b_000064_20100e91+0x191>
  40bbee:	cmp    DWORD PTR [rax],0xffffffff
  40bbf1:	je     40bc61 <__swc_fn_0a4ed24b_000064_20100e91+0x191>
  40bbf3:	mov    ecx,DWORD PTR [rsp+0x8]
  40bbf7:	mov    edx,DWORD PTR [rbx+0x58]
  40bbfa:	dec    rdx
  40bbfd:	cmp    ecx,0x2d
  40bc00:	jae    40bc58 <__swc_fn_0a4ed24b_000064_20100e91+0x188>
  40bc02:	cs nop WORD PTR [rax+rax*1+0x0]
  40bc0c:	nop    DWORD PTR [rax+0x0]
  40bc10:	mov    r8d,ecx
  40bc13:	test   ecx,ecx
  40bc15:	jne    40bc1f <__swc_fn_0a4ed24b_000064_20100e91+0x14f>
  40bc17:	mov    r8d,0x8
  40bc1d:	jmp    40bc4b <__swc_fn_0a4ed24b_000064_20100e91+0x17b>
  40bc1f:	cmp    r8d,0x8
  40bc23:	ja     40bc2b <__swc_fn_0a4ed24b_000064_20100e91+0x15b>
  40bc25:	shl    r8,0x4
  40bc29:	jmp    40bc4b <__swc_fn_0a4ed24b_000064_20100e91+0x17b>
  40bc2b:	lea    r8d,[r8-0x9]
  40bc2f:	mov    r9d,r8d
  40bc32:	shr    r9d,0x2
  40bc36:	and    r8d,0x3
  40bc3a:	lea    r9d,[r9+0x7]
  40bc3e:	lea    r9d,[r9-0x2]
  40bc42:	lea    r8d,[r8+0x5]
  40bc46:	shlx   r8,r8,r9
  40bc4b:	test   r8,rdx
  40bc4e:	je     40bc5d <__swc_fn_0a4ed24b_000064_20100e91+0x18d>
  40bc50:	add    ecx,0x1
  40bc53:	cmp    ecx,0x2d
  40bc56:	jb     40bc10 <__swc_fn_0a4ed24b_000064_20100e91+0x140>
  40bc58:	mov    ecx,0xffffffff
  40bc5d:	mov    DWORD PTR [rsp+0x8],ecx
  40bc61:	mov    ecx,DWORD PTR [rsp+0x8]
  40bc65:	cmp    ecx,0xffffffff
  40bc68:	je     40bc70 <__swc_fn_0a4ed24b_000064_20100e91+0x1a0>
  40bc6a:	cmp    DWORD PTR [rbx+0x58],0x40
  40bc6e:	jbe    40bc83 <__swc_fn_0a4ed24b_000064_20100e91+0x1b3>
  40bc70:	mov    rcx,r12
  40bc73:	mov    rdx,rbx
  40bc76:	mov    r8d,DWORD PTR [rax]
  40bc79:	call   40b580 <__swc_fn_0a4ed24b_000061_73a9baa2>
  40bc7e:	jmp    40bd57 <__swc_fn_0a4ed24b_000064_20100e91+0x287>
  40bc83:	lea    rax,[rip+0x16376]        # 422000 <__swc_data_base_0a4ed24b>
  40bc8a:	mov    rax,QWORD PTR [rax]
  40bc8d:	cmp    rax,0xffffffffffffffff
  40bc91:	je     40bca0 <__swc_fn_0a4ed24b_000064_20100e91+0x1d0>
  40bc93:	mov    eax,eax
  40bc95:	mov    edi,eax
  40bc97:	xor    eax,eax
  40bc99:	call   407000 <pthread_getspecific@plt>
  40bc9e:	jmp    40bca2 <__swc_fn_0a4ed24b_000064_20100e91+0x1d2>
  40bca0:	xor    eax,eax
  40bca2:	test   rax,rax
  40bca5:	jne    40bcb4 <__swc_fn_0a4ed24b_000064_20100e91+0x1e4>
  40bca7:	call   40ac20 <__swc_fn_0a4ed24b_000031_3c3e930e>
  40bcac:	mov    rcx,rax
  40bcaf:	call   4101e0 <__swc_fn_0a4ed24b_000128_8d8a7dd2>
  40bcb4:	test   rax,rax
  40bcb7:	je     40bcc4 <__swc_fn_0a4ed24b_000064_20100e91+0x1f4>
  40bcb9:	cmp    QWORD PTR [rax],r12
  40bcbc:	jne    40bcc4 <__swc_fn_0a4ed24b_000064_20100e91+0x1f4>
  40bcbe:	cmp    DWORD PTR [rax+0x20],0x0
  40bcc2:	je     40bccf <__swc_fn_0a4ed24b_000064_20100e91+0x1ff>
  40bcc4:	mov    rcx,r12
  40bcc7:	mov    rdx,rax
  40bcca:	call   40e150 <__swc_fn_0a4ed24b_000041_41400651>
  40bccf:	test   rax,rax
  40bcd2:	jne    40bcde <__swc_fn_0a4ed24b_000064_20100e91+0x20e>
  40bcd4:	mov    QWORD PTR [rbx+0x40],0x0
  40bcdc:	jmp    40bd57 <__swc_fn_0a4ed24b_000064_20100e91+0x287>
  40bcde:	lea    r8,[rsp+0xc]
  40bce3:	mov    ecx,DWORD PTR [rsp+0x8]
  40bce7:	mov    DWORD PTR [rsp+0xc],ecx
  40bceb:	mov    ecx,DWORD PTR [r8]
  40bcee:	lea    rcx,[rcx+rcx*4]
  40bcf2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40bcf7:	test   rcx,rcx
  40bcfa:	je     40bd33 <__swc_fn_0a4ed24b_000064_20100e91+0x263>
  40bcfc:	mov    rdx,QWORD PTR [rcx]
  40bcff:	test   rdx,rdx
  40bd02:	je     40bd10 <__swc_fn_0a4ed24b_000064_20100e91+0x240>
  40bd04:	mov    r9,QWORD PTR [rdx]
  40bd07:	mov    QWORD PTR [rcx],r9
  40bd0a:	add    DWORD PTR [rcx+0x28],0x1
  40bd0e:	jmp    40bd2e <__swc_fn_0a4ed24b_000064_20100e91+0x25e>
  40bd10:	mov    rdx,QWORD PTR [rcx+0x18]
  40bd14:	cmp    QWORD PTR [rcx+0x20],rdx
  40bd18:	jae    40bd2c <__swc_fn_0a4ed24b_000064_20100e91+0x25c>
  40bd1a:	mov    rdx,QWORD PTR [rcx+0x20]
  40bd1e:	mov    r9d,DWORD PTR [rcx+0x2c]
  40bd22:	add    QWORD PTR [rcx+0x20],r9
  40bd26:	add    DWORD PTR [rcx+0x28],0x1
  40bd2a:	jmp    40bd2e <__swc_fn_0a4ed24b_000064_20100e91+0x25e>
  40bd2c:	xor    edx,edx
  40bd2e:	test   rdx,rdx
  40bd31:	jne    40bd44 <__swc_fn_0a4ed24b_000064_20100e91+0x274>
  40bd33:	mov    rcx,r12
  40bd36:	mov    rdx,rax
  40bd39:	mov    r8d,DWORD PTR [r8]
  40bd3c:	call   40e2c0 <__swc_fn_0a4ed24b_000050_5e919db9>
  40bd41:	mov    rdx,rax
  40bd44:	test   rdx,rdx
  40bd47:	jne    40bd53 <__swc_fn_0a4ed24b_000064_20100e91+0x283>
  40bd49:	mov    QWORD PTR [rbx+0x40],0x0
  40bd51:	jmp    40bd57 <__swc_fn_0a4ed24b_000064_20100e91+0x287>
  40bd53:	mov    QWORD PTR [rbx+0x40],rdx
  40bd57:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40bd5d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40bd63:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40bd69:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40bd6f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40bd75:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40bd7b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40bd81:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40bd8a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40bd93:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40bd9c:	add    rsp,0xb8
  40bda3:	pop    rsi
  40bda4:	pop    rdi
  40bda5:	pop    r12
  40bda7:	pop    rbx
  40bda8:	ret
  40bda9:	add    BYTE PTR [rax],al
  40bdab:	add    BYTE PTR [rax],al
  40bdad:	add    BYTE PTR [rax],al
	...

000000000040bdb0 <__swc_fn_0a4ed24b_000067_0145abfc>:
  40bdb0:	ret
	...

000000000040bdc0 <__swc_fn_0a4ed24b_000070_357c932c>:
  40bdc0:	push   r12
  40bdc2:	push   r13
  40bdc4:	push   r14
  40bdc6:	push   rdi
  40bdc7:	push   rsi
  40bdc8:	sub    rsp,0x1a0
  40bdcf:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40bdd8:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40bde1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40bdea:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40bdf3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40bdfc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40be05:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40be0e:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40be17:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40be20:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40be29:	mov    r12,rdx
  40be2c:	mov    r13,rcx
  40be2f:	mov    rax,QWORD PTR [r12+0x48]
  40be34:	mov    ecx,DWORD PTR [r12+0x58]
  40be39:	lea    rdx,[rax-0x1]
  40be3d:	cmp    rdx,0x10000
  40be44:	jae    40bf3e <__swc_fn_0a4ed24b_000070_357c932c+0x17e>
  40be4a:	cmp    rax,0x8
  40be4e:	ja     40be55 <__swc_fn_0a4ed24b_000070_357c932c+0x95>
  40be50:	xor    r14d,r14d
  40be53:	jmp    40bea7 <__swc_fn_0a4ed24b_000070_357c932c+0xe7>
  40be55:	cmp    rax,0x80
  40be5c:	ja     40be68 <__swc_fn_0a4ed24b_000070_357c932c+0xa8>
  40be5e:	lea    r14,[rax+0xf]
  40be62:	shr    r14,0x4
  40be66:	jmp    40bea7 <__swc_fn_0a4ed24b_000070_357c932c+0xe7>
  40be68:	cmp    rax,0x10000
  40be6f:	jbe    40be79 <__swc_fn_0a4ed24b_000070_357c932c+0xb9>
  40be71:	mov    r14d,0xffffffff
  40be77:	jmp    40bea7 <__swc_fn_0a4ed24b_000070_357c932c+0xe7>
  40be79:	xor    eax,eax
  40be7b:	lzcnt  rax,rdx
  40be80:	mov    r8d,0x3f
  40be86:	sub    r8d,eax
  40be89:	lea    eax,[r8-0x2]
  40be8d:	shrx   rax,rdx,rax
  40be92:	and    eax,0x3
  40be95:	lea    edx,[r8-0x7]
  40be99:	lea    edx,[rdx*4+0x0]
  40bea0:	lea    edx,[rdx+0x9]
  40bea3:	lea    r14d,[rdx+rax*1]
  40bea7:	cmp    ecx,0x8
  40beaa:	jbe    40bec3 <__swc_fn_0a4ed24b_000070_357c932c+0x103>
  40beac:	cmp    ecx,0x10
  40beaf:	jne    40bf3e <__swc_fn_0a4ed24b_000070_357c932c+0x17e>
  40beb5:	test   r14d,r14d
  40beb8:	mov    eax,0x1
  40bebd:	cmove  r14d,eax
  40bec1:	jmp    40beca <__swc_fn_0a4ed24b_000070_357c932c+0x10a>
  40bec3:	lea    eax,[rcx-0x1]
  40bec6:	test   eax,ecx
  40bec8:	jne    40bf3e <__swc_fn_0a4ed24b_000070_357c932c+0x17e>
  40beca:	lea    rax,[rip+0x1612f]        # 422000 <__swc_data_base_0a4ed24b>
  40bed1:	mov    rax,QWORD PTR [rax]
  40bed4:	cmp    rax,0xffffffffffffffff
  40bed8:	je     40bee7 <__swc_fn_0a4ed24b_000070_357c932c+0x127>
  40beda:	mov    eax,eax
  40bedc:	mov    edi,eax
  40bede:	xor    eax,eax
  40bee0:	call   407000 <pthread_getspecific@plt>
  40bee5:	jmp    40bee9 <__swc_fn_0a4ed24b_000070_357c932c+0x129>
  40bee7:	xor    eax,eax
  40bee9:	test   rax,rax
  40beec:	je     40bf3e <__swc_fn_0a4ed24b_000070_357c932c+0x17e>
  40beee:	cmp    QWORD PTR [rax],r13
  40bef1:	jne    40bf3e <__swc_fn_0a4ed24b_000070_357c932c+0x17e>
  40bef3:	lea    rcx,[r14+r14*4]
  40bef7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40befc:	test   rax,rax
  40beff:	je     40bf3e <__swc_fn_0a4ed24b_000070_357c932c+0x17e>
  40bf01:	mov    rcx,QWORD PTR [rax]
  40bf04:	test   rcx,rcx
  40bf07:	je     40bf15 <__swc_fn_0a4ed24b_000070_357c932c+0x155>
  40bf09:	mov    rdx,QWORD PTR [rcx]
  40bf0c:	mov    QWORD PTR [rax],rdx
  40bf0f:	add    DWORD PTR [rax+0x28],0x1
  40bf13:	jmp    40bf32 <__swc_fn_0a4ed24b_000070_357c932c+0x172>
  40bf15:	mov    rcx,QWORD PTR [rax+0x18]
  40bf19:	cmp    QWORD PTR [rax+0x20],rcx
  40bf1d:	jae    40bf30 <__swc_fn_0a4ed24b_000070_357c932c+0x170>
  40bf1f:	mov    rcx,QWORD PTR [rax+0x20]
  40bf23:	mov    edx,DWORD PTR [rax+0x2c]
  40bf26:	add    QWORD PTR [rax+0x20],rdx
  40bf2a:	add    DWORD PTR [rax+0x28],0x1
  40bf2e:	jmp    40bf32 <__swc_fn_0a4ed24b_000070_357c932c+0x172>
  40bf30:	xor    ecx,ecx
  40bf32:	test   rcx,rcx
  40bf35:	je     40bf3e <__swc_fn_0a4ed24b_000070_357c932c+0x17e>
  40bf37:	mov    QWORD PTR [r12+0x40],rcx
  40bf3c:	jmp    40bf49 <__swc_fn_0a4ed24b_000070_357c932c+0x189>
  40bf3e:	mov    rcx,r13
  40bf41:	mov    rdx,r12
  40bf44:	call   40ed40 <__swc_fn_0a4ed24b_000071_1e1e3bf8>
  40bf49:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40bf52:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40bf5b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40bf64:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40bf6d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40bf76:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40bf7f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40bf88:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40bf91:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40bf9a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40bfa3:	add    rsp,0x1a0
  40bfaa:	pop    rsi
  40bfab:	pop    rdi
  40bfac:	pop    r14
  40bfae:	pop    r13
  40bfb0:	pop    r12
  40bfb2:	ret
	...

000000000040bfc0 <__swc_fn_0a4ed24b_000073_cdd57f51>:
  40bfc0:	push   r12
  40bfc2:	push   r13
  40bfc4:	push   r14
  40bfc6:	push   r15
  40bfc8:	push   rdi
  40bfc9:	push   rsi
  40bfca:	sub    rsp,0x188
  40bfd1:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40bfda:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40bfe3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40bfec:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40bff5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40bffe:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40c007:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40c010:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40c019:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40c022:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40c02b:	mov    r12,rdx
  40c02e:	mov    r13,rcx
  40c031:	mov    r14,QWORD PTR [r12+0x40]
  40c036:	lea    rax,[rip+0x18033]        # 424070 <__swc_bss_base_0a4ed24b+0x30>
  40c03d:	mov    rcx,r14
  40c040:	sub    rcx,QWORD PTR [rax+0x8]
  40c044:	mov    rax,QWORD PTR [rip+0x18035]        # 424080 <__swc_bss_base_0a4ed24b+0x40>
  40c04b:	cmp    rcx,rax
  40c04e:	jae    40c07a <__swc_fn_0a4ed24b_000073_cdd57f51+0xba>
  40c050:	mov    rax,r14
  40c053:	and    rax,0xffffffffffc00000
  40c05a:	mov    rcx,r14
  40c05d:	shr    rcx,0x10
  40c061:	and    ecx,0x3f
  40c064:	mov    edx,DWORD PTR [rax+0x28]
  40c067:	shrx   ecx,ecx,edx
  40c06c:	shl    rcx,0x4
  40c070:	lea    r15,[rax+rcx*8+0x80]
  40c078:	jmp    40c085 <__swc_fn_0a4ed24b_000073_cdd57f51+0xc5>
  40c07a:	mov    rcx,r14
  40c07d:	call   40ab50 <__swc_fn_0a4ed24b_000022_53fc00d2>
  40c082:	mov    r15,rax
  40c085:	test   r15,r15
  40c088:	je     40c12f <__swc_fn_0a4ed24b_000073_cdd57f51+0x16f>
  40c08e:	lea    rax,[rip+0x15f6b]        # 422000 <__swc_data_base_0a4ed24b>
  40c095:	mov    rax,QWORD PTR [rax]
  40c098:	cmp    rax,0xffffffffffffffff
  40c09c:	je     40c0ab <__swc_fn_0a4ed24b_000073_cdd57f51+0xeb>
  40c09e:	mov    eax,eax
  40c0a0:	mov    edi,eax
  40c0a2:	xor    eax,eax
  40c0a4:	call   407000 <pthread_getspecific@plt>
  40c0a9:	jmp    40c0ad <__swc_fn_0a4ed24b_000073_cdd57f51+0xed>
  40c0ab:	xor    eax,eax
  40c0ad:	mov    rcx,QWORD PTR [r15+0x40]
  40c0b1:	cmp    rcx,rax
  40c0b4:	jne    40c114 <__swc_fn_0a4ed24b_000073_cdd57f51+0x154>
  40c0b6:	test   rax,rax
  40c0b9:	je     40c12f <__swc_fn_0a4ed24b_000073_cdd57f51+0x16f>
  40c0bb:	mov    ecx,DWORD PTR [r15+0x6c]
  40c0bf:	test   ecx,ecx
  40c0c1:	je     40c0e1 <__swc_fn_0a4ed24b_000073_cdd57f51+0x121>
  40c0c3:	mov    rcx,r13
  40c0c6:	mov    rdx,rax
  40c0c9:	mov    r8,r15
  40c0cc:	mov    QWORD PTR [rsp+0xd8],rax
  40c0d4:	call   40e250 <__swc_fn_0a4ed24b_000047_e7fd8d42>
  40c0d9:	mov    rax,QWORD PTR [rsp+0xd8]
  40c0e1:	mov    rcx,QWORD PTR [r15]
  40c0e4:	mov    QWORD PTR [r14],rcx
  40c0e7:	mov    QWORD PTR [r15],r14
  40c0ea:	sub    DWORD PTR [r15+0x28],0x1
  40c0ef:	jne    40c124 <__swc_fn_0a4ed24b_000073_cdd57f51+0x164>
  40c0f1:	movzx  ecx,BYTE PTR [r15+0x39]
  40c0f6:	lea    rcx,[rcx+rcx*4]
  40c0fa:	lea    rcx,[rax+rcx*8+0x28]
  40c0ff:	cmp    QWORD PTR [rcx],r15
  40c102:	je     40c124 <__swc_fn_0a4ed24b_000073_cdd57f51+0x164>
  40c104:	mov    rcx,r13
  40c107:	mov    rdx,rax
  40c10a:	mov    r8,r15
  40c10d:	call   407d80 <__swc_fn_0a4ed24b_000051_27d2a35f>
  40c112:	jmp    40c124 <__swc_fn_0a4ed24b_000073_cdd57f51+0x164>
  40c114:	test   rcx,rcx
  40c117:	je     40c12f <__swc_fn_0a4ed24b_000073_cdd57f51+0x16f>
  40c119:	mov    rcx,r15
  40c11c:	mov    rdx,r14
  40c11f:	call   40a790 <__swc_fn_0a4ed24b_000010_0569f799>
  40c124:	mov    QWORD PTR [r12+0x40],0x0
  40c12d:	jmp    40c13a <__swc_fn_0a4ed24b_000073_cdd57f51+0x17a>
  40c12f:	mov    rcx,r13
  40c132:	mov    rdx,r12
  40c135:	call   40ed60 <__swc_fn_0a4ed24b_000074_30b8696a>
  40c13a:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40c143:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40c14c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40c155:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40c15e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40c167:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40c170:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40c179:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40c182:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40c18b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40c194:	add    rsp,0x188
  40c19b:	pop    rsi
  40c19c:	pop    rdi
  40c19d:	pop    r15
  40c19f:	pop    r14
  40c1a1:	pop    r13
  40c1a3:	pop    r12
  40c1a5:	ret
	...

000000000040c1b0 <__swc_fn_0a4ed24b_000076_c3ad0fb4>:
  40c1b0:	sub    rsp,0x8
  40c1b4:	mov    rax,rdx
  40c1b7:	mov    rdx,QWORD PTR [rax+0x40]
  40c1bb:	mov    r8,rax
  40c1be:	call   40bdb0 <__swc_fn_0a4ed24b_000067_0145abfc>
  40c1c3:	add    rsp,0x8
  40c1c7:	ret
	...

000000000040c1d0 <__swc_fn_0a4ed24b_000079_633af784>:
  40c1d0:	push   rsi
  40c1d1:	push   rdi
  40c1d2:	sub    rsp,0x8
  40c1d6:	cmp    rcx,0xffffffffffffffef
  40c1da:	ja     40c200 <__swc_fn_0a4ed24b_000079_633af784+0x30>
  40c1dc:	xor    esi,esi
  40c1de:	lea    rax,[rcx+0x100f]
  40c1e5:	and    rax,0xfffffffffffff000
  40c1ec:	lea    rcx,[rcx+0x10]
  40c1f0:	cmp    rcx,0xfffffffffffff000
  40c1f7:	cmovbe rsi,rax
  40c1fb:	test   rsi,rsi
  40c1fe:	jne    40c209 <__swc_fn_0a4ed24b_000079_633af784+0x39>
  40c200:	xor    eax,eax
  40c202:	add    rsp,0x8
  40c206:	pop    rdi
  40c207:	pop    rsi
  40c208:	ret
  40c209:	mov    rcx,rsi
  40c20c:	call   40c860 <__swc_fn_0a4ed24b_000109_9f5af8ae>
  40c211:	mov    rdi,rax
  40c214:	test   rax,rax
  40c217:	jne    40c222 <__swc_fn_0a4ed24b_000079_633af784+0x52>
  40c219:	xor    eax,eax
  40c21b:	add    rsp,0x8
  40c21f:	pop    rdi
  40c220:	pop    rsi
  40c221:	ret
  40c222:	mov    rcx,rdi
  40c225:	mov    rdx,rsi
  40c228:	call   409240 <__swc_fn_0a4ed24b_000111_f9e19033>
  40c22d:	test   al,al
  40c22f:	jne    40c245 <__swc_fn_0a4ed24b_000079_633af784+0x75>
  40c231:	mov    rcx,rdi
  40c234:	mov    rdx,rsi
  40c237:	call   40fe90 <__swc_fn_0a4ed24b_000113_4e83a03a>
  40c23c:	xor    eax,eax
  40c23e:	add    rsp,0x8
  40c242:	pop    rdi
  40c243:	pop    rsi
  40c244:	ret
  40c245:	mov    QWORD PTR [rdi],rsi
  40c248:	mov    QWORD PTR [rdi+0x8],0x0
  40c250:	lea    rax,[rdi+0x10]
  40c254:	add    rsp,0x8
  40c258:	pop    rdi
  40c259:	pop    rsi
  40c25a:	ret
  40c25b:	add    BYTE PTR [rax],al
  40c25d:	add    BYTE PTR [rax],al
	...

000000000040c260 <__swc_fn_0a4ed24b_000082_ff7d1455>:
  40c260:	sub    rsp,0x8
  40c264:	cmp    BYTE PTR [rcx+0x2c],0x10
  40c268:	jne    40c273 <__swc_fn_0a4ed24b_000082_ff7d1455+0x13>
  40c26a:	test   DWORD PTR [rcx+0x28],0x80
  40c271:	je     40c27b <__swc_fn_0a4ed24b_000082_ff7d1455+0x1b>
  40c273:	mov    rax,rcx
  40c276:	add    rsp,0x8
  40c27a:	ret
  40c27b:	mov    rcx,QWORD PTR [rcx+0x40]
  40c27f:	call   40c260 <__swc_fn_0a4ed24b_000082_ff7d1455>
  40c284:	add    rsp,0x8
  40c288:	ret
	...

000000000040c2a0 <__swc_fn_0a4ed24b_000085_e24ecd12>:
  40c2a0:	push   rsi
  40c2a1:	push   rdi
  40c2a2:	push   r12
  40c2a4:	push   r13
  40c2a6:	sub    rsp,0x8
  40c2aa:	mov    rsi,rdx
  40c2ad:	mov    rdi,rcx
  40c2b0:	xor    r8d,r8d
  40c2b3:	call   4085a0 <__swc_fn_0a4ed24b_000090_14cf59b2>
  40c2b8:	test   al,al
  40c2ba:	je     40c2cc <__swc_fn_0a4ed24b_000085_e24ecd12+0x2c>
  40c2bc:	mov    eax,0x1
  40c2c1:	add    rsp,0x8
  40c2c5:	pop    r13
  40c2c7:	pop    r12
  40c2c9:	pop    rdi
  40c2ca:	pop    rsi
  40c2cb:	ret
  40c2cc:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40c2d1:	je     40c2e0 <__swc_fn_0a4ed24b_000085_e24ecd12+0x40>
  40c2d3:	xor    eax,eax
  40c2d5:	add    rsp,0x8
  40c2d9:	pop    r13
  40c2db:	pop    r12
  40c2dd:	pop    rdi
  40c2de:	pop    rsi
  40c2df:	ret
  40c2e0:	mov    r12,QWORD PTR [rsi+0x98]
  40c2e7:	mov    rax,QWORD PTR [rsi+0xa0]
  40c2ee:	mov    rsi,rax
  40c2f1:	xor    r13d,r13d
  40c2f4:	test   rsi,rsi
  40c2f7:	je     40c354 <__swc_fn_0a4ed24b_000085_e24ecd12+0xb4>
  40c2f9:	cs nop WORD PTR [rax+rax*1+0x0]
  40c303:	cs nop WORD PTR [rax+rax*1+0x0]
  40c30d:	nop    DWORD PTR [rax]
  40c310:	lea    rax,[r13*8+0x0]
  40c318:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40c31d:	mov    rcx,rax
  40c320:	call   40c260 <__swc_fn_0a4ed24b_000082_ff7d1455>
  40c325:	cmp    BYTE PTR [rax+0x2c],0xe
  40c329:	jne    40c34a <__swc_fn_0a4ed24b_000085_e24ecd12+0xaa>
  40c32b:	mov    rcx,rdi
  40c32e:	mov    rdx,rax
  40c331:	call   40c2a0 <__swc_fn_0a4ed24b_000085_e24ecd12>
  40c336:	test   al,al
  40c338:	je     40c34a <__swc_fn_0a4ed24b_000085_e24ecd12+0xaa>
  40c33a:	mov    eax,0x1
  40c33f:	add    rsp,0x8
  40c343:	pop    r13
  40c345:	pop    r12
  40c347:	pop    rdi
  40c348:	pop    rsi
  40c349:	ret
  40c34a:	add    r13,0x1
  40c34e:	sub    rsi,0x1
  40c352:	jne    40c310 <__swc_fn_0a4ed24b_000085_e24ecd12+0x70>
  40c354:	xor    eax,eax
  40c356:	add    rsp,0x8
  40c35a:	pop    r13
  40c35c:	pop    r12
  40c35e:	pop    rdi
  40c35f:	pop    rsi
  40c360:	ret
	...

000000000040c370 <__swc_fn_0a4ed24b_000088_ab2f35d8>:
  40c370:	sub    rsp,0x18
  40c374:	vxorps xmm0,xmm0,xmm0
  40c378:	vmovdqu XMMWORD PTR [rsp],xmm0
  40c37d:	call   40ef70 <__swc_fn_0a4ed24b_000089_3c530920>
  40c382:	add    rsp,0x18
  40c386:	ret
	...

000000000040c390 <__swc_fn_0a4ed24b_000091_f21926ed>:
  40c390:	sub    rsp,0x8
  40c394:	mov    rcx,QWORD PTR [rip+0x1a9a5]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40c39b:	test   rcx,rcx
  40c39e:	jne    40c3b0 <__swc_fn_0a4ed24b_000091_f21926ed+0x20>
  40c3a0:	call   40a1a0 <__swc_fn_0a4ed24b_000165_56054fe7>
  40c3a5:	lea    rcx,[rax+0x1]
  40c3a9:	mov    QWORD PTR [rip+0x1a990],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40c3b0:	dec    rcx
  40c3b3:	call   411c60 <__swc_fn_0a4ed24b_000167_39c041ad>
  40c3b8:	mov    rax,QWORD PTR [rax+0xc0]
  40c3bf:	and    eax,0x1
  40c3c2:	setne  al
  40c3c5:	add    rsp,0x8
  40c3c9:	ret
	...

000000000040c3e0 <__swc_fn_0a4ed24b_000094_383a814c>:
  40c3e0:	push   rbx
  40c3e1:	push   rsi
  40c3e2:	push   rdi
  40c3e3:	push   r12
  40c3e5:	sub    rsp,0x28
  40c3e9:	mov    rbx,rcx
  40c3ec:	call   408900 <__swc_fn_0a4ed24b_000093_0c97fc6c>
  40c3f1:	mov    rcx,QWORD PTR [rip+0x1a948]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40c3f8:	test   rcx,rcx
  40c3fb:	jne    40c40d <__swc_fn_0a4ed24b_000094_383a814c+0x2d>
  40c3fd:	call   40a1a0 <__swc_fn_0a4ed24b_000165_56054fe7>
  40c402:	lea    rcx,[rax+0x1]
  40c406:	mov    QWORD PTR [rip+0x1a933],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40c40d:	dec    rcx
  40c410:	call   411c60 <__swc_fn_0a4ed24b_000167_39c041ad>
  40c415:	mov    rsi,rax
  40c418:	lea    rcx,[rsp+0x8]
  40c41d:	call   40f3b0 <__swc_fn_0a4ed24b_000092_809deff5>
  40c422:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40c429:	mov    r12,QWORD PTR [rsi+0xbe8]
  40c430:	lea    rcx,[rsi+0x10]
  40c434:	call   40d3b0 <__swc_fn_0a4ed24b_000157_3495a3ca>
  40c439:	mov    rcx,rsi
  40c43c:	call   40f520 <__swc_fn_0a4ed24b_000101_afcb7774>
  40c441:	vxorps xmm0,xmm0,xmm0
  40c445:	xor    eax,eax
  40c447:	cs nop WORD PTR [rax+rax*1+0x0]
  40c451:	cs nop WORD PTR [rax+rax*1+0x0]
  40c45b:	nop    DWORD PTR [rax+rax*1+0x0]
  40c460:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40c465:	add    rax,0x10
  40c469:	cmp    rax,0xbf0
  40c470:	jne    40c460 <__swc_fn_0a4ed24b_000094_383a814c+0x80>
  40c472:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c478:	vmovups XMMWORD PTR [rsi],xmm0
  40c47c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c482:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40c48a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40c491:	mov    QWORD PTR [rsi+0xbe8],r12
  40c498:	mov    rcx,QWORD PTR [rip+0x1a8a1]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40c49f:	test   rcx,rcx
  40c4a2:	jne    40c4b4 <__swc_fn_0a4ed24b_000094_383a814c+0xd4>
  40c4a4:	call   40a1a0 <__swc_fn_0a4ed24b_000165_56054fe7>
  40c4a9:	lea    rcx,[rax+0x1]
  40c4ad:	mov    QWORD PTR [rip+0x1a88c],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40c4b4:	dec    rcx
  40c4b7:	call   411c60 <__swc_fn_0a4ed24b_000167_39c041ad>
  40c4bc:	mov    rsi,rax
  40c4bf:	mov    QWORD PTR [rsi+0xc0],rbx
  40c4c6:	and    ebx,0x1
  40c4c9:	jne    40c4cd <__swc_fn_0a4ed24b_000094_383a814c+0xed>
  40c4cb:	xor    eax,eax
  40c4cd:	test   rbx,rbx
  40c4d0:	sete   al
  40c4d3:	xor    cl,cl
  40c4d5:	xor    dl,dl
  40c4d7:	xor    r8b,r8b
  40c4da:	xor    r9b,r9b
  40c4dd:	xor    r10b,r10b
  40c4e0:	mov    r11,rax
  40c4e3:	call   40ed70 <__swc_fn_0a4ed24b_000077_948ef603>
  40c4e8:	lea    rbx,[rsp+0x18]
  40c4ed:	mov    rcx,rbx
  40c4f0:	call   40f3b0 <__swc_fn_0a4ed24b_000092_809deff5>
  40c4f5:	lea    rcx,[rsi+0x10]
  40c4f9:	mov    edx,0x400000
  40c4fe:	mov    r8,rbx
  40c501:	call   409ee0 <__swc_fn_0a4ed24b_000159_6861d596>
  40c506:	lea    rcx,[rsi+0x68]
  40c50a:	mov    edx,0x4000
  40c50f:	mov    r8,rbx
  40c512:	call   409ee0 <__swc_fn_0a4ed24b_000159_6861d596>
  40c517:	add    rsp,0x28
  40c51b:	pop    r12
  40c51d:	pop    rdi
  40c51e:	pop    rsi
  40c51f:	pop    rbx
  40c520:	ret
	...

000000000040c530 <__swc_fn_0a4ed24b_000097_96d6739a>:
  40c530:	push   rbx
  40c531:	push   rsi
  40c532:	sub    rsp,0x18
  40c536:	mov    rbx,rcx
  40c539:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40c53e:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c544:	mov    rsi,QWORD PTR [rbx+0x70]
  40c548:	lea    rcx,[rcx+0x18]
  40c54c:	call   40d3b0 <__swc_fn_0a4ed24b_000157_3495a3ca>
  40c551:	lea    rcx,[rsp+0x8]
  40c556:	mov    rdx,rbx
  40c559:	mov    r8d,0x78
  40c55f:	call   408960 <__swc_fn_0a4ed24b_000096_a4baaa40>
  40c564:	mov    rax,rsi
  40c567:	add    rsp,0x18
  40c56b:	pop    rsi
  40c56c:	pop    rbx
  40c56d:	ret
	...

000000000040c570 <__swc_fn_0a4ed24b_000100_5714513e>:
  40c570:	push   rsi
  40c571:	push   rdi
  40c572:	sub    rsp,0x8
  40c576:	cmp    QWORD PTR [rcx],0x0
  40c57a:	jne    40c583 <__swc_fn_0a4ed24b_000100_5714513e+0x13>
  40c57c:	add    rsp,0x8
  40c580:	pop    rdi
  40c581:	pop    rsi
  40c582:	ret
  40c583:	mov    rsi,QWORD PTR [rcx]
  40c586:	mov    rax,QWORD PTR [rcx+0x8]
  40c58a:	test   rax,rax
  40c58d:	je     40c5a3 <__swc_fn_0a4ed24b_000100_5714513e+0x33>
  40c58f:	test   DWORD PTR [rax+0x28],0x400000
  40c596:	je     40c5a3 <__swc_fn_0a4ed24b_000100_5714513e+0x33>
  40c598:	mov    rcx,QWORD PTR [rax+0x30]
  40c59c:	test   rcx,rcx
  40c59f:	cmovne rax,rcx
  40c5a3:	lea    rdx,[rip+0x6c26]        # 4131d0 <__swc_rdata_base_0a4ed24b+0xc0>
  40c5aa:	lea    rcx,[rip+0x6d07]        # 4132b8 <__swc_rdata_base_0a4ed24b+0x1a8>
  40c5b1:	mov    r8,rax
  40c5b4:	xor    r9d,r9d
  40c5b7:	xor    al,al
  40c5b9:	mov    r10,rax
  40c5bc:	xor    r11d,r11d
  40c5bf:	call   40c370 <__swc_fn_0a4ed24b_000088_ab2f35d8>
  40c5c4:	test   rax,rax
  40c5c7:	je     40c5d7 <__swc_fn_0a4ed24b_000100_5714513e+0x67>
  40c5c9:	mov    rdi,QWORD PTR [rax+0x48]
  40c5cd:	test   rdi,rdi
  40c5d0:	je     40c5d7 <__swc_fn_0a4ed24b_000100_5714513e+0x67>
  40c5d2:	mov    rcx,rsi
  40c5d5:	call   rdi
  40c5d7:	add    rsp,0x8
  40c5db:	pop    rdi
  40c5dc:	pop    rsi
  40c5dd:	ret
	...

000000000040c5e0 <__swc_fn_0a4ed24b_000103_0d4cc079>:
  40c5e0:	push   rbx
  40c5e1:	push   rsi
  40c5e2:	push   rdi
  40c5e3:	sub    rsp,0x20
  40c5e7:	mov    rbx,rdx
  40c5ea:	mov    rsi,rcx
  40c5ed:	mov    rcx,QWORD PTR [rip+0x1a74c]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40c5f4:	test   rcx,rcx
  40c5f7:	jne    40c609 <__swc_fn_0a4ed24b_000103_0d4cc079+0x29>
  40c5f9:	call   40a1a0 <__swc_fn_0a4ed24b_000165_56054fe7>
  40c5fe:	lea    rcx,[rax+0x1]
  40c602:	mov    QWORD PTR [rip+0x1a737],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40c609:	dec    rcx
  40c60c:	call   411c60 <__swc_fn_0a4ed24b_000167_39c041ad>
  40c611:	mov    rdi,rax
  40c614:	mov    rax,QWORD PTR [rdi+0xbd0]
  40c61b:	xor    ecx,ecx
  40c61d:	test   rax,rax
  40c620:	je     40c625 <__swc_fn_0a4ed24b_000103_0d4cc079+0x45>
  40c622:	mov    rcx,QWORD PTR [rax]
  40c625:	call   40a2d0 <__swc_fn_0a4ed24b_000174_02e645b4>
  40c62a:	lea    rax,[rsp+0x8]
  40c62f:	lea    rcx,[rdi+0x9c8]
  40c636:	mov    QWORD PTR [rsp+0x8],rcx
  40c63b:	mov    QWORD PTR [rax+0x8],0x40
  40c643:	xor    ecx,ecx
  40c645:	mov    rdx,rax
  40c648:	call   40ffc0 <__swc_fn_0a4ed24b_000119_2d9caf16>
  40c64d:	mov    DWORD PTR [rdi+0xbc8],eax
  40c653:	mov    rdi,QWORD PTR [rdi+0x990]
  40c65a:	test   rdi,rdi
  40c65d:	je     40c667 <__swc_fn_0a4ed24b_000103_0d4cc079+0x87>
  40c65f:	mov    rcx,rsi
  40c662:	mov    rdx,rbx
  40c665:	call   rdi
  40c667:	call   40c390 <__swc_fn_0a4ed24b_000091_f21926ed>
  40c66c:	test   al,al
  40c66e:	je     40c67e <__swc_fn_0a4ed24b_000103_0d4cc079+0x9e>
  40c670:	mov    rcx,rsi
  40c673:	mov    rdx,rbx
  40c676:	xor    r8d,r8d
  40c679:	call   4093e0 <__swc_fn_0a4ed24b_000120_1e032ef6>
  40c67e:	mov    rcx,rsi
  40c681:	mov    rdx,rbx
  40c684:	call   408a60 <__swc_fn_0a4ed24b_000102_14986ec5>
  40c689:	call   40cc10 <__swc_fn_0a4ed24b_000118_591530fe>
  40c68e:	add    rsp,0x20
  40c692:	pop    rdi
  40c693:	pop    rsi
  40c694:	pop    rbx
  40c695:	ret
	...

000000000040c6a0 <__swc_fn_0a4ed24b_000106_aba05410>:
  40c6a0:	test   r8,r8
  40c6a3:	jne    40c6a8 <__swc_fn_0a4ed24b_000106_aba05410+0x8>
  40c6a5:	xor    eax,eax
  40c6a7:	ret
  40c6a8:	xor    eax,eax
  40c6aa:	nop    WORD PTR [rax+rax*1+0x0]
  40c6b0:	mov    r9,r8
  40c6b3:	sub    r9,rax
  40c6b6:	cmp    r9,0x10
  40c6ba:	jb     40c704 <__swc_fn_0a4ed24b_000106_aba05410+0x64>
  40c6bc:	lea    r9,[rcx+rax*1]
  40c6c0:	lea    r10,[rdx+rax*1]
  40c6c4:	vmovups xmm0,XMMWORD PTR [r10]
  40c6c9:	vmovups xmm1,XMMWORD PTR [r9]
  40c6ce:	vpcmpeqb xmm0,xmm1,xmm0
  40c6d2:	vpmovmskb r9d,xmm0
  40c6d6:	cmp    r9d,0xffff
  40c6dd:	je     40c6fe <__swc_fn_0a4ed24b_000106_aba05410+0x5e>
  40c6df:	not    r9d
  40c6e2:	xor    r8d,r8d
  40c6e5:	movzx  r9d,r9w
  40c6e9:	tzcnt  r8d,r9d
  40c6ee:	add    rax,r8
  40c6f1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c6f5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c6f9:	sub    ecx,eax
  40c6fb:	mov    eax,ecx
  40c6fd:	ret
  40c6fe:	lea    rax,[rax+0x10]
  40c702:	jmp    40c6b0 <__swc_fn_0a4ed24b_000106_aba05410+0x10>
  40c704:	cmp    r9,0x8
  40c708:	jb     40c77b <__swc_fn_0a4ed24b_000106_aba05410+0xdb>
  40c70a:	lea    r9,[rcx+rax*1]
  40c70e:	lea    r10,[rdx+rax*1]
  40c712:	mov    r9,QWORD PTR [r9]
  40c715:	xor    r9,QWORD PTR [r10]
  40c718:	test   r9,r9
  40c71b:	je     40c739 <__swc_fn_0a4ed24b_000106_aba05410+0x99>
  40c71d:	xor    r8d,r8d
  40c720:	tzcnt  r8,r9
  40c725:	shr    r8,0x3
  40c729:	add    rax,r8
  40c72c:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c730:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c734:	sub    ecx,eax
  40c736:	mov    eax,ecx
  40c738:	ret
  40c739:	lea    rax,[rax+0x8]
  40c73d:	cmp    rax,r8
  40c740:	jne    40c745 <__swc_fn_0a4ed24b_000106_aba05410+0xa5>
  40c742:	xor    eax,eax
  40c744:	ret
  40c745:	lea    rax,[r8-0x8]
  40c749:	lea    r8,[rcx+rax*1]
  40c74d:	lea    r9,[rdx+rax*1]
  40c751:	mov    r8,QWORD PTR [r8]
  40c754:	xor    r8,QWORD PTR [r9]
  40c757:	test   r8,r8
  40c75a:	je     40c778 <__swc_fn_0a4ed24b_000106_aba05410+0xd8>
  40c75c:	xor    r9d,r9d
  40c75f:	tzcnt  r9,r8
  40c764:	shr    r9,0x3
  40c768:	add    rax,r9
  40c76b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c76f:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c773:	sub    ecx,eax
  40c775:	mov    eax,ecx
  40c777:	ret
  40c778:	xor    eax,eax
  40c77a:	ret
  40c77b:	cmp    r9,0x4
  40c77f:	jb     40c7f2 <__swc_fn_0a4ed24b_000106_aba05410+0x152>
  40c781:	lea    r9,[rcx+rax*1]
  40c785:	lea    r10,[rdx+rax*1]
  40c789:	mov    r9d,DWORD PTR [r9]
  40c78c:	xor    r9d,DWORD PTR [r10]
  40c78f:	test   r9d,r9d
  40c792:	je     40c7b0 <__swc_fn_0a4ed24b_000106_aba05410+0x110>
  40c794:	xor    r8d,r8d
  40c797:	tzcnt  r8,r9
  40c79c:	shr    r8,0x3
  40c7a0:	add    rax,r8
  40c7a3:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c7a7:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c7ab:	sub    ecx,eax
  40c7ad:	mov    eax,ecx
  40c7af:	ret
  40c7b0:	lea    rax,[rax+0x4]
  40c7b4:	cmp    rax,r8
  40c7b7:	jne    40c7bc <__swc_fn_0a4ed24b_000106_aba05410+0x11c>
  40c7b9:	xor    eax,eax
  40c7bb:	ret
  40c7bc:	lea    rax,[r8-0x4]
  40c7c0:	lea    r8,[rcx+rax*1]
  40c7c4:	lea    r9,[rdx+rax*1]
  40c7c8:	mov    r8d,DWORD PTR [r8]
  40c7cb:	xor    r8d,DWORD PTR [r9]
  40c7ce:	test   r8d,r8d
  40c7d1:	je     40c7ef <__swc_fn_0a4ed24b_000106_aba05410+0x14f>
  40c7d3:	xor    r9d,r9d
  40c7d6:	tzcnt  r9,r8
  40c7db:	shr    r9,0x3
  40c7df:	add    rax,r9
  40c7e2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c7e6:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c7ea:	sub    ecx,eax
  40c7ec:	mov    eax,ecx
  40c7ee:	ret
  40c7ef:	xor    eax,eax
  40c7f1:	ret
  40c7f2:	cmp    r9,0x2
  40c7f6:	jb     40c849 <__swc_fn_0a4ed24b_000106_aba05410+0x1a9>
  40c7f8:	lea    r9,[rcx+rax*1]
  40c7fc:	lea    r10,[rdx+rax*1]
  40c800:	mov    r9w,WORD PTR [r9]
  40c804:	xor    r9w,WORD PTR [r10]
  40c808:	test   r9w,r9w
  40c80c:	je     40c82e <__swc_fn_0a4ed24b_000106_aba05410+0x18e>
  40c80e:	xor    r8d,r8d
  40c811:	movzx  r9d,r9w
  40c815:	tzcnt  r8,r9
  40c81a:	shr    r8,0x3
  40c81e:	add    rax,r8
  40c821:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c825:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c829:	sub    ecx,eax
  40c82b:	mov    eax,ecx
  40c82d:	ret
  40c82e:	lea    rax,[rax+0x2]
  40c832:	cmp    rax,r8
  40c835:	jne    40c83a <__swc_fn_0a4ed24b_000106_aba05410+0x19a>
  40c837:	xor    eax,eax
  40c839:	ret
  40c83a:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40c840:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40c846:	sub    eax,ecx
  40c848:	ret
  40c849:	test   r9,r9
  40c84c:	je     40c85b <__swc_fn_0a4ed24b_000106_aba05410+0x1bb>
  40c84e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c852:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c856:	sub    ecx,eax
  40c858:	mov    eax,ecx
  40c85a:	ret
  40c85b:	xor    eax,eax
  40c85d:	ret
	...

000000000040c860 <__swc_fn_0a4ed24b_000109_9f5af8ae>:
  40c860:	push   r12
  40c862:	push   r13
  40c864:	push   r14
  40c866:	push   rdi
  40c867:	push   rsi
  40c868:	push   r15
  40c86a:	sub    rsp,0xd8
  40c871:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c877:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c87d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c883:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c889:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c88f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c898:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c8a1:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c8aa:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c8b3:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c8bc:	mov    r12,rcx
  40c8bf:	test   rcx,rcx
  40c8c2:	je     40c8de <__swc_fn_0a4ed24b_000109_9f5af8ae+0x7e>
  40c8c4:	mov    eax,r12d
  40c8c7:	and    eax,0xfff
  40c8cd:	setne  al
  40c8d0:	cmp    r12,0xffffffffffffefff
  40c8d7:	seta   cl
  40c8da:	or     al,cl
  40c8dc:	je     40c8e5 <__swc_fn_0a4ed24b_000109_9f5af8ae+0x85>
  40c8de:	xor    eax,eax
  40c8e0:	jmp    40c97b <__swc_fn_0a4ed24b_000109_9f5af8ae+0x11b>
  40c8e5:	call   409100 <__swc_fn_0a4ed24b_000108_b8f4bd15>
  40c8ea:	mov    r13,rax
  40c8ed:	test   rax,rax
  40c8f0:	jne    40c8f9 <__swc_fn_0a4ed24b_000109_9f5af8ae+0x99>
  40c8f2:	xor    eax,eax
  40c8f4:	jmp    40c97b <__swc_fn_0a4ed24b_000109_9f5af8ae+0x11b>
  40c8f9:	lea    r14,[r12+0x1000]
  40c901:	xor    edi,edi
  40c903:	mov    rsi,r14
  40c906:	xor    edx,edx
  40c908:	mov    ecx,0x22
  40c90d:	mov    eax,0xffffffff
  40c912:	movsxd r8,eax
  40c915:	xor    r9d,r9d
  40c918:	xor    eax,eax
  40c91a:	call   4070c0 <mmap@plt>
  40c91f:	mov    r15,rax
  40c922:	cmp    rax,0xffffffffffffffff
  40c926:	jne    40c92c <__swc_fn_0a4ed24b_000109_9f5af8ae+0xcc>
  40c928:	xor    eax,eax
  40c92a:	jmp    40c97b <__swc_fn_0a4ed24b_000109_9f5af8ae+0x11b>
  40c92c:	mov    rdi,r15
  40c92f:	mov    esi,0x1000
  40c934:	mov    edx,0x3
  40c939:	xor    eax,eax
  40c93b:	call   407030 <mprotect@plt>
  40c940:	test   eax,eax
  40c942:	je     40c955 <__swc_fn_0a4ed24b_000109_9f5af8ae+0xf5>
  40c944:	mov    rdi,r15
  40c947:	mov    rsi,r14
  40c94a:	xor    eax,eax
  40c94c:	call   407020 <munmap@plt>
  40c951:	xor    eax,eax
  40c953:	jmp    40c97b <__swc_fn_0a4ed24b_000109_9f5af8ae+0x11b>
  40c955:	mov    QWORD PTR [r15+0x8],r12
  40c959:	mov    rcx,r13
  40c95c:	call   40cfb0 <__swc_fn_0a4ed24b_000133_807fd51d>
  40c961:	mov    rax,QWORD PTR [r13+0x8]
  40c965:	mov    QWORD PTR [r15],rax
  40c968:	mov    QWORD PTR [r13+0x8],r15
  40c96c:	mov    rcx,r13
  40c96f:	call   410360 <__swc_fn_0a4ed24b_000134_10472836>
  40c974:	lea    rax,[r15+0x1000]
  40c97b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c981:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c987:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c98d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c993:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c999:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c9a2:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c9ab:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c9b4:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c9bd:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c9c6:	add    rsp,0xd8
  40c9cd:	pop    r15
  40c9cf:	pop    rsi
  40c9d0:	pop    rdi
  40c9d1:	pop    r14
  40c9d3:	pop    r13
  40c9d5:	pop    r12
  40c9d7:	ret
	...

000000000040c9e0 <__swc_fn_0a4ed24b_000112_2f7f9346>:
  40c9e0:	push   rbx
  40c9e1:	push   r12
  40c9e3:	push   rdi
  40c9e4:	push   rsi
  40c9e5:	sub    rsp,0xa8
  40c9ec:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c9f2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c9f8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c9fe:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40ca04:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40ca0a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40ca10:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ca16:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ca1c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ca25:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ca2e:	mov    rbx,rdx
  40ca31:	mov    r12,rcx
  40ca34:	mov    rdi,rcx
  40ca37:	mov    rsi,rdx
  40ca3a:	xor    edx,edx
  40ca3c:	xor    eax,eax
  40ca3e:	call   407030 <mprotect@plt>
  40ca43:	test   eax,eax
  40ca45:	jne    40ca69 <__swc_fn_0a4ed24b_000112_2f7f9346+0x89>
  40ca47:	mov    rcx,r12
  40ca4a:	mov    rdx,rbx
  40ca4d:	xor    al,al
  40ca4f:	mov    r8,rax
  40ca52:	call   40fe00 <__swc_fn_0a4ed24b_000110_918d5a21>
  40ca57:	mov    rdi,r12
  40ca5a:	mov    rsi,rbx
  40ca5d:	mov    edx,0x4
  40ca62:	xor    eax,eax
  40ca64:	call   4070e0 <madvise@plt>
  40ca69:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ca6f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ca75:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ca7b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ca81:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ca87:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ca8d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ca93:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ca99:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40caa2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40caab:	add    rsp,0xa8
  40cab2:	pop    rsi
  40cab3:	pop    rdi
  40cab4:	pop    r12
  40cab6:	pop    rbx
  40cab7:	ret
	...

000000000040cac0 <__swc_fn_0a4ed24b_000115_3f6af4b1>:
  40cac0:	push   rsi
  40cac1:	push   rdi
  40cac2:	push   r12
  40cac4:	push   r13
  40cac6:	push   r14
  40cac8:	sub    rsp,0xe0
  40cacf:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40cad5:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40cadb:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40cae1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40cae7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40caed:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40caf6:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40caff:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40cb08:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40cb11:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40cb1a:	mov    rsi,rdx
  40cb1d:	mov    rdi,rcx
  40cb20:	call   409100 <__swc_fn_0a4ed24b_000108_b8f4bd15>
  40cb25:	mov    r12,rax
  40cb28:	test   rax,rax
  40cb2b:	jne    40cb32 <__swc_fn_0a4ed24b_000115_3f6af4b1+0x72>
  40cb2d:	jmp    40cba6 <__swc_fn_0a4ed24b_000115_3f6af4b1+0xe6>
  40cb32:	mov    rcx,r12
  40cb35:	call   40cfb0 <__swc_fn_0a4ed24b_000133_807fd51d>
  40cb3a:	lea    r13,[r12+0x8]
  40cb3f:	mov    rax,QWORD PTR [r13+0x0]
  40cb43:	test   rax,rax
  40cb46:	je     40cb9e <__swc_fn_0a4ed24b_000115_3f6af4b1+0xde>
  40cb48:	nop    DWORD PTR [rax+rax*1+0x0]
  40cb50:	lea    rcx,[rax+0x1000]
  40cb57:	cmp    rcx,rdi
  40cb5a:	jne    40cb92 <__swc_fn_0a4ed24b_000115_3f6af4b1+0xd2>
  40cb5c:	cmp    QWORD PTR [rax+0x8],rsi
  40cb60:	je     40cb6c <__swc_fn_0a4ed24b_000115_3f6af4b1+0xac>
  40cb62:	mov    rcx,r12
  40cb65:	call   410360 <__swc_fn_0a4ed24b_000134_10472836>
  40cb6a:	jmp    40cba6 <__swc_fn_0a4ed24b_000115_3f6af4b1+0xe6>
  40cb6c:	mov    r14,QWORD PTR [rax]
  40cb6f:	mov    rdi,rax
  40cb72:	lea    rsi,[rsi+0x1000]
  40cb79:	xor    eax,eax
  40cb7b:	call   407020 <munmap@plt>
  40cb80:	test   eax,eax
  40cb82:	jne    40cb88 <__swc_fn_0a4ed24b_000115_3f6af4b1+0xc8>
  40cb84:	mov    QWORD PTR [r13+0x0],r14
  40cb88:	mov    rcx,r12
  40cb8b:	call   410360 <__swc_fn_0a4ed24b_000134_10472836>
  40cb90:	jmp    40cba6 <__swc_fn_0a4ed24b_000115_3f6af4b1+0xe6>
  40cb92:	mov    r13,rax
  40cb95:	mov    rax,QWORD PTR [r13+0x0]
  40cb99:	test   rax,rax
  40cb9c:	jne    40cb50 <__swc_fn_0a4ed24b_000115_3f6af4b1+0x90>
  40cb9e:	mov    rcx,r12
  40cba1:	call   410360 <__swc_fn_0a4ed24b_000134_10472836>
  40cba6:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40cbac:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40cbb2:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40cbb8:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40cbbe:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40cbc4:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40cbcd:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40cbd6:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40cbdf:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40cbe8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40cbf1:	add    rsp,0xe0
  40cbf8:	pop    r14
  40cbfa:	pop    r13
  40cbfc:	pop    r12
  40cbfe:	pop    rdi
  40cbff:	pop    rsi
  40cc00:	ret
	...

000000000040cc10 <__swc_fn_0a4ed24b_000118_591530fe>:
  40cc10:	push   rdi
  40cc11:	push   rsi
  40cc12:	sub    rsp,0xa8
  40cc19:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cc1f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cc25:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cc2b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cc31:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cc37:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cc3d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cc43:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cc49:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cc52:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cc5b:	mov    rdi,0xfffffffffffffd66
  40cc62:	xor    eax,eax
  40cc64:	call   407040 <exit@plt>
  40cc69:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cc6f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cc75:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cc7b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cc81:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cc87:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cc8d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cc93:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cc99:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cca2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ccab:	add    rsp,0xa8
  40ccb2:	pop    rsi
  40ccb3:	pop    rdi
  40ccb4:	ret
	...

000000000040ccc0 <__swc_fn_0a4ed24b_000121_1c5e75b6>:
  40ccc0:	push   rbx
  40ccc1:	push   rsi
  40ccc2:	push   rdi
  40ccc3:	sub    rsp,0x30
  40ccc7:	mov    rbx,rdx
  40ccca:	mov    esi,ecx
  40cccc:	test   ecx,ecx
  40ccce:	je     40cda3 <__swc_fn_0a4ed24b_000121_1c5e75b6+0xe3>
  40ccd4:	mov    rcx,rsi
  40ccd7:	shl    rcx,0x4
  40ccdb:	call   40c1d0 <__swc_fn_0a4ed24b_000079_633af784>
  40cce0:	test   rax,rax
  40cce3:	je     40cd92 <__swc_fn_0a4ed24b_000121_1c5e75b6+0xd2>
  40cce9:	mov    rcx,rsi
  40ccec:	xor    edx,edx
  40ccee:	test   rsi,rsi
  40ccf1:	jbe    40cd72 <__swc_fn_0a4ed24b_000121_1c5e75b6+0xb2>
  40ccf7:	nop    WORD PTR [rax+rax*1+0x0]
  40cd00:	mov    r8d,edx
  40cd03:	mov    r9,QWORD PTR [rbx+r8*8]
  40cd07:	add    r8,r8
  40cd0a:	lea    r8,[rax+r8*8]
  40cd0e:	xor    r10d,r10d
  40cd11:	test   r9,r9
  40cd14:	je     40cd50 <__swc_fn_0a4ed24b_000121_1c5e75b6+0x90>
  40cd16:	mov    r11,r9
  40cd19:	mov    dil,BYTE PTR [r11]
  40cd1c:	test   dil,dil
  40cd1f:	je     40cd50 <__swc_fn_0a4ed24b_000121_1c5e75b6+0x90>
  40cd21:	cs nop WORD PTR [rax+rax*1+0x0]
  40cd2b:	cs nop WORD PTR [rax+rax*1+0x0]
  40cd35:	cs nop WORD PTR [rax+rax*1+0x0]
  40cd3f:	nop
  40cd40:	add    r11,0x1
  40cd44:	add    r10,0x1
  40cd48:	mov    dil,BYTE PTR [r11]
  40cd4b:	test   dil,dil
  40cd4e:	jne    40cd40 <__swc_fn_0a4ed24b_000121_1c5e75b6+0x80>
  40cd50:	mov    QWORD PTR [rsp+0x18],r9
  40cd55:	mov    QWORD PTR [rsp+0x20],r10
  40cd5a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40cd60:	vmovups XMMWORD PTR [r8],xmm0
  40cd65:	add    rdx,0x1
  40cd69:	cmp    rdx,rcx
  40cd6c:	jb     40cd00 <__swc_fn_0a4ed24b_000121_1c5e75b6+0x40>
  40cd72:	lea    rcx,[rip+0x19fd7]        # 426d50 <__swc_bss_base_0a4ed24b+0x2d10>
  40cd79:	mov    QWORD PTR [rsp+0x8],rax
  40cd7e:	mov    esi,esi
  40cd80:	mov    QWORD PTR [rsp+0x10],rsi
  40cd85:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40cd8b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40cd90:	jmp    40cda3 <__swc_fn_0a4ed24b_000121_1c5e75b6+0xe3>
  40cd92:	lea    rcx,[rip+0x6787]        # 413520 <__swc_rdata_base_0a4ed24b+0x410>
  40cd99:	call   40feb0 <__swc_fn_0a4ed24b_000116_3f5cfdef>
  40cd9e:	call   40cc10 <__swc_fn_0a4ed24b_000118_591530fe>
  40cda3:	add    rsp,0x30
  40cda7:	pop    rdi
  40cda8:	pop    rsi
  40cda9:	pop    rbx
  40cdaa:	ret
  40cdab:	add    BYTE PTR [rax],al
  40cdad:	add    BYTE PTR [rax],al
	...

000000000040cdb0 <__swc_fn_0a4ed24b_000124_37eaf452>:
  40cdb0:	push   rdi
  40cdb1:	push   rsi
  40cdb2:	sub    rsp,0xa8
  40cdb9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cdbf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cdc5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cdcb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cdd1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cdd7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cddd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cde3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cde9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cdf2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cdfb:	mov    edi,ecx
  40cdfd:	xor    eax,eax
  40cdff:	call   4070f0 <pthread_key_delete@plt>
  40ce04:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ce0a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ce10:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ce16:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ce1c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ce22:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ce28:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ce2e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ce34:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ce3d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ce46:	add    rsp,0xa8
  40ce4d:	pop    rsi
  40ce4e:	pop    rdi
  40ce4f:	ret

000000000040ce50 <__swc_fn_0a4ed24b_000127_f163135d>:
  40ce50:	push   rdi
  40ce51:	push   rsi
  40ce52:	sub    rsp,0xa8
  40ce59:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ce5f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ce65:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ce6b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40ce71:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40ce77:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40ce7d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ce83:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ce89:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ce92:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ce9b:	test   rcx,rcx
  40ce9e:	je     40ceaf <__swc_fn_0a4ed24b_000127_f163135d+0x5f>
  40cea0:	lea    rax,[rcx-0x1]
  40cea4:	mov    eax,eax
  40cea6:	mov    edi,eax
  40cea8:	xor    eax,eax
  40ceaa:	call   4070f0 <pthread_key_delete@plt>
  40ceaf:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ceb5:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cebb:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cec1:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cec7:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cecd:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ced3:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ced9:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cedf:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cee8:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cef1:	add    rsp,0xa8
  40cef8:	pop    rsi
  40cef9:	pop    rdi
  40cefa:	ret
  40cefb:	add    BYTE PTR [rax],al
  40cefd:	add    BYTE PTR [rax],al
	...

000000000040cf00 <__swc_fn_0a4ed24b_000130_375c7357>:
  40cf00:	push   rsi
  40cf01:	push   rdi
  40cf02:	sub    rsp,0xa8
  40cf09:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cf0f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cf15:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cf1b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cf21:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cf27:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cf2d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cf33:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cf39:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cf42:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cf4b:	xor    eax,eax
  40cf4d:	call   407100 <gettid@plt>
  40cf52:	movsxd rax,eax
  40cf55:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cf5b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cf61:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cf67:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cf6d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cf73:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cf79:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cf7f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cf85:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cf8e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cf97:	add    rsp,0xa8
  40cf9e:	pop    rdi
  40cf9f:	pop    rsi
  40cfa0:	ret
	...

000000000040cfb0 <__swc_fn_0a4ed24b_000133_807fd51d>:
  40cfb0:	push   rbx
  40cfb1:	push   rdi
  40cfb2:	push   rsi
  40cfb3:	sub    rsp,0xc0
  40cfba:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40cfc0:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40cfc6:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40cfcc:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40cfd2:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40cfd8:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40cfde:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40cfe4:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40cfed:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40cff6:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40cfff:	mov    rbx,rcx
  40d002:	cs nop WORD PTR [rax+rax*1+0x0]
  40d00c:	nop    DWORD PTR [rax+0x0]
  40d010:	mov    edx,0x80000000
  40d015:	xor    eax,eax
  40d017:	lock cmpxchg DWORD PTR [rbx],edx
  40d01b:	test   eax,eax
  40d01d:	je     40d054 <__swc_fn_0a4ed24b_000133_807fd51d+0xa4>
  40d01f:	mov    eax,DWORD PTR [rbx]
  40d021:	lea    rcx,[rsp+0x14]
  40d026:	mov    DWORD PTR [rsp+0x14],eax
  40d02a:	test   eax,eax
  40d02c:	je     40d010 <__swc_fn_0a4ed24b_000133_807fd51d+0x60>
  40d02e:	mov    QWORD PTR [rsp],0x0
  40d036:	mov    edi,0xca
  40d03b:	mov    rsi,rbx
  40d03e:	mov    edx,0x80
  40d043:	mov    ecx,DWORD PTR [rcx]
  40d045:	xor    r8d,r8d
  40d048:	xor    r9d,r9d
  40d04b:	xor    eax,eax
  40d04d:	call   407070 <syscall@plt>
  40d052:	jmp    40d010 <__swc_fn_0a4ed24b_000133_807fd51d+0x60>
  40d054:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40d05a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40d060:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40d066:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40d06c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40d072:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40d078:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40d07e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40d087:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40d090:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40d099:	add    rsp,0xc0
  40d0a0:	pop    rsi
  40d0a1:	pop    rdi
  40d0a2:	pop    rbx
  40d0a3:	ret
	...

000000000040d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>:
  40d0b0:	sub    rsp,0x8
  40d0b4:	call   410360 <__swc_fn_0a4ed24b_000134_10472836>
  40d0b9:	add    rsp,0x8
  40d0bd:	ret
	...

000000000040d0c0 <__swc_fn_0a4ed24b_000139_e4a7a8b1>:
  40d0c0:	push   rdi
  40d0c1:	push   rsi
  40d0c2:	sub    rsp,0xa8
  40d0c9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d0cf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d0d5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d0db:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d0e1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d0e7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d0ed:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d0f3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d0f9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d102:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d10b:	mov    edi,0x28
  40d110:	xor    eax,eax
  40d112:	call   4070d0 <malloc@plt>
  40d117:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d11d:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d123:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d129:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d12f:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d135:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d13b:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d141:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d147:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d150:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d159:	add    rsp,0xa8
  40d160:	pop    rsi
  40d161:	pop    rdi
  40d162:	ret
	...

000000000040d170 <__swc_fn_0a4ed24b_000142_89a6ef72>:
  40d170:	mov    QWORD PTR [r8],0x0
  40d177:	cmp    rdx,0x10
  40d17b:	jae    40d180 <__swc_fn_0a4ed24b_000142_89a6ef72+0x10>
  40d17d:	xor    eax,eax
  40d17f:	ret
  40d180:	mov    eax,DWORD PTR [rcx]
  40d182:	cmp    eax,0x42445753
  40d188:	jne    40d192 <__swc_fn_0a4ed24b_000142_89a6ef72+0x22>
  40d18a:	mov    eax,DWORD PTR [rcx+0x4]
  40d18d:	cmp    eax,0x1
  40d190:	je     40d195 <__swc_fn_0a4ed24b_000142_89a6ef72+0x25>
  40d192:	xor    eax,eax
  40d194:	ret
  40d195:	mov    QWORD PTR [r8],rdx
  40d198:	mov    rax,rcx
  40d19b:	ret
  40d19c:	add    BYTE PTR [rax],al
	...

000000000040d1a0 <__swc_fn_0a4ed24b_000145_32a1d6a2>:
  40d1a0:	push   rbx
  40d1a1:	sub    rsp,0xe0
  40d1a8:	lea    rbx,[rsp+0x8]
  40d1ad:	vxorps xmm0,xmm0,xmm0
  40d1b1:	vmovups YMMWORD PTR [rbx],ymm0
  40d1b5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40d1ba:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40d1bf:	vzeroupper
  40d1c2:	mov    DWORD PTR [rbx+0x60],0x0
  40d1c9:	mov    r8,rbx
  40d1cc:	mov    rdx,rcx
  40d1cf:	nop
  40d1d0:	mov    r9,rdx
  40d1d3:	movabs rdx,0x6666666666666667
  40d1dd:	mov    rax,r9
  40d1e0:	imul   rdx
  40d1e3:	sar    rdx,0x2
  40d1e7:	mov    r10,rdx
  40d1ea:	shr    rdx,0x3f
  40d1ee:	add    r10,rdx
  40d1f1:	mov    rdx,r10
  40d1f4:	imul   r11,r10,0xa
  40d1f8:	sub    r9,r11
  40d1fb:	mov    r11,QWORD PTR [rip+0x633e]        # 413540 <__swc_rdata_base_0a4ed24b+0x430>
  40d202:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40d207:	mov    BYTE PTR [r8],r9b
  40d20a:	lea    r9,[r8+0x1]
  40d20e:	mov    r8,r9
  40d211:	test   r10,r10
  40d214:	jne    40d1d0 <__swc_fn_0a4ed24b_000145_32a1d6a2+0x30>
  40d216:	test   rcx,rcx
  40d219:	jge    40d223 <__swc_fn_0a4ed24b_000145_32a1d6a2+0x83>
  40d21b:	mov    BYTE PTR [r9],0x2d
  40d21f:	add    r8,0x1
  40d223:	mov    BYTE PTR [r8],0x0
  40d227:	sub    r8,0x1
  40d22b:	mov    rax,rbx
  40d22e:	cmp    rax,r8
  40d231:	jae    40d256 <__swc_fn_0a4ed24b_000145_32a1d6a2+0xb6>
  40d233:	cs nop WORD PTR [rax+rax*1+0x0]
  40d23d:	nop    DWORD PTR [rax]
  40d240:	mov    cl,BYTE PTR [r8]
  40d243:	mov    dl,BYTE PTR [rax]
  40d245:	mov    BYTE PTR [r8],dl
  40d248:	sub    r8,0x1
  40d24c:	mov    BYTE PTR [rax],cl
  40d24e:	inc    rax
  40d251:	cmp    rax,r8
  40d254:	jb     40d240 <__swc_fn_0a4ed24b_000145_32a1d6a2+0xa0>
  40d256:	xor    eax,eax
  40d258:	test   rbx,rbx
  40d25b:	je     40d27e <__swc_fn_0a4ed24b_000145_32a1d6a2+0xde>
  40d25d:	mov    rcx,rbx
  40d260:	mov    dl,BYTE PTR [rcx]
  40d262:	test   dl,dl
  40d264:	je     40d27e <__swc_fn_0a4ed24b_000145_32a1d6a2+0xde>
  40d266:	cs nop WORD PTR [rax+rax*1+0x0]
  40d270:	add    rcx,0x1
  40d274:	add    rax,0x1
  40d278:	mov    dl,BYTE PTR [rcx]
  40d27a:	test   dl,dl
  40d27c:	jne    40d270 <__swc_fn_0a4ed24b_000145_32a1d6a2+0xd0>
  40d27e:	mov    QWORD PTR [rbx+0xa8],rbx
  40d285:	mov    QWORD PTR [rbx+0xb0],rax
  40d28c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d294:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d29c:	lea    rcx,[rbx+0xb8]
  40d2a3:	call   40feb0 <__swc_fn_0a4ed24b_000116_3f5cfdef>
  40d2a8:	add    rsp,0xe0
  40d2af:	pop    rbx
  40d2b0:	ret
	...

000000000040d2c0 <__swc_fn_0a4ed24b_000148_365b4daf>:
  40d2c0:	vxorps xmm0,xmm0,xmm0
  40d2c4:	vmovups XMMWORD PTR [rcx],xmm0
  40d2c8:	mov    QWORD PTR [rcx+0x10],0x0
  40d2d0:	ret
	...

000000000040d2e0 <__swc_fn_0a4ed24b_000151_365b4daf>:
  40d2e0:	vxorps xmm0,xmm0,xmm0
  40d2e4:	vmovups XMMWORD PTR [rcx],xmm0
  40d2e8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d2ed:	vxorps xmm0,xmm0,xmm0
  40d2f1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d2f6:	vmovups xmm0,XMMWORD PTR [rip+0x633a]        # 413638 <__swc_rdata_base_0a4ed24b+0x528>
  40d2fe:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d303:	vxorps xmm0,xmm0,xmm0
  40d307:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d30c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d311:	mov    QWORD PTR [rcx+0x60],0x0
  40d319:	ret
  40d31a:	add    BYTE PTR [rax],al
  40d31c:	add    BYTE PTR [rax],al
	...

000000000040d320 <__swc_fn_0a4ed24b_000154_365b4daf>:
  40d320:	vxorps xmm0,xmm0,xmm0
  40d324:	vmovups XMMWORD PTR [rcx],xmm0
  40d328:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d32d:	vxorps xmm0,xmm0,xmm0
  40d331:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d336:	vmovups xmm0,XMMWORD PTR [rip+0x6422]        # 413760 <__swc_rdata_base_0a4ed24b+0x650>
  40d33e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d343:	vxorps xmm0,xmm0,xmm0
  40d347:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d34c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d351:	vxorps xmm0,xmm0,xmm0
  40d355:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40d35a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40d35f:	vxorps xmm0,xmm0,xmm0
  40d363:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40d36b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40d373:	vxorps xmm0,xmm0,xmm0
  40d377:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40d37f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40d387:	vxorps xmm0,xmm0,xmm0
  40d38b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40d393:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40d39b:	mov    QWORD PTR [rcx+0xe0],0x0
  40d3a6:	ret
	...

000000000040d3b0 <__swc_fn_0a4ed24b_000157_3495a3ca>:
  40d3b0:	push   rbx
  40d3b1:	mov    rbx,rcx
  40d3b4:	call   4118f0 <__swc_fn_0a4ed24b_000158_31e09513>
  40d3b9:	mov    rax,QWORD PTR [rbx+0x10]
  40d3bd:	test   rax,rax
  40d3c0:	je     40d3d1 <__swc_fn_0a4ed24b_000157_3495a3ca+0x21>
  40d3c2:	mov    rcx,rbx
  40d3c5:	mov    rdx,rax
  40d3c8:	mov    r8,QWORD PTR [rbx+0x18]
  40d3cc:	call   409e90 <__swc_fn_0a4ed24b_000156_9e2052d6>
  40d3d1:	vxorps xmm0,xmm0,xmm0
  40d3d5:	vmovups XMMWORD PTR [rbx],xmm0
  40d3d9:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d3de:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d3e3:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d3e8:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d3ed:	mov    QWORD PTR [rbx+0x50],0x0
  40d3f5:	pop    rbx
  40d3f6:	ret
	...

000000000040d400 <__swc_fn_0a4ed24b_000160_dfca9093>:
  40d400:	sub    rsp,0x10
  40d404:	mov    eax,r8d
  40d407:	mov    r8d,r9d
  40d40a:	test   r9d,r9d
  40d40d:	jne    40d426 <__swc_fn_0a4ed24b_000160_dfca9093+0x26>
  40d40f:	vmovups xmm0,XMMWORD PTR [rip+0x6401]        # 413818 <__swc_rdata_base_0a4ed24b+0x708>
  40d417:	vmovups XMMWORD PTR [r10],xmm0
  40d41c:	mov    eax,0x1
  40d421:	add    rsp,0x10
  40d425:	ret
  40d426:	mov    r9,r8
  40d429:	cmp    r8,rax
  40d42c:	jb     40d433 <__swc_fn_0a4ed24b_000160_dfca9093+0x33>
  40d42e:	cmp    r9,rdx
  40d431:	jb     40d43a <__swc_fn_0a4ed24b_000160_dfca9093+0x3a>
  40d433:	xor    eax,eax
  40d435:	add    rsp,0x10
  40d439:	ret
  40d43a:	xor    eax,eax
  40d43c:	lea    r8,[r9+rax*1]
  40d440:	cmp    r8,rdx
  40d443:	jae    40d473 <__swc_fn_0a4ed24b_000160_dfca9093+0x73>
  40d445:	cs nop WORD PTR [rax+rax*1+0x0]
  40d44f:	cs nop WORD PTR [rax+rax*1+0x0]
  40d459:	nop    DWORD PTR [rax+0x0]
  40d460:	cmp    BYTE PTR [rcx+r8*1],0x0
  40d465:	je     40d473 <__swc_fn_0a4ed24b_000160_dfca9093+0x73>
  40d467:	inc    rax
  40d46a:	lea    r8,[r9+rax*1]
  40d46e:	cmp    r8,rdx
  40d471:	jb     40d460 <__swc_fn_0a4ed24b_000160_dfca9093+0x60>
  40d473:	cmp    r8,rdx
  40d476:	jne    40d47f <__swc_fn_0a4ed24b_000160_dfca9093+0x7f>
  40d478:	xor    eax,eax
  40d47a:	add    rsp,0x10
  40d47e:	ret
  40d47f:	add    rcx,r9
  40d482:	mov    QWORD PTR [rsp],rcx
  40d486:	mov    QWORD PTR [rsp+0x8],rax
  40d48b:	vmovups xmm0,XMMWORD PTR [rsp]
  40d490:	vmovups XMMWORD PTR [r10],xmm0
  40d495:	mov    eax,0x1
  40d49a:	add    rsp,0x10
  40d49e:	ret
	...

000000000040d4a0 <__swc_fn_0a4ed24b_000163_3a7aae74>:
  40d4a0:	push   rbp
  40d4a1:	push   rbx
  40d4a2:	push   rsi
  40d4a3:	push   rdi
  40d4a4:	push   r12
  40d4a6:	push   r13
  40d4a8:	push   r14
  40d4aa:	push   r15
  40d4ac:	sub    rsp,0x10
  40d4b0:	mov    rbp,rsp
  40d4b3:	vmovups XMMWORD PTR [rsp],xmm6
  40d4b8:	sub    rsp,0x50
  40d4bc:	mov    rbx,rsp
  40d4bf:	mov    rsi,r8
  40d4c2:	mov    QWORD PTR [rsp+0x30],r8
  40d4c7:	mov    rdi,rcx
  40d4ca:	mov    QWORD PTR [rsp+0x38],rcx
  40d4cf:	mov    r12,rdx
  40d4d2:	xor    r13b,r13b
  40d4d5:	mov    r14,QWORD PTR [rdi+0x8]
  40d4d9:	mov    QWORD PTR [rsp+0x40],r14
  40d4de:	xor    r15d,r15d
  40d4e1:	test   r14,r14
  40d4e4:	jbe    40d73e <__swc_fn_0a4ed24b_000163_3a7aae74+0x29e>
  40d4ea:	mov    r14,QWORD PTR [rdi]
  40d4ed:	mov    rax,QWORD PTR [rsp+0x40]
  40d4f2:	mov    QWORD PTR [rsp+0x48],r14
  40d4f7:	vmovups xmm6,XMMWORD PTR [rip+0x5f39]        # 413438 <__swc_rdata_base_0a4ed24b+0x328>
  40d4ff:	nop
  40d500:	cmp    QWORD PTR [r14+r15*8],0x0
  40d505:	jne    40d50f <__swc_fn_0a4ed24b_000163_3a7aae74+0x6f>
  40d507:	mov    r14,rax
  40d50a:	jmp    40d71e <__swc_fn_0a4ed24b_000163_3a7aae74+0x27e>
  40d50f:	mov    rcx,QWORD PTR [rdi]
  40d512:	mov    rdx,QWORD PTR [rcx+r15*8]
  40d516:	mov    rdi,rbx
  40d519:	mov    rcx,rdi
  40d51c:	sub    rsp,0x8
  40d520:	mov    r14,rax
  40d523:	call   409f10 <__swc_fn_0a4ed24b_000162_61e293bf>
  40d528:	add    rsp,0x8
  40d52c:	mov    al,BYTE PTR [rbx]
  40d52e:	test   al,al
  40d530:	je     40d71e <__swc_fn_0a4ed24b_000163_3a7aae74+0x27e>
  40d536:	mov    al,BYTE PTR [rbx+0x1]
  40d539:	test   al,al
  40d53b:	jne    40d546 <__swc_fn_0a4ed24b_000163_3a7aae74+0xa6>
  40d53d:	test   sil,sil
  40d540:	je     40d71e <__swc_fn_0a4ed24b_000163_3a7aae74+0x27e>
  40d546:	test   r13b,r13b
  40d549:	jne    40d607 <__swc_fn_0a4ed24b_000163_3a7aae74+0x167>
  40d54f:	test   r12,r12
  40d552:	je     40d607 <__swc_fn_0a4ed24b_000163_3a7aae74+0x167>
  40d558:	mov    al,BYTE PTR [rbx+0x1]
  40d55b:	test   al,al
  40d55d:	je     40d71e <__swc_fn_0a4ed24b_000163_3a7aae74+0x27e>
  40d563:	mov    eax,DWORD PTR [rbx+0x28]
  40d566:	cmp    DWORD PTR [r12+0x20],eax
  40d56b:	jne    40d71e <__swc_fn_0a4ed24b_000163_3a7aae74+0x27e>
  40d571:	mov    rax,QWORD PTR [r12]
  40d575:	mov    rcx,QWORD PTR [r12+0x8]
  40d57a:	cmp    QWORD PTR [rbx+0x20],rcx
  40d57e:	jne    40d71e <__swc_fn_0a4ed24b_000163_3a7aae74+0x27e>
  40d584:	mov    cl,0x1
  40d586:	test   rax,rax
  40d589:	je     40d5f2 <__swc_fn_0a4ed24b_000163_3a7aae74+0x152>
  40d58f:	mov    rdx,QWORD PTR [rbx+0x20]
  40d593:	xor    r8d,r8d
  40d596:	test   rdx,rdx
  40d599:	jbe    40d5f2 <__swc_fn_0a4ed24b_000163_3a7aae74+0x152>
  40d59b:	mov    r9,QWORD PTR [rbx+0x18]
  40d59f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40d5a4:	cs nop WORD PTR [rax+rax*1+0x0]
  40d5ae:	xchg   ax,ax
  40d5b0:	mov    r10b,BYTE PTR [rax+r8*1]
  40d5b4:	cmp    BYTE PTR [r9+r8*1],r10b
  40d5b8:	je     40d5e9 <__swc_fn_0a4ed24b_000163_3a7aae74+0x149>
  40d5ba:	vmovq  r10,xmm0
  40d5bf:	cmp    BYTE PTR [r10+r8*1],0x5c
  40d5c4:	jne    40d5cd <__swc_fn_0a4ed24b_000163_3a7aae74+0x12d>
  40d5c6:	cmp    BYTE PTR [rax+r8*1],0x2f
  40d5cb:	je     40d5e9 <__swc_fn_0a4ed24b_000163_3a7aae74+0x149>
  40d5cd:	vmovq  r10,xmm0
  40d5d2:	cmp    BYTE PTR [r10+r8*1],0x2f
  40d5d7:	jne    40d5e0 <__swc_fn_0a4ed24b_000163_3a7aae74+0x140>
  40d5d9:	cmp    BYTE PTR [rax+r8*1],0x5c
  40d5de:	je     40d5e9 <__swc_fn_0a4ed24b_000163_3a7aae74+0x149>
  40d5e0:	xor    eax,eax
  40d5e2:	movzx  eax,al
  40d5e5:	mov    cl,al
  40d5e7:	jmp    40d5f2 <__swc_fn_0a4ed24b_000163_3a7aae74+0x152>
  40d5e9:	add    r8,0x1
  40d5ed:	cmp    r8,rdx
  40d5f0:	jb     40d5b0 <__swc_fn_0a4ed24b_000163_3a7aae74+0x110>
  40d5f2:	test   cl,cl
  40d5f4:	je     40d71e <__swc_fn_0a4ed24b_000163_3a7aae74+0x27e>
  40d5fa:	mov    eax,0x1
  40d5ff:	mov    r13b,al
  40d602:	jmp    40d71e <__swc_fn_0a4ed24b_000163_3a7aae74+0x27e>
  40d607:	mov    r13b,0x1
  40d60a:	sub    rsp,0x20
  40d60e:	mov    rax,rsp
  40d611:	lea    rcx,[rdi+0x8]
  40d615:	mov    QWORD PTR [rax],rcx
  40d618:	lea    rsi,[rip+0x5cf1]        # 413310 <__swc_rdata_base_0a4ed24b+0x200>
  40d61f:	mov    QWORD PTR [rax+0x8],rsi
  40d623:	mov    QWORD PTR [rax+0x10],rsp
  40d627:	mov    QWORD PTR [rax+0x18],0x1
  40d62f:	lea    rcx,[rsp+0x10]
  40d634:	sub    rsp,0x8
  40d638:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  40d63d:	add    rsp,0x8
  40d641:	add    rsp,0x20
  40d645:	mov    al,BYTE PTR [rbx+0x1]
  40d648:	test   al,al
  40d64a:	je     40d6e7 <__swc_fn_0a4ed24b_000163_3a7aae74+0x247>
  40d650:	lea    rax,[rip+0x6261]        # 4138b8 <__swc_rdata_base_0a4ed24b+0x7a8>
  40d657:	sub    rsp,0x20
  40d65b:	mov    rcx,rsp
  40d65e:	mov    QWORD PTR [rcx],rax
  40d661:	mov    QWORD PTR [rcx+0x8],rsi
  40d665:	mov    QWORD PTR [rcx+0x10],rsp
  40d669:	mov    QWORD PTR [rcx+0x18],0x1
  40d671:	lea    rcx,[rsp+0x10]
  40d676:	sub    rsp,0x8
  40d67a:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  40d67f:	add    rsp,0x8
  40d683:	add    rsp,0x20
  40d687:	mov    eax,DWORD PTR [rbx+0x28]
  40d68a:	sub    rsp,0x60
  40d68e:	mov    rcx,rsp
  40d691:	lea    rdx,[rdi+0x18]
  40d695:	mov    QWORD PTR [rcx+0x18],rdx
  40d699:	mov    QWORD PTR [rcx+0x20],rsi
  40d69d:	vmovups XMMWORD PTR [rcx],xmm6
  40d6a1:	mov    QWORD PTR [rcx+0x28],rsp
  40d6a5:	mov    QWORD PTR [rcx+0x30],rsi
  40d6a9:	mov    DWORD PTR [rcx+0x10],eax
  40d6ac:	lea    rax,[rsp+0x10]
  40d6b1:	mov    QWORD PTR [rcx+0x38],rax
  40d6b5:	lea    rax,[rip+0x5d14]        # 4133d0 <__swc_rdata_base_0a4ed24b+0x2c0>
  40d6bc:	mov    QWORD PTR [rcx+0x40],rax
  40d6c0:	lea    rax,[rsp+0x18]
  40d6c5:	mov    QWORD PTR [rcx+0x48],rax
  40d6c9:	mov    QWORD PTR [rcx+0x50],0x3
  40d6d1:	lea    rcx,[rsp+0x48]
  40d6d6:	sub    rsp,0x8
  40d6da:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  40d6df:	add    rsp,0x8
  40d6e3:	add    rsp,0x60
  40d6e7:	lea    rax,[rip+0x5c7a]        # 413368 <__swc_rdata_base_0a4ed24b+0x258>
  40d6ee:	sub    rsp,0x20
  40d6f2:	mov    rcx,rsp
  40d6f5:	mov    QWORD PTR [rcx],rax
  40d6f8:	mov    QWORD PTR [rcx+0x8],rsi
  40d6fc:	mov    QWORD PTR [rcx+0x10],rsp
  40d700:	mov    QWORD PTR [rcx+0x18],0x1
  40d708:	lea    rcx,[rsp+0x10]
  40d70d:	sub    rsp,0x8
  40d711:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  40d716:	add    rsp,0x8
  40d71a:	add    rsp,0x20
  40d71e:	add    r15,0x1
  40d722:	cmp    r15,r14
  40d725:	jae    40d73e <__swc_fn_0a4ed24b_000163_3a7aae74+0x29e>
  40d727:	mov    rsi,QWORD PTR [rsp+0x30]
  40d72c:	mov    rdi,QWORD PTR [rsp+0x38]
  40d731:	mov    rax,r14
  40d734:	mov    r14,QWORD PTR [rsp+0x48]
  40d739:	jmp    40d500 <__swc_fn_0a4ed24b_000163_3a7aae74+0x60>
  40d73e:	add    rsp,0x50
  40d742:	vmovups xmm6,XMMWORD PTR [rsp]
  40d747:	add    rsp,0x10
  40d74b:	pop    r15
  40d74d:	pop    r14
  40d74f:	pop    r13
  40d751:	pop    r12
  40d753:	pop    rdi
  40d754:	pop    rsi
  40d755:	pop    rbx
  40d756:	pop    rbp
  40d757:	ret
	...

000000000040d760 <__swc_fn_0a4ed24b_000166_c370e18e>:
  40d760:	sub    rsp,0x8
  40d764:	call   410130 <__swc_fn_0a4ed24b_000125_7a81492f>
  40d769:	add    rsp,0x8
  40d76d:	ret
	...

000000000040d770 <__swc_fn_0a4ed24b_000169_4694b8ad>:
  40d770:	push   rsi
  40d771:	sub    rsp,0x30
  40d775:	lea    rsi,[rip+0x19624]        # 426da0 <__swc_bss_base_0a4ed24b+0x2d60>
  40d77c:	mov    rax,QWORD PTR [rsi]
  40d77f:	test   rax,rax
  40d782:	je     40d78a <__swc_fn_0a4ed24b_000169_4694b8ad+0x1a>
  40d784:	add    rsp,0x30
  40d788:	pop    rsi
  40d789:	ret
  40d78a:	mov    ecx,0x2
  40d78f:	mov    edx,0x8020
  40d794:	call   40f7d0 <__swc_fn_0a4ed24b_000107_c8d4a68e>
  40d799:	test   rax,rax
  40d79c:	jne    40d7ad <__swc_fn_0a4ed24b_000169_4694b8ad+0x3d>
  40d79e:	mov    QWORD PTR [rsp+0x18],rax
  40d7a3:	call   40cc10 <__swc_fn_0a4ed24b_000118_591530fe>
  40d7a8:	mov    rax,QWORD PTR [rsp+0x18]
  40d7ad:	mov    rcx,rax
  40d7b0:	xchg   QWORD PTR [rsi],rcx
  40d7b3:	add    rsp,0x30
  40d7b7:	pop    rsi
  40d7b8:	ret
  40d7b9:	add    BYTE PTR [rax],al
  40d7bb:	add    BYTE PTR [rax],al
  40d7bd:	add    BYTE PTR [rax],al
	...

000000000040d7c0 <__swc_fn_0a4ed24b_000172_1751ecdd>:
  40d7c0:	push   rsi
  40d7c1:	test   r8,r8
  40d7c4:	jne    40d7c8 <__swc_fn_0a4ed24b_000172_1751ecdd+0x8>
  40d7c6:	pop    rsi
  40d7c7:	ret
  40d7c8:	lea    rax,[rcx+0x18]
  40d7cc:	mov    r10,QWORD PTR [rax]
  40d7cf:	lea    r11,[r10+0x1]
  40d7d3:	mov    QWORD PTR [rax],r11
  40d7d6:	mov    r11,rdx
  40d7d9:	not    rdx
  40d7dc:	lea    rsi,[r8-0x1]
  40d7e0:	cmp    rsi,rdx
  40d7e3:	ja     40d803 <__swc_fn_0a4ed24b_000172_1751ecdd+0x43>
  40d7e5:	lea    rdx,[r11+r8*1]
  40d7e9:	dec    rdx
  40d7ec:	shr    rdx,0x6
  40d7f0:	mov    r8,r11
  40d7f3:	shr    r8,0x6
  40d7f7:	mov    rsi,rdx
  40d7fa:	sub    rsi,r8
  40d7fd:	cmp    rsi,0x8
  40d801:	jb     40d819 <__swc_fn_0a4ed24b_000172_1751ecdd+0x59>
  40d803:	lea    rcx,[rcx+0x10]
  40d807:	mov    rdx,QWORD PTR [rcx]
  40d80a:	add    rdx,r9
  40d80d:	mov    QWORD PTR [rcx],rdx
  40d810:	lea    rcx,[r10+0x2]
  40d814:	mov    QWORD PTR [rax],rcx
  40d817:	pop    rsi
  40d818:	ret
  40d819:	shr    r11,0x6
  40d81d:	nop    DWORD PTR [rax]
  40d820:	cmp    r11,rdx
  40d823:	ja     40d863 <__swc_fn_0a4ed24b_000172_1751ecdd+0xa3>
  40d825:	jmp    40d836 <__swc_fn_0a4ed24b_000172_1751ecdd+0x76>
  40d827:	nop    WORD PTR [rax+rax*1+0x0]
  40d830:	add    r11,0x1
  40d834:	jmp    40d820 <__swc_fn_0a4ed24b_000172_1751ecdd+0x60>
  40d836:	mov    r8,r11
  40d839:	shr    r8,0xc
  40d83d:	mov    rsi,r11
  40d840:	xor    rsi,r8
  40d843:	mov    r8,r11
  40d846:	shr    r8,0x18
  40d84a:	xor    rsi,r8
  40d84d:	and    esi,0xfff
  40d853:	lea    r8,[rcx+rsi*8+0x20]
  40d858:	mov    rsi,QWORD PTR [r8]
  40d85b:	add    rsi,r9
  40d85e:	mov    QWORD PTR [r8],rsi
  40d861:	jmp    40d830 <__swc_fn_0a4ed24b_000172_1751ecdd+0x70>
  40d863:	lea    rcx,[r10+0x2]
  40d867:	mov    QWORD PTR [rax],rcx
  40d86a:	pop    rsi
  40d86b:	ret
  40d86c:	add    BYTE PTR [rax],al
	...

000000000040d870 <__swc_fn_0a4ed24b_000175_1ca87929>:
  40d870:	push   rdi
  40d871:	push   rsi
  40d872:	sub    rsp,0xb8
  40d879:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40d87f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40d885:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40d88b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40d891:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40d897:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40d89d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40d8a3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40d8ac:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40d8b5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40d8be:	vxorps xmm0,xmm0,xmm0
  40d8c2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40d8c8:	mov    edi,0x1
  40d8cd:	lea    rsi,[rsp+0x8]
  40d8d2:	xor    eax,eax
  40d8d4:	call   407110 <clock_gettime@plt>
  40d8d9:	vxorpd xmm0,xmm0,xmm0
  40d8dd:	mov    rax,QWORD PTR [rsp+0x8]
  40d8e2:	vcvtsi2sd xmm0,xmm0,rax
  40d8e7:	vxorpd xmm1,xmm1,xmm1
  40d8eb:	mov    rax,QWORD PTR [rsp+0x10]
  40d8f0:	vcvtsi2sd xmm1,xmm1,rax
  40d8f5:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x600b]        # 413908 <__swc_rdata_base_0a4ed24b+0x7f8>
  40d8fd:	vaddsd xmm0,xmm0,xmm1
  40d901:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40d907:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40d90d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40d913:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40d919:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40d91f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40d925:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40d92b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40d934:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40d93d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40d946:	add    rsp,0xb8
  40d94d:	pop    rsi
  40d94e:	pop    rdi
  40d94f:	ret
	...

000000000040d960 <__swc_fn_0a4ed24b_000178_a483827c>:
  40d960:	push   rbp
  40d961:	push   rsi
  40d962:	push   rdi
  40d963:	push   r12
  40d965:	sub    rsp,0x90
  40d96c:	mov    rbp,rsp
  40d96f:	vmovups XMMWORD PTR [rsp],xmm6
  40d974:	vmovups XMMWORD PTR [rsp+0x10],xmm7
  40d97a:	vmovups XMMWORD PTR [rsp+0x20],xmm8
  40d980:	vmovups XMMWORD PTR [rsp+0x30],xmm9
  40d986:	vmovups XMMWORD PTR [rsp+0x40],xmm10
  40d98c:	vmovups XMMWORD PTR [rsp+0x50],xmm11
  40d992:	vmovups XMMWORD PTR [rsp+0x60],xmm12
  40d998:	vmovups XMMWORD PTR [rsp+0x70],xmm13
  40d99e:	vmovups XMMWORD PTR [rsp+0x80],xmm14
  40d9a7:	sub    rsp,0x68
  40d9ab:	call   40d870 <__swc_fn_0a4ed24b_000175_1ca87929>
  40d9b0:	add    rsp,0x8
  40d9b4:	vmovups xmm6,xmm0
  40d9b8:	xor    esi,esi
  40d9ba:	xor    edi,edi
  40d9bc:	vmovsd xmm7,QWORD PTR [rip+0x5bf0]        # 4135b4 <__swc_rdata_base_0a4ed24b+0x4a4>
  40d9c4:	vmovsd xmm8,QWORD PTR [rip+0x619c]        # 413b68 <__swc_rdata_base_0a4ed24b+0xa58>
  40d9cc:	vmovsd xmm9,QWORD PTR [rip+0x5f58]        # 41392c <__swc_rdata_base_0a4ed24b+0x81c>
  40d9d4:	vmovsd xmm10,QWORD PTR [rip+0x6195]        # 413b71 <__swc_rdata_base_0a4ed24b+0xa61>
  40d9dc:	vmovsd xmm11,QWORD PTR [rip+0x6196]        # 413b7a <__swc_rdata_base_0a4ed24b+0xa6a>
  40d9e4:	vmovsd xmm12,QWORD PTR [rip+0x6197]        # 413b83 <__swc_rdata_base_0a4ed24b+0xa73>
  40d9ec:	sub    rsp,0x8
  40d9f0:	xor    r12d,r12d
  40d9f3:	vxorpd xmm0,xmm0,xmm0
  40d9f7:	vcvtsi2sd xmm0,xmm0,edi
  40d9fb:	vaddsd xmm0,xmm0,xmm7
  40d9ff:	vdivsd xmm0,xmm0,xmm11
  40da04:	vaddsd xmm0,xmm0,xmm0
  40da08:	vsubsd xmm13,xmm9,xmm0
  40da0c:	vmulsd xmm14,xmm13,xmm13
  40da11:	cs nop WORD PTR [rax+rax*1+0x0]
  40da1b:	cs nop WORD PTR [rax+rax*1+0x0]
  40da25:	cs nop WORD PTR [rax+rax*1+0x0]
  40da2f:	nop
  40da30:	vxorpd xmm0,xmm0,xmm0
  40da34:	vcvtsi2sd xmm0,xmm0,r12d
  40da39:	vaddsd xmm0,xmm0,xmm7
  40da3d:	vdivsd xmm0,xmm0,xmm8
  40da42:	vaddsd xmm0,xmm0,xmm0
  40da46:	vsubsd xmm0,xmm0,xmm9
  40da4b:	vmulsd xmm0,xmm0,xmm10
  40da50:	vmulsd xmm1,xmm0,xmm0
  40da54:	vaddsd xmm1,xmm1,xmm14
  40da59:	vaddsd xmm1,xmm1,xmm9
  40da5e:	vsqrtsd xmm1,xmm1,xmm1
  40da62:	vdivsd xmm5,xmm9,xmm1
  40da66:	vmulsd xmm3,xmm0,xmm5
  40da6a:	vmulsd xmm4,xmm13,xmm5
  40da6e:	vxorpd xmm0,xmm0,xmm0
  40da72:	vxorpd xmm1,xmm1,xmm1
  40da76:	vxorpd xmm2,xmm2,xmm2
  40da7a:	xor    ecx,ecx
  40da7c:	call   40a350 <__swc_fn_0a4ed24b_000177_3634f827>
  40da81:	vmovsd xmm0,QWORD PTR [rip+0x1932f]        # 426db8 <__swc_bss_base_0a4ed24b+0x2d78>
  40da89:	vmulsd xmm0,xmm0,xmm12
  40da8e:	vcvttsd2si rcx,xmm0
  40da93:	vmovsd xmm0,QWORD PTR [rip+0x19325]        # 426dc0 <__swc_bss_base_0a4ed24b+0x2d80>
  40da9b:	vmulsd xmm0,xmm0,xmm12
  40daa0:	vcvttsd2si r8,xmm0
  40daa5:	vmovsd xmm0,QWORD PTR [rip+0x1931b]        # 426dc8 <__swc_bss_base_0a4ed24b+0x2d88>
  40daad:	vmulsd xmm0,xmm0,xmm12
  40dab2:	vcvttsd2si r10,xmm0
  40dab7:	cmp    rcx,0xff
  40dabe:	mov    eax,0xff
  40dac3:	cmovg  rcx,rax
  40dac7:	cmp    r8,0xff
  40dace:	cmovg  r8,rax
  40dad2:	cmp    r10,0xff
  40dad9:	cmovg  r10,rax
  40dadd:	lea    rcx,[rcx+r8*2]
  40dae1:	lea    rax,[r10+r10*2]
  40dae5:	add    rcx,rax
  40dae8:	add    rsi,rcx
  40daeb:	add    r12,0x1
  40daef:	cmp    r12,0x1e0
  40daf6:	jl     40da30 <__swc_fn_0a4ed24b_000178_a483827c+0xd0>
  40dafc:	add    rdi,0x1
  40db00:	cmp    rdi,0x168
  40db07:	jl     40d9f0 <__swc_fn_0a4ed24b_000178_a483827c+0x90>
  40db0d:	add    rsp,0x8
  40db11:	sub    rsp,0x8
  40db15:	call   40d870 <__swc_fn_0a4ed24b_000175_1ca87929>
  40db1a:	add    rsp,0x8
  40db1e:	vsubsd xmm0,xmm0,xmm6
  40db22:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x6062]        # 413b8c <__swc_rdata_base_0a4ed24b+0xa7c>
  40db2a:	lea    rax,[rip+0x5837]        # 413368 <__swc_rdata_base_0a4ed24b+0x258>
  40db31:	sub    rsp,0x90
  40db38:	mov    rcx,rsp
  40db3b:	vmovups xmm1,XMMWORD PTR [rip+0x6005]        # 413b48 <__swc_rdata_base_0a4ed24b+0xa38>
  40db43:	vmovups XMMWORD PTR [rcx],xmm1
  40db47:	mov    QWORD PTR [rcx+0x30],rsp
  40db4b:	lea    rdx,[rip+0x57be]        # 413310 <__swc_rdata_base_0a4ed24b+0x200>
  40db52:	mov    QWORD PTR [rcx+0x38],rdx
  40db56:	mov    QWORD PTR [rcx+0x10],rsi
  40db5a:	lea    r8,[rsp+0x10]
  40db5f:	mov    QWORD PTR [rcx+0x40],r8
  40db63:	lea    r8,[rip+0x5f4e]        # 413ab8 <__swc_rdata_base_0a4ed24b+0x9a8>
  40db6a:	mov    QWORD PTR [rcx+0x48],r8
  40db6e:	vmovups xmm1,XMMWORD PTR [rip+0x5fe2]        # 413b58 <__swc_rdata_base_0a4ed24b+0xa48>
  40db76:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40db7b:	lea    r8,[rsp+0x18]
  40db80:	mov    QWORD PTR [rcx+0x50],r8
  40db84:	mov    QWORD PTR [rcx+0x58],rdx
  40db88:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40db8d:	lea    r8,[rcx+0x28]
  40db91:	mov    QWORD PTR [rcx+0x60],r8
  40db95:	lea    r8,[rip+0x5f64]        # 413b00 <__swc_rdata_base_0a4ed24b+0x9f0>
  40db9c:	mov    QWORD PTR [rcx+0x68],r8
  40dba0:	mov    QWORD PTR [rcx+0x70],rax
  40dba4:	mov    QWORD PTR [rcx+0x78],rdx
  40dba8:	lea    rax,[rcx+0x30]
  40dbac:	mov    QWORD PTR [rcx+0x80],rax
  40dbb3:	mov    QWORD PTR [rcx+0x88],0x5
  40dbbe:	lea    rcx,[rcx+0x80]
  40dbc5:	sub    rsp,0x8
  40dbc9:	call   410720 <__swc_fn_0a4ed24b_000146_d2097256>
  40dbce:	add    rsp,0xf8
  40dbd5:	vmovups xmm6,XMMWORD PTR [rsp]
  40dbda:	vmovups xmm7,XMMWORD PTR [rsp+0x10]
  40dbe0:	vmovups xmm8,XMMWORD PTR [rsp+0x20]
  40dbe6:	vmovups xmm9,XMMWORD PTR [rsp+0x30]
  40dbec:	vmovups xmm10,XMMWORD PTR [rsp+0x40]
  40dbf2:	vmovups xmm11,XMMWORD PTR [rsp+0x50]
  40dbf8:	vmovups xmm12,XMMWORD PTR [rsp+0x60]
  40dbfe:	vmovups xmm13,XMMWORD PTR [rsp+0x70]
  40dc04:	vmovups xmm14,XMMWORD PTR [rsp+0x80]
  40dc0d:	add    rsp,0x90
  40dc14:	pop    r12
  40dc16:	pop    rdi
  40dc17:	pop    rsi
  40dc18:	pop    rbp
  40dc19:	ret
  40dc1a:	add    BYTE PTR [rax],al
  40dc1c:	add    BYTE PTR [rax],al
	...

000000000040dc20 <__swc_fn_0a4ed24b_000002_102336c4>:
  40dc20:	sub    rsp,0x8
  40dc24:	call   40c860 <__swc_fn_0a4ed24b_000109_9f5af8ae>
  40dc29:	mov    rcx,rax
  40dc2c:	test   rax,rax
  40dc2f:	je     40dc56 <__swc_fn_0a4ed24b_000002_102336c4+0x36>
  40dc31:	lea    rdx,[rip+0x16408]        # 424040 <__swc_bss_base_0a4ed24b>
  40dc38:	mov    r8,QWORD PTR [rip+0x16401]        # 424040 <__swc_bss_base_0a4ed24b>
  40dc3f:	nop
  40dc40:	lea    r9,[r8+0x1]
  40dc44:	mov    rax,r8
  40dc47:	lock cmpxchg QWORD PTR [rdx],r9
  40dc4c:	cmp    rax,r8
  40dc4f:	je     40dc56 <__swc_fn_0a4ed24b_000002_102336c4+0x36>
  40dc51:	mov    r8,rax
  40dc54:	jmp    40dc40 <__swc_fn_0a4ed24b_000002_102336c4+0x20>
  40dc56:	mov    rax,rcx
  40dc59:	add    rsp,0x8
  40dc5d:	ret
	...

000000000040dc60 <__swc_fn_0a4ed24b_000005_6a556171>:
  40dc60:	mov    r8d,edx
  40dc63:	xor    eax,eax
  40dc65:	tzcnt  eax,edx
  40dc69:	shrx   r9d,edx,eax
  40dc6e:	mov    DWORD PTR [rcx+0x2c],edx
  40dc71:	xor    eax,eax
  40dc73:	tzcnt  eax,edx
  40dc77:	mov    BYTE PTR [rcx+0x38],al
  40dc7a:	mov    eax,0xffffffff
  40dc7f:	xor    edx,edx
  40dc81:	div    r8d
  40dc84:	mov    DWORD PTR [rcx+0x34],eax
  40dc87:	mov    eax,r9d
  40dc8a:	mov    edx,r9d
  40dc8d:	imul   edx,r9d
  40dc91:	mov    r8d,0x2
  40dc97:	sub    r8d,edx
  40dc9a:	imul   eax,r8d
  40dc9e:	mov    edx,r9d
  40dca1:	imul   edx,eax
  40dca4:	mov    r8d,0x2
  40dcaa:	sub    r8d,edx
  40dcad:	imul   eax,r8d
  40dcb1:	mov    edx,r9d
  40dcb4:	imul   edx,eax
  40dcb7:	mov    r8d,0x2
  40dcbd:	sub    r8d,edx
  40dcc0:	imul   eax,r8d
  40dcc4:	mov    edx,r9d
  40dcc7:	imul   edx,eax
  40dcca:	mov    r8d,0x2
  40dcd0:	sub    r8d,edx
  40dcd3:	imul   eax,r8d
  40dcd7:	imul   r9d,eax
  40dcdb:	mov    edx,0x2
  40dce0:	sub    edx,r9d
  40dce3:	imul   eax,edx
  40dce6:	mov    DWORD PTR [rcx+0x30],eax
  40dce9:	ret
  40dcea:	add    BYTE PTR [rax],al
  40dcec:	add    BYTE PTR [rax],al
	...

000000000040dcf0 <__swc_fn_0a4ed24b_000008_b2f73e0d>:
  40dcf0:	xor    eax,eax
  40dcf2:	mov    DWORD PTR [rcx+0x68],eax
  40dcf5:	ret
	...

000000000040dd00 <__swc_fn_0a4ed24b_000011_71c91685>:
  40dd00:	mov    eax,DWORD PTR [rcx+0x28]
  40dd03:	shlx   eax,edx,eax
  40dd08:	shl    rax,0x10
  40dd0c:	lea    rdx,[rcx+rax*1]
  40dd10:	lea    rax,[rcx+0x3000]
  40dd17:	cmp    rdx,rax
  40dd1a:	cmovae rax,rdx
  40dd1e:	ret
	...

000000000040dd20 <__swc_fn_0a4ed24b_000014_be17798c>:
  40dd20:	push   rsi
  40dd21:	push   rdi
  40dd22:	push   r12
  40dd24:	push   r13
  40dd26:	push   r14
  40dd28:	mov    rsi,rdx
  40dd2b:	mov    rdi,rcx
  40dd2e:	rex mov dl,BYTE PTR [rsi+0x3a]
  40dd32:	mov    ecx,DWORD PTR [rdi+0x28]
  40dd35:	shr    dl,cl
  40dd37:	mov    r12d,0x1
  40dd3d:	mov    ecx,edx
  40dd3f:	shl    r12,cl
  40dd42:	mov    r13d,DWORD PTR [rsi+0x3c]
  40dd46:	rex mov BYTE PTR [rsi+0x3b],0x0
  40dd4b:	mov    QWORD PTR [rsi+0x40],0x0
  40dd53:	mov    QWORD PTR [rsi],0x0
  40dd5a:	mov    rax,QWORD PTR [rsi+0x10]
  40dd5e:	mov    QWORD PTR [rsi+0x20],rax
  40dd62:	lea    r14,[rip+0x162df]        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  40dd69:	mov    rax,QWORD PTR [r14]
  40dd6c:	shr    rax,0x2
  40dd70:	mov    rcx,rax
  40dd73:	cmp    rax,0x800000
  40dd7a:	mov    eax,0x800000
  40dd7f:	cmovb  rcx,rax
  40dd83:	lea    r8,[rip+0x162ce]        # 424058 <__swc_bss_base_0a4ed24b+0x18>
  40dd8a:	mov    rax,QWORD PTR [r8]
  40dd8d:	mov    r9,rax
  40dd90:	lea    r10,[r9+r13*1]
  40dd94:	cmp    r10,rcx
  40dd97:	ja     40ddbb <__swc_fn_0a4ed24b_000014_be17798c+0x9b>
  40dd99:	mov    rax,r9
  40dd9c:	lock cmpxchg QWORD PTR [r8],r10
  40dda1:	cmp    rax,r9
  40dda4:	je     40ddab <__swc_fn_0a4ed24b_000014_be17798c+0x8b>
  40dda6:	mov    r9,rax
  40dda9:	jmp    40dd90 <__swc_fn_0a4ed24b_000014_be17798c+0x70>
  40ddab:	mov    rcx,rdi
  40ddae:	mov    rdx,r12
  40ddb1:	call   40a990 <__swc_fn_0a4ed24b_000016_a0b588d0>
  40ddb6:	jmp    40de3d <__swc_fn_0a4ed24b_000014_be17798c+0x11d>
  40ddbb:	mov    rcx,rdi
  40ddbe:	movzx  edx,dl
  40ddc1:	call   40dd00 <__swc_fn_0a4ed24b_000011_71c91685>
  40ddc6:	test   r13,r13
  40ddc9:	je     40de36 <__swc_fn_0a4ed24b_000014_be17798c+0x116>
  40ddcf:	mov    rcx,rax
  40ddd2:	mov    rdx,r13
  40ddd5:	call   40c9e0 <__swc_fn_0a4ed24b_000112_2f7f9346>
  40ddda:	mov    rcx,QWORD PTR [rip+0x16267]        # 424048 <__swc_bss_base_0a4ed24b+0x8>
  40dde1:	cs nop WORD PTR [rax+rax*1+0x0]
  40ddeb:	nop    DWORD PTR [rax+rax*1+0x0]
  40ddf0:	mov    rdx,rcx
  40ddf3:	sub    rdx,r13
  40ddf6:	mov    rax,rcx
  40ddf9:	lock cmpxchg QWORD PTR [r14],rdx
  40ddfe:	cmp    rax,rcx
  40de01:	je     40de08 <__swc_fn_0a4ed24b_000014_be17798c+0xe8>
  40de03:	mov    rcx,rax
  40de06:	jmp    40ddf0 <__swc_fn_0a4ed24b_000014_be17798c+0xd0>
  40de08:	lea    rcx,[rip+0x16251]        # 424060 <__swc_bss_base_0a4ed24b+0x20>
  40de0f:	mov    rdx,QWORD PTR [rip+0x1624a]        # 424060 <__swc_bss_base_0a4ed24b+0x20>
  40de16:	cs nop WORD PTR [rax+rax*1+0x0]
  40de20:	lea    r8,[rdx+0x1]
  40de24:	mov    rax,rdx
  40de27:	lock cmpxchg QWORD PTR [rcx],r8
  40de2c:	cmp    rax,rdx
  40de2f:	je     40de36 <__swc_fn_0a4ed24b_000014_be17798c+0x116>
  40de31:	mov    rdx,rax
  40de34:	jmp    40de20 <__swc_fn_0a4ed24b_000014_be17798c+0x100>
  40de36:	mov    DWORD PTR [rsi+0x3c],0x0
  40de3d:	mov    rcx,rdi
  40de40:	mov    rdx,r12
  40de43:	call   407600 <__swc_fn_0a4ed24b_000018_77ece227>
  40de48:	pop    r14
  40de4a:	pop    r13
  40de4c:	pop    r12
  40de4e:	pop    rdi
  40de4f:	pop    rsi
  40de50:	ret
	...

000000000040de60 <__swc_fn_0a4ed24b_000017_f003fc47>:
  40de60:	mov    r8,QWORD PTR [rcx+0x48]
  40de64:	test   r8,rdx
  40de67:	je     40de98 <__swc_fn_0a4ed24b_000017_f003fc47+0x38>
  40de69:	nop    DWORD PTR [rax+0x0]
  40de70:	mov    rax,rdx
  40de73:	not    rax
  40de76:	mov    r9,r8
  40de79:	and    r9,rax
  40de7c:	mov    rax,r8
  40de7f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40de85:	cmp    rax,r8
  40de88:	jne    40de90 <__swc_fn_0a4ed24b_000017_f003fc47+0x30>
  40de8a:	mov    eax,0x1
  40de8f:	ret
  40de90:	mov    r8,rax
  40de93:	test   rax,rdx
  40de96:	jne    40de70 <__swc_fn_0a4ed24b_000017_f003fc47+0x10>
  40de98:	xor    eax,eax
  40de9a:	ret
  40de9b:	add    BYTE PTR [rax],al
  40de9d:	add    BYTE PTR [rax],al
	...

000000000040dea0 <__swc_fn_0a4ed24b_000020_4285d9c5>:
  40dea0:	push   rsi
  40dea1:	push   rdi
  40dea2:	push   r12
  40dea4:	push   r13
  40dea6:	sub    rsp,0x8
  40deaa:	mov    rsi,rdx
  40dead:	mov    rdi,rcx
  40deb0:	lea    r12,[rip+0x16339]        # 4241f0 <__swc_bss_base_0a4ed24b+0x1b0>
  40deb7:	mov    rcx,r12
  40deba:	call   4098a0 <__swc_fn_0a4ed24b_000135_db32cc57>
  40debf:	xor    eax,eax
  40dec1:	mov    rcx,QWORD PTR [rip+0x16330]        # 4241f8 <__swc_bss_base_0a4ed24b+0x1b8>
  40dec8:	mov    r13,rcx
  40decb:	test   r13,r13
  40dece:	je     40df1b <__swc_fn_0a4ed24b_000020_4285d9c5+0x7b>
  40ded0:	mov    rcx,QWORD PTR [r13+0x10]
  40ded4:	cmp    DWORD PTR [r13+0x28],esi
  40ded8:	jne    40df10 <__swc_fn_0a4ed24b_000020_4285d9c5+0x70>
  40deda:	test   rax,rax
  40dedd:	jne    40dee8 <__swc_fn_0a4ed24b_000020_4285d9c5+0x48>
  40dedf:	mov    QWORD PTR [rip+0x16312],rcx        # 4241f8 <__swc_bss_base_0a4ed24b+0x1b8>
  40dee6:	jmp    40deec <__swc_fn_0a4ed24b_000020_4285d9c5+0x4c>
  40dee8:	mov    QWORD PTR [rax+0x10],rcx
  40deec:	vxorps xmm0,xmm0,xmm0
  40def0:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40def6:	mov    QWORD PTR [r13+0x8],rdi
  40defa:	mov    rcx,r12
  40defd:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  40df02:	mov    rax,r13
  40df05:	add    rsp,0x8
  40df09:	pop    r13
  40df0b:	pop    r12
  40df0d:	pop    rdi
  40df0e:	pop    rsi
  40df0f:	ret
  40df10:	mov    rax,r13
  40df13:	mov    r13,rcx
  40df16:	test   rcx,rcx
  40df19:	jne    40ded0 <__swc_fn_0a4ed24b_000020_4285d9c5+0x30>
  40df1b:	mov    ecx,esi
  40df1d:	call   40a9c0 <__swc_fn_0a4ed24b_000019_447bb610>
  40df22:	mov    rsi,rax
  40df25:	test   rax,rax
  40df28:	jne    40df3f <__swc_fn_0a4ed24b_000020_4285d9c5+0x9f>
  40df2a:	mov    rcx,r12
  40df2d:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  40df32:	xor    eax,eax
  40df34:	add    rsp,0x8
  40df38:	pop    r13
  40df3a:	pop    r12
  40df3c:	pop    rdi
  40df3d:	pop    rsi
  40df3e:	ret
  40df3f:	mov    QWORD PTR [rsi+0x8],rdi
  40df43:	mov    rcx,r12
  40df46:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  40df4b:	mov    rax,rsi
  40df4e:	add    rsp,0x8
  40df52:	pop    r13
  40df54:	pop    r12
  40df56:	pop    rdi
  40df57:	pop    rsi
  40df58:	ret
  40df59:	add    BYTE PTR [rax],al
  40df5b:	add    BYTE PTR [rax],al
  40df5d:	add    BYTE PTR [rax],al
	...

000000000040df60 <__swc_fn_0a4ed24b_000023_e876734d>:
  40df60:	vxorps xmm0,xmm0,xmm0
  40df64:	xor    eax,eax
  40df66:	cs nop WORD PTR [rax+rax*1+0x0]
  40df70:	cs nop WORD PTR [rax+rax*1+0x0]
  40df7a:	nop    WORD PTR [rax+rax*1+0x0]
  40df80:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40df85:	add    rax,0x10
  40df89:	cmp    rax,0x2b00
  40df90:	jne    40df80 <__swc_fn_0a4ed24b_000023_e876734d+0x20>
  40df92:	ret
	...

000000000040dfa0 <__swc_fn_0a4ed24b_000026_e876734d>:
  40dfa0:	vxorps xmm0,xmm0,xmm0
  40dfa4:	vmovups XMMWORD PTR [rcx],xmm0
  40dfa8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40dfad:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40dfb2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40dfb7:	ret
	...

000000000040dfc0 <__swc_fn_0a4ed24b_000029_e876734d>:
  40dfc0:	vxorps xmm0,xmm0,xmm0
  40dfc4:	vmovups XMMWORD PTR [rcx],xmm0
  40dfc8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40dfcd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40dfd2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40dfd7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40dfdc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40dfe1:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40dfe6:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40dfeb:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40dff3:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40dffb:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40e003:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40e00b:	mov    QWORD PTR [rcx+0xc0],0x0
  40e016:	ret
	...

000000000040e020 <__swc_fn_0a4ed24b_000032_f1940e30>:
  40e020:	push   rsi
  40e021:	push   rdi
  40e022:	sub    rsp,0x8
  40e026:	mov    rsi,rcx
  40e029:	lea    rdi,[rip+0x13fd0]        # 422000 <__swc_data_base_0a4ed24b>
  40e030:	mov    rax,QWORD PTR [rdi]
  40e033:	cmp    rax,0xffffffffffffffff
  40e037:	je     40e03e <__swc_fn_0a4ed24b_000032_f1940e30+0x1e>
  40e039:	mov    rdi,rax
  40e03c:	jmp    40e06b <__swc_fn_0a4ed24b_000032_f1940e30+0x4b>
  40e03e:	call   409580 <__swc_fn_0a4ed24b_000123_e4107ade>
  40e043:	mov    rcx,rax
  40e046:	cmp    rax,0xffffffffffffffff
  40e04a:	je     40e07c <__swc_fn_0a4ed24b_000032_f1940e30+0x5c>
  40e04c:	mov    rax,0xffffffffffffffff
  40e053:	lock cmpxchg QWORD PTR [rdi],rcx
  40e058:	cmp    rax,0xffffffffffffffff
  40e05c:	je     40e068 <__swc_fn_0a4ed24b_000032_f1940e30+0x48>
  40e05e:	mov    rdi,rax
  40e061:	call   40cdb0 <__swc_fn_0a4ed24b_000124_37eaf452>
  40e066:	jmp    40e06b <__swc_fn_0a4ed24b_000032_f1940e30+0x4b>
  40e068:	mov    rdi,rcx
  40e06b:	cmp    rdi,0xffffffffffffffff
  40e06f:	je     40e07c <__swc_fn_0a4ed24b_000032_f1940e30+0x5c>
  40e071:	mov    rcx,rdi
  40e074:	mov    rdx,rsi
  40e077:	call   410130 <__swc_fn_0a4ed24b_000125_7a81492f>
  40e07c:	add    rsp,0x8
  40e080:	pop    rdi
  40e081:	pop    rsi
  40e082:	ret
	...

000000000040e090 <__swc_fn_0a4ed24b_000035_ab2e8c35>:
  40e090:	sub    rsp,0x38
  40e094:	mov    rax,rdx
  40e097:	test   dl,dl
  40e099:	jne    40e0b1 <__swc_fn_0a4ed24b_000035_ab2e8c35+0x21>
  40e09b:	mov    rax,r8
  40e09e:	test   r8b,r8b
  40e0a1:	cmove  eax,r9d
  40e0a5:	test   al,al
  40e0a7:	cmove  eax,r10d
  40e0ab:	test   al,al
  40e0ad:	cmove  eax,r11d
  40e0b1:	test   al,al
  40e0b3:	jne    40e0ba <__swc_fn_0a4ed24b_000035_ab2e8c35+0x2a>
  40e0b5:	add    rsp,0x38
  40e0b9:	ret
  40e0ba:	lea    rcx,[rip+0x504f]        # 413110 <__swc_rdata_base_0a4ed24b>
  40e0c1:	vmovups xmm0,XMMWORD PTR [rip+0x5057]        # 413120 <__swc_rdata_base_0a4ed24b+0x10>
  40e0c9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e0cf:	vmovups xmm0,XMMWORD PTR [rip+0x5059]        # 413130 <__swc_rdata_base_0a4ed24b+0x20>
  40e0d7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e0dd:	vmovups xmm0,XMMWORD PTR [rip+0x505b]        # 413140 <__swc_rdata_base_0a4ed24b+0x30>
  40e0e5:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e0eb:	lea    rdx,[rsp+0x8]
  40e0f0:	call   40c5e0 <__swc_fn_0a4ed24b_000103_0d4cc079>
  40e0f5:	jmp    40e0b5 <__swc_fn_0a4ed24b_000035_ab2e8c35+0x25>
	...

000000000040e100 <__swc_fn_0a4ed24b_000038_292d55e5>:
  40e100:	sub    rsp,0x8
  40e104:	mov    eax,0x1000
  40e109:	test   eax,eax
  40e10b:	mov    r8d,0x8
  40e111:	cmove  eax,r8d
  40e115:	dec    rax
  40e118:	mov    r8,0xffffffffffffffff
  40e11f:	sub    r8,rax
  40e122:	cmp    rdx,r8
  40e125:	ja     40e135 <__swc_fn_0a4ed24b_000038_292d55e5+0x35>
  40e127:	add    rdx,rax
  40e12a:	not    rax
  40e12d:	mov    r8,rdx
  40e130:	and    r8,rax
  40e133:	jne    40e13c <__swc_fn_0a4ed24b_000038_292d55e5+0x3c>
  40e135:	xor    eax,eax
  40e137:	add    rsp,0x8
  40e13b:	ret
  40e13c:	mov    rdx,r8
  40e13f:	call   40ace0 <__swc_fn_0a4ed24b_000037_1e381f55>
  40e144:	add    rsp,0x8
  40e148:	ret
  40e149:	add    BYTE PTR [rax],al
  40e14b:	add    BYTE PTR [rax],al
  40e14d:	add    BYTE PTR [rax],al
	...

000000000040e150 <__swc_fn_0a4ed24b_000041_41400651>:
  40e150:	push   rsi
  40e151:	push   rdi
  40e152:	sub    rsp,0x8
  40e156:	mov    rsi,rdx
  40e159:	mov    rdi,rcx
  40e15c:	test   rdx,rdx
  40e15f:	je     40e17b <__swc_fn_0a4ed24b_000041_41400651+0x2b>
  40e161:	xor    ecx,ecx
  40e163:	call   407720 <__swc_fn_0a4ed24b_000033_d15eb4ea>
  40e168:	mov    rax,QWORD PTR [rsi]
  40e16b:	test   rax,rax
  40e16e:	je     40e17b <__swc_fn_0a4ed24b_000041_41400651+0x2b>
  40e170:	mov    rcx,rax
  40e173:	mov    rdx,rsi
  40e176:	call   407840 <__swc_fn_0a4ed24b_000042_0573444d>
  40e17b:	mov    rcx,rdi
  40e17e:	call   40ad40 <__swc_fn_0a4ed24b_000040_8029566e>
  40e183:	mov    rsi,rax
  40e186:	test   rax,rax
  40e189:	jne    40e194 <__swc_fn_0a4ed24b_000041_41400651+0x44>
  40e18b:	xor    eax,eax
  40e18d:	add    rsp,0x8
  40e191:	pop    rdi
  40e192:	pop    rsi
  40e193:	ret
  40e194:	mov    rcx,rsi
  40e197:	call   407720 <__swc_fn_0a4ed24b_000033_d15eb4ea>
  40e19c:	mov    rax,rsi
  40e19f:	add    rsp,0x8
  40e1a3:	pop    rdi
  40e1a4:	pop    rsi
  40e1a5:	ret
	...

000000000040e1b0 <__swc_fn_0a4ed24b_000044_fe6bbfdb>:
  40e1b0:	movzx  eax,BYTE PTR [r8+0x39]
  40e1b5:	lea    rax,[rax+rax*4]
  40e1b9:	lea    rax,[rdx+rax*8+0x28]
  40e1be:	mov    ecx,DWORD PTR [r8+0x6c]
  40e1c2:	test   ecx,ecx
  40e1c4:	je     40e1fd <__swc_fn_0a4ed24b_000044_fe6bbfdb+0x4d>
  40e1c6:	mov    rcx,QWORD PTR [r8+0x50]
  40e1ca:	test   rcx,rcx
  40e1cd:	je     40e1d9 <__swc_fn_0a4ed24b_000044_fe6bbfdb+0x29>
  40e1cf:	mov    rax,QWORD PTR [r8+0x48]
  40e1d3:	mov    QWORD PTR [rcx+0x48],rax
  40e1d7:	jmp    40e1e1 <__swc_fn_0a4ed24b_000044_fe6bbfdb+0x31>
  40e1d9:	mov    rcx,QWORD PTR [r8+0x48]
  40e1dd:	mov    QWORD PTR [rax+0x18],rcx
  40e1e1:	mov    rax,QWORD PTR [r8+0x48]
  40e1e5:	test   rax,rax
  40e1e8:	je     40e1f2 <__swc_fn_0a4ed24b_000044_fe6bbfdb+0x42>
  40e1ea:	mov    rcx,QWORD PTR [r8+0x50]
  40e1ee:	mov    QWORD PTR [rax+0x50],rcx
  40e1f2:	vxorps xmm0,xmm0,xmm0
  40e1f6:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e1fc:	ret
  40e1fd:	mov    rcx,QWORD PTR [r8+0x50]
  40e201:	test   rcx,rcx
  40e204:	je     40e210 <__swc_fn_0a4ed24b_000044_fe6bbfdb+0x60>
  40e206:	mov    rdx,QWORD PTR [r8+0x48]
  40e20a:	mov    QWORD PTR [rcx+0x48],rdx
  40e20e:	jmp    40e218 <__swc_fn_0a4ed24b_000044_fe6bbfdb+0x68>
  40e210:	mov    rcx,QWORD PTR [r8+0x48]
  40e214:	mov    QWORD PTR [rax+0x8],rcx
  40e218:	mov    rcx,QWORD PTR [r8+0x48]
  40e21c:	test   rcx,rcx
  40e21f:	je     40e22b <__swc_fn_0a4ed24b_000044_fe6bbfdb+0x7b>
  40e221:	mov    rdx,QWORD PTR [r8+0x50]
  40e225:	mov    QWORD PTR [rcx+0x50],rdx
  40e229:	jmp    40e233 <__swc_fn_0a4ed24b_000044_fe6bbfdb+0x83>
  40e22b:	mov    rcx,QWORD PTR [r8+0x50]
  40e22f:	mov    QWORD PTR [rax+0x10],rcx
  40e233:	cmp    QWORD PTR [rax],r8
  40e236:	jne    40e23f <__swc_fn_0a4ed24b_000044_fe6bbfdb+0x8f>
  40e238:	mov    QWORD PTR [rax],0x0
  40e23f:	vxorps xmm0,xmm0,xmm0
  40e243:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e249:	ret
  40e24a:	add    BYTE PTR [rax],al
  40e24c:	add    BYTE PTR [rax],al
	...

000000000040e250 <__swc_fn_0a4ed24b_000047_e7fd8d42>:
  40e250:	sub    rsp,0x8
  40e254:	mov    r9,r8
  40e257:	mov    r10,rdx
  40e25a:	call   40e1b0 <__swc_fn_0a4ed24b_000044_fe6bbfdb>
  40e25f:	mov    DWORD PTR [r9+0x6c],0x0
  40e267:	movzx  eax,BYTE PTR [r9+0x39]
  40e26c:	lea    rax,[rax+rax*4]
  40e270:	lea    rax,[r10+rax*8+0x28]
  40e275:	mov    rcx,QWORD PTR [rax+0x10]
  40e279:	mov    QWORD PTR [r9+0x50],rcx
  40e27d:	mov    QWORD PTR [r9+0x48],0x0
  40e285:	mov    rcx,QWORD PTR [rax+0x10]
  40e289:	test   rcx,rcx
  40e28c:	je     40e294 <__swc_fn_0a4ed24b_000047_e7fd8d42+0x44>
  40e28e:	mov    QWORD PTR [rcx+0x48],r9
  40e292:	jmp    40e298 <__swc_fn_0a4ed24b_000047_e7fd8d42+0x48>
  40e294:	mov    QWORD PTR [rax+0x8],r9
  40e298:	mov    QWORD PTR [rax+0x10],r9
  40e29c:	add    rsp,0x8
  40e2a0:	ret
	...

000000000040e2c0 <__swc_fn_0a4ed24b_000050_5e919db9>:
  40e2c0:	push   rsi
  40e2c1:	push   rdi
  40e2c2:	push   r12
  40e2c4:	push   r13
  40e2c6:	push   r14
  40e2c8:	push   r15
  40e2ca:	sub    rsp,0x1f8
  40e2d1:	mov    esi,r8d
  40e2d4:	mov    QWORD PTR [rsp+0x1e8],rsi
  40e2dc:	mov    rdi,rcx
  40e2df:	mov    r12,rdx
  40e2e2:	lea    r13,[rsi+rsi*4]
  40e2e6:	lea    r13,[rdx+r13*8+0x28]
  40e2eb:	call   407ca0 <__swc_fn_0a4ed24b_000048_8e68f77b>
  40e2f0:	add    DWORD PTR [r12+0x24],0x1
  40e2f6:	test   BYTE PTR [r12+0x24],0x3f
  40e2fc:	jne    40e306 <__swc_fn_0a4ed24b_000050_5e919db9+0x46>
  40e2fe:	mov    rcx,rdi
  40e301:	call   40aec0 <__swc_fn_0a4ed24b_000049_f6a485a2>
  40e306:	mov    rax,QWORD PTR [r13+0x8]
  40e30a:	mov    r14,rax
  40e30d:	nop    DWORD PTR [rax]
  40e310:	test   r14,r14
  40e313:	jne    40e322 <__swc_fn_0a4ed24b_000050_5e919db9+0x62>
  40e315:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40e31d:	jmp    40e429 <__swc_fn_0a4ed24b_000050_5e919db9+0x169>
  40e322:	mov    r15,QWORD PTR [r14+0x48]
  40e326:	mov    rcx,r14
  40e329:	call   4073f0 <__swc_fn_0a4ed24b_000009_4c3ebf16>
  40e32e:	mov    rax,QWORD PTR [r14]
  40e331:	test   rax,rax
  40e334:	je     40e346 <__swc_fn_0a4ed24b_000050_5e919db9+0x86>
  40e336:	mov    rcx,QWORD PTR [rax]
  40e339:	mov    QWORD PTR [r14],rcx
  40e33c:	add    DWORD PTR [r14+0x28],0x1
  40e341:	mov    rsi,rax
  40e344:	jmp    40e365 <__swc_fn_0a4ed24b_000050_5e919db9+0xa5>
  40e346:	mov    rax,QWORD PTR [r14+0x18]
  40e34a:	cmp    QWORD PTR [r14+0x20],rax
  40e34e:	jae    40e363 <__swc_fn_0a4ed24b_000050_5e919db9+0xa3>
  40e350:	mov    rsi,QWORD PTR [r14+0x20]
  40e354:	mov    eax,DWORD PTR [r14+0x2c]
  40e358:	add    QWORD PTR [r14+0x20],rax
  40e35c:	add    DWORD PTR [r14+0x28],0x1
  40e361:	jmp    40e365 <__swc_fn_0a4ed24b_000050_5e919db9+0xa5>
  40e363:	xor    esi,esi
  40e365:	test   rsi,rsi
  40e368:	jne    40e3ad <__swc_fn_0a4ed24b_000050_5e919db9+0xed>
  40e36a:	mov    rcx,r14
  40e36d:	call   407320 <__swc_fn_0a4ed24b_000006_7b253ae1>
  40e372:	test   al,al
  40e374:	je     40e3ad <__swc_fn_0a4ed24b_000050_5e919db9+0xed>
  40e376:	mov    rax,QWORD PTR [r14]
  40e379:	test   rax,rax
  40e37c:	je     40e38b <__swc_fn_0a4ed24b_000050_5e919db9+0xcb>
  40e37e:	mov    rcx,QWORD PTR [rax]
  40e381:	mov    QWORD PTR [r14],rcx
  40e384:	add    DWORD PTR [r14+0x28],0x1
  40e389:	jmp    40e3aa <__swc_fn_0a4ed24b_000050_5e919db9+0xea>
  40e38b:	mov    rax,QWORD PTR [r14+0x18]
  40e38f:	cmp    QWORD PTR [r14+0x20],rax
  40e393:	jae    40e3a8 <__swc_fn_0a4ed24b_000050_5e919db9+0xe8>
  40e395:	mov    rax,QWORD PTR [r14+0x20]
  40e399:	mov    ecx,DWORD PTR [r14+0x2c]
  40e39d:	add    QWORD PTR [r14+0x20],rcx
  40e3a1:	add    DWORD PTR [r14+0x28],0x1
  40e3a6:	jmp    40e3aa <__swc_fn_0a4ed24b_000050_5e919db9+0xea>
  40e3a8:	xor    eax,eax
  40e3aa:	mov    rsi,rax
  40e3ad:	test   rsi,rsi
  40e3b0:	jne    40e403 <__swc_fn_0a4ed24b_000050_5e919db9+0x143>
  40e3b2:	mov    rcx,rdi
  40e3b5:	mov    rdx,r12
  40e3b8:	mov    r8,r14
  40e3bb:	call   40ae20 <__swc_fn_0a4ed24b_000046_b28a6ee7>
  40e3c0:	test   al,al
  40e3c2:	jne    40e403 <__swc_fn_0a4ed24b_000050_5e919db9+0x143>
  40e3c4:	mov    rcx,r14
  40e3c7:	call   4073f0 <__swc_fn_0a4ed24b_000009_4c3ebf16>
  40e3cc:	mov    rax,QWORD PTR [r14]
  40e3cf:	test   rax,rax
  40e3d2:	je     40e3e1 <__swc_fn_0a4ed24b_000050_5e919db9+0x121>
  40e3d4:	mov    rcx,QWORD PTR [rax]
  40e3d7:	mov    QWORD PTR [r14],rcx
  40e3da:	add    DWORD PTR [r14+0x28],0x1
  40e3df:	jmp    40e400 <__swc_fn_0a4ed24b_000050_5e919db9+0x140>
  40e3e1:	mov    rax,QWORD PTR [r14+0x18]
  40e3e5:	cmp    QWORD PTR [r14+0x20],rax
  40e3e9:	jae    40e3fe <__swc_fn_0a4ed24b_000050_5e919db9+0x13e>
  40e3eb:	mov    rax,QWORD PTR [r14+0x20]
  40e3ef:	mov    ecx,DWORD PTR [r14+0x2c]
  40e3f3:	add    QWORD PTR [r14+0x20],rcx
  40e3f7:	add    DWORD PTR [r14+0x28],0x1
  40e3fc:	jmp    40e400 <__swc_fn_0a4ed24b_000050_5e919db9+0x140>
  40e3fe:	xor    eax,eax
  40e400:	mov    rsi,rax
  40e403:	test   rsi,rsi
  40e406:	je     40e421 <__swc_fn_0a4ed24b_000050_5e919db9+0x161>
  40e408:	mov    QWORD PTR [r13+0x0],r14
  40e40c:	mov    rax,rsi
  40e40f:	add    rsp,0x1f8
  40e416:	pop    r15
  40e418:	pop    r14
  40e41a:	pop    r13
  40e41c:	pop    r12
  40e41e:	pop    rdi
  40e41f:	pop    rsi
  40e420:	ret
  40e421:	mov    r14,r15
  40e424:	jmp    40e310 <__swc_fn_0a4ed24b_000050_5e919db9+0x50>
  40e429:	cs nop WORD PTR [rax+rax*1+0x0]
  40e433:	cs nop WORD PTR [rax+rax*1+0x0]
  40e43d:	nop    DWORD PTR [rax]
  40e440:	mov    rcx,rdi
  40e443:	mov    rdx,r12
  40e446:	mov    r8d,esi
  40e449:	call   4079e0 <__swc_fn_0a4ed24b_000045_bb688d37>
  40e44e:	mov    r14,rax
  40e451:	test   rax,rax
  40e454:	jne    40e46a <__swc_fn_0a4ed24b_000050_5e919db9+0x1aa>
  40e456:	xor    eax,eax
  40e458:	add    rsp,0x1f8
  40e45f:	pop    r15
  40e461:	pop    r14
  40e463:	pop    r13
  40e465:	pop    r12
  40e467:	pop    rdi
  40e468:	pop    rsi
  40e469:	ret
  40e46a:	mov    QWORD PTR [r13+0x0],r14
  40e46e:	mov    rax,QWORD PTR [r14]
  40e471:	test   rax,rax
  40e474:	je     40e486 <__swc_fn_0a4ed24b_000050_5e919db9+0x1c6>
  40e476:	mov    rcx,QWORD PTR [rax]
  40e479:	mov    QWORD PTR [r14],rcx
  40e47c:	add    DWORD PTR [r14+0x28],0x1
  40e481:	mov    r15,rax
  40e484:	jmp    40e4a6 <__swc_fn_0a4ed24b_000050_5e919db9+0x1e6>
  40e486:	mov    rax,QWORD PTR [r14+0x18]
  40e48a:	cmp    QWORD PTR [r14+0x20],rax
  40e48e:	jae    40e4a3 <__swc_fn_0a4ed24b_000050_5e919db9+0x1e3>
  40e490:	mov    r15,QWORD PTR [r14+0x20]
  40e494:	mov    eax,DWORD PTR [r14+0x2c]
  40e498:	add    QWORD PTR [r14+0x20],rax
  40e49c:	add    DWORD PTR [r14+0x28],0x1
  40e4a1:	jmp    40e4a6 <__swc_fn_0a4ed24b_000050_5e919db9+0x1e6>
  40e4a3:	xor    r15d,r15d
  40e4a6:	test   r15,r15
  40e4a9:	jne    40e4ee <__swc_fn_0a4ed24b_000050_5e919db9+0x22e>
  40e4ab:	mov    rcx,r14
  40e4ae:	call   407320 <__swc_fn_0a4ed24b_000006_7b253ae1>
  40e4b3:	test   al,al
  40e4b5:	je     40e4ee <__swc_fn_0a4ed24b_000050_5e919db9+0x22e>
  40e4b7:	mov    rax,QWORD PTR [r14]
  40e4ba:	test   rax,rax
  40e4bd:	je     40e4cc <__swc_fn_0a4ed24b_000050_5e919db9+0x20c>
  40e4bf:	mov    rcx,QWORD PTR [rax]
  40e4c2:	mov    QWORD PTR [r14],rcx
  40e4c5:	add    DWORD PTR [r14+0x28],0x1
  40e4ca:	jmp    40e4eb <__swc_fn_0a4ed24b_000050_5e919db9+0x22b>
  40e4cc:	mov    rax,QWORD PTR [r14+0x18]
  40e4d0:	cmp    QWORD PTR [r14+0x20],rax
  40e4d4:	jae    40e4e9 <__swc_fn_0a4ed24b_000050_5e919db9+0x229>
  40e4d6:	mov    rax,QWORD PTR [r14+0x20]
  40e4da:	mov    ecx,DWORD PTR [r14+0x2c]
  40e4de:	add    QWORD PTR [r14+0x20],rcx
  40e4e2:	add    DWORD PTR [r14+0x28],0x1
  40e4e7:	jmp    40e4eb <__swc_fn_0a4ed24b_000050_5e919db9+0x22b>
  40e4e9:	xor    eax,eax
  40e4eb:	mov    r15,rax
  40e4ee:	test   r15,r15
  40e4f1:	je     40e440 <__swc_fn_0a4ed24b_000050_5e919db9+0x180>
  40e4f7:	mov    rax,r15
  40e4fa:	add    rsp,0x1f8
  40e501:	pop    r15
  40e503:	pop    r14
  40e505:	pop    r13
  40e507:	pop    r12
  40e509:	pop    rdi
  40e50a:	pop    rsi
  40e50b:	ret
  40e50c:	add    BYTE PTR [rax],al
	...

000000000040e510 <__swc_fn_0a4ed24b_000053_9aa81fa7>:
  40e510:	push   rsi
  40e511:	push   rdi
  40e512:	push   r12
  40e514:	mov    rsi,rdx
  40e517:	mov    rax,rdx
  40e51a:	shr    rax,0xc
  40e51e:	movabs rdx,0x9e3779b97f4a7c15
  40e528:	imul   rax,rdx
  40e52c:	shr    rax,0x20
  40e530:	lea    rax,[rax*8+0x0]
  40e538:	shr    rax,0x20
  40e53c:	lea    rax,[rax*8+0x0]
  40e544:	lea    rax,[rcx+rax*8+0x40]
  40e549:	xor    edx,edx
  40e54b:	test   dl,dl
  40e54d:	lea    rdi,[rcx+0x8]
  40e551:	cmove  rdi,rax
  40e555:	xor    edx,edx
  40e557:	test   dl,dl
  40e559:	lea    r12,[rcx+0x30]
  40e55d:	lea    rax,[rax+0x8]
  40e561:	cmove  r12,rax
  40e565:	mov    rcx,rdi
  40e568:	call   4098a0 <__swc_fn_0a4ed24b_000135_db32cc57>
  40e56d:	mov    QWORD PTR [rsi+0x30],0x0
  40e575:	mov    rax,QWORD PTR [r12]
  40e579:	mov    QWORD PTR [rsi+0x38],rax
  40e57d:	test   rax,rax
  40e580:	je     40e58a <__swc_fn_0a4ed24b_000053_9aa81fa7+0x7a>
  40e582:	mov    rax,QWORD PTR [rsi+0x38]
  40e586:	mov    QWORD PTR [rax+0x30],rsi
  40e58a:	mov    QWORD PTR [r12],rsi
  40e58e:	mov    rcx,rdi
  40e591:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  40e596:	pop    r12
  40e598:	pop    rdi
  40e599:	pop    rsi
  40e59a:	ret
  40e59b:	add    BYTE PTR [rax],al
  40e59d:	add    BYTE PTR [rax],al
	...

000000000040e5a0 <__swc_fn_0a4ed24b_000056_87dc216f>:
  40e5a0:	lea    rax,[rdx+rdx*4]
  40e5a4:	lea    rax,[rcx+rax*8+0x268]
  40e5ac:	mov    rdx,QWORD PTR [rax+0x10]
  40e5b0:	sub    QWORD PTR [rcx+0x2a68],rdx
  40e5b7:	sub    QWORD PTR [rcx+0x2a70],0x1
  40e5bf:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40e5c6:	lea    rdx,[rdx+rdx*4]
  40e5ca:	lea    rdx,[rcx+rdx*8+0x268]
  40e5d2:	vmovups xmm0,XMMWORD PTR [rdx]
  40e5d6:	vmovups XMMWORD PTR [rax],xmm0
  40e5da:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40e5df:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e5e4:	mov    rcx,QWORD PTR [rdx+0x20]
  40e5e8:	mov    QWORD PTR [rax+0x20],rcx
  40e5ec:	ret
  40e5ed:	add    BYTE PTR [rax],al
	...

000000000040e5f0 <__swc_fn_0a4ed24b_000059_ee6a254c>:
  40e5f0:	push   rsi
  40e5f1:	push   rdi
  40e5f2:	push   r12
  40e5f4:	push   r13
  40e5f6:	sub    rsp,0x8
  40e5fa:	mov    rsi,r8
  40e5fd:	mov    rdi,rcx
  40e600:	mov    r12,rdx
  40e603:	xor    r13d,r13d
  40e606:	cs nop WORD PTR [rax+rax*1+0x0]
  40e610:	mov    eax,DWORD PTR [r12+0x730]
  40e618:	cmp    r13d,eax
  40e61b:	jae    40e681 <__swc_fn_0a4ed24b_000059_ee6a254c+0x91>
  40e61d:	lea    rax,[r13+r13*4+0x0]
  40e622:	lea    rax,[r12+rax*8+0x738]
  40e62a:	mov    rdx,QWORD PTR [rax]
  40e62d:	mov    r8,QWORD PTR [rax+0x8]
  40e631:	mov    r9,QWORD PTR [rax+0x10]
  40e635:	cmp    QWORD PTR [rax+0x20],rsi
  40e639:	jb     40e640 <__swc_fn_0a4ed24b_000059_ee6a254c+0x50>
  40e63b:	inc    r13d
  40e63e:	jmp    40e610 <__swc_fn_0a4ed24b_000059_ee6a254c+0x20>
  40e640:	sub    DWORD PTR [r12+0x730],0x1
  40e649:	mov    ecx,DWORD PTR [r12+0x730]
  40e651:	lea    rcx,[rcx+rcx*4]
  40e655:	lea    rcx,[r12+rcx*8+0x738]
  40e65d:	vmovups xmm0,XMMWORD PTR [rcx]
  40e661:	vmovups XMMWORD PTR [rax],xmm0
  40e665:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40e66a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e66f:	mov    rcx,QWORD PTR [rcx+0x20]
  40e673:	mov    QWORD PTR [rax+0x20],rcx
  40e677:	mov    rcx,rdi
  40e67a:	call   407750 <__swc_fn_0a4ed24b_000039_9ae4348f>
  40e67f:	jmp    40e610 <__swc_fn_0a4ed24b_000059_ee6a254c+0x20>
  40e681:	add    rsp,0x8
  40e685:	pop    r13
  40e687:	pop    r12
  40e689:	pop    rdi
  40e68a:	pop    rsi
  40e68b:	ret
  40e68c:	add    BYTE PTR [rax],al
	...

000000000040e690 <__swc_fn_0a4ed24b_000062_0a65f1d5>:
  40e690:	push   rsi
  40e691:	push   rdi
  40e692:	push   r12
  40e694:	push   r13
  40e696:	push   r14
  40e698:	mov    rsi,rcx
  40e69b:	mov    rdi,rdx
  40e69e:	mov    r12,QWORD PTR [rdi]
  40e6a1:	mov    r13,QWORD PTR [rdi+0x18]
  40e6a5:	mov    rax,r12
  40e6a8:	add    rax,QWORD PTR [rdi+0x8]
  40e6ac:	sub    rax,r13
  40e6af:	cmp    r8,rax
  40e6b2:	jbe    40e6bd <__swc_fn_0a4ed24b_000062_0a65f1d5+0x2d>
  40e6b4:	pop    r14
  40e6b6:	pop    r13
  40e6b8:	pop    r12
  40e6ba:	pop    rdi
  40e6bb:	pop    rsi
  40e6bc:	ret
  40e6bd:	lea    rax,[r13+r8*1+0x0]
  40e6c2:	sub    rax,r12
  40e6c5:	mov    ecx,0x1000
  40e6ca:	test   ecx,ecx
  40e6cc:	mov    edx,0x8
  40e6d1:	cmove  ecx,edx
  40e6d4:	dec    rcx
  40e6d7:	mov    rdx,0xffffffffffffffff
  40e6de:	sub    rdx,rcx
  40e6e1:	cmp    rax,rdx
  40e6e4:	jbe    40e6eb <__swc_fn_0a4ed24b_000062_0a65f1d5+0x5b>
  40e6e6:	xor    r14d,r14d
  40e6e9:	jmp    40e6f6 <__swc_fn_0a4ed24b_000062_0a65f1d5+0x66>
  40e6eb:	add    rax,rcx
  40e6ee:	andn   rax,rcx,rax
  40e6f3:	mov    r14,rax
  40e6f6:	mov    rax,QWORD PTR [rdi+0x10]
  40e6fa:	cmp    r14,rax
  40e6fd:	ja     40e708 <__swc_fn_0a4ed24b_000062_0a65f1d5+0x78>
  40e6ff:	pop    r14
  40e701:	pop    r13
  40e703:	pop    r12
  40e705:	pop    rdi
  40e706:	pop    rsi
  40e707:	ret
  40e708:	mov    rax,r12
  40e70b:	add    rax,QWORD PTR [rdi+0x10]
  40e70f:	mov    rdx,r14
  40e712:	sub    rdx,QWORD PTR [rdi+0x10]
  40e716:	mov    rcx,rax
  40e719:	call   4072a0 <__swc_fn_0a4ed24b_000003_81215399>
  40e71e:	test   al,al
  40e720:	jne    40e72b <__swc_fn_0a4ed24b_000062_0a65f1d5+0x9b>
  40e722:	pop    r14
  40e724:	pop    r13
  40e726:	pop    r12
  40e728:	pop    rdi
  40e729:	pop    rsi
  40e72a:	ret
  40e72b:	add    r12,r14
  40e72e:	sub    r12,r13
  40e731:	mov    rcx,r12
  40e734:	sub    rcx,QWORD PTR [rdi+0x28]
  40e738:	mov    rdx,QWORD PTR [rsi+0x250]
  40e73f:	nop
  40e740:	lea    r8,[rdx+rcx*1]
  40e744:	mov    rax,rdx
  40e747:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40e750:	cmp    rax,rdx
  40e753:	je     40e75a <__swc_fn_0a4ed24b_000062_0a65f1d5+0xca>
  40e755:	mov    rdx,rax
  40e758:	jmp    40e740 <__swc_fn_0a4ed24b_000062_0a65f1d5+0xb0>
  40e75a:	mov    QWORD PTR [rdi+0x10],r14
  40e75e:	mov    QWORD PTR [rdi+0x28],r12
  40e762:	pop    r14
  40e764:	pop    r13
  40e766:	pop    r12
  40e768:	pop    rdi
  40e769:	pop    rsi
  40e76a:	ret
  40e76b:	add    BYTE PTR [rax],al
  40e76d:	add    BYTE PTR [rax],al
	...

000000000040e770 <__swc_fn_0a4ed24b_000065_0b20477c>:
  40e770:	push   rbx
  40e771:	push   rsi
  40e772:	push   rdi
  40e773:	push   r12
  40e775:	push   r13
  40e777:	sub    rsp,0xe0
  40e77e:	mov    rbx,rdx
  40e781:	mov    rsi,rcx
  40e784:	cmp    DWORD PTR [rbx+0x58],0x0
  40e788:	je     40e7ac <__swc_fn_0a4ed24b_000065_0b20477c+0x3c>
  40e78a:	mov    eax,DWORD PTR [rbx+0x58]
  40e78d:	sub    eax,0x1
  40e790:	test   DWORD PTR [rbx+0x58],eax
  40e793:	je     40e7ac <__swc_fn_0a4ed24b_000065_0b20477c+0x3c>
  40e795:	mov    QWORD PTR [rbx+0x40],0x0
  40e79d:	add    rsp,0xe0
  40e7a4:	pop    r13
  40e7a6:	pop    r12
  40e7a8:	pop    rdi
  40e7a9:	pop    rsi
  40e7aa:	pop    rbx
  40e7ab:	ret
  40e7ac:	mov    rax,QWORD PTR [rbx+0x40]
  40e7b0:	test   rax,rax
  40e7b3:	jne    40e7cf <__swc_fn_0a4ed24b_000065_0b20477c+0x5f>
  40e7b5:	mov    rcx,rsi
  40e7b8:	mov    rdx,rbx
  40e7bb:	call   40bad0 <__swc_fn_0a4ed24b_000064_20100e91>
  40e7c0:	add    rsp,0xe0
  40e7c7:	pop    r13
  40e7c9:	pop    r12
  40e7cb:	pop    rdi
  40e7cc:	pop    rsi
  40e7cd:	pop    rbx
  40e7ce:	ret
  40e7cf:	cmp    QWORD PTR [rbx+0x48],0x0
  40e7d4:	jne    40e7f0 <__swc_fn_0a4ed24b_000065_0b20477c+0x80>
  40e7d6:	mov    rcx,rsi
  40e7d9:	mov    rdx,rbx
  40e7dc:	call   407f90 <__swc_fn_0a4ed24b_000066_918d3875>
  40e7e1:	add    rsp,0xe0
  40e7e8:	pop    r13
  40e7ea:	pop    r12
  40e7ec:	pop    rdi
  40e7ed:	pop    rsi
  40e7ee:	pop    rbx
  40e7ef:	ret
  40e7f0:	mov    rdi,QWORD PTR [rbx+0x40]
  40e7f4:	lea    rax,[rip+0x15875]        # 424070 <__swc_bss_base_0a4ed24b+0x30>
  40e7fb:	mov    rcx,rdi
  40e7fe:	sub    rcx,QWORD PTR [rax+0x8]
  40e802:	mov    rax,QWORD PTR [rip+0x15877]        # 424080 <__swc_bss_base_0a4ed24b+0x40>
  40e809:	cmp    rcx,rax
  40e80c:	jae    40e838 <__swc_fn_0a4ed24b_000065_0b20477c+0xc8>
  40e80e:	mov    rax,rdi
  40e811:	and    rax,0xffffffffffc00000
  40e818:	mov    rcx,rdi
  40e81b:	shr    rcx,0x10
  40e81f:	and    ecx,0x3f
  40e822:	mov    edx,DWORD PTR [rax+0x28]
  40e825:	shrx   ecx,ecx,edx
  40e82a:	shl    rcx,0x4
  40e82e:	lea    r12,[rax+rcx*8+0x80]
  40e836:	jmp    40e843 <__swc_fn_0a4ed24b_000065_0b20477c+0xd3>
  40e838:	mov    rcx,rdi
  40e83b:	call   40ab50 <__swc_fn_0a4ed24b_000022_53fc00d2>
  40e840:	mov    r12,rax
  40e843:	test   r12,r12
  40e846:	je     40e855 <__swc_fn_0a4ed24b_000065_0b20477c+0xe5>
  40e848:	mov    eax,DWORD PTR [r12+0x2c]
  40e84d:	mov    r9d,eax
  40e850:	mov    r13,rax
  40e853:	jmp    40e8d4 <__swc_fn_0a4ed24b_000065_0b20477c+0x164>
  40e855:	mov    rcx,rsi
  40e858:	mov    rdx,rdi
  40e85b:	call   40b160 <__swc_fn_0a4ed24b_000052_92b016ae>
  40e860:	mov    rcx,QWORD PTR [rax+0x28]
  40e864:	mov    r9,rcx
  40e867:	mov    rdx,QWORD PTR [rax+0x20]
  40e86b:	mov    r13,rdx
  40e86e:	cmp    QWORD PTR [rbx+0x48],rcx
  40e872:	jbe    40e8ab <__swc_fn_0a4ed24b_000065_0b20477c+0x13b>
  40e874:	mov    ecx,DWORD PTR [rax+0x48]
  40e877:	cmp    DWORD PTR [rbx+0x58],ecx
  40e87a:	ja     40e8ab <__swc_fn_0a4ed24b_000065_0b20477c+0x13b>
  40e87c:	mov    rcx,rsi
  40e87f:	mov    rdx,rax
  40e882:	mov    r8,QWORD PTR [rbx+0x48]
  40e886:	mov    QWORD PTR [rsp+0xc8],r9
  40e88e:	mov    QWORD PTR [rsp+0xd0],rax
  40e896:	call   40e690 <__swc_fn_0a4ed24b_000062_0a65f1d5>
  40e89b:	mov    r9,QWORD PTR [rsp+0xc8]
  40e8a3:	mov    rax,QWORD PTR [rsp+0xd0]
  40e8ab:	mov    rcx,QWORD PTR [rax+0x28]
  40e8af:	cmp    QWORD PTR [rbx+0x48],rcx
  40e8b3:	ja     40e8d4 <__swc_fn_0a4ed24b_000065_0b20477c+0x164>
  40e8b5:	mov    ecx,DWORD PTR [rax+0x48]
  40e8b8:	cmp    DWORD PTR [rbx+0x58],ecx
  40e8bb:	ja     40e8d4 <__swc_fn_0a4ed24b_000065_0b20477c+0x164>
  40e8bd:	mov    rcx,QWORD PTR [rbx+0x48]
  40e8c1:	mov    QWORD PTR [rax+0x20],rcx
  40e8c5:	add    rsp,0xe0
  40e8cc:	pop    r13
  40e8ce:	pop    r12
  40e8d0:	pop    rdi
  40e8d1:	pop    rsi
  40e8d2:	pop    rbx
  40e8d3:	ret
  40e8d4:	test   r12,r12
  40e8d7:	je     40e909 <__swc_fn_0a4ed24b_000065_0b20477c+0x199>
  40e8d9:	cmp    QWORD PTR [rbx+0x48],r9
  40e8dd:	ja     40e909 <__swc_fn_0a4ed24b_000065_0b20477c+0x199>
  40e8df:	cmp    DWORD PTR [rbx+0x58],0x40
  40e8e3:	ja     40e909 <__swc_fn_0a4ed24b_000065_0b20477c+0x199>
  40e8e5:	cmp    DWORD PTR [rbx+0x58],0x0
  40e8e9:	je     40e8f6 <__swc_fn_0a4ed24b_000065_0b20477c+0x186>
  40e8eb:	mov    ecx,DWORD PTR [rbx+0x58]
  40e8ee:	dec    rcx
  40e8f1:	test   rdi,rcx
  40e8f4:	jne    40e909 <__swc_fn_0a4ed24b_000065_0b20477c+0x199>
  40e8f6:	mov    QWORD PTR [rbx+0x40],rdi
  40e8fa:	add    rsp,0xe0
  40e901:	pop    r13
  40e903:	pop    r12
  40e905:	pop    rdi
  40e906:	pop    rsi
  40e907:	pop    rbx
  40e908:	ret
  40e909:	vmovups xmm0,XMMWORD PTR [rbx]
  40e90d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e913:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40e918:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e91e:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40e923:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e929:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40e92e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40e934:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40e939:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40e93f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40e944:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40e94a:	mov    QWORD PTR [rsp+0x48],0x0
  40e953:	mov    rcx,rsi
  40e956:	lea    rdx,[rsp+0x8]
  40e95b:	call   40bad0 <__swc_fn_0a4ed24b_000064_20100e91>
  40e960:	mov    rax,QWORD PTR [rsp+0x48]
  40e965:	test   rax,rax
  40e968:	jne    40e981 <__swc_fn_0a4ed24b_000065_0b20477c+0x211>
  40e96a:	mov    QWORD PTR [rbx+0x40],0x0
  40e972:	add    rsp,0xe0
  40e979:	pop    r13
  40e97b:	pop    r12
  40e97d:	pop    rdi
  40e97e:	pop    rsi
  40e97f:	pop    rbx
  40e980:	ret
  40e981:	mov    rax,QWORD PTR [rbx+0x48]
  40e985:	cmp    r13,rax
  40e988:	cmovbe rax,r13
  40e98c:	mov    rcx,QWORD PTR [rsp+0x48]
  40e991:	mov    rdx,rdi
  40e994:	mov    r8,rax
  40e997:	call   4090e0 <__swc_fn_0a4ed24b_000105_83487ba1>
  40e99c:	vmovups xmm0,XMMWORD PTR [rbx]
  40e9a0:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40e9a6:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40e9ab:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40e9b1:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40e9b6:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40e9bf:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40e9c4:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40e9cd:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40e9d2:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40e9db:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40e9e0:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40e9e9:	mov    QWORD PTR [rsp+0xa8],rdi
  40e9f1:	mov    rcx,rsi
  40e9f4:	lea    rdx,[rsp+0x68]
  40e9f9:	call   407f90 <__swc_fn_0a4ed24b_000066_918d3875>
  40e9fe:	mov    rax,QWORD PTR [rsp+0x48]
  40ea03:	mov    QWORD PTR [rbx+0x40],rax
  40ea07:	add    rsp,0xe0
  40ea0e:	pop    r13
  40ea10:	pop    r12
  40ea12:	pop    rdi
  40ea13:	pop    rsi
  40ea14:	pop    rbx
  40ea15:	ret
	...

000000000040ea20 <__swc_fn_0a4ed24b_000068_f501e74b>:
  40ea20:	push   r12
  40ea22:	push   rdi
  40ea23:	push   rsi
  40ea24:	push   r13
  40ea26:	push   r14
  40ea28:	sub    rsp,0x190
  40ea2f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40ea38:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40ea41:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40ea4a:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40ea53:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40ea5c:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40ea65:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40ea6e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40ea77:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40ea80:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40ea89:	mov    r12,rcx
  40ea8c:	lea    rax,[rip+0x1356d]        # 422000 <__swc_data_base_0a4ed24b>
  40ea93:	mov    rax,QWORD PTR [rax]
  40ea96:	cmp    rax,0xffffffffffffffff
  40ea9a:	je     40eaa9 <__swc_fn_0a4ed24b_000068_f501e74b+0x89>
  40ea9c:	mov    eax,eax
  40ea9e:	mov    edi,eax
  40eaa0:	xor    eax,eax
  40eaa2:	call   407000 <pthread_getspecific@plt>
  40eaa7:	jmp    40eaab <__swc_fn_0a4ed24b_000068_f501e74b+0x8b>
  40eaa9:	xor    eax,eax
  40eaab:	test   rax,rax
  40eaae:	jne    40eabd <__swc_fn_0a4ed24b_000068_f501e74b+0x9d>
  40eab0:	call   40ac20 <__swc_fn_0a4ed24b_000031_3c3e930e>
  40eab5:	mov    rcx,rax
  40eab8:	call   4101e0 <__swc_fn_0a4ed24b_000128_8d8a7dd2>
  40eabd:	test   rax,rax
  40eac0:	je     40eae6 <__swc_fn_0a4ed24b_000068_f501e74b+0xc6>
  40eac2:	cmp    QWORD PTR [rax],r12
  40eac5:	jne    40eae6 <__swc_fn_0a4ed24b_000068_f501e74b+0xc6>
  40eac7:	xor    ecx,ecx
  40eac9:	mov    QWORD PTR [rsp+0xc8],rax
  40ead1:	call   407720 <__swc_fn_0a4ed24b_000033_d15eb4ea>
  40ead6:	mov    rdx,QWORD PTR [rsp+0xc8]
  40eade:	mov    rcx,r12
  40eae1:	call   407840 <__swc_fn_0a4ed24b_000042_0573444d>
  40eae6:	lea    rsi,[r12+0x10]
  40eaeb:	mov    rcx,rsi
  40eaee:	call   4098a0 <__swc_fn_0a4ed24b_000135_db32cc57>
  40eaf3:	mov    rdi,QWORD PTR [r12+0x20]
  40eaf8:	test   rdi,rdi
  40eafb:	je     40eb3e <__swc_fn_0a4ed24b_000068_f501e74b+0x11e>
  40eafd:	nop    DWORD PTR [rax]
  40eb00:	mov    rcx,r12
  40eb03:	mov    rdx,rdi
  40eb06:	call   40ade0 <__swc_fn_0a4ed24b_000043_47ff6d9b>
  40eb0b:	mov    rcx,r12
  40eb0e:	mov    rdx,rdi
  40eb11:	mov    r8,0xffffffffffffffff
  40eb18:	call   40e5f0 <__swc_fn_0a4ed24b_000059_ee6a254c>
  40eb1d:	mov    rcx,r12
  40eb20:	mov    rdx,rdi
  40eb23:	mov    r8d,0x9b8
  40eb29:	mov    r9d,0x9b8
  40eb2f:	call   407750 <__swc_fn_0a4ed24b_000039_9ae4348f>
  40eb34:	mov    rdi,QWORD PTR [r12+0x20]
  40eb39:	test   rdi,rdi
  40eb3c:	jne    40eb00 <__swc_fn_0a4ed24b_000068_f501e74b+0xe0>
  40eb3e:	xor    eax,eax
  40eb40:	xchg   QWORD PTR [r12+0x2a80],rax
  40eb48:	test   rax,rax
  40eb4b:	je     40eb71 <__swc_fn_0a4ed24b_000068_f501e74b+0x151>
  40eb4d:	cs nop WORD PTR [rax+rax*1+0x0]
  40eb57:	nop    WORD PTR [rax+rax*1+0x0]
  40eb60:	mov    rcx,rax
  40eb63:	mov    rax,QWORD PTR [rax+0x78]
  40eb67:	xor    edx,edx
  40eb69:	xchg   DWORD PTR [rcx+0x70],edx
  40eb6c:	test   rax,rax
  40eb6f:	jne    40eb60 <__swc_fn_0a4ed24b_000068_f501e74b+0x140>
  40eb71:	mov    rax,QWORD PTR [r12+0x18]
  40eb76:	mov    rdi,rax
  40eb79:	test   rdi,rdi
  40eb7c:	je     40ec11 <__swc_fn_0a4ed24b_000068_f501e74b+0x1f1>
  40eb82:	cs nop WORD PTR [rax+rax*1+0x0]
  40eb8c:	nop    DWORD PTR [rax+0x0]
  40eb90:	mov    rax,QWORD PTR [rdi+0x10]
  40eb94:	mov    r8d,DWORD PTR [rdi+0x2c]
  40eb98:	xor    r9d,r9d
  40eb9b:	test   r8,r8
  40eb9e:	jbe    40ebfd <__swc_fn_0a4ed24b_000068_f501e74b+0x1dd>
  40eba0:	mov    ecx,r9d
  40eba3:	shl    rcx,0x4
  40eba7:	lea    rdx,[rdi+rcx*8+0x80]
  40ebaf:	cmp    BYTE PTR [rdx+0x3b],0x0
  40ebb3:	je     40ebf4 <__swc_fn_0a4ed24b_000068_f501e74b+0x1d4>
  40ebb5:	mov    DWORD PTR [rdx+0x28],0x0
  40ebbc:	mov    rcx,rdi
  40ebbf:	mov    QWORD PTR [rsp+0xd0],rax
  40ebc7:	mov    QWORD PTR [rsp+0xd8],r8
  40ebcf:	mov    QWORD PTR [rsp+0xe0],r9
  40ebd7:	call   40dd20 <__swc_fn_0a4ed24b_000014_be17798c>
  40ebdc:	mov    rax,QWORD PTR [rsp+0xd0]
  40ebe4:	mov    r8,QWORD PTR [rsp+0xd8]
  40ebec:	mov    r9,QWORD PTR [rsp+0xe0]
  40ebf4:	add    r9,0x1
  40ebf8:	cmp    r9,r8
  40ebfb:	jb     40eba0 <__swc_fn_0a4ed24b_000068_f501e74b+0x180>
  40ebfd:	mov    rcx,rdi
  40ec00:	mov    rdi,rax
  40ec03:	call   407630 <__swc_fn_0a4ed24b_000021_9cf87641>
  40ec08:	test   rdi,rdi
  40ec0b:	jne    40eb90 <__swc_fn_0a4ed24b_000068_f501e74b+0x170>
  40ec11:	mov    QWORD PTR [r12+0x18],0x0
  40ec1a:	mov    QWORD PTR [r12+0x28],0x0
  40ec23:	mov    rcx,rsi
  40ec26:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  40ec2b:	mov    esi,0x8
  40ec30:	xor    edi,edi
  40ec32:	test   rsi,rsi
  40ec35:	je     40ec92 <__swc_fn_0a4ed24b_000068_f501e74b+0x272>
  40ec3b:	nop    DWORD PTR [rax+rax*1+0x0]
  40ec40:	lea    r13,[rdi*8+0x0]
  40ec48:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40ec4d:	test   r14,r14
  40ec50:	je     40ec88 <__swc_fn_0a4ed24b_000068_f501e74b+0x268>
  40ec52:	cs nop WORD PTR [rax+rax*1+0x0]
  40ec5c:	nop    DWORD PTR [rax+0x0]
  40ec60:	mov    rcx,r12
  40ec63:	mov    rdx,r14
  40ec66:	call   407df0 <__swc_fn_0a4ed24b_000054_e8e85c01>
  40ec6b:	mov    rcx,r12
  40ec6e:	mov    rdx,QWORD PTR [r14]
  40ec71:	mov    r8,QWORD PTR [r14+0x8]
  40ec75:	mov    r9,QWORD PTR [r14+0x10]
  40ec79:	call   407750 <__swc_fn_0a4ed24b_000039_9ae4348f>
  40ec7e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40ec83:	test   r14,r14
  40ec86:	jne    40ec60 <__swc_fn_0a4ed24b_000068_f501e74b+0x240>
  40ec88:	add    rdi,0x1
  40ec8c:	sub    rsi,0x1
  40ec90:	jne    40ec40 <__swc_fn_0a4ed24b_000068_f501e74b+0x220>
  40ec92:	mov    rcx,r12
  40ec95:	call   407ec0 <__swc_fn_0a4ed24b_000060_6818d0d1>
  40ec9a:	lea    rcx,[r12+0x250]
  40eca2:	mov    rdx,QWORD PTR [rcx]
  40eca5:	mov    r8,QWORD PTR [r12+0x250]
  40ecad:	nop    DWORD PTR [rax]
  40ecb0:	mov    r9,r8
  40ecb3:	sub    r9,rdx
  40ecb6:	mov    rax,r8
  40ecb9:	lock cmpxchg QWORD PTR [rcx],r9
  40ecbe:	cmp    rax,r8
  40ecc1:	je     40ecc8 <__swc_fn_0a4ed24b_000068_f501e74b+0x2a8>
  40ecc3:	mov    r8,rax
  40ecc6:	jmp    40ecb0 <__swc_fn_0a4ed24b_000068_f501e74b+0x290>
  40ecc8:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40ecd1:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40ecda:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40ece3:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40ecec:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40ecf5:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40ecfe:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40ed07:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40ed10:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40ed19:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40ed22:	add    rsp,0x190
  40ed29:	pop    r14
  40ed2b:	pop    r13
  40ed2d:	pop    rsi
  40ed2e:	pop    rdi
  40ed2f:	pop    r12
  40ed31:	ret
	...

000000000040ed40 <__swc_fn_0a4ed24b_000071_1e1e3bf8>:
  40ed40:	sub    rsp,0x8
  40ed44:	mov    QWORD PTR [rdx+0x40],0x0
  40ed4c:	call   40bad0 <__swc_fn_0a4ed24b_000064_20100e91>
  40ed51:	add    rsp,0x8
  40ed55:	ret
	...

000000000040ed60 <__swc_fn_0a4ed24b_000074_30b8696a>:
  40ed60:	sub    rsp,0x8
  40ed64:	call   407f90 <__swc_fn_0a4ed24b_000066_918d3875>
  40ed69:	add    rsp,0x8
  40ed6d:	ret
	...

000000000040ed70 <__swc_fn_0a4ed24b_000077_948ef603>:
  40ed70:	push   rbx
  40ed71:	push   rsi
  40ed72:	push   rdi
  40ed73:	push   r12
  40ed75:	push   r13
  40ed77:	push   r14
  40ed79:	push   r15
  40ed7b:	sub    rsp,0x20
  40ed7f:	mov    rbx,r11
  40ed82:	mov    rsi,rcx
  40ed85:	mov    rdi,rdx
  40ed88:	mov    r12,r8
  40ed8b:	mov    r13,r9
  40ed8e:	mov    r14,r10
  40ed91:	mov    rcx,QWORD PTR [rip+0x17fa8]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40ed98:	test   rcx,rcx
  40ed9b:	jne    40edad <__swc_fn_0a4ed24b_000077_948ef603+0x3d>
  40ed9d:	call   40a1a0 <__swc_fn_0a4ed24b_000165_56054fe7>
  40eda2:	lea    rcx,[rax+0x1]
  40eda6:	mov    QWORD PTR [rip+0x17f93],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40edad:	dec    rcx
  40edb0:	call   411c60 <__swc_fn_0a4ed24b_000167_39c041ad>
  40edb5:	mov    r15,rax
  40edb8:	lea    r11,[rip+0x15481]        # 424240 <__swc_bss_base_0a4ed24b+0x200>
  40edbf:	mov    rcx,r11
  40edc2:	call   407740 <__swc_fn_0a4ed24b_000036_290a131c>
  40edc7:	test   al,al
  40edc9:	jne    40edda <__swc_fn_0a4ed24b_000077_948ef603+0x6a>
  40edcb:	mov    rcx,r11
  40edce:	call   40ac80 <__swc_fn_0a4ed24b_000034_cf5ba7bd>
  40edd3:	lea    r11,[rip+0x15466]        # 424240 <__swc_bss_base_0a4ed24b+0x200>
  40edda:	mov    rcx,r11
  40eddd:	mov    rdx,rsi
  40ede0:	mov    r8,rdi
  40ede3:	mov    r9,r12
  40ede6:	mov    r10,r13
  40ede9:	mov    rsi,r11
  40edec:	mov    r11,r14
  40edef:	call   40e090 <__swc_fn_0a4ed24b_000035_ab2e8c35>
  40edf4:	test   bl,bl
  40edf6:	je     40ee1d <__swc_fn_0a4ed24b_000077_948ef603+0xad>
  40edf8:	mov    QWORD PTR [rsp+0x8],rsi
  40edfd:	lea    rax,[rip+0x434c]        # 413150 <__swc_rdata_base_0a4ed24b+0x40>
  40ee04:	mov    QWORD PTR [rsp+0x10],rax
  40ee09:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ee0f:	vmovups XMMWORD PTR [r15],xmm0
  40ee14:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40ee1d:	mov    rax,rsi
  40ee20:	add    rsp,0x20
  40ee24:	pop    r15
  40ee26:	pop    r14
  40ee28:	pop    r13
  40ee2a:	pop    r12
  40ee2c:	pop    rdi
  40ee2d:	pop    rsi
  40ee2e:	pop    rbx
  40ee2f:	ret

000000000040ee30 <__swc_fn_0a4ed24b_000080_207908fe>:
  40ee30:	sub    rsp,0x8
  40ee34:	mov    rax,rcx
  40ee37:	test   rcx,rcx
  40ee3a:	jne    40ee41 <__swc_fn_0a4ed24b_000080_207908fe+0x11>
  40ee3c:	add    rsp,0x8
  40ee40:	ret
  40ee41:	lea    rcx,[rax-0x10]
  40ee45:	mov    rax,QWORD PTR [rax-0x10]
  40ee49:	mov    rdx,rax
  40ee4c:	call   40fe90 <__swc_fn_0a4ed24b_000113_4e83a03a>
  40ee51:	add    rsp,0x8
  40ee55:	ret
	...

000000000040ee60 <__swc_fn_0a4ed24b_000083_f2d93dad>:
  40ee60:	sub    rsp,0x8
  40ee64:	xor    r11d,r11d
  40ee67:	call   408250 <__swc_fn_0a4ed24b_000084_5ed30bd6>
  40ee6c:	add    rsp,0x8
  40ee70:	ret
	...

000000000040ee80 <__swc_fn_0a4ed24b_000086_d9243de4>:
  40ee80:	push   rsi
  40ee81:	push   rdi
  40ee82:	push   r12
  40ee84:	push   r13
  40ee86:	push   r14
  40ee88:	push   r15
  40ee8a:	sub    rsp,0x68
  40ee8e:	mov    rsi,r9
  40ee91:	mov    rdi,rcx
  40ee94:	mov    r12,rdx
  40ee97:	mov    r13,r8
  40ee9a:	cmp    r8,r9
  40ee9d:	jne    40eec5 <__swc_fn_0a4ed24b_000086_d9243de4+0x45>
  40ee9f:	mov    rcx,rdi
  40eea2:	mov    rdx,r12
  40eea5:	xor    r8d,r8d
  40eea8:	call   4085a0 <__swc_fn_0a4ed24b_000090_14cf59b2>
  40eead:	test   al,al
  40eeaf:	je     40eec5 <__swc_fn_0a4ed24b_000086_d9243de4+0x45>
  40eeb1:	mov    eax,0x1
  40eeb6:	add    rsp,0x68
  40eeba:	pop    r15
  40eebc:	pop    r14
  40eebe:	pop    r13
  40eec0:	pop    r12
  40eec2:	pop    rdi
  40eec3:	pop    rsi
  40eec4:	ret
  40eec5:	cmp    BYTE PTR [r12+0x2c],0xe
  40eecb:	je     40eede <__swc_fn_0a4ed24b_000086_d9243de4+0x5e>
  40eecd:	xor    eax,eax
  40eecf:	add    rsp,0x68
  40eed3:	pop    r15
  40eed5:	pop    r14
  40eed7:	pop    r13
  40eed9:	pop    r12
  40eedb:	pop    rdi
  40eedc:	pop    rsi
  40eedd:	ret
  40eede:	mov    r14,QWORD PTR [r12+0x98]
  40eee6:	mov    rax,QWORD PTR [r12+0xa0]
  40eeee:	mov    r12,rax
  40eef1:	xor    r15d,r15d
  40eef4:	test   r12,r12
  40eef7:	je     40ef5f <__swc_fn_0a4ed24b_000086_d9243de4+0xdf>
  40eef9:	nop    DWORD PTR [rax+0x0]
  40ef00:	mov    QWORD PTR [rsp+0x58],r12
  40ef05:	lea    r12,[r15*8+0x0]
  40ef0d:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40ef12:	mov    rcx,rax
  40ef15:	call   40c260 <__swc_fn_0a4ed24b_000082_ff7d1455>
  40ef1a:	cmp    BYTE PTR [rax+0x2c],0xe
  40ef1e:	jne    40ef50 <__swc_fn_0a4ed24b_000086_d9243de4+0xd0>
  40ef20:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40ef25:	lea    r8,[r13+rcx*1+0x0]
  40ef2a:	mov    rcx,rdi
  40ef2d:	mov    rdx,rax
  40ef30:	mov    r9,rsi
  40ef33:	call   40ee80 <__swc_fn_0a4ed24b_000086_d9243de4>
  40ef38:	test   al,al
  40ef3a:	je     40ef50 <__swc_fn_0a4ed24b_000086_d9243de4+0xd0>
  40ef3c:	mov    eax,0x1
  40ef41:	add    rsp,0x68
  40ef45:	pop    r15
  40ef47:	pop    r14
  40ef49:	pop    r13
  40ef4b:	pop    r12
  40ef4d:	pop    rdi
  40ef4e:	pop    rsi
  40ef4f:	ret
  40ef50:	add    r15,0x1
  40ef54:	mov    r12,QWORD PTR [rsp+0x58]
  40ef59:	sub    r12,0x1
  40ef5d:	jne    40ef00 <__swc_fn_0a4ed24b_000086_d9243de4+0x80>
  40ef5f:	xor    eax,eax
  40ef61:	add    rsp,0x68
  40ef65:	pop    r15
  40ef67:	pop    r14
  40ef69:	pop    r13
  40ef6b:	pop    r12
  40ef6d:	pop    rdi
  40ef6e:	pop    rsi
  40ef6f:	ret

000000000040ef70 <__swc_fn_0a4ed24b_000089_3c530920>:
  40ef70:	push   rbp
  40ef71:	push   rbx
  40ef72:	push   rsi
  40ef73:	push   rdi
  40ef74:	push   r12
  40ef76:	push   r13
  40ef78:	push   r14
  40ef7a:	push   r15
  40ef7c:	sub    rsp,0x38
  40ef80:	mov    rbp,rsp
  40ef83:	mov    rbx,r11
  40ef86:	mov    rsi,rdx
  40ef89:	mov    rdi,r8
  40ef8c:	mov    r12,r9
  40ef8f:	mov    QWORD PTR [rsp+0x18],r9
  40ef94:	mov    r13,r10
  40ef97:	movzx  r14d,BYTE PTR [rbp+0x80]
  40ef9f:	movzx  r15d,BYTE PTR [rbp+0x88]
  40efa7:	test   r11,r11
  40efaa:	je     40efb0 <__swc_fn_0a4ed24b_000089_3c530920+0x40>
  40efac:	xor    eax,eax
  40efae:	mov    BYTE PTR [rbx],al
  40efb0:	test   r12,r12
  40efb3:	je     40efbe <__swc_fn_0a4ed24b_000089_3c530920+0x4e>
  40efb5:	mov    QWORD PTR [r12+0x8],0x0
  40efbe:	test   rcx,rcx
  40efc1:	je     40efc8 <__swc_fn_0a4ed24b_000089_3c530920+0x58>
  40efc3:	test   rsi,rsi
  40efc6:	jne    40efdb <__swc_fn_0a4ed24b_000089_3c530920+0x6b>
  40efc8:	xor    eax,eax
  40efca:	add    rsp,0x38
  40efce:	pop    r15
  40efd0:	pop    r14
  40efd2:	pop    r13
  40efd4:	pop    r12
  40efd6:	pop    rdi
  40efd7:	pop    rsi
  40efd8:	pop    rbx
  40efd9:	pop    rbp
  40efda:	ret
  40efdb:	call   40c260 <__swc_fn_0a4ed24b_000082_ff7d1455>
  40efe0:	mov    r12,rax
  40efe3:	mov    al,r15b
  40efe6:	test   r15b,r15b
  40efe9:	jne    40eff9 <__swc_fn_0a4ed24b_000089_3c530920+0x89>
  40efeb:	mov    eax,DWORD PTR [r12+0x28]
  40eff0:	and    eax,0x10000
  40eff6:	setne  al
  40eff9:	lea    r15,[rsp+0x8]
  40effe:	mov    QWORD PTR [rsp+0x20],r15
  40f003:	rex mov BYTE PTR [rsp+0x8],al
  40f008:	test   DWORD PTR [rsi+0x28],0x400000
  40f00f:	je     40f047 <__swc_fn_0a4ed24b_000089_3c530920+0xd7>
  40f011:	test   rsi,rsi
  40f014:	je     40f034 <__swc_fn_0a4ed24b_000089_3c530920+0xc4>
  40f016:	mov    rax,QWORD PTR [rsi+0x38]
  40f01a:	cmp    QWORD PTR [rax+0x10],rsi
  40f01e:	jne    40f034 <__swc_fn_0a4ed24b_000089_3c530920+0xc4>
  40f020:	rex mov al,BYTE PTR [rsp+0x8]
  40f025:	test   al,al
  40f027:	sete   al
  40f02a:	test   r14b,r14b
  40f02d:	sete   cl
  40f030:	test   al,cl
  40f032:	je     40f047 <__swc_fn_0a4ed24b_000089_3c530920+0xd7>
  40f034:	xor    eax,eax
  40f036:	add    rsp,0x38
  40f03a:	pop    r15
  40f03c:	pop    r14
  40f03e:	pop    r13
  40f040:	pop    r12
  40f042:	pop    rdi
  40f043:	pop    rsi
  40f044:	pop    rbx
  40f045:	pop    rbp
  40f046:	ret
  40f047:	mov    r15,r12
  40f04a:	test   r14b,r14b
  40f04d:	jne    40f064 <__swc_fn_0a4ed24b_000089_3c530920+0xf4>
  40f04f:	cmp    BYTE PTR [r12+0x2c],0x6
  40f055:	jne    40f064 <__swc_fn_0a4ed24b_000089_3c530920+0xf4>
  40f057:	mov    rcx,QWORD PTR [r12+0x40]
  40f05c:	call   40c260 <__swc_fn_0a4ed24b_000082_ff7d1455>
  40f061:	mov    r15,rax
  40f064:	test   r14b,r14b
  40f067:	je     40f06d <__swc_fn_0a4ed24b_000089_3c530920+0xfd>
  40f069:	mov    r15,QWORD PTR [r15+0x30]
  40f06d:	mov    rcx,rsi
  40f070:	call   40c260 <__swc_fn_0a4ed24b_000082_ff7d1455>
  40f075:	mov    rsi,rax
  40f078:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f07d:	je     40f0b4 <__swc_fn_0a4ed24b_000089_3c530920+0x144>
  40f07f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f084:	je     40f0b4 <__swc_fn_0a4ed24b_000089_3c530920+0x144>
  40f086:	mov    eax,DWORD PTR [rsi+0x28]
  40f089:	and    eax,0x10000
  40f08f:	je     40f0b4 <__swc_fn_0a4ed24b_000089_3c530920+0x144>
  40f091:	rex mov al,BYTE PTR [rsp+0x8]
  40f096:	test   al,al
  40f098:	jne    40f0ad <__swc_fn_0a4ed24b_000089_3c530920+0x13d>
  40f09a:	xor    eax,eax
  40f09c:	add    rsp,0x38
  40f0a0:	pop    r15
  40f0a2:	pop    r14
  40f0a4:	pop    r13
  40f0a6:	pop    r12
  40f0a8:	pop    rdi
  40f0a9:	pop    rsi
  40f0aa:	pop    rbx
  40f0ab:	pop    rbp
  40f0ac:	ret
  40f0ad:	mov    rax,QWORD PTR [rsi+0x30]
  40f0b1:	mov    rsi,rax
  40f0b4:	mov    r14b,r13b
  40f0b7:	test   rbx,rbx
  40f0ba:	je     40f0f0 <__swc_fn_0a4ed24b_000089_3c530920+0x180>
  40f0bc:	cmp    BYTE PTR [r12+0x2c],0x6
  40f0c2:	jne    40f0f0 <__swc_fn_0a4ed24b_000089_3c530920+0x180>
  40f0c4:	lea    rdx,[rip+0x40b5]        # 413180 <__swc_rdata_base_0a4ed24b+0x70>
  40f0cb:	mov    rcx,rsi
  40f0ce:	xor    r8d,r8d
  40f0d1:	call   4085a0 <__swc_fn_0a4ed24b_000090_14cf59b2>
  40f0d6:	test   al,al
  40f0d8:	je     40f0f0 <__swc_fn_0a4ed24b_000089_3c530920+0x180>
  40f0da:	mov    BYTE PTR [rbx],0x1
  40f0dd:	xor    eax,eax
  40f0df:	add    rsp,0x38
  40f0e3:	pop    r15
  40f0e5:	pop    r14
  40f0e7:	pop    r13
  40f0e9:	pop    r12
  40f0eb:	pop    rdi
  40f0ec:	pop    rsi
  40f0ed:	pop    rbx
  40f0ee:	pop    rbp
  40f0ef:	ret
  40f0f0:	test   rdi,rdi
  40f0f3:	jne    40f10d <__swc_fn_0a4ed24b_000089_3c530920+0x19d>
  40f0f5:	test   r13b,r13b
  40f0f8:	jne    40f10d <__swc_fn_0a4ed24b_000089_3c530920+0x19d>
  40f0fa:	xor    eax,eax
  40f0fc:	add    rsp,0x38
  40f100:	pop    r15
  40f102:	pop    r14
  40f104:	pop    r13
  40f106:	pop    r12
  40f108:	pop    rdi
  40f109:	pop    rsi
  40f10a:	pop    rbx
  40f10b:	pop    rbp
  40f10c:	ret
  40f10d:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f112:	jne    40f1c8 <__swc_fn_0a4ed24b_000089_3c530920+0x258>
  40f118:	mov    rcx,r15
  40f11b:	mov    rdx,rsi
  40f11e:	xor    r8d,r8d
  40f121:	call   4085a0 <__swc_fn_0a4ed24b_000090_14cf59b2>
  40f126:	test   al,al
  40f128:	jne    40f1c8 <__swc_fn_0a4ed24b_000089_3c530920+0x258>
  40f12e:	test   DWORD PTR [rsi+0x28],0x10000
  40f135:	je     40f153 <__swc_fn_0a4ed24b_000089_3c530920+0x1e3>
  40f137:	rex mov al,BYTE PTR [rsp+0x8]
  40f13c:	test   al,al
  40f13e:	jne    40f153 <__swc_fn_0a4ed24b_000089_3c530920+0x1e3>
  40f140:	xor    eax,eax
  40f142:	add    rsp,0x38
  40f146:	pop    r15
  40f148:	pop    r14
  40f14a:	pop    r13
  40f14c:	pop    r12
  40f14e:	pop    rdi
  40f14f:	pop    rsi
  40f150:	pop    rbx
  40f151:	pop    rbp
  40f152:	ret
  40f153:	test   rdi,rdi
  40f156:	jne    40f16b <__swc_fn_0a4ed24b_000089_3c530920+0x1fb>
  40f158:	xor    eax,eax
  40f15a:	add    rsp,0x38
  40f15e:	pop    r15
  40f160:	pop    r14
  40f162:	pop    r13
  40f164:	pop    r12
  40f166:	pop    rdi
  40f167:	pop    rsi
  40f168:	pop    rbx
  40f169:	pop    rbp
  40f16a:	ret
  40f16b:	mov    rcx,QWORD PTR [rsi+0x40]
  40f16f:	call   40c260 <__swc_fn_0a4ed24b_000082_ff7d1455>
  40f174:	mov    rsi,rax
  40f177:	mov    rax,QWORD PTR [rdi]
  40f17a:	mov    rdi,rax
  40f17d:	test   rax,rax
  40f180:	jne    40f1c3 <__swc_fn_0a4ed24b_000089_3c530920+0x253>
  40f182:	test   rbx,rbx
  40f185:	je     40f1c3 <__swc_fn_0a4ed24b_000089_3c530920+0x253>
  40f187:	mov    rcx,r15
  40f18a:	mov    rdx,rsi
  40f18d:	xor    r8d,r8d
  40f190:	call   4085a0 <__swc_fn_0a4ed24b_000090_14cf59b2>
  40f195:	mov    rcx,rax
  40f198:	test   al,al
  40f19a:	jne    40f1bc <__swc_fn_0a4ed24b_000089_3c530920+0x24c>
  40f19c:	mov    rcx,r15
  40f19f:	mov    rdx,rsi
  40f1a2:	call   40c2a0 <__swc_fn_0a4ed24b_000085_e24ecd12>
  40f1a7:	mov    rcx,rax
  40f1aa:	test   al,al
  40f1ac:	jne    40f1bc <__swc_fn_0a4ed24b_000089_3c530920+0x24c>
  40f1ae:	mov    rcx,rsi
  40f1b1:	mov    rdx,r15
  40f1b4:	call   40c2a0 <__swc_fn_0a4ed24b_000085_e24ecd12>
  40f1b9:	mov    rcx,rax
  40f1bc:	test   cl,cl
  40f1be:	setne  al
  40f1c1:	mov    BYTE PTR [rbx],al
  40f1c3:	xor    eax,eax
  40f1c5:	mov    r14b,al
  40f1c8:	test   rdi,rdi
  40f1cb:	jne    40f1e5 <__swc_fn_0a4ed24b_000089_3c530920+0x275>
  40f1cd:	test   r14b,r14b
  40f1d0:	jne    40f1e5 <__swc_fn_0a4ed24b_000089_3c530920+0x275>
  40f1d2:	xor    eax,eax
  40f1d4:	add    rsp,0x38
  40f1d8:	pop    r15
  40f1da:	pop    r14
  40f1dc:	pop    r13
  40f1de:	pop    r12
  40f1e0:	pop    rdi
  40f1e1:	pop    rsi
  40f1e2:	pop    rbx
  40f1e3:	pop    rbp
  40f1e4:	ret
  40f1e5:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f1ea:	je     40f1f6 <__swc_fn_0a4ed24b_000089_3c530920+0x286>
  40f1ec:	mov    r12,QWORD PTR [rsp+0x18]
  40f1f1:	jmp    40f27e <__swc_fn_0a4ed24b_000089_3c530920+0x30e>
  40f1f6:	mov    r12,QWORD PTR [rsp+0x18]
  40f1fb:	test   r12,r12
  40f1fe:	jne    40f212 <__swc_fn_0a4ed24b_000089_3c530920+0x2a2>
  40f200:	mov    rcx,r15
  40f203:	mov    rdx,rsi
  40f206:	xor    r8d,r8d
  40f209:	call   4085a0 <__swc_fn_0a4ed24b_000090_14cf59b2>
  40f20e:	test   al,al
  40f210:	jne    40f27e <__swc_fn_0a4ed24b_000089_3c530920+0x30e>
  40f212:	test   DWORD PTR [rsi+0x28],0x10000
  40f219:	je     40f237 <__swc_fn_0a4ed24b_000089_3c530920+0x2c7>
  40f21b:	rex mov al,BYTE PTR [rsp+0x8]
  40f220:	test   al,al
  40f222:	jne    40f237 <__swc_fn_0a4ed24b_000089_3c530920+0x2c7>
  40f224:	xor    eax,eax
  40f226:	add    rsp,0x38
  40f22a:	pop    r15
  40f22c:	pop    r14
  40f22e:	pop    r13
  40f230:	pop    r12
  40f232:	pop    rdi
  40f233:	pop    rsi
  40f234:	pop    rbx
  40f235:	pop    rbp
  40f236:	ret
  40f237:	test   rdi,rdi
  40f23a:	jne    40f24f <__swc_fn_0a4ed24b_000089_3c530920+0x2df>
  40f23c:	xor    eax,eax
  40f23e:	add    rsp,0x38
  40f242:	pop    r15
  40f244:	pop    r14
  40f246:	pop    r13
  40f248:	pop    r12
  40f24a:	pop    rdi
  40f24b:	pop    rsi
  40f24c:	pop    rbx
  40f24d:	pop    rbp
  40f24e:	ret
  40f24f:	cmp    QWORD PTR [rdi+0x8],0x0
  40f254:	jne    40f269 <__swc_fn_0a4ed24b_000089_3c530920+0x2f9>
  40f256:	xor    eax,eax
  40f258:	add    rsp,0x38
  40f25c:	pop    r15
  40f25e:	pop    r14
  40f260:	pop    r13
  40f262:	pop    r12
  40f264:	pop    rdi
  40f265:	pop    rsi
  40f266:	pop    rbx
  40f267:	pop    rbp
  40f268:	ret
  40f269:	mov    rax,QWORD PTR [rdi+0x8]
  40f26d:	mov    rax,QWORD PTR [rax]
  40f270:	mov    rsi,rax
  40f273:	mov    rdi,QWORD PTR [rdi]
  40f276:	mov    eax,0x1
  40f27b:	mov    r14b,al
  40f27e:	test   rdi,rdi
  40f281:	mov    rbx,QWORD PTR [rsp+0x20]
  40f286:	jne    40f2d0 <__swc_fn_0a4ed24b_000089_3c530920+0x360>
  40f288:	test   r14b,r14b
  40f28b:	je     40f2bd <__swc_fn_0a4ed24b_000089_3c530920+0x34d>
  40f28d:	test   r12,r12
  40f290:	je     40f2bd <__swc_fn_0a4ed24b_000089_3c530920+0x34d>
  40f292:	mov    rcx,r15
  40f295:	mov    rdx,rsi
  40f298:	xor    r8d,r8d
  40f29b:	mov    r9,r12
  40f29e:	mov    rbx,QWORD PTR [rsp+0x20]
  40f2a3:	movzx  r10d,BYTE PTR [rbx]
  40f2a7:	call   40ee60 <__swc_fn_0a4ed24b_000083_f2d93dad>
  40f2ac:	add    rsp,0x38
  40f2b0:	pop    r15
  40f2b2:	pop    r14
  40f2b4:	pop    r13
  40f2b6:	pop    r12
  40f2b8:	pop    rdi
  40f2b9:	pop    rsi
  40f2ba:	pop    rbx
  40f2bb:	pop    rbp
  40f2bc:	ret
  40f2bd:	xor    eax,eax
  40f2bf:	add    rsp,0x38
  40f2c3:	pop    r15
  40f2c5:	pop    r14
  40f2c7:	pop    r13
  40f2c9:	pop    r12
  40f2cb:	pop    rdi
  40f2cc:	pop    rsi
  40f2cd:	pop    rbx
  40f2ce:	pop    rbp
  40f2cf:	ret
  40f2d0:	mov    r13,rsi
  40f2d3:	mov    QWORD PTR [rsp+0x28],rdi
  40f2d8:	cmp    BYTE PTR [r15+0x2c],0xe
  40f2dd:	sete   al
  40f2e0:	mov    r14b,al
  40f2e3:	jne    40f2f7 <__swc_fn_0a4ed24b_000089_3c530920+0x387>
  40f2e5:	mov    rcx,rsi
  40f2e8:	mov    rdx,r15
  40f2eb:	call   40c2a0 <__swc_fn_0a4ed24b_000085_e24ecd12>
  40f2f0:	mov    r14b,al
  40f2f3:	test   al,al
  40f2f5:	jne    40f32c <__swc_fn_0a4ed24b_000089_3c530920+0x3bc>
  40f2f7:	cmp    BYTE PTR [r15+0x2c],0x12
  40f2fc:	je     40f32c <__swc_fn_0a4ed24b_000089_3c530920+0x3bc>
  40f2fe:	mov    rcx,r15
  40f301:	mov    rdx,rsi
  40f304:	mov    r8,rdi
  40f307:	mov    r9,r12
  40f30a:	mov    rax,rbx
  40f30d:	movzx  r10d,BYTE PTR [rax]
  40f311:	call   40ee60 <__swc_fn_0a4ed24b_000083_f2d93dad>
  40f316:	test   rax,rax
  40f319:	je     40f32c <__swc_fn_0a4ed24b_000089_3c530920+0x3bc>
  40f31b:	add    rsp,0x38
  40f31f:	pop    r15
  40f321:	pop    r14
  40f323:	pop    r13
  40f325:	pop    r12
  40f327:	pop    rdi
  40f328:	pop    rsi
  40f329:	pop    rbx
  40f32a:	pop    rbp
  40f32b:	ret
  40f32c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40f331:	jne    40f350 <__swc_fn_0a4ed24b_000089_3c530920+0x3e0>
  40f333:	mov    rax,QWORD PTR [rsi+0xd8]
  40f33a:	test   rax,rax
  40f33d:	je     40f350 <__swc_fn_0a4ed24b_000089_3c530920+0x3e0>
  40f33f:	add    rdi,QWORD PTR [rax+0x8]
  40f343:	mov    rax,QWORD PTR [rdi]
  40f346:	sub    rdi,QWORD PTR [rax+0x8]
  40f34a:	mov    rax,QWORD PTR [rax]
  40f34d:	mov    rsi,rax
  40f350:	test   r14b,r14b
  40f353:	je     40f37f <__swc_fn_0a4ed24b_000089_3c530920+0x40f>
  40f355:	mov    rcx,r15
  40f358:	mov    rdx,rsi
  40f35b:	mov    r8,rdi
  40f35e:	mov    r9,r13
  40f361:	mov    r14,QWORD PTR [rsp+0x28]
  40f366:	mov    r10,r14
  40f369:	call   408480 <__swc_fn_0a4ed24b_000087_693f118e>
  40f36e:	add    rsp,0x38
  40f372:	pop    r15
  40f374:	pop    r14
  40f376:	pop    r13
  40f378:	pop    r12
  40f37a:	pop    rdi
  40f37b:	pop    rsi
  40f37c:	pop    rbx
  40f37d:	pop    rbp
  40f37e:	ret
  40f37f:	mov    rcx,r15
  40f382:	mov    rdx,rsi
  40f385:	mov    r8,rdi
  40f388:	mov    r9,r12
  40f38b:	movzx  r10d,BYTE PTR [rbx]
  40f38f:	call   40ee60 <__swc_fn_0a4ed24b_000083_f2d93dad>
  40f394:	add    rsp,0x38
  40f398:	pop    r15
  40f39a:	pop    r14
  40f39c:	pop    r13
  40f39e:	pop    r12
  40f3a0:	pop    rdi
  40f3a1:	pop    rsi
  40f3a2:	pop    rbx
  40f3a3:	pop    rbp
  40f3a4:	ret
	...

000000000040f3b0 <__swc_fn_0a4ed24b_000092_809deff5>:
  40f3b0:	push   rbx
  40f3b1:	push   rsi
  40f3b2:	sub    rsp,0x18
  40f3b6:	mov    rbx,rcx
  40f3b9:	mov    rcx,QWORD PTR [rip+0x17980]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40f3c0:	test   rcx,rcx
  40f3c3:	jne    40f3d5 <__swc_fn_0a4ed24b_000092_809deff5+0x25>
  40f3c5:	call   40a1a0 <__swc_fn_0a4ed24b_000165_56054fe7>
  40f3ca:	lea    rcx,[rax+0x1]
  40f3ce:	mov    QWORD PTR [rip+0x1796b],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  40f3d5:	dec    rcx
  40f3d8:	call   411c60 <__swc_fn_0a4ed24b_000167_39c041ad>
  40f3dd:	mov    rsi,rax
  40f3e0:	mov    rax,QWORD PTR [rsi+0x8]
  40f3e4:	test   rax,rax
  40f3e7:	jne    40f437 <__swc_fn_0a4ed24b_000092_809deff5+0x87>
  40f3e9:	call   40c390 <__swc_fn_0a4ed24b_000091_f21926ed>
  40f3ee:	test   al,al
  40f3f0:	jne    40f437 <__swc_fn_0a4ed24b_000092_809deff5+0x87>
  40f3f2:	lea    rdx,[rip+0x14e47]        # 424240 <__swc_bss_base_0a4ed24b+0x200>
  40f3f9:	mov    rcx,rdx
  40f3fc:	call   407740 <__swc_fn_0a4ed24b_000036_290a131c>
  40f401:	test   al,al
  40f403:	jne    40f414 <__swc_fn_0a4ed24b_000092_809deff5+0x64>
  40f405:	mov    rcx,rdx
  40f408:	call   40ac80 <__swc_fn_0a4ed24b_000034_cf5ba7bd>
  40f40d:	lea    rdx,[rip+0x14e2c]        # 424240 <__swc_bss_base_0a4ed24b+0x200>
  40f414:	mov    QWORD PTR [rsp+0x8],rdx
  40f419:	lea    rax,[rip+0x3d30]        # 413150 <__swc_rdata_base_0a4ed24b+0x40>
  40f420:	mov    QWORD PTR [rsp+0x10],rax
  40f425:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f42b:	vmovups XMMWORD PTR [rsi],xmm0
  40f42f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40f437:	vmovups xmm0,XMMWORD PTR [rsi]
  40f43b:	vmovups XMMWORD PTR [rbx],xmm0
  40f43f:	mov    rax,rbx
  40f442:	add    rsp,0x18
  40f446:	pop    rsi
  40f447:	pop    rbx
  40f448:	ret
  40f449:	add    BYTE PTR [rax],al
  40f44b:	add    BYTE PTR [rax],al
  40f44d:	add    BYTE PTR [rax],al
	...

000000000040f450 <__swc_fn_0a4ed24b_000095_8cc4b392>:
  40f450:	sub    rsp,0x8
  40f454:	call   409340 <__swc_fn_0a4ed24b_000117_5aba1420>
  40f459:	add    rsp,0x8
  40f45d:	ret
	...

000000000040f460 <__swc_fn_0a4ed24b_000098_f82a1ed3>:
  40f460:	push   rbx
  40f461:	push   rsi
  40f462:	sub    rsp,0x28
  40f466:	mov    rbx,rcx
  40f469:	xor    esi,esi
  40f46b:	jmp    40f480 <__swc_fn_0a4ed24b_000098_f82a1ed3+0x20>
  40f46d:	nop    DWORD PTR [rax]
  40f470:	mov    QWORD PTR [rbx+0x28],rsi
  40f474:	mov    rsi,rbx
  40f477:	mov    rbx,rax
  40f47a:	nop    WORD PTR [rax+rax*1+0x0]
  40f480:	test   rbx,rbx
  40f483:	je     40f4e3 <__swc_fn_0a4ed24b_000098_f82a1ed3+0x83>
  40f485:	mov    rcx,rbx
  40f488:	mov    edx,0x1
  40f48d:	call   408200 <__swc_fn_0a4ed24b_000078_140918ec>
  40f492:	cmp    rax,0x1
  40f496:	jne    40f4e3 <__swc_fn_0a4ed24b_000098_f82a1ed3+0x83>
  40f498:	mov    r10,QWORD PTR [rbx+0x18]
  40f49c:	mov    rcx,r10
  40f49f:	mov    edx,0x1
  40f4a4:	call   408200 <__swc_fn_0a4ed24b_000078_140918ec>
  40f4a9:	cmp    rax,0x1
  40f4ad:	jne    40f4bc <__swc_fn_0a4ed24b_000098_f82a1ed3+0x5c>
  40f4af:	mov    rcx,r10
  40f4b2:	call   40c530 <__swc_fn_0a4ed24b_000097_96d6739a>
  40f4b7:	test   rax,rax
  40f4ba:	jne    40f470 <__swc_fn_0a4ed24b_000098_f82a1ed3+0x10>
  40f4bc:	mov    rax,QWORD PTR [rbx+0x20]
  40f4c0:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40f4c5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f4cb:	lea    rcx,[rsp+0x8]
  40f4d0:	mov    rdx,rbx
  40f4d3:	mov    r8d,0x30
  40f4d9:	mov    rbx,rax
  40f4dc:	call   408960 <__swc_fn_0a4ed24b_000096_a4baaa40>
  40f4e1:	jmp    40f480 <__swc_fn_0a4ed24b_000098_f82a1ed3+0x20>
  40f4e3:	test   rsi,rsi
  40f4e6:	jne    40f4ef <__swc_fn_0a4ed24b_000098_f82a1ed3+0x8f>
  40f4e8:	add    rsp,0x28
  40f4ec:	pop    rsi
  40f4ed:	pop    rbx
  40f4ee:	ret
  40f4ef:	mov    rax,rsi
  40f4f2:	mov    rsi,QWORD PTR [rsi+0x28]
  40f4f6:	mov    rbx,QWORD PTR [rax+0x20]
  40f4fa:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40f4ff:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f505:	lea    rcx,[rsp+0x18]
  40f50a:	mov    rdx,rax
  40f50d:	mov    r8d,0x30
  40f513:	call   408960 <__swc_fn_0a4ed24b_000096_a4baaa40>
  40f518:	jmp    40f480 <__swc_fn_0a4ed24b_000098_f82a1ed3+0x20>
  40f51d:	add    BYTE PTR [rax],al
	...

000000000040f520 <__swc_fn_0a4ed24b_000101_afcb7774>:
  40f520:	push   rbx
  40f521:	push   rsi
  40f522:	push   rdi
  40f523:	push   r12
  40f525:	push   r13
  40f527:	sub    rsp,0x20
  40f52b:	mov    rbx,rcx
  40f52e:	lea    rsi,[rcx+0x6f8]
  40f535:	mov    edi,0x4
  40f53a:	mov    r12,rsi
  40f53d:	test   rdi,rdi
  40f540:	je     40f58a <__swc_fn_0a4ed24b_000101_afcb7774+0x6a>
  40f542:	cs nop WORD PTR [rax+rax*1+0x0]
  40f54c:	nop    DWORD PTR [rax+0x0]
  40f550:	mov    rcx,QWORD PTR [r12+0x10]
  40f555:	mov    QWORD PTR [r12+0x10],0x0
  40f55e:	vxorps xmm0,xmm0,xmm0
  40f562:	vmovups XMMWORD PTR [r12],xmm0
  40f568:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40f56f:	mov    DWORD PTR [r12+0x20],0x0
  40f578:	call   4089b0 <__swc_fn_0a4ed24b_000099_5232b57d>
  40f57d:	add    r12,0x90
  40f584:	sub    rdi,0x1
  40f588:	jne    40f550 <__swc_fn_0a4ed24b_000101_afcb7774+0x30>
  40f58a:	mov    rax,QWORD PTR [rbx+0x938]
  40f591:	mov    rdi,rax
  40f594:	test   rdi,rdi
  40f597:	je     40f5f1 <__swc_fn_0a4ed24b_000101_afcb7774+0xd1>
  40f599:	nop    DWORD PTR [rax+0x0]
  40f5a0:	mov    r12d,0x10
  40f5a6:	lea    r13,[rdi+0x18]
  40f5aa:	test   r12,r12
  40f5ad:	je     40f5e6 <__swc_fn_0a4ed24b_000101_afcb7774+0xc6>
  40f5af:	nop
  40f5b0:	mov    rcx,QWORD PTR [r13+0x10]
  40f5b4:	mov    QWORD PTR [r13+0x10],0x0
  40f5bc:	vxorps xmm0,xmm0,xmm0
  40f5c0:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40f5c6:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40f5cc:	mov    DWORD PTR [r13+0x20],0x0
  40f5d4:	call   4089b0 <__swc_fn_0a4ed24b_000099_5232b57d>
  40f5d9:	add    r13,0x90
  40f5e0:	sub    r12,0x1
  40f5e4:	jne    40f5b0 <__swc_fn_0a4ed24b_000101_afcb7774+0x90>
  40f5e6:	mov    rax,QWORD PTR [rdi]
  40f5e9:	mov    rdi,rax
  40f5ec:	test   rax,rax
  40f5ef:	jne    40f5a0 <__swc_fn_0a4ed24b_000101_afcb7774+0x80>
  40f5f1:	vxorps xmm0,xmm0,xmm0
  40f5f5:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40f5fd:	mov    DWORD PTR [rbx+0x9b0],0x0
  40f607:	mov    DWORD PTR [rbx+0x9a8],0x0
  40f611:	mov    edi,0x4
  40f616:	mov    r12,rsi
  40f619:	lea    rsi,[rsi+0x38]
  40f61d:	test   rdi,rdi
  40f620:	je     40f64c <__swc_fn_0a4ed24b_000101_afcb7774+0x12c>
  40f622:	cs nop WORD PTR [rax+rax*1+0x0]
  40f62c:	nop    DWORD PTR [rax+0x0]
  40f630:	mov    rcx,rsi
  40f633:	call   40d3b0 <__swc_fn_0a4ed24b_000157_3495a3ca>
  40f638:	add    rsi,0x90
  40f63f:	add    r12,0x90
  40f646:	sub    rdi,0x1
  40f64a:	jne    40f630 <__swc_fn_0a4ed24b_000101_afcb7774+0x110>
  40f64c:	mov    rax,QWORD PTR [rbx+0x938]
  40f653:	mov    rdi,rax
  40f656:	mov    QWORD PTR [rbx+0x938],0x0
  40f661:	test   rdi,rdi
  40f664:	je     40f6d5 <__swc_fn_0a4ed24b_000101_afcb7774+0x1b5>
  40f66a:	nop    WORD PTR [rax+rax*1+0x0]
  40f670:	mov    esi,0x10
  40f675:	lea    r12,[rdi+0x18]
  40f679:	lea    r13,[rdi+0x50]
  40f67d:	test   rsi,rsi
  40f680:	je     40f6ac <__swc_fn_0a4ed24b_000101_afcb7774+0x18c>
  40f682:	cs nop WORD PTR [rax+rax*1+0x0]
  40f68c:	nop    DWORD PTR [rax+0x0]
  40f690:	mov    rcx,r13
  40f693:	call   40d3b0 <__swc_fn_0a4ed24b_000157_3495a3ca>
  40f698:	add    r13,0x90
  40f69f:	add    r12,0x90
  40f6a6:	sub    rsi,0x1
  40f6aa:	jne    40f690 <__swc_fn_0a4ed24b_000101_afcb7774+0x170>
  40f6ac:	mov    rax,QWORD PTR [rdi]
  40f6af:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40f6b4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f6ba:	lea    rcx,[rsp+0x8]
  40f6bf:	mov    rdx,rdi
  40f6c2:	mov    r8d,0x918
  40f6c8:	mov    rdi,rax
  40f6cb:	call   408960 <__swc_fn_0a4ed24b_000096_a4baaa40>
  40f6d0:	test   rdi,rdi
  40f6d3:	jne    40f670 <__swc_fn_0a4ed24b_000101_afcb7774+0x150>
  40f6d5:	lea    rcx,[rbx+0x68]
  40f6d9:	call   40d3b0 <__swc_fn_0a4ed24b_000157_3495a3ca>
  40f6de:	add    rsp,0x20
  40f6e2:	pop    r13
  40f6e4:	pop    r12
  40f6e6:	pop    rdi
  40f6e7:	pop    rsi
  40f6e8:	pop    rbx
  40f6e9:	ret
  40f6ea:	add    BYTE PTR [rax],al
  40f6ec:	add    BYTE PTR [rax],al
	...

000000000040f6f0 <__swc_fn_0a4ed24b_000104_04d1a8be>:
  40f6f0:	xor    eax,eax
  40f6f2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f6fc:	nop    DWORD PTR [rax+0x0]
  40f700:	mov    r9,r8
  40f703:	sub    r9,rax
  40f706:	cmp    r9,0x40
  40f70a:	jb     40f748 <__swc_fn_0a4ed24b_000104_04d1a8be+0x58>
  40f70c:	lea    r9,[rcx+rax*1]
  40f710:	lea    r10,[rdx+rax*1]
  40f714:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40f71a:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40f720:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40f726:	vmovups xmm3,XMMWORD PTR [r10]
  40f72b:	vmovups XMMWORD PTR [r9],xmm3
  40f730:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40f736:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40f73c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40f742:	lea    rax,[rax+0x40]
  40f746:	jmp    40f700 <__swc_fn_0a4ed24b_000104_04d1a8be+0x10>
  40f748:	nop    DWORD PTR [rax+rax*1+0x0]
  40f750:	mov    r9,r8
  40f753:	sub    r9,rax
  40f756:	cmp    r9,0x10
  40f75a:	jb     40f774 <__swc_fn_0a4ed24b_000104_04d1a8be+0x84>
  40f75c:	lea    r9,[rdx+rax*1]
  40f760:	lea    r10,[rcx+rax*1]
  40f764:	vmovups xmm0,XMMWORD PTR [r9]
  40f769:	vmovups XMMWORD PTR [r10],xmm0
  40f76e:	lea    rax,[rax+0x10]
  40f772:	jmp    40f750 <__swc_fn_0a4ed24b_000104_04d1a8be+0x60>
  40f774:	cs nop WORD PTR [rax+rax*1+0x0]
  40f77e:	xchg   ax,ax
  40f780:	mov    r9,r8
  40f783:	sub    r9,rax
  40f786:	cmp    r9,0x8
  40f78a:	jb     40f79d <__swc_fn_0a4ed24b_000104_04d1a8be+0xad>
  40f78c:	lea    r9,[rcx+rax*1]
  40f790:	mov    r10,QWORD PTR [rdx+rax*1]
  40f794:	mov    QWORD PTR [r9],r10
  40f797:	lea    rax,[rax+0x8]
  40f79b:	jmp    40f780 <__swc_fn_0a4ed24b_000104_04d1a8be+0x90>
  40f79d:	cmp    rax,r8
  40f7a0:	jae    40f7c0 <__swc_fn_0a4ed24b_000104_04d1a8be+0xd0>
  40f7a2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f7ac:	nop    DWORD PTR [rax+0x0]
  40f7b0:	mov    r9b,BYTE PTR [rdx+rax*1]
  40f7b4:	mov    BYTE PTR [rcx+rax*1],r9b
  40f7b8:	inc    rax
  40f7bb:	cmp    rax,r8
  40f7be:	jb     40f7b0 <__swc_fn_0a4ed24b_000104_04d1a8be+0xc0>
  40f7c0:	ret
	...

000000000040f7d0 <__swc_fn_0a4ed24b_000107_c8d4a68e>:
  40f7d0:	push   rbx
  40f7d1:	push   r12
  40f7d3:	push   rdi
  40f7d4:	push   rsi
  40f7d5:	push   r13
  40f7d7:	push   r14
  40f7d9:	push   r15
  40f7db:	sub    rsp,0x170
  40f7e2:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40f7eb:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40f7f4:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40f7fd:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40f806:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40f80f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40f818:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40f821:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40f82a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40f833:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40f83c:	mov    ebx,edx
  40f83e:	mov    QWORD PTR [rsp+0xa8],rbx
  40f846:	mov    r12d,ecx
  40f849:	test   edx,edx
  40f84b:	jne    40f862 <__swc_fn_0a4ed24b_000107_c8d4a68e+0x92>
  40f84d:	xor    eax,eax
  40f84f:	add    rsp,0x170
  40f856:	pop    r15
  40f858:	pop    r14
  40f85a:	pop    r13
  40f85c:	pop    rsi
  40f85d:	pop    rdi
  40f85e:	pop    r12
  40f860:	pop    rbx
  40f861:	ret
  40f862:	lea    rdi,[rip+0x3c47]        # 4134b0 <__swc_rdata_base_0a4ed24b+0x3a0>
  40f869:	mov    esi,0x90000
  40f86e:	xor    eax,eax
  40f870:	call   407090 <open@plt>
  40f875:	mov    r13,rax
  40f878:	mov    QWORD PTR [rsp+0xb0],rax
  40f880:	test   eax,eax
  40f882:	jge    40f88b <__swc_fn_0a4ed24b_000107_c8d4a68e+0xbb>
  40f884:	xor    eax,eax
  40f886:	jmp    40fd86 <__swc_fn_0a4ed24b_000107_c8d4a68e+0x5b6>
  40f88b:	nop    DWORD PTR [rax+rax*1+0x0]
  40f890:	movsxd rdi,r13d
  40f893:	mov    esi,0x2
  40f898:	xor    eax,eax
  40f89a:	call   407120 <flock@plt>
  40f89f:	test   eax,eax
  40f8a1:	je     40f8c0 <__swc_fn_0a4ed24b_000107_c8d4a68e+0xf0>
  40f8a3:	xor    eax,eax
  40f8a5:	call   407130 <__errno_location@plt>
  40f8aa:	cmp    DWORD PTR [rax],0x4
  40f8ad:	je     40f890 <__swc_fn_0a4ed24b_000107_c8d4a68e+0xc0>
  40f8af:	movsxd rdi,r13d
  40f8b2:	xor    eax,eax
  40f8b4:	call   4070b0 <close@plt>
  40f8b9:	xor    eax,eax
  40f8bb:	jmp    40fd86 <__swc_fn_0a4ed24b_000107_c8d4a68e+0x5b6>
  40f8c0:	lea    r14,[rsp+0x8]
  40f8c5:	mov    QWORD PTR [rsp+0xb8],r14
  40f8cd:	vxorps xmm0,xmm0,xmm0
  40f8d1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f8d7:	mov    QWORD PTR [rsp+0x18],0x0
  40f8e0:	mov    WORD PTR [rsp+0x20],0x0
  40f8e7:	mov    DWORD PTR [r14],0x67617753
  40f8ee:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40f8f6:	xor    eax,eax
  40f8f8:	call   407010 <getpid@plt>
  40f8fd:	mov    ecx,eax
  40f8ff:	mov    eax,0x1c
  40f904:	shrx   eax,ecx,eax
  40f909:	and    eax,0xf
  40f90c:	mov    rdx,QWORD PTR [rip+0x3bbd]        # 4134d0 <__swc_rdata_base_0a4ed24b+0x3c0>
  40f913:	mov    al,BYTE PTR [rdx+rax*1]
  40f916:	rex mov BYTE PTR [rsp+0x10],al
  40f91b:	mov    eax,0x1c
  40f920:	shrx   eax,r12d,eax
  40f925:	and    eax,0xf
  40f928:	mov    al,BYTE PTR [rdx+rax*1]
  40f92b:	rex mov BYTE PTR [rsp+0x19],al
  40f930:	mov    eax,0x18
  40f935:	shrx   eax,ecx,eax
  40f93a:	and    eax,0xf
  40f93d:	mov    al,BYTE PTR [rdx+rax*1]
  40f940:	rex mov BYTE PTR [rsp+0x11],al
  40f945:	mov    eax,0x18
  40f94a:	shrx   eax,r12d,eax
  40f94f:	and    eax,0xf
  40f952:	mov    al,BYTE PTR [rdx+rax*1]
  40f955:	rex mov BYTE PTR [rsp+0x1a],al
  40f95a:	mov    eax,0x14
  40f95f:	shrx   eax,ecx,eax
  40f964:	and    eax,0xf
  40f967:	mov    al,BYTE PTR [rdx+rax*1]
  40f96a:	rex mov BYTE PTR [rsp+0x12],al
  40f96f:	mov    eax,0x14
  40f974:	shrx   eax,r12d,eax
  40f979:	and    eax,0xf
  40f97c:	mov    al,BYTE PTR [rdx+rax*1]
  40f97f:	rex mov BYTE PTR [rsp+0x1b],al
  40f984:	mov    eax,0x10
  40f989:	shrx   eax,ecx,eax
  40f98e:	and    eax,0xf
  40f991:	mov    al,BYTE PTR [rdx+rax*1]
  40f994:	rex mov BYTE PTR [rsp+0x13],al
  40f999:	mov    eax,0x10
  40f99e:	shrx   eax,r12d,eax
  40f9a3:	and    eax,0xf
  40f9a6:	mov    al,BYTE PTR [rdx+rax*1]
  40f9a9:	rex mov BYTE PTR [rsp+0x1c],al
  40f9ae:	mov    eax,0xc
  40f9b3:	shrx   eax,ecx,eax
  40f9b8:	and    eax,0xf
  40f9bb:	mov    al,BYTE PTR [rdx+rax*1]
  40f9be:	rex mov BYTE PTR [rsp+0x14],al
  40f9c3:	mov    eax,0xc
  40f9c8:	shrx   eax,r12d,eax
  40f9cd:	and    eax,0xf
  40f9d0:	mov    al,BYTE PTR [rdx+rax*1]
  40f9d3:	rex mov BYTE PTR [rsp+0x1d],al
  40f9d8:	mov    eax,0x8
  40f9dd:	shrx   eax,ecx,eax
  40f9e2:	and    eax,0xf
  40f9e5:	mov    al,BYTE PTR [rdx+rax*1]
  40f9e8:	rex mov BYTE PTR [rsp+0x15],al
  40f9ed:	mov    eax,0x8
  40f9f2:	shrx   eax,r12d,eax
  40f9f7:	and    eax,0xf
  40f9fa:	mov    al,BYTE PTR [rdx+rax*1]
  40f9fd:	rex mov BYTE PTR [rsp+0x1e],al
  40fa02:	mov    eax,0x4
  40fa07:	shrx   eax,ecx,eax
  40fa0c:	and    eax,0xf
  40fa0f:	mov    al,BYTE PTR [rdx+rax*1]
  40fa12:	rex mov BYTE PTR [rsp+0x16],al
  40fa17:	mov    eax,0x4
  40fa1c:	shrx   eax,r12d,eax
  40fa21:	and    eax,0xf
  40fa24:	mov    al,BYTE PTR [rdx+rax*1]
  40fa27:	rex mov BYTE PTR [rsp+0x1f],al
  40fa2c:	xor    eax,eax
  40fa2e:	shrx   eax,ecx,eax
  40fa33:	and    eax,0xf
  40fa36:	mov    al,BYTE PTR [rdx+rax*1]
  40fa39:	rex mov BYTE PTR [rsp+0x17],al
  40fa3e:	xor    eax,eax
  40fa40:	shrx   eax,r12d,eax
  40fa45:	and    eax,0xf
  40fa48:	mov    al,BYTE PTR [rdx+rax*1]
  40fa4b:	rex mov BYTE PTR [rsp+0x20],al
  40fa50:	mov    BYTE PTR [r14+0x10],0x2e
  40fa55:	lea    r12,[rsp+0x22]
  40fa5a:	vxorps xmm0,xmm0,xmm0
  40fa5e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40fa64:	mov    DWORD PTR [r12],0x6d656d2f
  40fa6c:	mov    WORD PTR [r12+0x4],0x6466
  40fa74:	mov    BYTE PTR [r12+0x6],0x3a
  40fa7a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40fa80:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40fa86:	mov    rax,QWORD PTR [rsp+0x18]
  40fa8b:	mov    QWORD PTR [rsp+0x39],rax
  40fa90:	rex mov al,BYTE PTR [rsp+0x20]
  40fa95:	rex mov BYTE PTR [rsp+0x41],al
  40fa9a:	mov    DWORD PTR [r12+0x20],0x65642820
  40faa3:	mov    DWORD PTR [r12+0x24],0x6574656c
  40faac:	mov    WORD PTR [r12+0x28],0x2964
  40fab4:	lea    rdi,[rip+0x3a00]        # 4134bb <__swc_rdata_base_0a4ed24b+0x3ab>
  40fabb:	xor    eax,eax
  40fabd:	call   407140 <opendir@plt>
  40fac2:	mov    r15,rax
  40fac5:	test   rax,rax
  40fac8:	jne    40fadb <__swc_fn_0a4ed24b_000107_c8d4a68e+0x30b>
  40faca:	movsxd rdi,r13d
  40facd:	xor    eax,eax
  40facf:	call   4070b0 <close@plt>
  40fad4:	xor    eax,eax
  40fad6:	jmp    40fd86 <__swc_fn_0a4ed24b_000107_c8d4a68e+0x5b6>
  40fadb:	mov    rdi,r15
  40fade:	xor    eax,eax
  40fae0:	call   407150 <dirfd@plt>
  40fae5:	lea    r14,[rsp+0x54]
  40faea:	mov    DWORD PTR [rsp+0x54],eax
  40faee:	lea    rbx,[rsp+0x58]
  40faf3:	cs nop WORD PTR [rax+rax*1+0x0]
  40fafd:	nop    DWORD PTR [rax]
  40fb00:	mov    rdi,r15
  40fb03:	xor    eax,eax
  40fb05:	call   407160 <readdir@plt>
  40fb0a:	test   rax,rax
  40fb0d:	jne    40fb24 <__swc_fn_0a4ed24b_000107_c8d4a68e+0x354>
  40fb0f:	mov    r12,QWORD PTR [rsp+0xa8]
  40fb17:	mov    r13,QWORD PTR [rsp+0xb0]
  40fb1f:	jmp    40fcaa <__swc_fn_0a4ed24b_000107_c8d4a68e+0x4da>
  40fb24:	vxorps xmm0,xmm0,xmm0
  40fb28:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  40fb2e:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  40fb34:	vzeroupper
  40fb37:	lea    r13,[rax+0x13]
  40fb3b:	mov    rax,r14
  40fb3e:	movsxd rdi,DWORD PTR [rax]
  40fb41:	mov    rsi,r13
  40fb44:	mov    rdx,rbx
  40fb47:	mov    ecx,0x40
  40fb4c:	xor    eax,eax
  40fb4e:	call   407170 <readlinkat@plt>
  40fb53:	cmp    rax,0x2a
  40fb57:	jne    40fb00 <__swc_fn_0a4ed24b_000107_c8d4a68e+0x330>
  40fb59:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40fb5f:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40fb65:	vptest xmm0,xmm0
  40fb6a:	jne    40fb9a <__swc_fn_0a4ed24b_000107_c8d4a68e+0x3ca>
  40fb6c:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40fb72:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40fb78:	vptest xmm0,xmm0
  40fb7d:	jne    40fb9a <__swc_fn_0a4ed24b_000107_c8d4a68e+0x3ca>
  40fb7f:	mov    rcx,QWORD PTR [rsp+0x42]
  40fb84:	cmp    QWORD PTR [rsp+0x78],rcx
  40fb89:	jne    40fb9a <__swc_fn_0a4ed24b_000107_c8d4a68e+0x3ca>
  40fb8b:	mov    cx,WORD PTR [rsp+0x4a]
  40fb90:	cmp    WORD PTR [rsp+0x80],cx
  40fb98:	je     40fbc4 <__swc_fn_0a4ed24b_000107_c8d4a68e+0x3f4>
  40fb9a:	mov    rax,rbx
  40fb9d:	mov    rcx,r12
  40fba0:	movzx  edx,BYTE PTR [rax]
  40fba3:	movzx  r8d,BYTE PTR [rcx]
  40fba7:	cmp    rdx,r8
  40fbaa:	jne    40fbb6 <__swc_fn_0a4ed24b_000107_c8d4a68e+0x3e6>
  40fbac:	add    rax,0x1
  40fbb0:	add    rcx,0x1
  40fbb4:	jmp    40fba0 <__swc_fn_0a4ed24b_000107_c8d4a68e+0x3d0>
  40fbb6:	mov    rax,rdx
  40fbb9:	sub    rax,r8
  40fbbc:	test   eax,eax
  40fbbe:	jne    40fb00 <__swc_fn_0a4ed24b_000107_c8d4a68e+0x330>
  40fbc4:	movsxd rdi,DWORD PTR [r14]
  40fbc7:	mov    rsi,r13
  40fbca:	mov    edx,0x80002
  40fbcf:	xor    eax,eax
  40fbd1:	call   407180 <openat@plt>
  40fbd6:	lea    rbx,[rsp+0x98]
  40fbde:	mov    DWORD PTR [rsp+0x98],eax
  40fbe5:	test   eax,eax
  40fbe7:	mov    r13,QWORD PTR [rsp+0xb0]
  40fbef:	jge    40fc14 <__swc_fn_0a4ed24b_000107_c8d4a68e+0x444>
  40fbf1:	mov    rdi,r15
  40fbf4:	xor    eax,eax
  40fbf6:	call   407190 <closedir@plt>
  40fbfb:	mov    r13,QWORD PTR [rsp+0xb0]
  40fc03:	movsxd rdi,r13d
  40fc06:	xor    eax,eax
  40fc08:	call   4070b0 <close@plt>
  40fc0d:	xor    eax,eax
  40fc0f:	jmp    40fd86 <__swc_fn_0a4ed24b_000107_c8d4a68e+0x5b6>
  40fc14:	mov    rax,rbx
  40fc17:	movsxd rdi,DWORD PTR [rax]
  40fc1a:	xor    esi,esi
  40fc1c:	mov    edx,0x2
  40fc21:	xor    eax,eax
  40fc23:	call   4070a0 <lseek@plt>
  40fc28:	mov    r12,QWORD PTR [rsp+0xa8]
  40fc30:	cmp    rax,r12
  40fc33:	je     40fc5a <__swc_fn_0a4ed24b_000107_c8d4a68e+0x48a>
  40fc35:	movsxd rdi,DWORD PTR [rbx]
  40fc38:	xor    eax,eax
  40fc3a:	call   4070b0 <close@plt>
  40fc3f:	mov    rdi,r15
  40fc42:	xor    eax,eax
  40fc44:	call   407190 <closedir@plt>
  40fc49:	movsxd rdi,r13d
  40fc4c:	xor    eax,eax
  40fc4e:	call   4070b0 <close@plt>
  40fc53:	xor    eax,eax
  40fc55:	jmp    40fd86 <__swc_fn_0a4ed24b_000107_c8d4a68e+0x5b6>
  40fc5a:	xor    edi,edi
  40fc5c:	mov    rsi,r12
  40fc5f:	mov    edx,0x3
  40fc64:	mov    ecx,0x1
  40fc69:	mov    rax,rbx
  40fc6c:	movsxd r8,DWORD PTR [rax]
  40fc6f:	xor    r9d,r9d
  40fc72:	xor    eax,eax
  40fc74:	call   4070c0 <mmap@plt>
  40fc79:	xor    r12d,r12d
  40fc7c:	cmp    rax,0xffffffffffffffff
  40fc80:	cmovne r12,rax
  40fc84:	movsxd rdi,DWORD PTR [rbx]
  40fc87:	xor    eax,eax
  40fc89:	call   4070b0 <close@plt>
  40fc8e:	mov    rdi,r15
  40fc91:	xor    eax,eax
  40fc93:	call   407190 <closedir@plt>
  40fc98:	movsxd rdi,r13d
  40fc9b:	xor    eax,eax
  40fc9d:	call   4070b0 <close@plt>
  40fca2:	mov    rax,r12
  40fca5:	jmp    40fd86 <__swc_fn_0a4ed24b_000107_c8d4a68e+0x5b6>
  40fcaa:	mov    r14,QWORD PTR [rsp+0xb8]
  40fcb2:	mov    rdi,r14
  40fcb5:	mov    esi,0x1
  40fcba:	xor    eax,eax
  40fcbc:	call   4071a0 <memfd_create@plt>
  40fcc1:	lea    rbx,[rsp+0x9c]
  40fcc9:	mov    DWORD PTR [rsp+0x9c],eax
  40fcd0:	test   eax,eax
  40fcd2:	jge    40fcef <__swc_fn_0a4ed24b_000107_c8d4a68e+0x51f>
  40fcd4:	mov    rdi,r15
  40fcd7:	xor    eax,eax
  40fcd9:	call   407190 <closedir@plt>
  40fcde:	movsxd rdi,r13d
  40fce1:	xor    eax,eax
  40fce3:	call   4070b0 <close@plt>
  40fce8:	xor    eax,eax
  40fcea:	jmp    40fd86 <__swc_fn_0a4ed24b_000107_c8d4a68e+0x5b6>
  40fcef:	mov    rax,rbx
  40fcf2:	movsxd rdi,DWORD PTR [rax]
  40fcf5:	mov    rsi,r12
  40fcf8:	xor    eax,eax
  40fcfa:	call   4071b0 <ftruncate@plt>
  40fcff:	test   eax,eax
  40fd01:	je     40fd25 <__swc_fn_0a4ed24b_000107_c8d4a68e+0x555>
  40fd03:	movsxd rdi,DWORD PTR [rbx]
  40fd06:	xor    eax,eax
  40fd08:	call   4070b0 <close@plt>
  40fd0d:	mov    rdi,r15
  40fd10:	xor    eax,eax
  40fd12:	call   407190 <closedir@plt>
  40fd17:	movsxd rdi,r13d
  40fd1a:	xor    eax,eax
  40fd1c:	call   4070b0 <close@plt>
  40fd21:	xor    eax,eax
  40fd23:	jmp    40fd86 <__swc_fn_0a4ed24b_000107_c8d4a68e+0x5b6>
  40fd25:	xor    edi,edi
  40fd27:	mov    rsi,r12
  40fd2a:	mov    edx,0x3
  40fd2f:	mov    ecx,0x1
  40fd34:	mov    rax,rbx
  40fd37:	movsxd r8,DWORD PTR [rax]
  40fd3a:	xor    r9d,r9d
  40fd3d:	xor    eax,eax
  40fd3f:	call   4070c0 <mmap@plt>
  40fd44:	mov    r12,rax
  40fd47:	cmp    rax,0xffffffffffffffff
  40fd4b:	jne    40fd6f <__swc_fn_0a4ed24b_000107_c8d4a68e+0x59f>
  40fd4d:	movsxd rdi,DWORD PTR [rbx]
  40fd50:	xor    eax,eax
  40fd52:	call   4070b0 <close@plt>
  40fd57:	mov    rdi,r15
  40fd5a:	xor    eax,eax
  40fd5c:	call   407190 <closedir@plt>
  40fd61:	movsxd rdi,r13d
  40fd64:	xor    eax,eax
  40fd66:	call   4070b0 <close@plt>
  40fd6b:	xor    eax,eax
  40fd6d:	jmp    40fd86 <__swc_fn_0a4ed24b_000107_c8d4a68e+0x5b6>
  40fd6f:	mov    rdi,r15
  40fd72:	xor    eax,eax
  40fd74:	call   407190 <closedir@plt>
  40fd79:	movsxd rdi,r13d
  40fd7c:	xor    eax,eax
  40fd7e:	call   4070b0 <close@plt>
  40fd83:	mov    rax,r12
  40fd86:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40fd8f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40fd98:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40fda1:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40fdaa:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  40fdb3:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40fdbc:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  40fdc5:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40fdce:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  40fdd7:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  40fde0:	add    rsp,0x170
  40fde7:	pop    r15
  40fde9:	pop    r14
  40fdeb:	pop    r13
  40fded:	pop    rsi
  40fdee:	pop    rdi
  40fdef:	pop    r12
  40fdf1:	pop    rbx
  40fdf2:	ret
	...

000000000040fe00 <__swc_fn_0a4ed24b_000110_918d5a21>:
  40fe00:	push   rsi
  40fe01:	push   rdi
  40fe02:	push   r12
  40fe04:	push   r13
  40fe06:	sub    rsp,0x8
  40fe0a:	mov    rsi,r8
  40fe0d:	mov    rdi,rcx
  40fe10:	mov    r12,rdx
  40fe13:	call   409100 <__swc_fn_0a4ed24b_000108_b8f4bd15>
  40fe18:	mov    r13,rax
  40fe1b:	test   rax,rax
  40fe1e:	jne    40fe2b <__swc_fn_0a4ed24b_000110_918d5a21+0x2b>
  40fe20:	add    rsp,0x8
  40fe24:	pop    r13
  40fe26:	pop    r12
  40fe28:	pop    rdi
  40fe29:	pop    rsi
  40fe2a:	ret
  40fe2b:	mov    rcx,r13
  40fe2e:	call   40cfb0 <__swc_fn_0a4ed24b_000133_807fd51d>
  40fe33:	mov    rax,QWORD PTR [r13+0x8]
  40fe37:	test   rax,rax
  40fe3a:	je     40fe79 <__swc_fn_0a4ed24b_000110_918d5a21+0x79>
  40fe3c:	nop    DWORD PTR [rax+0x0]
  40fe40:	lea    rcx,[rax+0x1000]
  40fe47:	cmp    rdi,rcx
  40fe4a:	jne    40fe71 <__swc_fn_0a4ed24b_000110_918d5a21+0x71>
  40fe4c:	cmp    r12,0x1000
  40fe53:	jb     40fe71 <__swc_fn_0a4ed24b_000110_918d5a21+0x71>
  40fe55:	test   sil,sil
  40fe58:	setne  cl
  40fe5b:	mov    BYTE PTR [rax+0x10],cl
  40fe5e:	mov    rcx,r13
  40fe61:	call   410360 <__swc_fn_0a4ed24b_000134_10472836>
  40fe66:	add    rsp,0x8
  40fe6a:	pop    r13
  40fe6c:	pop    r12
  40fe6e:	pop    rdi
  40fe6f:	pop    rsi
  40fe70:	ret
  40fe71:	mov    rax,QWORD PTR [rax]
  40fe74:	test   rax,rax
  40fe77:	jne    40fe40 <__swc_fn_0a4ed24b_000110_918d5a21+0x40>
  40fe79:	mov    rcx,r13
  40fe7c:	call   410360 <__swc_fn_0a4ed24b_000134_10472836>
  40fe81:	add    rsp,0x8
  40fe85:	pop    r13
  40fe87:	pop    r12
  40fe89:	pop    rdi
  40fe8a:	pop    rsi
  40fe8b:	ret
  40fe8c:	add    BYTE PTR [rax],al
	...

000000000040fe90 <__swc_fn_0a4ed24b_000113_4e83a03a>:
  40fe90:	sub    rsp,0x8
  40fe94:	test   rcx,rcx
  40fe97:	jne    40fe9e <__swc_fn_0a4ed24b_000113_4e83a03a+0xe>
  40fe99:	add    rsp,0x8
  40fe9d:	ret
  40fe9e:	call   40cac0 <__swc_fn_0a4ed24b_000115_3f6af4b1>
  40fea3:	add    rsp,0x8
  40fea7:	ret
	...

000000000040feb0 <__swc_fn_0a4ed24b_000116_3f5cfdef>:
  40feb0:	push   r12
  40feb2:	push   r13
  40feb4:	push   r14
  40feb6:	push   rdi
  40feb7:	push   rsi
  40feb8:	sub    rsp,0xc0
  40febf:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40fec5:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40fecb:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40fed1:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40fed7:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40fedd:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40fee3:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40fee9:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40fef2:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40fefb:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40ff04:	mov    r12,QWORD PTR [rcx]
  40ff07:	test   r12,r12
  40ff0a:	jne    40ff1c <__swc_fn_0a4ed24b_000116_3f5cfdef+0x6c>
  40ff0c:	add    rsp,0xc0
  40ff13:	pop    rsi
  40ff14:	pop    rdi
  40ff15:	pop    r14
  40ff17:	pop    r13
  40ff19:	pop    r12
  40ff1b:	ret
  40ff1c:	xor    r13d,r13d
  40ff1f:	mov    r14,QWORD PTR [rcx+0x8]
  40ff23:	cs nop WORD PTR [rax+rax*1+0x0]
  40ff2d:	nop    DWORD PTR [rax]
  40ff30:	cmp    r13,r14
  40ff33:	jae    40ff6b <__swc_fn_0a4ed24b_000116_3f5cfdef+0xbb>
  40ff35:	lea    rax,[r12+r13*1]
  40ff39:	mov    rcx,r14
  40ff3c:	sub    rcx,r13
  40ff3f:	mov    edi,0x1
  40ff44:	mov    rsi,rax
  40ff47:	mov    rdx,rcx
  40ff4a:	xor    eax,eax
  40ff4c:	call   4071c0 <write@plt>
  40ff51:	test   rax,rax
  40ff54:	jle    40ff5b <__swc_fn_0a4ed24b_000116_3f5cfdef+0xab>
  40ff56:	add    r13,rax
  40ff59:	jmp    40ff30 <__swc_fn_0a4ed24b_000116_3f5cfdef+0x80>
  40ff5b:	je     40ff69 <__swc_fn_0a4ed24b_000116_3f5cfdef+0xb9>
  40ff5d:	xor    eax,eax
  40ff5f:	call   407130 <__errno_location@plt>
  40ff64:	cmp    DWORD PTR [rax],0x4
  40ff67:	je     40ff30 <__swc_fn_0a4ed24b_000116_3f5cfdef+0x80>
  40ff69:	jmp    40ff6b <__swc_fn_0a4ed24b_000116_3f5cfdef+0xbb>
  40ff6b:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ff71:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40ff77:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40ff7d:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ff83:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ff89:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ff8f:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ff95:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ff9e:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ffa7:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ffb0:	add    rsp,0xc0
  40ffb7:	pop    rsi
  40ffb8:	pop    rdi
  40ffb9:	pop    r14
  40ffbb:	pop    r13
  40ffbd:	pop    r12
  40ffbf:	ret

000000000040ffc0 <__swc_fn_0a4ed24b_000119_2d9caf16>:
  40ffc0:	push   rbx
  40ffc1:	push   r12
  40ffc3:	push   rdi
  40ffc4:	push   rsi
  40ffc5:	sub    rsp,0x4a8
  40ffcc:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  40ffd5:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  40ffde:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  40ffe7:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  40fff0:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  40fff9:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  410002:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  41000b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  410014:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  41001d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  410026:	mov    rbx,rdx
  410029:	mov    r12d,ecx
  41002c:	vxorps xmm0,xmm0,xmm0
  410030:	xor    eax,eax
  410032:	cs nop WORD PTR [rax+rax*1+0x0]
  41003c:	nop    DWORD PTR [rax+0x0]
  410040:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  410046:	add    rax,0x10
  41004a:	cmp    rax,0x400
  410051:	jne    410040 <__swc_fn_0a4ed24b_000119_2d9caf16+0x80>
  410053:	lea    rdi,[rsp+0x8]
  410058:	mov    esi,0x80
  41005d:	xor    eax,eax
  41005f:	call   4071d0 <backtrace@plt>
  410064:	test   eax,eax
  410066:	jle    410075 <__swc_fn_0a4ed24b_000119_2d9caf16+0xb5>
  410068:	movsxd rax,eax
  41006b:	lea    rcx,[r12+0x1]
  410070:	cmp    rcx,rax
  410073:	jb     410079 <__swc_fn_0a4ed24b_000119_2d9caf16+0xb9>
  410075:	xor    eax,eax
  410077:	jmp    4100aa <__swc_fn_0a4ed24b_000119_2d9caf16+0xea>
  410079:	mov    rcx,QWORD PTR [rbx+0x8]
  41007d:	sub    rax,r12
  410080:	lea    rsi,[rax-0x1]
  410084:	cmp    rcx,rsi
  410087:	cmovbe rsi,rcx
  41008b:	lea    eax,[r12+0x1]
  410090:	lea    rax,[rsp+rax*8+0x8]
  410095:	mov    rcx,QWORD PTR [rbx]
  410098:	mov    rdx,rax
  41009b:	lea    r8,[rsi*8+0x0]
  4100a3:	call   4090e0 <__swc_fn_0a4ed24b_000105_83487ba1>
  4100a8:	mov    eax,esi
  4100aa:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  4100b3:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  4100bc:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  4100c5:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  4100ce:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  4100d7:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  4100e0:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  4100e9:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  4100f2:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  4100fb:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  410104:	add    rsp,0x4a8
  41010b:	pop    rsi
  41010c:	pop    rdi
  41010d:	pop    r12
  41010f:	pop    rbx
  410110:	ret
	...

0000000000410120 <__swc_fn_0a4ed24b_000122_66e5d2a9>:
  410120:	mov    QWORD PTR [rcx],0x0
  410127:	ret
	...

0000000000410130 <__swc_fn_0a4ed24b_000125_7a81492f>:
  410130:	push   rdi
  410131:	push   rsi
  410132:	sub    rsp,0xa8
  410139:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41013f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410145:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41014b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410151:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410157:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41015d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410163:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410169:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410172:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41017b:	mov    edi,ecx
  41017d:	mov    rsi,rdx
  410180:	xor    eax,eax
  410182:	call   407060 <pthread_setspecific@plt>
  410187:	test   eax,eax
  410189:	sete   al
  41018c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410192:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410198:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41019e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4101a4:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4101aa:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4101b0:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4101b6:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4101bc:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4101c5:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4101ce:	add    rsp,0xa8
  4101d5:	pop    rsi
  4101d6:	pop    rdi
  4101d7:	ret
	...

00000000004101e0 <__swc_fn_0a4ed24b_000128_8d8a7dd2>:
  4101e0:	push   rdi
  4101e1:	push   rsi
  4101e2:	sub    rsp,0xa8
  4101e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4101ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4101f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4101fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410201:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410207:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41020d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410213:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410219:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410222:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41022b:	test   rcx,rcx
  41022e:	je     410241 <__swc_fn_0a4ed24b_000128_8d8a7dd2+0x61>
  410230:	lea    rax,[rcx-0x1]
  410234:	mov    eax,eax
  410236:	mov    edi,eax
  410238:	xor    eax,eax
  41023a:	call   407000 <pthread_getspecific@plt>
  41023f:	jmp    410243 <__swc_fn_0a4ed24b_000128_8d8a7dd2+0x63>
  410241:	xor    eax,eax
  410243:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410249:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  41024f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410255:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41025b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410261:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410267:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41026d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410273:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41027c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410285:	add    rsp,0xa8
  41028c:	pop    rsi
  41028d:	pop    rdi
  41028e:	ret
	...

0000000000410290 <__swc_fn_0a4ed24b_000131_91db8856>:
  410290:	push   rdi
  410291:	push   rsi
  410292:	sub    rsp,0xb8
  410299:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41029f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4102a5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4102ab:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4102b1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4102b7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4102bd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4102c3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4102cc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4102d5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4102de:	vxorps xmm0,xmm0,xmm0
  4102e2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4102e8:	mov    edi,0x1
  4102ed:	lea    rsi,[rsp+0x8]
  4102f2:	xor    eax,eax
  4102f4:	call   407110 <clock_gettime@plt>
  4102f9:	mov    rax,QWORD PTR [rsp+0x8]
  4102fe:	imul   rax,rax,0x3b9aca00
  410305:	add    rax,QWORD PTR [rsp+0x10]
  41030a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410310:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  410316:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  41031c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  410322:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410328:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  41032e:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  410334:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  41033d:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  410346:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  41034f:	add    rsp,0xb8
  410356:	pop    rsi
  410357:	pop    rdi
  410358:	ret
  410359:	add    BYTE PTR [rax],al
  41035b:	add    BYTE PTR [rax],al
  41035d:	add    BYTE PTR [rax],al
	...

0000000000410360 <__swc_fn_0a4ed24b_000134_10472836>:
  410360:	sub    rsp,0x8
  410364:	xor    eax,eax
  410366:	mov    DWORD PTR [rcx],eax
  410368:	mov    edx,0x7fffffff
  41036d:	call   4097e0 <__swc_fn_0a4ed24b_000132_51cc49e7>
  410372:	add    rsp,0x8
  410376:	ret
	...

0000000000410380 <__swc_fn_0a4ed24b_000137_2d595cc7>:
  410380:	push   rdi
  410381:	push   rsi
  410382:	sub    rsp,0xb8
  410389:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41038f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410395:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41039b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4103a1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4103a7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4103ad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4103b3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4103bc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4103c5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4103ce:	mov    edi,0x1
  4103d3:	xor    eax,eax
  4103d5:	call   4071e0 <__x86_get_cpuid_feature_leaf@plt>
  4103da:	mov    eax,DWORD PTR [rax+0x14]
  4103dd:	and    eax,0x20
  4103e0:	setne  al
  4103e3:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4103e9:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4103ef:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4103f5:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4103fb:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410401:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  410407:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41040d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  410416:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  41041f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410428:	add    rsp,0xb8
  41042f:	pop    rsi
  410430:	pop    rdi
  410431:	ret
	...

0000000000410440 <__swc_fn_0a4ed24b_000140_55003b6d>:
  410440:	push   rsi
  410441:	push   rdi
  410442:	push   r12
  410444:	push   r13
  410446:	push   r14
  410448:	push   r15
  41044a:	cmp    rdx,0x40
  41044e:	jae    41045d <__swc_fn_0a4ed24b_000140_55003b6d+0x1d>
  410450:	xor    eax,eax
  410452:	pop    r15
  410454:	pop    r14
  410456:	pop    r13
  410458:	pop    r12
  41045a:	pop    rdi
  41045b:	pop    rsi
  41045c:	ret
  41045d:	cmp    BYTE PTR [rcx],0x7f
  410460:	jne    4104a4 <__swc_fn_0a4ed24b_000140_55003b6d+0x64>
  410462:	movzx  eax,BYTE PTR [rcx+0x1]
  410466:	cmp    eax,0x45
  410469:	setne  al
  41046c:	jne    4104a0 <__swc_fn_0a4ed24b_000140_55003b6d+0x60>
  41046e:	movzx  eax,BYTE PTR [rcx+0x2]
  410472:	cmp    eax,0x4c
  410475:	setne  al
  410478:	jne    4104a0 <__swc_fn_0a4ed24b_000140_55003b6d+0x60>
  41047a:	movzx  eax,BYTE PTR [rcx+0x3]
  41047e:	cmp    eax,0x46
  410481:	setne  al
  410484:	jne    4104a0 <__swc_fn_0a4ed24b_000140_55003b6d+0x60>
  410486:	cmp    BYTE PTR [rcx+0x4],0x2
  41048a:	setne  al
  41048d:	jne    4104a0 <__swc_fn_0a4ed24b_000140_55003b6d+0x60>
  41048f:	cmp    BYTE PTR [rcx+0x5],0x1
  410493:	setne  al
  410496:	jne    4104a0 <__swc_fn_0a4ed24b_000140_55003b6d+0x60>
  410498:	cmp    WORD PTR [rcx+0x12],0x3e
  41049d:	setne  al
  4104a0:	test   al,al
  4104a2:	je     4104b1 <__swc_fn_0a4ed24b_000140_55003b6d+0x71>
  4104a4:	xor    eax,eax
  4104a6:	pop    r15
  4104a8:	pop    r14
  4104aa:	pop    r13
  4104ac:	pop    r12
  4104ae:	pop    rdi
  4104af:	pop    rsi
  4104b0:	ret
  4104b1:	cmp    WORD PTR [rcx+0x3a],0x40
  4104b6:	jne    4104d1 <__swc_fn_0a4ed24b_000140_55003b6d+0x91>
  4104b8:	cmp    WORD PTR [rcx+0x3c],0x0
  4104bd:	sete   al
  4104c0:	je     4104cd <__swc_fn_0a4ed24b_000140_55003b6d+0x8d>
  4104c2:	mov    ax,WORD PTR [rcx+0x3c]
  4104c6:	cmp    WORD PTR [rcx+0x3e],ax
  4104ca:	setae  al
  4104cd:	test   al,al
  4104cf:	je     4104de <__swc_fn_0a4ed24b_000140_55003b6d+0x9e>
  4104d1:	xor    eax,eax
  4104d3:	pop    r15
  4104d5:	pop    r14
  4104d7:	pop    r13
  4104d9:	pop    r12
  4104db:	pop    rdi
  4104dc:	pop    rsi
  4104dd:	ret
  4104de:	movzx  eax,WORD PTR [rcx+0x3c]
  4104e2:	shl    rax,0x6
  4104e6:	cmp    rax,rdx
  4104e9:	ja     4104f7 <__swc_fn_0a4ed24b_000140_55003b6d+0xb7>
  4104eb:	mov    r9,rdx
  4104ee:	sub    r9,rax
  4104f1:	cmp    QWORD PTR [rcx+0x28],r9
  4104f5:	jbe    410504 <__swc_fn_0a4ed24b_000140_55003b6d+0xc4>
  4104f7:	xor    eax,eax
  4104f9:	pop    r15
  4104fb:	pop    r14
  4104fd:	pop    r13
  4104ff:	pop    r12
  410501:	pop    rdi
  410502:	pop    rsi
  410503:	ret
  410504:	mov    rax,QWORD PTR [rcx+0x28]
  410508:	add    rax,rcx
  41050b:	movzx  r9d,WORD PTR [rcx+0x3e]
  410510:	lea    r9,[r9*8+0x0]
  410518:	lea    r10,[rax+r9*8]
  41051c:	cmp    QWORD PTR [r10+0x20],rdx
  410520:	ja     410542 <__swc_fn_0a4ed24b_000140_55003b6d+0x102>
  410522:	mov    r11,rdx
  410525:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  41052a:	cmp    QWORD PTR [r10+0x18],r11
  41052e:	seta   r9b
  410532:	ja     41053d <__swc_fn_0a4ed24b_000140_55003b6d+0xfd>
  410534:	cmp    QWORD PTR [r10+0x20],0x9
  410539:	setb   r9b
  41053d:	test   r9b,r9b
  410540:	je     41054f <__swc_fn_0a4ed24b_000140_55003b6d+0x10f>
  410542:	xor    eax,eax
  410544:	pop    r15
  410546:	pop    r14
  410548:	pop    r13
  41054a:	pop    r12
  41054c:	pop    rdi
  41054d:	pop    rsi
  41054e:	ret
  41054f:	movzx  r9d,WORD PTR [rcx+0x3c]
  410554:	xor    r11d,r11d
  410557:	test   r9,r9
  41055a:	jbe    410655 <__swc_fn_0a4ed24b_000140_55003b6d+0x215>
  410560:	mov    rsi,QWORD PTR [r10+0x20]
  410564:	sub    rsi,0x9
  410568:	cs nop WORD PTR [rax+rax*1+0x0]
  410572:	cs nop WORD PTR [rax+rax*1+0x0]
  41057c:	nop    DWORD PTR [rax+0x0]
  410580:	movzx  edi,r11w
  410584:	lea    rdi,[rdi*8+0x0]
  41058c:	lea    r12,[rax+rdi*8]
  410590:	rex mov edi,DWORD PTR [rax+rdi*8]
  410594:	cmp    rdi,rsi
  410597:	ja     410648 <__swc_fn_0a4ed24b_000140_55003b6d+0x208>
  41059d:	mov    r13,QWORD PTR [r10+0x18]
  4105a1:	add    r13,rdi
  4105a4:	lea    rdi,[rcx+r13*1]
  4105a8:	lea    r13,[rip+0x2f81]        # 413530 <__swc_rdata_base_0a4ed24b+0x420>
  4105af:	movabs r14,0x676264676177732e
  4105b9:	cmp    QWORD PTR [rdi],r14
  4105bc:	jne    4105c5 <__swc_fn_0a4ed24b_000140_55003b6d+0x185>
  4105be:	rex cmp BYTE PTR [rdi+0x8],0x0
  4105c3:	je     4105f2 <__swc_fn_0a4ed24b_000140_55003b6d+0x1b2>
  4105c5:	cs nop WORD PTR [rax+rax*1+0x0]
  4105cf:	nop
  4105d0:	movzx  r14d,BYTE PTR [rdi]
  4105d4:	movzx  r15d,BYTE PTR [r13+0x0]
  4105d9:	cmp    r14,r15
  4105dc:	jne    4105e8 <__swc_fn_0a4ed24b_000140_55003b6d+0x1a8>
  4105de:	add    rdi,0x1
  4105e2:	add    r13,0x1
  4105e6:	jmp    4105d0 <__swc_fn_0a4ed24b_000140_55003b6d+0x190>
  4105e8:	mov    rdi,r14
  4105eb:	sub    rdi,r15
  4105ee:	test   edi,edi
  4105f0:	jne    410648 <__swc_fn_0a4ed24b_000140_55003b6d+0x208>
  4105f2:	cmp    DWORD PTR [r12+0x4],0x1
  4105f8:	jne    410620 <__swc_fn_0a4ed24b_000140_55003b6d+0x1e0>
  4105fa:	cmp    QWORD PTR [r12+0x20],0x10
  410600:	setb   al
  410603:	jb     41061c <__swc_fn_0a4ed24b_000140_55003b6d+0x1dc>
  410605:	cmp    QWORD PTR [r12+0x20],rdx
  41060a:	seta   al
  41060d:	ja     41061c <__swc_fn_0a4ed24b_000140_55003b6d+0x1dc>
  41060f:	sub    rdx,QWORD PTR [r12+0x20]
  410614:	cmp    QWORD PTR [r12+0x18],rdx
  410619:	seta   al
  41061c:	test   al,al
  41061e:	je     41062d <__swc_fn_0a4ed24b_000140_55003b6d+0x1ed>
  410620:	xor    eax,eax
  410622:	pop    r15
  410624:	pop    r14
  410626:	pop    r13
  410628:	pop    r12
  41062a:	pop    rdi
  41062b:	pop    rsi
  41062c:	ret
  41062d:	mov    rax,QWORD PTR [r12+0x20]
  410632:	mov    QWORD PTR [r8],rax
  410635:	mov    rax,QWORD PTR [r12+0x18]
  41063a:	add    rax,rcx
  41063d:	pop    r15
  41063f:	pop    r14
  410641:	pop    r13
  410643:	pop    r12
  410645:	pop    rdi
  410646:	pop    rsi
  410647:	ret
  410648:	add    r11,0x1
  41064c:	cmp    r11,r9
  41064f:	jb     410580 <__swc_fn_0a4ed24b_000140_55003b6d+0x140>
  410655:	xor    eax,eax
  410657:	pop    r15
  410659:	pop    r14
  41065b:	pop    r13
  41065d:	pop    r12
  41065f:	pop    rdi
  410660:	pop    rsi
  410661:	ret
	...

0000000000410670 <__swc_fn_0a4ed24b_000143_b7ad855f>:
  410670:	push   rdi
  410671:	push   rsi
  410672:	sub    rsp,0xa8
  410679:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41067f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410685:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41068b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410691:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410697:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41069d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4106a3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4106a9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4106b2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4106bb:	mov    rdi,rcx
  4106be:	xor    eax,eax
  4106c0:	call   4071f0 <free@plt>
  4106c5:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4106cb:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4106d1:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4106d7:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4106dd:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4106e3:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4106e9:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4106ef:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4106f5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4106fe:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410707:	add    rsp,0xa8
  41070e:	pop    rsi
  41070f:	pop    rdi
  410710:	ret
	...

0000000000410720 <__swc_fn_0a4ed24b_000146_d2097256>:
  410720:	push   rbx
  410721:	push   rsi
  410722:	push   rdi
  410723:	push   r12
  410725:	push   r13
  410727:	push   r15
  410729:	sub    rsp,0x4e8
  410730:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  410739:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  410742:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  41074b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  410754:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  41075d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  410766:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  41076f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  410778:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  410781:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  41078a:	mov    rbx,QWORD PTR [rcx]
  41078d:	mov    rcx,QWORD PTR [rcx+0x8]
  410791:	mov    rsi,rcx
  410794:	xor    edi,edi
  410796:	vmovsd xmm6,QWORD PTR [rip+0x2df2]        # 413590 <__swc_rdata_base_0a4ed24b+0x480>
  41079e:	vmovsd xmm7,QWORD PTR [rip+0x2df3]        # 413599 <__swc_rdata_base_0a4ed24b+0x489>
  4107a6:	vmovsd xmm8,QWORD PTR [rip+0x2df4]        # 4135a2 <__swc_rdata_base_0a4ed24b+0x492>
  4107ae:	vmovsd xmm9,QWORD PTR [rip+0x2df5]        # 4135ab <__swc_rdata_base_0a4ed24b+0x49b>
  4107b6:	vmovsd xmm10,QWORD PTR [rip+0x2df6]        # 4135b4 <__swc_rdata_base_0a4ed24b+0x4a4>
  4107be:	vmovups xmm11,xmm6
  4107c2:	vmovsd QWORD PTR [rsp+0x418],xmm7
  4107cb:	vmovsd QWORD PTR [rsp+0x420],xmm8
  4107d4:	vmovsd QWORD PTR [rsp+0x428],xmm9
  4107dd:	vmovsd QWORD PTR [rsp+0x430],xmm10
  4107e6:	vmovsd xmm15,QWORD PTR [rip+0x2dcf]        # 4135bd <__swc_rdata_base_0a4ed24b+0x4ad>
  4107ee:	vmovups xmm14,xmm15
  4107f3:	vmovups xmm0,xmm9
  4107f8:	vmovsd QWORD PTR [rsp+0x438],xmm15
  410801:	vmovups xmm13,xmm8
  410806:	vmovsd QWORD PTR [rsp+0x440],xmm15
  41080f:	test   rsi,rsi
  410812:	je     411803 <__swc_fn_0a4ed24b_000146_d2097256+0x10e3>
  410818:	cs nop WORD PTR [rax+rax*1+0x0]
  410822:	cs nop WORD PTR [rax+rax*1+0x0]
  41082c:	nop    DWORD PTR [rax+0x0]
  410830:	lea    rcx,[rdi+rdi*1]
  410834:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  410839:	vpshufd xmm3,xmm2,0xee
  41083e:	vmovq  rcx,xmm3
  410843:	test   rcx,rcx
  410846:	je     41085c <__swc_fn_0a4ed24b_000146_d2097256+0x13c>
  410848:	test   DWORD PTR [rcx+0x28],0x400000
  41084f:	je     41085c <__swc_fn_0a4ed24b_000146_d2097256+0x13c>
  410851:	mov    rdx,QWORD PTR [rcx+0x30]
  410855:	test   rdx,rdx
  410858:	cmovne rcx,rdx
  41085c:	test   DWORD PTR [rcx+0x28],0x1000
  410863:	je     410884 <__swc_fn_0a4ed24b_000146_d2097256+0x164>
  410865:	mov    rdx,QWORD PTR [rcx+0x40]
  410869:	mov    rcx,rdx
  41086c:	vmovq  r8,xmm2
  410871:	mov    r8,QWORD PTR [r8]
  410874:	mov    QWORD PTR [rsp+0x60],r8
  410879:	mov    QWORD PTR [rsp+0x68],rdx
  41087e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  410884:	test   BYTE PTR [rcx+0x28],0x1
  410888:	jne    410890 <__swc_fn_0a4ed24b_000146_d2097256+0x170>
  41088a:	vmovups xmm12,xmm0
  41088e:	jmp    4108aa <__swc_fn_0a4ed24b_000146_d2097256+0x18a>
  410890:	vmovq  rax,xmm2
  410895:	mov    rax,QWORD PTR [rax]
  410898:	lea    rcx,[rax+0x10]
  41089c:	vmovups xmm12,xmm0
  4108a0:	call   40feb0 <__swc_fn_0a4ed24b_000116_3f5cfdef>
  4108a5:	jmp    4117e5 <__swc_fn_0a4ed24b_000146_d2097256+0x10c5>
  4108aa:	test   DWORD PTR [rcx+0x28],0x400
  4108b1:	je     410912 <__swc_fn_0a4ed24b_000146_d2097256+0x1f2>
  4108b3:	vmovq  rax,xmm2
  4108b8:	mov    rax,QWORD PTR [rax]
  4108bb:	xor    ecx,ecx
  4108bd:	test   rax,rax
  4108c0:	je     4108f0 <__swc_fn_0a4ed24b_000146_d2097256+0x1d0>
  4108c2:	mov    rdx,rax
  4108c5:	mov    r8b,BYTE PTR [rdx]
  4108c8:	test   r8b,r8b
  4108cb:	je     4108f0 <__swc_fn_0a4ed24b_000146_d2097256+0x1d0>
  4108cd:	cs nop WORD PTR [rax+rax*1+0x0]
  4108d7:	nop    WORD PTR [rax+rax*1+0x0]
  4108e0:	add    rdx,0x1
  4108e4:	add    rcx,0x1
  4108e8:	mov    r8b,BYTE PTR [rdx]
  4108eb:	test   r8b,r8b
  4108ee:	jne    4108e0 <__swc_fn_0a4ed24b_000146_d2097256+0x1c0>
  4108f0:	mov    QWORD PTR [rsp+0x88],rax
  4108f8:	mov    QWORD PTR [rsp+0x90],rcx
  410900:	lea    rcx,[rsp+0x88]
  410908:	call   40feb0 <__swc_fn_0a4ed24b_000116_3f5cfdef>
  41090d:	jmp    4117e5 <__swc_fn_0a4ed24b_000146_d2097256+0x10c5>
  410912:	cmp    BYTE PTR [rcx+0x2c],0x6
  410916:	jne    41092d <__swc_fn_0a4ed24b_000146_d2097256+0x20d>
  410918:	vmovq  rax,xmm2
  41091d:	mov    rax,QWORD PTR [rax]
  410920:	mov    rcx,rax
  410923:	call   409cb0 <__swc_fn_0a4ed24b_000144_c3e86ca0>
  410928:	jmp    4117e5 <__swc_fn_0a4ed24b_000146_d2097256+0x10c5>
  41092d:	cmp    BYTE PTR [rcx+0x2c],0x1
  410931:	jne    4117d9 <__swc_fn_0a4ed24b_000146_d2097256+0x10b9>
  410937:	vmovq  rdx,xmm2
  41093c:	mov    cl,BYTE PTR [rcx+0x40]
  41093f:	cmp    cl,0x7
  410942:	jb     410985 <__swc_fn_0a4ed24b_000146_d2097256+0x265>
  410944:	je     4109f8 <__swc_fn_0a4ed24b_000146_d2097256+0x2d8>
  41094a:	cmp    cl,0x8
  41094d:	je     410a04 <__swc_fn_0a4ed24b_000146_d2097256+0x2e4>
  410953:	cmp    cl,0x9
  410956:	je     410a1d <__swc_fn_0a4ed24b_000146_d2097256+0x2fd>
  41095c:	cmp    cl,0xa
  41095f:	je     4110e4 <__swc_fn_0a4ed24b_000146_d2097256+0x9c4>
  410965:	cmp    cl,0xb
  410968:	je     4117ab <__swc_fn_0a4ed24b_000146_d2097256+0x108b>
  41096e:	cmp    cl,0xc
  410971:	je     410a11 <__swc_fn_0a4ed24b_000146_d2097256+0x2f1>
  410977:	cmp    cl,0xd
  41097a:	je     4117a1 <__swc_fn_0a4ed24b_000146_d2097256+0x1081>
  410980:	jmp    4117cb <__swc_fn_0a4ed24b_000146_d2097256+0x10ab>
  410985:	cmp    cl,0x1
  410988:	je     4109a8 <__swc_fn_0a4ed24b_000146_d2097256+0x288>
  41098a:	cmp    cl,0x2
  41098d:	je     4109b6 <__swc_fn_0a4ed24b_000146_d2097256+0x296>
  41098f:	cmp    cl,0x3
  410992:	je     4109c4 <__swc_fn_0a4ed24b_000146_d2097256+0x2a4>
  410994:	cmp    cl,0x4
  410997:	je     4109d1 <__swc_fn_0a4ed24b_000146_d2097256+0x2b1>
  410999:	cmp    cl,0x5
  41099c:	je     4109de <__swc_fn_0a4ed24b_000146_d2097256+0x2be>
  41099e:	cmp    cl,0x6
  4109a1:	je     4109eb <__swc_fn_0a4ed24b_000146_d2097256+0x2cb>
  4109a3:	jmp    4117cb <__swc_fn_0a4ed24b_000146_d2097256+0x10ab>
  4109a8:	movsx  rcx,BYTE PTR [rdx]
  4109ac:	call   40d1a0 <__swc_fn_0a4ed24b_000145_32a1d6a2>
  4109b1:	jmp    4117e5 <__swc_fn_0a4ed24b_000146_d2097256+0x10c5>
  4109b6:	movsx  rcx,WORD PTR [rdx]
  4109ba:	call   40d1a0 <__swc_fn_0a4ed24b_000145_32a1d6a2>
  4109bf:	jmp    4117e5 <__swc_fn_0a4ed24b_000146_d2097256+0x10c5>
  4109c4:	movsxd rcx,DWORD PTR [rdx]
  4109c7:	call   40d1a0 <__swc_fn_0a4ed24b_000145_32a1d6a2>
  4109cc:	jmp    4117e5 <__swc_fn_0a4ed24b_000146_d2097256+0x10c5>
  4109d1:	mov    rcx,QWORD PTR [rdx]
  4109d4:	call   40d1a0 <__swc_fn_0a4ed24b_000145_32a1d6a2>
  4109d9:	jmp    4117e5 <__swc_fn_0a4ed24b_000146_d2097256+0x10c5>
  4109de:	movzx  ecx,BYTE PTR [rdx]
  4109e1:	call   409cb0 <__swc_fn_0a4ed24b_000144_c3e86ca0>
  4109e6:	jmp    4117e5 <__swc_fn_0a4ed24b_000146_d2097256+0x10c5>
  4109eb:	movzx  ecx,WORD PTR [rdx]
  4109ee:	call   409cb0 <__swc_fn_0a4ed24b_000144_c3e86ca0>
  4109f3:	jmp    4117e5 <__swc_fn_0a4ed24b_000146_d2097256+0x10c5>
  4109f8:	mov    ecx,DWORD PTR [rdx]
  4109fa:	call   409cb0 <__swc_fn_0a4ed24b_000144_c3e86ca0>
  4109ff:	jmp    4117e5 <__swc_fn_0a4ed24b_000146_d2097256+0x10c5>
  410a04:	mov    rcx,QWORD PTR [rdx]
  410a07:	call   409cb0 <__swc_fn_0a4ed24b_000144_c3e86ca0>
  410a0c:	jmp    4117e5 <__swc_fn_0a4ed24b_000146_d2097256+0x10c5>
  410a11:	mov    ecx,DWORD PTR [rdx]
  410a13:	call   409cb0 <__swc_fn_0a4ed24b_000144_c3e86ca0>
  410a18:	jmp    4117e5 <__swc_fn_0a4ed24b_000146_d2097256+0x10c5>
  410a1d:	lea    rcx,[rsp+0xa8]
  410a25:	vxorps xmm0,xmm0,xmm0
  410a29:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  410a32:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  410a3b:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  410a44:	vzeroupper
  410a47:	mov    DWORD PTR [rsp+0x108],0x0
  410a52:	vxorpd xmm0,xmm0,xmm0
  410a56:	vmovss xmm1,DWORD PTR [rdx]
  410a5a:	vcvtss2sd xmm0,xmm0,xmm1
  410a5e:	vmovsd xmm1,xmm1,xmm0
  410a62:	vcomisd xmm0,xmm0
  410a66:	setne  dl
  410a69:	movzx  edx,dl
  410a6c:	setp   r8b
  410a70:	movzx  r8d,r8b
  410a74:	or     edx,r8d
  410a77:	test   dl,dl
  410a79:	je     410a86 <__swc_fn_0a4ed24b_000146_d2097256+0x366>
  410a7b:	mov    DWORD PTR [rcx],0x6e616e
  410a81:	jmp    411078 <__swc_fn_0a4ed24b_000146_d2097256+0x958>
  410a86:	vcomisd xmm1,xmm6
  410a8a:	ja     410a92 <__swc_fn_0a4ed24b_000146_d2097256+0x372>
  410a8c:	vcomisd xmm7,xmm1
  410a90:	jbe    410ab6 <__swc_fn_0a4ed24b_000146_d2097256+0x396>
  410a92:	vxorpd xmm0,xmm0,xmm0
  410a96:	vcomisd xmm0,xmm1
  410a9a:	jbe    410aab <__swc_fn_0a4ed24b_000146_d2097256+0x38b>
  410a9c:	mov    DWORD PTR [rcx],0x666e692d
  410aa2:	mov    BYTE PTR [rcx+0x4],0x0
  410aa6:	jmp    411078 <__swc_fn_0a4ed24b_000146_d2097256+0x958>
  410aab:	mov    DWORD PTR [rcx],0x666e69
  410ab1:	jmp    411078 <__swc_fn_0a4ed24b_000146_d2097256+0x958>
  410ab6:	vcomisd xmm1,xmm8
  410abb:	jae    410ac7 <__swc_fn_0a4ed24b_000146_d2097256+0x3a7>
  410abd:	vcomisd xmm9,xmm1
  410ac1:	jbe    410e3e <__swc_fn_0a4ed24b_000146_d2097256+0x71e>
  410ac7:	vmovups xmm0,xmm1
  410acb:	vxorpd xmm2,xmm2,xmm2
  410acf:	vcomisd xmm2,xmm1
  410ad3:	jbe    410ae3 <__swc_fn_0a4ed24b_000146_d2097256+0x3c3>
  410ad5:	vmovsd xmm1,xmm1,xmm0
  410ad9:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x2a6f]        # 413550 <__swc_rdata_base_0a4ed24b+0x440>
  410ae1:	jmp    410ae7 <__swc_fn_0a4ed24b_000146_d2097256+0x3c7>
  410ae3:	vmovsd xmm1,xmm1,xmm0
  410ae7:	xor    r8d,r8d
  410aea:	vcomisd xmm1,xmm15
  410aef:	jb     410b10 <__swc_fn_0a4ed24b_000146_d2097256+0x3f0>
  410af1:	cs nop WORD PTR [rax+rax*1+0x0]
  410afb:	nop    DWORD PTR [rax+rax*1+0x0]
  410b00:	vdivsd xmm1,xmm1,xmm15
  410b05:	add    r8,0x1
  410b09:	vcomisd xmm1,xmm15
  410b0e:	jae    410b00 <__swc_fn_0a4ed24b_000146_d2097256+0x3e0>
  410b10:	mov    r9,rcx
  410b13:	vxorpd xmm2,xmm2,xmm2
  410b17:	vcomisd xmm2,xmm0
  410b1b:	jbe    410b24 <__swc_fn_0a4ed24b_000146_d2097256+0x404>
  410b1d:	mov    BYTE PTR [rcx],0x2d
  410b20:	lea    r9,[rcx+0x1]
  410b24:	vcvttsd2si rdx,xmm1
  410b29:	mov    r10b,dl
  410b2c:	add    r10b,0x30
  410b30:	mov    BYTE PTR [r9],r10b
  410b33:	vxorpd xmm0,xmm0,xmm0
  410b37:	movzx  edx,dl
  410b3a:	vcvtsi2sd xmm0,xmm0,rdx
  410b3f:	vsubsd xmm0,xmm1,xmm0
  410b43:	vmulsd xmm1,xmm0,xmm15
  410b48:	mov    BYTE PTR [r9+0x1],0x2e
  410b4d:	vcvttsd2si rdx,xmm1
  410b52:	mov    r10b,dl
  410b55:	add    r10b,0x30
  410b59:	mov    BYTE PTR [r9+0x2],r10b
  410b5d:	vxorpd xmm0,xmm0,xmm0
  410b61:	movzx  edx,dl
  410b64:	vcvtsi2sd xmm0,xmm0,rdx
  410b69:	vsubsd xmm0,xmm1,xmm0
  410b6d:	vmulsd xmm1,xmm0,xmm15
  410b72:	vcvttsd2si rdx,xmm1
  410b77:	mov    r10b,dl
  410b7a:	add    r10b,0x30
  410b7e:	mov    BYTE PTR [r9+0x3],r10b
  410b82:	vxorpd xmm0,xmm0,xmm0
  410b86:	movzx  edx,dl
  410b89:	vcvtsi2sd xmm0,xmm0,rdx
  410b8e:	vsubsd xmm0,xmm1,xmm0
  410b92:	vmulsd xmm1,xmm0,xmm15
  410b97:	vcvttsd2si rdx,xmm1
  410b9c:	mov    r10b,dl
  410b9f:	add    r10b,0x30
  410ba3:	mov    BYTE PTR [r9+0x4],r10b
  410ba7:	vxorpd xmm0,xmm0,xmm0
  410bab:	movzx  edx,dl
  410bae:	vcvtsi2sd xmm0,xmm0,rdx
  410bb3:	vsubsd xmm0,xmm1,xmm0
  410bb7:	vmulsd xmm1,xmm0,xmm15
  410bbc:	vcvttsd2si rdx,xmm1
  410bc1:	mov    r10b,dl
  410bc4:	add    r10b,0x30
  410bc8:	mov    BYTE PTR [r9+0x5],r10b
  410bcc:	vxorpd xmm0,xmm0,xmm0
  410bd0:	movzx  edx,dl
  410bd3:	vcvtsi2sd xmm0,xmm0,rdx
  410bd8:	vsubsd xmm0,xmm1,xmm0
  410bdc:	vmulsd xmm1,xmm0,xmm15
  410be1:	vcvttsd2si rdx,xmm1
  410be6:	mov    r10b,dl
  410be9:	add    r10b,0x30
  410bed:	mov    BYTE PTR [r9+0x6],r10b
  410bf1:	vxorpd xmm0,xmm0,xmm0
  410bf5:	movzx  edx,dl
  410bf8:	vcvtsi2sd xmm0,xmm0,rdx
  410bfd:	vsubsd xmm0,xmm1,xmm0
  410c01:	vmulsd xmm1,xmm0,xmm15
  410c06:	vcvttsd2si rdx,xmm1
  410c0b:	mov    r10b,dl
  410c0e:	add    r10b,0x30
  410c12:	mov    BYTE PTR [r9+0x7],r10b
  410c16:	vxorpd xmm0,xmm0,xmm0
  410c1a:	movzx  edx,dl
  410c1d:	vcvtsi2sd xmm0,xmm0,rdx
  410c22:	vsubsd xmm0,xmm1,xmm0
  410c26:	vmulsd xmm1,xmm0,xmm15
  410c2b:	vcvttsd2si rdx,xmm1
  410c30:	mov    r10b,dl
  410c33:	add    r10b,0x30
  410c37:	mov    BYTE PTR [r9+0x8],r10b
  410c3b:	vxorpd xmm0,xmm0,xmm0
  410c3f:	movzx  edx,dl
  410c42:	vcvtsi2sd xmm0,xmm0,rdx
  410c47:	vsubsd xmm0,xmm1,xmm0
  410c4b:	vmulsd xmm1,xmm0,xmm15
  410c50:	vcvttsd2si rdx,xmm1
  410c55:	mov    r10b,dl
  410c58:	add    r10b,0x30
  410c5c:	mov    BYTE PTR [r9+0x9],r10b
  410c60:	vxorpd xmm0,xmm0,xmm0
  410c64:	movzx  edx,dl
  410c67:	vcvtsi2sd xmm0,xmm0,rdx
  410c6c:	vsubsd xmm0,xmm1,xmm0
  410c70:	vmulsd xmm1,xmm0,xmm15
  410c75:	vcvttsd2si rdx,xmm1
  410c7a:	mov    r10b,dl
  410c7d:	add    r10b,0x30
  410c81:	mov    BYTE PTR [r9+0xa],r10b
  410c85:	vxorpd xmm0,xmm0,xmm0
  410c89:	movzx  edx,dl
  410c8c:	vcvtsi2sd xmm0,xmm0,rdx
  410c91:	vsubsd xmm0,xmm1,xmm0
  410c95:	vmulsd xmm1,xmm0,xmm15
  410c9a:	vcvttsd2si rdx,xmm1
  410c9f:	mov    r10b,dl
  410ca2:	add    r10b,0x30
  410ca6:	mov    BYTE PTR [r9+0xb],r10b
  410caa:	lea    r10,[r9+0x4]
  410cae:	vxorpd xmm0,xmm0,xmm0
  410cb2:	movzx  edx,dl
  410cb5:	vcvtsi2sd xmm0,xmm0,rdx
  410cba:	vsubsd xmm0,xmm1,xmm0
  410cbe:	vmulsd xmm1,xmm0,xmm15
  410cc3:	vcvttsd2si rdx,xmm1
  410cc8:	mov    r11b,dl
  410ccb:	add    r11b,0x30
  410ccf:	mov    BYTE PTR [r9+0xc],r11b
  410cd3:	vxorpd xmm0,xmm0,xmm0
  410cd7:	movzx  edx,dl
  410cda:	vcvtsi2sd xmm0,xmm0,rdx
  410cdf:	vsubsd xmm0,xmm1,xmm0
  410ce3:	vmulsd xmm1,xmm0,xmm15
  410ce8:	vcvttsd2si rdx,xmm1
  410ced:	mov    r11b,dl
  410cf0:	add    r11b,0x30
  410cf4:	mov    BYTE PTR [r9+0xd],r11b
  410cf8:	lea    r10,[r10+0x2]
  410cfc:	vxorpd xmm0,xmm0,xmm0
  410d00:	movzx  edx,dl
  410d03:	vcvtsi2sd xmm0,xmm0,rdx
  410d08:	vsubsd xmm0,xmm1,xmm0
  410d0c:	vmulsd xmm1,xmm0,xmm15
  410d11:	vcvttsd2si rdx,xmm1
  410d16:	mov    r11b,dl
  410d19:	add    r11b,0x30
  410d1d:	mov    BYTE PTR [r9+0xe],r11b
  410d21:	vxorpd xmm0,xmm0,xmm0
  410d25:	movzx  edx,dl
  410d28:	vcvtsi2sd xmm0,xmm0,rdx
  410d2d:	vsubsd xmm0,xmm1,xmm0
  410d31:	vmulsd xmm1,xmm0,xmm15
  410d36:	vcvttsd2si rdx,xmm1
  410d3b:	mov    r11b,dl
  410d3e:	add    r11b,0x30
  410d42:	mov    BYTE PTR [r9+0xf],r11b
  410d46:	lea    r10,[r10+0x2]
  410d4a:	lea    r10,[r10+0x2]
  410d4e:	lea    r10,[r10+0x2]
  410d52:	lea    r10,[r10+0x2]
  410d56:	lea    r10,[r10+0x2]
  410d5a:	vxorpd xmm0,xmm0,xmm0
  410d5e:	movzx  edx,dl
  410d61:	vcvtsi2sd xmm0,xmm0,rdx
  410d66:	vsubsd xmm0,xmm1,xmm0
  410d6a:	vmulsd xmm1,xmm0,xmm15
  410d6f:	vcvttsd2si rdx,xmm1
  410d74:	mov    r11b,dl
  410d77:	add    r11b,0x30
  410d7b:	mov    BYTE PTR [r9+0x10],r11b
  410d7f:	vxorpd xmm0,xmm0,xmm0
  410d83:	movzx  edx,dl
  410d86:	vcvtsi2sd xmm0,xmm0,rdx
  410d8b:	vsubsd xmm0,xmm1,xmm0
  410d8f:	vmulsd xmm1,xmm0,xmm15
  410d94:	vcvttsd2si rdx,xmm1
  410d99:	add    dl,0x30
  410d9c:	mov    BYTE PTR [r9+0x11],dl
  410da0:	mov    BYTE PTR [r10+0x2],0x65
  410da5:	lea    r9,[r10+0x3]
  410da9:	test   r8,r8
  410dac:	jl     410db5 <__swc_fn_0a4ed24b_000146_d2097256+0x695>
  410dae:	mov    BYTE PTR [r9],0x2b
  410db2:	inc    r9
  410db5:	mov    r10,r9
  410db8:	mov    rdx,r8
  410dbb:	nop    DWORD PTR [rax+rax*1+0x0]
  410dc0:	mov    r11,rdx
  410dc3:	movabs rdx,0x6666666666666667
  410dcd:	mov    rax,r11
  410dd0:	imul   rdx
  410dd3:	sar    rdx,0x2
  410dd7:	mov    r12,rdx
  410dda:	shr    rdx,0x3f
  410dde:	add    r12,rdx
  410de1:	mov    rdx,r12
  410de4:	imul   r13,r12,0xa
  410de8:	sub    r11,r13
  410deb:	mov    r13,QWORD PTR [rip+0x274e]        # 413540 <__swc_rdata_base_0a4ed24b+0x430>
  410df2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410df7:	mov    BYTE PTR [r10],r11b
  410dfa:	lea    r11,[r10+0x1]
  410dfe:	mov    r10,r11
  410e01:	test   r12,r12
  410e04:	jne    410dc0 <__swc_fn_0a4ed24b_000146_d2097256+0x6a0>
  410e06:	test   r8,r8
  410e09:	jge    410e13 <__swc_fn_0a4ed24b_000146_d2097256+0x6f3>
  410e0b:	mov    BYTE PTR [r11],0x2d
  410e0f:	lea    r10,[r11+0x1]
  410e13:	mov    BYTE PTR [r10],0x0
  410e17:	sub    r10,0x1
  410e1b:	nop    DWORD PTR [rax+rax*1+0x0]
  410e20:	cmp    r9,r10
  410e23:	jae    411078 <__swc_fn_0a4ed24b_000146_d2097256+0x958>
  410e29:	mov    al,BYTE PTR [r10]
  410e2c:	mov    dl,BYTE PTR [r9]
  410e2f:	mov    BYTE PTR [r10],dl
  410e32:	sub    r10,0x1
  410e36:	mov    BYTE PTR [r9],al
  410e39:	inc    r9
  410e3c:	jmp    410e20 <__swc_fn_0a4ed24b_000146_d2097256+0x700>
  410e3e:	vcvttsd2si rdx,xmm1
  410e43:	mov    r8,rdx
  410e46:	vxorpd xmm0,xmm0,xmm0
  410e4a:	vcvtsi2sd xmm0,xmm0,rdx
  410e4f:	vsubsd xmm0,xmm1,xmm0
  410e53:	mov    r9d,0x8
  410e59:	vxorpd xmm2,xmm2,xmm2
  410e5d:	vcomisd xmm2,xmm0
  410e61:	jbe    410e6b <__swc_fn_0a4ed24b_000146_d2097256+0x74b>
  410e63:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x26e5]        # 413550 <__swc_rdata_base_0a4ed24b+0x440>
  410e6b:	test   r9d,r9d
  410e6e:	je     410e7a <__swc_fn_0a4ed24b_000146_d2097256+0x75a>
  410e70:	vmulsd xmm0,xmm0,xmm14
  410e75:	dec    r9d
  410e78:	jne    410e70 <__swc_fn_0a4ed24b_000146_d2097256+0x750>
  410e7a:	vcvttsd2si r9,xmm0
  410e7f:	mov    r10,r9
  410e82:	vxorpd xmm2,xmm2,xmm2
  410e86:	vcvtsi2sd xmm2,xmm2,r9
  410e8b:	vsubsd xmm0,xmm0,xmm2
  410e8f:	vcomisd xmm0,xmm10
  410e94:	lea    r9,[r9+0x1]
  410e98:	cmova  r10,r9
  410e9c:	cmp    r10,0x5f5e100
  410ea3:	jne    410ebc <__swc_fn_0a4ed24b_000146_d2097256+0x79c>
  410ea5:	lea    r8,[rdx-0x1]
  410ea9:	vxorpd xmm0,xmm0,xmm0
  410ead:	vcomisd xmm0,xmm1
  410eb1:	lea    rdx,[rdx+0x1]
  410eb5:	cmovbe r8,rdx
  410eb9:	xor    r10d,r10d
  410ebc:	mov    r9,rcx
  410ebf:	test   r8,r8
  410ec2:	jne    410ee2 <__swc_fn_0a4ed24b_000146_d2097256+0x7c2>
  410ec4:	vxorpd xmm0,xmm0,xmm0
  410ec8:	vcomisd xmm0,xmm1
  410ecc:	jbe    410ed5 <__swc_fn_0a4ed24b_000146_d2097256+0x7b5>
  410ece:	mov    BYTE PTR [rcx],0x2d
  410ed1:	lea    r9,[rcx+0x1]
  410ed5:	mov    BYTE PTR [r9],0x30
  410ed9:	add    r9,0x1
  410edd:	jmp    410f7b <__swc_fn_0a4ed24b_000146_d2097256+0x85b>
  410ee2:	mov    r9,rcx
  410ee5:	mov    rdx,r8
  410ee8:	nop    DWORD PTR [rax+rax*1+0x0]
  410ef0:	mov    r11,rdx
  410ef3:	movabs rdx,0x6666666666666667
  410efd:	mov    r15,rax
  410f00:	mov    rax,r11
  410f03:	imul   rdx
  410f06:	mov    r12,rdx
  410f09:	mov    rax,r15
  410f0c:	sar    r12,0x2
  410f10:	mov    rdx,r12
  410f13:	shr    rdx,0x3f
  410f17:	add    r12,rdx
  410f1a:	mov    rdx,r12
  410f1d:	imul   r13,r12,0xa
  410f21:	sub    r11,r13
  410f24:	mov    r13,QWORD PTR [rip+0x2615]        # 413540 <__swc_rdata_base_0a4ed24b+0x430>
  410f2b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410f30:	mov    BYTE PTR [r9],r11b
  410f33:	lea    r11,[r9+0x1]
  410f37:	mov    r9,r11
  410f3a:	test   r12,r12
  410f3d:	jne    410ef0 <__swc_fn_0a4ed24b_000146_d2097256+0x7d0>
  410f3f:	test   r8,r8
  410f42:	jge    410f4c <__swc_fn_0a4ed24b_000146_d2097256+0x82c>
  410f44:	mov    BYTE PTR [r11],0x2d
  410f48:	lea    r9,[r11+0x1]
  410f4c:	mov    rdx,r9
  410f4f:	mov    BYTE PTR [r9],0x0
  410f53:	sub    r9,0x1
  410f57:	mov    r8,rcx
  410f5a:	cmp    r8,r9
  410f5d:	jae    410f78 <__swc_fn_0a4ed24b_000146_d2097256+0x858>
  410f5f:	nop
  410f60:	mov    r11b,BYTE PTR [r9]
  410f63:	mov    r12b,BYTE PTR [r8]
  410f66:	mov    BYTE PTR [r9],r12b
  410f69:	sub    r9,0x1
  410f6d:	mov    BYTE PTR [r8],r11b
  410f70:	inc    r8
  410f73:	cmp    r8,r9
  410f76:	jb     410f60 <__swc_fn_0a4ed24b_000146_d2097256+0x840>
  410f78:	mov    r9,rdx
  410f7b:	mov    BYTE PTR [r9],0x2e
  410f7f:	add    r9,0x1
  410f83:	xor    r8d,r8d
  410f86:	test   r10,r10
  410f89:	je     410fcf <__swc_fn_0a4ed24b_000146_d2097256+0x8af>
  410f8b:	mov    r11d,0x989680
  410f91:	cmp    r10,r11
  410f94:	jge    410fcf <__swc_fn_0a4ed24b_000146_d2097256+0x8af>
  410f96:	cs nop WORD PTR [rax+rax*1+0x0]
  410fa0:	inc    r8d
  410fa3:	movabs rdx,0x6666666666666667
  410fad:	mov    r15,rax
  410fb0:	mov    rax,r11
  410fb3:	imul   rdx
  410fb6:	mov    r11,rdx
  410fb9:	mov    rax,r15
  410fbc:	sar    r11,0x2
  410fc0:	mov    rdx,r11
  410fc3:	shr    rdx,0x3f
  410fc7:	add    r11,rdx
  410fca:	cmp    r10,r11
  410fcd:	jl     410fa0 <__swc_fn_0a4ed24b_000146_d2097256+0x880>
  410fcf:	test   r8d,r8d
  410fd2:	je     410fed <__swc_fn_0a4ed24b_000146_d2097256+0x8cd>
  410fd4:	cs nop WORD PTR [rax+rax*1+0x0]
  410fde:	xchg   ax,ax
  410fe0:	mov    BYTE PTR [r9],0x30
  410fe4:	add    r9,0x1
  410fe8:	dec    r8d
  410feb:	jne    410fe0 <__swc_fn_0a4ed24b_000146_d2097256+0x8c0>
  410fed:	mov    r8,r9
  410ff0:	mov    rdx,r10
  410ff3:	cs nop WORD PTR [rax+rax*1+0x0]
  410ffd:	nop    DWORD PTR [rax]
  411000:	mov    r11,rdx
  411003:	movabs rdx,0x6666666666666667
  41100d:	mov    rax,r11
  411010:	imul   rdx
  411013:	sar    rdx,0x2
  411017:	mov    r12,rdx
  41101a:	shr    rdx,0x3f
  41101e:	add    r12,rdx
  411021:	mov    rdx,r12
  411024:	imul   r13,r12,0xa
  411028:	sub    r11,r13
  41102b:	mov    r13,QWORD PTR [rip+0x250e]        # 413540 <__swc_rdata_base_0a4ed24b+0x430>
  411032:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411037:	mov    BYTE PTR [r8],r11b
  41103a:	lea    r11,[r8+0x1]
  41103e:	mov    r8,r11
  411041:	test   r12,r12
  411044:	jne    411000 <__swc_fn_0a4ed24b_000146_d2097256+0x8e0>
  411046:	test   r10,r10
  411049:	jge    411053 <__swc_fn_0a4ed24b_000146_d2097256+0x933>
  41104b:	mov    BYTE PTR [r11],0x2d
  41104f:	lea    r8,[r11+0x1]
  411053:	mov    BYTE PTR [r8],0x0
  411057:	sub    r8,0x1
  41105b:	cmp    r9,r8
  41105e:	jae    411078 <__swc_fn_0a4ed24b_000146_d2097256+0x958>
  411060:	mov    al,BYTE PTR [r8]
  411063:	mov    dl,BYTE PTR [r9]
  411066:	mov    BYTE PTR [r8],dl
  411069:	sub    r8,0x1
  41106d:	mov    BYTE PTR [r9],al
  411070:	inc    r9
  411073:	cmp    r9,r8
  411076:	jb     411060 <__swc_fn_0a4ed24b_000146_d2097256+0x940>
  411078:	xor    eax,eax
  41107a:	test   rcx,rcx
  41107d:	je     4110b0 <__swc_fn_0a4ed24b_000146_d2097256+0x990>
  41107f:	mov    rdx,rcx
  411082:	mov    r8b,BYTE PTR [rdx]
  411085:	test   r8b,r8b
  411088:	je     4110b0 <__swc_fn_0a4ed24b_000146_d2097256+0x990>
  41108a:	cs nop WORD PTR [rax+rax*1+0x0]
  411094:	cs nop WORD PTR [rax+rax*1+0x0]
  41109e:	xchg   ax,ax
  4110a0:	add    rdx,0x1
  4110a4:	add    rax,0x1
  4110a8:	mov    r8b,BYTE PTR [rdx]
  4110ab:	test   r8b,r8b
  4110ae:	jne    4110a0 <__swc_fn_0a4ed24b_000146_d2097256+0x980>
  4110b0:	mov    QWORD PTR [rsp+0x240],rcx
  4110b8:	mov    QWORD PTR [rsp+0x248],rax
  4110c0:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  4110c9:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  4110d2:	lea    rcx,[rsp+0x250]
  4110da:	call   40feb0 <__swc_fn_0a4ed24b_000116_3f5cfdef>
  4110df:	jmp    4117e5 <__swc_fn_0a4ed24b_000146_d2097256+0x10c5>
  4110e4:	lea    rcx,[rsp+0x260]
  4110ec:	vxorps xmm0,xmm0,xmm0
  4110f0:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  4110f9:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  411102:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  41110b:	vzeroupper
  41110e:	mov    DWORD PTR [rsp+0x2c0],0x0
  411119:	vmovsd xmm0,QWORD PTR [rdx]
  41111d:	vcomisd xmm0,xmm0
  411121:	setne  dl
  411124:	movzx  edx,dl
  411127:	setp   r8b
  41112b:	movzx  r8d,r8b
  41112f:	or     edx,r8d
  411132:	test   dl,dl
  411134:	je     411141 <__swc_fn_0a4ed24b_000146_d2097256+0xa21>
  411136:	mov    DWORD PTR [rcx],0x6e616e
  41113c:	jmp    411748 <__swc_fn_0a4ed24b_000146_d2097256+0x1028>
  411141:	vcomisd xmm0,xmm11
  411146:	ja     411157 <__swc_fn_0a4ed24b_000146_d2097256+0xa37>
  411148:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  411151:	vcomisd xmm6,xmm0
  411155:	jbe    41117b <__swc_fn_0a4ed24b_000146_d2097256+0xa5b>
  411157:	vxorpd xmm1,xmm1,xmm1
  41115b:	vcomisd xmm1,xmm0
  41115f:	jbe    411170 <__swc_fn_0a4ed24b_000146_d2097256+0xa50>
  411161:	mov    DWORD PTR [rcx],0x666e692d
  411167:	mov    BYTE PTR [rcx+0x4],0x0
  41116b:	jmp    411748 <__swc_fn_0a4ed24b_000146_d2097256+0x1028>
  411170:	mov    DWORD PTR [rcx],0x666e69
  411176:	jmp    411748 <__swc_fn_0a4ed24b_000146_d2097256+0x1028>
  41117b:	vcomisd xmm0,xmm13
  411180:	jae    41118c <__swc_fn_0a4ed24b_000146_d2097256+0xa6c>
  411182:	vcomisd xmm12,xmm0
  411186:	jbe    4114ee <__swc_fn_0a4ed24b_000146_d2097256+0xdce>
  41118c:	vmovups xmm1,xmm0
  411190:	vxorpd xmm2,xmm2,xmm2
  411194:	vcomisd xmm2,xmm0
  411198:	jbe    4111a8 <__swc_fn_0a4ed24b_000146_d2097256+0xa88>
  41119a:	vmovsd xmm0,xmm0,xmm1
  41119e:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x23aa]        # 413550 <__swc_rdata_base_0a4ed24b+0x440>
  4111a6:	jmp    4111ac <__swc_fn_0a4ed24b_000146_d2097256+0xa8c>
  4111a8:	vmovsd xmm0,xmm0,xmm1
  4111ac:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  4111b5:	xor    r8d,r8d
  4111b8:	vcomisd xmm0,xmm6
  4111bc:	jb     4111ce <__swc_fn_0a4ed24b_000146_d2097256+0xaae>
  4111be:	xchg   ax,ax
  4111c0:	vdivsd xmm0,xmm0,xmm6
  4111c4:	add    r8,0x1
  4111c8:	vcomisd xmm0,xmm6
  4111cc:	jae    4111c0 <__swc_fn_0a4ed24b_000146_d2097256+0xaa0>
  4111ce:	mov    r9,rcx
  4111d1:	vxorpd xmm2,xmm2,xmm2
  4111d5:	vcomisd xmm2,xmm1
  4111d9:	jbe    4111e2 <__swc_fn_0a4ed24b_000146_d2097256+0xac2>
  4111db:	mov    BYTE PTR [rcx],0x2d
  4111de:	lea    r9,[rcx+0x1]
  4111e2:	vcvttsd2si rdx,xmm0
  4111e7:	mov    r10b,dl
  4111ea:	add    r10b,0x30
  4111ee:	mov    BYTE PTR [r9],r10b
  4111f1:	vxorpd xmm1,xmm1,xmm1
  4111f5:	movzx  edx,dl
  4111f8:	vcvtsi2sd xmm1,xmm1,rdx
  4111fd:	vsubsd xmm0,xmm0,xmm1
  411201:	vmulsd xmm0,xmm0,xmm6
  411205:	mov    BYTE PTR [r9+0x1],0x2e
  41120a:	vcvttsd2si rdx,xmm0
  41120f:	mov    r10b,dl
  411212:	add    r10b,0x30
  411216:	mov    BYTE PTR [r9+0x2],r10b
  41121a:	vxorpd xmm1,xmm1,xmm1
  41121e:	movzx  edx,dl
  411221:	vcvtsi2sd xmm1,xmm1,rdx
  411226:	vsubsd xmm0,xmm0,xmm1
  41122a:	vmulsd xmm0,xmm0,xmm6
  41122e:	vcvttsd2si rdx,xmm0
  411233:	mov    r10b,dl
  411236:	add    r10b,0x30
  41123a:	mov    BYTE PTR [r9+0x3],r10b
  41123e:	vxorpd xmm1,xmm1,xmm1
  411242:	movzx  edx,dl
  411245:	vcvtsi2sd xmm1,xmm1,rdx
  41124a:	vsubsd xmm0,xmm0,xmm1
  41124e:	vmulsd xmm0,xmm0,xmm6
  411252:	vcvttsd2si rdx,xmm0
  411257:	mov    r10b,dl
  41125a:	add    r10b,0x30
  41125e:	mov    BYTE PTR [r9+0x4],r10b
  411262:	vxorpd xmm1,xmm1,xmm1
  411266:	movzx  edx,dl
  411269:	vcvtsi2sd xmm1,xmm1,rdx
  41126e:	vsubsd xmm0,xmm0,xmm1
  411272:	vmulsd xmm0,xmm0,xmm6
  411276:	vcvttsd2si rdx,xmm0
  41127b:	mov    r10b,dl
  41127e:	add    r10b,0x30
  411282:	mov    BYTE PTR [r9+0x5],r10b
  411286:	vxorpd xmm1,xmm1,xmm1
  41128a:	movzx  edx,dl
  41128d:	vcvtsi2sd xmm1,xmm1,rdx
  411292:	vsubsd xmm0,xmm0,xmm1
  411296:	vmulsd xmm0,xmm0,xmm6
  41129a:	vcvttsd2si rdx,xmm0
  41129f:	mov    r10b,dl
  4112a2:	add    r10b,0x30
  4112a6:	mov    BYTE PTR [r9+0x6],r10b
  4112aa:	vxorpd xmm1,xmm1,xmm1
  4112ae:	movzx  edx,dl
  4112b1:	vcvtsi2sd xmm1,xmm1,rdx
  4112b6:	vsubsd xmm0,xmm0,xmm1
  4112ba:	vmulsd xmm0,xmm0,xmm6
  4112be:	vcvttsd2si rdx,xmm0
  4112c3:	mov    r10b,dl
  4112c6:	add    r10b,0x30
  4112ca:	mov    BYTE PTR [r9+0x7],r10b
  4112ce:	vxorpd xmm1,xmm1,xmm1
  4112d2:	movzx  edx,dl
  4112d5:	vcvtsi2sd xmm1,xmm1,rdx
  4112da:	vsubsd xmm0,xmm0,xmm1
  4112de:	vmulsd xmm0,xmm0,xmm6
  4112e2:	vcvttsd2si rdx,xmm0
  4112e7:	mov    r10b,dl
  4112ea:	add    r10b,0x30
  4112ee:	mov    BYTE PTR [r9+0x8],r10b
  4112f2:	vxorpd xmm1,xmm1,xmm1
  4112f6:	movzx  edx,dl
  4112f9:	vcvtsi2sd xmm1,xmm1,rdx
  4112fe:	vsubsd xmm0,xmm0,xmm1
  411302:	vmulsd xmm0,xmm0,xmm6
  411306:	vcvttsd2si rdx,xmm0
  41130b:	mov    r10b,dl
  41130e:	add    r10b,0x30
  411312:	mov    BYTE PTR [r9+0x9],r10b
  411316:	vxorpd xmm1,xmm1,xmm1
  41131a:	movzx  edx,dl
  41131d:	vcvtsi2sd xmm1,xmm1,rdx
  411322:	vsubsd xmm0,xmm0,xmm1
  411326:	vmulsd xmm0,xmm0,xmm6
  41132a:	vcvttsd2si rdx,xmm0
  41132f:	mov    r10b,dl
  411332:	add    r10b,0x30
  411336:	mov    BYTE PTR [r9+0xa],r10b
  41133a:	vxorpd xmm1,xmm1,xmm1
  41133e:	movzx  edx,dl
  411341:	vcvtsi2sd xmm1,xmm1,rdx
  411346:	vsubsd xmm0,xmm0,xmm1
  41134a:	vmulsd xmm0,xmm0,xmm6
  41134e:	vcvttsd2si rdx,xmm0
  411353:	mov    r10b,dl
  411356:	add    r10b,0x30
  41135a:	mov    BYTE PTR [r9+0xb],r10b
  41135e:	lea    r10,[r9+0x4]
  411362:	vxorpd xmm1,xmm1,xmm1
  411366:	movzx  edx,dl
  411369:	vcvtsi2sd xmm1,xmm1,rdx
  41136e:	vsubsd xmm0,xmm0,xmm1
  411372:	vmulsd xmm0,xmm0,xmm6
  411376:	vcvttsd2si rdx,xmm0
  41137b:	mov    r11b,dl
  41137e:	add    r11b,0x30
  411382:	mov    BYTE PTR [r9+0xc],r11b
  411386:	vxorpd xmm1,xmm1,xmm1
  41138a:	movzx  edx,dl
  41138d:	vcvtsi2sd xmm1,xmm1,rdx
  411392:	vsubsd xmm0,xmm0,xmm1
  411396:	vmulsd xmm0,xmm0,xmm6
  41139a:	vcvttsd2si rdx,xmm0
  41139f:	mov    r11b,dl
  4113a2:	add    r11b,0x30
  4113a6:	mov    BYTE PTR [r9+0xd],r11b
  4113aa:	lea    r10,[r10+0x2]
  4113ae:	vxorpd xmm1,xmm1,xmm1
  4113b2:	movzx  edx,dl
  4113b5:	vcvtsi2sd xmm1,xmm1,rdx
  4113ba:	vsubsd xmm0,xmm0,xmm1
  4113be:	vmulsd xmm0,xmm0,xmm6
  4113c2:	vcvttsd2si rdx,xmm0
  4113c7:	mov    r11b,dl
  4113ca:	add    r11b,0x30
  4113ce:	mov    BYTE PTR [r9+0xe],r11b
  4113d2:	vxorpd xmm1,xmm1,xmm1
  4113d6:	movzx  edx,dl
  4113d9:	vcvtsi2sd xmm1,xmm1,rdx
  4113de:	vsubsd xmm0,xmm0,xmm1
  4113e2:	vmulsd xmm0,xmm0,xmm6
  4113e6:	vcvttsd2si rdx,xmm0
  4113eb:	mov    r11b,dl
  4113ee:	add    r11b,0x30
  4113f2:	mov    BYTE PTR [r9+0xf],r11b
  4113f6:	lea    r10,[r10+0x2]
  4113fa:	lea    r10,[r10+0x2]
  4113fe:	lea    r10,[r10+0x2]
  411402:	lea    r10,[r10+0x2]
  411406:	lea    r10,[r10+0x2]
  41140a:	vxorpd xmm1,xmm1,xmm1
  41140e:	movzx  edx,dl
  411411:	vcvtsi2sd xmm1,xmm1,rdx
  411416:	vsubsd xmm0,xmm0,xmm1
  41141a:	vmulsd xmm0,xmm0,xmm6
  41141e:	vcvttsd2si rdx,xmm0
  411423:	mov    r11b,dl
  411426:	add    r11b,0x30
  41142a:	mov    BYTE PTR [r9+0x10],r11b
  41142e:	vxorpd xmm1,xmm1,xmm1
  411432:	movzx  edx,dl
  411435:	vcvtsi2sd xmm1,xmm1,rdx
  41143a:	vsubsd xmm0,xmm0,xmm1
  41143e:	vmulsd xmm0,xmm0,xmm6
  411442:	vcvttsd2si rdx,xmm0
  411447:	add    dl,0x30
  41144a:	mov    BYTE PTR [r9+0x11],dl
  41144e:	mov    BYTE PTR [r10+0x2],0x65
  411453:	lea    r9,[r10+0x3]
  411457:	test   r8,r8
  41145a:	jl     411463 <__swc_fn_0a4ed24b_000146_d2097256+0xd43>
  41145c:	mov    BYTE PTR [r9],0x2b
  411460:	inc    r9
  411463:	mov    r10,r9
  411466:	mov    rdx,r8
  411469:	nop    DWORD PTR [rax+0x0]
  411470:	mov    r11,rdx
  411473:	movabs rdx,0x6666666666666667
  41147d:	mov    rax,r11
  411480:	imul   rdx
  411483:	sar    rdx,0x2
  411487:	mov    r12,rdx
  41148a:	shr    rdx,0x3f
  41148e:	add    r12,rdx
  411491:	mov    rdx,r12
  411494:	imul   r13,r12,0xa
  411498:	sub    r11,r13
  41149b:	mov    r13,QWORD PTR [rip+0x209e]        # 413540 <__swc_rdata_base_0a4ed24b+0x430>
  4114a2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4114a7:	mov    BYTE PTR [r10],r11b
  4114aa:	lea    r11,[r10+0x1]
  4114ae:	mov    r10,r11
  4114b1:	test   r12,r12
  4114b4:	jne    411470 <__swc_fn_0a4ed24b_000146_d2097256+0xd50>
  4114b6:	test   r8,r8
  4114b9:	jge    4114c3 <__swc_fn_0a4ed24b_000146_d2097256+0xda3>
  4114bb:	mov    BYTE PTR [r11],0x2d
  4114bf:	lea    r10,[r11+0x1]
  4114c3:	mov    BYTE PTR [r10],0x0
  4114c7:	sub    r10,0x1
  4114cb:	nop    DWORD PTR [rax+rax*1+0x0]
  4114d0:	cmp    r9,r10
  4114d3:	jae    411748 <__swc_fn_0a4ed24b_000146_d2097256+0x1028>
  4114d9:	mov    al,BYTE PTR [r10]
  4114dc:	mov    dl,BYTE PTR [r9]
  4114df:	mov    BYTE PTR [r10],dl
  4114e2:	sub    r10,0x1
  4114e6:	mov    BYTE PTR [r9],al
  4114e9:	inc    r9
  4114ec:	jmp    4114d0 <__swc_fn_0a4ed24b_000146_d2097256+0xdb0>
  4114ee:	vcvttsd2si rdx,xmm0
  4114f3:	mov    r8,rdx
  4114f6:	vxorpd xmm1,xmm1,xmm1
  4114fa:	vcvtsi2sd xmm1,xmm1,rdx
  4114ff:	vsubsd xmm1,xmm0,xmm1
  411503:	mov    r9d,0x8
  411509:	vxorpd xmm2,xmm2,xmm2
  41150d:	vcomisd xmm2,xmm1
  411511:	ja     41151e <__swc_fn_0a4ed24b_000146_d2097256+0xdfe>
  411513:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41151c:	jmp    41152f <__swc_fn_0a4ed24b_000146_d2097256+0xe0f>
  41151e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x202a]        # 413550 <__swc_rdata_base_0a4ed24b+0x440>
  411526:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41152f:	test   r9d,r9d
  411532:	je     411549 <__swc_fn_0a4ed24b_000146_d2097256+0xe29>
  411534:	cs nop WORD PTR [rax+rax*1+0x0]
  41153e:	xchg   ax,ax
  411540:	vmulsd xmm1,xmm1,xmm6
  411544:	dec    r9d
  411547:	jne    411540 <__swc_fn_0a4ed24b_000146_d2097256+0xe20>
  411549:	vcvttsd2si r9,xmm1
  41154e:	mov    r10,r9
  411551:	vxorpd xmm2,xmm2,xmm2
  411555:	vcvtsi2sd xmm2,xmm2,r9
  41155a:	vsubsd xmm1,xmm1,xmm2
  41155e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  411567:	vcomisd xmm1,xmm6
  41156b:	lea    r9,[r9+0x1]
  41156f:	cmova  r10,r9
  411573:	cmp    r10,0x5f5e100
  41157a:	jne    411593 <__swc_fn_0a4ed24b_000146_d2097256+0xe73>
  41157c:	lea    r8,[rdx-0x1]
  411580:	vxorpd xmm1,xmm1,xmm1
  411584:	vcomisd xmm1,xmm0
  411588:	lea    rdx,[rdx+0x1]
  41158c:	cmovbe r8,rdx
  411590:	xor    r10d,r10d
  411593:	mov    r9,rcx
  411596:	test   r8,r8
  411599:	jne    4115b9 <__swc_fn_0a4ed24b_000146_d2097256+0xe99>
  41159b:	vxorpd xmm1,xmm1,xmm1
  41159f:	vcomisd xmm1,xmm0
  4115a3:	jbe    4115ac <__swc_fn_0a4ed24b_000146_d2097256+0xe8c>
  4115a5:	mov    BYTE PTR [rcx],0x2d
  4115a8:	lea    r9,[rcx+0x1]
  4115ac:	mov    BYTE PTR [r9],0x30
  4115b0:	add    r9,0x1
  4115b4:	jmp    41164b <__swc_fn_0a4ed24b_000146_d2097256+0xf2b>
  4115b9:	mov    r9,rcx
  4115bc:	mov    rdx,r8
  4115bf:	nop
  4115c0:	mov    r11,rdx
  4115c3:	movabs rdx,0x6666666666666667
  4115cd:	mov    r15,rax
  4115d0:	mov    rax,r11
  4115d3:	imul   rdx
  4115d6:	mov    r12,rdx
  4115d9:	mov    rax,r15
  4115dc:	sar    r12,0x2
  4115e0:	mov    rdx,r12
  4115e3:	shr    rdx,0x3f
  4115e7:	add    r12,rdx
  4115ea:	mov    rdx,r12
  4115ed:	imul   r13,r12,0xa
  4115f1:	sub    r11,r13
  4115f4:	mov    r13,QWORD PTR [rip+0x1f45]        # 413540 <__swc_rdata_base_0a4ed24b+0x430>
  4115fb:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411600:	mov    BYTE PTR [r9],r11b
  411603:	lea    r11,[r9+0x1]
  411607:	mov    r9,r11
  41160a:	test   r12,r12
  41160d:	jne    4115c0 <__swc_fn_0a4ed24b_000146_d2097256+0xea0>
  41160f:	test   r8,r8
  411612:	jge    41161c <__swc_fn_0a4ed24b_000146_d2097256+0xefc>
  411614:	mov    BYTE PTR [r11],0x2d
  411618:	lea    r9,[r11+0x1]
  41161c:	mov    rdx,r9
  41161f:	mov    BYTE PTR [r9],0x0
  411623:	sub    r9,0x1
  411627:	mov    r8,rcx
  41162a:	cmp    r8,r9
  41162d:	jae    411648 <__swc_fn_0a4ed24b_000146_d2097256+0xf28>
  41162f:	nop
  411630:	mov    r11b,BYTE PTR [r9]
  411633:	mov    r12b,BYTE PTR [r8]
  411636:	mov    BYTE PTR [r9],r12b
  411639:	sub    r9,0x1
  41163d:	mov    BYTE PTR [r8],r11b
  411640:	inc    r8
  411643:	cmp    r8,r9
  411646:	jb     411630 <__swc_fn_0a4ed24b_000146_d2097256+0xf10>
  411648:	mov    r9,rdx
  41164b:	mov    BYTE PTR [r9],0x2e
  41164f:	add    r9,0x1
  411653:	xor    r8d,r8d
  411656:	test   r10,r10
  411659:	je     41169f <__swc_fn_0a4ed24b_000146_d2097256+0xf7f>
  41165b:	mov    r11d,0x989680
  411661:	cmp    r10,r11
  411664:	jge    41169f <__swc_fn_0a4ed24b_000146_d2097256+0xf7f>
  411666:	cs nop WORD PTR [rax+rax*1+0x0]
  411670:	inc    r8d
  411673:	movabs rdx,0x6666666666666667
  41167d:	mov    r15,rax
  411680:	mov    rax,r11
  411683:	imul   rdx
  411686:	mov    r11,rdx
  411689:	mov    rax,r15
  41168c:	sar    r11,0x2
  411690:	mov    rdx,r11
  411693:	shr    rdx,0x3f
  411697:	add    r11,rdx
  41169a:	cmp    r10,r11
  41169d:	jl     411670 <__swc_fn_0a4ed24b_000146_d2097256+0xf50>
  41169f:	test   r8d,r8d
  4116a2:	je     4116bd <__swc_fn_0a4ed24b_000146_d2097256+0xf9d>
  4116a4:	cs nop WORD PTR [rax+rax*1+0x0]
  4116ae:	xchg   ax,ax
  4116b0:	mov    BYTE PTR [r9],0x30
  4116b4:	add    r9,0x1
  4116b8:	dec    r8d
  4116bb:	jne    4116b0 <__swc_fn_0a4ed24b_000146_d2097256+0xf90>
  4116bd:	mov    r8,r9
  4116c0:	mov    rdx,r10
  4116c3:	cs nop WORD PTR [rax+rax*1+0x0]
  4116cd:	nop    DWORD PTR [rax]
  4116d0:	mov    r11,rdx
  4116d3:	movabs rdx,0x6666666666666667
  4116dd:	mov    rax,r11
  4116e0:	imul   rdx
  4116e3:	sar    rdx,0x2
  4116e7:	mov    r12,rdx
  4116ea:	shr    rdx,0x3f
  4116ee:	add    r12,rdx
  4116f1:	mov    rdx,r12
  4116f4:	imul   r13,r12,0xa
  4116f8:	sub    r11,r13
  4116fb:	mov    r13,QWORD PTR [rip+0x1e3e]        # 413540 <__swc_rdata_base_0a4ed24b+0x430>
  411702:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411707:	mov    BYTE PTR [r8],r11b
  41170a:	lea    r11,[r8+0x1]
  41170e:	mov    r8,r11
  411711:	test   r12,r12
  411714:	jne    4116d0 <__swc_fn_0a4ed24b_000146_d2097256+0xfb0>
  411716:	test   r10,r10
  411719:	jge    411723 <__swc_fn_0a4ed24b_000146_d2097256+0x1003>
  41171b:	mov    BYTE PTR [r11],0x2d
  41171f:	lea    r8,[r11+0x1]
  411723:	mov    BYTE PTR [r8],0x0
  411727:	sub    r8,0x1
  41172b:	cmp    r9,r8
  41172e:	jae    411748 <__swc_fn_0a4ed24b_000146_d2097256+0x1028>
  411730:	mov    al,BYTE PTR [r8]
  411733:	mov    dl,BYTE PTR [r9]
  411736:	mov    BYTE PTR [r8],dl
  411739:	sub    r8,0x1
  41173d:	mov    BYTE PTR [r9],al
  411740:	inc    r9
  411743:	cmp    r9,r8
  411746:	jb     411730 <__swc_fn_0a4ed24b_000146_d2097256+0x1010>
  411748:	xor    eax,eax
  41174a:	test   rcx,rcx
  41174d:	je     411770 <__swc_fn_0a4ed24b_000146_d2097256+0x1050>
  41174f:	mov    rdx,rcx
  411752:	mov    r8b,BYTE PTR [rdx]
  411755:	test   r8b,r8b
  411758:	je     411770 <__swc_fn_0a4ed24b_000146_d2097256+0x1050>
  41175a:	nop    WORD PTR [rax+rax*1+0x0]
  411760:	add    rdx,0x1
  411764:	add    rax,0x1
  411768:	mov    r8b,BYTE PTR [rdx]
  41176b:	test   r8b,r8b
  41176e:	jne    411760 <__swc_fn_0a4ed24b_000146_d2097256+0x1040>
  411770:	mov    QWORD PTR [rsp+0x3f8],rcx
  411778:	mov    QWORD PTR [rsp+0x400],rax
  411780:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  411789:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  411792:	lea    rcx,[rsp+0x408]
  41179a:	call   40feb0 <__swc_fn_0a4ed24b_000116_3f5cfdef>
  41179f:	jmp    4117e5 <__swc_fn_0a4ed24b_000146_d2097256+0x10c5>
  4117a1:	mov    rcx,rdx
  4117a4:	call   40feb0 <__swc_fn_0a4ed24b_000116_3f5cfdef>
  4117a9:	jmp    4117e5 <__swc_fn_0a4ed24b_000146_d2097256+0x10c5>
  4117ab:	mov    al,BYTE PTR [rdx]
  4117ad:	test   al,al
  4117af:	je     4117ba <__swc_fn_0a4ed24b_000146_d2097256+0x109a>
  4117b1:	lea    rax,[rip+0x1da8]        # 413560 <__swc_rdata_base_0a4ed24b+0x450>
  4117b8:	jmp    4117c1 <__swc_fn_0a4ed24b_000146_d2097256+0x10a1>
  4117ba:	lea    rax,[rip+0x1daf]        # 413570 <__swc_rdata_base_0a4ed24b+0x460>
  4117c1:	mov    rcx,rax
  4117c4:	call   40feb0 <__swc_fn_0a4ed24b_000116_3f5cfdef>
  4117c9:	jmp    4117e5 <__swc_fn_0a4ed24b_000146_d2097256+0x10c5>
  4117cb:	lea    rcx,[rip+0x1dae]        # 413580 <__swc_rdata_base_0a4ed24b+0x470>
  4117d2:	call   40feb0 <__swc_fn_0a4ed24b_000116_3f5cfdef>
  4117d7:	jmp    4117e5 <__swc_fn_0a4ed24b_000146_d2097256+0x10c5>
  4117d9:	lea    rcx,[rip+0x1da0]        # 413580 <__swc_rdata_base_0a4ed24b+0x470>
  4117e0:	call   40feb0 <__swc_fn_0a4ed24b_000116_3f5cfdef>
  4117e5:	add    rdi,0x1
  4117e9:	sub    rsi,0x1
  4117ed:	vmovups xmm0,xmm12
  4117f2:	vmovsd xmm6,QWORD PTR [rip+0x1d96]        # 413590 <__swc_rdata_base_0a4ed24b+0x480>
  4117fa:	test   rsi,rsi
  4117fd:	jne    410830 <__swc_fn_0a4ed24b_000146_d2097256+0x110>
  411803:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  41180c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  411815:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  41181e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411827:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411830:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411839:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411842:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  41184b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411854:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  41185d:	add    rsp,0x4e8
  411864:	pop    r15
  411866:	pop    r13
  411868:	pop    r12
  41186a:	pop    rdi
  41186b:	pop    rsi
  41186c:	pop    rbx
  41186d:	ret
	...

0000000000411870 <__swc_fn_0a4ed24b_000149_365b4daf>:
  411870:	vxorps xmm0,xmm0,xmm0
  411874:	vmovups XMMWORD PTR [rcx],xmm0
  411878:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41187d:	ret
	...

0000000000411880 <__swc_fn_0a4ed24b_000152_365b4daf>:
  411880:	vxorps xmm0,xmm0,xmm0
  411884:	vmovups XMMWORD PTR [rcx],xmm0
  411888:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41188d:	vxorps xmm0,xmm0,xmm0
  411891:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411896:	vmovups xmm0,XMMWORD PTR [rip+0x1e02]        # 4136a0 <__swc_rdata_base_0a4ed24b+0x590>
  41189e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4118a3:	vxorps xmm0,xmm0,xmm0
  4118a7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  4118ac:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  4118b1:	vxorps xmm0,xmm0,xmm0
  4118b5:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  4118ba:	mov    QWORD PTR [rcx+0x70],0x0
  4118c2:	ret
	...

00000000004118d0 <__swc_fn_0a4ed24b_000155_365b4daf>:
  4118d0:	vxorps xmm0,xmm0,xmm0
  4118d4:	vmovups XMMWORD PTR [rcx],xmm0
  4118d8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4118dd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4118e2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4118e7:	ret
	...

00000000004118f0 <__swc_fn_0a4ed24b_000158_31e09513>:
  4118f0:	push   rsi
  4118f1:	push   rdi
  4118f2:	sub    rsp,0x8
  4118f6:	mov    rsi,rcx
  4118f9:	mov    rdi,QWORD PTR [rsi+0x50]
  4118fd:	test   rdi,rdi
  411900:	je     411907 <__swc_fn_0a4ed24b_000158_31e09513+0x17>
  411902:	mov    rcx,rsi
  411905:	call   rdi
  411907:	mov    QWORD PTR [rsi+0x20],0x0
  41190f:	mov    rax,QWORD PTR [rsi+0x30]
  411913:	test   rax,rax
  411916:	je     411944 <__swc_fn_0a4ed24b_000158_31e09513+0x54>
  411918:	nop    DWORD PTR [rax+rax*1+0x0]
  411920:	mov    rdi,QWORD PTR [rax+0x8]
  411924:	mov    rcx,rsi
  411927:	mov    rdx,QWORD PTR [rax+0x10]
  41192b:	mov    rax,QWORD PTR [rax+0x18]
  41192f:	mov    r8,rax
  411932:	call   409e90 <__swc_fn_0a4ed24b_000156_9e2052d6>
  411937:	mov    QWORD PTR [rsi+0x30],rdi
  41193b:	mov    rax,QWORD PTR [rsi+0x30]
  41193f:	test   rax,rax
  411942:	jne    411920 <__swc_fn_0a4ed24b_000158_31e09513+0x30>
  411944:	mov    QWORD PTR [rsi+0x38],0x0
  41194c:	add    rsp,0x8
  411950:	pop    rdi
  411951:	pop    rsi
  411952:	ret
	...

0000000000411960 <__swc_fn_0a4ed24b_000161_b553c03d>:
  411960:	push   rbx
  411961:	push   rsi
  411962:	push   rdi
  411963:	push   r12
  411965:	sub    rsp,0x188
  41196c:	mov    rbx,rcx
  41196f:	lea    rsi,[rip+0x1541a]        # 426d90 <__swc_bss_base_0a4ed24b+0x2d50>
  411976:	mov    rcx,rsi
  411979:	call   4098a0 <__swc_fn_0a4ed24b_000135_db32cc57>
  41197e:	mov    rax,QWORD PTR [rip+0x15413]        # 426d98 <__swc_bss_base_0a4ed24b+0x2d58>
  411985:	mov    rdi,rax
  411988:	test   rdi,rdi
  41198b:	je     4119b9 <__swc_fn_0a4ed24b_000161_b553c03d+0x59>
  41198d:	nop    DWORD PTR [rax]
  411990:	cmp    QWORD PTR [rdi+0x8],rbx
  411994:	jne    4119ae <__swc_fn_0a4ed24b_000161_b553c03d+0x4e>
  411996:	mov    rcx,rsi
  411999:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  41199e:	mov    rax,rdi
  4119a1:	add    rsp,0x188
  4119a8:	pop    r12
  4119aa:	pop    rdi
  4119ab:	pop    rsi
  4119ac:	pop    rbx
  4119ad:	ret
  4119ae:	mov    rax,QWORD PTR [rdi]
  4119b1:	mov    rdi,rax
  4119b4:	test   rax,rax
  4119b7:	jne    411990 <__swc_fn_0a4ed24b_000161_b553c03d+0x30>
  4119b9:	call   40d0c0 <__swc_fn_0a4ed24b_000139_e4a7a8b1>
  4119be:	mov    rdi,rax
  4119c1:	test   rax,rax
  4119c4:	jne    4119dd <__swc_fn_0a4ed24b_000161_b553c03d+0x7d>
  4119c6:	mov    rcx,rsi
  4119c9:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  4119ce:	xor    eax,eax
  4119d0:	add    rsp,0x188
  4119d7:	pop    r12
  4119d9:	pop    rdi
  4119da:	pop    rsi
  4119db:	pop    rbx
  4119dc:	ret
  4119dd:	lea    rax,[rsp+0x18]
  4119e2:	mov    QWORD PTR [rax+0x10],0x0
  4119ea:	mov    QWORD PTR [rax+0x18],0x0
  4119f2:	mov    DWORD PTR [rax+0x20],0x0
  4119f9:	mov    BYTE PTR [rax+0x24],0x0
  4119fd:	mov    rax,QWORD PTR [rip+0x15394]        # 426d98 <__swc_bss_base_0a4ed24b+0x2d58>
  411a04:	mov    QWORD PTR [rsp+0x18],rax
  411a09:	mov    QWORD PTR [rsp+0x20],rbx
  411a0e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411a14:	vmovups XMMWORD PTR [rdi],xmm0
  411a18:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  411a1e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  411a23:	mov    rax,QWORD PTR [rsp+0x38]
  411a28:	mov    QWORD PTR [rdi+0x20],rax
  411a2c:	mov    QWORD PTR [rip+0x15365],rdi        # 426d98 <__swc_bss_base_0a4ed24b+0x2d58>
  411a33:	lea    rax,[rsp+0x40]
  411a38:	mov    QWORD PTR [rax],0x0
  411a3f:	mov    rcx,rbx
  411a42:	mov    rdx,rax
  411a45:	call   409980 <__swc_fn_0a4ed24b_000141_5e493395>
  411a4a:	mov    rbx,rax
  411a4d:	test   rax,rax
  411a50:	jne    411a6a <__swc_fn_0a4ed24b_000161_b553c03d+0x10a>
  411a52:	mov    rcx,rsi
  411a55:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  411a5a:	mov    rax,rdi
  411a5d:	add    rsp,0x188
  411a64:	pop    r12
  411a66:	pop    rdi
  411a67:	pop    rsi
  411a68:	pop    rbx
  411a69:	ret
  411a6a:	lea    r12,[rsp+0x50]
  411a6f:	mov    QWORD PTR [r12],0x0
  411a77:	mov    rcx,rbx
  411a7a:	mov    rdx,QWORD PTR [rsp+0x40]
  411a7f:	mov    r8,r12
  411a82:	call   40d170 <__swc_fn_0a4ed24b_000142_89a6ef72>
  411a87:	test   rax,rax
  411a8a:	jne    411aa4 <__swc_fn_0a4ed24b_000161_b553c03d+0x144>
  411a8c:	mov    rcx,rsi
  411a8f:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  411a94:	mov    rax,rdi
  411a97:	add    rsp,0x188
  411a9e:	pop    r12
  411aa0:	pop    rdi
  411aa1:	pop    rsi
  411aa2:	pop    rbx
  411aa3:	ret
  411aa4:	cmp    QWORD PTR [r12],0x10
  411aa9:	jb     411bac <__swc_fn_0a4ed24b_000161_b553c03d+0x24c>
  411aaf:	mov    ecx,DWORD PTR [rax]
  411ab1:	cmp    ecx,0x42445753
  411ab7:	jne    411bac <__swc_fn_0a4ed24b_000161_b553c03d+0x24c>
  411abd:	mov    ecx,DWORD PTR [rax+0x4]
  411ac0:	cmp    ecx,0x1
  411ac3:	jne    411bac <__swc_fn_0a4ed24b_000161_b553c03d+0x24c>
  411ac9:	mov    ecx,DWORD PTR [rax+0x8]
  411acc:	mov    edx,DWORD PTR [rax+0xc]
  411acf:	imul   r8,rcx,0x14
  411ad3:	mov    r9,QWORD PTR [rsp+0x50]
  411ad8:	sub    r9,0x10
  411adc:	cmp    r8,r9
  411adf:	ja     411bac <__swc_fn_0a4ed24b_000161_b553c03d+0x24c>
  411ae5:	lea    r8,[r8+0x10]
  411ae9:	cmp    rdx,r8
  411aec:	jb     411bac <__swc_fn_0a4ed24b_000161_b553c03d+0x24c>
  411af2:	mov    r8,QWORD PTR [rsp+0x50]
  411af7:	cmp    rdx,r8
  411afa:	ja     411bac <__swc_fn_0a4ed24b_000161_b553c03d+0x24c>
  411b00:	xor    r8d,r8d
  411b03:	test   rcx,rcx
  411b06:	jbe    411bd2 <__swc_fn_0a4ed24b_000161_b553c03d+0x272>
  411b0c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  411b12:	cs nop WORD PTR [rax+rax*1+0x0]
  411b1c:	nop    DWORD PTR [rax+0x0]
  411b20:	imul   r9,r8,0x14
  411b24:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  411b29:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  411b2e:	add    r10,r11
  411b31:	movabs r11,0x100000000
  411b3b:	cmp    r10,r11
  411b3e:	ja     411bac <__swc_fn_0a4ed24b_000161_b553c03d+0x24c>
  411b40:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  411b45:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  411b4a:	test   r10d,r10d
  411b4d:	setne  r11b
  411b51:	je     411b6b <__swc_fn_0a4ed24b_000161_b553c03d+0x20b>
  411b53:	cmp    r10d,edx
  411b56:	setb   r11b
  411b5a:	jb     411b6b <__swc_fn_0a4ed24b_000161_b553c03d+0x20b>
  411b5c:	vmovq  r11,xmm1
  411b61:	cmp    r10,r11
  411b64:	setae  r10b
  411b68:	mov    r11b,r10b
  411b6b:	mov    r10,r11
  411b6e:	test   r11b,r11b
  411b71:	jne    411b98 <__swc_fn_0a4ed24b_000161_b553c03d+0x238>
  411b73:	test   r9d,r9d
  411b76:	setne  r10b
  411b7a:	je     411b98 <__swc_fn_0a4ed24b_000161_b553c03d+0x238>
  411b7c:	cmp    r9d,edx
  411b7f:	setb   r10b
  411b83:	jb     411b98 <__swc_fn_0a4ed24b_000161_b553c03d+0x238>
  411b85:	vmovq  r10,xmm1
  411b8a:	cmp    r9,r10
  411b8d:	setae  r9b
  411b91:	movzx  r9d,r9b
  411b95:	mov    r10b,r9b
  411b98:	test   r10b,r10b
  411b9b:	jne    411bac <__swc_fn_0a4ed24b_000161_b553c03d+0x24c>
  411b9d:	add    r8,0x1
  411ba1:	cmp    r8,rcx
  411ba4:	jb     411b20 <__swc_fn_0a4ed24b_000161_b553c03d+0x1c0>
  411baa:	jmp    411bd2 <__swc_fn_0a4ed24b_000161_b553c03d+0x272>
  411bac:	xor    ecx,ecx
  411bae:	cmp    rax,rbx
  411bb1:	cmovne rcx,rax
  411bb5:	call   410670 <__swc_fn_0a4ed24b_000143_b7ad855f>
  411bba:	mov    rcx,rsi
  411bbd:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  411bc2:	mov    rax,rdi
  411bc5:	add    rsp,0x188
  411bcc:	pop    r12
  411bce:	pop    rdi
  411bcf:	pop    rsi
  411bd0:	pop    rbx
  411bd1:	ret
  411bd2:	mov    QWORD PTR [rdi+0x10],rax
  411bd6:	mov    rcx,QWORD PTR [rsp+0x50]
  411bdb:	mov    QWORD PTR [rdi+0x18],rcx
  411bdf:	mov    eax,DWORD PTR [rax+0x8]
  411be2:	mov    DWORD PTR [rdi+0x20],eax
  411be5:	rex mov BYTE PTR [rdi+0x24],0x1
  411bea:	mov    rcx,rsi
  411bed:	call   40d0b0 <__swc_fn_0a4ed24b_000136_d579ef75>
  411bf2:	mov    rax,rdi
  411bf5:	add    rsp,0x188
  411bfc:	pop    r12
  411bfe:	pop    rdi
  411bff:	pop    rsi
  411c00:	pop    rbx
  411c01:	ret
	...

0000000000411c10 <__swc_fn_0a4ed24b_000164_d25850aa>:
  411c10:	push   rsi
  411c11:	push   rdi
  411c12:	push   r12
  411c14:	mov    rsi,rdx
  411c17:	mov    rdi,rcx
  411c1a:	mov    rcx,QWORD PTR [rip+0x1511f]        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  411c21:	test   rcx,rcx
  411c24:	jne    411c36 <__swc_fn_0a4ed24b_000164_d25850aa+0x26>
  411c26:	call   40a1a0 <__swc_fn_0a4ed24b_000165_56054fe7>
  411c2b:	lea    rcx,[rax+0x1]
  411c2f:	mov    QWORD PTR [rip+0x1510a],rcx        # 426d40 <__swc_bss_base_0a4ed24b+0x2d00>
  411c36:	dec    rcx
  411c39:	call   411c60 <__swc_fn_0a4ed24b_000167_39c041ad>
  411c3e:	mov    r12,QWORD PTR [rax+0xbe0]
  411c45:	test   r12,r12
  411c48:	setne  al
  411c4b:	je     411c56 <__swc_fn_0a4ed24b_000164_d25850aa+0x46>
  411c4d:	mov    rcx,rdi
  411c50:	mov    rdx,rsi
  411c53:	call   r12
  411c56:	pop    r12
  411c58:	pop    rdi
  411c59:	pop    rsi
  411c5a:	ret
  411c5b:	add    BYTE PTR [rax],al
  411c5d:	add    BYTE PTR [rax],al
	...

0000000000411c60 <__swc_fn_0a4ed24b_000167_39c041ad>:
  411c60:	push   r12
  411c62:	push   rdi
  411c63:	push   rsi
  411c64:	sub    rsp,0xd0
  411c6b:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  411c71:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  411c77:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  411c7d:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  411c83:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  411c89:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  411c8f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  411c98:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  411ca1:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  411caa:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  411cb3:	mov    r12,rcx
  411cb6:	mov    edi,ecx
  411cb8:	xor    eax,eax
  411cba:	call   407000 <pthread_getspecific@plt>
  411cbf:	test   rax,rax
  411cc2:	je     411cc6 <__swc_fn_0a4ed24b_000167_39c041ad+0x66>
  411cc4:	jmp    411cce <__swc_fn_0a4ed24b_000167_39c041ad+0x6e>
  411cc6:	mov    rcx,r12
  411cc9:	call   40a200 <__swc_fn_0a4ed24b_000168_0ad81c51>
  411cce:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  411cd4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  411cda:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  411ce0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  411ce6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  411cec:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  411cf2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  411cfb:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  411d04:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  411d0d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  411d16:	add    rsp,0xd0
  411d1d:	pop    rsi
  411d1e:	pop    rdi
  411d1f:	pop    r12
  411d21:	ret
	...

0000000000411d30 <__swc_fn_0a4ed24b_000170_4dbacba0>:
  411d30:	push   rsi
  411d31:	sub    rsp,0x30
  411d35:	lea    rsi,[rip+0x1506c]        # 426da8 <__swc_bss_base_0a4ed24b+0x2d68>
  411d3c:	mov    rax,QWORD PTR [rsi]
  411d3f:	test   rax,rax
  411d42:	je     411d4a <__swc_fn_0a4ed24b_000170_4dbacba0+0x1a>
  411d44:	add    rsp,0x30
  411d48:	pop    rsi
  411d49:	ret
  411d4a:	mov    ecx,0x3
  411d4f:	mov    edx,0x10
  411d54:	call   40f7d0 <__swc_fn_0a4ed24b_000107_c8d4a68e>
  411d59:	test   rax,rax
  411d5c:	jne    411d6d <__swc_fn_0a4ed24b_000170_4dbacba0+0x3d>
  411d5e:	mov    QWORD PTR [rsp+0x18],rax
  411d63:	call   40cc10 <__swc_fn_0a4ed24b_000118_591530fe>
  411d68:	mov    rax,QWORD PTR [rsp+0x18]
  411d6d:	mov    rcx,rax
  411d70:	xchg   QWORD PTR [rsi],rcx
  411d73:	add    rsp,0x30
  411d77:	pop    rsi
  411d78:	ret
  411d79:	add    BYTE PTR [rax],al
  411d7b:	add    BYTE PTR [rax],al
  411d7d:	add    BYTE PTR [rax],al
	...

0000000000411d80 <__swc_fn_0a4ed24b_000173_e17a224b>:
  411d80:	push   rsi
  411d81:	push   rdi
  411d82:	sub    rsp,0x8
  411d86:	mov    rsi,rdx
  411d89:	mov    rdi,rcx
  411d8c:	mov    rax,QWORD PTR [rsi+0x8]
  411d90:	test   rax,rax
  411d93:	je     411d9d <__swc_fn_0a4ed24b_000173_e17a224b+0x1d>
  411d95:	mov    rcx,QWORD PTR [rsi]
  411d98:	mov    QWORD PTR [rax],rcx
  411d9b:	jmp    411da4 <__swc_fn_0a4ed24b_000173_e17a224b+0x24>
  411d9d:	mov    rax,QWORD PTR [rsi]
  411da0:	mov    QWORD PTR [rdi+0x8],rax
  411da4:	mov    rax,QWORD PTR [rsi]
  411da7:	test   rax,rax
  411daa:	je     411db4 <__swc_fn_0a4ed24b_000173_e17a224b+0x34>
  411dac:	mov    rcx,QWORD PTR [rsi+0x8]
  411db0:	mov    QWORD PTR [rax+0x8],rcx
  411db4:	mov    rcx,rdi
  411db7:	mov    rdx,QWORD PTR [rsi+0x10]
  411dbb:	mov    r8,QWORD PTR [rsi+0x18]
  411dbf:	mov    r9,0xffffffffffffffff
  411dc6:	call   40d7c0 <__swc_fn_0a4ed24b_000172_1751ecdd>
  411dcb:	mov    QWORD PTR [rsi+0x18],0x0
  411dd3:	mov    rax,QWORD PTR [rdi+0x8]
  411dd7:	test   rax,rax
  411dda:	jne    411dec <__swc_fn_0a4ed24b_000173_e17a224b+0x6c>
  411ddc:	call   411d30 <__swc_fn_0a4ed24b_000170_4dbacba0>
  411de1:	xor    ecx,ecx
  411de3:	mov    QWORD PTR [rax+0x8],rcx
  411de7:	xor    ecx,ecx
  411de9:	mov    QWORD PTR [rax],rcx
  411dec:	add    rsp,0x8
  411df0:	pop    rdi
  411df1:	pop    rsi
  411df2:	ret
	...

0000000000411e00 <__swc_fn_0a4ed24b_000176_0d61c738>:
  411e00:	push   rbp
  411e01:	sub    rsp,0x108
  411e08:	mov    rbp,rsp
  411e0b:	vmovups XMMWORD PTR [rsp+0x60],xmm6
  411e11:	vmovups XMMWORD PTR [rsp+0x70],xmm7
  411e17:	vmovups XMMWORD PTR [rsp+0x80],xmm8
  411e20:	vmovups XMMWORD PTR [rsp+0x90],xmm9
  411e29:	vmovups XMMWORD PTR [rsp+0xa0],xmm10
  411e32:	vmovups XMMWORD PTR [rsp+0xb0],xmm12
  411e3b:	vmovups XMMWORD PTR [rsp+0xc0],xmm13
  411e44:	vmovups XMMWORD PTR [rsp+0xd0],xmm14
  411e4d:	vmovups XMMWORD PTR [rsp+0xe0],xmm15
  411e56:	vmovups XMMWORD PTR [rsp+0xf0],xmm11
  411e5f:	vmovups xmm6,xmm5
  411e63:	vmovups xmm7,xmm0
  411e67:	vmovups xmm0,xmm1
  411e6b:	vmovups xmm1,xmm2
  411e6f:	vmovups xmm2,xmm3
  411e73:	vmovups xmm3,xmm4
  411e77:	vmovsd QWORD PTR [rsp+0x50],xmm4
  411e7d:	vmovsd xmm4,QWORD PTR [rbp+0x118]
  411e85:	vmovsd xmm5,QWORD PTR [rip+0x1a84]        # 413911 <__swc_rdata_base_0a4ed24b+0x801>
  411e8d:	mov    eax,0xffffffff
  411e92:	vsubsd xmm8,xmm0,QWORD PTR [rip+0x1a80]        # 41391a <__swc_rdata_base_0a4ed24b+0x80a>
  411e9a:	vsubsd xmm9,xmm1,QWORD PTR [rip+0x1a81]        # 413923 <__swc_rdata_base_0a4ed24b+0x813>
  411ea2:	vmulsd xmm10,xmm7,xmm2
  411ea6:	vfmadd231sd xmm10,xmm8,xmm3
  411eab:	vfmadd231sd xmm10,xmm9,xmm6
  411eb0:	vaddsd xmm10,xmm10,xmm10
  411eb5:	vmulsd xmm12,xmm7,xmm7
  411eb9:	vfmadd213sd xmm8,xmm8,xmm12
  411ebe:	vfmadd231sd xmm8,xmm9,xmm9
  411ec3:	vmovsd xmm14,QWORD PTR [rip+0x1a61]        # 41392c <__swc_rdata_base_0a4ed24b+0x81c>
  411ecb:	vsubsd xmm8,xmm8,xmm14
  411ed0:	vmulsd xmm9,xmm10,xmm10
  411ed5:	vmovsd xmm15,QWORD PTR [rip+0x1a58]        # 413935 <__swc_rdata_base_0a4ed24b+0x825>
  411edd:	vfnmadd213sd xmm8,xmm15,xmm9
  411ee2:	vxorpd xmm9,xmm9,xmm9
  411ee7:	vcomisd xmm9,xmm8
  411eec:	ja     411f37 <__swc_fn_0a4ed24b_000176_0d61c738+0x137>
  411eee:	vsqrtsd xmm9,xmm8,xmm8
  411ef3:	vxorpd xmm10,xmm10,XMMWORD PTR [rip+0x1655]        # 413550 <__swc_rdata_base_0a4ed24b+0x440>
  411efb:	vsubsd xmm8,xmm10,xmm9
  411f00:	vmovsd xmm12,QWORD PTR [rip+0x16ac]        # 4135b4 <__swc_rdata_base_0a4ed24b+0x4a4>
  411f08:	vmulsd xmm8,xmm8,xmm12
  411f0d:	vmovups xmm11,xmm8
  411f12:	vcomisd xmm4,xmm8
  411f17:	jbe    411f23 <__swc_fn_0a4ed24b_000176_0d61c738+0x123>
  411f19:	vaddsd xmm8,xmm10,xmm9
  411f1e:	vmulsd xmm11,xmm8,xmm12
  411f23:	vcomisd xmm11,xmm4
  411f27:	jb     411f37 <__swc_fn_0a4ed24b_000176_0d61c738+0x137>
  411f29:	vcomisd xmm5,xmm11
  411f2e:	jbe    411f37 <__swc_fn_0a4ed24b_000176_0d61c738+0x137>
  411f30:	vmovups xmm5,xmm11
  411f35:	xor    eax,eax
  411f37:	vsubsd xmm13,xmm7,QWORD PTR [rip+0x19ff]        # 41393e <__swc_rdata_base_0a4ed24b+0x82e>
  411f3f:	vsubsd xmm9,xmm1,QWORD PTR [rip+0x1a00]        # 413947 <__swc_rdata_base_0a4ed24b+0x837>
  411f47:	vmulsd xmm10,xmm13,xmm2
  411f4b:	vmulsd xmm11,xmm0,xmm3
  411f4f:	vaddsd xmm10,xmm10,xmm11
  411f54:	vfmadd231sd xmm10,xmm9,xmm6
  411f59:	vaddsd xmm10,xmm10,xmm10
  411f5e:	vmulsd xmm12,xmm13,xmm13
  411f63:	vmulsd xmm13,xmm0,xmm0
  411f67:	vaddsd xmm8,xmm12,xmm13
  411f6c:	vfmadd231sd xmm8,xmm9,xmm9
  411f71:	vsubsd xmm8,xmm8,xmm14
  411f76:	vmulsd xmm9,xmm10,xmm10
  411f7b:	vfnmadd213sd xmm8,xmm15,xmm9
  411f80:	vxorpd xmm9,xmm9,xmm9
  411f85:	vcomisd xmm9,xmm8
  411f8a:	ja     411fd6 <__swc_fn_0a4ed24b_000176_0d61c738+0x1d6>
  411f8c:	vsqrtsd xmm9,xmm8,xmm8
  411f91:	vxorpd xmm10,xmm10,XMMWORD PTR [rip+0x15b7]        # 413550 <__swc_rdata_base_0a4ed24b+0x440>
  411f99:	vsubsd xmm8,xmm10,xmm9
  411f9e:	vmovsd xmm12,QWORD PTR [rip+0x160e]        # 4135b4 <__swc_rdata_base_0a4ed24b+0x4a4>
  411fa6:	vmulsd xmm8,xmm8,xmm12
  411fab:	vmovups xmm3,xmm8
  411fb0:	vcomisd xmm4,xmm8
  411fb5:	jbe    411fc1 <__swc_fn_0a4ed24b_000176_0d61c738+0x1c1>
  411fb7:	vaddsd xmm8,xmm10,xmm9
  411fbc:	vmulsd xmm3,xmm8,xmm12
  411fc1:	vcomisd xmm3,xmm4
  411fc5:	jb     411fd6 <__swc_fn_0a4ed24b_000176_0d61c738+0x1d6>
  411fc7:	vcomisd xmm5,xmm3
  411fcb:	jbe    411fd6 <__swc_fn_0a4ed24b_000176_0d61c738+0x1d6>
  411fcd:	vmovups xmm5,xmm3
  411fd1:	mov    eax,0x1
  411fd6:	vsubsd xmm3,xmm7,QWORD PTR [rip+0x1972]        # 413950 <__swc_rdata_base_0a4ed24b+0x840>
  411fde:	vsubsd xmm9,xmm1,QWORD PTR [rip+0x194f]        # 413935 <__swc_rdata_base_0a4ed24b+0x825>
  411fe6:	vmulsd xmm10,xmm3,xmm2
  411fea:	vaddsd xmm10,xmm10,xmm11
  411fef:	vfmadd231sd xmm10,xmm9,xmm6
  411ff4:	vaddsd xmm10,xmm10,xmm10
  411ff9:	vmulsd xmm12,xmm3,xmm3
  411ffd:	vaddsd xmm8,xmm12,xmm13
  412002:	vfmadd231sd xmm8,xmm9,xmm9
  412007:	vsubsd xmm8,xmm8,xmm14
  41200c:	vmulsd xmm9,xmm10,xmm10
  412011:	vfnmadd213sd xmm8,xmm15,xmm9
  412016:	vxorpd xmm9,xmm9,xmm9
  41201b:	vcomisd xmm9,xmm8
  412020:	ja     41206c <__swc_fn_0a4ed24b_000176_0d61c738+0x26c>
  412022:	vsqrtsd xmm9,xmm8,xmm8
  412027:	vxorpd xmm10,xmm10,XMMWORD PTR [rip+0x1521]        # 413550 <__swc_rdata_base_0a4ed24b+0x440>
  41202f:	vsubsd xmm8,xmm10,xmm9
  412034:	vmovsd xmm12,QWORD PTR [rip+0x1578]        # 4135b4 <__swc_rdata_base_0a4ed24b+0x4a4>
  41203c:	vmulsd xmm8,xmm8,xmm12
  412041:	vmovups xmm3,xmm8
  412046:	vcomisd xmm4,xmm8
  41204b:	jbe    412057 <__swc_fn_0a4ed24b_000176_0d61c738+0x257>
  41204d:	vaddsd xmm8,xmm10,xmm9
  412052:	vmulsd xmm3,xmm8,xmm12
  412057:	vcomisd xmm3,xmm4
  41205b:	jb     41206c <__swc_fn_0a4ed24b_000176_0d61c738+0x26c>
  41205d:	vcomisd xmm5,xmm3
  412061:	jbe    41206c <__swc_fn_0a4ed24b_000176_0d61c738+0x26c>
  412063:	vmovups xmm5,xmm3
  412067:	mov    eax,0x2
  41206c:	vsubsd xmm8,xmm0,QWORD PTR [rip+0x18e5]        # 413959 <__swc_rdata_base_0a4ed24b+0x849>
  412074:	vmulsd xmm10,xmm7,xmm2
  412078:	vfmadd231sd xmm10,xmm8,QWORD PTR [rsp+0x50]
  41207f:	vfmadd231sd xmm10,xmm1,xmm6
  412084:	vaddsd xmm10,xmm10,xmm10
  412089:	vmulsd xmm12,xmm7,xmm7
  41208d:	vfmadd213sd xmm8,xmm8,xmm12
  412092:	vfmadd231sd xmm8,xmm1,xmm1
  412097:	vsubsd xmm8,xmm8,QWORD PTR [rip+0x18c3]        # 413962 <__swc_rdata_base_0a4ed24b+0x852>
  41209f:	vmulsd xmm9,xmm10,xmm10
  4120a4:	vfnmadd213sd xmm8,xmm15,xmm9
  4120a9:	vxorpd xmm9,xmm9,xmm9
  4120ae:	vcomisd xmm9,xmm8
  4120b3:	ja     4120ff <__swc_fn_0a4ed24b_000176_0d61c738+0x2ff>
  4120b5:	vsqrtsd xmm9,xmm8,xmm8
  4120ba:	vxorpd xmm10,xmm10,XMMWORD PTR [rip+0x148e]        # 413550 <__swc_rdata_base_0a4ed24b+0x440>
  4120c2:	vsubsd xmm8,xmm10,xmm9
  4120c7:	vmovsd xmm12,QWORD PTR [rip+0x14e5]        # 4135b4 <__swc_rdata_base_0a4ed24b+0x4a4>
  4120cf:	vmulsd xmm8,xmm8,xmm12
  4120d4:	vmovups xmm3,xmm8
  4120d9:	vcomisd xmm4,xmm8
  4120de:	jbe    4120ea <__swc_fn_0a4ed24b_000176_0d61c738+0x2ea>
  4120e0:	vaddsd xmm8,xmm10,xmm9
  4120e5:	vmulsd xmm3,xmm8,xmm12
  4120ea:	vcomisd xmm3,xmm4
  4120ee:	jb     4120ff <__swc_fn_0a4ed24b_000176_0d61c738+0x2ff>
  4120f0:	vcomisd xmm5,xmm3
  4120f4:	jbe    4120ff <__swc_fn_0a4ed24b_000176_0d61c738+0x2ff>
  4120f6:	vmovups xmm5,xmm3
  4120fa:	mov    eax,0x3
  4120ff:	vmovsd QWORD PTR [rip+0x14ca9],xmm5        # 426db0 <__swc_bss_base_0a4ed24b+0x2d70>
  412107:	mov    DWORD PTR [rip+0xff03],eax        # 422010 <__swc_data_base_0a4ed24b+0x10>
  41210d:	vmovups xmm6,XMMWORD PTR [rsp+0x60]
  412113:	vmovups xmm7,XMMWORD PTR [rsp+0x70]
  412119:	vmovups xmm8,XMMWORD PTR [rsp+0x80]
  412122:	vmovups xmm9,XMMWORD PTR [rsp+0x90]
  41212b:	vmovups xmm10,XMMWORD PTR [rsp+0xa0]
  412134:	vmovups xmm12,XMMWORD PTR [rsp+0xb0]
  41213d:	vmovups xmm13,XMMWORD PTR [rsp+0xc0]
  412146:	vmovups xmm14,XMMWORD PTR [rsp+0xd0]
  41214f:	vmovups xmm15,XMMWORD PTR [rsp+0xe0]
  412158:	vmovups xmm11,XMMWORD PTR [rsp+0xf0]
  412161:	add    rsp,0x108
  412168:	pop    rbp
  412169:	ret
