
/workspace/prompt2-20261115/batch5-final-micro/base/binarytrees/binarytrees:     file format elf64-x86-64


Disassembly of section .text:

000000000040d650 <__swc_fn_7dafa2b1_000175_82999b37>:
  40d650:	push   rbx
  40d651:	push   rsi
  40d652:	sub    rsp,0x68
  40d656:	mov    rbx,rcx
  40d659:	vxorps xmm0,xmm0,xmm0
  40d65d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40d663:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40d669:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40d66f:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40d675:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40d67b:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40d681:	mov    QWORD PTR [rsp+0x50],0x20
  40d68a:	mov    DWORD PTR [rsp+0x60],0x10
  40d692:	mov    rcx,QWORD PTR [rip+0x186a7]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40d699:	test   rcx,rcx
  40d69c:	jne    40d6ae <__swc_fn_7dafa2b1_000175_82999b37+0x5e>
  40d69e:	call   40a1d0 <__swc_fn_7dafa2b1_000165_dc0404ce>
  40d6a3:	lea    rcx,[rax+0x1]
  40d6a7:	mov    QWORD PTR [rip+0x18692],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40d6ae:	dec    rcx
  40d6b1:	call   4119a0 <__swc_fn_7dafa2b1_000167_3393d6f4>
  40d6b6:	mov    rcx,QWORD PTR [rax]
  40d6b9:	lea    rdx,[rsp+0x8]
  40d6be:	mov    rsi,QWORD PTR [rax+0x8]
  40d6c2:	mov    rsi,QWORD PTR [rsi+0x8]
  40d6c6:	call   rsi
  40d6c8:	mov    rax,QWORD PTR [rsp+0x48]
  40d6cd:	test   rax,rax
  40d6d0:	jne    40d6d6 <__swc_fn_7dafa2b1_000175_82999b37+0x86>
  40d6d2:	xor    esi,esi
  40d6d4:	jmp    40d6ea <__swc_fn_7dafa2b1_000175_82999b37+0x9a>
  40d6d6:	mov    rcx,QWORD PTR [rsp+0x50]
  40d6db:	mov    QWORD PTR [rax],rcx
  40d6de:	mov    QWORD PTR [rax+0x8],0x0
  40d6e6:	lea    rsi,[rax+0x10]
  40d6ea:	test   ebx,ebx
  40d6ec:	jle    40d707 <__swc_fn_7dafa2b1_000175_82999b37+0xb7>
  40d6ee:	dec    ebx
  40d6f0:	mov    ecx,ebx
  40d6f2:	call   40d650 <__swc_fn_7dafa2b1_000175_82999b37>
  40d6f7:	mov    QWORD PTR [rsi],rax
  40d6fa:	mov    ecx,ebx
  40d6fc:	call   40d650 <__swc_fn_7dafa2b1_000175_82999b37>
  40d701:	mov    QWORD PTR [rsi+0x8],rax
  40d705:	jmp    40d70f <__swc_fn_7dafa2b1_000175_82999b37+0xbf>
  40d707:	vxorps xmm0,xmm0,xmm0
  40d70b:	vmovdqu XMMWORD PTR [rsi],xmm0
  40d70f:	mov    rax,rsi
  40d712:	add    rsp,0x68
  40d716:	pop    rsi
  40d717:	pop    rbx
  40d718:	ret
