
/workspace/prompt2-20261115/batch5-final-micro/new/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

0000000000410c40 <__swc_fn_4fa09e82_000152_6203dca2>:
  410c40:	push   rbx
  410c41:	push   rsi
  410c42:	push   rdi
  410c43:	push   r12
  410c45:	push   r13
  410c47:	push   r15
  410c49:	sub    rsp,0x4e8
  410c50:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  410c59:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  410c62:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  410c6b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  410c74:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  410c7d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  410c86:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  410c8f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  410c98:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  410ca1:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  410caa:	mov    rbx,QWORD PTR [rcx]
  410cad:	mov    rcx,QWORD PTR [rcx+0x8]
  410cb1:	mov    rsi,rcx
  410cb4:	xor    edi,edi
  410cb6:	vmovsd xmm6,QWORD PTR [rip+0x29a2]        # 413660 <__swc_rdata_base_4fa09e82+0x550>
  410cbe:	vmovsd xmm7,QWORD PTR [rip+0x29a3]        # 413669 <__swc_rdata_base_4fa09e82+0x559>
  410cc6:	vmovsd xmm8,QWORD PTR [rip+0x29a4]        # 413672 <__swc_rdata_base_4fa09e82+0x562>
  410cce:	vmovsd xmm9,QWORD PTR [rip+0x29a5]        # 41367b <__swc_rdata_base_4fa09e82+0x56b>
  410cd6:	vmovsd xmm10,QWORD PTR [rip+0x29a6]        # 413684 <__swc_rdata_base_4fa09e82+0x574>
  410cde:	vmovups xmm11,xmm6
  410ce2:	vmovsd QWORD PTR [rsp+0x418],xmm7
  410ceb:	vmovsd QWORD PTR [rsp+0x420],xmm8
  410cf4:	vmovsd QWORD PTR [rsp+0x428],xmm9
  410cfd:	vmovsd QWORD PTR [rsp+0x430],xmm10
  410d06:	vmovsd xmm15,QWORD PTR [rip+0x297f]        # 41368d <__swc_rdata_base_4fa09e82+0x57d>
  410d0e:	vmovups xmm14,xmm15
  410d13:	vmovups xmm0,xmm9
  410d18:	vmovsd QWORD PTR [rsp+0x438],xmm15
  410d21:	vmovups xmm13,xmm8
  410d26:	vmovsd QWORD PTR [rsp+0x440],xmm15
  410d2f:	test   rsi,rsi
  410d32:	je     411d23 <__swc_fn_4fa09e82_000152_6203dca2+0x10e3>
  410d38:	cs nop WORD PTR [rax+rax*1+0x0]
  410d42:	cs nop WORD PTR [rax+rax*1+0x0]
  410d4c:	nop    DWORD PTR [rax+0x0]
  410d50:	lea    rcx,[rdi+rdi*1]
  410d54:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  410d59:	vpshufd xmm3,xmm2,0xee
  410d5e:	vmovq  rcx,xmm3
  410d63:	test   rcx,rcx
  410d66:	je     410d7c <__swc_fn_4fa09e82_000152_6203dca2+0x13c>
  410d68:	test   DWORD PTR [rcx+0x28],0x400000
  410d6f:	je     410d7c <__swc_fn_4fa09e82_000152_6203dca2+0x13c>
  410d71:	mov    rdx,QWORD PTR [rcx+0x30]
  410d75:	test   rdx,rdx
  410d78:	cmovne rcx,rdx
  410d7c:	test   DWORD PTR [rcx+0x28],0x1000
  410d83:	je     410da4 <__swc_fn_4fa09e82_000152_6203dca2+0x164>
  410d85:	mov    rdx,QWORD PTR [rcx+0x40]
  410d89:	mov    rcx,rdx
  410d8c:	vmovq  r8,xmm2
  410d91:	mov    r8,QWORD PTR [r8]
  410d94:	mov    QWORD PTR [rsp+0x60],r8
  410d99:	mov    QWORD PTR [rsp+0x68],rdx
  410d9e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  410da4:	test   BYTE PTR [rcx+0x28],0x1
  410da8:	jne    410db0 <__swc_fn_4fa09e82_000152_6203dca2+0x170>
  410daa:	vmovups xmm12,xmm0
  410dae:	jmp    410dca <__swc_fn_4fa09e82_000152_6203dca2+0x18a>
  410db0:	vmovq  rax,xmm2
  410db5:	mov    rax,QWORD PTR [rax]
  410db8:	lea    rcx,[rax+0x10]
  410dbc:	vmovups xmm12,xmm0
  410dc0:	call   4103d0 <__swc_fn_4fa09e82_000122_2648f149>
  410dc5:	jmp    411d05 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410dca:	test   DWORD PTR [rcx+0x28],0x400
  410dd1:	je     410e32 <__swc_fn_4fa09e82_000152_6203dca2+0x1f2>
  410dd3:	vmovq  rax,xmm2
  410dd8:	mov    rax,QWORD PTR [rax]
  410ddb:	xor    ecx,ecx
  410ddd:	test   rax,rax
  410de0:	je     410e10 <__swc_fn_4fa09e82_000152_6203dca2+0x1d0>
  410de2:	mov    rdx,rax
  410de5:	mov    r8b,BYTE PTR [rdx]
  410de8:	test   r8b,r8b
  410deb:	je     410e10 <__swc_fn_4fa09e82_000152_6203dca2+0x1d0>
  410ded:	cs nop WORD PTR [rax+rax*1+0x0]
  410df7:	nop    WORD PTR [rax+rax*1+0x0]
  410e00:	add    rdx,0x1
  410e04:	add    rcx,0x1
  410e08:	mov    r8b,BYTE PTR [rdx]
  410e0b:	test   r8b,r8b
  410e0e:	jne    410e00 <__swc_fn_4fa09e82_000152_6203dca2+0x1c0>
  410e10:	mov    QWORD PTR [rsp+0x88],rax
  410e18:	mov    QWORD PTR [rsp+0x90],rcx
  410e20:	lea    rcx,[rsp+0x88]
  410e28:	call   4103d0 <__swc_fn_4fa09e82_000122_2648f149>
  410e2d:	jmp    411d05 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410e32:	cmp    BYTE PTR [rcx+0x2c],0x6
  410e36:	jne    410e4d <__swc_fn_4fa09e82_000152_6203dca2+0x20d>
  410e38:	vmovq  rax,xmm2
  410e3d:	mov    rax,QWORD PTR [rax]
  410e40:	mov    rcx,rax
  410e43:	call   40a130 <__swc_fn_4fa09e82_000150_43c96957>
  410e48:	jmp    411d05 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410e4d:	cmp    BYTE PTR [rcx+0x2c],0x1
  410e51:	jne    411cf9 <__swc_fn_4fa09e82_000152_6203dca2+0x10b9>
  410e57:	vmovq  rdx,xmm2
  410e5c:	mov    cl,BYTE PTR [rcx+0x40]
  410e5f:	cmp    cl,0x7
  410e62:	jb     410ea5 <__swc_fn_4fa09e82_000152_6203dca2+0x265>
  410e64:	je     410f18 <__swc_fn_4fa09e82_000152_6203dca2+0x2d8>
  410e6a:	cmp    cl,0x8
  410e6d:	je     410f24 <__swc_fn_4fa09e82_000152_6203dca2+0x2e4>
  410e73:	cmp    cl,0x9
  410e76:	je     410f3d <__swc_fn_4fa09e82_000152_6203dca2+0x2fd>
  410e7c:	cmp    cl,0xa
  410e7f:	je     411604 <__swc_fn_4fa09e82_000152_6203dca2+0x9c4>
  410e85:	cmp    cl,0xb
  410e88:	je     411ccb <__swc_fn_4fa09e82_000152_6203dca2+0x108b>
  410e8e:	cmp    cl,0xc
  410e91:	je     410f31 <__swc_fn_4fa09e82_000152_6203dca2+0x2f1>
  410e97:	cmp    cl,0xd
  410e9a:	je     411cc1 <__swc_fn_4fa09e82_000152_6203dca2+0x1081>
  410ea0:	jmp    411ceb <__swc_fn_4fa09e82_000152_6203dca2+0x10ab>
  410ea5:	cmp    cl,0x1
  410ea8:	je     410ec8 <__swc_fn_4fa09e82_000152_6203dca2+0x288>
  410eaa:	cmp    cl,0x2
  410ead:	je     410ed6 <__swc_fn_4fa09e82_000152_6203dca2+0x296>
  410eaf:	cmp    cl,0x3
  410eb2:	je     410ee4 <__swc_fn_4fa09e82_000152_6203dca2+0x2a4>
  410eb4:	cmp    cl,0x4
  410eb7:	je     410ef1 <__swc_fn_4fa09e82_000152_6203dca2+0x2b1>
  410eb9:	cmp    cl,0x5
  410ebc:	je     410efe <__swc_fn_4fa09e82_000152_6203dca2+0x2be>
  410ebe:	cmp    cl,0x6
  410ec1:	je     410f0b <__swc_fn_4fa09e82_000152_6203dca2+0x2cb>
  410ec3:	jmp    411ceb <__swc_fn_4fa09e82_000152_6203dca2+0x10ab>
  410ec8:	movsx  rcx,BYTE PTR [rdx]
  410ecc:	call   40d620 <__swc_fn_4fa09e82_000151_2eb804cc>
  410ed1:	jmp    411d05 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410ed6:	movsx  rcx,WORD PTR [rdx]
  410eda:	call   40d620 <__swc_fn_4fa09e82_000151_2eb804cc>
  410edf:	jmp    411d05 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410ee4:	movsxd rcx,DWORD PTR [rdx]
  410ee7:	call   40d620 <__swc_fn_4fa09e82_000151_2eb804cc>
  410eec:	jmp    411d05 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410ef1:	mov    rcx,QWORD PTR [rdx]
  410ef4:	call   40d620 <__swc_fn_4fa09e82_000151_2eb804cc>
  410ef9:	jmp    411d05 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410efe:	movzx  ecx,BYTE PTR [rdx]
  410f01:	call   40a130 <__swc_fn_4fa09e82_000150_43c96957>
  410f06:	jmp    411d05 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410f0b:	movzx  ecx,WORD PTR [rdx]
  410f0e:	call   40a130 <__swc_fn_4fa09e82_000150_43c96957>
  410f13:	jmp    411d05 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410f18:	mov    ecx,DWORD PTR [rdx]
  410f1a:	call   40a130 <__swc_fn_4fa09e82_000150_43c96957>
  410f1f:	jmp    411d05 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410f24:	mov    rcx,QWORD PTR [rdx]
  410f27:	call   40a130 <__swc_fn_4fa09e82_000150_43c96957>
  410f2c:	jmp    411d05 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410f31:	mov    ecx,DWORD PTR [rdx]
  410f33:	call   40a130 <__swc_fn_4fa09e82_000150_43c96957>
  410f38:	jmp    411d05 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  410f3d:	lea    rcx,[rsp+0xa8]
  410f45:	vxorps xmm0,xmm0,xmm0
  410f49:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  410f52:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  410f5b:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  410f64:	vzeroupper
  410f67:	mov    DWORD PTR [rsp+0x108],0x0
  410f72:	vxorpd xmm0,xmm0,xmm0
  410f76:	vmovss xmm1,DWORD PTR [rdx]
  410f7a:	vcvtss2sd xmm0,xmm0,xmm1
  410f7e:	vmovsd xmm1,xmm1,xmm0
  410f82:	vcomisd xmm0,xmm0
  410f86:	setne  dl
  410f89:	movzx  edx,dl
  410f8c:	setp   r8b
  410f90:	movzx  r8d,r8b
  410f94:	or     edx,r8d
  410f97:	test   dl,dl
  410f99:	je     410fa6 <__swc_fn_4fa09e82_000152_6203dca2+0x366>
  410f9b:	mov    DWORD PTR [rcx],0x6e616e
  410fa1:	jmp    411598 <__swc_fn_4fa09e82_000152_6203dca2+0x958>
  410fa6:	vcomisd xmm1,xmm6
  410faa:	ja     410fb2 <__swc_fn_4fa09e82_000152_6203dca2+0x372>
  410fac:	vcomisd xmm7,xmm1
  410fb0:	jbe    410fd6 <__swc_fn_4fa09e82_000152_6203dca2+0x396>
  410fb2:	vxorpd xmm0,xmm0,xmm0
  410fb6:	vcomisd xmm0,xmm1
  410fba:	jbe    410fcb <__swc_fn_4fa09e82_000152_6203dca2+0x38b>
  410fbc:	mov    DWORD PTR [rcx],0x666e692d
  410fc2:	mov    BYTE PTR [rcx+0x4],0x0
  410fc6:	jmp    411598 <__swc_fn_4fa09e82_000152_6203dca2+0x958>
  410fcb:	mov    DWORD PTR [rcx],0x666e69
  410fd1:	jmp    411598 <__swc_fn_4fa09e82_000152_6203dca2+0x958>
  410fd6:	vcomisd xmm1,xmm8
  410fdb:	jae    410fe7 <__swc_fn_4fa09e82_000152_6203dca2+0x3a7>
  410fdd:	vcomisd xmm9,xmm1
  410fe1:	jbe    41135e <__swc_fn_4fa09e82_000152_6203dca2+0x71e>
  410fe7:	vmovups xmm0,xmm1
  410feb:	vxorpd xmm2,xmm2,xmm2
  410fef:	vcomisd xmm2,xmm1
  410ff3:	jbe    411003 <__swc_fn_4fa09e82_000152_6203dca2+0x3c3>
  410ff5:	vmovsd xmm1,xmm1,xmm0
  410ff9:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x261f]        # 413620 <__swc_rdata_base_4fa09e82+0x510>
  411001:	jmp    411007 <__swc_fn_4fa09e82_000152_6203dca2+0x3c7>
  411003:	vmovsd xmm1,xmm1,xmm0
  411007:	xor    r8d,r8d
  41100a:	vcomisd xmm1,xmm15
  41100f:	jb     411030 <__swc_fn_4fa09e82_000152_6203dca2+0x3f0>
  411011:	cs nop WORD PTR [rax+rax*1+0x0]
  41101b:	nop    DWORD PTR [rax+rax*1+0x0]
  411020:	vdivsd xmm1,xmm1,xmm15
  411025:	add    r8,0x1
  411029:	vcomisd xmm1,xmm15
  41102e:	jae    411020 <__swc_fn_4fa09e82_000152_6203dca2+0x3e0>
  411030:	mov    r9,rcx
  411033:	vxorpd xmm2,xmm2,xmm2
  411037:	vcomisd xmm2,xmm0
  41103b:	jbe    411044 <__swc_fn_4fa09e82_000152_6203dca2+0x404>
  41103d:	mov    BYTE PTR [rcx],0x2d
  411040:	lea    r9,[rcx+0x1]
  411044:	vcvttsd2si rdx,xmm1
  411049:	mov    r10b,dl
  41104c:	add    r10b,0x30
  411050:	mov    BYTE PTR [r9],r10b
  411053:	vxorpd xmm0,xmm0,xmm0
  411057:	movzx  edx,dl
  41105a:	vcvtsi2sd xmm0,xmm0,rdx
  41105f:	vsubsd xmm0,xmm1,xmm0
  411063:	vmulsd xmm1,xmm0,xmm15
  411068:	mov    BYTE PTR [r9+0x1],0x2e
  41106d:	vcvttsd2si rdx,xmm1
  411072:	mov    r10b,dl
  411075:	add    r10b,0x30
  411079:	mov    BYTE PTR [r9+0x2],r10b
  41107d:	vxorpd xmm0,xmm0,xmm0
  411081:	movzx  edx,dl
  411084:	vcvtsi2sd xmm0,xmm0,rdx
  411089:	vsubsd xmm0,xmm1,xmm0
  41108d:	vmulsd xmm1,xmm0,xmm15
  411092:	vcvttsd2si rdx,xmm1
  411097:	mov    r10b,dl
  41109a:	add    r10b,0x30
  41109e:	mov    BYTE PTR [r9+0x3],r10b
  4110a2:	vxorpd xmm0,xmm0,xmm0
  4110a6:	movzx  edx,dl
  4110a9:	vcvtsi2sd xmm0,xmm0,rdx
  4110ae:	vsubsd xmm0,xmm1,xmm0
  4110b2:	vmulsd xmm1,xmm0,xmm15
  4110b7:	vcvttsd2si rdx,xmm1
  4110bc:	mov    r10b,dl
  4110bf:	add    r10b,0x30
  4110c3:	mov    BYTE PTR [r9+0x4],r10b
  4110c7:	vxorpd xmm0,xmm0,xmm0
  4110cb:	movzx  edx,dl
  4110ce:	vcvtsi2sd xmm0,xmm0,rdx
  4110d3:	vsubsd xmm0,xmm1,xmm0
  4110d7:	vmulsd xmm1,xmm0,xmm15
  4110dc:	vcvttsd2si rdx,xmm1
  4110e1:	mov    r10b,dl
  4110e4:	add    r10b,0x30
  4110e8:	mov    BYTE PTR [r9+0x5],r10b
  4110ec:	vxorpd xmm0,xmm0,xmm0
  4110f0:	movzx  edx,dl
  4110f3:	vcvtsi2sd xmm0,xmm0,rdx
  4110f8:	vsubsd xmm0,xmm1,xmm0
  4110fc:	vmulsd xmm1,xmm0,xmm15
  411101:	vcvttsd2si rdx,xmm1
  411106:	mov    r10b,dl
  411109:	add    r10b,0x30
  41110d:	mov    BYTE PTR [r9+0x6],r10b
  411111:	vxorpd xmm0,xmm0,xmm0
  411115:	movzx  edx,dl
  411118:	vcvtsi2sd xmm0,xmm0,rdx
  41111d:	vsubsd xmm0,xmm1,xmm0
  411121:	vmulsd xmm1,xmm0,xmm15
  411126:	vcvttsd2si rdx,xmm1
  41112b:	mov    r10b,dl
  41112e:	add    r10b,0x30
  411132:	mov    BYTE PTR [r9+0x7],r10b
  411136:	vxorpd xmm0,xmm0,xmm0
  41113a:	movzx  edx,dl
  41113d:	vcvtsi2sd xmm0,xmm0,rdx
  411142:	vsubsd xmm0,xmm1,xmm0
  411146:	vmulsd xmm1,xmm0,xmm15
  41114b:	vcvttsd2si rdx,xmm1
  411150:	mov    r10b,dl
  411153:	add    r10b,0x30
  411157:	mov    BYTE PTR [r9+0x8],r10b
  41115b:	vxorpd xmm0,xmm0,xmm0
  41115f:	movzx  edx,dl
  411162:	vcvtsi2sd xmm0,xmm0,rdx
  411167:	vsubsd xmm0,xmm1,xmm0
  41116b:	vmulsd xmm1,xmm0,xmm15
  411170:	vcvttsd2si rdx,xmm1
  411175:	mov    r10b,dl
  411178:	add    r10b,0x30
  41117c:	mov    BYTE PTR [r9+0x9],r10b
  411180:	vxorpd xmm0,xmm0,xmm0
  411184:	movzx  edx,dl
  411187:	vcvtsi2sd xmm0,xmm0,rdx
  41118c:	vsubsd xmm0,xmm1,xmm0
  411190:	vmulsd xmm1,xmm0,xmm15
  411195:	vcvttsd2si rdx,xmm1
  41119a:	mov    r10b,dl
  41119d:	add    r10b,0x30
  4111a1:	mov    BYTE PTR [r9+0xa],r10b
  4111a5:	vxorpd xmm0,xmm0,xmm0
  4111a9:	movzx  edx,dl
  4111ac:	vcvtsi2sd xmm0,xmm0,rdx
  4111b1:	vsubsd xmm0,xmm1,xmm0
  4111b5:	vmulsd xmm1,xmm0,xmm15
  4111ba:	vcvttsd2si rdx,xmm1
  4111bf:	mov    r10b,dl
  4111c2:	add    r10b,0x30
  4111c6:	mov    BYTE PTR [r9+0xb],r10b
  4111ca:	lea    r10,[r9+0x4]
  4111ce:	vxorpd xmm0,xmm0,xmm0
  4111d2:	movzx  edx,dl
  4111d5:	vcvtsi2sd xmm0,xmm0,rdx
  4111da:	vsubsd xmm0,xmm1,xmm0
  4111de:	vmulsd xmm1,xmm0,xmm15
  4111e3:	vcvttsd2si rdx,xmm1
  4111e8:	mov    r11b,dl
  4111eb:	add    r11b,0x30
  4111ef:	mov    BYTE PTR [r9+0xc],r11b
  4111f3:	vxorpd xmm0,xmm0,xmm0
  4111f7:	movzx  edx,dl
  4111fa:	vcvtsi2sd xmm0,xmm0,rdx
  4111ff:	vsubsd xmm0,xmm1,xmm0
  411203:	vmulsd xmm1,xmm0,xmm15
  411208:	vcvttsd2si rdx,xmm1
  41120d:	mov    r11b,dl
  411210:	add    r11b,0x30
  411214:	mov    BYTE PTR [r9+0xd],r11b
  411218:	lea    r10,[r10+0x2]
  41121c:	vxorpd xmm0,xmm0,xmm0
  411220:	movzx  edx,dl
  411223:	vcvtsi2sd xmm0,xmm0,rdx
  411228:	vsubsd xmm0,xmm1,xmm0
  41122c:	vmulsd xmm1,xmm0,xmm15
  411231:	vcvttsd2si rdx,xmm1
  411236:	mov    r11b,dl
  411239:	add    r11b,0x30
  41123d:	mov    BYTE PTR [r9+0xe],r11b
  411241:	vxorpd xmm0,xmm0,xmm0
  411245:	movzx  edx,dl
  411248:	vcvtsi2sd xmm0,xmm0,rdx
  41124d:	vsubsd xmm0,xmm1,xmm0
  411251:	vmulsd xmm1,xmm0,xmm15
  411256:	vcvttsd2si rdx,xmm1
  41125b:	mov    r11b,dl
  41125e:	add    r11b,0x30
  411262:	mov    BYTE PTR [r9+0xf],r11b
  411266:	lea    r10,[r10+0x2]
  41126a:	lea    r10,[r10+0x2]
  41126e:	lea    r10,[r10+0x2]
  411272:	lea    r10,[r10+0x2]
  411276:	lea    r10,[r10+0x2]
  41127a:	vxorpd xmm0,xmm0,xmm0
  41127e:	movzx  edx,dl
  411281:	vcvtsi2sd xmm0,xmm0,rdx
  411286:	vsubsd xmm0,xmm1,xmm0
  41128a:	vmulsd xmm1,xmm0,xmm15
  41128f:	vcvttsd2si rdx,xmm1
  411294:	mov    r11b,dl
  411297:	add    r11b,0x30
  41129b:	mov    BYTE PTR [r9+0x10],r11b
  41129f:	vxorpd xmm0,xmm0,xmm0
  4112a3:	movzx  edx,dl
  4112a6:	vcvtsi2sd xmm0,xmm0,rdx
  4112ab:	vsubsd xmm0,xmm1,xmm0
  4112af:	vmulsd xmm1,xmm0,xmm15
  4112b4:	vcvttsd2si rdx,xmm1
  4112b9:	add    dl,0x30
  4112bc:	mov    BYTE PTR [r9+0x11],dl
  4112c0:	mov    BYTE PTR [r10+0x2],0x65
  4112c5:	lea    r9,[r10+0x3]
  4112c9:	test   r8,r8
  4112cc:	jl     4112d5 <__swc_fn_4fa09e82_000152_6203dca2+0x695>
  4112ce:	mov    BYTE PTR [r9],0x2b
  4112d2:	inc    r9
  4112d5:	mov    r10,r9
  4112d8:	mov    rdx,r8
  4112db:	nop    DWORD PTR [rax+rax*1+0x0]
  4112e0:	mov    r11,rdx
  4112e3:	movabs rdx,0x6666666666666667
  4112ed:	mov    rax,r11
  4112f0:	imul   rdx
  4112f3:	sar    rdx,0x2
  4112f7:	mov    r12,rdx
  4112fa:	shr    rdx,0x3f
  4112fe:	add    r12,rdx
  411301:	mov    rdx,r12
  411304:	imul   r13,r12,0xa
  411308:	sub    r11,r13
  41130b:	mov    r13,QWORD PTR [rip+0x22fe]        # 413610 <__swc_rdata_base_4fa09e82+0x500>
  411312:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411317:	mov    BYTE PTR [r10],r11b
  41131a:	lea    r11,[r10+0x1]
  41131e:	mov    r10,r11
  411321:	test   r12,r12
  411324:	jne    4112e0 <__swc_fn_4fa09e82_000152_6203dca2+0x6a0>
  411326:	test   r8,r8
  411329:	jge    411333 <__swc_fn_4fa09e82_000152_6203dca2+0x6f3>
  41132b:	mov    BYTE PTR [r11],0x2d
  41132f:	lea    r10,[r11+0x1]
  411333:	mov    BYTE PTR [r10],0x0
  411337:	sub    r10,0x1
  41133b:	nop    DWORD PTR [rax+rax*1+0x0]
  411340:	cmp    r9,r10
  411343:	jae    411598 <__swc_fn_4fa09e82_000152_6203dca2+0x958>
  411349:	mov    al,BYTE PTR [r10]
  41134c:	mov    dl,BYTE PTR [r9]
  41134f:	mov    BYTE PTR [r10],dl
  411352:	sub    r10,0x1
  411356:	mov    BYTE PTR [r9],al
  411359:	inc    r9
  41135c:	jmp    411340 <__swc_fn_4fa09e82_000152_6203dca2+0x700>
  41135e:	vcvttsd2si rdx,xmm1
  411363:	mov    r8,rdx
  411366:	vxorpd xmm0,xmm0,xmm0
  41136a:	vcvtsi2sd xmm0,xmm0,rdx
  41136f:	vsubsd xmm0,xmm1,xmm0
  411373:	mov    r9d,0x8
  411379:	vxorpd xmm2,xmm2,xmm2
  41137d:	vcomisd xmm2,xmm0
  411381:	jbe    41138b <__swc_fn_4fa09e82_000152_6203dca2+0x74b>
  411383:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x2295]        # 413620 <__swc_rdata_base_4fa09e82+0x510>
  41138b:	test   r9d,r9d
  41138e:	je     41139a <__swc_fn_4fa09e82_000152_6203dca2+0x75a>
  411390:	vmulsd xmm0,xmm0,xmm14
  411395:	dec    r9d
  411398:	jne    411390 <__swc_fn_4fa09e82_000152_6203dca2+0x750>
  41139a:	vcvttsd2si r9,xmm0
  41139f:	mov    r10,r9
  4113a2:	vxorpd xmm2,xmm2,xmm2
  4113a6:	vcvtsi2sd xmm2,xmm2,r9
  4113ab:	vsubsd xmm0,xmm0,xmm2
  4113af:	vcomisd xmm0,xmm10
  4113b4:	lea    r9,[r9+0x1]
  4113b8:	cmova  r10,r9
  4113bc:	cmp    r10,0x5f5e100
  4113c3:	jne    4113dc <__swc_fn_4fa09e82_000152_6203dca2+0x79c>
  4113c5:	lea    r8,[rdx-0x1]
  4113c9:	vxorpd xmm0,xmm0,xmm0
  4113cd:	vcomisd xmm0,xmm1
  4113d1:	lea    rdx,[rdx+0x1]
  4113d5:	cmovbe r8,rdx
  4113d9:	xor    r10d,r10d
  4113dc:	mov    r9,rcx
  4113df:	test   r8,r8
  4113e2:	jne    411402 <__swc_fn_4fa09e82_000152_6203dca2+0x7c2>
  4113e4:	vxorpd xmm0,xmm0,xmm0
  4113e8:	vcomisd xmm0,xmm1
  4113ec:	jbe    4113f5 <__swc_fn_4fa09e82_000152_6203dca2+0x7b5>
  4113ee:	mov    BYTE PTR [rcx],0x2d
  4113f1:	lea    r9,[rcx+0x1]
  4113f5:	mov    BYTE PTR [r9],0x30
  4113f9:	add    r9,0x1
  4113fd:	jmp    41149b <__swc_fn_4fa09e82_000152_6203dca2+0x85b>
  411402:	mov    r9,rcx
  411405:	mov    rdx,r8
  411408:	nop    DWORD PTR [rax+rax*1+0x0]
  411410:	mov    r11,rdx
  411413:	movabs rdx,0x6666666666666667
  41141d:	mov    r15,rax
  411420:	mov    rax,r11
  411423:	imul   rdx
  411426:	mov    r12,rdx
  411429:	mov    rax,r15
  41142c:	sar    r12,0x2
  411430:	mov    rdx,r12
  411433:	shr    rdx,0x3f
  411437:	add    r12,rdx
  41143a:	mov    rdx,r12
  41143d:	imul   r13,r12,0xa
  411441:	sub    r11,r13
  411444:	mov    r13,QWORD PTR [rip+0x21c5]        # 413610 <__swc_rdata_base_4fa09e82+0x500>
  41144b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411450:	mov    BYTE PTR [r9],r11b
  411453:	lea    r11,[r9+0x1]
  411457:	mov    r9,r11
  41145a:	test   r12,r12
  41145d:	jne    411410 <__swc_fn_4fa09e82_000152_6203dca2+0x7d0>
  41145f:	test   r8,r8
  411462:	jge    41146c <__swc_fn_4fa09e82_000152_6203dca2+0x82c>
  411464:	mov    BYTE PTR [r11],0x2d
  411468:	lea    r9,[r11+0x1]
  41146c:	mov    rdx,r9
  41146f:	mov    BYTE PTR [r9],0x0
  411473:	sub    r9,0x1
  411477:	mov    r8,rcx
  41147a:	cmp    r8,r9
  41147d:	jae    411498 <__swc_fn_4fa09e82_000152_6203dca2+0x858>
  41147f:	nop
  411480:	mov    r11b,BYTE PTR [r9]
  411483:	mov    r12b,BYTE PTR [r8]
  411486:	mov    BYTE PTR [r9],r12b
  411489:	sub    r9,0x1
  41148d:	mov    BYTE PTR [r8],r11b
  411490:	inc    r8
  411493:	cmp    r8,r9
  411496:	jb     411480 <__swc_fn_4fa09e82_000152_6203dca2+0x840>
  411498:	mov    r9,rdx
  41149b:	mov    BYTE PTR [r9],0x2e
  41149f:	add    r9,0x1
  4114a3:	xor    r8d,r8d
  4114a6:	test   r10,r10
  4114a9:	je     4114ef <__swc_fn_4fa09e82_000152_6203dca2+0x8af>
  4114ab:	mov    r11d,0x989680
  4114b1:	cmp    r10,r11
  4114b4:	jge    4114ef <__swc_fn_4fa09e82_000152_6203dca2+0x8af>
  4114b6:	cs nop WORD PTR [rax+rax*1+0x0]
  4114c0:	inc    r8d
  4114c3:	movabs rdx,0x6666666666666667
  4114cd:	mov    r15,rax
  4114d0:	mov    rax,r11
  4114d3:	imul   rdx
  4114d6:	mov    r11,rdx
  4114d9:	mov    rax,r15
  4114dc:	sar    r11,0x2
  4114e0:	mov    rdx,r11
  4114e3:	shr    rdx,0x3f
  4114e7:	add    r11,rdx
  4114ea:	cmp    r10,r11
  4114ed:	jl     4114c0 <__swc_fn_4fa09e82_000152_6203dca2+0x880>
  4114ef:	test   r8d,r8d
  4114f2:	je     41150d <__swc_fn_4fa09e82_000152_6203dca2+0x8cd>
  4114f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4114fe:	xchg   ax,ax
  411500:	mov    BYTE PTR [r9],0x30
  411504:	add    r9,0x1
  411508:	dec    r8d
  41150b:	jne    411500 <__swc_fn_4fa09e82_000152_6203dca2+0x8c0>
  41150d:	mov    r8,r9
  411510:	mov    rdx,r10
  411513:	cs nop WORD PTR [rax+rax*1+0x0]
  41151d:	nop    DWORD PTR [rax]
  411520:	mov    r11,rdx
  411523:	movabs rdx,0x6666666666666667
  41152d:	mov    rax,r11
  411530:	imul   rdx
  411533:	sar    rdx,0x2
  411537:	mov    r12,rdx
  41153a:	shr    rdx,0x3f
  41153e:	add    r12,rdx
  411541:	mov    rdx,r12
  411544:	imul   r13,r12,0xa
  411548:	sub    r11,r13
  41154b:	mov    r13,QWORD PTR [rip+0x20be]        # 413610 <__swc_rdata_base_4fa09e82+0x500>
  411552:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411557:	mov    BYTE PTR [r8],r11b
  41155a:	lea    r11,[r8+0x1]
  41155e:	mov    r8,r11
  411561:	test   r12,r12
  411564:	jne    411520 <__swc_fn_4fa09e82_000152_6203dca2+0x8e0>
  411566:	test   r10,r10
  411569:	jge    411573 <__swc_fn_4fa09e82_000152_6203dca2+0x933>
  41156b:	mov    BYTE PTR [r11],0x2d
  41156f:	lea    r8,[r11+0x1]
  411573:	mov    BYTE PTR [r8],0x0
  411577:	sub    r8,0x1
  41157b:	cmp    r9,r8
  41157e:	jae    411598 <__swc_fn_4fa09e82_000152_6203dca2+0x958>
  411580:	mov    al,BYTE PTR [r8]
  411583:	mov    dl,BYTE PTR [r9]
  411586:	mov    BYTE PTR [r8],dl
  411589:	sub    r8,0x1
  41158d:	mov    BYTE PTR [r9],al
  411590:	inc    r9
  411593:	cmp    r9,r8
  411596:	jb     411580 <__swc_fn_4fa09e82_000152_6203dca2+0x940>
  411598:	xor    eax,eax
  41159a:	test   rcx,rcx
  41159d:	je     4115d0 <__swc_fn_4fa09e82_000152_6203dca2+0x990>
  41159f:	mov    rdx,rcx
  4115a2:	mov    r8b,BYTE PTR [rdx]
  4115a5:	test   r8b,r8b
  4115a8:	je     4115d0 <__swc_fn_4fa09e82_000152_6203dca2+0x990>
  4115aa:	cs nop WORD PTR [rax+rax*1+0x0]
  4115b4:	cs nop WORD PTR [rax+rax*1+0x0]
  4115be:	xchg   ax,ax
  4115c0:	add    rdx,0x1
  4115c4:	add    rax,0x1
  4115c8:	mov    r8b,BYTE PTR [rdx]
  4115cb:	test   r8b,r8b
  4115ce:	jne    4115c0 <__swc_fn_4fa09e82_000152_6203dca2+0x980>
  4115d0:	mov    QWORD PTR [rsp+0x240],rcx
  4115d8:	mov    QWORD PTR [rsp+0x248],rax
  4115e0:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  4115e9:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  4115f2:	lea    rcx,[rsp+0x250]
  4115fa:	call   4103d0 <__swc_fn_4fa09e82_000122_2648f149>
  4115ff:	jmp    411d05 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  411604:	lea    rcx,[rsp+0x260]
  41160c:	vxorps xmm0,xmm0,xmm0
  411610:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  411619:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  411622:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  41162b:	vzeroupper
  41162e:	mov    DWORD PTR [rsp+0x2c0],0x0
  411639:	vmovsd xmm0,QWORD PTR [rdx]
  41163d:	vcomisd xmm0,xmm0
  411641:	setne  dl
  411644:	movzx  edx,dl
  411647:	setp   r8b
  41164b:	movzx  r8d,r8b
  41164f:	or     edx,r8d
  411652:	test   dl,dl
  411654:	je     411661 <__swc_fn_4fa09e82_000152_6203dca2+0xa21>
  411656:	mov    DWORD PTR [rcx],0x6e616e
  41165c:	jmp    411c68 <__swc_fn_4fa09e82_000152_6203dca2+0x1028>
  411661:	vcomisd xmm0,xmm11
  411666:	ja     411677 <__swc_fn_4fa09e82_000152_6203dca2+0xa37>
  411668:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  411671:	vcomisd xmm6,xmm0
  411675:	jbe    41169b <__swc_fn_4fa09e82_000152_6203dca2+0xa5b>
  411677:	vxorpd xmm1,xmm1,xmm1
  41167b:	vcomisd xmm1,xmm0
  41167f:	jbe    411690 <__swc_fn_4fa09e82_000152_6203dca2+0xa50>
  411681:	mov    DWORD PTR [rcx],0x666e692d
  411687:	mov    BYTE PTR [rcx+0x4],0x0
  41168b:	jmp    411c68 <__swc_fn_4fa09e82_000152_6203dca2+0x1028>
  411690:	mov    DWORD PTR [rcx],0x666e69
  411696:	jmp    411c68 <__swc_fn_4fa09e82_000152_6203dca2+0x1028>
  41169b:	vcomisd xmm0,xmm13
  4116a0:	jae    4116ac <__swc_fn_4fa09e82_000152_6203dca2+0xa6c>
  4116a2:	vcomisd xmm12,xmm0
  4116a6:	jbe    411a0e <__swc_fn_4fa09e82_000152_6203dca2+0xdce>
  4116ac:	vmovups xmm1,xmm0
  4116b0:	vxorpd xmm2,xmm2,xmm2
  4116b4:	vcomisd xmm2,xmm0
  4116b8:	jbe    4116c8 <__swc_fn_4fa09e82_000152_6203dca2+0xa88>
  4116ba:	vmovsd xmm0,xmm0,xmm1
  4116be:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x1f5a]        # 413620 <__swc_rdata_base_4fa09e82+0x510>
  4116c6:	jmp    4116cc <__swc_fn_4fa09e82_000152_6203dca2+0xa8c>
  4116c8:	vmovsd xmm0,xmm0,xmm1
  4116cc:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  4116d5:	xor    r8d,r8d
  4116d8:	vcomisd xmm0,xmm6
  4116dc:	jb     4116ee <__swc_fn_4fa09e82_000152_6203dca2+0xaae>
  4116de:	xchg   ax,ax
  4116e0:	vdivsd xmm0,xmm0,xmm6
  4116e4:	add    r8,0x1
  4116e8:	vcomisd xmm0,xmm6
  4116ec:	jae    4116e0 <__swc_fn_4fa09e82_000152_6203dca2+0xaa0>
  4116ee:	mov    r9,rcx
  4116f1:	vxorpd xmm2,xmm2,xmm2
  4116f5:	vcomisd xmm2,xmm1
  4116f9:	jbe    411702 <__swc_fn_4fa09e82_000152_6203dca2+0xac2>
  4116fb:	mov    BYTE PTR [rcx],0x2d
  4116fe:	lea    r9,[rcx+0x1]
  411702:	vcvttsd2si rdx,xmm0
  411707:	mov    r10b,dl
  41170a:	add    r10b,0x30
  41170e:	mov    BYTE PTR [r9],r10b
  411711:	vxorpd xmm1,xmm1,xmm1
  411715:	movzx  edx,dl
  411718:	vcvtsi2sd xmm1,xmm1,rdx
  41171d:	vsubsd xmm0,xmm0,xmm1
  411721:	vmulsd xmm0,xmm0,xmm6
  411725:	mov    BYTE PTR [r9+0x1],0x2e
  41172a:	vcvttsd2si rdx,xmm0
  41172f:	mov    r10b,dl
  411732:	add    r10b,0x30
  411736:	mov    BYTE PTR [r9+0x2],r10b
  41173a:	vxorpd xmm1,xmm1,xmm1
  41173e:	movzx  edx,dl
  411741:	vcvtsi2sd xmm1,xmm1,rdx
  411746:	vsubsd xmm0,xmm0,xmm1
  41174a:	vmulsd xmm0,xmm0,xmm6
  41174e:	vcvttsd2si rdx,xmm0
  411753:	mov    r10b,dl
  411756:	add    r10b,0x30
  41175a:	mov    BYTE PTR [r9+0x3],r10b
  41175e:	vxorpd xmm1,xmm1,xmm1
  411762:	movzx  edx,dl
  411765:	vcvtsi2sd xmm1,xmm1,rdx
  41176a:	vsubsd xmm0,xmm0,xmm1
  41176e:	vmulsd xmm0,xmm0,xmm6
  411772:	vcvttsd2si rdx,xmm0
  411777:	mov    r10b,dl
  41177a:	add    r10b,0x30
  41177e:	mov    BYTE PTR [r9+0x4],r10b
  411782:	vxorpd xmm1,xmm1,xmm1
  411786:	movzx  edx,dl
  411789:	vcvtsi2sd xmm1,xmm1,rdx
  41178e:	vsubsd xmm0,xmm0,xmm1
  411792:	vmulsd xmm0,xmm0,xmm6
  411796:	vcvttsd2si rdx,xmm0
  41179b:	mov    r10b,dl
  41179e:	add    r10b,0x30
  4117a2:	mov    BYTE PTR [r9+0x5],r10b
  4117a6:	vxorpd xmm1,xmm1,xmm1
  4117aa:	movzx  edx,dl
  4117ad:	vcvtsi2sd xmm1,xmm1,rdx
  4117b2:	vsubsd xmm0,xmm0,xmm1
  4117b6:	vmulsd xmm0,xmm0,xmm6
  4117ba:	vcvttsd2si rdx,xmm0
  4117bf:	mov    r10b,dl
  4117c2:	add    r10b,0x30
  4117c6:	mov    BYTE PTR [r9+0x6],r10b
  4117ca:	vxorpd xmm1,xmm1,xmm1
  4117ce:	movzx  edx,dl
  4117d1:	vcvtsi2sd xmm1,xmm1,rdx
  4117d6:	vsubsd xmm0,xmm0,xmm1
  4117da:	vmulsd xmm0,xmm0,xmm6
  4117de:	vcvttsd2si rdx,xmm0
  4117e3:	mov    r10b,dl
  4117e6:	add    r10b,0x30
  4117ea:	mov    BYTE PTR [r9+0x7],r10b
  4117ee:	vxorpd xmm1,xmm1,xmm1
  4117f2:	movzx  edx,dl
  4117f5:	vcvtsi2sd xmm1,xmm1,rdx
  4117fa:	vsubsd xmm0,xmm0,xmm1
  4117fe:	vmulsd xmm0,xmm0,xmm6
  411802:	vcvttsd2si rdx,xmm0
  411807:	mov    r10b,dl
  41180a:	add    r10b,0x30
  41180e:	mov    BYTE PTR [r9+0x8],r10b
  411812:	vxorpd xmm1,xmm1,xmm1
  411816:	movzx  edx,dl
  411819:	vcvtsi2sd xmm1,xmm1,rdx
  41181e:	vsubsd xmm0,xmm0,xmm1
  411822:	vmulsd xmm0,xmm0,xmm6
  411826:	vcvttsd2si rdx,xmm0
  41182b:	mov    r10b,dl
  41182e:	add    r10b,0x30
  411832:	mov    BYTE PTR [r9+0x9],r10b
  411836:	vxorpd xmm1,xmm1,xmm1
  41183a:	movzx  edx,dl
  41183d:	vcvtsi2sd xmm1,xmm1,rdx
  411842:	vsubsd xmm0,xmm0,xmm1
  411846:	vmulsd xmm0,xmm0,xmm6
  41184a:	vcvttsd2si rdx,xmm0
  41184f:	mov    r10b,dl
  411852:	add    r10b,0x30
  411856:	mov    BYTE PTR [r9+0xa],r10b
  41185a:	vxorpd xmm1,xmm1,xmm1
  41185e:	movzx  edx,dl
  411861:	vcvtsi2sd xmm1,xmm1,rdx
  411866:	vsubsd xmm0,xmm0,xmm1
  41186a:	vmulsd xmm0,xmm0,xmm6
  41186e:	vcvttsd2si rdx,xmm0
  411873:	mov    r10b,dl
  411876:	add    r10b,0x30
  41187a:	mov    BYTE PTR [r9+0xb],r10b
  41187e:	lea    r10,[r9+0x4]
  411882:	vxorpd xmm1,xmm1,xmm1
  411886:	movzx  edx,dl
  411889:	vcvtsi2sd xmm1,xmm1,rdx
  41188e:	vsubsd xmm0,xmm0,xmm1
  411892:	vmulsd xmm0,xmm0,xmm6
  411896:	vcvttsd2si rdx,xmm0
  41189b:	mov    r11b,dl
  41189e:	add    r11b,0x30
  4118a2:	mov    BYTE PTR [r9+0xc],r11b
  4118a6:	vxorpd xmm1,xmm1,xmm1
  4118aa:	movzx  edx,dl
  4118ad:	vcvtsi2sd xmm1,xmm1,rdx
  4118b2:	vsubsd xmm0,xmm0,xmm1
  4118b6:	vmulsd xmm0,xmm0,xmm6
  4118ba:	vcvttsd2si rdx,xmm0
  4118bf:	mov    r11b,dl
  4118c2:	add    r11b,0x30
  4118c6:	mov    BYTE PTR [r9+0xd],r11b
  4118ca:	lea    r10,[r10+0x2]
  4118ce:	vxorpd xmm1,xmm1,xmm1
  4118d2:	movzx  edx,dl
  4118d5:	vcvtsi2sd xmm1,xmm1,rdx
  4118da:	vsubsd xmm0,xmm0,xmm1
  4118de:	vmulsd xmm0,xmm0,xmm6
  4118e2:	vcvttsd2si rdx,xmm0
  4118e7:	mov    r11b,dl
  4118ea:	add    r11b,0x30
  4118ee:	mov    BYTE PTR [r9+0xe],r11b
  4118f2:	vxorpd xmm1,xmm1,xmm1
  4118f6:	movzx  edx,dl
  4118f9:	vcvtsi2sd xmm1,xmm1,rdx
  4118fe:	vsubsd xmm0,xmm0,xmm1
  411902:	vmulsd xmm0,xmm0,xmm6
  411906:	vcvttsd2si rdx,xmm0
  41190b:	mov    r11b,dl
  41190e:	add    r11b,0x30
  411912:	mov    BYTE PTR [r9+0xf],r11b
  411916:	lea    r10,[r10+0x2]
  41191a:	lea    r10,[r10+0x2]
  41191e:	lea    r10,[r10+0x2]
  411922:	lea    r10,[r10+0x2]
  411926:	lea    r10,[r10+0x2]
  41192a:	vxorpd xmm1,xmm1,xmm1
  41192e:	movzx  edx,dl
  411931:	vcvtsi2sd xmm1,xmm1,rdx
  411936:	vsubsd xmm0,xmm0,xmm1
  41193a:	vmulsd xmm0,xmm0,xmm6
  41193e:	vcvttsd2si rdx,xmm0
  411943:	mov    r11b,dl
  411946:	add    r11b,0x30
  41194a:	mov    BYTE PTR [r9+0x10],r11b
  41194e:	vxorpd xmm1,xmm1,xmm1
  411952:	movzx  edx,dl
  411955:	vcvtsi2sd xmm1,xmm1,rdx
  41195a:	vsubsd xmm0,xmm0,xmm1
  41195e:	vmulsd xmm0,xmm0,xmm6
  411962:	vcvttsd2si rdx,xmm0
  411967:	add    dl,0x30
  41196a:	mov    BYTE PTR [r9+0x11],dl
  41196e:	mov    BYTE PTR [r10+0x2],0x65
  411973:	lea    r9,[r10+0x3]
  411977:	test   r8,r8
  41197a:	jl     411983 <__swc_fn_4fa09e82_000152_6203dca2+0xd43>
  41197c:	mov    BYTE PTR [r9],0x2b
  411980:	inc    r9
  411983:	mov    r10,r9
  411986:	mov    rdx,r8
  411989:	nop    DWORD PTR [rax+0x0]
  411990:	mov    r11,rdx
  411993:	movabs rdx,0x6666666666666667
  41199d:	mov    rax,r11
  4119a0:	imul   rdx
  4119a3:	sar    rdx,0x2
  4119a7:	mov    r12,rdx
  4119aa:	shr    rdx,0x3f
  4119ae:	add    r12,rdx
  4119b1:	mov    rdx,r12
  4119b4:	imul   r13,r12,0xa
  4119b8:	sub    r11,r13
  4119bb:	mov    r13,QWORD PTR [rip+0x1c4e]        # 413610 <__swc_rdata_base_4fa09e82+0x500>
  4119c2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4119c7:	mov    BYTE PTR [r10],r11b
  4119ca:	lea    r11,[r10+0x1]
  4119ce:	mov    r10,r11
  4119d1:	test   r12,r12
  4119d4:	jne    411990 <__swc_fn_4fa09e82_000152_6203dca2+0xd50>
  4119d6:	test   r8,r8
  4119d9:	jge    4119e3 <__swc_fn_4fa09e82_000152_6203dca2+0xda3>
  4119db:	mov    BYTE PTR [r11],0x2d
  4119df:	lea    r10,[r11+0x1]
  4119e3:	mov    BYTE PTR [r10],0x0
  4119e7:	sub    r10,0x1
  4119eb:	nop    DWORD PTR [rax+rax*1+0x0]
  4119f0:	cmp    r9,r10
  4119f3:	jae    411c68 <__swc_fn_4fa09e82_000152_6203dca2+0x1028>
  4119f9:	mov    al,BYTE PTR [r10]
  4119fc:	mov    dl,BYTE PTR [r9]
  4119ff:	mov    BYTE PTR [r10],dl
  411a02:	sub    r10,0x1
  411a06:	mov    BYTE PTR [r9],al
  411a09:	inc    r9
  411a0c:	jmp    4119f0 <__swc_fn_4fa09e82_000152_6203dca2+0xdb0>
  411a0e:	vcvttsd2si rdx,xmm0
  411a13:	mov    r8,rdx
  411a16:	vxorpd xmm1,xmm1,xmm1
  411a1a:	vcvtsi2sd xmm1,xmm1,rdx
  411a1f:	vsubsd xmm1,xmm0,xmm1
  411a23:	mov    r9d,0x8
  411a29:	vxorpd xmm2,xmm2,xmm2
  411a2d:	vcomisd xmm2,xmm1
  411a31:	ja     411a3e <__swc_fn_4fa09e82_000152_6203dca2+0xdfe>
  411a33:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  411a3c:	jmp    411a4f <__swc_fn_4fa09e82_000152_6203dca2+0xe0f>
  411a3e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1bda]        # 413620 <__swc_rdata_base_4fa09e82+0x510>
  411a46:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  411a4f:	test   r9d,r9d
  411a52:	je     411a69 <__swc_fn_4fa09e82_000152_6203dca2+0xe29>
  411a54:	cs nop WORD PTR [rax+rax*1+0x0]
  411a5e:	xchg   ax,ax
  411a60:	vmulsd xmm1,xmm1,xmm6
  411a64:	dec    r9d
  411a67:	jne    411a60 <__swc_fn_4fa09e82_000152_6203dca2+0xe20>
  411a69:	vcvttsd2si r9,xmm1
  411a6e:	mov    r10,r9
  411a71:	vxorpd xmm2,xmm2,xmm2
  411a75:	vcvtsi2sd xmm2,xmm2,r9
  411a7a:	vsubsd xmm1,xmm1,xmm2
  411a7e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  411a87:	vcomisd xmm1,xmm6
  411a8b:	lea    r9,[r9+0x1]
  411a8f:	cmova  r10,r9
  411a93:	cmp    r10,0x5f5e100
  411a9a:	jne    411ab3 <__swc_fn_4fa09e82_000152_6203dca2+0xe73>
  411a9c:	lea    r8,[rdx-0x1]
  411aa0:	vxorpd xmm1,xmm1,xmm1
  411aa4:	vcomisd xmm1,xmm0
  411aa8:	lea    rdx,[rdx+0x1]
  411aac:	cmovbe r8,rdx
  411ab0:	xor    r10d,r10d
  411ab3:	mov    r9,rcx
  411ab6:	test   r8,r8
  411ab9:	jne    411ad9 <__swc_fn_4fa09e82_000152_6203dca2+0xe99>
  411abb:	vxorpd xmm1,xmm1,xmm1
  411abf:	vcomisd xmm1,xmm0
  411ac3:	jbe    411acc <__swc_fn_4fa09e82_000152_6203dca2+0xe8c>
  411ac5:	mov    BYTE PTR [rcx],0x2d
  411ac8:	lea    r9,[rcx+0x1]
  411acc:	mov    BYTE PTR [r9],0x30
  411ad0:	add    r9,0x1
  411ad4:	jmp    411b6b <__swc_fn_4fa09e82_000152_6203dca2+0xf2b>
  411ad9:	mov    r9,rcx
  411adc:	mov    rdx,r8
  411adf:	nop
  411ae0:	mov    r11,rdx
  411ae3:	movabs rdx,0x6666666666666667
  411aed:	mov    r15,rax
  411af0:	mov    rax,r11
  411af3:	imul   rdx
  411af6:	mov    r12,rdx
  411af9:	mov    rax,r15
  411afc:	sar    r12,0x2
  411b00:	mov    rdx,r12
  411b03:	shr    rdx,0x3f
  411b07:	add    r12,rdx
  411b0a:	mov    rdx,r12
  411b0d:	imul   r13,r12,0xa
  411b11:	sub    r11,r13
  411b14:	mov    r13,QWORD PTR [rip+0x1af5]        # 413610 <__swc_rdata_base_4fa09e82+0x500>
  411b1b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411b20:	mov    BYTE PTR [r9],r11b
  411b23:	lea    r11,[r9+0x1]
  411b27:	mov    r9,r11
  411b2a:	test   r12,r12
  411b2d:	jne    411ae0 <__swc_fn_4fa09e82_000152_6203dca2+0xea0>
  411b2f:	test   r8,r8
  411b32:	jge    411b3c <__swc_fn_4fa09e82_000152_6203dca2+0xefc>
  411b34:	mov    BYTE PTR [r11],0x2d
  411b38:	lea    r9,[r11+0x1]
  411b3c:	mov    rdx,r9
  411b3f:	mov    BYTE PTR [r9],0x0
  411b43:	sub    r9,0x1
  411b47:	mov    r8,rcx
  411b4a:	cmp    r8,r9
  411b4d:	jae    411b68 <__swc_fn_4fa09e82_000152_6203dca2+0xf28>
  411b4f:	nop
  411b50:	mov    r11b,BYTE PTR [r9]
  411b53:	mov    r12b,BYTE PTR [r8]
  411b56:	mov    BYTE PTR [r9],r12b
  411b59:	sub    r9,0x1
  411b5d:	mov    BYTE PTR [r8],r11b
  411b60:	inc    r8
  411b63:	cmp    r8,r9
  411b66:	jb     411b50 <__swc_fn_4fa09e82_000152_6203dca2+0xf10>
  411b68:	mov    r9,rdx
  411b6b:	mov    BYTE PTR [r9],0x2e
  411b6f:	add    r9,0x1
  411b73:	xor    r8d,r8d
  411b76:	test   r10,r10
  411b79:	je     411bbf <__swc_fn_4fa09e82_000152_6203dca2+0xf7f>
  411b7b:	mov    r11d,0x989680
  411b81:	cmp    r10,r11
  411b84:	jge    411bbf <__swc_fn_4fa09e82_000152_6203dca2+0xf7f>
  411b86:	cs nop WORD PTR [rax+rax*1+0x0]
  411b90:	inc    r8d
  411b93:	movabs rdx,0x6666666666666667
  411b9d:	mov    r15,rax
  411ba0:	mov    rax,r11
  411ba3:	imul   rdx
  411ba6:	mov    r11,rdx
  411ba9:	mov    rax,r15
  411bac:	sar    r11,0x2
  411bb0:	mov    rdx,r11
  411bb3:	shr    rdx,0x3f
  411bb7:	add    r11,rdx
  411bba:	cmp    r10,r11
  411bbd:	jl     411b90 <__swc_fn_4fa09e82_000152_6203dca2+0xf50>
  411bbf:	test   r8d,r8d
  411bc2:	je     411bdd <__swc_fn_4fa09e82_000152_6203dca2+0xf9d>
  411bc4:	cs nop WORD PTR [rax+rax*1+0x0]
  411bce:	xchg   ax,ax
  411bd0:	mov    BYTE PTR [r9],0x30
  411bd4:	add    r9,0x1
  411bd8:	dec    r8d
  411bdb:	jne    411bd0 <__swc_fn_4fa09e82_000152_6203dca2+0xf90>
  411bdd:	mov    r8,r9
  411be0:	mov    rdx,r10
  411be3:	cs nop WORD PTR [rax+rax*1+0x0]
  411bed:	nop    DWORD PTR [rax]
  411bf0:	mov    r11,rdx
  411bf3:	movabs rdx,0x6666666666666667
  411bfd:	mov    rax,r11
  411c00:	imul   rdx
  411c03:	sar    rdx,0x2
  411c07:	mov    r12,rdx
  411c0a:	shr    rdx,0x3f
  411c0e:	add    r12,rdx
  411c11:	mov    rdx,r12
  411c14:	imul   r13,r12,0xa
  411c18:	sub    r11,r13
  411c1b:	mov    r13,QWORD PTR [rip+0x19ee]        # 413610 <__swc_rdata_base_4fa09e82+0x500>
  411c22:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411c27:	mov    BYTE PTR [r8],r11b
  411c2a:	lea    r11,[r8+0x1]
  411c2e:	mov    r8,r11
  411c31:	test   r12,r12
  411c34:	jne    411bf0 <__swc_fn_4fa09e82_000152_6203dca2+0xfb0>
  411c36:	test   r10,r10
  411c39:	jge    411c43 <__swc_fn_4fa09e82_000152_6203dca2+0x1003>
  411c3b:	mov    BYTE PTR [r11],0x2d
  411c3f:	lea    r8,[r11+0x1]
  411c43:	mov    BYTE PTR [r8],0x0
  411c47:	sub    r8,0x1
  411c4b:	cmp    r9,r8
  411c4e:	jae    411c68 <__swc_fn_4fa09e82_000152_6203dca2+0x1028>
  411c50:	mov    al,BYTE PTR [r8]
  411c53:	mov    dl,BYTE PTR [r9]
  411c56:	mov    BYTE PTR [r8],dl
  411c59:	sub    r8,0x1
  411c5d:	mov    BYTE PTR [r9],al
  411c60:	inc    r9
  411c63:	cmp    r9,r8
  411c66:	jb     411c50 <__swc_fn_4fa09e82_000152_6203dca2+0x1010>
  411c68:	xor    eax,eax
  411c6a:	test   rcx,rcx
  411c6d:	je     411c90 <__swc_fn_4fa09e82_000152_6203dca2+0x1050>
  411c6f:	mov    rdx,rcx
  411c72:	mov    r8b,BYTE PTR [rdx]
  411c75:	test   r8b,r8b
  411c78:	je     411c90 <__swc_fn_4fa09e82_000152_6203dca2+0x1050>
  411c7a:	nop    WORD PTR [rax+rax*1+0x0]
  411c80:	add    rdx,0x1
  411c84:	add    rax,0x1
  411c88:	mov    r8b,BYTE PTR [rdx]
  411c8b:	test   r8b,r8b
  411c8e:	jne    411c80 <__swc_fn_4fa09e82_000152_6203dca2+0x1040>
  411c90:	mov    QWORD PTR [rsp+0x3f8],rcx
  411c98:	mov    QWORD PTR [rsp+0x400],rax
  411ca0:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  411ca9:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  411cb2:	lea    rcx,[rsp+0x408]
  411cba:	call   4103d0 <__swc_fn_4fa09e82_000122_2648f149>
  411cbf:	jmp    411d05 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  411cc1:	mov    rcx,rdx
  411cc4:	call   4103d0 <__swc_fn_4fa09e82_000122_2648f149>
  411cc9:	jmp    411d05 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  411ccb:	mov    al,BYTE PTR [rdx]
  411ccd:	test   al,al
  411ccf:	je     411cda <__swc_fn_4fa09e82_000152_6203dca2+0x109a>
  411cd1:	lea    rax,[rip+0x1958]        # 413630 <__swc_rdata_base_4fa09e82+0x520>
  411cd8:	jmp    411ce1 <__swc_fn_4fa09e82_000152_6203dca2+0x10a1>
  411cda:	lea    rax,[rip+0x195f]        # 413640 <__swc_rdata_base_4fa09e82+0x530>
  411ce1:	mov    rcx,rax
  411ce4:	call   4103d0 <__swc_fn_4fa09e82_000122_2648f149>
  411ce9:	jmp    411d05 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  411ceb:	lea    rcx,[rip+0x195e]        # 413650 <__swc_rdata_base_4fa09e82+0x540>
  411cf2:	call   4103d0 <__swc_fn_4fa09e82_000122_2648f149>
  411cf7:	jmp    411d05 <__swc_fn_4fa09e82_000152_6203dca2+0x10c5>
  411cf9:	lea    rcx,[rip+0x1950]        # 413650 <__swc_rdata_base_4fa09e82+0x540>
  411d00:	call   4103d0 <__swc_fn_4fa09e82_000122_2648f149>
  411d05:	add    rdi,0x1
  411d09:	sub    rsi,0x1
  411d0d:	vmovups xmm0,xmm12
  411d12:	vmovsd xmm6,QWORD PTR [rip+0x1946]        # 413660 <__swc_rdata_base_4fa09e82+0x550>
  411d1a:	test   rsi,rsi
  411d1d:	jne    410d50 <__swc_fn_4fa09e82_000152_6203dca2+0x110>
  411d23:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  411d2c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  411d35:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  411d3e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411d47:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411d50:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411d59:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411d62:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  411d6b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411d74:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  411d7d:	add    rsp,0x4e8
  411d84:	pop    r15
  411d86:	pop    r13
  411d88:	pop    r12
  411d8a:	pop    rdi
  411d8b:	pop    rsi
  411d8c:	pop    rbx
  411d8d:	ret
