
/workspace/prompt2-20261115/session-combined-micro/base/nbody/nbody:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <getpid@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <getpid@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <munmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <munmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <exit@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <exit@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <pthread_key_create@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <pthread_key_create@GLIBC_2.34>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_setspecific@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <pthread_setspecific@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <syscall@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <syscall@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dladdr@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <dladdr@GLIBC_2.34>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <open@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <open@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <lseek@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <lseek@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <close@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <close@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <mmap@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <mmap@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <malloc@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <malloc@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <madvise@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf9a]        # 413080 <madvise@GLIBC_2.2.5>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <pthread_key_delete@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf92]        # 413088 <pthread_key_delete@GLIBC_2.34>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <gettid@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf8a]        # 413090 <gettid@GLIBC_2.30>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <clock_gettime@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf82]        # 413098 <clock_gettime@GLIBC_2.17>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <flock@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf7a]        # 4130a0 <flock@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <__errno_location@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf72]        # 4130a8 <__errno_location@GLIBC_2.2.5>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <opendir@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf6a]        # 4130b0 <opendir@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <dirfd@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf62]        # 4130b8 <dirfd@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <readdir@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <readdir@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <readlinkat@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <readlinkat@GLIBC_2.4>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <openat@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <openat@GLIBC_2.4>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <closedir@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <closedir@GLIBC_2.2.5>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <memfd_create@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <memfd_create@GLIBC_2.27>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <ftruncate@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <ftruncate@GLIBC_2.2.5>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <write@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <write@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <backtrace@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <backtrace@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <__x86_get_cpuid_feature_leaf@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <free@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <free@GLIBC_2.2.5>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_6b1cf01f_000176_0ce64436+0x1720>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40c9c0 <__swc_fn_6b1cf01f_000121_12b4ed22>
  40724e:	xor    ecx,ecx
  407250:	call   40c0e0 <__swc_fn_6b1cf01f_000094_14db3cf9>
  407255:	call   4118e0 <__swc_fn_6b1cf01f_000176_0ce64436>
  40725a:	call   40eeb0 <__swc_fn_6b1cf01f_000095_337e587a>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_6b1cf01f_000000_46f18a51>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_6b1cf01f_000003_7ab4792e>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_6b1cf01f_000003_7ab4792e+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   409260 <__swc_fn_6b1cf01f_000111_b25e3a45>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_6b1cf01f_000003_7ab4792e+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1cd81]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1cd7a]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_6b1cf01f_000003_7ab4792e+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_6b1cf01f_000003_7ab4792e+0x30>
  4072e6:	lea    rcx,[rip+0x1cd63]        # 424050 <__swc_bss_base_6b1cf01f+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1cd5c]        # 424050 <__swc_bss_base_6b1cf01f+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_6b1cf01f_000003_7ab4792e+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_6b1cf01f_000003_7ab4792e+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_6b1cf01f_000006_a23dca5f>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40d760 <__swc_fn_6b1cf01f_000011_6493fbbc>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_6b1cf01f_000012_c7df5d22>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_6b1cf01f_000006_a23dca5f+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_6b1cf01f_000003_7ab4792e>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_6b1cf01f_000006_a23dca5f+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_6b1cf01f_000009_d7e2bb25>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_6b1cf01f_000009_d7e2bb25+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40a470 <__swc_fn_6b1cf01f_000007_614a4804>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40d750 <__swc_fn_6b1cf01f_000008_4e857afc>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_6b1cf01f_000009_d7e2bb25+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_6b1cf01f_000009_d7e2bb25+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_6b1cf01f_000012_c7df5d22>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_6b1cf01f_000015_07eb9884>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_6b1cf01f_000015_07eb9884+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_6b1cf01f_000015_07eb9884+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_6b1cf01f_000015_07eb9884+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_6b1cf01f_000015_07eb9884+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40d8c0 <__swc_fn_6b1cf01f_000017_4df2d1a0>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_6b1cf01f_000015_07eb9884+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1cb3d]        # 424058 <__swc_bss_base_6b1cf01f+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1cb36]        # 424058 <__swc_bss_base_6b1cf01f+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_6b1cf01f_000015_07eb9884+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_6b1cf01f_000015_07eb9884+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40d760 <__swc_fn_6b1cf01f_000011_6493fbbc>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_6b1cf01f_000015_07eb9884+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   40c6e0 <__swc_fn_6b1cf01f_000112_759e9ceb>
  407569:	lea    rcx,[rip+0x1cad8]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1cad1]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_6b1cf01f_000015_07eb9884+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_6b1cf01f_000015_07eb9884+0x110>
  407598:	lea    rcx,[rip+0x1cac1]        # 424060 <__swc_bss_base_6b1cf01f+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1caba]        # 424060 <__swc_bss_base_6b1cf01f+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_6b1cf01f_000015_07eb9884+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_6b1cf01f_000015_07eb9884+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_6b1cf01f_000018_7d1e8a10>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_6b1cf01f_000015_07eb9884+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_6b1cf01f_000018_7d1e8a10>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_6b1cf01f_000018_7d1e8a10+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_6b1cf01f_000018_7d1e8a10+0x10>

0000000000407630 <__swc_fn_6b1cf01f_000021_491ac000>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_6b1cf01f_000015_07eb9884>
  40763e:	lea    rdi,[rip+0x1cbab]        # 4241f0 <__swc_bss_base_6b1cf01f+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   4098c0 <__swc_fn_6b1cf01f_000135_e3032dc2>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1cb94]        # 4241f8 <__swc_bss_base_6b1cf01f+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1cb89],rsi        # 4241f8 <__swc_bss_base_6b1cf01f+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_6b1cf01f_000024_4aca8b9e>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_6b1cf01f_000027_4aca8b9e>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_6b1cf01f_000030_06a93956>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_6b1cf01f_000030_06a93956+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1a92c]        # 422000 <__swc_data_base_6b1cf01f>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_6b1cf01f_000030_06a93956+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_6b1cf01f_000030_06a93956+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_6b1cf01f_000030_06a93956+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40da80 <__swc_fn_6b1cf01f_000032_84881cd8>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_6b1cf01f_000030_06a93956+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_6b1cf01f_000036_8d895ba1>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_6b1cf01f_000030_06a93956+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_6b1cf01f_000042_bab03645>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_6b1cf01f_000033_7ca1566d>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40a920 <__swc_fn_6b1cf01f_000031_90860ff2>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   409740 <__swc_fn_6b1cf01f_000129_74b163fe>
  407734:	mov    rcx,rsi
  407737:	call   40da80 <__swc_fn_6b1cf01f_000032_84881cd8>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_6b1cf01f_000036_8d895ba1>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_6b1cf01f_000039_40d1e569>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_6b1cf01f_000039_40d1e569+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_6b1cf01f_000039_40d1e569+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_6b1cf01f_000039_40d1e569+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_6b1cf01f_000039_40d1e569+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_6b1cf01f_000039_40d1e569+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   409340 <__swc_fn_6b1cf01f_000114_27d95464>
  4077ca:	lea    rcx,[rip+0x1c877]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1c870]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_6b1cf01f_000039_40d1e569+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_6b1cf01f_000039_40d1e569+0x90>
  4077f8:	lea    rcx,[rip+0x1c861]        # 424060 <__swc_bss_base_6b1cf01f+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1c85a]        # 424060 <__swc_bss_base_6b1cf01f+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_6b1cf01f_000039_40d1e569+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_6b1cf01f_000039_40d1e569+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_6b1cf01f_000042_bab03645>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_6b1cf01f_000042_bab03645+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40e050 <__swc_fn_6b1cf01f_000059_3ca3ac64>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   4098c0 <__swc_fn_6b1cf01f_000135_e3032dc2>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_6b1cf01f_000042_bab03645+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_6b1cf01f_000042_bab03645+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_6b1cf01f_000009_d7e2bb25>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_6b1cf01f_000042_bab03645+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40d780 <__swc_fn_6b1cf01f_000014_afb279e2>
  40791e:	jmp    407941 <__swc_fn_6b1cf01f_000042_bab03645+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_6b1cf01f_000042_bab03645+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_6b1cf01f_000042_bab03645+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_6b1cf01f_000042_bab03645+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40aae0 <__swc_fn_6b1cf01f_000043_957e4917>
  407997:	mov    rcx,rdi
  40799a:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_6b1cf01f_000039_40d1e569>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_6b1cf01f_000045_1fe0f4e2>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_6b1cf01f_000045_1fe0f4e2+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_6b1cf01f_000045_1fe0f4e2+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_6b1cf01f_000045_1fe0f4e2+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_6b1cf01f_000045_1fe0f4e2+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   4098c0 <__swc_fn_6b1cf01f_000135_e3032dc2>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_6b1cf01f_000045_1fe0f4e2+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_6b1cf01f_000045_1fe0f4e2+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_6b1cf01f_000045_1fe0f4e2+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_6b1cf01f_000045_1fe0f4e2+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_6b1cf01f_000009_d7e2bb25>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_6b1cf01f_000045_1fe0f4e2+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_6b1cf01f_000045_1fe0f4e2+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_6b1cf01f_000045_1fe0f4e2+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_6b1cf01f_000045_1fe0f4e2+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_6b1cf01f_000045_1fe0f4e2+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40a520 <__swc_fn_6b1cf01f_000013_9ba72deb>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_6b1cf01f_000045_1fe0f4e2+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_6b1cf01f_000045_1fe0f4e2+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_6b1cf01f_000045_1fe0f4e2+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_6b1cf01f_000045_1fe0f4e2+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40d900 <__swc_fn_6b1cf01f_000020_a66e8b97>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_6b1cf01f_000045_1fe0f4e2+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40a520 <__swc_fn_6b1cf01f_000013_9ba72deb>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_6b1cf01f_000045_1fe0f4e2+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_6b1cf01f_000021_491ac000>
  407c07:	mov    rcx,r14
  407c0a:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_6b1cf01f_000045_1fe0f4e2+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_6b1cf01f_000045_1fe0f4e2+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_6b1cf01f_000045_1fe0f4e2+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_6b1cf01f_000048_c877e9d2>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_6b1cf01f_000048_c877e9d2+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_6b1cf01f_000048_c877e9d2+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_6b1cf01f_000048_c877e9d2+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_6b1cf01f_000048_c877e9d2+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40dcb0 <__swc_fn_6b1cf01f_000047_bc5ec610>
  407d14:	jmp    407ce0 <__swc_fn_6b1cf01f_000048_c877e9d2+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_6b1cf01f_000048_c877e9d2+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_6b1cf01f_000048_c877e9d2+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_6b1cf01f_000048_c877e9d2+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_6b1cf01f_000048_c877e9d2+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_6b1cf01f_000048_c877e9d2+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_6b1cf01f_000048_c877e9d2+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_6b1cf01f_000048_c877e9d2+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_6b1cf01f_000051_f7021588>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_6b1cf01f_000051_f7021588+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_6b1cf01f_000051_f7021588+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_6b1cf01f_000051_f7021588+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_6b1cf01f_000051_f7021588+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40dc10 <__swc_fn_6b1cf01f_000044_9c2ade9b>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40d780 <__swc_fn_6b1cf01f_000014_afb279e2>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_6b1cf01f_000054_ae20ea33>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   4098c0 <__swc_fn_6b1cf01f_000135_e3032dc2>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_6b1cf01f_000054_ae20ea33+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_6b1cf01f_000054_ae20ea33+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_6b1cf01f_000054_ae20ea33+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_6b1cf01f_000057_5b81d8b6>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_6b1cf01f_000060_e6407a0a>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_6b1cf01f_000060_e6407a0a+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_6b1cf01f_000039_40d1e569>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_6b1cf01f_000060_e6407a0a+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_6b1cf01f_000063_c8a062d6>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40ae60 <__swc_fn_6b1cf01f_000052_c7484fb0>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_6b1cf01f_000054_ae20ea33>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_6b1cf01f_000063_c8a062d6+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_6b1cf01f_000063_c8a062d6+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40af80 <__swc_fn_6b1cf01f_000058_8bd8d1d5>
  407f7f:	mov    rcx,rsi
  407f82:	call   40abc0 <__swc_fn_6b1cf01f_000049_2ff013cc>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_6b1cf01f_000066_254b71af>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_6b1cf01f_000066_254b71af+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1c049]        # 424070 <__swc_bss_base_6b1cf01f+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1c04b]        # 424080 <__swc_bss_base_6b1cf01f+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_6b1cf01f_000066_254b71af+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_6b1cf01f_000066_254b71af+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40a850 <__swc_fn_6b1cf01f_000022_3a2e2048>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_6b1cf01f_000066_254b71af+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_6b1cf01f_000063_c8a062d6>
  40808f:	jmp    408122 <__swc_fn_6b1cf01f_000066_254b71af+0x192>
  408094:	lea    rax,[rip+0x19f65]        # 422000 <__swc_data_base_6b1cf01f>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_6b1cf01f_000066_254b71af+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_6b1cf01f_000066_254b71af+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_6b1cf01f_000066_254b71af+0x135>
  4080b8:	call   40a920 <__swc_fn_6b1cf01f_000031_90860ff2>
  4080bd:	mov    rcx,rax
  4080c0:	call   40fc80 <__swc_fn_6b1cf01f_000128_41c3251c>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_6b1cf01f_000066_254b71af+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_6b1cf01f_000066_254b71af+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_6b1cf01f_000066_254b71af+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40dcb0 <__swc_fn_6b1cf01f_000047_bc5ec610>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_6b1cf01f_000066_254b71af+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_6b1cf01f_000051_f7021588>
  408115:	jmp    408122 <__swc_fn_6b1cf01f_000066_254b71af+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40a490 <__swc_fn_6b1cf01f_000010_395bb04b>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_6b1cf01f_000069_e681a956>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_6b1cf01f_000036_8d895ba1>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_6b1cf01f_000069_e681a956+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1c09a]        # 424240 <__swc_bss_base_6b1cf01f+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_6b1cf01f_000069_e681a956+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   4098c0 <__swc_fn_6b1cf01f_000135_e3032dc2>
  4081b5:	mov    rcx,rsi
  4081b8:	call   40e480 <__swc_fn_6b1cf01f_000068_7d4c42bf>
  4081bd:	mov    rcx,rsi
  4081c0:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_6b1cf01f_000072_bfa08900>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40e1d0 <__swc_fn_6b1cf01f_000065_f9f4b610>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_6b1cf01f_000075_524b0734>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   40e480 <__swc_fn_6b1cf01f_000068_7d4c42bf>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_6b1cf01f_000078_a120bd2b>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_6b1cf01f_000078_a120bd2b+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_6b1cf01f_000078_a120bd2b+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_6b1cf01f_000081_c25a0e73>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_6b1cf01f_000084_ddf2b8a1>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_6b1cf01f_000090_a2d50c23>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_6b1cf01f_000084_ddf2b8a1+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_6b1cf01f_000084_ddf2b8a1+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_6b1cf01f_000084_ddf2b8a1+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_6b1cf01f_000084_ddf2b8a1+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_6b1cf01f_000090_a2d50c23>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_6b1cf01f_000084_ddf2b8a1+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_6b1cf01f_000084_ddf2b8a1+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_6b1cf01f_000084_ddf2b8a1+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_6b1cf01f_000084_ddf2b8a1+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_6b1cf01f_000084_ddf2b8a1+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_6b1cf01f_000084_ddf2b8a1+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_6b1cf01f_000084_ddf2b8a1+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_6b1cf01f_000084_ddf2b8a1+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_6b1cf01f_000084_ddf2b8a1+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_6b1cf01f_000084_ddf2b8a1+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40bf60 <__swc_fn_6b1cf01f_000082_754dcd57>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_6b1cf01f_000084_ddf2b8a1+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_6b1cf01f_000084_ddf2b8a1+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_6b1cf01f_000084_ddf2b8a1+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40bf60 <__swc_fn_6b1cf01f_000082_754dcd57>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_6b1cf01f_000084_ddf2b8a1+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_6b1cf01f_000084_ddf2b8a1>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_6b1cf01f_000084_ddf2b8a1+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_6b1cf01f_000084_ddf2b8a1+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_6b1cf01f_000087_ea575bb3>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_6b1cf01f_000090_a2d50c23>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_6b1cf01f_000087_ea575bb3+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   40e8e0 <__swc_fn_6b1cf01f_000086_c45095aa>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_6b1cf01f_000087_ea575bb3+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_6b1cf01f_000087_ea575bb3+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_6b1cf01f_000087_ea575bb3+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40bf60 <__swc_fn_6b1cf01f_000082_754dcd57>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_6b1cf01f_000087_ea575bb3+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_6b1cf01f_000087_ea575bb3>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_6b1cf01f_000087_ea575bb3+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_6b1cf01f_000087_ea575bb3+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_6b1cf01f_000090_a2d50c23>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_6b1cf01f_000090_a2d50c23+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_6b1cf01f_000090_a2d50c23+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_6b1cf01f_000090_a2d50c23+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_6b1cf01f_000090_a2d50c23+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40bf60 <__swc_fn_6b1cf01f_000082_754dcd57>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40bf60 <__swc_fn_6b1cf01f_000082_754dcd57>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_6b1cf01f_000090_a2d50c23+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_6b1cf01f_000090_a2d50c23+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_6b1cf01f_000090_a2d50c23+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_6b1cf01f_000090_a2d50c23+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_6b1cf01f_000090_a2d50c23>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_6b1cf01f_000090_a2d50c23+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_6b1cf01f_000090_a2d50c23+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_6b1cf01f_000090_a2d50c23+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_6b1cf01f_000090_a2d50c23+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_6b1cf01f_000090_a2d50c23+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_6b1cf01f_000090_a2d50c23+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_6b1cf01f_000090_a2d50c23+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_6b1cf01f_000090_a2d50c23+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_6b1cf01f_000090_a2d50c23+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_6b1cf01f_000090_a2d50c23+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_6b1cf01f_000090_a2d50c23+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_6b1cf01f_000090_a2d50c23+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_6b1cf01f_000090_a2d50c23+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_6b1cf01f_000090_a2d50c23+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_6b1cf01f_000090_a2d50c23+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_6b1cf01f_000090_a2d50c23+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   409de0 <__swc_fn_6b1cf01f_000147_32a497f3>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_6b1cf01f_000090_a2d50c23+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_6b1cf01f_000090_a2d50c23>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_6b1cf01f_000090_a2d50c23+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_6b1cf01f_000090_a2d50c23+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_6b1cf01f_000090_a2d50c23+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   409de0 <__swc_fn_6b1cf01f_000147_32a497f3>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   409de0 <__swc_fn_6b1cf01f_000147_32a497f3>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_6b1cf01f_000093_f8c16535>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40c090 <__swc_fn_6b1cf01f_000091_3d2f5a0d>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_6b1cf01f_000093_f8c16535+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_6b1cf01f_000093_f8c16535+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   40fe20 <__swc_fn_6b1cf01f_000137_a4ba10ed>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_6b1cf01f_000093_f8c16535+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0xa872]        # 4131c0 <__swc_rdata_base_6b1cf01f+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   40f940 <__swc_fn_6b1cf01f_000116_035d76a1>
  408959:	call   40c910 <__swc_fn_6b1cf01f_000118_7f430081>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_6b1cf01f_000096_ad982b35>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40896f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408975:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40897b:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  408981:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  408987:	mov    QWORD PTR [rsp+0x48],rdx
  40898c:	mov    rax,r8
  40898f:	cmp    r8,0x1
  408993:	mov    edx,0x1
  408998:	cmovb  rax,rdx
  40899c:	mov    QWORD PTR [rsp+0x50],rax
  4089a1:	mov    rbx,QWORD PTR [rcx+0x8]
  4089a5:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a9:	mov    rcx,QWORD PTR [rcx]
  4089ac:	lea    rdx,[rsp+0x8]
  4089b1:	call   rbx
  4089b3:	add    rsp,0x70
  4089b7:	pop    rbx
  4089b8:	ret
  4089b9:	add    BYTE PTR [rax],al
  4089bb:	add    BYTE PTR [rax],al
  4089bd:	add    BYTE PTR [rax],al
	...

00000000004089c0 <__swc_fn_6b1cf01f_000099_b4c6da83>:
  4089c0:	push   rbx
  4089c1:	push   rsi
  4089c2:	push   rdi
  4089c3:	sub    rsp,0x30
  4089c7:	mov    rbx,rcx
  4089ca:	test   rcx,rcx
  4089cd:	je     4089e2 <__swc_fn_6b1cf01f_000099_b4c6da83+0x22>
  4089cf:	mov    rcx,rbx
  4089d2:	mov    edx,0x1
  4089d7:	call   408200 <__swc_fn_6b1cf01f_000078_a120bd2b>
  4089dc:	cmp    rax,0x1
  4089e0:	je     4089ea <__swc_fn_6b1cf01f_000099_b4c6da83+0x2a>
  4089e2:	add    rsp,0x30
  4089e6:	pop    rdi
  4089e7:	pop    rsi
  4089e8:	pop    rbx
  4089e9:	ret
  4089ea:	lea    rsi,[rsp+0x8]
  4089ef:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089f4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089fa:	lea    rax,[rsp+0x18]
  4089ff:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  408a04:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408a0a:	mov    rcx,QWORD PTR [rsp+0x20]
  408a0f:	test   rcx,rcx
  408a12:	je     408a28 <__swc_fn_6b1cf01f_000099_b4c6da83+0x68>
  408a14:	test   DWORD PTR [rcx+0x28],0x400000
  408a1b:	je     408a28 <__swc_fn_6b1cf01f_000099_b4c6da83+0x68>
  408a1d:	mov    rdx,QWORD PTR [rcx+0x30]
  408a21:	test   rdx,rdx
  408a24:	cmovne rcx,rdx
  408a28:	mov    edi,DWORD PTR [rcx+0x20]
  408a2b:	mov    rcx,rax
  408a2e:	call   40c270 <__swc_fn_6b1cf01f_000100_3ed08774>
  408a33:	mov    rcx,rsi
  408a36:	mov    rdx,QWORD PTR [rsp+0x18]
  408a3b:	mov    r8,rdi
  408a3e:	call   408960 <__swc_fn_6b1cf01f_000096_ad982b35>
  408a43:	mov    rcx,QWORD PTR [rbx+0x28]
  408a47:	call   40eec0 <__swc_fn_6b1cf01f_000098_00f01091>
  408a4c:	mov    rcx,rsi
  408a4f:	mov    rdx,rbx
  408a52:	mov    r8d,0x30
  408a58:	call   408960 <__swc_fn_6b1cf01f_000096_ad982b35>
  408a5d:	add    rsp,0x30
  408a61:	pop    rdi
  408a62:	pop    rsi
  408a63:	pop    rbx
  408a64:	ret
	...

0000000000408a80 <__swc_fn_6b1cf01f_000102_e9fdc18e>:
  408a80:	push   rbp
  408a81:	push   rbx
  408a82:	push   rsi
  408a83:	push   rdi
  408a84:	push   r12
  408a86:	push   r13
  408a88:	push   r14
  408a8a:	push   r15
  408a8c:	sub    rsp,0x500
  408a93:	mov    rbp,rsp
  408a96:	mov    rbx,rsp
  408a99:	mov    rsi,rdx
  408a9c:	mov    rdi,rcx
  408a9f:	mov    rcx,QWORD PTR [rip+0x1e29a]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  408aa6:	test   rcx,rcx
  408aa9:	jne    408ac3 <__swc_fn_6b1cf01f_000102_e9fdc18e+0x43>
  408aab:	sub    rsp,0x8
  408aaf:	call   40a1d0 <__swc_fn_6b1cf01f_000165_cf398896>
  408ab4:	add    rsp,0x8
  408ab8:	lea    rcx,[rax+0x1]
  408abc:	mov    QWORD PTR [rip+0x1e27d],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  408ac3:	dec    rcx
  408ac6:	sub    rsp,0x8
  408aca:	call   411740 <__swc_fn_6b1cf01f_000167_fce60b2b>
  408acf:	add    rsp,0x8
  408ad3:	mov    r12,rax
  408ad6:	mov    QWORD PTR [rsp+0x4f0],rax
  408ade:	lea    rax,[rip+0xa81b]        # 413300 <__swc_rdata_base_6b1cf01f+0x1f0>
  408ae5:	sub    rsp,0x20
  408ae9:	mov    rcx,rsp
  408aec:	mov    QWORD PTR [rcx],rax
  408aef:	lea    r13,[rip+0xa81a]        # 413310 <__swc_rdata_base_6b1cf01f+0x200>
  408af6:	mov    QWORD PTR [rcx+0x8],r13
  408afa:	mov    QWORD PTR [rcx+0x10],rsp
  408afe:	mov    QWORD PTR [rcx+0x18],0x1
  408b06:	lea    rcx,[rsp+0x10]
  408b0b:	sub    rsp,0x8
  408b0f:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  408b14:	add    rsp,0x8
  408b18:	add    rsp,0x20
  408b1c:	lea    rax,[rip+0xa835]        # 413358 <__swc_rdata_base_6b1cf01f+0x248>
  408b23:	sub    rsp,0x20
  408b27:	mov    rcx,rsp
  408b2a:	mov    QWORD PTR [rcx],rax
  408b2d:	mov    QWORD PTR [rcx+0x8],r13
  408b31:	mov    QWORD PTR [rcx+0x10],rsp
  408b35:	mov    QWORD PTR [rcx+0x18],0x1
  408b3d:	lea    rcx,[rsp+0x10]
  408b42:	sub    rsp,0x8
  408b46:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  408b4b:	add    rsp,0x8
  408b4f:	add    rsp,0x20
  408b53:	lea    r14,[rip+0xa80e]        # 413368 <__swc_rdata_base_6b1cf01f+0x258>
  408b5a:	sub    rsp,0x50
  408b5e:	mov    rax,rsp
  408b61:	vmovups xmm0,XMMWORD PTR [rip+0xa937]        # 4134a0 <__swc_rdata_base_6b1cf01f+0x390>
  408b69:	vmovups XMMWORD PTR [rax],xmm0
  408b6d:	mov    QWORD PTR [rax+0x10],rsp
  408b71:	mov    QWORD PTR [rax+0x18],r13
  408b75:	mov    QWORD PTR [rax+0x20],rdi
  408b79:	lea    rdi,[rip+0xa7f8]        # 413378 <__swc_rdata_base_6b1cf01f+0x268>
  408b80:	mov    QWORD PTR [rax+0x28],rdi
  408b84:	mov    QWORD PTR [rax+0x30],r14
  408b88:	mov    QWORD PTR [rax+0x38],r13
  408b8c:	lea    rcx,[rsp+0x10]
  408b91:	mov    QWORD PTR [rax+0x40],rcx
  408b95:	mov    QWORD PTR [rax+0x48],0x3
  408b9d:	lea    rcx,[rsp+0x40]
  408ba2:	sub    rsp,0x8
  408ba6:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  408bab:	add    rsp,0x8
  408baf:	add    rsp,0x50
  408bb3:	lea    rax,[rip+0xa806]        # 4133c0 <__swc_rdata_base_6b1cf01f+0x2b0>
  408bba:	sub    rsp,0x20
  408bbe:	mov    rcx,rsp
  408bc1:	mov    QWORD PTR [rcx],rax
  408bc4:	mov    QWORD PTR [rcx+0x8],r13
  408bc8:	mov    QWORD PTR [rcx+0x10],rsp
  408bcc:	mov    QWORD PTR [rcx+0x18],0x1
  408bd4:	lea    rcx,[rsp+0x10]
  408bd9:	sub    rsp,0x8
  408bdd:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  408be2:	add    rsp,0x8
  408be6:	add    rsp,0x20
  408bea:	mov    eax,DWORD PTR [rsi+0x20]
  408bed:	mov    ecx,DWORD PTR [rsi+0x24]
  408bf0:	sub    rsp,0xa0
  408bf7:	mov    rdx,rsp
  408bfa:	mov    QWORD PTR [rdx+0x30],rsi
  408bfe:	mov    QWORD PTR [rdx+0x38],rdi
  408c02:	vmovups xmm0,XMMWORD PTR [rip+0xa82e]        # 413438 <__swc_rdata_base_6b1cf01f+0x328>
  408c0a:	vmovups XMMWORD PTR [rdx],xmm0
  408c0e:	mov    QWORD PTR [rdx+0x40],rsp
  408c12:	mov    QWORD PTR [rdx+0x48],r13
  408c16:	mov    DWORD PTR [rdx+0x10],eax
  408c19:	lea    rax,[rsp+0x10]
  408c1e:	mov    QWORD PTR [rdx+0x50],rax
  408c22:	lea    rax,[rip+0xa7a7]        # 4133d0 <__swc_rdata_base_6b1cf01f+0x2c0>
  408c29:	mov    QWORD PTR [rdx+0x58],rax
  408c2d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c32:	lea    r8,[rsp+0x18]
  408c37:	mov    QWORD PTR [rdx+0x60],r8
  408c3b:	mov    QWORD PTR [rdx+0x68],r13
  408c3f:	mov    DWORD PTR [rdx+0x28],ecx
  408c42:	lea    rcx,[rdx+0x28]
  408c46:	mov    QWORD PTR [rdx+0x70],rcx
  408c4a:	mov    QWORD PTR [rdx+0x78],rax
  408c4e:	mov    QWORD PTR [rdx+0x80],r14
  408c55:	mov    QWORD PTR [rdx+0x88],r13
  408c5c:	lea    rax,[rdx+0x30]
  408c60:	mov    QWORD PTR [rdx+0x90],rax
  408c67:	mov    QWORD PTR [rdx+0x98],0x6
  408c72:	lea    rcx,[rdx+0x90]
  408c79:	sub    rsp,0x8
  408c7d:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  408c82:	add    rsp,0x8
  408c86:	add    rsp,0xa0
  408c8d:	sub    rsp,0x20
  408c91:	mov    rax,rsp
  408c94:	mov    QWORD PTR [rax],r14
  408c97:	mov    QWORD PTR [rax+0x8],r13
  408c9b:	mov    QWORD PTR [rax+0x10],rsp
  408c9f:	mov    QWORD PTR [rax+0x18],0x1
  408ca7:	lea    rcx,[rsp+0x10]
  408cac:	sub    rsp,0x8
  408cb0:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  408cb5:	add    rsp,0x8
  408cb9:	add    rsp,0x20
  408cbd:	mov    eax,DWORD PTR [r12+0x9ac]
  408cc5:	test   eax,eax
  408cc7:	je     408f00 <__swc_fn_6b1cf01f_000102_e9fdc18e+0x480>
  408ccd:	lea    rax,[rip+0xa744]        # 413418 <__swc_rdata_base_6b1cf01f+0x308>
  408cd4:	sub    rsp,0x20
  408cd8:	mov    rcx,rsp
  408cdb:	mov    QWORD PTR [rcx],rax
  408cde:	mov    QWORD PTR [rcx+0x8],r13
  408ce2:	mov    QWORD PTR [rcx+0x10],rsp
  408ce6:	mov    QWORD PTR [rcx+0x18],0x1
  408cee:	lea    rcx,[rsp+0x10]
  408cf3:	sub    rsp,0x8
  408cf7:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  408cfc:	add    rsp,0x8
  408d00:	add    rsp,0x20
  408d04:	mov    eax,DWORD PTR [r12+0x9ac]
  408d0c:	dec    eax
  408d0e:	mov    esi,eax
  408d10:	test   esi,esi
  408d12:	jl     408ed0 <__swc_fn_6b1cf01f_000102_e9fdc18e+0x450>
  408d18:	jmp    408d24 <__swc_fn_6b1cf01f_000102_e9fdc18e+0x2a4>
  408d1a:	nop    WORD PTR [rax+rax*1+0x0]
  408d20:	dec    esi
  408d22:	jmp    408d10 <__swc_fn_6b1cf01f_000102_e9fdc18e+0x290>
  408d24:	lea    rax,[rip+0xa6fd]        # 413428 <__swc_rdata_base_6b1cf01f+0x318>
  408d2b:	sub    rsp,0x20
  408d2f:	mov    rcx,rsp
  408d32:	mov    QWORD PTR [rcx],rax
  408d35:	mov    QWORD PTR [rcx+0x8],r13
  408d39:	mov    QWORD PTR [rcx+0x10],rsp
  408d3d:	mov    QWORD PTR [rcx+0x18],0x1
  408d45:	lea    rcx,[rsp+0x10]
  408d4a:	sub    rsp,0x8
  408d4e:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  408d53:	add    rsp,0x8
  408d57:	add    rsp,0x20
  408d5b:	movsxd rax,esi
  408d5e:	imul   r15,rax,0x30
  408d62:	add    r15,r12
  408d65:	add    r15,0xf8
  408d6c:	sub    rsp,0x20
  408d70:	mov    rax,rsp
  408d73:	mov    QWORD PTR [rax],r15
  408d76:	mov    QWORD PTR [rax+0x8],rdi
  408d7a:	mov    QWORD PTR [rax+0x10],rsp
  408d7e:	mov    QWORD PTR [rax+0x18],0x1
  408d86:	lea    rcx,[rsp+0x10]
  408d8b:	sub    rsp,0x8
  408d8f:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  408d94:	add    rsp,0x8
  408d98:	add    rsp,0x20
  408d9c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408da4:	lea    rsi,[rip+0xa68d]        # 413438 <__swc_rdata_base_6b1cf01f+0x328>
  408dab:	sub    rsp,0x20
  408daf:	mov    rax,rsp
  408db2:	mov    QWORD PTR [rax],rsi
  408db5:	mov    QWORD PTR [rax+0x8],r13
  408db9:	mov    QWORD PTR [rax+0x10],rsp
  408dbd:	mov    QWORD PTR [rax+0x18],0x1
  408dc5:	lea    rcx,[rsp+0x10]
  408dca:	sub    rsp,0x8
  408dce:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  408dd3:	add    rsp,0x8
  408dd7:	add    rsp,0x20
  408ddb:	sub    rsp,0x30
  408ddf:	mov    rax,rsp
  408de2:	mov    ecx,DWORD PTR [r15+0x20]
  408de6:	mov    QWORD PTR [rax],rcx
  408de9:	mov    QWORD PTR [rax+0x8],rsp
  408ded:	lea    rdi,[rip+0xa654]        # 413448 <__swc_rdata_base_6b1cf01f+0x338>
  408df4:	mov    QWORD PTR [rax+0x10],rdi
  408df8:	lea    rcx,[rsp+0x8]
  408dfd:	mov    QWORD PTR [rax+0x18],rcx
  408e01:	mov    QWORD PTR [rax+0x20],0x1
  408e09:	lea    rcx,[rsp+0x18]
  408e0e:	sub    rsp,0x8
  408e12:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  408e17:	add    rsp,0x8
  408e1b:	add    rsp,0x30
  408e1f:	sub    rsp,0x20
  408e23:	mov    rax,rsp
  408e26:	mov    QWORD PTR [rax],rsi
  408e29:	mov    QWORD PTR [rax+0x8],r13
  408e2d:	mov    QWORD PTR [rax+0x10],rsp
  408e31:	mov    QWORD PTR [rax+0x18],0x1
  408e39:	lea    rcx,[rsp+0x10]
  408e3e:	sub    rsp,0x8
  408e42:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  408e47:	add    rsp,0x8
  408e4b:	add    rsp,0x20
  408e4f:	sub    rsp,0x30
  408e53:	mov    rax,rsp
  408e56:	mov    ecx,DWORD PTR [r15+0x24]
  408e5a:	mov    QWORD PTR [rax],rcx
  408e5d:	mov    QWORD PTR [rax+0x8],rsp
  408e61:	mov    QWORD PTR [rax+0x10],rdi
  408e65:	lea    rcx,[rsp+0x8]
  408e6a:	mov    QWORD PTR [rax+0x18],rcx
  408e6e:	mov    QWORD PTR [rax+0x20],0x1
  408e76:	lea    rcx,[rsp+0x18]
  408e7b:	sub    rsp,0x8
  408e7f:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  408e84:	add    rsp,0x8
  408e88:	add    rsp,0x30
  408e8c:	sub    rsp,0x20
  408e90:	mov    rax,rsp
  408e93:	mov    QWORD PTR [rax],r14
  408e96:	mov    QWORD PTR [rax+0x8],r13
  408e9a:	mov    QWORD PTR [rax+0x10],rsp
  408e9e:	mov    QWORD PTR [rax+0x18],0x1
  408ea6:	lea    rcx,[rsp+0x10]
  408eab:	sub    rsp,0x8
  408eaf:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  408eb4:	add    rsp,0x8
  408eb8:	add    rsp,0x20
  408ebc:	lea    rdi,[rip+0xa4b5]        # 413378 <__swc_rdata_base_6b1cf01f+0x268>
  408ec3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408ecb:	jmp    408d20 <__swc_fn_6b1cf01f_000102_e9fdc18e+0x2a0>
  408ed0:	sub    rsp,0x20
  408ed4:	mov    rax,rsp
  408ed7:	mov    QWORD PTR [rax],r14
  408eda:	mov    QWORD PTR [rax+0x8],r13
  408ede:	mov    QWORD PTR [rax+0x10],rsp
  408ee2:	mov    QWORD PTR [rax+0x18],0x1
  408eea:	lea    rcx,[rsp+0x10]
  408eef:	sub    rsp,0x8
  408ef3:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  408ef8:	add    rsp,0x8
  408efc:	add    rsp,0x20
  408f00:	lea    rax,[rbx+0x28]
  408f04:	mov    rcx,rax
  408f07:	mov    QWORD PTR [rbx+0x28],0x0
  408f0f:	mov    QWORD PTR [rbx+0x30],0x0
  408f17:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408f1c:	add    rcx,0x10
  408f20:	mov    edx,0x1f
  408f25:	cs nop WORD PTR [rax+rax*1+0x0]
  408f2f:	nop
  408f30:	vmovups XMMWORD PTR [rcx],xmm0
  408f34:	add    rcx,0x10
  408f38:	sub    rdx,0x1
  408f3c:	jne    408f30 <__swc_fn_6b1cf01f_000102_e9fdc18e+0x4b0>
  408f3e:	lea    rsi,[rbx+0x228]
  408f45:	xor    ecx,ecx
  408f47:	cs nop WORD PTR [rax+rax*1+0x0]
  408f51:	cs nop WORD PTR [rax+rax*1+0x0]
  408f5b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f60:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f65:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f6a:	add    rcx,0x10
  408f6e:	cmp    rcx,0x200
  408f75:	jne    408f60 <__swc_fn_6b1cf01f_000102_e9fdc18e+0x4e0>
  408f77:	mov    eax,DWORD PTR [r12+0xbc8]
  408f7f:	lea    rcx,[r12+0x9c8]
  408f87:	mov    QWORD PTR [rbx+0x428],rcx
  408f8e:	mov    QWORD PTR [rbx+0x430],rax
  408f95:	lea    rdi,[rbx+0x438]
  408f9c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408fa4:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fac:	mov    eax,DWORD PTR [r12+0xbc8]
  408fb4:	test   eax,eax
  408fb6:	jne    409003 <__swc_fn_6b1cf01f_000102_e9fdc18e+0x583>
  408fb8:	lea    rax,[rbx+0x448]
  408fbf:	mov    QWORD PTR [rbx+0x448],rsi
  408fc6:	mov    QWORD PTR [rax+0x8],0x40
  408fce:	mov    ecx,0x1
  408fd3:	mov    rdx,rax
  408fd6:	sub    rsp,0x8
  408fda:	call   40fa60 <__swc_fn_6b1cf01f_000119_9175a56a>
  408fdf:	add    rsp,0x8
  408fe3:	mov    QWORD PTR [rbx+0x460],rsi
  408fea:	mov    ecx,eax
  408fec:	mov    QWORD PTR [rbx+0x468],rcx
  408ff3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408ffb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  409003:	mov    rsi,QWORD PTR [rbx+0x438]
  40900a:	mov    rax,QWORD PTR [rbx+0x440]
  409011:	mov    r15,rax
  409014:	xor    r12d,r12d
  409017:	test   r15,r15
  40901a:	je     4090d0 <__swc_fn_6b1cf01f_000102_e9fdc18e+0x650>
  409020:	mov    rax,QWORD PTR [rsi+r12*8]
  409024:	test   rax,rax
  409027:	je     409046 <__swc_fn_6b1cf01f_000102_e9fdc18e+0x5c6>
  409029:	lea    rcx,[rbx+0x4b8]
  409030:	mov    rdx,rax
  409033:	sub    rsp,0x8
  409037:	call   409f40 <__swc_fn_6b1cf01f_000162_60216e69>
  40903c:	add    rsp,0x8
  409040:	mov    al,BYTE PTR [rax]
  409042:	test   al,al
  409044:	jne    409052 <__swc_fn_6b1cf01f_000102_e9fdc18e+0x5d2>
  409046:	add    r12,0x1
  40904a:	sub    r15,0x1
  40904e:	jne    409020 <__swc_fn_6b1cf01f_000102_e9fdc18e+0x5a0>
  409050:	jmp    4090d0 <__swc_fn_6b1cf01f_000102_e9fdc18e+0x650>
  409052:	lea    rax,[rip+0xa437]        # 413490 <__swc_rdata_base_6b1cf01f+0x380>
  409059:	sub    rsp,0x20
  40905d:	mov    rcx,rsp
  409060:	mov    QWORD PTR [rcx],rax
  409063:	mov    QWORD PTR [rcx+0x8],r13
  409067:	mov    QWORD PTR [rcx+0x10],rsp
  40906b:	mov    QWORD PTR [rcx+0x18],0x1
  409073:	lea    rcx,[rsp+0x10]
  409078:	sub    rsp,0x8
  40907c:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  409081:	add    rsp,0x8
  409085:	add    rsp,0x20
  409089:	mov    rcx,rdi
  40908c:	xor    edx,edx
  40908e:	mov    al,0x1
  409090:	mov    r8,rax
  409093:	sub    rsp,0x8
  409097:	call   40d1c0 <__swc_fn_6b1cf01f_000163_8e41797b>
  40909c:	add    rsp,0x8
  4090a0:	sub    rsp,0x20
  4090a4:	mov    rax,rsp
  4090a7:	mov    QWORD PTR [rax],r14
  4090aa:	mov    QWORD PTR [rax+0x8],r13
  4090ae:	mov    QWORD PTR [rax+0x10],rsp
  4090b2:	mov    QWORD PTR [rax+0x18],0x1
  4090ba:	lea    rcx,[rsp+0x10]
  4090bf:	sub    rsp,0x8
  4090c3:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  4090c8:	add    rsp,0x8
  4090cc:	add    rsp,0x20
  4090d0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090d8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090e4:	add    rsp,0x500
  4090eb:	pop    r15
  4090ed:	pop    r14
  4090ef:	pop    r13
  4090f1:	pop    r12
  4090f3:	pop    rdi
  4090f4:	pop    rsi
  4090f5:	pop    rbx
  4090f6:	pop    rbp
  4090f7:	ret
	...

0000000000409100 <__swc_fn_6b1cf01f_000105_6fd80914>:
  409100:	sub    rsp,0x8
  409104:	test   r8,r8
  409107:	je     40910e <__swc_fn_6b1cf01f_000105_6fd80914+0xe>
  409109:	call   40f150 <__swc_fn_6b1cf01f_000104_5589fdbd>
  40910e:	add    rsp,0x8
  409112:	ret
	...

0000000000409120 <__swc_fn_6b1cf01f_000108_84af7666>:
  409120:	push   rsi
  409121:	push   rdi
  409122:	push   r12
  409124:	push   r13
  409126:	sub    rsp,0xd8
  40912d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409133:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  409139:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40913f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  409145:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40914b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  409154:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40915d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  409166:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40916f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  409178:	xor    eax,eax
  40917a:	call   407010 <getpid@plt>
  40917f:	mov    rsi,rax
  409182:	lea    rdi,[rip+0x1dbbf]        # 426d48 <__swc_bss_base_6b1cf01f+0x2d08>
  409189:	mov    r12,QWORD PTR [rdi]
  40918c:	test   r12,r12
  40918f:	je     40919d <__swc_fn_6b1cf01f_000108_84af7666+0x7d>
  409191:	cmp    DWORD PTR [r12+0x10],esi
  409196:	jne    40919d <__swc_fn_6b1cf01f_000108_84af7666+0x7d>
  409198:	mov    rax,r12
  40919b:	jmp    409200 <__swc_fn_6b1cf01f_000108_84af7666+0xe0>
  40919d:	mov    ecx,0x4
  4091a2:	mov    edx,0x18
  4091a7:	call   40f240 <__swc_fn_6b1cf01f_000107_4796e893>
  4091ac:	mov    rcx,rax
  4091af:	test   rax,rax
  4091b2:	jne    4091b8 <__swc_fn_6b1cf01f_000108_84af7666+0x98>
  4091b4:	xor    eax,eax
  4091b6:	jmp    409200 <__swc_fn_6b1cf01f_000108_84af7666+0xe0>
  4091b8:	mov    DWORD PTR [rcx+0x10],esi
  4091bb:	mov    rax,r12
  4091be:	lock cmpxchg QWORD PTR [rdi],rcx
  4091c3:	mov    r13,rax
  4091c6:	cmp    rax,r12
  4091c9:	je     4091df <__swc_fn_6b1cf01f_000108_84af7666+0xbf>
  4091cb:	mov    rdi,rcx
  4091ce:	mov    esi,0x18
  4091d3:	xor    eax,eax
  4091d5:	call   407020 <munmap@plt>
  4091da:	mov    rax,r13
  4091dd:	jmp    409200 <__swc_fn_6b1cf01f_000108_84af7666+0xe0>
  4091df:	test   r12,r12
  4091e2:	je     4091fd <__swc_fn_6b1cf01f_000108_84af7666+0xdd>
  4091e4:	mov    rdi,r12
  4091e7:	mov    esi,0x18
  4091ec:	xor    eax,eax
  4091ee:	mov    QWORD PTR [rsp+0x28],rcx
  4091f3:	call   407020 <munmap@plt>
  4091f8:	mov    rcx,QWORD PTR [rsp+0x28]
  4091fd:	mov    rax,rcx
  409200:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  409206:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40920c:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  409212:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  409218:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40921e:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409227:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  409230:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409239:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  409242:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40924b:	add    rsp,0xd8
  409252:	pop    r13
  409254:	pop    r12
  409256:	pop    rdi
  409257:	pop    rsi
  409258:	ret
  409259:	add    BYTE PTR [rax],al
  40925b:	add    BYTE PTR [rax],al
  40925d:	add    BYTE PTR [rax],al
	...

0000000000409260 <__swc_fn_6b1cf01f_000111_b25e3a45>:
  409260:	push   rbx
  409261:	push   r12
  409263:	push   rdi
  409264:	push   rsi
  409265:	sub    rsp,0xa8
  40926c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409272:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409278:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40927e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409284:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40928a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409290:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409296:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40929c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4092a5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4092ae:	mov    rbx,rdx
  4092b1:	mov    r12,rcx
  4092b4:	mov    rdi,rcx
  4092b7:	mov    rsi,rdx
  4092ba:	mov    edx,0x3
  4092bf:	xor    eax,eax
  4092c1:	call   407030 <mprotect@plt>
  4092c6:	test   eax,eax
  4092c8:	je     4092ce <__swc_fn_6b1cf01f_000111_b25e3a45+0x6e>
  4092ca:	xor    eax,eax
  4092cc:	jmp    4092e3 <__swc_fn_6b1cf01f_000111_b25e3a45+0x83>
  4092ce:	mov    rcx,r12
  4092d1:	mov    rdx,rbx
  4092d4:	mov    al,0x1
  4092d6:	mov    r8,rax
  4092d9:	call   40f890 <__swc_fn_6b1cf01f_000110_a808fe76>
  4092de:	mov    eax,0x1
  4092e3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4092e9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4092ef:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4092f5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4092fb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409301:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409307:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40930d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409313:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40931c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409325:	add    rsp,0xa8
  40932c:	pop    rsi
  40932d:	pop    rdi
  40932e:	pop    r12
  409330:	pop    rbx
  409331:	ret
	...

0000000000409340 <__swc_fn_6b1cf01f_000114_27d95464>:
  409340:	sub    rsp,0x8
  409344:	test   rcx,rcx
  409347:	jne    40934e <__swc_fn_6b1cf01f_000114_27d95464+0xe>
  409349:	add    rsp,0x8
  40934d:	ret
  40934e:	call   40c7c0 <__swc_fn_6b1cf01f_000115_1ba33335>
  409353:	add    rsp,0x8
  409357:	ret
	...

0000000000409360 <__swc_fn_6b1cf01f_000117_86a7fb9e>:
  409360:	push   rdi
  409361:	push   rsi
  409362:	sub    rsp,0xa8
  409369:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40936f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409375:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40937b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409381:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409387:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40938d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409393:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409399:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4093a2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4093ab:	xor    edi,edi
  4093ad:	xor    eax,eax
  4093af:	call   407040 <exit@plt>
  4093b4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4093ba:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4093c0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4093c6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4093cc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4093d2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4093d8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4093de:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4093e4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4093ed:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4093f6:	add    rsp,0xa8
  4093fd:	pop    rsi
  4093fe:	pop    rdi
  4093ff:	ret

0000000000409400 <__swc_fn_6b1cf01f_000120_ea68f292>:
  409400:	push   rbx
  409401:	push   rsi
  409402:	push   rdi
  409403:	push   r12
  409405:	sub    rsp,0x18
  409409:	mov    rbx,r8
  40940c:	mov    rsi,rcx
  40940f:	mov    rdi,rdx
  409412:	mov    rcx,QWORD PTR [rip+0x1d927]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  409419:	test   rcx,rcx
  40941c:	jne    40942e <__swc_fn_6b1cf01f_000120_ea68f292+0x2e>
  40941e:	call   40a1d0 <__swc_fn_6b1cf01f_000165_cf398896>
  409423:	lea    rcx,[rax+0x1]
  409427:	mov    QWORD PTR [rip+0x1d912],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40942e:	dec    rcx
  409431:	call   411740 <__swc_fn_6b1cf01f_000167_fce60b2b>
  409436:	mov    r12,rax
  409439:	cmp    ebx,0x3
  40943c:	jne    40944f <__swc_fn_6b1cf01f_000120_ea68f292+0x4f>
  40943e:	mov    rax,QWORD PTR [r12+0xbd0]
  409446:	test   rax,rax
  409449:	jne    40958f <__swc_fn_6b1cf01f_000120_ea68f292+0x18f>
  40944f:	cmp    ebx,0x5
  409452:	jne    409476 <__swc_fn_6b1cf01f_000120_ea68f292+0x76>
  409454:	call   40c090 <__swc_fn_6b1cf01f_000091_3d2f5a0d>
  409459:	test   al,al
  40945b:	jne    409476 <__swc_fn_6b1cf01f_000120_ea68f292+0x76>
  40945d:	mov    rcx,rsi
  409460:	mov    rdx,rdi
  409463:	call   4116f0 <__swc_fn_6b1cf01f_000164_1962e12a>
  409468:	test   al,al
  40946a:	je     409476 <__swc_fn_6b1cf01f_000120_ea68f292+0x76>
  40946c:	add    rsp,0x18
  409470:	pop    r12
  409472:	pop    rdi
  409473:	pop    rsi
  409474:	pop    rbx
  409475:	ret
  409476:	call   40c090 <__swc_fn_6b1cf01f_000091_3d2f5a0d>
  40947b:	test   al,al
  40947d:	jne    4094f2 <__swc_fn_6b1cf01f_000120_ea68f292+0xf2>
  40947f:	lea    rax,[rsp+0x8]
  409484:	vmovups xmm0,XMMWORD PTR [rsi]
  409488:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40948e:	mov    rcx,QWORD PTR [rsp+0x8]
  409493:	test   rcx,rcx
  409496:	jne    4094e7 <__swc_fn_6b1cf01f_000120_ea68f292+0xe7>
  409498:	cmp    ebx,0x3
  40949b:	je     4094a9 <__swc_fn_6b1cf01f_000120_ea68f292+0xa9>
  40949d:	cmp    ebx,0x4
  4094a0:	je     4094b9 <__swc_fn_6b1cf01f_000120_ea68f292+0xb9>
  4094a2:	cmp    ebx,0x5
  4094a5:	je     4094c9 <__swc_fn_6b1cf01f_000120_ea68f292+0xc9>
  4094a7:	jmp    4094d9 <__swc_fn_6b1cf01f_000120_ea68f292+0xd9>
  4094a9:	vmovups xmm0,XMMWORD PTR [rip+0xa02f]        # 4134e0 <__swc_rdata_base_6b1cf01f+0x3d0>
  4094b1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094b7:	jmp    4094e7 <__swc_fn_6b1cf01f_000120_ea68f292+0xe7>
  4094b9:	vmovups xmm0,XMMWORD PTR [rip+0xa02f]        # 4134f0 <__swc_rdata_base_6b1cf01f+0x3e0>
  4094c1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094c7:	jmp    4094e7 <__swc_fn_6b1cf01f_000120_ea68f292+0xe7>
  4094c9:	vmovups xmm0,XMMWORD PTR [rip+0xa02f]        # 413500 <__swc_rdata_base_6b1cf01f+0x3f0>
  4094d1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094d7:	jmp    4094e7 <__swc_fn_6b1cf01f_000120_ea68f292+0xe7>
  4094d9:	vmovups xmm0,XMMWORD PTR [rip+0xa02f]        # 413510 <__swc_rdata_base_6b1cf01f+0x400>
  4094e1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094e7:	mov    rcx,rax
  4094ea:	mov    rdx,rdi
  4094ed:	call   40c2e0 <__swc_fn_6b1cf01f_000103_67100064>
  4094f2:	vmovups xmm0,XMMWORD PTR [rdi]
  4094f6:	vmovups XMMWORD PTR [r12+0x940],xmm0
  409500:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  409505:	vmovups XMMWORD PTR [r12+0x950],xmm0
  40950f:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  409514:	vmovups XMMWORD PTR [r12+0x960],xmm0
  40951e:	lea    rax,[r12+0x940]
  409526:	mov    QWORD PTR [r12+0x970],rax
  40952e:	mov    rax,QWORD PTR [rsi]
  409531:	mov    QWORD PTR [r12+0x978],rax
  409539:	mov    rax,QWORD PTR [rsi+0x8]
  40953d:	mov    QWORD PTR [r12+0x980],rax
  409545:	movsxd rax,ebx
  409548:	mov    QWORD PTR [r12+0x988],rax
  409550:	cmp    ebx,0x5
  409553:	je     40955c <__swc_fn_6b1cf01f_000120_ea68f292+0x15c>
  409555:	xor    ecx,ecx
  409557:	call   40a300 <__swc_fn_6b1cf01f_000174_176517f9>
  40955c:	mov    rbx,QWORD PTR [r12+0xbe8]
  409564:	test   rbx,rbx
  409567:	je     409578 <__swc_fn_6b1cf01f_000120_ea68f292+0x178>
  409569:	mov    rcx,r12
  40956c:	call   rbx
  40956e:	add    rsp,0x18
  409572:	pop    r12
  409574:	pop    rdi
  409575:	pop    rsi
  409576:	pop    rbx
  409577:	ret
  409578:	mov    rcx,rsi
  40957b:	call   40f940 <__swc_fn_6b1cf01f_000116_035d76a1>
  409580:	call   40c910 <__swc_fn_6b1cf01f_000118_7f430081>
  409585:	add    rsp,0x18
  409589:	pop    r12
  40958b:	pop    rdi
  40958c:	pop    rsi
  40958d:	pop    rbx
  40958e:	ret
  40958f:	mov    rcx,rsi
  409592:	mov    rdx,rdi
  409595:	call   40c2e0 <__swc_fn_6b1cf01f_000103_67100064>
  40959a:	jmp    40944f <__swc_fn_6b1cf01f_000120_ea68f292+0x4f>
	...

00000000004095a0 <__swc_fn_6b1cf01f_000123_9d2cbd72>:
  4095a0:	push   rdi
  4095a1:	push   rsi
  4095a2:	sub    rsp,0xb8
  4095a9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4095af:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4095b5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4095bb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4095c1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4095c7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4095cd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4095d3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4095dc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4095e5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4095ee:	mov    DWORD PTR [rsp+0x8],0x0
  4095f6:	lea    rdi,[rsp+0x8]
  4095fb:	xor    esi,esi
  4095fd:	xor    eax,eax
  4095ff:	call   407050 <pthread_key_create@plt>
  409604:	test   eax,eax
  409606:	jne    40960e <__swc_fn_6b1cf01f_000123_9d2cbd72+0x6e>
  409608:	mov    eax,DWORD PTR [rsp+0x8]
  40960c:	jmp    409615 <__swc_fn_6b1cf01f_000123_9d2cbd72+0x75>
  40960e:	mov    rax,0xffffffffffffffff
  409615:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40961b:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409621:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409627:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40962d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409633:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409639:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40963f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409648:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409651:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40965a:	add    rsp,0xb8
  409661:	pop    rsi
  409662:	pop    rdi
  409663:	ret
	...

0000000000409670 <__swc_fn_6b1cf01f_000126_102fe7b9>:
  409670:	push   rdi
  409671:	push   rsi
  409672:	sub    rsp,0xb8
  409679:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40967f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409685:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40968b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409691:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409697:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40969d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4096a3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4096ac:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4096b5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4096be:	mov    DWORD PTR [rsp+0x8],0x0
  4096c6:	lea    rdi,[rsp+0x8]
  4096cb:	mov    rsi,rcx
  4096ce:	xor    eax,eax
  4096d0:	call   407050 <pthread_key_create@plt>
  4096d5:	test   eax,eax
  4096d7:	jne    4096e2 <__swc_fn_6b1cf01f_000126_102fe7b9+0x72>
  4096d9:	mov    eax,DWORD PTR [rsp+0x8]
  4096dd:	inc    rax
  4096e0:	jmp    4096e4 <__swc_fn_6b1cf01f_000126_102fe7b9+0x74>
  4096e2:	xor    eax,eax
  4096e4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4096ea:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4096f0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4096f6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4096fc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409702:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409708:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40970e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409717:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409720:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409729:	add    rsp,0xb8
  409730:	pop    rsi
  409731:	pop    rdi
  409732:	ret
	...

0000000000409740 <__swc_fn_6b1cf01f_000129_74b163fe>:
  409740:	push   rdi
  409741:	push   rsi
  409742:	sub    rsp,0xa8
  409749:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40974f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409755:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40975b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409761:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409767:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40976d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409773:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409779:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409782:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40978b:	test   rcx,rcx
  40978e:	setne  al
  409791:	je     4097aa <__swc_fn_6b1cf01f_000129_74b163fe+0x6a>
  409793:	lea    rax,[rcx-0x1]
  409797:	mov    eax,eax
  409799:	mov    edi,eax
  40979b:	mov    rsi,rdx
  40979e:	xor    eax,eax
  4097a0:	call   407060 <pthread_setspecific@plt>
  4097a5:	test   eax,eax
  4097a7:	sete   al
  4097aa:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4097b0:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4097b6:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4097bc:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4097c2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4097c8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4097ce:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4097d4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4097da:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4097e3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4097ec:	add    rsp,0xa8
  4097f3:	pop    rsi
  4097f4:	pop    rdi
  4097f5:	ret
	...

0000000000409800 <__swc_fn_6b1cf01f_000132_f908e7f9>:
  409800:	push   rdi
  409801:	push   rsi
  409802:	sub    rsp,0xa8
  409809:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40980f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409815:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40981b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409821:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409827:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40982d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409833:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409839:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409842:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40984b:	mov    rax,rdx
  40984e:	mov    QWORD PTR [rsp],0x0
  409856:	mov    edi,0xca
  40985b:	mov    rsi,rcx
  40985e:	mov    edx,0x81
  409863:	mov    eax,eax
  409865:	mov    ecx,eax
  409867:	xor    r8d,r8d
  40986a:	xor    r9d,r9d
  40986d:	xor    eax,eax
  40986f:	call   407070 <syscall@plt>
  409874:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40987a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409880:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409886:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40988c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409892:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409898:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40989e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4098a4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4098ad:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4098b6:	add    rsp,0xa8
  4098bd:	pop    rsi
  4098be:	pop    rdi
  4098bf:	ret

00000000004098c0 <__swc_fn_6b1cf01f_000135_e3032dc2>:
  4098c0:	sub    rsp,0x8
  4098c4:	call   40ccb0 <__swc_fn_6b1cf01f_000133_4b2af8da>
  4098c9:	add    rsp,0x8
  4098cd:	ret
	...

00000000004098d0 <__swc_fn_6b1cf01f_000138_0c00232f>:
  4098d0:	push   rdi
  4098d1:	push   rsi
  4098d2:	sub    rsp,0xc8
  4098d9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4098df:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4098e5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4098eb:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4098f1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4098f7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4098fd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  409906:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40990f:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  409918:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  409921:	vxorps xmm0,xmm0,xmm0
  409925:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40992b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409931:	mov    rdi,rcx
  409934:	lea    rsi,[rsp+0x8]
  409939:	xor    eax,eax
  40993b:	call   407080 <dladdr@plt>
  409940:	xor    ecx,ecx
  409942:	test   eax,eax
  409944:	je     40994b <__swc_fn_6b1cf01f_000138_0c00232f+0x7b>
  409946:	mov    rcx,QWORD PTR [rsp+0x10]
  40994b:	mov    rax,rcx
  40994e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  409954:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40995a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  409960:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  409966:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40996c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  409972:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40997b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  409984:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40998d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  409996:	add    rsp,0xc8
  40999d:	pop    rsi
  40999e:	pop    rdi
  40999f:	ret

00000000004099a0 <__swc_fn_6b1cf01f_000141_2ce79e3b>:
  4099a0:	push   rbx
  4099a1:	push   r12
  4099a3:	push   r13
  4099a5:	push   rdi
  4099a6:	push   rsi
  4099a7:	push   r14
  4099a9:	push   r15
  4099ab:	sub    rsp,0x150
  4099b2:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  4099bb:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  4099c4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  4099cd:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  4099d6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  4099df:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4099e8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4099f1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4099fa:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  409a03:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  409a0c:	mov    rbx,rdx
  409a0f:	mov    QWORD PTR [rsp+0x98],rdx
  409a17:	mov    r12,rcx
  409a1a:	mov    QWORD PTR [rsp+0xa0],rcx
  409a22:	mov    QWORD PTR [rbx],0x0
  409a29:	lea    r13,[rip+0x1d350]        # 426d80 <__swc_bss_base_6b1cf01f+0x2d40>
  409a30:	mov    rcx,r13
  409a33:	call   4098c0 <__swc_fn_6b1cf01f_000135_e3032dc2>
  409a38:	mov    rax,QWORD PTR [rip+0x1d349]        # 426d88 <__swc_bss_base_6b1cf01f+0x2d48>
  409a3f:	test   rax,rax
  409a42:	je     409a79 <__swc_fn_6b1cf01f_000141_2ce79e3b+0xd9>
  409a44:	cs nop WORD PTR [rax+rax*1+0x0]
  409a4e:	xchg   ax,ax
  409a50:	cmp    QWORD PTR [rax+0x8],r12
  409a54:	jne    409a71 <__swc_fn_6b1cf01f_000141_2ce79e3b+0xd1>
  409a56:	mov    rcx,QWORD PTR [rax+0x18]
  409a5a:	mov    QWORD PTR [rbx],rcx
  409a5d:	mov    rbx,QWORD PTR [rax+0x10]
  409a61:	mov    rcx,r13
  409a64:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  409a69:	mov    rax,rbx
  409a6c:	jmp    409c5b <__swc_fn_6b1cf01f_000141_2ce79e3b+0x2bb>
  409a71:	mov    rax,QWORD PTR [rax]
  409a74:	test   rax,rax
  409a77:	jne    409a50 <__swc_fn_6b1cf01f_000141_2ce79e3b+0xb0>
  409a79:	vxorps xmm0,xmm0,xmm0
  409a7d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  409a83:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  409a89:	mov    rdi,r12
  409a8c:	lea    rsi,[rsp+0x10]
  409a91:	xor    eax,eax
  409a93:	call   407080 <dladdr@plt>
  409a98:	test   eax,eax
  409a9a:	sete   al
  409a9d:	je     409aaa <__swc_fn_6b1cf01f_000141_2ce79e3b+0x10a>
  409a9f:	mov    rax,QWORD PTR [rsp+0x10]
  409aa4:	test   rax,rax
  409aa7:	sete   al
  409aaa:	test   al,al
  409aac:	je     409abd <__swc_fn_6b1cf01f_000141_2ce79e3b+0x11d>
  409aae:	mov    rcx,r13
  409ab1:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  409ab6:	xor    eax,eax
  409ab8:	jmp    409c5b <__swc_fn_6b1cf01f_000141_2ce79e3b+0x2bb>
  409abd:	mov    rdi,QWORD PTR [rsp+0x10]
  409ac2:	mov    esi,0x80000
  409ac7:	xor    eax,eax
  409ac9:	call   407090 <open@plt>
  409ace:	lea    r14,[rsp+0x30]
  409ad3:	mov    DWORD PTR [rsp+0x30],eax
  409ad7:	cmp    DWORD PTR [r14],0x0
  409adb:	jge    409aec <__swc_fn_6b1cf01f_000141_2ce79e3b+0x14c>
  409add:	mov    rcx,r13
  409ae0:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  409ae5:	xor    eax,eax
  409ae7:	jmp    409c5b <__swc_fn_6b1cf01f_000141_2ce79e3b+0x2bb>
  409aec:	mov    rax,r14
  409aef:	movsxd rdi,DWORD PTR [rax]
  409af2:	xor    esi,esi
  409af4:	mov    edx,0x2
  409af9:	xor    eax,eax
  409afb:	call   4070a0 <lseek@plt>
  409b00:	mov    r15,rax
  409b03:	test   rax,rax
  409b06:	jg     409b21 <__swc_fn_6b1cf01f_000141_2ce79e3b+0x181>
  409b08:	movsxd rdi,DWORD PTR [r14]
  409b0b:	xor    eax,eax
  409b0d:	call   4070b0 <close@plt>
  409b12:	mov    rcx,r13
  409b15:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  409b1a:	xor    eax,eax
  409b1c:	jmp    409c5b <__swc_fn_6b1cf01f_000141_2ce79e3b+0x2bb>
  409b21:	xor    edi,edi
  409b23:	mov    rsi,r15
  409b26:	mov    edx,0x1
  409b2b:	mov    ecx,0x2
  409b30:	mov    rax,r14
  409b33:	movsxd r8,DWORD PTR [rax]
  409b36:	xor    r9d,r9d
  409b39:	xor    eax,eax
  409b3b:	call   4070c0 <mmap@plt>
  409b40:	mov    rbx,rax
  409b43:	test   rax,rax
  409b46:	sete   al
  409b49:	cmp    rbx,0xffffffffffffffff
  409b4d:	sete   cl
  409b50:	or     al,cl
  409b52:	je     409b6d <__swc_fn_6b1cf01f_000141_2ce79e3b+0x1cd>
  409b54:	movsxd rdi,DWORD PTR [r14]
  409b57:	xor    eax,eax
  409b59:	call   4070b0 <close@plt>
  409b5e:	mov    rcx,r13
  409b61:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  409b66:	xor    eax,eax
  409b68:	jmp    409c5b <__swc_fn_6b1cf01f_000141_2ce79e3b+0x2bb>
  409b6d:	lea    rax,[rsp+0x50]
  409b72:	mov    QWORD PTR [rax],0x0
  409b79:	mov    rcx,rbx
  409b7c:	mov    rdx,r15
  409b7f:	mov    r8,rax
  409b82:	call   40fee0 <__swc_fn_6b1cf01f_000140_c6b99a56>
  409b87:	mov    r12,rax
  409b8a:	test   rax,rax
  409b8d:	jne    409bb5 <__swc_fn_6b1cf01f_000141_2ce79e3b+0x215>
  409b8f:	mov    rdi,rbx
  409b92:	mov    rsi,r15
  409b95:	xor    eax,eax
  409b97:	call   407020 <munmap@plt>
  409b9c:	movsxd rdi,DWORD PTR [r14]
  409b9f:	xor    eax,eax
  409ba1:	call   4070b0 <close@plt>
  409ba6:	mov    rcx,r13
  409ba9:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  409bae:	xor    eax,eax
  409bb0:	jmp    409c5b <__swc_fn_6b1cf01f_000141_2ce79e3b+0x2bb>
  409bb5:	mov    edi,0x20
  409bba:	xor    eax,eax
  409bbc:	call   4070d0 <malloc@plt>
  409bc1:	test   rax,rax
  409bc4:	jne    409be9 <__swc_fn_6b1cf01f_000141_2ce79e3b+0x249>
  409bc6:	mov    rdi,rbx
  409bc9:	mov    rsi,r15
  409bcc:	xor    eax,eax
  409bce:	call   407020 <munmap@plt>
  409bd3:	movsxd rdi,DWORD PTR [r14]
  409bd6:	xor    eax,eax
  409bd8:	call   4070b0 <close@plt>
  409bdd:	mov    rcx,r13
  409be0:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  409be5:	xor    eax,eax
  409be7:	jmp    409c5b <__swc_fn_6b1cf01f_000141_2ce79e3b+0x2bb>
  409be9:	mov    rcx,QWORD PTR [rip+0x1d198]        # 426d88 <__swc_bss_base_6b1cf01f+0x2d48>
  409bf0:	mov    QWORD PTR [rsp+0x70],rcx
  409bf5:	mov    rcx,QWORD PTR [rsp+0xa0]
  409bfd:	mov    QWORD PTR [rsp+0x78],rcx
  409c02:	mov    QWORD PTR [rsp+0x80],r12
  409c0a:	mov    rcx,QWORD PTR [rsp+0x50]
  409c0f:	mov    QWORD PTR [rsp+0x88],rcx
  409c17:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  409c1d:	vmovups XMMWORD PTR [rax],xmm0
  409c21:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  409c2a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  409c2f:	mov    QWORD PTR [rip+0x1d152],rax        # 426d88 <__swc_bss_base_6b1cf01f+0x2d48>
  409c36:	mov    rax,QWORD PTR [rsp+0x50]
  409c3b:	mov    rbx,QWORD PTR [rsp+0x98]
  409c43:	mov    QWORD PTR [rbx],rax
  409c46:	movsxd rdi,DWORD PTR [r14]
  409c49:	xor    eax,eax
  409c4b:	call   4070b0 <close@plt>
  409c50:	mov    rcx,r13
  409c53:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  409c58:	mov    rax,r12
  409c5b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  409c64:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  409c6d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  409c76:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  409c7f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  409c88:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  409c91:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  409c9a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  409ca3:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  409cac:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  409cb5:	add    rsp,0x150
  409cbc:	pop    r15
  409cbe:	pop    r14
  409cc0:	pop    rsi
  409cc1:	pop    rdi
  409cc2:	pop    r13
  409cc4:	pop    r12
  409cc6:	pop    rbx
  409cc7:	ret
	...

0000000000409cd0 <__swc_fn_6b1cf01f_000144_72996a5b>:
  409cd0:	push   rbx
  409cd1:	sub    rsp,0xe0
  409cd8:	lea    rbx,[rsp+0x8]
  409cdd:	vxorps xmm0,xmm0,xmm0
  409ce1:	vmovups XMMWORD PTR [rbx],xmm0
  409ce5:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409cea:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409cef:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  409cf4:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  409cf9:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  409cfe:	mov    DWORD PTR [rbx+0x60],0x0
  409d05:	mov    r8,rbx
  409d08:	nop    DWORD PTR [rax+rax*1+0x0]
  409d10:	mov    r9,rcx
  409d13:	movabs rcx,0xcccccccccccccccd
  409d1d:	mov    rax,r9
  409d20:	mul    rcx
  409d23:	mov    r10,rdx
  409d26:	shr    r10,0x3
  409d2a:	mov    rcx,r10
  409d2d:	imul   rdx,r10,0xa
  409d31:	sub    r9,rdx
  409d34:	mov    rdx,QWORD PTR [rip+0x9805]        # 413540 <__swc_rdata_base_6b1cf01f+0x430>
  409d3b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  409d40:	mov    BYTE PTR [r8],dl
  409d43:	lea    rdx,[r8+0x1]
  409d47:	mov    r8,rdx
  409d4a:	test   r10,r10
  409d4d:	jne    409d10 <__swc_fn_6b1cf01f_000144_72996a5b+0x40>
  409d4f:	mov    BYTE PTR [rdx],0x0
  409d52:	sub    r8,0x1
  409d56:	mov    rax,rbx
  409d59:	cmp    rax,r8
  409d5c:	jae    409d76 <__swc_fn_6b1cf01f_000144_72996a5b+0xa6>
  409d5e:	xchg   ax,ax
  409d60:	mov    cl,BYTE PTR [r8]
  409d63:	mov    dl,BYTE PTR [rax]
  409d65:	mov    BYTE PTR [r8],dl
  409d68:	sub    r8,0x1
  409d6c:	mov    BYTE PTR [rax],cl
  409d6e:	inc    rax
  409d71:	cmp    rax,r8
  409d74:	jb     409d60 <__swc_fn_6b1cf01f_000144_72996a5b+0x90>
  409d76:	xor    eax,eax
  409d78:	test   rbx,rbx
  409d7b:	je     409d9e <__swc_fn_6b1cf01f_000144_72996a5b+0xce>
  409d7d:	mov    rcx,rbx
  409d80:	mov    dl,BYTE PTR [rcx]
  409d82:	test   dl,dl
  409d84:	je     409d9e <__swc_fn_6b1cf01f_000144_72996a5b+0xce>
  409d86:	cs nop WORD PTR [rax+rax*1+0x0]
  409d90:	add    rcx,0x1
  409d94:	add    rax,0x1
  409d98:	mov    dl,BYTE PTR [rcx]
  409d9a:	test   dl,dl
  409d9c:	jne    409d90 <__swc_fn_6b1cf01f_000144_72996a5b+0xc0>
  409d9e:	mov    QWORD PTR [rbx+0xa8],rbx
  409da5:	mov    QWORD PTR [rbx+0xb0],rax
  409dac:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  409db4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  409dbc:	lea    rcx,[rbx+0xb8]
  409dc3:	call   40f940 <__swc_fn_6b1cf01f_000116_035d76a1>
  409dc8:	add    rsp,0xe0
  409dcf:	pop    rbx
  409dd0:	ret
	...

0000000000409de0 <__swc_fn_6b1cf01f_000147_32a497f3>:
  409de0:	sub    rsp,0x8
  409de4:	mov    rax,QWORD PTR [rcx+0x8]
  409de8:	mov    r8,QWORD PTR [rdx+0x8]
  409dec:	cmp    rax,r8
  409def:	je     409df8 <__swc_fn_6b1cf01f_000147_32a497f3+0x18>
  409df1:	xor    eax,eax
  409df3:	add    rsp,0x8
  409df7:	ret
  409df8:	test   rax,rax
  409dfb:	jne    409e0c <__swc_fn_6b1cf01f_000147_32a497f3+0x2c>
  409dfd:	test   r8,r8
  409e00:	jne    409e0c <__swc_fn_6b1cf01f_000147_32a497f3+0x2c>
  409e02:	mov    eax,0x1
  409e07:	add    rsp,0x8
  409e0b:	ret
  409e0c:	mov    rcx,QWORD PTR [rcx]
  409e0f:	mov    rdx,QWORD PTR [rdx]
  409e12:	test   rcx,rcx
  409e15:	sete   r8b
  409e19:	test   rdx,rdx
  409e1c:	sete   r9b
  409e20:	or     r8b,r9b
  409e23:	je     409e30 <__swc_fn_6b1cf01f_000147_32a497f3+0x50>
  409e25:	cmp    rcx,rdx
  409e28:	sete   al
  409e2b:	add    rsp,0x8
  409e2f:	ret
  409e30:	cmp    rcx,rdx
  409e33:	jne    409e3f <__swc_fn_6b1cf01f_000147_32a497f3+0x5f>
  409e35:	mov    eax,0x1
  409e3a:	add    rsp,0x8
  409e3e:	ret
  409e3f:	mov    r8,rax
  409e42:	call   40c3a0 <__swc_fn_6b1cf01f_000106_ed4b1681>
  409e47:	test   eax,eax
  409e49:	sete   al
  409e4c:	add    rsp,0x8
  409e50:	ret
	...

0000000000409e60 <__swc_fn_6b1cf01f_000150_9e4bc402>:
  409e60:	vxorps xmm0,xmm0,xmm0
  409e64:	vmovups XMMWORD PTR [rcx],xmm0
  409e68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e6d:	vxorps xmm0,xmm0,xmm0
  409e71:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e76:	vmovups xmm0,XMMWORD PTR [rip+0x977a]        # 4135f8 <__swc_rdata_base_6b1cf01f+0x4e8>
  409e7e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e83:	ret
	...

0000000000409e90 <__swc_fn_6b1cf01f_000153_9e4bc402>:
  409e90:	vxorps xmm0,xmm0,xmm0
  409e94:	vmovups XMMWORD PTR [rcx],xmm0
  409e98:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e9d:	vxorps xmm0,xmm0,xmm0
  409ea1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409ea6:	vmovups xmm0,XMMWORD PTR [rip+0x986a]        # 413718 <__swc_rdata_base_6b1cf01f+0x608>
  409eae:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409eb3:	mov    QWORD PTR [rcx+0x40],0x0
  409ebb:	ret
  409ebc:	add    BYTE PTR [rax],al
	...

0000000000409ec0 <__swc_fn_6b1cf01f_000156_2745c4a5>:
  409ec0:	push   rbx
  409ec1:	sub    rsp,0x70
  409ec5:	mov    rax,QWORD PTR [rcx]
  409ec8:	mov    rbx,QWORD PTR [rcx+0x8]
  409ecc:	vxorps xmm0,xmm0,xmm0
  409ed0:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409ed6:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409edc:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409ee2:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  409ee8:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  409eee:	mov    QWORD PTR [rsp+0x48],rdx
  409ef3:	mov    QWORD PTR [rsp+0x50],r8
  409ef8:	mov    rcx,rax
  409efb:	lea    rdx,[rsp+0x8]
  409f00:	mov    rbx,QWORD PTR [rbx+0x18]
  409f04:	call   rbx
  409f06:	add    rsp,0x70
  409f0a:	pop    rbx
  409f0b:	ret
  409f0c:	add    BYTE PTR [rax],al
	...

0000000000409f10 <__swc_fn_6b1cf01f_000159_d8afac28>:
  409f10:	push   rbx
  409f11:	push   rsi
  409f12:	push   rdi
  409f13:	mov    rbx,r8
  409f16:	mov    rsi,rcx
  409f19:	mov    rdi,rdx
  409f1c:	call   40d0c0 <__swc_fn_6b1cf01f_000157_232ffa22>
  409f21:	vmovups xmm0,XMMWORD PTR [rbx]
  409f25:	vmovups XMMWORD PTR [rsi],xmm0
  409f29:	mov    QWORD PTR [rsi+0x18],rdi
  409f2d:	pop    rdi
  409f2e:	pop    rsi
  409f2f:	pop    rbx
  409f30:	ret
	...

0000000000409f40 <__swc_fn_6b1cf01f_000162_60216e69>:
  409f40:	push   rbx
  409f41:	push   rsi
  409f42:	push   rdi
  409f43:	push   r12
  409f45:	push   r13
  409f47:	sub    rsp,0x50
  409f4b:	mov    rbx,rcx
  409f4e:	mov    rsi,rdx
  409f51:	vmovups xmm0,XMMWORD PTR [rip+0x98cf]        # 413828 <__swc_rdata_base_6b1cf01f+0x718>
  409f59:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409f5f:	vmovups xmm0,XMMWORD PTR [rip+0x98d1]        # 413838 <__swc_rdata_base_6b1cf01f+0x728>
  409f67:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409f6d:	vxorps xmm0,xmm0,xmm0
  409f71:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409f77:	mov    rcx,rdx
  409f7a:	call   4098d0 <__swc_fn_6b1cf01f_000138_0c00232f>
  409f7f:	mov    rdi,rax
  409f82:	test   rax,rax
  409f85:	jne    409fb6 <__swc_fn_6b1cf01f_000162_60216e69+0x76>
  409f87:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409f8d:	vmovups XMMWORD PTR [rbx],xmm0
  409f91:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409f97:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409f9c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fa2:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fa7:	mov    rax,rbx
  409faa:	add    rsp,0x50
  409fae:	pop    r13
  409fb0:	pop    r12
  409fb2:	pop    rdi
  409fb3:	pop    rsi
  409fb4:	pop    rbx
  409fb5:	ret
  409fb6:	mov    rcx,rdi
  409fb9:	call   411440 <__swc_fn_6b1cf01f_000161_b5a9d657>
  409fbe:	mov    r11,rax
  409fc1:	test   rax,rax
  409fc4:	je     409fce <__swc_fn_6b1cf01f_000162_60216e69+0x8e>
  409fc6:	mov    al,BYTE PTR [r11+0x24]
  409fca:	test   al,al
  409fcc:	jne    409ffd <__swc_fn_6b1cf01f_000162_60216e69+0xbd>
  409fce:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fd4:	vmovups XMMWORD PTR [rbx],xmm0
  409fd8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fde:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fe3:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fe9:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fee:	mov    rax,rbx
  409ff1:	add    rsp,0x50
  409ff5:	pop    r13
  409ff7:	pop    r12
  409ff9:	pop    rdi
  409ffa:	pop    rsi
  409ffb:	pop    rbx
  409ffc:	ret
  409ffd:	sub    rsi,rdi
  40a000:	mov    eax,0xffffffff
  40a005:	cmp    rsi,rax
  40a008:	jbe    40a039 <__swc_fn_6b1cf01f_000162_60216e69+0xf9>
  40a00a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a010:	vmovups XMMWORD PTR [rbx],xmm0
  40a014:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a01a:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a01f:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a025:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a02a:	mov    rax,rbx
  40a02d:	add    rsp,0x50
  40a031:	pop    r13
  40a033:	pop    r12
  40a035:	pop    rdi
  40a036:	pop    rsi
  40a037:	pop    rbx
  40a038:	ret
  40a039:	mov    rdi,QWORD PTR [r11+0x10]
  40a03d:	mov    eax,DWORD PTR [r11+0x20]
  40a041:	xor    ecx,ecx
  40a043:	test   rax,rax
  40a046:	jbe    40a198 <__swc_fn_6b1cf01f_000162_60216e69+0x258>
  40a04c:	nop    DWORD PTR [rax+0x0]
  40a050:	mov    edx,ecx
  40a052:	imul   r12,rdx,0x14
  40a056:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40a05b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40a060:	mov    r9d,esi
  40a063:	cmp    r9,rdx
  40a066:	jb     40a18b <__swc_fn_6b1cf01f_000162_60216e69+0x24b>
  40a06c:	add    rdx,r8
  40a06f:	mov    r8d,esi
  40a072:	cmp    r8,rdx
  40a075:	jae    40a18b <__swc_fn_6b1cf01f_000162_60216e69+0x24b>
  40a07b:	lea    rsi,[rsp+0x38]
  40a080:	mov    eax,DWORD PTR [rdi+0xc]
  40a083:	mov    DWORD PTR [rsp+0x38],eax
  40a087:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40a08c:	mov    rcx,rdi
  40a08f:	mov    rdx,QWORD PTR [r11+0x18]
  40a093:	mov    r8,rsi
  40a096:	mov    r8d,DWORD PTR [r8]
  40a099:	mov    r9,rax
  40a09c:	lea    r10,[rsp+0x10]
  40a0a1:	call   40d120 <__swc_fn_6b1cf01f_000160_01cbb887>
  40a0a6:	test   al,al
  40a0a8:	jne    40a0db <__swc_fn_6b1cf01f_000162_60216e69+0x19b>
  40a0aa:	vmovups xmm0,XMMWORD PTR [rip+0x97a6]        # 413858 <__swc_rdata_base_6b1cf01f+0x748>
  40a0b2:	vmovups XMMWORD PTR [rbx],xmm0
  40a0b6:	vmovups xmm0,XMMWORD PTR [rip+0x97aa]        # 413868 <__swc_rdata_base_6b1cf01f+0x758>
  40a0be:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a0c3:	vxorps xmm0,xmm0,xmm0
  40a0c7:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a0cc:	mov    rax,rbx
  40a0cf:	add    rsp,0x50
  40a0d3:	pop    r13
  40a0d5:	pop    r12
  40a0d7:	pop    rdi
  40a0d8:	pop    rsi
  40a0d9:	pop    rbx
  40a0da:	ret
  40a0db:	lea    r13,[rsp+0x3c]
  40a0e0:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40a0e5:	mov    DWORD PTR [rsp+0x3c],eax
  40a0e9:	test   eax,eax
  40a0eb:	je     40a13c <__swc_fn_6b1cf01f_000162_60216e69+0x1fc>
  40a0ed:	mov    rcx,rdi
  40a0f0:	mov    rdx,QWORD PTR [r11+0x18]
  40a0f4:	mov    r8d,DWORD PTR [rsi]
  40a0f7:	mov    rax,r13
  40a0fa:	mov    r9d,DWORD PTR [rax]
  40a0fd:	lea    r10,[rsp+0x20]
  40a102:	call   40d120 <__swc_fn_6b1cf01f_000160_01cbb887>
  40a107:	test   al,al
  40a109:	jne    40a13c <__swc_fn_6b1cf01f_000162_60216e69+0x1fc>
  40a10b:	vmovups xmm0,XMMWORD PTR [rip+0x9775]        # 413888 <__swc_rdata_base_6b1cf01f+0x778>
  40a113:	vmovups XMMWORD PTR [rbx],xmm0
  40a117:	vmovups xmm0,XMMWORD PTR [rip+0x9779]        # 413898 <__swc_rdata_base_6b1cf01f+0x788>
  40a11f:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a124:	vxorps xmm0,xmm0,xmm0
  40a128:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a12d:	mov    rax,rbx
  40a130:	add    rsp,0x50
  40a134:	pop    r13
  40a136:	pop    r12
  40a138:	pop    rdi
  40a139:	pop    rsi
  40a13a:	pop    rbx
  40a13b:	ret
  40a13c:	mov    eax,0x1
  40a141:	rex mov BYTE PTR [rsp+0x8],al
  40a146:	cmp    DWORD PTR [r13+0x0],0x0
  40a14b:	je     40a15c <__swc_fn_6b1cf01f_000162_60216e69+0x21c>
  40a14d:	rex mov BYTE PTR [rsp+0x9],0x1
  40a153:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40a158:	mov    DWORD PTR [rsp+0x30],eax
  40a15c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a162:	vmovups XMMWORD PTR [rbx],xmm0
  40a166:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a16c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a171:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a177:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a17c:	mov    rax,rbx
  40a17f:	add    rsp,0x50
  40a183:	pop    r13
  40a185:	pop    r12
  40a187:	pop    rdi
  40a188:	pop    rsi
  40a189:	pop    rbx
  40a18a:	ret
  40a18b:	add    rcx,0x1
  40a18f:	cmp    rcx,rax
  40a192:	jb     40a050 <__swc_fn_6b1cf01f_000162_60216e69+0x110>
  40a198:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a19e:	vmovups XMMWORD PTR [rbx],xmm0
  40a1a2:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a1a8:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a1ad:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a1b3:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a1b8:	mov    rax,rbx
  40a1bb:	add    rsp,0x50
  40a1bf:	pop    r13
  40a1c1:	pop    r12
  40a1c3:	pop    rdi
  40a1c4:	pop    rsi
  40a1c5:	pop    rbx
  40a1c6:	ret
	...

000000000040a1d0 <__swc_fn_6b1cf01f_000165_cf398896>:
  40a1d0:	sub    rsp,0x48
  40a1d4:	call   4095a0 <__swc_fn_6b1cf01f_000123_9d2cbd72>
  40a1d9:	cmp    rax,0xffffffffffffffff
  40a1dd:	je     40a1e4 <__swc_fn_6b1cf01f_000165_cf398896+0x14>
  40a1df:	add    rsp,0x48
  40a1e3:	ret
  40a1e4:	lea    rcx,[rip+0x96dd]        # 4138c8 <__swc_rdata_base_6b1cf01f+0x7b8>
  40a1eb:	vmovups xmm0,XMMWORD PTR [rip+0x96e5]        # 4138d8 <__swc_rdata_base_6b1cf01f+0x7c8>
  40a1f3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a1f9:	vmovups xmm0,XMMWORD PTR [rip+0x96e7]        # 4138e8 <__swc_rdata_base_6b1cf01f+0x7d8>
  40a201:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a207:	vmovups xmm0,XMMWORD PTR [rip+0x96e9]        # 4138f8 <__swc_rdata_base_6b1cf01f+0x7e8>
  40a20f:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a215:	lea    rdx,[rsp+0x8]
  40a21a:	mov    QWORD PTR [rsp+0x38],rax
  40a21f:	call   40c2e0 <__swc_fn_6b1cf01f_000103_67100064>
  40a224:	mov    rax,QWORD PTR [rsp+0x38]
  40a229:	jmp    40a1df <__swc_fn_6b1cf01f_000165_cf398896+0xf>
  40a22b:	add    BYTE PTR [rax],al
  40a22d:	add    BYTE PTR [rax],al
	...

000000000040a230 <__swc_fn_6b1cf01f_000168_92b7d63c>:
  40a230:	push   rbx
  40a231:	push   rsi
  40a232:	sub    rsp,0x28
  40a236:	mov    rbx,rcx
  40a239:	mov    DWORD PTR [rsp+0x8],0xbf0
  40a241:	mov    ecx,0xbf0
  40a246:	call   40bed0 <__swc_fn_6b1cf01f_000079_34776ded>
  40a24b:	mov    rsi,rax
  40a24e:	test   rax,rax
  40a251:	jne    40a25c <__swc_fn_6b1cf01f_000168_92b7d63c+0x2c>
  40a253:	xor    eax,eax
  40a255:	add    rsp,0x28
  40a259:	pop    rsi
  40a25a:	pop    rbx
  40a25b:	ret
  40a25c:	vxorps xmm0,xmm0,xmm0
  40a260:	xor    eax,eax
  40a262:	cs nop WORD PTR [rax+rax*1+0x0]
  40a26c:	nop    DWORD PTR [rax+0x0]
  40a270:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40a275:	add    rax,0x10
  40a279:	cmp    rax,0xbf0
  40a280:	jne    40a270 <__swc_fn_6b1cf01f_000168_92b7d63c+0x40>
  40a282:	lea    rax,[rbx+0x1]
  40a286:	mov    QWORD PTR [rsi+0x9c0],rax
  40a28d:	mov    rcx,rbx
  40a290:	mov    rdx,rsi
  40a293:	call   40d480 <__swc_fn_6b1cf01f_000166_f6173642>
  40a298:	test   al,al
  40a29a:	jne    40a2ad <__swc_fn_6b1cf01f_000168_92b7d63c+0x7d>
  40a29c:	mov    rcx,rsi
  40a29f:	call   40e890 <__swc_fn_6b1cf01f_000080_c1514492>
  40a2a4:	xor    eax,eax
  40a2a6:	add    rsp,0x28
  40a2aa:	pop    rsi
  40a2ab:	pop    rbx
  40a2ac:	ret
  40a2ad:	lea    rcx,[rsp+0x18]
  40a2b2:	call   40ee10 <__swc_fn_6b1cf01f_000092_8252f8c0>
  40a2b7:	mov    rax,rsi
  40a2ba:	add    rsp,0x28
  40a2be:	pop    rsi
  40a2bf:	pop    rbx
  40a2c0:	ret
	...

000000000040a2d0 <__swc_fn_6b1cf01f_000171_c0e8acb1>:
  40a2d0:	xor    eax,eax
  40a2d2:	mov    edx,0x1
  40a2d7:	lock cmpxchg QWORD PTR [rcx],rdx
  40a2dc:	test   rax,rax
  40a2df:	jne    40a2e2 <__swc_fn_6b1cf01f_000171_c0e8acb1+0x12>
  40a2e1:	ret
  40a2e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2ec:	nop    DWORD PTR [rax+0x0]
  40a2f0:	mov    rax,QWORD PTR [rcx]
  40a2f3:	test   rax,rax
  40a2f6:	je     40a2d0 <__swc_fn_6b1cf01f_000171_c0e8acb1>
  40a2f8:	jmp    40a2f0 <__swc_fn_6b1cf01f_000171_c0e8acb1+0x20>
  40a2fa:	add    BYTE PTR [rax],al
  40a2fc:	add    BYTE PTR [rax],al
	...

000000000040a300 <__swc_fn_6b1cf01f_000174_176517f9>:
  40a300:	push   rsi
  40a301:	push   rdi
  40a302:	sub    rsp,0x38
  40a306:	mov    rsi,rcx
  40a309:	call   40d490 <__swc_fn_6b1cf01f_000169_4579a84c>
  40a30e:	mov    rdi,rax
  40a311:	call   40cc00 <__swc_fn_6b1cf01f_000130_c1196dfb>
  40a316:	mov    r8,rax
  40a319:	mov    rcx,rdi
  40a31c:	call   40a2d0 <__swc_fn_6b1cf01f_000171_c0e8acb1>
  40a321:	mov    rax,QWORD PTR [rdi+0x8]
  40a325:	test   rax,rax
  40a328:	je     40a365 <__swc_fn_6b1cf01f_000174_176517f9+0x65>
  40a32a:	nop    WORD PTR [rax+rax*1+0x0]
  40a330:	cmp    rax,rsi
  40a333:	je     40a365 <__swc_fn_6b1cf01f_000174_176517f9+0x65>
  40a335:	mov    r9,QWORD PTR [rax]
  40a338:	cmp    QWORD PTR [rax+0x20],r8
  40a33c:	jne    40a35d <__swc_fn_6b1cf01f_000174_176517f9+0x5d>
  40a33e:	mov    rcx,rdi
  40a341:	mov    rdx,rax
  40a344:	mov    QWORD PTR [rsp+0x28],r8
  40a349:	mov    QWORD PTR [rsp+0x30],r9
  40a34e:	call   411860 <__swc_fn_6b1cf01f_000173_f69b1f05>
  40a353:	mov    r8,QWORD PTR [rsp+0x28]
  40a358:	mov    r9,QWORD PTR [rsp+0x30]
  40a35d:	mov    rax,r9
  40a360:	test   r9,r9
  40a363:	jne    40a330 <__swc_fn_6b1cf01f_000174_176517f9+0x30>
  40a365:	xor    eax,eax
  40a367:	mov    QWORD PTR [rdi],rax
  40a36a:	add    rsp,0x38
  40a36e:	pop    rdi
  40a36f:	pop    rsi
  40a370:	ret
	...

000000000040a380 <__swc_fn_6b1cf01f_000001_46f18a51>:
  40a380:	vxorps xmm0,xmm0,xmm0
  40a384:	xor    eax,eax
  40a386:	cs nop WORD PTR [rax+rax*1+0x0]
  40a390:	cs nop WORD PTR [rax+rax*1+0x0]
  40a39a:	nop    WORD PTR [rax+rax*1+0x0]
  40a3a0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a3a5:	add    rax,0x10
  40a3a9:	cmp    rax,0x2080
  40a3b0:	jne    40a3a0 <__swc_fn_6b1cf01f_000001_46f18a51+0x20>
  40a3b2:	ret
	...

000000000040a3c0 <__swc_fn_6b1cf01f_000004_1acc36a6>:
  40a3c0:	push   rsi
  40a3c1:	push   rdi
  40a3c2:	push   r12
  40a3c4:	push   r13
  40a3c6:	push   r14
  40a3c8:	mov    rsi,rcx
  40a3cb:	mov    edi,r10d
  40a3ce:	mov    r12,rcx
  40a3d1:	mov    r13,r9
  40a3d4:	mov    ecx,DWORD PTR [rdx+0x28]
  40a3d7:	shlx   r14d,r8d,ecx
  40a3dc:	mov    rcx,rdx
  40a3df:	mov    edx,r8d
  40a3e2:	call   40d760 <__swc_fn_6b1cf01f_000011_6493fbbc>
  40a3e7:	mov    rcx,rax
  40a3ea:	mov    eax,DWORD PTR [r12+0x3c]
  40a3ef:	xor    edx,edx
  40a3f1:	div    rdi
  40a3f4:	vxorps xmm0,xmm0,xmm0
  40a3f8:	vmovdqu XMMWORD PTR [rsi],xmm0
  40a3fc:	mov    QWORD PTR [r12+0x60],0x0
  40a405:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40a40a:	mov    QWORD PTR [r12+0x10],rcx
  40a40f:	imul   rax,rdi
  40a413:	lea    rdx,[rcx+rax*1]
  40a417:	mov    QWORD PTR [r12+0x18],rdx
  40a41c:	mov    QWORD PTR [r12+0x20],rcx
  40a421:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40a426:	mov    DWORD PTR [r12+0x28],0x0
  40a42f:	mov    DWORD PTR [r12+0x68],0x0
  40a438:	mov    BYTE PTR [r12+0x39],r13b
  40a43d:	mov    BYTE PTR [r12+0x3a],r14b
  40a442:	mov    BYTE PTR [r12+0x3b],0x1
  40a448:	mov    DWORD PTR [r12+0x6c],0x0
  40a451:	mov    rcx,r12
  40a454:	mov    edx,edi
  40a456:	call   40d6c0 <__swc_fn_6b1cf01f_000005_b2240b56>
  40a45b:	pop    r14
  40a45d:	pop    r13
  40a45f:	pop    r12
  40a461:	pop    rdi
  40a462:	pop    rsi
  40a463:	ret
	...

000000000040a470 <__swc_fn_6b1cf01f_000007_614a4804>:
  40a470:	mov    r8d,0x1
  40a476:	xor    eax,eax
  40a478:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40a47e:	test   eax,eax
  40a480:	jne    40a470 <__swc_fn_6b1cf01f_000007_614a4804>
  40a482:	ret
	...

000000000040a490 <__swc_fn_6b1cf01f_000010_395bb04b>:
  40a490:	lea    r8,[rcx+0x60]
  40a494:	mov    rax,QWORD PTR [r8]
  40a497:	mov    r9,rax
  40a49a:	nop    WORD PTR [rax+rax*1+0x0]
  40a4a0:	mov    QWORD PTR [rdx],r9
  40a4a3:	mov    rax,r9
  40a4a6:	lock cmpxchg QWORD PTR [r8],rdx
  40a4ab:	cmp    rax,r9
  40a4ae:	jne    40a517 <__swc_fn_6b1cf01f_000010_395bb04b+0x87>
  40a4b0:	mov    eax,DWORD PTR [rcx+0x6c]
  40a4b3:	test   eax,eax
  40a4b5:	je     40a516 <__swc_fn_6b1cf01f_000010_395bb04b+0x86>
  40a4b7:	lea    rdx,[rcx+0x70]
  40a4bb:	mov    r9d,0x1
  40a4c1:	xor    eax,eax
  40a4c3:	lock cmpxchg DWORD PTR [rdx],r9d
  40a4c8:	test   eax,eax
  40a4ca:	jne    40a516 <__swc_fn_6b1cf01f_000010_395bb04b+0x86>
  40a4cc:	mov    rax,rcx
  40a4cf:	and    rax,0xffffffffffc00000
  40a4d6:	mov    rax,QWORD PTR [rax+0x8]
  40a4da:	test   rax,rax
  40a4dd:	jne    40a4e5 <__swc_fn_6b1cf01f_000010_395bb04b+0x55>
  40a4df:	xor    eax,eax
  40a4e1:	xchg   DWORD PTR [rdx],eax
  40a4e3:	jmp    40a516 <__swc_fn_6b1cf01f_000010_395bb04b+0x86>
  40a4e5:	lea    rdx,[rax+0x2a80]
  40a4ec:	mov    rax,QWORD PTR [rdx]
  40a4ef:	mov    r8,rax
  40a4f2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a4fc:	nop    DWORD PTR [rax+0x0]
  40a500:	mov    QWORD PTR [rcx+0x78],r8
  40a504:	mov    rax,r8
  40a507:	lock cmpxchg QWORD PTR [rdx],rcx
  40a50c:	cmp    rax,r8
  40a50f:	je     40a516 <__swc_fn_6b1cf01f_000010_395bb04b+0x86>
  40a511:	mov    r8,rax
  40a514:	jmp    40a500 <__swc_fn_6b1cf01f_000010_395bb04b+0x70>
  40a516:	ret
  40a517:	mov    r9,rax
  40a51a:	jmp    40a4a0 <__swc_fn_6b1cf01f_000010_395bb04b+0x10>
	...

000000000040a520 <__swc_fn_6b1cf01f_000013_9ba72deb>:
  40a520:	push   rsi
  40a521:	push   rdi
  40a522:	push   r12
  40a524:	push   r13
  40a526:	push   r14
  40a528:	push   r15
  40a52a:	push   rbx
  40a52b:	sub    rsp,0x30
  40a52f:	mov    QWORD PTR [rsp+0x18],r8
  40a534:	mov    rsi,rcx
  40a537:	mov    rdi,rdx
  40a53a:	mov    rdx,QWORD PTR [rsi+0x40]
  40a53e:	xchg   ax,ax
  40a540:	mov    rax,rdx
  40a543:	not    rax
  40a546:	and    rax,QWORD PTR [rsi+0x20]
  40a54a:	test   rax,rax
  40a54d:	jne    40a561 <__swc_fn_6b1cf01f_000013_9ba72deb+0x41>
  40a54f:	xor    eax,eax
  40a551:	add    rsp,0x30
  40a555:	pop    rbx
  40a556:	pop    r15
  40a558:	pop    r14
  40a55a:	pop    r13
  40a55c:	pop    r12
  40a55e:	pop    rdi
  40a55f:	pop    rsi
  40a560:	ret
  40a561:	xor    ecx,ecx
  40a563:	tzcnt  rcx,rax
  40a568:	lea    r12,[rsp+0x8]
  40a56d:	mov    DWORD PTR [rsp+0x8],ecx
  40a571:	mov    r13d,0x1
  40a577:	shl    r13,cl
  40a57a:	mov    rcx,rdx
  40a57d:	or     rcx,r13
  40a580:	mov    rax,rdx
  40a583:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40a589:	cmp    rax,rdx
  40a58c:	je     40a593 <__swc_fn_6b1cf01f_000013_9ba72deb+0x73>
  40a58e:	mov    rdx,rax
  40a591:	jmp    40a540 <__swc_fn_6b1cf01f_000013_9ba72deb+0x20>
  40a593:	mov    eax,DWORD PTR [r12]
  40a597:	shl    rax,0x4
  40a59b:	lea    r14,[rsi+rax*8+0x80]
  40a5a3:	mov    rcx,rsi
  40a5a6:	mov    rax,r12
  40a5a9:	mov    edx,DWORD PTR [rax]
  40a5ab:	call   40d760 <__swc_fn_6b1cf01f_000011_6493fbbc>
  40a5b0:	mov    r15,rax
  40a5b3:	mov    rcx,rsi
  40a5b6:	mov    rdx,r13
  40a5b9:	call   40d8c0 <__swc_fn_6b1cf01f_000017_4df2d1a0>
  40a5be:	test   al,al
  40a5c0:	je     40a5f8 <__swc_fn_6b1cf01f_000013_9ba72deb+0xd8>
  40a5c2:	mov    ecx,DWORD PTR [r14+0x3c]
  40a5c6:	lea    rdx,[rip+0x19a8b]        # 424058 <__swc_bss_base_6b1cf01f+0x18>
  40a5cd:	mov    r8,QWORD PTR [rip+0x19a84]        # 424058 <__swc_bss_base_6b1cf01f+0x18>
  40a5d4:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5de:	xchg   ax,ax
  40a5e0:	mov    r9,r8
  40a5e3:	sub    r9,rcx
  40a5e6:	mov    rax,r8
  40a5e9:	lock cmpxchg QWORD PTR [rdx],r9
  40a5ee:	cmp    rax,r8
  40a5f1:	je     40a659 <__swc_fn_6b1cf01f_000013_9ba72deb+0x139>
  40a5f3:	mov    r8,rax
  40a5f6:	jmp    40a5e0 <__swc_fn_6b1cf01f_000013_9ba72deb+0xc0>
  40a5f8:	mov    rcx,rsi
  40a5fb:	mov    rax,r12
  40a5fe:	mov    edx,DWORD PTR [rax]
  40a600:	call   407450 <__swc_fn_6b1cf01f_000012_c7df5d22>
  40a605:	mov    rcx,r15
  40a608:	and    rcx,0xffffffffffff0000
  40a60f:	lea    rcx,[rcx+0x10000]
  40a616:	mov    rbx,rax
  40a619:	cmp    rax,rcx
  40a61c:	cmova  rbx,rcx
  40a620:	mov    rax,rbx
  40a623:	sub    rax,r15
  40a626:	mov    rcx,r15
  40a629:	mov    rdx,rax
  40a62c:	call   4072a0 <__swc_fn_6b1cf01f_000003_7ab4792e>
  40a631:	test   al,al
  40a633:	jne    40a652 <__swc_fn_6b1cf01f_000013_9ba72deb+0x132>
  40a635:	mov    rcx,rsi
  40a638:	mov    rdx,r13
  40a63b:	call   407600 <__swc_fn_6b1cf01f_000018_7d1e8a10>
  40a640:	xor    eax,eax
  40a642:	add    rsp,0x30
  40a646:	pop    rbx
  40a647:	pop    r15
  40a649:	pop    r14
  40a64b:	pop    r13
  40a64d:	pop    r12
  40a64f:	pop    rdi
  40a650:	pop    rsi
  40a651:	ret
  40a652:	sub    rbx,r15
  40a655:	mov    DWORD PTR [r14+0x3c],ebx
  40a659:	mov    rcx,r14
  40a65c:	mov    rdx,rsi
  40a65f:	mov    r8d,DWORD PTR [r12]
  40a663:	mov    r9d,edi
  40a666:	mov    rbx,QWORD PTR [rsp+0x18]
  40a66b:	mov    r10d,ebx
  40a66e:	call   40a3c0 <__swc_fn_6b1cf01f_000004_1acc36a6>
  40a673:	mov    rax,r14
  40a676:	add    rsp,0x30
  40a67a:	pop    rbx
  40a67b:	pop    r15
  40a67d:	pop    r14
  40a67f:	pop    r13
  40a681:	pop    r12
  40a683:	pop    rdi
  40a684:	pop    rsi
  40a685:	ret
	...

000000000040a690 <__swc_fn_6b1cf01f_000016_4b207b58>:
  40a690:	mov    r8,QWORD PTR [rcx+0x48]
  40a694:	cs nop WORD PTR [rax+rax*1+0x0]
  40a69e:	xchg   ax,ax
  40a6a0:	mov    r9,r8
  40a6a3:	or     r9,rdx
  40a6a6:	mov    rax,r8
  40a6a9:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40a6af:	cmp    rax,r8
  40a6b2:	jne    40a6b5 <__swc_fn_6b1cf01f_000016_4b207b58+0x25>
  40a6b4:	ret
  40a6b5:	mov    r8,rax
  40a6b8:	jmp    40a6a0 <__swc_fn_6b1cf01f_000016_4b207b58+0x10>
  40a6ba:	add    BYTE PTR [rax],al
  40a6bc:	add    BYTE PTR [rax],al
	...

000000000040a6c0 <__swc_fn_6b1cf01f_000019_2cc1532c>:
  40a6c0:	push   rsi
  40a6c1:	push   rdi
  40a6c2:	push   r12
  40a6c4:	mov    rsi,rcx
  40a6c7:	xor    edi,edi
  40a6c9:	lea    r12,[rip+0x19998]        # 424068 <__swc_bss_base_6b1cf01f+0x28>
  40a6d0:	mov    eax,DWORD PTR [r12]
  40a6d4:	xor    ecx,ecx
  40a6d6:	test   rax,rax
  40a6d9:	jbe    40a714 <__swc_fn_6b1cf01f_000019_2cc1532c+0x54>
  40a6db:	nop    DWORD PTR [rax+rax*1+0x0]
  40a6e0:	lea    rdx,[rip+0x19989]        # 424070 <__swc_bss_base_6b1cf01f+0x30>
  40a6e7:	mov    r8d,ecx
  40a6ea:	lea    r8,[r8+r8*2]
  40a6ee:	lea    r8,[rdx+r8*8]
  40a6f2:	mov    rdx,QWORD PTR [r8+0x10]
  40a6f6:	add    rdx,0x400000
  40a6fd:	cmp    rdx,0x40000000
  40a704:	ja     40a70b <__swc_fn_6b1cf01f_000019_2cc1532c+0x4b>
  40a706:	mov    rdi,r8
  40a709:	jmp    40a714 <__swc_fn_6b1cf01f_000019_2cc1532c+0x54>
  40a70b:	add    rcx,0x1
  40a70f:	cmp    rcx,rax
  40a712:	jb     40a6e0 <__swc_fn_6b1cf01f_000019_2cc1532c+0x20>
  40a714:	test   rdi,rdi
  40a717:	jne    40a7a3 <__swc_fn_6b1cf01f_000019_2cc1532c+0xe3>
  40a71d:	cmp    DWORD PTR [r12],0x10
  40a722:	jae    40a78b <__swc_fn_6b1cf01f_000019_2cc1532c+0xcb>
  40a724:	mov    ecx,0x40400000
  40a729:	call   40d680 <__swc_fn_6b1cf01f_000002_884bb5c0>
  40a72e:	test   rax,rax
  40a731:	je     40a78b <__swc_fn_6b1cf01f_000019_2cc1532c+0xcb>
  40a733:	lea    rcx,[rip+0x19936]        # 424070 <__swc_bss_base_6b1cf01f+0x30>
  40a73a:	mov    edx,DWORD PTR [r12]
  40a73e:	lea    rdx,[rdx+rdx*2]
  40a742:	lea    rdx,[rcx+rdx*8]
  40a746:	mov    QWORD PTR [rdx],rax
  40a749:	lea    rax,[rax+0x3fffff]
  40a750:	and    rax,0xffffffffffc00000
  40a757:	mov    QWORD PTR [rdx+0x8],rax
  40a75b:	mov    QWORD PTR [rdx+0x10],0x0
  40a763:	mov    edx,DWORD PTR [rip+0x198ff]        # 424068 <__swc_bss_base_6b1cf01f+0x28>
  40a769:	nop    DWORD PTR [rax+0x0]
  40a770:	lea    r9d,[rdx+0x1]
  40a774:	mov    rax,rdx
  40a777:	lock cmpxchg DWORD PTR [r12],r9d
  40a77d:	mov    r8d,eax
  40a780:	cmp    eax,edx
  40a782:	je     40a792 <__swc_fn_6b1cf01f_000019_2cc1532c+0xd2>
  40a784:	mov    rdx,r8
  40a787:	jmp    40a770 <__swc_fn_6b1cf01f_000019_2cc1532c+0xb0>
  40a789:	jmp    40a792 <__swc_fn_6b1cf01f_000019_2cc1532c+0xd2>
  40a78b:	xor    eax,eax
  40a78d:	pop    r12
  40a78f:	pop    rdi
  40a790:	pop    rsi
  40a791:	ret
  40a792:	mov    eax,DWORD PTR [rip+0x198d0]        # 424068 <__swc_bss_base_6b1cf01f+0x28>
  40a798:	sub    eax,0x1
  40a79b:	lea    rdi,[rax+rax*2]
  40a79f:	lea    rdi,[rcx+rdi*8]
  40a7a3:	mov    r12,QWORD PTR [rdi+0x8]
  40a7a7:	add    r12,QWORD PTR [rdi+0x10]
  40a7ab:	mov    rcx,r12
  40a7ae:	mov    edx,0x3000
  40a7b3:	call   4072a0 <__swc_fn_6b1cf01f_000003_7ab4792e>
  40a7b8:	test   al,al
  40a7ba:	jne    40a7c3 <__swc_fn_6b1cf01f_000019_2cc1532c+0x103>
  40a7bc:	xor    eax,eax
  40a7be:	pop    r12
  40a7c0:	pop    rdi
  40a7c1:	pop    rsi
  40a7c2:	ret
  40a7c3:	vxorps xmm0,xmm0,xmm0
  40a7c7:	xor    eax,eax
  40a7c9:	cs nop WORD PTR [rax+rax*1+0x0]
  40a7d3:	cs nop WORD PTR [rax+rax*1+0x0]
  40a7dd:	nop    DWORD PTR [rax]
  40a7e0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40a7e6:	add    rax,0x10
  40a7ea:	cmp    rax,0x3000
  40a7f1:	jne    40a7e0 <__swc_fn_6b1cf01f_000019_2cc1532c+0x120>
  40a7f3:	mov    DWORD PTR [r12+0x28],esi
  40a7f8:	mov    eax,0x40
  40a7fd:	mov    ecx,esi
  40a7ff:	shr    eax,cl
  40a801:	mov    DWORD PTR [r12+0x2c],eax
  40a806:	cmp    DWORD PTR [r12+0x2c],0x40
  40a80c:	jb     40a817 <__swc_fn_6b1cf01f_000019_2cc1532c+0x157>
  40a80e:	mov    rax,0xffffffffffffffff
  40a815:	jmp    40a827 <__swc_fn_6b1cf01f_000019_2cc1532c+0x167>
  40a817:	mov    eax,0x1
  40a81c:	mov    ecx,DWORD PTR [r12+0x2c]
  40a821:	shl    rax,cl
  40a824:	dec    rax
  40a827:	mov    QWORD PTR [r12+0x20],rax
  40a82c:	mov    DWORD PTR [r12],0x4e540001
  40a834:	mov    DWORD PTR [r12+0x4],0x53474d45
  40a83d:	add    QWORD PTR [rdi+0x10],0x400000
  40a845:	mov    rax,r12
  40a848:	pop    r12
  40a84a:	pop    rdi
  40a84b:	pop    rsi
  40a84c:	ret
  40a84d:	add    BYTE PTR [rax],al
	...

000000000040a850 <__swc_fn_6b1cf01f_000022_3a2e2048>:
  40a850:	mov    eax,0x1
  40a855:	mov    edx,DWORD PTR [rip+0x1980d]        # 424068 <__swc_bss_base_6b1cf01f+0x28>
  40a85b:	cmp    eax,edx
  40a85d:	jae    40a8ab <__swc_fn_6b1cf01f_000022_3a2e2048+0x5b>
  40a85f:	nop
  40a860:	lea    r8,[rip+0x19809]        # 424070 <__swc_bss_base_6b1cf01f+0x30>
  40a867:	lea    r9,[rax+rax*2]
  40a86b:	lea    r9,[r8+r9*8]
  40a86f:	mov    r8,rcx
  40a872:	sub    r8,QWORD PTR [r9+0x8]
  40a876:	mov    r9,QWORD PTR [r9+0x10]
  40a87a:	cmp    r8,r9
  40a87d:	jae    40a8a5 <__swc_fn_6b1cf01f_000022_3a2e2048+0x55>
  40a87f:	mov    rax,rcx
  40a882:	and    rax,0xffffffffffc00000
  40a889:	shr    rcx,0x10
  40a88d:	and    ecx,0x3f
  40a890:	mov    edx,DWORD PTR [rax+0x28]
  40a893:	shrx   ecx,ecx,edx
  40a898:	shl    rcx,0x4
  40a89c:	lea    rax,[rax+rcx*8+0x80]
  40a8a4:	ret
  40a8a5:	inc    eax
  40a8a7:	cmp    eax,edx
  40a8a9:	jb     40a860 <__swc_fn_6b1cf01f_000022_3a2e2048+0x10>
  40a8ab:	xor    eax,eax
  40a8ad:	ret
	...

000000000040a8b0 <__swc_fn_6b1cf01f_000025_4aca8b9e>:
  40a8b0:	vxorps xmm0,xmm0,xmm0
  40a8b4:	vmovups XMMWORD PTR [rcx],xmm0
  40a8b8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a8bd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a8c2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a8c7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40a8cc:	mov    QWORD PTR [rcx+0x50],0x0
  40a8d4:	ret
	...

000000000040a8e0 <__swc_fn_6b1cf01f_000028_4aca8b9e>:
  40a8e0:	vxorps xmm0,xmm0,xmm0
  40a8e4:	xor    eax,eax
  40a8e6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a8f0:	cs nop WORD PTR [rax+rax*1+0x0]
  40a8fa:	nop    WORD PTR [rax+rax*1+0x0]
  40a900:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a905:	add    rax,0x10
  40a909:	cmp    rax,0x9b0
  40a910:	jne    40a900 <__swc_fn_6b1cf01f_000028_4aca8b9e+0x20>
  40a912:	mov    QWORD PTR [rcx+0x9b0],0x0
  40a91d:	ret
	...

000000000040a920 <__swc_fn_6b1cf01f_000031_90860ff2>:
  40a920:	push   rsi
  40a921:	push   rdi
  40a922:	sub    rsp,0x8
  40a926:	lea    rsi,[rip+0x176db]        # 422008 <__swc_data_base_6b1cf01f+0x8>
  40a92d:	mov    rax,QWORD PTR [rsi]
  40a930:	mov    ecx,0xffffffff
  40a935:	cmp    rax,rcx
  40a938:	je     40a941 <__swc_fn_6b1cf01f_000031_90860ff2+0x21>
  40a93a:	add    rsp,0x8
  40a93e:	pop    rdi
  40a93f:	pop    rsi
  40a940:	ret
  40a941:	mov    rcx,QWORD PTR [rip+0x8730]        # 413078 <__swc_fn_6b1cf01f_000176_0ce64436+0x1798>
  40a948:	call   409670 <__swc_fn_6b1cf01f_000126_102fe7b9>
  40a94d:	mov    rcx,rax
  40a950:	mov    eax,0xffffffff
  40a955:	lock cmpxchg QWORD PTR [rsi],rcx
  40a95a:	mov    rdi,rax
  40a95d:	mov    eax,0xffffffff
  40a962:	cmp    rdi,rax
  40a965:	je     40a976 <__swc_fn_6b1cf01f_000031_90860ff2+0x56>
  40a967:	call   40cb50 <__swc_fn_6b1cf01f_000127_8dffa290>
  40a96c:	mov    rax,rdi
  40a96f:	add    rsp,0x8
  40a973:	pop    rdi
  40a974:	pop    rsi
  40a975:	ret
  40a976:	mov    rax,rcx
  40a979:	add    rsp,0x8
  40a97d:	pop    rdi
  40a97e:	pop    rsi
  40a97f:	ret

000000000040a980 <__swc_fn_6b1cf01f_000034_25f19556>:
  40a980:	sub    rsp,0x8
  40a984:	vxorps xmm0,xmm0,xmm0
  40a988:	xor    eax,eax
  40a98a:	cs nop WORD PTR [rax+rax*1+0x0]
  40a994:	cs nop WORD PTR [rax+rax*1+0x0]
  40a99e:	xchg   ax,ax
  40a9a0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a9a5:	add    rax,0x10
  40a9a9:	cmp    rax,0x2b00
  40a9b0:	jne    40a9a0 <__swc_fn_6b1cf01f_000034_25f19556+0x20>
  40a9b2:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40a9bc:	xor    al,al
  40a9be:	mov    rdx,rax
  40a9c1:	xor    al,al
  40a9c3:	mov    r8,rax
  40a9c6:	xor    al,al
  40a9c8:	mov    r9,rax
  40a9cb:	xor    al,al
  40a9cd:	mov    r10,rax
  40a9d0:	xor    al,al
  40a9d2:	mov    r11,rax
  40a9d5:	call   40daf0 <__swc_fn_6b1cf01f_000035_95622a2b>
  40a9da:	add    rsp,0x8
  40a9de:	ret
	...

000000000040a9e0 <__swc_fn_6b1cf01f_000037_b4982903>:
  40a9e0:	push   rsi
  40a9e1:	push   rdi
  40a9e2:	push   r12
  40a9e4:	mov    rsi,r8
  40a9e7:	mov    rdi,rdx
  40a9ea:	mov    rcx,rdx
  40a9ed:	call   40d680 <__swc_fn_6b1cf01f_000002_884bb5c0>
  40a9f2:	mov    r12,rax
  40a9f5:	test   rax,rax
  40a9f8:	jne    40aa01 <__swc_fn_6b1cf01f_000037_b4982903+0x21>
  40a9fa:	xor    eax,eax
  40a9fc:	pop    r12
  40a9fe:	pop    rdi
  40a9ff:	pop    rsi
  40aa00:	ret
  40aa01:	mov    rcx,r12
  40aa04:	mov    rdx,rsi
  40aa07:	call   4072a0 <__swc_fn_6b1cf01f_000003_7ab4792e>
  40aa0c:	test   al,al
  40aa0e:	jne    40aa22 <__swc_fn_6b1cf01f_000037_b4982903+0x42>
  40aa10:	mov    rcx,r12
  40aa13:	mov    rdx,rdi
  40aa16:	call   40f920 <__swc_fn_6b1cf01f_000113_49b378a9>
  40aa1b:	xor    eax,eax
  40aa1d:	pop    r12
  40aa1f:	pop    rdi
  40aa20:	pop    rsi
  40aa21:	ret
  40aa22:	mov    rax,r12
  40aa25:	pop    r12
  40aa27:	pop    rdi
  40aa28:	pop    rsi
  40aa29:	ret
	...

000000000040aa40 <__swc_fn_6b1cf01f_000040_6895916d>:
  40aa40:	push   rsi
  40aa41:	push   rdi
  40aa42:	push   r12
  40aa44:	mov    rsi,rcx
  40aa47:	mov    edx,0x9b8
  40aa4c:	call   40db60 <__swc_fn_6b1cf01f_000038_788ceb38>
  40aa51:	mov    rdi,rax
  40aa54:	test   rax,rax
  40aa57:	jne    40aa60 <__swc_fn_6b1cf01f_000040_6895916d+0x20>
  40aa59:	xor    eax,eax
  40aa5b:	pop    r12
  40aa5d:	pop    rdi
  40aa5e:	pop    rsi
  40aa5f:	ret
  40aa60:	vxorps xmm0,xmm0,xmm0
  40aa64:	xor    eax,eax
  40aa66:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa70:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa7a:	nop    WORD PTR [rax+rax*1+0x0]
  40aa80:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40aa85:	add    rax,0x10
  40aa89:	cmp    rax,0x9b0
  40aa90:	jne    40aa80 <__swc_fn_6b1cf01f_000040_6895916d+0x40>
  40aa92:	mov    QWORD PTR [rdi+0x9b0],0x0
  40aa9d:	mov    QWORD PTR [rdi],rsi
  40aaa0:	call   40cc00 <__swc_fn_6b1cf01f_000130_c1196dfb>
  40aaa5:	mov    QWORD PTR [rdi+0x18],rax
  40aaa9:	lea    r12,[rsi+0x10]
  40aaad:	mov    rcx,r12
  40aab0:	call   4098c0 <__swc_fn_6b1cf01f_000135_e3032dc2>
  40aab5:	mov    rax,QWORD PTR [rsi+0x20]
  40aab9:	mov    QWORD PTR [rdi+0x8],rax
  40aabd:	mov    rax,QWORD PTR [rsi+0x20]
  40aac1:	test   rax,rax
  40aac4:	je     40aaca <__swc_fn_6b1cf01f_000040_6895916d+0x8a>
  40aac6:	mov    QWORD PTR [rax+0x10],rdi
  40aaca:	mov    QWORD PTR [rsi+0x20],rdi
  40aace:	mov    rcx,r12
  40aad1:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  40aad6:	mov    rax,rdi
  40aad9:	pop    r12
  40aadb:	pop    rdi
  40aadc:	pop    rsi
  40aadd:	ret
	...

000000000040aae0 <__swc_fn_6b1cf01f_000043_957e4917>:
  40aae0:	mov    rax,QWORD PTR [rdx+0x10]
  40aae4:	test   rax,rax
  40aae7:	je     40aaf3 <__swc_fn_6b1cf01f_000043_957e4917+0x13>
  40aae9:	mov    rcx,QWORD PTR [rdx+0x8]
  40aaed:	mov    QWORD PTR [rax+0x8],rcx
  40aaf1:	jmp    40aafb <__swc_fn_6b1cf01f_000043_957e4917+0x1b>
  40aaf3:	mov    rax,QWORD PTR [rdx+0x8]
  40aaf7:	mov    QWORD PTR [rcx+0x20],rax
  40aafb:	mov    rax,QWORD PTR [rdx+0x8]
  40aaff:	test   rax,rax
  40ab02:	je     40ab0c <__swc_fn_6b1cf01f_000043_957e4917+0x2c>
  40ab04:	mov    rcx,QWORD PTR [rdx+0x10]
  40ab08:	mov    QWORD PTR [rax+0x10],rcx
  40ab0c:	vxorps xmm0,xmm0,xmm0
  40ab10:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40ab15:	ret
	...

000000000040ab20 <__swc_fn_6b1cf01f_000046_88f44774>:
  40ab20:	sub    rsp,0x8
  40ab24:	mov    r9,r8
  40ab27:	mov    r10,rdx
  40ab2a:	call   40dc10 <__swc_fn_6b1cf01f_000044_9c2ade9b>
  40ab2f:	mov    eax,0x1
  40ab34:	xchg   DWORD PTR [r9+0x6c],eax
  40ab38:	mov    rax,QWORD PTR [r9+0x60]
  40ab3c:	test   rax,rax
  40ab3f:	je     40ab83 <__swc_fn_6b1cf01f_000046_88f44774+0x63>
  40ab41:	xor    eax,eax
  40ab43:	xchg   DWORD PTR [r9+0x6c],eax
  40ab47:	movzx  eax,BYTE PTR [r9+0x39]
  40ab4c:	lea    rax,[rax+rax*4]
  40ab50:	lea    rax,[r10+rax*8+0x28]
  40ab55:	mov    QWORD PTR [r9+0x50],0x0
  40ab5d:	mov    rcx,QWORD PTR [rax+0x8]
  40ab61:	mov    QWORD PTR [r9+0x48],rcx
  40ab65:	mov    rcx,QWORD PTR [rax+0x8]
  40ab69:	test   rcx,rcx
  40ab6c:	je     40ab74 <__swc_fn_6b1cf01f_000046_88f44774+0x54>
  40ab6e:	mov    QWORD PTR [rcx+0x50],r9
  40ab72:	jmp    40ab78 <__swc_fn_6b1cf01f_000046_88f44774+0x58>
  40ab74:	mov    QWORD PTR [rax+0x10],r9
  40ab78:	mov    QWORD PTR [rax+0x8],r9
  40ab7c:	xor    eax,eax
  40ab7e:	add    rsp,0x8
  40ab82:	ret
  40ab83:	movzx  eax,BYTE PTR [r9+0x39]
  40ab88:	lea    rax,[rax+rax*4]
  40ab8c:	lea    rax,[r10+rax*8+0x28]
  40ab91:	mov    QWORD PTR [r9+0x50],0x0
  40ab99:	mov    rcx,QWORD PTR [rax+0x18]
  40ab9d:	mov    QWORD PTR [r9+0x48],rcx
  40aba1:	mov    rcx,QWORD PTR [rax+0x18]
  40aba5:	test   rcx,rcx
  40aba8:	je     40abae <__swc_fn_6b1cf01f_000046_88f44774+0x8e>
  40abaa:	mov    QWORD PTR [rcx+0x50],r9
  40abae:	mov    QWORD PTR [rax+0x18],r9
  40abb2:	mov    eax,0x1
  40abb7:	add    rsp,0x8
  40abbb:	ret
  40abbc:	add    BYTE PTR [rax],al
	...

000000000040abc0 <__swc_fn_6b1cf01f_000049_2ff013cc>:
  40abc0:	push   r12
  40abc2:	push   r13
  40abc4:	push   rdi
  40abc5:	push   rsi
  40abc6:	push   r14
  40abc8:	push   r15
  40abca:	sub    rsp,0x178
  40abd1:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40abda:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40abe3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40abec:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40abf5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40abfe:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40ac07:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40ac10:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40ac19:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40ac22:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40ac2b:	mov    r12,rcx
  40ac2e:	lea    rax,[rip+0x195cb]        # 424200 <__swc_bss_base_6b1cf01f+0x1c0>
  40ac35:	mov    rcx,QWORD PTR [rax]
  40ac38:	mov    r13,rcx
  40ac3b:	test   rcx,rcx
  40ac3e:	jne    40ac4e <__swc_fn_6b1cf01f_000049_2ff013cc+0x8e>
  40ac40:	mov    r13d,0x1dcd6500
  40ac46:	mov    ecx,0x1dcd6500
  40ac4b:	xchg   QWORD PTR [rax],rcx
  40ac4e:	lea    rax,[rip+0x173ab]        # 422000 <__swc_data_base_6b1cf01f>
  40ac55:	mov    rax,QWORD PTR [rax]
  40ac58:	cmp    rax,0xffffffffffffffff
  40ac5c:	je     40ac6b <__swc_fn_6b1cf01f_000049_2ff013cc+0xab>
  40ac5e:	mov    eax,eax
  40ac60:	mov    edi,eax
  40ac62:	xor    eax,eax
  40ac64:	call   407000 <pthread_getspecific@plt>
  40ac69:	jmp    40ac6d <__swc_fn_6b1cf01f_000049_2ff013cc+0xad>
  40ac6b:	xor    eax,eax
  40ac6d:	test   rax,rax
  40ac70:	jne    40ac7f <__swc_fn_6b1cf01f_000049_2ff013cc+0xbf>
  40ac72:	call   40a920 <__swc_fn_6b1cf01f_000031_90860ff2>
  40ac77:	mov    rcx,rax
  40ac7a:	call   40fc80 <__swc_fn_6b1cf01f_000128_41c3251c>
  40ac7f:	test   rax,rax
  40ac82:	je     40ac94 <__swc_fn_6b1cf01f_000049_2ff013cc+0xd4>
  40ac84:	cmp    QWORD PTR [rax],r12
  40ac87:	jne    40ac94 <__swc_fn_6b1cf01f_000049_2ff013cc+0xd4>
  40ac89:	cmp    DWORD PTR [rax+0x20],0x0
  40ac8d:	jne    40ac94 <__swc_fn_6b1cf01f_000049_2ff013cc+0xd4>
  40ac8f:	mov    rsi,rax
  40ac92:	jmp    40ac96 <__swc_fn_6b1cf01f_000049_2ff013cc+0xd6>
  40ac94:	xor    esi,esi
  40ac96:	lea    rdi,[r12+0x2a88]
  40ac9e:	mov    r14,QWORD PTR [rdi]
  40aca1:	test   r14,r14
  40aca4:	jne    40acf3 <__swc_fn_6b1cf01f_000049_2ff013cc+0x133>
  40aca6:	lea    rax,[rip+0x193ab]        # 424058 <__swc_bss_base_6b1cf01f+0x18>
  40acad:	mov    rax,QWORD PTR [rax]
  40acb0:	test   rax,rax
  40acb3:	setne  al
  40acb6:	jne    40acda <__swc_fn_6b1cf01f_000049_2ff013cc+0x11a>
  40acb8:	mov    rax,QWORD PTR [r12+0x2a70]
  40acc0:	test   rax,rax
  40acc3:	setne  al
  40acc6:	jne    40acda <__swc_fn_6b1cf01f_000049_2ff013cc+0x11a>
  40acc8:	test   rsi,rsi
  40accb:	setne  al
  40acce:	je     40acda <__swc_fn_6b1cf01f_000049_2ff013cc+0x11a>
  40acd0:	cmp    DWORD PTR [rsi+0x730],0x0
  40acd7:	setne  al
  40acda:	test   al,al
  40acdc:	je     40acee <__swc_fn_6b1cf01f_000049_2ff013cc+0x12e>
  40acde:	call   40fd30 <__swc_fn_6b1cf01f_000131_944f555b>
  40ace3:	lea    rcx,[rax+r13*1]
  40ace7:	xor    eax,eax
  40ace9:	lock cmpxchg QWORD PTR [rdi],rcx
  40acee:	jmp    40adf3 <__swc_fn_6b1cf01f_000049_2ff013cc+0x233>
  40acf3:	call   40fd30 <__swc_fn_6b1cf01f_000131_944f555b>
  40acf8:	mov    r15,rax
  40acfb:	cmp    rax,r14
  40acfe:	jb     40ad0f <__swc_fn_6b1cf01f_000049_2ff013cc+0x14f>
  40ad00:	xor    ecx,ecx
  40ad02:	mov    rax,r14
  40ad05:	lock cmpxchg QWORD PTR [rdi],rcx
  40ad0a:	cmp    rax,r14
  40ad0d:	je     40ad14 <__swc_fn_6b1cf01f_000049_2ff013cc+0x154>
  40ad0f:	jmp    40adf3 <__swc_fn_6b1cf01f_000049_2ff013cc+0x233>
  40ad14:	test   rsi,rsi
  40ad17:	je     40ad32 <__swc_fn_6b1cf01f_000049_2ff013cc+0x172>
  40ad19:	cmp    r15,r13
  40ad1c:	jb     40ad32 <__swc_fn_6b1cf01f_000049_2ff013cc+0x172>
  40ad1e:	mov    rax,r15
  40ad21:	sub    rax,r13
  40ad24:	mov    rcx,r12
  40ad27:	mov    rdx,rsi
  40ad2a:	mov    r8,rax
  40ad2d:	call   40e050 <__swc_fn_6b1cf01f_000059_3ca3ac64>
  40ad32:	lea    rsi,[r12+0x10]
  40ad37:	mov    rcx,rsi
  40ad3a:	call   4098c0 <__swc_fn_6b1cf01f_000135_e3032dc2>
  40ad3f:	mov    rax,QWORD PTR [r12+0x18]
  40ad44:	mov    rdi,rax
  40ad47:	test   rdi,rdi
  40ad4a:	je     40ad74 <__swc_fn_6b1cf01f_000049_2ff013cc+0x1b4>
  40ad4c:	cs nop WORD PTR [rax+rax*1+0x0]
  40ad56:	cs nop WORD PTR [rax+rax*1+0x0]
  40ad60:	mov    rcx,rdi
  40ad63:	call   407470 <__swc_fn_6b1cf01f_000015_07eb9884>
  40ad68:	mov    rax,QWORD PTR [rdi+0x10]
  40ad6c:	mov    rdi,rax
  40ad6f:	test   rax,rax
  40ad72:	jne    40ad60 <__swc_fn_6b1cf01f_000049_2ff013cc+0x1a0>
  40ad74:	mov    rcx,rsi
  40ad77:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  40ad7c:	mov    rcx,r12
  40ad7f:	call   4098c0 <__swc_fn_6b1cf01f_000135_e3032dc2>
  40ad84:	xor    esi,esi
  40ad86:	cs nop WORD PTR [rax+rax*1+0x0]
  40ad90:	mov    rax,QWORD PTR [r12+0x2a70]
  40ad98:	cmp    rsi,rax
  40ad9b:	jae    40adeb <__swc_fn_6b1cf01f_000049_2ff013cc+0x22b>
  40ad9d:	lea    rax,[rsi+rsi*4]
  40ada1:	lea    rax,[r12+rax*8+0x268]
  40ada9:	mov    r8,QWORD PTR [rax]
  40adac:	mov    r9,QWORD PTR [rax+0x8]
  40adb0:	mov    r10,QWORD PTR [rax+0x10]
  40adb4:	mov    rax,QWORD PTR [rax+0x20]
  40adb8:	cmp    rax,r15
  40adbb:	jae    40adc8 <__swc_fn_6b1cf01f_000049_2ff013cc+0x208>
  40adbd:	mov    rcx,r15
  40adc0:	sub    rcx,rax
  40adc3:	cmp    rcx,r13
  40adc6:	jae    40adcd <__swc_fn_6b1cf01f_000049_2ff013cc+0x20d>
  40adc8:	inc    rsi
  40adcb:	jmp    40ad90 <__swc_fn_6b1cf01f_000049_2ff013cc+0x1d0>
  40adcd:	mov    rcx,r12
  40add0:	mov    rdx,rsi
  40add3:	call   40e000 <__swc_fn_6b1cf01f_000056_38b21f11>
  40add8:	mov    rcx,r12
  40addb:	mov    rdx,r8
  40adde:	mov    r8,r9
  40ade1:	mov    r9,r10
  40ade4:	call   407750 <__swc_fn_6b1cf01f_000039_40d1e569>
  40ade9:	jmp    40ad90 <__swc_fn_6b1cf01f_000049_2ff013cc+0x1d0>
  40adeb:	mov    rcx,r12
  40adee:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  40adf3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40adfc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40ae05:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40ae0e:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40ae17:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40ae20:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40ae29:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40ae32:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40ae3b:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40ae44:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40ae4d:	add    rsp,0x178
  40ae54:	pop    r15
  40ae56:	pop    r14
  40ae58:	pop    rsi
  40ae59:	pop    rdi
  40ae5a:	pop    r13
  40ae5c:	pop    r12
  40ae5e:	ret
	...

000000000040ae60 <__swc_fn_6b1cf01f_000052_c7484fb0>:
  40ae60:	lea    rax,[rdx-0x58]
  40ae64:	ret
	...

000000000040ae70 <__swc_fn_6b1cf01f_000055_81f7713d>:
  40ae70:	push   rsi
  40ae71:	push   rdi
  40ae72:	push   r12
  40ae74:	push   r13
  40ae76:	sub    rsp,0x68
  40ae7a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40ae80:	mov    rsi,r9
  40ae83:	mov    rdi,rcx
  40ae86:	mov    r12,rdx
  40ae89:	mov    r13,r8
  40ae8c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40ae94:	jne    40aea3 <__swc_fn_6b1cf01f_000055_81f7713d+0x33>
  40ae96:	xor    eax,eax
  40ae98:	add    rsp,0x68
  40ae9c:	pop    r13
  40ae9e:	pop    r12
  40aea0:	pop    rdi
  40aea1:	pop    rsi
  40aea2:	ret
  40aea3:	mov    rcx,rdi
  40aea6:	call   4098c0 <__swc_fn_6b1cf01f_000135_e3032dc2>
  40aeab:	movabs rax,0x7fffffffffffffff
  40aeb5:	cmp    r12,rax
  40aeb8:	mov    rax,0xffffffffffffffff
  40aebf:	lea    rcx,[r12+r12*1]
  40aec3:	cmovbe rax,rcx
  40aec7:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40aece:	mov    rdx,rcx
  40aed1:	sub    rax,r12
  40aed4:	inc    rax
  40aed7:	xor    r8d,r8d
  40aeda:	test   rcx,rcx
  40aedd:	jbe    40af08 <__swc_fn_6b1cf01f_000055_81f7713d+0x98>
  40aedf:	nop
  40aee0:	lea    r9,[r8+r8*4]
  40aee4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40aeec:	sub    r9,r12
  40aeef:	cmp    r9,rax
  40aef2:	jae    40aeff <__swc_fn_6b1cf01f_000055_81f7713d+0x8f>
  40aef4:	mov    rdx,r8
  40aef7:	mov    rax,r9
  40aefa:	test   r9,r9
  40aefd:	je     40af08 <__swc_fn_6b1cf01f_000055_81f7713d+0x98>
  40aeff:	add    r8,0x1
  40af03:	cmp    r8,rcx
  40af06:	jb     40aee0 <__swc_fn_6b1cf01f_000055_81f7713d+0x70>
  40af08:	mov    rax,QWORD PTR [rdi+0x2a70]
  40af0f:	cmp    rdx,rax
  40af12:	jne    40af2f <__swc_fn_6b1cf01f_000055_81f7713d+0xbf>
  40af14:	mov    rcx,rdi
  40af17:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  40af1c:	xor    eax,eax
  40af1e:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40af24:	add    rsp,0x68
  40af28:	pop    r13
  40af2a:	pop    r12
  40af2c:	pop    rdi
  40af2d:	pop    rsi
  40af2e:	ret
  40af2f:	lea    rax,[rdx+rdx*4]
  40af33:	lea    rax,[rdi+rax*8+0x268]
  40af3b:	vmovups xmm6,XMMWORD PTR [rax]
  40af3f:	mov    r8,QWORD PTR [rax+0x10]
  40af43:	mov    rcx,rdi
  40af46:	call   40e000 <__swc_fn_6b1cf01f_000056_38b21f11>
  40af4b:	vpshufd xmm0,xmm6,0xee
  40af50:	vmovsd QWORD PTR [r13+0x0],xmm0
  40af56:	mov    QWORD PTR [rsi],r8
  40af59:	mov    rcx,rdi
  40af5c:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  40af61:	vmovq  rax,xmm6
  40af66:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40af6c:	add    rsp,0x68
  40af70:	pop    r13
  40af72:	pop    r12
  40af74:	pop    rdi
  40af75:	pop    rsi
  40af76:	ret
	...

000000000040af80 <__swc_fn_6b1cf01f_000058_8bd8d1d5>:
  40af80:	push   r12
  40af82:	push   r13
  40af84:	push   r14
  40af86:	push   r15
  40af88:	push   rdi
  40af89:	push   rsi
  40af8a:	sub    rsp,0x148
  40af91:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40af9a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40afa3:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40afac:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40afb5:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40afbe:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40afc7:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40afd0:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40afd9:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40afe2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40afeb:	mov    r12,r9
  40afee:	mov    r13,rcx
  40aff1:	mov    r14,rdx
  40aff4:	mov    r15,r8
  40aff7:	test   rdx,rdx
  40affa:	jne    40b00e <__swc_fn_6b1cf01f_000058_8bd8d1d5+0x8e>
  40affc:	add    rsp,0x148
  40b003:	pop    rsi
  40b004:	pop    rdi
  40b005:	pop    r15
  40b007:	pop    r14
  40b009:	pop    r13
  40b00b:	pop    r12
  40b00d:	ret
  40b00e:	cmp    r12,0x200000
  40b015:	ja     40b0a7 <__swc_fn_6b1cf01f_000058_8bd8d1d5+0x127>
  40b01b:	lea    rax,[rip+0x16fde]        # 422000 <__swc_data_base_6b1cf01f>
  40b022:	mov    rax,QWORD PTR [rax]
  40b025:	cmp    rax,0xffffffffffffffff
  40b029:	je     40b038 <__swc_fn_6b1cf01f_000058_8bd8d1d5+0xb8>
  40b02b:	mov    eax,eax
  40b02d:	mov    edi,eax
  40b02f:	xor    eax,eax
  40b031:	call   407000 <pthread_getspecific@plt>
  40b036:	jmp    40b03a <__swc_fn_6b1cf01f_000058_8bd8d1d5+0xba>
  40b038:	xor    eax,eax
  40b03a:	test   rax,rax
  40b03d:	je     40b044 <__swc_fn_6b1cf01f_000058_8bd8d1d5+0xc4>
  40b03f:	mov    rsi,rax
  40b042:	jmp    40b054 <__swc_fn_6b1cf01f_000058_8bd8d1d5+0xd4>
  40b044:	call   40a920 <__swc_fn_6b1cf01f_000031_90860ff2>
  40b049:	mov    rcx,rax
  40b04c:	call   40fc80 <__swc_fn_6b1cf01f_000128_41c3251c>
  40b051:	mov    rsi,rax
  40b054:	test   rsi,rsi
  40b057:	je     40b0a7 <__swc_fn_6b1cf01f_000058_8bd8d1d5+0x127>
  40b059:	cmp    QWORD PTR [rsi],r13
  40b05c:	jne    40b0a7 <__swc_fn_6b1cf01f_000058_8bd8d1d5+0x127>
  40b05e:	cmp    DWORD PTR [rsi+0x20],0x0
  40b062:	jne    40b0a7 <__swc_fn_6b1cf01f_000058_8bd8d1d5+0x127>
  40b064:	cmp    DWORD PTR [rsi+0x730],0x10
  40b06b:	jae    40b0a7 <__swc_fn_6b1cf01f_000058_8bd8d1d5+0x127>
  40b06d:	mov    eax,DWORD PTR [rsi+0x730]
  40b073:	lea    rdi,[rax+rax*4]
  40b077:	lea    rdi,[rsi+rdi*8+0x738]
  40b07f:	mov    QWORD PTR [rdi],r14
  40b082:	mov    QWORD PTR [rdi+0x8],r15
  40b086:	mov    QWORD PTR [rdi+0x10],r12
  40b08a:	mov    QWORD PTR [rdi+0x18],0x0
  40b092:	call   40fd30 <__swc_fn_6b1cf01f_000131_944f555b>
  40b097:	mov    QWORD PTR [rdi+0x20],rax
  40b09b:	add    DWORD PTR [rsi+0x730],0x1
  40b0a2:	jmp    40b206 <__swc_fn_6b1cf01f_000058_8bd8d1d5+0x286>
  40b0a7:	mov    rcx,r13
  40b0aa:	call   407e90 <__swc_fn_6b1cf01f_000057_5b81d8b6>
  40b0af:	mov    rsi,rax
  40b0b2:	cmp    r12,rax
  40b0b5:	jbe    40b0ea <__swc_fn_6b1cf01f_000058_8bd8d1d5+0x16a>
  40b0b7:	cmp    r12,0x10000000
  40b0be:	seta   al
  40b0c1:	ja     40b0d0 <__swc_fn_6b1cf01f_000058_8bd8d1d5+0x150>
  40b0c3:	mov    rax,QWORD PTR [r13+0x2a70]
  40b0ca:	test   rax,rax
  40b0cd:	setne  al
  40b0d0:	test   al,al
  40b0d2:	je     40b0ea <__swc_fn_6b1cf01f_000058_8bd8d1d5+0x16a>
  40b0d4:	mov    rcx,r13
  40b0d7:	mov    rdx,r14
  40b0da:	mov    r8,r15
  40b0dd:	mov    r9,r12
  40b0e0:	call   407750 <__swc_fn_6b1cf01f_000039_40d1e569>
  40b0e5:	jmp    40b206 <__swc_fn_6b1cf01f_000058_8bd8d1d5+0x286>
  40b0ea:	call   40fd30 <__swc_fn_6b1cf01f_000131_944f555b>
  40b0ef:	mov    rdi,rax
  40b0f2:	mov    rcx,r13
  40b0f5:	call   4098c0 <__swc_fn_6b1cf01f_000135_e3032dc2>
  40b0fa:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b102:	je     40b1ba <__swc_fn_6b1cf01f_000058_8bd8d1d5+0x23a>
  40b108:	nop    DWORD PTR [rax+rax*1+0x0]
  40b110:	cmp    QWORD PTR [r13+0x2a70],0x100
  40b11b:	jae    40b130 <__swc_fn_6b1cf01f_000058_8bd8d1d5+0x1b0>
  40b11d:	mov    rax,QWORD PTR [r13+0x2a68]
  40b124:	add    rax,r12
  40b127:	cmp    rax,rsi
  40b12a:	jbe    40b1ba <__swc_fn_6b1cf01f_000058_8bd8d1d5+0x23a>
  40b130:	xor    eax,eax
  40b132:	mov    rcx,QWORD PTR [r13+0x2a70]
  40b139:	mov    edx,0x1
  40b13e:	cmp    rcx,0x1
  40b142:	jbe    40b179 <__swc_fn_6b1cf01f_000058_8bd8d1d5+0x1f9>
  40b144:	cs nop WORD PTR [rax+rax*1+0x0]
  40b14e:	xchg   ax,ax
  40b150:	lea    r8,[rdx+rdx*4]
  40b154:	lea    r8,[r13+r8*8+0x268]
  40b15c:	lea    r9,[rax+rax*4]
  40b160:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40b168:	cmp    QWORD PTR [r8+0x18],r9
  40b16c:	cmovb  rax,rdx
  40b170:	add    rdx,0x1
  40b174:	cmp    rdx,rcx
  40b177:	jb     40b150 <__swc_fn_6b1cf01f_000058_8bd8d1d5+0x1d0>
  40b179:	lea    rcx,[rax+rax*4]
  40b17d:	lea    rcx,[r13+rcx*8+0x268]
  40b185:	mov    r8,QWORD PTR [rcx]
  40b188:	mov    r9,QWORD PTR [rcx+0x8]
  40b18c:	mov    r10,QWORD PTR [rcx+0x10]
  40b190:	mov    rcx,r13
  40b193:	mov    rdx,rax
  40b196:	call   40e000 <__swc_fn_6b1cf01f_000056_38b21f11>
  40b19b:	mov    rcx,r13
  40b19e:	mov    rdx,r8
  40b1a1:	mov    r8,r9
  40b1a4:	mov    r9,r10
  40b1a7:	call   407750 <__swc_fn_6b1cf01f_000039_40d1e569>
  40b1ac:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b1b4:	jne    40b110 <__swc_fn_6b1cf01f_000058_8bd8d1d5+0x190>
  40b1ba:	add    QWORD PTR [r13+0x2a78],0x1
  40b1c2:	mov    rax,QWORD PTR [r13+0x2a70]
  40b1c9:	lea    rax,[rax+rax*4]
  40b1cd:	lea    rax,[r13+rax*8+0x268]
  40b1d5:	mov    QWORD PTR [rax],r14
  40b1d8:	mov    QWORD PTR [rax+0x8],r15
  40b1dc:	mov    QWORD PTR [rax+0x10],r12
  40b1e0:	mov    rcx,QWORD PTR [r13+0x2a78]
  40b1e7:	mov    QWORD PTR [rax+0x18],rcx
  40b1eb:	mov    QWORD PTR [rax+0x20],rdi
  40b1ef:	add    QWORD PTR [r13+0x2a68],r12
  40b1f6:	add    QWORD PTR [r13+0x2a70],0x1
  40b1fe:	mov    rcx,r13
  40b201:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  40b206:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40b20f:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40b218:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40b221:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40b22a:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40b233:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40b23c:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40b245:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40b24e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40b257:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40b260:	add    rsp,0x148
  40b267:	pop    rsi
  40b268:	pop    rdi
  40b269:	pop    r15
  40b26b:	pop    r14
  40b26d:	pop    r13
  40b26f:	pop    r12
  40b271:	ret
	...

000000000040b280 <__swc_fn_6b1cf01f_000061_0a7f67d9>:
  40b280:	push   rbx
  40b281:	push   r12
  40b283:	push   r13
  40b285:	push   r14
  40b287:	push   r15
  40b289:	push   rdi
  40b28a:	push   rsi
  40b28b:	sub    rsp,0xf0
  40b292:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40b298:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40b29e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40b2a4:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40b2aa:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40b2b3:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40b2bc:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40b2c5:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40b2ce:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40b2d7:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40b2e0:	mov    eax,r8d
  40b2e3:	mov    rbx,rcx
  40b2e6:	mov    r12,rdx
  40b2e9:	mov    QWORD PTR [rsp+0x18],rdx
  40b2ee:	mov    ecx,DWORD PTR [r12+0x58]
  40b2f3:	mov    r13d,ecx
  40b2f6:	cmp    ecx,0x10
  40b2f9:	mov    ecx,0x10
  40b2fe:	cmovb  r13d,ecx
  40b302:	test   r13d,r13d
  40b305:	mov    rcx,r13
  40b308:	mov    edx,0x8
  40b30d:	cmove  ecx,edx
  40b310:	dec    rcx
  40b313:	mov    rdx,0xffffffffffffffff
  40b31a:	sub    rdx,rcx
  40b31d:	xor    r14d,r14d
  40b320:	mov    r8,rcx
  40b323:	not    r8
  40b326:	lea    rcx,[rcx+0x58]
  40b32a:	and    rcx,r8
  40b32d:	cmp    rdx,0x58
  40b331:	cmovae r14,rcx
  40b335:	cmp    eax,0xffffffff
  40b338:	jne    40b341 <__swc_fn_6b1cf01f_000061_0a7f67d9+0xc1>
  40b33a:	mov    r15,QWORD PTR [r12+0x48]
  40b33f:	jmp    40b373 <__swc_fn_6b1cf01f_000061_0a7f67d9+0xf3>
  40b341:	test   eax,eax
  40b343:	jne    40b34c <__swc_fn_6b1cf01f_000061_0a7f67d9+0xcc>
  40b345:	mov    eax,0x8
  40b34a:	jmp    40b370 <__swc_fn_6b1cf01f_000061_0a7f67d9+0xf0>
  40b34c:	cmp    eax,0x8
  40b34f:	ja     40b357 <__swc_fn_6b1cf01f_000061_0a7f67d9+0xd7>
  40b351:	shl    rax,0x4
  40b355:	jmp    40b370 <__swc_fn_6b1cf01f_000061_0a7f67d9+0xf0>
  40b357:	lea    eax,[rax-0x9]
  40b35a:	mov    ecx,eax
  40b35c:	shr    ecx,0x2
  40b35f:	and    eax,0x3
  40b362:	lea    ecx,[rcx+0x7]
  40b365:	lea    ecx,[rcx-0x2]
  40b368:	lea    eax,[rax+0x5]
  40b36b:	shlx   rax,rax,rcx
  40b370:	mov    r15,rax
  40b373:	lea    rax,[r14+r13*1]
  40b377:	mov    rcx,0xffffffffffffffff
  40b37e:	sub    rcx,rax
  40b381:	cmp    r15,rcx
  40b384:	jbe    40b394 <__swc_fn_6b1cf01f_000061_0a7f67d9+0x114>
  40b386:	mov    QWORD PTR [r12+0x40],0x0
  40b38f:	jmp    40b766 <__swc_fn_6b1cf01f_000061_0a7f67d9+0x4e6>
  40b394:	mov    QWORD PTR [rsp+0x20],r13
  40b399:	lea    r13,[rsp+0x8]
  40b39e:	add    rax,r15
  40b3a1:	mov    ecx,0x1000
  40b3a6:	test   ecx,ecx
  40b3a8:	mov    edx,0x8
  40b3ad:	cmove  ecx,edx
  40b3b0:	dec    rcx
  40b3b3:	mov    rdx,0xffffffffffffffff
  40b3ba:	sub    rdx,rcx
  40b3bd:	cmp    rax,rdx
  40b3c0:	jbe    40b3cc <__swc_fn_6b1cf01f_000061_0a7f67d9+0x14c>
  40b3c2:	mov    QWORD PTR [r13+0x0],0x0
  40b3ca:	jmp    40b3d9 <__swc_fn_6b1cf01f_000061_0a7f67d9+0x159>
  40b3cc:	add    rax,rcx
  40b3cf:	andn   rax,rcx,rax
  40b3d4:	mov    QWORD PTR [rsp+0x8],rax
  40b3d9:	cmp    QWORD PTR [r13+0x0],0x0
  40b3de:	jne    40b3ee <__swc_fn_6b1cf01f_000061_0a7f67d9+0x16e>
  40b3e0:	mov    QWORD PTR [r12+0x40],0x0
  40b3e9:	jmp    40b766 <__swc_fn_6b1cf01f_000061_0a7f67d9+0x4e6>
  40b3ee:	mov    QWORD PTR [rsp+0x30],r15
  40b3f3:	xor    r15d,r15d
  40b3f6:	mov    QWORD PTR [rsp+0x38],0x0
  40b3ff:	lea    r12,[rsp+0x10]
  40b404:	mov    QWORD PTR [rsp+0x28],r14
  40b409:	mov    r14,QWORD PTR [rsp+0x8]
  40b40e:	mov    QWORD PTR [rsp+0x10],r14
  40b413:	cmp    r14,0x10000
  40b41a:	ja     40b421 <__swc_fn_6b1cf01f_000061_0a7f67d9+0x1a1>
  40b41c:	mov    rax,r14
  40b41f:	jmp    40b472 <__swc_fn_6b1cf01f_000061_0a7f67d9+0x1f2>
  40b421:	xor    eax,eax
  40b423:	lea    rcx,[r14-0x1]
  40b427:	lzcnt  rax,rcx
  40b42c:	mov    ecx,0x3f
  40b431:	sub    rcx,rax
  40b434:	mov    eax,0x1
  40b439:	lea    rcx,[rcx-0x3]
  40b43d:	shl    rax,cl
  40b440:	mov    rcx,rax
  40b443:	cmp    rax,0x1000
  40b44a:	mov    eax,0x1000
  40b44f:	cmovb  rcx,rax
  40b453:	mov    rdx,0xffffffffffffffff
  40b45a:	sub    rdx,rcx
  40b45d:	mov    rax,r14
  40b460:	lea    r8,[r14+rcx*1-0x1]
  40b465:	neg    rcx
  40b468:	and    r8,rcx
  40b46b:	cmp    r14,rdx
  40b46e:	cmovbe rax,r8
  40b472:	mov    QWORD PTR [rsp+0x8],rax
  40b477:	lea    rax,[rip+0x16b82]        # 422000 <__swc_data_base_6b1cf01f>
  40b47e:	mov    rax,QWORD PTR [rax]
  40b481:	cmp    rax,0xffffffffffffffff
  40b485:	je     40b494 <__swc_fn_6b1cf01f_000061_0a7f67d9+0x214>
  40b487:	mov    eax,eax
  40b489:	mov    edi,eax
  40b48b:	xor    eax,eax
  40b48d:	call   407000 <pthread_getspecific@plt>
  40b492:	jmp    40b496 <__swc_fn_6b1cf01f_000061_0a7f67d9+0x216>
  40b494:	xor    eax,eax
  40b496:	test   rax,rax
  40b499:	jne    40b4a8 <__swc_fn_6b1cf01f_000061_0a7f67d9+0x228>
  40b49b:	call   40a920 <__swc_fn_6b1cf01f_000031_90860ff2>
  40b4a0:	mov    rcx,rax
  40b4a3:	call   40fc80 <__swc_fn_6b1cf01f_000128_41c3251c>
  40b4a8:	test   rax,rax
  40b4ab:	je     40b59c <__swc_fn_6b1cf01f_000061_0a7f67d9+0x31c>
  40b4b1:	cmp    QWORD PTR [rax],rbx
  40b4b4:	jne    40b59c <__swc_fn_6b1cf01f_000061_0a7f67d9+0x31c>
  40b4ba:	cmp    DWORD PTR [rax+0x20],0x0
  40b4be:	jne    40b59c <__swc_fn_6b1cf01f_000061_0a7f67d9+0x31c>
  40b4c4:	mov    rcx,QWORD PTR [rsp+0x8]
  40b4c9:	movabs rdx,0x7fffffffffffffff
  40b4d3:	cmp    rcx,rdx
  40b4d6:	mov    rdx,0xffffffffffffffff
  40b4dd:	lea    r8,[rcx+rcx*1]
  40b4e1:	cmovbe rdx,r8
  40b4e5:	mov    r8d,DWORD PTR [rax+0x730]
  40b4ec:	mov    r9d,r8d
  40b4ef:	sub    rdx,rcx
  40b4f2:	inc    rdx
  40b4f5:	xor    r10d,r10d
  40b4f8:	test   r8,r8
  40b4fb:	jbe    40b52b <__swc_fn_6b1cf01f_000061_0a7f67d9+0x2ab>
  40b4fd:	nop    DWORD PTR [rax]
  40b500:	mov    r11d,r10d
  40b503:	lea    r11,[r11+r11*4]
  40b507:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40b50f:	sub    r11,rcx
  40b512:	cmp    r11,rdx
  40b515:	jae    40b522 <__swc_fn_6b1cf01f_000061_0a7f67d9+0x2a2>
  40b517:	mov    r9d,r10d
  40b51a:	mov    rdx,r11
  40b51d:	test   r11,r11
  40b520:	je     40b52b <__swc_fn_6b1cf01f_000061_0a7f67d9+0x2ab>
  40b522:	add    r10,0x1
  40b526:	cmp    r10,r8
  40b529:	jb     40b500 <__swc_fn_6b1cf01f_000061_0a7f67d9+0x280>
  40b52b:	mov    ecx,DWORD PTR [rax+0x730]
  40b531:	cmp    r9d,ecx
  40b534:	jne    40b53a <__swc_fn_6b1cf01f_000061_0a7f67d9+0x2ba>
  40b536:	xor    eax,eax
  40b538:	jmp    40b599 <__swc_fn_6b1cf01f_000061_0a7f67d9+0x319>
  40b53a:	lea    rcx,[r9+r9*4]
  40b53e:	lea    rcx,[rax+rcx*8+0x738]
  40b546:	vmovups xmm0,XMMWORD PTR [rcx]
  40b54a:	mov    rdx,QWORD PTR [rcx+0x10]
  40b54e:	sub    DWORD PTR [rax+0x730],0x1
  40b555:	mov    r8d,DWORD PTR [rax+0x730]
  40b55c:	lea    r8,[r8+r8*4]
  40b560:	lea    r8,[rax+r8*8+0x738]
  40b568:	vmovups xmm1,XMMWORD PTR [r8]
  40b56d:	vmovups XMMWORD PTR [rcx],xmm1
  40b571:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40b577:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40b57c:	mov    rax,QWORD PTR [r8+0x20]
  40b580:	mov    QWORD PTR [rcx+0x20],rax
  40b584:	vpshufd xmm1,xmm0,0xee
  40b589:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40b58f:	mov    QWORD PTR [rsp+0x10],rdx
  40b594:	vmovq  rax,xmm0
  40b599:	mov    r15,rax
  40b59c:	test   r15,r15
  40b59f:	jne    40b5b7 <__swc_fn_6b1cf01f_000061_0a7f67d9+0x337>
  40b5a1:	mov    rcx,rbx
  40b5a4:	mov    rdx,QWORD PTR [rsp+0x8]
  40b5a9:	mov    r8,r13
  40b5ac:	mov    r9,r12
  40b5af:	call   40ae70 <__swc_fn_6b1cf01f_000055_81f7713d>
  40b5b4:	mov    r15,rax
  40b5b7:	test   r15,r15
  40b5ba:	je     40b5fb <__swc_fn_6b1cf01f_000061_0a7f67d9+0x37b>
  40b5bc:	cmp    QWORD PTR [r12],r14
  40b5c0:	jae    40b5fb <__swc_fn_6b1cf01f_000061_0a7f67d9+0x37b>
  40b5c2:	mov    rax,r15
  40b5c5:	add    rax,QWORD PTR [r12]
  40b5c9:	mov    rdx,r14
  40b5cc:	sub    rdx,QWORD PTR [r12]
  40b5d0:	mov    rcx,rax
  40b5d3:	call   4072a0 <__swc_fn_6b1cf01f_000003_7ab4792e>
  40b5d8:	test   al,al
  40b5da:	je     40b5e3 <__swc_fn_6b1cf01f_000061_0a7f67d9+0x363>
  40b5dc:	mov    QWORD PTR [rsp+0x10],r14
  40b5e1:	jmp    40b5fb <__swc_fn_6b1cf01f_000061_0a7f67d9+0x37b>
  40b5e3:	mov    rcx,rbx
  40b5e6:	mov    rdx,r15
  40b5e9:	mov    r8,QWORD PTR [rsp+0x8]
  40b5ee:	mov    r9,QWORD PTR [rsp+0x10]
  40b5f3:	call   40af80 <__swc_fn_6b1cf01f_000058_8bd8d1d5>
  40b5f8:	xor    r15d,r15d
  40b5fb:	test   r15,r15
  40b5fe:	jne    40b67a <__swc_fn_6b1cf01f_000061_0a7f67d9+0x3fa>
  40b600:	cmp    r14,0x10000
  40b607:	ja     40b60e <__swc_fn_6b1cf01f_000061_0a7f67d9+0x38e>
  40b609:	mov    rax,r14
  40b60c:	jmp    40b65f <__swc_fn_6b1cf01f_000061_0a7f67d9+0x3df>
  40b60e:	xor    eax,eax
  40b610:	lea    rcx,[r14-0x1]
  40b614:	lzcnt  rax,rcx
  40b619:	mov    ecx,0x3f
  40b61e:	sub    rcx,rax
  40b621:	mov    eax,0x1
  40b626:	lea    rcx,[rcx-0x3]
  40b62a:	shl    rax,cl
  40b62d:	mov    rcx,rax
  40b630:	cmp    rax,0x1000
  40b637:	mov    eax,0x1000
  40b63c:	cmovb  rcx,rax
  40b640:	mov    rdx,0xffffffffffffffff
  40b647:	sub    rdx,rcx
  40b64a:	mov    rax,r14
  40b64d:	lea    r8,[r14+rcx*1-0x1]
  40b652:	neg    rcx
  40b655:	and    r8,rcx
  40b658:	cmp    r14,rdx
  40b65b:	cmovbe rax,r8
  40b65f:	mov    QWORD PTR [rsp+0x8],rax
  40b664:	mov    QWORD PTR [rsp+0x10],r14
  40b669:	mov    rcx,rbx
  40b66c:	mov    rdx,rax
  40b66f:	mov    r8,r14
  40b672:	call   40a9e0 <__swc_fn_6b1cf01f_000037_b4982903>
  40b677:	mov    r15,rax
  40b67a:	test   r15,r15
  40b67d:	jne    40b68b <__swc_fn_6b1cf01f_000061_0a7f67d9+0x40b>
  40b67f:	mov    r13,QWORD PTR [rsp+0x20]
  40b684:	mov    rsi,QWORD PTR [rsp+0x38]
  40b689:	jmp    40b6c7 <__swc_fn_6b1cf01f_000061_0a7f67d9+0x447>
  40b68b:	mov    rax,r15
  40b68e:	add    rax,QWORD PTR [rsp+0x28]
  40b693:	mov    r13,QWORD PTR [rsp+0x20]
  40b698:	test   r13d,r13d
  40b69b:	mov    rcx,r13
  40b69e:	mov    edx,0x8
  40b6a3:	cmove  ecx,edx
  40b6a6:	dec    rcx
  40b6a9:	mov    rdx,0xffffffffffffffff
  40b6b0:	sub    rdx,rcx
  40b6b3:	cmp    rax,rdx
  40b6b6:	jbe    40b6bc <__swc_fn_6b1cf01f_000061_0a7f67d9+0x43c>
  40b6b8:	xor    eax,eax
  40b6ba:	jmp    40b6c4 <__swc_fn_6b1cf01f_000061_0a7f67d9+0x444>
  40b6bc:	add    rax,rcx
  40b6bf:	andn   rax,rcx,rax
  40b6c4:	mov    rsi,rax
  40b6c7:	mov    rax,QWORD PTR [rsp+0x8]
  40b6cc:	test   r15,r15
  40b6cf:	je     40b6d8 <__swc_fn_6b1cf01f_000061_0a7f67d9+0x458>
  40b6d1:	mov    rdi,QWORD PTR [rsp+0x18]
  40b6d6:	jmp    40b6ea <__swc_fn_6b1cf01f_000061_0a7f67d9+0x46a>
  40b6d8:	mov    rdi,QWORD PTR [rsp+0x18]
  40b6dd:	mov    QWORD PTR [rdi+0x40],0x0
  40b6e5:	jmp    40b766 <__swc_fn_6b1cf01f_000061_0a7f67d9+0x4e6>
  40b6ea:	lea    rdx,[rsi-0x58]
  40b6ee:	mov    QWORD PTR [rsi-0x58],r15
  40b6f2:	mov    QWORD PTR [rsi-0x50],rax
  40b6f6:	mov    rax,QWORD PTR [rsp+0x10]
  40b6fb:	mov    QWORD PTR [rsi-0x48],rax
  40b6ff:	mov    QWORD PTR [rsi-0x40],rsi
  40b703:	mov    rax,QWORD PTR [rdi+0x48]
  40b707:	mov    QWORD PTR [rsi-0x38],rax
  40b70b:	mov    rax,QWORD PTR [rsp+0x30]
  40b710:	mov    QWORD PTR [rsi-0x30],rax
  40b714:	mov    DWORD PTR [rsi-0x10],r13d
  40b718:	mov    QWORD PTR [rsi-0x28],0x0
  40b720:	mov    QWORD PTR [rsi-0x20],0x0
  40b728:	add    r15,QWORD PTR [r12]
  40b72c:	sub    r15,rsi
  40b72f:	mov    QWORD PTR [rsi-0x30],r15
  40b733:	mov    rcx,QWORD PTR [rbx+0x250]
  40b73a:	nop    WORD PTR [rax+rax*1+0x0]
  40b740:	lea    r8,[rcx+r15*1]
  40b744:	mov    rax,rcx
  40b747:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40b750:	cmp    rax,rcx
  40b753:	je     40b75a <__swc_fn_6b1cf01f_000061_0a7f67d9+0x4da>
  40b755:	mov    rcx,rax
  40b758:	jmp    40b740 <__swc_fn_6b1cf01f_000061_0a7f67d9+0x4c0>
  40b75a:	mov    rcx,rbx
  40b75d:	call   40df70 <__swc_fn_6b1cf01f_000053_82546d94>
  40b762:	mov    QWORD PTR [rdi+0x40],rsi
  40b766:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40b76c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40b772:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40b778:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40b77e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40b787:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40b790:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40b799:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40b7a2:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40b7ab:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40b7b4:	add    rsp,0xf0
  40b7bb:	pop    rsi
  40b7bc:	pop    rdi
  40b7bd:	pop    r15
  40b7bf:	pop    r14
  40b7c1:	pop    r13
  40b7c3:	pop    r12
  40b7c5:	pop    rbx
  40b7c6:	ret
	...

000000000040b7d0 <__swc_fn_6b1cf01f_000064_b0d63361>:
  40b7d0:	push   rbx
  40b7d1:	push   r12
  40b7d3:	push   rdi
  40b7d4:	push   rsi
  40b7d5:	sub    rsp,0xb8
  40b7dc:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40b7e2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40b7e8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40b7ee:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40b7f4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40b7fa:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40b800:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40b806:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40b80f:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40b818:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40b821:	mov    rbx,rdx
  40b824:	mov    r12,rcx
  40b827:	cmp    DWORD PTR [rbx+0x58],0x0
  40b82b:	je     40b845 <__swc_fn_6b1cf01f_000064_b0d63361+0x75>
  40b82d:	mov    eax,DWORD PTR [rbx+0x58]
  40b830:	sub    eax,0x1
  40b833:	test   DWORD PTR [rbx+0x58],eax
  40b836:	je     40b845 <__swc_fn_6b1cf01f_000064_b0d63361+0x75>
  40b838:	mov    QWORD PTR [rbx+0x40],0x0
  40b840:	jmp    40ba57 <__swc_fn_6b1cf01f_000064_b0d63361+0x287>
  40b845:	cmp    QWORD PTR [rbx+0x48],0x0
  40b84a:	jne    40b859 <__swc_fn_6b1cf01f_000064_b0d63361+0x89>
  40b84c:	mov    QWORD PTR [rbx+0x40],0x0
  40b854:	jmp    40ba57 <__swc_fn_6b1cf01f_000064_b0d63361+0x287>
  40b859:	lea    rax,[rsp+0x8]
  40b85e:	mov    rcx,QWORD PTR [rbx+0x48]
  40b862:	cmp    rcx,0x8
  40b866:	ja     40b870 <__swc_fn_6b1cf01f_000064_b0d63361+0xa0>
  40b868:	mov    DWORD PTR [rax],0x0
  40b86e:	jmp    40b8cb <__swc_fn_6b1cf01f_000064_b0d63361+0xfb>
  40b870:	cmp    rcx,0x80
  40b877:	ja     40b887 <__swc_fn_6b1cf01f_000064_b0d63361+0xb7>
  40b879:	lea    rcx,[rcx+0xf]
  40b87d:	shr    rcx,0x4
  40b881:	mov    DWORD PTR [rsp+0x8],ecx
  40b885:	jmp    40b8cb <__swc_fn_6b1cf01f_000064_b0d63361+0xfb>
  40b887:	cmp    rcx,0x10000
  40b88e:	jbe    40b898 <__swc_fn_6b1cf01f_000064_b0d63361+0xc8>
  40b890:	mov    DWORD PTR [rax],0xffffffff
  40b896:	jmp    40b8cb <__swc_fn_6b1cf01f_000064_b0d63361+0xfb>
  40b898:	dec    rcx
  40b89b:	xor    edx,edx
  40b89d:	lzcnt  rdx,rcx
  40b8a2:	mov    r8d,0x3f
  40b8a8:	sub    r8d,edx
  40b8ab:	lea    edx,[r8-0x2]
  40b8af:	shrx   rcx,rcx,rdx
  40b8b4:	and    ecx,0x3
  40b8b7:	lea    edx,[r8-0x7]
  40b8bb:	lea    edx,[rdx*4+0x0]
  40b8c2:	lea    edx,[rdx+0x9]
  40b8c5:	add    edx,ecx
  40b8c7:	mov    DWORD PTR [rsp+0x8],edx
  40b8cb:	cmp    DWORD PTR [rax],0x0
  40b8ce:	jne    40b8de <__swc_fn_6b1cf01f_000064_b0d63361+0x10e>
  40b8d0:	cmp    DWORD PTR [rbx+0x58],0x8
  40b8d4:	jbe    40b8de <__swc_fn_6b1cf01f_000064_b0d63361+0x10e>
  40b8d6:	mov    DWORD PTR [rsp+0x8],0x1
  40b8de:	cmp    DWORD PTR [rbx+0x58],0x10
  40b8e2:	jbe    40b961 <__swc_fn_6b1cf01f_000064_b0d63361+0x191>
  40b8e8:	cmp    DWORD PTR [rbx+0x58],0x40
  40b8ec:	ja     40b961 <__swc_fn_6b1cf01f_000064_b0d63361+0x191>
  40b8ee:	cmp    DWORD PTR [rax],0xffffffff
  40b8f1:	je     40b961 <__swc_fn_6b1cf01f_000064_b0d63361+0x191>
  40b8f3:	mov    ecx,DWORD PTR [rsp+0x8]
  40b8f7:	mov    edx,DWORD PTR [rbx+0x58]
  40b8fa:	dec    rdx
  40b8fd:	cmp    ecx,0x2d
  40b900:	jae    40b958 <__swc_fn_6b1cf01f_000064_b0d63361+0x188>
  40b902:	cs nop WORD PTR [rax+rax*1+0x0]
  40b90c:	nop    DWORD PTR [rax+0x0]
  40b910:	mov    r8d,ecx
  40b913:	test   ecx,ecx
  40b915:	jne    40b91f <__swc_fn_6b1cf01f_000064_b0d63361+0x14f>
  40b917:	mov    r8d,0x8
  40b91d:	jmp    40b94b <__swc_fn_6b1cf01f_000064_b0d63361+0x17b>
  40b91f:	cmp    r8d,0x8
  40b923:	ja     40b92b <__swc_fn_6b1cf01f_000064_b0d63361+0x15b>
  40b925:	shl    r8,0x4
  40b929:	jmp    40b94b <__swc_fn_6b1cf01f_000064_b0d63361+0x17b>
  40b92b:	lea    r8d,[r8-0x9]
  40b92f:	mov    r9d,r8d
  40b932:	shr    r9d,0x2
  40b936:	and    r8d,0x3
  40b93a:	lea    r9d,[r9+0x7]
  40b93e:	lea    r9d,[r9-0x2]
  40b942:	lea    r8d,[r8+0x5]
  40b946:	shlx   r8,r8,r9
  40b94b:	test   r8,rdx
  40b94e:	je     40b95d <__swc_fn_6b1cf01f_000064_b0d63361+0x18d>
  40b950:	add    ecx,0x1
  40b953:	cmp    ecx,0x2d
  40b956:	jb     40b910 <__swc_fn_6b1cf01f_000064_b0d63361+0x140>
  40b958:	mov    ecx,0xffffffff
  40b95d:	mov    DWORD PTR [rsp+0x8],ecx
  40b961:	mov    ecx,DWORD PTR [rsp+0x8]
  40b965:	cmp    ecx,0xffffffff
  40b968:	je     40b970 <__swc_fn_6b1cf01f_000064_b0d63361+0x1a0>
  40b96a:	cmp    DWORD PTR [rbx+0x58],0x40
  40b96e:	jbe    40b983 <__swc_fn_6b1cf01f_000064_b0d63361+0x1b3>
  40b970:	mov    rcx,r12
  40b973:	mov    rdx,rbx
  40b976:	mov    r8d,DWORD PTR [rax]
  40b979:	call   40b280 <__swc_fn_6b1cf01f_000061_0a7f67d9>
  40b97e:	jmp    40ba57 <__swc_fn_6b1cf01f_000064_b0d63361+0x287>
  40b983:	lea    rax,[rip+0x16676]        # 422000 <__swc_data_base_6b1cf01f>
  40b98a:	mov    rax,QWORD PTR [rax]
  40b98d:	cmp    rax,0xffffffffffffffff
  40b991:	je     40b9a0 <__swc_fn_6b1cf01f_000064_b0d63361+0x1d0>
  40b993:	mov    eax,eax
  40b995:	mov    edi,eax
  40b997:	xor    eax,eax
  40b999:	call   407000 <pthread_getspecific@plt>
  40b99e:	jmp    40b9a2 <__swc_fn_6b1cf01f_000064_b0d63361+0x1d2>
  40b9a0:	xor    eax,eax
  40b9a2:	test   rax,rax
  40b9a5:	jne    40b9b4 <__swc_fn_6b1cf01f_000064_b0d63361+0x1e4>
  40b9a7:	call   40a920 <__swc_fn_6b1cf01f_000031_90860ff2>
  40b9ac:	mov    rcx,rax
  40b9af:	call   40fc80 <__swc_fn_6b1cf01f_000128_41c3251c>
  40b9b4:	test   rax,rax
  40b9b7:	je     40b9c4 <__swc_fn_6b1cf01f_000064_b0d63361+0x1f4>
  40b9b9:	cmp    QWORD PTR [rax],r12
  40b9bc:	jne    40b9c4 <__swc_fn_6b1cf01f_000064_b0d63361+0x1f4>
  40b9be:	cmp    DWORD PTR [rax+0x20],0x0
  40b9c2:	je     40b9cf <__swc_fn_6b1cf01f_000064_b0d63361+0x1ff>
  40b9c4:	mov    rcx,r12
  40b9c7:	mov    rdx,rax
  40b9ca:	call   40dbb0 <__swc_fn_6b1cf01f_000041_414cc921>
  40b9cf:	test   rax,rax
  40b9d2:	jne    40b9de <__swc_fn_6b1cf01f_000064_b0d63361+0x20e>
  40b9d4:	mov    QWORD PTR [rbx+0x40],0x0
  40b9dc:	jmp    40ba57 <__swc_fn_6b1cf01f_000064_b0d63361+0x287>
  40b9de:	lea    r8,[rsp+0xc]
  40b9e3:	mov    ecx,DWORD PTR [rsp+0x8]
  40b9e7:	mov    DWORD PTR [rsp+0xc],ecx
  40b9eb:	mov    ecx,DWORD PTR [r8]
  40b9ee:	lea    rcx,[rcx+rcx*4]
  40b9f2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40b9f7:	test   rcx,rcx
  40b9fa:	je     40ba33 <__swc_fn_6b1cf01f_000064_b0d63361+0x263>
  40b9fc:	mov    rdx,QWORD PTR [rcx]
  40b9ff:	test   rdx,rdx
  40ba02:	je     40ba10 <__swc_fn_6b1cf01f_000064_b0d63361+0x240>
  40ba04:	mov    r9,QWORD PTR [rdx]
  40ba07:	mov    QWORD PTR [rcx],r9
  40ba0a:	add    DWORD PTR [rcx+0x28],0x1
  40ba0e:	jmp    40ba2e <__swc_fn_6b1cf01f_000064_b0d63361+0x25e>
  40ba10:	mov    rdx,QWORD PTR [rcx+0x18]
  40ba14:	cmp    QWORD PTR [rcx+0x20],rdx
  40ba18:	jae    40ba2c <__swc_fn_6b1cf01f_000064_b0d63361+0x25c>
  40ba1a:	mov    rdx,QWORD PTR [rcx+0x20]
  40ba1e:	mov    r9d,DWORD PTR [rcx+0x2c]
  40ba22:	add    QWORD PTR [rcx+0x20],r9
  40ba26:	add    DWORD PTR [rcx+0x28],0x1
  40ba2a:	jmp    40ba2e <__swc_fn_6b1cf01f_000064_b0d63361+0x25e>
  40ba2c:	xor    edx,edx
  40ba2e:	test   rdx,rdx
  40ba31:	jne    40ba44 <__swc_fn_6b1cf01f_000064_b0d63361+0x274>
  40ba33:	mov    rcx,r12
  40ba36:	mov    rdx,rax
  40ba39:	mov    r8d,DWORD PTR [r8]
  40ba3c:	call   40dd20 <__swc_fn_6b1cf01f_000050_ab8077df>
  40ba41:	mov    rdx,rax
  40ba44:	test   rdx,rdx
  40ba47:	jne    40ba53 <__swc_fn_6b1cf01f_000064_b0d63361+0x283>
  40ba49:	mov    QWORD PTR [rbx+0x40],0x0
  40ba51:	jmp    40ba57 <__swc_fn_6b1cf01f_000064_b0d63361+0x287>
  40ba53:	mov    QWORD PTR [rbx+0x40],rdx
  40ba57:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ba5d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40ba63:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40ba69:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ba6f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ba75:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ba7b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ba81:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ba8a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ba93:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ba9c:	add    rsp,0xb8
  40baa3:	pop    rsi
  40baa4:	pop    rdi
  40baa5:	pop    r12
  40baa7:	pop    rbx
  40baa8:	ret
  40baa9:	add    BYTE PTR [rax],al
  40baab:	add    BYTE PTR [rax],al
  40baad:	add    BYTE PTR [rax],al
	...

000000000040bab0 <__swc_fn_6b1cf01f_000067_94a51053>:
  40bab0:	ret
	...

000000000040bac0 <__swc_fn_6b1cf01f_000070_3181d86c>:
  40bac0:	push   r12
  40bac2:	push   r13
  40bac4:	push   r14
  40bac6:	push   rdi
  40bac7:	push   rsi
  40bac8:	sub    rsp,0x1a0
  40bacf:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40bad8:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40bae1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40baea:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40baf3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40bafc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40bb05:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40bb0e:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40bb17:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40bb20:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40bb29:	mov    r12,rdx
  40bb2c:	mov    r13,rcx
  40bb2f:	mov    rax,QWORD PTR [r12+0x48]
  40bb34:	mov    ecx,DWORD PTR [r12+0x58]
  40bb39:	lea    rdx,[rax-0x1]
  40bb3d:	cmp    rdx,0x10000
  40bb44:	jae    40bc3e <__swc_fn_6b1cf01f_000070_3181d86c+0x17e>
  40bb4a:	cmp    rax,0x8
  40bb4e:	ja     40bb55 <__swc_fn_6b1cf01f_000070_3181d86c+0x95>
  40bb50:	xor    r14d,r14d
  40bb53:	jmp    40bba7 <__swc_fn_6b1cf01f_000070_3181d86c+0xe7>
  40bb55:	cmp    rax,0x80
  40bb5c:	ja     40bb68 <__swc_fn_6b1cf01f_000070_3181d86c+0xa8>
  40bb5e:	lea    r14,[rax+0xf]
  40bb62:	shr    r14,0x4
  40bb66:	jmp    40bba7 <__swc_fn_6b1cf01f_000070_3181d86c+0xe7>
  40bb68:	cmp    rax,0x10000
  40bb6f:	jbe    40bb79 <__swc_fn_6b1cf01f_000070_3181d86c+0xb9>
  40bb71:	mov    r14d,0xffffffff
  40bb77:	jmp    40bba7 <__swc_fn_6b1cf01f_000070_3181d86c+0xe7>
  40bb79:	xor    eax,eax
  40bb7b:	lzcnt  rax,rdx
  40bb80:	mov    r8d,0x3f
  40bb86:	sub    r8d,eax
  40bb89:	lea    eax,[r8-0x2]
  40bb8d:	shrx   rax,rdx,rax
  40bb92:	and    eax,0x3
  40bb95:	lea    edx,[r8-0x7]
  40bb99:	lea    edx,[rdx*4+0x0]
  40bba0:	lea    edx,[rdx+0x9]
  40bba3:	lea    r14d,[rdx+rax*1]
  40bba7:	cmp    ecx,0x8
  40bbaa:	jbe    40bbc3 <__swc_fn_6b1cf01f_000070_3181d86c+0x103>
  40bbac:	cmp    ecx,0x10
  40bbaf:	jne    40bc3e <__swc_fn_6b1cf01f_000070_3181d86c+0x17e>
  40bbb5:	test   r14d,r14d
  40bbb8:	mov    eax,0x1
  40bbbd:	cmove  r14d,eax
  40bbc1:	jmp    40bbca <__swc_fn_6b1cf01f_000070_3181d86c+0x10a>
  40bbc3:	lea    eax,[rcx-0x1]
  40bbc6:	test   eax,ecx
  40bbc8:	jne    40bc3e <__swc_fn_6b1cf01f_000070_3181d86c+0x17e>
  40bbca:	lea    rax,[rip+0x1642f]        # 422000 <__swc_data_base_6b1cf01f>
  40bbd1:	mov    rax,QWORD PTR [rax]
  40bbd4:	cmp    rax,0xffffffffffffffff
  40bbd8:	je     40bbe7 <__swc_fn_6b1cf01f_000070_3181d86c+0x127>
  40bbda:	mov    eax,eax
  40bbdc:	mov    edi,eax
  40bbde:	xor    eax,eax
  40bbe0:	call   407000 <pthread_getspecific@plt>
  40bbe5:	jmp    40bbe9 <__swc_fn_6b1cf01f_000070_3181d86c+0x129>
  40bbe7:	xor    eax,eax
  40bbe9:	test   rax,rax
  40bbec:	je     40bc3e <__swc_fn_6b1cf01f_000070_3181d86c+0x17e>
  40bbee:	cmp    QWORD PTR [rax],r13
  40bbf1:	jne    40bc3e <__swc_fn_6b1cf01f_000070_3181d86c+0x17e>
  40bbf3:	lea    rcx,[r14+r14*4]
  40bbf7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40bbfc:	test   rax,rax
  40bbff:	je     40bc3e <__swc_fn_6b1cf01f_000070_3181d86c+0x17e>
  40bc01:	mov    rcx,QWORD PTR [rax]
  40bc04:	test   rcx,rcx
  40bc07:	je     40bc15 <__swc_fn_6b1cf01f_000070_3181d86c+0x155>
  40bc09:	mov    rdx,QWORD PTR [rcx]
  40bc0c:	mov    QWORD PTR [rax],rdx
  40bc0f:	add    DWORD PTR [rax+0x28],0x1
  40bc13:	jmp    40bc32 <__swc_fn_6b1cf01f_000070_3181d86c+0x172>
  40bc15:	mov    rcx,QWORD PTR [rax+0x18]
  40bc19:	cmp    QWORD PTR [rax+0x20],rcx
  40bc1d:	jae    40bc30 <__swc_fn_6b1cf01f_000070_3181d86c+0x170>
  40bc1f:	mov    rcx,QWORD PTR [rax+0x20]
  40bc23:	mov    edx,DWORD PTR [rax+0x2c]
  40bc26:	add    QWORD PTR [rax+0x20],rdx
  40bc2a:	add    DWORD PTR [rax+0x28],0x1
  40bc2e:	jmp    40bc32 <__swc_fn_6b1cf01f_000070_3181d86c+0x172>
  40bc30:	xor    ecx,ecx
  40bc32:	test   rcx,rcx
  40bc35:	je     40bc3e <__swc_fn_6b1cf01f_000070_3181d86c+0x17e>
  40bc37:	mov    QWORD PTR [r12+0x40],rcx
  40bc3c:	jmp    40bc49 <__swc_fn_6b1cf01f_000070_3181d86c+0x189>
  40bc3e:	mov    rcx,r13
  40bc41:	mov    rdx,r12
  40bc44:	call   40e7a0 <__swc_fn_6b1cf01f_000071_0d1ef36f>
  40bc49:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40bc52:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40bc5b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40bc64:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40bc6d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40bc76:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40bc7f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40bc88:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40bc91:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40bc9a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40bca3:	add    rsp,0x1a0
  40bcaa:	pop    rsi
  40bcab:	pop    rdi
  40bcac:	pop    r14
  40bcae:	pop    r13
  40bcb0:	pop    r12
  40bcb2:	ret
	...

000000000040bcc0 <__swc_fn_6b1cf01f_000073_c6c71bf7>:
  40bcc0:	push   r12
  40bcc2:	push   r13
  40bcc4:	push   r14
  40bcc6:	push   r15
  40bcc8:	push   rdi
  40bcc9:	push   rsi
  40bcca:	sub    rsp,0x188
  40bcd1:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40bcda:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40bce3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40bcec:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40bcf5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40bcfe:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40bd07:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40bd10:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40bd19:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40bd22:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40bd2b:	mov    r12,rdx
  40bd2e:	mov    r13,rcx
  40bd31:	mov    r14,QWORD PTR [r12+0x40]
  40bd36:	lea    rax,[rip+0x18333]        # 424070 <__swc_bss_base_6b1cf01f+0x30>
  40bd3d:	mov    rcx,r14
  40bd40:	sub    rcx,QWORD PTR [rax+0x8]
  40bd44:	mov    rax,QWORD PTR [rip+0x18335]        # 424080 <__swc_bss_base_6b1cf01f+0x40>
  40bd4b:	cmp    rcx,rax
  40bd4e:	jae    40bd7a <__swc_fn_6b1cf01f_000073_c6c71bf7+0xba>
  40bd50:	mov    rax,r14
  40bd53:	and    rax,0xffffffffffc00000
  40bd5a:	mov    rcx,r14
  40bd5d:	shr    rcx,0x10
  40bd61:	and    ecx,0x3f
  40bd64:	mov    edx,DWORD PTR [rax+0x28]
  40bd67:	shrx   ecx,ecx,edx
  40bd6c:	shl    rcx,0x4
  40bd70:	lea    r15,[rax+rcx*8+0x80]
  40bd78:	jmp    40bd85 <__swc_fn_6b1cf01f_000073_c6c71bf7+0xc5>
  40bd7a:	mov    rcx,r14
  40bd7d:	call   40a850 <__swc_fn_6b1cf01f_000022_3a2e2048>
  40bd82:	mov    r15,rax
  40bd85:	test   r15,r15
  40bd88:	je     40be2f <__swc_fn_6b1cf01f_000073_c6c71bf7+0x16f>
  40bd8e:	lea    rax,[rip+0x1626b]        # 422000 <__swc_data_base_6b1cf01f>
  40bd95:	mov    rax,QWORD PTR [rax]
  40bd98:	cmp    rax,0xffffffffffffffff
  40bd9c:	je     40bdab <__swc_fn_6b1cf01f_000073_c6c71bf7+0xeb>
  40bd9e:	mov    eax,eax
  40bda0:	mov    edi,eax
  40bda2:	xor    eax,eax
  40bda4:	call   407000 <pthread_getspecific@plt>
  40bda9:	jmp    40bdad <__swc_fn_6b1cf01f_000073_c6c71bf7+0xed>
  40bdab:	xor    eax,eax
  40bdad:	mov    rcx,QWORD PTR [r15+0x40]
  40bdb1:	cmp    rcx,rax
  40bdb4:	jne    40be14 <__swc_fn_6b1cf01f_000073_c6c71bf7+0x154>
  40bdb6:	test   rax,rax
  40bdb9:	je     40be2f <__swc_fn_6b1cf01f_000073_c6c71bf7+0x16f>
  40bdbb:	mov    ecx,DWORD PTR [r15+0x6c]
  40bdbf:	test   ecx,ecx
  40bdc1:	je     40bde1 <__swc_fn_6b1cf01f_000073_c6c71bf7+0x121>
  40bdc3:	mov    rcx,r13
  40bdc6:	mov    rdx,rax
  40bdc9:	mov    r8,r15
  40bdcc:	mov    QWORD PTR [rsp+0xd8],rax
  40bdd4:	call   40dcb0 <__swc_fn_6b1cf01f_000047_bc5ec610>
  40bdd9:	mov    rax,QWORD PTR [rsp+0xd8]
  40bde1:	mov    rcx,QWORD PTR [r15]
  40bde4:	mov    QWORD PTR [r14],rcx
  40bde7:	mov    QWORD PTR [r15],r14
  40bdea:	sub    DWORD PTR [r15+0x28],0x1
  40bdef:	jne    40be24 <__swc_fn_6b1cf01f_000073_c6c71bf7+0x164>
  40bdf1:	movzx  ecx,BYTE PTR [r15+0x39]
  40bdf6:	lea    rcx,[rcx+rcx*4]
  40bdfa:	lea    rcx,[rax+rcx*8+0x28]
  40bdff:	cmp    QWORD PTR [rcx],r15
  40be02:	je     40be24 <__swc_fn_6b1cf01f_000073_c6c71bf7+0x164>
  40be04:	mov    rcx,r13
  40be07:	mov    rdx,rax
  40be0a:	mov    r8,r15
  40be0d:	call   407d80 <__swc_fn_6b1cf01f_000051_f7021588>
  40be12:	jmp    40be24 <__swc_fn_6b1cf01f_000073_c6c71bf7+0x164>
  40be14:	test   rcx,rcx
  40be17:	je     40be2f <__swc_fn_6b1cf01f_000073_c6c71bf7+0x16f>
  40be19:	mov    rcx,r15
  40be1c:	mov    rdx,r14
  40be1f:	call   40a490 <__swc_fn_6b1cf01f_000010_395bb04b>
  40be24:	mov    QWORD PTR [r12+0x40],0x0
  40be2d:	jmp    40be3a <__swc_fn_6b1cf01f_000073_c6c71bf7+0x17a>
  40be2f:	mov    rcx,r13
  40be32:	mov    rdx,r12
  40be35:	call   40e7c0 <__swc_fn_6b1cf01f_000074_518516c2>
  40be3a:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40be43:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40be4c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40be55:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40be5e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40be67:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40be70:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40be79:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40be82:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40be8b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40be94:	add    rsp,0x188
  40be9b:	pop    rsi
  40be9c:	pop    rdi
  40be9d:	pop    r15
  40be9f:	pop    r14
  40bea1:	pop    r13
  40bea3:	pop    r12
  40bea5:	ret
	...

000000000040beb0 <__swc_fn_6b1cf01f_000076_9f0c6acf>:
  40beb0:	sub    rsp,0x8
  40beb4:	mov    rax,rdx
  40beb7:	mov    rdx,QWORD PTR [rax+0x40]
  40bebb:	mov    r8,rax
  40bebe:	call   40bab0 <__swc_fn_6b1cf01f_000067_94a51053>
  40bec3:	add    rsp,0x8
  40bec7:	ret
	...

000000000040bed0 <__swc_fn_6b1cf01f_000079_34776ded>:
  40bed0:	push   rsi
  40bed1:	push   rdi
  40bed2:	sub    rsp,0x8
  40bed6:	cmp    rcx,0xffffffffffffffef
  40beda:	ja     40bf00 <__swc_fn_6b1cf01f_000079_34776ded+0x30>
  40bedc:	xor    esi,esi
  40bede:	lea    rax,[rcx+0x100f]
  40bee5:	and    rax,0xfffffffffffff000
  40beec:	lea    rcx,[rcx+0x10]
  40bef0:	cmp    rcx,0xfffffffffffff000
  40bef7:	cmovbe rsi,rax
  40befb:	test   rsi,rsi
  40befe:	jne    40bf09 <__swc_fn_6b1cf01f_000079_34776ded+0x39>
  40bf00:	xor    eax,eax
  40bf02:	add    rsp,0x8
  40bf06:	pop    rdi
  40bf07:	pop    rsi
  40bf08:	ret
  40bf09:	mov    rcx,rsi
  40bf0c:	call   40c560 <__swc_fn_6b1cf01f_000109_8d425bd3>
  40bf11:	mov    rdi,rax
  40bf14:	test   rax,rax
  40bf17:	jne    40bf22 <__swc_fn_6b1cf01f_000079_34776ded+0x52>
  40bf19:	xor    eax,eax
  40bf1b:	add    rsp,0x8
  40bf1f:	pop    rdi
  40bf20:	pop    rsi
  40bf21:	ret
  40bf22:	mov    rcx,rdi
  40bf25:	mov    rdx,rsi
  40bf28:	call   409260 <__swc_fn_6b1cf01f_000111_b25e3a45>
  40bf2d:	test   al,al
  40bf2f:	jne    40bf45 <__swc_fn_6b1cf01f_000079_34776ded+0x75>
  40bf31:	mov    rcx,rdi
  40bf34:	mov    rdx,rsi
  40bf37:	call   40f920 <__swc_fn_6b1cf01f_000113_49b378a9>
  40bf3c:	xor    eax,eax
  40bf3e:	add    rsp,0x8
  40bf42:	pop    rdi
  40bf43:	pop    rsi
  40bf44:	ret
  40bf45:	mov    QWORD PTR [rdi],rsi
  40bf48:	mov    QWORD PTR [rdi+0x8],0x0
  40bf50:	lea    rax,[rdi+0x10]
  40bf54:	add    rsp,0x8
  40bf58:	pop    rdi
  40bf59:	pop    rsi
  40bf5a:	ret
  40bf5b:	add    BYTE PTR [rax],al
  40bf5d:	add    BYTE PTR [rax],al
	...

000000000040bf60 <__swc_fn_6b1cf01f_000082_754dcd57>:
  40bf60:	sub    rsp,0x8
  40bf64:	cmp    BYTE PTR [rcx+0x2c],0x10
  40bf68:	jne    40bf73 <__swc_fn_6b1cf01f_000082_754dcd57+0x13>
  40bf6a:	test   DWORD PTR [rcx+0x28],0x80
  40bf71:	je     40bf7b <__swc_fn_6b1cf01f_000082_754dcd57+0x1b>
  40bf73:	mov    rax,rcx
  40bf76:	add    rsp,0x8
  40bf7a:	ret
  40bf7b:	mov    rcx,QWORD PTR [rcx+0x40]
  40bf7f:	call   40bf60 <__swc_fn_6b1cf01f_000082_754dcd57>
  40bf84:	add    rsp,0x8
  40bf88:	ret
	...

000000000040bfa0 <__swc_fn_6b1cf01f_000085_1edf7c76>:
  40bfa0:	push   rsi
  40bfa1:	push   rdi
  40bfa2:	push   r12
  40bfa4:	push   r13
  40bfa6:	sub    rsp,0x8
  40bfaa:	mov    rsi,rdx
  40bfad:	mov    rdi,rcx
  40bfb0:	xor    r8d,r8d
  40bfb3:	call   4085a0 <__swc_fn_6b1cf01f_000090_a2d50c23>
  40bfb8:	test   al,al
  40bfba:	je     40bfcc <__swc_fn_6b1cf01f_000085_1edf7c76+0x2c>
  40bfbc:	mov    eax,0x1
  40bfc1:	add    rsp,0x8
  40bfc5:	pop    r13
  40bfc7:	pop    r12
  40bfc9:	pop    rdi
  40bfca:	pop    rsi
  40bfcb:	ret
  40bfcc:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40bfd1:	je     40bfe0 <__swc_fn_6b1cf01f_000085_1edf7c76+0x40>
  40bfd3:	xor    eax,eax
  40bfd5:	add    rsp,0x8
  40bfd9:	pop    r13
  40bfdb:	pop    r12
  40bfdd:	pop    rdi
  40bfde:	pop    rsi
  40bfdf:	ret
  40bfe0:	mov    r12,QWORD PTR [rsi+0x98]
  40bfe7:	mov    rax,QWORD PTR [rsi+0xa0]
  40bfee:	mov    rsi,rax
  40bff1:	xor    r13d,r13d
  40bff4:	test   rsi,rsi
  40bff7:	je     40c054 <__swc_fn_6b1cf01f_000085_1edf7c76+0xb4>
  40bff9:	cs nop WORD PTR [rax+rax*1+0x0]
  40c003:	cs nop WORD PTR [rax+rax*1+0x0]
  40c00d:	nop    DWORD PTR [rax]
  40c010:	lea    rax,[r13*8+0x0]
  40c018:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40c01d:	mov    rcx,rax
  40c020:	call   40bf60 <__swc_fn_6b1cf01f_000082_754dcd57>
  40c025:	cmp    BYTE PTR [rax+0x2c],0xe
  40c029:	jne    40c04a <__swc_fn_6b1cf01f_000085_1edf7c76+0xaa>
  40c02b:	mov    rcx,rdi
  40c02e:	mov    rdx,rax
  40c031:	call   40bfa0 <__swc_fn_6b1cf01f_000085_1edf7c76>
  40c036:	test   al,al
  40c038:	je     40c04a <__swc_fn_6b1cf01f_000085_1edf7c76+0xaa>
  40c03a:	mov    eax,0x1
  40c03f:	add    rsp,0x8
  40c043:	pop    r13
  40c045:	pop    r12
  40c047:	pop    rdi
  40c048:	pop    rsi
  40c049:	ret
  40c04a:	add    r13,0x1
  40c04e:	sub    rsi,0x1
  40c052:	jne    40c010 <__swc_fn_6b1cf01f_000085_1edf7c76+0x70>
  40c054:	xor    eax,eax
  40c056:	add    rsp,0x8
  40c05a:	pop    r13
  40c05c:	pop    r12
  40c05e:	pop    rdi
  40c05f:	pop    rsi
  40c060:	ret
	...

000000000040c070 <__swc_fn_6b1cf01f_000088_fcb34f6a>:
  40c070:	sub    rsp,0x18
  40c074:	vxorps xmm0,xmm0,xmm0
  40c078:	vmovdqu XMMWORD PTR [rsp],xmm0
  40c07d:	call   40e9d0 <__swc_fn_6b1cf01f_000089_386582f3>
  40c082:	add    rsp,0x18
  40c086:	ret
	...

000000000040c090 <__swc_fn_6b1cf01f_000091_3d2f5a0d>:
  40c090:	sub    rsp,0x8
  40c094:	mov    rcx,QWORD PTR [rip+0x1aca5]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40c09b:	test   rcx,rcx
  40c09e:	jne    40c0b0 <__swc_fn_6b1cf01f_000091_3d2f5a0d+0x20>
  40c0a0:	call   40a1d0 <__swc_fn_6b1cf01f_000165_cf398896>
  40c0a5:	lea    rcx,[rax+0x1]
  40c0a9:	mov    QWORD PTR [rip+0x1ac90],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40c0b0:	dec    rcx
  40c0b3:	call   411740 <__swc_fn_6b1cf01f_000167_fce60b2b>
  40c0b8:	mov    rax,QWORD PTR [rax+0xc0]
  40c0bf:	and    eax,0x1
  40c0c2:	setne  al
  40c0c5:	add    rsp,0x8
  40c0c9:	ret
	...

000000000040c0e0 <__swc_fn_6b1cf01f_000094_14db3cf9>:
  40c0e0:	push   rbx
  40c0e1:	push   rsi
  40c0e2:	push   rdi
  40c0e3:	push   r12
  40c0e5:	sub    rsp,0x28
  40c0e9:	mov    rbx,rcx
  40c0ec:	call   408900 <__swc_fn_6b1cf01f_000093_f8c16535>
  40c0f1:	mov    rcx,QWORD PTR [rip+0x1ac48]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40c0f8:	test   rcx,rcx
  40c0fb:	jne    40c10d <__swc_fn_6b1cf01f_000094_14db3cf9+0x2d>
  40c0fd:	call   40a1d0 <__swc_fn_6b1cf01f_000165_cf398896>
  40c102:	lea    rcx,[rax+0x1]
  40c106:	mov    QWORD PTR [rip+0x1ac33],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40c10d:	dec    rcx
  40c110:	call   411740 <__swc_fn_6b1cf01f_000167_fce60b2b>
  40c115:	mov    rsi,rax
  40c118:	lea    rcx,[rsp+0x8]
  40c11d:	call   40ee10 <__swc_fn_6b1cf01f_000092_8252f8c0>
  40c122:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40c129:	mov    r12,QWORD PTR [rsi+0xbe8]
  40c130:	lea    rcx,[rsi+0x10]
  40c134:	call   40d0c0 <__swc_fn_6b1cf01f_000157_232ffa22>
  40c139:	mov    rcx,rsi
  40c13c:	call   40ef80 <__swc_fn_6b1cf01f_000101_eab3874f>
  40c141:	vxorps xmm0,xmm0,xmm0
  40c145:	xor    eax,eax
  40c147:	cs nop WORD PTR [rax+rax*1+0x0]
  40c151:	cs nop WORD PTR [rax+rax*1+0x0]
  40c15b:	nop    DWORD PTR [rax+rax*1+0x0]
  40c160:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40c165:	add    rax,0x10
  40c169:	cmp    rax,0xbf0
  40c170:	jne    40c160 <__swc_fn_6b1cf01f_000094_14db3cf9+0x80>
  40c172:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c178:	vmovups XMMWORD PTR [rsi],xmm0
  40c17c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c182:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40c18a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40c191:	mov    QWORD PTR [rsi+0xbe8],r12
  40c198:	mov    rcx,QWORD PTR [rip+0x1aba1]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40c19f:	test   rcx,rcx
  40c1a2:	jne    40c1b4 <__swc_fn_6b1cf01f_000094_14db3cf9+0xd4>
  40c1a4:	call   40a1d0 <__swc_fn_6b1cf01f_000165_cf398896>
  40c1a9:	lea    rcx,[rax+0x1]
  40c1ad:	mov    QWORD PTR [rip+0x1ab8c],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40c1b4:	dec    rcx
  40c1b7:	call   411740 <__swc_fn_6b1cf01f_000167_fce60b2b>
  40c1bc:	mov    rsi,rax
  40c1bf:	mov    QWORD PTR [rsi+0xc0],rbx
  40c1c6:	and    ebx,0x1
  40c1c9:	jne    40c1cd <__swc_fn_6b1cf01f_000094_14db3cf9+0xed>
  40c1cb:	xor    eax,eax
  40c1cd:	test   rbx,rbx
  40c1d0:	sete   al
  40c1d3:	xor    cl,cl
  40c1d5:	xor    dl,dl
  40c1d7:	xor    r8b,r8b
  40c1da:	xor    r9b,r9b
  40c1dd:	xor    r10b,r10b
  40c1e0:	mov    r11,rax
  40c1e3:	call   40e7d0 <__swc_fn_6b1cf01f_000077_8b8614a7>
  40c1e8:	lea    rbx,[rsp+0x18]
  40c1ed:	mov    rcx,rbx
  40c1f0:	call   40ee10 <__swc_fn_6b1cf01f_000092_8252f8c0>
  40c1f5:	lea    rcx,[rsi+0x10]
  40c1f9:	mov    edx,0x400000
  40c1fe:	mov    r8,rbx
  40c201:	call   409f10 <__swc_fn_6b1cf01f_000159_d8afac28>
  40c206:	lea    rcx,[rsi+0x68]
  40c20a:	mov    edx,0x4000
  40c20f:	mov    r8,rbx
  40c212:	call   409f10 <__swc_fn_6b1cf01f_000159_d8afac28>
  40c217:	add    rsp,0x28
  40c21b:	pop    r12
  40c21d:	pop    rdi
  40c21e:	pop    rsi
  40c21f:	pop    rbx
  40c220:	ret
	...

000000000040c230 <__swc_fn_6b1cf01f_000097_4c97e0db>:
  40c230:	push   rbx
  40c231:	push   rsi
  40c232:	sub    rsp,0x18
  40c236:	mov    rbx,rcx
  40c239:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40c23e:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c244:	mov    rsi,QWORD PTR [rbx+0x70]
  40c248:	lea    rcx,[rcx+0x18]
  40c24c:	call   40d0c0 <__swc_fn_6b1cf01f_000157_232ffa22>
  40c251:	lea    rcx,[rsp+0x8]
  40c256:	mov    rdx,rbx
  40c259:	mov    r8d,0x78
  40c25f:	call   408960 <__swc_fn_6b1cf01f_000096_ad982b35>
  40c264:	mov    rax,rsi
  40c267:	add    rsp,0x18
  40c26b:	pop    rsi
  40c26c:	pop    rbx
  40c26d:	ret
	...

000000000040c270 <__swc_fn_6b1cf01f_000100_3ed08774>:
  40c270:	push   rsi
  40c271:	push   rdi
  40c272:	sub    rsp,0x8
  40c276:	cmp    QWORD PTR [rcx],0x0
  40c27a:	jne    40c283 <__swc_fn_6b1cf01f_000100_3ed08774+0x13>
  40c27c:	add    rsp,0x8
  40c280:	pop    rdi
  40c281:	pop    rsi
  40c282:	ret
  40c283:	mov    rsi,QWORD PTR [rcx]
  40c286:	mov    rax,QWORD PTR [rcx+0x8]
  40c28a:	test   rax,rax
  40c28d:	je     40c2a3 <__swc_fn_6b1cf01f_000100_3ed08774+0x33>
  40c28f:	test   DWORD PTR [rax+0x28],0x400000
  40c296:	je     40c2a3 <__swc_fn_6b1cf01f_000100_3ed08774+0x33>
  40c298:	mov    rcx,QWORD PTR [rax+0x30]
  40c29c:	test   rcx,rcx
  40c29f:	cmovne rax,rcx
  40c2a3:	lea    rdx,[rip+0x6f26]        # 4131d0 <__swc_rdata_base_6b1cf01f+0xc0>
  40c2aa:	lea    rcx,[rip+0x7007]        # 4132b8 <__swc_rdata_base_6b1cf01f+0x1a8>
  40c2b1:	mov    r8,rax
  40c2b4:	xor    r9d,r9d
  40c2b7:	xor    al,al
  40c2b9:	mov    r10,rax
  40c2bc:	xor    r11d,r11d
  40c2bf:	call   40c070 <__swc_fn_6b1cf01f_000088_fcb34f6a>
  40c2c4:	test   rax,rax
  40c2c7:	je     40c2d7 <__swc_fn_6b1cf01f_000100_3ed08774+0x67>
  40c2c9:	mov    rdi,QWORD PTR [rax+0x48]
  40c2cd:	test   rdi,rdi
  40c2d0:	je     40c2d7 <__swc_fn_6b1cf01f_000100_3ed08774+0x67>
  40c2d2:	mov    rcx,rsi
  40c2d5:	call   rdi
  40c2d7:	add    rsp,0x8
  40c2db:	pop    rdi
  40c2dc:	pop    rsi
  40c2dd:	ret
	...

000000000040c2e0 <__swc_fn_6b1cf01f_000103_67100064>:
  40c2e0:	push   rbx
  40c2e1:	push   rsi
  40c2e2:	push   rdi
  40c2e3:	sub    rsp,0x20
  40c2e7:	mov    rbx,rdx
  40c2ea:	mov    rsi,rcx
  40c2ed:	mov    rcx,QWORD PTR [rip+0x1aa4c]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40c2f4:	test   rcx,rcx
  40c2f7:	jne    40c309 <__swc_fn_6b1cf01f_000103_67100064+0x29>
  40c2f9:	call   40a1d0 <__swc_fn_6b1cf01f_000165_cf398896>
  40c2fe:	lea    rcx,[rax+0x1]
  40c302:	mov    QWORD PTR [rip+0x1aa37],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40c309:	dec    rcx
  40c30c:	call   411740 <__swc_fn_6b1cf01f_000167_fce60b2b>
  40c311:	mov    rdi,rax
  40c314:	mov    rax,QWORD PTR [rdi+0xbd0]
  40c31b:	xor    ecx,ecx
  40c31d:	test   rax,rax
  40c320:	je     40c325 <__swc_fn_6b1cf01f_000103_67100064+0x45>
  40c322:	mov    rcx,QWORD PTR [rax]
  40c325:	call   40a300 <__swc_fn_6b1cf01f_000174_176517f9>
  40c32a:	lea    rax,[rsp+0x8]
  40c32f:	lea    rcx,[rdi+0x9c8]
  40c336:	mov    QWORD PTR [rsp+0x8],rcx
  40c33b:	mov    QWORD PTR [rax+0x8],0x40
  40c343:	xor    ecx,ecx
  40c345:	mov    rdx,rax
  40c348:	call   40fa60 <__swc_fn_6b1cf01f_000119_9175a56a>
  40c34d:	mov    DWORD PTR [rdi+0xbc8],eax
  40c353:	mov    rdi,QWORD PTR [rdi+0x990]
  40c35a:	test   rdi,rdi
  40c35d:	je     40c367 <__swc_fn_6b1cf01f_000103_67100064+0x87>
  40c35f:	mov    rcx,rsi
  40c362:	mov    rdx,rbx
  40c365:	call   rdi
  40c367:	call   40c090 <__swc_fn_6b1cf01f_000091_3d2f5a0d>
  40c36c:	test   al,al
  40c36e:	je     40c37e <__swc_fn_6b1cf01f_000103_67100064+0x9e>
  40c370:	mov    rcx,rsi
  40c373:	mov    rdx,rbx
  40c376:	xor    r8d,r8d
  40c379:	call   409400 <__swc_fn_6b1cf01f_000120_ea68f292>
  40c37e:	mov    rcx,rsi
  40c381:	mov    rdx,rbx
  40c384:	call   408a80 <__swc_fn_6b1cf01f_000102_e9fdc18e>
  40c389:	call   40c910 <__swc_fn_6b1cf01f_000118_7f430081>
  40c38e:	add    rsp,0x20
  40c392:	pop    rdi
  40c393:	pop    rsi
  40c394:	pop    rbx
  40c395:	ret
	...

000000000040c3a0 <__swc_fn_6b1cf01f_000106_ed4b1681>:
  40c3a0:	test   r8,r8
  40c3a3:	jne    40c3a8 <__swc_fn_6b1cf01f_000106_ed4b1681+0x8>
  40c3a5:	xor    eax,eax
  40c3a7:	ret
  40c3a8:	xor    eax,eax
  40c3aa:	nop    WORD PTR [rax+rax*1+0x0]
  40c3b0:	mov    r9,r8
  40c3b3:	sub    r9,rax
  40c3b6:	cmp    r9,0x10
  40c3ba:	jb     40c404 <__swc_fn_6b1cf01f_000106_ed4b1681+0x64>
  40c3bc:	lea    r9,[rcx+rax*1]
  40c3c0:	lea    r10,[rdx+rax*1]
  40c3c4:	vmovups xmm0,XMMWORD PTR [r10]
  40c3c9:	vmovups xmm1,XMMWORD PTR [r9]
  40c3ce:	vpcmpeqb xmm0,xmm1,xmm0
  40c3d2:	vpmovmskb r9d,xmm0
  40c3d6:	cmp    r9d,0xffff
  40c3dd:	je     40c3fe <__swc_fn_6b1cf01f_000106_ed4b1681+0x5e>
  40c3df:	not    r9d
  40c3e2:	xor    r8d,r8d
  40c3e5:	movzx  r9d,r9w
  40c3e9:	tzcnt  r8d,r9d
  40c3ee:	add    rax,r8
  40c3f1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c3f5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c3f9:	sub    ecx,eax
  40c3fb:	mov    eax,ecx
  40c3fd:	ret
  40c3fe:	lea    rax,[rax+0x10]
  40c402:	jmp    40c3b0 <__swc_fn_6b1cf01f_000106_ed4b1681+0x10>
  40c404:	cmp    r9,0x8
  40c408:	jb     40c47b <__swc_fn_6b1cf01f_000106_ed4b1681+0xdb>
  40c40a:	lea    r9,[rcx+rax*1]
  40c40e:	lea    r10,[rdx+rax*1]
  40c412:	mov    r9,QWORD PTR [r9]
  40c415:	xor    r9,QWORD PTR [r10]
  40c418:	test   r9,r9
  40c41b:	je     40c439 <__swc_fn_6b1cf01f_000106_ed4b1681+0x99>
  40c41d:	xor    r8d,r8d
  40c420:	tzcnt  r8,r9
  40c425:	shr    r8,0x3
  40c429:	add    rax,r8
  40c42c:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c430:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c434:	sub    ecx,eax
  40c436:	mov    eax,ecx
  40c438:	ret
  40c439:	lea    rax,[rax+0x8]
  40c43d:	cmp    rax,r8
  40c440:	jne    40c445 <__swc_fn_6b1cf01f_000106_ed4b1681+0xa5>
  40c442:	xor    eax,eax
  40c444:	ret
  40c445:	lea    rax,[r8-0x8]
  40c449:	lea    r8,[rcx+rax*1]
  40c44d:	lea    r9,[rdx+rax*1]
  40c451:	mov    r8,QWORD PTR [r8]
  40c454:	xor    r8,QWORD PTR [r9]
  40c457:	test   r8,r8
  40c45a:	je     40c478 <__swc_fn_6b1cf01f_000106_ed4b1681+0xd8>
  40c45c:	xor    r9d,r9d
  40c45f:	tzcnt  r9,r8
  40c464:	shr    r9,0x3
  40c468:	add    rax,r9
  40c46b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c46f:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c473:	sub    ecx,eax
  40c475:	mov    eax,ecx
  40c477:	ret
  40c478:	xor    eax,eax
  40c47a:	ret
  40c47b:	cmp    r9,0x4
  40c47f:	jb     40c4f2 <__swc_fn_6b1cf01f_000106_ed4b1681+0x152>
  40c481:	lea    r9,[rcx+rax*1]
  40c485:	lea    r10,[rdx+rax*1]
  40c489:	mov    r9d,DWORD PTR [r9]
  40c48c:	xor    r9d,DWORD PTR [r10]
  40c48f:	test   r9d,r9d
  40c492:	je     40c4b0 <__swc_fn_6b1cf01f_000106_ed4b1681+0x110>
  40c494:	xor    r8d,r8d
  40c497:	tzcnt  r8,r9
  40c49c:	shr    r8,0x3
  40c4a0:	add    rax,r8
  40c4a3:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4a7:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4ab:	sub    ecx,eax
  40c4ad:	mov    eax,ecx
  40c4af:	ret
  40c4b0:	lea    rax,[rax+0x4]
  40c4b4:	cmp    rax,r8
  40c4b7:	jne    40c4bc <__swc_fn_6b1cf01f_000106_ed4b1681+0x11c>
  40c4b9:	xor    eax,eax
  40c4bb:	ret
  40c4bc:	lea    rax,[r8-0x4]
  40c4c0:	lea    r8,[rcx+rax*1]
  40c4c4:	lea    r9,[rdx+rax*1]
  40c4c8:	mov    r8d,DWORD PTR [r8]
  40c4cb:	xor    r8d,DWORD PTR [r9]
  40c4ce:	test   r8d,r8d
  40c4d1:	je     40c4ef <__swc_fn_6b1cf01f_000106_ed4b1681+0x14f>
  40c4d3:	xor    r9d,r9d
  40c4d6:	tzcnt  r9,r8
  40c4db:	shr    r9,0x3
  40c4df:	add    rax,r9
  40c4e2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4e6:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4ea:	sub    ecx,eax
  40c4ec:	mov    eax,ecx
  40c4ee:	ret
  40c4ef:	xor    eax,eax
  40c4f1:	ret
  40c4f2:	cmp    r9,0x2
  40c4f6:	jb     40c549 <__swc_fn_6b1cf01f_000106_ed4b1681+0x1a9>
  40c4f8:	lea    r9,[rcx+rax*1]
  40c4fc:	lea    r10,[rdx+rax*1]
  40c500:	mov    r9w,WORD PTR [r9]
  40c504:	xor    r9w,WORD PTR [r10]
  40c508:	test   r9w,r9w
  40c50c:	je     40c52e <__swc_fn_6b1cf01f_000106_ed4b1681+0x18e>
  40c50e:	xor    r8d,r8d
  40c511:	movzx  r9d,r9w
  40c515:	tzcnt  r8,r9
  40c51a:	shr    r8,0x3
  40c51e:	add    rax,r8
  40c521:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c525:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c529:	sub    ecx,eax
  40c52b:	mov    eax,ecx
  40c52d:	ret
  40c52e:	lea    rax,[rax+0x2]
  40c532:	cmp    rax,r8
  40c535:	jne    40c53a <__swc_fn_6b1cf01f_000106_ed4b1681+0x19a>
  40c537:	xor    eax,eax
  40c539:	ret
  40c53a:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40c540:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40c546:	sub    eax,ecx
  40c548:	ret
  40c549:	test   r9,r9
  40c54c:	je     40c55b <__swc_fn_6b1cf01f_000106_ed4b1681+0x1bb>
  40c54e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c552:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c556:	sub    ecx,eax
  40c558:	mov    eax,ecx
  40c55a:	ret
  40c55b:	xor    eax,eax
  40c55d:	ret
	...

000000000040c560 <__swc_fn_6b1cf01f_000109_8d425bd3>:
  40c560:	push   r12
  40c562:	push   r13
  40c564:	push   r14
  40c566:	push   rdi
  40c567:	push   rsi
  40c568:	push   r15
  40c56a:	sub    rsp,0xd8
  40c571:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c577:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c57d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c583:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c589:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c58f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c598:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c5a1:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c5aa:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c5b3:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c5bc:	mov    r12,rcx
  40c5bf:	test   rcx,rcx
  40c5c2:	je     40c5de <__swc_fn_6b1cf01f_000109_8d425bd3+0x7e>
  40c5c4:	mov    eax,r12d
  40c5c7:	and    eax,0xfff
  40c5cd:	setne  al
  40c5d0:	cmp    r12,0xffffffffffffefff
  40c5d7:	seta   cl
  40c5da:	or     al,cl
  40c5dc:	je     40c5e5 <__swc_fn_6b1cf01f_000109_8d425bd3+0x85>
  40c5de:	xor    eax,eax
  40c5e0:	jmp    40c67b <__swc_fn_6b1cf01f_000109_8d425bd3+0x11b>
  40c5e5:	call   409120 <__swc_fn_6b1cf01f_000108_84af7666>
  40c5ea:	mov    r13,rax
  40c5ed:	test   rax,rax
  40c5f0:	jne    40c5f9 <__swc_fn_6b1cf01f_000109_8d425bd3+0x99>
  40c5f2:	xor    eax,eax
  40c5f4:	jmp    40c67b <__swc_fn_6b1cf01f_000109_8d425bd3+0x11b>
  40c5f9:	lea    r14,[r12+0x1000]
  40c601:	xor    edi,edi
  40c603:	mov    rsi,r14
  40c606:	xor    edx,edx
  40c608:	mov    ecx,0x22
  40c60d:	mov    eax,0xffffffff
  40c612:	movsxd r8,eax
  40c615:	xor    r9d,r9d
  40c618:	xor    eax,eax
  40c61a:	call   4070c0 <mmap@plt>
  40c61f:	mov    r15,rax
  40c622:	cmp    rax,0xffffffffffffffff
  40c626:	jne    40c62c <__swc_fn_6b1cf01f_000109_8d425bd3+0xcc>
  40c628:	xor    eax,eax
  40c62a:	jmp    40c67b <__swc_fn_6b1cf01f_000109_8d425bd3+0x11b>
  40c62c:	mov    rdi,r15
  40c62f:	mov    esi,0x1000
  40c634:	mov    edx,0x3
  40c639:	xor    eax,eax
  40c63b:	call   407030 <mprotect@plt>
  40c640:	test   eax,eax
  40c642:	je     40c655 <__swc_fn_6b1cf01f_000109_8d425bd3+0xf5>
  40c644:	mov    rdi,r15
  40c647:	mov    rsi,r14
  40c64a:	xor    eax,eax
  40c64c:	call   407020 <munmap@plt>
  40c651:	xor    eax,eax
  40c653:	jmp    40c67b <__swc_fn_6b1cf01f_000109_8d425bd3+0x11b>
  40c655:	mov    QWORD PTR [r15+0x8],r12
  40c659:	mov    rcx,r13
  40c65c:	call   40ccb0 <__swc_fn_6b1cf01f_000133_4b2af8da>
  40c661:	mov    rax,QWORD PTR [r13+0x8]
  40c665:	mov    QWORD PTR [r15],rax
  40c668:	mov    QWORD PTR [r13+0x8],r15
  40c66c:	mov    rcx,r13
  40c66f:	call   40fe00 <__swc_fn_6b1cf01f_000134_29412410>
  40c674:	lea    rax,[r15+0x1000]
  40c67b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c681:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c687:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c68d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c693:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c699:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c6a2:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c6ab:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c6b4:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c6bd:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c6c6:	add    rsp,0xd8
  40c6cd:	pop    r15
  40c6cf:	pop    rsi
  40c6d0:	pop    rdi
  40c6d1:	pop    r14
  40c6d3:	pop    r13
  40c6d5:	pop    r12
  40c6d7:	ret
	...

000000000040c6e0 <__swc_fn_6b1cf01f_000112_759e9ceb>:
  40c6e0:	push   rbx
  40c6e1:	push   r12
  40c6e3:	push   rdi
  40c6e4:	push   rsi
  40c6e5:	sub    rsp,0xa8
  40c6ec:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c6f2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c6f8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c6fe:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c704:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c70a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c710:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40c716:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40c71c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40c725:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40c72e:	mov    rbx,rdx
  40c731:	mov    r12,rcx
  40c734:	mov    rdi,rcx
  40c737:	mov    rsi,rdx
  40c73a:	xor    edx,edx
  40c73c:	xor    eax,eax
  40c73e:	call   407030 <mprotect@plt>
  40c743:	test   eax,eax
  40c745:	jne    40c769 <__swc_fn_6b1cf01f_000112_759e9ceb+0x89>
  40c747:	mov    rcx,r12
  40c74a:	mov    rdx,rbx
  40c74d:	xor    al,al
  40c74f:	mov    r8,rax
  40c752:	call   40f890 <__swc_fn_6b1cf01f_000110_a808fe76>
  40c757:	mov    rdi,r12
  40c75a:	mov    rsi,rbx
  40c75d:	mov    edx,0x4
  40c762:	xor    eax,eax
  40c764:	call   4070e0 <madvise@plt>
  40c769:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40c76f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40c775:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40c77b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40c781:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40c787:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40c78d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40c793:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40c799:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40c7a2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40c7ab:	add    rsp,0xa8
  40c7b2:	pop    rsi
  40c7b3:	pop    rdi
  40c7b4:	pop    r12
  40c7b6:	pop    rbx
  40c7b7:	ret
	...

000000000040c7c0 <__swc_fn_6b1cf01f_000115_1ba33335>:
  40c7c0:	push   rsi
  40c7c1:	push   rdi
  40c7c2:	push   r12
  40c7c4:	push   r13
  40c7c6:	push   r14
  40c7c8:	sub    rsp,0xe0
  40c7cf:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c7d5:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c7db:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c7e1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c7e7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c7ed:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c7f6:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c7ff:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c808:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c811:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c81a:	mov    rsi,rdx
  40c81d:	mov    rdi,rcx
  40c820:	call   409120 <__swc_fn_6b1cf01f_000108_84af7666>
  40c825:	mov    r12,rax
  40c828:	test   rax,rax
  40c82b:	jne    40c832 <__swc_fn_6b1cf01f_000115_1ba33335+0x72>
  40c82d:	jmp    40c8a6 <__swc_fn_6b1cf01f_000115_1ba33335+0xe6>
  40c832:	mov    rcx,r12
  40c835:	call   40ccb0 <__swc_fn_6b1cf01f_000133_4b2af8da>
  40c83a:	lea    r13,[r12+0x8]
  40c83f:	mov    rax,QWORD PTR [r13+0x0]
  40c843:	test   rax,rax
  40c846:	je     40c89e <__swc_fn_6b1cf01f_000115_1ba33335+0xde>
  40c848:	nop    DWORD PTR [rax+rax*1+0x0]
  40c850:	lea    rcx,[rax+0x1000]
  40c857:	cmp    rcx,rdi
  40c85a:	jne    40c892 <__swc_fn_6b1cf01f_000115_1ba33335+0xd2>
  40c85c:	cmp    QWORD PTR [rax+0x8],rsi
  40c860:	je     40c86c <__swc_fn_6b1cf01f_000115_1ba33335+0xac>
  40c862:	mov    rcx,r12
  40c865:	call   40fe00 <__swc_fn_6b1cf01f_000134_29412410>
  40c86a:	jmp    40c8a6 <__swc_fn_6b1cf01f_000115_1ba33335+0xe6>
  40c86c:	mov    r14,QWORD PTR [rax]
  40c86f:	mov    rdi,rax
  40c872:	lea    rsi,[rsi+0x1000]
  40c879:	xor    eax,eax
  40c87b:	call   407020 <munmap@plt>
  40c880:	test   eax,eax
  40c882:	jne    40c888 <__swc_fn_6b1cf01f_000115_1ba33335+0xc8>
  40c884:	mov    QWORD PTR [r13+0x0],r14
  40c888:	mov    rcx,r12
  40c88b:	call   40fe00 <__swc_fn_6b1cf01f_000134_29412410>
  40c890:	jmp    40c8a6 <__swc_fn_6b1cf01f_000115_1ba33335+0xe6>
  40c892:	mov    r13,rax
  40c895:	mov    rax,QWORD PTR [r13+0x0]
  40c899:	test   rax,rax
  40c89c:	jne    40c850 <__swc_fn_6b1cf01f_000115_1ba33335+0x90>
  40c89e:	mov    rcx,r12
  40c8a1:	call   40fe00 <__swc_fn_6b1cf01f_000134_29412410>
  40c8a6:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c8ac:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c8b2:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c8b8:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c8be:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c8c4:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c8cd:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c8d6:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c8df:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c8e8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c8f1:	add    rsp,0xe0
  40c8f8:	pop    r14
  40c8fa:	pop    r13
  40c8fc:	pop    r12
  40c8fe:	pop    rdi
  40c8ff:	pop    rsi
  40c900:	ret
	...

000000000040c910 <__swc_fn_6b1cf01f_000118_7f430081>:
  40c910:	push   rdi
  40c911:	push   rsi
  40c912:	sub    rsp,0xa8
  40c919:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c91f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c925:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c92b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c931:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c937:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c93d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40c943:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40c949:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40c952:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40c95b:	mov    rdi,0xfffffffffffffd66
  40c962:	xor    eax,eax
  40c964:	call   407040 <exit@plt>
  40c969:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40c96f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40c975:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40c97b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40c981:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40c987:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40c98d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40c993:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40c999:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40c9a2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40c9ab:	add    rsp,0xa8
  40c9b2:	pop    rsi
  40c9b3:	pop    rdi
  40c9b4:	ret
	...

000000000040c9c0 <__swc_fn_6b1cf01f_000121_12b4ed22>:
  40c9c0:	push   rbx
  40c9c1:	push   rsi
  40c9c2:	push   rdi
  40c9c3:	sub    rsp,0x30
  40c9c7:	mov    rbx,rdx
  40c9ca:	mov    esi,ecx
  40c9cc:	test   ecx,ecx
  40c9ce:	je     40caa3 <__swc_fn_6b1cf01f_000121_12b4ed22+0xe3>
  40c9d4:	mov    rcx,rsi
  40c9d7:	shl    rcx,0x4
  40c9db:	call   40bed0 <__swc_fn_6b1cf01f_000079_34776ded>
  40c9e0:	test   rax,rax
  40c9e3:	je     40ca92 <__swc_fn_6b1cf01f_000121_12b4ed22+0xd2>
  40c9e9:	mov    rcx,rsi
  40c9ec:	xor    edx,edx
  40c9ee:	test   rsi,rsi
  40c9f1:	jbe    40ca72 <__swc_fn_6b1cf01f_000121_12b4ed22+0xb2>
  40c9f7:	nop    WORD PTR [rax+rax*1+0x0]
  40ca00:	mov    r8d,edx
  40ca03:	mov    r9,QWORD PTR [rbx+r8*8]
  40ca07:	add    r8,r8
  40ca0a:	lea    r8,[rax+r8*8]
  40ca0e:	xor    r10d,r10d
  40ca11:	test   r9,r9
  40ca14:	je     40ca50 <__swc_fn_6b1cf01f_000121_12b4ed22+0x90>
  40ca16:	mov    r11,r9
  40ca19:	mov    dil,BYTE PTR [r11]
  40ca1c:	test   dil,dil
  40ca1f:	je     40ca50 <__swc_fn_6b1cf01f_000121_12b4ed22+0x90>
  40ca21:	cs nop WORD PTR [rax+rax*1+0x0]
  40ca2b:	cs nop WORD PTR [rax+rax*1+0x0]
  40ca35:	cs nop WORD PTR [rax+rax*1+0x0]
  40ca3f:	nop
  40ca40:	add    r11,0x1
  40ca44:	add    r10,0x1
  40ca48:	mov    dil,BYTE PTR [r11]
  40ca4b:	test   dil,dil
  40ca4e:	jne    40ca40 <__swc_fn_6b1cf01f_000121_12b4ed22+0x80>
  40ca50:	mov    QWORD PTR [rsp+0x18],r9
  40ca55:	mov    QWORD PTR [rsp+0x20],r10
  40ca5a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40ca60:	vmovups XMMWORD PTR [r8],xmm0
  40ca65:	add    rdx,0x1
  40ca69:	cmp    rdx,rcx
  40ca6c:	jb     40ca00 <__swc_fn_6b1cf01f_000121_12b4ed22+0x40>
  40ca72:	lea    rcx,[rip+0x1a2d7]        # 426d50 <__swc_bss_base_6b1cf01f+0x2d10>
  40ca79:	mov    QWORD PTR [rsp+0x8],rax
  40ca7e:	mov    esi,esi
  40ca80:	mov    QWORD PTR [rsp+0x10],rsi
  40ca85:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ca8b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40ca90:	jmp    40caa3 <__swc_fn_6b1cf01f_000121_12b4ed22+0xe3>
  40ca92:	lea    rcx,[rip+0x6a87]        # 413520 <__swc_rdata_base_6b1cf01f+0x410>
  40ca99:	call   40f940 <__swc_fn_6b1cf01f_000116_035d76a1>
  40ca9e:	call   40c910 <__swc_fn_6b1cf01f_000118_7f430081>
  40caa3:	add    rsp,0x30
  40caa7:	pop    rdi
  40caa8:	pop    rsi
  40caa9:	pop    rbx
  40caaa:	ret
  40caab:	add    BYTE PTR [rax],al
  40caad:	add    BYTE PTR [rax],al
	...

000000000040cab0 <__swc_fn_6b1cf01f_000124_667fbf24>:
  40cab0:	push   rdi
  40cab1:	push   rsi
  40cab2:	sub    rsp,0xa8
  40cab9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cabf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cac5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cacb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cad1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cad7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cadd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cae3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cae9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40caf2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cafb:	mov    edi,ecx
  40cafd:	xor    eax,eax
  40caff:	call   4070f0 <pthread_key_delete@plt>
  40cb04:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cb0a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cb10:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cb16:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cb1c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cb22:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cb28:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cb2e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cb34:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cb3d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cb46:	add    rsp,0xa8
  40cb4d:	pop    rsi
  40cb4e:	pop    rdi
  40cb4f:	ret

000000000040cb50 <__swc_fn_6b1cf01f_000127_8dffa290>:
  40cb50:	push   rdi
  40cb51:	push   rsi
  40cb52:	sub    rsp,0xa8
  40cb59:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cb5f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cb65:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cb6b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cb71:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cb77:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cb7d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cb83:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cb89:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cb92:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cb9b:	test   rcx,rcx
  40cb9e:	je     40cbaf <__swc_fn_6b1cf01f_000127_8dffa290+0x5f>
  40cba0:	lea    rax,[rcx-0x1]
  40cba4:	mov    eax,eax
  40cba6:	mov    edi,eax
  40cba8:	xor    eax,eax
  40cbaa:	call   4070f0 <pthread_key_delete@plt>
  40cbaf:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cbb5:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cbbb:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cbc1:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cbc7:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cbcd:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cbd3:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cbd9:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cbdf:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cbe8:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cbf1:	add    rsp,0xa8
  40cbf8:	pop    rsi
  40cbf9:	pop    rdi
  40cbfa:	ret
  40cbfb:	add    BYTE PTR [rax],al
  40cbfd:	add    BYTE PTR [rax],al
	...

000000000040cc00 <__swc_fn_6b1cf01f_000130_c1196dfb>:
  40cc00:	push   rsi
  40cc01:	push   rdi
  40cc02:	sub    rsp,0xa8
  40cc09:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cc0f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cc15:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cc1b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cc21:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cc27:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cc2d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cc33:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cc39:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cc42:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cc4b:	xor    eax,eax
  40cc4d:	call   407100 <gettid@plt>
  40cc52:	movsxd rax,eax
  40cc55:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cc5b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cc61:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cc67:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cc6d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cc73:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cc79:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cc7f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cc85:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cc8e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cc97:	add    rsp,0xa8
  40cc9e:	pop    rdi
  40cc9f:	pop    rsi
  40cca0:	ret
	...

000000000040ccb0 <__swc_fn_6b1cf01f_000133_4b2af8da>:
  40ccb0:	push   rbx
  40ccb1:	push   rdi
  40ccb2:	push   rsi
  40ccb3:	sub    rsp,0xc0
  40ccba:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40ccc0:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40ccc6:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40cccc:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40ccd2:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40ccd8:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40ccde:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40cce4:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40cced:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40ccf6:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40ccff:	mov    rbx,rcx
  40cd02:	cs nop WORD PTR [rax+rax*1+0x0]
  40cd0c:	nop    DWORD PTR [rax+0x0]
  40cd10:	mov    edx,0x80000000
  40cd15:	xor    eax,eax
  40cd17:	lock cmpxchg DWORD PTR [rbx],edx
  40cd1b:	test   eax,eax
  40cd1d:	je     40cd54 <__swc_fn_6b1cf01f_000133_4b2af8da+0xa4>
  40cd1f:	mov    eax,DWORD PTR [rbx]
  40cd21:	lea    rcx,[rsp+0x14]
  40cd26:	mov    DWORD PTR [rsp+0x14],eax
  40cd2a:	test   eax,eax
  40cd2c:	je     40cd10 <__swc_fn_6b1cf01f_000133_4b2af8da+0x60>
  40cd2e:	mov    QWORD PTR [rsp],0x0
  40cd36:	mov    edi,0xca
  40cd3b:	mov    rsi,rbx
  40cd3e:	mov    edx,0x80
  40cd43:	mov    ecx,DWORD PTR [rcx]
  40cd45:	xor    r8d,r8d
  40cd48:	xor    r9d,r9d
  40cd4b:	xor    eax,eax
  40cd4d:	call   407070 <syscall@plt>
  40cd52:	jmp    40cd10 <__swc_fn_6b1cf01f_000133_4b2af8da+0x60>
  40cd54:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40cd5a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40cd60:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40cd66:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40cd6c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40cd72:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40cd78:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40cd7e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40cd87:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40cd90:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40cd99:	add    rsp,0xc0
  40cda0:	pop    rsi
  40cda1:	pop    rdi
  40cda2:	pop    rbx
  40cda3:	ret
	...

000000000040cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>:
  40cdb0:	sub    rsp,0x8
  40cdb4:	call   40fe00 <__swc_fn_6b1cf01f_000134_29412410>
  40cdb9:	add    rsp,0x8
  40cdbd:	ret
	...

000000000040cdc0 <__swc_fn_6b1cf01f_000139_7c02fe26>:
  40cdc0:	push   rdi
  40cdc1:	push   rsi
  40cdc2:	sub    rsp,0xa8
  40cdc9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cdcf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cdd5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cddb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cde1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cde7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cded:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cdf3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cdf9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ce02:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ce0b:	mov    edi,0x28
  40ce10:	xor    eax,eax
  40ce12:	call   4070d0 <malloc@plt>
  40ce17:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ce1d:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ce23:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ce29:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ce2f:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ce35:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ce3b:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ce41:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ce47:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ce50:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ce59:	add    rsp,0xa8
  40ce60:	pop    rsi
  40ce61:	pop    rdi
  40ce62:	ret
	...

000000000040ce70 <__swc_fn_6b1cf01f_000142_56e56812>:
  40ce70:	mov    QWORD PTR [r8],0x0
  40ce77:	cmp    rdx,0x10
  40ce7b:	jae    40ce80 <__swc_fn_6b1cf01f_000142_56e56812+0x10>
  40ce7d:	xor    eax,eax
  40ce7f:	ret
  40ce80:	mov    eax,DWORD PTR [rcx]
  40ce82:	cmp    eax,0x42445753
  40ce88:	jne    40ce92 <__swc_fn_6b1cf01f_000142_56e56812+0x22>
  40ce8a:	mov    eax,DWORD PTR [rcx+0x4]
  40ce8d:	cmp    eax,0x1
  40ce90:	je     40ce95 <__swc_fn_6b1cf01f_000142_56e56812+0x25>
  40ce92:	xor    eax,eax
  40ce94:	ret
  40ce95:	mov    QWORD PTR [r8],rdx
  40ce98:	mov    rax,rcx
  40ce9b:	ret
  40ce9c:	add    BYTE PTR [rax],al
	...

000000000040cea0 <__swc_fn_6b1cf01f_000145_863755b5>:
  40cea0:	push   rbx
  40cea1:	sub    rsp,0xe0
  40cea8:	lea    rbx,[rsp+0x8]
  40cead:	vxorps xmm0,xmm0,xmm0
  40ceb1:	vmovups XMMWORD PTR [rbx],xmm0
  40ceb5:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ceba:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40cebf:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40cec4:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40cec9:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  40cece:	mov    DWORD PTR [rbx+0x60],0x0
  40ced5:	mov    r8,rbx
  40ced8:	mov    rdx,rcx
  40cedb:	nop    DWORD PTR [rax+rax*1+0x0]
  40cee0:	mov    r9,rdx
  40cee3:	movabs rdx,0x6666666666666667
  40ceed:	mov    rax,r9
  40cef0:	imul   rdx
  40cef3:	sar    rdx,0x2
  40cef7:	mov    r10,rdx
  40cefa:	shr    rdx,0x3f
  40cefe:	add    r10,rdx
  40cf01:	mov    rdx,r10
  40cf04:	imul   r11,r10,0xa
  40cf08:	sub    r9,r11
  40cf0b:	mov    r11,QWORD PTR [rip+0x662e]        # 413540 <__swc_rdata_base_6b1cf01f+0x430>
  40cf12:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40cf17:	mov    BYTE PTR [r8],r9b
  40cf1a:	lea    r9,[r8+0x1]
  40cf1e:	mov    r8,r9
  40cf21:	test   r10,r10
  40cf24:	jne    40cee0 <__swc_fn_6b1cf01f_000145_863755b5+0x40>
  40cf26:	test   rcx,rcx
  40cf29:	jge    40cf33 <__swc_fn_6b1cf01f_000145_863755b5+0x93>
  40cf2b:	mov    BYTE PTR [r9],0x2d
  40cf2f:	add    r8,0x1
  40cf33:	mov    BYTE PTR [r8],0x0
  40cf37:	sub    r8,0x1
  40cf3b:	mov    rax,rbx
  40cf3e:	cmp    rax,r8
  40cf41:	jae    40cf66 <__swc_fn_6b1cf01f_000145_863755b5+0xc6>
  40cf43:	cs nop WORD PTR [rax+rax*1+0x0]
  40cf4d:	nop    DWORD PTR [rax]
  40cf50:	mov    cl,BYTE PTR [r8]
  40cf53:	mov    dl,BYTE PTR [rax]
  40cf55:	mov    BYTE PTR [r8],dl
  40cf58:	sub    r8,0x1
  40cf5c:	mov    BYTE PTR [rax],cl
  40cf5e:	inc    rax
  40cf61:	cmp    rax,r8
  40cf64:	jb     40cf50 <__swc_fn_6b1cf01f_000145_863755b5+0xb0>
  40cf66:	xor    eax,eax
  40cf68:	test   rbx,rbx
  40cf6b:	je     40cf8e <__swc_fn_6b1cf01f_000145_863755b5+0xee>
  40cf6d:	mov    rcx,rbx
  40cf70:	mov    dl,BYTE PTR [rcx]
  40cf72:	test   dl,dl
  40cf74:	je     40cf8e <__swc_fn_6b1cf01f_000145_863755b5+0xee>
  40cf76:	cs nop WORD PTR [rax+rax*1+0x0]
  40cf80:	add    rcx,0x1
  40cf84:	add    rax,0x1
  40cf88:	mov    dl,BYTE PTR [rcx]
  40cf8a:	test   dl,dl
  40cf8c:	jne    40cf80 <__swc_fn_6b1cf01f_000145_863755b5+0xe0>
  40cf8e:	mov    QWORD PTR [rbx+0xa8],rbx
  40cf95:	mov    QWORD PTR [rbx+0xb0],rax
  40cf9c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40cfa4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40cfac:	lea    rcx,[rbx+0xb8]
  40cfb3:	call   40f940 <__swc_fn_6b1cf01f_000116_035d76a1>
  40cfb8:	add    rsp,0xe0
  40cfbf:	pop    rbx
  40cfc0:	ret
	...

000000000040cfd0 <__swc_fn_6b1cf01f_000148_9e4bc402>:
  40cfd0:	vxorps xmm0,xmm0,xmm0
  40cfd4:	vmovups XMMWORD PTR [rcx],xmm0
  40cfd8:	mov    QWORD PTR [rcx+0x10],0x0
  40cfe0:	ret
	...

000000000040cff0 <__swc_fn_6b1cf01f_000151_9e4bc402>:
  40cff0:	vxorps xmm0,xmm0,xmm0
  40cff4:	vmovups XMMWORD PTR [rcx],xmm0
  40cff8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40cffd:	vxorps xmm0,xmm0,xmm0
  40d001:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d006:	vmovups xmm0,XMMWORD PTR [rip+0x662a]        # 413638 <__swc_rdata_base_6b1cf01f+0x528>
  40d00e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d013:	vxorps xmm0,xmm0,xmm0
  40d017:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d01c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d021:	mov    QWORD PTR [rcx+0x60],0x0
  40d029:	ret
  40d02a:	add    BYTE PTR [rax],al
  40d02c:	add    BYTE PTR [rax],al
	...

000000000040d030 <__swc_fn_6b1cf01f_000154_9e4bc402>:
  40d030:	vxorps xmm0,xmm0,xmm0
  40d034:	vmovups XMMWORD PTR [rcx],xmm0
  40d038:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d03d:	vxorps xmm0,xmm0,xmm0
  40d041:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d046:	vmovups xmm0,XMMWORD PTR [rip+0x6712]        # 413760 <__swc_rdata_base_6b1cf01f+0x650>
  40d04e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d053:	vxorps xmm0,xmm0,xmm0
  40d057:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d05c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d061:	vxorps xmm0,xmm0,xmm0
  40d065:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40d06a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40d06f:	vxorps xmm0,xmm0,xmm0
  40d073:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40d07b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40d083:	vxorps xmm0,xmm0,xmm0
  40d087:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40d08f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40d097:	vxorps xmm0,xmm0,xmm0
  40d09b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40d0a3:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40d0ab:	mov    QWORD PTR [rcx+0xe0],0x0
  40d0b6:	ret
	...

000000000040d0c0 <__swc_fn_6b1cf01f_000157_232ffa22>:
  40d0c0:	push   rbx
  40d0c1:	mov    rbx,rcx
  40d0c4:	call   4113d0 <__swc_fn_6b1cf01f_000158_b43b2f96>
  40d0c9:	mov    rax,QWORD PTR [rbx+0x10]
  40d0cd:	test   rax,rax
  40d0d0:	je     40d0e1 <__swc_fn_6b1cf01f_000157_232ffa22+0x21>
  40d0d2:	mov    rcx,rbx
  40d0d5:	mov    rdx,rax
  40d0d8:	mov    r8,QWORD PTR [rbx+0x18]
  40d0dc:	call   409ec0 <__swc_fn_6b1cf01f_000156_2745c4a5>
  40d0e1:	vxorps xmm0,xmm0,xmm0
  40d0e5:	vmovups XMMWORD PTR [rbx],xmm0
  40d0e9:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d0ee:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d0f3:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d0f8:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d0fd:	mov    QWORD PTR [rbx+0x50],0x0
  40d105:	pop    rbx
  40d106:	ret
	...

000000000040d120 <__swc_fn_6b1cf01f_000160_01cbb887>:
  40d120:	sub    rsp,0x10
  40d124:	mov    eax,r8d
  40d127:	mov    r8d,r9d
  40d12a:	test   r9d,r9d
  40d12d:	jne    40d146 <__swc_fn_6b1cf01f_000160_01cbb887+0x26>
  40d12f:	vmovups xmm0,XMMWORD PTR [rip+0x66e1]        # 413818 <__swc_rdata_base_6b1cf01f+0x708>
  40d137:	vmovups XMMWORD PTR [r10],xmm0
  40d13c:	mov    eax,0x1
  40d141:	add    rsp,0x10
  40d145:	ret
  40d146:	mov    r9,r8
  40d149:	cmp    r8,rax
  40d14c:	jb     40d153 <__swc_fn_6b1cf01f_000160_01cbb887+0x33>
  40d14e:	cmp    r9,rdx
  40d151:	jb     40d15a <__swc_fn_6b1cf01f_000160_01cbb887+0x3a>
  40d153:	xor    eax,eax
  40d155:	add    rsp,0x10
  40d159:	ret
  40d15a:	xor    eax,eax
  40d15c:	lea    r8,[r9+rax*1]
  40d160:	cmp    r8,rdx
  40d163:	jae    40d193 <__swc_fn_6b1cf01f_000160_01cbb887+0x73>
  40d165:	cs nop WORD PTR [rax+rax*1+0x0]
  40d16f:	cs nop WORD PTR [rax+rax*1+0x0]
  40d179:	nop    DWORD PTR [rax+0x0]
  40d180:	cmp    BYTE PTR [rcx+r8*1],0x0
  40d185:	je     40d193 <__swc_fn_6b1cf01f_000160_01cbb887+0x73>
  40d187:	inc    rax
  40d18a:	lea    r8,[r9+rax*1]
  40d18e:	cmp    r8,rdx
  40d191:	jb     40d180 <__swc_fn_6b1cf01f_000160_01cbb887+0x60>
  40d193:	cmp    r8,rdx
  40d196:	jne    40d19f <__swc_fn_6b1cf01f_000160_01cbb887+0x7f>
  40d198:	xor    eax,eax
  40d19a:	add    rsp,0x10
  40d19e:	ret
  40d19f:	add    rcx,r9
  40d1a2:	mov    QWORD PTR [rsp],rcx
  40d1a6:	mov    QWORD PTR [rsp+0x8],rax
  40d1ab:	vmovups xmm0,XMMWORD PTR [rsp]
  40d1b0:	vmovups XMMWORD PTR [r10],xmm0
  40d1b5:	mov    eax,0x1
  40d1ba:	add    rsp,0x10
  40d1be:	ret
	...

000000000040d1c0 <__swc_fn_6b1cf01f_000163_8e41797b>:
  40d1c0:	push   rbp
  40d1c1:	push   rbx
  40d1c2:	push   rsi
  40d1c3:	push   rdi
  40d1c4:	push   r12
  40d1c6:	push   r13
  40d1c8:	push   r14
  40d1ca:	push   r15
  40d1cc:	sub    rsp,0x10
  40d1d0:	mov    rbp,rsp
  40d1d3:	vmovups XMMWORD PTR [rsp],xmm6
  40d1d8:	sub    rsp,0x50
  40d1dc:	mov    rbx,rsp
  40d1df:	mov    rsi,r8
  40d1e2:	mov    QWORD PTR [rsp+0x30],r8
  40d1e7:	mov    rdi,rcx
  40d1ea:	mov    QWORD PTR [rsp+0x38],rcx
  40d1ef:	mov    r12,rdx
  40d1f2:	xor    r13b,r13b
  40d1f5:	mov    r14,QWORD PTR [rdi+0x8]
  40d1f9:	mov    QWORD PTR [rsp+0x40],r14
  40d1fe:	xor    r15d,r15d
  40d201:	test   r14,r14
  40d204:	jbe    40d45e <__swc_fn_6b1cf01f_000163_8e41797b+0x29e>
  40d20a:	mov    r14,QWORD PTR [rdi]
  40d20d:	mov    rax,QWORD PTR [rsp+0x40]
  40d212:	mov    QWORD PTR [rsp+0x48],r14
  40d217:	vmovups xmm6,XMMWORD PTR [rip+0x6219]        # 413438 <__swc_rdata_base_6b1cf01f+0x328>
  40d21f:	nop
  40d220:	cmp    QWORD PTR [r14+r15*8],0x0
  40d225:	jne    40d22f <__swc_fn_6b1cf01f_000163_8e41797b+0x6f>
  40d227:	mov    r14,rax
  40d22a:	jmp    40d43e <__swc_fn_6b1cf01f_000163_8e41797b+0x27e>
  40d22f:	mov    rcx,QWORD PTR [rdi]
  40d232:	mov    rdx,QWORD PTR [rcx+r15*8]
  40d236:	mov    rdi,rbx
  40d239:	mov    rcx,rdi
  40d23c:	sub    rsp,0x8
  40d240:	mov    r14,rax
  40d243:	call   409f40 <__swc_fn_6b1cf01f_000162_60216e69>
  40d248:	add    rsp,0x8
  40d24c:	mov    al,BYTE PTR [rbx]
  40d24e:	test   al,al
  40d250:	je     40d43e <__swc_fn_6b1cf01f_000163_8e41797b+0x27e>
  40d256:	mov    al,BYTE PTR [rbx+0x1]
  40d259:	test   al,al
  40d25b:	jne    40d266 <__swc_fn_6b1cf01f_000163_8e41797b+0xa6>
  40d25d:	test   sil,sil
  40d260:	je     40d43e <__swc_fn_6b1cf01f_000163_8e41797b+0x27e>
  40d266:	test   r13b,r13b
  40d269:	jne    40d327 <__swc_fn_6b1cf01f_000163_8e41797b+0x167>
  40d26f:	test   r12,r12
  40d272:	je     40d327 <__swc_fn_6b1cf01f_000163_8e41797b+0x167>
  40d278:	mov    al,BYTE PTR [rbx+0x1]
  40d27b:	test   al,al
  40d27d:	je     40d43e <__swc_fn_6b1cf01f_000163_8e41797b+0x27e>
  40d283:	mov    eax,DWORD PTR [rbx+0x28]
  40d286:	cmp    DWORD PTR [r12+0x20],eax
  40d28b:	jne    40d43e <__swc_fn_6b1cf01f_000163_8e41797b+0x27e>
  40d291:	mov    rax,QWORD PTR [r12]
  40d295:	mov    rcx,QWORD PTR [r12+0x8]
  40d29a:	cmp    QWORD PTR [rbx+0x20],rcx
  40d29e:	jne    40d43e <__swc_fn_6b1cf01f_000163_8e41797b+0x27e>
  40d2a4:	mov    cl,0x1
  40d2a6:	test   rax,rax
  40d2a9:	je     40d312 <__swc_fn_6b1cf01f_000163_8e41797b+0x152>
  40d2af:	mov    rdx,QWORD PTR [rbx+0x20]
  40d2b3:	xor    r8d,r8d
  40d2b6:	test   rdx,rdx
  40d2b9:	jbe    40d312 <__swc_fn_6b1cf01f_000163_8e41797b+0x152>
  40d2bb:	mov    r9,QWORD PTR [rbx+0x18]
  40d2bf:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40d2c4:	cs nop WORD PTR [rax+rax*1+0x0]
  40d2ce:	xchg   ax,ax
  40d2d0:	mov    r10b,BYTE PTR [rax+r8*1]
  40d2d4:	cmp    BYTE PTR [r9+r8*1],r10b
  40d2d8:	je     40d309 <__swc_fn_6b1cf01f_000163_8e41797b+0x149>
  40d2da:	vmovq  r10,xmm0
  40d2df:	cmp    BYTE PTR [r10+r8*1],0x5c
  40d2e4:	jne    40d2ed <__swc_fn_6b1cf01f_000163_8e41797b+0x12d>
  40d2e6:	cmp    BYTE PTR [rax+r8*1],0x2f
  40d2eb:	je     40d309 <__swc_fn_6b1cf01f_000163_8e41797b+0x149>
  40d2ed:	vmovq  r10,xmm0
  40d2f2:	cmp    BYTE PTR [r10+r8*1],0x2f
  40d2f7:	jne    40d300 <__swc_fn_6b1cf01f_000163_8e41797b+0x140>
  40d2f9:	cmp    BYTE PTR [rax+r8*1],0x5c
  40d2fe:	je     40d309 <__swc_fn_6b1cf01f_000163_8e41797b+0x149>
  40d300:	xor    eax,eax
  40d302:	movzx  eax,al
  40d305:	mov    cl,al
  40d307:	jmp    40d312 <__swc_fn_6b1cf01f_000163_8e41797b+0x152>
  40d309:	add    r8,0x1
  40d30d:	cmp    r8,rdx
  40d310:	jb     40d2d0 <__swc_fn_6b1cf01f_000163_8e41797b+0x110>
  40d312:	test   cl,cl
  40d314:	je     40d43e <__swc_fn_6b1cf01f_000163_8e41797b+0x27e>
  40d31a:	mov    eax,0x1
  40d31f:	mov    r13b,al
  40d322:	jmp    40d43e <__swc_fn_6b1cf01f_000163_8e41797b+0x27e>
  40d327:	mov    r13b,0x1
  40d32a:	sub    rsp,0x20
  40d32e:	mov    rax,rsp
  40d331:	lea    rcx,[rdi+0x8]
  40d335:	mov    QWORD PTR [rax],rcx
  40d338:	lea    rsi,[rip+0x5fd1]        # 413310 <__swc_rdata_base_6b1cf01f+0x200>
  40d33f:	mov    QWORD PTR [rax+0x8],rsi
  40d343:	mov    QWORD PTR [rax+0x10],rsp
  40d347:	mov    QWORD PTR [rax+0x18],0x1
  40d34f:	lea    rcx,[rsp+0x10]
  40d354:	sub    rsp,0x8
  40d358:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  40d35d:	add    rsp,0x8
  40d361:	add    rsp,0x20
  40d365:	mov    al,BYTE PTR [rbx+0x1]
  40d368:	test   al,al
  40d36a:	je     40d407 <__swc_fn_6b1cf01f_000163_8e41797b+0x247>
  40d370:	lea    rax,[rip+0x6541]        # 4138b8 <__swc_rdata_base_6b1cf01f+0x7a8>
  40d377:	sub    rsp,0x20
  40d37b:	mov    rcx,rsp
  40d37e:	mov    QWORD PTR [rcx],rax
  40d381:	mov    QWORD PTR [rcx+0x8],rsi
  40d385:	mov    QWORD PTR [rcx+0x10],rsp
  40d389:	mov    QWORD PTR [rcx+0x18],0x1
  40d391:	lea    rcx,[rsp+0x10]
  40d396:	sub    rsp,0x8
  40d39a:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  40d39f:	add    rsp,0x8
  40d3a3:	add    rsp,0x20
  40d3a7:	mov    eax,DWORD PTR [rbx+0x28]
  40d3aa:	sub    rsp,0x60
  40d3ae:	mov    rcx,rsp
  40d3b1:	lea    rdx,[rdi+0x18]
  40d3b5:	mov    QWORD PTR [rcx+0x18],rdx
  40d3b9:	mov    QWORD PTR [rcx+0x20],rsi
  40d3bd:	vmovups XMMWORD PTR [rcx],xmm6
  40d3c1:	mov    QWORD PTR [rcx+0x28],rsp
  40d3c5:	mov    QWORD PTR [rcx+0x30],rsi
  40d3c9:	mov    DWORD PTR [rcx+0x10],eax
  40d3cc:	lea    rax,[rsp+0x10]
  40d3d1:	mov    QWORD PTR [rcx+0x38],rax
  40d3d5:	lea    rax,[rip+0x5ff4]        # 4133d0 <__swc_rdata_base_6b1cf01f+0x2c0>
  40d3dc:	mov    QWORD PTR [rcx+0x40],rax
  40d3e0:	lea    rax,[rsp+0x18]
  40d3e5:	mov    QWORD PTR [rcx+0x48],rax
  40d3e9:	mov    QWORD PTR [rcx+0x50],0x3
  40d3f1:	lea    rcx,[rsp+0x48]
  40d3f6:	sub    rsp,0x8
  40d3fa:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  40d3ff:	add    rsp,0x8
  40d403:	add    rsp,0x60
  40d407:	lea    rax,[rip+0x5f5a]        # 413368 <__swc_rdata_base_6b1cf01f+0x258>
  40d40e:	sub    rsp,0x20
  40d412:	mov    rcx,rsp
  40d415:	mov    QWORD PTR [rcx],rax
  40d418:	mov    QWORD PTR [rcx+0x8],rsi
  40d41c:	mov    QWORD PTR [rcx+0x10],rsp
  40d420:	mov    QWORD PTR [rcx+0x18],0x1
  40d428:	lea    rcx,[rsp+0x10]
  40d42d:	sub    rsp,0x8
  40d431:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  40d436:	add    rsp,0x8
  40d43a:	add    rsp,0x20
  40d43e:	add    r15,0x1
  40d442:	cmp    r15,r14
  40d445:	jae    40d45e <__swc_fn_6b1cf01f_000163_8e41797b+0x29e>
  40d447:	mov    rsi,QWORD PTR [rsp+0x30]
  40d44c:	mov    rdi,QWORD PTR [rsp+0x38]
  40d451:	mov    rax,r14
  40d454:	mov    r14,QWORD PTR [rsp+0x48]
  40d459:	jmp    40d220 <__swc_fn_6b1cf01f_000163_8e41797b+0x60>
  40d45e:	add    rsp,0x50
  40d462:	vmovups xmm6,XMMWORD PTR [rsp]
  40d467:	add    rsp,0x10
  40d46b:	pop    r15
  40d46d:	pop    r14
  40d46f:	pop    r13
  40d471:	pop    r12
  40d473:	pop    rdi
  40d474:	pop    rsi
  40d475:	pop    rbx
  40d476:	pop    rbp
  40d477:	ret
	...

000000000040d480 <__swc_fn_6b1cf01f_000166_f6173642>:
  40d480:	sub    rsp,0x8
  40d484:	call   40fbd0 <__swc_fn_6b1cf01f_000125_ce762363>
  40d489:	add    rsp,0x8
  40d48d:	ret
	...

000000000040d490 <__swc_fn_6b1cf01f_000169_4579a84c>:
  40d490:	push   rsi
  40d491:	sub    rsp,0x30
  40d495:	lea    rsi,[rip+0x19904]        # 426da0 <__swc_bss_base_6b1cf01f+0x2d60>
  40d49c:	mov    rax,QWORD PTR [rsi]
  40d49f:	test   rax,rax
  40d4a2:	je     40d4aa <__swc_fn_6b1cf01f_000169_4579a84c+0x1a>
  40d4a4:	add    rsp,0x30
  40d4a8:	pop    rsi
  40d4a9:	ret
  40d4aa:	mov    ecx,0x2
  40d4af:	mov    edx,0x8020
  40d4b4:	call   40f240 <__swc_fn_6b1cf01f_000107_4796e893>
  40d4b9:	test   rax,rax
  40d4bc:	jne    40d4cd <__swc_fn_6b1cf01f_000169_4579a84c+0x3d>
  40d4be:	mov    QWORD PTR [rsp+0x18],rax
  40d4c3:	call   40c910 <__swc_fn_6b1cf01f_000118_7f430081>
  40d4c8:	mov    rax,QWORD PTR [rsp+0x18]
  40d4cd:	mov    rcx,rax
  40d4d0:	xchg   QWORD PTR [rsi],rcx
  40d4d3:	add    rsp,0x30
  40d4d7:	pop    rsi
  40d4d8:	ret
  40d4d9:	add    BYTE PTR [rax],al
  40d4db:	add    BYTE PTR [rax],al
  40d4dd:	add    BYTE PTR [rax],al
	...

000000000040d4e0 <__swc_fn_6b1cf01f_000172_97fbc432>:
  40d4e0:	push   rsi
  40d4e1:	test   r8,r8
  40d4e4:	jne    40d4e8 <__swc_fn_6b1cf01f_000172_97fbc432+0x8>
  40d4e6:	pop    rsi
  40d4e7:	ret
  40d4e8:	lea    rax,[rcx+0x18]
  40d4ec:	mov    r10,QWORD PTR [rax]
  40d4ef:	lea    r11,[r10+0x1]
  40d4f3:	mov    QWORD PTR [rax],r11
  40d4f6:	mov    r11,rdx
  40d4f9:	not    rdx
  40d4fc:	lea    rsi,[r8-0x1]
  40d500:	cmp    rsi,rdx
  40d503:	ja     40d523 <__swc_fn_6b1cf01f_000172_97fbc432+0x43>
  40d505:	lea    rdx,[r11+r8*1]
  40d509:	dec    rdx
  40d50c:	shr    rdx,0x6
  40d510:	mov    r8,r11
  40d513:	shr    r8,0x6
  40d517:	mov    rsi,rdx
  40d51a:	sub    rsi,r8
  40d51d:	cmp    rsi,0x8
  40d521:	jb     40d539 <__swc_fn_6b1cf01f_000172_97fbc432+0x59>
  40d523:	lea    rcx,[rcx+0x10]
  40d527:	mov    rdx,QWORD PTR [rcx]
  40d52a:	add    rdx,r9
  40d52d:	mov    QWORD PTR [rcx],rdx
  40d530:	lea    rcx,[r10+0x2]
  40d534:	mov    QWORD PTR [rax],rcx
  40d537:	pop    rsi
  40d538:	ret
  40d539:	shr    r11,0x6
  40d53d:	nop    DWORD PTR [rax]
  40d540:	cmp    r11,rdx
  40d543:	ja     40d583 <__swc_fn_6b1cf01f_000172_97fbc432+0xa3>
  40d545:	jmp    40d556 <__swc_fn_6b1cf01f_000172_97fbc432+0x76>
  40d547:	nop    WORD PTR [rax+rax*1+0x0]
  40d550:	add    r11,0x1
  40d554:	jmp    40d540 <__swc_fn_6b1cf01f_000172_97fbc432+0x60>
  40d556:	mov    r8,r11
  40d559:	shr    r8,0xc
  40d55d:	mov    rsi,r11
  40d560:	xor    rsi,r8
  40d563:	mov    r8,r11
  40d566:	shr    r8,0x18
  40d56a:	xor    rsi,r8
  40d56d:	and    esi,0xfff
  40d573:	lea    r8,[rcx+rsi*8+0x20]
  40d578:	mov    rsi,QWORD PTR [r8]
  40d57b:	add    rsi,r9
  40d57e:	mov    QWORD PTR [r8],rsi
  40d581:	jmp    40d550 <__swc_fn_6b1cf01f_000172_97fbc432+0x70>
  40d583:	lea    rcx,[r10+0x2]
  40d587:	mov    QWORD PTR [rax],rcx
  40d58a:	pop    rsi
  40d58b:	ret
  40d58c:	add    BYTE PTR [rax],al
	...

000000000040d590 <__swc_fn_6b1cf01f_000175_1ca87929>:
  40d590:	push   rdi
  40d591:	push   rsi
  40d592:	sub    rsp,0xb8
  40d599:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40d59f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40d5a5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40d5ab:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40d5b1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40d5b7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40d5bd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40d5c3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40d5cc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40d5d5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40d5de:	vxorps xmm0,xmm0,xmm0
  40d5e2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40d5e8:	mov    edi,0x1
  40d5ed:	lea    rsi,[rsp+0x8]
  40d5f2:	xor    eax,eax
  40d5f4:	call   407110 <clock_gettime@plt>
  40d5f9:	vxorpd xmm0,xmm0,xmm0
  40d5fd:	mov    rax,QWORD PTR [rsp+0x8]
  40d602:	vcvtsi2sd xmm0,xmm0,rax
  40d607:	vxorpd xmm1,xmm1,xmm1
  40d60b:	mov    rax,QWORD PTR [rsp+0x10]
  40d610:	vcvtsi2sd xmm1,xmm1,rax
  40d615:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x62eb]        # 413908 <__swc_rdata_base_6b1cf01f+0x7f8>
  40d61d:	vaddsd xmm0,xmm0,xmm1
  40d621:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40d627:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40d62d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40d633:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40d639:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40d63f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40d645:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40d64b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40d654:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40d65d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40d666:	add    rsp,0xb8
  40d66d:	pop    rsi
  40d66e:	pop    rdi
  40d66f:	ret
	...

000000000040d680 <__swc_fn_6b1cf01f_000002_884bb5c0>:
  40d680:	sub    rsp,0x8
  40d684:	call   40c560 <__swc_fn_6b1cf01f_000109_8d425bd3>
  40d689:	mov    rcx,rax
  40d68c:	test   rax,rax
  40d68f:	je     40d6b6 <__swc_fn_6b1cf01f_000002_884bb5c0+0x36>
  40d691:	lea    rdx,[rip+0x169a8]        # 424040 <__swc_bss_base_6b1cf01f>
  40d698:	mov    r8,QWORD PTR [rip+0x169a1]        # 424040 <__swc_bss_base_6b1cf01f>
  40d69f:	nop
  40d6a0:	lea    r9,[r8+0x1]
  40d6a4:	mov    rax,r8
  40d6a7:	lock cmpxchg QWORD PTR [rdx],r9
  40d6ac:	cmp    rax,r8
  40d6af:	je     40d6b6 <__swc_fn_6b1cf01f_000002_884bb5c0+0x36>
  40d6b1:	mov    r8,rax
  40d6b4:	jmp    40d6a0 <__swc_fn_6b1cf01f_000002_884bb5c0+0x20>
  40d6b6:	mov    rax,rcx
  40d6b9:	add    rsp,0x8
  40d6bd:	ret
	...

000000000040d6c0 <__swc_fn_6b1cf01f_000005_b2240b56>:
  40d6c0:	mov    r8d,edx
  40d6c3:	xor    eax,eax
  40d6c5:	tzcnt  eax,edx
  40d6c9:	shrx   r9d,edx,eax
  40d6ce:	mov    DWORD PTR [rcx+0x2c],edx
  40d6d1:	xor    eax,eax
  40d6d3:	tzcnt  eax,edx
  40d6d7:	mov    BYTE PTR [rcx+0x38],al
  40d6da:	mov    eax,0xffffffff
  40d6df:	xor    edx,edx
  40d6e1:	div    r8d
  40d6e4:	mov    DWORD PTR [rcx+0x34],eax
  40d6e7:	mov    eax,r9d
  40d6ea:	mov    edx,r9d
  40d6ed:	imul   edx,r9d
  40d6f1:	mov    r8d,0x2
  40d6f7:	sub    r8d,edx
  40d6fa:	imul   eax,r8d
  40d6fe:	mov    edx,r9d
  40d701:	imul   edx,eax
  40d704:	mov    r8d,0x2
  40d70a:	sub    r8d,edx
  40d70d:	imul   eax,r8d
  40d711:	mov    edx,r9d
  40d714:	imul   edx,eax
  40d717:	mov    r8d,0x2
  40d71d:	sub    r8d,edx
  40d720:	imul   eax,r8d
  40d724:	mov    edx,r9d
  40d727:	imul   edx,eax
  40d72a:	mov    r8d,0x2
  40d730:	sub    r8d,edx
  40d733:	imul   eax,r8d
  40d737:	imul   r9d,eax
  40d73b:	mov    edx,0x2
  40d740:	sub    edx,r9d
  40d743:	imul   eax,edx
  40d746:	mov    DWORD PTR [rcx+0x30],eax
  40d749:	ret
  40d74a:	add    BYTE PTR [rax],al
  40d74c:	add    BYTE PTR [rax],al
	...

000000000040d750 <__swc_fn_6b1cf01f_000008_4e857afc>:
  40d750:	xor    eax,eax
  40d752:	mov    DWORD PTR [rcx+0x68],eax
  40d755:	ret
	...

000000000040d760 <__swc_fn_6b1cf01f_000011_6493fbbc>:
  40d760:	mov    eax,DWORD PTR [rcx+0x28]
  40d763:	shlx   eax,edx,eax
  40d768:	shl    rax,0x10
  40d76c:	lea    rdx,[rcx+rax*1]
  40d770:	lea    rax,[rcx+0x3000]
  40d777:	cmp    rdx,rax
  40d77a:	cmovae rax,rdx
  40d77e:	ret
	...

000000000040d780 <__swc_fn_6b1cf01f_000014_afb279e2>:
  40d780:	push   rsi
  40d781:	push   rdi
  40d782:	push   r12
  40d784:	push   r13
  40d786:	push   r14
  40d788:	mov    rsi,rdx
  40d78b:	mov    rdi,rcx
  40d78e:	rex mov dl,BYTE PTR [rsi+0x3a]
  40d792:	mov    ecx,DWORD PTR [rdi+0x28]
  40d795:	shr    dl,cl
  40d797:	mov    r12d,0x1
  40d79d:	mov    ecx,edx
  40d79f:	shl    r12,cl
  40d7a2:	mov    r13d,DWORD PTR [rsi+0x3c]
  40d7a6:	rex mov BYTE PTR [rsi+0x3b],0x0
  40d7ab:	mov    QWORD PTR [rsi+0x40],0x0
  40d7b3:	mov    QWORD PTR [rsi],0x0
  40d7ba:	mov    rax,QWORD PTR [rsi+0x10]
  40d7be:	mov    QWORD PTR [rsi+0x20],rax
  40d7c2:	lea    r14,[rip+0x1687f]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  40d7c9:	mov    rax,QWORD PTR [r14]
  40d7cc:	shr    rax,0x2
  40d7d0:	mov    rcx,rax
  40d7d3:	cmp    rax,0x800000
  40d7da:	mov    eax,0x800000
  40d7df:	cmovb  rcx,rax
  40d7e3:	lea    r8,[rip+0x1686e]        # 424058 <__swc_bss_base_6b1cf01f+0x18>
  40d7ea:	mov    rax,QWORD PTR [r8]
  40d7ed:	mov    r9,rax
  40d7f0:	lea    r10,[r9+r13*1]
  40d7f4:	cmp    r10,rcx
  40d7f7:	ja     40d81b <__swc_fn_6b1cf01f_000014_afb279e2+0x9b>
  40d7f9:	mov    rax,r9
  40d7fc:	lock cmpxchg QWORD PTR [r8],r10
  40d801:	cmp    rax,r9
  40d804:	je     40d80b <__swc_fn_6b1cf01f_000014_afb279e2+0x8b>
  40d806:	mov    r9,rax
  40d809:	jmp    40d7f0 <__swc_fn_6b1cf01f_000014_afb279e2+0x70>
  40d80b:	mov    rcx,rdi
  40d80e:	mov    rdx,r12
  40d811:	call   40a690 <__swc_fn_6b1cf01f_000016_4b207b58>
  40d816:	jmp    40d89d <__swc_fn_6b1cf01f_000014_afb279e2+0x11d>
  40d81b:	mov    rcx,rdi
  40d81e:	movzx  edx,dl
  40d821:	call   40d760 <__swc_fn_6b1cf01f_000011_6493fbbc>
  40d826:	test   r13,r13
  40d829:	je     40d896 <__swc_fn_6b1cf01f_000014_afb279e2+0x116>
  40d82f:	mov    rcx,rax
  40d832:	mov    rdx,r13
  40d835:	call   40c6e0 <__swc_fn_6b1cf01f_000112_759e9ceb>
  40d83a:	mov    rcx,QWORD PTR [rip+0x16807]        # 424048 <__swc_bss_base_6b1cf01f+0x8>
  40d841:	cs nop WORD PTR [rax+rax*1+0x0]
  40d84b:	nop    DWORD PTR [rax+rax*1+0x0]
  40d850:	mov    rdx,rcx
  40d853:	sub    rdx,r13
  40d856:	mov    rax,rcx
  40d859:	lock cmpxchg QWORD PTR [r14],rdx
  40d85e:	cmp    rax,rcx
  40d861:	je     40d868 <__swc_fn_6b1cf01f_000014_afb279e2+0xe8>
  40d863:	mov    rcx,rax
  40d866:	jmp    40d850 <__swc_fn_6b1cf01f_000014_afb279e2+0xd0>
  40d868:	lea    rcx,[rip+0x167f1]        # 424060 <__swc_bss_base_6b1cf01f+0x20>
  40d86f:	mov    rdx,QWORD PTR [rip+0x167ea]        # 424060 <__swc_bss_base_6b1cf01f+0x20>
  40d876:	cs nop WORD PTR [rax+rax*1+0x0]
  40d880:	lea    r8,[rdx+0x1]
  40d884:	mov    rax,rdx
  40d887:	lock cmpxchg QWORD PTR [rcx],r8
  40d88c:	cmp    rax,rdx
  40d88f:	je     40d896 <__swc_fn_6b1cf01f_000014_afb279e2+0x116>
  40d891:	mov    rdx,rax
  40d894:	jmp    40d880 <__swc_fn_6b1cf01f_000014_afb279e2+0x100>
  40d896:	mov    DWORD PTR [rsi+0x3c],0x0
  40d89d:	mov    rcx,rdi
  40d8a0:	mov    rdx,r12
  40d8a3:	call   407600 <__swc_fn_6b1cf01f_000018_7d1e8a10>
  40d8a8:	pop    r14
  40d8aa:	pop    r13
  40d8ac:	pop    r12
  40d8ae:	pop    rdi
  40d8af:	pop    rsi
  40d8b0:	ret
	...

000000000040d8c0 <__swc_fn_6b1cf01f_000017_4df2d1a0>:
  40d8c0:	mov    r8,QWORD PTR [rcx+0x48]
  40d8c4:	test   r8,rdx
  40d8c7:	je     40d8f8 <__swc_fn_6b1cf01f_000017_4df2d1a0+0x38>
  40d8c9:	nop    DWORD PTR [rax+0x0]
  40d8d0:	mov    rax,rdx
  40d8d3:	not    rax
  40d8d6:	mov    r9,r8
  40d8d9:	and    r9,rax
  40d8dc:	mov    rax,r8
  40d8df:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40d8e5:	cmp    rax,r8
  40d8e8:	jne    40d8f0 <__swc_fn_6b1cf01f_000017_4df2d1a0+0x30>
  40d8ea:	mov    eax,0x1
  40d8ef:	ret
  40d8f0:	mov    r8,rax
  40d8f3:	test   rax,rdx
  40d8f6:	jne    40d8d0 <__swc_fn_6b1cf01f_000017_4df2d1a0+0x10>
  40d8f8:	xor    eax,eax
  40d8fa:	ret
  40d8fb:	add    BYTE PTR [rax],al
  40d8fd:	add    BYTE PTR [rax],al
	...

000000000040d900 <__swc_fn_6b1cf01f_000020_a66e8b97>:
  40d900:	push   rsi
  40d901:	push   rdi
  40d902:	push   r12
  40d904:	push   r13
  40d906:	sub    rsp,0x8
  40d90a:	mov    rsi,rdx
  40d90d:	mov    rdi,rcx
  40d910:	lea    r12,[rip+0x168d9]        # 4241f0 <__swc_bss_base_6b1cf01f+0x1b0>
  40d917:	mov    rcx,r12
  40d91a:	call   4098c0 <__swc_fn_6b1cf01f_000135_e3032dc2>
  40d91f:	xor    eax,eax
  40d921:	mov    rcx,QWORD PTR [rip+0x168d0]        # 4241f8 <__swc_bss_base_6b1cf01f+0x1b8>
  40d928:	mov    r13,rcx
  40d92b:	test   r13,r13
  40d92e:	je     40d97b <__swc_fn_6b1cf01f_000020_a66e8b97+0x7b>
  40d930:	mov    rcx,QWORD PTR [r13+0x10]
  40d934:	cmp    DWORD PTR [r13+0x28],esi
  40d938:	jne    40d970 <__swc_fn_6b1cf01f_000020_a66e8b97+0x70>
  40d93a:	test   rax,rax
  40d93d:	jne    40d948 <__swc_fn_6b1cf01f_000020_a66e8b97+0x48>
  40d93f:	mov    QWORD PTR [rip+0x168b2],rcx        # 4241f8 <__swc_bss_base_6b1cf01f+0x1b8>
  40d946:	jmp    40d94c <__swc_fn_6b1cf01f_000020_a66e8b97+0x4c>
  40d948:	mov    QWORD PTR [rax+0x10],rcx
  40d94c:	vxorps xmm0,xmm0,xmm0
  40d950:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40d956:	mov    QWORD PTR [r13+0x8],rdi
  40d95a:	mov    rcx,r12
  40d95d:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  40d962:	mov    rax,r13
  40d965:	add    rsp,0x8
  40d969:	pop    r13
  40d96b:	pop    r12
  40d96d:	pop    rdi
  40d96e:	pop    rsi
  40d96f:	ret
  40d970:	mov    rax,r13
  40d973:	mov    r13,rcx
  40d976:	test   rcx,rcx
  40d979:	jne    40d930 <__swc_fn_6b1cf01f_000020_a66e8b97+0x30>
  40d97b:	mov    ecx,esi
  40d97d:	call   40a6c0 <__swc_fn_6b1cf01f_000019_2cc1532c>
  40d982:	mov    rsi,rax
  40d985:	test   rax,rax
  40d988:	jne    40d99f <__swc_fn_6b1cf01f_000020_a66e8b97+0x9f>
  40d98a:	mov    rcx,r12
  40d98d:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  40d992:	xor    eax,eax
  40d994:	add    rsp,0x8
  40d998:	pop    r13
  40d99a:	pop    r12
  40d99c:	pop    rdi
  40d99d:	pop    rsi
  40d99e:	ret
  40d99f:	mov    QWORD PTR [rsi+0x8],rdi
  40d9a3:	mov    rcx,r12
  40d9a6:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  40d9ab:	mov    rax,rsi
  40d9ae:	add    rsp,0x8
  40d9b2:	pop    r13
  40d9b4:	pop    r12
  40d9b6:	pop    rdi
  40d9b7:	pop    rsi
  40d9b8:	ret
  40d9b9:	add    BYTE PTR [rax],al
  40d9bb:	add    BYTE PTR [rax],al
  40d9bd:	add    BYTE PTR [rax],al
	...

000000000040d9c0 <__swc_fn_6b1cf01f_000023_4aca8b9e>:
  40d9c0:	vxorps xmm0,xmm0,xmm0
  40d9c4:	xor    eax,eax
  40d9c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40d9d0:	cs nop WORD PTR [rax+rax*1+0x0]
  40d9da:	nop    WORD PTR [rax+rax*1+0x0]
  40d9e0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40d9e5:	add    rax,0x10
  40d9e9:	cmp    rax,0x2b00
  40d9f0:	jne    40d9e0 <__swc_fn_6b1cf01f_000023_4aca8b9e+0x20>
  40d9f2:	ret
	...

000000000040da00 <__swc_fn_6b1cf01f_000026_4aca8b9e>:
  40da00:	vxorps xmm0,xmm0,xmm0
  40da04:	vmovups XMMWORD PTR [rcx],xmm0
  40da08:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40da0d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40da12:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40da17:	ret
	...

000000000040da20 <__swc_fn_6b1cf01f_000029_4aca8b9e>:
  40da20:	vxorps xmm0,xmm0,xmm0
  40da24:	vmovups XMMWORD PTR [rcx],xmm0
  40da28:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40da2d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40da32:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40da37:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40da3c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40da41:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40da46:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40da4b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40da53:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40da5b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40da63:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40da6b:	mov    QWORD PTR [rcx+0xc0],0x0
  40da76:	ret
	...

000000000040da80 <__swc_fn_6b1cf01f_000032_84881cd8>:
  40da80:	push   rsi
  40da81:	push   rdi
  40da82:	sub    rsp,0x8
  40da86:	mov    rsi,rcx
  40da89:	lea    rdi,[rip+0x14570]        # 422000 <__swc_data_base_6b1cf01f>
  40da90:	mov    rax,QWORD PTR [rdi]
  40da93:	cmp    rax,0xffffffffffffffff
  40da97:	je     40da9e <__swc_fn_6b1cf01f_000032_84881cd8+0x1e>
  40da99:	mov    rdi,rax
  40da9c:	jmp    40dacb <__swc_fn_6b1cf01f_000032_84881cd8+0x4b>
  40da9e:	call   4095a0 <__swc_fn_6b1cf01f_000123_9d2cbd72>
  40daa3:	mov    rcx,rax
  40daa6:	cmp    rax,0xffffffffffffffff
  40daaa:	je     40dadc <__swc_fn_6b1cf01f_000032_84881cd8+0x5c>
  40daac:	mov    rax,0xffffffffffffffff
  40dab3:	lock cmpxchg QWORD PTR [rdi],rcx
  40dab8:	cmp    rax,0xffffffffffffffff
  40dabc:	je     40dac8 <__swc_fn_6b1cf01f_000032_84881cd8+0x48>
  40dabe:	mov    rdi,rax
  40dac1:	call   40cab0 <__swc_fn_6b1cf01f_000124_667fbf24>
  40dac6:	jmp    40dacb <__swc_fn_6b1cf01f_000032_84881cd8+0x4b>
  40dac8:	mov    rdi,rcx
  40dacb:	cmp    rdi,0xffffffffffffffff
  40dacf:	je     40dadc <__swc_fn_6b1cf01f_000032_84881cd8+0x5c>
  40dad1:	mov    rcx,rdi
  40dad4:	mov    rdx,rsi
  40dad7:	call   40fbd0 <__swc_fn_6b1cf01f_000125_ce762363>
  40dadc:	add    rsp,0x8
  40dae0:	pop    rdi
  40dae1:	pop    rsi
  40dae2:	ret
	...

000000000040daf0 <__swc_fn_6b1cf01f_000035_95622a2b>:
  40daf0:	sub    rsp,0x38
  40daf4:	mov    rax,rdx
  40daf7:	test   dl,dl
  40daf9:	jne    40db11 <__swc_fn_6b1cf01f_000035_95622a2b+0x21>
  40dafb:	mov    rax,r8
  40dafe:	test   r8b,r8b
  40db01:	cmove  eax,r9d
  40db05:	test   al,al
  40db07:	cmove  eax,r10d
  40db0b:	test   al,al
  40db0d:	cmove  eax,r11d
  40db11:	test   al,al
  40db13:	jne    40db1a <__swc_fn_6b1cf01f_000035_95622a2b+0x2a>
  40db15:	add    rsp,0x38
  40db19:	ret
  40db1a:	lea    rcx,[rip+0x55ef]        # 413110 <__swc_rdata_base_6b1cf01f>
  40db21:	vmovups xmm0,XMMWORD PTR [rip+0x55f7]        # 413120 <__swc_rdata_base_6b1cf01f+0x10>
  40db29:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40db2f:	vmovups xmm0,XMMWORD PTR [rip+0x55f9]        # 413130 <__swc_rdata_base_6b1cf01f+0x20>
  40db37:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40db3d:	vmovups xmm0,XMMWORD PTR [rip+0x55fb]        # 413140 <__swc_rdata_base_6b1cf01f+0x30>
  40db45:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40db4b:	lea    rdx,[rsp+0x8]
  40db50:	call   40c2e0 <__swc_fn_6b1cf01f_000103_67100064>
  40db55:	jmp    40db15 <__swc_fn_6b1cf01f_000035_95622a2b+0x25>
	...

000000000040db60 <__swc_fn_6b1cf01f_000038_788ceb38>:
  40db60:	sub    rsp,0x8
  40db64:	mov    eax,0x1000
  40db69:	test   eax,eax
  40db6b:	mov    r8d,0x8
  40db71:	cmove  eax,r8d
  40db75:	dec    rax
  40db78:	mov    r8,0xffffffffffffffff
  40db7f:	sub    r8,rax
  40db82:	cmp    rdx,r8
  40db85:	ja     40db95 <__swc_fn_6b1cf01f_000038_788ceb38+0x35>
  40db87:	add    rdx,rax
  40db8a:	not    rax
  40db8d:	mov    r8,rdx
  40db90:	and    r8,rax
  40db93:	jne    40db9c <__swc_fn_6b1cf01f_000038_788ceb38+0x3c>
  40db95:	xor    eax,eax
  40db97:	add    rsp,0x8
  40db9b:	ret
  40db9c:	mov    rdx,r8
  40db9f:	call   40a9e0 <__swc_fn_6b1cf01f_000037_b4982903>
  40dba4:	add    rsp,0x8
  40dba8:	ret
  40dba9:	add    BYTE PTR [rax],al
  40dbab:	add    BYTE PTR [rax],al
  40dbad:	add    BYTE PTR [rax],al
	...

000000000040dbb0 <__swc_fn_6b1cf01f_000041_414cc921>:
  40dbb0:	push   rsi
  40dbb1:	push   rdi
  40dbb2:	sub    rsp,0x8
  40dbb6:	mov    rsi,rdx
  40dbb9:	mov    rdi,rcx
  40dbbc:	test   rdx,rdx
  40dbbf:	je     40dbdb <__swc_fn_6b1cf01f_000041_414cc921+0x2b>
  40dbc1:	xor    ecx,ecx
  40dbc3:	call   407720 <__swc_fn_6b1cf01f_000033_7ca1566d>
  40dbc8:	mov    rax,QWORD PTR [rsi]
  40dbcb:	test   rax,rax
  40dbce:	je     40dbdb <__swc_fn_6b1cf01f_000041_414cc921+0x2b>
  40dbd0:	mov    rcx,rax
  40dbd3:	mov    rdx,rsi
  40dbd6:	call   407840 <__swc_fn_6b1cf01f_000042_bab03645>
  40dbdb:	mov    rcx,rdi
  40dbde:	call   40aa40 <__swc_fn_6b1cf01f_000040_6895916d>
  40dbe3:	mov    rsi,rax
  40dbe6:	test   rax,rax
  40dbe9:	jne    40dbf4 <__swc_fn_6b1cf01f_000041_414cc921+0x44>
  40dbeb:	xor    eax,eax
  40dbed:	add    rsp,0x8
  40dbf1:	pop    rdi
  40dbf2:	pop    rsi
  40dbf3:	ret
  40dbf4:	mov    rcx,rsi
  40dbf7:	call   407720 <__swc_fn_6b1cf01f_000033_7ca1566d>
  40dbfc:	mov    rax,rsi
  40dbff:	add    rsp,0x8
  40dc03:	pop    rdi
  40dc04:	pop    rsi
  40dc05:	ret
	...

000000000040dc10 <__swc_fn_6b1cf01f_000044_9c2ade9b>:
  40dc10:	movzx  eax,BYTE PTR [r8+0x39]
  40dc15:	lea    rax,[rax+rax*4]
  40dc19:	lea    rax,[rdx+rax*8+0x28]
  40dc1e:	mov    ecx,DWORD PTR [r8+0x6c]
  40dc22:	test   ecx,ecx
  40dc24:	je     40dc5d <__swc_fn_6b1cf01f_000044_9c2ade9b+0x4d>
  40dc26:	mov    rcx,QWORD PTR [r8+0x50]
  40dc2a:	test   rcx,rcx
  40dc2d:	je     40dc39 <__swc_fn_6b1cf01f_000044_9c2ade9b+0x29>
  40dc2f:	mov    rax,QWORD PTR [r8+0x48]
  40dc33:	mov    QWORD PTR [rcx+0x48],rax
  40dc37:	jmp    40dc41 <__swc_fn_6b1cf01f_000044_9c2ade9b+0x31>
  40dc39:	mov    rcx,QWORD PTR [r8+0x48]
  40dc3d:	mov    QWORD PTR [rax+0x18],rcx
  40dc41:	mov    rax,QWORD PTR [r8+0x48]
  40dc45:	test   rax,rax
  40dc48:	je     40dc52 <__swc_fn_6b1cf01f_000044_9c2ade9b+0x42>
  40dc4a:	mov    rcx,QWORD PTR [r8+0x50]
  40dc4e:	mov    QWORD PTR [rax+0x50],rcx
  40dc52:	vxorps xmm0,xmm0,xmm0
  40dc56:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40dc5c:	ret
  40dc5d:	mov    rcx,QWORD PTR [r8+0x50]
  40dc61:	test   rcx,rcx
  40dc64:	je     40dc70 <__swc_fn_6b1cf01f_000044_9c2ade9b+0x60>
  40dc66:	mov    rdx,QWORD PTR [r8+0x48]
  40dc6a:	mov    QWORD PTR [rcx+0x48],rdx
  40dc6e:	jmp    40dc78 <__swc_fn_6b1cf01f_000044_9c2ade9b+0x68>
  40dc70:	mov    rcx,QWORD PTR [r8+0x48]
  40dc74:	mov    QWORD PTR [rax+0x8],rcx
  40dc78:	mov    rcx,QWORD PTR [r8+0x48]
  40dc7c:	test   rcx,rcx
  40dc7f:	je     40dc8b <__swc_fn_6b1cf01f_000044_9c2ade9b+0x7b>
  40dc81:	mov    rdx,QWORD PTR [r8+0x50]
  40dc85:	mov    QWORD PTR [rcx+0x50],rdx
  40dc89:	jmp    40dc93 <__swc_fn_6b1cf01f_000044_9c2ade9b+0x83>
  40dc8b:	mov    rcx,QWORD PTR [r8+0x50]
  40dc8f:	mov    QWORD PTR [rax+0x10],rcx
  40dc93:	cmp    QWORD PTR [rax],r8
  40dc96:	jne    40dc9f <__swc_fn_6b1cf01f_000044_9c2ade9b+0x8f>
  40dc98:	mov    QWORD PTR [rax],0x0
  40dc9f:	vxorps xmm0,xmm0,xmm0
  40dca3:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40dca9:	ret
  40dcaa:	add    BYTE PTR [rax],al
  40dcac:	add    BYTE PTR [rax],al
	...

000000000040dcb0 <__swc_fn_6b1cf01f_000047_bc5ec610>:
  40dcb0:	sub    rsp,0x8
  40dcb4:	mov    r9,r8
  40dcb7:	mov    r10,rdx
  40dcba:	call   40dc10 <__swc_fn_6b1cf01f_000044_9c2ade9b>
  40dcbf:	mov    DWORD PTR [r9+0x6c],0x0
  40dcc7:	movzx  eax,BYTE PTR [r9+0x39]
  40dccc:	lea    rax,[rax+rax*4]
  40dcd0:	lea    rax,[r10+rax*8+0x28]
  40dcd5:	mov    rcx,QWORD PTR [rax+0x10]
  40dcd9:	mov    QWORD PTR [r9+0x50],rcx
  40dcdd:	mov    QWORD PTR [r9+0x48],0x0
  40dce5:	mov    rcx,QWORD PTR [rax+0x10]
  40dce9:	test   rcx,rcx
  40dcec:	je     40dcf4 <__swc_fn_6b1cf01f_000047_bc5ec610+0x44>
  40dcee:	mov    QWORD PTR [rcx+0x48],r9
  40dcf2:	jmp    40dcf8 <__swc_fn_6b1cf01f_000047_bc5ec610+0x48>
  40dcf4:	mov    QWORD PTR [rax+0x8],r9
  40dcf8:	mov    QWORD PTR [rax+0x10],r9
  40dcfc:	add    rsp,0x8
  40dd00:	ret
	...

000000000040dd20 <__swc_fn_6b1cf01f_000050_ab8077df>:
  40dd20:	push   rsi
  40dd21:	push   rdi
  40dd22:	push   r12
  40dd24:	push   r13
  40dd26:	push   r14
  40dd28:	push   r15
  40dd2a:	sub    rsp,0x1f8
  40dd31:	mov    esi,r8d
  40dd34:	mov    QWORD PTR [rsp+0x1e8],rsi
  40dd3c:	mov    rdi,rcx
  40dd3f:	mov    r12,rdx
  40dd42:	lea    r13,[rsi+rsi*4]
  40dd46:	lea    r13,[rdx+r13*8+0x28]
  40dd4b:	call   407ca0 <__swc_fn_6b1cf01f_000048_c877e9d2>
  40dd50:	add    DWORD PTR [r12+0x24],0x1
  40dd56:	test   BYTE PTR [r12+0x24],0x3f
  40dd5c:	jne    40dd66 <__swc_fn_6b1cf01f_000050_ab8077df+0x46>
  40dd5e:	mov    rcx,rdi
  40dd61:	call   40abc0 <__swc_fn_6b1cf01f_000049_2ff013cc>
  40dd66:	mov    rax,QWORD PTR [r13+0x8]
  40dd6a:	mov    r14,rax
  40dd6d:	nop    DWORD PTR [rax]
  40dd70:	test   r14,r14
  40dd73:	jne    40dd82 <__swc_fn_6b1cf01f_000050_ab8077df+0x62>
  40dd75:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40dd7d:	jmp    40de89 <__swc_fn_6b1cf01f_000050_ab8077df+0x169>
  40dd82:	mov    r15,QWORD PTR [r14+0x48]
  40dd86:	mov    rcx,r14
  40dd89:	call   4073f0 <__swc_fn_6b1cf01f_000009_d7e2bb25>
  40dd8e:	mov    rax,QWORD PTR [r14]
  40dd91:	test   rax,rax
  40dd94:	je     40dda6 <__swc_fn_6b1cf01f_000050_ab8077df+0x86>
  40dd96:	mov    rcx,QWORD PTR [rax]
  40dd99:	mov    QWORD PTR [r14],rcx
  40dd9c:	add    DWORD PTR [r14+0x28],0x1
  40dda1:	mov    rsi,rax
  40dda4:	jmp    40ddc5 <__swc_fn_6b1cf01f_000050_ab8077df+0xa5>
  40dda6:	mov    rax,QWORD PTR [r14+0x18]
  40ddaa:	cmp    QWORD PTR [r14+0x20],rax
  40ddae:	jae    40ddc3 <__swc_fn_6b1cf01f_000050_ab8077df+0xa3>
  40ddb0:	mov    rsi,QWORD PTR [r14+0x20]
  40ddb4:	mov    eax,DWORD PTR [r14+0x2c]
  40ddb8:	add    QWORD PTR [r14+0x20],rax
  40ddbc:	add    DWORD PTR [r14+0x28],0x1
  40ddc1:	jmp    40ddc5 <__swc_fn_6b1cf01f_000050_ab8077df+0xa5>
  40ddc3:	xor    esi,esi
  40ddc5:	test   rsi,rsi
  40ddc8:	jne    40de0d <__swc_fn_6b1cf01f_000050_ab8077df+0xed>
  40ddca:	mov    rcx,r14
  40ddcd:	call   407320 <__swc_fn_6b1cf01f_000006_a23dca5f>
  40ddd2:	test   al,al
  40ddd4:	je     40de0d <__swc_fn_6b1cf01f_000050_ab8077df+0xed>
  40ddd6:	mov    rax,QWORD PTR [r14]
  40ddd9:	test   rax,rax
  40dddc:	je     40ddeb <__swc_fn_6b1cf01f_000050_ab8077df+0xcb>
  40ddde:	mov    rcx,QWORD PTR [rax]
  40dde1:	mov    QWORD PTR [r14],rcx
  40dde4:	add    DWORD PTR [r14+0x28],0x1
  40dde9:	jmp    40de0a <__swc_fn_6b1cf01f_000050_ab8077df+0xea>
  40ddeb:	mov    rax,QWORD PTR [r14+0x18]
  40ddef:	cmp    QWORD PTR [r14+0x20],rax
  40ddf3:	jae    40de08 <__swc_fn_6b1cf01f_000050_ab8077df+0xe8>
  40ddf5:	mov    rax,QWORD PTR [r14+0x20]
  40ddf9:	mov    ecx,DWORD PTR [r14+0x2c]
  40ddfd:	add    QWORD PTR [r14+0x20],rcx
  40de01:	add    DWORD PTR [r14+0x28],0x1
  40de06:	jmp    40de0a <__swc_fn_6b1cf01f_000050_ab8077df+0xea>
  40de08:	xor    eax,eax
  40de0a:	mov    rsi,rax
  40de0d:	test   rsi,rsi
  40de10:	jne    40de63 <__swc_fn_6b1cf01f_000050_ab8077df+0x143>
  40de12:	mov    rcx,rdi
  40de15:	mov    rdx,r12
  40de18:	mov    r8,r14
  40de1b:	call   40ab20 <__swc_fn_6b1cf01f_000046_88f44774>
  40de20:	test   al,al
  40de22:	jne    40de63 <__swc_fn_6b1cf01f_000050_ab8077df+0x143>
  40de24:	mov    rcx,r14
  40de27:	call   4073f0 <__swc_fn_6b1cf01f_000009_d7e2bb25>
  40de2c:	mov    rax,QWORD PTR [r14]
  40de2f:	test   rax,rax
  40de32:	je     40de41 <__swc_fn_6b1cf01f_000050_ab8077df+0x121>
  40de34:	mov    rcx,QWORD PTR [rax]
  40de37:	mov    QWORD PTR [r14],rcx
  40de3a:	add    DWORD PTR [r14+0x28],0x1
  40de3f:	jmp    40de60 <__swc_fn_6b1cf01f_000050_ab8077df+0x140>
  40de41:	mov    rax,QWORD PTR [r14+0x18]
  40de45:	cmp    QWORD PTR [r14+0x20],rax
  40de49:	jae    40de5e <__swc_fn_6b1cf01f_000050_ab8077df+0x13e>
  40de4b:	mov    rax,QWORD PTR [r14+0x20]
  40de4f:	mov    ecx,DWORD PTR [r14+0x2c]
  40de53:	add    QWORD PTR [r14+0x20],rcx
  40de57:	add    DWORD PTR [r14+0x28],0x1
  40de5c:	jmp    40de60 <__swc_fn_6b1cf01f_000050_ab8077df+0x140>
  40de5e:	xor    eax,eax
  40de60:	mov    rsi,rax
  40de63:	test   rsi,rsi
  40de66:	je     40de81 <__swc_fn_6b1cf01f_000050_ab8077df+0x161>
  40de68:	mov    QWORD PTR [r13+0x0],r14
  40de6c:	mov    rax,rsi
  40de6f:	add    rsp,0x1f8
  40de76:	pop    r15
  40de78:	pop    r14
  40de7a:	pop    r13
  40de7c:	pop    r12
  40de7e:	pop    rdi
  40de7f:	pop    rsi
  40de80:	ret
  40de81:	mov    r14,r15
  40de84:	jmp    40dd70 <__swc_fn_6b1cf01f_000050_ab8077df+0x50>
  40de89:	cs nop WORD PTR [rax+rax*1+0x0]
  40de93:	cs nop WORD PTR [rax+rax*1+0x0]
  40de9d:	nop    DWORD PTR [rax]
  40dea0:	mov    rcx,rdi
  40dea3:	mov    rdx,r12
  40dea6:	mov    r8d,esi
  40dea9:	call   4079e0 <__swc_fn_6b1cf01f_000045_1fe0f4e2>
  40deae:	mov    r14,rax
  40deb1:	test   rax,rax
  40deb4:	jne    40deca <__swc_fn_6b1cf01f_000050_ab8077df+0x1aa>
  40deb6:	xor    eax,eax
  40deb8:	add    rsp,0x1f8
  40debf:	pop    r15
  40dec1:	pop    r14
  40dec3:	pop    r13
  40dec5:	pop    r12
  40dec7:	pop    rdi
  40dec8:	pop    rsi
  40dec9:	ret
  40deca:	mov    QWORD PTR [r13+0x0],r14
  40dece:	mov    rax,QWORD PTR [r14]
  40ded1:	test   rax,rax
  40ded4:	je     40dee6 <__swc_fn_6b1cf01f_000050_ab8077df+0x1c6>
  40ded6:	mov    rcx,QWORD PTR [rax]
  40ded9:	mov    QWORD PTR [r14],rcx
  40dedc:	add    DWORD PTR [r14+0x28],0x1
  40dee1:	mov    r15,rax
  40dee4:	jmp    40df06 <__swc_fn_6b1cf01f_000050_ab8077df+0x1e6>
  40dee6:	mov    rax,QWORD PTR [r14+0x18]
  40deea:	cmp    QWORD PTR [r14+0x20],rax
  40deee:	jae    40df03 <__swc_fn_6b1cf01f_000050_ab8077df+0x1e3>
  40def0:	mov    r15,QWORD PTR [r14+0x20]
  40def4:	mov    eax,DWORD PTR [r14+0x2c]
  40def8:	add    QWORD PTR [r14+0x20],rax
  40defc:	add    DWORD PTR [r14+0x28],0x1
  40df01:	jmp    40df06 <__swc_fn_6b1cf01f_000050_ab8077df+0x1e6>
  40df03:	xor    r15d,r15d
  40df06:	test   r15,r15
  40df09:	jne    40df4e <__swc_fn_6b1cf01f_000050_ab8077df+0x22e>
  40df0b:	mov    rcx,r14
  40df0e:	call   407320 <__swc_fn_6b1cf01f_000006_a23dca5f>
  40df13:	test   al,al
  40df15:	je     40df4e <__swc_fn_6b1cf01f_000050_ab8077df+0x22e>
  40df17:	mov    rax,QWORD PTR [r14]
  40df1a:	test   rax,rax
  40df1d:	je     40df2c <__swc_fn_6b1cf01f_000050_ab8077df+0x20c>
  40df1f:	mov    rcx,QWORD PTR [rax]
  40df22:	mov    QWORD PTR [r14],rcx
  40df25:	add    DWORD PTR [r14+0x28],0x1
  40df2a:	jmp    40df4b <__swc_fn_6b1cf01f_000050_ab8077df+0x22b>
  40df2c:	mov    rax,QWORD PTR [r14+0x18]
  40df30:	cmp    QWORD PTR [r14+0x20],rax
  40df34:	jae    40df49 <__swc_fn_6b1cf01f_000050_ab8077df+0x229>
  40df36:	mov    rax,QWORD PTR [r14+0x20]
  40df3a:	mov    ecx,DWORD PTR [r14+0x2c]
  40df3e:	add    QWORD PTR [r14+0x20],rcx
  40df42:	add    DWORD PTR [r14+0x28],0x1
  40df47:	jmp    40df4b <__swc_fn_6b1cf01f_000050_ab8077df+0x22b>
  40df49:	xor    eax,eax
  40df4b:	mov    r15,rax
  40df4e:	test   r15,r15
  40df51:	je     40dea0 <__swc_fn_6b1cf01f_000050_ab8077df+0x180>
  40df57:	mov    rax,r15
  40df5a:	add    rsp,0x1f8
  40df61:	pop    r15
  40df63:	pop    r14
  40df65:	pop    r13
  40df67:	pop    r12
  40df69:	pop    rdi
  40df6a:	pop    rsi
  40df6b:	ret
  40df6c:	add    BYTE PTR [rax],al
	...

000000000040df70 <__swc_fn_6b1cf01f_000053_82546d94>:
  40df70:	push   rsi
  40df71:	push   rdi
  40df72:	push   r12
  40df74:	mov    rsi,rdx
  40df77:	mov    rax,rdx
  40df7a:	shr    rax,0xc
  40df7e:	movabs rdx,0x9e3779b97f4a7c15
  40df88:	imul   rax,rdx
  40df8c:	shr    rax,0x20
  40df90:	lea    rax,[rax*8+0x0]
  40df98:	shr    rax,0x20
  40df9c:	lea    rax,[rax*8+0x0]
  40dfa4:	lea    rax,[rcx+rax*8+0x40]
  40dfa9:	xor    edx,edx
  40dfab:	test   dl,dl
  40dfad:	lea    rdi,[rcx+0x8]
  40dfb1:	cmove  rdi,rax
  40dfb5:	xor    edx,edx
  40dfb7:	test   dl,dl
  40dfb9:	lea    r12,[rcx+0x30]
  40dfbd:	lea    rax,[rax+0x8]
  40dfc1:	cmove  r12,rax
  40dfc5:	mov    rcx,rdi
  40dfc8:	call   4098c0 <__swc_fn_6b1cf01f_000135_e3032dc2>
  40dfcd:	mov    QWORD PTR [rsi+0x30],0x0
  40dfd5:	mov    rax,QWORD PTR [r12]
  40dfd9:	mov    QWORD PTR [rsi+0x38],rax
  40dfdd:	test   rax,rax
  40dfe0:	je     40dfea <__swc_fn_6b1cf01f_000053_82546d94+0x7a>
  40dfe2:	mov    rax,QWORD PTR [rsi+0x38]
  40dfe6:	mov    QWORD PTR [rax+0x30],rsi
  40dfea:	mov    QWORD PTR [r12],rsi
  40dfee:	mov    rcx,rdi
  40dff1:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  40dff6:	pop    r12
  40dff8:	pop    rdi
  40dff9:	pop    rsi
  40dffa:	ret
  40dffb:	add    BYTE PTR [rax],al
  40dffd:	add    BYTE PTR [rax],al
	...

000000000040e000 <__swc_fn_6b1cf01f_000056_38b21f11>:
  40e000:	lea    rax,[rdx+rdx*4]
  40e004:	lea    rax,[rcx+rax*8+0x268]
  40e00c:	mov    rdx,QWORD PTR [rax+0x10]
  40e010:	sub    QWORD PTR [rcx+0x2a68],rdx
  40e017:	sub    QWORD PTR [rcx+0x2a70],0x1
  40e01f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40e026:	lea    rdx,[rdx+rdx*4]
  40e02a:	lea    rdx,[rcx+rdx*8+0x268]
  40e032:	vmovups xmm0,XMMWORD PTR [rdx]
  40e036:	vmovups XMMWORD PTR [rax],xmm0
  40e03a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40e03f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e044:	mov    rcx,QWORD PTR [rdx+0x20]
  40e048:	mov    QWORD PTR [rax+0x20],rcx
  40e04c:	ret
  40e04d:	add    BYTE PTR [rax],al
	...

000000000040e050 <__swc_fn_6b1cf01f_000059_3ca3ac64>:
  40e050:	push   rsi
  40e051:	push   rdi
  40e052:	push   r12
  40e054:	push   r13
  40e056:	sub    rsp,0x8
  40e05a:	mov    rsi,r8
  40e05d:	mov    rdi,rcx
  40e060:	mov    r12,rdx
  40e063:	xor    r13d,r13d
  40e066:	cs nop WORD PTR [rax+rax*1+0x0]
  40e070:	mov    eax,DWORD PTR [r12+0x730]
  40e078:	cmp    r13d,eax
  40e07b:	jae    40e0e1 <__swc_fn_6b1cf01f_000059_3ca3ac64+0x91>
  40e07d:	lea    rax,[r13+r13*4+0x0]
  40e082:	lea    rax,[r12+rax*8+0x738]
  40e08a:	mov    rdx,QWORD PTR [rax]
  40e08d:	mov    r8,QWORD PTR [rax+0x8]
  40e091:	mov    r9,QWORD PTR [rax+0x10]
  40e095:	cmp    QWORD PTR [rax+0x20],rsi
  40e099:	jb     40e0a0 <__swc_fn_6b1cf01f_000059_3ca3ac64+0x50>
  40e09b:	inc    r13d
  40e09e:	jmp    40e070 <__swc_fn_6b1cf01f_000059_3ca3ac64+0x20>
  40e0a0:	sub    DWORD PTR [r12+0x730],0x1
  40e0a9:	mov    ecx,DWORD PTR [r12+0x730]
  40e0b1:	lea    rcx,[rcx+rcx*4]
  40e0b5:	lea    rcx,[r12+rcx*8+0x738]
  40e0bd:	vmovups xmm0,XMMWORD PTR [rcx]
  40e0c1:	vmovups XMMWORD PTR [rax],xmm0
  40e0c5:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40e0ca:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e0cf:	mov    rcx,QWORD PTR [rcx+0x20]
  40e0d3:	mov    QWORD PTR [rax+0x20],rcx
  40e0d7:	mov    rcx,rdi
  40e0da:	call   407750 <__swc_fn_6b1cf01f_000039_40d1e569>
  40e0df:	jmp    40e070 <__swc_fn_6b1cf01f_000059_3ca3ac64+0x20>
  40e0e1:	add    rsp,0x8
  40e0e5:	pop    r13
  40e0e7:	pop    r12
  40e0e9:	pop    rdi
  40e0ea:	pop    rsi
  40e0eb:	ret
  40e0ec:	add    BYTE PTR [rax],al
	...

000000000040e0f0 <__swc_fn_6b1cf01f_000062_7e482c5f>:
  40e0f0:	push   rsi
  40e0f1:	push   rdi
  40e0f2:	push   r12
  40e0f4:	push   r13
  40e0f6:	push   r14
  40e0f8:	mov    rsi,rcx
  40e0fb:	mov    rdi,rdx
  40e0fe:	mov    r12,QWORD PTR [rdi]
  40e101:	mov    r13,QWORD PTR [rdi+0x18]
  40e105:	mov    rax,r12
  40e108:	add    rax,QWORD PTR [rdi+0x8]
  40e10c:	sub    rax,r13
  40e10f:	cmp    r8,rax
  40e112:	jbe    40e11d <__swc_fn_6b1cf01f_000062_7e482c5f+0x2d>
  40e114:	pop    r14
  40e116:	pop    r13
  40e118:	pop    r12
  40e11a:	pop    rdi
  40e11b:	pop    rsi
  40e11c:	ret
  40e11d:	lea    rax,[r13+r8*1+0x0]
  40e122:	sub    rax,r12
  40e125:	mov    ecx,0x1000
  40e12a:	test   ecx,ecx
  40e12c:	mov    edx,0x8
  40e131:	cmove  ecx,edx
  40e134:	dec    rcx
  40e137:	mov    rdx,0xffffffffffffffff
  40e13e:	sub    rdx,rcx
  40e141:	cmp    rax,rdx
  40e144:	jbe    40e14b <__swc_fn_6b1cf01f_000062_7e482c5f+0x5b>
  40e146:	xor    r14d,r14d
  40e149:	jmp    40e156 <__swc_fn_6b1cf01f_000062_7e482c5f+0x66>
  40e14b:	add    rax,rcx
  40e14e:	andn   rax,rcx,rax
  40e153:	mov    r14,rax
  40e156:	mov    rax,QWORD PTR [rdi+0x10]
  40e15a:	cmp    r14,rax
  40e15d:	ja     40e168 <__swc_fn_6b1cf01f_000062_7e482c5f+0x78>
  40e15f:	pop    r14
  40e161:	pop    r13
  40e163:	pop    r12
  40e165:	pop    rdi
  40e166:	pop    rsi
  40e167:	ret
  40e168:	mov    rax,r12
  40e16b:	add    rax,QWORD PTR [rdi+0x10]
  40e16f:	mov    rdx,r14
  40e172:	sub    rdx,QWORD PTR [rdi+0x10]
  40e176:	mov    rcx,rax
  40e179:	call   4072a0 <__swc_fn_6b1cf01f_000003_7ab4792e>
  40e17e:	test   al,al
  40e180:	jne    40e18b <__swc_fn_6b1cf01f_000062_7e482c5f+0x9b>
  40e182:	pop    r14
  40e184:	pop    r13
  40e186:	pop    r12
  40e188:	pop    rdi
  40e189:	pop    rsi
  40e18a:	ret
  40e18b:	add    r12,r14
  40e18e:	sub    r12,r13
  40e191:	mov    rcx,r12
  40e194:	sub    rcx,QWORD PTR [rdi+0x28]
  40e198:	mov    rdx,QWORD PTR [rsi+0x250]
  40e19f:	nop
  40e1a0:	lea    r8,[rdx+rcx*1]
  40e1a4:	mov    rax,rdx
  40e1a7:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40e1b0:	cmp    rax,rdx
  40e1b3:	je     40e1ba <__swc_fn_6b1cf01f_000062_7e482c5f+0xca>
  40e1b5:	mov    rdx,rax
  40e1b8:	jmp    40e1a0 <__swc_fn_6b1cf01f_000062_7e482c5f+0xb0>
  40e1ba:	mov    QWORD PTR [rdi+0x10],r14
  40e1be:	mov    QWORD PTR [rdi+0x28],r12
  40e1c2:	pop    r14
  40e1c4:	pop    r13
  40e1c6:	pop    r12
  40e1c8:	pop    rdi
  40e1c9:	pop    rsi
  40e1ca:	ret
  40e1cb:	add    BYTE PTR [rax],al
  40e1cd:	add    BYTE PTR [rax],al
	...

000000000040e1d0 <__swc_fn_6b1cf01f_000065_f9f4b610>:
  40e1d0:	push   rbx
  40e1d1:	push   rsi
  40e1d2:	push   rdi
  40e1d3:	push   r12
  40e1d5:	push   r13
  40e1d7:	sub    rsp,0xe0
  40e1de:	mov    rbx,rdx
  40e1e1:	mov    rsi,rcx
  40e1e4:	cmp    DWORD PTR [rbx+0x58],0x0
  40e1e8:	je     40e20c <__swc_fn_6b1cf01f_000065_f9f4b610+0x3c>
  40e1ea:	mov    eax,DWORD PTR [rbx+0x58]
  40e1ed:	sub    eax,0x1
  40e1f0:	test   DWORD PTR [rbx+0x58],eax
  40e1f3:	je     40e20c <__swc_fn_6b1cf01f_000065_f9f4b610+0x3c>
  40e1f5:	mov    QWORD PTR [rbx+0x40],0x0
  40e1fd:	add    rsp,0xe0
  40e204:	pop    r13
  40e206:	pop    r12
  40e208:	pop    rdi
  40e209:	pop    rsi
  40e20a:	pop    rbx
  40e20b:	ret
  40e20c:	mov    rax,QWORD PTR [rbx+0x40]
  40e210:	test   rax,rax
  40e213:	jne    40e22f <__swc_fn_6b1cf01f_000065_f9f4b610+0x5f>
  40e215:	mov    rcx,rsi
  40e218:	mov    rdx,rbx
  40e21b:	call   40b7d0 <__swc_fn_6b1cf01f_000064_b0d63361>
  40e220:	add    rsp,0xe0
  40e227:	pop    r13
  40e229:	pop    r12
  40e22b:	pop    rdi
  40e22c:	pop    rsi
  40e22d:	pop    rbx
  40e22e:	ret
  40e22f:	cmp    QWORD PTR [rbx+0x48],0x0
  40e234:	jne    40e250 <__swc_fn_6b1cf01f_000065_f9f4b610+0x80>
  40e236:	mov    rcx,rsi
  40e239:	mov    rdx,rbx
  40e23c:	call   407f90 <__swc_fn_6b1cf01f_000066_254b71af>
  40e241:	add    rsp,0xe0
  40e248:	pop    r13
  40e24a:	pop    r12
  40e24c:	pop    rdi
  40e24d:	pop    rsi
  40e24e:	pop    rbx
  40e24f:	ret
  40e250:	mov    rdi,QWORD PTR [rbx+0x40]
  40e254:	lea    rax,[rip+0x15e15]        # 424070 <__swc_bss_base_6b1cf01f+0x30>
  40e25b:	mov    rcx,rdi
  40e25e:	sub    rcx,QWORD PTR [rax+0x8]
  40e262:	mov    rax,QWORD PTR [rip+0x15e17]        # 424080 <__swc_bss_base_6b1cf01f+0x40>
  40e269:	cmp    rcx,rax
  40e26c:	jae    40e298 <__swc_fn_6b1cf01f_000065_f9f4b610+0xc8>
  40e26e:	mov    rax,rdi
  40e271:	and    rax,0xffffffffffc00000
  40e278:	mov    rcx,rdi
  40e27b:	shr    rcx,0x10
  40e27f:	and    ecx,0x3f
  40e282:	mov    edx,DWORD PTR [rax+0x28]
  40e285:	shrx   ecx,ecx,edx
  40e28a:	shl    rcx,0x4
  40e28e:	lea    r12,[rax+rcx*8+0x80]
  40e296:	jmp    40e2a3 <__swc_fn_6b1cf01f_000065_f9f4b610+0xd3>
  40e298:	mov    rcx,rdi
  40e29b:	call   40a850 <__swc_fn_6b1cf01f_000022_3a2e2048>
  40e2a0:	mov    r12,rax
  40e2a3:	test   r12,r12
  40e2a6:	je     40e2b5 <__swc_fn_6b1cf01f_000065_f9f4b610+0xe5>
  40e2a8:	mov    eax,DWORD PTR [r12+0x2c]
  40e2ad:	mov    r9d,eax
  40e2b0:	mov    r13,rax
  40e2b3:	jmp    40e334 <__swc_fn_6b1cf01f_000065_f9f4b610+0x164>
  40e2b5:	mov    rcx,rsi
  40e2b8:	mov    rdx,rdi
  40e2bb:	call   40ae60 <__swc_fn_6b1cf01f_000052_c7484fb0>
  40e2c0:	mov    rcx,QWORD PTR [rax+0x28]
  40e2c4:	mov    r9,rcx
  40e2c7:	mov    rdx,QWORD PTR [rax+0x20]
  40e2cb:	mov    r13,rdx
  40e2ce:	cmp    QWORD PTR [rbx+0x48],rcx
  40e2d2:	jbe    40e30b <__swc_fn_6b1cf01f_000065_f9f4b610+0x13b>
  40e2d4:	mov    ecx,DWORD PTR [rax+0x48]
  40e2d7:	cmp    DWORD PTR [rbx+0x58],ecx
  40e2da:	ja     40e30b <__swc_fn_6b1cf01f_000065_f9f4b610+0x13b>
  40e2dc:	mov    rcx,rsi
  40e2df:	mov    rdx,rax
  40e2e2:	mov    r8,QWORD PTR [rbx+0x48]
  40e2e6:	mov    QWORD PTR [rsp+0xc8],r9
  40e2ee:	mov    QWORD PTR [rsp+0xd0],rax
  40e2f6:	call   40e0f0 <__swc_fn_6b1cf01f_000062_7e482c5f>
  40e2fb:	mov    r9,QWORD PTR [rsp+0xc8]
  40e303:	mov    rax,QWORD PTR [rsp+0xd0]
  40e30b:	mov    rcx,QWORD PTR [rax+0x28]
  40e30f:	cmp    QWORD PTR [rbx+0x48],rcx
  40e313:	ja     40e334 <__swc_fn_6b1cf01f_000065_f9f4b610+0x164>
  40e315:	mov    ecx,DWORD PTR [rax+0x48]
  40e318:	cmp    DWORD PTR [rbx+0x58],ecx
  40e31b:	ja     40e334 <__swc_fn_6b1cf01f_000065_f9f4b610+0x164>
  40e31d:	mov    rcx,QWORD PTR [rbx+0x48]
  40e321:	mov    QWORD PTR [rax+0x20],rcx
  40e325:	add    rsp,0xe0
  40e32c:	pop    r13
  40e32e:	pop    r12
  40e330:	pop    rdi
  40e331:	pop    rsi
  40e332:	pop    rbx
  40e333:	ret
  40e334:	test   r12,r12
  40e337:	je     40e369 <__swc_fn_6b1cf01f_000065_f9f4b610+0x199>
  40e339:	cmp    QWORD PTR [rbx+0x48],r9
  40e33d:	ja     40e369 <__swc_fn_6b1cf01f_000065_f9f4b610+0x199>
  40e33f:	cmp    DWORD PTR [rbx+0x58],0x40
  40e343:	ja     40e369 <__swc_fn_6b1cf01f_000065_f9f4b610+0x199>
  40e345:	cmp    DWORD PTR [rbx+0x58],0x0
  40e349:	je     40e356 <__swc_fn_6b1cf01f_000065_f9f4b610+0x186>
  40e34b:	mov    ecx,DWORD PTR [rbx+0x58]
  40e34e:	dec    rcx
  40e351:	test   rdi,rcx
  40e354:	jne    40e369 <__swc_fn_6b1cf01f_000065_f9f4b610+0x199>
  40e356:	mov    QWORD PTR [rbx+0x40],rdi
  40e35a:	add    rsp,0xe0
  40e361:	pop    r13
  40e363:	pop    r12
  40e365:	pop    rdi
  40e366:	pop    rsi
  40e367:	pop    rbx
  40e368:	ret
  40e369:	vmovups xmm0,XMMWORD PTR [rbx]
  40e36d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e373:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40e378:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e37e:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40e383:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e389:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40e38e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40e394:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40e399:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40e39f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40e3a4:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40e3aa:	mov    QWORD PTR [rsp+0x48],0x0
  40e3b3:	mov    rcx,rsi
  40e3b6:	lea    rdx,[rsp+0x8]
  40e3bb:	call   40b7d0 <__swc_fn_6b1cf01f_000064_b0d63361>
  40e3c0:	mov    rax,QWORD PTR [rsp+0x48]
  40e3c5:	test   rax,rax
  40e3c8:	jne    40e3e1 <__swc_fn_6b1cf01f_000065_f9f4b610+0x211>
  40e3ca:	mov    QWORD PTR [rbx+0x40],0x0
  40e3d2:	add    rsp,0xe0
  40e3d9:	pop    r13
  40e3db:	pop    r12
  40e3dd:	pop    rdi
  40e3de:	pop    rsi
  40e3df:	pop    rbx
  40e3e0:	ret
  40e3e1:	mov    rax,QWORD PTR [rbx+0x48]
  40e3e5:	cmp    r13,rax
  40e3e8:	cmovbe rax,r13
  40e3ec:	mov    rcx,QWORD PTR [rsp+0x48]
  40e3f1:	mov    rdx,rdi
  40e3f4:	mov    r8,rax
  40e3f7:	call   409100 <__swc_fn_6b1cf01f_000105_6fd80914>
  40e3fc:	vmovups xmm0,XMMWORD PTR [rbx]
  40e400:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40e406:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40e40b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40e411:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40e416:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40e41f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40e424:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40e42d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40e432:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40e43b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40e440:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40e449:	mov    QWORD PTR [rsp+0xa8],rdi
  40e451:	mov    rcx,rsi
  40e454:	lea    rdx,[rsp+0x68]
  40e459:	call   407f90 <__swc_fn_6b1cf01f_000066_254b71af>
  40e45e:	mov    rax,QWORD PTR [rsp+0x48]
  40e463:	mov    QWORD PTR [rbx+0x40],rax
  40e467:	add    rsp,0xe0
  40e46e:	pop    r13
  40e470:	pop    r12
  40e472:	pop    rdi
  40e473:	pop    rsi
  40e474:	pop    rbx
  40e475:	ret
	...

000000000040e480 <__swc_fn_6b1cf01f_000068_7d4c42bf>:
  40e480:	push   r12
  40e482:	push   rdi
  40e483:	push   rsi
  40e484:	push   r13
  40e486:	push   r14
  40e488:	sub    rsp,0x190
  40e48f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40e498:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40e4a1:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40e4aa:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40e4b3:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40e4bc:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40e4c5:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40e4ce:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40e4d7:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40e4e0:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40e4e9:	mov    r12,rcx
  40e4ec:	lea    rax,[rip+0x13b0d]        # 422000 <__swc_data_base_6b1cf01f>
  40e4f3:	mov    rax,QWORD PTR [rax]
  40e4f6:	cmp    rax,0xffffffffffffffff
  40e4fa:	je     40e509 <__swc_fn_6b1cf01f_000068_7d4c42bf+0x89>
  40e4fc:	mov    eax,eax
  40e4fe:	mov    edi,eax
  40e500:	xor    eax,eax
  40e502:	call   407000 <pthread_getspecific@plt>
  40e507:	jmp    40e50b <__swc_fn_6b1cf01f_000068_7d4c42bf+0x8b>
  40e509:	xor    eax,eax
  40e50b:	test   rax,rax
  40e50e:	jne    40e51d <__swc_fn_6b1cf01f_000068_7d4c42bf+0x9d>
  40e510:	call   40a920 <__swc_fn_6b1cf01f_000031_90860ff2>
  40e515:	mov    rcx,rax
  40e518:	call   40fc80 <__swc_fn_6b1cf01f_000128_41c3251c>
  40e51d:	test   rax,rax
  40e520:	je     40e546 <__swc_fn_6b1cf01f_000068_7d4c42bf+0xc6>
  40e522:	cmp    QWORD PTR [rax],r12
  40e525:	jne    40e546 <__swc_fn_6b1cf01f_000068_7d4c42bf+0xc6>
  40e527:	xor    ecx,ecx
  40e529:	mov    QWORD PTR [rsp+0xc8],rax
  40e531:	call   407720 <__swc_fn_6b1cf01f_000033_7ca1566d>
  40e536:	mov    rdx,QWORD PTR [rsp+0xc8]
  40e53e:	mov    rcx,r12
  40e541:	call   407840 <__swc_fn_6b1cf01f_000042_bab03645>
  40e546:	lea    rsi,[r12+0x10]
  40e54b:	mov    rcx,rsi
  40e54e:	call   4098c0 <__swc_fn_6b1cf01f_000135_e3032dc2>
  40e553:	mov    rdi,QWORD PTR [r12+0x20]
  40e558:	test   rdi,rdi
  40e55b:	je     40e59e <__swc_fn_6b1cf01f_000068_7d4c42bf+0x11e>
  40e55d:	nop    DWORD PTR [rax]
  40e560:	mov    rcx,r12
  40e563:	mov    rdx,rdi
  40e566:	call   40aae0 <__swc_fn_6b1cf01f_000043_957e4917>
  40e56b:	mov    rcx,r12
  40e56e:	mov    rdx,rdi
  40e571:	mov    r8,0xffffffffffffffff
  40e578:	call   40e050 <__swc_fn_6b1cf01f_000059_3ca3ac64>
  40e57d:	mov    rcx,r12
  40e580:	mov    rdx,rdi
  40e583:	mov    r8d,0x9b8
  40e589:	mov    r9d,0x9b8
  40e58f:	call   407750 <__swc_fn_6b1cf01f_000039_40d1e569>
  40e594:	mov    rdi,QWORD PTR [r12+0x20]
  40e599:	test   rdi,rdi
  40e59c:	jne    40e560 <__swc_fn_6b1cf01f_000068_7d4c42bf+0xe0>
  40e59e:	xor    eax,eax
  40e5a0:	xchg   QWORD PTR [r12+0x2a80],rax
  40e5a8:	test   rax,rax
  40e5ab:	je     40e5d1 <__swc_fn_6b1cf01f_000068_7d4c42bf+0x151>
  40e5ad:	cs nop WORD PTR [rax+rax*1+0x0]
  40e5b7:	nop    WORD PTR [rax+rax*1+0x0]
  40e5c0:	mov    rcx,rax
  40e5c3:	mov    rax,QWORD PTR [rax+0x78]
  40e5c7:	xor    edx,edx
  40e5c9:	xchg   DWORD PTR [rcx+0x70],edx
  40e5cc:	test   rax,rax
  40e5cf:	jne    40e5c0 <__swc_fn_6b1cf01f_000068_7d4c42bf+0x140>
  40e5d1:	mov    rax,QWORD PTR [r12+0x18]
  40e5d6:	mov    rdi,rax
  40e5d9:	test   rdi,rdi
  40e5dc:	je     40e671 <__swc_fn_6b1cf01f_000068_7d4c42bf+0x1f1>
  40e5e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40e5ec:	nop    DWORD PTR [rax+0x0]
  40e5f0:	mov    rax,QWORD PTR [rdi+0x10]
  40e5f4:	mov    r8d,DWORD PTR [rdi+0x2c]
  40e5f8:	xor    r9d,r9d
  40e5fb:	test   r8,r8
  40e5fe:	jbe    40e65d <__swc_fn_6b1cf01f_000068_7d4c42bf+0x1dd>
  40e600:	mov    ecx,r9d
  40e603:	shl    rcx,0x4
  40e607:	lea    rdx,[rdi+rcx*8+0x80]
  40e60f:	cmp    BYTE PTR [rdx+0x3b],0x0
  40e613:	je     40e654 <__swc_fn_6b1cf01f_000068_7d4c42bf+0x1d4>
  40e615:	mov    DWORD PTR [rdx+0x28],0x0
  40e61c:	mov    rcx,rdi
  40e61f:	mov    QWORD PTR [rsp+0xd0],rax
  40e627:	mov    QWORD PTR [rsp+0xd8],r8
  40e62f:	mov    QWORD PTR [rsp+0xe0],r9
  40e637:	call   40d780 <__swc_fn_6b1cf01f_000014_afb279e2>
  40e63c:	mov    rax,QWORD PTR [rsp+0xd0]
  40e644:	mov    r8,QWORD PTR [rsp+0xd8]
  40e64c:	mov    r9,QWORD PTR [rsp+0xe0]
  40e654:	add    r9,0x1
  40e658:	cmp    r9,r8
  40e65b:	jb     40e600 <__swc_fn_6b1cf01f_000068_7d4c42bf+0x180>
  40e65d:	mov    rcx,rdi
  40e660:	mov    rdi,rax
  40e663:	call   407630 <__swc_fn_6b1cf01f_000021_491ac000>
  40e668:	test   rdi,rdi
  40e66b:	jne    40e5f0 <__swc_fn_6b1cf01f_000068_7d4c42bf+0x170>
  40e671:	mov    QWORD PTR [r12+0x18],0x0
  40e67a:	mov    QWORD PTR [r12+0x28],0x0
  40e683:	mov    rcx,rsi
  40e686:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  40e68b:	mov    esi,0x8
  40e690:	xor    edi,edi
  40e692:	test   rsi,rsi
  40e695:	je     40e6f2 <__swc_fn_6b1cf01f_000068_7d4c42bf+0x272>
  40e69b:	nop    DWORD PTR [rax+rax*1+0x0]
  40e6a0:	lea    r13,[rdi*8+0x0]
  40e6a8:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40e6ad:	test   r14,r14
  40e6b0:	je     40e6e8 <__swc_fn_6b1cf01f_000068_7d4c42bf+0x268>
  40e6b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40e6bc:	nop    DWORD PTR [rax+0x0]
  40e6c0:	mov    rcx,r12
  40e6c3:	mov    rdx,r14
  40e6c6:	call   407df0 <__swc_fn_6b1cf01f_000054_ae20ea33>
  40e6cb:	mov    rcx,r12
  40e6ce:	mov    rdx,QWORD PTR [r14]
  40e6d1:	mov    r8,QWORD PTR [r14+0x8]
  40e6d5:	mov    r9,QWORD PTR [r14+0x10]
  40e6d9:	call   407750 <__swc_fn_6b1cf01f_000039_40d1e569>
  40e6de:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40e6e3:	test   r14,r14
  40e6e6:	jne    40e6c0 <__swc_fn_6b1cf01f_000068_7d4c42bf+0x240>
  40e6e8:	add    rdi,0x1
  40e6ec:	sub    rsi,0x1
  40e6f0:	jne    40e6a0 <__swc_fn_6b1cf01f_000068_7d4c42bf+0x220>
  40e6f2:	mov    rcx,r12
  40e6f5:	call   407ec0 <__swc_fn_6b1cf01f_000060_e6407a0a>
  40e6fa:	lea    rcx,[r12+0x250]
  40e702:	mov    rdx,QWORD PTR [rcx]
  40e705:	mov    r8,QWORD PTR [r12+0x250]
  40e70d:	nop    DWORD PTR [rax]
  40e710:	mov    r9,r8
  40e713:	sub    r9,rdx
  40e716:	mov    rax,r8
  40e719:	lock cmpxchg QWORD PTR [rcx],r9
  40e71e:	cmp    rax,r8
  40e721:	je     40e728 <__swc_fn_6b1cf01f_000068_7d4c42bf+0x2a8>
  40e723:	mov    r8,rax
  40e726:	jmp    40e710 <__swc_fn_6b1cf01f_000068_7d4c42bf+0x290>
  40e728:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40e731:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40e73a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40e743:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40e74c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40e755:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40e75e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40e767:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40e770:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40e779:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40e782:	add    rsp,0x190
  40e789:	pop    r14
  40e78b:	pop    r13
  40e78d:	pop    rsi
  40e78e:	pop    rdi
  40e78f:	pop    r12
  40e791:	ret
	...

000000000040e7a0 <__swc_fn_6b1cf01f_000071_0d1ef36f>:
  40e7a0:	sub    rsp,0x8
  40e7a4:	mov    QWORD PTR [rdx+0x40],0x0
  40e7ac:	call   40b7d0 <__swc_fn_6b1cf01f_000064_b0d63361>
  40e7b1:	add    rsp,0x8
  40e7b5:	ret
	...

000000000040e7c0 <__swc_fn_6b1cf01f_000074_518516c2>:
  40e7c0:	sub    rsp,0x8
  40e7c4:	call   407f90 <__swc_fn_6b1cf01f_000066_254b71af>
  40e7c9:	add    rsp,0x8
  40e7cd:	ret
	...

000000000040e7d0 <__swc_fn_6b1cf01f_000077_8b8614a7>:
  40e7d0:	push   rbx
  40e7d1:	push   rsi
  40e7d2:	push   rdi
  40e7d3:	push   r12
  40e7d5:	push   r13
  40e7d7:	push   r14
  40e7d9:	push   r15
  40e7db:	sub    rsp,0x20
  40e7df:	mov    rbx,r11
  40e7e2:	mov    rsi,rcx
  40e7e5:	mov    rdi,rdx
  40e7e8:	mov    r12,r8
  40e7eb:	mov    r13,r9
  40e7ee:	mov    r14,r10
  40e7f1:	mov    rcx,QWORD PTR [rip+0x18548]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40e7f8:	test   rcx,rcx
  40e7fb:	jne    40e80d <__swc_fn_6b1cf01f_000077_8b8614a7+0x3d>
  40e7fd:	call   40a1d0 <__swc_fn_6b1cf01f_000165_cf398896>
  40e802:	lea    rcx,[rax+0x1]
  40e806:	mov    QWORD PTR [rip+0x18533],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40e80d:	dec    rcx
  40e810:	call   411740 <__swc_fn_6b1cf01f_000167_fce60b2b>
  40e815:	mov    r15,rax
  40e818:	lea    r11,[rip+0x15a21]        # 424240 <__swc_bss_base_6b1cf01f+0x200>
  40e81f:	mov    rcx,r11
  40e822:	call   407740 <__swc_fn_6b1cf01f_000036_8d895ba1>
  40e827:	test   al,al
  40e829:	jne    40e83a <__swc_fn_6b1cf01f_000077_8b8614a7+0x6a>
  40e82b:	mov    rcx,r11
  40e82e:	call   40a980 <__swc_fn_6b1cf01f_000034_25f19556>
  40e833:	lea    r11,[rip+0x15a06]        # 424240 <__swc_bss_base_6b1cf01f+0x200>
  40e83a:	mov    rcx,r11
  40e83d:	mov    rdx,rsi
  40e840:	mov    r8,rdi
  40e843:	mov    r9,r12
  40e846:	mov    r10,r13
  40e849:	mov    rsi,r11
  40e84c:	mov    r11,r14
  40e84f:	call   40daf0 <__swc_fn_6b1cf01f_000035_95622a2b>
  40e854:	test   bl,bl
  40e856:	je     40e87d <__swc_fn_6b1cf01f_000077_8b8614a7+0xad>
  40e858:	mov    QWORD PTR [rsp+0x8],rsi
  40e85d:	lea    rax,[rip+0x48ec]        # 413150 <__swc_rdata_base_6b1cf01f+0x40>
  40e864:	mov    QWORD PTR [rsp+0x10],rax
  40e869:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e86f:	vmovups XMMWORD PTR [r15],xmm0
  40e874:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40e87d:	mov    rax,rsi
  40e880:	add    rsp,0x20
  40e884:	pop    r15
  40e886:	pop    r14
  40e888:	pop    r13
  40e88a:	pop    r12
  40e88c:	pop    rdi
  40e88d:	pop    rsi
  40e88e:	pop    rbx
  40e88f:	ret

000000000040e890 <__swc_fn_6b1cf01f_000080_c1514492>:
  40e890:	sub    rsp,0x8
  40e894:	mov    rax,rcx
  40e897:	test   rcx,rcx
  40e89a:	jne    40e8a1 <__swc_fn_6b1cf01f_000080_c1514492+0x11>
  40e89c:	add    rsp,0x8
  40e8a0:	ret
  40e8a1:	lea    rcx,[rax-0x10]
  40e8a5:	mov    rax,QWORD PTR [rax-0x10]
  40e8a9:	mov    rdx,rax
  40e8ac:	call   40f920 <__swc_fn_6b1cf01f_000113_49b378a9>
  40e8b1:	add    rsp,0x8
  40e8b5:	ret
	...

000000000040e8c0 <__swc_fn_6b1cf01f_000083_31b501f2>:
  40e8c0:	sub    rsp,0x8
  40e8c4:	xor    r11d,r11d
  40e8c7:	call   408250 <__swc_fn_6b1cf01f_000084_ddf2b8a1>
  40e8cc:	add    rsp,0x8
  40e8d0:	ret
	...

000000000040e8e0 <__swc_fn_6b1cf01f_000086_c45095aa>:
  40e8e0:	push   rsi
  40e8e1:	push   rdi
  40e8e2:	push   r12
  40e8e4:	push   r13
  40e8e6:	push   r14
  40e8e8:	push   r15
  40e8ea:	sub    rsp,0x68
  40e8ee:	mov    rsi,r9
  40e8f1:	mov    rdi,rcx
  40e8f4:	mov    r12,rdx
  40e8f7:	mov    r13,r8
  40e8fa:	cmp    r8,r9
  40e8fd:	jne    40e925 <__swc_fn_6b1cf01f_000086_c45095aa+0x45>
  40e8ff:	mov    rcx,rdi
  40e902:	mov    rdx,r12
  40e905:	xor    r8d,r8d
  40e908:	call   4085a0 <__swc_fn_6b1cf01f_000090_a2d50c23>
  40e90d:	test   al,al
  40e90f:	je     40e925 <__swc_fn_6b1cf01f_000086_c45095aa+0x45>
  40e911:	mov    eax,0x1
  40e916:	add    rsp,0x68
  40e91a:	pop    r15
  40e91c:	pop    r14
  40e91e:	pop    r13
  40e920:	pop    r12
  40e922:	pop    rdi
  40e923:	pop    rsi
  40e924:	ret
  40e925:	cmp    BYTE PTR [r12+0x2c],0xe
  40e92b:	je     40e93e <__swc_fn_6b1cf01f_000086_c45095aa+0x5e>
  40e92d:	xor    eax,eax
  40e92f:	add    rsp,0x68
  40e933:	pop    r15
  40e935:	pop    r14
  40e937:	pop    r13
  40e939:	pop    r12
  40e93b:	pop    rdi
  40e93c:	pop    rsi
  40e93d:	ret
  40e93e:	mov    r14,QWORD PTR [r12+0x98]
  40e946:	mov    rax,QWORD PTR [r12+0xa0]
  40e94e:	mov    r12,rax
  40e951:	xor    r15d,r15d
  40e954:	test   r12,r12
  40e957:	je     40e9bf <__swc_fn_6b1cf01f_000086_c45095aa+0xdf>
  40e959:	nop    DWORD PTR [rax+0x0]
  40e960:	mov    QWORD PTR [rsp+0x58],r12
  40e965:	lea    r12,[r15*8+0x0]
  40e96d:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40e972:	mov    rcx,rax
  40e975:	call   40bf60 <__swc_fn_6b1cf01f_000082_754dcd57>
  40e97a:	cmp    BYTE PTR [rax+0x2c],0xe
  40e97e:	jne    40e9b0 <__swc_fn_6b1cf01f_000086_c45095aa+0xd0>
  40e980:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40e985:	lea    r8,[r13+rcx*1+0x0]
  40e98a:	mov    rcx,rdi
  40e98d:	mov    rdx,rax
  40e990:	mov    r9,rsi
  40e993:	call   40e8e0 <__swc_fn_6b1cf01f_000086_c45095aa>
  40e998:	test   al,al
  40e99a:	je     40e9b0 <__swc_fn_6b1cf01f_000086_c45095aa+0xd0>
  40e99c:	mov    eax,0x1
  40e9a1:	add    rsp,0x68
  40e9a5:	pop    r15
  40e9a7:	pop    r14
  40e9a9:	pop    r13
  40e9ab:	pop    r12
  40e9ad:	pop    rdi
  40e9ae:	pop    rsi
  40e9af:	ret
  40e9b0:	add    r15,0x1
  40e9b4:	mov    r12,QWORD PTR [rsp+0x58]
  40e9b9:	sub    r12,0x1
  40e9bd:	jne    40e960 <__swc_fn_6b1cf01f_000086_c45095aa+0x80>
  40e9bf:	xor    eax,eax
  40e9c1:	add    rsp,0x68
  40e9c5:	pop    r15
  40e9c7:	pop    r14
  40e9c9:	pop    r13
  40e9cb:	pop    r12
  40e9cd:	pop    rdi
  40e9ce:	pop    rsi
  40e9cf:	ret

000000000040e9d0 <__swc_fn_6b1cf01f_000089_386582f3>:
  40e9d0:	push   rbp
  40e9d1:	push   rbx
  40e9d2:	push   rsi
  40e9d3:	push   rdi
  40e9d4:	push   r12
  40e9d6:	push   r13
  40e9d8:	push   r14
  40e9da:	push   r15
  40e9dc:	sub    rsp,0x38
  40e9e0:	mov    rbp,rsp
  40e9e3:	mov    rbx,r11
  40e9e6:	mov    rsi,rdx
  40e9e9:	mov    rdi,r8
  40e9ec:	mov    r12,r9
  40e9ef:	mov    QWORD PTR [rsp+0x18],r9
  40e9f4:	mov    r13,r10
  40e9f7:	movzx  r14d,BYTE PTR [rbp+0x80]
  40e9ff:	movzx  r15d,BYTE PTR [rbp+0x88]
  40ea07:	test   r11,r11
  40ea0a:	je     40ea10 <__swc_fn_6b1cf01f_000089_386582f3+0x40>
  40ea0c:	xor    eax,eax
  40ea0e:	mov    BYTE PTR [rbx],al
  40ea10:	test   r12,r12
  40ea13:	je     40ea1e <__swc_fn_6b1cf01f_000089_386582f3+0x4e>
  40ea15:	mov    QWORD PTR [r12+0x8],0x0
  40ea1e:	test   rcx,rcx
  40ea21:	je     40ea28 <__swc_fn_6b1cf01f_000089_386582f3+0x58>
  40ea23:	test   rsi,rsi
  40ea26:	jne    40ea3b <__swc_fn_6b1cf01f_000089_386582f3+0x6b>
  40ea28:	xor    eax,eax
  40ea2a:	add    rsp,0x38
  40ea2e:	pop    r15
  40ea30:	pop    r14
  40ea32:	pop    r13
  40ea34:	pop    r12
  40ea36:	pop    rdi
  40ea37:	pop    rsi
  40ea38:	pop    rbx
  40ea39:	pop    rbp
  40ea3a:	ret
  40ea3b:	call   40bf60 <__swc_fn_6b1cf01f_000082_754dcd57>
  40ea40:	mov    r12,rax
  40ea43:	mov    al,r15b
  40ea46:	test   r15b,r15b
  40ea49:	jne    40ea59 <__swc_fn_6b1cf01f_000089_386582f3+0x89>
  40ea4b:	mov    eax,DWORD PTR [r12+0x28]
  40ea50:	and    eax,0x10000
  40ea56:	setne  al
  40ea59:	lea    r15,[rsp+0x8]
  40ea5e:	mov    QWORD PTR [rsp+0x20],r15
  40ea63:	rex mov BYTE PTR [rsp+0x8],al
  40ea68:	test   DWORD PTR [rsi+0x28],0x400000
  40ea6f:	je     40eaa7 <__swc_fn_6b1cf01f_000089_386582f3+0xd7>
  40ea71:	test   rsi,rsi
  40ea74:	je     40ea94 <__swc_fn_6b1cf01f_000089_386582f3+0xc4>
  40ea76:	mov    rax,QWORD PTR [rsi+0x38]
  40ea7a:	cmp    QWORD PTR [rax+0x10],rsi
  40ea7e:	jne    40ea94 <__swc_fn_6b1cf01f_000089_386582f3+0xc4>
  40ea80:	rex mov al,BYTE PTR [rsp+0x8]
  40ea85:	test   al,al
  40ea87:	sete   al
  40ea8a:	test   r14b,r14b
  40ea8d:	sete   cl
  40ea90:	test   al,cl
  40ea92:	je     40eaa7 <__swc_fn_6b1cf01f_000089_386582f3+0xd7>
  40ea94:	xor    eax,eax
  40ea96:	add    rsp,0x38
  40ea9a:	pop    r15
  40ea9c:	pop    r14
  40ea9e:	pop    r13
  40eaa0:	pop    r12
  40eaa2:	pop    rdi
  40eaa3:	pop    rsi
  40eaa4:	pop    rbx
  40eaa5:	pop    rbp
  40eaa6:	ret
  40eaa7:	mov    r15,r12
  40eaaa:	test   r14b,r14b
  40eaad:	jne    40eac4 <__swc_fn_6b1cf01f_000089_386582f3+0xf4>
  40eaaf:	cmp    BYTE PTR [r12+0x2c],0x6
  40eab5:	jne    40eac4 <__swc_fn_6b1cf01f_000089_386582f3+0xf4>
  40eab7:	mov    rcx,QWORD PTR [r12+0x40]
  40eabc:	call   40bf60 <__swc_fn_6b1cf01f_000082_754dcd57>
  40eac1:	mov    r15,rax
  40eac4:	test   r14b,r14b
  40eac7:	je     40eacd <__swc_fn_6b1cf01f_000089_386582f3+0xfd>
  40eac9:	mov    r15,QWORD PTR [r15+0x30]
  40eacd:	mov    rcx,rsi
  40ead0:	call   40bf60 <__swc_fn_6b1cf01f_000082_754dcd57>
  40ead5:	mov    rsi,rax
  40ead8:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40eadd:	je     40eb14 <__swc_fn_6b1cf01f_000089_386582f3+0x144>
  40eadf:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40eae4:	je     40eb14 <__swc_fn_6b1cf01f_000089_386582f3+0x144>
  40eae6:	mov    eax,DWORD PTR [rsi+0x28]
  40eae9:	and    eax,0x10000
  40eaef:	je     40eb14 <__swc_fn_6b1cf01f_000089_386582f3+0x144>
  40eaf1:	rex mov al,BYTE PTR [rsp+0x8]
  40eaf6:	test   al,al
  40eaf8:	jne    40eb0d <__swc_fn_6b1cf01f_000089_386582f3+0x13d>
  40eafa:	xor    eax,eax
  40eafc:	add    rsp,0x38
  40eb00:	pop    r15
  40eb02:	pop    r14
  40eb04:	pop    r13
  40eb06:	pop    r12
  40eb08:	pop    rdi
  40eb09:	pop    rsi
  40eb0a:	pop    rbx
  40eb0b:	pop    rbp
  40eb0c:	ret
  40eb0d:	mov    rax,QWORD PTR [rsi+0x30]
  40eb11:	mov    rsi,rax
  40eb14:	mov    r14b,r13b
  40eb17:	test   rbx,rbx
  40eb1a:	je     40eb50 <__swc_fn_6b1cf01f_000089_386582f3+0x180>
  40eb1c:	cmp    BYTE PTR [r12+0x2c],0x6
  40eb22:	jne    40eb50 <__swc_fn_6b1cf01f_000089_386582f3+0x180>
  40eb24:	lea    rdx,[rip+0x4655]        # 413180 <__swc_rdata_base_6b1cf01f+0x70>
  40eb2b:	mov    rcx,rsi
  40eb2e:	xor    r8d,r8d
  40eb31:	call   4085a0 <__swc_fn_6b1cf01f_000090_a2d50c23>
  40eb36:	test   al,al
  40eb38:	je     40eb50 <__swc_fn_6b1cf01f_000089_386582f3+0x180>
  40eb3a:	mov    BYTE PTR [rbx],0x1
  40eb3d:	xor    eax,eax
  40eb3f:	add    rsp,0x38
  40eb43:	pop    r15
  40eb45:	pop    r14
  40eb47:	pop    r13
  40eb49:	pop    r12
  40eb4b:	pop    rdi
  40eb4c:	pop    rsi
  40eb4d:	pop    rbx
  40eb4e:	pop    rbp
  40eb4f:	ret
  40eb50:	test   rdi,rdi
  40eb53:	jne    40eb6d <__swc_fn_6b1cf01f_000089_386582f3+0x19d>
  40eb55:	test   r13b,r13b
  40eb58:	jne    40eb6d <__swc_fn_6b1cf01f_000089_386582f3+0x19d>
  40eb5a:	xor    eax,eax
  40eb5c:	add    rsp,0x38
  40eb60:	pop    r15
  40eb62:	pop    r14
  40eb64:	pop    r13
  40eb66:	pop    r12
  40eb68:	pop    rdi
  40eb69:	pop    rsi
  40eb6a:	pop    rbx
  40eb6b:	pop    rbp
  40eb6c:	ret
  40eb6d:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40eb72:	jne    40ec28 <__swc_fn_6b1cf01f_000089_386582f3+0x258>
  40eb78:	mov    rcx,r15
  40eb7b:	mov    rdx,rsi
  40eb7e:	xor    r8d,r8d
  40eb81:	call   4085a0 <__swc_fn_6b1cf01f_000090_a2d50c23>
  40eb86:	test   al,al
  40eb88:	jne    40ec28 <__swc_fn_6b1cf01f_000089_386582f3+0x258>
  40eb8e:	test   DWORD PTR [rsi+0x28],0x10000
  40eb95:	je     40ebb3 <__swc_fn_6b1cf01f_000089_386582f3+0x1e3>
  40eb97:	rex mov al,BYTE PTR [rsp+0x8]
  40eb9c:	test   al,al
  40eb9e:	jne    40ebb3 <__swc_fn_6b1cf01f_000089_386582f3+0x1e3>
  40eba0:	xor    eax,eax
  40eba2:	add    rsp,0x38
  40eba6:	pop    r15
  40eba8:	pop    r14
  40ebaa:	pop    r13
  40ebac:	pop    r12
  40ebae:	pop    rdi
  40ebaf:	pop    rsi
  40ebb0:	pop    rbx
  40ebb1:	pop    rbp
  40ebb2:	ret
  40ebb3:	test   rdi,rdi
  40ebb6:	jne    40ebcb <__swc_fn_6b1cf01f_000089_386582f3+0x1fb>
  40ebb8:	xor    eax,eax
  40ebba:	add    rsp,0x38
  40ebbe:	pop    r15
  40ebc0:	pop    r14
  40ebc2:	pop    r13
  40ebc4:	pop    r12
  40ebc6:	pop    rdi
  40ebc7:	pop    rsi
  40ebc8:	pop    rbx
  40ebc9:	pop    rbp
  40ebca:	ret
  40ebcb:	mov    rcx,QWORD PTR [rsi+0x40]
  40ebcf:	call   40bf60 <__swc_fn_6b1cf01f_000082_754dcd57>
  40ebd4:	mov    rsi,rax
  40ebd7:	mov    rax,QWORD PTR [rdi]
  40ebda:	mov    rdi,rax
  40ebdd:	test   rax,rax
  40ebe0:	jne    40ec23 <__swc_fn_6b1cf01f_000089_386582f3+0x253>
  40ebe2:	test   rbx,rbx
  40ebe5:	je     40ec23 <__swc_fn_6b1cf01f_000089_386582f3+0x253>
  40ebe7:	mov    rcx,r15
  40ebea:	mov    rdx,rsi
  40ebed:	xor    r8d,r8d
  40ebf0:	call   4085a0 <__swc_fn_6b1cf01f_000090_a2d50c23>
  40ebf5:	mov    rcx,rax
  40ebf8:	test   al,al
  40ebfa:	jne    40ec1c <__swc_fn_6b1cf01f_000089_386582f3+0x24c>
  40ebfc:	mov    rcx,r15
  40ebff:	mov    rdx,rsi
  40ec02:	call   40bfa0 <__swc_fn_6b1cf01f_000085_1edf7c76>
  40ec07:	mov    rcx,rax
  40ec0a:	test   al,al
  40ec0c:	jne    40ec1c <__swc_fn_6b1cf01f_000089_386582f3+0x24c>
  40ec0e:	mov    rcx,rsi
  40ec11:	mov    rdx,r15
  40ec14:	call   40bfa0 <__swc_fn_6b1cf01f_000085_1edf7c76>
  40ec19:	mov    rcx,rax
  40ec1c:	test   cl,cl
  40ec1e:	setne  al
  40ec21:	mov    BYTE PTR [rbx],al
  40ec23:	xor    eax,eax
  40ec25:	mov    r14b,al
  40ec28:	test   rdi,rdi
  40ec2b:	jne    40ec45 <__swc_fn_6b1cf01f_000089_386582f3+0x275>
  40ec2d:	test   r14b,r14b
  40ec30:	jne    40ec45 <__swc_fn_6b1cf01f_000089_386582f3+0x275>
  40ec32:	xor    eax,eax
  40ec34:	add    rsp,0x38
  40ec38:	pop    r15
  40ec3a:	pop    r14
  40ec3c:	pop    r13
  40ec3e:	pop    r12
  40ec40:	pop    rdi
  40ec41:	pop    rsi
  40ec42:	pop    rbx
  40ec43:	pop    rbp
  40ec44:	ret
  40ec45:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40ec4a:	je     40ec56 <__swc_fn_6b1cf01f_000089_386582f3+0x286>
  40ec4c:	mov    r12,QWORD PTR [rsp+0x18]
  40ec51:	jmp    40ecde <__swc_fn_6b1cf01f_000089_386582f3+0x30e>
  40ec56:	mov    r12,QWORD PTR [rsp+0x18]
  40ec5b:	test   r12,r12
  40ec5e:	jne    40ec72 <__swc_fn_6b1cf01f_000089_386582f3+0x2a2>
  40ec60:	mov    rcx,r15
  40ec63:	mov    rdx,rsi
  40ec66:	xor    r8d,r8d
  40ec69:	call   4085a0 <__swc_fn_6b1cf01f_000090_a2d50c23>
  40ec6e:	test   al,al
  40ec70:	jne    40ecde <__swc_fn_6b1cf01f_000089_386582f3+0x30e>
  40ec72:	test   DWORD PTR [rsi+0x28],0x10000
  40ec79:	je     40ec97 <__swc_fn_6b1cf01f_000089_386582f3+0x2c7>
  40ec7b:	rex mov al,BYTE PTR [rsp+0x8]
  40ec80:	test   al,al
  40ec82:	jne    40ec97 <__swc_fn_6b1cf01f_000089_386582f3+0x2c7>
  40ec84:	xor    eax,eax
  40ec86:	add    rsp,0x38
  40ec8a:	pop    r15
  40ec8c:	pop    r14
  40ec8e:	pop    r13
  40ec90:	pop    r12
  40ec92:	pop    rdi
  40ec93:	pop    rsi
  40ec94:	pop    rbx
  40ec95:	pop    rbp
  40ec96:	ret
  40ec97:	test   rdi,rdi
  40ec9a:	jne    40ecaf <__swc_fn_6b1cf01f_000089_386582f3+0x2df>
  40ec9c:	xor    eax,eax
  40ec9e:	add    rsp,0x38
  40eca2:	pop    r15
  40eca4:	pop    r14
  40eca6:	pop    r13
  40eca8:	pop    r12
  40ecaa:	pop    rdi
  40ecab:	pop    rsi
  40ecac:	pop    rbx
  40ecad:	pop    rbp
  40ecae:	ret
  40ecaf:	cmp    QWORD PTR [rdi+0x8],0x0
  40ecb4:	jne    40ecc9 <__swc_fn_6b1cf01f_000089_386582f3+0x2f9>
  40ecb6:	xor    eax,eax
  40ecb8:	add    rsp,0x38
  40ecbc:	pop    r15
  40ecbe:	pop    r14
  40ecc0:	pop    r13
  40ecc2:	pop    r12
  40ecc4:	pop    rdi
  40ecc5:	pop    rsi
  40ecc6:	pop    rbx
  40ecc7:	pop    rbp
  40ecc8:	ret
  40ecc9:	mov    rax,QWORD PTR [rdi+0x8]
  40eccd:	mov    rax,QWORD PTR [rax]
  40ecd0:	mov    rsi,rax
  40ecd3:	mov    rdi,QWORD PTR [rdi]
  40ecd6:	mov    eax,0x1
  40ecdb:	mov    r14b,al
  40ecde:	test   rdi,rdi
  40ece1:	mov    rbx,QWORD PTR [rsp+0x20]
  40ece6:	jne    40ed30 <__swc_fn_6b1cf01f_000089_386582f3+0x360>
  40ece8:	test   r14b,r14b
  40eceb:	je     40ed1d <__swc_fn_6b1cf01f_000089_386582f3+0x34d>
  40eced:	test   r12,r12
  40ecf0:	je     40ed1d <__swc_fn_6b1cf01f_000089_386582f3+0x34d>
  40ecf2:	mov    rcx,r15
  40ecf5:	mov    rdx,rsi
  40ecf8:	xor    r8d,r8d
  40ecfb:	mov    r9,r12
  40ecfe:	mov    rbx,QWORD PTR [rsp+0x20]
  40ed03:	movzx  r10d,BYTE PTR [rbx]
  40ed07:	call   40e8c0 <__swc_fn_6b1cf01f_000083_31b501f2>
  40ed0c:	add    rsp,0x38
  40ed10:	pop    r15
  40ed12:	pop    r14
  40ed14:	pop    r13
  40ed16:	pop    r12
  40ed18:	pop    rdi
  40ed19:	pop    rsi
  40ed1a:	pop    rbx
  40ed1b:	pop    rbp
  40ed1c:	ret
  40ed1d:	xor    eax,eax
  40ed1f:	add    rsp,0x38
  40ed23:	pop    r15
  40ed25:	pop    r14
  40ed27:	pop    r13
  40ed29:	pop    r12
  40ed2b:	pop    rdi
  40ed2c:	pop    rsi
  40ed2d:	pop    rbx
  40ed2e:	pop    rbp
  40ed2f:	ret
  40ed30:	mov    r13,rsi
  40ed33:	mov    QWORD PTR [rsp+0x28],rdi
  40ed38:	cmp    BYTE PTR [r15+0x2c],0xe
  40ed3d:	sete   al
  40ed40:	mov    r14b,al
  40ed43:	jne    40ed57 <__swc_fn_6b1cf01f_000089_386582f3+0x387>
  40ed45:	mov    rcx,rsi
  40ed48:	mov    rdx,r15
  40ed4b:	call   40bfa0 <__swc_fn_6b1cf01f_000085_1edf7c76>
  40ed50:	mov    r14b,al
  40ed53:	test   al,al
  40ed55:	jne    40ed8c <__swc_fn_6b1cf01f_000089_386582f3+0x3bc>
  40ed57:	cmp    BYTE PTR [r15+0x2c],0x12
  40ed5c:	je     40ed8c <__swc_fn_6b1cf01f_000089_386582f3+0x3bc>
  40ed5e:	mov    rcx,r15
  40ed61:	mov    rdx,rsi
  40ed64:	mov    r8,rdi
  40ed67:	mov    r9,r12
  40ed6a:	mov    rax,rbx
  40ed6d:	movzx  r10d,BYTE PTR [rax]
  40ed71:	call   40e8c0 <__swc_fn_6b1cf01f_000083_31b501f2>
  40ed76:	test   rax,rax
  40ed79:	je     40ed8c <__swc_fn_6b1cf01f_000089_386582f3+0x3bc>
  40ed7b:	add    rsp,0x38
  40ed7f:	pop    r15
  40ed81:	pop    r14
  40ed83:	pop    r13
  40ed85:	pop    r12
  40ed87:	pop    rdi
  40ed88:	pop    rsi
  40ed89:	pop    rbx
  40ed8a:	pop    rbp
  40ed8b:	ret
  40ed8c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40ed91:	jne    40edb0 <__swc_fn_6b1cf01f_000089_386582f3+0x3e0>
  40ed93:	mov    rax,QWORD PTR [rsi+0xd8]
  40ed9a:	test   rax,rax
  40ed9d:	je     40edb0 <__swc_fn_6b1cf01f_000089_386582f3+0x3e0>
  40ed9f:	add    rdi,QWORD PTR [rax+0x8]
  40eda3:	mov    rax,QWORD PTR [rdi]
  40eda6:	sub    rdi,QWORD PTR [rax+0x8]
  40edaa:	mov    rax,QWORD PTR [rax]
  40edad:	mov    rsi,rax
  40edb0:	test   r14b,r14b
  40edb3:	je     40eddf <__swc_fn_6b1cf01f_000089_386582f3+0x40f>
  40edb5:	mov    rcx,r15
  40edb8:	mov    rdx,rsi
  40edbb:	mov    r8,rdi
  40edbe:	mov    r9,r13
  40edc1:	mov    r14,QWORD PTR [rsp+0x28]
  40edc6:	mov    r10,r14
  40edc9:	call   408480 <__swc_fn_6b1cf01f_000087_ea575bb3>
  40edce:	add    rsp,0x38
  40edd2:	pop    r15
  40edd4:	pop    r14
  40edd6:	pop    r13
  40edd8:	pop    r12
  40edda:	pop    rdi
  40eddb:	pop    rsi
  40eddc:	pop    rbx
  40eddd:	pop    rbp
  40edde:	ret
  40eddf:	mov    rcx,r15
  40ede2:	mov    rdx,rsi
  40ede5:	mov    r8,rdi
  40ede8:	mov    r9,r12
  40edeb:	movzx  r10d,BYTE PTR [rbx]
  40edef:	call   40e8c0 <__swc_fn_6b1cf01f_000083_31b501f2>
  40edf4:	add    rsp,0x38
  40edf8:	pop    r15
  40edfa:	pop    r14
  40edfc:	pop    r13
  40edfe:	pop    r12
  40ee00:	pop    rdi
  40ee01:	pop    rsi
  40ee02:	pop    rbx
  40ee03:	pop    rbp
  40ee04:	ret
	...

000000000040ee10 <__swc_fn_6b1cf01f_000092_8252f8c0>:
  40ee10:	push   rbx
  40ee11:	push   rsi
  40ee12:	sub    rsp,0x18
  40ee16:	mov    rbx,rcx
  40ee19:	mov    rcx,QWORD PTR [rip+0x17f20]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40ee20:	test   rcx,rcx
  40ee23:	jne    40ee35 <__swc_fn_6b1cf01f_000092_8252f8c0+0x25>
  40ee25:	call   40a1d0 <__swc_fn_6b1cf01f_000165_cf398896>
  40ee2a:	lea    rcx,[rax+0x1]
  40ee2e:	mov    QWORD PTR [rip+0x17f0b],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  40ee35:	dec    rcx
  40ee38:	call   411740 <__swc_fn_6b1cf01f_000167_fce60b2b>
  40ee3d:	mov    rsi,rax
  40ee40:	mov    rax,QWORD PTR [rsi+0x8]
  40ee44:	test   rax,rax
  40ee47:	jne    40ee97 <__swc_fn_6b1cf01f_000092_8252f8c0+0x87>
  40ee49:	call   40c090 <__swc_fn_6b1cf01f_000091_3d2f5a0d>
  40ee4e:	test   al,al
  40ee50:	jne    40ee97 <__swc_fn_6b1cf01f_000092_8252f8c0+0x87>
  40ee52:	lea    rdx,[rip+0x153e7]        # 424240 <__swc_bss_base_6b1cf01f+0x200>
  40ee59:	mov    rcx,rdx
  40ee5c:	call   407740 <__swc_fn_6b1cf01f_000036_8d895ba1>
  40ee61:	test   al,al
  40ee63:	jne    40ee74 <__swc_fn_6b1cf01f_000092_8252f8c0+0x64>
  40ee65:	mov    rcx,rdx
  40ee68:	call   40a980 <__swc_fn_6b1cf01f_000034_25f19556>
  40ee6d:	lea    rdx,[rip+0x153cc]        # 424240 <__swc_bss_base_6b1cf01f+0x200>
  40ee74:	mov    QWORD PTR [rsp+0x8],rdx
  40ee79:	lea    rax,[rip+0x42d0]        # 413150 <__swc_rdata_base_6b1cf01f+0x40>
  40ee80:	mov    QWORD PTR [rsp+0x10],rax
  40ee85:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ee8b:	vmovups XMMWORD PTR [rsi],xmm0
  40ee8f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40ee97:	vmovups xmm0,XMMWORD PTR [rsi]
  40ee9b:	vmovups XMMWORD PTR [rbx],xmm0
  40ee9f:	mov    rax,rbx
  40eea2:	add    rsp,0x18
  40eea6:	pop    rsi
  40eea7:	pop    rbx
  40eea8:	ret
  40eea9:	add    BYTE PTR [rax],al
  40eeab:	add    BYTE PTR [rax],al
  40eead:	add    BYTE PTR [rax],al
	...

000000000040eeb0 <__swc_fn_6b1cf01f_000095_337e587a>:
  40eeb0:	sub    rsp,0x8
  40eeb4:	call   409360 <__swc_fn_6b1cf01f_000117_86a7fb9e>
  40eeb9:	add    rsp,0x8
  40eebd:	ret
	...

000000000040eec0 <__swc_fn_6b1cf01f_000098_00f01091>:
  40eec0:	push   rbx
  40eec1:	push   rsi
  40eec2:	sub    rsp,0x28
  40eec6:	mov    rbx,rcx
  40eec9:	xor    esi,esi
  40eecb:	jmp    40eee0 <__swc_fn_6b1cf01f_000098_00f01091+0x20>
  40eecd:	nop    DWORD PTR [rax]
  40eed0:	mov    QWORD PTR [rbx+0x28],rsi
  40eed4:	mov    rsi,rbx
  40eed7:	mov    rbx,rax
  40eeda:	nop    WORD PTR [rax+rax*1+0x0]
  40eee0:	test   rbx,rbx
  40eee3:	je     40ef43 <__swc_fn_6b1cf01f_000098_00f01091+0x83>
  40eee5:	mov    rcx,rbx
  40eee8:	mov    edx,0x1
  40eeed:	call   408200 <__swc_fn_6b1cf01f_000078_a120bd2b>
  40eef2:	cmp    rax,0x1
  40eef6:	jne    40ef43 <__swc_fn_6b1cf01f_000098_00f01091+0x83>
  40eef8:	mov    r10,QWORD PTR [rbx+0x18]
  40eefc:	mov    rcx,r10
  40eeff:	mov    edx,0x1
  40ef04:	call   408200 <__swc_fn_6b1cf01f_000078_a120bd2b>
  40ef09:	cmp    rax,0x1
  40ef0d:	jne    40ef1c <__swc_fn_6b1cf01f_000098_00f01091+0x5c>
  40ef0f:	mov    rcx,r10
  40ef12:	call   40c230 <__swc_fn_6b1cf01f_000097_4c97e0db>
  40ef17:	test   rax,rax
  40ef1a:	jne    40eed0 <__swc_fn_6b1cf01f_000098_00f01091+0x10>
  40ef1c:	mov    rax,QWORD PTR [rbx+0x20]
  40ef20:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40ef25:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ef2b:	lea    rcx,[rsp+0x8]
  40ef30:	mov    rdx,rbx
  40ef33:	mov    r8d,0x30
  40ef39:	mov    rbx,rax
  40ef3c:	call   408960 <__swc_fn_6b1cf01f_000096_ad982b35>
  40ef41:	jmp    40eee0 <__swc_fn_6b1cf01f_000098_00f01091+0x20>
  40ef43:	test   rsi,rsi
  40ef46:	jne    40ef4f <__swc_fn_6b1cf01f_000098_00f01091+0x8f>
  40ef48:	add    rsp,0x28
  40ef4c:	pop    rsi
  40ef4d:	pop    rbx
  40ef4e:	ret
  40ef4f:	mov    rax,rsi
  40ef52:	mov    rsi,QWORD PTR [rsi+0x28]
  40ef56:	mov    rbx,QWORD PTR [rax+0x20]
  40ef5a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40ef5f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40ef65:	lea    rcx,[rsp+0x18]
  40ef6a:	mov    rdx,rax
  40ef6d:	mov    r8d,0x30
  40ef73:	call   408960 <__swc_fn_6b1cf01f_000096_ad982b35>
  40ef78:	jmp    40eee0 <__swc_fn_6b1cf01f_000098_00f01091+0x20>
  40ef7d:	add    BYTE PTR [rax],al
	...

000000000040ef80 <__swc_fn_6b1cf01f_000101_eab3874f>:
  40ef80:	push   rbx
  40ef81:	push   rsi
  40ef82:	push   rdi
  40ef83:	push   r12
  40ef85:	push   r13
  40ef87:	sub    rsp,0x20
  40ef8b:	mov    rbx,rcx
  40ef8e:	lea    rsi,[rcx+0x6f8]
  40ef95:	mov    edi,0x4
  40ef9a:	mov    r12,rsi
  40ef9d:	test   rdi,rdi
  40efa0:	je     40efea <__swc_fn_6b1cf01f_000101_eab3874f+0x6a>
  40efa2:	cs nop WORD PTR [rax+rax*1+0x0]
  40efac:	nop    DWORD PTR [rax+0x0]
  40efb0:	mov    rcx,QWORD PTR [r12+0x10]
  40efb5:	mov    QWORD PTR [r12+0x10],0x0
  40efbe:	vxorps xmm0,xmm0,xmm0
  40efc2:	vmovups XMMWORD PTR [r12],xmm0
  40efc8:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40efcf:	mov    DWORD PTR [r12+0x20],0x0
  40efd8:	call   4089c0 <__swc_fn_6b1cf01f_000099_b4c6da83>
  40efdd:	add    r12,0x90
  40efe4:	sub    rdi,0x1
  40efe8:	jne    40efb0 <__swc_fn_6b1cf01f_000101_eab3874f+0x30>
  40efea:	mov    rax,QWORD PTR [rbx+0x938]
  40eff1:	mov    rdi,rax
  40eff4:	test   rdi,rdi
  40eff7:	je     40f051 <__swc_fn_6b1cf01f_000101_eab3874f+0xd1>
  40eff9:	nop    DWORD PTR [rax+0x0]
  40f000:	mov    r12d,0x10
  40f006:	lea    r13,[rdi+0x18]
  40f00a:	test   r12,r12
  40f00d:	je     40f046 <__swc_fn_6b1cf01f_000101_eab3874f+0xc6>
  40f00f:	nop
  40f010:	mov    rcx,QWORD PTR [r13+0x10]
  40f014:	mov    QWORD PTR [r13+0x10],0x0
  40f01c:	vxorps xmm0,xmm0,xmm0
  40f020:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40f026:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40f02c:	mov    DWORD PTR [r13+0x20],0x0
  40f034:	call   4089c0 <__swc_fn_6b1cf01f_000099_b4c6da83>
  40f039:	add    r13,0x90
  40f040:	sub    r12,0x1
  40f044:	jne    40f010 <__swc_fn_6b1cf01f_000101_eab3874f+0x90>
  40f046:	mov    rax,QWORD PTR [rdi]
  40f049:	mov    rdi,rax
  40f04c:	test   rax,rax
  40f04f:	jne    40f000 <__swc_fn_6b1cf01f_000101_eab3874f+0x80>
  40f051:	vxorps xmm0,xmm0,xmm0
  40f055:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40f05d:	mov    DWORD PTR [rbx+0x9b0],0x0
  40f067:	mov    DWORD PTR [rbx+0x9a8],0x0
  40f071:	mov    edi,0x4
  40f076:	mov    r12,rsi
  40f079:	lea    rsi,[rsi+0x38]
  40f07d:	test   rdi,rdi
  40f080:	je     40f0ac <__swc_fn_6b1cf01f_000101_eab3874f+0x12c>
  40f082:	cs nop WORD PTR [rax+rax*1+0x0]
  40f08c:	nop    DWORD PTR [rax+0x0]
  40f090:	mov    rcx,rsi
  40f093:	call   40d0c0 <__swc_fn_6b1cf01f_000157_232ffa22>
  40f098:	add    rsi,0x90
  40f09f:	add    r12,0x90
  40f0a6:	sub    rdi,0x1
  40f0aa:	jne    40f090 <__swc_fn_6b1cf01f_000101_eab3874f+0x110>
  40f0ac:	mov    rax,QWORD PTR [rbx+0x938]
  40f0b3:	mov    rdi,rax
  40f0b6:	mov    QWORD PTR [rbx+0x938],0x0
  40f0c1:	test   rdi,rdi
  40f0c4:	je     40f135 <__swc_fn_6b1cf01f_000101_eab3874f+0x1b5>
  40f0ca:	nop    WORD PTR [rax+rax*1+0x0]
  40f0d0:	mov    esi,0x10
  40f0d5:	lea    r12,[rdi+0x18]
  40f0d9:	lea    r13,[rdi+0x50]
  40f0dd:	test   rsi,rsi
  40f0e0:	je     40f10c <__swc_fn_6b1cf01f_000101_eab3874f+0x18c>
  40f0e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f0ec:	nop    DWORD PTR [rax+0x0]
  40f0f0:	mov    rcx,r13
  40f0f3:	call   40d0c0 <__swc_fn_6b1cf01f_000157_232ffa22>
  40f0f8:	add    r13,0x90
  40f0ff:	add    r12,0x90
  40f106:	sub    rsi,0x1
  40f10a:	jne    40f0f0 <__swc_fn_6b1cf01f_000101_eab3874f+0x170>
  40f10c:	mov    rax,QWORD PTR [rdi]
  40f10f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40f114:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f11a:	lea    rcx,[rsp+0x8]
  40f11f:	mov    rdx,rdi
  40f122:	mov    r8d,0x918
  40f128:	mov    rdi,rax
  40f12b:	call   408960 <__swc_fn_6b1cf01f_000096_ad982b35>
  40f130:	test   rdi,rdi
  40f133:	jne    40f0d0 <__swc_fn_6b1cf01f_000101_eab3874f+0x150>
  40f135:	lea    rcx,[rbx+0x68]
  40f139:	call   40d0c0 <__swc_fn_6b1cf01f_000157_232ffa22>
  40f13e:	add    rsp,0x20
  40f142:	pop    r13
  40f144:	pop    r12
  40f146:	pop    rdi
  40f147:	pop    rsi
  40f148:	pop    rbx
  40f149:	ret
  40f14a:	add    BYTE PTR [rax],al
  40f14c:	add    BYTE PTR [rax],al
	...

000000000040f150 <__swc_fn_6b1cf01f_000104_5589fdbd>:
  40f150:	xor    eax,eax
  40f152:	cs nop WORD PTR [rax+rax*1+0x0]
  40f15c:	nop    DWORD PTR [rax+0x0]
  40f160:	mov    r9,r8
  40f163:	sub    r9,rax
  40f166:	cmp    r9,0x40
  40f16a:	jb     40f1a8 <__swc_fn_6b1cf01f_000104_5589fdbd+0x58>
  40f16c:	lea    r9,[rcx+rax*1]
  40f170:	lea    r10,[rdx+rax*1]
  40f174:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40f17a:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40f180:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40f186:	vmovups xmm3,XMMWORD PTR [r10]
  40f18b:	vmovups XMMWORD PTR [r9],xmm3
  40f190:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40f196:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40f19c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40f1a2:	lea    rax,[rax+0x40]
  40f1a6:	jmp    40f160 <__swc_fn_6b1cf01f_000104_5589fdbd+0x10>
  40f1a8:	nop    DWORD PTR [rax+rax*1+0x0]
  40f1b0:	mov    r9,r8
  40f1b3:	sub    r9,rax
  40f1b6:	cmp    r9,0x10
  40f1ba:	jb     40f1d4 <__swc_fn_6b1cf01f_000104_5589fdbd+0x84>
  40f1bc:	lea    r9,[rdx+rax*1]
  40f1c0:	lea    r10,[rcx+rax*1]
  40f1c4:	vmovups xmm0,XMMWORD PTR [r9]
  40f1c9:	vmovups XMMWORD PTR [r10],xmm0
  40f1ce:	lea    rax,[rax+0x10]
  40f1d2:	jmp    40f1b0 <__swc_fn_6b1cf01f_000104_5589fdbd+0x60>
  40f1d4:	cs nop WORD PTR [rax+rax*1+0x0]
  40f1de:	xchg   ax,ax
  40f1e0:	mov    r9,r8
  40f1e3:	sub    r9,rax
  40f1e6:	cmp    r9,0x8
  40f1ea:	jb     40f1fd <__swc_fn_6b1cf01f_000104_5589fdbd+0xad>
  40f1ec:	lea    r9,[rcx+rax*1]
  40f1f0:	mov    r10,QWORD PTR [rdx+rax*1]
  40f1f4:	mov    QWORD PTR [r9],r10
  40f1f7:	lea    rax,[rax+0x8]
  40f1fb:	jmp    40f1e0 <__swc_fn_6b1cf01f_000104_5589fdbd+0x90>
  40f1fd:	cmp    rax,r8
  40f200:	jae    40f220 <__swc_fn_6b1cf01f_000104_5589fdbd+0xd0>
  40f202:	cs nop WORD PTR [rax+rax*1+0x0]
  40f20c:	nop    DWORD PTR [rax+0x0]
  40f210:	mov    r9b,BYTE PTR [rdx+rax*1]
  40f214:	mov    BYTE PTR [rcx+rax*1],r9b
  40f218:	inc    rax
  40f21b:	cmp    rax,r8
  40f21e:	jb     40f210 <__swc_fn_6b1cf01f_000104_5589fdbd+0xc0>
  40f220:	ret
	...

000000000040f240 <__swc_fn_6b1cf01f_000107_4796e893>:
  40f240:	push   rbx
  40f241:	push   r12
  40f243:	push   rdi
  40f244:	push   rsi
  40f245:	push   r13
  40f247:	push   r14
  40f249:	push   r15
  40f24b:	sub    rsp,0x170
  40f252:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40f25b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40f264:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40f26d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40f276:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40f27f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40f288:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40f291:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40f29a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40f2a3:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40f2ac:	mov    ebx,edx
  40f2ae:	mov    QWORD PTR [rsp+0xa8],rbx
  40f2b6:	mov    r12d,ecx
  40f2b9:	test   edx,edx
  40f2bb:	jne    40f2d2 <__swc_fn_6b1cf01f_000107_4796e893+0x92>
  40f2bd:	xor    eax,eax
  40f2bf:	add    rsp,0x170
  40f2c6:	pop    r15
  40f2c8:	pop    r14
  40f2ca:	pop    r13
  40f2cc:	pop    rsi
  40f2cd:	pop    rdi
  40f2ce:	pop    r12
  40f2d0:	pop    rbx
  40f2d1:	ret
  40f2d2:	lea    rdi,[rip+0x41d7]        # 4134b0 <__swc_rdata_base_6b1cf01f+0x3a0>
  40f2d9:	mov    esi,0x90000
  40f2de:	xor    eax,eax
  40f2e0:	call   407090 <open@plt>
  40f2e5:	mov    r13,rax
  40f2e8:	mov    QWORD PTR [rsp+0xb0],rax
  40f2f0:	test   eax,eax
  40f2f2:	jge    40f2fb <__swc_fn_6b1cf01f_000107_4796e893+0xbb>
  40f2f4:	xor    eax,eax
  40f2f6:	jmp    40f816 <__swc_fn_6b1cf01f_000107_4796e893+0x5d6>
  40f2fb:	nop    DWORD PTR [rax+rax*1+0x0]
  40f300:	movsxd rdi,r13d
  40f303:	mov    esi,0x2
  40f308:	xor    eax,eax
  40f30a:	call   407120 <flock@plt>
  40f30f:	test   eax,eax
  40f311:	je     40f330 <__swc_fn_6b1cf01f_000107_4796e893+0xf0>
  40f313:	xor    eax,eax
  40f315:	call   407130 <__errno_location@plt>
  40f31a:	cmp    DWORD PTR [rax],0x4
  40f31d:	je     40f300 <__swc_fn_6b1cf01f_000107_4796e893+0xc0>
  40f31f:	movsxd rdi,r13d
  40f322:	xor    eax,eax
  40f324:	call   4070b0 <close@plt>
  40f329:	xor    eax,eax
  40f32b:	jmp    40f816 <__swc_fn_6b1cf01f_000107_4796e893+0x5d6>
  40f330:	lea    r14,[rsp+0x8]
  40f335:	mov    QWORD PTR [rsp+0xb8],r14
  40f33d:	vxorps xmm0,xmm0,xmm0
  40f341:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f347:	mov    QWORD PTR [rsp+0x18],0x0
  40f350:	mov    WORD PTR [rsp+0x20],0x0
  40f357:	mov    DWORD PTR [r14],0x67617753
  40f35e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40f366:	xor    eax,eax
  40f368:	call   407010 <getpid@plt>
  40f36d:	mov    ecx,eax
  40f36f:	mov    eax,0x1c
  40f374:	shrx   eax,ecx,eax
  40f379:	and    eax,0xf
  40f37c:	mov    rdx,QWORD PTR [rip+0x414d]        # 4134d0 <__swc_rdata_base_6b1cf01f+0x3c0>
  40f383:	mov    al,BYTE PTR [rdx+rax*1]
  40f386:	rex mov BYTE PTR [rsp+0x10],al
  40f38b:	mov    eax,0x1c
  40f390:	shrx   eax,r12d,eax
  40f395:	and    eax,0xf
  40f398:	mov    al,BYTE PTR [rdx+rax*1]
  40f39b:	rex mov BYTE PTR [rsp+0x19],al
  40f3a0:	mov    eax,0x18
  40f3a5:	shrx   eax,ecx,eax
  40f3aa:	and    eax,0xf
  40f3ad:	mov    al,BYTE PTR [rdx+rax*1]
  40f3b0:	rex mov BYTE PTR [rsp+0x11],al
  40f3b5:	mov    eax,0x18
  40f3ba:	shrx   eax,r12d,eax
  40f3bf:	and    eax,0xf
  40f3c2:	mov    al,BYTE PTR [rdx+rax*1]
  40f3c5:	rex mov BYTE PTR [rsp+0x1a],al
  40f3ca:	mov    eax,0x14
  40f3cf:	shrx   eax,ecx,eax
  40f3d4:	and    eax,0xf
  40f3d7:	mov    al,BYTE PTR [rdx+rax*1]
  40f3da:	rex mov BYTE PTR [rsp+0x12],al
  40f3df:	mov    eax,0x14
  40f3e4:	shrx   eax,r12d,eax
  40f3e9:	and    eax,0xf
  40f3ec:	mov    al,BYTE PTR [rdx+rax*1]
  40f3ef:	rex mov BYTE PTR [rsp+0x1b],al
  40f3f4:	mov    eax,0x10
  40f3f9:	shrx   eax,ecx,eax
  40f3fe:	and    eax,0xf
  40f401:	mov    al,BYTE PTR [rdx+rax*1]
  40f404:	rex mov BYTE PTR [rsp+0x13],al
  40f409:	mov    eax,0x10
  40f40e:	shrx   eax,r12d,eax
  40f413:	and    eax,0xf
  40f416:	mov    al,BYTE PTR [rdx+rax*1]
  40f419:	rex mov BYTE PTR [rsp+0x1c],al
  40f41e:	mov    eax,0xc
  40f423:	shrx   eax,ecx,eax
  40f428:	and    eax,0xf
  40f42b:	mov    al,BYTE PTR [rdx+rax*1]
  40f42e:	rex mov BYTE PTR [rsp+0x14],al
  40f433:	mov    eax,0xc
  40f438:	shrx   eax,r12d,eax
  40f43d:	and    eax,0xf
  40f440:	mov    al,BYTE PTR [rdx+rax*1]
  40f443:	rex mov BYTE PTR [rsp+0x1d],al
  40f448:	mov    eax,0x8
  40f44d:	shrx   eax,ecx,eax
  40f452:	and    eax,0xf
  40f455:	mov    al,BYTE PTR [rdx+rax*1]
  40f458:	rex mov BYTE PTR [rsp+0x15],al
  40f45d:	mov    eax,0x8
  40f462:	shrx   eax,r12d,eax
  40f467:	and    eax,0xf
  40f46a:	mov    al,BYTE PTR [rdx+rax*1]
  40f46d:	rex mov BYTE PTR [rsp+0x1e],al
  40f472:	mov    eax,0x4
  40f477:	shrx   eax,ecx,eax
  40f47c:	and    eax,0xf
  40f47f:	mov    al,BYTE PTR [rdx+rax*1]
  40f482:	rex mov BYTE PTR [rsp+0x16],al
  40f487:	mov    eax,0x4
  40f48c:	shrx   eax,r12d,eax
  40f491:	and    eax,0xf
  40f494:	mov    al,BYTE PTR [rdx+rax*1]
  40f497:	rex mov BYTE PTR [rsp+0x1f],al
  40f49c:	xor    eax,eax
  40f49e:	shrx   eax,ecx,eax
  40f4a3:	and    eax,0xf
  40f4a6:	mov    al,BYTE PTR [rdx+rax*1]
  40f4a9:	rex mov BYTE PTR [rsp+0x17],al
  40f4ae:	xor    eax,eax
  40f4b0:	shrx   eax,r12d,eax
  40f4b5:	and    eax,0xf
  40f4b8:	mov    al,BYTE PTR [rdx+rax*1]
  40f4bb:	rex mov BYTE PTR [rsp+0x20],al
  40f4c0:	mov    BYTE PTR [r14+0x10],0x2e
  40f4c5:	lea    r12,[rsp+0x22]
  40f4ca:	vxorps xmm0,xmm0,xmm0
  40f4ce:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40f4d4:	mov    DWORD PTR [r12],0x6d656d2f
  40f4dc:	mov    WORD PTR [r12+0x4],0x6466
  40f4e4:	mov    BYTE PTR [r12+0x6],0x3a
  40f4ea:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f4f0:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40f4f6:	mov    rax,QWORD PTR [rsp+0x18]
  40f4fb:	mov    QWORD PTR [rsp+0x39],rax
  40f500:	rex mov al,BYTE PTR [rsp+0x20]
  40f505:	rex mov BYTE PTR [rsp+0x41],al
  40f50a:	mov    DWORD PTR [r12+0x20],0x65642820
  40f513:	mov    DWORD PTR [r12+0x24],0x6574656c
  40f51c:	mov    WORD PTR [r12+0x28],0x2964
  40f524:	lea    rdi,[rip+0x3f90]        # 4134bb <__swc_rdata_base_6b1cf01f+0x3ab>
  40f52b:	xor    eax,eax
  40f52d:	call   407140 <opendir@plt>
  40f532:	mov    r15,rax
  40f535:	test   rax,rax
  40f538:	jne    40f54b <__swc_fn_6b1cf01f_000107_4796e893+0x30b>
  40f53a:	movsxd rdi,r13d
  40f53d:	xor    eax,eax
  40f53f:	call   4070b0 <close@plt>
  40f544:	xor    eax,eax
  40f546:	jmp    40f816 <__swc_fn_6b1cf01f_000107_4796e893+0x5d6>
  40f54b:	mov    rdi,r15
  40f54e:	xor    eax,eax
  40f550:	call   407150 <dirfd@plt>
  40f555:	lea    r14,[rsp+0x54]
  40f55a:	mov    DWORD PTR [rsp+0x54],eax
  40f55e:	lea    rbx,[rsp+0x58]
  40f563:	cs nop WORD PTR [rax+rax*1+0x0]
  40f56d:	cs nop WORD PTR [rax+rax*1+0x0]
  40f577:	nop    WORD PTR [rax+rax*1+0x0]
  40f580:	mov    rdi,r15
  40f583:	xor    eax,eax
  40f585:	call   407160 <readdir@plt>
  40f58a:	test   rax,rax
  40f58d:	jne    40f5a4 <__swc_fn_6b1cf01f_000107_4796e893+0x364>
  40f58f:	mov    r12,QWORD PTR [rsp+0xa8]
  40f597:	mov    r13,QWORD PTR [rsp+0xb0]
  40f59f:	jmp    40f73a <__swc_fn_6b1cf01f_000107_4796e893+0x4fa>
  40f5a4:	vxorps xmm0,xmm0,xmm0
  40f5a8:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40f5ae:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40f5b4:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40f5ba:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40f5c3:	lea    r13,[rax+0x13]
  40f5c7:	mov    rax,r14
  40f5ca:	movsxd rdi,DWORD PTR [rax]
  40f5cd:	mov    rsi,r13
  40f5d0:	mov    rdx,rbx
  40f5d3:	mov    ecx,0x40
  40f5d8:	xor    eax,eax
  40f5da:	call   407170 <readlinkat@plt>
  40f5df:	cmp    rax,0x2a
  40f5e3:	jne    40f580 <__swc_fn_6b1cf01f_000107_4796e893+0x340>
  40f5e5:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40f5eb:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40f5f1:	vptest xmm0,xmm0
  40f5f6:	jne    40f626 <__swc_fn_6b1cf01f_000107_4796e893+0x3e6>
  40f5f8:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40f5fe:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40f604:	vptest xmm0,xmm0
  40f609:	jne    40f626 <__swc_fn_6b1cf01f_000107_4796e893+0x3e6>
  40f60b:	mov    rcx,QWORD PTR [rsp+0x42]
  40f610:	cmp    QWORD PTR [rsp+0x78],rcx
  40f615:	jne    40f626 <__swc_fn_6b1cf01f_000107_4796e893+0x3e6>
  40f617:	mov    cx,WORD PTR [rsp+0x4a]
  40f61c:	cmp    WORD PTR [rsp+0x80],cx
  40f624:	je     40f654 <__swc_fn_6b1cf01f_000107_4796e893+0x414>
  40f626:	mov    rax,rbx
  40f629:	mov    rcx,r12
  40f62c:	nop    DWORD PTR [rax+0x0]
  40f630:	movzx  edx,BYTE PTR [rax]
  40f633:	movzx  r8d,BYTE PTR [rcx]
  40f637:	cmp    rdx,r8
  40f63a:	jne    40f646 <__swc_fn_6b1cf01f_000107_4796e893+0x406>
  40f63c:	add    rax,0x1
  40f640:	add    rcx,0x1
  40f644:	jmp    40f630 <__swc_fn_6b1cf01f_000107_4796e893+0x3f0>
  40f646:	mov    rax,rdx
  40f649:	sub    rax,r8
  40f64c:	test   eax,eax
  40f64e:	jne    40f580 <__swc_fn_6b1cf01f_000107_4796e893+0x340>
  40f654:	movsxd rdi,DWORD PTR [r14]
  40f657:	mov    rsi,r13
  40f65a:	mov    edx,0x80002
  40f65f:	xor    eax,eax
  40f661:	call   407180 <openat@plt>
  40f666:	lea    rbx,[rsp+0x98]
  40f66e:	mov    DWORD PTR [rsp+0x98],eax
  40f675:	test   eax,eax
  40f677:	mov    r13,QWORD PTR [rsp+0xb0]
  40f67f:	jge    40f6a4 <__swc_fn_6b1cf01f_000107_4796e893+0x464>
  40f681:	mov    rdi,r15
  40f684:	xor    eax,eax
  40f686:	call   407190 <closedir@plt>
  40f68b:	mov    r13,QWORD PTR [rsp+0xb0]
  40f693:	movsxd rdi,r13d
  40f696:	xor    eax,eax
  40f698:	call   4070b0 <close@plt>
  40f69d:	xor    eax,eax
  40f69f:	jmp    40f816 <__swc_fn_6b1cf01f_000107_4796e893+0x5d6>
  40f6a4:	mov    rax,rbx
  40f6a7:	movsxd rdi,DWORD PTR [rax]
  40f6aa:	xor    esi,esi
  40f6ac:	mov    edx,0x2
  40f6b1:	xor    eax,eax
  40f6b3:	call   4070a0 <lseek@plt>
  40f6b8:	mov    r12,QWORD PTR [rsp+0xa8]
  40f6c0:	cmp    rax,r12
  40f6c3:	je     40f6ea <__swc_fn_6b1cf01f_000107_4796e893+0x4aa>
  40f6c5:	movsxd rdi,DWORD PTR [rbx]
  40f6c8:	xor    eax,eax
  40f6ca:	call   4070b0 <close@plt>
  40f6cf:	mov    rdi,r15
  40f6d2:	xor    eax,eax
  40f6d4:	call   407190 <closedir@plt>
  40f6d9:	movsxd rdi,r13d
  40f6dc:	xor    eax,eax
  40f6de:	call   4070b0 <close@plt>
  40f6e3:	xor    eax,eax
  40f6e5:	jmp    40f816 <__swc_fn_6b1cf01f_000107_4796e893+0x5d6>
  40f6ea:	xor    edi,edi
  40f6ec:	mov    rsi,r12
  40f6ef:	mov    edx,0x3
  40f6f4:	mov    ecx,0x1
  40f6f9:	mov    rax,rbx
  40f6fc:	movsxd r8,DWORD PTR [rax]
  40f6ff:	xor    r9d,r9d
  40f702:	xor    eax,eax
  40f704:	call   4070c0 <mmap@plt>
  40f709:	xor    r12d,r12d
  40f70c:	cmp    rax,0xffffffffffffffff
  40f710:	cmovne r12,rax
  40f714:	movsxd rdi,DWORD PTR [rbx]
  40f717:	xor    eax,eax
  40f719:	call   4070b0 <close@plt>
  40f71e:	mov    rdi,r15
  40f721:	xor    eax,eax
  40f723:	call   407190 <closedir@plt>
  40f728:	movsxd rdi,r13d
  40f72b:	xor    eax,eax
  40f72d:	call   4070b0 <close@plt>
  40f732:	mov    rax,r12
  40f735:	jmp    40f816 <__swc_fn_6b1cf01f_000107_4796e893+0x5d6>
  40f73a:	mov    r14,QWORD PTR [rsp+0xb8]
  40f742:	mov    rdi,r14
  40f745:	mov    esi,0x1
  40f74a:	xor    eax,eax
  40f74c:	call   4071a0 <memfd_create@plt>
  40f751:	lea    rbx,[rsp+0x9c]
  40f759:	mov    DWORD PTR [rsp+0x9c],eax
  40f760:	test   eax,eax
  40f762:	jge    40f77f <__swc_fn_6b1cf01f_000107_4796e893+0x53f>
  40f764:	mov    rdi,r15
  40f767:	xor    eax,eax
  40f769:	call   407190 <closedir@plt>
  40f76e:	movsxd rdi,r13d
  40f771:	xor    eax,eax
  40f773:	call   4070b0 <close@plt>
  40f778:	xor    eax,eax
  40f77a:	jmp    40f816 <__swc_fn_6b1cf01f_000107_4796e893+0x5d6>
  40f77f:	mov    rax,rbx
  40f782:	movsxd rdi,DWORD PTR [rax]
  40f785:	mov    rsi,r12
  40f788:	xor    eax,eax
  40f78a:	call   4071b0 <ftruncate@plt>
  40f78f:	test   eax,eax
  40f791:	je     40f7b5 <__swc_fn_6b1cf01f_000107_4796e893+0x575>
  40f793:	movsxd rdi,DWORD PTR [rbx]
  40f796:	xor    eax,eax
  40f798:	call   4070b0 <close@plt>
  40f79d:	mov    rdi,r15
  40f7a0:	xor    eax,eax
  40f7a2:	call   407190 <closedir@plt>
  40f7a7:	movsxd rdi,r13d
  40f7aa:	xor    eax,eax
  40f7ac:	call   4070b0 <close@plt>
  40f7b1:	xor    eax,eax
  40f7b3:	jmp    40f816 <__swc_fn_6b1cf01f_000107_4796e893+0x5d6>
  40f7b5:	xor    edi,edi
  40f7b7:	mov    rsi,r12
  40f7ba:	mov    edx,0x3
  40f7bf:	mov    ecx,0x1
  40f7c4:	mov    rax,rbx
  40f7c7:	movsxd r8,DWORD PTR [rax]
  40f7ca:	xor    r9d,r9d
  40f7cd:	xor    eax,eax
  40f7cf:	call   4070c0 <mmap@plt>
  40f7d4:	mov    r12,rax
  40f7d7:	cmp    rax,0xffffffffffffffff
  40f7db:	jne    40f7ff <__swc_fn_6b1cf01f_000107_4796e893+0x5bf>
  40f7dd:	movsxd rdi,DWORD PTR [rbx]
  40f7e0:	xor    eax,eax
  40f7e2:	call   4070b0 <close@plt>
  40f7e7:	mov    rdi,r15
  40f7ea:	xor    eax,eax
  40f7ec:	call   407190 <closedir@plt>
  40f7f1:	movsxd rdi,r13d
  40f7f4:	xor    eax,eax
  40f7f6:	call   4070b0 <close@plt>
  40f7fb:	xor    eax,eax
  40f7fd:	jmp    40f816 <__swc_fn_6b1cf01f_000107_4796e893+0x5d6>
  40f7ff:	mov    rdi,r15
  40f802:	xor    eax,eax
  40f804:	call   407190 <closedir@plt>
  40f809:	movsxd rdi,r13d
  40f80c:	xor    eax,eax
  40f80e:	call   4070b0 <close@plt>
  40f813:	mov    rax,r12
  40f816:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40f81f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40f828:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40f831:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40f83a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  40f843:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40f84c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  40f855:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40f85e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  40f867:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  40f870:	add    rsp,0x170
  40f877:	pop    r15
  40f879:	pop    r14
  40f87b:	pop    r13
  40f87d:	pop    rsi
  40f87e:	pop    rdi
  40f87f:	pop    r12
  40f881:	pop    rbx
  40f882:	ret
	...

000000000040f890 <__swc_fn_6b1cf01f_000110_a808fe76>:
  40f890:	push   rsi
  40f891:	push   rdi
  40f892:	push   r12
  40f894:	push   r13
  40f896:	sub    rsp,0x8
  40f89a:	mov    rsi,r8
  40f89d:	mov    rdi,rcx
  40f8a0:	mov    r12,rdx
  40f8a3:	call   409120 <__swc_fn_6b1cf01f_000108_84af7666>
  40f8a8:	mov    r13,rax
  40f8ab:	test   rax,rax
  40f8ae:	jne    40f8bb <__swc_fn_6b1cf01f_000110_a808fe76+0x2b>
  40f8b0:	add    rsp,0x8
  40f8b4:	pop    r13
  40f8b6:	pop    r12
  40f8b8:	pop    rdi
  40f8b9:	pop    rsi
  40f8ba:	ret
  40f8bb:	mov    rcx,r13
  40f8be:	call   40ccb0 <__swc_fn_6b1cf01f_000133_4b2af8da>
  40f8c3:	mov    rax,QWORD PTR [r13+0x8]
  40f8c7:	test   rax,rax
  40f8ca:	je     40f909 <__swc_fn_6b1cf01f_000110_a808fe76+0x79>
  40f8cc:	nop    DWORD PTR [rax+0x0]
  40f8d0:	lea    rcx,[rax+0x1000]
  40f8d7:	cmp    rdi,rcx
  40f8da:	jne    40f901 <__swc_fn_6b1cf01f_000110_a808fe76+0x71>
  40f8dc:	cmp    r12,0x1000
  40f8e3:	jb     40f901 <__swc_fn_6b1cf01f_000110_a808fe76+0x71>
  40f8e5:	test   sil,sil
  40f8e8:	setne  cl
  40f8eb:	mov    BYTE PTR [rax+0x10],cl
  40f8ee:	mov    rcx,r13
  40f8f1:	call   40fe00 <__swc_fn_6b1cf01f_000134_29412410>
  40f8f6:	add    rsp,0x8
  40f8fa:	pop    r13
  40f8fc:	pop    r12
  40f8fe:	pop    rdi
  40f8ff:	pop    rsi
  40f900:	ret
  40f901:	mov    rax,QWORD PTR [rax]
  40f904:	test   rax,rax
  40f907:	jne    40f8d0 <__swc_fn_6b1cf01f_000110_a808fe76+0x40>
  40f909:	mov    rcx,r13
  40f90c:	call   40fe00 <__swc_fn_6b1cf01f_000134_29412410>
  40f911:	add    rsp,0x8
  40f915:	pop    r13
  40f917:	pop    r12
  40f919:	pop    rdi
  40f91a:	pop    rsi
  40f91b:	ret
  40f91c:	add    BYTE PTR [rax],al
	...

000000000040f920 <__swc_fn_6b1cf01f_000113_49b378a9>:
  40f920:	sub    rsp,0x8
  40f924:	test   rcx,rcx
  40f927:	jne    40f92e <__swc_fn_6b1cf01f_000113_49b378a9+0xe>
  40f929:	add    rsp,0x8
  40f92d:	ret
  40f92e:	call   40c7c0 <__swc_fn_6b1cf01f_000115_1ba33335>
  40f933:	add    rsp,0x8
  40f937:	ret
	...

000000000040f940 <__swc_fn_6b1cf01f_000116_035d76a1>:
  40f940:	push   r12
  40f942:	push   r13
  40f944:	push   r14
  40f946:	push   rdi
  40f947:	push   rsi
  40f948:	sub    rsp,0xc0
  40f94f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40f955:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40f95b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40f961:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40f967:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40f96d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40f973:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40f979:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40f982:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40f98b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40f994:	mov    r12,QWORD PTR [rcx]
  40f997:	test   r12,r12
  40f99a:	jne    40f9ac <__swc_fn_6b1cf01f_000116_035d76a1+0x6c>
  40f99c:	add    rsp,0xc0
  40f9a3:	pop    rsi
  40f9a4:	pop    rdi
  40f9a5:	pop    r14
  40f9a7:	pop    r13
  40f9a9:	pop    r12
  40f9ab:	ret
  40f9ac:	xor    r13d,r13d
  40f9af:	mov    r14,QWORD PTR [rcx+0x8]
  40f9b3:	cs nop WORD PTR [rax+rax*1+0x0]
  40f9bd:	nop    DWORD PTR [rax]
  40f9c0:	cmp    r13,r14
  40f9c3:	jae    40f9fe <__swc_fn_6b1cf01f_000116_035d76a1+0xbe>
  40f9c5:	lea    rax,[r12+r13*1]
  40f9c9:	mov    rcx,r14
  40f9cc:	sub    rcx,r13
  40f9cf:	mov    edi,0x1
  40f9d4:	mov    rsi,rax
  40f9d7:	mov    rdx,rcx
  40f9da:	xor    eax,eax
  40f9dc:	call   4071c0 <write@plt>
  40f9e1:	test   rax,rax
  40f9e4:	jle    40f9eb <__swc_fn_6b1cf01f_000116_035d76a1+0xab>
  40f9e6:	add    r13,rax
  40f9e9:	jmp    40f9c0 <__swc_fn_6b1cf01f_000116_035d76a1+0x80>
  40f9eb:	test   rax,rax
  40f9ee:	je     40f9fc <__swc_fn_6b1cf01f_000116_035d76a1+0xbc>
  40f9f0:	xor    eax,eax
  40f9f2:	call   407130 <__errno_location@plt>
  40f9f7:	cmp    DWORD PTR [rax],0x4
  40f9fa:	je     40f9c0 <__swc_fn_6b1cf01f_000116_035d76a1+0x80>
  40f9fc:	jmp    40f9fe <__swc_fn_6b1cf01f_000116_035d76a1+0xbe>
  40f9fe:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40fa04:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40fa0a:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40fa10:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40fa16:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40fa1c:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40fa22:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40fa28:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40fa31:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40fa3a:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40fa43:	add    rsp,0xc0
  40fa4a:	pop    rsi
  40fa4b:	pop    rdi
  40fa4c:	pop    r14
  40fa4e:	pop    r13
  40fa50:	pop    r12
  40fa52:	ret
	...

000000000040fa60 <__swc_fn_6b1cf01f_000119_9175a56a>:
  40fa60:	push   rbx
  40fa61:	push   r12
  40fa63:	push   rdi
  40fa64:	push   rsi
  40fa65:	sub    rsp,0x4a8
  40fa6c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  40fa75:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  40fa7e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  40fa87:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  40fa90:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  40fa99:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  40faa2:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  40faab:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  40fab4:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  40fabd:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  40fac6:	mov    rbx,rdx
  40fac9:	mov    r12d,ecx
  40facc:	vxorps xmm0,xmm0,xmm0
  40fad0:	xor    eax,eax
  40fad2:	cs nop WORD PTR [rax+rax*1+0x0]
  40fadc:	nop    DWORD PTR [rax+0x0]
  40fae0:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  40fae6:	add    rax,0x10
  40faea:	cmp    rax,0x400
  40faf1:	jne    40fae0 <__swc_fn_6b1cf01f_000119_9175a56a+0x80>
  40faf3:	lea    rdi,[rsp+0x8]
  40faf8:	mov    esi,0x80
  40fafd:	xor    eax,eax
  40faff:	call   4071d0 <backtrace@plt>
  40fb04:	test   eax,eax
  40fb06:	jle    40fb15 <__swc_fn_6b1cf01f_000119_9175a56a+0xb5>
  40fb08:	movsxd rax,eax
  40fb0b:	lea    rcx,[r12+0x1]
  40fb10:	cmp    rcx,rax
  40fb13:	jb     40fb19 <__swc_fn_6b1cf01f_000119_9175a56a+0xb9>
  40fb15:	xor    eax,eax
  40fb17:	jmp    40fb4a <__swc_fn_6b1cf01f_000119_9175a56a+0xea>
  40fb19:	mov    rcx,QWORD PTR [rbx+0x8]
  40fb1d:	sub    rax,r12
  40fb20:	lea    rsi,[rax-0x1]
  40fb24:	cmp    rcx,rsi
  40fb27:	cmovbe rsi,rcx
  40fb2b:	lea    eax,[r12+0x1]
  40fb30:	lea    rax,[rsp+rax*8+0x8]
  40fb35:	mov    rcx,QWORD PTR [rbx]
  40fb38:	mov    rdx,rax
  40fb3b:	lea    r8,[rsi*8+0x0]
  40fb43:	call   409100 <__swc_fn_6b1cf01f_000105_6fd80914>
  40fb48:	mov    eax,esi
  40fb4a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  40fb53:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  40fb5c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  40fb65:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  40fb6e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  40fb77:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  40fb80:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  40fb89:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  40fb92:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  40fb9b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  40fba4:	add    rsp,0x4a8
  40fbab:	pop    rsi
  40fbac:	pop    rdi
  40fbad:	pop    r12
  40fbaf:	pop    rbx
  40fbb0:	ret
	...

000000000040fbc0 <__swc_fn_6b1cf01f_000122_e09461fd>:
  40fbc0:	mov    QWORD PTR [rcx],0x0
  40fbc7:	ret
	...

000000000040fbd0 <__swc_fn_6b1cf01f_000125_ce762363>:
  40fbd0:	push   rdi
  40fbd1:	push   rsi
  40fbd2:	sub    rsp,0xa8
  40fbd9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40fbdf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40fbe5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40fbeb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40fbf1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40fbf7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40fbfd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40fc03:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40fc09:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40fc12:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40fc1b:	mov    edi,ecx
  40fc1d:	mov    rsi,rdx
  40fc20:	xor    eax,eax
  40fc22:	call   407060 <pthread_setspecific@plt>
  40fc27:	test   eax,eax
  40fc29:	sete   al
  40fc2c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40fc32:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40fc38:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40fc3e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40fc44:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40fc4a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40fc50:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40fc56:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40fc5c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40fc65:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40fc6e:	add    rsp,0xa8
  40fc75:	pop    rsi
  40fc76:	pop    rdi
  40fc77:	ret
	...

000000000040fc80 <__swc_fn_6b1cf01f_000128_41c3251c>:
  40fc80:	push   rdi
  40fc81:	push   rsi
  40fc82:	sub    rsp,0xa8
  40fc89:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40fc8f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40fc95:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40fc9b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40fca1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40fca7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40fcad:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40fcb3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40fcb9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40fcc2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40fccb:	test   rcx,rcx
  40fcce:	je     40fce1 <__swc_fn_6b1cf01f_000128_41c3251c+0x61>
  40fcd0:	lea    rax,[rcx-0x1]
  40fcd4:	mov    eax,eax
  40fcd6:	mov    edi,eax
  40fcd8:	xor    eax,eax
  40fcda:	call   407000 <pthread_getspecific@plt>
  40fcdf:	jmp    40fce3 <__swc_fn_6b1cf01f_000128_41c3251c+0x63>
  40fce1:	xor    eax,eax
  40fce3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40fce9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40fcef:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40fcf5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40fcfb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40fd01:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40fd07:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40fd0d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40fd13:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40fd1c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40fd25:	add    rsp,0xa8
  40fd2c:	pop    rsi
  40fd2d:	pop    rdi
  40fd2e:	ret
	...

000000000040fd30 <__swc_fn_6b1cf01f_000131_944f555b>:
  40fd30:	push   rdi
  40fd31:	push   rsi
  40fd32:	sub    rsp,0xb8
  40fd39:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40fd3f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40fd45:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40fd4b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40fd51:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40fd57:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40fd5d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40fd63:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40fd6c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40fd75:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40fd7e:	vxorps xmm0,xmm0,xmm0
  40fd82:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40fd88:	mov    edi,0x1
  40fd8d:	lea    rsi,[rsp+0x8]
  40fd92:	xor    eax,eax
  40fd94:	call   407110 <clock_gettime@plt>
  40fd99:	mov    rax,QWORD PTR [rsp+0x8]
  40fd9e:	imul   rax,rax,0x3b9aca00
  40fda5:	add    rax,QWORD PTR [rsp+0x10]
  40fdaa:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40fdb0:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40fdb6:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40fdbc:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40fdc2:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40fdc8:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40fdce:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40fdd4:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40fddd:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40fde6:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40fdef:	add    rsp,0xb8
  40fdf6:	pop    rsi
  40fdf7:	pop    rdi
  40fdf8:	ret
  40fdf9:	add    BYTE PTR [rax],al
  40fdfb:	add    BYTE PTR [rax],al
  40fdfd:	add    BYTE PTR [rax],al
	...

000000000040fe00 <__swc_fn_6b1cf01f_000134_29412410>:
  40fe00:	sub    rsp,0x8
  40fe04:	xor    eax,eax
  40fe06:	mov    DWORD PTR [rcx],eax
  40fe08:	mov    edx,0x7fffffff
  40fe0d:	call   409800 <__swc_fn_6b1cf01f_000132_f908e7f9>
  40fe12:	add    rsp,0x8
  40fe16:	ret
	...

000000000040fe20 <__swc_fn_6b1cf01f_000137_a4ba10ed>:
  40fe20:	push   rdi
  40fe21:	push   rsi
  40fe22:	sub    rsp,0xb8
  40fe29:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40fe2f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40fe35:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40fe3b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40fe41:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40fe47:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40fe4d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40fe53:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40fe5c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40fe65:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40fe6e:	mov    edi,0x1
  40fe73:	xor    eax,eax
  40fe75:	call   4071e0 <__x86_get_cpuid_feature_leaf@plt>
  40fe7a:	mov    eax,DWORD PTR [rax+0x14]
  40fe7d:	and    eax,0x20
  40fe80:	setne  al
  40fe83:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40fe89:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40fe8f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40fe95:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40fe9b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40fea1:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40fea7:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40fead:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40feb6:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40febf:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40fec8:	add    rsp,0xb8
  40fecf:	pop    rsi
  40fed0:	pop    rdi
  40fed1:	ret
	...

000000000040fee0 <__swc_fn_6b1cf01f_000140_c6b99a56>:
  40fee0:	push   rsi
  40fee1:	push   rdi
  40fee2:	push   r12
  40fee4:	push   r13
  40fee6:	push   r14
  40fee8:	push   r15
  40feea:	cmp    rdx,0x40
  40feee:	jae    40fefd <__swc_fn_6b1cf01f_000140_c6b99a56+0x1d>
  40fef0:	xor    eax,eax
  40fef2:	pop    r15
  40fef4:	pop    r14
  40fef6:	pop    r13
  40fef8:	pop    r12
  40fefa:	pop    rdi
  40fefb:	pop    rsi
  40fefc:	ret
  40fefd:	cmp    BYTE PTR [rcx],0x7f
  40ff00:	jne    40ff44 <__swc_fn_6b1cf01f_000140_c6b99a56+0x64>
  40ff02:	movzx  eax,BYTE PTR [rcx+0x1]
  40ff06:	cmp    eax,0x45
  40ff09:	setne  al
  40ff0c:	jne    40ff40 <__swc_fn_6b1cf01f_000140_c6b99a56+0x60>
  40ff0e:	movzx  eax,BYTE PTR [rcx+0x2]
  40ff12:	cmp    eax,0x4c
  40ff15:	setne  al
  40ff18:	jne    40ff40 <__swc_fn_6b1cf01f_000140_c6b99a56+0x60>
  40ff1a:	movzx  eax,BYTE PTR [rcx+0x3]
  40ff1e:	cmp    eax,0x46
  40ff21:	setne  al
  40ff24:	jne    40ff40 <__swc_fn_6b1cf01f_000140_c6b99a56+0x60>
  40ff26:	cmp    BYTE PTR [rcx+0x4],0x2
  40ff2a:	setne  al
  40ff2d:	jne    40ff40 <__swc_fn_6b1cf01f_000140_c6b99a56+0x60>
  40ff2f:	cmp    BYTE PTR [rcx+0x5],0x1
  40ff33:	setne  al
  40ff36:	jne    40ff40 <__swc_fn_6b1cf01f_000140_c6b99a56+0x60>
  40ff38:	cmp    WORD PTR [rcx+0x12],0x3e
  40ff3d:	setne  al
  40ff40:	test   al,al
  40ff42:	je     40ff51 <__swc_fn_6b1cf01f_000140_c6b99a56+0x71>
  40ff44:	xor    eax,eax
  40ff46:	pop    r15
  40ff48:	pop    r14
  40ff4a:	pop    r13
  40ff4c:	pop    r12
  40ff4e:	pop    rdi
  40ff4f:	pop    rsi
  40ff50:	ret
  40ff51:	cmp    WORD PTR [rcx+0x3a],0x40
  40ff56:	jne    40ff71 <__swc_fn_6b1cf01f_000140_c6b99a56+0x91>
  40ff58:	cmp    WORD PTR [rcx+0x3c],0x0
  40ff5d:	sete   al
  40ff60:	je     40ff6d <__swc_fn_6b1cf01f_000140_c6b99a56+0x8d>
  40ff62:	mov    ax,WORD PTR [rcx+0x3c]
  40ff66:	cmp    WORD PTR [rcx+0x3e],ax
  40ff6a:	setae  al
  40ff6d:	test   al,al
  40ff6f:	je     40ff7e <__swc_fn_6b1cf01f_000140_c6b99a56+0x9e>
  40ff71:	xor    eax,eax
  40ff73:	pop    r15
  40ff75:	pop    r14
  40ff77:	pop    r13
  40ff79:	pop    r12
  40ff7b:	pop    rdi
  40ff7c:	pop    rsi
  40ff7d:	ret
  40ff7e:	movzx  eax,WORD PTR [rcx+0x3c]
  40ff82:	shl    rax,0x6
  40ff86:	cmp    rax,rdx
  40ff89:	ja     40ff97 <__swc_fn_6b1cf01f_000140_c6b99a56+0xb7>
  40ff8b:	mov    r9,rdx
  40ff8e:	sub    r9,rax
  40ff91:	cmp    QWORD PTR [rcx+0x28],r9
  40ff95:	jbe    40ffa4 <__swc_fn_6b1cf01f_000140_c6b99a56+0xc4>
  40ff97:	xor    eax,eax
  40ff99:	pop    r15
  40ff9b:	pop    r14
  40ff9d:	pop    r13
  40ff9f:	pop    r12
  40ffa1:	pop    rdi
  40ffa2:	pop    rsi
  40ffa3:	ret
  40ffa4:	mov    rax,QWORD PTR [rcx+0x28]
  40ffa8:	add    rax,rcx
  40ffab:	movzx  r9d,WORD PTR [rcx+0x3e]
  40ffb0:	lea    r9,[r9*8+0x0]
  40ffb8:	lea    r10,[rax+r9*8]
  40ffbc:	cmp    QWORD PTR [r10+0x20],rdx
  40ffc0:	ja     40ffe2 <__swc_fn_6b1cf01f_000140_c6b99a56+0x102>
  40ffc2:	mov    r11,rdx
  40ffc5:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  40ffca:	cmp    QWORD PTR [r10+0x18],r11
  40ffce:	seta   r9b
  40ffd2:	ja     40ffdd <__swc_fn_6b1cf01f_000140_c6b99a56+0xfd>
  40ffd4:	cmp    QWORD PTR [r10+0x20],0x9
  40ffd9:	setb   r9b
  40ffdd:	test   r9b,r9b
  40ffe0:	je     40ffef <__swc_fn_6b1cf01f_000140_c6b99a56+0x10f>
  40ffe2:	xor    eax,eax
  40ffe4:	pop    r15
  40ffe6:	pop    r14
  40ffe8:	pop    r13
  40ffea:	pop    r12
  40ffec:	pop    rdi
  40ffed:	pop    rsi
  40ffee:	ret
  40ffef:	movzx  r9d,WORD PTR [rcx+0x3c]
  40fff4:	xor    r11d,r11d
  40fff7:	test   r9,r9
  40fffa:	jbe    4100f5 <__swc_fn_6b1cf01f_000140_c6b99a56+0x215>
  410000:	mov    rsi,QWORD PTR [r10+0x20]
  410004:	sub    rsi,0x9
  410008:	cs nop WORD PTR [rax+rax*1+0x0]
  410012:	cs nop WORD PTR [rax+rax*1+0x0]
  41001c:	nop    DWORD PTR [rax+0x0]
  410020:	movzx  edi,r11w
  410024:	lea    rdi,[rdi*8+0x0]
  41002c:	lea    r12,[rax+rdi*8]
  410030:	rex mov edi,DWORD PTR [rax+rdi*8]
  410034:	cmp    rdi,rsi
  410037:	ja     4100e8 <__swc_fn_6b1cf01f_000140_c6b99a56+0x208>
  41003d:	mov    r13,QWORD PTR [r10+0x18]
  410041:	add    r13,rdi
  410044:	lea    rdi,[rcx+r13*1]
  410048:	lea    r13,[rip+0x34e1]        # 413530 <__swc_rdata_base_6b1cf01f+0x420>
  41004f:	movabs r14,0x676264676177732e
  410059:	cmp    QWORD PTR [rdi],r14
  41005c:	jne    410065 <__swc_fn_6b1cf01f_000140_c6b99a56+0x185>
  41005e:	rex cmp BYTE PTR [rdi+0x8],0x0
  410063:	je     410092 <__swc_fn_6b1cf01f_000140_c6b99a56+0x1b2>
  410065:	cs nop WORD PTR [rax+rax*1+0x0]
  41006f:	nop
  410070:	movzx  r14d,BYTE PTR [rdi]
  410074:	movzx  r15d,BYTE PTR [r13+0x0]
  410079:	cmp    r14,r15
  41007c:	jne    410088 <__swc_fn_6b1cf01f_000140_c6b99a56+0x1a8>
  41007e:	add    rdi,0x1
  410082:	add    r13,0x1
  410086:	jmp    410070 <__swc_fn_6b1cf01f_000140_c6b99a56+0x190>
  410088:	mov    rdi,r14
  41008b:	sub    rdi,r15
  41008e:	test   edi,edi
  410090:	jne    4100e8 <__swc_fn_6b1cf01f_000140_c6b99a56+0x208>
  410092:	cmp    DWORD PTR [r12+0x4],0x1
  410098:	jne    4100c0 <__swc_fn_6b1cf01f_000140_c6b99a56+0x1e0>
  41009a:	cmp    QWORD PTR [r12+0x20],0x10
  4100a0:	setb   al
  4100a3:	jb     4100bc <__swc_fn_6b1cf01f_000140_c6b99a56+0x1dc>
  4100a5:	cmp    QWORD PTR [r12+0x20],rdx
  4100aa:	seta   al
  4100ad:	ja     4100bc <__swc_fn_6b1cf01f_000140_c6b99a56+0x1dc>
  4100af:	sub    rdx,QWORD PTR [r12+0x20]
  4100b4:	cmp    QWORD PTR [r12+0x18],rdx
  4100b9:	seta   al
  4100bc:	test   al,al
  4100be:	je     4100cd <__swc_fn_6b1cf01f_000140_c6b99a56+0x1ed>
  4100c0:	xor    eax,eax
  4100c2:	pop    r15
  4100c4:	pop    r14
  4100c6:	pop    r13
  4100c8:	pop    r12
  4100ca:	pop    rdi
  4100cb:	pop    rsi
  4100cc:	ret
  4100cd:	mov    rax,QWORD PTR [r12+0x20]
  4100d2:	mov    QWORD PTR [r8],rax
  4100d5:	mov    rax,QWORD PTR [r12+0x18]
  4100da:	add    rax,rcx
  4100dd:	pop    r15
  4100df:	pop    r14
  4100e1:	pop    r13
  4100e3:	pop    r12
  4100e5:	pop    rdi
  4100e6:	pop    rsi
  4100e7:	ret
  4100e8:	add    r11,0x1
  4100ec:	cmp    r11,r9
  4100ef:	jb     410020 <__swc_fn_6b1cf01f_000140_c6b99a56+0x140>
  4100f5:	xor    eax,eax
  4100f7:	pop    r15
  4100f9:	pop    r14
  4100fb:	pop    r13
  4100fd:	pop    r12
  4100ff:	pop    rdi
  410100:	pop    rsi
  410101:	ret
	...

0000000000410110 <__swc_fn_6b1cf01f_000143_81c0d993>:
  410110:	push   rdi
  410111:	push   rsi
  410112:	sub    rsp,0xa8
  410119:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41011f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410125:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41012b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410131:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410137:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41013d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410143:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410149:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410152:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41015b:	mov    rdi,rcx
  41015e:	xor    eax,eax
  410160:	call   4071f0 <free@plt>
  410165:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41016b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410171:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410177:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41017d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410183:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410189:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41018f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410195:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41019e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4101a7:	add    rsp,0xa8
  4101ae:	pop    rsi
  4101af:	pop    rdi
  4101b0:	ret
	...

00000000004101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>:
  4101c0:	push   rbx
  4101c1:	push   rsi
  4101c2:	push   rdi
  4101c3:	push   r12
  4101c5:	push   r13
  4101c7:	push   r15
  4101c9:	sub    rsp,0x4e8
  4101d0:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  4101d9:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  4101e2:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  4101eb:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  4101f4:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  4101fd:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  410206:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  41020f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  410218:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  410221:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  41022a:	mov    rbx,QWORD PTR [rcx]
  41022d:	mov    rcx,QWORD PTR [rcx+0x8]
  410231:	mov    rsi,rcx
  410234:	xor    edi,edi
  410236:	vmovsd xmm6,QWORD PTR [rip+0x3352]        # 413590 <__swc_rdata_base_6b1cf01f+0x480>
  41023e:	vmovsd xmm7,QWORD PTR [rip+0x3353]        # 413599 <__swc_rdata_base_6b1cf01f+0x489>
  410246:	vmovsd xmm8,QWORD PTR [rip+0x3354]        # 4135a2 <__swc_rdata_base_6b1cf01f+0x492>
  41024e:	vmovsd xmm9,QWORD PTR [rip+0x3355]        # 4135ab <__swc_rdata_base_6b1cf01f+0x49b>
  410256:	vmovsd xmm10,QWORD PTR [rip+0x3356]        # 4135b4 <__swc_rdata_base_6b1cf01f+0x4a4>
  41025e:	vmovups xmm11,xmm6
  410262:	vmovsd QWORD PTR [rsp+0x418],xmm7
  41026b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  410274:	vmovsd QWORD PTR [rsp+0x428],xmm9
  41027d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  410286:	vmovsd xmm15,QWORD PTR [rip+0x332f]        # 4135bd <__swc_rdata_base_6b1cf01f+0x4ad>
  41028e:	vmovups xmm14,xmm15
  410293:	vmovups xmm0,xmm9
  410298:	vmovsd QWORD PTR [rsp+0x438],xmm15
  4102a1:	vmovups xmm13,xmm8
  4102a6:	vmovsd QWORD PTR [rsp+0x440],xmm15
  4102af:	test   rsi,rsi
  4102b2:	je     4112e3 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1123>
  4102b8:	cs nop WORD PTR [rax+rax*1+0x0]
  4102c2:	cs nop WORD PTR [rax+rax*1+0x0]
  4102cc:	nop    DWORD PTR [rax+0x0]
  4102d0:	lea    rcx,[rdi+rdi*1]
  4102d4:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  4102d9:	vpshufd xmm3,xmm2,0xee
  4102de:	vmovq  rcx,xmm3
  4102e3:	test   rcx,rcx
  4102e6:	je     4102fc <__swc_fn_6b1cf01f_000146_43f4fdca+0x13c>
  4102e8:	test   DWORD PTR [rcx+0x28],0x400000
  4102ef:	je     4102fc <__swc_fn_6b1cf01f_000146_43f4fdca+0x13c>
  4102f1:	mov    rdx,QWORD PTR [rcx+0x30]
  4102f5:	test   rdx,rdx
  4102f8:	cmovne rcx,rdx
  4102fc:	test   DWORD PTR [rcx+0x28],0x1000
  410303:	je     410324 <__swc_fn_6b1cf01f_000146_43f4fdca+0x164>
  410305:	mov    rdx,QWORD PTR [rcx+0x40]
  410309:	mov    rcx,rdx
  41030c:	vmovq  r8,xmm2
  410311:	mov    r8,QWORD PTR [r8]
  410314:	mov    QWORD PTR [rsp+0x60],r8
  410319:	mov    QWORD PTR [rsp+0x68],rdx
  41031e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  410324:	test   BYTE PTR [rcx+0x28],0x1
  410328:	jne    410330 <__swc_fn_6b1cf01f_000146_43f4fdca+0x170>
  41032a:	vmovups xmm12,xmm0
  41032e:	jmp    41034a <__swc_fn_6b1cf01f_000146_43f4fdca+0x18a>
  410330:	vmovq  rax,xmm2
  410335:	mov    rax,QWORD PTR [rax]
  410338:	lea    rcx,[rax+0x10]
  41033c:	vmovups xmm12,xmm0
  410340:	call   40f940 <__swc_fn_6b1cf01f_000116_035d76a1>
  410345:	jmp    4112c5 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1105>
  41034a:	test   DWORD PTR [rcx+0x28],0x400
  410351:	je     4103b2 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1f2>
  410353:	vmovq  rax,xmm2
  410358:	mov    rax,QWORD PTR [rax]
  41035b:	xor    ecx,ecx
  41035d:	test   rax,rax
  410360:	je     410390 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1d0>
  410362:	mov    rdx,rax
  410365:	mov    r8b,BYTE PTR [rdx]
  410368:	test   r8b,r8b
  41036b:	je     410390 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1d0>
  41036d:	cs nop WORD PTR [rax+rax*1+0x0]
  410377:	nop    WORD PTR [rax+rax*1+0x0]
  410380:	add    rdx,0x1
  410384:	add    rcx,0x1
  410388:	mov    r8b,BYTE PTR [rdx]
  41038b:	test   r8b,r8b
  41038e:	jne    410380 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1c0>
  410390:	mov    QWORD PTR [rsp+0x88],rax
  410398:	mov    QWORD PTR [rsp+0x90],rcx
  4103a0:	lea    rcx,[rsp+0x88]
  4103a8:	call   40f940 <__swc_fn_6b1cf01f_000116_035d76a1>
  4103ad:	jmp    4112c5 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1105>
  4103b2:	cmp    BYTE PTR [rcx+0x2c],0x6
  4103b6:	jne    4103cd <__swc_fn_6b1cf01f_000146_43f4fdca+0x20d>
  4103b8:	vmovq  rax,xmm2
  4103bd:	mov    rax,QWORD PTR [rax]
  4103c0:	mov    rcx,rax
  4103c3:	call   409cd0 <__swc_fn_6b1cf01f_000144_72996a5b>
  4103c8:	jmp    4112c5 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1105>
  4103cd:	cmp    BYTE PTR [rcx+0x2c],0x1
  4103d1:	jne    4112b9 <__swc_fn_6b1cf01f_000146_43f4fdca+0x10f9>
  4103d7:	vmovq  rdx,xmm2
  4103dc:	mov    cl,BYTE PTR [rcx+0x40]
  4103df:	cmp    cl,0x7
  4103e2:	jb     410425 <__swc_fn_6b1cf01f_000146_43f4fdca+0x265>
  4103e4:	je     410498 <__swc_fn_6b1cf01f_000146_43f4fdca+0x2d8>
  4103ea:	cmp    cl,0x8
  4103ed:	je     4104a4 <__swc_fn_6b1cf01f_000146_43f4fdca+0x2e4>
  4103f3:	cmp    cl,0x9
  4103f6:	je     4104bd <__swc_fn_6b1cf01f_000146_43f4fdca+0x2fd>
  4103fc:	cmp    cl,0xa
  4103ff:	je     410ba4 <__swc_fn_6b1cf01f_000146_43f4fdca+0x9e4>
  410405:	cmp    cl,0xb
  410408:	je     41128b <__swc_fn_6b1cf01f_000146_43f4fdca+0x10cb>
  41040e:	cmp    cl,0xc
  410411:	je     4104b1 <__swc_fn_6b1cf01f_000146_43f4fdca+0x2f1>
  410417:	cmp    cl,0xd
  41041a:	je     411281 <__swc_fn_6b1cf01f_000146_43f4fdca+0x10c1>
  410420:	jmp    4112ab <__swc_fn_6b1cf01f_000146_43f4fdca+0x10eb>
  410425:	cmp    cl,0x1
  410428:	je     410448 <__swc_fn_6b1cf01f_000146_43f4fdca+0x288>
  41042a:	cmp    cl,0x2
  41042d:	je     410456 <__swc_fn_6b1cf01f_000146_43f4fdca+0x296>
  41042f:	cmp    cl,0x3
  410432:	je     410464 <__swc_fn_6b1cf01f_000146_43f4fdca+0x2a4>
  410434:	cmp    cl,0x4
  410437:	je     410471 <__swc_fn_6b1cf01f_000146_43f4fdca+0x2b1>
  410439:	cmp    cl,0x5
  41043c:	je     41047e <__swc_fn_6b1cf01f_000146_43f4fdca+0x2be>
  41043e:	cmp    cl,0x6
  410441:	je     41048b <__swc_fn_6b1cf01f_000146_43f4fdca+0x2cb>
  410443:	jmp    4112ab <__swc_fn_6b1cf01f_000146_43f4fdca+0x10eb>
  410448:	movsx  rcx,BYTE PTR [rdx]
  41044c:	call   40cea0 <__swc_fn_6b1cf01f_000145_863755b5>
  410451:	jmp    4112c5 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1105>
  410456:	movsx  rcx,WORD PTR [rdx]
  41045a:	call   40cea0 <__swc_fn_6b1cf01f_000145_863755b5>
  41045f:	jmp    4112c5 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1105>
  410464:	movsxd rcx,DWORD PTR [rdx]
  410467:	call   40cea0 <__swc_fn_6b1cf01f_000145_863755b5>
  41046c:	jmp    4112c5 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1105>
  410471:	mov    rcx,QWORD PTR [rdx]
  410474:	call   40cea0 <__swc_fn_6b1cf01f_000145_863755b5>
  410479:	jmp    4112c5 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1105>
  41047e:	movzx  ecx,BYTE PTR [rdx]
  410481:	call   409cd0 <__swc_fn_6b1cf01f_000144_72996a5b>
  410486:	jmp    4112c5 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1105>
  41048b:	movzx  ecx,WORD PTR [rdx]
  41048e:	call   409cd0 <__swc_fn_6b1cf01f_000144_72996a5b>
  410493:	jmp    4112c5 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1105>
  410498:	mov    ecx,DWORD PTR [rdx]
  41049a:	call   409cd0 <__swc_fn_6b1cf01f_000144_72996a5b>
  41049f:	jmp    4112c5 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1105>
  4104a4:	mov    rcx,QWORD PTR [rdx]
  4104a7:	call   409cd0 <__swc_fn_6b1cf01f_000144_72996a5b>
  4104ac:	jmp    4112c5 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1105>
  4104b1:	mov    ecx,DWORD PTR [rdx]
  4104b3:	call   409cd0 <__swc_fn_6b1cf01f_000144_72996a5b>
  4104b8:	jmp    4112c5 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1105>
  4104bd:	lea    rcx,[rsp+0xa8]
  4104c5:	vxorps xmm0,xmm0,xmm0
  4104c9:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4104d2:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4104db:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4104e4:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4104ed:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  4104f6:	vmovups XMMWORD PTR [rsp+0xf8],xmm0
  4104ff:	mov    DWORD PTR [rsp+0x108],0x0
  41050a:	vxorpd xmm0,xmm0,xmm0
  41050e:	vmovss xmm1,DWORD PTR [rdx]
  410512:	vcvtss2sd xmm0,xmm0,xmm1
  410516:	vmovsd xmm1,xmm1,xmm0
  41051a:	vcomisd xmm0,xmm0
  41051e:	setne  dl
  410521:	movzx  edx,dl
  410524:	setp   r8b
  410528:	movzx  r8d,r8b
  41052c:	or     edx,r8d
  41052f:	test   dl,dl
  410531:	je     41053e <__swc_fn_6b1cf01f_000146_43f4fdca+0x37e>
  410533:	mov    DWORD PTR [rcx],0x6e616e
  410539:	jmp    410b38 <__swc_fn_6b1cf01f_000146_43f4fdca+0x978>
  41053e:	vcomisd xmm1,xmm6
  410542:	ja     41054a <__swc_fn_6b1cf01f_000146_43f4fdca+0x38a>
  410544:	vcomisd xmm7,xmm1
  410548:	jbe    41056e <__swc_fn_6b1cf01f_000146_43f4fdca+0x3ae>
  41054a:	vxorpd xmm0,xmm0,xmm0
  41054e:	vcomisd xmm0,xmm1
  410552:	jbe    410563 <__swc_fn_6b1cf01f_000146_43f4fdca+0x3a3>
  410554:	mov    DWORD PTR [rcx],0x666e692d
  41055a:	mov    BYTE PTR [rcx+0x4],0x0
  41055e:	jmp    410b38 <__swc_fn_6b1cf01f_000146_43f4fdca+0x978>
  410563:	mov    DWORD PTR [rcx],0x666e69
  410569:	jmp    410b38 <__swc_fn_6b1cf01f_000146_43f4fdca+0x978>
  41056e:	vcomisd xmm1,xmm8
  410573:	jae    41057f <__swc_fn_6b1cf01f_000146_43f4fdca+0x3bf>
  410575:	vcomisd xmm9,xmm1
  410579:	jbe    4108fe <__swc_fn_6b1cf01f_000146_43f4fdca+0x73e>
  41057f:	vmovups xmm0,xmm1
  410583:	vxorpd xmm2,xmm2,xmm2
  410587:	vcomisd xmm2,xmm1
  41058b:	jbe    41059b <__swc_fn_6b1cf01f_000146_43f4fdca+0x3db>
  41058d:	vmovsd xmm1,xmm1,xmm0
  410591:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x2fb7]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  410599:	jmp    41059f <__swc_fn_6b1cf01f_000146_43f4fdca+0x3df>
  41059b:	vmovsd xmm1,xmm1,xmm0
  41059f:	xor    r8d,r8d
  4105a2:	vcomisd xmm1,xmm15
  4105a7:	jb     4105d0 <__swc_fn_6b1cf01f_000146_43f4fdca+0x410>
  4105a9:	cs nop WORD PTR [rax+rax*1+0x0]
  4105b3:	cs nop WORD PTR [rax+rax*1+0x0]
  4105bd:	nop    DWORD PTR [rax]
  4105c0:	vdivsd xmm1,xmm1,xmm15
  4105c5:	add    r8,0x1
  4105c9:	vcomisd xmm1,xmm15
  4105ce:	jae    4105c0 <__swc_fn_6b1cf01f_000146_43f4fdca+0x400>
  4105d0:	mov    r9,rcx
  4105d3:	vxorpd xmm2,xmm2,xmm2
  4105d7:	vcomisd xmm2,xmm0
  4105db:	jbe    4105e4 <__swc_fn_6b1cf01f_000146_43f4fdca+0x424>
  4105dd:	mov    BYTE PTR [rcx],0x2d
  4105e0:	lea    r9,[rcx+0x1]
  4105e4:	vcvttsd2si rdx,xmm1
  4105e9:	mov    r10b,dl
  4105ec:	add    r10b,0x30
  4105f0:	mov    BYTE PTR [r9],r10b
  4105f3:	vxorpd xmm0,xmm0,xmm0
  4105f7:	movzx  edx,dl
  4105fa:	vcvtsi2sd xmm0,xmm0,rdx
  4105ff:	vsubsd xmm0,xmm1,xmm0
  410603:	vmulsd xmm1,xmm0,xmm15
  410608:	mov    BYTE PTR [r9+0x1],0x2e
  41060d:	vcvttsd2si rdx,xmm1
  410612:	mov    r10b,dl
  410615:	add    r10b,0x30
  410619:	mov    BYTE PTR [r9+0x2],r10b
  41061d:	vxorpd xmm0,xmm0,xmm0
  410621:	movzx  edx,dl
  410624:	vcvtsi2sd xmm0,xmm0,rdx
  410629:	vsubsd xmm0,xmm1,xmm0
  41062d:	vmulsd xmm1,xmm0,xmm15
  410632:	vcvttsd2si rdx,xmm1
  410637:	mov    r10b,dl
  41063a:	add    r10b,0x30
  41063e:	mov    BYTE PTR [r9+0x3],r10b
  410642:	vxorpd xmm0,xmm0,xmm0
  410646:	movzx  edx,dl
  410649:	vcvtsi2sd xmm0,xmm0,rdx
  41064e:	vsubsd xmm0,xmm1,xmm0
  410652:	vmulsd xmm1,xmm0,xmm15
  410657:	vcvttsd2si rdx,xmm1
  41065c:	mov    r10b,dl
  41065f:	add    r10b,0x30
  410663:	mov    BYTE PTR [r9+0x4],r10b
  410667:	vxorpd xmm0,xmm0,xmm0
  41066b:	movzx  edx,dl
  41066e:	vcvtsi2sd xmm0,xmm0,rdx
  410673:	vsubsd xmm0,xmm1,xmm0
  410677:	vmulsd xmm1,xmm0,xmm15
  41067c:	vcvttsd2si rdx,xmm1
  410681:	mov    r10b,dl
  410684:	add    r10b,0x30
  410688:	mov    BYTE PTR [r9+0x5],r10b
  41068c:	vxorpd xmm0,xmm0,xmm0
  410690:	movzx  edx,dl
  410693:	vcvtsi2sd xmm0,xmm0,rdx
  410698:	vsubsd xmm0,xmm1,xmm0
  41069c:	vmulsd xmm1,xmm0,xmm15
  4106a1:	vcvttsd2si rdx,xmm1
  4106a6:	mov    r10b,dl
  4106a9:	add    r10b,0x30
  4106ad:	mov    BYTE PTR [r9+0x6],r10b
  4106b1:	vxorpd xmm0,xmm0,xmm0
  4106b5:	movzx  edx,dl
  4106b8:	vcvtsi2sd xmm0,xmm0,rdx
  4106bd:	vsubsd xmm0,xmm1,xmm0
  4106c1:	vmulsd xmm1,xmm0,xmm15
  4106c6:	vcvttsd2si rdx,xmm1
  4106cb:	mov    r10b,dl
  4106ce:	add    r10b,0x30
  4106d2:	mov    BYTE PTR [r9+0x7],r10b
  4106d6:	vxorpd xmm0,xmm0,xmm0
  4106da:	movzx  edx,dl
  4106dd:	vcvtsi2sd xmm0,xmm0,rdx
  4106e2:	vsubsd xmm0,xmm1,xmm0
  4106e6:	vmulsd xmm1,xmm0,xmm15
  4106eb:	vcvttsd2si rdx,xmm1
  4106f0:	mov    r10b,dl
  4106f3:	add    r10b,0x30
  4106f7:	mov    BYTE PTR [r9+0x8],r10b
  4106fb:	vxorpd xmm0,xmm0,xmm0
  4106ff:	movzx  edx,dl
  410702:	vcvtsi2sd xmm0,xmm0,rdx
  410707:	vsubsd xmm0,xmm1,xmm0
  41070b:	vmulsd xmm1,xmm0,xmm15
  410710:	vcvttsd2si rdx,xmm1
  410715:	mov    r10b,dl
  410718:	add    r10b,0x30
  41071c:	mov    BYTE PTR [r9+0x9],r10b
  410720:	vxorpd xmm0,xmm0,xmm0
  410724:	movzx  edx,dl
  410727:	vcvtsi2sd xmm0,xmm0,rdx
  41072c:	vsubsd xmm0,xmm1,xmm0
  410730:	vmulsd xmm1,xmm0,xmm15
  410735:	vcvttsd2si rdx,xmm1
  41073a:	mov    r10b,dl
  41073d:	add    r10b,0x30
  410741:	mov    BYTE PTR [r9+0xa],r10b
  410745:	vxorpd xmm0,xmm0,xmm0
  410749:	movzx  edx,dl
  41074c:	vcvtsi2sd xmm0,xmm0,rdx
  410751:	vsubsd xmm0,xmm1,xmm0
  410755:	vmulsd xmm1,xmm0,xmm15
  41075a:	vcvttsd2si rdx,xmm1
  41075f:	mov    r10b,dl
  410762:	add    r10b,0x30
  410766:	mov    BYTE PTR [r9+0xb],r10b
  41076a:	lea    r10,[r9+0x4]
  41076e:	vxorpd xmm0,xmm0,xmm0
  410772:	movzx  edx,dl
  410775:	vcvtsi2sd xmm0,xmm0,rdx
  41077a:	vsubsd xmm0,xmm1,xmm0
  41077e:	vmulsd xmm1,xmm0,xmm15
  410783:	vcvttsd2si rdx,xmm1
  410788:	mov    r11b,dl
  41078b:	add    r11b,0x30
  41078f:	mov    BYTE PTR [r9+0xc],r11b
  410793:	vxorpd xmm0,xmm0,xmm0
  410797:	movzx  edx,dl
  41079a:	vcvtsi2sd xmm0,xmm0,rdx
  41079f:	vsubsd xmm0,xmm1,xmm0
  4107a3:	vmulsd xmm1,xmm0,xmm15
  4107a8:	vcvttsd2si rdx,xmm1
  4107ad:	mov    r11b,dl
  4107b0:	add    r11b,0x30
  4107b4:	mov    BYTE PTR [r9+0xd],r11b
  4107b8:	lea    r10,[r10+0x2]
  4107bc:	vxorpd xmm0,xmm0,xmm0
  4107c0:	movzx  edx,dl
  4107c3:	vcvtsi2sd xmm0,xmm0,rdx
  4107c8:	vsubsd xmm0,xmm1,xmm0
  4107cc:	vmulsd xmm1,xmm0,xmm15
  4107d1:	vcvttsd2si rdx,xmm1
  4107d6:	mov    r11b,dl
  4107d9:	add    r11b,0x30
  4107dd:	mov    BYTE PTR [r9+0xe],r11b
  4107e1:	vxorpd xmm0,xmm0,xmm0
  4107e5:	movzx  edx,dl
  4107e8:	vcvtsi2sd xmm0,xmm0,rdx
  4107ed:	vsubsd xmm0,xmm1,xmm0
  4107f1:	vmulsd xmm1,xmm0,xmm15
  4107f6:	vcvttsd2si rdx,xmm1
  4107fb:	mov    r11b,dl
  4107fe:	add    r11b,0x30
  410802:	mov    BYTE PTR [r9+0xf],r11b
  410806:	lea    r10,[r10+0x2]
  41080a:	lea    r10,[r10+0x2]
  41080e:	lea    r10,[r10+0x2]
  410812:	lea    r10,[r10+0x2]
  410816:	lea    r10,[r10+0x2]
  41081a:	vxorpd xmm0,xmm0,xmm0
  41081e:	movzx  edx,dl
  410821:	vcvtsi2sd xmm0,xmm0,rdx
  410826:	vsubsd xmm0,xmm1,xmm0
  41082a:	vmulsd xmm1,xmm0,xmm15
  41082f:	vcvttsd2si rdx,xmm1
  410834:	mov    r11b,dl
  410837:	add    r11b,0x30
  41083b:	mov    BYTE PTR [r9+0x10],r11b
  41083f:	vxorpd xmm0,xmm0,xmm0
  410843:	movzx  edx,dl
  410846:	vcvtsi2sd xmm0,xmm0,rdx
  41084b:	vsubsd xmm0,xmm1,xmm0
  41084f:	vmulsd xmm1,xmm0,xmm15
  410854:	vcvttsd2si rdx,xmm1
  410859:	add    dl,0x30
  41085c:	mov    BYTE PTR [r9+0x11],dl
  410860:	mov    BYTE PTR [r10+0x2],0x65
  410865:	lea    r9,[r10+0x3]
  410869:	test   r8,r8
  41086c:	jl     410875 <__swc_fn_6b1cf01f_000146_43f4fdca+0x6b5>
  41086e:	mov    BYTE PTR [r9],0x2b
  410872:	inc    r9
  410875:	mov    r10,r9
  410878:	mov    rdx,r8
  41087b:	nop    DWORD PTR [rax+rax*1+0x0]
  410880:	mov    r11,rdx
  410883:	movabs rdx,0x6666666666666667
  41088d:	mov    rax,r11
  410890:	imul   rdx
  410893:	sar    rdx,0x2
  410897:	mov    r12,rdx
  41089a:	shr    rdx,0x3f
  41089e:	add    r12,rdx
  4108a1:	mov    rdx,r12
  4108a4:	imul   r13,r12,0xa
  4108a8:	sub    r11,r13
  4108ab:	mov    r13,QWORD PTR [rip+0x2c8e]        # 413540 <__swc_rdata_base_6b1cf01f+0x430>
  4108b2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4108b7:	mov    BYTE PTR [r10],r11b
  4108ba:	lea    r11,[r10+0x1]
  4108be:	mov    r10,r11
  4108c1:	test   r12,r12
  4108c4:	jne    410880 <__swc_fn_6b1cf01f_000146_43f4fdca+0x6c0>
  4108c6:	test   r8,r8
  4108c9:	jge    4108d3 <__swc_fn_6b1cf01f_000146_43f4fdca+0x713>
  4108cb:	mov    BYTE PTR [r11],0x2d
  4108cf:	lea    r10,[r11+0x1]
  4108d3:	mov    BYTE PTR [r10],0x0
  4108d7:	sub    r10,0x1
  4108db:	nop    DWORD PTR [rax+rax*1+0x0]
  4108e0:	cmp    r9,r10
  4108e3:	jae    410b38 <__swc_fn_6b1cf01f_000146_43f4fdca+0x978>
  4108e9:	mov    al,BYTE PTR [r10]
  4108ec:	mov    dl,BYTE PTR [r9]
  4108ef:	mov    BYTE PTR [r10],dl
  4108f2:	sub    r10,0x1
  4108f6:	mov    BYTE PTR [r9],al
  4108f9:	inc    r9
  4108fc:	jmp    4108e0 <__swc_fn_6b1cf01f_000146_43f4fdca+0x720>
  4108fe:	vcvttsd2si rdx,xmm1
  410903:	mov    r8,rdx
  410906:	vxorpd xmm0,xmm0,xmm0
  41090a:	vcvtsi2sd xmm0,xmm0,rdx
  41090f:	vsubsd xmm0,xmm1,xmm0
  410913:	mov    r9d,0x8
  410919:	vxorpd xmm2,xmm2,xmm2
  41091d:	vcomisd xmm2,xmm0
  410921:	jbe    41092b <__swc_fn_6b1cf01f_000146_43f4fdca+0x76b>
  410923:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x2c25]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  41092b:	test   r9d,r9d
  41092e:	je     41093a <__swc_fn_6b1cf01f_000146_43f4fdca+0x77a>
  410930:	vmulsd xmm0,xmm0,xmm14
  410935:	dec    r9d
  410938:	jne    410930 <__swc_fn_6b1cf01f_000146_43f4fdca+0x770>
  41093a:	vcvttsd2si r9,xmm0
  41093f:	mov    r10,r9
  410942:	vxorpd xmm2,xmm2,xmm2
  410946:	vcvtsi2sd xmm2,xmm2,r9
  41094b:	vsubsd xmm0,xmm0,xmm2
  41094f:	vcomisd xmm0,xmm10
  410954:	lea    r9,[r9+0x1]
  410958:	cmova  r10,r9
  41095c:	cmp    r10,0x5f5e100
  410963:	jne    41097c <__swc_fn_6b1cf01f_000146_43f4fdca+0x7bc>
  410965:	lea    r8,[rdx-0x1]
  410969:	vxorpd xmm0,xmm0,xmm0
  41096d:	vcomisd xmm0,xmm1
  410971:	lea    rdx,[rdx+0x1]
  410975:	cmovbe r8,rdx
  410979:	xor    r10d,r10d
  41097c:	mov    r9,rcx
  41097f:	test   r8,r8
  410982:	jne    4109a2 <__swc_fn_6b1cf01f_000146_43f4fdca+0x7e2>
  410984:	vxorpd xmm0,xmm0,xmm0
  410988:	vcomisd xmm0,xmm1
  41098c:	jbe    410995 <__swc_fn_6b1cf01f_000146_43f4fdca+0x7d5>
  41098e:	mov    BYTE PTR [rcx],0x2d
  410991:	lea    r9,[rcx+0x1]
  410995:	mov    BYTE PTR [r9],0x30
  410999:	add    r9,0x1
  41099d:	jmp    410a3b <__swc_fn_6b1cf01f_000146_43f4fdca+0x87b>
  4109a2:	mov    r9,rcx
  4109a5:	mov    rdx,r8
  4109a8:	nop    DWORD PTR [rax+rax*1+0x0]
  4109b0:	mov    r11,rdx
  4109b3:	movabs rdx,0x6666666666666667
  4109bd:	mov    r15,rax
  4109c0:	mov    rax,r11
  4109c3:	imul   rdx
  4109c6:	mov    r12,rdx
  4109c9:	mov    rax,r15
  4109cc:	sar    r12,0x2
  4109d0:	mov    rdx,r12
  4109d3:	shr    rdx,0x3f
  4109d7:	add    r12,rdx
  4109da:	mov    rdx,r12
  4109dd:	imul   r13,r12,0xa
  4109e1:	sub    r11,r13
  4109e4:	mov    r13,QWORD PTR [rip+0x2b55]        # 413540 <__swc_rdata_base_6b1cf01f+0x430>
  4109eb:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4109f0:	mov    BYTE PTR [r9],r11b
  4109f3:	lea    r11,[r9+0x1]
  4109f7:	mov    r9,r11
  4109fa:	test   r12,r12
  4109fd:	jne    4109b0 <__swc_fn_6b1cf01f_000146_43f4fdca+0x7f0>
  4109ff:	test   r8,r8
  410a02:	jge    410a0c <__swc_fn_6b1cf01f_000146_43f4fdca+0x84c>
  410a04:	mov    BYTE PTR [r11],0x2d
  410a08:	lea    r9,[r11+0x1]
  410a0c:	mov    rdx,r9
  410a0f:	mov    BYTE PTR [r9],0x0
  410a13:	sub    r9,0x1
  410a17:	mov    r8,rcx
  410a1a:	cmp    r8,r9
  410a1d:	jae    410a38 <__swc_fn_6b1cf01f_000146_43f4fdca+0x878>
  410a1f:	nop
  410a20:	mov    r11b,BYTE PTR [r9]
  410a23:	mov    r12b,BYTE PTR [r8]
  410a26:	mov    BYTE PTR [r9],r12b
  410a29:	sub    r9,0x1
  410a2d:	mov    BYTE PTR [r8],r11b
  410a30:	inc    r8
  410a33:	cmp    r8,r9
  410a36:	jb     410a20 <__swc_fn_6b1cf01f_000146_43f4fdca+0x860>
  410a38:	mov    r9,rdx
  410a3b:	mov    BYTE PTR [r9],0x2e
  410a3f:	add    r9,0x1
  410a43:	xor    r8d,r8d
  410a46:	test   r10,r10
  410a49:	je     410a8f <__swc_fn_6b1cf01f_000146_43f4fdca+0x8cf>
  410a4b:	mov    r11d,0x989680
  410a51:	cmp    r10,r11
  410a54:	jge    410a8f <__swc_fn_6b1cf01f_000146_43f4fdca+0x8cf>
  410a56:	cs nop WORD PTR [rax+rax*1+0x0]
  410a60:	inc    r8d
  410a63:	movabs rdx,0x6666666666666667
  410a6d:	mov    r15,rax
  410a70:	mov    rax,r11
  410a73:	imul   rdx
  410a76:	mov    r11,rdx
  410a79:	mov    rax,r15
  410a7c:	sar    r11,0x2
  410a80:	mov    rdx,r11
  410a83:	shr    rdx,0x3f
  410a87:	add    r11,rdx
  410a8a:	cmp    r10,r11
  410a8d:	jl     410a60 <__swc_fn_6b1cf01f_000146_43f4fdca+0x8a0>
  410a8f:	test   r8d,r8d
  410a92:	je     410aad <__swc_fn_6b1cf01f_000146_43f4fdca+0x8ed>
  410a94:	cs nop WORD PTR [rax+rax*1+0x0]
  410a9e:	xchg   ax,ax
  410aa0:	mov    BYTE PTR [r9],0x30
  410aa4:	add    r9,0x1
  410aa8:	dec    r8d
  410aab:	jne    410aa0 <__swc_fn_6b1cf01f_000146_43f4fdca+0x8e0>
  410aad:	mov    r8,r9
  410ab0:	mov    rdx,r10
  410ab3:	cs nop WORD PTR [rax+rax*1+0x0]
  410abd:	nop    DWORD PTR [rax]
  410ac0:	mov    r11,rdx
  410ac3:	movabs rdx,0x6666666666666667
  410acd:	mov    rax,r11
  410ad0:	imul   rdx
  410ad3:	sar    rdx,0x2
  410ad7:	mov    r12,rdx
  410ada:	shr    rdx,0x3f
  410ade:	add    r12,rdx
  410ae1:	mov    rdx,r12
  410ae4:	imul   r13,r12,0xa
  410ae8:	sub    r11,r13
  410aeb:	mov    r13,QWORD PTR [rip+0x2a4e]        # 413540 <__swc_rdata_base_6b1cf01f+0x430>
  410af2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410af7:	mov    BYTE PTR [r8],r11b
  410afa:	lea    r11,[r8+0x1]
  410afe:	mov    r8,r11
  410b01:	test   r12,r12
  410b04:	jne    410ac0 <__swc_fn_6b1cf01f_000146_43f4fdca+0x900>
  410b06:	test   r10,r10
  410b09:	jge    410b13 <__swc_fn_6b1cf01f_000146_43f4fdca+0x953>
  410b0b:	mov    BYTE PTR [r11],0x2d
  410b0f:	lea    r8,[r11+0x1]
  410b13:	mov    BYTE PTR [r8],0x0
  410b17:	sub    r8,0x1
  410b1b:	cmp    r9,r8
  410b1e:	jae    410b38 <__swc_fn_6b1cf01f_000146_43f4fdca+0x978>
  410b20:	mov    al,BYTE PTR [r8]
  410b23:	mov    dl,BYTE PTR [r9]
  410b26:	mov    BYTE PTR [r8],dl
  410b29:	sub    r8,0x1
  410b2d:	mov    BYTE PTR [r9],al
  410b30:	inc    r9
  410b33:	cmp    r9,r8
  410b36:	jb     410b20 <__swc_fn_6b1cf01f_000146_43f4fdca+0x960>
  410b38:	xor    eax,eax
  410b3a:	test   rcx,rcx
  410b3d:	je     410b70 <__swc_fn_6b1cf01f_000146_43f4fdca+0x9b0>
  410b3f:	mov    rdx,rcx
  410b42:	mov    r8b,BYTE PTR [rdx]
  410b45:	test   r8b,r8b
  410b48:	je     410b70 <__swc_fn_6b1cf01f_000146_43f4fdca+0x9b0>
  410b4a:	cs nop WORD PTR [rax+rax*1+0x0]
  410b54:	cs nop WORD PTR [rax+rax*1+0x0]
  410b5e:	xchg   ax,ax
  410b60:	add    rdx,0x1
  410b64:	add    rax,0x1
  410b68:	mov    r8b,BYTE PTR [rdx]
  410b6b:	test   r8b,r8b
  410b6e:	jne    410b60 <__swc_fn_6b1cf01f_000146_43f4fdca+0x9a0>
  410b70:	mov    QWORD PTR [rsp+0x240],rcx
  410b78:	mov    QWORD PTR [rsp+0x248],rax
  410b80:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  410b89:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  410b92:	lea    rcx,[rsp+0x250]
  410b9a:	call   40f940 <__swc_fn_6b1cf01f_000116_035d76a1>
  410b9f:	jmp    4112c5 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1105>
  410ba4:	lea    rcx,[rsp+0x260]
  410bac:	vxorps xmm0,xmm0,xmm0
  410bb0:	vmovups XMMWORD PTR [rsp+0x260],xmm0
  410bb9:	vmovups XMMWORD PTR [rsp+0x270],xmm0
  410bc2:	vmovups XMMWORD PTR [rsp+0x280],xmm0
  410bcb:	vmovups XMMWORD PTR [rsp+0x290],xmm0
  410bd4:	vmovups XMMWORD PTR [rsp+0x2a0],xmm0
  410bdd:	vmovups XMMWORD PTR [rsp+0x2b0],xmm0
  410be6:	mov    DWORD PTR [rsp+0x2c0],0x0
  410bf1:	vmovsd xmm0,QWORD PTR [rdx]
  410bf5:	vcomisd xmm0,xmm0
  410bf9:	setne  dl
  410bfc:	movzx  edx,dl
  410bff:	setp   r8b
  410c03:	movzx  r8d,r8b
  410c07:	or     edx,r8d
  410c0a:	test   dl,dl
  410c0c:	je     410c19 <__swc_fn_6b1cf01f_000146_43f4fdca+0xa59>
  410c0e:	mov    DWORD PTR [rcx],0x6e616e
  410c14:	jmp    411228 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1068>
  410c19:	vcomisd xmm0,xmm11
  410c1e:	ja     410c2f <__swc_fn_6b1cf01f_000146_43f4fdca+0xa6f>
  410c20:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  410c29:	vcomisd xmm6,xmm0
  410c2d:	jbe    410c53 <__swc_fn_6b1cf01f_000146_43f4fdca+0xa93>
  410c2f:	vxorpd xmm1,xmm1,xmm1
  410c33:	vcomisd xmm1,xmm0
  410c37:	jbe    410c48 <__swc_fn_6b1cf01f_000146_43f4fdca+0xa88>
  410c39:	mov    DWORD PTR [rcx],0x666e692d
  410c3f:	mov    BYTE PTR [rcx+0x4],0x0
  410c43:	jmp    411228 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1068>
  410c48:	mov    DWORD PTR [rcx],0x666e69
  410c4e:	jmp    411228 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1068>
  410c53:	vcomisd xmm0,xmm13
  410c58:	jae    410c64 <__swc_fn_6b1cf01f_000146_43f4fdca+0xaa4>
  410c5a:	vcomisd xmm12,xmm0
  410c5e:	jbe    410fce <__swc_fn_6b1cf01f_000146_43f4fdca+0xe0e>
  410c64:	vmovups xmm1,xmm0
  410c68:	vxorpd xmm2,xmm2,xmm2
  410c6c:	vcomisd xmm2,xmm0
  410c70:	jbe    410c80 <__swc_fn_6b1cf01f_000146_43f4fdca+0xac0>
  410c72:	vmovsd xmm0,xmm0,xmm1
  410c76:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x28d2]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  410c7e:	jmp    410c84 <__swc_fn_6b1cf01f_000146_43f4fdca+0xac4>
  410c80:	vmovsd xmm0,xmm0,xmm1
  410c84:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  410c8d:	xor    r8d,r8d
  410c90:	vcomisd xmm0,xmm6
  410c94:	jb     410cae <__swc_fn_6b1cf01f_000146_43f4fdca+0xaee>
  410c96:	cs nop WORD PTR [rax+rax*1+0x0]
  410ca0:	vdivsd xmm0,xmm0,xmm6
  410ca4:	add    r8,0x1
  410ca8:	vcomisd xmm0,xmm6
  410cac:	jae    410ca0 <__swc_fn_6b1cf01f_000146_43f4fdca+0xae0>
  410cae:	mov    r9,rcx
  410cb1:	vxorpd xmm2,xmm2,xmm2
  410cb5:	vcomisd xmm2,xmm1
  410cb9:	jbe    410cc2 <__swc_fn_6b1cf01f_000146_43f4fdca+0xb02>
  410cbb:	mov    BYTE PTR [rcx],0x2d
  410cbe:	lea    r9,[rcx+0x1]
  410cc2:	vcvttsd2si rdx,xmm0
  410cc7:	mov    r10b,dl
  410cca:	add    r10b,0x30
  410cce:	mov    BYTE PTR [r9],r10b
  410cd1:	vxorpd xmm1,xmm1,xmm1
  410cd5:	movzx  edx,dl
  410cd8:	vcvtsi2sd xmm1,xmm1,rdx
  410cdd:	vsubsd xmm0,xmm0,xmm1
  410ce1:	vmulsd xmm0,xmm0,xmm6
  410ce5:	mov    BYTE PTR [r9+0x1],0x2e
  410cea:	vcvttsd2si rdx,xmm0
  410cef:	mov    r10b,dl
  410cf2:	add    r10b,0x30
  410cf6:	mov    BYTE PTR [r9+0x2],r10b
  410cfa:	vxorpd xmm1,xmm1,xmm1
  410cfe:	movzx  edx,dl
  410d01:	vcvtsi2sd xmm1,xmm1,rdx
  410d06:	vsubsd xmm0,xmm0,xmm1
  410d0a:	vmulsd xmm0,xmm0,xmm6
  410d0e:	vcvttsd2si rdx,xmm0
  410d13:	mov    r10b,dl
  410d16:	add    r10b,0x30
  410d1a:	mov    BYTE PTR [r9+0x3],r10b
  410d1e:	vxorpd xmm1,xmm1,xmm1
  410d22:	movzx  edx,dl
  410d25:	vcvtsi2sd xmm1,xmm1,rdx
  410d2a:	vsubsd xmm0,xmm0,xmm1
  410d2e:	vmulsd xmm0,xmm0,xmm6
  410d32:	vcvttsd2si rdx,xmm0
  410d37:	mov    r10b,dl
  410d3a:	add    r10b,0x30
  410d3e:	mov    BYTE PTR [r9+0x4],r10b
  410d42:	vxorpd xmm1,xmm1,xmm1
  410d46:	movzx  edx,dl
  410d49:	vcvtsi2sd xmm1,xmm1,rdx
  410d4e:	vsubsd xmm0,xmm0,xmm1
  410d52:	vmulsd xmm0,xmm0,xmm6
  410d56:	vcvttsd2si rdx,xmm0
  410d5b:	mov    r10b,dl
  410d5e:	add    r10b,0x30
  410d62:	mov    BYTE PTR [r9+0x5],r10b
  410d66:	vxorpd xmm1,xmm1,xmm1
  410d6a:	movzx  edx,dl
  410d6d:	vcvtsi2sd xmm1,xmm1,rdx
  410d72:	vsubsd xmm0,xmm0,xmm1
  410d76:	vmulsd xmm0,xmm0,xmm6
  410d7a:	vcvttsd2si rdx,xmm0
  410d7f:	mov    r10b,dl
  410d82:	add    r10b,0x30
  410d86:	mov    BYTE PTR [r9+0x6],r10b
  410d8a:	vxorpd xmm1,xmm1,xmm1
  410d8e:	movzx  edx,dl
  410d91:	vcvtsi2sd xmm1,xmm1,rdx
  410d96:	vsubsd xmm0,xmm0,xmm1
  410d9a:	vmulsd xmm0,xmm0,xmm6
  410d9e:	vcvttsd2si rdx,xmm0
  410da3:	mov    r10b,dl
  410da6:	add    r10b,0x30
  410daa:	mov    BYTE PTR [r9+0x7],r10b
  410dae:	vxorpd xmm1,xmm1,xmm1
  410db2:	movzx  edx,dl
  410db5:	vcvtsi2sd xmm1,xmm1,rdx
  410dba:	vsubsd xmm0,xmm0,xmm1
  410dbe:	vmulsd xmm0,xmm0,xmm6
  410dc2:	vcvttsd2si rdx,xmm0
  410dc7:	mov    r10b,dl
  410dca:	add    r10b,0x30
  410dce:	mov    BYTE PTR [r9+0x8],r10b
  410dd2:	vxorpd xmm1,xmm1,xmm1
  410dd6:	movzx  edx,dl
  410dd9:	vcvtsi2sd xmm1,xmm1,rdx
  410dde:	vsubsd xmm0,xmm0,xmm1
  410de2:	vmulsd xmm0,xmm0,xmm6
  410de6:	vcvttsd2si rdx,xmm0
  410deb:	mov    r10b,dl
  410dee:	add    r10b,0x30
  410df2:	mov    BYTE PTR [r9+0x9],r10b
  410df6:	vxorpd xmm1,xmm1,xmm1
  410dfa:	movzx  edx,dl
  410dfd:	vcvtsi2sd xmm1,xmm1,rdx
  410e02:	vsubsd xmm0,xmm0,xmm1
  410e06:	vmulsd xmm0,xmm0,xmm6
  410e0a:	vcvttsd2si rdx,xmm0
  410e0f:	mov    r10b,dl
  410e12:	add    r10b,0x30
  410e16:	mov    BYTE PTR [r9+0xa],r10b
  410e1a:	vxorpd xmm1,xmm1,xmm1
  410e1e:	movzx  edx,dl
  410e21:	vcvtsi2sd xmm1,xmm1,rdx
  410e26:	vsubsd xmm0,xmm0,xmm1
  410e2a:	vmulsd xmm0,xmm0,xmm6
  410e2e:	vcvttsd2si rdx,xmm0
  410e33:	mov    r10b,dl
  410e36:	add    r10b,0x30
  410e3a:	mov    BYTE PTR [r9+0xb],r10b
  410e3e:	lea    r10,[r9+0x4]
  410e42:	vxorpd xmm1,xmm1,xmm1
  410e46:	movzx  edx,dl
  410e49:	vcvtsi2sd xmm1,xmm1,rdx
  410e4e:	vsubsd xmm0,xmm0,xmm1
  410e52:	vmulsd xmm0,xmm0,xmm6
  410e56:	vcvttsd2si rdx,xmm0
  410e5b:	mov    r11b,dl
  410e5e:	add    r11b,0x30
  410e62:	mov    BYTE PTR [r9+0xc],r11b
  410e66:	vxorpd xmm1,xmm1,xmm1
  410e6a:	movzx  edx,dl
  410e6d:	vcvtsi2sd xmm1,xmm1,rdx
  410e72:	vsubsd xmm0,xmm0,xmm1
  410e76:	vmulsd xmm0,xmm0,xmm6
  410e7a:	vcvttsd2si rdx,xmm0
  410e7f:	mov    r11b,dl
  410e82:	add    r11b,0x30
  410e86:	mov    BYTE PTR [r9+0xd],r11b
  410e8a:	lea    r10,[r10+0x2]
  410e8e:	vxorpd xmm1,xmm1,xmm1
  410e92:	movzx  edx,dl
  410e95:	vcvtsi2sd xmm1,xmm1,rdx
  410e9a:	vsubsd xmm0,xmm0,xmm1
  410e9e:	vmulsd xmm0,xmm0,xmm6
  410ea2:	vcvttsd2si rdx,xmm0
  410ea7:	mov    r11b,dl
  410eaa:	add    r11b,0x30
  410eae:	mov    BYTE PTR [r9+0xe],r11b
  410eb2:	vxorpd xmm1,xmm1,xmm1
  410eb6:	movzx  edx,dl
  410eb9:	vcvtsi2sd xmm1,xmm1,rdx
  410ebe:	vsubsd xmm0,xmm0,xmm1
  410ec2:	vmulsd xmm0,xmm0,xmm6
  410ec6:	vcvttsd2si rdx,xmm0
  410ecb:	mov    r11b,dl
  410ece:	add    r11b,0x30
  410ed2:	mov    BYTE PTR [r9+0xf],r11b
  410ed6:	lea    r10,[r10+0x2]
  410eda:	lea    r10,[r10+0x2]
  410ede:	lea    r10,[r10+0x2]
  410ee2:	lea    r10,[r10+0x2]
  410ee6:	lea    r10,[r10+0x2]
  410eea:	vxorpd xmm1,xmm1,xmm1
  410eee:	movzx  edx,dl
  410ef1:	vcvtsi2sd xmm1,xmm1,rdx
  410ef6:	vsubsd xmm0,xmm0,xmm1
  410efa:	vmulsd xmm0,xmm0,xmm6
  410efe:	vcvttsd2si rdx,xmm0
  410f03:	mov    r11b,dl
  410f06:	add    r11b,0x30
  410f0a:	mov    BYTE PTR [r9+0x10],r11b
  410f0e:	vxorpd xmm1,xmm1,xmm1
  410f12:	movzx  edx,dl
  410f15:	vcvtsi2sd xmm1,xmm1,rdx
  410f1a:	vsubsd xmm0,xmm0,xmm1
  410f1e:	vmulsd xmm0,xmm0,xmm6
  410f22:	vcvttsd2si rdx,xmm0
  410f27:	add    dl,0x30
  410f2a:	mov    BYTE PTR [r9+0x11],dl
  410f2e:	mov    BYTE PTR [r10+0x2],0x65
  410f33:	lea    r9,[r10+0x3]
  410f37:	test   r8,r8
  410f3a:	jl     410f43 <__swc_fn_6b1cf01f_000146_43f4fdca+0xd83>
  410f3c:	mov    BYTE PTR [r9],0x2b
  410f40:	inc    r9
  410f43:	mov    r10,r9
  410f46:	mov    rdx,r8
  410f49:	nop    DWORD PTR [rax+0x0]
  410f50:	mov    r11,rdx
  410f53:	movabs rdx,0x6666666666666667
  410f5d:	mov    rax,r11
  410f60:	imul   rdx
  410f63:	sar    rdx,0x2
  410f67:	mov    r12,rdx
  410f6a:	shr    rdx,0x3f
  410f6e:	add    r12,rdx
  410f71:	mov    rdx,r12
  410f74:	imul   r13,r12,0xa
  410f78:	sub    r11,r13
  410f7b:	mov    r13,QWORD PTR [rip+0x25be]        # 413540 <__swc_rdata_base_6b1cf01f+0x430>
  410f82:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410f87:	mov    BYTE PTR [r10],r11b
  410f8a:	lea    r11,[r10+0x1]
  410f8e:	mov    r10,r11
  410f91:	test   r12,r12
  410f94:	jne    410f50 <__swc_fn_6b1cf01f_000146_43f4fdca+0xd90>
  410f96:	test   r8,r8
  410f99:	jge    410fa3 <__swc_fn_6b1cf01f_000146_43f4fdca+0xde3>
  410f9b:	mov    BYTE PTR [r11],0x2d
  410f9f:	lea    r10,[r11+0x1]
  410fa3:	mov    BYTE PTR [r10],0x0
  410fa7:	sub    r10,0x1
  410fab:	nop    DWORD PTR [rax+rax*1+0x0]
  410fb0:	cmp    r9,r10
  410fb3:	jae    411228 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1068>
  410fb9:	mov    al,BYTE PTR [r10]
  410fbc:	mov    dl,BYTE PTR [r9]
  410fbf:	mov    BYTE PTR [r10],dl
  410fc2:	sub    r10,0x1
  410fc6:	mov    BYTE PTR [r9],al
  410fc9:	inc    r9
  410fcc:	jmp    410fb0 <__swc_fn_6b1cf01f_000146_43f4fdca+0xdf0>
  410fce:	vcvttsd2si rdx,xmm0
  410fd3:	mov    r8,rdx
  410fd6:	vxorpd xmm1,xmm1,xmm1
  410fda:	vcvtsi2sd xmm1,xmm1,rdx
  410fdf:	vsubsd xmm1,xmm0,xmm1
  410fe3:	mov    r9d,0x8
  410fe9:	vxorpd xmm2,xmm2,xmm2
  410fed:	vcomisd xmm2,xmm1
  410ff1:	ja     410ffe <__swc_fn_6b1cf01f_000146_43f4fdca+0xe3e>
  410ff3:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  410ffc:	jmp    41100f <__swc_fn_6b1cf01f_000146_43f4fdca+0xe4f>
  410ffe:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x254a]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  411006:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41100f:	test   r9d,r9d
  411012:	je     411029 <__swc_fn_6b1cf01f_000146_43f4fdca+0xe69>
  411014:	cs nop WORD PTR [rax+rax*1+0x0]
  41101e:	xchg   ax,ax
  411020:	vmulsd xmm1,xmm1,xmm6
  411024:	dec    r9d
  411027:	jne    411020 <__swc_fn_6b1cf01f_000146_43f4fdca+0xe60>
  411029:	vcvttsd2si r9,xmm1
  41102e:	mov    r10,r9
  411031:	vxorpd xmm2,xmm2,xmm2
  411035:	vcvtsi2sd xmm2,xmm2,r9
  41103a:	vsubsd xmm1,xmm1,xmm2
  41103e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  411047:	vcomisd xmm1,xmm6
  41104b:	lea    r9,[r9+0x1]
  41104f:	cmova  r10,r9
  411053:	cmp    r10,0x5f5e100
  41105a:	jne    411073 <__swc_fn_6b1cf01f_000146_43f4fdca+0xeb3>
  41105c:	lea    r8,[rdx-0x1]
  411060:	vxorpd xmm1,xmm1,xmm1
  411064:	vcomisd xmm1,xmm0
  411068:	lea    rdx,[rdx+0x1]
  41106c:	cmovbe r8,rdx
  411070:	xor    r10d,r10d
  411073:	mov    r9,rcx
  411076:	test   r8,r8
  411079:	jne    411099 <__swc_fn_6b1cf01f_000146_43f4fdca+0xed9>
  41107b:	vxorpd xmm1,xmm1,xmm1
  41107f:	vcomisd xmm1,xmm0
  411083:	jbe    41108c <__swc_fn_6b1cf01f_000146_43f4fdca+0xecc>
  411085:	mov    BYTE PTR [rcx],0x2d
  411088:	lea    r9,[rcx+0x1]
  41108c:	mov    BYTE PTR [r9],0x30
  411090:	add    r9,0x1
  411094:	jmp    41112b <__swc_fn_6b1cf01f_000146_43f4fdca+0xf6b>
  411099:	mov    r9,rcx
  41109c:	mov    rdx,r8
  41109f:	nop
  4110a0:	mov    r11,rdx
  4110a3:	movabs rdx,0x6666666666666667
  4110ad:	mov    r15,rax
  4110b0:	mov    rax,r11
  4110b3:	imul   rdx
  4110b6:	mov    r12,rdx
  4110b9:	mov    rax,r15
  4110bc:	sar    r12,0x2
  4110c0:	mov    rdx,r12
  4110c3:	shr    rdx,0x3f
  4110c7:	add    r12,rdx
  4110ca:	mov    rdx,r12
  4110cd:	imul   r13,r12,0xa
  4110d1:	sub    r11,r13
  4110d4:	mov    r13,QWORD PTR [rip+0x2465]        # 413540 <__swc_rdata_base_6b1cf01f+0x430>
  4110db:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4110e0:	mov    BYTE PTR [r9],r11b
  4110e3:	lea    r11,[r9+0x1]
  4110e7:	mov    r9,r11
  4110ea:	test   r12,r12
  4110ed:	jne    4110a0 <__swc_fn_6b1cf01f_000146_43f4fdca+0xee0>
  4110ef:	test   r8,r8
  4110f2:	jge    4110fc <__swc_fn_6b1cf01f_000146_43f4fdca+0xf3c>
  4110f4:	mov    BYTE PTR [r11],0x2d
  4110f8:	lea    r9,[r11+0x1]
  4110fc:	mov    rdx,r9
  4110ff:	mov    BYTE PTR [r9],0x0
  411103:	sub    r9,0x1
  411107:	mov    r8,rcx
  41110a:	cmp    r8,r9
  41110d:	jae    411128 <__swc_fn_6b1cf01f_000146_43f4fdca+0xf68>
  41110f:	nop
  411110:	mov    r11b,BYTE PTR [r9]
  411113:	mov    r12b,BYTE PTR [r8]
  411116:	mov    BYTE PTR [r9],r12b
  411119:	sub    r9,0x1
  41111d:	mov    BYTE PTR [r8],r11b
  411120:	inc    r8
  411123:	cmp    r8,r9
  411126:	jb     411110 <__swc_fn_6b1cf01f_000146_43f4fdca+0xf50>
  411128:	mov    r9,rdx
  41112b:	mov    BYTE PTR [r9],0x2e
  41112f:	add    r9,0x1
  411133:	xor    r8d,r8d
  411136:	test   r10,r10
  411139:	je     41117f <__swc_fn_6b1cf01f_000146_43f4fdca+0xfbf>
  41113b:	mov    r11d,0x989680
  411141:	cmp    r10,r11
  411144:	jge    41117f <__swc_fn_6b1cf01f_000146_43f4fdca+0xfbf>
  411146:	cs nop WORD PTR [rax+rax*1+0x0]
  411150:	inc    r8d
  411153:	movabs rdx,0x6666666666666667
  41115d:	mov    r15,rax
  411160:	mov    rax,r11
  411163:	imul   rdx
  411166:	mov    r11,rdx
  411169:	mov    rax,r15
  41116c:	sar    r11,0x2
  411170:	mov    rdx,r11
  411173:	shr    rdx,0x3f
  411177:	add    r11,rdx
  41117a:	cmp    r10,r11
  41117d:	jl     411150 <__swc_fn_6b1cf01f_000146_43f4fdca+0xf90>
  41117f:	test   r8d,r8d
  411182:	je     41119d <__swc_fn_6b1cf01f_000146_43f4fdca+0xfdd>
  411184:	cs nop WORD PTR [rax+rax*1+0x0]
  41118e:	xchg   ax,ax
  411190:	mov    BYTE PTR [r9],0x30
  411194:	add    r9,0x1
  411198:	dec    r8d
  41119b:	jne    411190 <__swc_fn_6b1cf01f_000146_43f4fdca+0xfd0>
  41119d:	mov    r8,r9
  4111a0:	mov    rdx,r10
  4111a3:	cs nop WORD PTR [rax+rax*1+0x0]
  4111ad:	nop    DWORD PTR [rax]
  4111b0:	mov    r11,rdx
  4111b3:	movabs rdx,0x6666666666666667
  4111bd:	mov    rax,r11
  4111c0:	imul   rdx
  4111c3:	sar    rdx,0x2
  4111c7:	mov    r12,rdx
  4111ca:	shr    rdx,0x3f
  4111ce:	add    r12,rdx
  4111d1:	mov    rdx,r12
  4111d4:	imul   r13,r12,0xa
  4111d8:	sub    r11,r13
  4111db:	mov    r13,QWORD PTR [rip+0x235e]        # 413540 <__swc_rdata_base_6b1cf01f+0x430>
  4111e2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4111e7:	mov    BYTE PTR [r8],r11b
  4111ea:	lea    r11,[r8+0x1]
  4111ee:	mov    r8,r11
  4111f1:	test   r12,r12
  4111f4:	jne    4111b0 <__swc_fn_6b1cf01f_000146_43f4fdca+0xff0>
  4111f6:	test   r10,r10
  4111f9:	jge    411203 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1043>
  4111fb:	mov    BYTE PTR [r11],0x2d
  4111ff:	lea    r8,[r11+0x1]
  411203:	mov    BYTE PTR [r8],0x0
  411207:	sub    r8,0x1
  41120b:	cmp    r9,r8
  41120e:	jae    411228 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1068>
  411210:	mov    al,BYTE PTR [r8]
  411213:	mov    dl,BYTE PTR [r9]
  411216:	mov    BYTE PTR [r8],dl
  411219:	sub    r8,0x1
  41121d:	mov    BYTE PTR [r9],al
  411220:	inc    r9
  411223:	cmp    r9,r8
  411226:	jb     411210 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1050>
  411228:	xor    eax,eax
  41122a:	test   rcx,rcx
  41122d:	je     411250 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1090>
  41122f:	mov    rdx,rcx
  411232:	mov    r8b,BYTE PTR [rdx]
  411235:	test   r8b,r8b
  411238:	je     411250 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1090>
  41123a:	nop    WORD PTR [rax+rax*1+0x0]
  411240:	add    rdx,0x1
  411244:	add    rax,0x1
  411248:	mov    r8b,BYTE PTR [rdx]
  41124b:	test   r8b,r8b
  41124e:	jne    411240 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1080>
  411250:	mov    QWORD PTR [rsp+0x3f8],rcx
  411258:	mov    QWORD PTR [rsp+0x400],rax
  411260:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  411269:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  411272:	lea    rcx,[rsp+0x408]
  41127a:	call   40f940 <__swc_fn_6b1cf01f_000116_035d76a1>
  41127f:	jmp    4112c5 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1105>
  411281:	mov    rcx,rdx
  411284:	call   40f940 <__swc_fn_6b1cf01f_000116_035d76a1>
  411289:	jmp    4112c5 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1105>
  41128b:	mov    al,BYTE PTR [rdx]
  41128d:	test   al,al
  41128f:	je     41129a <__swc_fn_6b1cf01f_000146_43f4fdca+0x10da>
  411291:	lea    rax,[rip+0x22c8]        # 413560 <__swc_rdata_base_6b1cf01f+0x450>
  411298:	jmp    4112a1 <__swc_fn_6b1cf01f_000146_43f4fdca+0x10e1>
  41129a:	lea    rax,[rip+0x22cf]        # 413570 <__swc_rdata_base_6b1cf01f+0x460>
  4112a1:	mov    rcx,rax
  4112a4:	call   40f940 <__swc_fn_6b1cf01f_000116_035d76a1>
  4112a9:	jmp    4112c5 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1105>
  4112ab:	lea    rcx,[rip+0x22ce]        # 413580 <__swc_rdata_base_6b1cf01f+0x470>
  4112b2:	call   40f940 <__swc_fn_6b1cf01f_000116_035d76a1>
  4112b7:	jmp    4112c5 <__swc_fn_6b1cf01f_000146_43f4fdca+0x1105>
  4112b9:	lea    rcx,[rip+0x22c0]        # 413580 <__swc_rdata_base_6b1cf01f+0x470>
  4112c0:	call   40f940 <__swc_fn_6b1cf01f_000116_035d76a1>
  4112c5:	add    rdi,0x1
  4112c9:	sub    rsi,0x1
  4112cd:	vmovups xmm0,xmm12
  4112d2:	vmovsd xmm6,QWORD PTR [rip+0x22b6]        # 413590 <__swc_rdata_base_6b1cf01f+0x480>
  4112da:	test   rsi,rsi
  4112dd:	jne    4102d0 <__swc_fn_6b1cf01f_000146_43f4fdca+0x110>
  4112e3:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  4112ec:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  4112f5:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  4112fe:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411307:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411310:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411319:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411322:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  41132b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411334:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  41133d:	add    rsp,0x4e8
  411344:	pop    r15
  411346:	pop    r13
  411348:	pop    r12
  41134a:	pop    rdi
  41134b:	pop    rsi
  41134c:	pop    rbx
  41134d:	ret
	...

0000000000411350 <__swc_fn_6b1cf01f_000149_9e4bc402>:
  411350:	vxorps xmm0,xmm0,xmm0
  411354:	vmovups XMMWORD PTR [rcx],xmm0
  411358:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41135d:	ret
	...

0000000000411360 <__swc_fn_6b1cf01f_000152_9e4bc402>:
  411360:	vxorps xmm0,xmm0,xmm0
  411364:	vmovups XMMWORD PTR [rcx],xmm0
  411368:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41136d:	vxorps xmm0,xmm0,xmm0
  411371:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411376:	vmovups xmm0,XMMWORD PTR [rip+0x2322]        # 4136a0 <__swc_rdata_base_6b1cf01f+0x590>
  41137e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411383:	vxorps xmm0,xmm0,xmm0
  411387:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  41138c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411391:	vxorps xmm0,xmm0,xmm0
  411395:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  41139a:	mov    QWORD PTR [rcx+0x70],0x0
  4113a2:	ret
	...

00000000004113b0 <__swc_fn_6b1cf01f_000155_9e4bc402>:
  4113b0:	vxorps xmm0,xmm0,xmm0
  4113b4:	vmovups XMMWORD PTR [rcx],xmm0
  4113b8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4113bd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4113c2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4113c7:	ret
	...

00000000004113d0 <__swc_fn_6b1cf01f_000158_b43b2f96>:
  4113d0:	push   rsi
  4113d1:	push   rdi
  4113d2:	sub    rsp,0x8
  4113d6:	mov    rsi,rcx
  4113d9:	mov    rdi,QWORD PTR [rsi+0x50]
  4113dd:	test   rdi,rdi
  4113e0:	je     4113e7 <__swc_fn_6b1cf01f_000158_b43b2f96+0x17>
  4113e2:	mov    rcx,rsi
  4113e5:	call   rdi
  4113e7:	mov    QWORD PTR [rsi+0x20],0x0
  4113ef:	mov    rax,QWORD PTR [rsi+0x30]
  4113f3:	test   rax,rax
  4113f6:	je     411424 <__swc_fn_6b1cf01f_000158_b43b2f96+0x54>
  4113f8:	nop    DWORD PTR [rax+rax*1+0x0]
  411400:	mov    rdi,QWORD PTR [rax+0x8]
  411404:	mov    rcx,rsi
  411407:	mov    rdx,QWORD PTR [rax+0x10]
  41140b:	mov    rax,QWORD PTR [rax+0x18]
  41140f:	mov    r8,rax
  411412:	call   409ec0 <__swc_fn_6b1cf01f_000156_2745c4a5>
  411417:	mov    QWORD PTR [rsi+0x30],rdi
  41141b:	mov    rax,QWORD PTR [rsi+0x30]
  41141f:	test   rax,rax
  411422:	jne    411400 <__swc_fn_6b1cf01f_000158_b43b2f96+0x30>
  411424:	mov    QWORD PTR [rsi+0x38],0x0
  41142c:	add    rsp,0x8
  411430:	pop    rdi
  411431:	pop    rsi
  411432:	ret
	...

0000000000411440 <__swc_fn_6b1cf01f_000161_b5a9d657>:
  411440:	push   rbx
  411441:	push   rsi
  411442:	push   rdi
  411443:	push   r12
  411445:	sub    rsp,0x188
  41144c:	mov    rbx,rcx
  41144f:	lea    rsi,[rip+0x1593a]        # 426d90 <__swc_bss_base_6b1cf01f+0x2d50>
  411456:	mov    rcx,rsi
  411459:	call   4098c0 <__swc_fn_6b1cf01f_000135_e3032dc2>
  41145e:	mov    rax,QWORD PTR [rip+0x15933]        # 426d98 <__swc_bss_base_6b1cf01f+0x2d58>
  411465:	mov    rdi,rax
  411468:	test   rdi,rdi
  41146b:	je     411499 <__swc_fn_6b1cf01f_000161_b5a9d657+0x59>
  41146d:	nop    DWORD PTR [rax]
  411470:	cmp    QWORD PTR [rdi+0x8],rbx
  411474:	jne    41148e <__swc_fn_6b1cf01f_000161_b5a9d657+0x4e>
  411476:	mov    rcx,rsi
  411479:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  41147e:	mov    rax,rdi
  411481:	add    rsp,0x188
  411488:	pop    r12
  41148a:	pop    rdi
  41148b:	pop    rsi
  41148c:	pop    rbx
  41148d:	ret
  41148e:	mov    rax,QWORD PTR [rdi]
  411491:	mov    rdi,rax
  411494:	test   rax,rax
  411497:	jne    411470 <__swc_fn_6b1cf01f_000161_b5a9d657+0x30>
  411499:	call   40cdc0 <__swc_fn_6b1cf01f_000139_7c02fe26>
  41149e:	mov    rdi,rax
  4114a1:	test   rax,rax
  4114a4:	jne    4114bd <__swc_fn_6b1cf01f_000161_b5a9d657+0x7d>
  4114a6:	mov    rcx,rsi
  4114a9:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  4114ae:	xor    eax,eax
  4114b0:	add    rsp,0x188
  4114b7:	pop    r12
  4114b9:	pop    rdi
  4114ba:	pop    rsi
  4114bb:	pop    rbx
  4114bc:	ret
  4114bd:	lea    rax,[rsp+0x18]
  4114c2:	mov    QWORD PTR [rax+0x10],0x0
  4114ca:	mov    QWORD PTR [rax+0x18],0x0
  4114d2:	mov    DWORD PTR [rax+0x20],0x0
  4114d9:	mov    BYTE PTR [rax+0x24],0x0
  4114dd:	mov    rax,QWORD PTR [rip+0x158b4]        # 426d98 <__swc_bss_base_6b1cf01f+0x2d58>
  4114e4:	mov    QWORD PTR [rsp+0x18],rax
  4114e9:	mov    QWORD PTR [rsp+0x20],rbx
  4114ee:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  4114f4:	vmovups XMMWORD PTR [rdi],xmm0
  4114f8:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  4114fe:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  411503:	mov    rax,QWORD PTR [rsp+0x38]
  411508:	mov    QWORD PTR [rdi+0x20],rax
  41150c:	mov    QWORD PTR [rip+0x15885],rdi        # 426d98 <__swc_bss_base_6b1cf01f+0x2d58>
  411513:	lea    rax,[rsp+0x40]
  411518:	mov    QWORD PTR [rax],0x0
  41151f:	mov    rcx,rbx
  411522:	mov    rdx,rax
  411525:	call   4099a0 <__swc_fn_6b1cf01f_000141_2ce79e3b>
  41152a:	mov    rbx,rax
  41152d:	test   rax,rax
  411530:	jne    41154a <__swc_fn_6b1cf01f_000161_b5a9d657+0x10a>
  411532:	mov    rcx,rsi
  411535:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  41153a:	mov    rax,rdi
  41153d:	add    rsp,0x188
  411544:	pop    r12
  411546:	pop    rdi
  411547:	pop    rsi
  411548:	pop    rbx
  411549:	ret
  41154a:	lea    r12,[rsp+0x50]
  41154f:	mov    QWORD PTR [r12],0x0
  411557:	mov    rcx,rbx
  41155a:	mov    rdx,QWORD PTR [rsp+0x40]
  41155f:	mov    r8,r12
  411562:	call   40ce70 <__swc_fn_6b1cf01f_000142_56e56812>
  411567:	test   rax,rax
  41156a:	jne    411584 <__swc_fn_6b1cf01f_000161_b5a9d657+0x144>
  41156c:	mov    rcx,rsi
  41156f:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  411574:	mov    rax,rdi
  411577:	add    rsp,0x188
  41157e:	pop    r12
  411580:	pop    rdi
  411581:	pop    rsi
  411582:	pop    rbx
  411583:	ret
  411584:	cmp    QWORD PTR [r12],0x10
  411589:	jb     41168c <__swc_fn_6b1cf01f_000161_b5a9d657+0x24c>
  41158f:	mov    ecx,DWORD PTR [rax]
  411591:	cmp    ecx,0x42445753
  411597:	jne    41168c <__swc_fn_6b1cf01f_000161_b5a9d657+0x24c>
  41159d:	mov    ecx,DWORD PTR [rax+0x4]
  4115a0:	cmp    ecx,0x1
  4115a3:	jne    41168c <__swc_fn_6b1cf01f_000161_b5a9d657+0x24c>
  4115a9:	mov    ecx,DWORD PTR [rax+0x8]
  4115ac:	mov    edx,DWORD PTR [rax+0xc]
  4115af:	imul   r8,rcx,0x14
  4115b3:	mov    r9,QWORD PTR [rsp+0x50]
  4115b8:	sub    r9,0x10
  4115bc:	cmp    r8,r9
  4115bf:	ja     41168c <__swc_fn_6b1cf01f_000161_b5a9d657+0x24c>
  4115c5:	lea    r8,[r8+0x10]
  4115c9:	cmp    rdx,r8
  4115cc:	jb     41168c <__swc_fn_6b1cf01f_000161_b5a9d657+0x24c>
  4115d2:	mov    r8,QWORD PTR [rsp+0x50]
  4115d7:	cmp    rdx,r8
  4115da:	ja     41168c <__swc_fn_6b1cf01f_000161_b5a9d657+0x24c>
  4115e0:	xor    r8d,r8d
  4115e3:	test   rcx,rcx
  4115e6:	jbe    4116b2 <__swc_fn_6b1cf01f_000161_b5a9d657+0x272>
  4115ec:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  4115f2:	cs nop WORD PTR [rax+rax*1+0x0]
  4115fc:	nop    DWORD PTR [rax+0x0]
  411600:	imul   r9,r8,0x14
  411604:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  411609:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  41160e:	add    r10,r11
  411611:	movabs r11,0x100000000
  41161b:	cmp    r10,r11
  41161e:	ja     41168c <__swc_fn_6b1cf01f_000161_b5a9d657+0x24c>
  411620:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  411625:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  41162a:	test   r10d,r10d
  41162d:	setne  r11b
  411631:	je     41164b <__swc_fn_6b1cf01f_000161_b5a9d657+0x20b>
  411633:	cmp    r10d,edx
  411636:	setb   r11b
  41163a:	jb     41164b <__swc_fn_6b1cf01f_000161_b5a9d657+0x20b>
  41163c:	vmovq  r11,xmm1
  411641:	cmp    r10,r11
  411644:	setae  r10b
  411648:	mov    r11b,r10b
  41164b:	mov    r10,r11
  41164e:	test   r11b,r11b
  411651:	jne    411678 <__swc_fn_6b1cf01f_000161_b5a9d657+0x238>
  411653:	test   r9d,r9d
  411656:	setne  r10b
  41165a:	je     411678 <__swc_fn_6b1cf01f_000161_b5a9d657+0x238>
  41165c:	cmp    r9d,edx
  41165f:	setb   r10b
  411663:	jb     411678 <__swc_fn_6b1cf01f_000161_b5a9d657+0x238>
  411665:	vmovq  r10,xmm1
  41166a:	cmp    r9,r10
  41166d:	setae  r9b
  411671:	movzx  r9d,r9b
  411675:	mov    r10b,r9b
  411678:	test   r10b,r10b
  41167b:	jne    41168c <__swc_fn_6b1cf01f_000161_b5a9d657+0x24c>
  41167d:	add    r8,0x1
  411681:	cmp    r8,rcx
  411684:	jb     411600 <__swc_fn_6b1cf01f_000161_b5a9d657+0x1c0>
  41168a:	jmp    4116b2 <__swc_fn_6b1cf01f_000161_b5a9d657+0x272>
  41168c:	xor    ecx,ecx
  41168e:	cmp    rax,rbx
  411691:	cmovne rcx,rax
  411695:	call   410110 <__swc_fn_6b1cf01f_000143_81c0d993>
  41169a:	mov    rcx,rsi
  41169d:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  4116a2:	mov    rax,rdi
  4116a5:	add    rsp,0x188
  4116ac:	pop    r12
  4116ae:	pop    rdi
  4116af:	pop    rsi
  4116b0:	pop    rbx
  4116b1:	ret
  4116b2:	mov    QWORD PTR [rdi+0x10],rax
  4116b6:	mov    rcx,QWORD PTR [rsp+0x50]
  4116bb:	mov    QWORD PTR [rdi+0x18],rcx
  4116bf:	mov    eax,DWORD PTR [rax+0x8]
  4116c2:	mov    DWORD PTR [rdi+0x20],eax
  4116c5:	rex mov BYTE PTR [rdi+0x24],0x1
  4116ca:	mov    rcx,rsi
  4116cd:	call   40cdb0 <__swc_fn_6b1cf01f_000136_3e875c27>
  4116d2:	mov    rax,rdi
  4116d5:	add    rsp,0x188
  4116dc:	pop    r12
  4116de:	pop    rdi
  4116df:	pop    rsi
  4116e0:	pop    rbx
  4116e1:	ret
	...

00000000004116f0 <__swc_fn_6b1cf01f_000164_1962e12a>:
  4116f0:	push   rsi
  4116f1:	push   rdi
  4116f2:	push   r12
  4116f4:	mov    rsi,rdx
  4116f7:	mov    rdi,rcx
  4116fa:	mov    rcx,QWORD PTR [rip+0x1563f]        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  411701:	test   rcx,rcx
  411704:	jne    411716 <__swc_fn_6b1cf01f_000164_1962e12a+0x26>
  411706:	call   40a1d0 <__swc_fn_6b1cf01f_000165_cf398896>
  41170b:	lea    rcx,[rax+0x1]
  41170f:	mov    QWORD PTR [rip+0x1562a],rcx        # 426d40 <__swc_bss_base_6b1cf01f+0x2d00>
  411716:	dec    rcx
  411719:	call   411740 <__swc_fn_6b1cf01f_000167_fce60b2b>
  41171e:	mov    r12,QWORD PTR [rax+0xbe0]
  411725:	test   r12,r12
  411728:	setne  al
  41172b:	je     411736 <__swc_fn_6b1cf01f_000164_1962e12a+0x46>
  41172d:	mov    rcx,rdi
  411730:	mov    rdx,rsi
  411733:	call   r12
  411736:	pop    r12
  411738:	pop    rdi
  411739:	pop    rsi
  41173a:	ret
  41173b:	add    BYTE PTR [rax],al
  41173d:	add    BYTE PTR [rax],al
	...

0000000000411740 <__swc_fn_6b1cf01f_000167_fce60b2b>:
  411740:	push   r12
  411742:	push   rdi
  411743:	push   rsi
  411744:	sub    rsp,0xd0
  41174b:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  411751:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  411757:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  41175d:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  411763:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  411769:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  41176f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  411778:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  411781:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  41178a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  411793:	mov    r12,rcx
  411796:	mov    edi,ecx
  411798:	xor    eax,eax
  41179a:	call   407000 <pthread_getspecific@plt>
  41179f:	test   rax,rax
  4117a2:	je     4117a6 <__swc_fn_6b1cf01f_000167_fce60b2b+0x66>
  4117a4:	jmp    4117ae <__swc_fn_6b1cf01f_000167_fce60b2b+0x6e>
  4117a6:	mov    rcx,r12
  4117a9:	call   40a230 <__swc_fn_6b1cf01f_000168_92b7d63c>
  4117ae:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  4117b4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  4117ba:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  4117c0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  4117c6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  4117cc:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  4117d2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  4117db:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  4117e4:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  4117ed:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  4117f6:	add    rsp,0xd0
  4117fd:	pop    rsi
  4117fe:	pop    rdi
  4117ff:	pop    r12
  411801:	ret
	...

0000000000411810 <__swc_fn_6b1cf01f_000170_fa3003e2>:
  411810:	push   rsi
  411811:	sub    rsp,0x30
  411815:	lea    rsi,[rip+0x1558c]        # 426da8 <__swc_bss_base_6b1cf01f+0x2d68>
  41181c:	mov    rax,QWORD PTR [rsi]
  41181f:	test   rax,rax
  411822:	je     41182a <__swc_fn_6b1cf01f_000170_fa3003e2+0x1a>
  411824:	add    rsp,0x30
  411828:	pop    rsi
  411829:	ret
  41182a:	mov    ecx,0x3
  41182f:	mov    edx,0x10
  411834:	call   40f240 <__swc_fn_6b1cf01f_000107_4796e893>
  411839:	test   rax,rax
  41183c:	jne    41184d <__swc_fn_6b1cf01f_000170_fa3003e2+0x3d>
  41183e:	mov    QWORD PTR [rsp+0x18],rax
  411843:	call   40c910 <__swc_fn_6b1cf01f_000118_7f430081>
  411848:	mov    rax,QWORD PTR [rsp+0x18]
  41184d:	mov    rcx,rax
  411850:	xchg   QWORD PTR [rsi],rcx
  411853:	add    rsp,0x30
  411857:	pop    rsi
  411858:	ret
  411859:	add    BYTE PTR [rax],al
  41185b:	add    BYTE PTR [rax],al
  41185d:	add    BYTE PTR [rax],al
	...

0000000000411860 <__swc_fn_6b1cf01f_000173_f69b1f05>:
  411860:	push   rsi
  411861:	push   rdi
  411862:	sub    rsp,0x8
  411866:	mov    rsi,rdx
  411869:	mov    rdi,rcx
  41186c:	mov    rax,QWORD PTR [rsi+0x8]
  411870:	test   rax,rax
  411873:	je     41187d <__swc_fn_6b1cf01f_000173_f69b1f05+0x1d>
  411875:	mov    rcx,QWORD PTR [rsi]
  411878:	mov    QWORD PTR [rax],rcx
  41187b:	jmp    411884 <__swc_fn_6b1cf01f_000173_f69b1f05+0x24>
  41187d:	mov    rax,QWORD PTR [rsi]
  411880:	mov    QWORD PTR [rdi+0x8],rax
  411884:	mov    rax,QWORD PTR [rsi]
  411887:	test   rax,rax
  41188a:	je     411894 <__swc_fn_6b1cf01f_000173_f69b1f05+0x34>
  41188c:	mov    rcx,QWORD PTR [rsi+0x8]
  411890:	mov    QWORD PTR [rax+0x8],rcx
  411894:	mov    rcx,rdi
  411897:	mov    rdx,QWORD PTR [rsi+0x10]
  41189b:	mov    r8,QWORD PTR [rsi+0x18]
  41189f:	mov    r9,0xffffffffffffffff
  4118a6:	call   40d4e0 <__swc_fn_6b1cf01f_000172_97fbc432>
  4118ab:	mov    QWORD PTR [rsi+0x18],0x0
  4118b3:	mov    rax,QWORD PTR [rdi+0x8]
  4118b7:	test   rax,rax
  4118ba:	jne    4118cc <__swc_fn_6b1cf01f_000173_f69b1f05+0x6c>
  4118bc:	call   411810 <__swc_fn_6b1cf01f_000170_fa3003e2>
  4118c1:	xor    ecx,ecx
  4118c3:	mov    QWORD PTR [rax+0x8],rcx
  4118c7:	xor    ecx,ecx
  4118c9:	mov    QWORD PTR [rax],rcx
  4118cc:	add    rsp,0x8
  4118d0:	pop    rdi
  4118d1:	pop    rsi
  4118d2:	ret
	...

00000000004118e0 <__swc_fn_6b1cf01f_000176_0ce64436>:
  4118e0:	push   rbp
  4118e1:	push   rbx
  4118e2:	push   rsi
  4118e3:	sub    rsp,0xa8
  4118ea:	mov    rbp,rsp
  4118ed:	vmovups XMMWORD PTR [rsp],xmm6
  4118f2:	vmovups XMMWORD PTR [rsp+0x10],xmm7
  4118f8:	vmovups XMMWORD PTR [rsp+0x20],xmm8
  4118fe:	vmovups XMMWORD PTR [rsp+0x30],xmm9
  411904:	vmovups XMMWORD PTR [rsp+0x40],xmm10
  41190a:	vmovups XMMWORD PTR [rsp+0x50],xmm11
  411910:	vmovups XMMWORD PTR [rsp+0x60],xmm12
  411916:	vmovups XMMWORD PTR [rsp+0x70],xmm13
  41191c:	vmovups XMMWORD PTR [rsp+0x80],xmm14
  411925:	vmovups XMMWORD PTR [rsp+0x90],xmm15
  41192e:	sub    rsp,0x510
  411935:	mov    rbx,rsp
  411938:	lea    rax,[rip+0x1fd9]        # 413918 <__swc_rdata_base_6b1cf01f+0x808>
  41193f:	xor    ecx,ecx
  411941:	cs nop WORD PTR [rax+rax*1+0x0]
  41194b:	cs nop WORD PTR [rax+rax*1+0x0]
  411955:	cs nop WORD PTR [rax+rax*1+0x0]
  41195f:	nop
  411960:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  411965:	vmovdqu XMMWORD PTR [rbx+rcx*1],xmm0
  41196a:	add    rcx,0x10
  41196e:	cmp    rcx,0x110
  411975:	jne    411960 <__swc_fn_6b1cf01f_000176_0ce64436+0x80>
  411977:	mov    DWORD PTR [rbx+0x110],0x531799ac
  411981:	mov    DWORD PTR [rbx+0x114],0x3f60a8f3
  41198b:	sub    rsp,0x8
  41198f:	call   40d590 <__swc_fn_6b1cf01f_000175_1ca87929>
  411994:	add    rsp,0x8
  411998:	vmovsd QWORD PTR [rsp+0x2d0],xmm0
  4119a1:	vxorpd xmm0,xmm0,xmm0
  4119a5:	vmovups xmm2,xmm0
  4119a9:	mov    rax,rbx
  4119ac:	vmovsd xmm3,QWORD PTR [rbx+0x18]
  4119b1:	vmovsd xmm4,QWORD PTR [rbx+0x30]
  4119b6:	vmulsd xmm3,xmm3,xmm4
  4119ba:	vaddsd xmm1,xmm0,xmm3
  4119be:	vmovsd xmm3,QWORD PTR [rbx+0x20]
  4119c3:	vfmadd231sd xmm2,xmm3,xmm4
  4119c8:	vmovsd xmm3,QWORD PTR [rbx+0x28]
  4119cd:	vfmadd231sd xmm0,xmm3,xmm4
  4119d2:	add    rax,0x38
  4119d6:	vmovsd xmm3,QWORD PTR [rax+0x18]
  4119db:	vmovsd xmm4,QWORD PTR [rax+0x30]
  4119e0:	vfmadd231sd xmm1,xmm3,xmm4
  4119e5:	vmovsd xmm3,QWORD PTR [rax+0x20]
  4119ea:	vfmadd231sd xmm2,xmm3,xmm4
  4119ef:	vmovsd xmm3,QWORD PTR [rax+0x28]
  4119f4:	vfmadd231sd xmm0,xmm3,xmm4
  4119f9:	vmovsd xmm3,QWORD PTR [rax+0x50]
  4119fe:	vmovsd xmm4,QWORD PTR [rax+0x68]
  411a03:	vfmadd231sd xmm1,xmm3,xmm4
  411a08:	vmovsd xmm3,QWORD PTR [rax+0x58]
  411a0d:	vfmadd231sd xmm2,xmm3,xmm4
  411a12:	vmovsd xmm3,QWORD PTR [rax+0x60]
  411a17:	vfmadd231sd xmm0,xmm3,xmm4
  411a1c:	vmovsd xmm3,QWORD PTR [rax+0x88]
  411a24:	vmovsd xmm4,QWORD PTR [rax+0xa0]
  411a2c:	vfmadd231sd xmm1,xmm3,xmm4
  411a31:	vmovsd xmm3,QWORD PTR [rax+0x90]
  411a39:	vfmadd231sd xmm2,xmm3,xmm4
  411a3e:	vmovsd xmm3,QWORD PTR [rax+0x98]
  411a46:	vfmadd231sd xmm0,xmm3,xmm4
  411a4b:	vmovsd xmm3,QWORD PTR [rax+0xc0]
  411a53:	vmovsd xmm4,QWORD PTR [rax+0xd8]
  411a5b:	vfmadd231sd xmm1,xmm3,xmm4
  411a60:	vmovsd xmm3,QWORD PTR [rax+0xc8]
  411a68:	vfmadd231sd xmm2,xmm3,xmm4
  411a6d:	vmovsd xmm3,QWORD PTR [rax+0xd0]
  411a75:	vfmadd231sd xmm0,xmm3,xmm4
  411a7a:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1ace]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  411a82:	vmovsd xmm3,QWORD PTR [rip+0x2056]        # 413ae0 <__swc_rdata_base_6b1cf01f+0x9d0>
  411a8a:	vdivsd xmm1,xmm1,xmm3
  411a8e:	vmovsd QWORD PTR [rbx+0x18],xmm1
  411a93:	vxorpd xmm2,xmm2,XMMWORD PTR [rip+0x1ab5]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  411a9b:	vdivsd xmm1,xmm2,xmm3
  411a9f:	vmovsd QWORD PTR [rbx+0x20],xmm1
  411aa4:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x1aa4]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  411aac:	vdivsd xmm0,xmm0,xmm3
  411ab0:	vmovsd QWORD PTR [rbx+0x28],xmm0
  411ab5:	xor    eax,eax
  411ab7:	vmovsd xmm0,QWORD PTR [rip+0x202a]        # 413ae9 <__swc_rdata_base_6b1cf01f+0x9d9>
  411abf:	vpshufd xmm1,xmm0,0x44
  411ac4:	vmovups XMMWORD PTR [rsp+0x2e0],xmm1
  411acd:	vpunpcklqdq xmm2,xmm0,xmm0
  411ad1:	vmovups XMMWORD PTR [rsp+0x2f0],xmm2
  411ada:	vmovdqu xmm3,XMMWORD PTR [rsp]
  411adf:	vmovdqu xmm4,XMMWORD PTR [rsp+0x18]
  411ae5:	vmovdqu xmm5,XMMWORD PTR [rsp+0x38]
  411aeb:	vmovups XMMWORD PTR [rsp+0x320],xmm5
  411af4:	vmovdqu xmm7,XMMWORD PTR [rsp+0x50]
  411afa:	vmovdqu xmm8,XMMWORD PTR [rsp+0x70]
  411b00:	vmovups XMMWORD PTR [rsp+0x340],xmm8
  411b09:	vmovdqu xmm9,XMMWORD PTR [rsp+0x88]
  411b12:	vmovdqu xmm10,XMMWORD PTR [rsp+0xa8]
  411b1b:	vmovups XMMWORD PTR [rsp+0x350],xmm10
  411b24:	vmovdqu xmm11,XMMWORD PTR [rsp+0xc0]
  411b2d:	vmovdqu xmm12,XMMWORD PTR [rsp+0xe0]
  411b36:	vmovups XMMWORD PTR [rsp+0x360],xmm11
  411b3f:	vmovups XMMWORD PTR [rsp+0x370],xmm12
  411b48:	vmovdqu xmm13,XMMWORD PTR [rsp+0xf8]
  411b51:	mov    rcx,QWORD PTR [rsp+0x68]
  411b56:	mov    rdx,QWORD PTR [rsp+0x30]
  411b5b:	mov    r8,QWORD PTR [rsp+0xa0]
  411b63:	mov    r9,QWORD PTR [rsp+0xd8]
  411b6b:	mov    r10,QWORD PTR [rsp+0x110]
  411b73:	jmp    411bd4 <__swc_fn_6b1cf01f_000176_0ce64436+0x2f4>
  411b75:	cs nop WORD PTR [rax+rax*1+0x0]
  411b7f:	cs nop WORD PTR [rax+rax*1+0x0]
  411b89:	nop    DWORD PTR [rax+0x0]
  411b90:	vmovups xmm2,XMMWORD PTR [rsp+0x2f0]
  411b99:	vmovups xmm4,XMMWORD PTR [rsp+0x310]
  411ba2:	vmovups xmm5,XMMWORD PTR [rsp+0x320]
  411bab:	vmovups xmm10,xmm13
  411bb0:	vmovups XMMWORD PTR [rsp+0x360],xmm7
  411bb9:	vmovups xmm12,xmm11
  411bbe:	vmovups xmm13,xmm3
  411bc2:	vmovups xmm3,XMMWORD PTR [rsp+0x300]
  411bcb:	vmovups xmm7,XMMWORD PTR [rsp+0x330]
  411bd4:	vsubpd xmm14,xmm3,xmm5
  411bd8:	vpsrldq xmm6,xmm14,0x8
  411bde:	vmovsd xmm15,QWORD PTR [rbx+0x10]
  411be3:	vmovsd QWORD PTR [rsp+0x390],xmm15
  411bec:	vmovsd xmm0,QWORD PTR [rbx+0x48]
  411bf1:	vmovsd QWORD PTR [rsp+0x398],xmm0
  411bfa:	vsubsd xmm5,xmm15,xmm0
  411bfe:	vmulsd xmm0,xmm14,xmm14
  411c03:	vfmadd231sd xmm0,xmm6,xmm6
  411c08:	vfmadd231sd xmm0,xmm5,xmm5
  411c0d:	vsubpd xmm6,xmm3,xmm8
  411c12:	vmulsd xmm8,xmm6,xmm6
  411c16:	vmovups XMMWORD PTR [rsp+0x380],xmm13
  411c1f:	vpsrldq xmm13,xmm6,0x8
  411c24:	vfmadd231sd xmm8,xmm13,xmm13
  411c29:	vmovsd xmm13,QWORD PTR [rbx+0x80]
  411c31:	vmovsd QWORD PTR [rsp+0x3a0],xmm13
  411c3a:	vsubsd xmm1,xmm15,xmm13
  411c3f:	vfmadd231sd xmm8,xmm1,xmm1
  411c44:	vpunpcklqdq xmm0,xmm0,xmm8
  411c49:	vsqrtpd xmm8,xmm0
  411c4d:	vmulpd xmm0,xmm0,xmm8
  411c52:	vdivpd xmm0,xmm2,xmm0
  411c56:	vpshufd xmm8,xmm0,0x44
  411c5b:	vmovq  xmm13,rcx
  411c60:	vpshufd xmm13,xmm13,0x44
  411c66:	vmulpd xmm11,xmm14,xmm13
  411c6b:	vmovups XMMWORD PTR [rsp+0x3b0],xmm13
  411c74:	vmovq  xmm13,rcx
  411c79:	vmovsd QWORD PTR [rsp+0x3c0],xmm13
  411c82:	vfnmadd231pd xmm4,xmm11,xmm8
  411c87:	vmulsd xmm11,xmm5,xmm13
  411c8c:	vfnmadd213sd xmm11,xmm0,QWORD PTR [rbx+0x28]
  411c92:	vmovq  xmm13,rdx
  411c97:	vpshufd xmm13,xmm13,0x44
  411c9d:	vmulpd xmm14,xmm14,xmm13
  411ca2:	vmulpd xmm8,xmm14,xmm8
  411ca7:	vmovq  xmm14,rdx
  411cac:	vaddpd xmm7,xmm7,xmm8
  411cb1:	vmovups XMMWORD PTR [rsp+0x3d0],xmm7
  411cba:	vmulsd xmm5,xmm5,xmm14
  411cbf:	vfmadd213sd xmm5,xmm0,QWORD PTR [rbx+0x60]
  411cc5:	vmovsd QWORD PTR [rsp+0x3e0],xmm5
  411cce:	vmulpd xmm8,xmm6,xmm13
  411cd3:	vpsrldq xmm0,xmm0,0x8
  411cd8:	vpshufd xmm5,xmm0,0x44
  411cdd:	vmulpd xmm8,xmm8,xmm5
  411ce1:	vmovq  xmm2,r8
  411ce6:	vpshufd xmm2,xmm2,0x44
  411ceb:	vmulpd xmm6,xmm6,xmm2
  411cef:	vfnmadd231pd xmm4,xmm6,xmm5
  411cf4:	vmovq  xmm5,r8
  411cf9:	vmovsd QWORD PTR [rsp+0x400],xmm5
  411d02:	vmulsd xmm6,xmm1,xmm5
  411d06:	vfnmadd213sd xmm6,xmm0,xmm11
  411d0b:	vaddpd xmm8,xmm9,xmm8
  411d10:	vmovups XMMWORD PTR [rsp+0x410],xmm8
  411d19:	vmulsd xmm1,xmm1,xmm14
  411d1e:	vmulsd xmm0,xmm1,xmm0
  411d22:	vaddsd xmm0,xmm0,QWORD PTR [rbx+0x98]
  411d2a:	vmovsd QWORD PTR [rsp+0x420],xmm0
  411d33:	vsubpd xmm1,xmm3,xmm10
  411d38:	vmulpd xmm9,xmm1,xmm13
  411d3d:	vpsrldq xmm0,xmm1,0x8
  411d42:	vmovsd xmm11,QWORD PTR [rbx+0xb8]
  411d4a:	vmovsd QWORD PTR [rsp+0x428],xmm11
  411d53:	vsubsd xmm5,xmm15,xmm11
  411d58:	vmulsd xmm8,xmm1,xmm1
  411d5c:	vfmadd213sd xmm0,xmm0,xmm8
  411d61:	vfmadd231sd xmm0,xmm5,xmm5
  411d66:	vsubpd xmm8,xmm3,xmm12
  411d6b:	vmulsd xmm12,xmm8,xmm8
  411d70:	vpsrldq xmm7,xmm8,0x8
  411d76:	vmulsd xmm7,xmm7,xmm7
  411d7a:	vaddsd xmm7,xmm12,xmm7
  411d7e:	vmovsd xmm12,QWORD PTR [rbx+0xf0]
  411d86:	vmovsd QWORD PTR [rsp+0x430],xmm12
  411d8f:	vsubsd xmm11,xmm15,xmm12
  411d94:	vfmadd231sd xmm7,xmm11,xmm11
  411d99:	vpunpcklqdq xmm0,xmm0,xmm7
  411d9d:	vsqrtpd xmm7,xmm0
  411da1:	vmulpd xmm0,xmm0,xmm7
  411da5:	vmovups xmm15,XMMWORD PTR [rsp+0x2f0]
  411dae:	vdivpd xmm0,xmm15,xmm0
  411db2:	vpshufd xmm7,xmm0,0x44
  411db7:	vmulpd xmm9,xmm9,xmm7
  411dbb:	vmovq  xmm12,r9
  411dc0:	vpshufd xmm12,xmm12,0x44
  411dc6:	vmulpd xmm1,xmm1,xmm12
  411dcb:	vfnmadd213pd xmm1,xmm7,xmm4
  411dd0:	vmovq  xmm7,r9
  411dd5:	vmovsd QWORD PTR [rsp+0x450],xmm7
  411dde:	vmulsd xmm4,xmm5,xmm7
  411de2:	vfnmadd231sd xmm6,xmm4,xmm0
  411de7:	vaddpd xmm9,xmm9,XMMWORD PTR [rsp+0x360]
  411df0:	vmulsd xmm4,xmm5,xmm14
  411df5:	vmovsd xmm5,QWORD PTR [rbx+0xd0]
  411dfd:	vfmadd231sd xmm5,xmm4,xmm0
  411e02:	vmovsd QWORD PTR [rsp+0x458],xmm5
  411e0b:	vmulpd xmm4,xmm8,xmm13
  411e10:	vpsrldq xmm0,xmm0,0x8
  411e15:	vpshufd xmm13,xmm0,0x44
  411e1a:	vmulpd xmm4,xmm4,xmm13
  411e1f:	vmovq  xmm5,r10
  411e24:	vpshufd xmm5,xmm5,0x44
  411e29:	vmovups XMMWORD PTR [rsp+0x460],xmm5
  411e32:	vmulpd xmm8,xmm8,xmm5
  411e36:	vmulpd xmm8,xmm8,xmm13
  411e3b:	vmovups xmm13,xmm4
  411e3f:	vsubpd xmm4,xmm1,xmm8
  411e44:	vfmadd231pd xmm3,xmm4,XMMWORD PTR [rsp+0x2e0]
  411e4e:	vmovq  xmm8,r10
  411e53:	vmovups XMMWORD PTR [rsp+0x300],xmm3
  411e5c:	vmovsd QWORD PTR [rsp+0x470],xmm8
  411e65:	vaddpd xmm3,xmm13,XMMWORD PTR [rsp+0x380]
  411e6e:	vmovups XMMWORD PTR [rsp+0x480],xmm3
  411e77:	vmulsd xmm13,xmm11,xmm8
  411e7c:	vfnmadd231sd xmm6,xmm13,xmm0
  411e81:	vmovsd QWORD PTR [rbx+0x28],xmm6
  411e86:	vmulsd xmm11,xmm11,xmm14
  411e8b:	vmulsd xmm0,xmm11,xmm0
  411e8f:	vaddsd xmm0,xmm0,QWORD PTR [rbx+0x108]
  411e97:	vmovups xmm13,XMMWORD PTR [rsp+0x320]
  411ea0:	vmovsd QWORD PTR [rsp+0x498],xmm0
  411ea9:	vsubpd xmm14,xmm13,XMMWORD PTR [rsp+0x340]
  411eb2:	vmovups XMMWORD PTR [rsp+0x310],xmm4
  411ebb:	vmulpd xmm4,xmm14,xmm2
  411ebf:	vmovups xmm6,XMMWORD PTR [rsp+0x3b0]
  411ec8:	vmovups XMMWORD PTR [rsp+0x3f0],xmm2
  411ed1:	vmulpd xmm2,xmm14,xmm6
  411ed5:	vpsrldq xmm8,xmm14,0x8
  411edb:	vmovsd xmm0,QWORD PTR [rsp+0x398]
  411ee4:	vsubsd xmm1,xmm0,QWORD PTR [rsp+0x3a0]
  411eed:	vmulsd xmm3,xmm14,xmm14
  411ef2:	vfmadd231sd xmm3,xmm8,xmm8
  411ef7:	vfmadd231sd xmm3,xmm1,xmm1
  411efc:	vsubpd xmm8,xmm13,xmm10
  411f01:	vmulsd xmm14,xmm8,xmm8
  411f06:	vpsrldq xmm10,xmm8,0x8
  411f0c:	vmulsd xmm10,xmm10,xmm10
  411f11:	vaddsd xmm10,xmm14,xmm10
  411f16:	vsubsd xmm11,xmm0,QWORD PTR [rsp+0x428]
  411f1f:	vfmadd231sd xmm10,xmm11,xmm11
  411f24:	vpunpcklqdq xmm3,xmm3,xmm10
  411f29:	vsqrtpd xmm10,xmm3
  411f2d:	vmulpd xmm3,xmm3,xmm10
  411f32:	vdivpd xmm3,xmm15,xmm3
  411f36:	vpshufd xmm10,xmm3,0x44
  411f3b:	vfnmadd213pd xmm4,xmm10,XMMWORD PTR [rsp+0x3d0]
  411f45:	vmulpd xmm2,xmm2,xmm10
  411f4a:	vaddpd xmm2,xmm2,XMMWORD PTR [rsp+0x410]
  411f53:	vmovups XMMWORD PTR [rsp+0x4a0],xmm2
  411f5c:	vmulsd xmm14,xmm1,QWORD PTR [rsp+0x400]
  411f65:	vmovsd xmm10,QWORD PTR [rsp+0x3e0]
  411f6e:	vfnmadd231sd xmm10,xmm14,xmm3
  411f73:	vmovsd xmm14,QWORD PTR [rsp+0x3c0]
  411f7c:	vmulsd xmm1,xmm1,xmm14
  411f81:	vfmadd213sd xmm1,xmm3,QWORD PTR [rsp+0x420]
  411f8b:	vmovsd QWORD PTR [rsp+0x4b0],xmm1
  411f94:	vmulpd xmm2,xmm8,xmm12
  411f99:	vmulpd xmm8,xmm8,xmm6
  411f9d:	vpsrldq xmm3,xmm3,0x8
  411fa2:	vpshufd xmm1,xmm3,0x44
  411fa7:	vfnmadd213pd xmm2,xmm1,xmm4
  411fac:	vfmadd213pd xmm1,xmm8,xmm9
  411fb1:	vmulsd xmm4,xmm11,xmm7
  411fb5:	vfnmadd213sd xmm4,xmm3,xmm10
  411fba:	vmulsd xmm8,xmm11,xmm14
  411fbf:	vmulsd xmm3,xmm8,xmm3
  411fc3:	vaddsd xmm3,xmm3,QWORD PTR [rsp+0x458]
  411fcc:	vmovsd QWORD PTR [rsp+0x4b8],xmm3
  411fd5:	vsubpd xmm9,xmm13,XMMWORD PTR [rsp+0x370]
  411fde:	vmulpd xmm10,xmm9,xmm5
  411fe2:	vmulpd xmm6,xmm9,xmm6
  411fe6:	vpsrldq xmm7,xmm9,0x8
  411fec:	vsubsd xmm5,xmm0,QWORD PTR [rsp+0x430]
  411ff5:	vmulsd xmm0,xmm9,xmm9
  411ffa:	vfmadd231sd xmm0,xmm7,xmm7
  411fff:	vfmadd231sd xmm0,xmm5,xmm5
  412004:	vmovups xmm9,XMMWORD PTR [rsp+0x340]
  41200d:	vsubpd xmm11,xmm9,XMMWORD PTR [rsp+0x350]
  412016:	vmulsd xmm7,xmm11,xmm11
  41201b:	vpsrldq xmm8,xmm11,0x8
  412021:	vfmadd231sd xmm7,xmm8,xmm8
  412026:	vmovsd xmm8,QWORD PTR [rsp+0x3a0]
  41202f:	vsubsd xmm3,xmm8,QWORD PTR [rsp+0x428]
  412038:	vfmadd231sd xmm7,xmm3,xmm3
  41203d:	vpunpcklqdq xmm0,xmm0,xmm7
  412041:	vsqrtpd xmm7,xmm0
  412045:	vmulpd xmm0,xmm0,xmm7
  412049:	vdivpd xmm0,xmm15,xmm0
  41204d:	vpshufd xmm9,xmm0,0x44
  412052:	vmulpd xmm7,xmm10,xmm9
  412057:	vmovsd xmm15,QWORD PTR [rsp+0x450]
  412060:	vsubpd xmm7,xmm2,xmm7
  412064:	vmovups xmm2,XMMWORD PTR [rsp+0x2e0]
  41206d:	vfmadd231pd xmm13,xmm7,xmm2
  412072:	vmovups XMMWORD PTR [rsp+0x320],xmm13
  41207b:	vmulpd xmm6,xmm6,xmm9
  412080:	vaddpd xmm6,xmm6,XMMWORD PTR [rsp+0x480]
  412089:	vmovsd xmm10,QWORD PTR [rsp+0x470]
  412092:	vmulsd xmm9,xmm5,xmm10
  412097:	vfnmadd231sd xmm4,xmm9,xmm0
  41209c:	vmovsd QWORD PTR [rbx+0x60],xmm4
  4120a1:	vmulsd xmm5,xmm5,xmm14
  4120a6:	vfmadd213sd xmm5,xmm0,QWORD PTR [rsp+0x498]
  4120b0:	vmulpd xmm9,xmm11,xmm12
  4120b5:	vmovups xmm14,XMMWORD PTR [rsp+0x3f0]
  4120be:	vmulpd xmm11,xmm11,xmm14
  4120c3:	vpsrldq xmm0,xmm0,0x8
  4120c8:	vpshufd xmm13,xmm0,0x44
  4120cd:	vmovups XMMWORD PTR [rsp+0x330],xmm7
  4120d6:	vmovups xmm7,XMMWORD PTR [rsp+0x4a0]
  4120df:	vfnmadd231pd xmm7,xmm9,xmm13
  4120e4:	vfmadd231pd xmm1,xmm11,xmm13
  4120e9:	vmovups XMMWORD PTR [rsp+0x4d0],xmm1
  4120f2:	vmulsd xmm9,xmm3,xmm15
  4120f7:	vmovsd xmm11,QWORD PTR [rsp+0x4b0]
  412100:	vfnmadd231sd xmm11,xmm9,xmm0
  412105:	vmovsd xmm13,QWORD PTR [rsp+0x400]
  41210e:	vmulsd xmm3,xmm3,xmm13
  412113:	vmulsd xmm0,xmm3,xmm0
  412117:	vaddsd xmm0,xmm0,QWORD PTR [rsp+0x4b8]
  412120:	vmovups xmm9,XMMWORD PTR [rsp+0x340]
  412129:	vmovups xmm3,XMMWORD PTR [rsp+0x370]
  412132:	vmovsd QWORD PTR [rsp+0x4e0],xmm0
  41213b:	vsubpd xmm4,xmm9,xmm3
  41213f:	vmulpd xmm15,xmm4,XMMWORD PTR [rsp+0x460]
  412148:	vmulpd xmm14,xmm4,xmm14
  41214d:	vpsrldq xmm0,xmm4,0x8
  412152:	vmovsd xmm9,QWORD PTR [rsp+0x430]
  41215b:	vsubsd xmm1,xmm8,xmm9
  412160:	vmulsd xmm4,xmm4,xmm4
  412164:	vfmadd213sd xmm0,xmm0,xmm4
  412169:	vfmadd231sd xmm0,xmm1,xmm1
  41216e:	vmovups xmm4,XMMWORD PTR [rsp+0x350]
  412177:	vsubpd xmm8,xmm4,xmm3
  41217b:	vmovups XMMWORD PTR [rsp+0x4f0],xmm8
  412184:	vmulsd xmm3,xmm8,xmm8
  412189:	vpsrldq xmm4,xmm8,0x8
  41218f:	vfmadd231sd xmm3,xmm4,xmm4
  412194:	vmovsd xmm4,QWORD PTR [rsp+0x428]
  41219d:	vmovups XMMWORD PTR [rsp+0x440],xmm12
  4121a6:	vsubsd xmm12,xmm4,xmm9
  4121ab:	vmovsd QWORD PTR [rsp+0x500],xmm12
  4121b4:	vfmadd231sd xmm3,xmm12,xmm12
  4121b9:	vpunpcklqdq xmm0,xmm0,xmm3
  4121bd:	vsqrtpd xmm3,xmm0
  4121c1:	vmulpd xmm0,xmm0,xmm3
  4121c5:	vmovups xmm4,XMMWORD PTR [rsp+0x2f0]
  4121ce:	vdivpd xmm0,xmm4,xmm0
  4121d2:	vpshufd xmm3,xmm0,0x44
  4121d7:	vmulpd xmm15,xmm15,xmm3
  4121db:	vmovups xmm8,XMMWORD PTR [rsp+0x340]
  4121e4:	vmovups xmm4,xmm9
  4121e9:	vmovups xmm12,XMMWORD PTR [rsp+0x460]
  4121f2:	vsubpd xmm9,xmm7,xmm15
  4121f7:	vfmadd231pd xmm8,xmm9,xmm2
  4121fc:	vmovups XMMWORD PTR [rsp+0x340],xmm8
  412205:	vfmadd213pd xmm3,xmm14,xmm6
  41220a:	vmulsd xmm6,xmm1,xmm10
  41220f:	vfnmadd213sd xmm6,xmm0,xmm11
  412214:	vmovsd QWORD PTR [rbx+0x98],xmm6
  41221c:	vmulsd xmm1,xmm1,xmm13
  412221:	vfmadd213sd xmm1,xmm0,xmm5
  412226:	vmovups xmm5,XMMWORD PTR [rsp+0x4f0]
  41222f:	vmulpd xmm7,xmm5,xmm12
  412234:	vmulpd xmm5,xmm5,XMMWORD PTR [rsp+0x440]
  41223d:	vpsrldq xmm0,xmm0,0x8
  412242:	vpshufd xmm11,xmm0,0x44
  412247:	vfnmadd213pd xmm7,xmm11,XMMWORD PTR [rsp+0x4d0]
  412251:	vmovups xmm13,XMMWORD PTR [rsp+0x350]
  41225a:	vfmadd231pd xmm13,xmm7,xmm2
  41225f:	vmovups XMMWORD PTR [rsp+0x350],xmm13
  412268:	vmulpd xmm5,xmm5,xmm11
  41226d:	vmovups xmm11,XMMWORD PTR [rsp+0x370]
  412276:	vmovsd xmm12,QWORD PTR [rsp+0x3a0]
  41227f:	vaddpd xmm3,xmm3,xmm5
  412283:	vfmadd231pd xmm11,xmm3,xmm2
  412288:	vmovsd xmm5,QWORD PTR [rsp+0x500]
  412291:	vmovups XMMWORD PTR [rsp+0x370],xmm11
  41229a:	vmulsd xmm10,xmm5,xmm10
  41229f:	vfnmadd213sd xmm10,xmm0,QWORD PTR [rsp+0x4e0]
  4122a9:	vmovsd QWORD PTR [rbx+0xd0],xmm10
  4122b1:	vmulsd xmm5,xmm5,QWORD PTR [rsp+0x450]
  4122ba:	vfmadd213sd xmm0,xmm5,xmm1
  4122bf:	vmovsd QWORD PTR [rbx+0x108],xmm0
  4122c7:	vmovsd xmm5,QWORD PTR [rip+0x181a]        # 413ae9 <__swc_rdata_base_6b1cf01f+0x9d9>
  4122cf:	vmovsd xmm1,QWORD PTR [rbx+0x28]
  4122d4:	vfmadd213sd xmm1,xmm5,QWORD PTR [rsp+0x390]
  4122de:	vmovsd QWORD PTR [rbx+0x10],xmm1
  4122e3:	vmovsd xmm1,QWORD PTR [rbx+0x60]
  4122e8:	vfmadd213sd xmm1,xmm5,QWORD PTR [rsp+0x398]
  4122f2:	vmovsd QWORD PTR [rbx+0x48],xmm1
  4122f7:	vmulsd xmm1,xmm6,xmm5
  4122fb:	vaddsd xmm1,xmm12,xmm1
  4122ff:	vmovsd QWORD PTR [rbx+0x80],xmm1
  412307:	vmulsd xmm1,xmm10,xmm5
  41230b:	vaddsd xmm1,xmm1,QWORD PTR [rsp+0x428]
  412314:	vmovsd QWORD PTR [rbx+0xb8],xmm1
  41231c:	vfmadd213sd xmm0,xmm5,xmm4
  412321:	vmovsd QWORD PTR [rbx+0xf0],xmm0
  412329:	add    rax,0x1
  41232d:	cmp    rax,0x7a120
  412334:	jl     411b90 <__swc_fn_6b1cf01f_000176_0ce64436+0x2b0>
  41233a:	vmovdqu XMMWORD PTR [rsp+0xa8],xmm13
  412343:	vmovdqu XMMWORD PTR [rsp+0xc0],xmm7
  41234c:	vmovdqu XMMWORD PTR [rsp+0xe0],xmm11
  412355:	vmovdqu XMMWORD PTR [rsp+0xf8],xmm3
  41235e:	vmovups xmm3,XMMWORD PTR [rsp+0x300]
  412367:	vmovdqu XMMWORD PTR [rsp],xmm3
  41236c:	vmovups xmm4,XMMWORD PTR [rsp+0x310]
  412375:	vmovdqu XMMWORD PTR [rsp+0x18],xmm4
  41237b:	vmovups xmm13,XMMWORD PTR [rsp+0x320]
  412384:	vmovdqu XMMWORD PTR [rsp+0x38],xmm13
  41238a:	vmovups xmm7,XMMWORD PTR [rsp+0x330]
  412393:	vmovdqu XMMWORD PTR [rsp+0x50],xmm7
  412399:	vmovdqu XMMWORD PTR [rsp+0x70],xmm8
  41239f:	vmovdqu XMMWORD PTR [rsp+0x88],xmm9
  4123a8:	mov    QWORD PTR [rbx+0x258],0x5
  4123b3:	vxorpd xmm0,xmm0,xmm0
  4123b7:	vmovsd xmm1,QWORD PTR [rip+0x11f5]        # 4135b4 <__swc_rdata_base_6b1cf01f+0x4a4>
  4123bf:	vmovsd xmm3,QWORD PTR [rbx+0x30]
  4123c4:	vmulsd xmm2,xmm1,xmm3
  4123c8:	vmovsd xmm4,QWORD PTR [rbx+0x18]
  4123cd:	vmulsd xmm4,xmm4,xmm4
  4123d1:	vmovsd xmm5,QWORD PTR [rbx+0x20]
  4123d6:	vfmadd231sd xmm4,xmm5,xmm5
  4123db:	vmovsd xmm5,QWORD PTR [rbx+0x28]
  4123e0:	vfmadd231sd xmm4,xmm5,xmm5
  4123e5:	vfmadd231sd xmm0,xmm2,xmm4
  4123ea:	vmovsd xmm2,QWORD PTR [rbx]
  4123ee:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x38]
  4123f3:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  4123f8:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x40]
  4123fd:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  412402:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x48]
  412407:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x68]
  41240c:	vmulsd xmm2,xmm2,xmm2
  412410:	vfmadd231sd xmm2,xmm4,xmm4
  412415:	vfmadd231sd xmm2,xmm5,xmm5
  41241a:	vsqrtsd xmm2,xmm2,xmm2
  41241e:	vdivsd xmm2,xmm9,xmm2
  412422:	vsubsd xmm0,xmm0,xmm2
  412426:	vmovsd xmm2,QWORD PTR [rbx]
  41242a:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x70]
  41242f:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  412434:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x78]
  412439:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  41243e:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x80]
  412446:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xa0]
  41244e:	vmulsd xmm2,xmm2,xmm2
  412452:	vfmadd231sd xmm2,xmm4,xmm4
  412457:	vfmadd231sd xmm2,xmm5,xmm5
  41245c:	vsqrtsd xmm2,xmm2,xmm2
  412460:	vdivsd xmm2,xmm9,xmm2
  412464:	vsubsd xmm0,xmm0,xmm2
  412468:	vmovsd xmm2,QWORD PTR [rbx]
  41246c:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  412474:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  412479:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  412481:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  412486:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  41248e:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  412496:	vmulsd xmm2,xmm2,xmm2
  41249a:	vfmadd231sd xmm2,xmm4,xmm4
  41249f:	vfmadd231sd xmm2,xmm5,xmm5
  4124a4:	vsqrtsd xmm2,xmm2,xmm2
  4124a8:	vdivsd xmm2,xmm9,xmm2
  4124ac:	vsubsd xmm0,xmm0,xmm2
  4124b0:	vmovsd xmm2,QWORD PTR [rbx]
  4124b4:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xe0]
  4124bc:	vmovsd xmm4,QWORD PTR [rbx+0x8]
  4124c1:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xe8]
  4124c9:	vmovsd xmm5,QWORD PTR [rbx+0x10]
  4124ce:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xf0]
  4124d6:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x110]
  4124de:	vmulsd xmm2,xmm2,xmm2
  4124e2:	vfmadd231sd xmm2,xmm4,xmm4
  4124e7:	vfmadd231sd xmm2,xmm5,xmm5
  4124ec:	vsqrtsd xmm2,xmm2,xmm2
  4124f0:	vdivsd xmm2,xmm9,xmm2
  4124f4:	vsubsd xmm0,xmm0,xmm2
  4124f8:	vmovsd xmm3,QWORD PTR [rbx+0x68]
  4124fd:	vmulsd xmm2,xmm1,xmm3
  412501:	vmovsd xmm4,QWORD PTR [rbx+0x50]
  412506:	vmulsd xmm4,xmm4,xmm4
  41250a:	vmovsd xmm5,QWORD PTR [rbx+0x58]
  41250f:	vfmadd231sd xmm4,xmm5,xmm5
  412514:	vmovsd xmm5,QWORD PTR [rbx+0x60]
  412519:	vfmadd231sd xmm4,xmm5,xmm5
  41251e:	vfmadd231sd xmm0,xmm2,xmm4
  412523:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  412528:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0x70]
  41252d:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  412532:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0x78]
  412537:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  41253c:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0x80]
  412544:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xa0]
  41254c:	vmulsd xmm2,xmm2,xmm2
  412550:	vfmadd231sd xmm2,xmm4,xmm4
  412555:	vfmadd231sd xmm2,xmm5,xmm5
  41255a:	vsqrtsd xmm2,xmm2,xmm2
  41255e:	vdivsd xmm2,xmm9,xmm2
  412562:	vsubsd xmm0,xmm0,xmm2
  412566:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  41256b:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  412573:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  412578:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  412580:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  412585:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  41258d:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  412595:	vmulsd xmm2,xmm2,xmm2
  412599:	vfmadd231sd xmm2,xmm4,xmm4
  41259e:	vfmadd231sd xmm2,xmm5,xmm5
  4125a3:	vsqrtsd xmm2,xmm2,xmm2
  4125a7:	vdivsd xmm2,xmm9,xmm2
  4125ab:	vsubsd xmm0,xmm0,xmm2
  4125af:	vmovsd xmm2,QWORD PTR [rbx+0x38]
  4125b4:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xe0]
  4125bc:	vmovsd xmm4,QWORD PTR [rbx+0x40]
  4125c1:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xe8]
  4125c9:	vmovsd xmm5,QWORD PTR [rbx+0x48]
  4125ce:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xf0]
  4125d6:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0x110]
  4125de:	vmulsd xmm2,xmm2,xmm2
  4125e2:	vfmadd231sd xmm2,xmm4,xmm4
  4125e7:	vfmadd231sd xmm2,xmm5,xmm5
  4125ec:	vsqrtsd xmm2,xmm2,xmm2
  4125f0:	vdivsd xmm2,xmm9,xmm2
  4125f4:	vsubsd xmm0,xmm0,xmm2
  4125f8:	vmovsd xmm3,QWORD PTR [rbx+0xa0]
  412600:	vmulsd xmm2,xmm1,xmm3
  412604:	vmovsd xmm4,QWORD PTR [rbx+0x88]
  41260c:	vmulsd xmm4,xmm4,xmm4
  412610:	vmovsd xmm5,QWORD PTR [rbx+0x90]
  412618:	vfmadd231sd xmm4,xmm5,xmm5
  41261d:	vmovsd xmm5,QWORD PTR [rbx+0x98]
  412625:	vfmadd231sd xmm4,xmm5,xmm5
  41262a:	vfmadd231sd xmm0,xmm2,xmm4
  41262f:	vmovsd xmm2,QWORD PTR [rbx+0x70]
  412634:	vsubsd xmm2,xmm2,QWORD PTR [rbx+0xa8]
  41263c:	vmovsd xmm4,QWORD PTR [rbx+0x78]
  412641:	vsubsd xmm4,xmm4,QWORD PTR [rbx+0xb0]
  412649:	vmovsd xmm5,QWORD PTR [rbx+0x80]
  412651:	vsubsd xmm5,xmm5,QWORD PTR [rbx+0xb8]
  412659:	vmulsd xmm9,xmm3,QWORD PTR [rbx+0xd8]
  412661:	vmulsd xmm2,xmm2,xmm2
  412665:	vfmadd231sd xmm2,xmm4,xmm4
  41266a:	vfmadd231sd xmm2,xmm5,xmm5
  41266f:	vsqrtsd xmm2,xmm2,xmm2
  412673:	vdivsd xmm2,xmm9,xmm2
  412677:	vsubsd xmm0,xmm0,xmm2
  41267b:	vmovsd xmm2,QWORD PTR [rbx+0x70]
  412680:	vmovsd xmm6,QWORD PTR [rbx+0xe0]
  412688:	vsubsd xmm2,xmm2,xmm6
  41268c:	vmovsd xmm4,QWORD PTR [rbx+0x78]
  412691:	vmovsd xmm7,QWORD PTR [rbx+0xe8]
  412699:	vsubsd xmm4,xmm4,xmm7
  41269d:	vmovsd xmm5,QWORD PTR [rbx+0x80]
  4126a5:	vmovsd xmm8,QWORD PTR [rbx+0xf0]
  4126ad:	vsubsd xmm5,xmm5,xmm8
  4126b2:	vmovsd xmm10,QWORD PTR [rbx+0x110]
  4126ba:	vmulsd xmm9,xmm3,xmm10
  4126bf:	vmulsd xmm2,xmm2,xmm2
  4126c3:	vfmadd231sd xmm2,xmm4,xmm4
  4126c8:	vfmadd231sd xmm2,xmm5,xmm5
  4126cd:	vsqrtsd xmm2,xmm2,xmm2
  4126d1:	vdivsd xmm2,xmm9,xmm2
  4126d5:	vsubsd xmm0,xmm0,xmm2
  4126d9:	vmovsd xmm3,QWORD PTR [rbx+0xd8]
  4126e1:	vmulsd xmm2,xmm1,xmm3
  4126e5:	vmovsd xmm4,QWORD PTR [rbx+0xc0]
  4126ed:	vmulsd xmm4,xmm4,xmm4
  4126f1:	vmovsd xmm5,QWORD PTR [rbx+0xc8]
  4126f9:	vfmadd231sd xmm4,xmm5,xmm5
  4126fe:	vmovsd xmm5,QWORD PTR [rbx+0xd0]
  412706:	vfmadd231sd xmm4,xmm5,xmm5
  41270b:	vfmadd231sd xmm0,xmm2,xmm4
  412710:	vmovsd xmm2,QWORD PTR [rbx+0xa8]
  412718:	vsubsd xmm2,xmm2,xmm6
  41271c:	vmovsd xmm4,QWORD PTR [rbx+0xb0]
  412724:	vsubsd xmm4,xmm4,xmm7
  412728:	vmovsd xmm5,QWORD PTR [rbx+0xb8]
  412730:	vsubsd xmm5,xmm5,xmm8
  412735:	vmulsd xmm9,xmm3,xmm10
  41273a:	vmulsd xmm2,xmm2,xmm2
  41273e:	vfmadd231sd xmm2,xmm4,xmm4
  412743:	vfmadd231sd xmm2,xmm5,xmm5
  412748:	vsqrtsd xmm2,xmm2,xmm2
  41274c:	vdivsd xmm2,xmm9,xmm2
  412750:	vsubsd xmm0,xmm0,xmm2
  412754:	vmulsd xmm2,xmm10,xmm1
  412758:	vmovsd xmm4,QWORD PTR [rbx+0xf8]
  412760:	vmulsd xmm4,xmm4,xmm4
  412764:	vmovsd xmm5,QWORD PTR [rbx+0x100]
  41276c:	vfmadd231sd xmm4,xmm5,xmm5
  412771:	vmovsd xmm5,QWORD PTR [rbx+0x108]
  412779:	vfmadd231sd xmm4,xmm5,xmm5
  41277e:	vfmadd231sd xmm0,xmm2,xmm4
  412783:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0xdc5]        # 413550 <__swc_rdata_base_6b1cf01f+0x440>
  41278b:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x135f]        # 413af2 <__swc_rdata_base_6b1cf01f+0x9e2>
  412793:	vroundsd xmm0,xmm0,xmm0,0x1
  412799:	vmovsd xmm1,QWORD PTR [rip+0xe01]        # 4135a2 <__swc_rdata_base_6b1cf01f+0x492>
  4127a1:	vcomisd xmm0,xmm1
  4127a5:	jb     4127bf <__swc_fn_6b1cf01f_000176_0ce64436+0xedf>
  4127a7:	vsubsd xmm0,xmm0,xmm1
  4127ab:	vcvttsd2si rsi,xmm0
  4127b0:	movabs rax,0x8000000000000000
  4127ba:	xor    rsi,rax
  4127bd:	jmp    4127c4 <__swc_fn_6b1cf01f_000176_0ce64436+0xee4>
  4127bf:	vcvttsd2si rsi,xmm0
  4127c4:	sub    rsp,0x8
  4127c8:	call   40d590 <__swc_fn_6b1cf01f_000175_1ca87929>
  4127cd:	add    rsp,0x8
  4127d1:	vsubsd xmm0,xmm0,QWORD PTR [rsp+0x2d0]
  4127da:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x1319]        # 413afb <__swc_rdata_base_6b1cf01f+0x9eb>
  4127e2:	lea    rax,[rip+0xb7f]        # 413368 <__swc_rdata_base_6b1cf01f+0x258>
  4127e9:	sub    rsp,0x90
  4127f0:	mov    rcx,rsp
  4127f3:	vmovups xmm1,XMMWORD PTR [rip+0x12c5]        # 413ac0 <__swc_rdata_base_6b1cf01f+0x9b0>
  4127fb:	vmovups XMMWORD PTR [rcx],xmm1
  4127ff:	mov    QWORD PTR [rcx+0x30],rsp
  412803:	lea    rdx,[rip+0xb06]        # 413310 <__swc_rdata_base_6b1cf01f+0x200>
  41280a:	mov    QWORD PTR [rcx+0x38],rdx
  41280e:	mov    QWORD PTR [rcx+0x10],rsi
  412812:	lea    r8,[rsp+0x10]
  412817:	mov    QWORD PTR [rcx+0x40],r8
  41281b:	lea    r8,[rip+0x120e]        # 413a30 <__swc_rdata_base_6b1cf01f+0x920>
  412822:	mov    QWORD PTR [rcx+0x48],r8
  412826:	vmovups xmm1,XMMWORD PTR [rip+0x12a2]        # 413ad0 <__swc_rdata_base_6b1cf01f+0x9c0>
  41282e:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  412833:	lea    r8,[rsp+0x18]
  412838:	mov    QWORD PTR [rcx+0x50],r8
  41283c:	mov    QWORD PTR [rcx+0x58],rdx
  412840:	vmovsd QWORD PTR [rcx+0x28],xmm0
  412845:	lea    r8,[rcx+0x28]
  412849:	mov    QWORD PTR [rcx+0x60],r8
  41284d:	lea    r8,[rip+0x1224]        # 413a78 <__swc_rdata_base_6b1cf01f+0x968>
  412854:	mov    QWORD PTR [rcx+0x68],r8
  412858:	mov    QWORD PTR [rcx+0x70],rax
  41285c:	mov    QWORD PTR [rcx+0x78],rdx
  412860:	lea    rax,[rcx+0x30]
  412864:	mov    QWORD PTR [rcx+0x80],rax
  41286b:	mov    QWORD PTR [rcx+0x88],0x5
  412876:	lea    rcx,[rcx+0x80]
  41287d:	sub    rsp,0x8
  412881:	call   4101c0 <__swc_fn_6b1cf01f_000146_43f4fdca>
  412886:	add    rsp,0x5a8
  41288d:	vmovups xmm6,XMMWORD PTR [rsp]
  412892:	vmovups xmm7,XMMWORD PTR [rsp+0x10]
  412898:	vmovups xmm8,XMMWORD PTR [rsp+0x20]
  41289e:	vmovups xmm9,XMMWORD PTR [rsp+0x30]
  4128a4:	vmovups xmm10,XMMWORD PTR [rsp+0x40]
  4128aa:	vmovups xmm11,XMMWORD PTR [rsp+0x50]
  4128b0:	vmovups xmm12,XMMWORD PTR [rsp+0x60]
  4128b6:	vmovups xmm13,XMMWORD PTR [rsp+0x70]
  4128bc:	vmovups xmm14,XMMWORD PTR [rsp+0x80]
  4128c5:	vmovups xmm15,XMMWORD PTR [rsp+0x90]
  4128ce:	add    rsp,0xa8
  4128d5:	pop    rsi
  4128d6:	pop    rbx
  4128d7:	pop    rbp
  4128d8:	ret
