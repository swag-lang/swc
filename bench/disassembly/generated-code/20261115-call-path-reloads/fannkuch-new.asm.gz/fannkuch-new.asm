
/workspace/prompt2-20261115/batch9-audited-micro/new/fannkuch/fannkuch:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xb002]        # 412008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <open@plt>:
  407010:	jmp    QWORD PTR [rip+0xaffa]        # 412010 <open@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <flock@plt>:
  407020:	jmp    QWORD PTR [rip+0xaff2]        # 412018 <flock@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <__errno_location@plt>:
  407030:	jmp    QWORD PTR [rip+0xafea]        # 412020 <__errno_location@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <close@plt>:
  407040:	jmp    QWORD PTR [rip+0xafe2]        # 412028 <close@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <getpid@plt>:
  407050:	jmp    QWORD PTR [rip+0xafda]        # 412030 <getpid@GLIBC_2.2.5>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <opendir@plt>:
  407060:	jmp    QWORD PTR [rip+0xafd2]        # 412038 <opendir@GLIBC_2.2.5>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <dirfd@plt>:
  407070:	jmp    QWORD PTR [rip+0xafca]        # 412040 <dirfd@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <readdir@plt>:
  407080:	jmp    QWORD PTR [rip+0xafc2]        # 412048 <readdir@GLIBC_2.2.5>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <readlinkat@plt>:
  407090:	jmp    QWORD PTR [rip+0xafba]        # 412050 <readlinkat@GLIBC_2.4>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <openat@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xafb2]        # 412058 <openat@GLIBC_2.4>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <closedir@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xafaa]        # 412060 <closedir@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <lseek@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xafa2]        # 412068 <lseek@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <mmap@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xaf9a]        # 412070 <mmap@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <memfd_create@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xaf92]        # 412078 <memfd_create@GLIBC_2.27>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <ftruncate@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xaf8a]        # 412080 <ftruncate@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <write@plt>:
  407100:	jmp    QWORD PTR [rip+0xaf82]        # 412088 <write@GLIBC_2.2.5>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <backtrace@plt>:
  407110:	jmp    QWORD PTR [rip+0xaf7a]        # 412090 <backtrace@GLIBC_2.2.5>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <pthread_setspecific@plt>:
  407120:	jmp    QWORD PTR [rip+0xaf72]        # 412098 <pthread_setspecific@GLIBC_2.34>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <clock_gettime@plt>:
  407130:	jmp    QWORD PTR [rip+0xaf6a]        # 4120a0 <clock_gettime@GLIBC_2.17>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <__x86_get_cpuid_feature_leaf@plt>:
  407140:	jmp    QWORD PTR [rip+0xaf62]        # 4120a8 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <free@plt>:
  407150:	jmp    QWORD PTR [rip+0xaf5a]        # 4120b0 <free@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <munmap@plt>:
  407160:	jmp    QWORD PTR [rip+0xaf52]        # 4120b8 <munmap@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <mprotect@plt>:
  407170:	jmp    QWORD PTR [rip+0xaf4a]        # 4120c0 <mprotect@GLIBC_2.2.5>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <exit@plt>:
  407180:	jmp    QWORD PTR [rip+0xaf42]        # 4120c8 <exit@GLIBC_2.2.5>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <pthread_key_create@plt>:
  407190:	jmp    QWORD PTR [rip+0xaf3a]        # 4120d0 <pthread_key_create@GLIBC_2.34>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <syscall@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xaf32]        # 4120d8 <syscall@GLIBC_2.2.5>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <dladdr@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xaf2a]        # 4120e0 <dladdr@GLIBC_2.34>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <malloc@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xaf22]        # 4120e8 <malloc@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <madvise@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xaf22]        # 4120f8 <madvise@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <pthread_key_delete@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xaf1a]        # 412100 <pthread_key_delete@GLIBC_2.34>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <gettid@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xaf12]        # 412108 <gettid@GLIBC_2.30>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xaddf]        # 412000 <__swc_fn_585f006d_000176_4de704de+0x400>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   411100 <__swc_fn_585f006d_000125_540bf7e8>
  40724e:	xor    ecx,ecx
  407250:	call   410820 <__swc_fn_585f006d_000098_4f209617>
  407255:	call   407320 <__swc_fn_585f006d_000003_8d3f617b>
  40725a:	call   408ed0 <__swc_fn_585f006d_000099_65137b72>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_585f006d_000000_2744b483>:
  407270:	push   rbx
  407271:	sub    rsp,0x70
  407275:	cmp    rcx,0xffffffffffffffef
  407279:	jbe    407283 <__swc_fn_585f006d_000000_2744b483+0x13>
  40727b:	xor    eax,eax
  40727d:	add    rsp,0x70
  407281:	pop    rbx
  407282:	ret
  407283:	vxorps xmm0,xmm0,xmm0
  407287:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40728d:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  407293:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  407299:	vzeroupper
  40729c:	lea    rax,[rcx+0x10]
  4072a0:	mov    QWORD PTR [rsp+0x50],rax
  4072a5:	mov    DWORD PTR [rsp+0x60],0x10
  4072ad:	mov    rcx,QWORD PTR [rip+0x1bd8c]        # 423040 <__swc_bss_base_585f006d>
  4072b4:	test   rcx,rcx
  4072b7:	jne    4072c9 <__swc_fn_585f006d_000000_2744b483+0x59>
  4072b9:	call   40e820 <__swc_fn_585f006d_000169_994c8876>
  4072be:	lea    rcx,[rax+0x1]
  4072c2:	mov    QWORD PTR [rip+0x1bd77],rcx        # 423040 <__swc_bss_base_585f006d>
  4072c9:	dec    rcx
  4072cc:	call   40b6e0 <__swc_fn_585f006d_000171_360af05d>
  4072d1:	mov    rcx,QWORD PTR [rax]
  4072d4:	lea    rdx,[rsp+0x8]
  4072d9:	mov    rbx,QWORD PTR [rax+0x8]
  4072dd:	mov    rbx,QWORD PTR [rbx+0x8]
  4072e1:	call   rbx
  4072e3:	mov    rax,QWORD PTR [rsp+0x48]
  4072e8:	test   rax,rax
  4072eb:	jne    4072f5 <__swc_fn_585f006d_000000_2744b483+0x85>
  4072ed:	xor    eax,eax
  4072ef:	add    rsp,0x70
  4072f3:	pop    rbx
  4072f4:	ret
  4072f5:	mov    rcx,QWORD PTR [rsp+0x50]
  4072fa:	mov    QWORD PTR [rax],rcx
  4072fd:	mov    QWORD PTR [rax+0x8],0x0
  407305:	lea    rax,[rax+0x10]
  407309:	add    rsp,0x70
  40730d:	pop    rbx
  40730e:	ret
	...

0000000000407320 <__swc_fn_585f006d_000003_8d3f617b>:
  407320:	push   rbp
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	push   r13
  407327:	push   r14
  407329:	sub    rsp,0x10
  40732d:	mov    rbp,rsp
  407330:	vmovups XMMWORD PTR [rsp],xmm6
  407335:	sub    rsp,0xc0
  40733c:	mov    ecx,0x48
  407341:	sub    rsp,0x8
  407345:	call   407270 <__swc_fn_585f006d_000000_2744b483>
  40734a:	add    rsp,0x8
  40734e:	mov    rsi,rax
  407351:	mov    ecx,0x48
  407356:	sub    rsp,0x8
  40735a:	call   407270 <__swc_fn_585f006d_000000_2744b483>
  40735f:	add    rsp,0x8
  407363:	mov    rdi,rax
  407366:	mov    ecx,0x48
  40736b:	sub    rsp,0x8
  40736f:	call   407270 <__swc_fn_585f006d_000000_2744b483>
  407374:	add    rsp,0x8
  407378:	mov    r12,rax
  40737b:	sub    rsp,0x8
  40737f:	call   40e9e0 <__swc_fn_585f006d_000002_1ca87929>
  407384:	add    rsp,0x8
  407388:	vmovups xmm6,xmm0
  40738c:	mov    QWORD PTR [rdi],0x0
  407393:	mov    QWORD PTR [rdi+0x8],0x1
  40739b:	mov    QWORD PTR [rdi+0x10],0x2
  4073a3:	mov    QWORD PTR [rdi+0x18],0x3
  4073ab:	mov    QWORD PTR [rdi+0x20],0x4
  4073b3:	mov    QWORD PTR [rdi+0x28],0x5
  4073bb:	mov    QWORD PTR [rdi+0x30],0x6
  4073c3:	mov    QWORD PTR [rdi+0x38],0x7
  4073cb:	mov    QWORD PTR [rdi+0x40],0x8
  4073d3:	xor    eax,eax
  4073d5:	xor    ecx,ecx
  4073d7:	xor    edx,edx
  4073d9:	mov    r8d,0x9
  4073df:	nop
  4073e0:	cmp    r8,0x1
  4073e4:	je     4073fe <__swc_fn_585f006d_000003_8d3f617b+0xde>
  4073e6:	cs nop WORD PTR [rax+rax*1+0x0]
  4073f0:	mov    QWORD PTR [r12+r8*8-0x8],r8
  4073f5:	dec    r8
  4073f8:	cmp    r8,0x1
  4073fc:	jne    4073f0 <__swc_fn_585f006d_000003_8d3f617b+0xd0>
  4073fe:	mov    r9,QWORD PTR [rdi]
  407401:	mov    QWORD PTR [rsi],r9
  407404:	mov    r10,QWORD PTR [rdi+0x8]
  407408:	mov    QWORD PTR [rsi+0x8],r10
  40740c:	mov    r10,QWORD PTR [rdi+0x10]
  407410:	mov    QWORD PTR [rsi+0x10],r10
  407414:	mov    r10,QWORD PTR [rdi+0x18]
  407418:	mov    QWORD PTR [rsi+0x18],r10
  40741c:	mov    r10,QWORD PTR [rdi+0x20]
  407420:	mov    QWORD PTR [rsi+0x20],r10
  407424:	mov    r10,QWORD PTR [rdi+0x28]
  407428:	mov    QWORD PTR [rsi+0x28],r10
  40742c:	mov    r10,QWORD PTR [rdi+0x30]
  407430:	mov    QWORD PTR [rsi+0x30],r10
  407434:	mov    r10,QWORD PTR [rdi+0x38]
  407438:	mov    QWORD PTR [rsi+0x38],r10
  40743c:	mov    r10,QWORD PTR [rdi+0x40]
  407440:	mov    QWORD PTR [rsi+0x40],r10
  407444:	xor    r10d,r10d
  407447:	test   r9,r9
  40744a:	je     4074fa <__swc_fn_585f006d_000003_8d3f617b+0x1da>
  407450:	jle    4074eb <__swc_fn_585f006d_000003_8d3f617b+0x1cb>
  407456:	mov    r14,QWORD PTR [rsi+r9*8]
  40745a:	mov    QWORD PTR [rsi],r14
  40745d:	mov    QWORD PTR [rsi+r9*8],r9
  407461:	dec    r9
  407464:	cmp    r9,0x1
  407468:	jle    4074eb <__swc_fn_585f006d_000003_8d3f617b+0x1cb>
  40746e:	mov    r13,QWORD PTR [rsi+0x8]
  407472:	mov    r14,QWORD PTR [rsi+r9*8]
  407476:	mov    QWORD PTR [rsi+0x8],r14
  40747a:	mov    QWORD PTR [rsi+r9*8],r13
  40747e:	dec    r9
  407481:	cmp    r9,0x2
  407485:	jle    4074eb <__swc_fn_585f006d_000003_8d3f617b+0x1cb>
  407487:	mov    r13,QWORD PTR [rsi+0x10]
  40748b:	mov    r14,QWORD PTR [rsi+r9*8]
  40748f:	mov    QWORD PTR [rsi+0x10],r14
  407493:	mov    QWORD PTR [rsi+r9*8],r13
  407497:	dec    r9
  40749a:	cmp    r9,0x3
  40749e:	jle    4074eb <__swc_fn_585f006d_000003_8d3f617b+0x1cb>
  4074a0:	mov    r13,QWORD PTR [rsi+0x18]
  4074a4:	mov    r14,QWORD PTR [rsi+r9*8]
  4074a8:	mov    QWORD PTR [rsi+0x18],r14
  4074ac:	mov    QWORD PTR [rsi+r9*8],r13
  4074b0:	dec    r9
  4074b3:	cmp    r9,0x4
  4074b7:	jle    4074eb <__swc_fn_585f006d_000003_8d3f617b+0x1cb>
  4074b9:	mov    r11d,0x4
  4074bf:	jmp    4074d0 <__swc_fn_585f006d_000003_8d3f617b+0x1b0>
  4074c1:	cmp    r11,r9
  4074c4:	jge    4074eb <__swc_fn_585f006d_000003_8d3f617b+0x1cb>
  4074c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4074d0:	mov    r13,QWORD PTR [rsi+r11*8]
  4074d4:	mov    r14,QWORD PTR [rsi+r9*8]
  4074d8:	mov    QWORD PTR [rsi+r11*8],r14
  4074dc:	mov    QWORD PTR [rsi+r9*8],r13
  4074e0:	inc    r11
  4074e3:	dec    r9
  4074e6:	cmp    r11,r9
  4074e9:	jl     4074d0 <__swc_fn_585f006d_000003_8d3f617b+0x1b0>
  4074eb:	inc    r10
  4074ee:	mov    r9,QWORD PTR [rsi]
  4074f1:	test   r9,r9
  4074f4:	jne    407450 <__swc_fn_585f006d_000003_8d3f617b+0x130>
  4074fa:	cmp    r10,rcx
  4074fd:	cmovg  rcx,r10
  407501:	test   dl,0x1
  407504:	jne    40750b <__swc_fn_585f006d_000003_8d3f617b+0x1eb>
  407506:	add    rax,r10
  407509:	jmp    40750e <__swc_fn_585f006d_000003_8d3f617b+0x1ee>
  40750b:	sub    rax,r10
  40750e:	xchg   ax,ax
  407510:	cmp    r8,0x9
  407514:	je     40756b <__swc_fn_585f006d_000003_8d3f617b+0x24b>
  407516:	mov    r10,QWORD PTR [rdi]
  407519:	xor    r11d,r11d
  40751c:	test   r8,r8
  40751f:	jle    407552 <__swc_fn_585f006d_000003_8d3f617b+0x232>
  407521:	cs nop WORD PTR [rax+rax*1+0x0]
  40752b:	cs nop WORD PTR [rax+rax*1+0x0]
  407535:	cs nop WORD PTR [rax+rax*1+0x0]
  40753f:	nop
  407540:	mov    r13,QWORD PTR [rdi+r11*8+0x8]
  407545:	mov    QWORD PTR [rdi+r11*8],r13
  407549:	add    r11,0x1
  40754d:	cmp    r11,r8
  407550:	jl     407540 <__swc_fn_585f006d_000003_8d3f617b+0x220>
  407552:	mov    QWORD PTR [rdi+r8*8],r10
  407556:	dec    QWORD PTR [r12+r8*8]
  40755a:	je     40755e <__swc_fn_585f006d_000003_8d3f617b+0x23e>
  40755c:	jns    407563 <__swc_fn_585f006d_000003_8d3f617b+0x243>
  40755e:	inc    r8
  407561:	jmp    407510 <__swc_fn_585f006d_000003_8d3f617b+0x1f0>
  407563:	inc    rdx
  407566:	jmp    4073e0 <__swc_fn_585f006d_000003_8d3f617b+0xc0>
  40756b:	imul   r13,rax,0x3e8
  407572:	add    r13,rcx
  407575:	sub    rsp,0x8
  407579:	call   40e9e0 <__swc_fn_585f006d_000002_1ca87929>
  40757e:	add    rsp,0x8
  407582:	vsubsd xmm0,xmm0,xmm6
  407586:	vmulsd xmm0,xmm0,QWORD PTR [rip+0xac9a]        # 412228 <__swc_rdata_base_585f006d+0x118>
  40758e:	lea    rax,[rip+0xab8b]        # 412120 <__swc_rdata_base_585f006d+0x10>
  407595:	sub    rsp,0x90
  40759c:	mov    rcx,rsp
  40759f:	vmovups xmm1,XMMWORD PTR [rip+0xac61]        # 412208 <__swc_rdata_base_585f006d+0xf8>
  4075a7:	vmovups XMMWORD PTR [rcx],xmm1
  4075ab:	mov    QWORD PTR [rcx+0x30],rsp
  4075af:	lea    rdx,[rip+0xab7a]        # 412130 <__swc_rdata_base_585f006d+0x20>
  4075b6:	mov    QWORD PTR [rcx+0x38],rdx
  4075ba:	mov    QWORD PTR [rcx+0x10],r13
  4075be:	lea    r8,[rsp+0x10]
  4075c3:	mov    QWORD PTR [rcx+0x40],r8
  4075c7:	lea    r8,[rip+0xabaa]        # 412178 <__swc_rdata_base_585f006d+0x68>
  4075ce:	mov    QWORD PTR [rcx+0x48],r8
  4075d2:	vmovups xmm1,XMMWORD PTR [rip+0xac3e]        # 412218 <__swc_rdata_base_585f006d+0x108>
  4075da:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  4075df:	lea    r8,[rsp+0x18]
  4075e4:	mov    QWORD PTR [rcx+0x50],r8
  4075e8:	mov    QWORD PTR [rcx+0x58],rdx
  4075ec:	vmovsd QWORD PTR [rcx+0x28],xmm0
  4075f1:	lea    r8,[rcx+0x28]
  4075f5:	mov    QWORD PTR [rcx+0x60],r8
  4075f9:	lea    r8,[rip+0xabc0]        # 4121c0 <__swc_rdata_base_585f006d+0xb0>
  407600:	mov    QWORD PTR [rcx+0x68],r8
  407604:	mov    QWORD PTR [rcx+0x70],rax
  407608:	mov    QWORD PTR [rcx+0x78],rdx
  40760c:	lea    rax,[rcx+0x30]
  407610:	mov    QWORD PTR [rcx+0x80],rax
  407617:	mov    QWORD PTR [rcx+0x88],0x5
  407622:	lea    rcx,[rcx+0x80]
  407629:	sub    rsp,0x8
  40762d:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  407632:	add    rsp,0x8
  407636:	add    rsp,0x90
  40763d:	mov    rcx,r12
  407640:	sub    rsp,0x8
  407644:	call   40b880 <__swc_fn_585f006d_000001_5d3d19bd>
  407649:	add    rsp,0x8
  40764d:	mov    rcx,rdi
  407650:	sub    rsp,0x8
  407654:	call   40b880 <__swc_fn_585f006d_000001_5d3d19bd>
  407659:	add    rsp,0x8
  40765d:	mov    rcx,rsi
  407660:	sub    rsp,0x8
  407664:	call   40b880 <__swc_fn_585f006d_000001_5d3d19bd>
  407669:	add    rsp,0xc8
  407670:	vmovups xmm6,XMMWORD PTR [rsp]
  407675:	add    rsp,0x10
  407679:	pop    r14
  40767b:	pop    r13
  40767d:	pop    r12
  40767f:	pop    rdi
  407680:	pop    rsi
  407681:	pop    rbp
  407682:	ret
	...

0000000000407690 <__swc_fn_585f006d_000006_81d2e1e9>:
  407690:	sub    rsp,0x8
  407694:	call   410ca0 <__swc_fn_585f006d_000113_6b799b8d>
  407699:	mov    rcx,rax
  40769c:	test   rax,rax
  40769f:	je     4076c6 <__swc_fn_585f006d_000006_81d2e1e9+0x36>
  4076a1:	lea    rdx,[rip+0x1b9a0]        # 423048 <__swc_bss_base_585f006d+0x8>
  4076a8:	mov    r8,QWORD PTR [rip+0x1b999]        # 423048 <__swc_bss_base_585f006d+0x8>
  4076af:	nop
  4076b0:	lea    r9,[r8+0x1]
  4076b4:	mov    rax,r8
  4076b7:	lock cmpxchg QWORD PTR [rdx],r9
  4076bc:	cmp    rax,r8
  4076bf:	je     4076c6 <__swc_fn_585f006d_000006_81d2e1e9+0x36>
  4076c1:	mov    r8,rax
  4076c4:	jmp    4076b0 <__swc_fn_585f006d_000006_81d2e1e9+0x20>
  4076c6:	mov    rax,rcx
  4076c9:	add    rsp,0x8
  4076cd:	ret
	...

00000000004076d0 <__swc_fn_585f006d_000009_065ed5b1>:
  4076d0:	mov    r8d,edx
  4076d3:	xor    eax,eax
  4076d5:	tzcnt  eax,edx
  4076d9:	shrx   r9d,edx,eax
  4076de:	mov    DWORD PTR [rcx+0x2c],edx
  4076e1:	xor    eax,eax
  4076e3:	tzcnt  eax,edx
  4076e7:	mov    BYTE PTR [rcx+0x38],al
  4076ea:	mov    eax,0xffffffff
  4076ef:	xor    edx,edx
  4076f1:	div    r8d
  4076f4:	mov    DWORD PTR [rcx+0x34],eax
  4076f7:	mov    eax,r9d
  4076fa:	mov    edx,r9d
  4076fd:	imul   edx,r9d
  407701:	mov    r8d,0x2
  407707:	sub    r8d,edx
  40770a:	imul   eax,r8d
  40770e:	mov    edx,r9d
  407711:	imul   edx,eax
  407714:	mov    r8d,0x2
  40771a:	sub    r8d,edx
  40771d:	imul   eax,r8d
  407721:	mov    edx,r9d
  407724:	imul   edx,eax
  407727:	mov    r8d,0x2
  40772d:	sub    r8d,edx
  407730:	imul   eax,r8d
  407734:	mov    edx,r9d
  407737:	imul   edx,eax
  40773a:	mov    r8d,0x2
  407740:	sub    r8d,edx
  407743:	imul   eax,r8d
  407747:	imul   r9d,eax
  40774b:	mov    edx,0x2
  407750:	sub    edx,r9d
  407753:	imul   eax,edx
  407756:	mov    DWORD PTR [rcx+0x30],eax
  407759:	ret
  40775a:	add    BYTE PTR [rax],al
  40775c:	add    BYTE PTR [rax],al
	...

0000000000407760 <__swc_fn_585f006d_000012_861b8b62>:
  407760:	xor    eax,eax
  407762:	mov    DWORD PTR [rcx+0x68],eax
  407765:	ret
	...

0000000000407770 <__swc_fn_585f006d_000015_9dea5065>:
  407770:	mov    eax,DWORD PTR [rcx+0x28]
  407773:	shlx   eax,edx,eax
  407778:	shl    rax,0x10
  40777c:	lea    rdx,[rcx+rax*1]
  407780:	lea    rax,[rcx+0x3000]
  407787:	cmp    rdx,rax
  40778a:	cmovae rax,rdx
  40778e:	ret
	...

0000000000407790 <__swc_fn_585f006d_000018_283e2b5e>:
  407790:	push   rsi
  407791:	push   rdi
  407792:	push   r12
  407794:	push   r13
  407796:	push   r14
  407798:	mov    rsi,rdx
  40779b:	mov    rdi,rcx
  40779e:	rex mov dl,BYTE PTR [rsi+0x3a]
  4077a2:	mov    ecx,DWORD PTR [rdi+0x28]
  4077a5:	shr    dl,cl
  4077a7:	mov    r12d,0x1
  4077ad:	mov    ecx,edx
  4077af:	shl    r12,cl
  4077b2:	mov    r13d,DWORD PTR [rsi+0x3c]
  4077b6:	rex mov BYTE PTR [rsi+0x3b],0x0
  4077bb:	mov    QWORD PTR [rsi+0x40],0x0
  4077c3:	mov    QWORD PTR [rsi],0x0
  4077ca:	mov    rax,QWORD PTR [rsi+0x10]
  4077ce:	mov    QWORD PTR [rsi+0x20],rax
  4077d2:	lea    r14,[rip+0x1b877]        # 423050 <__swc_bss_base_585f006d+0x10>
  4077d9:	mov    rax,QWORD PTR [r14]
  4077dc:	shr    rax,0x2
  4077e0:	mov    rcx,rax
  4077e3:	cmp    rax,0x800000
  4077ea:	mov    eax,0x800000
  4077ef:	cmovb  rcx,rax
  4077f3:	lea    r8,[rip+0x1b866]        # 423060 <__swc_bss_base_585f006d+0x20>
  4077fa:	mov    rax,QWORD PTR [r8]
  4077fd:	mov    r9,rax
  407800:	lea    r10,[r9+r13*1]
  407804:	cmp    r10,rcx
  407807:	ja     40782b <__swc_fn_585f006d_000018_283e2b5e+0x9b>
  407809:	mov    rax,r9
  40780c:	lock cmpxchg QWORD PTR [r8],r10
  407811:	cmp    rax,r9
  407814:	je     40781b <__swc_fn_585f006d_000018_283e2b5e+0x8b>
  407816:	mov    r9,rax
  407819:	jmp    407800 <__swc_fn_585f006d_000018_283e2b5e+0x70>
  40781b:	mov    rcx,rdi
  40781e:	mov    rdx,r12
  407821:	call   40edd0 <__swc_fn_585f006d_000020_de02dbdf>
  407826:	jmp    4078ad <__swc_fn_585f006d_000018_283e2b5e+0x11d>
  40782b:	mov    rcx,rdi
  40782e:	movzx  edx,dl
  407831:	call   407770 <__swc_fn_585f006d_000015_9dea5065>
  407836:	test   r13,r13
  407839:	je     4078a6 <__swc_fn_585f006d_000018_283e2b5e+0x116>
  40783f:	mov    rcx,rax
  407842:	mov    rdx,r13
  407845:	call   410e20 <__swc_fn_585f006d_000116_e9fc0224>
  40784a:	mov    rcx,QWORD PTR [rip+0x1b7ff]        # 423050 <__swc_bss_base_585f006d+0x10>
  407851:	cs nop WORD PTR [rax+rax*1+0x0]
  40785b:	nop    DWORD PTR [rax+rax*1+0x0]
  407860:	mov    rdx,rcx
  407863:	sub    rdx,r13
  407866:	mov    rax,rcx
  407869:	lock cmpxchg QWORD PTR [r14],rdx
  40786e:	cmp    rax,rcx
  407871:	je     407878 <__swc_fn_585f006d_000018_283e2b5e+0xe8>
  407873:	mov    rcx,rax
  407876:	jmp    407860 <__swc_fn_585f006d_000018_283e2b5e+0xd0>
  407878:	lea    rcx,[rip+0x1b7e9]        # 423068 <__swc_bss_base_585f006d+0x28>
  40787f:	mov    rdx,QWORD PTR [rip+0x1b7e2]        # 423068 <__swc_bss_base_585f006d+0x28>
  407886:	cs nop WORD PTR [rax+rax*1+0x0]
  407890:	lea    r8,[rdx+0x1]
  407894:	mov    rax,rdx
  407897:	lock cmpxchg QWORD PTR [rcx],r8
  40789c:	cmp    rax,rdx
  40789f:	je     4078a6 <__swc_fn_585f006d_000018_283e2b5e+0x116>
  4078a1:	mov    rdx,rax
  4078a4:	jmp    407890 <__swc_fn_585f006d_000018_283e2b5e+0x100>
  4078a6:	mov    DWORD PTR [rsi+0x3c],0x0
  4078ad:	mov    rcx,rdi
  4078b0:	mov    rdx,r12
  4078b3:	call   40bc90 <__swc_fn_585f006d_000022_c8f5f27c>
  4078b8:	pop    r14
  4078ba:	pop    r13
  4078bc:	pop    r12
  4078be:	pop    rdi
  4078bf:	pop    rsi
  4078c0:	ret
	...

00000000004078d0 <__swc_fn_585f006d_000021_fd2b165c>:
  4078d0:	mov    r8,QWORD PTR [rcx+0x48]
  4078d4:	test   r8,rdx
  4078d7:	je     407908 <__swc_fn_585f006d_000021_fd2b165c+0x38>
  4078d9:	nop    DWORD PTR [rax+0x0]
  4078e0:	mov    rax,rdx
  4078e3:	not    rax
  4078e6:	mov    r9,r8
  4078e9:	and    r9,rax
  4078ec:	mov    rax,r8
  4078ef:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  4078f5:	cmp    rax,r8
  4078f8:	jne    407900 <__swc_fn_585f006d_000021_fd2b165c+0x30>
  4078fa:	mov    eax,0x1
  4078ff:	ret
  407900:	mov    r8,rax
  407903:	test   rax,rdx
  407906:	jne    4078e0 <__swc_fn_585f006d_000021_fd2b165c+0x10>
  407908:	xor    eax,eax
  40790a:	ret
  40790b:	add    BYTE PTR [rax],al
  40790d:	add    BYTE PTR [rax],al
	...

0000000000407910 <__swc_fn_585f006d_000024_2685aade>:
  407910:	push   rsi
  407911:	push   rdi
  407912:	push   r12
  407914:	push   r13
  407916:	sub    rsp,0x8
  40791a:	mov    rsi,rdx
  40791d:	mov    rdi,rcx
  407920:	lea    r12,[rip+0x1b8d1]        # 4231f8 <__swc_bss_base_585f006d+0x1b8>
  407927:	mov    rcx,r12
  40792a:	call   40df20 <__swc_fn_585f006d_000139_86bb0f90>
  40792f:	xor    eax,eax
  407931:	mov    rcx,QWORD PTR [rip+0x1b8c8]        # 423200 <__swc_bss_base_585f006d+0x1c0>
  407938:	mov    r13,rcx
  40793b:	test   r13,r13
  40793e:	je     40798b <__swc_fn_585f006d_000024_2685aade+0x7b>
  407940:	mov    rcx,QWORD PTR [r13+0x10]
  407944:	cmp    DWORD PTR [r13+0x28],esi
  407948:	jne    407980 <__swc_fn_585f006d_000024_2685aade+0x70>
  40794a:	test   rax,rax
  40794d:	jne    407958 <__swc_fn_585f006d_000024_2685aade+0x48>
  40794f:	mov    QWORD PTR [rip+0x1b8aa],rcx        # 423200 <__swc_bss_base_585f006d+0x1c0>
  407956:	jmp    40795c <__swc_fn_585f006d_000024_2685aade+0x4c>
  407958:	mov    QWORD PTR [rax+0x10],rcx
  40795c:	vxorps xmm0,xmm0,xmm0
  407960:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407966:	mov    QWORD PTR [r13+0x8],rdi
  40796a:	mov    rcx,r12
  40796d:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  407972:	mov    rax,r13
  407975:	add    rsp,0x8
  407979:	pop    r13
  40797b:	pop    r12
  40797d:	pop    rdi
  40797e:	pop    rsi
  40797f:	ret
  407980:	mov    rax,r13
  407983:	mov    r13,rcx
  407986:	test   rcx,rcx
  407989:	jne    407940 <__swc_fn_585f006d_000024_2685aade+0x30>
  40798b:	mov    ecx,esi
  40798d:	call   40ee00 <__swc_fn_585f006d_000023_2d0fcd2c>
  407992:	mov    rsi,rax
  407995:	test   rax,rax
  407998:	jne    4079af <__swc_fn_585f006d_000024_2685aade+0x9f>
  40799a:	mov    rcx,r12
  40799d:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  4079a2:	xor    eax,eax
  4079a4:	add    rsp,0x8
  4079a8:	pop    r13
  4079aa:	pop    r12
  4079ac:	pop    rdi
  4079ad:	pop    rsi
  4079ae:	ret
  4079af:	mov    QWORD PTR [rsi+0x8],rdi
  4079b3:	mov    rcx,r12
  4079b6:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  4079bb:	mov    rax,rsi
  4079be:	add    rsp,0x8
  4079c2:	pop    r13
  4079c4:	pop    r12
  4079c6:	pop    rdi
  4079c7:	pop    rsi
  4079c8:	ret
	...

00000000004079e0 <__swc_fn_585f006d_000027_9798fb47>:
  4079e0:	vxorps xmm0,xmm0,xmm0
  4079e4:	xor    eax,eax
  4079e6:	cs nop WORD PTR [rax+rax*1+0x0]
  4079f0:	cs nop WORD PTR [rax+rax*1+0x0]
  4079fa:	nop    WORD PTR [rax+rax*1+0x0]
  407a00:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  407a05:	add    rax,0x10
  407a09:	cmp    rax,0x2b00
  407a10:	jne    407a00 <__swc_fn_585f006d_000027_9798fb47+0x20>
  407a12:	ret
	...

0000000000407a20 <__swc_fn_585f006d_000030_9798fb47>:
  407a20:	vxorps xmm0,xmm0,xmm0
  407a24:	vmovups XMMWORD PTR [rcx],xmm0
  407a28:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  407a2d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407a32:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407a37:	ret
	...

0000000000407a40 <__swc_fn_585f006d_000033_9798fb47>:
  407a40:	vxorps xmm0,xmm0,xmm0
  407a44:	vmovups XMMWORD PTR [rcx],xmm0
  407a48:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  407a4d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407a52:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407a57:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  407a5c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407a61:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407a66:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  407a6b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  407a73:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  407a7b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  407a83:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  407a8b:	mov    QWORD PTR [rcx+0xc0],0x0
  407a96:	ret
	...

0000000000407aa0 <__swc_fn_585f006d_000036_92d9bbff>:
  407aa0:	push   rsi
  407aa1:	push   rdi
  407aa2:	sub    rsp,0x8
  407aa6:	mov    rsi,rcx
  407aa9:	lea    rdi,[rip+0x19550]        # 421000 <__swc_data_base_585f006d>
  407ab0:	mov    rax,QWORD PTR [rdi]
  407ab3:	cmp    rax,0xffffffffffffffff
  407ab7:	je     407abe <__swc_fn_585f006d_000036_92d9bbff+0x1e>
  407ab9:	mov    rdi,rax
  407abc:	jmp    407aeb <__swc_fn_585f006d_000036_92d9bbff+0x4b>
  407abe:	call   40dc00 <__swc_fn_585f006d_000127_58f0f391>
  407ac3:	mov    rcx,rax
  407ac6:	cmp    rax,0xffffffffffffffff
  407aca:	je     407afc <__swc_fn_585f006d_000036_92d9bbff+0x5c>
  407acc:	mov    rax,0xffffffffffffffff
  407ad3:	lock cmpxchg QWORD PTR [rdi],rcx
  407ad8:	cmp    rax,0xffffffffffffffff
  407adc:	je     407ae8 <__swc_fn_585f006d_000036_92d9bbff+0x48>
  407ade:	mov    rdi,rax
  407ae1:	call   4111f0 <__swc_fn_585f006d_000128_a481cb88>
  407ae6:	jmp    407aeb <__swc_fn_585f006d_000036_92d9bbff+0x4b>
  407ae8:	mov    rdi,rcx
  407aeb:	cmp    rdi,0xffffffffffffffff
  407aef:	je     407afc <__swc_fn_585f006d_000036_92d9bbff+0x5c>
  407af1:	mov    rcx,rdi
  407af4:	mov    rdx,rsi
  407af7:	call   409bb0 <__swc_fn_585f006d_000129_4bbe3f14>
  407afc:	add    rsp,0x8
  407b00:	pop    rdi
  407b01:	pop    rsi
  407b02:	ret
	...

0000000000407b10 <__swc_fn_585f006d_000039_03f1bf9a>:
  407b10:	sub    rsp,0x38
  407b14:	mov    rax,rdx
  407b17:	test   dl,dl
  407b19:	jne    407b31 <__swc_fn_585f006d_000039_03f1bf9a+0x21>
  407b1b:	mov    rax,r8
  407b1e:	test   r8b,r8b
  407b21:	cmove  eax,r9d
  407b25:	test   al,al
  407b27:	cmove  eax,r10d
  407b2b:	test   al,al
  407b2d:	cmove  eax,r11d
  407b31:	test   al,al
  407b33:	jne    407b3a <__swc_fn_585f006d_000039_03f1bf9a+0x2a>
  407b35:	add    rsp,0x38
  407b39:	ret
  407b3a:	lea    rcx,[rip+0xa6f7]        # 412238 <__swc_rdata_base_585f006d+0x128>
  407b41:	vmovups xmm0,XMMWORD PTR [rip+0xa6ff]        # 412248 <__swc_rdata_base_585f006d+0x138>
  407b49:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  407b4f:	vmovups xmm0,XMMWORD PTR [rip+0xa701]        # 412258 <__swc_rdata_base_585f006d+0x148>
  407b57:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  407b5d:	vmovups xmm0,XMMWORD PTR [rip+0xa703]        # 412268 <__swc_rdata_base_585f006d+0x158>
  407b65:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  407b6b:	lea    rdx,[rsp+0x8]
  407b70:	call   410a20 <__swc_fn_585f006d_000107_90faaa26>
  407b75:	jmp    407b35 <__swc_fn_585f006d_000039_03f1bf9a+0x25>
	...

0000000000407b80 <__swc_fn_585f006d_000042_facd3e17>:
  407b80:	sub    rsp,0x8
  407b84:	mov    eax,0x1000
  407b89:	test   eax,eax
  407b8b:	mov    r8d,0x8
  407b91:	cmove  eax,r8d
  407b95:	dec    rax
  407b98:	mov    r8,0xffffffffffffffff
  407b9f:	sub    r8,rax
  407ba2:	cmp    rdx,r8
  407ba5:	ja     407bb5 <__swc_fn_585f006d_000042_facd3e17+0x35>
  407ba7:	add    rdx,rax
  407baa:	not    rax
  407bad:	mov    r8,rdx
  407bb0:	and    r8,rax
  407bb3:	jne    407bbc <__swc_fn_585f006d_000042_facd3e17+0x3c>
  407bb5:	xor    eax,eax
  407bb7:	add    rsp,0x8
  407bbb:	ret
  407bbc:	mov    rdx,r8
  407bbf:	call   40f120 <__swc_fn_585f006d_000041_c90d80c1>
  407bc4:	add    rsp,0x8
  407bc8:	ret
  407bc9:	add    BYTE PTR [rax],al
  407bcb:	add    BYTE PTR [rax],al
  407bcd:	add    BYTE PTR [rax],al
	...

0000000000407bd0 <__swc_fn_585f006d_000045_d8bd27c3>:
  407bd0:	push   rsi
  407bd1:	push   rdi
  407bd2:	sub    rsp,0x8
  407bd6:	mov    rsi,rdx
  407bd9:	mov    rdi,rcx
  407bdc:	test   rdx,rdx
  407bdf:	je     407bfb <__swc_fn_585f006d_000045_d8bd27c3+0x2b>
  407be1:	xor    ecx,ecx
  407be3:	call   40bdb0 <__swc_fn_585f006d_000037_28d0e998>
  407be8:	mov    rax,QWORD PTR [rsi]
  407beb:	test   rax,rax
  407bee:	je     407bfb <__swc_fn_585f006d_000045_d8bd27c3+0x2b>
  407bf0:	mov    rcx,rax
  407bf3:	mov    rdx,rsi
  407bf6:	call   40bec0 <__swc_fn_585f006d_000046_b30433d0>
  407bfb:	mov    rcx,rdi
  407bfe:	call   40f180 <__swc_fn_585f006d_000044_a78ae66b>
  407c03:	mov    rsi,rax
  407c06:	test   rax,rax
  407c09:	jne    407c14 <__swc_fn_585f006d_000045_d8bd27c3+0x44>
  407c0b:	xor    eax,eax
  407c0d:	add    rsp,0x8
  407c11:	pop    rdi
  407c12:	pop    rsi
  407c13:	ret
  407c14:	mov    rcx,rsi
  407c17:	call   40bdb0 <__swc_fn_585f006d_000037_28d0e998>
  407c1c:	mov    rax,rsi
  407c1f:	add    rsp,0x8
  407c23:	pop    rdi
  407c24:	pop    rsi
  407c25:	ret
	...

0000000000407c30 <__swc_fn_585f006d_000048_137687bb>:
  407c30:	movzx  eax,BYTE PTR [r8+0x39]
  407c35:	lea    rax,[rax+rax*4]
  407c39:	lea    rax,[rdx+rax*8+0x28]
  407c3e:	mov    ecx,DWORD PTR [r8+0x6c]
  407c42:	test   ecx,ecx
  407c44:	je     407c7d <__swc_fn_585f006d_000048_137687bb+0x4d>
  407c46:	mov    rcx,QWORD PTR [r8+0x50]
  407c4a:	test   rcx,rcx
  407c4d:	je     407c59 <__swc_fn_585f006d_000048_137687bb+0x29>
  407c4f:	mov    rax,QWORD PTR [r8+0x48]
  407c53:	mov    QWORD PTR [rcx+0x48],rax
  407c57:	jmp    407c61 <__swc_fn_585f006d_000048_137687bb+0x31>
  407c59:	mov    rcx,QWORD PTR [r8+0x48]
  407c5d:	mov    QWORD PTR [rax+0x18],rcx
  407c61:	mov    rax,QWORD PTR [r8+0x48]
  407c65:	test   rax,rax
  407c68:	je     407c72 <__swc_fn_585f006d_000048_137687bb+0x42>
  407c6a:	mov    rcx,QWORD PTR [r8+0x50]
  407c6e:	mov    QWORD PTR [rax+0x50],rcx
  407c72:	vxorps xmm0,xmm0,xmm0
  407c76:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  407c7c:	ret
  407c7d:	mov    rcx,QWORD PTR [r8+0x50]
  407c81:	test   rcx,rcx
  407c84:	je     407c90 <__swc_fn_585f006d_000048_137687bb+0x60>
  407c86:	mov    rdx,QWORD PTR [r8+0x48]
  407c8a:	mov    QWORD PTR [rcx+0x48],rdx
  407c8e:	jmp    407c98 <__swc_fn_585f006d_000048_137687bb+0x68>
  407c90:	mov    rcx,QWORD PTR [r8+0x48]
  407c94:	mov    QWORD PTR [rax+0x8],rcx
  407c98:	mov    rcx,QWORD PTR [r8+0x48]
  407c9c:	test   rcx,rcx
  407c9f:	je     407cab <__swc_fn_585f006d_000048_137687bb+0x7b>
  407ca1:	mov    rdx,QWORD PTR [r8+0x50]
  407ca5:	mov    QWORD PTR [rcx+0x50],rdx
  407ca9:	jmp    407cb3 <__swc_fn_585f006d_000048_137687bb+0x83>
  407cab:	mov    rcx,QWORD PTR [r8+0x50]
  407caf:	mov    QWORD PTR [rax+0x10],rcx
  407cb3:	cmp    QWORD PTR [rax],r8
  407cb6:	jne    407cbf <__swc_fn_585f006d_000048_137687bb+0x8f>
  407cb8:	mov    QWORD PTR [rax],0x0
  407cbf:	vxorps xmm0,xmm0,xmm0
  407cc3:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  407cc9:	ret
  407cca:	add    BYTE PTR [rax],al
  407ccc:	add    BYTE PTR [rax],al
	...

0000000000407cd0 <__swc_fn_585f006d_000051_e072b516>:
  407cd0:	sub    rsp,0x8
  407cd4:	mov    r9,r8
  407cd7:	mov    r10,rdx
  407cda:	call   407c30 <__swc_fn_585f006d_000048_137687bb>
  407cdf:	mov    DWORD PTR [r9+0x6c],0x0
  407ce7:	movzx  eax,BYTE PTR [r9+0x39]
  407cec:	lea    rax,[rax+rax*4]
  407cf0:	lea    rax,[r10+rax*8+0x28]
  407cf5:	mov    rcx,QWORD PTR [rax+0x10]
  407cf9:	mov    QWORD PTR [r9+0x50],rcx
  407cfd:	mov    QWORD PTR [r9+0x48],0x0
  407d05:	mov    rcx,QWORD PTR [rax+0x10]
  407d09:	test   rcx,rcx
  407d0c:	je     407d14 <__swc_fn_585f006d_000051_e072b516+0x44>
  407d0e:	mov    QWORD PTR [rcx+0x48],r9
  407d12:	jmp    407d18 <__swc_fn_585f006d_000051_e072b516+0x48>
  407d14:	mov    QWORD PTR [rax+0x8],r9
  407d18:	mov    QWORD PTR [rax+0x10],r9
  407d1c:	add    rsp,0x8
  407d20:	ret
	...

0000000000407d40 <__swc_fn_585f006d_000054_faa92dcc>:
  407d40:	push   rsi
  407d41:	push   rdi
  407d42:	push   r12
  407d44:	push   r13
  407d46:	push   r14
  407d48:	push   r15
  407d4a:	sub    rsp,0x1f8
  407d51:	mov    esi,r8d
  407d54:	mov    QWORD PTR [rsp+0x1e8],rsi
  407d5c:	mov    rdi,rcx
  407d5f:	mov    r12,rdx
  407d62:	lea    r13,[rsi+rsi*4]
  407d66:	lea    r13,[rdx+r13*8+0x28]
  407d6b:	call   40c320 <__swc_fn_585f006d_000052_d846b172>
  407d70:	add    DWORD PTR [r12+0x24],0x1
  407d76:	test   BYTE PTR [r12+0x24],0x3f
  407d7c:	jne    407d86 <__swc_fn_585f006d_000054_faa92dcc+0x46>
  407d7e:	mov    rcx,rdi
  407d81:	call   40f300 <__swc_fn_585f006d_000053_3af34d7f>
  407d86:	mov    rax,QWORD PTR [r13+0x8]
  407d8a:	mov    r14,rax
  407d8d:	nop    DWORD PTR [rax]
  407d90:	test   r14,r14
  407d93:	jne    407da2 <__swc_fn_585f006d_000054_faa92dcc+0x62>
  407d95:	mov    rsi,QWORD PTR [rsp+0x1e8]
  407d9d:	jmp    407ea9 <__swc_fn_585f006d_000054_faa92dcc+0x169>
  407da2:	mov    r15,QWORD PTR [r14+0x48]
  407da6:	mov    rcx,r14
  407da9:	call   40ba80 <__swc_fn_585f006d_000013_e4b0ddfc>
  407dae:	mov    rax,QWORD PTR [r14]
  407db1:	test   rax,rax
  407db4:	je     407dc6 <__swc_fn_585f006d_000054_faa92dcc+0x86>
  407db6:	mov    rcx,QWORD PTR [rax]
  407db9:	mov    QWORD PTR [r14],rcx
  407dbc:	add    DWORD PTR [r14+0x28],0x1
  407dc1:	mov    rsi,rax
  407dc4:	jmp    407de5 <__swc_fn_585f006d_000054_faa92dcc+0xa5>
  407dc6:	mov    rax,QWORD PTR [r14+0x18]
  407dca:	cmp    QWORD PTR [r14+0x20],rax
  407dce:	jae    407de3 <__swc_fn_585f006d_000054_faa92dcc+0xa3>
  407dd0:	mov    rsi,QWORD PTR [r14+0x20]
  407dd4:	mov    eax,DWORD PTR [r14+0x2c]
  407dd8:	add    QWORD PTR [r14+0x20],rax
  407ddc:	add    DWORD PTR [r14+0x28],0x1
  407de1:	jmp    407de5 <__swc_fn_585f006d_000054_faa92dcc+0xa5>
  407de3:	xor    esi,esi
  407de5:	test   rsi,rsi
  407de8:	jne    407e2d <__swc_fn_585f006d_000054_faa92dcc+0xed>
  407dea:	mov    rcx,r14
  407ded:	call   40b9b0 <__swc_fn_585f006d_000010_24a20786>
  407df2:	test   al,al
  407df4:	je     407e2d <__swc_fn_585f006d_000054_faa92dcc+0xed>
  407df6:	mov    rax,QWORD PTR [r14]
  407df9:	test   rax,rax
  407dfc:	je     407e0b <__swc_fn_585f006d_000054_faa92dcc+0xcb>
  407dfe:	mov    rcx,QWORD PTR [rax]
  407e01:	mov    QWORD PTR [r14],rcx
  407e04:	add    DWORD PTR [r14+0x28],0x1
  407e09:	jmp    407e2a <__swc_fn_585f006d_000054_faa92dcc+0xea>
  407e0b:	mov    rax,QWORD PTR [r14+0x18]
  407e0f:	cmp    QWORD PTR [r14+0x20],rax
  407e13:	jae    407e28 <__swc_fn_585f006d_000054_faa92dcc+0xe8>
  407e15:	mov    rax,QWORD PTR [r14+0x20]
  407e19:	mov    ecx,DWORD PTR [r14+0x2c]
  407e1d:	add    QWORD PTR [r14+0x20],rcx
  407e21:	add    DWORD PTR [r14+0x28],0x1
  407e26:	jmp    407e2a <__swc_fn_585f006d_000054_faa92dcc+0xea>
  407e28:	xor    eax,eax
  407e2a:	mov    rsi,rax
  407e2d:	test   rsi,rsi
  407e30:	jne    407e83 <__swc_fn_585f006d_000054_faa92dcc+0x143>
  407e32:	mov    rcx,rdi
  407e35:	mov    rdx,r12
  407e38:	mov    r8,r14
  407e3b:	call   40f260 <__swc_fn_585f006d_000050_129b9bf4>
  407e40:	test   al,al
  407e42:	jne    407e83 <__swc_fn_585f006d_000054_faa92dcc+0x143>
  407e44:	mov    rcx,r14
  407e47:	call   40ba80 <__swc_fn_585f006d_000013_e4b0ddfc>
  407e4c:	mov    rax,QWORD PTR [r14]
  407e4f:	test   rax,rax
  407e52:	je     407e61 <__swc_fn_585f006d_000054_faa92dcc+0x121>
  407e54:	mov    rcx,QWORD PTR [rax]
  407e57:	mov    QWORD PTR [r14],rcx
  407e5a:	add    DWORD PTR [r14+0x28],0x1
  407e5f:	jmp    407e80 <__swc_fn_585f006d_000054_faa92dcc+0x140>
  407e61:	mov    rax,QWORD PTR [r14+0x18]
  407e65:	cmp    QWORD PTR [r14+0x20],rax
  407e69:	jae    407e7e <__swc_fn_585f006d_000054_faa92dcc+0x13e>
  407e6b:	mov    rax,QWORD PTR [r14+0x20]
  407e6f:	mov    ecx,DWORD PTR [r14+0x2c]
  407e73:	add    QWORD PTR [r14+0x20],rcx
  407e77:	add    DWORD PTR [r14+0x28],0x1
  407e7c:	jmp    407e80 <__swc_fn_585f006d_000054_faa92dcc+0x140>
  407e7e:	xor    eax,eax
  407e80:	mov    rsi,rax
  407e83:	test   rsi,rsi
  407e86:	je     407ea1 <__swc_fn_585f006d_000054_faa92dcc+0x161>
  407e88:	mov    QWORD PTR [r13+0x0],r14
  407e8c:	mov    rax,rsi
  407e8f:	add    rsp,0x1f8
  407e96:	pop    r15
  407e98:	pop    r14
  407e9a:	pop    r13
  407e9c:	pop    r12
  407e9e:	pop    rdi
  407e9f:	pop    rsi
  407ea0:	ret
  407ea1:	mov    r14,r15
  407ea4:	jmp    407d90 <__swc_fn_585f006d_000054_faa92dcc+0x50>
  407ea9:	cs nop WORD PTR [rax+rax*1+0x0]
  407eb3:	cs nop WORD PTR [rax+rax*1+0x0]
  407ebd:	nop    DWORD PTR [rax]
  407ec0:	mov    rcx,rdi
  407ec3:	mov    rdx,r12
  407ec6:	mov    r8d,esi
  407ec9:	call   40c060 <__swc_fn_585f006d_000049_ad48ec88>
  407ece:	mov    r14,rax
  407ed1:	test   rax,rax
  407ed4:	jne    407eea <__swc_fn_585f006d_000054_faa92dcc+0x1aa>
  407ed6:	xor    eax,eax
  407ed8:	add    rsp,0x1f8
  407edf:	pop    r15
  407ee1:	pop    r14
  407ee3:	pop    r13
  407ee5:	pop    r12
  407ee7:	pop    rdi
  407ee8:	pop    rsi
  407ee9:	ret
  407eea:	mov    QWORD PTR [r13+0x0],r14
  407eee:	mov    rax,QWORD PTR [r14]
  407ef1:	test   rax,rax
  407ef4:	je     407f06 <__swc_fn_585f006d_000054_faa92dcc+0x1c6>
  407ef6:	mov    rcx,QWORD PTR [rax]
  407ef9:	mov    QWORD PTR [r14],rcx
  407efc:	add    DWORD PTR [r14+0x28],0x1
  407f01:	mov    r15,rax
  407f04:	jmp    407f26 <__swc_fn_585f006d_000054_faa92dcc+0x1e6>
  407f06:	mov    rax,QWORD PTR [r14+0x18]
  407f0a:	cmp    QWORD PTR [r14+0x20],rax
  407f0e:	jae    407f23 <__swc_fn_585f006d_000054_faa92dcc+0x1e3>
  407f10:	mov    r15,QWORD PTR [r14+0x20]
  407f14:	mov    eax,DWORD PTR [r14+0x2c]
  407f18:	add    QWORD PTR [r14+0x20],rax
  407f1c:	add    DWORD PTR [r14+0x28],0x1
  407f21:	jmp    407f26 <__swc_fn_585f006d_000054_faa92dcc+0x1e6>
  407f23:	xor    r15d,r15d
  407f26:	test   r15,r15
  407f29:	jne    407f6e <__swc_fn_585f006d_000054_faa92dcc+0x22e>
  407f2b:	mov    rcx,r14
  407f2e:	call   40b9b0 <__swc_fn_585f006d_000010_24a20786>
  407f33:	test   al,al
  407f35:	je     407f6e <__swc_fn_585f006d_000054_faa92dcc+0x22e>
  407f37:	mov    rax,QWORD PTR [r14]
  407f3a:	test   rax,rax
  407f3d:	je     407f4c <__swc_fn_585f006d_000054_faa92dcc+0x20c>
  407f3f:	mov    rcx,QWORD PTR [rax]
  407f42:	mov    QWORD PTR [r14],rcx
  407f45:	add    DWORD PTR [r14+0x28],0x1
  407f4a:	jmp    407f6b <__swc_fn_585f006d_000054_faa92dcc+0x22b>
  407f4c:	mov    rax,QWORD PTR [r14+0x18]
  407f50:	cmp    QWORD PTR [r14+0x20],rax
  407f54:	jae    407f69 <__swc_fn_585f006d_000054_faa92dcc+0x229>
  407f56:	mov    rax,QWORD PTR [r14+0x20]
  407f5a:	mov    ecx,DWORD PTR [r14+0x2c]
  407f5e:	add    QWORD PTR [r14+0x20],rcx
  407f62:	add    DWORD PTR [r14+0x28],0x1
  407f67:	jmp    407f6b <__swc_fn_585f006d_000054_faa92dcc+0x22b>
  407f69:	xor    eax,eax
  407f6b:	mov    r15,rax
  407f6e:	test   r15,r15
  407f71:	je     407ec0 <__swc_fn_585f006d_000054_faa92dcc+0x180>
  407f77:	mov    rax,r15
  407f7a:	add    rsp,0x1f8
  407f81:	pop    r15
  407f83:	pop    r14
  407f85:	pop    r13
  407f87:	pop    r12
  407f89:	pop    rdi
  407f8a:	pop    rsi
  407f8b:	ret
  407f8c:	add    BYTE PTR [rax],al
	...

0000000000407f90 <__swc_fn_585f006d_000057_7e1dbcb0>:
  407f90:	push   rsi
  407f91:	push   rdi
  407f92:	push   r12
  407f94:	mov    rsi,rdx
  407f97:	mov    rax,rdx
  407f9a:	shr    rax,0xc
  407f9e:	movabs rdx,0x9e3779b97f4a7c15
  407fa8:	imul   rax,rdx
  407fac:	shr    rax,0x20
  407fb0:	lea    rax,[rax*8+0x0]
  407fb8:	shr    rax,0x20
  407fbc:	lea    rax,[rax*8+0x0]
  407fc4:	lea    rax,[rcx+rax*8+0x40]
  407fc9:	xor    edx,edx
  407fcb:	test   dl,dl
  407fcd:	lea    rdi,[rcx+0x8]
  407fd1:	cmove  rdi,rax
  407fd5:	xor    edx,edx
  407fd7:	test   dl,dl
  407fd9:	lea    r12,[rcx+0x30]
  407fdd:	lea    rax,[rax+0x8]
  407fe1:	cmove  r12,rax
  407fe5:	mov    rcx,rdi
  407fe8:	call   40df20 <__swc_fn_585f006d_000139_86bb0f90>
  407fed:	mov    QWORD PTR [rsi+0x30],0x0
  407ff5:	mov    rax,QWORD PTR [r12]
  407ff9:	mov    QWORD PTR [rsi+0x38],rax
  407ffd:	test   rax,rax
  408000:	je     40800a <__swc_fn_585f006d_000057_7e1dbcb0+0x7a>
  408002:	mov    rax,QWORD PTR [rsi+0x38]
  408006:	mov    QWORD PTR [rax+0x30],rsi
  40800a:	mov    QWORD PTR [r12],rsi
  40800e:	mov    rcx,rdi
  408011:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  408016:	pop    r12
  408018:	pop    rdi
  408019:	pop    rsi
  40801a:	ret
  40801b:	add    BYTE PTR [rax],al
  40801d:	add    BYTE PTR [rax],al
	...

0000000000408020 <__swc_fn_585f006d_000060_15c28ca7>:
  408020:	lea    rax,[rdx+rdx*4]
  408024:	lea    rax,[rcx+rax*8+0x268]
  40802c:	mov    rdx,QWORD PTR [rax+0x10]
  408030:	sub    QWORD PTR [rcx+0x2a68],rdx
  408037:	sub    QWORD PTR [rcx+0x2a70],0x1
  40803f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  408046:	lea    rdx,[rdx+rdx*4]
  40804a:	lea    rdx,[rcx+rdx*8+0x268]
  408052:	vmovups xmm0,XMMWORD PTR [rdx]
  408056:	vmovups XMMWORD PTR [rax],xmm0
  40805a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40805f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  408064:	mov    rcx,QWORD PTR [rdx+0x20]
  408068:	mov    QWORD PTR [rax+0x20],rcx
  40806c:	ret
  40806d:	add    BYTE PTR [rax],al
	...

0000000000408070 <__swc_fn_585f006d_000063_dea90857>:
  408070:	push   rsi
  408071:	push   rdi
  408072:	push   r12
  408074:	push   r13
  408076:	sub    rsp,0x8
  40807a:	mov    rsi,r8
  40807d:	mov    rdi,rcx
  408080:	mov    r12,rdx
  408083:	xor    r13d,r13d
  408086:	cs nop WORD PTR [rax+rax*1+0x0]
  408090:	mov    eax,DWORD PTR [r12+0x730]
  408098:	cmp    r13d,eax
  40809b:	jae    408101 <__swc_fn_585f006d_000063_dea90857+0x91>
  40809d:	lea    rax,[r13+r13*4+0x0]
  4080a2:	lea    rax,[r12+rax*8+0x738]
  4080aa:	mov    rdx,QWORD PTR [rax]
  4080ad:	mov    r8,QWORD PTR [rax+0x8]
  4080b1:	mov    r9,QWORD PTR [rax+0x10]
  4080b5:	cmp    QWORD PTR [rax+0x20],rsi
  4080b9:	jb     4080c0 <__swc_fn_585f006d_000063_dea90857+0x50>
  4080bb:	inc    r13d
  4080be:	jmp    408090 <__swc_fn_585f006d_000063_dea90857+0x20>
  4080c0:	sub    DWORD PTR [r12+0x730],0x1
  4080c9:	mov    ecx,DWORD PTR [r12+0x730]
  4080d1:	lea    rcx,[rcx+rcx*4]
  4080d5:	lea    rcx,[r12+rcx*8+0x738]
  4080dd:	vmovups xmm0,XMMWORD PTR [rcx]
  4080e1:	vmovups XMMWORD PTR [rax],xmm0
  4080e5:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  4080ea:	vmovups XMMWORD PTR [rax+0x10],xmm0
  4080ef:	mov    rcx,QWORD PTR [rcx+0x20]
  4080f3:	mov    QWORD PTR [rax+0x20],rcx
  4080f7:	mov    rcx,rdi
  4080fa:	call   40bde0 <__swc_fn_585f006d_000043_d3c2ab54>
  4080ff:	jmp    408090 <__swc_fn_585f006d_000063_dea90857+0x20>
  408101:	add    rsp,0x8
  408105:	pop    r13
  408107:	pop    r12
  408109:	pop    rdi
  40810a:	pop    rsi
  40810b:	ret
  40810c:	add    BYTE PTR [rax],al
	...

0000000000408110 <__swc_fn_585f006d_000066_de167e8d>:
  408110:	push   rsi
  408111:	push   rdi
  408112:	push   r12
  408114:	push   r13
  408116:	push   r14
  408118:	mov    rsi,rcx
  40811b:	mov    rdi,rdx
  40811e:	mov    r12,QWORD PTR [rdi]
  408121:	mov    r13,QWORD PTR [rdi+0x18]
  408125:	mov    rax,r12
  408128:	add    rax,QWORD PTR [rdi+0x8]
  40812c:	sub    rax,r13
  40812f:	cmp    r8,rax
  408132:	jbe    40813d <__swc_fn_585f006d_000066_de167e8d+0x2d>
  408134:	pop    r14
  408136:	pop    r13
  408138:	pop    r12
  40813a:	pop    rdi
  40813b:	pop    rsi
  40813c:	ret
  40813d:	lea    rax,[r13+r8*1+0x0]
  408142:	sub    rax,r12
  408145:	mov    ecx,0x1000
  40814a:	test   ecx,ecx
  40814c:	mov    edx,0x8
  408151:	cmove  ecx,edx
  408154:	dec    rcx
  408157:	mov    rdx,0xffffffffffffffff
  40815e:	sub    rdx,rcx
  408161:	cmp    rax,rdx
  408164:	jbe    40816b <__swc_fn_585f006d_000066_de167e8d+0x5b>
  408166:	xor    r14d,r14d
  408169:	jmp    408176 <__swc_fn_585f006d_000066_de167e8d+0x66>
  40816b:	add    rax,rcx
  40816e:	andn   rax,rcx,rax
  408173:	mov    r14,rax
  408176:	mov    rax,QWORD PTR [rdi+0x10]
  40817a:	cmp    r14,rax
  40817d:	ja     408188 <__swc_fn_585f006d_000066_de167e8d+0x78>
  40817f:	pop    r14
  408181:	pop    r13
  408183:	pop    r12
  408185:	pop    rdi
  408186:	pop    rsi
  408187:	ret
  408188:	mov    rax,r12
  40818b:	add    rax,QWORD PTR [rdi+0x10]
  40818f:	mov    rdx,r14
  408192:	sub    rdx,QWORD PTR [rdi+0x10]
  408196:	mov    rcx,rax
  408199:	call   40b930 <__swc_fn_585f006d_000007_f7acedb0>
  40819e:	test   al,al
  4081a0:	jne    4081ab <__swc_fn_585f006d_000066_de167e8d+0x9b>
  4081a2:	pop    r14
  4081a4:	pop    r13
  4081a6:	pop    r12
  4081a8:	pop    rdi
  4081a9:	pop    rsi
  4081aa:	ret
  4081ab:	add    r12,r14
  4081ae:	sub    r12,r13
  4081b1:	mov    rcx,r12
  4081b4:	sub    rcx,QWORD PTR [rdi+0x28]
  4081b8:	mov    rdx,QWORD PTR [rsi+0x250]
  4081bf:	nop
  4081c0:	lea    r8,[rdx+rcx*1]
  4081c4:	mov    rax,rdx
  4081c7:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  4081d0:	cmp    rax,rdx
  4081d3:	je     4081da <__swc_fn_585f006d_000066_de167e8d+0xca>
  4081d5:	mov    rdx,rax
  4081d8:	jmp    4081c0 <__swc_fn_585f006d_000066_de167e8d+0xb0>
  4081da:	mov    QWORD PTR [rdi+0x10],r14
  4081de:	mov    QWORD PTR [rdi+0x28],r12
  4081e2:	pop    r14
  4081e4:	pop    r13
  4081e6:	pop    r12
  4081e8:	pop    rdi
  4081e9:	pop    rsi
  4081ea:	ret
  4081eb:	add    BYTE PTR [rax],al
  4081ed:	add    BYTE PTR [rax],al
	...

00000000004081f0 <__swc_fn_585f006d_000069_7130736e>:
  4081f0:	push   rbx
  4081f1:	push   rsi
  4081f2:	push   rdi
  4081f3:	push   r12
  4081f5:	push   r13
  4081f7:	sub    rsp,0xe0
  4081fe:	mov    rbx,rdx
  408201:	mov    rsi,rcx
  408204:	cmp    DWORD PTR [rbx+0x58],0x0
  408208:	je     40822c <__swc_fn_585f006d_000069_7130736e+0x3c>
  40820a:	mov    eax,DWORD PTR [rbx+0x58]
  40820d:	sub    eax,0x1
  408210:	test   DWORD PTR [rbx+0x58],eax
  408213:	je     40822c <__swc_fn_585f006d_000069_7130736e+0x3c>
  408215:	mov    QWORD PTR [rbx+0x40],0x0
  40821d:	add    rsp,0xe0
  408224:	pop    r13
  408226:	pop    r12
  408228:	pop    rdi
  408229:	pop    rsi
  40822a:	pop    rbx
  40822b:	ret
  40822c:	mov    rax,QWORD PTR [rbx+0x40]
  408230:	test   rax,rax
  408233:	jne    40824f <__swc_fn_585f006d_000069_7130736e+0x5f>
  408235:	mov    rcx,rsi
  408238:	mov    rdx,rbx
  40823b:	call   40ff10 <__swc_fn_585f006d_000068_f3aa21af>
  408240:	add    rsp,0xe0
  408247:	pop    r13
  408249:	pop    r12
  40824b:	pop    rdi
  40824c:	pop    rsi
  40824d:	pop    rbx
  40824e:	ret
  40824f:	cmp    QWORD PTR [rbx+0x48],0x0
  408254:	jne    408270 <__swc_fn_585f006d_000069_7130736e+0x80>
  408256:	mov    rcx,rsi
  408259:	mov    rdx,rbx
  40825c:	call   40c610 <__swc_fn_585f006d_000070_97813b89>
  408261:	add    rsp,0xe0
  408268:	pop    r13
  40826a:	pop    r12
  40826c:	pop    rdi
  40826d:	pop    rsi
  40826e:	pop    rbx
  40826f:	ret
  408270:	mov    rdi,QWORD PTR [rbx+0x40]
  408274:	lea    rax,[rip+0x1adfd]        # 423078 <__swc_bss_base_585f006d+0x38>
  40827b:	mov    rcx,rdi
  40827e:	sub    rcx,QWORD PTR [rax+0x8]
  408282:	mov    rax,QWORD PTR [rip+0x1adff]        # 423088 <__swc_bss_base_585f006d+0x48>
  408289:	cmp    rcx,rax
  40828c:	jae    4082b8 <__swc_fn_585f006d_000069_7130736e+0xc8>
  40828e:	mov    rax,rdi
  408291:	and    rax,0xffffffffffc00000
  408298:	mov    rcx,rdi
  40829b:	shr    rcx,0x10
  40829f:	and    ecx,0x3f
  4082a2:	mov    edx,DWORD PTR [rax+0x28]
  4082a5:	shrx   ecx,ecx,edx
  4082aa:	shl    rcx,0x4
  4082ae:	lea    r12,[rax+rcx*8+0x80]
  4082b6:	jmp    4082c3 <__swc_fn_585f006d_000069_7130736e+0xd3>
  4082b8:	mov    rcx,rdi
  4082bb:	call   40ef90 <__swc_fn_585f006d_000026_bcdc5519>
  4082c0:	mov    r12,rax
  4082c3:	test   r12,r12
  4082c6:	je     4082d5 <__swc_fn_585f006d_000069_7130736e+0xe5>
  4082c8:	mov    eax,DWORD PTR [r12+0x2c]
  4082cd:	mov    r9d,eax
  4082d0:	mov    r13,rax
  4082d3:	jmp    408354 <__swc_fn_585f006d_000069_7130736e+0x164>
  4082d5:	mov    rcx,rsi
  4082d8:	mov    rdx,rdi
  4082db:	call   40f5a0 <__swc_fn_585f006d_000056_df0696cd>
  4082e0:	mov    rcx,QWORD PTR [rax+0x28]
  4082e4:	mov    r9,rcx
  4082e7:	mov    rdx,QWORD PTR [rax+0x20]
  4082eb:	mov    r13,rdx
  4082ee:	cmp    QWORD PTR [rbx+0x48],rcx
  4082f2:	jbe    40832b <__swc_fn_585f006d_000069_7130736e+0x13b>
  4082f4:	mov    ecx,DWORD PTR [rax+0x48]
  4082f7:	cmp    DWORD PTR [rbx+0x58],ecx
  4082fa:	ja     40832b <__swc_fn_585f006d_000069_7130736e+0x13b>
  4082fc:	mov    rcx,rsi
  4082ff:	mov    rdx,rax
  408302:	mov    r8,QWORD PTR [rbx+0x48]
  408306:	mov    QWORD PTR [rsp+0xc8],r9
  40830e:	mov    QWORD PTR [rsp+0xd0],rax
  408316:	call   408110 <__swc_fn_585f006d_000066_de167e8d>
  40831b:	mov    r9,QWORD PTR [rsp+0xc8]
  408323:	mov    rax,QWORD PTR [rsp+0xd0]
  40832b:	mov    rcx,QWORD PTR [rax+0x28]
  40832f:	cmp    QWORD PTR [rbx+0x48],rcx
  408333:	ja     408354 <__swc_fn_585f006d_000069_7130736e+0x164>
  408335:	mov    ecx,DWORD PTR [rax+0x48]
  408338:	cmp    DWORD PTR [rbx+0x58],ecx
  40833b:	ja     408354 <__swc_fn_585f006d_000069_7130736e+0x164>
  40833d:	mov    rcx,QWORD PTR [rbx+0x48]
  408341:	mov    QWORD PTR [rax+0x20],rcx
  408345:	add    rsp,0xe0
  40834c:	pop    r13
  40834e:	pop    r12
  408350:	pop    rdi
  408351:	pop    rsi
  408352:	pop    rbx
  408353:	ret
  408354:	test   r12,r12
  408357:	je     408389 <__swc_fn_585f006d_000069_7130736e+0x199>
  408359:	cmp    QWORD PTR [rbx+0x48],r9
  40835d:	ja     408389 <__swc_fn_585f006d_000069_7130736e+0x199>
  40835f:	cmp    DWORD PTR [rbx+0x58],0x40
  408363:	ja     408389 <__swc_fn_585f006d_000069_7130736e+0x199>
  408365:	cmp    DWORD PTR [rbx+0x58],0x0
  408369:	je     408376 <__swc_fn_585f006d_000069_7130736e+0x186>
  40836b:	mov    ecx,DWORD PTR [rbx+0x58]
  40836e:	dec    rcx
  408371:	test   rdi,rcx
  408374:	jne    408389 <__swc_fn_585f006d_000069_7130736e+0x199>
  408376:	mov    QWORD PTR [rbx+0x40],rdi
  40837a:	add    rsp,0xe0
  408381:	pop    r13
  408383:	pop    r12
  408385:	pop    rdi
  408386:	pop    rsi
  408387:	pop    rbx
  408388:	ret
  408389:	vmovups xmm0,XMMWORD PTR [rbx]
  40838d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  408393:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  408398:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40839e:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  4083a3:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  4083a9:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  4083ae:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  4083b4:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  4083b9:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  4083bf:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  4083c4:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  4083ca:	mov    QWORD PTR [rsp+0x48],0x0
  4083d3:	mov    rcx,rsi
  4083d6:	lea    rdx,[rsp+0x8]
  4083db:	call   40ff10 <__swc_fn_585f006d_000068_f3aa21af>
  4083e0:	mov    rax,QWORD PTR [rsp+0x48]
  4083e5:	test   rax,rax
  4083e8:	jne    408401 <__swc_fn_585f006d_000069_7130736e+0x211>
  4083ea:	mov    QWORD PTR [rbx+0x40],0x0
  4083f2:	add    rsp,0xe0
  4083f9:	pop    r13
  4083fb:	pop    r12
  4083fd:	pop    rdi
  4083fe:	pop    rsi
  4083ff:	pop    rbx
  408400:	ret
  408401:	mov    rax,QWORD PTR [rbx+0x48]
  408405:	cmp    r13,rax
  408408:	cmovbe rax,r13
  40840c:	mov    rcx,QWORD PTR [rsp+0x48]
  408411:	mov    rdx,rdi
  408414:	mov    r8,rax
  408417:	call   40d760 <__swc_fn_585f006d_000109_7c204aac>
  40841c:	vmovups xmm0,XMMWORD PTR [rbx]
  408420:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  408426:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40842b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  408431:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  408436:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40843f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  408444:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40844d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  408452:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40845b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  408460:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  408469:	mov    QWORD PTR [rsp+0xa8],rdi
  408471:	mov    rcx,rsi
  408474:	lea    rdx,[rsp+0x68]
  408479:	call   40c610 <__swc_fn_585f006d_000070_97813b89>
  40847e:	mov    rax,QWORD PTR [rsp+0x48]
  408483:	mov    QWORD PTR [rbx+0x40],rax
  408487:	add    rsp,0xe0
  40848e:	pop    r13
  408490:	pop    r12
  408492:	pop    rdi
  408493:	pop    rsi
  408494:	pop    rbx
  408495:	ret
	...

00000000004084a0 <__swc_fn_585f006d_000072_61e60aab>:
  4084a0:	push   r12
  4084a2:	push   rdi
  4084a3:	push   rsi
  4084a4:	push   r13
  4084a6:	push   r14
  4084a8:	sub    rsp,0x190
  4084af:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  4084b8:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  4084c1:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  4084ca:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  4084d3:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  4084dc:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  4084e5:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  4084ee:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  4084f7:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  408500:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  408509:	mov    r12,rcx
  40850c:	lea    rax,[rip+0x18aed]        # 421000 <__swc_data_base_585f006d>
  408513:	mov    rax,QWORD PTR [rax]
  408516:	cmp    rax,0xffffffffffffffff
  40851a:	je     408529 <__swc_fn_585f006d_000072_61e60aab+0x89>
  40851c:	mov    eax,eax
  40851e:	mov    edi,eax
  408520:	xor    eax,eax
  408522:	call   407000 <pthread_getspecific@plt>
  408527:	jmp    40852b <__swc_fn_585f006d_000072_61e60aab+0x8b>
  408529:	xor    eax,eax
  40852b:	test   rax,rax
  40852e:	jne    40853d <__swc_fn_585f006d_000072_61e60aab+0x9d>
  408530:	call   40f060 <__swc_fn_585f006d_000035_cd1a4e8c>
  408535:	mov    rcx,rax
  408538:	call   409c60 <__swc_fn_585f006d_000132_5f757033>
  40853d:	test   rax,rax
  408540:	je     408566 <__swc_fn_585f006d_000072_61e60aab+0xc6>
  408542:	cmp    QWORD PTR [rax],r12
  408545:	jne    408566 <__swc_fn_585f006d_000072_61e60aab+0xc6>
  408547:	xor    ecx,ecx
  408549:	mov    QWORD PTR [rsp+0xc8],rax
  408551:	call   40bdb0 <__swc_fn_585f006d_000037_28d0e998>
  408556:	mov    rdx,QWORD PTR [rsp+0xc8]
  40855e:	mov    rcx,r12
  408561:	call   40bec0 <__swc_fn_585f006d_000046_b30433d0>
  408566:	lea    rsi,[r12+0x10]
  40856b:	mov    rcx,rsi
  40856e:	call   40df20 <__swc_fn_585f006d_000139_86bb0f90>
  408573:	mov    rdi,QWORD PTR [r12+0x20]
  408578:	test   rdi,rdi
  40857b:	je     4085be <__swc_fn_585f006d_000072_61e60aab+0x11e>
  40857d:	nop    DWORD PTR [rax]
  408580:	mov    rcx,r12
  408583:	mov    rdx,rdi
  408586:	call   40f220 <__swc_fn_585f006d_000047_6e7a8d58>
  40858b:	mov    rcx,r12
  40858e:	mov    rdx,rdi
  408591:	mov    r8,0xffffffffffffffff
  408598:	call   408070 <__swc_fn_585f006d_000063_dea90857>
  40859d:	mov    rcx,r12
  4085a0:	mov    rdx,rdi
  4085a3:	mov    r8d,0x9b8
  4085a9:	mov    r9d,0x9b8
  4085af:	call   40bde0 <__swc_fn_585f006d_000043_d3c2ab54>
  4085b4:	mov    rdi,QWORD PTR [r12+0x20]
  4085b9:	test   rdi,rdi
  4085bc:	jne    408580 <__swc_fn_585f006d_000072_61e60aab+0xe0>
  4085be:	xor    eax,eax
  4085c0:	xchg   QWORD PTR [r12+0x2a80],rax
  4085c8:	test   rax,rax
  4085cb:	je     4085f1 <__swc_fn_585f006d_000072_61e60aab+0x151>
  4085cd:	cs nop WORD PTR [rax+rax*1+0x0]
  4085d7:	nop    WORD PTR [rax+rax*1+0x0]
  4085e0:	mov    rcx,rax
  4085e3:	mov    rax,QWORD PTR [rax+0x78]
  4085e7:	xor    edx,edx
  4085e9:	xchg   DWORD PTR [rcx+0x70],edx
  4085ec:	test   rax,rax
  4085ef:	jne    4085e0 <__swc_fn_585f006d_000072_61e60aab+0x140>
  4085f1:	mov    rax,QWORD PTR [r12+0x18]
  4085f6:	mov    rdi,rax
  4085f9:	test   rdi,rdi
  4085fc:	je     408691 <__swc_fn_585f006d_000072_61e60aab+0x1f1>
  408602:	cs nop WORD PTR [rax+rax*1+0x0]
  40860c:	nop    DWORD PTR [rax+0x0]
  408610:	mov    rax,QWORD PTR [rdi+0x10]
  408614:	mov    r8d,DWORD PTR [rdi+0x2c]
  408618:	xor    r9d,r9d
  40861b:	test   r8,r8
  40861e:	jbe    40867d <__swc_fn_585f006d_000072_61e60aab+0x1dd>
  408620:	mov    ecx,r9d
  408623:	shl    rcx,0x4
  408627:	lea    rdx,[rdi+rcx*8+0x80]
  40862f:	cmp    BYTE PTR [rdx+0x3b],0x0
  408633:	je     408674 <__swc_fn_585f006d_000072_61e60aab+0x1d4>
  408635:	mov    DWORD PTR [rdx+0x28],0x0
  40863c:	mov    rcx,rdi
  40863f:	mov    QWORD PTR [rsp+0xd0],rax
  408647:	mov    QWORD PTR [rsp+0xd8],r8
  40864f:	mov    QWORD PTR [rsp+0xe0],r9
  408657:	call   407790 <__swc_fn_585f006d_000018_283e2b5e>
  40865c:	mov    rax,QWORD PTR [rsp+0xd0]
  408664:	mov    r8,QWORD PTR [rsp+0xd8]
  40866c:	mov    r9,QWORD PTR [rsp+0xe0]
  408674:	add    r9,0x1
  408678:	cmp    r9,r8
  40867b:	jb     408620 <__swc_fn_585f006d_000072_61e60aab+0x180>
  40867d:	mov    rcx,rdi
  408680:	mov    rdi,rax
  408683:	call   40bcc0 <__swc_fn_585f006d_000025_aa910677>
  408688:	test   rdi,rdi
  40868b:	jne    408610 <__swc_fn_585f006d_000072_61e60aab+0x170>
  408691:	mov    QWORD PTR [r12+0x18],0x0
  40869a:	mov    QWORD PTR [r12+0x28],0x0
  4086a3:	mov    rcx,rsi
  4086a6:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  4086ab:	mov    esi,0x8
  4086b0:	xor    edi,edi
  4086b2:	test   rsi,rsi
  4086b5:	je     408712 <__swc_fn_585f006d_000072_61e60aab+0x272>
  4086bb:	nop    DWORD PTR [rax+rax*1+0x0]
  4086c0:	lea    r13,[rdi*8+0x0]
  4086c8:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  4086cd:	test   r14,r14
  4086d0:	je     408708 <__swc_fn_585f006d_000072_61e60aab+0x268>
  4086d2:	cs nop WORD PTR [rax+rax*1+0x0]
  4086dc:	nop    DWORD PTR [rax+0x0]
  4086e0:	mov    rcx,r12
  4086e3:	mov    rdx,r14
  4086e6:	call   40c470 <__swc_fn_585f006d_000058_1bb23e77>
  4086eb:	mov    rcx,r12
  4086ee:	mov    rdx,QWORD PTR [r14]
  4086f1:	mov    r8,QWORD PTR [r14+0x8]
  4086f5:	mov    r9,QWORD PTR [r14+0x10]
  4086f9:	call   40bde0 <__swc_fn_585f006d_000043_d3c2ab54>
  4086fe:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  408703:	test   r14,r14
  408706:	jne    4086e0 <__swc_fn_585f006d_000072_61e60aab+0x240>
  408708:	add    rdi,0x1
  40870c:	sub    rsi,0x1
  408710:	jne    4086c0 <__swc_fn_585f006d_000072_61e60aab+0x220>
  408712:	mov    rcx,r12
  408715:	call   40c540 <__swc_fn_585f006d_000064_ffcd96eb>
  40871a:	lea    rcx,[r12+0x250]
  408722:	mov    rdx,QWORD PTR [rcx]
  408725:	mov    r8,QWORD PTR [r12+0x250]
  40872d:	nop    DWORD PTR [rax]
  408730:	mov    r9,r8
  408733:	sub    r9,rdx
  408736:	mov    rax,r8
  408739:	lock cmpxchg QWORD PTR [rcx],r9
  40873e:	cmp    rax,r8
  408741:	je     408748 <__swc_fn_585f006d_000072_61e60aab+0x2a8>
  408743:	mov    r8,rax
  408746:	jmp    408730 <__swc_fn_585f006d_000072_61e60aab+0x290>
  408748:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  408751:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40875a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  408763:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40876c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  408775:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40877e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  408787:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  408790:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  408799:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  4087a2:	add    rsp,0x190
  4087a9:	pop    r14
  4087ab:	pop    r13
  4087ad:	pop    rsi
  4087ae:	pop    rdi
  4087af:	pop    r12
  4087b1:	ret
	...

00000000004087c0 <__swc_fn_585f006d_000075_64d36d78>:
  4087c0:	sub    rsp,0x8
  4087c4:	mov    QWORD PTR [rdx+0x40],0x0
  4087cc:	call   40ff10 <__swc_fn_585f006d_000068_f3aa21af>
  4087d1:	add    rsp,0x8
  4087d5:	ret
	...

00000000004087e0 <__swc_fn_585f006d_000078_1966ae2e>:
  4087e0:	sub    rsp,0x8
  4087e4:	call   40c610 <__swc_fn_585f006d_000070_97813b89>
  4087e9:	add    rsp,0x8
  4087ed:	ret
	...

00000000004087f0 <__swc_fn_585f006d_000081_5cc7acfc>:
  4087f0:	push   rbx
  4087f1:	push   rsi
  4087f2:	push   rdi
  4087f3:	push   r12
  4087f5:	push   r13
  4087f7:	push   r14
  4087f9:	push   r15
  4087fb:	sub    rsp,0x20
  4087ff:	mov    rbx,r11
  408802:	mov    rsi,rcx
  408805:	mov    rdi,rdx
  408808:	mov    r12,r8
  40880b:	mov    r13,r9
  40880e:	mov    r14,r10
  408811:	mov    rcx,QWORD PTR [rip+0x1a828]        # 423040 <__swc_bss_base_585f006d>
  408818:	test   rcx,rcx
  40881b:	jne    40882d <__swc_fn_585f006d_000081_5cc7acfc+0x3d>
  40881d:	call   40e820 <__swc_fn_585f006d_000169_994c8876>
  408822:	lea    rcx,[rax+0x1]
  408826:	mov    QWORD PTR [rip+0x1a813],rcx        # 423040 <__swc_bss_base_585f006d>
  40882d:	dec    rcx
  408830:	call   40b6e0 <__swc_fn_585f006d_000171_360af05d>
  408835:	mov    r15,rax
  408838:	lea    r11,[rip+0x1aa01]        # 423240 <__swc_bss_base_585f006d+0x200>
  40883f:	mov    rcx,r11
  408842:	call   40bdd0 <__swc_fn_585f006d_000040_eb6108f2>
  408847:	test   al,al
  408849:	jne    40885a <__swc_fn_585f006d_000081_5cc7acfc+0x6a>
  40884b:	mov    rcx,r11
  40884e:	call   40f0c0 <__swc_fn_585f006d_000038_14f56618>
  408853:	lea    r11,[rip+0x1a9e6]        # 423240 <__swc_bss_base_585f006d+0x200>
  40885a:	mov    rcx,r11
  40885d:	mov    rdx,rsi
  408860:	mov    r8,rdi
  408863:	mov    r9,r12
  408866:	mov    r10,r13
  408869:	mov    rsi,r11
  40886c:	mov    r11,r14
  40886f:	call   407b10 <__swc_fn_585f006d_000039_03f1bf9a>
  408874:	test   bl,bl
  408876:	je     40889d <__swc_fn_585f006d_000081_5cc7acfc+0xad>
  408878:	mov    QWORD PTR [rsp+0x8],rsi
  40887d:	lea    rax,[rip+0x99f4]        # 412278 <__swc_rdata_base_585f006d+0x168>
  408884:	mov    QWORD PTR [rsp+0x10],rax
  408889:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40888f:	vmovups XMMWORD PTR [r15],xmm0
  408894:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40889d:	mov    rax,rsi
  4088a0:	add    rsp,0x20
  4088a4:	pop    r15
  4088a6:	pop    r14
  4088a8:	pop    r13
  4088aa:	pop    r12
  4088ac:	pop    rdi
  4088ad:	pop    rsi
  4088ae:	pop    rbx
  4088af:	ret

00000000004088b0 <__swc_fn_585f006d_000084_cf82995a>:
  4088b0:	sub    rsp,0x8
  4088b4:	mov    rax,rcx
  4088b7:	test   rcx,rcx
  4088ba:	jne    4088c1 <__swc_fn_585f006d_000084_cf82995a+0x11>
  4088bc:	add    rsp,0x8
  4088c0:	ret
  4088c1:	lea    rcx,[rax-0x10]
  4088c5:	mov    rax,QWORD PTR [rax-0x10]
  4088c9:	mov    rdx,rax
  4088cc:	call   409910 <__swc_fn_585f006d_000117_ed2d8fed>
  4088d1:	add    rsp,0x8
  4088d5:	ret
	...

00000000004088e0 <__swc_fn_585f006d_000087_ef55f6e4>:
  4088e0:	sub    rsp,0x8
  4088e4:	xor    r11d,r11d
  4088e7:	call   40c8d0 <__swc_fn_585f006d_000088_0d280354>
  4088ec:	add    rsp,0x8
  4088f0:	ret
	...

0000000000408900 <__swc_fn_585f006d_000090_23214800>:
  408900:	push   rsi
  408901:	push   rdi
  408902:	push   r12
  408904:	push   r13
  408906:	push   r14
  408908:	push   r15
  40890a:	sub    rsp,0x68
  40890e:	mov    rsi,r9
  408911:	mov    rdi,rcx
  408914:	mov    r12,rdx
  408917:	mov    r13,r8
  40891a:	cmp    r8,r9
  40891d:	jne    408945 <__swc_fn_585f006d_000090_23214800+0x45>
  40891f:	mov    rcx,rdi
  408922:	mov    rdx,r12
  408925:	xor    r8d,r8d
  408928:	call   40cc20 <__swc_fn_585f006d_000094_63c1827b>
  40892d:	test   al,al
  40892f:	je     408945 <__swc_fn_585f006d_000090_23214800+0x45>
  408931:	mov    eax,0x1
  408936:	add    rsp,0x68
  40893a:	pop    r15
  40893c:	pop    r14
  40893e:	pop    r13
  408940:	pop    r12
  408942:	pop    rdi
  408943:	pop    rsi
  408944:	ret
  408945:	cmp    BYTE PTR [r12+0x2c],0xe
  40894b:	je     40895e <__swc_fn_585f006d_000090_23214800+0x5e>
  40894d:	xor    eax,eax
  40894f:	add    rsp,0x68
  408953:	pop    r15
  408955:	pop    r14
  408957:	pop    r13
  408959:	pop    r12
  40895b:	pop    rdi
  40895c:	pop    rsi
  40895d:	ret
  40895e:	mov    r14,QWORD PTR [r12+0x98]
  408966:	mov    rax,QWORD PTR [r12+0xa0]
  40896e:	mov    r12,rax
  408971:	xor    r15d,r15d
  408974:	test   r12,r12
  408977:	je     4089df <__swc_fn_585f006d_000090_23214800+0xdf>
  408979:	nop    DWORD PTR [rax+0x0]
  408980:	mov    QWORD PTR [rsp+0x58],r12
  408985:	lea    r12,[r15*8+0x0]
  40898d:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  408992:	mov    rcx,rax
  408995:	call   4106a0 <__swc_fn_585f006d_000086_3953ef98>
  40899a:	cmp    BYTE PTR [rax+0x2c],0xe
  40899e:	jne    4089d0 <__swc_fn_585f006d_000090_23214800+0xd0>
  4089a0:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  4089a5:	lea    r8,[r13+rcx*1+0x0]
  4089aa:	mov    rcx,rdi
  4089ad:	mov    rdx,rax
  4089b0:	mov    r9,rsi
  4089b3:	call   408900 <__swc_fn_585f006d_000090_23214800>
  4089b8:	test   al,al
  4089ba:	je     4089d0 <__swc_fn_585f006d_000090_23214800+0xd0>
  4089bc:	mov    eax,0x1
  4089c1:	add    rsp,0x68
  4089c5:	pop    r15
  4089c7:	pop    r14
  4089c9:	pop    r13
  4089cb:	pop    r12
  4089cd:	pop    rdi
  4089ce:	pop    rsi
  4089cf:	ret
  4089d0:	add    r15,0x1
  4089d4:	mov    r12,QWORD PTR [rsp+0x58]
  4089d9:	sub    r12,0x1
  4089dd:	jne    408980 <__swc_fn_585f006d_000090_23214800+0x80>
  4089df:	xor    eax,eax
  4089e1:	add    rsp,0x68
  4089e5:	pop    r15
  4089e7:	pop    r14
  4089e9:	pop    r13
  4089eb:	pop    r12
  4089ed:	pop    rdi
  4089ee:	pop    rsi
  4089ef:	ret

00000000004089f0 <__swc_fn_585f006d_000093_c2567a3b>:
  4089f0:	push   rbp
  4089f1:	push   rbx
  4089f2:	push   rsi
  4089f3:	push   rdi
  4089f4:	push   r12
  4089f6:	push   r13
  4089f8:	push   r14
  4089fa:	push   r15
  4089fc:	sub    rsp,0x38
  408a00:	mov    rbp,rsp
  408a03:	mov    rbx,r11
  408a06:	mov    rsi,rdx
  408a09:	mov    rdi,r8
  408a0c:	mov    r12,r9
  408a0f:	mov    QWORD PTR [rsp+0x18],r9
  408a14:	mov    r13,r10
  408a17:	movzx  r14d,BYTE PTR [rbp+0x80]
  408a1f:	movzx  r15d,BYTE PTR [rbp+0x88]
  408a27:	test   r11,r11
  408a2a:	je     408a30 <__swc_fn_585f006d_000093_c2567a3b+0x40>
  408a2c:	xor    eax,eax
  408a2e:	mov    BYTE PTR [rbx],al
  408a30:	test   r12,r12
  408a33:	je     408a3e <__swc_fn_585f006d_000093_c2567a3b+0x4e>
  408a35:	mov    QWORD PTR [r12+0x8],0x0
  408a3e:	test   rcx,rcx
  408a41:	je     408a48 <__swc_fn_585f006d_000093_c2567a3b+0x58>
  408a43:	test   rsi,rsi
  408a46:	jne    408a5b <__swc_fn_585f006d_000093_c2567a3b+0x6b>
  408a48:	xor    eax,eax
  408a4a:	add    rsp,0x38
  408a4e:	pop    r15
  408a50:	pop    r14
  408a52:	pop    r13
  408a54:	pop    r12
  408a56:	pop    rdi
  408a57:	pop    rsi
  408a58:	pop    rbx
  408a59:	pop    rbp
  408a5a:	ret
  408a5b:	call   4106a0 <__swc_fn_585f006d_000086_3953ef98>
  408a60:	mov    r12,rax
  408a63:	mov    al,r15b
  408a66:	test   r15b,r15b
  408a69:	jne    408a79 <__swc_fn_585f006d_000093_c2567a3b+0x89>
  408a6b:	mov    eax,DWORD PTR [r12+0x28]
  408a70:	and    eax,0x10000
  408a76:	setne  al
  408a79:	lea    r15,[rsp+0x8]
  408a7e:	mov    QWORD PTR [rsp+0x20],r15
  408a83:	rex mov BYTE PTR [rsp+0x8],al
  408a88:	test   DWORD PTR [rsi+0x28],0x400000
  408a8f:	je     408ac7 <__swc_fn_585f006d_000093_c2567a3b+0xd7>
  408a91:	test   rsi,rsi
  408a94:	je     408ab4 <__swc_fn_585f006d_000093_c2567a3b+0xc4>
  408a96:	mov    rax,QWORD PTR [rsi+0x38]
  408a9a:	cmp    QWORD PTR [rax+0x10],rsi
  408a9e:	jne    408ab4 <__swc_fn_585f006d_000093_c2567a3b+0xc4>
  408aa0:	rex mov al,BYTE PTR [rsp+0x8]
  408aa5:	test   al,al
  408aa7:	sete   al
  408aaa:	test   r14b,r14b
  408aad:	sete   cl
  408ab0:	test   al,cl
  408ab2:	je     408ac7 <__swc_fn_585f006d_000093_c2567a3b+0xd7>
  408ab4:	xor    eax,eax
  408ab6:	add    rsp,0x38
  408aba:	pop    r15
  408abc:	pop    r14
  408abe:	pop    r13
  408ac0:	pop    r12
  408ac2:	pop    rdi
  408ac3:	pop    rsi
  408ac4:	pop    rbx
  408ac5:	pop    rbp
  408ac6:	ret
  408ac7:	mov    r15,r12
  408aca:	test   r14b,r14b
  408acd:	jne    408ae4 <__swc_fn_585f006d_000093_c2567a3b+0xf4>
  408acf:	cmp    BYTE PTR [r12+0x2c],0x6
  408ad5:	jne    408ae4 <__swc_fn_585f006d_000093_c2567a3b+0xf4>
  408ad7:	mov    rcx,QWORD PTR [r12+0x40]
  408adc:	call   4106a0 <__swc_fn_585f006d_000086_3953ef98>
  408ae1:	mov    r15,rax
  408ae4:	test   r14b,r14b
  408ae7:	je     408aed <__swc_fn_585f006d_000093_c2567a3b+0xfd>
  408ae9:	mov    r15,QWORD PTR [r15+0x30]
  408aed:	mov    rcx,rsi
  408af0:	call   4106a0 <__swc_fn_585f006d_000086_3953ef98>
  408af5:	mov    rsi,rax
  408af8:	rex cmp BYTE PTR [rsi+0x2c],0x6
  408afd:	je     408b34 <__swc_fn_585f006d_000093_c2567a3b+0x144>
  408aff:	rex cmp BYTE PTR [rsi+0x2c],0x12
  408b04:	je     408b34 <__swc_fn_585f006d_000093_c2567a3b+0x144>
  408b06:	mov    eax,DWORD PTR [rsi+0x28]
  408b09:	and    eax,0x10000
  408b0f:	je     408b34 <__swc_fn_585f006d_000093_c2567a3b+0x144>
  408b11:	rex mov al,BYTE PTR [rsp+0x8]
  408b16:	test   al,al
  408b18:	jne    408b2d <__swc_fn_585f006d_000093_c2567a3b+0x13d>
  408b1a:	xor    eax,eax
  408b1c:	add    rsp,0x38
  408b20:	pop    r15
  408b22:	pop    r14
  408b24:	pop    r13
  408b26:	pop    r12
  408b28:	pop    rdi
  408b29:	pop    rsi
  408b2a:	pop    rbx
  408b2b:	pop    rbp
  408b2c:	ret
  408b2d:	mov    rax,QWORD PTR [rsi+0x30]
  408b31:	mov    rsi,rax
  408b34:	mov    r14b,r13b
  408b37:	test   rbx,rbx
  408b3a:	je     408b70 <__swc_fn_585f006d_000093_c2567a3b+0x180>
  408b3c:	cmp    BYTE PTR [r12+0x2c],0x6
  408b42:	jne    408b70 <__swc_fn_585f006d_000093_c2567a3b+0x180>
  408b44:	lea    rdx,[rip+0x975d]        # 4122a8 <__swc_rdata_base_585f006d+0x198>
  408b4b:	mov    rcx,rsi
  408b4e:	xor    r8d,r8d
  408b51:	call   40cc20 <__swc_fn_585f006d_000094_63c1827b>
  408b56:	test   al,al
  408b58:	je     408b70 <__swc_fn_585f006d_000093_c2567a3b+0x180>
  408b5a:	mov    BYTE PTR [rbx],0x1
  408b5d:	xor    eax,eax
  408b5f:	add    rsp,0x38
  408b63:	pop    r15
  408b65:	pop    r14
  408b67:	pop    r13
  408b69:	pop    r12
  408b6b:	pop    rdi
  408b6c:	pop    rsi
  408b6d:	pop    rbx
  408b6e:	pop    rbp
  408b6f:	ret
  408b70:	test   rdi,rdi
  408b73:	jne    408b8d <__swc_fn_585f006d_000093_c2567a3b+0x19d>
  408b75:	test   r13b,r13b
  408b78:	jne    408b8d <__swc_fn_585f006d_000093_c2567a3b+0x19d>
  408b7a:	xor    eax,eax
  408b7c:	add    rsp,0x38
  408b80:	pop    r15
  408b82:	pop    r14
  408b84:	pop    r13
  408b86:	pop    r12
  408b88:	pop    rdi
  408b89:	pop    rsi
  408b8a:	pop    rbx
  408b8b:	pop    rbp
  408b8c:	ret
  408b8d:	rex cmp BYTE PTR [rsi+0x2c],0x6
  408b92:	jne    408c48 <__swc_fn_585f006d_000093_c2567a3b+0x258>
  408b98:	mov    rcx,r15
  408b9b:	mov    rdx,rsi
  408b9e:	xor    r8d,r8d
  408ba1:	call   40cc20 <__swc_fn_585f006d_000094_63c1827b>
  408ba6:	test   al,al
  408ba8:	jne    408c48 <__swc_fn_585f006d_000093_c2567a3b+0x258>
  408bae:	test   DWORD PTR [rsi+0x28],0x10000
  408bb5:	je     408bd3 <__swc_fn_585f006d_000093_c2567a3b+0x1e3>
  408bb7:	rex mov al,BYTE PTR [rsp+0x8]
  408bbc:	test   al,al
  408bbe:	jne    408bd3 <__swc_fn_585f006d_000093_c2567a3b+0x1e3>
  408bc0:	xor    eax,eax
  408bc2:	add    rsp,0x38
  408bc6:	pop    r15
  408bc8:	pop    r14
  408bca:	pop    r13
  408bcc:	pop    r12
  408bce:	pop    rdi
  408bcf:	pop    rsi
  408bd0:	pop    rbx
  408bd1:	pop    rbp
  408bd2:	ret
  408bd3:	test   rdi,rdi
  408bd6:	jne    408beb <__swc_fn_585f006d_000093_c2567a3b+0x1fb>
  408bd8:	xor    eax,eax
  408bda:	add    rsp,0x38
  408bde:	pop    r15
  408be0:	pop    r14
  408be2:	pop    r13
  408be4:	pop    r12
  408be6:	pop    rdi
  408be7:	pop    rsi
  408be8:	pop    rbx
  408be9:	pop    rbp
  408bea:	ret
  408beb:	mov    rcx,QWORD PTR [rsi+0x40]
  408bef:	call   4106a0 <__swc_fn_585f006d_000086_3953ef98>
  408bf4:	mov    rsi,rax
  408bf7:	mov    rax,QWORD PTR [rdi]
  408bfa:	mov    rdi,rax
  408bfd:	test   rax,rax
  408c00:	jne    408c43 <__swc_fn_585f006d_000093_c2567a3b+0x253>
  408c02:	test   rbx,rbx
  408c05:	je     408c43 <__swc_fn_585f006d_000093_c2567a3b+0x253>
  408c07:	mov    rcx,r15
  408c0a:	mov    rdx,rsi
  408c0d:	xor    r8d,r8d
  408c10:	call   40cc20 <__swc_fn_585f006d_000094_63c1827b>
  408c15:	mov    rcx,rax
  408c18:	test   al,al
  408c1a:	jne    408c3c <__swc_fn_585f006d_000093_c2567a3b+0x24c>
  408c1c:	mov    rcx,r15
  408c1f:	mov    rdx,rsi
  408c22:	call   4106e0 <__swc_fn_585f006d_000089_d182c4dc>
  408c27:	mov    rcx,rax
  408c2a:	test   al,al
  408c2c:	jne    408c3c <__swc_fn_585f006d_000093_c2567a3b+0x24c>
  408c2e:	mov    rcx,rsi
  408c31:	mov    rdx,r15
  408c34:	call   4106e0 <__swc_fn_585f006d_000089_d182c4dc>
  408c39:	mov    rcx,rax
  408c3c:	test   cl,cl
  408c3e:	setne  al
  408c41:	mov    BYTE PTR [rbx],al
  408c43:	xor    eax,eax
  408c45:	mov    r14b,al
  408c48:	test   rdi,rdi
  408c4b:	jne    408c65 <__swc_fn_585f006d_000093_c2567a3b+0x275>
  408c4d:	test   r14b,r14b
  408c50:	jne    408c65 <__swc_fn_585f006d_000093_c2567a3b+0x275>
  408c52:	xor    eax,eax
  408c54:	add    rsp,0x38
  408c58:	pop    r15
  408c5a:	pop    r14
  408c5c:	pop    r13
  408c5e:	pop    r12
  408c60:	pop    rdi
  408c61:	pop    rsi
  408c62:	pop    rbx
  408c63:	pop    rbp
  408c64:	ret
  408c65:	rex cmp BYTE PTR [rsi+0x2c],0x12
  408c6a:	je     408c76 <__swc_fn_585f006d_000093_c2567a3b+0x286>
  408c6c:	mov    r12,QWORD PTR [rsp+0x18]
  408c71:	jmp    408cfe <__swc_fn_585f006d_000093_c2567a3b+0x30e>
  408c76:	mov    r12,QWORD PTR [rsp+0x18]
  408c7b:	test   r12,r12
  408c7e:	jne    408c92 <__swc_fn_585f006d_000093_c2567a3b+0x2a2>
  408c80:	mov    rcx,r15
  408c83:	mov    rdx,rsi
  408c86:	xor    r8d,r8d
  408c89:	call   40cc20 <__swc_fn_585f006d_000094_63c1827b>
  408c8e:	test   al,al
  408c90:	jne    408cfe <__swc_fn_585f006d_000093_c2567a3b+0x30e>
  408c92:	test   DWORD PTR [rsi+0x28],0x10000
  408c99:	je     408cb7 <__swc_fn_585f006d_000093_c2567a3b+0x2c7>
  408c9b:	rex mov al,BYTE PTR [rsp+0x8]
  408ca0:	test   al,al
  408ca2:	jne    408cb7 <__swc_fn_585f006d_000093_c2567a3b+0x2c7>
  408ca4:	xor    eax,eax
  408ca6:	add    rsp,0x38
  408caa:	pop    r15
  408cac:	pop    r14
  408cae:	pop    r13
  408cb0:	pop    r12
  408cb2:	pop    rdi
  408cb3:	pop    rsi
  408cb4:	pop    rbx
  408cb5:	pop    rbp
  408cb6:	ret
  408cb7:	test   rdi,rdi
  408cba:	jne    408ccf <__swc_fn_585f006d_000093_c2567a3b+0x2df>
  408cbc:	xor    eax,eax
  408cbe:	add    rsp,0x38
  408cc2:	pop    r15
  408cc4:	pop    r14
  408cc6:	pop    r13
  408cc8:	pop    r12
  408cca:	pop    rdi
  408ccb:	pop    rsi
  408ccc:	pop    rbx
  408ccd:	pop    rbp
  408cce:	ret
  408ccf:	cmp    QWORD PTR [rdi+0x8],0x0
  408cd4:	jne    408ce9 <__swc_fn_585f006d_000093_c2567a3b+0x2f9>
  408cd6:	xor    eax,eax
  408cd8:	add    rsp,0x38
  408cdc:	pop    r15
  408cde:	pop    r14
  408ce0:	pop    r13
  408ce2:	pop    r12
  408ce4:	pop    rdi
  408ce5:	pop    rsi
  408ce6:	pop    rbx
  408ce7:	pop    rbp
  408ce8:	ret
  408ce9:	mov    rax,QWORD PTR [rdi+0x8]
  408ced:	mov    rax,QWORD PTR [rax]
  408cf0:	mov    rsi,rax
  408cf3:	mov    rdi,QWORD PTR [rdi]
  408cf6:	mov    eax,0x1
  408cfb:	mov    r14b,al
  408cfe:	test   rdi,rdi
  408d01:	mov    rbx,QWORD PTR [rsp+0x20]
  408d06:	jne    408d50 <__swc_fn_585f006d_000093_c2567a3b+0x360>
  408d08:	test   r14b,r14b
  408d0b:	je     408d3d <__swc_fn_585f006d_000093_c2567a3b+0x34d>
  408d0d:	test   r12,r12
  408d10:	je     408d3d <__swc_fn_585f006d_000093_c2567a3b+0x34d>
  408d12:	mov    rcx,r15
  408d15:	mov    rdx,rsi
  408d18:	xor    r8d,r8d
  408d1b:	mov    r9,r12
  408d1e:	mov    rbx,QWORD PTR [rsp+0x20]
  408d23:	movzx  r10d,BYTE PTR [rbx]
  408d27:	call   4088e0 <__swc_fn_585f006d_000087_ef55f6e4>
  408d2c:	add    rsp,0x38
  408d30:	pop    r15
  408d32:	pop    r14
  408d34:	pop    r13
  408d36:	pop    r12
  408d38:	pop    rdi
  408d39:	pop    rsi
  408d3a:	pop    rbx
  408d3b:	pop    rbp
  408d3c:	ret
  408d3d:	xor    eax,eax
  408d3f:	add    rsp,0x38
  408d43:	pop    r15
  408d45:	pop    r14
  408d47:	pop    r13
  408d49:	pop    r12
  408d4b:	pop    rdi
  408d4c:	pop    rsi
  408d4d:	pop    rbx
  408d4e:	pop    rbp
  408d4f:	ret
  408d50:	mov    r13,rsi
  408d53:	mov    QWORD PTR [rsp+0x28],rdi
  408d58:	cmp    BYTE PTR [r15+0x2c],0xe
  408d5d:	sete   al
  408d60:	mov    r14b,al
  408d63:	jne    408d77 <__swc_fn_585f006d_000093_c2567a3b+0x387>
  408d65:	mov    rcx,rsi
  408d68:	mov    rdx,r15
  408d6b:	call   4106e0 <__swc_fn_585f006d_000089_d182c4dc>
  408d70:	mov    r14b,al
  408d73:	test   al,al
  408d75:	jne    408dac <__swc_fn_585f006d_000093_c2567a3b+0x3bc>
  408d77:	cmp    BYTE PTR [r15+0x2c],0x12
  408d7c:	je     408dac <__swc_fn_585f006d_000093_c2567a3b+0x3bc>
  408d7e:	mov    rcx,r15
  408d81:	mov    rdx,rsi
  408d84:	mov    r8,rdi
  408d87:	mov    r9,r12
  408d8a:	mov    rax,rbx
  408d8d:	movzx  r10d,BYTE PTR [rax]
  408d91:	call   4088e0 <__swc_fn_585f006d_000087_ef55f6e4>
  408d96:	test   rax,rax
  408d99:	je     408dac <__swc_fn_585f006d_000093_c2567a3b+0x3bc>
  408d9b:	add    rsp,0x38
  408d9f:	pop    r15
  408da1:	pop    r14
  408da3:	pop    r13
  408da5:	pop    r12
  408da7:	pop    rdi
  408da8:	pop    rsi
  408da9:	pop    rbx
  408daa:	pop    rbp
  408dab:	ret
  408dac:	rex cmp BYTE PTR [rsi+0x2c],0xe
  408db1:	jne    408dd0 <__swc_fn_585f006d_000093_c2567a3b+0x3e0>
  408db3:	mov    rax,QWORD PTR [rsi+0xd8]
  408dba:	test   rax,rax
  408dbd:	je     408dd0 <__swc_fn_585f006d_000093_c2567a3b+0x3e0>
  408dbf:	add    rdi,QWORD PTR [rax+0x8]
  408dc3:	mov    rax,QWORD PTR [rdi]
  408dc6:	sub    rdi,QWORD PTR [rax+0x8]
  408dca:	mov    rax,QWORD PTR [rax]
  408dcd:	mov    rsi,rax
  408dd0:	test   r14b,r14b
  408dd3:	je     408dff <__swc_fn_585f006d_000093_c2567a3b+0x40f>
  408dd5:	mov    rcx,r15
  408dd8:	mov    rdx,rsi
  408ddb:	mov    r8,rdi
  408dde:	mov    r9,r13
  408de1:	mov    r14,QWORD PTR [rsp+0x28]
  408de6:	mov    r10,r14
  408de9:	call   40cb00 <__swc_fn_585f006d_000091_c1c9085b>
  408dee:	add    rsp,0x38
  408df2:	pop    r15
  408df4:	pop    r14
  408df6:	pop    r13
  408df8:	pop    r12
  408dfa:	pop    rdi
  408dfb:	pop    rsi
  408dfc:	pop    rbx
  408dfd:	pop    rbp
  408dfe:	ret
  408dff:	mov    rcx,r15
  408e02:	mov    rdx,rsi
  408e05:	mov    r8,rdi
  408e08:	mov    r9,r12
  408e0b:	movzx  r10d,BYTE PTR [rbx]
  408e0f:	call   4088e0 <__swc_fn_585f006d_000087_ef55f6e4>
  408e14:	add    rsp,0x38
  408e18:	pop    r15
  408e1a:	pop    r14
  408e1c:	pop    r13
  408e1e:	pop    r12
  408e20:	pop    rdi
  408e21:	pop    rsi
  408e22:	pop    rbx
  408e23:	pop    rbp
  408e24:	ret
	...

0000000000408e30 <__swc_fn_585f006d_000096_93bfe675>:
  408e30:	push   rbx
  408e31:	push   rsi
  408e32:	sub    rsp,0x18
  408e36:	mov    rbx,rcx
  408e39:	mov    rcx,QWORD PTR [rip+0x1a200]        # 423040 <__swc_bss_base_585f006d>
  408e40:	test   rcx,rcx
  408e43:	jne    408e55 <__swc_fn_585f006d_000096_93bfe675+0x25>
  408e45:	call   40e820 <__swc_fn_585f006d_000169_994c8876>
  408e4a:	lea    rcx,[rax+0x1]
  408e4e:	mov    QWORD PTR [rip+0x1a1eb],rcx        # 423040 <__swc_bss_base_585f006d>
  408e55:	dec    rcx
  408e58:	call   40b6e0 <__swc_fn_585f006d_000171_360af05d>
  408e5d:	mov    rsi,rax
  408e60:	mov    rax,QWORD PTR [rsi+0x8]
  408e64:	test   rax,rax
  408e67:	jne    408eb7 <__swc_fn_585f006d_000096_93bfe675+0x87>
  408e69:	call   4107d0 <__swc_fn_585f006d_000095_ad13d15c>
  408e6e:	test   al,al
  408e70:	jne    408eb7 <__swc_fn_585f006d_000096_93bfe675+0x87>
  408e72:	lea    rdx,[rip+0x1a3c7]        # 423240 <__swc_bss_base_585f006d+0x200>
  408e79:	mov    rcx,rdx
  408e7c:	call   40bdd0 <__swc_fn_585f006d_000040_eb6108f2>
  408e81:	test   al,al
  408e83:	jne    408e94 <__swc_fn_585f006d_000096_93bfe675+0x64>
  408e85:	mov    rcx,rdx
  408e88:	call   40f0c0 <__swc_fn_585f006d_000038_14f56618>
  408e8d:	lea    rdx,[rip+0x1a3ac]        # 423240 <__swc_bss_base_585f006d+0x200>
  408e94:	mov    QWORD PTR [rsp+0x8],rdx
  408e99:	lea    rax,[rip+0x93d8]        # 412278 <__swc_rdata_base_585f006d+0x168>
  408ea0:	mov    QWORD PTR [rsp+0x10],rax
  408ea5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  408eab:	vmovups XMMWORD PTR [rsi],xmm0
  408eaf:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  408eb7:	vmovups xmm0,XMMWORD PTR [rsi]
  408ebb:	vmovups XMMWORD PTR [rbx],xmm0
  408ebf:	mov    rax,rbx
  408ec2:	add    rsp,0x18
  408ec6:	pop    rsi
  408ec7:	pop    rbx
  408ec8:	ret
  408ec9:	add    BYTE PTR [rax],al
  408ecb:	add    BYTE PTR [rax],al
  408ecd:	add    BYTE PTR [rax],al
	...

0000000000408ed0 <__swc_fn_585f006d_000099_65137b72>:
  408ed0:	sub    rsp,0x8
  408ed4:	call   40d9c0 <__swc_fn_585f006d_000121_0a5fa85a>
  408ed9:	add    rsp,0x8
  408edd:	ret
	...

0000000000408ee0 <__swc_fn_585f006d_000102_e34f54dc>:
  408ee0:	push   rbx
  408ee1:	push   rsi
  408ee2:	sub    rsp,0x28
  408ee6:	mov    rbx,rcx
  408ee9:	xor    esi,esi
  408eeb:	jmp    408f00 <__swc_fn_585f006d_000102_e34f54dc+0x20>
  408eed:	nop    DWORD PTR [rax]
  408ef0:	mov    QWORD PTR [rbx+0x28],rsi
  408ef4:	mov    rsi,rbx
  408ef7:	mov    rbx,rax
  408efa:	nop    WORD PTR [rax+rax*1+0x0]
  408f00:	test   rbx,rbx
  408f03:	je     408f63 <__swc_fn_585f006d_000102_e34f54dc+0x83>
  408f05:	mov    rcx,rbx
  408f08:	mov    edx,0x1
  408f0d:	call   40c880 <__swc_fn_585f006d_000082_63a67586>
  408f12:	cmp    rax,0x1
  408f16:	jne    408f63 <__swc_fn_585f006d_000102_e34f54dc+0x83>
  408f18:	mov    r10,QWORD PTR [rbx+0x18]
  408f1c:	mov    rcx,r10
  408f1f:	mov    edx,0x1
  408f24:	call   40c880 <__swc_fn_585f006d_000082_63a67586>
  408f29:	cmp    rax,0x1
  408f2d:	jne    408f3c <__swc_fn_585f006d_000102_e34f54dc+0x5c>
  408f2f:	mov    rcx,r10
  408f32:	call   410970 <__swc_fn_585f006d_000101_d0b19c14>
  408f37:	test   rax,rax
  408f3a:	jne    408ef0 <__swc_fn_585f006d_000102_e34f54dc+0x10>
  408f3c:	mov    rax,QWORD PTR [rbx+0x20]
  408f40:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  408f45:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  408f4b:	lea    rcx,[rsp+0x8]
  408f50:	mov    rdx,rbx
  408f53:	mov    r8d,0x30
  408f59:	mov    rbx,rax
  408f5c:	call   40cfe0 <__swc_fn_585f006d_000100_d4bdcaa4>
  408f61:	jmp    408f00 <__swc_fn_585f006d_000102_e34f54dc+0x20>
  408f63:	test   rsi,rsi
  408f66:	jne    408f6f <__swc_fn_585f006d_000102_e34f54dc+0x8f>
  408f68:	add    rsp,0x28
  408f6c:	pop    rsi
  408f6d:	pop    rbx
  408f6e:	ret
  408f6f:	mov    rax,rsi
  408f72:	mov    rsi,QWORD PTR [rsi+0x28]
  408f76:	mov    rbx,QWORD PTR [rax+0x20]
  408f7a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  408f7f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408f85:	lea    rcx,[rsp+0x18]
  408f8a:	mov    rdx,rax
  408f8d:	mov    r8d,0x30
  408f93:	call   40cfe0 <__swc_fn_585f006d_000100_d4bdcaa4>
  408f98:	jmp    408f00 <__swc_fn_585f006d_000102_e34f54dc+0x20>
  408f9d:	add    BYTE PTR [rax],al
	...

0000000000408fa0 <__swc_fn_585f006d_000105_5a85fcf5>:
  408fa0:	push   rbx
  408fa1:	push   rsi
  408fa2:	push   rdi
  408fa3:	push   r12
  408fa5:	push   r13
  408fa7:	sub    rsp,0x20
  408fab:	mov    rbx,rcx
  408fae:	lea    rsi,[rcx+0x6f8]
  408fb5:	mov    edi,0x4
  408fba:	mov    r12,rsi
  408fbd:	test   rdi,rdi
  408fc0:	je     40900a <__swc_fn_585f006d_000105_5a85fcf5+0x6a>
  408fc2:	cs nop WORD PTR [rax+rax*1+0x0]
  408fcc:	nop    DWORD PTR [rax+0x0]
  408fd0:	mov    rcx,QWORD PTR [r12+0x10]
  408fd5:	mov    QWORD PTR [r12+0x10],0x0
  408fde:	vxorps xmm0,xmm0,xmm0
  408fe2:	vmovups XMMWORD PTR [r12],xmm0
  408fe8:	vmovups XMMWORD PTR [r12+0x28],xmm0
  408fef:	mov    DWORD PTR [r12+0x20],0x0
  408ff8:	call   40d030 <__swc_fn_585f006d_000103_2fdd2c61>
  408ffd:	add    r12,0x90
  409004:	sub    rdi,0x1
  409008:	jne    408fd0 <__swc_fn_585f006d_000105_5a85fcf5+0x30>
  40900a:	mov    rax,QWORD PTR [rbx+0x938]
  409011:	mov    rdi,rax
  409014:	test   rdi,rdi
  409017:	je     409071 <__swc_fn_585f006d_000105_5a85fcf5+0xd1>
  409019:	nop    DWORD PTR [rax+0x0]
  409020:	mov    r12d,0x10
  409026:	lea    r13,[rdi+0x18]
  40902a:	test   r12,r12
  40902d:	je     409066 <__swc_fn_585f006d_000105_5a85fcf5+0xc6>
  40902f:	nop
  409030:	mov    rcx,QWORD PTR [r13+0x10]
  409034:	mov    QWORD PTR [r13+0x10],0x0
  40903c:	vxorps xmm0,xmm0,xmm0
  409040:	vmovups XMMWORD PTR [r13+0x0],xmm0
  409046:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40904c:	mov    DWORD PTR [r13+0x20],0x0
  409054:	call   40d030 <__swc_fn_585f006d_000103_2fdd2c61>
  409059:	add    r13,0x90
  409060:	sub    r12,0x1
  409064:	jne    409030 <__swc_fn_585f006d_000105_5a85fcf5+0x90>
  409066:	mov    rax,QWORD PTR [rdi]
  409069:	mov    rdi,rax
  40906c:	test   rax,rax
  40906f:	jne    409020 <__swc_fn_585f006d_000105_5a85fcf5+0x80>
  409071:	vxorps xmm0,xmm0,xmm0
  409075:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40907d:	mov    DWORD PTR [rbx+0x9b0],0x0
  409087:	mov    DWORD PTR [rbx+0x9a8],0x0
  409091:	mov    edi,0x4
  409096:	mov    r12,rsi
  409099:	lea    rsi,[rsi+0x38]
  40909d:	test   rdi,rdi
  4090a0:	je     4090cc <__swc_fn_585f006d_000105_5a85fcf5+0x12c>
  4090a2:	cs nop WORD PTR [rax+rax*1+0x0]
  4090ac:	nop    DWORD PTR [rax+0x0]
  4090b0:	mov    rcx,rsi
  4090b3:	call   4117f0 <__swc_fn_585f006d_000161_13ead2ff>
  4090b8:	add    rsi,0x90
  4090bf:	add    r12,0x90
  4090c6:	sub    rdi,0x1
  4090ca:	jne    4090b0 <__swc_fn_585f006d_000105_5a85fcf5+0x110>
  4090cc:	mov    rax,QWORD PTR [rbx+0x938]
  4090d3:	mov    rdi,rax
  4090d6:	mov    QWORD PTR [rbx+0x938],0x0
  4090e1:	test   rdi,rdi
  4090e4:	je     409155 <__swc_fn_585f006d_000105_5a85fcf5+0x1b5>
  4090ea:	nop    WORD PTR [rax+rax*1+0x0]
  4090f0:	mov    esi,0x10
  4090f5:	lea    r12,[rdi+0x18]
  4090f9:	lea    r13,[rdi+0x50]
  4090fd:	test   rsi,rsi
  409100:	je     40912c <__swc_fn_585f006d_000105_5a85fcf5+0x18c>
  409102:	cs nop WORD PTR [rax+rax*1+0x0]
  40910c:	nop    DWORD PTR [rax+0x0]
  409110:	mov    rcx,r13
  409113:	call   4117f0 <__swc_fn_585f006d_000161_13ead2ff>
  409118:	add    r13,0x90
  40911f:	add    r12,0x90
  409126:	sub    rsi,0x1
  40912a:	jne    409110 <__swc_fn_585f006d_000105_5a85fcf5+0x170>
  40912c:	mov    rax,QWORD PTR [rdi]
  40912f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  409134:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40913a:	lea    rcx,[rsp+0x8]
  40913f:	mov    rdx,rdi
  409142:	mov    r8d,0x918
  409148:	mov    rdi,rax
  40914b:	call   40cfe0 <__swc_fn_585f006d_000100_d4bdcaa4>
  409150:	test   rdi,rdi
  409153:	jne    4090f0 <__swc_fn_585f006d_000105_5a85fcf5+0x150>
  409155:	lea    rcx,[rbx+0x68]
  409159:	call   4117f0 <__swc_fn_585f006d_000161_13ead2ff>
  40915e:	add    rsp,0x20
  409162:	pop    r13
  409164:	pop    r12
  409166:	pop    rdi
  409167:	pop    rsi
  409168:	pop    rbx
  409169:	ret
  40916a:	add    BYTE PTR [rax],al
  40916c:	add    BYTE PTR [rax],al
	...

0000000000409170 <__swc_fn_585f006d_000108_c51c3158>:
  409170:	xor    eax,eax
  409172:	cs nop WORD PTR [rax+rax*1+0x0]
  40917c:	nop    DWORD PTR [rax+0x0]
  409180:	mov    r9,r8
  409183:	sub    r9,rax
  409186:	cmp    r9,0x40
  40918a:	jb     4091c8 <__swc_fn_585f006d_000108_c51c3158+0x58>
  40918c:	lea    r9,[rcx+rax*1]
  409190:	lea    r10,[rdx+rax*1]
  409194:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40919a:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  4091a0:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  4091a6:	vmovups xmm3,XMMWORD PTR [r10]
  4091ab:	vmovups XMMWORD PTR [r9],xmm3
  4091b0:	vmovups XMMWORD PTR [r9+0x10],xmm0
  4091b6:	vmovups XMMWORD PTR [r9+0x20],xmm1
  4091bc:	vmovups XMMWORD PTR [r9+0x30],xmm2
  4091c2:	lea    rax,[rax+0x40]
  4091c6:	jmp    409180 <__swc_fn_585f006d_000108_c51c3158+0x10>
  4091c8:	nop    DWORD PTR [rax+rax*1+0x0]
  4091d0:	mov    r9,r8
  4091d3:	sub    r9,rax
  4091d6:	cmp    r9,0x10
  4091da:	jb     4091f4 <__swc_fn_585f006d_000108_c51c3158+0x84>
  4091dc:	lea    r9,[rdx+rax*1]
  4091e0:	lea    r10,[rcx+rax*1]
  4091e4:	vmovups xmm0,XMMWORD PTR [r9]
  4091e9:	vmovups XMMWORD PTR [r10],xmm0
  4091ee:	lea    rax,[rax+0x10]
  4091f2:	jmp    4091d0 <__swc_fn_585f006d_000108_c51c3158+0x60>
  4091f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4091fe:	xchg   ax,ax
  409200:	mov    r9,r8
  409203:	sub    r9,rax
  409206:	cmp    r9,0x8
  40920a:	jb     40921d <__swc_fn_585f006d_000108_c51c3158+0xad>
  40920c:	lea    r9,[rcx+rax*1]
  409210:	mov    r10,QWORD PTR [rdx+rax*1]
  409214:	mov    QWORD PTR [r9],r10
  409217:	lea    rax,[rax+0x8]
  40921b:	jmp    409200 <__swc_fn_585f006d_000108_c51c3158+0x90>
  40921d:	cmp    rax,r8
  409220:	jae    409240 <__swc_fn_585f006d_000108_c51c3158+0xd0>
  409222:	cs nop WORD PTR [rax+rax*1+0x0]
  40922c:	nop    DWORD PTR [rax+0x0]
  409230:	mov    r9b,BYTE PTR [rdx+rax*1]
  409234:	mov    BYTE PTR [rcx+rax*1],r9b
  409238:	inc    rax
  40923b:	cmp    rax,r8
  40923e:	jb     409230 <__swc_fn_585f006d_000108_c51c3158+0xc0>
  409240:	ret
	...

0000000000409250 <__swc_fn_585f006d_000111_6814119b>:
  409250:	push   rbx
  409251:	push   r12
  409253:	push   rdi
  409254:	push   rsi
  409255:	push   r13
  409257:	push   r14
  409259:	push   r15
  40925b:	sub    rsp,0x170
  409262:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40926b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  409274:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40927d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  409286:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40928f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  409298:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  4092a1:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  4092aa:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  4092b3:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  4092bc:	mov    ebx,edx
  4092be:	mov    QWORD PTR [rsp+0xa8],rbx
  4092c6:	mov    r12d,ecx
  4092c9:	test   edx,edx
  4092cb:	jne    4092e2 <__swc_fn_585f006d_000111_6814119b+0x92>
  4092cd:	xor    eax,eax
  4092cf:	add    rsp,0x170
  4092d6:	pop    r15
  4092d8:	pop    r14
  4092da:	pop    r13
  4092dc:	pop    rsi
  4092dd:	pop    rdi
  4092de:	pop    r12
  4092e0:	pop    rbx
  4092e1:	ret
  4092e2:	lea    rdi,[rip+0x9297]        # 412580 <__swc_rdata_base_585f006d+0x470>
  4092e9:	mov    esi,0x90000
  4092ee:	xor    eax,eax
  4092f0:	call   407010 <open@plt>
  4092f5:	mov    r13,rax
  4092f8:	mov    QWORD PTR [rsp+0xb0],rax
  409300:	test   eax,eax
  409302:	jge    40930b <__swc_fn_585f006d_000111_6814119b+0xbb>
  409304:	xor    eax,eax
  409306:	jmp    409806 <__swc_fn_585f006d_000111_6814119b+0x5b6>
  40930b:	nop    DWORD PTR [rax+rax*1+0x0]
  409310:	movsxd rdi,r13d
  409313:	mov    esi,0x2
  409318:	xor    eax,eax
  40931a:	call   407020 <flock@plt>
  40931f:	test   eax,eax
  409321:	je     409340 <__swc_fn_585f006d_000111_6814119b+0xf0>
  409323:	xor    eax,eax
  409325:	call   407030 <__errno_location@plt>
  40932a:	cmp    DWORD PTR [rax],0x4
  40932d:	je     409310 <__swc_fn_585f006d_000111_6814119b+0xc0>
  40932f:	movsxd rdi,r13d
  409332:	xor    eax,eax
  409334:	call   407040 <close@plt>
  409339:	xor    eax,eax
  40933b:	jmp    409806 <__swc_fn_585f006d_000111_6814119b+0x5b6>
  409340:	lea    r14,[rsp+0x8]
  409345:	mov    QWORD PTR [rsp+0xb8],r14
  40934d:	vxorps xmm0,xmm0,xmm0
  409351:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409357:	mov    QWORD PTR [rsp+0x18],0x0
  409360:	mov    WORD PTR [rsp+0x20],0x0
  409367:	mov    DWORD PTR [r14],0x67617753
  40936e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  409376:	xor    eax,eax
  409378:	call   407050 <getpid@plt>
  40937d:	mov    ecx,eax
  40937f:	mov    eax,0x1c
  409384:	shrx   eax,ecx,eax
  409389:	and    eax,0xf
  40938c:	mov    rdx,QWORD PTR [rip+0x920d]        # 4125a0 <__swc_rdata_base_585f006d+0x490>
  409393:	mov    al,BYTE PTR [rdx+rax*1]
  409396:	rex mov BYTE PTR [rsp+0x10],al
  40939b:	mov    eax,0x1c
  4093a0:	shrx   eax,r12d,eax
  4093a5:	and    eax,0xf
  4093a8:	mov    al,BYTE PTR [rdx+rax*1]
  4093ab:	rex mov BYTE PTR [rsp+0x19],al
  4093b0:	mov    eax,0x18
  4093b5:	shrx   eax,ecx,eax
  4093ba:	and    eax,0xf
  4093bd:	mov    al,BYTE PTR [rdx+rax*1]
  4093c0:	rex mov BYTE PTR [rsp+0x11],al
  4093c5:	mov    eax,0x18
  4093ca:	shrx   eax,r12d,eax
  4093cf:	and    eax,0xf
  4093d2:	mov    al,BYTE PTR [rdx+rax*1]
  4093d5:	rex mov BYTE PTR [rsp+0x1a],al
  4093da:	mov    eax,0x14
  4093df:	shrx   eax,ecx,eax
  4093e4:	and    eax,0xf
  4093e7:	mov    al,BYTE PTR [rdx+rax*1]
  4093ea:	rex mov BYTE PTR [rsp+0x12],al
  4093ef:	mov    eax,0x14
  4093f4:	shrx   eax,r12d,eax
  4093f9:	and    eax,0xf
  4093fc:	mov    al,BYTE PTR [rdx+rax*1]
  4093ff:	rex mov BYTE PTR [rsp+0x1b],al
  409404:	mov    eax,0x10
  409409:	shrx   eax,ecx,eax
  40940e:	and    eax,0xf
  409411:	mov    al,BYTE PTR [rdx+rax*1]
  409414:	rex mov BYTE PTR [rsp+0x13],al
  409419:	mov    eax,0x10
  40941e:	shrx   eax,r12d,eax
  409423:	and    eax,0xf
  409426:	mov    al,BYTE PTR [rdx+rax*1]
  409429:	rex mov BYTE PTR [rsp+0x1c],al
  40942e:	mov    eax,0xc
  409433:	shrx   eax,ecx,eax
  409438:	and    eax,0xf
  40943b:	mov    al,BYTE PTR [rdx+rax*1]
  40943e:	rex mov BYTE PTR [rsp+0x14],al
  409443:	mov    eax,0xc
  409448:	shrx   eax,r12d,eax
  40944d:	and    eax,0xf
  409450:	mov    al,BYTE PTR [rdx+rax*1]
  409453:	rex mov BYTE PTR [rsp+0x1d],al
  409458:	mov    eax,0x8
  40945d:	shrx   eax,ecx,eax
  409462:	and    eax,0xf
  409465:	mov    al,BYTE PTR [rdx+rax*1]
  409468:	rex mov BYTE PTR [rsp+0x15],al
  40946d:	mov    eax,0x8
  409472:	shrx   eax,r12d,eax
  409477:	and    eax,0xf
  40947a:	mov    al,BYTE PTR [rdx+rax*1]
  40947d:	rex mov BYTE PTR [rsp+0x1e],al
  409482:	mov    eax,0x4
  409487:	shrx   eax,ecx,eax
  40948c:	and    eax,0xf
  40948f:	mov    al,BYTE PTR [rdx+rax*1]
  409492:	rex mov BYTE PTR [rsp+0x16],al
  409497:	mov    eax,0x4
  40949c:	shrx   eax,r12d,eax
  4094a1:	and    eax,0xf
  4094a4:	mov    al,BYTE PTR [rdx+rax*1]
  4094a7:	rex mov BYTE PTR [rsp+0x1f],al
  4094ac:	xor    eax,eax
  4094ae:	shrx   eax,ecx,eax
  4094b3:	and    eax,0xf
  4094b6:	mov    al,BYTE PTR [rdx+rax*1]
  4094b9:	rex mov BYTE PTR [rsp+0x17],al
  4094be:	xor    eax,eax
  4094c0:	shrx   eax,r12d,eax
  4094c5:	and    eax,0xf
  4094c8:	mov    al,BYTE PTR [rdx+rax*1]
  4094cb:	rex mov BYTE PTR [rsp+0x20],al
  4094d0:	mov    BYTE PTR [r14+0x10],0x2e
  4094d5:	lea    r12,[rsp+0x22]
  4094da:	vxorps xmm0,xmm0,xmm0
  4094de:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  4094e4:	mov    DWORD PTR [r12],0x6d656d2f
  4094ec:	mov    WORD PTR [r12+0x4],0x6466
  4094f4:	mov    BYTE PTR [r12+0x6],0x3a
  4094fa:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409500:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  409506:	mov    rax,QWORD PTR [rsp+0x18]
  40950b:	mov    QWORD PTR [rsp+0x39],rax
  409510:	rex mov al,BYTE PTR [rsp+0x20]
  409515:	rex mov BYTE PTR [rsp+0x41],al
  40951a:	mov    DWORD PTR [r12+0x20],0x65642820
  409523:	mov    DWORD PTR [r12+0x24],0x6574656c
  40952c:	mov    WORD PTR [r12+0x28],0x2964
  409534:	lea    rdi,[rip+0x9050]        # 41258b <__swc_rdata_base_585f006d+0x47b>
  40953b:	xor    eax,eax
  40953d:	call   407060 <opendir@plt>
  409542:	mov    r15,rax
  409545:	test   rax,rax
  409548:	jne    40955b <__swc_fn_585f006d_000111_6814119b+0x30b>
  40954a:	movsxd rdi,r13d
  40954d:	xor    eax,eax
  40954f:	call   407040 <close@plt>
  409554:	xor    eax,eax
  409556:	jmp    409806 <__swc_fn_585f006d_000111_6814119b+0x5b6>
  40955b:	mov    rdi,r15
  40955e:	xor    eax,eax
  409560:	call   407070 <dirfd@plt>
  409565:	lea    r14,[rsp+0x54]
  40956a:	mov    DWORD PTR [rsp+0x54],eax
  40956e:	lea    rbx,[rsp+0x58]
  409573:	cs nop WORD PTR [rax+rax*1+0x0]
  40957d:	nop    DWORD PTR [rax]
  409580:	mov    rdi,r15
  409583:	xor    eax,eax
  409585:	call   407080 <readdir@plt>
  40958a:	test   rax,rax
  40958d:	jne    4095a4 <__swc_fn_585f006d_000111_6814119b+0x354>
  40958f:	mov    r12,QWORD PTR [rsp+0xa8]
  409597:	mov    r13,QWORD PTR [rsp+0xb0]
  40959f:	jmp    40972a <__swc_fn_585f006d_000111_6814119b+0x4da>
  4095a4:	vxorps xmm0,xmm0,xmm0
  4095a8:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  4095ae:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  4095b4:	vzeroupper
  4095b7:	lea    r13,[rax+0x13]
  4095bb:	mov    rax,r14
  4095be:	movsxd rdi,DWORD PTR [rax]
  4095c1:	mov    rsi,r13
  4095c4:	mov    rdx,rbx
  4095c7:	mov    ecx,0x40
  4095cc:	xor    eax,eax
  4095ce:	call   407090 <readlinkat@plt>
  4095d3:	cmp    rax,0x2a
  4095d7:	jne    409580 <__swc_fn_585f006d_000111_6814119b+0x330>
  4095d9:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  4095df:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  4095e5:	vptest xmm0,xmm0
  4095ea:	jne    40961a <__swc_fn_585f006d_000111_6814119b+0x3ca>
  4095ec:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  4095f2:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  4095f8:	vptest xmm0,xmm0
  4095fd:	jne    40961a <__swc_fn_585f006d_000111_6814119b+0x3ca>
  4095ff:	mov    rcx,QWORD PTR [rsp+0x42]
  409604:	cmp    QWORD PTR [rsp+0x78],rcx
  409609:	jne    40961a <__swc_fn_585f006d_000111_6814119b+0x3ca>
  40960b:	mov    cx,WORD PTR [rsp+0x4a]
  409610:	cmp    WORD PTR [rsp+0x80],cx
  409618:	je     409644 <__swc_fn_585f006d_000111_6814119b+0x3f4>
  40961a:	mov    rax,rbx
  40961d:	mov    rcx,r12
  409620:	movzx  edx,BYTE PTR [rax]
  409623:	movzx  r8d,BYTE PTR [rcx]
  409627:	cmp    rdx,r8
  40962a:	jne    409636 <__swc_fn_585f006d_000111_6814119b+0x3e6>
  40962c:	add    rax,0x1
  409630:	add    rcx,0x1
  409634:	jmp    409620 <__swc_fn_585f006d_000111_6814119b+0x3d0>
  409636:	mov    rax,rdx
  409639:	sub    rax,r8
  40963c:	test   eax,eax
  40963e:	jne    409580 <__swc_fn_585f006d_000111_6814119b+0x330>
  409644:	movsxd rdi,DWORD PTR [r14]
  409647:	mov    rsi,r13
  40964a:	mov    edx,0x80002
  40964f:	xor    eax,eax
  409651:	call   4070a0 <openat@plt>
  409656:	lea    rbx,[rsp+0x98]
  40965e:	mov    DWORD PTR [rsp+0x98],eax
  409665:	test   eax,eax
  409667:	mov    r13,QWORD PTR [rsp+0xb0]
  40966f:	jge    409694 <__swc_fn_585f006d_000111_6814119b+0x444>
  409671:	mov    rdi,r15
  409674:	xor    eax,eax
  409676:	call   4070b0 <closedir@plt>
  40967b:	mov    r13,QWORD PTR [rsp+0xb0]
  409683:	movsxd rdi,r13d
  409686:	xor    eax,eax
  409688:	call   407040 <close@plt>
  40968d:	xor    eax,eax
  40968f:	jmp    409806 <__swc_fn_585f006d_000111_6814119b+0x5b6>
  409694:	mov    rax,rbx
  409697:	movsxd rdi,DWORD PTR [rax]
  40969a:	xor    esi,esi
  40969c:	mov    edx,0x2
  4096a1:	xor    eax,eax
  4096a3:	call   4070c0 <lseek@plt>
  4096a8:	mov    r12,QWORD PTR [rsp+0xa8]
  4096b0:	cmp    rax,r12
  4096b3:	je     4096da <__swc_fn_585f006d_000111_6814119b+0x48a>
  4096b5:	movsxd rdi,DWORD PTR [rbx]
  4096b8:	xor    eax,eax
  4096ba:	call   407040 <close@plt>
  4096bf:	mov    rdi,r15
  4096c2:	xor    eax,eax
  4096c4:	call   4070b0 <closedir@plt>
  4096c9:	movsxd rdi,r13d
  4096cc:	xor    eax,eax
  4096ce:	call   407040 <close@plt>
  4096d3:	xor    eax,eax
  4096d5:	jmp    409806 <__swc_fn_585f006d_000111_6814119b+0x5b6>
  4096da:	xor    edi,edi
  4096dc:	mov    rsi,r12
  4096df:	mov    edx,0x3
  4096e4:	mov    ecx,0x1
  4096e9:	mov    rax,rbx
  4096ec:	movsxd r8,DWORD PTR [rax]
  4096ef:	xor    r9d,r9d
  4096f2:	xor    eax,eax
  4096f4:	call   4070d0 <mmap@plt>
  4096f9:	xor    r12d,r12d
  4096fc:	cmp    rax,0xffffffffffffffff
  409700:	cmovne r12,rax
  409704:	movsxd rdi,DWORD PTR [rbx]
  409707:	xor    eax,eax
  409709:	call   407040 <close@plt>
  40970e:	mov    rdi,r15
  409711:	xor    eax,eax
  409713:	call   4070b0 <closedir@plt>
  409718:	movsxd rdi,r13d
  40971b:	xor    eax,eax
  40971d:	call   407040 <close@plt>
  409722:	mov    rax,r12
  409725:	jmp    409806 <__swc_fn_585f006d_000111_6814119b+0x5b6>
  40972a:	mov    r14,QWORD PTR [rsp+0xb8]
  409732:	mov    rdi,r14
  409735:	mov    esi,0x1
  40973a:	xor    eax,eax
  40973c:	call   4070e0 <memfd_create@plt>
  409741:	lea    rbx,[rsp+0x9c]
  409749:	mov    DWORD PTR [rsp+0x9c],eax
  409750:	test   eax,eax
  409752:	jge    40976f <__swc_fn_585f006d_000111_6814119b+0x51f>
  409754:	mov    rdi,r15
  409757:	xor    eax,eax
  409759:	call   4070b0 <closedir@plt>
  40975e:	movsxd rdi,r13d
  409761:	xor    eax,eax
  409763:	call   407040 <close@plt>
  409768:	xor    eax,eax
  40976a:	jmp    409806 <__swc_fn_585f006d_000111_6814119b+0x5b6>
  40976f:	mov    rax,rbx
  409772:	movsxd rdi,DWORD PTR [rax]
  409775:	mov    rsi,r12
  409778:	xor    eax,eax
  40977a:	call   4070f0 <ftruncate@plt>
  40977f:	test   eax,eax
  409781:	je     4097a5 <__swc_fn_585f006d_000111_6814119b+0x555>
  409783:	movsxd rdi,DWORD PTR [rbx]
  409786:	xor    eax,eax
  409788:	call   407040 <close@plt>
  40978d:	mov    rdi,r15
  409790:	xor    eax,eax
  409792:	call   4070b0 <closedir@plt>
  409797:	movsxd rdi,r13d
  40979a:	xor    eax,eax
  40979c:	call   407040 <close@plt>
  4097a1:	xor    eax,eax
  4097a3:	jmp    409806 <__swc_fn_585f006d_000111_6814119b+0x5b6>
  4097a5:	xor    edi,edi
  4097a7:	mov    rsi,r12
  4097aa:	mov    edx,0x3
  4097af:	mov    ecx,0x1
  4097b4:	mov    rax,rbx
  4097b7:	movsxd r8,DWORD PTR [rax]
  4097ba:	xor    r9d,r9d
  4097bd:	xor    eax,eax
  4097bf:	call   4070d0 <mmap@plt>
  4097c4:	mov    r12,rax
  4097c7:	cmp    rax,0xffffffffffffffff
  4097cb:	jne    4097ef <__swc_fn_585f006d_000111_6814119b+0x59f>
  4097cd:	movsxd rdi,DWORD PTR [rbx]
  4097d0:	xor    eax,eax
  4097d2:	call   407040 <close@plt>
  4097d7:	mov    rdi,r15
  4097da:	xor    eax,eax
  4097dc:	call   4070b0 <closedir@plt>
  4097e1:	movsxd rdi,r13d
  4097e4:	xor    eax,eax
  4097e6:	call   407040 <close@plt>
  4097eb:	xor    eax,eax
  4097ed:	jmp    409806 <__swc_fn_585f006d_000111_6814119b+0x5b6>
  4097ef:	mov    rdi,r15
  4097f2:	xor    eax,eax
  4097f4:	call   4070b0 <closedir@plt>
  4097f9:	movsxd rdi,r13d
  4097fc:	xor    eax,eax
  4097fe:	call   407040 <close@plt>
  409803:	mov    rax,r12
  409806:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40980f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  409818:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  409821:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40982a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  409833:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40983c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  409845:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40984e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  409857:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  409860:	add    rsp,0x170
  409867:	pop    r15
  409869:	pop    r14
  40986b:	pop    r13
  40986d:	pop    rsi
  40986e:	pop    rdi
  40986f:	pop    r12
  409871:	pop    rbx
  409872:	ret
	...

0000000000409880 <__swc_fn_585f006d_000114_5f48311c>:
  409880:	push   rsi
  409881:	push   rdi
  409882:	push   r12
  409884:	push   r13
  409886:	sub    rsp,0x8
  40988a:	mov    rsi,r8
  40988d:	mov    rdi,rcx
  409890:	mov    r12,rdx
  409893:	call   40d780 <__swc_fn_585f006d_000112_126150d1>
  409898:	mov    r13,rax
  40989b:	test   rax,rax
  40989e:	jne    4098ab <__swc_fn_585f006d_000114_5f48311c+0x2b>
  4098a0:	add    rsp,0x8
  4098a4:	pop    r13
  4098a6:	pop    r12
  4098a8:	pop    rdi
  4098a9:	pop    rsi
  4098aa:	ret
  4098ab:	mov    rcx,r13
  4098ae:	call   4113f0 <__swc_fn_585f006d_000137_8c07c14b>
  4098b3:	mov    rax,QWORD PTR [r13+0x8]
  4098b7:	test   rax,rax
  4098ba:	je     4098f9 <__swc_fn_585f006d_000114_5f48311c+0x79>
  4098bc:	nop    DWORD PTR [rax+0x0]
  4098c0:	lea    rcx,[rax+0x1000]
  4098c7:	cmp    rdi,rcx
  4098ca:	jne    4098f1 <__swc_fn_585f006d_000114_5f48311c+0x71>
  4098cc:	cmp    r12,0x1000
  4098d3:	jb     4098f1 <__swc_fn_585f006d_000114_5f48311c+0x71>
  4098d5:	test   sil,sil
  4098d8:	setne  cl
  4098db:	mov    BYTE PTR [rax+0x10],cl
  4098de:	mov    rcx,r13
  4098e1:	call   409de0 <__swc_fn_585f006d_000138_715e84ff>
  4098e6:	add    rsp,0x8
  4098ea:	pop    r13
  4098ec:	pop    r12
  4098ee:	pop    rdi
  4098ef:	pop    rsi
  4098f0:	ret
  4098f1:	mov    rax,QWORD PTR [rax]
  4098f4:	test   rax,rax
  4098f7:	jne    4098c0 <__swc_fn_585f006d_000114_5f48311c+0x40>
  4098f9:	mov    rcx,r13
  4098fc:	call   409de0 <__swc_fn_585f006d_000138_715e84ff>
  409901:	add    rsp,0x8
  409905:	pop    r13
  409907:	pop    r12
  409909:	pop    rdi
  40990a:	pop    rsi
  40990b:	ret
  40990c:	add    BYTE PTR [rax],al
	...

0000000000409910 <__swc_fn_585f006d_000117_ed2d8fed>:
  409910:	sub    rsp,0x8
  409914:	test   rcx,rcx
  409917:	jne    40991e <__swc_fn_585f006d_000117_ed2d8fed+0xe>
  409919:	add    rsp,0x8
  40991d:	ret
  40991e:	call   410f00 <__swc_fn_585f006d_000119_d3318640>
  409923:	add    rsp,0x8
  409927:	ret
	...

0000000000409930 <__swc_fn_585f006d_000120_2648f149>:
  409930:	push   r12
  409932:	push   r13
  409934:	push   r14
  409936:	push   rdi
  409937:	push   rsi
  409938:	sub    rsp,0xc0
  40993f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409945:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40994b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409951:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409957:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40995d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409963:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409969:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409972:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40997b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409984:	mov    r12,QWORD PTR [rcx]
  409987:	test   r12,r12
  40998a:	jne    40999c <__swc_fn_585f006d_000120_2648f149+0x6c>
  40998c:	add    rsp,0xc0
  409993:	pop    rsi
  409994:	pop    rdi
  409995:	pop    r14
  409997:	pop    r13
  409999:	pop    r12
  40999b:	ret
  40999c:	xor    r13d,r13d
  40999f:	mov    r14,QWORD PTR [rcx+0x8]
  4099a3:	cs nop WORD PTR [rax+rax*1+0x0]
  4099ad:	nop    DWORD PTR [rax]
  4099b0:	cmp    r13,r14
  4099b3:	jae    4099eb <__swc_fn_585f006d_000120_2648f149+0xbb>
  4099b5:	lea    rax,[r12+r13*1]
  4099b9:	mov    rcx,r14
  4099bc:	sub    rcx,r13
  4099bf:	mov    edi,0x1
  4099c4:	mov    rsi,rax
  4099c7:	mov    rdx,rcx
  4099ca:	xor    eax,eax
  4099cc:	call   407100 <write@plt>
  4099d1:	test   rax,rax
  4099d4:	jle    4099db <__swc_fn_585f006d_000120_2648f149+0xab>
  4099d6:	add    r13,rax
  4099d9:	jmp    4099b0 <__swc_fn_585f006d_000120_2648f149+0x80>
  4099db:	je     4099e9 <__swc_fn_585f006d_000120_2648f149+0xb9>
  4099dd:	xor    eax,eax
  4099df:	call   407030 <__errno_location@plt>
  4099e4:	cmp    DWORD PTR [rax],0x4
  4099e7:	je     4099b0 <__swc_fn_585f006d_000120_2648f149+0x80>
  4099e9:	jmp    4099eb <__swc_fn_585f006d_000120_2648f149+0xbb>
  4099eb:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4099f1:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4099f7:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4099fd:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409a03:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409a09:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409a0f:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409a15:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409a1e:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409a27:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409a30:	add    rsp,0xc0
  409a37:	pop    rsi
  409a38:	pop    rdi
  409a39:	pop    r14
  409a3b:	pop    r13
  409a3d:	pop    r12
  409a3f:	ret

0000000000409a40 <__swc_fn_585f006d_000123_4f256d58>:
  409a40:	push   rbx
  409a41:	push   r12
  409a43:	push   rdi
  409a44:	push   rsi
  409a45:	sub    rsp,0x4a8
  409a4c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  409a55:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  409a5e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  409a67:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  409a70:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  409a79:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  409a82:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  409a8b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  409a94:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  409a9d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  409aa6:	mov    rbx,rdx
  409aa9:	mov    r12d,ecx
  409aac:	vxorps xmm0,xmm0,xmm0
  409ab0:	xor    eax,eax
  409ab2:	cs nop WORD PTR [rax+rax*1+0x0]
  409abc:	nop    DWORD PTR [rax+0x0]
  409ac0:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  409ac6:	add    rax,0x10
  409aca:	cmp    rax,0x400
  409ad1:	jne    409ac0 <__swc_fn_585f006d_000123_4f256d58+0x80>
  409ad3:	lea    rdi,[rsp+0x8]
  409ad8:	mov    esi,0x80
  409add:	xor    eax,eax
  409adf:	call   407110 <backtrace@plt>
  409ae4:	test   eax,eax
  409ae6:	jle    409af5 <__swc_fn_585f006d_000123_4f256d58+0xb5>
  409ae8:	movsxd rax,eax
  409aeb:	lea    rcx,[r12+0x1]
  409af0:	cmp    rcx,rax
  409af3:	jb     409af9 <__swc_fn_585f006d_000123_4f256d58+0xb9>
  409af5:	xor    eax,eax
  409af7:	jmp    409b2a <__swc_fn_585f006d_000123_4f256d58+0xea>
  409af9:	mov    rcx,QWORD PTR [rbx+0x8]
  409afd:	sub    rax,r12
  409b00:	lea    rsi,[rax-0x1]
  409b04:	cmp    rcx,rsi
  409b07:	cmovbe rsi,rcx
  409b0b:	lea    eax,[r12+0x1]
  409b10:	lea    rax,[rsp+rax*8+0x8]
  409b15:	mov    rcx,QWORD PTR [rbx]
  409b18:	mov    rdx,rax
  409b1b:	lea    r8,[rsi*8+0x0]
  409b23:	call   40d760 <__swc_fn_585f006d_000109_7c204aac>
  409b28:	mov    eax,esi
  409b2a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  409b33:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  409b3c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  409b45:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  409b4e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  409b57:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  409b60:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  409b69:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  409b72:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  409b7b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  409b84:	add    rsp,0x4a8
  409b8b:	pop    rsi
  409b8c:	pop    rdi
  409b8d:	pop    r12
  409b8f:	pop    rbx
  409b90:	ret
	...

0000000000409ba0 <__swc_fn_585f006d_000126_fcd5a289>:
  409ba0:	mov    QWORD PTR [rcx],0x0
  409ba7:	ret
	...

0000000000409bb0 <__swc_fn_585f006d_000129_4bbe3f14>:
  409bb0:	push   rdi
  409bb1:	push   rsi
  409bb2:	sub    rsp,0xa8
  409bb9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409bbf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409bc5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409bcb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409bd1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409bd7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409bdd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409be3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409be9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409bf2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409bfb:	mov    edi,ecx
  409bfd:	mov    rsi,rdx
  409c00:	xor    eax,eax
  409c02:	call   407120 <pthread_setspecific@plt>
  409c07:	test   eax,eax
  409c09:	sete   al
  409c0c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409c12:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409c18:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409c1e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409c24:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409c2a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409c30:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409c36:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409c3c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409c45:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409c4e:	add    rsp,0xa8
  409c55:	pop    rsi
  409c56:	pop    rdi
  409c57:	ret
	...

0000000000409c60 <__swc_fn_585f006d_000132_5f757033>:
  409c60:	push   rdi
  409c61:	push   rsi
  409c62:	sub    rsp,0xa8
  409c69:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409c6f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409c75:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409c7b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409c81:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409c87:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409c8d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409c93:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409c99:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409ca2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409cab:	test   rcx,rcx
  409cae:	je     409cc1 <__swc_fn_585f006d_000132_5f757033+0x61>
  409cb0:	lea    rax,[rcx-0x1]
  409cb4:	mov    eax,eax
  409cb6:	mov    edi,eax
  409cb8:	xor    eax,eax
  409cba:	call   407000 <pthread_getspecific@plt>
  409cbf:	jmp    409cc3 <__swc_fn_585f006d_000132_5f757033+0x63>
  409cc1:	xor    eax,eax
  409cc3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409cc9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409ccf:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409cd5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409cdb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409ce1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409ce7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409ced:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409cf3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409cfc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409d05:	add    rsp,0xa8
  409d0c:	pop    rsi
  409d0d:	pop    rdi
  409d0e:	ret
	...

0000000000409d10 <__swc_fn_585f006d_000135_07d76562>:
  409d10:	push   rdi
  409d11:	push   rsi
  409d12:	sub    rsp,0xb8
  409d19:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409d1f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409d25:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409d2b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409d31:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409d37:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409d3d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409d43:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409d4c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409d55:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409d5e:	vxorps xmm0,xmm0,xmm0
  409d62:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409d68:	mov    edi,0x1
  409d6d:	lea    rsi,[rsp+0x8]
  409d72:	xor    eax,eax
  409d74:	call   407130 <clock_gettime@plt>
  409d79:	mov    rax,QWORD PTR [rsp+0x8]
  409d7e:	imul   rax,rax,0x3b9aca00
  409d85:	add    rax,QWORD PTR [rsp+0x10]
  409d8a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409d90:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409d96:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409d9c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409da2:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409da8:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409dae:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409db4:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409dbd:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409dc6:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409dcf:	add    rsp,0xb8
  409dd6:	pop    rsi
  409dd7:	pop    rdi
  409dd8:	ret
  409dd9:	add    BYTE PTR [rax],al
  409ddb:	add    BYTE PTR [rax],al
  409ddd:	add    BYTE PTR [rax],al
	...

0000000000409de0 <__swc_fn_585f006d_000138_715e84ff>:
  409de0:	sub    rsp,0x8
  409de4:	xor    eax,eax
  409de6:	mov    DWORD PTR [rcx],eax
  409de8:	mov    edx,0x7fffffff
  409ded:	call   40de60 <__swc_fn_585f006d_000136_865f5106>
  409df2:	add    rsp,0x8
  409df6:	ret
	...

0000000000409e00 <__swc_fn_585f006d_000141_519fdf94>:
  409e00:	push   rdi
  409e01:	push   rsi
  409e02:	sub    rsp,0xb8
  409e09:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409e0f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409e15:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409e1b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409e21:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409e27:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409e2d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409e33:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409e3c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409e45:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409e4e:	mov    edi,0x1
  409e53:	xor    eax,eax
  409e55:	call   407140 <__x86_get_cpuid_feature_leaf@plt>
  409e5a:	mov    eax,DWORD PTR [rax+0x14]
  409e5d:	and    eax,0x20
  409e60:	setne  al
  409e63:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409e69:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409e6f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409e75:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409e7b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409e81:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409e87:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409e8d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409e96:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409e9f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409ea8:	add    rsp,0xb8
  409eaf:	pop    rsi
  409eb0:	pop    rdi
  409eb1:	ret
	...

0000000000409ec0 <__swc_fn_585f006d_000144_d5d4d43f>:
  409ec0:	push   rsi
  409ec1:	push   rdi
  409ec2:	push   r12
  409ec4:	push   r13
  409ec6:	push   r14
  409ec8:	push   r15
  409eca:	cmp    rdx,0x40
  409ece:	jae    409edd <__swc_fn_585f006d_000144_d5d4d43f+0x1d>
  409ed0:	xor    eax,eax
  409ed2:	pop    r15
  409ed4:	pop    r14
  409ed6:	pop    r13
  409ed8:	pop    r12
  409eda:	pop    rdi
  409edb:	pop    rsi
  409edc:	ret
  409edd:	cmp    BYTE PTR [rcx],0x7f
  409ee0:	jne    409f24 <__swc_fn_585f006d_000144_d5d4d43f+0x64>
  409ee2:	movzx  eax,BYTE PTR [rcx+0x1]
  409ee6:	cmp    eax,0x45
  409ee9:	setne  al
  409eec:	jne    409f20 <__swc_fn_585f006d_000144_d5d4d43f+0x60>
  409eee:	movzx  eax,BYTE PTR [rcx+0x2]
  409ef2:	cmp    eax,0x4c
  409ef5:	setne  al
  409ef8:	jne    409f20 <__swc_fn_585f006d_000144_d5d4d43f+0x60>
  409efa:	movzx  eax,BYTE PTR [rcx+0x3]
  409efe:	cmp    eax,0x46
  409f01:	setne  al
  409f04:	jne    409f20 <__swc_fn_585f006d_000144_d5d4d43f+0x60>
  409f06:	cmp    BYTE PTR [rcx+0x4],0x2
  409f0a:	setne  al
  409f0d:	jne    409f20 <__swc_fn_585f006d_000144_d5d4d43f+0x60>
  409f0f:	cmp    BYTE PTR [rcx+0x5],0x1
  409f13:	setne  al
  409f16:	jne    409f20 <__swc_fn_585f006d_000144_d5d4d43f+0x60>
  409f18:	cmp    WORD PTR [rcx+0x12],0x3e
  409f1d:	setne  al
  409f20:	test   al,al
  409f22:	je     409f31 <__swc_fn_585f006d_000144_d5d4d43f+0x71>
  409f24:	xor    eax,eax
  409f26:	pop    r15
  409f28:	pop    r14
  409f2a:	pop    r13
  409f2c:	pop    r12
  409f2e:	pop    rdi
  409f2f:	pop    rsi
  409f30:	ret
  409f31:	cmp    WORD PTR [rcx+0x3a],0x40
  409f36:	jne    409f51 <__swc_fn_585f006d_000144_d5d4d43f+0x91>
  409f38:	cmp    WORD PTR [rcx+0x3c],0x0
  409f3d:	sete   al
  409f40:	je     409f4d <__swc_fn_585f006d_000144_d5d4d43f+0x8d>
  409f42:	mov    ax,WORD PTR [rcx+0x3c]
  409f46:	cmp    WORD PTR [rcx+0x3e],ax
  409f4a:	setae  al
  409f4d:	test   al,al
  409f4f:	je     409f5e <__swc_fn_585f006d_000144_d5d4d43f+0x9e>
  409f51:	xor    eax,eax
  409f53:	pop    r15
  409f55:	pop    r14
  409f57:	pop    r13
  409f59:	pop    r12
  409f5b:	pop    rdi
  409f5c:	pop    rsi
  409f5d:	ret
  409f5e:	movzx  eax,WORD PTR [rcx+0x3c]
  409f62:	shl    rax,0x6
  409f66:	cmp    rax,rdx
  409f69:	ja     409f77 <__swc_fn_585f006d_000144_d5d4d43f+0xb7>
  409f6b:	mov    r9,rdx
  409f6e:	sub    r9,rax
  409f71:	cmp    QWORD PTR [rcx+0x28],r9
  409f75:	jbe    409f84 <__swc_fn_585f006d_000144_d5d4d43f+0xc4>
  409f77:	xor    eax,eax
  409f79:	pop    r15
  409f7b:	pop    r14
  409f7d:	pop    r13
  409f7f:	pop    r12
  409f81:	pop    rdi
  409f82:	pop    rsi
  409f83:	ret
  409f84:	mov    rax,QWORD PTR [rcx+0x28]
  409f88:	add    rax,rcx
  409f8b:	movzx  r9d,WORD PTR [rcx+0x3e]
  409f90:	lea    r9,[r9*8+0x0]
  409f98:	lea    r10,[rax+r9*8]
  409f9c:	cmp    QWORD PTR [r10+0x20],rdx
  409fa0:	ja     409fc2 <__swc_fn_585f006d_000144_d5d4d43f+0x102>
  409fa2:	mov    r11,rdx
  409fa5:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  409faa:	cmp    QWORD PTR [r10+0x18],r11
  409fae:	seta   r9b
  409fb2:	ja     409fbd <__swc_fn_585f006d_000144_d5d4d43f+0xfd>
  409fb4:	cmp    QWORD PTR [r10+0x20],0x9
  409fb9:	setb   r9b
  409fbd:	test   r9b,r9b
  409fc0:	je     409fcf <__swc_fn_585f006d_000144_d5d4d43f+0x10f>
  409fc2:	xor    eax,eax
  409fc4:	pop    r15
  409fc6:	pop    r14
  409fc8:	pop    r13
  409fca:	pop    r12
  409fcc:	pop    rdi
  409fcd:	pop    rsi
  409fce:	ret
  409fcf:	movzx  r9d,WORD PTR [rcx+0x3c]
  409fd4:	xor    r11d,r11d
  409fd7:	test   r9,r9
  409fda:	jbe    40a0d5 <__swc_fn_585f006d_000144_d5d4d43f+0x215>
  409fe0:	mov    rsi,QWORD PTR [r10+0x20]
  409fe4:	sub    rsi,0x9
  409fe8:	cs nop WORD PTR [rax+rax*1+0x0]
  409ff2:	cs nop WORD PTR [rax+rax*1+0x0]
  409ffc:	nop    DWORD PTR [rax+0x0]
  40a000:	movzx  edi,r11w
  40a004:	lea    rdi,[rdi*8+0x0]
  40a00c:	lea    r12,[rax+rdi*8]
  40a010:	rex mov edi,DWORD PTR [rax+rdi*8]
  40a014:	cmp    rdi,rsi
  40a017:	ja     40a0c8 <__swc_fn_585f006d_000144_d5d4d43f+0x208>
  40a01d:	mov    r13,QWORD PTR [r10+0x18]
  40a021:	add    r13,rdi
  40a024:	lea    rdi,[rcx+r13*1]
  40a028:	lea    r13,[rip+0x85d1]        # 412600 <__swc_rdata_base_585f006d+0x4f0>
  40a02f:	movabs r14,0x676264676177732e
  40a039:	cmp    QWORD PTR [rdi],r14
  40a03c:	jne    40a045 <__swc_fn_585f006d_000144_d5d4d43f+0x185>
  40a03e:	rex cmp BYTE PTR [rdi+0x8],0x0
  40a043:	je     40a072 <__swc_fn_585f006d_000144_d5d4d43f+0x1b2>
  40a045:	cs nop WORD PTR [rax+rax*1+0x0]
  40a04f:	nop
  40a050:	movzx  r14d,BYTE PTR [rdi]
  40a054:	movzx  r15d,BYTE PTR [r13+0x0]
  40a059:	cmp    r14,r15
  40a05c:	jne    40a068 <__swc_fn_585f006d_000144_d5d4d43f+0x1a8>
  40a05e:	add    rdi,0x1
  40a062:	add    r13,0x1
  40a066:	jmp    40a050 <__swc_fn_585f006d_000144_d5d4d43f+0x190>
  40a068:	mov    rdi,r14
  40a06b:	sub    rdi,r15
  40a06e:	test   edi,edi
  40a070:	jne    40a0c8 <__swc_fn_585f006d_000144_d5d4d43f+0x208>
  40a072:	cmp    DWORD PTR [r12+0x4],0x1
  40a078:	jne    40a0a0 <__swc_fn_585f006d_000144_d5d4d43f+0x1e0>
  40a07a:	cmp    QWORD PTR [r12+0x20],0x10
  40a080:	setb   al
  40a083:	jb     40a09c <__swc_fn_585f006d_000144_d5d4d43f+0x1dc>
  40a085:	cmp    QWORD PTR [r12+0x20],rdx
  40a08a:	seta   al
  40a08d:	ja     40a09c <__swc_fn_585f006d_000144_d5d4d43f+0x1dc>
  40a08f:	sub    rdx,QWORD PTR [r12+0x20]
  40a094:	cmp    QWORD PTR [r12+0x18],rdx
  40a099:	seta   al
  40a09c:	test   al,al
  40a09e:	je     40a0ad <__swc_fn_585f006d_000144_d5d4d43f+0x1ed>
  40a0a0:	xor    eax,eax
  40a0a2:	pop    r15
  40a0a4:	pop    r14
  40a0a6:	pop    r13
  40a0a8:	pop    r12
  40a0aa:	pop    rdi
  40a0ab:	pop    rsi
  40a0ac:	ret
  40a0ad:	mov    rax,QWORD PTR [r12+0x20]
  40a0b2:	mov    QWORD PTR [r8],rax
  40a0b5:	mov    rax,QWORD PTR [r12+0x18]
  40a0ba:	add    rax,rcx
  40a0bd:	pop    r15
  40a0bf:	pop    r14
  40a0c1:	pop    r13
  40a0c3:	pop    r12
  40a0c5:	pop    rdi
  40a0c6:	pop    rsi
  40a0c7:	ret
  40a0c8:	add    r11,0x1
  40a0cc:	cmp    r11,r9
  40a0cf:	jb     40a000 <__swc_fn_585f006d_000144_d5d4d43f+0x140>
  40a0d5:	xor    eax,eax
  40a0d7:	pop    r15
  40a0d9:	pop    r14
  40a0db:	pop    r13
  40a0dd:	pop    r12
  40a0df:	pop    rdi
  40a0e0:	pop    rsi
  40a0e1:	ret
	...

000000000040a0f0 <__swc_fn_585f006d_000147_d7edc04f>:
  40a0f0:	push   rdi
  40a0f1:	push   rsi
  40a0f2:	sub    rsp,0xa8
  40a0f9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40a0ff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40a105:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40a10b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40a111:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40a117:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40a11d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40a123:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40a129:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a132:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a13b:	mov    rdi,rcx
  40a13e:	xor    eax,eax
  40a140:	call   407150 <free@plt>
  40a145:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a14b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a151:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a157:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a15d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a163:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a169:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a16f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a175:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a17e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a187:	add    rsp,0xa8
  40a18e:	pop    rsi
  40a18f:	pop    rdi
  40a190:	ret
	...

000000000040a1a0 <__swc_fn_585f006d_000150_6203dca2>:
  40a1a0:	push   rbx
  40a1a1:	push   rsi
  40a1a2:	push   rdi
  40a1a3:	push   r12
  40a1a5:	push   r13
  40a1a7:	push   r15
  40a1a9:	sub    rsp,0x4e8
  40a1b0:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  40a1b9:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  40a1c2:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  40a1cb:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  40a1d4:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  40a1dd:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  40a1e6:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  40a1ef:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  40a1f8:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  40a201:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  40a20a:	mov    rbx,QWORD PTR [rcx]
  40a20d:	mov    rcx,QWORD PTR [rcx+0x8]
  40a211:	mov    rsi,rcx
  40a214:	xor    edi,edi
  40a216:	vmovsd xmm6,QWORD PTR [rip+0x8442]        # 412660 <__swc_rdata_base_585f006d+0x550>
  40a21e:	vmovsd xmm7,QWORD PTR [rip+0x8443]        # 412669 <__swc_rdata_base_585f006d+0x559>
  40a226:	vmovsd xmm8,QWORD PTR [rip+0x8444]        # 412672 <__swc_rdata_base_585f006d+0x562>
  40a22e:	vmovsd xmm9,QWORD PTR [rip+0x8445]        # 41267b <__swc_rdata_base_585f006d+0x56b>
  40a236:	vmovsd xmm10,QWORD PTR [rip+0x8446]        # 412684 <__swc_rdata_base_585f006d+0x574>
  40a23e:	vmovups xmm11,xmm6
  40a242:	vmovsd QWORD PTR [rsp+0x418],xmm7
  40a24b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  40a254:	vmovsd QWORD PTR [rsp+0x428],xmm9
  40a25d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  40a266:	vmovsd xmm15,QWORD PTR [rip+0x841f]        # 41268d <__swc_rdata_base_585f006d+0x57d>
  40a26e:	vmovups xmm14,xmm15
  40a273:	vmovups xmm0,xmm9
  40a278:	vmovsd QWORD PTR [rsp+0x438],xmm15
  40a281:	vmovups xmm13,xmm8
  40a286:	vmovsd QWORD PTR [rsp+0x440],xmm15
  40a28f:	test   rsi,rsi
  40a292:	je     40b283 <__swc_fn_585f006d_000150_6203dca2+0x10e3>
  40a298:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2a2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2ac:	nop    DWORD PTR [rax+0x0]
  40a2b0:	lea    rcx,[rdi+rdi*1]
  40a2b4:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  40a2b9:	vpshufd xmm3,xmm2,0xee
  40a2be:	vmovq  rcx,xmm3
  40a2c3:	test   rcx,rcx
  40a2c6:	je     40a2dc <__swc_fn_585f006d_000150_6203dca2+0x13c>
  40a2c8:	test   DWORD PTR [rcx+0x28],0x400000
  40a2cf:	je     40a2dc <__swc_fn_585f006d_000150_6203dca2+0x13c>
  40a2d1:	mov    rdx,QWORD PTR [rcx+0x30]
  40a2d5:	test   rdx,rdx
  40a2d8:	cmovne rcx,rdx
  40a2dc:	test   DWORD PTR [rcx+0x28],0x1000
  40a2e3:	je     40a304 <__swc_fn_585f006d_000150_6203dca2+0x164>
  40a2e5:	mov    rdx,QWORD PTR [rcx+0x40]
  40a2e9:	mov    rcx,rdx
  40a2ec:	vmovq  r8,xmm2
  40a2f1:	mov    r8,QWORD PTR [r8]
  40a2f4:	mov    QWORD PTR [rsp+0x60],r8
  40a2f9:	mov    QWORD PTR [rsp+0x68],rdx
  40a2fe:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  40a304:	test   BYTE PTR [rcx+0x28],0x1
  40a308:	jne    40a310 <__swc_fn_585f006d_000150_6203dca2+0x170>
  40a30a:	vmovups xmm12,xmm0
  40a30e:	jmp    40a32a <__swc_fn_585f006d_000150_6203dca2+0x18a>
  40a310:	vmovq  rax,xmm2
  40a315:	mov    rax,QWORD PTR [rax]
  40a318:	lea    rcx,[rax+0x10]
  40a31c:	vmovups xmm12,xmm0
  40a320:	call   409930 <__swc_fn_585f006d_000120_2648f149>
  40a325:	jmp    40b265 <__swc_fn_585f006d_000150_6203dca2+0x10c5>
  40a32a:	test   DWORD PTR [rcx+0x28],0x400
  40a331:	je     40a392 <__swc_fn_585f006d_000150_6203dca2+0x1f2>
  40a333:	vmovq  rax,xmm2
  40a338:	mov    rax,QWORD PTR [rax]
  40a33b:	xor    ecx,ecx
  40a33d:	test   rax,rax
  40a340:	je     40a370 <__swc_fn_585f006d_000150_6203dca2+0x1d0>
  40a342:	mov    rdx,rax
  40a345:	mov    r8b,BYTE PTR [rdx]
  40a348:	test   r8b,r8b
  40a34b:	je     40a370 <__swc_fn_585f006d_000150_6203dca2+0x1d0>
  40a34d:	cs nop WORD PTR [rax+rax*1+0x0]
  40a357:	nop    WORD PTR [rax+rax*1+0x0]
  40a360:	add    rdx,0x1
  40a364:	add    rcx,0x1
  40a368:	mov    r8b,BYTE PTR [rdx]
  40a36b:	test   r8b,r8b
  40a36e:	jne    40a360 <__swc_fn_585f006d_000150_6203dca2+0x1c0>
  40a370:	mov    QWORD PTR [rsp+0x88],rax
  40a378:	mov    QWORD PTR [rsp+0x90],rcx
  40a380:	lea    rcx,[rsp+0x88]
  40a388:	call   409930 <__swc_fn_585f006d_000120_2648f149>
  40a38d:	jmp    40b265 <__swc_fn_585f006d_000150_6203dca2+0x10c5>
  40a392:	cmp    BYTE PTR [rcx+0x2c],0x6
  40a396:	jne    40a3ad <__swc_fn_585f006d_000150_6203dca2+0x20d>
  40a398:	vmovq  rax,xmm2
  40a39d:	mov    rax,QWORD PTR [rax]
  40a3a0:	mov    rcx,rax
  40a3a3:	call   40e330 <__swc_fn_585f006d_000148_43c96957>
  40a3a8:	jmp    40b265 <__swc_fn_585f006d_000150_6203dca2+0x10c5>
  40a3ad:	cmp    BYTE PTR [rcx+0x2c],0x1
  40a3b1:	jne    40b259 <__swc_fn_585f006d_000150_6203dca2+0x10b9>
  40a3b7:	vmovq  rdx,xmm2
  40a3bc:	mov    cl,BYTE PTR [rcx+0x40]
  40a3bf:	cmp    cl,0x7
  40a3c2:	jb     40a405 <__swc_fn_585f006d_000150_6203dca2+0x265>
  40a3c4:	je     40a478 <__swc_fn_585f006d_000150_6203dca2+0x2d8>
  40a3ca:	cmp    cl,0x8
  40a3cd:	je     40a484 <__swc_fn_585f006d_000150_6203dca2+0x2e4>
  40a3d3:	cmp    cl,0x9
  40a3d6:	je     40a49d <__swc_fn_585f006d_000150_6203dca2+0x2fd>
  40a3dc:	cmp    cl,0xa
  40a3df:	je     40ab64 <__swc_fn_585f006d_000150_6203dca2+0x9c4>
  40a3e5:	cmp    cl,0xb
  40a3e8:	je     40b22b <__swc_fn_585f006d_000150_6203dca2+0x108b>
  40a3ee:	cmp    cl,0xc
  40a3f1:	je     40a491 <__swc_fn_585f006d_000150_6203dca2+0x2f1>
  40a3f7:	cmp    cl,0xd
  40a3fa:	je     40b221 <__swc_fn_585f006d_000150_6203dca2+0x1081>
  40a400:	jmp    40b24b <__swc_fn_585f006d_000150_6203dca2+0x10ab>
  40a405:	cmp    cl,0x1
  40a408:	je     40a428 <__swc_fn_585f006d_000150_6203dca2+0x288>
  40a40a:	cmp    cl,0x2
  40a40d:	je     40a436 <__swc_fn_585f006d_000150_6203dca2+0x296>
  40a40f:	cmp    cl,0x3
  40a412:	je     40a444 <__swc_fn_585f006d_000150_6203dca2+0x2a4>
  40a414:	cmp    cl,0x4
  40a417:	je     40a451 <__swc_fn_585f006d_000150_6203dca2+0x2b1>
  40a419:	cmp    cl,0x5
  40a41c:	je     40a45e <__swc_fn_585f006d_000150_6203dca2+0x2be>
  40a41e:	cmp    cl,0x6
  40a421:	je     40a46b <__swc_fn_585f006d_000150_6203dca2+0x2cb>
  40a423:	jmp    40b24b <__swc_fn_585f006d_000150_6203dca2+0x10ab>
  40a428:	movsx  rcx,BYTE PTR [rdx]
  40a42c:	call   4115e0 <__swc_fn_585f006d_000149_2eb804cc>
  40a431:	jmp    40b265 <__swc_fn_585f006d_000150_6203dca2+0x10c5>
  40a436:	movsx  rcx,WORD PTR [rdx]
  40a43a:	call   4115e0 <__swc_fn_585f006d_000149_2eb804cc>
  40a43f:	jmp    40b265 <__swc_fn_585f006d_000150_6203dca2+0x10c5>
  40a444:	movsxd rcx,DWORD PTR [rdx]
  40a447:	call   4115e0 <__swc_fn_585f006d_000149_2eb804cc>
  40a44c:	jmp    40b265 <__swc_fn_585f006d_000150_6203dca2+0x10c5>
  40a451:	mov    rcx,QWORD PTR [rdx]
  40a454:	call   4115e0 <__swc_fn_585f006d_000149_2eb804cc>
  40a459:	jmp    40b265 <__swc_fn_585f006d_000150_6203dca2+0x10c5>
  40a45e:	movzx  ecx,BYTE PTR [rdx]
  40a461:	call   40e330 <__swc_fn_585f006d_000148_43c96957>
  40a466:	jmp    40b265 <__swc_fn_585f006d_000150_6203dca2+0x10c5>
  40a46b:	movzx  ecx,WORD PTR [rdx]
  40a46e:	call   40e330 <__swc_fn_585f006d_000148_43c96957>
  40a473:	jmp    40b265 <__swc_fn_585f006d_000150_6203dca2+0x10c5>
  40a478:	mov    ecx,DWORD PTR [rdx]
  40a47a:	call   40e330 <__swc_fn_585f006d_000148_43c96957>
  40a47f:	jmp    40b265 <__swc_fn_585f006d_000150_6203dca2+0x10c5>
  40a484:	mov    rcx,QWORD PTR [rdx]
  40a487:	call   40e330 <__swc_fn_585f006d_000148_43c96957>
  40a48c:	jmp    40b265 <__swc_fn_585f006d_000150_6203dca2+0x10c5>
  40a491:	mov    ecx,DWORD PTR [rdx]
  40a493:	call   40e330 <__swc_fn_585f006d_000148_43c96957>
  40a498:	jmp    40b265 <__swc_fn_585f006d_000150_6203dca2+0x10c5>
  40a49d:	lea    rcx,[rsp+0xa8]
  40a4a5:	vxorps xmm0,xmm0,xmm0
  40a4a9:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  40a4b2:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  40a4bb:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  40a4c4:	vzeroupper
  40a4c7:	mov    DWORD PTR [rsp+0x108],0x0
  40a4d2:	vxorpd xmm0,xmm0,xmm0
  40a4d6:	vmovss xmm1,DWORD PTR [rdx]
  40a4da:	vcvtss2sd xmm0,xmm0,xmm1
  40a4de:	vmovsd xmm1,xmm1,xmm0
  40a4e2:	vcomisd xmm0,xmm0
  40a4e6:	setne  dl
  40a4e9:	movzx  edx,dl
  40a4ec:	setp   r8b
  40a4f0:	movzx  r8d,r8b
  40a4f4:	or     edx,r8d
  40a4f7:	test   dl,dl
  40a4f9:	je     40a506 <__swc_fn_585f006d_000150_6203dca2+0x366>
  40a4fb:	mov    DWORD PTR [rcx],0x6e616e
  40a501:	jmp    40aaf8 <__swc_fn_585f006d_000150_6203dca2+0x958>
  40a506:	vcomisd xmm1,xmm6
  40a50a:	ja     40a512 <__swc_fn_585f006d_000150_6203dca2+0x372>
  40a50c:	vcomisd xmm7,xmm1
  40a510:	jbe    40a536 <__swc_fn_585f006d_000150_6203dca2+0x396>
  40a512:	vxorpd xmm0,xmm0,xmm0
  40a516:	vcomisd xmm0,xmm1
  40a51a:	jbe    40a52b <__swc_fn_585f006d_000150_6203dca2+0x38b>
  40a51c:	mov    DWORD PTR [rcx],0x666e692d
  40a522:	mov    BYTE PTR [rcx+0x4],0x0
  40a526:	jmp    40aaf8 <__swc_fn_585f006d_000150_6203dca2+0x958>
  40a52b:	mov    DWORD PTR [rcx],0x666e69
  40a531:	jmp    40aaf8 <__swc_fn_585f006d_000150_6203dca2+0x958>
  40a536:	vcomisd xmm1,xmm8
  40a53b:	jae    40a547 <__swc_fn_585f006d_000150_6203dca2+0x3a7>
  40a53d:	vcomisd xmm9,xmm1
  40a541:	jbe    40a8be <__swc_fn_585f006d_000150_6203dca2+0x71e>
  40a547:	vmovups xmm0,xmm1
  40a54b:	vxorpd xmm2,xmm2,xmm2
  40a54f:	vcomisd xmm2,xmm1
  40a553:	jbe    40a563 <__swc_fn_585f006d_000150_6203dca2+0x3c3>
  40a555:	vmovsd xmm1,xmm1,xmm0
  40a559:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x80bf]        # 412620 <__swc_rdata_base_585f006d+0x510>
  40a561:	jmp    40a567 <__swc_fn_585f006d_000150_6203dca2+0x3c7>
  40a563:	vmovsd xmm1,xmm1,xmm0
  40a567:	xor    r8d,r8d
  40a56a:	vcomisd xmm1,xmm15
  40a56f:	jb     40a590 <__swc_fn_585f006d_000150_6203dca2+0x3f0>
  40a571:	cs nop WORD PTR [rax+rax*1+0x0]
  40a57b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a580:	vdivsd xmm1,xmm1,xmm15
  40a585:	add    r8,0x1
  40a589:	vcomisd xmm1,xmm15
  40a58e:	jae    40a580 <__swc_fn_585f006d_000150_6203dca2+0x3e0>
  40a590:	mov    r9,rcx
  40a593:	vxorpd xmm2,xmm2,xmm2
  40a597:	vcomisd xmm2,xmm0
  40a59b:	jbe    40a5a4 <__swc_fn_585f006d_000150_6203dca2+0x404>
  40a59d:	mov    BYTE PTR [rcx],0x2d
  40a5a0:	lea    r9,[rcx+0x1]
  40a5a4:	vcvttsd2si rdx,xmm1
  40a5a9:	mov    r10b,dl
  40a5ac:	add    r10b,0x30
  40a5b0:	mov    BYTE PTR [r9],r10b
  40a5b3:	vxorpd xmm0,xmm0,xmm0
  40a5b7:	movzx  edx,dl
  40a5ba:	vcvtsi2sd xmm0,xmm0,rdx
  40a5bf:	vsubsd xmm0,xmm1,xmm0
  40a5c3:	vmulsd xmm1,xmm0,xmm15
  40a5c8:	mov    BYTE PTR [r9+0x1],0x2e
  40a5cd:	vcvttsd2si rdx,xmm1
  40a5d2:	mov    r10b,dl
  40a5d5:	add    r10b,0x30
  40a5d9:	mov    BYTE PTR [r9+0x2],r10b
  40a5dd:	vxorpd xmm0,xmm0,xmm0
  40a5e1:	movzx  edx,dl
  40a5e4:	vcvtsi2sd xmm0,xmm0,rdx
  40a5e9:	vsubsd xmm0,xmm1,xmm0
  40a5ed:	vmulsd xmm1,xmm0,xmm15
  40a5f2:	vcvttsd2si rdx,xmm1
  40a5f7:	mov    r10b,dl
  40a5fa:	add    r10b,0x30
  40a5fe:	mov    BYTE PTR [r9+0x3],r10b
  40a602:	vxorpd xmm0,xmm0,xmm0
  40a606:	movzx  edx,dl
  40a609:	vcvtsi2sd xmm0,xmm0,rdx
  40a60e:	vsubsd xmm0,xmm1,xmm0
  40a612:	vmulsd xmm1,xmm0,xmm15
  40a617:	vcvttsd2si rdx,xmm1
  40a61c:	mov    r10b,dl
  40a61f:	add    r10b,0x30
  40a623:	mov    BYTE PTR [r9+0x4],r10b
  40a627:	vxorpd xmm0,xmm0,xmm0
  40a62b:	movzx  edx,dl
  40a62e:	vcvtsi2sd xmm0,xmm0,rdx
  40a633:	vsubsd xmm0,xmm1,xmm0
  40a637:	vmulsd xmm1,xmm0,xmm15
  40a63c:	vcvttsd2si rdx,xmm1
  40a641:	mov    r10b,dl
  40a644:	add    r10b,0x30
  40a648:	mov    BYTE PTR [r9+0x5],r10b
  40a64c:	vxorpd xmm0,xmm0,xmm0
  40a650:	movzx  edx,dl
  40a653:	vcvtsi2sd xmm0,xmm0,rdx
  40a658:	vsubsd xmm0,xmm1,xmm0
  40a65c:	vmulsd xmm1,xmm0,xmm15
  40a661:	vcvttsd2si rdx,xmm1
  40a666:	mov    r10b,dl
  40a669:	add    r10b,0x30
  40a66d:	mov    BYTE PTR [r9+0x6],r10b
  40a671:	vxorpd xmm0,xmm0,xmm0
  40a675:	movzx  edx,dl
  40a678:	vcvtsi2sd xmm0,xmm0,rdx
  40a67d:	vsubsd xmm0,xmm1,xmm0
  40a681:	vmulsd xmm1,xmm0,xmm15
  40a686:	vcvttsd2si rdx,xmm1
  40a68b:	mov    r10b,dl
  40a68e:	add    r10b,0x30
  40a692:	mov    BYTE PTR [r9+0x7],r10b
  40a696:	vxorpd xmm0,xmm0,xmm0
  40a69a:	movzx  edx,dl
  40a69d:	vcvtsi2sd xmm0,xmm0,rdx
  40a6a2:	vsubsd xmm0,xmm1,xmm0
  40a6a6:	vmulsd xmm1,xmm0,xmm15
  40a6ab:	vcvttsd2si rdx,xmm1
  40a6b0:	mov    r10b,dl
  40a6b3:	add    r10b,0x30
  40a6b7:	mov    BYTE PTR [r9+0x8],r10b
  40a6bb:	vxorpd xmm0,xmm0,xmm0
  40a6bf:	movzx  edx,dl
  40a6c2:	vcvtsi2sd xmm0,xmm0,rdx
  40a6c7:	vsubsd xmm0,xmm1,xmm0
  40a6cb:	vmulsd xmm1,xmm0,xmm15
  40a6d0:	vcvttsd2si rdx,xmm1
  40a6d5:	mov    r10b,dl
  40a6d8:	add    r10b,0x30
  40a6dc:	mov    BYTE PTR [r9+0x9],r10b
  40a6e0:	vxorpd xmm0,xmm0,xmm0
  40a6e4:	movzx  edx,dl
  40a6e7:	vcvtsi2sd xmm0,xmm0,rdx
  40a6ec:	vsubsd xmm0,xmm1,xmm0
  40a6f0:	vmulsd xmm1,xmm0,xmm15
  40a6f5:	vcvttsd2si rdx,xmm1
  40a6fa:	mov    r10b,dl
  40a6fd:	add    r10b,0x30
  40a701:	mov    BYTE PTR [r9+0xa],r10b
  40a705:	vxorpd xmm0,xmm0,xmm0
  40a709:	movzx  edx,dl
  40a70c:	vcvtsi2sd xmm0,xmm0,rdx
  40a711:	vsubsd xmm0,xmm1,xmm0
  40a715:	vmulsd xmm1,xmm0,xmm15
  40a71a:	vcvttsd2si rdx,xmm1
  40a71f:	mov    r10b,dl
  40a722:	add    r10b,0x30
  40a726:	mov    BYTE PTR [r9+0xb],r10b
  40a72a:	lea    r10,[r9+0x4]
  40a72e:	vxorpd xmm0,xmm0,xmm0
  40a732:	movzx  edx,dl
  40a735:	vcvtsi2sd xmm0,xmm0,rdx
  40a73a:	vsubsd xmm0,xmm1,xmm0
  40a73e:	vmulsd xmm1,xmm0,xmm15
  40a743:	vcvttsd2si rdx,xmm1
  40a748:	mov    r11b,dl
  40a74b:	add    r11b,0x30
  40a74f:	mov    BYTE PTR [r9+0xc],r11b
  40a753:	vxorpd xmm0,xmm0,xmm0
  40a757:	movzx  edx,dl
  40a75a:	vcvtsi2sd xmm0,xmm0,rdx
  40a75f:	vsubsd xmm0,xmm1,xmm0
  40a763:	vmulsd xmm1,xmm0,xmm15
  40a768:	vcvttsd2si rdx,xmm1
  40a76d:	mov    r11b,dl
  40a770:	add    r11b,0x30
  40a774:	mov    BYTE PTR [r9+0xd],r11b
  40a778:	lea    r10,[r10+0x2]
  40a77c:	vxorpd xmm0,xmm0,xmm0
  40a780:	movzx  edx,dl
  40a783:	vcvtsi2sd xmm0,xmm0,rdx
  40a788:	vsubsd xmm0,xmm1,xmm0
  40a78c:	vmulsd xmm1,xmm0,xmm15
  40a791:	vcvttsd2si rdx,xmm1
  40a796:	mov    r11b,dl
  40a799:	add    r11b,0x30
  40a79d:	mov    BYTE PTR [r9+0xe],r11b
  40a7a1:	vxorpd xmm0,xmm0,xmm0
  40a7a5:	movzx  edx,dl
  40a7a8:	vcvtsi2sd xmm0,xmm0,rdx
  40a7ad:	vsubsd xmm0,xmm1,xmm0
  40a7b1:	vmulsd xmm1,xmm0,xmm15
  40a7b6:	vcvttsd2si rdx,xmm1
  40a7bb:	mov    r11b,dl
  40a7be:	add    r11b,0x30
  40a7c2:	mov    BYTE PTR [r9+0xf],r11b
  40a7c6:	lea    r10,[r10+0x2]
  40a7ca:	lea    r10,[r10+0x2]
  40a7ce:	lea    r10,[r10+0x2]
  40a7d2:	lea    r10,[r10+0x2]
  40a7d6:	lea    r10,[r10+0x2]
  40a7da:	vxorpd xmm0,xmm0,xmm0
  40a7de:	movzx  edx,dl
  40a7e1:	vcvtsi2sd xmm0,xmm0,rdx
  40a7e6:	vsubsd xmm0,xmm1,xmm0
  40a7ea:	vmulsd xmm1,xmm0,xmm15
  40a7ef:	vcvttsd2si rdx,xmm1
  40a7f4:	mov    r11b,dl
  40a7f7:	add    r11b,0x30
  40a7fb:	mov    BYTE PTR [r9+0x10],r11b
  40a7ff:	vxorpd xmm0,xmm0,xmm0
  40a803:	movzx  edx,dl
  40a806:	vcvtsi2sd xmm0,xmm0,rdx
  40a80b:	vsubsd xmm0,xmm1,xmm0
  40a80f:	vmulsd xmm1,xmm0,xmm15
  40a814:	vcvttsd2si rdx,xmm1
  40a819:	add    dl,0x30
  40a81c:	mov    BYTE PTR [r9+0x11],dl
  40a820:	mov    BYTE PTR [r10+0x2],0x65
  40a825:	lea    r9,[r10+0x3]
  40a829:	test   r8,r8
  40a82c:	jl     40a835 <__swc_fn_585f006d_000150_6203dca2+0x695>
  40a82e:	mov    BYTE PTR [r9],0x2b
  40a832:	inc    r9
  40a835:	mov    r10,r9
  40a838:	mov    rdx,r8
  40a83b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a840:	mov    r11,rdx
  40a843:	movabs rdx,0x6666666666666667
  40a84d:	mov    rax,r11
  40a850:	imul   rdx
  40a853:	sar    rdx,0x2
  40a857:	mov    r12,rdx
  40a85a:	shr    rdx,0x3f
  40a85e:	add    r12,rdx
  40a861:	mov    rdx,r12
  40a864:	imul   r13,r12,0xa
  40a868:	sub    r11,r13
  40a86b:	mov    r13,QWORD PTR [rip+0x7d9e]        # 412610 <__swc_rdata_base_585f006d+0x500>
  40a872:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40a877:	mov    BYTE PTR [r10],r11b
  40a87a:	lea    r11,[r10+0x1]
  40a87e:	mov    r10,r11
  40a881:	test   r12,r12
  40a884:	jne    40a840 <__swc_fn_585f006d_000150_6203dca2+0x6a0>
  40a886:	test   r8,r8
  40a889:	jge    40a893 <__swc_fn_585f006d_000150_6203dca2+0x6f3>
  40a88b:	mov    BYTE PTR [r11],0x2d
  40a88f:	lea    r10,[r11+0x1]
  40a893:	mov    BYTE PTR [r10],0x0
  40a897:	sub    r10,0x1
  40a89b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a8a0:	cmp    r9,r10
  40a8a3:	jae    40aaf8 <__swc_fn_585f006d_000150_6203dca2+0x958>
  40a8a9:	mov    al,BYTE PTR [r10]
  40a8ac:	mov    dl,BYTE PTR [r9]
  40a8af:	mov    BYTE PTR [r10],dl
  40a8b2:	sub    r10,0x1
  40a8b6:	mov    BYTE PTR [r9],al
  40a8b9:	inc    r9
  40a8bc:	jmp    40a8a0 <__swc_fn_585f006d_000150_6203dca2+0x700>
  40a8be:	vcvttsd2si rdx,xmm1
  40a8c3:	mov    r8,rdx
  40a8c6:	vxorpd xmm0,xmm0,xmm0
  40a8ca:	vcvtsi2sd xmm0,xmm0,rdx
  40a8cf:	vsubsd xmm0,xmm1,xmm0
  40a8d3:	mov    r9d,0x8
  40a8d9:	vxorpd xmm2,xmm2,xmm2
  40a8dd:	vcomisd xmm2,xmm0
  40a8e1:	jbe    40a8eb <__swc_fn_585f006d_000150_6203dca2+0x74b>
  40a8e3:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x7d35]        # 412620 <__swc_rdata_base_585f006d+0x510>
  40a8eb:	test   r9d,r9d
  40a8ee:	je     40a8fa <__swc_fn_585f006d_000150_6203dca2+0x75a>
  40a8f0:	vmulsd xmm0,xmm0,xmm14
  40a8f5:	dec    r9d
  40a8f8:	jne    40a8f0 <__swc_fn_585f006d_000150_6203dca2+0x750>
  40a8fa:	vcvttsd2si r9,xmm0
  40a8ff:	mov    r10,r9
  40a902:	vxorpd xmm2,xmm2,xmm2
  40a906:	vcvtsi2sd xmm2,xmm2,r9
  40a90b:	vsubsd xmm0,xmm0,xmm2
  40a90f:	vcomisd xmm0,xmm10
  40a914:	lea    r9,[r9+0x1]
  40a918:	cmova  r10,r9
  40a91c:	cmp    r10,0x5f5e100
  40a923:	jne    40a93c <__swc_fn_585f006d_000150_6203dca2+0x79c>
  40a925:	lea    r8,[rdx-0x1]
  40a929:	vxorpd xmm0,xmm0,xmm0
  40a92d:	vcomisd xmm0,xmm1
  40a931:	lea    rdx,[rdx+0x1]
  40a935:	cmovbe r8,rdx
  40a939:	xor    r10d,r10d
  40a93c:	mov    r9,rcx
  40a93f:	test   r8,r8
  40a942:	jne    40a962 <__swc_fn_585f006d_000150_6203dca2+0x7c2>
  40a944:	vxorpd xmm0,xmm0,xmm0
  40a948:	vcomisd xmm0,xmm1
  40a94c:	jbe    40a955 <__swc_fn_585f006d_000150_6203dca2+0x7b5>
  40a94e:	mov    BYTE PTR [rcx],0x2d
  40a951:	lea    r9,[rcx+0x1]
  40a955:	mov    BYTE PTR [r9],0x30
  40a959:	add    r9,0x1
  40a95d:	jmp    40a9fb <__swc_fn_585f006d_000150_6203dca2+0x85b>
  40a962:	mov    r9,rcx
  40a965:	mov    rdx,r8
  40a968:	nop    DWORD PTR [rax+rax*1+0x0]
  40a970:	mov    r11,rdx
  40a973:	movabs rdx,0x6666666666666667
  40a97d:	mov    r15,rax
  40a980:	mov    rax,r11
  40a983:	imul   rdx
  40a986:	mov    r12,rdx
  40a989:	mov    rax,r15
  40a98c:	sar    r12,0x2
  40a990:	mov    rdx,r12
  40a993:	shr    rdx,0x3f
  40a997:	add    r12,rdx
  40a99a:	mov    rdx,r12
  40a99d:	imul   r13,r12,0xa
  40a9a1:	sub    r11,r13
  40a9a4:	mov    r13,QWORD PTR [rip+0x7c65]        # 412610 <__swc_rdata_base_585f006d+0x500>
  40a9ab:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40a9b0:	mov    BYTE PTR [r9],r11b
  40a9b3:	lea    r11,[r9+0x1]
  40a9b7:	mov    r9,r11
  40a9ba:	test   r12,r12
  40a9bd:	jne    40a970 <__swc_fn_585f006d_000150_6203dca2+0x7d0>
  40a9bf:	test   r8,r8
  40a9c2:	jge    40a9cc <__swc_fn_585f006d_000150_6203dca2+0x82c>
  40a9c4:	mov    BYTE PTR [r11],0x2d
  40a9c8:	lea    r9,[r11+0x1]
  40a9cc:	mov    rdx,r9
  40a9cf:	mov    BYTE PTR [r9],0x0
  40a9d3:	sub    r9,0x1
  40a9d7:	mov    r8,rcx
  40a9da:	cmp    r8,r9
  40a9dd:	jae    40a9f8 <__swc_fn_585f006d_000150_6203dca2+0x858>
  40a9df:	nop
  40a9e0:	mov    r11b,BYTE PTR [r9]
  40a9e3:	mov    r12b,BYTE PTR [r8]
  40a9e6:	mov    BYTE PTR [r9],r12b
  40a9e9:	sub    r9,0x1
  40a9ed:	mov    BYTE PTR [r8],r11b
  40a9f0:	inc    r8
  40a9f3:	cmp    r8,r9
  40a9f6:	jb     40a9e0 <__swc_fn_585f006d_000150_6203dca2+0x840>
  40a9f8:	mov    r9,rdx
  40a9fb:	mov    BYTE PTR [r9],0x2e
  40a9ff:	add    r9,0x1
  40aa03:	xor    r8d,r8d
  40aa06:	test   r10,r10
  40aa09:	je     40aa4f <__swc_fn_585f006d_000150_6203dca2+0x8af>
  40aa0b:	mov    r11d,0x989680
  40aa11:	cmp    r10,r11
  40aa14:	jge    40aa4f <__swc_fn_585f006d_000150_6203dca2+0x8af>
  40aa16:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa20:	inc    r8d
  40aa23:	movabs rdx,0x6666666666666667
  40aa2d:	mov    r15,rax
  40aa30:	mov    rax,r11
  40aa33:	imul   rdx
  40aa36:	mov    r11,rdx
  40aa39:	mov    rax,r15
  40aa3c:	sar    r11,0x2
  40aa40:	mov    rdx,r11
  40aa43:	shr    rdx,0x3f
  40aa47:	add    r11,rdx
  40aa4a:	cmp    r10,r11
  40aa4d:	jl     40aa20 <__swc_fn_585f006d_000150_6203dca2+0x880>
  40aa4f:	test   r8d,r8d
  40aa52:	je     40aa6d <__swc_fn_585f006d_000150_6203dca2+0x8cd>
  40aa54:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa5e:	xchg   ax,ax
  40aa60:	mov    BYTE PTR [r9],0x30
  40aa64:	add    r9,0x1
  40aa68:	dec    r8d
  40aa6b:	jne    40aa60 <__swc_fn_585f006d_000150_6203dca2+0x8c0>
  40aa6d:	mov    r8,r9
  40aa70:	mov    rdx,r10
  40aa73:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa7d:	nop    DWORD PTR [rax]
  40aa80:	mov    r11,rdx
  40aa83:	movabs rdx,0x6666666666666667
  40aa8d:	mov    rax,r11
  40aa90:	imul   rdx
  40aa93:	sar    rdx,0x2
  40aa97:	mov    r12,rdx
  40aa9a:	shr    rdx,0x3f
  40aa9e:	add    r12,rdx
  40aaa1:	mov    rdx,r12
  40aaa4:	imul   r13,r12,0xa
  40aaa8:	sub    r11,r13
  40aaab:	mov    r13,QWORD PTR [rip+0x7b5e]        # 412610 <__swc_rdata_base_585f006d+0x500>
  40aab2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40aab7:	mov    BYTE PTR [r8],r11b
  40aaba:	lea    r11,[r8+0x1]
  40aabe:	mov    r8,r11
  40aac1:	test   r12,r12
  40aac4:	jne    40aa80 <__swc_fn_585f006d_000150_6203dca2+0x8e0>
  40aac6:	test   r10,r10
  40aac9:	jge    40aad3 <__swc_fn_585f006d_000150_6203dca2+0x933>
  40aacb:	mov    BYTE PTR [r11],0x2d
  40aacf:	lea    r8,[r11+0x1]
  40aad3:	mov    BYTE PTR [r8],0x0
  40aad7:	sub    r8,0x1
  40aadb:	cmp    r9,r8
  40aade:	jae    40aaf8 <__swc_fn_585f006d_000150_6203dca2+0x958>
  40aae0:	mov    al,BYTE PTR [r8]
  40aae3:	mov    dl,BYTE PTR [r9]
  40aae6:	mov    BYTE PTR [r8],dl
  40aae9:	sub    r8,0x1
  40aaed:	mov    BYTE PTR [r9],al
  40aaf0:	inc    r9
  40aaf3:	cmp    r9,r8
  40aaf6:	jb     40aae0 <__swc_fn_585f006d_000150_6203dca2+0x940>
  40aaf8:	xor    eax,eax
  40aafa:	test   rcx,rcx
  40aafd:	je     40ab30 <__swc_fn_585f006d_000150_6203dca2+0x990>
  40aaff:	mov    rdx,rcx
  40ab02:	mov    r8b,BYTE PTR [rdx]
  40ab05:	test   r8b,r8b
  40ab08:	je     40ab30 <__swc_fn_585f006d_000150_6203dca2+0x990>
  40ab0a:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab14:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab1e:	xchg   ax,ax
  40ab20:	add    rdx,0x1
  40ab24:	add    rax,0x1
  40ab28:	mov    r8b,BYTE PTR [rdx]
  40ab2b:	test   r8b,r8b
  40ab2e:	jne    40ab20 <__swc_fn_585f006d_000150_6203dca2+0x980>
  40ab30:	mov    QWORD PTR [rsp+0x240],rcx
  40ab38:	mov    QWORD PTR [rsp+0x248],rax
  40ab40:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  40ab49:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  40ab52:	lea    rcx,[rsp+0x250]
  40ab5a:	call   409930 <__swc_fn_585f006d_000120_2648f149>
  40ab5f:	jmp    40b265 <__swc_fn_585f006d_000150_6203dca2+0x10c5>
  40ab64:	lea    rcx,[rsp+0x260]
  40ab6c:	vxorps xmm0,xmm0,xmm0
  40ab70:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  40ab79:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  40ab82:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  40ab8b:	vzeroupper
  40ab8e:	mov    DWORD PTR [rsp+0x2c0],0x0
  40ab99:	vmovsd xmm0,QWORD PTR [rdx]
  40ab9d:	vcomisd xmm0,xmm0
  40aba1:	setne  dl
  40aba4:	movzx  edx,dl
  40aba7:	setp   r8b
  40abab:	movzx  r8d,r8b
  40abaf:	or     edx,r8d
  40abb2:	test   dl,dl
  40abb4:	je     40abc1 <__swc_fn_585f006d_000150_6203dca2+0xa21>
  40abb6:	mov    DWORD PTR [rcx],0x6e616e
  40abbc:	jmp    40b1c8 <__swc_fn_585f006d_000150_6203dca2+0x1028>
  40abc1:	vcomisd xmm0,xmm11
  40abc6:	ja     40abd7 <__swc_fn_585f006d_000150_6203dca2+0xa37>
  40abc8:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  40abd1:	vcomisd xmm6,xmm0
  40abd5:	jbe    40abfb <__swc_fn_585f006d_000150_6203dca2+0xa5b>
  40abd7:	vxorpd xmm1,xmm1,xmm1
  40abdb:	vcomisd xmm1,xmm0
  40abdf:	jbe    40abf0 <__swc_fn_585f006d_000150_6203dca2+0xa50>
  40abe1:	mov    DWORD PTR [rcx],0x666e692d
  40abe7:	mov    BYTE PTR [rcx+0x4],0x0
  40abeb:	jmp    40b1c8 <__swc_fn_585f006d_000150_6203dca2+0x1028>
  40abf0:	mov    DWORD PTR [rcx],0x666e69
  40abf6:	jmp    40b1c8 <__swc_fn_585f006d_000150_6203dca2+0x1028>
  40abfb:	vcomisd xmm0,xmm13
  40ac00:	jae    40ac0c <__swc_fn_585f006d_000150_6203dca2+0xa6c>
  40ac02:	vcomisd xmm12,xmm0
  40ac06:	jbe    40af6e <__swc_fn_585f006d_000150_6203dca2+0xdce>
  40ac0c:	vmovups xmm1,xmm0
  40ac10:	vxorpd xmm2,xmm2,xmm2
  40ac14:	vcomisd xmm2,xmm0
  40ac18:	jbe    40ac28 <__swc_fn_585f006d_000150_6203dca2+0xa88>
  40ac1a:	vmovsd xmm0,xmm0,xmm1
  40ac1e:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x79fa]        # 412620 <__swc_rdata_base_585f006d+0x510>
  40ac26:	jmp    40ac2c <__swc_fn_585f006d_000150_6203dca2+0xa8c>
  40ac28:	vmovsd xmm0,xmm0,xmm1
  40ac2c:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  40ac35:	xor    r8d,r8d
  40ac38:	vcomisd xmm0,xmm6
  40ac3c:	jb     40ac4e <__swc_fn_585f006d_000150_6203dca2+0xaae>
  40ac3e:	xchg   ax,ax
  40ac40:	vdivsd xmm0,xmm0,xmm6
  40ac44:	add    r8,0x1
  40ac48:	vcomisd xmm0,xmm6
  40ac4c:	jae    40ac40 <__swc_fn_585f006d_000150_6203dca2+0xaa0>
  40ac4e:	mov    r9,rcx
  40ac51:	vxorpd xmm2,xmm2,xmm2
  40ac55:	vcomisd xmm2,xmm1
  40ac59:	jbe    40ac62 <__swc_fn_585f006d_000150_6203dca2+0xac2>
  40ac5b:	mov    BYTE PTR [rcx],0x2d
  40ac5e:	lea    r9,[rcx+0x1]
  40ac62:	vcvttsd2si rdx,xmm0
  40ac67:	mov    r10b,dl
  40ac6a:	add    r10b,0x30
  40ac6e:	mov    BYTE PTR [r9],r10b
  40ac71:	vxorpd xmm1,xmm1,xmm1
  40ac75:	movzx  edx,dl
  40ac78:	vcvtsi2sd xmm1,xmm1,rdx
  40ac7d:	vsubsd xmm0,xmm0,xmm1
  40ac81:	vmulsd xmm0,xmm0,xmm6
  40ac85:	mov    BYTE PTR [r9+0x1],0x2e
  40ac8a:	vcvttsd2si rdx,xmm0
  40ac8f:	mov    r10b,dl
  40ac92:	add    r10b,0x30
  40ac96:	mov    BYTE PTR [r9+0x2],r10b
  40ac9a:	vxorpd xmm1,xmm1,xmm1
  40ac9e:	movzx  edx,dl
  40aca1:	vcvtsi2sd xmm1,xmm1,rdx
  40aca6:	vsubsd xmm0,xmm0,xmm1
  40acaa:	vmulsd xmm0,xmm0,xmm6
  40acae:	vcvttsd2si rdx,xmm0
  40acb3:	mov    r10b,dl
  40acb6:	add    r10b,0x30
  40acba:	mov    BYTE PTR [r9+0x3],r10b
  40acbe:	vxorpd xmm1,xmm1,xmm1
  40acc2:	movzx  edx,dl
  40acc5:	vcvtsi2sd xmm1,xmm1,rdx
  40acca:	vsubsd xmm0,xmm0,xmm1
  40acce:	vmulsd xmm0,xmm0,xmm6
  40acd2:	vcvttsd2si rdx,xmm0
  40acd7:	mov    r10b,dl
  40acda:	add    r10b,0x30
  40acde:	mov    BYTE PTR [r9+0x4],r10b
  40ace2:	vxorpd xmm1,xmm1,xmm1
  40ace6:	movzx  edx,dl
  40ace9:	vcvtsi2sd xmm1,xmm1,rdx
  40acee:	vsubsd xmm0,xmm0,xmm1
  40acf2:	vmulsd xmm0,xmm0,xmm6
  40acf6:	vcvttsd2si rdx,xmm0
  40acfb:	mov    r10b,dl
  40acfe:	add    r10b,0x30
  40ad02:	mov    BYTE PTR [r9+0x5],r10b
  40ad06:	vxorpd xmm1,xmm1,xmm1
  40ad0a:	movzx  edx,dl
  40ad0d:	vcvtsi2sd xmm1,xmm1,rdx
  40ad12:	vsubsd xmm0,xmm0,xmm1
  40ad16:	vmulsd xmm0,xmm0,xmm6
  40ad1a:	vcvttsd2si rdx,xmm0
  40ad1f:	mov    r10b,dl
  40ad22:	add    r10b,0x30
  40ad26:	mov    BYTE PTR [r9+0x6],r10b
  40ad2a:	vxorpd xmm1,xmm1,xmm1
  40ad2e:	movzx  edx,dl
  40ad31:	vcvtsi2sd xmm1,xmm1,rdx
  40ad36:	vsubsd xmm0,xmm0,xmm1
  40ad3a:	vmulsd xmm0,xmm0,xmm6
  40ad3e:	vcvttsd2si rdx,xmm0
  40ad43:	mov    r10b,dl
  40ad46:	add    r10b,0x30
  40ad4a:	mov    BYTE PTR [r9+0x7],r10b
  40ad4e:	vxorpd xmm1,xmm1,xmm1
  40ad52:	movzx  edx,dl
  40ad55:	vcvtsi2sd xmm1,xmm1,rdx
  40ad5a:	vsubsd xmm0,xmm0,xmm1
  40ad5e:	vmulsd xmm0,xmm0,xmm6
  40ad62:	vcvttsd2si rdx,xmm0
  40ad67:	mov    r10b,dl
  40ad6a:	add    r10b,0x30
  40ad6e:	mov    BYTE PTR [r9+0x8],r10b
  40ad72:	vxorpd xmm1,xmm1,xmm1
  40ad76:	movzx  edx,dl
  40ad79:	vcvtsi2sd xmm1,xmm1,rdx
  40ad7e:	vsubsd xmm0,xmm0,xmm1
  40ad82:	vmulsd xmm0,xmm0,xmm6
  40ad86:	vcvttsd2si rdx,xmm0
  40ad8b:	mov    r10b,dl
  40ad8e:	add    r10b,0x30
  40ad92:	mov    BYTE PTR [r9+0x9],r10b
  40ad96:	vxorpd xmm1,xmm1,xmm1
  40ad9a:	movzx  edx,dl
  40ad9d:	vcvtsi2sd xmm1,xmm1,rdx
  40ada2:	vsubsd xmm0,xmm0,xmm1
  40ada6:	vmulsd xmm0,xmm0,xmm6
  40adaa:	vcvttsd2si rdx,xmm0
  40adaf:	mov    r10b,dl
  40adb2:	add    r10b,0x30
  40adb6:	mov    BYTE PTR [r9+0xa],r10b
  40adba:	vxorpd xmm1,xmm1,xmm1
  40adbe:	movzx  edx,dl
  40adc1:	vcvtsi2sd xmm1,xmm1,rdx
  40adc6:	vsubsd xmm0,xmm0,xmm1
  40adca:	vmulsd xmm0,xmm0,xmm6
  40adce:	vcvttsd2si rdx,xmm0
  40add3:	mov    r10b,dl
  40add6:	add    r10b,0x30
  40adda:	mov    BYTE PTR [r9+0xb],r10b
  40adde:	lea    r10,[r9+0x4]
  40ade2:	vxorpd xmm1,xmm1,xmm1
  40ade6:	movzx  edx,dl
  40ade9:	vcvtsi2sd xmm1,xmm1,rdx
  40adee:	vsubsd xmm0,xmm0,xmm1
  40adf2:	vmulsd xmm0,xmm0,xmm6
  40adf6:	vcvttsd2si rdx,xmm0
  40adfb:	mov    r11b,dl
  40adfe:	add    r11b,0x30
  40ae02:	mov    BYTE PTR [r9+0xc],r11b
  40ae06:	vxorpd xmm1,xmm1,xmm1
  40ae0a:	movzx  edx,dl
  40ae0d:	vcvtsi2sd xmm1,xmm1,rdx
  40ae12:	vsubsd xmm0,xmm0,xmm1
  40ae16:	vmulsd xmm0,xmm0,xmm6
  40ae1a:	vcvttsd2si rdx,xmm0
  40ae1f:	mov    r11b,dl
  40ae22:	add    r11b,0x30
  40ae26:	mov    BYTE PTR [r9+0xd],r11b
  40ae2a:	lea    r10,[r10+0x2]
  40ae2e:	vxorpd xmm1,xmm1,xmm1
  40ae32:	movzx  edx,dl
  40ae35:	vcvtsi2sd xmm1,xmm1,rdx
  40ae3a:	vsubsd xmm0,xmm0,xmm1
  40ae3e:	vmulsd xmm0,xmm0,xmm6
  40ae42:	vcvttsd2si rdx,xmm0
  40ae47:	mov    r11b,dl
  40ae4a:	add    r11b,0x30
  40ae4e:	mov    BYTE PTR [r9+0xe],r11b
  40ae52:	vxorpd xmm1,xmm1,xmm1
  40ae56:	movzx  edx,dl
  40ae59:	vcvtsi2sd xmm1,xmm1,rdx
  40ae5e:	vsubsd xmm0,xmm0,xmm1
  40ae62:	vmulsd xmm0,xmm0,xmm6
  40ae66:	vcvttsd2si rdx,xmm0
  40ae6b:	mov    r11b,dl
  40ae6e:	add    r11b,0x30
  40ae72:	mov    BYTE PTR [r9+0xf],r11b
  40ae76:	lea    r10,[r10+0x2]
  40ae7a:	lea    r10,[r10+0x2]
  40ae7e:	lea    r10,[r10+0x2]
  40ae82:	lea    r10,[r10+0x2]
  40ae86:	lea    r10,[r10+0x2]
  40ae8a:	vxorpd xmm1,xmm1,xmm1
  40ae8e:	movzx  edx,dl
  40ae91:	vcvtsi2sd xmm1,xmm1,rdx
  40ae96:	vsubsd xmm0,xmm0,xmm1
  40ae9a:	vmulsd xmm0,xmm0,xmm6
  40ae9e:	vcvttsd2si rdx,xmm0
  40aea3:	mov    r11b,dl
  40aea6:	add    r11b,0x30
  40aeaa:	mov    BYTE PTR [r9+0x10],r11b
  40aeae:	vxorpd xmm1,xmm1,xmm1
  40aeb2:	movzx  edx,dl
  40aeb5:	vcvtsi2sd xmm1,xmm1,rdx
  40aeba:	vsubsd xmm0,xmm0,xmm1
  40aebe:	vmulsd xmm0,xmm0,xmm6
  40aec2:	vcvttsd2si rdx,xmm0
  40aec7:	add    dl,0x30
  40aeca:	mov    BYTE PTR [r9+0x11],dl
  40aece:	mov    BYTE PTR [r10+0x2],0x65
  40aed3:	lea    r9,[r10+0x3]
  40aed7:	test   r8,r8
  40aeda:	jl     40aee3 <__swc_fn_585f006d_000150_6203dca2+0xd43>
  40aedc:	mov    BYTE PTR [r9],0x2b
  40aee0:	inc    r9
  40aee3:	mov    r10,r9
  40aee6:	mov    rdx,r8
  40aee9:	nop    DWORD PTR [rax+0x0]
  40aef0:	mov    r11,rdx
  40aef3:	movabs rdx,0x6666666666666667
  40aefd:	mov    rax,r11
  40af00:	imul   rdx
  40af03:	sar    rdx,0x2
  40af07:	mov    r12,rdx
  40af0a:	shr    rdx,0x3f
  40af0e:	add    r12,rdx
  40af11:	mov    rdx,r12
  40af14:	imul   r13,r12,0xa
  40af18:	sub    r11,r13
  40af1b:	mov    r13,QWORD PTR [rip+0x76ee]        # 412610 <__swc_rdata_base_585f006d+0x500>
  40af22:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40af27:	mov    BYTE PTR [r10],r11b
  40af2a:	lea    r11,[r10+0x1]
  40af2e:	mov    r10,r11
  40af31:	test   r12,r12
  40af34:	jne    40aef0 <__swc_fn_585f006d_000150_6203dca2+0xd50>
  40af36:	test   r8,r8
  40af39:	jge    40af43 <__swc_fn_585f006d_000150_6203dca2+0xda3>
  40af3b:	mov    BYTE PTR [r11],0x2d
  40af3f:	lea    r10,[r11+0x1]
  40af43:	mov    BYTE PTR [r10],0x0
  40af47:	sub    r10,0x1
  40af4b:	nop    DWORD PTR [rax+rax*1+0x0]
  40af50:	cmp    r9,r10
  40af53:	jae    40b1c8 <__swc_fn_585f006d_000150_6203dca2+0x1028>
  40af59:	mov    al,BYTE PTR [r10]
  40af5c:	mov    dl,BYTE PTR [r9]
  40af5f:	mov    BYTE PTR [r10],dl
  40af62:	sub    r10,0x1
  40af66:	mov    BYTE PTR [r9],al
  40af69:	inc    r9
  40af6c:	jmp    40af50 <__swc_fn_585f006d_000150_6203dca2+0xdb0>
  40af6e:	vcvttsd2si rdx,xmm0
  40af73:	mov    r8,rdx
  40af76:	vxorpd xmm1,xmm1,xmm1
  40af7a:	vcvtsi2sd xmm1,xmm1,rdx
  40af7f:	vsubsd xmm1,xmm0,xmm1
  40af83:	mov    r9d,0x8
  40af89:	vxorpd xmm2,xmm2,xmm2
  40af8d:	vcomisd xmm2,xmm1
  40af91:	ja     40af9e <__swc_fn_585f006d_000150_6203dca2+0xdfe>
  40af93:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40af9c:	jmp    40afaf <__swc_fn_585f006d_000150_6203dca2+0xe0f>
  40af9e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x767a]        # 412620 <__swc_rdata_base_585f006d+0x510>
  40afa6:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40afaf:	test   r9d,r9d
  40afb2:	je     40afc9 <__swc_fn_585f006d_000150_6203dca2+0xe29>
  40afb4:	cs nop WORD PTR [rax+rax*1+0x0]
  40afbe:	xchg   ax,ax
  40afc0:	vmulsd xmm1,xmm1,xmm6
  40afc4:	dec    r9d
  40afc7:	jne    40afc0 <__swc_fn_585f006d_000150_6203dca2+0xe20>
  40afc9:	vcvttsd2si r9,xmm1
  40afce:	mov    r10,r9
  40afd1:	vxorpd xmm2,xmm2,xmm2
  40afd5:	vcvtsi2sd xmm2,xmm2,r9
  40afda:	vsubsd xmm1,xmm1,xmm2
  40afde:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  40afe7:	vcomisd xmm1,xmm6
  40afeb:	lea    r9,[r9+0x1]
  40afef:	cmova  r10,r9
  40aff3:	cmp    r10,0x5f5e100
  40affa:	jne    40b013 <__swc_fn_585f006d_000150_6203dca2+0xe73>
  40affc:	lea    r8,[rdx-0x1]
  40b000:	vxorpd xmm1,xmm1,xmm1
  40b004:	vcomisd xmm1,xmm0
  40b008:	lea    rdx,[rdx+0x1]
  40b00c:	cmovbe r8,rdx
  40b010:	xor    r10d,r10d
  40b013:	mov    r9,rcx
  40b016:	test   r8,r8
  40b019:	jne    40b039 <__swc_fn_585f006d_000150_6203dca2+0xe99>
  40b01b:	vxorpd xmm1,xmm1,xmm1
  40b01f:	vcomisd xmm1,xmm0
  40b023:	jbe    40b02c <__swc_fn_585f006d_000150_6203dca2+0xe8c>
  40b025:	mov    BYTE PTR [rcx],0x2d
  40b028:	lea    r9,[rcx+0x1]
  40b02c:	mov    BYTE PTR [r9],0x30
  40b030:	add    r9,0x1
  40b034:	jmp    40b0cb <__swc_fn_585f006d_000150_6203dca2+0xf2b>
  40b039:	mov    r9,rcx
  40b03c:	mov    rdx,r8
  40b03f:	nop
  40b040:	mov    r11,rdx
  40b043:	movabs rdx,0x6666666666666667
  40b04d:	mov    r15,rax
  40b050:	mov    rax,r11
  40b053:	imul   rdx
  40b056:	mov    r12,rdx
  40b059:	mov    rax,r15
  40b05c:	sar    r12,0x2
  40b060:	mov    rdx,r12
  40b063:	shr    rdx,0x3f
  40b067:	add    r12,rdx
  40b06a:	mov    rdx,r12
  40b06d:	imul   r13,r12,0xa
  40b071:	sub    r11,r13
  40b074:	mov    r13,QWORD PTR [rip+0x7595]        # 412610 <__swc_rdata_base_585f006d+0x500>
  40b07b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b080:	mov    BYTE PTR [r9],r11b
  40b083:	lea    r11,[r9+0x1]
  40b087:	mov    r9,r11
  40b08a:	test   r12,r12
  40b08d:	jne    40b040 <__swc_fn_585f006d_000150_6203dca2+0xea0>
  40b08f:	test   r8,r8
  40b092:	jge    40b09c <__swc_fn_585f006d_000150_6203dca2+0xefc>
  40b094:	mov    BYTE PTR [r11],0x2d
  40b098:	lea    r9,[r11+0x1]
  40b09c:	mov    rdx,r9
  40b09f:	mov    BYTE PTR [r9],0x0
  40b0a3:	sub    r9,0x1
  40b0a7:	mov    r8,rcx
  40b0aa:	cmp    r8,r9
  40b0ad:	jae    40b0c8 <__swc_fn_585f006d_000150_6203dca2+0xf28>
  40b0af:	nop
  40b0b0:	mov    r11b,BYTE PTR [r9]
  40b0b3:	mov    r12b,BYTE PTR [r8]
  40b0b6:	mov    BYTE PTR [r9],r12b
  40b0b9:	sub    r9,0x1
  40b0bd:	mov    BYTE PTR [r8],r11b
  40b0c0:	inc    r8
  40b0c3:	cmp    r8,r9
  40b0c6:	jb     40b0b0 <__swc_fn_585f006d_000150_6203dca2+0xf10>
  40b0c8:	mov    r9,rdx
  40b0cb:	mov    BYTE PTR [r9],0x2e
  40b0cf:	add    r9,0x1
  40b0d3:	xor    r8d,r8d
  40b0d6:	test   r10,r10
  40b0d9:	je     40b11f <__swc_fn_585f006d_000150_6203dca2+0xf7f>
  40b0db:	mov    r11d,0x989680
  40b0e1:	cmp    r10,r11
  40b0e4:	jge    40b11f <__swc_fn_585f006d_000150_6203dca2+0xf7f>
  40b0e6:	cs nop WORD PTR [rax+rax*1+0x0]
  40b0f0:	inc    r8d
  40b0f3:	movabs rdx,0x6666666666666667
  40b0fd:	mov    r15,rax
  40b100:	mov    rax,r11
  40b103:	imul   rdx
  40b106:	mov    r11,rdx
  40b109:	mov    rax,r15
  40b10c:	sar    r11,0x2
  40b110:	mov    rdx,r11
  40b113:	shr    rdx,0x3f
  40b117:	add    r11,rdx
  40b11a:	cmp    r10,r11
  40b11d:	jl     40b0f0 <__swc_fn_585f006d_000150_6203dca2+0xf50>
  40b11f:	test   r8d,r8d
  40b122:	je     40b13d <__swc_fn_585f006d_000150_6203dca2+0xf9d>
  40b124:	cs nop WORD PTR [rax+rax*1+0x0]
  40b12e:	xchg   ax,ax
  40b130:	mov    BYTE PTR [r9],0x30
  40b134:	add    r9,0x1
  40b138:	dec    r8d
  40b13b:	jne    40b130 <__swc_fn_585f006d_000150_6203dca2+0xf90>
  40b13d:	mov    r8,r9
  40b140:	mov    rdx,r10
  40b143:	cs nop WORD PTR [rax+rax*1+0x0]
  40b14d:	nop    DWORD PTR [rax]
  40b150:	mov    r11,rdx
  40b153:	movabs rdx,0x6666666666666667
  40b15d:	mov    rax,r11
  40b160:	imul   rdx
  40b163:	sar    rdx,0x2
  40b167:	mov    r12,rdx
  40b16a:	shr    rdx,0x3f
  40b16e:	add    r12,rdx
  40b171:	mov    rdx,r12
  40b174:	imul   r13,r12,0xa
  40b178:	sub    r11,r13
  40b17b:	mov    r13,QWORD PTR [rip+0x748e]        # 412610 <__swc_rdata_base_585f006d+0x500>
  40b182:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b187:	mov    BYTE PTR [r8],r11b
  40b18a:	lea    r11,[r8+0x1]
  40b18e:	mov    r8,r11
  40b191:	test   r12,r12
  40b194:	jne    40b150 <__swc_fn_585f006d_000150_6203dca2+0xfb0>
  40b196:	test   r10,r10
  40b199:	jge    40b1a3 <__swc_fn_585f006d_000150_6203dca2+0x1003>
  40b19b:	mov    BYTE PTR [r11],0x2d
  40b19f:	lea    r8,[r11+0x1]
  40b1a3:	mov    BYTE PTR [r8],0x0
  40b1a7:	sub    r8,0x1
  40b1ab:	cmp    r9,r8
  40b1ae:	jae    40b1c8 <__swc_fn_585f006d_000150_6203dca2+0x1028>
  40b1b0:	mov    al,BYTE PTR [r8]
  40b1b3:	mov    dl,BYTE PTR [r9]
  40b1b6:	mov    BYTE PTR [r8],dl
  40b1b9:	sub    r8,0x1
  40b1bd:	mov    BYTE PTR [r9],al
  40b1c0:	inc    r9
  40b1c3:	cmp    r9,r8
  40b1c6:	jb     40b1b0 <__swc_fn_585f006d_000150_6203dca2+0x1010>
  40b1c8:	xor    eax,eax
  40b1ca:	test   rcx,rcx
  40b1cd:	je     40b1f0 <__swc_fn_585f006d_000150_6203dca2+0x1050>
  40b1cf:	mov    rdx,rcx
  40b1d2:	mov    r8b,BYTE PTR [rdx]
  40b1d5:	test   r8b,r8b
  40b1d8:	je     40b1f0 <__swc_fn_585f006d_000150_6203dca2+0x1050>
  40b1da:	nop    WORD PTR [rax+rax*1+0x0]
  40b1e0:	add    rdx,0x1
  40b1e4:	add    rax,0x1
  40b1e8:	mov    r8b,BYTE PTR [rdx]
  40b1eb:	test   r8b,r8b
  40b1ee:	jne    40b1e0 <__swc_fn_585f006d_000150_6203dca2+0x1040>
  40b1f0:	mov    QWORD PTR [rsp+0x3f8],rcx
  40b1f8:	mov    QWORD PTR [rsp+0x400],rax
  40b200:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  40b209:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  40b212:	lea    rcx,[rsp+0x408]
  40b21a:	call   409930 <__swc_fn_585f006d_000120_2648f149>
  40b21f:	jmp    40b265 <__swc_fn_585f006d_000150_6203dca2+0x10c5>
  40b221:	mov    rcx,rdx
  40b224:	call   409930 <__swc_fn_585f006d_000120_2648f149>
  40b229:	jmp    40b265 <__swc_fn_585f006d_000150_6203dca2+0x10c5>
  40b22b:	mov    al,BYTE PTR [rdx]
  40b22d:	test   al,al
  40b22f:	je     40b23a <__swc_fn_585f006d_000150_6203dca2+0x109a>
  40b231:	lea    rax,[rip+0x73f8]        # 412630 <__swc_rdata_base_585f006d+0x520>
  40b238:	jmp    40b241 <__swc_fn_585f006d_000150_6203dca2+0x10a1>
  40b23a:	lea    rax,[rip+0x73ff]        # 412640 <__swc_rdata_base_585f006d+0x530>
  40b241:	mov    rcx,rax
  40b244:	call   409930 <__swc_fn_585f006d_000120_2648f149>
  40b249:	jmp    40b265 <__swc_fn_585f006d_000150_6203dca2+0x10c5>
  40b24b:	lea    rcx,[rip+0x73fe]        # 412650 <__swc_rdata_base_585f006d+0x540>
  40b252:	call   409930 <__swc_fn_585f006d_000120_2648f149>
  40b257:	jmp    40b265 <__swc_fn_585f006d_000150_6203dca2+0x10c5>
  40b259:	lea    rcx,[rip+0x73f0]        # 412650 <__swc_rdata_base_585f006d+0x540>
  40b260:	call   409930 <__swc_fn_585f006d_000120_2648f149>
  40b265:	add    rdi,0x1
  40b269:	sub    rsi,0x1
  40b26d:	vmovups xmm0,xmm12
  40b272:	vmovsd xmm6,QWORD PTR [rip+0x73e6]        # 412660 <__swc_rdata_base_585f006d+0x550>
  40b27a:	test   rsi,rsi
  40b27d:	jne    40a2b0 <__swc_fn_585f006d_000150_6203dca2+0x110>
  40b283:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  40b28c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  40b295:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  40b29e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  40b2a7:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  40b2b0:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  40b2b9:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  40b2c2:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  40b2cb:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  40b2d4:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  40b2dd:	add    rsp,0x4e8
  40b2e4:	pop    r15
  40b2e6:	pop    r13
  40b2e8:	pop    r12
  40b2ea:	pop    rdi
  40b2eb:	pop    rsi
  40b2ec:	pop    rbx
  40b2ed:	ret
	...

000000000040b2f0 <__swc_fn_585f006d_000153_86f1d437>:
  40b2f0:	vxorps xmm0,xmm0,xmm0
  40b2f4:	vmovups XMMWORD PTR [rcx],xmm0
  40b2f8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b2fd:	ret
	...

000000000040b300 <__swc_fn_585f006d_000156_86f1d437>:
  40b300:	vxorps xmm0,xmm0,xmm0
  40b304:	vmovups XMMWORD PTR [rcx],xmm0
  40b308:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b30d:	vxorps xmm0,xmm0,xmm0
  40b311:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b316:	vmovups xmm0,XMMWORD PTR [rip+0x7452]        # 412770 <__swc_rdata_base_585f006d+0x660>
  40b31e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b323:	vxorps xmm0,xmm0,xmm0
  40b327:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40b32c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40b331:	vxorps xmm0,xmm0,xmm0
  40b335:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40b33a:	mov    QWORD PTR [rcx+0x70],0x0
  40b342:	ret
	...

000000000040b350 <__swc_fn_585f006d_000159_86f1d437>:
  40b350:	vxorps xmm0,xmm0,xmm0
  40b354:	vmovups XMMWORD PTR [rcx],xmm0
  40b358:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b35d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b362:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b367:	ret
	...

000000000040b370 <__swc_fn_585f006d_000162_e36363a8>:
  40b370:	push   rsi
  40b371:	push   rdi
  40b372:	sub    rsp,0x8
  40b376:	mov    rsi,rcx
  40b379:	mov    rdi,QWORD PTR [rsi+0x50]
  40b37d:	test   rdi,rdi
  40b380:	je     40b387 <__swc_fn_585f006d_000162_e36363a8+0x17>
  40b382:	mov    rcx,rsi
  40b385:	call   rdi
  40b387:	mov    QWORD PTR [rsi+0x20],0x0
  40b38f:	mov    rax,QWORD PTR [rsi+0x30]
  40b393:	test   rax,rax
  40b396:	je     40b3c4 <__swc_fn_585f006d_000162_e36363a8+0x54>
  40b398:	nop    DWORD PTR [rax+rax*1+0x0]
  40b3a0:	mov    rdi,QWORD PTR [rax+0x8]
  40b3a4:	mov    rcx,rsi
  40b3a7:	mov    rdx,QWORD PTR [rax+0x10]
  40b3ab:	mov    rax,QWORD PTR [rax+0x18]
  40b3af:	mov    r8,rax
  40b3b2:	call   40e510 <__swc_fn_585f006d_000160_47b270e1>
  40b3b7:	mov    QWORD PTR [rsi+0x30],rdi
  40b3bb:	mov    rax,QWORD PTR [rsi+0x30]
  40b3bf:	test   rax,rax
  40b3c2:	jne    40b3a0 <__swc_fn_585f006d_000162_e36363a8+0x30>
  40b3c4:	mov    QWORD PTR [rsi+0x38],0x0
  40b3cc:	add    rsp,0x8
  40b3d0:	pop    rdi
  40b3d1:	pop    rsi
  40b3d2:	ret
	...

000000000040b3e0 <__swc_fn_585f006d_000165_016ee66a>:
  40b3e0:	push   rbx
  40b3e1:	push   rsi
  40b3e2:	push   rdi
  40b3e3:	push   r12
  40b3e5:	sub    rsp,0x188
  40b3ec:	mov    rbx,rcx
  40b3ef:	lea    rsi,[rip+0x1a992]        # 425d88 <__swc_bss_base_585f006d+0x2d48>
  40b3f6:	mov    rcx,rsi
  40b3f9:	call   40df20 <__swc_fn_585f006d_000139_86bb0f90>
  40b3fe:	mov    rax,QWORD PTR [rip+0x1a98b]        # 425d90 <__swc_bss_base_585f006d+0x2d50>
  40b405:	mov    rdi,rax
  40b408:	test   rdi,rdi
  40b40b:	je     40b439 <__swc_fn_585f006d_000165_016ee66a+0x59>
  40b40d:	nop    DWORD PTR [rax]
  40b410:	cmp    QWORD PTR [rdi+0x8],rbx
  40b414:	jne    40b42e <__swc_fn_585f006d_000165_016ee66a+0x4e>
  40b416:	mov    rcx,rsi
  40b419:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40b41e:	mov    rax,rdi
  40b421:	add    rsp,0x188
  40b428:	pop    r12
  40b42a:	pop    rdi
  40b42b:	pop    rsi
  40b42c:	pop    rbx
  40b42d:	ret
  40b42e:	mov    rax,QWORD PTR [rdi]
  40b431:	mov    rdi,rax
  40b434:	test   rax,rax
  40b437:	jne    40b410 <__swc_fn_585f006d_000165_016ee66a+0x30>
  40b439:	call   411500 <__swc_fn_585f006d_000143_d299b428>
  40b43e:	mov    rdi,rax
  40b441:	test   rax,rax
  40b444:	jne    40b45d <__swc_fn_585f006d_000165_016ee66a+0x7d>
  40b446:	mov    rcx,rsi
  40b449:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40b44e:	xor    eax,eax
  40b450:	add    rsp,0x188
  40b457:	pop    r12
  40b459:	pop    rdi
  40b45a:	pop    rsi
  40b45b:	pop    rbx
  40b45c:	ret
  40b45d:	lea    rax,[rsp+0x18]
  40b462:	mov    QWORD PTR [rax+0x10],0x0
  40b46a:	mov    QWORD PTR [rax+0x18],0x0
  40b472:	mov    DWORD PTR [rax+0x20],0x0
  40b479:	mov    BYTE PTR [rax+0x24],0x0
  40b47d:	mov    rax,QWORD PTR [rip+0x1a90c]        # 425d90 <__swc_bss_base_585f006d+0x2d50>
  40b484:	mov    QWORD PTR [rsp+0x18],rax
  40b489:	mov    QWORD PTR [rsp+0x20],rbx
  40b48e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40b494:	vmovups XMMWORD PTR [rdi],xmm0
  40b498:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40b49e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  40b4a3:	mov    rax,QWORD PTR [rsp+0x38]
  40b4a8:	mov    QWORD PTR [rdi+0x20],rax
  40b4ac:	mov    QWORD PTR [rip+0x1a8dd],rdi        # 425d90 <__swc_bss_base_585f006d+0x2d50>
  40b4b3:	lea    rax,[rsp+0x40]
  40b4b8:	mov    QWORD PTR [rax],0x0
  40b4bf:	mov    rcx,rbx
  40b4c2:	mov    rdx,rax
  40b4c5:	call   40e000 <__swc_fn_585f006d_000145_1534de9a>
  40b4ca:	mov    rbx,rax
  40b4cd:	test   rax,rax
  40b4d0:	jne    40b4ea <__swc_fn_585f006d_000165_016ee66a+0x10a>
  40b4d2:	mov    rcx,rsi
  40b4d5:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40b4da:	mov    rax,rdi
  40b4dd:	add    rsp,0x188
  40b4e4:	pop    r12
  40b4e6:	pop    rdi
  40b4e7:	pop    rsi
  40b4e8:	pop    rbx
  40b4e9:	ret
  40b4ea:	lea    r12,[rsp+0x50]
  40b4ef:	mov    QWORD PTR [r12],0x0
  40b4f7:	mov    rcx,rbx
  40b4fa:	mov    rdx,QWORD PTR [rsp+0x40]
  40b4ff:	mov    r8,r12
  40b502:	call   4115b0 <__swc_fn_585f006d_000146_162f363d>
  40b507:	test   rax,rax
  40b50a:	jne    40b524 <__swc_fn_585f006d_000165_016ee66a+0x144>
  40b50c:	mov    rcx,rsi
  40b50f:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40b514:	mov    rax,rdi
  40b517:	add    rsp,0x188
  40b51e:	pop    r12
  40b520:	pop    rdi
  40b521:	pop    rsi
  40b522:	pop    rbx
  40b523:	ret
  40b524:	cmp    QWORD PTR [r12],0x10
  40b529:	jb     40b62c <__swc_fn_585f006d_000165_016ee66a+0x24c>
  40b52f:	mov    ecx,DWORD PTR [rax]
  40b531:	cmp    ecx,0x42445753
  40b537:	jne    40b62c <__swc_fn_585f006d_000165_016ee66a+0x24c>
  40b53d:	mov    ecx,DWORD PTR [rax+0x4]
  40b540:	cmp    ecx,0x1
  40b543:	jne    40b62c <__swc_fn_585f006d_000165_016ee66a+0x24c>
  40b549:	mov    ecx,DWORD PTR [rax+0x8]
  40b54c:	mov    edx,DWORD PTR [rax+0xc]
  40b54f:	imul   r8,rcx,0x14
  40b553:	mov    r9,QWORD PTR [rsp+0x50]
  40b558:	sub    r9,0x10
  40b55c:	cmp    r8,r9
  40b55f:	ja     40b62c <__swc_fn_585f006d_000165_016ee66a+0x24c>
  40b565:	lea    r8,[r8+0x10]
  40b569:	cmp    rdx,r8
  40b56c:	jb     40b62c <__swc_fn_585f006d_000165_016ee66a+0x24c>
  40b572:	mov    r8,QWORD PTR [rsp+0x50]
  40b577:	cmp    rdx,r8
  40b57a:	ja     40b62c <__swc_fn_585f006d_000165_016ee66a+0x24c>
  40b580:	xor    r8d,r8d
  40b583:	test   rcx,rcx
  40b586:	jbe    40b652 <__swc_fn_585f006d_000165_016ee66a+0x272>
  40b58c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  40b592:	cs nop WORD PTR [rax+rax*1+0x0]
  40b59c:	nop    DWORD PTR [rax+0x0]
  40b5a0:	imul   r9,r8,0x14
  40b5a4:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  40b5a9:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  40b5ae:	add    r10,r11
  40b5b1:	movabs r11,0x100000000
  40b5bb:	cmp    r10,r11
  40b5be:	ja     40b62c <__swc_fn_585f006d_000165_016ee66a+0x24c>
  40b5c0:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  40b5c5:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  40b5ca:	test   r10d,r10d
  40b5cd:	setne  r11b
  40b5d1:	je     40b5eb <__swc_fn_585f006d_000165_016ee66a+0x20b>
  40b5d3:	cmp    r10d,edx
  40b5d6:	setb   r11b
  40b5da:	jb     40b5eb <__swc_fn_585f006d_000165_016ee66a+0x20b>
  40b5dc:	vmovq  r11,xmm1
  40b5e1:	cmp    r10,r11
  40b5e4:	setae  r10b
  40b5e8:	mov    r11b,r10b
  40b5eb:	mov    r10,r11
  40b5ee:	test   r11b,r11b
  40b5f1:	jne    40b618 <__swc_fn_585f006d_000165_016ee66a+0x238>
  40b5f3:	test   r9d,r9d
  40b5f6:	setne  r10b
  40b5fa:	je     40b618 <__swc_fn_585f006d_000165_016ee66a+0x238>
  40b5fc:	cmp    r9d,edx
  40b5ff:	setb   r10b
  40b603:	jb     40b618 <__swc_fn_585f006d_000165_016ee66a+0x238>
  40b605:	vmovq  r10,xmm1
  40b60a:	cmp    r9,r10
  40b60d:	setae  r9b
  40b611:	movzx  r9d,r9b
  40b615:	mov    r10b,r9b
  40b618:	test   r10b,r10b
  40b61b:	jne    40b62c <__swc_fn_585f006d_000165_016ee66a+0x24c>
  40b61d:	add    r8,0x1
  40b621:	cmp    r8,rcx
  40b624:	jb     40b5a0 <__swc_fn_585f006d_000165_016ee66a+0x1c0>
  40b62a:	jmp    40b652 <__swc_fn_585f006d_000165_016ee66a+0x272>
  40b62c:	xor    ecx,ecx
  40b62e:	cmp    rax,rbx
  40b631:	cmovne rcx,rax
  40b635:	call   40a0f0 <__swc_fn_585f006d_000147_d7edc04f>
  40b63a:	mov    rcx,rsi
  40b63d:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40b642:	mov    rax,rdi
  40b645:	add    rsp,0x188
  40b64c:	pop    r12
  40b64e:	pop    rdi
  40b64f:	pop    rsi
  40b650:	pop    rbx
  40b651:	ret
  40b652:	mov    QWORD PTR [rdi+0x10],rax
  40b656:	mov    rcx,QWORD PTR [rsp+0x50]
  40b65b:	mov    QWORD PTR [rdi+0x18],rcx
  40b65f:	mov    eax,DWORD PTR [rax+0x8]
  40b662:	mov    DWORD PTR [rdi+0x20],eax
  40b665:	rex mov BYTE PTR [rdi+0x24],0x1
  40b66a:	mov    rcx,rsi
  40b66d:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40b672:	mov    rax,rdi
  40b675:	add    rsp,0x188
  40b67c:	pop    r12
  40b67e:	pop    rdi
  40b67f:	pop    rsi
  40b680:	pop    rbx
  40b681:	ret
	...

000000000040b690 <__swc_fn_585f006d_000168_3459066f>:
  40b690:	push   rsi
  40b691:	push   rdi
  40b692:	push   r12
  40b694:	mov    rsi,rdx
  40b697:	mov    rdi,rcx
  40b69a:	mov    rcx,QWORD PTR [rip+0x1799f]        # 423040 <__swc_bss_base_585f006d>
  40b6a1:	test   rcx,rcx
  40b6a4:	jne    40b6b6 <__swc_fn_585f006d_000168_3459066f+0x26>
  40b6a6:	call   40e820 <__swc_fn_585f006d_000169_994c8876>
  40b6ab:	lea    rcx,[rax+0x1]
  40b6af:	mov    QWORD PTR [rip+0x1798a],rcx        # 423040 <__swc_bss_base_585f006d>
  40b6b6:	dec    rcx
  40b6b9:	call   40b6e0 <__swc_fn_585f006d_000171_360af05d>
  40b6be:	mov    r12,QWORD PTR [rax+0xbe0]
  40b6c5:	test   r12,r12
  40b6c8:	setne  al
  40b6cb:	je     40b6d6 <__swc_fn_585f006d_000168_3459066f+0x46>
  40b6cd:	mov    rcx,rdi
  40b6d0:	mov    rdx,rsi
  40b6d3:	call   r12
  40b6d6:	pop    r12
  40b6d8:	pop    rdi
  40b6d9:	pop    rsi
  40b6da:	ret
  40b6db:	add    BYTE PTR [rax],al
  40b6dd:	add    BYTE PTR [rax],al
	...

000000000040b6e0 <__swc_fn_585f006d_000171_360af05d>:
  40b6e0:	push   r12
  40b6e2:	push   rdi
  40b6e3:	push   rsi
  40b6e4:	sub    rsp,0xd0
  40b6eb:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40b6f1:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40b6f7:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40b6fd:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40b703:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40b709:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40b70f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40b718:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40b721:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40b72a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40b733:	mov    r12,rcx
  40b736:	mov    edi,ecx
  40b738:	xor    eax,eax
  40b73a:	call   407000 <pthread_getspecific@plt>
  40b73f:	test   rax,rax
  40b742:	je     40b746 <__swc_fn_585f006d_000171_360af05d+0x66>
  40b744:	jmp    40b74e <__swc_fn_585f006d_000171_360af05d+0x6e>
  40b746:	mov    rcx,r12
  40b749:	call   40e880 <__swc_fn_585f006d_000172_cbeff767>
  40b74e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40b754:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40b75a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40b760:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40b766:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40b76c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40b772:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40b77b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40b784:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40b78d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40b796:	add    rsp,0xd0
  40b79d:	pop    rsi
  40b79e:	pop    rdi
  40b79f:	pop    r12
  40b7a1:	ret
	...

000000000040b7b0 <__swc_fn_585f006d_000174_5eac0ab4>:
  40b7b0:	push   rsi
  40b7b1:	sub    rsp,0x30
  40b7b5:	lea    rsi,[rip+0x1a5e4]        # 425da0 <__swc_bss_base_585f006d+0x2d60>
  40b7bc:	mov    rax,QWORD PTR [rsi]
  40b7bf:	test   rax,rax
  40b7c2:	je     40b7ca <__swc_fn_585f006d_000174_5eac0ab4+0x1a>
  40b7c4:	add    rsp,0x30
  40b7c8:	pop    rsi
  40b7c9:	ret
  40b7ca:	mov    ecx,0x3
  40b7cf:	mov    edx,0x10
  40b7d4:	call   409250 <__swc_fn_585f006d_000111_6814119b>
  40b7d9:	test   rax,rax
  40b7dc:	jne    40b7ed <__swc_fn_585f006d_000174_5eac0ab4+0x3d>
  40b7de:	mov    QWORD PTR [rsp+0x18],rax
  40b7e3:	call   411050 <__swc_fn_585f006d_000122_be2e2f68>
  40b7e8:	mov    rax,QWORD PTR [rsp+0x18]
  40b7ed:	mov    rcx,rax
  40b7f0:	xchg   QWORD PTR [rsi],rcx
  40b7f3:	add    rsp,0x30
  40b7f7:	pop    rsi
  40b7f8:	ret
  40b7f9:	add    BYTE PTR [rax],al
  40b7fb:	add    BYTE PTR [rax],al
  40b7fd:	add    BYTE PTR [rax],al
	...

000000000040b800 <__swc_fn_585f006d_000177_cf4ffedd>:
  40b800:	push   rsi
  40b801:	push   rdi
  40b802:	sub    rsp,0x8
  40b806:	mov    rsi,rdx
  40b809:	mov    rdi,rcx
  40b80c:	mov    rax,QWORD PTR [rsi+0x8]
  40b810:	test   rax,rax
  40b813:	je     40b81d <__swc_fn_585f006d_000177_cf4ffedd+0x1d>
  40b815:	mov    rcx,QWORD PTR [rsi]
  40b818:	mov    QWORD PTR [rax],rcx
  40b81b:	jmp    40b824 <__swc_fn_585f006d_000177_cf4ffedd+0x24>
  40b81d:	mov    rax,QWORD PTR [rsi]
  40b820:	mov    QWORD PTR [rdi+0x8],rax
  40b824:	mov    rax,QWORD PTR [rsi]
  40b827:	test   rax,rax
  40b82a:	je     40b834 <__swc_fn_585f006d_000177_cf4ffedd+0x34>
  40b82c:	mov    rcx,QWORD PTR [rsi+0x8]
  40b830:	mov    QWORD PTR [rax+0x8],rcx
  40b834:	mov    rcx,rdi
  40b837:	mov    rdx,QWORD PTR [rsi+0x10]
  40b83b:	mov    r8,QWORD PTR [rsi+0x18]
  40b83f:	mov    r9,0xffffffffffffffff
  40b846:	call   411c00 <__swc_fn_585f006d_000176_4de704de>
  40b84b:	mov    QWORD PTR [rsi+0x18],0x0
  40b853:	mov    rax,QWORD PTR [rdi+0x8]
  40b857:	test   rax,rax
  40b85a:	jne    40b86c <__swc_fn_585f006d_000177_cf4ffedd+0x6c>
  40b85c:	call   40b7b0 <__swc_fn_585f006d_000174_5eac0ab4>
  40b861:	xor    ecx,ecx
  40b863:	mov    QWORD PTR [rax+0x8],rcx
  40b867:	xor    ecx,ecx
  40b869:	mov    QWORD PTR [rax],rcx
  40b86c:	add    rsp,0x8
  40b870:	pop    rdi
  40b871:	pop    rsi
  40b872:	ret
	...

000000000040b880 <__swc_fn_585f006d_000001_5d3d19bd>:
  40b880:	push   rbx
  40b881:	sub    rsp,0x70
  40b885:	test   rcx,rcx
  40b888:	jne    40b890 <__swc_fn_585f006d_000001_5d3d19bd+0x10>
  40b88a:	add    rsp,0x70
  40b88e:	pop    rbx
  40b88f:	ret
  40b890:	vxorps xmm0,xmm0,xmm0
  40b894:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40b89a:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40b8a0:	vzeroupper
  40b8a3:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40b8a9:	lea    rax,[rcx-0x10]
  40b8ad:	mov    QWORD PTR [rsp+0x48],rax
  40b8b2:	mov    rax,QWORD PTR [rcx-0x10]
  40b8b6:	mov    QWORD PTR [rsp+0x50],rax
  40b8bb:	mov    rcx,QWORD PTR [rip+0x1777e]        # 423040 <__swc_bss_base_585f006d>
  40b8c2:	test   rcx,rcx
  40b8c5:	jne    40b8d7 <__swc_fn_585f006d_000001_5d3d19bd+0x57>
  40b8c7:	call   40e820 <__swc_fn_585f006d_000169_994c8876>
  40b8cc:	lea    rcx,[rax+0x1]
  40b8d0:	mov    QWORD PTR [rip+0x17769],rcx        # 423040 <__swc_bss_base_585f006d>
  40b8d7:	dec    rcx
  40b8da:	call   40b6e0 <__swc_fn_585f006d_000171_360af05d>
  40b8df:	mov    rcx,QWORD PTR [rax]
  40b8e2:	lea    rdx,[rsp+0x8]
  40b8e7:	mov    rbx,QWORD PTR [rax+0x8]
  40b8eb:	mov    rbx,QWORD PTR [rbx+0x18]
  40b8ef:	call   rbx
  40b8f1:	add    rsp,0x70
  40b8f5:	pop    rbx
  40b8f6:	ret
	...

000000000040b900 <__swc_fn_585f006d_000004_9ee35b18>:
  40b900:	vxorps xmm0,xmm0,xmm0
  40b904:	vmovups XMMWORD PTR [rcx],xmm0
  40b908:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b90d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b912:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b917:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40b91c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40b921:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40b926:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40b92b:	ret
  40b92c:	add    BYTE PTR [rax],al
	...

000000000040b930 <__swc_fn_585f006d_000007_f7acedb0>:
  40b930:	push   rsi
  40b931:	mov    rsi,rdx
  40b934:	test   rdx,rdx
  40b937:	jne    40b940 <__swc_fn_585f006d_000007_f7acedb0+0x10>
  40b939:	mov    eax,0x1
  40b93e:	pop    rsi
  40b93f:	ret
  40b940:	mov    rdx,rsi
  40b943:	call   40d8c0 <__swc_fn_585f006d_000115_36905703>
  40b948:	test   al,al
  40b94a:	jne    40b950 <__swc_fn_585f006d_000007_f7acedb0+0x20>
  40b94c:	xor    eax,eax
  40b94e:	pop    rsi
  40b94f:	ret
  40b950:	lea    rcx,[rip+0x176f9]        # 423050 <__swc_bss_base_585f006d+0x10>
  40b957:	mov    rdx,QWORD PTR [rip+0x176f2]        # 423050 <__swc_bss_base_585f006d+0x10>
  40b95e:	xchg   ax,ax
  40b960:	lea    r8,[rdx+rsi*1]
  40b964:	mov    rax,rdx
  40b967:	lock cmpxchg QWORD PTR [rcx],r8
  40b96c:	cmp    rax,rdx
  40b96f:	je     40b976 <__swc_fn_585f006d_000007_f7acedb0+0x46>
  40b971:	mov    rdx,rax
  40b974:	jmp    40b960 <__swc_fn_585f006d_000007_f7acedb0+0x30>
  40b976:	lea    rcx,[rip+0x176db]        # 423058 <__swc_bss_base_585f006d+0x18>
  40b97d:	mov    rdx,QWORD PTR [rip+0x176d4]        # 423058 <__swc_bss_base_585f006d+0x18>
  40b984:	cs nop WORD PTR [rax+rax*1+0x0]
  40b98e:	xchg   ax,ax
  40b990:	lea    r8,[rdx+0x1]
  40b994:	mov    rax,rdx
  40b997:	lock cmpxchg QWORD PTR [rcx],r8
  40b99c:	cmp    rax,rdx
  40b99f:	je     40b9a6 <__swc_fn_585f006d_000007_f7acedb0+0x76>
  40b9a1:	mov    rdx,rax
  40b9a4:	jmp    40b990 <__swc_fn_585f006d_000007_f7acedb0+0x60>
  40b9a6:	mov    eax,0x1
  40b9ab:	pop    rsi
  40b9ac:	ret
  40b9ad:	add    BYTE PTR [rax],al
	...

000000000040b9b0 <__swc_fn_585f006d_000010_24a20786>:
  40b9b0:	push   rbx
  40b9b1:	push   rsi
  40b9b2:	push   rdi
  40b9b3:	push   r12
  40b9b5:	sub    rsp,0x18
  40b9b9:	mov    rbx,rcx
  40b9bc:	mov    rsi,rcx
  40b9bf:	and    rsi,0xffffffffffc00000
  40b9c6:	movzx  eax,BYTE PTR [rbx+0x3a]
  40b9ca:	mov    ecx,DWORD PTR [rsi+0x28]
  40b9cd:	shrx   eax,eax,ecx
  40b9d2:	lea    rdi,[rsp+0x8]
  40b9d7:	mov    DWORD PTR [rsp+0x8],eax
  40b9db:	mov    rcx,rsi
  40b9de:	mov    rax,rdi
  40b9e1:	mov    edx,DWORD PTR [rax]
  40b9e3:	call   407770 <__swc_fn_585f006d_000015_9dea5065>
  40b9e8:	mov    r12,rax
  40b9eb:	mov    rcx,rsi
  40b9ee:	mov    edx,DWORD PTR [rdi]
  40b9f0:	call   40bae0 <__swc_fn_585f006d_000016_9afb7cfb>
  40b9f5:	mov    rcx,r12
  40b9f8:	mov    edx,DWORD PTR [rbx+0x3c]
  40b9fb:	add    rcx,rdx
  40b9fe:	cmp    rcx,rax
  40ba01:	jb     40ba0f <__swc_fn_585f006d_000010_24a20786+0x5f>
  40ba03:	xor    eax,eax
  40ba05:	add    rsp,0x18
  40ba09:	pop    r12
  40ba0b:	pop    rdi
  40ba0c:	pop    rsi
  40ba0d:	pop    rbx
  40ba0e:	ret
  40ba0f:	mov    rdx,QWORD PTR [rbx+0x20]
  40ba13:	mov    r8d,DWORD PTR [rbx+0x2c]
  40ba17:	add    rdx,r8
  40ba1a:	lea    rsi,[rdx+0xffff]
  40ba21:	and    rsi,0xffffffffffff0000
  40ba28:	cmp    rax,rsi
  40ba2b:	cmovbe rsi,rax
  40ba2f:	mov    rax,rsi
  40ba32:	sub    rax,rcx
  40ba35:	mov    rdx,rax
  40ba38:	call   40b930 <__swc_fn_585f006d_000007_f7acedb0>
  40ba3d:	test   al,al
  40ba3f:	jne    40ba4d <__swc_fn_585f006d_000010_24a20786+0x9d>
  40ba41:	xor    eax,eax
  40ba43:	add    rsp,0x18
  40ba47:	pop    r12
  40ba49:	pop    rdi
  40ba4a:	pop    rsi
  40ba4b:	pop    rbx
  40ba4c:	ret
  40ba4d:	sub    rsi,r12
  40ba50:	mov    DWORD PTR [rbx+0x3c],esi
  40ba53:	mov    ecx,DWORD PTR [rbx+0x2c]
  40ba56:	mov    rax,rsi
  40ba59:	xor    edx,edx
  40ba5b:	div    rcx
  40ba5e:	imul   rax,rcx
  40ba62:	add    r12,rax
  40ba65:	mov    QWORD PTR [rbx+0x18],r12
  40ba69:	mov    eax,0x1
  40ba6e:	add    rsp,0x18
  40ba72:	pop    r12
  40ba74:	pop    rdi
  40ba75:	pop    rsi
  40ba76:	pop    rbx
  40ba77:	ret
	...

000000000040ba80 <__swc_fn_585f006d_000013_e4b0ddfc>:
  40ba80:	sub    rsp,0x8
  40ba84:	mov    rdx,rcx
  40ba87:	lea    r9,[rcx+0x60]
  40ba8b:	mov    rax,QWORD PTR [r9]
  40ba8e:	test   rax,rax
  40ba91:	jne    40ba98 <__swc_fn_585f006d_000013_e4b0ddfc+0x18>
  40ba93:	add    rsp,0x8
  40ba97:	ret
  40ba98:	mov    rcx,rdx
  40ba9b:	call   40ebb0 <__swc_fn_585f006d_000011_c3647f66>
  40baa0:	xor    eax,eax
  40baa2:	xchg   QWORD PTR [r9],rax
  40baa5:	mov    r8,rax
  40baa8:	mov    rcx,rdx
  40baab:	call   407760 <__swc_fn_585f006d_000012_861b8b62>
  40bab0:	xor    eax,eax
  40bab2:	test   r8,r8
  40bab5:	je     40bad6 <__swc_fn_585f006d_000013_e4b0ddfc+0x56>
  40bab7:	nop    WORD PTR [rax+rax*1+0x0]
  40bac0:	mov    rcx,QWORD PTR [r8]
  40bac3:	mov    r9,QWORD PTR [rdx]
  40bac6:	mov    QWORD PTR [r8],r9
  40bac9:	mov    QWORD PTR [rdx],r8
  40bacc:	mov    r8,rcx
  40bacf:	inc    eax
  40bad1:	test   rcx,rcx
  40bad4:	jne    40bac0 <__swc_fn_585f006d_000013_e4b0ddfc+0x40>
  40bad6:	sub    DWORD PTR [rdx+0x28],eax
  40bad9:	add    rsp,0x8
  40badd:	ret
	...

000000000040bae0 <__swc_fn_585f006d_000016_9afb7cfb>:
  40bae0:	lea    eax,[rdx+0x1]
  40bae3:	mov    edx,DWORD PTR [rcx+0x28]
  40bae6:	shlx   eax,eax,edx
  40baeb:	shl    rax,0x10
  40baef:	add    rax,rcx
  40baf2:	ret
	...

000000000040bb00 <__swc_fn_585f006d_000019_adca76cf>:
  40bb00:	push   rbx
  40bb01:	push   rsi
  40bb02:	push   rdi
  40bb03:	push   r12
  40bb05:	push   r13
  40bb07:	push   r14
  40bb09:	push   r15
  40bb0b:	sub    rsp,0x30
  40bb0f:	mov    rbx,rcx
  40bb12:	lea    rsi,[rcx+0x48]
  40bb16:	mov    QWORD PTR [rsp+0x18],rsi
  40bb1b:	mov    rax,QWORD PTR [rsi]
  40bb1e:	mov    rdi,rax
  40bb21:	lea    r12,[rsp+0x8]
  40bb26:	lea    r13,[rcx+0x40]
  40bb2a:	nop    WORD PTR [rax+rax*1+0x0]
  40bb30:	test   rdi,rdi
  40bb33:	je     40bc73 <__swc_fn_585f006d_000019_adca76cf+0x173>
  40bb39:	xor    eax,eax
  40bb3b:	tzcnt  rax,rdi
  40bb40:	mov    DWORD PTR [rsp+0x8],eax
  40bb44:	mov    r14d,0x1
  40bb4a:	mov    ecx,eax
  40bb4c:	shl    r14,cl
  40bb4f:	andn   rdi,r14,rdi
  40bb54:	mov    rcx,QWORD PTR [r13+0x0]
  40bb58:	test   rcx,r14
  40bb5b:	jne    40bb30 <__swc_fn_585f006d_000019_adca76cf+0x30>
  40bb5d:	mov    rdx,rcx
  40bb60:	or     rdx,r14
  40bb63:	mov    rax,rcx
  40bb66:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  40bb6c:	cmp    rax,rcx
  40bb6f:	je     40bb79 <__swc_fn_585f006d_000019_adca76cf+0x79>
  40bb71:	mov    rax,QWORD PTR [rsi]
  40bb74:	mov    rdi,rax
  40bb77:	jmp    40bb30 <__swc_fn_585f006d_000019_adca76cf+0x30>
  40bb79:	mov    rcx,rbx
  40bb7c:	mov    rdx,r14
  40bb7f:	call   4078d0 <__swc_fn_585f006d_000021_fd2b165c>
  40bb84:	test   al,al
  40bb86:	je     40bc5e <__swc_fn_585f006d_000019_adca76cf+0x15e>
  40bb8c:	mov    eax,DWORD PTR [r12]
  40bb90:	shl    rax,0x4
  40bb94:	lea    r15,[rbx+rax*8+0x80]
  40bb9c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  40bba4:	lea    rcx,[rip+0x174b5]        # 423060 <__swc_bss_base_585f006d+0x20>
  40bbab:	mov    rdx,QWORD PTR [rip+0x174ae]        # 423060 <__swc_bss_base_585f006d+0x20>
  40bbb2:	cs nop WORD PTR [rax+rax*1+0x0]
  40bbbc:	nop    DWORD PTR [rax+0x0]
  40bbc0:	mov    r8,rdx
  40bbc3:	sub    r8,rsi
  40bbc6:	mov    rax,rdx
  40bbc9:	lock cmpxchg QWORD PTR [rcx],r8
  40bbce:	cmp    rax,rdx
  40bbd1:	je     40bbd8 <__swc_fn_585f006d_000019_adca76cf+0xd8>
  40bbd3:	mov    rdx,rax
  40bbd6:	jmp    40bbc0 <__swc_fn_585f006d_000019_adca76cf+0xc0>
  40bbd8:	mov    rcx,rbx
  40bbdb:	mov    rax,r12
  40bbde:	mov    edx,DWORD PTR [rax]
  40bbe0:	call   407770 <__swc_fn_585f006d_000015_9dea5065>
  40bbe5:	test   rsi,rsi
  40bbe8:	je     40bc56 <__swc_fn_585f006d_000019_adca76cf+0x156>
  40bbee:	mov    rcx,rax
  40bbf1:	mov    rdx,rsi
  40bbf4:	call   410e20 <__swc_fn_585f006d_000116_e9fc0224>
  40bbf9:	lea    rcx,[rip+0x17450]        # 423050 <__swc_bss_base_585f006d+0x10>
  40bc00:	mov    rdx,QWORD PTR [rip+0x17449]        # 423050 <__swc_bss_base_585f006d+0x10>
  40bc07:	nop    WORD PTR [rax+rax*1+0x0]
  40bc10:	mov    r8,rdx
  40bc13:	sub    r8,rsi
  40bc16:	mov    rax,rdx
  40bc19:	lock cmpxchg QWORD PTR [rcx],r8
  40bc1e:	cmp    rax,rdx
  40bc21:	je     40bc28 <__swc_fn_585f006d_000019_adca76cf+0x128>
  40bc23:	mov    rdx,rax
  40bc26:	jmp    40bc10 <__swc_fn_585f006d_000019_adca76cf+0x110>
  40bc28:	lea    rcx,[rip+0x17439]        # 423068 <__swc_bss_base_585f006d+0x28>
  40bc2f:	mov    rdx,QWORD PTR [rip+0x17432]        # 423068 <__swc_bss_base_585f006d+0x28>
  40bc36:	cs nop WORD PTR [rax+rax*1+0x0]
  40bc40:	lea    r8,[rdx+0x1]
  40bc44:	mov    rax,rdx
  40bc47:	lock cmpxchg QWORD PTR [rcx],r8
  40bc4c:	cmp    rax,rdx
  40bc4f:	je     40bc56 <__swc_fn_585f006d_000019_adca76cf+0x156>
  40bc51:	mov    rdx,rax
  40bc54:	jmp    40bc40 <__swc_fn_585f006d_000019_adca76cf+0x140>
  40bc56:	mov    DWORD PTR [r15+0x3c],0x0
  40bc5e:	mov    rcx,rbx
  40bc61:	mov    rdx,r14
  40bc64:	call   40bc90 <__swc_fn_585f006d_000022_c8f5f27c>
  40bc69:	mov    rsi,QWORD PTR [rsp+0x18]
  40bc6e:	jmp    40bb30 <__swc_fn_585f006d_000019_adca76cf+0x30>
  40bc73:	add    rsp,0x30
  40bc77:	pop    r15
  40bc79:	pop    r14
  40bc7b:	pop    r13
  40bc7d:	pop    r12
  40bc7f:	pop    rdi
  40bc80:	pop    rsi
  40bc81:	pop    rbx
  40bc82:	ret
	...

000000000040bc90 <__swc_fn_585f006d_000022_c8f5f27c>:
  40bc90:	mov    r8,QWORD PTR [rcx+0x40]
  40bc94:	cs nop WORD PTR [rax+rax*1+0x0]
  40bc9e:	xchg   ax,ax
  40bca0:	mov    rax,rdx
  40bca3:	not    rax
  40bca6:	mov    r9,r8
  40bca9:	and    r9,rax
  40bcac:	mov    rax,r8
  40bcaf:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  40bcb5:	cmp    rax,r8
  40bcb8:	jne    40bcbb <__swc_fn_585f006d_000022_c8f5f27c+0x2b>
  40bcba:	ret
  40bcbb:	mov    r8,rax
  40bcbe:	jmp    40bca0 <__swc_fn_585f006d_000022_c8f5f27c+0x10>

000000000040bcc0 <__swc_fn_585f006d_000025_aa910677>:
  40bcc0:	push   rsi
  40bcc1:	push   rdi
  40bcc2:	sub    rsp,0x8
  40bcc6:	mov    rsi,rcx
  40bcc9:	call   40bb00 <__swc_fn_585f006d_000019_adca76cf>
  40bcce:	lea    rdi,[rip+0x17523]        # 4231f8 <__swc_bss_base_585f006d+0x1b8>
  40bcd5:	mov    rcx,rdi
  40bcd8:	call   40df20 <__swc_fn_585f006d_000139_86bb0f90>
  40bcdd:	mov    QWORD PTR [rsi+0x8],0x0
  40bce5:	mov    QWORD PTR [rsi+0x18],0x0
  40bced:	mov    rax,QWORD PTR [rip+0x1750c]        # 423200 <__swc_bss_base_585f006d+0x1c0>
  40bcf4:	mov    QWORD PTR [rsi+0x10],rax
  40bcf8:	mov    QWORD PTR [rip+0x17501],rsi        # 423200 <__swc_bss_base_585f006d+0x1c0>
  40bcff:	mov    rcx,rdi
  40bd02:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40bd07:	add    rsp,0x8
  40bd0b:	pop    rdi
  40bd0c:	pop    rsi
  40bd0d:	ret
	...

000000000040bd10 <__swc_fn_585f006d_000028_9798fb47>:
  40bd10:	vxorps xmm0,xmm0,xmm0
  40bd14:	vmovups XMMWORD PTR [rcx],xmm0
  40bd18:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40bd1d:	mov    QWORD PTR [rcx+0x20],0x0
  40bd25:	ret
	...

000000000040bd30 <__swc_fn_585f006d_000031_9798fb47>:
  40bd30:	vxorps xmm0,xmm0,xmm0
  40bd34:	vmovups XMMWORD PTR [rcx],xmm0
  40bd38:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40bd3d:	mov    QWORD PTR [rcx+0x20],0x0
  40bd45:	ret
	...

000000000040bd50 <__swc_fn_585f006d_000034_9128bcf9>:
  40bd50:	push   r12
  40bd52:	mov    r12,rdi
  40bd55:	test   rdi,rdi
  40bd58:	jne    40bd5d <__swc_fn_585f006d_000034_9128bcf9+0xd>
  40bd5a:	pop    r12
  40bd5c:	ret
  40bd5d:	lea    rax,[rip+0x1529c]        # 421000 <__swc_data_base_585f006d>
  40bd64:	mov    rax,QWORD PTR [rax]
  40bd67:	cmp    rax,0xffffffffffffffff
  40bd6b:	je     40bd7a <__swc_fn_585f006d_000034_9128bcf9+0x2a>
  40bd6d:	mov    eax,eax
  40bd6f:	mov    edi,eax
  40bd71:	xor    eax,eax
  40bd73:	call   407000 <pthread_getspecific@plt>
  40bd78:	jmp    40bd7c <__swc_fn_585f006d_000034_9128bcf9+0x2c>
  40bd7a:	xor    eax,eax
  40bd7c:	cmp    rax,r12
  40bd7f:	jne    40bd88 <__swc_fn_585f006d_000034_9128bcf9+0x38>
  40bd81:	xor    ecx,ecx
  40bd83:	call   407aa0 <__swc_fn_585f006d_000036_92d9bbff>
  40bd88:	mov    rdx,QWORD PTR [r12]
  40bd8c:	test   rdx,rdx
  40bd8f:	je     40bda8 <__swc_fn_585f006d_000034_9128bcf9+0x58>
  40bd91:	mov    rcx,rdx
  40bd94:	call   40bdd0 <__swc_fn_585f006d_000040_eb6108f2>
  40bd99:	test   al,al
  40bd9b:	je     40bda8 <__swc_fn_585f006d_000034_9128bcf9+0x58>
  40bd9d:	mov    rcx,rdx
  40bda0:	mov    rdx,r12
  40bda3:	call   40bec0 <__swc_fn_585f006d_000046_b30433d0>
  40bda8:	pop    r12
  40bdaa:	ret
  40bdab:	add    BYTE PTR [rax],al
  40bdad:	add    BYTE PTR [rax],al
	...

000000000040bdb0 <__swc_fn_585f006d_000037_28d0e998>:
  40bdb0:	push   rsi
  40bdb1:	mov    rsi,rcx
  40bdb4:	call   40f060 <__swc_fn_585f006d_000035_cd1a4e8c>
  40bdb9:	mov    rcx,rax
  40bdbc:	mov    rdx,rsi
  40bdbf:	call   40dda0 <__swc_fn_585f006d_000133_ae5891af>
  40bdc4:	mov    rcx,rsi
  40bdc7:	call   407aa0 <__swc_fn_585f006d_000036_92d9bbff>
  40bdcc:	pop    rsi
  40bdcd:	ret
	...

000000000040bdd0 <__swc_fn_585f006d_000040_eb6108f2>:
  40bdd0:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40bdda:	sete   al
  40bddd:	ret
	...

000000000040bde0 <__swc_fn_585f006d_000043_d3c2ab54>:
  40bde0:	push   rsi
  40bde1:	test   rdx,rdx
  40bde4:	jne    40bde8 <__swc_fn_585f006d_000043_d3c2ab54+0x8>
  40bde6:	pop    rsi
  40bde7:	ret
  40bde8:	mov    rax,r8
  40bdeb:	mov    ecx,0x1000
  40bdf0:	test   ecx,ecx
  40bdf2:	mov    r10d,0x8
  40bdf8:	cmove  ecx,r10d
  40bdfc:	dec    rcx
  40bdff:	mov    r10,0xffffffffffffffff
  40be06:	sub    r10,rcx
  40be09:	cmp    r8,r10
  40be0c:	jbe    40be12 <__swc_fn_585f006d_000043_d3c2ab54+0x32>
  40be0e:	xor    eax,eax
  40be10:	jmp    40be1a <__swc_fn_585f006d_000043_d3c2ab54+0x3a>
  40be12:	add    rax,rcx
  40be15:	andn   rax,rcx,rax
  40be1a:	mov    ecx,0x1000
  40be1f:	test   ecx,ecx
  40be21:	mov    r8d,0x8
  40be27:	cmove  ecx,r8d
  40be2b:	dec    rcx
  40be2e:	mov    r8,0xffffffffffffffff
  40be35:	sub    r8,rcx
  40be38:	cmp    r9,r8
  40be3b:	jbe    40be41 <__swc_fn_585f006d_000043_d3c2ab54+0x61>
  40be3d:	xor    esi,esi
  40be3f:	jmp    40be4c <__swc_fn_585f006d_000043_d3c2ab54+0x6c>
  40be41:	add    r9,rcx
  40be44:	andn   r9,rcx,r9
  40be49:	mov    rsi,r9
  40be4c:	mov    rcx,rdx
  40be4f:	mov    rdx,rax
  40be52:	mov    r8,rsi
  40be55:	call   40d9a0 <__swc_fn_585f006d_000118_5208f471>
  40be5a:	lea    rcx,[rip+0x171ef]        # 423050 <__swc_bss_base_585f006d+0x10>
  40be61:	mov    rdx,QWORD PTR [rip+0x171e8]        # 423050 <__swc_bss_base_585f006d+0x10>
  40be68:	nop    DWORD PTR [rax+rax*1+0x0]
  40be70:	mov    r8,rdx
  40be73:	sub    r8,rsi
  40be76:	mov    rax,rdx
  40be79:	lock cmpxchg QWORD PTR [rcx],r8
  40be7e:	cmp    rax,rdx
  40be81:	je     40be88 <__swc_fn_585f006d_000043_d3c2ab54+0xa8>
  40be83:	mov    rdx,rax
  40be86:	jmp    40be70 <__swc_fn_585f006d_000043_d3c2ab54+0x90>
  40be88:	lea    rcx,[rip+0x171d9]        # 423068 <__swc_bss_base_585f006d+0x28>
  40be8f:	mov    rdx,QWORD PTR [rip+0x171d2]        # 423068 <__swc_bss_base_585f006d+0x28>
  40be96:	cs nop WORD PTR [rax+rax*1+0x0]
  40bea0:	lea    r8,[rdx+0x1]
  40bea4:	mov    rax,rdx
  40bea7:	lock cmpxchg QWORD PTR [rcx],r8
  40beac:	cmp    rax,rdx
  40beaf:	je     40beb6 <__swc_fn_585f006d_000043_d3c2ab54+0xd6>
  40beb1:	mov    rdx,rax
  40beb4:	jmp    40bea0 <__swc_fn_585f006d_000043_d3c2ab54+0xc0>
  40beb6:	pop    rsi
  40beb7:	ret
	...

000000000040bec0 <__swc_fn_585f006d_000046_b30433d0>:
  40bec0:	push   rbx
  40bec1:	push   rsi
  40bec2:	push   rdi
  40bec3:	push   r12
  40bec5:	push   r13
  40bec7:	push   r14
  40bec9:	push   r15
  40becb:	sub    rsp,0x30
  40becf:	mov    rbx,rdx
  40bed2:	mov    QWORD PTR [rsp+0x18],rdx
  40bed7:	mov    rsi,rcx
  40beda:	mov    eax,0x1
  40bedf:	xchg   DWORD PTR [rbx+0x20],eax
  40bee2:	test   eax,eax
  40bee4:	je     40bef6 <__swc_fn_585f006d_000046_b30433d0+0x36>
  40bee6:	add    rsp,0x30
  40beea:	pop    r15
  40beec:	pop    r14
  40beee:	pop    r13
  40bef0:	pop    r12
  40bef2:	pop    rdi
  40bef3:	pop    rsi
  40bef4:	pop    rbx
  40bef5:	ret
  40bef6:	mov    rcx,rsi
  40bef9:	mov    rdx,rbx
  40befc:	mov    r8,0xffffffffffffffff
  40bf03:	call   408070 <__swc_fn_585f006d_000063_dea90857>
  40bf08:	lea    rdi,[rsi+0x10]
  40bf0c:	mov    QWORD PTR [rsp+0x20],rdi
  40bf11:	mov    rcx,rdi
  40bf14:	call   40df20 <__swc_fn_585f006d_000139_86bb0f90>
  40bf19:	xor    r12d,r12d
  40bf1c:	cs nop WORD PTR [rax+rax*1+0x0]
  40bf26:	cs nop WORD PTR [rax+rax*1+0x0]
  40bf30:	mov    eax,r12d
  40bf33:	lea    r13,[rax+rax*4]
  40bf37:	lea    r13,[rbx+r13*8+0x28]
  40bf3c:	mov    rax,QWORD PTR [r13+0x8]
  40bf40:	mov    QWORD PTR [rsp+0x8],rax
  40bf45:	mov    rax,QWORD PTR [r13+0x18]
  40bf49:	mov    QWORD PTR [rsp+0x10],rax
  40bf4e:	mov    r14d,0x2
  40bf54:	xor    r15d,r15d
  40bf57:	test   r14,r14
  40bf5a:	je     40bfd7 <__swc_fn_585f006d_000046_b30433d0+0x117>
  40bf60:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  40bf65:	mov    rdi,rax
  40bf68:	test   rdi,rdi
  40bf6b:	je     40bfc9 <__swc_fn_585f006d_000046_b30433d0+0x109>
  40bf6d:	nop    DWORD PTR [rax]
  40bf70:	mov    rbx,QWORD PTR [rdi+0x48]
  40bf74:	mov    DWORD PTR [rdi+0x6c],0x0
  40bf7b:	mov    rcx,rdi
  40bf7e:	call   40ba80 <__swc_fn_585f006d_000013_e4b0ddfc>
  40bf83:	cmp    DWORD PTR [rdi+0x28],0x0
  40bf87:	jne    40bfa0 <__swc_fn_585f006d_000046_b30433d0+0xe0>
  40bf89:	mov    rax,rdi
  40bf8c:	and    rax,0xffffffffffc00000
  40bf93:	mov    rcx,rax
  40bf96:	mov    rdx,rdi
  40bf99:	call   407790 <__swc_fn_585f006d_000018_283e2b5e>
  40bf9e:	jmp    40bfc1 <__swc_fn_585f006d_000046_b30433d0+0x101>
  40bfa0:	mov    QWORD PTR [rdi+0x40],0x0
  40bfa8:	rex mov BYTE PTR [rdi+0x3b],0x2
  40bfad:	mov    QWORD PTR [rdi+0x50],0x0
  40bfb5:	mov    rax,QWORD PTR [rsi+0x28]
  40bfb9:	mov    QWORD PTR [rdi+0x48],rax
  40bfbd:	mov    QWORD PTR [rsi+0x28],rdi
  40bfc1:	mov    rdi,rbx
  40bfc4:	test   rbx,rbx
  40bfc7:	jne    40bf70 <__swc_fn_585f006d_000046_b30433d0+0xb0>
  40bfc9:	add    r15,0x1
  40bfcd:	sub    r14,0x1
  40bfd1:	jne    40bf60 <__swc_fn_585f006d_000046_b30433d0+0xa0>
  40bfd7:	vxorps xmm0,xmm0,xmm0
  40bfdb:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  40bfe1:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40bfe7:	mov    QWORD PTR [r13+0x20],0x0
  40bfef:	add    r12,0x1
  40bff3:	cmp    r12,0x2d
  40bff7:	mov    rbx,QWORD PTR [rsp+0x18]
  40bffc:	jb     40bf30 <__swc_fn_585f006d_000046_b30433d0+0x70>
  40c002:	mov    rcx,rsi
  40c005:	mov    rbx,QWORD PTR [rsp+0x18]
  40c00a:	mov    rdx,rbx
  40c00d:	mov    rdi,QWORD PTR [rsp+0x20]
  40c012:	call   40f220 <__swc_fn_585f006d_000047_6e7a8d58>
  40c017:	mov    rcx,rdi
  40c01a:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40c01f:	mov    rcx,rsi
  40c022:	mov    rdx,rbx
  40c025:	mov    r8d,0x9b8
  40c02b:	mov    r9d,0x9b8
  40c031:	call   40bde0 <__swc_fn_585f006d_000043_d3c2ab54>
  40c036:	add    rsp,0x30
  40c03a:	pop    r15
  40c03c:	pop    r14
  40c03e:	pop    r13
  40c040:	pop    r12
  40c042:	pop    rdi
  40c043:	pop    rsi
  40c044:	pop    rbx
  40c045:	ret
	...

000000000040c060 <__swc_fn_585f006d_000049_ad48ec88>:
  40c060:	push   rbx
  40c061:	push   rsi
  40c062:	push   rdi
  40c063:	push   r12
  40c065:	push   r13
  40c067:	push   r14
  40c069:	push   r15
  40c06b:	sub    rsp,0x30
  40c06f:	mov    ebx,r8d
  40c072:	mov    rsi,rcx
  40c075:	mov    rdi,rdx
  40c078:	test   r8d,r8d
  40c07b:	jne    40c084 <__swc_fn_585f006d_000049_ad48ec88+0x24>
  40c07d:	mov    eax,0x8
  40c082:	jmp    40c0ab <__swc_fn_585f006d_000049_ad48ec88+0x4b>
  40c084:	cmp    ebx,0x8
  40c087:	ja     40c092 <__swc_fn_585f006d_000049_ad48ec88+0x32>
  40c089:	mov    rax,rbx
  40c08c:	shl    rax,0x4
  40c090:	jmp    40c0ab <__swc_fn_585f006d_000049_ad48ec88+0x4b>
  40c092:	lea    eax,[rbx-0x9]
  40c095:	mov    ecx,eax
  40c097:	shr    ecx,0x2
  40c09a:	and    eax,0x3
  40c09d:	lea    ecx,[rcx+0x7]
  40c0a0:	lea    ecx,[rcx-0x2]
  40c0a3:	lea    eax,[rax+0x5]
  40c0a6:	shlx   rax,rax,rcx
  40c0ab:	lea    r12,[rsp+0x8]
  40c0b0:	mov    DWORD PTR [rsp+0x8],eax
  40c0b4:	lea    r13,[rsp+0xc]
  40c0b9:	mov    QWORD PTR [rsp+0x18],r13
  40c0be:	xor    eax,eax
  40c0c0:	cmp    ebx,0x21
  40c0c3:	setae  al
  40c0c6:	lea    eax,[rax+rax*2]
  40c0c9:	mov    DWORD PTR [rsp+0xc],eax
  40c0cd:	lea    r14,[rsi+0x10]
  40c0d1:	mov    rcx,r14
  40c0d4:	call   40df20 <__swc_fn_585f006d_000139_86bb0f90>
  40c0d9:	xor    eax,eax
  40c0db:	mov    rcx,QWORD PTR [rsi+0x28]
  40c0df:	mov    r15,rcx
  40c0e2:	test   r15,r15
  40c0e5:	je     40c196 <__swc_fn_585f006d_000049_ad48ec88+0x136>
  40c0eb:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0f5:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0ff:	nop
  40c100:	mov    rcx,QWORD PTR [r15+0x48]
  40c104:	movzx  edx,BYTE PTR [r15+0x39]
  40c109:	cmp    edx,ebx
  40c10b:	jne    40c187 <__swc_fn_585f006d_000049_ad48ec88+0x127>
  40c10d:	test   rax,rax
  40c110:	jne    40c118 <__swc_fn_585f006d_000049_ad48ec88+0xb8>
  40c112:	mov    QWORD PTR [rsi+0x28],rcx
  40c116:	jmp    40c11c <__swc_fn_585f006d_000049_ad48ec88+0xbc>
  40c118:	mov    QWORD PTR [rax+0x48],rcx
  40c11c:	vxorps xmm0,xmm0,xmm0
  40c120:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  40c126:	mov    BYTE PTR [r15+0x3b],0x1
  40c12b:	mov    QWORD PTR [r15+0x40],rdi
  40c12f:	mov    rcx,r15
  40c132:	call   40ba80 <__swc_fn_585f006d_000013_e4b0ddfc>
  40c137:	movzx  eax,BYTE PTR [r15+0x39]
  40c13c:	lea    rax,[rax+rax*4]
  40c140:	lea    rax,[rdi+rax*8+0x28]
  40c145:	mov    rcx,QWORD PTR [rax+0x10]
  40c149:	mov    QWORD PTR [r15+0x50],rcx
  40c14d:	mov    QWORD PTR [r15+0x48],0x0
  40c155:	mov    rcx,QWORD PTR [rax+0x10]
  40c159:	test   rcx,rcx
  40c15c:	je     40c164 <__swc_fn_585f006d_000049_ad48ec88+0x104>
  40c15e:	mov    QWORD PTR [rcx+0x48],r15
  40c162:	jmp    40c168 <__swc_fn_585f006d_000049_ad48ec88+0x108>
  40c164:	mov    QWORD PTR [rax+0x8],r15
  40c168:	mov    QWORD PTR [rax+0x10],r15
  40c16c:	mov    rcx,r14
  40c16f:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40c174:	mov    rax,r15
  40c177:	add    rsp,0x30
  40c17b:	pop    r15
  40c17d:	pop    r14
  40c17f:	pop    r13
  40c181:	pop    r12
  40c183:	pop    rdi
  40c184:	pop    rsi
  40c185:	pop    rbx
  40c186:	ret
  40c187:	mov    rax,r15
  40c18a:	mov    r15,rcx
  40c18d:	test   rcx,rcx
  40c190:	jne    40c100 <__swc_fn_585f006d_000049_ad48ec88+0xa0>
  40c196:	mov    rax,QWORD PTR [rsi+0x18]
  40c19a:	mov    r15,rax
  40c19d:	test   r15,r15
  40c1a0:	je     40c236 <__swc_fn_585f006d_000049_ad48ec88+0x1d6>
  40c1a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40c1b0:	mov    eax,DWORD PTR [rsp+0xc]
  40c1b4:	cmp    DWORD PTR [r15+0x28],eax
  40c1b8:	jne    40c226 <__swc_fn_585f006d_000049_ad48ec88+0x1c6>
  40c1ba:	mov    rcx,r15
  40c1bd:	mov    edx,ebx
  40c1bf:	mov    rax,r12
  40c1c2:	mov    r8d,DWORD PTR [rax]
  40c1c5:	call   40ec60 <__swc_fn_585f006d_000017_efc44797>
  40c1ca:	mov    r13,rax
  40c1cd:	test   rax,rax
  40c1d0:	je     40c226 <__swc_fn_585f006d_000049_ad48ec88+0x1c6>
  40c1d2:	mov    QWORD PTR [r13+0x40],rdi
  40c1d6:	movzx  eax,BYTE PTR [r13+0x39]
  40c1db:	lea    rax,[rax+rax*4]
  40c1df:	lea    rax,[rdi+rax*8+0x28]
  40c1e4:	mov    rcx,QWORD PTR [rax+0x10]
  40c1e8:	mov    QWORD PTR [r13+0x50],rcx
  40c1ec:	mov    QWORD PTR [r13+0x48],0x0
  40c1f4:	mov    rcx,QWORD PTR [rax+0x10]
  40c1f8:	test   rcx,rcx
  40c1fb:	je     40c203 <__swc_fn_585f006d_000049_ad48ec88+0x1a3>
  40c1fd:	mov    QWORD PTR [rcx+0x48],r13
  40c201:	jmp    40c207 <__swc_fn_585f006d_000049_ad48ec88+0x1a7>
  40c203:	mov    QWORD PTR [rax+0x8],r13
  40c207:	mov    QWORD PTR [rax+0x10],r13
  40c20b:	mov    rcx,r14
  40c20e:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40c213:	mov    rax,r13
  40c216:	add    rsp,0x30
  40c21a:	pop    r15
  40c21c:	pop    r14
  40c21e:	pop    r13
  40c220:	pop    r12
  40c222:	pop    rdi
  40c223:	pop    rsi
  40c224:	pop    rbx
  40c225:	ret
  40c226:	mov    rax,QWORD PTR [r15+0x10]
  40c22a:	mov    r15,rax
  40c22d:	test   rax,rax
  40c230:	jne    40c1b0 <__swc_fn_585f006d_000049_ad48ec88+0x150>
  40c236:	mov    rcx,rsi
  40c239:	mov    r13,QWORD PTR [rsp+0x18]
  40c23e:	mov    edx,DWORD PTR [r13+0x0]
  40c242:	call   407910 <__swc_fn_585f006d_000024_2685aade>
  40c247:	mov    r13,rax
  40c24a:	test   rax,rax
  40c24d:	jne    40c269 <__swc_fn_585f006d_000049_ad48ec88+0x209>
  40c24f:	mov    rcx,r14
  40c252:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40c257:	xor    eax,eax
  40c259:	add    rsp,0x30
  40c25d:	pop    r15
  40c25f:	pop    r14
  40c261:	pop    r13
  40c263:	pop    r12
  40c265:	pop    rdi
  40c266:	pop    rsi
  40c267:	pop    rbx
  40c268:	ret
  40c269:	mov    rcx,r13
  40c26c:	mov    edx,ebx
  40c26e:	mov    r8d,DWORD PTR [r12]
  40c272:	call   40ec60 <__swc_fn_585f006d_000017_efc44797>
  40c277:	mov    rbx,rax
  40c27a:	test   rax,rax
  40c27d:	jne    40c2a1 <__swc_fn_585f006d_000049_ad48ec88+0x241>
  40c27f:	mov    rcx,r13
  40c282:	call   40bcc0 <__swc_fn_585f006d_000025_aa910677>
  40c287:	mov    rcx,r14
  40c28a:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40c28f:	xor    eax,eax
  40c291:	add    rsp,0x30
  40c295:	pop    r15
  40c297:	pop    r14
  40c299:	pop    r13
  40c29b:	pop    r12
  40c29d:	pop    rdi
  40c29e:	pop    rsi
  40c29f:	pop    rbx
  40c2a0:	ret
  40c2a1:	mov    rax,QWORD PTR [rsi+0x18]
  40c2a5:	mov    QWORD PTR [r13+0x10],rax
  40c2a9:	mov    rax,QWORD PTR [rsi+0x18]
  40c2ad:	test   rax,rax
  40c2b0:	je     40c2b6 <__swc_fn_585f006d_000049_ad48ec88+0x256>
  40c2b2:	mov    QWORD PTR [rax+0x18],r13
  40c2b6:	mov    QWORD PTR [rsi+0x18],r13
  40c2ba:	mov    QWORD PTR [rbx+0x40],rdi
  40c2be:	movzx  eax,BYTE PTR [rbx+0x39]
  40c2c2:	lea    rax,[rax+rax*4]
  40c2c6:	lea    rax,[rdi+rax*8+0x28]
  40c2cb:	mov    rcx,QWORD PTR [rax+0x10]
  40c2cf:	mov    QWORD PTR [rbx+0x50],rcx
  40c2d3:	mov    QWORD PTR [rbx+0x48],0x0
  40c2db:	mov    rcx,QWORD PTR [rax+0x10]
  40c2df:	test   rcx,rcx
  40c2e2:	je     40c2ea <__swc_fn_585f006d_000049_ad48ec88+0x28a>
  40c2e4:	mov    QWORD PTR [rcx+0x48],rbx
  40c2e8:	jmp    40c2ee <__swc_fn_585f006d_000049_ad48ec88+0x28e>
  40c2ea:	mov    QWORD PTR [rax+0x8],rbx
  40c2ee:	mov    QWORD PTR [rax+0x10],rbx
  40c2f2:	mov    rcx,r14
  40c2f5:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40c2fa:	mov    rax,rbx
  40c2fd:	add    rsp,0x30
  40c301:	pop    r15
  40c303:	pop    r14
  40c305:	pop    r13
  40c307:	pop    r12
  40c309:	pop    rdi
  40c30a:	pop    rsi
  40c30b:	pop    rbx
  40c30c:	ret
	...

000000000040c320 <__swc_fn_585f006d_000052_d846b172>:
  40c320:	push   rsi
  40c321:	push   rdi
  40c322:	push   r12
  40c324:	mov    rsi,rdx
  40c327:	mov    rdi,rcx
  40c32a:	lea    rax,[rcx+0x2a80]
  40c331:	mov    rcx,QWORD PTR [rax]
  40c334:	test   rcx,rcx
  40c337:	jne    40c33e <__swc_fn_585f006d_000052_d846b172+0x1e>
  40c339:	pop    r12
  40c33b:	pop    rdi
  40c33c:	pop    rsi
  40c33d:	ret
  40c33e:	xor    ecx,ecx
  40c340:	xchg   QWORD PTR [rax],rcx
  40c343:	mov    r12,rcx
  40c346:	cs nop WORD PTR [rax+rax*1+0x0]
  40c350:	cs nop WORD PTR [rax+rax*1+0x0]
  40c35a:	nop    WORD PTR [rax+rax*1+0x0]
  40c360:	test   r12,r12
  40c363:	je     40c3fa <__swc_fn_585f006d_000052_d846b172+0xda>
  40c369:	mov    r8,r12
  40c36c:	mov    r12,QWORD PTR [r12+0x78]
  40c371:	lea    rcx,[r8+0x70]
  40c375:	xor    eax,eax
  40c377:	xchg   DWORD PTR [r8+0x70],eax
  40c37b:	cmp    QWORD PTR [r8+0x40],rsi
  40c37f:	jne    40c396 <__swc_fn_585f006d_000052_d846b172+0x76>
  40c381:	mov    eax,DWORD PTR [r8+0x6c]
  40c385:	test   eax,eax
  40c387:	je     40c360 <__swc_fn_585f006d_000052_d846b172+0x40>
  40c389:	mov    rcx,rdi
  40c38c:	mov    rdx,rsi
  40c38f:	call   407cd0 <__swc_fn_585f006d_000051_e072b516>
  40c394:	jmp    40c360 <__swc_fn_585f006d_000052_d846b172+0x40>
  40c396:	mov    rax,QWORD PTR [r8+0x40]
  40c39a:	test   rax,rax
  40c39d:	je     40c360 <__swc_fn_585f006d_000052_d846b172+0x40>
  40c39f:	mov    eax,DWORD PTR [r8+0x6c]
  40c3a3:	test   eax,eax
  40c3a5:	je     40c360 <__swc_fn_585f006d_000052_d846b172+0x40>
  40c3a7:	mov    r9d,0x1
  40c3ad:	xor    eax,eax
  40c3af:	lock cmpxchg DWORD PTR [rcx],r9d
  40c3b4:	test   eax,eax
  40c3b6:	jne    40c360 <__swc_fn_585f006d_000052_d846b172+0x40>
  40c3b8:	mov    rax,r8
  40c3bb:	and    rax,0xffffffffffc00000
  40c3c2:	mov    rax,QWORD PTR [rax+0x8]
  40c3c6:	test   rax,rax
  40c3c9:	jne    40c3d1 <__swc_fn_585f006d_000052_d846b172+0xb1>
  40c3cb:	xor    eax,eax
  40c3cd:	xchg   DWORD PTR [rcx],eax
  40c3cf:	jmp    40c360 <__swc_fn_585f006d_000052_d846b172+0x40>
  40c3d1:	lea    rcx,[rax+0x2a80]
  40c3d8:	mov    rax,QWORD PTR [rcx]
  40c3db:	mov    rdx,rax
  40c3de:	xchg   ax,ax
  40c3e0:	mov    QWORD PTR [r8+0x78],rdx
  40c3e4:	mov    rax,rdx
  40c3e7:	lock cmpxchg QWORD PTR [rcx],r8
  40c3ec:	cmp    rax,rdx
  40c3ef:	je     40c360 <__swc_fn_585f006d_000052_d846b172+0x40>
  40c3f5:	mov    rdx,rax
  40c3f8:	jmp    40c3e0 <__swc_fn_585f006d_000052_d846b172+0xc0>
  40c3fa:	pop    r12
  40c3fc:	pop    rdi
  40c3fd:	pop    rsi
  40c3fe:	ret
	...

000000000040c400 <__swc_fn_585f006d_000055_2e3450f7>:
  40c400:	sub    rsp,0x8
  40c404:	mov    r9,r8
  40c407:	movzx  eax,BYTE PTR [r9+0x39]
  40c40c:	lea    rax,[rax+rax*4]
  40c410:	lea    rax,[rdx+rax*8+0x28]
  40c415:	cmp    QWORD PTR [rax],r9
  40c418:	je     40c420 <__swc_fn_585f006d_000055_2e3450f7+0x20>
  40c41a:	cmp    QWORD PTR [rax+0x20],r9
  40c41e:	jne    40c425 <__swc_fn_585f006d_000055_2e3450f7+0x25>
  40c420:	add    rsp,0x8
  40c424:	ret
  40c425:	cmp    QWORD PTR [rax+0x20],0x0
  40c42a:	je     40c437 <__swc_fn_585f006d_000055_2e3450f7+0x37>
  40c42c:	mov    r8,QWORD PTR [rax+0x20]
  40c430:	cmp    DWORD PTR [r8+0x28],0x0
  40c435:	je     40c440 <__swc_fn_585f006d_000055_2e3450f7+0x40>
  40c437:	mov    QWORD PTR [rax+0x20],r9
  40c43b:	add    rsp,0x8
  40c43f:	ret
  40c440:	mov    r8,r9
  40c443:	call   407c30 <__swc_fn_585f006d_000048_137687bb>
  40c448:	mov    rax,r9
  40c44b:	and    rax,0xffffffffffc00000
  40c452:	mov    rcx,rax
  40c455:	mov    rdx,r9
  40c458:	call   407790 <__swc_fn_585f006d_000018_283e2b5e>
  40c45d:	add    rsp,0x8
  40c461:	ret
	...

000000000040c470 <__swc_fn_585f006d_000058_1bb23e77>:
  40c470:	push   rsi
  40c471:	push   rdi
  40c472:	push   r12
  40c474:	mov    rsi,rdx
  40c477:	mov    rax,rdx
  40c47a:	shr    rax,0xc
  40c47e:	movabs rdx,0x9e3779b97f4a7c15
  40c488:	imul   rax,rdx
  40c48c:	shr    rax,0x20
  40c490:	lea    rax,[rax*8+0x0]
  40c498:	shr    rax,0x20
  40c49c:	lea    rax,[rax*8+0x0]
  40c4a4:	lea    rax,[rcx+rax*8+0x40]
  40c4a9:	xor    edx,edx
  40c4ab:	test   dl,dl
  40c4ad:	lea    rdi,[rcx+0x8]
  40c4b1:	cmove  rdi,rax
  40c4b5:	xor    edx,edx
  40c4b7:	test   dl,dl
  40c4b9:	lea    r12,[rcx+0x30]
  40c4bd:	lea    rax,[rax+0x8]
  40c4c1:	cmove  r12,rax
  40c4c5:	mov    rcx,rdi
  40c4c8:	call   40df20 <__swc_fn_585f006d_000139_86bb0f90>
  40c4cd:	mov    rax,QWORD PTR [rsi+0x30]
  40c4d1:	test   rax,rax
  40c4d4:	jne    40c4e0 <__swc_fn_585f006d_000058_1bb23e77+0x70>
  40c4d6:	mov    rax,QWORD PTR [rsi+0x38]
  40c4da:	mov    QWORD PTR [r12],rax
  40c4de:	jmp    40c4e8 <__swc_fn_585f006d_000058_1bb23e77+0x78>
  40c4e0:	mov    rcx,QWORD PTR [rsi+0x38]
  40c4e4:	mov    QWORD PTR [rax+0x38],rcx
  40c4e8:	mov    rax,QWORD PTR [rsi+0x38]
  40c4ec:	test   rax,rax
  40c4ef:	je     40c4f9 <__swc_fn_585f006d_000058_1bb23e77+0x89>
  40c4f1:	mov    rcx,QWORD PTR [rsi+0x30]
  40c4f5:	mov    QWORD PTR [rax+0x30],rcx
  40c4f9:	vxorps xmm0,xmm0,xmm0
  40c4fd:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  40c502:	mov    rcx,rdi
  40c505:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40c50a:	pop    r12
  40c50c:	pop    rdi
  40c50d:	pop    rsi
  40c50e:	ret
	...

000000000040c510 <__swc_fn_585f006d_000061_ad030a10>:
  40c510:	mov    rax,QWORD PTR [rcx+0x250]
  40c517:	mov    rcx,rax
  40c51a:	cmp    rax,0x1000000
  40c521:	mov    eax,0x1000000
  40c526:	cmovb  rcx,rax
  40c52a:	mov    rax,rcx
  40c52d:	cmp    rcx,0x10000000
  40c534:	mov    ecx,0x10000000
  40c539:	cmova  rax,rcx
  40c53d:	ret
	...

000000000040c540 <__swc_fn_585f006d_000064_ffcd96eb>:
  40c540:	push   rsi
  40c541:	push   rdi
  40c542:	push   r12
  40c544:	mov    rsi,rcx
  40c547:	mov    rdi,QWORD PTR [rsi+0x2a70]
  40c54e:	xor    r12d,r12d
  40c551:	test   rdi,rdi
  40c554:	jbe    40c58b <__swc_fn_585f006d_000064_ffcd96eb+0x4b>
  40c556:	cs nop WORD PTR [rax+rax*1+0x0]
  40c560:	lea    rax,[r12+r12*4]
  40c564:	lea    rax,[rsi+rax*8+0x268]
  40c56c:	mov    rcx,rsi
  40c56f:	mov    rdx,QWORD PTR [rax]
  40c572:	mov    r8,QWORD PTR [rax+0x8]
  40c576:	mov    rax,QWORD PTR [rax+0x10]
  40c57a:	mov    r9,rax
  40c57d:	call   40bde0 <__swc_fn_585f006d_000043_d3c2ab54>
  40c582:	add    r12,0x1
  40c586:	cmp    r12,rdi
  40c589:	jb     40c560 <__swc_fn_585f006d_000064_ffcd96eb+0x20>
  40c58b:	vxorps xmm0,xmm0,xmm0
  40c58f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  40c597:	pop    r12
  40c599:	pop    rdi
  40c59a:	pop    rsi
  40c59b:	ret
  40c59c:	add    BYTE PTR [rax],al
	...

000000000040c5a0 <__swc_fn_585f006d_000067_8c7d044b>:
  40c5a0:	push   rsi
  40c5a1:	push   rdi
  40c5a2:	sub    rsp,0x8
  40c5a6:	mov    rsi,rcx
  40c5a9:	call   40f5a0 <__swc_fn_585f006d_000056_df0696cd>
  40c5ae:	mov    rdi,rax
  40c5b1:	mov    rcx,rsi
  40c5b4:	mov    rdx,rax
  40c5b7:	call   40c470 <__swc_fn_585f006d_000058_1bb23e77>
  40c5bc:	mov    rcx,QWORD PTR [rdi+0x28]
  40c5c0:	mov    rdx,QWORD PTR [rsi+0x250]
  40c5c7:	nop    WORD PTR [rax+rax*1+0x0]
  40c5d0:	mov    r8,rdx
  40c5d3:	sub    r8,rcx
  40c5d6:	mov    rax,rdx
  40c5d9:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40c5e2:	cmp    rax,rdx
  40c5e5:	je     40c5ec <__swc_fn_585f006d_000067_8c7d044b+0x4c>
  40c5e7:	mov    rdx,rax
  40c5ea:	jmp    40c5d0 <__swc_fn_585f006d_000067_8c7d044b+0x30>
  40c5ec:	mov    rcx,rsi
  40c5ef:	mov    rdx,QWORD PTR [rdi]
  40c5f2:	mov    r8,QWORD PTR [rdi+0x8]
  40c5f6:	mov    r9,QWORD PTR [rdi+0x10]
  40c5fa:	call   40f6c0 <__swc_fn_585f006d_000062_b304235a>
  40c5ff:	mov    rcx,rsi
  40c602:	call   40f300 <__swc_fn_585f006d_000053_3af34d7f>
  40c607:	add    rsp,0x8
  40c60b:	pop    rdi
  40c60c:	pop    rsi
  40c60d:	ret
	...

000000000040c610 <__swc_fn_585f006d_000070_97813b89>:
  40c610:	push   r12
  40c612:	push   r13
  40c614:	push   r14
  40c616:	push   rdi
  40c617:	push   rsi
  40c618:	sub    rsp,0x1b0
  40c61f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  40c628:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  40c631:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  40c63a:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  40c643:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  40c64c:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  40c655:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  40c65e:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  40c667:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  40c670:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  40c679:	mov    r8,rdx
  40c67c:	mov    r12,rcx
  40c67f:	mov    r13,QWORD PTR [r8+0x40]
  40c683:	test   r13,r13
  40c686:	jne    40c698 <__swc_fn_585f006d_000070_97813b89+0x88>
  40c688:	add    rsp,0x1b0
  40c68f:	pop    rsi
  40c690:	pop    rdi
  40c691:	pop    r14
  40c693:	pop    r13
  40c695:	pop    r12
  40c697:	ret
  40c698:	mov    QWORD PTR [r8+0x40],0x0
  40c6a0:	lea    rax,[rip+0x169d1]        # 423078 <__swc_bss_base_585f006d+0x38>
  40c6a7:	mov    rcx,r13
  40c6aa:	sub    rcx,QWORD PTR [rax+0x8]
  40c6ae:	mov    rax,QWORD PTR [rip+0x169d3]        # 423088 <__swc_bss_base_585f006d+0x48>
  40c6b5:	cmp    rcx,rax
  40c6b8:	jae    40c6e4 <__swc_fn_585f006d_000070_97813b89+0xd4>
  40c6ba:	mov    rax,r13
  40c6bd:	and    rax,0xffffffffffc00000
  40c6c4:	mov    rcx,r13
  40c6c7:	shr    rcx,0x10
  40c6cb:	and    ecx,0x3f
  40c6ce:	mov    edx,DWORD PTR [rax+0x28]
  40c6d1:	shrx   ecx,ecx,edx
  40c6d6:	shl    rcx,0x4
  40c6da:	lea    r14,[rax+rcx*8+0x80]
  40c6e2:	jmp    40c6ff <__swc_fn_585f006d_000070_97813b89+0xef>
  40c6e4:	mov    rcx,r13
  40c6e7:	mov    QWORD PTR [rsp+0xf8],r8
  40c6ef:	call   40ef90 <__swc_fn_585f006d_000026_bcdc5519>
  40c6f4:	mov    r8,QWORD PTR [rsp+0xf8]
  40c6fc:	mov    r14,rax
  40c6ff:	test   r14,r14
  40c702:	jne    40c714 <__swc_fn_585f006d_000070_97813b89+0x104>
  40c704:	mov    rcx,r12
  40c707:	mov    rdx,r13
  40c70a:	call   40c5a0 <__swc_fn_585f006d_000067_8c7d044b>
  40c70f:	jmp    40c7a2 <__swc_fn_585f006d_000070_97813b89+0x192>
  40c714:	lea    rax,[rip+0x148e5]        # 421000 <__swc_data_base_585f006d>
  40c71b:	mov    rax,QWORD PTR [rax]
  40c71e:	cmp    rax,0xffffffffffffffff
  40c722:	je     40c731 <__swc_fn_585f006d_000070_97813b89+0x121>
  40c724:	mov    eax,eax
  40c726:	mov    edi,eax
  40c728:	xor    eax,eax
  40c72a:	call   407000 <pthread_getspecific@plt>
  40c72f:	jmp    40c733 <__swc_fn_585f006d_000070_97813b89+0x123>
  40c731:	xor    eax,eax
  40c733:	test   rax,rax
  40c736:	jne    40c745 <__swc_fn_585f006d_000070_97813b89+0x135>
  40c738:	call   40f060 <__swc_fn_585f006d_000035_cd1a4e8c>
  40c73d:	mov    rcx,rax
  40c740:	call   409c60 <__swc_fn_585f006d_000132_5f757033>
  40c745:	test   rax,rax
  40c748:	je     40c797 <__swc_fn_585f006d_000070_97813b89+0x187>
  40c74a:	cmp    QWORD PTR [r14+0x40],rax
  40c74e:	jne    40c797 <__swc_fn_585f006d_000070_97813b89+0x187>
  40c750:	mov    ecx,DWORD PTR [r14+0x6c]
  40c754:	test   ecx,ecx
  40c756:	je     40c776 <__swc_fn_585f006d_000070_97813b89+0x166>
  40c758:	mov    rcx,r12
  40c75b:	mov    rdx,rax
  40c75e:	mov    r8,r14
  40c761:	mov    QWORD PTR [rsp+0x100],rax
  40c769:	call   407cd0 <__swc_fn_585f006d_000051_e072b516>
  40c76e:	mov    rax,QWORD PTR [rsp+0x100]
  40c776:	mov    rcx,QWORD PTR [r14]
  40c779:	mov    QWORD PTR [r13+0x0],rcx
  40c77d:	mov    QWORD PTR [r14],r13
  40c780:	sub    DWORD PTR [r14+0x28],0x1
  40c785:	jne    40c7a2 <__swc_fn_585f006d_000070_97813b89+0x192>
  40c787:	mov    rcx,r12
  40c78a:	mov    rdx,rax
  40c78d:	mov    r8,r14
  40c790:	call   40c400 <__swc_fn_585f006d_000055_2e3450f7>
  40c795:	jmp    40c7a2 <__swc_fn_585f006d_000070_97813b89+0x192>
  40c797:	mov    rcx,r14
  40c79a:	mov    rdx,r13
  40c79d:	call   40ebd0 <__swc_fn_585f006d_000014_524c1f23>
  40c7a2:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40c7ab:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  40c7b4:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40c7bd:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  40c7c6:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40c7cf:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  40c7d8:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  40c7e1:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40c7ea:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  40c7f3:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40c7fc:	add    rsp,0x1b0
  40c803:	pop    rsi
  40c804:	pop    rdi
  40c805:	pop    r14
  40c807:	pop    r13
  40c809:	pop    r12
  40c80b:	ret
  40c80c:	add    BYTE PTR [rax],al
	...

000000000040c810 <__swc_fn_585f006d_000073_9c99bf04>:
  40c810:	push   rsi
  40c811:	mov    rsi,rcx
  40c814:	call   40bdd0 <__swc_fn_585f006d_000040_eb6108f2>
  40c819:	test   al,al
  40c81b:	jne    40c81f <__swc_fn_585f006d_000073_9c99bf04+0xf>
  40c81d:	pop    rsi
  40c81e:	ret
  40c81f:	lea    rax,[rip+0x16a1a]        # 423240 <__swc_bss_base_585f006d+0x200>
  40c826:	cmp    rsi,rax
  40c829:	jne    40c82d <__swc_fn_585f006d_000073_9c99bf04+0x1d>
  40c82b:	pop    rsi
  40c82c:	ret
  40c82d:	mov    rcx,rsi
  40c830:	call   40df20 <__swc_fn_585f006d_000139_86bb0f90>
  40c835:	mov    rcx,rsi
  40c838:	call   4084a0 <__swc_fn_585f006d_000072_61e60aab>
  40c83d:	mov    rcx,rsi
  40c840:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40c845:	pop    rsi
  40c846:	ret
	...

000000000040c850 <__swc_fn_585f006d_000076_15bd096c>:
  40c850:	sub    rsp,0x8
  40c854:	call   4081f0 <__swc_fn_585f006d_000069_7130736e>
  40c859:	add    rsp,0x8
  40c85d:	ret
	...

000000000040c860 <__swc_fn_585f006d_000079_a5fd3362>:
  40c860:	push   rsi
  40c861:	mov    rsi,rdx
  40c864:	call   4084a0 <__swc_fn_585f006d_000072_61e60aab>
  40c869:	mov    QWORD PTR [rsi+0x40],0x0
  40c871:	pop    rsi
  40c872:	ret
	...

000000000040c880 <__swc_fn_585f006d_000082_63a67586>:
  40c880:	mov    r8,rcx
  40c883:	mov    rcx,QWORD PTR [rcx]
  40c886:	cs nop WORD PTR [rax+rax*1+0x0]
  40c890:	mov    r9,rcx
  40c893:	sub    r9,rdx
  40c896:	mov    rax,rcx
  40c899:	lock cmpxchg QWORD PTR [r8],r9
  40c89e:	cmp    rax,rcx
  40c8a1:	je     40c8a8 <__swc_fn_585f006d_000082_63a67586+0x28>
  40c8a3:	mov    rcx,rax
  40c8a6:	jmp    40c890 <__swc_fn_585f006d_000082_63a67586+0x10>
  40c8a8:	mov    rax,rcx
  40c8ab:	ret
  40c8ac:	add    BYTE PTR [rax],al
	...

000000000040c8b0 <__swc_fn_585f006d_000085_c618ff58>:
  40c8b0:	vxorps xmm0,xmm0,xmm0
  40c8b4:	vmovups XMMWORD PTR [rcx],xmm0
  40c8b8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40c8bd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40c8c2:	ret
	...

000000000040c8d0 <__swc_fn_585f006d_000088_0d280354>:
  40c8d0:	push   rsi
  40c8d1:	push   rdi
  40c8d2:	push   r12
  40c8d4:	push   r13
  40c8d6:	push   r15
  40c8d8:	push   r14
  40c8da:	push   rbx
  40c8db:	sub    rsp,0x60
  40c8df:	mov    QWORD PTR [rsp+0x28],r11
  40c8e4:	mov    rsi,rcx
  40c8e7:	mov    rdi,rdx
  40c8ea:	mov    QWORD PTR [rsp+0x30],rdx
  40c8ef:	mov    r12,r8
  40c8f2:	mov    r13,r9
  40c8f5:	mov    QWORD PTR [rsp+0x38],r10
  40c8fa:	xor    r8d,r8d
  40c8fd:	call   40cc20 <__swc_fn_585f006d_000094_63c1827b>
  40c902:	test   al,al
  40c904:	je     40c919 <__swc_fn_585f006d_000088_0d280354+0x49>
  40c906:	mov    rax,r12
  40c909:	add    rsp,0x60
  40c90d:	pop    rbx
  40c90e:	pop    r14
  40c910:	pop    r15
  40c912:	pop    r13
  40c914:	pop    r12
  40c916:	pop    rdi
  40c917:	pop    rsi
  40c918:	ret
  40c919:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40c91e:	je     40c932 <__swc_fn_585f006d_000088_0d280354+0x62>
  40c920:	xor    eax,eax
  40c922:	add    rsp,0x60
  40c926:	pop    rbx
  40c927:	pop    r14
  40c929:	pop    r15
  40c92b:	pop    r13
  40c92d:	pop    r12
  40c92f:	pop    rdi
  40c930:	pop    rsi
  40c931:	ret
  40c932:	mov    r15,rdi
  40c935:	mov    QWORD PTR [rsp+0x40],rdi
  40c93a:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40c93f:	jne    40c9af <__swc_fn_585f006d_000088_0d280354+0xdf>
  40c941:	mov    r14,QWORD PTR [r15+0xb8]
  40c948:	mov    rax,QWORD PTR [r15+0xc0]
  40c94f:	mov    r15,rax
  40c952:	xor    edi,edi
  40c954:	test   r15,r15
  40c957:	je     40c9af <__swc_fn_585f006d_000088_0d280354+0xdf>
  40c959:	nop    DWORD PTR [rax+0x0]
  40c960:	lea    rbx,[rdi*8+0x0]
  40c968:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  40c96d:	mov    rcx,rax
  40c970:	mov    rdx,rsi
  40c973:	xor    r8d,r8d
  40c976:	call   40cc20 <__swc_fn_585f006d_000094_63c1827b>
  40c97b:	test   al,al
  40c97d:	je     40c9a5 <__swc_fn_585f006d_000088_0d280354+0xd5>
  40c97f:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  40c984:	test   rax,rax
  40c987:	je     40c9a5 <__swc_fn_585f006d_000088_0d280354+0xd5>
  40c989:	test   r13,r13
  40c98c:	je     40c992 <__swc_fn_585f006d_000088_0d280354+0xc2>
  40c98e:	mov    QWORD PTR [r13+0x8],rax
  40c992:	mov    rax,r12
  40c995:	add    rsp,0x60
  40c999:	pop    rbx
  40c99a:	pop    r14
  40c99c:	pop    r15
  40c99e:	pop    r13
  40c9a0:	pop    r12
  40c9a2:	pop    rdi
  40c9a3:	pop    rsi
  40c9a4:	ret
  40c9a5:	add    rdi,0x1
  40c9a9:	sub    r15,0x1
  40c9ad:	jne    40c960 <__swc_fn_585f006d_000088_0d280354+0x90>
  40c9af:	test   r12,r12
  40c9b2:	jne    40c9c6 <__swc_fn_585f006d_000088_0d280354+0xf6>
  40c9b4:	xor    eax,eax
  40c9b6:	add    rsp,0x60
  40c9ba:	pop    rbx
  40c9bb:	pop    r14
  40c9bd:	pop    r15
  40c9bf:	pop    r13
  40c9c1:	pop    r12
  40c9c3:	pop    rdi
  40c9c4:	pop    rsi
  40c9c5:	ret
  40c9c6:	mov    rbx,QWORD PTR [rsp+0x28]
  40c9cb:	mov    rdi,QWORD PTR [rsp+0x30]
  40c9d0:	mov    rax,rbx
  40c9d3:	test   rax,rax
  40c9d6:	je     40ca06 <__swc_fn_585f006d_000088_0d280354+0x136>
  40c9d8:	nop    DWORD PTR [rax+rax*1+0x0]
  40c9e0:	cmp    QWORD PTR [rax+0x8],r12
  40c9e4:	jne    40c9fd <__swc_fn_585f006d_000088_0d280354+0x12d>
  40c9e6:	cmp    QWORD PTR [rax],rdi
  40c9e9:	jne    40c9fd <__swc_fn_585f006d_000088_0d280354+0x12d>
  40c9eb:	xor    eax,eax
  40c9ed:	add    rsp,0x60
  40c9f1:	pop    rbx
  40c9f2:	pop    r14
  40c9f4:	pop    r15
  40c9f6:	pop    r13
  40c9f8:	pop    r12
  40c9fa:	pop    rdi
  40c9fb:	pop    rsi
  40c9fc:	ret
  40c9fd:	mov    rax,QWORD PTR [rax+0x10]
  40ca01:	test   rax,rax
  40ca04:	jne    40c9e0 <__swc_fn_585f006d_000088_0d280354+0x110>
  40ca06:	lea    r14,[rsp+0x8]
  40ca0b:	mov    QWORD PTR [rsp+0x48],r14
  40ca10:	mov    QWORD PTR [rsp+0x8],rdi
  40ca15:	mov    QWORD PTR [rsp+0x10],r12
  40ca1a:	mov    QWORD PTR [rsp+0x18],rbx
  40ca1f:	mov    r15,QWORD PTR [rsp+0x40]
  40ca24:	mov    rbx,QWORD PTR [r15+0x98]
  40ca2b:	mov    rax,QWORD PTR [r15+0xa0]
  40ca32:	mov    rdi,rax
  40ca35:	mov    r15,QWORD PTR [rsp+0x38]
  40ca3a:	xor    r14d,r14d
  40ca3d:	test   rdi,rdi
  40ca40:	je     40caea <__swc_fn_585f006d_000088_0d280354+0x21a>
  40ca46:	cs nop WORD PTR [rax+rax*1+0x0]
  40ca50:	mov    QWORD PTR [rsp+0x50],rdi
  40ca55:	lea    rdi,[r14*8+0x0]
  40ca5d:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  40ca62:	mov    rcx,rax
  40ca65:	call   4106a0 <__swc_fn_585f006d_000086_3953ef98>
  40ca6a:	test   DWORD PTR [rax+0x28],0x10000
  40ca71:	je     40ca78 <__swc_fn_585f006d_000088_0d280354+0x1a8>
  40ca73:	test   r15b,r15b
  40ca76:	je     40cad1 <__swc_fn_585f006d_000088_0d280354+0x201>
  40ca78:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  40ca7c:	lea    rdi,[r12+rcx*1]
  40ca80:	cmp    BYTE PTR [rax+0x2c],0x6
  40ca84:	jne    40ca98 <__swc_fn_585f006d_000088_0d280354+0x1c8>
  40ca86:	mov    rax,QWORD PTR [rax+0x40]
  40ca8a:	mov    rcx,rax
  40ca8d:	call   4106a0 <__swc_fn_585f006d_000086_3953ef98>
  40ca92:	mov    rcx,QWORD PTR [rdi]
  40ca95:	mov    rdi,rcx
  40ca98:	test   rdi,rdi
  40ca9b:	je     40cad1 <__swc_fn_585f006d_000088_0d280354+0x201>
  40ca9d:	mov    rcx,rsi
  40caa0:	mov    rdx,rax
  40caa3:	mov    r8,rdi
  40caa6:	mov    r9,r13
  40caa9:	mov    al,r15b
  40caac:	mov    r10,rax
  40caaf:	mov    rdi,QWORD PTR [rsp+0x48]
  40cab4:	mov    r11,rdi
  40cab7:	call   40c8d0 <__swc_fn_585f006d_000088_0d280354>
  40cabc:	test   rax,rax
  40cabf:	je     40cad1 <__swc_fn_585f006d_000088_0d280354+0x201>
  40cac1:	add    rsp,0x60
  40cac5:	pop    rbx
  40cac6:	pop    r14
  40cac8:	pop    r15
  40caca:	pop    r13
  40cacc:	pop    r12
  40cace:	pop    rdi
  40cacf:	pop    rsi
  40cad0:	ret
  40cad1:	add    r14,0x1
  40cad5:	mov    rax,QWORD PTR [rsp+0x50]
  40cada:	sub    rax,0x1
  40cade:	mov    rdi,rax
  40cae1:	test   rax,rax
  40cae4:	jne    40ca50 <__swc_fn_585f006d_000088_0d280354+0x180>
  40caea:	xor    eax,eax
  40caec:	add    rsp,0x60
  40caf0:	pop    rbx
  40caf1:	pop    r14
  40caf3:	pop    r15
  40caf5:	pop    r13
  40caf7:	pop    r12
  40caf9:	pop    rdi
  40cafa:	pop    rsi
  40cafb:	ret
  40cafc:	add    BYTE PTR [rax],al
	...

000000000040cb00 <__swc_fn_585f006d_000091_c1c9085b>:
  40cb00:	push   rsi
  40cb01:	push   rdi
  40cb02:	push   r12
  40cb04:	push   r13
  40cb06:	push   r14
  40cb08:	push   r15
  40cb0a:	sub    rsp,0x78
  40cb0e:	mov    rsi,r10
  40cb11:	mov    QWORD PTR [rsp+0x68],r10
  40cb16:	mov    rdi,rcx
  40cb19:	mov    r12,rdx
  40cb1c:	mov    r13,r8
  40cb1f:	mov    r14,r9
  40cb22:	xor    r8d,r8d
  40cb25:	call   40cc20 <__swc_fn_585f006d_000094_63c1827b>
  40cb2a:	test   al,al
  40cb2c:	je     40cb55 <__swc_fn_585f006d_000091_c1c9085b+0x55>
  40cb2e:	mov    rcx,r14
  40cb31:	mov    rdx,r12
  40cb34:	mov    r8,r13
  40cb37:	mov    r9,rsi
  40cb3a:	call   408900 <__swc_fn_585f006d_000090_23214800>
  40cb3f:	test   al,al
  40cb41:	je     40cb55 <__swc_fn_585f006d_000091_c1c9085b+0x55>
  40cb43:	mov    rax,r13
  40cb46:	add    rsp,0x78
  40cb4a:	pop    r15
  40cb4c:	pop    r14
  40cb4e:	pop    r13
  40cb50:	pop    r12
  40cb52:	pop    rdi
  40cb53:	pop    rsi
  40cb54:	ret
  40cb55:	cmp    BYTE PTR [r12+0x2c],0xe
  40cb5b:	je     40cb6e <__swc_fn_585f006d_000091_c1c9085b+0x6e>
  40cb5d:	xor    eax,eax
  40cb5f:	add    rsp,0x78
  40cb63:	pop    r15
  40cb65:	pop    r14
  40cb67:	pop    r13
  40cb69:	pop    r12
  40cb6b:	pop    rdi
  40cb6c:	pop    rsi
  40cb6d:	ret
  40cb6e:	mov    r15,QWORD PTR [r12+0x98]
  40cb76:	mov    rax,QWORD PTR [r12+0xa0]
  40cb7e:	mov    r12,rax
  40cb81:	xor    esi,esi
  40cb83:	test   r12,r12
  40cb86:	je     40cbf9 <__swc_fn_585f006d_000091_c1c9085b+0xf9>
  40cb88:	nop    DWORD PTR [rax+rax*1+0x0]
  40cb90:	mov    QWORD PTR [rsp+0x70],r12
  40cb95:	lea    r12,[rsi*8+0x0]
  40cb9d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  40cba2:	mov    rcx,rax
  40cba5:	call   4106a0 <__swc_fn_585f006d_000086_3953ef98>
  40cbaa:	cmp    BYTE PTR [rax+0x2c],0xe
  40cbae:	jne    40cbe4 <__swc_fn_585f006d_000091_c1c9085b+0xe4>
  40cbb0:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  40cbb5:	lea    r8,[r13+rcx*1+0x0]
  40cbba:	mov    rcx,rdi
  40cbbd:	mov    rdx,rax
  40cbc0:	mov    r9,r14
  40cbc3:	mov    r12,QWORD PTR [rsp+0x68]
  40cbc8:	mov    r10,r12
  40cbcb:	call   40cb00 <__swc_fn_585f006d_000091_c1c9085b>
  40cbd0:	test   rax,rax
  40cbd3:	je     40cbe4 <__swc_fn_585f006d_000091_c1c9085b+0xe4>
  40cbd5:	add    rsp,0x78
  40cbd9:	pop    r15
  40cbdb:	pop    r14
  40cbdd:	pop    r13
  40cbdf:	pop    r12
  40cbe1:	pop    rdi
  40cbe2:	pop    rsi
  40cbe3:	ret
  40cbe4:	add    rsi,0x1
  40cbe8:	mov    rax,QWORD PTR [rsp+0x70]
  40cbed:	sub    rax,0x1
  40cbf1:	mov    r12,rax
  40cbf4:	test   rax,rax
  40cbf7:	jne    40cb90 <__swc_fn_585f006d_000091_c1c9085b+0x90>
  40cbf9:	xor    eax,eax
  40cbfb:	add    rsp,0x78
  40cbff:	pop    r15
  40cc01:	pop    r14
  40cc03:	pop    r13
  40cc05:	pop    r12
  40cc07:	pop    rdi
  40cc08:	pop    rsi
  40cc09:	ret
	...

000000000040cc20 <__swc_fn_585f006d_000094_63c1827b>:
  40cc20:	push   rbx
  40cc21:	push   rsi
  40cc22:	push   rdi
  40cc23:	push   r12
  40cc25:	push   r13
  40cc27:	push   r14
  40cc29:	push   r15
  40cc2b:	sub    rsp,0x120
  40cc32:	mov    rbx,r8
  40cc35:	mov    rsi,rdx
  40cc38:	test   rcx,rcx
  40cc3b:	jne    40cc5a <__swc_fn_585f006d_000094_63c1827b+0x3a>
  40cc3d:	test   rsi,rsi
  40cc40:	jne    40cc5a <__swc_fn_585f006d_000094_63c1827b+0x3a>
  40cc42:	mov    eax,0x1
  40cc47:	add    rsp,0x120
  40cc4e:	pop    r15
  40cc50:	pop    r14
  40cc52:	pop    r13
  40cc54:	pop    r12
  40cc56:	pop    rdi
  40cc57:	pop    rsi
  40cc58:	pop    rbx
  40cc59:	ret
  40cc5a:	test   rcx,rcx
  40cc5d:	je     40cc64 <__swc_fn_585f006d_000094_63c1827b+0x44>
  40cc5f:	test   rsi,rsi
  40cc62:	jne    40cc79 <__swc_fn_585f006d_000094_63c1827b+0x59>
  40cc64:	xor    eax,eax
  40cc66:	add    rsp,0x120
  40cc6d:	pop    r15
  40cc6f:	pop    r14
  40cc71:	pop    r13
  40cc73:	pop    r12
  40cc75:	pop    rdi
  40cc76:	pop    rsi
  40cc77:	pop    rbx
  40cc78:	ret
  40cc79:	call   4106a0 <__swc_fn_585f006d_000086_3953ef98>
  40cc7e:	mov    rdi,rax
  40cc81:	mov    rcx,rsi
  40cc84:	call   4106a0 <__swc_fn_585f006d_000086_3953ef98>
  40cc89:	test   bl,0x1
  40cc8c:	je     40ccca <__swc_fn_585f006d_000094_63c1827b+0xaa>
  40cc8e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  40cc93:	jne    40ccca <__swc_fn_585f006d_000094_63c1827b+0xaa>
  40cc95:	mov    ecx,DWORD PTR [rdi+0x28]
  40cc98:	test   ecx,0x1000
  40cc9e:	je     40ccca <__swc_fn_585f006d_000094_63c1827b+0xaa>
  40cca0:	test   ecx,0x10000
  40cca6:	je     40ccca <__swc_fn_585f006d_000094_63c1827b+0xaa>
  40cca8:	mov    rcx,QWORD PTR [rdi+0x40]
  40ccac:	mov    rdx,rax
  40ccaf:	mov    r8d,ebx
  40ccb2:	call   40cc20 <__swc_fn_585f006d_000094_63c1827b>
  40ccb7:	add    rsp,0x120
  40ccbe:	pop    r15
  40ccc0:	pop    r14
  40ccc2:	pop    r13
  40ccc4:	pop    r12
  40ccc6:	pop    rdi
  40ccc7:	pop    rsi
  40ccc8:	pop    rbx
  40ccc9:	ret
  40ccca:	mov    cl,BYTE PTR [rax+0x2c]
  40cccd:	rex cmp BYTE PTR [rdi+0x2c],cl
  40ccd1:	jne    40ccdb <__swc_fn_585f006d_000094_63c1827b+0xbb>
  40ccd3:	mov    ecx,DWORD PTR [rax+0x20]
  40ccd6:	cmp    DWORD PTR [rdi+0x20],ecx
  40ccd9:	je     40ccf0 <__swc_fn_585f006d_000094_63c1827b+0xd0>
  40ccdb:	xor    eax,eax
  40ccdd:	add    rsp,0x120
  40cce4:	pop    r15
  40cce6:	pop    r14
  40cce8:	pop    r13
  40ccea:	pop    r12
  40ccec:	pop    rdi
  40cced:	pop    rsi
  40ccee:	pop    rbx
  40ccef:	ret
  40ccf0:	mov    ecx,DWORD PTR [rdi+0x28]
  40ccf3:	and    ecx,0xffb5ffff
  40ccf9:	mov    edx,DWORD PTR [rax+0x28]
  40ccfc:	and    edx,0xffb5ffff
  40cd02:	cmp    ecx,edx
  40cd04:	je     40cd1b <__swc_fn_585f006d_000094_63c1827b+0xfb>
  40cd06:	xor    eax,eax
  40cd08:	add    rsp,0x120
  40cd0f:	pop    r15
  40cd11:	pop    r14
  40cd13:	pop    r13
  40cd15:	pop    r12
  40cd17:	pop    rdi
  40cd18:	pop    rsi
  40cd19:	pop    rbx
  40cd1a:	ret
  40cd1b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  40cd20:	jne    40cd75 <__swc_fn_585f006d_000094_63c1827b+0x155>
  40cd22:	mov    cl,BYTE PTR [rax+0x40]
  40cd25:	rex cmp BYTE PTR [rdi+0x40],cl
  40cd29:	je     40cd40 <__swc_fn_585f006d_000094_63c1827b+0x120>
  40cd2b:	xor    eax,eax
  40cd2d:	add    rsp,0x120
  40cd34:	pop    r15
  40cd36:	pop    r14
  40cd38:	pop    r13
  40cd3a:	pop    r12
  40cd3c:	pop    rdi
  40cd3d:	pop    rsi
  40cd3e:	pop    rbx
  40cd3f:	ret
  40cd40:	rex cmp BYTE PTR [rdi+0x40],0xd
  40cd45:	je     40cd5d <__swc_fn_585f006d_000094_63c1827b+0x13d>
  40cd47:	rex cmp BYTE PTR [rdi+0x40],0xf
  40cd4c:	sete   cl
  40cd4f:	je     40cd59 <__swc_fn_585f006d_000094_63c1827b+0x139>
  40cd51:	rex cmp BYTE PTR [rdi+0x40],0xe
  40cd56:	sete   cl
  40cd59:	test   cl,cl
  40cd5b:	je     40cd75 <__swc_fn_585f006d_000094_63c1827b+0x155>
  40cd5d:	mov    eax,0x1
  40cd62:	add    rsp,0x120
  40cd69:	pop    r15
  40cd6b:	pop    r14
  40cd6d:	pop    r13
  40cd6f:	pop    r12
  40cd71:	pop    rdi
  40cd72:	pop    rsi
  40cd73:	pop    rbx
  40cd74:	ret
  40cd75:	test   DWORD PTR [rdi+0x28],0x200200
  40cd7c:	je     40cf2f <__swc_fn_585f006d_000094_63c1827b+0x30f>
  40cd82:	mov    rsi,QWORD PTR [rdi+0x88]
  40cd89:	mov    rdi,QWORD PTR [rdi+0x90]
  40cd90:	mov    r12,QWORD PTR [rax+0x88]
  40cd97:	mov    rax,QWORD PTR [rax+0x90]
  40cd9e:	cmp    rdi,rax
  40cda1:	je     40cdb8 <__swc_fn_585f006d_000094_63c1827b+0x198>
  40cda3:	xor    eax,eax
  40cda5:	add    rsp,0x120
  40cdac:	pop    r15
  40cdae:	pop    r14
  40cdb0:	pop    r13
  40cdb2:	pop    r12
  40cdb4:	pop    rdi
  40cdb5:	pop    rsi
  40cdb6:	pop    rbx
  40cdb7:	ret
  40cdb8:	test   rsi,rsi
  40cdbb:	je     40cdc2 <__swc_fn_585f006d_000094_63c1827b+0x1a2>
  40cdbd:	test   r12,r12
  40cdc0:	jne    40cdda <__swc_fn_585f006d_000094_63c1827b+0x1ba>
  40cdc2:	mov    eax,0x1
  40cdc7:	add    rsp,0x120
  40cdce:	pop    r15
  40cdd0:	pop    r14
  40cdd2:	pop    r13
  40cdd4:	pop    r12
  40cdd6:	pop    rdi
  40cdd7:	pop    rsi
  40cdd8:	pop    rbx
  40cdd9:	ret
  40cdda:	xor    r13d,r13d
  40cddd:	test   rdi,rdi
  40cde0:	jbe    40cf17 <__swc_fn_585f006d_000094_63c1827b+0x2f7>
  40cde6:	lea    r14,[rsp+0x78]
  40cdeb:	lea    r15,[rsp+0xb8]
  40cdf3:	cs nop WORD PTR [rax+rax*1+0x0]
  40cdfd:	cs nop WORD PTR [rax+rax*1+0x0]
  40ce07:	nop    WORD PTR [rax+rax*1+0x0]
  40ce10:	lea    rax,[r13*8+0x0]
  40ce18:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40ce1d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40ce23:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  40ce29:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40ce32:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  40ce38:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40ce41:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  40ce47:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40ce50:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  40ce56:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40ce5f:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  40ce66:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  40ce6f:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  40ce76:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  40ce7f:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  40ce86:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40ce8f:	xor    al,al
  40ce91:	rex test BYTE PTR [rsp+0xb0],0x1
  40ce9a:	je     40cea1 <__swc_fn_585f006d_000094_63c1827b+0x281>
  40ce9c:	mov    eax,0x1
  40cea1:	rex test BYTE PTR [rsp+0xf0],0x1
  40ceaa:	je     40ceb1 <__swc_fn_585f006d_000094_63c1827b+0x291>
  40ceac:	mov    eax,0x1
  40ceb1:	test   al,al
  40ceb3:	jne    40ced9 <__swc_fn_585f006d_000094_63c1827b+0x2b9>
  40ceb5:	mov    rcx,r14
  40ceb8:	mov    rdx,r15
  40cebb:	call   40e430 <__swc_fn_585f006d_000151_6fb05988>
  40cec0:	test   al,al
  40cec2:	jne    40ced9 <__swc_fn_585f006d_000094_63c1827b+0x2b9>
  40cec4:	xor    eax,eax
  40cec6:	add    rsp,0x120
  40cecd:	pop    r15
  40cecf:	pop    r14
  40ced1:	pop    r13
  40ced3:	pop    r12
  40ced5:	pop    rdi
  40ced6:	pop    rsi
  40ced7:	pop    rbx
  40ced8:	ret
  40ced9:	mov    rcx,QWORD PTR [rsp+0x88]
  40cee1:	mov    rdx,QWORD PTR [rsp+0xc8]
  40cee9:	mov    r8d,ebx
  40ceec:	call   40cc20 <__swc_fn_585f006d_000094_63c1827b>
  40cef1:	test   al,al
  40cef3:	jne    40cf0a <__swc_fn_585f006d_000094_63c1827b+0x2ea>
  40cef5:	xor    eax,eax
  40cef7:	add    rsp,0x120
  40cefe:	pop    r15
  40cf00:	pop    r14
  40cf02:	pop    r13
  40cf04:	pop    r12
  40cf06:	pop    rdi
  40cf07:	pop    rsi
  40cf08:	pop    rbx
  40cf09:	ret
  40cf0a:	add    r13,0x1
  40cf0e:	cmp    r13,rdi
  40cf11:	jb     40ce10 <__swc_fn_585f006d_000094_63c1827b+0x1f0>
  40cf17:	mov    eax,0x1
  40cf1c:	add    rsp,0x120
  40cf23:	pop    r15
  40cf25:	pop    r14
  40cf27:	pop    r13
  40cf29:	pop    r12
  40cf2b:	pop    rdi
  40cf2c:	pop    rsi
  40cf2d:	pop    rbx
  40cf2e:	ret
  40cf2f:	test   bl,0x2
  40cf32:	je     40cf54 <__swc_fn_585f006d_000094_63c1827b+0x334>
  40cf34:	lea    rcx,[rdi+0x10]
  40cf38:	lea    rdx,[rax+0x10]
  40cf3c:	call   40e430 <__swc_fn_585f006d_000151_6fb05988>
  40cf41:	add    rsp,0x120
  40cf48:	pop    r15
  40cf4a:	pop    r14
  40cf4c:	pop    r13
  40cf4e:	pop    r12
  40cf50:	pop    rdi
  40cf51:	pop    rsi
  40cf52:	pop    rbx
  40cf53:	ret
  40cf54:	mov    rcx,rdi
  40cf57:	mov    rdx,rax
  40cf5a:	call   40e430 <__swc_fn_585f006d_000151_6fb05988>
  40cf5f:	add    rsp,0x120
  40cf66:	pop    r15
  40cf68:	pop    r14
  40cf6a:	pop    r13
  40cf6c:	pop    r12
  40cf6e:	pop    rdi
  40cf6f:	pop    rsi
  40cf70:	pop    rbx
  40cf71:	ret
	...

000000000040cf80 <__swc_fn_585f006d_000097_4185993f>:
  40cf80:	push   rbx
  40cf81:	mov    rbx,rcx
  40cf84:	call   4107d0 <__swc_fn_585f006d_000095_ad13d15c>
  40cf89:	movzx  r11d,al
  40cf8d:	mov    r8b,r11b
  40cf90:	test   r8b,r8b
  40cf93:	jne    40cfad <__swc_fn_585f006d_000097_4185993f+0x2d>
  40cf95:	mov    r11d,0x1
  40cf9b:	mov    r10,rbx
  40cf9e:	mov    r9,r11
  40cfa1:	and    r10,r11
  40cfa4:	test   r10,r10
  40cfa7:	setne  dl
  40cfaa:	mov    r8b,dl
  40cfad:	mov    r10b,r8b
  40cfb0:	test   r10b,r10b
  40cfb3:	je     40cfb7 <__swc_fn_585f006d_000097_4185993f+0x37>
  40cfb5:	pop    rbx
  40cfb6:	ret
  40cfb7:	call   409e00 <__swc_fn_585f006d_000141_519fdf94>
  40cfbc:	movzx  r10d,al
  40cfc0:	test   r10b,r10b
  40cfc3:	je     40cfc7 <__swc_fn_585f006d_000097_4185993f+0x47>
  40cfc5:	pop    rbx
  40cfc6:	ret
  40cfc7:	lea    r10,[rip+0x531a]        # 4122e8 <__swc_rdata_base_585f006d+0x1d8>
  40cfce:	mov    rax,r10
  40cfd1:	mov    rcx,rax
  40cfd4:	call   409930 <__swc_fn_585f006d_000120_2648f149>
  40cfd9:	call   411050 <__swc_fn_585f006d_000122_be2e2f68>
  40cfde:	pop    rbx
  40cfdf:	ret

000000000040cfe0 <__swc_fn_585f006d_000100_d4bdcaa4>:
  40cfe0:	push   rbx
  40cfe1:	sub    rsp,0x70
  40cfe5:	vxorps xmm0,xmm0,xmm0
  40cfe9:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40cfef:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40cff5:	vzeroupper
  40cff8:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40cffe:	mov    QWORD PTR [rsp+0x48],rdx
  40d003:	mov    rax,r8
  40d006:	cmp    r8,0x1
  40d00a:	mov    edx,0x1
  40d00f:	cmovb  rax,rdx
  40d013:	mov    QWORD PTR [rsp+0x50],rax
  40d018:	mov    rbx,QWORD PTR [rcx+0x8]
  40d01c:	mov    rbx,QWORD PTR [rbx+0x18]
  40d020:	mov    rcx,QWORD PTR [rcx]
  40d023:	lea    rdx,[rsp+0x8]
  40d028:	call   rbx
  40d02a:	add    rsp,0x70
  40d02e:	pop    rbx
  40d02f:	ret

000000000040d030 <__swc_fn_585f006d_000103_2fdd2c61>:
  40d030:	push   rbx
  40d031:	push   rsi
  40d032:	push   rdi
  40d033:	sub    rsp,0x30
  40d037:	mov    rbx,rcx
  40d03a:	test   rcx,rcx
  40d03d:	je     40d052 <__swc_fn_585f006d_000103_2fdd2c61+0x22>
  40d03f:	mov    rcx,rbx
  40d042:	mov    edx,0x1
  40d047:	call   40c880 <__swc_fn_585f006d_000082_63a67586>
  40d04c:	cmp    rax,0x1
  40d050:	je     40d05a <__swc_fn_585f006d_000103_2fdd2c61+0x2a>
  40d052:	add    rsp,0x30
  40d056:	pop    rdi
  40d057:	pop    rsi
  40d058:	pop    rbx
  40d059:	ret
  40d05a:	lea    rsi,[rsp+0x8]
  40d05f:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40d064:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40d06a:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  40d06f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40d075:	mov    rax,QWORD PTR [rsp+0x20]
  40d07a:	test   rax,rax
  40d07d:	je     40d093 <__swc_fn_585f006d_000103_2fdd2c61+0x63>
  40d07f:	test   DWORD PTR [rax+0x28],0x400000
  40d086:	je     40d093 <__swc_fn_585f006d_000103_2fdd2c61+0x63>
  40d088:	mov    rcx,QWORD PTR [rax+0x30]
  40d08c:	test   rcx,rcx
  40d08f:	cmovne rax,rcx
  40d093:	mov    edi,DWORD PTR [rax+0x20]
  40d096:	lea    rcx,[rsp+0x18]
  40d09b:	call   4109b0 <__swc_fn_585f006d_000104_3c3b96fb>
  40d0a0:	mov    rcx,rsi
  40d0a3:	mov    rdx,QWORD PTR [rsp+0x18]
  40d0a8:	mov    r8,rdi
  40d0ab:	call   40cfe0 <__swc_fn_585f006d_000100_d4bdcaa4>
  40d0b0:	mov    rcx,QWORD PTR [rbx+0x28]
  40d0b4:	call   408ee0 <__swc_fn_585f006d_000102_e34f54dc>
  40d0b9:	mov    rcx,rsi
  40d0bc:	mov    rdx,rbx
  40d0bf:	mov    r8d,0x30
  40d0c5:	call   40cfe0 <__swc_fn_585f006d_000100_d4bdcaa4>
  40d0ca:	add    rsp,0x30
  40d0ce:	pop    rdi
  40d0cf:	pop    rsi
  40d0d0:	pop    rbx
  40d0d1:	ret
	...

000000000040d0e0 <__swc_fn_585f006d_000106_ffe51047>:
  40d0e0:	push   rbp
  40d0e1:	push   rbx
  40d0e2:	push   rsi
  40d0e3:	push   rdi
  40d0e4:	push   r12
  40d0e6:	push   r13
  40d0e8:	push   r14
  40d0ea:	push   r15
  40d0ec:	sub    rsp,0x500
  40d0f3:	mov    rbp,rsp
  40d0f6:	mov    rbx,rsp
  40d0f9:	mov    rsi,rdx
  40d0fc:	mov    rdi,rcx
  40d0ff:	mov    rcx,QWORD PTR [rip+0x15f3a]        # 423040 <__swc_bss_base_585f006d>
  40d106:	test   rcx,rcx
  40d109:	jne    40d123 <__swc_fn_585f006d_000106_ffe51047+0x43>
  40d10b:	sub    rsp,0x8
  40d10f:	call   40e820 <__swc_fn_585f006d_000169_994c8876>
  40d114:	add    rsp,0x8
  40d118:	lea    rcx,[rax+0x1]
  40d11c:	mov    QWORD PTR [rip+0x15f1d],rcx        # 423040 <__swc_bss_base_585f006d>
  40d123:	dec    rcx
  40d126:	sub    rsp,0x8
  40d12a:	call   40b6e0 <__swc_fn_585f006d_000171_360af05d>
  40d12f:	add    rsp,0x8
  40d133:	mov    r12,rax
  40d136:	mov    QWORD PTR [rsp+0x4f0],rax
  40d13e:	lea    rax,[rip+0x52e3]        # 412428 <__swc_rdata_base_585f006d+0x318>
  40d145:	sub    rsp,0x20
  40d149:	mov    rcx,rsp
  40d14c:	mov    QWORD PTR [rcx],rax
  40d14f:	lea    r13,[rip+0x4fda]        # 412130 <__swc_rdata_base_585f006d+0x20>
  40d156:	mov    QWORD PTR [rcx+0x8],r13
  40d15a:	mov    QWORD PTR [rcx+0x10],rsp
  40d15e:	mov    QWORD PTR [rcx+0x18],0x1
  40d166:	lea    rcx,[rsp+0x10]
  40d16b:	sub    rsp,0x8
  40d16f:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  40d174:	add    rsp,0x8
  40d178:	add    rsp,0x20
  40d17c:	lea    rax,[rip+0x52b5]        # 412438 <__swc_rdata_base_585f006d+0x328>
  40d183:	sub    rsp,0x20
  40d187:	mov    rcx,rsp
  40d18a:	mov    QWORD PTR [rcx],rax
  40d18d:	mov    QWORD PTR [rcx+0x8],r13
  40d191:	mov    QWORD PTR [rcx+0x10],rsp
  40d195:	mov    QWORD PTR [rcx+0x18],0x1
  40d19d:	lea    rcx,[rsp+0x10]
  40d1a2:	sub    rsp,0x8
  40d1a6:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  40d1ab:	add    rsp,0x8
  40d1af:	add    rsp,0x20
  40d1b3:	lea    r14,[rip+0x4f66]        # 412120 <__swc_rdata_base_585f006d+0x10>
  40d1ba:	sub    rsp,0x50
  40d1be:	mov    rax,rsp
  40d1c1:	vmovups xmm0,XMMWORD PTR [rip+0x53a7]        # 412570 <__swc_rdata_base_585f006d+0x460>
  40d1c9:	vmovups XMMWORD PTR [rax],xmm0
  40d1cd:	mov    QWORD PTR [rax+0x10],rsp
  40d1d1:	mov    QWORD PTR [rax+0x18],r13
  40d1d5:	mov    QWORD PTR [rax+0x20],rdi
  40d1d9:	lea    rdi,[rip+0x5268]        # 412448 <__swc_rdata_base_585f006d+0x338>
  40d1e0:	mov    QWORD PTR [rax+0x28],rdi
  40d1e4:	mov    QWORD PTR [rax+0x30],r14
  40d1e8:	mov    QWORD PTR [rax+0x38],r13
  40d1ec:	lea    rcx,[rsp+0x10]
  40d1f1:	mov    QWORD PTR [rax+0x40],rcx
  40d1f5:	mov    QWORD PTR [rax+0x48],0x3
  40d1fd:	lea    rcx,[rsp+0x40]
  40d202:	sub    rsp,0x8
  40d206:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  40d20b:	add    rsp,0x8
  40d20f:	add    rsp,0x50
  40d213:	lea    rax,[rip+0x5276]        # 412490 <__swc_rdata_base_585f006d+0x380>
  40d21a:	sub    rsp,0x20
  40d21e:	mov    rcx,rsp
  40d221:	mov    QWORD PTR [rcx],rax
  40d224:	mov    QWORD PTR [rcx+0x8],r13
  40d228:	mov    QWORD PTR [rcx+0x10],rsp
  40d22c:	mov    QWORD PTR [rcx+0x18],0x1
  40d234:	lea    rcx,[rsp+0x10]
  40d239:	sub    rsp,0x8
  40d23d:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  40d242:	add    rsp,0x8
  40d246:	add    rsp,0x20
  40d24a:	mov    eax,DWORD PTR [rsi+0x20]
  40d24d:	mov    ecx,DWORD PTR [rsi+0x24]
  40d250:	sub    rsp,0xa0
  40d257:	mov    rdx,rsp
  40d25a:	mov    QWORD PTR [rdx+0x30],rsi
  40d25e:	mov    QWORD PTR [rdx+0x38],rdi
  40d262:	vmovups xmm0,XMMWORD PTR [rip+0x529e]        # 412508 <__swc_rdata_base_585f006d+0x3f8>
  40d26a:	vmovups XMMWORD PTR [rdx],xmm0
  40d26e:	mov    QWORD PTR [rdx+0x40],rsp
  40d272:	mov    QWORD PTR [rdx+0x48],r13
  40d276:	mov    DWORD PTR [rdx+0x10],eax
  40d279:	lea    rax,[rsp+0x10]
  40d27e:	mov    QWORD PTR [rdx+0x50],rax
  40d282:	lea    rax,[rip+0x5217]        # 4124a0 <__swc_rdata_base_585f006d+0x390>
  40d289:	mov    QWORD PTR [rdx+0x58],rax
  40d28d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  40d292:	lea    r8,[rsp+0x18]
  40d297:	mov    QWORD PTR [rdx+0x60],r8
  40d29b:	mov    QWORD PTR [rdx+0x68],r13
  40d29f:	mov    DWORD PTR [rdx+0x28],ecx
  40d2a2:	lea    rcx,[rdx+0x28]
  40d2a6:	mov    QWORD PTR [rdx+0x70],rcx
  40d2aa:	mov    QWORD PTR [rdx+0x78],rax
  40d2ae:	mov    QWORD PTR [rdx+0x80],r14
  40d2b5:	mov    QWORD PTR [rdx+0x88],r13
  40d2bc:	lea    rax,[rdx+0x30]
  40d2c0:	mov    QWORD PTR [rdx+0x90],rax
  40d2c7:	mov    QWORD PTR [rdx+0x98],0x6
  40d2d2:	lea    rcx,[rdx+0x90]
  40d2d9:	sub    rsp,0x8
  40d2dd:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  40d2e2:	add    rsp,0x8
  40d2e6:	add    rsp,0xa0
  40d2ed:	sub    rsp,0x20
  40d2f1:	mov    rax,rsp
  40d2f4:	mov    QWORD PTR [rax],r14
  40d2f7:	mov    QWORD PTR [rax+0x8],r13
  40d2fb:	mov    QWORD PTR [rax+0x10],rsp
  40d2ff:	mov    QWORD PTR [rax+0x18],0x1
  40d307:	lea    rcx,[rsp+0x10]
  40d30c:	sub    rsp,0x8
  40d310:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  40d315:	add    rsp,0x8
  40d319:	add    rsp,0x20
  40d31d:	mov    eax,DWORD PTR [r12+0x9ac]
  40d325:	test   eax,eax
  40d327:	je     40d560 <__swc_fn_585f006d_000106_ffe51047+0x480>
  40d32d:	lea    rax,[rip+0x51b4]        # 4124e8 <__swc_rdata_base_585f006d+0x3d8>
  40d334:	sub    rsp,0x20
  40d338:	mov    rcx,rsp
  40d33b:	mov    QWORD PTR [rcx],rax
  40d33e:	mov    QWORD PTR [rcx+0x8],r13
  40d342:	mov    QWORD PTR [rcx+0x10],rsp
  40d346:	mov    QWORD PTR [rcx+0x18],0x1
  40d34e:	lea    rcx,[rsp+0x10]
  40d353:	sub    rsp,0x8
  40d357:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  40d35c:	add    rsp,0x8
  40d360:	add    rsp,0x20
  40d364:	mov    eax,DWORD PTR [r12+0x9ac]
  40d36c:	dec    eax
  40d36e:	mov    esi,eax
  40d370:	test   esi,esi
  40d372:	jl     40d530 <__swc_fn_585f006d_000106_ffe51047+0x450>
  40d378:	jmp    40d384 <__swc_fn_585f006d_000106_ffe51047+0x2a4>
  40d37a:	nop    WORD PTR [rax+rax*1+0x0]
  40d380:	dec    esi
  40d382:	jmp    40d370 <__swc_fn_585f006d_000106_ffe51047+0x290>
  40d384:	lea    rax,[rip+0x516d]        # 4124f8 <__swc_rdata_base_585f006d+0x3e8>
  40d38b:	sub    rsp,0x20
  40d38f:	mov    rcx,rsp
  40d392:	mov    QWORD PTR [rcx],rax
  40d395:	mov    QWORD PTR [rcx+0x8],r13
  40d399:	mov    QWORD PTR [rcx+0x10],rsp
  40d39d:	mov    QWORD PTR [rcx+0x18],0x1
  40d3a5:	lea    rcx,[rsp+0x10]
  40d3aa:	sub    rsp,0x8
  40d3ae:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  40d3b3:	add    rsp,0x8
  40d3b7:	add    rsp,0x20
  40d3bb:	movsxd rax,esi
  40d3be:	imul   r15,rax,0x30
  40d3c2:	add    r15,r12
  40d3c5:	add    r15,0xf8
  40d3cc:	sub    rsp,0x20
  40d3d0:	mov    rax,rsp
  40d3d3:	mov    QWORD PTR [rax],r15
  40d3d6:	mov    QWORD PTR [rax+0x8],rdi
  40d3da:	mov    QWORD PTR [rax+0x10],rsp
  40d3de:	mov    QWORD PTR [rax+0x18],0x1
  40d3e6:	lea    rcx,[rsp+0x10]
  40d3eb:	sub    rsp,0x8
  40d3ef:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  40d3f4:	add    rsp,0x8
  40d3f8:	add    rsp,0x20
  40d3fc:	mov    QWORD PTR [rsp+0x4f8],rsi
  40d404:	lea    rsi,[rip+0x50fd]        # 412508 <__swc_rdata_base_585f006d+0x3f8>
  40d40b:	sub    rsp,0x20
  40d40f:	mov    rax,rsp
  40d412:	mov    QWORD PTR [rax],rsi
  40d415:	mov    QWORD PTR [rax+0x8],r13
  40d419:	mov    QWORD PTR [rax+0x10],rsp
  40d41d:	mov    QWORD PTR [rax+0x18],0x1
  40d425:	lea    rcx,[rsp+0x10]
  40d42a:	sub    rsp,0x8
  40d42e:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  40d433:	add    rsp,0x8
  40d437:	add    rsp,0x20
  40d43b:	sub    rsp,0x30
  40d43f:	mov    rax,rsp
  40d442:	mov    ecx,DWORD PTR [r15+0x20]
  40d446:	mov    QWORD PTR [rax],rcx
  40d449:	mov    QWORD PTR [rax+0x8],rsp
  40d44d:	lea    rdi,[rip+0x50c4]        # 412518 <__swc_rdata_base_585f006d+0x408>
  40d454:	mov    QWORD PTR [rax+0x10],rdi
  40d458:	lea    rcx,[rsp+0x8]
  40d45d:	mov    QWORD PTR [rax+0x18],rcx
  40d461:	mov    QWORD PTR [rax+0x20],0x1
  40d469:	lea    rcx,[rsp+0x18]
  40d46e:	sub    rsp,0x8
  40d472:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  40d477:	add    rsp,0x8
  40d47b:	add    rsp,0x30
  40d47f:	sub    rsp,0x20
  40d483:	mov    rax,rsp
  40d486:	mov    QWORD PTR [rax],rsi
  40d489:	mov    QWORD PTR [rax+0x8],r13
  40d48d:	mov    QWORD PTR [rax+0x10],rsp
  40d491:	mov    QWORD PTR [rax+0x18],0x1
  40d499:	lea    rcx,[rsp+0x10]
  40d49e:	sub    rsp,0x8
  40d4a2:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  40d4a7:	add    rsp,0x8
  40d4ab:	add    rsp,0x20
  40d4af:	sub    rsp,0x30
  40d4b3:	mov    rax,rsp
  40d4b6:	mov    ecx,DWORD PTR [r15+0x24]
  40d4ba:	mov    QWORD PTR [rax],rcx
  40d4bd:	mov    QWORD PTR [rax+0x8],rsp
  40d4c1:	mov    QWORD PTR [rax+0x10],rdi
  40d4c5:	lea    rcx,[rsp+0x8]
  40d4ca:	mov    QWORD PTR [rax+0x18],rcx
  40d4ce:	mov    QWORD PTR [rax+0x20],0x1
  40d4d6:	lea    rcx,[rsp+0x18]
  40d4db:	sub    rsp,0x8
  40d4df:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  40d4e4:	add    rsp,0x8
  40d4e8:	add    rsp,0x30
  40d4ec:	sub    rsp,0x20
  40d4f0:	mov    rax,rsp
  40d4f3:	mov    QWORD PTR [rax],r14
  40d4f6:	mov    QWORD PTR [rax+0x8],r13
  40d4fa:	mov    QWORD PTR [rax+0x10],rsp
  40d4fe:	mov    QWORD PTR [rax+0x18],0x1
  40d506:	lea    rcx,[rsp+0x10]
  40d50b:	sub    rsp,0x8
  40d50f:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  40d514:	add    rsp,0x8
  40d518:	add    rsp,0x20
  40d51c:	lea    rdi,[rip+0x4f25]        # 412448 <__swc_rdata_base_585f006d+0x338>
  40d523:	mov    rsi,QWORD PTR [rsp+0x4f8]
  40d52b:	jmp    40d380 <__swc_fn_585f006d_000106_ffe51047+0x2a0>
  40d530:	sub    rsp,0x20
  40d534:	mov    rax,rsp
  40d537:	mov    QWORD PTR [rax],r14
  40d53a:	mov    QWORD PTR [rax+0x8],r13
  40d53e:	mov    QWORD PTR [rax+0x10],rsp
  40d542:	mov    QWORD PTR [rax+0x18],0x1
  40d54a:	lea    rcx,[rsp+0x10]
  40d54f:	sub    rsp,0x8
  40d553:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  40d558:	add    rsp,0x8
  40d55c:	add    rsp,0x20
  40d560:	lea    rax,[rbx+0x28]
  40d564:	mov    rcx,rax
  40d567:	mov    QWORD PTR [rbx+0x28],0x0
  40d56f:	mov    QWORD PTR [rbx+0x30],0x0
  40d577:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  40d57c:	add    rcx,0x10
  40d580:	mov    edx,0x1f
  40d585:	cs nop WORD PTR [rax+rax*1+0x0]
  40d58f:	nop
  40d590:	vmovups XMMWORD PTR [rcx],xmm0
  40d594:	add    rcx,0x10
  40d598:	sub    rdx,0x1
  40d59c:	jne    40d590 <__swc_fn_585f006d_000106_ffe51047+0x4b0>
  40d59e:	lea    rsi,[rbx+0x228]
  40d5a5:	xor    ecx,ecx
  40d5a7:	cs nop WORD PTR [rax+rax*1+0x0]
  40d5b1:	cs nop WORD PTR [rax+rax*1+0x0]
  40d5bb:	nop    DWORD PTR [rax+rax*1+0x0]
  40d5c0:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  40d5c5:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  40d5ca:	add    rcx,0x10
  40d5ce:	cmp    rcx,0x200
  40d5d5:	jne    40d5c0 <__swc_fn_585f006d_000106_ffe51047+0x4e0>
  40d5d7:	mov    eax,DWORD PTR [r12+0xbc8]
  40d5df:	lea    rcx,[r12+0x9c8]
  40d5e7:	mov    QWORD PTR [rbx+0x428],rcx
  40d5ee:	mov    QWORD PTR [rbx+0x430],rax
  40d5f5:	lea    rdi,[rbx+0x438]
  40d5fc:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  40d604:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  40d60c:	mov    eax,DWORD PTR [r12+0xbc8]
  40d614:	test   eax,eax
  40d616:	jne    40d663 <__swc_fn_585f006d_000106_ffe51047+0x583>
  40d618:	lea    rax,[rbx+0x448]
  40d61f:	mov    QWORD PTR [rbx+0x448],rsi
  40d626:	mov    QWORD PTR [rax+0x8],0x40
  40d62e:	mov    ecx,0x1
  40d633:	mov    rdx,rax
  40d636:	sub    rsp,0x8
  40d63a:	call   409a40 <__swc_fn_585f006d_000123_4f256d58>
  40d63f:	add    rsp,0x8
  40d643:	mov    QWORD PTR [rbx+0x460],rsi
  40d64a:	mov    ecx,eax
  40d64c:	mov    QWORD PTR [rbx+0x468],rcx
  40d653:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  40d65b:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  40d663:	mov    rsi,QWORD PTR [rbx+0x438]
  40d66a:	mov    rax,QWORD PTR [rbx+0x440]
  40d671:	mov    r15,rax
  40d674:	xor    r12d,r12d
  40d677:	test   r15,r15
  40d67a:	je     40d730 <__swc_fn_585f006d_000106_ffe51047+0x650>
  40d680:	mov    rax,QWORD PTR [rsi+r12*8]
  40d684:	test   rax,rax
  40d687:	je     40d6a6 <__swc_fn_585f006d_000106_ffe51047+0x5c6>
  40d689:	lea    rcx,[rbx+0x4b8]
  40d690:	mov    rdx,rax
  40d693:	sub    rsp,0x8
  40d697:	call   40e590 <__swc_fn_585f006d_000166_cc119975>
  40d69c:	add    rsp,0x8
  40d6a0:	mov    al,BYTE PTR [rax]
  40d6a2:	test   al,al
  40d6a4:	jne    40d6b2 <__swc_fn_585f006d_000106_ffe51047+0x5d2>
  40d6a6:	add    r12,0x1
  40d6aa:	sub    r15,0x1
  40d6ae:	jne    40d680 <__swc_fn_585f006d_000106_ffe51047+0x5a0>
  40d6b0:	jmp    40d730 <__swc_fn_585f006d_000106_ffe51047+0x650>
  40d6b2:	lea    rax,[rip+0x4ea7]        # 412560 <__swc_rdata_base_585f006d+0x450>
  40d6b9:	sub    rsp,0x20
  40d6bd:	mov    rcx,rsp
  40d6c0:	mov    QWORD PTR [rcx],rax
  40d6c3:	mov    QWORD PTR [rcx+0x8],r13
  40d6c7:	mov    QWORD PTR [rcx+0x10],rsp
  40d6cb:	mov    QWORD PTR [rcx+0x18],0x1
  40d6d3:	lea    rcx,[rsp+0x10]
  40d6d8:	sub    rsp,0x8
  40d6dc:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  40d6e1:	add    rsp,0x8
  40d6e5:	add    rsp,0x20
  40d6e9:	mov    rcx,rdi
  40d6ec:	xor    edx,edx
  40d6ee:	mov    al,0x1
  40d6f0:	mov    r8,rax
  40d6f3:	sub    rsp,0x8
  40d6f7:	call   4118e0 <__swc_fn_585f006d_000167_bcc835b8>
  40d6fc:	add    rsp,0x8
  40d700:	sub    rsp,0x20
  40d704:	mov    rax,rsp
  40d707:	mov    QWORD PTR [rax],r14
  40d70a:	mov    QWORD PTR [rax+0x8],r13
  40d70e:	mov    QWORD PTR [rax+0x10],rsp
  40d712:	mov    QWORD PTR [rax+0x18],0x1
  40d71a:	lea    rcx,[rsp+0x10]
  40d71f:	sub    rsp,0x8
  40d723:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  40d728:	add    rsp,0x8
  40d72c:	add    rsp,0x20
  40d730:	mov    r12,QWORD PTR [rsp+0x4f0]
  40d738:	mov    DWORD PTR [r12+0xbc8],0x0
  40d744:	add    rsp,0x500
  40d74b:	pop    r15
  40d74d:	pop    r14
  40d74f:	pop    r13
  40d751:	pop    r12
  40d753:	pop    rdi
  40d754:	pop    rsi
  40d755:	pop    rbx
  40d756:	pop    rbp
  40d757:	ret
	...

000000000040d760 <__swc_fn_585f006d_000109_7c204aac>:
  40d760:	sub    rsp,0x8
  40d764:	test   r8,r8
  40d767:	je     40d76e <__swc_fn_585f006d_000109_7c204aac+0xe>
  40d769:	call   409170 <__swc_fn_585f006d_000108_c51c3158>
  40d76e:	add    rsp,0x8
  40d772:	ret
	...

000000000040d780 <__swc_fn_585f006d_000112_126150d1>:
  40d780:	push   rsi
  40d781:	push   rdi
  40d782:	push   r12
  40d784:	push   r13
  40d786:	sub    rsp,0xd8
  40d78d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40d793:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40d799:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40d79f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40d7a5:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40d7ab:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40d7b4:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40d7bd:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40d7c6:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40d7cf:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40d7d8:	xor    eax,eax
  40d7da:	call   407050 <getpid@plt>
  40d7df:	mov    rsi,rax
  40d7e2:	lea    rdi,[rip+0x18557]        # 425d40 <__swc_bss_base_585f006d+0x2d00>
  40d7e9:	mov    r12,QWORD PTR [rdi]
  40d7ec:	test   r12,r12
  40d7ef:	je     40d7fd <__swc_fn_585f006d_000112_126150d1+0x7d>
  40d7f1:	cmp    DWORD PTR [r12+0x10],esi
  40d7f6:	jne    40d7fd <__swc_fn_585f006d_000112_126150d1+0x7d>
  40d7f8:	mov    rax,r12
  40d7fb:	jmp    40d860 <__swc_fn_585f006d_000112_126150d1+0xe0>
  40d7fd:	mov    ecx,0x4
  40d802:	mov    edx,0x18
  40d807:	call   409250 <__swc_fn_585f006d_000111_6814119b>
  40d80c:	mov    rcx,rax
  40d80f:	test   rax,rax
  40d812:	jne    40d818 <__swc_fn_585f006d_000112_126150d1+0x98>
  40d814:	xor    eax,eax
  40d816:	jmp    40d860 <__swc_fn_585f006d_000112_126150d1+0xe0>
  40d818:	mov    DWORD PTR [rcx+0x10],esi
  40d81b:	mov    rax,r12
  40d81e:	lock cmpxchg QWORD PTR [rdi],rcx
  40d823:	mov    r13,rax
  40d826:	cmp    rax,r12
  40d829:	je     40d83f <__swc_fn_585f006d_000112_126150d1+0xbf>
  40d82b:	mov    rdi,rcx
  40d82e:	mov    esi,0x18
  40d833:	xor    eax,eax
  40d835:	call   407160 <munmap@plt>
  40d83a:	mov    rax,r13
  40d83d:	jmp    40d860 <__swc_fn_585f006d_000112_126150d1+0xe0>
  40d83f:	test   r12,r12
  40d842:	je     40d85d <__swc_fn_585f006d_000112_126150d1+0xdd>
  40d844:	mov    rdi,r12
  40d847:	mov    esi,0x18
  40d84c:	xor    eax,eax
  40d84e:	mov    QWORD PTR [rsp+0x28],rcx
  40d853:	call   407160 <munmap@plt>
  40d858:	mov    rcx,QWORD PTR [rsp+0x28]
  40d85d:	mov    rax,rcx
  40d860:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40d866:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40d86c:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40d872:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40d878:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40d87e:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40d887:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40d890:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40d899:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40d8a2:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40d8ab:	add    rsp,0xd8
  40d8b2:	pop    r13
  40d8b4:	pop    r12
  40d8b6:	pop    rdi
  40d8b7:	pop    rsi
  40d8b8:	ret
  40d8b9:	add    BYTE PTR [rax],al
  40d8bb:	add    BYTE PTR [rax],al
  40d8bd:	add    BYTE PTR [rax],al
	...

000000000040d8c0 <__swc_fn_585f006d_000115_36905703>:
  40d8c0:	push   rbx
  40d8c1:	push   r12
  40d8c3:	push   rdi
  40d8c4:	push   rsi
  40d8c5:	sub    rsp,0xa8
  40d8cc:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d8d2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d8d8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d8de:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d8e4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d8ea:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d8f0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d8f6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d8fc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40d905:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40d90e:	mov    rbx,rdx
  40d911:	mov    r12,rcx
  40d914:	mov    rdi,rcx
  40d917:	mov    rsi,rdx
  40d91a:	mov    edx,0x3
  40d91f:	xor    eax,eax
  40d921:	call   407170 <mprotect@plt>
  40d926:	test   eax,eax
  40d928:	je     40d92e <__swc_fn_585f006d_000115_36905703+0x6e>
  40d92a:	xor    eax,eax
  40d92c:	jmp    40d943 <__swc_fn_585f006d_000115_36905703+0x83>
  40d92e:	mov    rcx,r12
  40d931:	mov    rdx,rbx
  40d934:	mov    al,0x1
  40d936:	mov    r8,rax
  40d939:	call   409880 <__swc_fn_585f006d_000114_5f48311c>
  40d93e:	mov    eax,0x1
  40d943:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40d949:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40d94f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40d955:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40d95b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40d961:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40d967:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40d96d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40d973:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40d97c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40d985:	add    rsp,0xa8
  40d98c:	pop    rsi
  40d98d:	pop    rdi
  40d98e:	pop    r12
  40d990:	pop    rbx
  40d991:	ret
	...

000000000040d9a0 <__swc_fn_585f006d_000118_5208f471>:
  40d9a0:	sub    rsp,0x8
  40d9a4:	test   rcx,rcx
  40d9a7:	jne    40d9ae <__swc_fn_585f006d_000118_5208f471+0xe>
  40d9a9:	add    rsp,0x8
  40d9ad:	ret
  40d9ae:	call   410f00 <__swc_fn_585f006d_000119_d3318640>
  40d9b3:	add    rsp,0x8
  40d9b7:	ret
	...

000000000040d9c0 <__swc_fn_585f006d_000121_0a5fa85a>:
  40d9c0:	push   rdi
  40d9c1:	push   rsi
  40d9c2:	sub    rsp,0xa8
  40d9c9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40d9cf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40d9d5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40d9db:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40d9e1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40d9e7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40d9ed:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40d9f3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40d9f9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40da02:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40da0b:	xor    edi,edi
  40da0d:	xor    eax,eax
  40da0f:	call   407180 <exit@plt>
  40da14:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40da1a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40da20:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40da26:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40da2c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40da32:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40da38:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40da3e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40da44:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40da4d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40da56:	add    rsp,0xa8
  40da5d:	pop    rsi
  40da5e:	pop    rdi
  40da5f:	ret

000000000040da60 <__swc_fn_585f006d_000124_83db7238>:
  40da60:	push   rbx
  40da61:	push   rsi
  40da62:	push   rdi
  40da63:	push   r12
  40da65:	sub    rsp,0x18
  40da69:	mov    rbx,r8
  40da6c:	mov    rsi,rcx
  40da6f:	mov    rdi,rdx
  40da72:	mov    rcx,QWORD PTR [rip+0x155c7]        # 423040 <__swc_bss_base_585f006d>
  40da79:	test   rcx,rcx
  40da7c:	jne    40da8e <__swc_fn_585f006d_000124_83db7238+0x2e>
  40da7e:	call   40e820 <__swc_fn_585f006d_000169_994c8876>
  40da83:	lea    rcx,[rax+0x1]
  40da87:	mov    QWORD PTR [rip+0x155b2],rcx        # 423040 <__swc_bss_base_585f006d>
  40da8e:	dec    rcx
  40da91:	call   40b6e0 <__swc_fn_585f006d_000171_360af05d>
  40da96:	mov    r12,rax
  40da99:	cmp    ebx,0x3
  40da9c:	jne    40daaf <__swc_fn_585f006d_000124_83db7238+0x4f>
  40da9e:	mov    rax,QWORD PTR [r12+0xbd0]
  40daa6:	test   rax,rax
  40daa9:	jne    40dbec <__swc_fn_585f006d_000124_83db7238+0x18c>
  40daaf:	cmp    ebx,0x5
  40dab2:	jne    40dad6 <__swc_fn_585f006d_000124_83db7238+0x76>
  40dab4:	call   4107d0 <__swc_fn_585f006d_000095_ad13d15c>
  40dab9:	test   al,al
  40dabb:	jne    40dad6 <__swc_fn_585f006d_000124_83db7238+0x76>
  40dabd:	mov    rcx,rsi
  40dac0:	mov    rdx,rdi
  40dac3:	call   40b690 <__swc_fn_585f006d_000168_3459066f>
  40dac8:	test   al,al
  40daca:	je     40dad6 <__swc_fn_585f006d_000124_83db7238+0x76>
  40dacc:	add    rsp,0x18
  40dad0:	pop    r12
  40dad2:	pop    rdi
  40dad3:	pop    rsi
  40dad4:	pop    rbx
  40dad5:	ret
  40dad6:	call   4107d0 <__swc_fn_585f006d_000095_ad13d15c>
  40dadb:	test   al,al
  40dadd:	jne    40db4f <__swc_fn_585f006d_000124_83db7238+0xef>
  40dadf:	vmovups xmm0,XMMWORD PTR [rsi]
  40dae3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dae9:	mov    rax,QWORD PTR [rsp+0x8]
  40daee:	test   rax,rax
  40daf1:	jne    40db42 <__swc_fn_585f006d_000124_83db7238+0xe2>
  40daf3:	cmp    ebx,0x3
  40daf6:	je     40db04 <__swc_fn_585f006d_000124_83db7238+0xa4>
  40daf8:	cmp    ebx,0x4
  40dafb:	je     40db14 <__swc_fn_585f006d_000124_83db7238+0xb4>
  40dafd:	cmp    ebx,0x5
  40db00:	je     40db24 <__swc_fn_585f006d_000124_83db7238+0xc4>
  40db02:	jmp    40db34 <__swc_fn_585f006d_000124_83db7238+0xd4>
  40db04:	vmovups xmm0,XMMWORD PTR [rip+0x4aa4]        # 4125b0 <__swc_rdata_base_585f006d+0x4a0>
  40db0c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40db12:	jmp    40db42 <__swc_fn_585f006d_000124_83db7238+0xe2>
  40db14:	vmovups xmm0,XMMWORD PTR [rip+0x4aa4]        # 4125c0 <__swc_rdata_base_585f006d+0x4b0>
  40db1c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40db22:	jmp    40db42 <__swc_fn_585f006d_000124_83db7238+0xe2>
  40db24:	vmovups xmm0,XMMWORD PTR [rip+0x4aa4]        # 4125d0 <__swc_rdata_base_585f006d+0x4c0>
  40db2c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40db32:	jmp    40db42 <__swc_fn_585f006d_000124_83db7238+0xe2>
  40db34:	vmovups xmm0,XMMWORD PTR [rip+0x4aa4]        # 4125e0 <__swc_rdata_base_585f006d+0x4d0>
  40db3c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40db42:	lea    rcx,[rsp+0x8]
  40db47:	mov    rdx,rdi
  40db4a:	call   410a20 <__swc_fn_585f006d_000107_90faaa26>
  40db4f:	vmovups xmm0,XMMWORD PTR [rdi]
  40db53:	vmovups XMMWORD PTR [r12+0x940],xmm0
  40db5d:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  40db62:	vmovups XMMWORD PTR [r12+0x950],xmm0
  40db6c:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  40db71:	vmovups XMMWORD PTR [r12+0x960],xmm0
  40db7b:	lea    rax,[r12+0x940]
  40db83:	mov    QWORD PTR [r12+0x970],rax
  40db8b:	mov    rax,QWORD PTR [rsi]
  40db8e:	mov    QWORD PTR [r12+0x978],rax
  40db96:	mov    rax,QWORD PTR [rsi+0x8]
  40db9a:	mov    QWORD PTR [r12+0x980],rax
  40dba2:	movsxd rax,ebx
  40dba5:	mov    QWORD PTR [r12+0x988],rax
  40dbad:	cmp    ebx,0x5
  40dbb0:	je     40dbb9 <__swc_fn_585f006d_000124_83db7238+0x159>
  40dbb2:	xor    ecx,ecx
  40dbb4:	call   40e950 <__swc_fn_585f006d_000178_718d7b54>
  40dbb9:	mov    rbx,QWORD PTR [r12+0xbe8]
  40dbc1:	test   rbx,rbx
  40dbc4:	je     40dbd5 <__swc_fn_585f006d_000124_83db7238+0x175>
  40dbc6:	mov    rcx,r12
  40dbc9:	call   rbx
  40dbcb:	add    rsp,0x18
  40dbcf:	pop    r12
  40dbd1:	pop    rdi
  40dbd2:	pop    rsi
  40dbd3:	pop    rbx
  40dbd4:	ret
  40dbd5:	mov    rcx,rsi
  40dbd8:	call   409930 <__swc_fn_585f006d_000120_2648f149>
  40dbdd:	call   411050 <__swc_fn_585f006d_000122_be2e2f68>
  40dbe2:	add    rsp,0x18
  40dbe6:	pop    r12
  40dbe8:	pop    rdi
  40dbe9:	pop    rsi
  40dbea:	pop    rbx
  40dbeb:	ret
  40dbec:	mov    rcx,rsi
  40dbef:	mov    rdx,rdi
  40dbf2:	call   410a20 <__swc_fn_585f006d_000107_90faaa26>
  40dbf7:	jmp    40daaf <__swc_fn_585f006d_000124_83db7238+0x4f>
  40dbfc:	add    BYTE PTR [rax],al
	...

000000000040dc00 <__swc_fn_585f006d_000127_58f0f391>:
  40dc00:	push   rdi
  40dc01:	push   rsi
  40dc02:	sub    rsp,0xb8
  40dc09:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40dc0f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40dc15:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40dc1b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40dc21:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40dc27:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40dc2d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40dc33:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40dc3c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40dc45:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40dc4e:	mov    DWORD PTR [rsp+0x8],0x0
  40dc56:	lea    rdi,[rsp+0x8]
  40dc5b:	xor    esi,esi
  40dc5d:	xor    eax,eax
  40dc5f:	call   407190 <pthread_key_create@plt>
  40dc64:	test   eax,eax
  40dc66:	jne    40dc6e <__swc_fn_585f006d_000127_58f0f391+0x6e>
  40dc68:	mov    eax,DWORD PTR [rsp+0x8]
  40dc6c:	jmp    40dc75 <__swc_fn_585f006d_000127_58f0f391+0x75>
  40dc6e:	mov    rax,0xffffffffffffffff
  40dc75:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40dc7b:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40dc81:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40dc87:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40dc8d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40dc93:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40dc99:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40dc9f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40dca8:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40dcb1:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40dcba:	add    rsp,0xb8
  40dcc1:	pop    rsi
  40dcc2:	pop    rdi
  40dcc3:	ret
	...

000000000040dcd0 <__swc_fn_585f006d_000130_4a82cdf6>:
  40dcd0:	push   rdi
  40dcd1:	push   rsi
  40dcd2:	sub    rsp,0xb8
  40dcd9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40dcdf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40dce5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40dceb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40dcf1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40dcf7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40dcfd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40dd03:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40dd0c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40dd15:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40dd1e:	mov    DWORD PTR [rsp+0x8],0x0
  40dd26:	lea    rdi,[rsp+0x8]
  40dd2b:	mov    rsi,rcx
  40dd2e:	xor    eax,eax
  40dd30:	call   407190 <pthread_key_create@plt>
  40dd35:	test   eax,eax
  40dd37:	jne    40dd42 <__swc_fn_585f006d_000130_4a82cdf6+0x72>
  40dd39:	mov    eax,DWORD PTR [rsp+0x8]
  40dd3d:	inc    rax
  40dd40:	jmp    40dd44 <__swc_fn_585f006d_000130_4a82cdf6+0x74>
  40dd42:	xor    eax,eax
  40dd44:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40dd4a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40dd50:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40dd56:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40dd5c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40dd62:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40dd68:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40dd6e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40dd77:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40dd80:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40dd89:	add    rsp,0xb8
  40dd90:	pop    rsi
  40dd91:	pop    rdi
  40dd92:	ret
	...

000000000040dda0 <__swc_fn_585f006d_000133_ae5891af>:
  40dda0:	push   rdi
  40dda1:	push   rsi
  40dda2:	sub    rsp,0xa8
  40dda9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ddaf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ddb5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ddbb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40ddc1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40ddc7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40ddcd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ddd3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ddd9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40dde2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ddeb:	test   rcx,rcx
  40ddee:	setne  al
  40ddf1:	je     40de0a <__swc_fn_585f006d_000133_ae5891af+0x6a>
  40ddf3:	lea    rax,[rcx-0x1]
  40ddf7:	mov    eax,eax
  40ddf9:	mov    edi,eax
  40ddfb:	mov    rsi,rdx
  40ddfe:	xor    eax,eax
  40de00:	call   407120 <pthread_setspecific@plt>
  40de05:	test   eax,eax
  40de07:	sete   al
  40de0a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40de10:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40de16:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40de1c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40de22:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40de28:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40de2e:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40de34:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40de3a:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40de43:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40de4c:	add    rsp,0xa8
  40de53:	pop    rsi
  40de54:	pop    rdi
  40de55:	ret
	...

000000000040de60 <__swc_fn_585f006d_000136_865f5106>:
  40de60:	push   rdi
  40de61:	push   rsi
  40de62:	sub    rsp,0xa8
  40de69:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40de6f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40de75:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40de7b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40de81:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40de87:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40de8d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40de93:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40de99:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40dea2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40deab:	mov    rax,rdx
  40deae:	mov    QWORD PTR [rsp],0x0
  40deb6:	mov    edi,0xca
  40debb:	mov    rsi,rcx
  40debe:	mov    edx,0x81
  40dec3:	mov    eax,eax
  40dec5:	mov    ecx,eax
  40dec7:	xor    r8d,r8d
  40deca:	xor    r9d,r9d
  40decd:	xor    eax,eax
  40decf:	call   4071a0 <syscall@plt>
  40ded4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40deda:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40dee0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40dee6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40deec:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40def2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40def8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40defe:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40df04:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40df0d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40df16:	add    rsp,0xa8
  40df1d:	pop    rsi
  40df1e:	pop    rdi
  40df1f:	ret

000000000040df20 <__swc_fn_585f006d_000139_86bb0f90>:
  40df20:	sub    rsp,0x8
  40df24:	call   4113f0 <__swc_fn_585f006d_000137_8c07c14b>
  40df29:	add    rsp,0x8
  40df2d:	ret
	...

000000000040df30 <__swc_fn_585f006d_000142_be4c2719>:
  40df30:	push   rdi
  40df31:	push   rsi
  40df32:	sub    rsp,0xc8
  40df39:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40df3f:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40df45:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40df4b:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40df51:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40df57:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40df5d:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40df66:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40df6f:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40df78:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40df81:	vxorps xmm0,xmm0,xmm0
  40df85:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40df8b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40df91:	mov    rdi,rcx
  40df94:	lea    rsi,[rsp+0x8]
  40df99:	xor    eax,eax
  40df9b:	call   4071b0 <dladdr@plt>
  40dfa0:	xor    ecx,ecx
  40dfa2:	test   eax,eax
  40dfa4:	je     40dfab <__swc_fn_585f006d_000142_be4c2719+0x7b>
  40dfa6:	mov    rcx,QWORD PTR [rsp+0x10]
  40dfab:	mov    rax,rcx
  40dfae:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40dfb4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40dfba:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40dfc0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40dfc6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40dfcc:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40dfd2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40dfdb:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40dfe4:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40dfed:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40dff6:	add    rsp,0xc8
  40dffd:	pop    rsi
  40dffe:	pop    rdi
  40dfff:	ret

000000000040e000 <__swc_fn_585f006d_000145_1534de9a>:
  40e000:	push   rbx
  40e001:	push   r12
  40e003:	push   r13
  40e005:	push   rdi
  40e006:	push   rsi
  40e007:	push   r14
  40e009:	push   r15
  40e00b:	sub    rsp,0x150
  40e012:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40e01b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40e024:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40e02d:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40e036:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40e03f:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40e048:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40e051:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40e05a:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40e063:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40e06c:	mov    rbx,rdx
  40e06f:	mov    QWORD PTR [rsp+0x98],rdx
  40e077:	mov    r12,rcx
  40e07a:	mov    QWORD PTR [rsp+0xa0],rcx
  40e082:	mov    QWORD PTR [rbx],0x0
  40e089:	lea    r13,[rip+0x17ce8]        # 425d78 <__swc_bss_base_585f006d+0x2d38>
  40e090:	mov    rcx,r13
  40e093:	call   40df20 <__swc_fn_585f006d_000139_86bb0f90>
  40e098:	mov    rax,QWORD PTR [rip+0x17ce1]        # 425d80 <__swc_bss_base_585f006d+0x2d40>
  40e09f:	test   rax,rax
  40e0a2:	je     40e0d9 <__swc_fn_585f006d_000145_1534de9a+0xd9>
  40e0a4:	cs nop WORD PTR [rax+rax*1+0x0]
  40e0ae:	xchg   ax,ax
  40e0b0:	cmp    QWORD PTR [rax+0x8],r12
  40e0b4:	jne    40e0d1 <__swc_fn_585f006d_000145_1534de9a+0xd1>
  40e0b6:	mov    rcx,QWORD PTR [rax+0x18]
  40e0ba:	mov    QWORD PTR [rbx],rcx
  40e0bd:	mov    rbx,QWORD PTR [rax+0x10]
  40e0c1:	mov    rcx,r13
  40e0c4:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40e0c9:	mov    rax,rbx
  40e0cc:	jmp    40e2bb <__swc_fn_585f006d_000145_1534de9a+0x2bb>
  40e0d1:	mov    rax,QWORD PTR [rax]
  40e0d4:	test   rax,rax
  40e0d7:	jne    40e0b0 <__swc_fn_585f006d_000145_1534de9a+0xb0>
  40e0d9:	vxorps xmm0,xmm0,xmm0
  40e0dd:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  40e0e3:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  40e0e9:	mov    rdi,r12
  40e0ec:	lea    rsi,[rsp+0x10]
  40e0f1:	xor    eax,eax
  40e0f3:	call   4071b0 <dladdr@plt>
  40e0f8:	test   eax,eax
  40e0fa:	sete   al
  40e0fd:	je     40e10a <__swc_fn_585f006d_000145_1534de9a+0x10a>
  40e0ff:	mov    rax,QWORD PTR [rsp+0x10]
  40e104:	test   rax,rax
  40e107:	sete   al
  40e10a:	test   al,al
  40e10c:	je     40e11d <__swc_fn_585f006d_000145_1534de9a+0x11d>
  40e10e:	mov    rcx,r13
  40e111:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40e116:	xor    eax,eax
  40e118:	jmp    40e2bb <__swc_fn_585f006d_000145_1534de9a+0x2bb>
  40e11d:	mov    rdi,QWORD PTR [rsp+0x10]
  40e122:	mov    esi,0x80000
  40e127:	xor    eax,eax
  40e129:	call   407010 <open@plt>
  40e12e:	lea    r14,[rsp+0x30]
  40e133:	mov    DWORD PTR [rsp+0x30],eax
  40e137:	cmp    DWORD PTR [r14],0x0
  40e13b:	jge    40e14c <__swc_fn_585f006d_000145_1534de9a+0x14c>
  40e13d:	mov    rcx,r13
  40e140:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40e145:	xor    eax,eax
  40e147:	jmp    40e2bb <__swc_fn_585f006d_000145_1534de9a+0x2bb>
  40e14c:	mov    rax,r14
  40e14f:	movsxd rdi,DWORD PTR [rax]
  40e152:	xor    esi,esi
  40e154:	mov    edx,0x2
  40e159:	xor    eax,eax
  40e15b:	call   4070c0 <lseek@plt>
  40e160:	mov    r15,rax
  40e163:	test   rax,rax
  40e166:	jg     40e181 <__swc_fn_585f006d_000145_1534de9a+0x181>
  40e168:	movsxd rdi,DWORD PTR [r14]
  40e16b:	xor    eax,eax
  40e16d:	call   407040 <close@plt>
  40e172:	mov    rcx,r13
  40e175:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40e17a:	xor    eax,eax
  40e17c:	jmp    40e2bb <__swc_fn_585f006d_000145_1534de9a+0x2bb>
  40e181:	xor    edi,edi
  40e183:	mov    rsi,r15
  40e186:	mov    edx,0x1
  40e18b:	mov    ecx,0x2
  40e190:	mov    rax,r14
  40e193:	movsxd r8,DWORD PTR [rax]
  40e196:	xor    r9d,r9d
  40e199:	xor    eax,eax
  40e19b:	call   4070d0 <mmap@plt>
  40e1a0:	mov    rbx,rax
  40e1a3:	test   rax,rax
  40e1a6:	sete   al
  40e1a9:	cmp    rbx,0xffffffffffffffff
  40e1ad:	sete   cl
  40e1b0:	or     al,cl
  40e1b2:	je     40e1cd <__swc_fn_585f006d_000145_1534de9a+0x1cd>
  40e1b4:	movsxd rdi,DWORD PTR [r14]
  40e1b7:	xor    eax,eax
  40e1b9:	call   407040 <close@plt>
  40e1be:	mov    rcx,r13
  40e1c1:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40e1c6:	xor    eax,eax
  40e1c8:	jmp    40e2bb <__swc_fn_585f006d_000145_1534de9a+0x2bb>
  40e1cd:	lea    rax,[rsp+0x50]
  40e1d2:	mov    QWORD PTR [rax],0x0
  40e1d9:	mov    rcx,rbx
  40e1dc:	mov    rdx,r15
  40e1df:	mov    r8,rax
  40e1e2:	call   409ec0 <__swc_fn_585f006d_000144_d5d4d43f>
  40e1e7:	mov    r12,rax
  40e1ea:	test   rax,rax
  40e1ed:	jne    40e215 <__swc_fn_585f006d_000145_1534de9a+0x215>
  40e1ef:	mov    rdi,rbx
  40e1f2:	mov    rsi,r15
  40e1f5:	xor    eax,eax
  40e1f7:	call   407160 <munmap@plt>
  40e1fc:	movsxd rdi,DWORD PTR [r14]
  40e1ff:	xor    eax,eax
  40e201:	call   407040 <close@plt>
  40e206:	mov    rcx,r13
  40e209:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40e20e:	xor    eax,eax
  40e210:	jmp    40e2bb <__swc_fn_585f006d_000145_1534de9a+0x2bb>
  40e215:	mov    edi,0x20
  40e21a:	xor    eax,eax
  40e21c:	call   4071c0 <malloc@plt>
  40e221:	test   rax,rax
  40e224:	jne    40e249 <__swc_fn_585f006d_000145_1534de9a+0x249>
  40e226:	mov    rdi,rbx
  40e229:	mov    rsi,r15
  40e22c:	xor    eax,eax
  40e22e:	call   407160 <munmap@plt>
  40e233:	movsxd rdi,DWORD PTR [r14]
  40e236:	xor    eax,eax
  40e238:	call   407040 <close@plt>
  40e23d:	mov    rcx,r13
  40e240:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40e245:	xor    eax,eax
  40e247:	jmp    40e2bb <__swc_fn_585f006d_000145_1534de9a+0x2bb>
  40e249:	mov    rcx,QWORD PTR [rip+0x17b30]        # 425d80 <__swc_bss_base_585f006d+0x2d40>
  40e250:	mov    QWORD PTR [rsp+0x70],rcx
  40e255:	mov    rcx,QWORD PTR [rsp+0xa0]
  40e25d:	mov    QWORD PTR [rsp+0x78],rcx
  40e262:	mov    QWORD PTR [rsp+0x80],r12
  40e26a:	mov    rcx,QWORD PTR [rsp+0x50]
  40e26f:	mov    QWORD PTR [rsp+0x88],rcx
  40e277:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  40e27d:	vmovups XMMWORD PTR [rax],xmm0
  40e281:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  40e28a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e28f:	mov    QWORD PTR [rip+0x17aea],rax        # 425d80 <__swc_bss_base_585f006d+0x2d40>
  40e296:	mov    rax,QWORD PTR [rsp+0x50]
  40e29b:	mov    rbx,QWORD PTR [rsp+0x98]
  40e2a3:	mov    QWORD PTR [rbx],rax
  40e2a6:	movsxd rdi,DWORD PTR [r14]
  40e2a9:	xor    eax,eax
  40e2ab:	call   407040 <close@plt>
  40e2b0:	mov    rcx,r13
  40e2b3:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40e2b8:	mov    rax,r12
  40e2bb:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40e2c4:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40e2cd:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40e2d6:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40e2df:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40e2e8:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40e2f1:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40e2fa:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40e303:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40e30c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40e315:	add    rsp,0x150
  40e31c:	pop    r15
  40e31e:	pop    r14
  40e320:	pop    rsi
  40e321:	pop    rdi
  40e322:	pop    r13
  40e324:	pop    r12
  40e326:	pop    rbx
  40e327:	ret
	...

000000000040e330 <__swc_fn_585f006d_000148_43c96957>:
  40e330:	push   rbx
  40e331:	sub    rsp,0xe0
  40e338:	lea    rbx,[rsp+0x8]
  40e33d:	vxorps xmm0,xmm0,xmm0
  40e341:	vmovups YMMWORD PTR [rbx],ymm0
  40e345:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40e34a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40e34f:	vzeroupper
  40e352:	mov    DWORD PTR [rbx+0x60],0x0
  40e359:	mov    r8,rbx
  40e35c:	nop    DWORD PTR [rax+0x0]
  40e360:	mov    r9,rcx
  40e363:	movabs rcx,0xcccccccccccccccd
  40e36d:	mov    rax,r9
  40e370:	mul    rcx
  40e373:	mov    r10,rdx
  40e376:	shr    r10,0x3
  40e37a:	mov    rcx,r10
  40e37d:	imul   rdx,r10,0xa
  40e381:	sub    r9,rdx
  40e384:	mov    rdx,QWORD PTR [rip+0x4285]        # 412610 <__swc_rdata_base_585f006d+0x500>
  40e38b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  40e390:	mov    BYTE PTR [r8],dl
  40e393:	lea    rdx,[r8+0x1]
  40e397:	mov    r8,rdx
  40e39a:	test   r10,r10
  40e39d:	jne    40e360 <__swc_fn_585f006d_000148_43c96957+0x30>
  40e39f:	mov    BYTE PTR [rdx],0x0
  40e3a2:	sub    r8,0x1
  40e3a6:	mov    rax,rbx
  40e3a9:	cmp    rax,r8
  40e3ac:	jae    40e3c6 <__swc_fn_585f006d_000148_43c96957+0x96>
  40e3ae:	xchg   ax,ax
  40e3b0:	mov    cl,BYTE PTR [r8]
  40e3b3:	mov    dl,BYTE PTR [rax]
  40e3b5:	mov    BYTE PTR [r8],dl
  40e3b8:	sub    r8,0x1
  40e3bc:	mov    BYTE PTR [rax],cl
  40e3be:	inc    rax
  40e3c1:	cmp    rax,r8
  40e3c4:	jb     40e3b0 <__swc_fn_585f006d_000148_43c96957+0x80>
  40e3c6:	xor    eax,eax
  40e3c8:	test   rbx,rbx
  40e3cb:	je     40e3ee <__swc_fn_585f006d_000148_43c96957+0xbe>
  40e3cd:	mov    rcx,rbx
  40e3d0:	mov    dl,BYTE PTR [rcx]
  40e3d2:	test   dl,dl
  40e3d4:	je     40e3ee <__swc_fn_585f006d_000148_43c96957+0xbe>
  40e3d6:	cs nop WORD PTR [rax+rax*1+0x0]
  40e3e0:	add    rcx,0x1
  40e3e4:	add    rax,0x1
  40e3e8:	mov    dl,BYTE PTR [rcx]
  40e3ea:	test   dl,dl
  40e3ec:	jne    40e3e0 <__swc_fn_585f006d_000148_43c96957+0xb0>
  40e3ee:	mov    QWORD PTR [rbx+0xa8],rbx
  40e3f5:	mov    QWORD PTR [rbx+0xb0],rax
  40e3fc:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40e404:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40e40c:	lea    rcx,[rbx+0xb8]
  40e413:	call   409930 <__swc_fn_585f006d_000120_2648f149>
  40e418:	add    rsp,0xe0
  40e41f:	pop    rbx
  40e420:	ret
	...

000000000040e430 <__swc_fn_585f006d_000151_6fb05988>:
  40e430:	sub    rsp,0x8
  40e434:	mov    rax,QWORD PTR [rcx+0x8]
  40e438:	mov    r8,QWORD PTR [rdx+0x8]
  40e43c:	cmp    rax,r8
  40e43f:	je     40e448 <__swc_fn_585f006d_000151_6fb05988+0x18>
  40e441:	xor    eax,eax
  40e443:	add    rsp,0x8
  40e447:	ret
  40e448:	test   rax,rax
  40e44b:	jne    40e45c <__swc_fn_585f006d_000151_6fb05988+0x2c>
  40e44d:	test   r8,r8
  40e450:	jne    40e45c <__swc_fn_585f006d_000151_6fb05988+0x2c>
  40e452:	mov    eax,0x1
  40e457:	add    rsp,0x8
  40e45b:	ret
  40e45c:	mov    rcx,QWORD PTR [rcx]
  40e45f:	mov    rdx,QWORD PTR [rdx]
  40e462:	test   rcx,rcx
  40e465:	sete   r8b
  40e469:	test   rdx,rdx
  40e46c:	sete   r9b
  40e470:	or     r8b,r9b
  40e473:	je     40e480 <__swc_fn_585f006d_000151_6fb05988+0x50>
  40e475:	cmp    rcx,rdx
  40e478:	sete   al
  40e47b:	add    rsp,0x8
  40e47f:	ret
  40e480:	cmp    rcx,rdx
  40e483:	jne    40e48f <__swc_fn_585f006d_000151_6fb05988+0x5f>
  40e485:	mov    eax,0x1
  40e48a:	add    rsp,0x8
  40e48e:	ret
  40e48f:	mov    r8,rax
  40e492:	call   410ae0 <__swc_fn_585f006d_000110_3dc01326>
  40e497:	test   eax,eax
  40e499:	sete   al
  40e49c:	add    rsp,0x8
  40e4a0:	ret
	...

000000000040e4b0 <__swc_fn_585f006d_000154_86f1d437>:
  40e4b0:	vxorps xmm0,xmm0,xmm0
  40e4b4:	vmovups XMMWORD PTR [rcx],xmm0
  40e4b8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e4bd:	vxorps xmm0,xmm0,xmm0
  40e4c1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e4c6:	vmovups xmm0,XMMWORD PTR [rip+0x41fa]        # 4126c8 <__swc_rdata_base_585f006d+0x5b8>
  40e4ce:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e4d3:	ret
	...

000000000040e4e0 <__swc_fn_585f006d_000157_86f1d437>:
  40e4e0:	vxorps xmm0,xmm0,xmm0
  40e4e4:	vmovups XMMWORD PTR [rcx],xmm0
  40e4e8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e4ed:	vxorps xmm0,xmm0,xmm0
  40e4f1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e4f6:	vmovups xmm0,XMMWORD PTR [rip+0x42ea]        # 4127e8 <__swc_rdata_base_585f006d+0x6d8>
  40e4fe:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e503:	mov    QWORD PTR [rcx+0x40],0x0
  40e50b:	ret
  40e50c:	add    BYTE PTR [rax],al
	...

000000000040e510 <__swc_fn_585f006d_000160_47b270e1>:
  40e510:	push   rbx
  40e511:	sub    rsp,0x70
  40e515:	mov    rax,QWORD PTR [rcx]
  40e518:	mov    rbx,QWORD PTR [rcx+0x8]
  40e51c:	vxorps xmm0,xmm0,xmm0
  40e520:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40e526:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40e52c:	vzeroupper
  40e52f:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40e535:	mov    QWORD PTR [rsp+0x48],rdx
  40e53a:	mov    QWORD PTR [rsp+0x50],r8
  40e53f:	mov    rcx,rax
  40e542:	lea    rdx,[rsp+0x8]
  40e547:	mov    rbx,QWORD PTR [rbx+0x18]
  40e54b:	call   rbx
  40e54d:	add    rsp,0x70
  40e551:	pop    rbx
  40e552:	ret
	...

000000000040e560 <__swc_fn_585f006d_000163_8a3d304f>:
  40e560:	push   rbx
  40e561:	push   rsi
  40e562:	push   rdi
  40e563:	mov    rbx,r8
  40e566:	mov    rsi,rcx
  40e569:	mov    rdi,rdx
  40e56c:	call   4117f0 <__swc_fn_585f006d_000161_13ead2ff>
  40e571:	vmovups xmm0,XMMWORD PTR [rbx]
  40e575:	vmovups XMMWORD PTR [rsi],xmm0
  40e579:	mov    QWORD PTR [rsi+0x18],rdi
  40e57d:	pop    rdi
  40e57e:	pop    rsi
  40e57f:	pop    rbx
  40e580:	ret
	...

000000000040e590 <__swc_fn_585f006d_000166_cc119975>:
  40e590:	push   rbx
  40e591:	push   rsi
  40e592:	push   rdi
  40e593:	push   r12
  40e595:	push   r13
  40e597:	sub    rsp,0x50
  40e59b:	mov    rbx,rcx
  40e59e:	mov    rsi,rdx
  40e5a1:	vmovups xmm0,XMMWORD PTR [rip+0x434f]        # 4128f8 <__swc_rdata_base_585f006d+0x7e8>
  40e5a9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e5af:	vmovups xmm0,XMMWORD PTR [rip+0x4351]        # 412908 <__swc_rdata_base_585f006d+0x7f8>
  40e5b7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e5bd:	vxorps xmm0,xmm0,xmm0
  40e5c1:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e5c7:	mov    rcx,rdx
  40e5ca:	call   40df30 <__swc_fn_585f006d_000142_be4c2719>
  40e5cf:	mov    rdi,rax
  40e5d2:	test   rax,rax
  40e5d5:	jne    40e606 <__swc_fn_585f006d_000166_cc119975+0x76>
  40e5d7:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e5dd:	vmovups XMMWORD PTR [rbx],xmm0
  40e5e1:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e5e7:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e5ec:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e5f2:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e5f7:	mov    rax,rbx
  40e5fa:	add    rsp,0x50
  40e5fe:	pop    r13
  40e600:	pop    r12
  40e602:	pop    rdi
  40e603:	pop    rsi
  40e604:	pop    rbx
  40e605:	ret
  40e606:	mov    rcx,rdi
  40e609:	call   40b3e0 <__swc_fn_585f006d_000165_016ee66a>
  40e60e:	mov    r11,rax
  40e611:	test   rax,rax
  40e614:	je     40e61e <__swc_fn_585f006d_000166_cc119975+0x8e>
  40e616:	mov    al,BYTE PTR [r11+0x24]
  40e61a:	test   al,al
  40e61c:	jne    40e64d <__swc_fn_585f006d_000166_cc119975+0xbd>
  40e61e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e624:	vmovups XMMWORD PTR [rbx],xmm0
  40e628:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e62e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e633:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e639:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e63e:	mov    rax,rbx
  40e641:	add    rsp,0x50
  40e645:	pop    r13
  40e647:	pop    r12
  40e649:	pop    rdi
  40e64a:	pop    rsi
  40e64b:	pop    rbx
  40e64c:	ret
  40e64d:	sub    rsi,rdi
  40e650:	mov    eax,0xffffffff
  40e655:	cmp    rsi,rax
  40e658:	jbe    40e689 <__swc_fn_585f006d_000166_cc119975+0xf9>
  40e65a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e660:	vmovups XMMWORD PTR [rbx],xmm0
  40e664:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e66a:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e66f:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e675:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e67a:	mov    rax,rbx
  40e67d:	add    rsp,0x50
  40e681:	pop    r13
  40e683:	pop    r12
  40e685:	pop    rdi
  40e686:	pop    rsi
  40e687:	pop    rbx
  40e688:	ret
  40e689:	mov    rdi,QWORD PTR [r11+0x10]
  40e68d:	mov    eax,DWORD PTR [r11+0x20]
  40e691:	xor    ecx,ecx
  40e693:	test   rax,rax
  40e696:	jbe    40e7e8 <__swc_fn_585f006d_000166_cc119975+0x258>
  40e69c:	nop    DWORD PTR [rax+0x0]
  40e6a0:	mov    edx,ecx
  40e6a2:	imul   r12,rdx,0x14
  40e6a6:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40e6ab:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40e6b0:	mov    r9d,esi
  40e6b3:	cmp    r9,rdx
  40e6b6:	jb     40e7db <__swc_fn_585f006d_000166_cc119975+0x24b>
  40e6bc:	add    rdx,r8
  40e6bf:	mov    r8d,esi
  40e6c2:	cmp    r8,rdx
  40e6c5:	jae    40e7db <__swc_fn_585f006d_000166_cc119975+0x24b>
  40e6cb:	lea    rsi,[rsp+0x38]
  40e6d0:	mov    eax,DWORD PTR [rdi+0xc]
  40e6d3:	mov    DWORD PTR [rsp+0x38],eax
  40e6d7:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40e6dc:	mov    rcx,rdi
  40e6df:	mov    rdx,QWORD PTR [r11+0x18]
  40e6e3:	mov    r8,rsi
  40e6e6:	mov    r8d,DWORD PTR [r8]
  40e6e9:	mov    r9,rax
  40e6ec:	lea    r10,[rsp+0x10]
  40e6f1:	call   411840 <__swc_fn_585f006d_000164_72795826>
  40e6f6:	test   al,al
  40e6f8:	jne    40e72b <__swc_fn_585f006d_000166_cc119975+0x19b>
  40e6fa:	vmovups xmm0,XMMWORD PTR [rip+0x4226]        # 412928 <__swc_rdata_base_585f006d+0x818>
  40e702:	vmovups XMMWORD PTR [rbx],xmm0
  40e706:	vmovups xmm0,XMMWORD PTR [rip+0x422a]        # 412938 <__swc_rdata_base_585f006d+0x828>
  40e70e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e713:	vxorps xmm0,xmm0,xmm0
  40e717:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e71c:	mov    rax,rbx
  40e71f:	add    rsp,0x50
  40e723:	pop    r13
  40e725:	pop    r12
  40e727:	pop    rdi
  40e728:	pop    rsi
  40e729:	pop    rbx
  40e72a:	ret
  40e72b:	lea    r13,[rsp+0x3c]
  40e730:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40e735:	mov    DWORD PTR [rsp+0x3c],eax
  40e739:	test   eax,eax
  40e73b:	je     40e78c <__swc_fn_585f006d_000166_cc119975+0x1fc>
  40e73d:	mov    rcx,rdi
  40e740:	mov    rdx,QWORD PTR [r11+0x18]
  40e744:	mov    r8d,DWORD PTR [rsi]
  40e747:	mov    rax,r13
  40e74a:	mov    r9d,DWORD PTR [rax]
  40e74d:	lea    r10,[rsp+0x20]
  40e752:	call   411840 <__swc_fn_585f006d_000164_72795826>
  40e757:	test   al,al
  40e759:	jne    40e78c <__swc_fn_585f006d_000166_cc119975+0x1fc>
  40e75b:	vmovups xmm0,XMMWORD PTR [rip+0x41f5]        # 412958 <__swc_rdata_base_585f006d+0x848>
  40e763:	vmovups XMMWORD PTR [rbx],xmm0
  40e767:	vmovups xmm0,XMMWORD PTR [rip+0x41f9]        # 412968 <__swc_rdata_base_585f006d+0x858>
  40e76f:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e774:	vxorps xmm0,xmm0,xmm0
  40e778:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e77d:	mov    rax,rbx
  40e780:	add    rsp,0x50
  40e784:	pop    r13
  40e786:	pop    r12
  40e788:	pop    rdi
  40e789:	pop    rsi
  40e78a:	pop    rbx
  40e78b:	ret
  40e78c:	mov    eax,0x1
  40e791:	rex mov BYTE PTR [rsp+0x8],al
  40e796:	cmp    DWORD PTR [r13+0x0],0x0
  40e79b:	je     40e7ac <__swc_fn_585f006d_000166_cc119975+0x21c>
  40e79d:	rex mov BYTE PTR [rsp+0x9],0x1
  40e7a3:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40e7a8:	mov    DWORD PTR [rsp+0x30],eax
  40e7ac:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e7b2:	vmovups XMMWORD PTR [rbx],xmm0
  40e7b6:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e7bc:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e7c1:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e7c7:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e7cc:	mov    rax,rbx
  40e7cf:	add    rsp,0x50
  40e7d3:	pop    r13
  40e7d5:	pop    r12
  40e7d7:	pop    rdi
  40e7d8:	pop    rsi
  40e7d9:	pop    rbx
  40e7da:	ret
  40e7db:	add    rcx,0x1
  40e7df:	cmp    rcx,rax
  40e7e2:	jb     40e6a0 <__swc_fn_585f006d_000166_cc119975+0x110>
  40e7e8:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e7ee:	vmovups XMMWORD PTR [rbx],xmm0
  40e7f2:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e7f8:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e7fd:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e803:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e808:	mov    rax,rbx
  40e80b:	add    rsp,0x50
  40e80f:	pop    r13
  40e811:	pop    r12
  40e813:	pop    rdi
  40e814:	pop    rsi
  40e815:	pop    rbx
  40e816:	ret
	...

000000000040e820 <__swc_fn_585f006d_000169_994c8876>:
  40e820:	sub    rsp,0x48
  40e824:	call   40dc00 <__swc_fn_585f006d_000127_58f0f391>
  40e829:	cmp    rax,0xffffffffffffffff
  40e82d:	je     40e834 <__swc_fn_585f006d_000169_994c8876+0x14>
  40e82f:	add    rsp,0x48
  40e833:	ret
  40e834:	lea    rcx,[rip+0x415d]        # 412998 <__swc_rdata_base_585f006d+0x888>
  40e83b:	vmovups xmm0,XMMWORD PTR [rip+0x4165]        # 4129a8 <__swc_rdata_base_585f006d+0x898>
  40e843:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e849:	vmovups xmm0,XMMWORD PTR [rip+0x4167]        # 4129b8 <__swc_rdata_base_585f006d+0x8a8>
  40e851:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e857:	vmovups xmm0,XMMWORD PTR [rip+0x4169]        # 4129c8 <__swc_rdata_base_585f006d+0x8b8>
  40e85f:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e865:	lea    rdx,[rsp+0x8]
  40e86a:	mov    QWORD PTR [rsp+0x38],rax
  40e86f:	call   410a20 <__swc_fn_585f006d_000107_90faaa26>
  40e874:	mov    rax,QWORD PTR [rsp+0x38]
  40e879:	jmp    40e82f <__swc_fn_585f006d_000169_994c8876+0xf>
  40e87b:	add    BYTE PTR [rax],al
  40e87d:	add    BYTE PTR [rax],al
	...

000000000040e880 <__swc_fn_585f006d_000172_cbeff767>:
  40e880:	push   rbx
  40e881:	push   rsi
  40e882:	sub    rsp,0x28
  40e886:	mov    rbx,rcx
  40e889:	mov    DWORD PTR [rsp+0x8],0xbf0
  40e891:	mov    ecx,0xbf0
  40e896:	call   410610 <__swc_fn_585f006d_000083_4a10c7e7>
  40e89b:	mov    rsi,rax
  40e89e:	test   rax,rax
  40e8a1:	jne    40e8ac <__swc_fn_585f006d_000172_cbeff767+0x2c>
  40e8a3:	xor    eax,eax
  40e8a5:	add    rsp,0x28
  40e8a9:	pop    rsi
  40e8aa:	pop    rbx
  40e8ab:	ret
  40e8ac:	vxorps xmm0,xmm0,xmm0
  40e8b0:	xor    eax,eax
  40e8b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40e8bc:	nop    DWORD PTR [rax+0x0]
  40e8c0:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40e8c5:	add    rax,0x10
  40e8c9:	cmp    rax,0xbf0
  40e8d0:	jne    40e8c0 <__swc_fn_585f006d_000172_cbeff767+0x40>
  40e8d2:	lea    rax,[rbx+0x1]
  40e8d6:	mov    QWORD PTR [rsi+0x9c0],rax
  40e8dd:	mov    rcx,rbx
  40e8e0:	mov    rdx,rsi
  40e8e3:	call   411ba0 <__swc_fn_585f006d_000170_646fdf20>
  40e8e8:	test   al,al
  40e8ea:	jne    40e8fd <__swc_fn_585f006d_000172_cbeff767+0x7d>
  40e8ec:	mov    rcx,rsi
  40e8ef:	call   4088b0 <__swc_fn_585f006d_000084_cf82995a>
  40e8f4:	xor    eax,eax
  40e8f6:	add    rsp,0x28
  40e8fa:	pop    rsi
  40e8fb:	pop    rbx
  40e8fc:	ret
  40e8fd:	lea    rcx,[rsp+0x18]
  40e902:	call   408e30 <__swc_fn_585f006d_000096_93bfe675>
  40e907:	mov    rax,rsi
  40e90a:	add    rsp,0x28
  40e90e:	pop    rsi
  40e90f:	pop    rbx
  40e910:	ret
	...

000000000040e920 <__swc_fn_585f006d_000175_e09f8b62>:
  40e920:	xor    eax,eax
  40e922:	mov    edx,0x1
  40e927:	lock cmpxchg QWORD PTR [rcx],rdx
  40e92c:	test   rax,rax
  40e92f:	jne    40e932 <__swc_fn_585f006d_000175_e09f8b62+0x12>
  40e931:	ret
  40e932:	cs nop WORD PTR [rax+rax*1+0x0]
  40e93c:	nop    DWORD PTR [rax+0x0]
  40e940:	mov    rax,QWORD PTR [rcx]
  40e943:	test   rax,rax
  40e946:	je     40e920 <__swc_fn_585f006d_000175_e09f8b62>
  40e948:	jmp    40e940 <__swc_fn_585f006d_000175_e09f8b62+0x20>
  40e94a:	add    BYTE PTR [rax],al
  40e94c:	add    BYTE PTR [rax],al
	...

000000000040e950 <__swc_fn_585f006d_000178_718d7b54>:
  40e950:	push   rsi
  40e951:	push   rdi
  40e952:	sub    rsp,0x38
  40e956:	mov    rsi,rcx
  40e959:	call   411bb0 <__swc_fn_585f006d_000173_1e0ea8cf>
  40e95e:	mov    rdi,rax
  40e961:	call   411340 <__swc_fn_585f006d_000134_a9c1c700>
  40e966:	mov    r8,rax
  40e969:	mov    rcx,rdi
  40e96c:	call   40e920 <__swc_fn_585f006d_000175_e09f8b62>
  40e971:	mov    rax,QWORD PTR [rdi+0x8]
  40e975:	test   rax,rax
  40e978:	je     40e9b5 <__swc_fn_585f006d_000178_718d7b54+0x65>
  40e97a:	nop    WORD PTR [rax+rax*1+0x0]
  40e980:	cmp    rax,rsi
  40e983:	je     40e9b5 <__swc_fn_585f006d_000178_718d7b54+0x65>
  40e985:	mov    r9,QWORD PTR [rax]
  40e988:	cmp    QWORD PTR [rax+0x20],r8
  40e98c:	jne    40e9ad <__swc_fn_585f006d_000178_718d7b54+0x5d>
  40e98e:	mov    rcx,rdi
  40e991:	mov    rdx,rax
  40e994:	mov    QWORD PTR [rsp+0x28],r8
  40e999:	mov    QWORD PTR [rsp+0x30],r9
  40e99e:	call   40b800 <__swc_fn_585f006d_000177_cf4ffedd>
  40e9a3:	mov    r8,QWORD PTR [rsp+0x28]
  40e9a8:	mov    r9,QWORD PTR [rsp+0x30]
  40e9ad:	mov    rax,r9
  40e9b0:	test   r9,r9
  40e9b3:	jne    40e980 <__swc_fn_585f006d_000178_718d7b54+0x30>
  40e9b5:	xor    eax,eax
  40e9b7:	mov    QWORD PTR [rdi],rax
  40e9ba:	add    rsp,0x38
  40e9be:	pop    rdi
  40e9bf:	pop    rsi
  40e9c0:	ret
	...

000000000040e9e0 <__swc_fn_585f006d_000002_1ca87929>:
  40e9e0:	push   rdi
  40e9e1:	push   rsi
  40e9e2:	sub    rsp,0xb8
  40e9e9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40e9ef:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40e9f5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40e9fb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40ea01:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40ea07:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40ea0d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40ea13:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40ea1c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40ea25:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40ea2e:	vxorps xmm0,xmm0,xmm0
  40ea32:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ea38:	mov    edi,0x1
  40ea3d:	lea    rsi,[rsp+0x8]
  40ea42:	xor    eax,eax
  40ea44:	call   407130 <clock_gettime@plt>
  40ea49:	vxorpd xmm0,xmm0,xmm0
  40ea4d:	mov    rax,QWORD PTR [rsp+0x8]
  40ea52:	vcvtsi2sd xmm0,xmm0,rax
  40ea57:	vxorpd xmm1,xmm1,xmm1
  40ea5b:	mov    rax,QWORD PTR [rsp+0x10]
  40ea60:	vcvtsi2sd xmm1,xmm1,rax
  40ea65:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x36a3]        # 412110 <__swc_rdata_base_585f006d>
  40ea6d:	vaddsd xmm0,xmm0,xmm1
  40ea71:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ea77:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40ea7d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40ea83:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ea89:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ea8f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ea95:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ea9b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40eaa4:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40eaad:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40eab6:	add    rsp,0xb8
  40eabd:	pop    rsi
  40eabe:	pop    rdi
  40eabf:	ret

000000000040eac0 <__swc_fn_585f006d_000005_9ee35b18>:
  40eac0:	vxorps xmm0,xmm0,xmm0
  40eac4:	xor    eax,eax
  40eac6:	cs nop WORD PTR [rax+rax*1+0x0]
  40ead0:	cs nop WORD PTR [rax+rax*1+0x0]
  40eada:	nop    WORD PTR [rax+rax*1+0x0]
  40eae0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40eae5:	add    rax,0x10
  40eae9:	cmp    rax,0x2080
  40eaf0:	jne    40eae0 <__swc_fn_585f006d_000005_9ee35b18+0x20>
  40eaf2:	ret
	...

000000000040eb00 <__swc_fn_585f006d_000008_d64b2baa>:
  40eb00:	push   rsi
  40eb01:	push   rdi
  40eb02:	push   r12
  40eb04:	push   r13
  40eb06:	push   r14
  40eb08:	mov    rsi,rcx
  40eb0b:	mov    edi,r10d
  40eb0e:	mov    r12,rcx
  40eb11:	mov    r13,r9
  40eb14:	mov    ecx,DWORD PTR [rdx+0x28]
  40eb17:	shlx   r14d,r8d,ecx
  40eb1c:	mov    rcx,rdx
  40eb1f:	mov    edx,r8d
  40eb22:	call   407770 <__swc_fn_585f006d_000015_9dea5065>
  40eb27:	mov    rcx,rax
  40eb2a:	mov    eax,DWORD PTR [r12+0x3c]
  40eb2f:	xor    edx,edx
  40eb31:	div    rdi
  40eb34:	vxorps xmm0,xmm0,xmm0
  40eb38:	vmovdqu XMMWORD PTR [rsi],xmm0
  40eb3c:	mov    QWORD PTR [r12+0x60],0x0
  40eb45:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40eb4a:	mov    QWORD PTR [r12+0x10],rcx
  40eb4f:	imul   rax,rdi
  40eb53:	lea    rdx,[rcx+rax*1]
  40eb57:	mov    QWORD PTR [r12+0x18],rdx
  40eb5c:	mov    QWORD PTR [r12+0x20],rcx
  40eb61:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40eb66:	mov    DWORD PTR [r12+0x28],0x0
  40eb6f:	mov    DWORD PTR [r12+0x68],0x0
  40eb78:	mov    BYTE PTR [r12+0x39],r13b
  40eb7d:	mov    BYTE PTR [r12+0x3a],r14b
  40eb82:	mov    BYTE PTR [r12+0x3b],0x1
  40eb88:	mov    DWORD PTR [r12+0x6c],0x0
  40eb91:	mov    rcx,r12
  40eb94:	mov    edx,edi
  40eb96:	call   4076d0 <__swc_fn_585f006d_000009_065ed5b1>
  40eb9b:	pop    r14
  40eb9d:	pop    r13
  40eb9f:	pop    r12
  40eba1:	pop    rdi
  40eba2:	pop    rsi
  40eba3:	ret
	...

000000000040ebb0 <__swc_fn_585f006d_000011_c3647f66>:
  40ebb0:	mov    r8d,0x1
  40ebb6:	xor    eax,eax
  40ebb8:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40ebbe:	test   eax,eax
  40ebc0:	jne    40ebb0 <__swc_fn_585f006d_000011_c3647f66>
  40ebc2:	ret
	...

000000000040ebd0 <__swc_fn_585f006d_000014_524c1f23>:
  40ebd0:	lea    r8,[rcx+0x60]
  40ebd4:	mov    rax,QWORD PTR [r8]
  40ebd7:	mov    r9,rax
  40ebda:	nop    WORD PTR [rax+rax*1+0x0]
  40ebe0:	mov    QWORD PTR [rdx],r9
  40ebe3:	mov    rax,r9
  40ebe6:	lock cmpxchg QWORD PTR [r8],rdx
  40ebeb:	cmp    rax,r9
  40ebee:	jne    40ec57 <__swc_fn_585f006d_000014_524c1f23+0x87>
  40ebf0:	mov    eax,DWORD PTR [rcx+0x6c]
  40ebf3:	test   eax,eax
  40ebf5:	je     40ec56 <__swc_fn_585f006d_000014_524c1f23+0x86>
  40ebf7:	lea    rdx,[rcx+0x70]
  40ebfb:	mov    r9d,0x1
  40ec01:	xor    eax,eax
  40ec03:	lock cmpxchg DWORD PTR [rdx],r9d
  40ec08:	test   eax,eax
  40ec0a:	jne    40ec56 <__swc_fn_585f006d_000014_524c1f23+0x86>
  40ec0c:	mov    rax,rcx
  40ec0f:	and    rax,0xffffffffffc00000
  40ec16:	mov    rax,QWORD PTR [rax+0x8]
  40ec1a:	test   rax,rax
  40ec1d:	jne    40ec25 <__swc_fn_585f006d_000014_524c1f23+0x55>
  40ec1f:	xor    eax,eax
  40ec21:	xchg   DWORD PTR [rdx],eax
  40ec23:	jmp    40ec56 <__swc_fn_585f006d_000014_524c1f23+0x86>
  40ec25:	lea    rdx,[rax+0x2a80]
  40ec2c:	mov    rax,QWORD PTR [rdx]
  40ec2f:	mov    r8,rax
  40ec32:	cs nop WORD PTR [rax+rax*1+0x0]
  40ec3c:	nop    DWORD PTR [rax+0x0]
  40ec40:	mov    QWORD PTR [rcx+0x78],r8
  40ec44:	mov    rax,r8
  40ec47:	lock cmpxchg QWORD PTR [rdx],rcx
  40ec4c:	cmp    rax,r8
  40ec4f:	je     40ec56 <__swc_fn_585f006d_000014_524c1f23+0x86>
  40ec51:	mov    r8,rax
  40ec54:	jmp    40ec40 <__swc_fn_585f006d_000014_524c1f23+0x70>
  40ec56:	ret
  40ec57:	mov    r9,rax
  40ec5a:	jmp    40ebe0 <__swc_fn_585f006d_000014_524c1f23+0x10>
	...

000000000040ec60 <__swc_fn_585f006d_000017_efc44797>:
  40ec60:	push   rsi
  40ec61:	push   rdi
  40ec62:	push   r12
  40ec64:	push   r13
  40ec66:	push   r14
  40ec68:	push   r15
  40ec6a:	push   rbx
  40ec6b:	sub    rsp,0x30
  40ec6f:	mov    QWORD PTR [rsp+0x18],r8
  40ec74:	mov    rsi,rcx
  40ec77:	mov    rdi,rdx
  40ec7a:	mov    rdx,QWORD PTR [rsi+0x40]
  40ec7e:	xchg   ax,ax
  40ec80:	mov    rax,rdx
  40ec83:	not    rax
  40ec86:	and    rax,QWORD PTR [rsi+0x20]
  40ec8a:	test   rax,rax
  40ec8d:	jne    40eca1 <__swc_fn_585f006d_000017_efc44797+0x41>
  40ec8f:	xor    eax,eax
  40ec91:	add    rsp,0x30
  40ec95:	pop    rbx
  40ec96:	pop    r15
  40ec98:	pop    r14
  40ec9a:	pop    r13
  40ec9c:	pop    r12
  40ec9e:	pop    rdi
  40ec9f:	pop    rsi
  40eca0:	ret
  40eca1:	xor    ecx,ecx
  40eca3:	tzcnt  rcx,rax
  40eca8:	lea    r12,[rsp+0x8]
  40ecad:	mov    DWORD PTR [rsp+0x8],ecx
  40ecb1:	mov    r13d,0x1
  40ecb7:	shl    r13,cl
  40ecba:	mov    rcx,rdx
  40ecbd:	or     rcx,r13
  40ecc0:	mov    rax,rdx
  40ecc3:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40ecc9:	cmp    rax,rdx
  40eccc:	je     40ecd3 <__swc_fn_585f006d_000017_efc44797+0x73>
  40ecce:	mov    rdx,rax
  40ecd1:	jmp    40ec80 <__swc_fn_585f006d_000017_efc44797+0x20>
  40ecd3:	mov    eax,DWORD PTR [r12]
  40ecd7:	shl    rax,0x4
  40ecdb:	lea    r14,[rsi+rax*8+0x80]
  40ece3:	mov    rcx,rsi
  40ece6:	mov    rax,r12
  40ece9:	mov    edx,DWORD PTR [rax]
  40eceb:	call   407770 <__swc_fn_585f006d_000015_9dea5065>
  40ecf0:	mov    r15,rax
  40ecf3:	mov    rcx,rsi
  40ecf6:	mov    rdx,r13
  40ecf9:	call   4078d0 <__swc_fn_585f006d_000021_fd2b165c>
  40ecfe:	test   al,al
  40ed00:	je     40ed38 <__swc_fn_585f006d_000017_efc44797+0xd8>
  40ed02:	mov    ecx,DWORD PTR [r14+0x3c]
  40ed06:	lea    rdx,[rip+0x14353]        # 423060 <__swc_bss_base_585f006d+0x20>
  40ed0d:	mov    r8,QWORD PTR [rip+0x1434c]        # 423060 <__swc_bss_base_585f006d+0x20>
  40ed14:	cs nop WORD PTR [rax+rax*1+0x0]
  40ed1e:	xchg   ax,ax
  40ed20:	mov    r9,r8
  40ed23:	sub    r9,rcx
  40ed26:	mov    rax,r8
  40ed29:	lock cmpxchg QWORD PTR [rdx],r9
  40ed2e:	cmp    rax,r8
  40ed31:	je     40ed99 <__swc_fn_585f006d_000017_efc44797+0x139>
  40ed33:	mov    r8,rax
  40ed36:	jmp    40ed20 <__swc_fn_585f006d_000017_efc44797+0xc0>
  40ed38:	mov    rcx,rsi
  40ed3b:	mov    rax,r12
  40ed3e:	mov    edx,DWORD PTR [rax]
  40ed40:	call   40bae0 <__swc_fn_585f006d_000016_9afb7cfb>
  40ed45:	mov    rcx,r15
  40ed48:	and    rcx,0xffffffffffff0000
  40ed4f:	lea    rcx,[rcx+0x10000]
  40ed56:	mov    rbx,rax
  40ed59:	cmp    rax,rcx
  40ed5c:	cmova  rbx,rcx
  40ed60:	mov    rax,rbx
  40ed63:	sub    rax,r15
  40ed66:	mov    rcx,r15
  40ed69:	mov    rdx,rax
  40ed6c:	call   40b930 <__swc_fn_585f006d_000007_f7acedb0>
  40ed71:	test   al,al
  40ed73:	jne    40ed92 <__swc_fn_585f006d_000017_efc44797+0x132>
  40ed75:	mov    rcx,rsi
  40ed78:	mov    rdx,r13
  40ed7b:	call   40bc90 <__swc_fn_585f006d_000022_c8f5f27c>
  40ed80:	xor    eax,eax
  40ed82:	add    rsp,0x30
  40ed86:	pop    rbx
  40ed87:	pop    r15
  40ed89:	pop    r14
  40ed8b:	pop    r13
  40ed8d:	pop    r12
  40ed8f:	pop    rdi
  40ed90:	pop    rsi
  40ed91:	ret
  40ed92:	sub    rbx,r15
  40ed95:	mov    DWORD PTR [r14+0x3c],ebx
  40ed99:	mov    rcx,r14
  40ed9c:	mov    rdx,rsi
  40ed9f:	mov    r8d,DWORD PTR [r12]
  40eda3:	mov    r9d,edi
  40eda6:	mov    rbx,QWORD PTR [rsp+0x18]
  40edab:	mov    r10d,ebx
  40edae:	call   40eb00 <__swc_fn_585f006d_000008_d64b2baa>
  40edb3:	mov    rax,r14
  40edb6:	add    rsp,0x30
  40edba:	pop    rbx
  40edbb:	pop    r15
  40edbd:	pop    r14
  40edbf:	pop    r13
  40edc1:	pop    r12
  40edc3:	pop    rdi
  40edc4:	pop    rsi
  40edc5:	ret
	...

000000000040edd0 <__swc_fn_585f006d_000020_de02dbdf>:
  40edd0:	mov    r8,QWORD PTR [rcx+0x48]
  40edd4:	cs nop WORD PTR [rax+rax*1+0x0]
  40edde:	xchg   ax,ax
  40ede0:	mov    r9,r8
  40ede3:	or     r9,rdx
  40ede6:	mov    rax,r8
  40ede9:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40edef:	cmp    rax,r8
  40edf2:	jne    40edf5 <__swc_fn_585f006d_000020_de02dbdf+0x25>
  40edf4:	ret
  40edf5:	mov    r8,rax
  40edf8:	jmp    40ede0 <__swc_fn_585f006d_000020_de02dbdf+0x10>
  40edfa:	add    BYTE PTR [rax],al
  40edfc:	add    BYTE PTR [rax],al
	...

000000000040ee00 <__swc_fn_585f006d_000023_2d0fcd2c>:
  40ee00:	push   rsi
  40ee01:	push   rdi
  40ee02:	push   r12
  40ee04:	mov    rsi,rcx
  40ee07:	xor    edi,edi
  40ee09:	lea    r12,[rip+0x14260]        # 423070 <__swc_bss_base_585f006d+0x30>
  40ee10:	mov    eax,DWORD PTR [r12]
  40ee14:	xor    ecx,ecx
  40ee16:	test   rax,rax
  40ee19:	jbe    40ee54 <__swc_fn_585f006d_000023_2d0fcd2c+0x54>
  40ee1b:	nop    DWORD PTR [rax+rax*1+0x0]
  40ee20:	lea    rdx,[rip+0x14251]        # 423078 <__swc_bss_base_585f006d+0x38>
  40ee27:	mov    r8d,ecx
  40ee2a:	lea    r8,[r8+r8*2]
  40ee2e:	lea    r8,[rdx+r8*8]
  40ee32:	mov    rdx,QWORD PTR [r8+0x10]
  40ee36:	add    rdx,0x400000
  40ee3d:	cmp    rdx,0x40000000
  40ee44:	ja     40ee4b <__swc_fn_585f006d_000023_2d0fcd2c+0x4b>
  40ee46:	mov    rdi,r8
  40ee49:	jmp    40ee54 <__swc_fn_585f006d_000023_2d0fcd2c+0x54>
  40ee4b:	add    rcx,0x1
  40ee4f:	cmp    rcx,rax
  40ee52:	jb     40ee20 <__swc_fn_585f006d_000023_2d0fcd2c+0x20>
  40ee54:	test   rdi,rdi
  40ee57:	jne    40eee3 <__swc_fn_585f006d_000023_2d0fcd2c+0xe3>
  40ee5d:	cmp    DWORD PTR [r12],0x10
  40ee62:	jae    40eecb <__swc_fn_585f006d_000023_2d0fcd2c+0xcb>
  40ee64:	mov    ecx,0x40400000
  40ee69:	call   407690 <__swc_fn_585f006d_000006_81d2e1e9>
  40ee6e:	test   rax,rax
  40ee71:	je     40eecb <__swc_fn_585f006d_000023_2d0fcd2c+0xcb>
  40ee73:	lea    rcx,[rip+0x141fe]        # 423078 <__swc_bss_base_585f006d+0x38>
  40ee7a:	mov    edx,DWORD PTR [r12]
  40ee7e:	lea    rdx,[rdx+rdx*2]
  40ee82:	lea    rdx,[rcx+rdx*8]
  40ee86:	mov    QWORD PTR [rdx],rax
  40ee89:	lea    rax,[rax+0x3fffff]
  40ee90:	and    rax,0xffffffffffc00000
  40ee97:	mov    QWORD PTR [rdx+0x8],rax
  40ee9b:	mov    QWORD PTR [rdx+0x10],0x0
  40eea3:	mov    edx,DWORD PTR [rip+0x141c7]        # 423070 <__swc_bss_base_585f006d+0x30>
  40eea9:	nop    DWORD PTR [rax+0x0]
  40eeb0:	lea    r9d,[rdx+0x1]
  40eeb4:	mov    rax,rdx
  40eeb7:	lock cmpxchg DWORD PTR [r12],r9d
  40eebd:	mov    r8d,eax
  40eec0:	cmp    eax,edx
  40eec2:	je     40eed2 <__swc_fn_585f006d_000023_2d0fcd2c+0xd2>
  40eec4:	mov    rdx,r8
  40eec7:	jmp    40eeb0 <__swc_fn_585f006d_000023_2d0fcd2c+0xb0>
  40eec9:	jmp    40eed2 <__swc_fn_585f006d_000023_2d0fcd2c+0xd2>
  40eecb:	xor    eax,eax
  40eecd:	pop    r12
  40eecf:	pop    rdi
  40eed0:	pop    rsi
  40eed1:	ret
  40eed2:	mov    eax,DWORD PTR [rip+0x14198]        # 423070 <__swc_bss_base_585f006d+0x30>
  40eed8:	sub    eax,0x1
  40eedb:	lea    rdi,[rax+rax*2]
  40eedf:	lea    rdi,[rcx+rdi*8]
  40eee3:	mov    r12,QWORD PTR [rdi+0x8]
  40eee7:	add    r12,QWORD PTR [rdi+0x10]
  40eeeb:	mov    rcx,r12
  40eeee:	mov    edx,0x3000
  40eef3:	call   40b930 <__swc_fn_585f006d_000007_f7acedb0>
  40eef8:	test   al,al
  40eefa:	jne    40ef03 <__swc_fn_585f006d_000023_2d0fcd2c+0x103>
  40eefc:	xor    eax,eax
  40eefe:	pop    r12
  40ef00:	pop    rdi
  40ef01:	pop    rsi
  40ef02:	ret
  40ef03:	vxorps xmm0,xmm0,xmm0
  40ef07:	xor    eax,eax
  40ef09:	cs nop WORD PTR [rax+rax*1+0x0]
  40ef13:	cs nop WORD PTR [rax+rax*1+0x0]
  40ef1d:	nop    DWORD PTR [rax]
  40ef20:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40ef26:	add    rax,0x10
  40ef2a:	cmp    rax,0x3000
  40ef31:	jne    40ef20 <__swc_fn_585f006d_000023_2d0fcd2c+0x120>
  40ef33:	mov    DWORD PTR [r12+0x28],esi
  40ef38:	mov    eax,0x40
  40ef3d:	mov    ecx,esi
  40ef3f:	shr    eax,cl
  40ef41:	mov    DWORD PTR [r12+0x2c],eax
  40ef46:	cmp    DWORD PTR [r12+0x2c],0x40
  40ef4c:	jb     40ef57 <__swc_fn_585f006d_000023_2d0fcd2c+0x157>
  40ef4e:	mov    rax,0xffffffffffffffff
  40ef55:	jmp    40ef67 <__swc_fn_585f006d_000023_2d0fcd2c+0x167>
  40ef57:	mov    eax,0x1
  40ef5c:	mov    ecx,DWORD PTR [r12+0x2c]
  40ef61:	shl    rax,cl
  40ef64:	dec    rax
  40ef67:	mov    QWORD PTR [r12+0x20],rax
  40ef6c:	mov    DWORD PTR [r12],0x4e540001
  40ef74:	mov    DWORD PTR [r12+0x4],0x53474d45
  40ef7d:	add    QWORD PTR [rdi+0x10],0x400000
  40ef85:	mov    rax,r12
  40ef88:	pop    r12
  40ef8a:	pop    rdi
  40ef8b:	pop    rsi
  40ef8c:	ret
  40ef8d:	add    BYTE PTR [rax],al
	...

000000000040ef90 <__swc_fn_585f006d_000026_bcdc5519>:
  40ef90:	mov    eax,0x1
  40ef95:	mov    edx,DWORD PTR [rip+0x140d5]        # 423070 <__swc_bss_base_585f006d+0x30>
  40ef9b:	cmp    eax,edx
  40ef9d:	jae    40efeb <__swc_fn_585f006d_000026_bcdc5519+0x5b>
  40ef9f:	nop
  40efa0:	lea    r8,[rip+0x140d1]        # 423078 <__swc_bss_base_585f006d+0x38>
  40efa7:	lea    r9,[rax+rax*2]
  40efab:	lea    r9,[r8+r9*8]
  40efaf:	mov    r8,rcx
  40efb2:	sub    r8,QWORD PTR [r9+0x8]
  40efb6:	mov    r9,QWORD PTR [r9+0x10]
  40efba:	cmp    r8,r9
  40efbd:	jae    40efe5 <__swc_fn_585f006d_000026_bcdc5519+0x55>
  40efbf:	mov    rax,rcx
  40efc2:	and    rax,0xffffffffffc00000
  40efc9:	shr    rcx,0x10
  40efcd:	and    ecx,0x3f
  40efd0:	mov    edx,DWORD PTR [rax+0x28]
  40efd3:	shrx   ecx,ecx,edx
  40efd8:	shl    rcx,0x4
  40efdc:	lea    rax,[rax+rcx*8+0x80]
  40efe4:	ret
  40efe5:	inc    eax
  40efe7:	cmp    eax,edx
  40efe9:	jb     40efa0 <__swc_fn_585f006d_000026_bcdc5519+0x10>
  40efeb:	xor    eax,eax
  40efed:	ret
	...

000000000040eff0 <__swc_fn_585f006d_000029_9798fb47>:
  40eff0:	vxorps xmm0,xmm0,xmm0
  40eff4:	vmovups XMMWORD PTR [rcx],xmm0
  40eff8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40effd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40f002:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40f007:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40f00c:	mov    QWORD PTR [rcx+0x50],0x0
  40f014:	ret
	...

000000000040f020 <__swc_fn_585f006d_000032_9798fb47>:
  40f020:	vxorps xmm0,xmm0,xmm0
  40f024:	xor    eax,eax
  40f026:	cs nop WORD PTR [rax+rax*1+0x0]
  40f030:	cs nop WORD PTR [rax+rax*1+0x0]
  40f03a:	nop    WORD PTR [rax+rax*1+0x0]
  40f040:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40f045:	add    rax,0x10
  40f049:	cmp    rax,0x9b0
  40f050:	jne    40f040 <__swc_fn_585f006d_000032_9798fb47+0x20>
  40f052:	mov    QWORD PTR [rcx+0x9b0],0x0
  40f05d:	ret
	...

000000000040f060 <__swc_fn_585f006d_000035_cd1a4e8c>:
  40f060:	push   rsi
  40f061:	push   rdi
  40f062:	sub    rsp,0x8
  40f066:	lea    rsi,[rip+0x11f9b]        # 421008 <__swc_data_base_585f006d+0x8>
  40f06d:	mov    rax,QWORD PTR [rsi]
  40f070:	mov    ecx,0xffffffff
  40f075:	cmp    rax,rcx
  40f078:	je     40f081 <__swc_fn_585f006d_000035_cd1a4e8c+0x21>
  40f07a:	add    rsp,0x8
  40f07e:	pop    rdi
  40f07f:	pop    rsi
  40f080:	ret
  40f081:	mov    rcx,QWORD PTR [rip+0x3068]        # 4120f0 <__swc_fn_585f006d_000176_4de704de+0x4f0>
  40f088:	call   40dcd0 <__swc_fn_585f006d_000130_4a82cdf6>
  40f08d:	mov    rcx,rax
  40f090:	mov    eax,0xffffffff
  40f095:	lock cmpxchg QWORD PTR [rsi],rcx
  40f09a:	mov    rdi,rax
  40f09d:	mov    eax,0xffffffff
  40f0a2:	cmp    rdi,rax
  40f0a5:	je     40f0b6 <__swc_fn_585f006d_000035_cd1a4e8c+0x56>
  40f0a7:	call   411290 <__swc_fn_585f006d_000131_a611b8c4>
  40f0ac:	mov    rax,rdi
  40f0af:	add    rsp,0x8
  40f0b3:	pop    rdi
  40f0b4:	pop    rsi
  40f0b5:	ret
  40f0b6:	mov    rax,rcx
  40f0b9:	add    rsp,0x8
  40f0bd:	pop    rdi
  40f0be:	pop    rsi
  40f0bf:	ret

000000000040f0c0 <__swc_fn_585f006d_000038_14f56618>:
  40f0c0:	sub    rsp,0x8
  40f0c4:	vxorps xmm0,xmm0,xmm0
  40f0c8:	xor    eax,eax
  40f0ca:	cs nop WORD PTR [rax+rax*1+0x0]
  40f0d4:	cs nop WORD PTR [rax+rax*1+0x0]
  40f0de:	xchg   ax,ax
  40f0e0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40f0e5:	add    rax,0x10
  40f0e9:	cmp    rax,0x2b00
  40f0f0:	jne    40f0e0 <__swc_fn_585f006d_000038_14f56618+0x20>
  40f0f2:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40f0fc:	xor    al,al
  40f0fe:	mov    rdx,rax
  40f101:	xor    al,al
  40f103:	mov    r8,rax
  40f106:	xor    al,al
  40f108:	mov    r9,rax
  40f10b:	xor    al,al
  40f10d:	mov    r10,rax
  40f110:	xor    al,al
  40f112:	mov    r11,rax
  40f115:	call   407b10 <__swc_fn_585f006d_000039_03f1bf9a>
  40f11a:	add    rsp,0x8
  40f11e:	ret
	...

000000000040f120 <__swc_fn_585f006d_000041_c90d80c1>:
  40f120:	push   rsi
  40f121:	push   rdi
  40f122:	push   r12
  40f124:	mov    rsi,r8
  40f127:	mov    rdi,rdx
  40f12a:	mov    rcx,rdx
  40f12d:	call   407690 <__swc_fn_585f006d_000006_81d2e1e9>
  40f132:	mov    r12,rax
  40f135:	test   rax,rax
  40f138:	jne    40f141 <__swc_fn_585f006d_000041_c90d80c1+0x21>
  40f13a:	xor    eax,eax
  40f13c:	pop    r12
  40f13e:	pop    rdi
  40f13f:	pop    rsi
  40f140:	ret
  40f141:	mov    rcx,r12
  40f144:	mov    rdx,rsi
  40f147:	call   40b930 <__swc_fn_585f006d_000007_f7acedb0>
  40f14c:	test   al,al
  40f14e:	jne    40f162 <__swc_fn_585f006d_000041_c90d80c1+0x42>
  40f150:	mov    rcx,r12
  40f153:	mov    rdx,rdi
  40f156:	call   409910 <__swc_fn_585f006d_000117_ed2d8fed>
  40f15b:	xor    eax,eax
  40f15d:	pop    r12
  40f15f:	pop    rdi
  40f160:	pop    rsi
  40f161:	ret
  40f162:	mov    rax,r12
  40f165:	pop    r12
  40f167:	pop    rdi
  40f168:	pop    rsi
  40f169:	ret
	...

000000000040f180 <__swc_fn_585f006d_000044_a78ae66b>:
  40f180:	push   rsi
  40f181:	push   rdi
  40f182:	push   r12
  40f184:	mov    rsi,rcx
  40f187:	mov    edx,0x9b8
  40f18c:	call   407b80 <__swc_fn_585f006d_000042_facd3e17>
  40f191:	mov    rdi,rax
  40f194:	test   rax,rax
  40f197:	jne    40f1a0 <__swc_fn_585f006d_000044_a78ae66b+0x20>
  40f199:	xor    eax,eax
  40f19b:	pop    r12
  40f19d:	pop    rdi
  40f19e:	pop    rsi
  40f19f:	ret
  40f1a0:	vxorps xmm0,xmm0,xmm0
  40f1a4:	xor    eax,eax
  40f1a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40f1b0:	cs nop WORD PTR [rax+rax*1+0x0]
  40f1ba:	nop    WORD PTR [rax+rax*1+0x0]
  40f1c0:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40f1c5:	add    rax,0x10
  40f1c9:	cmp    rax,0x9b0
  40f1d0:	jne    40f1c0 <__swc_fn_585f006d_000044_a78ae66b+0x40>
  40f1d2:	mov    QWORD PTR [rdi+0x9b0],0x0
  40f1dd:	mov    QWORD PTR [rdi],rsi
  40f1e0:	call   411340 <__swc_fn_585f006d_000134_a9c1c700>
  40f1e5:	mov    QWORD PTR [rdi+0x18],rax
  40f1e9:	lea    r12,[rsi+0x10]
  40f1ed:	mov    rcx,r12
  40f1f0:	call   40df20 <__swc_fn_585f006d_000139_86bb0f90>
  40f1f5:	mov    rax,QWORD PTR [rsi+0x20]
  40f1f9:	mov    QWORD PTR [rdi+0x8],rax
  40f1fd:	mov    rax,QWORD PTR [rsi+0x20]
  40f201:	test   rax,rax
  40f204:	je     40f20a <__swc_fn_585f006d_000044_a78ae66b+0x8a>
  40f206:	mov    QWORD PTR [rax+0x10],rdi
  40f20a:	mov    QWORD PTR [rsi+0x20],rdi
  40f20e:	mov    rcx,r12
  40f211:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40f216:	mov    rax,rdi
  40f219:	pop    r12
  40f21b:	pop    rdi
  40f21c:	pop    rsi
  40f21d:	ret
	...

000000000040f220 <__swc_fn_585f006d_000047_6e7a8d58>:
  40f220:	mov    rax,QWORD PTR [rdx+0x10]
  40f224:	test   rax,rax
  40f227:	je     40f233 <__swc_fn_585f006d_000047_6e7a8d58+0x13>
  40f229:	mov    rcx,QWORD PTR [rdx+0x8]
  40f22d:	mov    QWORD PTR [rax+0x8],rcx
  40f231:	jmp    40f23b <__swc_fn_585f006d_000047_6e7a8d58+0x1b>
  40f233:	mov    rax,QWORD PTR [rdx+0x8]
  40f237:	mov    QWORD PTR [rcx+0x20],rax
  40f23b:	mov    rax,QWORD PTR [rdx+0x8]
  40f23f:	test   rax,rax
  40f242:	je     40f24c <__swc_fn_585f006d_000047_6e7a8d58+0x2c>
  40f244:	mov    rcx,QWORD PTR [rdx+0x10]
  40f248:	mov    QWORD PTR [rax+0x10],rcx
  40f24c:	vxorps xmm0,xmm0,xmm0
  40f250:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40f255:	ret
	...

000000000040f260 <__swc_fn_585f006d_000050_129b9bf4>:
  40f260:	sub    rsp,0x8
  40f264:	mov    r9,r8
  40f267:	mov    r10,rdx
  40f26a:	call   407c30 <__swc_fn_585f006d_000048_137687bb>
  40f26f:	mov    eax,0x1
  40f274:	xchg   DWORD PTR [r9+0x6c],eax
  40f278:	mov    rax,QWORD PTR [r9+0x60]
  40f27c:	test   rax,rax
  40f27f:	je     40f2c3 <__swc_fn_585f006d_000050_129b9bf4+0x63>
  40f281:	xor    eax,eax
  40f283:	xchg   DWORD PTR [r9+0x6c],eax
  40f287:	movzx  eax,BYTE PTR [r9+0x39]
  40f28c:	lea    rax,[rax+rax*4]
  40f290:	lea    rax,[r10+rax*8+0x28]
  40f295:	mov    QWORD PTR [r9+0x50],0x0
  40f29d:	mov    rcx,QWORD PTR [rax+0x8]
  40f2a1:	mov    QWORD PTR [r9+0x48],rcx
  40f2a5:	mov    rcx,QWORD PTR [rax+0x8]
  40f2a9:	test   rcx,rcx
  40f2ac:	je     40f2b4 <__swc_fn_585f006d_000050_129b9bf4+0x54>
  40f2ae:	mov    QWORD PTR [rcx+0x50],r9
  40f2b2:	jmp    40f2b8 <__swc_fn_585f006d_000050_129b9bf4+0x58>
  40f2b4:	mov    QWORD PTR [rax+0x10],r9
  40f2b8:	mov    QWORD PTR [rax+0x8],r9
  40f2bc:	xor    eax,eax
  40f2be:	add    rsp,0x8
  40f2c2:	ret
  40f2c3:	movzx  eax,BYTE PTR [r9+0x39]
  40f2c8:	lea    rax,[rax+rax*4]
  40f2cc:	lea    rax,[r10+rax*8+0x28]
  40f2d1:	mov    QWORD PTR [r9+0x50],0x0
  40f2d9:	mov    rcx,QWORD PTR [rax+0x18]
  40f2dd:	mov    QWORD PTR [r9+0x48],rcx
  40f2e1:	mov    rcx,QWORD PTR [rax+0x18]
  40f2e5:	test   rcx,rcx
  40f2e8:	je     40f2ee <__swc_fn_585f006d_000050_129b9bf4+0x8e>
  40f2ea:	mov    QWORD PTR [rcx+0x50],r9
  40f2ee:	mov    QWORD PTR [rax+0x18],r9
  40f2f2:	mov    eax,0x1
  40f2f7:	add    rsp,0x8
  40f2fb:	ret
  40f2fc:	add    BYTE PTR [rax],al
	...

000000000040f300 <__swc_fn_585f006d_000053_3af34d7f>:
  40f300:	push   r12
  40f302:	push   r13
  40f304:	push   rdi
  40f305:	push   rsi
  40f306:	push   r14
  40f308:	push   r15
  40f30a:	sub    rsp,0x178
  40f311:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40f31a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40f323:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40f32c:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40f335:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40f33e:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40f347:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40f350:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40f359:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40f362:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40f36b:	mov    r12,rcx
  40f36e:	lea    rax,[rip+0x13e93]        # 423208 <__swc_bss_base_585f006d+0x1c8>
  40f375:	mov    rcx,QWORD PTR [rax]
  40f378:	mov    r13,rcx
  40f37b:	test   rcx,rcx
  40f37e:	jne    40f38e <__swc_fn_585f006d_000053_3af34d7f+0x8e>
  40f380:	mov    r13d,0x1dcd6500
  40f386:	mov    ecx,0x1dcd6500
  40f38b:	xchg   QWORD PTR [rax],rcx
  40f38e:	lea    rax,[rip+0x11c6b]        # 421000 <__swc_data_base_585f006d>
  40f395:	mov    rax,QWORD PTR [rax]
  40f398:	cmp    rax,0xffffffffffffffff
  40f39c:	je     40f3ab <__swc_fn_585f006d_000053_3af34d7f+0xab>
  40f39e:	mov    eax,eax
  40f3a0:	mov    edi,eax
  40f3a2:	xor    eax,eax
  40f3a4:	call   407000 <pthread_getspecific@plt>
  40f3a9:	jmp    40f3ad <__swc_fn_585f006d_000053_3af34d7f+0xad>
  40f3ab:	xor    eax,eax
  40f3ad:	test   rax,rax
  40f3b0:	jne    40f3bf <__swc_fn_585f006d_000053_3af34d7f+0xbf>
  40f3b2:	call   40f060 <__swc_fn_585f006d_000035_cd1a4e8c>
  40f3b7:	mov    rcx,rax
  40f3ba:	call   409c60 <__swc_fn_585f006d_000132_5f757033>
  40f3bf:	test   rax,rax
  40f3c2:	je     40f3d4 <__swc_fn_585f006d_000053_3af34d7f+0xd4>
  40f3c4:	cmp    QWORD PTR [rax],r12
  40f3c7:	jne    40f3d4 <__swc_fn_585f006d_000053_3af34d7f+0xd4>
  40f3c9:	cmp    DWORD PTR [rax+0x20],0x0
  40f3cd:	jne    40f3d4 <__swc_fn_585f006d_000053_3af34d7f+0xd4>
  40f3cf:	mov    rsi,rax
  40f3d2:	jmp    40f3d6 <__swc_fn_585f006d_000053_3af34d7f+0xd6>
  40f3d4:	xor    esi,esi
  40f3d6:	lea    rdi,[r12+0x2a88]
  40f3de:	mov    r14,QWORD PTR [rdi]
  40f3e1:	test   r14,r14
  40f3e4:	jne    40f433 <__swc_fn_585f006d_000053_3af34d7f+0x133>
  40f3e6:	lea    rax,[rip+0x13c73]        # 423060 <__swc_bss_base_585f006d+0x20>
  40f3ed:	mov    rax,QWORD PTR [rax]
  40f3f0:	test   rax,rax
  40f3f3:	setne  al
  40f3f6:	jne    40f41a <__swc_fn_585f006d_000053_3af34d7f+0x11a>
  40f3f8:	mov    rax,QWORD PTR [r12+0x2a70]
  40f400:	test   rax,rax
  40f403:	setne  al
  40f406:	jne    40f41a <__swc_fn_585f006d_000053_3af34d7f+0x11a>
  40f408:	test   rsi,rsi
  40f40b:	setne  al
  40f40e:	je     40f41a <__swc_fn_585f006d_000053_3af34d7f+0x11a>
  40f410:	cmp    DWORD PTR [rsi+0x730],0x0
  40f417:	setne  al
  40f41a:	test   al,al
  40f41c:	je     40f42e <__swc_fn_585f006d_000053_3af34d7f+0x12e>
  40f41e:	call   409d10 <__swc_fn_585f006d_000135_07d76562>
  40f423:	lea    rcx,[rax+r13*1]
  40f427:	xor    eax,eax
  40f429:	lock cmpxchg QWORD PTR [rdi],rcx
  40f42e:	jmp    40f533 <__swc_fn_585f006d_000053_3af34d7f+0x233>
  40f433:	call   409d10 <__swc_fn_585f006d_000135_07d76562>
  40f438:	mov    r15,rax
  40f43b:	cmp    rax,r14
  40f43e:	jb     40f44f <__swc_fn_585f006d_000053_3af34d7f+0x14f>
  40f440:	xor    ecx,ecx
  40f442:	mov    rax,r14
  40f445:	lock cmpxchg QWORD PTR [rdi],rcx
  40f44a:	cmp    rax,r14
  40f44d:	je     40f454 <__swc_fn_585f006d_000053_3af34d7f+0x154>
  40f44f:	jmp    40f533 <__swc_fn_585f006d_000053_3af34d7f+0x233>
  40f454:	test   rsi,rsi
  40f457:	je     40f472 <__swc_fn_585f006d_000053_3af34d7f+0x172>
  40f459:	cmp    r15,r13
  40f45c:	jb     40f472 <__swc_fn_585f006d_000053_3af34d7f+0x172>
  40f45e:	mov    rax,r15
  40f461:	sub    rax,r13
  40f464:	mov    rcx,r12
  40f467:	mov    rdx,rsi
  40f46a:	mov    r8,rax
  40f46d:	call   408070 <__swc_fn_585f006d_000063_dea90857>
  40f472:	lea    rsi,[r12+0x10]
  40f477:	mov    rcx,rsi
  40f47a:	call   40df20 <__swc_fn_585f006d_000139_86bb0f90>
  40f47f:	mov    rax,QWORD PTR [r12+0x18]
  40f484:	mov    rdi,rax
  40f487:	test   rdi,rdi
  40f48a:	je     40f4b4 <__swc_fn_585f006d_000053_3af34d7f+0x1b4>
  40f48c:	cs nop WORD PTR [rax+rax*1+0x0]
  40f496:	cs nop WORD PTR [rax+rax*1+0x0]
  40f4a0:	mov    rcx,rdi
  40f4a3:	call   40bb00 <__swc_fn_585f006d_000019_adca76cf>
  40f4a8:	mov    rax,QWORD PTR [rdi+0x10]
  40f4ac:	mov    rdi,rax
  40f4af:	test   rax,rax
  40f4b2:	jne    40f4a0 <__swc_fn_585f006d_000053_3af34d7f+0x1a0>
  40f4b4:	mov    rcx,rsi
  40f4b7:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40f4bc:	mov    rcx,r12
  40f4bf:	call   40df20 <__swc_fn_585f006d_000139_86bb0f90>
  40f4c4:	xor    esi,esi
  40f4c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40f4d0:	mov    rax,QWORD PTR [r12+0x2a70]
  40f4d8:	cmp    rsi,rax
  40f4db:	jae    40f52b <__swc_fn_585f006d_000053_3af34d7f+0x22b>
  40f4dd:	lea    rax,[rsi+rsi*4]
  40f4e1:	lea    rax,[r12+rax*8+0x268]
  40f4e9:	mov    r8,QWORD PTR [rax]
  40f4ec:	mov    r9,QWORD PTR [rax+0x8]
  40f4f0:	mov    r10,QWORD PTR [rax+0x10]
  40f4f4:	mov    rax,QWORD PTR [rax+0x20]
  40f4f8:	cmp    rax,r15
  40f4fb:	jae    40f508 <__swc_fn_585f006d_000053_3af34d7f+0x208>
  40f4fd:	mov    rcx,r15
  40f500:	sub    rcx,rax
  40f503:	cmp    rcx,r13
  40f506:	jae    40f50d <__swc_fn_585f006d_000053_3af34d7f+0x20d>
  40f508:	inc    rsi
  40f50b:	jmp    40f4d0 <__swc_fn_585f006d_000053_3af34d7f+0x1d0>
  40f50d:	mov    rcx,r12
  40f510:	mov    rdx,rsi
  40f513:	call   408020 <__swc_fn_585f006d_000060_15c28ca7>
  40f518:	mov    rcx,r12
  40f51b:	mov    rdx,r8
  40f51e:	mov    r8,r9
  40f521:	mov    r9,r10
  40f524:	call   40bde0 <__swc_fn_585f006d_000043_d3c2ab54>
  40f529:	jmp    40f4d0 <__swc_fn_585f006d_000053_3af34d7f+0x1d0>
  40f52b:	mov    rcx,r12
  40f52e:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40f533:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40f53c:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40f545:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40f54e:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40f557:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40f560:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40f569:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40f572:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40f57b:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40f584:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40f58d:	add    rsp,0x178
  40f594:	pop    r15
  40f596:	pop    r14
  40f598:	pop    rsi
  40f599:	pop    rdi
  40f59a:	pop    r13
  40f59c:	pop    r12
  40f59e:	ret
	...

000000000040f5a0 <__swc_fn_585f006d_000056_df0696cd>:
  40f5a0:	lea    rax,[rdx-0x58]
  40f5a4:	ret
	...

000000000040f5b0 <__swc_fn_585f006d_000059_2ca0cb05>:
  40f5b0:	push   rsi
  40f5b1:	push   rdi
  40f5b2:	push   r12
  40f5b4:	push   r13
  40f5b6:	sub    rsp,0x68
  40f5ba:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40f5c0:	mov    rsi,r9
  40f5c3:	mov    rdi,rcx
  40f5c6:	mov    r12,rdx
  40f5c9:	mov    r13,r8
  40f5cc:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40f5d4:	jne    40f5e3 <__swc_fn_585f006d_000059_2ca0cb05+0x33>
  40f5d6:	xor    eax,eax
  40f5d8:	add    rsp,0x68
  40f5dc:	pop    r13
  40f5de:	pop    r12
  40f5e0:	pop    rdi
  40f5e1:	pop    rsi
  40f5e2:	ret
  40f5e3:	mov    rcx,rdi
  40f5e6:	call   40df20 <__swc_fn_585f006d_000139_86bb0f90>
  40f5eb:	movabs rax,0x7fffffffffffffff
  40f5f5:	cmp    r12,rax
  40f5f8:	mov    rax,0xffffffffffffffff
  40f5ff:	lea    rcx,[r12+r12*1]
  40f603:	cmovbe rax,rcx
  40f607:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40f60e:	mov    rdx,rcx
  40f611:	sub    rax,r12
  40f614:	inc    rax
  40f617:	xor    r8d,r8d
  40f61a:	test   rcx,rcx
  40f61d:	jbe    40f648 <__swc_fn_585f006d_000059_2ca0cb05+0x98>
  40f61f:	nop
  40f620:	lea    r9,[r8+r8*4]
  40f624:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40f62c:	sub    r9,r12
  40f62f:	cmp    r9,rax
  40f632:	jae    40f63f <__swc_fn_585f006d_000059_2ca0cb05+0x8f>
  40f634:	mov    rdx,r8
  40f637:	mov    rax,r9
  40f63a:	test   r9,r9
  40f63d:	je     40f648 <__swc_fn_585f006d_000059_2ca0cb05+0x98>
  40f63f:	add    r8,0x1
  40f643:	cmp    r8,rcx
  40f646:	jb     40f620 <__swc_fn_585f006d_000059_2ca0cb05+0x70>
  40f648:	mov    rax,QWORD PTR [rdi+0x2a70]
  40f64f:	cmp    rdx,rax
  40f652:	jne    40f66f <__swc_fn_585f006d_000059_2ca0cb05+0xbf>
  40f654:	mov    rcx,rdi
  40f657:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40f65c:	xor    eax,eax
  40f65e:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40f664:	add    rsp,0x68
  40f668:	pop    r13
  40f66a:	pop    r12
  40f66c:	pop    rdi
  40f66d:	pop    rsi
  40f66e:	ret
  40f66f:	lea    rax,[rdx+rdx*4]
  40f673:	lea    rax,[rdi+rax*8+0x268]
  40f67b:	vmovups xmm6,XMMWORD PTR [rax]
  40f67f:	mov    r8,QWORD PTR [rax+0x10]
  40f683:	mov    rcx,rdi
  40f686:	call   408020 <__swc_fn_585f006d_000060_15c28ca7>
  40f68b:	vpshufd xmm0,xmm6,0xee
  40f690:	vmovsd QWORD PTR [r13+0x0],xmm0
  40f696:	mov    QWORD PTR [rsi],r8
  40f699:	mov    rcx,rdi
  40f69c:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40f6a1:	vmovq  rax,xmm6
  40f6a6:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40f6ac:	add    rsp,0x68
  40f6b0:	pop    r13
  40f6b2:	pop    r12
  40f6b4:	pop    rdi
  40f6b5:	pop    rsi
  40f6b6:	ret
	...

000000000040f6c0 <__swc_fn_585f006d_000062_b304235a>:
  40f6c0:	push   r12
  40f6c2:	push   r13
  40f6c4:	push   r14
  40f6c6:	push   r15
  40f6c8:	push   rdi
  40f6c9:	push   rsi
  40f6ca:	sub    rsp,0x148
  40f6d1:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40f6da:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40f6e3:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40f6ec:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40f6f5:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40f6fe:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40f707:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40f710:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40f719:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40f722:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40f72b:	mov    r12,r9
  40f72e:	mov    r13,rcx
  40f731:	mov    r14,rdx
  40f734:	mov    r15,r8
  40f737:	test   rdx,rdx
  40f73a:	jne    40f74e <__swc_fn_585f006d_000062_b304235a+0x8e>
  40f73c:	add    rsp,0x148
  40f743:	pop    rsi
  40f744:	pop    rdi
  40f745:	pop    r15
  40f747:	pop    r14
  40f749:	pop    r13
  40f74b:	pop    r12
  40f74d:	ret
  40f74e:	cmp    r12,0x200000
  40f755:	ja     40f7e7 <__swc_fn_585f006d_000062_b304235a+0x127>
  40f75b:	lea    rax,[rip+0x1189e]        # 421000 <__swc_data_base_585f006d>
  40f762:	mov    rax,QWORD PTR [rax]
  40f765:	cmp    rax,0xffffffffffffffff
  40f769:	je     40f778 <__swc_fn_585f006d_000062_b304235a+0xb8>
  40f76b:	mov    eax,eax
  40f76d:	mov    edi,eax
  40f76f:	xor    eax,eax
  40f771:	call   407000 <pthread_getspecific@plt>
  40f776:	jmp    40f77a <__swc_fn_585f006d_000062_b304235a+0xba>
  40f778:	xor    eax,eax
  40f77a:	test   rax,rax
  40f77d:	je     40f784 <__swc_fn_585f006d_000062_b304235a+0xc4>
  40f77f:	mov    rsi,rax
  40f782:	jmp    40f794 <__swc_fn_585f006d_000062_b304235a+0xd4>
  40f784:	call   40f060 <__swc_fn_585f006d_000035_cd1a4e8c>
  40f789:	mov    rcx,rax
  40f78c:	call   409c60 <__swc_fn_585f006d_000132_5f757033>
  40f791:	mov    rsi,rax
  40f794:	test   rsi,rsi
  40f797:	je     40f7e7 <__swc_fn_585f006d_000062_b304235a+0x127>
  40f799:	cmp    QWORD PTR [rsi],r13
  40f79c:	jne    40f7e7 <__swc_fn_585f006d_000062_b304235a+0x127>
  40f79e:	cmp    DWORD PTR [rsi+0x20],0x0
  40f7a2:	jne    40f7e7 <__swc_fn_585f006d_000062_b304235a+0x127>
  40f7a4:	cmp    DWORD PTR [rsi+0x730],0x10
  40f7ab:	jae    40f7e7 <__swc_fn_585f006d_000062_b304235a+0x127>
  40f7ad:	mov    eax,DWORD PTR [rsi+0x730]
  40f7b3:	lea    rdi,[rax+rax*4]
  40f7b7:	lea    rdi,[rsi+rdi*8+0x738]
  40f7bf:	mov    QWORD PTR [rdi],r14
  40f7c2:	mov    QWORD PTR [rdi+0x8],r15
  40f7c6:	mov    QWORD PTR [rdi+0x10],r12
  40f7ca:	mov    QWORD PTR [rdi+0x18],0x0
  40f7d2:	call   409d10 <__swc_fn_585f006d_000135_07d76562>
  40f7d7:	mov    QWORD PTR [rdi+0x20],rax
  40f7db:	add    DWORD PTR [rsi+0x730],0x1
  40f7e2:	jmp    40f946 <__swc_fn_585f006d_000062_b304235a+0x286>
  40f7e7:	mov    rcx,r13
  40f7ea:	call   40c510 <__swc_fn_585f006d_000061_ad030a10>
  40f7ef:	mov    rsi,rax
  40f7f2:	cmp    r12,rax
  40f7f5:	jbe    40f82a <__swc_fn_585f006d_000062_b304235a+0x16a>
  40f7f7:	cmp    r12,0x10000000
  40f7fe:	seta   al
  40f801:	ja     40f810 <__swc_fn_585f006d_000062_b304235a+0x150>
  40f803:	mov    rax,QWORD PTR [r13+0x2a70]
  40f80a:	test   rax,rax
  40f80d:	setne  al
  40f810:	test   al,al
  40f812:	je     40f82a <__swc_fn_585f006d_000062_b304235a+0x16a>
  40f814:	mov    rcx,r13
  40f817:	mov    rdx,r14
  40f81a:	mov    r8,r15
  40f81d:	mov    r9,r12
  40f820:	call   40bde0 <__swc_fn_585f006d_000043_d3c2ab54>
  40f825:	jmp    40f946 <__swc_fn_585f006d_000062_b304235a+0x286>
  40f82a:	call   409d10 <__swc_fn_585f006d_000135_07d76562>
  40f82f:	mov    rdi,rax
  40f832:	mov    rcx,r13
  40f835:	call   40df20 <__swc_fn_585f006d_000139_86bb0f90>
  40f83a:	cmp    QWORD PTR [r13+0x2a70],0x0
  40f842:	je     40f8fa <__swc_fn_585f006d_000062_b304235a+0x23a>
  40f848:	nop    DWORD PTR [rax+rax*1+0x0]
  40f850:	cmp    QWORD PTR [r13+0x2a70],0x100
  40f85b:	jae    40f870 <__swc_fn_585f006d_000062_b304235a+0x1b0>
  40f85d:	mov    rax,QWORD PTR [r13+0x2a68]
  40f864:	add    rax,r12
  40f867:	cmp    rax,rsi
  40f86a:	jbe    40f8fa <__swc_fn_585f006d_000062_b304235a+0x23a>
  40f870:	xor    eax,eax
  40f872:	mov    rcx,QWORD PTR [r13+0x2a70]
  40f879:	mov    edx,0x1
  40f87e:	cmp    rcx,0x1
  40f882:	jbe    40f8b9 <__swc_fn_585f006d_000062_b304235a+0x1f9>
  40f884:	cs nop WORD PTR [rax+rax*1+0x0]
  40f88e:	xchg   ax,ax
  40f890:	lea    r8,[rdx+rdx*4]
  40f894:	lea    r8,[r13+r8*8+0x268]
  40f89c:	lea    r9,[rax+rax*4]
  40f8a0:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40f8a8:	cmp    QWORD PTR [r8+0x18],r9
  40f8ac:	cmovb  rax,rdx
  40f8b0:	add    rdx,0x1
  40f8b4:	cmp    rdx,rcx
  40f8b7:	jb     40f890 <__swc_fn_585f006d_000062_b304235a+0x1d0>
  40f8b9:	lea    rcx,[rax+rax*4]
  40f8bd:	lea    rcx,[r13+rcx*8+0x268]
  40f8c5:	mov    r8,QWORD PTR [rcx]
  40f8c8:	mov    r9,QWORD PTR [rcx+0x8]
  40f8cc:	mov    r10,QWORD PTR [rcx+0x10]
  40f8d0:	mov    rcx,r13
  40f8d3:	mov    rdx,rax
  40f8d6:	call   408020 <__swc_fn_585f006d_000060_15c28ca7>
  40f8db:	mov    rcx,r13
  40f8de:	mov    rdx,r8
  40f8e1:	mov    r8,r9
  40f8e4:	mov    r9,r10
  40f8e7:	call   40bde0 <__swc_fn_585f006d_000043_d3c2ab54>
  40f8ec:	cmp    QWORD PTR [r13+0x2a70],0x0
  40f8f4:	jne    40f850 <__swc_fn_585f006d_000062_b304235a+0x190>
  40f8fa:	add    QWORD PTR [r13+0x2a78],0x1
  40f902:	mov    rax,QWORD PTR [r13+0x2a70]
  40f909:	lea    rax,[rax+rax*4]
  40f90d:	lea    rax,[r13+rax*8+0x268]
  40f915:	mov    QWORD PTR [rax],r14
  40f918:	mov    QWORD PTR [rax+0x8],r15
  40f91c:	mov    QWORD PTR [rax+0x10],r12
  40f920:	mov    rcx,QWORD PTR [r13+0x2a78]
  40f927:	mov    QWORD PTR [rax+0x18],rcx
  40f92b:	mov    QWORD PTR [rax+0x20],rdi
  40f92f:	add    QWORD PTR [r13+0x2a68],r12
  40f936:	add    QWORD PTR [r13+0x2a70],0x1
  40f93e:	mov    rcx,r13
  40f941:	call   4114f0 <__swc_fn_585f006d_000140_055b38a4>
  40f946:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40f94f:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40f958:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40f961:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40f96a:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40f973:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40f97c:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40f985:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40f98e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40f997:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40f9a0:	add    rsp,0x148
  40f9a7:	pop    rsi
  40f9a8:	pop    rdi
  40f9a9:	pop    r15
  40f9ab:	pop    r14
  40f9ad:	pop    r13
  40f9af:	pop    r12
  40f9b1:	ret
	...

000000000040f9c0 <__swc_fn_585f006d_000065_d9ee99ea>:
  40f9c0:	push   rbx
  40f9c1:	push   r12
  40f9c3:	push   r13
  40f9c5:	push   r14
  40f9c7:	push   r15
  40f9c9:	push   rdi
  40f9ca:	push   rsi
  40f9cb:	sub    rsp,0xf0
  40f9d2:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40f9d8:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40f9de:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40f9e4:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40f9ea:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40f9f3:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40f9fc:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40fa05:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40fa0e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40fa17:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40fa20:	mov    eax,r8d
  40fa23:	mov    rbx,rcx
  40fa26:	mov    r12,rdx
  40fa29:	mov    QWORD PTR [rsp+0x18],rdx
  40fa2e:	mov    ecx,DWORD PTR [r12+0x58]
  40fa33:	mov    r13d,ecx
  40fa36:	cmp    ecx,0x10
  40fa39:	mov    ecx,0x10
  40fa3e:	cmovb  r13d,ecx
  40fa42:	test   r13d,r13d
  40fa45:	mov    rcx,r13
  40fa48:	mov    edx,0x8
  40fa4d:	cmove  ecx,edx
  40fa50:	dec    rcx
  40fa53:	mov    rdx,0xffffffffffffffff
  40fa5a:	sub    rdx,rcx
  40fa5d:	xor    r14d,r14d
  40fa60:	mov    r8,rcx
  40fa63:	not    r8
  40fa66:	lea    rcx,[rcx+0x58]
  40fa6a:	and    rcx,r8
  40fa6d:	cmp    rdx,0x58
  40fa71:	cmovae r14,rcx
  40fa75:	cmp    eax,0xffffffff
  40fa78:	jne    40fa81 <__swc_fn_585f006d_000065_d9ee99ea+0xc1>
  40fa7a:	mov    r15,QWORD PTR [r12+0x48]
  40fa7f:	jmp    40fab3 <__swc_fn_585f006d_000065_d9ee99ea+0xf3>
  40fa81:	test   eax,eax
  40fa83:	jne    40fa8c <__swc_fn_585f006d_000065_d9ee99ea+0xcc>
  40fa85:	mov    eax,0x8
  40fa8a:	jmp    40fab0 <__swc_fn_585f006d_000065_d9ee99ea+0xf0>
  40fa8c:	cmp    eax,0x8
  40fa8f:	ja     40fa97 <__swc_fn_585f006d_000065_d9ee99ea+0xd7>
  40fa91:	shl    rax,0x4
  40fa95:	jmp    40fab0 <__swc_fn_585f006d_000065_d9ee99ea+0xf0>
  40fa97:	lea    eax,[rax-0x9]
  40fa9a:	mov    ecx,eax
  40fa9c:	shr    ecx,0x2
  40fa9f:	and    eax,0x3
  40faa2:	lea    ecx,[rcx+0x7]
  40faa5:	lea    ecx,[rcx-0x2]
  40faa8:	lea    eax,[rax+0x5]
  40faab:	shlx   rax,rax,rcx
  40fab0:	mov    r15,rax
  40fab3:	lea    rax,[r14+r13*1]
  40fab7:	mov    rcx,0xffffffffffffffff
  40fabe:	sub    rcx,rax
  40fac1:	cmp    r15,rcx
  40fac4:	jbe    40fad4 <__swc_fn_585f006d_000065_d9ee99ea+0x114>
  40fac6:	mov    QWORD PTR [r12+0x40],0x0
  40facf:	jmp    40fea6 <__swc_fn_585f006d_000065_d9ee99ea+0x4e6>
  40fad4:	mov    QWORD PTR [rsp+0x20],r13
  40fad9:	lea    r13,[rsp+0x8]
  40fade:	add    rax,r15
  40fae1:	mov    ecx,0x1000
  40fae6:	test   ecx,ecx
  40fae8:	mov    edx,0x8
  40faed:	cmove  ecx,edx
  40faf0:	dec    rcx
  40faf3:	mov    rdx,0xffffffffffffffff
  40fafa:	sub    rdx,rcx
  40fafd:	cmp    rax,rdx
  40fb00:	jbe    40fb0c <__swc_fn_585f006d_000065_d9ee99ea+0x14c>
  40fb02:	mov    QWORD PTR [r13+0x0],0x0
  40fb0a:	jmp    40fb19 <__swc_fn_585f006d_000065_d9ee99ea+0x159>
  40fb0c:	add    rax,rcx
  40fb0f:	andn   rax,rcx,rax
  40fb14:	mov    QWORD PTR [rsp+0x8],rax
  40fb19:	cmp    QWORD PTR [r13+0x0],0x0
  40fb1e:	jne    40fb2e <__swc_fn_585f006d_000065_d9ee99ea+0x16e>
  40fb20:	mov    QWORD PTR [r12+0x40],0x0
  40fb29:	jmp    40fea6 <__swc_fn_585f006d_000065_d9ee99ea+0x4e6>
  40fb2e:	mov    QWORD PTR [rsp+0x30],r15
  40fb33:	xor    r15d,r15d
  40fb36:	mov    QWORD PTR [rsp+0x38],0x0
  40fb3f:	lea    r12,[rsp+0x10]
  40fb44:	mov    QWORD PTR [rsp+0x28],r14
  40fb49:	mov    r14,QWORD PTR [rsp+0x8]
  40fb4e:	mov    QWORD PTR [rsp+0x10],r14
  40fb53:	cmp    r14,0x10000
  40fb5a:	ja     40fb61 <__swc_fn_585f006d_000065_d9ee99ea+0x1a1>
  40fb5c:	mov    rax,r14
  40fb5f:	jmp    40fbb2 <__swc_fn_585f006d_000065_d9ee99ea+0x1f2>
  40fb61:	xor    eax,eax
  40fb63:	lea    rcx,[r14-0x1]
  40fb67:	lzcnt  rax,rcx
  40fb6c:	mov    ecx,0x3f
  40fb71:	sub    rcx,rax
  40fb74:	mov    eax,0x1
  40fb79:	lea    rcx,[rcx-0x3]
  40fb7d:	shl    rax,cl
  40fb80:	mov    rcx,rax
  40fb83:	cmp    rax,0x1000
  40fb8a:	mov    eax,0x1000
  40fb8f:	cmovb  rcx,rax
  40fb93:	mov    rdx,0xffffffffffffffff
  40fb9a:	sub    rdx,rcx
  40fb9d:	mov    rax,r14
  40fba0:	lea    r8,[r14+rcx*1-0x1]
  40fba5:	neg    rcx
  40fba8:	and    r8,rcx
  40fbab:	cmp    r14,rdx
  40fbae:	cmovbe rax,r8
  40fbb2:	mov    QWORD PTR [rsp+0x8],rax
  40fbb7:	lea    rax,[rip+0x11442]        # 421000 <__swc_data_base_585f006d>
  40fbbe:	mov    rax,QWORD PTR [rax]
  40fbc1:	cmp    rax,0xffffffffffffffff
  40fbc5:	je     40fbd4 <__swc_fn_585f006d_000065_d9ee99ea+0x214>
  40fbc7:	mov    eax,eax
  40fbc9:	mov    edi,eax
  40fbcb:	xor    eax,eax
  40fbcd:	call   407000 <pthread_getspecific@plt>
  40fbd2:	jmp    40fbd6 <__swc_fn_585f006d_000065_d9ee99ea+0x216>
  40fbd4:	xor    eax,eax
  40fbd6:	test   rax,rax
  40fbd9:	jne    40fbe8 <__swc_fn_585f006d_000065_d9ee99ea+0x228>
  40fbdb:	call   40f060 <__swc_fn_585f006d_000035_cd1a4e8c>
  40fbe0:	mov    rcx,rax
  40fbe3:	call   409c60 <__swc_fn_585f006d_000132_5f757033>
  40fbe8:	test   rax,rax
  40fbeb:	je     40fcdc <__swc_fn_585f006d_000065_d9ee99ea+0x31c>
  40fbf1:	cmp    QWORD PTR [rax],rbx
  40fbf4:	jne    40fcdc <__swc_fn_585f006d_000065_d9ee99ea+0x31c>
  40fbfa:	cmp    DWORD PTR [rax+0x20],0x0
  40fbfe:	jne    40fcdc <__swc_fn_585f006d_000065_d9ee99ea+0x31c>
  40fc04:	mov    rcx,QWORD PTR [rsp+0x8]
  40fc09:	movabs rdx,0x7fffffffffffffff
  40fc13:	cmp    rcx,rdx
  40fc16:	mov    rdx,0xffffffffffffffff
  40fc1d:	lea    r8,[rcx+rcx*1]
  40fc21:	cmovbe rdx,r8
  40fc25:	mov    r8d,DWORD PTR [rax+0x730]
  40fc2c:	mov    r9d,r8d
  40fc2f:	sub    rdx,rcx
  40fc32:	inc    rdx
  40fc35:	xor    r10d,r10d
  40fc38:	test   r8,r8
  40fc3b:	jbe    40fc6b <__swc_fn_585f006d_000065_d9ee99ea+0x2ab>
  40fc3d:	nop    DWORD PTR [rax]
  40fc40:	mov    r11d,r10d
  40fc43:	lea    r11,[r11+r11*4]
  40fc47:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40fc4f:	sub    r11,rcx
  40fc52:	cmp    r11,rdx
  40fc55:	jae    40fc62 <__swc_fn_585f006d_000065_d9ee99ea+0x2a2>
  40fc57:	mov    r9d,r10d
  40fc5a:	mov    rdx,r11
  40fc5d:	test   r11,r11
  40fc60:	je     40fc6b <__swc_fn_585f006d_000065_d9ee99ea+0x2ab>
  40fc62:	add    r10,0x1
  40fc66:	cmp    r10,r8
  40fc69:	jb     40fc40 <__swc_fn_585f006d_000065_d9ee99ea+0x280>
  40fc6b:	mov    ecx,DWORD PTR [rax+0x730]
  40fc71:	cmp    r9d,ecx
  40fc74:	jne    40fc7a <__swc_fn_585f006d_000065_d9ee99ea+0x2ba>
  40fc76:	xor    eax,eax
  40fc78:	jmp    40fcd9 <__swc_fn_585f006d_000065_d9ee99ea+0x319>
  40fc7a:	lea    rcx,[r9+r9*4]
  40fc7e:	lea    rcx,[rax+rcx*8+0x738]
  40fc86:	vmovups xmm0,XMMWORD PTR [rcx]
  40fc8a:	mov    rdx,QWORD PTR [rcx+0x10]
  40fc8e:	sub    DWORD PTR [rax+0x730],0x1
  40fc95:	mov    r8d,DWORD PTR [rax+0x730]
  40fc9c:	lea    r8,[r8+r8*4]
  40fca0:	lea    r8,[rax+r8*8+0x738]
  40fca8:	vmovups xmm1,XMMWORD PTR [r8]
  40fcad:	vmovups XMMWORD PTR [rcx],xmm1
  40fcb1:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40fcb7:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40fcbc:	mov    rax,QWORD PTR [r8+0x20]
  40fcc0:	mov    QWORD PTR [rcx+0x20],rax
  40fcc4:	vpshufd xmm1,xmm0,0xee
  40fcc9:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40fccf:	mov    QWORD PTR [rsp+0x10],rdx
  40fcd4:	vmovq  rax,xmm0
  40fcd9:	mov    r15,rax
  40fcdc:	test   r15,r15
  40fcdf:	jne    40fcf7 <__swc_fn_585f006d_000065_d9ee99ea+0x337>
  40fce1:	mov    rcx,rbx
  40fce4:	mov    rdx,QWORD PTR [rsp+0x8]
  40fce9:	mov    r8,r13
  40fcec:	mov    r9,r12
  40fcef:	call   40f5b0 <__swc_fn_585f006d_000059_2ca0cb05>
  40fcf4:	mov    r15,rax
  40fcf7:	test   r15,r15
  40fcfa:	je     40fd3b <__swc_fn_585f006d_000065_d9ee99ea+0x37b>
  40fcfc:	cmp    QWORD PTR [r12],r14
  40fd00:	jae    40fd3b <__swc_fn_585f006d_000065_d9ee99ea+0x37b>
  40fd02:	mov    rax,r15
  40fd05:	add    rax,QWORD PTR [r12]
  40fd09:	mov    rdx,r14
  40fd0c:	sub    rdx,QWORD PTR [r12]
  40fd10:	mov    rcx,rax
  40fd13:	call   40b930 <__swc_fn_585f006d_000007_f7acedb0>
  40fd18:	test   al,al
  40fd1a:	je     40fd23 <__swc_fn_585f006d_000065_d9ee99ea+0x363>
  40fd1c:	mov    QWORD PTR [rsp+0x10],r14
  40fd21:	jmp    40fd3b <__swc_fn_585f006d_000065_d9ee99ea+0x37b>
  40fd23:	mov    rcx,rbx
  40fd26:	mov    rdx,r15
  40fd29:	mov    r8,QWORD PTR [rsp+0x8]
  40fd2e:	mov    r9,QWORD PTR [rsp+0x10]
  40fd33:	call   40f6c0 <__swc_fn_585f006d_000062_b304235a>
  40fd38:	xor    r15d,r15d
  40fd3b:	test   r15,r15
  40fd3e:	jne    40fdba <__swc_fn_585f006d_000065_d9ee99ea+0x3fa>
  40fd40:	cmp    r14,0x10000
  40fd47:	ja     40fd4e <__swc_fn_585f006d_000065_d9ee99ea+0x38e>
  40fd49:	mov    rax,r14
  40fd4c:	jmp    40fd9f <__swc_fn_585f006d_000065_d9ee99ea+0x3df>
  40fd4e:	xor    eax,eax
  40fd50:	lea    rcx,[r14-0x1]
  40fd54:	lzcnt  rax,rcx
  40fd59:	mov    ecx,0x3f
  40fd5e:	sub    rcx,rax
  40fd61:	mov    eax,0x1
  40fd66:	lea    rcx,[rcx-0x3]
  40fd6a:	shl    rax,cl
  40fd6d:	mov    rcx,rax
  40fd70:	cmp    rax,0x1000
  40fd77:	mov    eax,0x1000
  40fd7c:	cmovb  rcx,rax
  40fd80:	mov    rdx,0xffffffffffffffff
  40fd87:	sub    rdx,rcx
  40fd8a:	mov    rax,r14
  40fd8d:	lea    r8,[r14+rcx*1-0x1]
  40fd92:	neg    rcx
  40fd95:	and    r8,rcx
  40fd98:	cmp    r14,rdx
  40fd9b:	cmovbe rax,r8
  40fd9f:	mov    QWORD PTR [rsp+0x8],rax
  40fda4:	mov    QWORD PTR [rsp+0x10],r14
  40fda9:	mov    rcx,rbx
  40fdac:	mov    rdx,rax
  40fdaf:	mov    r8,r14
  40fdb2:	call   40f120 <__swc_fn_585f006d_000041_c90d80c1>
  40fdb7:	mov    r15,rax
  40fdba:	test   r15,r15
  40fdbd:	jne    40fdcb <__swc_fn_585f006d_000065_d9ee99ea+0x40b>
  40fdbf:	mov    r13,QWORD PTR [rsp+0x20]
  40fdc4:	mov    rsi,QWORD PTR [rsp+0x38]
  40fdc9:	jmp    40fe07 <__swc_fn_585f006d_000065_d9ee99ea+0x447>
  40fdcb:	mov    rax,r15
  40fdce:	add    rax,QWORD PTR [rsp+0x28]
  40fdd3:	mov    r13,QWORD PTR [rsp+0x20]
  40fdd8:	test   r13d,r13d
  40fddb:	mov    rcx,r13
  40fdde:	mov    edx,0x8
  40fde3:	cmove  ecx,edx
  40fde6:	dec    rcx
  40fde9:	mov    rdx,0xffffffffffffffff
  40fdf0:	sub    rdx,rcx
  40fdf3:	cmp    rax,rdx
  40fdf6:	jbe    40fdfc <__swc_fn_585f006d_000065_d9ee99ea+0x43c>
  40fdf8:	xor    eax,eax
  40fdfa:	jmp    40fe04 <__swc_fn_585f006d_000065_d9ee99ea+0x444>
  40fdfc:	add    rax,rcx
  40fdff:	andn   rax,rcx,rax
  40fe04:	mov    rsi,rax
  40fe07:	mov    rax,QWORD PTR [rsp+0x8]
  40fe0c:	test   r15,r15
  40fe0f:	je     40fe18 <__swc_fn_585f006d_000065_d9ee99ea+0x458>
  40fe11:	mov    rdi,QWORD PTR [rsp+0x18]
  40fe16:	jmp    40fe2a <__swc_fn_585f006d_000065_d9ee99ea+0x46a>
  40fe18:	mov    rdi,QWORD PTR [rsp+0x18]
  40fe1d:	mov    QWORD PTR [rdi+0x40],0x0
  40fe25:	jmp    40fea6 <__swc_fn_585f006d_000065_d9ee99ea+0x4e6>
  40fe2a:	lea    rdx,[rsi-0x58]
  40fe2e:	mov    QWORD PTR [rsi-0x58],r15
  40fe32:	mov    QWORD PTR [rsi-0x50],rax
  40fe36:	mov    rax,QWORD PTR [rsp+0x10]
  40fe3b:	mov    QWORD PTR [rsi-0x48],rax
  40fe3f:	mov    QWORD PTR [rsi-0x40],rsi
  40fe43:	mov    rax,QWORD PTR [rdi+0x48]
  40fe47:	mov    QWORD PTR [rsi-0x38],rax
  40fe4b:	mov    rax,QWORD PTR [rsp+0x30]
  40fe50:	mov    QWORD PTR [rsi-0x30],rax
  40fe54:	mov    DWORD PTR [rsi-0x10],r13d
  40fe58:	mov    QWORD PTR [rsi-0x28],0x0
  40fe60:	mov    QWORD PTR [rsi-0x20],0x0
  40fe68:	add    r15,QWORD PTR [r12]
  40fe6c:	sub    r15,rsi
  40fe6f:	mov    QWORD PTR [rsi-0x30],r15
  40fe73:	mov    rcx,QWORD PTR [rbx+0x250]
  40fe7a:	nop    WORD PTR [rax+rax*1+0x0]
  40fe80:	lea    r8,[rcx+r15*1]
  40fe84:	mov    rax,rcx
  40fe87:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40fe90:	cmp    rax,rcx
  40fe93:	je     40fe9a <__swc_fn_585f006d_000065_d9ee99ea+0x4da>
  40fe95:	mov    rcx,rax
  40fe98:	jmp    40fe80 <__swc_fn_585f006d_000065_d9ee99ea+0x4c0>
  40fe9a:	mov    rcx,rbx
  40fe9d:	call   407f90 <__swc_fn_585f006d_000057_7e1dbcb0>
  40fea2:	mov    QWORD PTR [rdi+0x40],rsi
  40fea6:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40feac:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40feb2:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40feb8:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40febe:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40fec7:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40fed0:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40fed9:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40fee2:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40feeb:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40fef4:	add    rsp,0xf0
  40fefb:	pop    rsi
  40fefc:	pop    rdi
  40fefd:	pop    r15
  40feff:	pop    r14
  40ff01:	pop    r13
  40ff03:	pop    r12
  40ff05:	pop    rbx
  40ff06:	ret
	...

000000000040ff10 <__swc_fn_585f006d_000068_f3aa21af>:
  40ff10:	push   rbx
  40ff11:	push   r12
  40ff13:	push   rdi
  40ff14:	push   rsi
  40ff15:	sub    rsp,0xb8
  40ff1c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40ff22:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40ff28:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40ff2e:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40ff34:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40ff3a:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40ff40:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40ff46:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40ff4f:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40ff58:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40ff61:	mov    rbx,rdx
  40ff64:	mov    r12,rcx
  40ff67:	cmp    DWORD PTR [rbx+0x58],0x0
  40ff6b:	je     40ff85 <__swc_fn_585f006d_000068_f3aa21af+0x75>
  40ff6d:	mov    eax,DWORD PTR [rbx+0x58]
  40ff70:	sub    eax,0x1
  40ff73:	test   DWORD PTR [rbx+0x58],eax
  40ff76:	je     40ff85 <__swc_fn_585f006d_000068_f3aa21af+0x75>
  40ff78:	mov    QWORD PTR [rbx+0x40],0x0
  40ff80:	jmp    410197 <__swc_fn_585f006d_000068_f3aa21af+0x287>
  40ff85:	cmp    QWORD PTR [rbx+0x48],0x0
  40ff8a:	jne    40ff99 <__swc_fn_585f006d_000068_f3aa21af+0x89>
  40ff8c:	mov    QWORD PTR [rbx+0x40],0x0
  40ff94:	jmp    410197 <__swc_fn_585f006d_000068_f3aa21af+0x287>
  40ff99:	lea    rax,[rsp+0x8]
  40ff9e:	mov    rcx,QWORD PTR [rbx+0x48]
  40ffa2:	cmp    rcx,0x8
  40ffa6:	ja     40ffb0 <__swc_fn_585f006d_000068_f3aa21af+0xa0>
  40ffa8:	mov    DWORD PTR [rax],0x0
  40ffae:	jmp    41000b <__swc_fn_585f006d_000068_f3aa21af+0xfb>
  40ffb0:	cmp    rcx,0x80
  40ffb7:	ja     40ffc7 <__swc_fn_585f006d_000068_f3aa21af+0xb7>
  40ffb9:	lea    rcx,[rcx+0xf]
  40ffbd:	shr    rcx,0x4
  40ffc1:	mov    DWORD PTR [rsp+0x8],ecx
  40ffc5:	jmp    41000b <__swc_fn_585f006d_000068_f3aa21af+0xfb>
  40ffc7:	cmp    rcx,0x10000
  40ffce:	jbe    40ffd8 <__swc_fn_585f006d_000068_f3aa21af+0xc8>
  40ffd0:	mov    DWORD PTR [rax],0xffffffff
  40ffd6:	jmp    41000b <__swc_fn_585f006d_000068_f3aa21af+0xfb>
  40ffd8:	dec    rcx
  40ffdb:	xor    edx,edx
  40ffdd:	lzcnt  rdx,rcx
  40ffe2:	mov    r8d,0x3f
  40ffe8:	sub    r8d,edx
  40ffeb:	lea    edx,[r8-0x2]
  40ffef:	shrx   rcx,rcx,rdx
  40fff4:	and    ecx,0x3
  40fff7:	lea    edx,[r8-0x7]
  40fffb:	lea    edx,[rdx*4+0x0]
  410002:	lea    edx,[rdx+0x9]
  410005:	add    edx,ecx
  410007:	mov    DWORD PTR [rsp+0x8],edx
  41000b:	cmp    DWORD PTR [rax],0x0
  41000e:	jne    41001e <__swc_fn_585f006d_000068_f3aa21af+0x10e>
  410010:	cmp    DWORD PTR [rbx+0x58],0x8
  410014:	jbe    41001e <__swc_fn_585f006d_000068_f3aa21af+0x10e>
  410016:	mov    DWORD PTR [rsp+0x8],0x1
  41001e:	cmp    DWORD PTR [rbx+0x58],0x10
  410022:	jbe    4100a1 <__swc_fn_585f006d_000068_f3aa21af+0x191>
  410028:	cmp    DWORD PTR [rbx+0x58],0x40
  41002c:	ja     4100a1 <__swc_fn_585f006d_000068_f3aa21af+0x191>
  41002e:	cmp    DWORD PTR [rax],0xffffffff
  410031:	je     4100a1 <__swc_fn_585f006d_000068_f3aa21af+0x191>
  410033:	mov    ecx,DWORD PTR [rsp+0x8]
  410037:	mov    edx,DWORD PTR [rbx+0x58]
  41003a:	dec    rdx
  41003d:	cmp    ecx,0x2d
  410040:	jae    410098 <__swc_fn_585f006d_000068_f3aa21af+0x188>
  410042:	cs nop WORD PTR [rax+rax*1+0x0]
  41004c:	nop    DWORD PTR [rax+0x0]
  410050:	mov    r8d,ecx
  410053:	test   ecx,ecx
  410055:	jne    41005f <__swc_fn_585f006d_000068_f3aa21af+0x14f>
  410057:	mov    r8d,0x8
  41005d:	jmp    41008b <__swc_fn_585f006d_000068_f3aa21af+0x17b>
  41005f:	cmp    r8d,0x8
  410063:	ja     41006b <__swc_fn_585f006d_000068_f3aa21af+0x15b>
  410065:	shl    r8,0x4
  410069:	jmp    41008b <__swc_fn_585f006d_000068_f3aa21af+0x17b>
  41006b:	lea    r8d,[r8-0x9]
  41006f:	mov    r9d,r8d
  410072:	shr    r9d,0x2
  410076:	and    r8d,0x3
  41007a:	lea    r9d,[r9+0x7]
  41007e:	lea    r9d,[r9-0x2]
  410082:	lea    r8d,[r8+0x5]
  410086:	shlx   r8,r8,r9
  41008b:	test   r8,rdx
  41008e:	je     41009d <__swc_fn_585f006d_000068_f3aa21af+0x18d>
  410090:	add    ecx,0x1
  410093:	cmp    ecx,0x2d
  410096:	jb     410050 <__swc_fn_585f006d_000068_f3aa21af+0x140>
  410098:	mov    ecx,0xffffffff
  41009d:	mov    DWORD PTR [rsp+0x8],ecx
  4100a1:	mov    ecx,DWORD PTR [rsp+0x8]
  4100a5:	cmp    ecx,0xffffffff
  4100a8:	je     4100b0 <__swc_fn_585f006d_000068_f3aa21af+0x1a0>
  4100aa:	cmp    DWORD PTR [rbx+0x58],0x40
  4100ae:	jbe    4100c3 <__swc_fn_585f006d_000068_f3aa21af+0x1b3>
  4100b0:	mov    rcx,r12
  4100b3:	mov    rdx,rbx
  4100b6:	mov    r8d,DWORD PTR [rax]
  4100b9:	call   40f9c0 <__swc_fn_585f006d_000065_d9ee99ea>
  4100be:	jmp    410197 <__swc_fn_585f006d_000068_f3aa21af+0x287>
  4100c3:	lea    rax,[rip+0x10f36]        # 421000 <__swc_data_base_585f006d>
  4100ca:	mov    rax,QWORD PTR [rax]
  4100cd:	cmp    rax,0xffffffffffffffff
  4100d1:	je     4100e0 <__swc_fn_585f006d_000068_f3aa21af+0x1d0>
  4100d3:	mov    eax,eax
  4100d5:	mov    edi,eax
  4100d7:	xor    eax,eax
  4100d9:	call   407000 <pthread_getspecific@plt>
  4100de:	jmp    4100e2 <__swc_fn_585f006d_000068_f3aa21af+0x1d2>
  4100e0:	xor    eax,eax
  4100e2:	test   rax,rax
  4100e5:	jne    4100f4 <__swc_fn_585f006d_000068_f3aa21af+0x1e4>
  4100e7:	call   40f060 <__swc_fn_585f006d_000035_cd1a4e8c>
  4100ec:	mov    rcx,rax
  4100ef:	call   409c60 <__swc_fn_585f006d_000132_5f757033>
  4100f4:	test   rax,rax
  4100f7:	je     410104 <__swc_fn_585f006d_000068_f3aa21af+0x1f4>
  4100f9:	cmp    QWORD PTR [rax],r12
  4100fc:	jne    410104 <__swc_fn_585f006d_000068_f3aa21af+0x1f4>
  4100fe:	cmp    DWORD PTR [rax+0x20],0x0
  410102:	je     41010f <__swc_fn_585f006d_000068_f3aa21af+0x1ff>
  410104:	mov    rcx,r12
  410107:	mov    rdx,rax
  41010a:	call   407bd0 <__swc_fn_585f006d_000045_d8bd27c3>
  41010f:	test   rax,rax
  410112:	jne    41011e <__swc_fn_585f006d_000068_f3aa21af+0x20e>
  410114:	mov    QWORD PTR [rbx+0x40],0x0
  41011c:	jmp    410197 <__swc_fn_585f006d_000068_f3aa21af+0x287>
  41011e:	lea    r8,[rsp+0xc]
  410123:	mov    ecx,DWORD PTR [rsp+0x8]
  410127:	mov    DWORD PTR [rsp+0xc],ecx
  41012b:	mov    ecx,DWORD PTR [r8]
  41012e:	lea    rcx,[rcx+rcx*4]
  410132:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  410137:	test   rcx,rcx
  41013a:	je     410173 <__swc_fn_585f006d_000068_f3aa21af+0x263>
  41013c:	mov    rdx,QWORD PTR [rcx]
  41013f:	test   rdx,rdx
  410142:	je     410150 <__swc_fn_585f006d_000068_f3aa21af+0x240>
  410144:	mov    r9,QWORD PTR [rdx]
  410147:	mov    QWORD PTR [rcx],r9
  41014a:	add    DWORD PTR [rcx+0x28],0x1
  41014e:	jmp    41016e <__swc_fn_585f006d_000068_f3aa21af+0x25e>
  410150:	mov    rdx,QWORD PTR [rcx+0x18]
  410154:	cmp    QWORD PTR [rcx+0x20],rdx
  410158:	jae    41016c <__swc_fn_585f006d_000068_f3aa21af+0x25c>
  41015a:	mov    rdx,QWORD PTR [rcx+0x20]
  41015e:	mov    r9d,DWORD PTR [rcx+0x2c]
  410162:	add    QWORD PTR [rcx+0x20],r9
  410166:	add    DWORD PTR [rcx+0x28],0x1
  41016a:	jmp    41016e <__swc_fn_585f006d_000068_f3aa21af+0x25e>
  41016c:	xor    edx,edx
  41016e:	test   rdx,rdx
  410171:	jne    410184 <__swc_fn_585f006d_000068_f3aa21af+0x274>
  410173:	mov    rcx,r12
  410176:	mov    rdx,rax
  410179:	mov    r8d,DWORD PTR [r8]
  41017c:	call   407d40 <__swc_fn_585f006d_000054_faa92dcc>
  410181:	mov    rdx,rax
  410184:	test   rdx,rdx
  410187:	jne    410193 <__swc_fn_585f006d_000068_f3aa21af+0x283>
  410189:	mov    QWORD PTR [rbx+0x40],0x0
  410191:	jmp    410197 <__swc_fn_585f006d_000068_f3aa21af+0x287>
  410193:	mov    QWORD PTR [rbx+0x40],rdx
  410197:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  41019d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4101a3:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4101a9:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4101af:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4101b5:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4101bb:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4101c1:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4101ca:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4101d3:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4101dc:	add    rsp,0xb8
  4101e3:	pop    rsi
  4101e4:	pop    rdi
  4101e5:	pop    r12
  4101e7:	pop    rbx
  4101e8:	ret
  4101e9:	add    BYTE PTR [rax],al
  4101eb:	add    BYTE PTR [rax],al
  4101ed:	add    BYTE PTR [rax],al
	...

00000000004101f0 <__swc_fn_585f006d_000071_b3d7b28e>:
  4101f0:	ret
	...

0000000000410200 <__swc_fn_585f006d_000074_042643a3>:
  410200:	push   r12
  410202:	push   r13
  410204:	push   r14
  410206:	push   rdi
  410207:	push   rsi
  410208:	sub    rsp,0x1a0
  41020f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  410218:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  410221:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  41022a:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  410233:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  41023c:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  410245:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  41024e:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  410257:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  410260:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  410269:	mov    r12,rdx
  41026c:	mov    r13,rcx
  41026f:	mov    rax,QWORD PTR [r12+0x48]
  410274:	mov    ecx,DWORD PTR [r12+0x58]
  410279:	lea    rdx,[rax-0x1]
  41027d:	cmp    rdx,0x10000
  410284:	jae    41037e <__swc_fn_585f006d_000074_042643a3+0x17e>
  41028a:	cmp    rax,0x8
  41028e:	ja     410295 <__swc_fn_585f006d_000074_042643a3+0x95>
  410290:	xor    r14d,r14d
  410293:	jmp    4102e7 <__swc_fn_585f006d_000074_042643a3+0xe7>
  410295:	cmp    rax,0x80
  41029c:	ja     4102a8 <__swc_fn_585f006d_000074_042643a3+0xa8>
  41029e:	lea    r14,[rax+0xf]
  4102a2:	shr    r14,0x4
  4102a6:	jmp    4102e7 <__swc_fn_585f006d_000074_042643a3+0xe7>
  4102a8:	cmp    rax,0x10000
  4102af:	jbe    4102b9 <__swc_fn_585f006d_000074_042643a3+0xb9>
  4102b1:	mov    r14d,0xffffffff
  4102b7:	jmp    4102e7 <__swc_fn_585f006d_000074_042643a3+0xe7>
  4102b9:	xor    eax,eax
  4102bb:	lzcnt  rax,rdx
  4102c0:	mov    r8d,0x3f
  4102c6:	sub    r8d,eax
  4102c9:	lea    eax,[r8-0x2]
  4102cd:	shrx   rax,rdx,rax
  4102d2:	and    eax,0x3
  4102d5:	lea    edx,[r8-0x7]
  4102d9:	lea    edx,[rdx*4+0x0]
  4102e0:	lea    edx,[rdx+0x9]
  4102e3:	lea    r14d,[rdx+rax*1]
  4102e7:	cmp    ecx,0x8
  4102ea:	jbe    410303 <__swc_fn_585f006d_000074_042643a3+0x103>
  4102ec:	cmp    ecx,0x10
  4102ef:	jne    41037e <__swc_fn_585f006d_000074_042643a3+0x17e>
  4102f5:	test   r14d,r14d
  4102f8:	mov    eax,0x1
  4102fd:	cmove  r14d,eax
  410301:	jmp    41030a <__swc_fn_585f006d_000074_042643a3+0x10a>
  410303:	lea    eax,[rcx-0x1]
  410306:	test   eax,ecx
  410308:	jne    41037e <__swc_fn_585f006d_000074_042643a3+0x17e>
  41030a:	lea    rax,[rip+0x10cef]        # 421000 <__swc_data_base_585f006d>
  410311:	mov    rax,QWORD PTR [rax]
  410314:	cmp    rax,0xffffffffffffffff
  410318:	je     410327 <__swc_fn_585f006d_000074_042643a3+0x127>
  41031a:	mov    eax,eax
  41031c:	mov    edi,eax
  41031e:	xor    eax,eax
  410320:	call   407000 <pthread_getspecific@plt>
  410325:	jmp    410329 <__swc_fn_585f006d_000074_042643a3+0x129>
  410327:	xor    eax,eax
  410329:	test   rax,rax
  41032c:	je     41037e <__swc_fn_585f006d_000074_042643a3+0x17e>
  41032e:	cmp    QWORD PTR [rax],r13
  410331:	jne    41037e <__swc_fn_585f006d_000074_042643a3+0x17e>
  410333:	lea    rcx,[r14+r14*4]
  410337:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  41033c:	test   rax,rax
  41033f:	je     41037e <__swc_fn_585f006d_000074_042643a3+0x17e>
  410341:	mov    rcx,QWORD PTR [rax]
  410344:	test   rcx,rcx
  410347:	je     410355 <__swc_fn_585f006d_000074_042643a3+0x155>
  410349:	mov    rdx,QWORD PTR [rcx]
  41034c:	mov    QWORD PTR [rax],rdx
  41034f:	add    DWORD PTR [rax+0x28],0x1
  410353:	jmp    410372 <__swc_fn_585f006d_000074_042643a3+0x172>
  410355:	mov    rcx,QWORD PTR [rax+0x18]
  410359:	cmp    QWORD PTR [rax+0x20],rcx
  41035d:	jae    410370 <__swc_fn_585f006d_000074_042643a3+0x170>
  41035f:	mov    rcx,QWORD PTR [rax+0x20]
  410363:	mov    edx,DWORD PTR [rax+0x2c]
  410366:	add    QWORD PTR [rax+0x20],rdx
  41036a:	add    DWORD PTR [rax+0x28],0x1
  41036e:	jmp    410372 <__swc_fn_585f006d_000074_042643a3+0x172>
  410370:	xor    ecx,ecx
  410372:	test   rcx,rcx
  410375:	je     41037e <__swc_fn_585f006d_000074_042643a3+0x17e>
  410377:	mov    QWORD PTR [r12+0x40],rcx
  41037c:	jmp    410389 <__swc_fn_585f006d_000074_042643a3+0x189>
  41037e:	mov    rcx,r13
  410381:	mov    rdx,r12
  410384:	call   4087c0 <__swc_fn_585f006d_000075_64d36d78>
  410389:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  410392:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  41039b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  4103a4:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  4103ad:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  4103b6:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  4103bf:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  4103c8:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  4103d1:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  4103da:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  4103e3:	add    rsp,0x1a0
  4103ea:	pop    rsi
  4103eb:	pop    rdi
  4103ec:	pop    r14
  4103ee:	pop    r13
  4103f0:	pop    r12
  4103f2:	ret
	...

0000000000410400 <__swc_fn_585f006d_000077_7b195156>:
  410400:	push   r12
  410402:	push   r13
  410404:	push   r14
  410406:	push   r15
  410408:	push   rdi
  410409:	push   rsi
  41040a:	sub    rsp,0x188
  410411:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  41041a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  410423:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  41042c:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  410435:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  41043e:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  410447:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  410450:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  410459:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  410462:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  41046b:	mov    r12,rdx
  41046e:	mov    r13,rcx
  410471:	mov    r14,QWORD PTR [r12+0x40]
  410476:	lea    rax,[rip+0x12bfb]        # 423078 <__swc_bss_base_585f006d+0x38>
  41047d:	mov    rcx,r14
  410480:	sub    rcx,QWORD PTR [rax+0x8]
  410484:	mov    rax,QWORD PTR [rip+0x12bfd]        # 423088 <__swc_bss_base_585f006d+0x48>
  41048b:	cmp    rcx,rax
  41048e:	jae    4104ba <__swc_fn_585f006d_000077_7b195156+0xba>
  410490:	mov    rax,r14
  410493:	and    rax,0xffffffffffc00000
  41049a:	mov    rcx,r14
  41049d:	shr    rcx,0x10
  4104a1:	and    ecx,0x3f
  4104a4:	mov    edx,DWORD PTR [rax+0x28]
  4104a7:	shrx   ecx,ecx,edx
  4104ac:	shl    rcx,0x4
  4104b0:	lea    r15,[rax+rcx*8+0x80]
  4104b8:	jmp    4104c5 <__swc_fn_585f006d_000077_7b195156+0xc5>
  4104ba:	mov    rcx,r14
  4104bd:	call   40ef90 <__swc_fn_585f006d_000026_bcdc5519>
  4104c2:	mov    r15,rax
  4104c5:	test   r15,r15
  4104c8:	je     41056f <__swc_fn_585f006d_000077_7b195156+0x16f>
  4104ce:	lea    rax,[rip+0x10b2b]        # 421000 <__swc_data_base_585f006d>
  4104d5:	mov    rax,QWORD PTR [rax]
  4104d8:	cmp    rax,0xffffffffffffffff
  4104dc:	je     4104eb <__swc_fn_585f006d_000077_7b195156+0xeb>
  4104de:	mov    eax,eax
  4104e0:	mov    edi,eax
  4104e2:	xor    eax,eax
  4104e4:	call   407000 <pthread_getspecific@plt>
  4104e9:	jmp    4104ed <__swc_fn_585f006d_000077_7b195156+0xed>
  4104eb:	xor    eax,eax
  4104ed:	mov    rcx,QWORD PTR [r15+0x40]
  4104f1:	cmp    rcx,rax
  4104f4:	jne    410554 <__swc_fn_585f006d_000077_7b195156+0x154>
  4104f6:	test   rax,rax
  4104f9:	je     41056f <__swc_fn_585f006d_000077_7b195156+0x16f>
  4104fb:	mov    ecx,DWORD PTR [r15+0x6c]
  4104ff:	test   ecx,ecx
  410501:	je     410521 <__swc_fn_585f006d_000077_7b195156+0x121>
  410503:	mov    rcx,r13
  410506:	mov    rdx,rax
  410509:	mov    r8,r15
  41050c:	mov    QWORD PTR [rsp+0xd8],rax
  410514:	call   407cd0 <__swc_fn_585f006d_000051_e072b516>
  410519:	mov    rax,QWORD PTR [rsp+0xd8]
  410521:	mov    rcx,QWORD PTR [r15]
  410524:	mov    QWORD PTR [r14],rcx
  410527:	mov    QWORD PTR [r15],r14
  41052a:	sub    DWORD PTR [r15+0x28],0x1
  41052f:	jne    410564 <__swc_fn_585f006d_000077_7b195156+0x164>
  410531:	movzx  ecx,BYTE PTR [r15+0x39]
  410536:	lea    rcx,[rcx+rcx*4]
  41053a:	lea    rcx,[rax+rcx*8+0x28]
  41053f:	cmp    QWORD PTR [rcx],r15
  410542:	je     410564 <__swc_fn_585f006d_000077_7b195156+0x164>
  410544:	mov    rcx,r13
  410547:	mov    rdx,rax
  41054a:	mov    r8,r15
  41054d:	call   40c400 <__swc_fn_585f006d_000055_2e3450f7>
  410552:	jmp    410564 <__swc_fn_585f006d_000077_7b195156+0x164>
  410554:	test   rcx,rcx
  410557:	je     41056f <__swc_fn_585f006d_000077_7b195156+0x16f>
  410559:	mov    rcx,r15
  41055c:	mov    rdx,r14
  41055f:	call   40ebd0 <__swc_fn_585f006d_000014_524c1f23>
  410564:	mov    QWORD PTR [r12+0x40],0x0
  41056d:	jmp    41057a <__swc_fn_585f006d_000077_7b195156+0x17a>
  41056f:	mov    rcx,r13
  410572:	mov    rdx,r12
  410575:	call   4087e0 <__swc_fn_585f006d_000078_1966ae2e>
  41057a:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  410583:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  41058c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  410595:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  41059e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  4105a7:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  4105b0:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  4105b9:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  4105c2:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  4105cb:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  4105d4:	add    rsp,0x188
  4105db:	pop    rsi
  4105dc:	pop    rdi
  4105dd:	pop    r15
  4105df:	pop    r14
  4105e1:	pop    r13
  4105e3:	pop    r12
  4105e5:	ret
	...

00000000004105f0 <__swc_fn_585f006d_000080_d2cd17e2>:
  4105f0:	sub    rsp,0x8
  4105f4:	mov    rax,rdx
  4105f7:	mov    rdx,QWORD PTR [rax+0x40]
  4105fb:	mov    r8,rax
  4105fe:	call   4101f0 <__swc_fn_585f006d_000071_b3d7b28e>
  410603:	add    rsp,0x8
  410607:	ret
	...

0000000000410610 <__swc_fn_585f006d_000083_4a10c7e7>:
  410610:	push   rsi
  410611:	push   rdi
  410612:	sub    rsp,0x8
  410616:	cmp    rcx,0xffffffffffffffef
  41061a:	ja     410640 <__swc_fn_585f006d_000083_4a10c7e7+0x30>
  41061c:	xor    esi,esi
  41061e:	lea    rax,[rcx+0x100f]
  410625:	and    rax,0xfffffffffffff000
  41062c:	lea    rcx,[rcx+0x10]
  410630:	cmp    rcx,0xfffffffffffff000
  410637:	cmovbe rsi,rax
  41063b:	test   rsi,rsi
  41063e:	jne    410649 <__swc_fn_585f006d_000083_4a10c7e7+0x39>
  410640:	xor    eax,eax
  410642:	add    rsp,0x8
  410646:	pop    rdi
  410647:	pop    rsi
  410648:	ret
  410649:	mov    rcx,rsi
  41064c:	call   410ca0 <__swc_fn_585f006d_000113_6b799b8d>
  410651:	mov    rdi,rax
  410654:	test   rax,rax
  410657:	jne    410662 <__swc_fn_585f006d_000083_4a10c7e7+0x52>
  410659:	xor    eax,eax
  41065b:	add    rsp,0x8
  41065f:	pop    rdi
  410660:	pop    rsi
  410661:	ret
  410662:	mov    rcx,rdi
  410665:	mov    rdx,rsi
  410668:	call   40d8c0 <__swc_fn_585f006d_000115_36905703>
  41066d:	test   al,al
  41066f:	jne    410685 <__swc_fn_585f006d_000083_4a10c7e7+0x75>
  410671:	mov    rcx,rdi
  410674:	mov    rdx,rsi
  410677:	call   409910 <__swc_fn_585f006d_000117_ed2d8fed>
  41067c:	xor    eax,eax
  41067e:	add    rsp,0x8
  410682:	pop    rdi
  410683:	pop    rsi
  410684:	ret
  410685:	mov    QWORD PTR [rdi],rsi
  410688:	mov    QWORD PTR [rdi+0x8],0x0
  410690:	lea    rax,[rdi+0x10]
  410694:	add    rsp,0x8
  410698:	pop    rdi
  410699:	pop    rsi
  41069a:	ret
  41069b:	add    BYTE PTR [rax],al
  41069d:	add    BYTE PTR [rax],al
	...

00000000004106a0 <__swc_fn_585f006d_000086_3953ef98>:
  4106a0:	sub    rsp,0x8
  4106a4:	cmp    BYTE PTR [rcx+0x2c],0x10
  4106a8:	jne    4106b3 <__swc_fn_585f006d_000086_3953ef98+0x13>
  4106aa:	test   DWORD PTR [rcx+0x28],0x80
  4106b1:	je     4106bb <__swc_fn_585f006d_000086_3953ef98+0x1b>
  4106b3:	mov    rax,rcx
  4106b6:	add    rsp,0x8
  4106ba:	ret
  4106bb:	mov    rcx,QWORD PTR [rcx+0x40]
  4106bf:	call   4106a0 <__swc_fn_585f006d_000086_3953ef98>
  4106c4:	add    rsp,0x8
  4106c8:	ret
	...

00000000004106e0 <__swc_fn_585f006d_000089_d182c4dc>:
  4106e0:	push   rsi
  4106e1:	push   rdi
  4106e2:	push   r12
  4106e4:	push   r13
  4106e6:	sub    rsp,0x8
  4106ea:	mov    rsi,rdx
  4106ed:	mov    rdi,rcx
  4106f0:	xor    r8d,r8d
  4106f3:	call   40cc20 <__swc_fn_585f006d_000094_63c1827b>
  4106f8:	test   al,al
  4106fa:	je     41070c <__swc_fn_585f006d_000089_d182c4dc+0x2c>
  4106fc:	mov    eax,0x1
  410701:	add    rsp,0x8
  410705:	pop    r13
  410707:	pop    r12
  410709:	pop    rdi
  41070a:	pop    rsi
  41070b:	ret
  41070c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  410711:	je     410720 <__swc_fn_585f006d_000089_d182c4dc+0x40>
  410713:	xor    eax,eax
  410715:	add    rsp,0x8
  410719:	pop    r13
  41071b:	pop    r12
  41071d:	pop    rdi
  41071e:	pop    rsi
  41071f:	ret
  410720:	mov    r12,QWORD PTR [rsi+0x98]
  410727:	mov    rax,QWORD PTR [rsi+0xa0]
  41072e:	mov    rsi,rax
  410731:	xor    r13d,r13d
  410734:	test   rsi,rsi
  410737:	je     410794 <__swc_fn_585f006d_000089_d182c4dc+0xb4>
  410739:	cs nop WORD PTR [rax+rax*1+0x0]
  410743:	cs nop WORD PTR [rax+rax*1+0x0]
  41074d:	nop    DWORD PTR [rax]
  410750:	lea    rax,[r13*8+0x0]
  410758:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  41075d:	mov    rcx,rax
  410760:	call   4106a0 <__swc_fn_585f006d_000086_3953ef98>
  410765:	cmp    BYTE PTR [rax+0x2c],0xe
  410769:	jne    41078a <__swc_fn_585f006d_000089_d182c4dc+0xaa>
  41076b:	mov    rcx,rdi
  41076e:	mov    rdx,rax
  410771:	call   4106e0 <__swc_fn_585f006d_000089_d182c4dc>
  410776:	test   al,al
  410778:	je     41078a <__swc_fn_585f006d_000089_d182c4dc+0xaa>
  41077a:	mov    eax,0x1
  41077f:	add    rsp,0x8
  410783:	pop    r13
  410785:	pop    r12
  410787:	pop    rdi
  410788:	pop    rsi
  410789:	ret
  41078a:	add    r13,0x1
  41078e:	sub    rsi,0x1
  410792:	jne    410750 <__swc_fn_585f006d_000089_d182c4dc+0x70>
  410794:	xor    eax,eax
  410796:	add    rsp,0x8
  41079a:	pop    r13
  41079c:	pop    r12
  41079e:	pop    rdi
  41079f:	pop    rsi
  4107a0:	ret
	...

00000000004107b0 <__swc_fn_585f006d_000092_14c65203>:
  4107b0:	sub    rsp,0x18
  4107b4:	vxorps xmm0,xmm0,xmm0
  4107b8:	vmovdqu XMMWORD PTR [rsp],xmm0
  4107bd:	call   4089f0 <__swc_fn_585f006d_000093_c2567a3b>
  4107c2:	add    rsp,0x18
  4107c6:	ret
	...

00000000004107d0 <__swc_fn_585f006d_000095_ad13d15c>:
  4107d0:	sub    rsp,0x8
  4107d4:	mov    rcx,QWORD PTR [rip+0x12865]        # 423040 <__swc_bss_base_585f006d>
  4107db:	test   rcx,rcx
  4107de:	jne    4107f0 <__swc_fn_585f006d_000095_ad13d15c+0x20>
  4107e0:	call   40e820 <__swc_fn_585f006d_000169_994c8876>
  4107e5:	lea    rcx,[rax+0x1]
  4107e9:	mov    QWORD PTR [rip+0x12850],rcx        # 423040 <__swc_bss_base_585f006d>
  4107f0:	dec    rcx
  4107f3:	call   40b6e0 <__swc_fn_585f006d_000171_360af05d>
  4107f8:	mov    rax,QWORD PTR [rax+0xc0]
  4107ff:	and    eax,0x1
  410802:	setne  al
  410805:	add    rsp,0x8
  410809:	ret
	...

0000000000410820 <__swc_fn_585f006d_000098_4f209617>:
  410820:	push   rbx
  410821:	push   rsi
  410822:	push   rdi
  410823:	push   r12
  410825:	sub    rsp,0x28
  410829:	mov    rbx,rcx
  41082c:	call   40cf80 <__swc_fn_585f006d_000097_4185993f>
  410831:	mov    rcx,QWORD PTR [rip+0x12808]        # 423040 <__swc_bss_base_585f006d>
  410838:	test   rcx,rcx
  41083b:	jne    41084d <__swc_fn_585f006d_000098_4f209617+0x2d>
  41083d:	call   40e820 <__swc_fn_585f006d_000169_994c8876>
  410842:	lea    rcx,[rax+0x1]
  410846:	mov    QWORD PTR [rip+0x127f3],rcx        # 423040 <__swc_bss_base_585f006d>
  41084d:	dec    rcx
  410850:	call   40b6e0 <__swc_fn_585f006d_000171_360af05d>
  410855:	mov    rsi,rax
  410858:	lea    rcx,[rsp+0x8]
  41085d:	call   408e30 <__swc_fn_585f006d_000096_93bfe675>
  410862:	mov    rdi,QWORD PTR [rsi+0x9c0]
  410869:	mov    r12,QWORD PTR [rsi+0xbe8]
  410870:	lea    rcx,[rsi+0x10]
  410874:	call   4117f0 <__swc_fn_585f006d_000161_13ead2ff>
  410879:	mov    rcx,rsi
  41087c:	call   408fa0 <__swc_fn_585f006d_000105_5a85fcf5>
  410881:	vxorps xmm0,xmm0,xmm0
  410885:	xor    eax,eax
  410887:	cs nop WORD PTR [rax+rax*1+0x0]
  410891:	cs nop WORD PTR [rax+rax*1+0x0]
  41089b:	nop    DWORD PTR [rax+rax*1+0x0]
  4108a0:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  4108a5:	add    rax,0x10
  4108a9:	cmp    rax,0xbf0
  4108b0:	jne    4108a0 <__swc_fn_585f006d_000098_4f209617+0x80>
  4108b2:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4108b8:	vmovups XMMWORD PTR [rsi],xmm0
  4108bc:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4108c2:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  4108ca:	mov    QWORD PTR [rsi+0x9c0],rdi
  4108d1:	mov    QWORD PTR [rsi+0xbe8],r12
  4108d8:	mov    rcx,QWORD PTR [rip+0x12761]        # 423040 <__swc_bss_base_585f006d>
  4108df:	test   rcx,rcx
  4108e2:	jne    4108f4 <__swc_fn_585f006d_000098_4f209617+0xd4>
  4108e4:	call   40e820 <__swc_fn_585f006d_000169_994c8876>
  4108e9:	lea    rcx,[rax+0x1]
  4108ed:	mov    QWORD PTR [rip+0x1274c],rcx        # 423040 <__swc_bss_base_585f006d>
  4108f4:	dec    rcx
  4108f7:	call   40b6e0 <__swc_fn_585f006d_000171_360af05d>
  4108fc:	mov    rsi,rax
  4108ff:	mov    QWORD PTR [rsi+0xc0],rbx
  410906:	and    ebx,0x1
  410909:	jne    41090d <__swc_fn_585f006d_000098_4f209617+0xed>
  41090b:	xor    eax,eax
  41090d:	test   rbx,rbx
  410910:	sete   al
  410913:	xor    cl,cl
  410915:	xor    dl,dl
  410917:	xor    r8b,r8b
  41091a:	xor    r9b,r9b
  41091d:	xor    r10b,r10b
  410920:	mov    r11,rax
  410923:	call   4087f0 <__swc_fn_585f006d_000081_5cc7acfc>
  410928:	lea    rbx,[rsp+0x18]
  41092d:	mov    rcx,rbx
  410930:	call   408e30 <__swc_fn_585f006d_000096_93bfe675>
  410935:	lea    rcx,[rsi+0x10]
  410939:	mov    edx,0x400000
  41093e:	mov    r8,rbx
  410941:	call   40e560 <__swc_fn_585f006d_000163_8a3d304f>
  410946:	lea    rcx,[rsi+0x68]
  41094a:	mov    edx,0x4000
  41094f:	mov    r8,rbx
  410952:	call   40e560 <__swc_fn_585f006d_000163_8a3d304f>
  410957:	add    rsp,0x28
  41095b:	pop    r12
  41095d:	pop    rdi
  41095e:	pop    rsi
  41095f:	pop    rbx
  410960:	ret
	...

0000000000410970 <__swc_fn_585f006d_000101_d0b19c14>:
  410970:	push   rbx
  410971:	push   rsi
  410972:	sub    rsp,0x18
  410976:	mov    rbx,rcx
  410979:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  41097e:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410984:	mov    rsi,QWORD PTR [rbx+0x70]
  410988:	lea    rcx,[rcx+0x18]
  41098c:	call   4117f0 <__swc_fn_585f006d_000161_13ead2ff>
  410991:	lea    rcx,[rsp+0x8]
  410996:	mov    rdx,rbx
  410999:	mov    r8d,0x78
  41099f:	call   40cfe0 <__swc_fn_585f006d_000100_d4bdcaa4>
  4109a4:	mov    rax,rsi
  4109a7:	add    rsp,0x18
  4109ab:	pop    rsi
  4109ac:	pop    rbx
  4109ad:	ret
	...

00000000004109b0 <__swc_fn_585f006d_000104_3c3b96fb>:
  4109b0:	push   rsi
  4109b1:	push   rdi
  4109b2:	sub    rsp,0x8
  4109b6:	cmp    QWORD PTR [rcx],0x0
  4109ba:	jne    4109c3 <__swc_fn_585f006d_000104_3c3b96fb+0x13>
  4109bc:	add    rsp,0x8
  4109c0:	pop    rdi
  4109c1:	pop    rsi
  4109c2:	ret
  4109c3:	mov    rsi,QWORD PTR [rcx]
  4109c6:	mov    rax,QWORD PTR [rcx+0x8]
  4109ca:	test   rax,rax
  4109cd:	je     4109e3 <__swc_fn_585f006d_000104_3c3b96fb+0x33>
  4109cf:	test   DWORD PTR [rax+0x28],0x400000
  4109d6:	je     4109e3 <__swc_fn_585f006d_000104_3c3b96fb+0x33>
  4109d8:	mov    rcx,QWORD PTR [rax+0x30]
  4109dc:	test   rcx,rcx
  4109df:	cmovne rax,rcx
  4109e3:	lea    rdx,[rip+0x190e]        # 4122f8 <__swc_rdata_base_585f006d+0x1e8>
  4109ea:	lea    rcx,[rip+0x19ef]        # 4123e0 <__swc_rdata_base_585f006d+0x2d0>
  4109f1:	mov    r8,rax
  4109f4:	xor    r9d,r9d
  4109f7:	xor    al,al
  4109f9:	mov    r10,rax
  4109fc:	xor    r11d,r11d
  4109ff:	call   4107b0 <__swc_fn_585f006d_000092_14c65203>
  410a04:	test   rax,rax
  410a07:	je     410a17 <__swc_fn_585f006d_000104_3c3b96fb+0x67>
  410a09:	mov    rdi,QWORD PTR [rax+0x48]
  410a0d:	test   rdi,rdi
  410a10:	je     410a17 <__swc_fn_585f006d_000104_3c3b96fb+0x67>
  410a12:	mov    rcx,rsi
  410a15:	call   rdi
  410a17:	add    rsp,0x8
  410a1b:	pop    rdi
  410a1c:	pop    rsi
  410a1d:	ret
	...

0000000000410a20 <__swc_fn_585f006d_000107_90faaa26>:
  410a20:	push   rbx
  410a21:	push   rsi
  410a22:	push   rdi
  410a23:	sub    rsp,0x20
  410a27:	mov    rbx,rdx
  410a2a:	mov    rsi,rcx
  410a2d:	mov    rcx,QWORD PTR [rip+0x1260c]        # 423040 <__swc_bss_base_585f006d>
  410a34:	test   rcx,rcx
  410a37:	jne    410a49 <__swc_fn_585f006d_000107_90faaa26+0x29>
  410a39:	call   40e820 <__swc_fn_585f006d_000169_994c8876>
  410a3e:	lea    rcx,[rax+0x1]
  410a42:	mov    QWORD PTR [rip+0x125f7],rcx        # 423040 <__swc_bss_base_585f006d>
  410a49:	dec    rcx
  410a4c:	call   40b6e0 <__swc_fn_585f006d_000171_360af05d>
  410a51:	mov    rdi,rax
  410a54:	mov    rax,QWORD PTR [rdi+0xbd0]
  410a5b:	xor    ecx,ecx
  410a5d:	test   rax,rax
  410a60:	je     410a65 <__swc_fn_585f006d_000107_90faaa26+0x45>
  410a62:	mov    rcx,QWORD PTR [rax]
  410a65:	call   40e950 <__swc_fn_585f006d_000178_718d7b54>
  410a6a:	lea    rax,[rsp+0x8]
  410a6f:	lea    rcx,[rdi+0x9c8]
  410a76:	mov    QWORD PTR [rsp+0x8],rcx
  410a7b:	mov    QWORD PTR [rax+0x8],0x40
  410a83:	xor    ecx,ecx
  410a85:	mov    rdx,rax
  410a88:	call   409a40 <__swc_fn_585f006d_000123_4f256d58>
  410a8d:	mov    DWORD PTR [rdi+0xbc8],eax
  410a93:	mov    rdi,QWORD PTR [rdi+0x990]
  410a9a:	test   rdi,rdi
  410a9d:	je     410aa7 <__swc_fn_585f006d_000107_90faaa26+0x87>
  410a9f:	mov    rcx,rsi
  410aa2:	mov    rdx,rbx
  410aa5:	call   rdi
  410aa7:	call   4107d0 <__swc_fn_585f006d_000095_ad13d15c>
  410aac:	test   al,al
  410aae:	je     410abe <__swc_fn_585f006d_000107_90faaa26+0x9e>
  410ab0:	mov    rcx,rsi
  410ab3:	mov    rdx,rbx
  410ab6:	xor    r8d,r8d
  410ab9:	call   40da60 <__swc_fn_585f006d_000124_83db7238>
  410abe:	mov    rcx,rsi
  410ac1:	mov    rdx,rbx
  410ac4:	call   40d0e0 <__swc_fn_585f006d_000106_ffe51047>
  410ac9:	call   411050 <__swc_fn_585f006d_000122_be2e2f68>
  410ace:	add    rsp,0x20
  410ad2:	pop    rdi
  410ad3:	pop    rsi
  410ad4:	pop    rbx
  410ad5:	ret
	...

0000000000410ae0 <__swc_fn_585f006d_000110_3dc01326>:
  410ae0:	test   r8,r8
  410ae3:	jne    410ae8 <__swc_fn_585f006d_000110_3dc01326+0x8>
  410ae5:	xor    eax,eax
  410ae7:	ret
  410ae8:	xor    eax,eax
  410aea:	nop    WORD PTR [rax+rax*1+0x0]
  410af0:	mov    r9,r8
  410af3:	sub    r9,rax
  410af6:	cmp    r9,0x10
  410afa:	jb     410b44 <__swc_fn_585f006d_000110_3dc01326+0x64>
  410afc:	lea    r9,[rcx+rax*1]
  410b00:	lea    r10,[rdx+rax*1]
  410b04:	vmovups xmm0,XMMWORD PTR [r10]
  410b09:	vmovups xmm1,XMMWORD PTR [r9]
  410b0e:	vpcmpeqb xmm0,xmm1,xmm0
  410b12:	vpmovmskb r9d,xmm0
  410b16:	cmp    r9d,0xffff
  410b1d:	je     410b3e <__swc_fn_585f006d_000110_3dc01326+0x5e>
  410b1f:	not    r9d
  410b22:	xor    r8d,r8d
  410b25:	movzx  r9d,r9w
  410b29:	tzcnt  r8d,r9d
  410b2e:	add    rax,r8
  410b31:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410b35:	movzx  eax,BYTE PTR [rdx+rax*1]
  410b39:	sub    ecx,eax
  410b3b:	mov    eax,ecx
  410b3d:	ret
  410b3e:	lea    rax,[rax+0x10]
  410b42:	jmp    410af0 <__swc_fn_585f006d_000110_3dc01326+0x10>
  410b44:	cmp    r9,0x8
  410b48:	jb     410bbb <__swc_fn_585f006d_000110_3dc01326+0xdb>
  410b4a:	lea    r9,[rcx+rax*1]
  410b4e:	lea    r10,[rdx+rax*1]
  410b52:	mov    r9,QWORD PTR [r9]
  410b55:	xor    r9,QWORD PTR [r10]
  410b58:	test   r9,r9
  410b5b:	je     410b79 <__swc_fn_585f006d_000110_3dc01326+0x99>
  410b5d:	xor    r8d,r8d
  410b60:	tzcnt  r8,r9
  410b65:	shr    r8,0x3
  410b69:	add    rax,r8
  410b6c:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410b70:	movzx  eax,BYTE PTR [rdx+rax*1]
  410b74:	sub    ecx,eax
  410b76:	mov    eax,ecx
  410b78:	ret
  410b79:	lea    rax,[rax+0x8]
  410b7d:	cmp    rax,r8
  410b80:	jne    410b85 <__swc_fn_585f006d_000110_3dc01326+0xa5>
  410b82:	xor    eax,eax
  410b84:	ret
  410b85:	lea    rax,[r8-0x8]
  410b89:	lea    r8,[rcx+rax*1]
  410b8d:	lea    r9,[rdx+rax*1]
  410b91:	mov    r8,QWORD PTR [r8]
  410b94:	xor    r8,QWORD PTR [r9]
  410b97:	test   r8,r8
  410b9a:	je     410bb8 <__swc_fn_585f006d_000110_3dc01326+0xd8>
  410b9c:	xor    r9d,r9d
  410b9f:	tzcnt  r9,r8
  410ba4:	shr    r9,0x3
  410ba8:	add    rax,r9
  410bab:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410baf:	movzx  eax,BYTE PTR [rdx+rax*1]
  410bb3:	sub    ecx,eax
  410bb5:	mov    eax,ecx
  410bb7:	ret
  410bb8:	xor    eax,eax
  410bba:	ret
  410bbb:	cmp    r9,0x4
  410bbf:	jb     410c32 <__swc_fn_585f006d_000110_3dc01326+0x152>
  410bc1:	lea    r9,[rcx+rax*1]
  410bc5:	lea    r10,[rdx+rax*1]
  410bc9:	mov    r9d,DWORD PTR [r9]
  410bcc:	xor    r9d,DWORD PTR [r10]
  410bcf:	test   r9d,r9d
  410bd2:	je     410bf0 <__swc_fn_585f006d_000110_3dc01326+0x110>
  410bd4:	xor    r8d,r8d
  410bd7:	tzcnt  r8,r9
  410bdc:	shr    r8,0x3
  410be0:	add    rax,r8
  410be3:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410be7:	movzx  eax,BYTE PTR [rdx+rax*1]
  410beb:	sub    ecx,eax
  410bed:	mov    eax,ecx
  410bef:	ret
  410bf0:	lea    rax,[rax+0x4]
  410bf4:	cmp    rax,r8
  410bf7:	jne    410bfc <__swc_fn_585f006d_000110_3dc01326+0x11c>
  410bf9:	xor    eax,eax
  410bfb:	ret
  410bfc:	lea    rax,[r8-0x4]
  410c00:	lea    r8,[rcx+rax*1]
  410c04:	lea    r9,[rdx+rax*1]
  410c08:	mov    r8d,DWORD PTR [r8]
  410c0b:	xor    r8d,DWORD PTR [r9]
  410c0e:	test   r8d,r8d
  410c11:	je     410c2f <__swc_fn_585f006d_000110_3dc01326+0x14f>
  410c13:	xor    r9d,r9d
  410c16:	tzcnt  r9,r8
  410c1b:	shr    r9,0x3
  410c1f:	add    rax,r9
  410c22:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410c26:	movzx  eax,BYTE PTR [rdx+rax*1]
  410c2a:	sub    ecx,eax
  410c2c:	mov    eax,ecx
  410c2e:	ret
  410c2f:	xor    eax,eax
  410c31:	ret
  410c32:	cmp    r9,0x2
  410c36:	jb     410c89 <__swc_fn_585f006d_000110_3dc01326+0x1a9>
  410c38:	lea    r9,[rcx+rax*1]
  410c3c:	lea    r10,[rdx+rax*1]
  410c40:	mov    r9w,WORD PTR [r9]
  410c44:	xor    r9w,WORD PTR [r10]
  410c48:	test   r9w,r9w
  410c4c:	je     410c6e <__swc_fn_585f006d_000110_3dc01326+0x18e>
  410c4e:	xor    r8d,r8d
  410c51:	movzx  r9d,r9w
  410c55:	tzcnt  r8,r9
  410c5a:	shr    r8,0x3
  410c5e:	add    rax,r8
  410c61:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410c65:	movzx  eax,BYTE PTR [rdx+rax*1]
  410c69:	sub    ecx,eax
  410c6b:	mov    eax,ecx
  410c6d:	ret
  410c6e:	lea    rax,[rax+0x2]
  410c72:	cmp    rax,r8
  410c75:	jne    410c7a <__swc_fn_585f006d_000110_3dc01326+0x19a>
  410c77:	xor    eax,eax
  410c79:	ret
  410c7a:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  410c80:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  410c86:	sub    eax,ecx
  410c88:	ret
  410c89:	test   r9,r9
  410c8c:	je     410c9b <__swc_fn_585f006d_000110_3dc01326+0x1bb>
  410c8e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410c92:	movzx  eax,BYTE PTR [rdx+rax*1]
  410c96:	sub    ecx,eax
  410c98:	mov    eax,ecx
  410c9a:	ret
  410c9b:	xor    eax,eax
  410c9d:	ret
	...

0000000000410ca0 <__swc_fn_585f006d_000113_6b799b8d>:
  410ca0:	push   r12
  410ca2:	push   r13
  410ca4:	push   r14
  410ca6:	push   rdi
  410ca7:	push   rsi
  410ca8:	push   r15
  410caa:	sub    rsp,0xd8
  410cb1:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  410cb7:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  410cbd:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  410cc3:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  410cc9:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  410ccf:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  410cd8:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  410ce1:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  410cea:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  410cf3:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  410cfc:	mov    r12,rcx
  410cff:	test   rcx,rcx
  410d02:	je     410d1e <__swc_fn_585f006d_000113_6b799b8d+0x7e>
  410d04:	mov    eax,r12d
  410d07:	and    eax,0xfff
  410d0d:	setne  al
  410d10:	cmp    r12,0xffffffffffffefff
  410d17:	seta   cl
  410d1a:	or     al,cl
  410d1c:	je     410d25 <__swc_fn_585f006d_000113_6b799b8d+0x85>
  410d1e:	xor    eax,eax
  410d20:	jmp    410dbb <__swc_fn_585f006d_000113_6b799b8d+0x11b>
  410d25:	call   40d780 <__swc_fn_585f006d_000112_126150d1>
  410d2a:	mov    r13,rax
  410d2d:	test   rax,rax
  410d30:	jne    410d39 <__swc_fn_585f006d_000113_6b799b8d+0x99>
  410d32:	xor    eax,eax
  410d34:	jmp    410dbb <__swc_fn_585f006d_000113_6b799b8d+0x11b>
  410d39:	lea    r14,[r12+0x1000]
  410d41:	xor    edi,edi
  410d43:	mov    rsi,r14
  410d46:	xor    edx,edx
  410d48:	mov    ecx,0x22
  410d4d:	mov    eax,0xffffffff
  410d52:	movsxd r8,eax
  410d55:	xor    r9d,r9d
  410d58:	xor    eax,eax
  410d5a:	call   4070d0 <mmap@plt>
  410d5f:	mov    r15,rax
  410d62:	cmp    rax,0xffffffffffffffff
  410d66:	jne    410d6c <__swc_fn_585f006d_000113_6b799b8d+0xcc>
  410d68:	xor    eax,eax
  410d6a:	jmp    410dbb <__swc_fn_585f006d_000113_6b799b8d+0x11b>
  410d6c:	mov    rdi,r15
  410d6f:	mov    esi,0x1000
  410d74:	mov    edx,0x3
  410d79:	xor    eax,eax
  410d7b:	call   407170 <mprotect@plt>
  410d80:	test   eax,eax
  410d82:	je     410d95 <__swc_fn_585f006d_000113_6b799b8d+0xf5>
  410d84:	mov    rdi,r15
  410d87:	mov    rsi,r14
  410d8a:	xor    eax,eax
  410d8c:	call   407160 <munmap@plt>
  410d91:	xor    eax,eax
  410d93:	jmp    410dbb <__swc_fn_585f006d_000113_6b799b8d+0x11b>
  410d95:	mov    QWORD PTR [r15+0x8],r12
  410d99:	mov    rcx,r13
  410d9c:	call   4113f0 <__swc_fn_585f006d_000137_8c07c14b>
  410da1:	mov    rax,QWORD PTR [r13+0x8]
  410da5:	mov    QWORD PTR [r15],rax
  410da8:	mov    QWORD PTR [r13+0x8],r15
  410dac:	mov    rcx,r13
  410daf:	call   409de0 <__swc_fn_585f006d_000138_715e84ff>
  410db4:	lea    rax,[r15+0x1000]
  410dbb:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  410dc1:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  410dc7:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  410dcd:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  410dd3:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  410dd9:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  410de2:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  410deb:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  410df4:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  410dfd:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  410e06:	add    rsp,0xd8
  410e0d:	pop    r15
  410e0f:	pop    rsi
  410e10:	pop    rdi
  410e11:	pop    r14
  410e13:	pop    r13
  410e15:	pop    r12
  410e17:	ret
	...

0000000000410e20 <__swc_fn_585f006d_000116_e9fc0224>:
  410e20:	push   rbx
  410e21:	push   r12
  410e23:	push   rdi
  410e24:	push   rsi
  410e25:	sub    rsp,0xa8
  410e2c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  410e32:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410e38:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  410e3e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410e44:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410e4a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  410e50:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410e56:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410e5c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410e65:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  410e6e:	mov    rbx,rdx
  410e71:	mov    r12,rcx
  410e74:	mov    rdi,rcx
  410e77:	mov    rsi,rdx
  410e7a:	xor    edx,edx
  410e7c:	xor    eax,eax
  410e7e:	call   407170 <mprotect@plt>
  410e83:	test   eax,eax
  410e85:	jne    410ea9 <__swc_fn_585f006d_000116_e9fc0224+0x89>
  410e87:	mov    rcx,r12
  410e8a:	mov    rdx,rbx
  410e8d:	xor    al,al
  410e8f:	mov    r8,rax
  410e92:	call   409880 <__swc_fn_585f006d_000114_5f48311c>
  410e97:	mov    rdi,r12
  410e9a:	mov    rsi,rbx
  410e9d:	mov    edx,0x4
  410ea2:	xor    eax,eax
  410ea4:	call   4071d0 <madvise@plt>
  410ea9:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410eaf:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410eb5:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410ebb:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410ec1:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410ec7:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410ecd:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410ed3:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410ed9:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410ee2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410eeb:	add    rsp,0xa8
  410ef2:	pop    rsi
  410ef3:	pop    rdi
  410ef4:	pop    r12
  410ef6:	pop    rbx
  410ef7:	ret
	...

0000000000410f00 <__swc_fn_585f006d_000119_d3318640>:
  410f00:	push   rsi
  410f01:	push   rdi
  410f02:	push   r12
  410f04:	push   r13
  410f06:	push   r14
  410f08:	sub    rsp,0xe0
  410f0f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  410f15:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  410f1b:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  410f21:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  410f27:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  410f2d:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  410f36:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  410f3f:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  410f48:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  410f51:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  410f5a:	mov    rsi,rdx
  410f5d:	mov    rdi,rcx
  410f60:	call   40d780 <__swc_fn_585f006d_000112_126150d1>
  410f65:	mov    r12,rax
  410f68:	test   rax,rax
  410f6b:	jne    410f72 <__swc_fn_585f006d_000119_d3318640+0x72>
  410f6d:	jmp    410fe6 <__swc_fn_585f006d_000119_d3318640+0xe6>
  410f72:	mov    rcx,r12
  410f75:	call   4113f0 <__swc_fn_585f006d_000137_8c07c14b>
  410f7a:	lea    r13,[r12+0x8]
  410f7f:	mov    rax,QWORD PTR [r13+0x0]
  410f83:	test   rax,rax
  410f86:	je     410fde <__swc_fn_585f006d_000119_d3318640+0xde>
  410f88:	nop    DWORD PTR [rax+rax*1+0x0]
  410f90:	lea    rcx,[rax+0x1000]
  410f97:	cmp    rcx,rdi
  410f9a:	jne    410fd2 <__swc_fn_585f006d_000119_d3318640+0xd2>
  410f9c:	cmp    QWORD PTR [rax+0x8],rsi
  410fa0:	je     410fac <__swc_fn_585f006d_000119_d3318640+0xac>
  410fa2:	mov    rcx,r12
  410fa5:	call   409de0 <__swc_fn_585f006d_000138_715e84ff>
  410faa:	jmp    410fe6 <__swc_fn_585f006d_000119_d3318640+0xe6>
  410fac:	mov    r14,QWORD PTR [rax]
  410faf:	mov    rdi,rax
  410fb2:	lea    rsi,[rsi+0x1000]
  410fb9:	xor    eax,eax
  410fbb:	call   407160 <munmap@plt>
  410fc0:	test   eax,eax
  410fc2:	jne    410fc8 <__swc_fn_585f006d_000119_d3318640+0xc8>
  410fc4:	mov    QWORD PTR [r13+0x0],r14
  410fc8:	mov    rcx,r12
  410fcb:	call   409de0 <__swc_fn_585f006d_000138_715e84ff>
  410fd0:	jmp    410fe6 <__swc_fn_585f006d_000119_d3318640+0xe6>
  410fd2:	mov    r13,rax
  410fd5:	mov    rax,QWORD PTR [r13+0x0]
  410fd9:	test   rax,rax
  410fdc:	jne    410f90 <__swc_fn_585f006d_000119_d3318640+0x90>
  410fde:	mov    rcx,r12
  410fe1:	call   409de0 <__swc_fn_585f006d_000138_715e84ff>
  410fe6:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  410fec:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  410ff2:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  410ff8:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  410ffe:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  411004:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  41100d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  411016:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  41101f:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  411028:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  411031:	add    rsp,0xe0
  411038:	pop    r14
  41103a:	pop    r13
  41103c:	pop    r12
  41103e:	pop    rdi
  41103f:	pop    rsi
  411040:	ret
	...

0000000000411050 <__swc_fn_585f006d_000122_be2e2f68>:
  411050:	push   rdi
  411051:	push   rsi
  411052:	sub    rsp,0xa8
  411059:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41105f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411065:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41106b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411071:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411077:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41107d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411083:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411089:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411092:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41109b:	mov    rdi,0xfffffffffffffd66
  4110a2:	xor    eax,eax
  4110a4:	call   407180 <exit@plt>
  4110a9:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4110af:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4110b5:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4110bb:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4110c1:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4110c7:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4110cd:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4110d3:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4110d9:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4110e2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4110eb:	add    rsp,0xa8
  4110f2:	pop    rsi
  4110f3:	pop    rdi
  4110f4:	ret
	...

0000000000411100 <__swc_fn_585f006d_000125_540bf7e8>:
  411100:	push   rbx
  411101:	push   rsi
  411102:	push   rdi
  411103:	sub    rsp,0x30
  411107:	mov    rbx,rdx
  41110a:	mov    esi,ecx
  41110c:	test   ecx,ecx
  41110e:	je     4111e3 <__swc_fn_585f006d_000125_540bf7e8+0xe3>
  411114:	mov    rcx,rsi
  411117:	shl    rcx,0x4
  41111b:	call   410610 <__swc_fn_585f006d_000083_4a10c7e7>
  411120:	test   rax,rax
  411123:	je     4111d2 <__swc_fn_585f006d_000125_540bf7e8+0xd2>
  411129:	mov    rcx,rsi
  41112c:	xor    edx,edx
  41112e:	test   rsi,rsi
  411131:	jbe    4111b2 <__swc_fn_585f006d_000125_540bf7e8+0xb2>
  411137:	nop    WORD PTR [rax+rax*1+0x0]
  411140:	mov    r8d,edx
  411143:	mov    r9,QWORD PTR [rbx+r8*8]
  411147:	add    r8,r8
  41114a:	lea    r8,[rax+r8*8]
  41114e:	xor    r10d,r10d
  411151:	test   r9,r9
  411154:	je     411190 <__swc_fn_585f006d_000125_540bf7e8+0x90>
  411156:	mov    r11,r9
  411159:	mov    dil,BYTE PTR [r11]
  41115c:	test   dil,dil
  41115f:	je     411190 <__swc_fn_585f006d_000125_540bf7e8+0x90>
  411161:	cs nop WORD PTR [rax+rax*1+0x0]
  41116b:	cs nop WORD PTR [rax+rax*1+0x0]
  411175:	cs nop WORD PTR [rax+rax*1+0x0]
  41117f:	nop
  411180:	add    r11,0x1
  411184:	add    r10,0x1
  411188:	mov    dil,BYTE PTR [r11]
  41118b:	test   dil,dil
  41118e:	jne    411180 <__swc_fn_585f006d_000125_540bf7e8+0x80>
  411190:	mov    QWORD PTR [rsp+0x18],r9
  411195:	mov    QWORD PTR [rsp+0x20],r10
  41119a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  4111a0:	vmovups XMMWORD PTR [r8],xmm0
  4111a5:	add    rdx,0x1
  4111a9:	cmp    rdx,rcx
  4111ac:	jb     411140 <__swc_fn_585f006d_000125_540bf7e8+0x40>
  4111b2:	lea    rcx,[rip+0x14b8f]        # 425d48 <__swc_bss_base_585f006d+0x2d08>
  4111b9:	mov    QWORD PTR [rsp+0x8],rax
  4111be:	mov    esi,esi
  4111c0:	mov    QWORD PTR [rsp+0x10],rsi
  4111c5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4111cb:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4111d0:	jmp    4111e3 <__swc_fn_585f006d_000125_540bf7e8+0xe3>
  4111d2:	lea    rcx,[rip+0x1417]        # 4125f0 <__swc_rdata_base_585f006d+0x4e0>
  4111d9:	call   409930 <__swc_fn_585f006d_000120_2648f149>
  4111de:	call   411050 <__swc_fn_585f006d_000122_be2e2f68>
  4111e3:	add    rsp,0x30
  4111e7:	pop    rdi
  4111e8:	pop    rsi
  4111e9:	pop    rbx
  4111ea:	ret
  4111eb:	add    BYTE PTR [rax],al
  4111ed:	add    BYTE PTR [rax],al
	...

00000000004111f0 <__swc_fn_585f006d_000128_a481cb88>:
  4111f0:	push   rdi
  4111f1:	push   rsi
  4111f2:	sub    rsp,0xa8
  4111f9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4111ff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411205:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41120b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411211:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411217:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41121d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411223:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411229:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411232:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41123b:	mov    edi,ecx
  41123d:	xor    eax,eax
  41123f:	call   4071e0 <pthread_key_delete@plt>
  411244:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41124a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411250:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411256:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41125c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411262:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411268:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41126e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411274:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41127d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411286:	add    rsp,0xa8
  41128d:	pop    rsi
  41128e:	pop    rdi
  41128f:	ret

0000000000411290 <__swc_fn_585f006d_000131_a611b8c4>:
  411290:	push   rdi
  411291:	push   rsi
  411292:	sub    rsp,0xa8
  411299:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41129f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4112a5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4112ab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4112b1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4112b7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4112bd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4112c3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4112c9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4112d2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4112db:	test   rcx,rcx
  4112de:	je     4112ef <__swc_fn_585f006d_000131_a611b8c4+0x5f>
  4112e0:	lea    rax,[rcx-0x1]
  4112e4:	mov    eax,eax
  4112e6:	mov    edi,eax
  4112e8:	xor    eax,eax
  4112ea:	call   4071e0 <pthread_key_delete@plt>
  4112ef:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4112f5:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4112fb:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411301:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411307:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  41130d:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411313:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411319:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  41131f:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411328:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411331:	add    rsp,0xa8
  411338:	pop    rsi
  411339:	pop    rdi
  41133a:	ret
  41133b:	add    BYTE PTR [rax],al
  41133d:	add    BYTE PTR [rax],al
	...

0000000000411340 <__swc_fn_585f006d_000134_a9c1c700>:
  411340:	push   rsi
  411341:	push   rdi
  411342:	sub    rsp,0xa8
  411349:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41134f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411355:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41135b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411361:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411367:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41136d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411373:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411379:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411382:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41138b:	xor    eax,eax
  41138d:	call   4071f0 <gettid@plt>
  411392:	movsxd rax,eax
  411395:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41139b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4113a1:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4113a7:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4113ad:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4113b3:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4113b9:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4113bf:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4113c5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4113ce:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4113d7:	add    rsp,0xa8
  4113de:	pop    rdi
  4113df:	pop    rsi
  4113e0:	ret
	...

00000000004113f0 <__swc_fn_585f006d_000137_8c07c14b>:
  4113f0:	push   rbx
  4113f1:	push   rdi
  4113f2:	push   rsi
  4113f3:	sub    rsp,0xc0
  4113fa:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  411400:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  411406:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41140c:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  411412:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  411418:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41141e:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  411424:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41142d:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  411436:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41143f:	mov    rbx,rcx
  411442:	cs nop WORD PTR [rax+rax*1+0x0]
  41144c:	nop    DWORD PTR [rax+0x0]
  411450:	mov    edx,0x80000000
  411455:	xor    eax,eax
  411457:	lock cmpxchg DWORD PTR [rbx],edx
  41145b:	test   eax,eax
  41145d:	je     411494 <__swc_fn_585f006d_000137_8c07c14b+0xa4>
  41145f:	mov    eax,DWORD PTR [rbx]
  411461:	lea    rcx,[rsp+0x14]
  411466:	mov    DWORD PTR [rsp+0x14],eax
  41146a:	test   eax,eax
  41146c:	je     411450 <__swc_fn_585f006d_000137_8c07c14b+0x60>
  41146e:	mov    QWORD PTR [rsp],0x0
  411476:	mov    edi,0xca
  41147b:	mov    rsi,rbx
  41147e:	mov    edx,0x80
  411483:	mov    ecx,DWORD PTR [rcx]
  411485:	xor    r8d,r8d
  411488:	xor    r9d,r9d
  41148b:	xor    eax,eax
  41148d:	call   4071a0 <syscall@plt>
  411492:	jmp    411450 <__swc_fn_585f006d_000137_8c07c14b+0x60>
  411494:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  41149a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4114a0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4114a6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4114ac:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4114b2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4114b8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4114be:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4114c7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4114d0:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4114d9:	add    rsp,0xc0
  4114e0:	pop    rsi
  4114e1:	pop    rdi
  4114e2:	pop    rbx
  4114e3:	ret
	...

00000000004114f0 <__swc_fn_585f006d_000140_055b38a4>:
  4114f0:	sub    rsp,0x8
  4114f4:	call   409de0 <__swc_fn_585f006d_000138_715e84ff>
  4114f9:	add    rsp,0x8
  4114fd:	ret
	...

0000000000411500 <__swc_fn_585f006d_000143_d299b428>:
  411500:	push   rdi
  411501:	push   rsi
  411502:	sub    rsp,0xa8
  411509:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41150f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411515:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41151b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411521:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411527:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41152d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411533:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411539:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411542:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41154b:	mov    edi,0x28
  411550:	xor    eax,eax
  411552:	call   4071c0 <malloc@plt>
  411557:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41155d:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411563:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411569:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41156f:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411575:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  41157b:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411581:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411587:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411590:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411599:	add    rsp,0xa8
  4115a0:	pop    rsi
  4115a1:	pop    rdi
  4115a2:	ret
	...

00000000004115b0 <__swc_fn_585f006d_000146_162f363d>:
  4115b0:	mov    QWORD PTR [r8],0x0
  4115b7:	cmp    rdx,0x10
  4115bb:	jae    4115c0 <__swc_fn_585f006d_000146_162f363d+0x10>
  4115bd:	xor    eax,eax
  4115bf:	ret
  4115c0:	mov    eax,DWORD PTR [rcx]
  4115c2:	cmp    eax,0x42445753
  4115c8:	jne    4115d2 <__swc_fn_585f006d_000146_162f363d+0x22>
  4115ca:	mov    eax,DWORD PTR [rcx+0x4]
  4115cd:	cmp    eax,0x1
  4115d0:	je     4115d5 <__swc_fn_585f006d_000146_162f363d+0x25>
  4115d2:	xor    eax,eax
  4115d4:	ret
  4115d5:	mov    QWORD PTR [r8],rdx
  4115d8:	mov    rax,rcx
  4115db:	ret
  4115dc:	add    BYTE PTR [rax],al
	...

00000000004115e0 <__swc_fn_585f006d_000149_2eb804cc>:
  4115e0:	push   rbx
  4115e1:	sub    rsp,0xe0
  4115e8:	lea    rbx,[rsp+0x8]
  4115ed:	vxorps xmm0,xmm0,xmm0
  4115f1:	vmovups YMMWORD PTR [rbx],ymm0
  4115f5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  4115fa:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  4115ff:	vzeroupper
  411602:	mov    DWORD PTR [rbx+0x60],0x0
  411609:	mov    r8,rbx
  41160c:	mov    rdx,rcx
  41160f:	nop
  411610:	mov    r9,rdx
  411613:	movabs rdx,0x6666666666666667
  41161d:	mov    rax,r9
  411620:	imul   rdx
  411623:	sar    rdx,0x2
  411627:	mov    r10,rdx
  41162a:	shr    rdx,0x3f
  41162e:	add    r10,rdx
  411631:	mov    rdx,r10
  411634:	imul   r11,r10,0xa
  411638:	sub    r9,r11
  41163b:	mov    r11,QWORD PTR [rip+0xfce]        # 412610 <__swc_rdata_base_585f006d+0x500>
  411642:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  411647:	mov    BYTE PTR [r8],r9b
  41164a:	lea    r9,[r8+0x1]
  41164e:	mov    r8,r9
  411651:	test   r10,r10
  411654:	jne    411610 <__swc_fn_585f006d_000149_2eb804cc+0x30>
  411656:	test   rcx,rcx
  411659:	jge    411663 <__swc_fn_585f006d_000149_2eb804cc+0x83>
  41165b:	mov    BYTE PTR [r9],0x2d
  41165f:	add    r8,0x1
  411663:	mov    BYTE PTR [r8],0x0
  411667:	sub    r8,0x1
  41166b:	mov    rax,rbx
  41166e:	cmp    rax,r8
  411671:	jae    411696 <__swc_fn_585f006d_000149_2eb804cc+0xb6>
  411673:	cs nop WORD PTR [rax+rax*1+0x0]
  41167d:	nop    DWORD PTR [rax]
  411680:	mov    cl,BYTE PTR [r8]
  411683:	mov    dl,BYTE PTR [rax]
  411685:	mov    BYTE PTR [r8],dl
  411688:	sub    r8,0x1
  41168c:	mov    BYTE PTR [rax],cl
  41168e:	inc    rax
  411691:	cmp    rax,r8
  411694:	jb     411680 <__swc_fn_585f006d_000149_2eb804cc+0xa0>
  411696:	xor    eax,eax
  411698:	test   rbx,rbx
  41169b:	je     4116be <__swc_fn_585f006d_000149_2eb804cc+0xde>
  41169d:	mov    rcx,rbx
  4116a0:	mov    dl,BYTE PTR [rcx]
  4116a2:	test   dl,dl
  4116a4:	je     4116be <__swc_fn_585f006d_000149_2eb804cc+0xde>
  4116a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4116b0:	add    rcx,0x1
  4116b4:	add    rax,0x1
  4116b8:	mov    dl,BYTE PTR [rcx]
  4116ba:	test   dl,dl
  4116bc:	jne    4116b0 <__swc_fn_585f006d_000149_2eb804cc+0xd0>
  4116be:	mov    QWORD PTR [rbx+0xa8],rbx
  4116c5:	mov    QWORD PTR [rbx+0xb0],rax
  4116cc:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  4116d4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  4116dc:	lea    rcx,[rbx+0xb8]
  4116e3:	call   409930 <__swc_fn_585f006d_000120_2648f149>
  4116e8:	add    rsp,0xe0
  4116ef:	pop    rbx
  4116f0:	ret
	...

0000000000411700 <__swc_fn_585f006d_000152_86f1d437>:
  411700:	vxorps xmm0,xmm0,xmm0
  411704:	vmovups XMMWORD PTR [rcx],xmm0
  411708:	mov    QWORD PTR [rcx+0x10],0x0
  411710:	ret
	...

0000000000411720 <__swc_fn_585f006d_000155_86f1d437>:
  411720:	vxorps xmm0,xmm0,xmm0
  411724:	vmovups XMMWORD PTR [rcx],xmm0
  411728:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41172d:	vxorps xmm0,xmm0,xmm0
  411731:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411736:	vmovups xmm0,XMMWORD PTR [rip+0xfca]        # 412708 <__swc_rdata_base_585f006d+0x5f8>
  41173e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411743:	vxorps xmm0,xmm0,xmm0
  411747:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  41174c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411751:	mov    QWORD PTR [rcx+0x60],0x0
  411759:	ret
  41175a:	add    BYTE PTR [rax],al
  41175c:	add    BYTE PTR [rax],al
	...

0000000000411760 <__swc_fn_585f006d_000158_86f1d437>:
  411760:	vxorps xmm0,xmm0,xmm0
  411764:	vmovups XMMWORD PTR [rcx],xmm0
  411768:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41176d:	vxorps xmm0,xmm0,xmm0
  411771:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411776:	vmovups xmm0,XMMWORD PTR [rip+0x10b2]        # 412830 <__swc_rdata_base_585f006d+0x720>
  41177e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411783:	vxorps xmm0,xmm0,xmm0
  411787:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  41178c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411791:	vxorps xmm0,xmm0,xmm0
  411795:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  41179a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  41179f:	vxorps xmm0,xmm0,xmm0
  4117a3:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  4117ab:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  4117b3:	vxorps xmm0,xmm0,xmm0
  4117b7:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  4117bf:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  4117c7:	vxorps xmm0,xmm0,xmm0
  4117cb:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  4117d3:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  4117db:	mov    QWORD PTR [rcx+0xe0],0x0
  4117e6:	ret
	...

00000000004117f0 <__swc_fn_585f006d_000161_13ead2ff>:
  4117f0:	push   rbx
  4117f1:	mov    rbx,rcx
  4117f4:	call   40b370 <__swc_fn_585f006d_000162_e36363a8>
  4117f9:	mov    rax,QWORD PTR [rbx+0x10]
  4117fd:	test   rax,rax
  411800:	je     411811 <__swc_fn_585f006d_000161_13ead2ff+0x21>
  411802:	mov    rcx,rbx
  411805:	mov    rdx,rax
  411808:	mov    r8,QWORD PTR [rbx+0x18]
  41180c:	call   40e510 <__swc_fn_585f006d_000160_47b270e1>
  411811:	vxorps xmm0,xmm0,xmm0
  411815:	vmovups XMMWORD PTR [rbx],xmm0
  411819:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  41181e:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  411823:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  411828:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  41182d:	mov    QWORD PTR [rbx+0x50],0x0
  411835:	pop    rbx
  411836:	ret
	...

0000000000411840 <__swc_fn_585f006d_000164_72795826>:
  411840:	sub    rsp,0x10
  411844:	mov    eax,r8d
  411847:	mov    r8d,r9d
  41184a:	test   r9d,r9d
  41184d:	jne    411866 <__swc_fn_585f006d_000164_72795826+0x26>
  41184f:	vmovups xmm0,XMMWORD PTR [rip+0x1091]        # 4128e8 <__swc_rdata_base_585f006d+0x7d8>
  411857:	vmovups XMMWORD PTR [r10],xmm0
  41185c:	mov    eax,0x1
  411861:	add    rsp,0x10
  411865:	ret
  411866:	mov    r9,r8
  411869:	cmp    r8,rax
  41186c:	jb     411873 <__swc_fn_585f006d_000164_72795826+0x33>
  41186e:	cmp    r9,rdx
  411871:	jb     41187a <__swc_fn_585f006d_000164_72795826+0x3a>
  411873:	xor    eax,eax
  411875:	add    rsp,0x10
  411879:	ret
  41187a:	xor    eax,eax
  41187c:	lea    r8,[r9+rax*1]
  411880:	cmp    r8,rdx
  411883:	jae    4118b3 <__swc_fn_585f006d_000164_72795826+0x73>
  411885:	cs nop WORD PTR [rax+rax*1+0x0]
  41188f:	cs nop WORD PTR [rax+rax*1+0x0]
  411899:	nop    DWORD PTR [rax+0x0]
  4118a0:	cmp    BYTE PTR [rcx+r8*1],0x0
  4118a5:	je     4118b3 <__swc_fn_585f006d_000164_72795826+0x73>
  4118a7:	inc    rax
  4118aa:	lea    r8,[r9+rax*1]
  4118ae:	cmp    r8,rdx
  4118b1:	jb     4118a0 <__swc_fn_585f006d_000164_72795826+0x60>
  4118b3:	cmp    r8,rdx
  4118b6:	jne    4118bf <__swc_fn_585f006d_000164_72795826+0x7f>
  4118b8:	xor    eax,eax
  4118ba:	add    rsp,0x10
  4118be:	ret
  4118bf:	add    rcx,r9
  4118c2:	mov    QWORD PTR [rsp],rcx
  4118c6:	mov    QWORD PTR [rsp+0x8],rax
  4118cb:	vmovups xmm0,XMMWORD PTR [rsp]
  4118d0:	vmovups XMMWORD PTR [r10],xmm0
  4118d5:	mov    eax,0x1
  4118da:	add    rsp,0x10
  4118de:	ret
	...

00000000004118e0 <__swc_fn_585f006d_000167_bcc835b8>:
  4118e0:	push   rbp
  4118e1:	push   rbx
  4118e2:	push   rsi
  4118e3:	push   rdi
  4118e4:	push   r12
  4118e6:	push   r13
  4118e8:	push   r14
  4118ea:	push   r15
  4118ec:	sub    rsp,0x10
  4118f0:	mov    rbp,rsp
  4118f3:	vmovups XMMWORD PTR [rsp],xmm6
  4118f8:	sub    rsp,0x50
  4118fc:	mov    rbx,rsp
  4118ff:	mov    rsi,r8
  411902:	mov    QWORD PTR [rsp+0x30],r8
  411907:	mov    rdi,rcx
  41190a:	mov    QWORD PTR [rsp+0x38],rcx
  41190f:	mov    r12,rdx
  411912:	xor    r13b,r13b
  411915:	mov    r14,QWORD PTR [rdi+0x8]
  411919:	mov    QWORD PTR [rsp+0x40],r14
  41191e:	xor    r15d,r15d
  411921:	test   r14,r14
  411924:	jbe    411b7e <__swc_fn_585f006d_000167_bcc835b8+0x29e>
  41192a:	mov    r14,QWORD PTR [rdi]
  41192d:	mov    rax,QWORD PTR [rsp+0x40]
  411932:	mov    QWORD PTR [rsp+0x48],r14
  411937:	vmovups xmm6,XMMWORD PTR [rip+0xbc9]        # 412508 <__swc_rdata_base_585f006d+0x3f8>
  41193f:	nop
  411940:	cmp    QWORD PTR [r14+r15*8],0x0
  411945:	jne    41194f <__swc_fn_585f006d_000167_bcc835b8+0x6f>
  411947:	mov    r14,rax
  41194a:	jmp    411b5e <__swc_fn_585f006d_000167_bcc835b8+0x27e>
  41194f:	mov    rcx,QWORD PTR [rdi]
  411952:	mov    rdx,QWORD PTR [rcx+r15*8]
  411956:	mov    rdi,rbx
  411959:	mov    rcx,rdi
  41195c:	sub    rsp,0x8
  411960:	mov    r14,rax
  411963:	call   40e590 <__swc_fn_585f006d_000166_cc119975>
  411968:	add    rsp,0x8
  41196c:	mov    al,BYTE PTR [rbx]
  41196e:	test   al,al
  411970:	je     411b5e <__swc_fn_585f006d_000167_bcc835b8+0x27e>
  411976:	mov    al,BYTE PTR [rbx+0x1]
  411979:	test   al,al
  41197b:	jne    411986 <__swc_fn_585f006d_000167_bcc835b8+0xa6>
  41197d:	test   sil,sil
  411980:	je     411b5e <__swc_fn_585f006d_000167_bcc835b8+0x27e>
  411986:	test   r13b,r13b
  411989:	jne    411a47 <__swc_fn_585f006d_000167_bcc835b8+0x167>
  41198f:	test   r12,r12
  411992:	je     411a47 <__swc_fn_585f006d_000167_bcc835b8+0x167>
  411998:	mov    al,BYTE PTR [rbx+0x1]
  41199b:	test   al,al
  41199d:	je     411b5e <__swc_fn_585f006d_000167_bcc835b8+0x27e>
  4119a3:	mov    eax,DWORD PTR [rbx+0x28]
  4119a6:	cmp    DWORD PTR [r12+0x20],eax
  4119ab:	jne    411b5e <__swc_fn_585f006d_000167_bcc835b8+0x27e>
  4119b1:	mov    rax,QWORD PTR [r12]
  4119b5:	mov    rcx,QWORD PTR [r12+0x8]
  4119ba:	cmp    QWORD PTR [rbx+0x20],rcx
  4119be:	jne    411b5e <__swc_fn_585f006d_000167_bcc835b8+0x27e>
  4119c4:	mov    cl,0x1
  4119c6:	test   rax,rax
  4119c9:	je     411a32 <__swc_fn_585f006d_000167_bcc835b8+0x152>
  4119cf:	mov    rdx,QWORD PTR [rbx+0x20]
  4119d3:	xor    r8d,r8d
  4119d6:	test   rdx,rdx
  4119d9:	jbe    411a32 <__swc_fn_585f006d_000167_bcc835b8+0x152>
  4119db:	mov    r9,QWORD PTR [rbx+0x18]
  4119df:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  4119e4:	cs nop WORD PTR [rax+rax*1+0x0]
  4119ee:	xchg   ax,ax
  4119f0:	mov    r10b,BYTE PTR [rax+r8*1]
  4119f4:	cmp    BYTE PTR [r9+r8*1],r10b
  4119f8:	je     411a29 <__swc_fn_585f006d_000167_bcc835b8+0x149>
  4119fa:	vmovq  r10,xmm0
  4119ff:	cmp    BYTE PTR [r10+r8*1],0x5c
  411a04:	jne    411a0d <__swc_fn_585f006d_000167_bcc835b8+0x12d>
  411a06:	cmp    BYTE PTR [rax+r8*1],0x2f
  411a0b:	je     411a29 <__swc_fn_585f006d_000167_bcc835b8+0x149>
  411a0d:	vmovq  r10,xmm0
  411a12:	cmp    BYTE PTR [r10+r8*1],0x2f
  411a17:	jne    411a20 <__swc_fn_585f006d_000167_bcc835b8+0x140>
  411a19:	cmp    BYTE PTR [rax+r8*1],0x5c
  411a1e:	je     411a29 <__swc_fn_585f006d_000167_bcc835b8+0x149>
  411a20:	xor    eax,eax
  411a22:	movzx  eax,al
  411a25:	mov    cl,al
  411a27:	jmp    411a32 <__swc_fn_585f006d_000167_bcc835b8+0x152>
  411a29:	add    r8,0x1
  411a2d:	cmp    r8,rdx
  411a30:	jb     4119f0 <__swc_fn_585f006d_000167_bcc835b8+0x110>
  411a32:	test   cl,cl
  411a34:	je     411b5e <__swc_fn_585f006d_000167_bcc835b8+0x27e>
  411a3a:	mov    eax,0x1
  411a3f:	mov    r13b,al
  411a42:	jmp    411b5e <__swc_fn_585f006d_000167_bcc835b8+0x27e>
  411a47:	mov    r13b,0x1
  411a4a:	sub    rsp,0x20
  411a4e:	mov    rax,rsp
  411a51:	lea    rcx,[rdi+0x8]
  411a55:	mov    QWORD PTR [rax],rcx
  411a58:	lea    rsi,[rip+0x6d1]        # 412130 <__swc_rdata_base_585f006d+0x20>
  411a5f:	mov    QWORD PTR [rax+0x8],rsi
  411a63:	mov    QWORD PTR [rax+0x10],rsp
  411a67:	mov    QWORD PTR [rax+0x18],0x1
  411a6f:	lea    rcx,[rsp+0x10]
  411a74:	sub    rsp,0x8
  411a78:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  411a7d:	add    rsp,0x8
  411a81:	add    rsp,0x20
  411a85:	mov    al,BYTE PTR [rbx+0x1]
  411a88:	test   al,al
  411a8a:	je     411b27 <__swc_fn_585f006d_000167_bcc835b8+0x247>
  411a90:	lea    rax,[rip+0xef1]        # 412988 <__swc_rdata_base_585f006d+0x878>
  411a97:	sub    rsp,0x20
  411a9b:	mov    rcx,rsp
  411a9e:	mov    QWORD PTR [rcx],rax
  411aa1:	mov    QWORD PTR [rcx+0x8],rsi
  411aa5:	mov    QWORD PTR [rcx+0x10],rsp
  411aa9:	mov    QWORD PTR [rcx+0x18],0x1
  411ab1:	lea    rcx,[rsp+0x10]
  411ab6:	sub    rsp,0x8
  411aba:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  411abf:	add    rsp,0x8
  411ac3:	add    rsp,0x20
  411ac7:	mov    eax,DWORD PTR [rbx+0x28]
  411aca:	sub    rsp,0x60
  411ace:	mov    rcx,rsp
  411ad1:	lea    rdx,[rdi+0x18]
  411ad5:	mov    QWORD PTR [rcx+0x18],rdx
  411ad9:	mov    QWORD PTR [rcx+0x20],rsi
  411add:	vmovups XMMWORD PTR [rcx],xmm6
  411ae1:	mov    QWORD PTR [rcx+0x28],rsp
  411ae5:	mov    QWORD PTR [rcx+0x30],rsi
  411ae9:	mov    DWORD PTR [rcx+0x10],eax
  411aec:	lea    rax,[rsp+0x10]
  411af1:	mov    QWORD PTR [rcx+0x38],rax
  411af5:	lea    rax,[rip+0x9a4]        # 4124a0 <__swc_rdata_base_585f006d+0x390>
  411afc:	mov    QWORD PTR [rcx+0x40],rax
  411b00:	lea    rax,[rsp+0x18]
  411b05:	mov    QWORD PTR [rcx+0x48],rax
  411b09:	mov    QWORD PTR [rcx+0x50],0x3
  411b11:	lea    rcx,[rsp+0x48]
  411b16:	sub    rsp,0x8
  411b1a:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  411b1f:	add    rsp,0x8
  411b23:	add    rsp,0x60
  411b27:	lea    rax,[rip+0x5f2]        # 412120 <__swc_rdata_base_585f006d+0x10>
  411b2e:	sub    rsp,0x20
  411b32:	mov    rcx,rsp
  411b35:	mov    QWORD PTR [rcx],rax
  411b38:	mov    QWORD PTR [rcx+0x8],rsi
  411b3c:	mov    QWORD PTR [rcx+0x10],rsp
  411b40:	mov    QWORD PTR [rcx+0x18],0x1
  411b48:	lea    rcx,[rsp+0x10]
  411b4d:	sub    rsp,0x8
  411b51:	call   40a1a0 <__swc_fn_585f006d_000150_6203dca2>
  411b56:	add    rsp,0x8
  411b5a:	add    rsp,0x20
  411b5e:	add    r15,0x1
  411b62:	cmp    r15,r14
  411b65:	jae    411b7e <__swc_fn_585f006d_000167_bcc835b8+0x29e>
  411b67:	mov    rsi,QWORD PTR [rsp+0x30]
  411b6c:	mov    rdi,QWORD PTR [rsp+0x38]
  411b71:	mov    rax,r14
  411b74:	mov    r14,QWORD PTR [rsp+0x48]
  411b79:	jmp    411940 <__swc_fn_585f006d_000167_bcc835b8+0x60>
  411b7e:	add    rsp,0x50
  411b82:	vmovups xmm6,XMMWORD PTR [rsp]
  411b87:	add    rsp,0x10
  411b8b:	pop    r15
  411b8d:	pop    r14
  411b8f:	pop    r13
  411b91:	pop    r12
  411b93:	pop    rdi
  411b94:	pop    rsi
  411b95:	pop    rbx
  411b96:	pop    rbp
  411b97:	ret
	...

0000000000411ba0 <__swc_fn_585f006d_000170_646fdf20>:
  411ba0:	sub    rsp,0x8
  411ba4:	call   409bb0 <__swc_fn_585f006d_000129_4bbe3f14>
  411ba9:	add    rsp,0x8
  411bad:	ret
	...

0000000000411bb0 <__swc_fn_585f006d_000173_1e0ea8cf>:
  411bb0:	push   rsi
  411bb1:	sub    rsp,0x30
  411bb5:	lea    rsi,[rip+0x141dc]        # 425d98 <__swc_bss_base_585f006d+0x2d58>
  411bbc:	mov    rax,QWORD PTR [rsi]
  411bbf:	test   rax,rax
  411bc2:	je     411bca <__swc_fn_585f006d_000173_1e0ea8cf+0x1a>
  411bc4:	add    rsp,0x30
  411bc8:	pop    rsi
  411bc9:	ret
  411bca:	mov    ecx,0x2
  411bcf:	mov    edx,0x8020
  411bd4:	call   409250 <__swc_fn_585f006d_000111_6814119b>
  411bd9:	test   rax,rax
  411bdc:	jne    411bed <__swc_fn_585f006d_000173_1e0ea8cf+0x3d>
  411bde:	mov    QWORD PTR [rsp+0x18],rax
  411be3:	call   411050 <__swc_fn_585f006d_000122_be2e2f68>
  411be8:	mov    rax,QWORD PTR [rsp+0x18]
  411bed:	mov    rcx,rax
  411bf0:	xchg   QWORD PTR [rsi],rcx
  411bf3:	add    rsp,0x30
  411bf7:	pop    rsi
  411bf8:	ret
  411bf9:	add    BYTE PTR [rax],al
  411bfb:	add    BYTE PTR [rax],al
  411bfd:	add    BYTE PTR [rax],al
	...

0000000000411c00 <__swc_fn_585f006d_000176_4de704de>:
  411c00:	push   rsi
  411c01:	test   r8,r8
  411c04:	jne    411c08 <__swc_fn_585f006d_000176_4de704de+0x8>
  411c06:	pop    rsi
  411c07:	ret
  411c08:	lea    rax,[rcx+0x18]
  411c0c:	mov    r10,QWORD PTR [rax]
  411c0f:	lea    r11,[r10+0x1]
  411c13:	mov    QWORD PTR [rax],r11
  411c16:	mov    r11,rdx
  411c19:	not    rdx
  411c1c:	lea    rsi,[r8-0x1]
  411c20:	cmp    rsi,rdx
  411c23:	ja     411c43 <__swc_fn_585f006d_000176_4de704de+0x43>
  411c25:	lea    rdx,[r11+r8*1]
  411c29:	dec    rdx
  411c2c:	shr    rdx,0x6
  411c30:	mov    r8,r11
  411c33:	shr    r8,0x6
  411c37:	mov    rsi,rdx
  411c3a:	sub    rsi,r8
  411c3d:	cmp    rsi,0x8
  411c41:	jb     411c59 <__swc_fn_585f006d_000176_4de704de+0x59>
  411c43:	lea    rcx,[rcx+0x10]
  411c47:	mov    rdx,QWORD PTR [rcx]
  411c4a:	add    rdx,r9
  411c4d:	mov    QWORD PTR [rcx],rdx
  411c50:	lea    rcx,[r10+0x2]
  411c54:	mov    QWORD PTR [rax],rcx
  411c57:	pop    rsi
  411c58:	ret
  411c59:	shr    r11,0x6
  411c5d:	nop    DWORD PTR [rax]
  411c60:	cmp    r11,rdx
  411c63:	ja     411ca3 <__swc_fn_585f006d_000176_4de704de+0xa3>
  411c65:	jmp    411c76 <__swc_fn_585f006d_000176_4de704de+0x76>
  411c67:	nop    WORD PTR [rax+rax*1+0x0]
  411c70:	add    r11,0x1
  411c74:	jmp    411c60 <__swc_fn_585f006d_000176_4de704de+0x60>
  411c76:	mov    r8,r11
  411c79:	shr    r8,0xc
  411c7d:	mov    rsi,r11
  411c80:	xor    rsi,r8
  411c83:	mov    r8,r11
  411c86:	shr    r8,0x18
  411c8a:	xor    rsi,r8
  411c8d:	and    esi,0xfff
  411c93:	lea    r8,[rcx+rsi*8+0x20]
  411c98:	mov    rsi,QWORD PTR [r8]
  411c9b:	add    rsi,r9
  411c9e:	mov    QWORD PTR [r8],rsi
  411ca1:	jmp    411c70 <__swc_fn_585f006d_000176_4de704de+0x70>
  411ca3:	lea    rcx,[r10+0x2]
  411ca7:	mov    QWORD PTR [rax],rcx
  411caa:	pop    rsi
  411cab:	ret
