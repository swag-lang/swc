	.file	"llvm-zero-store.cpp"
	.intel_syntax noprefix
	.text
	.p2align 4
	.globl	zero96
	.type	zero96, @function
zero96:
.LFB0:
	.cfi_startproc
	vpxor	xmm0, xmm0, xmm0
	vmovdqu	YMMWORD PTR [rdi], ymm0
	vmovdqu	YMMWORD PTR 32[rdi], ymm0
	vmovdqu	YMMWORD PTR 64[rdi], ymm0
	vzeroupper
	ret
	.cfi_endproc
.LFE0:
	.size	zero96, .-zero96
	.ident	"GCC: (Debian 14.2.0-19) 14.2.0"
	.section	.note.GNU-stack,"",@progbits
