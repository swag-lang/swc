
/workspace/prompt2-20261115/batch5-final-micro/new/binarytrees/binarytrees:     file format elf64-x86-64


Disassembly of section .text:

000000000040e9e0 <__swc_fn_7dafa2b1_000002_6e6aee58>:
  40e9e0:	push   rbx
  40e9e1:	sub    rsp,0x80
  40e9e8:	mov    rax,rcx
  40e9eb:	mov    rcx,QWORD PTR [rax]
  40e9ee:	test   rcx,rcx
  40e9f1:	je     40ea10 <__swc_fn_7dafa2b1_000002_6e6aee58+0x30>
  40e9f3:	mov    QWORD PTR [rsp+0x68],rax
  40e9f8:	call   40e9e0 <__swc_fn_7dafa2b1_000002_6e6aee58>
  40e9fd:	mov    rax,QWORD PTR [rsp+0x68]
  40ea02:	mov    rcx,QWORD PTR [rax+0x8]
  40ea06:	call   40e9e0 <__swc_fn_7dafa2b1_000002_6e6aee58>
  40ea0b:	mov    rax,QWORD PTR [rsp+0x68]
  40ea10:	test   rax,rax
  40ea13:	je     40ea76 <__swc_fn_7dafa2b1_000002_6e6aee58+0x96>
  40ea15:	vxorps xmm0,xmm0,xmm0
  40ea19:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40ea1f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40ea25:	vzeroupper
  40ea28:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40ea2e:	lea    rcx,[rax-0x10]
  40ea32:	mov    QWORD PTR [rsp+0x48],rcx
  40ea37:	mov    rax,QWORD PTR [rax-0x10]
  40ea3b:	mov    QWORD PTR [rsp+0x50],rax
  40ea40:	mov    rcx,QWORD PTR [rip+0x145f9]        # 423040 <__swc_bss_base_7dafa2b1>
  40ea47:	test   rcx,rcx
  40ea4a:	jne    40ea5c <__swc_fn_7dafa2b1_000002_6e6aee58+0x7c>
  40ea4c:	call   4119a0 <__swc_fn_7dafa2b1_000170_994c8876>
  40ea51:	lea    rcx,[rax+0x1]
  40ea55:	mov    QWORD PTR [rip+0x145e4],rcx        # 423040 <__swc_bss_base_7dafa2b1>
  40ea5c:	dec    rcx
  40ea5f:	call   40e840 <__swc_fn_7dafa2b1_000172_360af05d>
  40ea64:	mov    rcx,QWORD PTR [rax]
  40ea67:	lea    rdx,[rsp+0x8]
  40ea6c:	mov    rbx,QWORD PTR [rax+0x8]
  40ea70:	mov    rbx,QWORD PTR [rbx+0x18]
  40ea74:	call   rbx
  40ea76:	add    rsp,0x80
  40ea7d:	pop    rbx
  40ea7e:	ret
