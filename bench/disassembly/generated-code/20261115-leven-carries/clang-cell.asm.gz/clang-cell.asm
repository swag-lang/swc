    1ca0:	31 ff                	xor    edi,edi
    1ca2:	3a 44 35 00          	cmp    al,BYTE PTR [rbp+rsi*1+0x0]
    1ca6:	40 0f 95 c7          	setne  dil
    1caa:	48 01 d7             	add    rdi,rdx
    1cad:	48 8b 54 f4 68       	mov    rdx,QWORD PTR [rsp+rsi*8+0x68]
    1cb2:	4c 8d 42 01          	lea    r8,[rdx+0x1]
    1cb6:	49 39 f8             	cmp    r8,rdi
    1cb9:	49 0f 42 f8          	cmovb  rdi,r8
    1cbd:	48 ff c1             	inc    rcx
    1cc0:	48 39 f9             	cmp    rcx,rdi
    1cc3:	48 0f 43 cf          	cmovae rcx,rdi
    1cc7:	48 89 8c f4 68 02 00 	mov    QWORD PTR [rsp+rsi*8+0x268],rcx
    1cce:	00 
    1ccf:	48 8d 7e 01          	lea    rdi,[rsi+0x1]
    1cd3:	48 89 fe             	mov    rsi,rdi
    1cd6:	49 39 fd             	cmp    r13,rdi
    1cd9:	75 c5                	jne    1ca0 <main+0x9f0>
