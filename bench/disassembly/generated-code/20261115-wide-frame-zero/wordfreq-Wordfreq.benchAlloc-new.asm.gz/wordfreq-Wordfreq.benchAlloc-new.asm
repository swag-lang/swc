
/workspace/prompt2-20261115/batch5-final-micro/new/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

000000000040a7e0 <__swc_fn_4fa09e82_000001_2744b483>:
  40a7e0:	push   rbx
  40a7e1:	sub    rsp,0x70
  40a7e5:	cmp    rcx,0xffffffffffffffef
  40a7e9:	jbe    40a7f3 <__swc_fn_4fa09e82_000001_2744b483+0x13>
  40a7eb:	xor    eax,eax
  40a7ed:	add    rsp,0x70
  40a7f1:	pop    rbx
  40a7f2:	ret
  40a7f3:	vxorps xmm0,xmm0,xmm0
  40a7f7:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40a7fd:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40a803:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  40a809:	vzeroupper
  40a80c:	lea    rax,[rcx+0x10]
  40a810:	mov    QWORD PTR [rsp+0x50],rax
  40a815:	mov    DWORD PTR [rsp+0x60],0x10
  40a81d:	mov    rcx,QWORD PTR [rip+0x1981c]        # 424040 <__swc_bss_base_4fa09e82>
  40a824:	test   rcx,rcx
  40a827:	jne    40a839 <__swc_fn_4fa09e82_000001_2744b483+0x59>
  40a829:	call   40a620 <__swc_fn_4fa09e82_000171_994c8876>
  40a82e:	lea    rcx,[rax+0x1]
  40a832:	mov    QWORD PTR [rip+0x19807],rcx        # 424040 <__swc_bss_base_4fa09e82>
  40a839:	dec    rcx
  40a83c:	call   412180 <__swc_fn_4fa09e82_000173_360af05d>
  40a841:	mov    rcx,QWORD PTR [rax]
  40a844:	lea    rdx,[rsp+0x8]
  40a849:	mov    rbx,QWORD PTR [rax+0x8]
  40a84d:	mov    rbx,QWORD PTR [rbx+0x8]
  40a851:	call   rbx
  40a853:	mov    rax,QWORD PTR [rsp+0x48]
  40a858:	test   rax,rax
  40a85b:	jne    40a865 <__swc_fn_4fa09e82_000001_2744b483+0x85>
  40a85d:	xor    eax,eax
  40a85f:	add    rsp,0x70
  40a863:	pop    rbx
  40a864:	ret
  40a865:	mov    rcx,QWORD PTR [rsp+0x50]
  40a86a:	mov    QWORD PTR [rax],rcx
  40a86d:	mov    QWORD PTR [rax+0x8],0x0
  40a875:	lea    rax,[rax+0x10]
  40a879:	add    rsp,0x70
  40a87d:	pop    rbx
  40a87e:	ret
