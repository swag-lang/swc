# Field Notes Toolkit

A small generated project bundle for field survey teams.

## Contents

- `config/sites.json` defines three fictional survey locations.
- `data/observations.csv` records sample readings.
- `docs/handling.md` explains the generated file layout.
- `src/catalog.json` describes the viewer used to inspect the bundle.

All names and measurements are fictional and generated for this repository.
