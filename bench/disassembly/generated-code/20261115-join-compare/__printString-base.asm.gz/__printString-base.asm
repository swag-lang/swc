
/workspace/prompt2-20261115/batch4-final-micro/base/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .text:

00000000004098c0 <__swc_fn_4fa09e82_000117_79691377>:
  4098c0:	push   r12
  4098c2:	push   r13
  4098c4:	push   r14
  4098c6:	push   rdi
  4098c7:	push   rsi
  4098c8:	sub    rsp,0xc0
  4098cf:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4098d5:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4098db:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4098e1:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4098e7:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4098ed:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4098f3:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4098f9:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409902:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40990b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409914:	mov    r12,QWORD PTR [rcx]
  409917:	test   r12,r12
  40991a:	jne    40992c <__swc_fn_4fa09e82_000117_79691377+0x6c>
  40991c:	add    rsp,0xc0
  409923:	pop    rsi
  409924:	pop    rdi
  409925:	pop    r14
  409927:	pop    r13
  409929:	pop    r12
  40992b:	ret
  40992c:	xor    r13d,r13d
  40992f:	mov    r14,QWORD PTR [rcx+0x8]
  409933:	cs nop WORD PTR [rax+rax*1+0x0]
  40993d:	nop    DWORD PTR [rax]
  409940:	cmp    r13,r14
  409943:	jae    40997e <__swc_fn_4fa09e82_000117_79691377+0xbe>
  409945:	lea    rax,[r12+r13*1]
  409949:	mov    rcx,r14
  40994c:	sub    rcx,r13
  40994f:	mov    edi,0x1
  409954:	mov    rsi,rax
  409957:	mov    rdx,rcx
  40995a:	xor    eax,eax
  40995c:	call   407100 <write@plt>
  409961:	test   rax,rax
  409964:	jle    40996b <__swc_fn_4fa09e82_000117_79691377+0xab>
  409966:	add    r13,rax
  409969:	jmp    409940 <__swc_fn_4fa09e82_000117_79691377+0x80>
  40996b:	test   rax,rax
  40996e:	je     40997c <__swc_fn_4fa09e82_000117_79691377+0xbc>
  409970:	xor    eax,eax
  409972:	call   407030 <__errno_location@plt>
  409977:	cmp    DWORD PTR [rax],0x4
  40997a:	je     409940 <__swc_fn_4fa09e82_000117_79691377+0x80>
  40997c:	jmp    40997e <__swc_fn_4fa09e82_000117_79691377+0xbe>
  40997e:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409984:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40998a:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409990:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409996:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40999c:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4099a2:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4099a8:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4099b1:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4099ba:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4099c3:	add    rsp,0xc0
  4099ca:	pop    rsi
  4099cb:	pop    rdi
  4099cc:	pop    r14
  4099ce:	pop    r13
  4099d0:	pop    r12
  4099d2:	ret
