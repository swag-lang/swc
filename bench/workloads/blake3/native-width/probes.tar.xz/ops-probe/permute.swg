#global private
#global #[Swag.Safety(.Overflow, false)]

alias U32x8 = #simd [8] u32

#[Swag.NoInline]
func transform(input, pattern: const [*] u32, output: [*] u32, seed: u32, count: u8)
{
    const SameHalves = cast(U32x8, [1'u32, 3, 0, 2, 5, 7, 4, 6])
    const Mask = cast(U32x8, [0xff00ff00'u32, 0xffff, 0xee00ee00, 0xdeadbeef,
                            0x00ff00ff, 0xff000000, 0xff00, 0xabcd1234])
    let words = cast(const [*] U32x8, input)
    let plans = cast(const [*] U32x8, pattern)
    let result = cast([*] U32x8, output)
    var seeds: [8] u32
    for lane in 8 do
        seeds[lane] = seed
    let broadcast = cast(const *U32x8, &seeds)[]
    result[0] = Swag.vecShuffle(words[0], SameHalves)
    result[1] = Swag.vecShuffle(words[0], plans[0])
    result[2] = (Swag.ror(words[0] ^ broadcast, 16) + Swag.rol(words[0], 8)) & Mask
    result[3] = Swag.ror(words[0], count)
    result[4] = Swag.rol(words[0], 32)
}

#main
{
    const First = [1'u32, 3, 0, 2, 5, 7, 4, 6]
    const Mask = [0xff00ff00'u32, 0xffff, 0xee00ee00, 0xdeadbeef,
                  0x00ff00ff, 0xff000000, 0xff00, 0xabcd1234]
    var input: [8] u32
    var pattern: [8] u32 = [7, 0, 4, 1, 6, 3, 5, 2]
    var output: [40] u32
    for index in 8 do
        input[index] = cast(u32, index) * 0x9e3779b9'u32 + 0xb7e15163'u32

    const Seed = 0x105b4631'u32
    for count in [0'u8, 5, 31, 32, 67]
    {
        transform(&input[0], &pattern[0], &output[0], Seed, count)
        for lane in 8
        {
            let item = input[lane]
            Swag.require(output[lane] == input[First[lane]])
            Swag.require(output[8 + lane] == input[pattern[lane]])
            Swag.require(output[16 + lane] == ((Swag.ror(item ^ Seed, 16) + Swag.rol(item, 8)) & Mask[lane]))
            Swag.require(output[24 + lane] == Swag.ror(item, count))
            Swag.require(output[32 + lane] == item)
        }
    }
}
