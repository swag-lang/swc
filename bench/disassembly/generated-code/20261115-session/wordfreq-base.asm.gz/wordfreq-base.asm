
/workspace/prompt2-20261115/session-combined-micro/base/wordfreq/wordfreq:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <open@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <open@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <flock@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <flock@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <__errno_location@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <__errno_location@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <close@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <close@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <getpid@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <getpid@GLIBC_2.2.5>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <opendir@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <opendir@GLIBC_2.2.5>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <dirfd@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <dirfd@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <readdir@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <readdir@GLIBC_2.2.5>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <readlinkat@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <readlinkat@GLIBC_2.4>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <openat@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <openat@GLIBC_2.4>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <closedir@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <closedir@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <lseek@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <lseek@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <mmap@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <mmap@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <memfd_create@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf92]        # 413078 <memfd_create@GLIBC_2.27>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <ftruncate@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf8a]        # 413080 <ftruncate@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <write@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf82]        # 413088 <write@GLIBC_2.2.5>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <backtrace@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf7a]        # 413090 <backtrace@GLIBC_2.2.5>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <pthread_setspecific@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf72]        # 413098 <pthread_setspecific@GLIBC_2.34>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <clock_gettime@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf6a]        # 4130a0 <clock_gettime@GLIBC_2.17>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <__x86_get_cpuid_feature_leaf@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf62]        # 4130a8 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <free@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf5a]        # 4130b0 <free@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <munmap@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <munmap@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <mprotect@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <mprotect@GLIBC_2.2.5>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <exit@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <exit@GLIBC_2.2.5>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <pthread_key_create@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <pthread_key_create@GLIBC_2.34>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <syscall@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <syscall@GLIBC_2.2.5>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <dladdr@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <dladdr@GLIBC_2.34>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <malloc@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <malloc@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <madvise@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <madvise@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <pthread_key_delete@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <pthread_key_delete@GLIBC_2.34>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <gettid@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <gettid@GLIBC_2.30>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_4fa09e82_000179_6937fe70+0xe50>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   411560 <__swc_fn_4fa09e82_000122_12b4ed22>
  40724e:	xor    ecx,ecx
  407250:	call   40dd60 <__swc_fn_4fa09e82_000094_14db3cf9>
  407255:	call   40b920 <__swc_fn_4fa09e82_000180_913db40c>
  40725a:	call   410bb0 <__swc_fn_4fa09e82_000095_337e587a>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_4fa09e82_000000_46f18a51>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_4fa09e82_000003_7ab4792e>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_4fa09e82_000003_7ab4792e+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   40e180 <__swc_fn_4fa09e82_000112_b25e3a45>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_4fa09e82_000003_7ab4792e+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1cd81]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1cd7a]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_4fa09e82_000003_7ab4792e+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_4fa09e82_000003_7ab4792e+0x30>
  4072e6:	lea    rcx,[rip+0x1cd63]        # 424050 <__swc_bss_base_4fa09e82+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1cd5c]        # 424050 <__swc_bss_base_4fa09e82+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_4fa09e82_000003_7ab4792e+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_4fa09e82_000003_7ab4792e+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_4fa09e82_000006_a23dca5f>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40f460 <__swc_fn_4fa09e82_000011_6493fbbc>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_4fa09e82_000012_c7df5d22>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_4fa09e82_000006_a23dca5f+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_4fa09e82_000003_7ab4792e>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_4fa09e82_000006_a23dca5f+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_4fa09e82_000009_d7e2bb25>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_4fa09e82_000009_d7e2bb25+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40c0f0 <__swc_fn_4fa09e82_000007_614a4804>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40f450 <__swc_fn_4fa09e82_000008_4e857afc>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_4fa09e82_000009_d7e2bb25+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_4fa09e82_000009_d7e2bb25+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_4fa09e82_000012_c7df5d22>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_4fa09e82_000015_07eb9884>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_4fa09e82_000015_07eb9884+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_4fa09e82_000015_07eb9884+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_4fa09e82_000015_07eb9884+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_4fa09e82_000015_07eb9884+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40f5c0 <__swc_fn_4fa09e82_000017_4df2d1a0>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_4fa09e82_000015_07eb9884+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1cb3d]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1cb36]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_4fa09e82_000015_07eb9884+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_4fa09e82_000015_07eb9884+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40f460 <__swc_fn_4fa09e82_000011_6493fbbc>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_4fa09e82_000015_07eb9884+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   411270 <__swc_fn_4fa09e82_000113_759e9ceb>
  407569:	lea    rcx,[rip+0x1cad8]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1cad1]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_4fa09e82_000015_07eb9884+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_4fa09e82_000015_07eb9884+0x110>
  407598:	lea    rcx,[rip+0x1cac1]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1caba]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_4fa09e82_000015_07eb9884+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_4fa09e82_000015_07eb9884+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_4fa09e82_000018_7d1e8a10>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_4fa09e82_000015_07eb9884+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_4fa09e82_000018_7d1e8a10>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_4fa09e82_000018_7d1e8a10+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_4fa09e82_000018_7d1e8a10+0x10>

0000000000407630 <__swc_fn_4fa09e82_000021_491ac000>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_4fa09e82_000015_07eb9884>
  40763e:	lea    rdi,[rip+0x1cbab]        # 4241f0 <__swc_bss_base_4fa09e82+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   40e7e0 <__swc_fn_4fa09e82_000136_e3032dc2>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1cb94]        # 4241f8 <__swc_bss_base_4fa09e82+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1cb89],rsi        # 4241f8 <__swc_bss_base_4fa09e82+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_4fa09e82_000024_4aca8b9e>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_4fa09e82_000027_4aca8b9e>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_4fa09e82_000030_06a93956>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_4fa09e82_000030_06a93956+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1a92c]        # 422000 <__swc_data_base_4fa09e82>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_4fa09e82_000030_06a93956+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_4fa09e82_000030_06a93956+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_4fa09e82_000030_06a93956+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40f780 <__swc_fn_4fa09e82_000032_84881cd8>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_4fa09e82_000030_06a93956+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_4fa09e82_000036_8d895ba1>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_4fa09e82_000030_06a93956+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_4fa09e82_000042_bab03645>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_4fa09e82_000033_7ca1566d>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40c5a0 <__swc_fn_4fa09e82_000031_90860ff2>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   40e660 <__swc_fn_4fa09e82_000130_74b163fe>
  407734:	mov    rcx,rsi
  407737:	call   40f780 <__swc_fn_4fa09e82_000032_84881cd8>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_4fa09e82_000036_8d895ba1>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_4fa09e82_000039_40d1e569>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_4fa09e82_000039_40d1e569+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_4fa09e82_000039_40d1e569+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_4fa09e82_000039_40d1e569+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_4fa09e82_000039_40d1e569+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_4fa09e82_000039_40d1e569+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   40e260 <__swc_fn_4fa09e82_000115_27d95464>
  4077ca:	lea    rcx,[rip+0x1c877]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1c870]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_4fa09e82_000039_40d1e569+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_4fa09e82_000039_40d1e569+0x90>
  4077f8:	lea    rcx,[rip+0x1c861]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1c85a]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_4fa09e82_000039_40d1e569+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_4fa09e82_000039_40d1e569+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_4fa09e82_000042_bab03645>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_4fa09e82_000042_bab03645+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40fd50 <__swc_fn_4fa09e82_000059_3ca3ac64>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   40e7e0 <__swc_fn_4fa09e82_000136_e3032dc2>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_4fa09e82_000042_bab03645+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_4fa09e82_000042_bab03645+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_4fa09e82_000009_d7e2bb25>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_4fa09e82_000042_bab03645+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40f480 <__swc_fn_4fa09e82_000014_afb279e2>
  40791e:	jmp    407941 <__swc_fn_4fa09e82_000042_bab03645+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_4fa09e82_000042_bab03645+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_4fa09e82_000042_bab03645+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_4fa09e82_000042_bab03645+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40c760 <__swc_fn_4fa09e82_000043_957e4917>
  407997:	mov    rcx,rdi
  40799a:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_4fa09e82_000039_40d1e569>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_4fa09e82_000045_1fe0f4e2>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_4fa09e82_000045_1fe0f4e2+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_4fa09e82_000045_1fe0f4e2+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_4fa09e82_000045_1fe0f4e2+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_4fa09e82_000045_1fe0f4e2+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   40e7e0 <__swc_fn_4fa09e82_000136_e3032dc2>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_4fa09e82_000045_1fe0f4e2+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_4fa09e82_000045_1fe0f4e2+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_4fa09e82_000045_1fe0f4e2+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_4fa09e82_000045_1fe0f4e2+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_4fa09e82_000009_d7e2bb25>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_4fa09e82_000045_1fe0f4e2+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_4fa09e82_000045_1fe0f4e2+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_4fa09e82_000045_1fe0f4e2+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_4fa09e82_000045_1fe0f4e2+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_4fa09e82_000045_1fe0f4e2+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40c1a0 <__swc_fn_4fa09e82_000013_9ba72deb>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_4fa09e82_000045_1fe0f4e2+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_4fa09e82_000045_1fe0f4e2+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_4fa09e82_000045_1fe0f4e2+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_4fa09e82_000045_1fe0f4e2+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40f600 <__swc_fn_4fa09e82_000020_a66e8b97>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_4fa09e82_000045_1fe0f4e2+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40c1a0 <__swc_fn_4fa09e82_000013_9ba72deb>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_4fa09e82_000045_1fe0f4e2+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_4fa09e82_000021_491ac000>
  407c07:	mov    rcx,r14
  407c0a:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_4fa09e82_000045_1fe0f4e2+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_4fa09e82_000045_1fe0f4e2+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_4fa09e82_000045_1fe0f4e2+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_4fa09e82_000048_c877e9d2>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_4fa09e82_000048_c877e9d2+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_4fa09e82_000048_c877e9d2+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_4fa09e82_000048_c877e9d2+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_4fa09e82_000048_c877e9d2+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40f9b0 <__swc_fn_4fa09e82_000047_bc5ec610>
  407d14:	jmp    407ce0 <__swc_fn_4fa09e82_000048_c877e9d2+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_4fa09e82_000048_c877e9d2+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_4fa09e82_000048_c877e9d2+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_4fa09e82_000048_c877e9d2+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_4fa09e82_000048_c877e9d2+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_4fa09e82_000048_c877e9d2+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_4fa09e82_000048_c877e9d2+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_4fa09e82_000048_c877e9d2+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_4fa09e82_000051_f7021588>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_4fa09e82_000051_f7021588+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_4fa09e82_000051_f7021588+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_4fa09e82_000051_f7021588+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_4fa09e82_000051_f7021588+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40f910 <__swc_fn_4fa09e82_000044_9c2ade9b>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40f480 <__swc_fn_4fa09e82_000014_afb279e2>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_4fa09e82_000054_ae20ea33>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   40e7e0 <__swc_fn_4fa09e82_000136_e3032dc2>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_4fa09e82_000054_ae20ea33+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_4fa09e82_000054_ae20ea33+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_4fa09e82_000054_ae20ea33+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_4fa09e82_000057_5b81d8b6>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_4fa09e82_000060_e6407a0a>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_4fa09e82_000060_e6407a0a+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_4fa09e82_000039_40d1e569>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_4fa09e82_000060_e6407a0a+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_4fa09e82_000063_c8a062d6>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40cae0 <__swc_fn_4fa09e82_000052_c7484fb0>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_4fa09e82_000054_ae20ea33>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_4fa09e82_000063_c8a062d6+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_4fa09e82_000063_c8a062d6+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40cc00 <__swc_fn_4fa09e82_000058_8bd8d1d5>
  407f7f:	mov    rcx,rsi
  407f82:	call   40c840 <__swc_fn_4fa09e82_000049_2ff013cc>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_4fa09e82_000066_254b71af>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_4fa09e82_000066_254b71af+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1c049]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1c04b]        # 424080 <__swc_bss_base_4fa09e82+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_4fa09e82_000066_254b71af+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_4fa09e82_000066_254b71af+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40c4d0 <__swc_fn_4fa09e82_000022_3a2e2048>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_4fa09e82_000066_254b71af+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_4fa09e82_000063_c8a062d6>
  40808f:	jmp    408122 <__swc_fn_4fa09e82_000066_254b71af+0x192>
  408094:	lea    rax,[rip+0x19f65]        # 422000 <__swc_data_base_4fa09e82>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_4fa09e82_000066_254b71af+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_4fa09e82_000066_254b71af+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_4fa09e82_000066_254b71af+0x135>
  4080b8:	call   40c5a0 <__swc_fn_4fa09e82_000031_90860ff2>
  4080bd:	mov    rcx,rax
  4080c0:	call   409c00 <__swc_fn_4fa09e82_000129_41c3251c>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_4fa09e82_000066_254b71af+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_4fa09e82_000066_254b71af+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_4fa09e82_000066_254b71af+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40f9b0 <__swc_fn_4fa09e82_000047_bc5ec610>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_4fa09e82_000066_254b71af+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_4fa09e82_000051_f7021588>
  408115:	jmp    408122 <__swc_fn_4fa09e82_000066_254b71af+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40c110 <__swc_fn_4fa09e82_000010_395bb04b>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_4fa09e82_000069_e681a956>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_4fa09e82_000036_8d895ba1>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_4fa09e82_000069_e681a956+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1c09a]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_4fa09e82_000069_e681a956+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   40e7e0 <__swc_fn_4fa09e82_000136_e3032dc2>
  4081b5:	mov    rcx,rsi
  4081b8:	call   410180 <__swc_fn_4fa09e82_000068_7d4c42bf>
  4081bd:	mov    rcx,rsi
  4081c0:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_4fa09e82_000072_bfa08900>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40fed0 <__swc_fn_4fa09e82_000065_f9f4b610>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_4fa09e82_000075_524b0734>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   410180 <__swc_fn_4fa09e82_000068_7d4c42bf>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_4fa09e82_000078_a120bd2b>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_4fa09e82_000078_a120bd2b+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_4fa09e82_000078_a120bd2b+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_4fa09e82_000081_c25a0e73>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_4fa09e82_000084_ddf2b8a1>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_4fa09e82_000090_a2d50c23>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_4fa09e82_000084_ddf2b8a1+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_4fa09e82_000084_ddf2b8a1+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_4fa09e82_000084_ddf2b8a1+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_4fa09e82_000084_ddf2b8a1+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_4fa09e82_000090_a2d50c23>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_4fa09e82_000084_ddf2b8a1+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_4fa09e82_000084_ddf2b8a1+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_4fa09e82_000084_ddf2b8a1+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_4fa09e82_000084_ddf2b8a1+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_4fa09e82_000084_ddf2b8a1+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_4fa09e82_000084_ddf2b8a1+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_4fa09e82_000084_ddf2b8a1+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_4fa09e82_000084_ddf2b8a1+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_4fa09e82_000084_ddf2b8a1+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_4fa09e82_000084_ddf2b8a1+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40dbe0 <__swc_fn_4fa09e82_000082_754dcd57>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_4fa09e82_000084_ddf2b8a1+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_4fa09e82_000084_ddf2b8a1+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_4fa09e82_000084_ddf2b8a1+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40dbe0 <__swc_fn_4fa09e82_000082_754dcd57>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_4fa09e82_000084_ddf2b8a1+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_4fa09e82_000084_ddf2b8a1>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_4fa09e82_000084_ddf2b8a1+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_4fa09e82_000084_ddf2b8a1+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_4fa09e82_000087_ea575bb3>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_4fa09e82_000090_a2d50c23>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_4fa09e82_000087_ea575bb3+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   4105e0 <__swc_fn_4fa09e82_000086_c45095aa>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_4fa09e82_000087_ea575bb3+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_4fa09e82_000087_ea575bb3+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_4fa09e82_000087_ea575bb3+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40dbe0 <__swc_fn_4fa09e82_000082_754dcd57>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_4fa09e82_000087_ea575bb3+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_4fa09e82_000087_ea575bb3>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_4fa09e82_000087_ea575bb3+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_4fa09e82_000087_ea575bb3+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_4fa09e82_000090_a2d50c23>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_4fa09e82_000090_a2d50c23+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_4fa09e82_000090_a2d50c23+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_4fa09e82_000090_a2d50c23+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_4fa09e82_000090_a2d50c23+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40dbe0 <__swc_fn_4fa09e82_000082_754dcd57>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40dbe0 <__swc_fn_4fa09e82_000082_754dcd57>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_4fa09e82_000090_a2d50c23+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_4fa09e82_000090_a2d50c23+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_4fa09e82_000090_a2d50c23+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_4fa09e82_000090_a2d50c23+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_4fa09e82_000090_a2d50c23>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_4fa09e82_000090_a2d50c23+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_4fa09e82_000090_a2d50c23+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_4fa09e82_000090_a2d50c23+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_4fa09e82_000090_a2d50c23+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_4fa09e82_000090_a2d50c23+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_4fa09e82_000090_a2d50c23+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_4fa09e82_000090_a2d50c23+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_4fa09e82_000090_a2d50c23+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_4fa09e82_000090_a2d50c23+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_4fa09e82_000090_a2d50c23+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_4fa09e82_000090_a2d50c23+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_4fa09e82_000090_a2d50c23+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_4fa09e82_000090_a2d50c23+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_4fa09e82_000090_a2d50c23+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_4fa09e82_000090_a2d50c23+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_4fa09e82_000090_a2d50c23+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   40ed00 <__swc_fn_4fa09e82_000148_32a497f3>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_4fa09e82_000090_a2d50c23+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_4fa09e82_000090_a2d50c23>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_4fa09e82_000090_a2d50c23+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_4fa09e82_000090_a2d50c23+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_4fa09e82_000090_a2d50c23+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   40ed00 <__swc_fn_4fa09e82_000148_32a497f3>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   40ed00 <__swc_fn_4fa09e82_000148_32a497f3>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_4fa09e82_000093_f8c16535>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40dd10 <__swc_fn_4fa09e82_000091_3d2f5a0d>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_4fa09e82_000093_f8c16535+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_4fa09e82_000093_f8c16535+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   409da0 <__swc_fn_4fa09e82_000138_a4ba10ed>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_4fa09e82_000093_f8c16535+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0xa872]        # 4131c0 <__swc_rdata_base_4fa09e82+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   4098c0 <__swc_fn_4fa09e82_000117_035d76a1>
  408959:	call   4114a0 <__swc_fn_4fa09e82_000119_7f430081>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_4fa09e82_000096_ad982b35>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40896f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408975:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40897b:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  408981:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  408987:	mov    QWORD PTR [rsp+0x48],rdx
  40898c:	mov    rax,r8
  40898f:	cmp    r8,0x1
  408993:	mov    edx,0x1
  408998:	cmovb  rax,rdx
  40899c:	mov    QWORD PTR [rsp+0x50],rax
  4089a1:	mov    rbx,QWORD PTR [rcx+0x8]
  4089a5:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a9:	mov    rcx,QWORD PTR [rcx]
  4089ac:	lea    rdx,[rsp+0x8]
  4089b1:	call   rbx
  4089b3:	add    rsp,0x70
  4089b7:	pop    rbx
  4089b8:	ret
  4089b9:	add    BYTE PTR [rax],al
  4089bb:	add    BYTE PTR [rax],al
  4089bd:	add    BYTE PTR [rax],al
	...

00000000004089c0 <__swc_fn_4fa09e82_000099_b4c6da83>:
  4089c0:	push   rbx
  4089c1:	push   rsi
  4089c2:	push   rdi
  4089c3:	sub    rsp,0x30
  4089c7:	mov    rbx,rcx
  4089ca:	test   rcx,rcx
  4089cd:	je     4089e2 <__swc_fn_4fa09e82_000099_b4c6da83+0x22>
  4089cf:	mov    rcx,rbx
  4089d2:	mov    edx,0x1
  4089d7:	call   408200 <__swc_fn_4fa09e82_000078_a120bd2b>
  4089dc:	cmp    rax,0x1
  4089e0:	je     4089ea <__swc_fn_4fa09e82_000099_b4c6da83+0x2a>
  4089e2:	add    rsp,0x30
  4089e6:	pop    rdi
  4089e7:	pop    rsi
  4089e8:	pop    rbx
  4089e9:	ret
  4089ea:	lea    rsi,[rsp+0x8]
  4089ef:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089f4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089fa:	lea    rax,[rsp+0x18]
  4089ff:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  408a04:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  408a0a:	mov    rcx,QWORD PTR [rsp+0x20]
  408a0f:	test   rcx,rcx
  408a12:	je     408a28 <__swc_fn_4fa09e82_000099_b4c6da83+0x68>
  408a14:	test   DWORD PTR [rcx+0x28],0x400000
  408a1b:	je     408a28 <__swc_fn_4fa09e82_000099_b4c6da83+0x68>
  408a1d:	mov    rdx,QWORD PTR [rcx+0x30]
  408a21:	test   rdx,rdx
  408a24:	cmovne rcx,rdx
  408a28:	mov    edi,DWORD PTR [rcx+0x20]
  408a2b:	mov    rcx,rax
  408a2e:	call   40def0 <__swc_fn_4fa09e82_000100_3ed08774>
  408a33:	mov    rcx,rsi
  408a36:	mov    rdx,QWORD PTR [rsp+0x18]
  408a3b:	mov    r8,rdi
  408a3e:	call   408960 <__swc_fn_4fa09e82_000096_ad982b35>
  408a43:	mov    rcx,QWORD PTR [rbx+0x28]
  408a47:	call   410bc0 <__swc_fn_4fa09e82_000098_00f01091>
  408a4c:	mov    rcx,rsi
  408a4f:	mov    rdx,rbx
  408a52:	mov    r8d,0x30
  408a58:	call   408960 <__swc_fn_4fa09e82_000096_ad982b35>
  408a5d:	add    rsp,0x30
  408a61:	pop    rdi
  408a62:	pop    rsi
  408a63:	pop    rbx
  408a64:	ret
	...

0000000000408a80 <__swc_fn_4fa09e82_000102_e9fdc18e>:
  408a80:	push   rbp
  408a81:	push   rbx
  408a82:	push   rsi
  408a83:	push   rdi
  408a84:	push   r12
  408a86:	push   r13
  408a88:	push   r14
  408a8a:	push   r15
  408a8c:	sub    rsp,0x500
  408a93:	mov    rbp,rsp
  408a96:	mov    rbx,rsp
  408a99:	mov    rsi,rdx
  408a9c:	mov    rdi,rcx
  408a9f:	mov    rcx,QWORD PTR [rip+0x1e29a]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  408aa6:	test   rcx,rcx
  408aa9:	jne    408ac3 <__swc_fn_4fa09e82_000102_e9fdc18e+0x43>
  408aab:	sub    rsp,0x8
  408aaf:	call   40f0f0 <__swc_fn_4fa09e82_000166_cf398896>
  408ab4:	add    rsp,0x8
  408ab8:	lea    rcx,[rax+0x1]
  408abc:	mov    QWORD PTR [rip+0x1e27d],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  408ac3:	dec    rcx
  408ac6:	sub    rsp,0x8
  408aca:	call   40b6c0 <__swc_fn_4fa09e82_000168_fce60b2b>
  408acf:	add    rsp,0x8
  408ad3:	mov    r12,rax
  408ad6:	mov    QWORD PTR [rsp+0x4f0],rax
  408ade:	lea    rax,[rip+0xa81b]        # 413300 <__swc_rdata_base_4fa09e82+0x1f0>
  408ae5:	sub    rsp,0x20
  408ae9:	mov    rcx,rsp
  408aec:	mov    QWORD PTR [rcx],rax
  408aef:	lea    r13,[rip+0xa81a]        # 413310 <__swc_rdata_base_4fa09e82+0x200>
  408af6:	mov    QWORD PTR [rcx+0x8],r13
  408afa:	mov    QWORD PTR [rcx+0x10],rsp
  408afe:	mov    QWORD PTR [rcx+0x18],0x1
  408b06:	lea    rcx,[rsp+0x10]
  408b0b:	sub    rsp,0x8
  408b0f:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  408b14:	add    rsp,0x8
  408b18:	add    rsp,0x20
  408b1c:	lea    rax,[rip+0xa835]        # 413358 <__swc_rdata_base_4fa09e82+0x248>
  408b23:	sub    rsp,0x20
  408b27:	mov    rcx,rsp
  408b2a:	mov    QWORD PTR [rcx],rax
  408b2d:	mov    QWORD PTR [rcx+0x8],r13
  408b31:	mov    QWORD PTR [rcx+0x10],rsp
  408b35:	mov    QWORD PTR [rcx+0x18],0x1
  408b3d:	lea    rcx,[rsp+0x10]
  408b42:	sub    rsp,0x8
  408b46:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  408b4b:	add    rsp,0x8
  408b4f:	add    rsp,0x20
  408b53:	lea    r14,[rip+0xa80e]        # 413368 <__swc_rdata_base_4fa09e82+0x258>
  408b5a:	sub    rsp,0x50
  408b5e:	mov    rax,rsp
  408b61:	vmovups xmm0,XMMWORD PTR [rip+0xa937]        # 4134a0 <__swc_rdata_base_4fa09e82+0x390>
  408b69:	vmovups XMMWORD PTR [rax],xmm0
  408b6d:	mov    QWORD PTR [rax+0x10],rsp
  408b71:	mov    QWORD PTR [rax+0x18],r13
  408b75:	mov    QWORD PTR [rax+0x20],rdi
  408b79:	lea    rdi,[rip+0xa7f8]        # 413378 <__swc_rdata_base_4fa09e82+0x268>
  408b80:	mov    QWORD PTR [rax+0x28],rdi
  408b84:	mov    QWORD PTR [rax+0x30],r14
  408b88:	mov    QWORD PTR [rax+0x38],r13
  408b8c:	lea    rcx,[rsp+0x10]
  408b91:	mov    QWORD PTR [rax+0x40],rcx
  408b95:	mov    QWORD PTR [rax+0x48],0x3
  408b9d:	lea    rcx,[rsp+0x40]
  408ba2:	sub    rsp,0x8
  408ba6:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  408bab:	add    rsp,0x8
  408baf:	add    rsp,0x50
  408bb3:	lea    rax,[rip+0xa806]        # 4133c0 <__swc_rdata_base_4fa09e82+0x2b0>
  408bba:	sub    rsp,0x20
  408bbe:	mov    rcx,rsp
  408bc1:	mov    QWORD PTR [rcx],rax
  408bc4:	mov    QWORD PTR [rcx+0x8],r13
  408bc8:	mov    QWORD PTR [rcx+0x10],rsp
  408bcc:	mov    QWORD PTR [rcx+0x18],0x1
  408bd4:	lea    rcx,[rsp+0x10]
  408bd9:	sub    rsp,0x8
  408bdd:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  408be2:	add    rsp,0x8
  408be6:	add    rsp,0x20
  408bea:	mov    eax,DWORD PTR [rsi+0x20]
  408bed:	mov    ecx,DWORD PTR [rsi+0x24]
  408bf0:	sub    rsp,0xa0
  408bf7:	mov    rdx,rsp
  408bfa:	mov    QWORD PTR [rdx+0x30],rsi
  408bfe:	mov    QWORD PTR [rdx+0x38],rdi
  408c02:	vmovups xmm0,XMMWORD PTR [rip+0xa82e]        # 413438 <__swc_rdata_base_4fa09e82+0x328>
  408c0a:	vmovups XMMWORD PTR [rdx],xmm0
  408c0e:	mov    QWORD PTR [rdx+0x40],rsp
  408c12:	mov    QWORD PTR [rdx+0x48],r13
  408c16:	mov    DWORD PTR [rdx+0x10],eax
  408c19:	lea    rax,[rsp+0x10]
  408c1e:	mov    QWORD PTR [rdx+0x50],rax
  408c22:	lea    rax,[rip+0xa7a7]        # 4133d0 <__swc_rdata_base_4fa09e82+0x2c0>
  408c29:	mov    QWORD PTR [rdx+0x58],rax
  408c2d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c32:	lea    r8,[rsp+0x18]
  408c37:	mov    QWORD PTR [rdx+0x60],r8
  408c3b:	mov    QWORD PTR [rdx+0x68],r13
  408c3f:	mov    DWORD PTR [rdx+0x28],ecx
  408c42:	lea    rcx,[rdx+0x28]
  408c46:	mov    QWORD PTR [rdx+0x70],rcx
  408c4a:	mov    QWORD PTR [rdx+0x78],rax
  408c4e:	mov    QWORD PTR [rdx+0x80],r14
  408c55:	mov    QWORD PTR [rdx+0x88],r13
  408c5c:	lea    rax,[rdx+0x30]
  408c60:	mov    QWORD PTR [rdx+0x90],rax
  408c67:	mov    QWORD PTR [rdx+0x98],0x6
  408c72:	lea    rcx,[rdx+0x90]
  408c79:	sub    rsp,0x8
  408c7d:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  408c82:	add    rsp,0x8
  408c86:	add    rsp,0xa0
  408c8d:	sub    rsp,0x20
  408c91:	mov    rax,rsp
  408c94:	mov    QWORD PTR [rax],r14
  408c97:	mov    QWORD PTR [rax+0x8],r13
  408c9b:	mov    QWORD PTR [rax+0x10],rsp
  408c9f:	mov    QWORD PTR [rax+0x18],0x1
  408ca7:	lea    rcx,[rsp+0x10]
  408cac:	sub    rsp,0x8
  408cb0:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  408cb5:	add    rsp,0x8
  408cb9:	add    rsp,0x20
  408cbd:	mov    eax,DWORD PTR [r12+0x9ac]
  408cc5:	test   eax,eax
  408cc7:	je     408f00 <__swc_fn_4fa09e82_000102_e9fdc18e+0x480>
  408ccd:	lea    rax,[rip+0xa744]        # 413418 <__swc_rdata_base_4fa09e82+0x308>
  408cd4:	sub    rsp,0x20
  408cd8:	mov    rcx,rsp
  408cdb:	mov    QWORD PTR [rcx],rax
  408cde:	mov    QWORD PTR [rcx+0x8],r13
  408ce2:	mov    QWORD PTR [rcx+0x10],rsp
  408ce6:	mov    QWORD PTR [rcx+0x18],0x1
  408cee:	lea    rcx,[rsp+0x10]
  408cf3:	sub    rsp,0x8
  408cf7:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  408cfc:	add    rsp,0x8
  408d00:	add    rsp,0x20
  408d04:	mov    eax,DWORD PTR [r12+0x9ac]
  408d0c:	dec    eax
  408d0e:	mov    esi,eax
  408d10:	test   esi,esi
  408d12:	jl     408ed0 <__swc_fn_4fa09e82_000102_e9fdc18e+0x450>
  408d18:	jmp    408d24 <__swc_fn_4fa09e82_000102_e9fdc18e+0x2a4>
  408d1a:	nop    WORD PTR [rax+rax*1+0x0]
  408d20:	dec    esi
  408d22:	jmp    408d10 <__swc_fn_4fa09e82_000102_e9fdc18e+0x290>
  408d24:	lea    rax,[rip+0xa6fd]        # 413428 <__swc_rdata_base_4fa09e82+0x318>
  408d2b:	sub    rsp,0x20
  408d2f:	mov    rcx,rsp
  408d32:	mov    QWORD PTR [rcx],rax
  408d35:	mov    QWORD PTR [rcx+0x8],r13
  408d39:	mov    QWORD PTR [rcx+0x10],rsp
  408d3d:	mov    QWORD PTR [rcx+0x18],0x1
  408d45:	lea    rcx,[rsp+0x10]
  408d4a:	sub    rsp,0x8
  408d4e:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  408d53:	add    rsp,0x8
  408d57:	add    rsp,0x20
  408d5b:	movsxd rax,esi
  408d5e:	imul   r15,rax,0x30
  408d62:	add    r15,r12
  408d65:	add    r15,0xf8
  408d6c:	sub    rsp,0x20
  408d70:	mov    rax,rsp
  408d73:	mov    QWORD PTR [rax],r15
  408d76:	mov    QWORD PTR [rax+0x8],rdi
  408d7a:	mov    QWORD PTR [rax+0x10],rsp
  408d7e:	mov    QWORD PTR [rax+0x18],0x1
  408d86:	lea    rcx,[rsp+0x10]
  408d8b:	sub    rsp,0x8
  408d8f:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  408d94:	add    rsp,0x8
  408d98:	add    rsp,0x20
  408d9c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408da4:	lea    rsi,[rip+0xa68d]        # 413438 <__swc_rdata_base_4fa09e82+0x328>
  408dab:	sub    rsp,0x20
  408daf:	mov    rax,rsp
  408db2:	mov    QWORD PTR [rax],rsi
  408db5:	mov    QWORD PTR [rax+0x8],r13
  408db9:	mov    QWORD PTR [rax+0x10],rsp
  408dbd:	mov    QWORD PTR [rax+0x18],0x1
  408dc5:	lea    rcx,[rsp+0x10]
  408dca:	sub    rsp,0x8
  408dce:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  408dd3:	add    rsp,0x8
  408dd7:	add    rsp,0x20
  408ddb:	sub    rsp,0x30
  408ddf:	mov    rax,rsp
  408de2:	mov    ecx,DWORD PTR [r15+0x20]
  408de6:	mov    QWORD PTR [rax],rcx
  408de9:	mov    QWORD PTR [rax+0x8],rsp
  408ded:	lea    rdi,[rip+0xa654]        # 413448 <__swc_rdata_base_4fa09e82+0x338>
  408df4:	mov    QWORD PTR [rax+0x10],rdi
  408df8:	lea    rcx,[rsp+0x8]
  408dfd:	mov    QWORD PTR [rax+0x18],rcx
  408e01:	mov    QWORD PTR [rax+0x20],0x1
  408e09:	lea    rcx,[rsp+0x18]
  408e0e:	sub    rsp,0x8
  408e12:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  408e17:	add    rsp,0x8
  408e1b:	add    rsp,0x30
  408e1f:	sub    rsp,0x20
  408e23:	mov    rax,rsp
  408e26:	mov    QWORD PTR [rax],rsi
  408e29:	mov    QWORD PTR [rax+0x8],r13
  408e2d:	mov    QWORD PTR [rax+0x10],rsp
  408e31:	mov    QWORD PTR [rax+0x18],0x1
  408e39:	lea    rcx,[rsp+0x10]
  408e3e:	sub    rsp,0x8
  408e42:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  408e47:	add    rsp,0x8
  408e4b:	add    rsp,0x20
  408e4f:	sub    rsp,0x30
  408e53:	mov    rax,rsp
  408e56:	mov    ecx,DWORD PTR [r15+0x24]
  408e5a:	mov    QWORD PTR [rax],rcx
  408e5d:	mov    QWORD PTR [rax+0x8],rsp
  408e61:	mov    QWORD PTR [rax+0x10],rdi
  408e65:	lea    rcx,[rsp+0x8]
  408e6a:	mov    QWORD PTR [rax+0x18],rcx
  408e6e:	mov    QWORD PTR [rax+0x20],0x1
  408e76:	lea    rcx,[rsp+0x18]
  408e7b:	sub    rsp,0x8
  408e7f:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  408e84:	add    rsp,0x8
  408e88:	add    rsp,0x30
  408e8c:	sub    rsp,0x20
  408e90:	mov    rax,rsp
  408e93:	mov    QWORD PTR [rax],r14
  408e96:	mov    QWORD PTR [rax+0x8],r13
  408e9a:	mov    QWORD PTR [rax+0x10],rsp
  408e9e:	mov    QWORD PTR [rax+0x18],0x1
  408ea6:	lea    rcx,[rsp+0x10]
  408eab:	sub    rsp,0x8
  408eaf:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  408eb4:	add    rsp,0x8
  408eb8:	add    rsp,0x20
  408ebc:	lea    rdi,[rip+0xa4b5]        # 413378 <__swc_rdata_base_4fa09e82+0x268>
  408ec3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408ecb:	jmp    408d20 <__swc_fn_4fa09e82_000102_e9fdc18e+0x2a0>
  408ed0:	sub    rsp,0x20
  408ed4:	mov    rax,rsp
  408ed7:	mov    QWORD PTR [rax],r14
  408eda:	mov    QWORD PTR [rax+0x8],r13
  408ede:	mov    QWORD PTR [rax+0x10],rsp
  408ee2:	mov    QWORD PTR [rax+0x18],0x1
  408eea:	lea    rcx,[rsp+0x10]
  408eef:	sub    rsp,0x8
  408ef3:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  408ef8:	add    rsp,0x8
  408efc:	add    rsp,0x20
  408f00:	lea    rax,[rbx+0x28]
  408f04:	mov    rcx,rax
  408f07:	mov    QWORD PTR [rbx+0x28],0x0
  408f0f:	mov    QWORD PTR [rbx+0x30],0x0
  408f17:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408f1c:	add    rcx,0x10
  408f20:	mov    edx,0x1f
  408f25:	cs nop WORD PTR [rax+rax*1+0x0]
  408f2f:	nop
  408f30:	vmovups XMMWORD PTR [rcx],xmm0
  408f34:	add    rcx,0x10
  408f38:	sub    rdx,0x1
  408f3c:	jne    408f30 <__swc_fn_4fa09e82_000102_e9fdc18e+0x4b0>
  408f3e:	lea    rsi,[rbx+0x228]
  408f45:	xor    ecx,ecx
  408f47:	cs nop WORD PTR [rax+rax*1+0x0]
  408f51:	cs nop WORD PTR [rax+rax*1+0x0]
  408f5b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f60:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f65:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f6a:	add    rcx,0x10
  408f6e:	cmp    rcx,0x200
  408f75:	jne    408f60 <__swc_fn_4fa09e82_000102_e9fdc18e+0x4e0>
  408f77:	mov    eax,DWORD PTR [r12+0xbc8]
  408f7f:	lea    rcx,[r12+0x9c8]
  408f87:	mov    QWORD PTR [rbx+0x428],rcx
  408f8e:	mov    QWORD PTR [rbx+0x430],rax
  408f95:	lea    rdi,[rbx+0x438]
  408f9c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408fa4:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fac:	mov    eax,DWORD PTR [r12+0xbc8]
  408fb4:	test   eax,eax
  408fb6:	jne    409003 <__swc_fn_4fa09e82_000102_e9fdc18e+0x583>
  408fb8:	lea    rax,[rbx+0x448]
  408fbf:	mov    QWORD PTR [rbx+0x448],rsi
  408fc6:	mov    QWORD PTR [rax+0x8],0x40
  408fce:	mov    ecx,0x1
  408fd3:	mov    rdx,rax
  408fd6:	sub    rsp,0x8
  408fda:	call   4099e0 <__swc_fn_4fa09e82_000120_9175a56a>
  408fdf:	add    rsp,0x8
  408fe3:	mov    QWORD PTR [rbx+0x460],rsi
  408fea:	mov    ecx,eax
  408fec:	mov    QWORD PTR [rbx+0x468],rcx
  408ff3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408ffb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  409003:	mov    rsi,QWORD PTR [rbx+0x438]
  40900a:	mov    rax,QWORD PTR [rbx+0x440]
  409011:	mov    r15,rax
  409014:	xor    r12d,r12d
  409017:	test   r15,r15
  40901a:	je     4090d0 <__swc_fn_4fa09e82_000102_e9fdc18e+0x650>
  409020:	mov    rax,QWORD PTR [rsi+r12*8]
  409024:	test   rax,rax
  409027:	je     409046 <__swc_fn_4fa09e82_000102_e9fdc18e+0x5c6>
  409029:	lea    rcx,[rbx+0x4b8]
  409030:	mov    rdx,rax
  409033:	sub    rsp,0x8
  409037:	call   40ee60 <__swc_fn_4fa09e82_000163_60216e69>
  40903c:	add    rsp,0x8
  409040:	mov    al,BYTE PTR [rax]
  409042:	test   al,al
  409044:	jne    409052 <__swc_fn_4fa09e82_000102_e9fdc18e+0x5d2>
  409046:	add    r12,0x1
  40904a:	sub    r15,0x1
  40904e:	jne    409020 <__swc_fn_4fa09e82_000102_e9fdc18e+0x5a0>
  409050:	jmp    4090d0 <__swc_fn_4fa09e82_000102_e9fdc18e+0x650>
  409052:	lea    rax,[rip+0xa437]        # 413490 <__swc_rdata_base_4fa09e82+0x380>
  409059:	sub    rsp,0x20
  40905d:	mov    rcx,rsp
  409060:	mov    QWORD PTR [rcx],rax
  409063:	mov    QWORD PTR [rcx+0x8],r13
  409067:	mov    QWORD PTR [rcx+0x10],rsp
  40906b:	mov    QWORD PTR [rcx+0x18],0x1
  409073:	lea    rcx,[rsp+0x10]
  409078:	sub    rsp,0x8
  40907c:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  409081:	add    rsp,0x8
  409085:	add    rsp,0x20
  409089:	mov    rcx,rdi
  40908c:	xor    edx,edx
  40908e:	mov    al,0x1
  409090:	mov    r8,rax
  409093:	sub    rsp,0x8
  409097:	call   411d60 <__swc_fn_4fa09e82_000164_8e41797b>
  40909c:	add    rsp,0x8
  4090a0:	sub    rsp,0x20
  4090a4:	mov    rax,rsp
  4090a7:	mov    QWORD PTR [rax],r14
  4090aa:	mov    QWORD PTR [rax+0x8],r13
  4090ae:	mov    QWORD PTR [rax+0x10],rsp
  4090b2:	mov    QWORD PTR [rax+0x18],0x1
  4090ba:	lea    rcx,[rsp+0x10]
  4090bf:	sub    rsp,0x8
  4090c3:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  4090c8:	add    rsp,0x8
  4090cc:	add    rsp,0x20
  4090d0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090d8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090e4:	add    rsp,0x500
  4090eb:	pop    r15
  4090ed:	pop    r14
  4090ef:	pop    r13
  4090f1:	pop    r12
  4090f3:	pop    rdi
  4090f4:	pop    rsi
  4090f5:	pop    rbx
  4090f6:	pop    rbp
  4090f7:	ret
	...

0000000000409100 <__swc_fn_4fa09e82_000105_5f646f9d>:
  409100:	test   r8,r8
  409103:	jne    409106 <__swc_fn_4fa09e82_000105_5f646f9d+0x6>
  409105:	ret
  409106:	xor    eax,eax
  409108:	movzx  r9d,dl
  40910c:	movabs r10,0x101010101010101
  409116:	imul   r9,r10
  40911a:	vmovq  xmm0,r9
  40911f:	vpshufd xmm0,xmm0,0x44
  409124:	cs nop WORD PTR [rax+rax*1+0x0]
  40912e:	xchg   ax,ax
  409130:	mov    r10,r8
  409133:	sub    r10,rax
  409136:	cmp    r10,0x40
  40913a:	jb     40915d <__swc_fn_4fa09e82_000105_5f646f9d+0x5d>
  40913c:	lea    r10,[rcx+rax*1]
  409140:	vmovups XMMWORD PTR [r10],xmm0
  409145:	vmovups XMMWORD PTR [r10+0x10],xmm0
  40914b:	vmovups XMMWORD PTR [r10+0x20],xmm0
  409151:	vmovups XMMWORD PTR [r10+0x30],xmm0
  409157:	lea    rax,[rax+0x40]
  40915b:	jmp    409130 <__swc_fn_4fa09e82_000105_5f646f9d+0x30>
  40915d:	nop    DWORD PTR [rax]
  409160:	mov    r10,r8
  409163:	sub    r10,rax
  409166:	cmp    r10,0x10
  40916a:	jb     40917b <__swc_fn_4fa09e82_000105_5f646f9d+0x7b>
  40916c:	lea    r10,[rcx+rax*1]
  409170:	vmovups XMMWORD PTR [r10],xmm0
  409175:	lea    rax,[rax+0x10]
  409179:	jmp    409160 <__swc_fn_4fa09e82_000105_5f646f9d+0x60>
  40917b:	nop    DWORD PTR [rax+rax*1+0x0]
  409180:	mov    r10,r8
  409183:	sub    r10,rax
  409186:	cmp    r10,0x8
  40918a:	jb     409199 <__swc_fn_4fa09e82_000105_5f646f9d+0x99>
  40918c:	lea    r10,[rcx+rax*1]
  409190:	mov    QWORD PTR [r10],r9
  409193:	lea    rax,[rax+0x8]
  409197:	jmp    409180 <__swc_fn_4fa09e82_000105_5f646f9d+0x80>
  409199:	cmp    rax,r8
  40919c:	jae    4091ab <__swc_fn_4fa09e82_000105_5f646f9d+0xab>
  40919e:	xchg   ax,ax
  4091a0:	mov    BYTE PTR [rcx+rax*1],dl
  4091a3:	inc    rax
  4091a6:	cmp    rax,r8
  4091a9:	jb     4091a0 <__swc_fn_4fa09e82_000105_5f646f9d+0xa0>
  4091ab:	ret
	...

00000000004091c0 <__swc_fn_4fa09e82_000108_4796e893>:
  4091c0:	push   rbx
  4091c1:	push   r12
  4091c3:	push   rdi
  4091c4:	push   rsi
  4091c5:	push   r13
  4091c7:	push   r14
  4091c9:	push   r15
  4091cb:	sub    rsp,0x170
  4091d2:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  4091db:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  4091e4:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  4091ed:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  4091f6:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  4091ff:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  409208:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  409211:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40921a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  409223:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40922c:	mov    ebx,edx
  40922e:	mov    QWORD PTR [rsp+0xa8],rbx
  409236:	mov    r12d,ecx
  409239:	test   edx,edx
  40923b:	jne    409252 <__swc_fn_4fa09e82_000108_4796e893+0x92>
  40923d:	xor    eax,eax
  40923f:	add    rsp,0x170
  409246:	pop    r15
  409248:	pop    r14
  40924a:	pop    r13
  40924c:	pop    rsi
  40924d:	pop    rdi
  40924e:	pop    r12
  409250:	pop    rbx
  409251:	ret
  409252:	lea    rdi,[rip+0xa257]        # 4134b0 <__swc_rdata_base_4fa09e82+0x3a0>
  409259:	mov    esi,0x90000
  40925e:	xor    eax,eax
  409260:	call   407010 <open@plt>
  409265:	mov    r13,rax
  409268:	mov    QWORD PTR [rsp+0xb0],rax
  409270:	test   eax,eax
  409272:	jge    40927b <__swc_fn_4fa09e82_000108_4796e893+0xbb>
  409274:	xor    eax,eax
  409276:	jmp    409796 <__swc_fn_4fa09e82_000108_4796e893+0x5d6>
  40927b:	nop    DWORD PTR [rax+rax*1+0x0]
  409280:	movsxd rdi,r13d
  409283:	mov    esi,0x2
  409288:	xor    eax,eax
  40928a:	call   407020 <flock@plt>
  40928f:	test   eax,eax
  409291:	je     4092b0 <__swc_fn_4fa09e82_000108_4796e893+0xf0>
  409293:	xor    eax,eax
  409295:	call   407030 <__errno_location@plt>
  40929a:	cmp    DWORD PTR [rax],0x4
  40929d:	je     409280 <__swc_fn_4fa09e82_000108_4796e893+0xc0>
  40929f:	movsxd rdi,r13d
  4092a2:	xor    eax,eax
  4092a4:	call   407040 <close@plt>
  4092a9:	xor    eax,eax
  4092ab:	jmp    409796 <__swc_fn_4fa09e82_000108_4796e893+0x5d6>
  4092b0:	lea    r14,[rsp+0x8]
  4092b5:	mov    QWORD PTR [rsp+0xb8],r14
  4092bd:	vxorps xmm0,xmm0,xmm0
  4092c1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4092c7:	mov    QWORD PTR [rsp+0x18],0x0
  4092d0:	mov    WORD PTR [rsp+0x20],0x0
  4092d7:	mov    DWORD PTR [r14],0x67617753
  4092de:	mov    DWORD PTR [r14+0x4],0x2e74522e
  4092e6:	xor    eax,eax
  4092e8:	call   407050 <getpid@plt>
  4092ed:	mov    ecx,eax
  4092ef:	mov    eax,0x1c
  4092f4:	shrx   eax,ecx,eax
  4092f9:	and    eax,0xf
  4092fc:	mov    rdx,QWORD PTR [rip+0xa1cd]        # 4134d0 <__swc_rdata_base_4fa09e82+0x3c0>
  409303:	mov    al,BYTE PTR [rdx+rax*1]
  409306:	rex mov BYTE PTR [rsp+0x10],al
  40930b:	mov    eax,0x1c
  409310:	shrx   eax,r12d,eax
  409315:	and    eax,0xf
  409318:	mov    al,BYTE PTR [rdx+rax*1]
  40931b:	rex mov BYTE PTR [rsp+0x19],al
  409320:	mov    eax,0x18
  409325:	shrx   eax,ecx,eax
  40932a:	and    eax,0xf
  40932d:	mov    al,BYTE PTR [rdx+rax*1]
  409330:	rex mov BYTE PTR [rsp+0x11],al
  409335:	mov    eax,0x18
  40933a:	shrx   eax,r12d,eax
  40933f:	and    eax,0xf
  409342:	mov    al,BYTE PTR [rdx+rax*1]
  409345:	rex mov BYTE PTR [rsp+0x1a],al
  40934a:	mov    eax,0x14
  40934f:	shrx   eax,ecx,eax
  409354:	and    eax,0xf
  409357:	mov    al,BYTE PTR [rdx+rax*1]
  40935a:	rex mov BYTE PTR [rsp+0x12],al
  40935f:	mov    eax,0x14
  409364:	shrx   eax,r12d,eax
  409369:	and    eax,0xf
  40936c:	mov    al,BYTE PTR [rdx+rax*1]
  40936f:	rex mov BYTE PTR [rsp+0x1b],al
  409374:	mov    eax,0x10
  409379:	shrx   eax,ecx,eax
  40937e:	and    eax,0xf
  409381:	mov    al,BYTE PTR [rdx+rax*1]
  409384:	rex mov BYTE PTR [rsp+0x13],al
  409389:	mov    eax,0x10
  40938e:	shrx   eax,r12d,eax
  409393:	and    eax,0xf
  409396:	mov    al,BYTE PTR [rdx+rax*1]
  409399:	rex mov BYTE PTR [rsp+0x1c],al
  40939e:	mov    eax,0xc
  4093a3:	shrx   eax,ecx,eax
  4093a8:	and    eax,0xf
  4093ab:	mov    al,BYTE PTR [rdx+rax*1]
  4093ae:	rex mov BYTE PTR [rsp+0x14],al
  4093b3:	mov    eax,0xc
  4093b8:	shrx   eax,r12d,eax
  4093bd:	and    eax,0xf
  4093c0:	mov    al,BYTE PTR [rdx+rax*1]
  4093c3:	rex mov BYTE PTR [rsp+0x1d],al
  4093c8:	mov    eax,0x8
  4093cd:	shrx   eax,ecx,eax
  4093d2:	and    eax,0xf
  4093d5:	mov    al,BYTE PTR [rdx+rax*1]
  4093d8:	rex mov BYTE PTR [rsp+0x15],al
  4093dd:	mov    eax,0x8
  4093e2:	shrx   eax,r12d,eax
  4093e7:	and    eax,0xf
  4093ea:	mov    al,BYTE PTR [rdx+rax*1]
  4093ed:	rex mov BYTE PTR [rsp+0x1e],al
  4093f2:	mov    eax,0x4
  4093f7:	shrx   eax,ecx,eax
  4093fc:	and    eax,0xf
  4093ff:	mov    al,BYTE PTR [rdx+rax*1]
  409402:	rex mov BYTE PTR [rsp+0x16],al
  409407:	mov    eax,0x4
  40940c:	shrx   eax,r12d,eax
  409411:	and    eax,0xf
  409414:	mov    al,BYTE PTR [rdx+rax*1]
  409417:	rex mov BYTE PTR [rsp+0x1f],al
  40941c:	xor    eax,eax
  40941e:	shrx   eax,ecx,eax
  409423:	and    eax,0xf
  409426:	mov    al,BYTE PTR [rdx+rax*1]
  409429:	rex mov BYTE PTR [rsp+0x17],al
  40942e:	xor    eax,eax
  409430:	shrx   eax,r12d,eax
  409435:	and    eax,0xf
  409438:	mov    al,BYTE PTR [rdx+rax*1]
  40943b:	rex mov BYTE PTR [rsp+0x20],al
  409440:	mov    BYTE PTR [r14+0x10],0x2e
  409445:	lea    r12,[rsp+0x22]
  40944a:	vxorps xmm0,xmm0,xmm0
  40944e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  409454:	mov    DWORD PTR [r12],0x6d656d2f
  40945c:	mov    WORD PTR [r12+0x4],0x6466
  409464:	mov    BYTE PTR [r12+0x6],0x3a
  40946a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409470:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  409476:	mov    rax,QWORD PTR [rsp+0x18]
  40947b:	mov    QWORD PTR [rsp+0x39],rax
  409480:	rex mov al,BYTE PTR [rsp+0x20]
  409485:	rex mov BYTE PTR [rsp+0x41],al
  40948a:	mov    DWORD PTR [r12+0x20],0x65642820
  409493:	mov    DWORD PTR [r12+0x24],0x6574656c
  40949c:	mov    WORD PTR [r12+0x28],0x2964
  4094a4:	lea    rdi,[rip+0xa010]        # 4134bb <__swc_rdata_base_4fa09e82+0x3ab>
  4094ab:	xor    eax,eax
  4094ad:	call   407060 <opendir@plt>
  4094b2:	mov    r15,rax
  4094b5:	test   rax,rax
  4094b8:	jne    4094cb <__swc_fn_4fa09e82_000108_4796e893+0x30b>
  4094ba:	movsxd rdi,r13d
  4094bd:	xor    eax,eax
  4094bf:	call   407040 <close@plt>
  4094c4:	xor    eax,eax
  4094c6:	jmp    409796 <__swc_fn_4fa09e82_000108_4796e893+0x5d6>
  4094cb:	mov    rdi,r15
  4094ce:	xor    eax,eax
  4094d0:	call   407070 <dirfd@plt>
  4094d5:	lea    r14,[rsp+0x54]
  4094da:	mov    DWORD PTR [rsp+0x54],eax
  4094de:	lea    rbx,[rsp+0x58]
  4094e3:	cs nop WORD PTR [rax+rax*1+0x0]
  4094ed:	cs nop WORD PTR [rax+rax*1+0x0]
  4094f7:	nop    WORD PTR [rax+rax*1+0x0]
  409500:	mov    rdi,r15
  409503:	xor    eax,eax
  409505:	call   407080 <readdir@plt>
  40950a:	test   rax,rax
  40950d:	jne    409524 <__swc_fn_4fa09e82_000108_4796e893+0x364>
  40950f:	mov    r12,QWORD PTR [rsp+0xa8]
  409517:	mov    r13,QWORD PTR [rsp+0xb0]
  40951f:	jmp    4096ba <__swc_fn_4fa09e82_000108_4796e893+0x4fa>
  409524:	vxorps xmm0,xmm0,xmm0
  409528:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40952e:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  409534:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40953a:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  409543:	lea    r13,[rax+0x13]
  409547:	mov    rax,r14
  40954a:	movsxd rdi,DWORD PTR [rax]
  40954d:	mov    rsi,r13
  409550:	mov    rdx,rbx
  409553:	mov    ecx,0x40
  409558:	xor    eax,eax
  40955a:	call   407090 <readlinkat@plt>
  40955f:	cmp    rax,0x2a
  409563:	jne    409500 <__swc_fn_4fa09e82_000108_4796e893+0x340>
  409565:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40956b:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  409571:	vptest xmm0,xmm0
  409576:	jne    4095a6 <__swc_fn_4fa09e82_000108_4796e893+0x3e6>
  409578:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40957e:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  409584:	vptest xmm0,xmm0
  409589:	jne    4095a6 <__swc_fn_4fa09e82_000108_4796e893+0x3e6>
  40958b:	mov    rcx,QWORD PTR [rsp+0x42]
  409590:	cmp    QWORD PTR [rsp+0x78],rcx
  409595:	jne    4095a6 <__swc_fn_4fa09e82_000108_4796e893+0x3e6>
  409597:	mov    cx,WORD PTR [rsp+0x4a]
  40959c:	cmp    WORD PTR [rsp+0x80],cx
  4095a4:	je     4095d4 <__swc_fn_4fa09e82_000108_4796e893+0x414>
  4095a6:	mov    rax,rbx
  4095a9:	mov    rcx,r12
  4095ac:	nop    DWORD PTR [rax+0x0]
  4095b0:	movzx  edx,BYTE PTR [rax]
  4095b3:	movzx  r8d,BYTE PTR [rcx]
  4095b7:	cmp    rdx,r8
  4095ba:	jne    4095c6 <__swc_fn_4fa09e82_000108_4796e893+0x406>
  4095bc:	add    rax,0x1
  4095c0:	add    rcx,0x1
  4095c4:	jmp    4095b0 <__swc_fn_4fa09e82_000108_4796e893+0x3f0>
  4095c6:	mov    rax,rdx
  4095c9:	sub    rax,r8
  4095cc:	test   eax,eax
  4095ce:	jne    409500 <__swc_fn_4fa09e82_000108_4796e893+0x340>
  4095d4:	movsxd rdi,DWORD PTR [r14]
  4095d7:	mov    rsi,r13
  4095da:	mov    edx,0x80002
  4095df:	xor    eax,eax
  4095e1:	call   4070a0 <openat@plt>
  4095e6:	lea    rbx,[rsp+0x98]
  4095ee:	mov    DWORD PTR [rsp+0x98],eax
  4095f5:	test   eax,eax
  4095f7:	mov    r13,QWORD PTR [rsp+0xb0]
  4095ff:	jge    409624 <__swc_fn_4fa09e82_000108_4796e893+0x464>
  409601:	mov    rdi,r15
  409604:	xor    eax,eax
  409606:	call   4070b0 <closedir@plt>
  40960b:	mov    r13,QWORD PTR [rsp+0xb0]
  409613:	movsxd rdi,r13d
  409616:	xor    eax,eax
  409618:	call   407040 <close@plt>
  40961d:	xor    eax,eax
  40961f:	jmp    409796 <__swc_fn_4fa09e82_000108_4796e893+0x5d6>
  409624:	mov    rax,rbx
  409627:	movsxd rdi,DWORD PTR [rax]
  40962a:	xor    esi,esi
  40962c:	mov    edx,0x2
  409631:	xor    eax,eax
  409633:	call   4070c0 <lseek@plt>
  409638:	mov    r12,QWORD PTR [rsp+0xa8]
  409640:	cmp    rax,r12
  409643:	je     40966a <__swc_fn_4fa09e82_000108_4796e893+0x4aa>
  409645:	movsxd rdi,DWORD PTR [rbx]
  409648:	xor    eax,eax
  40964a:	call   407040 <close@plt>
  40964f:	mov    rdi,r15
  409652:	xor    eax,eax
  409654:	call   4070b0 <closedir@plt>
  409659:	movsxd rdi,r13d
  40965c:	xor    eax,eax
  40965e:	call   407040 <close@plt>
  409663:	xor    eax,eax
  409665:	jmp    409796 <__swc_fn_4fa09e82_000108_4796e893+0x5d6>
  40966a:	xor    edi,edi
  40966c:	mov    rsi,r12
  40966f:	mov    edx,0x3
  409674:	mov    ecx,0x1
  409679:	mov    rax,rbx
  40967c:	movsxd r8,DWORD PTR [rax]
  40967f:	xor    r9d,r9d
  409682:	xor    eax,eax
  409684:	call   4070d0 <mmap@plt>
  409689:	xor    r12d,r12d
  40968c:	cmp    rax,0xffffffffffffffff
  409690:	cmovne r12,rax
  409694:	movsxd rdi,DWORD PTR [rbx]
  409697:	xor    eax,eax
  409699:	call   407040 <close@plt>
  40969e:	mov    rdi,r15
  4096a1:	xor    eax,eax
  4096a3:	call   4070b0 <closedir@plt>
  4096a8:	movsxd rdi,r13d
  4096ab:	xor    eax,eax
  4096ad:	call   407040 <close@plt>
  4096b2:	mov    rax,r12
  4096b5:	jmp    409796 <__swc_fn_4fa09e82_000108_4796e893+0x5d6>
  4096ba:	mov    r14,QWORD PTR [rsp+0xb8]
  4096c2:	mov    rdi,r14
  4096c5:	mov    esi,0x1
  4096ca:	xor    eax,eax
  4096cc:	call   4070e0 <memfd_create@plt>
  4096d1:	lea    rbx,[rsp+0x9c]
  4096d9:	mov    DWORD PTR [rsp+0x9c],eax
  4096e0:	test   eax,eax
  4096e2:	jge    4096ff <__swc_fn_4fa09e82_000108_4796e893+0x53f>
  4096e4:	mov    rdi,r15
  4096e7:	xor    eax,eax
  4096e9:	call   4070b0 <closedir@plt>
  4096ee:	movsxd rdi,r13d
  4096f1:	xor    eax,eax
  4096f3:	call   407040 <close@plt>
  4096f8:	xor    eax,eax
  4096fa:	jmp    409796 <__swc_fn_4fa09e82_000108_4796e893+0x5d6>
  4096ff:	mov    rax,rbx
  409702:	movsxd rdi,DWORD PTR [rax]
  409705:	mov    rsi,r12
  409708:	xor    eax,eax
  40970a:	call   4070f0 <ftruncate@plt>
  40970f:	test   eax,eax
  409711:	je     409735 <__swc_fn_4fa09e82_000108_4796e893+0x575>
  409713:	movsxd rdi,DWORD PTR [rbx]
  409716:	xor    eax,eax
  409718:	call   407040 <close@plt>
  40971d:	mov    rdi,r15
  409720:	xor    eax,eax
  409722:	call   4070b0 <closedir@plt>
  409727:	movsxd rdi,r13d
  40972a:	xor    eax,eax
  40972c:	call   407040 <close@plt>
  409731:	xor    eax,eax
  409733:	jmp    409796 <__swc_fn_4fa09e82_000108_4796e893+0x5d6>
  409735:	xor    edi,edi
  409737:	mov    rsi,r12
  40973a:	mov    edx,0x3
  40973f:	mov    ecx,0x1
  409744:	mov    rax,rbx
  409747:	movsxd r8,DWORD PTR [rax]
  40974a:	xor    r9d,r9d
  40974d:	xor    eax,eax
  40974f:	call   4070d0 <mmap@plt>
  409754:	mov    r12,rax
  409757:	cmp    rax,0xffffffffffffffff
  40975b:	jne    40977f <__swc_fn_4fa09e82_000108_4796e893+0x5bf>
  40975d:	movsxd rdi,DWORD PTR [rbx]
  409760:	xor    eax,eax
  409762:	call   407040 <close@plt>
  409767:	mov    rdi,r15
  40976a:	xor    eax,eax
  40976c:	call   4070b0 <closedir@plt>
  409771:	movsxd rdi,r13d
  409774:	xor    eax,eax
  409776:	call   407040 <close@plt>
  40977b:	xor    eax,eax
  40977d:	jmp    409796 <__swc_fn_4fa09e82_000108_4796e893+0x5d6>
  40977f:	mov    rdi,r15
  409782:	xor    eax,eax
  409784:	call   4070b0 <closedir@plt>
  409789:	movsxd rdi,r13d
  40978c:	xor    eax,eax
  40978e:	call   407040 <close@plt>
  409793:	mov    rax,r12
  409796:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40979f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  4097a8:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  4097b1:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  4097ba:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  4097c3:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  4097cc:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  4097d5:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  4097de:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  4097e7:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  4097f0:	add    rsp,0x170
  4097f7:	pop    r15
  4097f9:	pop    r14
  4097fb:	pop    r13
  4097fd:	pop    rsi
  4097fe:	pop    rdi
  4097ff:	pop    r12
  409801:	pop    rbx
  409802:	ret
	...

0000000000409810 <__swc_fn_4fa09e82_000111_a808fe76>:
  409810:	push   rsi
  409811:	push   rdi
  409812:	push   r12
  409814:	push   r13
  409816:	sub    rsp,0x8
  40981a:	mov    rsi,r8
  40981d:	mov    rdi,rcx
  409820:	mov    r12,rdx
  409823:	call   40e040 <__swc_fn_4fa09e82_000109_84af7666>
  409828:	mov    r13,rax
  40982b:	test   rax,rax
  40982e:	jne    40983b <__swc_fn_4fa09e82_000111_a808fe76+0x2b>
  409830:	add    rsp,0x8
  409834:	pop    r13
  409836:	pop    r12
  409838:	pop    rdi
  409839:	pop    rsi
  40983a:	ret
  40983b:	mov    rcx,r13
  40983e:	call   411850 <__swc_fn_4fa09e82_000134_4b2af8da>
  409843:	mov    rax,QWORD PTR [r13+0x8]
  409847:	test   rax,rax
  40984a:	je     409889 <__swc_fn_4fa09e82_000111_a808fe76+0x79>
  40984c:	nop    DWORD PTR [rax+0x0]
  409850:	lea    rcx,[rax+0x1000]
  409857:	cmp    rdi,rcx
  40985a:	jne    409881 <__swc_fn_4fa09e82_000111_a808fe76+0x71>
  40985c:	cmp    r12,0x1000
  409863:	jb     409881 <__swc_fn_4fa09e82_000111_a808fe76+0x71>
  409865:	test   sil,sil
  409868:	setne  cl
  40986b:	mov    BYTE PTR [rax+0x10],cl
  40986e:	mov    rcx,r13
  409871:	call   409d80 <__swc_fn_4fa09e82_000135_29412410>
  409876:	add    rsp,0x8
  40987a:	pop    r13
  40987c:	pop    r12
  40987e:	pop    rdi
  40987f:	pop    rsi
  409880:	ret
  409881:	mov    rax,QWORD PTR [rax]
  409884:	test   rax,rax
  409887:	jne    409850 <__swc_fn_4fa09e82_000111_a808fe76+0x40>
  409889:	mov    rcx,r13
  40988c:	call   409d80 <__swc_fn_4fa09e82_000135_29412410>
  409891:	add    rsp,0x8
  409895:	pop    r13
  409897:	pop    r12
  409899:	pop    rdi
  40989a:	pop    rsi
  40989b:	ret
  40989c:	add    BYTE PTR [rax],al
	...

00000000004098a0 <__swc_fn_4fa09e82_000114_49b378a9>:
  4098a0:	sub    rsp,0x8
  4098a4:	test   rcx,rcx
  4098a7:	jne    4098ae <__swc_fn_4fa09e82_000114_49b378a9+0xe>
  4098a9:	add    rsp,0x8
  4098ad:	ret
  4098ae:	call   411350 <__swc_fn_4fa09e82_000116_1ba33335>
  4098b3:	add    rsp,0x8
  4098b7:	ret
	...

00000000004098c0 <__swc_fn_4fa09e82_000117_035d76a1>:
  4098c0:	push   r12
  4098c2:	push   r13
  4098c4:	push   r14
  4098c6:	push   rdi
  4098c7:	push   rsi
  4098c8:	sub    rsp,0xc0
  4098cf:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  4098d5:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  4098db:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  4098e1:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4098e7:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4098ed:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4098f3:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4098f9:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409902:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40990b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409914:	mov    r12,QWORD PTR [rcx]
  409917:	test   r12,r12
  40991a:	jne    40992c <__swc_fn_4fa09e82_000117_035d76a1+0x6c>
  40991c:	add    rsp,0xc0
  409923:	pop    rsi
  409924:	pop    rdi
  409925:	pop    r14
  409927:	pop    r13
  409929:	pop    r12
  40992b:	ret
  40992c:	xor    r13d,r13d
  40992f:	mov    r14,QWORD PTR [rcx+0x8]
  409933:	cs nop WORD PTR [rax+rax*1+0x0]
  40993d:	nop    DWORD PTR [rax]
  409940:	cmp    r13,r14
  409943:	jae    40997e <__swc_fn_4fa09e82_000117_035d76a1+0xbe>
  409945:	lea    rax,[r12+r13*1]
  409949:	mov    rcx,r14
  40994c:	sub    rcx,r13
  40994f:	mov    edi,0x1
  409954:	mov    rsi,rax
  409957:	mov    rdx,rcx
  40995a:	xor    eax,eax
  40995c:	call   407100 <write@plt>
  409961:	test   rax,rax
  409964:	jle    40996b <__swc_fn_4fa09e82_000117_035d76a1+0xab>
  409966:	add    r13,rax
  409969:	jmp    409940 <__swc_fn_4fa09e82_000117_035d76a1+0x80>
  40996b:	test   rax,rax
  40996e:	je     40997c <__swc_fn_4fa09e82_000117_035d76a1+0xbc>
  409970:	xor    eax,eax
  409972:	call   407030 <__errno_location@plt>
  409977:	cmp    DWORD PTR [rax],0x4
  40997a:	je     409940 <__swc_fn_4fa09e82_000117_035d76a1+0x80>
  40997c:	jmp    40997e <__swc_fn_4fa09e82_000117_035d76a1+0xbe>
  40997e:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409984:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40998a:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409990:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409996:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40999c:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4099a2:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4099a8:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4099b1:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4099ba:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4099c3:	add    rsp,0xc0
  4099ca:	pop    rsi
  4099cb:	pop    rdi
  4099cc:	pop    r14
  4099ce:	pop    r13
  4099d0:	pop    r12
  4099d2:	ret
	...

00000000004099e0 <__swc_fn_4fa09e82_000120_9175a56a>:
  4099e0:	push   rbx
  4099e1:	push   r12
  4099e3:	push   rdi
  4099e4:	push   rsi
  4099e5:	sub    rsp,0x4a8
  4099ec:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  4099f5:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  4099fe:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  409a07:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  409a10:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  409a19:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  409a22:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  409a2b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  409a34:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  409a3d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  409a46:	mov    rbx,rdx
  409a49:	mov    r12d,ecx
  409a4c:	vxorps xmm0,xmm0,xmm0
  409a50:	xor    eax,eax
  409a52:	cs nop WORD PTR [rax+rax*1+0x0]
  409a5c:	nop    DWORD PTR [rax+0x0]
  409a60:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  409a66:	add    rax,0x10
  409a6a:	cmp    rax,0x400
  409a71:	jne    409a60 <__swc_fn_4fa09e82_000120_9175a56a+0x80>
  409a73:	lea    rdi,[rsp+0x8]
  409a78:	mov    esi,0x80
  409a7d:	xor    eax,eax
  409a7f:	call   407110 <backtrace@plt>
  409a84:	test   eax,eax
  409a86:	jle    409a95 <__swc_fn_4fa09e82_000120_9175a56a+0xb5>
  409a88:	movsxd rax,eax
  409a8b:	lea    rcx,[r12+0x1]
  409a90:	cmp    rcx,rax
  409a93:	jb     409a99 <__swc_fn_4fa09e82_000120_9175a56a+0xb9>
  409a95:	xor    eax,eax
  409a97:	jmp    409aca <__swc_fn_4fa09e82_000120_9175a56a+0xea>
  409a99:	mov    rcx,QWORD PTR [rbx+0x8]
  409a9d:	sub    rax,r12
  409aa0:	lea    rsi,[rax-0x1]
  409aa4:	cmp    rcx,rsi
  409aa7:	cmovbe rsi,rcx
  409aab:	lea    eax,[r12+0x1]
  409ab0:	lea    rax,[rsp+rax*8+0x8]
  409ab5:	mov    rcx,QWORD PTR [rbx]
  409ab8:	mov    rdx,rax
  409abb:	lea    r8,[rsi*8+0x0]
  409ac3:	call   40e020 <__swc_fn_4fa09e82_000106_6fd80914>
  409ac8:	mov    eax,esi
  409aca:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  409ad3:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  409adc:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  409ae5:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  409aee:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  409af7:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  409b00:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  409b09:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  409b12:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  409b1b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  409b24:	add    rsp,0x4a8
  409b2b:	pop    rsi
  409b2c:	pop    rdi
  409b2d:	pop    r12
  409b2f:	pop    rbx
  409b30:	ret
	...

0000000000409b40 <__swc_fn_4fa09e82_000123_e09461fd>:
  409b40:	mov    QWORD PTR [rcx],0x0
  409b47:	ret
	...

0000000000409b50 <__swc_fn_4fa09e82_000126_ce762363>:
  409b50:	push   rdi
  409b51:	push   rsi
  409b52:	sub    rsp,0xa8
  409b59:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409b5f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409b65:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409b6b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409b71:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409b77:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409b7d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409b83:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409b89:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409b92:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409b9b:	mov    edi,ecx
  409b9d:	mov    rsi,rdx
  409ba0:	xor    eax,eax
  409ba2:	call   407120 <pthread_setspecific@plt>
  409ba7:	test   eax,eax
  409ba9:	sete   al
  409bac:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409bb2:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409bb8:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409bbe:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409bc4:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409bca:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409bd0:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409bd6:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409bdc:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409be5:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409bee:	add    rsp,0xa8
  409bf5:	pop    rsi
  409bf6:	pop    rdi
  409bf7:	ret
	...

0000000000409c00 <__swc_fn_4fa09e82_000129_41c3251c>:
  409c00:	push   rdi
  409c01:	push   rsi
  409c02:	sub    rsp,0xa8
  409c09:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409c0f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409c15:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409c1b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409c21:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409c27:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409c2d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409c33:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409c39:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409c42:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409c4b:	test   rcx,rcx
  409c4e:	je     409c61 <__swc_fn_4fa09e82_000129_41c3251c+0x61>
  409c50:	lea    rax,[rcx-0x1]
  409c54:	mov    eax,eax
  409c56:	mov    edi,eax
  409c58:	xor    eax,eax
  409c5a:	call   407000 <pthread_getspecific@plt>
  409c5f:	jmp    409c63 <__swc_fn_4fa09e82_000129_41c3251c+0x63>
  409c61:	xor    eax,eax
  409c63:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409c69:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409c6f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409c75:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409c7b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409c81:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409c87:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409c8d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409c93:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409c9c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409ca5:	add    rsp,0xa8
  409cac:	pop    rsi
  409cad:	pop    rdi
  409cae:	ret
	...

0000000000409cb0 <__swc_fn_4fa09e82_000132_944f555b>:
  409cb0:	push   rdi
  409cb1:	push   rsi
  409cb2:	sub    rsp,0xb8
  409cb9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409cbf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409cc5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409ccb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409cd1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409cd7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409cdd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409ce3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409cec:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409cf5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409cfe:	vxorps xmm0,xmm0,xmm0
  409d02:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409d08:	mov    edi,0x1
  409d0d:	lea    rsi,[rsp+0x8]
  409d12:	xor    eax,eax
  409d14:	call   407130 <clock_gettime@plt>
  409d19:	mov    rax,QWORD PTR [rsp+0x8]
  409d1e:	imul   rax,rax,0x3b9aca00
  409d25:	add    rax,QWORD PTR [rsp+0x10]
  409d2a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409d30:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409d36:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409d3c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409d42:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409d48:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409d4e:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409d54:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409d5d:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409d66:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409d6f:	add    rsp,0xb8
  409d76:	pop    rsi
  409d77:	pop    rdi
  409d78:	ret
  409d79:	add    BYTE PTR [rax],al
  409d7b:	add    BYTE PTR [rax],al
  409d7d:	add    BYTE PTR [rax],al
	...

0000000000409d80 <__swc_fn_4fa09e82_000135_29412410>:
  409d80:	sub    rsp,0x8
  409d84:	xor    eax,eax
  409d86:	mov    DWORD PTR [rcx],eax
  409d88:	mov    edx,0x7fffffff
  409d8d:	call   40e720 <__swc_fn_4fa09e82_000133_f908e7f9>
  409d92:	add    rsp,0x8
  409d96:	ret
	...

0000000000409da0 <__swc_fn_4fa09e82_000138_a4ba10ed>:
  409da0:	push   rdi
  409da1:	push   rsi
  409da2:	sub    rsp,0xb8
  409da9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409daf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409db5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409dbb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409dc1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409dc7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409dcd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409dd3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409ddc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409de5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409dee:	mov    edi,0x1
  409df3:	xor    eax,eax
  409df5:	call   407140 <__x86_get_cpuid_feature_leaf@plt>
  409dfa:	mov    eax,DWORD PTR [rax+0x14]
  409dfd:	and    eax,0x20
  409e00:	setne  al
  409e03:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409e09:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409e0f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409e15:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409e1b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409e21:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409e27:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409e2d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409e36:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409e3f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409e48:	add    rsp,0xb8
  409e4f:	pop    rsi
  409e50:	pop    rdi
  409e51:	ret
	...

0000000000409e60 <__swc_fn_4fa09e82_000141_c6b99a56>:
  409e60:	push   rsi
  409e61:	push   rdi
  409e62:	push   r12
  409e64:	push   r13
  409e66:	push   r14
  409e68:	push   r15
  409e6a:	cmp    rdx,0x40
  409e6e:	jae    409e7d <__swc_fn_4fa09e82_000141_c6b99a56+0x1d>
  409e70:	xor    eax,eax
  409e72:	pop    r15
  409e74:	pop    r14
  409e76:	pop    r13
  409e78:	pop    r12
  409e7a:	pop    rdi
  409e7b:	pop    rsi
  409e7c:	ret
  409e7d:	cmp    BYTE PTR [rcx],0x7f
  409e80:	jne    409ec4 <__swc_fn_4fa09e82_000141_c6b99a56+0x64>
  409e82:	movzx  eax,BYTE PTR [rcx+0x1]
  409e86:	cmp    eax,0x45
  409e89:	setne  al
  409e8c:	jne    409ec0 <__swc_fn_4fa09e82_000141_c6b99a56+0x60>
  409e8e:	movzx  eax,BYTE PTR [rcx+0x2]
  409e92:	cmp    eax,0x4c
  409e95:	setne  al
  409e98:	jne    409ec0 <__swc_fn_4fa09e82_000141_c6b99a56+0x60>
  409e9a:	movzx  eax,BYTE PTR [rcx+0x3]
  409e9e:	cmp    eax,0x46
  409ea1:	setne  al
  409ea4:	jne    409ec0 <__swc_fn_4fa09e82_000141_c6b99a56+0x60>
  409ea6:	cmp    BYTE PTR [rcx+0x4],0x2
  409eaa:	setne  al
  409ead:	jne    409ec0 <__swc_fn_4fa09e82_000141_c6b99a56+0x60>
  409eaf:	cmp    BYTE PTR [rcx+0x5],0x1
  409eb3:	setne  al
  409eb6:	jne    409ec0 <__swc_fn_4fa09e82_000141_c6b99a56+0x60>
  409eb8:	cmp    WORD PTR [rcx+0x12],0x3e
  409ebd:	setne  al
  409ec0:	test   al,al
  409ec2:	je     409ed1 <__swc_fn_4fa09e82_000141_c6b99a56+0x71>
  409ec4:	xor    eax,eax
  409ec6:	pop    r15
  409ec8:	pop    r14
  409eca:	pop    r13
  409ecc:	pop    r12
  409ece:	pop    rdi
  409ecf:	pop    rsi
  409ed0:	ret
  409ed1:	cmp    WORD PTR [rcx+0x3a],0x40
  409ed6:	jne    409ef1 <__swc_fn_4fa09e82_000141_c6b99a56+0x91>
  409ed8:	cmp    WORD PTR [rcx+0x3c],0x0
  409edd:	sete   al
  409ee0:	je     409eed <__swc_fn_4fa09e82_000141_c6b99a56+0x8d>
  409ee2:	mov    ax,WORD PTR [rcx+0x3c]
  409ee6:	cmp    WORD PTR [rcx+0x3e],ax
  409eea:	setae  al
  409eed:	test   al,al
  409eef:	je     409efe <__swc_fn_4fa09e82_000141_c6b99a56+0x9e>
  409ef1:	xor    eax,eax
  409ef3:	pop    r15
  409ef5:	pop    r14
  409ef7:	pop    r13
  409ef9:	pop    r12
  409efb:	pop    rdi
  409efc:	pop    rsi
  409efd:	ret
  409efe:	movzx  eax,WORD PTR [rcx+0x3c]
  409f02:	shl    rax,0x6
  409f06:	cmp    rax,rdx
  409f09:	ja     409f17 <__swc_fn_4fa09e82_000141_c6b99a56+0xb7>
  409f0b:	mov    r9,rdx
  409f0e:	sub    r9,rax
  409f11:	cmp    QWORD PTR [rcx+0x28],r9
  409f15:	jbe    409f24 <__swc_fn_4fa09e82_000141_c6b99a56+0xc4>
  409f17:	xor    eax,eax
  409f19:	pop    r15
  409f1b:	pop    r14
  409f1d:	pop    r13
  409f1f:	pop    r12
  409f21:	pop    rdi
  409f22:	pop    rsi
  409f23:	ret
  409f24:	mov    rax,QWORD PTR [rcx+0x28]
  409f28:	add    rax,rcx
  409f2b:	movzx  r9d,WORD PTR [rcx+0x3e]
  409f30:	lea    r9,[r9*8+0x0]
  409f38:	lea    r10,[rax+r9*8]
  409f3c:	cmp    QWORD PTR [r10+0x20],rdx
  409f40:	ja     409f62 <__swc_fn_4fa09e82_000141_c6b99a56+0x102>
  409f42:	mov    r11,rdx
  409f45:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  409f4a:	cmp    QWORD PTR [r10+0x18],r11
  409f4e:	seta   r9b
  409f52:	ja     409f5d <__swc_fn_4fa09e82_000141_c6b99a56+0xfd>
  409f54:	cmp    QWORD PTR [r10+0x20],0x9
  409f59:	setb   r9b
  409f5d:	test   r9b,r9b
  409f60:	je     409f6f <__swc_fn_4fa09e82_000141_c6b99a56+0x10f>
  409f62:	xor    eax,eax
  409f64:	pop    r15
  409f66:	pop    r14
  409f68:	pop    r13
  409f6a:	pop    r12
  409f6c:	pop    rdi
  409f6d:	pop    rsi
  409f6e:	ret
  409f6f:	movzx  r9d,WORD PTR [rcx+0x3c]
  409f74:	xor    r11d,r11d
  409f77:	test   r9,r9
  409f7a:	jbe    40a075 <__swc_fn_4fa09e82_000141_c6b99a56+0x215>
  409f80:	mov    rsi,QWORD PTR [r10+0x20]
  409f84:	sub    rsi,0x9
  409f88:	cs nop WORD PTR [rax+rax*1+0x0]
  409f92:	cs nop WORD PTR [rax+rax*1+0x0]
  409f9c:	nop    DWORD PTR [rax+0x0]
  409fa0:	movzx  edi,r11w
  409fa4:	lea    rdi,[rdi*8+0x0]
  409fac:	lea    r12,[rax+rdi*8]
  409fb0:	rex mov edi,DWORD PTR [rax+rdi*8]
  409fb4:	cmp    rdi,rsi
  409fb7:	ja     40a068 <__swc_fn_4fa09e82_000141_c6b99a56+0x208>
  409fbd:	mov    r13,QWORD PTR [r10+0x18]
  409fc1:	add    r13,rdi
  409fc4:	lea    rdi,[rcx+r13*1]
  409fc8:	lea    r13,[rip+0x9561]        # 413530 <__swc_rdata_base_4fa09e82+0x420>
  409fcf:	movabs r14,0x676264676177732e
  409fd9:	cmp    QWORD PTR [rdi],r14
  409fdc:	jne    409fe5 <__swc_fn_4fa09e82_000141_c6b99a56+0x185>
  409fde:	rex cmp BYTE PTR [rdi+0x8],0x0
  409fe3:	je     40a012 <__swc_fn_4fa09e82_000141_c6b99a56+0x1b2>
  409fe5:	cs nop WORD PTR [rax+rax*1+0x0]
  409fef:	nop
  409ff0:	movzx  r14d,BYTE PTR [rdi]
  409ff4:	movzx  r15d,BYTE PTR [r13+0x0]
  409ff9:	cmp    r14,r15
  409ffc:	jne    40a008 <__swc_fn_4fa09e82_000141_c6b99a56+0x1a8>
  409ffe:	add    rdi,0x1
  40a002:	add    r13,0x1
  40a006:	jmp    409ff0 <__swc_fn_4fa09e82_000141_c6b99a56+0x190>
  40a008:	mov    rdi,r14
  40a00b:	sub    rdi,r15
  40a00e:	test   edi,edi
  40a010:	jne    40a068 <__swc_fn_4fa09e82_000141_c6b99a56+0x208>
  40a012:	cmp    DWORD PTR [r12+0x4],0x1
  40a018:	jne    40a040 <__swc_fn_4fa09e82_000141_c6b99a56+0x1e0>
  40a01a:	cmp    QWORD PTR [r12+0x20],0x10
  40a020:	setb   al
  40a023:	jb     40a03c <__swc_fn_4fa09e82_000141_c6b99a56+0x1dc>
  40a025:	cmp    QWORD PTR [r12+0x20],rdx
  40a02a:	seta   al
  40a02d:	ja     40a03c <__swc_fn_4fa09e82_000141_c6b99a56+0x1dc>
  40a02f:	sub    rdx,QWORD PTR [r12+0x20]
  40a034:	cmp    QWORD PTR [r12+0x18],rdx
  40a039:	seta   al
  40a03c:	test   al,al
  40a03e:	je     40a04d <__swc_fn_4fa09e82_000141_c6b99a56+0x1ed>
  40a040:	xor    eax,eax
  40a042:	pop    r15
  40a044:	pop    r14
  40a046:	pop    r13
  40a048:	pop    r12
  40a04a:	pop    rdi
  40a04b:	pop    rsi
  40a04c:	ret
  40a04d:	mov    rax,QWORD PTR [r12+0x20]
  40a052:	mov    QWORD PTR [r8],rax
  40a055:	mov    rax,QWORD PTR [r12+0x18]
  40a05a:	add    rax,rcx
  40a05d:	pop    r15
  40a05f:	pop    r14
  40a061:	pop    r13
  40a063:	pop    r12
  40a065:	pop    rdi
  40a066:	pop    rsi
  40a067:	ret
  40a068:	add    r11,0x1
  40a06c:	cmp    r11,r9
  40a06f:	jb     409fa0 <__swc_fn_4fa09e82_000141_c6b99a56+0x140>
  40a075:	xor    eax,eax
  40a077:	pop    r15
  40a079:	pop    r14
  40a07b:	pop    r13
  40a07d:	pop    r12
  40a07f:	pop    rdi
  40a080:	pop    rsi
  40a081:	ret
	...

000000000040a090 <__swc_fn_4fa09e82_000144_81c0d993>:
  40a090:	push   rdi
  40a091:	push   rsi
  40a092:	sub    rsp,0xa8
  40a099:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40a09f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40a0a5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40a0ab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40a0b1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40a0b7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40a0bd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40a0c3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40a0c9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a0d2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a0db:	mov    rdi,rcx
  40a0de:	xor    eax,eax
  40a0e0:	call   407150 <free@plt>
  40a0e5:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a0eb:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a0f1:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a0f7:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a0fd:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a103:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a109:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a10f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a115:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a11e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a127:	add    rsp,0xa8
  40a12e:	pop    rsi
  40a12f:	pop    rdi
  40a130:	ret
	...

000000000040a140 <__swc_fn_4fa09e82_000147_43f4fdca>:
  40a140:	push   rbx
  40a141:	push   rsi
  40a142:	push   rdi
  40a143:	push   r12
  40a145:	push   r13
  40a147:	push   r15
  40a149:	sub    rsp,0x4e8
  40a150:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  40a159:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  40a162:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  40a16b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  40a174:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  40a17d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  40a186:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  40a18f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  40a198:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  40a1a1:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  40a1aa:	mov    rbx,QWORD PTR [rcx]
  40a1ad:	mov    rcx,QWORD PTR [rcx+0x8]
  40a1b1:	mov    rsi,rcx
  40a1b4:	xor    edi,edi
  40a1b6:	vmovsd xmm6,QWORD PTR [rip+0x93d2]        # 413590 <__swc_rdata_base_4fa09e82+0x480>
  40a1be:	vmovsd xmm7,QWORD PTR [rip+0x93d3]        # 413599 <__swc_rdata_base_4fa09e82+0x489>
  40a1c6:	vmovsd xmm8,QWORD PTR [rip+0x93d4]        # 4135a2 <__swc_rdata_base_4fa09e82+0x492>
  40a1ce:	vmovsd xmm9,QWORD PTR [rip+0x93d5]        # 4135ab <__swc_rdata_base_4fa09e82+0x49b>
  40a1d6:	vmovsd xmm10,QWORD PTR [rip+0x93d6]        # 4135b4 <__swc_rdata_base_4fa09e82+0x4a4>
  40a1de:	vmovups xmm11,xmm6
  40a1e2:	vmovsd QWORD PTR [rsp+0x418],xmm7
  40a1eb:	vmovsd QWORD PTR [rsp+0x420],xmm8
  40a1f4:	vmovsd QWORD PTR [rsp+0x428],xmm9
  40a1fd:	vmovsd QWORD PTR [rsp+0x430],xmm10
  40a206:	vmovsd xmm15,QWORD PTR [rip+0x93af]        # 4135bd <__swc_rdata_base_4fa09e82+0x4ad>
  40a20e:	vmovups xmm14,xmm15
  40a213:	vmovups xmm0,xmm9
  40a218:	vmovsd QWORD PTR [rsp+0x438],xmm15
  40a221:	vmovups xmm13,xmm8
  40a226:	vmovsd QWORD PTR [rsp+0x440],xmm15
  40a22f:	test   rsi,rsi
  40a232:	je     40b263 <__swc_fn_4fa09e82_000147_43f4fdca+0x1123>
  40a238:	cs nop WORD PTR [rax+rax*1+0x0]
  40a242:	cs nop WORD PTR [rax+rax*1+0x0]
  40a24c:	nop    DWORD PTR [rax+0x0]
  40a250:	lea    rcx,[rdi+rdi*1]
  40a254:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  40a259:	vpshufd xmm3,xmm2,0xee
  40a25e:	vmovq  rcx,xmm3
  40a263:	test   rcx,rcx
  40a266:	je     40a27c <__swc_fn_4fa09e82_000147_43f4fdca+0x13c>
  40a268:	test   DWORD PTR [rcx+0x28],0x400000
  40a26f:	je     40a27c <__swc_fn_4fa09e82_000147_43f4fdca+0x13c>
  40a271:	mov    rdx,QWORD PTR [rcx+0x30]
  40a275:	test   rdx,rdx
  40a278:	cmovne rcx,rdx
  40a27c:	test   DWORD PTR [rcx+0x28],0x1000
  40a283:	je     40a2a4 <__swc_fn_4fa09e82_000147_43f4fdca+0x164>
  40a285:	mov    rdx,QWORD PTR [rcx+0x40]
  40a289:	mov    rcx,rdx
  40a28c:	vmovq  r8,xmm2
  40a291:	mov    r8,QWORD PTR [r8]
  40a294:	mov    QWORD PTR [rsp+0x60],r8
  40a299:	mov    QWORD PTR [rsp+0x68],rdx
  40a29e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  40a2a4:	test   BYTE PTR [rcx+0x28],0x1
  40a2a8:	jne    40a2b0 <__swc_fn_4fa09e82_000147_43f4fdca+0x170>
  40a2aa:	vmovups xmm12,xmm0
  40a2ae:	jmp    40a2ca <__swc_fn_4fa09e82_000147_43f4fdca+0x18a>
  40a2b0:	vmovq  rax,xmm2
  40a2b5:	mov    rax,QWORD PTR [rax]
  40a2b8:	lea    rcx,[rax+0x10]
  40a2bc:	vmovups xmm12,xmm0
  40a2c0:	call   4098c0 <__swc_fn_4fa09e82_000117_035d76a1>
  40a2c5:	jmp    40b245 <__swc_fn_4fa09e82_000147_43f4fdca+0x1105>
  40a2ca:	test   DWORD PTR [rcx+0x28],0x400
  40a2d1:	je     40a332 <__swc_fn_4fa09e82_000147_43f4fdca+0x1f2>
  40a2d3:	vmovq  rax,xmm2
  40a2d8:	mov    rax,QWORD PTR [rax]
  40a2db:	xor    ecx,ecx
  40a2dd:	test   rax,rax
  40a2e0:	je     40a310 <__swc_fn_4fa09e82_000147_43f4fdca+0x1d0>
  40a2e2:	mov    rdx,rax
  40a2e5:	mov    r8b,BYTE PTR [rdx]
  40a2e8:	test   r8b,r8b
  40a2eb:	je     40a310 <__swc_fn_4fa09e82_000147_43f4fdca+0x1d0>
  40a2ed:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2f7:	nop    WORD PTR [rax+rax*1+0x0]
  40a300:	add    rdx,0x1
  40a304:	add    rcx,0x1
  40a308:	mov    r8b,BYTE PTR [rdx]
  40a30b:	test   r8b,r8b
  40a30e:	jne    40a300 <__swc_fn_4fa09e82_000147_43f4fdca+0x1c0>
  40a310:	mov    QWORD PTR [rsp+0x88],rax
  40a318:	mov    QWORD PTR [rsp+0x90],rcx
  40a320:	lea    rcx,[rsp+0x88]
  40a328:	call   4098c0 <__swc_fn_4fa09e82_000117_035d76a1>
  40a32d:	jmp    40b245 <__swc_fn_4fa09e82_000147_43f4fdca+0x1105>
  40a332:	cmp    BYTE PTR [rcx+0x2c],0x6
  40a336:	jne    40a34d <__swc_fn_4fa09e82_000147_43f4fdca+0x20d>
  40a338:	vmovq  rax,xmm2
  40a33d:	mov    rax,QWORD PTR [rax]
  40a340:	mov    rcx,rax
  40a343:	call   40ebf0 <__swc_fn_4fa09e82_000145_72996a5b>
  40a348:	jmp    40b245 <__swc_fn_4fa09e82_000147_43f4fdca+0x1105>
  40a34d:	cmp    BYTE PTR [rcx+0x2c],0x1
  40a351:	jne    40b239 <__swc_fn_4fa09e82_000147_43f4fdca+0x10f9>
  40a357:	vmovq  rdx,xmm2
  40a35c:	mov    cl,BYTE PTR [rcx+0x40]
  40a35f:	cmp    cl,0x7
  40a362:	jb     40a3a5 <__swc_fn_4fa09e82_000147_43f4fdca+0x265>
  40a364:	je     40a418 <__swc_fn_4fa09e82_000147_43f4fdca+0x2d8>
  40a36a:	cmp    cl,0x8
  40a36d:	je     40a424 <__swc_fn_4fa09e82_000147_43f4fdca+0x2e4>
  40a373:	cmp    cl,0x9
  40a376:	je     40a43d <__swc_fn_4fa09e82_000147_43f4fdca+0x2fd>
  40a37c:	cmp    cl,0xa
  40a37f:	je     40ab24 <__swc_fn_4fa09e82_000147_43f4fdca+0x9e4>
  40a385:	cmp    cl,0xb
  40a388:	je     40b20b <__swc_fn_4fa09e82_000147_43f4fdca+0x10cb>
  40a38e:	cmp    cl,0xc
  40a391:	je     40a431 <__swc_fn_4fa09e82_000147_43f4fdca+0x2f1>
  40a397:	cmp    cl,0xd
  40a39a:	je     40b201 <__swc_fn_4fa09e82_000147_43f4fdca+0x10c1>
  40a3a0:	jmp    40b22b <__swc_fn_4fa09e82_000147_43f4fdca+0x10eb>
  40a3a5:	cmp    cl,0x1
  40a3a8:	je     40a3c8 <__swc_fn_4fa09e82_000147_43f4fdca+0x288>
  40a3aa:	cmp    cl,0x2
  40a3ad:	je     40a3d6 <__swc_fn_4fa09e82_000147_43f4fdca+0x296>
  40a3af:	cmp    cl,0x3
  40a3b2:	je     40a3e4 <__swc_fn_4fa09e82_000147_43f4fdca+0x2a4>
  40a3b4:	cmp    cl,0x4
  40a3b7:	je     40a3f1 <__swc_fn_4fa09e82_000147_43f4fdca+0x2b1>
  40a3b9:	cmp    cl,0x5
  40a3bc:	je     40a3fe <__swc_fn_4fa09e82_000147_43f4fdca+0x2be>
  40a3be:	cmp    cl,0x6
  40a3c1:	je     40a40b <__swc_fn_4fa09e82_000147_43f4fdca+0x2cb>
  40a3c3:	jmp    40b22b <__swc_fn_4fa09e82_000147_43f4fdca+0x10eb>
  40a3c8:	movsx  rcx,BYTE PTR [rdx]
  40a3cc:	call   411a40 <__swc_fn_4fa09e82_000146_863755b5>
  40a3d1:	jmp    40b245 <__swc_fn_4fa09e82_000147_43f4fdca+0x1105>
  40a3d6:	movsx  rcx,WORD PTR [rdx]
  40a3da:	call   411a40 <__swc_fn_4fa09e82_000146_863755b5>
  40a3df:	jmp    40b245 <__swc_fn_4fa09e82_000147_43f4fdca+0x1105>
  40a3e4:	movsxd rcx,DWORD PTR [rdx]
  40a3e7:	call   411a40 <__swc_fn_4fa09e82_000146_863755b5>
  40a3ec:	jmp    40b245 <__swc_fn_4fa09e82_000147_43f4fdca+0x1105>
  40a3f1:	mov    rcx,QWORD PTR [rdx]
  40a3f4:	call   411a40 <__swc_fn_4fa09e82_000146_863755b5>
  40a3f9:	jmp    40b245 <__swc_fn_4fa09e82_000147_43f4fdca+0x1105>
  40a3fe:	movzx  ecx,BYTE PTR [rdx]
  40a401:	call   40ebf0 <__swc_fn_4fa09e82_000145_72996a5b>
  40a406:	jmp    40b245 <__swc_fn_4fa09e82_000147_43f4fdca+0x1105>
  40a40b:	movzx  ecx,WORD PTR [rdx]
  40a40e:	call   40ebf0 <__swc_fn_4fa09e82_000145_72996a5b>
  40a413:	jmp    40b245 <__swc_fn_4fa09e82_000147_43f4fdca+0x1105>
  40a418:	mov    ecx,DWORD PTR [rdx]
  40a41a:	call   40ebf0 <__swc_fn_4fa09e82_000145_72996a5b>
  40a41f:	jmp    40b245 <__swc_fn_4fa09e82_000147_43f4fdca+0x1105>
  40a424:	mov    rcx,QWORD PTR [rdx]
  40a427:	call   40ebf0 <__swc_fn_4fa09e82_000145_72996a5b>
  40a42c:	jmp    40b245 <__swc_fn_4fa09e82_000147_43f4fdca+0x1105>
  40a431:	mov    ecx,DWORD PTR [rdx]
  40a433:	call   40ebf0 <__swc_fn_4fa09e82_000145_72996a5b>
  40a438:	jmp    40b245 <__swc_fn_4fa09e82_000147_43f4fdca+0x1105>
  40a43d:	lea    rcx,[rsp+0xa8]
  40a445:	vxorps xmm0,xmm0,xmm0
  40a449:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40a452:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40a45b:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  40a464:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  40a46d:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40a476:	vmovups XMMWORD PTR [rsp+0xf8],xmm0
  40a47f:	mov    DWORD PTR [rsp+0x108],0x0
  40a48a:	vxorpd xmm0,xmm0,xmm0
  40a48e:	vmovss xmm1,DWORD PTR [rdx]
  40a492:	vcvtss2sd xmm0,xmm0,xmm1
  40a496:	vmovsd xmm1,xmm1,xmm0
  40a49a:	vcomisd xmm0,xmm0
  40a49e:	setne  dl
  40a4a1:	movzx  edx,dl
  40a4a4:	setp   r8b
  40a4a8:	movzx  r8d,r8b
  40a4ac:	or     edx,r8d
  40a4af:	test   dl,dl
  40a4b1:	je     40a4be <__swc_fn_4fa09e82_000147_43f4fdca+0x37e>
  40a4b3:	mov    DWORD PTR [rcx],0x6e616e
  40a4b9:	jmp    40aab8 <__swc_fn_4fa09e82_000147_43f4fdca+0x978>
  40a4be:	vcomisd xmm1,xmm6
  40a4c2:	ja     40a4ca <__swc_fn_4fa09e82_000147_43f4fdca+0x38a>
  40a4c4:	vcomisd xmm7,xmm1
  40a4c8:	jbe    40a4ee <__swc_fn_4fa09e82_000147_43f4fdca+0x3ae>
  40a4ca:	vxorpd xmm0,xmm0,xmm0
  40a4ce:	vcomisd xmm0,xmm1
  40a4d2:	jbe    40a4e3 <__swc_fn_4fa09e82_000147_43f4fdca+0x3a3>
  40a4d4:	mov    DWORD PTR [rcx],0x666e692d
  40a4da:	mov    BYTE PTR [rcx+0x4],0x0
  40a4de:	jmp    40aab8 <__swc_fn_4fa09e82_000147_43f4fdca+0x978>
  40a4e3:	mov    DWORD PTR [rcx],0x666e69
  40a4e9:	jmp    40aab8 <__swc_fn_4fa09e82_000147_43f4fdca+0x978>
  40a4ee:	vcomisd xmm1,xmm8
  40a4f3:	jae    40a4ff <__swc_fn_4fa09e82_000147_43f4fdca+0x3bf>
  40a4f5:	vcomisd xmm9,xmm1
  40a4f9:	jbe    40a87e <__swc_fn_4fa09e82_000147_43f4fdca+0x73e>
  40a4ff:	vmovups xmm0,xmm1
  40a503:	vxorpd xmm2,xmm2,xmm2
  40a507:	vcomisd xmm2,xmm1
  40a50b:	jbe    40a51b <__swc_fn_4fa09e82_000147_43f4fdca+0x3db>
  40a50d:	vmovsd xmm1,xmm1,xmm0
  40a511:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x9037]        # 413550 <__swc_rdata_base_4fa09e82+0x440>
  40a519:	jmp    40a51f <__swc_fn_4fa09e82_000147_43f4fdca+0x3df>
  40a51b:	vmovsd xmm1,xmm1,xmm0
  40a51f:	xor    r8d,r8d
  40a522:	vcomisd xmm1,xmm15
  40a527:	jb     40a550 <__swc_fn_4fa09e82_000147_43f4fdca+0x410>
  40a529:	cs nop WORD PTR [rax+rax*1+0x0]
  40a533:	cs nop WORD PTR [rax+rax*1+0x0]
  40a53d:	nop    DWORD PTR [rax]
  40a540:	vdivsd xmm1,xmm1,xmm15
  40a545:	add    r8,0x1
  40a549:	vcomisd xmm1,xmm15
  40a54e:	jae    40a540 <__swc_fn_4fa09e82_000147_43f4fdca+0x400>
  40a550:	mov    r9,rcx
  40a553:	vxorpd xmm2,xmm2,xmm2
  40a557:	vcomisd xmm2,xmm0
  40a55b:	jbe    40a564 <__swc_fn_4fa09e82_000147_43f4fdca+0x424>
  40a55d:	mov    BYTE PTR [rcx],0x2d
  40a560:	lea    r9,[rcx+0x1]
  40a564:	vcvttsd2si rdx,xmm1
  40a569:	mov    r10b,dl
  40a56c:	add    r10b,0x30
  40a570:	mov    BYTE PTR [r9],r10b
  40a573:	vxorpd xmm0,xmm0,xmm0
  40a577:	movzx  edx,dl
  40a57a:	vcvtsi2sd xmm0,xmm0,rdx
  40a57f:	vsubsd xmm0,xmm1,xmm0
  40a583:	vmulsd xmm1,xmm0,xmm15
  40a588:	mov    BYTE PTR [r9+0x1],0x2e
  40a58d:	vcvttsd2si rdx,xmm1
  40a592:	mov    r10b,dl
  40a595:	add    r10b,0x30
  40a599:	mov    BYTE PTR [r9+0x2],r10b
  40a59d:	vxorpd xmm0,xmm0,xmm0
  40a5a1:	movzx  edx,dl
  40a5a4:	vcvtsi2sd xmm0,xmm0,rdx
  40a5a9:	vsubsd xmm0,xmm1,xmm0
  40a5ad:	vmulsd xmm1,xmm0,xmm15
  40a5b2:	vcvttsd2si rdx,xmm1
  40a5b7:	mov    r10b,dl
  40a5ba:	add    r10b,0x30
  40a5be:	mov    BYTE PTR [r9+0x3],r10b
  40a5c2:	vxorpd xmm0,xmm0,xmm0
  40a5c6:	movzx  edx,dl
  40a5c9:	vcvtsi2sd xmm0,xmm0,rdx
  40a5ce:	vsubsd xmm0,xmm1,xmm0
  40a5d2:	vmulsd xmm1,xmm0,xmm15
  40a5d7:	vcvttsd2si rdx,xmm1
  40a5dc:	mov    r10b,dl
  40a5df:	add    r10b,0x30
  40a5e3:	mov    BYTE PTR [r9+0x4],r10b
  40a5e7:	vxorpd xmm0,xmm0,xmm0
  40a5eb:	movzx  edx,dl
  40a5ee:	vcvtsi2sd xmm0,xmm0,rdx
  40a5f3:	vsubsd xmm0,xmm1,xmm0
  40a5f7:	vmulsd xmm1,xmm0,xmm15
  40a5fc:	vcvttsd2si rdx,xmm1
  40a601:	mov    r10b,dl
  40a604:	add    r10b,0x30
  40a608:	mov    BYTE PTR [r9+0x5],r10b
  40a60c:	vxorpd xmm0,xmm0,xmm0
  40a610:	movzx  edx,dl
  40a613:	vcvtsi2sd xmm0,xmm0,rdx
  40a618:	vsubsd xmm0,xmm1,xmm0
  40a61c:	vmulsd xmm1,xmm0,xmm15
  40a621:	vcvttsd2si rdx,xmm1
  40a626:	mov    r10b,dl
  40a629:	add    r10b,0x30
  40a62d:	mov    BYTE PTR [r9+0x6],r10b
  40a631:	vxorpd xmm0,xmm0,xmm0
  40a635:	movzx  edx,dl
  40a638:	vcvtsi2sd xmm0,xmm0,rdx
  40a63d:	vsubsd xmm0,xmm1,xmm0
  40a641:	vmulsd xmm1,xmm0,xmm15
  40a646:	vcvttsd2si rdx,xmm1
  40a64b:	mov    r10b,dl
  40a64e:	add    r10b,0x30
  40a652:	mov    BYTE PTR [r9+0x7],r10b
  40a656:	vxorpd xmm0,xmm0,xmm0
  40a65a:	movzx  edx,dl
  40a65d:	vcvtsi2sd xmm0,xmm0,rdx
  40a662:	vsubsd xmm0,xmm1,xmm0
  40a666:	vmulsd xmm1,xmm0,xmm15
  40a66b:	vcvttsd2si rdx,xmm1
  40a670:	mov    r10b,dl
  40a673:	add    r10b,0x30
  40a677:	mov    BYTE PTR [r9+0x8],r10b
  40a67b:	vxorpd xmm0,xmm0,xmm0
  40a67f:	movzx  edx,dl
  40a682:	vcvtsi2sd xmm0,xmm0,rdx
  40a687:	vsubsd xmm0,xmm1,xmm0
  40a68b:	vmulsd xmm1,xmm0,xmm15
  40a690:	vcvttsd2si rdx,xmm1
  40a695:	mov    r10b,dl
  40a698:	add    r10b,0x30
  40a69c:	mov    BYTE PTR [r9+0x9],r10b
  40a6a0:	vxorpd xmm0,xmm0,xmm0
  40a6a4:	movzx  edx,dl
  40a6a7:	vcvtsi2sd xmm0,xmm0,rdx
  40a6ac:	vsubsd xmm0,xmm1,xmm0
  40a6b0:	vmulsd xmm1,xmm0,xmm15
  40a6b5:	vcvttsd2si rdx,xmm1
  40a6ba:	mov    r10b,dl
  40a6bd:	add    r10b,0x30
  40a6c1:	mov    BYTE PTR [r9+0xa],r10b
  40a6c5:	vxorpd xmm0,xmm0,xmm0
  40a6c9:	movzx  edx,dl
  40a6cc:	vcvtsi2sd xmm0,xmm0,rdx
  40a6d1:	vsubsd xmm0,xmm1,xmm0
  40a6d5:	vmulsd xmm1,xmm0,xmm15
  40a6da:	vcvttsd2si rdx,xmm1
  40a6df:	mov    r10b,dl
  40a6e2:	add    r10b,0x30
  40a6e6:	mov    BYTE PTR [r9+0xb],r10b
  40a6ea:	lea    r10,[r9+0x4]
  40a6ee:	vxorpd xmm0,xmm0,xmm0
  40a6f2:	movzx  edx,dl
  40a6f5:	vcvtsi2sd xmm0,xmm0,rdx
  40a6fa:	vsubsd xmm0,xmm1,xmm0
  40a6fe:	vmulsd xmm1,xmm0,xmm15
  40a703:	vcvttsd2si rdx,xmm1
  40a708:	mov    r11b,dl
  40a70b:	add    r11b,0x30
  40a70f:	mov    BYTE PTR [r9+0xc],r11b
  40a713:	vxorpd xmm0,xmm0,xmm0
  40a717:	movzx  edx,dl
  40a71a:	vcvtsi2sd xmm0,xmm0,rdx
  40a71f:	vsubsd xmm0,xmm1,xmm0
  40a723:	vmulsd xmm1,xmm0,xmm15
  40a728:	vcvttsd2si rdx,xmm1
  40a72d:	mov    r11b,dl
  40a730:	add    r11b,0x30
  40a734:	mov    BYTE PTR [r9+0xd],r11b
  40a738:	lea    r10,[r10+0x2]
  40a73c:	vxorpd xmm0,xmm0,xmm0
  40a740:	movzx  edx,dl
  40a743:	vcvtsi2sd xmm0,xmm0,rdx
  40a748:	vsubsd xmm0,xmm1,xmm0
  40a74c:	vmulsd xmm1,xmm0,xmm15
  40a751:	vcvttsd2si rdx,xmm1
  40a756:	mov    r11b,dl
  40a759:	add    r11b,0x30
  40a75d:	mov    BYTE PTR [r9+0xe],r11b
  40a761:	vxorpd xmm0,xmm0,xmm0
  40a765:	movzx  edx,dl
  40a768:	vcvtsi2sd xmm0,xmm0,rdx
  40a76d:	vsubsd xmm0,xmm1,xmm0
  40a771:	vmulsd xmm1,xmm0,xmm15
  40a776:	vcvttsd2si rdx,xmm1
  40a77b:	mov    r11b,dl
  40a77e:	add    r11b,0x30
  40a782:	mov    BYTE PTR [r9+0xf],r11b
  40a786:	lea    r10,[r10+0x2]
  40a78a:	lea    r10,[r10+0x2]
  40a78e:	lea    r10,[r10+0x2]
  40a792:	lea    r10,[r10+0x2]
  40a796:	lea    r10,[r10+0x2]
  40a79a:	vxorpd xmm0,xmm0,xmm0
  40a79e:	movzx  edx,dl
  40a7a1:	vcvtsi2sd xmm0,xmm0,rdx
  40a7a6:	vsubsd xmm0,xmm1,xmm0
  40a7aa:	vmulsd xmm1,xmm0,xmm15
  40a7af:	vcvttsd2si rdx,xmm1
  40a7b4:	mov    r11b,dl
  40a7b7:	add    r11b,0x30
  40a7bb:	mov    BYTE PTR [r9+0x10],r11b
  40a7bf:	vxorpd xmm0,xmm0,xmm0
  40a7c3:	movzx  edx,dl
  40a7c6:	vcvtsi2sd xmm0,xmm0,rdx
  40a7cb:	vsubsd xmm0,xmm1,xmm0
  40a7cf:	vmulsd xmm1,xmm0,xmm15
  40a7d4:	vcvttsd2si rdx,xmm1
  40a7d9:	add    dl,0x30
  40a7dc:	mov    BYTE PTR [r9+0x11],dl
  40a7e0:	mov    BYTE PTR [r10+0x2],0x65
  40a7e5:	lea    r9,[r10+0x3]
  40a7e9:	test   r8,r8
  40a7ec:	jl     40a7f5 <__swc_fn_4fa09e82_000147_43f4fdca+0x6b5>
  40a7ee:	mov    BYTE PTR [r9],0x2b
  40a7f2:	inc    r9
  40a7f5:	mov    r10,r9
  40a7f8:	mov    rdx,r8
  40a7fb:	nop    DWORD PTR [rax+rax*1+0x0]
  40a800:	mov    r11,rdx
  40a803:	movabs rdx,0x6666666666666667
  40a80d:	mov    rax,r11
  40a810:	imul   rdx
  40a813:	sar    rdx,0x2
  40a817:	mov    r12,rdx
  40a81a:	shr    rdx,0x3f
  40a81e:	add    r12,rdx
  40a821:	mov    rdx,r12
  40a824:	imul   r13,r12,0xa
  40a828:	sub    r11,r13
  40a82b:	mov    r13,QWORD PTR [rip+0x8d0e]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40a832:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40a837:	mov    BYTE PTR [r10],r11b
  40a83a:	lea    r11,[r10+0x1]
  40a83e:	mov    r10,r11
  40a841:	test   r12,r12
  40a844:	jne    40a800 <__swc_fn_4fa09e82_000147_43f4fdca+0x6c0>
  40a846:	test   r8,r8
  40a849:	jge    40a853 <__swc_fn_4fa09e82_000147_43f4fdca+0x713>
  40a84b:	mov    BYTE PTR [r11],0x2d
  40a84f:	lea    r10,[r11+0x1]
  40a853:	mov    BYTE PTR [r10],0x0
  40a857:	sub    r10,0x1
  40a85b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a860:	cmp    r9,r10
  40a863:	jae    40aab8 <__swc_fn_4fa09e82_000147_43f4fdca+0x978>
  40a869:	mov    al,BYTE PTR [r10]
  40a86c:	mov    dl,BYTE PTR [r9]
  40a86f:	mov    BYTE PTR [r10],dl
  40a872:	sub    r10,0x1
  40a876:	mov    BYTE PTR [r9],al
  40a879:	inc    r9
  40a87c:	jmp    40a860 <__swc_fn_4fa09e82_000147_43f4fdca+0x720>
  40a87e:	vcvttsd2si rdx,xmm1
  40a883:	mov    r8,rdx
  40a886:	vxorpd xmm0,xmm0,xmm0
  40a88a:	vcvtsi2sd xmm0,xmm0,rdx
  40a88f:	vsubsd xmm0,xmm1,xmm0
  40a893:	mov    r9d,0x8
  40a899:	vxorpd xmm2,xmm2,xmm2
  40a89d:	vcomisd xmm2,xmm0
  40a8a1:	jbe    40a8ab <__swc_fn_4fa09e82_000147_43f4fdca+0x76b>
  40a8a3:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x8ca5]        # 413550 <__swc_rdata_base_4fa09e82+0x440>
  40a8ab:	test   r9d,r9d
  40a8ae:	je     40a8ba <__swc_fn_4fa09e82_000147_43f4fdca+0x77a>
  40a8b0:	vmulsd xmm0,xmm0,xmm14
  40a8b5:	dec    r9d
  40a8b8:	jne    40a8b0 <__swc_fn_4fa09e82_000147_43f4fdca+0x770>
  40a8ba:	vcvttsd2si r9,xmm0
  40a8bf:	mov    r10,r9
  40a8c2:	vxorpd xmm2,xmm2,xmm2
  40a8c6:	vcvtsi2sd xmm2,xmm2,r9
  40a8cb:	vsubsd xmm0,xmm0,xmm2
  40a8cf:	vcomisd xmm0,xmm10
  40a8d4:	lea    r9,[r9+0x1]
  40a8d8:	cmova  r10,r9
  40a8dc:	cmp    r10,0x5f5e100
  40a8e3:	jne    40a8fc <__swc_fn_4fa09e82_000147_43f4fdca+0x7bc>
  40a8e5:	lea    r8,[rdx-0x1]
  40a8e9:	vxorpd xmm0,xmm0,xmm0
  40a8ed:	vcomisd xmm0,xmm1
  40a8f1:	lea    rdx,[rdx+0x1]
  40a8f5:	cmovbe r8,rdx
  40a8f9:	xor    r10d,r10d
  40a8fc:	mov    r9,rcx
  40a8ff:	test   r8,r8
  40a902:	jne    40a922 <__swc_fn_4fa09e82_000147_43f4fdca+0x7e2>
  40a904:	vxorpd xmm0,xmm0,xmm0
  40a908:	vcomisd xmm0,xmm1
  40a90c:	jbe    40a915 <__swc_fn_4fa09e82_000147_43f4fdca+0x7d5>
  40a90e:	mov    BYTE PTR [rcx],0x2d
  40a911:	lea    r9,[rcx+0x1]
  40a915:	mov    BYTE PTR [r9],0x30
  40a919:	add    r9,0x1
  40a91d:	jmp    40a9bb <__swc_fn_4fa09e82_000147_43f4fdca+0x87b>
  40a922:	mov    r9,rcx
  40a925:	mov    rdx,r8
  40a928:	nop    DWORD PTR [rax+rax*1+0x0]
  40a930:	mov    r11,rdx
  40a933:	movabs rdx,0x6666666666666667
  40a93d:	mov    r15,rax
  40a940:	mov    rax,r11
  40a943:	imul   rdx
  40a946:	mov    r12,rdx
  40a949:	mov    rax,r15
  40a94c:	sar    r12,0x2
  40a950:	mov    rdx,r12
  40a953:	shr    rdx,0x3f
  40a957:	add    r12,rdx
  40a95a:	mov    rdx,r12
  40a95d:	imul   r13,r12,0xa
  40a961:	sub    r11,r13
  40a964:	mov    r13,QWORD PTR [rip+0x8bd5]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40a96b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40a970:	mov    BYTE PTR [r9],r11b
  40a973:	lea    r11,[r9+0x1]
  40a977:	mov    r9,r11
  40a97a:	test   r12,r12
  40a97d:	jne    40a930 <__swc_fn_4fa09e82_000147_43f4fdca+0x7f0>
  40a97f:	test   r8,r8
  40a982:	jge    40a98c <__swc_fn_4fa09e82_000147_43f4fdca+0x84c>
  40a984:	mov    BYTE PTR [r11],0x2d
  40a988:	lea    r9,[r11+0x1]
  40a98c:	mov    rdx,r9
  40a98f:	mov    BYTE PTR [r9],0x0
  40a993:	sub    r9,0x1
  40a997:	mov    r8,rcx
  40a99a:	cmp    r8,r9
  40a99d:	jae    40a9b8 <__swc_fn_4fa09e82_000147_43f4fdca+0x878>
  40a99f:	nop
  40a9a0:	mov    r11b,BYTE PTR [r9]
  40a9a3:	mov    r12b,BYTE PTR [r8]
  40a9a6:	mov    BYTE PTR [r9],r12b
  40a9a9:	sub    r9,0x1
  40a9ad:	mov    BYTE PTR [r8],r11b
  40a9b0:	inc    r8
  40a9b3:	cmp    r8,r9
  40a9b6:	jb     40a9a0 <__swc_fn_4fa09e82_000147_43f4fdca+0x860>
  40a9b8:	mov    r9,rdx
  40a9bb:	mov    BYTE PTR [r9],0x2e
  40a9bf:	add    r9,0x1
  40a9c3:	xor    r8d,r8d
  40a9c6:	test   r10,r10
  40a9c9:	je     40aa0f <__swc_fn_4fa09e82_000147_43f4fdca+0x8cf>
  40a9cb:	mov    r11d,0x989680
  40a9d1:	cmp    r10,r11
  40a9d4:	jge    40aa0f <__swc_fn_4fa09e82_000147_43f4fdca+0x8cf>
  40a9d6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9e0:	inc    r8d
  40a9e3:	movabs rdx,0x6666666666666667
  40a9ed:	mov    r15,rax
  40a9f0:	mov    rax,r11
  40a9f3:	imul   rdx
  40a9f6:	mov    r11,rdx
  40a9f9:	mov    rax,r15
  40a9fc:	sar    r11,0x2
  40aa00:	mov    rdx,r11
  40aa03:	shr    rdx,0x3f
  40aa07:	add    r11,rdx
  40aa0a:	cmp    r10,r11
  40aa0d:	jl     40a9e0 <__swc_fn_4fa09e82_000147_43f4fdca+0x8a0>
  40aa0f:	test   r8d,r8d
  40aa12:	je     40aa2d <__swc_fn_4fa09e82_000147_43f4fdca+0x8ed>
  40aa14:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa1e:	xchg   ax,ax
  40aa20:	mov    BYTE PTR [r9],0x30
  40aa24:	add    r9,0x1
  40aa28:	dec    r8d
  40aa2b:	jne    40aa20 <__swc_fn_4fa09e82_000147_43f4fdca+0x8e0>
  40aa2d:	mov    r8,r9
  40aa30:	mov    rdx,r10
  40aa33:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa3d:	nop    DWORD PTR [rax]
  40aa40:	mov    r11,rdx
  40aa43:	movabs rdx,0x6666666666666667
  40aa4d:	mov    rax,r11
  40aa50:	imul   rdx
  40aa53:	sar    rdx,0x2
  40aa57:	mov    r12,rdx
  40aa5a:	shr    rdx,0x3f
  40aa5e:	add    r12,rdx
  40aa61:	mov    rdx,r12
  40aa64:	imul   r13,r12,0xa
  40aa68:	sub    r11,r13
  40aa6b:	mov    r13,QWORD PTR [rip+0x8ace]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40aa72:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40aa77:	mov    BYTE PTR [r8],r11b
  40aa7a:	lea    r11,[r8+0x1]
  40aa7e:	mov    r8,r11
  40aa81:	test   r12,r12
  40aa84:	jne    40aa40 <__swc_fn_4fa09e82_000147_43f4fdca+0x900>
  40aa86:	test   r10,r10
  40aa89:	jge    40aa93 <__swc_fn_4fa09e82_000147_43f4fdca+0x953>
  40aa8b:	mov    BYTE PTR [r11],0x2d
  40aa8f:	lea    r8,[r11+0x1]
  40aa93:	mov    BYTE PTR [r8],0x0
  40aa97:	sub    r8,0x1
  40aa9b:	cmp    r9,r8
  40aa9e:	jae    40aab8 <__swc_fn_4fa09e82_000147_43f4fdca+0x978>
  40aaa0:	mov    al,BYTE PTR [r8]
  40aaa3:	mov    dl,BYTE PTR [r9]
  40aaa6:	mov    BYTE PTR [r8],dl
  40aaa9:	sub    r8,0x1
  40aaad:	mov    BYTE PTR [r9],al
  40aab0:	inc    r9
  40aab3:	cmp    r9,r8
  40aab6:	jb     40aaa0 <__swc_fn_4fa09e82_000147_43f4fdca+0x960>
  40aab8:	xor    eax,eax
  40aaba:	test   rcx,rcx
  40aabd:	je     40aaf0 <__swc_fn_4fa09e82_000147_43f4fdca+0x9b0>
  40aabf:	mov    rdx,rcx
  40aac2:	mov    r8b,BYTE PTR [rdx]
  40aac5:	test   r8b,r8b
  40aac8:	je     40aaf0 <__swc_fn_4fa09e82_000147_43f4fdca+0x9b0>
  40aaca:	cs nop WORD PTR [rax+rax*1+0x0]
  40aad4:	cs nop WORD PTR [rax+rax*1+0x0]
  40aade:	xchg   ax,ax
  40aae0:	add    rdx,0x1
  40aae4:	add    rax,0x1
  40aae8:	mov    r8b,BYTE PTR [rdx]
  40aaeb:	test   r8b,r8b
  40aaee:	jne    40aae0 <__swc_fn_4fa09e82_000147_43f4fdca+0x9a0>
  40aaf0:	mov    QWORD PTR [rsp+0x240],rcx
  40aaf8:	mov    QWORD PTR [rsp+0x248],rax
  40ab00:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  40ab09:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  40ab12:	lea    rcx,[rsp+0x250]
  40ab1a:	call   4098c0 <__swc_fn_4fa09e82_000117_035d76a1>
  40ab1f:	jmp    40b245 <__swc_fn_4fa09e82_000147_43f4fdca+0x1105>
  40ab24:	lea    rcx,[rsp+0x260]
  40ab2c:	vxorps xmm0,xmm0,xmm0
  40ab30:	vmovups XMMWORD PTR [rsp+0x260],xmm0
  40ab39:	vmovups XMMWORD PTR [rsp+0x270],xmm0
  40ab42:	vmovups XMMWORD PTR [rsp+0x280],xmm0
  40ab4b:	vmovups XMMWORD PTR [rsp+0x290],xmm0
  40ab54:	vmovups XMMWORD PTR [rsp+0x2a0],xmm0
  40ab5d:	vmovups XMMWORD PTR [rsp+0x2b0],xmm0
  40ab66:	mov    DWORD PTR [rsp+0x2c0],0x0
  40ab71:	vmovsd xmm0,QWORD PTR [rdx]
  40ab75:	vcomisd xmm0,xmm0
  40ab79:	setne  dl
  40ab7c:	movzx  edx,dl
  40ab7f:	setp   r8b
  40ab83:	movzx  r8d,r8b
  40ab87:	or     edx,r8d
  40ab8a:	test   dl,dl
  40ab8c:	je     40ab99 <__swc_fn_4fa09e82_000147_43f4fdca+0xa59>
  40ab8e:	mov    DWORD PTR [rcx],0x6e616e
  40ab94:	jmp    40b1a8 <__swc_fn_4fa09e82_000147_43f4fdca+0x1068>
  40ab99:	vcomisd xmm0,xmm11
  40ab9e:	ja     40abaf <__swc_fn_4fa09e82_000147_43f4fdca+0xa6f>
  40aba0:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  40aba9:	vcomisd xmm6,xmm0
  40abad:	jbe    40abd3 <__swc_fn_4fa09e82_000147_43f4fdca+0xa93>
  40abaf:	vxorpd xmm1,xmm1,xmm1
  40abb3:	vcomisd xmm1,xmm0
  40abb7:	jbe    40abc8 <__swc_fn_4fa09e82_000147_43f4fdca+0xa88>
  40abb9:	mov    DWORD PTR [rcx],0x666e692d
  40abbf:	mov    BYTE PTR [rcx+0x4],0x0
  40abc3:	jmp    40b1a8 <__swc_fn_4fa09e82_000147_43f4fdca+0x1068>
  40abc8:	mov    DWORD PTR [rcx],0x666e69
  40abce:	jmp    40b1a8 <__swc_fn_4fa09e82_000147_43f4fdca+0x1068>
  40abd3:	vcomisd xmm0,xmm13
  40abd8:	jae    40abe4 <__swc_fn_4fa09e82_000147_43f4fdca+0xaa4>
  40abda:	vcomisd xmm12,xmm0
  40abde:	jbe    40af4e <__swc_fn_4fa09e82_000147_43f4fdca+0xe0e>
  40abe4:	vmovups xmm1,xmm0
  40abe8:	vxorpd xmm2,xmm2,xmm2
  40abec:	vcomisd xmm2,xmm0
  40abf0:	jbe    40ac00 <__swc_fn_4fa09e82_000147_43f4fdca+0xac0>
  40abf2:	vmovsd xmm0,xmm0,xmm1
  40abf6:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x8952]        # 413550 <__swc_rdata_base_4fa09e82+0x440>
  40abfe:	jmp    40ac04 <__swc_fn_4fa09e82_000147_43f4fdca+0xac4>
  40ac00:	vmovsd xmm0,xmm0,xmm1
  40ac04:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  40ac0d:	xor    r8d,r8d
  40ac10:	vcomisd xmm0,xmm6
  40ac14:	jb     40ac2e <__swc_fn_4fa09e82_000147_43f4fdca+0xaee>
  40ac16:	cs nop WORD PTR [rax+rax*1+0x0]
  40ac20:	vdivsd xmm0,xmm0,xmm6
  40ac24:	add    r8,0x1
  40ac28:	vcomisd xmm0,xmm6
  40ac2c:	jae    40ac20 <__swc_fn_4fa09e82_000147_43f4fdca+0xae0>
  40ac2e:	mov    r9,rcx
  40ac31:	vxorpd xmm2,xmm2,xmm2
  40ac35:	vcomisd xmm2,xmm1
  40ac39:	jbe    40ac42 <__swc_fn_4fa09e82_000147_43f4fdca+0xb02>
  40ac3b:	mov    BYTE PTR [rcx],0x2d
  40ac3e:	lea    r9,[rcx+0x1]
  40ac42:	vcvttsd2si rdx,xmm0
  40ac47:	mov    r10b,dl
  40ac4a:	add    r10b,0x30
  40ac4e:	mov    BYTE PTR [r9],r10b
  40ac51:	vxorpd xmm1,xmm1,xmm1
  40ac55:	movzx  edx,dl
  40ac58:	vcvtsi2sd xmm1,xmm1,rdx
  40ac5d:	vsubsd xmm0,xmm0,xmm1
  40ac61:	vmulsd xmm0,xmm0,xmm6
  40ac65:	mov    BYTE PTR [r9+0x1],0x2e
  40ac6a:	vcvttsd2si rdx,xmm0
  40ac6f:	mov    r10b,dl
  40ac72:	add    r10b,0x30
  40ac76:	mov    BYTE PTR [r9+0x2],r10b
  40ac7a:	vxorpd xmm1,xmm1,xmm1
  40ac7e:	movzx  edx,dl
  40ac81:	vcvtsi2sd xmm1,xmm1,rdx
  40ac86:	vsubsd xmm0,xmm0,xmm1
  40ac8a:	vmulsd xmm0,xmm0,xmm6
  40ac8e:	vcvttsd2si rdx,xmm0
  40ac93:	mov    r10b,dl
  40ac96:	add    r10b,0x30
  40ac9a:	mov    BYTE PTR [r9+0x3],r10b
  40ac9e:	vxorpd xmm1,xmm1,xmm1
  40aca2:	movzx  edx,dl
  40aca5:	vcvtsi2sd xmm1,xmm1,rdx
  40acaa:	vsubsd xmm0,xmm0,xmm1
  40acae:	vmulsd xmm0,xmm0,xmm6
  40acb2:	vcvttsd2si rdx,xmm0
  40acb7:	mov    r10b,dl
  40acba:	add    r10b,0x30
  40acbe:	mov    BYTE PTR [r9+0x4],r10b
  40acc2:	vxorpd xmm1,xmm1,xmm1
  40acc6:	movzx  edx,dl
  40acc9:	vcvtsi2sd xmm1,xmm1,rdx
  40acce:	vsubsd xmm0,xmm0,xmm1
  40acd2:	vmulsd xmm0,xmm0,xmm6
  40acd6:	vcvttsd2si rdx,xmm0
  40acdb:	mov    r10b,dl
  40acde:	add    r10b,0x30
  40ace2:	mov    BYTE PTR [r9+0x5],r10b
  40ace6:	vxorpd xmm1,xmm1,xmm1
  40acea:	movzx  edx,dl
  40aced:	vcvtsi2sd xmm1,xmm1,rdx
  40acf2:	vsubsd xmm0,xmm0,xmm1
  40acf6:	vmulsd xmm0,xmm0,xmm6
  40acfa:	vcvttsd2si rdx,xmm0
  40acff:	mov    r10b,dl
  40ad02:	add    r10b,0x30
  40ad06:	mov    BYTE PTR [r9+0x6],r10b
  40ad0a:	vxorpd xmm1,xmm1,xmm1
  40ad0e:	movzx  edx,dl
  40ad11:	vcvtsi2sd xmm1,xmm1,rdx
  40ad16:	vsubsd xmm0,xmm0,xmm1
  40ad1a:	vmulsd xmm0,xmm0,xmm6
  40ad1e:	vcvttsd2si rdx,xmm0
  40ad23:	mov    r10b,dl
  40ad26:	add    r10b,0x30
  40ad2a:	mov    BYTE PTR [r9+0x7],r10b
  40ad2e:	vxorpd xmm1,xmm1,xmm1
  40ad32:	movzx  edx,dl
  40ad35:	vcvtsi2sd xmm1,xmm1,rdx
  40ad3a:	vsubsd xmm0,xmm0,xmm1
  40ad3e:	vmulsd xmm0,xmm0,xmm6
  40ad42:	vcvttsd2si rdx,xmm0
  40ad47:	mov    r10b,dl
  40ad4a:	add    r10b,0x30
  40ad4e:	mov    BYTE PTR [r9+0x8],r10b
  40ad52:	vxorpd xmm1,xmm1,xmm1
  40ad56:	movzx  edx,dl
  40ad59:	vcvtsi2sd xmm1,xmm1,rdx
  40ad5e:	vsubsd xmm0,xmm0,xmm1
  40ad62:	vmulsd xmm0,xmm0,xmm6
  40ad66:	vcvttsd2si rdx,xmm0
  40ad6b:	mov    r10b,dl
  40ad6e:	add    r10b,0x30
  40ad72:	mov    BYTE PTR [r9+0x9],r10b
  40ad76:	vxorpd xmm1,xmm1,xmm1
  40ad7a:	movzx  edx,dl
  40ad7d:	vcvtsi2sd xmm1,xmm1,rdx
  40ad82:	vsubsd xmm0,xmm0,xmm1
  40ad86:	vmulsd xmm0,xmm0,xmm6
  40ad8a:	vcvttsd2si rdx,xmm0
  40ad8f:	mov    r10b,dl
  40ad92:	add    r10b,0x30
  40ad96:	mov    BYTE PTR [r9+0xa],r10b
  40ad9a:	vxorpd xmm1,xmm1,xmm1
  40ad9e:	movzx  edx,dl
  40ada1:	vcvtsi2sd xmm1,xmm1,rdx
  40ada6:	vsubsd xmm0,xmm0,xmm1
  40adaa:	vmulsd xmm0,xmm0,xmm6
  40adae:	vcvttsd2si rdx,xmm0
  40adb3:	mov    r10b,dl
  40adb6:	add    r10b,0x30
  40adba:	mov    BYTE PTR [r9+0xb],r10b
  40adbe:	lea    r10,[r9+0x4]
  40adc2:	vxorpd xmm1,xmm1,xmm1
  40adc6:	movzx  edx,dl
  40adc9:	vcvtsi2sd xmm1,xmm1,rdx
  40adce:	vsubsd xmm0,xmm0,xmm1
  40add2:	vmulsd xmm0,xmm0,xmm6
  40add6:	vcvttsd2si rdx,xmm0
  40addb:	mov    r11b,dl
  40adde:	add    r11b,0x30
  40ade2:	mov    BYTE PTR [r9+0xc],r11b
  40ade6:	vxorpd xmm1,xmm1,xmm1
  40adea:	movzx  edx,dl
  40aded:	vcvtsi2sd xmm1,xmm1,rdx
  40adf2:	vsubsd xmm0,xmm0,xmm1
  40adf6:	vmulsd xmm0,xmm0,xmm6
  40adfa:	vcvttsd2si rdx,xmm0
  40adff:	mov    r11b,dl
  40ae02:	add    r11b,0x30
  40ae06:	mov    BYTE PTR [r9+0xd],r11b
  40ae0a:	lea    r10,[r10+0x2]
  40ae0e:	vxorpd xmm1,xmm1,xmm1
  40ae12:	movzx  edx,dl
  40ae15:	vcvtsi2sd xmm1,xmm1,rdx
  40ae1a:	vsubsd xmm0,xmm0,xmm1
  40ae1e:	vmulsd xmm0,xmm0,xmm6
  40ae22:	vcvttsd2si rdx,xmm0
  40ae27:	mov    r11b,dl
  40ae2a:	add    r11b,0x30
  40ae2e:	mov    BYTE PTR [r9+0xe],r11b
  40ae32:	vxorpd xmm1,xmm1,xmm1
  40ae36:	movzx  edx,dl
  40ae39:	vcvtsi2sd xmm1,xmm1,rdx
  40ae3e:	vsubsd xmm0,xmm0,xmm1
  40ae42:	vmulsd xmm0,xmm0,xmm6
  40ae46:	vcvttsd2si rdx,xmm0
  40ae4b:	mov    r11b,dl
  40ae4e:	add    r11b,0x30
  40ae52:	mov    BYTE PTR [r9+0xf],r11b
  40ae56:	lea    r10,[r10+0x2]
  40ae5a:	lea    r10,[r10+0x2]
  40ae5e:	lea    r10,[r10+0x2]
  40ae62:	lea    r10,[r10+0x2]
  40ae66:	lea    r10,[r10+0x2]
  40ae6a:	vxorpd xmm1,xmm1,xmm1
  40ae6e:	movzx  edx,dl
  40ae71:	vcvtsi2sd xmm1,xmm1,rdx
  40ae76:	vsubsd xmm0,xmm0,xmm1
  40ae7a:	vmulsd xmm0,xmm0,xmm6
  40ae7e:	vcvttsd2si rdx,xmm0
  40ae83:	mov    r11b,dl
  40ae86:	add    r11b,0x30
  40ae8a:	mov    BYTE PTR [r9+0x10],r11b
  40ae8e:	vxorpd xmm1,xmm1,xmm1
  40ae92:	movzx  edx,dl
  40ae95:	vcvtsi2sd xmm1,xmm1,rdx
  40ae9a:	vsubsd xmm0,xmm0,xmm1
  40ae9e:	vmulsd xmm0,xmm0,xmm6
  40aea2:	vcvttsd2si rdx,xmm0
  40aea7:	add    dl,0x30
  40aeaa:	mov    BYTE PTR [r9+0x11],dl
  40aeae:	mov    BYTE PTR [r10+0x2],0x65
  40aeb3:	lea    r9,[r10+0x3]
  40aeb7:	test   r8,r8
  40aeba:	jl     40aec3 <__swc_fn_4fa09e82_000147_43f4fdca+0xd83>
  40aebc:	mov    BYTE PTR [r9],0x2b
  40aec0:	inc    r9
  40aec3:	mov    r10,r9
  40aec6:	mov    rdx,r8
  40aec9:	nop    DWORD PTR [rax+0x0]
  40aed0:	mov    r11,rdx
  40aed3:	movabs rdx,0x6666666666666667
  40aedd:	mov    rax,r11
  40aee0:	imul   rdx
  40aee3:	sar    rdx,0x2
  40aee7:	mov    r12,rdx
  40aeea:	shr    rdx,0x3f
  40aeee:	add    r12,rdx
  40aef1:	mov    rdx,r12
  40aef4:	imul   r13,r12,0xa
  40aef8:	sub    r11,r13
  40aefb:	mov    r13,QWORD PTR [rip+0x863e]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40af02:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40af07:	mov    BYTE PTR [r10],r11b
  40af0a:	lea    r11,[r10+0x1]
  40af0e:	mov    r10,r11
  40af11:	test   r12,r12
  40af14:	jne    40aed0 <__swc_fn_4fa09e82_000147_43f4fdca+0xd90>
  40af16:	test   r8,r8
  40af19:	jge    40af23 <__swc_fn_4fa09e82_000147_43f4fdca+0xde3>
  40af1b:	mov    BYTE PTR [r11],0x2d
  40af1f:	lea    r10,[r11+0x1]
  40af23:	mov    BYTE PTR [r10],0x0
  40af27:	sub    r10,0x1
  40af2b:	nop    DWORD PTR [rax+rax*1+0x0]
  40af30:	cmp    r9,r10
  40af33:	jae    40b1a8 <__swc_fn_4fa09e82_000147_43f4fdca+0x1068>
  40af39:	mov    al,BYTE PTR [r10]
  40af3c:	mov    dl,BYTE PTR [r9]
  40af3f:	mov    BYTE PTR [r10],dl
  40af42:	sub    r10,0x1
  40af46:	mov    BYTE PTR [r9],al
  40af49:	inc    r9
  40af4c:	jmp    40af30 <__swc_fn_4fa09e82_000147_43f4fdca+0xdf0>
  40af4e:	vcvttsd2si rdx,xmm0
  40af53:	mov    r8,rdx
  40af56:	vxorpd xmm1,xmm1,xmm1
  40af5a:	vcvtsi2sd xmm1,xmm1,rdx
  40af5f:	vsubsd xmm1,xmm0,xmm1
  40af63:	mov    r9d,0x8
  40af69:	vxorpd xmm2,xmm2,xmm2
  40af6d:	vcomisd xmm2,xmm1
  40af71:	ja     40af7e <__swc_fn_4fa09e82_000147_43f4fdca+0xe3e>
  40af73:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40af7c:	jmp    40af8f <__swc_fn_4fa09e82_000147_43f4fdca+0xe4f>
  40af7e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x85ca]        # 413550 <__swc_rdata_base_4fa09e82+0x440>
  40af86:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40af8f:	test   r9d,r9d
  40af92:	je     40afa9 <__swc_fn_4fa09e82_000147_43f4fdca+0xe69>
  40af94:	cs nop WORD PTR [rax+rax*1+0x0]
  40af9e:	xchg   ax,ax
  40afa0:	vmulsd xmm1,xmm1,xmm6
  40afa4:	dec    r9d
  40afa7:	jne    40afa0 <__swc_fn_4fa09e82_000147_43f4fdca+0xe60>
  40afa9:	vcvttsd2si r9,xmm1
  40afae:	mov    r10,r9
  40afb1:	vxorpd xmm2,xmm2,xmm2
  40afb5:	vcvtsi2sd xmm2,xmm2,r9
  40afba:	vsubsd xmm1,xmm1,xmm2
  40afbe:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  40afc7:	vcomisd xmm1,xmm6
  40afcb:	lea    r9,[r9+0x1]
  40afcf:	cmova  r10,r9
  40afd3:	cmp    r10,0x5f5e100
  40afda:	jne    40aff3 <__swc_fn_4fa09e82_000147_43f4fdca+0xeb3>
  40afdc:	lea    r8,[rdx-0x1]
  40afe0:	vxorpd xmm1,xmm1,xmm1
  40afe4:	vcomisd xmm1,xmm0
  40afe8:	lea    rdx,[rdx+0x1]
  40afec:	cmovbe r8,rdx
  40aff0:	xor    r10d,r10d
  40aff3:	mov    r9,rcx
  40aff6:	test   r8,r8
  40aff9:	jne    40b019 <__swc_fn_4fa09e82_000147_43f4fdca+0xed9>
  40affb:	vxorpd xmm1,xmm1,xmm1
  40afff:	vcomisd xmm1,xmm0
  40b003:	jbe    40b00c <__swc_fn_4fa09e82_000147_43f4fdca+0xecc>
  40b005:	mov    BYTE PTR [rcx],0x2d
  40b008:	lea    r9,[rcx+0x1]
  40b00c:	mov    BYTE PTR [r9],0x30
  40b010:	add    r9,0x1
  40b014:	jmp    40b0ab <__swc_fn_4fa09e82_000147_43f4fdca+0xf6b>
  40b019:	mov    r9,rcx
  40b01c:	mov    rdx,r8
  40b01f:	nop
  40b020:	mov    r11,rdx
  40b023:	movabs rdx,0x6666666666666667
  40b02d:	mov    r15,rax
  40b030:	mov    rax,r11
  40b033:	imul   rdx
  40b036:	mov    r12,rdx
  40b039:	mov    rax,r15
  40b03c:	sar    r12,0x2
  40b040:	mov    rdx,r12
  40b043:	shr    rdx,0x3f
  40b047:	add    r12,rdx
  40b04a:	mov    rdx,r12
  40b04d:	imul   r13,r12,0xa
  40b051:	sub    r11,r13
  40b054:	mov    r13,QWORD PTR [rip+0x84e5]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40b05b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b060:	mov    BYTE PTR [r9],r11b
  40b063:	lea    r11,[r9+0x1]
  40b067:	mov    r9,r11
  40b06a:	test   r12,r12
  40b06d:	jne    40b020 <__swc_fn_4fa09e82_000147_43f4fdca+0xee0>
  40b06f:	test   r8,r8
  40b072:	jge    40b07c <__swc_fn_4fa09e82_000147_43f4fdca+0xf3c>
  40b074:	mov    BYTE PTR [r11],0x2d
  40b078:	lea    r9,[r11+0x1]
  40b07c:	mov    rdx,r9
  40b07f:	mov    BYTE PTR [r9],0x0
  40b083:	sub    r9,0x1
  40b087:	mov    r8,rcx
  40b08a:	cmp    r8,r9
  40b08d:	jae    40b0a8 <__swc_fn_4fa09e82_000147_43f4fdca+0xf68>
  40b08f:	nop
  40b090:	mov    r11b,BYTE PTR [r9]
  40b093:	mov    r12b,BYTE PTR [r8]
  40b096:	mov    BYTE PTR [r9],r12b
  40b099:	sub    r9,0x1
  40b09d:	mov    BYTE PTR [r8],r11b
  40b0a0:	inc    r8
  40b0a3:	cmp    r8,r9
  40b0a6:	jb     40b090 <__swc_fn_4fa09e82_000147_43f4fdca+0xf50>
  40b0a8:	mov    r9,rdx
  40b0ab:	mov    BYTE PTR [r9],0x2e
  40b0af:	add    r9,0x1
  40b0b3:	xor    r8d,r8d
  40b0b6:	test   r10,r10
  40b0b9:	je     40b0ff <__swc_fn_4fa09e82_000147_43f4fdca+0xfbf>
  40b0bb:	mov    r11d,0x989680
  40b0c1:	cmp    r10,r11
  40b0c4:	jge    40b0ff <__swc_fn_4fa09e82_000147_43f4fdca+0xfbf>
  40b0c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40b0d0:	inc    r8d
  40b0d3:	movabs rdx,0x6666666666666667
  40b0dd:	mov    r15,rax
  40b0e0:	mov    rax,r11
  40b0e3:	imul   rdx
  40b0e6:	mov    r11,rdx
  40b0e9:	mov    rax,r15
  40b0ec:	sar    r11,0x2
  40b0f0:	mov    rdx,r11
  40b0f3:	shr    rdx,0x3f
  40b0f7:	add    r11,rdx
  40b0fa:	cmp    r10,r11
  40b0fd:	jl     40b0d0 <__swc_fn_4fa09e82_000147_43f4fdca+0xf90>
  40b0ff:	test   r8d,r8d
  40b102:	je     40b11d <__swc_fn_4fa09e82_000147_43f4fdca+0xfdd>
  40b104:	cs nop WORD PTR [rax+rax*1+0x0]
  40b10e:	xchg   ax,ax
  40b110:	mov    BYTE PTR [r9],0x30
  40b114:	add    r9,0x1
  40b118:	dec    r8d
  40b11b:	jne    40b110 <__swc_fn_4fa09e82_000147_43f4fdca+0xfd0>
  40b11d:	mov    r8,r9
  40b120:	mov    rdx,r10
  40b123:	cs nop WORD PTR [rax+rax*1+0x0]
  40b12d:	nop    DWORD PTR [rax]
  40b130:	mov    r11,rdx
  40b133:	movabs rdx,0x6666666666666667
  40b13d:	mov    rax,r11
  40b140:	imul   rdx
  40b143:	sar    rdx,0x2
  40b147:	mov    r12,rdx
  40b14a:	shr    rdx,0x3f
  40b14e:	add    r12,rdx
  40b151:	mov    rdx,r12
  40b154:	imul   r13,r12,0xa
  40b158:	sub    r11,r13
  40b15b:	mov    r13,QWORD PTR [rip+0x83de]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40b162:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b167:	mov    BYTE PTR [r8],r11b
  40b16a:	lea    r11,[r8+0x1]
  40b16e:	mov    r8,r11
  40b171:	test   r12,r12
  40b174:	jne    40b130 <__swc_fn_4fa09e82_000147_43f4fdca+0xff0>
  40b176:	test   r10,r10
  40b179:	jge    40b183 <__swc_fn_4fa09e82_000147_43f4fdca+0x1043>
  40b17b:	mov    BYTE PTR [r11],0x2d
  40b17f:	lea    r8,[r11+0x1]
  40b183:	mov    BYTE PTR [r8],0x0
  40b187:	sub    r8,0x1
  40b18b:	cmp    r9,r8
  40b18e:	jae    40b1a8 <__swc_fn_4fa09e82_000147_43f4fdca+0x1068>
  40b190:	mov    al,BYTE PTR [r8]
  40b193:	mov    dl,BYTE PTR [r9]
  40b196:	mov    BYTE PTR [r8],dl
  40b199:	sub    r8,0x1
  40b19d:	mov    BYTE PTR [r9],al
  40b1a0:	inc    r9
  40b1a3:	cmp    r9,r8
  40b1a6:	jb     40b190 <__swc_fn_4fa09e82_000147_43f4fdca+0x1050>
  40b1a8:	xor    eax,eax
  40b1aa:	test   rcx,rcx
  40b1ad:	je     40b1d0 <__swc_fn_4fa09e82_000147_43f4fdca+0x1090>
  40b1af:	mov    rdx,rcx
  40b1b2:	mov    r8b,BYTE PTR [rdx]
  40b1b5:	test   r8b,r8b
  40b1b8:	je     40b1d0 <__swc_fn_4fa09e82_000147_43f4fdca+0x1090>
  40b1ba:	nop    WORD PTR [rax+rax*1+0x0]
  40b1c0:	add    rdx,0x1
  40b1c4:	add    rax,0x1
  40b1c8:	mov    r8b,BYTE PTR [rdx]
  40b1cb:	test   r8b,r8b
  40b1ce:	jne    40b1c0 <__swc_fn_4fa09e82_000147_43f4fdca+0x1080>
  40b1d0:	mov    QWORD PTR [rsp+0x3f8],rcx
  40b1d8:	mov    QWORD PTR [rsp+0x400],rax
  40b1e0:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  40b1e9:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  40b1f2:	lea    rcx,[rsp+0x408]
  40b1fa:	call   4098c0 <__swc_fn_4fa09e82_000117_035d76a1>
  40b1ff:	jmp    40b245 <__swc_fn_4fa09e82_000147_43f4fdca+0x1105>
  40b201:	mov    rcx,rdx
  40b204:	call   4098c0 <__swc_fn_4fa09e82_000117_035d76a1>
  40b209:	jmp    40b245 <__swc_fn_4fa09e82_000147_43f4fdca+0x1105>
  40b20b:	mov    al,BYTE PTR [rdx]
  40b20d:	test   al,al
  40b20f:	je     40b21a <__swc_fn_4fa09e82_000147_43f4fdca+0x10da>
  40b211:	lea    rax,[rip+0x8348]        # 413560 <__swc_rdata_base_4fa09e82+0x450>
  40b218:	jmp    40b221 <__swc_fn_4fa09e82_000147_43f4fdca+0x10e1>
  40b21a:	lea    rax,[rip+0x834f]        # 413570 <__swc_rdata_base_4fa09e82+0x460>
  40b221:	mov    rcx,rax
  40b224:	call   4098c0 <__swc_fn_4fa09e82_000117_035d76a1>
  40b229:	jmp    40b245 <__swc_fn_4fa09e82_000147_43f4fdca+0x1105>
  40b22b:	lea    rcx,[rip+0x834e]        # 413580 <__swc_rdata_base_4fa09e82+0x470>
  40b232:	call   4098c0 <__swc_fn_4fa09e82_000117_035d76a1>
  40b237:	jmp    40b245 <__swc_fn_4fa09e82_000147_43f4fdca+0x1105>
  40b239:	lea    rcx,[rip+0x8340]        # 413580 <__swc_rdata_base_4fa09e82+0x470>
  40b240:	call   4098c0 <__swc_fn_4fa09e82_000117_035d76a1>
  40b245:	add    rdi,0x1
  40b249:	sub    rsi,0x1
  40b24d:	vmovups xmm0,xmm12
  40b252:	vmovsd xmm6,QWORD PTR [rip+0x8336]        # 413590 <__swc_rdata_base_4fa09e82+0x480>
  40b25a:	test   rsi,rsi
  40b25d:	jne    40a250 <__swc_fn_4fa09e82_000147_43f4fdca+0x110>
  40b263:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  40b26c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  40b275:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  40b27e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  40b287:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  40b290:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  40b299:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  40b2a2:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  40b2ab:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  40b2b4:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  40b2bd:	add    rsp,0x4e8
  40b2c4:	pop    r15
  40b2c6:	pop    r13
  40b2c8:	pop    r12
  40b2ca:	pop    rdi
  40b2cb:	pop    rsi
  40b2cc:	pop    rbx
  40b2cd:	ret
	...

000000000040b2d0 <__swc_fn_4fa09e82_000150_9e4bc402>:
  40b2d0:	vxorps xmm0,xmm0,xmm0
  40b2d4:	vmovups XMMWORD PTR [rcx],xmm0
  40b2d8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b2dd:	ret
	...

000000000040b2e0 <__swc_fn_4fa09e82_000153_9e4bc402>:
  40b2e0:	vxorps xmm0,xmm0,xmm0
  40b2e4:	vmovups XMMWORD PTR [rcx],xmm0
  40b2e8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b2ed:	vxorps xmm0,xmm0,xmm0
  40b2f1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b2f6:	vmovups xmm0,XMMWORD PTR [rip+0x83a2]        # 4136a0 <__swc_rdata_base_4fa09e82+0x590>
  40b2fe:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b303:	vxorps xmm0,xmm0,xmm0
  40b307:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40b30c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40b311:	vxorps xmm0,xmm0,xmm0
  40b315:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40b31a:	mov    QWORD PTR [rcx+0x70],0x0
  40b322:	ret
	...

000000000040b330 <__swc_fn_4fa09e82_000156_9e4bc402>:
  40b330:	vxorps xmm0,xmm0,xmm0
  40b334:	vmovups XMMWORD PTR [rcx],xmm0
  40b338:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b33d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b342:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b347:	ret
	...

000000000040b350 <__swc_fn_4fa09e82_000159_b43b2f96>:
  40b350:	push   rsi
  40b351:	push   rdi
  40b352:	sub    rsp,0x8
  40b356:	mov    rsi,rcx
  40b359:	mov    rdi,QWORD PTR [rsi+0x50]
  40b35d:	test   rdi,rdi
  40b360:	je     40b367 <__swc_fn_4fa09e82_000159_b43b2f96+0x17>
  40b362:	mov    rcx,rsi
  40b365:	call   rdi
  40b367:	mov    QWORD PTR [rsi+0x20],0x0
  40b36f:	mov    rax,QWORD PTR [rsi+0x30]
  40b373:	test   rax,rax
  40b376:	je     40b3a4 <__swc_fn_4fa09e82_000159_b43b2f96+0x54>
  40b378:	nop    DWORD PTR [rax+rax*1+0x0]
  40b380:	mov    rdi,QWORD PTR [rax+0x8]
  40b384:	mov    rcx,rsi
  40b387:	mov    rdx,QWORD PTR [rax+0x10]
  40b38b:	mov    rax,QWORD PTR [rax+0x18]
  40b38f:	mov    r8,rax
  40b392:	call   40ede0 <__swc_fn_4fa09e82_000157_2745c4a5>
  40b397:	mov    QWORD PTR [rsi+0x30],rdi
  40b39b:	mov    rax,QWORD PTR [rsi+0x30]
  40b39f:	test   rax,rax
  40b3a2:	jne    40b380 <__swc_fn_4fa09e82_000159_b43b2f96+0x30>
  40b3a4:	mov    QWORD PTR [rsi+0x38],0x0
  40b3ac:	add    rsp,0x8
  40b3b0:	pop    rdi
  40b3b1:	pop    rsi
  40b3b2:	ret
	...

000000000040b3c0 <__swc_fn_4fa09e82_000162_b5a9d657>:
  40b3c0:	push   rbx
  40b3c1:	push   rsi
  40b3c2:	push   rdi
  40b3c3:	push   r12
  40b3c5:	sub    rsp,0x188
  40b3cc:	mov    rbx,rcx
  40b3cf:	lea    rsi,[rip+0x1b9ba]        # 426d90 <__swc_bss_base_4fa09e82+0x2d50>
  40b3d6:	mov    rcx,rsi
  40b3d9:	call   40e7e0 <__swc_fn_4fa09e82_000136_e3032dc2>
  40b3de:	mov    rax,QWORD PTR [rip+0x1b9b3]        # 426d98 <__swc_bss_base_4fa09e82+0x2d58>
  40b3e5:	mov    rdi,rax
  40b3e8:	test   rdi,rdi
  40b3eb:	je     40b419 <__swc_fn_4fa09e82_000162_b5a9d657+0x59>
  40b3ed:	nop    DWORD PTR [rax]
  40b3f0:	cmp    QWORD PTR [rdi+0x8],rbx
  40b3f4:	jne    40b40e <__swc_fn_4fa09e82_000162_b5a9d657+0x4e>
  40b3f6:	mov    rcx,rsi
  40b3f9:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40b3fe:	mov    rax,rdi
  40b401:	add    rsp,0x188
  40b408:	pop    r12
  40b40a:	pop    rdi
  40b40b:	pop    rsi
  40b40c:	pop    rbx
  40b40d:	ret
  40b40e:	mov    rax,QWORD PTR [rdi]
  40b411:	mov    rdi,rax
  40b414:	test   rax,rax
  40b417:	jne    40b3f0 <__swc_fn_4fa09e82_000162_b5a9d657+0x30>
  40b419:	call   411960 <__swc_fn_4fa09e82_000140_7c02fe26>
  40b41e:	mov    rdi,rax
  40b421:	test   rax,rax
  40b424:	jne    40b43d <__swc_fn_4fa09e82_000162_b5a9d657+0x7d>
  40b426:	mov    rcx,rsi
  40b429:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40b42e:	xor    eax,eax
  40b430:	add    rsp,0x188
  40b437:	pop    r12
  40b439:	pop    rdi
  40b43a:	pop    rsi
  40b43b:	pop    rbx
  40b43c:	ret
  40b43d:	lea    rax,[rsp+0x18]
  40b442:	mov    QWORD PTR [rax+0x10],0x0
  40b44a:	mov    QWORD PTR [rax+0x18],0x0
  40b452:	mov    DWORD PTR [rax+0x20],0x0
  40b459:	mov    BYTE PTR [rax+0x24],0x0
  40b45d:	mov    rax,QWORD PTR [rip+0x1b934]        # 426d98 <__swc_bss_base_4fa09e82+0x2d58>
  40b464:	mov    QWORD PTR [rsp+0x18],rax
  40b469:	mov    QWORD PTR [rsp+0x20],rbx
  40b46e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40b474:	vmovups XMMWORD PTR [rdi],xmm0
  40b478:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40b47e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  40b483:	mov    rax,QWORD PTR [rsp+0x38]
  40b488:	mov    QWORD PTR [rdi+0x20],rax
  40b48c:	mov    QWORD PTR [rip+0x1b905],rdi        # 426d98 <__swc_bss_base_4fa09e82+0x2d58>
  40b493:	lea    rax,[rsp+0x40]
  40b498:	mov    QWORD PTR [rax],0x0
  40b49f:	mov    rcx,rbx
  40b4a2:	mov    rdx,rax
  40b4a5:	call   40e8c0 <__swc_fn_4fa09e82_000142_2ce79e3b>
  40b4aa:	mov    rbx,rax
  40b4ad:	test   rax,rax
  40b4b0:	jne    40b4ca <__swc_fn_4fa09e82_000162_b5a9d657+0x10a>
  40b4b2:	mov    rcx,rsi
  40b4b5:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40b4ba:	mov    rax,rdi
  40b4bd:	add    rsp,0x188
  40b4c4:	pop    r12
  40b4c6:	pop    rdi
  40b4c7:	pop    rsi
  40b4c8:	pop    rbx
  40b4c9:	ret
  40b4ca:	lea    r12,[rsp+0x50]
  40b4cf:	mov    QWORD PTR [r12],0x0
  40b4d7:	mov    rcx,rbx
  40b4da:	mov    rdx,QWORD PTR [rsp+0x40]
  40b4df:	mov    r8,r12
  40b4e2:	call   411a10 <__swc_fn_4fa09e82_000143_56e56812>
  40b4e7:	test   rax,rax
  40b4ea:	jne    40b504 <__swc_fn_4fa09e82_000162_b5a9d657+0x144>
  40b4ec:	mov    rcx,rsi
  40b4ef:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40b4f4:	mov    rax,rdi
  40b4f7:	add    rsp,0x188
  40b4fe:	pop    r12
  40b500:	pop    rdi
  40b501:	pop    rsi
  40b502:	pop    rbx
  40b503:	ret
  40b504:	cmp    QWORD PTR [r12],0x10
  40b509:	jb     40b60c <__swc_fn_4fa09e82_000162_b5a9d657+0x24c>
  40b50f:	mov    ecx,DWORD PTR [rax]
  40b511:	cmp    ecx,0x42445753
  40b517:	jne    40b60c <__swc_fn_4fa09e82_000162_b5a9d657+0x24c>
  40b51d:	mov    ecx,DWORD PTR [rax+0x4]
  40b520:	cmp    ecx,0x1
  40b523:	jne    40b60c <__swc_fn_4fa09e82_000162_b5a9d657+0x24c>
  40b529:	mov    ecx,DWORD PTR [rax+0x8]
  40b52c:	mov    edx,DWORD PTR [rax+0xc]
  40b52f:	imul   r8,rcx,0x14
  40b533:	mov    r9,QWORD PTR [rsp+0x50]
  40b538:	sub    r9,0x10
  40b53c:	cmp    r8,r9
  40b53f:	ja     40b60c <__swc_fn_4fa09e82_000162_b5a9d657+0x24c>
  40b545:	lea    r8,[r8+0x10]
  40b549:	cmp    rdx,r8
  40b54c:	jb     40b60c <__swc_fn_4fa09e82_000162_b5a9d657+0x24c>
  40b552:	mov    r8,QWORD PTR [rsp+0x50]
  40b557:	cmp    rdx,r8
  40b55a:	ja     40b60c <__swc_fn_4fa09e82_000162_b5a9d657+0x24c>
  40b560:	xor    r8d,r8d
  40b563:	test   rcx,rcx
  40b566:	jbe    40b632 <__swc_fn_4fa09e82_000162_b5a9d657+0x272>
  40b56c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  40b572:	cs nop WORD PTR [rax+rax*1+0x0]
  40b57c:	nop    DWORD PTR [rax+0x0]
  40b580:	imul   r9,r8,0x14
  40b584:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  40b589:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  40b58e:	add    r10,r11
  40b591:	movabs r11,0x100000000
  40b59b:	cmp    r10,r11
  40b59e:	ja     40b60c <__swc_fn_4fa09e82_000162_b5a9d657+0x24c>
  40b5a0:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  40b5a5:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  40b5aa:	test   r10d,r10d
  40b5ad:	setne  r11b
  40b5b1:	je     40b5cb <__swc_fn_4fa09e82_000162_b5a9d657+0x20b>
  40b5b3:	cmp    r10d,edx
  40b5b6:	setb   r11b
  40b5ba:	jb     40b5cb <__swc_fn_4fa09e82_000162_b5a9d657+0x20b>
  40b5bc:	vmovq  r11,xmm1
  40b5c1:	cmp    r10,r11
  40b5c4:	setae  r10b
  40b5c8:	mov    r11b,r10b
  40b5cb:	mov    r10,r11
  40b5ce:	test   r11b,r11b
  40b5d1:	jne    40b5f8 <__swc_fn_4fa09e82_000162_b5a9d657+0x238>
  40b5d3:	test   r9d,r9d
  40b5d6:	setne  r10b
  40b5da:	je     40b5f8 <__swc_fn_4fa09e82_000162_b5a9d657+0x238>
  40b5dc:	cmp    r9d,edx
  40b5df:	setb   r10b
  40b5e3:	jb     40b5f8 <__swc_fn_4fa09e82_000162_b5a9d657+0x238>
  40b5e5:	vmovq  r10,xmm1
  40b5ea:	cmp    r9,r10
  40b5ed:	setae  r9b
  40b5f1:	movzx  r9d,r9b
  40b5f5:	mov    r10b,r9b
  40b5f8:	test   r10b,r10b
  40b5fb:	jne    40b60c <__swc_fn_4fa09e82_000162_b5a9d657+0x24c>
  40b5fd:	add    r8,0x1
  40b601:	cmp    r8,rcx
  40b604:	jb     40b580 <__swc_fn_4fa09e82_000162_b5a9d657+0x1c0>
  40b60a:	jmp    40b632 <__swc_fn_4fa09e82_000162_b5a9d657+0x272>
  40b60c:	xor    ecx,ecx
  40b60e:	cmp    rax,rbx
  40b611:	cmovne rcx,rax
  40b615:	call   40a090 <__swc_fn_4fa09e82_000144_81c0d993>
  40b61a:	mov    rcx,rsi
  40b61d:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40b622:	mov    rax,rdi
  40b625:	add    rsp,0x188
  40b62c:	pop    r12
  40b62e:	pop    rdi
  40b62f:	pop    rsi
  40b630:	pop    rbx
  40b631:	ret
  40b632:	mov    QWORD PTR [rdi+0x10],rax
  40b636:	mov    rcx,QWORD PTR [rsp+0x50]
  40b63b:	mov    QWORD PTR [rdi+0x18],rcx
  40b63f:	mov    eax,DWORD PTR [rax+0x8]
  40b642:	mov    DWORD PTR [rdi+0x20],eax
  40b645:	rex mov BYTE PTR [rdi+0x24],0x1
  40b64a:	mov    rcx,rsi
  40b64d:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40b652:	mov    rax,rdi
  40b655:	add    rsp,0x188
  40b65c:	pop    r12
  40b65e:	pop    rdi
  40b65f:	pop    rsi
  40b660:	pop    rbx
  40b661:	ret
	...

000000000040b670 <__swc_fn_4fa09e82_000165_1962e12a>:
  40b670:	push   rsi
  40b671:	push   rdi
  40b672:	push   r12
  40b674:	mov    rsi,rdx
  40b677:	mov    rdi,rcx
  40b67a:	mov    rcx,QWORD PTR [rip+0x1b6bf]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40b681:	test   rcx,rcx
  40b684:	jne    40b696 <__swc_fn_4fa09e82_000165_1962e12a+0x26>
  40b686:	call   40f0f0 <__swc_fn_4fa09e82_000166_cf398896>
  40b68b:	lea    rcx,[rax+0x1]
  40b68f:	mov    QWORD PTR [rip+0x1b6aa],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40b696:	dec    rcx
  40b699:	call   40b6c0 <__swc_fn_4fa09e82_000168_fce60b2b>
  40b69e:	mov    r12,QWORD PTR [rax+0xbe0]
  40b6a5:	test   r12,r12
  40b6a8:	setne  al
  40b6ab:	je     40b6b6 <__swc_fn_4fa09e82_000165_1962e12a+0x46>
  40b6ad:	mov    rcx,rdi
  40b6b0:	mov    rdx,rsi
  40b6b3:	call   r12
  40b6b6:	pop    r12
  40b6b8:	pop    rdi
  40b6b9:	pop    rsi
  40b6ba:	ret
  40b6bb:	add    BYTE PTR [rax],al
  40b6bd:	add    BYTE PTR [rax],al
	...

000000000040b6c0 <__swc_fn_4fa09e82_000168_fce60b2b>:
  40b6c0:	push   r12
  40b6c2:	push   rdi
  40b6c3:	push   rsi
  40b6c4:	sub    rsp,0xd0
  40b6cb:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40b6d1:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40b6d7:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40b6dd:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40b6e3:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40b6e9:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40b6ef:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40b6f8:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40b701:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40b70a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40b713:	mov    r12,rcx
  40b716:	mov    edi,ecx
  40b718:	xor    eax,eax
  40b71a:	call   407000 <pthread_getspecific@plt>
  40b71f:	test   rax,rax
  40b722:	je     40b726 <__swc_fn_4fa09e82_000168_fce60b2b+0x66>
  40b724:	jmp    40b72e <__swc_fn_4fa09e82_000168_fce60b2b+0x6e>
  40b726:	mov    rcx,r12
  40b729:	call   40f150 <__swc_fn_4fa09e82_000169_92b7d63c>
  40b72e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40b734:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40b73a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40b740:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40b746:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40b74c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40b752:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40b75b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40b764:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40b76d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40b776:	add    rsp,0xd0
  40b77d:	pop    rsi
  40b77e:	pop    rdi
  40b77f:	pop    r12
  40b781:	ret
	...

000000000040b790 <__swc_fn_4fa09e82_000171_fa3003e2>:
  40b790:	push   rsi
  40b791:	sub    rsp,0x30
  40b795:	lea    rsi,[rip+0x1b60c]        # 426da8 <__swc_bss_base_4fa09e82+0x2d68>
  40b79c:	mov    rax,QWORD PTR [rsi]
  40b79f:	test   rax,rax
  40b7a2:	je     40b7aa <__swc_fn_4fa09e82_000171_fa3003e2+0x1a>
  40b7a4:	add    rsp,0x30
  40b7a8:	pop    rsi
  40b7a9:	ret
  40b7aa:	mov    ecx,0x3
  40b7af:	mov    edx,0x10
  40b7b4:	call   4091c0 <__swc_fn_4fa09e82_000108_4796e893>
  40b7b9:	test   rax,rax
  40b7bc:	jne    40b7cd <__swc_fn_4fa09e82_000171_fa3003e2+0x3d>
  40b7be:	mov    QWORD PTR [rsp+0x18],rax
  40b7c3:	call   4114a0 <__swc_fn_4fa09e82_000119_7f430081>
  40b7c8:	mov    rax,QWORD PTR [rsp+0x18]
  40b7cd:	mov    rcx,rax
  40b7d0:	xchg   QWORD PTR [rsi],rcx
  40b7d3:	add    rsp,0x30
  40b7d7:	pop    rsi
  40b7d8:	ret
  40b7d9:	add    BYTE PTR [rax],al
  40b7db:	add    BYTE PTR [rax],al
  40b7dd:	add    BYTE PTR [rax],al
	...

000000000040b7e0 <__swc_fn_4fa09e82_000174_f69b1f05>:
  40b7e0:	push   rsi
  40b7e1:	push   rdi
  40b7e2:	sub    rsp,0x8
  40b7e6:	mov    rsi,rdx
  40b7e9:	mov    rdi,rcx
  40b7ec:	mov    rax,QWORD PTR [rsi+0x8]
  40b7f0:	test   rax,rax
  40b7f3:	je     40b7fd <__swc_fn_4fa09e82_000174_f69b1f05+0x1d>
  40b7f5:	mov    rcx,QWORD PTR [rsi]
  40b7f8:	mov    QWORD PTR [rax],rcx
  40b7fb:	jmp    40b804 <__swc_fn_4fa09e82_000174_f69b1f05+0x24>
  40b7fd:	mov    rax,QWORD PTR [rsi]
  40b800:	mov    QWORD PTR [rdi+0x8],rax
  40b804:	mov    rax,QWORD PTR [rsi]
  40b807:	test   rax,rax
  40b80a:	je     40b814 <__swc_fn_4fa09e82_000174_f69b1f05+0x34>
  40b80c:	mov    rcx,QWORD PTR [rsi+0x8]
  40b810:	mov    QWORD PTR [rax+0x8],rcx
  40b814:	mov    rcx,rdi
  40b817:	mov    rdx,QWORD PTR [rsi+0x10]
  40b81b:	mov    r8,QWORD PTR [rsi+0x18]
  40b81f:	mov    r9,0xffffffffffffffff
  40b826:	call   412080 <__swc_fn_4fa09e82_000173_97fbc432>
  40b82b:	mov    QWORD PTR [rsi+0x18],0x0
  40b833:	mov    rax,QWORD PTR [rdi+0x8]
  40b837:	test   rax,rax
  40b83a:	jne    40b84c <__swc_fn_4fa09e82_000174_f69b1f05+0x6c>
  40b83c:	call   40b790 <__swc_fn_4fa09e82_000171_fa3003e2>
  40b841:	xor    ecx,ecx
  40b843:	mov    QWORD PTR [rax+0x8],rcx
  40b847:	xor    ecx,ecx
  40b849:	mov    QWORD PTR [rax],rcx
  40b84c:	add    rsp,0x8
  40b850:	pop    rdi
  40b851:	pop    rsi
  40b852:	ret
	...

000000000040b860 <__swc_fn_4fa09e82_000177_2744b483>:
  40b860:	push   rbx
  40b861:	sub    rsp,0x70
  40b865:	cmp    rcx,0xffffffffffffffef
  40b869:	jbe    40b873 <__swc_fn_4fa09e82_000177_2744b483+0x13>
  40b86b:	xor    eax,eax
  40b86d:	add    rsp,0x70
  40b871:	pop    rbx
  40b872:	ret
  40b873:	vxorps xmm0,xmm0,xmm0
  40b877:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40b87d:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40b883:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40b889:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40b88f:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40b895:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40b89b:	lea    rax,[rcx+0x10]
  40b89f:	mov    QWORD PTR [rsp+0x50],rax
  40b8a4:	mov    DWORD PTR [rsp+0x60],0x10
  40b8ac:	mov    rcx,QWORD PTR [rip+0x1b48d]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40b8b3:	test   rcx,rcx
  40b8b6:	jne    40b8c8 <__swc_fn_4fa09e82_000177_2744b483+0x68>
  40b8b8:	call   40f0f0 <__swc_fn_4fa09e82_000166_cf398896>
  40b8bd:	lea    rcx,[rax+0x1]
  40b8c1:	mov    QWORD PTR [rip+0x1b478],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40b8c8:	dec    rcx
  40b8cb:	call   40b6c0 <__swc_fn_4fa09e82_000168_fce60b2b>
  40b8d0:	mov    rcx,QWORD PTR [rax]
  40b8d3:	lea    rdx,[rsp+0x8]
  40b8d8:	mov    rbx,QWORD PTR [rax+0x8]
  40b8dc:	mov    rbx,QWORD PTR [rbx+0x8]
  40b8e0:	call   rbx
  40b8e2:	mov    rax,QWORD PTR [rsp+0x48]
  40b8e7:	test   rax,rax
  40b8ea:	jne    40b8f4 <__swc_fn_4fa09e82_000177_2744b483+0x94>
  40b8ec:	xor    eax,eax
  40b8ee:	add    rsp,0x70
  40b8f2:	pop    rbx
  40b8f3:	ret
  40b8f4:	mov    rcx,QWORD PTR [rsp+0x50]
  40b8f9:	mov    QWORD PTR [rax],rcx
  40b8fc:	mov    QWORD PTR [rax+0x8],0x0
  40b904:	lea    rax,[rax+0x10]
  40b908:	add    rsp,0x70
  40b90c:	pop    rbx
  40b90d:	ret
	...

000000000040b920 <__swc_fn_4fa09e82_000180_913db40c>:
  40b920:	push   rbp
  40b921:	push   rbx
  40b922:	push   rsi
  40b923:	push   rdi
  40b924:	push   r12
  40b926:	push   r15
  40b928:	push   r13
  40b92a:	push   r14
  40b92c:	sub    rsp,0x10
  40b930:	mov    rbp,rsp
  40b933:	vmovups XMMWORD PTR [rsp],xmm6
  40b938:	sub    rsp,0x50
  40b93c:	mov    rbx,rsp
  40b93f:	sub    rsp,0x8
  40b943:	mov    ecx,0x13880
  40b948:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  40b94d:	mov    rsi,rax
  40b950:	mov    ecx,0x9c40
  40b955:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  40b95a:	mov    rdi,rax
  40b95d:	mov    ecx,0x9c40
  40b962:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  40b967:	mov    r12,rax
  40b96a:	xor    ecx,ecx
  40b96c:	xor    r8d,r8d
  40b96f:	cs nop WORD PTR [rax+rax*1+0x0]
  40b979:	nop    DWORD PTR [rax+0x0]
  40b980:	lea    r9,[r8+0x1]
  40b984:	mov    r10,r9
  40b987:	movabs rdx,0xaaaaaaaaaaaaaaab
  40b991:	mov    r15,rax
  40b994:	mov    rax,r8
  40b997:	mul    rdx
  40b99a:	mov    r11,rdx
  40b99d:	mov    rax,r15
  40b9a0:	shr    r11,0x2
  40b9a4:	imul   r11,r11,0x6
  40b9a8:	mov    rdx,r8
  40b9ab:	sub    rdx,r11
  40b9ae:	lea    r11,[rdx+0x3]
  40b9b2:	mov    QWORD PTR [rdi+r8*8],rcx
  40b9b6:	mov    QWORD PTR [r12+r8*8],r11
  40b9ba:	xor    r8d,r8d
  40b9bd:	test   r11,r11
  40b9c0:	jbe    40ba14 <__swc_fn_4fa09e82_000180_913db40c+0xf4>
  40b9c2:	xor    r13d,r13d
  40b9c5:	cs nop WORD PTR [rax+rax*1+0x0]
  40b9cf:	nop
  40b9d0:	movabs rdx,0x4ec4ec4ec4ec4ec5
  40b9da:	mov    r15,rax
  40b9dd:	mov    rax,r10
  40b9e0:	mul    rdx
  40b9e3:	mov    r14,rdx
  40b9e6:	mov    rax,r15
  40b9e9:	shr    r14,0x3
  40b9ed:	imul   r14,r14,0x1a
  40b9f1:	sub    r10,r14
  40b9f4:	lea    r10,[r10+0x61]
  40b9f8:	mov    BYTE PTR [rsi+rcx*1],r10b
  40b9fc:	inc    rcx
  40b9ff:	shr    rdx,0x3
  40ba03:	lea    r10,[rdx+r13*1]
  40ba07:	add    r8,0x1
  40ba0b:	add    r13,0x7
  40ba0f:	cmp    r8,r11
  40ba12:	jb     40b9d0 <__swc_fn_4fa09e82_000180_913db40c+0xb0>
  40ba14:	mov    r8,r9
  40ba17:	cmp    r9,0x1388
  40ba1e:	jb     40b980 <__swc_fn_4fa09e82_000180_913db40c+0x60>
  40ba24:	mov    ecx,0x16e3600
  40ba29:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  40ba2e:	mov    QWORD PTR [rip+0x1b39b],rax        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40ba35:	xor    ecx,ecx
  40ba37:	xor    r8d,r8d
  40ba3a:	nop    WORD PTR [rax+rax*1+0x0]
  40ba40:	mov    r9,QWORD PTR [rip+0x165c9]        # 422010 <__swc_data_base_4fa09e82+0x10>
  40ba47:	imul   r9,r9,0x41a7
  40ba4e:	movabs rdx,0x200000005
  40ba58:	mov    r11,rax
  40ba5b:	mov    rax,r9
  40ba5e:	mul    rdx
  40ba61:	mov    r10,rdx
  40ba64:	mov    rdx,r9
  40ba67:	sub    rdx,r10
  40ba6a:	shr    rdx,1
  40ba6d:	add    rdx,r10
  40ba70:	shr    rdx,0x1e
  40ba74:	imul   r10,rdx,0x7fffffff
  40ba7b:	sub    r9,r10
  40ba7e:	mov    QWORD PTR [rip+0x1658b],r9        # 422010 <__swc_data_base_4fa09e82+0x10>
  40ba85:	movabs rdx,0x346dc5d63886594b
  40ba8f:	mov    rax,r9
  40ba92:	mul    rdx
  40ba95:	mov    rax,r11
  40ba98:	shr    rdx,0xa
  40ba9c:	imul   rdx,rdx,0x1388
  40baa3:	sub    r9,rdx
  40baa6:	mov    rdx,QWORD PTR [rdi+r9*8]
  40baaa:	mov    r9,QWORD PTR [r12+r9*8]
  40baae:	xor    r10d,r10d
  40bab1:	test   r9,r9
  40bab4:	jbe    40bad4 <__swc_fn_4fa09e82_000180_913db40c+0x1b4>
  40bab6:	mov    r11,QWORD PTR [rip+0x1b313]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40babd:	add    rdx,rsi
  40bac0:	mov    r13b,BYTE PTR [rdx+r10*1]
  40bac4:	mov    BYTE PTR [r11+rcx*1],r13b
  40bac8:	inc    rcx
  40bacb:	add    r10,0x1
  40bacf:	cmp    r10,r9
  40bad2:	jb     40bac0 <__swc_fn_4fa09e82_000180_913db40c+0x1a0>
  40bad4:	lea    r9,[r8+0x1]
  40bad8:	movabs rdx,0xaaaaaaaaaaaaaaab
  40bae2:	mov    r11,rax
  40bae5:	mov    rax,r9
  40bae8:	mul    rdx
  40baeb:	mov    r8,rdx
  40baee:	mov    rax,r11
  40baf1:	shr    r8,0x3
  40baf5:	imul   r8,r8,0xc
  40baf9:	mov    rdx,r9
  40bafc:	sub    rdx,r8
  40baff:	jne    40bb0e <__swc_fn_4fa09e82_000180_913db40c+0x1ee>
  40bb01:	mov    rdx,QWORD PTR [rip+0x1b2c8]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40bb08:	mov    BYTE PTR [rdx+rcx*1],0xa
  40bb0c:	jmp    40bb19 <__swc_fn_4fa09e82_000180_913db40c+0x1f9>
  40bb0e:	mov    rdx,QWORD PTR [rip+0x1b2bb]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40bb15:	mov    BYTE PTR [rdx+rcx*1],0x20
  40bb19:	lea    r13,[rcx+0x1]
  40bb1d:	mov    r15,r13
  40bb20:	mov    rcx,r13
  40bb23:	mov    r8,r9
  40bb26:	cmp    r9,0x1e8480
  40bb2d:	jb     40ba40 <__swc_fn_4fa09e82_000180_913db40c+0x120>
  40bb33:	mov    QWORD PTR [rsp+0x48],r15
  40bb38:	call   40f2a0 <__swc_fn_4fa09e82_000178_1ca87929>
  40bb3d:	vmovups xmm6,xmm0
  40bb41:	mov    rsi,rbx
  40bb44:	mov    QWORD PTR [rsp+0x50],rsi
  40bb49:	vxorps xmm0,xmm0,xmm0
  40bb4d:	vmovups XMMWORD PTR [rbx],xmm0
  40bb51:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40bb56:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40bb5b:	mov    QWORD PTR [rbx+0x30],0x0
  40bb63:	mov    r8,QWORD PTR [rip+0x1b266]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40bb6a:	mov    rcx,rsi
  40bb6d:	mov    edx,0x4000
  40bb72:	call   412130 <__swc_fn_4fa09e82_000176_e7f0b636>
  40bb77:	xor    edi,edi
  40bb79:	xor    al,al
  40bb7b:	xor    r12d,r12d
  40bb7e:	cmp    r12,r13
  40bb81:	jae    40bcef <__swc_fn_4fa09e82_000180_913db40c+0x3cf>
  40bb87:	nop    WORD PTR [rax+rax*1+0x0]
  40bb90:	mov    rcx,QWORD PTR [rip+0x1b239]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  40bb97:	mov    cl,BYTE PTR [rcx+r12*1]
  40bb9b:	sub    cl,0x61
  40bb9e:	cmp    cl,0x19
  40bba1:	ja     40bbb8 <__swc_fn_4fa09e82_000180_913db40c+0x298>
  40bba3:	test   al,al
  40bba5:	jne    40bcde <__swc_fn_4fa09e82_000180_913db40c+0x3be>
  40bbab:	mov    rdi,r12
  40bbae:	mov    eax,0x1
  40bbb3:	jmp    40bcde <__swc_fn_4fa09e82_000180_913db40c+0x3be>
  40bbb8:	test   al,al
  40bbba:	je     40bcde <__swc_fn_4fa09e82_000180_913db40c+0x3be>
  40bbc0:	mov    r14,r12
  40bbc3:	sub    r14,rdi
  40bbc6:	mov    eax,0x811c9dc5
  40bbcb:	xor    ecx,ecx
  40bbcd:	test   r14,r14
  40bbd0:	jbe    40bc52 <__swc_fn_4fa09e82_000180_913db40c+0x332>
  40bbd6:	mov    rdx,QWORD PTR [rbx+0x20]
  40bbda:	add    rdx,rdi
  40bbdd:	cmp    r14,0x4
  40bbe1:	jb     40bc40 <__swc_fn_4fa09e82_000180_913db40c+0x320>
  40bbe7:	lea    r8,[r14-0x3]
  40bbeb:	cs nop WORD PTR [rax+rax*1+0x0]
  40bbf5:	cs nop WORD PTR [rax+rax*1+0x0]
  40bbff:	nop
  40bc00:	xor    al,BYTE PTR [rdx+rcx*1]
  40bc03:	imul   eax,eax,0x1000193
  40bc09:	xor    al,BYTE PTR [rdx+rcx*1+0x1]
  40bc0d:	imul   eax,eax,0x1000193
  40bc13:	xor    al,BYTE PTR [rdx+rcx*1+0x2]
  40bc17:	imul   eax,eax,0x1000193
  40bc1d:	xor    al,BYTE PTR [rdx+rcx*1+0x3]
  40bc21:	imul   eax,eax,0x1000193
  40bc27:	add    rcx,0x4
  40bc2b:	cmp    rcx,r8
  40bc2e:	jb     40bc00 <__swc_fn_4fa09e82_000180_913db40c+0x2e0>
  40bc30:	cmp    rcx,r14
  40bc33:	jae    40bc52 <__swc_fn_4fa09e82_000180_913db40c+0x332>
  40bc35:	cs nop WORD PTR [rax+rax*1+0x0]
  40bc3f:	nop
  40bc40:	xor    al,BYTE PTR [rdx+rcx*1]
  40bc43:	imul   eax,eax,0x1000193
  40bc49:	add    rcx,0x1
  40bc4d:	cmp    rcx,r14
  40bc50:	jb     40bc40 <__swc_fn_4fa09e82_000180_913db40c+0x320>
  40bc52:	and    rax,QWORD PTR [rbx+0x28]
  40bc56:	mov    r15,rax
  40bc59:	mov    rsi,QWORD PTR [rbx+0x18]
  40bc5d:	mov    r13,QWORD PTR [rbx+0x8]
  40bc61:	cmp    BYTE PTR [rsi+r15*1],0x0
  40bc66:	je     40bca6 <__swc_fn_4fa09e82_000180_913db40c+0x386>
  40bc68:	nop    DWORD PTR [rax+rax*1+0x0]
  40bc70:	cmp    QWORD PTR [r13+r15*8+0x0],r14
  40bc75:	jne    40bc98 <__swc_fn_4fa09e82_000180_913db40c+0x378>
  40bc77:	mov    rax,QWORD PTR [rbx]
  40bc7a:	mov    rax,QWORD PTR [rax+r15*8]
  40bc7e:	mov    rcx,QWORD PTR [rbx+0x20]
  40bc82:	add    rax,rcx
  40bc85:	lea    rdx,[rcx+rdi*1]
  40bc89:	mov    rcx,rax
  40bc8c:	mov    r8,r14
  40bc8f:	call   410f30 <__swc_fn_4fa09e82_000107_ed4b1681>
  40bc94:	test   eax,eax
  40bc96:	je     40bca6 <__swc_fn_4fa09e82_000180_913db40c+0x386>
  40bc98:	inc    r15
  40bc9b:	and    r15,QWORD PTR [rbx+0x28]
  40bc9f:	cmp    BYTE PTR [rsi+r15*1],0x0
  40bca4:	jne    40bc70 <__swc_fn_4fa09e82_000180_913db40c+0x350>
  40bca6:	cmp    BYTE PTR [rsi+r15*1],0x0
  40bcab:	jne    40bcd4 <__swc_fn_4fa09e82_000180_913db40c+0x3b4>
  40bcad:	mov    BYTE PTR [rsi+r15*1],0x1
  40bcb2:	mov    rax,QWORD PTR [rbx]
  40bcb5:	mov    QWORD PTR [rax+r15*8],rdi
  40bcb9:	mov    rax,QWORD PTR [rbx+0x8]
  40bcbd:	mov    QWORD PTR [rax+r15*8],r14
  40bcc1:	mov    rax,QWORD PTR [rbx+0x10]
  40bcc5:	mov    QWORD PTR [rax+r15*8],0x1
  40bccd:	add    QWORD PTR [rbx+0x30],0x1
  40bcd2:	jmp    40bcdc <__swc_fn_4fa09e82_000180_913db40c+0x3bc>
  40bcd4:	mov    rax,QWORD PTR [rbx+0x10]
  40bcd8:	inc    QWORD PTR [rax+r15*8]
  40bcdc:	xor    eax,eax
  40bcde:	inc    r12
  40bce1:	mov    r13,QWORD PTR [rsp+0x48]
  40bce6:	cmp    r12,r13
  40bce9:	jb     40bb90 <__swc_fn_4fa09e82_000180_913db40c+0x270>
  40bcef:	test   al,al
  40bcf1:	je     40be1b <__swc_fn_4fa09e82_000180_913db40c+0x4fb>
  40bcf7:	mov    r13,QWORD PTR [rsp+0x48]
  40bcfc:	sub    r13,rdi
  40bcff:	mov    eax,0x811c9dc5
  40bd04:	xor    ecx,ecx
  40bd06:	test   r13,r13
  40bd09:	jbe    40bd92 <__swc_fn_4fa09e82_000180_913db40c+0x472>
  40bd0f:	mov    rdx,QWORD PTR [rbx+0x20]
  40bd13:	add    rdx,rdi
  40bd16:	cmp    r13,0x4
  40bd1a:	jb     40bd80 <__swc_fn_4fa09e82_000180_913db40c+0x460>
  40bd20:	lea    r8,[r13-0x3]
  40bd24:	cs nop WORD PTR [rax+rax*1+0x0]
  40bd2e:	cs nop WORD PTR [rax+rax*1+0x0]
  40bd38:	nop    DWORD PTR [rax+rax*1+0x0]
  40bd40:	xor    al,BYTE PTR [rdx+rcx*1]
  40bd43:	imul   eax,eax,0x1000193
  40bd49:	xor    al,BYTE PTR [rdx+rcx*1+0x1]
  40bd4d:	imul   eax,eax,0x1000193
  40bd53:	xor    al,BYTE PTR [rdx+rcx*1+0x2]
  40bd57:	imul   eax,eax,0x1000193
  40bd5d:	xor    al,BYTE PTR [rdx+rcx*1+0x3]
  40bd61:	imul   eax,eax,0x1000193
  40bd67:	add    rcx,0x4
  40bd6b:	cmp    rcx,r8
  40bd6e:	jb     40bd40 <__swc_fn_4fa09e82_000180_913db40c+0x420>
  40bd70:	cmp    rcx,r13
  40bd73:	jae    40bd92 <__swc_fn_4fa09e82_000180_913db40c+0x472>
  40bd75:	cs nop WORD PTR [rax+rax*1+0x0]
  40bd7f:	nop
  40bd80:	xor    al,BYTE PTR [rdx+rcx*1]
  40bd83:	imul   eax,eax,0x1000193
  40bd89:	add    rcx,0x1
  40bd8d:	cmp    rcx,r13
  40bd90:	jb     40bd80 <__swc_fn_4fa09e82_000180_913db40c+0x460>
  40bd92:	mov    rsi,QWORD PTR [rsp+0x50]
  40bd97:	and    rax,QWORD PTR [rsi+0x28]
  40bd9b:	mov    r12,rax
  40bd9e:	mov    r14,QWORD PTR [rbx+0x18]
  40bda2:	mov    r15,QWORD PTR [rbx+0x8]
  40bda6:	cmp    BYTE PTR [r14+r12*1],0x0
  40bdab:	je     40bde5 <__swc_fn_4fa09e82_000180_913db40c+0x4c5>
  40bdad:	nop    DWORD PTR [rax]
  40bdb0:	cmp    QWORD PTR [r15+r12*8],r13
  40bdb4:	jne    40bdd7 <__swc_fn_4fa09e82_000180_913db40c+0x4b7>
  40bdb6:	mov    rax,QWORD PTR [rbx]
  40bdb9:	mov    rax,QWORD PTR [rax+r12*8]
  40bdbd:	mov    rcx,QWORD PTR [rbx+0x20]
  40bdc1:	add    rax,rcx
  40bdc4:	lea    rdx,[rcx+rdi*1]
  40bdc8:	mov    rcx,rax
  40bdcb:	mov    r8,r13
  40bdce:	call   410f30 <__swc_fn_4fa09e82_000107_ed4b1681>
  40bdd3:	test   eax,eax
  40bdd5:	je     40bde5 <__swc_fn_4fa09e82_000180_913db40c+0x4c5>
  40bdd7:	inc    r12
  40bdda:	and    r12,QWORD PTR [rbx+0x28]
  40bdde:	cmp    BYTE PTR [r14+r12*1],0x0
  40bde3:	jne    40bdb0 <__swc_fn_4fa09e82_000180_913db40c+0x490>
  40bde5:	cmp    BYTE PTR [r14+r12*1],0x0
  40bdea:	jne    40be13 <__swc_fn_4fa09e82_000180_913db40c+0x4f3>
  40bdec:	mov    BYTE PTR [r14+r12*1],0x1
  40bdf1:	mov    rax,QWORD PTR [rbx]
  40bdf4:	mov    QWORD PTR [rax+r12*8],rdi
  40bdf8:	mov    rax,QWORD PTR [rbx+0x8]
  40bdfc:	mov    QWORD PTR [rax+r12*8],r13
  40be00:	mov    rax,QWORD PTR [rbx+0x10]
  40be04:	mov    QWORD PTR [rax+r12*8],0x1
  40be0c:	add    QWORD PTR [rsi+0x30],0x1
  40be11:	jmp    40be1b <__swc_fn_4fa09e82_000180_913db40c+0x4fb>
  40be13:	mov    rax,QWORD PTR [rbx+0x10]
  40be17:	inc    QWORD PTR [rax+r12*8]
  40be1b:	mov    rsi,QWORD PTR [rbx+0x30]
  40be1f:	lea    rdi,[rsi*8+0x0]
  40be27:	mov    rcx,rdi
  40be2a:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  40be2f:	mov    QWORD PTR [rip+0x1af82],rax        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  40be36:	mov    rcx,rdi
  40be39:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  40be3e:	mov    QWORD PTR [rip+0x1af83],rax        # 426dc8 <__swc_bss_base_4fa09e82+0x2d88>
  40be45:	mov    rcx,rdi
  40be48:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  40be4d:	mov    QWORD PTR [rip+0x1af6c],rax        # 426dc0 <__swc_bss_base_4fa09e82+0x2d80>
  40be54:	mov    rcx,rdi
  40be57:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  40be5c:	mov    QWORD PTR [rip+0x1af4d],rax        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  40be63:	xor    ecx,ecx
  40be65:	xor    edx,edx
  40be67:	mov    r8,QWORD PTR [rip+0x1af4a]        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  40be6e:	mov    r9,QWORD PTR [rip+0x1af53]        # 426dc8 <__swc_bss_base_4fa09e82+0x2d88>
  40be75:	mov    r10,QWORD PTR [rip+0x1af44]        # 426dc0 <__swc_bss_base_4fa09e82+0x2d80>
  40be7c:	cs nop WORD PTR [rax+rax*1+0x0]
  40be86:	cs nop WORD PTR [rax+rax*1+0x0]
  40be90:	mov    r11,QWORD PTR [rbx+0x18]
  40be94:	cmp    BYTE PTR [r11+rdx*1],0x0
  40be99:	je     40bec5 <__swc_fn_4fa09e82_000180_913db40c+0x5a5>
  40be9b:	mov    r11,QWORD PTR [rbx+0x10]
  40be9f:	mov    r11,QWORD PTR [r11+rdx*8]
  40bea3:	mov    QWORD PTR [r8+rcx*8],r11
  40bea7:	mov    r11,QWORD PTR [rbx]
  40beaa:	mov    r11,QWORD PTR [r11+rdx*8]
  40beae:	mov    QWORD PTR [r9+rcx*8],r11
  40beb2:	mov    r11,QWORD PTR [rbx+0x8]
  40beb6:	mov    r11,QWORD PTR [r11+rdx*8]
  40beba:	mov    QWORD PTR [r10+rcx*8],r11
  40bebe:	mov    QWORD PTR [rax+rcx*8],rcx
  40bec2:	inc    rcx
  40bec5:	add    rdx,0x1
  40bec9:	cmp    rdx,0x4000
  40bed0:	jb     40be90 <__swc_fn_4fa09e82_000180_913db40c+0x570>
  40bed2:	xor    ecx,ecx
  40bed4:	lea    rdx,[rsi-0x1]
  40bed8:	call   4121b0 <__swc_fn_4fa09e82_000179_6937fe70>
  40bedd:	imul   rsi,rsi,0x7
  40bee1:	xor    eax,eax
  40bee3:	mov    rcx,QWORD PTR [rip+0x1aec6]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  40beea:	mov    rdx,QWORD PTR [rip+0x1aec7]        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  40bef1:	cs nop WORD PTR [rax+rax*1+0x0]
  40befb:	nop    DWORD PTR [rax+rax*1+0x0]
  40bf00:	lea    r8,[rax+0x1]
  40bf04:	mov    rax,QWORD PTR [rcx+rax*8]
  40bf08:	mov    r9,r8
  40bf0b:	imul   r9,QWORD PTR [rdx+rax*8]
  40bf10:	add    rsi,r9
  40bf13:	mov    rax,r8
  40bf16:	cmp    r8,0x14
  40bf1a:	jb     40bf00 <__swc_fn_4fa09e82_000180_913db40c+0x5e0>
  40bf1c:	call   40f2a0 <__swc_fn_4fa09e82_000178_1ca87929>
  40bf21:	vsubsd xmm0,xmm0,xmm6
  40bf25:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x7a9b]        # 4139c8 <__swc_rdata_base_4fa09e82+0x8b8>
  40bf2d:	lea    rax,[rip+0x7434]        # 413368 <__swc_rdata_base_4fa09e82+0x258>
  40bf34:	sub    rsp,0x88
  40bf3b:	mov    rcx,rsp
  40bf3e:	vmovups xmm1,XMMWORD PTR [rip+0x7a62]        # 4139a8 <__swc_rdata_base_4fa09e82+0x898>
  40bf46:	vmovups XMMWORD PTR [rcx],xmm1
  40bf4a:	mov    QWORD PTR [rcx+0x30],rsp
  40bf4e:	lea    rdx,[rip+0x73bb]        # 413310 <__swc_rdata_base_4fa09e82+0x200>
  40bf55:	mov    QWORD PTR [rcx+0x38],rdx
  40bf59:	mov    QWORD PTR [rcx+0x10],rsi
  40bf5d:	lea    r8,[rsp+0x10]
  40bf62:	mov    QWORD PTR [rcx+0x40],r8
  40bf66:	lea    r8,[rip+0x79ab]        # 413918 <__swc_rdata_base_4fa09e82+0x808>
  40bf6d:	mov    QWORD PTR [rcx+0x48],r8
  40bf71:	vmovups xmm1,XMMWORD PTR [rip+0x7a3f]        # 4139b8 <__swc_rdata_base_4fa09e82+0x8a8>
  40bf79:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40bf7e:	lea    r8,[rsp+0x18]
  40bf83:	mov    QWORD PTR [rcx+0x50],r8
  40bf87:	mov    QWORD PTR [rcx+0x58],rdx
  40bf8b:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40bf90:	lea    r8,[rcx+0x28]
  40bf94:	mov    QWORD PTR [rcx+0x60],r8
  40bf98:	lea    r8,[rip+0x79c1]        # 413960 <__swc_rdata_base_4fa09e82+0x850>
  40bf9f:	mov    QWORD PTR [rcx+0x68],r8
  40bfa3:	mov    QWORD PTR [rcx+0x70],rax
  40bfa7:	mov    QWORD PTR [rcx+0x78],rdx
  40bfab:	lea    rax,[rcx+0x30]
  40bfaf:	mov    QWORD PTR [rcx+0x80],rax
  40bfb6:	mov    QWORD PTR [rcx+0x88],0x5
  40bfc1:	lea    rcx,[rcx+0x80]
  40bfc8:	sub    rsp,0x8
  40bfcc:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  40bfd1:	add    rsp,0xe8
  40bfd8:	vmovups xmm6,XMMWORD PTR [rsp]
  40bfdd:	add    rsp,0x10
  40bfe1:	pop    r14
  40bfe3:	pop    r13
  40bfe5:	pop    r15
  40bfe7:	pop    r12
  40bfe9:	pop    rdi
  40bfea:	pop    rsi
  40bfeb:	pop    rbx
  40bfec:	pop    rbp
  40bfed:	ret
	...

000000000040c000 <__swc_fn_4fa09e82_000001_46f18a51>:
  40c000:	vxorps xmm0,xmm0,xmm0
  40c004:	xor    eax,eax
  40c006:	cs nop WORD PTR [rax+rax*1+0x0]
  40c010:	cs nop WORD PTR [rax+rax*1+0x0]
  40c01a:	nop    WORD PTR [rax+rax*1+0x0]
  40c020:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40c025:	add    rax,0x10
  40c029:	cmp    rax,0x2080
  40c030:	jne    40c020 <__swc_fn_4fa09e82_000001_46f18a51+0x20>
  40c032:	ret
	...

000000000040c040 <__swc_fn_4fa09e82_000004_1acc36a6>:
  40c040:	push   rsi
  40c041:	push   rdi
  40c042:	push   r12
  40c044:	push   r13
  40c046:	push   r14
  40c048:	mov    rsi,rcx
  40c04b:	mov    edi,r10d
  40c04e:	mov    r12,rcx
  40c051:	mov    r13,r9
  40c054:	mov    ecx,DWORD PTR [rdx+0x28]
  40c057:	shlx   r14d,r8d,ecx
  40c05c:	mov    rcx,rdx
  40c05f:	mov    edx,r8d
  40c062:	call   40f460 <__swc_fn_4fa09e82_000011_6493fbbc>
  40c067:	mov    rcx,rax
  40c06a:	mov    eax,DWORD PTR [r12+0x3c]
  40c06f:	xor    edx,edx
  40c071:	div    rdi
  40c074:	vxorps xmm0,xmm0,xmm0
  40c078:	vmovdqu XMMWORD PTR [rsi],xmm0
  40c07c:	mov    QWORD PTR [r12+0x60],0x0
  40c085:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40c08a:	mov    QWORD PTR [r12+0x10],rcx
  40c08f:	imul   rax,rdi
  40c093:	lea    rdx,[rcx+rax*1]
  40c097:	mov    QWORD PTR [r12+0x18],rdx
  40c09c:	mov    QWORD PTR [r12+0x20],rcx
  40c0a1:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40c0a6:	mov    DWORD PTR [r12+0x28],0x0
  40c0af:	mov    DWORD PTR [r12+0x68],0x0
  40c0b8:	mov    BYTE PTR [r12+0x39],r13b
  40c0bd:	mov    BYTE PTR [r12+0x3a],r14b
  40c0c2:	mov    BYTE PTR [r12+0x3b],0x1
  40c0c8:	mov    DWORD PTR [r12+0x6c],0x0
  40c0d1:	mov    rcx,r12
  40c0d4:	mov    edx,edi
  40c0d6:	call   40f3c0 <__swc_fn_4fa09e82_000005_b2240b56>
  40c0db:	pop    r14
  40c0dd:	pop    r13
  40c0df:	pop    r12
  40c0e1:	pop    rdi
  40c0e2:	pop    rsi
  40c0e3:	ret
	...

000000000040c0f0 <__swc_fn_4fa09e82_000007_614a4804>:
  40c0f0:	mov    r8d,0x1
  40c0f6:	xor    eax,eax
  40c0f8:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40c0fe:	test   eax,eax
  40c100:	jne    40c0f0 <__swc_fn_4fa09e82_000007_614a4804>
  40c102:	ret
	...

000000000040c110 <__swc_fn_4fa09e82_000010_395bb04b>:
  40c110:	lea    r8,[rcx+0x60]
  40c114:	mov    rax,QWORD PTR [r8]
  40c117:	mov    r9,rax
  40c11a:	nop    WORD PTR [rax+rax*1+0x0]
  40c120:	mov    QWORD PTR [rdx],r9
  40c123:	mov    rax,r9
  40c126:	lock cmpxchg QWORD PTR [r8],rdx
  40c12b:	cmp    rax,r9
  40c12e:	jne    40c197 <__swc_fn_4fa09e82_000010_395bb04b+0x87>
  40c130:	mov    eax,DWORD PTR [rcx+0x6c]
  40c133:	test   eax,eax
  40c135:	je     40c196 <__swc_fn_4fa09e82_000010_395bb04b+0x86>
  40c137:	lea    rdx,[rcx+0x70]
  40c13b:	mov    r9d,0x1
  40c141:	xor    eax,eax
  40c143:	lock cmpxchg DWORD PTR [rdx],r9d
  40c148:	test   eax,eax
  40c14a:	jne    40c196 <__swc_fn_4fa09e82_000010_395bb04b+0x86>
  40c14c:	mov    rax,rcx
  40c14f:	and    rax,0xffffffffffc00000
  40c156:	mov    rax,QWORD PTR [rax+0x8]
  40c15a:	test   rax,rax
  40c15d:	jne    40c165 <__swc_fn_4fa09e82_000010_395bb04b+0x55>
  40c15f:	xor    eax,eax
  40c161:	xchg   DWORD PTR [rdx],eax
  40c163:	jmp    40c196 <__swc_fn_4fa09e82_000010_395bb04b+0x86>
  40c165:	lea    rdx,[rax+0x2a80]
  40c16c:	mov    rax,QWORD PTR [rdx]
  40c16f:	mov    r8,rax
  40c172:	cs nop WORD PTR [rax+rax*1+0x0]
  40c17c:	nop    DWORD PTR [rax+0x0]
  40c180:	mov    QWORD PTR [rcx+0x78],r8
  40c184:	mov    rax,r8
  40c187:	lock cmpxchg QWORD PTR [rdx],rcx
  40c18c:	cmp    rax,r8
  40c18f:	je     40c196 <__swc_fn_4fa09e82_000010_395bb04b+0x86>
  40c191:	mov    r8,rax
  40c194:	jmp    40c180 <__swc_fn_4fa09e82_000010_395bb04b+0x70>
  40c196:	ret
  40c197:	mov    r9,rax
  40c19a:	jmp    40c120 <__swc_fn_4fa09e82_000010_395bb04b+0x10>
	...

000000000040c1a0 <__swc_fn_4fa09e82_000013_9ba72deb>:
  40c1a0:	push   rsi
  40c1a1:	push   rdi
  40c1a2:	push   r12
  40c1a4:	push   r13
  40c1a6:	push   r14
  40c1a8:	push   r15
  40c1aa:	push   rbx
  40c1ab:	sub    rsp,0x30
  40c1af:	mov    QWORD PTR [rsp+0x18],r8
  40c1b4:	mov    rsi,rcx
  40c1b7:	mov    rdi,rdx
  40c1ba:	mov    rdx,QWORD PTR [rsi+0x40]
  40c1be:	xchg   ax,ax
  40c1c0:	mov    rax,rdx
  40c1c3:	not    rax
  40c1c6:	and    rax,QWORD PTR [rsi+0x20]
  40c1ca:	test   rax,rax
  40c1cd:	jne    40c1e1 <__swc_fn_4fa09e82_000013_9ba72deb+0x41>
  40c1cf:	xor    eax,eax
  40c1d1:	add    rsp,0x30
  40c1d5:	pop    rbx
  40c1d6:	pop    r15
  40c1d8:	pop    r14
  40c1da:	pop    r13
  40c1dc:	pop    r12
  40c1de:	pop    rdi
  40c1df:	pop    rsi
  40c1e0:	ret
  40c1e1:	xor    ecx,ecx
  40c1e3:	tzcnt  rcx,rax
  40c1e8:	lea    r12,[rsp+0x8]
  40c1ed:	mov    DWORD PTR [rsp+0x8],ecx
  40c1f1:	mov    r13d,0x1
  40c1f7:	shl    r13,cl
  40c1fa:	mov    rcx,rdx
  40c1fd:	or     rcx,r13
  40c200:	mov    rax,rdx
  40c203:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40c209:	cmp    rax,rdx
  40c20c:	je     40c213 <__swc_fn_4fa09e82_000013_9ba72deb+0x73>
  40c20e:	mov    rdx,rax
  40c211:	jmp    40c1c0 <__swc_fn_4fa09e82_000013_9ba72deb+0x20>
  40c213:	mov    eax,DWORD PTR [r12]
  40c217:	shl    rax,0x4
  40c21b:	lea    r14,[rsi+rax*8+0x80]
  40c223:	mov    rcx,rsi
  40c226:	mov    rax,r12
  40c229:	mov    edx,DWORD PTR [rax]
  40c22b:	call   40f460 <__swc_fn_4fa09e82_000011_6493fbbc>
  40c230:	mov    r15,rax
  40c233:	mov    rcx,rsi
  40c236:	mov    rdx,r13
  40c239:	call   40f5c0 <__swc_fn_4fa09e82_000017_4df2d1a0>
  40c23e:	test   al,al
  40c240:	je     40c278 <__swc_fn_4fa09e82_000013_9ba72deb+0xd8>
  40c242:	mov    ecx,DWORD PTR [r14+0x3c]
  40c246:	lea    rdx,[rip+0x17e0b]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40c24d:	mov    r8,QWORD PTR [rip+0x17e04]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40c254:	cs nop WORD PTR [rax+rax*1+0x0]
  40c25e:	xchg   ax,ax
  40c260:	mov    r9,r8
  40c263:	sub    r9,rcx
  40c266:	mov    rax,r8
  40c269:	lock cmpxchg QWORD PTR [rdx],r9
  40c26e:	cmp    rax,r8
  40c271:	je     40c2d9 <__swc_fn_4fa09e82_000013_9ba72deb+0x139>
  40c273:	mov    r8,rax
  40c276:	jmp    40c260 <__swc_fn_4fa09e82_000013_9ba72deb+0xc0>
  40c278:	mov    rcx,rsi
  40c27b:	mov    rax,r12
  40c27e:	mov    edx,DWORD PTR [rax]
  40c280:	call   407450 <__swc_fn_4fa09e82_000012_c7df5d22>
  40c285:	mov    rcx,r15
  40c288:	and    rcx,0xffffffffffff0000
  40c28f:	lea    rcx,[rcx+0x10000]
  40c296:	mov    rbx,rax
  40c299:	cmp    rax,rcx
  40c29c:	cmova  rbx,rcx
  40c2a0:	mov    rax,rbx
  40c2a3:	sub    rax,r15
  40c2a6:	mov    rcx,r15
  40c2a9:	mov    rdx,rax
  40c2ac:	call   4072a0 <__swc_fn_4fa09e82_000003_7ab4792e>
  40c2b1:	test   al,al
  40c2b3:	jne    40c2d2 <__swc_fn_4fa09e82_000013_9ba72deb+0x132>
  40c2b5:	mov    rcx,rsi
  40c2b8:	mov    rdx,r13
  40c2bb:	call   407600 <__swc_fn_4fa09e82_000018_7d1e8a10>
  40c2c0:	xor    eax,eax
  40c2c2:	add    rsp,0x30
  40c2c6:	pop    rbx
  40c2c7:	pop    r15
  40c2c9:	pop    r14
  40c2cb:	pop    r13
  40c2cd:	pop    r12
  40c2cf:	pop    rdi
  40c2d0:	pop    rsi
  40c2d1:	ret
  40c2d2:	sub    rbx,r15
  40c2d5:	mov    DWORD PTR [r14+0x3c],ebx
  40c2d9:	mov    rcx,r14
  40c2dc:	mov    rdx,rsi
  40c2df:	mov    r8d,DWORD PTR [r12]
  40c2e3:	mov    r9d,edi
  40c2e6:	mov    rbx,QWORD PTR [rsp+0x18]
  40c2eb:	mov    r10d,ebx
  40c2ee:	call   40c040 <__swc_fn_4fa09e82_000004_1acc36a6>
  40c2f3:	mov    rax,r14
  40c2f6:	add    rsp,0x30
  40c2fa:	pop    rbx
  40c2fb:	pop    r15
  40c2fd:	pop    r14
  40c2ff:	pop    r13
  40c301:	pop    r12
  40c303:	pop    rdi
  40c304:	pop    rsi
  40c305:	ret
	...

000000000040c310 <__swc_fn_4fa09e82_000016_4b207b58>:
  40c310:	mov    r8,QWORD PTR [rcx+0x48]
  40c314:	cs nop WORD PTR [rax+rax*1+0x0]
  40c31e:	xchg   ax,ax
  40c320:	mov    r9,r8
  40c323:	or     r9,rdx
  40c326:	mov    rax,r8
  40c329:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40c32f:	cmp    rax,r8
  40c332:	jne    40c335 <__swc_fn_4fa09e82_000016_4b207b58+0x25>
  40c334:	ret
  40c335:	mov    r8,rax
  40c338:	jmp    40c320 <__swc_fn_4fa09e82_000016_4b207b58+0x10>
  40c33a:	add    BYTE PTR [rax],al
  40c33c:	add    BYTE PTR [rax],al
	...

000000000040c340 <__swc_fn_4fa09e82_000019_2cc1532c>:
  40c340:	push   rsi
  40c341:	push   rdi
  40c342:	push   r12
  40c344:	mov    rsi,rcx
  40c347:	xor    edi,edi
  40c349:	lea    r12,[rip+0x17d18]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40c350:	mov    eax,DWORD PTR [r12]
  40c354:	xor    ecx,ecx
  40c356:	test   rax,rax
  40c359:	jbe    40c394 <__swc_fn_4fa09e82_000019_2cc1532c+0x54>
  40c35b:	nop    DWORD PTR [rax+rax*1+0x0]
  40c360:	lea    rdx,[rip+0x17d09]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  40c367:	mov    r8d,ecx
  40c36a:	lea    r8,[r8+r8*2]
  40c36e:	lea    r8,[rdx+r8*8]
  40c372:	mov    rdx,QWORD PTR [r8+0x10]
  40c376:	add    rdx,0x400000
  40c37d:	cmp    rdx,0x40000000
  40c384:	ja     40c38b <__swc_fn_4fa09e82_000019_2cc1532c+0x4b>
  40c386:	mov    rdi,r8
  40c389:	jmp    40c394 <__swc_fn_4fa09e82_000019_2cc1532c+0x54>
  40c38b:	add    rcx,0x1
  40c38f:	cmp    rcx,rax
  40c392:	jb     40c360 <__swc_fn_4fa09e82_000019_2cc1532c+0x20>
  40c394:	test   rdi,rdi
  40c397:	jne    40c423 <__swc_fn_4fa09e82_000019_2cc1532c+0xe3>
  40c39d:	cmp    DWORD PTR [r12],0x10
  40c3a2:	jae    40c40b <__swc_fn_4fa09e82_000019_2cc1532c+0xcb>
  40c3a4:	mov    ecx,0x40400000
  40c3a9:	call   40f380 <__swc_fn_4fa09e82_000002_884bb5c0>
  40c3ae:	test   rax,rax
  40c3b1:	je     40c40b <__swc_fn_4fa09e82_000019_2cc1532c+0xcb>
  40c3b3:	lea    rcx,[rip+0x17cb6]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  40c3ba:	mov    edx,DWORD PTR [r12]
  40c3be:	lea    rdx,[rdx+rdx*2]
  40c3c2:	lea    rdx,[rcx+rdx*8]
  40c3c6:	mov    QWORD PTR [rdx],rax
  40c3c9:	lea    rax,[rax+0x3fffff]
  40c3d0:	and    rax,0xffffffffffc00000
  40c3d7:	mov    QWORD PTR [rdx+0x8],rax
  40c3db:	mov    QWORD PTR [rdx+0x10],0x0
  40c3e3:	mov    edx,DWORD PTR [rip+0x17c7f]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40c3e9:	nop    DWORD PTR [rax+0x0]
  40c3f0:	lea    r9d,[rdx+0x1]
  40c3f4:	mov    rax,rdx
  40c3f7:	lock cmpxchg DWORD PTR [r12],r9d
  40c3fd:	mov    r8d,eax
  40c400:	cmp    eax,edx
  40c402:	je     40c412 <__swc_fn_4fa09e82_000019_2cc1532c+0xd2>
  40c404:	mov    rdx,r8
  40c407:	jmp    40c3f0 <__swc_fn_4fa09e82_000019_2cc1532c+0xb0>
  40c409:	jmp    40c412 <__swc_fn_4fa09e82_000019_2cc1532c+0xd2>
  40c40b:	xor    eax,eax
  40c40d:	pop    r12
  40c40f:	pop    rdi
  40c410:	pop    rsi
  40c411:	ret
  40c412:	mov    eax,DWORD PTR [rip+0x17c50]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40c418:	sub    eax,0x1
  40c41b:	lea    rdi,[rax+rax*2]
  40c41f:	lea    rdi,[rcx+rdi*8]
  40c423:	mov    r12,QWORD PTR [rdi+0x8]
  40c427:	add    r12,QWORD PTR [rdi+0x10]
  40c42b:	mov    rcx,r12
  40c42e:	mov    edx,0x3000
  40c433:	call   4072a0 <__swc_fn_4fa09e82_000003_7ab4792e>
  40c438:	test   al,al
  40c43a:	jne    40c443 <__swc_fn_4fa09e82_000019_2cc1532c+0x103>
  40c43c:	xor    eax,eax
  40c43e:	pop    r12
  40c440:	pop    rdi
  40c441:	pop    rsi
  40c442:	ret
  40c443:	vxorps xmm0,xmm0,xmm0
  40c447:	xor    eax,eax
  40c449:	cs nop WORD PTR [rax+rax*1+0x0]
  40c453:	cs nop WORD PTR [rax+rax*1+0x0]
  40c45d:	nop    DWORD PTR [rax]
  40c460:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40c466:	add    rax,0x10
  40c46a:	cmp    rax,0x3000
  40c471:	jne    40c460 <__swc_fn_4fa09e82_000019_2cc1532c+0x120>
  40c473:	mov    DWORD PTR [r12+0x28],esi
  40c478:	mov    eax,0x40
  40c47d:	mov    ecx,esi
  40c47f:	shr    eax,cl
  40c481:	mov    DWORD PTR [r12+0x2c],eax
  40c486:	cmp    DWORD PTR [r12+0x2c],0x40
  40c48c:	jb     40c497 <__swc_fn_4fa09e82_000019_2cc1532c+0x157>
  40c48e:	mov    rax,0xffffffffffffffff
  40c495:	jmp    40c4a7 <__swc_fn_4fa09e82_000019_2cc1532c+0x167>
  40c497:	mov    eax,0x1
  40c49c:	mov    ecx,DWORD PTR [r12+0x2c]
  40c4a1:	shl    rax,cl
  40c4a4:	dec    rax
  40c4a7:	mov    QWORD PTR [r12+0x20],rax
  40c4ac:	mov    DWORD PTR [r12],0x4e540001
  40c4b4:	mov    DWORD PTR [r12+0x4],0x53474d45
  40c4bd:	add    QWORD PTR [rdi+0x10],0x400000
  40c4c5:	mov    rax,r12
  40c4c8:	pop    r12
  40c4ca:	pop    rdi
  40c4cb:	pop    rsi
  40c4cc:	ret
  40c4cd:	add    BYTE PTR [rax],al
	...

000000000040c4d0 <__swc_fn_4fa09e82_000022_3a2e2048>:
  40c4d0:	mov    eax,0x1
  40c4d5:	mov    edx,DWORD PTR [rip+0x17b8d]        # 424068 <__swc_bss_base_4fa09e82+0x28>
  40c4db:	cmp    eax,edx
  40c4dd:	jae    40c52b <__swc_fn_4fa09e82_000022_3a2e2048+0x5b>
  40c4df:	nop
  40c4e0:	lea    r8,[rip+0x17b89]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  40c4e7:	lea    r9,[rax+rax*2]
  40c4eb:	lea    r9,[r8+r9*8]
  40c4ef:	mov    r8,rcx
  40c4f2:	sub    r8,QWORD PTR [r9+0x8]
  40c4f6:	mov    r9,QWORD PTR [r9+0x10]
  40c4fa:	cmp    r8,r9
  40c4fd:	jae    40c525 <__swc_fn_4fa09e82_000022_3a2e2048+0x55>
  40c4ff:	mov    rax,rcx
  40c502:	and    rax,0xffffffffffc00000
  40c509:	shr    rcx,0x10
  40c50d:	and    ecx,0x3f
  40c510:	mov    edx,DWORD PTR [rax+0x28]
  40c513:	shrx   ecx,ecx,edx
  40c518:	shl    rcx,0x4
  40c51c:	lea    rax,[rax+rcx*8+0x80]
  40c524:	ret
  40c525:	inc    eax
  40c527:	cmp    eax,edx
  40c529:	jb     40c4e0 <__swc_fn_4fa09e82_000022_3a2e2048+0x10>
  40c52b:	xor    eax,eax
  40c52d:	ret
	...

000000000040c530 <__swc_fn_4fa09e82_000025_4aca8b9e>:
  40c530:	vxorps xmm0,xmm0,xmm0
  40c534:	vmovups XMMWORD PTR [rcx],xmm0
  40c538:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40c53d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40c542:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40c547:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40c54c:	mov    QWORD PTR [rcx+0x50],0x0
  40c554:	ret
	...

000000000040c560 <__swc_fn_4fa09e82_000028_4aca8b9e>:
  40c560:	vxorps xmm0,xmm0,xmm0
  40c564:	xor    eax,eax
  40c566:	cs nop WORD PTR [rax+rax*1+0x0]
  40c570:	cs nop WORD PTR [rax+rax*1+0x0]
  40c57a:	nop    WORD PTR [rax+rax*1+0x0]
  40c580:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40c585:	add    rax,0x10
  40c589:	cmp    rax,0x9b0
  40c590:	jne    40c580 <__swc_fn_4fa09e82_000028_4aca8b9e+0x20>
  40c592:	mov    QWORD PTR [rcx+0x9b0],0x0
  40c59d:	ret
	...

000000000040c5a0 <__swc_fn_4fa09e82_000031_90860ff2>:
  40c5a0:	push   rsi
  40c5a1:	push   rdi
  40c5a2:	sub    rsp,0x8
  40c5a6:	lea    rsi,[rip+0x15a5b]        # 422008 <__swc_data_base_4fa09e82+0x8>
  40c5ad:	mov    rax,QWORD PTR [rsi]
  40c5b0:	mov    ecx,0xffffffff
  40c5b5:	cmp    rax,rcx
  40c5b8:	je     40c5c1 <__swc_fn_4fa09e82_000031_90860ff2+0x21>
  40c5ba:	add    rsp,0x8
  40c5be:	pop    rdi
  40c5bf:	pop    rsi
  40c5c0:	ret
  40c5c1:	mov    rcx,QWORD PTR [rip+0x6af0]        # 4130b8 <__swc_fn_4fa09e82_000179_6937fe70+0xf08>
  40c5c8:	call   40e590 <__swc_fn_4fa09e82_000127_102fe7b9>
  40c5cd:	mov    rcx,rax
  40c5d0:	mov    eax,0xffffffff
  40c5d5:	lock cmpxchg QWORD PTR [rsi],rcx
  40c5da:	mov    rdi,rax
  40c5dd:	mov    eax,0xffffffff
  40c5e2:	cmp    rdi,rax
  40c5e5:	je     40c5f6 <__swc_fn_4fa09e82_000031_90860ff2+0x56>
  40c5e7:	call   4116f0 <__swc_fn_4fa09e82_000128_8dffa290>
  40c5ec:	mov    rax,rdi
  40c5ef:	add    rsp,0x8
  40c5f3:	pop    rdi
  40c5f4:	pop    rsi
  40c5f5:	ret
  40c5f6:	mov    rax,rcx
  40c5f9:	add    rsp,0x8
  40c5fd:	pop    rdi
  40c5fe:	pop    rsi
  40c5ff:	ret

000000000040c600 <__swc_fn_4fa09e82_000034_25f19556>:
  40c600:	sub    rsp,0x8
  40c604:	vxorps xmm0,xmm0,xmm0
  40c608:	xor    eax,eax
  40c60a:	cs nop WORD PTR [rax+rax*1+0x0]
  40c614:	cs nop WORD PTR [rax+rax*1+0x0]
  40c61e:	xchg   ax,ax
  40c620:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40c625:	add    rax,0x10
  40c629:	cmp    rax,0x2b00
  40c630:	jne    40c620 <__swc_fn_4fa09e82_000034_25f19556+0x20>
  40c632:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40c63c:	xor    al,al
  40c63e:	mov    rdx,rax
  40c641:	xor    al,al
  40c643:	mov    r8,rax
  40c646:	xor    al,al
  40c648:	mov    r9,rax
  40c64b:	xor    al,al
  40c64d:	mov    r10,rax
  40c650:	xor    al,al
  40c652:	mov    r11,rax
  40c655:	call   40f7f0 <__swc_fn_4fa09e82_000035_95622a2b>
  40c65a:	add    rsp,0x8
  40c65e:	ret
	...

000000000040c660 <__swc_fn_4fa09e82_000037_b4982903>:
  40c660:	push   rsi
  40c661:	push   rdi
  40c662:	push   r12
  40c664:	mov    rsi,r8
  40c667:	mov    rdi,rdx
  40c66a:	mov    rcx,rdx
  40c66d:	call   40f380 <__swc_fn_4fa09e82_000002_884bb5c0>
  40c672:	mov    r12,rax
  40c675:	test   rax,rax
  40c678:	jne    40c681 <__swc_fn_4fa09e82_000037_b4982903+0x21>
  40c67a:	xor    eax,eax
  40c67c:	pop    r12
  40c67e:	pop    rdi
  40c67f:	pop    rsi
  40c680:	ret
  40c681:	mov    rcx,r12
  40c684:	mov    rdx,rsi
  40c687:	call   4072a0 <__swc_fn_4fa09e82_000003_7ab4792e>
  40c68c:	test   al,al
  40c68e:	jne    40c6a2 <__swc_fn_4fa09e82_000037_b4982903+0x42>
  40c690:	mov    rcx,r12
  40c693:	mov    rdx,rdi
  40c696:	call   4098a0 <__swc_fn_4fa09e82_000114_49b378a9>
  40c69b:	xor    eax,eax
  40c69d:	pop    r12
  40c69f:	pop    rdi
  40c6a0:	pop    rsi
  40c6a1:	ret
  40c6a2:	mov    rax,r12
  40c6a5:	pop    r12
  40c6a7:	pop    rdi
  40c6a8:	pop    rsi
  40c6a9:	ret
	...

000000000040c6c0 <__swc_fn_4fa09e82_000040_6895916d>:
  40c6c0:	push   rsi
  40c6c1:	push   rdi
  40c6c2:	push   r12
  40c6c4:	mov    rsi,rcx
  40c6c7:	mov    edx,0x9b8
  40c6cc:	call   40f860 <__swc_fn_4fa09e82_000038_788ceb38>
  40c6d1:	mov    rdi,rax
  40c6d4:	test   rax,rax
  40c6d7:	jne    40c6e0 <__swc_fn_4fa09e82_000040_6895916d+0x20>
  40c6d9:	xor    eax,eax
  40c6db:	pop    r12
  40c6dd:	pop    rdi
  40c6de:	pop    rsi
  40c6df:	ret
  40c6e0:	vxorps xmm0,xmm0,xmm0
  40c6e4:	xor    eax,eax
  40c6e6:	cs nop WORD PTR [rax+rax*1+0x0]
  40c6f0:	cs nop WORD PTR [rax+rax*1+0x0]
  40c6fa:	nop    WORD PTR [rax+rax*1+0x0]
  40c700:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40c705:	add    rax,0x10
  40c709:	cmp    rax,0x9b0
  40c710:	jne    40c700 <__swc_fn_4fa09e82_000040_6895916d+0x40>
  40c712:	mov    QWORD PTR [rdi+0x9b0],0x0
  40c71d:	mov    QWORD PTR [rdi],rsi
  40c720:	call   4117a0 <__swc_fn_4fa09e82_000131_c1196dfb>
  40c725:	mov    QWORD PTR [rdi+0x18],rax
  40c729:	lea    r12,[rsi+0x10]
  40c72d:	mov    rcx,r12
  40c730:	call   40e7e0 <__swc_fn_4fa09e82_000136_e3032dc2>
  40c735:	mov    rax,QWORD PTR [rsi+0x20]
  40c739:	mov    QWORD PTR [rdi+0x8],rax
  40c73d:	mov    rax,QWORD PTR [rsi+0x20]
  40c741:	test   rax,rax
  40c744:	je     40c74a <__swc_fn_4fa09e82_000040_6895916d+0x8a>
  40c746:	mov    QWORD PTR [rax+0x10],rdi
  40c74a:	mov    QWORD PTR [rsi+0x20],rdi
  40c74e:	mov    rcx,r12
  40c751:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40c756:	mov    rax,rdi
  40c759:	pop    r12
  40c75b:	pop    rdi
  40c75c:	pop    rsi
  40c75d:	ret
	...

000000000040c760 <__swc_fn_4fa09e82_000043_957e4917>:
  40c760:	mov    rax,QWORD PTR [rdx+0x10]
  40c764:	test   rax,rax
  40c767:	je     40c773 <__swc_fn_4fa09e82_000043_957e4917+0x13>
  40c769:	mov    rcx,QWORD PTR [rdx+0x8]
  40c76d:	mov    QWORD PTR [rax+0x8],rcx
  40c771:	jmp    40c77b <__swc_fn_4fa09e82_000043_957e4917+0x1b>
  40c773:	mov    rax,QWORD PTR [rdx+0x8]
  40c777:	mov    QWORD PTR [rcx+0x20],rax
  40c77b:	mov    rax,QWORD PTR [rdx+0x8]
  40c77f:	test   rax,rax
  40c782:	je     40c78c <__swc_fn_4fa09e82_000043_957e4917+0x2c>
  40c784:	mov    rcx,QWORD PTR [rdx+0x10]
  40c788:	mov    QWORD PTR [rax+0x10],rcx
  40c78c:	vxorps xmm0,xmm0,xmm0
  40c790:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40c795:	ret
	...

000000000040c7a0 <__swc_fn_4fa09e82_000046_88f44774>:
  40c7a0:	sub    rsp,0x8
  40c7a4:	mov    r9,r8
  40c7a7:	mov    r10,rdx
  40c7aa:	call   40f910 <__swc_fn_4fa09e82_000044_9c2ade9b>
  40c7af:	mov    eax,0x1
  40c7b4:	xchg   DWORD PTR [r9+0x6c],eax
  40c7b8:	mov    rax,QWORD PTR [r9+0x60]
  40c7bc:	test   rax,rax
  40c7bf:	je     40c803 <__swc_fn_4fa09e82_000046_88f44774+0x63>
  40c7c1:	xor    eax,eax
  40c7c3:	xchg   DWORD PTR [r9+0x6c],eax
  40c7c7:	movzx  eax,BYTE PTR [r9+0x39]
  40c7cc:	lea    rax,[rax+rax*4]
  40c7d0:	lea    rax,[r10+rax*8+0x28]
  40c7d5:	mov    QWORD PTR [r9+0x50],0x0
  40c7dd:	mov    rcx,QWORD PTR [rax+0x8]
  40c7e1:	mov    QWORD PTR [r9+0x48],rcx
  40c7e5:	mov    rcx,QWORD PTR [rax+0x8]
  40c7e9:	test   rcx,rcx
  40c7ec:	je     40c7f4 <__swc_fn_4fa09e82_000046_88f44774+0x54>
  40c7ee:	mov    QWORD PTR [rcx+0x50],r9
  40c7f2:	jmp    40c7f8 <__swc_fn_4fa09e82_000046_88f44774+0x58>
  40c7f4:	mov    QWORD PTR [rax+0x10],r9
  40c7f8:	mov    QWORD PTR [rax+0x8],r9
  40c7fc:	xor    eax,eax
  40c7fe:	add    rsp,0x8
  40c802:	ret
  40c803:	movzx  eax,BYTE PTR [r9+0x39]
  40c808:	lea    rax,[rax+rax*4]
  40c80c:	lea    rax,[r10+rax*8+0x28]
  40c811:	mov    QWORD PTR [r9+0x50],0x0
  40c819:	mov    rcx,QWORD PTR [rax+0x18]
  40c81d:	mov    QWORD PTR [r9+0x48],rcx
  40c821:	mov    rcx,QWORD PTR [rax+0x18]
  40c825:	test   rcx,rcx
  40c828:	je     40c82e <__swc_fn_4fa09e82_000046_88f44774+0x8e>
  40c82a:	mov    QWORD PTR [rcx+0x50],r9
  40c82e:	mov    QWORD PTR [rax+0x18],r9
  40c832:	mov    eax,0x1
  40c837:	add    rsp,0x8
  40c83b:	ret
  40c83c:	add    BYTE PTR [rax],al
	...

000000000040c840 <__swc_fn_4fa09e82_000049_2ff013cc>:
  40c840:	push   r12
  40c842:	push   r13
  40c844:	push   rdi
  40c845:	push   rsi
  40c846:	push   r14
  40c848:	push   r15
  40c84a:	sub    rsp,0x178
  40c851:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40c85a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40c863:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40c86c:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40c875:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40c87e:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40c887:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40c890:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40c899:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40c8a2:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40c8ab:	mov    r12,rcx
  40c8ae:	lea    rax,[rip+0x1794b]        # 424200 <__swc_bss_base_4fa09e82+0x1c0>
  40c8b5:	mov    rcx,QWORD PTR [rax]
  40c8b8:	mov    r13,rcx
  40c8bb:	test   rcx,rcx
  40c8be:	jne    40c8ce <__swc_fn_4fa09e82_000049_2ff013cc+0x8e>
  40c8c0:	mov    r13d,0x1dcd6500
  40c8c6:	mov    ecx,0x1dcd6500
  40c8cb:	xchg   QWORD PTR [rax],rcx
  40c8ce:	lea    rax,[rip+0x1572b]        # 422000 <__swc_data_base_4fa09e82>
  40c8d5:	mov    rax,QWORD PTR [rax]
  40c8d8:	cmp    rax,0xffffffffffffffff
  40c8dc:	je     40c8eb <__swc_fn_4fa09e82_000049_2ff013cc+0xab>
  40c8de:	mov    eax,eax
  40c8e0:	mov    edi,eax
  40c8e2:	xor    eax,eax
  40c8e4:	call   407000 <pthread_getspecific@plt>
  40c8e9:	jmp    40c8ed <__swc_fn_4fa09e82_000049_2ff013cc+0xad>
  40c8eb:	xor    eax,eax
  40c8ed:	test   rax,rax
  40c8f0:	jne    40c8ff <__swc_fn_4fa09e82_000049_2ff013cc+0xbf>
  40c8f2:	call   40c5a0 <__swc_fn_4fa09e82_000031_90860ff2>
  40c8f7:	mov    rcx,rax
  40c8fa:	call   409c00 <__swc_fn_4fa09e82_000129_41c3251c>
  40c8ff:	test   rax,rax
  40c902:	je     40c914 <__swc_fn_4fa09e82_000049_2ff013cc+0xd4>
  40c904:	cmp    QWORD PTR [rax],r12
  40c907:	jne    40c914 <__swc_fn_4fa09e82_000049_2ff013cc+0xd4>
  40c909:	cmp    DWORD PTR [rax+0x20],0x0
  40c90d:	jne    40c914 <__swc_fn_4fa09e82_000049_2ff013cc+0xd4>
  40c90f:	mov    rsi,rax
  40c912:	jmp    40c916 <__swc_fn_4fa09e82_000049_2ff013cc+0xd6>
  40c914:	xor    esi,esi
  40c916:	lea    rdi,[r12+0x2a88]
  40c91e:	mov    r14,QWORD PTR [rdi]
  40c921:	test   r14,r14
  40c924:	jne    40c973 <__swc_fn_4fa09e82_000049_2ff013cc+0x133>
  40c926:	lea    rax,[rip+0x1772b]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40c92d:	mov    rax,QWORD PTR [rax]
  40c930:	test   rax,rax
  40c933:	setne  al
  40c936:	jne    40c95a <__swc_fn_4fa09e82_000049_2ff013cc+0x11a>
  40c938:	mov    rax,QWORD PTR [r12+0x2a70]
  40c940:	test   rax,rax
  40c943:	setne  al
  40c946:	jne    40c95a <__swc_fn_4fa09e82_000049_2ff013cc+0x11a>
  40c948:	test   rsi,rsi
  40c94b:	setne  al
  40c94e:	je     40c95a <__swc_fn_4fa09e82_000049_2ff013cc+0x11a>
  40c950:	cmp    DWORD PTR [rsi+0x730],0x0
  40c957:	setne  al
  40c95a:	test   al,al
  40c95c:	je     40c96e <__swc_fn_4fa09e82_000049_2ff013cc+0x12e>
  40c95e:	call   409cb0 <__swc_fn_4fa09e82_000132_944f555b>
  40c963:	lea    rcx,[rax+r13*1]
  40c967:	xor    eax,eax
  40c969:	lock cmpxchg QWORD PTR [rdi],rcx
  40c96e:	jmp    40ca73 <__swc_fn_4fa09e82_000049_2ff013cc+0x233>
  40c973:	call   409cb0 <__swc_fn_4fa09e82_000132_944f555b>
  40c978:	mov    r15,rax
  40c97b:	cmp    rax,r14
  40c97e:	jb     40c98f <__swc_fn_4fa09e82_000049_2ff013cc+0x14f>
  40c980:	xor    ecx,ecx
  40c982:	mov    rax,r14
  40c985:	lock cmpxchg QWORD PTR [rdi],rcx
  40c98a:	cmp    rax,r14
  40c98d:	je     40c994 <__swc_fn_4fa09e82_000049_2ff013cc+0x154>
  40c98f:	jmp    40ca73 <__swc_fn_4fa09e82_000049_2ff013cc+0x233>
  40c994:	test   rsi,rsi
  40c997:	je     40c9b2 <__swc_fn_4fa09e82_000049_2ff013cc+0x172>
  40c999:	cmp    r15,r13
  40c99c:	jb     40c9b2 <__swc_fn_4fa09e82_000049_2ff013cc+0x172>
  40c99e:	mov    rax,r15
  40c9a1:	sub    rax,r13
  40c9a4:	mov    rcx,r12
  40c9a7:	mov    rdx,rsi
  40c9aa:	mov    r8,rax
  40c9ad:	call   40fd50 <__swc_fn_4fa09e82_000059_3ca3ac64>
  40c9b2:	lea    rsi,[r12+0x10]
  40c9b7:	mov    rcx,rsi
  40c9ba:	call   40e7e0 <__swc_fn_4fa09e82_000136_e3032dc2>
  40c9bf:	mov    rax,QWORD PTR [r12+0x18]
  40c9c4:	mov    rdi,rax
  40c9c7:	test   rdi,rdi
  40c9ca:	je     40c9f4 <__swc_fn_4fa09e82_000049_2ff013cc+0x1b4>
  40c9cc:	cs nop WORD PTR [rax+rax*1+0x0]
  40c9d6:	cs nop WORD PTR [rax+rax*1+0x0]
  40c9e0:	mov    rcx,rdi
  40c9e3:	call   407470 <__swc_fn_4fa09e82_000015_07eb9884>
  40c9e8:	mov    rax,QWORD PTR [rdi+0x10]
  40c9ec:	mov    rdi,rax
  40c9ef:	test   rax,rax
  40c9f2:	jne    40c9e0 <__swc_fn_4fa09e82_000049_2ff013cc+0x1a0>
  40c9f4:	mov    rcx,rsi
  40c9f7:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40c9fc:	mov    rcx,r12
  40c9ff:	call   40e7e0 <__swc_fn_4fa09e82_000136_e3032dc2>
  40ca04:	xor    esi,esi
  40ca06:	cs nop WORD PTR [rax+rax*1+0x0]
  40ca10:	mov    rax,QWORD PTR [r12+0x2a70]
  40ca18:	cmp    rsi,rax
  40ca1b:	jae    40ca6b <__swc_fn_4fa09e82_000049_2ff013cc+0x22b>
  40ca1d:	lea    rax,[rsi+rsi*4]
  40ca21:	lea    rax,[r12+rax*8+0x268]
  40ca29:	mov    r8,QWORD PTR [rax]
  40ca2c:	mov    r9,QWORD PTR [rax+0x8]
  40ca30:	mov    r10,QWORD PTR [rax+0x10]
  40ca34:	mov    rax,QWORD PTR [rax+0x20]
  40ca38:	cmp    rax,r15
  40ca3b:	jae    40ca48 <__swc_fn_4fa09e82_000049_2ff013cc+0x208>
  40ca3d:	mov    rcx,r15
  40ca40:	sub    rcx,rax
  40ca43:	cmp    rcx,r13
  40ca46:	jae    40ca4d <__swc_fn_4fa09e82_000049_2ff013cc+0x20d>
  40ca48:	inc    rsi
  40ca4b:	jmp    40ca10 <__swc_fn_4fa09e82_000049_2ff013cc+0x1d0>
  40ca4d:	mov    rcx,r12
  40ca50:	mov    rdx,rsi
  40ca53:	call   40fd00 <__swc_fn_4fa09e82_000056_38b21f11>
  40ca58:	mov    rcx,r12
  40ca5b:	mov    rdx,r8
  40ca5e:	mov    r8,r9
  40ca61:	mov    r9,r10
  40ca64:	call   407750 <__swc_fn_4fa09e82_000039_40d1e569>
  40ca69:	jmp    40ca10 <__swc_fn_4fa09e82_000049_2ff013cc+0x1d0>
  40ca6b:	mov    rcx,r12
  40ca6e:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40ca73:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40ca7c:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40ca85:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40ca8e:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40ca97:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40caa0:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40caa9:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40cab2:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40cabb:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40cac4:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40cacd:	add    rsp,0x178
  40cad4:	pop    r15
  40cad6:	pop    r14
  40cad8:	pop    rsi
  40cad9:	pop    rdi
  40cada:	pop    r13
  40cadc:	pop    r12
  40cade:	ret
	...

000000000040cae0 <__swc_fn_4fa09e82_000052_c7484fb0>:
  40cae0:	lea    rax,[rdx-0x58]
  40cae4:	ret
	...

000000000040caf0 <__swc_fn_4fa09e82_000055_81f7713d>:
  40caf0:	push   rsi
  40caf1:	push   rdi
  40caf2:	push   r12
  40caf4:	push   r13
  40caf6:	sub    rsp,0x68
  40cafa:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40cb00:	mov    rsi,r9
  40cb03:	mov    rdi,rcx
  40cb06:	mov    r12,rdx
  40cb09:	mov    r13,r8
  40cb0c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40cb14:	jne    40cb23 <__swc_fn_4fa09e82_000055_81f7713d+0x33>
  40cb16:	xor    eax,eax
  40cb18:	add    rsp,0x68
  40cb1c:	pop    r13
  40cb1e:	pop    r12
  40cb20:	pop    rdi
  40cb21:	pop    rsi
  40cb22:	ret
  40cb23:	mov    rcx,rdi
  40cb26:	call   40e7e0 <__swc_fn_4fa09e82_000136_e3032dc2>
  40cb2b:	movabs rax,0x7fffffffffffffff
  40cb35:	cmp    r12,rax
  40cb38:	mov    rax,0xffffffffffffffff
  40cb3f:	lea    rcx,[r12+r12*1]
  40cb43:	cmovbe rax,rcx
  40cb47:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40cb4e:	mov    rdx,rcx
  40cb51:	sub    rax,r12
  40cb54:	inc    rax
  40cb57:	xor    r8d,r8d
  40cb5a:	test   rcx,rcx
  40cb5d:	jbe    40cb88 <__swc_fn_4fa09e82_000055_81f7713d+0x98>
  40cb5f:	nop
  40cb60:	lea    r9,[r8+r8*4]
  40cb64:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40cb6c:	sub    r9,r12
  40cb6f:	cmp    r9,rax
  40cb72:	jae    40cb7f <__swc_fn_4fa09e82_000055_81f7713d+0x8f>
  40cb74:	mov    rdx,r8
  40cb77:	mov    rax,r9
  40cb7a:	test   r9,r9
  40cb7d:	je     40cb88 <__swc_fn_4fa09e82_000055_81f7713d+0x98>
  40cb7f:	add    r8,0x1
  40cb83:	cmp    r8,rcx
  40cb86:	jb     40cb60 <__swc_fn_4fa09e82_000055_81f7713d+0x70>
  40cb88:	mov    rax,QWORD PTR [rdi+0x2a70]
  40cb8f:	cmp    rdx,rax
  40cb92:	jne    40cbaf <__swc_fn_4fa09e82_000055_81f7713d+0xbf>
  40cb94:	mov    rcx,rdi
  40cb97:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40cb9c:	xor    eax,eax
  40cb9e:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40cba4:	add    rsp,0x68
  40cba8:	pop    r13
  40cbaa:	pop    r12
  40cbac:	pop    rdi
  40cbad:	pop    rsi
  40cbae:	ret
  40cbaf:	lea    rax,[rdx+rdx*4]
  40cbb3:	lea    rax,[rdi+rax*8+0x268]
  40cbbb:	vmovups xmm6,XMMWORD PTR [rax]
  40cbbf:	mov    r8,QWORD PTR [rax+0x10]
  40cbc3:	mov    rcx,rdi
  40cbc6:	call   40fd00 <__swc_fn_4fa09e82_000056_38b21f11>
  40cbcb:	vpshufd xmm0,xmm6,0xee
  40cbd0:	vmovsd QWORD PTR [r13+0x0],xmm0
  40cbd6:	mov    QWORD PTR [rsi],r8
  40cbd9:	mov    rcx,rdi
  40cbdc:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40cbe1:	vmovq  rax,xmm6
  40cbe6:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40cbec:	add    rsp,0x68
  40cbf0:	pop    r13
  40cbf2:	pop    r12
  40cbf4:	pop    rdi
  40cbf5:	pop    rsi
  40cbf6:	ret
	...

000000000040cc00 <__swc_fn_4fa09e82_000058_8bd8d1d5>:
  40cc00:	push   r12
  40cc02:	push   r13
  40cc04:	push   r14
  40cc06:	push   r15
  40cc08:	push   rdi
  40cc09:	push   rsi
  40cc0a:	sub    rsp,0x148
  40cc11:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40cc1a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40cc23:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40cc2c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40cc35:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40cc3e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40cc47:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40cc50:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40cc59:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40cc62:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40cc6b:	mov    r12,r9
  40cc6e:	mov    r13,rcx
  40cc71:	mov    r14,rdx
  40cc74:	mov    r15,r8
  40cc77:	test   rdx,rdx
  40cc7a:	jne    40cc8e <__swc_fn_4fa09e82_000058_8bd8d1d5+0x8e>
  40cc7c:	add    rsp,0x148
  40cc83:	pop    rsi
  40cc84:	pop    rdi
  40cc85:	pop    r15
  40cc87:	pop    r14
  40cc89:	pop    r13
  40cc8b:	pop    r12
  40cc8d:	ret
  40cc8e:	cmp    r12,0x200000
  40cc95:	ja     40cd27 <__swc_fn_4fa09e82_000058_8bd8d1d5+0x127>
  40cc9b:	lea    rax,[rip+0x1535e]        # 422000 <__swc_data_base_4fa09e82>
  40cca2:	mov    rax,QWORD PTR [rax]
  40cca5:	cmp    rax,0xffffffffffffffff
  40cca9:	je     40ccb8 <__swc_fn_4fa09e82_000058_8bd8d1d5+0xb8>
  40ccab:	mov    eax,eax
  40ccad:	mov    edi,eax
  40ccaf:	xor    eax,eax
  40ccb1:	call   407000 <pthread_getspecific@plt>
  40ccb6:	jmp    40ccba <__swc_fn_4fa09e82_000058_8bd8d1d5+0xba>
  40ccb8:	xor    eax,eax
  40ccba:	test   rax,rax
  40ccbd:	je     40ccc4 <__swc_fn_4fa09e82_000058_8bd8d1d5+0xc4>
  40ccbf:	mov    rsi,rax
  40ccc2:	jmp    40ccd4 <__swc_fn_4fa09e82_000058_8bd8d1d5+0xd4>
  40ccc4:	call   40c5a0 <__swc_fn_4fa09e82_000031_90860ff2>
  40ccc9:	mov    rcx,rax
  40cccc:	call   409c00 <__swc_fn_4fa09e82_000129_41c3251c>
  40ccd1:	mov    rsi,rax
  40ccd4:	test   rsi,rsi
  40ccd7:	je     40cd27 <__swc_fn_4fa09e82_000058_8bd8d1d5+0x127>
  40ccd9:	cmp    QWORD PTR [rsi],r13
  40ccdc:	jne    40cd27 <__swc_fn_4fa09e82_000058_8bd8d1d5+0x127>
  40ccde:	cmp    DWORD PTR [rsi+0x20],0x0
  40cce2:	jne    40cd27 <__swc_fn_4fa09e82_000058_8bd8d1d5+0x127>
  40cce4:	cmp    DWORD PTR [rsi+0x730],0x10
  40cceb:	jae    40cd27 <__swc_fn_4fa09e82_000058_8bd8d1d5+0x127>
  40cced:	mov    eax,DWORD PTR [rsi+0x730]
  40ccf3:	lea    rdi,[rax+rax*4]
  40ccf7:	lea    rdi,[rsi+rdi*8+0x738]
  40ccff:	mov    QWORD PTR [rdi],r14
  40cd02:	mov    QWORD PTR [rdi+0x8],r15
  40cd06:	mov    QWORD PTR [rdi+0x10],r12
  40cd0a:	mov    QWORD PTR [rdi+0x18],0x0
  40cd12:	call   409cb0 <__swc_fn_4fa09e82_000132_944f555b>
  40cd17:	mov    QWORD PTR [rdi+0x20],rax
  40cd1b:	add    DWORD PTR [rsi+0x730],0x1
  40cd22:	jmp    40ce86 <__swc_fn_4fa09e82_000058_8bd8d1d5+0x286>
  40cd27:	mov    rcx,r13
  40cd2a:	call   407e90 <__swc_fn_4fa09e82_000057_5b81d8b6>
  40cd2f:	mov    rsi,rax
  40cd32:	cmp    r12,rax
  40cd35:	jbe    40cd6a <__swc_fn_4fa09e82_000058_8bd8d1d5+0x16a>
  40cd37:	cmp    r12,0x10000000
  40cd3e:	seta   al
  40cd41:	ja     40cd50 <__swc_fn_4fa09e82_000058_8bd8d1d5+0x150>
  40cd43:	mov    rax,QWORD PTR [r13+0x2a70]
  40cd4a:	test   rax,rax
  40cd4d:	setne  al
  40cd50:	test   al,al
  40cd52:	je     40cd6a <__swc_fn_4fa09e82_000058_8bd8d1d5+0x16a>
  40cd54:	mov    rcx,r13
  40cd57:	mov    rdx,r14
  40cd5a:	mov    r8,r15
  40cd5d:	mov    r9,r12
  40cd60:	call   407750 <__swc_fn_4fa09e82_000039_40d1e569>
  40cd65:	jmp    40ce86 <__swc_fn_4fa09e82_000058_8bd8d1d5+0x286>
  40cd6a:	call   409cb0 <__swc_fn_4fa09e82_000132_944f555b>
  40cd6f:	mov    rdi,rax
  40cd72:	mov    rcx,r13
  40cd75:	call   40e7e0 <__swc_fn_4fa09e82_000136_e3032dc2>
  40cd7a:	cmp    QWORD PTR [r13+0x2a70],0x0
  40cd82:	je     40ce3a <__swc_fn_4fa09e82_000058_8bd8d1d5+0x23a>
  40cd88:	nop    DWORD PTR [rax+rax*1+0x0]
  40cd90:	cmp    QWORD PTR [r13+0x2a70],0x100
  40cd9b:	jae    40cdb0 <__swc_fn_4fa09e82_000058_8bd8d1d5+0x1b0>
  40cd9d:	mov    rax,QWORD PTR [r13+0x2a68]
  40cda4:	add    rax,r12
  40cda7:	cmp    rax,rsi
  40cdaa:	jbe    40ce3a <__swc_fn_4fa09e82_000058_8bd8d1d5+0x23a>
  40cdb0:	xor    eax,eax
  40cdb2:	mov    rcx,QWORD PTR [r13+0x2a70]
  40cdb9:	mov    edx,0x1
  40cdbe:	cmp    rcx,0x1
  40cdc2:	jbe    40cdf9 <__swc_fn_4fa09e82_000058_8bd8d1d5+0x1f9>
  40cdc4:	cs nop WORD PTR [rax+rax*1+0x0]
  40cdce:	xchg   ax,ax
  40cdd0:	lea    r8,[rdx+rdx*4]
  40cdd4:	lea    r8,[r13+r8*8+0x268]
  40cddc:	lea    r9,[rax+rax*4]
  40cde0:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40cde8:	cmp    QWORD PTR [r8+0x18],r9
  40cdec:	cmovb  rax,rdx
  40cdf0:	add    rdx,0x1
  40cdf4:	cmp    rdx,rcx
  40cdf7:	jb     40cdd0 <__swc_fn_4fa09e82_000058_8bd8d1d5+0x1d0>
  40cdf9:	lea    rcx,[rax+rax*4]
  40cdfd:	lea    rcx,[r13+rcx*8+0x268]
  40ce05:	mov    r8,QWORD PTR [rcx]
  40ce08:	mov    r9,QWORD PTR [rcx+0x8]
  40ce0c:	mov    r10,QWORD PTR [rcx+0x10]
  40ce10:	mov    rcx,r13
  40ce13:	mov    rdx,rax
  40ce16:	call   40fd00 <__swc_fn_4fa09e82_000056_38b21f11>
  40ce1b:	mov    rcx,r13
  40ce1e:	mov    rdx,r8
  40ce21:	mov    r8,r9
  40ce24:	mov    r9,r10
  40ce27:	call   407750 <__swc_fn_4fa09e82_000039_40d1e569>
  40ce2c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40ce34:	jne    40cd90 <__swc_fn_4fa09e82_000058_8bd8d1d5+0x190>
  40ce3a:	add    QWORD PTR [r13+0x2a78],0x1
  40ce42:	mov    rax,QWORD PTR [r13+0x2a70]
  40ce49:	lea    rax,[rax+rax*4]
  40ce4d:	lea    rax,[r13+rax*8+0x268]
  40ce55:	mov    QWORD PTR [rax],r14
  40ce58:	mov    QWORD PTR [rax+0x8],r15
  40ce5c:	mov    QWORD PTR [rax+0x10],r12
  40ce60:	mov    rcx,QWORD PTR [r13+0x2a78]
  40ce67:	mov    QWORD PTR [rax+0x18],rcx
  40ce6b:	mov    QWORD PTR [rax+0x20],rdi
  40ce6f:	add    QWORD PTR [r13+0x2a68],r12
  40ce76:	add    QWORD PTR [r13+0x2a70],0x1
  40ce7e:	mov    rcx,r13
  40ce81:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40ce86:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40ce8f:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40ce98:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40cea1:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40ceaa:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40ceb3:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40cebc:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40cec5:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40cece:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40ced7:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40cee0:	add    rsp,0x148
  40cee7:	pop    rsi
  40cee8:	pop    rdi
  40cee9:	pop    r15
  40ceeb:	pop    r14
  40ceed:	pop    r13
  40ceef:	pop    r12
  40cef1:	ret
	...

000000000040cf00 <__swc_fn_4fa09e82_000061_0a7f67d9>:
  40cf00:	push   rbx
  40cf01:	push   r12
  40cf03:	push   r13
  40cf05:	push   r14
  40cf07:	push   r15
  40cf09:	push   rdi
  40cf0a:	push   rsi
  40cf0b:	sub    rsp,0xf0
  40cf12:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40cf18:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40cf1e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40cf24:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40cf2a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40cf33:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40cf3c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40cf45:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40cf4e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40cf57:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40cf60:	mov    eax,r8d
  40cf63:	mov    rbx,rcx
  40cf66:	mov    r12,rdx
  40cf69:	mov    QWORD PTR [rsp+0x18],rdx
  40cf6e:	mov    ecx,DWORD PTR [r12+0x58]
  40cf73:	mov    r13d,ecx
  40cf76:	cmp    ecx,0x10
  40cf79:	mov    ecx,0x10
  40cf7e:	cmovb  r13d,ecx
  40cf82:	test   r13d,r13d
  40cf85:	mov    rcx,r13
  40cf88:	mov    edx,0x8
  40cf8d:	cmove  ecx,edx
  40cf90:	dec    rcx
  40cf93:	mov    rdx,0xffffffffffffffff
  40cf9a:	sub    rdx,rcx
  40cf9d:	xor    r14d,r14d
  40cfa0:	mov    r8,rcx
  40cfa3:	not    r8
  40cfa6:	lea    rcx,[rcx+0x58]
  40cfaa:	and    rcx,r8
  40cfad:	cmp    rdx,0x58
  40cfb1:	cmovae r14,rcx
  40cfb5:	cmp    eax,0xffffffff
  40cfb8:	jne    40cfc1 <__swc_fn_4fa09e82_000061_0a7f67d9+0xc1>
  40cfba:	mov    r15,QWORD PTR [r12+0x48]
  40cfbf:	jmp    40cff3 <__swc_fn_4fa09e82_000061_0a7f67d9+0xf3>
  40cfc1:	test   eax,eax
  40cfc3:	jne    40cfcc <__swc_fn_4fa09e82_000061_0a7f67d9+0xcc>
  40cfc5:	mov    eax,0x8
  40cfca:	jmp    40cff0 <__swc_fn_4fa09e82_000061_0a7f67d9+0xf0>
  40cfcc:	cmp    eax,0x8
  40cfcf:	ja     40cfd7 <__swc_fn_4fa09e82_000061_0a7f67d9+0xd7>
  40cfd1:	shl    rax,0x4
  40cfd5:	jmp    40cff0 <__swc_fn_4fa09e82_000061_0a7f67d9+0xf0>
  40cfd7:	lea    eax,[rax-0x9]
  40cfda:	mov    ecx,eax
  40cfdc:	shr    ecx,0x2
  40cfdf:	and    eax,0x3
  40cfe2:	lea    ecx,[rcx+0x7]
  40cfe5:	lea    ecx,[rcx-0x2]
  40cfe8:	lea    eax,[rax+0x5]
  40cfeb:	shlx   rax,rax,rcx
  40cff0:	mov    r15,rax
  40cff3:	lea    rax,[r14+r13*1]
  40cff7:	mov    rcx,0xffffffffffffffff
  40cffe:	sub    rcx,rax
  40d001:	cmp    r15,rcx
  40d004:	jbe    40d014 <__swc_fn_4fa09e82_000061_0a7f67d9+0x114>
  40d006:	mov    QWORD PTR [r12+0x40],0x0
  40d00f:	jmp    40d3e6 <__swc_fn_4fa09e82_000061_0a7f67d9+0x4e6>
  40d014:	mov    QWORD PTR [rsp+0x20],r13
  40d019:	lea    r13,[rsp+0x8]
  40d01e:	add    rax,r15
  40d021:	mov    ecx,0x1000
  40d026:	test   ecx,ecx
  40d028:	mov    edx,0x8
  40d02d:	cmove  ecx,edx
  40d030:	dec    rcx
  40d033:	mov    rdx,0xffffffffffffffff
  40d03a:	sub    rdx,rcx
  40d03d:	cmp    rax,rdx
  40d040:	jbe    40d04c <__swc_fn_4fa09e82_000061_0a7f67d9+0x14c>
  40d042:	mov    QWORD PTR [r13+0x0],0x0
  40d04a:	jmp    40d059 <__swc_fn_4fa09e82_000061_0a7f67d9+0x159>
  40d04c:	add    rax,rcx
  40d04f:	andn   rax,rcx,rax
  40d054:	mov    QWORD PTR [rsp+0x8],rax
  40d059:	cmp    QWORD PTR [r13+0x0],0x0
  40d05e:	jne    40d06e <__swc_fn_4fa09e82_000061_0a7f67d9+0x16e>
  40d060:	mov    QWORD PTR [r12+0x40],0x0
  40d069:	jmp    40d3e6 <__swc_fn_4fa09e82_000061_0a7f67d9+0x4e6>
  40d06e:	mov    QWORD PTR [rsp+0x30],r15
  40d073:	xor    r15d,r15d
  40d076:	mov    QWORD PTR [rsp+0x38],0x0
  40d07f:	lea    r12,[rsp+0x10]
  40d084:	mov    QWORD PTR [rsp+0x28],r14
  40d089:	mov    r14,QWORD PTR [rsp+0x8]
  40d08e:	mov    QWORD PTR [rsp+0x10],r14
  40d093:	cmp    r14,0x10000
  40d09a:	ja     40d0a1 <__swc_fn_4fa09e82_000061_0a7f67d9+0x1a1>
  40d09c:	mov    rax,r14
  40d09f:	jmp    40d0f2 <__swc_fn_4fa09e82_000061_0a7f67d9+0x1f2>
  40d0a1:	xor    eax,eax
  40d0a3:	lea    rcx,[r14-0x1]
  40d0a7:	lzcnt  rax,rcx
  40d0ac:	mov    ecx,0x3f
  40d0b1:	sub    rcx,rax
  40d0b4:	mov    eax,0x1
  40d0b9:	lea    rcx,[rcx-0x3]
  40d0bd:	shl    rax,cl
  40d0c0:	mov    rcx,rax
  40d0c3:	cmp    rax,0x1000
  40d0ca:	mov    eax,0x1000
  40d0cf:	cmovb  rcx,rax
  40d0d3:	mov    rdx,0xffffffffffffffff
  40d0da:	sub    rdx,rcx
  40d0dd:	mov    rax,r14
  40d0e0:	lea    r8,[r14+rcx*1-0x1]
  40d0e5:	neg    rcx
  40d0e8:	and    r8,rcx
  40d0eb:	cmp    r14,rdx
  40d0ee:	cmovbe rax,r8
  40d0f2:	mov    QWORD PTR [rsp+0x8],rax
  40d0f7:	lea    rax,[rip+0x14f02]        # 422000 <__swc_data_base_4fa09e82>
  40d0fe:	mov    rax,QWORD PTR [rax]
  40d101:	cmp    rax,0xffffffffffffffff
  40d105:	je     40d114 <__swc_fn_4fa09e82_000061_0a7f67d9+0x214>
  40d107:	mov    eax,eax
  40d109:	mov    edi,eax
  40d10b:	xor    eax,eax
  40d10d:	call   407000 <pthread_getspecific@plt>
  40d112:	jmp    40d116 <__swc_fn_4fa09e82_000061_0a7f67d9+0x216>
  40d114:	xor    eax,eax
  40d116:	test   rax,rax
  40d119:	jne    40d128 <__swc_fn_4fa09e82_000061_0a7f67d9+0x228>
  40d11b:	call   40c5a0 <__swc_fn_4fa09e82_000031_90860ff2>
  40d120:	mov    rcx,rax
  40d123:	call   409c00 <__swc_fn_4fa09e82_000129_41c3251c>
  40d128:	test   rax,rax
  40d12b:	je     40d21c <__swc_fn_4fa09e82_000061_0a7f67d9+0x31c>
  40d131:	cmp    QWORD PTR [rax],rbx
  40d134:	jne    40d21c <__swc_fn_4fa09e82_000061_0a7f67d9+0x31c>
  40d13a:	cmp    DWORD PTR [rax+0x20],0x0
  40d13e:	jne    40d21c <__swc_fn_4fa09e82_000061_0a7f67d9+0x31c>
  40d144:	mov    rcx,QWORD PTR [rsp+0x8]
  40d149:	movabs rdx,0x7fffffffffffffff
  40d153:	cmp    rcx,rdx
  40d156:	mov    rdx,0xffffffffffffffff
  40d15d:	lea    r8,[rcx+rcx*1]
  40d161:	cmovbe rdx,r8
  40d165:	mov    r8d,DWORD PTR [rax+0x730]
  40d16c:	mov    r9d,r8d
  40d16f:	sub    rdx,rcx
  40d172:	inc    rdx
  40d175:	xor    r10d,r10d
  40d178:	test   r8,r8
  40d17b:	jbe    40d1ab <__swc_fn_4fa09e82_000061_0a7f67d9+0x2ab>
  40d17d:	nop    DWORD PTR [rax]
  40d180:	mov    r11d,r10d
  40d183:	lea    r11,[r11+r11*4]
  40d187:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40d18f:	sub    r11,rcx
  40d192:	cmp    r11,rdx
  40d195:	jae    40d1a2 <__swc_fn_4fa09e82_000061_0a7f67d9+0x2a2>
  40d197:	mov    r9d,r10d
  40d19a:	mov    rdx,r11
  40d19d:	test   r11,r11
  40d1a0:	je     40d1ab <__swc_fn_4fa09e82_000061_0a7f67d9+0x2ab>
  40d1a2:	add    r10,0x1
  40d1a6:	cmp    r10,r8
  40d1a9:	jb     40d180 <__swc_fn_4fa09e82_000061_0a7f67d9+0x280>
  40d1ab:	mov    ecx,DWORD PTR [rax+0x730]
  40d1b1:	cmp    r9d,ecx
  40d1b4:	jne    40d1ba <__swc_fn_4fa09e82_000061_0a7f67d9+0x2ba>
  40d1b6:	xor    eax,eax
  40d1b8:	jmp    40d219 <__swc_fn_4fa09e82_000061_0a7f67d9+0x319>
  40d1ba:	lea    rcx,[r9+r9*4]
  40d1be:	lea    rcx,[rax+rcx*8+0x738]
  40d1c6:	vmovups xmm0,XMMWORD PTR [rcx]
  40d1ca:	mov    rdx,QWORD PTR [rcx+0x10]
  40d1ce:	sub    DWORD PTR [rax+0x730],0x1
  40d1d5:	mov    r8d,DWORD PTR [rax+0x730]
  40d1dc:	lea    r8,[r8+r8*4]
  40d1e0:	lea    r8,[rax+r8*8+0x738]
  40d1e8:	vmovups xmm1,XMMWORD PTR [r8]
  40d1ed:	vmovups XMMWORD PTR [rcx],xmm1
  40d1f1:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40d1f7:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40d1fc:	mov    rax,QWORD PTR [r8+0x20]
  40d200:	mov    QWORD PTR [rcx+0x20],rax
  40d204:	vpshufd xmm1,xmm0,0xee
  40d209:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40d20f:	mov    QWORD PTR [rsp+0x10],rdx
  40d214:	vmovq  rax,xmm0
  40d219:	mov    r15,rax
  40d21c:	test   r15,r15
  40d21f:	jne    40d237 <__swc_fn_4fa09e82_000061_0a7f67d9+0x337>
  40d221:	mov    rcx,rbx
  40d224:	mov    rdx,QWORD PTR [rsp+0x8]
  40d229:	mov    r8,r13
  40d22c:	mov    r9,r12
  40d22f:	call   40caf0 <__swc_fn_4fa09e82_000055_81f7713d>
  40d234:	mov    r15,rax
  40d237:	test   r15,r15
  40d23a:	je     40d27b <__swc_fn_4fa09e82_000061_0a7f67d9+0x37b>
  40d23c:	cmp    QWORD PTR [r12],r14
  40d240:	jae    40d27b <__swc_fn_4fa09e82_000061_0a7f67d9+0x37b>
  40d242:	mov    rax,r15
  40d245:	add    rax,QWORD PTR [r12]
  40d249:	mov    rdx,r14
  40d24c:	sub    rdx,QWORD PTR [r12]
  40d250:	mov    rcx,rax
  40d253:	call   4072a0 <__swc_fn_4fa09e82_000003_7ab4792e>
  40d258:	test   al,al
  40d25a:	je     40d263 <__swc_fn_4fa09e82_000061_0a7f67d9+0x363>
  40d25c:	mov    QWORD PTR [rsp+0x10],r14
  40d261:	jmp    40d27b <__swc_fn_4fa09e82_000061_0a7f67d9+0x37b>
  40d263:	mov    rcx,rbx
  40d266:	mov    rdx,r15
  40d269:	mov    r8,QWORD PTR [rsp+0x8]
  40d26e:	mov    r9,QWORD PTR [rsp+0x10]
  40d273:	call   40cc00 <__swc_fn_4fa09e82_000058_8bd8d1d5>
  40d278:	xor    r15d,r15d
  40d27b:	test   r15,r15
  40d27e:	jne    40d2fa <__swc_fn_4fa09e82_000061_0a7f67d9+0x3fa>
  40d280:	cmp    r14,0x10000
  40d287:	ja     40d28e <__swc_fn_4fa09e82_000061_0a7f67d9+0x38e>
  40d289:	mov    rax,r14
  40d28c:	jmp    40d2df <__swc_fn_4fa09e82_000061_0a7f67d9+0x3df>
  40d28e:	xor    eax,eax
  40d290:	lea    rcx,[r14-0x1]
  40d294:	lzcnt  rax,rcx
  40d299:	mov    ecx,0x3f
  40d29e:	sub    rcx,rax
  40d2a1:	mov    eax,0x1
  40d2a6:	lea    rcx,[rcx-0x3]
  40d2aa:	shl    rax,cl
  40d2ad:	mov    rcx,rax
  40d2b0:	cmp    rax,0x1000
  40d2b7:	mov    eax,0x1000
  40d2bc:	cmovb  rcx,rax
  40d2c0:	mov    rdx,0xffffffffffffffff
  40d2c7:	sub    rdx,rcx
  40d2ca:	mov    rax,r14
  40d2cd:	lea    r8,[r14+rcx*1-0x1]
  40d2d2:	neg    rcx
  40d2d5:	and    r8,rcx
  40d2d8:	cmp    r14,rdx
  40d2db:	cmovbe rax,r8
  40d2df:	mov    QWORD PTR [rsp+0x8],rax
  40d2e4:	mov    QWORD PTR [rsp+0x10],r14
  40d2e9:	mov    rcx,rbx
  40d2ec:	mov    rdx,rax
  40d2ef:	mov    r8,r14
  40d2f2:	call   40c660 <__swc_fn_4fa09e82_000037_b4982903>
  40d2f7:	mov    r15,rax
  40d2fa:	test   r15,r15
  40d2fd:	jne    40d30b <__swc_fn_4fa09e82_000061_0a7f67d9+0x40b>
  40d2ff:	mov    r13,QWORD PTR [rsp+0x20]
  40d304:	mov    rsi,QWORD PTR [rsp+0x38]
  40d309:	jmp    40d347 <__swc_fn_4fa09e82_000061_0a7f67d9+0x447>
  40d30b:	mov    rax,r15
  40d30e:	add    rax,QWORD PTR [rsp+0x28]
  40d313:	mov    r13,QWORD PTR [rsp+0x20]
  40d318:	test   r13d,r13d
  40d31b:	mov    rcx,r13
  40d31e:	mov    edx,0x8
  40d323:	cmove  ecx,edx
  40d326:	dec    rcx
  40d329:	mov    rdx,0xffffffffffffffff
  40d330:	sub    rdx,rcx
  40d333:	cmp    rax,rdx
  40d336:	jbe    40d33c <__swc_fn_4fa09e82_000061_0a7f67d9+0x43c>
  40d338:	xor    eax,eax
  40d33a:	jmp    40d344 <__swc_fn_4fa09e82_000061_0a7f67d9+0x444>
  40d33c:	add    rax,rcx
  40d33f:	andn   rax,rcx,rax
  40d344:	mov    rsi,rax
  40d347:	mov    rax,QWORD PTR [rsp+0x8]
  40d34c:	test   r15,r15
  40d34f:	je     40d358 <__swc_fn_4fa09e82_000061_0a7f67d9+0x458>
  40d351:	mov    rdi,QWORD PTR [rsp+0x18]
  40d356:	jmp    40d36a <__swc_fn_4fa09e82_000061_0a7f67d9+0x46a>
  40d358:	mov    rdi,QWORD PTR [rsp+0x18]
  40d35d:	mov    QWORD PTR [rdi+0x40],0x0
  40d365:	jmp    40d3e6 <__swc_fn_4fa09e82_000061_0a7f67d9+0x4e6>
  40d36a:	lea    rdx,[rsi-0x58]
  40d36e:	mov    QWORD PTR [rsi-0x58],r15
  40d372:	mov    QWORD PTR [rsi-0x50],rax
  40d376:	mov    rax,QWORD PTR [rsp+0x10]
  40d37b:	mov    QWORD PTR [rsi-0x48],rax
  40d37f:	mov    QWORD PTR [rsi-0x40],rsi
  40d383:	mov    rax,QWORD PTR [rdi+0x48]
  40d387:	mov    QWORD PTR [rsi-0x38],rax
  40d38b:	mov    rax,QWORD PTR [rsp+0x30]
  40d390:	mov    QWORD PTR [rsi-0x30],rax
  40d394:	mov    DWORD PTR [rsi-0x10],r13d
  40d398:	mov    QWORD PTR [rsi-0x28],0x0
  40d3a0:	mov    QWORD PTR [rsi-0x20],0x0
  40d3a8:	add    r15,QWORD PTR [r12]
  40d3ac:	sub    r15,rsi
  40d3af:	mov    QWORD PTR [rsi-0x30],r15
  40d3b3:	mov    rcx,QWORD PTR [rbx+0x250]
  40d3ba:	nop    WORD PTR [rax+rax*1+0x0]
  40d3c0:	lea    r8,[rcx+r15*1]
  40d3c4:	mov    rax,rcx
  40d3c7:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40d3d0:	cmp    rax,rcx
  40d3d3:	je     40d3da <__swc_fn_4fa09e82_000061_0a7f67d9+0x4da>
  40d3d5:	mov    rcx,rax
  40d3d8:	jmp    40d3c0 <__swc_fn_4fa09e82_000061_0a7f67d9+0x4c0>
  40d3da:	mov    rcx,rbx
  40d3dd:	call   40fc70 <__swc_fn_4fa09e82_000053_82546d94>
  40d3e2:	mov    QWORD PTR [rdi+0x40],rsi
  40d3e6:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40d3ec:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40d3f2:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40d3f8:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40d3fe:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40d407:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40d410:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40d419:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40d422:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40d42b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40d434:	add    rsp,0xf0
  40d43b:	pop    rsi
  40d43c:	pop    rdi
  40d43d:	pop    r15
  40d43f:	pop    r14
  40d441:	pop    r13
  40d443:	pop    r12
  40d445:	pop    rbx
  40d446:	ret
	...

000000000040d450 <__swc_fn_4fa09e82_000064_b0d63361>:
  40d450:	push   rbx
  40d451:	push   r12
  40d453:	push   rdi
  40d454:	push   rsi
  40d455:	sub    rsp,0xb8
  40d45c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40d462:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40d468:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40d46e:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40d474:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40d47a:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40d480:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40d486:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40d48f:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40d498:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40d4a1:	mov    rbx,rdx
  40d4a4:	mov    r12,rcx
  40d4a7:	cmp    DWORD PTR [rbx+0x58],0x0
  40d4ab:	je     40d4c5 <__swc_fn_4fa09e82_000064_b0d63361+0x75>
  40d4ad:	mov    eax,DWORD PTR [rbx+0x58]
  40d4b0:	sub    eax,0x1
  40d4b3:	test   DWORD PTR [rbx+0x58],eax
  40d4b6:	je     40d4c5 <__swc_fn_4fa09e82_000064_b0d63361+0x75>
  40d4b8:	mov    QWORD PTR [rbx+0x40],0x0
  40d4c0:	jmp    40d6d7 <__swc_fn_4fa09e82_000064_b0d63361+0x287>
  40d4c5:	cmp    QWORD PTR [rbx+0x48],0x0
  40d4ca:	jne    40d4d9 <__swc_fn_4fa09e82_000064_b0d63361+0x89>
  40d4cc:	mov    QWORD PTR [rbx+0x40],0x0
  40d4d4:	jmp    40d6d7 <__swc_fn_4fa09e82_000064_b0d63361+0x287>
  40d4d9:	lea    rax,[rsp+0x8]
  40d4de:	mov    rcx,QWORD PTR [rbx+0x48]
  40d4e2:	cmp    rcx,0x8
  40d4e6:	ja     40d4f0 <__swc_fn_4fa09e82_000064_b0d63361+0xa0>
  40d4e8:	mov    DWORD PTR [rax],0x0
  40d4ee:	jmp    40d54b <__swc_fn_4fa09e82_000064_b0d63361+0xfb>
  40d4f0:	cmp    rcx,0x80
  40d4f7:	ja     40d507 <__swc_fn_4fa09e82_000064_b0d63361+0xb7>
  40d4f9:	lea    rcx,[rcx+0xf]
  40d4fd:	shr    rcx,0x4
  40d501:	mov    DWORD PTR [rsp+0x8],ecx
  40d505:	jmp    40d54b <__swc_fn_4fa09e82_000064_b0d63361+0xfb>
  40d507:	cmp    rcx,0x10000
  40d50e:	jbe    40d518 <__swc_fn_4fa09e82_000064_b0d63361+0xc8>
  40d510:	mov    DWORD PTR [rax],0xffffffff
  40d516:	jmp    40d54b <__swc_fn_4fa09e82_000064_b0d63361+0xfb>
  40d518:	dec    rcx
  40d51b:	xor    edx,edx
  40d51d:	lzcnt  rdx,rcx
  40d522:	mov    r8d,0x3f
  40d528:	sub    r8d,edx
  40d52b:	lea    edx,[r8-0x2]
  40d52f:	shrx   rcx,rcx,rdx
  40d534:	and    ecx,0x3
  40d537:	lea    edx,[r8-0x7]
  40d53b:	lea    edx,[rdx*4+0x0]
  40d542:	lea    edx,[rdx+0x9]
  40d545:	add    edx,ecx
  40d547:	mov    DWORD PTR [rsp+0x8],edx
  40d54b:	cmp    DWORD PTR [rax],0x0
  40d54e:	jne    40d55e <__swc_fn_4fa09e82_000064_b0d63361+0x10e>
  40d550:	cmp    DWORD PTR [rbx+0x58],0x8
  40d554:	jbe    40d55e <__swc_fn_4fa09e82_000064_b0d63361+0x10e>
  40d556:	mov    DWORD PTR [rsp+0x8],0x1
  40d55e:	cmp    DWORD PTR [rbx+0x58],0x10
  40d562:	jbe    40d5e1 <__swc_fn_4fa09e82_000064_b0d63361+0x191>
  40d568:	cmp    DWORD PTR [rbx+0x58],0x40
  40d56c:	ja     40d5e1 <__swc_fn_4fa09e82_000064_b0d63361+0x191>
  40d56e:	cmp    DWORD PTR [rax],0xffffffff
  40d571:	je     40d5e1 <__swc_fn_4fa09e82_000064_b0d63361+0x191>
  40d573:	mov    ecx,DWORD PTR [rsp+0x8]
  40d577:	mov    edx,DWORD PTR [rbx+0x58]
  40d57a:	dec    rdx
  40d57d:	cmp    ecx,0x2d
  40d580:	jae    40d5d8 <__swc_fn_4fa09e82_000064_b0d63361+0x188>
  40d582:	cs nop WORD PTR [rax+rax*1+0x0]
  40d58c:	nop    DWORD PTR [rax+0x0]
  40d590:	mov    r8d,ecx
  40d593:	test   ecx,ecx
  40d595:	jne    40d59f <__swc_fn_4fa09e82_000064_b0d63361+0x14f>
  40d597:	mov    r8d,0x8
  40d59d:	jmp    40d5cb <__swc_fn_4fa09e82_000064_b0d63361+0x17b>
  40d59f:	cmp    r8d,0x8
  40d5a3:	ja     40d5ab <__swc_fn_4fa09e82_000064_b0d63361+0x15b>
  40d5a5:	shl    r8,0x4
  40d5a9:	jmp    40d5cb <__swc_fn_4fa09e82_000064_b0d63361+0x17b>
  40d5ab:	lea    r8d,[r8-0x9]
  40d5af:	mov    r9d,r8d
  40d5b2:	shr    r9d,0x2
  40d5b6:	and    r8d,0x3
  40d5ba:	lea    r9d,[r9+0x7]
  40d5be:	lea    r9d,[r9-0x2]
  40d5c2:	lea    r8d,[r8+0x5]
  40d5c6:	shlx   r8,r8,r9
  40d5cb:	test   r8,rdx
  40d5ce:	je     40d5dd <__swc_fn_4fa09e82_000064_b0d63361+0x18d>
  40d5d0:	add    ecx,0x1
  40d5d3:	cmp    ecx,0x2d
  40d5d6:	jb     40d590 <__swc_fn_4fa09e82_000064_b0d63361+0x140>
  40d5d8:	mov    ecx,0xffffffff
  40d5dd:	mov    DWORD PTR [rsp+0x8],ecx
  40d5e1:	mov    ecx,DWORD PTR [rsp+0x8]
  40d5e5:	cmp    ecx,0xffffffff
  40d5e8:	je     40d5f0 <__swc_fn_4fa09e82_000064_b0d63361+0x1a0>
  40d5ea:	cmp    DWORD PTR [rbx+0x58],0x40
  40d5ee:	jbe    40d603 <__swc_fn_4fa09e82_000064_b0d63361+0x1b3>
  40d5f0:	mov    rcx,r12
  40d5f3:	mov    rdx,rbx
  40d5f6:	mov    r8d,DWORD PTR [rax]
  40d5f9:	call   40cf00 <__swc_fn_4fa09e82_000061_0a7f67d9>
  40d5fe:	jmp    40d6d7 <__swc_fn_4fa09e82_000064_b0d63361+0x287>
  40d603:	lea    rax,[rip+0x149f6]        # 422000 <__swc_data_base_4fa09e82>
  40d60a:	mov    rax,QWORD PTR [rax]
  40d60d:	cmp    rax,0xffffffffffffffff
  40d611:	je     40d620 <__swc_fn_4fa09e82_000064_b0d63361+0x1d0>
  40d613:	mov    eax,eax
  40d615:	mov    edi,eax
  40d617:	xor    eax,eax
  40d619:	call   407000 <pthread_getspecific@plt>
  40d61e:	jmp    40d622 <__swc_fn_4fa09e82_000064_b0d63361+0x1d2>
  40d620:	xor    eax,eax
  40d622:	test   rax,rax
  40d625:	jne    40d634 <__swc_fn_4fa09e82_000064_b0d63361+0x1e4>
  40d627:	call   40c5a0 <__swc_fn_4fa09e82_000031_90860ff2>
  40d62c:	mov    rcx,rax
  40d62f:	call   409c00 <__swc_fn_4fa09e82_000129_41c3251c>
  40d634:	test   rax,rax
  40d637:	je     40d644 <__swc_fn_4fa09e82_000064_b0d63361+0x1f4>
  40d639:	cmp    QWORD PTR [rax],r12
  40d63c:	jne    40d644 <__swc_fn_4fa09e82_000064_b0d63361+0x1f4>
  40d63e:	cmp    DWORD PTR [rax+0x20],0x0
  40d642:	je     40d64f <__swc_fn_4fa09e82_000064_b0d63361+0x1ff>
  40d644:	mov    rcx,r12
  40d647:	mov    rdx,rax
  40d64a:	call   40f8b0 <__swc_fn_4fa09e82_000041_414cc921>
  40d64f:	test   rax,rax
  40d652:	jne    40d65e <__swc_fn_4fa09e82_000064_b0d63361+0x20e>
  40d654:	mov    QWORD PTR [rbx+0x40],0x0
  40d65c:	jmp    40d6d7 <__swc_fn_4fa09e82_000064_b0d63361+0x287>
  40d65e:	lea    r8,[rsp+0xc]
  40d663:	mov    ecx,DWORD PTR [rsp+0x8]
  40d667:	mov    DWORD PTR [rsp+0xc],ecx
  40d66b:	mov    ecx,DWORD PTR [r8]
  40d66e:	lea    rcx,[rcx+rcx*4]
  40d672:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40d677:	test   rcx,rcx
  40d67a:	je     40d6b3 <__swc_fn_4fa09e82_000064_b0d63361+0x263>
  40d67c:	mov    rdx,QWORD PTR [rcx]
  40d67f:	test   rdx,rdx
  40d682:	je     40d690 <__swc_fn_4fa09e82_000064_b0d63361+0x240>
  40d684:	mov    r9,QWORD PTR [rdx]
  40d687:	mov    QWORD PTR [rcx],r9
  40d68a:	add    DWORD PTR [rcx+0x28],0x1
  40d68e:	jmp    40d6ae <__swc_fn_4fa09e82_000064_b0d63361+0x25e>
  40d690:	mov    rdx,QWORD PTR [rcx+0x18]
  40d694:	cmp    QWORD PTR [rcx+0x20],rdx
  40d698:	jae    40d6ac <__swc_fn_4fa09e82_000064_b0d63361+0x25c>
  40d69a:	mov    rdx,QWORD PTR [rcx+0x20]
  40d69e:	mov    r9d,DWORD PTR [rcx+0x2c]
  40d6a2:	add    QWORD PTR [rcx+0x20],r9
  40d6a6:	add    DWORD PTR [rcx+0x28],0x1
  40d6aa:	jmp    40d6ae <__swc_fn_4fa09e82_000064_b0d63361+0x25e>
  40d6ac:	xor    edx,edx
  40d6ae:	test   rdx,rdx
  40d6b1:	jne    40d6c4 <__swc_fn_4fa09e82_000064_b0d63361+0x274>
  40d6b3:	mov    rcx,r12
  40d6b6:	mov    rdx,rax
  40d6b9:	mov    r8d,DWORD PTR [r8]
  40d6bc:	call   40fa20 <__swc_fn_4fa09e82_000050_ab8077df>
  40d6c1:	mov    rdx,rax
  40d6c4:	test   rdx,rdx
  40d6c7:	jne    40d6d3 <__swc_fn_4fa09e82_000064_b0d63361+0x283>
  40d6c9:	mov    QWORD PTR [rbx+0x40],0x0
  40d6d1:	jmp    40d6d7 <__swc_fn_4fa09e82_000064_b0d63361+0x287>
  40d6d3:	mov    QWORD PTR [rbx+0x40],rdx
  40d6d7:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40d6dd:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40d6e3:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40d6e9:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40d6ef:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40d6f5:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40d6fb:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40d701:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40d70a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40d713:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40d71c:	add    rsp,0xb8
  40d723:	pop    rsi
  40d724:	pop    rdi
  40d725:	pop    r12
  40d727:	pop    rbx
  40d728:	ret
  40d729:	add    BYTE PTR [rax],al
  40d72b:	add    BYTE PTR [rax],al
  40d72d:	add    BYTE PTR [rax],al
	...

000000000040d730 <__swc_fn_4fa09e82_000067_94a51053>:
  40d730:	ret
	...

000000000040d740 <__swc_fn_4fa09e82_000070_3181d86c>:
  40d740:	push   r12
  40d742:	push   r13
  40d744:	push   r14
  40d746:	push   rdi
  40d747:	push   rsi
  40d748:	sub    rsp,0x1a0
  40d74f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40d758:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40d761:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40d76a:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40d773:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40d77c:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40d785:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40d78e:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40d797:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40d7a0:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40d7a9:	mov    r12,rdx
  40d7ac:	mov    r13,rcx
  40d7af:	mov    rax,QWORD PTR [r12+0x48]
  40d7b4:	mov    ecx,DWORD PTR [r12+0x58]
  40d7b9:	lea    rdx,[rax-0x1]
  40d7bd:	cmp    rdx,0x10000
  40d7c4:	jae    40d8be <__swc_fn_4fa09e82_000070_3181d86c+0x17e>
  40d7ca:	cmp    rax,0x8
  40d7ce:	ja     40d7d5 <__swc_fn_4fa09e82_000070_3181d86c+0x95>
  40d7d0:	xor    r14d,r14d
  40d7d3:	jmp    40d827 <__swc_fn_4fa09e82_000070_3181d86c+0xe7>
  40d7d5:	cmp    rax,0x80
  40d7dc:	ja     40d7e8 <__swc_fn_4fa09e82_000070_3181d86c+0xa8>
  40d7de:	lea    r14,[rax+0xf]
  40d7e2:	shr    r14,0x4
  40d7e6:	jmp    40d827 <__swc_fn_4fa09e82_000070_3181d86c+0xe7>
  40d7e8:	cmp    rax,0x10000
  40d7ef:	jbe    40d7f9 <__swc_fn_4fa09e82_000070_3181d86c+0xb9>
  40d7f1:	mov    r14d,0xffffffff
  40d7f7:	jmp    40d827 <__swc_fn_4fa09e82_000070_3181d86c+0xe7>
  40d7f9:	xor    eax,eax
  40d7fb:	lzcnt  rax,rdx
  40d800:	mov    r8d,0x3f
  40d806:	sub    r8d,eax
  40d809:	lea    eax,[r8-0x2]
  40d80d:	shrx   rax,rdx,rax
  40d812:	and    eax,0x3
  40d815:	lea    edx,[r8-0x7]
  40d819:	lea    edx,[rdx*4+0x0]
  40d820:	lea    edx,[rdx+0x9]
  40d823:	lea    r14d,[rdx+rax*1]
  40d827:	cmp    ecx,0x8
  40d82a:	jbe    40d843 <__swc_fn_4fa09e82_000070_3181d86c+0x103>
  40d82c:	cmp    ecx,0x10
  40d82f:	jne    40d8be <__swc_fn_4fa09e82_000070_3181d86c+0x17e>
  40d835:	test   r14d,r14d
  40d838:	mov    eax,0x1
  40d83d:	cmove  r14d,eax
  40d841:	jmp    40d84a <__swc_fn_4fa09e82_000070_3181d86c+0x10a>
  40d843:	lea    eax,[rcx-0x1]
  40d846:	test   eax,ecx
  40d848:	jne    40d8be <__swc_fn_4fa09e82_000070_3181d86c+0x17e>
  40d84a:	lea    rax,[rip+0x147af]        # 422000 <__swc_data_base_4fa09e82>
  40d851:	mov    rax,QWORD PTR [rax]
  40d854:	cmp    rax,0xffffffffffffffff
  40d858:	je     40d867 <__swc_fn_4fa09e82_000070_3181d86c+0x127>
  40d85a:	mov    eax,eax
  40d85c:	mov    edi,eax
  40d85e:	xor    eax,eax
  40d860:	call   407000 <pthread_getspecific@plt>
  40d865:	jmp    40d869 <__swc_fn_4fa09e82_000070_3181d86c+0x129>
  40d867:	xor    eax,eax
  40d869:	test   rax,rax
  40d86c:	je     40d8be <__swc_fn_4fa09e82_000070_3181d86c+0x17e>
  40d86e:	cmp    QWORD PTR [rax],r13
  40d871:	jne    40d8be <__swc_fn_4fa09e82_000070_3181d86c+0x17e>
  40d873:	lea    rcx,[r14+r14*4]
  40d877:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40d87c:	test   rax,rax
  40d87f:	je     40d8be <__swc_fn_4fa09e82_000070_3181d86c+0x17e>
  40d881:	mov    rcx,QWORD PTR [rax]
  40d884:	test   rcx,rcx
  40d887:	je     40d895 <__swc_fn_4fa09e82_000070_3181d86c+0x155>
  40d889:	mov    rdx,QWORD PTR [rcx]
  40d88c:	mov    QWORD PTR [rax],rdx
  40d88f:	add    DWORD PTR [rax+0x28],0x1
  40d893:	jmp    40d8b2 <__swc_fn_4fa09e82_000070_3181d86c+0x172>
  40d895:	mov    rcx,QWORD PTR [rax+0x18]
  40d899:	cmp    QWORD PTR [rax+0x20],rcx
  40d89d:	jae    40d8b0 <__swc_fn_4fa09e82_000070_3181d86c+0x170>
  40d89f:	mov    rcx,QWORD PTR [rax+0x20]
  40d8a3:	mov    edx,DWORD PTR [rax+0x2c]
  40d8a6:	add    QWORD PTR [rax+0x20],rdx
  40d8aa:	add    DWORD PTR [rax+0x28],0x1
  40d8ae:	jmp    40d8b2 <__swc_fn_4fa09e82_000070_3181d86c+0x172>
  40d8b0:	xor    ecx,ecx
  40d8b2:	test   rcx,rcx
  40d8b5:	je     40d8be <__swc_fn_4fa09e82_000070_3181d86c+0x17e>
  40d8b7:	mov    QWORD PTR [r12+0x40],rcx
  40d8bc:	jmp    40d8c9 <__swc_fn_4fa09e82_000070_3181d86c+0x189>
  40d8be:	mov    rcx,r13
  40d8c1:	mov    rdx,r12
  40d8c4:	call   4104a0 <__swc_fn_4fa09e82_000071_0d1ef36f>
  40d8c9:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40d8d2:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40d8db:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40d8e4:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40d8ed:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40d8f6:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40d8ff:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40d908:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40d911:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40d91a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40d923:	add    rsp,0x1a0
  40d92a:	pop    rsi
  40d92b:	pop    rdi
  40d92c:	pop    r14
  40d92e:	pop    r13
  40d930:	pop    r12
  40d932:	ret
	...

000000000040d940 <__swc_fn_4fa09e82_000073_c6c71bf7>:
  40d940:	push   r12
  40d942:	push   r13
  40d944:	push   r14
  40d946:	push   r15
  40d948:	push   rdi
  40d949:	push   rsi
  40d94a:	sub    rsp,0x188
  40d951:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40d95a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40d963:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40d96c:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40d975:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40d97e:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40d987:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40d990:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40d999:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40d9a2:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40d9ab:	mov    r12,rdx
  40d9ae:	mov    r13,rcx
  40d9b1:	mov    r14,QWORD PTR [r12+0x40]
  40d9b6:	lea    rax,[rip+0x166b3]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  40d9bd:	mov    rcx,r14
  40d9c0:	sub    rcx,QWORD PTR [rax+0x8]
  40d9c4:	mov    rax,QWORD PTR [rip+0x166b5]        # 424080 <__swc_bss_base_4fa09e82+0x40>
  40d9cb:	cmp    rcx,rax
  40d9ce:	jae    40d9fa <__swc_fn_4fa09e82_000073_c6c71bf7+0xba>
  40d9d0:	mov    rax,r14
  40d9d3:	and    rax,0xffffffffffc00000
  40d9da:	mov    rcx,r14
  40d9dd:	shr    rcx,0x10
  40d9e1:	and    ecx,0x3f
  40d9e4:	mov    edx,DWORD PTR [rax+0x28]
  40d9e7:	shrx   ecx,ecx,edx
  40d9ec:	shl    rcx,0x4
  40d9f0:	lea    r15,[rax+rcx*8+0x80]
  40d9f8:	jmp    40da05 <__swc_fn_4fa09e82_000073_c6c71bf7+0xc5>
  40d9fa:	mov    rcx,r14
  40d9fd:	call   40c4d0 <__swc_fn_4fa09e82_000022_3a2e2048>
  40da02:	mov    r15,rax
  40da05:	test   r15,r15
  40da08:	je     40daaf <__swc_fn_4fa09e82_000073_c6c71bf7+0x16f>
  40da0e:	lea    rax,[rip+0x145eb]        # 422000 <__swc_data_base_4fa09e82>
  40da15:	mov    rax,QWORD PTR [rax]
  40da18:	cmp    rax,0xffffffffffffffff
  40da1c:	je     40da2b <__swc_fn_4fa09e82_000073_c6c71bf7+0xeb>
  40da1e:	mov    eax,eax
  40da20:	mov    edi,eax
  40da22:	xor    eax,eax
  40da24:	call   407000 <pthread_getspecific@plt>
  40da29:	jmp    40da2d <__swc_fn_4fa09e82_000073_c6c71bf7+0xed>
  40da2b:	xor    eax,eax
  40da2d:	mov    rcx,QWORD PTR [r15+0x40]
  40da31:	cmp    rcx,rax
  40da34:	jne    40da94 <__swc_fn_4fa09e82_000073_c6c71bf7+0x154>
  40da36:	test   rax,rax
  40da39:	je     40daaf <__swc_fn_4fa09e82_000073_c6c71bf7+0x16f>
  40da3b:	mov    ecx,DWORD PTR [r15+0x6c]
  40da3f:	test   ecx,ecx
  40da41:	je     40da61 <__swc_fn_4fa09e82_000073_c6c71bf7+0x121>
  40da43:	mov    rcx,r13
  40da46:	mov    rdx,rax
  40da49:	mov    r8,r15
  40da4c:	mov    QWORD PTR [rsp+0xd8],rax
  40da54:	call   40f9b0 <__swc_fn_4fa09e82_000047_bc5ec610>
  40da59:	mov    rax,QWORD PTR [rsp+0xd8]
  40da61:	mov    rcx,QWORD PTR [r15]
  40da64:	mov    QWORD PTR [r14],rcx
  40da67:	mov    QWORD PTR [r15],r14
  40da6a:	sub    DWORD PTR [r15+0x28],0x1
  40da6f:	jne    40daa4 <__swc_fn_4fa09e82_000073_c6c71bf7+0x164>
  40da71:	movzx  ecx,BYTE PTR [r15+0x39]
  40da76:	lea    rcx,[rcx+rcx*4]
  40da7a:	lea    rcx,[rax+rcx*8+0x28]
  40da7f:	cmp    QWORD PTR [rcx],r15
  40da82:	je     40daa4 <__swc_fn_4fa09e82_000073_c6c71bf7+0x164>
  40da84:	mov    rcx,r13
  40da87:	mov    rdx,rax
  40da8a:	mov    r8,r15
  40da8d:	call   407d80 <__swc_fn_4fa09e82_000051_f7021588>
  40da92:	jmp    40daa4 <__swc_fn_4fa09e82_000073_c6c71bf7+0x164>
  40da94:	test   rcx,rcx
  40da97:	je     40daaf <__swc_fn_4fa09e82_000073_c6c71bf7+0x16f>
  40da99:	mov    rcx,r15
  40da9c:	mov    rdx,r14
  40da9f:	call   40c110 <__swc_fn_4fa09e82_000010_395bb04b>
  40daa4:	mov    QWORD PTR [r12+0x40],0x0
  40daad:	jmp    40daba <__swc_fn_4fa09e82_000073_c6c71bf7+0x17a>
  40daaf:	mov    rcx,r13
  40dab2:	mov    rdx,r12
  40dab5:	call   4104c0 <__swc_fn_4fa09e82_000074_518516c2>
  40daba:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40dac3:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40dacc:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40dad5:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40dade:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40dae7:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40daf0:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40daf9:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40db02:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40db0b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40db14:	add    rsp,0x188
  40db1b:	pop    rsi
  40db1c:	pop    rdi
  40db1d:	pop    r15
  40db1f:	pop    r14
  40db21:	pop    r13
  40db23:	pop    r12
  40db25:	ret
	...

000000000040db30 <__swc_fn_4fa09e82_000076_9f0c6acf>:
  40db30:	sub    rsp,0x8
  40db34:	mov    rax,rdx
  40db37:	mov    rdx,QWORD PTR [rax+0x40]
  40db3b:	mov    r8,rax
  40db3e:	call   40d730 <__swc_fn_4fa09e82_000067_94a51053>
  40db43:	add    rsp,0x8
  40db47:	ret
	...

000000000040db50 <__swc_fn_4fa09e82_000079_34776ded>:
  40db50:	push   rsi
  40db51:	push   rdi
  40db52:	sub    rsp,0x8
  40db56:	cmp    rcx,0xffffffffffffffef
  40db5a:	ja     40db80 <__swc_fn_4fa09e82_000079_34776ded+0x30>
  40db5c:	xor    esi,esi
  40db5e:	lea    rax,[rcx+0x100f]
  40db65:	and    rax,0xfffffffffffff000
  40db6c:	lea    rcx,[rcx+0x10]
  40db70:	cmp    rcx,0xfffffffffffff000
  40db77:	cmovbe rsi,rax
  40db7b:	test   rsi,rsi
  40db7e:	jne    40db89 <__swc_fn_4fa09e82_000079_34776ded+0x39>
  40db80:	xor    eax,eax
  40db82:	add    rsp,0x8
  40db86:	pop    rdi
  40db87:	pop    rsi
  40db88:	ret
  40db89:	mov    rcx,rsi
  40db8c:	call   4110f0 <__swc_fn_4fa09e82_000110_8d425bd3>
  40db91:	mov    rdi,rax
  40db94:	test   rax,rax
  40db97:	jne    40dba2 <__swc_fn_4fa09e82_000079_34776ded+0x52>
  40db99:	xor    eax,eax
  40db9b:	add    rsp,0x8
  40db9f:	pop    rdi
  40dba0:	pop    rsi
  40dba1:	ret
  40dba2:	mov    rcx,rdi
  40dba5:	mov    rdx,rsi
  40dba8:	call   40e180 <__swc_fn_4fa09e82_000112_b25e3a45>
  40dbad:	test   al,al
  40dbaf:	jne    40dbc5 <__swc_fn_4fa09e82_000079_34776ded+0x75>
  40dbb1:	mov    rcx,rdi
  40dbb4:	mov    rdx,rsi
  40dbb7:	call   4098a0 <__swc_fn_4fa09e82_000114_49b378a9>
  40dbbc:	xor    eax,eax
  40dbbe:	add    rsp,0x8
  40dbc2:	pop    rdi
  40dbc3:	pop    rsi
  40dbc4:	ret
  40dbc5:	mov    QWORD PTR [rdi],rsi
  40dbc8:	mov    QWORD PTR [rdi+0x8],0x0
  40dbd0:	lea    rax,[rdi+0x10]
  40dbd4:	add    rsp,0x8
  40dbd8:	pop    rdi
  40dbd9:	pop    rsi
  40dbda:	ret
  40dbdb:	add    BYTE PTR [rax],al
  40dbdd:	add    BYTE PTR [rax],al
	...

000000000040dbe0 <__swc_fn_4fa09e82_000082_754dcd57>:
  40dbe0:	sub    rsp,0x8
  40dbe4:	cmp    BYTE PTR [rcx+0x2c],0x10
  40dbe8:	jne    40dbf3 <__swc_fn_4fa09e82_000082_754dcd57+0x13>
  40dbea:	test   DWORD PTR [rcx+0x28],0x80
  40dbf1:	je     40dbfb <__swc_fn_4fa09e82_000082_754dcd57+0x1b>
  40dbf3:	mov    rax,rcx
  40dbf6:	add    rsp,0x8
  40dbfa:	ret
  40dbfb:	mov    rcx,QWORD PTR [rcx+0x40]
  40dbff:	call   40dbe0 <__swc_fn_4fa09e82_000082_754dcd57>
  40dc04:	add    rsp,0x8
  40dc08:	ret
	...

000000000040dc20 <__swc_fn_4fa09e82_000085_1edf7c76>:
  40dc20:	push   rsi
  40dc21:	push   rdi
  40dc22:	push   r12
  40dc24:	push   r13
  40dc26:	sub    rsp,0x8
  40dc2a:	mov    rsi,rdx
  40dc2d:	mov    rdi,rcx
  40dc30:	xor    r8d,r8d
  40dc33:	call   4085a0 <__swc_fn_4fa09e82_000090_a2d50c23>
  40dc38:	test   al,al
  40dc3a:	je     40dc4c <__swc_fn_4fa09e82_000085_1edf7c76+0x2c>
  40dc3c:	mov    eax,0x1
  40dc41:	add    rsp,0x8
  40dc45:	pop    r13
  40dc47:	pop    r12
  40dc49:	pop    rdi
  40dc4a:	pop    rsi
  40dc4b:	ret
  40dc4c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40dc51:	je     40dc60 <__swc_fn_4fa09e82_000085_1edf7c76+0x40>
  40dc53:	xor    eax,eax
  40dc55:	add    rsp,0x8
  40dc59:	pop    r13
  40dc5b:	pop    r12
  40dc5d:	pop    rdi
  40dc5e:	pop    rsi
  40dc5f:	ret
  40dc60:	mov    r12,QWORD PTR [rsi+0x98]
  40dc67:	mov    rax,QWORD PTR [rsi+0xa0]
  40dc6e:	mov    rsi,rax
  40dc71:	xor    r13d,r13d
  40dc74:	test   rsi,rsi
  40dc77:	je     40dcd4 <__swc_fn_4fa09e82_000085_1edf7c76+0xb4>
  40dc79:	cs nop WORD PTR [rax+rax*1+0x0]
  40dc83:	cs nop WORD PTR [rax+rax*1+0x0]
  40dc8d:	nop    DWORD PTR [rax]
  40dc90:	lea    rax,[r13*8+0x0]
  40dc98:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40dc9d:	mov    rcx,rax
  40dca0:	call   40dbe0 <__swc_fn_4fa09e82_000082_754dcd57>
  40dca5:	cmp    BYTE PTR [rax+0x2c],0xe
  40dca9:	jne    40dcca <__swc_fn_4fa09e82_000085_1edf7c76+0xaa>
  40dcab:	mov    rcx,rdi
  40dcae:	mov    rdx,rax
  40dcb1:	call   40dc20 <__swc_fn_4fa09e82_000085_1edf7c76>
  40dcb6:	test   al,al
  40dcb8:	je     40dcca <__swc_fn_4fa09e82_000085_1edf7c76+0xaa>
  40dcba:	mov    eax,0x1
  40dcbf:	add    rsp,0x8
  40dcc3:	pop    r13
  40dcc5:	pop    r12
  40dcc7:	pop    rdi
  40dcc8:	pop    rsi
  40dcc9:	ret
  40dcca:	add    r13,0x1
  40dcce:	sub    rsi,0x1
  40dcd2:	jne    40dc90 <__swc_fn_4fa09e82_000085_1edf7c76+0x70>
  40dcd4:	xor    eax,eax
  40dcd6:	add    rsp,0x8
  40dcda:	pop    r13
  40dcdc:	pop    r12
  40dcde:	pop    rdi
  40dcdf:	pop    rsi
  40dce0:	ret
	...

000000000040dcf0 <__swc_fn_4fa09e82_000088_fcb34f6a>:
  40dcf0:	sub    rsp,0x18
  40dcf4:	vxorps xmm0,xmm0,xmm0
  40dcf8:	vmovdqu XMMWORD PTR [rsp],xmm0
  40dcfd:	call   4106d0 <__swc_fn_4fa09e82_000089_386582f3>
  40dd02:	add    rsp,0x18
  40dd06:	ret
	...

000000000040dd10 <__swc_fn_4fa09e82_000091_3d2f5a0d>:
  40dd10:	sub    rsp,0x8
  40dd14:	mov    rcx,QWORD PTR [rip+0x19025]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40dd1b:	test   rcx,rcx
  40dd1e:	jne    40dd30 <__swc_fn_4fa09e82_000091_3d2f5a0d+0x20>
  40dd20:	call   40f0f0 <__swc_fn_4fa09e82_000166_cf398896>
  40dd25:	lea    rcx,[rax+0x1]
  40dd29:	mov    QWORD PTR [rip+0x19010],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40dd30:	dec    rcx
  40dd33:	call   40b6c0 <__swc_fn_4fa09e82_000168_fce60b2b>
  40dd38:	mov    rax,QWORD PTR [rax+0xc0]
  40dd3f:	and    eax,0x1
  40dd42:	setne  al
  40dd45:	add    rsp,0x8
  40dd49:	ret
	...

000000000040dd60 <__swc_fn_4fa09e82_000094_14db3cf9>:
  40dd60:	push   rbx
  40dd61:	push   rsi
  40dd62:	push   rdi
  40dd63:	push   r12
  40dd65:	sub    rsp,0x28
  40dd69:	mov    rbx,rcx
  40dd6c:	call   408900 <__swc_fn_4fa09e82_000093_f8c16535>
  40dd71:	mov    rcx,QWORD PTR [rip+0x18fc8]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40dd78:	test   rcx,rcx
  40dd7b:	jne    40dd8d <__swc_fn_4fa09e82_000094_14db3cf9+0x2d>
  40dd7d:	call   40f0f0 <__swc_fn_4fa09e82_000166_cf398896>
  40dd82:	lea    rcx,[rax+0x1]
  40dd86:	mov    QWORD PTR [rip+0x18fb3],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40dd8d:	dec    rcx
  40dd90:	call   40b6c0 <__swc_fn_4fa09e82_000168_fce60b2b>
  40dd95:	mov    rsi,rax
  40dd98:	lea    rcx,[rsp+0x8]
  40dd9d:	call   410b10 <__swc_fn_4fa09e82_000092_8252f8c0>
  40dda2:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40dda9:	mov    r12,QWORD PTR [rsi+0xbe8]
  40ddb0:	lea    rcx,[rsi+0x10]
  40ddb4:	call   411c60 <__swc_fn_4fa09e82_000158_232ffa22>
  40ddb9:	mov    rcx,rsi
  40ddbc:	call   410c80 <__swc_fn_4fa09e82_000101_eab3874f>
  40ddc1:	vxorps xmm0,xmm0,xmm0
  40ddc5:	xor    eax,eax
  40ddc7:	cs nop WORD PTR [rax+rax*1+0x0]
  40ddd1:	cs nop WORD PTR [rax+rax*1+0x0]
  40dddb:	nop    DWORD PTR [rax+rax*1+0x0]
  40dde0:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40dde5:	add    rax,0x10
  40dde9:	cmp    rax,0xbf0
  40ddf0:	jne    40dde0 <__swc_fn_4fa09e82_000094_14db3cf9+0x80>
  40ddf2:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ddf8:	vmovups XMMWORD PTR [rsi],xmm0
  40ddfc:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40de02:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40de0a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40de11:	mov    QWORD PTR [rsi+0xbe8],r12
  40de18:	mov    rcx,QWORD PTR [rip+0x18f21]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40de1f:	test   rcx,rcx
  40de22:	jne    40de34 <__swc_fn_4fa09e82_000094_14db3cf9+0xd4>
  40de24:	call   40f0f0 <__swc_fn_4fa09e82_000166_cf398896>
  40de29:	lea    rcx,[rax+0x1]
  40de2d:	mov    QWORD PTR [rip+0x18f0c],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40de34:	dec    rcx
  40de37:	call   40b6c0 <__swc_fn_4fa09e82_000168_fce60b2b>
  40de3c:	mov    rsi,rax
  40de3f:	mov    QWORD PTR [rsi+0xc0],rbx
  40de46:	and    ebx,0x1
  40de49:	jne    40de4d <__swc_fn_4fa09e82_000094_14db3cf9+0xed>
  40de4b:	xor    eax,eax
  40de4d:	test   rbx,rbx
  40de50:	sete   al
  40de53:	xor    cl,cl
  40de55:	xor    dl,dl
  40de57:	xor    r8b,r8b
  40de5a:	xor    r9b,r9b
  40de5d:	xor    r10b,r10b
  40de60:	mov    r11,rax
  40de63:	call   4104d0 <__swc_fn_4fa09e82_000077_8b8614a7>
  40de68:	lea    rbx,[rsp+0x18]
  40de6d:	mov    rcx,rbx
  40de70:	call   410b10 <__swc_fn_4fa09e82_000092_8252f8c0>
  40de75:	lea    rcx,[rsi+0x10]
  40de79:	mov    edx,0x400000
  40de7e:	mov    r8,rbx
  40de81:	call   40ee30 <__swc_fn_4fa09e82_000160_d8afac28>
  40de86:	lea    rcx,[rsi+0x68]
  40de8a:	mov    edx,0x4000
  40de8f:	mov    r8,rbx
  40de92:	call   40ee30 <__swc_fn_4fa09e82_000160_d8afac28>
  40de97:	add    rsp,0x28
  40de9b:	pop    r12
  40de9d:	pop    rdi
  40de9e:	pop    rsi
  40de9f:	pop    rbx
  40dea0:	ret
	...

000000000040deb0 <__swc_fn_4fa09e82_000097_4c97e0db>:
  40deb0:	push   rbx
  40deb1:	push   rsi
  40deb2:	sub    rsp,0x18
  40deb6:	mov    rbx,rcx
  40deb9:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40debe:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dec4:	mov    rsi,QWORD PTR [rbx+0x70]
  40dec8:	lea    rcx,[rcx+0x18]
  40decc:	call   411c60 <__swc_fn_4fa09e82_000158_232ffa22>
  40ded1:	lea    rcx,[rsp+0x8]
  40ded6:	mov    rdx,rbx
  40ded9:	mov    r8d,0x78
  40dedf:	call   408960 <__swc_fn_4fa09e82_000096_ad982b35>
  40dee4:	mov    rax,rsi
  40dee7:	add    rsp,0x18
  40deeb:	pop    rsi
  40deec:	pop    rbx
  40deed:	ret
	...

000000000040def0 <__swc_fn_4fa09e82_000100_3ed08774>:
  40def0:	push   rsi
  40def1:	push   rdi
  40def2:	sub    rsp,0x8
  40def6:	cmp    QWORD PTR [rcx],0x0
  40defa:	jne    40df03 <__swc_fn_4fa09e82_000100_3ed08774+0x13>
  40defc:	add    rsp,0x8
  40df00:	pop    rdi
  40df01:	pop    rsi
  40df02:	ret
  40df03:	mov    rsi,QWORD PTR [rcx]
  40df06:	mov    rax,QWORD PTR [rcx+0x8]
  40df0a:	test   rax,rax
  40df0d:	je     40df23 <__swc_fn_4fa09e82_000100_3ed08774+0x33>
  40df0f:	test   DWORD PTR [rax+0x28],0x400000
  40df16:	je     40df23 <__swc_fn_4fa09e82_000100_3ed08774+0x33>
  40df18:	mov    rcx,QWORD PTR [rax+0x30]
  40df1c:	test   rcx,rcx
  40df1f:	cmovne rax,rcx
  40df23:	lea    rdx,[rip+0x52a6]        # 4131d0 <__swc_rdata_base_4fa09e82+0xc0>
  40df2a:	lea    rcx,[rip+0x5387]        # 4132b8 <__swc_rdata_base_4fa09e82+0x1a8>
  40df31:	mov    r8,rax
  40df34:	xor    r9d,r9d
  40df37:	xor    al,al
  40df39:	mov    r10,rax
  40df3c:	xor    r11d,r11d
  40df3f:	call   40dcf0 <__swc_fn_4fa09e82_000088_fcb34f6a>
  40df44:	test   rax,rax
  40df47:	je     40df57 <__swc_fn_4fa09e82_000100_3ed08774+0x67>
  40df49:	mov    rdi,QWORD PTR [rax+0x48]
  40df4d:	test   rdi,rdi
  40df50:	je     40df57 <__swc_fn_4fa09e82_000100_3ed08774+0x67>
  40df52:	mov    rcx,rsi
  40df55:	call   rdi
  40df57:	add    rsp,0x8
  40df5b:	pop    rdi
  40df5c:	pop    rsi
  40df5d:	ret
	...

000000000040df60 <__swc_fn_4fa09e82_000103_67100064>:
  40df60:	push   rbx
  40df61:	push   rsi
  40df62:	push   rdi
  40df63:	sub    rsp,0x20
  40df67:	mov    rbx,rdx
  40df6a:	mov    rsi,rcx
  40df6d:	mov    rcx,QWORD PTR [rip+0x18dcc]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40df74:	test   rcx,rcx
  40df77:	jne    40df89 <__swc_fn_4fa09e82_000103_67100064+0x29>
  40df79:	call   40f0f0 <__swc_fn_4fa09e82_000166_cf398896>
  40df7e:	lea    rcx,[rax+0x1]
  40df82:	mov    QWORD PTR [rip+0x18db7],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40df89:	dec    rcx
  40df8c:	call   40b6c0 <__swc_fn_4fa09e82_000168_fce60b2b>
  40df91:	mov    rdi,rax
  40df94:	mov    rax,QWORD PTR [rdi+0xbd0]
  40df9b:	xor    ecx,ecx
  40df9d:	test   rax,rax
  40dfa0:	je     40dfa5 <__swc_fn_4fa09e82_000103_67100064+0x45>
  40dfa2:	mov    rcx,QWORD PTR [rax]
  40dfa5:	call   40f220 <__swc_fn_4fa09e82_000175_176517f9>
  40dfaa:	lea    rax,[rsp+0x8]
  40dfaf:	lea    rcx,[rdi+0x9c8]
  40dfb6:	mov    QWORD PTR [rsp+0x8],rcx
  40dfbb:	mov    QWORD PTR [rax+0x8],0x40
  40dfc3:	xor    ecx,ecx
  40dfc5:	mov    rdx,rax
  40dfc8:	call   4099e0 <__swc_fn_4fa09e82_000120_9175a56a>
  40dfcd:	mov    DWORD PTR [rdi+0xbc8],eax
  40dfd3:	mov    rdi,QWORD PTR [rdi+0x990]
  40dfda:	test   rdi,rdi
  40dfdd:	je     40dfe7 <__swc_fn_4fa09e82_000103_67100064+0x87>
  40dfdf:	mov    rcx,rsi
  40dfe2:	mov    rdx,rbx
  40dfe5:	call   rdi
  40dfe7:	call   40dd10 <__swc_fn_4fa09e82_000091_3d2f5a0d>
  40dfec:	test   al,al
  40dfee:	je     40dffe <__swc_fn_4fa09e82_000103_67100064+0x9e>
  40dff0:	mov    rcx,rsi
  40dff3:	mov    rdx,rbx
  40dff6:	xor    r8d,r8d
  40dff9:	call   40e320 <__swc_fn_4fa09e82_000121_ea68f292>
  40dffe:	mov    rcx,rsi
  40e001:	mov    rdx,rbx
  40e004:	call   408a80 <__swc_fn_4fa09e82_000102_e9fdc18e>
  40e009:	call   4114a0 <__swc_fn_4fa09e82_000119_7f430081>
  40e00e:	add    rsp,0x20
  40e012:	pop    rdi
  40e013:	pop    rsi
  40e014:	pop    rbx
  40e015:	ret
	...

000000000040e020 <__swc_fn_4fa09e82_000106_6fd80914>:
  40e020:	sub    rsp,0x8
  40e024:	test   r8,r8
  40e027:	je     40e02e <__swc_fn_4fa09e82_000106_6fd80914+0xe>
  40e029:	call   410e50 <__swc_fn_4fa09e82_000104_5589fdbd>
  40e02e:	add    rsp,0x8
  40e032:	ret
	...

000000000040e040 <__swc_fn_4fa09e82_000109_84af7666>:
  40e040:	push   rsi
  40e041:	push   rdi
  40e042:	push   r12
  40e044:	push   r13
  40e046:	sub    rsp,0xd8
  40e04d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40e053:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40e059:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40e05f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40e065:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40e06b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40e074:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40e07d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40e086:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40e08f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40e098:	xor    eax,eax
  40e09a:	call   407050 <getpid@plt>
  40e09f:	mov    rsi,rax
  40e0a2:	lea    rdi,[rip+0x18c9f]        # 426d48 <__swc_bss_base_4fa09e82+0x2d08>
  40e0a9:	mov    r12,QWORD PTR [rdi]
  40e0ac:	test   r12,r12
  40e0af:	je     40e0bd <__swc_fn_4fa09e82_000109_84af7666+0x7d>
  40e0b1:	cmp    DWORD PTR [r12+0x10],esi
  40e0b6:	jne    40e0bd <__swc_fn_4fa09e82_000109_84af7666+0x7d>
  40e0b8:	mov    rax,r12
  40e0bb:	jmp    40e120 <__swc_fn_4fa09e82_000109_84af7666+0xe0>
  40e0bd:	mov    ecx,0x4
  40e0c2:	mov    edx,0x18
  40e0c7:	call   4091c0 <__swc_fn_4fa09e82_000108_4796e893>
  40e0cc:	mov    rcx,rax
  40e0cf:	test   rax,rax
  40e0d2:	jne    40e0d8 <__swc_fn_4fa09e82_000109_84af7666+0x98>
  40e0d4:	xor    eax,eax
  40e0d6:	jmp    40e120 <__swc_fn_4fa09e82_000109_84af7666+0xe0>
  40e0d8:	mov    DWORD PTR [rcx+0x10],esi
  40e0db:	mov    rax,r12
  40e0de:	lock cmpxchg QWORD PTR [rdi],rcx
  40e0e3:	mov    r13,rax
  40e0e6:	cmp    rax,r12
  40e0e9:	je     40e0ff <__swc_fn_4fa09e82_000109_84af7666+0xbf>
  40e0eb:	mov    rdi,rcx
  40e0ee:	mov    esi,0x18
  40e0f3:	xor    eax,eax
  40e0f5:	call   407160 <munmap@plt>
  40e0fa:	mov    rax,r13
  40e0fd:	jmp    40e120 <__swc_fn_4fa09e82_000109_84af7666+0xe0>
  40e0ff:	test   r12,r12
  40e102:	je     40e11d <__swc_fn_4fa09e82_000109_84af7666+0xdd>
  40e104:	mov    rdi,r12
  40e107:	mov    esi,0x18
  40e10c:	xor    eax,eax
  40e10e:	mov    QWORD PTR [rsp+0x28],rcx
  40e113:	call   407160 <munmap@plt>
  40e118:	mov    rcx,QWORD PTR [rsp+0x28]
  40e11d:	mov    rax,rcx
  40e120:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40e126:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40e12c:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40e132:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40e138:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40e13e:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40e147:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40e150:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40e159:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40e162:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40e16b:	add    rsp,0xd8
  40e172:	pop    r13
  40e174:	pop    r12
  40e176:	pop    rdi
  40e177:	pop    rsi
  40e178:	ret
  40e179:	add    BYTE PTR [rax],al
  40e17b:	add    BYTE PTR [rax],al
  40e17d:	add    BYTE PTR [rax],al
	...

000000000040e180 <__swc_fn_4fa09e82_000112_b25e3a45>:
  40e180:	push   rbx
  40e181:	push   r12
  40e183:	push   rdi
  40e184:	push   rsi
  40e185:	sub    rsp,0xa8
  40e18c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e192:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e198:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e19e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e1a4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e1aa:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e1b0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e1b6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e1bc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e1c5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e1ce:	mov    rbx,rdx
  40e1d1:	mov    r12,rcx
  40e1d4:	mov    rdi,rcx
  40e1d7:	mov    rsi,rdx
  40e1da:	mov    edx,0x3
  40e1df:	xor    eax,eax
  40e1e1:	call   407170 <mprotect@plt>
  40e1e6:	test   eax,eax
  40e1e8:	je     40e1ee <__swc_fn_4fa09e82_000112_b25e3a45+0x6e>
  40e1ea:	xor    eax,eax
  40e1ec:	jmp    40e203 <__swc_fn_4fa09e82_000112_b25e3a45+0x83>
  40e1ee:	mov    rcx,r12
  40e1f1:	mov    rdx,rbx
  40e1f4:	mov    al,0x1
  40e1f6:	mov    r8,rax
  40e1f9:	call   409810 <__swc_fn_4fa09e82_000111_a808fe76>
  40e1fe:	mov    eax,0x1
  40e203:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e209:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e20f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e215:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e21b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e221:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e227:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e22d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e233:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e23c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e245:	add    rsp,0xa8
  40e24c:	pop    rsi
  40e24d:	pop    rdi
  40e24e:	pop    r12
  40e250:	pop    rbx
  40e251:	ret
	...

000000000040e260 <__swc_fn_4fa09e82_000115_27d95464>:
  40e260:	sub    rsp,0x8
  40e264:	test   rcx,rcx
  40e267:	jne    40e26e <__swc_fn_4fa09e82_000115_27d95464+0xe>
  40e269:	add    rsp,0x8
  40e26d:	ret
  40e26e:	call   411350 <__swc_fn_4fa09e82_000116_1ba33335>
  40e273:	add    rsp,0x8
  40e277:	ret
	...

000000000040e280 <__swc_fn_4fa09e82_000118_86a7fb9e>:
  40e280:	push   rdi
  40e281:	push   rsi
  40e282:	sub    rsp,0xa8
  40e289:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e28f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e295:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e29b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e2a1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e2a7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e2ad:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e2b3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e2b9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e2c2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e2cb:	xor    edi,edi
  40e2cd:	xor    eax,eax
  40e2cf:	call   407180 <exit@plt>
  40e2d4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e2da:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e2e0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e2e6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e2ec:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e2f2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e2f8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e2fe:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e304:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e30d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e316:	add    rsp,0xa8
  40e31d:	pop    rsi
  40e31e:	pop    rdi
  40e31f:	ret

000000000040e320 <__swc_fn_4fa09e82_000121_ea68f292>:
  40e320:	push   rbx
  40e321:	push   rsi
  40e322:	push   rdi
  40e323:	push   r12
  40e325:	sub    rsp,0x18
  40e329:	mov    rbx,r8
  40e32c:	mov    rsi,rcx
  40e32f:	mov    rdi,rdx
  40e332:	mov    rcx,QWORD PTR [rip+0x18a07]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40e339:	test   rcx,rcx
  40e33c:	jne    40e34e <__swc_fn_4fa09e82_000121_ea68f292+0x2e>
  40e33e:	call   40f0f0 <__swc_fn_4fa09e82_000166_cf398896>
  40e343:	lea    rcx,[rax+0x1]
  40e347:	mov    QWORD PTR [rip+0x189f2],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  40e34e:	dec    rcx
  40e351:	call   40b6c0 <__swc_fn_4fa09e82_000168_fce60b2b>
  40e356:	mov    r12,rax
  40e359:	cmp    ebx,0x3
  40e35c:	jne    40e36f <__swc_fn_4fa09e82_000121_ea68f292+0x4f>
  40e35e:	mov    rax,QWORD PTR [r12+0xbd0]
  40e366:	test   rax,rax
  40e369:	jne    40e4af <__swc_fn_4fa09e82_000121_ea68f292+0x18f>
  40e36f:	cmp    ebx,0x5
  40e372:	jne    40e396 <__swc_fn_4fa09e82_000121_ea68f292+0x76>
  40e374:	call   40dd10 <__swc_fn_4fa09e82_000091_3d2f5a0d>
  40e379:	test   al,al
  40e37b:	jne    40e396 <__swc_fn_4fa09e82_000121_ea68f292+0x76>
  40e37d:	mov    rcx,rsi
  40e380:	mov    rdx,rdi
  40e383:	call   40b670 <__swc_fn_4fa09e82_000165_1962e12a>
  40e388:	test   al,al
  40e38a:	je     40e396 <__swc_fn_4fa09e82_000121_ea68f292+0x76>
  40e38c:	add    rsp,0x18
  40e390:	pop    r12
  40e392:	pop    rdi
  40e393:	pop    rsi
  40e394:	pop    rbx
  40e395:	ret
  40e396:	call   40dd10 <__swc_fn_4fa09e82_000091_3d2f5a0d>
  40e39b:	test   al,al
  40e39d:	jne    40e412 <__swc_fn_4fa09e82_000121_ea68f292+0xf2>
  40e39f:	lea    rax,[rsp+0x8]
  40e3a4:	vmovups xmm0,XMMWORD PTR [rsi]
  40e3a8:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e3ae:	mov    rcx,QWORD PTR [rsp+0x8]
  40e3b3:	test   rcx,rcx
  40e3b6:	jne    40e407 <__swc_fn_4fa09e82_000121_ea68f292+0xe7>
  40e3b8:	cmp    ebx,0x3
  40e3bb:	je     40e3c9 <__swc_fn_4fa09e82_000121_ea68f292+0xa9>
  40e3bd:	cmp    ebx,0x4
  40e3c0:	je     40e3d9 <__swc_fn_4fa09e82_000121_ea68f292+0xb9>
  40e3c2:	cmp    ebx,0x5
  40e3c5:	je     40e3e9 <__swc_fn_4fa09e82_000121_ea68f292+0xc9>
  40e3c7:	jmp    40e3f9 <__swc_fn_4fa09e82_000121_ea68f292+0xd9>
  40e3c9:	vmovups xmm0,XMMWORD PTR [rip+0x510f]        # 4134e0 <__swc_rdata_base_4fa09e82+0x3d0>
  40e3d1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e3d7:	jmp    40e407 <__swc_fn_4fa09e82_000121_ea68f292+0xe7>
  40e3d9:	vmovups xmm0,XMMWORD PTR [rip+0x510f]        # 4134f0 <__swc_rdata_base_4fa09e82+0x3e0>
  40e3e1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e3e7:	jmp    40e407 <__swc_fn_4fa09e82_000121_ea68f292+0xe7>
  40e3e9:	vmovups xmm0,XMMWORD PTR [rip+0x510f]        # 413500 <__swc_rdata_base_4fa09e82+0x3f0>
  40e3f1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e3f7:	jmp    40e407 <__swc_fn_4fa09e82_000121_ea68f292+0xe7>
  40e3f9:	vmovups xmm0,XMMWORD PTR [rip+0x510f]        # 413510 <__swc_rdata_base_4fa09e82+0x400>
  40e401:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e407:	mov    rcx,rax
  40e40a:	mov    rdx,rdi
  40e40d:	call   40df60 <__swc_fn_4fa09e82_000103_67100064>
  40e412:	vmovups xmm0,XMMWORD PTR [rdi]
  40e416:	vmovups XMMWORD PTR [r12+0x940],xmm0
  40e420:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  40e425:	vmovups XMMWORD PTR [r12+0x950],xmm0
  40e42f:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  40e434:	vmovups XMMWORD PTR [r12+0x960],xmm0
  40e43e:	lea    rax,[r12+0x940]
  40e446:	mov    QWORD PTR [r12+0x970],rax
  40e44e:	mov    rax,QWORD PTR [rsi]
  40e451:	mov    QWORD PTR [r12+0x978],rax
  40e459:	mov    rax,QWORD PTR [rsi+0x8]
  40e45d:	mov    QWORD PTR [r12+0x980],rax
  40e465:	movsxd rax,ebx
  40e468:	mov    QWORD PTR [r12+0x988],rax
  40e470:	cmp    ebx,0x5
  40e473:	je     40e47c <__swc_fn_4fa09e82_000121_ea68f292+0x15c>
  40e475:	xor    ecx,ecx
  40e477:	call   40f220 <__swc_fn_4fa09e82_000175_176517f9>
  40e47c:	mov    rbx,QWORD PTR [r12+0xbe8]
  40e484:	test   rbx,rbx
  40e487:	je     40e498 <__swc_fn_4fa09e82_000121_ea68f292+0x178>
  40e489:	mov    rcx,r12
  40e48c:	call   rbx
  40e48e:	add    rsp,0x18
  40e492:	pop    r12
  40e494:	pop    rdi
  40e495:	pop    rsi
  40e496:	pop    rbx
  40e497:	ret
  40e498:	mov    rcx,rsi
  40e49b:	call   4098c0 <__swc_fn_4fa09e82_000117_035d76a1>
  40e4a0:	call   4114a0 <__swc_fn_4fa09e82_000119_7f430081>
  40e4a5:	add    rsp,0x18
  40e4a9:	pop    r12
  40e4ab:	pop    rdi
  40e4ac:	pop    rsi
  40e4ad:	pop    rbx
  40e4ae:	ret
  40e4af:	mov    rcx,rsi
  40e4b2:	mov    rdx,rdi
  40e4b5:	call   40df60 <__swc_fn_4fa09e82_000103_67100064>
  40e4ba:	jmp    40e36f <__swc_fn_4fa09e82_000121_ea68f292+0x4f>
	...

000000000040e4c0 <__swc_fn_4fa09e82_000124_9d2cbd72>:
  40e4c0:	push   rdi
  40e4c1:	push   rsi
  40e4c2:	sub    rsp,0xb8
  40e4c9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40e4cf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40e4d5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40e4db:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40e4e1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40e4e7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40e4ed:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40e4f3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40e4fc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40e505:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40e50e:	mov    DWORD PTR [rsp+0x8],0x0
  40e516:	lea    rdi,[rsp+0x8]
  40e51b:	xor    esi,esi
  40e51d:	xor    eax,eax
  40e51f:	call   407190 <pthread_key_create@plt>
  40e524:	test   eax,eax
  40e526:	jne    40e52e <__swc_fn_4fa09e82_000124_9d2cbd72+0x6e>
  40e528:	mov    eax,DWORD PTR [rsp+0x8]
  40e52c:	jmp    40e535 <__swc_fn_4fa09e82_000124_9d2cbd72+0x75>
  40e52e:	mov    rax,0xffffffffffffffff
  40e535:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40e53b:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40e541:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40e547:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40e54d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40e553:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40e559:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40e55f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40e568:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40e571:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40e57a:	add    rsp,0xb8
  40e581:	pop    rsi
  40e582:	pop    rdi
  40e583:	ret
	...

000000000040e590 <__swc_fn_4fa09e82_000127_102fe7b9>:
  40e590:	push   rdi
  40e591:	push   rsi
  40e592:	sub    rsp,0xb8
  40e599:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40e59f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40e5a5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40e5ab:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40e5b1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40e5b7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40e5bd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40e5c3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40e5cc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40e5d5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40e5de:	mov    DWORD PTR [rsp+0x8],0x0
  40e5e6:	lea    rdi,[rsp+0x8]
  40e5eb:	mov    rsi,rcx
  40e5ee:	xor    eax,eax
  40e5f0:	call   407190 <pthread_key_create@plt>
  40e5f5:	test   eax,eax
  40e5f7:	jne    40e602 <__swc_fn_4fa09e82_000127_102fe7b9+0x72>
  40e5f9:	mov    eax,DWORD PTR [rsp+0x8]
  40e5fd:	inc    rax
  40e600:	jmp    40e604 <__swc_fn_4fa09e82_000127_102fe7b9+0x74>
  40e602:	xor    eax,eax
  40e604:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40e60a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40e610:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40e616:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40e61c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40e622:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40e628:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40e62e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40e637:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40e640:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40e649:	add    rsp,0xb8
  40e650:	pop    rsi
  40e651:	pop    rdi
  40e652:	ret
	...

000000000040e660 <__swc_fn_4fa09e82_000130_74b163fe>:
  40e660:	push   rdi
  40e661:	push   rsi
  40e662:	sub    rsp,0xa8
  40e669:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e66f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e675:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e67b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e681:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e687:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e68d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e693:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e699:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e6a2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e6ab:	test   rcx,rcx
  40e6ae:	setne  al
  40e6b1:	je     40e6ca <__swc_fn_4fa09e82_000130_74b163fe+0x6a>
  40e6b3:	lea    rax,[rcx-0x1]
  40e6b7:	mov    eax,eax
  40e6b9:	mov    edi,eax
  40e6bb:	mov    rsi,rdx
  40e6be:	xor    eax,eax
  40e6c0:	call   407120 <pthread_setspecific@plt>
  40e6c5:	test   eax,eax
  40e6c7:	sete   al
  40e6ca:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e6d0:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e6d6:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e6dc:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e6e2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e6e8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e6ee:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e6f4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e6fa:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e703:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e70c:	add    rsp,0xa8
  40e713:	pop    rsi
  40e714:	pop    rdi
  40e715:	ret
	...

000000000040e720 <__swc_fn_4fa09e82_000133_f908e7f9>:
  40e720:	push   rdi
  40e721:	push   rsi
  40e722:	sub    rsp,0xa8
  40e729:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e72f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e735:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e73b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e741:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e747:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e74d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e753:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e759:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e762:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e76b:	mov    rax,rdx
  40e76e:	mov    QWORD PTR [rsp],0x0
  40e776:	mov    edi,0xca
  40e77b:	mov    rsi,rcx
  40e77e:	mov    edx,0x81
  40e783:	mov    eax,eax
  40e785:	mov    ecx,eax
  40e787:	xor    r8d,r8d
  40e78a:	xor    r9d,r9d
  40e78d:	xor    eax,eax
  40e78f:	call   4071a0 <syscall@plt>
  40e794:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e79a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e7a0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e7a6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e7ac:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e7b2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e7b8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e7be:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e7c4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e7cd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e7d6:	add    rsp,0xa8
  40e7dd:	pop    rsi
  40e7de:	pop    rdi
  40e7df:	ret

000000000040e7e0 <__swc_fn_4fa09e82_000136_e3032dc2>:
  40e7e0:	sub    rsp,0x8
  40e7e4:	call   411850 <__swc_fn_4fa09e82_000134_4b2af8da>
  40e7e9:	add    rsp,0x8
  40e7ed:	ret
	...

000000000040e7f0 <__swc_fn_4fa09e82_000139_0c00232f>:
  40e7f0:	push   rdi
  40e7f1:	push   rsi
  40e7f2:	sub    rsp,0xc8
  40e7f9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40e7ff:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40e805:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40e80b:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40e811:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40e817:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40e81d:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40e826:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40e82f:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40e838:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40e841:	vxorps xmm0,xmm0,xmm0
  40e845:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e84b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e851:	mov    rdi,rcx
  40e854:	lea    rsi,[rsp+0x8]
  40e859:	xor    eax,eax
  40e85b:	call   4071b0 <dladdr@plt>
  40e860:	xor    ecx,ecx
  40e862:	test   eax,eax
  40e864:	je     40e86b <__swc_fn_4fa09e82_000139_0c00232f+0x7b>
  40e866:	mov    rcx,QWORD PTR [rsp+0x10]
  40e86b:	mov    rax,rcx
  40e86e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40e874:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40e87a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40e880:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40e886:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40e88c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40e892:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40e89b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40e8a4:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40e8ad:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40e8b6:	add    rsp,0xc8
  40e8bd:	pop    rsi
  40e8be:	pop    rdi
  40e8bf:	ret

000000000040e8c0 <__swc_fn_4fa09e82_000142_2ce79e3b>:
  40e8c0:	push   rbx
  40e8c1:	push   r12
  40e8c3:	push   r13
  40e8c5:	push   rdi
  40e8c6:	push   rsi
  40e8c7:	push   r14
  40e8c9:	push   r15
  40e8cb:	sub    rsp,0x150
  40e8d2:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40e8db:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40e8e4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40e8ed:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40e8f6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40e8ff:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40e908:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40e911:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40e91a:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40e923:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40e92c:	mov    rbx,rdx
  40e92f:	mov    QWORD PTR [rsp+0x98],rdx
  40e937:	mov    r12,rcx
  40e93a:	mov    QWORD PTR [rsp+0xa0],rcx
  40e942:	mov    QWORD PTR [rbx],0x0
  40e949:	lea    r13,[rip+0x18430]        # 426d80 <__swc_bss_base_4fa09e82+0x2d40>
  40e950:	mov    rcx,r13
  40e953:	call   40e7e0 <__swc_fn_4fa09e82_000136_e3032dc2>
  40e958:	mov    rax,QWORD PTR [rip+0x18429]        # 426d88 <__swc_bss_base_4fa09e82+0x2d48>
  40e95f:	test   rax,rax
  40e962:	je     40e999 <__swc_fn_4fa09e82_000142_2ce79e3b+0xd9>
  40e964:	cs nop WORD PTR [rax+rax*1+0x0]
  40e96e:	xchg   ax,ax
  40e970:	cmp    QWORD PTR [rax+0x8],r12
  40e974:	jne    40e991 <__swc_fn_4fa09e82_000142_2ce79e3b+0xd1>
  40e976:	mov    rcx,QWORD PTR [rax+0x18]
  40e97a:	mov    QWORD PTR [rbx],rcx
  40e97d:	mov    rbx,QWORD PTR [rax+0x10]
  40e981:	mov    rcx,r13
  40e984:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40e989:	mov    rax,rbx
  40e98c:	jmp    40eb7b <__swc_fn_4fa09e82_000142_2ce79e3b+0x2bb>
  40e991:	mov    rax,QWORD PTR [rax]
  40e994:	test   rax,rax
  40e997:	jne    40e970 <__swc_fn_4fa09e82_000142_2ce79e3b+0xb0>
  40e999:	vxorps xmm0,xmm0,xmm0
  40e99d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  40e9a3:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  40e9a9:	mov    rdi,r12
  40e9ac:	lea    rsi,[rsp+0x10]
  40e9b1:	xor    eax,eax
  40e9b3:	call   4071b0 <dladdr@plt>
  40e9b8:	test   eax,eax
  40e9ba:	sete   al
  40e9bd:	je     40e9ca <__swc_fn_4fa09e82_000142_2ce79e3b+0x10a>
  40e9bf:	mov    rax,QWORD PTR [rsp+0x10]
  40e9c4:	test   rax,rax
  40e9c7:	sete   al
  40e9ca:	test   al,al
  40e9cc:	je     40e9dd <__swc_fn_4fa09e82_000142_2ce79e3b+0x11d>
  40e9ce:	mov    rcx,r13
  40e9d1:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40e9d6:	xor    eax,eax
  40e9d8:	jmp    40eb7b <__swc_fn_4fa09e82_000142_2ce79e3b+0x2bb>
  40e9dd:	mov    rdi,QWORD PTR [rsp+0x10]
  40e9e2:	mov    esi,0x80000
  40e9e7:	xor    eax,eax
  40e9e9:	call   407010 <open@plt>
  40e9ee:	lea    r14,[rsp+0x30]
  40e9f3:	mov    DWORD PTR [rsp+0x30],eax
  40e9f7:	cmp    DWORD PTR [r14],0x0
  40e9fb:	jge    40ea0c <__swc_fn_4fa09e82_000142_2ce79e3b+0x14c>
  40e9fd:	mov    rcx,r13
  40ea00:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40ea05:	xor    eax,eax
  40ea07:	jmp    40eb7b <__swc_fn_4fa09e82_000142_2ce79e3b+0x2bb>
  40ea0c:	mov    rax,r14
  40ea0f:	movsxd rdi,DWORD PTR [rax]
  40ea12:	xor    esi,esi
  40ea14:	mov    edx,0x2
  40ea19:	xor    eax,eax
  40ea1b:	call   4070c0 <lseek@plt>
  40ea20:	mov    r15,rax
  40ea23:	test   rax,rax
  40ea26:	jg     40ea41 <__swc_fn_4fa09e82_000142_2ce79e3b+0x181>
  40ea28:	movsxd rdi,DWORD PTR [r14]
  40ea2b:	xor    eax,eax
  40ea2d:	call   407040 <close@plt>
  40ea32:	mov    rcx,r13
  40ea35:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40ea3a:	xor    eax,eax
  40ea3c:	jmp    40eb7b <__swc_fn_4fa09e82_000142_2ce79e3b+0x2bb>
  40ea41:	xor    edi,edi
  40ea43:	mov    rsi,r15
  40ea46:	mov    edx,0x1
  40ea4b:	mov    ecx,0x2
  40ea50:	mov    rax,r14
  40ea53:	movsxd r8,DWORD PTR [rax]
  40ea56:	xor    r9d,r9d
  40ea59:	xor    eax,eax
  40ea5b:	call   4070d0 <mmap@plt>
  40ea60:	mov    rbx,rax
  40ea63:	test   rax,rax
  40ea66:	sete   al
  40ea69:	cmp    rbx,0xffffffffffffffff
  40ea6d:	sete   cl
  40ea70:	or     al,cl
  40ea72:	je     40ea8d <__swc_fn_4fa09e82_000142_2ce79e3b+0x1cd>
  40ea74:	movsxd rdi,DWORD PTR [r14]
  40ea77:	xor    eax,eax
  40ea79:	call   407040 <close@plt>
  40ea7e:	mov    rcx,r13
  40ea81:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40ea86:	xor    eax,eax
  40ea88:	jmp    40eb7b <__swc_fn_4fa09e82_000142_2ce79e3b+0x2bb>
  40ea8d:	lea    rax,[rsp+0x50]
  40ea92:	mov    QWORD PTR [rax],0x0
  40ea99:	mov    rcx,rbx
  40ea9c:	mov    rdx,r15
  40ea9f:	mov    r8,rax
  40eaa2:	call   409e60 <__swc_fn_4fa09e82_000141_c6b99a56>
  40eaa7:	mov    r12,rax
  40eaaa:	test   rax,rax
  40eaad:	jne    40ead5 <__swc_fn_4fa09e82_000142_2ce79e3b+0x215>
  40eaaf:	mov    rdi,rbx
  40eab2:	mov    rsi,r15
  40eab5:	xor    eax,eax
  40eab7:	call   407160 <munmap@plt>
  40eabc:	movsxd rdi,DWORD PTR [r14]
  40eabf:	xor    eax,eax
  40eac1:	call   407040 <close@plt>
  40eac6:	mov    rcx,r13
  40eac9:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40eace:	xor    eax,eax
  40ead0:	jmp    40eb7b <__swc_fn_4fa09e82_000142_2ce79e3b+0x2bb>
  40ead5:	mov    edi,0x20
  40eada:	xor    eax,eax
  40eadc:	call   4071c0 <malloc@plt>
  40eae1:	test   rax,rax
  40eae4:	jne    40eb09 <__swc_fn_4fa09e82_000142_2ce79e3b+0x249>
  40eae6:	mov    rdi,rbx
  40eae9:	mov    rsi,r15
  40eaec:	xor    eax,eax
  40eaee:	call   407160 <munmap@plt>
  40eaf3:	movsxd rdi,DWORD PTR [r14]
  40eaf6:	xor    eax,eax
  40eaf8:	call   407040 <close@plt>
  40eafd:	mov    rcx,r13
  40eb00:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40eb05:	xor    eax,eax
  40eb07:	jmp    40eb7b <__swc_fn_4fa09e82_000142_2ce79e3b+0x2bb>
  40eb09:	mov    rcx,QWORD PTR [rip+0x18278]        # 426d88 <__swc_bss_base_4fa09e82+0x2d48>
  40eb10:	mov    QWORD PTR [rsp+0x70],rcx
  40eb15:	mov    rcx,QWORD PTR [rsp+0xa0]
  40eb1d:	mov    QWORD PTR [rsp+0x78],rcx
  40eb22:	mov    QWORD PTR [rsp+0x80],r12
  40eb2a:	mov    rcx,QWORD PTR [rsp+0x50]
  40eb2f:	mov    QWORD PTR [rsp+0x88],rcx
  40eb37:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  40eb3d:	vmovups XMMWORD PTR [rax],xmm0
  40eb41:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  40eb4a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40eb4f:	mov    QWORD PTR [rip+0x18232],rax        # 426d88 <__swc_bss_base_4fa09e82+0x2d48>
  40eb56:	mov    rax,QWORD PTR [rsp+0x50]
  40eb5b:	mov    rbx,QWORD PTR [rsp+0x98]
  40eb63:	mov    QWORD PTR [rbx],rax
  40eb66:	movsxd rdi,DWORD PTR [r14]
  40eb69:	xor    eax,eax
  40eb6b:	call   407040 <close@plt>
  40eb70:	mov    rcx,r13
  40eb73:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40eb78:	mov    rax,r12
  40eb7b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40eb84:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40eb8d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40eb96:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40eb9f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40eba8:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40ebb1:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40ebba:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40ebc3:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40ebcc:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40ebd5:	add    rsp,0x150
  40ebdc:	pop    r15
  40ebde:	pop    r14
  40ebe0:	pop    rsi
  40ebe1:	pop    rdi
  40ebe2:	pop    r13
  40ebe4:	pop    r12
  40ebe6:	pop    rbx
  40ebe7:	ret
	...

000000000040ebf0 <__swc_fn_4fa09e82_000145_72996a5b>:
  40ebf0:	push   rbx
  40ebf1:	sub    rsp,0xe0
  40ebf8:	lea    rbx,[rsp+0x8]
  40ebfd:	vxorps xmm0,xmm0,xmm0
  40ec01:	vmovups XMMWORD PTR [rbx],xmm0
  40ec05:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ec0a:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ec0f:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40ec14:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40ec19:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  40ec1e:	mov    DWORD PTR [rbx+0x60],0x0
  40ec25:	mov    r8,rbx
  40ec28:	nop    DWORD PTR [rax+rax*1+0x0]
  40ec30:	mov    r9,rcx
  40ec33:	movabs rcx,0xcccccccccccccccd
  40ec3d:	mov    rax,r9
  40ec40:	mul    rcx
  40ec43:	mov    r10,rdx
  40ec46:	shr    r10,0x3
  40ec4a:	mov    rcx,r10
  40ec4d:	imul   rdx,r10,0xa
  40ec51:	sub    r9,rdx
  40ec54:	mov    rdx,QWORD PTR [rip+0x48e5]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  40ec5b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  40ec60:	mov    BYTE PTR [r8],dl
  40ec63:	lea    rdx,[r8+0x1]
  40ec67:	mov    r8,rdx
  40ec6a:	test   r10,r10
  40ec6d:	jne    40ec30 <__swc_fn_4fa09e82_000145_72996a5b+0x40>
  40ec6f:	mov    BYTE PTR [rdx],0x0
  40ec72:	sub    r8,0x1
  40ec76:	mov    rax,rbx
  40ec79:	cmp    rax,r8
  40ec7c:	jae    40ec96 <__swc_fn_4fa09e82_000145_72996a5b+0xa6>
  40ec7e:	xchg   ax,ax
  40ec80:	mov    cl,BYTE PTR [r8]
  40ec83:	mov    dl,BYTE PTR [rax]
  40ec85:	mov    BYTE PTR [r8],dl
  40ec88:	sub    r8,0x1
  40ec8c:	mov    BYTE PTR [rax],cl
  40ec8e:	inc    rax
  40ec91:	cmp    rax,r8
  40ec94:	jb     40ec80 <__swc_fn_4fa09e82_000145_72996a5b+0x90>
  40ec96:	xor    eax,eax
  40ec98:	test   rbx,rbx
  40ec9b:	je     40ecbe <__swc_fn_4fa09e82_000145_72996a5b+0xce>
  40ec9d:	mov    rcx,rbx
  40eca0:	mov    dl,BYTE PTR [rcx]
  40eca2:	test   dl,dl
  40eca4:	je     40ecbe <__swc_fn_4fa09e82_000145_72996a5b+0xce>
  40eca6:	cs nop WORD PTR [rax+rax*1+0x0]
  40ecb0:	add    rcx,0x1
  40ecb4:	add    rax,0x1
  40ecb8:	mov    dl,BYTE PTR [rcx]
  40ecba:	test   dl,dl
  40ecbc:	jne    40ecb0 <__swc_fn_4fa09e82_000145_72996a5b+0xc0>
  40ecbe:	mov    QWORD PTR [rbx+0xa8],rbx
  40ecc5:	mov    QWORD PTR [rbx+0xb0],rax
  40eccc:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40ecd4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40ecdc:	lea    rcx,[rbx+0xb8]
  40ece3:	call   4098c0 <__swc_fn_4fa09e82_000117_035d76a1>
  40ece8:	add    rsp,0xe0
  40ecef:	pop    rbx
  40ecf0:	ret
	...

000000000040ed00 <__swc_fn_4fa09e82_000148_32a497f3>:
  40ed00:	sub    rsp,0x8
  40ed04:	mov    rax,QWORD PTR [rcx+0x8]
  40ed08:	mov    r8,QWORD PTR [rdx+0x8]
  40ed0c:	cmp    rax,r8
  40ed0f:	je     40ed18 <__swc_fn_4fa09e82_000148_32a497f3+0x18>
  40ed11:	xor    eax,eax
  40ed13:	add    rsp,0x8
  40ed17:	ret
  40ed18:	test   rax,rax
  40ed1b:	jne    40ed2c <__swc_fn_4fa09e82_000148_32a497f3+0x2c>
  40ed1d:	test   r8,r8
  40ed20:	jne    40ed2c <__swc_fn_4fa09e82_000148_32a497f3+0x2c>
  40ed22:	mov    eax,0x1
  40ed27:	add    rsp,0x8
  40ed2b:	ret
  40ed2c:	mov    rcx,QWORD PTR [rcx]
  40ed2f:	mov    rdx,QWORD PTR [rdx]
  40ed32:	test   rcx,rcx
  40ed35:	sete   r8b
  40ed39:	test   rdx,rdx
  40ed3c:	sete   r9b
  40ed40:	or     r8b,r9b
  40ed43:	je     40ed50 <__swc_fn_4fa09e82_000148_32a497f3+0x50>
  40ed45:	cmp    rcx,rdx
  40ed48:	sete   al
  40ed4b:	add    rsp,0x8
  40ed4f:	ret
  40ed50:	cmp    rcx,rdx
  40ed53:	jne    40ed5f <__swc_fn_4fa09e82_000148_32a497f3+0x5f>
  40ed55:	mov    eax,0x1
  40ed5a:	add    rsp,0x8
  40ed5e:	ret
  40ed5f:	mov    r8,rax
  40ed62:	call   410f30 <__swc_fn_4fa09e82_000107_ed4b1681>
  40ed67:	test   eax,eax
  40ed69:	sete   al
  40ed6c:	add    rsp,0x8
  40ed70:	ret
	...

000000000040ed80 <__swc_fn_4fa09e82_000151_9e4bc402>:
  40ed80:	vxorps xmm0,xmm0,xmm0
  40ed84:	vmovups XMMWORD PTR [rcx],xmm0
  40ed88:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40ed8d:	vxorps xmm0,xmm0,xmm0
  40ed91:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40ed96:	vmovups xmm0,XMMWORD PTR [rip+0x485a]        # 4135f8 <__swc_rdata_base_4fa09e82+0x4e8>
  40ed9e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40eda3:	ret
	...

000000000040edb0 <__swc_fn_4fa09e82_000154_9e4bc402>:
  40edb0:	vxorps xmm0,xmm0,xmm0
  40edb4:	vmovups XMMWORD PTR [rcx],xmm0
  40edb8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40edbd:	vxorps xmm0,xmm0,xmm0
  40edc1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40edc6:	vmovups xmm0,XMMWORD PTR [rip+0x494a]        # 413718 <__swc_rdata_base_4fa09e82+0x608>
  40edce:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40edd3:	mov    QWORD PTR [rcx+0x40],0x0
  40eddb:	ret
  40eddc:	add    BYTE PTR [rax],al
	...

000000000040ede0 <__swc_fn_4fa09e82_000157_2745c4a5>:
  40ede0:	push   rbx
  40ede1:	sub    rsp,0x70
  40ede5:	mov    rax,QWORD PTR [rcx]
  40ede8:	mov    rbx,QWORD PTR [rcx+0x8]
  40edec:	vxorps xmm0,xmm0,xmm0
  40edf0:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40edf6:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40edfc:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40ee02:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40ee08:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40ee0e:	mov    QWORD PTR [rsp+0x48],rdx
  40ee13:	mov    QWORD PTR [rsp+0x50],r8
  40ee18:	mov    rcx,rax
  40ee1b:	lea    rdx,[rsp+0x8]
  40ee20:	mov    rbx,QWORD PTR [rbx+0x18]
  40ee24:	call   rbx
  40ee26:	add    rsp,0x70
  40ee2a:	pop    rbx
  40ee2b:	ret
  40ee2c:	add    BYTE PTR [rax],al
	...

000000000040ee30 <__swc_fn_4fa09e82_000160_d8afac28>:
  40ee30:	push   rbx
  40ee31:	push   rsi
  40ee32:	push   rdi
  40ee33:	mov    rbx,r8
  40ee36:	mov    rsi,rcx
  40ee39:	mov    rdi,rdx
  40ee3c:	call   411c60 <__swc_fn_4fa09e82_000158_232ffa22>
  40ee41:	vmovups xmm0,XMMWORD PTR [rbx]
  40ee45:	vmovups XMMWORD PTR [rsi],xmm0
  40ee49:	mov    QWORD PTR [rsi+0x18],rdi
  40ee4d:	pop    rdi
  40ee4e:	pop    rsi
  40ee4f:	pop    rbx
  40ee50:	ret
	...

000000000040ee60 <__swc_fn_4fa09e82_000163_60216e69>:
  40ee60:	push   rbx
  40ee61:	push   rsi
  40ee62:	push   rdi
  40ee63:	push   r12
  40ee65:	push   r13
  40ee67:	sub    rsp,0x50
  40ee6b:	mov    rbx,rcx
  40ee6e:	mov    rsi,rdx
  40ee71:	vmovups xmm0,XMMWORD PTR [rip+0x49af]        # 413828 <__swc_rdata_base_4fa09e82+0x718>
  40ee79:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ee7f:	vmovups xmm0,XMMWORD PTR [rip+0x49b1]        # 413838 <__swc_rdata_base_4fa09e82+0x728>
  40ee87:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40ee8d:	vxorps xmm0,xmm0,xmm0
  40ee91:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40ee97:	mov    rcx,rdx
  40ee9a:	call   40e7f0 <__swc_fn_4fa09e82_000139_0c00232f>
  40ee9f:	mov    rdi,rax
  40eea2:	test   rax,rax
  40eea5:	jne    40eed6 <__swc_fn_4fa09e82_000163_60216e69+0x76>
  40eea7:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40eead:	vmovups XMMWORD PTR [rbx],xmm0
  40eeb1:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40eeb7:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40eebc:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40eec2:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40eec7:	mov    rax,rbx
  40eeca:	add    rsp,0x50
  40eece:	pop    r13
  40eed0:	pop    r12
  40eed2:	pop    rdi
  40eed3:	pop    rsi
  40eed4:	pop    rbx
  40eed5:	ret
  40eed6:	mov    rcx,rdi
  40eed9:	call   40b3c0 <__swc_fn_4fa09e82_000162_b5a9d657>
  40eede:	mov    r11,rax
  40eee1:	test   rax,rax
  40eee4:	je     40eeee <__swc_fn_4fa09e82_000163_60216e69+0x8e>
  40eee6:	mov    al,BYTE PTR [r11+0x24]
  40eeea:	test   al,al
  40eeec:	jne    40ef1d <__swc_fn_4fa09e82_000163_60216e69+0xbd>
  40eeee:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40eef4:	vmovups XMMWORD PTR [rbx],xmm0
  40eef8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40eefe:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ef03:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40ef09:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ef0e:	mov    rax,rbx
  40ef11:	add    rsp,0x50
  40ef15:	pop    r13
  40ef17:	pop    r12
  40ef19:	pop    rdi
  40ef1a:	pop    rsi
  40ef1b:	pop    rbx
  40ef1c:	ret
  40ef1d:	sub    rsi,rdi
  40ef20:	mov    eax,0xffffffff
  40ef25:	cmp    rsi,rax
  40ef28:	jbe    40ef59 <__swc_fn_4fa09e82_000163_60216e69+0xf9>
  40ef2a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ef30:	vmovups XMMWORD PTR [rbx],xmm0
  40ef34:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40ef3a:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ef3f:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40ef45:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ef4a:	mov    rax,rbx
  40ef4d:	add    rsp,0x50
  40ef51:	pop    r13
  40ef53:	pop    r12
  40ef55:	pop    rdi
  40ef56:	pop    rsi
  40ef57:	pop    rbx
  40ef58:	ret
  40ef59:	mov    rdi,QWORD PTR [r11+0x10]
  40ef5d:	mov    eax,DWORD PTR [r11+0x20]
  40ef61:	xor    ecx,ecx
  40ef63:	test   rax,rax
  40ef66:	jbe    40f0b8 <__swc_fn_4fa09e82_000163_60216e69+0x258>
  40ef6c:	nop    DWORD PTR [rax+0x0]
  40ef70:	mov    edx,ecx
  40ef72:	imul   r12,rdx,0x14
  40ef76:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40ef7b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40ef80:	mov    r9d,esi
  40ef83:	cmp    r9,rdx
  40ef86:	jb     40f0ab <__swc_fn_4fa09e82_000163_60216e69+0x24b>
  40ef8c:	add    rdx,r8
  40ef8f:	mov    r8d,esi
  40ef92:	cmp    r8,rdx
  40ef95:	jae    40f0ab <__swc_fn_4fa09e82_000163_60216e69+0x24b>
  40ef9b:	lea    rsi,[rsp+0x38]
  40efa0:	mov    eax,DWORD PTR [rdi+0xc]
  40efa3:	mov    DWORD PTR [rsp+0x38],eax
  40efa7:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40efac:	mov    rcx,rdi
  40efaf:	mov    rdx,QWORD PTR [r11+0x18]
  40efb3:	mov    r8,rsi
  40efb6:	mov    r8d,DWORD PTR [r8]
  40efb9:	mov    r9,rax
  40efbc:	lea    r10,[rsp+0x10]
  40efc1:	call   411cc0 <__swc_fn_4fa09e82_000161_01cbb887>
  40efc6:	test   al,al
  40efc8:	jne    40effb <__swc_fn_4fa09e82_000163_60216e69+0x19b>
  40efca:	vmovups xmm0,XMMWORD PTR [rip+0x4886]        # 413858 <__swc_rdata_base_4fa09e82+0x748>
  40efd2:	vmovups XMMWORD PTR [rbx],xmm0
  40efd6:	vmovups xmm0,XMMWORD PTR [rip+0x488a]        # 413868 <__swc_rdata_base_4fa09e82+0x758>
  40efde:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40efe3:	vxorps xmm0,xmm0,xmm0
  40efe7:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40efec:	mov    rax,rbx
  40efef:	add    rsp,0x50
  40eff3:	pop    r13
  40eff5:	pop    r12
  40eff7:	pop    rdi
  40eff8:	pop    rsi
  40eff9:	pop    rbx
  40effa:	ret
  40effb:	lea    r13,[rsp+0x3c]
  40f000:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40f005:	mov    DWORD PTR [rsp+0x3c],eax
  40f009:	test   eax,eax
  40f00b:	je     40f05c <__swc_fn_4fa09e82_000163_60216e69+0x1fc>
  40f00d:	mov    rcx,rdi
  40f010:	mov    rdx,QWORD PTR [r11+0x18]
  40f014:	mov    r8d,DWORD PTR [rsi]
  40f017:	mov    rax,r13
  40f01a:	mov    r9d,DWORD PTR [rax]
  40f01d:	lea    r10,[rsp+0x20]
  40f022:	call   411cc0 <__swc_fn_4fa09e82_000161_01cbb887>
  40f027:	test   al,al
  40f029:	jne    40f05c <__swc_fn_4fa09e82_000163_60216e69+0x1fc>
  40f02b:	vmovups xmm0,XMMWORD PTR [rip+0x4855]        # 413888 <__swc_rdata_base_4fa09e82+0x778>
  40f033:	vmovups XMMWORD PTR [rbx],xmm0
  40f037:	vmovups xmm0,XMMWORD PTR [rip+0x4859]        # 413898 <__swc_rdata_base_4fa09e82+0x788>
  40f03f:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40f044:	vxorps xmm0,xmm0,xmm0
  40f048:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40f04d:	mov    rax,rbx
  40f050:	add    rsp,0x50
  40f054:	pop    r13
  40f056:	pop    r12
  40f058:	pop    rdi
  40f059:	pop    rsi
  40f05a:	pop    rbx
  40f05b:	ret
  40f05c:	mov    eax,0x1
  40f061:	rex mov BYTE PTR [rsp+0x8],al
  40f066:	cmp    DWORD PTR [r13+0x0],0x0
  40f06b:	je     40f07c <__swc_fn_4fa09e82_000163_60216e69+0x21c>
  40f06d:	rex mov BYTE PTR [rsp+0x9],0x1
  40f073:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40f078:	mov    DWORD PTR [rsp+0x30],eax
  40f07c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f082:	vmovups XMMWORD PTR [rbx],xmm0
  40f086:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40f08c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40f091:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40f097:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40f09c:	mov    rax,rbx
  40f09f:	add    rsp,0x50
  40f0a3:	pop    r13
  40f0a5:	pop    r12
  40f0a7:	pop    rdi
  40f0a8:	pop    rsi
  40f0a9:	pop    rbx
  40f0aa:	ret
  40f0ab:	add    rcx,0x1
  40f0af:	cmp    rcx,rax
  40f0b2:	jb     40ef70 <__swc_fn_4fa09e82_000163_60216e69+0x110>
  40f0b8:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f0be:	vmovups XMMWORD PTR [rbx],xmm0
  40f0c2:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40f0c8:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40f0cd:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40f0d3:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40f0d8:	mov    rax,rbx
  40f0db:	add    rsp,0x50
  40f0df:	pop    r13
  40f0e1:	pop    r12
  40f0e3:	pop    rdi
  40f0e4:	pop    rsi
  40f0e5:	pop    rbx
  40f0e6:	ret
	...

000000000040f0f0 <__swc_fn_4fa09e82_000166_cf398896>:
  40f0f0:	sub    rsp,0x48
  40f0f4:	call   40e4c0 <__swc_fn_4fa09e82_000124_9d2cbd72>
  40f0f9:	cmp    rax,0xffffffffffffffff
  40f0fd:	je     40f104 <__swc_fn_4fa09e82_000166_cf398896+0x14>
  40f0ff:	add    rsp,0x48
  40f103:	ret
  40f104:	lea    rcx,[rip+0x47bd]        # 4138c8 <__swc_rdata_base_4fa09e82+0x7b8>
  40f10b:	vmovups xmm0,XMMWORD PTR [rip+0x47c5]        # 4138d8 <__swc_rdata_base_4fa09e82+0x7c8>
  40f113:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f119:	vmovups xmm0,XMMWORD PTR [rip+0x47c7]        # 4138e8 <__swc_rdata_base_4fa09e82+0x7d8>
  40f121:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f127:	vmovups xmm0,XMMWORD PTR [rip+0x47c9]        # 4138f8 <__swc_rdata_base_4fa09e82+0x7e8>
  40f12f:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40f135:	lea    rdx,[rsp+0x8]
  40f13a:	mov    QWORD PTR [rsp+0x38],rax
  40f13f:	call   40df60 <__swc_fn_4fa09e82_000103_67100064>
  40f144:	mov    rax,QWORD PTR [rsp+0x38]
  40f149:	jmp    40f0ff <__swc_fn_4fa09e82_000166_cf398896+0xf>
  40f14b:	add    BYTE PTR [rax],al
  40f14d:	add    BYTE PTR [rax],al
	...

000000000040f150 <__swc_fn_4fa09e82_000169_92b7d63c>:
  40f150:	push   rbx
  40f151:	push   rsi
  40f152:	sub    rsp,0x28
  40f156:	mov    rbx,rcx
  40f159:	mov    DWORD PTR [rsp+0x8],0xbf0
  40f161:	mov    ecx,0xbf0
  40f166:	call   40db50 <__swc_fn_4fa09e82_000079_34776ded>
  40f16b:	mov    rsi,rax
  40f16e:	test   rax,rax
  40f171:	jne    40f17c <__swc_fn_4fa09e82_000169_92b7d63c+0x2c>
  40f173:	xor    eax,eax
  40f175:	add    rsp,0x28
  40f179:	pop    rsi
  40f17a:	pop    rbx
  40f17b:	ret
  40f17c:	vxorps xmm0,xmm0,xmm0
  40f180:	xor    eax,eax
  40f182:	cs nop WORD PTR [rax+rax*1+0x0]
  40f18c:	nop    DWORD PTR [rax+0x0]
  40f190:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40f195:	add    rax,0x10
  40f199:	cmp    rax,0xbf0
  40f1a0:	jne    40f190 <__swc_fn_4fa09e82_000169_92b7d63c+0x40>
  40f1a2:	lea    rax,[rbx+0x1]
  40f1a6:	mov    QWORD PTR [rsi+0x9c0],rax
  40f1ad:	mov    rcx,rbx
  40f1b0:	mov    rdx,rsi
  40f1b3:	call   412020 <__swc_fn_4fa09e82_000167_f6173642>
  40f1b8:	test   al,al
  40f1ba:	jne    40f1cd <__swc_fn_4fa09e82_000169_92b7d63c+0x7d>
  40f1bc:	mov    rcx,rsi
  40f1bf:	call   410590 <__swc_fn_4fa09e82_000080_c1514492>
  40f1c4:	xor    eax,eax
  40f1c6:	add    rsp,0x28
  40f1ca:	pop    rsi
  40f1cb:	pop    rbx
  40f1cc:	ret
  40f1cd:	lea    rcx,[rsp+0x18]
  40f1d2:	call   410b10 <__swc_fn_4fa09e82_000092_8252f8c0>
  40f1d7:	mov    rax,rsi
  40f1da:	add    rsp,0x28
  40f1de:	pop    rsi
  40f1df:	pop    rbx
  40f1e0:	ret
	...

000000000040f1f0 <__swc_fn_4fa09e82_000172_c0e8acb1>:
  40f1f0:	xor    eax,eax
  40f1f2:	mov    edx,0x1
  40f1f7:	lock cmpxchg QWORD PTR [rcx],rdx
  40f1fc:	test   rax,rax
  40f1ff:	jne    40f202 <__swc_fn_4fa09e82_000172_c0e8acb1+0x12>
  40f201:	ret
  40f202:	cs nop WORD PTR [rax+rax*1+0x0]
  40f20c:	nop    DWORD PTR [rax+0x0]
  40f210:	mov    rax,QWORD PTR [rcx]
  40f213:	test   rax,rax
  40f216:	je     40f1f0 <__swc_fn_4fa09e82_000172_c0e8acb1>
  40f218:	jmp    40f210 <__swc_fn_4fa09e82_000172_c0e8acb1+0x20>
  40f21a:	add    BYTE PTR [rax],al
  40f21c:	add    BYTE PTR [rax],al
	...

000000000040f220 <__swc_fn_4fa09e82_000175_176517f9>:
  40f220:	push   rsi
  40f221:	push   rdi
  40f222:	sub    rsp,0x38
  40f226:	mov    rsi,rcx
  40f229:	call   412030 <__swc_fn_4fa09e82_000170_4579a84c>
  40f22e:	mov    rdi,rax
  40f231:	call   4117a0 <__swc_fn_4fa09e82_000131_c1196dfb>
  40f236:	mov    r8,rax
  40f239:	mov    rcx,rdi
  40f23c:	call   40f1f0 <__swc_fn_4fa09e82_000172_c0e8acb1>
  40f241:	mov    rax,QWORD PTR [rdi+0x8]
  40f245:	test   rax,rax
  40f248:	je     40f285 <__swc_fn_4fa09e82_000175_176517f9+0x65>
  40f24a:	nop    WORD PTR [rax+rax*1+0x0]
  40f250:	cmp    rax,rsi
  40f253:	je     40f285 <__swc_fn_4fa09e82_000175_176517f9+0x65>
  40f255:	mov    r9,QWORD PTR [rax]
  40f258:	cmp    QWORD PTR [rax+0x20],r8
  40f25c:	jne    40f27d <__swc_fn_4fa09e82_000175_176517f9+0x5d>
  40f25e:	mov    rcx,rdi
  40f261:	mov    rdx,rax
  40f264:	mov    QWORD PTR [rsp+0x28],r8
  40f269:	mov    QWORD PTR [rsp+0x30],r9
  40f26e:	call   40b7e0 <__swc_fn_4fa09e82_000174_f69b1f05>
  40f273:	mov    r8,QWORD PTR [rsp+0x28]
  40f278:	mov    r9,QWORD PTR [rsp+0x30]
  40f27d:	mov    rax,r9
  40f280:	test   r9,r9
  40f283:	jne    40f250 <__swc_fn_4fa09e82_000175_176517f9+0x30>
  40f285:	xor    eax,eax
  40f287:	mov    QWORD PTR [rdi],rax
  40f28a:	add    rsp,0x38
  40f28e:	pop    rdi
  40f28f:	pop    rsi
  40f290:	ret
	...

000000000040f2a0 <__swc_fn_4fa09e82_000178_1ca87929>:
  40f2a0:	push   rdi
  40f2a1:	push   rsi
  40f2a2:	sub    rsp,0xb8
  40f2a9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40f2af:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40f2b5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40f2bb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40f2c1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40f2c7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40f2cd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40f2d3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40f2dc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40f2e5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40f2ee:	vxorps xmm0,xmm0,xmm0
  40f2f2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f2f8:	mov    edi,0x1
  40f2fd:	lea    rsi,[rsp+0x8]
  40f302:	xor    eax,eax
  40f304:	call   407130 <clock_gettime@plt>
  40f309:	vxorpd xmm0,xmm0,xmm0
  40f30d:	mov    rax,QWORD PTR [rsp+0x8]
  40f312:	vcvtsi2sd xmm0,xmm0,rax
  40f317:	vxorpd xmm1,xmm1,xmm1
  40f31b:	mov    rax,QWORD PTR [rsp+0x10]
  40f320:	vcvtsi2sd xmm1,xmm1,rax
  40f325:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x45db]        # 413908 <__swc_rdata_base_4fa09e82+0x7f8>
  40f32d:	vaddsd xmm0,xmm0,xmm1
  40f331:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40f337:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40f33d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40f343:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40f349:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40f34f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40f355:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40f35b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40f364:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40f36d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40f376:	add    rsp,0xb8
  40f37d:	pop    rsi
  40f37e:	pop    rdi
  40f37f:	ret

000000000040f380 <__swc_fn_4fa09e82_000002_884bb5c0>:
  40f380:	sub    rsp,0x8
  40f384:	call   4110f0 <__swc_fn_4fa09e82_000110_8d425bd3>
  40f389:	mov    rcx,rax
  40f38c:	test   rax,rax
  40f38f:	je     40f3b6 <__swc_fn_4fa09e82_000002_884bb5c0+0x36>
  40f391:	lea    rdx,[rip+0x14ca8]        # 424040 <__swc_bss_base_4fa09e82>
  40f398:	mov    r8,QWORD PTR [rip+0x14ca1]        # 424040 <__swc_bss_base_4fa09e82>
  40f39f:	nop
  40f3a0:	lea    r9,[r8+0x1]
  40f3a4:	mov    rax,r8
  40f3a7:	lock cmpxchg QWORD PTR [rdx],r9
  40f3ac:	cmp    rax,r8
  40f3af:	je     40f3b6 <__swc_fn_4fa09e82_000002_884bb5c0+0x36>
  40f3b1:	mov    r8,rax
  40f3b4:	jmp    40f3a0 <__swc_fn_4fa09e82_000002_884bb5c0+0x20>
  40f3b6:	mov    rax,rcx
  40f3b9:	add    rsp,0x8
  40f3bd:	ret
	...

000000000040f3c0 <__swc_fn_4fa09e82_000005_b2240b56>:
  40f3c0:	mov    r8d,edx
  40f3c3:	xor    eax,eax
  40f3c5:	tzcnt  eax,edx
  40f3c9:	shrx   r9d,edx,eax
  40f3ce:	mov    DWORD PTR [rcx+0x2c],edx
  40f3d1:	xor    eax,eax
  40f3d3:	tzcnt  eax,edx
  40f3d7:	mov    BYTE PTR [rcx+0x38],al
  40f3da:	mov    eax,0xffffffff
  40f3df:	xor    edx,edx
  40f3e1:	div    r8d
  40f3e4:	mov    DWORD PTR [rcx+0x34],eax
  40f3e7:	mov    eax,r9d
  40f3ea:	mov    edx,r9d
  40f3ed:	imul   edx,r9d
  40f3f1:	mov    r8d,0x2
  40f3f7:	sub    r8d,edx
  40f3fa:	imul   eax,r8d
  40f3fe:	mov    edx,r9d
  40f401:	imul   edx,eax
  40f404:	mov    r8d,0x2
  40f40a:	sub    r8d,edx
  40f40d:	imul   eax,r8d
  40f411:	mov    edx,r9d
  40f414:	imul   edx,eax
  40f417:	mov    r8d,0x2
  40f41d:	sub    r8d,edx
  40f420:	imul   eax,r8d
  40f424:	mov    edx,r9d
  40f427:	imul   edx,eax
  40f42a:	mov    r8d,0x2
  40f430:	sub    r8d,edx
  40f433:	imul   eax,r8d
  40f437:	imul   r9d,eax
  40f43b:	mov    edx,0x2
  40f440:	sub    edx,r9d
  40f443:	imul   eax,edx
  40f446:	mov    DWORD PTR [rcx+0x30],eax
  40f449:	ret
  40f44a:	add    BYTE PTR [rax],al
  40f44c:	add    BYTE PTR [rax],al
	...

000000000040f450 <__swc_fn_4fa09e82_000008_4e857afc>:
  40f450:	xor    eax,eax
  40f452:	mov    DWORD PTR [rcx+0x68],eax
  40f455:	ret
	...

000000000040f460 <__swc_fn_4fa09e82_000011_6493fbbc>:
  40f460:	mov    eax,DWORD PTR [rcx+0x28]
  40f463:	shlx   eax,edx,eax
  40f468:	shl    rax,0x10
  40f46c:	lea    rdx,[rcx+rax*1]
  40f470:	lea    rax,[rcx+0x3000]
  40f477:	cmp    rdx,rax
  40f47a:	cmovae rax,rdx
  40f47e:	ret
	...

000000000040f480 <__swc_fn_4fa09e82_000014_afb279e2>:
  40f480:	push   rsi
  40f481:	push   rdi
  40f482:	push   r12
  40f484:	push   r13
  40f486:	push   r14
  40f488:	mov    rsi,rdx
  40f48b:	mov    rdi,rcx
  40f48e:	rex mov dl,BYTE PTR [rsi+0x3a]
  40f492:	mov    ecx,DWORD PTR [rdi+0x28]
  40f495:	shr    dl,cl
  40f497:	mov    r12d,0x1
  40f49d:	mov    ecx,edx
  40f49f:	shl    r12,cl
  40f4a2:	mov    r13d,DWORD PTR [rsi+0x3c]
  40f4a6:	rex mov BYTE PTR [rsi+0x3b],0x0
  40f4ab:	mov    QWORD PTR [rsi+0x40],0x0
  40f4b3:	mov    QWORD PTR [rsi],0x0
  40f4ba:	mov    rax,QWORD PTR [rsi+0x10]
  40f4be:	mov    QWORD PTR [rsi+0x20],rax
  40f4c2:	lea    r14,[rip+0x14b7f]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  40f4c9:	mov    rax,QWORD PTR [r14]
  40f4cc:	shr    rax,0x2
  40f4d0:	mov    rcx,rax
  40f4d3:	cmp    rax,0x800000
  40f4da:	mov    eax,0x800000
  40f4df:	cmovb  rcx,rax
  40f4e3:	lea    r8,[rip+0x14b6e]        # 424058 <__swc_bss_base_4fa09e82+0x18>
  40f4ea:	mov    rax,QWORD PTR [r8]
  40f4ed:	mov    r9,rax
  40f4f0:	lea    r10,[r9+r13*1]
  40f4f4:	cmp    r10,rcx
  40f4f7:	ja     40f51b <__swc_fn_4fa09e82_000014_afb279e2+0x9b>
  40f4f9:	mov    rax,r9
  40f4fc:	lock cmpxchg QWORD PTR [r8],r10
  40f501:	cmp    rax,r9
  40f504:	je     40f50b <__swc_fn_4fa09e82_000014_afb279e2+0x8b>
  40f506:	mov    r9,rax
  40f509:	jmp    40f4f0 <__swc_fn_4fa09e82_000014_afb279e2+0x70>
  40f50b:	mov    rcx,rdi
  40f50e:	mov    rdx,r12
  40f511:	call   40c310 <__swc_fn_4fa09e82_000016_4b207b58>
  40f516:	jmp    40f59d <__swc_fn_4fa09e82_000014_afb279e2+0x11d>
  40f51b:	mov    rcx,rdi
  40f51e:	movzx  edx,dl
  40f521:	call   40f460 <__swc_fn_4fa09e82_000011_6493fbbc>
  40f526:	test   r13,r13
  40f529:	je     40f596 <__swc_fn_4fa09e82_000014_afb279e2+0x116>
  40f52f:	mov    rcx,rax
  40f532:	mov    rdx,r13
  40f535:	call   411270 <__swc_fn_4fa09e82_000113_759e9ceb>
  40f53a:	mov    rcx,QWORD PTR [rip+0x14b07]        # 424048 <__swc_bss_base_4fa09e82+0x8>
  40f541:	cs nop WORD PTR [rax+rax*1+0x0]
  40f54b:	nop    DWORD PTR [rax+rax*1+0x0]
  40f550:	mov    rdx,rcx
  40f553:	sub    rdx,r13
  40f556:	mov    rax,rcx
  40f559:	lock cmpxchg QWORD PTR [r14],rdx
  40f55e:	cmp    rax,rcx
  40f561:	je     40f568 <__swc_fn_4fa09e82_000014_afb279e2+0xe8>
  40f563:	mov    rcx,rax
  40f566:	jmp    40f550 <__swc_fn_4fa09e82_000014_afb279e2+0xd0>
  40f568:	lea    rcx,[rip+0x14af1]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  40f56f:	mov    rdx,QWORD PTR [rip+0x14aea]        # 424060 <__swc_bss_base_4fa09e82+0x20>
  40f576:	cs nop WORD PTR [rax+rax*1+0x0]
  40f580:	lea    r8,[rdx+0x1]
  40f584:	mov    rax,rdx
  40f587:	lock cmpxchg QWORD PTR [rcx],r8
  40f58c:	cmp    rax,rdx
  40f58f:	je     40f596 <__swc_fn_4fa09e82_000014_afb279e2+0x116>
  40f591:	mov    rdx,rax
  40f594:	jmp    40f580 <__swc_fn_4fa09e82_000014_afb279e2+0x100>
  40f596:	mov    DWORD PTR [rsi+0x3c],0x0
  40f59d:	mov    rcx,rdi
  40f5a0:	mov    rdx,r12
  40f5a3:	call   407600 <__swc_fn_4fa09e82_000018_7d1e8a10>
  40f5a8:	pop    r14
  40f5aa:	pop    r13
  40f5ac:	pop    r12
  40f5ae:	pop    rdi
  40f5af:	pop    rsi
  40f5b0:	ret
	...

000000000040f5c0 <__swc_fn_4fa09e82_000017_4df2d1a0>:
  40f5c0:	mov    r8,QWORD PTR [rcx+0x48]
  40f5c4:	test   r8,rdx
  40f5c7:	je     40f5f8 <__swc_fn_4fa09e82_000017_4df2d1a0+0x38>
  40f5c9:	nop    DWORD PTR [rax+0x0]
  40f5d0:	mov    rax,rdx
  40f5d3:	not    rax
  40f5d6:	mov    r9,r8
  40f5d9:	and    r9,rax
  40f5dc:	mov    rax,r8
  40f5df:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40f5e5:	cmp    rax,r8
  40f5e8:	jne    40f5f0 <__swc_fn_4fa09e82_000017_4df2d1a0+0x30>
  40f5ea:	mov    eax,0x1
  40f5ef:	ret
  40f5f0:	mov    r8,rax
  40f5f3:	test   rax,rdx
  40f5f6:	jne    40f5d0 <__swc_fn_4fa09e82_000017_4df2d1a0+0x10>
  40f5f8:	xor    eax,eax
  40f5fa:	ret
  40f5fb:	add    BYTE PTR [rax],al
  40f5fd:	add    BYTE PTR [rax],al
	...

000000000040f600 <__swc_fn_4fa09e82_000020_a66e8b97>:
  40f600:	push   rsi
  40f601:	push   rdi
  40f602:	push   r12
  40f604:	push   r13
  40f606:	sub    rsp,0x8
  40f60a:	mov    rsi,rdx
  40f60d:	mov    rdi,rcx
  40f610:	lea    r12,[rip+0x14bd9]        # 4241f0 <__swc_bss_base_4fa09e82+0x1b0>
  40f617:	mov    rcx,r12
  40f61a:	call   40e7e0 <__swc_fn_4fa09e82_000136_e3032dc2>
  40f61f:	xor    eax,eax
  40f621:	mov    rcx,QWORD PTR [rip+0x14bd0]        # 4241f8 <__swc_bss_base_4fa09e82+0x1b8>
  40f628:	mov    r13,rcx
  40f62b:	test   r13,r13
  40f62e:	je     40f67b <__swc_fn_4fa09e82_000020_a66e8b97+0x7b>
  40f630:	mov    rcx,QWORD PTR [r13+0x10]
  40f634:	cmp    DWORD PTR [r13+0x28],esi
  40f638:	jne    40f670 <__swc_fn_4fa09e82_000020_a66e8b97+0x70>
  40f63a:	test   rax,rax
  40f63d:	jne    40f648 <__swc_fn_4fa09e82_000020_a66e8b97+0x48>
  40f63f:	mov    QWORD PTR [rip+0x14bb2],rcx        # 4241f8 <__swc_bss_base_4fa09e82+0x1b8>
  40f646:	jmp    40f64c <__swc_fn_4fa09e82_000020_a66e8b97+0x4c>
  40f648:	mov    QWORD PTR [rax+0x10],rcx
  40f64c:	vxorps xmm0,xmm0,xmm0
  40f650:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40f656:	mov    QWORD PTR [r13+0x8],rdi
  40f65a:	mov    rcx,r12
  40f65d:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40f662:	mov    rax,r13
  40f665:	add    rsp,0x8
  40f669:	pop    r13
  40f66b:	pop    r12
  40f66d:	pop    rdi
  40f66e:	pop    rsi
  40f66f:	ret
  40f670:	mov    rax,r13
  40f673:	mov    r13,rcx
  40f676:	test   rcx,rcx
  40f679:	jne    40f630 <__swc_fn_4fa09e82_000020_a66e8b97+0x30>
  40f67b:	mov    ecx,esi
  40f67d:	call   40c340 <__swc_fn_4fa09e82_000019_2cc1532c>
  40f682:	mov    rsi,rax
  40f685:	test   rax,rax
  40f688:	jne    40f69f <__swc_fn_4fa09e82_000020_a66e8b97+0x9f>
  40f68a:	mov    rcx,r12
  40f68d:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40f692:	xor    eax,eax
  40f694:	add    rsp,0x8
  40f698:	pop    r13
  40f69a:	pop    r12
  40f69c:	pop    rdi
  40f69d:	pop    rsi
  40f69e:	ret
  40f69f:	mov    QWORD PTR [rsi+0x8],rdi
  40f6a3:	mov    rcx,r12
  40f6a6:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40f6ab:	mov    rax,rsi
  40f6ae:	add    rsp,0x8
  40f6b2:	pop    r13
  40f6b4:	pop    r12
  40f6b6:	pop    rdi
  40f6b7:	pop    rsi
  40f6b8:	ret
  40f6b9:	add    BYTE PTR [rax],al
  40f6bb:	add    BYTE PTR [rax],al
  40f6bd:	add    BYTE PTR [rax],al
	...

000000000040f6c0 <__swc_fn_4fa09e82_000023_4aca8b9e>:
  40f6c0:	vxorps xmm0,xmm0,xmm0
  40f6c4:	xor    eax,eax
  40f6c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40f6d0:	cs nop WORD PTR [rax+rax*1+0x0]
  40f6da:	nop    WORD PTR [rax+rax*1+0x0]
  40f6e0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40f6e5:	add    rax,0x10
  40f6e9:	cmp    rax,0x2b00
  40f6f0:	jne    40f6e0 <__swc_fn_4fa09e82_000023_4aca8b9e+0x20>
  40f6f2:	ret
	...

000000000040f700 <__swc_fn_4fa09e82_000026_4aca8b9e>:
  40f700:	vxorps xmm0,xmm0,xmm0
  40f704:	vmovups XMMWORD PTR [rcx],xmm0
  40f708:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f70d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40f712:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40f717:	ret
	...

000000000040f720 <__swc_fn_4fa09e82_000029_4aca8b9e>:
  40f720:	vxorps xmm0,xmm0,xmm0
  40f724:	vmovups XMMWORD PTR [rcx],xmm0
  40f728:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f72d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40f732:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40f737:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40f73c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40f741:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40f746:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40f74b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40f753:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40f75b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40f763:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40f76b:	mov    QWORD PTR [rcx+0xc0],0x0
  40f776:	ret
	...

000000000040f780 <__swc_fn_4fa09e82_000032_84881cd8>:
  40f780:	push   rsi
  40f781:	push   rdi
  40f782:	sub    rsp,0x8
  40f786:	mov    rsi,rcx
  40f789:	lea    rdi,[rip+0x12870]        # 422000 <__swc_data_base_4fa09e82>
  40f790:	mov    rax,QWORD PTR [rdi]
  40f793:	cmp    rax,0xffffffffffffffff
  40f797:	je     40f79e <__swc_fn_4fa09e82_000032_84881cd8+0x1e>
  40f799:	mov    rdi,rax
  40f79c:	jmp    40f7cb <__swc_fn_4fa09e82_000032_84881cd8+0x4b>
  40f79e:	call   40e4c0 <__swc_fn_4fa09e82_000124_9d2cbd72>
  40f7a3:	mov    rcx,rax
  40f7a6:	cmp    rax,0xffffffffffffffff
  40f7aa:	je     40f7dc <__swc_fn_4fa09e82_000032_84881cd8+0x5c>
  40f7ac:	mov    rax,0xffffffffffffffff
  40f7b3:	lock cmpxchg QWORD PTR [rdi],rcx
  40f7b8:	cmp    rax,0xffffffffffffffff
  40f7bc:	je     40f7c8 <__swc_fn_4fa09e82_000032_84881cd8+0x48>
  40f7be:	mov    rdi,rax
  40f7c1:	call   411650 <__swc_fn_4fa09e82_000125_667fbf24>
  40f7c6:	jmp    40f7cb <__swc_fn_4fa09e82_000032_84881cd8+0x4b>
  40f7c8:	mov    rdi,rcx
  40f7cb:	cmp    rdi,0xffffffffffffffff
  40f7cf:	je     40f7dc <__swc_fn_4fa09e82_000032_84881cd8+0x5c>
  40f7d1:	mov    rcx,rdi
  40f7d4:	mov    rdx,rsi
  40f7d7:	call   409b50 <__swc_fn_4fa09e82_000126_ce762363>
  40f7dc:	add    rsp,0x8
  40f7e0:	pop    rdi
  40f7e1:	pop    rsi
  40f7e2:	ret
	...

000000000040f7f0 <__swc_fn_4fa09e82_000035_95622a2b>:
  40f7f0:	sub    rsp,0x38
  40f7f4:	mov    rax,rdx
  40f7f7:	test   dl,dl
  40f7f9:	jne    40f811 <__swc_fn_4fa09e82_000035_95622a2b+0x21>
  40f7fb:	mov    rax,r8
  40f7fe:	test   r8b,r8b
  40f801:	cmove  eax,r9d
  40f805:	test   al,al
  40f807:	cmove  eax,r10d
  40f80b:	test   al,al
  40f80d:	cmove  eax,r11d
  40f811:	test   al,al
  40f813:	jne    40f81a <__swc_fn_4fa09e82_000035_95622a2b+0x2a>
  40f815:	add    rsp,0x38
  40f819:	ret
  40f81a:	lea    rcx,[rip+0x38ef]        # 413110 <__swc_rdata_base_4fa09e82>
  40f821:	vmovups xmm0,XMMWORD PTR [rip+0x38f7]        # 413120 <__swc_rdata_base_4fa09e82+0x10>
  40f829:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f82f:	vmovups xmm0,XMMWORD PTR [rip+0x38f9]        # 413130 <__swc_rdata_base_4fa09e82+0x20>
  40f837:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f83d:	vmovups xmm0,XMMWORD PTR [rip+0x38fb]        # 413140 <__swc_rdata_base_4fa09e82+0x30>
  40f845:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40f84b:	lea    rdx,[rsp+0x8]
  40f850:	call   40df60 <__swc_fn_4fa09e82_000103_67100064>
  40f855:	jmp    40f815 <__swc_fn_4fa09e82_000035_95622a2b+0x25>
	...

000000000040f860 <__swc_fn_4fa09e82_000038_788ceb38>:
  40f860:	sub    rsp,0x8
  40f864:	mov    eax,0x1000
  40f869:	test   eax,eax
  40f86b:	mov    r8d,0x8
  40f871:	cmove  eax,r8d
  40f875:	dec    rax
  40f878:	mov    r8,0xffffffffffffffff
  40f87f:	sub    r8,rax
  40f882:	cmp    rdx,r8
  40f885:	ja     40f895 <__swc_fn_4fa09e82_000038_788ceb38+0x35>
  40f887:	add    rdx,rax
  40f88a:	not    rax
  40f88d:	mov    r8,rdx
  40f890:	and    r8,rax
  40f893:	jne    40f89c <__swc_fn_4fa09e82_000038_788ceb38+0x3c>
  40f895:	xor    eax,eax
  40f897:	add    rsp,0x8
  40f89b:	ret
  40f89c:	mov    rdx,r8
  40f89f:	call   40c660 <__swc_fn_4fa09e82_000037_b4982903>
  40f8a4:	add    rsp,0x8
  40f8a8:	ret
  40f8a9:	add    BYTE PTR [rax],al
  40f8ab:	add    BYTE PTR [rax],al
  40f8ad:	add    BYTE PTR [rax],al
	...

000000000040f8b0 <__swc_fn_4fa09e82_000041_414cc921>:
  40f8b0:	push   rsi
  40f8b1:	push   rdi
  40f8b2:	sub    rsp,0x8
  40f8b6:	mov    rsi,rdx
  40f8b9:	mov    rdi,rcx
  40f8bc:	test   rdx,rdx
  40f8bf:	je     40f8db <__swc_fn_4fa09e82_000041_414cc921+0x2b>
  40f8c1:	xor    ecx,ecx
  40f8c3:	call   407720 <__swc_fn_4fa09e82_000033_7ca1566d>
  40f8c8:	mov    rax,QWORD PTR [rsi]
  40f8cb:	test   rax,rax
  40f8ce:	je     40f8db <__swc_fn_4fa09e82_000041_414cc921+0x2b>
  40f8d0:	mov    rcx,rax
  40f8d3:	mov    rdx,rsi
  40f8d6:	call   407840 <__swc_fn_4fa09e82_000042_bab03645>
  40f8db:	mov    rcx,rdi
  40f8de:	call   40c6c0 <__swc_fn_4fa09e82_000040_6895916d>
  40f8e3:	mov    rsi,rax
  40f8e6:	test   rax,rax
  40f8e9:	jne    40f8f4 <__swc_fn_4fa09e82_000041_414cc921+0x44>
  40f8eb:	xor    eax,eax
  40f8ed:	add    rsp,0x8
  40f8f1:	pop    rdi
  40f8f2:	pop    rsi
  40f8f3:	ret
  40f8f4:	mov    rcx,rsi
  40f8f7:	call   407720 <__swc_fn_4fa09e82_000033_7ca1566d>
  40f8fc:	mov    rax,rsi
  40f8ff:	add    rsp,0x8
  40f903:	pop    rdi
  40f904:	pop    rsi
  40f905:	ret
	...

000000000040f910 <__swc_fn_4fa09e82_000044_9c2ade9b>:
  40f910:	movzx  eax,BYTE PTR [r8+0x39]
  40f915:	lea    rax,[rax+rax*4]
  40f919:	lea    rax,[rdx+rax*8+0x28]
  40f91e:	mov    ecx,DWORD PTR [r8+0x6c]
  40f922:	test   ecx,ecx
  40f924:	je     40f95d <__swc_fn_4fa09e82_000044_9c2ade9b+0x4d>
  40f926:	mov    rcx,QWORD PTR [r8+0x50]
  40f92a:	test   rcx,rcx
  40f92d:	je     40f939 <__swc_fn_4fa09e82_000044_9c2ade9b+0x29>
  40f92f:	mov    rax,QWORD PTR [r8+0x48]
  40f933:	mov    QWORD PTR [rcx+0x48],rax
  40f937:	jmp    40f941 <__swc_fn_4fa09e82_000044_9c2ade9b+0x31>
  40f939:	mov    rcx,QWORD PTR [r8+0x48]
  40f93d:	mov    QWORD PTR [rax+0x18],rcx
  40f941:	mov    rax,QWORD PTR [r8+0x48]
  40f945:	test   rax,rax
  40f948:	je     40f952 <__swc_fn_4fa09e82_000044_9c2ade9b+0x42>
  40f94a:	mov    rcx,QWORD PTR [r8+0x50]
  40f94e:	mov    QWORD PTR [rax+0x50],rcx
  40f952:	vxorps xmm0,xmm0,xmm0
  40f956:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40f95c:	ret
  40f95d:	mov    rcx,QWORD PTR [r8+0x50]
  40f961:	test   rcx,rcx
  40f964:	je     40f970 <__swc_fn_4fa09e82_000044_9c2ade9b+0x60>
  40f966:	mov    rdx,QWORD PTR [r8+0x48]
  40f96a:	mov    QWORD PTR [rcx+0x48],rdx
  40f96e:	jmp    40f978 <__swc_fn_4fa09e82_000044_9c2ade9b+0x68>
  40f970:	mov    rcx,QWORD PTR [r8+0x48]
  40f974:	mov    QWORD PTR [rax+0x8],rcx
  40f978:	mov    rcx,QWORD PTR [r8+0x48]
  40f97c:	test   rcx,rcx
  40f97f:	je     40f98b <__swc_fn_4fa09e82_000044_9c2ade9b+0x7b>
  40f981:	mov    rdx,QWORD PTR [r8+0x50]
  40f985:	mov    QWORD PTR [rcx+0x50],rdx
  40f989:	jmp    40f993 <__swc_fn_4fa09e82_000044_9c2ade9b+0x83>
  40f98b:	mov    rcx,QWORD PTR [r8+0x50]
  40f98f:	mov    QWORD PTR [rax+0x10],rcx
  40f993:	cmp    QWORD PTR [rax],r8
  40f996:	jne    40f99f <__swc_fn_4fa09e82_000044_9c2ade9b+0x8f>
  40f998:	mov    QWORD PTR [rax],0x0
  40f99f:	vxorps xmm0,xmm0,xmm0
  40f9a3:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40f9a9:	ret
  40f9aa:	add    BYTE PTR [rax],al
  40f9ac:	add    BYTE PTR [rax],al
	...

000000000040f9b0 <__swc_fn_4fa09e82_000047_bc5ec610>:
  40f9b0:	sub    rsp,0x8
  40f9b4:	mov    r9,r8
  40f9b7:	mov    r10,rdx
  40f9ba:	call   40f910 <__swc_fn_4fa09e82_000044_9c2ade9b>
  40f9bf:	mov    DWORD PTR [r9+0x6c],0x0
  40f9c7:	movzx  eax,BYTE PTR [r9+0x39]
  40f9cc:	lea    rax,[rax+rax*4]
  40f9d0:	lea    rax,[r10+rax*8+0x28]
  40f9d5:	mov    rcx,QWORD PTR [rax+0x10]
  40f9d9:	mov    QWORD PTR [r9+0x50],rcx
  40f9dd:	mov    QWORD PTR [r9+0x48],0x0
  40f9e5:	mov    rcx,QWORD PTR [rax+0x10]
  40f9e9:	test   rcx,rcx
  40f9ec:	je     40f9f4 <__swc_fn_4fa09e82_000047_bc5ec610+0x44>
  40f9ee:	mov    QWORD PTR [rcx+0x48],r9
  40f9f2:	jmp    40f9f8 <__swc_fn_4fa09e82_000047_bc5ec610+0x48>
  40f9f4:	mov    QWORD PTR [rax+0x8],r9
  40f9f8:	mov    QWORD PTR [rax+0x10],r9
  40f9fc:	add    rsp,0x8
  40fa00:	ret
	...

000000000040fa20 <__swc_fn_4fa09e82_000050_ab8077df>:
  40fa20:	push   rsi
  40fa21:	push   rdi
  40fa22:	push   r12
  40fa24:	push   r13
  40fa26:	push   r14
  40fa28:	push   r15
  40fa2a:	sub    rsp,0x1f8
  40fa31:	mov    esi,r8d
  40fa34:	mov    QWORD PTR [rsp+0x1e8],rsi
  40fa3c:	mov    rdi,rcx
  40fa3f:	mov    r12,rdx
  40fa42:	lea    r13,[rsi+rsi*4]
  40fa46:	lea    r13,[rdx+r13*8+0x28]
  40fa4b:	call   407ca0 <__swc_fn_4fa09e82_000048_c877e9d2>
  40fa50:	add    DWORD PTR [r12+0x24],0x1
  40fa56:	test   BYTE PTR [r12+0x24],0x3f
  40fa5c:	jne    40fa66 <__swc_fn_4fa09e82_000050_ab8077df+0x46>
  40fa5e:	mov    rcx,rdi
  40fa61:	call   40c840 <__swc_fn_4fa09e82_000049_2ff013cc>
  40fa66:	mov    rax,QWORD PTR [r13+0x8]
  40fa6a:	mov    r14,rax
  40fa6d:	nop    DWORD PTR [rax]
  40fa70:	test   r14,r14
  40fa73:	jne    40fa82 <__swc_fn_4fa09e82_000050_ab8077df+0x62>
  40fa75:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40fa7d:	jmp    40fb89 <__swc_fn_4fa09e82_000050_ab8077df+0x169>
  40fa82:	mov    r15,QWORD PTR [r14+0x48]
  40fa86:	mov    rcx,r14
  40fa89:	call   4073f0 <__swc_fn_4fa09e82_000009_d7e2bb25>
  40fa8e:	mov    rax,QWORD PTR [r14]
  40fa91:	test   rax,rax
  40fa94:	je     40faa6 <__swc_fn_4fa09e82_000050_ab8077df+0x86>
  40fa96:	mov    rcx,QWORD PTR [rax]
  40fa99:	mov    QWORD PTR [r14],rcx
  40fa9c:	add    DWORD PTR [r14+0x28],0x1
  40faa1:	mov    rsi,rax
  40faa4:	jmp    40fac5 <__swc_fn_4fa09e82_000050_ab8077df+0xa5>
  40faa6:	mov    rax,QWORD PTR [r14+0x18]
  40faaa:	cmp    QWORD PTR [r14+0x20],rax
  40faae:	jae    40fac3 <__swc_fn_4fa09e82_000050_ab8077df+0xa3>
  40fab0:	mov    rsi,QWORD PTR [r14+0x20]
  40fab4:	mov    eax,DWORD PTR [r14+0x2c]
  40fab8:	add    QWORD PTR [r14+0x20],rax
  40fabc:	add    DWORD PTR [r14+0x28],0x1
  40fac1:	jmp    40fac5 <__swc_fn_4fa09e82_000050_ab8077df+0xa5>
  40fac3:	xor    esi,esi
  40fac5:	test   rsi,rsi
  40fac8:	jne    40fb0d <__swc_fn_4fa09e82_000050_ab8077df+0xed>
  40faca:	mov    rcx,r14
  40facd:	call   407320 <__swc_fn_4fa09e82_000006_a23dca5f>
  40fad2:	test   al,al
  40fad4:	je     40fb0d <__swc_fn_4fa09e82_000050_ab8077df+0xed>
  40fad6:	mov    rax,QWORD PTR [r14]
  40fad9:	test   rax,rax
  40fadc:	je     40faeb <__swc_fn_4fa09e82_000050_ab8077df+0xcb>
  40fade:	mov    rcx,QWORD PTR [rax]
  40fae1:	mov    QWORD PTR [r14],rcx
  40fae4:	add    DWORD PTR [r14+0x28],0x1
  40fae9:	jmp    40fb0a <__swc_fn_4fa09e82_000050_ab8077df+0xea>
  40faeb:	mov    rax,QWORD PTR [r14+0x18]
  40faef:	cmp    QWORD PTR [r14+0x20],rax
  40faf3:	jae    40fb08 <__swc_fn_4fa09e82_000050_ab8077df+0xe8>
  40faf5:	mov    rax,QWORD PTR [r14+0x20]
  40faf9:	mov    ecx,DWORD PTR [r14+0x2c]
  40fafd:	add    QWORD PTR [r14+0x20],rcx
  40fb01:	add    DWORD PTR [r14+0x28],0x1
  40fb06:	jmp    40fb0a <__swc_fn_4fa09e82_000050_ab8077df+0xea>
  40fb08:	xor    eax,eax
  40fb0a:	mov    rsi,rax
  40fb0d:	test   rsi,rsi
  40fb10:	jne    40fb63 <__swc_fn_4fa09e82_000050_ab8077df+0x143>
  40fb12:	mov    rcx,rdi
  40fb15:	mov    rdx,r12
  40fb18:	mov    r8,r14
  40fb1b:	call   40c7a0 <__swc_fn_4fa09e82_000046_88f44774>
  40fb20:	test   al,al
  40fb22:	jne    40fb63 <__swc_fn_4fa09e82_000050_ab8077df+0x143>
  40fb24:	mov    rcx,r14
  40fb27:	call   4073f0 <__swc_fn_4fa09e82_000009_d7e2bb25>
  40fb2c:	mov    rax,QWORD PTR [r14]
  40fb2f:	test   rax,rax
  40fb32:	je     40fb41 <__swc_fn_4fa09e82_000050_ab8077df+0x121>
  40fb34:	mov    rcx,QWORD PTR [rax]
  40fb37:	mov    QWORD PTR [r14],rcx
  40fb3a:	add    DWORD PTR [r14+0x28],0x1
  40fb3f:	jmp    40fb60 <__swc_fn_4fa09e82_000050_ab8077df+0x140>
  40fb41:	mov    rax,QWORD PTR [r14+0x18]
  40fb45:	cmp    QWORD PTR [r14+0x20],rax
  40fb49:	jae    40fb5e <__swc_fn_4fa09e82_000050_ab8077df+0x13e>
  40fb4b:	mov    rax,QWORD PTR [r14+0x20]
  40fb4f:	mov    ecx,DWORD PTR [r14+0x2c]
  40fb53:	add    QWORD PTR [r14+0x20],rcx
  40fb57:	add    DWORD PTR [r14+0x28],0x1
  40fb5c:	jmp    40fb60 <__swc_fn_4fa09e82_000050_ab8077df+0x140>
  40fb5e:	xor    eax,eax
  40fb60:	mov    rsi,rax
  40fb63:	test   rsi,rsi
  40fb66:	je     40fb81 <__swc_fn_4fa09e82_000050_ab8077df+0x161>
  40fb68:	mov    QWORD PTR [r13+0x0],r14
  40fb6c:	mov    rax,rsi
  40fb6f:	add    rsp,0x1f8
  40fb76:	pop    r15
  40fb78:	pop    r14
  40fb7a:	pop    r13
  40fb7c:	pop    r12
  40fb7e:	pop    rdi
  40fb7f:	pop    rsi
  40fb80:	ret
  40fb81:	mov    r14,r15
  40fb84:	jmp    40fa70 <__swc_fn_4fa09e82_000050_ab8077df+0x50>
  40fb89:	cs nop WORD PTR [rax+rax*1+0x0]
  40fb93:	cs nop WORD PTR [rax+rax*1+0x0]
  40fb9d:	nop    DWORD PTR [rax]
  40fba0:	mov    rcx,rdi
  40fba3:	mov    rdx,r12
  40fba6:	mov    r8d,esi
  40fba9:	call   4079e0 <__swc_fn_4fa09e82_000045_1fe0f4e2>
  40fbae:	mov    r14,rax
  40fbb1:	test   rax,rax
  40fbb4:	jne    40fbca <__swc_fn_4fa09e82_000050_ab8077df+0x1aa>
  40fbb6:	xor    eax,eax
  40fbb8:	add    rsp,0x1f8
  40fbbf:	pop    r15
  40fbc1:	pop    r14
  40fbc3:	pop    r13
  40fbc5:	pop    r12
  40fbc7:	pop    rdi
  40fbc8:	pop    rsi
  40fbc9:	ret
  40fbca:	mov    QWORD PTR [r13+0x0],r14
  40fbce:	mov    rax,QWORD PTR [r14]
  40fbd1:	test   rax,rax
  40fbd4:	je     40fbe6 <__swc_fn_4fa09e82_000050_ab8077df+0x1c6>
  40fbd6:	mov    rcx,QWORD PTR [rax]
  40fbd9:	mov    QWORD PTR [r14],rcx
  40fbdc:	add    DWORD PTR [r14+0x28],0x1
  40fbe1:	mov    r15,rax
  40fbe4:	jmp    40fc06 <__swc_fn_4fa09e82_000050_ab8077df+0x1e6>
  40fbe6:	mov    rax,QWORD PTR [r14+0x18]
  40fbea:	cmp    QWORD PTR [r14+0x20],rax
  40fbee:	jae    40fc03 <__swc_fn_4fa09e82_000050_ab8077df+0x1e3>
  40fbf0:	mov    r15,QWORD PTR [r14+0x20]
  40fbf4:	mov    eax,DWORD PTR [r14+0x2c]
  40fbf8:	add    QWORD PTR [r14+0x20],rax
  40fbfc:	add    DWORD PTR [r14+0x28],0x1
  40fc01:	jmp    40fc06 <__swc_fn_4fa09e82_000050_ab8077df+0x1e6>
  40fc03:	xor    r15d,r15d
  40fc06:	test   r15,r15
  40fc09:	jne    40fc4e <__swc_fn_4fa09e82_000050_ab8077df+0x22e>
  40fc0b:	mov    rcx,r14
  40fc0e:	call   407320 <__swc_fn_4fa09e82_000006_a23dca5f>
  40fc13:	test   al,al
  40fc15:	je     40fc4e <__swc_fn_4fa09e82_000050_ab8077df+0x22e>
  40fc17:	mov    rax,QWORD PTR [r14]
  40fc1a:	test   rax,rax
  40fc1d:	je     40fc2c <__swc_fn_4fa09e82_000050_ab8077df+0x20c>
  40fc1f:	mov    rcx,QWORD PTR [rax]
  40fc22:	mov    QWORD PTR [r14],rcx
  40fc25:	add    DWORD PTR [r14+0x28],0x1
  40fc2a:	jmp    40fc4b <__swc_fn_4fa09e82_000050_ab8077df+0x22b>
  40fc2c:	mov    rax,QWORD PTR [r14+0x18]
  40fc30:	cmp    QWORD PTR [r14+0x20],rax
  40fc34:	jae    40fc49 <__swc_fn_4fa09e82_000050_ab8077df+0x229>
  40fc36:	mov    rax,QWORD PTR [r14+0x20]
  40fc3a:	mov    ecx,DWORD PTR [r14+0x2c]
  40fc3e:	add    QWORD PTR [r14+0x20],rcx
  40fc42:	add    DWORD PTR [r14+0x28],0x1
  40fc47:	jmp    40fc4b <__swc_fn_4fa09e82_000050_ab8077df+0x22b>
  40fc49:	xor    eax,eax
  40fc4b:	mov    r15,rax
  40fc4e:	test   r15,r15
  40fc51:	je     40fba0 <__swc_fn_4fa09e82_000050_ab8077df+0x180>
  40fc57:	mov    rax,r15
  40fc5a:	add    rsp,0x1f8
  40fc61:	pop    r15
  40fc63:	pop    r14
  40fc65:	pop    r13
  40fc67:	pop    r12
  40fc69:	pop    rdi
  40fc6a:	pop    rsi
  40fc6b:	ret
  40fc6c:	add    BYTE PTR [rax],al
	...

000000000040fc70 <__swc_fn_4fa09e82_000053_82546d94>:
  40fc70:	push   rsi
  40fc71:	push   rdi
  40fc72:	push   r12
  40fc74:	mov    rsi,rdx
  40fc77:	mov    rax,rdx
  40fc7a:	shr    rax,0xc
  40fc7e:	movabs rdx,0x9e3779b97f4a7c15
  40fc88:	imul   rax,rdx
  40fc8c:	shr    rax,0x20
  40fc90:	lea    rax,[rax*8+0x0]
  40fc98:	shr    rax,0x20
  40fc9c:	lea    rax,[rax*8+0x0]
  40fca4:	lea    rax,[rcx+rax*8+0x40]
  40fca9:	xor    edx,edx
  40fcab:	test   dl,dl
  40fcad:	lea    rdi,[rcx+0x8]
  40fcb1:	cmove  rdi,rax
  40fcb5:	xor    edx,edx
  40fcb7:	test   dl,dl
  40fcb9:	lea    r12,[rcx+0x30]
  40fcbd:	lea    rax,[rax+0x8]
  40fcc1:	cmove  r12,rax
  40fcc5:	mov    rcx,rdi
  40fcc8:	call   40e7e0 <__swc_fn_4fa09e82_000136_e3032dc2>
  40fccd:	mov    QWORD PTR [rsi+0x30],0x0
  40fcd5:	mov    rax,QWORD PTR [r12]
  40fcd9:	mov    QWORD PTR [rsi+0x38],rax
  40fcdd:	test   rax,rax
  40fce0:	je     40fcea <__swc_fn_4fa09e82_000053_82546d94+0x7a>
  40fce2:	mov    rax,QWORD PTR [rsi+0x38]
  40fce6:	mov    QWORD PTR [rax+0x30],rsi
  40fcea:	mov    QWORD PTR [r12],rsi
  40fcee:	mov    rcx,rdi
  40fcf1:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  40fcf6:	pop    r12
  40fcf8:	pop    rdi
  40fcf9:	pop    rsi
  40fcfa:	ret
  40fcfb:	add    BYTE PTR [rax],al
  40fcfd:	add    BYTE PTR [rax],al
	...

000000000040fd00 <__swc_fn_4fa09e82_000056_38b21f11>:
  40fd00:	lea    rax,[rdx+rdx*4]
  40fd04:	lea    rax,[rcx+rax*8+0x268]
  40fd0c:	mov    rdx,QWORD PTR [rax+0x10]
  40fd10:	sub    QWORD PTR [rcx+0x2a68],rdx
  40fd17:	sub    QWORD PTR [rcx+0x2a70],0x1
  40fd1f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40fd26:	lea    rdx,[rdx+rdx*4]
  40fd2a:	lea    rdx,[rcx+rdx*8+0x268]
  40fd32:	vmovups xmm0,XMMWORD PTR [rdx]
  40fd36:	vmovups XMMWORD PTR [rax],xmm0
  40fd3a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40fd3f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40fd44:	mov    rcx,QWORD PTR [rdx+0x20]
  40fd48:	mov    QWORD PTR [rax+0x20],rcx
  40fd4c:	ret
  40fd4d:	add    BYTE PTR [rax],al
	...

000000000040fd50 <__swc_fn_4fa09e82_000059_3ca3ac64>:
  40fd50:	push   rsi
  40fd51:	push   rdi
  40fd52:	push   r12
  40fd54:	push   r13
  40fd56:	sub    rsp,0x8
  40fd5a:	mov    rsi,r8
  40fd5d:	mov    rdi,rcx
  40fd60:	mov    r12,rdx
  40fd63:	xor    r13d,r13d
  40fd66:	cs nop WORD PTR [rax+rax*1+0x0]
  40fd70:	mov    eax,DWORD PTR [r12+0x730]
  40fd78:	cmp    r13d,eax
  40fd7b:	jae    40fde1 <__swc_fn_4fa09e82_000059_3ca3ac64+0x91>
  40fd7d:	lea    rax,[r13+r13*4+0x0]
  40fd82:	lea    rax,[r12+rax*8+0x738]
  40fd8a:	mov    rdx,QWORD PTR [rax]
  40fd8d:	mov    r8,QWORD PTR [rax+0x8]
  40fd91:	mov    r9,QWORD PTR [rax+0x10]
  40fd95:	cmp    QWORD PTR [rax+0x20],rsi
  40fd99:	jb     40fda0 <__swc_fn_4fa09e82_000059_3ca3ac64+0x50>
  40fd9b:	inc    r13d
  40fd9e:	jmp    40fd70 <__swc_fn_4fa09e82_000059_3ca3ac64+0x20>
  40fda0:	sub    DWORD PTR [r12+0x730],0x1
  40fda9:	mov    ecx,DWORD PTR [r12+0x730]
  40fdb1:	lea    rcx,[rcx+rcx*4]
  40fdb5:	lea    rcx,[r12+rcx*8+0x738]
  40fdbd:	vmovups xmm0,XMMWORD PTR [rcx]
  40fdc1:	vmovups XMMWORD PTR [rax],xmm0
  40fdc5:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40fdca:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40fdcf:	mov    rcx,QWORD PTR [rcx+0x20]
  40fdd3:	mov    QWORD PTR [rax+0x20],rcx
  40fdd7:	mov    rcx,rdi
  40fdda:	call   407750 <__swc_fn_4fa09e82_000039_40d1e569>
  40fddf:	jmp    40fd70 <__swc_fn_4fa09e82_000059_3ca3ac64+0x20>
  40fde1:	add    rsp,0x8
  40fde5:	pop    r13
  40fde7:	pop    r12
  40fde9:	pop    rdi
  40fdea:	pop    rsi
  40fdeb:	ret
  40fdec:	add    BYTE PTR [rax],al
	...

000000000040fdf0 <__swc_fn_4fa09e82_000062_7e482c5f>:
  40fdf0:	push   rsi
  40fdf1:	push   rdi
  40fdf2:	push   r12
  40fdf4:	push   r13
  40fdf6:	push   r14
  40fdf8:	mov    rsi,rcx
  40fdfb:	mov    rdi,rdx
  40fdfe:	mov    r12,QWORD PTR [rdi]
  40fe01:	mov    r13,QWORD PTR [rdi+0x18]
  40fe05:	mov    rax,r12
  40fe08:	add    rax,QWORD PTR [rdi+0x8]
  40fe0c:	sub    rax,r13
  40fe0f:	cmp    r8,rax
  40fe12:	jbe    40fe1d <__swc_fn_4fa09e82_000062_7e482c5f+0x2d>
  40fe14:	pop    r14
  40fe16:	pop    r13
  40fe18:	pop    r12
  40fe1a:	pop    rdi
  40fe1b:	pop    rsi
  40fe1c:	ret
  40fe1d:	lea    rax,[r13+r8*1+0x0]
  40fe22:	sub    rax,r12
  40fe25:	mov    ecx,0x1000
  40fe2a:	test   ecx,ecx
  40fe2c:	mov    edx,0x8
  40fe31:	cmove  ecx,edx
  40fe34:	dec    rcx
  40fe37:	mov    rdx,0xffffffffffffffff
  40fe3e:	sub    rdx,rcx
  40fe41:	cmp    rax,rdx
  40fe44:	jbe    40fe4b <__swc_fn_4fa09e82_000062_7e482c5f+0x5b>
  40fe46:	xor    r14d,r14d
  40fe49:	jmp    40fe56 <__swc_fn_4fa09e82_000062_7e482c5f+0x66>
  40fe4b:	add    rax,rcx
  40fe4e:	andn   rax,rcx,rax
  40fe53:	mov    r14,rax
  40fe56:	mov    rax,QWORD PTR [rdi+0x10]
  40fe5a:	cmp    r14,rax
  40fe5d:	ja     40fe68 <__swc_fn_4fa09e82_000062_7e482c5f+0x78>
  40fe5f:	pop    r14
  40fe61:	pop    r13
  40fe63:	pop    r12
  40fe65:	pop    rdi
  40fe66:	pop    rsi
  40fe67:	ret
  40fe68:	mov    rax,r12
  40fe6b:	add    rax,QWORD PTR [rdi+0x10]
  40fe6f:	mov    rdx,r14
  40fe72:	sub    rdx,QWORD PTR [rdi+0x10]
  40fe76:	mov    rcx,rax
  40fe79:	call   4072a0 <__swc_fn_4fa09e82_000003_7ab4792e>
  40fe7e:	test   al,al
  40fe80:	jne    40fe8b <__swc_fn_4fa09e82_000062_7e482c5f+0x9b>
  40fe82:	pop    r14
  40fe84:	pop    r13
  40fe86:	pop    r12
  40fe88:	pop    rdi
  40fe89:	pop    rsi
  40fe8a:	ret
  40fe8b:	add    r12,r14
  40fe8e:	sub    r12,r13
  40fe91:	mov    rcx,r12
  40fe94:	sub    rcx,QWORD PTR [rdi+0x28]
  40fe98:	mov    rdx,QWORD PTR [rsi+0x250]
  40fe9f:	nop
  40fea0:	lea    r8,[rdx+rcx*1]
  40fea4:	mov    rax,rdx
  40fea7:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40feb0:	cmp    rax,rdx
  40feb3:	je     40feba <__swc_fn_4fa09e82_000062_7e482c5f+0xca>
  40feb5:	mov    rdx,rax
  40feb8:	jmp    40fea0 <__swc_fn_4fa09e82_000062_7e482c5f+0xb0>
  40feba:	mov    QWORD PTR [rdi+0x10],r14
  40febe:	mov    QWORD PTR [rdi+0x28],r12
  40fec2:	pop    r14
  40fec4:	pop    r13
  40fec6:	pop    r12
  40fec8:	pop    rdi
  40fec9:	pop    rsi
  40feca:	ret
  40fecb:	add    BYTE PTR [rax],al
  40fecd:	add    BYTE PTR [rax],al
	...

000000000040fed0 <__swc_fn_4fa09e82_000065_f9f4b610>:
  40fed0:	push   rbx
  40fed1:	push   rsi
  40fed2:	push   rdi
  40fed3:	push   r12
  40fed5:	push   r13
  40fed7:	sub    rsp,0xe0
  40fede:	mov    rbx,rdx
  40fee1:	mov    rsi,rcx
  40fee4:	cmp    DWORD PTR [rbx+0x58],0x0
  40fee8:	je     40ff0c <__swc_fn_4fa09e82_000065_f9f4b610+0x3c>
  40feea:	mov    eax,DWORD PTR [rbx+0x58]
  40feed:	sub    eax,0x1
  40fef0:	test   DWORD PTR [rbx+0x58],eax
  40fef3:	je     40ff0c <__swc_fn_4fa09e82_000065_f9f4b610+0x3c>
  40fef5:	mov    QWORD PTR [rbx+0x40],0x0
  40fefd:	add    rsp,0xe0
  40ff04:	pop    r13
  40ff06:	pop    r12
  40ff08:	pop    rdi
  40ff09:	pop    rsi
  40ff0a:	pop    rbx
  40ff0b:	ret
  40ff0c:	mov    rax,QWORD PTR [rbx+0x40]
  40ff10:	test   rax,rax
  40ff13:	jne    40ff2f <__swc_fn_4fa09e82_000065_f9f4b610+0x5f>
  40ff15:	mov    rcx,rsi
  40ff18:	mov    rdx,rbx
  40ff1b:	call   40d450 <__swc_fn_4fa09e82_000064_b0d63361>
  40ff20:	add    rsp,0xe0
  40ff27:	pop    r13
  40ff29:	pop    r12
  40ff2b:	pop    rdi
  40ff2c:	pop    rsi
  40ff2d:	pop    rbx
  40ff2e:	ret
  40ff2f:	cmp    QWORD PTR [rbx+0x48],0x0
  40ff34:	jne    40ff50 <__swc_fn_4fa09e82_000065_f9f4b610+0x80>
  40ff36:	mov    rcx,rsi
  40ff39:	mov    rdx,rbx
  40ff3c:	call   407f90 <__swc_fn_4fa09e82_000066_254b71af>
  40ff41:	add    rsp,0xe0
  40ff48:	pop    r13
  40ff4a:	pop    r12
  40ff4c:	pop    rdi
  40ff4d:	pop    rsi
  40ff4e:	pop    rbx
  40ff4f:	ret
  40ff50:	mov    rdi,QWORD PTR [rbx+0x40]
  40ff54:	lea    rax,[rip+0x14115]        # 424070 <__swc_bss_base_4fa09e82+0x30>
  40ff5b:	mov    rcx,rdi
  40ff5e:	sub    rcx,QWORD PTR [rax+0x8]
  40ff62:	mov    rax,QWORD PTR [rip+0x14117]        # 424080 <__swc_bss_base_4fa09e82+0x40>
  40ff69:	cmp    rcx,rax
  40ff6c:	jae    40ff98 <__swc_fn_4fa09e82_000065_f9f4b610+0xc8>
  40ff6e:	mov    rax,rdi
  40ff71:	and    rax,0xffffffffffc00000
  40ff78:	mov    rcx,rdi
  40ff7b:	shr    rcx,0x10
  40ff7f:	and    ecx,0x3f
  40ff82:	mov    edx,DWORD PTR [rax+0x28]
  40ff85:	shrx   ecx,ecx,edx
  40ff8a:	shl    rcx,0x4
  40ff8e:	lea    r12,[rax+rcx*8+0x80]
  40ff96:	jmp    40ffa3 <__swc_fn_4fa09e82_000065_f9f4b610+0xd3>
  40ff98:	mov    rcx,rdi
  40ff9b:	call   40c4d0 <__swc_fn_4fa09e82_000022_3a2e2048>
  40ffa0:	mov    r12,rax
  40ffa3:	test   r12,r12
  40ffa6:	je     40ffb5 <__swc_fn_4fa09e82_000065_f9f4b610+0xe5>
  40ffa8:	mov    eax,DWORD PTR [r12+0x2c]
  40ffad:	mov    r9d,eax
  40ffb0:	mov    r13,rax
  40ffb3:	jmp    410034 <__swc_fn_4fa09e82_000065_f9f4b610+0x164>
  40ffb5:	mov    rcx,rsi
  40ffb8:	mov    rdx,rdi
  40ffbb:	call   40cae0 <__swc_fn_4fa09e82_000052_c7484fb0>
  40ffc0:	mov    rcx,QWORD PTR [rax+0x28]
  40ffc4:	mov    r9,rcx
  40ffc7:	mov    rdx,QWORD PTR [rax+0x20]
  40ffcb:	mov    r13,rdx
  40ffce:	cmp    QWORD PTR [rbx+0x48],rcx
  40ffd2:	jbe    41000b <__swc_fn_4fa09e82_000065_f9f4b610+0x13b>
  40ffd4:	mov    ecx,DWORD PTR [rax+0x48]
  40ffd7:	cmp    DWORD PTR [rbx+0x58],ecx
  40ffda:	ja     41000b <__swc_fn_4fa09e82_000065_f9f4b610+0x13b>
  40ffdc:	mov    rcx,rsi
  40ffdf:	mov    rdx,rax
  40ffe2:	mov    r8,QWORD PTR [rbx+0x48]
  40ffe6:	mov    QWORD PTR [rsp+0xc8],r9
  40ffee:	mov    QWORD PTR [rsp+0xd0],rax
  40fff6:	call   40fdf0 <__swc_fn_4fa09e82_000062_7e482c5f>
  40fffb:	mov    r9,QWORD PTR [rsp+0xc8]
  410003:	mov    rax,QWORD PTR [rsp+0xd0]
  41000b:	mov    rcx,QWORD PTR [rax+0x28]
  41000f:	cmp    QWORD PTR [rbx+0x48],rcx
  410013:	ja     410034 <__swc_fn_4fa09e82_000065_f9f4b610+0x164>
  410015:	mov    ecx,DWORD PTR [rax+0x48]
  410018:	cmp    DWORD PTR [rbx+0x58],ecx
  41001b:	ja     410034 <__swc_fn_4fa09e82_000065_f9f4b610+0x164>
  41001d:	mov    rcx,QWORD PTR [rbx+0x48]
  410021:	mov    QWORD PTR [rax+0x20],rcx
  410025:	add    rsp,0xe0
  41002c:	pop    r13
  41002e:	pop    r12
  410030:	pop    rdi
  410031:	pop    rsi
  410032:	pop    rbx
  410033:	ret
  410034:	test   r12,r12
  410037:	je     410069 <__swc_fn_4fa09e82_000065_f9f4b610+0x199>
  410039:	cmp    QWORD PTR [rbx+0x48],r9
  41003d:	ja     410069 <__swc_fn_4fa09e82_000065_f9f4b610+0x199>
  41003f:	cmp    DWORD PTR [rbx+0x58],0x40
  410043:	ja     410069 <__swc_fn_4fa09e82_000065_f9f4b610+0x199>
  410045:	cmp    DWORD PTR [rbx+0x58],0x0
  410049:	je     410056 <__swc_fn_4fa09e82_000065_f9f4b610+0x186>
  41004b:	mov    ecx,DWORD PTR [rbx+0x58]
  41004e:	dec    rcx
  410051:	test   rdi,rcx
  410054:	jne    410069 <__swc_fn_4fa09e82_000065_f9f4b610+0x199>
  410056:	mov    QWORD PTR [rbx+0x40],rdi
  41005a:	add    rsp,0xe0
  410061:	pop    r13
  410063:	pop    r12
  410065:	pop    rdi
  410066:	pop    rsi
  410067:	pop    rbx
  410068:	ret
  410069:	vmovups xmm0,XMMWORD PTR [rbx]
  41006d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410073:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  410078:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  41007e:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  410083:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  410089:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  41008e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  410094:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  410099:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  41009f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  4100a4:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  4100aa:	mov    QWORD PTR [rsp+0x48],0x0
  4100b3:	mov    rcx,rsi
  4100b6:	lea    rdx,[rsp+0x8]
  4100bb:	call   40d450 <__swc_fn_4fa09e82_000064_b0d63361>
  4100c0:	mov    rax,QWORD PTR [rsp+0x48]
  4100c5:	test   rax,rax
  4100c8:	jne    4100e1 <__swc_fn_4fa09e82_000065_f9f4b610+0x211>
  4100ca:	mov    QWORD PTR [rbx+0x40],0x0
  4100d2:	add    rsp,0xe0
  4100d9:	pop    r13
  4100db:	pop    r12
  4100dd:	pop    rdi
  4100de:	pop    rsi
  4100df:	pop    rbx
  4100e0:	ret
  4100e1:	mov    rax,QWORD PTR [rbx+0x48]
  4100e5:	cmp    r13,rax
  4100e8:	cmovbe rax,r13
  4100ec:	mov    rcx,QWORD PTR [rsp+0x48]
  4100f1:	mov    rdx,rdi
  4100f4:	mov    r8,rax
  4100f7:	call   40e020 <__swc_fn_4fa09e82_000106_6fd80914>
  4100fc:	vmovups xmm0,XMMWORD PTR [rbx]
  410100:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  410106:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  41010b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  410111:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  410116:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  41011f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  410124:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  41012d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  410132:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  41013b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  410140:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  410149:	mov    QWORD PTR [rsp+0xa8],rdi
  410151:	mov    rcx,rsi
  410154:	lea    rdx,[rsp+0x68]
  410159:	call   407f90 <__swc_fn_4fa09e82_000066_254b71af>
  41015e:	mov    rax,QWORD PTR [rsp+0x48]
  410163:	mov    QWORD PTR [rbx+0x40],rax
  410167:	add    rsp,0xe0
  41016e:	pop    r13
  410170:	pop    r12
  410172:	pop    rdi
  410173:	pop    rsi
  410174:	pop    rbx
  410175:	ret
	...

0000000000410180 <__swc_fn_4fa09e82_000068_7d4c42bf>:
  410180:	push   r12
  410182:	push   rdi
  410183:	push   rsi
  410184:	push   r13
  410186:	push   r14
  410188:	sub    rsp,0x190
  41018f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  410198:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  4101a1:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  4101aa:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  4101b3:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  4101bc:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  4101c5:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  4101ce:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  4101d7:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  4101e0:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  4101e9:	mov    r12,rcx
  4101ec:	lea    rax,[rip+0x11e0d]        # 422000 <__swc_data_base_4fa09e82>
  4101f3:	mov    rax,QWORD PTR [rax]
  4101f6:	cmp    rax,0xffffffffffffffff
  4101fa:	je     410209 <__swc_fn_4fa09e82_000068_7d4c42bf+0x89>
  4101fc:	mov    eax,eax
  4101fe:	mov    edi,eax
  410200:	xor    eax,eax
  410202:	call   407000 <pthread_getspecific@plt>
  410207:	jmp    41020b <__swc_fn_4fa09e82_000068_7d4c42bf+0x8b>
  410209:	xor    eax,eax
  41020b:	test   rax,rax
  41020e:	jne    41021d <__swc_fn_4fa09e82_000068_7d4c42bf+0x9d>
  410210:	call   40c5a0 <__swc_fn_4fa09e82_000031_90860ff2>
  410215:	mov    rcx,rax
  410218:	call   409c00 <__swc_fn_4fa09e82_000129_41c3251c>
  41021d:	test   rax,rax
  410220:	je     410246 <__swc_fn_4fa09e82_000068_7d4c42bf+0xc6>
  410222:	cmp    QWORD PTR [rax],r12
  410225:	jne    410246 <__swc_fn_4fa09e82_000068_7d4c42bf+0xc6>
  410227:	xor    ecx,ecx
  410229:	mov    QWORD PTR [rsp+0xc8],rax
  410231:	call   407720 <__swc_fn_4fa09e82_000033_7ca1566d>
  410236:	mov    rdx,QWORD PTR [rsp+0xc8]
  41023e:	mov    rcx,r12
  410241:	call   407840 <__swc_fn_4fa09e82_000042_bab03645>
  410246:	lea    rsi,[r12+0x10]
  41024b:	mov    rcx,rsi
  41024e:	call   40e7e0 <__swc_fn_4fa09e82_000136_e3032dc2>
  410253:	mov    rdi,QWORD PTR [r12+0x20]
  410258:	test   rdi,rdi
  41025b:	je     41029e <__swc_fn_4fa09e82_000068_7d4c42bf+0x11e>
  41025d:	nop    DWORD PTR [rax]
  410260:	mov    rcx,r12
  410263:	mov    rdx,rdi
  410266:	call   40c760 <__swc_fn_4fa09e82_000043_957e4917>
  41026b:	mov    rcx,r12
  41026e:	mov    rdx,rdi
  410271:	mov    r8,0xffffffffffffffff
  410278:	call   40fd50 <__swc_fn_4fa09e82_000059_3ca3ac64>
  41027d:	mov    rcx,r12
  410280:	mov    rdx,rdi
  410283:	mov    r8d,0x9b8
  410289:	mov    r9d,0x9b8
  41028f:	call   407750 <__swc_fn_4fa09e82_000039_40d1e569>
  410294:	mov    rdi,QWORD PTR [r12+0x20]
  410299:	test   rdi,rdi
  41029c:	jne    410260 <__swc_fn_4fa09e82_000068_7d4c42bf+0xe0>
  41029e:	xor    eax,eax
  4102a0:	xchg   QWORD PTR [r12+0x2a80],rax
  4102a8:	test   rax,rax
  4102ab:	je     4102d1 <__swc_fn_4fa09e82_000068_7d4c42bf+0x151>
  4102ad:	cs nop WORD PTR [rax+rax*1+0x0]
  4102b7:	nop    WORD PTR [rax+rax*1+0x0]
  4102c0:	mov    rcx,rax
  4102c3:	mov    rax,QWORD PTR [rax+0x78]
  4102c7:	xor    edx,edx
  4102c9:	xchg   DWORD PTR [rcx+0x70],edx
  4102cc:	test   rax,rax
  4102cf:	jne    4102c0 <__swc_fn_4fa09e82_000068_7d4c42bf+0x140>
  4102d1:	mov    rax,QWORD PTR [r12+0x18]
  4102d6:	mov    rdi,rax
  4102d9:	test   rdi,rdi
  4102dc:	je     410371 <__swc_fn_4fa09e82_000068_7d4c42bf+0x1f1>
  4102e2:	cs nop WORD PTR [rax+rax*1+0x0]
  4102ec:	nop    DWORD PTR [rax+0x0]
  4102f0:	mov    rax,QWORD PTR [rdi+0x10]
  4102f4:	mov    r8d,DWORD PTR [rdi+0x2c]
  4102f8:	xor    r9d,r9d
  4102fb:	test   r8,r8
  4102fe:	jbe    41035d <__swc_fn_4fa09e82_000068_7d4c42bf+0x1dd>
  410300:	mov    ecx,r9d
  410303:	shl    rcx,0x4
  410307:	lea    rdx,[rdi+rcx*8+0x80]
  41030f:	cmp    BYTE PTR [rdx+0x3b],0x0
  410313:	je     410354 <__swc_fn_4fa09e82_000068_7d4c42bf+0x1d4>
  410315:	mov    DWORD PTR [rdx+0x28],0x0
  41031c:	mov    rcx,rdi
  41031f:	mov    QWORD PTR [rsp+0xd0],rax
  410327:	mov    QWORD PTR [rsp+0xd8],r8
  41032f:	mov    QWORD PTR [rsp+0xe0],r9
  410337:	call   40f480 <__swc_fn_4fa09e82_000014_afb279e2>
  41033c:	mov    rax,QWORD PTR [rsp+0xd0]
  410344:	mov    r8,QWORD PTR [rsp+0xd8]
  41034c:	mov    r9,QWORD PTR [rsp+0xe0]
  410354:	add    r9,0x1
  410358:	cmp    r9,r8
  41035b:	jb     410300 <__swc_fn_4fa09e82_000068_7d4c42bf+0x180>
  41035d:	mov    rcx,rdi
  410360:	mov    rdi,rax
  410363:	call   407630 <__swc_fn_4fa09e82_000021_491ac000>
  410368:	test   rdi,rdi
  41036b:	jne    4102f0 <__swc_fn_4fa09e82_000068_7d4c42bf+0x170>
  410371:	mov    QWORD PTR [r12+0x18],0x0
  41037a:	mov    QWORD PTR [r12+0x28],0x0
  410383:	mov    rcx,rsi
  410386:	call   411950 <__swc_fn_4fa09e82_000137_3e875c27>
  41038b:	mov    esi,0x8
  410390:	xor    edi,edi
  410392:	test   rsi,rsi
  410395:	je     4103f2 <__swc_fn_4fa09e82_000068_7d4c42bf+0x272>
  41039b:	nop    DWORD PTR [rax+rax*1+0x0]
  4103a0:	lea    r13,[rdi*8+0x0]
  4103a8:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  4103ad:	test   r14,r14
  4103b0:	je     4103e8 <__swc_fn_4fa09e82_000068_7d4c42bf+0x268>
  4103b2:	cs nop WORD PTR [rax+rax*1+0x0]
  4103bc:	nop    DWORD PTR [rax+0x0]
  4103c0:	mov    rcx,r12
  4103c3:	mov    rdx,r14
  4103c6:	call   407df0 <__swc_fn_4fa09e82_000054_ae20ea33>
  4103cb:	mov    rcx,r12
  4103ce:	mov    rdx,QWORD PTR [r14]
  4103d1:	mov    r8,QWORD PTR [r14+0x8]
  4103d5:	mov    r9,QWORD PTR [r14+0x10]
  4103d9:	call   407750 <__swc_fn_4fa09e82_000039_40d1e569>
  4103de:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  4103e3:	test   r14,r14
  4103e6:	jne    4103c0 <__swc_fn_4fa09e82_000068_7d4c42bf+0x240>
  4103e8:	add    rdi,0x1
  4103ec:	sub    rsi,0x1
  4103f0:	jne    4103a0 <__swc_fn_4fa09e82_000068_7d4c42bf+0x220>
  4103f2:	mov    rcx,r12
  4103f5:	call   407ec0 <__swc_fn_4fa09e82_000060_e6407a0a>
  4103fa:	lea    rcx,[r12+0x250]
  410402:	mov    rdx,QWORD PTR [rcx]
  410405:	mov    r8,QWORD PTR [r12+0x250]
  41040d:	nop    DWORD PTR [rax]
  410410:	mov    r9,r8
  410413:	sub    r9,rdx
  410416:	mov    rax,r8
  410419:	lock cmpxchg QWORD PTR [rcx],r9
  41041e:	cmp    rax,r8
  410421:	je     410428 <__swc_fn_4fa09e82_000068_7d4c42bf+0x2a8>
  410423:	mov    r8,rax
  410426:	jmp    410410 <__swc_fn_4fa09e82_000068_7d4c42bf+0x290>
  410428:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  410431:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  41043a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  410443:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  41044c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  410455:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  41045e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  410467:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  410470:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  410479:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  410482:	add    rsp,0x190
  410489:	pop    r14
  41048b:	pop    r13
  41048d:	pop    rsi
  41048e:	pop    rdi
  41048f:	pop    r12
  410491:	ret
	...

00000000004104a0 <__swc_fn_4fa09e82_000071_0d1ef36f>:
  4104a0:	sub    rsp,0x8
  4104a4:	mov    QWORD PTR [rdx+0x40],0x0
  4104ac:	call   40d450 <__swc_fn_4fa09e82_000064_b0d63361>
  4104b1:	add    rsp,0x8
  4104b5:	ret
	...

00000000004104c0 <__swc_fn_4fa09e82_000074_518516c2>:
  4104c0:	sub    rsp,0x8
  4104c4:	call   407f90 <__swc_fn_4fa09e82_000066_254b71af>
  4104c9:	add    rsp,0x8
  4104cd:	ret
	...

00000000004104d0 <__swc_fn_4fa09e82_000077_8b8614a7>:
  4104d0:	push   rbx
  4104d1:	push   rsi
  4104d2:	push   rdi
  4104d3:	push   r12
  4104d5:	push   r13
  4104d7:	push   r14
  4104d9:	push   r15
  4104db:	sub    rsp,0x20
  4104df:	mov    rbx,r11
  4104e2:	mov    rsi,rcx
  4104e5:	mov    rdi,rdx
  4104e8:	mov    r12,r8
  4104eb:	mov    r13,r9
  4104ee:	mov    r14,r10
  4104f1:	mov    rcx,QWORD PTR [rip+0x16848]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  4104f8:	test   rcx,rcx
  4104fb:	jne    41050d <__swc_fn_4fa09e82_000077_8b8614a7+0x3d>
  4104fd:	call   40f0f0 <__swc_fn_4fa09e82_000166_cf398896>
  410502:	lea    rcx,[rax+0x1]
  410506:	mov    QWORD PTR [rip+0x16833],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  41050d:	dec    rcx
  410510:	call   40b6c0 <__swc_fn_4fa09e82_000168_fce60b2b>
  410515:	mov    r15,rax
  410518:	lea    r11,[rip+0x13d21]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  41051f:	mov    rcx,r11
  410522:	call   407740 <__swc_fn_4fa09e82_000036_8d895ba1>
  410527:	test   al,al
  410529:	jne    41053a <__swc_fn_4fa09e82_000077_8b8614a7+0x6a>
  41052b:	mov    rcx,r11
  41052e:	call   40c600 <__swc_fn_4fa09e82_000034_25f19556>
  410533:	lea    r11,[rip+0x13d06]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  41053a:	mov    rcx,r11
  41053d:	mov    rdx,rsi
  410540:	mov    r8,rdi
  410543:	mov    r9,r12
  410546:	mov    r10,r13
  410549:	mov    rsi,r11
  41054c:	mov    r11,r14
  41054f:	call   40f7f0 <__swc_fn_4fa09e82_000035_95622a2b>
  410554:	test   bl,bl
  410556:	je     41057d <__swc_fn_4fa09e82_000077_8b8614a7+0xad>
  410558:	mov    QWORD PTR [rsp+0x8],rsi
  41055d:	lea    rax,[rip+0x2bec]        # 413150 <__swc_rdata_base_4fa09e82+0x40>
  410564:	mov    QWORD PTR [rsp+0x10],rax
  410569:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  41056f:	vmovups XMMWORD PTR [r15],xmm0
  410574:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  41057d:	mov    rax,rsi
  410580:	add    rsp,0x20
  410584:	pop    r15
  410586:	pop    r14
  410588:	pop    r13
  41058a:	pop    r12
  41058c:	pop    rdi
  41058d:	pop    rsi
  41058e:	pop    rbx
  41058f:	ret

0000000000410590 <__swc_fn_4fa09e82_000080_c1514492>:
  410590:	sub    rsp,0x8
  410594:	mov    rax,rcx
  410597:	test   rcx,rcx
  41059a:	jne    4105a1 <__swc_fn_4fa09e82_000080_c1514492+0x11>
  41059c:	add    rsp,0x8
  4105a0:	ret
  4105a1:	lea    rcx,[rax-0x10]
  4105a5:	mov    rax,QWORD PTR [rax-0x10]
  4105a9:	mov    rdx,rax
  4105ac:	call   4098a0 <__swc_fn_4fa09e82_000114_49b378a9>
  4105b1:	add    rsp,0x8
  4105b5:	ret
	...

00000000004105c0 <__swc_fn_4fa09e82_000083_31b501f2>:
  4105c0:	sub    rsp,0x8
  4105c4:	xor    r11d,r11d
  4105c7:	call   408250 <__swc_fn_4fa09e82_000084_ddf2b8a1>
  4105cc:	add    rsp,0x8
  4105d0:	ret
	...

00000000004105e0 <__swc_fn_4fa09e82_000086_c45095aa>:
  4105e0:	push   rsi
  4105e1:	push   rdi
  4105e2:	push   r12
  4105e4:	push   r13
  4105e6:	push   r14
  4105e8:	push   r15
  4105ea:	sub    rsp,0x68
  4105ee:	mov    rsi,r9
  4105f1:	mov    rdi,rcx
  4105f4:	mov    r12,rdx
  4105f7:	mov    r13,r8
  4105fa:	cmp    r8,r9
  4105fd:	jne    410625 <__swc_fn_4fa09e82_000086_c45095aa+0x45>
  4105ff:	mov    rcx,rdi
  410602:	mov    rdx,r12
  410605:	xor    r8d,r8d
  410608:	call   4085a0 <__swc_fn_4fa09e82_000090_a2d50c23>
  41060d:	test   al,al
  41060f:	je     410625 <__swc_fn_4fa09e82_000086_c45095aa+0x45>
  410611:	mov    eax,0x1
  410616:	add    rsp,0x68
  41061a:	pop    r15
  41061c:	pop    r14
  41061e:	pop    r13
  410620:	pop    r12
  410622:	pop    rdi
  410623:	pop    rsi
  410624:	ret
  410625:	cmp    BYTE PTR [r12+0x2c],0xe
  41062b:	je     41063e <__swc_fn_4fa09e82_000086_c45095aa+0x5e>
  41062d:	xor    eax,eax
  41062f:	add    rsp,0x68
  410633:	pop    r15
  410635:	pop    r14
  410637:	pop    r13
  410639:	pop    r12
  41063b:	pop    rdi
  41063c:	pop    rsi
  41063d:	ret
  41063e:	mov    r14,QWORD PTR [r12+0x98]
  410646:	mov    rax,QWORD PTR [r12+0xa0]
  41064e:	mov    r12,rax
  410651:	xor    r15d,r15d
  410654:	test   r12,r12
  410657:	je     4106bf <__swc_fn_4fa09e82_000086_c45095aa+0xdf>
  410659:	nop    DWORD PTR [rax+0x0]
  410660:	mov    QWORD PTR [rsp+0x58],r12
  410665:	lea    r12,[r15*8+0x0]
  41066d:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  410672:	mov    rcx,rax
  410675:	call   40dbe0 <__swc_fn_4fa09e82_000082_754dcd57>
  41067a:	cmp    BYTE PTR [rax+0x2c],0xe
  41067e:	jne    4106b0 <__swc_fn_4fa09e82_000086_c45095aa+0xd0>
  410680:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  410685:	lea    r8,[r13+rcx*1+0x0]
  41068a:	mov    rcx,rdi
  41068d:	mov    rdx,rax
  410690:	mov    r9,rsi
  410693:	call   4105e0 <__swc_fn_4fa09e82_000086_c45095aa>
  410698:	test   al,al
  41069a:	je     4106b0 <__swc_fn_4fa09e82_000086_c45095aa+0xd0>
  41069c:	mov    eax,0x1
  4106a1:	add    rsp,0x68
  4106a5:	pop    r15
  4106a7:	pop    r14
  4106a9:	pop    r13
  4106ab:	pop    r12
  4106ad:	pop    rdi
  4106ae:	pop    rsi
  4106af:	ret
  4106b0:	add    r15,0x1
  4106b4:	mov    r12,QWORD PTR [rsp+0x58]
  4106b9:	sub    r12,0x1
  4106bd:	jne    410660 <__swc_fn_4fa09e82_000086_c45095aa+0x80>
  4106bf:	xor    eax,eax
  4106c1:	add    rsp,0x68
  4106c5:	pop    r15
  4106c7:	pop    r14
  4106c9:	pop    r13
  4106cb:	pop    r12
  4106cd:	pop    rdi
  4106ce:	pop    rsi
  4106cf:	ret

00000000004106d0 <__swc_fn_4fa09e82_000089_386582f3>:
  4106d0:	push   rbp
  4106d1:	push   rbx
  4106d2:	push   rsi
  4106d3:	push   rdi
  4106d4:	push   r12
  4106d6:	push   r13
  4106d8:	push   r14
  4106da:	push   r15
  4106dc:	sub    rsp,0x38
  4106e0:	mov    rbp,rsp
  4106e3:	mov    rbx,r11
  4106e6:	mov    rsi,rdx
  4106e9:	mov    rdi,r8
  4106ec:	mov    r12,r9
  4106ef:	mov    QWORD PTR [rsp+0x18],r9
  4106f4:	mov    r13,r10
  4106f7:	movzx  r14d,BYTE PTR [rbp+0x80]
  4106ff:	movzx  r15d,BYTE PTR [rbp+0x88]
  410707:	test   r11,r11
  41070a:	je     410710 <__swc_fn_4fa09e82_000089_386582f3+0x40>
  41070c:	xor    eax,eax
  41070e:	mov    BYTE PTR [rbx],al
  410710:	test   r12,r12
  410713:	je     41071e <__swc_fn_4fa09e82_000089_386582f3+0x4e>
  410715:	mov    QWORD PTR [r12+0x8],0x0
  41071e:	test   rcx,rcx
  410721:	je     410728 <__swc_fn_4fa09e82_000089_386582f3+0x58>
  410723:	test   rsi,rsi
  410726:	jne    41073b <__swc_fn_4fa09e82_000089_386582f3+0x6b>
  410728:	xor    eax,eax
  41072a:	add    rsp,0x38
  41072e:	pop    r15
  410730:	pop    r14
  410732:	pop    r13
  410734:	pop    r12
  410736:	pop    rdi
  410737:	pop    rsi
  410738:	pop    rbx
  410739:	pop    rbp
  41073a:	ret
  41073b:	call   40dbe0 <__swc_fn_4fa09e82_000082_754dcd57>
  410740:	mov    r12,rax
  410743:	mov    al,r15b
  410746:	test   r15b,r15b
  410749:	jne    410759 <__swc_fn_4fa09e82_000089_386582f3+0x89>
  41074b:	mov    eax,DWORD PTR [r12+0x28]
  410750:	and    eax,0x10000
  410756:	setne  al
  410759:	lea    r15,[rsp+0x8]
  41075e:	mov    QWORD PTR [rsp+0x20],r15
  410763:	rex mov BYTE PTR [rsp+0x8],al
  410768:	test   DWORD PTR [rsi+0x28],0x400000
  41076f:	je     4107a7 <__swc_fn_4fa09e82_000089_386582f3+0xd7>
  410771:	test   rsi,rsi
  410774:	je     410794 <__swc_fn_4fa09e82_000089_386582f3+0xc4>
  410776:	mov    rax,QWORD PTR [rsi+0x38]
  41077a:	cmp    QWORD PTR [rax+0x10],rsi
  41077e:	jne    410794 <__swc_fn_4fa09e82_000089_386582f3+0xc4>
  410780:	rex mov al,BYTE PTR [rsp+0x8]
  410785:	test   al,al
  410787:	sete   al
  41078a:	test   r14b,r14b
  41078d:	sete   cl
  410790:	test   al,cl
  410792:	je     4107a7 <__swc_fn_4fa09e82_000089_386582f3+0xd7>
  410794:	xor    eax,eax
  410796:	add    rsp,0x38
  41079a:	pop    r15
  41079c:	pop    r14
  41079e:	pop    r13
  4107a0:	pop    r12
  4107a2:	pop    rdi
  4107a3:	pop    rsi
  4107a4:	pop    rbx
  4107a5:	pop    rbp
  4107a6:	ret
  4107a7:	mov    r15,r12
  4107aa:	test   r14b,r14b
  4107ad:	jne    4107c4 <__swc_fn_4fa09e82_000089_386582f3+0xf4>
  4107af:	cmp    BYTE PTR [r12+0x2c],0x6
  4107b5:	jne    4107c4 <__swc_fn_4fa09e82_000089_386582f3+0xf4>
  4107b7:	mov    rcx,QWORD PTR [r12+0x40]
  4107bc:	call   40dbe0 <__swc_fn_4fa09e82_000082_754dcd57>
  4107c1:	mov    r15,rax
  4107c4:	test   r14b,r14b
  4107c7:	je     4107cd <__swc_fn_4fa09e82_000089_386582f3+0xfd>
  4107c9:	mov    r15,QWORD PTR [r15+0x30]
  4107cd:	mov    rcx,rsi
  4107d0:	call   40dbe0 <__swc_fn_4fa09e82_000082_754dcd57>
  4107d5:	mov    rsi,rax
  4107d8:	rex cmp BYTE PTR [rsi+0x2c],0x6
  4107dd:	je     410814 <__swc_fn_4fa09e82_000089_386582f3+0x144>
  4107df:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4107e4:	je     410814 <__swc_fn_4fa09e82_000089_386582f3+0x144>
  4107e6:	mov    eax,DWORD PTR [rsi+0x28]
  4107e9:	and    eax,0x10000
  4107ef:	je     410814 <__swc_fn_4fa09e82_000089_386582f3+0x144>
  4107f1:	rex mov al,BYTE PTR [rsp+0x8]
  4107f6:	test   al,al
  4107f8:	jne    41080d <__swc_fn_4fa09e82_000089_386582f3+0x13d>
  4107fa:	xor    eax,eax
  4107fc:	add    rsp,0x38
  410800:	pop    r15
  410802:	pop    r14
  410804:	pop    r13
  410806:	pop    r12
  410808:	pop    rdi
  410809:	pop    rsi
  41080a:	pop    rbx
  41080b:	pop    rbp
  41080c:	ret
  41080d:	mov    rax,QWORD PTR [rsi+0x30]
  410811:	mov    rsi,rax
  410814:	mov    r14b,r13b
  410817:	test   rbx,rbx
  41081a:	je     410850 <__swc_fn_4fa09e82_000089_386582f3+0x180>
  41081c:	cmp    BYTE PTR [r12+0x2c],0x6
  410822:	jne    410850 <__swc_fn_4fa09e82_000089_386582f3+0x180>
  410824:	lea    rdx,[rip+0x2955]        # 413180 <__swc_rdata_base_4fa09e82+0x70>
  41082b:	mov    rcx,rsi
  41082e:	xor    r8d,r8d
  410831:	call   4085a0 <__swc_fn_4fa09e82_000090_a2d50c23>
  410836:	test   al,al
  410838:	je     410850 <__swc_fn_4fa09e82_000089_386582f3+0x180>
  41083a:	mov    BYTE PTR [rbx],0x1
  41083d:	xor    eax,eax
  41083f:	add    rsp,0x38
  410843:	pop    r15
  410845:	pop    r14
  410847:	pop    r13
  410849:	pop    r12
  41084b:	pop    rdi
  41084c:	pop    rsi
  41084d:	pop    rbx
  41084e:	pop    rbp
  41084f:	ret
  410850:	test   rdi,rdi
  410853:	jne    41086d <__swc_fn_4fa09e82_000089_386582f3+0x19d>
  410855:	test   r13b,r13b
  410858:	jne    41086d <__swc_fn_4fa09e82_000089_386582f3+0x19d>
  41085a:	xor    eax,eax
  41085c:	add    rsp,0x38
  410860:	pop    r15
  410862:	pop    r14
  410864:	pop    r13
  410866:	pop    r12
  410868:	pop    rdi
  410869:	pop    rsi
  41086a:	pop    rbx
  41086b:	pop    rbp
  41086c:	ret
  41086d:	rex cmp BYTE PTR [rsi+0x2c],0x6
  410872:	jne    410928 <__swc_fn_4fa09e82_000089_386582f3+0x258>
  410878:	mov    rcx,r15
  41087b:	mov    rdx,rsi
  41087e:	xor    r8d,r8d
  410881:	call   4085a0 <__swc_fn_4fa09e82_000090_a2d50c23>
  410886:	test   al,al
  410888:	jne    410928 <__swc_fn_4fa09e82_000089_386582f3+0x258>
  41088e:	test   DWORD PTR [rsi+0x28],0x10000
  410895:	je     4108b3 <__swc_fn_4fa09e82_000089_386582f3+0x1e3>
  410897:	rex mov al,BYTE PTR [rsp+0x8]
  41089c:	test   al,al
  41089e:	jne    4108b3 <__swc_fn_4fa09e82_000089_386582f3+0x1e3>
  4108a0:	xor    eax,eax
  4108a2:	add    rsp,0x38
  4108a6:	pop    r15
  4108a8:	pop    r14
  4108aa:	pop    r13
  4108ac:	pop    r12
  4108ae:	pop    rdi
  4108af:	pop    rsi
  4108b0:	pop    rbx
  4108b1:	pop    rbp
  4108b2:	ret
  4108b3:	test   rdi,rdi
  4108b6:	jne    4108cb <__swc_fn_4fa09e82_000089_386582f3+0x1fb>
  4108b8:	xor    eax,eax
  4108ba:	add    rsp,0x38
  4108be:	pop    r15
  4108c0:	pop    r14
  4108c2:	pop    r13
  4108c4:	pop    r12
  4108c6:	pop    rdi
  4108c7:	pop    rsi
  4108c8:	pop    rbx
  4108c9:	pop    rbp
  4108ca:	ret
  4108cb:	mov    rcx,QWORD PTR [rsi+0x40]
  4108cf:	call   40dbe0 <__swc_fn_4fa09e82_000082_754dcd57>
  4108d4:	mov    rsi,rax
  4108d7:	mov    rax,QWORD PTR [rdi]
  4108da:	mov    rdi,rax
  4108dd:	test   rax,rax
  4108e0:	jne    410923 <__swc_fn_4fa09e82_000089_386582f3+0x253>
  4108e2:	test   rbx,rbx
  4108e5:	je     410923 <__swc_fn_4fa09e82_000089_386582f3+0x253>
  4108e7:	mov    rcx,r15
  4108ea:	mov    rdx,rsi
  4108ed:	xor    r8d,r8d
  4108f0:	call   4085a0 <__swc_fn_4fa09e82_000090_a2d50c23>
  4108f5:	mov    rcx,rax
  4108f8:	test   al,al
  4108fa:	jne    41091c <__swc_fn_4fa09e82_000089_386582f3+0x24c>
  4108fc:	mov    rcx,r15
  4108ff:	mov    rdx,rsi
  410902:	call   40dc20 <__swc_fn_4fa09e82_000085_1edf7c76>
  410907:	mov    rcx,rax
  41090a:	test   al,al
  41090c:	jne    41091c <__swc_fn_4fa09e82_000089_386582f3+0x24c>
  41090e:	mov    rcx,rsi
  410911:	mov    rdx,r15
  410914:	call   40dc20 <__swc_fn_4fa09e82_000085_1edf7c76>
  410919:	mov    rcx,rax
  41091c:	test   cl,cl
  41091e:	setne  al
  410921:	mov    BYTE PTR [rbx],al
  410923:	xor    eax,eax
  410925:	mov    r14b,al
  410928:	test   rdi,rdi
  41092b:	jne    410945 <__swc_fn_4fa09e82_000089_386582f3+0x275>
  41092d:	test   r14b,r14b
  410930:	jne    410945 <__swc_fn_4fa09e82_000089_386582f3+0x275>
  410932:	xor    eax,eax
  410934:	add    rsp,0x38
  410938:	pop    r15
  41093a:	pop    r14
  41093c:	pop    r13
  41093e:	pop    r12
  410940:	pop    rdi
  410941:	pop    rsi
  410942:	pop    rbx
  410943:	pop    rbp
  410944:	ret
  410945:	rex cmp BYTE PTR [rsi+0x2c],0x12
  41094a:	je     410956 <__swc_fn_4fa09e82_000089_386582f3+0x286>
  41094c:	mov    r12,QWORD PTR [rsp+0x18]
  410951:	jmp    4109de <__swc_fn_4fa09e82_000089_386582f3+0x30e>
  410956:	mov    r12,QWORD PTR [rsp+0x18]
  41095b:	test   r12,r12
  41095e:	jne    410972 <__swc_fn_4fa09e82_000089_386582f3+0x2a2>
  410960:	mov    rcx,r15
  410963:	mov    rdx,rsi
  410966:	xor    r8d,r8d
  410969:	call   4085a0 <__swc_fn_4fa09e82_000090_a2d50c23>
  41096e:	test   al,al
  410970:	jne    4109de <__swc_fn_4fa09e82_000089_386582f3+0x30e>
  410972:	test   DWORD PTR [rsi+0x28],0x10000
  410979:	je     410997 <__swc_fn_4fa09e82_000089_386582f3+0x2c7>
  41097b:	rex mov al,BYTE PTR [rsp+0x8]
  410980:	test   al,al
  410982:	jne    410997 <__swc_fn_4fa09e82_000089_386582f3+0x2c7>
  410984:	xor    eax,eax
  410986:	add    rsp,0x38
  41098a:	pop    r15
  41098c:	pop    r14
  41098e:	pop    r13
  410990:	pop    r12
  410992:	pop    rdi
  410993:	pop    rsi
  410994:	pop    rbx
  410995:	pop    rbp
  410996:	ret
  410997:	test   rdi,rdi
  41099a:	jne    4109af <__swc_fn_4fa09e82_000089_386582f3+0x2df>
  41099c:	xor    eax,eax
  41099e:	add    rsp,0x38
  4109a2:	pop    r15
  4109a4:	pop    r14
  4109a6:	pop    r13
  4109a8:	pop    r12
  4109aa:	pop    rdi
  4109ab:	pop    rsi
  4109ac:	pop    rbx
  4109ad:	pop    rbp
  4109ae:	ret
  4109af:	cmp    QWORD PTR [rdi+0x8],0x0
  4109b4:	jne    4109c9 <__swc_fn_4fa09e82_000089_386582f3+0x2f9>
  4109b6:	xor    eax,eax
  4109b8:	add    rsp,0x38
  4109bc:	pop    r15
  4109be:	pop    r14
  4109c0:	pop    r13
  4109c2:	pop    r12
  4109c4:	pop    rdi
  4109c5:	pop    rsi
  4109c6:	pop    rbx
  4109c7:	pop    rbp
  4109c8:	ret
  4109c9:	mov    rax,QWORD PTR [rdi+0x8]
  4109cd:	mov    rax,QWORD PTR [rax]
  4109d0:	mov    rsi,rax
  4109d3:	mov    rdi,QWORD PTR [rdi]
  4109d6:	mov    eax,0x1
  4109db:	mov    r14b,al
  4109de:	test   rdi,rdi
  4109e1:	mov    rbx,QWORD PTR [rsp+0x20]
  4109e6:	jne    410a30 <__swc_fn_4fa09e82_000089_386582f3+0x360>
  4109e8:	test   r14b,r14b
  4109eb:	je     410a1d <__swc_fn_4fa09e82_000089_386582f3+0x34d>
  4109ed:	test   r12,r12
  4109f0:	je     410a1d <__swc_fn_4fa09e82_000089_386582f3+0x34d>
  4109f2:	mov    rcx,r15
  4109f5:	mov    rdx,rsi
  4109f8:	xor    r8d,r8d
  4109fb:	mov    r9,r12
  4109fe:	mov    rbx,QWORD PTR [rsp+0x20]
  410a03:	movzx  r10d,BYTE PTR [rbx]
  410a07:	call   4105c0 <__swc_fn_4fa09e82_000083_31b501f2>
  410a0c:	add    rsp,0x38
  410a10:	pop    r15
  410a12:	pop    r14
  410a14:	pop    r13
  410a16:	pop    r12
  410a18:	pop    rdi
  410a19:	pop    rsi
  410a1a:	pop    rbx
  410a1b:	pop    rbp
  410a1c:	ret
  410a1d:	xor    eax,eax
  410a1f:	add    rsp,0x38
  410a23:	pop    r15
  410a25:	pop    r14
  410a27:	pop    r13
  410a29:	pop    r12
  410a2b:	pop    rdi
  410a2c:	pop    rsi
  410a2d:	pop    rbx
  410a2e:	pop    rbp
  410a2f:	ret
  410a30:	mov    r13,rsi
  410a33:	mov    QWORD PTR [rsp+0x28],rdi
  410a38:	cmp    BYTE PTR [r15+0x2c],0xe
  410a3d:	sete   al
  410a40:	mov    r14b,al
  410a43:	jne    410a57 <__swc_fn_4fa09e82_000089_386582f3+0x387>
  410a45:	mov    rcx,rsi
  410a48:	mov    rdx,r15
  410a4b:	call   40dc20 <__swc_fn_4fa09e82_000085_1edf7c76>
  410a50:	mov    r14b,al
  410a53:	test   al,al
  410a55:	jne    410a8c <__swc_fn_4fa09e82_000089_386582f3+0x3bc>
  410a57:	cmp    BYTE PTR [r15+0x2c],0x12
  410a5c:	je     410a8c <__swc_fn_4fa09e82_000089_386582f3+0x3bc>
  410a5e:	mov    rcx,r15
  410a61:	mov    rdx,rsi
  410a64:	mov    r8,rdi
  410a67:	mov    r9,r12
  410a6a:	mov    rax,rbx
  410a6d:	movzx  r10d,BYTE PTR [rax]
  410a71:	call   4105c0 <__swc_fn_4fa09e82_000083_31b501f2>
  410a76:	test   rax,rax
  410a79:	je     410a8c <__swc_fn_4fa09e82_000089_386582f3+0x3bc>
  410a7b:	add    rsp,0x38
  410a7f:	pop    r15
  410a81:	pop    r14
  410a83:	pop    r13
  410a85:	pop    r12
  410a87:	pop    rdi
  410a88:	pop    rsi
  410a89:	pop    rbx
  410a8a:	pop    rbp
  410a8b:	ret
  410a8c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  410a91:	jne    410ab0 <__swc_fn_4fa09e82_000089_386582f3+0x3e0>
  410a93:	mov    rax,QWORD PTR [rsi+0xd8]
  410a9a:	test   rax,rax
  410a9d:	je     410ab0 <__swc_fn_4fa09e82_000089_386582f3+0x3e0>
  410a9f:	add    rdi,QWORD PTR [rax+0x8]
  410aa3:	mov    rax,QWORD PTR [rdi]
  410aa6:	sub    rdi,QWORD PTR [rax+0x8]
  410aaa:	mov    rax,QWORD PTR [rax]
  410aad:	mov    rsi,rax
  410ab0:	test   r14b,r14b
  410ab3:	je     410adf <__swc_fn_4fa09e82_000089_386582f3+0x40f>
  410ab5:	mov    rcx,r15
  410ab8:	mov    rdx,rsi
  410abb:	mov    r8,rdi
  410abe:	mov    r9,r13
  410ac1:	mov    r14,QWORD PTR [rsp+0x28]
  410ac6:	mov    r10,r14
  410ac9:	call   408480 <__swc_fn_4fa09e82_000087_ea575bb3>
  410ace:	add    rsp,0x38
  410ad2:	pop    r15
  410ad4:	pop    r14
  410ad6:	pop    r13
  410ad8:	pop    r12
  410ada:	pop    rdi
  410adb:	pop    rsi
  410adc:	pop    rbx
  410add:	pop    rbp
  410ade:	ret
  410adf:	mov    rcx,r15
  410ae2:	mov    rdx,rsi
  410ae5:	mov    r8,rdi
  410ae8:	mov    r9,r12
  410aeb:	movzx  r10d,BYTE PTR [rbx]
  410aef:	call   4105c0 <__swc_fn_4fa09e82_000083_31b501f2>
  410af4:	add    rsp,0x38
  410af8:	pop    r15
  410afa:	pop    r14
  410afc:	pop    r13
  410afe:	pop    r12
  410b00:	pop    rdi
  410b01:	pop    rsi
  410b02:	pop    rbx
  410b03:	pop    rbp
  410b04:	ret
	...

0000000000410b10 <__swc_fn_4fa09e82_000092_8252f8c0>:
  410b10:	push   rbx
  410b11:	push   rsi
  410b12:	sub    rsp,0x18
  410b16:	mov    rbx,rcx
  410b19:	mov    rcx,QWORD PTR [rip+0x16220]        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  410b20:	test   rcx,rcx
  410b23:	jne    410b35 <__swc_fn_4fa09e82_000092_8252f8c0+0x25>
  410b25:	call   40f0f0 <__swc_fn_4fa09e82_000166_cf398896>
  410b2a:	lea    rcx,[rax+0x1]
  410b2e:	mov    QWORD PTR [rip+0x1620b],rcx        # 426d40 <__swc_bss_base_4fa09e82+0x2d00>
  410b35:	dec    rcx
  410b38:	call   40b6c0 <__swc_fn_4fa09e82_000168_fce60b2b>
  410b3d:	mov    rsi,rax
  410b40:	mov    rax,QWORD PTR [rsi+0x8]
  410b44:	test   rax,rax
  410b47:	jne    410b97 <__swc_fn_4fa09e82_000092_8252f8c0+0x87>
  410b49:	call   40dd10 <__swc_fn_4fa09e82_000091_3d2f5a0d>
  410b4e:	test   al,al
  410b50:	jne    410b97 <__swc_fn_4fa09e82_000092_8252f8c0+0x87>
  410b52:	lea    rdx,[rip+0x136e7]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  410b59:	mov    rcx,rdx
  410b5c:	call   407740 <__swc_fn_4fa09e82_000036_8d895ba1>
  410b61:	test   al,al
  410b63:	jne    410b74 <__swc_fn_4fa09e82_000092_8252f8c0+0x64>
  410b65:	mov    rcx,rdx
  410b68:	call   40c600 <__swc_fn_4fa09e82_000034_25f19556>
  410b6d:	lea    rdx,[rip+0x136cc]        # 424240 <__swc_bss_base_4fa09e82+0x200>
  410b74:	mov    QWORD PTR [rsp+0x8],rdx
  410b79:	lea    rax,[rip+0x25d0]        # 413150 <__swc_rdata_base_4fa09e82+0x40>
  410b80:	mov    QWORD PTR [rsp+0x10],rax
  410b85:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  410b8b:	vmovups XMMWORD PTR [rsi],xmm0
  410b8f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  410b97:	vmovups xmm0,XMMWORD PTR [rsi]
  410b9b:	vmovups XMMWORD PTR [rbx],xmm0
  410b9f:	mov    rax,rbx
  410ba2:	add    rsp,0x18
  410ba6:	pop    rsi
  410ba7:	pop    rbx
  410ba8:	ret
  410ba9:	add    BYTE PTR [rax],al
  410bab:	add    BYTE PTR [rax],al
  410bad:	add    BYTE PTR [rax],al
	...

0000000000410bb0 <__swc_fn_4fa09e82_000095_337e587a>:
  410bb0:	sub    rsp,0x8
  410bb4:	call   40e280 <__swc_fn_4fa09e82_000118_86a7fb9e>
  410bb9:	add    rsp,0x8
  410bbd:	ret
	...

0000000000410bc0 <__swc_fn_4fa09e82_000098_00f01091>:
  410bc0:	push   rbx
  410bc1:	push   rsi
  410bc2:	sub    rsp,0x28
  410bc6:	mov    rbx,rcx
  410bc9:	xor    esi,esi
  410bcb:	jmp    410be0 <__swc_fn_4fa09e82_000098_00f01091+0x20>
  410bcd:	nop    DWORD PTR [rax]
  410bd0:	mov    QWORD PTR [rbx+0x28],rsi
  410bd4:	mov    rsi,rbx
  410bd7:	mov    rbx,rax
  410bda:	nop    WORD PTR [rax+rax*1+0x0]
  410be0:	test   rbx,rbx
  410be3:	je     410c43 <__swc_fn_4fa09e82_000098_00f01091+0x83>
  410be5:	mov    rcx,rbx
  410be8:	mov    edx,0x1
  410bed:	call   408200 <__swc_fn_4fa09e82_000078_a120bd2b>
  410bf2:	cmp    rax,0x1
  410bf6:	jne    410c43 <__swc_fn_4fa09e82_000098_00f01091+0x83>
  410bf8:	mov    r10,QWORD PTR [rbx+0x18]
  410bfc:	mov    rcx,r10
  410bff:	mov    edx,0x1
  410c04:	call   408200 <__swc_fn_4fa09e82_000078_a120bd2b>
  410c09:	cmp    rax,0x1
  410c0d:	jne    410c1c <__swc_fn_4fa09e82_000098_00f01091+0x5c>
  410c0f:	mov    rcx,r10
  410c12:	call   40deb0 <__swc_fn_4fa09e82_000097_4c97e0db>
  410c17:	test   rax,rax
  410c1a:	jne    410bd0 <__swc_fn_4fa09e82_000098_00f01091+0x10>
  410c1c:	mov    rax,QWORD PTR [rbx+0x20]
  410c20:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  410c25:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410c2b:	lea    rcx,[rsp+0x8]
  410c30:	mov    rdx,rbx
  410c33:	mov    r8d,0x30
  410c39:	mov    rbx,rax
  410c3c:	call   408960 <__swc_fn_4fa09e82_000096_ad982b35>
  410c41:	jmp    410be0 <__swc_fn_4fa09e82_000098_00f01091+0x20>
  410c43:	test   rsi,rsi
  410c46:	jne    410c4f <__swc_fn_4fa09e82_000098_00f01091+0x8f>
  410c48:	add    rsp,0x28
  410c4c:	pop    rsi
  410c4d:	pop    rbx
  410c4e:	ret
  410c4f:	mov    rax,rsi
  410c52:	mov    rsi,QWORD PTR [rsi+0x28]
  410c56:	mov    rbx,QWORD PTR [rax+0x20]
  410c5a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  410c5f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  410c65:	lea    rcx,[rsp+0x18]
  410c6a:	mov    rdx,rax
  410c6d:	mov    r8d,0x30
  410c73:	call   408960 <__swc_fn_4fa09e82_000096_ad982b35>
  410c78:	jmp    410be0 <__swc_fn_4fa09e82_000098_00f01091+0x20>
  410c7d:	add    BYTE PTR [rax],al
	...

0000000000410c80 <__swc_fn_4fa09e82_000101_eab3874f>:
  410c80:	push   rbx
  410c81:	push   rsi
  410c82:	push   rdi
  410c83:	push   r12
  410c85:	push   r13
  410c87:	sub    rsp,0x20
  410c8b:	mov    rbx,rcx
  410c8e:	lea    rsi,[rcx+0x6f8]
  410c95:	mov    edi,0x4
  410c9a:	mov    r12,rsi
  410c9d:	test   rdi,rdi
  410ca0:	je     410cea <__swc_fn_4fa09e82_000101_eab3874f+0x6a>
  410ca2:	cs nop WORD PTR [rax+rax*1+0x0]
  410cac:	nop    DWORD PTR [rax+0x0]
  410cb0:	mov    rcx,QWORD PTR [r12+0x10]
  410cb5:	mov    QWORD PTR [r12+0x10],0x0
  410cbe:	vxorps xmm0,xmm0,xmm0
  410cc2:	vmovups XMMWORD PTR [r12],xmm0
  410cc8:	vmovups XMMWORD PTR [r12+0x28],xmm0
  410ccf:	mov    DWORD PTR [r12+0x20],0x0
  410cd8:	call   4089c0 <__swc_fn_4fa09e82_000099_b4c6da83>
  410cdd:	add    r12,0x90
  410ce4:	sub    rdi,0x1
  410ce8:	jne    410cb0 <__swc_fn_4fa09e82_000101_eab3874f+0x30>
  410cea:	mov    rax,QWORD PTR [rbx+0x938]
  410cf1:	mov    rdi,rax
  410cf4:	test   rdi,rdi
  410cf7:	je     410d51 <__swc_fn_4fa09e82_000101_eab3874f+0xd1>
  410cf9:	nop    DWORD PTR [rax+0x0]
  410d00:	mov    r12d,0x10
  410d06:	lea    r13,[rdi+0x18]
  410d0a:	test   r12,r12
  410d0d:	je     410d46 <__swc_fn_4fa09e82_000101_eab3874f+0xc6>
  410d0f:	nop
  410d10:	mov    rcx,QWORD PTR [r13+0x10]
  410d14:	mov    QWORD PTR [r13+0x10],0x0
  410d1c:	vxorps xmm0,xmm0,xmm0
  410d20:	vmovups XMMWORD PTR [r13+0x0],xmm0
  410d26:	vmovups XMMWORD PTR [r13+0x28],xmm0
  410d2c:	mov    DWORD PTR [r13+0x20],0x0
  410d34:	call   4089c0 <__swc_fn_4fa09e82_000099_b4c6da83>
  410d39:	add    r13,0x90
  410d40:	sub    r12,0x1
  410d44:	jne    410d10 <__swc_fn_4fa09e82_000101_eab3874f+0x90>
  410d46:	mov    rax,QWORD PTR [rdi]
  410d49:	mov    rdi,rax
  410d4c:	test   rax,rax
  410d4f:	jne    410d00 <__swc_fn_4fa09e82_000101_eab3874f+0x80>
  410d51:	vxorps xmm0,xmm0,xmm0
  410d55:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  410d5d:	mov    DWORD PTR [rbx+0x9b0],0x0
  410d67:	mov    DWORD PTR [rbx+0x9a8],0x0
  410d71:	mov    edi,0x4
  410d76:	mov    r12,rsi
  410d79:	lea    rsi,[rsi+0x38]
  410d7d:	test   rdi,rdi
  410d80:	je     410dac <__swc_fn_4fa09e82_000101_eab3874f+0x12c>
  410d82:	cs nop WORD PTR [rax+rax*1+0x0]
  410d8c:	nop    DWORD PTR [rax+0x0]
  410d90:	mov    rcx,rsi
  410d93:	call   411c60 <__swc_fn_4fa09e82_000158_232ffa22>
  410d98:	add    rsi,0x90
  410d9f:	add    r12,0x90
  410da6:	sub    rdi,0x1
  410daa:	jne    410d90 <__swc_fn_4fa09e82_000101_eab3874f+0x110>
  410dac:	mov    rax,QWORD PTR [rbx+0x938]
  410db3:	mov    rdi,rax
  410db6:	mov    QWORD PTR [rbx+0x938],0x0
  410dc1:	test   rdi,rdi
  410dc4:	je     410e35 <__swc_fn_4fa09e82_000101_eab3874f+0x1b5>
  410dca:	nop    WORD PTR [rax+rax*1+0x0]
  410dd0:	mov    esi,0x10
  410dd5:	lea    r12,[rdi+0x18]
  410dd9:	lea    r13,[rdi+0x50]
  410ddd:	test   rsi,rsi
  410de0:	je     410e0c <__swc_fn_4fa09e82_000101_eab3874f+0x18c>
  410de2:	cs nop WORD PTR [rax+rax*1+0x0]
  410dec:	nop    DWORD PTR [rax+0x0]
  410df0:	mov    rcx,r13
  410df3:	call   411c60 <__swc_fn_4fa09e82_000158_232ffa22>
  410df8:	add    r13,0x90
  410dff:	add    r12,0x90
  410e06:	sub    rsi,0x1
  410e0a:	jne    410df0 <__swc_fn_4fa09e82_000101_eab3874f+0x170>
  410e0c:	mov    rax,QWORD PTR [rdi]
  410e0f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  410e14:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410e1a:	lea    rcx,[rsp+0x8]
  410e1f:	mov    rdx,rdi
  410e22:	mov    r8d,0x918
  410e28:	mov    rdi,rax
  410e2b:	call   408960 <__swc_fn_4fa09e82_000096_ad982b35>
  410e30:	test   rdi,rdi
  410e33:	jne    410dd0 <__swc_fn_4fa09e82_000101_eab3874f+0x150>
  410e35:	lea    rcx,[rbx+0x68]
  410e39:	call   411c60 <__swc_fn_4fa09e82_000158_232ffa22>
  410e3e:	add    rsp,0x20
  410e42:	pop    r13
  410e44:	pop    r12
  410e46:	pop    rdi
  410e47:	pop    rsi
  410e48:	pop    rbx
  410e49:	ret
  410e4a:	add    BYTE PTR [rax],al
  410e4c:	add    BYTE PTR [rax],al
	...

0000000000410e50 <__swc_fn_4fa09e82_000104_5589fdbd>:
  410e50:	xor    eax,eax
  410e52:	cs nop WORD PTR [rax+rax*1+0x0]
  410e5c:	nop    DWORD PTR [rax+0x0]
  410e60:	mov    r9,r8
  410e63:	sub    r9,rax
  410e66:	cmp    r9,0x40
  410e6a:	jb     410ea8 <__swc_fn_4fa09e82_000104_5589fdbd+0x58>
  410e6c:	lea    r9,[rcx+rax*1]
  410e70:	lea    r10,[rdx+rax*1]
  410e74:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  410e7a:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  410e80:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  410e86:	vmovups xmm3,XMMWORD PTR [r10]
  410e8b:	vmovups XMMWORD PTR [r9],xmm3
  410e90:	vmovups XMMWORD PTR [r9+0x10],xmm0
  410e96:	vmovups XMMWORD PTR [r9+0x20],xmm1
  410e9c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  410ea2:	lea    rax,[rax+0x40]
  410ea6:	jmp    410e60 <__swc_fn_4fa09e82_000104_5589fdbd+0x10>
  410ea8:	nop    DWORD PTR [rax+rax*1+0x0]
  410eb0:	mov    r9,r8
  410eb3:	sub    r9,rax
  410eb6:	cmp    r9,0x10
  410eba:	jb     410ed4 <__swc_fn_4fa09e82_000104_5589fdbd+0x84>
  410ebc:	lea    r9,[rdx+rax*1]
  410ec0:	lea    r10,[rcx+rax*1]
  410ec4:	vmovups xmm0,XMMWORD PTR [r9]
  410ec9:	vmovups XMMWORD PTR [r10],xmm0
  410ece:	lea    rax,[rax+0x10]
  410ed2:	jmp    410eb0 <__swc_fn_4fa09e82_000104_5589fdbd+0x60>
  410ed4:	cs nop WORD PTR [rax+rax*1+0x0]
  410ede:	xchg   ax,ax
  410ee0:	mov    r9,r8
  410ee3:	sub    r9,rax
  410ee6:	cmp    r9,0x8
  410eea:	jb     410efd <__swc_fn_4fa09e82_000104_5589fdbd+0xad>
  410eec:	lea    r9,[rcx+rax*1]
  410ef0:	mov    r10,QWORD PTR [rdx+rax*1]
  410ef4:	mov    QWORD PTR [r9],r10
  410ef7:	lea    rax,[rax+0x8]
  410efb:	jmp    410ee0 <__swc_fn_4fa09e82_000104_5589fdbd+0x90>
  410efd:	cmp    rax,r8
  410f00:	jae    410f20 <__swc_fn_4fa09e82_000104_5589fdbd+0xd0>
  410f02:	cs nop WORD PTR [rax+rax*1+0x0]
  410f0c:	nop    DWORD PTR [rax+0x0]
  410f10:	mov    r9b,BYTE PTR [rdx+rax*1]
  410f14:	mov    BYTE PTR [rcx+rax*1],r9b
  410f18:	inc    rax
  410f1b:	cmp    rax,r8
  410f1e:	jb     410f10 <__swc_fn_4fa09e82_000104_5589fdbd+0xc0>
  410f20:	ret
	...

0000000000410f30 <__swc_fn_4fa09e82_000107_ed4b1681>:
  410f30:	test   r8,r8
  410f33:	jne    410f38 <__swc_fn_4fa09e82_000107_ed4b1681+0x8>
  410f35:	xor    eax,eax
  410f37:	ret
  410f38:	xor    eax,eax
  410f3a:	nop    WORD PTR [rax+rax*1+0x0]
  410f40:	mov    r9,r8
  410f43:	sub    r9,rax
  410f46:	cmp    r9,0x10
  410f4a:	jb     410f94 <__swc_fn_4fa09e82_000107_ed4b1681+0x64>
  410f4c:	lea    r9,[rcx+rax*1]
  410f50:	lea    r10,[rdx+rax*1]
  410f54:	vmovups xmm0,XMMWORD PTR [r10]
  410f59:	vmovups xmm1,XMMWORD PTR [r9]
  410f5e:	vpcmpeqb xmm0,xmm1,xmm0
  410f62:	vpmovmskb r9d,xmm0
  410f66:	cmp    r9d,0xffff
  410f6d:	je     410f8e <__swc_fn_4fa09e82_000107_ed4b1681+0x5e>
  410f6f:	not    r9d
  410f72:	xor    r8d,r8d
  410f75:	movzx  r9d,r9w
  410f79:	tzcnt  r8d,r9d
  410f7e:	add    rax,r8
  410f81:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410f85:	movzx  eax,BYTE PTR [rdx+rax*1]
  410f89:	sub    ecx,eax
  410f8b:	mov    eax,ecx
  410f8d:	ret
  410f8e:	lea    rax,[rax+0x10]
  410f92:	jmp    410f40 <__swc_fn_4fa09e82_000107_ed4b1681+0x10>
  410f94:	cmp    r9,0x8
  410f98:	jb     41100b <__swc_fn_4fa09e82_000107_ed4b1681+0xdb>
  410f9a:	lea    r9,[rcx+rax*1]
  410f9e:	lea    r10,[rdx+rax*1]
  410fa2:	mov    r9,QWORD PTR [r9]
  410fa5:	xor    r9,QWORD PTR [r10]
  410fa8:	test   r9,r9
  410fab:	je     410fc9 <__swc_fn_4fa09e82_000107_ed4b1681+0x99>
  410fad:	xor    r8d,r8d
  410fb0:	tzcnt  r8,r9
  410fb5:	shr    r8,0x3
  410fb9:	add    rax,r8
  410fbc:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410fc0:	movzx  eax,BYTE PTR [rdx+rax*1]
  410fc4:	sub    ecx,eax
  410fc6:	mov    eax,ecx
  410fc8:	ret
  410fc9:	lea    rax,[rax+0x8]
  410fcd:	cmp    rax,r8
  410fd0:	jne    410fd5 <__swc_fn_4fa09e82_000107_ed4b1681+0xa5>
  410fd2:	xor    eax,eax
  410fd4:	ret
  410fd5:	lea    rax,[r8-0x8]
  410fd9:	lea    r8,[rcx+rax*1]
  410fdd:	lea    r9,[rdx+rax*1]
  410fe1:	mov    r8,QWORD PTR [r8]
  410fe4:	xor    r8,QWORD PTR [r9]
  410fe7:	test   r8,r8
  410fea:	je     411008 <__swc_fn_4fa09e82_000107_ed4b1681+0xd8>
  410fec:	xor    r9d,r9d
  410fef:	tzcnt  r9,r8
  410ff4:	shr    r9,0x3
  410ff8:	add    rax,r9
  410ffb:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410fff:	movzx  eax,BYTE PTR [rdx+rax*1]
  411003:	sub    ecx,eax
  411005:	mov    eax,ecx
  411007:	ret
  411008:	xor    eax,eax
  41100a:	ret
  41100b:	cmp    r9,0x4
  41100f:	jb     411082 <__swc_fn_4fa09e82_000107_ed4b1681+0x152>
  411011:	lea    r9,[rcx+rax*1]
  411015:	lea    r10,[rdx+rax*1]
  411019:	mov    r9d,DWORD PTR [r9]
  41101c:	xor    r9d,DWORD PTR [r10]
  41101f:	test   r9d,r9d
  411022:	je     411040 <__swc_fn_4fa09e82_000107_ed4b1681+0x110>
  411024:	xor    r8d,r8d
  411027:	tzcnt  r8,r9
  41102c:	shr    r8,0x3
  411030:	add    rax,r8
  411033:	movzx  ecx,BYTE PTR [rcx+rax*1]
  411037:	movzx  eax,BYTE PTR [rdx+rax*1]
  41103b:	sub    ecx,eax
  41103d:	mov    eax,ecx
  41103f:	ret
  411040:	lea    rax,[rax+0x4]
  411044:	cmp    rax,r8
  411047:	jne    41104c <__swc_fn_4fa09e82_000107_ed4b1681+0x11c>
  411049:	xor    eax,eax
  41104b:	ret
  41104c:	lea    rax,[r8-0x4]
  411050:	lea    r8,[rcx+rax*1]
  411054:	lea    r9,[rdx+rax*1]
  411058:	mov    r8d,DWORD PTR [r8]
  41105b:	xor    r8d,DWORD PTR [r9]
  41105e:	test   r8d,r8d
  411061:	je     41107f <__swc_fn_4fa09e82_000107_ed4b1681+0x14f>
  411063:	xor    r9d,r9d
  411066:	tzcnt  r9,r8
  41106b:	shr    r9,0x3
  41106f:	add    rax,r9
  411072:	movzx  ecx,BYTE PTR [rcx+rax*1]
  411076:	movzx  eax,BYTE PTR [rdx+rax*1]
  41107a:	sub    ecx,eax
  41107c:	mov    eax,ecx
  41107e:	ret
  41107f:	xor    eax,eax
  411081:	ret
  411082:	cmp    r9,0x2
  411086:	jb     4110d9 <__swc_fn_4fa09e82_000107_ed4b1681+0x1a9>
  411088:	lea    r9,[rcx+rax*1]
  41108c:	lea    r10,[rdx+rax*1]
  411090:	mov    r9w,WORD PTR [r9]
  411094:	xor    r9w,WORD PTR [r10]
  411098:	test   r9w,r9w
  41109c:	je     4110be <__swc_fn_4fa09e82_000107_ed4b1681+0x18e>
  41109e:	xor    r8d,r8d
  4110a1:	movzx  r9d,r9w
  4110a5:	tzcnt  r8,r9
  4110aa:	shr    r8,0x3
  4110ae:	add    rax,r8
  4110b1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  4110b5:	movzx  eax,BYTE PTR [rdx+rax*1]
  4110b9:	sub    ecx,eax
  4110bb:	mov    eax,ecx
  4110bd:	ret
  4110be:	lea    rax,[rax+0x2]
  4110c2:	cmp    rax,r8
  4110c5:	jne    4110ca <__swc_fn_4fa09e82_000107_ed4b1681+0x19a>
  4110c7:	xor    eax,eax
  4110c9:	ret
  4110ca:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  4110d0:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  4110d6:	sub    eax,ecx
  4110d8:	ret
  4110d9:	test   r9,r9
  4110dc:	je     4110eb <__swc_fn_4fa09e82_000107_ed4b1681+0x1bb>
  4110de:	movzx  ecx,BYTE PTR [rcx+rax*1]
  4110e2:	movzx  eax,BYTE PTR [rdx+rax*1]
  4110e6:	sub    ecx,eax
  4110e8:	mov    eax,ecx
  4110ea:	ret
  4110eb:	xor    eax,eax
  4110ed:	ret
	...

00000000004110f0 <__swc_fn_4fa09e82_000110_8d425bd3>:
  4110f0:	push   r12
  4110f2:	push   r13
  4110f4:	push   r14
  4110f6:	push   rdi
  4110f7:	push   rsi
  4110f8:	push   r15
  4110fa:	sub    rsp,0xd8
  411101:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  411107:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  41110d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  411113:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  411119:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  41111f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  411128:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  411131:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  41113a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  411143:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  41114c:	mov    r12,rcx
  41114f:	test   rcx,rcx
  411152:	je     41116e <__swc_fn_4fa09e82_000110_8d425bd3+0x7e>
  411154:	mov    eax,r12d
  411157:	and    eax,0xfff
  41115d:	setne  al
  411160:	cmp    r12,0xffffffffffffefff
  411167:	seta   cl
  41116a:	or     al,cl
  41116c:	je     411175 <__swc_fn_4fa09e82_000110_8d425bd3+0x85>
  41116e:	xor    eax,eax
  411170:	jmp    41120b <__swc_fn_4fa09e82_000110_8d425bd3+0x11b>
  411175:	call   40e040 <__swc_fn_4fa09e82_000109_84af7666>
  41117a:	mov    r13,rax
  41117d:	test   rax,rax
  411180:	jne    411189 <__swc_fn_4fa09e82_000110_8d425bd3+0x99>
  411182:	xor    eax,eax
  411184:	jmp    41120b <__swc_fn_4fa09e82_000110_8d425bd3+0x11b>
  411189:	lea    r14,[r12+0x1000]
  411191:	xor    edi,edi
  411193:	mov    rsi,r14
  411196:	xor    edx,edx
  411198:	mov    ecx,0x22
  41119d:	mov    eax,0xffffffff
  4111a2:	movsxd r8,eax
  4111a5:	xor    r9d,r9d
  4111a8:	xor    eax,eax
  4111aa:	call   4070d0 <mmap@plt>
  4111af:	mov    r15,rax
  4111b2:	cmp    rax,0xffffffffffffffff
  4111b6:	jne    4111bc <__swc_fn_4fa09e82_000110_8d425bd3+0xcc>
  4111b8:	xor    eax,eax
  4111ba:	jmp    41120b <__swc_fn_4fa09e82_000110_8d425bd3+0x11b>
  4111bc:	mov    rdi,r15
  4111bf:	mov    esi,0x1000
  4111c4:	mov    edx,0x3
  4111c9:	xor    eax,eax
  4111cb:	call   407170 <mprotect@plt>
  4111d0:	test   eax,eax
  4111d2:	je     4111e5 <__swc_fn_4fa09e82_000110_8d425bd3+0xf5>
  4111d4:	mov    rdi,r15
  4111d7:	mov    rsi,r14
  4111da:	xor    eax,eax
  4111dc:	call   407160 <munmap@plt>
  4111e1:	xor    eax,eax
  4111e3:	jmp    41120b <__swc_fn_4fa09e82_000110_8d425bd3+0x11b>
  4111e5:	mov    QWORD PTR [r15+0x8],r12
  4111e9:	mov    rcx,r13
  4111ec:	call   411850 <__swc_fn_4fa09e82_000134_4b2af8da>
  4111f1:	mov    rax,QWORD PTR [r13+0x8]
  4111f5:	mov    QWORD PTR [r15],rax
  4111f8:	mov    QWORD PTR [r13+0x8],r15
  4111fc:	mov    rcx,r13
  4111ff:	call   409d80 <__swc_fn_4fa09e82_000135_29412410>
  411204:	lea    rax,[r15+0x1000]
  41120b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  411211:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  411217:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  41121d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  411223:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  411229:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  411232:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  41123b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  411244:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  41124d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  411256:	add    rsp,0xd8
  41125d:	pop    r15
  41125f:	pop    rsi
  411260:	pop    rdi
  411261:	pop    r14
  411263:	pop    r13
  411265:	pop    r12
  411267:	ret
	...

0000000000411270 <__swc_fn_4fa09e82_000113_759e9ceb>:
  411270:	push   rbx
  411271:	push   r12
  411273:	push   rdi
  411274:	push   rsi
  411275:	sub    rsp,0xa8
  41127c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  411282:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411288:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41128e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411294:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  41129a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4112a0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4112a6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4112ac:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4112b5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4112be:	mov    rbx,rdx
  4112c1:	mov    r12,rcx
  4112c4:	mov    rdi,rcx
  4112c7:	mov    rsi,rdx
  4112ca:	xor    edx,edx
  4112cc:	xor    eax,eax
  4112ce:	call   407170 <mprotect@plt>
  4112d3:	test   eax,eax
  4112d5:	jne    4112f9 <__swc_fn_4fa09e82_000113_759e9ceb+0x89>
  4112d7:	mov    rcx,r12
  4112da:	mov    rdx,rbx
  4112dd:	xor    al,al
  4112df:	mov    r8,rax
  4112e2:	call   409810 <__swc_fn_4fa09e82_000111_a808fe76>
  4112e7:	mov    rdi,r12
  4112ea:	mov    rsi,rbx
  4112ed:	mov    edx,0x4
  4112f2:	xor    eax,eax
  4112f4:	call   4071d0 <madvise@plt>
  4112f9:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4112ff:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411305:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41130b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411311:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411317:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  41131d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411323:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411329:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411332:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41133b:	add    rsp,0xa8
  411342:	pop    rsi
  411343:	pop    rdi
  411344:	pop    r12
  411346:	pop    rbx
  411347:	ret
	...

0000000000411350 <__swc_fn_4fa09e82_000116_1ba33335>:
  411350:	push   rsi
  411351:	push   rdi
  411352:	push   r12
  411354:	push   r13
  411356:	push   r14
  411358:	sub    rsp,0xe0
  41135f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  411365:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  41136b:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  411371:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  411377:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  41137d:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  411386:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  41138f:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  411398:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  4113a1:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  4113aa:	mov    rsi,rdx
  4113ad:	mov    rdi,rcx
  4113b0:	call   40e040 <__swc_fn_4fa09e82_000109_84af7666>
  4113b5:	mov    r12,rax
  4113b8:	test   rax,rax
  4113bb:	jne    4113c2 <__swc_fn_4fa09e82_000116_1ba33335+0x72>
  4113bd:	jmp    411436 <__swc_fn_4fa09e82_000116_1ba33335+0xe6>
  4113c2:	mov    rcx,r12
  4113c5:	call   411850 <__swc_fn_4fa09e82_000134_4b2af8da>
  4113ca:	lea    r13,[r12+0x8]
  4113cf:	mov    rax,QWORD PTR [r13+0x0]
  4113d3:	test   rax,rax
  4113d6:	je     41142e <__swc_fn_4fa09e82_000116_1ba33335+0xde>
  4113d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4113e0:	lea    rcx,[rax+0x1000]
  4113e7:	cmp    rcx,rdi
  4113ea:	jne    411422 <__swc_fn_4fa09e82_000116_1ba33335+0xd2>
  4113ec:	cmp    QWORD PTR [rax+0x8],rsi
  4113f0:	je     4113fc <__swc_fn_4fa09e82_000116_1ba33335+0xac>
  4113f2:	mov    rcx,r12
  4113f5:	call   409d80 <__swc_fn_4fa09e82_000135_29412410>
  4113fa:	jmp    411436 <__swc_fn_4fa09e82_000116_1ba33335+0xe6>
  4113fc:	mov    r14,QWORD PTR [rax]
  4113ff:	mov    rdi,rax
  411402:	lea    rsi,[rsi+0x1000]
  411409:	xor    eax,eax
  41140b:	call   407160 <munmap@plt>
  411410:	test   eax,eax
  411412:	jne    411418 <__swc_fn_4fa09e82_000116_1ba33335+0xc8>
  411414:	mov    QWORD PTR [r13+0x0],r14
  411418:	mov    rcx,r12
  41141b:	call   409d80 <__swc_fn_4fa09e82_000135_29412410>
  411420:	jmp    411436 <__swc_fn_4fa09e82_000116_1ba33335+0xe6>
  411422:	mov    r13,rax
  411425:	mov    rax,QWORD PTR [r13+0x0]
  411429:	test   rax,rax
  41142c:	jne    4113e0 <__swc_fn_4fa09e82_000116_1ba33335+0x90>
  41142e:	mov    rcx,r12
  411431:	call   409d80 <__swc_fn_4fa09e82_000135_29412410>
  411436:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  41143c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  411442:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  411448:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  41144e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  411454:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  41145d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  411466:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  41146f:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  411478:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  411481:	add    rsp,0xe0
  411488:	pop    r14
  41148a:	pop    r13
  41148c:	pop    r12
  41148e:	pop    rdi
  41148f:	pop    rsi
  411490:	ret
	...

00000000004114a0 <__swc_fn_4fa09e82_000119_7f430081>:
  4114a0:	push   rdi
  4114a1:	push   rsi
  4114a2:	sub    rsp,0xa8
  4114a9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4114af:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4114b5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4114bb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4114c1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4114c7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4114cd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4114d3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4114d9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4114e2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4114eb:	mov    rdi,0xfffffffffffffd66
  4114f2:	xor    eax,eax
  4114f4:	call   407180 <exit@plt>
  4114f9:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4114ff:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411505:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41150b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411511:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411517:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  41151d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411523:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411529:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411532:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41153b:	add    rsp,0xa8
  411542:	pop    rsi
  411543:	pop    rdi
  411544:	ret
	...

0000000000411560 <__swc_fn_4fa09e82_000122_12b4ed22>:
  411560:	push   rbx
  411561:	push   rsi
  411562:	push   rdi
  411563:	sub    rsp,0x30
  411567:	mov    rbx,rdx
  41156a:	mov    esi,ecx
  41156c:	test   ecx,ecx
  41156e:	je     411643 <__swc_fn_4fa09e82_000122_12b4ed22+0xe3>
  411574:	mov    rcx,rsi
  411577:	shl    rcx,0x4
  41157b:	call   40db50 <__swc_fn_4fa09e82_000079_34776ded>
  411580:	test   rax,rax
  411583:	je     411632 <__swc_fn_4fa09e82_000122_12b4ed22+0xd2>
  411589:	mov    rcx,rsi
  41158c:	xor    edx,edx
  41158e:	test   rsi,rsi
  411591:	jbe    411612 <__swc_fn_4fa09e82_000122_12b4ed22+0xb2>
  411597:	nop    WORD PTR [rax+rax*1+0x0]
  4115a0:	mov    r8d,edx
  4115a3:	mov    r9,QWORD PTR [rbx+r8*8]
  4115a7:	add    r8,r8
  4115aa:	lea    r8,[rax+r8*8]
  4115ae:	xor    r10d,r10d
  4115b1:	test   r9,r9
  4115b4:	je     4115f0 <__swc_fn_4fa09e82_000122_12b4ed22+0x90>
  4115b6:	mov    r11,r9
  4115b9:	mov    dil,BYTE PTR [r11]
  4115bc:	test   dil,dil
  4115bf:	je     4115f0 <__swc_fn_4fa09e82_000122_12b4ed22+0x90>
  4115c1:	cs nop WORD PTR [rax+rax*1+0x0]
  4115cb:	cs nop WORD PTR [rax+rax*1+0x0]
  4115d5:	cs nop WORD PTR [rax+rax*1+0x0]
  4115df:	nop
  4115e0:	add    r11,0x1
  4115e4:	add    r10,0x1
  4115e8:	mov    dil,BYTE PTR [r11]
  4115eb:	test   dil,dil
  4115ee:	jne    4115e0 <__swc_fn_4fa09e82_000122_12b4ed22+0x80>
  4115f0:	mov    QWORD PTR [rsp+0x18],r9
  4115f5:	mov    QWORD PTR [rsp+0x20],r10
  4115fa:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411600:	vmovups XMMWORD PTR [r8],xmm0
  411605:	add    rdx,0x1
  411609:	cmp    rdx,rcx
  41160c:	jb     4115a0 <__swc_fn_4fa09e82_000122_12b4ed22+0x40>
  411612:	lea    rcx,[rip+0x15737]        # 426d50 <__swc_bss_base_4fa09e82+0x2d10>
  411619:	mov    QWORD PTR [rsp+0x8],rax
  41161e:	mov    esi,esi
  411620:	mov    QWORD PTR [rsp+0x10],rsi
  411625:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  41162b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411630:	jmp    411643 <__swc_fn_4fa09e82_000122_12b4ed22+0xe3>
  411632:	lea    rcx,[rip+0x1ee7]        # 413520 <__swc_rdata_base_4fa09e82+0x410>
  411639:	call   4098c0 <__swc_fn_4fa09e82_000117_035d76a1>
  41163e:	call   4114a0 <__swc_fn_4fa09e82_000119_7f430081>
  411643:	add    rsp,0x30
  411647:	pop    rdi
  411648:	pop    rsi
  411649:	pop    rbx
  41164a:	ret
  41164b:	add    BYTE PTR [rax],al
  41164d:	add    BYTE PTR [rax],al
	...

0000000000411650 <__swc_fn_4fa09e82_000125_667fbf24>:
  411650:	push   rdi
  411651:	push   rsi
  411652:	sub    rsp,0xa8
  411659:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41165f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411665:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41166b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411671:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411677:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41167d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411683:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411689:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411692:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41169b:	mov    edi,ecx
  41169d:	xor    eax,eax
  41169f:	call   4071e0 <pthread_key_delete@plt>
  4116a4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4116aa:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4116b0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4116b6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4116bc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4116c2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4116c8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4116ce:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4116d4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4116dd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4116e6:	add    rsp,0xa8
  4116ed:	pop    rsi
  4116ee:	pop    rdi
  4116ef:	ret

00000000004116f0 <__swc_fn_4fa09e82_000128_8dffa290>:
  4116f0:	push   rdi
  4116f1:	push   rsi
  4116f2:	sub    rsp,0xa8
  4116f9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4116ff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411705:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41170b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411711:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411717:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41171d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411723:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411729:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411732:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41173b:	test   rcx,rcx
  41173e:	je     41174f <__swc_fn_4fa09e82_000128_8dffa290+0x5f>
  411740:	lea    rax,[rcx-0x1]
  411744:	mov    eax,eax
  411746:	mov    edi,eax
  411748:	xor    eax,eax
  41174a:	call   4071e0 <pthread_key_delete@plt>
  41174f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  411755:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  41175b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411761:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411767:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  41176d:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411773:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411779:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  41177f:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411788:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411791:	add    rsp,0xa8
  411798:	pop    rsi
  411799:	pop    rdi
  41179a:	ret
  41179b:	add    BYTE PTR [rax],al
  41179d:	add    BYTE PTR [rax],al
	...

00000000004117a0 <__swc_fn_4fa09e82_000131_c1196dfb>:
  4117a0:	push   rsi
  4117a1:	push   rdi
  4117a2:	sub    rsp,0xa8
  4117a9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4117af:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4117b5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4117bb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4117c1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4117c7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4117cd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4117d3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4117d9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4117e2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4117eb:	xor    eax,eax
  4117ed:	call   4071f0 <gettid@plt>
  4117f2:	movsxd rax,eax
  4117f5:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4117fb:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411801:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411807:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41180d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411813:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411819:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41181f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411825:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41182e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411837:	add    rsp,0xa8
  41183e:	pop    rdi
  41183f:	pop    rsi
  411840:	ret
	...

0000000000411850 <__swc_fn_4fa09e82_000134_4b2af8da>:
  411850:	push   rbx
  411851:	push   rdi
  411852:	push   rsi
  411853:	sub    rsp,0xc0
  41185a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  411860:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  411866:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41186c:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  411872:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  411878:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41187e:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  411884:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41188d:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  411896:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41189f:	mov    rbx,rcx
  4118a2:	cs nop WORD PTR [rax+rax*1+0x0]
  4118ac:	nop    DWORD PTR [rax+0x0]
  4118b0:	mov    edx,0x80000000
  4118b5:	xor    eax,eax
  4118b7:	lock cmpxchg DWORD PTR [rbx],edx
  4118bb:	test   eax,eax
  4118bd:	je     4118f4 <__swc_fn_4fa09e82_000134_4b2af8da+0xa4>
  4118bf:	mov    eax,DWORD PTR [rbx]
  4118c1:	lea    rcx,[rsp+0x14]
  4118c6:	mov    DWORD PTR [rsp+0x14],eax
  4118ca:	test   eax,eax
  4118cc:	je     4118b0 <__swc_fn_4fa09e82_000134_4b2af8da+0x60>
  4118ce:	mov    QWORD PTR [rsp],0x0
  4118d6:	mov    edi,0xca
  4118db:	mov    rsi,rbx
  4118de:	mov    edx,0x80
  4118e3:	mov    ecx,DWORD PTR [rcx]
  4118e5:	xor    r8d,r8d
  4118e8:	xor    r9d,r9d
  4118eb:	xor    eax,eax
  4118ed:	call   4071a0 <syscall@plt>
  4118f2:	jmp    4118b0 <__swc_fn_4fa09e82_000134_4b2af8da+0x60>
  4118f4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4118fa:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  411900:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  411906:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41190c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  411912:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  411918:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41191e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  411927:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  411930:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  411939:	add    rsp,0xc0
  411940:	pop    rsi
  411941:	pop    rdi
  411942:	pop    rbx
  411943:	ret
	...

0000000000411950 <__swc_fn_4fa09e82_000137_3e875c27>:
  411950:	sub    rsp,0x8
  411954:	call   409d80 <__swc_fn_4fa09e82_000135_29412410>
  411959:	add    rsp,0x8
  41195d:	ret
	...

0000000000411960 <__swc_fn_4fa09e82_000140_7c02fe26>:
  411960:	push   rdi
  411961:	push   rsi
  411962:	sub    rsp,0xa8
  411969:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41196f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411975:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41197b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411981:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411987:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41198d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411993:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411999:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4119a2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4119ab:	mov    edi,0x28
  4119b0:	xor    eax,eax
  4119b2:	call   4071c0 <malloc@plt>
  4119b7:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4119bd:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4119c3:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4119c9:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4119cf:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4119d5:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4119db:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4119e1:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4119e7:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4119f0:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4119f9:	add    rsp,0xa8
  411a00:	pop    rsi
  411a01:	pop    rdi
  411a02:	ret
	...

0000000000411a10 <__swc_fn_4fa09e82_000143_56e56812>:
  411a10:	mov    QWORD PTR [r8],0x0
  411a17:	cmp    rdx,0x10
  411a1b:	jae    411a20 <__swc_fn_4fa09e82_000143_56e56812+0x10>
  411a1d:	xor    eax,eax
  411a1f:	ret
  411a20:	mov    eax,DWORD PTR [rcx]
  411a22:	cmp    eax,0x42445753
  411a28:	jne    411a32 <__swc_fn_4fa09e82_000143_56e56812+0x22>
  411a2a:	mov    eax,DWORD PTR [rcx+0x4]
  411a2d:	cmp    eax,0x1
  411a30:	je     411a35 <__swc_fn_4fa09e82_000143_56e56812+0x25>
  411a32:	xor    eax,eax
  411a34:	ret
  411a35:	mov    QWORD PTR [r8],rdx
  411a38:	mov    rax,rcx
  411a3b:	ret
  411a3c:	add    BYTE PTR [rax],al
	...

0000000000411a40 <__swc_fn_4fa09e82_000146_863755b5>:
  411a40:	push   rbx
  411a41:	sub    rsp,0xe0
  411a48:	lea    rbx,[rsp+0x8]
  411a4d:	vxorps xmm0,xmm0,xmm0
  411a51:	vmovups XMMWORD PTR [rbx],xmm0
  411a55:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  411a5a:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  411a5f:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  411a64:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  411a69:	vmovups XMMWORD PTR [rbx+0x50],xmm0
  411a6e:	mov    DWORD PTR [rbx+0x60],0x0
  411a75:	mov    r8,rbx
  411a78:	mov    rdx,rcx
  411a7b:	nop    DWORD PTR [rax+rax*1+0x0]
  411a80:	mov    r9,rdx
  411a83:	movabs rdx,0x6666666666666667
  411a8d:	mov    rax,r9
  411a90:	imul   rdx
  411a93:	sar    rdx,0x2
  411a97:	mov    r10,rdx
  411a9a:	shr    rdx,0x3f
  411a9e:	add    r10,rdx
  411aa1:	mov    rdx,r10
  411aa4:	imul   r11,r10,0xa
  411aa8:	sub    r9,r11
  411aab:	mov    r11,QWORD PTR [rip+0x1a8e]        # 413540 <__swc_rdata_base_4fa09e82+0x430>
  411ab2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  411ab7:	mov    BYTE PTR [r8],r9b
  411aba:	lea    r9,[r8+0x1]
  411abe:	mov    r8,r9
  411ac1:	test   r10,r10
  411ac4:	jne    411a80 <__swc_fn_4fa09e82_000146_863755b5+0x40>
  411ac6:	test   rcx,rcx
  411ac9:	jge    411ad3 <__swc_fn_4fa09e82_000146_863755b5+0x93>
  411acb:	mov    BYTE PTR [r9],0x2d
  411acf:	add    r8,0x1
  411ad3:	mov    BYTE PTR [r8],0x0
  411ad7:	sub    r8,0x1
  411adb:	mov    rax,rbx
  411ade:	cmp    rax,r8
  411ae1:	jae    411b06 <__swc_fn_4fa09e82_000146_863755b5+0xc6>
  411ae3:	cs nop WORD PTR [rax+rax*1+0x0]
  411aed:	nop    DWORD PTR [rax]
  411af0:	mov    cl,BYTE PTR [r8]
  411af3:	mov    dl,BYTE PTR [rax]
  411af5:	mov    BYTE PTR [r8],dl
  411af8:	sub    r8,0x1
  411afc:	mov    BYTE PTR [rax],cl
  411afe:	inc    rax
  411b01:	cmp    rax,r8
  411b04:	jb     411af0 <__swc_fn_4fa09e82_000146_863755b5+0xb0>
  411b06:	xor    eax,eax
  411b08:	test   rbx,rbx
  411b0b:	je     411b2e <__swc_fn_4fa09e82_000146_863755b5+0xee>
  411b0d:	mov    rcx,rbx
  411b10:	mov    dl,BYTE PTR [rcx]
  411b12:	test   dl,dl
  411b14:	je     411b2e <__swc_fn_4fa09e82_000146_863755b5+0xee>
  411b16:	cs nop WORD PTR [rax+rax*1+0x0]
  411b20:	add    rcx,0x1
  411b24:	add    rax,0x1
  411b28:	mov    dl,BYTE PTR [rcx]
  411b2a:	test   dl,dl
  411b2c:	jne    411b20 <__swc_fn_4fa09e82_000146_863755b5+0xe0>
  411b2e:	mov    QWORD PTR [rbx+0xa8],rbx
  411b35:	mov    QWORD PTR [rbx+0xb0],rax
  411b3c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  411b44:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  411b4c:	lea    rcx,[rbx+0xb8]
  411b53:	call   4098c0 <__swc_fn_4fa09e82_000117_035d76a1>
  411b58:	add    rsp,0xe0
  411b5f:	pop    rbx
  411b60:	ret
	...

0000000000411b70 <__swc_fn_4fa09e82_000149_9e4bc402>:
  411b70:	vxorps xmm0,xmm0,xmm0
  411b74:	vmovups XMMWORD PTR [rcx],xmm0
  411b78:	mov    QWORD PTR [rcx+0x10],0x0
  411b80:	ret
	...

0000000000411b90 <__swc_fn_4fa09e82_000152_9e4bc402>:
  411b90:	vxorps xmm0,xmm0,xmm0
  411b94:	vmovups XMMWORD PTR [rcx],xmm0
  411b98:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411b9d:	vxorps xmm0,xmm0,xmm0
  411ba1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411ba6:	vmovups xmm0,XMMWORD PTR [rip+0x1a8a]        # 413638 <__swc_rdata_base_4fa09e82+0x528>
  411bae:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411bb3:	vxorps xmm0,xmm0,xmm0
  411bb7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411bbc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411bc1:	mov    QWORD PTR [rcx+0x60],0x0
  411bc9:	ret
  411bca:	add    BYTE PTR [rax],al
  411bcc:	add    BYTE PTR [rax],al
	...

0000000000411bd0 <__swc_fn_4fa09e82_000155_9e4bc402>:
  411bd0:	vxorps xmm0,xmm0,xmm0
  411bd4:	vmovups XMMWORD PTR [rcx],xmm0
  411bd8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411bdd:	vxorps xmm0,xmm0,xmm0
  411be1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411be6:	vmovups xmm0,XMMWORD PTR [rip+0x1b72]        # 413760 <__swc_rdata_base_4fa09e82+0x650>
  411bee:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411bf3:	vxorps xmm0,xmm0,xmm0
  411bf7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411bfc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411c01:	vxorps xmm0,xmm0,xmm0
  411c05:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  411c0a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  411c0f:	vxorps xmm0,xmm0,xmm0
  411c13:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  411c1b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  411c23:	vxorps xmm0,xmm0,xmm0
  411c27:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  411c2f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  411c37:	vxorps xmm0,xmm0,xmm0
  411c3b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  411c43:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  411c4b:	mov    QWORD PTR [rcx+0xe0],0x0
  411c56:	ret
	...

0000000000411c60 <__swc_fn_4fa09e82_000158_232ffa22>:
  411c60:	push   rbx
  411c61:	mov    rbx,rcx
  411c64:	call   40b350 <__swc_fn_4fa09e82_000159_b43b2f96>
  411c69:	mov    rax,QWORD PTR [rbx+0x10]
  411c6d:	test   rax,rax
  411c70:	je     411c81 <__swc_fn_4fa09e82_000158_232ffa22+0x21>
  411c72:	mov    rcx,rbx
  411c75:	mov    rdx,rax
  411c78:	mov    r8,QWORD PTR [rbx+0x18]
  411c7c:	call   40ede0 <__swc_fn_4fa09e82_000157_2745c4a5>
  411c81:	vxorps xmm0,xmm0,xmm0
  411c85:	vmovups XMMWORD PTR [rbx],xmm0
  411c89:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  411c8e:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  411c93:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  411c98:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  411c9d:	mov    QWORD PTR [rbx+0x50],0x0
  411ca5:	pop    rbx
  411ca6:	ret
	...

0000000000411cc0 <__swc_fn_4fa09e82_000161_01cbb887>:
  411cc0:	sub    rsp,0x10
  411cc4:	mov    eax,r8d
  411cc7:	mov    r8d,r9d
  411cca:	test   r9d,r9d
  411ccd:	jne    411ce6 <__swc_fn_4fa09e82_000161_01cbb887+0x26>
  411ccf:	vmovups xmm0,XMMWORD PTR [rip+0x1b41]        # 413818 <__swc_rdata_base_4fa09e82+0x708>
  411cd7:	vmovups XMMWORD PTR [r10],xmm0
  411cdc:	mov    eax,0x1
  411ce1:	add    rsp,0x10
  411ce5:	ret
  411ce6:	mov    r9,r8
  411ce9:	cmp    r8,rax
  411cec:	jb     411cf3 <__swc_fn_4fa09e82_000161_01cbb887+0x33>
  411cee:	cmp    r9,rdx
  411cf1:	jb     411cfa <__swc_fn_4fa09e82_000161_01cbb887+0x3a>
  411cf3:	xor    eax,eax
  411cf5:	add    rsp,0x10
  411cf9:	ret
  411cfa:	xor    eax,eax
  411cfc:	lea    r8,[r9+rax*1]
  411d00:	cmp    r8,rdx
  411d03:	jae    411d33 <__swc_fn_4fa09e82_000161_01cbb887+0x73>
  411d05:	cs nop WORD PTR [rax+rax*1+0x0]
  411d0f:	cs nop WORD PTR [rax+rax*1+0x0]
  411d19:	nop    DWORD PTR [rax+0x0]
  411d20:	cmp    BYTE PTR [rcx+r8*1],0x0
  411d25:	je     411d33 <__swc_fn_4fa09e82_000161_01cbb887+0x73>
  411d27:	inc    rax
  411d2a:	lea    r8,[r9+rax*1]
  411d2e:	cmp    r8,rdx
  411d31:	jb     411d20 <__swc_fn_4fa09e82_000161_01cbb887+0x60>
  411d33:	cmp    r8,rdx
  411d36:	jne    411d3f <__swc_fn_4fa09e82_000161_01cbb887+0x7f>
  411d38:	xor    eax,eax
  411d3a:	add    rsp,0x10
  411d3e:	ret
  411d3f:	add    rcx,r9
  411d42:	mov    QWORD PTR [rsp],rcx
  411d46:	mov    QWORD PTR [rsp+0x8],rax
  411d4b:	vmovups xmm0,XMMWORD PTR [rsp]
  411d50:	vmovups XMMWORD PTR [r10],xmm0
  411d55:	mov    eax,0x1
  411d5a:	add    rsp,0x10
  411d5e:	ret
	...

0000000000411d60 <__swc_fn_4fa09e82_000164_8e41797b>:
  411d60:	push   rbp
  411d61:	push   rbx
  411d62:	push   rsi
  411d63:	push   rdi
  411d64:	push   r12
  411d66:	push   r13
  411d68:	push   r14
  411d6a:	push   r15
  411d6c:	sub    rsp,0x10
  411d70:	mov    rbp,rsp
  411d73:	vmovups XMMWORD PTR [rsp],xmm6
  411d78:	sub    rsp,0x50
  411d7c:	mov    rbx,rsp
  411d7f:	mov    rsi,r8
  411d82:	mov    QWORD PTR [rsp+0x30],r8
  411d87:	mov    rdi,rcx
  411d8a:	mov    QWORD PTR [rsp+0x38],rcx
  411d8f:	mov    r12,rdx
  411d92:	xor    r13b,r13b
  411d95:	mov    r14,QWORD PTR [rdi+0x8]
  411d99:	mov    QWORD PTR [rsp+0x40],r14
  411d9e:	xor    r15d,r15d
  411da1:	test   r14,r14
  411da4:	jbe    411ffe <__swc_fn_4fa09e82_000164_8e41797b+0x29e>
  411daa:	mov    r14,QWORD PTR [rdi]
  411dad:	mov    rax,QWORD PTR [rsp+0x40]
  411db2:	mov    QWORD PTR [rsp+0x48],r14
  411db7:	vmovups xmm6,XMMWORD PTR [rip+0x1679]        # 413438 <__swc_rdata_base_4fa09e82+0x328>
  411dbf:	nop
  411dc0:	cmp    QWORD PTR [r14+r15*8],0x0
  411dc5:	jne    411dcf <__swc_fn_4fa09e82_000164_8e41797b+0x6f>
  411dc7:	mov    r14,rax
  411dca:	jmp    411fde <__swc_fn_4fa09e82_000164_8e41797b+0x27e>
  411dcf:	mov    rcx,QWORD PTR [rdi]
  411dd2:	mov    rdx,QWORD PTR [rcx+r15*8]
  411dd6:	mov    rdi,rbx
  411dd9:	mov    rcx,rdi
  411ddc:	sub    rsp,0x8
  411de0:	mov    r14,rax
  411de3:	call   40ee60 <__swc_fn_4fa09e82_000163_60216e69>
  411de8:	add    rsp,0x8
  411dec:	mov    al,BYTE PTR [rbx]
  411dee:	test   al,al
  411df0:	je     411fde <__swc_fn_4fa09e82_000164_8e41797b+0x27e>
  411df6:	mov    al,BYTE PTR [rbx+0x1]
  411df9:	test   al,al
  411dfb:	jne    411e06 <__swc_fn_4fa09e82_000164_8e41797b+0xa6>
  411dfd:	test   sil,sil
  411e00:	je     411fde <__swc_fn_4fa09e82_000164_8e41797b+0x27e>
  411e06:	test   r13b,r13b
  411e09:	jne    411ec7 <__swc_fn_4fa09e82_000164_8e41797b+0x167>
  411e0f:	test   r12,r12
  411e12:	je     411ec7 <__swc_fn_4fa09e82_000164_8e41797b+0x167>
  411e18:	mov    al,BYTE PTR [rbx+0x1]
  411e1b:	test   al,al
  411e1d:	je     411fde <__swc_fn_4fa09e82_000164_8e41797b+0x27e>
  411e23:	mov    eax,DWORD PTR [rbx+0x28]
  411e26:	cmp    DWORD PTR [r12+0x20],eax
  411e2b:	jne    411fde <__swc_fn_4fa09e82_000164_8e41797b+0x27e>
  411e31:	mov    rax,QWORD PTR [r12]
  411e35:	mov    rcx,QWORD PTR [r12+0x8]
  411e3a:	cmp    QWORD PTR [rbx+0x20],rcx
  411e3e:	jne    411fde <__swc_fn_4fa09e82_000164_8e41797b+0x27e>
  411e44:	mov    cl,0x1
  411e46:	test   rax,rax
  411e49:	je     411eb2 <__swc_fn_4fa09e82_000164_8e41797b+0x152>
  411e4f:	mov    rdx,QWORD PTR [rbx+0x20]
  411e53:	xor    r8d,r8d
  411e56:	test   rdx,rdx
  411e59:	jbe    411eb2 <__swc_fn_4fa09e82_000164_8e41797b+0x152>
  411e5b:	mov    r9,QWORD PTR [rbx+0x18]
  411e5f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  411e64:	cs nop WORD PTR [rax+rax*1+0x0]
  411e6e:	xchg   ax,ax
  411e70:	mov    r10b,BYTE PTR [rax+r8*1]
  411e74:	cmp    BYTE PTR [r9+r8*1],r10b
  411e78:	je     411ea9 <__swc_fn_4fa09e82_000164_8e41797b+0x149>
  411e7a:	vmovq  r10,xmm0
  411e7f:	cmp    BYTE PTR [r10+r8*1],0x5c
  411e84:	jne    411e8d <__swc_fn_4fa09e82_000164_8e41797b+0x12d>
  411e86:	cmp    BYTE PTR [rax+r8*1],0x2f
  411e8b:	je     411ea9 <__swc_fn_4fa09e82_000164_8e41797b+0x149>
  411e8d:	vmovq  r10,xmm0
  411e92:	cmp    BYTE PTR [r10+r8*1],0x2f
  411e97:	jne    411ea0 <__swc_fn_4fa09e82_000164_8e41797b+0x140>
  411e99:	cmp    BYTE PTR [rax+r8*1],0x5c
  411e9e:	je     411ea9 <__swc_fn_4fa09e82_000164_8e41797b+0x149>
  411ea0:	xor    eax,eax
  411ea2:	movzx  eax,al
  411ea5:	mov    cl,al
  411ea7:	jmp    411eb2 <__swc_fn_4fa09e82_000164_8e41797b+0x152>
  411ea9:	add    r8,0x1
  411ead:	cmp    r8,rdx
  411eb0:	jb     411e70 <__swc_fn_4fa09e82_000164_8e41797b+0x110>
  411eb2:	test   cl,cl
  411eb4:	je     411fde <__swc_fn_4fa09e82_000164_8e41797b+0x27e>
  411eba:	mov    eax,0x1
  411ebf:	mov    r13b,al
  411ec2:	jmp    411fde <__swc_fn_4fa09e82_000164_8e41797b+0x27e>
  411ec7:	mov    r13b,0x1
  411eca:	sub    rsp,0x20
  411ece:	mov    rax,rsp
  411ed1:	lea    rcx,[rdi+0x8]
  411ed5:	mov    QWORD PTR [rax],rcx
  411ed8:	lea    rsi,[rip+0x1431]        # 413310 <__swc_rdata_base_4fa09e82+0x200>
  411edf:	mov    QWORD PTR [rax+0x8],rsi
  411ee3:	mov    QWORD PTR [rax+0x10],rsp
  411ee7:	mov    QWORD PTR [rax+0x18],0x1
  411eef:	lea    rcx,[rsp+0x10]
  411ef4:	sub    rsp,0x8
  411ef8:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  411efd:	add    rsp,0x8
  411f01:	add    rsp,0x20
  411f05:	mov    al,BYTE PTR [rbx+0x1]
  411f08:	test   al,al
  411f0a:	je     411fa7 <__swc_fn_4fa09e82_000164_8e41797b+0x247>
  411f10:	lea    rax,[rip+0x19a1]        # 4138b8 <__swc_rdata_base_4fa09e82+0x7a8>
  411f17:	sub    rsp,0x20
  411f1b:	mov    rcx,rsp
  411f1e:	mov    QWORD PTR [rcx],rax
  411f21:	mov    QWORD PTR [rcx+0x8],rsi
  411f25:	mov    QWORD PTR [rcx+0x10],rsp
  411f29:	mov    QWORD PTR [rcx+0x18],0x1
  411f31:	lea    rcx,[rsp+0x10]
  411f36:	sub    rsp,0x8
  411f3a:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  411f3f:	add    rsp,0x8
  411f43:	add    rsp,0x20
  411f47:	mov    eax,DWORD PTR [rbx+0x28]
  411f4a:	sub    rsp,0x60
  411f4e:	mov    rcx,rsp
  411f51:	lea    rdx,[rdi+0x18]
  411f55:	mov    QWORD PTR [rcx+0x18],rdx
  411f59:	mov    QWORD PTR [rcx+0x20],rsi
  411f5d:	vmovups XMMWORD PTR [rcx],xmm6
  411f61:	mov    QWORD PTR [rcx+0x28],rsp
  411f65:	mov    QWORD PTR [rcx+0x30],rsi
  411f69:	mov    DWORD PTR [rcx+0x10],eax
  411f6c:	lea    rax,[rsp+0x10]
  411f71:	mov    QWORD PTR [rcx+0x38],rax
  411f75:	lea    rax,[rip+0x1454]        # 4133d0 <__swc_rdata_base_4fa09e82+0x2c0>
  411f7c:	mov    QWORD PTR [rcx+0x40],rax
  411f80:	lea    rax,[rsp+0x18]
  411f85:	mov    QWORD PTR [rcx+0x48],rax
  411f89:	mov    QWORD PTR [rcx+0x50],0x3
  411f91:	lea    rcx,[rsp+0x48]
  411f96:	sub    rsp,0x8
  411f9a:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  411f9f:	add    rsp,0x8
  411fa3:	add    rsp,0x60
  411fa7:	lea    rax,[rip+0x13ba]        # 413368 <__swc_rdata_base_4fa09e82+0x258>
  411fae:	sub    rsp,0x20
  411fb2:	mov    rcx,rsp
  411fb5:	mov    QWORD PTR [rcx],rax
  411fb8:	mov    QWORD PTR [rcx+0x8],rsi
  411fbc:	mov    QWORD PTR [rcx+0x10],rsp
  411fc0:	mov    QWORD PTR [rcx+0x18],0x1
  411fc8:	lea    rcx,[rsp+0x10]
  411fcd:	sub    rsp,0x8
  411fd1:	call   40a140 <__swc_fn_4fa09e82_000147_43f4fdca>
  411fd6:	add    rsp,0x8
  411fda:	add    rsp,0x20
  411fde:	add    r15,0x1
  411fe2:	cmp    r15,r14
  411fe5:	jae    411ffe <__swc_fn_4fa09e82_000164_8e41797b+0x29e>
  411fe7:	mov    rsi,QWORD PTR [rsp+0x30]
  411fec:	mov    rdi,QWORD PTR [rsp+0x38]
  411ff1:	mov    rax,r14
  411ff4:	mov    r14,QWORD PTR [rsp+0x48]
  411ff9:	jmp    411dc0 <__swc_fn_4fa09e82_000164_8e41797b+0x60>
  411ffe:	add    rsp,0x50
  412002:	vmovups xmm6,XMMWORD PTR [rsp]
  412007:	add    rsp,0x10
  41200b:	pop    r15
  41200d:	pop    r14
  41200f:	pop    r13
  412011:	pop    r12
  412013:	pop    rdi
  412014:	pop    rsi
  412015:	pop    rbx
  412016:	pop    rbp
  412017:	ret
	...

0000000000412020 <__swc_fn_4fa09e82_000167_f6173642>:
  412020:	sub    rsp,0x8
  412024:	call   409b50 <__swc_fn_4fa09e82_000126_ce762363>
  412029:	add    rsp,0x8
  41202d:	ret
	...

0000000000412030 <__swc_fn_4fa09e82_000170_4579a84c>:
  412030:	push   rsi
  412031:	sub    rsp,0x30
  412035:	lea    rsi,[rip+0x14d64]        # 426da0 <__swc_bss_base_4fa09e82+0x2d60>
  41203c:	mov    rax,QWORD PTR [rsi]
  41203f:	test   rax,rax
  412042:	je     41204a <__swc_fn_4fa09e82_000170_4579a84c+0x1a>
  412044:	add    rsp,0x30
  412048:	pop    rsi
  412049:	ret
  41204a:	mov    ecx,0x2
  41204f:	mov    edx,0x8020
  412054:	call   4091c0 <__swc_fn_4fa09e82_000108_4796e893>
  412059:	test   rax,rax
  41205c:	jne    41206d <__swc_fn_4fa09e82_000170_4579a84c+0x3d>
  41205e:	mov    QWORD PTR [rsp+0x18],rax
  412063:	call   4114a0 <__swc_fn_4fa09e82_000119_7f430081>
  412068:	mov    rax,QWORD PTR [rsp+0x18]
  41206d:	mov    rcx,rax
  412070:	xchg   QWORD PTR [rsi],rcx
  412073:	add    rsp,0x30
  412077:	pop    rsi
  412078:	ret
  412079:	add    BYTE PTR [rax],al
  41207b:	add    BYTE PTR [rax],al
  41207d:	add    BYTE PTR [rax],al
	...

0000000000412080 <__swc_fn_4fa09e82_000173_97fbc432>:
  412080:	push   rsi
  412081:	test   r8,r8
  412084:	jne    412088 <__swc_fn_4fa09e82_000173_97fbc432+0x8>
  412086:	pop    rsi
  412087:	ret
  412088:	lea    rax,[rcx+0x18]
  41208c:	mov    r10,QWORD PTR [rax]
  41208f:	lea    r11,[r10+0x1]
  412093:	mov    QWORD PTR [rax],r11
  412096:	mov    r11,rdx
  412099:	not    rdx
  41209c:	lea    rsi,[r8-0x1]
  4120a0:	cmp    rsi,rdx
  4120a3:	ja     4120c3 <__swc_fn_4fa09e82_000173_97fbc432+0x43>
  4120a5:	lea    rdx,[r11+r8*1]
  4120a9:	dec    rdx
  4120ac:	shr    rdx,0x6
  4120b0:	mov    r8,r11
  4120b3:	shr    r8,0x6
  4120b7:	mov    rsi,rdx
  4120ba:	sub    rsi,r8
  4120bd:	cmp    rsi,0x8
  4120c1:	jb     4120d9 <__swc_fn_4fa09e82_000173_97fbc432+0x59>
  4120c3:	lea    rcx,[rcx+0x10]
  4120c7:	mov    rdx,QWORD PTR [rcx]
  4120ca:	add    rdx,r9
  4120cd:	mov    QWORD PTR [rcx],rdx
  4120d0:	lea    rcx,[r10+0x2]
  4120d4:	mov    QWORD PTR [rax],rcx
  4120d7:	pop    rsi
  4120d8:	ret
  4120d9:	shr    r11,0x6
  4120dd:	nop    DWORD PTR [rax]
  4120e0:	cmp    r11,rdx
  4120e3:	ja     412123 <__swc_fn_4fa09e82_000173_97fbc432+0xa3>
  4120e5:	jmp    4120f6 <__swc_fn_4fa09e82_000173_97fbc432+0x76>
  4120e7:	nop    WORD PTR [rax+rax*1+0x0]
  4120f0:	add    r11,0x1
  4120f4:	jmp    4120e0 <__swc_fn_4fa09e82_000173_97fbc432+0x60>
  4120f6:	mov    r8,r11
  4120f9:	shr    r8,0xc
  4120fd:	mov    rsi,r11
  412100:	xor    rsi,r8
  412103:	mov    r8,r11
  412106:	shr    r8,0x18
  41210a:	xor    rsi,r8
  41210d:	and    esi,0xfff
  412113:	lea    r8,[rcx+rsi*8+0x20]
  412118:	mov    rsi,QWORD PTR [r8]
  41211b:	add    rsi,r9
  41211e:	mov    QWORD PTR [r8],rsi
  412121:	jmp    4120f0 <__swc_fn_4fa09e82_000173_97fbc432+0x70>
  412123:	lea    rcx,[r10+0x2]
  412127:	mov    QWORD PTR [rax],rcx
  41212a:	pop    rsi
  41212b:	ret
  41212c:	add    BYTE PTR [rax],al
	...

0000000000412130 <__swc_fn_4fa09e82_000176_e7f0b636>:
  412130:	push   rsi
  412131:	push   rdi
  412132:	push   r12
  412134:	mov    rsi,r8
  412137:	mov    rdi,rcx
  41213a:	mov    r12,rdx
  41213d:	lea    rcx,[rdx*8+0x0]
  412145:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  41214a:	mov    QWORD PTR [rdi],rax
  41214d:	lea    rcx,[r12*8+0x0]
  412155:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  41215a:	mov    QWORD PTR [rdi+0x8],rax
  41215e:	lea    rcx,[r12*8+0x0]
  412166:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  41216b:	mov    QWORD PTR [rdi+0x10],rax
  41216f:	mov    rcx,r12
  412172:	call   40b860 <__swc_fn_4fa09e82_000177_2744b483>
  412177:	mov    QWORD PTR [rdi+0x18],rax
  41217b:	mov    rcx,rax
  41217e:	xor    al,al
  412180:	mov    rdx,rax
  412183:	mov    r8,r12
  412186:	call   409100 <__swc_fn_4fa09e82_000105_5f646f9d>
  41218b:	mov    QWORD PTR [rdi+0x20],rsi
  41218f:	lea    rax,[r12-0x1]
  412194:	mov    QWORD PTR [rdi+0x28],rax
  412198:	mov    QWORD PTR [rdi+0x30],0x0
  4121a0:	pop    r12
  4121a2:	pop    rdi
  4121a3:	pop    rsi
  4121a4:	ret
	...

00000000004121b0 <__swc_fn_4fa09e82_000179_6937fe70>:
  4121b0:	push   rsi
  4121b1:	push   rdi
  4121b2:	push   r12
  4121b4:	push   r13
  4121b6:	push   r14
  4121b8:	push   r15
  4121ba:	sub    rsp,0xd8
  4121c1:	mov    rsi,rdx
  4121c4:	mov    QWORD PTR [rsp+0x88],rdx
  4121cc:	mov    rdi,rcx
  4121cf:	cmp    rdi,rsi
  4121d2:	jge    4123e9 <__swc_fn_4fa09e82_000179_6937fe70+0x239>
  4121d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4121e0:	lea    rax,[rdi+rsi*1]
  4121e4:	mov    rcx,rax
  4121e7:	shr    rax,0x3f
  4121eb:	add    rcx,rax
  4121ee:	sar    rcx,1
  4121f1:	mov    rax,QWORD PTR [rip+0x14bb8]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  4121f8:	mov    r12,QWORD PTR [rax+rcx*8]
  4121fc:	mov    r13,rdi
  4121ff:	mov    QWORD PTR [rsp+0x90],rdi
  412207:	mov    r14,rsi
  41220a:	nop    WORD PTR [rax+rax*1+0x0]
  412210:	cmp    r13,r14
  412213:	jle    412220 <__swc_fn_4fa09e82_000179_6937fe70+0x70>
  412215:	mov    rax,r13
  412218:	mov    r13,r14
  41221b:	jmp    4123c5 <__swc_fn_4fa09e82_000179_6937fe70+0x215>
  412220:	mov    r15,QWORD PTR [rip+0x14b89]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  412227:	mov    rsi,QWORD PTR [rip+0x14b8a]        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  41222e:	mov    QWORD PTR [rsp+0xa8],rsi
  412236:	mov    rdi,QWORD PTR [rsi+r12*8]
  41223a:	mov    QWORD PTR [rsp+0xa0],r14
  412242:	mov    r14,QWORD PTR [rip+0x14b77]        # 426dc0 <__swc_bss_base_4fa09e82+0x2d80>
  412249:	mov    rax,QWORD PTR [rip+0x14b78]        # 426dc8 <__swc_bss_base_4fa09e82+0x2d88>
  412250:	mov    QWORD PTR [rsp+0xb0],rax
  412258:	mov    r9,QWORD PTR [rip+0x14b71]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  41225f:	mov    QWORD PTR [rsp+0xb8],r9
  412267:	nop    WORD PTR [rax+rax*1+0x0]
  412270:	mov    r10,QWORD PTR [r15+r13*8]
  412274:	cmp    QWORD PTR [rsi+r10*8],rdi
  412278:	je     41227e <__swc_fn_4fa09e82_000179_6937fe70+0xce>
  41227a:	ja     4122b5 <__swc_fn_4fa09e82_000179_6937fe70+0x105>
  41227c:	jmp    4122d2 <__swc_fn_4fa09e82_000179_6937fe70+0x122>
  41227e:	mov    rcx,QWORD PTR [r14+r10*8]
  412282:	mov    r8,QWORD PTR [r14+r12*8]
  412286:	cmp    r8,rcx
  412289:	cmovae r8,rcx
  41228d:	mov    rcx,QWORD PTR [rax+r10*8]
  412291:	add    rcx,r9
  412294:	mov    rdx,QWORD PTR [rax+r12*8]
  412298:	add    rdx,r9
  41229b:	mov    rsi,r10
  41229e:	call   410f30 <__swc_fn_4fa09e82_000107_ed4b1681>
  4122a3:	test   eax,eax
  4122a5:	je     4122ab <__swc_fn_4fa09e82_000179_6937fe70+0xfb>
  4122a7:	jl     4122b5 <__swc_fn_4fa09e82_000179_6937fe70+0x105>
  4122a9:	jmp    4122d2 <__swc_fn_4fa09e82_000179_6937fe70+0x122>
  4122ab:	mov    rax,QWORD PTR [r14+r12*8]
  4122af:	cmp    QWORD PTR [r14+rsi*8],rax
  4122b3:	jae    4122d2 <__swc_fn_4fa09e82_000179_6937fe70+0x122>
  4122b5:	inc    r13
  4122b8:	mov    rsi,QWORD PTR [rsp+0xa8]
  4122c0:	mov    rax,QWORD PTR [rsp+0xb0]
  4122c8:	mov    r9,QWORD PTR [rsp+0xb8]
  4122d0:	jmp    412270 <__swc_fn_4fa09e82_000179_6937fe70+0xc0>
  4122d2:	mov    rsi,QWORD PTR [rip+0x14ad7]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  4122d9:	mov    QWORD PTR [rsp+0xc0],rsi
  4122e1:	mov    rdi,QWORD PTR [rip+0x14ad0]        # 426db8 <__swc_bss_base_4fa09e82+0x2d78>
  4122e8:	mov    r14,QWORD PTR [rip+0x14ad1]        # 426dc0 <__swc_bss_base_4fa09e82+0x2d80>
  4122ef:	mov    r15,QWORD PTR [rip+0x14ad2]        # 426dc8 <__swc_bss_base_4fa09e82+0x2d88>
  4122f6:	mov    QWORD PTR [rsp+0x98],r13
  4122fe:	mov    r13,QWORD PTR [rsp+0xa0]
  412306:	mov    rax,QWORD PTR [rip+0x14ac3]        # 426dd0 <__swc_bss_base_4fa09e82+0x2d90>
  41230d:	mov    QWORD PTR [rsp+0xc8],rax
  412315:	cs nop WORD PTR [rax+rax*1+0x0]
  41231f:	nop
  412320:	mov    r9,QWORD PTR [rsi+r13*8]
  412324:	mov    rcx,QWORD PTR [rdi+r9*8]
  412328:	cmp    QWORD PTR [rdi+r12*8],rcx
  41232c:	je     412332 <__swc_fn_4fa09e82_000179_6937fe70+0x182>
  41232e:	ja     412369 <__swc_fn_4fa09e82_000179_6937fe70+0x1b9>
  412330:	jmp    41237e <__swc_fn_4fa09e82_000179_6937fe70+0x1ce>
  412332:	mov    rcx,QWORD PTR [r14+r12*8]
  412336:	mov    r8,QWORD PTR [r14+r9*8]
  41233a:	cmp    r8,rcx
  41233d:	cmovae r8,rcx
  412341:	mov    rcx,QWORD PTR [r15+r12*8]
  412345:	add    rcx,rax
  412348:	mov    rdx,QWORD PTR [r15+r9*8]
  41234c:	add    rdx,rax
  41234f:	mov    rsi,r9
  412352:	call   410f30 <__swc_fn_4fa09e82_000107_ed4b1681>
  412357:	test   eax,eax
  412359:	je     41235f <__swc_fn_4fa09e82_000179_6937fe70+0x1af>
  41235b:	jl     412369 <__swc_fn_4fa09e82_000179_6937fe70+0x1b9>
  41235d:	jmp    41237e <__swc_fn_4fa09e82_000179_6937fe70+0x1ce>
  41235f:	mov    rax,QWORD PTR [r14+rsi*8]
  412363:	cmp    QWORD PTR [r14+r12*8],rax
  412367:	jae    41237e <__swc_fn_4fa09e82_000179_6937fe70+0x1ce>
  412369:	dec    r13
  41236c:	mov    rsi,QWORD PTR [rsp+0xc0]
  412374:	mov    rax,QWORD PTR [rsp+0xc8]
  41237c:	jmp    412320 <__swc_fn_4fa09e82_000179_6937fe70+0x170>
  41237e:	mov    rax,QWORD PTR [rsp+0x98]
  412386:	cmp    rax,r13
  412389:	jle    412396 <__swc_fn_4fa09e82_000179_6937fe70+0x1e6>
  41238b:	mov    r14,r13
  41238e:	mov    r13,rax
  412391:	jmp    412210 <__swc_fn_4fa09e82_000179_6937fe70+0x60>
  412396:	mov    rcx,QWORD PTR [rip+0x14a13]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  41239d:	mov    rdx,QWORD PTR [rcx+rax*8]
  4123a1:	mov    r8,QWORD PTR [rcx+r13*8]
  4123a5:	mov    QWORD PTR [rcx+rax*8],r8
  4123a9:	mov    rcx,QWORD PTR [rip+0x14a00]        # 426db0 <__swc_bss_base_4fa09e82+0x2d70>
  4123b0:	mov    QWORD PTR [rcx+r13*8],rdx
  4123b4:	inc    rax
  4123b7:	dec    r13
  4123ba:	mov    r14,r13
  4123bd:	mov    r13,rax
  4123c0:	jmp    412210 <__swc_fn_4fa09e82_000179_6937fe70+0x60>
  4123c5:	mov    rcx,QWORD PTR [rsp+0x90]
  4123cd:	mov    rdx,r13
  4123d0:	mov    rdi,rax
  4123d3:	call   4121b0 <__swc_fn_4fa09e82_000179_6937fe70>
  4123d8:	mov    rsi,QWORD PTR [rsp+0x88]
  4123e0:	cmp    rdi,rsi
  4123e3:	jl     4121e0 <__swc_fn_4fa09e82_000179_6937fe70+0x30>
  4123e9:	add    rsp,0xd8
  4123f0:	pop    r15
  4123f2:	pop    r14
  4123f4:	pop    r13
  4123f6:	pop    r12
  4123f8:	pop    rdi
  4123f9:	pop    rsi
  4123fa:	ret
