
/workspace/prompt2-20261115/batch9-audited-micro/new/csvagg/csvagg:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <mmap@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <mmap@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <mprotect@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <mprotect@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <munmap@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <munmap@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <madvise@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <madvise@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <exit@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <exit@GLIBC_2.2.5>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_key_delete@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <pthread_key_delete@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <gettid@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <gettid@GLIBC_2.30>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <syscall@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <syscall@GLIBC_2.2.5>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <malloc@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <malloc@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <open@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <open@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <flock@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <flock@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <__errno_location@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <__errno_location@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <close@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <close@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <getpid@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf92]        # 413078 <getpid@GLIBC_2.2.5>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <opendir@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf8a]        # 413080 <opendir@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <dirfd@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf82]        # 413088 <dirfd@GLIBC_2.2.5>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <readdir@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf7a]        # 413090 <readdir@GLIBC_2.2.5>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <readlinkat@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf72]        # 413098 <readlinkat@GLIBC_2.4>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <openat@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf6a]        # 4130a0 <openat@GLIBC_2.4>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <closedir@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf62]        # 4130a8 <closedir@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <lseek@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf5a]        # 4130b0 <lseek@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <memfd_create@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf52]        # 4130b8 <memfd_create@GLIBC_2.27>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <ftruncate@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf4a]        # 4130c0 <ftruncate@GLIBC_2.2.5>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <write@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf42]        # 4130c8 <write@GLIBC_2.2.5>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <backtrace@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf3a]        # 4130d0 <backtrace@GLIBC_2.2.5>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <pthread_setspecific@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf32]        # 4130d8 <pthread_setspecific@GLIBC_2.34>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <clock_gettime@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130e0 <clock_gettime@GLIBC_2.17>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <__x86_get_cpuid_feature_leaf@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf22]        # 4130e8 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <free@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf1a]        # 4130f0 <free@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <pthread_key_create@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <pthread_key_create@GLIBC_2.34>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <dladdr@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <dladdr@GLIBC_2.34>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_e121059d_000179_718d7b54+0x490>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40a6e0 <__swc_fn_e121059d_000126_540bf7e8>
  40724e:	xor    ecx,ecx
  407250:	call   4116c0 <__swc_fn_e121059d_000098_4f209617>
  407255:	call   407300 <__swc_fn_e121059d_000003_68d30882>
  40725a:	call   409d30 <__swc_fn_e121059d_000099_65137b72>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_e121059d_000000_e7f0b636>:
  407270:	push   rsi
  407271:	push   rdi
  407272:	push   r12
  407274:	mov    rsi,r8
  407277:	mov    rdi,rcx
  40727a:	mov    r12,rdx
  40727d:	lea    rcx,[rdx*8+0x0]
  407285:	call   40b2a0 <__swc_fn_e121059d_000001_2744b483>
  40728a:	mov    QWORD PTR [rdi],rax
  40728d:	lea    rcx,[r12*8+0x0]
  407295:	call   40b2a0 <__swc_fn_e121059d_000001_2744b483>
  40729a:	mov    QWORD PTR [rdi+0x8],rax
  40729e:	lea    rcx,[r12*8+0x0]
  4072a6:	call   40b2a0 <__swc_fn_e121059d_000001_2744b483>
  4072ab:	mov    QWORD PTR [rdi+0x10],rax
  4072af:	mov    rcx,r12
  4072b2:	call   40b2a0 <__swc_fn_e121059d_000001_2744b483>
  4072b7:	mov    QWORD PTR [rdi+0x18],rax
  4072bb:	mov    rcx,rax
  4072be:	xor    al,al
  4072c0:	mov    rdx,rax
  4072c3:	mov    r8,r12
  4072c6:	call   40d1a0 <__swc_fn_e121059d_000109_a342ead8>
  4072cb:	mov    QWORD PTR [rdi+0x20],rsi
  4072cf:	lea    rax,[r12-0x1]
  4072d4:	mov    QWORD PTR [rdi+0x28],rax
  4072d8:	mov    QWORD PTR [rdi+0x30],0x0
  4072e0:	pop    r12
  4072e2:	pop    rdi
  4072e3:	pop    rsi
  4072e4:	ret
	...

0000000000407300 <__swc_fn_e121059d_000003_68d30882>:
  407300:	push   rbp
  407301:	push   rbx
  407302:	push   rsi
  407303:	push   rdi
  407304:	push   r12
  407306:	push   r13
  407308:	push   r14
  40730a:	push   r15
  40730c:	sub    rsp,0x50
  407310:	mov    rbp,rsp
  407313:	vmovups XMMWORD PTR [rsp],xmm6
  407318:	vmovups XMMWORD PTR [rsp+0x10],xmm7
  40731e:	vmovups XMMWORD PTR [rsp+0x20],xmm8
  407324:	vmovups XMMWORD PTR [rsp+0x30],xmm9
  40732a:	vmovups XMMWORD PTR [rsp+0x40],xmm10
  407330:	sub    rsp,0x8b0
  407337:	mov    rbx,rsp
  40733a:	sub    rsp,0x8
  40733e:	mov    ecx,0x124f800
  407343:	call   40b2a0 <__swc_fn_e121059d_000001_2744b483>
  407348:	mov    rsi,rax
  40734b:	mov    QWORD PTR [rsp+0x7a8],rax
  407353:	xor    ecx,ecx
  407355:	xor    r8d,r8d
  407358:	mov    QWORD PTR [rsp+0x7b0],r8
  407360:	lea    r9,[rbx+0xa0]
  407367:	lea    r10,[rbx+0xf0]
  40736e:	lea    r11,[rbx+0x168]
  407375:	mov    QWORD PTR [rsp+0x7b8],r11
  40737d:	lea    rdi,[rbx+0x1b0]
  407384:	mov    QWORD PTR [rsp+0x7c0],rdi
  40738c:	nop    DWORD PTR [rax+0x0]
  407390:	test   r8,r8
  407393:	jbe    40739d <__swc_fn_e121059d_000003_68d30882+0x9d>
  407395:	mov    BYTE PTR [rsi+rcx*1],0xa
  407399:	add    rcx,0x1
  40739d:	lea    r12,[rip+0xbd7c]        # 413120 <__swc_rdata_base_e121059d+0x10>
  4073a4:	mov    r13,QWORD PTR [rip+0x1ac55]        # 422000 <__swc_data_base_e121059d>
  4073ab:	imul   r13,r13,0x41a7
  4073b2:	movabs rdx,0x200000005
  4073bc:	mov    r11,rax
  4073bf:	mov    rax,r13
  4073c2:	mul    rdx
  4073c5:	mov    r14,rdx
  4073c8:	mov    rdx,r13
  4073cb:	sub    rdx,r14
  4073ce:	shr    rdx,1
  4073d1:	add    rdx,r14
  4073d4:	shr    rdx,0x1e
  4073d8:	imul   r14,rdx,0x7fffffff
  4073df:	sub    r13,r14
  4073e2:	mov    QWORD PTR [rip+0x1ac17],r13        # 422000 <__swc_data_base_e121059d>
  4073e9:	mov    edx,r13d
  4073ec:	and    edx,0x7
  4073ef:	add    rdx,rdx
  4073f2:	mov    r14,QWORD PTR [r12+rdx*8]
  4073f6:	mov    r12,QWORD PTR [r12+rdx*8+0x8]
  4073fb:	imul   r13,r13,0x41a7
  407402:	movabs rdx,0x200000005
  40740c:	mov    rax,r13
  40740f:	mul    rdx
  407412:	mov    r15,rdx
  407415:	mov    rdx,r13
  407418:	sub    rdx,r15
  40741b:	shr    rdx,1
  40741e:	add    rdx,r15
  407421:	shr    rdx,0x1e
  407425:	imul   r15,rdx,0x7fffffff
  40742c:	sub    r13,r15
  40742f:	mov    QWORD PTR [rip+0x1abca],r13        # 422000 <__swc_data_base_e121059d>
  407436:	movabs rdx,0xaaaaaaaaaaaaaaab
  407440:	mov    rax,r13
  407443:	mul    rdx
  407446:	mov    r15,rdx
  407449:	shr    r15,1
  40744c:	lea    r15,[r15+r15*2]
  407450:	mov    rdx,r13
  407453:	sub    rdx,r15
  407456:	lea    r15,[rdx+0x7e8]
  40745d:	imul   r13,r13,0x41a7
  407464:	movabs rdx,0x200000005
  40746e:	mov    rax,r13
  407471:	mul    rdx
  407474:	mov    rdi,rdx
  407477:	mov    rdx,r13
  40747a:	sub    rdx,rdi
  40747d:	shr    rdx,1
  407480:	add    rdx,rdi
  407483:	shr    rdx,0x1e
  407487:	imul   rdi,rdx,0x7fffffff
  40748e:	sub    r13,rdi
  407491:	mov    QWORD PTR [rip+0x1ab68],r13        # 422000 <__swc_data_base_e121059d>
  407498:	movabs rdx,0xaaaaaaaaaaaaaaab
  4074a2:	mov    rax,r13
  4074a5:	mul    rdx
  4074a8:	mov    rdi,rdx
  4074ab:	shr    rdi,0x3
  4074af:	imul   rdi,rdi,0xc
  4074b3:	mov    rdx,r13
  4074b6:	sub    rdx,rdi
  4074b9:	lea    rdi,[rdx+0x1]
  4074bd:	imul   r13,r13,0x41a7
  4074c4:	movabs rdx,0x200000005
  4074ce:	mov    QWORD PTR [rsp+0x878],rcx
  4074d6:	mov    rcx,r11
  4074d9:	mov    rax,r13
  4074dc:	mul    rdx
  4074df:	mov    r11,rdx
  4074e2:	mov    rax,rcx
  4074e5:	mov    rcx,QWORD PTR [rsp+0x878]
  4074ed:	mov    rdx,r13
  4074f0:	sub    rdx,r11
  4074f3:	shr    rdx,1
  4074f6:	add    rdx,r11
  4074f9:	shr    rdx,0x1e
  4074fd:	imul   r11,rdx,0x7fffffff
  407504:	sub    r13,r11
  407507:	mov    QWORD PTR [rip+0x1aaf2],r13        # 422000 <__swc_data_base_e121059d>
  40750e:	mov    r11,r13
  407511:	shr    r11,0x2
  407515:	movabs rdx,0x4924924924924925
  40751f:	mov    QWORD PTR [rsp+0x880],rcx
  407527:	mov    rcx,rax
  40752a:	mov    rax,r11
  40752d:	mul    rdx
  407530:	mov    r11,rdx
  407533:	mov    rax,rcx
  407536:	mov    rcx,QWORD PTR [rsp+0x880]
  40753e:	shr    r11,1
  407541:	imul   r11,r11,0x1c
  407545:	mov    rdx,r13
  407548:	sub    rdx,r11
  40754b:	lea    r11,[rdx+0x1]
  40754f:	mov    QWORD PTR [rsp+0x7d8],r11
  407557:	imul   r13,r13,0x41a7
  40755e:	movabs rdx,0x200000005
  407568:	mov    QWORD PTR [rsp+0x888],rcx
  407570:	mov    rcx,rax
  407573:	mov    rax,r13
  407576:	mul    rdx
  407579:	mov    r11,rdx
  40757c:	mov    rax,rcx
  40757f:	mov    rcx,QWORD PTR [rsp+0x888]
  407587:	mov    rdx,r13
  40758a:	sub    rdx,r11
  40758d:	shr    rdx,1
  407590:	add    rdx,r11
  407593:	shr    rdx,0x1e
  407597:	imul   r11,rdx,0x7fffffff
  40759e:	sub    r13,r11
  4075a1:	mov    QWORD PTR [rip+0x1aa58],r13        # 422000 <__swc_data_base_e121059d>
  4075a8:	mov    r11,r13
  4075ab:	shr    r11,1
  4075ae:	movabs rdx,0xa3d70a3d70a3d70b
  4075b8:	mov    QWORD PTR [rsp+0x890],rcx
  4075c0:	mov    rcx,rax
  4075c3:	mov    rax,r11
  4075c6:	mul    rdx
  4075c9:	mov    r11,rdx
  4075cc:	mov    rax,rcx
  4075cf:	mov    rcx,QWORD PTR [rsp+0x890]
  4075d7:	shr    r11,0x4
  4075db:	imul   r11,r11,0x32
  4075df:	mov    rdx,r13
  4075e2:	sub    rdx,r11
  4075e5:	lea    r11,[rdx+0x1]
  4075e9:	mov    QWORD PTR [rsp+0x7e8],r11
  4075f1:	imul   r13,r13,0x41a7
  4075f8:	movabs rdx,0x200000005
  407602:	mov    QWORD PTR [rsp+0x898],rcx
  40760a:	mov    rcx,rax
  40760d:	mov    rax,r13
  407610:	mul    rdx
  407613:	mov    r11,rdx
  407616:	mov    rax,rcx
  407619:	mov    rcx,QWORD PTR [rsp+0x898]
  407621:	mov    rdx,r13
  407624:	sub    rdx,r11
  407627:	shr    rdx,1
  40762a:	add    rdx,r11
  40762d:	shr    rdx,0x1e
  407631:	imul   r11,rdx,0x7fffffff
  407638:	sub    r13,r11
  40763b:	mov    QWORD PTR [rip+0x1a9be],r13        # 422000 <__swc_data_base_e121059d>
  407642:	movabs rdx,0xa7f0aa6670e5710d
  40764c:	mov    QWORD PTR [rsp+0x8a0],rcx
  407654:	mov    rcx,rax
  407657:	mov    rax,r13
  40765a:	mul    rdx
  40765d:	mov    rax,rcx
  407660:	mov    rcx,QWORD PTR [rsp+0x8a0]
  407668:	shr    rdx,0x10
  40766c:	imul   rdx,rdx,0x1863c
  407673:	sub    r13,rdx
  407676:	lea    r11,[r13+0x64]
  40767a:	mov    QWORD PTR [rsp+0x7f8],r11
  407682:	vxorps xmm0,xmm0,xmm0
  407686:	vmovups XMMWORD PTR [rbx+0xa0],xmm0
  40768e:	mov    QWORD PTR [rbx+0xb0],0x0
  407699:	xor    r13d,r13d
  40769c:	mov    rdx,r8
  40769f:	test   r8,r8
  4076a2:	jne    4076ae <__swc_fn_e121059d_000003_68d30882+0x3ae>
  4076a4:	mov    BYTE PTR [r9],0x30
  4076a8:	mov    r13d,0x1
  4076ae:	vmovsd xmm6,QWORD PTR [rsp+0x800]
  4076b7:	vmovsd xmm7,QWORD PTR [rsp+0x8a8]
  4076c0:	test   rdx,rdx
  4076c3:	jbe    407730 <__swc_fn_e121059d_000003_68d30882+0x430>
  4076c9:	cs nop WORD PTR [rax+rax*1+0x0]
  4076d3:	cs nop WORD PTR [rax+rax*1+0x0]
  4076dd:	nop    DWORD PTR [rax]
  4076e0:	mov    r8,rdx
  4076e3:	vmovq  xmm6,rdx
  4076e8:	movabs rdx,0xcccccccccccccccd
  4076f2:	vmovq  r11,xmm6
  4076f7:	vmovq  xmm7,rcx
  4076fc:	mov    rcx,rax
  4076ff:	mov    rax,r8
  407702:	mul    rdx
  407705:	mov    r8,rdx
  407708:	mov    rax,rcx
  40770b:	vmovq  rcx,xmm7
  407710:	shr    r8,0x3
  407714:	imul   r8,r8,0xa
  407718:	sub    r11,r8
  40771b:	lea    r8,[r11+0x30]
  40771f:	mov    BYTE PTR [r9+r13*1],r8b
  407723:	add    r13,0x1
  407727:	shr    rdx,0x3
  40772b:	test   rdx,rdx
  40772e:	ja     4076e0 <__swc_fn_e121059d_000003_68d30882+0x3e0>
  407730:	vmovsd QWORD PTR [rsp+0x800],xmm6
  407739:	vmovsd QWORD PTR [rsp+0x8a8],xmm7
  407742:	test   r13,r13
  407745:	jbe    407766 <__swc_fn_e121059d_000003_68d30882+0x466>
  407747:	nop    WORD PTR [rax+rax*1+0x0]
  407750:	lea    rdx,[r13-0x1]
  407754:	mov    r13,rdx
  407757:	mov    dl,BYTE PTR [r9+rdx*1]
  40775b:	mov    BYTE PTR [rsi+rcx*1],dl
  40775e:	inc    rcx
  407761:	test   r13,r13
  407764:	ja     407750 <__swc_fn_e121059d_000003_68d30882+0x450>
  407766:	mov    BYTE PTR [rsi+rcx*1],0x2c
  40776a:	inc    rcx
  40776d:	xor    edx,edx
  40776f:	test   r12,r12
  407772:	jbe    407795 <__swc_fn_e121059d_000003_68d30882+0x495>
  407774:	cs nop WORD PTR [rax+rax*1+0x0]
  40777e:	xchg   ax,ax
  407780:	mov    r8b,BYTE PTR [r14+rdx*1]
  407784:	mov    BYTE PTR [rsi+rcx*1],r8b
  407788:	add    rcx,0x1
  40778c:	add    rdx,0x1
  407790:	cmp    rdx,r12
  407793:	jb     407780 <__swc_fn_e121059d_000003_68d30882+0x480>
  407795:	mov    BYTE PTR [rsi+rcx*1],0x2c
  407799:	inc    rcx
  40779c:	vxorps xmm0,xmm0,xmm0
  4077a0:	vmovups XMMWORD PTR [rbx+0xf0],xmm0
  4077a8:	mov    QWORD PTR [rbx+0x100],0x0
  4077b3:	xor    r8d,r8d
  4077b6:	mov    r11,r15
  4077b9:	test   r15,r15
  4077bc:	jne    4077c8 <__swc_fn_e121059d_000003_68d30882+0x4c8>
  4077be:	mov    BYTE PTR [r10],0x30
  4077c2:	mov    r8d,0x1
  4077c8:	test   r11,r11
  4077cb:	jbe    40780c <__swc_fn_e121059d_000003_68d30882+0x50c>
  4077cd:	nop    DWORD PTR [rax]
  4077d0:	movabs rdx,0xcccccccccccccccd
  4077da:	mov    r14,rax
  4077dd:	mov    rax,r11
  4077e0:	mul    rdx
  4077e3:	mov    r12,rdx
  4077e6:	mov    rax,r14
  4077e9:	shr    r12,0x3
  4077ed:	imul   r12,r12,0xa
  4077f1:	sub    r11,r12
  4077f4:	lea    r11,[r11+0x30]
  4077f8:	mov    BYTE PTR [r10+r8*1],r11b
  4077fc:	add    r8,0x1
  407800:	mov    r11,rdx
  407803:	shr    r11,0x3
  407807:	test   r11,r11
  40780a:	ja     4077d0 <__swc_fn_e121059d_000003_68d30882+0x4d0>
  40780c:	test   r8,r8
  40780f:	jbe    407836 <__swc_fn_e121059d_000003_68d30882+0x536>
  407811:	cs nop WORD PTR [rax+rax*1+0x0]
  40781b:	nop    DWORD PTR [rax+rax*1+0x0]
  407820:	lea    rdx,[r8-0x1]
  407824:	mov    r8,rdx
  407827:	mov    dl,BYTE PTR [r10+rdx*1]
  40782b:	mov    BYTE PTR [rsi+rcx*1],dl
  40782e:	inc    rcx
  407831:	test   r8,r8
  407834:	ja     407820 <__swc_fn_e121059d_000003_68d30882+0x520>
  407836:	mov    BYTE PTR [rsi+rcx*1],0x2d
  40783a:	movabs rdx,0xcccccccccccccccd
  407844:	mov    r11,rax
  407847:	mov    rax,rdi
  40784a:	mul    rdx
  40784d:	mov    r8,rdx
  407850:	mov    r14,r11
  407853:	shr    r8,0x3
  407857:	lea    rdx,[r8+0x30]
  40785b:	mov    BYTE PTR [rsi+rcx*1+0x1],dl
  40785f:	imul   r8,r8,0xa
  407863:	sub    rdi,r8
  407866:	lea    rdx,[rdi+0x30]
  40786a:	mov    BYTE PTR [rsi+rcx*1+0x2],dl
  40786e:	mov    BYTE PTR [rsi+rcx*1+0x3],0x2d
  407873:	mov    r11,QWORD PTR [rsp+0x7d8]
  40787b:	movabs rdx,0xcccccccccccccccd
  407885:	mov    rax,r11
  407888:	mul    rdx
  40788b:	mov    r8,rdx
  40788e:	mov    rax,r14
  407891:	shr    r8,0x3
  407895:	lea    rdx,[r8+0x30]
  407899:	mov    BYTE PTR [rsi+rcx*1+0x4],dl
  40789d:	imul   r8,r8,0xa
  4078a1:	sub    r11,r8
  4078a4:	lea    rdx,[r11+0x30]
  4078a8:	mov    BYTE PTR [rsi+rcx*1+0x5],dl
  4078ac:	mov    BYTE PTR [rsi+rcx*1+0x6],0x2c
  4078b1:	lea    rcx,[rcx+0x7]
  4078b5:	vxorps xmm0,xmm0,xmm0
  4078b9:	vmovups XMMWORD PTR [rbx+0x168],xmm0
  4078c1:	mov    QWORD PTR [rbx+0x178],0x0
  4078cc:	xor    r8d,r8d
  4078cf:	mov    r11,QWORD PTR [rsp+0x7e8]
  4078d7:	mov    rdi,r11
  4078da:	test   r11,r11
  4078dd:	je     4078e9 <__swc_fn_e121059d_000003_68d30882+0x5e9>
  4078df:	mov    r11,QWORD PTR [rsp+0x7b8]
  4078e7:	jmp    4078fb <__swc_fn_e121059d_000003_68d30882+0x5fb>
  4078e9:	mov    r11,QWORD PTR [rsp+0x7b8]
  4078f1:	mov    BYTE PTR [r11],0x30
  4078f5:	mov    r8d,0x1
  4078fb:	test   rdi,rdi
  4078fe:	jbe    40793c <__swc_fn_e121059d_000003_68d30882+0x63c>
  407900:	movabs rdx,0xcccccccccccccccd
  40790a:	mov    r14,rax
  40790d:	mov    rax,rdi
  407910:	mul    rdx
  407913:	mov    r12,rdx
  407916:	mov    rax,r14
  407919:	shr    r12,0x3
  40791d:	imul   r12,r12,0xa
  407921:	sub    rdi,r12
  407924:	lea    rdi,[rdi+0x30]
  407928:	mov    BYTE PTR [r11+r8*1],dil
  40792c:	add    r8,0x1
  407930:	mov    rdi,rdx
  407933:	shr    rdi,0x3
  407937:	test   rdi,rdi
  40793a:	ja     407900 <__swc_fn_e121059d_000003_68d30882+0x600>
  40793c:	test   r8,r8
  40793f:	jbe    407966 <__swc_fn_e121059d_000003_68d30882+0x666>
  407941:	cs nop WORD PTR [rax+rax*1+0x0]
  40794b:	nop    DWORD PTR [rax+rax*1+0x0]
  407950:	lea    rdx,[r8-0x1]
  407954:	mov    r8,rdx
  407957:	mov    dl,BYTE PTR [r11+rdx*1]
  40795b:	mov    BYTE PTR [rsi+rcx*1],dl
  40795e:	inc    rcx
  407961:	test   r8,r8
  407964:	ja     407950 <__swc_fn_e121059d_000003_68d30882+0x650>
  407966:	mov    BYTE PTR [rsi+rcx*1],0x2c
  40796a:	inc    rcx
  40796d:	vxorps xmm0,xmm0,xmm0
  407971:	vmovups XMMWORD PTR [rbx+0x1b0],xmm0
  407979:	mov    QWORD PTR [rbx+0x1c0],0x0
  407984:	xor    r8d,r8d
  407987:	mov    rdi,QWORD PTR [rsp+0x7f8]
  40798f:	mov    r12,rdi
  407992:	shr    r12,0x2
  407996:	movabs rdx,0x28f5c28f5c28f5c3
  4079a0:	mov    r11,rax
  4079a3:	mov    rax,r12
  4079a6:	mul    rdx
  4079a9:	mov    r12,rdx
  4079ac:	mov    rax,r11
  4079af:	shr    r12,0x2
  4079b3:	mov    r13,r12
  4079b6:	test   r12,r12
  4079b9:	je     4079c5 <__swc_fn_e121059d_000003_68d30882+0x6c5>
  4079bb:	mov    r14,QWORD PTR [rsp+0x7c0]
  4079c3:	jmp    4079d7 <__swc_fn_e121059d_000003_68d30882+0x6d7>
  4079c5:	mov    r14,QWORD PTR [rsp+0x7c0]
  4079cd:	mov    BYTE PTR [r14],0x30
  4079d1:	mov    r8d,0x1
  4079d7:	test   r13,r13
  4079da:	jbe    407a1c <__swc_fn_e121059d_000003_68d30882+0x71c>
  4079dc:	nop    DWORD PTR [rax+0x0]
  4079e0:	movabs rdx,0xcccccccccccccccd
  4079ea:	mov    r11,rax
  4079ed:	mov    rax,r13
  4079f0:	mul    rdx
  4079f3:	mov    r15,rdx
  4079f6:	mov    rax,r11
  4079f9:	shr    r15,0x3
  4079fd:	imul   r15,r15,0xa
  407a01:	sub    r13,r15
  407a04:	lea    r13,[r13+0x30]
  407a08:	mov    BYTE PTR [r14+r8*1],r13b
  407a0c:	add    r8,0x1
  407a10:	mov    r13,rdx
  407a13:	shr    r13,0x3
  407a17:	test   r13,r13
  407a1a:	ja     4079e0 <__swc_fn_e121059d_000003_68d30882+0x6e0>
  407a1c:	test   r8,r8
  407a1f:	jbe    407a46 <__swc_fn_e121059d_000003_68d30882+0x746>
  407a21:	cs nop WORD PTR [rax+rax*1+0x0]
  407a2b:	nop    DWORD PTR [rax+rax*1+0x0]
  407a30:	lea    rdx,[r8-0x1]
  407a34:	mov    r8,rdx
  407a37:	mov    dl,BYTE PTR [r14+rdx*1]
  407a3b:	mov    BYTE PTR [rsi+rcx*1],dl
  407a3e:	inc    rcx
  407a41:	test   r8,r8
  407a44:	ja     407a30 <__swc_fn_e121059d_000003_68d30882+0x730>
  407a46:	mov    BYTE PTR [rsi+rcx*1],0x2e
  407a4a:	imul   r12,r12,0x64
  407a4e:	sub    rdi,r12
  407a51:	movabs rdx,0xcccccccccccccccd
  407a5b:	mov    r11,rax
  407a5e:	mov    rax,rdi
  407a61:	mul    rdx
  407a64:	mov    r8,rdx
  407a67:	mov    rax,r11
  407a6a:	shr    r8,0x3
  407a6e:	lea    rdx,[r8+0x30]
  407a72:	mov    BYTE PTR [rsi+rcx*1+0x1],dl
  407a76:	imul   r8,r8,0xa
  407a7a:	sub    rdi,r8
  407a7d:	lea    rdx,[rdi+0x30]
  407a81:	mov    BYTE PTR [rsi+rcx*1+0x2],dl
  407a85:	lea    rdi,[rcx+0x3]
  407a89:	mov    QWORD PTR [rsp+0x808],rdi
  407a91:	mov    rcx,rdi
  407a94:	mov    r8,QWORD PTR [rsp+0x7b0]
  407a9c:	add    r8,0x1
  407aa0:	mov    QWORD PTR [rsp+0x7b0],r8
  407aa8:	cmp    r8,0x61a80
  407aaf:	jb     407390 <__swc_fn_e121059d_000003_68d30882+0x90>
  407ab5:	call   40f880 <__swc_fn_e121059d_000002_1ca87929>
  407aba:	vmovups xmm6,xmm0
  407abe:	vxorps xmm0,xmm0,xmm0
  407ac2:	vmovups XMMWORD PTR [rbx+0x208],xmm0
  407aca:	vmovups XMMWORD PTR [rbx+0x218],xmm0
  407ad2:	vmovups XMMWORD PTR [rbx+0x228],xmm0
  407ada:	mov    QWORD PTR [rbx+0x238],0x0
  407ae5:	lea    rcx,[rbx+0x208]
  407aec:	mov    edx,0x40
  407af1:	mov    r8,rsi
  407af4:	call   407270 <__swc_fn_e121059d_000000_e7f0b636>
  407af9:	mov    ecx,0x200
  407afe:	call   40b2a0 <__swc_fn_e121059d_000001_2744b483>
  407b03:	mov    r12,rax
  407b06:	mov    QWORD PTR [rsp+0x810],rax
  407b0e:	mov    ecx,0x200
  407b13:	call   40b2a0 <__swc_fn_e121059d_000001_2744b483>
  407b18:	mov    QWORD PTR [rsp+0x818],rax
  407b20:	mov    ecx,0x200
  407b25:	call   40b2a0 <__swc_fn_e121059d_000001_2744b483>
  407b2a:	mov    QWORD PTR [rsp+0x820],rax
  407b32:	mov    ecx,0x200
  407b37:	call   40b2a0 <__swc_fn_e121059d_000001_2744b483>
  407b3c:	mov    QWORD PTR [rsp+0x828],rax
  407b44:	xor    ecx,ecx
  407b46:	xor    r15d,r15d
  407b49:	mov    QWORD PTR [rsp+0x830],r15
  407b51:	vmovups xmm7,XMMWORD PTR [rip+0xb737]        # 413290 <__swc_rdata_base_e121059d+0x180>
  407b59:	vmovups xmm8,XMMWORD PTR [rip+0xb73f]        # 4132a0 <__swc_rdata_base_e121059d+0x190>
  407b61:	vmovsd xmm9,QWORD PTR [rip+0xb767]        # 4132d0 <__swc_rdata_base_e121059d+0x1c0>
  407b69:	cmp    rcx,rdi
  407b6c:	jae    4080ac <__swc_fn_e121059d_000003_68d30882+0xdac>
  407b72:	cs nop WORD PTR [rax+rax*1+0x0]
  407b7c:	nop    DWORD PTR [rax+0x0]
  407b80:	mov    r15,rcx
  407b83:	cmp    rcx,rdi
  407b86:	jae    407c00 <__swc_fn_e121059d_000003_68d30882+0x900>
  407b8c:	mov    rax,rdi
  407b8f:	sub    rax,r15
  407b92:	cmp    rax,0x4
  407b96:	jb     407be0 <__swc_fn_e121059d_000003_68d30882+0x8e0>
  407b98:	mov    rax,rdi
  407b9b:	sub    rax,0x3
  407b9f:	cmp    r15,rax
  407ba2:	jae    407be0 <__swc_fn_e121059d_000003_68d30882+0x8e0>
  407ba4:	cs nop WORD PTR [rax+rax*1+0x0]
  407bae:	xchg   ax,ax
  407bb0:	cmp    BYTE PTR [rsi+r15*1],0xa
  407bb5:	je     407c00 <__swc_fn_e121059d_000003_68d30882+0x900>
  407bb7:	cmp    BYTE PTR [rsi+r15*1+0x1],0xa
  407bbd:	je     407bf1 <__swc_fn_e121059d_000003_68d30882+0x8f1>
  407bbf:	cmp    BYTE PTR [rsi+r15*1+0x2],0xa
  407bc5:	je     407bf6 <__swc_fn_e121059d_000003_68d30882+0x8f6>
  407bc7:	cmp    BYTE PTR [rsi+r15*1+0x3],0xa
  407bcd:	je     407bfc <__swc_fn_e121059d_000003_68d30882+0x8fc>
  407bcf:	lea    r15,[r15+0x4]
  407bd3:	cmp    r15,rax
  407bd6:	jb     407bb0 <__swc_fn_e121059d_000003_68d30882+0x8b0>
  407bd8:	nop    DWORD PTR [rax+rax*1+0x0]
  407be0:	cmp    r15,rdi
  407be3:	jae    407c00 <__swc_fn_e121059d_000003_68d30882+0x900>
  407be5:	cmp    BYTE PTR [rsi+r15*1],0xa
  407bea:	je     407c00 <__swc_fn_e121059d_000003_68d30882+0x900>
  407bec:	inc    r15
  407bef:	jmp    407be0 <__swc_fn_e121059d_000003_68d30882+0x8e0>
  407bf1:	inc    r15
  407bf4:	jmp    407c00 <__swc_fn_e121059d_000003_68d30882+0x900>
  407bf6:	lea    r15,[r15+0x2]
  407bfa:	jmp    407c00 <__swc_fn_e121059d_000003_68d30882+0x900>
  407bfc:	lea    r15,[r15+0x3]
  407c00:	cmp    rcx,r15
  407c03:	jae    407c80 <__swc_fn_e121059d_000003_68d30882+0x980>
  407c09:	mov    rax,r15
  407c0c:	sub    rax,rcx
  407c0f:	cmp    rax,0x4
  407c13:	jb     407c60 <__swc_fn_e121059d_000003_68d30882+0x960>
  407c19:	mov    rax,r15
  407c1c:	sub    rax,0x3
  407c20:	cmp    rcx,rax
  407c23:	jae    407c60 <__swc_fn_e121059d_000003_68d30882+0x960>
  407c25:	cs nop WORD PTR [rax+rax*1+0x0]
  407c2f:	nop
  407c30:	cmp    BYTE PTR [rsi+rcx*1],0x2c
  407c34:	je     407c80 <__swc_fn_e121059d_000003_68d30882+0x980>
  407c36:	cmp    BYTE PTR [rsi+rcx*1+0x1],0x2c
  407c3b:	je     407c71 <__swc_fn_e121059d_000003_68d30882+0x971>
  407c3d:	cmp    BYTE PTR [rsi+rcx*1+0x2],0x2c
  407c42:	je     407c76 <__swc_fn_e121059d_000003_68d30882+0x976>
  407c44:	cmp    BYTE PTR [rsi+rcx*1+0x3],0x2c
  407c49:	je     407c7c <__swc_fn_e121059d_000003_68d30882+0x97c>
  407c4b:	lea    rcx,[rcx+0x4]
  407c4f:	cmp    rcx,rax
  407c52:	jb     407c30 <__swc_fn_e121059d_000003_68d30882+0x930>
  407c54:	cs nop WORD PTR [rax+rax*1+0x0]
  407c5e:	xchg   ax,ax
  407c60:	cmp    rcx,r15
  407c63:	jae    407c80 <__swc_fn_e121059d_000003_68d30882+0x980>
  407c65:	cmp    BYTE PTR [rsi+rcx*1],0x2c
  407c69:	je     407c80 <__swc_fn_e121059d_000003_68d30882+0x980>
  407c6b:	add    rcx,0x1
  407c6f:	jmp    407c60 <__swc_fn_e121059d_000003_68d30882+0x960>
  407c71:	inc    rcx
  407c74:	jmp    407c80 <__swc_fn_e121059d_000003_68d30882+0x980>
  407c76:	lea    rcx,[rcx+0x2]
  407c7a:	jmp    407c80 <__swc_fn_e121059d_000003_68d30882+0x980>
  407c7c:	lea    rcx,[rcx+0x3]
  407c80:	lea    rdi,[rcx+0x1]
  407c84:	mov    rcx,rdi
  407c87:	cmp    rdi,r15
  407c8a:	jae    407d00 <__swc_fn_e121059d_000003_68d30882+0xa00>
  407c90:	mov    rax,r15
  407c93:	sub    rax,rcx
  407c96:	cmp    rax,0x4
  407c9a:	jb     407ce0 <__swc_fn_e121059d_000003_68d30882+0x9e0>
  407c9c:	mov    rax,r15
  407c9f:	sub    rax,0x3
  407ca3:	cmp    rcx,rax
  407ca6:	jae    407ce0 <__swc_fn_e121059d_000003_68d30882+0x9e0>
  407ca8:	nop    DWORD PTR [rax+rax*1+0x0]
  407cb0:	cmp    BYTE PTR [rsi+rcx*1],0x2c
  407cb4:	je     407d00 <__swc_fn_e121059d_000003_68d30882+0xa00>
  407cb6:	cmp    BYTE PTR [rsi+rcx*1+0x1],0x2c
  407cbb:	je     407cf1 <__swc_fn_e121059d_000003_68d30882+0x9f1>
  407cbd:	cmp    BYTE PTR [rsi+rcx*1+0x2],0x2c
  407cc2:	je     407cf6 <__swc_fn_e121059d_000003_68d30882+0x9f6>
  407cc4:	cmp    BYTE PTR [rsi+rcx*1+0x3],0x2c
  407cc9:	je     407cfc <__swc_fn_e121059d_000003_68d30882+0x9fc>
  407ccb:	lea    rcx,[rcx+0x4]
  407ccf:	cmp    rcx,rax
  407cd2:	jb     407cb0 <__swc_fn_e121059d_000003_68d30882+0x9b0>
  407cd4:	cs nop WORD PTR [rax+rax*1+0x0]
  407cde:	xchg   ax,ax
  407ce0:	cmp    rcx,r15
  407ce3:	jae    407d00 <__swc_fn_e121059d_000003_68d30882+0xa00>
  407ce5:	cmp    BYTE PTR [rsi+rcx*1],0x2c
  407ce9:	je     407d00 <__swc_fn_e121059d_000003_68d30882+0xa00>
  407ceb:	add    rcx,0x1
  407cef:	jmp    407ce0 <__swc_fn_e121059d_000003_68d30882+0x9e0>
  407cf1:	inc    rcx
  407cf4:	jmp    407d00 <__swc_fn_e121059d_000003_68d30882+0xa00>
  407cf6:	lea    rcx,[rcx+0x2]
  407cfa:	jmp    407d00 <__swc_fn_e121059d_000003_68d30882+0xa00>
  407cfc:	lea    rcx,[rcx+0x3]
  407d00:	mov    r14,rcx
  407d03:	sub    r14,rdi
  407d06:	add    rcx,0x1
  407d0a:	cmp    rcx,r15
  407d0d:	jae    407da0 <__swc_fn_e121059d_000003_68d30882+0xaa0>
  407d13:	mov    rax,r15
  407d16:	sub    rax,rcx
  407d19:	cmp    rax,0x4
  407d1d:	jb     407d80 <__swc_fn_e121059d_000003_68d30882+0xa80>
  407d23:	mov    rax,r15
  407d26:	sub    rax,0x3
  407d2a:	cmp    rcx,rax
  407d2d:	jae    407d80 <__swc_fn_e121059d_000003_68d30882+0xa80>
  407d33:	cs nop WORD PTR [rax+rax*1+0x0]
  407d3d:	cs nop WORD PTR [rax+rax*1+0x0]
  407d47:	nop    WORD PTR [rax+rax*1+0x0]
  407d50:	cmp    BYTE PTR [rsi+rcx*1],0x2c
  407d54:	je     407da0 <__swc_fn_e121059d_000003_68d30882+0xaa0>
  407d56:	cmp    BYTE PTR [rsi+rcx*1+0x1],0x2c
  407d5b:	je     407d91 <__swc_fn_e121059d_000003_68d30882+0xa91>
  407d5d:	cmp    BYTE PTR [rsi+rcx*1+0x2],0x2c
  407d62:	je     407d96 <__swc_fn_e121059d_000003_68d30882+0xa96>
  407d64:	cmp    BYTE PTR [rsi+rcx*1+0x3],0x2c
  407d69:	je     407d9c <__swc_fn_e121059d_000003_68d30882+0xa9c>
  407d6b:	lea    rcx,[rcx+0x4]
  407d6f:	cmp    rcx,rax
  407d72:	jb     407d50 <__swc_fn_e121059d_000003_68d30882+0xa50>
  407d74:	cs nop WORD PTR [rax+rax*1+0x0]
  407d7e:	xchg   ax,ax
  407d80:	cmp    rcx,r15
  407d83:	jae    407da0 <__swc_fn_e121059d_000003_68d30882+0xaa0>
  407d85:	cmp    BYTE PTR [rsi+rcx*1],0x2c
  407d89:	je     407da0 <__swc_fn_e121059d_000003_68d30882+0xaa0>
  407d8b:	add    rcx,0x1
  407d8f:	jmp    407d80 <__swc_fn_e121059d_000003_68d30882+0xa80>
  407d91:	inc    rcx
  407d94:	jmp    407da0 <__swc_fn_e121059d_000003_68d30882+0xaa0>
  407d96:	lea    rcx,[rcx+0x2]
  407d9a:	jmp    407da0 <__swc_fn_e121059d_000003_68d30882+0xaa0>
  407d9c:	lea    rcx,[rcx+0x3]
  407da0:	add    rcx,0x1
  407da4:	xor    r13d,r13d
  407da7:	cmp    rcx,r15
  407daa:	jae    407dce <__swc_fn_e121059d_000003_68d30882+0xace>
  407dac:	nop    DWORD PTR [rax+0x0]
  407db0:	movzx  edx,BYTE PTR [rsi+rcx*1]
  407db4:	cmp    edx,0x2c
  407db7:	je     407dce <__swc_fn_e121059d_000003_68d30882+0xace>
  407db9:	lea    r8,[r13+r13*4+0x0]
  407dbe:	sub    dl,0x30
  407dc1:	lea    r13,[rdx+r8*2]
  407dc5:	add    rcx,0x1
  407dc9:	cmp    rcx,r15
  407dcc:	jb     407db0 <__swc_fn_e121059d_000003_68d30882+0xab0>
  407dce:	add    rcx,0x1
  407dd2:	xor    edx,edx
  407dd4:	cmp    rcx,r15
  407dd7:	jae    407e10 <__swc_fn_e121059d_000003_68d30882+0xb10>
  407dd9:	cs nop WORD PTR [rax+rax*1+0x0]
  407de3:	cs nop WORD PTR [rax+rax*1+0x0]
  407ded:	nop    DWORD PTR [rax]
  407df0:	movzx  r8d,BYTE PTR [rsi+rcx*1]
  407df5:	cmp    r8d,0x2e
  407df9:	je     407e10 <__swc_fn_e121059d_000003_68d30882+0xb10>
  407dfb:	lea    rdx,[rdx+rdx*4]
  407dff:	sub    r8b,0x30
  407e03:	lea    rdx,[r8+rdx*2]
  407e07:	add    rcx,0x1
  407e0b:	cmp    rcx,r15
  407e0e:	jb     407df0 <__swc_fn_e121059d_000003_68d30882+0xaf0>
  407e10:	add    rcx,0x1
  407e14:	xor    r8d,r8d
  407e17:	cmp    rcx,r15
  407e1a:	jae    407e3a <__swc_fn_e121059d_000003_68d30882+0xb3a>
  407e1c:	nop    DWORD PTR [rax+0x0]
  407e20:	lea    r8,[r8+r8*4]
  407e24:	movzx  r9d,BYTE PTR [rsi+rcx*1]
  407e29:	sub    r9b,0x30
  407e2d:	lea    r8,[r9+r8*2]
  407e31:	add    rcx,0x1
  407e35:	cmp    rcx,r15
  407e38:	jb     407e20 <__swc_fn_e121059d_000003_68d30882+0xb20>
  407e3a:	vmovq  xmm0,rdx
  407e3f:	vpunpckldq xmm0,xmm0,xmm7
  407e43:	vsubpd xmm0,xmm0,xmm8
  407e48:	vpunpckhqdq xmm1,xmm0,xmm0
  407e4c:	vaddsd xmm0,xmm0,xmm1
  407e50:	vmovq  xmm1,r8
  407e55:	vpunpckldq xmm1,xmm1,xmm7
  407e59:	vsubpd xmm1,xmm1,xmm8
  407e5e:	vpunpckhqdq xmm2,xmm1,xmm1
  407e62:	vaddsd xmm1,xmm1,xmm2
  407e66:	vdivsd xmm1,xmm1,xmm9
  407e6b:	vaddsd xmm10,xmm0,xmm1
  407e6f:	mov    ecx,0x811c9dc5
  407e74:	xor    edx,edx
  407e76:	test   r14,r14
  407e79:	jbe    407ef3 <__swc_fn_e121059d_000003_68d30882+0xbf3>
  407e7f:	mov    r8,QWORD PTR [rbx+0x228]
  407e86:	add    r8,rdi
  407e89:	cmp    r14,0x4
  407e8d:	jb     407ee0 <__swc_fn_e121059d_000003_68d30882+0xbe0>
  407e93:	lea    r9,[r14-0x3]
  407e97:	nop    WORD PTR [rax+rax*1+0x0]
  407ea0:	xor    cl,BYTE PTR [r8+rdx*1]
  407ea4:	imul   ecx,ecx,0x1000193
  407eaa:	xor    cl,BYTE PTR [r8+rdx*1+0x1]
  407eaf:	imul   ecx,ecx,0x1000193
  407eb5:	xor    cl,BYTE PTR [r8+rdx*1+0x2]
  407eba:	imul   ecx,ecx,0x1000193
  407ec0:	xor    cl,BYTE PTR [r8+rdx*1+0x3]
  407ec5:	imul   ecx,ecx,0x1000193
  407ecb:	add    rdx,0x4
  407ecf:	cmp    rdx,r9
  407ed2:	jb     407ea0 <__swc_fn_e121059d_000003_68d30882+0xba0>
  407ed4:	cmp    rdx,r14
  407ed7:	jae    407ef3 <__swc_fn_e121059d_000003_68d30882+0xbf3>
  407ed9:	nop    DWORD PTR [rax+0x0]
  407ee0:	xor    cl,BYTE PTR [r8+rdx*1]
  407ee4:	imul   ecx,ecx,0x1000193
  407eea:	add    rdx,0x1
  407eee:	cmp    rdx,r14
  407ef1:	jb     407ee0 <__swc_fn_e121059d_000003_68d30882+0xbe0>
  407ef3:	and    rcx,QWORD PTR [rbx+0x230]
  407efa:	mov    rsi,rcx
  407efd:	mov    QWORD PTR [rsp+0x838],r15
  407f05:	mov    r15,QWORD PTR [rbx+0x220]
  407f0c:	mov    QWORD PTR [rsp+0x840],r13
  407f14:	mov    r13,QWORD PTR [rbx+0x210]
  407f1b:	cmp    BYTE PTR [r15+rsi*1],0x0
  407f20:	je     407f70 <__swc_fn_e121059d_000003_68d30882+0xc70>
  407f22:	cs nop WORD PTR [rax+rax*1+0x0]
  407f2c:	nop    DWORD PTR [rax+0x0]
  407f30:	cmp    QWORD PTR [r13+rsi*8+0x0],r14
  407f35:	jne    407f5f <__swc_fn_e121059d_000003_68d30882+0xc5f>
  407f37:	mov    rax,QWORD PTR [rbx+0x208]
  407f3e:	mov    rax,QWORD PTR [rax+rsi*8]
  407f42:	mov    rcx,QWORD PTR [rbx+0x228]
  407f49:	add    rax,rcx
  407f4c:	lea    rdx,[rcx+rdi*1]
  407f50:	mov    rcx,rax
  407f53:	mov    r8,r14
  407f56:	call   40a0b0 <__swc_fn_e121059d_000111_3dc01326>
  407f5b:	test   eax,eax
  407f5d:	je     407f70 <__swc_fn_e121059d_000003_68d30882+0xc70>
  407f5f:	inc    rsi
  407f62:	and    rsi,QWORD PTR [rbx+0x230]
  407f69:	cmp    BYTE PTR [r15+rsi*1],0x0
  407f6e:	jne    407f30 <__swc_fn_e121059d_000003_68d30882+0xc30>
  407f70:	cmp    BYTE PTR [r15+rsi*1],0x0
  407f75:	je     407f9c <__swc_fn_e121059d_000003_68d30882+0xc9c>
  407f77:	mov    rdi,QWORD PTR [rsp+0x818]
  407f7f:	mov    r14,QWORD PTR [rsp+0x820]
  407f87:	mov    r15,QWORD PTR [rsp+0x828]
  407f8f:	mov    r13,QWORD PTR [rsp+0x840]
  407f97:	jmp    40802c <__swc_fn_e121059d_000003_68d30882+0xd2c>
  407f9c:	mov    rcx,QWORD PTR [rbx+0x238]
  407fa3:	mov    rdx,QWORD PTR [rbx+0x220]
  407faa:	mov    BYTE PTR [rdx+rsi*1],0x1
  407fae:	mov    rdx,QWORD PTR [rbx+0x208]
  407fb5:	mov    QWORD PTR [rdx+rsi*8],rdi
  407fb9:	mov    rdx,QWORD PTR [rbx+0x210]
  407fc0:	mov    QWORD PTR [rdx+rsi*8],r14
  407fc4:	mov    rdx,QWORD PTR [rbx+0x218]
  407fcb:	mov    QWORD PTR [rdx+rsi*8],rcx
  407fcf:	add    QWORD PTR [rbx+0x238],0x1
  407fd7:	mov    QWORD PTR [r12+rcx*8],0x1
  407fdf:	mov    rdi,QWORD PTR [rsp+0x818]
  407fe7:	mov    r13,QWORD PTR [rsp+0x840]
  407fef:	mov    QWORD PTR [rdi+rcx*8],r13
  407ff3:	vmovq  xmm0,r13
  407ff8:	vpunpckldq xmm0,xmm0,xmm7
  407ffc:	vsubpd xmm0,xmm0,xmm8
  408001:	vpunpckhqdq xmm1,xmm0,xmm0
  408005:	vaddsd xmm0,xmm0,xmm1
  408009:	vmulsd xmm0,xmm0,xmm10
  40800e:	mov    r14,QWORD PTR [rsp+0x820]
  408016:	vmovq  QWORD PTR [r14+rcx*8],xmm0
  40801c:	mov    r15,QWORD PTR [rsp+0x828]
  408024:	vmovq  QWORD PTR [r15+rcx*8],xmm10
  40802a:	jmp    408074 <__swc_fn_e121059d_000003_68d30882+0xd74>
  40802c:	mov    rcx,QWORD PTR [rbx+0x218]
  408033:	mov    rcx,QWORD PTR [rcx+rsi*8]
  408037:	inc    QWORD PTR [r12+rcx*8]
  40803b:	add    QWORD PTR [rdi+rcx*8],r13
  40803f:	vmovq  xmm0,r13
  408044:	vpunpckldq xmm0,xmm0,xmm7
  408048:	vsubpd xmm0,xmm0,xmm8
  40804d:	vpunpckhqdq xmm1,xmm0,xmm0
  408051:	vaddsd xmm0,xmm0,xmm1
  408055:	vmulsd xmm0,xmm0,xmm10
  40805a:	vaddsd xmm0,xmm0,QWORD PTR [r14+rcx*8]
  408060:	vmovq  QWORD PTR [r14+rcx*8],xmm0
  408066:	vcomisd xmm10,QWORD PTR [r15+rcx*8]
  40806c:	jbe    408074 <__swc_fn_e121059d_000003_68d30882+0xd74>
  40806e:	vmovq  QWORD PTR [r15+rcx*8],xmm10
  408074:	mov    rsi,QWORD PTR [rsp+0x830]
  40807c:	add    rsi,0x1
  408080:	mov    rcx,QWORD PTR [rsp+0x838]
  408088:	mov    QWORD PTR [rsp+0x830],rsi
  408090:	inc    rcx
  408093:	mov    rsi,QWORD PTR [rsp+0x7a8]
  40809b:	mov    rdi,QWORD PTR [rsp+0x808]
  4080a3:	cmp    rcx,rdi
  4080a6:	jb     407b80 <__swc_fn_e121059d_000003_68d30882+0x880>
  4080ac:	lea    r13,[rbx+0x320]
  4080b3:	mov    QWORD PTR [rsp+0x848],r13
  4080bb:	vxorps xmm0,xmm0,xmm0
  4080bf:	xor    ecx,ecx
  4080c1:	cs nop WORD PTR [rax+rax*1+0x0]
  4080cb:	cs nop WORD PTR [rax+rax*1+0x0]
  4080d5:	cs nop WORD PTR [rax+rax*1+0x0]
  4080df:	nop
  4080e0:	vmovdqu XMMWORD PTR [r13+rcx*1+0x0],xmm0
  4080e7:	add    rcx,0x10
  4080eb:	cmp    rcx,0x200
  4080f2:	jne    4080e0 <__swc_fn_e121059d_000003_68d30882+0xde0>
  4080f4:	lea    r15,[rbx+0x520]
  4080fb:	vxorps xmm0,xmm0,xmm0
  4080ff:	xor    ecx,ecx
  408101:	cs nop WORD PTR [rax+rax*1+0x0]
  40810b:	cs nop WORD PTR [rax+rax*1+0x0]
  408115:	cs nop WORD PTR [rax+rax*1+0x0]
  40811f:	nop
  408120:	vmovdqu XMMWORD PTR [r15+rcx*1],xmm0
  408126:	add    rcx,0x10
  40812a:	cmp    rcx,0x200
  408131:	jne    408120 <__swc_fn_e121059d_000003_68d30882+0xe20>
  408133:	xor    edi,edi
  408135:	xor    ecx,ecx
  408137:	mov    rsi,rdi
  40813a:	cs nop WORD PTR [rax+rax*1+0x0]
  408144:	cs nop WORD PTR [rax+rax*1+0x0]
  40814e:	xchg   ax,ax
  408150:	mov    rdx,QWORD PTR [rbx+0x220]
  408157:	cmp    BYTE PTR [rdx+rcx*1],0x0
  40815b:	je     408167 <__swc_fn_e121059d_000003_68d30882+0xe67>
  40815d:	mov    QWORD PTR [r15+rdi*8],rcx
  408161:	inc    rdi
  408164:	mov    rsi,rdi
  408167:	add    rcx,0x1
  40816b:	cmp    rcx,0x40
  40816f:	jb     408150 <__swc_fn_e121059d_000003_68d30882+0xe50>
  408171:	mov    QWORD PTR [rsp+0x850],rsi
  408179:	xor    ecx,ecx
  40817b:	test   rdi,rdi
  40817e:	jbe    40818e <__swc_fn_e121059d_000003_68d30882+0xe8e>
  408180:	mov    QWORD PTR [r13+rcx*8+0x0],rcx
  408185:	add    rcx,0x1
  408189:	cmp    rcx,rdi
  40818c:	jb     408180 <__swc_fn_e121059d_000003_68d30882+0xe80>
  40818e:	xor    r12d,r12d
  408191:	mov    QWORD PTR [rsp+0x858],r12
  408199:	test   rdi,rdi
  40819c:	mov    r14,QWORD PTR [rsp+0x7a8]
  4081a4:	mov    rcx,rdi
  4081a7:	jbe    4082ce <__swc_fn_e121059d_000003_68d30882+0xfce>
  4081ad:	nop    DWORD PTR [rax]
  4081b0:	mov    rsi,r12
  4081b3:	xor    r9d,r9d
  4081b6:	test   rdi,rdi
  4081b9:	mov    rdi,r9
  4081bc:	ja     4081cb <__swc_fn_e121059d_000003_68d30882+0xecb>
  4081be:	mov    rcx,QWORD PTR [rsp+0x850]
  4081c6:	jmp    408292 <__swc_fn_e121059d_000003_68d30882+0xf92>
  4081cb:	cs nop WORD PTR [rax+rax*1+0x0]
  4081d5:	cs nop WORD PTR [rax+rax*1+0x0]
  4081df:	nop
  4081e0:	cmp    rdi,r12
  4081e3:	jbe    40826c <__swc_fn_e121059d_000003_68d30882+0xf6c>
  4081e9:	mov    rax,QWORD PTR [r13+rsi*8+0x0]
  4081ee:	mov    r12,QWORD PTR [r15+rax*8]
  4081f2:	mov    rax,QWORD PTR [r13+rdi*8+0x0]
  4081f7:	mov    r13,QWORD PTR [r15+rax*8]
  4081fb:	mov    rax,QWORD PTR [rbx+0x210]
  408202:	mov    rcx,QWORD PTR [rax+r12*8]
  408206:	mov    r8,rcx
  408209:	mov    rax,QWORD PTR [rax+r13*8]
  40820d:	cmp    rax,rcx
  408210:	jae    408220 <__swc_fn_e121059d_000003_68d30882+0xf20>
  408212:	mov    rax,QWORD PTR [rbx+0x210]
  408219:	mov    rax,QWORD PTR [rax+r13*8]
  40821d:	mov    r8,rax
  408220:	mov    rax,QWORD PTR [rbx+0x208]
  408227:	mov    rcx,QWORD PTR [rax+r13*8]
  40822b:	add    rcx,r14
  40822e:	mov    rax,QWORD PTR [rax+r12*8]
  408232:	lea    rdx,[rax+r14*1]
  408236:	call   40a0b0 <__swc_fn_e121059d_000111_3dc01326>
  40823b:	mov    rcx,rax
  40823e:	test   eax,eax
  408240:	setl   dl
  408243:	jl     408266 <__swc_fn_e121059d_000003_68d30882+0xf66>
  408245:	test   ecx,ecx
  408247:	sete   cl
  40824a:	movzx  ecx,cl
  40824d:	jne    408264 <__swc_fn_e121059d_000003_68d30882+0xf64>
  40824f:	mov    rcx,QWORD PTR [rbx+0x210]
  408256:	mov    rdx,QWORD PTR [rcx+r12*8]
  40825a:	cmp    QWORD PTR [rcx+r13*8],rdx
  40825e:	setb   cl
  408261:	movzx  ecx,cl
  408264:	mov    dl,cl
  408266:	test   dl,dl
  408268:	cmovne rsi,rdi
  40826c:	add    rdi,0x1
  408270:	mov    rcx,QWORD PTR [rsp+0x850]
  408278:	cmp    rdi,rcx
  40827b:	jae    408292 <__swc_fn_e121059d_000003_68d30882+0xf92>
  40827d:	mov    r13,QWORD PTR [rsp+0x848]
  408285:	mov    r12,QWORD PTR [rsp+0x858]
  40828d:	jmp    4081e0 <__swc_fn_e121059d_000003_68d30882+0xee0>
  408292:	mov    r13,QWORD PTR [rsp+0x848]
  40829a:	mov    r12,QWORD PTR [rsp+0x858]
  4082a2:	mov    rdx,QWORD PTR [r13+r12*8+0x0]
  4082a7:	mov    r8,QWORD PTR [r13+rsi*8+0x0]
  4082ac:	mov    QWORD PTR [r13+r12*8+0x0],r8
  4082b1:	mov    QWORD PTR [r13+rsi*8+0x0],rdx
  4082b6:	add    r12,0x1
  4082ba:	mov    QWORD PTR [rsp+0x858],r12
  4082c2:	cmp    r12,rcx
  4082c5:	mov    rdi,rcx
  4082c8:	jb     4081b0 <__swc_fn_e121059d_000003_68d30882+0xeb0>
  4082ce:	mov    rsi,QWORD PTR [rsp+0x830]
  4082d6:	xor    edx,edx
  4082d8:	test   rcx,rcx
  4082db:	jbe    408409 <__swc_fn_e121059d_000003_68d30882+0x1109>
  4082e1:	mov    r8,QWORD PTR [rbx+0x218]
  4082e8:	vmovsd xmm0,QWORD PTR [rip+0xafe9]        # 4132d9 <__swc_rdata_base_e121059d+0x1c9>
  4082f0:	vmovsd xmm1,QWORD PTR [rip+0xafea]        # 4132e2 <__swc_rdata_base_e121059d+0x1d2>
  4082f8:	mov    r12,QWORD PTR [rsp+0x810]
  408300:	mov    rdi,QWORD PTR [rsp+0x818]
  408308:	mov    r14,QWORD PTR [rsp+0x820]
  408310:	mov    r9,QWORD PTR [rsp+0x828]
  408318:	vmovups xmm2,xmm1
  40831c:	vmovsd xmm4,QWORD PTR [rsp+0x848]
  408325:	vmovq  xmm5,r8
  40832a:	nop    WORD PTR [rax+rax*1+0x0]
  408330:	mov    r10,QWORD PTR [r13+rdx*8+0x0]
  408335:	mov    r10,QWORD PTR [r15+r10*8]
  408339:	mov    r10,QWORD PTR [r8+r10*8]
  40833d:	lea    r11,[rdx+0x1]
  408341:	vmovq  xmm3,QWORD PTR [r14+r10*8]
  408347:	vfmadd213sd xmm3,xmm9,xmm0
  40834c:	vcomisd xmm3,xmm1
  408350:	jb     40836a <__swc_fn_e121059d_000003_68d30882+0x106a>
  408352:	vsubsd xmm3,xmm3,xmm1
  408356:	vcvttsd2si rdx,xmm3
  40835b:	movabs r8,0x8000000000000000
  408365:	xor    rdx,r8
  408368:	jmp    40836f <__swc_fn_e121059d_000003_68d30882+0x106f>
  40836a:	vcvttsd2si rdx,xmm3
  40836f:	mov    rax,rdx
  408372:	mov    QWORD PTR [rsp+0x868],rdx
  40837a:	movabs rdx,0xc6f45449cb59c69
  408384:	mov    r13,QWORD PTR [rsp+0x868]
  40838c:	mul    rdx
  40838f:	mov    r8,rdx
  408392:	mov    rdx,r13
  408395:	sub    rdx,r8
  408398:	shr    rdx,1
  40839b:	add    rdx,r8
  40839e:	shr    rdx,0x13
  4083a2:	imul   r8,rdx,0xf4243
  4083a9:	sub    r13,r8
  4083ac:	mov    rdx,r11
  4083af:	imul   rdx,r13
  4083b3:	add    rsi,rdx
  4083b6:	mov    rdx,QWORD PTR [r12+r10*8]
  4083ba:	add    rdx,QWORD PTR [rdi+r10*8]
  4083be:	vmovq  xmm3,QWORD PTR [r9+r10*8]
  4083c4:	vfmadd213sd xmm3,xmm9,xmm0
  4083c9:	vcomisd xmm3,xmm2
  4083cd:	jb     4083e7 <__swc_fn_e121059d_000003_68d30882+0x10e7>
  4083cf:	vsubsd xmm3,xmm3,xmm2
  4083d3:	vcvttsd2si r8,xmm3
  4083d8:	movabs r10,0x8000000000000000
  4083e2:	xor    r8,r10
  4083e5:	jmp    4083ec <__swc_fn_e121059d_000003_68d30882+0x10ec>
  4083e7:	vcvttsd2si r8,xmm3
  4083ec:	add    rdx,r8
  4083ef:	add    rsi,rdx
  4083f2:	mov    rdx,r11
  4083f5:	cmp    r11,rcx
  4083f8:	jae    408409 <__swc_fn_e121059d_000003_68d30882+0x1109>
  4083fa:	vmovq  r13,xmm4
  4083ff:	vmovq  r8,xmm5
  408404:	jmp    408330 <__swc_fn_e121059d_000003_68d30882+0x1030>
  408409:	call   40f880 <__swc_fn_e121059d_000002_1ca87929>
  40840e:	vsubsd xmm0,xmm0,xmm6
  408412:	vmulsd xmm0,xmm0,QWORD PTR [rip+0xaed1]        # 4132eb <__swc_rdata_base_e121059d+0x1db>
  40841a:	lea    rax,[rip+0xad7f]        # 4131a0 <__swc_rdata_base_e121059d+0x90>
  408421:	sub    rsp,0x88
  408428:	mov    rcx,rsp
  40842b:	vmovups xmm1,XMMWORD PTR [rip+0xae7d]        # 4132b0 <__swc_rdata_base_e121059d+0x1a0>
  408433:	vmovups XMMWORD PTR [rcx],xmm1
  408437:	mov    QWORD PTR [rcx+0x30],rsp
  40843b:	lea    rdx,[rip+0xad6e]        # 4131b0 <__swc_rdata_base_e121059d+0xa0>
  408442:	mov    QWORD PTR [rcx+0x38],rdx
  408446:	mov    QWORD PTR [rcx+0x10],rsi
  40844a:	lea    r8,[rsp+0x10]
  40844f:	mov    QWORD PTR [rcx+0x40],r8
  408453:	lea    r8,[rip+0xad9e]        # 4131f8 <__swc_rdata_base_e121059d+0xe8>
  40845a:	mov    QWORD PTR [rcx+0x48],r8
  40845e:	vmovups xmm1,XMMWORD PTR [rip+0xae5a]        # 4132c0 <__swc_rdata_base_e121059d+0x1b0>
  408466:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40846b:	lea    r8,[rsp+0x18]
  408470:	mov    QWORD PTR [rcx+0x50],r8
  408474:	mov    QWORD PTR [rcx+0x58],rdx
  408478:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40847d:	lea    r8,[rcx+0x28]
  408481:	mov    QWORD PTR [rcx+0x60],r8
  408485:	lea    r8,[rip+0xadb4]        # 413240 <__swc_rdata_base_e121059d+0x130>
  40848c:	mov    QWORD PTR [rcx+0x68],r8
  408490:	mov    QWORD PTR [rcx+0x70],rax
  408494:	mov    QWORD PTR [rcx+0x78],rdx
  408498:	lea    rax,[rcx+0x30]
  40849c:	mov    QWORD PTR [rcx+0x80],rax
  4084a3:	mov    QWORD PTR [rcx+0x88],0x5
  4084ae:	lea    rcx,[rcx+0x80]
  4084b5:	sub    rsp,0x8
  4084b9:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  4084be:	add    rsp,0x948
  4084c5:	vmovups xmm6,XMMWORD PTR [rsp]
  4084ca:	vmovups xmm7,XMMWORD PTR [rsp+0x10]
  4084d0:	vmovups xmm8,XMMWORD PTR [rsp+0x20]
  4084d6:	vmovups xmm9,XMMWORD PTR [rsp+0x30]
  4084dc:	vmovups xmm10,XMMWORD PTR [rsp+0x40]
  4084e2:	add    rsp,0x50
  4084e6:	pop    r15
  4084e8:	pop    r14
  4084ea:	pop    r13
  4084ec:	pop    r12
  4084ee:	pop    rdi
  4084ef:	pop    rsi
  4084f0:	pop    rbx
  4084f1:	pop    rbp
  4084f2:	ret
	...

0000000000408500 <__swc_fn_e121059d_000006_81d2e1e9>:
  408500:	sub    rsp,0x8
  408504:	call   40a270 <__swc_fn_e121059d_000114_6b799b8d>
  408509:	mov    rcx,rax
  40850c:	test   rax,rax
  40850f:	je     408536 <__swc_fn_e121059d_000006_81d2e1e9+0x36>
  408511:	lea    rdx,[rip+0x1bb30]        # 424048 <__swc_bss_base_e121059d+0x8>
  408518:	mov    r8,QWORD PTR [rip+0x1bb29]        # 424048 <__swc_bss_base_e121059d+0x8>
  40851f:	nop
  408520:	lea    r9,[r8+0x1]
  408524:	mov    rax,r8
  408527:	lock cmpxchg QWORD PTR [rdx],r9
  40852c:	cmp    rax,r8
  40852f:	je     408536 <__swc_fn_e121059d_000006_81d2e1e9+0x36>
  408531:	mov    r8,rax
  408534:	jmp    408520 <__swc_fn_e121059d_000006_81d2e1e9+0x20>
  408536:	mov    rax,rcx
  408539:	add    rsp,0x8
  40853d:	ret
	...

0000000000408540 <__swc_fn_e121059d_000009_065ed5b1>:
  408540:	mov    r8d,edx
  408543:	xor    eax,eax
  408545:	tzcnt  eax,edx
  408549:	shrx   r9d,edx,eax
  40854e:	mov    DWORD PTR [rcx+0x2c],edx
  408551:	xor    eax,eax
  408553:	tzcnt  eax,edx
  408557:	mov    BYTE PTR [rcx+0x38],al
  40855a:	mov    eax,0xffffffff
  40855f:	xor    edx,edx
  408561:	div    r8d
  408564:	mov    DWORD PTR [rcx+0x34],eax
  408567:	mov    eax,r9d
  40856a:	mov    edx,r9d
  40856d:	imul   edx,r9d
  408571:	mov    r8d,0x2
  408577:	sub    r8d,edx
  40857a:	imul   eax,r8d
  40857e:	mov    edx,r9d
  408581:	imul   edx,eax
  408584:	mov    r8d,0x2
  40858a:	sub    r8d,edx
  40858d:	imul   eax,r8d
  408591:	mov    edx,r9d
  408594:	imul   edx,eax
  408597:	mov    r8d,0x2
  40859d:	sub    r8d,edx
  4085a0:	imul   eax,r8d
  4085a4:	mov    edx,r9d
  4085a7:	imul   edx,eax
  4085aa:	mov    r8d,0x2
  4085b0:	sub    r8d,edx
  4085b3:	imul   eax,r8d
  4085b7:	imul   r9d,eax
  4085bb:	mov    edx,0x2
  4085c0:	sub    edx,r9d
  4085c3:	imul   eax,edx
  4085c6:	mov    DWORD PTR [rcx+0x30],eax
  4085c9:	ret
  4085ca:	add    BYTE PTR [rax],al
  4085cc:	add    BYTE PTR [rax],al
	...

00000000004085d0 <__swc_fn_e121059d_000012_861b8b62>:
  4085d0:	xor    eax,eax
  4085d2:	mov    DWORD PTR [rcx+0x68],eax
  4085d5:	ret
	...

00000000004085e0 <__swc_fn_e121059d_000015_9dea5065>:
  4085e0:	mov    eax,DWORD PTR [rcx+0x28]
  4085e3:	shlx   eax,edx,eax
  4085e8:	shl    rax,0x10
  4085ec:	lea    rdx,[rcx+rax*1]
  4085f0:	lea    rax,[rcx+0x3000]
  4085f7:	cmp    rdx,rax
  4085fa:	cmovae rax,rdx
  4085fe:	ret
	...

0000000000408600 <__swc_fn_e121059d_000018_283e2b5e>:
  408600:	push   rsi
  408601:	push   rdi
  408602:	push   r12
  408604:	push   r13
  408606:	push   r14
  408608:	mov    rsi,rdx
  40860b:	mov    rdi,rcx
  40860e:	rex mov dl,BYTE PTR [rsi+0x3a]
  408612:	mov    ecx,DWORD PTR [rdi+0x28]
  408615:	shr    dl,cl
  408617:	mov    r12d,0x1
  40861d:	mov    ecx,edx
  40861f:	shl    r12,cl
  408622:	mov    r13d,DWORD PTR [rsi+0x3c]
  408626:	rex mov BYTE PTR [rsi+0x3b],0x0
  40862b:	mov    QWORD PTR [rsi+0x40],0x0
  408633:	mov    QWORD PTR [rsi],0x0
  40863a:	mov    rax,QWORD PTR [rsi+0x10]
  40863e:	mov    QWORD PTR [rsi+0x20],rax
  408642:	lea    r14,[rip+0x1ba07]        # 424050 <__swc_bss_base_e121059d+0x10>
  408649:	mov    rax,QWORD PTR [r14]
  40864c:	shr    rax,0x2
  408650:	mov    rcx,rax
  408653:	cmp    rax,0x800000
  40865a:	mov    eax,0x800000
  40865f:	cmovb  rcx,rax
  408663:	lea    r8,[rip+0x1b9f6]        # 424060 <__swc_bss_base_e121059d+0x20>
  40866a:	mov    rax,QWORD PTR [r8]
  40866d:	mov    r9,rax
  408670:	lea    r10,[r9+r13*1]
  408674:	cmp    r10,rcx
  408677:	ja     40869b <__swc_fn_e121059d_000018_283e2b5e+0x9b>
  408679:	mov    rax,r9
  40867c:	lock cmpxchg QWORD PTR [r8],r10
  408681:	cmp    rax,r9
  408684:	je     40868b <__swc_fn_e121059d_000018_283e2b5e+0x8b>
  408686:	mov    r9,rax
  408689:	jmp    408670 <__swc_fn_e121059d_000018_283e2b5e+0x70>
  40868b:	mov    rcx,rdi
  40868e:	mov    rdx,r12
  408691:	call   40fc70 <__swc_fn_e121059d_000020_de02dbdf>
  408696:	jmp    40871d <__swc_fn_e121059d_000018_283e2b5e+0x11d>
  40869b:	mov    rcx,rdi
  40869e:	movzx  edx,dl
  4086a1:	call   4085e0 <__swc_fn_e121059d_000015_9dea5065>
  4086a6:	test   r13,r13
  4086a9:	je     408716 <__swc_fn_e121059d_000018_283e2b5e+0x116>
  4086af:	mov    rcx,rax
  4086b2:	mov    rdx,r13
  4086b5:	call   40a3f0 <__swc_fn_e121059d_000117_e9fc0224>
  4086ba:	mov    rcx,QWORD PTR [rip+0x1b98f]        # 424050 <__swc_bss_base_e121059d+0x10>
  4086c1:	cs nop WORD PTR [rax+rax*1+0x0]
  4086cb:	nop    DWORD PTR [rax+rax*1+0x0]
  4086d0:	mov    rdx,rcx
  4086d3:	sub    rdx,r13
  4086d6:	mov    rax,rcx
  4086d9:	lock cmpxchg QWORD PTR [r14],rdx
  4086de:	cmp    rax,rcx
  4086e1:	je     4086e8 <__swc_fn_e121059d_000018_283e2b5e+0xe8>
  4086e3:	mov    rcx,rax
  4086e6:	jmp    4086d0 <__swc_fn_e121059d_000018_283e2b5e+0xd0>
  4086e8:	lea    rcx,[rip+0x1b979]        # 424068 <__swc_bss_base_e121059d+0x28>
  4086ef:	mov    rdx,QWORD PTR [rip+0x1b972]        # 424068 <__swc_bss_base_e121059d+0x28>
  4086f6:	cs nop WORD PTR [rax+rax*1+0x0]
  408700:	lea    r8,[rdx+0x1]
  408704:	mov    rax,rdx
  408707:	lock cmpxchg QWORD PTR [rcx],r8
  40870c:	cmp    rax,rdx
  40870f:	je     408716 <__swc_fn_e121059d_000018_283e2b5e+0x116>
  408711:	mov    rdx,rax
  408714:	jmp    408700 <__swc_fn_e121059d_000018_283e2b5e+0x100>
  408716:	mov    DWORD PTR [rsi+0x3c],0x0
  40871d:	mov    rcx,rdi
  408720:	mov    rdx,r12
  408723:	call   40b6d0 <__swc_fn_e121059d_000022_c8f5f27c>
  408728:	pop    r14
  40872a:	pop    r13
  40872c:	pop    r12
  40872e:	pop    rdi
  40872f:	pop    rsi
  408730:	ret
	...

0000000000408740 <__swc_fn_e121059d_000021_fd2b165c>:
  408740:	mov    r8,QWORD PTR [rcx+0x48]
  408744:	test   r8,rdx
  408747:	je     408778 <__swc_fn_e121059d_000021_fd2b165c+0x38>
  408749:	nop    DWORD PTR [rax+0x0]
  408750:	mov    rax,rdx
  408753:	not    rax
  408756:	mov    r9,r8
  408759:	and    r9,rax
  40875c:	mov    rax,r8
  40875f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  408765:	cmp    rax,r8
  408768:	jne    408770 <__swc_fn_e121059d_000021_fd2b165c+0x30>
  40876a:	mov    eax,0x1
  40876f:	ret
  408770:	mov    r8,rax
  408773:	test   rax,rdx
  408776:	jne    408750 <__swc_fn_e121059d_000021_fd2b165c+0x10>
  408778:	xor    eax,eax
  40877a:	ret
  40877b:	add    BYTE PTR [rax],al
  40877d:	add    BYTE PTR [rax],al
	...

0000000000408780 <__swc_fn_e121059d_000024_2685aade>:
  408780:	push   rsi
  408781:	push   rdi
  408782:	push   r12
  408784:	push   r13
  408786:	sub    rsp,0x8
  40878a:	mov    rsi,rdx
  40878d:	mov    rdi,rcx
  408790:	lea    r12,[rip+0x1ba61]        # 4241f8 <__swc_bss_base_e121059d+0x1b8>
  408797:	mov    rcx,r12
  40879a:	call   412140 <__swc_fn_e121059d_000140_86bb0f90>
  40879f:	xor    eax,eax
  4087a1:	mov    rcx,QWORD PTR [rip+0x1ba58]        # 424200 <__swc_bss_base_e121059d+0x1c0>
  4087a8:	mov    r13,rcx
  4087ab:	test   r13,r13
  4087ae:	je     4087fb <__swc_fn_e121059d_000024_2685aade+0x7b>
  4087b0:	mov    rcx,QWORD PTR [r13+0x10]
  4087b4:	cmp    DWORD PTR [r13+0x28],esi
  4087b8:	jne    4087f0 <__swc_fn_e121059d_000024_2685aade+0x70>
  4087ba:	test   rax,rax
  4087bd:	jne    4087c8 <__swc_fn_e121059d_000024_2685aade+0x48>
  4087bf:	mov    QWORD PTR [rip+0x1ba3a],rcx        # 424200 <__swc_bss_base_e121059d+0x1c0>
  4087c6:	jmp    4087cc <__swc_fn_e121059d_000024_2685aade+0x4c>
  4087c8:	mov    QWORD PTR [rax+0x10],rcx
  4087cc:	vxorps xmm0,xmm0,xmm0
  4087d0:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  4087d6:	mov    QWORD PTR [r13+0x8],rdi
  4087da:	mov    rcx,r12
  4087dd:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  4087e2:	mov    rax,r13
  4087e5:	add    rsp,0x8
  4087e9:	pop    r13
  4087eb:	pop    r12
  4087ed:	pop    rdi
  4087ee:	pop    rsi
  4087ef:	ret
  4087f0:	mov    rax,r13
  4087f3:	mov    r13,rcx
  4087f6:	test   rcx,rcx
  4087f9:	jne    4087b0 <__swc_fn_e121059d_000024_2685aade+0x30>
  4087fb:	mov    ecx,esi
  4087fd:	call   40fca0 <__swc_fn_e121059d_000023_2d0fcd2c>
  408802:	mov    rsi,rax
  408805:	test   rax,rax
  408808:	jne    40881f <__swc_fn_e121059d_000024_2685aade+0x9f>
  40880a:	mov    rcx,r12
  40880d:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  408812:	xor    eax,eax
  408814:	add    rsp,0x8
  408818:	pop    r13
  40881a:	pop    r12
  40881c:	pop    rdi
  40881d:	pop    rsi
  40881e:	ret
  40881f:	mov    QWORD PTR [rsi+0x8],rdi
  408823:	mov    rcx,r12
  408826:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  40882b:	mov    rax,rsi
  40882e:	add    rsp,0x8
  408832:	pop    r13
  408834:	pop    r12
  408836:	pop    rdi
  408837:	pop    rsi
  408838:	ret
  408839:	add    BYTE PTR [rax],al
  40883b:	add    BYTE PTR [rax],al
  40883d:	add    BYTE PTR [rax],al
	...

0000000000408840 <__swc_fn_e121059d_000027_9798fb47>:
  408840:	vxorps xmm0,xmm0,xmm0
  408844:	xor    eax,eax
  408846:	cs nop WORD PTR [rax+rax*1+0x0]
  408850:	cs nop WORD PTR [rax+rax*1+0x0]
  40885a:	nop    WORD PTR [rax+rax*1+0x0]
  408860:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  408865:	add    rax,0x10
  408869:	cmp    rax,0x2b00
  408870:	jne    408860 <__swc_fn_e121059d_000027_9798fb47+0x20>
  408872:	ret
	...

0000000000408880 <__swc_fn_e121059d_000030_9798fb47>:
  408880:	vxorps xmm0,xmm0,xmm0
  408884:	vmovups XMMWORD PTR [rcx],xmm0
  408888:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40888d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408892:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  408897:	ret
	...

00000000004088a0 <__swc_fn_e121059d_000033_9798fb47>:
  4088a0:	vxorps xmm0,xmm0,xmm0
  4088a4:	vmovups XMMWORD PTR [rcx],xmm0
  4088a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4088ad:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4088b2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4088b7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  4088bc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  4088c1:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  4088c6:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  4088cb:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  4088d3:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  4088db:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  4088e3:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  4088eb:	mov    QWORD PTR [rcx+0xc0],0x0
  4088f6:	ret
	...

0000000000408900 <__swc_fn_e121059d_000036_92d9bbff>:
  408900:	push   rsi
  408901:	push   rdi
  408902:	sub    rsp,0x8
  408906:	mov    rsi,rcx
  408909:	lea    rdi,[rip+0x196f8]        # 422008 <__swc_data_base_e121059d+0x8>
  408910:	mov    rax,QWORD PTR [rdi]
  408913:	cmp    rax,0xffffffffffffffff
  408917:	je     40891e <__swc_fn_e121059d_000036_92d9bbff+0x1e>
  408919:	mov    rdi,rax
  40891c:	jmp    40894b <__swc_fn_e121059d_000036_92d9bbff+0x4b>
  40891e:	call   411e20 <__swc_fn_e121059d_000128_58f0f391>
  408923:	mov    rcx,rax
  408926:	cmp    rax,0xffffffffffffffff
  40892a:	je     40895c <__swc_fn_e121059d_000036_92d9bbff+0x5c>
  40892c:	mov    rax,0xffffffffffffffff
  408933:	lock cmpxchg QWORD PTR [rdi],rcx
  408938:	cmp    rax,0xffffffffffffffff
  40893c:	je     408948 <__swc_fn_e121059d_000036_92d9bbff+0x48>
  40893e:	mov    rdi,rax
  408941:	call   40a7d0 <__swc_fn_e121059d_000129_a481cb88>
  408946:	jmp    40894b <__swc_fn_e121059d_000036_92d9bbff+0x4b>
  408948:	mov    rdi,rcx
  40894b:	cmp    rdi,0xffffffffffffffff
  40894f:	je     40895c <__swc_fn_e121059d_000036_92d9bbff+0x5c>
  408951:	mov    rcx,rdi
  408954:	mov    rdx,rsi
  408957:	call   40dbb0 <__swc_fn_e121059d_000130_4bbe3f14>
  40895c:	add    rsp,0x8
  408960:	pop    rdi
  408961:	pop    rsi
  408962:	ret
	...

0000000000408970 <__swc_fn_e121059d_000039_03f1bf9a>:
  408970:	sub    rsp,0x38
  408974:	mov    rax,rdx
  408977:	test   dl,dl
  408979:	jne    408991 <__swc_fn_e121059d_000039_03f1bf9a+0x21>
  40897b:	mov    rax,r8
  40897e:	test   r8b,r8b
  408981:	cmove  eax,r9d
  408985:	test   al,al
  408987:	cmove  eax,r10d
  40898b:	test   al,al
  40898d:	cmove  eax,r11d
  408991:	test   al,al
  408993:	jne    40899a <__swc_fn_e121059d_000039_03f1bf9a+0x2a>
  408995:	add    rsp,0x38
  408999:	ret
  40899a:	lea    rcx,[rip+0xa957]        # 4132f8 <__swc_rdata_base_e121059d+0x1e8>
  4089a1:	vmovups xmm0,XMMWORD PTR [rip+0xa95f]        # 413308 <__swc_rdata_base_e121059d+0x1f8>
  4089a9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089af:	vmovups xmm0,XMMWORD PTR [rip+0xa961]        # 413318 <__swc_rdata_base_e121059d+0x208>
  4089b7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4089bd:	vmovups xmm0,XMMWORD PTR [rip+0xa963]        # 413328 <__swc_rdata_base_e121059d+0x218>
  4089c5:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  4089cb:	lea    rdx,[rsp+0x8]
  4089d0:	call   4118c0 <__swc_fn_e121059d_000107_90faaa26>
  4089d5:	jmp    408995 <__swc_fn_e121059d_000039_03f1bf9a+0x25>
	...

00000000004089e0 <__swc_fn_e121059d_000042_facd3e17>:
  4089e0:	sub    rsp,0x8
  4089e4:	mov    eax,0x1000
  4089e9:	test   eax,eax
  4089eb:	mov    r8d,0x8
  4089f1:	cmove  eax,r8d
  4089f5:	dec    rax
  4089f8:	mov    r8,0xffffffffffffffff
  4089ff:	sub    r8,rax
  408a02:	cmp    rdx,r8
  408a05:	ja     408a15 <__swc_fn_e121059d_000042_facd3e17+0x35>
  408a07:	add    rdx,rax
  408a0a:	not    rax
  408a0d:	mov    r8,rdx
  408a10:	and    r8,rax
  408a13:	jne    408a1c <__swc_fn_e121059d_000042_facd3e17+0x3c>
  408a15:	xor    eax,eax
  408a17:	add    rsp,0x8
  408a1b:	ret
  408a1c:	mov    rdx,r8
  408a1f:	call   40ffc0 <__swc_fn_e121059d_000041_c90d80c1>
  408a24:	add    rsp,0x8
  408a28:	ret
  408a29:	add    BYTE PTR [rax],al
  408a2b:	add    BYTE PTR [rax],al
  408a2d:	add    BYTE PTR [rax],al
	...

0000000000408a30 <__swc_fn_e121059d_000045_d8bd27c3>:
  408a30:	push   rsi
  408a31:	push   rdi
  408a32:	sub    rsp,0x8
  408a36:	mov    rsi,rdx
  408a39:	mov    rdi,rcx
  408a3c:	test   rdx,rdx
  408a3f:	je     408a5b <__swc_fn_e121059d_000045_d8bd27c3+0x2b>
  408a41:	xor    ecx,ecx
  408a43:	call   40b7f0 <__swc_fn_e121059d_000037_28d0e998>
  408a48:	mov    rax,QWORD PTR [rsi]
  408a4b:	test   rax,rax
  408a4e:	je     408a5b <__swc_fn_e121059d_000045_d8bd27c3+0x2b>
  408a50:	mov    rcx,rax
  408a53:	mov    rdx,rsi
  408a56:	call   40b900 <__swc_fn_e121059d_000046_b30433d0>
  408a5b:	mov    rcx,rdi
  408a5e:	call   410020 <__swc_fn_e121059d_000044_a78ae66b>
  408a63:	mov    rsi,rax
  408a66:	test   rax,rax
  408a69:	jne    408a74 <__swc_fn_e121059d_000045_d8bd27c3+0x44>
  408a6b:	xor    eax,eax
  408a6d:	add    rsp,0x8
  408a71:	pop    rdi
  408a72:	pop    rsi
  408a73:	ret
  408a74:	mov    rcx,rsi
  408a77:	call   40b7f0 <__swc_fn_e121059d_000037_28d0e998>
  408a7c:	mov    rax,rsi
  408a7f:	add    rsp,0x8
  408a83:	pop    rdi
  408a84:	pop    rsi
  408a85:	ret
	...

0000000000408a90 <__swc_fn_e121059d_000048_137687bb>:
  408a90:	movzx  eax,BYTE PTR [r8+0x39]
  408a95:	lea    rax,[rax+rax*4]
  408a99:	lea    rax,[rdx+rax*8+0x28]
  408a9e:	mov    ecx,DWORD PTR [r8+0x6c]
  408aa2:	test   ecx,ecx
  408aa4:	je     408add <__swc_fn_e121059d_000048_137687bb+0x4d>
  408aa6:	mov    rcx,QWORD PTR [r8+0x50]
  408aaa:	test   rcx,rcx
  408aad:	je     408ab9 <__swc_fn_e121059d_000048_137687bb+0x29>
  408aaf:	mov    rax,QWORD PTR [r8+0x48]
  408ab3:	mov    QWORD PTR [rcx+0x48],rax
  408ab7:	jmp    408ac1 <__swc_fn_e121059d_000048_137687bb+0x31>
  408ab9:	mov    rcx,QWORD PTR [r8+0x48]
  408abd:	mov    QWORD PTR [rax+0x18],rcx
  408ac1:	mov    rax,QWORD PTR [r8+0x48]
  408ac5:	test   rax,rax
  408ac8:	je     408ad2 <__swc_fn_e121059d_000048_137687bb+0x42>
  408aca:	mov    rcx,QWORD PTR [r8+0x50]
  408ace:	mov    QWORD PTR [rax+0x50],rcx
  408ad2:	vxorps xmm0,xmm0,xmm0
  408ad6:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  408adc:	ret
  408add:	mov    rcx,QWORD PTR [r8+0x50]
  408ae1:	test   rcx,rcx
  408ae4:	je     408af0 <__swc_fn_e121059d_000048_137687bb+0x60>
  408ae6:	mov    rdx,QWORD PTR [r8+0x48]
  408aea:	mov    QWORD PTR [rcx+0x48],rdx
  408aee:	jmp    408af8 <__swc_fn_e121059d_000048_137687bb+0x68>
  408af0:	mov    rcx,QWORD PTR [r8+0x48]
  408af4:	mov    QWORD PTR [rax+0x8],rcx
  408af8:	mov    rcx,QWORD PTR [r8+0x48]
  408afc:	test   rcx,rcx
  408aff:	je     408b0b <__swc_fn_e121059d_000048_137687bb+0x7b>
  408b01:	mov    rdx,QWORD PTR [r8+0x50]
  408b05:	mov    QWORD PTR [rcx+0x50],rdx
  408b09:	jmp    408b13 <__swc_fn_e121059d_000048_137687bb+0x83>
  408b0b:	mov    rcx,QWORD PTR [r8+0x50]
  408b0f:	mov    QWORD PTR [rax+0x10],rcx
  408b13:	cmp    QWORD PTR [rax],r8
  408b16:	jne    408b1f <__swc_fn_e121059d_000048_137687bb+0x8f>
  408b18:	mov    QWORD PTR [rax],0x0
  408b1f:	vxorps xmm0,xmm0,xmm0
  408b23:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  408b29:	ret
  408b2a:	add    BYTE PTR [rax],al
  408b2c:	add    BYTE PTR [rax],al
	...

0000000000408b30 <__swc_fn_e121059d_000051_e072b516>:
  408b30:	sub    rsp,0x8
  408b34:	mov    r9,r8
  408b37:	mov    r10,rdx
  408b3a:	call   408a90 <__swc_fn_e121059d_000048_137687bb>
  408b3f:	mov    DWORD PTR [r9+0x6c],0x0
  408b47:	movzx  eax,BYTE PTR [r9+0x39]
  408b4c:	lea    rax,[rax+rax*4]
  408b50:	lea    rax,[r10+rax*8+0x28]
  408b55:	mov    rcx,QWORD PTR [rax+0x10]
  408b59:	mov    QWORD PTR [r9+0x50],rcx
  408b5d:	mov    QWORD PTR [r9+0x48],0x0
  408b65:	mov    rcx,QWORD PTR [rax+0x10]
  408b69:	test   rcx,rcx
  408b6c:	je     408b74 <__swc_fn_e121059d_000051_e072b516+0x44>
  408b6e:	mov    QWORD PTR [rcx+0x48],r9
  408b72:	jmp    408b78 <__swc_fn_e121059d_000051_e072b516+0x48>
  408b74:	mov    QWORD PTR [rax+0x8],r9
  408b78:	mov    QWORD PTR [rax+0x10],r9
  408b7c:	add    rsp,0x8
  408b80:	ret
	...

0000000000408ba0 <__swc_fn_e121059d_000054_faa92dcc>:
  408ba0:	push   rsi
  408ba1:	push   rdi
  408ba2:	push   r12
  408ba4:	push   r13
  408ba6:	push   r14
  408ba8:	push   r15
  408baa:	sub    rsp,0x1f8
  408bb1:	mov    esi,r8d
  408bb4:	mov    QWORD PTR [rsp+0x1e8],rsi
  408bbc:	mov    rdi,rcx
  408bbf:	mov    r12,rdx
  408bc2:	lea    r13,[rsi+rsi*4]
  408bc6:	lea    r13,[rdx+r13*8+0x28]
  408bcb:	call   40bd60 <__swc_fn_e121059d_000052_d846b172>
  408bd0:	add    DWORD PTR [r12+0x24],0x1
  408bd6:	test   BYTE PTR [r12+0x24],0x3f
  408bdc:	jne    408be6 <__swc_fn_e121059d_000054_faa92dcc+0x46>
  408bde:	mov    rcx,rdi
  408be1:	call   4101a0 <__swc_fn_e121059d_000053_3af34d7f>
  408be6:	mov    rax,QWORD PTR [r13+0x8]
  408bea:	mov    r14,rax
  408bed:	nop    DWORD PTR [rax]
  408bf0:	test   r14,r14
  408bf3:	jne    408c02 <__swc_fn_e121059d_000054_faa92dcc+0x62>
  408bf5:	mov    rsi,QWORD PTR [rsp+0x1e8]
  408bfd:	jmp    408d09 <__swc_fn_e121059d_000054_faa92dcc+0x169>
  408c02:	mov    r15,QWORD PTR [r14+0x48]
  408c06:	mov    rcx,r14
  408c09:	call   40b4c0 <__swc_fn_e121059d_000013_e4b0ddfc>
  408c0e:	mov    rax,QWORD PTR [r14]
  408c11:	test   rax,rax
  408c14:	je     408c26 <__swc_fn_e121059d_000054_faa92dcc+0x86>
  408c16:	mov    rcx,QWORD PTR [rax]
  408c19:	mov    QWORD PTR [r14],rcx
  408c1c:	add    DWORD PTR [r14+0x28],0x1
  408c21:	mov    rsi,rax
  408c24:	jmp    408c45 <__swc_fn_e121059d_000054_faa92dcc+0xa5>
  408c26:	mov    rax,QWORD PTR [r14+0x18]
  408c2a:	cmp    QWORD PTR [r14+0x20],rax
  408c2e:	jae    408c43 <__swc_fn_e121059d_000054_faa92dcc+0xa3>
  408c30:	mov    rsi,QWORD PTR [r14+0x20]
  408c34:	mov    eax,DWORD PTR [r14+0x2c]
  408c38:	add    QWORD PTR [r14+0x20],rax
  408c3c:	add    DWORD PTR [r14+0x28],0x1
  408c41:	jmp    408c45 <__swc_fn_e121059d_000054_faa92dcc+0xa5>
  408c43:	xor    esi,esi
  408c45:	test   rsi,rsi
  408c48:	jne    408c8d <__swc_fn_e121059d_000054_faa92dcc+0xed>
  408c4a:	mov    rcx,r14
  408c4d:	call   40b3f0 <__swc_fn_e121059d_000010_24a20786>
  408c52:	test   al,al
  408c54:	je     408c8d <__swc_fn_e121059d_000054_faa92dcc+0xed>
  408c56:	mov    rax,QWORD PTR [r14]
  408c59:	test   rax,rax
  408c5c:	je     408c6b <__swc_fn_e121059d_000054_faa92dcc+0xcb>
  408c5e:	mov    rcx,QWORD PTR [rax]
  408c61:	mov    QWORD PTR [r14],rcx
  408c64:	add    DWORD PTR [r14+0x28],0x1
  408c69:	jmp    408c8a <__swc_fn_e121059d_000054_faa92dcc+0xea>
  408c6b:	mov    rax,QWORD PTR [r14+0x18]
  408c6f:	cmp    QWORD PTR [r14+0x20],rax
  408c73:	jae    408c88 <__swc_fn_e121059d_000054_faa92dcc+0xe8>
  408c75:	mov    rax,QWORD PTR [r14+0x20]
  408c79:	mov    ecx,DWORD PTR [r14+0x2c]
  408c7d:	add    QWORD PTR [r14+0x20],rcx
  408c81:	add    DWORD PTR [r14+0x28],0x1
  408c86:	jmp    408c8a <__swc_fn_e121059d_000054_faa92dcc+0xea>
  408c88:	xor    eax,eax
  408c8a:	mov    rsi,rax
  408c8d:	test   rsi,rsi
  408c90:	jne    408ce3 <__swc_fn_e121059d_000054_faa92dcc+0x143>
  408c92:	mov    rcx,rdi
  408c95:	mov    rdx,r12
  408c98:	mov    r8,r14
  408c9b:	call   410100 <__swc_fn_e121059d_000050_129b9bf4>
  408ca0:	test   al,al
  408ca2:	jne    408ce3 <__swc_fn_e121059d_000054_faa92dcc+0x143>
  408ca4:	mov    rcx,r14
  408ca7:	call   40b4c0 <__swc_fn_e121059d_000013_e4b0ddfc>
  408cac:	mov    rax,QWORD PTR [r14]
  408caf:	test   rax,rax
  408cb2:	je     408cc1 <__swc_fn_e121059d_000054_faa92dcc+0x121>
  408cb4:	mov    rcx,QWORD PTR [rax]
  408cb7:	mov    QWORD PTR [r14],rcx
  408cba:	add    DWORD PTR [r14+0x28],0x1
  408cbf:	jmp    408ce0 <__swc_fn_e121059d_000054_faa92dcc+0x140>
  408cc1:	mov    rax,QWORD PTR [r14+0x18]
  408cc5:	cmp    QWORD PTR [r14+0x20],rax
  408cc9:	jae    408cde <__swc_fn_e121059d_000054_faa92dcc+0x13e>
  408ccb:	mov    rax,QWORD PTR [r14+0x20]
  408ccf:	mov    ecx,DWORD PTR [r14+0x2c]
  408cd3:	add    QWORD PTR [r14+0x20],rcx
  408cd7:	add    DWORD PTR [r14+0x28],0x1
  408cdc:	jmp    408ce0 <__swc_fn_e121059d_000054_faa92dcc+0x140>
  408cde:	xor    eax,eax
  408ce0:	mov    rsi,rax
  408ce3:	test   rsi,rsi
  408ce6:	je     408d01 <__swc_fn_e121059d_000054_faa92dcc+0x161>
  408ce8:	mov    QWORD PTR [r13+0x0],r14
  408cec:	mov    rax,rsi
  408cef:	add    rsp,0x1f8
  408cf6:	pop    r15
  408cf8:	pop    r14
  408cfa:	pop    r13
  408cfc:	pop    r12
  408cfe:	pop    rdi
  408cff:	pop    rsi
  408d00:	ret
  408d01:	mov    r14,r15
  408d04:	jmp    408bf0 <__swc_fn_e121059d_000054_faa92dcc+0x50>
  408d09:	cs nop WORD PTR [rax+rax*1+0x0]
  408d13:	cs nop WORD PTR [rax+rax*1+0x0]
  408d1d:	nop    DWORD PTR [rax]
  408d20:	mov    rcx,rdi
  408d23:	mov    rdx,r12
  408d26:	mov    r8d,esi
  408d29:	call   40baa0 <__swc_fn_e121059d_000049_ad48ec88>
  408d2e:	mov    r14,rax
  408d31:	test   rax,rax
  408d34:	jne    408d4a <__swc_fn_e121059d_000054_faa92dcc+0x1aa>
  408d36:	xor    eax,eax
  408d38:	add    rsp,0x1f8
  408d3f:	pop    r15
  408d41:	pop    r14
  408d43:	pop    r13
  408d45:	pop    r12
  408d47:	pop    rdi
  408d48:	pop    rsi
  408d49:	ret
  408d4a:	mov    QWORD PTR [r13+0x0],r14
  408d4e:	mov    rax,QWORD PTR [r14]
  408d51:	test   rax,rax
  408d54:	je     408d66 <__swc_fn_e121059d_000054_faa92dcc+0x1c6>
  408d56:	mov    rcx,QWORD PTR [rax]
  408d59:	mov    QWORD PTR [r14],rcx
  408d5c:	add    DWORD PTR [r14+0x28],0x1
  408d61:	mov    r15,rax
  408d64:	jmp    408d86 <__swc_fn_e121059d_000054_faa92dcc+0x1e6>
  408d66:	mov    rax,QWORD PTR [r14+0x18]
  408d6a:	cmp    QWORD PTR [r14+0x20],rax
  408d6e:	jae    408d83 <__swc_fn_e121059d_000054_faa92dcc+0x1e3>
  408d70:	mov    r15,QWORD PTR [r14+0x20]
  408d74:	mov    eax,DWORD PTR [r14+0x2c]
  408d78:	add    QWORD PTR [r14+0x20],rax
  408d7c:	add    DWORD PTR [r14+0x28],0x1
  408d81:	jmp    408d86 <__swc_fn_e121059d_000054_faa92dcc+0x1e6>
  408d83:	xor    r15d,r15d
  408d86:	test   r15,r15
  408d89:	jne    408dce <__swc_fn_e121059d_000054_faa92dcc+0x22e>
  408d8b:	mov    rcx,r14
  408d8e:	call   40b3f0 <__swc_fn_e121059d_000010_24a20786>
  408d93:	test   al,al
  408d95:	je     408dce <__swc_fn_e121059d_000054_faa92dcc+0x22e>
  408d97:	mov    rax,QWORD PTR [r14]
  408d9a:	test   rax,rax
  408d9d:	je     408dac <__swc_fn_e121059d_000054_faa92dcc+0x20c>
  408d9f:	mov    rcx,QWORD PTR [rax]
  408da2:	mov    QWORD PTR [r14],rcx
  408da5:	add    DWORD PTR [r14+0x28],0x1
  408daa:	jmp    408dcb <__swc_fn_e121059d_000054_faa92dcc+0x22b>
  408dac:	mov    rax,QWORD PTR [r14+0x18]
  408db0:	cmp    QWORD PTR [r14+0x20],rax
  408db4:	jae    408dc9 <__swc_fn_e121059d_000054_faa92dcc+0x229>
  408db6:	mov    rax,QWORD PTR [r14+0x20]
  408dba:	mov    ecx,DWORD PTR [r14+0x2c]
  408dbe:	add    QWORD PTR [r14+0x20],rcx
  408dc2:	add    DWORD PTR [r14+0x28],0x1
  408dc7:	jmp    408dcb <__swc_fn_e121059d_000054_faa92dcc+0x22b>
  408dc9:	xor    eax,eax
  408dcb:	mov    r15,rax
  408dce:	test   r15,r15
  408dd1:	je     408d20 <__swc_fn_e121059d_000054_faa92dcc+0x180>
  408dd7:	mov    rax,r15
  408dda:	add    rsp,0x1f8
  408de1:	pop    r15
  408de3:	pop    r14
  408de5:	pop    r13
  408de7:	pop    r12
  408de9:	pop    rdi
  408dea:	pop    rsi
  408deb:	ret
  408dec:	add    BYTE PTR [rax],al
	...

0000000000408df0 <__swc_fn_e121059d_000057_7e1dbcb0>:
  408df0:	push   rsi
  408df1:	push   rdi
  408df2:	push   r12
  408df4:	mov    rsi,rdx
  408df7:	mov    rax,rdx
  408dfa:	shr    rax,0xc
  408dfe:	movabs rdx,0x9e3779b97f4a7c15
  408e08:	imul   rax,rdx
  408e0c:	shr    rax,0x20
  408e10:	lea    rax,[rax*8+0x0]
  408e18:	shr    rax,0x20
  408e1c:	lea    rax,[rax*8+0x0]
  408e24:	lea    rax,[rcx+rax*8+0x40]
  408e29:	xor    edx,edx
  408e2b:	test   dl,dl
  408e2d:	lea    rdi,[rcx+0x8]
  408e31:	cmove  rdi,rax
  408e35:	xor    edx,edx
  408e37:	test   dl,dl
  408e39:	lea    r12,[rcx+0x30]
  408e3d:	lea    rax,[rax+0x8]
  408e41:	cmove  r12,rax
  408e45:	mov    rcx,rdi
  408e48:	call   412140 <__swc_fn_e121059d_000140_86bb0f90>
  408e4d:	mov    QWORD PTR [rsi+0x30],0x0
  408e55:	mov    rax,QWORD PTR [r12]
  408e59:	mov    QWORD PTR [rsi+0x38],rax
  408e5d:	test   rax,rax
  408e60:	je     408e6a <__swc_fn_e121059d_000057_7e1dbcb0+0x7a>
  408e62:	mov    rax,QWORD PTR [rsi+0x38]
  408e66:	mov    QWORD PTR [rax+0x30],rsi
  408e6a:	mov    QWORD PTR [r12],rsi
  408e6e:	mov    rcx,rdi
  408e71:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  408e76:	pop    r12
  408e78:	pop    rdi
  408e79:	pop    rsi
  408e7a:	ret
  408e7b:	add    BYTE PTR [rax],al
  408e7d:	add    BYTE PTR [rax],al
	...

0000000000408e80 <__swc_fn_e121059d_000060_15c28ca7>:
  408e80:	lea    rax,[rdx+rdx*4]
  408e84:	lea    rax,[rcx+rax*8+0x268]
  408e8c:	mov    rdx,QWORD PTR [rax+0x10]
  408e90:	sub    QWORD PTR [rcx+0x2a68],rdx
  408e97:	sub    QWORD PTR [rcx+0x2a70],0x1
  408e9f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  408ea6:	lea    rdx,[rdx+rdx*4]
  408eaa:	lea    rdx,[rcx+rdx*8+0x268]
  408eb2:	vmovups xmm0,XMMWORD PTR [rdx]
  408eb6:	vmovups XMMWORD PTR [rax],xmm0
  408eba:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  408ebf:	vmovups XMMWORD PTR [rax+0x10],xmm0
  408ec4:	mov    rcx,QWORD PTR [rdx+0x20]
  408ec8:	mov    QWORD PTR [rax+0x20],rcx
  408ecc:	ret
  408ecd:	add    BYTE PTR [rax],al
	...

0000000000408ed0 <__swc_fn_e121059d_000063_dea90857>:
  408ed0:	push   rsi
  408ed1:	push   rdi
  408ed2:	push   r12
  408ed4:	push   r13
  408ed6:	sub    rsp,0x8
  408eda:	mov    rsi,r8
  408edd:	mov    rdi,rcx
  408ee0:	mov    r12,rdx
  408ee3:	xor    r13d,r13d
  408ee6:	cs nop WORD PTR [rax+rax*1+0x0]
  408ef0:	mov    eax,DWORD PTR [r12+0x730]
  408ef8:	cmp    r13d,eax
  408efb:	jae    408f61 <__swc_fn_e121059d_000063_dea90857+0x91>
  408efd:	lea    rax,[r13+r13*4+0x0]
  408f02:	lea    rax,[r12+rax*8+0x738]
  408f0a:	mov    rdx,QWORD PTR [rax]
  408f0d:	mov    r8,QWORD PTR [rax+0x8]
  408f11:	mov    r9,QWORD PTR [rax+0x10]
  408f15:	cmp    QWORD PTR [rax+0x20],rsi
  408f19:	jb     408f20 <__swc_fn_e121059d_000063_dea90857+0x50>
  408f1b:	inc    r13d
  408f1e:	jmp    408ef0 <__swc_fn_e121059d_000063_dea90857+0x20>
  408f20:	sub    DWORD PTR [r12+0x730],0x1
  408f29:	mov    ecx,DWORD PTR [r12+0x730]
  408f31:	lea    rcx,[rcx+rcx*4]
  408f35:	lea    rcx,[r12+rcx*8+0x738]
  408f3d:	vmovups xmm0,XMMWORD PTR [rcx]
  408f41:	vmovups XMMWORD PTR [rax],xmm0
  408f45:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  408f4a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  408f4f:	mov    rcx,QWORD PTR [rcx+0x20]
  408f53:	mov    QWORD PTR [rax+0x20],rcx
  408f57:	mov    rcx,rdi
  408f5a:	call   40b820 <__swc_fn_e121059d_000043_d3c2ab54>
  408f5f:	jmp    408ef0 <__swc_fn_e121059d_000063_dea90857+0x20>
  408f61:	add    rsp,0x8
  408f65:	pop    r13
  408f67:	pop    r12
  408f69:	pop    rdi
  408f6a:	pop    rsi
  408f6b:	ret
  408f6c:	add    BYTE PTR [rax],al
	...

0000000000408f70 <__swc_fn_e121059d_000066_de167e8d>:
  408f70:	push   rsi
  408f71:	push   rdi
  408f72:	push   r12
  408f74:	push   r13
  408f76:	push   r14
  408f78:	mov    rsi,rcx
  408f7b:	mov    rdi,rdx
  408f7e:	mov    r12,QWORD PTR [rdi]
  408f81:	mov    r13,QWORD PTR [rdi+0x18]
  408f85:	mov    rax,r12
  408f88:	add    rax,QWORD PTR [rdi+0x8]
  408f8c:	sub    rax,r13
  408f8f:	cmp    r8,rax
  408f92:	jbe    408f9d <__swc_fn_e121059d_000066_de167e8d+0x2d>
  408f94:	pop    r14
  408f96:	pop    r13
  408f98:	pop    r12
  408f9a:	pop    rdi
  408f9b:	pop    rsi
  408f9c:	ret
  408f9d:	lea    rax,[r13+r8*1+0x0]
  408fa2:	sub    rax,r12
  408fa5:	mov    ecx,0x1000
  408faa:	test   ecx,ecx
  408fac:	mov    edx,0x8
  408fb1:	cmove  ecx,edx
  408fb4:	dec    rcx
  408fb7:	mov    rdx,0xffffffffffffffff
  408fbe:	sub    rdx,rcx
  408fc1:	cmp    rax,rdx
  408fc4:	jbe    408fcb <__swc_fn_e121059d_000066_de167e8d+0x5b>
  408fc6:	xor    r14d,r14d
  408fc9:	jmp    408fd6 <__swc_fn_e121059d_000066_de167e8d+0x66>
  408fcb:	add    rax,rcx
  408fce:	andn   rax,rcx,rax
  408fd3:	mov    r14,rax
  408fd6:	mov    rax,QWORD PTR [rdi+0x10]
  408fda:	cmp    r14,rax
  408fdd:	ja     408fe8 <__swc_fn_e121059d_000066_de167e8d+0x78>
  408fdf:	pop    r14
  408fe1:	pop    r13
  408fe3:	pop    r12
  408fe5:	pop    rdi
  408fe6:	pop    rsi
  408fe7:	ret
  408fe8:	mov    rax,r12
  408feb:	add    rax,QWORD PTR [rdi+0x10]
  408fef:	mov    rdx,r14
  408ff2:	sub    rdx,QWORD PTR [rdi+0x10]
  408ff6:	mov    rcx,rax
  408ff9:	call   40b370 <__swc_fn_e121059d_000007_f7acedb0>
  408ffe:	test   al,al
  409000:	jne    40900b <__swc_fn_e121059d_000066_de167e8d+0x9b>
  409002:	pop    r14
  409004:	pop    r13
  409006:	pop    r12
  409008:	pop    rdi
  409009:	pop    rsi
  40900a:	ret
  40900b:	add    r12,r14
  40900e:	sub    r12,r13
  409011:	mov    rcx,r12
  409014:	sub    rcx,QWORD PTR [rdi+0x28]
  409018:	mov    rdx,QWORD PTR [rsi+0x250]
  40901f:	nop
  409020:	lea    r8,[rdx+rcx*1]
  409024:	mov    rax,rdx
  409027:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  409030:	cmp    rax,rdx
  409033:	je     40903a <__swc_fn_e121059d_000066_de167e8d+0xca>
  409035:	mov    rdx,rax
  409038:	jmp    409020 <__swc_fn_e121059d_000066_de167e8d+0xb0>
  40903a:	mov    QWORD PTR [rdi+0x10],r14
  40903e:	mov    QWORD PTR [rdi+0x28],r12
  409042:	pop    r14
  409044:	pop    r13
  409046:	pop    r12
  409048:	pop    rdi
  409049:	pop    rsi
  40904a:	ret
  40904b:	add    BYTE PTR [rax],al
  40904d:	add    BYTE PTR [rax],al
	...

0000000000409050 <__swc_fn_e121059d_000069_7130736e>:
  409050:	push   rbx
  409051:	push   rsi
  409052:	push   rdi
  409053:	push   r12
  409055:	push   r13
  409057:	sub    rsp,0xe0
  40905e:	mov    rbx,rdx
  409061:	mov    rsi,rcx
  409064:	cmp    DWORD PTR [rbx+0x58],0x0
  409068:	je     40908c <__swc_fn_e121059d_000069_7130736e+0x3c>
  40906a:	mov    eax,DWORD PTR [rbx+0x58]
  40906d:	sub    eax,0x1
  409070:	test   DWORD PTR [rbx+0x58],eax
  409073:	je     40908c <__swc_fn_e121059d_000069_7130736e+0x3c>
  409075:	mov    QWORD PTR [rbx+0x40],0x0
  40907d:	add    rsp,0xe0
  409084:	pop    r13
  409086:	pop    r12
  409088:	pop    rdi
  409089:	pop    rsi
  40908a:	pop    rbx
  40908b:	ret
  40908c:	mov    rax,QWORD PTR [rbx+0x40]
  409090:	test   rax,rax
  409093:	jne    4090af <__swc_fn_e121059d_000069_7130736e+0x5f>
  409095:	mov    rcx,rsi
  409098:	mov    rdx,rbx
  40909b:	call   410db0 <__swc_fn_e121059d_000068_f3aa21af>
  4090a0:	add    rsp,0xe0
  4090a7:	pop    r13
  4090a9:	pop    r12
  4090ab:	pop    rdi
  4090ac:	pop    rsi
  4090ad:	pop    rbx
  4090ae:	ret
  4090af:	cmp    QWORD PTR [rbx+0x48],0x0
  4090b4:	jne    4090d0 <__swc_fn_e121059d_000069_7130736e+0x80>
  4090b6:	mov    rcx,rsi
  4090b9:	mov    rdx,rbx
  4090bc:	call   40c050 <__swc_fn_e121059d_000070_97813b89>
  4090c1:	add    rsp,0xe0
  4090c8:	pop    r13
  4090ca:	pop    r12
  4090cc:	pop    rdi
  4090cd:	pop    rsi
  4090ce:	pop    rbx
  4090cf:	ret
  4090d0:	mov    rdi,QWORD PTR [rbx+0x40]
  4090d4:	lea    rax,[rip+0x1af9d]        # 424078 <__swc_bss_base_e121059d+0x38>
  4090db:	mov    rcx,rdi
  4090de:	sub    rcx,QWORD PTR [rax+0x8]
  4090e2:	mov    rax,QWORD PTR [rip+0x1af9f]        # 424088 <__swc_bss_base_e121059d+0x48>
  4090e9:	cmp    rcx,rax
  4090ec:	jae    409118 <__swc_fn_e121059d_000069_7130736e+0xc8>
  4090ee:	mov    rax,rdi
  4090f1:	and    rax,0xffffffffffc00000
  4090f8:	mov    rcx,rdi
  4090fb:	shr    rcx,0x10
  4090ff:	and    ecx,0x3f
  409102:	mov    edx,DWORD PTR [rax+0x28]
  409105:	shrx   ecx,ecx,edx
  40910a:	shl    rcx,0x4
  40910e:	lea    r12,[rax+rcx*8+0x80]
  409116:	jmp    409123 <__swc_fn_e121059d_000069_7130736e+0xd3>
  409118:	mov    rcx,rdi
  40911b:	call   40fe30 <__swc_fn_e121059d_000026_bcdc5519>
  409120:	mov    r12,rax
  409123:	test   r12,r12
  409126:	je     409135 <__swc_fn_e121059d_000069_7130736e+0xe5>
  409128:	mov    eax,DWORD PTR [r12+0x2c]
  40912d:	mov    r9d,eax
  409130:	mov    r13,rax
  409133:	jmp    4091b4 <__swc_fn_e121059d_000069_7130736e+0x164>
  409135:	mov    rcx,rsi
  409138:	mov    rdx,rdi
  40913b:	call   410440 <__swc_fn_e121059d_000056_df0696cd>
  409140:	mov    rcx,QWORD PTR [rax+0x28]
  409144:	mov    r9,rcx
  409147:	mov    rdx,QWORD PTR [rax+0x20]
  40914b:	mov    r13,rdx
  40914e:	cmp    QWORD PTR [rbx+0x48],rcx
  409152:	jbe    40918b <__swc_fn_e121059d_000069_7130736e+0x13b>
  409154:	mov    ecx,DWORD PTR [rax+0x48]
  409157:	cmp    DWORD PTR [rbx+0x58],ecx
  40915a:	ja     40918b <__swc_fn_e121059d_000069_7130736e+0x13b>
  40915c:	mov    rcx,rsi
  40915f:	mov    rdx,rax
  409162:	mov    r8,QWORD PTR [rbx+0x48]
  409166:	mov    QWORD PTR [rsp+0xc8],r9
  40916e:	mov    QWORD PTR [rsp+0xd0],rax
  409176:	call   408f70 <__swc_fn_e121059d_000066_de167e8d>
  40917b:	mov    r9,QWORD PTR [rsp+0xc8]
  409183:	mov    rax,QWORD PTR [rsp+0xd0]
  40918b:	mov    rcx,QWORD PTR [rax+0x28]
  40918f:	cmp    QWORD PTR [rbx+0x48],rcx
  409193:	ja     4091b4 <__swc_fn_e121059d_000069_7130736e+0x164>
  409195:	mov    ecx,DWORD PTR [rax+0x48]
  409198:	cmp    DWORD PTR [rbx+0x58],ecx
  40919b:	ja     4091b4 <__swc_fn_e121059d_000069_7130736e+0x164>
  40919d:	mov    rcx,QWORD PTR [rbx+0x48]
  4091a1:	mov    QWORD PTR [rax+0x20],rcx
  4091a5:	add    rsp,0xe0
  4091ac:	pop    r13
  4091ae:	pop    r12
  4091b0:	pop    rdi
  4091b1:	pop    rsi
  4091b2:	pop    rbx
  4091b3:	ret
  4091b4:	test   r12,r12
  4091b7:	je     4091e9 <__swc_fn_e121059d_000069_7130736e+0x199>
  4091b9:	cmp    QWORD PTR [rbx+0x48],r9
  4091bd:	ja     4091e9 <__swc_fn_e121059d_000069_7130736e+0x199>
  4091bf:	cmp    DWORD PTR [rbx+0x58],0x40
  4091c3:	ja     4091e9 <__swc_fn_e121059d_000069_7130736e+0x199>
  4091c5:	cmp    DWORD PTR [rbx+0x58],0x0
  4091c9:	je     4091d6 <__swc_fn_e121059d_000069_7130736e+0x186>
  4091cb:	mov    ecx,DWORD PTR [rbx+0x58]
  4091ce:	dec    rcx
  4091d1:	test   rdi,rcx
  4091d4:	jne    4091e9 <__swc_fn_e121059d_000069_7130736e+0x199>
  4091d6:	mov    QWORD PTR [rbx+0x40],rdi
  4091da:	add    rsp,0xe0
  4091e1:	pop    r13
  4091e3:	pop    r12
  4091e5:	pop    rdi
  4091e6:	pop    rsi
  4091e7:	pop    rbx
  4091e8:	ret
  4091e9:	vmovups xmm0,XMMWORD PTR [rbx]
  4091ed:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4091f3:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  4091f8:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4091fe:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  409203:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409209:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40920e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  409214:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  409219:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40921f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  409224:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40922a:	mov    QWORD PTR [rsp+0x48],0x0
  409233:	mov    rcx,rsi
  409236:	lea    rdx,[rsp+0x8]
  40923b:	call   410db0 <__swc_fn_e121059d_000068_f3aa21af>
  409240:	mov    rax,QWORD PTR [rsp+0x48]
  409245:	test   rax,rax
  409248:	jne    409261 <__swc_fn_e121059d_000069_7130736e+0x211>
  40924a:	mov    QWORD PTR [rbx+0x40],0x0
  409252:	add    rsp,0xe0
  409259:	pop    r13
  40925b:	pop    r12
  40925d:	pop    rdi
  40925e:	pop    rsi
  40925f:	pop    rbx
  409260:	ret
  409261:	mov    rax,QWORD PTR [rbx+0x48]
  409265:	cmp    r13,rax
  409268:	cmovbe rax,r13
  40926c:	mov    rcx,QWORD PTR [rsp+0x48]
  409271:	mov    rdx,rdi
  409274:	mov    r8,rax
  409277:	call   411980 <__swc_fn_e121059d_000110_7c204aac>
  40927c:	vmovups xmm0,XMMWORD PTR [rbx]
  409280:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  409286:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40928b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  409291:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  409296:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40929f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  4092a4:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4092ad:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  4092b2:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4092bb:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  4092c0:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4092c9:	mov    QWORD PTR [rsp+0xa8],rdi
  4092d1:	mov    rcx,rsi
  4092d4:	lea    rdx,[rsp+0x68]
  4092d9:	call   40c050 <__swc_fn_e121059d_000070_97813b89>
  4092de:	mov    rax,QWORD PTR [rsp+0x48]
  4092e3:	mov    QWORD PTR [rbx+0x40],rax
  4092e7:	add    rsp,0xe0
  4092ee:	pop    r13
  4092f0:	pop    r12
  4092f2:	pop    rdi
  4092f3:	pop    rsi
  4092f4:	pop    rbx
  4092f5:	ret
	...

0000000000409300 <__swc_fn_e121059d_000072_61e60aab>:
  409300:	push   r12
  409302:	push   rdi
  409303:	push   rsi
  409304:	push   r13
  409306:	push   r14
  409308:	sub    rsp,0x190
  40930f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  409318:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  409321:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40932a:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  409333:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40933c:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  409345:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40934e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  409357:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  409360:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  409369:	mov    r12,rcx
  40936c:	lea    rax,[rip+0x18c95]        # 422008 <__swc_data_base_e121059d+0x8>
  409373:	mov    rax,QWORD PTR [rax]
  409376:	cmp    rax,0xffffffffffffffff
  40937a:	je     409389 <__swc_fn_e121059d_000072_61e60aab+0x89>
  40937c:	mov    eax,eax
  40937e:	mov    edi,eax
  409380:	xor    eax,eax
  409382:	call   407000 <pthread_getspecific@plt>
  409387:	jmp    40938b <__swc_fn_e121059d_000072_61e60aab+0x8b>
  409389:	xor    eax,eax
  40938b:	test   rax,rax
  40938e:	jne    40939d <__swc_fn_e121059d_000072_61e60aab+0x9d>
  409390:	call   40ff00 <__swc_fn_e121059d_000035_cd1a4e8c>
  409395:	mov    rcx,rax
  409398:	call   40dc60 <__swc_fn_e121059d_000133_5f757033>
  40939d:	test   rax,rax
  4093a0:	je     4093c6 <__swc_fn_e121059d_000072_61e60aab+0xc6>
  4093a2:	cmp    QWORD PTR [rax],r12
  4093a5:	jne    4093c6 <__swc_fn_e121059d_000072_61e60aab+0xc6>
  4093a7:	xor    ecx,ecx
  4093a9:	mov    QWORD PTR [rsp+0xc8],rax
  4093b1:	call   40b7f0 <__swc_fn_e121059d_000037_28d0e998>
  4093b6:	mov    rdx,QWORD PTR [rsp+0xc8]
  4093be:	mov    rcx,r12
  4093c1:	call   40b900 <__swc_fn_e121059d_000046_b30433d0>
  4093c6:	lea    rsi,[r12+0x10]
  4093cb:	mov    rcx,rsi
  4093ce:	call   412140 <__swc_fn_e121059d_000140_86bb0f90>
  4093d3:	mov    rdi,QWORD PTR [r12+0x20]
  4093d8:	test   rdi,rdi
  4093db:	je     40941e <__swc_fn_e121059d_000072_61e60aab+0x11e>
  4093dd:	nop    DWORD PTR [rax]
  4093e0:	mov    rcx,r12
  4093e3:	mov    rdx,rdi
  4093e6:	call   4100c0 <__swc_fn_e121059d_000047_6e7a8d58>
  4093eb:	mov    rcx,r12
  4093ee:	mov    rdx,rdi
  4093f1:	mov    r8,0xffffffffffffffff
  4093f8:	call   408ed0 <__swc_fn_e121059d_000063_dea90857>
  4093fd:	mov    rcx,r12
  409400:	mov    rdx,rdi
  409403:	mov    r8d,0x9b8
  409409:	mov    r9d,0x9b8
  40940f:	call   40b820 <__swc_fn_e121059d_000043_d3c2ab54>
  409414:	mov    rdi,QWORD PTR [r12+0x20]
  409419:	test   rdi,rdi
  40941c:	jne    4093e0 <__swc_fn_e121059d_000072_61e60aab+0xe0>
  40941e:	xor    eax,eax
  409420:	xchg   QWORD PTR [r12+0x2a80],rax
  409428:	test   rax,rax
  40942b:	je     409451 <__swc_fn_e121059d_000072_61e60aab+0x151>
  40942d:	cs nop WORD PTR [rax+rax*1+0x0]
  409437:	nop    WORD PTR [rax+rax*1+0x0]
  409440:	mov    rcx,rax
  409443:	mov    rax,QWORD PTR [rax+0x78]
  409447:	xor    edx,edx
  409449:	xchg   DWORD PTR [rcx+0x70],edx
  40944c:	test   rax,rax
  40944f:	jne    409440 <__swc_fn_e121059d_000072_61e60aab+0x140>
  409451:	mov    rax,QWORD PTR [r12+0x18]
  409456:	mov    rdi,rax
  409459:	test   rdi,rdi
  40945c:	je     4094f1 <__swc_fn_e121059d_000072_61e60aab+0x1f1>
  409462:	cs nop WORD PTR [rax+rax*1+0x0]
  40946c:	nop    DWORD PTR [rax+0x0]
  409470:	mov    rax,QWORD PTR [rdi+0x10]
  409474:	mov    r8d,DWORD PTR [rdi+0x2c]
  409478:	xor    r9d,r9d
  40947b:	test   r8,r8
  40947e:	jbe    4094dd <__swc_fn_e121059d_000072_61e60aab+0x1dd>
  409480:	mov    ecx,r9d
  409483:	shl    rcx,0x4
  409487:	lea    rdx,[rdi+rcx*8+0x80]
  40948f:	cmp    BYTE PTR [rdx+0x3b],0x0
  409493:	je     4094d4 <__swc_fn_e121059d_000072_61e60aab+0x1d4>
  409495:	mov    DWORD PTR [rdx+0x28],0x0
  40949c:	mov    rcx,rdi
  40949f:	mov    QWORD PTR [rsp+0xd0],rax
  4094a7:	mov    QWORD PTR [rsp+0xd8],r8
  4094af:	mov    QWORD PTR [rsp+0xe0],r9
  4094b7:	call   408600 <__swc_fn_e121059d_000018_283e2b5e>
  4094bc:	mov    rax,QWORD PTR [rsp+0xd0]
  4094c4:	mov    r8,QWORD PTR [rsp+0xd8]
  4094cc:	mov    r9,QWORD PTR [rsp+0xe0]
  4094d4:	add    r9,0x1
  4094d8:	cmp    r9,r8
  4094db:	jb     409480 <__swc_fn_e121059d_000072_61e60aab+0x180>
  4094dd:	mov    rcx,rdi
  4094e0:	mov    rdi,rax
  4094e3:	call   40b700 <__swc_fn_e121059d_000025_aa910677>
  4094e8:	test   rdi,rdi
  4094eb:	jne    409470 <__swc_fn_e121059d_000072_61e60aab+0x170>
  4094f1:	mov    QWORD PTR [r12+0x18],0x0
  4094fa:	mov    QWORD PTR [r12+0x28],0x0
  409503:	mov    rcx,rsi
  409506:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  40950b:	mov    esi,0x8
  409510:	xor    edi,edi
  409512:	test   rsi,rsi
  409515:	je     409572 <__swc_fn_e121059d_000072_61e60aab+0x272>
  40951b:	nop    DWORD PTR [rax+rax*1+0x0]
  409520:	lea    r13,[rdi*8+0x0]
  409528:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40952d:	test   r14,r14
  409530:	je     409568 <__swc_fn_e121059d_000072_61e60aab+0x268>
  409532:	cs nop WORD PTR [rax+rax*1+0x0]
  40953c:	nop    DWORD PTR [rax+0x0]
  409540:	mov    rcx,r12
  409543:	mov    rdx,r14
  409546:	call   40beb0 <__swc_fn_e121059d_000058_1bb23e77>
  40954b:	mov    rcx,r12
  40954e:	mov    rdx,QWORD PTR [r14]
  409551:	mov    r8,QWORD PTR [r14+0x8]
  409555:	mov    r9,QWORD PTR [r14+0x10]
  409559:	call   40b820 <__swc_fn_e121059d_000043_d3c2ab54>
  40955e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  409563:	test   r14,r14
  409566:	jne    409540 <__swc_fn_e121059d_000072_61e60aab+0x240>
  409568:	add    rdi,0x1
  40956c:	sub    rsi,0x1
  409570:	jne    409520 <__swc_fn_e121059d_000072_61e60aab+0x220>
  409572:	mov    rcx,r12
  409575:	call   40bf80 <__swc_fn_e121059d_000064_ffcd96eb>
  40957a:	lea    rcx,[r12+0x250]
  409582:	mov    rdx,QWORD PTR [rcx]
  409585:	mov    r8,QWORD PTR [r12+0x250]
  40958d:	nop    DWORD PTR [rax]
  409590:	mov    r9,r8
  409593:	sub    r9,rdx
  409596:	mov    rax,r8
  409599:	lock cmpxchg QWORD PTR [rcx],r9
  40959e:	cmp    rax,r8
  4095a1:	je     4095a8 <__swc_fn_e121059d_000072_61e60aab+0x2a8>
  4095a3:	mov    r8,rax
  4095a6:	jmp    409590 <__swc_fn_e121059d_000072_61e60aab+0x290>
  4095a8:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  4095b1:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  4095ba:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  4095c3:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  4095cc:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  4095d5:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  4095de:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  4095e7:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  4095f0:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  4095f9:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  409602:	add    rsp,0x190
  409609:	pop    r14
  40960b:	pop    r13
  40960d:	pop    rsi
  40960e:	pop    rdi
  40960f:	pop    r12
  409611:	ret
	...

0000000000409620 <__swc_fn_e121059d_000075_64d36d78>:
  409620:	sub    rsp,0x8
  409624:	mov    QWORD PTR [rdx+0x40],0x0
  40962c:	call   410db0 <__swc_fn_e121059d_000068_f3aa21af>
  409631:	add    rsp,0x8
  409635:	ret
	...

0000000000409640 <__swc_fn_e121059d_000078_1966ae2e>:
  409640:	sub    rsp,0x8
  409644:	call   40c050 <__swc_fn_e121059d_000070_97813b89>
  409649:	add    rsp,0x8
  40964d:	ret
	...

0000000000409650 <__swc_fn_e121059d_000081_5cc7acfc>:
  409650:	push   rbx
  409651:	push   rsi
  409652:	push   rdi
  409653:	push   r12
  409655:	push   r13
  409657:	push   r14
  409659:	push   r15
  40965b:	sub    rsp,0x20
  40965f:	mov    rbx,r11
  409662:	mov    rsi,rcx
  409665:	mov    rdi,rdx
  409668:	mov    r12,r8
  40966b:	mov    r13,r9
  40966e:	mov    r14,r10
  409671:	mov    rcx,QWORD PTR [rip+0x1a9c8]        # 424040 <__swc_bss_base_e121059d>
  409678:	test   rcx,rcx
  40967b:	jne    40968d <__swc_fn_e121059d_000081_5cc7acfc+0x3d>
  40967d:	call   412a40 <__swc_fn_e121059d_000170_994c8876>
  409682:	lea    rcx,[rax+0x1]
  409686:	mov    QWORD PTR [rip+0x1a9b3],rcx        # 424040 <__swc_bss_base_e121059d>
  40968d:	dec    rcx
  409690:	call   40f6e0 <__swc_fn_e121059d_000172_360af05d>
  409695:	mov    r15,rax
  409698:	lea    r11,[rip+0x1aba1]        # 424240 <__swc_bss_base_e121059d+0x200>
  40969f:	mov    rcx,r11
  4096a2:	call   40b810 <__swc_fn_e121059d_000040_eb6108f2>
  4096a7:	test   al,al
  4096a9:	jne    4096ba <__swc_fn_e121059d_000081_5cc7acfc+0x6a>
  4096ab:	mov    rcx,r11
  4096ae:	call   40ff60 <__swc_fn_e121059d_000038_14f56618>
  4096b3:	lea    r11,[rip+0x1ab86]        # 424240 <__swc_bss_base_e121059d+0x200>
  4096ba:	mov    rcx,r11
  4096bd:	mov    rdx,rsi
  4096c0:	mov    r8,rdi
  4096c3:	mov    r9,r12
  4096c6:	mov    r10,r13
  4096c9:	mov    rsi,r11
  4096cc:	mov    r11,r14
  4096cf:	call   408970 <__swc_fn_e121059d_000039_03f1bf9a>
  4096d4:	test   bl,bl
  4096d6:	je     4096fd <__swc_fn_e121059d_000081_5cc7acfc+0xad>
  4096d8:	mov    QWORD PTR [rsp+0x8],rsi
  4096dd:	lea    rax,[rip+0x9c54]        # 413338 <__swc_rdata_base_e121059d+0x228>
  4096e4:	mov    QWORD PTR [rsp+0x10],rax
  4096e9:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4096ef:	vmovups XMMWORD PTR [r15],xmm0
  4096f4:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  4096fd:	mov    rax,rsi
  409700:	add    rsp,0x20
  409704:	pop    r15
  409706:	pop    r14
  409708:	pop    r13
  40970a:	pop    r12
  40970c:	pop    rdi
  40970d:	pop    rsi
  40970e:	pop    rbx
  40970f:	ret

0000000000409710 <__swc_fn_e121059d_000084_cf82995a>:
  409710:	sub    rsp,0x8
  409714:	mov    rax,rcx
  409717:	test   rcx,rcx
  40971a:	jne    409721 <__swc_fn_e121059d_000084_cf82995a+0x11>
  40971c:	add    rsp,0x8
  409720:	ret
  409721:	lea    rcx,[rax-0x10]
  409725:	mov    rax,QWORD PTR [rax-0x10]
  409729:	mov    rdx,rax
  40972c:	call   40d910 <__swc_fn_e121059d_000118_ed2d8fed>
  409731:	add    rsp,0x8
  409735:	ret
	...

0000000000409740 <__swc_fn_e121059d_000087_ef55f6e4>:
  409740:	sub    rsp,0x8
  409744:	xor    r11d,r11d
  409747:	call   40c310 <__swc_fn_e121059d_000088_0d280354>
  40974c:	add    rsp,0x8
  409750:	ret
	...

0000000000409760 <__swc_fn_e121059d_000090_23214800>:
  409760:	push   rsi
  409761:	push   rdi
  409762:	push   r12
  409764:	push   r13
  409766:	push   r14
  409768:	push   r15
  40976a:	sub    rsp,0x68
  40976e:	mov    rsi,r9
  409771:	mov    rdi,rcx
  409774:	mov    r12,rdx
  409777:	mov    r13,r8
  40977a:	cmp    r8,r9
  40977d:	jne    4097a5 <__swc_fn_e121059d_000090_23214800+0x45>
  40977f:	mov    rcx,rdi
  409782:	mov    rdx,r12
  409785:	xor    r8d,r8d
  409788:	call   40c660 <__swc_fn_e121059d_000094_63c1827b>
  40978d:	test   al,al
  40978f:	je     4097a5 <__swc_fn_e121059d_000090_23214800+0x45>
  409791:	mov    eax,0x1
  409796:	add    rsp,0x68
  40979a:	pop    r15
  40979c:	pop    r14
  40979e:	pop    r13
  4097a0:	pop    r12
  4097a2:	pop    rdi
  4097a3:	pop    rsi
  4097a4:	ret
  4097a5:	cmp    BYTE PTR [r12+0x2c],0xe
  4097ab:	je     4097be <__swc_fn_e121059d_000090_23214800+0x5e>
  4097ad:	xor    eax,eax
  4097af:	add    rsp,0x68
  4097b3:	pop    r15
  4097b5:	pop    r14
  4097b7:	pop    r13
  4097b9:	pop    r12
  4097bb:	pop    rdi
  4097bc:	pop    rsi
  4097bd:	ret
  4097be:	mov    r14,QWORD PTR [r12+0x98]
  4097c6:	mov    rax,QWORD PTR [r12+0xa0]
  4097ce:	mov    r12,rax
  4097d1:	xor    r15d,r15d
  4097d4:	test   r12,r12
  4097d7:	je     40983f <__swc_fn_e121059d_000090_23214800+0xdf>
  4097d9:	nop    DWORD PTR [rax+0x0]
  4097e0:	mov    QWORD PTR [rsp+0x58],r12
  4097e5:	lea    r12,[r15*8+0x0]
  4097ed:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  4097f2:	mov    rcx,rax
  4097f5:	call   411540 <__swc_fn_e121059d_000086_3953ef98>
  4097fa:	cmp    BYTE PTR [rax+0x2c],0xe
  4097fe:	jne    409830 <__swc_fn_e121059d_000090_23214800+0xd0>
  409800:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  409805:	lea    r8,[r13+rcx*1+0x0]
  40980a:	mov    rcx,rdi
  40980d:	mov    rdx,rax
  409810:	mov    r9,rsi
  409813:	call   409760 <__swc_fn_e121059d_000090_23214800>
  409818:	test   al,al
  40981a:	je     409830 <__swc_fn_e121059d_000090_23214800+0xd0>
  40981c:	mov    eax,0x1
  409821:	add    rsp,0x68
  409825:	pop    r15
  409827:	pop    r14
  409829:	pop    r13
  40982b:	pop    r12
  40982d:	pop    rdi
  40982e:	pop    rsi
  40982f:	ret
  409830:	add    r15,0x1
  409834:	mov    r12,QWORD PTR [rsp+0x58]
  409839:	sub    r12,0x1
  40983d:	jne    4097e0 <__swc_fn_e121059d_000090_23214800+0x80>
  40983f:	xor    eax,eax
  409841:	add    rsp,0x68
  409845:	pop    r15
  409847:	pop    r14
  409849:	pop    r13
  40984b:	pop    r12
  40984d:	pop    rdi
  40984e:	pop    rsi
  40984f:	ret

0000000000409850 <__swc_fn_e121059d_000093_c2567a3b>:
  409850:	push   rbp
  409851:	push   rbx
  409852:	push   rsi
  409853:	push   rdi
  409854:	push   r12
  409856:	push   r13
  409858:	push   r14
  40985a:	push   r15
  40985c:	sub    rsp,0x38
  409860:	mov    rbp,rsp
  409863:	mov    rbx,r11
  409866:	mov    rsi,rdx
  409869:	mov    rdi,r8
  40986c:	mov    r12,r9
  40986f:	mov    QWORD PTR [rsp+0x18],r9
  409874:	mov    r13,r10
  409877:	movzx  r14d,BYTE PTR [rbp+0x80]
  40987f:	movzx  r15d,BYTE PTR [rbp+0x88]
  409887:	test   r11,r11
  40988a:	je     409890 <__swc_fn_e121059d_000093_c2567a3b+0x40>
  40988c:	xor    eax,eax
  40988e:	mov    BYTE PTR [rbx],al
  409890:	test   r12,r12
  409893:	je     40989e <__swc_fn_e121059d_000093_c2567a3b+0x4e>
  409895:	mov    QWORD PTR [r12+0x8],0x0
  40989e:	test   rcx,rcx
  4098a1:	je     4098a8 <__swc_fn_e121059d_000093_c2567a3b+0x58>
  4098a3:	test   rsi,rsi
  4098a6:	jne    4098bb <__swc_fn_e121059d_000093_c2567a3b+0x6b>
  4098a8:	xor    eax,eax
  4098aa:	add    rsp,0x38
  4098ae:	pop    r15
  4098b0:	pop    r14
  4098b2:	pop    r13
  4098b4:	pop    r12
  4098b6:	pop    rdi
  4098b7:	pop    rsi
  4098b8:	pop    rbx
  4098b9:	pop    rbp
  4098ba:	ret
  4098bb:	call   411540 <__swc_fn_e121059d_000086_3953ef98>
  4098c0:	mov    r12,rax
  4098c3:	mov    al,r15b
  4098c6:	test   r15b,r15b
  4098c9:	jne    4098d9 <__swc_fn_e121059d_000093_c2567a3b+0x89>
  4098cb:	mov    eax,DWORD PTR [r12+0x28]
  4098d0:	and    eax,0x10000
  4098d6:	setne  al
  4098d9:	lea    r15,[rsp+0x8]
  4098de:	mov    QWORD PTR [rsp+0x20],r15
  4098e3:	rex mov BYTE PTR [rsp+0x8],al
  4098e8:	test   DWORD PTR [rsi+0x28],0x400000
  4098ef:	je     409927 <__swc_fn_e121059d_000093_c2567a3b+0xd7>
  4098f1:	test   rsi,rsi
  4098f4:	je     409914 <__swc_fn_e121059d_000093_c2567a3b+0xc4>
  4098f6:	mov    rax,QWORD PTR [rsi+0x38]
  4098fa:	cmp    QWORD PTR [rax+0x10],rsi
  4098fe:	jne    409914 <__swc_fn_e121059d_000093_c2567a3b+0xc4>
  409900:	rex mov al,BYTE PTR [rsp+0x8]
  409905:	test   al,al
  409907:	sete   al
  40990a:	test   r14b,r14b
  40990d:	sete   cl
  409910:	test   al,cl
  409912:	je     409927 <__swc_fn_e121059d_000093_c2567a3b+0xd7>
  409914:	xor    eax,eax
  409916:	add    rsp,0x38
  40991a:	pop    r15
  40991c:	pop    r14
  40991e:	pop    r13
  409920:	pop    r12
  409922:	pop    rdi
  409923:	pop    rsi
  409924:	pop    rbx
  409925:	pop    rbp
  409926:	ret
  409927:	mov    r15,r12
  40992a:	test   r14b,r14b
  40992d:	jne    409944 <__swc_fn_e121059d_000093_c2567a3b+0xf4>
  40992f:	cmp    BYTE PTR [r12+0x2c],0x6
  409935:	jne    409944 <__swc_fn_e121059d_000093_c2567a3b+0xf4>
  409937:	mov    rcx,QWORD PTR [r12+0x40]
  40993c:	call   411540 <__swc_fn_e121059d_000086_3953ef98>
  409941:	mov    r15,rax
  409944:	test   r14b,r14b
  409947:	je     40994d <__swc_fn_e121059d_000093_c2567a3b+0xfd>
  409949:	mov    r15,QWORD PTR [r15+0x30]
  40994d:	mov    rcx,rsi
  409950:	call   411540 <__swc_fn_e121059d_000086_3953ef98>
  409955:	mov    rsi,rax
  409958:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40995d:	je     409994 <__swc_fn_e121059d_000093_c2567a3b+0x144>
  40995f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  409964:	je     409994 <__swc_fn_e121059d_000093_c2567a3b+0x144>
  409966:	mov    eax,DWORD PTR [rsi+0x28]
  409969:	and    eax,0x10000
  40996f:	je     409994 <__swc_fn_e121059d_000093_c2567a3b+0x144>
  409971:	rex mov al,BYTE PTR [rsp+0x8]
  409976:	test   al,al
  409978:	jne    40998d <__swc_fn_e121059d_000093_c2567a3b+0x13d>
  40997a:	xor    eax,eax
  40997c:	add    rsp,0x38
  409980:	pop    r15
  409982:	pop    r14
  409984:	pop    r13
  409986:	pop    r12
  409988:	pop    rdi
  409989:	pop    rsi
  40998a:	pop    rbx
  40998b:	pop    rbp
  40998c:	ret
  40998d:	mov    rax,QWORD PTR [rsi+0x30]
  409991:	mov    rsi,rax
  409994:	mov    r14b,r13b
  409997:	test   rbx,rbx
  40999a:	je     4099d0 <__swc_fn_e121059d_000093_c2567a3b+0x180>
  40999c:	cmp    BYTE PTR [r12+0x2c],0x6
  4099a2:	jne    4099d0 <__swc_fn_e121059d_000093_c2567a3b+0x180>
  4099a4:	lea    rdx,[rip+0x99bd]        # 413368 <__swc_rdata_base_e121059d+0x258>
  4099ab:	mov    rcx,rsi
  4099ae:	xor    r8d,r8d
  4099b1:	call   40c660 <__swc_fn_e121059d_000094_63c1827b>
  4099b6:	test   al,al
  4099b8:	je     4099d0 <__swc_fn_e121059d_000093_c2567a3b+0x180>
  4099ba:	mov    BYTE PTR [rbx],0x1
  4099bd:	xor    eax,eax
  4099bf:	add    rsp,0x38
  4099c3:	pop    r15
  4099c5:	pop    r14
  4099c7:	pop    r13
  4099c9:	pop    r12
  4099cb:	pop    rdi
  4099cc:	pop    rsi
  4099cd:	pop    rbx
  4099ce:	pop    rbp
  4099cf:	ret
  4099d0:	test   rdi,rdi
  4099d3:	jne    4099ed <__swc_fn_e121059d_000093_c2567a3b+0x19d>
  4099d5:	test   r13b,r13b
  4099d8:	jne    4099ed <__swc_fn_e121059d_000093_c2567a3b+0x19d>
  4099da:	xor    eax,eax
  4099dc:	add    rsp,0x38
  4099e0:	pop    r15
  4099e2:	pop    r14
  4099e4:	pop    r13
  4099e6:	pop    r12
  4099e8:	pop    rdi
  4099e9:	pop    rsi
  4099ea:	pop    rbx
  4099eb:	pop    rbp
  4099ec:	ret
  4099ed:	rex cmp BYTE PTR [rsi+0x2c],0x6
  4099f2:	jne    409aa8 <__swc_fn_e121059d_000093_c2567a3b+0x258>
  4099f8:	mov    rcx,r15
  4099fb:	mov    rdx,rsi
  4099fe:	xor    r8d,r8d
  409a01:	call   40c660 <__swc_fn_e121059d_000094_63c1827b>
  409a06:	test   al,al
  409a08:	jne    409aa8 <__swc_fn_e121059d_000093_c2567a3b+0x258>
  409a0e:	test   DWORD PTR [rsi+0x28],0x10000
  409a15:	je     409a33 <__swc_fn_e121059d_000093_c2567a3b+0x1e3>
  409a17:	rex mov al,BYTE PTR [rsp+0x8]
  409a1c:	test   al,al
  409a1e:	jne    409a33 <__swc_fn_e121059d_000093_c2567a3b+0x1e3>
  409a20:	xor    eax,eax
  409a22:	add    rsp,0x38
  409a26:	pop    r15
  409a28:	pop    r14
  409a2a:	pop    r13
  409a2c:	pop    r12
  409a2e:	pop    rdi
  409a2f:	pop    rsi
  409a30:	pop    rbx
  409a31:	pop    rbp
  409a32:	ret
  409a33:	test   rdi,rdi
  409a36:	jne    409a4b <__swc_fn_e121059d_000093_c2567a3b+0x1fb>
  409a38:	xor    eax,eax
  409a3a:	add    rsp,0x38
  409a3e:	pop    r15
  409a40:	pop    r14
  409a42:	pop    r13
  409a44:	pop    r12
  409a46:	pop    rdi
  409a47:	pop    rsi
  409a48:	pop    rbx
  409a49:	pop    rbp
  409a4a:	ret
  409a4b:	mov    rcx,QWORD PTR [rsi+0x40]
  409a4f:	call   411540 <__swc_fn_e121059d_000086_3953ef98>
  409a54:	mov    rsi,rax
  409a57:	mov    rax,QWORD PTR [rdi]
  409a5a:	mov    rdi,rax
  409a5d:	test   rax,rax
  409a60:	jne    409aa3 <__swc_fn_e121059d_000093_c2567a3b+0x253>
  409a62:	test   rbx,rbx
  409a65:	je     409aa3 <__swc_fn_e121059d_000093_c2567a3b+0x253>
  409a67:	mov    rcx,r15
  409a6a:	mov    rdx,rsi
  409a6d:	xor    r8d,r8d
  409a70:	call   40c660 <__swc_fn_e121059d_000094_63c1827b>
  409a75:	mov    rcx,rax
  409a78:	test   al,al
  409a7a:	jne    409a9c <__swc_fn_e121059d_000093_c2567a3b+0x24c>
  409a7c:	mov    rcx,r15
  409a7f:	mov    rdx,rsi
  409a82:	call   411580 <__swc_fn_e121059d_000089_d182c4dc>
  409a87:	mov    rcx,rax
  409a8a:	test   al,al
  409a8c:	jne    409a9c <__swc_fn_e121059d_000093_c2567a3b+0x24c>
  409a8e:	mov    rcx,rsi
  409a91:	mov    rdx,r15
  409a94:	call   411580 <__swc_fn_e121059d_000089_d182c4dc>
  409a99:	mov    rcx,rax
  409a9c:	test   cl,cl
  409a9e:	setne  al
  409aa1:	mov    BYTE PTR [rbx],al
  409aa3:	xor    eax,eax
  409aa5:	mov    r14b,al
  409aa8:	test   rdi,rdi
  409aab:	jne    409ac5 <__swc_fn_e121059d_000093_c2567a3b+0x275>
  409aad:	test   r14b,r14b
  409ab0:	jne    409ac5 <__swc_fn_e121059d_000093_c2567a3b+0x275>
  409ab2:	xor    eax,eax
  409ab4:	add    rsp,0x38
  409ab8:	pop    r15
  409aba:	pop    r14
  409abc:	pop    r13
  409abe:	pop    r12
  409ac0:	pop    rdi
  409ac1:	pop    rsi
  409ac2:	pop    rbx
  409ac3:	pop    rbp
  409ac4:	ret
  409ac5:	rex cmp BYTE PTR [rsi+0x2c],0x12
  409aca:	je     409ad6 <__swc_fn_e121059d_000093_c2567a3b+0x286>
  409acc:	mov    r12,QWORD PTR [rsp+0x18]
  409ad1:	jmp    409b5e <__swc_fn_e121059d_000093_c2567a3b+0x30e>
  409ad6:	mov    r12,QWORD PTR [rsp+0x18]
  409adb:	test   r12,r12
  409ade:	jne    409af2 <__swc_fn_e121059d_000093_c2567a3b+0x2a2>
  409ae0:	mov    rcx,r15
  409ae3:	mov    rdx,rsi
  409ae6:	xor    r8d,r8d
  409ae9:	call   40c660 <__swc_fn_e121059d_000094_63c1827b>
  409aee:	test   al,al
  409af0:	jne    409b5e <__swc_fn_e121059d_000093_c2567a3b+0x30e>
  409af2:	test   DWORD PTR [rsi+0x28],0x10000
  409af9:	je     409b17 <__swc_fn_e121059d_000093_c2567a3b+0x2c7>
  409afb:	rex mov al,BYTE PTR [rsp+0x8]
  409b00:	test   al,al
  409b02:	jne    409b17 <__swc_fn_e121059d_000093_c2567a3b+0x2c7>
  409b04:	xor    eax,eax
  409b06:	add    rsp,0x38
  409b0a:	pop    r15
  409b0c:	pop    r14
  409b0e:	pop    r13
  409b10:	pop    r12
  409b12:	pop    rdi
  409b13:	pop    rsi
  409b14:	pop    rbx
  409b15:	pop    rbp
  409b16:	ret
  409b17:	test   rdi,rdi
  409b1a:	jne    409b2f <__swc_fn_e121059d_000093_c2567a3b+0x2df>
  409b1c:	xor    eax,eax
  409b1e:	add    rsp,0x38
  409b22:	pop    r15
  409b24:	pop    r14
  409b26:	pop    r13
  409b28:	pop    r12
  409b2a:	pop    rdi
  409b2b:	pop    rsi
  409b2c:	pop    rbx
  409b2d:	pop    rbp
  409b2e:	ret
  409b2f:	cmp    QWORD PTR [rdi+0x8],0x0
  409b34:	jne    409b49 <__swc_fn_e121059d_000093_c2567a3b+0x2f9>
  409b36:	xor    eax,eax
  409b38:	add    rsp,0x38
  409b3c:	pop    r15
  409b3e:	pop    r14
  409b40:	pop    r13
  409b42:	pop    r12
  409b44:	pop    rdi
  409b45:	pop    rsi
  409b46:	pop    rbx
  409b47:	pop    rbp
  409b48:	ret
  409b49:	mov    rax,QWORD PTR [rdi+0x8]
  409b4d:	mov    rax,QWORD PTR [rax]
  409b50:	mov    rsi,rax
  409b53:	mov    rdi,QWORD PTR [rdi]
  409b56:	mov    eax,0x1
  409b5b:	mov    r14b,al
  409b5e:	test   rdi,rdi
  409b61:	mov    rbx,QWORD PTR [rsp+0x20]
  409b66:	jne    409bb0 <__swc_fn_e121059d_000093_c2567a3b+0x360>
  409b68:	test   r14b,r14b
  409b6b:	je     409b9d <__swc_fn_e121059d_000093_c2567a3b+0x34d>
  409b6d:	test   r12,r12
  409b70:	je     409b9d <__swc_fn_e121059d_000093_c2567a3b+0x34d>
  409b72:	mov    rcx,r15
  409b75:	mov    rdx,rsi
  409b78:	xor    r8d,r8d
  409b7b:	mov    r9,r12
  409b7e:	mov    rbx,QWORD PTR [rsp+0x20]
  409b83:	movzx  r10d,BYTE PTR [rbx]
  409b87:	call   409740 <__swc_fn_e121059d_000087_ef55f6e4>
  409b8c:	add    rsp,0x38
  409b90:	pop    r15
  409b92:	pop    r14
  409b94:	pop    r13
  409b96:	pop    r12
  409b98:	pop    rdi
  409b99:	pop    rsi
  409b9a:	pop    rbx
  409b9b:	pop    rbp
  409b9c:	ret
  409b9d:	xor    eax,eax
  409b9f:	add    rsp,0x38
  409ba3:	pop    r15
  409ba5:	pop    r14
  409ba7:	pop    r13
  409ba9:	pop    r12
  409bab:	pop    rdi
  409bac:	pop    rsi
  409bad:	pop    rbx
  409bae:	pop    rbp
  409baf:	ret
  409bb0:	mov    r13,rsi
  409bb3:	mov    QWORD PTR [rsp+0x28],rdi
  409bb8:	cmp    BYTE PTR [r15+0x2c],0xe
  409bbd:	sete   al
  409bc0:	mov    r14b,al
  409bc3:	jne    409bd7 <__swc_fn_e121059d_000093_c2567a3b+0x387>
  409bc5:	mov    rcx,rsi
  409bc8:	mov    rdx,r15
  409bcb:	call   411580 <__swc_fn_e121059d_000089_d182c4dc>
  409bd0:	mov    r14b,al
  409bd3:	test   al,al
  409bd5:	jne    409c0c <__swc_fn_e121059d_000093_c2567a3b+0x3bc>
  409bd7:	cmp    BYTE PTR [r15+0x2c],0x12
  409bdc:	je     409c0c <__swc_fn_e121059d_000093_c2567a3b+0x3bc>
  409bde:	mov    rcx,r15
  409be1:	mov    rdx,rsi
  409be4:	mov    r8,rdi
  409be7:	mov    r9,r12
  409bea:	mov    rax,rbx
  409bed:	movzx  r10d,BYTE PTR [rax]
  409bf1:	call   409740 <__swc_fn_e121059d_000087_ef55f6e4>
  409bf6:	test   rax,rax
  409bf9:	je     409c0c <__swc_fn_e121059d_000093_c2567a3b+0x3bc>
  409bfb:	add    rsp,0x38
  409bff:	pop    r15
  409c01:	pop    r14
  409c03:	pop    r13
  409c05:	pop    r12
  409c07:	pop    rdi
  409c08:	pop    rsi
  409c09:	pop    rbx
  409c0a:	pop    rbp
  409c0b:	ret
  409c0c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  409c11:	jne    409c30 <__swc_fn_e121059d_000093_c2567a3b+0x3e0>
  409c13:	mov    rax,QWORD PTR [rsi+0xd8]
  409c1a:	test   rax,rax
  409c1d:	je     409c30 <__swc_fn_e121059d_000093_c2567a3b+0x3e0>
  409c1f:	add    rdi,QWORD PTR [rax+0x8]
  409c23:	mov    rax,QWORD PTR [rdi]
  409c26:	sub    rdi,QWORD PTR [rax+0x8]
  409c2a:	mov    rax,QWORD PTR [rax]
  409c2d:	mov    rsi,rax
  409c30:	test   r14b,r14b
  409c33:	je     409c5f <__swc_fn_e121059d_000093_c2567a3b+0x40f>
  409c35:	mov    rcx,r15
  409c38:	mov    rdx,rsi
  409c3b:	mov    r8,rdi
  409c3e:	mov    r9,r13
  409c41:	mov    r14,QWORD PTR [rsp+0x28]
  409c46:	mov    r10,r14
  409c49:	call   40c540 <__swc_fn_e121059d_000091_c1c9085b>
  409c4e:	add    rsp,0x38
  409c52:	pop    r15
  409c54:	pop    r14
  409c56:	pop    r13
  409c58:	pop    r12
  409c5a:	pop    rdi
  409c5b:	pop    rsi
  409c5c:	pop    rbx
  409c5d:	pop    rbp
  409c5e:	ret
  409c5f:	mov    rcx,r15
  409c62:	mov    rdx,rsi
  409c65:	mov    r8,rdi
  409c68:	mov    r9,r12
  409c6b:	movzx  r10d,BYTE PTR [rbx]
  409c6f:	call   409740 <__swc_fn_e121059d_000087_ef55f6e4>
  409c74:	add    rsp,0x38
  409c78:	pop    r15
  409c7a:	pop    r14
  409c7c:	pop    r13
  409c7e:	pop    r12
  409c80:	pop    rdi
  409c81:	pop    rsi
  409c82:	pop    rbx
  409c83:	pop    rbp
  409c84:	ret
	...

0000000000409c90 <__swc_fn_e121059d_000096_93bfe675>:
  409c90:	push   rbx
  409c91:	push   rsi
  409c92:	sub    rsp,0x18
  409c96:	mov    rbx,rcx
  409c99:	mov    rcx,QWORD PTR [rip+0x1a3a0]        # 424040 <__swc_bss_base_e121059d>
  409ca0:	test   rcx,rcx
  409ca3:	jne    409cb5 <__swc_fn_e121059d_000096_93bfe675+0x25>
  409ca5:	call   412a40 <__swc_fn_e121059d_000170_994c8876>
  409caa:	lea    rcx,[rax+0x1]
  409cae:	mov    QWORD PTR [rip+0x1a38b],rcx        # 424040 <__swc_bss_base_e121059d>
  409cb5:	dec    rcx
  409cb8:	call   40f6e0 <__swc_fn_e121059d_000172_360af05d>
  409cbd:	mov    rsi,rax
  409cc0:	mov    rax,QWORD PTR [rsi+0x8]
  409cc4:	test   rax,rax
  409cc7:	jne    409d17 <__swc_fn_e121059d_000096_93bfe675+0x87>
  409cc9:	call   411670 <__swc_fn_e121059d_000095_ad13d15c>
  409cce:	test   al,al
  409cd0:	jne    409d17 <__swc_fn_e121059d_000096_93bfe675+0x87>
  409cd2:	lea    rdx,[rip+0x1a567]        # 424240 <__swc_bss_base_e121059d+0x200>
  409cd9:	mov    rcx,rdx
  409cdc:	call   40b810 <__swc_fn_e121059d_000040_eb6108f2>
  409ce1:	test   al,al
  409ce3:	jne    409cf4 <__swc_fn_e121059d_000096_93bfe675+0x64>
  409ce5:	mov    rcx,rdx
  409ce8:	call   40ff60 <__swc_fn_e121059d_000038_14f56618>
  409ced:	lea    rdx,[rip+0x1a54c]        # 424240 <__swc_bss_base_e121059d+0x200>
  409cf4:	mov    QWORD PTR [rsp+0x8],rdx
  409cf9:	lea    rax,[rip+0x9638]        # 413338 <__swc_rdata_base_e121059d+0x228>
  409d00:	mov    QWORD PTR [rsp+0x10],rax
  409d05:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409d0b:	vmovups XMMWORD PTR [rsi],xmm0
  409d0f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  409d17:	vmovups xmm0,XMMWORD PTR [rsi]
  409d1b:	vmovups XMMWORD PTR [rbx],xmm0
  409d1f:	mov    rax,rbx
  409d22:	add    rsp,0x18
  409d26:	pop    rsi
  409d27:	pop    rbx
  409d28:	ret
  409d29:	add    BYTE PTR [rax],al
  409d2b:	add    BYTE PTR [rax],al
  409d2d:	add    BYTE PTR [rax],al
	...

0000000000409d30 <__swc_fn_e121059d_000099_65137b72>:
  409d30:	sub    rsp,0x8
  409d34:	call   411be0 <__swc_fn_e121059d_000122_0a5fa85a>
  409d39:	add    rsp,0x8
  409d3d:	ret
	...

0000000000409d40 <__swc_fn_e121059d_000102_e34f54dc>:
  409d40:	push   rbx
  409d41:	push   rsi
  409d42:	sub    rsp,0x28
  409d46:	mov    rbx,rcx
  409d49:	xor    esi,esi
  409d4b:	jmp    409d60 <__swc_fn_e121059d_000102_e34f54dc+0x20>
  409d4d:	nop    DWORD PTR [rax]
  409d50:	mov    QWORD PTR [rbx+0x28],rsi
  409d54:	mov    rsi,rbx
  409d57:	mov    rbx,rax
  409d5a:	nop    WORD PTR [rax+rax*1+0x0]
  409d60:	test   rbx,rbx
  409d63:	je     409dc3 <__swc_fn_e121059d_000102_e34f54dc+0x83>
  409d65:	mov    rcx,rbx
  409d68:	mov    edx,0x1
  409d6d:	call   40c2c0 <__swc_fn_e121059d_000082_63a67586>
  409d72:	cmp    rax,0x1
  409d76:	jne    409dc3 <__swc_fn_e121059d_000102_e34f54dc+0x83>
  409d78:	mov    r10,QWORD PTR [rbx+0x18]
  409d7c:	mov    rcx,r10
  409d7f:	mov    edx,0x1
  409d84:	call   40c2c0 <__swc_fn_e121059d_000082_63a67586>
  409d89:	cmp    rax,0x1
  409d8d:	jne    409d9c <__swc_fn_e121059d_000102_e34f54dc+0x5c>
  409d8f:	mov    rcx,r10
  409d92:	call   411810 <__swc_fn_e121059d_000101_d0b19c14>
  409d97:	test   rax,rax
  409d9a:	jne    409d50 <__swc_fn_e121059d_000102_e34f54dc+0x10>
  409d9c:	mov    rax,QWORD PTR [rbx+0x20]
  409da0:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  409da5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409dab:	lea    rcx,[rsp+0x8]
  409db0:	mov    rdx,rbx
  409db3:	mov    r8d,0x30
  409db9:	mov    rbx,rax
  409dbc:	call   40ca20 <__swc_fn_e121059d_000100_d4bdcaa4>
  409dc1:	jmp    409d60 <__swc_fn_e121059d_000102_e34f54dc+0x20>
  409dc3:	test   rsi,rsi
  409dc6:	jne    409dcf <__swc_fn_e121059d_000102_e34f54dc+0x8f>
  409dc8:	add    rsp,0x28
  409dcc:	pop    rsi
  409dcd:	pop    rbx
  409dce:	ret
  409dcf:	mov    rax,rsi
  409dd2:	mov    rsi,QWORD PTR [rsi+0x28]
  409dd6:	mov    rbx,QWORD PTR [rax+0x20]
  409dda:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  409ddf:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409de5:	lea    rcx,[rsp+0x18]
  409dea:	mov    rdx,rax
  409ded:	mov    r8d,0x30
  409df3:	call   40ca20 <__swc_fn_e121059d_000100_d4bdcaa4>
  409df8:	jmp    409d60 <__swc_fn_e121059d_000102_e34f54dc+0x20>
  409dfd:	add    BYTE PTR [rax],al
	...

0000000000409e00 <__swc_fn_e121059d_000105_5a85fcf5>:
  409e00:	push   rbx
  409e01:	push   rsi
  409e02:	push   rdi
  409e03:	push   r12
  409e05:	push   r13
  409e07:	sub    rsp,0x20
  409e0b:	mov    rbx,rcx
  409e0e:	lea    rsi,[rcx+0x6f8]
  409e15:	mov    edi,0x4
  409e1a:	mov    r12,rsi
  409e1d:	test   rdi,rdi
  409e20:	je     409e6a <__swc_fn_e121059d_000105_5a85fcf5+0x6a>
  409e22:	cs nop WORD PTR [rax+rax*1+0x0]
  409e2c:	nop    DWORD PTR [rax+0x0]
  409e30:	mov    rcx,QWORD PTR [r12+0x10]
  409e35:	mov    QWORD PTR [r12+0x10],0x0
  409e3e:	vxorps xmm0,xmm0,xmm0
  409e42:	vmovups XMMWORD PTR [r12],xmm0
  409e48:	vmovups XMMWORD PTR [r12+0x28],xmm0
  409e4f:	mov    DWORD PTR [r12+0x20],0x0
  409e58:	call   40ca70 <__swc_fn_e121059d_000103_2fdd2c61>
  409e5d:	add    r12,0x90
  409e64:	sub    rdi,0x1
  409e68:	jne    409e30 <__swc_fn_e121059d_000105_5a85fcf5+0x30>
  409e6a:	mov    rax,QWORD PTR [rbx+0x938]
  409e71:	mov    rdi,rax
  409e74:	test   rdi,rdi
  409e77:	je     409ed1 <__swc_fn_e121059d_000105_5a85fcf5+0xd1>
  409e79:	nop    DWORD PTR [rax+0x0]
  409e80:	mov    r12d,0x10
  409e86:	lea    r13,[rdi+0x18]
  409e8a:	test   r12,r12
  409e8d:	je     409ec6 <__swc_fn_e121059d_000105_5a85fcf5+0xc6>
  409e8f:	nop
  409e90:	mov    rcx,QWORD PTR [r13+0x10]
  409e94:	mov    QWORD PTR [r13+0x10],0x0
  409e9c:	vxorps xmm0,xmm0,xmm0
  409ea0:	vmovups XMMWORD PTR [r13+0x0],xmm0
  409ea6:	vmovups XMMWORD PTR [r13+0x28],xmm0
  409eac:	mov    DWORD PTR [r13+0x20],0x0
  409eb4:	call   40ca70 <__swc_fn_e121059d_000103_2fdd2c61>
  409eb9:	add    r13,0x90
  409ec0:	sub    r12,0x1
  409ec4:	jne    409e90 <__swc_fn_e121059d_000105_5a85fcf5+0x90>
  409ec6:	mov    rax,QWORD PTR [rdi]
  409ec9:	mov    rdi,rax
  409ecc:	test   rax,rax
  409ecf:	jne    409e80 <__swc_fn_e121059d_000105_5a85fcf5+0x80>
  409ed1:	vxorps xmm0,xmm0,xmm0
  409ed5:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  409edd:	mov    DWORD PTR [rbx+0x9b0],0x0
  409ee7:	mov    DWORD PTR [rbx+0x9a8],0x0
  409ef1:	mov    edi,0x4
  409ef6:	mov    r12,rsi
  409ef9:	lea    rsi,[rsi+0x38]
  409efd:	test   rdi,rdi
  409f00:	je     409f2c <__swc_fn_e121059d_000105_5a85fcf5+0x12c>
  409f02:	cs nop WORD PTR [rax+rax*1+0x0]
  409f0c:	nop    DWORD PTR [rax+0x0]
  409f10:	mov    rcx,rsi
  409f13:	call   40add0 <__swc_fn_e121059d_000162_13ead2ff>
  409f18:	add    rsi,0x90
  409f1f:	add    r12,0x90
  409f26:	sub    rdi,0x1
  409f2a:	jne    409f10 <__swc_fn_e121059d_000105_5a85fcf5+0x110>
  409f2c:	mov    rax,QWORD PTR [rbx+0x938]
  409f33:	mov    rdi,rax
  409f36:	mov    QWORD PTR [rbx+0x938],0x0
  409f41:	test   rdi,rdi
  409f44:	je     409fb5 <__swc_fn_e121059d_000105_5a85fcf5+0x1b5>
  409f4a:	nop    WORD PTR [rax+rax*1+0x0]
  409f50:	mov    esi,0x10
  409f55:	lea    r12,[rdi+0x18]
  409f59:	lea    r13,[rdi+0x50]
  409f5d:	test   rsi,rsi
  409f60:	je     409f8c <__swc_fn_e121059d_000105_5a85fcf5+0x18c>
  409f62:	cs nop WORD PTR [rax+rax*1+0x0]
  409f6c:	nop    DWORD PTR [rax+0x0]
  409f70:	mov    rcx,r13
  409f73:	call   40add0 <__swc_fn_e121059d_000162_13ead2ff>
  409f78:	add    r13,0x90
  409f7f:	add    r12,0x90
  409f86:	sub    rsi,0x1
  409f8a:	jne    409f70 <__swc_fn_e121059d_000105_5a85fcf5+0x170>
  409f8c:	mov    rax,QWORD PTR [rdi]
  409f8f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  409f94:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409f9a:	lea    rcx,[rsp+0x8]
  409f9f:	mov    rdx,rdi
  409fa2:	mov    r8d,0x918
  409fa8:	mov    rdi,rax
  409fab:	call   40ca20 <__swc_fn_e121059d_000100_d4bdcaa4>
  409fb0:	test   rdi,rdi
  409fb3:	jne    409f50 <__swc_fn_e121059d_000105_5a85fcf5+0x150>
  409fb5:	lea    rcx,[rbx+0x68]
  409fb9:	call   40add0 <__swc_fn_e121059d_000162_13ead2ff>
  409fbe:	add    rsp,0x20
  409fc2:	pop    r13
  409fc4:	pop    r12
  409fc6:	pop    rdi
  409fc7:	pop    rsi
  409fc8:	pop    rbx
  409fc9:	ret
  409fca:	add    BYTE PTR [rax],al
  409fcc:	add    BYTE PTR [rax],al
	...

0000000000409fd0 <__swc_fn_e121059d_000108_c51c3158>:
  409fd0:	xor    eax,eax
  409fd2:	cs nop WORD PTR [rax+rax*1+0x0]
  409fdc:	nop    DWORD PTR [rax+0x0]
  409fe0:	mov    r9,r8
  409fe3:	sub    r9,rax
  409fe6:	cmp    r9,0x40
  409fea:	jb     40a028 <__swc_fn_e121059d_000108_c51c3158+0x58>
  409fec:	lea    r9,[rcx+rax*1]
  409ff0:	lea    r10,[rdx+rax*1]
  409ff4:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  409ffa:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40a000:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40a006:	vmovups xmm3,XMMWORD PTR [r10]
  40a00b:	vmovups XMMWORD PTR [r9],xmm3
  40a010:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40a016:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40a01c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40a022:	lea    rax,[rax+0x40]
  40a026:	jmp    409fe0 <__swc_fn_e121059d_000108_c51c3158+0x10>
  40a028:	nop    DWORD PTR [rax+rax*1+0x0]
  40a030:	mov    r9,r8
  40a033:	sub    r9,rax
  40a036:	cmp    r9,0x10
  40a03a:	jb     40a054 <__swc_fn_e121059d_000108_c51c3158+0x84>
  40a03c:	lea    r9,[rdx+rax*1]
  40a040:	lea    r10,[rcx+rax*1]
  40a044:	vmovups xmm0,XMMWORD PTR [r9]
  40a049:	vmovups XMMWORD PTR [r10],xmm0
  40a04e:	lea    rax,[rax+0x10]
  40a052:	jmp    40a030 <__swc_fn_e121059d_000108_c51c3158+0x60>
  40a054:	cs nop WORD PTR [rax+rax*1+0x0]
  40a05e:	xchg   ax,ax
  40a060:	mov    r9,r8
  40a063:	sub    r9,rax
  40a066:	cmp    r9,0x8
  40a06a:	jb     40a07d <__swc_fn_e121059d_000108_c51c3158+0xad>
  40a06c:	lea    r9,[rcx+rax*1]
  40a070:	mov    r10,QWORD PTR [rdx+rax*1]
  40a074:	mov    QWORD PTR [r9],r10
  40a077:	lea    rax,[rax+0x8]
  40a07b:	jmp    40a060 <__swc_fn_e121059d_000108_c51c3158+0x90>
  40a07d:	cmp    rax,r8
  40a080:	jae    40a0a0 <__swc_fn_e121059d_000108_c51c3158+0xd0>
  40a082:	cs nop WORD PTR [rax+rax*1+0x0]
  40a08c:	nop    DWORD PTR [rax+0x0]
  40a090:	mov    r9b,BYTE PTR [rdx+rax*1]
  40a094:	mov    BYTE PTR [rcx+rax*1],r9b
  40a098:	inc    rax
  40a09b:	cmp    rax,r8
  40a09e:	jb     40a090 <__swc_fn_e121059d_000108_c51c3158+0xc0>
  40a0a0:	ret
	...

000000000040a0b0 <__swc_fn_e121059d_000111_3dc01326>:
  40a0b0:	test   r8,r8
  40a0b3:	jne    40a0b8 <__swc_fn_e121059d_000111_3dc01326+0x8>
  40a0b5:	xor    eax,eax
  40a0b7:	ret
  40a0b8:	xor    eax,eax
  40a0ba:	nop    WORD PTR [rax+rax*1+0x0]
  40a0c0:	mov    r9,r8
  40a0c3:	sub    r9,rax
  40a0c6:	cmp    r9,0x10
  40a0ca:	jb     40a114 <__swc_fn_e121059d_000111_3dc01326+0x64>
  40a0cc:	lea    r9,[rcx+rax*1]
  40a0d0:	lea    r10,[rdx+rax*1]
  40a0d4:	vmovups xmm0,XMMWORD PTR [r10]
  40a0d9:	vmovups xmm1,XMMWORD PTR [r9]
  40a0de:	vpcmpeqb xmm0,xmm1,xmm0
  40a0e2:	vpmovmskb r9d,xmm0
  40a0e6:	cmp    r9d,0xffff
  40a0ed:	je     40a10e <__swc_fn_e121059d_000111_3dc01326+0x5e>
  40a0ef:	not    r9d
  40a0f2:	xor    r8d,r8d
  40a0f5:	movzx  r9d,r9w
  40a0f9:	tzcnt  r8d,r9d
  40a0fe:	add    rax,r8
  40a101:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40a105:	movzx  eax,BYTE PTR [rdx+rax*1]
  40a109:	sub    ecx,eax
  40a10b:	mov    eax,ecx
  40a10d:	ret
  40a10e:	lea    rax,[rax+0x10]
  40a112:	jmp    40a0c0 <__swc_fn_e121059d_000111_3dc01326+0x10>
  40a114:	cmp    r9,0x8
  40a118:	jb     40a18b <__swc_fn_e121059d_000111_3dc01326+0xdb>
  40a11a:	lea    r9,[rcx+rax*1]
  40a11e:	lea    r10,[rdx+rax*1]
  40a122:	mov    r9,QWORD PTR [r9]
  40a125:	xor    r9,QWORD PTR [r10]
  40a128:	test   r9,r9
  40a12b:	je     40a149 <__swc_fn_e121059d_000111_3dc01326+0x99>
  40a12d:	xor    r8d,r8d
  40a130:	tzcnt  r8,r9
  40a135:	shr    r8,0x3
  40a139:	add    rax,r8
  40a13c:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40a140:	movzx  eax,BYTE PTR [rdx+rax*1]
  40a144:	sub    ecx,eax
  40a146:	mov    eax,ecx
  40a148:	ret
  40a149:	lea    rax,[rax+0x8]
  40a14d:	cmp    rax,r8
  40a150:	jne    40a155 <__swc_fn_e121059d_000111_3dc01326+0xa5>
  40a152:	xor    eax,eax
  40a154:	ret
  40a155:	lea    rax,[r8-0x8]
  40a159:	lea    r8,[rcx+rax*1]
  40a15d:	lea    r9,[rdx+rax*1]
  40a161:	mov    r8,QWORD PTR [r8]
  40a164:	xor    r8,QWORD PTR [r9]
  40a167:	test   r8,r8
  40a16a:	je     40a188 <__swc_fn_e121059d_000111_3dc01326+0xd8>
  40a16c:	xor    r9d,r9d
  40a16f:	tzcnt  r9,r8
  40a174:	shr    r9,0x3
  40a178:	add    rax,r9
  40a17b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40a17f:	movzx  eax,BYTE PTR [rdx+rax*1]
  40a183:	sub    ecx,eax
  40a185:	mov    eax,ecx
  40a187:	ret
  40a188:	xor    eax,eax
  40a18a:	ret
  40a18b:	cmp    r9,0x4
  40a18f:	jb     40a202 <__swc_fn_e121059d_000111_3dc01326+0x152>
  40a191:	lea    r9,[rcx+rax*1]
  40a195:	lea    r10,[rdx+rax*1]
  40a199:	mov    r9d,DWORD PTR [r9]
  40a19c:	xor    r9d,DWORD PTR [r10]
  40a19f:	test   r9d,r9d
  40a1a2:	je     40a1c0 <__swc_fn_e121059d_000111_3dc01326+0x110>
  40a1a4:	xor    r8d,r8d
  40a1a7:	tzcnt  r8,r9
  40a1ac:	shr    r8,0x3
  40a1b0:	add    rax,r8
  40a1b3:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40a1b7:	movzx  eax,BYTE PTR [rdx+rax*1]
  40a1bb:	sub    ecx,eax
  40a1bd:	mov    eax,ecx
  40a1bf:	ret
  40a1c0:	lea    rax,[rax+0x4]
  40a1c4:	cmp    rax,r8
  40a1c7:	jne    40a1cc <__swc_fn_e121059d_000111_3dc01326+0x11c>
  40a1c9:	xor    eax,eax
  40a1cb:	ret
  40a1cc:	lea    rax,[r8-0x4]
  40a1d0:	lea    r8,[rcx+rax*1]
  40a1d4:	lea    r9,[rdx+rax*1]
  40a1d8:	mov    r8d,DWORD PTR [r8]
  40a1db:	xor    r8d,DWORD PTR [r9]
  40a1de:	test   r8d,r8d
  40a1e1:	je     40a1ff <__swc_fn_e121059d_000111_3dc01326+0x14f>
  40a1e3:	xor    r9d,r9d
  40a1e6:	tzcnt  r9,r8
  40a1eb:	shr    r9,0x3
  40a1ef:	add    rax,r9
  40a1f2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40a1f6:	movzx  eax,BYTE PTR [rdx+rax*1]
  40a1fa:	sub    ecx,eax
  40a1fc:	mov    eax,ecx
  40a1fe:	ret
  40a1ff:	xor    eax,eax
  40a201:	ret
  40a202:	cmp    r9,0x2
  40a206:	jb     40a259 <__swc_fn_e121059d_000111_3dc01326+0x1a9>
  40a208:	lea    r9,[rcx+rax*1]
  40a20c:	lea    r10,[rdx+rax*1]
  40a210:	mov    r9w,WORD PTR [r9]
  40a214:	xor    r9w,WORD PTR [r10]
  40a218:	test   r9w,r9w
  40a21c:	je     40a23e <__swc_fn_e121059d_000111_3dc01326+0x18e>
  40a21e:	xor    r8d,r8d
  40a221:	movzx  r9d,r9w
  40a225:	tzcnt  r8,r9
  40a22a:	shr    r8,0x3
  40a22e:	add    rax,r8
  40a231:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40a235:	movzx  eax,BYTE PTR [rdx+rax*1]
  40a239:	sub    ecx,eax
  40a23b:	mov    eax,ecx
  40a23d:	ret
  40a23e:	lea    rax,[rax+0x2]
  40a242:	cmp    rax,r8
  40a245:	jne    40a24a <__swc_fn_e121059d_000111_3dc01326+0x19a>
  40a247:	xor    eax,eax
  40a249:	ret
  40a24a:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40a250:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40a256:	sub    eax,ecx
  40a258:	ret
  40a259:	test   r9,r9
  40a25c:	je     40a26b <__swc_fn_e121059d_000111_3dc01326+0x1bb>
  40a25e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40a262:	movzx  eax,BYTE PTR [rdx+rax*1]
  40a266:	sub    ecx,eax
  40a268:	mov    eax,ecx
  40a26a:	ret
  40a26b:	xor    eax,eax
  40a26d:	ret
	...

000000000040a270 <__swc_fn_e121059d_000114_6b799b8d>:
  40a270:	push   r12
  40a272:	push   r13
  40a274:	push   r14
  40a276:	push   rdi
  40a277:	push   rsi
  40a278:	push   r15
  40a27a:	sub    rsp,0xd8
  40a281:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40a287:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40a28d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40a293:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40a299:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40a29f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40a2a8:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40a2b1:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40a2ba:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40a2c3:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40a2cc:	mov    r12,rcx
  40a2cf:	test   rcx,rcx
  40a2d2:	je     40a2ee <__swc_fn_e121059d_000114_6b799b8d+0x7e>
  40a2d4:	mov    eax,r12d
  40a2d7:	and    eax,0xfff
  40a2dd:	setne  al
  40a2e0:	cmp    r12,0xffffffffffffefff
  40a2e7:	seta   cl
  40a2ea:	or     al,cl
  40a2ec:	je     40a2f5 <__swc_fn_e121059d_000114_6b799b8d+0x85>
  40a2ee:	xor    eax,eax
  40a2f0:	jmp    40a38b <__swc_fn_e121059d_000114_6b799b8d+0x11b>
  40a2f5:	call   4119a0 <__swc_fn_e121059d_000113_126150d1>
  40a2fa:	mov    r13,rax
  40a2fd:	test   rax,rax
  40a300:	jne    40a309 <__swc_fn_e121059d_000114_6b799b8d+0x99>
  40a302:	xor    eax,eax
  40a304:	jmp    40a38b <__swc_fn_e121059d_000114_6b799b8d+0x11b>
  40a309:	lea    r14,[r12+0x1000]
  40a311:	xor    edi,edi
  40a313:	mov    rsi,r14
  40a316:	xor    edx,edx
  40a318:	mov    ecx,0x22
  40a31d:	mov    eax,0xffffffff
  40a322:	movsxd r8,eax
  40a325:	xor    r9d,r9d
  40a328:	xor    eax,eax
  40a32a:	call   407010 <mmap@plt>
  40a32f:	mov    r15,rax
  40a332:	cmp    rax,0xffffffffffffffff
  40a336:	jne    40a33c <__swc_fn_e121059d_000114_6b799b8d+0xcc>
  40a338:	xor    eax,eax
  40a33a:	jmp    40a38b <__swc_fn_e121059d_000114_6b799b8d+0x11b>
  40a33c:	mov    rdi,r15
  40a33f:	mov    esi,0x1000
  40a344:	mov    edx,0x3
  40a349:	xor    eax,eax
  40a34b:	call   407020 <mprotect@plt>
  40a350:	test   eax,eax
  40a352:	je     40a365 <__swc_fn_e121059d_000114_6b799b8d+0xf5>
  40a354:	mov    rdi,r15
  40a357:	mov    rsi,r14
  40a35a:	xor    eax,eax
  40a35c:	call   407030 <munmap@plt>
  40a361:	xor    eax,eax
  40a363:	jmp    40a38b <__swc_fn_e121059d_000114_6b799b8d+0x11b>
  40a365:	mov    QWORD PTR [r15+0x8],r12
  40a369:	mov    rcx,r13
  40a36c:	call   40a9d0 <__swc_fn_e121059d_000138_8c07c14b>
  40a371:	mov    rax,QWORD PTR [r13+0x8]
  40a375:	mov    QWORD PTR [r15],rax
  40a378:	mov    QWORD PTR [r13+0x8],r15
  40a37c:	mov    rcx,r13
  40a37f:	call   40dde0 <__swc_fn_e121059d_000139_715e84ff>
  40a384:	lea    rax,[r15+0x1000]
  40a38b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40a391:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40a397:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40a39d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40a3a3:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40a3a9:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40a3b2:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40a3bb:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40a3c4:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40a3cd:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40a3d6:	add    rsp,0xd8
  40a3dd:	pop    r15
  40a3df:	pop    rsi
  40a3e0:	pop    rdi
  40a3e1:	pop    r14
  40a3e3:	pop    r13
  40a3e5:	pop    r12
  40a3e7:	ret
	...

000000000040a3f0 <__swc_fn_e121059d_000117_e9fc0224>:
  40a3f0:	push   rbx
  40a3f1:	push   r12
  40a3f3:	push   rdi
  40a3f4:	push   rsi
  40a3f5:	sub    rsp,0xa8
  40a3fc:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40a402:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40a408:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40a40e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40a414:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40a41a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40a420:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40a426:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40a42c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a435:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a43e:	mov    rbx,rdx
  40a441:	mov    r12,rcx
  40a444:	mov    rdi,rcx
  40a447:	mov    rsi,rdx
  40a44a:	xor    edx,edx
  40a44c:	xor    eax,eax
  40a44e:	call   407020 <mprotect@plt>
  40a453:	test   eax,eax
  40a455:	jne    40a479 <__swc_fn_e121059d_000117_e9fc0224+0x89>
  40a457:	mov    rcx,r12
  40a45a:	mov    rdx,rbx
  40a45d:	xor    al,al
  40a45f:	mov    r8,rax
  40a462:	call   40d880 <__swc_fn_e121059d_000115_5f48311c>
  40a467:	mov    rdi,r12
  40a46a:	mov    rsi,rbx
  40a46d:	mov    edx,0x4
  40a472:	xor    eax,eax
  40a474:	call   407040 <madvise@plt>
  40a479:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a47f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a485:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a48b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a491:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a497:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a49d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a4a3:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a4a9:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a4b2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a4bb:	add    rsp,0xa8
  40a4c2:	pop    rsi
  40a4c3:	pop    rdi
  40a4c4:	pop    r12
  40a4c6:	pop    rbx
  40a4c7:	ret
	...

000000000040a4d0 <__swc_fn_e121059d_000120_d3318640>:
  40a4d0:	push   rsi
  40a4d1:	push   rdi
  40a4d2:	push   r12
  40a4d4:	push   r13
  40a4d6:	push   r14
  40a4d8:	sub    rsp,0xe0
  40a4df:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40a4e5:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40a4eb:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40a4f1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40a4f7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40a4fd:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40a506:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40a50f:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40a518:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40a521:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40a52a:	mov    rsi,rdx
  40a52d:	mov    rdi,rcx
  40a530:	call   4119a0 <__swc_fn_e121059d_000113_126150d1>
  40a535:	mov    r12,rax
  40a538:	test   rax,rax
  40a53b:	jne    40a542 <__swc_fn_e121059d_000120_d3318640+0x72>
  40a53d:	jmp    40a5b6 <__swc_fn_e121059d_000120_d3318640+0xe6>
  40a542:	mov    rcx,r12
  40a545:	call   40a9d0 <__swc_fn_e121059d_000138_8c07c14b>
  40a54a:	lea    r13,[r12+0x8]
  40a54f:	mov    rax,QWORD PTR [r13+0x0]
  40a553:	test   rax,rax
  40a556:	je     40a5ae <__swc_fn_e121059d_000120_d3318640+0xde>
  40a558:	nop    DWORD PTR [rax+rax*1+0x0]
  40a560:	lea    rcx,[rax+0x1000]
  40a567:	cmp    rcx,rdi
  40a56a:	jne    40a5a2 <__swc_fn_e121059d_000120_d3318640+0xd2>
  40a56c:	cmp    QWORD PTR [rax+0x8],rsi
  40a570:	je     40a57c <__swc_fn_e121059d_000120_d3318640+0xac>
  40a572:	mov    rcx,r12
  40a575:	call   40dde0 <__swc_fn_e121059d_000139_715e84ff>
  40a57a:	jmp    40a5b6 <__swc_fn_e121059d_000120_d3318640+0xe6>
  40a57c:	mov    r14,QWORD PTR [rax]
  40a57f:	mov    rdi,rax
  40a582:	lea    rsi,[rsi+0x1000]
  40a589:	xor    eax,eax
  40a58b:	call   407030 <munmap@plt>
  40a590:	test   eax,eax
  40a592:	jne    40a598 <__swc_fn_e121059d_000120_d3318640+0xc8>
  40a594:	mov    QWORD PTR [r13+0x0],r14
  40a598:	mov    rcx,r12
  40a59b:	call   40dde0 <__swc_fn_e121059d_000139_715e84ff>
  40a5a0:	jmp    40a5b6 <__swc_fn_e121059d_000120_d3318640+0xe6>
  40a5a2:	mov    r13,rax
  40a5a5:	mov    rax,QWORD PTR [r13+0x0]
  40a5a9:	test   rax,rax
  40a5ac:	jne    40a560 <__swc_fn_e121059d_000120_d3318640+0x90>
  40a5ae:	mov    rcx,r12
  40a5b1:	call   40dde0 <__swc_fn_e121059d_000139_715e84ff>
  40a5b6:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40a5bc:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40a5c2:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40a5c8:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40a5ce:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40a5d4:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40a5dd:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40a5e6:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40a5ef:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40a5f8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40a601:	add    rsp,0xe0
  40a608:	pop    r14
  40a60a:	pop    r13
  40a60c:	pop    r12
  40a60e:	pop    rdi
  40a60f:	pop    rsi
  40a610:	ret
	...

000000000040a620 <__swc_fn_e121059d_000123_be2e2f68>:
  40a620:	push   rdi
  40a621:	push   rsi
  40a622:	sub    rsp,0xa8
  40a629:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40a62f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40a635:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40a63b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40a641:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40a647:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40a64d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40a653:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40a659:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a662:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a66b:	mov    rdi,0xfffffffffffffd66
  40a672:	xor    eax,eax
  40a674:	call   407050 <exit@plt>
  40a679:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a67f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a685:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a68b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a691:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a697:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a69d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a6a3:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a6a9:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a6b2:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a6bb:	add    rsp,0xa8
  40a6c2:	pop    rsi
  40a6c3:	pop    rdi
  40a6c4:	ret
	...

000000000040a6e0 <__swc_fn_e121059d_000126_540bf7e8>:
  40a6e0:	push   rbx
  40a6e1:	push   rsi
  40a6e2:	push   rdi
  40a6e3:	sub    rsp,0x30
  40a6e7:	mov    rbx,rdx
  40a6ea:	mov    esi,ecx
  40a6ec:	test   ecx,ecx
  40a6ee:	je     40a7c3 <__swc_fn_e121059d_000126_540bf7e8+0xe3>
  40a6f4:	mov    rcx,rsi
  40a6f7:	shl    rcx,0x4
  40a6fb:	call   4114b0 <__swc_fn_e121059d_000083_4a10c7e7>
  40a700:	test   rax,rax
  40a703:	je     40a7b2 <__swc_fn_e121059d_000126_540bf7e8+0xd2>
  40a709:	mov    rcx,rsi
  40a70c:	xor    edx,edx
  40a70e:	test   rsi,rsi
  40a711:	jbe    40a792 <__swc_fn_e121059d_000126_540bf7e8+0xb2>
  40a717:	nop    WORD PTR [rax+rax*1+0x0]
  40a720:	mov    r8d,edx
  40a723:	mov    r9,QWORD PTR [rbx+r8*8]
  40a727:	add    r8,r8
  40a72a:	lea    r8,[rax+r8*8]
  40a72e:	xor    r10d,r10d
  40a731:	test   r9,r9
  40a734:	je     40a770 <__swc_fn_e121059d_000126_540bf7e8+0x90>
  40a736:	mov    r11,r9
  40a739:	mov    dil,BYTE PTR [r11]
  40a73c:	test   dil,dil
  40a73f:	je     40a770 <__swc_fn_e121059d_000126_540bf7e8+0x90>
  40a741:	cs nop WORD PTR [rax+rax*1+0x0]
  40a74b:	cs nop WORD PTR [rax+rax*1+0x0]
  40a755:	cs nop WORD PTR [rax+rax*1+0x0]
  40a75f:	nop
  40a760:	add    r11,0x1
  40a764:	add    r10,0x1
  40a768:	mov    dil,BYTE PTR [r11]
  40a76b:	test   dil,dil
  40a76e:	jne    40a760 <__swc_fn_e121059d_000126_540bf7e8+0x80>
  40a770:	mov    QWORD PTR [rsp+0x18],r9
  40a775:	mov    QWORD PTR [rsp+0x20],r10
  40a77a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a780:	vmovups XMMWORD PTR [r8],xmm0
  40a785:	add    rdx,0x1
  40a789:	cmp    rdx,rcx
  40a78c:	jb     40a720 <__swc_fn_e121059d_000126_540bf7e8+0x40>
  40a792:	lea    rcx,[rip+0x1c5af]        # 426d48 <__swc_bss_base_e121059d+0x2d08>
  40a799:	mov    QWORD PTR [rsp+0x8],rax
  40a79e:	mov    esi,esi
  40a7a0:	mov    QWORD PTR [rsp+0x10],rsi
  40a7a5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a7ab:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a7b0:	jmp    40a7c3 <__swc_fn_e121059d_000126_540bf7e8+0xe3>
  40a7b2:	lea    rcx,[rip+0x8ef7]        # 4136b0 <__swc_rdata_base_e121059d+0x5a0>
  40a7b9:	call   40d930 <__swc_fn_e121059d_000121_2648f149>
  40a7be:	call   40a620 <__swc_fn_e121059d_000123_be2e2f68>
  40a7c3:	add    rsp,0x30
  40a7c7:	pop    rdi
  40a7c8:	pop    rsi
  40a7c9:	pop    rbx
  40a7ca:	ret
  40a7cb:	add    BYTE PTR [rax],al
  40a7cd:	add    BYTE PTR [rax],al
	...

000000000040a7d0 <__swc_fn_e121059d_000129_a481cb88>:
  40a7d0:	push   rdi
  40a7d1:	push   rsi
  40a7d2:	sub    rsp,0xa8
  40a7d9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40a7df:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40a7e5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40a7eb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40a7f1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40a7f7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40a7fd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40a803:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40a809:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a812:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a81b:	mov    edi,ecx
  40a81d:	xor    eax,eax
  40a81f:	call   407060 <pthread_key_delete@plt>
  40a824:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a82a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a830:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a836:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a83c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a842:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a848:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a84e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a854:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a85d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a866:	add    rsp,0xa8
  40a86d:	pop    rsi
  40a86e:	pop    rdi
  40a86f:	ret

000000000040a870 <__swc_fn_e121059d_000132_a611b8c4>:
  40a870:	push   rdi
  40a871:	push   rsi
  40a872:	sub    rsp,0xa8
  40a879:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40a87f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40a885:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40a88b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40a891:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40a897:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40a89d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40a8a3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40a8a9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a8b2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a8bb:	test   rcx,rcx
  40a8be:	je     40a8cf <__swc_fn_e121059d_000132_a611b8c4+0x5f>
  40a8c0:	lea    rax,[rcx-0x1]
  40a8c4:	mov    eax,eax
  40a8c6:	mov    edi,eax
  40a8c8:	xor    eax,eax
  40a8ca:	call   407060 <pthread_key_delete@plt>
  40a8cf:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a8d5:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a8db:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a8e1:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a8e7:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a8ed:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a8f3:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a8f9:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a8ff:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a908:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a911:	add    rsp,0xa8
  40a918:	pop    rsi
  40a919:	pop    rdi
  40a91a:	ret
  40a91b:	add    BYTE PTR [rax],al
  40a91d:	add    BYTE PTR [rax],al
	...

000000000040a920 <__swc_fn_e121059d_000135_a9c1c700>:
  40a920:	push   rsi
  40a921:	push   rdi
  40a922:	sub    rsp,0xa8
  40a929:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40a92f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40a935:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40a93b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40a941:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40a947:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40a94d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40a953:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40a959:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a962:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a96b:	xor    eax,eax
  40a96d:	call   407070 <gettid@plt>
  40a972:	movsxd rax,eax
  40a975:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a97b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a981:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a987:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a98d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a993:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a999:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a99f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a9a5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a9ae:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a9b7:	add    rsp,0xa8
  40a9be:	pop    rdi
  40a9bf:	pop    rsi
  40a9c0:	ret
	...

000000000040a9d0 <__swc_fn_e121059d_000138_8c07c14b>:
  40a9d0:	push   rbx
  40a9d1:	push   rdi
  40a9d2:	push   rsi
  40a9d3:	sub    rsp,0xc0
  40a9da:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40a9e0:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40a9e6:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40a9ec:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40a9f2:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40a9f8:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40a9fe:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40aa04:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40aa0d:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40aa16:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40aa1f:	mov    rbx,rcx
  40aa22:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa2c:	nop    DWORD PTR [rax+0x0]
  40aa30:	mov    edx,0x80000000
  40aa35:	xor    eax,eax
  40aa37:	lock cmpxchg DWORD PTR [rbx],edx
  40aa3b:	test   eax,eax
  40aa3d:	je     40aa74 <__swc_fn_e121059d_000138_8c07c14b+0xa4>
  40aa3f:	mov    eax,DWORD PTR [rbx]
  40aa41:	lea    rcx,[rsp+0x14]
  40aa46:	mov    DWORD PTR [rsp+0x14],eax
  40aa4a:	test   eax,eax
  40aa4c:	je     40aa30 <__swc_fn_e121059d_000138_8c07c14b+0x60>
  40aa4e:	mov    QWORD PTR [rsp],0x0
  40aa56:	mov    edi,0xca
  40aa5b:	mov    rsi,rbx
  40aa5e:	mov    edx,0x80
  40aa63:	mov    ecx,DWORD PTR [rcx]
  40aa65:	xor    r8d,r8d
  40aa68:	xor    r9d,r9d
  40aa6b:	xor    eax,eax
  40aa6d:	call   407080 <syscall@plt>
  40aa72:	jmp    40aa30 <__swc_fn_e121059d_000138_8c07c14b+0x60>
  40aa74:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40aa7a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40aa80:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40aa86:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40aa8c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40aa92:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40aa98:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40aa9e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40aaa7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40aab0:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40aab9:	add    rsp,0xc0
  40aac0:	pop    rsi
  40aac1:	pop    rdi
  40aac2:	pop    rbx
  40aac3:	ret
	...

000000000040aad0 <__swc_fn_e121059d_000141_055b38a4>:
  40aad0:	sub    rsp,0x8
  40aad4:	call   40dde0 <__swc_fn_e121059d_000139_715e84ff>
  40aad9:	add    rsp,0x8
  40aadd:	ret
	...

000000000040aae0 <__swc_fn_e121059d_000144_d299b428>:
  40aae0:	push   rdi
  40aae1:	push   rsi
  40aae2:	sub    rsp,0xa8
  40aae9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40aaef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40aaf5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40aafb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40ab01:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40ab07:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40ab0d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ab13:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ab19:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ab22:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ab2b:	mov    edi,0x28
  40ab30:	xor    eax,eax
  40ab32:	call   407090 <malloc@plt>
  40ab37:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ab3d:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ab43:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ab49:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ab4f:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ab55:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ab5b:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ab61:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ab67:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ab70:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ab79:	add    rsp,0xa8
  40ab80:	pop    rsi
  40ab81:	pop    rdi
  40ab82:	ret
	...

000000000040ab90 <__swc_fn_e121059d_000147_162f363d>:
  40ab90:	mov    QWORD PTR [r8],0x0
  40ab97:	cmp    rdx,0x10
  40ab9b:	jae    40aba0 <__swc_fn_e121059d_000147_162f363d+0x10>
  40ab9d:	xor    eax,eax
  40ab9f:	ret
  40aba0:	mov    eax,DWORD PTR [rcx]
  40aba2:	cmp    eax,0x42445753
  40aba8:	jne    40abb2 <__swc_fn_e121059d_000147_162f363d+0x22>
  40abaa:	mov    eax,DWORD PTR [rcx+0x4]
  40abad:	cmp    eax,0x1
  40abb0:	je     40abb5 <__swc_fn_e121059d_000147_162f363d+0x25>
  40abb2:	xor    eax,eax
  40abb4:	ret
  40abb5:	mov    QWORD PTR [r8],rdx
  40abb8:	mov    rax,rcx
  40abbb:	ret
  40abbc:	add    BYTE PTR [rax],al
	...

000000000040abc0 <__swc_fn_e121059d_000150_2eb804cc>:
  40abc0:	push   rbx
  40abc1:	sub    rsp,0xe0
  40abc8:	lea    rbx,[rsp+0x8]
  40abcd:	vxorps xmm0,xmm0,xmm0
  40abd1:	vmovups YMMWORD PTR [rbx],ymm0
  40abd5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40abda:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40abdf:	vzeroupper
  40abe2:	mov    DWORD PTR [rbx+0x60],0x0
  40abe9:	mov    r8,rbx
  40abec:	mov    rdx,rcx
  40abef:	nop
  40abf0:	mov    r9,rdx
  40abf3:	movabs rdx,0x6666666666666667
  40abfd:	mov    rax,r9
  40ac00:	imul   rdx
  40ac03:	sar    rdx,0x2
  40ac07:	mov    r10,rdx
  40ac0a:	shr    rdx,0x3f
  40ac0e:	add    r10,rdx
  40ac11:	mov    rdx,r10
  40ac14:	imul   r11,r10,0xa
  40ac18:	sub    r9,r11
  40ac1b:	mov    r11,QWORD PTR [rip+0x8aae]        # 4136d0 <__swc_rdata_base_e121059d+0x5c0>
  40ac22:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40ac27:	mov    BYTE PTR [r8],r9b
  40ac2a:	lea    r9,[r8+0x1]
  40ac2e:	mov    r8,r9
  40ac31:	test   r10,r10
  40ac34:	jne    40abf0 <__swc_fn_e121059d_000150_2eb804cc+0x30>
  40ac36:	test   rcx,rcx
  40ac39:	jge    40ac43 <__swc_fn_e121059d_000150_2eb804cc+0x83>
  40ac3b:	mov    BYTE PTR [r9],0x2d
  40ac3f:	add    r8,0x1
  40ac43:	mov    BYTE PTR [r8],0x0
  40ac47:	sub    r8,0x1
  40ac4b:	mov    rax,rbx
  40ac4e:	cmp    rax,r8
  40ac51:	jae    40ac76 <__swc_fn_e121059d_000150_2eb804cc+0xb6>
  40ac53:	cs nop WORD PTR [rax+rax*1+0x0]
  40ac5d:	nop    DWORD PTR [rax]
  40ac60:	mov    cl,BYTE PTR [r8]
  40ac63:	mov    dl,BYTE PTR [rax]
  40ac65:	mov    BYTE PTR [r8],dl
  40ac68:	sub    r8,0x1
  40ac6c:	mov    BYTE PTR [rax],cl
  40ac6e:	inc    rax
  40ac71:	cmp    rax,r8
  40ac74:	jb     40ac60 <__swc_fn_e121059d_000150_2eb804cc+0xa0>
  40ac76:	xor    eax,eax
  40ac78:	test   rbx,rbx
  40ac7b:	je     40ac9e <__swc_fn_e121059d_000150_2eb804cc+0xde>
  40ac7d:	mov    rcx,rbx
  40ac80:	mov    dl,BYTE PTR [rcx]
  40ac82:	test   dl,dl
  40ac84:	je     40ac9e <__swc_fn_e121059d_000150_2eb804cc+0xde>
  40ac86:	cs nop WORD PTR [rax+rax*1+0x0]
  40ac90:	add    rcx,0x1
  40ac94:	add    rax,0x1
  40ac98:	mov    dl,BYTE PTR [rcx]
  40ac9a:	test   dl,dl
  40ac9c:	jne    40ac90 <__swc_fn_e121059d_000150_2eb804cc+0xd0>
  40ac9e:	mov    QWORD PTR [rbx+0xa8],rbx
  40aca5:	mov    QWORD PTR [rbx+0xb0],rax
  40acac:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40acb4:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40acbc:	lea    rcx,[rbx+0xb8]
  40acc3:	call   40d930 <__swc_fn_e121059d_000121_2648f149>
  40acc8:	add    rsp,0xe0
  40accf:	pop    rbx
  40acd0:	ret
	...

000000000040ace0 <__swc_fn_e121059d_000153_86f1d437>:
  40ace0:	vxorps xmm0,xmm0,xmm0
  40ace4:	vmovups XMMWORD PTR [rcx],xmm0
  40ace8:	mov    QWORD PTR [rcx+0x10],0x0
  40acf0:	ret
	...

000000000040ad00 <__swc_fn_e121059d_000156_86f1d437>:
  40ad00:	vxorps xmm0,xmm0,xmm0
  40ad04:	vmovups XMMWORD PTR [rcx],xmm0
  40ad08:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40ad0d:	vxorps xmm0,xmm0,xmm0
  40ad11:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40ad16:	vmovups xmm0,XMMWORD PTR [rip+0x8a9a]        # 4137b8 <__swc_rdata_base_e121059d+0x6a8>
  40ad1e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40ad23:	vxorps xmm0,xmm0,xmm0
  40ad27:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40ad2c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40ad31:	mov    QWORD PTR [rcx+0x60],0x0
  40ad39:	ret
  40ad3a:	add    BYTE PTR [rax],al
  40ad3c:	add    BYTE PTR [rax],al
	...

000000000040ad40 <__swc_fn_e121059d_000159_86f1d437>:
  40ad40:	vxorps xmm0,xmm0,xmm0
  40ad44:	vmovups XMMWORD PTR [rcx],xmm0
  40ad48:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40ad4d:	vxorps xmm0,xmm0,xmm0
  40ad51:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40ad56:	vmovups xmm0,XMMWORD PTR [rip+0x8b82]        # 4138e0 <__swc_rdata_base_e121059d+0x7d0>
  40ad5e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40ad63:	vxorps xmm0,xmm0,xmm0
  40ad67:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40ad6c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40ad71:	vxorps xmm0,xmm0,xmm0
  40ad75:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40ad7a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40ad7f:	vxorps xmm0,xmm0,xmm0
  40ad83:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40ad8b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40ad93:	vxorps xmm0,xmm0,xmm0
  40ad97:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40ad9f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40ada7:	vxorps xmm0,xmm0,xmm0
  40adab:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40adb3:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40adbb:	mov    QWORD PTR [rcx+0xe0],0x0
  40adc6:	ret
	...

000000000040add0 <__swc_fn_e121059d_000162_13ead2ff>:
  40add0:	push   rbx
  40add1:	mov    rbx,rcx
  40add4:	call   40f370 <__swc_fn_e121059d_000163_e36363a8>
  40add9:	mov    rax,QWORD PTR [rbx+0x10]
  40addd:	test   rax,rax
  40ade0:	je     40adf1 <__swc_fn_e121059d_000162_13ead2ff+0x21>
  40ade2:	mov    rcx,rbx
  40ade5:	mov    rdx,rax
  40ade8:	mov    r8,QWORD PTR [rbx+0x18]
  40adec:	call   412730 <__swc_fn_e121059d_000161_47b270e1>
  40adf1:	vxorps xmm0,xmm0,xmm0
  40adf5:	vmovups XMMWORD PTR [rbx],xmm0
  40adf9:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40adfe:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ae03:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40ae08:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40ae0d:	mov    QWORD PTR [rbx+0x50],0x0
  40ae15:	pop    rbx
  40ae16:	ret
	...

000000000040ae20 <__swc_fn_e121059d_000165_72795826>:
  40ae20:	sub    rsp,0x10
  40ae24:	mov    eax,r8d
  40ae27:	mov    r8d,r9d
  40ae2a:	test   r9d,r9d
  40ae2d:	jne    40ae46 <__swc_fn_e121059d_000165_72795826+0x26>
  40ae2f:	vmovups xmm0,XMMWORD PTR [rip+0x8b61]        # 413998 <__swc_rdata_base_e121059d+0x888>
  40ae37:	vmovups XMMWORD PTR [r10],xmm0
  40ae3c:	mov    eax,0x1
  40ae41:	add    rsp,0x10
  40ae45:	ret
  40ae46:	mov    r9,r8
  40ae49:	cmp    r8,rax
  40ae4c:	jb     40ae53 <__swc_fn_e121059d_000165_72795826+0x33>
  40ae4e:	cmp    r9,rdx
  40ae51:	jb     40ae5a <__swc_fn_e121059d_000165_72795826+0x3a>
  40ae53:	xor    eax,eax
  40ae55:	add    rsp,0x10
  40ae59:	ret
  40ae5a:	xor    eax,eax
  40ae5c:	lea    r8,[r9+rax*1]
  40ae60:	cmp    r8,rdx
  40ae63:	jae    40ae93 <__swc_fn_e121059d_000165_72795826+0x73>
  40ae65:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae6f:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae79:	nop    DWORD PTR [rax+0x0]
  40ae80:	cmp    BYTE PTR [rcx+r8*1],0x0
  40ae85:	je     40ae93 <__swc_fn_e121059d_000165_72795826+0x73>
  40ae87:	inc    rax
  40ae8a:	lea    r8,[r9+rax*1]
  40ae8e:	cmp    r8,rdx
  40ae91:	jb     40ae80 <__swc_fn_e121059d_000165_72795826+0x60>
  40ae93:	cmp    r8,rdx
  40ae96:	jne    40ae9f <__swc_fn_e121059d_000165_72795826+0x7f>
  40ae98:	xor    eax,eax
  40ae9a:	add    rsp,0x10
  40ae9e:	ret
  40ae9f:	add    rcx,r9
  40aea2:	mov    QWORD PTR [rsp],rcx
  40aea6:	mov    QWORD PTR [rsp+0x8],rax
  40aeab:	vmovups xmm0,XMMWORD PTR [rsp]
  40aeb0:	vmovups XMMWORD PTR [r10],xmm0
  40aeb5:	mov    eax,0x1
  40aeba:	add    rsp,0x10
  40aebe:	ret
	...

000000000040aec0 <__swc_fn_e121059d_000168_bcc835b8>:
  40aec0:	push   rbp
  40aec1:	push   rbx
  40aec2:	push   rsi
  40aec3:	push   rdi
  40aec4:	push   r12
  40aec6:	push   r13
  40aec8:	push   r14
  40aeca:	push   r15
  40aecc:	sub    rsp,0x10
  40aed0:	mov    rbp,rsp
  40aed3:	vmovups XMMWORD PTR [rsp],xmm6
  40aed8:	sub    rsp,0x50
  40aedc:	mov    rbx,rsp
  40aedf:	mov    rsi,r8
  40aee2:	mov    QWORD PTR [rsp+0x30],r8
  40aee7:	mov    rdi,rcx
  40aeea:	mov    QWORD PTR [rsp+0x38],rcx
  40aeef:	mov    r12,rdx
  40aef2:	xor    r13b,r13b
  40aef5:	mov    r14,QWORD PTR [rdi+0x8]
  40aef9:	mov    QWORD PTR [rsp+0x40],r14
  40aefe:	xor    r15d,r15d
  40af01:	test   r14,r14
  40af04:	jbe    40b15e <__swc_fn_e121059d_000168_bcc835b8+0x29e>
  40af0a:	mov    r14,QWORD PTR [rdi]
  40af0d:	mov    rax,QWORD PTR [rsp+0x40]
  40af12:	mov    QWORD PTR [rsp+0x48],r14
  40af17:	vmovups xmm6,XMMWORD PTR [rip+0x86a9]        # 4135c8 <__swc_rdata_base_e121059d+0x4b8>
  40af1f:	nop
  40af20:	cmp    QWORD PTR [r14+r15*8],0x0
  40af25:	jne    40af2f <__swc_fn_e121059d_000168_bcc835b8+0x6f>
  40af27:	mov    r14,rax
  40af2a:	jmp    40b13e <__swc_fn_e121059d_000168_bcc835b8+0x27e>
  40af2f:	mov    rcx,QWORD PTR [rdi]
  40af32:	mov    rdx,QWORD PTR [rcx+r15*8]
  40af36:	mov    rdi,rbx
  40af39:	mov    rcx,rdi
  40af3c:	sub    rsp,0x8
  40af40:	mov    r14,rax
  40af43:	call   4127b0 <__swc_fn_e121059d_000167_cc119975>
  40af48:	add    rsp,0x8
  40af4c:	mov    al,BYTE PTR [rbx]
  40af4e:	test   al,al
  40af50:	je     40b13e <__swc_fn_e121059d_000168_bcc835b8+0x27e>
  40af56:	mov    al,BYTE PTR [rbx+0x1]
  40af59:	test   al,al
  40af5b:	jne    40af66 <__swc_fn_e121059d_000168_bcc835b8+0xa6>
  40af5d:	test   sil,sil
  40af60:	je     40b13e <__swc_fn_e121059d_000168_bcc835b8+0x27e>
  40af66:	test   r13b,r13b
  40af69:	jne    40b027 <__swc_fn_e121059d_000168_bcc835b8+0x167>
  40af6f:	test   r12,r12
  40af72:	je     40b027 <__swc_fn_e121059d_000168_bcc835b8+0x167>
  40af78:	mov    al,BYTE PTR [rbx+0x1]
  40af7b:	test   al,al
  40af7d:	je     40b13e <__swc_fn_e121059d_000168_bcc835b8+0x27e>
  40af83:	mov    eax,DWORD PTR [rbx+0x28]
  40af86:	cmp    DWORD PTR [r12+0x20],eax
  40af8b:	jne    40b13e <__swc_fn_e121059d_000168_bcc835b8+0x27e>
  40af91:	mov    rax,QWORD PTR [r12]
  40af95:	mov    rcx,QWORD PTR [r12+0x8]
  40af9a:	cmp    QWORD PTR [rbx+0x20],rcx
  40af9e:	jne    40b13e <__swc_fn_e121059d_000168_bcc835b8+0x27e>
  40afa4:	mov    cl,0x1
  40afa6:	test   rax,rax
  40afa9:	je     40b012 <__swc_fn_e121059d_000168_bcc835b8+0x152>
  40afaf:	mov    rdx,QWORD PTR [rbx+0x20]
  40afb3:	xor    r8d,r8d
  40afb6:	test   rdx,rdx
  40afb9:	jbe    40b012 <__swc_fn_e121059d_000168_bcc835b8+0x152>
  40afbb:	mov    r9,QWORD PTR [rbx+0x18]
  40afbf:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40afc4:	cs nop WORD PTR [rax+rax*1+0x0]
  40afce:	xchg   ax,ax
  40afd0:	mov    r10b,BYTE PTR [rax+r8*1]
  40afd4:	cmp    BYTE PTR [r9+r8*1],r10b
  40afd8:	je     40b009 <__swc_fn_e121059d_000168_bcc835b8+0x149>
  40afda:	vmovq  r10,xmm0
  40afdf:	cmp    BYTE PTR [r10+r8*1],0x5c
  40afe4:	jne    40afed <__swc_fn_e121059d_000168_bcc835b8+0x12d>
  40afe6:	cmp    BYTE PTR [rax+r8*1],0x2f
  40afeb:	je     40b009 <__swc_fn_e121059d_000168_bcc835b8+0x149>
  40afed:	vmovq  r10,xmm0
  40aff2:	cmp    BYTE PTR [r10+r8*1],0x2f
  40aff7:	jne    40b000 <__swc_fn_e121059d_000168_bcc835b8+0x140>
  40aff9:	cmp    BYTE PTR [rax+r8*1],0x5c
  40affe:	je     40b009 <__swc_fn_e121059d_000168_bcc835b8+0x149>
  40b000:	xor    eax,eax
  40b002:	movzx  eax,al
  40b005:	mov    cl,al
  40b007:	jmp    40b012 <__swc_fn_e121059d_000168_bcc835b8+0x152>
  40b009:	add    r8,0x1
  40b00d:	cmp    r8,rdx
  40b010:	jb     40afd0 <__swc_fn_e121059d_000168_bcc835b8+0x110>
  40b012:	test   cl,cl
  40b014:	je     40b13e <__swc_fn_e121059d_000168_bcc835b8+0x27e>
  40b01a:	mov    eax,0x1
  40b01f:	mov    r13b,al
  40b022:	jmp    40b13e <__swc_fn_e121059d_000168_bcc835b8+0x27e>
  40b027:	mov    r13b,0x1
  40b02a:	sub    rsp,0x20
  40b02e:	mov    rax,rsp
  40b031:	lea    rcx,[rdi+0x8]
  40b035:	mov    QWORD PTR [rax],rcx
  40b038:	lea    rsi,[rip+0x8171]        # 4131b0 <__swc_rdata_base_e121059d+0xa0>
  40b03f:	mov    QWORD PTR [rax+0x8],rsi
  40b043:	mov    QWORD PTR [rax+0x10],rsp
  40b047:	mov    QWORD PTR [rax+0x18],0x1
  40b04f:	lea    rcx,[rsp+0x10]
  40b054:	sub    rsp,0x8
  40b058:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40b05d:	add    rsp,0x8
  40b061:	add    rsp,0x20
  40b065:	mov    al,BYTE PTR [rbx+0x1]
  40b068:	test   al,al
  40b06a:	je     40b107 <__swc_fn_e121059d_000168_bcc835b8+0x247>
  40b070:	lea    rax,[rip+0x89c1]        # 413a38 <__swc_rdata_base_e121059d+0x928>
  40b077:	sub    rsp,0x20
  40b07b:	mov    rcx,rsp
  40b07e:	mov    QWORD PTR [rcx],rax
  40b081:	mov    QWORD PTR [rcx+0x8],rsi
  40b085:	mov    QWORD PTR [rcx+0x10],rsp
  40b089:	mov    QWORD PTR [rcx+0x18],0x1
  40b091:	lea    rcx,[rsp+0x10]
  40b096:	sub    rsp,0x8
  40b09a:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40b09f:	add    rsp,0x8
  40b0a3:	add    rsp,0x20
  40b0a7:	mov    eax,DWORD PTR [rbx+0x28]
  40b0aa:	sub    rsp,0x60
  40b0ae:	mov    rcx,rsp
  40b0b1:	lea    rdx,[rdi+0x18]
  40b0b5:	mov    QWORD PTR [rcx+0x18],rdx
  40b0b9:	mov    QWORD PTR [rcx+0x20],rsi
  40b0bd:	vmovups XMMWORD PTR [rcx],xmm6
  40b0c1:	mov    QWORD PTR [rcx+0x28],rsp
  40b0c5:	mov    QWORD PTR [rcx+0x30],rsi
  40b0c9:	mov    DWORD PTR [rcx+0x10],eax
  40b0cc:	lea    rax,[rsp+0x10]
  40b0d1:	mov    QWORD PTR [rcx+0x38],rax
  40b0d5:	lea    rax,[rip+0x8484]        # 413560 <__swc_rdata_base_e121059d+0x450>
  40b0dc:	mov    QWORD PTR [rcx+0x40],rax
  40b0e0:	lea    rax,[rsp+0x18]
  40b0e5:	mov    QWORD PTR [rcx+0x48],rax
  40b0e9:	mov    QWORD PTR [rcx+0x50],0x3
  40b0f1:	lea    rcx,[rsp+0x48]
  40b0f6:	sub    rsp,0x8
  40b0fa:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40b0ff:	add    rsp,0x8
  40b103:	add    rsp,0x60
  40b107:	lea    rax,[rip+0x8092]        # 4131a0 <__swc_rdata_base_e121059d+0x90>
  40b10e:	sub    rsp,0x20
  40b112:	mov    rcx,rsp
  40b115:	mov    QWORD PTR [rcx],rax
  40b118:	mov    QWORD PTR [rcx+0x8],rsi
  40b11c:	mov    QWORD PTR [rcx+0x10],rsp
  40b120:	mov    QWORD PTR [rcx+0x18],0x1
  40b128:	lea    rcx,[rsp+0x10]
  40b12d:	sub    rsp,0x8
  40b131:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40b136:	add    rsp,0x8
  40b13a:	add    rsp,0x20
  40b13e:	add    r15,0x1
  40b142:	cmp    r15,r14
  40b145:	jae    40b15e <__swc_fn_e121059d_000168_bcc835b8+0x29e>
  40b147:	mov    rsi,QWORD PTR [rsp+0x30]
  40b14c:	mov    rdi,QWORD PTR [rsp+0x38]
  40b151:	mov    rax,r14
  40b154:	mov    r14,QWORD PTR [rsp+0x48]
  40b159:	jmp    40af20 <__swc_fn_e121059d_000168_bcc835b8+0x60>
  40b15e:	add    rsp,0x50
  40b162:	vmovups xmm6,XMMWORD PTR [rsp]
  40b167:	add    rsp,0x10
  40b16b:	pop    r15
  40b16d:	pop    r14
  40b16f:	pop    r13
  40b171:	pop    r12
  40b173:	pop    rdi
  40b174:	pop    rsi
  40b175:	pop    rbx
  40b176:	pop    rbp
  40b177:	ret
	...

000000000040b180 <__swc_fn_e121059d_000171_646fdf20>:
  40b180:	sub    rsp,0x8
  40b184:	call   40dbb0 <__swc_fn_e121059d_000130_4bbe3f14>
  40b189:	add    rsp,0x8
  40b18d:	ret
	...

000000000040b190 <__swc_fn_e121059d_000174_1e0ea8cf>:
  40b190:	push   rsi
  40b191:	sub    rsp,0x30
  40b195:	lea    rsi,[rip+0x1bbfc]        # 426d98 <__swc_bss_base_e121059d+0x2d58>
  40b19c:	mov    rax,QWORD PTR [rsi]
  40b19f:	test   rax,rax
  40b1a2:	je     40b1aa <__swc_fn_e121059d_000174_1e0ea8cf+0x1a>
  40b1a4:	add    rsp,0x30
  40b1a8:	pop    rsi
  40b1a9:	ret
  40b1aa:	mov    ecx,0x2
  40b1af:	mov    edx,0x8020
  40b1b4:	call   40d250 <__swc_fn_e121059d_000112_6814119b>
  40b1b9:	test   rax,rax
  40b1bc:	jne    40b1cd <__swc_fn_e121059d_000174_1e0ea8cf+0x3d>
  40b1be:	mov    QWORD PTR [rsp+0x18],rax
  40b1c3:	call   40a620 <__swc_fn_e121059d_000123_be2e2f68>
  40b1c8:	mov    rax,QWORD PTR [rsp+0x18]
  40b1cd:	mov    rcx,rax
  40b1d0:	xchg   QWORD PTR [rsi],rcx
  40b1d3:	add    rsp,0x30
  40b1d7:	pop    rsi
  40b1d8:	ret
  40b1d9:	add    BYTE PTR [rax],al
  40b1db:	add    BYTE PTR [rax],al
  40b1dd:	add    BYTE PTR [rax],al
	...

000000000040b1e0 <__swc_fn_e121059d_000177_4de704de>:
  40b1e0:	push   rsi
  40b1e1:	test   r8,r8
  40b1e4:	jne    40b1e8 <__swc_fn_e121059d_000177_4de704de+0x8>
  40b1e6:	pop    rsi
  40b1e7:	ret
  40b1e8:	lea    rax,[rcx+0x18]
  40b1ec:	mov    r10,QWORD PTR [rax]
  40b1ef:	lea    r11,[r10+0x1]
  40b1f3:	mov    QWORD PTR [rax],r11
  40b1f6:	mov    r11,rdx
  40b1f9:	not    rdx
  40b1fc:	lea    rsi,[r8-0x1]
  40b200:	cmp    rsi,rdx
  40b203:	ja     40b223 <__swc_fn_e121059d_000177_4de704de+0x43>
  40b205:	lea    rdx,[r11+r8*1]
  40b209:	dec    rdx
  40b20c:	shr    rdx,0x6
  40b210:	mov    r8,r11
  40b213:	shr    r8,0x6
  40b217:	mov    rsi,rdx
  40b21a:	sub    rsi,r8
  40b21d:	cmp    rsi,0x8
  40b221:	jb     40b239 <__swc_fn_e121059d_000177_4de704de+0x59>
  40b223:	lea    rcx,[rcx+0x10]
  40b227:	mov    rdx,QWORD PTR [rcx]
  40b22a:	add    rdx,r9
  40b22d:	mov    QWORD PTR [rcx],rdx
  40b230:	lea    rcx,[r10+0x2]
  40b234:	mov    QWORD PTR [rax],rcx
  40b237:	pop    rsi
  40b238:	ret
  40b239:	shr    r11,0x6
  40b23d:	nop    DWORD PTR [rax]
  40b240:	cmp    r11,rdx
  40b243:	ja     40b283 <__swc_fn_e121059d_000177_4de704de+0xa3>
  40b245:	jmp    40b256 <__swc_fn_e121059d_000177_4de704de+0x76>
  40b247:	nop    WORD PTR [rax+rax*1+0x0]
  40b250:	add    r11,0x1
  40b254:	jmp    40b240 <__swc_fn_e121059d_000177_4de704de+0x60>
  40b256:	mov    r8,r11
  40b259:	shr    r8,0xc
  40b25d:	mov    rsi,r11
  40b260:	xor    rsi,r8
  40b263:	mov    r8,r11
  40b266:	shr    r8,0x18
  40b26a:	xor    rsi,r8
  40b26d:	and    esi,0xfff
  40b273:	lea    r8,[rcx+rsi*8+0x20]
  40b278:	mov    rsi,QWORD PTR [r8]
  40b27b:	add    rsi,r9
  40b27e:	mov    QWORD PTR [r8],rsi
  40b281:	jmp    40b250 <__swc_fn_e121059d_000177_4de704de+0x70>
  40b283:	lea    rcx,[r10+0x2]
  40b287:	mov    QWORD PTR [rax],rcx
  40b28a:	pop    rsi
  40b28b:	ret
	...

000000000040b2a0 <__swc_fn_e121059d_000001_2744b483>:
  40b2a0:	push   rbx
  40b2a1:	sub    rsp,0x70
  40b2a5:	cmp    rcx,0xffffffffffffffef
  40b2a9:	jbe    40b2b3 <__swc_fn_e121059d_000001_2744b483+0x13>
  40b2ab:	xor    eax,eax
  40b2ad:	add    rsp,0x70
  40b2b1:	pop    rbx
  40b2b2:	ret
  40b2b3:	vxorps xmm0,xmm0,xmm0
  40b2b7:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40b2bd:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40b2c3:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  40b2c9:	vzeroupper
  40b2cc:	lea    rax,[rcx+0x10]
  40b2d0:	mov    QWORD PTR [rsp+0x50],rax
  40b2d5:	mov    DWORD PTR [rsp+0x60],0x10
  40b2dd:	mov    rcx,QWORD PTR [rip+0x18d5c]        # 424040 <__swc_bss_base_e121059d>
  40b2e4:	test   rcx,rcx
  40b2e7:	jne    40b2f9 <__swc_fn_e121059d_000001_2744b483+0x59>
  40b2e9:	call   412a40 <__swc_fn_e121059d_000170_994c8876>
  40b2ee:	lea    rcx,[rax+0x1]
  40b2f2:	mov    QWORD PTR [rip+0x18d47],rcx        # 424040 <__swc_bss_base_e121059d>
  40b2f9:	dec    rcx
  40b2fc:	call   40f6e0 <__swc_fn_e121059d_000172_360af05d>
  40b301:	mov    rcx,QWORD PTR [rax]
  40b304:	lea    rdx,[rsp+0x8]
  40b309:	mov    rbx,QWORD PTR [rax+0x8]
  40b30d:	mov    rbx,QWORD PTR [rbx+0x8]
  40b311:	call   rbx
  40b313:	mov    rax,QWORD PTR [rsp+0x48]
  40b318:	test   rax,rax
  40b31b:	jne    40b325 <__swc_fn_e121059d_000001_2744b483+0x85>
  40b31d:	xor    eax,eax
  40b31f:	add    rsp,0x70
  40b323:	pop    rbx
  40b324:	ret
  40b325:	mov    rcx,QWORD PTR [rsp+0x50]
  40b32a:	mov    QWORD PTR [rax],rcx
  40b32d:	mov    QWORD PTR [rax+0x8],0x0
  40b335:	lea    rax,[rax+0x10]
  40b339:	add    rsp,0x70
  40b33d:	pop    rbx
  40b33e:	ret
	...

000000000040b340 <__swc_fn_e121059d_000004_9ee35b18>:
  40b340:	vxorps xmm0,xmm0,xmm0
  40b344:	vmovups XMMWORD PTR [rcx],xmm0
  40b348:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b34d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b352:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b357:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40b35c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40b361:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40b366:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40b36b:	ret
  40b36c:	add    BYTE PTR [rax],al
	...

000000000040b370 <__swc_fn_e121059d_000007_f7acedb0>:
  40b370:	push   rsi
  40b371:	mov    rsi,rdx
  40b374:	test   rdx,rdx
  40b377:	jne    40b380 <__swc_fn_e121059d_000007_f7acedb0+0x10>
  40b379:	mov    eax,0x1
  40b37e:	pop    rsi
  40b37f:	ret
  40b380:	mov    rdx,rsi
  40b383:	call   411ae0 <__swc_fn_e121059d_000116_36905703>
  40b388:	test   al,al
  40b38a:	jne    40b390 <__swc_fn_e121059d_000007_f7acedb0+0x20>
  40b38c:	xor    eax,eax
  40b38e:	pop    rsi
  40b38f:	ret
  40b390:	lea    rcx,[rip+0x18cb9]        # 424050 <__swc_bss_base_e121059d+0x10>
  40b397:	mov    rdx,QWORD PTR [rip+0x18cb2]        # 424050 <__swc_bss_base_e121059d+0x10>
  40b39e:	xchg   ax,ax
  40b3a0:	lea    r8,[rdx+rsi*1]
  40b3a4:	mov    rax,rdx
  40b3a7:	lock cmpxchg QWORD PTR [rcx],r8
  40b3ac:	cmp    rax,rdx
  40b3af:	je     40b3b6 <__swc_fn_e121059d_000007_f7acedb0+0x46>
  40b3b1:	mov    rdx,rax
  40b3b4:	jmp    40b3a0 <__swc_fn_e121059d_000007_f7acedb0+0x30>
  40b3b6:	lea    rcx,[rip+0x18c9b]        # 424058 <__swc_bss_base_e121059d+0x18>
  40b3bd:	mov    rdx,QWORD PTR [rip+0x18c94]        # 424058 <__swc_bss_base_e121059d+0x18>
  40b3c4:	cs nop WORD PTR [rax+rax*1+0x0]
  40b3ce:	xchg   ax,ax
  40b3d0:	lea    r8,[rdx+0x1]
  40b3d4:	mov    rax,rdx
  40b3d7:	lock cmpxchg QWORD PTR [rcx],r8
  40b3dc:	cmp    rax,rdx
  40b3df:	je     40b3e6 <__swc_fn_e121059d_000007_f7acedb0+0x76>
  40b3e1:	mov    rdx,rax
  40b3e4:	jmp    40b3d0 <__swc_fn_e121059d_000007_f7acedb0+0x60>
  40b3e6:	mov    eax,0x1
  40b3eb:	pop    rsi
  40b3ec:	ret
  40b3ed:	add    BYTE PTR [rax],al
	...

000000000040b3f0 <__swc_fn_e121059d_000010_24a20786>:
  40b3f0:	push   rbx
  40b3f1:	push   rsi
  40b3f2:	push   rdi
  40b3f3:	push   r12
  40b3f5:	sub    rsp,0x18
  40b3f9:	mov    rbx,rcx
  40b3fc:	mov    rsi,rcx
  40b3ff:	and    rsi,0xffffffffffc00000
  40b406:	movzx  eax,BYTE PTR [rbx+0x3a]
  40b40a:	mov    ecx,DWORD PTR [rsi+0x28]
  40b40d:	shrx   eax,eax,ecx
  40b412:	lea    rdi,[rsp+0x8]
  40b417:	mov    DWORD PTR [rsp+0x8],eax
  40b41b:	mov    rcx,rsi
  40b41e:	mov    rax,rdi
  40b421:	mov    edx,DWORD PTR [rax]
  40b423:	call   4085e0 <__swc_fn_e121059d_000015_9dea5065>
  40b428:	mov    r12,rax
  40b42b:	mov    rcx,rsi
  40b42e:	mov    edx,DWORD PTR [rdi]
  40b430:	call   40b520 <__swc_fn_e121059d_000016_9afb7cfb>
  40b435:	mov    rcx,r12
  40b438:	mov    edx,DWORD PTR [rbx+0x3c]
  40b43b:	add    rcx,rdx
  40b43e:	cmp    rcx,rax
  40b441:	jb     40b44f <__swc_fn_e121059d_000010_24a20786+0x5f>
  40b443:	xor    eax,eax
  40b445:	add    rsp,0x18
  40b449:	pop    r12
  40b44b:	pop    rdi
  40b44c:	pop    rsi
  40b44d:	pop    rbx
  40b44e:	ret
  40b44f:	mov    rdx,QWORD PTR [rbx+0x20]
  40b453:	mov    r8d,DWORD PTR [rbx+0x2c]
  40b457:	add    rdx,r8
  40b45a:	lea    rsi,[rdx+0xffff]
  40b461:	and    rsi,0xffffffffffff0000
  40b468:	cmp    rax,rsi
  40b46b:	cmovbe rsi,rax
  40b46f:	mov    rax,rsi
  40b472:	sub    rax,rcx
  40b475:	mov    rdx,rax
  40b478:	call   40b370 <__swc_fn_e121059d_000007_f7acedb0>
  40b47d:	test   al,al
  40b47f:	jne    40b48d <__swc_fn_e121059d_000010_24a20786+0x9d>
  40b481:	xor    eax,eax
  40b483:	add    rsp,0x18
  40b487:	pop    r12
  40b489:	pop    rdi
  40b48a:	pop    rsi
  40b48b:	pop    rbx
  40b48c:	ret
  40b48d:	sub    rsi,r12
  40b490:	mov    DWORD PTR [rbx+0x3c],esi
  40b493:	mov    ecx,DWORD PTR [rbx+0x2c]
  40b496:	mov    rax,rsi
  40b499:	xor    edx,edx
  40b49b:	div    rcx
  40b49e:	imul   rax,rcx
  40b4a2:	add    r12,rax
  40b4a5:	mov    QWORD PTR [rbx+0x18],r12
  40b4a9:	mov    eax,0x1
  40b4ae:	add    rsp,0x18
  40b4b2:	pop    r12
  40b4b4:	pop    rdi
  40b4b5:	pop    rsi
  40b4b6:	pop    rbx
  40b4b7:	ret
	...

000000000040b4c0 <__swc_fn_e121059d_000013_e4b0ddfc>:
  40b4c0:	sub    rsp,0x8
  40b4c4:	mov    rdx,rcx
  40b4c7:	lea    r9,[rcx+0x60]
  40b4cb:	mov    rax,QWORD PTR [r9]
  40b4ce:	test   rax,rax
  40b4d1:	jne    40b4d8 <__swc_fn_e121059d_000013_e4b0ddfc+0x18>
  40b4d3:	add    rsp,0x8
  40b4d7:	ret
  40b4d8:	mov    rcx,rdx
  40b4db:	call   40fa50 <__swc_fn_e121059d_000011_c3647f66>
  40b4e0:	xor    eax,eax
  40b4e2:	xchg   QWORD PTR [r9],rax
  40b4e5:	mov    r8,rax
  40b4e8:	mov    rcx,rdx
  40b4eb:	call   4085d0 <__swc_fn_e121059d_000012_861b8b62>
  40b4f0:	xor    eax,eax
  40b4f2:	test   r8,r8
  40b4f5:	je     40b516 <__swc_fn_e121059d_000013_e4b0ddfc+0x56>
  40b4f7:	nop    WORD PTR [rax+rax*1+0x0]
  40b500:	mov    rcx,QWORD PTR [r8]
  40b503:	mov    r9,QWORD PTR [rdx]
  40b506:	mov    QWORD PTR [r8],r9
  40b509:	mov    QWORD PTR [rdx],r8
  40b50c:	mov    r8,rcx
  40b50f:	inc    eax
  40b511:	test   rcx,rcx
  40b514:	jne    40b500 <__swc_fn_e121059d_000013_e4b0ddfc+0x40>
  40b516:	sub    DWORD PTR [rdx+0x28],eax
  40b519:	add    rsp,0x8
  40b51d:	ret
	...

000000000040b520 <__swc_fn_e121059d_000016_9afb7cfb>:
  40b520:	lea    eax,[rdx+0x1]
  40b523:	mov    edx,DWORD PTR [rcx+0x28]
  40b526:	shlx   eax,eax,edx
  40b52b:	shl    rax,0x10
  40b52f:	add    rax,rcx
  40b532:	ret
	...

000000000040b540 <__swc_fn_e121059d_000019_adca76cf>:
  40b540:	push   rbx
  40b541:	push   rsi
  40b542:	push   rdi
  40b543:	push   r12
  40b545:	push   r13
  40b547:	push   r14
  40b549:	push   r15
  40b54b:	sub    rsp,0x30
  40b54f:	mov    rbx,rcx
  40b552:	lea    rsi,[rcx+0x48]
  40b556:	mov    QWORD PTR [rsp+0x18],rsi
  40b55b:	mov    rax,QWORD PTR [rsi]
  40b55e:	mov    rdi,rax
  40b561:	lea    r12,[rsp+0x8]
  40b566:	lea    r13,[rcx+0x40]
  40b56a:	nop    WORD PTR [rax+rax*1+0x0]
  40b570:	test   rdi,rdi
  40b573:	je     40b6b3 <__swc_fn_e121059d_000019_adca76cf+0x173>
  40b579:	xor    eax,eax
  40b57b:	tzcnt  rax,rdi
  40b580:	mov    DWORD PTR [rsp+0x8],eax
  40b584:	mov    r14d,0x1
  40b58a:	mov    ecx,eax
  40b58c:	shl    r14,cl
  40b58f:	andn   rdi,r14,rdi
  40b594:	mov    rcx,QWORD PTR [r13+0x0]
  40b598:	test   rcx,r14
  40b59b:	jne    40b570 <__swc_fn_e121059d_000019_adca76cf+0x30>
  40b59d:	mov    rdx,rcx
  40b5a0:	or     rdx,r14
  40b5a3:	mov    rax,rcx
  40b5a6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  40b5ac:	cmp    rax,rcx
  40b5af:	je     40b5b9 <__swc_fn_e121059d_000019_adca76cf+0x79>
  40b5b1:	mov    rax,QWORD PTR [rsi]
  40b5b4:	mov    rdi,rax
  40b5b7:	jmp    40b570 <__swc_fn_e121059d_000019_adca76cf+0x30>
  40b5b9:	mov    rcx,rbx
  40b5bc:	mov    rdx,r14
  40b5bf:	call   408740 <__swc_fn_e121059d_000021_fd2b165c>
  40b5c4:	test   al,al
  40b5c6:	je     40b69e <__swc_fn_e121059d_000019_adca76cf+0x15e>
  40b5cc:	mov    eax,DWORD PTR [r12]
  40b5d0:	shl    rax,0x4
  40b5d4:	lea    r15,[rbx+rax*8+0x80]
  40b5dc:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  40b5e4:	lea    rcx,[rip+0x18a75]        # 424060 <__swc_bss_base_e121059d+0x20>
  40b5eb:	mov    rdx,QWORD PTR [rip+0x18a6e]        # 424060 <__swc_bss_base_e121059d+0x20>
  40b5f2:	cs nop WORD PTR [rax+rax*1+0x0]
  40b5fc:	nop    DWORD PTR [rax+0x0]
  40b600:	mov    r8,rdx
  40b603:	sub    r8,rsi
  40b606:	mov    rax,rdx
  40b609:	lock cmpxchg QWORD PTR [rcx],r8
  40b60e:	cmp    rax,rdx
  40b611:	je     40b618 <__swc_fn_e121059d_000019_adca76cf+0xd8>
  40b613:	mov    rdx,rax
  40b616:	jmp    40b600 <__swc_fn_e121059d_000019_adca76cf+0xc0>
  40b618:	mov    rcx,rbx
  40b61b:	mov    rax,r12
  40b61e:	mov    edx,DWORD PTR [rax]
  40b620:	call   4085e0 <__swc_fn_e121059d_000015_9dea5065>
  40b625:	test   rsi,rsi
  40b628:	je     40b696 <__swc_fn_e121059d_000019_adca76cf+0x156>
  40b62e:	mov    rcx,rax
  40b631:	mov    rdx,rsi
  40b634:	call   40a3f0 <__swc_fn_e121059d_000117_e9fc0224>
  40b639:	lea    rcx,[rip+0x18a10]        # 424050 <__swc_bss_base_e121059d+0x10>
  40b640:	mov    rdx,QWORD PTR [rip+0x18a09]        # 424050 <__swc_bss_base_e121059d+0x10>
  40b647:	nop    WORD PTR [rax+rax*1+0x0]
  40b650:	mov    r8,rdx
  40b653:	sub    r8,rsi
  40b656:	mov    rax,rdx
  40b659:	lock cmpxchg QWORD PTR [rcx],r8
  40b65e:	cmp    rax,rdx
  40b661:	je     40b668 <__swc_fn_e121059d_000019_adca76cf+0x128>
  40b663:	mov    rdx,rax
  40b666:	jmp    40b650 <__swc_fn_e121059d_000019_adca76cf+0x110>
  40b668:	lea    rcx,[rip+0x189f9]        # 424068 <__swc_bss_base_e121059d+0x28>
  40b66f:	mov    rdx,QWORD PTR [rip+0x189f2]        # 424068 <__swc_bss_base_e121059d+0x28>
  40b676:	cs nop WORD PTR [rax+rax*1+0x0]
  40b680:	lea    r8,[rdx+0x1]
  40b684:	mov    rax,rdx
  40b687:	lock cmpxchg QWORD PTR [rcx],r8
  40b68c:	cmp    rax,rdx
  40b68f:	je     40b696 <__swc_fn_e121059d_000019_adca76cf+0x156>
  40b691:	mov    rdx,rax
  40b694:	jmp    40b680 <__swc_fn_e121059d_000019_adca76cf+0x140>
  40b696:	mov    DWORD PTR [r15+0x3c],0x0
  40b69e:	mov    rcx,rbx
  40b6a1:	mov    rdx,r14
  40b6a4:	call   40b6d0 <__swc_fn_e121059d_000022_c8f5f27c>
  40b6a9:	mov    rsi,QWORD PTR [rsp+0x18]
  40b6ae:	jmp    40b570 <__swc_fn_e121059d_000019_adca76cf+0x30>
  40b6b3:	add    rsp,0x30
  40b6b7:	pop    r15
  40b6b9:	pop    r14
  40b6bb:	pop    r13
  40b6bd:	pop    r12
  40b6bf:	pop    rdi
  40b6c0:	pop    rsi
  40b6c1:	pop    rbx
  40b6c2:	ret
	...

000000000040b6d0 <__swc_fn_e121059d_000022_c8f5f27c>:
  40b6d0:	mov    r8,QWORD PTR [rcx+0x40]
  40b6d4:	cs nop WORD PTR [rax+rax*1+0x0]
  40b6de:	xchg   ax,ax
  40b6e0:	mov    rax,rdx
  40b6e3:	not    rax
  40b6e6:	mov    r9,r8
  40b6e9:	and    r9,rax
  40b6ec:	mov    rax,r8
  40b6ef:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  40b6f5:	cmp    rax,r8
  40b6f8:	jne    40b6fb <__swc_fn_e121059d_000022_c8f5f27c+0x2b>
  40b6fa:	ret
  40b6fb:	mov    r8,rax
  40b6fe:	jmp    40b6e0 <__swc_fn_e121059d_000022_c8f5f27c+0x10>

000000000040b700 <__swc_fn_e121059d_000025_aa910677>:
  40b700:	push   rsi
  40b701:	push   rdi
  40b702:	sub    rsp,0x8
  40b706:	mov    rsi,rcx
  40b709:	call   40b540 <__swc_fn_e121059d_000019_adca76cf>
  40b70e:	lea    rdi,[rip+0x18ae3]        # 4241f8 <__swc_bss_base_e121059d+0x1b8>
  40b715:	mov    rcx,rdi
  40b718:	call   412140 <__swc_fn_e121059d_000140_86bb0f90>
  40b71d:	mov    QWORD PTR [rsi+0x8],0x0
  40b725:	mov    QWORD PTR [rsi+0x18],0x0
  40b72d:	mov    rax,QWORD PTR [rip+0x18acc]        # 424200 <__swc_bss_base_e121059d+0x1c0>
  40b734:	mov    QWORD PTR [rsi+0x10],rax
  40b738:	mov    QWORD PTR [rip+0x18ac1],rsi        # 424200 <__swc_bss_base_e121059d+0x1c0>
  40b73f:	mov    rcx,rdi
  40b742:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  40b747:	add    rsp,0x8
  40b74b:	pop    rdi
  40b74c:	pop    rsi
  40b74d:	ret
	...

000000000040b750 <__swc_fn_e121059d_000028_9798fb47>:
  40b750:	vxorps xmm0,xmm0,xmm0
  40b754:	vmovups XMMWORD PTR [rcx],xmm0
  40b758:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b75d:	mov    QWORD PTR [rcx+0x20],0x0
  40b765:	ret
	...

000000000040b770 <__swc_fn_e121059d_000031_9798fb47>:
  40b770:	vxorps xmm0,xmm0,xmm0
  40b774:	vmovups XMMWORD PTR [rcx],xmm0
  40b778:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b77d:	mov    QWORD PTR [rcx+0x20],0x0
  40b785:	ret
	...

000000000040b790 <__swc_fn_e121059d_000034_9128bcf9>:
  40b790:	push   r12
  40b792:	mov    r12,rdi
  40b795:	test   rdi,rdi
  40b798:	jne    40b79d <__swc_fn_e121059d_000034_9128bcf9+0xd>
  40b79a:	pop    r12
  40b79c:	ret
  40b79d:	lea    rax,[rip+0x16864]        # 422008 <__swc_data_base_e121059d+0x8>
  40b7a4:	mov    rax,QWORD PTR [rax]
  40b7a7:	cmp    rax,0xffffffffffffffff
  40b7ab:	je     40b7ba <__swc_fn_e121059d_000034_9128bcf9+0x2a>
  40b7ad:	mov    eax,eax
  40b7af:	mov    edi,eax
  40b7b1:	xor    eax,eax
  40b7b3:	call   407000 <pthread_getspecific@plt>
  40b7b8:	jmp    40b7bc <__swc_fn_e121059d_000034_9128bcf9+0x2c>
  40b7ba:	xor    eax,eax
  40b7bc:	cmp    rax,r12
  40b7bf:	jne    40b7c8 <__swc_fn_e121059d_000034_9128bcf9+0x38>
  40b7c1:	xor    ecx,ecx
  40b7c3:	call   408900 <__swc_fn_e121059d_000036_92d9bbff>
  40b7c8:	mov    rdx,QWORD PTR [r12]
  40b7cc:	test   rdx,rdx
  40b7cf:	je     40b7e8 <__swc_fn_e121059d_000034_9128bcf9+0x58>
  40b7d1:	mov    rcx,rdx
  40b7d4:	call   40b810 <__swc_fn_e121059d_000040_eb6108f2>
  40b7d9:	test   al,al
  40b7db:	je     40b7e8 <__swc_fn_e121059d_000034_9128bcf9+0x58>
  40b7dd:	mov    rcx,rdx
  40b7e0:	mov    rdx,r12
  40b7e3:	call   40b900 <__swc_fn_e121059d_000046_b30433d0>
  40b7e8:	pop    r12
  40b7ea:	ret
  40b7eb:	add    BYTE PTR [rax],al
  40b7ed:	add    BYTE PTR [rax],al
	...

000000000040b7f0 <__swc_fn_e121059d_000037_28d0e998>:
  40b7f0:	push   rsi
  40b7f1:	mov    rsi,rcx
  40b7f4:	call   40ff00 <__swc_fn_e121059d_000035_cd1a4e8c>
  40b7f9:	mov    rcx,rax
  40b7fc:	mov    rdx,rsi
  40b7ff:	call   411fc0 <__swc_fn_e121059d_000134_ae5891af>
  40b804:	mov    rcx,rsi
  40b807:	call   408900 <__swc_fn_e121059d_000036_92d9bbff>
  40b80c:	pop    rsi
  40b80d:	ret
	...

000000000040b810 <__swc_fn_e121059d_000040_eb6108f2>:
  40b810:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40b81a:	sete   al
  40b81d:	ret
	...

000000000040b820 <__swc_fn_e121059d_000043_d3c2ab54>:
  40b820:	push   rsi
  40b821:	test   rdx,rdx
  40b824:	jne    40b828 <__swc_fn_e121059d_000043_d3c2ab54+0x8>
  40b826:	pop    rsi
  40b827:	ret
  40b828:	mov    rax,r8
  40b82b:	mov    ecx,0x1000
  40b830:	test   ecx,ecx
  40b832:	mov    r10d,0x8
  40b838:	cmove  ecx,r10d
  40b83c:	dec    rcx
  40b83f:	mov    r10,0xffffffffffffffff
  40b846:	sub    r10,rcx
  40b849:	cmp    r8,r10
  40b84c:	jbe    40b852 <__swc_fn_e121059d_000043_d3c2ab54+0x32>
  40b84e:	xor    eax,eax
  40b850:	jmp    40b85a <__swc_fn_e121059d_000043_d3c2ab54+0x3a>
  40b852:	add    rax,rcx
  40b855:	andn   rax,rcx,rax
  40b85a:	mov    ecx,0x1000
  40b85f:	test   ecx,ecx
  40b861:	mov    r8d,0x8
  40b867:	cmove  ecx,r8d
  40b86b:	dec    rcx
  40b86e:	mov    r8,0xffffffffffffffff
  40b875:	sub    r8,rcx
  40b878:	cmp    r9,r8
  40b87b:	jbe    40b881 <__swc_fn_e121059d_000043_d3c2ab54+0x61>
  40b87d:	xor    esi,esi
  40b87f:	jmp    40b88c <__swc_fn_e121059d_000043_d3c2ab54+0x6c>
  40b881:	add    r9,rcx
  40b884:	andn   r9,rcx,r9
  40b889:	mov    rsi,r9
  40b88c:	mov    rcx,rdx
  40b88f:	mov    rdx,rax
  40b892:	mov    r8,rsi
  40b895:	call   411bc0 <__swc_fn_e121059d_000119_5208f471>
  40b89a:	lea    rcx,[rip+0x187af]        # 424050 <__swc_bss_base_e121059d+0x10>
  40b8a1:	mov    rdx,QWORD PTR [rip+0x187a8]        # 424050 <__swc_bss_base_e121059d+0x10>
  40b8a8:	nop    DWORD PTR [rax+rax*1+0x0]
  40b8b0:	mov    r8,rdx
  40b8b3:	sub    r8,rsi
  40b8b6:	mov    rax,rdx
  40b8b9:	lock cmpxchg QWORD PTR [rcx],r8
  40b8be:	cmp    rax,rdx
  40b8c1:	je     40b8c8 <__swc_fn_e121059d_000043_d3c2ab54+0xa8>
  40b8c3:	mov    rdx,rax
  40b8c6:	jmp    40b8b0 <__swc_fn_e121059d_000043_d3c2ab54+0x90>
  40b8c8:	lea    rcx,[rip+0x18799]        # 424068 <__swc_bss_base_e121059d+0x28>
  40b8cf:	mov    rdx,QWORD PTR [rip+0x18792]        # 424068 <__swc_bss_base_e121059d+0x28>
  40b8d6:	cs nop WORD PTR [rax+rax*1+0x0]
  40b8e0:	lea    r8,[rdx+0x1]
  40b8e4:	mov    rax,rdx
  40b8e7:	lock cmpxchg QWORD PTR [rcx],r8
  40b8ec:	cmp    rax,rdx
  40b8ef:	je     40b8f6 <__swc_fn_e121059d_000043_d3c2ab54+0xd6>
  40b8f1:	mov    rdx,rax
  40b8f4:	jmp    40b8e0 <__swc_fn_e121059d_000043_d3c2ab54+0xc0>
  40b8f6:	pop    rsi
  40b8f7:	ret
	...

000000000040b900 <__swc_fn_e121059d_000046_b30433d0>:
  40b900:	push   rbx
  40b901:	push   rsi
  40b902:	push   rdi
  40b903:	push   r12
  40b905:	push   r13
  40b907:	push   r14
  40b909:	push   r15
  40b90b:	sub    rsp,0x30
  40b90f:	mov    rbx,rdx
  40b912:	mov    QWORD PTR [rsp+0x18],rdx
  40b917:	mov    rsi,rcx
  40b91a:	mov    eax,0x1
  40b91f:	xchg   DWORD PTR [rbx+0x20],eax
  40b922:	test   eax,eax
  40b924:	je     40b936 <__swc_fn_e121059d_000046_b30433d0+0x36>
  40b926:	add    rsp,0x30
  40b92a:	pop    r15
  40b92c:	pop    r14
  40b92e:	pop    r13
  40b930:	pop    r12
  40b932:	pop    rdi
  40b933:	pop    rsi
  40b934:	pop    rbx
  40b935:	ret
  40b936:	mov    rcx,rsi
  40b939:	mov    rdx,rbx
  40b93c:	mov    r8,0xffffffffffffffff
  40b943:	call   408ed0 <__swc_fn_e121059d_000063_dea90857>
  40b948:	lea    rdi,[rsi+0x10]
  40b94c:	mov    QWORD PTR [rsp+0x20],rdi
  40b951:	mov    rcx,rdi
  40b954:	call   412140 <__swc_fn_e121059d_000140_86bb0f90>
  40b959:	xor    r12d,r12d
  40b95c:	cs nop WORD PTR [rax+rax*1+0x0]
  40b966:	cs nop WORD PTR [rax+rax*1+0x0]
  40b970:	mov    eax,r12d
  40b973:	lea    r13,[rax+rax*4]
  40b977:	lea    r13,[rbx+r13*8+0x28]
  40b97c:	mov    rax,QWORD PTR [r13+0x8]
  40b980:	mov    QWORD PTR [rsp+0x8],rax
  40b985:	mov    rax,QWORD PTR [r13+0x18]
  40b989:	mov    QWORD PTR [rsp+0x10],rax
  40b98e:	mov    r14d,0x2
  40b994:	xor    r15d,r15d
  40b997:	test   r14,r14
  40b99a:	je     40ba17 <__swc_fn_e121059d_000046_b30433d0+0x117>
  40b9a0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  40b9a5:	mov    rdi,rax
  40b9a8:	test   rdi,rdi
  40b9ab:	je     40ba09 <__swc_fn_e121059d_000046_b30433d0+0x109>
  40b9ad:	nop    DWORD PTR [rax]
  40b9b0:	mov    rbx,QWORD PTR [rdi+0x48]
  40b9b4:	mov    DWORD PTR [rdi+0x6c],0x0
  40b9bb:	mov    rcx,rdi
  40b9be:	call   40b4c0 <__swc_fn_e121059d_000013_e4b0ddfc>
  40b9c3:	cmp    DWORD PTR [rdi+0x28],0x0
  40b9c7:	jne    40b9e0 <__swc_fn_e121059d_000046_b30433d0+0xe0>
  40b9c9:	mov    rax,rdi
  40b9cc:	and    rax,0xffffffffffc00000
  40b9d3:	mov    rcx,rax
  40b9d6:	mov    rdx,rdi
  40b9d9:	call   408600 <__swc_fn_e121059d_000018_283e2b5e>
  40b9de:	jmp    40ba01 <__swc_fn_e121059d_000046_b30433d0+0x101>
  40b9e0:	mov    QWORD PTR [rdi+0x40],0x0
  40b9e8:	rex mov BYTE PTR [rdi+0x3b],0x2
  40b9ed:	mov    QWORD PTR [rdi+0x50],0x0
  40b9f5:	mov    rax,QWORD PTR [rsi+0x28]
  40b9f9:	mov    QWORD PTR [rdi+0x48],rax
  40b9fd:	mov    QWORD PTR [rsi+0x28],rdi
  40ba01:	mov    rdi,rbx
  40ba04:	test   rbx,rbx
  40ba07:	jne    40b9b0 <__swc_fn_e121059d_000046_b30433d0+0xb0>
  40ba09:	add    r15,0x1
  40ba0d:	sub    r14,0x1
  40ba11:	jne    40b9a0 <__swc_fn_e121059d_000046_b30433d0+0xa0>
  40ba17:	vxorps xmm0,xmm0,xmm0
  40ba1b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  40ba21:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40ba27:	mov    QWORD PTR [r13+0x20],0x0
  40ba2f:	add    r12,0x1
  40ba33:	cmp    r12,0x2d
  40ba37:	mov    rbx,QWORD PTR [rsp+0x18]
  40ba3c:	jb     40b970 <__swc_fn_e121059d_000046_b30433d0+0x70>
  40ba42:	mov    rcx,rsi
  40ba45:	mov    rbx,QWORD PTR [rsp+0x18]
  40ba4a:	mov    rdx,rbx
  40ba4d:	mov    rdi,QWORD PTR [rsp+0x20]
  40ba52:	call   4100c0 <__swc_fn_e121059d_000047_6e7a8d58>
  40ba57:	mov    rcx,rdi
  40ba5a:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  40ba5f:	mov    rcx,rsi
  40ba62:	mov    rdx,rbx
  40ba65:	mov    r8d,0x9b8
  40ba6b:	mov    r9d,0x9b8
  40ba71:	call   40b820 <__swc_fn_e121059d_000043_d3c2ab54>
  40ba76:	add    rsp,0x30
  40ba7a:	pop    r15
  40ba7c:	pop    r14
  40ba7e:	pop    r13
  40ba80:	pop    r12
  40ba82:	pop    rdi
  40ba83:	pop    rsi
  40ba84:	pop    rbx
  40ba85:	ret
	...

000000000040baa0 <__swc_fn_e121059d_000049_ad48ec88>:
  40baa0:	push   rbx
  40baa1:	push   rsi
  40baa2:	push   rdi
  40baa3:	push   r12
  40baa5:	push   r13
  40baa7:	push   r14
  40baa9:	push   r15
  40baab:	sub    rsp,0x30
  40baaf:	mov    ebx,r8d
  40bab2:	mov    rsi,rcx
  40bab5:	mov    rdi,rdx
  40bab8:	test   r8d,r8d
  40babb:	jne    40bac4 <__swc_fn_e121059d_000049_ad48ec88+0x24>
  40babd:	mov    eax,0x8
  40bac2:	jmp    40baeb <__swc_fn_e121059d_000049_ad48ec88+0x4b>
  40bac4:	cmp    ebx,0x8
  40bac7:	ja     40bad2 <__swc_fn_e121059d_000049_ad48ec88+0x32>
  40bac9:	mov    rax,rbx
  40bacc:	shl    rax,0x4
  40bad0:	jmp    40baeb <__swc_fn_e121059d_000049_ad48ec88+0x4b>
  40bad2:	lea    eax,[rbx-0x9]
  40bad5:	mov    ecx,eax
  40bad7:	shr    ecx,0x2
  40bada:	and    eax,0x3
  40badd:	lea    ecx,[rcx+0x7]
  40bae0:	lea    ecx,[rcx-0x2]
  40bae3:	lea    eax,[rax+0x5]
  40bae6:	shlx   rax,rax,rcx
  40baeb:	lea    r12,[rsp+0x8]
  40baf0:	mov    DWORD PTR [rsp+0x8],eax
  40baf4:	lea    r13,[rsp+0xc]
  40baf9:	mov    QWORD PTR [rsp+0x18],r13
  40bafe:	xor    eax,eax
  40bb00:	cmp    ebx,0x21
  40bb03:	setae  al
  40bb06:	lea    eax,[rax+rax*2]
  40bb09:	mov    DWORD PTR [rsp+0xc],eax
  40bb0d:	lea    r14,[rsi+0x10]
  40bb11:	mov    rcx,r14
  40bb14:	call   412140 <__swc_fn_e121059d_000140_86bb0f90>
  40bb19:	xor    eax,eax
  40bb1b:	mov    rcx,QWORD PTR [rsi+0x28]
  40bb1f:	mov    r15,rcx
  40bb22:	test   r15,r15
  40bb25:	je     40bbd6 <__swc_fn_e121059d_000049_ad48ec88+0x136>
  40bb2b:	cs nop WORD PTR [rax+rax*1+0x0]
  40bb35:	cs nop WORD PTR [rax+rax*1+0x0]
  40bb3f:	nop
  40bb40:	mov    rcx,QWORD PTR [r15+0x48]
  40bb44:	movzx  edx,BYTE PTR [r15+0x39]
  40bb49:	cmp    edx,ebx
  40bb4b:	jne    40bbc7 <__swc_fn_e121059d_000049_ad48ec88+0x127>
  40bb4d:	test   rax,rax
  40bb50:	jne    40bb58 <__swc_fn_e121059d_000049_ad48ec88+0xb8>
  40bb52:	mov    QWORD PTR [rsi+0x28],rcx
  40bb56:	jmp    40bb5c <__swc_fn_e121059d_000049_ad48ec88+0xbc>
  40bb58:	mov    QWORD PTR [rax+0x48],rcx
  40bb5c:	vxorps xmm0,xmm0,xmm0
  40bb60:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  40bb66:	mov    BYTE PTR [r15+0x3b],0x1
  40bb6b:	mov    QWORD PTR [r15+0x40],rdi
  40bb6f:	mov    rcx,r15
  40bb72:	call   40b4c0 <__swc_fn_e121059d_000013_e4b0ddfc>
  40bb77:	movzx  eax,BYTE PTR [r15+0x39]
  40bb7c:	lea    rax,[rax+rax*4]
  40bb80:	lea    rax,[rdi+rax*8+0x28]
  40bb85:	mov    rcx,QWORD PTR [rax+0x10]
  40bb89:	mov    QWORD PTR [r15+0x50],rcx
  40bb8d:	mov    QWORD PTR [r15+0x48],0x0
  40bb95:	mov    rcx,QWORD PTR [rax+0x10]
  40bb99:	test   rcx,rcx
  40bb9c:	je     40bba4 <__swc_fn_e121059d_000049_ad48ec88+0x104>
  40bb9e:	mov    QWORD PTR [rcx+0x48],r15
  40bba2:	jmp    40bba8 <__swc_fn_e121059d_000049_ad48ec88+0x108>
  40bba4:	mov    QWORD PTR [rax+0x8],r15
  40bba8:	mov    QWORD PTR [rax+0x10],r15
  40bbac:	mov    rcx,r14
  40bbaf:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  40bbb4:	mov    rax,r15
  40bbb7:	add    rsp,0x30
  40bbbb:	pop    r15
  40bbbd:	pop    r14
  40bbbf:	pop    r13
  40bbc1:	pop    r12
  40bbc3:	pop    rdi
  40bbc4:	pop    rsi
  40bbc5:	pop    rbx
  40bbc6:	ret
  40bbc7:	mov    rax,r15
  40bbca:	mov    r15,rcx
  40bbcd:	test   rcx,rcx
  40bbd0:	jne    40bb40 <__swc_fn_e121059d_000049_ad48ec88+0xa0>
  40bbd6:	mov    rax,QWORD PTR [rsi+0x18]
  40bbda:	mov    r15,rax
  40bbdd:	test   r15,r15
  40bbe0:	je     40bc76 <__swc_fn_e121059d_000049_ad48ec88+0x1d6>
  40bbe6:	cs nop WORD PTR [rax+rax*1+0x0]
  40bbf0:	mov    eax,DWORD PTR [rsp+0xc]
  40bbf4:	cmp    DWORD PTR [r15+0x28],eax
  40bbf8:	jne    40bc66 <__swc_fn_e121059d_000049_ad48ec88+0x1c6>
  40bbfa:	mov    rcx,r15
  40bbfd:	mov    edx,ebx
  40bbff:	mov    rax,r12
  40bc02:	mov    r8d,DWORD PTR [rax]
  40bc05:	call   40fb00 <__swc_fn_e121059d_000017_efc44797>
  40bc0a:	mov    r13,rax
  40bc0d:	test   rax,rax
  40bc10:	je     40bc66 <__swc_fn_e121059d_000049_ad48ec88+0x1c6>
  40bc12:	mov    QWORD PTR [r13+0x40],rdi
  40bc16:	movzx  eax,BYTE PTR [r13+0x39]
  40bc1b:	lea    rax,[rax+rax*4]
  40bc1f:	lea    rax,[rdi+rax*8+0x28]
  40bc24:	mov    rcx,QWORD PTR [rax+0x10]
  40bc28:	mov    QWORD PTR [r13+0x50],rcx
  40bc2c:	mov    QWORD PTR [r13+0x48],0x0
  40bc34:	mov    rcx,QWORD PTR [rax+0x10]
  40bc38:	test   rcx,rcx
  40bc3b:	je     40bc43 <__swc_fn_e121059d_000049_ad48ec88+0x1a3>
  40bc3d:	mov    QWORD PTR [rcx+0x48],r13
  40bc41:	jmp    40bc47 <__swc_fn_e121059d_000049_ad48ec88+0x1a7>
  40bc43:	mov    QWORD PTR [rax+0x8],r13
  40bc47:	mov    QWORD PTR [rax+0x10],r13
  40bc4b:	mov    rcx,r14
  40bc4e:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  40bc53:	mov    rax,r13
  40bc56:	add    rsp,0x30
  40bc5a:	pop    r15
  40bc5c:	pop    r14
  40bc5e:	pop    r13
  40bc60:	pop    r12
  40bc62:	pop    rdi
  40bc63:	pop    rsi
  40bc64:	pop    rbx
  40bc65:	ret
  40bc66:	mov    rax,QWORD PTR [r15+0x10]
  40bc6a:	mov    r15,rax
  40bc6d:	test   rax,rax
  40bc70:	jne    40bbf0 <__swc_fn_e121059d_000049_ad48ec88+0x150>
  40bc76:	mov    rcx,rsi
  40bc79:	mov    r13,QWORD PTR [rsp+0x18]
  40bc7e:	mov    edx,DWORD PTR [r13+0x0]
  40bc82:	call   408780 <__swc_fn_e121059d_000024_2685aade>
  40bc87:	mov    r13,rax
  40bc8a:	test   rax,rax
  40bc8d:	jne    40bca9 <__swc_fn_e121059d_000049_ad48ec88+0x209>
  40bc8f:	mov    rcx,r14
  40bc92:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  40bc97:	xor    eax,eax
  40bc99:	add    rsp,0x30
  40bc9d:	pop    r15
  40bc9f:	pop    r14
  40bca1:	pop    r13
  40bca3:	pop    r12
  40bca5:	pop    rdi
  40bca6:	pop    rsi
  40bca7:	pop    rbx
  40bca8:	ret
  40bca9:	mov    rcx,r13
  40bcac:	mov    edx,ebx
  40bcae:	mov    r8d,DWORD PTR [r12]
  40bcb2:	call   40fb00 <__swc_fn_e121059d_000017_efc44797>
  40bcb7:	mov    rbx,rax
  40bcba:	test   rax,rax
  40bcbd:	jne    40bce1 <__swc_fn_e121059d_000049_ad48ec88+0x241>
  40bcbf:	mov    rcx,r13
  40bcc2:	call   40b700 <__swc_fn_e121059d_000025_aa910677>
  40bcc7:	mov    rcx,r14
  40bcca:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  40bccf:	xor    eax,eax
  40bcd1:	add    rsp,0x30
  40bcd5:	pop    r15
  40bcd7:	pop    r14
  40bcd9:	pop    r13
  40bcdb:	pop    r12
  40bcdd:	pop    rdi
  40bcde:	pop    rsi
  40bcdf:	pop    rbx
  40bce0:	ret
  40bce1:	mov    rax,QWORD PTR [rsi+0x18]
  40bce5:	mov    QWORD PTR [r13+0x10],rax
  40bce9:	mov    rax,QWORD PTR [rsi+0x18]
  40bced:	test   rax,rax
  40bcf0:	je     40bcf6 <__swc_fn_e121059d_000049_ad48ec88+0x256>
  40bcf2:	mov    QWORD PTR [rax+0x18],r13
  40bcf6:	mov    QWORD PTR [rsi+0x18],r13
  40bcfa:	mov    QWORD PTR [rbx+0x40],rdi
  40bcfe:	movzx  eax,BYTE PTR [rbx+0x39]
  40bd02:	lea    rax,[rax+rax*4]
  40bd06:	lea    rax,[rdi+rax*8+0x28]
  40bd0b:	mov    rcx,QWORD PTR [rax+0x10]
  40bd0f:	mov    QWORD PTR [rbx+0x50],rcx
  40bd13:	mov    QWORD PTR [rbx+0x48],0x0
  40bd1b:	mov    rcx,QWORD PTR [rax+0x10]
  40bd1f:	test   rcx,rcx
  40bd22:	je     40bd2a <__swc_fn_e121059d_000049_ad48ec88+0x28a>
  40bd24:	mov    QWORD PTR [rcx+0x48],rbx
  40bd28:	jmp    40bd2e <__swc_fn_e121059d_000049_ad48ec88+0x28e>
  40bd2a:	mov    QWORD PTR [rax+0x8],rbx
  40bd2e:	mov    QWORD PTR [rax+0x10],rbx
  40bd32:	mov    rcx,r14
  40bd35:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  40bd3a:	mov    rax,rbx
  40bd3d:	add    rsp,0x30
  40bd41:	pop    r15
  40bd43:	pop    r14
  40bd45:	pop    r13
  40bd47:	pop    r12
  40bd49:	pop    rdi
  40bd4a:	pop    rsi
  40bd4b:	pop    rbx
  40bd4c:	ret
	...

000000000040bd60 <__swc_fn_e121059d_000052_d846b172>:
  40bd60:	push   rsi
  40bd61:	push   rdi
  40bd62:	push   r12
  40bd64:	mov    rsi,rdx
  40bd67:	mov    rdi,rcx
  40bd6a:	lea    rax,[rcx+0x2a80]
  40bd71:	mov    rcx,QWORD PTR [rax]
  40bd74:	test   rcx,rcx
  40bd77:	jne    40bd7e <__swc_fn_e121059d_000052_d846b172+0x1e>
  40bd79:	pop    r12
  40bd7b:	pop    rdi
  40bd7c:	pop    rsi
  40bd7d:	ret
  40bd7e:	xor    ecx,ecx
  40bd80:	xchg   QWORD PTR [rax],rcx
  40bd83:	mov    r12,rcx
  40bd86:	cs nop WORD PTR [rax+rax*1+0x0]
  40bd90:	cs nop WORD PTR [rax+rax*1+0x0]
  40bd9a:	nop    WORD PTR [rax+rax*1+0x0]
  40bda0:	test   r12,r12
  40bda3:	je     40be3a <__swc_fn_e121059d_000052_d846b172+0xda>
  40bda9:	mov    r8,r12
  40bdac:	mov    r12,QWORD PTR [r12+0x78]
  40bdb1:	lea    rcx,[r8+0x70]
  40bdb5:	xor    eax,eax
  40bdb7:	xchg   DWORD PTR [r8+0x70],eax
  40bdbb:	cmp    QWORD PTR [r8+0x40],rsi
  40bdbf:	jne    40bdd6 <__swc_fn_e121059d_000052_d846b172+0x76>
  40bdc1:	mov    eax,DWORD PTR [r8+0x6c]
  40bdc5:	test   eax,eax
  40bdc7:	je     40bda0 <__swc_fn_e121059d_000052_d846b172+0x40>
  40bdc9:	mov    rcx,rdi
  40bdcc:	mov    rdx,rsi
  40bdcf:	call   408b30 <__swc_fn_e121059d_000051_e072b516>
  40bdd4:	jmp    40bda0 <__swc_fn_e121059d_000052_d846b172+0x40>
  40bdd6:	mov    rax,QWORD PTR [r8+0x40]
  40bdda:	test   rax,rax
  40bddd:	je     40bda0 <__swc_fn_e121059d_000052_d846b172+0x40>
  40bddf:	mov    eax,DWORD PTR [r8+0x6c]
  40bde3:	test   eax,eax
  40bde5:	je     40bda0 <__swc_fn_e121059d_000052_d846b172+0x40>
  40bde7:	mov    r9d,0x1
  40bded:	xor    eax,eax
  40bdef:	lock cmpxchg DWORD PTR [rcx],r9d
  40bdf4:	test   eax,eax
  40bdf6:	jne    40bda0 <__swc_fn_e121059d_000052_d846b172+0x40>
  40bdf8:	mov    rax,r8
  40bdfb:	and    rax,0xffffffffffc00000
  40be02:	mov    rax,QWORD PTR [rax+0x8]
  40be06:	test   rax,rax
  40be09:	jne    40be11 <__swc_fn_e121059d_000052_d846b172+0xb1>
  40be0b:	xor    eax,eax
  40be0d:	xchg   DWORD PTR [rcx],eax
  40be0f:	jmp    40bda0 <__swc_fn_e121059d_000052_d846b172+0x40>
  40be11:	lea    rcx,[rax+0x2a80]
  40be18:	mov    rax,QWORD PTR [rcx]
  40be1b:	mov    rdx,rax
  40be1e:	xchg   ax,ax
  40be20:	mov    QWORD PTR [r8+0x78],rdx
  40be24:	mov    rax,rdx
  40be27:	lock cmpxchg QWORD PTR [rcx],r8
  40be2c:	cmp    rax,rdx
  40be2f:	je     40bda0 <__swc_fn_e121059d_000052_d846b172+0x40>
  40be35:	mov    rdx,rax
  40be38:	jmp    40be20 <__swc_fn_e121059d_000052_d846b172+0xc0>
  40be3a:	pop    r12
  40be3c:	pop    rdi
  40be3d:	pop    rsi
  40be3e:	ret
	...

000000000040be40 <__swc_fn_e121059d_000055_2e3450f7>:
  40be40:	sub    rsp,0x8
  40be44:	mov    r9,r8
  40be47:	movzx  eax,BYTE PTR [r9+0x39]
  40be4c:	lea    rax,[rax+rax*4]
  40be50:	lea    rax,[rdx+rax*8+0x28]
  40be55:	cmp    QWORD PTR [rax],r9
  40be58:	je     40be60 <__swc_fn_e121059d_000055_2e3450f7+0x20>
  40be5a:	cmp    QWORD PTR [rax+0x20],r9
  40be5e:	jne    40be65 <__swc_fn_e121059d_000055_2e3450f7+0x25>
  40be60:	add    rsp,0x8
  40be64:	ret
  40be65:	cmp    QWORD PTR [rax+0x20],0x0
  40be6a:	je     40be77 <__swc_fn_e121059d_000055_2e3450f7+0x37>
  40be6c:	mov    r8,QWORD PTR [rax+0x20]
  40be70:	cmp    DWORD PTR [r8+0x28],0x0
  40be75:	je     40be80 <__swc_fn_e121059d_000055_2e3450f7+0x40>
  40be77:	mov    QWORD PTR [rax+0x20],r9
  40be7b:	add    rsp,0x8
  40be7f:	ret
  40be80:	mov    r8,r9
  40be83:	call   408a90 <__swc_fn_e121059d_000048_137687bb>
  40be88:	mov    rax,r9
  40be8b:	and    rax,0xffffffffffc00000
  40be92:	mov    rcx,rax
  40be95:	mov    rdx,r9
  40be98:	call   408600 <__swc_fn_e121059d_000018_283e2b5e>
  40be9d:	add    rsp,0x8
  40bea1:	ret
	...

000000000040beb0 <__swc_fn_e121059d_000058_1bb23e77>:
  40beb0:	push   rsi
  40beb1:	push   rdi
  40beb2:	push   r12
  40beb4:	mov    rsi,rdx
  40beb7:	mov    rax,rdx
  40beba:	shr    rax,0xc
  40bebe:	movabs rdx,0x9e3779b97f4a7c15
  40bec8:	imul   rax,rdx
  40becc:	shr    rax,0x20
  40bed0:	lea    rax,[rax*8+0x0]
  40bed8:	shr    rax,0x20
  40bedc:	lea    rax,[rax*8+0x0]
  40bee4:	lea    rax,[rcx+rax*8+0x40]
  40bee9:	xor    edx,edx
  40beeb:	test   dl,dl
  40beed:	lea    rdi,[rcx+0x8]
  40bef1:	cmove  rdi,rax
  40bef5:	xor    edx,edx
  40bef7:	test   dl,dl
  40bef9:	lea    r12,[rcx+0x30]
  40befd:	lea    rax,[rax+0x8]
  40bf01:	cmove  r12,rax
  40bf05:	mov    rcx,rdi
  40bf08:	call   412140 <__swc_fn_e121059d_000140_86bb0f90>
  40bf0d:	mov    rax,QWORD PTR [rsi+0x30]
  40bf11:	test   rax,rax
  40bf14:	jne    40bf20 <__swc_fn_e121059d_000058_1bb23e77+0x70>
  40bf16:	mov    rax,QWORD PTR [rsi+0x38]
  40bf1a:	mov    QWORD PTR [r12],rax
  40bf1e:	jmp    40bf28 <__swc_fn_e121059d_000058_1bb23e77+0x78>
  40bf20:	mov    rcx,QWORD PTR [rsi+0x38]
  40bf24:	mov    QWORD PTR [rax+0x38],rcx
  40bf28:	mov    rax,QWORD PTR [rsi+0x38]
  40bf2c:	test   rax,rax
  40bf2f:	je     40bf39 <__swc_fn_e121059d_000058_1bb23e77+0x89>
  40bf31:	mov    rcx,QWORD PTR [rsi+0x30]
  40bf35:	mov    QWORD PTR [rax+0x30],rcx
  40bf39:	vxorps xmm0,xmm0,xmm0
  40bf3d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  40bf42:	mov    rcx,rdi
  40bf45:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  40bf4a:	pop    r12
  40bf4c:	pop    rdi
  40bf4d:	pop    rsi
  40bf4e:	ret
	...

000000000040bf50 <__swc_fn_e121059d_000061_ad030a10>:
  40bf50:	mov    rax,QWORD PTR [rcx+0x250]
  40bf57:	mov    rcx,rax
  40bf5a:	cmp    rax,0x1000000
  40bf61:	mov    eax,0x1000000
  40bf66:	cmovb  rcx,rax
  40bf6a:	mov    rax,rcx
  40bf6d:	cmp    rcx,0x10000000
  40bf74:	mov    ecx,0x10000000
  40bf79:	cmova  rax,rcx
  40bf7d:	ret
	...

000000000040bf80 <__swc_fn_e121059d_000064_ffcd96eb>:
  40bf80:	push   rsi
  40bf81:	push   rdi
  40bf82:	push   r12
  40bf84:	mov    rsi,rcx
  40bf87:	mov    rdi,QWORD PTR [rsi+0x2a70]
  40bf8e:	xor    r12d,r12d
  40bf91:	test   rdi,rdi
  40bf94:	jbe    40bfcb <__swc_fn_e121059d_000064_ffcd96eb+0x4b>
  40bf96:	cs nop WORD PTR [rax+rax*1+0x0]
  40bfa0:	lea    rax,[r12+r12*4]
  40bfa4:	lea    rax,[rsi+rax*8+0x268]
  40bfac:	mov    rcx,rsi
  40bfaf:	mov    rdx,QWORD PTR [rax]
  40bfb2:	mov    r8,QWORD PTR [rax+0x8]
  40bfb6:	mov    rax,QWORD PTR [rax+0x10]
  40bfba:	mov    r9,rax
  40bfbd:	call   40b820 <__swc_fn_e121059d_000043_d3c2ab54>
  40bfc2:	add    r12,0x1
  40bfc6:	cmp    r12,rdi
  40bfc9:	jb     40bfa0 <__swc_fn_e121059d_000064_ffcd96eb+0x20>
  40bfcb:	vxorps xmm0,xmm0,xmm0
  40bfcf:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  40bfd7:	pop    r12
  40bfd9:	pop    rdi
  40bfda:	pop    rsi
  40bfdb:	ret
  40bfdc:	add    BYTE PTR [rax],al
	...

000000000040bfe0 <__swc_fn_e121059d_000067_8c7d044b>:
  40bfe0:	push   rsi
  40bfe1:	push   rdi
  40bfe2:	sub    rsp,0x8
  40bfe6:	mov    rsi,rcx
  40bfe9:	call   410440 <__swc_fn_e121059d_000056_df0696cd>
  40bfee:	mov    rdi,rax
  40bff1:	mov    rcx,rsi
  40bff4:	mov    rdx,rax
  40bff7:	call   40beb0 <__swc_fn_e121059d_000058_1bb23e77>
  40bffc:	mov    rcx,QWORD PTR [rdi+0x28]
  40c000:	mov    rdx,QWORD PTR [rsi+0x250]
  40c007:	nop    WORD PTR [rax+rax*1+0x0]
  40c010:	mov    r8,rdx
  40c013:	sub    r8,rcx
  40c016:	mov    rax,rdx
  40c019:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40c022:	cmp    rax,rdx
  40c025:	je     40c02c <__swc_fn_e121059d_000067_8c7d044b+0x4c>
  40c027:	mov    rdx,rax
  40c02a:	jmp    40c010 <__swc_fn_e121059d_000067_8c7d044b+0x30>
  40c02c:	mov    rcx,rsi
  40c02f:	mov    rdx,QWORD PTR [rdi]
  40c032:	mov    r8,QWORD PTR [rdi+0x8]
  40c036:	mov    r9,QWORD PTR [rdi+0x10]
  40c03a:	call   410560 <__swc_fn_e121059d_000062_b304235a>
  40c03f:	mov    rcx,rsi
  40c042:	call   4101a0 <__swc_fn_e121059d_000053_3af34d7f>
  40c047:	add    rsp,0x8
  40c04b:	pop    rdi
  40c04c:	pop    rsi
  40c04d:	ret
	...

000000000040c050 <__swc_fn_e121059d_000070_97813b89>:
  40c050:	push   r12
  40c052:	push   r13
  40c054:	push   r14
  40c056:	push   rdi
  40c057:	push   rsi
  40c058:	sub    rsp,0x1b0
  40c05f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  40c068:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  40c071:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  40c07a:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  40c083:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  40c08c:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  40c095:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  40c09e:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  40c0a7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  40c0b0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  40c0b9:	mov    r8,rdx
  40c0bc:	mov    r12,rcx
  40c0bf:	mov    r13,QWORD PTR [r8+0x40]
  40c0c3:	test   r13,r13
  40c0c6:	jne    40c0d8 <__swc_fn_e121059d_000070_97813b89+0x88>
  40c0c8:	add    rsp,0x1b0
  40c0cf:	pop    rsi
  40c0d0:	pop    rdi
  40c0d1:	pop    r14
  40c0d3:	pop    r13
  40c0d5:	pop    r12
  40c0d7:	ret
  40c0d8:	mov    QWORD PTR [r8+0x40],0x0
  40c0e0:	lea    rax,[rip+0x17f91]        # 424078 <__swc_bss_base_e121059d+0x38>
  40c0e7:	mov    rcx,r13
  40c0ea:	sub    rcx,QWORD PTR [rax+0x8]
  40c0ee:	mov    rax,QWORD PTR [rip+0x17f93]        # 424088 <__swc_bss_base_e121059d+0x48>
  40c0f5:	cmp    rcx,rax
  40c0f8:	jae    40c124 <__swc_fn_e121059d_000070_97813b89+0xd4>
  40c0fa:	mov    rax,r13
  40c0fd:	and    rax,0xffffffffffc00000
  40c104:	mov    rcx,r13
  40c107:	shr    rcx,0x10
  40c10b:	and    ecx,0x3f
  40c10e:	mov    edx,DWORD PTR [rax+0x28]
  40c111:	shrx   ecx,ecx,edx
  40c116:	shl    rcx,0x4
  40c11a:	lea    r14,[rax+rcx*8+0x80]
  40c122:	jmp    40c13f <__swc_fn_e121059d_000070_97813b89+0xef>
  40c124:	mov    rcx,r13
  40c127:	mov    QWORD PTR [rsp+0xf8],r8
  40c12f:	call   40fe30 <__swc_fn_e121059d_000026_bcdc5519>
  40c134:	mov    r8,QWORD PTR [rsp+0xf8]
  40c13c:	mov    r14,rax
  40c13f:	test   r14,r14
  40c142:	jne    40c154 <__swc_fn_e121059d_000070_97813b89+0x104>
  40c144:	mov    rcx,r12
  40c147:	mov    rdx,r13
  40c14a:	call   40bfe0 <__swc_fn_e121059d_000067_8c7d044b>
  40c14f:	jmp    40c1e2 <__swc_fn_e121059d_000070_97813b89+0x192>
  40c154:	lea    rax,[rip+0x15ead]        # 422008 <__swc_data_base_e121059d+0x8>
  40c15b:	mov    rax,QWORD PTR [rax]
  40c15e:	cmp    rax,0xffffffffffffffff
  40c162:	je     40c171 <__swc_fn_e121059d_000070_97813b89+0x121>
  40c164:	mov    eax,eax
  40c166:	mov    edi,eax
  40c168:	xor    eax,eax
  40c16a:	call   407000 <pthread_getspecific@plt>
  40c16f:	jmp    40c173 <__swc_fn_e121059d_000070_97813b89+0x123>
  40c171:	xor    eax,eax
  40c173:	test   rax,rax
  40c176:	jne    40c185 <__swc_fn_e121059d_000070_97813b89+0x135>
  40c178:	call   40ff00 <__swc_fn_e121059d_000035_cd1a4e8c>
  40c17d:	mov    rcx,rax
  40c180:	call   40dc60 <__swc_fn_e121059d_000133_5f757033>
  40c185:	test   rax,rax
  40c188:	je     40c1d7 <__swc_fn_e121059d_000070_97813b89+0x187>
  40c18a:	cmp    QWORD PTR [r14+0x40],rax
  40c18e:	jne    40c1d7 <__swc_fn_e121059d_000070_97813b89+0x187>
  40c190:	mov    ecx,DWORD PTR [r14+0x6c]
  40c194:	test   ecx,ecx
  40c196:	je     40c1b6 <__swc_fn_e121059d_000070_97813b89+0x166>
  40c198:	mov    rcx,r12
  40c19b:	mov    rdx,rax
  40c19e:	mov    r8,r14
  40c1a1:	mov    QWORD PTR [rsp+0x100],rax
  40c1a9:	call   408b30 <__swc_fn_e121059d_000051_e072b516>
  40c1ae:	mov    rax,QWORD PTR [rsp+0x100]
  40c1b6:	mov    rcx,QWORD PTR [r14]
  40c1b9:	mov    QWORD PTR [r13+0x0],rcx
  40c1bd:	mov    QWORD PTR [r14],r13
  40c1c0:	sub    DWORD PTR [r14+0x28],0x1
  40c1c5:	jne    40c1e2 <__swc_fn_e121059d_000070_97813b89+0x192>
  40c1c7:	mov    rcx,r12
  40c1ca:	mov    rdx,rax
  40c1cd:	mov    r8,r14
  40c1d0:	call   40be40 <__swc_fn_e121059d_000055_2e3450f7>
  40c1d5:	jmp    40c1e2 <__swc_fn_e121059d_000070_97813b89+0x192>
  40c1d7:	mov    rcx,r14
  40c1da:	mov    rdx,r13
  40c1dd:	call   40fa70 <__swc_fn_e121059d_000014_524c1f23>
  40c1e2:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40c1eb:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  40c1f4:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40c1fd:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  40c206:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40c20f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  40c218:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  40c221:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40c22a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  40c233:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40c23c:	add    rsp,0x1b0
  40c243:	pop    rsi
  40c244:	pop    rdi
  40c245:	pop    r14
  40c247:	pop    r13
  40c249:	pop    r12
  40c24b:	ret
  40c24c:	add    BYTE PTR [rax],al
	...

000000000040c250 <__swc_fn_e121059d_000073_9c99bf04>:
  40c250:	push   rsi
  40c251:	mov    rsi,rcx
  40c254:	call   40b810 <__swc_fn_e121059d_000040_eb6108f2>
  40c259:	test   al,al
  40c25b:	jne    40c25f <__swc_fn_e121059d_000073_9c99bf04+0xf>
  40c25d:	pop    rsi
  40c25e:	ret
  40c25f:	lea    rax,[rip+0x17fda]        # 424240 <__swc_bss_base_e121059d+0x200>
  40c266:	cmp    rsi,rax
  40c269:	jne    40c26d <__swc_fn_e121059d_000073_9c99bf04+0x1d>
  40c26b:	pop    rsi
  40c26c:	ret
  40c26d:	mov    rcx,rsi
  40c270:	call   412140 <__swc_fn_e121059d_000140_86bb0f90>
  40c275:	mov    rcx,rsi
  40c278:	call   409300 <__swc_fn_e121059d_000072_61e60aab>
  40c27d:	mov    rcx,rsi
  40c280:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  40c285:	pop    rsi
  40c286:	ret
	...

000000000040c290 <__swc_fn_e121059d_000076_15bd096c>:
  40c290:	sub    rsp,0x8
  40c294:	call   409050 <__swc_fn_e121059d_000069_7130736e>
  40c299:	add    rsp,0x8
  40c29d:	ret
	...

000000000040c2a0 <__swc_fn_e121059d_000079_a5fd3362>:
  40c2a0:	push   rsi
  40c2a1:	mov    rsi,rdx
  40c2a4:	call   409300 <__swc_fn_e121059d_000072_61e60aab>
  40c2a9:	mov    QWORD PTR [rsi+0x40],0x0
  40c2b1:	pop    rsi
  40c2b2:	ret
	...

000000000040c2c0 <__swc_fn_e121059d_000082_63a67586>:
  40c2c0:	mov    r8,rcx
  40c2c3:	mov    rcx,QWORD PTR [rcx]
  40c2c6:	cs nop WORD PTR [rax+rax*1+0x0]
  40c2d0:	mov    r9,rcx
  40c2d3:	sub    r9,rdx
  40c2d6:	mov    rax,rcx
  40c2d9:	lock cmpxchg QWORD PTR [r8],r9
  40c2de:	cmp    rax,rcx
  40c2e1:	je     40c2e8 <__swc_fn_e121059d_000082_63a67586+0x28>
  40c2e3:	mov    rcx,rax
  40c2e6:	jmp    40c2d0 <__swc_fn_e121059d_000082_63a67586+0x10>
  40c2e8:	mov    rax,rcx
  40c2eb:	ret
  40c2ec:	add    BYTE PTR [rax],al
	...

000000000040c2f0 <__swc_fn_e121059d_000085_c618ff58>:
  40c2f0:	vxorps xmm0,xmm0,xmm0
  40c2f4:	vmovups XMMWORD PTR [rcx],xmm0
  40c2f8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40c2fd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40c302:	ret
	...

000000000040c310 <__swc_fn_e121059d_000088_0d280354>:
  40c310:	push   rsi
  40c311:	push   rdi
  40c312:	push   r12
  40c314:	push   r13
  40c316:	push   r15
  40c318:	push   r14
  40c31a:	push   rbx
  40c31b:	sub    rsp,0x60
  40c31f:	mov    QWORD PTR [rsp+0x28],r11
  40c324:	mov    rsi,rcx
  40c327:	mov    rdi,rdx
  40c32a:	mov    QWORD PTR [rsp+0x30],rdx
  40c32f:	mov    r12,r8
  40c332:	mov    r13,r9
  40c335:	mov    QWORD PTR [rsp+0x38],r10
  40c33a:	xor    r8d,r8d
  40c33d:	call   40c660 <__swc_fn_e121059d_000094_63c1827b>
  40c342:	test   al,al
  40c344:	je     40c359 <__swc_fn_e121059d_000088_0d280354+0x49>
  40c346:	mov    rax,r12
  40c349:	add    rsp,0x60
  40c34d:	pop    rbx
  40c34e:	pop    r14
  40c350:	pop    r15
  40c352:	pop    r13
  40c354:	pop    r12
  40c356:	pop    rdi
  40c357:	pop    rsi
  40c358:	ret
  40c359:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40c35e:	je     40c372 <__swc_fn_e121059d_000088_0d280354+0x62>
  40c360:	xor    eax,eax
  40c362:	add    rsp,0x60
  40c366:	pop    rbx
  40c367:	pop    r14
  40c369:	pop    r15
  40c36b:	pop    r13
  40c36d:	pop    r12
  40c36f:	pop    rdi
  40c370:	pop    rsi
  40c371:	ret
  40c372:	mov    r15,rdi
  40c375:	mov    QWORD PTR [rsp+0x40],rdi
  40c37a:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40c37f:	jne    40c3ef <__swc_fn_e121059d_000088_0d280354+0xdf>
  40c381:	mov    r14,QWORD PTR [r15+0xb8]
  40c388:	mov    rax,QWORD PTR [r15+0xc0]
  40c38f:	mov    r15,rax
  40c392:	xor    edi,edi
  40c394:	test   r15,r15
  40c397:	je     40c3ef <__swc_fn_e121059d_000088_0d280354+0xdf>
  40c399:	nop    DWORD PTR [rax+0x0]
  40c3a0:	lea    rbx,[rdi*8+0x0]
  40c3a8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  40c3ad:	mov    rcx,rax
  40c3b0:	mov    rdx,rsi
  40c3b3:	xor    r8d,r8d
  40c3b6:	call   40c660 <__swc_fn_e121059d_000094_63c1827b>
  40c3bb:	test   al,al
  40c3bd:	je     40c3e5 <__swc_fn_e121059d_000088_0d280354+0xd5>
  40c3bf:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  40c3c4:	test   rax,rax
  40c3c7:	je     40c3e5 <__swc_fn_e121059d_000088_0d280354+0xd5>
  40c3c9:	test   r13,r13
  40c3cc:	je     40c3d2 <__swc_fn_e121059d_000088_0d280354+0xc2>
  40c3ce:	mov    QWORD PTR [r13+0x8],rax
  40c3d2:	mov    rax,r12
  40c3d5:	add    rsp,0x60
  40c3d9:	pop    rbx
  40c3da:	pop    r14
  40c3dc:	pop    r15
  40c3de:	pop    r13
  40c3e0:	pop    r12
  40c3e2:	pop    rdi
  40c3e3:	pop    rsi
  40c3e4:	ret
  40c3e5:	add    rdi,0x1
  40c3e9:	sub    r15,0x1
  40c3ed:	jne    40c3a0 <__swc_fn_e121059d_000088_0d280354+0x90>
  40c3ef:	test   r12,r12
  40c3f2:	jne    40c406 <__swc_fn_e121059d_000088_0d280354+0xf6>
  40c3f4:	xor    eax,eax
  40c3f6:	add    rsp,0x60
  40c3fa:	pop    rbx
  40c3fb:	pop    r14
  40c3fd:	pop    r15
  40c3ff:	pop    r13
  40c401:	pop    r12
  40c403:	pop    rdi
  40c404:	pop    rsi
  40c405:	ret
  40c406:	mov    rbx,QWORD PTR [rsp+0x28]
  40c40b:	mov    rdi,QWORD PTR [rsp+0x30]
  40c410:	mov    rax,rbx
  40c413:	test   rax,rax
  40c416:	je     40c446 <__swc_fn_e121059d_000088_0d280354+0x136>
  40c418:	nop    DWORD PTR [rax+rax*1+0x0]
  40c420:	cmp    QWORD PTR [rax+0x8],r12
  40c424:	jne    40c43d <__swc_fn_e121059d_000088_0d280354+0x12d>
  40c426:	cmp    QWORD PTR [rax],rdi
  40c429:	jne    40c43d <__swc_fn_e121059d_000088_0d280354+0x12d>
  40c42b:	xor    eax,eax
  40c42d:	add    rsp,0x60
  40c431:	pop    rbx
  40c432:	pop    r14
  40c434:	pop    r15
  40c436:	pop    r13
  40c438:	pop    r12
  40c43a:	pop    rdi
  40c43b:	pop    rsi
  40c43c:	ret
  40c43d:	mov    rax,QWORD PTR [rax+0x10]
  40c441:	test   rax,rax
  40c444:	jne    40c420 <__swc_fn_e121059d_000088_0d280354+0x110>
  40c446:	lea    r14,[rsp+0x8]
  40c44b:	mov    QWORD PTR [rsp+0x48],r14
  40c450:	mov    QWORD PTR [rsp+0x8],rdi
  40c455:	mov    QWORD PTR [rsp+0x10],r12
  40c45a:	mov    QWORD PTR [rsp+0x18],rbx
  40c45f:	mov    r15,QWORD PTR [rsp+0x40]
  40c464:	mov    rbx,QWORD PTR [r15+0x98]
  40c46b:	mov    rax,QWORD PTR [r15+0xa0]
  40c472:	mov    rdi,rax
  40c475:	mov    r15,QWORD PTR [rsp+0x38]
  40c47a:	xor    r14d,r14d
  40c47d:	test   rdi,rdi
  40c480:	je     40c52a <__swc_fn_e121059d_000088_0d280354+0x21a>
  40c486:	cs nop WORD PTR [rax+rax*1+0x0]
  40c490:	mov    QWORD PTR [rsp+0x50],rdi
  40c495:	lea    rdi,[r14*8+0x0]
  40c49d:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  40c4a2:	mov    rcx,rax
  40c4a5:	call   411540 <__swc_fn_e121059d_000086_3953ef98>
  40c4aa:	test   DWORD PTR [rax+0x28],0x10000
  40c4b1:	je     40c4b8 <__swc_fn_e121059d_000088_0d280354+0x1a8>
  40c4b3:	test   r15b,r15b
  40c4b6:	je     40c511 <__swc_fn_e121059d_000088_0d280354+0x201>
  40c4b8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  40c4bc:	lea    rdi,[r12+rcx*1]
  40c4c0:	cmp    BYTE PTR [rax+0x2c],0x6
  40c4c4:	jne    40c4d8 <__swc_fn_e121059d_000088_0d280354+0x1c8>
  40c4c6:	mov    rax,QWORD PTR [rax+0x40]
  40c4ca:	mov    rcx,rax
  40c4cd:	call   411540 <__swc_fn_e121059d_000086_3953ef98>
  40c4d2:	mov    rcx,QWORD PTR [rdi]
  40c4d5:	mov    rdi,rcx
  40c4d8:	test   rdi,rdi
  40c4db:	je     40c511 <__swc_fn_e121059d_000088_0d280354+0x201>
  40c4dd:	mov    rcx,rsi
  40c4e0:	mov    rdx,rax
  40c4e3:	mov    r8,rdi
  40c4e6:	mov    r9,r13
  40c4e9:	mov    al,r15b
  40c4ec:	mov    r10,rax
  40c4ef:	mov    rdi,QWORD PTR [rsp+0x48]
  40c4f4:	mov    r11,rdi
  40c4f7:	call   40c310 <__swc_fn_e121059d_000088_0d280354>
  40c4fc:	test   rax,rax
  40c4ff:	je     40c511 <__swc_fn_e121059d_000088_0d280354+0x201>
  40c501:	add    rsp,0x60
  40c505:	pop    rbx
  40c506:	pop    r14
  40c508:	pop    r15
  40c50a:	pop    r13
  40c50c:	pop    r12
  40c50e:	pop    rdi
  40c50f:	pop    rsi
  40c510:	ret
  40c511:	add    r14,0x1
  40c515:	mov    rax,QWORD PTR [rsp+0x50]
  40c51a:	sub    rax,0x1
  40c51e:	mov    rdi,rax
  40c521:	test   rax,rax
  40c524:	jne    40c490 <__swc_fn_e121059d_000088_0d280354+0x180>
  40c52a:	xor    eax,eax
  40c52c:	add    rsp,0x60
  40c530:	pop    rbx
  40c531:	pop    r14
  40c533:	pop    r15
  40c535:	pop    r13
  40c537:	pop    r12
  40c539:	pop    rdi
  40c53a:	pop    rsi
  40c53b:	ret
  40c53c:	add    BYTE PTR [rax],al
	...

000000000040c540 <__swc_fn_e121059d_000091_c1c9085b>:
  40c540:	push   rsi
  40c541:	push   rdi
  40c542:	push   r12
  40c544:	push   r13
  40c546:	push   r14
  40c548:	push   r15
  40c54a:	sub    rsp,0x78
  40c54e:	mov    rsi,r10
  40c551:	mov    QWORD PTR [rsp+0x68],r10
  40c556:	mov    rdi,rcx
  40c559:	mov    r12,rdx
  40c55c:	mov    r13,r8
  40c55f:	mov    r14,r9
  40c562:	xor    r8d,r8d
  40c565:	call   40c660 <__swc_fn_e121059d_000094_63c1827b>
  40c56a:	test   al,al
  40c56c:	je     40c595 <__swc_fn_e121059d_000091_c1c9085b+0x55>
  40c56e:	mov    rcx,r14
  40c571:	mov    rdx,r12
  40c574:	mov    r8,r13
  40c577:	mov    r9,rsi
  40c57a:	call   409760 <__swc_fn_e121059d_000090_23214800>
  40c57f:	test   al,al
  40c581:	je     40c595 <__swc_fn_e121059d_000091_c1c9085b+0x55>
  40c583:	mov    rax,r13
  40c586:	add    rsp,0x78
  40c58a:	pop    r15
  40c58c:	pop    r14
  40c58e:	pop    r13
  40c590:	pop    r12
  40c592:	pop    rdi
  40c593:	pop    rsi
  40c594:	ret
  40c595:	cmp    BYTE PTR [r12+0x2c],0xe
  40c59b:	je     40c5ae <__swc_fn_e121059d_000091_c1c9085b+0x6e>
  40c59d:	xor    eax,eax
  40c59f:	add    rsp,0x78
  40c5a3:	pop    r15
  40c5a5:	pop    r14
  40c5a7:	pop    r13
  40c5a9:	pop    r12
  40c5ab:	pop    rdi
  40c5ac:	pop    rsi
  40c5ad:	ret
  40c5ae:	mov    r15,QWORD PTR [r12+0x98]
  40c5b6:	mov    rax,QWORD PTR [r12+0xa0]
  40c5be:	mov    r12,rax
  40c5c1:	xor    esi,esi
  40c5c3:	test   r12,r12
  40c5c6:	je     40c639 <__swc_fn_e121059d_000091_c1c9085b+0xf9>
  40c5c8:	nop    DWORD PTR [rax+rax*1+0x0]
  40c5d0:	mov    QWORD PTR [rsp+0x70],r12
  40c5d5:	lea    r12,[rsi*8+0x0]
  40c5dd:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  40c5e2:	mov    rcx,rax
  40c5e5:	call   411540 <__swc_fn_e121059d_000086_3953ef98>
  40c5ea:	cmp    BYTE PTR [rax+0x2c],0xe
  40c5ee:	jne    40c624 <__swc_fn_e121059d_000091_c1c9085b+0xe4>
  40c5f0:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  40c5f5:	lea    r8,[r13+rcx*1+0x0]
  40c5fa:	mov    rcx,rdi
  40c5fd:	mov    rdx,rax
  40c600:	mov    r9,r14
  40c603:	mov    r12,QWORD PTR [rsp+0x68]
  40c608:	mov    r10,r12
  40c60b:	call   40c540 <__swc_fn_e121059d_000091_c1c9085b>
  40c610:	test   rax,rax
  40c613:	je     40c624 <__swc_fn_e121059d_000091_c1c9085b+0xe4>
  40c615:	add    rsp,0x78
  40c619:	pop    r15
  40c61b:	pop    r14
  40c61d:	pop    r13
  40c61f:	pop    r12
  40c621:	pop    rdi
  40c622:	pop    rsi
  40c623:	ret
  40c624:	add    rsi,0x1
  40c628:	mov    rax,QWORD PTR [rsp+0x70]
  40c62d:	sub    rax,0x1
  40c631:	mov    r12,rax
  40c634:	test   rax,rax
  40c637:	jne    40c5d0 <__swc_fn_e121059d_000091_c1c9085b+0x90>
  40c639:	xor    eax,eax
  40c63b:	add    rsp,0x78
  40c63f:	pop    r15
  40c641:	pop    r14
  40c643:	pop    r13
  40c645:	pop    r12
  40c647:	pop    rdi
  40c648:	pop    rsi
  40c649:	ret
	...

000000000040c660 <__swc_fn_e121059d_000094_63c1827b>:
  40c660:	push   rbx
  40c661:	push   rsi
  40c662:	push   rdi
  40c663:	push   r12
  40c665:	push   r13
  40c667:	push   r14
  40c669:	push   r15
  40c66b:	sub    rsp,0x120
  40c672:	mov    rbx,r8
  40c675:	mov    rsi,rdx
  40c678:	test   rcx,rcx
  40c67b:	jne    40c69a <__swc_fn_e121059d_000094_63c1827b+0x3a>
  40c67d:	test   rsi,rsi
  40c680:	jne    40c69a <__swc_fn_e121059d_000094_63c1827b+0x3a>
  40c682:	mov    eax,0x1
  40c687:	add    rsp,0x120
  40c68e:	pop    r15
  40c690:	pop    r14
  40c692:	pop    r13
  40c694:	pop    r12
  40c696:	pop    rdi
  40c697:	pop    rsi
  40c698:	pop    rbx
  40c699:	ret
  40c69a:	test   rcx,rcx
  40c69d:	je     40c6a4 <__swc_fn_e121059d_000094_63c1827b+0x44>
  40c69f:	test   rsi,rsi
  40c6a2:	jne    40c6b9 <__swc_fn_e121059d_000094_63c1827b+0x59>
  40c6a4:	xor    eax,eax
  40c6a6:	add    rsp,0x120
  40c6ad:	pop    r15
  40c6af:	pop    r14
  40c6b1:	pop    r13
  40c6b3:	pop    r12
  40c6b5:	pop    rdi
  40c6b6:	pop    rsi
  40c6b7:	pop    rbx
  40c6b8:	ret
  40c6b9:	call   411540 <__swc_fn_e121059d_000086_3953ef98>
  40c6be:	mov    rdi,rax
  40c6c1:	mov    rcx,rsi
  40c6c4:	call   411540 <__swc_fn_e121059d_000086_3953ef98>
  40c6c9:	test   bl,0x1
  40c6cc:	je     40c70a <__swc_fn_e121059d_000094_63c1827b+0xaa>
  40c6ce:	rex cmp BYTE PTR [rdi+0x2c],0x6
  40c6d3:	jne    40c70a <__swc_fn_e121059d_000094_63c1827b+0xaa>
  40c6d5:	mov    ecx,DWORD PTR [rdi+0x28]
  40c6d8:	test   ecx,0x1000
  40c6de:	je     40c70a <__swc_fn_e121059d_000094_63c1827b+0xaa>
  40c6e0:	test   ecx,0x10000
  40c6e6:	je     40c70a <__swc_fn_e121059d_000094_63c1827b+0xaa>
  40c6e8:	mov    rcx,QWORD PTR [rdi+0x40]
  40c6ec:	mov    rdx,rax
  40c6ef:	mov    r8d,ebx
  40c6f2:	call   40c660 <__swc_fn_e121059d_000094_63c1827b>
  40c6f7:	add    rsp,0x120
  40c6fe:	pop    r15
  40c700:	pop    r14
  40c702:	pop    r13
  40c704:	pop    r12
  40c706:	pop    rdi
  40c707:	pop    rsi
  40c708:	pop    rbx
  40c709:	ret
  40c70a:	mov    cl,BYTE PTR [rax+0x2c]
  40c70d:	rex cmp BYTE PTR [rdi+0x2c],cl
  40c711:	jne    40c71b <__swc_fn_e121059d_000094_63c1827b+0xbb>
  40c713:	mov    ecx,DWORD PTR [rax+0x20]
  40c716:	cmp    DWORD PTR [rdi+0x20],ecx
  40c719:	je     40c730 <__swc_fn_e121059d_000094_63c1827b+0xd0>
  40c71b:	xor    eax,eax
  40c71d:	add    rsp,0x120
  40c724:	pop    r15
  40c726:	pop    r14
  40c728:	pop    r13
  40c72a:	pop    r12
  40c72c:	pop    rdi
  40c72d:	pop    rsi
  40c72e:	pop    rbx
  40c72f:	ret
  40c730:	mov    ecx,DWORD PTR [rdi+0x28]
  40c733:	and    ecx,0xffb5ffff
  40c739:	mov    edx,DWORD PTR [rax+0x28]
  40c73c:	and    edx,0xffb5ffff
  40c742:	cmp    ecx,edx
  40c744:	je     40c75b <__swc_fn_e121059d_000094_63c1827b+0xfb>
  40c746:	xor    eax,eax
  40c748:	add    rsp,0x120
  40c74f:	pop    r15
  40c751:	pop    r14
  40c753:	pop    r13
  40c755:	pop    r12
  40c757:	pop    rdi
  40c758:	pop    rsi
  40c759:	pop    rbx
  40c75a:	ret
  40c75b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  40c760:	jne    40c7b5 <__swc_fn_e121059d_000094_63c1827b+0x155>
  40c762:	mov    cl,BYTE PTR [rax+0x40]
  40c765:	rex cmp BYTE PTR [rdi+0x40],cl
  40c769:	je     40c780 <__swc_fn_e121059d_000094_63c1827b+0x120>
  40c76b:	xor    eax,eax
  40c76d:	add    rsp,0x120
  40c774:	pop    r15
  40c776:	pop    r14
  40c778:	pop    r13
  40c77a:	pop    r12
  40c77c:	pop    rdi
  40c77d:	pop    rsi
  40c77e:	pop    rbx
  40c77f:	ret
  40c780:	rex cmp BYTE PTR [rdi+0x40],0xd
  40c785:	je     40c79d <__swc_fn_e121059d_000094_63c1827b+0x13d>
  40c787:	rex cmp BYTE PTR [rdi+0x40],0xf
  40c78c:	sete   cl
  40c78f:	je     40c799 <__swc_fn_e121059d_000094_63c1827b+0x139>
  40c791:	rex cmp BYTE PTR [rdi+0x40],0xe
  40c796:	sete   cl
  40c799:	test   cl,cl
  40c79b:	je     40c7b5 <__swc_fn_e121059d_000094_63c1827b+0x155>
  40c79d:	mov    eax,0x1
  40c7a2:	add    rsp,0x120
  40c7a9:	pop    r15
  40c7ab:	pop    r14
  40c7ad:	pop    r13
  40c7af:	pop    r12
  40c7b1:	pop    rdi
  40c7b2:	pop    rsi
  40c7b3:	pop    rbx
  40c7b4:	ret
  40c7b5:	test   DWORD PTR [rdi+0x28],0x200200
  40c7bc:	je     40c96f <__swc_fn_e121059d_000094_63c1827b+0x30f>
  40c7c2:	mov    rsi,QWORD PTR [rdi+0x88]
  40c7c9:	mov    rdi,QWORD PTR [rdi+0x90]
  40c7d0:	mov    r12,QWORD PTR [rax+0x88]
  40c7d7:	mov    rax,QWORD PTR [rax+0x90]
  40c7de:	cmp    rdi,rax
  40c7e1:	je     40c7f8 <__swc_fn_e121059d_000094_63c1827b+0x198>
  40c7e3:	xor    eax,eax
  40c7e5:	add    rsp,0x120
  40c7ec:	pop    r15
  40c7ee:	pop    r14
  40c7f0:	pop    r13
  40c7f2:	pop    r12
  40c7f4:	pop    rdi
  40c7f5:	pop    rsi
  40c7f6:	pop    rbx
  40c7f7:	ret
  40c7f8:	test   rsi,rsi
  40c7fb:	je     40c802 <__swc_fn_e121059d_000094_63c1827b+0x1a2>
  40c7fd:	test   r12,r12
  40c800:	jne    40c81a <__swc_fn_e121059d_000094_63c1827b+0x1ba>
  40c802:	mov    eax,0x1
  40c807:	add    rsp,0x120
  40c80e:	pop    r15
  40c810:	pop    r14
  40c812:	pop    r13
  40c814:	pop    r12
  40c816:	pop    rdi
  40c817:	pop    rsi
  40c818:	pop    rbx
  40c819:	ret
  40c81a:	xor    r13d,r13d
  40c81d:	test   rdi,rdi
  40c820:	jbe    40c957 <__swc_fn_e121059d_000094_63c1827b+0x2f7>
  40c826:	lea    r14,[rsp+0x78]
  40c82b:	lea    r15,[rsp+0xb8]
  40c833:	cs nop WORD PTR [rax+rax*1+0x0]
  40c83d:	cs nop WORD PTR [rax+rax*1+0x0]
  40c847:	nop    WORD PTR [rax+rax*1+0x0]
  40c850:	lea    rax,[r13*8+0x0]
  40c858:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40c85d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40c863:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  40c869:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40c872:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  40c878:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40c881:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  40c887:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40c890:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  40c896:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40c89f:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  40c8a6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  40c8af:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  40c8b6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  40c8bf:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  40c8c6:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40c8cf:	xor    al,al
  40c8d1:	rex test BYTE PTR [rsp+0xb0],0x1
  40c8da:	je     40c8e1 <__swc_fn_e121059d_000094_63c1827b+0x281>
  40c8dc:	mov    eax,0x1
  40c8e1:	rex test BYTE PTR [rsp+0xf0],0x1
  40c8ea:	je     40c8f1 <__swc_fn_e121059d_000094_63c1827b+0x291>
  40c8ec:	mov    eax,0x1
  40c8f1:	test   al,al
  40c8f3:	jne    40c919 <__swc_fn_e121059d_000094_63c1827b+0x2b9>
  40c8f5:	mov    rcx,r14
  40c8f8:	mov    rdx,r15
  40c8fb:	call   412650 <__swc_fn_e121059d_000152_6fb05988>
  40c900:	test   al,al
  40c902:	jne    40c919 <__swc_fn_e121059d_000094_63c1827b+0x2b9>
  40c904:	xor    eax,eax
  40c906:	add    rsp,0x120
  40c90d:	pop    r15
  40c90f:	pop    r14
  40c911:	pop    r13
  40c913:	pop    r12
  40c915:	pop    rdi
  40c916:	pop    rsi
  40c917:	pop    rbx
  40c918:	ret
  40c919:	mov    rcx,QWORD PTR [rsp+0x88]
  40c921:	mov    rdx,QWORD PTR [rsp+0xc8]
  40c929:	mov    r8d,ebx
  40c92c:	call   40c660 <__swc_fn_e121059d_000094_63c1827b>
  40c931:	test   al,al
  40c933:	jne    40c94a <__swc_fn_e121059d_000094_63c1827b+0x2ea>
  40c935:	xor    eax,eax
  40c937:	add    rsp,0x120
  40c93e:	pop    r15
  40c940:	pop    r14
  40c942:	pop    r13
  40c944:	pop    r12
  40c946:	pop    rdi
  40c947:	pop    rsi
  40c948:	pop    rbx
  40c949:	ret
  40c94a:	add    r13,0x1
  40c94e:	cmp    r13,rdi
  40c951:	jb     40c850 <__swc_fn_e121059d_000094_63c1827b+0x1f0>
  40c957:	mov    eax,0x1
  40c95c:	add    rsp,0x120
  40c963:	pop    r15
  40c965:	pop    r14
  40c967:	pop    r13
  40c969:	pop    r12
  40c96b:	pop    rdi
  40c96c:	pop    rsi
  40c96d:	pop    rbx
  40c96e:	ret
  40c96f:	test   bl,0x2
  40c972:	je     40c994 <__swc_fn_e121059d_000094_63c1827b+0x334>
  40c974:	lea    rcx,[rdi+0x10]
  40c978:	lea    rdx,[rax+0x10]
  40c97c:	call   412650 <__swc_fn_e121059d_000152_6fb05988>
  40c981:	add    rsp,0x120
  40c988:	pop    r15
  40c98a:	pop    r14
  40c98c:	pop    r13
  40c98e:	pop    r12
  40c990:	pop    rdi
  40c991:	pop    rsi
  40c992:	pop    rbx
  40c993:	ret
  40c994:	mov    rcx,rdi
  40c997:	mov    rdx,rax
  40c99a:	call   412650 <__swc_fn_e121059d_000152_6fb05988>
  40c99f:	add    rsp,0x120
  40c9a6:	pop    r15
  40c9a8:	pop    r14
  40c9aa:	pop    r13
  40c9ac:	pop    r12
  40c9ae:	pop    rdi
  40c9af:	pop    rsi
  40c9b0:	pop    rbx
  40c9b1:	ret
	...

000000000040c9c0 <__swc_fn_e121059d_000097_4185993f>:
  40c9c0:	push   rbx
  40c9c1:	mov    rbx,rcx
  40c9c4:	call   411670 <__swc_fn_e121059d_000095_ad13d15c>
  40c9c9:	movzx  r11d,al
  40c9cd:	mov    r8b,r11b
  40c9d0:	test   r8b,r8b
  40c9d3:	jne    40c9ed <__swc_fn_e121059d_000097_4185993f+0x2d>
  40c9d5:	mov    r11d,0x1
  40c9db:	mov    r10,rbx
  40c9de:	mov    r9,r11
  40c9e1:	and    r10,r11
  40c9e4:	test   r10,r10
  40c9e7:	setne  dl
  40c9ea:	mov    r8b,dl
  40c9ed:	mov    r10b,r8b
  40c9f0:	test   r10b,r10b
  40c9f3:	je     40c9f7 <__swc_fn_e121059d_000097_4185993f+0x37>
  40c9f5:	pop    rbx
  40c9f6:	ret
  40c9f7:	call   40de00 <__swc_fn_e121059d_000142_519fdf94>
  40c9fc:	movzx  r10d,al
  40ca00:	test   r10b,r10b
  40ca03:	je     40ca07 <__swc_fn_e121059d_000097_4185993f+0x47>
  40ca05:	pop    rbx
  40ca06:	ret
  40ca07:	lea    r10,[rip+0x699a]        # 4133a8 <__swc_rdata_base_e121059d+0x298>
  40ca0e:	mov    rax,r10
  40ca11:	mov    rcx,rax
  40ca14:	call   40d930 <__swc_fn_e121059d_000121_2648f149>
  40ca19:	call   40a620 <__swc_fn_e121059d_000123_be2e2f68>
  40ca1e:	pop    rbx
  40ca1f:	ret

000000000040ca20 <__swc_fn_e121059d_000100_d4bdcaa4>:
  40ca20:	push   rbx
  40ca21:	sub    rsp,0x70
  40ca25:	vxorps xmm0,xmm0,xmm0
  40ca29:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40ca2f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40ca35:	vzeroupper
  40ca38:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40ca3e:	mov    QWORD PTR [rsp+0x48],rdx
  40ca43:	mov    rax,r8
  40ca46:	cmp    r8,0x1
  40ca4a:	mov    edx,0x1
  40ca4f:	cmovb  rax,rdx
  40ca53:	mov    QWORD PTR [rsp+0x50],rax
  40ca58:	mov    rbx,QWORD PTR [rcx+0x8]
  40ca5c:	mov    rbx,QWORD PTR [rbx+0x18]
  40ca60:	mov    rcx,QWORD PTR [rcx]
  40ca63:	lea    rdx,[rsp+0x8]
  40ca68:	call   rbx
  40ca6a:	add    rsp,0x70
  40ca6e:	pop    rbx
  40ca6f:	ret

000000000040ca70 <__swc_fn_e121059d_000103_2fdd2c61>:
  40ca70:	push   rbx
  40ca71:	push   rsi
  40ca72:	push   rdi
  40ca73:	sub    rsp,0x30
  40ca77:	mov    rbx,rcx
  40ca7a:	test   rcx,rcx
  40ca7d:	je     40ca92 <__swc_fn_e121059d_000103_2fdd2c61+0x22>
  40ca7f:	mov    rcx,rbx
  40ca82:	mov    edx,0x1
  40ca87:	call   40c2c0 <__swc_fn_e121059d_000082_63a67586>
  40ca8c:	cmp    rax,0x1
  40ca90:	je     40ca9a <__swc_fn_e121059d_000103_2fdd2c61+0x2a>
  40ca92:	add    rsp,0x30
  40ca96:	pop    rdi
  40ca97:	pop    rsi
  40ca98:	pop    rbx
  40ca99:	ret
  40ca9a:	lea    rsi,[rsp+0x8]
  40ca9f:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40caa4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40caaa:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  40caaf:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40cab5:	mov    rax,QWORD PTR [rsp+0x20]
  40caba:	test   rax,rax
  40cabd:	je     40cad3 <__swc_fn_e121059d_000103_2fdd2c61+0x63>
  40cabf:	test   DWORD PTR [rax+0x28],0x400000
  40cac6:	je     40cad3 <__swc_fn_e121059d_000103_2fdd2c61+0x63>
  40cac8:	mov    rcx,QWORD PTR [rax+0x30]
  40cacc:	test   rcx,rcx
  40cacf:	cmovne rax,rcx
  40cad3:	mov    edi,DWORD PTR [rax+0x20]
  40cad6:	lea    rcx,[rsp+0x18]
  40cadb:	call   411850 <__swc_fn_e121059d_000104_3c3b96fb>
  40cae0:	mov    rcx,rsi
  40cae3:	mov    rdx,QWORD PTR [rsp+0x18]
  40cae8:	mov    r8,rdi
  40caeb:	call   40ca20 <__swc_fn_e121059d_000100_d4bdcaa4>
  40caf0:	mov    rcx,QWORD PTR [rbx+0x28]
  40caf4:	call   409d40 <__swc_fn_e121059d_000102_e34f54dc>
  40caf9:	mov    rcx,rsi
  40cafc:	mov    rdx,rbx
  40caff:	mov    r8d,0x30
  40cb05:	call   40ca20 <__swc_fn_e121059d_000100_d4bdcaa4>
  40cb0a:	add    rsp,0x30
  40cb0e:	pop    rdi
  40cb0f:	pop    rsi
  40cb10:	pop    rbx
  40cb11:	ret
	...

000000000040cb20 <__swc_fn_e121059d_000106_ffe51047>:
  40cb20:	push   rbp
  40cb21:	push   rbx
  40cb22:	push   rsi
  40cb23:	push   rdi
  40cb24:	push   r12
  40cb26:	push   r13
  40cb28:	push   r14
  40cb2a:	push   r15
  40cb2c:	sub    rsp,0x500
  40cb33:	mov    rbp,rsp
  40cb36:	mov    rbx,rsp
  40cb39:	mov    rsi,rdx
  40cb3c:	mov    rdi,rcx
  40cb3f:	mov    rcx,QWORD PTR [rip+0x174fa]        # 424040 <__swc_bss_base_e121059d>
  40cb46:	test   rcx,rcx
  40cb49:	jne    40cb63 <__swc_fn_e121059d_000106_ffe51047+0x43>
  40cb4b:	sub    rsp,0x8
  40cb4f:	call   412a40 <__swc_fn_e121059d_000170_994c8876>
  40cb54:	add    rsp,0x8
  40cb58:	lea    rcx,[rax+0x1]
  40cb5c:	mov    QWORD PTR [rip+0x174dd],rcx        # 424040 <__swc_bss_base_e121059d>
  40cb63:	dec    rcx
  40cb66:	sub    rsp,0x8
  40cb6a:	call   40f6e0 <__swc_fn_e121059d_000172_360af05d>
  40cb6f:	add    rsp,0x8
  40cb73:	mov    r12,rax
  40cb76:	mov    QWORD PTR [rsp+0x4f0],rax
  40cb7e:	lea    rax,[rip+0x6963]        # 4134e8 <__swc_rdata_base_e121059d+0x3d8>
  40cb85:	sub    rsp,0x20
  40cb89:	mov    rcx,rsp
  40cb8c:	mov    QWORD PTR [rcx],rax
  40cb8f:	lea    r13,[rip+0x661a]        # 4131b0 <__swc_rdata_base_e121059d+0xa0>
  40cb96:	mov    QWORD PTR [rcx+0x8],r13
  40cb9a:	mov    QWORD PTR [rcx+0x10],rsp
  40cb9e:	mov    QWORD PTR [rcx+0x18],0x1
  40cba6:	lea    rcx,[rsp+0x10]
  40cbab:	sub    rsp,0x8
  40cbaf:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40cbb4:	add    rsp,0x8
  40cbb8:	add    rsp,0x20
  40cbbc:	lea    rax,[rip+0x6935]        # 4134f8 <__swc_rdata_base_e121059d+0x3e8>
  40cbc3:	sub    rsp,0x20
  40cbc7:	mov    rcx,rsp
  40cbca:	mov    QWORD PTR [rcx],rax
  40cbcd:	mov    QWORD PTR [rcx+0x8],r13
  40cbd1:	mov    QWORD PTR [rcx+0x10],rsp
  40cbd5:	mov    QWORD PTR [rcx+0x18],0x1
  40cbdd:	lea    rcx,[rsp+0x10]
  40cbe2:	sub    rsp,0x8
  40cbe6:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40cbeb:	add    rsp,0x8
  40cbef:	add    rsp,0x20
  40cbf3:	lea    r14,[rip+0x65a6]        # 4131a0 <__swc_rdata_base_e121059d+0x90>
  40cbfa:	sub    rsp,0x50
  40cbfe:	mov    rax,rsp
  40cc01:	vmovups xmm0,XMMWORD PTR [rip+0x6a27]        # 413630 <__swc_rdata_base_e121059d+0x520>
  40cc09:	vmovups XMMWORD PTR [rax],xmm0
  40cc0d:	mov    QWORD PTR [rax+0x10],rsp
  40cc11:	mov    QWORD PTR [rax+0x18],r13
  40cc15:	mov    QWORD PTR [rax+0x20],rdi
  40cc19:	lea    rdi,[rip+0x68e8]        # 413508 <__swc_rdata_base_e121059d+0x3f8>
  40cc20:	mov    QWORD PTR [rax+0x28],rdi
  40cc24:	mov    QWORD PTR [rax+0x30],r14
  40cc28:	mov    QWORD PTR [rax+0x38],r13
  40cc2c:	lea    rcx,[rsp+0x10]
  40cc31:	mov    QWORD PTR [rax+0x40],rcx
  40cc35:	mov    QWORD PTR [rax+0x48],0x3
  40cc3d:	lea    rcx,[rsp+0x40]
  40cc42:	sub    rsp,0x8
  40cc46:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40cc4b:	add    rsp,0x8
  40cc4f:	add    rsp,0x50
  40cc53:	lea    rax,[rip+0x68f6]        # 413550 <__swc_rdata_base_e121059d+0x440>
  40cc5a:	sub    rsp,0x20
  40cc5e:	mov    rcx,rsp
  40cc61:	mov    QWORD PTR [rcx],rax
  40cc64:	mov    QWORD PTR [rcx+0x8],r13
  40cc68:	mov    QWORD PTR [rcx+0x10],rsp
  40cc6c:	mov    QWORD PTR [rcx+0x18],0x1
  40cc74:	lea    rcx,[rsp+0x10]
  40cc79:	sub    rsp,0x8
  40cc7d:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40cc82:	add    rsp,0x8
  40cc86:	add    rsp,0x20
  40cc8a:	mov    eax,DWORD PTR [rsi+0x20]
  40cc8d:	mov    ecx,DWORD PTR [rsi+0x24]
  40cc90:	sub    rsp,0xa0
  40cc97:	mov    rdx,rsp
  40cc9a:	mov    QWORD PTR [rdx+0x30],rsi
  40cc9e:	mov    QWORD PTR [rdx+0x38],rdi
  40cca2:	vmovups xmm0,XMMWORD PTR [rip+0x691e]        # 4135c8 <__swc_rdata_base_e121059d+0x4b8>
  40ccaa:	vmovups XMMWORD PTR [rdx],xmm0
  40ccae:	mov    QWORD PTR [rdx+0x40],rsp
  40ccb2:	mov    QWORD PTR [rdx+0x48],r13
  40ccb6:	mov    DWORD PTR [rdx+0x10],eax
  40ccb9:	lea    rax,[rsp+0x10]
  40ccbe:	mov    QWORD PTR [rdx+0x50],rax
  40ccc2:	lea    rax,[rip+0x6897]        # 413560 <__swc_rdata_base_e121059d+0x450>
  40ccc9:	mov    QWORD PTR [rdx+0x58],rax
  40cccd:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  40ccd2:	lea    r8,[rsp+0x18]
  40ccd7:	mov    QWORD PTR [rdx+0x60],r8
  40ccdb:	mov    QWORD PTR [rdx+0x68],r13
  40ccdf:	mov    DWORD PTR [rdx+0x28],ecx
  40cce2:	lea    rcx,[rdx+0x28]
  40cce6:	mov    QWORD PTR [rdx+0x70],rcx
  40ccea:	mov    QWORD PTR [rdx+0x78],rax
  40ccee:	mov    QWORD PTR [rdx+0x80],r14
  40ccf5:	mov    QWORD PTR [rdx+0x88],r13
  40ccfc:	lea    rax,[rdx+0x30]
  40cd00:	mov    QWORD PTR [rdx+0x90],rax
  40cd07:	mov    QWORD PTR [rdx+0x98],0x6
  40cd12:	lea    rcx,[rdx+0x90]
  40cd19:	sub    rsp,0x8
  40cd1d:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40cd22:	add    rsp,0x8
  40cd26:	add    rsp,0xa0
  40cd2d:	sub    rsp,0x20
  40cd31:	mov    rax,rsp
  40cd34:	mov    QWORD PTR [rax],r14
  40cd37:	mov    QWORD PTR [rax+0x8],r13
  40cd3b:	mov    QWORD PTR [rax+0x10],rsp
  40cd3f:	mov    QWORD PTR [rax+0x18],0x1
  40cd47:	lea    rcx,[rsp+0x10]
  40cd4c:	sub    rsp,0x8
  40cd50:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40cd55:	add    rsp,0x8
  40cd59:	add    rsp,0x20
  40cd5d:	mov    eax,DWORD PTR [r12+0x9ac]
  40cd65:	test   eax,eax
  40cd67:	je     40cfa0 <__swc_fn_e121059d_000106_ffe51047+0x480>
  40cd6d:	lea    rax,[rip+0x6834]        # 4135a8 <__swc_rdata_base_e121059d+0x498>
  40cd74:	sub    rsp,0x20
  40cd78:	mov    rcx,rsp
  40cd7b:	mov    QWORD PTR [rcx],rax
  40cd7e:	mov    QWORD PTR [rcx+0x8],r13
  40cd82:	mov    QWORD PTR [rcx+0x10],rsp
  40cd86:	mov    QWORD PTR [rcx+0x18],0x1
  40cd8e:	lea    rcx,[rsp+0x10]
  40cd93:	sub    rsp,0x8
  40cd97:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40cd9c:	add    rsp,0x8
  40cda0:	add    rsp,0x20
  40cda4:	mov    eax,DWORD PTR [r12+0x9ac]
  40cdac:	dec    eax
  40cdae:	mov    esi,eax
  40cdb0:	test   esi,esi
  40cdb2:	jl     40cf70 <__swc_fn_e121059d_000106_ffe51047+0x450>
  40cdb8:	jmp    40cdc4 <__swc_fn_e121059d_000106_ffe51047+0x2a4>
  40cdba:	nop    WORD PTR [rax+rax*1+0x0]
  40cdc0:	dec    esi
  40cdc2:	jmp    40cdb0 <__swc_fn_e121059d_000106_ffe51047+0x290>
  40cdc4:	lea    rax,[rip+0x67ed]        # 4135b8 <__swc_rdata_base_e121059d+0x4a8>
  40cdcb:	sub    rsp,0x20
  40cdcf:	mov    rcx,rsp
  40cdd2:	mov    QWORD PTR [rcx],rax
  40cdd5:	mov    QWORD PTR [rcx+0x8],r13
  40cdd9:	mov    QWORD PTR [rcx+0x10],rsp
  40cddd:	mov    QWORD PTR [rcx+0x18],0x1
  40cde5:	lea    rcx,[rsp+0x10]
  40cdea:	sub    rsp,0x8
  40cdee:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40cdf3:	add    rsp,0x8
  40cdf7:	add    rsp,0x20
  40cdfb:	movsxd rax,esi
  40cdfe:	imul   r15,rax,0x30
  40ce02:	add    r15,r12
  40ce05:	add    r15,0xf8
  40ce0c:	sub    rsp,0x20
  40ce10:	mov    rax,rsp
  40ce13:	mov    QWORD PTR [rax],r15
  40ce16:	mov    QWORD PTR [rax+0x8],rdi
  40ce1a:	mov    QWORD PTR [rax+0x10],rsp
  40ce1e:	mov    QWORD PTR [rax+0x18],0x1
  40ce26:	lea    rcx,[rsp+0x10]
  40ce2b:	sub    rsp,0x8
  40ce2f:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40ce34:	add    rsp,0x8
  40ce38:	add    rsp,0x20
  40ce3c:	mov    QWORD PTR [rsp+0x4f8],rsi
  40ce44:	lea    rsi,[rip+0x677d]        # 4135c8 <__swc_rdata_base_e121059d+0x4b8>
  40ce4b:	sub    rsp,0x20
  40ce4f:	mov    rax,rsp
  40ce52:	mov    QWORD PTR [rax],rsi
  40ce55:	mov    QWORD PTR [rax+0x8],r13
  40ce59:	mov    QWORD PTR [rax+0x10],rsp
  40ce5d:	mov    QWORD PTR [rax+0x18],0x1
  40ce65:	lea    rcx,[rsp+0x10]
  40ce6a:	sub    rsp,0x8
  40ce6e:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40ce73:	add    rsp,0x8
  40ce77:	add    rsp,0x20
  40ce7b:	sub    rsp,0x30
  40ce7f:	mov    rax,rsp
  40ce82:	mov    ecx,DWORD PTR [r15+0x20]
  40ce86:	mov    QWORD PTR [rax],rcx
  40ce89:	mov    QWORD PTR [rax+0x8],rsp
  40ce8d:	lea    rdi,[rip+0x6744]        # 4135d8 <__swc_rdata_base_e121059d+0x4c8>
  40ce94:	mov    QWORD PTR [rax+0x10],rdi
  40ce98:	lea    rcx,[rsp+0x8]
  40ce9d:	mov    QWORD PTR [rax+0x18],rcx
  40cea1:	mov    QWORD PTR [rax+0x20],0x1
  40cea9:	lea    rcx,[rsp+0x18]
  40ceae:	sub    rsp,0x8
  40ceb2:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40ceb7:	add    rsp,0x8
  40cebb:	add    rsp,0x30
  40cebf:	sub    rsp,0x20
  40cec3:	mov    rax,rsp
  40cec6:	mov    QWORD PTR [rax],rsi
  40cec9:	mov    QWORD PTR [rax+0x8],r13
  40cecd:	mov    QWORD PTR [rax+0x10],rsp
  40ced1:	mov    QWORD PTR [rax+0x18],0x1
  40ced9:	lea    rcx,[rsp+0x10]
  40cede:	sub    rsp,0x8
  40cee2:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40cee7:	add    rsp,0x8
  40ceeb:	add    rsp,0x20
  40ceef:	sub    rsp,0x30
  40cef3:	mov    rax,rsp
  40cef6:	mov    ecx,DWORD PTR [r15+0x24]
  40cefa:	mov    QWORD PTR [rax],rcx
  40cefd:	mov    QWORD PTR [rax+0x8],rsp
  40cf01:	mov    QWORD PTR [rax+0x10],rdi
  40cf05:	lea    rcx,[rsp+0x8]
  40cf0a:	mov    QWORD PTR [rax+0x18],rcx
  40cf0e:	mov    QWORD PTR [rax+0x20],0x1
  40cf16:	lea    rcx,[rsp+0x18]
  40cf1b:	sub    rsp,0x8
  40cf1f:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40cf24:	add    rsp,0x8
  40cf28:	add    rsp,0x30
  40cf2c:	sub    rsp,0x20
  40cf30:	mov    rax,rsp
  40cf33:	mov    QWORD PTR [rax],r14
  40cf36:	mov    QWORD PTR [rax+0x8],r13
  40cf3a:	mov    QWORD PTR [rax+0x10],rsp
  40cf3e:	mov    QWORD PTR [rax+0x18],0x1
  40cf46:	lea    rcx,[rsp+0x10]
  40cf4b:	sub    rsp,0x8
  40cf4f:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40cf54:	add    rsp,0x8
  40cf58:	add    rsp,0x20
  40cf5c:	lea    rdi,[rip+0x65a5]        # 413508 <__swc_rdata_base_e121059d+0x3f8>
  40cf63:	mov    rsi,QWORD PTR [rsp+0x4f8]
  40cf6b:	jmp    40cdc0 <__swc_fn_e121059d_000106_ffe51047+0x2a0>
  40cf70:	sub    rsp,0x20
  40cf74:	mov    rax,rsp
  40cf77:	mov    QWORD PTR [rax],r14
  40cf7a:	mov    QWORD PTR [rax+0x8],r13
  40cf7e:	mov    QWORD PTR [rax+0x10],rsp
  40cf82:	mov    QWORD PTR [rax+0x18],0x1
  40cf8a:	lea    rcx,[rsp+0x10]
  40cf8f:	sub    rsp,0x8
  40cf93:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40cf98:	add    rsp,0x8
  40cf9c:	add    rsp,0x20
  40cfa0:	lea    rax,[rbx+0x28]
  40cfa4:	mov    rcx,rax
  40cfa7:	mov    QWORD PTR [rbx+0x28],0x0
  40cfaf:	mov    QWORD PTR [rbx+0x30],0x0
  40cfb7:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  40cfbc:	add    rcx,0x10
  40cfc0:	mov    edx,0x1f
  40cfc5:	cs nop WORD PTR [rax+rax*1+0x0]
  40cfcf:	nop
  40cfd0:	vmovups XMMWORD PTR [rcx],xmm0
  40cfd4:	add    rcx,0x10
  40cfd8:	sub    rdx,0x1
  40cfdc:	jne    40cfd0 <__swc_fn_e121059d_000106_ffe51047+0x4b0>
  40cfde:	lea    rsi,[rbx+0x228]
  40cfe5:	xor    ecx,ecx
  40cfe7:	cs nop WORD PTR [rax+rax*1+0x0]
  40cff1:	cs nop WORD PTR [rax+rax*1+0x0]
  40cffb:	nop    DWORD PTR [rax+rax*1+0x0]
  40d000:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  40d005:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  40d00a:	add    rcx,0x10
  40d00e:	cmp    rcx,0x200
  40d015:	jne    40d000 <__swc_fn_e121059d_000106_ffe51047+0x4e0>
  40d017:	mov    eax,DWORD PTR [r12+0xbc8]
  40d01f:	lea    rcx,[r12+0x9c8]
  40d027:	mov    QWORD PTR [rbx+0x428],rcx
  40d02e:	mov    QWORD PTR [rbx+0x430],rax
  40d035:	lea    rdi,[rbx+0x438]
  40d03c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  40d044:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  40d04c:	mov    eax,DWORD PTR [r12+0xbc8]
  40d054:	test   eax,eax
  40d056:	jne    40d0a3 <__swc_fn_e121059d_000106_ffe51047+0x583>
  40d058:	lea    rax,[rbx+0x448]
  40d05f:	mov    QWORD PTR [rbx+0x448],rsi
  40d066:	mov    QWORD PTR [rax+0x8],0x40
  40d06e:	mov    ecx,0x1
  40d073:	mov    rdx,rax
  40d076:	sub    rsp,0x8
  40d07a:	call   40da40 <__swc_fn_e121059d_000124_4f256d58>
  40d07f:	add    rsp,0x8
  40d083:	mov    QWORD PTR [rbx+0x460],rsi
  40d08a:	mov    ecx,eax
  40d08c:	mov    QWORD PTR [rbx+0x468],rcx
  40d093:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  40d09b:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  40d0a3:	mov    rsi,QWORD PTR [rbx+0x438]
  40d0aa:	mov    rax,QWORD PTR [rbx+0x440]
  40d0b1:	mov    r15,rax
  40d0b4:	xor    r12d,r12d
  40d0b7:	test   r15,r15
  40d0ba:	je     40d170 <__swc_fn_e121059d_000106_ffe51047+0x650>
  40d0c0:	mov    rax,QWORD PTR [rsi+r12*8]
  40d0c4:	test   rax,rax
  40d0c7:	je     40d0e6 <__swc_fn_e121059d_000106_ffe51047+0x5c6>
  40d0c9:	lea    rcx,[rbx+0x4b8]
  40d0d0:	mov    rdx,rax
  40d0d3:	sub    rsp,0x8
  40d0d7:	call   4127b0 <__swc_fn_e121059d_000167_cc119975>
  40d0dc:	add    rsp,0x8
  40d0e0:	mov    al,BYTE PTR [rax]
  40d0e2:	test   al,al
  40d0e4:	jne    40d0f2 <__swc_fn_e121059d_000106_ffe51047+0x5d2>
  40d0e6:	add    r12,0x1
  40d0ea:	sub    r15,0x1
  40d0ee:	jne    40d0c0 <__swc_fn_e121059d_000106_ffe51047+0x5a0>
  40d0f0:	jmp    40d170 <__swc_fn_e121059d_000106_ffe51047+0x650>
  40d0f2:	lea    rax,[rip+0x6527]        # 413620 <__swc_rdata_base_e121059d+0x510>
  40d0f9:	sub    rsp,0x20
  40d0fd:	mov    rcx,rsp
  40d100:	mov    QWORD PTR [rcx],rax
  40d103:	mov    QWORD PTR [rcx+0x8],r13
  40d107:	mov    QWORD PTR [rcx+0x10],rsp
  40d10b:	mov    QWORD PTR [rcx+0x18],0x1
  40d113:	lea    rcx,[rsp+0x10]
  40d118:	sub    rsp,0x8
  40d11c:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40d121:	add    rsp,0x8
  40d125:	add    rsp,0x20
  40d129:	mov    rcx,rdi
  40d12c:	xor    edx,edx
  40d12e:	mov    al,0x1
  40d130:	mov    r8,rax
  40d133:	sub    rsp,0x8
  40d137:	call   40aec0 <__swc_fn_e121059d_000168_bcc835b8>
  40d13c:	add    rsp,0x8
  40d140:	sub    rsp,0x20
  40d144:	mov    rax,rsp
  40d147:	mov    QWORD PTR [rax],r14
  40d14a:	mov    QWORD PTR [rax+0x8],r13
  40d14e:	mov    QWORD PTR [rax+0x10],rsp
  40d152:	mov    QWORD PTR [rax+0x18],0x1
  40d15a:	lea    rcx,[rsp+0x10]
  40d15f:	sub    rsp,0x8
  40d163:	call   40e1a0 <__swc_fn_e121059d_000151_6203dca2>
  40d168:	add    rsp,0x8
  40d16c:	add    rsp,0x20
  40d170:	mov    r12,QWORD PTR [rsp+0x4f0]
  40d178:	mov    DWORD PTR [r12+0xbc8],0x0
  40d184:	add    rsp,0x500
  40d18b:	pop    r15
  40d18d:	pop    r14
  40d18f:	pop    r13
  40d191:	pop    r12
  40d193:	pop    rdi
  40d194:	pop    rsi
  40d195:	pop    rbx
  40d196:	pop    rbp
  40d197:	ret
	...

000000000040d1a0 <__swc_fn_e121059d_000109_a342ead8>:
  40d1a0:	test   r8,r8
  40d1a3:	jne    40d1a6 <__swc_fn_e121059d_000109_a342ead8+0x6>
  40d1a5:	ret
  40d1a6:	xor    eax,eax
  40d1a8:	movzx  r9d,dl
  40d1ac:	movabs r10,0x101010101010101
  40d1b6:	imul   r9,r10
  40d1ba:	vmovq  xmm0,r9
  40d1bf:	vpshufd xmm0,xmm0,0x44
  40d1c4:	cs nop WORD PTR [rax+rax*1+0x0]
  40d1ce:	xchg   ax,ax
  40d1d0:	mov    r10,r8
  40d1d3:	sub    r10,rax
  40d1d6:	cmp    r10,0x40
  40d1da:	jb     40d1fd <__swc_fn_e121059d_000109_a342ead8+0x5d>
  40d1dc:	lea    r10,[rcx+rax*1]
  40d1e0:	vmovups XMMWORD PTR [r10],xmm0
  40d1e5:	vmovups XMMWORD PTR [r10+0x10],xmm0
  40d1eb:	vmovups XMMWORD PTR [r10+0x20],xmm0
  40d1f1:	vmovups XMMWORD PTR [r10+0x30],xmm0
  40d1f7:	lea    rax,[rax+0x40]
  40d1fb:	jmp    40d1d0 <__swc_fn_e121059d_000109_a342ead8+0x30>
  40d1fd:	nop    DWORD PTR [rax]
  40d200:	mov    r10,r8
  40d203:	sub    r10,rax
  40d206:	cmp    r10,0x10
  40d20a:	jb     40d21b <__swc_fn_e121059d_000109_a342ead8+0x7b>
  40d20c:	lea    r10,[rcx+rax*1]
  40d210:	vmovups XMMWORD PTR [r10],xmm0
  40d215:	lea    rax,[rax+0x10]
  40d219:	jmp    40d200 <__swc_fn_e121059d_000109_a342ead8+0x60>
  40d21b:	nop    DWORD PTR [rax+rax*1+0x0]
  40d220:	mov    r10,r8
  40d223:	sub    r10,rax
  40d226:	cmp    r10,0x8
  40d22a:	jb     40d239 <__swc_fn_e121059d_000109_a342ead8+0x99>
  40d22c:	lea    r10,[rcx+rax*1]
  40d230:	mov    QWORD PTR [r10],r9
  40d233:	lea    rax,[rax+0x8]
  40d237:	jmp    40d220 <__swc_fn_e121059d_000109_a342ead8+0x80>
  40d239:	cmp    rax,r8
  40d23c:	jae    40d24b <__swc_fn_e121059d_000109_a342ead8+0xab>
  40d23e:	xchg   ax,ax
  40d240:	mov    BYTE PTR [rcx+rax*1],dl
  40d243:	inc    rax
  40d246:	cmp    rax,r8
  40d249:	jb     40d240 <__swc_fn_e121059d_000109_a342ead8+0xa0>
  40d24b:	ret
  40d24c:	add    BYTE PTR [rax],al
	...

000000000040d250 <__swc_fn_e121059d_000112_6814119b>:
  40d250:	push   rbx
  40d251:	push   r12
  40d253:	push   rdi
  40d254:	push   rsi
  40d255:	push   r13
  40d257:	push   r14
  40d259:	push   r15
  40d25b:	sub    rsp,0x170
  40d262:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40d26b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40d274:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40d27d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40d286:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40d28f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40d298:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40d2a1:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40d2aa:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40d2b3:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40d2bc:	mov    ebx,edx
  40d2be:	mov    QWORD PTR [rsp+0xa8],rbx
  40d2c6:	mov    r12d,ecx
  40d2c9:	test   edx,edx
  40d2cb:	jne    40d2e2 <__swc_fn_e121059d_000112_6814119b+0x92>
  40d2cd:	xor    eax,eax
  40d2cf:	add    rsp,0x170
  40d2d6:	pop    r15
  40d2d8:	pop    r14
  40d2da:	pop    r13
  40d2dc:	pop    rsi
  40d2dd:	pop    rdi
  40d2de:	pop    r12
  40d2e0:	pop    rbx
  40d2e1:	ret
  40d2e2:	lea    rdi,[rip+0x6357]        # 413640 <__swc_rdata_base_e121059d+0x530>
  40d2e9:	mov    esi,0x90000
  40d2ee:	xor    eax,eax
  40d2f0:	call   4070a0 <open@plt>
  40d2f5:	mov    r13,rax
  40d2f8:	mov    QWORD PTR [rsp+0xb0],rax
  40d300:	test   eax,eax
  40d302:	jge    40d30b <__swc_fn_e121059d_000112_6814119b+0xbb>
  40d304:	xor    eax,eax
  40d306:	jmp    40d806 <__swc_fn_e121059d_000112_6814119b+0x5b6>
  40d30b:	nop    DWORD PTR [rax+rax*1+0x0]
  40d310:	movsxd rdi,r13d
  40d313:	mov    esi,0x2
  40d318:	xor    eax,eax
  40d31a:	call   4070b0 <flock@plt>
  40d31f:	test   eax,eax
  40d321:	je     40d340 <__swc_fn_e121059d_000112_6814119b+0xf0>
  40d323:	xor    eax,eax
  40d325:	call   4070c0 <__errno_location@plt>
  40d32a:	cmp    DWORD PTR [rax],0x4
  40d32d:	je     40d310 <__swc_fn_e121059d_000112_6814119b+0xc0>
  40d32f:	movsxd rdi,r13d
  40d332:	xor    eax,eax
  40d334:	call   4070d0 <close@plt>
  40d339:	xor    eax,eax
  40d33b:	jmp    40d806 <__swc_fn_e121059d_000112_6814119b+0x5b6>
  40d340:	lea    r14,[rsp+0x8]
  40d345:	mov    QWORD PTR [rsp+0xb8],r14
  40d34d:	vxorps xmm0,xmm0,xmm0
  40d351:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40d357:	mov    QWORD PTR [rsp+0x18],0x0
  40d360:	mov    WORD PTR [rsp+0x20],0x0
  40d367:	mov    DWORD PTR [r14],0x67617753
  40d36e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40d376:	xor    eax,eax
  40d378:	call   4070e0 <getpid@plt>
  40d37d:	mov    ecx,eax
  40d37f:	mov    eax,0x1c
  40d384:	shrx   eax,ecx,eax
  40d389:	and    eax,0xf
  40d38c:	mov    rdx,QWORD PTR [rip+0x62cd]        # 413660 <__swc_rdata_base_e121059d+0x550>
  40d393:	mov    al,BYTE PTR [rdx+rax*1]
  40d396:	rex mov BYTE PTR [rsp+0x10],al
  40d39b:	mov    eax,0x1c
  40d3a0:	shrx   eax,r12d,eax
  40d3a5:	and    eax,0xf
  40d3a8:	mov    al,BYTE PTR [rdx+rax*1]
  40d3ab:	rex mov BYTE PTR [rsp+0x19],al
  40d3b0:	mov    eax,0x18
  40d3b5:	shrx   eax,ecx,eax
  40d3ba:	and    eax,0xf
  40d3bd:	mov    al,BYTE PTR [rdx+rax*1]
  40d3c0:	rex mov BYTE PTR [rsp+0x11],al
  40d3c5:	mov    eax,0x18
  40d3ca:	shrx   eax,r12d,eax
  40d3cf:	and    eax,0xf
  40d3d2:	mov    al,BYTE PTR [rdx+rax*1]
  40d3d5:	rex mov BYTE PTR [rsp+0x1a],al
  40d3da:	mov    eax,0x14
  40d3df:	shrx   eax,ecx,eax
  40d3e4:	and    eax,0xf
  40d3e7:	mov    al,BYTE PTR [rdx+rax*1]
  40d3ea:	rex mov BYTE PTR [rsp+0x12],al
  40d3ef:	mov    eax,0x14
  40d3f4:	shrx   eax,r12d,eax
  40d3f9:	and    eax,0xf
  40d3fc:	mov    al,BYTE PTR [rdx+rax*1]
  40d3ff:	rex mov BYTE PTR [rsp+0x1b],al
  40d404:	mov    eax,0x10
  40d409:	shrx   eax,ecx,eax
  40d40e:	and    eax,0xf
  40d411:	mov    al,BYTE PTR [rdx+rax*1]
  40d414:	rex mov BYTE PTR [rsp+0x13],al
  40d419:	mov    eax,0x10
  40d41e:	shrx   eax,r12d,eax
  40d423:	and    eax,0xf
  40d426:	mov    al,BYTE PTR [rdx+rax*1]
  40d429:	rex mov BYTE PTR [rsp+0x1c],al
  40d42e:	mov    eax,0xc
  40d433:	shrx   eax,ecx,eax
  40d438:	and    eax,0xf
  40d43b:	mov    al,BYTE PTR [rdx+rax*1]
  40d43e:	rex mov BYTE PTR [rsp+0x14],al
  40d443:	mov    eax,0xc
  40d448:	shrx   eax,r12d,eax
  40d44d:	and    eax,0xf
  40d450:	mov    al,BYTE PTR [rdx+rax*1]
  40d453:	rex mov BYTE PTR [rsp+0x1d],al
  40d458:	mov    eax,0x8
  40d45d:	shrx   eax,ecx,eax
  40d462:	and    eax,0xf
  40d465:	mov    al,BYTE PTR [rdx+rax*1]
  40d468:	rex mov BYTE PTR [rsp+0x15],al
  40d46d:	mov    eax,0x8
  40d472:	shrx   eax,r12d,eax
  40d477:	and    eax,0xf
  40d47a:	mov    al,BYTE PTR [rdx+rax*1]
  40d47d:	rex mov BYTE PTR [rsp+0x1e],al
  40d482:	mov    eax,0x4
  40d487:	shrx   eax,ecx,eax
  40d48c:	and    eax,0xf
  40d48f:	mov    al,BYTE PTR [rdx+rax*1]
  40d492:	rex mov BYTE PTR [rsp+0x16],al
  40d497:	mov    eax,0x4
  40d49c:	shrx   eax,r12d,eax
  40d4a1:	and    eax,0xf
  40d4a4:	mov    al,BYTE PTR [rdx+rax*1]
  40d4a7:	rex mov BYTE PTR [rsp+0x1f],al
  40d4ac:	xor    eax,eax
  40d4ae:	shrx   eax,ecx,eax
  40d4b3:	and    eax,0xf
  40d4b6:	mov    al,BYTE PTR [rdx+rax*1]
  40d4b9:	rex mov BYTE PTR [rsp+0x17],al
  40d4be:	xor    eax,eax
  40d4c0:	shrx   eax,r12d,eax
  40d4c5:	and    eax,0xf
  40d4c8:	mov    al,BYTE PTR [rdx+rax*1]
  40d4cb:	rex mov BYTE PTR [rsp+0x20],al
  40d4d0:	mov    BYTE PTR [r14+0x10],0x2e
  40d4d5:	lea    r12,[rsp+0x22]
  40d4da:	vxorps xmm0,xmm0,xmm0
  40d4de:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40d4e4:	mov    DWORD PTR [r12],0x6d656d2f
  40d4ec:	mov    WORD PTR [r12+0x4],0x6466
  40d4f4:	mov    BYTE PTR [r12+0x6],0x3a
  40d4fa:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40d500:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40d506:	mov    rax,QWORD PTR [rsp+0x18]
  40d50b:	mov    QWORD PTR [rsp+0x39],rax
  40d510:	rex mov al,BYTE PTR [rsp+0x20]
  40d515:	rex mov BYTE PTR [rsp+0x41],al
  40d51a:	mov    DWORD PTR [r12+0x20],0x65642820
  40d523:	mov    DWORD PTR [r12+0x24],0x6574656c
  40d52c:	mov    WORD PTR [r12+0x28],0x2964
  40d534:	lea    rdi,[rip+0x6110]        # 41364b <__swc_rdata_base_e121059d+0x53b>
  40d53b:	xor    eax,eax
  40d53d:	call   4070f0 <opendir@plt>
  40d542:	mov    r15,rax
  40d545:	test   rax,rax
  40d548:	jne    40d55b <__swc_fn_e121059d_000112_6814119b+0x30b>
  40d54a:	movsxd rdi,r13d
  40d54d:	xor    eax,eax
  40d54f:	call   4070d0 <close@plt>
  40d554:	xor    eax,eax
  40d556:	jmp    40d806 <__swc_fn_e121059d_000112_6814119b+0x5b6>
  40d55b:	mov    rdi,r15
  40d55e:	xor    eax,eax
  40d560:	call   407100 <dirfd@plt>
  40d565:	lea    r14,[rsp+0x54]
  40d56a:	mov    DWORD PTR [rsp+0x54],eax
  40d56e:	lea    rbx,[rsp+0x58]
  40d573:	cs nop WORD PTR [rax+rax*1+0x0]
  40d57d:	nop    DWORD PTR [rax]
  40d580:	mov    rdi,r15
  40d583:	xor    eax,eax
  40d585:	call   407110 <readdir@plt>
  40d58a:	test   rax,rax
  40d58d:	jne    40d5a4 <__swc_fn_e121059d_000112_6814119b+0x354>
  40d58f:	mov    r12,QWORD PTR [rsp+0xa8]
  40d597:	mov    r13,QWORD PTR [rsp+0xb0]
  40d59f:	jmp    40d72a <__swc_fn_e121059d_000112_6814119b+0x4da>
  40d5a4:	vxorps xmm0,xmm0,xmm0
  40d5a8:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  40d5ae:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  40d5b4:	vzeroupper
  40d5b7:	lea    r13,[rax+0x13]
  40d5bb:	mov    rax,r14
  40d5be:	movsxd rdi,DWORD PTR [rax]
  40d5c1:	mov    rsi,r13
  40d5c4:	mov    rdx,rbx
  40d5c7:	mov    ecx,0x40
  40d5cc:	xor    eax,eax
  40d5ce:	call   407120 <readlinkat@plt>
  40d5d3:	cmp    rax,0x2a
  40d5d7:	jne    40d580 <__swc_fn_e121059d_000112_6814119b+0x330>
  40d5d9:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40d5df:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40d5e5:	vptest xmm0,xmm0
  40d5ea:	jne    40d61a <__swc_fn_e121059d_000112_6814119b+0x3ca>
  40d5ec:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40d5f2:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40d5f8:	vptest xmm0,xmm0
  40d5fd:	jne    40d61a <__swc_fn_e121059d_000112_6814119b+0x3ca>
  40d5ff:	mov    rcx,QWORD PTR [rsp+0x42]
  40d604:	cmp    QWORD PTR [rsp+0x78],rcx
  40d609:	jne    40d61a <__swc_fn_e121059d_000112_6814119b+0x3ca>
  40d60b:	mov    cx,WORD PTR [rsp+0x4a]
  40d610:	cmp    WORD PTR [rsp+0x80],cx
  40d618:	je     40d644 <__swc_fn_e121059d_000112_6814119b+0x3f4>
  40d61a:	mov    rax,rbx
  40d61d:	mov    rcx,r12
  40d620:	movzx  edx,BYTE PTR [rax]
  40d623:	movzx  r8d,BYTE PTR [rcx]
  40d627:	cmp    rdx,r8
  40d62a:	jne    40d636 <__swc_fn_e121059d_000112_6814119b+0x3e6>
  40d62c:	add    rax,0x1
  40d630:	add    rcx,0x1
  40d634:	jmp    40d620 <__swc_fn_e121059d_000112_6814119b+0x3d0>
  40d636:	mov    rax,rdx
  40d639:	sub    rax,r8
  40d63c:	test   eax,eax
  40d63e:	jne    40d580 <__swc_fn_e121059d_000112_6814119b+0x330>
  40d644:	movsxd rdi,DWORD PTR [r14]
  40d647:	mov    rsi,r13
  40d64a:	mov    edx,0x80002
  40d64f:	xor    eax,eax
  40d651:	call   407130 <openat@plt>
  40d656:	lea    rbx,[rsp+0x98]
  40d65e:	mov    DWORD PTR [rsp+0x98],eax
  40d665:	test   eax,eax
  40d667:	mov    r13,QWORD PTR [rsp+0xb0]
  40d66f:	jge    40d694 <__swc_fn_e121059d_000112_6814119b+0x444>
  40d671:	mov    rdi,r15
  40d674:	xor    eax,eax
  40d676:	call   407140 <closedir@plt>
  40d67b:	mov    r13,QWORD PTR [rsp+0xb0]
  40d683:	movsxd rdi,r13d
  40d686:	xor    eax,eax
  40d688:	call   4070d0 <close@plt>
  40d68d:	xor    eax,eax
  40d68f:	jmp    40d806 <__swc_fn_e121059d_000112_6814119b+0x5b6>
  40d694:	mov    rax,rbx
  40d697:	movsxd rdi,DWORD PTR [rax]
  40d69a:	xor    esi,esi
  40d69c:	mov    edx,0x2
  40d6a1:	xor    eax,eax
  40d6a3:	call   407150 <lseek@plt>
  40d6a8:	mov    r12,QWORD PTR [rsp+0xa8]
  40d6b0:	cmp    rax,r12
  40d6b3:	je     40d6da <__swc_fn_e121059d_000112_6814119b+0x48a>
  40d6b5:	movsxd rdi,DWORD PTR [rbx]
  40d6b8:	xor    eax,eax
  40d6ba:	call   4070d0 <close@plt>
  40d6bf:	mov    rdi,r15
  40d6c2:	xor    eax,eax
  40d6c4:	call   407140 <closedir@plt>
  40d6c9:	movsxd rdi,r13d
  40d6cc:	xor    eax,eax
  40d6ce:	call   4070d0 <close@plt>
  40d6d3:	xor    eax,eax
  40d6d5:	jmp    40d806 <__swc_fn_e121059d_000112_6814119b+0x5b6>
  40d6da:	xor    edi,edi
  40d6dc:	mov    rsi,r12
  40d6df:	mov    edx,0x3
  40d6e4:	mov    ecx,0x1
  40d6e9:	mov    rax,rbx
  40d6ec:	movsxd r8,DWORD PTR [rax]
  40d6ef:	xor    r9d,r9d
  40d6f2:	xor    eax,eax
  40d6f4:	call   407010 <mmap@plt>
  40d6f9:	xor    r12d,r12d
  40d6fc:	cmp    rax,0xffffffffffffffff
  40d700:	cmovne r12,rax
  40d704:	movsxd rdi,DWORD PTR [rbx]
  40d707:	xor    eax,eax
  40d709:	call   4070d0 <close@plt>
  40d70e:	mov    rdi,r15
  40d711:	xor    eax,eax
  40d713:	call   407140 <closedir@plt>
  40d718:	movsxd rdi,r13d
  40d71b:	xor    eax,eax
  40d71d:	call   4070d0 <close@plt>
  40d722:	mov    rax,r12
  40d725:	jmp    40d806 <__swc_fn_e121059d_000112_6814119b+0x5b6>
  40d72a:	mov    r14,QWORD PTR [rsp+0xb8]
  40d732:	mov    rdi,r14
  40d735:	mov    esi,0x1
  40d73a:	xor    eax,eax
  40d73c:	call   407160 <memfd_create@plt>
  40d741:	lea    rbx,[rsp+0x9c]
  40d749:	mov    DWORD PTR [rsp+0x9c],eax
  40d750:	test   eax,eax
  40d752:	jge    40d76f <__swc_fn_e121059d_000112_6814119b+0x51f>
  40d754:	mov    rdi,r15
  40d757:	xor    eax,eax
  40d759:	call   407140 <closedir@plt>
  40d75e:	movsxd rdi,r13d
  40d761:	xor    eax,eax
  40d763:	call   4070d0 <close@plt>
  40d768:	xor    eax,eax
  40d76a:	jmp    40d806 <__swc_fn_e121059d_000112_6814119b+0x5b6>
  40d76f:	mov    rax,rbx
  40d772:	movsxd rdi,DWORD PTR [rax]
  40d775:	mov    rsi,r12
  40d778:	xor    eax,eax
  40d77a:	call   407170 <ftruncate@plt>
  40d77f:	test   eax,eax
  40d781:	je     40d7a5 <__swc_fn_e121059d_000112_6814119b+0x555>
  40d783:	movsxd rdi,DWORD PTR [rbx]
  40d786:	xor    eax,eax
  40d788:	call   4070d0 <close@plt>
  40d78d:	mov    rdi,r15
  40d790:	xor    eax,eax
  40d792:	call   407140 <closedir@plt>
  40d797:	movsxd rdi,r13d
  40d79a:	xor    eax,eax
  40d79c:	call   4070d0 <close@plt>
  40d7a1:	xor    eax,eax
  40d7a3:	jmp    40d806 <__swc_fn_e121059d_000112_6814119b+0x5b6>
  40d7a5:	xor    edi,edi
  40d7a7:	mov    rsi,r12
  40d7aa:	mov    edx,0x3
  40d7af:	mov    ecx,0x1
  40d7b4:	mov    rax,rbx
  40d7b7:	movsxd r8,DWORD PTR [rax]
  40d7ba:	xor    r9d,r9d
  40d7bd:	xor    eax,eax
  40d7bf:	call   407010 <mmap@plt>
  40d7c4:	mov    r12,rax
  40d7c7:	cmp    rax,0xffffffffffffffff
  40d7cb:	jne    40d7ef <__swc_fn_e121059d_000112_6814119b+0x59f>
  40d7cd:	movsxd rdi,DWORD PTR [rbx]
  40d7d0:	xor    eax,eax
  40d7d2:	call   4070d0 <close@plt>
  40d7d7:	mov    rdi,r15
  40d7da:	xor    eax,eax
  40d7dc:	call   407140 <closedir@plt>
  40d7e1:	movsxd rdi,r13d
  40d7e4:	xor    eax,eax
  40d7e6:	call   4070d0 <close@plt>
  40d7eb:	xor    eax,eax
  40d7ed:	jmp    40d806 <__swc_fn_e121059d_000112_6814119b+0x5b6>
  40d7ef:	mov    rdi,r15
  40d7f2:	xor    eax,eax
  40d7f4:	call   407140 <closedir@plt>
  40d7f9:	movsxd rdi,r13d
  40d7fc:	xor    eax,eax
  40d7fe:	call   4070d0 <close@plt>
  40d803:	mov    rax,r12
  40d806:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40d80f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40d818:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40d821:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40d82a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  40d833:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40d83c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  40d845:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40d84e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  40d857:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  40d860:	add    rsp,0x170
  40d867:	pop    r15
  40d869:	pop    r14
  40d86b:	pop    r13
  40d86d:	pop    rsi
  40d86e:	pop    rdi
  40d86f:	pop    r12
  40d871:	pop    rbx
  40d872:	ret
	...

000000000040d880 <__swc_fn_e121059d_000115_5f48311c>:
  40d880:	push   rsi
  40d881:	push   rdi
  40d882:	push   r12
  40d884:	push   r13
  40d886:	sub    rsp,0x8
  40d88a:	mov    rsi,r8
  40d88d:	mov    rdi,rcx
  40d890:	mov    r12,rdx
  40d893:	call   4119a0 <__swc_fn_e121059d_000113_126150d1>
  40d898:	mov    r13,rax
  40d89b:	test   rax,rax
  40d89e:	jne    40d8ab <__swc_fn_e121059d_000115_5f48311c+0x2b>
  40d8a0:	add    rsp,0x8
  40d8a4:	pop    r13
  40d8a6:	pop    r12
  40d8a8:	pop    rdi
  40d8a9:	pop    rsi
  40d8aa:	ret
  40d8ab:	mov    rcx,r13
  40d8ae:	call   40a9d0 <__swc_fn_e121059d_000138_8c07c14b>
  40d8b3:	mov    rax,QWORD PTR [r13+0x8]
  40d8b7:	test   rax,rax
  40d8ba:	je     40d8f9 <__swc_fn_e121059d_000115_5f48311c+0x79>
  40d8bc:	nop    DWORD PTR [rax+0x0]
  40d8c0:	lea    rcx,[rax+0x1000]
  40d8c7:	cmp    rdi,rcx
  40d8ca:	jne    40d8f1 <__swc_fn_e121059d_000115_5f48311c+0x71>
  40d8cc:	cmp    r12,0x1000
  40d8d3:	jb     40d8f1 <__swc_fn_e121059d_000115_5f48311c+0x71>
  40d8d5:	test   sil,sil
  40d8d8:	setne  cl
  40d8db:	mov    BYTE PTR [rax+0x10],cl
  40d8de:	mov    rcx,r13
  40d8e1:	call   40dde0 <__swc_fn_e121059d_000139_715e84ff>
  40d8e6:	add    rsp,0x8
  40d8ea:	pop    r13
  40d8ec:	pop    r12
  40d8ee:	pop    rdi
  40d8ef:	pop    rsi
  40d8f0:	ret
  40d8f1:	mov    rax,QWORD PTR [rax]
  40d8f4:	test   rax,rax
  40d8f7:	jne    40d8c0 <__swc_fn_e121059d_000115_5f48311c+0x40>
  40d8f9:	mov    rcx,r13
  40d8fc:	call   40dde0 <__swc_fn_e121059d_000139_715e84ff>
  40d901:	add    rsp,0x8
  40d905:	pop    r13
  40d907:	pop    r12
  40d909:	pop    rdi
  40d90a:	pop    rsi
  40d90b:	ret
  40d90c:	add    BYTE PTR [rax],al
	...

000000000040d910 <__swc_fn_e121059d_000118_ed2d8fed>:
  40d910:	sub    rsp,0x8
  40d914:	test   rcx,rcx
  40d917:	jne    40d91e <__swc_fn_e121059d_000118_ed2d8fed+0xe>
  40d919:	add    rsp,0x8
  40d91d:	ret
  40d91e:	call   40a4d0 <__swc_fn_e121059d_000120_d3318640>
  40d923:	add    rsp,0x8
  40d927:	ret
	...

000000000040d930 <__swc_fn_e121059d_000121_2648f149>:
  40d930:	push   r12
  40d932:	push   r13
  40d934:	push   r14
  40d936:	push   rdi
  40d937:	push   rsi
  40d938:	sub    rsp,0xc0
  40d93f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40d945:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40d94b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40d951:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40d957:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40d95d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40d963:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40d969:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40d972:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40d97b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40d984:	mov    r12,QWORD PTR [rcx]
  40d987:	test   r12,r12
  40d98a:	jne    40d99c <__swc_fn_e121059d_000121_2648f149+0x6c>
  40d98c:	add    rsp,0xc0
  40d993:	pop    rsi
  40d994:	pop    rdi
  40d995:	pop    r14
  40d997:	pop    r13
  40d999:	pop    r12
  40d99b:	ret
  40d99c:	xor    r13d,r13d
  40d99f:	mov    r14,QWORD PTR [rcx+0x8]
  40d9a3:	cs nop WORD PTR [rax+rax*1+0x0]
  40d9ad:	nop    DWORD PTR [rax]
  40d9b0:	cmp    r13,r14
  40d9b3:	jae    40d9eb <__swc_fn_e121059d_000121_2648f149+0xbb>
  40d9b5:	lea    rax,[r12+r13*1]
  40d9b9:	mov    rcx,r14
  40d9bc:	sub    rcx,r13
  40d9bf:	mov    edi,0x1
  40d9c4:	mov    rsi,rax
  40d9c7:	mov    rdx,rcx
  40d9ca:	xor    eax,eax
  40d9cc:	call   407180 <write@plt>
  40d9d1:	test   rax,rax
  40d9d4:	jle    40d9db <__swc_fn_e121059d_000121_2648f149+0xab>
  40d9d6:	add    r13,rax
  40d9d9:	jmp    40d9b0 <__swc_fn_e121059d_000121_2648f149+0x80>
  40d9db:	je     40d9e9 <__swc_fn_e121059d_000121_2648f149+0xb9>
  40d9dd:	xor    eax,eax
  40d9df:	call   4070c0 <__errno_location@plt>
  40d9e4:	cmp    DWORD PTR [rax],0x4
  40d9e7:	je     40d9b0 <__swc_fn_e121059d_000121_2648f149+0x80>
  40d9e9:	jmp    40d9eb <__swc_fn_e121059d_000121_2648f149+0xbb>
  40d9eb:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40d9f1:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40d9f7:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40d9fd:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40da03:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40da09:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40da0f:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40da15:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40da1e:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40da27:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40da30:	add    rsp,0xc0
  40da37:	pop    rsi
  40da38:	pop    rdi
  40da39:	pop    r14
  40da3b:	pop    r13
  40da3d:	pop    r12
  40da3f:	ret

000000000040da40 <__swc_fn_e121059d_000124_4f256d58>:
  40da40:	push   rbx
  40da41:	push   r12
  40da43:	push   rdi
  40da44:	push   rsi
  40da45:	sub    rsp,0x4a8
  40da4c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  40da55:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  40da5e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  40da67:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  40da70:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  40da79:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  40da82:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  40da8b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  40da94:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  40da9d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  40daa6:	mov    rbx,rdx
  40daa9:	mov    r12d,ecx
  40daac:	vxorps xmm0,xmm0,xmm0
  40dab0:	xor    eax,eax
  40dab2:	cs nop WORD PTR [rax+rax*1+0x0]
  40dabc:	nop    DWORD PTR [rax+0x0]
  40dac0:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  40dac6:	add    rax,0x10
  40daca:	cmp    rax,0x400
  40dad1:	jne    40dac0 <__swc_fn_e121059d_000124_4f256d58+0x80>
  40dad3:	lea    rdi,[rsp+0x8]
  40dad8:	mov    esi,0x80
  40dadd:	xor    eax,eax
  40dadf:	call   407190 <backtrace@plt>
  40dae4:	test   eax,eax
  40dae6:	jle    40daf5 <__swc_fn_e121059d_000124_4f256d58+0xb5>
  40dae8:	movsxd rax,eax
  40daeb:	lea    rcx,[r12+0x1]
  40daf0:	cmp    rcx,rax
  40daf3:	jb     40daf9 <__swc_fn_e121059d_000124_4f256d58+0xb9>
  40daf5:	xor    eax,eax
  40daf7:	jmp    40db2a <__swc_fn_e121059d_000124_4f256d58+0xea>
  40daf9:	mov    rcx,QWORD PTR [rbx+0x8]
  40dafd:	sub    rax,r12
  40db00:	lea    rsi,[rax-0x1]
  40db04:	cmp    rcx,rsi
  40db07:	cmovbe rsi,rcx
  40db0b:	lea    eax,[r12+0x1]
  40db10:	lea    rax,[rsp+rax*8+0x8]
  40db15:	mov    rcx,QWORD PTR [rbx]
  40db18:	mov    rdx,rax
  40db1b:	lea    r8,[rsi*8+0x0]
  40db23:	call   411980 <__swc_fn_e121059d_000110_7c204aac>
  40db28:	mov    eax,esi
  40db2a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  40db33:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  40db3c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  40db45:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  40db4e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  40db57:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  40db60:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  40db69:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  40db72:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  40db7b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  40db84:	add    rsp,0x4a8
  40db8b:	pop    rsi
  40db8c:	pop    rdi
  40db8d:	pop    r12
  40db8f:	pop    rbx
  40db90:	ret
	...

000000000040dba0 <__swc_fn_e121059d_000127_fcd5a289>:
  40dba0:	mov    QWORD PTR [rcx],0x0
  40dba7:	ret
	...

000000000040dbb0 <__swc_fn_e121059d_000130_4bbe3f14>:
  40dbb0:	push   rdi
  40dbb1:	push   rsi
  40dbb2:	sub    rsp,0xa8
  40dbb9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40dbbf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40dbc5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40dbcb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40dbd1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40dbd7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40dbdd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40dbe3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40dbe9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40dbf2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40dbfb:	mov    edi,ecx
  40dbfd:	mov    rsi,rdx
  40dc00:	xor    eax,eax
  40dc02:	call   4071a0 <pthread_setspecific@plt>
  40dc07:	test   eax,eax
  40dc09:	sete   al
  40dc0c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40dc12:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40dc18:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40dc1e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40dc24:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40dc2a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40dc30:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40dc36:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40dc3c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40dc45:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40dc4e:	add    rsp,0xa8
  40dc55:	pop    rsi
  40dc56:	pop    rdi
  40dc57:	ret
	...

000000000040dc60 <__swc_fn_e121059d_000133_5f757033>:
  40dc60:	push   rdi
  40dc61:	push   rsi
  40dc62:	sub    rsp,0xa8
  40dc69:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40dc6f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40dc75:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40dc7b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40dc81:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40dc87:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40dc8d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40dc93:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40dc99:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40dca2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40dcab:	test   rcx,rcx
  40dcae:	je     40dcc1 <__swc_fn_e121059d_000133_5f757033+0x61>
  40dcb0:	lea    rax,[rcx-0x1]
  40dcb4:	mov    eax,eax
  40dcb6:	mov    edi,eax
  40dcb8:	xor    eax,eax
  40dcba:	call   407000 <pthread_getspecific@plt>
  40dcbf:	jmp    40dcc3 <__swc_fn_e121059d_000133_5f757033+0x63>
  40dcc1:	xor    eax,eax
  40dcc3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40dcc9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40dccf:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40dcd5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40dcdb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40dce1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40dce7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40dced:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40dcf3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40dcfc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40dd05:	add    rsp,0xa8
  40dd0c:	pop    rsi
  40dd0d:	pop    rdi
  40dd0e:	ret
	...

000000000040dd10 <__swc_fn_e121059d_000136_07d76562>:
  40dd10:	push   rdi
  40dd11:	push   rsi
  40dd12:	sub    rsp,0xb8
  40dd19:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40dd1f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40dd25:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40dd2b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40dd31:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40dd37:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40dd3d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40dd43:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40dd4c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40dd55:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40dd5e:	vxorps xmm0,xmm0,xmm0
  40dd62:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dd68:	mov    edi,0x1
  40dd6d:	lea    rsi,[rsp+0x8]
  40dd72:	xor    eax,eax
  40dd74:	call   4071b0 <clock_gettime@plt>
  40dd79:	mov    rax,QWORD PTR [rsp+0x8]
  40dd7e:	imul   rax,rax,0x3b9aca00
  40dd85:	add    rax,QWORD PTR [rsp+0x10]
  40dd8a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40dd90:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40dd96:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40dd9c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40dda2:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40dda8:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ddae:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ddb4:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ddbd:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ddc6:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ddcf:	add    rsp,0xb8
  40ddd6:	pop    rsi
  40ddd7:	pop    rdi
  40ddd8:	ret
  40ddd9:	add    BYTE PTR [rax],al
  40dddb:	add    BYTE PTR [rax],al
  40dddd:	add    BYTE PTR [rax],al
	...

000000000040dde0 <__swc_fn_e121059d_000139_715e84ff>:
  40dde0:	sub    rsp,0x8
  40dde4:	xor    eax,eax
  40dde6:	mov    DWORD PTR [rcx],eax
  40dde8:	mov    edx,0x7fffffff
  40dded:	call   412080 <__swc_fn_e121059d_000137_865f5106>
  40ddf2:	add    rsp,0x8
  40ddf6:	ret
	...

000000000040de00 <__swc_fn_e121059d_000142_519fdf94>:
  40de00:	push   rdi
  40de01:	push   rsi
  40de02:	sub    rsp,0xb8
  40de09:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40de0f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40de15:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40de1b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40de21:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40de27:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40de2d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40de33:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40de3c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40de45:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40de4e:	mov    edi,0x1
  40de53:	xor    eax,eax
  40de55:	call   4071c0 <__x86_get_cpuid_feature_leaf@plt>
  40de5a:	mov    eax,DWORD PTR [rax+0x14]
  40de5d:	and    eax,0x20
  40de60:	setne  al
  40de63:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40de69:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40de6f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40de75:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40de7b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40de81:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40de87:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40de8d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40de96:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40de9f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40dea8:	add    rsp,0xb8
  40deaf:	pop    rsi
  40deb0:	pop    rdi
  40deb1:	ret
	...

000000000040dec0 <__swc_fn_e121059d_000145_d5d4d43f>:
  40dec0:	push   rsi
  40dec1:	push   rdi
  40dec2:	push   r12
  40dec4:	push   r13
  40dec6:	push   r14
  40dec8:	push   r15
  40deca:	cmp    rdx,0x40
  40dece:	jae    40dedd <__swc_fn_e121059d_000145_d5d4d43f+0x1d>
  40ded0:	xor    eax,eax
  40ded2:	pop    r15
  40ded4:	pop    r14
  40ded6:	pop    r13
  40ded8:	pop    r12
  40deda:	pop    rdi
  40dedb:	pop    rsi
  40dedc:	ret
  40dedd:	cmp    BYTE PTR [rcx],0x7f
  40dee0:	jne    40df24 <__swc_fn_e121059d_000145_d5d4d43f+0x64>
  40dee2:	movzx  eax,BYTE PTR [rcx+0x1]
  40dee6:	cmp    eax,0x45
  40dee9:	setne  al
  40deec:	jne    40df20 <__swc_fn_e121059d_000145_d5d4d43f+0x60>
  40deee:	movzx  eax,BYTE PTR [rcx+0x2]
  40def2:	cmp    eax,0x4c
  40def5:	setne  al
  40def8:	jne    40df20 <__swc_fn_e121059d_000145_d5d4d43f+0x60>
  40defa:	movzx  eax,BYTE PTR [rcx+0x3]
  40defe:	cmp    eax,0x46
  40df01:	setne  al
  40df04:	jne    40df20 <__swc_fn_e121059d_000145_d5d4d43f+0x60>
  40df06:	cmp    BYTE PTR [rcx+0x4],0x2
  40df0a:	setne  al
  40df0d:	jne    40df20 <__swc_fn_e121059d_000145_d5d4d43f+0x60>
  40df0f:	cmp    BYTE PTR [rcx+0x5],0x1
  40df13:	setne  al
  40df16:	jne    40df20 <__swc_fn_e121059d_000145_d5d4d43f+0x60>
  40df18:	cmp    WORD PTR [rcx+0x12],0x3e
  40df1d:	setne  al
  40df20:	test   al,al
  40df22:	je     40df31 <__swc_fn_e121059d_000145_d5d4d43f+0x71>
  40df24:	xor    eax,eax
  40df26:	pop    r15
  40df28:	pop    r14
  40df2a:	pop    r13
  40df2c:	pop    r12
  40df2e:	pop    rdi
  40df2f:	pop    rsi
  40df30:	ret
  40df31:	cmp    WORD PTR [rcx+0x3a],0x40
  40df36:	jne    40df51 <__swc_fn_e121059d_000145_d5d4d43f+0x91>
  40df38:	cmp    WORD PTR [rcx+0x3c],0x0
  40df3d:	sete   al
  40df40:	je     40df4d <__swc_fn_e121059d_000145_d5d4d43f+0x8d>
  40df42:	mov    ax,WORD PTR [rcx+0x3c]
  40df46:	cmp    WORD PTR [rcx+0x3e],ax
  40df4a:	setae  al
  40df4d:	test   al,al
  40df4f:	je     40df5e <__swc_fn_e121059d_000145_d5d4d43f+0x9e>
  40df51:	xor    eax,eax
  40df53:	pop    r15
  40df55:	pop    r14
  40df57:	pop    r13
  40df59:	pop    r12
  40df5b:	pop    rdi
  40df5c:	pop    rsi
  40df5d:	ret
  40df5e:	movzx  eax,WORD PTR [rcx+0x3c]
  40df62:	shl    rax,0x6
  40df66:	cmp    rax,rdx
  40df69:	ja     40df77 <__swc_fn_e121059d_000145_d5d4d43f+0xb7>
  40df6b:	mov    r9,rdx
  40df6e:	sub    r9,rax
  40df71:	cmp    QWORD PTR [rcx+0x28],r9
  40df75:	jbe    40df84 <__swc_fn_e121059d_000145_d5d4d43f+0xc4>
  40df77:	xor    eax,eax
  40df79:	pop    r15
  40df7b:	pop    r14
  40df7d:	pop    r13
  40df7f:	pop    r12
  40df81:	pop    rdi
  40df82:	pop    rsi
  40df83:	ret
  40df84:	mov    rax,QWORD PTR [rcx+0x28]
  40df88:	add    rax,rcx
  40df8b:	movzx  r9d,WORD PTR [rcx+0x3e]
  40df90:	lea    r9,[r9*8+0x0]
  40df98:	lea    r10,[rax+r9*8]
  40df9c:	cmp    QWORD PTR [r10+0x20],rdx
  40dfa0:	ja     40dfc2 <__swc_fn_e121059d_000145_d5d4d43f+0x102>
  40dfa2:	mov    r11,rdx
  40dfa5:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  40dfaa:	cmp    QWORD PTR [r10+0x18],r11
  40dfae:	seta   r9b
  40dfb2:	ja     40dfbd <__swc_fn_e121059d_000145_d5d4d43f+0xfd>
  40dfb4:	cmp    QWORD PTR [r10+0x20],0x9
  40dfb9:	setb   r9b
  40dfbd:	test   r9b,r9b
  40dfc0:	je     40dfcf <__swc_fn_e121059d_000145_d5d4d43f+0x10f>
  40dfc2:	xor    eax,eax
  40dfc4:	pop    r15
  40dfc6:	pop    r14
  40dfc8:	pop    r13
  40dfca:	pop    r12
  40dfcc:	pop    rdi
  40dfcd:	pop    rsi
  40dfce:	ret
  40dfcf:	movzx  r9d,WORD PTR [rcx+0x3c]
  40dfd4:	xor    r11d,r11d
  40dfd7:	test   r9,r9
  40dfda:	jbe    40e0d5 <__swc_fn_e121059d_000145_d5d4d43f+0x215>
  40dfe0:	mov    rsi,QWORD PTR [r10+0x20]
  40dfe4:	sub    rsi,0x9
  40dfe8:	cs nop WORD PTR [rax+rax*1+0x0]
  40dff2:	cs nop WORD PTR [rax+rax*1+0x0]
  40dffc:	nop    DWORD PTR [rax+0x0]
  40e000:	movzx  edi,r11w
  40e004:	lea    rdi,[rdi*8+0x0]
  40e00c:	lea    r12,[rax+rdi*8]
  40e010:	rex mov edi,DWORD PTR [rax+rdi*8]
  40e014:	cmp    rdi,rsi
  40e017:	ja     40e0c8 <__swc_fn_e121059d_000145_d5d4d43f+0x208>
  40e01d:	mov    r13,QWORD PTR [r10+0x18]
  40e021:	add    r13,rdi
  40e024:	lea    rdi,[rcx+r13*1]
  40e028:	lea    r13,[rip+0x5691]        # 4136c0 <__swc_rdata_base_e121059d+0x5b0>
  40e02f:	movabs r14,0x676264676177732e
  40e039:	cmp    QWORD PTR [rdi],r14
  40e03c:	jne    40e045 <__swc_fn_e121059d_000145_d5d4d43f+0x185>
  40e03e:	rex cmp BYTE PTR [rdi+0x8],0x0
  40e043:	je     40e072 <__swc_fn_e121059d_000145_d5d4d43f+0x1b2>
  40e045:	cs nop WORD PTR [rax+rax*1+0x0]
  40e04f:	nop
  40e050:	movzx  r14d,BYTE PTR [rdi]
  40e054:	movzx  r15d,BYTE PTR [r13+0x0]
  40e059:	cmp    r14,r15
  40e05c:	jne    40e068 <__swc_fn_e121059d_000145_d5d4d43f+0x1a8>
  40e05e:	add    rdi,0x1
  40e062:	add    r13,0x1
  40e066:	jmp    40e050 <__swc_fn_e121059d_000145_d5d4d43f+0x190>
  40e068:	mov    rdi,r14
  40e06b:	sub    rdi,r15
  40e06e:	test   edi,edi
  40e070:	jne    40e0c8 <__swc_fn_e121059d_000145_d5d4d43f+0x208>
  40e072:	cmp    DWORD PTR [r12+0x4],0x1
  40e078:	jne    40e0a0 <__swc_fn_e121059d_000145_d5d4d43f+0x1e0>
  40e07a:	cmp    QWORD PTR [r12+0x20],0x10
  40e080:	setb   al
  40e083:	jb     40e09c <__swc_fn_e121059d_000145_d5d4d43f+0x1dc>
  40e085:	cmp    QWORD PTR [r12+0x20],rdx
  40e08a:	seta   al
  40e08d:	ja     40e09c <__swc_fn_e121059d_000145_d5d4d43f+0x1dc>
  40e08f:	sub    rdx,QWORD PTR [r12+0x20]
  40e094:	cmp    QWORD PTR [r12+0x18],rdx
  40e099:	seta   al
  40e09c:	test   al,al
  40e09e:	je     40e0ad <__swc_fn_e121059d_000145_d5d4d43f+0x1ed>
  40e0a0:	xor    eax,eax
  40e0a2:	pop    r15
  40e0a4:	pop    r14
  40e0a6:	pop    r13
  40e0a8:	pop    r12
  40e0aa:	pop    rdi
  40e0ab:	pop    rsi
  40e0ac:	ret
  40e0ad:	mov    rax,QWORD PTR [r12+0x20]
  40e0b2:	mov    QWORD PTR [r8],rax
  40e0b5:	mov    rax,QWORD PTR [r12+0x18]
  40e0ba:	add    rax,rcx
  40e0bd:	pop    r15
  40e0bf:	pop    r14
  40e0c1:	pop    r13
  40e0c3:	pop    r12
  40e0c5:	pop    rdi
  40e0c6:	pop    rsi
  40e0c7:	ret
  40e0c8:	add    r11,0x1
  40e0cc:	cmp    r11,r9
  40e0cf:	jb     40e000 <__swc_fn_e121059d_000145_d5d4d43f+0x140>
  40e0d5:	xor    eax,eax
  40e0d7:	pop    r15
  40e0d9:	pop    r14
  40e0db:	pop    r13
  40e0dd:	pop    r12
  40e0df:	pop    rdi
  40e0e0:	pop    rsi
  40e0e1:	ret
	...

000000000040e0f0 <__swc_fn_e121059d_000148_d7edc04f>:
  40e0f0:	push   rdi
  40e0f1:	push   rsi
  40e0f2:	sub    rsp,0xa8
  40e0f9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e0ff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e105:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e10b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e111:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e117:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e11d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e123:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e129:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e132:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e13b:	mov    rdi,rcx
  40e13e:	xor    eax,eax
  40e140:	call   4071d0 <free@plt>
  40e145:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e14b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e151:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e157:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e15d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e163:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e169:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e16f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e175:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e17e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e187:	add    rsp,0xa8
  40e18e:	pop    rsi
  40e18f:	pop    rdi
  40e190:	ret
	...

000000000040e1a0 <__swc_fn_e121059d_000151_6203dca2>:
  40e1a0:	push   rbx
  40e1a1:	push   rsi
  40e1a2:	push   rdi
  40e1a3:	push   r12
  40e1a5:	push   r13
  40e1a7:	push   r15
  40e1a9:	sub    rsp,0x4e8
  40e1b0:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  40e1b9:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  40e1c2:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  40e1cb:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  40e1d4:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  40e1dd:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  40e1e6:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  40e1ef:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  40e1f8:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  40e201:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  40e20a:	mov    rbx,QWORD PTR [rcx]
  40e20d:	mov    rcx,QWORD PTR [rcx+0x8]
  40e211:	mov    rsi,rcx
  40e214:	xor    edi,edi
  40e216:	vmovsd xmm6,QWORD PTR [rip+0x5502]        # 413720 <__swc_rdata_base_e121059d+0x610>
  40e21e:	vmovsd xmm7,QWORD PTR [rip+0x5503]        # 413729 <__swc_rdata_base_e121059d+0x619>
  40e226:	vmovsd xmm8,QWORD PTR [rip+0x50b4]        # 4132e2 <__swc_rdata_base_e121059d+0x1d2>
  40e22e:	vmovsd xmm9,QWORD PTR [rip+0x54fc]        # 413732 <__swc_rdata_base_e121059d+0x622>
  40e236:	vmovsd xmm10,QWORD PTR [rip+0x509b]        # 4132d9 <__swc_rdata_base_e121059d+0x1c9>
  40e23e:	vmovups xmm11,xmm6
  40e242:	vmovsd QWORD PTR [rsp+0x418],xmm7
  40e24b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  40e254:	vmovsd QWORD PTR [rsp+0x428],xmm9
  40e25d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  40e266:	vmovsd xmm15,QWORD PTR [rip+0x54cd]        # 41373b <__swc_rdata_base_e121059d+0x62b>
  40e26e:	vmovups xmm14,xmm15
  40e273:	vmovups xmm0,xmm9
  40e278:	vmovsd QWORD PTR [rsp+0x438],xmm15
  40e281:	vmovups xmm13,xmm8
  40e286:	vmovsd QWORD PTR [rsp+0x440],xmm15
  40e28f:	test   rsi,rsi
  40e292:	je     40f283 <__swc_fn_e121059d_000151_6203dca2+0x10e3>
  40e298:	cs nop WORD PTR [rax+rax*1+0x0]
  40e2a2:	cs nop WORD PTR [rax+rax*1+0x0]
  40e2ac:	nop    DWORD PTR [rax+0x0]
  40e2b0:	lea    rcx,[rdi+rdi*1]
  40e2b4:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  40e2b9:	vpshufd xmm3,xmm2,0xee
  40e2be:	vmovq  rcx,xmm3
  40e2c3:	test   rcx,rcx
  40e2c6:	je     40e2dc <__swc_fn_e121059d_000151_6203dca2+0x13c>
  40e2c8:	test   DWORD PTR [rcx+0x28],0x400000
  40e2cf:	je     40e2dc <__swc_fn_e121059d_000151_6203dca2+0x13c>
  40e2d1:	mov    rdx,QWORD PTR [rcx+0x30]
  40e2d5:	test   rdx,rdx
  40e2d8:	cmovne rcx,rdx
  40e2dc:	test   DWORD PTR [rcx+0x28],0x1000
  40e2e3:	je     40e304 <__swc_fn_e121059d_000151_6203dca2+0x164>
  40e2e5:	mov    rdx,QWORD PTR [rcx+0x40]
  40e2e9:	mov    rcx,rdx
  40e2ec:	vmovq  r8,xmm2
  40e2f1:	mov    r8,QWORD PTR [r8]
  40e2f4:	mov    QWORD PTR [rsp+0x60],r8
  40e2f9:	mov    QWORD PTR [rsp+0x68],rdx
  40e2fe:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  40e304:	test   BYTE PTR [rcx+0x28],0x1
  40e308:	jne    40e310 <__swc_fn_e121059d_000151_6203dca2+0x170>
  40e30a:	vmovups xmm12,xmm0
  40e30e:	jmp    40e32a <__swc_fn_e121059d_000151_6203dca2+0x18a>
  40e310:	vmovq  rax,xmm2
  40e315:	mov    rax,QWORD PTR [rax]
  40e318:	lea    rcx,[rax+0x10]
  40e31c:	vmovups xmm12,xmm0
  40e320:	call   40d930 <__swc_fn_e121059d_000121_2648f149>
  40e325:	jmp    40f265 <__swc_fn_e121059d_000151_6203dca2+0x10c5>
  40e32a:	test   DWORD PTR [rcx+0x28],0x400
  40e331:	je     40e392 <__swc_fn_e121059d_000151_6203dca2+0x1f2>
  40e333:	vmovq  rax,xmm2
  40e338:	mov    rax,QWORD PTR [rax]
  40e33b:	xor    ecx,ecx
  40e33d:	test   rax,rax
  40e340:	je     40e370 <__swc_fn_e121059d_000151_6203dca2+0x1d0>
  40e342:	mov    rdx,rax
  40e345:	mov    r8b,BYTE PTR [rdx]
  40e348:	test   r8b,r8b
  40e34b:	je     40e370 <__swc_fn_e121059d_000151_6203dca2+0x1d0>
  40e34d:	cs nop WORD PTR [rax+rax*1+0x0]
  40e357:	nop    WORD PTR [rax+rax*1+0x0]
  40e360:	add    rdx,0x1
  40e364:	add    rcx,0x1
  40e368:	mov    r8b,BYTE PTR [rdx]
  40e36b:	test   r8b,r8b
  40e36e:	jne    40e360 <__swc_fn_e121059d_000151_6203dca2+0x1c0>
  40e370:	mov    QWORD PTR [rsp+0x88],rax
  40e378:	mov    QWORD PTR [rsp+0x90],rcx
  40e380:	lea    rcx,[rsp+0x88]
  40e388:	call   40d930 <__swc_fn_e121059d_000121_2648f149>
  40e38d:	jmp    40f265 <__swc_fn_e121059d_000151_6203dca2+0x10c5>
  40e392:	cmp    BYTE PTR [rcx+0x2c],0x6
  40e396:	jne    40e3ad <__swc_fn_e121059d_000151_6203dca2+0x20d>
  40e398:	vmovq  rax,xmm2
  40e39d:	mov    rax,QWORD PTR [rax]
  40e3a0:	mov    rcx,rax
  40e3a3:	call   412550 <__swc_fn_e121059d_000149_43c96957>
  40e3a8:	jmp    40f265 <__swc_fn_e121059d_000151_6203dca2+0x10c5>
  40e3ad:	cmp    BYTE PTR [rcx+0x2c],0x1
  40e3b1:	jne    40f259 <__swc_fn_e121059d_000151_6203dca2+0x10b9>
  40e3b7:	vmovq  rdx,xmm2
  40e3bc:	mov    cl,BYTE PTR [rcx+0x40]
  40e3bf:	cmp    cl,0x7
  40e3c2:	jb     40e405 <__swc_fn_e121059d_000151_6203dca2+0x265>
  40e3c4:	je     40e478 <__swc_fn_e121059d_000151_6203dca2+0x2d8>
  40e3ca:	cmp    cl,0x8
  40e3cd:	je     40e484 <__swc_fn_e121059d_000151_6203dca2+0x2e4>
  40e3d3:	cmp    cl,0x9
  40e3d6:	je     40e49d <__swc_fn_e121059d_000151_6203dca2+0x2fd>
  40e3dc:	cmp    cl,0xa
  40e3df:	je     40eb64 <__swc_fn_e121059d_000151_6203dca2+0x9c4>
  40e3e5:	cmp    cl,0xb
  40e3e8:	je     40f22b <__swc_fn_e121059d_000151_6203dca2+0x108b>
  40e3ee:	cmp    cl,0xc
  40e3f1:	je     40e491 <__swc_fn_e121059d_000151_6203dca2+0x2f1>
  40e3f7:	cmp    cl,0xd
  40e3fa:	je     40f221 <__swc_fn_e121059d_000151_6203dca2+0x1081>
  40e400:	jmp    40f24b <__swc_fn_e121059d_000151_6203dca2+0x10ab>
  40e405:	cmp    cl,0x1
  40e408:	je     40e428 <__swc_fn_e121059d_000151_6203dca2+0x288>
  40e40a:	cmp    cl,0x2
  40e40d:	je     40e436 <__swc_fn_e121059d_000151_6203dca2+0x296>
  40e40f:	cmp    cl,0x3
  40e412:	je     40e444 <__swc_fn_e121059d_000151_6203dca2+0x2a4>
  40e414:	cmp    cl,0x4
  40e417:	je     40e451 <__swc_fn_e121059d_000151_6203dca2+0x2b1>
  40e419:	cmp    cl,0x5
  40e41c:	je     40e45e <__swc_fn_e121059d_000151_6203dca2+0x2be>
  40e41e:	cmp    cl,0x6
  40e421:	je     40e46b <__swc_fn_e121059d_000151_6203dca2+0x2cb>
  40e423:	jmp    40f24b <__swc_fn_e121059d_000151_6203dca2+0x10ab>
  40e428:	movsx  rcx,BYTE PTR [rdx]
  40e42c:	call   40abc0 <__swc_fn_e121059d_000150_2eb804cc>
  40e431:	jmp    40f265 <__swc_fn_e121059d_000151_6203dca2+0x10c5>
  40e436:	movsx  rcx,WORD PTR [rdx]
  40e43a:	call   40abc0 <__swc_fn_e121059d_000150_2eb804cc>
  40e43f:	jmp    40f265 <__swc_fn_e121059d_000151_6203dca2+0x10c5>
  40e444:	movsxd rcx,DWORD PTR [rdx]
  40e447:	call   40abc0 <__swc_fn_e121059d_000150_2eb804cc>
  40e44c:	jmp    40f265 <__swc_fn_e121059d_000151_6203dca2+0x10c5>
  40e451:	mov    rcx,QWORD PTR [rdx]
  40e454:	call   40abc0 <__swc_fn_e121059d_000150_2eb804cc>
  40e459:	jmp    40f265 <__swc_fn_e121059d_000151_6203dca2+0x10c5>
  40e45e:	movzx  ecx,BYTE PTR [rdx]
  40e461:	call   412550 <__swc_fn_e121059d_000149_43c96957>
  40e466:	jmp    40f265 <__swc_fn_e121059d_000151_6203dca2+0x10c5>
  40e46b:	movzx  ecx,WORD PTR [rdx]
  40e46e:	call   412550 <__swc_fn_e121059d_000149_43c96957>
  40e473:	jmp    40f265 <__swc_fn_e121059d_000151_6203dca2+0x10c5>
  40e478:	mov    ecx,DWORD PTR [rdx]
  40e47a:	call   412550 <__swc_fn_e121059d_000149_43c96957>
  40e47f:	jmp    40f265 <__swc_fn_e121059d_000151_6203dca2+0x10c5>
  40e484:	mov    rcx,QWORD PTR [rdx]
  40e487:	call   412550 <__swc_fn_e121059d_000149_43c96957>
  40e48c:	jmp    40f265 <__swc_fn_e121059d_000151_6203dca2+0x10c5>
  40e491:	mov    ecx,DWORD PTR [rdx]
  40e493:	call   412550 <__swc_fn_e121059d_000149_43c96957>
  40e498:	jmp    40f265 <__swc_fn_e121059d_000151_6203dca2+0x10c5>
  40e49d:	lea    rcx,[rsp+0xa8]
  40e4a5:	vxorps xmm0,xmm0,xmm0
  40e4a9:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  40e4b2:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  40e4bb:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  40e4c4:	vzeroupper
  40e4c7:	mov    DWORD PTR [rsp+0x108],0x0
  40e4d2:	vxorpd xmm0,xmm0,xmm0
  40e4d6:	vmovss xmm1,DWORD PTR [rdx]
  40e4da:	vcvtss2sd xmm0,xmm0,xmm1
  40e4de:	vmovsd xmm1,xmm1,xmm0
  40e4e2:	vcomisd xmm0,xmm0
  40e4e6:	setne  dl
  40e4e9:	movzx  edx,dl
  40e4ec:	setp   r8b
  40e4f0:	movzx  r8d,r8b
  40e4f4:	or     edx,r8d
  40e4f7:	test   dl,dl
  40e4f9:	je     40e506 <__swc_fn_e121059d_000151_6203dca2+0x366>
  40e4fb:	mov    DWORD PTR [rcx],0x6e616e
  40e501:	jmp    40eaf8 <__swc_fn_e121059d_000151_6203dca2+0x958>
  40e506:	vcomisd xmm1,xmm6
  40e50a:	ja     40e512 <__swc_fn_e121059d_000151_6203dca2+0x372>
  40e50c:	vcomisd xmm7,xmm1
  40e510:	jbe    40e536 <__swc_fn_e121059d_000151_6203dca2+0x396>
  40e512:	vxorpd xmm0,xmm0,xmm0
  40e516:	vcomisd xmm0,xmm1
  40e51a:	jbe    40e52b <__swc_fn_e121059d_000151_6203dca2+0x38b>
  40e51c:	mov    DWORD PTR [rcx],0x666e692d
  40e522:	mov    BYTE PTR [rcx+0x4],0x0
  40e526:	jmp    40eaf8 <__swc_fn_e121059d_000151_6203dca2+0x958>
  40e52b:	mov    DWORD PTR [rcx],0x666e69
  40e531:	jmp    40eaf8 <__swc_fn_e121059d_000151_6203dca2+0x958>
  40e536:	vcomisd xmm1,xmm8
  40e53b:	jae    40e547 <__swc_fn_e121059d_000151_6203dca2+0x3a7>
  40e53d:	vcomisd xmm9,xmm1
  40e541:	jbe    40e8be <__swc_fn_e121059d_000151_6203dca2+0x71e>
  40e547:	vmovups xmm0,xmm1
  40e54b:	vxorpd xmm2,xmm2,xmm2
  40e54f:	vcomisd xmm2,xmm1
  40e553:	jbe    40e563 <__swc_fn_e121059d_000151_6203dca2+0x3c3>
  40e555:	vmovsd xmm1,xmm1,xmm0
  40e559:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x517f]        # 4136e0 <__swc_rdata_base_e121059d+0x5d0>
  40e561:	jmp    40e567 <__swc_fn_e121059d_000151_6203dca2+0x3c7>
  40e563:	vmovsd xmm1,xmm1,xmm0
  40e567:	xor    r8d,r8d
  40e56a:	vcomisd xmm1,xmm15
  40e56f:	jb     40e590 <__swc_fn_e121059d_000151_6203dca2+0x3f0>
  40e571:	cs nop WORD PTR [rax+rax*1+0x0]
  40e57b:	nop    DWORD PTR [rax+rax*1+0x0]
  40e580:	vdivsd xmm1,xmm1,xmm15
  40e585:	add    r8,0x1
  40e589:	vcomisd xmm1,xmm15
  40e58e:	jae    40e580 <__swc_fn_e121059d_000151_6203dca2+0x3e0>
  40e590:	mov    r9,rcx
  40e593:	vxorpd xmm2,xmm2,xmm2
  40e597:	vcomisd xmm2,xmm0
  40e59b:	jbe    40e5a4 <__swc_fn_e121059d_000151_6203dca2+0x404>
  40e59d:	mov    BYTE PTR [rcx],0x2d
  40e5a0:	lea    r9,[rcx+0x1]
  40e5a4:	vcvttsd2si rdx,xmm1
  40e5a9:	mov    r10b,dl
  40e5ac:	add    r10b,0x30
  40e5b0:	mov    BYTE PTR [r9],r10b
  40e5b3:	vxorpd xmm0,xmm0,xmm0
  40e5b7:	movzx  edx,dl
  40e5ba:	vcvtsi2sd xmm0,xmm0,rdx
  40e5bf:	vsubsd xmm0,xmm1,xmm0
  40e5c3:	vmulsd xmm1,xmm0,xmm15
  40e5c8:	mov    BYTE PTR [r9+0x1],0x2e
  40e5cd:	vcvttsd2si rdx,xmm1
  40e5d2:	mov    r10b,dl
  40e5d5:	add    r10b,0x30
  40e5d9:	mov    BYTE PTR [r9+0x2],r10b
  40e5dd:	vxorpd xmm0,xmm0,xmm0
  40e5e1:	movzx  edx,dl
  40e5e4:	vcvtsi2sd xmm0,xmm0,rdx
  40e5e9:	vsubsd xmm0,xmm1,xmm0
  40e5ed:	vmulsd xmm1,xmm0,xmm15
  40e5f2:	vcvttsd2si rdx,xmm1
  40e5f7:	mov    r10b,dl
  40e5fa:	add    r10b,0x30
  40e5fe:	mov    BYTE PTR [r9+0x3],r10b
  40e602:	vxorpd xmm0,xmm0,xmm0
  40e606:	movzx  edx,dl
  40e609:	vcvtsi2sd xmm0,xmm0,rdx
  40e60e:	vsubsd xmm0,xmm1,xmm0
  40e612:	vmulsd xmm1,xmm0,xmm15
  40e617:	vcvttsd2si rdx,xmm1
  40e61c:	mov    r10b,dl
  40e61f:	add    r10b,0x30
  40e623:	mov    BYTE PTR [r9+0x4],r10b
  40e627:	vxorpd xmm0,xmm0,xmm0
  40e62b:	movzx  edx,dl
  40e62e:	vcvtsi2sd xmm0,xmm0,rdx
  40e633:	vsubsd xmm0,xmm1,xmm0
  40e637:	vmulsd xmm1,xmm0,xmm15
  40e63c:	vcvttsd2si rdx,xmm1
  40e641:	mov    r10b,dl
  40e644:	add    r10b,0x30
  40e648:	mov    BYTE PTR [r9+0x5],r10b
  40e64c:	vxorpd xmm0,xmm0,xmm0
  40e650:	movzx  edx,dl
  40e653:	vcvtsi2sd xmm0,xmm0,rdx
  40e658:	vsubsd xmm0,xmm1,xmm0
  40e65c:	vmulsd xmm1,xmm0,xmm15
  40e661:	vcvttsd2si rdx,xmm1
  40e666:	mov    r10b,dl
  40e669:	add    r10b,0x30
  40e66d:	mov    BYTE PTR [r9+0x6],r10b
  40e671:	vxorpd xmm0,xmm0,xmm0
  40e675:	movzx  edx,dl
  40e678:	vcvtsi2sd xmm0,xmm0,rdx
  40e67d:	vsubsd xmm0,xmm1,xmm0
  40e681:	vmulsd xmm1,xmm0,xmm15
  40e686:	vcvttsd2si rdx,xmm1
  40e68b:	mov    r10b,dl
  40e68e:	add    r10b,0x30
  40e692:	mov    BYTE PTR [r9+0x7],r10b
  40e696:	vxorpd xmm0,xmm0,xmm0
  40e69a:	movzx  edx,dl
  40e69d:	vcvtsi2sd xmm0,xmm0,rdx
  40e6a2:	vsubsd xmm0,xmm1,xmm0
  40e6a6:	vmulsd xmm1,xmm0,xmm15
  40e6ab:	vcvttsd2si rdx,xmm1
  40e6b0:	mov    r10b,dl
  40e6b3:	add    r10b,0x30
  40e6b7:	mov    BYTE PTR [r9+0x8],r10b
  40e6bb:	vxorpd xmm0,xmm0,xmm0
  40e6bf:	movzx  edx,dl
  40e6c2:	vcvtsi2sd xmm0,xmm0,rdx
  40e6c7:	vsubsd xmm0,xmm1,xmm0
  40e6cb:	vmulsd xmm1,xmm0,xmm15
  40e6d0:	vcvttsd2si rdx,xmm1
  40e6d5:	mov    r10b,dl
  40e6d8:	add    r10b,0x30
  40e6dc:	mov    BYTE PTR [r9+0x9],r10b
  40e6e0:	vxorpd xmm0,xmm0,xmm0
  40e6e4:	movzx  edx,dl
  40e6e7:	vcvtsi2sd xmm0,xmm0,rdx
  40e6ec:	vsubsd xmm0,xmm1,xmm0
  40e6f0:	vmulsd xmm1,xmm0,xmm15
  40e6f5:	vcvttsd2si rdx,xmm1
  40e6fa:	mov    r10b,dl
  40e6fd:	add    r10b,0x30
  40e701:	mov    BYTE PTR [r9+0xa],r10b
  40e705:	vxorpd xmm0,xmm0,xmm0
  40e709:	movzx  edx,dl
  40e70c:	vcvtsi2sd xmm0,xmm0,rdx
  40e711:	vsubsd xmm0,xmm1,xmm0
  40e715:	vmulsd xmm1,xmm0,xmm15
  40e71a:	vcvttsd2si rdx,xmm1
  40e71f:	mov    r10b,dl
  40e722:	add    r10b,0x30
  40e726:	mov    BYTE PTR [r9+0xb],r10b
  40e72a:	lea    r10,[r9+0x4]
  40e72e:	vxorpd xmm0,xmm0,xmm0
  40e732:	movzx  edx,dl
  40e735:	vcvtsi2sd xmm0,xmm0,rdx
  40e73a:	vsubsd xmm0,xmm1,xmm0
  40e73e:	vmulsd xmm1,xmm0,xmm15
  40e743:	vcvttsd2si rdx,xmm1
  40e748:	mov    r11b,dl
  40e74b:	add    r11b,0x30
  40e74f:	mov    BYTE PTR [r9+0xc],r11b
  40e753:	vxorpd xmm0,xmm0,xmm0
  40e757:	movzx  edx,dl
  40e75a:	vcvtsi2sd xmm0,xmm0,rdx
  40e75f:	vsubsd xmm0,xmm1,xmm0
  40e763:	vmulsd xmm1,xmm0,xmm15
  40e768:	vcvttsd2si rdx,xmm1
  40e76d:	mov    r11b,dl
  40e770:	add    r11b,0x30
  40e774:	mov    BYTE PTR [r9+0xd],r11b
  40e778:	lea    r10,[r10+0x2]
  40e77c:	vxorpd xmm0,xmm0,xmm0
  40e780:	movzx  edx,dl
  40e783:	vcvtsi2sd xmm0,xmm0,rdx
  40e788:	vsubsd xmm0,xmm1,xmm0
  40e78c:	vmulsd xmm1,xmm0,xmm15
  40e791:	vcvttsd2si rdx,xmm1
  40e796:	mov    r11b,dl
  40e799:	add    r11b,0x30
  40e79d:	mov    BYTE PTR [r9+0xe],r11b
  40e7a1:	vxorpd xmm0,xmm0,xmm0
  40e7a5:	movzx  edx,dl
  40e7a8:	vcvtsi2sd xmm0,xmm0,rdx
  40e7ad:	vsubsd xmm0,xmm1,xmm0
  40e7b1:	vmulsd xmm1,xmm0,xmm15
  40e7b6:	vcvttsd2si rdx,xmm1
  40e7bb:	mov    r11b,dl
  40e7be:	add    r11b,0x30
  40e7c2:	mov    BYTE PTR [r9+0xf],r11b
  40e7c6:	lea    r10,[r10+0x2]
  40e7ca:	lea    r10,[r10+0x2]
  40e7ce:	lea    r10,[r10+0x2]
  40e7d2:	lea    r10,[r10+0x2]
  40e7d6:	lea    r10,[r10+0x2]
  40e7da:	vxorpd xmm0,xmm0,xmm0
  40e7de:	movzx  edx,dl
  40e7e1:	vcvtsi2sd xmm0,xmm0,rdx
  40e7e6:	vsubsd xmm0,xmm1,xmm0
  40e7ea:	vmulsd xmm1,xmm0,xmm15
  40e7ef:	vcvttsd2si rdx,xmm1
  40e7f4:	mov    r11b,dl
  40e7f7:	add    r11b,0x30
  40e7fb:	mov    BYTE PTR [r9+0x10],r11b
  40e7ff:	vxorpd xmm0,xmm0,xmm0
  40e803:	movzx  edx,dl
  40e806:	vcvtsi2sd xmm0,xmm0,rdx
  40e80b:	vsubsd xmm0,xmm1,xmm0
  40e80f:	vmulsd xmm1,xmm0,xmm15
  40e814:	vcvttsd2si rdx,xmm1
  40e819:	add    dl,0x30
  40e81c:	mov    BYTE PTR [r9+0x11],dl
  40e820:	mov    BYTE PTR [r10+0x2],0x65
  40e825:	lea    r9,[r10+0x3]
  40e829:	test   r8,r8
  40e82c:	jl     40e835 <__swc_fn_e121059d_000151_6203dca2+0x695>
  40e82e:	mov    BYTE PTR [r9],0x2b
  40e832:	inc    r9
  40e835:	mov    r10,r9
  40e838:	mov    rdx,r8
  40e83b:	nop    DWORD PTR [rax+rax*1+0x0]
  40e840:	mov    r11,rdx
  40e843:	movabs rdx,0x6666666666666667
  40e84d:	mov    rax,r11
  40e850:	imul   rdx
  40e853:	sar    rdx,0x2
  40e857:	mov    r12,rdx
  40e85a:	shr    rdx,0x3f
  40e85e:	add    r12,rdx
  40e861:	mov    rdx,r12
  40e864:	imul   r13,r12,0xa
  40e868:	sub    r11,r13
  40e86b:	mov    r13,QWORD PTR [rip+0x4e5e]        # 4136d0 <__swc_rdata_base_e121059d+0x5c0>
  40e872:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40e877:	mov    BYTE PTR [r10],r11b
  40e87a:	lea    r11,[r10+0x1]
  40e87e:	mov    r10,r11
  40e881:	test   r12,r12
  40e884:	jne    40e840 <__swc_fn_e121059d_000151_6203dca2+0x6a0>
  40e886:	test   r8,r8
  40e889:	jge    40e893 <__swc_fn_e121059d_000151_6203dca2+0x6f3>
  40e88b:	mov    BYTE PTR [r11],0x2d
  40e88f:	lea    r10,[r11+0x1]
  40e893:	mov    BYTE PTR [r10],0x0
  40e897:	sub    r10,0x1
  40e89b:	nop    DWORD PTR [rax+rax*1+0x0]
  40e8a0:	cmp    r9,r10
  40e8a3:	jae    40eaf8 <__swc_fn_e121059d_000151_6203dca2+0x958>
  40e8a9:	mov    al,BYTE PTR [r10]
  40e8ac:	mov    dl,BYTE PTR [r9]
  40e8af:	mov    BYTE PTR [r10],dl
  40e8b2:	sub    r10,0x1
  40e8b6:	mov    BYTE PTR [r9],al
  40e8b9:	inc    r9
  40e8bc:	jmp    40e8a0 <__swc_fn_e121059d_000151_6203dca2+0x700>
  40e8be:	vcvttsd2si rdx,xmm1
  40e8c3:	mov    r8,rdx
  40e8c6:	vxorpd xmm0,xmm0,xmm0
  40e8ca:	vcvtsi2sd xmm0,xmm0,rdx
  40e8cf:	vsubsd xmm0,xmm1,xmm0
  40e8d3:	mov    r9d,0x8
  40e8d9:	vxorpd xmm2,xmm2,xmm2
  40e8dd:	vcomisd xmm2,xmm0
  40e8e1:	jbe    40e8eb <__swc_fn_e121059d_000151_6203dca2+0x74b>
  40e8e3:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x4df5]        # 4136e0 <__swc_rdata_base_e121059d+0x5d0>
  40e8eb:	test   r9d,r9d
  40e8ee:	je     40e8fa <__swc_fn_e121059d_000151_6203dca2+0x75a>
  40e8f0:	vmulsd xmm0,xmm0,xmm14
  40e8f5:	dec    r9d
  40e8f8:	jne    40e8f0 <__swc_fn_e121059d_000151_6203dca2+0x750>
  40e8fa:	vcvttsd2si r9,xmm0
  40e8ff:	mov    r10,r9
  40e902:	vxorpd xmm2,xmm2,xmm2
  40e906:	vcvtsi2sd xmm2,xmm2,r9
  40e90b:	vsubsd xmm0,xmm0,xmm2
  40e90f:	vcomisd xmm0,xmm10
  40e914:	lea    r9,[r9+0x1]
  40e918:	cmova  r10,r9
  40e91c:	cmp    r10,0x5f5e100
  40e923:	jne    40e93c <__swc_fn_e121059d_000151_6203dca2+0x79c>
  40e925:	lea    r8,[rdx-0x1]
  40e929:	vxorpd xmm0,xmm0,xmm0
  40e92d:	vcomisd xmm0,xmm1
  40e931:	lea    rdx,[rdx+0x1]
  40e935:	cmovbe r8,rdx
  40e939:	xor    r10d,r10d
  40e93c:	mov    r9,rcx
  40e93f:	test   r8,r8
  40e942:	jne    40e962 <__swc_fn_e121059d_000151_6203dca2+0x7c2>
  40e944:	vxorpd xmm0,xmm0,xmm0
  40e948:	vcomisd xmm0,xmm1
  40e94c:	jbe    40e955 <__swc_fn_e121059d_000151_6203dca2+0x7b5>
  40e94e:	mov    BYTE PTR [rcx],0x2d
  40e951:	lea    r9,[rcx+0x1]
  40e955:	mov    BYTE PTR [r9],0x30
  40e959:	add    r9,0x1
  40e95d:	jmp    40e9fb <__swc_fn_e121059d_000151_6203dca2+0x85b>
  40e962:	mov    r9,rcx
  40e965:	mov    rdx,r8
  40e968:	nop    DWORD PTR [rax+rax*1+0x0]
  40e970:	mov    r11,rdx
  40e973:	movabs rdx,0x6666666666666667
  40e97d:	mov    r15,rax
  40e980:	mov    rax,r11
  40e983:	imul   rdx
  40e986:	mov    r12,rdx
  40e989:	mov    rax,r15
  40e98c:	sar    r12,0x2
  40e990:	mov    rdx,r12
  40e993:	shr    rdx,0x3f
  40e997:	add    r12,rdx
  40e99a:	mov    rdx,r12
  40e99d:	imul   r13,r12,0xa
  40e9a1:	sub    r11,r13
  40e9a4:	mov    r13,QWORD PTR [rip+0x4d25]        # 4136d0 <__swc_rdata_base_e121059d+0x5c0>
  40e9ab:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40e9b0:	mov    BYTE PTR [r9],r11b
  40e9b3:	lea    r11,[r9+0x1]
  40e9b7:	mov    r9,r11
  40e9ba:	test   r12,r12
  40e9bd:	jne    40e970 <__swc_fn_e121059d_000151_6203dca2+0x7d0>
  40e9bf:	test   r8,r8
  40e9c2:	jge    40e9cc <__swc_fn_e121059d_000151_6203dca2+0x82c>
  40e9c4:	mov    BYTE PTR [r11],0x2d
  40e9c8:	lea    r9,[r11+0x1]
  40e9cc:	mov    rdx,r9
  40e9cf:	mov    BYTE PTR [r9],0x0
  40e9d3:	sub    r9,0x1
  40e9d7:	mov    r8,rcx
  40e9da:	cmp    r8,r9
  40e9dd:	jae    40e9f8 <__swc_fn_e121059d_000151_6203dca2+0x858>
  40e9df:	nop
  40e9e0:	mov    r11b,BYTE PTR [r9]
  40e9e3:	mov    r12b,BYTE PTR [r8]
  40e9e6:	mov    BYTE PTR [r9],r12b
  40e9e9:	sub    r9,0x1
  40e9ed:	mov    BYTE PTR [r8],r11b
  40e9f0:	inc    r8
  40e9f3:	cmp    r8,r9
  40e9f6:	jb     40e9e0 <__swc_fn_e121059d_000151_6203dca2+0x840>
  40e9f8:	mov    r9,rdx
  40e9fb:	mov    BYTE PTR [r9],0x2e
  40e9ff:	add    r9,0x1
  40ea03:	xor    r8d,r8d
  40ea06:	test   r10,r10
  40ea09:	je     40ea4f <__swc_fn_e121059d_000151_6203dca2+0x8af>
  40ea0b:	mov    r11d,0x989680
  40ea11:	cmp    r10,r11
  40ea14:	jge    40ea4f <__swc_fn_e121059d_000151_6203dca2+0x8af>
  40ea16:	cs nop WORD PTR [rax+rax*1+0x0]
  40ea20:	inc    r8d
  40ea23:	movabs rdx,0x6666666666666667
  40ea2d:	mov    r15,rax
  40ea30:	mov    rax,r11
  40ea33:	imul   rdx
  40ea36:	mov    r11,rdx
  40ea39:	mov    rax,r15
  40ea3c:	sar    r11,0x2
  40ea40:	mov    rdx,r11
  40ea43:	shr    rdx,0x3f
  40ea47:	add    r11,rdx
  40ea4a:	cmp    r10,r11
  40ea4d:	jl     40ea20 <__swc_fn_e121059d_000151_6203dca2+0x880>
  40ea4f:	test   r8d,r8d
  40ea52:	je     40ea6d <__swc_fn_e121059d_000151_6203dca2+0x8cd>
  40ea54:	cs nop WORD PTR [rax+rax*1+0x0]
  40ea5e:	xchg   ax,ax
  40ea60:	mov    BYTE PTR [r9],0x30
  40ea64:	add    r9,0x1
  40ea68:	dec    r8d
  40ea6b:	jne    40ea60 <__swc_fn_e121059d_000151_6203dca2+0x8c0>
  40ea6d:	mov    r8,r9
  40ea70:	mov    rdx,r10
  40ea73:	cs nop WORD PTR [rax+rax*1+0x0]
  40ea7d:	nop    DWORD PTR [rax]
  40ea80:	mov    r11,rdx
  40ea83:	movabs rdx,0x6666666666666667
  40ea8d:	mov    rax,r11
  40ea90:	imul   rdx
  40ea93:	sar    rdx,0x2
  40ea97:	mov    r12,rdx
  40ea9a:	shr    rdx,0x3f
  40ea9e:	add    r12,rdx
  40eaa1:	mov    rdx,r12
  40eaa4:	imul   r13,r12,0xa
  40eaa8:	sub    r11,r13
  40eaab:	mov    r13,QWORD PTR [rip+0x4c1e]        # 4136d0 <__swc_rdata_base_e121059d+0x5c0>
  40eab2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40eab7:	mov    BYTE PTR [r8],r11b
  40eaba:	lea    r11,[r8+0x1]
  40eabe:	mov    r8,r11
  40eac1:	test   r12,r12
  40eac4:	jne    40ea80 <__swc_fn_e121059d_000151_6203dca2+0x8e0>
  40eac6:	test   r10,r10
  40eac9:	jge    40ead3 <__swc_fn_e121059d_000151_6203dca2+0x933>
  40eacb:	mov    BYTE PTR [r11],0x2d
  40eacf:	lea    r8,[r11+0x1]
  40ead3:	mov    BYTE PTR [r8],0x0
  40ead7:	sub    r8,0x1
  40eadb:	cmp    r9,r8
  40eade:	jae    40eaf8 <__swc_fn_e121059d_000151_6203dca2+0x958>
  40eae0:	mov    al,BYTE PTR [r8]
  40eae3:	mov    dl,BYTE PTR [r9]
  40eae6:	mov    BYTE PTR [r8],dl
  40eae9:	sub    r8,0x1
  40eaed:	mov    BYTE PTR [r9],al
  40eaf0:	inc    r9
  40eaf3:	cmp    r9,r8
  40eaf6:	jb     40eae0 <__swc_fn_e121059d_000151_6203dca2+0x940>
  40eaf8:	xor    eax,eax
  40eafa:	test   rcx,rcx
  40eafd:	je     40eb30 <__swc_fn_e121059d_000151_6203dca2+0x990>
  40eaff:	mov    rdx,rcx
  40eb02:	mov    r8b,BYTE PTR [rdx]
  40eb05:	test   r8b,r8b
  40eb08:	je     40eb30 <__swc_fn_e121059d_000151_6203dca2+0x990>
  40eb0a:	cs nop WORD PTR [rax+rax*1+0x0]
  40eb14:	cs nop WORD PTR [rax+rax*1+0x0]
  40eb1e:	xchg   ax,ax
  40eb20:	add    rdx,0x1
  40eb24:	add    rax,0x1
  40eb28:	mov    r8b,BYTE PTR [rdx]
  40eb2b:	test   r8b,r8b
  40eb2e:	jne    40eb20 <__swc_fn_e121059d_000151_6203dca2+0x980>
  40eb30:	mov    QWORD PTR [rsp+0x240],rcx
  40eb38:	mov    QWORD PTR [rsp+0x248],rax
  40eb40:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  40eb49:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  40eb52:	lea    rcx,[rsp+0x250]
  40eb5a:	call   40d930 <__swc_fn_e121059d_000121_2648f149>
  40eb5f:	jmp    40f265 <__swc_fn_e121059d_000151_6203dca2+0x10c5>
  40eb64:	lea    rcx,[rsp+0x260]
  40eb6c:	vxorps xmm0,xmm0,xmm0
  40eb70:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  40eb79:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  40eb82:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  40eb8b:	vzeroupper
  40eb8e:	mov    DWORD PTR [rsp+0x2c0],0x0
  40eb99:	vmovsd xmm0,QWORD PTR [rdx]
  40eb9d:	vcomisd xmm0,xmm0
  40eba1:	setne  dl
  40eba4:	movzx  edx,dl
  40eba7:	setp   r8b
  40ebab:	movzx  r8d,r8b
  40ebaf:	or     edx,r8d
  40ebb2:	test   dl,dl
  40ebb4:	je     40ebc1 <__swc_fn_e121059d_000151_6203dca2+0xa21>
  40ebb6:	mov    DWORD PTR [rcx],0x6e616e
  40ebbc:	jmp    40f1c8 <__swc_fn_e121059d_000151_6203dca2+0x1028>
  40ebc1:	vcomisd xmm0,xmm11
  40ebc6:	ja     40ebd7 <__swc_fn_e121059d_000151_6203dca2+0xa37>
  40ebc8:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  40ebd1:	vcomisd xmm6,xmm0
  40ebd5:	jbe    40ebfb <__swc_fn_e121059d_000151_6203dca2+0xa5b>
  40ebd7:	vxorpd xmm1,xmm1,xmm1
  40ebdb:	vcomisd xmm1,xmm0
  40ebdf:	jbe    40ebf0 <__swc_fn_e121059d_000151_6203dca2+0xa50>
  40ebe1:	mov    DWORD PTR [rcx],0x666e692d
  40ebe7:	mov    BYTE PTR [rcx+0x4],0x0
  40ebeb:	jmp    40f1c8 <__swc_fn_e121059d_000151_6203dca2+0x1028>
  40ebf0:	mov    DWORD PTR [rcx],0x666e69
  40ebf6:	jmp    40f1c8 <__swc_fn_e121059d_000151_6203dca2+0x1028>
  40ebfb:	vcomisd xmm0,xmm13
  40ec00:	jae    40ec0c <__swc_fn_e121059d_000151_6203dca2+0xa6c>
  40ec02:	vcomisd xmm12,xmm0
  40ec06:	jbe    40ef6e <__swc_fn_e121059d_000151_6203dca2+0xdce>
  40ec0c:	vmovups xmm1,xmm0
  40ec10:	vxorpd xmm2,xmm2,xmm2
  40ec14:	vcomisd xmm2,xmm0
  40ec18:	jbe    40ec28 <__swc_fn_e121059d_000151_6203dca2+0xa88>
  40ec1a:	vmovsd xmm0,xmm0,xmm1
  40ec1e:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x4aba]        # 4136e0 <__swc_rdata_base_e121059d+0x5d0>
  40ec26:	jmp    40ec2c <__swc_fn_e121059d_000151_6203dca2+0xa8c>
  40ec28:	vmovsd xmm0,xmm0,xmm1
  40ec2c:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  40ec35:	xor    r8d,r8d
  40ec38:	vcomisd xmm0,xmm6
  40ec3c:	jb     40ec4e <__swc_fn_e121059d_000151_6203dca2+0xaae>
  40ec3e:	xchg   ax,ax
  40ec40:	vdivsd xmm0,xmm0,xmm6
  40ec44:	add    r8,0x1
  40ec48:	vcomisd xmm0,xmm6
  40ec4c:	jae    40ec40 <__swc_fn_e121059d_000151_6203dca2+0xaa0>
  40ec4e:	mov    r9,rcx
  40ec51:	vxorpd xmm2,xmm2,xmm2
  40ec55:	vcomisd xmm2,xmm1
  40ec59:	jbe    40ec62 <__swc_fn_e121059d_000151_6203dca2+0xac2>
  40ec5b:	mov    BYTE PTR [rcx],0x2d
  40ec5e:	lea    r9,[rcx+0x1]
  40ec62:	vcvttsd2si rdx,xmm0
  40ec67:	mov    r10b,dl
  40ec6a:	add    r10b,0x30
  40ec6e:	mov    BYTE PTR [r9],r10b
  40ec71:	vxorpd xmm1,xmm1,xmm1
  40ec75:	movzx  edx,dl
  40ec78:	vcvtsi2sd xmm1,xmm1,rdx
  40ec7d:	vsubsd xmm0,xmm0,xmm1
  40ec81:	vmulsd xmm0,xmm0,xmm6
  40ec85:	mov    BYTE PTR [r9+0x1],0x2e
  40ec8a:	vcvttsd2si rdx,xmm0
  40ec8f:	mov    r10b,dl
  40ec92:	add    r10b,0x30
  40ec96:	mov    BYTE PTR [r9+0x2],r10b
  40ec9a:	vxorpd xmm1,xmm1,xmm1
  40ec9e:	movzx  edx,dl
  40eca1:	vcvtsi2sd xmm1,xmm1,rdx
  40eca6:	vsubsd xmm0,xmm0,xmm1
  40ecaa:	vmulsd xmm0,xmm0,xmm6
  40ecae:	vcvttsd2si rdx,xmm0
  40ecb3:	mov    r10b,dl
  40ecb6:	add    r10b,0x30
  40ecba:	mov    BYTE PTR [r9+0x3],r10b
  40ecbe:	vxorpd xmm1,xmm1,xmm1
  40ecc2:	movzx  edx,dl
  40ecc5:	vcvtsi2sd xmm1,xmm1,rdx
  40ecca:	vsubsd xmm0,xmm0,xmm1
  40ecce:	vmulsd xmm0,xmm0,xmm6
  40ecd2:	vcvttsd2si rdx,xmm0
  40ecd7:	mov    r10b,dl
  40ecda:	add    r10b,0x30
  40ecde:	mov    BYTE PTR [r9+0x4],r10b
  40ece2:	vxorpd xmm1,xmm1,xmm1
  40ece6:	movzx  edx,dl
  40ece9:	vcvtsi2sd xmm1,xmm1,rdx
  40ecee:	vsubsd xmm0,xmm0,xmm1
  40ecf2:	vmulsd xmm0,xmm0,xmm6
  40ecf6:	vcvttsd2si rdx,xmm0
  40ecfb:	mov    r10b,dl
  40ecfe:	add    r10b,0x30
  40ed02:	mov    BYTE PTR [r9+0x5],r10b
  40ed06:	vxorpd xmm1,xmm1,xmm1
  40ed0a:	movzx  edx,dl
  40ed0d:	vcvtsi2sd xmm1,xmm1,rdx
  40ed12:	vsubsd xmm0,xmm0,xmm1
  40ed16:	vmulsd xmm0,xmm0,xmm6
  40ed1a:	vcvttsd2si rdx,xmm0
  40ed1f:	mov    r10b,dl
  40ed22:	add    r10b,0x30
  40ed26:	mov    BYTE PTR [r9+0x6],r10b
  40ed2a:	vxorpd xmm1,xmm1,xmm1
  40ed2e:	movzx  edx,dl
  40ed31:	vcvtsi2sd xmm1,xmm1,rdx
  40ed36:	vsubsd xmm0,xmm0,xmm1
  40ed3a:	vmulsd xmm0,xmm0,xmm6
  40ed3e:	vcvttsd2si rdx,xmm0
  40ed43:	mov    r10b,dl
  40ed46:	add    r10b,0x30
  40ed4a:	mov    BYTE PTR [r9+0x7],r10b
  40ed4e:	vxorpd xmm1,xmm1,xmm1
  40ed52:	movzx  edx,dl
  40ed55:	vcvtsi2sd xmm1,xmm1,rdx
  40ed5a:	vsubsd xmm0,xmm0,xmm1
  40ed5e:	vmulsd xmm0,xmm0,xmm6
  40ed62:	vcvttsd2si rdx,xmm0
  40ed67:	mov    r10b,dl
  40ed6a:	add    r10b,0x30
  40ed6e:	mov    BYTE PTR [r9+0x8],r10b
  40ed72:	vxorpd xmm1,xmm1,xmm1
  40ed76:	movzx  edx,dl
  40ed79:	vcvtsi2sd xmm1,xmm1,rdx
  40ed7e:	vsubsd xmm0,xmm0,xmm1
  40ed82:	vmulsd xmm0,xmm0,xmm6
  40ed86:	vcvttsd2si rdx,xmm0
  40ed8b:	mov    r10b,dl
  40ed8e:	add    r10b,0x30
  40ed92:	mov    BYTE PTR [r9+0x9],r10b
  40ed96:	vxorpd xmm1,xmm1,xmm1
  40ed9a:	movzx  edx,dl
  40ed9d:	vcvtsi2sd xmm1,xmm1,rdx
  40eda2:	vsubsd xmm0,xmm0,xmm1
  40eda6:	vmulsd xmm0,xmm0,xmm6
  40edaa:	vcvttsd2si rdx,xmm0
  40edaf:	mov    r10b,dl
  40edb2:	add    r10b,0x30
  40edb6:	mov    BYTE PTR [r9+0xa],r10b
  40edba:	vxorpd xmm1,xmm1,xmm1
  40edbe:	movzx  edx,dl
  40edc1:	vcvtsi2sd xmm1,xmm1,rdx
  40edc6:	vsubsd xmm0,xmm0,xmm1
  40edca:	vmulsd xmm0,xmm0,xmm6
  40edce:	vcvttsd2si rdx,xmm0
  40edd3:	mov    r10b,dl
  40edd6:	add    r10b,0x30
  40edda:	mov    BYTE PTR [r9+0xb],r10b
  40edde:	lea    r10,[r9+0x4]
  40ede2:	vxorpd xmm1,xmm1,xmm1
  40ede6:	movzx  edx,dl
  40ede9:	vcvtsi2sd xmm1,xmm1,rdx
  40edee:	vsubsd xmm0,xmm0,xmm1
  40edf2:	vmulsd xmm0,xmm0,xmm6
  40edf6:	vcvttsd2si rdx,xmm0
  40edfb:	mov    r11b,dl
  40edfe:	add    r11b,0x30
  40ee02:	mov    BYTE PTR [r9+0xc],r11b
  40ee06:	vxorpd xmm1,xmm1,xmm1
  40ee0a:	movzx  edx,dl
  40ee0d:	vcvtsi2sd xmm1,xmm1,rdx
  40ee12:	vsubsd xmm0,xmm0,xmm1
  40ee16:	vmulsd xmm0,xmm0,xmm6
  40ee1a:	vcvttsd2si rdx,xmm0
  40ee1f:	mov    r11b,dl
  40ee22:	add    r11b,0x30
  40ee26:	mov    BYTE PTR [r9+0xd],r11b
  40ee2a:	lea    r10,[r10+0x2]
  40ee2e:	vxorpd xmm1,xmm1,xmm1
  40ee32:	movzx  edx,dl
  40ee35:	vcvtsi2sd xmm1,xmm1,rdx
  40ee3a:	vsubsd xmm0,xmm0,xmm1
  40ee3e:	vmulsd xmm0,xmm0,xmm6
  40ee42:	vcvttsd2si rdx,xmm0
  40ee47:	mov    r11b,dl
  40ee4a:	add    r11b,0x30
  40ee4e:	mov    BYTE PTR [r9+0xe],r11b
  40ee52:	vxorpd xmm1,xmm1,xmm1
  40ee56:	movzx  edx,dl
  40ee59:	vcvtsi2sd xmm1,xmm1,rdx
  40ee5e:	vsubsd xmm0,xmm0,xmm1
  40ee62:	vmulsd xmm0,xmm0,xmm6
  40ee66:	vcvttsd2si rdx,xmm0
  40ee6b:	mov    r11b,dl
  40ee6e:	add    r11b,0x30
  40ee72:	mov    BYTE PTR [r9+0xf],r11b
  40ee76:	lea    r10,[r10+0x2]
  40ee7a:	lea    r10,[r10+0x2]
  40ee7e:	lea    r10,[r10+0x2]
  40ee82:	lea    r10,[r10+0x2]
  40ee86:	lea    r10,[r10+0x2]
  40ee8a:	vxorpd xmm1,xmm1,xmm1
  40ee8e:	movzx  edx,dl
  40ee91:	vcvtsi2sd xmm1,xmm1,rdx
  40ee96:	vsubsd xmm0,xmm0,xmm1
  40ee9a:	vmulsd xmm0,xmm0,xmm6
  40ee9e:	vcvttsd2si rdx,xmm0
  40eea3:	mov    r11b,dl
  40eea6:	add    r11b,0x30
  40eeaa:	mov    BYTE PTR [r9+0x10],r11b
  40eeae:	vxorpd xmm1,xmm1,xmm1
  40eeb2:	movzx  edx,dl
  40eeb5:	vcvtsi2sd xmm1,xmm1,rdx
  40eeba:	vsubsd xmm0,xmm0,xmm1
  40eebe:	vmulsd xmm0,xmm0,xmm6
  40eec2:	vcvttsd2si rdx,xmm0
  40eec7:	add    dl,0x30
  40eeca:	mov    BYTE PTR [r9+0x11],dl
  40eece:	mov    BYTE PTR [r10+0x2],0x65
  40eed3:	lea    r9,[r10+0x3]
  40eed7:	test   r8,r8
  40eeda:	jl     40eee3 <__swc_fn_e121059d_000151_6203dca2+0xd43>
  40eedc:	mov    BYTE PTR [r9],0x2b
  40eee0:	inc    r9
  40eee3:	mov    r10,r9
  40eee6:	mov    rdx,r8
  40eee9:	nop    DWORD PTR [rax+0x0]
  40eef0:	mov    r11,rdx
  40eef3:	movabs rdx,0x6666666666666667
  40eefd:	mov    rax,r11
  40ef00:	imul   rdx
  40ef03:	sar    rdx,0x2
  40ef07:	mov    r12,rdx
  40ef0a:	shr    rdx,0x3f
  40ef0e:	add    r12,rdx
  40ef11:	mov    rdx,r12
  40ef14:	imul   r13,r12,0xa
  40ef18:	sub    r11,r13
  40ef1b:	mov    r13,QWORD PTR [rip+0x47ae]        # 4136d0 <__swc_rdata_base_e121059d+0x5c0>
  40ef22:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40ef27:	mov    BYTE PTR [r10],r11b
  40ef2a:	lea    r11,[r10+0x1]
  40ef2e:	mov    r10,r11
  40ef31:	test   r12,r12
  40ef34:	jne    40eef0 <__swc_fn_e121059d_000151_6203dca2+0xd50>
  40ef36:	test   r8,r8
  40ef39:	jge    40ef43 <__swc_fn_e121059d_000151_6203dca2+0xda3>
  40ef3b:	mov    BYTE PTR [r11],0x2d
  40ef3f:	lea    r10,[r11+0x1]
  40ef43:	mov    BYTE PTR [r10],0x0
  40ef47:	sub    r10,0x1
  40ef4b:	nop    DWORD PTR [rax+rax*1+0x0]
  40ef50:	cmp    r9,r10
  40ef53:	jae    40f1c8 <__swc_fn_e121059d_000151_6203dca2+0x1028>
  40ef59:	mov    al,BYTE PTR [r10]
  40ef5c:	mov    dl,BYTE PTR [r9]
  40ef5f:	mov    BYTE PTR [r10],dl
  40ef62:	sub    r10,0x1
  40ef66:	mov    BYTE PTR [r9],al
  40ef69:	inc    r9
  40ef6c:	jmp    40ef50 <__swc_fn_e121059d_000151_6203dca2+0xdb0>
  40ef6e:	vcvttsd2si rdx,xmm0
  40ef73:	mov    r8,rdx
  40ef76:	vxorpd xmm1,xmm1,xmm1
  40ef7a:	vcvtsi2sd xmm1,xmm1,rdx
  40ef7f:	vsubsd xmm1,xmm0,xmm1
  40ef83:	mov    r9d,0x8
  40ef89:	vxorpd xmm2,xmm2,xmm2
  40ef8d:	vcomisd xmm2,xmm1
  40ef91:	ja     40ef9e <__swc_fn_e121059d_000151_6203dca2+0xdfe>
  40ef93:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40ef9c:	jmp    40efaf <__swc_fn_e121059d_000151_6203dca2+0xe0f>
  40ef9e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x473a]        # 4136e0 <__swc_rdata_base_e121059d+0x5d0>
  40efa6:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40efaf:	test   r9d,r9d
  40efb2:	je     40efc9 <__swc_fn_e121059d_000151_6203dca2+0xe29>
  40efb4:	cs nop WORD PTR [rax+rax*1+0x0]
  40efbe:	xchg   ax,ax
  40efc0:	vmulsd xmm1,xmm1,xmm6
  40efc4:	dec    r9d
  40efc7:	jne    40efc0 <__swc_fn_e121059d_000151_6203dca2+0xe20>
  40efc9:	vcvttsd2si r9,xmm1
  40efce:	mov    r10,r9
  40efd1:	vxorpd xmm2,xmm2,xmm2
  40efd5:	vcvtsi2sd xmm2,xmm2,r9
  40efda:	vsubsd xmm1,xmm1,xmm2
  40efde:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  40efe7:	vcomisd xmm1,xmm6
  40efeb:	lea    r9,[r9+0x1]
  40efef:	cmova  r10,r9
  40eff3:	cmp    r10,0x5f5e100
  40effa:	jne    40f013 <__swc_fn_e121059d_000151_6203dca2+0xe73>
  40effc:	lea    r8,[rdx-0x1]
  40f000:	vxorpd xmm1,xmm1,xmm1
  40f004:	vcomisd xmm1,xmm0
  40f008:	lea    rdx,[rdx+0x1]
  40f00c:	cmovbe r8,rdx
  40f010:	xor    r10d,r10d
  40f013:	mov    r9,rcx
  40f016:	test   r8,r8
  40f019:	jne    40f039 <__swc_fn_e121059d_000151_6203dca2+0xe99>
  40f01b:	vxorpd xmm1,xmm1,xmm1
  40f01f:	vcomisd xmm1,xmm0
  40f023:	jbe    40f02c <__swc_fn_e121059d_000151_6203dca2+0xe8c>
  40f025:	mov    BYTE PTR [rcx],0x2d
  40f028:	lea    r9,[rcx+0x1]
  40f02c:	mov    BYTE PTR [r9],0x30
  40f030:	add    r9,0x1
  40f034:	jmp    40f0cb <__swc_fn_e121059d_000151_6203dca2+0xf2b>
  40f039:	mov    r9,rcx
  40f03c:	mov    rdx,r8
  40f03f:	nop
  40f040:	mov    r11,rdx
  40f043:	movabs rdx,0x6666666666666667
  40f04d:	mov    r15,rax
  40f050:	mov    rax,r11
  40f053:	imul   rdx
  40f056:	mov    r12,rdx
  40f059:	mov    rax,r15
  40f05c:	sar    r12,0x2
  40f060:	mov    rdx,r12
  40f063:	shr    rdx,0x3f
  40f067:	add    r12,rdx
  40f06a:	mov    rdx,r12
  40f06d:	imul   r13,r12,0xa
  40f071:	sub    r11,r13
  40f074:	mov    r13,QWORD PTR [rip+0x4655]        # 4136d0 <__swc_rdata_base_e121059d+0x5c0>
  40f07b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40f080:	mov    BYTE PTR [r9],r11b
  40f083:	lea    r11,[r9+0x1]
  40f087:	mov    r9,r11
  40f08a:	test   r12,r12
  40f08d:	jne    40f040 <__swc_fn_e121059d_000151_6203dca2+0xea0>
  40f08f:	test   r8,r8
  40f092:	jge    40f09c <__swc_fn_e121059d_000151_6203dca2+0xefc>
  40f094:	mov    BYTE PTR [r11],0x2d
  40f098:	lea    r9,[r11+0x1]
  40f09c:	mov    rdx,r9
  40f09f:	mov    BYTE PTR [r9],0x0
  40f0a3:	sub    r9,0x1
  40f0a7:	mov    r8,rcx
  40f0aa:	cmp    r8,r9
  40f0ad:	jae    40f0c8 <__swc_fn_e121059d_000151_6203dca2+0xf28>
  40f0af:	nop
  40f0b0:	mov    r11b,BYTE PTR [r9]
  40f0b3:	mov    r12b,BYTE PTR [r8]
  40f0b6:	mov    BYTE PTR [r9],r12b
  40f0b9:	sub    r9,0x1
  40f0bd:	mov    BYTE PTR [r8],r11b
  40f0c0:	inc    r8
  40f0c3:	cmp    r8,r9
  40f0c6:	jb     40f0b0 <__swc_fn_e121059d_000151_6203dca2+0xf10>
  40f0c8:	mov    r9,rdx
  40f0cb:	mov    BYTE PTR [r9],0x2e
  40f0cf:	add    r9,0x1
  40f0d3:	xor    r8d,r8d
  40f0d6:	test   r10,r10
  40f0d9:	je     40f11f <__swc_fn_e121059d_000151_6203dca2+0xf7f>
  40f0db:	mov    r11d,0x989680
  40f0e1:	cmp    r10,r11
  40f0e4:	jge    40f11f <__swc_fn_e121059d_000151_6203dca2+0xf7f>
  40f0e6:	cs nop WORD PTR [rax+rax*1+0x0]
  40f0f0:	inc    r8d
  40f0f3:	movabs rdx,0x6666666666666667
  40f0fd:	mov    r15,rax
  40f100:	mov    rax,r11
  40f103:	imul   rdx
  40f106:	mov    r11,rdx
  40f109:	mov    rax,r15
  40f10c:	sar    r11,0x2
  40f110:	mov    rdx,r11
  40f113:	shr    rdx,0x3f
  40f117:	add    r11,rdx
  40f11a:	cmp    r10,r11
  40f11d:	jl     40f0f0 <__swc_fn_e121059d_000151_6203dca2+0xf50>
  40f11f:	test   r8d,r8d
  40f122:	je     40f13d <__swc_fn_e121059d_000151_6203dca2+0xf9d>
  40f124:	cs nop WORD PTR [rax+rax*1+0x0]
  40f12e:	xchg   ax,ax
  40f130:	mov    BYTE PTR [r9],0x30
  40f134:	add    r9,0x1
  40f138:	dec    r8d
  40f13b:	jne    40f130 <__swc_fn_e121059d_000151_6203dca2+0xf90>
  40f13d:	mov    r8,r9
  40f140:	mov    rdx,r10
  40f143:	cs nop WORD PTR [rax+rax*1+0x0]
  40f14d:	nop    DWORD PTR [rax]
  40f150:	mov    r11,rdx
  40f153:	movabs rdx,0x6666666666666667
  40f15d:	mov    rax,r11
  40f160:	imul   rdx
  40f163:	sar    rdx,0x2
  40f167:	mov    r12,rdx
  40f16a:	shr    rdx,0x3f
  40f16e:	add    r12,rdx
  40f171:	mov    rdx,r12
  40f174:	imul   r13,r12,0xa
  40f178:	sub    r11,r13
  40f17b:	mov    r13,QWORD PTR [rip+0x454e]        # 4136d0 <__swc_rdata_base_e121059d+0x5c0>
  40f182:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40f187:	mov    BYTE PTR [r8],r11b
  40f18a:	lea    r11,[r8+0x1]
  40f18e:	mov    r8,r11
  40f191:	test   r12,r12
  40f194:	jne    40f150 <__swc_fn_e121059d_000151_6203dca2+0xfb0>
  40f196:	test   r10,r10
  40f199:	jge    40f1a3 <__swc_fn_e121059d_000151_6203dca2+0x1003>
  40f19b:	mov    BYTE PTR [r11],0x2d
  40f19f:	lea    r8,[r11+0x1]
  40f1a3:	mov    BYTE PTR [r8],0x0
  40f1a7:	sub    r8,0x1
  40f1ab:	cmp    r9,r8
  40f1ae:	jae    40f1c8 <__swc_fn_e121059d_000151_6203dca2+0x1028>
  40f1b0:	mov    al,BYTE PTR [r8]
  40f1b3:	mov    dl,BYTE PTR [r9]
  40f1b6:	mov    BYTE PTR [r8],dl
  40f1b9:	sub    r8,0x1
  40f1bd:	mov    BYTE PTR [r9],al
  40f1c0:	inc    r9
  40f1c3:	cmp    r9,r8
  40f1c6:	jb     40f1b0 <__swc_fn_e121059d_000151_6203dca2+0x1010>
  40f1c8:	xor    eax,eax
  40f1ca:	test   rcx,rcx
  40f1cd:	je     40f1f0 <__swc_fn_e121059d_000151_6203dca2+0x1050>
  40f1cf:	mov    rdx,rcx
  40f1d2:	mov    r8b,BYTE PTR [rdx]
  40f1d5:	test   r8b,r8b
  40f1d8:	je     40f1f0 <__swc_fn_e121059d_000151_6203dca2+0x1050>
  40f1da:	nop    WORD PTR [rax+rax*1+0x0]
  40f1e0:	add    rdx,0x1
  40f1e4:	add    rax,0x1
  40f1e8:	mov    r8b,BYTE PTR [rdx]
  40f1eb:	test   r8b,r8b
  40f1ee:	jne    40f1e0 <__swc_fn_e121059d_000151_6203dca2+0x1040>
  40f1f0:	mov    QWORD PTR [rsp+0x3f8],rcx
  40f1f8:	mov    QWORD PTR [rsp+0x400],rax
  40f200:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  40f209:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  40f212:	lea    rcx,[rsp+0x408]
  40f21a:	call   40d930 <__swc_fn_e121059d_000121_2648f149>
  40f21f:	jmp    40f265 <__swc_fn_e121059d_000151_6203dca2+0x10c5>
  40f221:	mov    rcx,rdx
  40f224:	call   40d930 <__swc_fn_e121059d_000121_2648f149>
  40f229:	jmp    40f265 <__swc_fn_e121059d_000151_6203dca2+0x10c5>
  40f22b:	mov    al,BYTE PTR [rdx]
  40f22d:	test   al,al
  40f22f:	je     40f23a <__swc_fn_e121059d_000151_6203dca2+0x109a>
  40f231:	lea    rax,[rip+0x44b8]        # 4136f0 <__swc_rdata_base_e121059d+0x5e0>
  40f238:	jmp    40f241 <__swc_fn_e121059d_000151_6203dca2+0x10a1>
  40f23a:	lea    rax,[rip+0x44bf]        # 413700 <__swc_rdata_base_e121059d+0x5f0>
  40f241:	mov    rcx,rax
  40f244:	call   40d930 <__swc_fn_e121059d_000121_2648f149>
  40f249:	jmp    40f265 <__swc_fn_e121059d_000151_6203dca2+0x10c5>
  40f24b:	lea    rcx,[rip+0x44be]        # 413710 <__swc_rdata_base_e121059d+0x600>
  40f252:	call   40d930 <__swc_fn_e121059d_000121_2648f149>
  40f257:	jmp    40f265 <__swc_fn_e121059d_000151_6203dca2+0x10c5>
  40f259:	lea    rcx,[rip+0x44b0]        # 413710 <__swc_rdata_base_e121059d+0x600>
  40f260:	call   40d930 <__swc_fn_e121059d_000121_2648f149>
  40f265:	add    rdi,0x1
  40f269:	sub    rsi,0x1
  40f26d:	vmovups xmm0,xmm12
  40f272:	vmovsd xmm6,QWORD PTR [rip+0x44a6]        # 413720 <__swc_rdata_base_e121059d+0x610>
  40f27a:	test   rsi,rsi
  40f27d:	jne    40e2b0 <__swc_fn_e121059d_000151_6203dca2+0x110>
  40f283:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  40f28c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  40f295:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  40f29e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  40f2a7:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  40f2b0:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  40f2b9:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  40f2c2:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  40f2cb:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  40f2d4:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  40f2dd:	add    rsp,0x4e8
  40f2e4:	pop    r15
  40f2e6:	pop    r13
  40f2e8:	pop    r12
  40f2ea:	pop    rdi
  40f2eb:	pop    rsi
  40f2ec:	pop    rbx
  40f2ed:	ret
	...

000000000040f2f0 <__swc_fn_e121059d_000154_86f1d437>:
  40f2f0:	vxorps xmm0,xmm0,xmm0
  40f2f4:	vmovups XMMWORD PTR [rcx],xmm0
  40f2f8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f2fd:	ret
	...

000000000040f300 <__swc_fn_e121059d_000157_86f1d437>:
  40f300:	vxorps xmm0,xmm0,xmm0
  40f304:	vmovups XMMWORD PTR [rcx],xmm0
  40f308:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f30d:	vxorps xmm0,xmm0,xmm0
  40f311:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40f316:	vmovups xmm0,XMMWORD PTR [rip+0x4502]        # 413820 <__swc_rdata_base_e121059d+0x710>
  40f31e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40f323:	vxorps xmm0,xmm0,xmm0
  40f327:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40f32c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40f331:	vxorps xmm0,xmm0,xmm0
  40f335:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40f33a:	mov    QWORD PTR [rcx+0x70],0x0
  40f342:	ret
	...

000000000040f350 <__swc_fn_e121059d_000160_86f1d437>:
  40f350:	vxorps xmm0,xmm0,xmm0
  40f354:	vmovups XMMWORD PTR [rcx],xmm0
  40f358:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f35d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40f362:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40f367:	ret
	...

000000000040f370 <__swc_fn_e121059d_000163_e36363a8>:
  40f370:	push   rsi
  40f371:	push   rdi
  40f372:	sub    rsp,0x8
  40f376:	mov    rsi,rcx
  40f379:	mov    rdi,QWORD PTR [rsi+0x50]
  40f37d:	test   rdi,rdi
  40f380:	je     40f387 <__swc_fn_e121059d_000163_e36363a8+0x17>
  40f382:	mov    rcx,rsi
  40f385:	call   rdi
  40f387:	mov    QWORD PTR [rsi+0x20],0x0
  40f38f:	mov    rax,QWORD PTR [rsi+0x30]
  40f393:	test   rax,rax
  40f396:	je     40f3c4 <__swc_fn_e121059d_000163_e36363a8+0x54>
  40f398:	nop    DWORD PTR [rax+rax*1+0x0]
  40f3a0:	mov    rdi,QWORD PTR [rax+0x8]
  40f3a4:	mov    rcx,rsi
  40f3a7:	mov    rdx,QWORD PTR [rax+0x10]
  40f3ab:	mov    rax,QWORD PTR [rax+0x18]
  40f3af:	mov    r8,rax
  40f3b2:	call   412730 <__swc_fn_e121059d_000161_47b270e1>
  40f3b7:	mov    QWORD PTR [rsi+0x30],rdi
  40f3bb:	mov    rax,QWORD PTR [rsi+0x30]
  40f3bf:	test   rax,rax
  40f3c2:	jne    40f3a0 <__swc_fn_e121059d_000163_e36363a8+0x30>
  40f3c4:	mov    QWORD PTR [rsi+0x38],0x0
  40f3cc:	add    rsp,0x8
  40f3d0:	pop    rdi
  40f3d1:	pop    rsi
  40f3d2:	ret
	...

000000000040f3e0 <__swc_fn_e121059d_000166_016ee66a>:
  40f3e0:	push   rbx
  40f3e1:	push   rsi
  40f3e2:	push   rdi
  40f3e3:	push   r12
  40f3e5:	sub    rsp,0x188
  40f3ec:	mov    rbx,rcx
  40f3ef:	lea    rsi,[rip+0x17992]        # 426d88 <__swc_bss_base_e121059d+0x2d48>
  40f3f6:	mov    rcx,rsi
  40f3f9:	call   412140 <__swc_fn_e121059d_000140_86bb0f90>
  40f3fe:	mov    rax,QWORD PTR [rip+0x1798b]        # 426d90 <__swc_bss_base_e121059d+0x2d50>
  40f405:	mov    rdi,rax
  40f408:	test   rdi,rdi
  40f40b:	je     40f439 <__swc_fn_e121059d_000166_016ee66a+0x59>
  40f40d:	nop    DWORD PTR [rax]
  40f410:	cmp    QWORD PTR [rdi+0x8],rbx
  40f414:	jne    40f42e <__swc_fn_e121059d_000166_016ee66a+0x4e>
  40f416:	mov    rcx,rsi
  40f419:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  40f41e:	mov    rax,rdi
  40f421:	add    rsp,0x188
  40f428:	pop    r12
  40f42a:	pop    rdi
  40f42b:	pop    rsi
  40f42c:	pop    rbx
  40f42d:	ret
  40f42e:	mov    rax,QWORD PTR [rdi]
  40f431:	mov    rdi,rax
  40f434:	test   rax,rax
  40f437:	jne    40f410 <__swc_fn_e121059d_000166_016ee66a+0x30>
  40f439:	call   40aae0 <__swc_fn_e121059d_000144_d299b428>
  40f43e:	mov    rdi,rax
  40f441:	test   rax,rax
  40f444:	jne    40f45d <__swc_fn_e121059d_000166_016ee66a+0x7d>
  40f446:	mov    rcx,rsi
  40f449:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  40f44e:	xor    eax,eax
  40f450:	add    rsp,0x188
  40f457:	pop    r12
  40f459:	pop    rdi
  40f45a:	pop    rsi
  40f45b:	pop    rbx
  40f45c:	ret
  40f45d:	lea    rax,[rsp+0x18]
  40f462:	mov    QWORD PTR [rax+0x10],0x0
  40f46a:	mov    QWORD PTR [rax+0x18],0x0
  40f472:	mov    DWORD PTR [rax+0x20],0x0
  40f479:	mov    BYTE PTR [rax+0x24],0x0
  40f47d:	mov    rax,QWORD PTR [rip+0x1790c]        # 426d90 <__swc_bss_base_e121059d+0x2d50>
  40f484:	mov    QWORD PTR [rsp+0x18],rax
  40f489:	mov    QWORD PTR [rsp+0x20],rbx
  40f48e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40f494:	vmovups XMMWORD PTR [rdi],xmm0
  40f498:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40f49e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  40f4a3:	mov    rax,QWORD PTR [rsp+0x38]
  40f4a8:	mov    QWORD PTR [rdi+0x20],rax
  40f4ac:	mov    QWORD PTR [rip+0x178dd],rdi        # 426d90 <__swc_bss_base_e121059d+0x2d50>
  40f4b3:	lea    rax,[rsp+0x40]
  40f4b8:	mov    QWORD PTR [rax],0x0
  40f4bf:	mov    rcx,rbx
  40f4c2:	mov    rdx,rax
  40f4c5:	call   412220 <__swc_fn_e121059d_000146_1534de9a>
  40f4ca:	mov    rbx,rax
  40f4cd:	test   rax,rax
  40f4d0:	jne    40f4ea <__swc_fn_e121059d_000166_016ee66a+0x10a>
  40f4d2:	mov    rcx,rsi
  40f4d5:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  40f4da:	mov    rax,rdi
  40f4dd:	add    rsp,0x188
  40f4e4:	pop    r12
  40f4e6:	pop    rdi
  40f4e7:	pop    rsi
  40f4e8:	pop    rbx
  40f4e9:	ret
  40f4ea:	lea    r12,[rsp+0x50]
  40f4ef:	mov    QWORD PTR [r12],0x0
  40f4f7:	mov    rcx,rbx
  40f4fa:	mov    rdx,QWORD PTR [rsp+0x40]
  40f4ff:	mov    r8,r12
  40f502:	call   40ab90 <__swc_fn_e121059d_000147_162f363d>
  40f507:	test   rax,rax
  40f50a:	jne    40f524 <__swc_fn_e121059d_000166_016ee66a+0x144>
  40f50c:	mov    rcx,rsi
  40f50f:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  40f514:	mov    rax,rdi
  40f517:	add    rsp,0x188
  40f51e:	pop    r12
  40f520:	pop    rdi
  40f521:	pop    rsi
  40f522:	pop    rbx
  40f523:	ret
  40f524:	cmp    QWORD PTR [r12],0x10
  40f529:	jb     40f62c <__swc_fn_e121059d_000166_016ee66a+0x24c>
  40f52f:	mov    ecx,DWORD PTR [rax]
  40f531:	cmp    ecx,0x42445753
  40f537:	jne    40f62c <__swc_fn_e121059d_000166_016ee66a+0x24c>
  40f53d:	mov    ecx,DWORD PTR [rax+0x4]
  40f540:	cmp    ecx,0x1
  40f543:	jne    40f62c <__swc_fn_e121059d_000166_016ee66a+0x24c>
  40f549:	mov    ecx,DWORD PTR [rax+0x8]
  40f54c:	mov    edx,DWORD PTR [rax+0xc]
  40f54f:	imul   r8,rcx,0x14
  40f553:	mov    r9,QWORD PTR [rsp+0x50]
  40f558:	sub    r9,0x10
  40f55c:	cmp    r8,r9
  40f55f:	ja     40f62c <__swc_fn_e121059d_000166_016ee66a+0x24c>
  40f565:	lea    r8,[r8+0x10]
  40f569:	cmp    rdx,r8
  40f56c:	jb     40f62c <__swc_fn_e121059d_000166_016ee66a+0x24c>
  40f572:	mov    r8,QWORD PTR [rsp+0x50]
  40f577:	cmp    rdx,r8
  40f57a:	ja     40f62c <__swc_fn_e121059d_000166_016ee66a+0x24c>
  40f580:	xor    r8d,r8d
  40f583:	test   rcx,rcx
  40f586:	jbe    40f652 <__swc_fn_e121059d_000166_016ee66a+0x272>
  40f58c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  40f592:	cs nop WORD PTR [rax+rax*1+0x0]
  40f59c:	nop    DWORD PTR [rax+0x0]
  40f5a0:	imul   r9,r8,0x14
  40f5a4:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  40f5a9:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  40f5ae:	add    r10,r11
  40f5b1:	movabs r11,0x100000000
  40f5bb:	cmp    r10,r11
  40f5be:	ja     40f62c <__swc_fn_e121059d_000166_016ee66a+0x24c>
  40f5c0:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  40f5c5:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  40f5ca:	test   r10d,r10d
  40f5cd:	setne  r11b
  40f5d1:	je     40f5eb <__swc_fn_e121059d_000166_016ee66a+0x20b>
  40f5d3:	cmp    r10d,edx
  40f5d6:	setb   r11b
  40f5da:	jb     40f5eb <__swc_fn_e121059d_000166_016ee66a+0x20b>
  40f5dc:	vmovq  r11,xmm1
  40f5e1:	cmp    r10,r11
  40f5e4:	setae  r10b
  40f5e8:	mov    r11b,r10b
  40f5eb:	mov    r10,r11
  40f5ee:	test   r11b,r11b
  40f5f1:	jne    40f618 <__swc_fn_e121059d_000166_016ee66a+0x238>
  40f5f3:	test   r9d,r9d
  40f5f6:	setne  r10b
  40f5fa:	je     40f618 <__swc_fn_e121059d_000166_016ee66a+0x238>
  40f5fc:	cmp    r9d,edx
  40f5ff:	setb   r10b
  40f603:	jb     40f618 <__swc_fn_e121059d_000166_016ee66a+0x238>
  40f605:	vmovq  r10,xmm1
  40f60a:	cmp    r9,r10
  40f60d:	setae  r9b
  40f611:	movzx  r9d,r9b
  40f615:	mov    r10b,r9b
  40f618:	test   r10b,r10b
  40f61b:	jne    40f62c <__swc_fn_e121059d_000166_016ee66a+0x24c>
  40f61d:	add    r8,0x1
  40f621:	cmp    r8,rcx
  40f624:	jb     40f5a0 <__swc_fn_e121059d_000166_016ee66a+0x1c0>
  40f62a:	jmp    40f652 <__swc_fn_e121059d_000166_016ee66a+0x272>
  40f62c:	xor    ecx,ecx
  40f62e:	cmp    rax,rbx
  40f631:	cmovne rcx,rax
  40f635:	call   40e0f0 <__swc_fn_e121059d_000148_d7edc04f>
  40f63a:	mov    rcx,rsi
  40f63d:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  40f642:	mov    rax,rdi
  40f645:	add    rsp,0x188
  40f64c:	pop    r12
  40f64e:	pop    rdi
  40f64f:	pop    rsi
  40f650:	pop    rbx
  40f651:	ret
  40f652:	mov    QWORD PTR [rdi+0x10],rax
  40f656:	mov    rcx,QWORD PTR [rsp+0x50]
  40f65b:	mov    QWORD PTR [rdi+0x18],rcx
  40f65f:	mov    eax,DWORD PTR [rax+0x8]
  40f662:	mov    DWORD PTR [rdi+0x20],eax
  40f665:	rex mov BYTE PTR [rdi+0x24],0x1
  40f66a:	mov    rcx,rsi
  40f66d:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  40f672:	mov    rax,rdi
  40f675:	add    rsp,0x188
  40f67c:	pop    r12
  40f67e:	pop    rdi
  40f67f:	pop    rsi
  40f680:	pop    rbx
  40f681:	ret
	...

000000000040f690 <__swc_fn_e121059d_000169_3459066f>:
  40f690:	push   rsi
  40f691:	push   rdi
  40f692:	push   r12
  40f694:	mov    rsi,rdx
  40f697:	mov    rdi,rcx
  40f69a:	mov    rcx,QWORD PTR [rip+0x1499f]        # 424040 <__swc_bss_base_e121059d>
  40f6a1:	test   rcx,rcx
  40f6a4:	jne    40f6b6 <__swc_fn_e121059d_000169_3459066f+0x26>
  40f6a6:	call   412a40 <__swc_fn_e121059d_000170_994c8876>
  40f6ab:	lea    rcx,[rax+0x1]
  40f6af:	mov    QWORD PTR [rip+0x1498a],rcx        # 424040 <__swc_bss_base_e121059d>
  40f6b6:	dec    rcx
  40f6b9:	call   40f6e0 <__swc_fn_e121059d_000172_360af05d>
  40f6be:	mov    r12,QWORD PTR [rax+0xbe0]
  40f6c5:	test   r12,r12
  40f6c8:	setne  al
  40f6cb:	je     40f6d6 <__swc_fn_e121059d_000169_3459066f+0x46>
  40f6cd:	mov    rcx,rdi
  40f6d0:	mov    rdx,rsi
  40f6d3:	call   r12
  40f6d6:	pop    r12
  40f6d8:	pop    rdi
  40f6d9:	pop    rsi
  40f6da:	ret
  40f6db:	add    BYTE PTR [rax],al
  40f6dd:	add    BYTE PTR [rax],al
	...

000000000040f6e0 <__swc_fn_e121059d_000172_360af05d>:
  40f6e0:	push   r12
  40f6e2:	push   rdi
  40f6e3:	push   rsi
  40f6e4:	sub    rsp,0xd0
  40f6eb:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40f6f1:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40f6f7:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40f6fd:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40f703:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40f709:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40f70f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40f718:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40f721:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40f72a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40f733:	mov    r12,rcx
  40f736:	mov    edi,ecx
  40f738:	xor    eax,eax
  40f73a:	call   407000 <pthread_getspecific@plt>
  40f73f:	test   rax,rax
  40f742:	je     40f746 <__swc_fn_e121059d_000172_360af05d+0x66>
  40f744:	jmp    40f74e <__swc_fn_e121059d_000172_360af05d+0x6e>
  40f746:	mov    rcx,r12
  40f749:	call   412aa0 <__swc_fn_e121059d_000173_cbeff767>
  40f74e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40f754:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40f75a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40f760:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40f766:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40f76c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40f772:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40f77b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40f784:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40f78d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40f796:	add    rsp,0xd0
  40f79d:	pop    rsi
  40f79e:	pop    rdi
  40f79f:	pop    r12
  40f7a1:	ret
	...

000000000040f7b0 <__swc_fn_e121059d_000175_5eac0ab4>:
  40f7b0:	push   rsi
  40f7b1:	sub    rsp,0x30
  40f7b5:	lea    rsi,[rip+0x175e4]        # 426da0 <__swc_bss_base_e121059d+0x2d60>
  40f7bc:	mov    rax,QWORD PTR [rsi]
  40f7bf:	test   rax,rax
  40f7c2:	je     40f7ca <__swc_fn_e121059d_000175_5eac0ab4+0x1a>
  40f7c4:	add    rsp,0x30
  40f7c8:	pop    rsi
  40f7c9:	ret
  40f7ca:	mov    ecx,0x3
  40f7cf:	mov    edx,0x10
  40f7d4:	call   40d250 <__swc_fn_e121059d_000112_6814119b>
  40f7d9:	test   rax,rax
  40f7dc:	jne    40f7ed <__swc_fn_e121059d_000175_5eac0ab4+0x3d>
  40f7de:	mov    QWORD PTR [rsp+0x18],rax
  40f7e3:	call   40a620 <__swc_fn_e121059d_000123_be2e2f68>
  40f7e8:	mov    rax,QWORD PTR [rsp+0x18]
  40f7ed:	mov    rcx,rax
  40f7f0:	xchg   QWORD PTR [rsi],rcx
  40f7f3:	add    rsp,0x30
  40f7f7:	pop    rsi
  40f7f8:	ret
  40f7f9:	add    BYTE PTR [rax],al
  40f7fb:	add    BYTE PTR [rax],al
  40f7fd:	add    BYTE PTR [rax],al
	...

000000000040f800 <__swc_fn_e121059d_000178_cf4ffedd>:
  40f800:	push   rsi
  40f801:	push   rdi
  40f802:	sub    rsp,0x8
  40f806:	mov    rsi,rdx
  40f809:	mov    rdi,rcx
  40f80c:	mov    rax,QWORD PTR [rsi+0x8]
  40f810:	test   rax,rax
  40f813:	je     40f81d <__swc_fn_e121059d_000178_cf4ffedd+0x1d>
  40f815:	mov    rcx,QWORD PTR [rsi]
  40f818:	mov    QWORD PTR [rax],rcx
  40f81b:	jmp    40f824 <__swc_fn_e121059d_000178_cf4ffedd+0x24>
  40f81d:	mov    rax,QWORD PTR [rsi]
  40f820:	mov    QWORD PTR [rdi+0x8],rax
  40f824:	mov    rax,QWORD PTR [rsi]
  40f827:	test   rax,rax
  40f82a:	je     40f834 <__swc_fn_e121059d_000178_cf4ffedd+0x34>
  40f82c:	mov    rcx,QWORD PTR [rsi+0x8]
  40f830:	mov    QWORD PTR [rax+0x8],rcx
  40f834:	mov    rcx,rdi
  40f837:	mov    rdx,QWORD PTR [rsi+0x10]
  40f83b:	mov    r8,QWORD PTR [rsi+0x18]
  40f83f:	mov    r9,0xffffffffffffffff
  40f846:	call   40b1e0 <__swc_fn_e121059d_000177_4de704de>
  40f84b:	mov    QWORD PTR [rsi+0x18],0x0
  40f853:	mov    rax,QWORD PTR [rdi+0x8]
  40f857:	test   rax,rax
  40f85a:	jne    40f86c <__swc_fn_e121059d_000178_cf4ffedd+0x6c>
  40f85c:	call   40f7b0 <__swc_fn_e121059d_000175_5eac0ab4>
  40f861:	xor    ecx,ecx
  40f863:	mov    QWORD PTR [rax+0x8],rcx
  40f867:	xor    ecx,ecx
  40f869:	mov    QWORD PTR [rax],rcx
  40f86c:	add    rsp,0x8
  40f870:	pop    rdi
  40f871:	pop    rsi
  40f872:	ret
	...

000000000040f880 <__swc_fn_e121059d_000002_1ca87929>:
  40f880:	push   rdi
  40f881:	push   rsi
  40f882:	sub    rsp,0xb8
  40f889:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40f88f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40f895:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40f89b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40f8a1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40f8a7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40f8ad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40f8b3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40f8bc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40f8c5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40f8ce:	vxorps xmm0,xmm0,xmm0
  40f8d2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f8d8:	mov    edi,0x1
  40f8dd:	lea    rsi,[rsp+0x8]
  40f8e2:	xor    eax,eax
  40f8e4:	call   4071b0 <clock_gettime@plt>
  40f8e9:	vxorpd xmm0,xmm0,xmm0
  40f8ed:	mov    rax,QWORD PTR [rsp+0x8]
  40f8f2:	vcvtsi2sd xmm0,xmm0,rax
  40f8f7:	vxorpd xmm1,xmm1,xmm1
  40f8fb:	mov    rax,QWORD PTR [rsp+0x10]
  40f900:	vcvtsi2sd xmm1,xmm1,rax
  40f905:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x3803]        # 413110 <__swc_rdata_base_e121059d>
  40f90d:	vaddsd xmm0,xmm0,xmm1
  40f911:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40f917:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40f91d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40f923:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40f929:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40f92f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40f935:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40f93b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40f944:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40f94d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40f956:	add    rsp,0xb8
  40f95d:	pop    rsi
  40f95e:	pop    rdi
  40f95f:	ret

000000000040f960 <__swc_fn_e121059d_000005_9ee35b18>:
  40f960:	vxorps xmm0,xmm0,xmm0
  40f964:	xor    eax,eax
  40f966:	cs nop WORD PTR [rax+rax*1+0x0]
  40f970:	cs nop WORD PTR [rax+rax*1+0x0]
  40f97a:	nop    WORD PTR [rax+rax*1+0x0]
  40f980:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40f985:	add    rax,0x10
  40f989:	cmp    rax,0x2080
  40f990:	jne    40f980 <__swc_fn_e121059d_000005_9ee35b18+0x20>
  40f992:	ret
	...

000000000040f9a0 <__swc_fn_e121059d_000008_d64b2baa>:
  40f9a0:	push   rsi
  40f9a1:	push   rdi
  40f9a2:	push   r12
  40f9a4:	push   r13
  40f9a6:	push   r14
  40f9a8:	mov    rsi,rcx
  40f9ab:	mov    edi,r10d
  40f9ae:	mov    r12,rcx
  40f9b1:	mov    r13,r9
  40f9b4:	mov    ecx,DWORD PTR [rdx+0x28]
  40f9b7:	shlx   r14d,r8d,ecx
  40f9bc:	mov    rcx,rdx
  40f9bf:	mov    edx,r8d
  40f9c2:	call   4085e0 <__swc_fn_e121059d_000015_9dea5065>
  40f9c7:	mov    rcx,rax
  40f9ca:	mov    eax,DWORD PTR [r12+0x3c]
  40f9cf:	xor    edx,edx
  40f9d1:	div    rdi
  40f9d4:	vxorps xmm0,xmm0,xmm0
  40f9d8:	vmovdqu XMMWORD PTR [rsi],xmm0
  40f9dc:	mov    QWORD PTR [r12+0x60],0x0
  40f9e5:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40f9ea:	mov    QWORD PTR [r12+0x10],rcx
  40f9ef:	imul   rax,rdi
  40f9f3:	lea    rdx,[rcx+rax*1]
  40f9f7:	mov    QWORD PTR [r12+0x18],rdx
  40f9fc:	mov    QWORD PTR [r12+0x20],rcx
  40fa01:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40fa06:	mov    DWORD PTR [r12+0x28],0x0
  40fa0f:	mov    DWORD PTR [r12+0x68],0x0
  40fa18:	mov    BYTE PTR [r12+0x39],r13b
  40fa1d:	mov    BYTE PTR [r12+0x3a],r14b
  40fa22:	mov    BYTE PTR [r12+0x3b],0x1
  40fa28:	mov    DWORD PTR [r12+0x6c],0x0
  40fa31:	mov    rcx,r12
  40fa34:	mov    edx,edi
  40fa36:	call   408540 <__swc_fn_e121059d_000009_065ed5b1>
  40fa3b:	pop    r14
  40fa3d:	pop    r13
  40fa3f:	pop    r12
  40fa41:	pop    rdi
  40fa42:	pop    rsi
  40fa43:	ret
	...

000000000040fa50 <__swc_fn_e121059d_000011_c3647f66>:
  40fa50:	mov    r8d,0x1
  40fa56:	xor    eax,eax
  40fa58:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40fa5e:	test   eax,eax
  40fa60:	jne    40fa50 <__swc_fn_e121059d_000011_c3647f66>
  40fa62:	ret
	...

000000000040fa70 <__swc_fn_e121059d_000014_524c1f23>:
  40fa70:	lea    r8,[rcx+0x60]
  40fa74:	mov    rax,QWORD PTR [r8]
  40fa77:	mov    r9,rax
  40fa7a:	nop    WORD PTR [rax+rax*1+0x0]
  40fa80:	mov    QWORD PTR [rdx],r9
  40fa83:	mov    rax,r9
  40fa86:	lock cmpxchg QWORD PTR [r8],rdx
  40fa8b:	cmp    rax,r9
  40fa8e:	jne    40faf7 <__swc_fn_e121059d_000014_524c1f23+0x87>
  40fa90:	mov    eax,DWORD PTR [rcx+0x6c]
  40fa93:	test   eax,eax
  40fa95:	je     40faf6 <__swc_fn_e121059d_000014_524c1f23+0x86>
  40fa97:	lea    rdx,[rcx+0x70]
  40fa9b:	mov    r9d,0x1
  40faa1:	xor    eax,eax
  40faa3:	lock cmpxchg DWORD PTR [rdx],r9d
  40faa8:	test   eax,eax
  40faaa:	jne    40faf6 <__swc_fn_e121059d_000014_524c1f23+0x86>
  40faac:	mov    rax,rcx
  40faaf:	and    rax,0xffffffffffc00000
  40fab6:	mov    rax,QWORD PTR [rax+0x8]
  40faba:	test   rax,rax
  40fabd:	jne    40fac5 <__swc_fn_e121059d_000014_524c1f23+0x55>
  40fabf:	xor    eax,eax
  40fac1:	xchg   DWORD PTR [rdx],eax
  40fac3:	jmp    40faf6 <__swc_fn_e121059d_000014_524c1f23+0x86>
  40fac5:	lea    rdx,[rax+0x2a80]
  40facc:	mov    rax,QWORD PTR [rdx]
  40facf:	mov    r8,rax
  40fad2:	cs nop WORD PTR [rax+rax*1+0x0]
  40fadc:	nop    DWORD PTR [rax+0x0]
  40fae0:	mov    QWORD PTR [rcx+0x78],r8
  40fae4:	mov    rax,r8
  40fae7:	lock cmpxchg QWORD PTR [rdx],rcx
  40faec:	cmp    rax,r8
  40faef:	je     40faf6 <__swc_fn_e121059d_000014_524c1f23+0x86>
  40faf1:	mov    r8,rax
  40faf4:	jmp    40fae0 <__swc_fn_e121059d_000014_524c1f23+0x70>
  40faf6:	ret
  40faf7:	mov    r9,rax
  40fafa:	jmp    40fa80 <__swc_fn_e121059d_000014_524c1f23+0x10>
	...

000000000040fb00 <__swc_fn_e121059d_000017_efc44797>:
  40fb00:	push   rsi
  40fb01:	push   rdi
  40fb02:	push   r12
  40fb04:	push   r13
  40fb06:	push   r14
  40fb08:	push   r15
  40fb0a:	push   rbx
  40fb0b:	sub    rsp,0x30
  40fb0f:	mov    QWORD PTR [rsp+0x18],r8
  40fb14:	mov    rsi,rcx
  40fb17:	mov    rdi,rdx
  40fb1a:	mov    rdx,QWORD PTR [rsi+0x40]
  40fb1e:	xchg   ax,ax
  40fb20:	mov    rax,rdx
  40fb23:	not    rax
  40fb26:	and    rax,QWORD PTR [rsi+0x20]
  40fb2a:	test   rax,rax
  40fb2d:	jne    40fb41 <__swc_fn_e121059d_000017_efc44797+0x41>
  40fb2f:	xor    eax,eax
  40fb31:	add    rsp,0x30
  40fb35:	pop    rbx
  40fb36:	pop    r15
  40fb38:	pop    r14
  40fb3a:	pop    r13
  40fb3c:	pop    r12
  40fb3e:	pop    rdi
  40fb3f:	pop    rsi
  40fb40:	ret
  40fb41:	xor    ecx,ecx
  40fb43:	tzcnt  rcx,rax
  40fb48:	lea    r12,[rsp+0x8]
  40fb4d:	mov    DWORD PTR [rsp+0x8],ecx
  40fb51:	mov    r13d,0x1
  40fb57:	shl    r13,cl
  40fb5a:	mov    rcx,rdx
  40fb5d:	or     rcx,r13
  40fb60:	mov    rax,rdx
  40fb63:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40fb69:	cmp    rax,rdx
  40fb6c:	je     40fb73 <__swc_fn_e121059d_000017_efc44797+0x73>
  40fb6e:	mov    rdx,rax
  40fb71:	jmp    40fb20 <__swc_fn_e121059d_000017_efc44797+0x20>
  40fb73:	mov    eax,DWORD PTR [r12]
  40fb77:	shl    rax,0x4
  40fb7b:	lea    r14,[rsi+rax*8+0x80]
  40fb83:	mov    rcx,rsi
  40fb86:	mov    rax,r12
  40fb89:	mov    edx,DWORD PTR [rax]
  40fb8b:	call   4085e0 <__swc_fn_e121059d_000015_9dea5065>
  40fb90:	mov    r15,rax
  40fb93:	mov    rcx,rsi
  40fb96:	mov    rdx,r13
  40fb99:	call   408740 <__swc_fn_e121059d_000021_fd2b165c>
  40fb9e:	test   al,al
  40fba0:	je     40fbd8 <__swc_fn_e121059d_000017_efc44797+0xd8>
  40fba2:	mov    ecx,DWORD PTR [r14+0x3c]
  40fba6:	lea    rdx,[rip+0x144b3]        # 424060 <__swc_bss_base_e121059d+0x20>
  40fbad:	mov    r8,QWORD PTR [rip+0x144ac]        # 424060 <__swc_bss_base_e121059d+0x20>
  40fbb4:	cs nop WORD PTR [rax+rax*1+0x0]
  40fbbe:	xchg   ax,ax
  40fbc0:	mov    r9,r8
  40fbc3:	sub    r9,rcx
  40fbc6:	mov    rax,r8
  40fbc9:	lock cmpxchg QWORD PTR [rdx],r9
  40fbce:	cmp    rax,r8
  40fbd1:	je     40fc39 <__swc_fn_e121059d_000017_efc44797+0x139>
  40fbd3:	mov    r8,rax
  40fbd6:	jmp    40fbc0 <__swc_fn_e121059d_000017_efc44797+0xc0>
  40fbd8:	mov    rcx,rsi
  40fbdb:	mov    rax,r12
  40fbde:	mov    edx,DWORD PTR [rax]
  40fbe0:	call   40b520 <__swc_fn_e121059d_000016_9afb7cfb>
  40fbe5:	mov    rcx,r15
  40fbe8:	and    rcx,0xffffffffffff0000
  40fbef:	lea    rcx,[rcx+0x10000]
  40fbf6:	mov    rbx,rax
  40fbf9:	cmp    rax,rcx
  40fbfc:	cmova  rbx,rcx
  40fc00:	mov    rax,rbx
  40fc03:	sub    rax,r15
  40fc06:	mov    rcx,r15
  40fc09:	mov    rdx,rax
  40fc0c:	call   40b370 <__swc_fn_e121059d_000007_f7acedb0>
  40fc11:	test   al,al
  40fc13:	jne    40fc32 <__swc_fn_e121059d_000017_efc44797+0x132>
  40fc15:	mov    rcx,rsi
  40fc18:	mov    rdx,r13
  40fc1b:	call   40b6d0 <__swc_fn_e121059d_000022_c8f5f27c>
  40fc20:	xor    eax,eax
  40fc22:	add    rsp,0x30
  40fc26:	pop    rbx
  40fc27:	pop    r15
  40fc29:	pop    r14
  40fc2b:	pop    r13
  40fc2d:	pop    r12
  40fc2f:	pop    rdi
  40fc30:	pop    rsi
  40fc31:	ret
  40fc32:	sub    rbx,r15
  40fc35:	mov    DWORD PTR [r14+0x3c],ebx
  40fc39:	mov    rcx,r14
  40fc3c:	mov    rdx,rsi
  40fc3f:	mov    r8d,DWORD PTR [r12]
  40fc43:	mov    r9d,edi
  40fc46:	mov    rbx,QWORD PTR [rsp+0x18]
  40fc4b:	mov    r10d,ebx
  40fc4e:	call   40f9a0 <__swc_fn_e121059d_000008_d64b2baa>
  40fc53:	mov    rax,r14
  40fc56:	add    rsp,0x30
  40fc5a:	pop    rbx
  40fc5b:	pop    r15
  40fc5d:	pop    r14
  40fc5f:	pop    r13
  40fc61:	pop    r12
  40fc63:	pop    rdi
  40fc64:	pop    rsi
  40fc65:	ret
	...

000000000040fc70 <__swc_fn_e121059d_000020_de02dbdf>:
  40fc70:	mov    r8,QWORD PTR [rcx+0x48]
  40fc74:	cs nop WORD PTR [rax+rax*1+0x0]
  40fc7e:	xchg   ax,ax
  40fc80:	mov    r9,r8
  40fc83:	or     r9,rdx
  40fc86:	mov    rax,r8
  40fc89:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40fc8f:	cmp    rax,r8
  40fc92:	jne    40fc95 <__swc_fn_e121059d_000020_de02dbdf+0x25>
  40fc94:	ret
  40fc95:	mov    r8,rax
  40fc98:	jmp    40fc80 <__swc_fn_e121059d_000020_de02dbdf+0x10>
  40fc9a:	add    BYTE PTR [rax],al
  40fc9c:	add    BYTE PTR [rax],al
	...

000000000040fca0 <__swc_fn_e121059d_000023_2d0fcd2c>:
  40fca0:	push   rsi
  40fca1:	push   rdi
  40fca2:	push   r12
  40fca4:	mov    rsi,rcx
  40fca7:	xor    edi,edi
  40fca9:	lea    r12,[rip+0x143c0]        # 424070 <__swc_bss_base_e121059d+0x30>
  40fcb0:	mov    eax,DWORD PTR [r12]
  40fcb4:	xor    ecx,ecx
  40fcb6:	test   rax,rax
  40fcb9:	jbe    40fcf4 <__swc_fn_e121059d_000023_2d0fcd2c+0x54>
  40fcbb:	nop    DWORD PTR [rax+rax*1+0x0]
  40fcc0:	lea    rdx,[rip+0x143b1]        # 424078 <__swc_bss_base_e121059d+0x38>
  40fcc7:	mov    r8d,ecx
  40fcca:	lea    r8,[r8+r8*2]
  40fcce:	lea    r8,[rdx+r8*8]
  40fcd2:	mov    rdx,QWORD PTR [r8+0x10]
  40fcd6:	add    rdx,0x400000
  40fcdd:	cmp    rdx,0x40000000
  40fce4:	ja     40fceb <__swc_fn_e121059d_000023_2d0fcd2c+0x4b>
  40fce6:	mov    rdi,r8
  40fce9:	jmp    40fcf4 <__swc_fn_e121059d_000023_2d0fcd2c+0x54>
  40fceb:	add    rcx,0x1
  40fcef:	cmp    rcx,rax
  40fcf2:	jb     40fcc0 <__swc_fn_e121059d_000023_2d0fcd2c+0x20>
  40fcf4:	test   rdi,rdi
  40fcf7:	jne    40fd83 <__swc_fn_e121059d_000023_2d0fcd2c+0xe3>
  40fcfd:	cmp    DWORD PTR [r12],0x10
  40fd02:	jae    40fd6b <__swc_fn_e121059d_000023_2d0fcd2c+0xcb>
  40fd04:	mov    ecx,0x40400000
  40fd09:	call   408500 <__swc_fn_e121059d_000006_81d2e1e9>
  40fd0e:	test   rax,rax
  40fd11:	je     40fd6b <__swc_fn_e121059d_000023_2d0fcd2c+0xcb>
  40fd13:	lea    rcx,[rip+0x1435e]        # 424078 <__swc_bss_base_e121059d+0x38>
  40fd1a:	mov    edx,DWORD PTR [r12]
  40fd1e:	lea    rdx,[rdx+rdx*2]
  40fd22:	lea    rdx,[rcx+rdx*8]
  40fd26:	mov    QWORD PTR [rdx],rax
  40fd29:	lea    rax,[rax+0x3fffff]
  40fd30:	and    rax,0xffffffffffc00000
  40fd37:	mov    QWORD PTR [rdx+0x8],rax
  40fd3b:	mov    QWORD PTR [rdx+0x10],0x0
  40fd43:	mov    edx,DWORD PTR [rip+0x14327]        # 424070 <__swc_bss_base_e121059d+0x30>
  40fd49:	nop    DWORD PTR [rax+0x0]
  40fd50:	lea    r9d,[rdx+0x1]
  40fd54:	mov    rax,rdx
  40fd57:	lock cmpxchg DWORD PTR [r12],r9d
  40fd5d:	mov    r8d,eax
  40fd60:	cmp    eax,edx
  40fd62:	je     40fd72 <__swc_fn_e121059d_000023_2d0fcd2c+0xd2>
  40fd64:	mov    rdx,r8
  40fd67:	jmp    40fd50 <__swc_fn_e121059d_000023_2d0fcd2c+0xb0>
  40fd69:	jmp    40fd72 <__swc_fn_e121059d_000023_2d0fcd2c+0xd2>
  40fd6b:	xor    eax,eax
  40fd6d:	pop    r12
  40fd6f:	pop    rdi
  40fd70:	pop    rsi
  40fd71:	ret
  40fd72:	mov    eax,DWORD PTR [rip+0x142f8]        # 424070 <__swc_bss_base_e121059d+0x30>
  40fd78:	sub    eax,0x1
  40fd7b:	lea    rdi,[rax+rax*2]
  40fd7f:	lea    rdi,[rcx+rdi*8]
  40fd83:	mov    r12,QWORD PTR [rdi+0x8]
  40fd87:	add    r12,QWORD PTR [rdi+0x10]
  40fd8b:	mov    rcx,r12
  40fd8e:	mov    edx,0x3000
  40fd93:	call   40b370 <__swc_fn_e121059d_000007_f7acedb0>
  40fd98:	test   al,al
  40fd9a:	jne    40fda3 <__swc_fn_e121059d_000023_2d0fcd2c+0x103>
  40fd9c:	xor    eax,eax
  40fd9e:	pop    r12
  40fda0:	pop    rdi
  40fda1:	pop    rsi
  40fda2:	ret
  40fda3:	vxorps xmm0,xmm0,xmm0
  40fda7:	xor    eax,eax
  40fda9:	cs nop WORD PTR [rax+rax*1+0x0]
  40fdb3:	cs nop WORD PTR [rax+rax*1+0x0]
  40fdbd:	nop    DWORD PTR [rax]
  40fdc0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40fdc6:	add    rax,0x10
  40fdca:	cmp    rax,0x3000
  40fdd1:	jne    40fdc0 <__swc_fn_e121059d_000023_2d0fcd2c+0x120>
  40fdd3:	mov    DWORD PTR [r12+0x28],esi
  40fdd8:	mov    eax,0x40
  40fddd:	mov    ecx,esi
  40fddf:	shr    eax,cl
  40fde1:	mov    DWORD PTR [r12+0x2c],eax
  40fde6:	cmp    DWORD PTR [r12+0x2c],0x40
  40fdec:	jb     40fdf7 <__swc_fn_e121059d_000023_2d0fcd2c+0x157>
  40fdee:	mov    rax,0xffffffffffffffff
  40fdf5:	jmp    40fe07 <__swc_fn_e121059d_000023_2d0fcd2c+0x167>
  40fdf7:	mov    eax,0x1
  40fdfc:	mov    ecx,DWORD PTR [r12+0x2c]
  40fe01:	shl    rax,cl
  40fe04:	dec    rax
  40fe07:	mov    QWORD PTR [r12+0x20],rax
  40fe0c:	mov    DWORD PTR [r12],0x4e540001
  40fe14:	mov    DWORD PTR [r12+0x4],0x53474d45
  40fe1d:	add    QWORD PTR [rdi+0x10],0x400000
  40fe25:	mov    rax,r12
  40fe28:	pop    r12
  40fe2a:	pop    rdi
  40fe2b:	pop    rsi
  40fe2c:	ret
  40fe2d:	add    BYTE PTR [rax],al
	...

000000000040fe30 <__swc_fn_e121059d_000026_bcdc5519>:
  40fe30:	mov    eax,0x1
  40fe35:	mov    edx,DWORD PTR [rip+0x14235]        # 424070 <__swc_bss_base_e121059d+0x30>
  40fe3b:	cmp    eax,edx
  40fe3d:	jae    40fe8b <__swc_fn_e121059d_000026_bcdc5519+0x5b>
  40fe3f:	nop
  40fe40:	lea    r8,[rip+0x14231]        # 424078 <__swc_bss_base_e121059d+0x38>
  40fe47:	lea    r9,[rax+rax*2]
  40fe4b:	lea    r9,[r8+r9*8]
  40fe4f:	mov    r8,rcx
  40fe52:	sub    r8,QWORD PTR [r9+0x8]
  40fe56:	mov    r9,QWORD PTR [r9+0x10]
  40fe5a:	cmp    r8,r9
  40fe5d:	jae    40fe85 <__swc_fn_e121059d_000026_bcdc5519+0x55>
  40fe5f:	mov    rax,rcx
  40fe62:	and    rax,0xffffffffffc00000
  40fe69:	shr    rcx,0x10
  40fe6d:	and    ecx,0x3f
  40fe70:	mov    edx,DWORD PTR [rax+0x28]
  40fe73:	shrx   ecx,ecx,edx
  40fe78:	shl    rcx,0x4
  40fe7c:	lea    rax,[rax+rcx*8+0x80]
  40fe84:	ret
  40fe85:	inc    eax
  40fe87:	cmp    eax,edx
  40fe89:	jb     40fe40 <__swc_fn_e121059d_000026_bcdc5519+0x10>
  40fe8b:	xor    eax,eax
  40fe8d:	ret
	...

000000000040fe90 <__swc_fn_e121059d_000029_9798fb47>:
  40fe90:	vxorps xmm0,xmm0,xmm0
  40fe94:	vmovups XMMWORD PTR [rcx],xmm0
  40fe98:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40fe9d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40fea2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40fea7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40feac:	mov    QWORD PTR [rcx+0x50],0x0
  40feb4:	ret
	...

000000000040fec0 <__swc_fn_e121059d_000032_9798fb47>:
  40fec0:	vxorps xmm0,xmm0,xmm0
  40fec4:	xor    eax,eax
  40fec6:	cs nop WORD PTR [rax+rax*1+0x0]
  40fed0:	cs nop WORD PTR [rax+rax*1+0x0]
  40feda:	nop    WORD PTR [rax+rax*1+0x0]
  40fee0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40fee5:	add    rax,0x10
  40fee9:	cmp    rax,0x9b0
  40fef0:	jne    40fee0 <__swc_fn_e121059d_000032_9798fb47+0x20>
  40fef2:	mov    QWORD PTR [rcx+0x9b0],0x0
  40fefd:	ret
	...

000000000040ff00 <__swc_fn_e121059d_000035_cd1a4e8c>:
  40ff00:	push   rsi
  40ff01:	push   rdi
  40ff02:	sub    rsp,0x8
  40ff06:	lea    rsi,[rip+0x12103]        # 422010 <__swc_data_base_e121059d+0x10>
  40ff0d:	mov    rax,QWORD PTR [rsi]
  40ff10:	mov    ecx,0xffffffff
  40ff15:	cmp    rax,rcx
  40ff18:	je     40ff21 <__swc_fn_e121059d_000035_cd1a4e8c+0x21>
  40ff1a:	add    rsp,0x8
  40ff1e:	pop    rdi
  40ff1f:	pop    rsi
  40ff20:	ret
  40ff21:	mov    rcx,QWORD PTR [rip+0x31d0]        # 4130f8 <__swc_fn_e121059d_000179_718d7b54+0x588>
  40ff28:	call   411ef0 <__swc_fn_e121059d_000131_4a82cdf6>
  40ff2d:	mov    rcx,rax
  40ff30:	mov    eax,0xffffffff
  40ff35:	lock cmpxchg QWORD PTR [rsi],rcx
  40ff3a:	mov    rdi,rax
  40ff3d:	mov    eax,0xffffffff
  40ff42:	cmp    rdi,rax
  40ff45:	je     40ff56 <__swc_fn_e121059d_000035_cd1a4e8c+0x56>
  40ff47:	call   40a870 <__swc_fn_e121059d_000132_a611b8c4>
  40ff4c:	mov    rax,rdi
  40ff4f:	add    rsp,0x8
  40ff53:	pop    rdi
  40ff54:	pop    rsi
  40ff55:	ret
  40ff56:	mov    rax,rcx
  40ff59:	add    rsp,0x8
  40ff5d:	pop    rdi
  40ff5e:	pop    rsi
  40ff5f:	ret

000000000040ff60 <__swc_fn_e121059d_000038_14f56618>:
  40ff60:	sub    rsp,0x8
  40ff64:	vxorps xmm0,xmm0,xmm0
  40ff68:	xor    eax,eax
  40ff6a:	cs nop WORD PTR [rax+rax*1+0x0]
  40ff74:	cs nop WORD PTR [rax+rax*1+0x0]
  40ff7e:	xchg   ax,ax
  40ff80:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40ff85:	add    rax,0x10
  40ff89:	cmp    rax,0x2b00
  40ff90:	jne    40ff80 <__swc_fn_e121059d_000038_14f56618+0x20>
  40ff92:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40ff9c:	xor    al,al
  40ff9e:	mov    rdx,rax
  40ffa1:	xor    al,al
  40ffa3:	mov    r8,rax
  40ffa6:	xor    al,al
  40ffa8:	mov    r9,rax
  40ffab:	xor    al,al
  40ffad:	mov    r10,rax
  40ffb0:	xor    al,al
  40ffb2:	mov    r11,rax
  40ffb5:	call   408970 <__swc_fn_e121059d_000039_03f1bf9a>
  40ffba:	add    rsp,0x8
  40ffbe:	ret
	...

000000000040ffc0 <__swc_fn_e121059d_000041_c90d80c1>:
  40ffc0:	push   rsi
  40ffc1:	push   rdi
  40ffc2:	push   r12
  40ffc4:	mov    rsi,r8
  40ffc7:	mov    rdi,rdx
  40ffca:	mov    rcx,rdx
  40ffcd:	call   408500 <__swc_fn_e121059d_000006_81d2e1e9>
  40ffd2:	mov    r12,rax
  40ffd5:	test   rax,rax
  40ffd8:	jne    40ffe1 <__swc_fn_e121059d_000041_c90d80c1+0x21>
  40ffda:	xor    eax,eax
  40ffdc:	pop    r12
  40ffde:	pop    rdi
  40ffdf:	pop    rsi
  40ffe0:	ret
  40ffe1:	mov    rcx,r12
  40ffe4:	mov    rdx,rsi
  40ffe7:	call   40b370 <__swc_fn_e121059d_000007_f7acedb0>
  40ffec:	test   al,al
  40ffee:	jne    410002 <__swc_fn_e121059d_000041_c90d80c1+0x42>
  40fff0:	mov    rcx,r12
  40fff3:	mov    rdx,rdi
  40fff6:	call   40d910 <__swc_fn_e121059d_000118_ed2d8fed>
  40fffb:	xor    eax,eax
  40fffd:	pop    r12
  40ffff:	pop    rdi
  410000:	pop    rsi
  410001:	ret
  410002:	mov    rax,r12
  410005:	pop    r12
  410007:	pop    rdi
  410008:	pop    rsi
  410009:	ret
	...

0000000000410020 <__swc_fn_e121059d_000044_a78ae66b>:
  410020:	push   rsi
  410021:	push   rdi
  410022:	push   r12
  410024:	mov    rsi,rcx
  410027:	mov    edx,0x9b8
  41002c:	call   4089e0 <__swc_fn_e121059d_000042_facd3e17>
  410031:	mov    rdi,rax
  410034:	test   rax,rax
  410037:	jne    410040 <__swc_fn_e121059d_000044_a78ae66b+0x20>
  410039:	xor    eax,eax
  41003b:	pop    r12
  41003d:	pop    rdi
  41003e:	pop    rsi
  41003f:	ret
  410040:	vxorps xmm0,xmm0,xmm0
  410044:	xor    eax,eax
  410046:	cs nop WORD PTR [rax+rax*1+0x0]
  410050:	cs nop WORD PTR [rax+rax*1+0x0]
  41005a:	nop    WORD PTR [rax+rax*1+0x0]
  410060:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  410065:	add    rax,0x10
  410069:	cmp    rax,0x9b0
  410070:	jne    410060 <__swc_fn_e121059d_000044_a78ae66b+0x40>
  410072:	mov    QWORD PTR [rdi+0x9b0],0x0
  41007d:	mov    QWORD PTR [rdi],rsi
  410080:	call   40a920 <__swc_fn_e121059d_000135_a9c1c700>
  410085:	mov    QWORD PTR [rdi+0x18],rax
  410089:	lea    r12,[rsi+0x10]
  41008d:	mov    rcx,r12
  410090:	call   412140 <__swc_fn_e121059d_000140_86bb0f90>
  410095:	mov    rax,QWORD PTR [rsi+0x20]
  410099:	mov    QWORD PTR [rdi+0x8],rax
  41009d:	mov    rax,QWORD PTR [rsi+0x20]
  4100a1:	test   rax,rax
  4100a4:	je     4100aa <__swc_fn_e121059d_000044_a78ae66b+0x8a>
  4100a6:	mov    QWORD PTR [rax+0x10],rdi
  4100aa:	mov    QWORD PTR [rsi+0x20],rdi
  4100ae:	mov    rcx,r12
  4100b1:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  4100b6:	mov    rax,rdi
  4100b9:	pop    r12
  4100bb:	pop    rdi
  4100bc:	pop    rsi
  4100bd:	ret
	...

00000000004100c0 <__swc_fn_e121059d_000047_6e7a8d58>:
  4100c0:	mov    rax,QWORD PTR [rdx+0x10]
  4100c4:	test   rax,rax
  4100c7:	je     4100d3 <__swc_fn_e121059d_000047_6e7a8d58+0x13>
  4100c9:	mov    rcx,QWORD PTR [rdx+0x8]
  4100cd:	mov    QWORD PTR [rax+0x8],rcx
  4100d1:	jmp    4100db <__swc_fn_e121059d_000047_6e7a8d58+0x1b>
  4100d3:	mov    rax,QWORD PTR [rdx+0x8]
  4100d7:	mov    QWORD PTR [rcx+0x20],rax
  4100db:	mov    rax,QWORD PTR [rdx+0x8]
  4100df:	test   rax,rax
  4100e2:	je     4100ec <__swc_fn_e121059d_000047_6e7a8d58+0x2c>
  4100e4:	mov    rcx,QWORD PTR [rdx+0x10]
  4100e8:	mov    QWORD PTR [rax+0x10],rcx
  4100ec:	vxorps xmm0,xmm0,xmm0
  4100f0:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  4100f5:	ret
	...

0000000000410100 <__swc_fn_e121059d_000050_129b9bf4>:
  410100:	sub    rsp,0x8
  410104:	mov    r9,r8
  410107:	mov    r10,rdx
  41010a:	call   408a90 <__swc_fn_e121059d_000048_137687bb>
  41010f:	mov    eax,0x1
  410114:	xchg   DWORD PTR [r9+0x6c],eax
  410118:	mov    rax,QWORD PTR [r9+0x60]
  41011c:	test   rax,rax
  41011f:	je     410163 <__swc_fn_e121059d_000050_129b9bf4+0x63>
  410121:	xor    eax,eax
  410123:	xchg   DWORD PTR [r9+0x6c],eax
  410127:	movzx  eax,BYTE PTR [r9+0x39]
  41012c:	lea    rax,[rax+rax*4]
  410130:	lea    rax,[r10+rax*8+0x28]
  410135:	mov    QWORD PTR [r9+0x50],0x0
  41013d:	mov    rcx,QWORD PTR [rax+0x8]
  410141:	mov    QWORD PTR [r9+0x48],rcx
  410145:	mov    rcx,QWORD PTR [rax+0x8]
  410149:	test   rcx,rcx
  41014c:	je     410154 <__swc_fn_e121059d_000050_129b9bf4+0x54>
  41014e:	mov    QWORD PTR [rcx+0x50],r9
  410152:	jmp    410158 <__swc_fn_e121059d_000050_129b9bf4+0x58>
  410154:	mov    QWORD PTR [rax+0x10],r9
  410158:	mov    QWORD PTR [rax+0x8],r9
  41015c:	xor    eax,eax
  41015e:	add    rsp,0x8
  410162:	ret
  410163:	movzx  eax,BYTE PTR [r9+0x39]
  410168:	lea    rax,[rax+rax*4]
  41016c:	lea    rax,[r10+rax*8+0x28]
  410171:	mov    QWORD PTR [r9+0x50],0x0
  410179:	mov    rcx,QWORD PTR [rax+0x18]
  41017d:	mov    QWORD PTR [r9+0x48],rcx
  410181:	mov    rcx,QWORD PTR [rax+0x18]
  410185:	test   rcx,rcx
  410188:	je     41018e <__swc_fn_e121059d_000050_129b9bf4+0x8e>
  41018a:	mov    QWORD PTR [rcx+0x50],r9
  41018e:	mov    QWORD PTR [rax+0x18],r9
  410192:	mov    eax,0x1
  410197:	add    rsp,0x8
  41019b:	ret
  41019c:	add    BYTE PTR [rax],al
	...

00000000004101a0 <__swc_fn_e121059d_000053_3af34d7f>:
  4101a0:	push   r12
  4101a2:	push   r13
  4101a4:	push   rdi
  4101a5:	push   rsi
  4101a6:	push   r14
  4101a8:	push   r15
  4101aa:	sub    rsp,0x178
  4101b1:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  4101ba:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  4101c3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  4101cc:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  4101d5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  4101de:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  4101e7:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  4101f0:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  4101f9:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  410202:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  41020b:	mov    r12,rcx
  41020e:	lea    rax,[rip+0x13ff3]        # 424208 <__swc_bss_base_e121059d+0x1c8>
  410215:	mov    rcx,QWORD PTR [rax]
  410218:	mov    r13,rcx
  41021b:	test   rcx,rcx
  41021e:	jne    41022e <__swc_fn_e121059d_000053_3af34d7f+0x8e>
  410220:	mov    r13d,0x1dcd6500
  410226:	mov    ecx,0x1dcd6500
  41022b:	xchg   QWORD PTR [rax],rcx
  41022e:	lea    rax,[rip+0x11dd3]        # 422008 <__swc_data_base_e121059d+0x8>
  410235:	mov    rax,QWORD PTR [rax]
  410238:	cmp    rax,0xffffffffffffffff
  41023c:	je     41024b <__swc_fn_e121059d_000053_3af34d7f+0xab>
  41023e:	mov    eax,eax
  410240:	mov    edi,eax
  410242:	xor    eax,eax
  410244:	call   407000 <pthread_getspecific@plt>
  410249:	jmp    41024d <__swc_fn_e121059d_000053_3af34d7f+0xad>
  41024b:	xor    eax,eax
  41024d:	test   rax,rax
  410250:	jne    41025f <__swc_fn_e121059d_000053_3af34d7f+0xbf>
  410252:	call   40ff00 <__swc_fn_e121059d_000035_cd1a4e8c>
  410257:	mov    rcx,rax
  41025a:	call   40dc60 <__swc_fn_e121059d_000133_5f757033>
  41025f:	test   rax,rax
  410262:	je     410274 <__swc_fn_e121059d_000053_3af34d7f+0xd4>
  410264:	cmp    QWORD PTR [rax],r12
  410267:	jne    410274 <__swc_fn_e121059d_000053_3af34d7f+0xd4>
  410269:	cmp    DWORD PTR [rax+0x20],0x0
  41026d:	jne    410274 <__swc_fn_e121059d_000053_3af34d7f+0xd4>
  41026f:	mov    rsi,rax
  410272:	jmp    410276 <__swc_fn_e121059d_000053_3af34d7f+0xd6>
  410274:	xor    esi,esi
  410276:	lea    rdi,[r12+0x2a88]
  41027e:	mov    r14,QWORD PTR [rdi]
  410281:	test   r14,r14
  410284:	jne    4102d3 <__swc_fn_e121059d_000053_3af34d7f+0x133>
  410286:	lea    rax,[rip+0x13dd3]        # 424060 <__swc_bss_base_e121059d+0x20>
  41028d:	mov    rax,QWORD PTR [rax]
  410290:	test   rax,rax
  410293:	setne  al
  410296:	jne    4102ba <__swc_fn_e121059d_000053_3af34d7f+0x11a>
  410298:	mov    rax,QWORD PTR [r12+0x2a70]
  4102a0:	test   rax,rax
  4102a3:	setne  al
  4102a6:	jne    4102ba <__swc_fn_e121059d_000053_3af34d7f+0x11a>
  4102a8:	test   rsi,rsi
  4102ab:	setne  al
  4102ae:	je     4102ba <__swc_fn_e121059d_000053_3af34d7f+0x11a>
  4102b0:	cmp    DWORD PTR [rsi+0x730],0x0
  4102b7:	setne  al
  4102ba:	test   al,al
  4102bc:	je     4102ce <__swc_fn_e121059d_000053_3af34d7f+0x12e>
  4102be:	call   40dd10 <__swc_fn_e121059d_000136_07d76562>
  4102c3:	lea    rcx,[rax+r13*1]
  4102c7:	xor    eax,eax
  4102c9:	lock cmpxchg QWORD PTR [rdi],rcx
  4102ce:	jmp    4103d3 <__swc_fn_e121059d_000053_3af34d7f+0x233>
  4102d3:	call   40dd10 <__swc_fn_e121059d_000136_07d76562>
  4102d8:	mov    r15,rax
  4102db:	cmp    rax,r14
  4102de:	jb     4102ef <__swc_fn_e121059d_000053_3af34d7f+0x14f>
  4102e0:	xor    ecx,ecx
  4102e2:	mov    rax,r14
  4102e5:	lock cmpxchg QWORD PTR [rdi],rcx
  4102ea:	cmp    rax,r14
  4102ed:	je     4102f4 <__swc_fn_e121059d_000053_3af34d7f+0x154>
  4102ef:	jmp    4103d3 <__swc_fn_e121059d_000053_3af34d7f+0x233>
  4102f4:	test   rsi,rsi
  4102f7:	je     410312 <__swc_fn_e121059d_000053_3af34d7f+0x172>
  4102f9:	cmp    r15,r13
  4102fc:	jb     410312 <__swc_fn_e121059d_000053_3af34d7f+0x172>
  4102fe:	mov    rax,r15
  410301:	sub    rax,r13
  410304:	mov    rcx,r12
  410307:	mov    rdx,rsi
  41030a:	mov    r8,rax
  41030d:	call   408ed0 <__swc_fn_e121059d_000063_dea90857>
  410312:	lea    rsi,[r12+0x10]
  410317:	mov    rcx,rsi
  41031a:	call   412140 <__swc_fn_e121059d_000140_86bb0f90>
  41031f:	mov    rax,QWORD PTR [r12+0x18]
  410324:	mov    rdi,rax
  410327:	test   rdi,rdi
  41032a:	je     410354 <__swc_fn_e121059d_000053_3af34d7f+0x1b4>
  41032c:	cs nop WORD PTR [rax+rax*1+0x0]
  410336:	cs nop WORD PTR [rax+rax*1+0x0]
  410340:	mov    rcx,rdi
  410343:	call   40b540 <__swc_fn_e121059d_000019_adca76cf>
  410348:	mov    rax,QWORD PTR [rdi+0x10]
  41034c:	mov    rdi,rax
  41034f:	test   rax,rax
  410352:	jne    410340 <__swc_fn_e121059d_000053_3af34d7f+0x1a0>
  410354:	mov    rcx,rsi
  410357:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  41035c:	mov    rcx,r12
  41035f:	call   412140 <__swc_fn_e121059d_000140_86bb0f90>
  410364:	xor    esi,esi
  410366:	cs nop WORD PTR [rax+rax*1+0x0]
  410370:	mov    rax,QWORD PTR [r12+0x2a70]
  410378:	cmp    rsi,rax
  41037b:	jae    4103cb <__swc_fn_e121059d_000053_3af34d7f+0x22b>
  41037d:	lea    rax,[rsi+rsi*4]
  410381:	lea    rax,[r12+rax*8+0x268]
  410389:	mov    r8,QWORD PTR [rax]
  41038c:	mov    r9,QWORD PTR [rax+0x8]
  410390:	mov    r10,QWORD PTR [rax+0x10]
  410394:	mov    rax,QWORD PTR [rax+0x20]
  410398:	cmp    rax,r15
  41039b:	jae    4103a8 <__swc_fn_e121059d_000053_3af34d7f+0x208>
  41039d:	mov    rcx,r15
  4103a0:	sub    rcx,rax
  4103a3:	cmp    rcx,r13
  4103a6:	jae    4103ad <__swc_fn_e121059d_000053_3af34d7f+0x20d>
  4103a8:	inc    rsi
  4103ab:	jmp    410370 <__swc_fn_e121059d_000053_3af34d7f+0x1d0>
  4103ad:	mov    rcx,r12
  4103b0:	mov    rdx,rsi
  4103b3:	call   408e80 <__swc_fn_e121059d_000060_15c28ca7>
  4103b8:	mov    rcx,r12
  4103bb:	mov    rdx,r8
  4103be:	mov    r8,r9
  4103c1:	mov    r9,r10
  4103c4:	call   40b820 <__swc_fn_e121059d_000043_d3c2ab54>
  4103c9:	jmp    410370 <__swc_fn_e121059d_000053_3af34d7f+0x1d0>
  4103cb:	mov    rcx,r12
  4103ce:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  4103d3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  4103dc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  4103e5:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  4103ee:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  4103f7:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  410400:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  410409:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  410412:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  41041b:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  410424:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  41042d:	add    rsp,0x178
  410434:	pop    r15
  410436:	pop    r14
  410438:	pop    rsi
  410439:	pop    rdi
  41043a:	pop    r13
  41043c:	pop    r12
  41043e:	ret
	...

0000000000410440 <__swc_fn_e121059d_000056_df0696cd>:
  410440:	lea    rax,[rdx-0x58]
  410444:	ret
	...

0000000000410450 <__swc_fn_e121059d_000059_2ca0cb05>:
  410450:	push   rsi
  410451:	push   rdi
  410452:	push   r12
  410454:	push   r13
  410456:	sub    rsp,0x68
  41045a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  410460:	mov    rsi,r9
  410463:	mov    rdi,rcx
  410466:	mov    r12,rdx
  410469:	mov    r13,r8
  41046c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  410474:	jne    410483 <__swc_fn_e121059d_000059_2ca0cb05+0x33>
  410476:	xor    eax,eax
  410478:	add    rsp,0x68
  41047c:	pop    r13
  41047e:	pop    r12
  410480:	pop    rdi
  410481:	pop    rsi
  410482:	ret
  410483:	mov    rcx,rdi
  410486:	call   412140 <__swc_fn_e121059d_000140_86bb0f90>
  41048b:	movabs rax,0x7fffffffffffffff
  410495:	cmp    r12,rax
  410498:	mov    rax,0xffffffffffffffff
  41049f:	lea    rcx,[r12+r12*1]
  4104a3:	cmovbe rax,rcx
  4104a7:	mov    rcx,QWORD PTR [rdi+0x2a70]
  4104ae:	mov    rdx,rcx
  4104b1:	sub    rax,r12
  4104b4:	inc    rax
  4104b7:	xor    r8d,r8d
  4104ba:	test   rcx,rcx
  4104bd:	jbe    4104e8 <__swc_fn_e121059d_000059_2ca0cb05+0x98>
  4104bf:	nop
  4104c0:	lea    r9,[r8+r8*4]
  4104c4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  4104cc:	sub    r9,r12
  4104cf:	cmp    r9,rax
  4104d2:	jae    4104df <__swc_fn_e121059d_000059_2ca0cb05+0x8f>
  4104d4:	mov    rdx,r8
  4104d7:	mov    rax,r9
  4104da:	test   r9,r9
  4104dd:	je     4104e8 <__swc_fn_e121059d_000059_2ca0cb05+0x98>
  4104df:	add    r8,0x1
  4104e3:	cmp    r8,rcx
  4104e6:	jb     4104c0 <__swc_fn_e121059d_000059_2ca0cb05+0x70>
  4104e8:	mov    rax,QWORD PTR [rdi+0x2a70]
  4104ef:	cmp    rdx,rax
  4104f2:	jne    41050f <__swc_fn_e121059d_000059_2ca0cb05+0xbf>
  4104f4:	mov    rcx,rdi
  4104f7:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  4104fc:	xor    eax,eax
  4104fe:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  410504:	add    rsp,0x68
  410508:	pop    r13
  41050a:	pop    r12
  41050c:	pop    rdi
  41050d:	pop    rsi
  41050e:	ret
  41050f:	lea    rax,[rdx+rdx*4]
  410513:	lea    rax,[rdi+rax*8+0x268]
  41051b:	vmovups xmm6,XMMWORD PTR [rax]
  41051f:	mov    r8,QWORD PTR [rax+0x10]
  410523:	mov    rcx,rdi
  410526:	call   408e80 <__swc_fn_e121059d_000060_15c28ca7>
  41052b:	vpshufd xmm0,xmm6,0xee
  410530:	vmovsd QWORD PTR [r13+0x0],xmm0
  410536:	mov    QWORD PTR [rsi],r8
  410539:	mov    rcx,rdi
  41053c:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  410541:	vmovq  rax,xmm6
  410546:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  41054c:	add    rsp,0x68
  410550:	pop    r13
  410552:	pop    r12
  410554:	pop    rdi
  410555:	pop    rsi
  410556:	ret
	...

0000000000410560 <__swc_fn_e121059d_000062_b304235a>:
  410560:	push   r12
  410562:	push   r13
  410564:	push   r14
  410566:	push   r15
  410568:	push   rdi
  410569:	push   rsi
  41056a:	sub    rsp,0x148
  410571:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  41057a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  410583:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  41058c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  410595:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  41059e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4105a7:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4105b0:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4105b9:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  4105c2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  4105cb:	mov    r12,r9
  4105ce:	mov    r13,rcx
  4105d1:	mov    r14,rdx
  4105d4:	mov    r15,r8
  4105d7:	test   rdx,rdx
  4105da:	jne    4105ee <__swc_fn_e121059d_000062_b304235a+0x8e>
  4105dc:	add    rsp,0x148
  4105e3:	pop    rsi
  4105e4:	pop    rdi
  4105e5:	pop    r15
  4105e7:	pop    r14
  4105e9:	pop    r13
  4105eb:	pop    r12
  4105ed:	ret
  4105ee:	cmp    r12,0x200000
  4105f5:	ja     410687 <__swc_fn_e121059d_000062_b304235a+0x127>
  4105fb:	lea    rax,[rip+0x11a06]        # 422008 <__swc_data_base_e121059d+0x8>
  410602:	mov    rax,QWORD PTR [rax]
  410605:	cmp    rax,0xffffffffffffffff
  410609:	je     410618 <__swc_fn_e121059d_000062_b304235a+0xb8>
  41060b:	mov    eax,eax
  41060d:	mov    edi,eax
  41060f:	xor    eax,eax
  410611:	call   407000 <pthread_getspecific@plt>
  410616:	jmp    41061a <__swc_fn_e121059d_000062_b304235a+0xba>
  410618:	xor    eax,eax
  41061a:	test   rax,rax
  41061d:	je     410624 <__swc_fn_e121059d_000062_b304235a+0xc4>
  41061f:	mov    rsi,rax
  410622:	jmp    410634 <__swc_fn_e121059d_000062_b304235a+0xd4>
  410624:	call   40ff00 <__swc_fn_e121059d_000035_cd1a4e8c>
  410629:	mov    rcx,rax
  41062c:	call   40dc60 <__swc_fn_e121059d_000133_5f757033>
  410631:	mov    rsi,rax
  410634:	test   rsi,rsi
  410637:	je     410687 <__swc_fn_e121059d_000062_b304235a+0x127>
  410639:	cmp    QWORD PTR [rsi],r13
  41063c:	jne    410687 <__swc_fn_e121059d_000062_b304235a+0x127>
  41063e:	cmp    DWORD PTR [rsi+0x20],0x0
  410642:	jne    410687 <__swc_fn_e121059d_000062_b304235a+0x127>
  410644:	cmp    DWORD PTR [rsi+0x730],0x10
  41064b:	jae    410687 <__swc_fn_e121059d_000062_b304235a+0x127>
  41064d:	mov    eax,DWORD PTR [rsi+0x730]
  410653:	lea    rdi,[rax+rax*4]
  410657:	lea    rdi,[rsi+rdi*8+0x738]
  41065f:	mov    QWORD PTR [rdi],r14
  410662:	mov    QWORD PTR [rdi+0x8],r15
  410666:	mov    QWORD PTR [rdi+0x10],r12
  41066a:	mov    QWORD PTR [rdi+0x18],0x0
  410672:	call   40dd10 <__swc_fn_e121059d_000136_07d76562>
  410677:	mov    QWORD PTR [rdi+0x20],rax
  41067b:	add    DWORD PTR [rsi+0x730],0x1
  410682:	jmp    4107e6 <__swc_fn_e121059d_000062_b304235a+0x286>
  410687:	mov    rcx,r13
  41068a:	call   40bf50 <__swc_fn_e121059d_000061_ad030a10>
  41068f:	mov    rsi,rax
  410692:	cmp    r12,rax
  410695:	jbe    4106ca <__swc_fn_e121059d_000062_b304235a+0x16a>
  410697:	cmp    r12,0x10000000
  41069e:	seta   al
  4106a1:	ja     4106b0 <__swc_fn_e121059d_000062_b304235a+0x150>
  4106a3:	mov    rax,QWORD PTR [r13+0x2a70]
  4106aa:	test   rax,rax
  4106ad:	setne  al
  4106b0:	test   al,al
  4106b2:	je     4106ca <__swc_fn_e121059d_000062_b304235a+0x16a>
  4106b4:	mov    rcx,r13
  4106b7:	mov    rdx,r14
  4106ba:	mov    r8,r15
  4106bd:	mov    r9,r12
  4106c0:	call   40b820 <__swc_fn_e121059d_000043_d3c2ab54>
  4106c5:	jmp    4107e6 <__swc_fn_e121059d_000062_b304235a+0x286>
  4106ca:	call   40dd10 <__swc_fn_e121059d_000136_07d76562>
  4106cf:	mov    rdi,rax
  4106d2:	mov    rcx,r13
  4106d5:	call   412140 <__swc_fn_e121059d_000140_86bb0f90>
  4106da:	cmp    QWORD PTR [r13+0x2a70],0x0
  4106e2:	je     41079a <__swc_fn_e121059d_000062_b304235a+0x23a>
  4106e8:	nop    DWORD PTR [rax+rax*1+0x0]
  4106f0:	cmp    QWORD PTR [r13+0x2a70],0x100
  4106fb:	jae    410710 <__swc_fn_e121059d_000062_b304235a+0x1b0>
  4106fd:	mov    rax,QWORD PTR [r13+0x2a68]
  410704:	add    rax,r12
  410707:	cmp    rax,rsi
  41070a:	jbe    41079a <__swc_fn_e121059d_000062_b304235a+0x23a>
  410710:	xor    eax,eax
  410712:	mov    rcx,QWORD PTR [r13+0x2a70]
  410719:	mov    edx,0x1
  41071e:	cmp    rcx,0x1
  410722:	jbe    410759 <__swc_fn_e121059d_000062_b304235a+0x1f9>
  410724:	cs nop WORD PTR [rax+rax*1+0x0]
  41072e:	xchg   ax,ax
  410730:	lea    r8,[rdx+rdx*4]
  410734:	lea    r8,[r13+r8*8+0x268]
  41073c:	lea    r9,[rax+rax*4]
  410740:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  410748:	cmp    QWORD PTR [r8+0x18],r9
  41074c:	cmovb  rax,rdx
  410750:	add    rdx,0x1
  410754:	cmp    rdx,rcx
  410757:	jb     410730 <__swc_fn_e121059d_000062_b304235a+0x1d0>
  410759:	lea    rcx,[rax+rax*4]
  41075d:	lea    rcx,[r13+rcx*8+0x268]
  410765:	mov    r8,QWORD PTR [rcx]
  410768:	mov    r9,QWORD PTR [rcx+0x8]
  41076c:	mov    r10,QWORD PTR [rcx+0x10]
  410770:	mov    rcx,r13
  410773:	mov    rdx,rax
  410776:	call   408e80 <__swc_fn_e121059d_000060_15c28ca7>
  41077b:	mov    rcx,r13
  41077e:	mov    rdx,r8
  410781:	mov    r8,r9
  410784:	mov    r9,r10
  410787:	call   40b820 <__swc_fn_e121059d_000043_d3c2ab54>
  41078c:	cmp    QWORD PTR [r13+0x2a70],0x0
  410794:	jne    4106f0 <__swc_fn_e121059d_000062_b304235a+0x190>
  41079a:	add    QWORD PTR [r13+0x2a78],0x1
  4107a2:	mov    rax,QWORD PTR [r13+0x2a70]
  4107a9:	lea    rax,[rax+rax*4]
  4107ad:	lea    rax,[r13+rax*8+0x268]
  4107b5:	mov    QWORD PTR [rax],r14
  4107b8:	mov    QWORD PTR [rax+0x8],r15
  4107bc:	mov    QWORD PTR [rax+0x10],r12
  4107c0:	mov    rcx,QWORD PTR [r13+0x2a78]
  4107c7:	mov    QWORD PTR [rax+0x18],rcx
  4107cb:	mov    QWORD PTR [rax+0x20],rdi
  4107cf:	add    QWORD PTR [r13+0x2a68],r12
  4107d6:	add    QWORD PTR [r13+0x2a70],0x1
  4107de:	mov    rcx,r13
  4107e1:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  4107e6:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  4107ef:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  4107f8:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  410801:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  41080a:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  410813:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  41081c:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  410825:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  41082e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  410837:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  410840:	add    rsp,0x148
  410847:	pop    rsi
  410848:	pop    rdi
  410849:	pop    r15
  41084b:	pop    r14
  41084d:	pop    r13
  41084f:	pop    r12
  410851:	ret
	...

0000000000410860 <__swc_fn_e121059d_000065_d9ee99ea>:
  410860:	push   rbx
  410861:	push   r12
  410863:	push   r13
  410865:	push   r14
  410867:	push   r15
  410869:	push   rdi
  41086a:	push   rsi
  41086b:	sub    rsp,0xf0
  410872:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  410878:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  41087e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  410884:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  41088a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  410893:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  41089c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  4108a5:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  4108ae:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  4108b7:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  4108c0:	mov    eax,r8d
  4108c3:	mov    rbx,rcx
  4108c6:	mov    r12,rdx
  4108c9:	mov    QWORD PTR [rsp+0x18],rdx
  4108ce:	mov    ecx,DWORD PTR [r12+0x58]
  4108d3:	mov    r13d,ecx
  4108d6:	cmp    ecx,0x10
  4108d9:	mov    ecx,0x10
  4108de:	cmovb  r13d,ecx
  4108e2:	test   r13d,r13d
  4108e5:	mov    rcx,r13
  4108e8:	mov    edx,0x8
  4108ed:	cmove  ecx,edx
  4108f0:	dec    rcx
  4108f3:	mov    rdx,0xffffffffffffffff
  4108fa:	sub    rdx,rcx
  4108fd:	xor    r14d,r14d
  410900:	mov    r8,rcx
  410903:	not    r8
  410906:	lea    rcx,[rcx+0x58]
  41090a:	and    rcx,r8
  41090d:	cmp    rdx,0x58
  410911:	cmovae r14,rcx
  410915:	cmp    eax,0xffffffff
  410918:	jne    410921 <__swc_fn_e121059d_000065_d9ee99ea+0xc1>
  41091a:	mov    r15,QWORD PTR [r12+0x48]
  41091f:	jmp    410953 <__swc_fn_e121059d_000065_d9ee99ea+0xf3>
  410921:	test   eax,eax
  410923:	jne    41092c <__swc_fn_e121059d_000065_d9ee99ea+0xcc>
  410925:	mov    eax,0x8
  41092a:	jmp    410950 <__swc_fn_e121059d_000065_d9ee99ea+0xf0>
  41092c:	cmp    eax,0x8
  41092f:	ja     410937 <__swc_fn_e121059d_000065_d9ee99ea+0xd7>
  410931:	shl    rax,0x4
  410935:	jmp    410950 <__swc_fn_e121059d_000065_d9ee99ea+0xf0>
  410937:	lea    eax,[rax-0x9]
  41093a:	mov    ecx,eax
  41093c:	shr    ecx,0x2
  41093f:	and    eax,0x3
  410942:	lea    ecx,[rcx+0x7]
  410945:	lea    ecx,[rcx-0x2]
  410948:	lea    eax,[rax+0x5]
  41094b:	shlx   rax,rax,rcx
  410950:	mov    r15,rax
  410953:	lea    rax,[r14+r13*1]
  410957:	mov    rcx,0xffffffffffffffff
  41095e:	sub    rcx,rax
  410961:	cmp    r15,rcx
  410964:	jbe    410974 <__swc_fn_e121059d_000065_d9ee99ea+0x114>
  410966:	mov    QWORD PTR [r12+0x40],0x0
  41096f:	jmp    410d46 <__swc_fn_e121059d_000065_d9ee99ea+0x4e6>
  410974:	mov    QWORD PTR [rsp+0x20],r13
  410979:	lea    r13,[rsp+0x8]
  41097e:	add    rax,r15
  410981:	mov    ecx,0x1000
  410986:	test   ecx,ecx
  410988:	mov    edx,0x8
  41098d:	cmove  ecx,edx
  410990:	dec    rcx
  410993:	mov    rdx,0xffffffffffffffff
  41099a:	sub    rdx,rcx
  41099d:	cmp    rax,rdx
  4109a0:	jbe    4109ac <__swc_fn_e121059d_000065_d9ee99ea+0x14c>
  4109a2:	mov    QWORD PTR [r13+0x0],0x0
  4109aa:	jmp    4109b9 <__swc_fn_e121059d_000065_d9ee99ea+0x159>
  4109ac:	add    rax,rcx
  4109af:	andn   rax,rcx,rax
  4109b4:	mov    QWORD PTR [rsp+0x8],rax
  4109b9:	cmp    QWORD PTR [r13+0x0],0x0
  4109be:	jne    4109ce <__swc_fn_e121059d_000065_d9ee99ea+0x16e>
  4109c0:	mov    QWORD PTR [r12+0x40],0x0
  4109c9:	jmp    410d46 <__swc_fn_e121059d_000065_d9ee99ea+0x4e6>
  4109ce:	mov    QWORD PTR [rsp+0x30],r15
  4109d3:	xor    r15d,r15d
  4109d6:	mov    QWORD PTR [rsp+0x38],0x0
  4109df:	lea    r12,[rsp+0x10]
  4109e4:	mov    QWORD PTR [rsp+0x28],r14
  4109e9:	mov    r14,QWORD PTR [rsp+0x8]
  4109ee:	mov    QWORD PTR [rsp+0x10],r14
  4109f3:	cmp    r14,0x10000
  4109fa:	ja     410a01 <__swc_fn_e121059d_000065_d9ee99ea+0x1a1>
  4109fc:	mov    rax,r14
  4109ff:	jmp    410a52 <__swc_fn_e121059d_000065_d9ee99ea+0x1f2>
  410a01:	xor    eax,eax
  410a03:	lea    rcx,[r14-0x1]
  410a07:	lzcnt  rax,rcx
  410a0c:	mov    ecx,0x3f
  410a11:	sub    rcx,rax
  410a14:	mov    eax,0x1
  410a19:	lea    rcx,[rcx-0x3]
  410a1d:	shl    rax,cl
  410a20:	mov    rcx,rax
  410a23:	cmp    rax,0x1000
  410a2a:	mov    eax,0x1000
  410a2f:	cmovb  rcx,rax
  410a33:	mov    rdx,0xffffffffffffffff
  410a3a:	sub    rdx,rcx
  410a3d:	mov    rax,r14
  410a40:	lea    r8,[r14+rcx*1-0x1]
  410a45:	neg    rcx
  410a48:	and    r8,rcx
  410a4b:	cmp    r14,rdx
  410a4e:	cmovbe rax,r8
  410a52:	mov    QWORD PTR [rsp+0x8],rax
  410a57:	lea    rax,[rip+0x115aa]        # 422008 <__swc_data_base_e121059d+0x8>
  410a5e:	mov    rax,QWORD PTR [rax]
  410a61:	cmp    rax,0xffffffffffffffff
  410a65:	je     410a74 <__swc_fn_e121059d_000065_d9ee99ea+0x214>
  410a67:	mov    eax,eax
  410a69:	mov    edi,eax
  410a6b:	xor    eax,eax
  410a6d:	call   407000 <pthread_getspecific@plt>
  410a72:	jmp    410a76 <__swc_fn_e121059d_000065_d9ee99ea+0x216>
  410a74:	xor    eax,eax
  410a76:	test   rax,rax
  410a79:	jne    410a88 <__swc_fn_e121059d_000065_d9ee99ea+0x228>
  410a7b:	call   40ff00 <__swc_fn_e121059d_000035_cd1a4e8c>
  410a80:	mov    rcx,rax
  410a83:	call   40dc60 <__swc_fn_e121059d_000133_5f757033>
  410a88:	test   rax,rax
  410a8b:	je     410b7c <__swc_fn_e121059d_000065_d9ee99ea+0x31c>
  410a91:	cmp    QWORD PTR [rax],rbx
  410a94:	jne    410b7c <__swc_fn_e121059d_000065_d9ee99ea+0x31c>
  410a9a:	cmp    DWORD PTR [rax+0x20],0x0
  410a9e:	jne    410b7c <__swc_fn_e121059d_000065_d9ee99ea+0x31c>
  410aa4:	mov    rcx,QWORD PTR [rsp+0x8]
  410aa9:	movabs rdx,0x7fffffffffffffff
  410ab3:	cmp    rcx,rdx
  410ab6:	mov    rdx,0xffffffffffffffff
  410abd:	lea    r8,[rcx+rcx*1]
  410ac1:	cmovbe rdx,r8
  410ac5:	mov    r8d,DWORD PTR [rax+0x730]
  410acc:	mov    r9d,r8d
  410acf:	sub    rdx,rcx
  410ad2:	inc    rdx
  410ad5:	xor    r10d,r10d
  410ad8:	test   r8,r8
  410adb:	jbe    410b0b <__swc_fn_e121059d_000065_d9ee99ea+0x2ab>
  410add:	nop    DWORD PTR [rax]
  410ae0:	mov    r11d,r10d
  410ae3:	lea    r11,[r11+r11*4]
  410ae7:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  410aef:	sub    r11,rcx
  410af2:	cmp    r11,rdx
  410af5:	jae    410b02 <__swc_fn_e121059d_000065_d9ee99ea+0x2a2>
  410af7:	mov    r9d,r10d
  410afa:	mov    rdx,r11
  410afd:	test   r11,r11
  410b00:	je     410b0b <__swc_fn_e121059d_000065_d9ee99ea+0x2ab>
  410b02:	add    r10,0x1
  410b06:	cmp    r10,r8
  410b09:	jb     410ae0 <__swc_fn_e121059d_000065_d9ee99ea+0x280>
  410b0b:	mov    ecx,DWORD PTR [rax+0x730]
  410b11:	cmp    r9d,ecx
  410b14:	jne    410b1a <__swc_fn_e121059d_000065_d9ee99ea+0x2ba>
  410b16:	xor    eax,eax
  410b18:	jmp    410b79 <__swc_fn_e121059d_000065_d9ee99ea+0x319>
  410b1a:	lea    rcx,[r9+r9*4]
  410b1e:	lea    rcx,[rax+rcx*8+0x738]
  410b26:	vmovups xmm0,XMMWORD PTR [rcx]
  410b2a:	mov    rdx,QWORD PTR [rcx+0x10]
  410b2e:	sub    DWORD PTR [rax+0x730],0x1
  410b35:	mov    r8d,DWORD PTR [rax+0x730]
  410b3c:	lea    r8,[r8+r8*4]
  410b40:	lea    r8,[rax+r8*8+0x738]
  410b48:	vmovups xmm1,XMMWORD PTR [r8]
  410b4d:	vmovups XMMWORD PTR [rcx],xmm1
  410b51:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  410b57:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  410b5c:	mov    rax,QWORD PTR [r8+0x20]
  410b60:	mov    QWORD PTR [rcx+0x20],rax
  410b64:	vpshufd xmm1,xmm0,0xee
  410b69:	vmovsd QWORD PTR [rsp+0x8],xmm1
  410b6f:	mov    QWORD PTR [rsp+0x10],rdx
  410b74:	vmovq  rax,xmm0
  410b79:	mov    r15,rax
  410b7c:	test   r15,r15
  410b7f:	jne    410b97 <__swc_fn_e121059d_000065_d9ee99ea+0x337>
  410b81:	mov    rcx,rbx
  410b84:	mov    rdx,QWORD PTR [rsp+0x8]
  410b89:	mov    r8,r13
  410b8c:	mov    r9,r12
  410b8f:	call   410450 <__swc_fn_e121059d_000059_2ca0cb05>
  410b94:	mov    r15,rax
  410b97:	test   r15,r15
  410b9a:	je     410bdb <__swc_fn_e121059d_000065_d9ee99ea+0x37b>
  410b9c:	cmp    QWORD PTR [r12],r14
  410ba0:	jae    410bdb <__swc_fn_e121059d_000065_d9ee99ea+0x37b>
  410ba2:	mov    rax,r15
  410ba5:	add    rax,QWORD PTR [r12]
  410ba9:	mov    rdx,r14
  410bac:	sub    rdx,QWORD PTR [r12]
  410bb0:	mov    rcx,rax
  410bb3:	call   40b370 <__swc_fn_e121059d_000007_f7acedb0>
  410bb8:	test   al,al
  410bba:	je     410bc3 <__swc_fn_e121059d_000065_d9ee99ea+0x363>
  410bbc:	mov    QWORD PTR [rsp+0x10],r14
  410bc1:	jmp    410bdb <__swc_fn_e121059d_000065_d9ee99ea+0x37b>
  410bc3:	mov    rcx,rbx
  410bc6:	mov    rdx,r15
  410bc9:	mov    r8,QWORD PTR [rsp+0x8]
  410bce:	mov    r9,QWORD PTR [rsp+0x10]
  410bd3:	call   410560 <__swc_fn_e121059d_000062_b304235a>
  410bd8:	xor    r15d,r15d
  410bdb:	test   r15,r15
  410bde:	jne    410c5a <__swc_fn_e121059d_000065_d9ee99ea+0x3fa>
  410be0:	cmp    r14,0x10000
  410be7:	ja     410bee <__swc_fn_e121059d_000065_d9ee99ea+0x38e>
  410be9:	mov    rax,r14
  410bec:	jmp    410c3f <__swc_fn_e121059d_000065_d9ee99ea+0x3df>
  410bee:	xor    eax,eax
  410bf0:	lea    rcx,[r14-0x1]
  410bf4:	lzcnt  rax,rcx
  410bf9:	mov    ecx,0x3f
  410bfe:	sub    rcx,rax
  410c01:	mov    eax,0x1
  410c06:	lea    rcx,[rcx-0x3]
  410c0a:	shl    rax,cl
  410c0d:	mov    rcx,rax
  410c10:	cmp    rax,0x1000
  410c17:	mov    eax,0x1000
  410c1c:	cmovb  rcx,rax
  410c20:	mov    rdx,0xffffffffffffffff
  410c27:	sub    rdx,rcx
  410c2a:	mov    rax,r14
  410c2d:	lea    r8,[r14+rcx*1-0x1]
  410c32:	neg    rcx
  410c35:	and    r8,rcx
  410c38:	cmp    r14,rdx
  410c3b:	cmovbe rax,r8
  410c3f:	mov    QWORD PTR [rsp+0x8],rax
  410c44:	mov    QWORD PTR [rsp+0x10],r14
  410c49:	mov    rcx,rbx
  410c4c:	mov    rdx,rax
  410c4f:	mov    r8,r14
  410c52:	call   40ffc0 <__swc_fn_e121059d_000041_c90d80c1>
  410c57:	mov    r15,rax
  410c5a:	test   r15,r15
  410c5d:	jne    410c6b <__swc_fn_e121059d_000065_d9ee99ea+0x40b>
  410c5f:	mov    r13,QWORD PTR [rsp+0x20]
  410c64:	mov    rsi,QWORD PTR [rsp+0x38]
  410c69:	jmp    410ca7 <__swc_fn_e121059d_000065_d9ee99ea+0x447>
  410c6b:	mov    rax,r15
  410c6e:	add    rax,QWORD PTR [rsp+0x28]
  410c73:	mov    r13,QWORD PTR [rsp+0x20]
  410c78:	test   r13d,r13d
  410c7b:	mov    rcx,r13
  410c7e:	mov    edx,0x8
  410c83:	cmove  ecx,edx
  410c86:	dec    rcx
  410c89:	mov    rdx,0xffffffffffffffff
  410c90:	sub    rdx,rcx
  410c93:	cmp    rax,rdx
  410c96:	jbe    410c9c <__swc_fn_e121059d_000065_d9ee99ea+0x43c>
  410c98:	xor    eax,eax
  410c9a:	jmp    410ca4 <__swc_fn_e121059d_000065_d9ee99ea+0x444>
  410c9c:	add    rax,rcx
  410c9f:	andn   rax,rcx,rax
  410ca4:	mov    rsi,rax
  410ca7:	mov    rax,QWORD PTR [rsp+0x8]
  410cac:	test   r15,r15
  410caf:	je     410cb8 <__swc_fn_e121059d_000065_d9ee99ea+0x458>
  410cb1:	mov    rdi,QWORD PTR [rsp+0x18]
  410cb6:	jmp    410cca <__swc_fn_e121059d_000065_d9ee99ea+0x46a>
  410cb8:	mov    rdi,QWORD PTR [rsp+0x18]
  410cbd:	mov    QWORD PTR [rdi+0x40],0x0
  410cc5:	jmp    410d46 <__swc_fn_e121059d_000065_d9ee99ea+0x4e6>
  410cca:	lea    rdx,[rsi-0x58]
  410cce:	mov    QWORD PTR [rsi-0x58],r15
  410cd2:	mov    QWORD PTR [rsi-0x50],rax
  410cd6:	mov    rax,QWORD PTR [rsp+0x10]
  410cdb:	mov    QWORD PTR [rsi-0x48],rax
  410cdf:	mov    QWORD PTR [rsi-0x40],rsi
  410ce3:	mov    rax,QWORD PTR [rdi+0x48]
  410ce7:	mov    QWORD PTR [rsi-0x38],rax
  410ceb:	mov    rax,QWORD PTR [rsp+0x30]
  410cf0:	mov    QWORD PTR [rsi-0x30],rax
  410cf4:	mov    DWORD PTR [rsi-0x10],r13d
  410cf8:	mov    QWORD PTR [rsi-0x28],0x0
  410d00:	mov    QWORD PTR [rsi-0x20],0x0
  410d08:	add    r15,QWORD PTR [r12]
  410d0c:	sub    r15,rsi
  410d0f:	mov    QWORD PTR [rsi-0x30],r15
  410d13:	mov    rcx,QWORD PTR [rbx+0x250]
  410d1a:	nop    WORD PTR [rax+rax*1+0x0]
  410d20:	lea    r8,[rcx+r15*1]
  410d24:	mov    rax,rcx
  410d27:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  410d30:	cmp    rax,rcx
  410d33:	je     410d3a <__swc_fn_e121059d_000065_d9ee99ea+0x4da>
  410d35:	mov    rcx,rax
  410d38:	jmp    410d20 <__swc_fn_e121059d_000065_d9ee99ea+0x4c0>
  410d3a:	mov    rcx,rbx
  410d3d:	call   408df0 <__swc_fn_e121059d_000057_7e1dbcb0>
  410d42:	mov    QWORD PTR [rdi+0x40],rsi
  410d46:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  410d4c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  410d52:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  410d58:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  410d5e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  410d67:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  410d70:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  410d79:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  410d82:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  410d8b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  410d94:	add    rsp,0xf0
  410d9b:	pop    rsi
  410d9c:	pop    rdi
  410d9d:	pop    r15
  410d9f:	pop    r14
  410da1:	pop    r13
  410da3:	pop    r12
  410da5:	pop    rbx
  410da6:	ret
	...

0000000000410db0 <__swc_fn_e121059d_000068_f3aa21af>:
  410db0:	push   rbx
  410db1:	push   r12
  410db3:	push   rdi
  410db4:	push   rsi
  410db5:	sub    rsp,0xb8
  410dbc:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  410dc2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410dc8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  410dce:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410dd4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410dda:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  410de0:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410de6:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  410def:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410df8:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  410e01:	mov    rbx,rdx
  410e04:	mov    r12,rcx
  410e07:	cmp    DWORD PTR [rbx+0x58],0x0
  410e0b:	je     410e25 <__swc_fn_e121059d_000068_f3aa21af+0x75>
  410e0d:	mov    eax,DWORD PTR [rbx+0x58]
  410e10:	sub    eax,0x1
  410e13:	test   DWORD PTR [rbx+0x58],eax
  410e16:	je     410e25 <__swc_fn_e121059d_000068_f3aa21af+0x75>
  410e18:	mov    QWORD PTR [rbx+0x40],0x0
  410e20:	jmp    411037 <__swc_fn_e121059d_000068_f3aa21af+0x287>
  410e25:	cmp    QWORD PTR [rbx+0x48],0x0
  410e2a:	jne    410e39 <__swc_fn_e121059d_000068_f3aa21af+0x89>
  410e2c:	mov    QWORD PTR [rbx+0x40],0x0
  410e34:	jmp    411037 <__swc_fn_e121059d_000068_f3aa21af+0x287>
  410e39:	lea    rax,[rsp+0x8]
  410e3e:	mov    rcx,QWORD PTR [rbx+0x48]
  410e42:	cmp    rcx,0x8
  410e46:	ja     410e50 <__swc_fn_e121059d_000068_f3aa21af+0xa0>
  410e48:	mov    DWORD PTR [rax],0x0
  410e4e:	jmp    410eab <__swc_fn_e121059d_000068_f3aa21af+0xfb>
  410e50:	cmp    rcx,0x80
  410e57:	ja     410e67 <__swc_fn_e121059d_000068_f3aa21af+0xb7>
  410e59:	lea    rcx,[rcx+0xf]
  410e5d:	shr    rcx,0x4
  410e61:	mov    DWORD PTR [rsp+0x8],ecx
  410e65:	jmp    410eab <__swc_fn_e121059d_000068_f3aa21af+0xfb>
  410e67:	cmp    rcx,0x10000
  410e6e:	jbe    410e78 <__swc_fn_e121059d_000068_f3aa21af+0xc8>
  410e70:	mov    DWORD PTR [rax],0xffffffff
  410e76:	jmp    410eab <__swc_fn_e121059d_000068_f3aa21af+0xfb>
  410e78:	dec    rcx
  410e7b:	xor    edx,edx
  410e7d:	lzcnt  rdx,rcx
  410e82:	mov    r8d,0x3f
  410e88:	sub    r8d,edx
  410e8b:	lea    edx,[r8-0x2]
  410e8f:	shrx   rcx,rcx,rdx
  410e94:	and    ecx,0x3
  410e97:	lea    edx,[r8-0x7]
  410e9b:	lea    edx,[rdx*4+0x0]
  410ea2:	lea    edx,[rdx+0x9]
  410ea5:	add    edx,ecx
  410ea7:	mov    DWORD PTR [rsp+0x8],edx
  410eab:	cmp    DWORD PTR [rax],0x0
  410eae:	jne    410ebe <__swc_fn_e121059d_000068_f3aa21af+0x10e>
  410eb0:	cmp    DWORD PTR [rbx+0x58],0x8
  410eb4:	jbe    410ebe <__swc_fn_e121059d_000068_f3aa21af+0x10e>
  410eb6:	mov    DWORD PTR [rsp+0x8],0x1
  410ebe:	cmp    DWORD PTR [rbx+0x58],0x10
  410ec2:	jbe    410f41 <__swc_fn_e121059d_000068_f3aa21af+0x191>
  410ec8:	cmp    DWORD PTR [rbx+0x58],0x40
  410ecc:	ja     410f41 <__swc_fn_e121059d_000068_f3aa21af+0x191>
  410ece:	cmp    DWORD PTR [rax],0xffffffff
  410ed1:	je     410f41 <__swc_fn_e121059d_000068_f3aa21af+0x191>
  410ed3:	mov    ecx,DWORD PTR [rsp+0x8]
  410ed7:	mov    edx,DWORD PTR [rbx+0x58]
  410eda:	dec    rdx
  410edd:	cmp    ecx,0x2d
  410ee0:	jae    410f38 <__swc_fn_e121059d_000068_f3aa21af+0x188>
  410ee2:	cs nop WORD PTR [rax+rax*1+0x0]
  410eec:	nop    DWORD PTR [rax+0x0]
  410ef0:	mov    r8d,ecx
  410ef3:	test   ecx,ecx
  410ef5:	jne    410eff <__swc_fn_e121059d_000068_f3aa21af+0x14f>
  410ef7:	mov    r8d,0x8
  410efd:	jmp    410f2b <__swc_fn_e121059d_000068_f3aa21af+0x17b>
  410eff:	cmp    r8d,0x8
  410f03:	ja     410f0b <__swc_fn_e121059d_000068_f3aa21af+0x15b>
  410f05:	shl    r8,0x4
  410f09:	jmp    410f2b <__swc_fn_e121059d_000068_f3aa21af+0x17b>
  410f0b:	lea    r8d,[r8-0x9]
  410f0f:	mov    r9d,r8d
  410f12:	shr    r9d,0x2
  410f16:	and    r8d,0x3
  410f1a:	lea    r9d,[r9+0x7]
  410f1e:	lea    r9d,[r9-0x2]
  410f22:	lea    r8d,[r8+0x5]
  410f26:	shlx   r8,r8,r9
  410f2b:	test   r8,rdx
  410f2e:	je     410f3d <__swc_fn_e121059d_000068_f3aa21af+0x18d>
  410f30:	add    ecx,0x1
  410f33:	cmp    ecx,0x2d
  410f36:	jb     410ef0 <__swc_fn_e121059d_000068_f3aa21af+0x140>
  410f38:	mov    ecx,0xffffffff
  410f3d:	mov    DWORD PTR [rsp+0x8],ecx
  410f41:	mov    ecx,DWORD PTR [rsp+0x8]
  410f45:	cmp    ecx,0xffffffff
  410f48:	je     410f50 <__swc_fn_e121059d_000068_f3aa21af+0x1a0>
  410f4a:	cmp    DWORD PTR [rbx+0x58],0x40
  410f4e:	jbe    410f63 <__swc_fn_e121059d_000068_f3aa21af+0x1b3>
  410f50:	mov    rcx,r12
  410f53:	mov    rdx,rbx
  410f56:	mov    r8d,DWORD PTR [rax]
  410f59:	call   410860 <__swc_fn_e121059d_000065_d9ee99ea>
  410f5e:	jmp    411037 <__swc_fn_e121059d_000068_f3aa21af+0x287>
  410f63:	lea    rax,[rip+0x1109e]        # 422008 <__swc_data_base_e121059d+0x8>
  410f6a:	mov    rax,QWORD PTR [rax]
  410f6d:	cmp    rax,0xffffffffffffffff
  410f71:	je     410f80 <__swc_fn_e121059d_000068_f3aa21af+0x1d0>
  410f73:	mov    eax,eax
  410f75:	mov    edi,eax
  410f77:	xor    eax,eax
  410f79:	call   407000 <pthread_getspecific@plt>
  410f7e:	jmp    410f82 <__swc_fn_e121059d_000068_f3aa21af+0x1d2>
  410f80:	xor    eax,eax
  410f82:	test   rax,rax
  410f85:	jne    410f94 <__swc_fn_e121059d_000068_f3aa21af+0x1e4>
  410f87:	call   40ff00 <__swc_fn_e121059d_000035_cd1a4e8c>
  410f8c:	mov    rcx,rax
  410f8f:	call   40dc60 <__swc_fn_e121059d_000133_5f757033>
  410f94:	test   rax,rax
  410f97:	je     410fa4 <__swc_fn_e121059d_000068_f3aa21af+0x1f4>
  410f99:	cmp    QWORD PTR [rax],r12
  410f9c:	jne    410fa4 <__swc_fn_e121059d_000068_f3aa21af+0x1f4>
  410f9e:	cmp    DWORD PTR [rax+0x20],0x0
  410fa2:	je     410faf <__swc_fn_e121059d_000068_f3aa21af+0x1ff>
  410fa4:	mov    rcx,r12
  410fa7:	mov    rdx,rax
  410faa:	call   408a30 <__swc_fn_e121059d_000045_d8bd27c3>
  410faf:	test   rax,rax
  410fb2:	jne    410fbe <__swc_fn_e121059d_000068_f3aa21af+0x20e>
  410fb4:	mov    QWORD PTR [rbx+0x40],0x0
  410fbc:	jmp    411037 <__swc_fn_e121059d_000068_f3aa21af+0x287>
  410fbe:	lea    r8,[rsp+0xc]
  410fc3:	mov    ecx,DWORD PTR [rsp+0x8]
  410fc7:	mov    DWORD PTR [rsp+0xc],ecx
  410fcb:	mov    ecx,DWORD PTR [r8]
  410fce:	lea    rcx,[rcx+rcx*4]
  410fd2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  410fd7:	test   rcx,rcx
  410fda:	je     411013 <__swc_fn_e121059d_000068_f3aa21af+0x263>
  410fdc:	mov    rdx,QWORD PTR [rcx]
  410fdf:	test   rdx,rdx
  410fe2:	je     410ff0 <__swc_fn_e121059d_000068_f3aa21af+0x240>
  410fe4:	mov    r9,QWORD PTR [rdx]
  410fe7:	mov    QWORD PTR [rcx],r9
  410fea:	add    DWORD PTR [rcx+0x28],0x1
  410fee:	jmp    41100e <__swc_fn_e121059d_000068_f3aa21af+0x25e>
  410ff0:	mov    rdx,QWORD PTR [rcx+0x18]
  410ff4:	cmp    QWORD PTR [rcx+0x20],rdx
  410ff8:	jae    41100c <__swc_fn_e121059d_000068_f3aa21af+0x25c>
  410ffa:	mov    rdx,QWORD PTR [rcx+0x20]
  410ffe:	mov    r9d,DWORD PTR [rcx+0x2c]
  411002:	add    QWORD PTR [rcx+0x20],r9
  411006:	add    DWORD PTR [rcx+0x28],0x1
  41100a:	jmp    41100e <__swc_fn_e121059d_000068_f3aa21af+0x25e>
  41100c:	xor    edx,edx
  41100e:	test   rdx,rdx
  411011:	jne    411024 <__swc_fn_e121059d_000068_f3aa21af+0x274>
  411013:	mov    rcx,r12
  411016:	mov    rdx,rax
  411019:	mov    r8d,DWORD PTR [r8]
  41101c:	call   408ba0 <__swc_fn_e121059d_000054_faa92dcc>
  411021:	mov    rdx,rax
  411024:	test   rdx,rdx
  411027:	jne    411033 <__swc_fn_e121059d_000068_f3aa21af+0x283>
  411029:	mov    QWORD PTR [rbx+0x40],0x0
  411031:	jmp    411037 <__swc_fn_e121059d_000068_f3aa21af+0x287>
  411033:	mov    QWORD PTR [rbx+0x40],rdx
  411037:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  41103d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  411043:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  411049:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41104f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  411055:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  41105b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  411061:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  41106a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  411073:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  41107c:	add    rsp,0xb8
  411083:	pop    rsi
  411084:	pop    rdi
  411085:	pop    r12
  411087:	pop    rbx
  411088:	ret
  411089:	add    BYTE PTR [rax],al
  41108b:	add    BYTE PTR [rax],al
  41108d:	add    BYTE PTR [rax],al
	...

0000000000411090 <__swc_fn_e121059d_000071_b3d7b28e>:
  411090:	ret
	...

00000000004110a0 <__swc_fn_e121059d_000074_042643a3>:
  4110a0:	push   r12
  4110a2:	push   r13
  4110a4:	push   r14
  4110a6:	push   rdi
  4110a7:	push   rsi
  4110a8:	sub    rsp,0x1a0
  4110af:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  4110b8:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  4110c1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  4110ca:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  4110d3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  4110dc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  4110e5:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  4110ee:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  4110f7:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  411100:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  411109:	mov    r12,rdx
  41110c:	mov    r13,rcx
  41110f:	mov    rax,QWORD PTR [r12+0x48]
  411114:	mov    ecx,DWORD PTR [r12+0x58]
  411119:	lea    rdx,[rax-0x1]
  41111d:	cmp    rdx,0x10000
  411124:	jae    41121e <__swc_fn_e121059d_000074_042643a3+0x17e>
  41112a:	cmp    rax,0x8
  41112e:	ja     411135 <__swc_fn_e121059d_000074_042643a3+0x95>
  411130:	xor    r14d,r14d
  411133:	jmp    411187 <__swc_fn_e121059d_000074_042643a3+0xe7>
  411135:	cmp    rax,0x80
  41113c:	ja     411148 <__swc_fn_e121059d_000074_042643a3+0xa8>
  41113e:	lea    r14,[rax+0xf]
  411142:	shr    r14,0x4
  411146:	jmp    411187 <__swc_fn_e121059d_000074_042643a3+0xe7>
  411148:	cmp    rax,0x10000
  41114f:	jbe    411159 <__swc_fn_e121059d_000074_042643a3+0xb9>
  411151:	mov    r14d,0xffffffff
  411157:	jmp    411187 <__swc_fn_e121059d_000074_042643a3+0xe7>
  411159:	xor    eax,eax
  41115b:	lzcnt  rax,rdx
  411160:	mov    r8d,0x3f
  411166:	sub    r8d,eax
  411169:	lea    eax,[r8-0x2]
  41116d:	shrx   rax,rdx,rax
  411172:	and    eax,0x3
  411175:	lea    edx,[r8-0x7]
  411179:	lea    edx,[rdx*4+0x0]
  411180:	lea    edx,[rdx+0x9]
  411183:	lea    r14d,[rdx+rax*1]
  411187:	cmp    ecx,0x8
  41118a:	jbe    4111a3 <__swc_fn_e121059d_000074_042643a3+0x103>
  41118c:	cmp    ecx,0x10
  41118f:	jne    41121e <__swc_fn_e121059d_000074_042643a3+0x17e>
  411195:	test   r14d,r14d
  411198:	mov    eax,0x1
  41119d:	cmove  r14d,eax
  4111a1:	jmp    4111aa <__swc_fn_e121059d_000074_042643a3+0x10a>
  4111a3:	lea    eax,[rcx-0x1]
  4111a6:	test   eax,ecx
  4111a8:	jne    41121e <__swc_fn_e121059d_000074_042643a3+0x17e>
  4111aa:	lea    rax,[rip+0x10e57]        # 422008 <__swc_data_base_e121059d+0x8>
  4111b1:	mov    rax,QWORD PTR [rax]
  4111b4:	cmp    rax,0xffffffffffffffff
  4111b8:	je     4111c7 <__swc_fn_e121059d_000074_042643a3+0x127>
  4111ba:	mov    eax,eax
  4111bc:	mov    edi,eax
  4111be:	xor    eax,eax
  4111c0:	call   407000 <pthread_getspecific@plt>
  4111c5:	jmp    4111c9 <__swc_fn_e121059d_000074_042643a3+0x129>
  4111c7:	xor    eax,eax
  4111c9:	test   rax,rax
  4111cc:	je     41121e <__swc_fn_e121059d_000074_042643a3+0x17e>
  4111ce:	cmp    QWORD PTR [rax],r13
  4111d1:	jne    41121e <__swc_fn_e121059d_000074_042643a3+0x17e>
  4111d3:	lea    rcx,[r14+r14*4]
  4111d7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  4111dc:	test   rax,rax
  4111df:	je     41121e <__swc_fn_e121059d_000074_042643a3+0x17e>
  4111e1:	mov    rcx,QWORD PTR [rax]
  4111e4:	test   rcx,rcx
  4111e7:	je     4111f5 <__swc_fn_e121059d_000074_042643a3+0x155>
  4111e9:	mov    rdx,QWORD PTR [rcx]
  4111ec:	mov    QWORD PTR [rax],rdx
  4111ef:	add    DWORD PTR [rax+0x28],0x1
  4111f3:	jmp    411212 <__swc_fn_e121059d_000074_042643a3+0x172>
  4111f5:	mov    rcx,QWORD PTR [rax+0x18]
  4111f9:	cmp    QWORD PTR [rax+0x20],rcx
  4111fd:	jae    411210 <__swc_fn_e121059d_000074_042643a3+0x170>
  4111ff:	mov    rcx,QWORD PTR [rax+0x20]
  411203:	mov    edx,DWORD PTR [rax+0x2c]
  411206:	add    QWORD PTR [rax+0x20],rdx
  41120a:	add    DWORD PTR [rax+0x28],0x1
  41120e:	jmp    411212 <__swc_fn_e121059d_000074_042643a3+0x172>
  411210:	xor    ecx,ecx
  411212:	test   rcx,rcx
  411215:	je     41121e <__swc_fn_e121059d_000074_042643a3+0x17e>
  411217:	mov    QWORD PTR [r12+0x40],rcx
  41121c:	jmp    411229 <__swc_fn_e121059d_000074_042643a3+0x189>
  41121e:	mov    rcx,r13
  411221:	mov    rdx,r12
  411224:	call   409620 <__swc_fn_e121059d_000075_64d36d78>
  411229:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  411232:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  41123b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  411244:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  41124d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  411256:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  41125f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  411268:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  411271:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  41127a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  411283:	add    rsp,0x1a0
  41128a:	pop    rsi
  41128b:	pop    rdi
  41128c:	pop    r14
  41128e:	pop    r13
  411290:	pop    r12
  411292:	ret
	...

00000000004112a0 <__swc_fn_e121059d_000077_7b195156>:
  4112a0:	push   r12
  4112a2:	push   r13
  4112a4:	push   r14
  4112a6:	push   r15
  4112a8:	push   rdi
  4112a9:	push   rsi
  4112aa:	sub    rsp,0x188
  4112b1:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  4112ba:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  4112c3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  4112cc:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  4112d5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  4112de:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  4112e7:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  4112f0:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  4112f9:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  411302:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  41130b:	mov    r12,rdx
  41130e:	mov    r13,rcx
  411311:	mov    r14,QWORD PTR [r12+0x40]
  411316:	lea    rax,[rip+0x12d5b]        # 424078 <__swc_bss_base_e121059d+0x38>
  41131d:	mov    rcx,r14
  411320:	sub    rcx,QWORD PTR [rax+0x8]
  411324:	mov    rax,QWORD PTR [rip+0x12d5d]        # 424088 <__swc_bss_base_e121059d+0x48>
  41132b:	cmp    rcx,rax
  41132e:	jae    41135a <__swc_fn_e121059d_000077_7b195156+0xba>
  411330:	mov    rax,r14
  411333:	and    rax,0xffffffffffc00000
  41133a:	mov    rcx,r14
  41133d:	shr    rcx,0x10
  411341:	and    ecx,0x3f
  411344:	mov    edx,DWORD PTR [rax+0x28]
  411347:	shrx   ecx,ecx,edx
  41134c:	shl    rcx,0x4
  411350:	lea    r15,[rax+rcx*8+0x80]
  411358:	jmp    411365 <__swc_fn_e121059d_000077_7b195156+0xc5>
  41135a:	mov    rcx,r14
  41135d:	call   40fe30 <__swc_fn_e121059d_000026_bcdc5519>
  411362:	mov    r15,rax
  411365:	test   r15,r15
  411368:	je     41140f <__swc_fn_e121059d_000077_7b195156+0x16f>
  41136e:	lea    rax,[rip+0x10c93]        # 422008 <__swc_data_base_e121059d+0x8>
  411375:	mov    rax,QWORD PTR [rax]
  411378:	cmp    rax,0xffffffffffffffff
  41137c:	je     41138b <__swc_fn_e121059d_000077_7b195156+0xeb>
  41137e:	mov    eax,eax
  411380:	mov    edi,eax
  411382:	xor    eax,eax
  411384:	call   407000 <pthread_getspecific@plt>
  411389:	jmp    41138d <__swc_fn_e121059d_000077_7b195156+0xed>
  41138b:	xor    eax,eax
  41138d:	mov    rcx,QWORD PTR [r15+0x40]
  411391:	cmp    rcx,rax
  411394:	jne    4113f4 <__swc_fn_e121059d_000077_7b195156+0x154>
  411396:	test   rax,rax
  411399:	je     41140f <__swc_fn_e121059d_000077_7b195156+0x16f>
  41139b:	mov    ecx,DWORD PTR [r15+0x6c]
  41139f:	test   ecx,ecx
  4113a1:	je     4113c1 <__swc_fn_e121059d_000077_7b195156+0x121>
  4113a3:	mov    rcx,r13
  4113a6:	mov    rdx,rax
  4113a9:	mov    r8,r15
  4113ac:	mov    QWORD PTR [rsp+0xd8],rax
  4113b4:	call   408b30 <__swc_fn_e121059d_000051_e072b516>
  4113b9:	mov    rax,QWORD PTR [rsp+0xd8]
  4113c1:	mov    rcx,QWORD PTR [r15]
  4113c4:	mov    QWORD PTR [r14],rcx
  4113c7:	mov    QWORD PTR [r15],r14
  4113ca:	sub    DWORD PTR [r15+0x28],0x1
  4113cf:	jne    411404 <__swc_fn_e121059d_000077_7b195156+0x164>
  4113d1:	movzx  ecx,BYTE PTR [r15+0x39]
  4113d6:	lea    rcx,[rcx+rcx*4]
  4113da:	lea    rcx,[rax+rcx*8+0x28]
  4113df:	cmp    QWORD PTR [rcx],r15
  4113e2:	je     411404 <__swc_fn_e121059d_000077_7b195156+0x164>
  4113e4:	mov    rcx,r13
  4113e7:	mov    rdx,rax
  4113ea:	mov    r8,r15
  4113ed:	call   40be40 <__swc_fn_e121059d_000055_2e3450f7>
  4113f2:	jmp    411404 <__swc_fn_e121059d_000077_7b195156+0x164>
  4113f4:	test   rcx,rcx
  4113f7:	je     41140f <__swc_fn_e121059d_000077_7b195156+0x16f>
  4113f9:	mov    rcx,r15
  4113fc:	mov    rdx,r14
  4113ff:	call   40fa70 <__swc_fn_e121059d_000014_524c1f23>
  411404:	mov    QWORD PTR [r12+0x40],0x0
  41140d:	jmp    41141a <__swc_fn_e121059d_000077_7b195156+0x17a>
  41140f:	mov    rcx,r13
  411412:	mov    rdx,r12
  411415:	call   409640 <__swc_fn_e121059d_000078_1966ae2e>
  41141a:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  411423:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  41142c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  411435:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  41143e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  411447:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  411450:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  411459:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  411462:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  41146b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  411474:	add    rsp,0x188
  41147b:	pop    rsi
  41147c:	pop    rdi
  41147d:	pop    r15
  41147f:	pop    r14
  411481:	pop    r13
  411483:	pop    r12
  411485:	ret
	...

0000000000411490 <__swc_fn_e121059d_000080_d2cd17e2>:
  411490:	sub    rsp,0x8
  411494:	mov    rax,rdx
  411497:	mov    rdx,QWORD PTR [rax+0x40]
  41149b:	mov    r8,rax
  41149e:	call   411090 <__swc_fn_e121059d_000071_b3d7b28e>
  4114a3:	add    rsp,0x8
  4114a7:	ret
	...

00000000004114b0 <__swc_fn_e121059d_000083_4a10c7e7>:
  4114b0:	push   rsi
  4114b1:	push   rdi
  4114b2:	sub    rsp,0x8
  4114b6:	cmp    rcx,0xffffffffffffffef
  4114ba:	ja     4114e0 <__swc_fn_e121059d_000083_4a10c7e7+0x30>
  4114bc:	xor    esi,esi
  4114be:	lea    rax,[rcx+0x100f]
  4114c5:	and    rax,0xfffffffffffff000
  4114cc:	lea    rcx,[rcx+0x10]
  4114d0:	cmp    rcx,0xfffffffffffff000
  4114d7:	cmovbe rsi,rax
  4114db:	test   rsi,rsi
  4114de:	jne    4114e9 <__swc_fn_e121059d_000083_4a10c7e7+0x39>
  4114e0:	xor    eax,eax
  4114e2:	add    rsp,0x8
  4114e6:	pop    rdi
  4114e7:	pop    rsi
  4114e8:	ret
  4114e9:	mov    rcx,rsi
  4114ec:	call   40a270 <__swc_fn_e121059d_000114_6b799b8d>
  4114f1:	mov    rdi,rax
  4114f4:	test   rax,rax
  4114f7:	jne    411502 <__swc_fn_e121059d_000083_4a10c7e7+0x52>
  4114f9:	xor    eax,eax
  4114fb:	add    rsp,0x8
  4114ff:	pop    rdi
  411500:	pop    rsi
  411501:	ret
  411502:	mov    rcx,rdi
  411505:	mov    rdx,rsi
  411508:	call   411ae0 <__swc_fn_e121059d_000116_36905703>
  41150d:	test   al,al
  41150f:	jne    411525 <__swc_fn_e121059d_000083_4a10c7e7+0x75>
  411511:	mov    rcx,rdi
  411514:	mov    rdx,rsi
  411517:	call   40d910 <__swc_fn_e121059d_000118_ed2d8fed>
  41151c:	xor    eax,eax
  41151e:	add    rsp,0x8
  411522:	pop    rdi
  411523:	pop    rsi
  411524:	ret
  411525:	mov    QWORD PTR [rdi],rsi
  411528:	mov    QWORD PTR [rdi+0x8],0x0
  411530:	lea    rax,[rdi+0x10]
  411534:	add    rsp,0x8
  411538:	pop    rdi
  411539:	pop    rsi
  41153a:	ret
  41153b:	add    BYTE PTR [rax],al
  41153d:	add    BYTE PTR [rax],al
	...

0000000000411540 <__swc_fn_e121059d_000086_3953ef98>:
  411540:	sub    rsp,0x8
  411544:	cmp    BYTE PTR [rcx+0x2c],0x10
  411548:	jne    411553 <__swc_fn_e121059d_000086_3953ef98+0x13>
  41154a:	test   DWORD PTR [rcx+0x28],0x80
  411551:	je     41155b <__swc_fn_e121059d_000086_3953ef98+0x1b>
  411553:	mov    rax,rcx
  411556:	add    rsp,0x8
  41155a:	ret
  41155b:	mov    rcx,QWORD PTR [rcx+0x40]
  41155f:	call   411540 <__swc_fn_e121059d_000086_3953ef98>
  411564:	add    rsp,0x8
  411568:	ret
	...

0000000000411580 <__swc_fn_e121059d_000089_d182c4dc>:
  411580:	push   rsi
  411581:	push   rdi
  411582:	push   r12
  411584:	push   r13
  411586:	sub    rsp,0x8
  41158a:	mov    rsi,rdx
  41158d:	mov    rdi,rcx
  411590:	xor    r8d,r8d
  411593:	call   40c660 <__swc_fn_e121059d_000094_63c1827b>
  411598:	test   al,al
  41159a:	je     4115ac <__swc_fn_e121059d_000089_d182c4dc+0x2c>
  41159c:	mov    eax,0x1
  4115a1:	add    rsp,0x8
  4115a5:	pop    r13
  4115a7:	pop    r12
  4115a9:	pop    rdi
  4115aa:	pop    rsi
  4115ab:	ret
  4115ac:	rex cmp BYTE PTR [rsi+0x2c],0xe
  4115b1:	je     4115c0 <__swc_fn_e121059d_000089_d182c4dc+0x40>
  4115b3:	xor    eax,eax
  4115b5:	add    rsp,0x8
  4115b9:	pop    r13
  4115bb:	pop    r12
  4115bd:	pop    rdi
  4115be:	pop    rsi
  4115bf:	ret
  4115c0:	mov    r12,QWORD PTR [rsi+0x98]
  4115c7:	mov    rax,QWORD PTR [rsi+0xa0]
  4115ce:	mov    rsi,rax
  4115d1:	xor    r13d,r13d
  4115d4:	test   rsi,rsi
  4115d7:	je     411634 <__swc_fn_e121059d_000089_d182c4dc+0xb4>
  4115d9:	cs nop WORD PTR [rax+rax*1+0x0]
  4115e3:	cs nop WORD PTR [rax+rax*1+0x0]
  4115ed:	nop    DWORD PTR [rax]
  4115f0:	lea    rax,[r13*8+0x0]
  4115f8:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  4115fd:	mov    rcx,rax
  411600:	call   411540 <__swc_fn_e121059d_000086_3953ef98>
  411605:	cmp    BYTE PTR [rax+0x2c],0xe
  411609:	jne    41162a <__swc_fn_e121059d_000089_d182c4dc+0xaa>
  41160b:	mov    rcx,rdi
  41160e:	mov    rdx,rax
  411611:	call   411580 <__swc_fn_e121059d_000089_d182c4dc>
  411616:	test   al,al
  411618:	je     41162a <__swc_fn_e121059d_000089_d182c4dc+0xaa>
  41161a:	mov    eax,0x1
  41161f:	add    rsp,0x8
  411623:	pop    r13
  411625:	pop    r12
  411627:	pop    rdi
  411628:	pop    rsi
  411629:	ret
  41162a:	add    r13,0x1
  41162e:	sub    rsi,0x1
  411632:	jne    4115f0 <__swc_fn_e121059d_000089_d182c4dc+0x70>
  411634:	xor    eax,eax
  411636:	add    rsp,0x8
  41163a:	pop    r13
  41163c:	pop    r12
  41163e:	pop    rdi
  41163f:	pop    rsi
  411640:	ret
	...

0000000000411650 <__swc_fn_e121059d_000092_14c65203>:
  411650:	sub    rsp,0x18
  411654:	vxorps xmm0,xmm0,xmm0
  411658:	vmovdqu XMMWORD PTR [rsp],xmm0
  41165d:	call   409850 <__swc_fn_e121059d_000093_c2567a3b>
  411662:	add    rsp,0x18
  411666:	ret
	...

0000000000411670 <__swc_fn_e121059d_000095_ad13d15c>:
  411670:	sub    rsp,0x8
  411674:	mov    rcx,QWORD PTR [rip+0x129c5]        # 424040 <__swc_bss_base_e121059d>
  41167b:	test   rcx,rcx
  41167e:	jne    411690 <__swc_fn_e121059d_000095_ad13d15c+0x20>
  411680:	call   412a40 <__swc_fn_e121059d_000170_994c8876>
  411685:	lea    rcx,[rax+0x1]
  411689:	mov    QWORD PTR [rip+0x129b0],rcx        # 424040 <__swc_bss_base_e121059d>
  411690:	dec    rcx
  411693:	call   40f6e0 <__swc_fn_e121059d_000172_360af05d>
  411698:	mov    rax,QWORD PTR [rax+0xc0]
  41169f:	and    eax,0x1
  4116a2:	setne  al
  4116a5:	add    rsp,0x8
  4116a9:	ret
	...

00000000004116c0 <__swc_fn_e121059d_000098_4f209617>:
  4116c0:	push   rbx
  4116c1:	push   rsi
  4116c2:	push   rdi
  4116c3:	push   r12
  4116c5:	sub    rsp,0x28
  4116c9:	mov    rbx,rcx
  4116cc:	call   40c9c0 <__swc_fn_e121059d_000097_4185993f>
  4116d1:	mov    rcx,QWORD PTR [rip+0x12968]        # 424040 <__swc_bss_base_e121059d>
  4116d8:	test   rcx,rcx
  4116db:	jne    4116ed <__swc_fn_e121059d_000098_4f209617+0x2d>
  4116dd:	call   412a40 <__swc_fn_e121059d_000170_994c8876>
  4116e2:	lea    rcx,[rax+0x1]
  4116e6:	mov    QWORD PTR [rip+0x12953],rcx        # 424040 <__swc_bss_base_e121059d>
  4116ed:	dec    rcx
  4116f0:	call   40f6e0 <__swc_fn_e121059d_000172_360af05d>
  4116f5:	mov    rsi,rax
  4116f8:	lea    rcx,[rsp+0x8]
  4116fd:	call   409c90 <__swc_fn_e121059d_000096_93bfe675>
  411702:	mov    rdi,QWORD PTR [rsi+0x9c0]
  411709:	mov    r12,QWORD PTR [rsi+0xbe8]
  411710:	lea    rcx,[rsi+0x10]
  411714:	call   40add0 <__swc_fn_e121059d_000162_13ead2ff>
  411719:	mov    rcx,rsi
  41171c:	call   409e00 <__swc_fn_e121059d_000105_5a85fcf5>
  411721:	vxorps xmm0,xmm0,xmm0
  411725:	xor    eax,eax
  411727:	cs nop WORD PTR [rax+rax*1+0x0]
  411731:	cs nop WORD PTR [rax+rax*1+0x0]
  41173b:	nop    DWORD PTR [rax+rax*1+0x0]
  411740:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  411745:	add    rax,0x10
  411749:	cmp    rax,0xbf0
  411750:	jne    411740 <__swc_fn_e121059d_000098_4f209617+0x80>
  411752:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  411758:	vmovups XMMWORD PTR [rsi],xmm0
  41175c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  411762:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  41176a:	mov    QWORD PTR [rsi+0x9c0],rdi
  411771:	mov    QWORD PTR [rsi+0xbe8],r12
  411778:	mov    rcx,QWORD PTR [rip+0x128c1]        # 424040 <__swc_bss_base_e121059d>
  41177f:	test   rcx,rcx
  411782:	jne    411794 <__swc_fn_e121059d_000098_4f209617+0xd4>
  411784:	call   412a40 <__swc_fn_e121059d_000170_994c8876>
  411789:	lea    rcx,[rax+0x1]
  41178d:	mov    QWORD PTR [rip+0x128ac],rcx        # 424040 <__swc_bss_base_e121059d>
  411794:	dec    rcx
  411797:	call   40f6e0 <__swc_fn_e121059d_000172_360af05d>
  41179c:	mov    rsi,rax
  41179f:	mov    QWORD PTR [rsi+0xc0],rbx
  4117a6:	and    ebx,0x1
  4117a9:	jne    4117ad <__swc_fn_e121059d_000098_4f209617+0xed>
  4117ab:	xor    eax,eax
  4117ad:	test   rbx,rbx
  4117b0:	sete   al
  4117b3:	xor    cl,cl
  4117b5:	xor    dl,dl
  4117b7:	xor    r8b,r8b
  4117ba:	xor    r9b,r9b
  4117bd:	xor    r10b,r10b
  4117c0:	mov    r11,rax
  4117c3:	call   409650 <__swc_fn_e121059d_000081_5cc7acfc>
  4117c8:	lea    rbx,[rsp+0x18]
  4117cd:	mov    rcx,rbx
  4117d0:	call   409c90 <__swc_fn_e121059d_000096_93bfe675>
  4117d5:	lea    rcx,[rsi+0x10]
  4117d9:	mov    edx,0x400000
  4117de:	mov    r8,rbx
  4117e1:	call   412780 <__swc_fn_e121059d_000164_8a3d304f>
  4117e6:	lea    rcx,[rsi+0x68]
  4117ea:	mov    edx,0x4000
  4117ef:	mov    r8,rbx
  4117f2:	call   412780 <__swc_fn_e121059d_000164_8a3d304f>
  4117f7:	add    rsp,0x28
  4117fb:	pop    r12
  4117fd:	pop    rdi
  4117fe:	pop    rsi
  4117ff:	pop    rbx
  411800:	ret
	...

0000000000411810 <__swc_fn_e121059d_000101_d0b19c14>:
  411810:	push   rbx
  411811:	push   rsi
  411812:	sub    rsp,0x18
  411816:	mov    rbx,rcx
  411819:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  41181e:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  411824:	mov    rsi,QWORD PTR [rbx+0x70]
  411828:	lea    rcx,[rcx+0x18]
  41182c:	call   40add0 <__swc_fn_e121059d_000162_13ead2ff>
  411831:	lea    rcx,[rsp+0x8]
  411836:	mov    rdx,rbx
  411839:	mov    r8d,0x78
  41183f:	call   40ca20 <__swc_fn_e121059d_000100_d4bdcaa4>
  411844:	mov    rax,rsi
  411847:	add    rsp,0x18
  41184b:	pop    rsi
  41184c:	pop    rbx
  41184d:	ret
	...

0000000000411850 <__swc_fn_e121059d_000104_3c3b96fb>:
  411850:	push   rsi
  411851:	push   rdi
  411852:	sub    rsp,0x8
  411856:	cmp    QWORD PTR [rcx],0x0
  41185a:	jne    411863 <__swc_fn_e121059d_000104_3c3b96fb+0x13>
  41185c:	add    rsp,0x8
  411860:	pop    rdi
  411861:	pop    rsi
  411862:	ret
  411863:	mov    rsi,QWORD PTR [rcx]
  411866:	mov    rax,QWORD PTR [rcx+0x8]
  41186a:	test   rax,rax
  41186d:	je     411883 <__swc_fn_e121059d_000104_3c3b96fb+0x33>
  41186f:	test   DWORD PTR [rax+0x28],0x400000
  411876:	je     411883 <__swc_fn_e121059d_000104_3c3b96fb+0x33>
  411878:	mov    rcx,QWORD PTR [rax+0x30]
  41187c:	test   rcx,rcx
  41187f:	cmovne rax,rcx
  411883:	lea    rdx,[rip+0x1b2e]        # 4133b8 <__swc_rdata_base_e121059d+0x2a8>
  41188a:	lea    rcx,[rip+0x1c0f]        # 4134a0 <__swc_rdata_base_e121059d+0x390>
  411891:	mov    r8,rax
  411894:	xor    r9d,r9d
  411897:	xor    al,al
  411899:	mov    r10,rax
  41189c:	xor    r11d,r11d
  41189f:	call   411650 <__swc_fn_e121059d_000092_14c65203>
  4118a4:	test   rax,rax
  4118a7:	je     4118b7 <__swc_fn_e121059d_000104_3c3b96fb+0x67>
  4118a9:	mov    rdi,QWORD PTR [rax+0x48]
  4118ad:	test   rdi,rdi
  4118b0:	je     4118b7 <__swc_fn_e121059d_000104_3c3b96fb+0x67>
  4118b2:	mov    rcx,rsi
  4118b5:	call   rdi
  4118b7:	add    rsp,0x8
  4118bb:	pop    rdi
  4118bc:	pop    rsi
  4118bd:	ret
	...

00000000004118c0 <__swc_fn_e121059d_000107_90faaa26>:
  4118c0:	push   rbx
  4118c1:	push   rsi
  4118c2:	push   rdi
  4118c3:	sub    rsp,0x20
  4118c7:	mov    rbx,rdx
  4118ca:	mov    rsi,rcx
  4118cd:	mov    rcx,QWORD PTR [rip+0x1276c]        # 424040 <__swc_bss_base_e121059d>
  4118d4:	test   rcx,rcx
  4118d7:	jne    4118e9 <__swc_fn_e121059d_000107_90faaa26+0x29>
  4118d9:	call   412a40 <__swc_fn_e121059d_000170_994c8876>
  4118de:	lea    rcx,[rax+0x1]
  4118e2:	mov    QWORD PTR [rip+0x12757],rcx        # 424040 <__swc_bss_base_e121059d>
  4118e9:	dec    rcx
  4118ec:	call   40f6e0 <__swc_fn_e121059d_000172_360af05d>
  4118f1:	mov    rdi,rax
  4118f4:	mov    rax,QWORD PTR [rdi+0xbd0]
  4118fb:	xor    ecx,ecx
  4118fd:	test   rax,rax
  411900:	je     411905 <__swc_fn_e121059d_000107_90faaa26+0x45>
  411902:	mov    rcx,QWORD PTR [rax]
  411905:	call   412b70 <__swc_fn_e121059d_000179_718d7b54>
  41190a:	lea    rax,[rsp+0x8]
  41190f:	lea    rcx,[rdi+0x9c8]
  411916:	mov    QWORD PTR [rsp+0x8],rcx
  41191b:	mov    QWORD PTR [rax+0x8],0x40
  411923:	xor    ecx,ecx
  411925:	mov    rdx,rax
  411928:	call   40da40 <__swc_fn_e121059d_000124_4f256d58>
  41192d:	mov    DWORD PTR [rdi+0xbc8],eax
  411933:	mov    rdi,QWORD PTR [rdi+0x990]
  41193a:	test   rdi,rdi
  41193d:	je     411947 <__swc_fn_e121059d_000107_90faaa26+0x87>
  41193f:	mov    rcx,rsi
  411942:	mov    rdx,rbx
  411945:	call   rdi
  411947:	call   411670 <__swc_fn_e121059d_000095_ad13d15c>
  41194c:	test   al,al
  41194e:	je     41195e <__swc_fn_e121059d_000107_90faaa26+0x9e>
  411950:	mov    rcx,rsi
  411953:	mov    rdx,rbx
  411956:	xor    r8d,r8d
  411959:	call   411c80 <__swc_fn_e121059d_000125_83db7238>
  41195e:	mov    rcx,rsi
  411961:	mov    rdx,rbx
  411964:	call   40cb20 <__swc_fn_e121059d_000106_ffe51047>
  411969:	call   40a620 <__swc_fn_e121059d_000123_be2e2f68>
  41196e:	add    rsp,0x20
  411972:	pop    rdi
  411973:	pop    rsi
  411974:	pop    rbx
  411975:	ret
	...

0000000000411980 <__swc_fn_e121059d_000110_7c204aac>:
  411980:	sub    rsp,0x8
  411984:	test   r8,r8
  411987:	je     41198e <__swc_fn_e121059d_000110_7c204aac+0xe>
  411989:	call   409fd0 <__swc_fn_e121059d_000108_c51c3158>
  41198e:	add    rsp,0x8
  411992:	ret
	...

00000000004119a0 <__swc_fn_e121059d_000113_126150d1>:
  4119a0:	push   rsi
  4119a1:	push   rdi
  4119a2:	push   r12
  4119a4:	push   r13
  4119a6:	sub    rsp,0xd8
  4119ad:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  4119b3:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  4119b9:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  4119bf:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  4119c5:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  4119cb:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  4119d4:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  4119dd:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  4119e6:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  4119ef:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  4119f8:	xor    eax,eax
  4119fa:	call   4070e0 <getpid@plt>
  4119ff:	mov    rsi,rax
  411a02:	lea    rdi,[rip+0x15337]        # 426d40 <__swc_bss_base_e121059d+0x2d00>
  411a09:	mov    r12,QWORD PTR [rdi]
  411a0c:	test   r12,r12
  411a0f:	je     411a1d <__swc_fn_e121059d_000113_126150d1+0x7d>
  411a11:	cmp    DWORD PTR [r12+0x10],esi
  411a16:	jne    411a1d <__swc_fn_e121059d_000113_126150d1+0x7d>
  411a18:	mov    rax,r12
  411a1b:	jmp    411a80 <__swc_fn_e121059d_000113_126150d1+0xe0>
  411a1d:	mov    ecx,0x4
  411a22:	mov    edx,0x18
  411a27:	call   40d250 <__swc_fn_e121059d_000112_6814119b>
  411a2c:	mov    rcx,rax
  411a2f:	test   rax,rax
  411a32:	jne    411a38 <__swc_fn_e121059d_000113_126150d1+0x98>
  411a34:	xor    eax,eax
  411a36:	jmp    411a80 <__swc_fn_e121059d_000113_126150d1+0xe0>
  411a38:	mov    DWORD PTR [rcx+0x10],esi
  411a3b:	mov    rax,r12
  411a3e:	lock cmpxchg QWORD PTR [rdi],rcx
  411a43:	mov    r13,rax
  411a46:	cmp    rax,r12
  411a49:	je     411a5f <__swc_fn_e121059d_000113_126150d1+0xbf>
  411a4b:	mov    rdi,rcx
  411a4e:	mov    esi,0x18
  411a53:	xor    eax,eax
  411a55:	call   407030 <munmap@plt>
  411a5a:	mov    rax,r13
  411a5d:	jmp    411a80 <__swc_fn_e121059d_000113_126150d1+0xe0>
  411a5f:	test   r12,r12
  411a62:	je     411a7d <__swc_fn_e121059d_000113_126150d1+0xdd>
  411a64:	mov    rdi,r12
  411a67:	mov    esi,0x18
  411a6c:	xor    eax,eax
  411a6e:	mov    QWORD PTR [rsp+0x28],rcx
  411a73:	call   407030 <munmap@plt>
  411a78:	mov    rcx,QWORD PTR [rsp+0x28]
  411a7d:	mov    rax,rcx
  411a80:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  411a86:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  411a8c:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  411a92:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  411a98:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  411a9e:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  411aa7:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  411ab0:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  411ab9:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  411ac2:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  411acb:	add    rsp,0xd8
  411ad2:	pop    r13
  411ad4:	pop    r12
  411ad6:	pop    rdi
  411ad7:	pop    rsi
  411ad8:	ret
  411ad9:	add    BYTE PTR [rax],al
  411adb:	add    BYTE PTR [rax],al
  411add:	add    BYTE PTR [rax],al
	...

0000000000411ae0 <__swc_fn_e121059d_000116_36905703>:
  411ae0:	push   rbx
  411ae1:	push   r12
  411ae3:	push   rdi
  411ae4:	push   rsi
  411ae5:	sub    rsp,0xa8
  411aec:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  411af2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411af8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  411afe:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411b04:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411b0a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  411b10:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411b16:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411b1c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411b25:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  411b2e:	mov    rbx,rdx
  411b31:	mov    r12,rcx
  411b34:	mov    rdi,rcx
  411b37:	mov    rsi,rdx
  411b3a:	mov    edx,0x3
  411b3f:	xor    eax,eax
  411b41:	call   407020 <mprotect@plt>
  411b46:	test   eax,eax
  411b48:	je     411b4e <__swc_fn_e121059d_000116_36905703+0x6e>
  411b4a:	xor    eax,eax
  411b4c:	jmp    411b63 <__swc_fn_e121059d_000116_36905703+0x83>
  411b4e:	mov    rcx,r12
  411b51:	mov    rdx,rbx
  411b54:	mov    al,0x1
  411b56:	mov    r8,rax
  411b59:	call   40d880 <__swc_fn_e121059d_000115_5f48311c>
  411b5e:	mov    eax,0x1
  411b63:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  411b69:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411b6f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411b75:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411b7b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411b81:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411b87:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411b8d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411b93:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411b9c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411ba5:	add    rsp,0xa8
  411bac:	pop    rsi
  411bad:	pop    rdi
  411bae:	pop    r12
  411bb0:	pop    rbx
  411bb1:	ret
	...

0000000000411bc0 <__swc_fn_e121059d_000119_5208f471>:
  411bc0:	sub    rsp,0x8
  411bc4:	test   rcx,rcx
  411bc7:	jne    411bce <__swc_fn_e121059d_000119_5208f471+0xe>
  411bc9:	add    rsp,0x8
  411bcd:	ret
  411bce:	call   40a4d0 <__swc_fn_e121059d_000120_d3318640>
  411bd3:	add    rsp,0x8
  411bd7:	ret
	...

0000000000411be0 <__swc_fn_e121059d_000122_0a5fa85a>:
  411be0:	push   rdi
  411be1:	push   rsi
  411be2:	sub    rsp,0xa8
  411be9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  411bef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411bf5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  411bfb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411c01:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411c07:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  411c0d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411c13:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411c19:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411c22:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  411c2b:	xor    edi,edi
  411c2d:	xor    eax,eax
  411c2f:	call   407050 <exit@plt>
  411c34:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  411c3a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411c40:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411c46:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411c4c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411c52:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411c58:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411c5e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411c64:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411c6d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411c76:	add    rsp,0xa8
  411c7d:	pop    rsi
  411c7e:	pop    rdi
  411c7f:	ret

0000000000411c80 <__swc_fn_e121059d_000125_83db7238>:
  411c80:	push   rbx
  411c81:	push   rsi
  411c82:	push   rdi
  411c83:	push   r12
  411c85:	sub    rsp,0x18
  411c89:	mov    rbx,r8
  411c8c:	mov    rsi,rcx
  411c8f:	mov    rdi,rdx
  411c92:	mov    rcx,QWORD PTR [rip+0x123a7]        # 424040 <__swc_bss_base_e121059d>
  411c99:	test   rcx,rcx
  411c9c:	jne    411cae <__swc_fn_e121059d_000125_83db7238+0x2e>
  411c9e:	call   412a40 <__swc_fn_e121059d_000170_994c8876>
  411ca3:	lea    rcx,[rax+0x1]
  411ca7:	mov    QWORD PTR [rip+0x12392],rcx        # 424040 <__swc_bss_base_e121059d>
  411cae:	dec    rcx
  411cb1:	call   40f6e0 <__swc_fn_e121059d_000172_360af05d>
  411cb6:	mov    r12,rax
  411cb9:	cmp    ebx,0x3
  411cbc:	jne    411ccf <__swc_fn_e121059d_000125_83db7238+0x4f>
  411cbe:	mov    rax,QWORD PTR [r12+0xbd0]
  411cc6:	test   rax,rax
  411cc9:	jne    411e0c <__swc_fn_e121059d_000125_83db7238+0x18c>
  411ccf:	cmp    ebx,0x5
  411cd2:	jne    411cf6 <__swc_fn_e121059d_000125_83db7238+0x76>
  411cd4:	call   411670 <__swc_fn_e121059d_000095_ad13d15c>
  411cd9:	test   al,al
  411cdb:	jne    411cf6 <__swc_fn_e121059d_000125_83db7238+0x76>
  411cdd:	mov    rcx,rsi
  411ce0:	mov    rdx,rdi
  411ce3:	call   40f690 <__swc_fn_e121059d_000169_3459066f>
  411ce8:	test   al,al
  411cea:	je     411cf6 <__swc_fn_e121059d_000125_83db7238+0x76>
  411cec:	add    rsp,0x18
  411cf0:	pop    r12
  411cf2:	pop    rdi
  411cf3:	pop    rsi
  411cf4:	pop    rbx
  411cf5:	ret
  411cf6:	call   411670 <__swc_fn_e121059d_000095_ad13d15c>
  411cfb:	test   al,al
  411cfd:	jne    411d6f <__swc_fn_e121059d_000125_83db7238+0xef>
  411cff:	vmovups xmm0,XMMWORD PTR [rsi]
  411d03:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  411d09:	mov    rax,QWORD PTR [rsp+0x8]
  411d0e:	test   rax,rax
  411d11:	jne    411d62 <__swc_fn_e121059d_000125_83db7238+0xe2>
  411d13:	cmp    ebx,0x3
  411d16:	je     411d24 <__swc_fn_e121059d_000125_83db7238+0xa4>
  411d18:	cmp    ebx,0x4
  411d1b:	je     411d34 <__swc_fn_e121059d_000125_83db7238+0xb4>
  411d1d:	cmp    ebx,0x5
  411d20:	je     411d44 <__swc_fn_e121059d_000125_83db7238+0xc4>
  411d22:	jmp    411d54 <__swc_fn_e121059d_000125_83db7238+0xd4>
  411d24:	vmovups xmm0,XMMWORD PTR [rip+0x1944]        # 413670 <__swc_rdata_base_e121059d+0x560>
  411d2c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  411d32:	jmp    411d62 <__swc_fn_e121059d_000125_83db7238+0xe2>
  411d34:	vmovups xmm0,XMMWORD PTR [rip+0x1944]        # 413680 <__swc_rdata_base_e121059d+0x570>
  411d3c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  411d42:	jmp    411d62 <__swc_fn_e121059d_000125_83db7238+0xe2>
  411d44:	vmovups xmm0,XMMWORD PTR [rip+0x1944]        # 413690 <__swc_rdata_base_e121059d+0x580>
  411d4c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  411d52:	jmp    411d62 <__swc_fn_e121059d_000125_83db7238+0xe2>
  411d54:	vmovups xmm0,XMMWORD PTR [rip+0x1944]        # 4136a0 <__swc_rdata_base_e121059d+0x590>
  411d5c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  411d62:	lea    rcx,[rsp+0x8]
  411d67:	mov    rdx,rdi
  411d6a:	call   4118c0 <__swc_fn_e121059d_000107_90faaa26>
  411d6f:	vmovups xmm0,XMMWORD PTR [rdi]
  411d73:	vmovups XMMWORD PTR [r12+0x940],xmm0
  411d7d:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  411d82:	vmovups XMMWORD PTR [r12+0x950],xmm0
  411d8c:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  411d91:	vmovups XMMWORD PTR [r12+0x960],xmm0
  411d9b:	lea    rax,[r12+0x940]
  411da3:	mov    QWORD PTR [r12+0x970],rax
  411dab:	mov    rax,QWORD PTR [rsi]
  411dae:	mov    QWORD PTR [r12+0x978],rax
  411db6:	mov    rax,QWORD PTR [rsi+0x8]
  411dba:	mov    QWORD PTR [r12+0x980],rax
  411dc2:	movsxd rax,ebx
  411dc5:	mov    QWORD PTR [r12+0x988],rax
  411dcd:	cmp    ebx,0x5
  411dd0:	je     411dd9 <__swc_fn_e121059d_000125_83db7238+0x159>
  411dd2:	xor    ecx,ecx
  411dd4:	call   412b70 <__swc_fn_e121059d_000179_718d7b54>
  411dd9:	mov    rbx,QWORD PTR [r12+0xbe8]
  411de1:	test   rbx,rbx
  411de4:	je     411df5 <__swc_fn_e121059d_000125_83db7238+0x175>
  411de6:	mov    rcx,r12
  411de9:	call   rbx
  411deb:	add    rsp,0x18
  411def:	pop    r12
  411df1:	pop    rdi
  411df2:	pop    rsi
  411df3:	pop    rbx
  411df4:	ret
  411df5:	mov    rcx,rsi
  411df8:	call   40d930 <__swc_fn_e121059d_000121_2648f149>
  411dfd:	call   40a620 <__swc_fn_e121059d_000123_be2e2f68>
  411e02:	add    rsp,0x18
  411e06:	pop    r12
  411e08:	pop    rdi
  411e09:	pop    rsi
  411e0a:	pop    rbx
  411e0b:	ret
  411e0c:	mov    rcx,rsi
  411e0f:	mov    rdx,rdi
  411e12:	call   4118c0 <__swc_fn_e121059d_000107_90faaa26>
  411e17:	jmp    411ccf <__swc_fn_e121059d_000125_83db7238+0x4f>
  411e1c:	add    BYTE PTR [rax],al
	...

0000000000411e20 <__swc_fn_e121059d_000128_58f0f391>:
  411e20:	push   rdi
  411e21:	push   rsi
  411e22:	sub    rsp,0xb8
  411e29:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  411e2f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  411e35:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  411e3b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  411e41:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  411e47:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  411e4d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  411e53:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  411e5c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  411e65:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  411e6e:	mov    DWORD PTR [rsp+0x8],0x0
  411e76:	lea    rdi,[rsp+0x8]
  411e7b:	xor    esi,esi
  411e7d:	xor    eax,eax
  411e7f:	call   4071e0 <pthread_key_create@plt>
  411e84:	test   eax,eax
  411e86:	jne    411e8e <__swc_fn_e121059d_000128_58f0f391+0x6e>
  411e88:	mov    eax,DWORD PTR [rsp+0x8]
  411e8c:	jmp    411e95 <__swc_fn_e121059d_000128_58f0f391+0x75>
  411e8e:	mov    rax,0xffffffffffffffff
  411e95:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  411e9b:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  411ea1:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  411ea7:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  411ead:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  411eb3:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  411eb9:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  411ebf:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  411ec8:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  411ed1:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  411eda:	add    rsp,0xb8
  411ee1:	pop    rsi
  411ee2:	pop    rdi
  411ee3:	ret
	...

0000000000411ef0 <__swc_fn_e121059d_000131_4a82cdf6>:
  411ef0:	push   rdi
  411ef1:	push   rsi
  411ef2:	sub    rsp,0xb8
  411ef9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  411eff:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  411f05:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  411f0b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  411f11:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  411f17:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  411f1d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  411f23:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  411f2c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  411f35:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  411f3e:	mov    DWORD PTR [rsp+0x8],0x0
  411f46:	lea    rdi,[rsp+0x8]
  411f4b:	mov    rsi,rcx
  411f4e:	xor    eax,eax
  411f50:	call   4071e0 <pthread_key_create@plt>
  411f55:	test   eax,eax
  411f57:	jne    411f62 <__swc_fn_e121059d_000131_4a82cdf6+0x72>
  411f59:	mov    eax,DWORD PTR [rsp+0x8]
  411f5d:	inc    rax
  411f60:	jmp    411f64 <__swc_fn_e121059d_000131_4a82cdf6+0x74>
  411f62:	xor    eax,eax
  411f64:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  411f6a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  411f70:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  411f76:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  411f7c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  411f82:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  411f88:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  411f8e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  411f97:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  411fa0:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  411fa9:	add    rsp,0xb8
  411fb0:	pop    rsi
  411fb1:	pop    rdi
  411fb2:	ret
	...

0000000000411fc0 <__swc_fn_e121059d_000134_ae5891af>:
  411fc0:	push   rdi
  411fc1:	push   rsi
  411fc2:	sub    rsp,0xa8
  411fc9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  411fcf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411fd5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  411fdb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411fe1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411fe7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  411fed:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411ff3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411ff9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  412002:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41200b:	test   rcx,rcx
  41200e:	setne  al
  412011:	je     41202a <__swc_fn_e121059d_000134_ae5891af+0x6a>
  412013:	lea    rax,[rcx-0x1]
  412017:	mov    eax,eax
  412019:	mov    edi,eax
  41201b:	mov    rsi,rdx
  41201e:	xor    eax,eax
  412020:	call   4071a0 <pthread_setspecific@plt>
  412025:	test   eax,eax
  412027:	sete   al
  41202a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  412030:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  412036:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41203c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  412042:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  412048:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  41204e:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  412054:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  41205a:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  412063:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41206c:	add    rsp,0xa8
  412073:	pop    rsi
  412074:	pop    rdi
  412075:	ret
	...

0000000000412080 <__swc_fn_e121059d_000137_865f5106>:
  412080:	push   rdi
  412081:	push   rsi
  412082:	sub    rsp,0xa8
  412089:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41208f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  412095:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41209b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4120a1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4120a7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4120ad:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4120b3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4120b9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4120c2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4120cb:	mov    rax,rdx
  4120ce:	mov    QWORD PTR [rsp],0x0
  4120d6:	mov    edi,0xca
  4120db:	mov    rsi,rcx
  4120de:	mov    edx,0x81
  4120e3:	mov    eax,eax
  4120e5:	mov    ecx,eax
  4120e7:	xor    r8d,r8d
  4120ea:	xor    r9d,r9d
  4120ed:	xor    eax,eax
  4120ef:	call   407080 <syscall@plt>
  4120f4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4120fa:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  412100:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  412106:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41210c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  412112:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  412118:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41211e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  412124:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41212d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  412136:	add    rsp,0xa8
  41213d:	pop    rsi
  41213e:	pop    rdi
  41213f:	ret

0000000000412140 <__swc_fn_e121059d_000140_86bb0f90>:
  412140:	sub    rsp,0x8
  412144:	call   40a9d0 <__swc_fn_e121059d_000138_8c07c14b>
  412149:	add    rsp,0x8
  41214d:	ret
	...

0000000000412150 <__swc_fn_e121059d_000143_be4c2719>:
  412150:	push   rdi
  412151:	push   rsi
  412152:	sub    rsp,0xc8
  412159:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  41215f:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  412165:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  41216b:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  412171:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  412177:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  41217d:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  412186:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  41218f:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  412198:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  4121a1:	vxorps xmm0,xmm0,xmm0
  4121a5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4121ab:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4121b1:	mov    rdi,rcx
  4121b4:	lea    rsi,[rsp+0x8]
  4121b9:	xor    eax,eax
  4121bb:	call   4071f0 <dladdr@plt>
  4121c0:	xor    ecx,ecx
  4121c2:	test   eax,eax
  4121c4:	je     4121cb <__swc_fn_e121059d_000143_be4c2719+0x7b>
  4121c6:	mov    rcx,QWORD PTR [rsp+0x10]
  4121cb:	mov    rax,rcx
  4121ce:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  4121d4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  4121da:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  4121e0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  4121e6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  4121ec:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  4121f2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  4121fb:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  412204:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  41220d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  412216:	add    rsp,0xc8
  41221d:	pop    rsi
  41221e:	pop    rdi
  41221f:	ret

0000000000412220 <__swc_fn_e121059d_000146_1534de9a>:
  412220:	push   rbx
  412221:	push   r12
  412223:	push   r13
  412225:	push   rdi
  412226:	push   rsi
  412227:	push   r14
  412229:	push   r15
  41222b:	sub    rsp,0x150
  412232:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  41223b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  412244:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  41224d:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  412256:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  41225f:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  412268:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  412271:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  41227a:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  412283:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  41228c:	mov    rbx,rdx
  41228f:	mov    QWORD PTR [rsp+0x98],rdx
  412297:	mov    r12,rcx
  41229a:	mov    QWORD PTR [rsp+0xa0],rcx
  4122a2:	mov    QWORD PTR [rbx],0x0
  4122a9:	lea    r13,[rip+0x14ac8]        # 426d78 <__swc_bss_base_e121059d+0x2d38>
  4122b0:	mov    rcx,r13
  4122b3:	call   412140 <__swc_fn_e121059d_000140_86bb0f90>
  4122b8:	mov    rax,QWORD PTR [rip+0x14ac1]        # 426d80 <__swc_bss_base_e121059d+0x2d40>
  4122bf:	test   rax,rax
  4122c2:	je     4122f9 <__swc_fn_e121059d_000146_1534de9a+0xd9>
  4122c4:	cs nop WORD PTR [rax+rax*1+0x0]
  4122ce:	xchg   ax,ax
  4122d0:	cmp    QWORD PTR [rax+0x8],r12
  4122d4:	jne    4122f1 <__swc_fn_e121059d_000146_1534de9a+0xd1>
  4122d6:	mov    rcx,QWORD PTR [rax+0x18]
  4122da:	mov    QWORD PTR [rbx],rcx
  4122dd:	mov    rbx,QWORD PTR [rax+0x10]
  4122e1:	mov    rcx,r13
  4122e4:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  4122e9:	mov    rax,rbx
  4122ec:	jmp    4124db <__swc_fn_e121059d_000146_1534de9a+0x2bb>
  4122f1:	mov    rax,QWORD PTR [rax]
  4122f4:	test   rax,rax
  4122f7:	jne    4122d0 <__swc_fn_e121059d_000146_1534de9a+0xb0>
  4122f9:	vxorps xmm0,xmm0,xmm0
  4122fd:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  412303:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  412309:	mov    rdi,r12
  41230c:	lea    rsi,[rsp+0x10]
  412311:	xor    eax,eax
  412313:	call   4071f0 <dladdr@plt>
  412318:	test   eax,eax
  41231a:	sete   al
  41231d:	je     41232a <__swc_fn_e121059d_000146_1534de9a+0x10a>
  41231f:	mov    rax,QWORD PTR [rsp+0x10]
  412324:	test   rax,rax
  412327:	sete   al
  41232a:	test   al,al
  41232c:	je     41233d <__swc_fn_e121059d_000146_1534de9a+0x11d>
  41232e:	mov    rcx,r13
  412331:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  412336:	xor    eax,eax
  412338:	jmp    4124db <__swc_fn_e121059d_000146_1534de9a+0x2bb>
  41233d:	mov    rdi,QWORD PTR [rsp+0x10]
  412342:	mov    esi,0x80000
  412347:	xor    eax,eax
  412349:	call   4070a0 <open@plt>
  41234e:	lea    r14,[rsp+0x30]
  412353:	mov    DWORD PTR [rsp+0x30],eax
  412357:	cmp    DWORD PTR [r14],0x0
  41235b:	jge    41236c <__swc_fn_e121059d_000146_1534de9a+0x14c>
  41235d:	mov    rcx,r13
  412360:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  412365:	xor    eax,eax
  412367:	jmp    4124db <__swc_fn_e121059d_000146_1534de9a+0x2bb>
  41236c:	mov    rax,r14
  41236f:	movsxd rdi,DWORD PTR [rax]
  412372:	xor    esi,esi
  412374:	mov    edx,0x2
  412379:	xor    eax,eax
  41237b:	call   407150 <lseek@plt>
  412380:	mov    r15,rax
  412383:	test   rax,rax
  412386:	jg     4123a1 <__swc_fn_e121059d_000146_1534de9a+0x181>
  412388:	movsxd rdi,DWORD PTR [r14]
  41238b:	xor    eax,eax
  41238d:	call   4070d0 <close@plt>
  412392:	mov    rcx,r13
  412395:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  41239a:	xor    eax,eax
  41239c:	jmp    4124db <__swc_fn_e121059d_000146_1534de9a+0x2bb>
  4123a1:	xor    edi,edi
  4123a3:	mov    rsi,r15
  4123a6:	mov    edx,0x1
  4123ab:	mov    ecx,0x2
  4123b0:	mov    rax,r14
  4123b3:	movsxd r8,DWORD PTR [rax]
  4123b6:	xor    r9d,r9d
  4123b9:	xor    eax,eax
  4123bb:	call   407010 <mmap@plt>
  4123c0:	mov    rbx,rax
  4123c3:	test   rax,rax
  4123c6:	sete   al
  4123c9:	cmp    rbx,0xffffffffffffffff
  4123cd:	sete   cl
  4123d0:	or     al,cl
  4123d2:	je     4123ed <__swc_fn_e121059d_000146_1534de9a+0x1cd>
  4123d4:	movsxd rdi,DWORD PTR [r14]
  4123d7:	xor    eax,eax
  4123d9:	call   4070d0 <close@plt>
  4123de:	mov    rcx,r13
  4123e1:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  4123e6:	xor    eax,eax
  4123e8:	jmp    4124db <__swc_fn_e121059d_000146_1534de9a+0x2bb>
  4123ed:	lea    rax,[rsp+0x50]
  4123f2:	mov    QWORD PTR [rax],0x0
  4123f9:	mov    rcx,rbx
  4123fc:	mov    rdx,r15
  4123ff:	mov    r8,rax
  412402:	call   40dec0 <__swc_fn_e121059d_000145_d5d4d43f>
  412407:	mov    r12,rax
  41240a:	test   rax,rax
  41240d:	jne    412435 <__swc_fn_e121059d_000146_1534de9a+0x215>
  41240f:	mov    rdi,rbx
  412412:	mov    rsi,r15
  412415:	xor    eax,eax
  412417:	call   407030 <munmap@plt>
  41241c:	movsxd rdi,DWORD PTR [r14]
  41241f:	xor    eax,eax
  412421:	call   4070d0 <close@plt>
  412426:	mov    rcx,r13
  412429:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  41242e:	xor    eax,eax
  412430:	jmp    4124db <__swc_fn_e121059d_000146_1534de9a+0x2bb>
  412435:	mov    edi,0x20
  41243a:	xor    eax,eax
  41243c:	call   407090 <malloc@plt>
  412441:	test   rax,rax
  412444:	jne    412469 <__swc_fn_e121059d_000146_1534de9a+0x249>
  412446:	mov    rdi,rbx
  412449:	mov    rsi,r15
  41244c:	xor    eax,eax
  41244e:	call   407030 <munmap@plt>
  412453:	movsxd rdi,DWORD PTR [r14]
  412456:	xor    eax,eax
  412458:	call   4070d0 <close@plt>
  41245d:	mov    rcx,r13
  412460:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  412465:	xor    eax,eax
  412467:	jmp    4124db <__swc_fn_e121059d_000146_1534de9a+0x2bb>
  412469:	mov    rcx,QWORD PTR [rip+0x14910]        # 426d80 <__swc_bss_base_e121059d+0x2d40>
  412470:	mov    QWORD PTR [rsp+0x70],rcx
  412475:	mov    rcx,QWORD PTR [rsp+0xa0]
  41247d:	mov    QWORD PTR [rsp+0x78],rcx
  412482:	mov    QWORD PTR [rsp+0x80],r12
  41248a:	mov    rcx,QWORD PTR [rsp+0x50]
  41248f:	mov    QWORD PTR [rsp+0x88],rcx
  412497:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  41249d:	vmovups XMMWORD PTR [rax],xmm0
  4124a1:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  4124aa:	vmovups XMMWORD PTR [rax+0x10],xmm0
  4124af:	mov    QWORD PTR [rip+0x148ca],rax        # 426d80 <__swc_bss_base_e121059d+0x2d40>
  4124b6:	mov    rax,QWORD PTR [rsp+0x50]
  4124bb:	mov    rbx,QWORD PTR [rsp+0x98]
  4124c3:	mov    QWORD PTR [rbx],rax
  4124c6:	movsxd rdi,DWORD PTR [r14]
  4124c9:	xor    eax,eax
  4124cb:	call   4070d0 <close@plt>
  4124d0:	mov    rcx,r13
  4124d3:	call   40aad0 <__swc_fn_e121059d_000141_055b38a4>
  4124d8:	mov    rax,r12
  4124db:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  4124e4:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  4124ed:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  4124f6:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  4124ff:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  412508:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  412511:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  41251a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  412523:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  41252c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  412535:	add    rsp,0x150
  41253c:	pop    r15
  41253e:	pop    r14
  412540:	pop    rsi
  412541:	pop    rdi
  412542:	pop    r13
  412544:	pop    r12
  412546:	pop    rbx
  412547:	ret
	...

0000000000412550 <__swc_fn_e121059d_000149_43c96957>:
  412550:	push   rbx
  412551:	sub    rsp,0xe0
  412558:	lea    rbx,[rsp+0x8]
  41255d:	vxorps xmm0,xmm0,xmm0
  412561:	vmovups YMMWORD PTR [rbx],ymm0
  412565:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  41256a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  41256f:	vzeroupper
  412572:	mov    DWORD PTR [rbx+0x60],0x0
  412579:	mov    r8,rbx
  41257c:	nop    DWORD PTR [rax+0x0]
  412580:	mov    r9,rcx
  412583:	movabs rcx,0xcccccccccccccccd
  41258d:	mov    rax,r9
  412590:	mul    rcx
  412593:	mov    r10,rdx
  412596:	shr    r10,0x3
  41259a:	mov    rcx,r10
  41259d:	imul   rdx,r10,0xa
  4125a1:	sub    r9,rdx
  4125a4:	mov    rdx,QWORD PTR [rip+0x1125]        # 4136d0 <__swc_rdata_base_e121059d+0x5c0>
  4125ab:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  4125b0:	mov    BYTE PTR [r8],dl
  4125b3:	lea    rdx,[r8+0x1]
  4125b7:	mov    r8,rdx
  4125ba:	test   r10,r10
  4125bd:	jne    412580 <__swc_fn_e121059d_000149_43c96957+0x30>
  4125bf:	mov    BYTE PTR [rdx],0x0
  4125c2:	sub    r8,0x1
  4125c6:	mov    rax,rbx
  4125c9:	cmp    rax,r8
  4125cc:	jae    4125e6 <__swc_fn_e121059d_000149_43c96957+0x96>
  4125ce:	xchg   ax,ax
  4125d0:	mov    cl,BYTE PTR [r8]
  4125d3:	mov    dl,BYTE PTR [rax]
  4125d5:	mov    BYTE PTR [r8],dl
  4125d8:	sub    r8,0x1
  4125dc:	mov    BYTE PTR [rax],cl
  4125de:	inc    rax
  4125e1:	cmp    rax,r8
  4125e4:	jb     4125d0 <__swc_fn_e121059d_000149_43c96957+0x80>
  4125e6:	xor    eax,eax
  4125e8:	test   rbx,rbx
  4125eb:	je     41260e <__swc_fn_e121059d_000149_43c96957+0xbe>
  4125ed:	mov    rcx,rbx
  4125f0:	mov    dl,BYTE PTR [rcx]
  4125f2:	test   dl,dl
  4125f4:	je     41260e <__swc_fn_e121059d_000149_43c96957+0xbe>
  4125f6:	cs nop WORD PTR [rax+rax*1+0x0]
  412600:	add    rcx,0x1
  412604:	add    rax,0x1
  412608:	mov    dl,BYTE PTR [rcx]
  41260a:	test   dl,dl
  41260c:	jne    412600 <__swc_fn_e121059d_000149_43c96957+0xb0>
  41260e:	mov    QWORD PTR [rbx+0xa8],rbx
  412615:	mov    QWORD PTR [rbx+0xb0],rax
  41261c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  412624:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  41262c:	lea    rcx,[rbx+0xb8]
  412633:	call   40d930 <__swc_fn_e121059d_000121_2648f149>
  412638:	add    rsp,0xe0
  41263f:	pop    rbx
  412640:	ret
	...

0000000000412650 <__swc_fn_e121059d_000152_6fb05988>:
  412650:	sub    rsp,0x8
  412654:	mov    rax,QWORD PTR [rcx+0x8]
  412658:	mov    r8,QWORD PTR [rdx+0x8]
  41265c:	cmp    rax,r8
  41265f:	je     412668 <__swc_fn_e121059d_000152_6fb05988+0x18>
  412661:	xor    eax,eax
  412663:	add    rsp,0x8
  412667:	ret
  412668:	test   rax,rax
  41266b:	jne    41267c <__swc_fn_e121059d_000152_6fb05988+0x2c>
  41266d:	test   r8,r8
  412670:	jne    41267c <__swc_fn_e121059d_000152_6fb05988+0x2c>
  412672:	mov    eax,0x1
  412677:	add    rsp,0x8
  41267b:	ret
  41267c:	mov    rcx,QWORD PTR [rcx]
  41267f:	mov    rdx,QWORD PTR [rdx]
  412682:	test   rcx,rcx
  412685:	sete   r8b
  412689:	test   rdx,rdx
  41268c:	sete   r9b
  412690:	or     r8b,r9b
  412693:	je     4126a0 <__swc_fn_e121059d_000152_6fb05988+0x50>
  412695:	cmp    rcx,rdx
  412698:	sete   al
  41269b:	add    rsp,0x8
  41269f:	ret
  4126a0:	cmp    rcx,rdx
  4126a3:	jne    4126af <__swc_fn_e121059d_000152_6fb05988+0x5f>
  4126a5:	mov    eax,0x1
  4126aa:	add    rsp,0x8
  4126ae:	ret
  4126af:	mov    r8,rax
  4126b2:	call   40a0b0 <__swc_fn_e121059d_000111_3dc01326>
  4126b7:	test   eax,eax
  4126b9:	sete   al
  4126bc:	add    rsp,0x8
  4126c0:	ret
	...

00000000004126d0 <__swc_fn_e121059d_000155_86f1d437>:
  4126d0:	vxorps xmm0,xmm0,xmm0
  4126d4:	vmovups XMMWORD PTR [rcx],xmm0
  4126d8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4126dd:	vxorps xmm0,xmm0,xmm0
  4126e1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4126e6:	vmovups xmm0,XMMWORD PTR [rip+0x108a]        # 413778 <__swc_rdata_base_e121059d+0x668>
  4126ee:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4126f3:	ret
	...

0000000000412700 <__swc_fn_e121059d_000158_86f1d437>:
  412700:	vxorps xmm0,xmm0,xmm0
  412704:	vmovups XMMWORD PTR [rcx],xmm0
  412708:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41270d:	vxorps xmm0,xmm0,xmm0
  412711:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  412716:	vmovups xmm0,XMMWORD PTR [rip+0x117a]        # 413898 <__swc_rdata_base_e121059d+0x788>
  41271e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  412723:	mov    QWORD PTR [rcx+0x40],0x0
  41272b:	ret
  41272c:	add    BYTE PTR [rax],al
	...

0000000000412730 <__swc_fn_e121059d_000161_47b270e1>:
  412730:	push   rbx
  412731:	sub    rsp,0x70
  412735:	mov    rax,QWORD PTR [rcx]
  412738:	mov    rbx,QWORD PTR [rcx+0x8]
  41273c:	vxorps xmm0,xmm0,xmm0
  412740:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  412746:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  41274c:	vzeroupper
  41274f:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  412755:	mov    QWORD PTR [rsp+0x48],rdx
  41275a:	mov    QWORD PTR [rsp+0x50],r8
  41275f:	mov    rcx,rax
  412762:	lea    rdx,[rsp+0x8]
  412767:	mov    rbx,QWORD PTR [rbx+0x18]
  41276b:	call   rbx
  41276d:	add    rsp,0x70
  412771:	pop    rbx
  412772:	ret
	...

0000000000412780 <__swc_fn_e121059d_000164_8a3d304f>:
  412780:	push   rbx
  412781:	push   rsi
  412782:	push   rdi
  412783:	mov    rbx,r8
  412786:	mov    rsi,rcx
  412789:	mov    rdi,rdx
  41278c:	call   40add0 <__swc_fn_e121059d_000162_13ead2ff>
  412791:	vmovups xmm0,XMMWORD PTR [rbx]
  412795:	vmovups XMMWORD PTR [rsi],xmm0
  412799:	mov    QWORD PTR [rsi+0x18],rdi
  41279d:	pop    rdi
  41279e:	pop    rsi
  41279f:	pop    rbx
  4127a0:	ret
	...

00000000004127b0 <__swc_fn_e121059d_000167_cc119975>:
  4127b0:	push   rbx
  4127b1:	push   rsi
  4127b2:	push   rdi
  4127b3:	push   r12
  4127b5:	push   r13
  4127b7:	sub    rsp,0x50
  4127bb:	mov    rbx,rcx
  4127be:	mov    rsi,rdx
  4127c1:	vmovups xmm0,XMMWORD PTR [rip+0x11df]        # 4139a8 <__swc_rdata_base_e121059d+0x898>
  4127c9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4127cf:	vmovups xmm0,XMMWORD PTR [rip+0x11e1]        # 4139b8 <__swc_rdata_base_e121059d+0x8a8>
  4127d7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4127dd:	vxorps xmm0,xmm0,xmm0
  4127e1:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  4127e7:	mov    rcx,rdx
  4127ea:	call   412150 <__swc_fn_e121059d_000143_be4c2719>
  4127ef:	mov    rdi,rax
  4127f2:	test   rax,rax
  4127f5:	jne    412826 <__swc_fn_e121059d_000167_cc119975+0x76>
  4127f7:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4127fd:	vmovups XMMWORD PTR [rbx],xmm0
  412801:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  412807:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  41280c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  412812:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  412817:	mov    rax,rbx
  41281a:	add    rsp,0x50
  41281e:	pop    r13
  412820:	pop    r12
  412822:	pop    rdi
  412823:	pop    rsi
  412824:	pop    rbx
  412825:	ret
  412826:	mov    rcx,rdi
  412829:	call   40f3e0 <__swc_fn_e121059d_000166_016ee66a>
  41282e:	mov    r11,rax
  412831:	test   rax,rax
  412834:	je     41283e <__swc_fn_e121059d_000167_cc119975+0x8e>
  412836:	mov    al,BYTE PTR [r11+0x24]
  41283a:	test   al,al
  41283c:	jne    41286d <__swc_fn_e121059d_000167_cc119975+0xbd>
  41283e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  412844:	vmovups XMMWORD PTR [rbx],xmm0
  412848:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  41284e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  412853:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  412859:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  41285e:	mov    rax,rbx
  412861:	add    rsp,0x50
  412865:	pop    r13
  412867:	pop    r12
  412869:	pop    rdi
  41286a:	pop    rsi
  41286b:	pop    rbx
  41286c:	ret
  41286d:	sub    rsi,rdi
  412870:	mov    eax,0xffffffff
  412875:	cmp    rsi,rax
  412878:	jbe    4128a9 <__swc_fn_e121059d_000167_cc119975+0xf9>
  41287a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  412880:	vmovups XMMWORD PTR [rbx],xmm0
  412884:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  41288a:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  41288f:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  412895:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  41289a:	mov    rax,rbx
  41289d:	add    rsp,0x50
  4128a1:	pop    r13
  4128a3:	pop    r12
  4128a5:	pop    rdi
  4128a6:	pop    rsi
  4128a7:	pop    rbx
  4128a8:	ret
  4128a9:	mov    rdi,QWORD PTR [r11+0x10]
  4128ad:	mov    eax,DWORD PTR [r11+0x20]
  4128b1:	xor    ecx,ecx
  4128b3:	test   rax,rax
  4128b6:	jbe    412a08 <__swc_fn_e121059d_000167_cc119975+0x258>
  4128bc:	nop    DWORD PTR [rax+0x0]
  4128c0:	mov    edx,ecx
  4128c2:	imul   r12,rdx,0x14
  4128c6:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  4128cb:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  4128d0:	mov    r9d,esi
  4128d3:	cmp    r9,rdx
  4128d6:	jb     4129fb <__swc_fn_e121059d_000167_cc119975+0x24b>
  4128dc:	add    rdx,r8
  4128df:	mov    r8d,esi
  4128e2:	cmp    r8,rdx
  4128e5:	jae    4129fb <__swc_fn_e121059d_000167_cc119975+0x24b>
  4128eb:	lea    rsi,[rsp+0x38]
  4128f0:	mov    eax,DWORD PTR [rdi+0xc]
  4128f3:	mov    DWORD PTR [rsp+0x38],eax
  4128f7:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  4128fc:	mov    rcx,rdi
  4128ff:	mov    rdx,QWORD PTR [r11+0x18]
  412903:	mov    r8,rsi
  412906:	mov    r8d,DWORD PTR [r8]
  412909:	mov    r9,rax
  41290c:	lea    r10,[rsp+0x10]
  412911:	call   40ae20 <__swc_fn_e121059d_000165_72795826>
  412916:	test   al,al
  412918:	jne    41294b <__swc_fn_e121059d_000167_cc119975+0x19b>
  41291a:	vmovups xmm0,XMMWORD PTR [rip+0x10b6]        # 4139d8 <__swc_rdata_base_e121059d+0x8c8>
  412922:	vmovups XMMWORD PTR [rbx],xmm0
  412926:	vmovups xmm0,XMMWORD PTR [rip+0x10ba]        # 4139e8 <__swc_rdata_base_e121059d+0x8d8>
  41292e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  412933:	vxorps xmm0,xmm0,xmm0
  412937:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  41293c:	mov    rax,rbx
  41293f:	add    rsp,0x50
  412943:	pop    r13
  412945:	pop    r12
  412947:	pop    rdi
  412948:	pop    rsi
  412949:	pop    rbx
  41294a:	ret
  41294b:	lea    r13,[rsp+0x3c]
  412950:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  412955:	mov    DWORD PTR [rsp+0x3c],eax
  412959:	test   eax,eax
  41295b:	je     4129ac <__swc_fn_e121059d_000167_cc119975+0x1fc>
  41295d:	mov    rcx,rdi
  412960:	mov    rdx,QWORD PTR [r11+0x18]
  412964:	mov    r8d,DWORD PTR [rsi]
  412967:	mov    rax,r13
  41296a:	mov    r9d,DWORD PTR [rax]
  41296d:	lea    r10,[rsp+0x20]
  412972:	call   40ae20 <__swc_fn_e121059d_000165_72795826>
  412977:	test   al,al
  412979:	jne    4129ac <__swc_fn_e121059d_000167_cc119975+0x1fc>
  41297b:	vmovups xmm0,XMMWORD PTR [rip+0x1085]        # 413a08 <__swc_rdata_base_e121059d+0x8f8>
  412983:	vmovups XMMWORD PTR [rbx],xmm0
  412987:	vmovups xmm0,XMMWORD PTR [rip+0x1089]        # 413a18 <__swc_rdata_base_e121059d+0x908>
  41298f:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  412994:	vxorps xmm0,xmm0,xmm0
  412998:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  41299d:	mov    rax,rbx
  4129a0:	add    rsp,0x50
  4129a4:	pop    r13
  4129a6:	pop    r12
  4129a8:	pop    rdi
  4129a9:	pop    rsi
  4129aa:	pop    rbx
  4129ab:	ret
  4129ac:	mov    eax,0x1
  4129b1:	rex mov BYTE PTR [rsp+0x8],al
  4129b6:	cmp    DWORD PTR [r13+0x0],0x0
  4129bb:	je     4129cc <__swc_fn_e121059d_000167_cc119975+0x21c>
  4129bd:	rex mov BYTE PTR [rsp+0x9],0x1
  4129c3:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  4129c8:	mov    DWORD PTR [rsp+0x30],eax
  4129cc:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  4129d2:	vmovups XMMWORD PTR [rbx],xmm0
  4129d6:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  4129dc:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  4129e1:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  4129e7:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  4129ec:	mov    rax,rbx
  4129ef:	add    rsp,0x50
  4129f3:	pop    r13
  4129f5:	pop    r12
  4129f7:	pop    rdi
  4129f8:	pop    rsi
  4129f9:	pop    rbx
  4129fa:	ret
  4129fb:	add    rcx,0x1
  4129ff:	cmp    rcx,rax
  412a02:	jb     4128c0 <__swc_fn_e121059d_000167_cc119975+0x110>
  412a08:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  412a0e:	vmovups XMMWORD PTR [rbx],xmm0
  412a12:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  412a18:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  412a1d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  412a23:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  412a28:	mov    rax,rbx
  412a2b:	add    rsp,0x50
  412a2f:	pop    r13
  412a31:	pop    r12
  412a33:	pop    rdi
  412a34:	pop    rsi
  412a35:	pop    rbx
  412a36:	ret
	...

0000000000412a40 <__swc_fn_e121059d_000170_994c8876>:
  412a40:	sub    rsp,0x48
  412a44:	call   411e20 <__swc_fn_e121059d_000128_58f0f391>
  412a49:	cmp    rax,0xffffffffffffffff
  412a4d:	je     412a54 <__swc_fn_e121059d_000170_994c8876+0x14>
  412a4f:	add    rsp,0x48
  412a53:	ret
  412a54:	lea    rcx,[rip+0xfed]        # 413a48 <__swc_rdata_base_e121059d+0x938>
  412a5b:	vmovups xmm0,XMMWORD PTR [rip+0xff5]        # 413a58 <__swc_rdata_base_e121059d+0x948>
  412a63:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  412a69:	vmovups xmm0,XMMWORD PTR [rip+0xff7]        # 413a68 <__swc_rdata_base_e121059d+0x958>
  412a71:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  412a77:	vmovups xmm0,XMMWORD PTR [rip+0xff9]        # 413a78 <__swc_rdata_base_e121059d+0x968>
  412a7f:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  412a85:	lea    rdx,[rsp+0x8]
  412a8a:	mov    QWORD PTR [rsp+0x38],rax
  412a8f:	call   4118c0 <__swc_fn_e121059d_000107_90faaa26>
  412a94:	mov    rax,QWORD PTR [rsp+0x38]
  412a99:	jmp    412a4f <__swc_fn_e121059d_000170_994c8876+0xf>
  412a9b:	add    BYTE PTR [rax],al
  412a9d:	add    BYTE PTR [rax],al
	...

0000000000412aa0 <__swc_fn_e121059d_000173_cbeff767>:
  412aa0:	push   rbx
  412aa1:	push   rsi
  412aa2:	sub    rsp,0x28
  412aa6:	mov    rbx,rcx
  412aa9:	mov    DWORD PTR [rsp+0x8],0xbf0
  412ab1:	mov    ecx,0xbf0
  412ab6:	call   4114b0 <__swc_fn_e121059d_000083_4a10c7e7>
  412abb:	mov    rsi,rax
  412abe:	test   rax,rax
  412ac1:	jne    412acc <__swc_fn_e121059d_000173_cbeff767+0x2c>
  412ac3:	xor    eax,eax
  412ac5:	add    rsp,0x28
  412ac9:	pop    rsi
  412aca:	pop    rbx
  412acb:	ret
  412acc:	vxorps xmm0,xmm0,xmm0
  412ad0:	xor    eax,eax
  412ad2:	cs nop WORD PTR [rax+rax*1+0x0]
  412adc:	nop    DWORD PTR [rax+0x0]
  412ae0:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  412ae5:	add    rax,0x10
  412ae9:	cmp    rax,0xbf0
  412af0:	jne    412ae0 <__swc_fn_e121059d_000173_cbeff767+0x40>
  412af2:	lea    rax,[rbx+0x1]
  412af6:	mov    QWORD PTR [rsi+0x9c0],rax
  412afd:	mov    rcx,rbx
  412b00:	mov    rdx,rsi
  412b03:	call   40b180 <__swc_fn_e121059d_000171_646fdf20>
  412b08:	test   al,al
  412b0a:	jne    412b1d <__swc_fn_e121059d_000173_cbeff767+0x7d>
  412b0c:	mov    rcx,rsi
  412b0f:	call   409710 <__swc_fn_e121059d_000084_cf82995a>
  412b14:	xor    eax,eax
  412b16:	add    rsp,0x28
  412b1a:	pop    rsi
  412b1b:	pop    rbx
  412b1c:	ret
  412b1d:	lea    rcx,[rsp+0x18]
  412b22:	call   409c90 <__swc_fn_e121059d_000096_93bfe675>
  412b27:	mov    rax,rsi
  412b2a:	add    rsp,0x28
  412b2e:	pop    rsi
  412b2f:	pop    rbx
  412b30:	ret
	...

0000000000412b40 <__swc_fn_e121059d_000176_e09f8b62>:
  412b40:	xor    eax,eax
  412b42:	mov    edx,0x1
  412b47:	lock cmpxchg QWORD PTR [rcx],rdx
  412b4c:	test   rax,rax
  412b4f:	jne    412b52 <__swc_fn_e121059d_000176_e09f8b62+0x12>
  412b51:	ret
  412b52:	cs nop WORD PTR [rax+rax*1+0x0]
  412b5c:	nop    DWORD PTR [rax+0x0]
  412b60:	mov    rax,QWORD PTR [rcx]
  412b63:	test   rax,rax
  412b66:	je     412b40 <__swc_fn_e121059d_000176_e09f8b62>
  412b68:	jmp    412b60 <__swc_fn_e121059d_000176_e09f8b62+0x20>
  412b6a:	add    BYTE PTR [rax],al
  412b6c:	add    BYTE PTR [rax],al
	...

0000000000412b70 <__swc_fn_e121059d_000179_718d7b54>:
  412b70:	push   rsi
  412b71:	push   rdi
  412b72:	sub    rsp,0x38
  412b76:	mov    rsi,rcx
  412b79:	call   40b190 <__swc_fn_e121059d_000174_1e0ea8cf>
  412b7e:	mov    rdi,rax
  412b81:	call   40a920 <__swc_fn_e121059d_000135_a9c1c700>
  412b86:	mov    r8,rax
  412b89:	mov    rcx,rdi
  412b8c:	call   412b40 <__swc_fn_e121059d_000176_e09f8b62>
  412b91:	mov    rax,QWORD PTR [rdi+0x8]
  412b95:	test   rax,rax
  412b98:	je     412bd5 <__swc_fn_e121059d_000179_718d7b54+0x65>
  412b9a:	nop    WORD PTR [rax+rax*1+0x0]
  412ba0:	cmp    rax,rsi
  412ba3:	je     412bd5 <__swc_fn_e121059d_000179_718d7b54+0x65>
  412ba5:	mov    r9,QWORD PTR [rax]
  412ba8:	cmp    QWORD PTR [rax+0x20],r8
  412bac:	jne    412bcd <__swc_fn_e121059d_000179_718d7b54+0x5d>
  412bae:	mov    rcx,rdi
  412bb1:	mov    rdx,rax
  412bb4:	mov    QWORD PTR [rsp+0x28],r8
  412bb9:	mov    QWORD PTR [rsp+0x30],r9
  412bbe:	call   40f800 <__swc_fn_e121059d_000178_cf4ffedd>
  412bc3:	mov    r8,QWORD PTR [rsp+0x28]
  412bc8:	mov    r9,QWORD PTR [rsp+0x30]
  412bcd:	mov    rax,r9
  412bd0:	test   r9,r9
  412bd3:	jne    412ba0 <__swc_fn_e121059d_000179_718d7b54+0x30>
  412bd5:	xor    eax,eax
  412bd7:	mov    QWORD PTR [rdi],rax
  412bda:	add    rsp,0x38
  412bde:	pop    rdi
  412bdf:	pop    rsi
  412be0:	ret
