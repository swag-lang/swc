
/workspace/prompt2-20261115/batch5-final-micro/new/chacha/chacha:     file format elf64-x86-64


Disassembly of section .text:

000000000040ab00 <__swc_fn_3464c816_000001_2744b483>:
  40ab00:	push   rbx
  40ab01:	sub    rsp,0x70
  40ab05:	cmp    rcx,0xffffffffffffffef
  40ab09:	jbe    40ab13 <__swc_fn_3464c816_000001_2744b483+0x13>
  40ab0b:	xor    eax,eax
  40ab0d:	add    rsp,0x70
  40ab11:	pop    rbx
  40ab12:	ret
  40ab13:	vxorps xmm0,xmm0,xmm0
  40ab17:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40ab1d:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40ab23:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  40ab29:	vzeroupper
  40ab2c:	lea    rax,[rcx+0x10]
  40ab30:	mov    QWORD PTR [rsp+0x50],rax
  40ab35:	mov    DWORD PTR [rsp+0x60],0x10
  40ab3d:	mov    rcx,QWORD PTR [rip+0x194fc]        # 424040 <__swc_bss_base_3464c816>
  40ab44:	test   rcx,rcx
  40ab47:	jne    40ab59 <__swc_fn_3464c816_000001_2744b483+0x59>
  40ab49:	call   40a940 <__swc_fn_3464c816_000168_994c8876>
  40ab4e:	lea    rcx,[rax+0x1]
  40ab52:	mov    QWORD PTR [rip+0x194e7],rcx        # 424040 <__swc_bss_base_3464c816>
  40ab59:	dec    rcx
  40ab5c:	call   411ec0 <__swc_fn_3464c816_000170_360af05d>
  40ab61:	mov    rcx,QWORD PTR [rax]
  40ab64:	lea    rdx,[rsp+0x8]
  40ab69:	mov    rbx,QWORD PTR [rax+0x8]
  40ab6d:	mov    rbx,QWORD PTR [rbx+0x8]
  40ab71:	call   rbx
  40ab73:	mov    rax,QWORD PTR [rsp+0x48]
  40ab78:	test   rax,rax
  40ab7b:	jne    40ab85 <__swc_fn_3464c816_000001_2744b483+0x85>
  40ab7d:	xor    eax,eax
  40ab7f:	add    rsp,0x70
  40ab83:	pop    rbx
  40ab84:	ret
  40ab85:	mov    rcx,QWORD PTR [rsp+0x50]
  40ab8a:	mov    QWORD PTR [rax],rcx
  40ab8d:	mov    QWORD PTR [rax+0x8],0x0
  40ab95:	lea    rax,[rax+0x10]
  40ab99:	add    rsp,0x70
  40ab9d:	pop    rbx
  40ab9e:	ret
