
/workspace/prompt2-20261115/batch7-placement-micro/new/sha256/sha256:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <open@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <open@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <flock@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <flock@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <__errno_location@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <__errno_location@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <close@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <close@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <getpid@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <getpid@GLIBC_2.2.5>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <opendir@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <opendir@GLIBC_2.2.5>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <dirfd@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <dirfd@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <readdir@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <readdir@GLIBC_2.2.5>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <readlinkat@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <readlinkat@GLIBC_2.4>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <openat@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <openat@GLIBC_2.4>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <closedir@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <closedir@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <lseek@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <lseek@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <mmap@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <mmap@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <memfd_create@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf92]        # 413078 <memfd_create@GLIBC_2.27>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <ftruncate@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf8a]        # 413080 <ftruncate@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <write@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf82]        # 413088 <write@GLIBC_2.2.5>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <backtrace@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf7a]        # 413090 <backtrace@GLIBC_2.2.5>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <pthread_setspecific@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf72]        # 413098 <pthread_setspecific@GLIBC_2.34>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <clock_gettime@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf6a]        # 4130a0 <clock_gettime@GLIBC_2.17>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <__x86_get_cpuid_feature_leaf@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf62]        # 4130a8 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <free@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf5a]        # 4130b0 <free@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <munmap@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf52]        # 4130b8 <munmap@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <mprotect@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf4a]        # 4130c0 <mprotect@GLIBC_2.2.5>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <exit@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf42]        # 4130c8 <exit@GLIBC_2.2.5>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <pthread_key_create@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf3a]        # 4130d0 <pthread_key_create@GLIBC_2.34>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <syscall@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf32]        # 4130d8 <syscall@GLIBC_2.2.5>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <dladdr@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130e0 <dladdr@GLIBC_2.34>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <malloc@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf22]        # 4130e8 <malloc@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <madvise@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <madvise@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <pthread_key_delete@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <pthread_key_delete@GLIBC_2.34>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <gettid@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <gettid@GLIBC_2.30>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_65555ab2_000176_4de704de+0x10a0>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   411460 <__swc_fn_65555ab2_000125_540bf7e8>
  40724e:	xor    ecx,ecx
  407250:	call   410b80 <__swc_fn_65555ab2_000098_4f209617>
  407255:	call   407320 <__swc_fn_65555ab2_000003_72e41d4d>
  40725a:	call   409230 <__swc_fn_65555ab2_000099_65137b72>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_65555ab2_000000_2744b483>:
  407270:	push   rbx
  407271:	sub    rsp,0x70
  407275:	cmp    rcx,0xffffffffffffffef
  407279:	jbe    407283 <__swc_fn_65555ab2_000000_2744b483+0x13>
  40727b:	xor    eax,eax
  40727d:	add    rsp,0x70
  407281:	pop    rbx
  407282:	ret
  407283:	vxorps xmm0,xmm0,xmm0
  407287:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40728d:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  407293:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  407299:	vzeroupper
  40729c:	lea    rax,[rcx+0x10]
  4072a0:	mov    QWORD PTR [rsp+0x50],rax
  4072a5:	mov    DWORD PTR [rsp+0x60],0x10
  4072ad:	mov    rcx,QWORD PTR [rip+0x1cd8c]        # 424040 <__swc_bss_base_65555ab2>
  4072b4:	test   rcx,rcx
  4072b7:	jne    4072c9 <__swc_fn_65555ab2_000000_2744b483+0x59>
  4072b9:	call   40eb80 <__swc_fn_65555ab2_000169_994c8876>
  4072be:	lea    rcx,[rax+0x1]
  4072c2:	mov    QWORD PTR [rip+0x1cd77],rcx        # 424040 <__swc_bss_base_65555ab2>
  4072c9:	dec    rcx
  4072cc:	call   40ba40 <__swc_fn_65555ab2_000171_360af05d>
  4072d1:	mov    rcx,QWORD PTR [rax]
  4072d4:	lea    rdx,[rsp+0x8]
  4072d9:	mov    rbx,QWORD PTR [rax+0x8]
  4072dd:	mov    rbx,QWORD PTR [rbx+0x8]
  4072e1:	call   rbx
  4072e3:	mov    rax,QWORD PTR [rsp+0x48]
  4072e8:	test   rax,rax
  4072eb:	jne    4072f5 <__swc_fn_65555ab2_000000_2744b483+0x85>
  4072ed:	xor    eax,eax
  4072ef:	add    rsp,0x70
  4072f3:	pop    rbx
  4072f4:	ret
  4072f5:	mov    rcx,QWORD PTR [rsp+0x50]
  4072fa:	mov    QWORD PTR [rax],rcx
  4072fd:	mov    QWORD PTR [rax+0x8],0x0
  407305:	lea    rax,[rax+0x10]
  407309:	add    rsp,0x70
  40730d:	pop    rbx
  40730e:	ret
	...

0000000000407320 <__swc_fn_65555ab2_000003_72e41d4d>:
  407320:	push   rbp
  407321:	push   rbx
  407322:	push   rsi
  407323:	push   rdi
  407324:	push   r12
  407326:	push   r13
  407328:	push   r14
  40732a:	push   r15
  40732c:	sub    rsp,0x10
  407330:	mov    rbp,rsp
  407333:	vmovups XMMWORD PTR [rsp],xmm6
  407338:	sub    rsp,0x430
  40733f:	mov    rbx,rsp
  407342:	mov    ecx,0x800000
  407347:	sub    rsp,0x8
  40734b:	call   407270 <__swc_fn_65555ab2_000000_2744b483>
  407350:	add    rsp,0x8
  407354:	mov    rsi,rax
  407357:	mov    QWORD PTR [rsp+0x3c0],rax
  40735f:	xor    ecx,ecx
  407361:	cs nop WORD PTR [rax+rax*1+0x0]
  40736b:	nop    DWORD PTR [rax+rax*1+0x0]
  407370:	mov    r8,QWORD PTR [rip+0x1ac89]        # 422000 <__swc_data_base_65555ab2>
  407377:	imul   r8,r8,0x41a7
  40737e:	movabs rdx,0x200000005
  407388:	mov    r11,rax
  40738b:	mov    rax,r8
  40738e:	mul    rdx
  407391:	mov    r9,rdx
  407394:	mov    rdx,r8
  407397:	sub    rdx,r9
  40739a:	shr    rdx,1
  40739d:	add    rdx,r9
  4073a0:	shr    rdx,0x1e
  4073a4:	imul   r9,rdx,0x7fffffff
  4073ab:	sub    r8,r9
  4073ae:	mov    QWORD PTR [rip+0x1ac4b],r8        # 422000 <__swc_data_base_65555ab2>
  4073b5:	mov    BYTE PTR [rsi+rcx*1],r8b
  4073b9:	add    rcx,0x1
  4073bd:	mov    r8,QWORD PTR [rip+0x1ac3c]        # 422000 <__swc_data_base_65555ab2>
  4073c4:	imul   r8,r8,0x41a7
  4073cb:	movabs rdx,0x200000005
  4073d5:	mov    rax,r8
  4073d8:	mul    rdx
  4073db:	mov    r9,rdx
  4073de:	mov    rax,r11
  4073e1:	mov    rdx,r8
  4073e4:	sub    rdx,r9
  4073e7:	shr    rdx,1
  4073ea:	add    rdx,r9
  4073ed:	shr    rdx,0x1e
  4073f1:	imul   rdx,rdx,0x7fffffff
  4073f8:	sub    r8,rdx
  4073fb:	mov    QWORD PTR [rip+0x1abfe],r8        # 422000 <__swc_data_base_65555ab2>
  407402:	mov    BYTE PTR [rsi+rcx*1],r8b
  407406:	add    rcx,0x1
  40740a:	cmp    rcx,0x800000
  407411:	jb     407370 <__swc_fn_65555ab2_000003_72e41d4d+0x50>
  407417:	sub    rsp,0x8
  40741b:	call   40ed40 <__swc_fn_65555ab2_000002_1ca87929>
  407420:	add    rsp,0x8
  407424:	vmovups xmm6,xmm0
  407428:	mov    ecx,0x800080
  40742d:	sub    rsp,0x8
  407431:	call   407270 <__swc_fn_65555ab2_000000_2744b483>
  407436:	add    rsp,0x8
  40743a:	mov    rdi,rax
  40743d:	mov    QWORD PTR [rsp+0x3c8],rax
  407445:	xor    eax,eax
  407447:	cs nop WORD PTR [rax+rax*1+0x0]
  407451:	cs nop WORD PTR [rax+rax*1+0x0]
  40745b:	nop    DWORD PTR [rax+rax*1+0x0]
  407460:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*1]
  407465:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40746a:	add    rax,0x10
  40746e:	cmp    rax,0x800000
  407475:	jne    407460 <__swc_fn_65555ab2_000003_72e41d4d+0x140>
  407477:	rex mov BYTE PTR [rdi+0x800000],0x80
  40747f:	mov    eax,0x800001
  407484:	cs nop WORD PTR [rax+rax*1+0x0]
  40748e:	xchg   ax,ax
  407490:	mov    ecx,eax
  407492:	and    ecx,0x3f
  407495:	cmp    rcx,0x38
  407499:	je     4074a4 <__swc_fn_65555ab2_000003_72e41d4d+0x184>
  40749b:	mov    BYTE PTR [rdi+rax*1],0x0
  40749f:	inc    rax
  4074a2:	jmp    407490 <__swc_fn_65555ab2_000003_72e41d4d+0x170>
  4074a4:	mov    BYTE PTR [rdi+rax*1],0x0
  4074a8:	mov    BYTE PTR [rdi+rax*1+0x1],0x0
  4074ad:	mov    BYTE PTR [rdi+rax*1+0x2],0x0
  4074b2:	mov    BYTE PTR [rdi+rax*1+0x3],0x0
  4074b7:	mov    BYTE PTR [rdi+rax*1+0x4],0x4
  4074bc:	mov    BYTE PTR [rdi+rax*1+0x5],0x0
  4074c1:	mov    BYTE PTR [rdi+rax*1+0x6],0x0
  4074c6:	mov    BYTE PTR [rdi+rax*1+0x7],0x0
  4074cb:	lea    rax,[rax+0x8]
  4074cf:	mov    ecx,0x6a09e667
  4074d4:	mov    edx,0xbb67ae85
  4074d9:	mov    r8d,0x3c6ef372
  4074df:	mov    r9d,0xa54ff53a
  4074e5:	mov    r10d,0x510e527f
  4074eb:	mov    r11d,0x9b05688c
  4074f1:	mov    r12d,0x1f83d9ab
  4074f7:	mov    r13d,0x5be0cd19
  4074fd:	mov    QWORD PTR [rsp+0x408],r13
  407505:	lea    r14,[rbx+0x90]
  40750c:	vxorps xmm0,xmm0,xmm0
  407510:	xor    r15d,r15d
  407513:	cs nop WORD PTR [rax+rax*1+0x0]
  40751d:	nop    DWORD PTR [rax]
  407520:	vmovdqu XMMWORD PTR [r14+r15*1],xmm0
  407526:	add    r15,0x10
  40752a:	cmp    r15,0x200
  407531:	jne    407520 <__swc_fn_65555ab2_000003_72e41d4d+0x200>
  407533:	shr    rax,0x6
  407537:	mov    QWORD PTR [rsp+0x410],rax
  40753f:	xor    r15d,r15d
  407542:	test   rax,rax
  407545:	ja     407563 <__swc_fn_65555ab2_000003_72e41d4d+0x243>
  407547:	mov    rax,rcx
  40754a:	mov    rcx,rdx
  40754d:	mov    rsi,r10
  407550:	mov    rdi,r11
  407553:	mov    rdx,QWORD PTR [rsp+0x408]
  40755b:	mov    r10,r9
  40755e:	jmp    4078bc <__swc_fn_65555ab2_000003_72e41d4d+0x59c>
  407563:	vmovsd xmm2,QWORD PTR [rsp+0x408]
  40756c:	nop    DWORD PTR [rax+0x0]
  407570:	mov    rsi,r15
  407573:	shl    rsi,0x6
  407577:	mov    eax,DWORD PTR [rdi+rsi*1]
  40757a:	bswap  eax
  40757c:	mov    QWORD PTR [rbx+0x90],rax
  407583:	mov    eax,DWORD PTR [rdi+rsi*1+0x4]
  407587:	bswap  eax
  407589:	mov    QWORD PTR [rbx+0x98],rax
  407590:	mov    eax,DWORD PTR [rdi+rsi*1+0x8]
  407594:	bswap  eax
  407596:	mov    QWORD PTR [rbx+0xa0],rax
  40759d:	mov    eax,DWORD PTR [rdi+rsi*1+0xc]
  4075a1:	bswap  eax
  4075a3:	mov    QWORD PTR [rbx+0xa8],rax
  4075aa:	mov    eax,DWORD PTR [rdi+rsi*1+0x10]
  4075ae:	bswap  eax
  4075b0:	mov    QWORD PTR [rbx+0xb0],rax
  4075b7:	mov    eax,DWORD PTR [rdi+rsi*1+0x14]
  4075bb:	bswap  eax
  4075bd:	mov    QWORD PTR [rbx+0xb8],rax
  4075c4:	mov    eax,DWORD PTR [rdi+rsi*1+0x18]
  4075c8:	bswap  eax
  4075ca:	mov    QWORD PTR [rbx+0xc0],rax
  4075d1:	mov    eax,DWORD PTR [rdi+rsi*1+0x1c]
  4075d5:	bswap  eax
  4075d7:	mov    QWORD PTR [rbx+0xc8],rax
  4075de:	mov    eax,DWORD PTR [rdi+rsi*1+0x20]
  4075e2:	bswap  eax
  4075e4:	mov    QWORD PTR [rbx+0xd0],rax
  4075eb:	mov    eax,DWORD PTR [rdi+rsi*1+0x24]
  4075ef:	bswap  eax
  4075f1:	mov    QWORD PTR [rbx+0xd8],rax
  4075f8:	mov    eax,DWORD PTR [rdi+rsi*1+0x28]
  4075fc:	bswap  eax
  4075fe:	mov    QWORD PTR [rbx+0xe0],rax
  407605:	mov    eax,DWORD PTR [rdi+rsi*1+0x2c]
  407609:	bswap  eax
  40760b:	mov    QWORD PTR [rbx+0xe8],rax
  407612:	mov    eax,DWORD PTR [rdi+rsi*1+0x30]
  407616:	bswap  eax
  407618:	mov    QWORD PTR [rbx+0xf0],rax
  40761f:	mov    eax,DWORD PTR [rdi+rsi*1+0x34]
  407623:	bswap  eax
  407625:	mov    QWORD PTR [rbx+0xf8],rax
  40762c:	mov    eax,DWORD PTR [rdi+rsi*1+0x38]
  407630:	bswap  eax
  407632:	mov    QWORD PTR [rbx+0x100],rax
  407639:	vmovq  xmm3,r15
  40763e:	mov    eax,DWORD PTR [rdi+rsi*1+0x3c]
  407642:	bswap  eax
  407644:	mov    QWORD PTR [rbx+0x108],rax
  40764b:	mov    eax,0x10
  407650:	cmp    rax,0x40
  407654:	jae    4076b3 <__swc_fn_65555ab2_000003_72e41d4d+0x393>
  407656:	cs nop WORD PTR [rax+rax*1+0x0]
  407660:	mov    rsi,QWORD PTR [r14+rax*8-0x78]
  407665:	mov    r15,QWORD PTR [r14+rax*8-0x10]
  40766a:	rorx   edi,esi,0x7
  407670:	rorx   r13d,esi,0x12
  407676:	xor    rdi,r13
  407679:	shr    rsi,0x3
  40767d:	xor    rdi,rsi
  407680:	rorx   esi,r15d,0x11
  407686:	rorx   r13d,r15d,0x13
  40768c:	xor    rsi,r13
  40768f:	shr    r15,0xa
  407693:	xor    rsi,r15
  407696:	mov    r13,QWORD PTR [r14+rax*8-0x80]
  40769b:	add    r13,rdi
  40769e:	add    r13,QWORD PTR [r14+rax*8-0x38]
  4076a3:	add    r13d,esi
  4076a6:	mov    QWORD PTR [r14+rax*8],r13
  4076aa:	inc    rax
  4076ad:	cmp    rax,0x40
  4076b1:	jb     407660 <__swc_fn_65555ab2_000003_72e41d4d+0x340>
  4076b3:	mov    rax,rcx
  4076b6:	mov    rsi,rdx
  4076b9:	mov    rdi,r8
  4076bc:	mov    r13,r9
  4076bf:	mov    r15,r10
  4076c2:	vmovq  xmm4,r10
  4076c7:	mov    r10,r11
  4076ca:	vmovq  xmm5,r11
  4076cf:	mov    r11,r12
  4076d2:	mov    QWORD PTR [rsp+0x3e8],r9
  4076da:	mov    QWORD PTR [rsp+0x400],r12
  4076e2:	vmovq  r9,xmm2
  4076e7:	xor    r12d,r12d
  4076ea:	mov    QWORD PTR [rsp+0x3e0],r8
  4076f2:	mov    QWORD PTR [rsp+0x3d0],rcx
  4076fa:	mov    QWORD PTR [rsp+0x3d8],rdx
  407702:	cs nop WORD PTR [rax+rax*1+0x0]
  40770c:	cs nop WORD PTR [rax+rax*1+0x0]
  407716:	cs nop WORD PTR [rax+rax*1+0x0]
  407720:	rorx   r8d,r15d,0x6
  407726:	rorx   edx,r15d,0xb
  40772c:	xor    r8,rdx
  40772f:	rorx   edx,r15d,0x19
  407735:	xor    r8,rdx
  407738:	mov    rdx,r15
  40773b:	and    rdx,r10
  40773e:	andn   ecx,r15d,r11d
  407743:	xor    rdx,rcx
  407746:	add    r9,r8
  407749:	add    r9,rdx
  40774c:	lea    rcx,[rip+0xb9cd]        # 413120 <__swc_rdata_base_65555ab2+0x10>
  407753:	add    r9,QWORD PTR [rcx+r12*8]
  407757:	add    r9d,DWORD PTR [r14+r12*8]
  40775b:	rorx   edx,eax,0x2
  407761:	rorx   r8d,eax,0xd
  407767:	xor    rdx,r8
  40776a:	rorx   r8d,eax,0x16
  407770:	xor    rdx,r8
  407773:	mov    r8,rsi
  407776:	xor    r8,rdi
  407779:	and    r8,rax
  40777c:	vmovq  xmm0,rax
  407781:	mov    rax,rsi
  407784:	and    rax,rdi
  407787:	xor    r8,rax
  40778a:	add    edx,r8d
  40778d:	lea    eax,[r13+r9*1+0x0]
  407792:	lea    r8d,[r9+rdx*1]
  407796:	add    r12,0x1
  40779a:	rorx   edx,eax,0x6
  4077a0:	rorx   r9d,eax,0xb
  4077a6:	xor    rdx,r9
  4077a9:	rorx   r9d,eax,0x19
  4077af:	xor    rdx,r9
  4077b2:	mov    r9,rax
  4077b5:	and    r9,r15
  4077b8:	andn   r13d,eax,r10d
  4077bd:	xor    r9,r13
  4077c0:	add    r11,rdx
  4077c3:	add    r11,r9
  4077c6:	add    r11,QWORD PTR [rcx+r12*8]
  4077ca:	mov    ecx,r11d
  4077cd:	add    ecx,DWORD PTR [r14+r12*8]
  4077d1:	rorx   edx,r8d,0x2
  4077d7:	rorx   r9d,r8d,0xd
  4077dd:	xor    rdx,r9
  4077e0:	rorx   r9d,r8d,0x16
  4077e6:	xor    rdx,r9
  4077e9:	vmovq  r13,xmm0
  4077ee:	mov    r9,r13
  4077f1:	xor    r9,rsi
  4077f4:	and    r9,r8
  4077f7:	mov    r11,r13
  4077fa:	and    r11,rsi
  4077fd:	xor    r9,r11
  407800:	add    edx,r9d
  407803:	mov    r9,r10
  407806:	mov    r11,r15
  407809:	mov    r10,rax
  40780c:	lea    r15d,[rdi+rcx*1]
  407810:	vmovq  xmm1,rax
  407815:	mov    rdi,r13
  407818:	mov    r13,rsi
  40781b:	mov    rsi,r8
  40781e:	add    ecx,edx
  407820:	mov    rdx,r15
  407823:	mov    rax,rcx
  407826:	add    r12,0x1
  40782a:	cmp    r12,0x40
  40782e:	jb     407720 <__swc_fn_65555ab2_000003_72e41d4d+0x400>
  407834:	mov    rax,QWORD PTR [rsp+0x3d0]
  40783c:	add    eax,ecx
  40783e:	mov    rcx,QWORD PTR [rsp+0x3d8]
  407846:	add    ecx,r8d
  407849:	mov    r8,QWORD PTR [rsp+0x3e0]
  407851:	add    r8d,edi
  407854:	mov    r10,QWORD PTR [rsp+0x3e8]
  40785c:	add    r10d,r13d
  40785f:	vmovq  rsi,xmm4
  407864:	add    esi,edx
  407866:	vmovq  rdi,xmm5
  40786b:	vmovq  rdx,xmm1
  407870:	add    edi,edx
  407872:	mov    r12,QWORD PTR [rsp+0x400]
  40787a:	add    r12d,r11d
  40787d:	vmovq  rdx,xmm2
  407882:	add    edx,r9d
  407885:	vmovq  r15,xmm3
  40788a:	vmovq  xmm2,rdx
  40788f:	add    r15,0x1
  407893:	mov    r9,QWORD PTR [rsp+0x410]
  40789b:	cmp    r15,r9
  40789e:	jae    4078bc <__swc_fn_65555ab2_000003_72e41d4d+0x59c>
  4078a0:	mov    rdx,rcx
  4078a3:	mov    r9,r10
  4078a6:	mov    r10,rsi
  4078a9:	mov    r11,rdi
  4078ac:	mov    rdi,QWORD PTR [rsp+0x3c8]
  4078b4:	mov    rcx,rax
  4078b7:	jmp    407570 <__swc_fn_65555ab2_000003_72e41d4d+0x250>
  4078bc:	xor    rax,rcx
  4078bf:	xor    rax,r8
  4078c2:	xor    rax,r10
  4078c5:	xor    rax,rsi
  4078c8:	xor    rax,rdi
  4078cb:	xor    rax,r12
  4078ce:	mov    rsi,rax
  4078d1:	xor    rsi,rdx
  4078d4:	sub    rsp,0x8
  4078d8:	call   40ed40 <__swc_fn_65555ab2_000002_1ca87929>
  4078dd:	add    rsp,0x8
  4078e1:	vsubsd xmm0,xmm0,xmm6
  4078e5:	vmulsd xmm0,xmm0,QWORD PTR [rip+0xbb3b]        # 413428 <__swc_rdata_base_65555ab2+0x318>
  4078ed:	lea    rax,[rip+0xba2c]        # 413320 <__swc_rdata_base_65555ab2+0x210>
  4078f4:	sub    rsp,0x90
  4078fb:	mov    rcx,rsp
  4078fe:	vmovups xmm1,XMMWORD PTR [rip+0xbb02]        # 413408 <__swc_rdata_base_65555ab2+0x2f8>
  407906:	vmovups XMMWORD PTR [rcx],xmm1
  40790a:	mov    QWORD PTR [rcx+0x30],rsp
  40790e:	lea    rdx,[rip+0xba1b]        # 413330 <__swc_rdata_base_65555ab2+0x220>
  407915:	mov    QWORD PTR [rcx+0x38],rdx
  407919:	mov    QWORD PTR [rcx+0x10],rsi
  40791d:	lea    r8,[rsp+0x10]
  407922:	mov    QWORD PTR [rcx+0x40],r8
  407926:	lea    r8,[rip+0xba4b]        # 413378 <__swc_rdata_base_65555ab2+0x268>
  40792d:	mov    QWORD PTR [rcx+0x48],r8
  407931:	vmovups xmm1,XMMWORD PTR [rip+0xbadf]        # 413418 <__swc_rdata_base_65555ab2+0x308>
  407939:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40793e:	lea    r8,[rsp+0x18]
  407943:	mov    QWORD PTR [rcx+0x50],r8
  407947:	mov    QWORD PTR [rcx+0x58],rdx
  40794b:	vmovsd QWORD PTR [rcx+0x28],xmm0
  407950:	lea    r8,[rcx+0x28]
  407954:	mov    QWORD PTR [rcx+0x60],r8
  407958:	lea    r8,[rip+0xba61]        # 4133c0 <__swc_rdata_base_65555ab2+0x2b0>
  40795f:	mov    QWORD PTR [rcx+0x68],r8
  407963:	mov    QWORD PTR [rcx+0x70],rax
  407967:	mov    QWORD PTR [rcx+0x78],rdx
  40796b:	lea    rax,[rcx+0x30]
  40796f:	mov    QWORD PTR [rcx+0x80],rax
  407976:	mov    QWORD PTR [rcx+0x88],0x5
  407981:	lea    rcx,[rcx+0x80]
  407988:	sub    rsp,0x8
  40798c:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  407991:	add    rsp,0x8
  407995:	add    rsp,0x90
  40799c:	mov    rdi,QWORD PTR [rsp+0x3c8]
  4079a4:	mov    rcx,rdi
  4079a7:	sub    rsp,0x8
  4079ab:	call   40bbe0 <__swc_fn_65555ab2_000001_5d3d19bd>
  4079b0:	add    rsp,0x8
  4079b4:	mov    rsi,QWORD PTR [rsp+0x3c0]
  4079bc:	mov    rcx,rsi
  4079bf:	sub    rsp,0x8
  4079c3:	call   40bbe0 <__swc_fn_65555ab2_000001_5d3d19bd>
  4079c8:	add    rsp,0x438
  4079cf:	vmovups xmm6,XMMWORD PTR [rsp]
  4079d4:	add    rsp,0x10
  4079d8:	pop    r15
  4079da:	pop    r14
  4079dc:	pop    r13
  4079de:	pop    r12
  4079e0:	pop    rdi
  4079e1:	pop    rsi
  4079e2:	pop    rbx
  4079e3:	pop    rbp
  4079e4:	ret
	...

00000000004079f0 <__swc_fn_65555ab2_000006_81d2e1e9>:
  4079f0:	sub    rsp,0x8
  4079f4:	call   411000 <__swc_fn_65555ab2_000113_6b799b8d>
  4079f9:	mov    rcx,rax
  4079fc:	test   rax,rax
  4079ff:	je     407a26 <__swc_fn_65555ab2_000006_81d2e1e9+0x36>
  407a01:	lea    rdx,[rip+0x1c640]        # 424048 <__swc_bss_base_65555ab2+0x8>
  407a08:	mov    r8,QWORD PTR [rip+0x1c639]        # 424048 <__swc_bss_base_65555ab2+0x8>
  407a0f:	nop
  407a10:	lea    r9,[r8+0x1]
  407a14:	mov    rax,r8
  407a17:	lock cmpxchg QWORD PTR [rdx],r9
  407a1c:	cmp    rax,r8
  407a1f:	je     407a26 <__swc_fn_65555ab2_000006_81d2e1e9+0x36>
  407a21:	mov    r8,rax
  407a24:	jmp    407a10 <__swc_fn_65555ab2_000006_81d2e1e9+0x20>
  407a26:	mov    rax,rcx
  407a29:	add    rsp,0x8
  407a2d:	ret
	...

0000000000407a30 <__swc_fn_65555ab2_000009_065ed5b1>:
  407a30:	mov    r8d,edx
  407a33:	xor    eax,eax
  407a35:	tzcnt  eax,edx
  407a39:	shrx   r9d,edx,eax
  407a3e:	mov    DWORD PTR [rcx+0x2c],edx
  407a41:	xor    eax,eax
  407a43:	tzcnt  eax,edx
  407a47:	mov    BYTE PTR [rcx+0x38],al
  407a4a:	mov    eax,0xffffffff
  407a4f:	xor    edx,edx
  407a51:	div    r8d
  407a54:	mov    DWORD PTR [rcx+0x34],eax
  407a57:	mov    eax,r9d
  407a5a:	mov    edx,r9d
  407a5d:	imul   edx,r9d
  407a61:	mov    r8d,0x2
  407a67:	sub    r8d,edx
  407a6a:	imul   eax,r8d
  407a6e:	mov    edx,r9d
  407a71:	imul   edx,eax
  407a74:	mov    r8d,0x2
  407a7a:	sub    r8d,edx
  407a7d:	imul   eax,r8d
  407a81:	mov    edx,r9d
  407a84:	imul   edx,eax
  407a87:	mov    r8d,0x2
  407a8d:	sub    r8d,edx
  407a90:	imul   eax,r8d
  407a94:	mov    edx,r9d
  407a97:	imul   edx,eax
  407a9a:	mov    r8d,0x2
  407aa0:	sub    r8d,edx
  407aa3:	imul   eax,r8d
  407aa7:	imul   r9d,eax
  407aab:	mov    edx,0x2
  407ab0:	sub    edx,r9d
  407ab3:	imul   eax,edx
  407ab6:	mov    DWORD PTR [rcx+0x30],eax
  407ab9:	ret
  407aba:	add    BYTE PTR [rax],al
  407abc:	add    BYTE PTR [rax],al
	...

0000000000407ac0 <__swc_fn_65555ab2_000012_861b8b62>:
  407ac0:	xor    eax,eax
  407ac2:	mov    DWORD PTR [rcx+0x68],eax
  407ac5:	ret
	...

0000000000407ad0 <__swc_fn_65555ab2_000015_9dea5065>:
  407ad0:	mov    eax,DWORD PTR [rcx+0x28]
  407ad3:	shlx   eax,edx,eax
  407ad8:	shl    rax,0x10
  407adc:	lea    rdx,[rcx+rax*1]
  407ae0:	lea    rax,[rcx+0x3000]
  407ae7:	cmp    rdx,rax
  407aea:	cmovae rax,rdx
  407aee:	ret
	...

0000000000407af0 <__swc_fn_65555ab2_000018_283e2b5e>:
  407af0:	push   rsi
  407af1:	push   rdi
  407af2:	push   r12
  407af4:	push   r13
  407af6:	push   r14
  407af8:	mov    rsi,rdx
  407afb:	mov    rdi,rcx
  407afe:	rex mov dl,BYTE PTR [rsi+0x3a]
  407b02:	mov    ecx,DWORD PTR [rdi+0x28]
  407b05:	shr    dl,cl
  407b07:	mov    r12d,0x1
  407b0d:	mov    ecx,edx
  407b0f:	shl    r12,cl
  407b12:	mov    r13d,DWORD PTR [rsi+0x3c]
  407b16:	rex mov BYTE PTR [rsi+0x3b],0x0
  407b1b:	mov    QWORD PTR [rsi+0x40],0x0
  407b23:	mov    QWORD PTR [rsi],0x0
  407b2a:	mov    rax,QWORD PTR [rsi+0x10]
  407b2e:	mov    QWORD PTR [rsi+0x20],rax
  407b32:	lea    r14,[rip+0x1c517]        # 424050 <__swc_bss_base_65555ab2+0x10>
  407b39:	mov    rax,QWORD PTR [r14]
  407b3c:	shr    rax,0x2
  407b40:	mov    rcx,rax
  407b43:	cmp    rax,0x800000
  407b4a:	mov    eax,0x800000
  407b4f:	cmovb  rcx,rax
  407b53:	lea    r8,[rip+0x1c506]        # 424060 <__swc_bss_base_65555ab2+0x20>
  407b5a:	mov    rax,QWORD PTR [r8]
  407b5d:	mov    r9,rax
  407b60:	lea    r10,[r9+r13*1]
  407b64:	cmp    r10,rcx
  407b67:	ja     407b8b <__swc_fn_65555ab2_000018_283e2b5e+0x9b>
  407b69:	mov    rax,r9
  407b6c:	lock cmpxchg QWORD PTR [r8],r10
  407b71:	cmp    rax,r9
  407b74:	je     407b7b <__swc_fn_65555ab2_000018_283e2b5e+0x8b>
  407b76:	mov    r9,rax
  407b79:	jmp    407b60 <__swc_fn_65555ab2_000018_283e2b5e+0x70>
  407b7b:	mov    rcx,rdi
  407b7e:	mov    rdx,r12
  407b81:	call   40f130 <__swc_fn_65555ab2_000020_de02dbdf>
  407b86:	jmp    407c0d <__swc_fn_65555ab2_000018_283e2b5e+0x11d>
  407b8b:	mov    rcx,rdi
  407b8e:	movzx  edx,dl
  407b91:	call   407ad0 <__swc_fn_65555ab2_000015_9dea5065>
  407b96:	test   r13,r13
  407b99:	je     407c06 <__swc_fn_65555ab2_000018_283e2b5e+0x116>
  407b9f:	mov    rcx,rax
  407ba2:	mov    rdx,r13
  407ba5:	call   411180 <__swc_fn_65555ab2_000116_e9fc0224>
  407baa:	mov    rcx,QWORD PTR [rip+0x1c49f]        # 424050 <__swc_bss_base_65555ab2+0x10>
  407bb1:	cs nop WORD PTR [rax+rax*1+0x0]
  407bbb:	nop    DWORD PTR [rax+rax*1+0x0]
  407bc0:	mov    rdx,rcx
  407bc3:	sub    rdx,r13
  407bc6:	mov    rax,rcx
  407bc9:	lock cmpxchg QWORD PTR [r14],rdx
  407bce:	cmp    rax,rcx
  407bd1:	je     407bd8 <__swc_fn_65555ab2_000018_283e2b5e+0xe8>
  407bd3:	mov    rcx,rax
  407bd6:	jmp    407bc0 <__swc_fn_65555ab2_000018_283e2b5e+0xd0>
  407bd8:	lea    rcx,[rip+0x1c489]        # 424068 <__swc_bss_base_65555ab2+0x28>
  407bdf:	mov    rdx,QWORD PTR [rip+0x1c482]        # 424068 <__swc_bss_base_65555ab2+0x28>
  407be6:	cs nop WORD PTR [rax+rax*1+0x0]
  407bf0:	lea    r8,[rdx+0x1]
  407bf4:	mov    rax,rdx
  407bf7:	lock cmpxchg QWORD PTR [rcx],r8
  407bfc:	cmp    rax,rdx
  407bff:	je     407c06 <__swc_fn_65555ab2_000018_283e2b5e+0x116>
  407c01:	mov    rdx,rax
  407c04:	jmp    407bf0 <__swc_fn_65555ab2_000018_283e2b5e+0x100>
  407c06:	mov    DWORD PTR [rsi+0x3c],0x0
  407c0d:	mov    rcx,rdi
  407c10:	mov    rdx,r12
  407c13:	call   40bff0 <__swc_fn_65555ab2_000022_c8f5f27c>
  407c18:	pop    r14
  407c1a:	pop    r13
  407c1c:	pop    r12
  407c1e:	pop    rdi
  407c1f:	pop    rsi
  407c20:	ret
	...

0000000000407c30 <__swc_fn_65555ab2_000021_fd2b165c>:
  407c30:	mov    r8,QWORD PTR [rcx+0x48]
  407c34:	test   r8,rdx
  407c37:	je     407c68 <__swc_fn_65555ab2_000021_fd2b165c+0x38>
  407c39:	nop    DWORD PTR [rax+0x0]
  407c40:	mov    rax,rdx
  407c43:	not    rax
  407c46:	mov    r9,r8
  407c49:	and    r9,rax
  407c4c:	mov    rax,r8
  407c4f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  407c55:	cmp    rax,r8
  407c58:	jne    407c60 <__swc_fn_65555ab2_000021_fd2b165c+0x30>
  407c5a:	mov    eax,0x1
  407c5f:	ret
  407c60:	mov    r8,rax
  407c63:	test   rax,rdx
  407c66:	jne    407c40 <__swc_fn_65555ab2_000021_fd2b165c+0x10>
  407c68:	xor    eax,eax
  407c6a:	ret
  407c6b:	add    BYTE PTR [rax],al
  407c6d:	add    BYTE PTR [rax],al
	...

0000000000407c70 <__swc_fn_65555ab2_000024_2685aade>:
  407c70:	push   rsi
  407c71:	push   rdi
  407c72:	push   r12
  407c74:	push   r13
  407c76:	sub    rsp,0x8
  407c7a:	mov    rsi,rdx
  407c7d:	mov    rdi,rcx
  407c80:	lea    r12,[rip+0x1c571]        # 4241f8 <__swc_bss_base_65555ab2+0x1b8>
  407c87:	mov    rcx,r12
  407c8a:	call   40e280 <__swc_fn_65555ab2_000139_86bb0f90>
  407c8f:	xor    eax,eax
  407c91:	mov    rcx,QWORD PTR [rip+0x1c568]        # 424200 <__swc_bss_base_65555ab2+0x1c0>
  407c98:	mov    r13,rcx
  407c9b:	test   r13,r13
  407c9e:	je     407ceb <__swc_fn_65555ab2_000024_2685aade+0x7b>
  407ca0:	mov    rcx,QWORD PTR [r13+0x10]
  407ca4:	cmp    DWORD PTR [r13+0x28],esi
  407ca8:	jne    407ce0 <__swc_fn_65555ab2_000024_2685aade+0x70>
  407caa:	test   rax,rax
  407cad:	jne    407cb8 <__swc_fn_65555ab2_000024_2685aade+0x48>
  407caf:	mov    QWORD PTR [rip+0x1c54a],rcx        # 424200 <__swc_bss_base_65555ab2+0x1c0>
  407cb6:	jmp    407cbc <__swc_fn_65555ab2_000024_2685aade+0x4c>
  407cb8:	mov    QWORD PTR [rax+0x10],rcx
  407cbc:	vxorps xmm0,xmm0,xmm0
  407cc0:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407cc6:	mov    QWORD PTR [r13+0x8],rdi
  407cca:	mov    rcx,r12
  407ccd:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  407cd2:	mov    rax,r13
  407cd5:	add    rsp,0x8
  407cd9:	pop    r13
  407cdb:	pop    r12
  407cdd:	pop    rdi
  407cde:	pop    rsi
  407cdf:	ret
  407ce0:	mov    rax,r13
  407ce3:	mov    r13,rcx
  407ce6:	test   rcx,rcx
  407ce9:	jne    407ca0 <__swc_fn_65555ab2_000024_2685aade+0x30>
  407ceb:	mov    ecx,esi
  407ced:	call   40f160 <__swc_fn_65555ab2_000023_2d0fcd2c>
  407cf2:	mov    rsi,rax
  407cf5:	test   rax,rax
  407cf8:	jne    407d0f <__swc_fn_65555ab2_000024_2685aade+0x9f>
  407cfa:	mov    rcx,r12
  407cfd:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  407d02:	xor    eax,eax
  407d04:	add    rsp,0x8
  407d08:	pop    r13
  407d0a:	pop    r12
  407d0c:	pop    rdi
  407d0d:	pop    rsi
  407d0e:	ret
  407d0f:	mov    QWORD PTR [rsi+0x8],rdi
  407d13:	mov    rcx,r12
  407d16:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  407d1b:	mov    rax,rsi
  407d1e:	add    rsp,0x8
  407d22:	pop    r13
  407d24:	pop    r12
  407d26:	pop    rdi
  407d27:	pop    rsi
  407d28:	ret
	...

0000000000407d40 <__swc_fn_65555ab2_000027_9798fb47>:
  407d40:	vxorps xmm0,xmm0,xmm0
  407d44:	xor    eax,eax
  407d46:	cs nop WORD PTR [rax+rax*1+0x0]
  407d50:	cs nop WORD PTR [rax+rax*1+0x0]
  407d5a:	nop    WORD PTR [rax+rax*1+0x0]
  407d60:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  407d65:	add    rax,0x10
  407d69:	cmp    rax,0x2b00
  407d70:	jne    407d60 <__swc_fn_65555ab2_000027_9798fb47+0x20>
  407d72:	ret
	...

0000000000407d80 <__swc_fn_65555ab2_000030_9798fb47>:
  407d80:	vxorps xmm0,xmm0,xmm0
  407d84:	vmovups XMMWORD PTR [rcx],xmm0
  407d88:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  407d8d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407d92:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407d97:	ret
	...

0000000000407da0 <__swc_fn_65555ab2_000033_9798fb47>:
  407da0:	vxorps xmm0,xmm0,xmm0
  407da4:	vmovups XMMWORD PTR [rcx],xmm0
  407da8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  407dad:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407db2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407db7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  407dbc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407dc1:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407dc6:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  407dcb:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  407dd3:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  407ddb:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  407de3:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  407deb:	mov    QWORD PTR [rcx+0xc0],0x0
  407df6:	ret
	...

0000000000407e00 <__swc_fn_65555ab2_000036_92d9bbff>:
  407e00:	push   rsi
  407e01:	push   rdi
  407e02:	sub    rsp,0x8
  407e06:	mov    rsi,rcx
  407e09:	lea    rdi,[rip+0x1a1f8]        # 422008 <__swc_data_base_65555ab2+0x8>
  407e10:	mov    rax,QWORD PTR [rdi]
  407e13:	cmp    rax,0xffffffffffffffff
  407e17:	je     407e1e <__swc_fn_65555ab2_000036_92d9bbff+0x1e>
  407e19:	mov    rdi,rax
  407e1c:	jmp    407e4b <__swc_fn_65555ab2_000036_92d9bbff+0x4b>
  407e1e:	call   40df60 <__swc_fn_65555ab2_000127_58f0f391>
  407e23:	mov    rcx,rax
  407e26:	cmp    rax,0xffffffffffffffff
  407e2a:	je     407e5c <__swc_fn_65555ab2_000036_92d9bbff+0x5c>
  407e2c:	mov    rax,0xffffffffffffffff
  407e33:	lock cmpxchg QWORD PTR [rdi],rcx
  407e38:	cmp    rax,0xffffffffffffffff
  407e3c:	je     407e48 <__swc_fn_65555ab2_000036_92d9bbff+0x48>
  407e3e:	mov    rdi,rax
  407e41:	call   411550 <__swc_fn_65555ab2_000128_a481cb88>
  407e46:	jmp    407e4b <__swc_fn_65555ab2_000036_92d9bbff+0x4b>
  407e48:	mov    rdi,rcx
  407e4b:	cmp    rdi,0xffffffffffffffff
  407e4f:	je     407e5c <__swc_fn_65555ab2_000036_92d9bbff+0x5c>
  407e51:	mov    rcx,rdi
  407e54:	mov    rdx,rsi
  407e57:	call   409f10 <__swc_fn_65555ab2_000129_4bbe3f14>
  407e5c:	add    rsp,0x8
  407e60:	pop    rdi
  407e61:	pop    rsi
  407e62:	ret
	...

0000000000407e70 <__swc_fn_65555ab2_000039_03f1bf9a>:
  407e70:	sub    rsp,0x38
  407e74:	mov    rax,rdx
  407e77:	test   dl,dl
  407e79:	jne    407e91 <__swc_fn_65555ab2_000039_03f1bf9a+0x21>
  407e7b:	mov    rax,r8
  407e7e:	test   r8b,r8b
  407e81:	cmove  eax,r9d
  407e85:	test   al,al
  407e87:	cmove  eax,r10d
  407e8b:	test   al,al
  407e8d:	cmove  eax,r11d
  407e91:	test   al,al
  407e93:	jne    407e9a <__swc_fn_65555ab2_000039_03f1bf9a+0x2a>
  407e95:	add    rsp,0x38
  407e99:	ret
  407e9a:	lea    rcx,[rip+0xb597]        # 413438 <__swc_rdata_base_65555ab2+0x328>
  407ea1:	vmovups xmm0,XMMWORD PTR [rip+0xb59f]        # 413448 <__swc_rdata_base_65555ab2+0x338>
  407ea9:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  407eaf:	vmovups xmm0,XMMWORD PTR [rip+0xb5a1]        # 413458 <__swc_rdata_base_65555ab2+0x348>
  407eb7:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  407ebd:	vmovups xmm0,XMMWORD PTR [rip+0xb5a3]        # 413468 <__swc_rdata_base_65555ab2+0x358>
  407ec5:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  407ecb:	lea    rdx,[rsp+0x8]
  407ed0:	call   410d80 <__swc_fn_65555ab2_000107_90faaa26>
  407ed5:	jmp    407e95 <__swc_fn_65555ab2_000039_03f1bf9a+0x25>
	...

0000000000407ee0 <__swc_fn_65555ab2_000042_facd3e17>:
  407ee0:	sub    rsp,0x8
  407ee4:	mov    eax,0x1000
  407ee9:	test   eax,eax
  407eeb:	mov    r8d,0x8
  407ef1:	cmove  eax,r8d
  407ef5:	dec    rax
  407ef8:	mov    r8,0xffffffffffffffff
  407eff:	sub    r8,rax
  407f02:	cmp    rdx,r8
  407f05:	ja     407f15 <__swc_fn_65555ab2_000042_facd3e17+0x35>
  407f07:	add    rdx,rax
  407f0a:	not    rax
  407f0d:	mov    r8,rdx
  407f10:	and    r8,rax
  407f13:	jne    407f1c <__swc_fn_65555ab2_000042_facd3e17+0x3c>
  407f15:	xor    eax,eax
  407f17:	add    rsp,0x8
  407f1b:	ret
  407f1c:	mov    rdx,r8
  407f1f:	call   40f480 <__swc_fn_65555ab2_000041_c90d80c1>
  407f24:	add    rsp,0x8
  407f28:	ret
  407f29:	add    BYTE PTR [rax],al
  407f2b:	add    BYTE PTR [rax],al
  407f2d:	add    BYTE PTR [rax],al
	...

0000000000407f30 <__swc_fn_65555ab2_000045_d8bd27c3>:
  407f30:	push   rsi
  407f31:	push   rdi
  407f32:	sub    rsp,0x8
  407f36:	mov    rsi,rdx
  407f39:	mov    rdi,rcx
  407f3c:	test   rdx,rdx
  407f3f:	je     407f5b <__swc_fn_65555ab2_000045_d8bd27c3+0x2b>
  407f41:	xor    ecx,ecx
  407f43:	call   40c110 <__swc_fn_65555ab2_000037_28d0e998>
  407f48:	mov    rax,QWORD PTR [rsi]
  407f4b:	test   rax,rax
  407f4e:	je     407f5b <__swc_fn_65555ab2_000045_d8bd27c3+0x2b>
  407f50:	mov    rcx,rax
  407f53:	mov    rdx,rsi
  407f56:	call   40c220 <__swc_fn_65555ab2_000046_b30433d0>
  407f5b:	mov    rcx,rdi
  407f5e:	call   40f4e0 <__swc_fn_65555ab2_000044_a78ae66b>
  407f63:	mov    rsi,rax
  407f66:	test   rax,rax
  407f69:	jne    407f74 <__swc_fn_65555ab2_000045_d8bd27c3+0x44>
  407f6b:	xor    eax,eax
  407f6d:	add    rsp,0x8
  407f71:	pop    rdi
  407f72:	pop    rsi
  407f73:	ret
  407f74:	mov    rcx,rsi
  407f77:	call   40c110 <__swc_fn_65555ab2_000037_28d0e998>
  407f7c:	mov    rax,rsi
  407f7f:	add    rsp,0x8
  407f83:	pop    rdi
  407f84:	pop    rsi
  407f85:	ret
	...

0000000000407f90 <__swc_fn_65555ab2_000048_137687bb>:
  407f90:	movzx  eax,BYTE PTR [r8+0x39]
  407f95:	lea    rax,[rax+rax*4]
  407f99:	lea    rax,[rdx+rax*8+0x28]
  407f9e:	mov    ecx,DWORD PTR [r8+0x6c]
  407fa2:	test   ecx,ecx
  407fa4:	je     407fdd <__swc_fn_65555ab2_000048_137687bb+0x4d>
  407fa6:	mov    rcx,QWORD PTR [r8+0x50]
  407faa:	test   rcx,rcx
  407fad:	je     407fb9 <__swc_fn_65555ab2_000048_137687bb+0x29>
  407faf:	mov    rax,QWORD PTR [r8+0x48]
  407fb3:	mov    QWORD PTR [rcx+0x48],rax
  407fb7:	jmp    407fc1 <__swc_fn_65555ab2_000048_137687bb+0x31>
  407fb9:	mov    rcx,QWORD PTR [r8+0x48]
  407fbd:	mov    QWORD PTR [rax+0x18],rcx
  407fc1:	mov    rax,QWORD PTR [r8+0x48]
  407fc5:	test   rax,rax
  407fc8:	je     407fd2 <__swc_fn_65555ab2_000048_137687bb+0x42>
  407fca:	mov    rcx,QWORD PTR [r8+0x50]
  407fce:	mov    QWORD PTR [rax+0x50],rcx
  407fd2:	vxorps xmm0,xmm0,xmm0
  407fd6:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  407fdc:	ret
  407fdd:	mov    rcx,QWORD PTR [r8+0x50]
  407fe1:	test   rcx,rcx
  407fe4:	je     407ff0 <__swc_fn_65555ab2_000048_137687bb+0x60>
  407fe6:	mov    rdx,QWORD PTR [r8+0x48]
  407fea:	mov    QWORD PTR [rcx+0x48],rdx
  407fee:	jmp    407ff8 <__swc_fn_65555ab2_000048_137687bb+0x68>
  407ff0:	mov    rcx,QWORD PTR [r8+0x48]
  407ff4:	mov    QWORD PTR [rax+0x8],rcx
  407ff8:	mov    rcx,QWORD PTR [r8+0x48]
  407ffc:	test   rcx,rcx
  407fff:	je     40800b <__swc_fn_65555ab2_000048_137687bb+0x7b>
  408001:	mov    rdx,QWORD PTR [r8+0x50]
  408005:	mov    QWORD PTR [rcx+0x50],rdx
  408009:	jmp    408013 <__swc_fn_65555ab2_000048_137687bb+0x83>
  40800b:	mov    rcx,QWORD PTR [r8+0x50]
  40800f:	mov    QWORD PTR [rax+0x10],rcx
  408013:	cmp    QWORD PTR [rax],r8
  408016:	jne    40801f <__swc_fn_65555ab2_000048_137687bb+0x8f>
  408018:	mov    QWORD PTR [rax],0x0
  40801f:	vxorps xmm0,xmm0,xmm0
  408023:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  408029:	ret
  40802a:	add    BYTE PTR [rax],al
  40802c:	add    BYTE PTR [rax],al
	...

0000000000408030 <__swc_fn_65555ab2_000051_e072b516>:
  408030:	sub    rsp,0x8
  408034:	mov    r9,r8
  408037:	mov    r10,rdx
  40803a:	call   407f90 <__swc_fn_65555ab2_000048_137687bb>
  40803f:	mov    DWORD PTR [r9+0x6c],0x0
  408047:	movzx  eax,BYTE PTR [r9+0x39]
  40804c:	lea    rax,[rax+rax*4]
  408050:	lea    rax,[r10+rax*8+0x28]
  408055:	mov    rcx,QWORD PTR [rax+0x10]
  408059:	mov    QWORD PTR [r9+0x50],rcx
  40805d:	mov    QWORD PTR [r9+0x48],0x0
  408065:	mov    rcx,QWORD PTR [rax+0x10]
  408069:	test   rcx,rcx
  40806c:	je     408074 <__swc_fn_65555ab2_000051_e072b516+0x44>
  40806e:	mov    QWORD PTR [rcx+0x48],r9
  408072:	jmp    408078 <__swc_fn_65555ab2_000051_e072b516+0x48>
  408074:	mov    QWORD PTR [rax+0x8],r9
  408078:	mov    QWORD PTR [rax+0x10],r9
  40807c:	add    rsp,0x8
  408080:	ret
	...

00000000004080a0 <__swc_fn_65555ab2_000054_faa92dcc>:
  4080a0:	push   rsi
  4080a1:	push   rdi
  4080a2:	push   r12
  4080a4:	push   r13
  4080a6:	push   r14
  4080a8:	push   r15
  4080aa:	sub    rsp,0x1f8
  4080b1:	mov    esi,r8d
  4080b4:	mov    QWORD PTR [rsp+0x1e8],rsi
  4080bc:	mov    rdi,rcx
  4080bf:	mov    r12,rdx
  4080c2:	lea    r13,[rsi+rsi*4]
  4080c6:	lea    r13,[rdx+r13*8+0x28]
  4080cb:	call   40c680 <__swc_fn_65555ab2_000052_d846b172>
  4080d0:	add    DWORD PTR [r12+0x24],0x1
  4080d6:	test   BYTE PTR [r12+0x24],0x3f
  4080dc:	jne    4080e6 <__swc_fn_65555ab2_000054_faa92dcc+0x46>
  4080de:	mov    rcx,rdi
  4080e1:	call   40f660 <__swc_fn_65555ab2_000053_3af34d7f>
  4080e6:	mov    rax,QWORD PTR [r13+0x8]
  4080ea:	mov    r14,rax
  4080ed:	nop    DWORD PTR [rax]
  4080f0:	test   r14,r14
  4080f3:	jne    408102 <__swc_fn_65555ab2_000054_faa92dcc+0x62>
  4080f5:	mov    rsi,QWORD PTR [rsp+0x1e8]
  4080fd:	jmp    408209 <__swc_fn_65555ab2_000054_faa92dcc+0x169>
  408102:	mov    r15,QWORD PTR [r14+0x48]
  408106:	mov    rcx,r14
  408109:	call   40bde0 <__swc_fn_65555ab2_000013_e4b0ddfc>
  40810e:	mov    rax,QWORD PTR [r14]
  408111:	test   rax,rax
  408114:	je     408126 <__swc_fn_65555ab2_000054_faa92dcc+0x86>
  408116:	mov    rcx,QWORD PTR [rax]
  408119:	mov    QWORD PTR [r14],rcx
  40811c:	add    DWORD PTR [r14+0x28],0x1
  408121:	mov    rsi,rax
  408124:	jmp    408145 <__swc_fn_65555ab2_000054_faa92dcc+0xa5>
  408126:	mov    rax,QWORD PTR [r14+0x18]
  40812a:	cmp    QWORD PTR [r14+0x20],rax
  40812e:	jae    408143 <__swc_fn_65555ab2_000054_faa92dcc+0xa3>
  408130:	mov    rsi,QWORD PTR [r14+0x20]
  408134:	mov    eax,DWORD PTR [r14+0x2c]
  408138:	add    QWORD PTR [r14+0x20],rax
  40813c:	add    DWORD PTR [r14+0x28],0x1
  408141:	jmp    408145 <__swc_fn_65555ab2_000054_faa92dcc+0xa5>
  408143:	xor    esi,esi
  408145:	test   rsi,rsi
  408148:	jne    40818d <__swc_fn_65555ab2_000054_faa92dcc+0xed>
  40814a:	mov    rcx,r14
  40814d:	call   40bd10 <__swc_fn_65555ab2_000010_24a20786>
  408152:	test   al,al
  408154:	je     40818d <__swc_fn_65555ab2_000054_faa92dcc+0xed>
  408156:	mov    rax,QWORD PTR [r14]
  408159:	test   rax,rax
  40815c:	je     40816b <__swc_fn_65555ab2_000054_faa92dcc+0xcb>
  40815e:	mov    rcx,QWORD PTR [rax]
  408161:	mov    QWORD PTR [r14],rcx
  408164:	add    DWORD PTR [r14+0x28],0x1
  408169:	jmp    40818a <__swc_fn_65555ab2_000054_faa92dcc+0xea>
  40816b:	mov    rax,QWORD PTR [r14+0x18]
  40816f:	cmp    QWORD PTR [r14+0x20],rax
  408173:	jae    408188 <__swc_fn_65555ab2_000054_faa92dcc+0xe8>
  408175:	mov    rax,QWORD PTR [r14+0x20]
  408179:	mov    ecx,DWORD PTR [r14+0x2c]
  40817d:	add    QWORD PTR [r14+0x20],rcx
  408181:	add    DWORD PTR [r14+0x28],0x1
  408186:	jmp    40818a <__swc_fn_65555ab2_000054_faa92dcc+0xea>
  408188:	xor    eax,eax
  40818a:	mov    rsi,rax
  40818d:	test   rsi,rsi
  408190:	jne    4081e3 <__swc_fn_65555ab2_000054_faa92dcc+0x143>
  408192:	mov    rcx,rdi
  408195:	mov    rdx,r12
  408198:	mov    r8,r14
  40819b:	call   40f5c0 <__swc_fn_65555ab2_000050_129b9bf4>
  4081a0:	test   al,al
  4081a2:	jne    4081e3 <__swc_fn_65555ab2_000054_faa92dcc+0x143>
  4081a4:	mov    rcx,r14
  4081a7:	call   40bde0 <__swc_fn_65555ab2_000013_e4b0ddfc>
  4081ac:	mov    rax,QWORD PTR [r14]
  4081af:	test   rax,rax
  4081b2:	je     4081c1 <__swc_fn_65555ab2_000054_faa92dcc+0x121>
  4081b4:	mov    rcx,QWORD PTR [rax]
  4081b7:	mov    QWORD PTR [r14],rcx
  4081ba:	add    DWORD PTR [r14+0x28],0x1
  4081bf:	jmp    4081e0 <__swc_fn_65555ab2_000054_faa92dcc+0x140>
  4081c1:	mov    rax,QWORD PTR [r14+0x18]
  4081c5:	cmp    QWORD PTR [r14+0x20],rax
  4081c9:	jae    4081de <__swc_fn_65555ab2_000054_faa92dcc+0x13e>
  4081cb:	mov    rax,QWORD PTR [r14+0x20]
  4081cf:	mov    ecx,DWORD PTR [r14+0x2c]
  4081d3:	add    QWORD PTR [r14+0x20],rcx
  4081d7:	add    DWORD PTR [r14+0x28],0x1
  4081dc:	jmp    4081e0 <__swc_fn_65555ab2_000054_faa92dcc+0x140>
  4081de:	xor    eax,eax
  4081e0:	mov    rsi,rax
  4081e3:	test   rsi,rsi
  4081e6:	je     408201 <__swc_fn_65555ab2_000054_faa92dcc+0x161>
  4081e8:	mov    QWORD PTR [r13+0x0],r14
  4081ec:	mov    rax,rsi
  4081ef:	add    rsp,0x1f8
  4081f6:	pop    r15
  4081f8:	pop    r14
  4081fa:	pop    r13
  4081fc:	pop    r12
  4081fe:	pop    rdi
  4081ff:	pop    rsi
  408200:	ret
  408201:	mov    r14,r15
  408204:	jmp    4080f0 <__swc_fn_65555ab2_000054_faa92dcc+0x50>
  408209:	cs nop WORD PTR [rax+rax*1+0x0]
  408213:	cs nop WORD PTR [rax+rax*1+0x0]
  40821d:	nop    DWORD PTR [rax]
  408220:	mov    rcx,rdi
  408223:	mov    rdx,r12
  408226:	mov    r8d,esi
  408229:	call   40c3c0 <__swc_fn_65555ab2_000049_ad48ec88>
  40822e:	mov    r14,rax
  408231:	test   rax,rax
  408234:	jne    40824a <__swc_fn_65555ab2_000054_faa92dcc+0x1aa>
  408236:	xor    eax,eax
  408238:	add    rsp,0x1f8
  40823f:	pop    r15
  408241:	pop    r14
  408243:	pop    r13
  408245:	pop    r12
  408247:	pop    rdi
  408248:	pop    rsi
  408249:	ret
  40824a:	mov    QWORD PTR [r13+0x0],r14
  40824e:	mov    rax,QWORD PTR [r14]
  408251:	test   rax,rax
  408254:	je     408266 <__swc_fn_65555ab2_000054_faa92dcc+0x1c6>
  408256:	mov    rcx,QWORD PTR [rax]
  408259:	mov    QWORD PTR [r14],rcx
  40825c:	add    DWORD PTR [r14+0x28],0x1
  408261:	mov    r15,rax
  408264:	jmp    408286 <__swc_fn_65555ab2_000054_faa92dcc+0x1e6>
  408266:	mov    rax,QWORD PTR [r14+0x18]
  40826a:	cmp    QWORD PTR [r14+0x20],rax
  40826e:	jae    408283 <__swc_fn_65555ab2_000054_faa92dcc+0x1e3>
  408270:	mov    r15,QWORD PTR [r14+0x20]
  408274:	mov    eax,DWORD PTR [r14+0x2c]
  408278:	add    QWORD PTR [r14+0x20],rax
  40827c:	add    DWORD PTR [r14+0x28],0x1
  408281:	jmp    408286 <__swc_fn_65555ab2_000054_faa92dcc+0x1e6>
  408283:	xor    r15d,r15d
  408286:	test   r15,r15
  408289:	jne    4082ce <__swc_fn_65555ab2_000054_faa92dcc+0x22e>
  40828b:	mov    rcx,r14
  40828e:	call   40bd10 <__swc_fn_65555ab2_000010_24a20786>
  408293:	test   al,al
  408295:	je     4082ce <__swc_fn_65555ab2_000054_faa92dcc+0x22e>
  408297:	mov    rax,QWORD PTR [r14]
  40829a:	test   rax,rax
  40829d:	je     4082ac <__swc_fn_65555ab2_000054_faa92dcc+0x20c>
  40829f:	mov    rcx,QWORD PTR [rax]
  4082a2:	mov    QWORD PTR [r14],rcx
  4082a5:	add    DWORD PTR [r14+0x28],0x1
  4082aa:	jmp    4082cb <__swc_fn_65555ab2_000054_faa92dcc+0x22b>
  4082ac:	mov    rax,QWORD PTR [r14+0x18]
  4082b0:	cmp    QWORD PTR [r14+0x20],rax
  4082b4:	jae    4082c9 <__swc_fn_65555ab2_000054_faa92dcc+0x229>
  4082b6:	mov    rax,QWORD PTR [r14+0x20]
  4082ba:	mov    ecx,DWORD PTR [r14+0x2c]
  4082be:	add    QWORD PTR [r14+0x20],rcx
  4082c2:	add    DWORD PTR [r14+0x28],0x1
  4082c7:	jmp    4082cb <__swc_fn_65555ab2_000054_faa92dcc+0x22b>
  4082c9:	xor    eax,eax
  4082cb:	mov    r15,rax
  4082ce:	test   r15,r15
  4082d1:	je     408220 <__swc_fn_65555ab2_000054_faa92dcc+0x180>
  4082d7:	mov    rax,r15
  4082da:	add    rsp,0x1f8
  4082e1:	pop    r15
  4082e3:	pop    r14
  4082e5:	pop    r13
  4082e7:	pop    r12
  4082e9:	pop    rdi
  4082ea:	pop    rsi
  4082eb:	ret
  4082ec:	add    BYTE PTR [rax],al
	...

00000000004082f0 <__swc_fn_65555ab2_000057_7e1dbcb0>:
  4082f0:	push   rsi
  4082f1:	push   rdi
  4082f2:	push   r12
  4082f4:	mov    rsi,rdx
  4082f7:	mov    rax,rdx
  4082fa:	shr    rax,0xc
  4082fe:	movabs rdx,0x9e3779b97f4a7c15
  408308:	imul   rax,rdx
  40830c:	shr    rax,0x20
  408310:	lea    rax,[rax*8+0x0]
  408318:	shr    rax,0x20
  40831c:	lea    rax,[rax*8+0x0]
  408324:	lea    rax,[rcx+rax*8+0x40]
  408329:	xor    edx,edx
  40832b:	test   dl,dl
  40832d:	lea    rdi,[rcx+0x8]
  408331:	cmove  rdi,rax
  408335:	xor    edx,edx
  408337:	test   dl,dl
  408339:	lea    r12,[rcx+0x30]
  40833d:	lea    rax,[rax+0x8]
  408341:	cmove  r12,rax
  408345:	mov    rcx,rdi
  408348:	call   40e280 <__swc_fn_65555ab2_000139_86bb0f90>
  40834d:	mov    QWORD PTR [rsi+0x30],0x0
  408355:	mov    rax,QWORD PTR [r12]
  408359:	mov    QWORD PTR [rsi+0x38],rax
  40835d:	test   rax,rax
  408360:	je     40836a <__swc_fn_65555ab2_000057_7e1dbcb0+0x7a>
  408362:	mov    rax,QWORD PTR [rsi+0x38]
  408366:	mov    QWORD PTR [rax+0x30],rsi
  40836a:	mov    QWORD PTR [r12],rsi
  40836e:	mov    rcx,rdi
  408371:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  408376:	pop    r12
  408378:	pop    rdi
  408379:	pop    rsi
  40837a:	ret
  40837b:	add    BYTE PTR [rax],al
  40837d:	add    BYTE PTR [rax],al
	...

0000000000408380 <__swc_fn_65555ab2_000060_15c28ca7>:
  408380:	lea    rax,[rdx+rdx*4]
  408384:	lea    rax,[rcx+rax*8+0x268]
  40838c:	mov    rdx,QWORD PTR [rax+0x10]
  408390:	sub    QWORD PTR [rcx+0x2a68],rdx
  408397:	sub    QWORD PTR [rcx+0x2a70],0x1
  40839f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  4083a6:	lea    rdx,[rdx+rdx*4]
  4083aa:	lea    rdx,[rcx+rdx*8+0x268]
  4083b2:	vmovups xmm0,XMMWORD PTR [rdx]
  4083b6:	vmovups XMMWORD PTR [rax],xmm0
  4083ba:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  4083bf:	vmovups XMMWORD PTR [rax+0x10],xmm0
  4083c4:	mov    rcx,QWORD PTR [rdx+0x20]
  4083c8:	mov    QWORD PTR [rax+0x20],rcx
  4083cc:	ret
  4083cd:	add    BYTE PTR [rax],al
	...

00000000004083d0 <__swc_fn_65555ab2_000063_dea90857>:
  4083d0:	push   rsi
  4083d1:	push   rdi
  4083d2:	push   r12
  4083d4:	push   r13
  4083d6:	sub    rsp,0x8
  4083da:	mov    rsi,r8
  4083dd:	mov    rdi,rcx
  4083e0:	mov    r12,rdx
  4083e3:	xor    r13d,r13d
  4083e6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083f0:	mov    eax,DWORD PTR [r12+0x730]
  4083f8:	cmp    r13d,eax
  4083fb:	jae    408461 <__swc_fn_65555ab2_000063_dea90857+0x91>
  4083fd:	lea    rax,[r13+r13*4+0x0]
  408402:	lea    rax,[r12+rax*8+0x738]
  40840a:	mov    rdx,QWORD PTR [rax]
  40840d:	mov    r8,QWORD PTR [rax+0x8]
  408411:	mov    r9,QWORD PTR [rax+0x10]
  408415:	cmp    QWORD PTR [rax+0x20],rsi
  408419:	jb     408420 <__swc_fn_65555ab2_000063_dea90857+0x50>
  40841b:	inc    r13d
  40841e:	jmp    4083f0 <__swc_fn_65555ab2_000063_dea90857+0x20>
  408420:	sub    DWORD PTR [r12+0x730],0x1
  408429:	mov    ecx,DWORD PTR [r12+0x730]
  408431:	lea    rcx,[rcx+rcx*4]
  408435:	lea    rcx,[r12+rcx*8+0x738]
  40843d:	vmovups xmm0,XMMWORD PTR [rcx]
  408441:	vmovups XMMWORD PTR [rax],xmm0
  408445:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40844a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40844f:	mov    rcx,QWORD PTR [rcx+0x20]
  408453:	mov    QWORD PTR [rax+0x20],rcx
  408457:	mov    rcx,rdi
  40845a:	call   40c140 <__swc_fn_65555ab2_000043_d3c2ab54>
  40845f:	jmp    4083f0 <__swc_fn_65555ab2_000063_dea90857+0x20>
  408461:	add    rsp,0x8
  408465:	pop    r13
  408467:	pop    r12
  408469:	pop    rdi
  40846a:	pop    rsi
  40846b:	ret
  40846c:	add    BYTE PTR [rax],al
	...

0000000000408470 <__swc_fn_65555ab2_000066_de167e8d>:
  408470:	push   rsi
  408471:	push   rdi
  408472:	push   r12
  408474:	push   r13
  408476:	push   r14
  408478:	mov    rsi,rcx
  40847b:	mov    rdi,rdx
  40847e:	mov    r12,QWORD PTR [rdi]
  408481:	mov    r13,QWORD PTR [rdi+0x18]
  408485:	mov    rax,r12
  408488:	add    rax,QWORD PTR [rdi+0x8]
  40848c:	sub    rax,r13
  40848f:	cmp    r8,rax
  408492:	jbe    40849d <__swc_fn_65555ab2_000066_de167e8d+0x2d>
  408494:	pop    r14
  408496:	pop    r13
  408498:	pop    r12
  40849a:	pop    rdi
  40849b:	pop    rsi
  40849c:	ret
  40849d:	lea    rax,[r13+r8*1+0x0]
  4084a2:	sub    rax,r12
  4084a5:	mov    ecx,0x1000
  4084aa:	test   ecx,ecx
  4084ac:	mov    edx,0x8
  4084b1:	cmove  ecx,edx
  4084b4:	dec    rcx
  4084b7:	mov    rdx,0xffffffffffffffff
  4084be:	sub    rdx,rcx
  4084c1:	cmp    rax,rdx
  4084c4:	jbe    4084cb <__swc_fn_65555ab2_000066_de167e8d+0x5b>
  4084c6:	xor    r14d,r14d
  4084c9:	jmp    4084d6 <__swc_fn_65555ab2_000066_de167e8d+0x66>
  4084cb:	add    rax,rcx
  4084ce:	andn   rax,rcx,rax
  4084d3:	mov    r14,rax
  4084d6:	mov    rax,QWORD PTR [rdi+0x10]
  4084da:	cmp    r14,rax
  4084dd:	ja     4084e8 <__swc_fn_65555ab2_000066_de167e8d+0x78>
  4084df:	pop    r14
  4084e1:	pop    r13
  4084e3:	pop    r12
  4084e5:	pop    rdi
  4084e6:	pop    rsi
  4084e7:	ret
  4084e8:	mov    rax,r12
  4084eb:	add    rax,QWORD PTR [rdi+0x10]
  4084ef:	mov    rdx,r14
  4084f2:	sub    rdx,QWORD PTR [rdi+0x10]
  4084f6:	mov    rcx,rax
  4084f9:	call   40bc90 <__swc_fn_65555ab2_000007_f7acedb0>
  4084fe:	test   al,al
  408500:	jne    40850b <__swc_fn_65555ab2_000066_de167e8d+0x9b>
  408502:	pop    r14
  408504:	pop    r13
  408506:	pop    r12
  408508:	pop    rdi
  408509:	pop    rsi
  40850a:	ret
  40850b:	add    r12,r14
  40850e:	sub    r12,r13
  408511:	mov    rcx,r12
  408514:	sub    rcx,QWORD PTR [rdi+0x28]
  408518:	mov    rdx,QWORD PTR [rsi+0x250]
  40851f:	nop
  408520:	lea    r8,[rdx+rcx*1]
  408524:	mov    rax,rdx
  408527:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  408530:	cmp    rax,rdx
  408533:	je     40853a <__swc_fn_65555ab2_000066_de167e8d+0xca>
  408535:	mov    rdx,rax
  408538:	jmp    408520 <__swc_fn_65555ab2_000066_de167e8d+0xb0>
  40853a:	mov    QWORD PTR [rdi+0x10],r14
  40853e:	mov    QWORD PTR [rdi+0x28],r12
  408542:	pop    r14
  408544:	pop    r13
  408546:	pop    r12
  408548:	pop    rdi
  408549:	pop    rsi
  40854a:	ret
  40854b:	add    BYTE PTR [rax],al
  40854d:	add    BYTE PTR [rax],al
	...

0000000000408550 <__swc_fn_65555ab2_000069_7130736e>:
  408550:	push   rbx
  408551:	push   rsi
  408552:	push   rdi
  408553:	push   r12
  408555:	push   r13
  408557:	sub    rsp,0xe0
  40855e:	mov    rbx,rdx
  408561:	mov    rsi,rcx
  408564:	cmp    DWORD PTR [rbx+0x58],0x0
  408568:	je     40858c <__swc_fn_65555ab2_000069_7130736e+0x3c>
  40856a:	mov    eax,DWORD PTR [rbx+0x58]
  40856d:	sub    eax,0x1
  408570:	test   DWORD PTR [rbx+0x58],eax
  408573:	je     40858c <__swc_fn_65555ab2_000069_7130736e+0x3c>
  408575:	mov    QWORD PTR [rbx+0x40],0x0
  40857d:	add    rsp,0xe0
  408584:	pop    r13
  408586:	pop    r12
  408588:	pop    rdi
  408589:	pop    rsi
  40858a:	pop    rbx
  40858b:	ret
  40858c:	mov    rax,QWORD PTR [rbx+0x40]
  408590:	test   rax,rax
  408593:	jne    4085af <__swc_fn_65555ab2_000069_7130736e+0x5f>
  408595:	mov    rcx,rsi
  408598:	mov    rdx,rbx
  40859b:	call   410270 <__swc_fn_65555ab2_000068_f3aa21af>
  4085a0:	add    rsp,0xe0
  4085a7:	pop    r13
  4085a9:	pop    r12
  4085ab:	pop    rdi
  4085ac:	pop    rsi
  4085ad:	pop    rbx
  4085ae:	ret
  4085af:	cmp    QWORD PTR [rbx+0x48],0x0
  4085b4:	jne    4085d0 <__swc_fn_65555ab2_000069_7130736e+0x80>
  4085b6:	mov    rcx,rsi
  4085b9:	mov    rdx,rbx
  4085bc:	call   40c970 <__swc_fn_65555ab2_000070_97813b89>
  4085c1:	add    rsp,0xe0
  4085c8:	pop    r13
  4085ca:	pop    r12
  4085cc:	pop    rdi
  4085cd:	pop    rsi
  4085ce:	pop    rbx
  4085cf:	ret
  4085d0:	mov    rdi,QWORD PTR [rbx+0x40]
  4085d4:	lea    rax,[rip+0x1ba9d]        # 424078 <__swc_bss_base_65555ab2+0x38>
  4085db:	mov    rcx,rdi
  4085de:	sub    rcx,QWORD PTR [rax+0x8]
  4085e2:	mov    rax,QWORD PTR [rip+0x1ba9f]        # 424088 <__swc_bss_base_65555ab2+0x48>
  4085e9:	cmp    rcx,rax
  4085ec:	jae    408618 <__swc_fn_65555ab2_000069_7130736e+0xc8>
  4085ee:	mov    rax,rdi
  4085f1:	and    rax,0xffffffffffc00000
  4085f8:	mov    rcx,rdi
  4085fb:	shr    rcx,0x10
  4085ff:	and    ecx,0x3f
  408602:	mov    edx,DWORD PTR [rax+0x28]
  408605:	shrx   ecx,ecx,edx
  40860a:	shl    rcx,0x4
  40860e:	lea    r12,[rax+rcx*8+0x80]
  408616:	jmp    408623 <__swc_fn_65555ab2_000069_7130736e+0xd3>
  408618:	mov    rcx,rdi
  40861b:	call   40f2f0 <__swc_fn_65555ab2_000026_bcdc5519>
  408620:	mov    r12,rax
  408623:	test   r12,r12
  408626:	je     408635 <__swc_fn_65555ab2_000069_7130736e+0xe5>
  408628:	mov    eax,DWORD PTR [r12+0x2c]
  40862d:	mov    r9d,eax
  408630:	mov    r13,rax
  408633:	jmp    4086b4 <__swc_fn_65555ab2_000069_7130736e+0x164>
  408635:	mov    rcx,rsi
  408638:	mov    rdx,rdi
  40863b:	call   40f900 <__swc_fn_65555ab2_000056_df0696cd>
  408640:	mov    rcx,QWORD PTR [rax+0x28]
  408644:	mov    r9,rcx
  408647:	mov    rdx,QWORD PTR [rax+0x20]
  40864b:	mov    r13,rdx
  40864e:	cmp    QWORD PTR [rbx+0x48],rcx
  408652:	jbe    40868b <__swc_fn_65555ab2_000069_7130736e+0x13b>
  408654:	mov    ecx,DWORD PTR [rax+0x48]
  408657:	cmp    DWORD PTR [rbx+0x58],ecx
  40865a:	ja     40868b <__swc_fn_65555ab2_000069_7130736e+0x13b>
  40865c:	mov    rcx,rsi
  40865f:	mov    rdx,rax
  408662:	mov    r8,QWORD PTR [rbx+0x48]
  408666:	mov    QWORD PTR [rsp+0xc8],r9
  40866e:	mov    QWORD PTR [rsp+0xd0],rax
  408676:	call   408470 <__swc_fn_65555ab2_000066_de167e8d>
  40867b:	mov    r9,QWORD PTR [rsp+0xc8]
  408683:	mov    rax,QWORD PTR [rsp+0xd0]
  40868b:	mov    rcx,QWORD PTR [rax+0x28]
  40868f:	cmp    QWORD PTR [rbx+0x48],rcx
  408693:	ja     4086b4 <__swc_fn_65555ab2_000069_7130736e+0x164>
  408695:	mov    ecx,DWORD PTR [rax+0x48]
  408698:	cmp    DWORD PTR [rbx+0x58],ecx
  40869b:	ja     4086b4 <__swc_fn_65555ab2_000069_7130736e+0x164>
  40869d:	mov    rcx,QWORD PTR [rbx+0x48]
  4086a1:	mov    QWORD PTR [rax+0x20],rcx
  4086a5:	add    rsp,0xe0
  4086ac:	pop    r13
  4086ae:	pop    r12
  4086b0:	pop    rdi
  4086b1:	pop    rsi
  4086b2:	pop    rbx
  4086b3:	ret
  4086b4:	test   r12,r12
  4086b7:	je     4086e9 <__swc_fn_65555ab2_000069_7130736e+0x199>
  4086b9:	cmp    QWORD PTR [rbx+0x48],r9
  4086bd:	ja     4086e9 <__swc_fn_65555ab2_000069_7130736e+0x199>
  4086bf:	cmp    DWORD PTR [rbx+0x58],0x40
  4086c3:	ja     4086e9 <__swc_fn_65555ab2_000069_7130736e+0x199>
  4086c5:	cmp    DWORD PTR [rbx+0x58],0x0
  4086c9:	je     4086d6 <__swc_fn_65555ab2_000069_7130736e+0x186>
  4086cb:	mov    ecx,DWORD PTR [rbx+0x58]
  4086ce:	dec    rcx
  4086d1:	test   rdi,rcx
  4086d4:	jne    4086e9 <__swc_fn_65555ab2_000069_7130736e+0x199>
  4086d6:	mov    QWORD PTR [rbx+0x40],rdi
  4086da:	add    rsp,0xe0
  4086e1:	pop    r13
  4086e3:	pop    r12
  4086e5:	pop    rdi
  4086e6:	pop    rsi
  4086e7:	pop    rbx
  4086e8:	ret
  4086e9:	vmovups xmm0,XMMWORD PTR [rbx]
  4086ed:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4086f3:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  4086f8:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4086fe:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  408703:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  408709:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40870e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  408714:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  408719:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40871f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  408724:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40872a:	mov    QWORD PTR [rsp+0x48],0x0
  408733:	mov    rcx,rsi
  408736:	lea    rdx,[rsp+0x8]
  40873b:	call   410270 <__swc_fn_65555ab2_000068_f3aa21af>
  408740:	mov    rax,QWORD PTR [rsp+0x48]
  408745:	test   rax,rax
  408748:	jne    408761 <__swc_fn_65555ab2_000069_7130736e+0x211>
  40874a:	mov    QWORD PTR [rbx+0x40],0x0
  408752:	add    rsp,0xe0
  408759:	pop    r13
  40875b:	pop    r12
  40875d:	pop    rdi
  40875e:	pop    rsi
  40875f:	pop    rbx
  408760:	ret
  408761:	mov    rax,QWORD PTR [rbx+0x48]
  408765:	cmp    r13,rax
  408768:	cmovbe rax,r13
  40876c:	mov    rcx,QWORD PTR [rsp+0x48]
  408771:	mov    rdx,rdi
  408774:	mov    r8,rax
  408777:	call   40dac0 <__swc_fn_65555ab2_000109_7c204aac>
  40877c:	vmovups xmm0,XMMWORD PTR [rbx]
  408780:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  408786:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40878b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  408791:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  408796:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40879f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  4087a4:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087ad:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  4087b2:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087bb:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  4087c0:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087c9:	mov    QWORD PTR [rsp+0xa8],rdi
  4087d1:	mov    rcx,rsi
  4087d4:	lea    rdx,[rsp+0x68]
  4087d9:	call   40c970 <__swc_fn_65555ab2_000070_97813b89>
  4087de:	mov    rax,QWORD PTR [rsp+0x48]
  4087e3:	mov    QWORD PTR [rbx+0x40],rax
  4087e7:	add    rsp,0xe0
  4087ee:	pop    r13
  4087f0:	pop    r12
  4087f2:	pop    rdi
  4087f3:	pop    rsi
  4087f4:	pop    rbx
  4087f5:	ret
	...

0000000000408800 <__swc_fn_65555ab2_000072_61e60aab>:
  408800:	push   r12
  408802:	push   rdi
  408803:	push   rsi
  408804:	push   r13
  408806:	push   r14
  408808:	sub    rsp,0x190
  40880f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  408818:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  408821:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40882a:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  408833:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40883c:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  408845:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40884e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  408857:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  408860:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  408869:	mov    r12,rcx
  40886c:	lea    rax,[rip+0x19795]        # 422008 <__swc_data_base_65555ab2+0x8>
  408873:	mov    rax,QWORD PTR [rax]
  408876:	cmp    rax,0xffffffffffffffff
  40887a:	je     408889 <__swc_fn_65555ab2_000072_61e60aab+0x89>
  40887c:	mov    eax,eax
  40887e:	mov    edi,eax
  408880:	xor    eax,eax
  408882:	call   407000 <pthread_getspecific@plt>
  408887:	jmp    40888b <__swc_fn_65555ab2_000072_61e60aab+0x8b>
  408889:	xor    eax,eax
  40888b:	test   rax,rax
  40888e:	jne    40889d <__swc_fn_65555ab2_000072_61e60aab+0x9d>
  408890:	call   40f3c0 <__swc_fn_65555ab2_000035_cd1a4e8c>
  408895:	mov    rcx,rax
  408898:	call   409fc0 <__swc_fn_65555ab2_000132_5f757033>
  40889d:	test   rax,rax
  4088a0:	je     4088c6 <__swc_fn_65555ab2_000072_61e60aab+0xc6>
  4088a2:	cmp    QWORD PTR [rax],r12
  4088a5:	jne    4088c6 <__swc_fn_65555ab2_000072_61e60aab+0xc6>
  4088a7:	xor    ecx,ecx
  4088a9:	mov    QWORD PTR [rsp+0xc8],rax
  4088b1:	call   40c110 <__swc_fn_65555ab2_000037_28d0e998>
  4088b6:	mov    rdx,QWORD PTR [rsp+0xc8]
  4088be:	mov    rcx,r12
  4088c1:	call   40c220 <__swc_fn_65555ab2_000046_b30433d0>
  4088c6:	lea    rsi,[r12+0x10]
  4088cb:	mov    rcx,rsi
  4088ce:	call   40e280 <__swc_fn_65555ab2_000139_86bb0f90>
  4088d3:	mov    rdi,QWORD PTR [r12+0x20]
  4088d8:	test   rdi,rdi
  4088db:	je     40891e <__swc_fn_65555ab2_000072_61e60aab+0x11e>
  4088dd:	nop    DWORD PTR [rax]
  4088e0:	mov    rcx,r12
  4088e3:	mov    rdx,rdi
  4088e6:	call   40f580 <__swc_fn_65555ab2_000047_6e7a8d58>
  4088eb:	mov    rcx,r12
  4088ee:	mov    rdx,rdi
  4088f1:	mov    r8,0xffffffffffffffff
  4088f8:	call   4083d0 <__swc_fn_65555ab2_000063_dea90857>
  4088fd:	mov    rcx,r12
  408900:	mov    rdx,rdi
  408903:	mov    r8d,0x9b8
  408909:	mov    r9d,0x9b8
  40890f:	call   40c140 <__swc_fn_65555ab2_000043_d3c2ab54>
  408914:	mov    rdi,QWORD PTR [r12+0x20]
  408919:	test   rdi,rdi
  40891c:	jne    4088e0 <__swc_fn_65555ab2_000072_61e60aab+0xe0>
  40891e:	xor    eax,eax
  408920:	xchg   QWORD PTR [r12+0x2a80],rax
  408928:	test   rax,rax
  40892b:	je     408951 <__swc_fn_65555ab2_000072_61e60aab+0x151>
  40892d:	cs nop WORD PTR [rax+rax*1+0x0]
  408937:	nop    WORD PTR [rax+rax*1+0x0]
  408940:	mov    rcx,rax
  408943:	mov    rax,QWORD PTR [rax+0x78]
  408947:	xor    edx,edx
  408949:	xchg   DWORD PTR [rcx+0x70],edx
  40894c:	test   rax,rax
  40894f:	jne    408940 <__swc_fn_65555ab2_000072_61e60aab+0x140>
  408951:	mov    rax,QWORD PTR [r12+0x18]
  408956:	mov    rdi,rax
  408959:	test   rdi,rdi
  40895c:	je     4089f1 <__swc_fn_65555ab2_000072_61e60aab+0x1f1>
  408962:	cs nop WORD PTR [rax+rax*1+0x0]
  40896c:	nop    DWORD PTR [rax+0x0]
  408970:	mov    rax,QWORD PTR [rdi+0x10]
  408974:	mov    r8d,DWORD PTR [rdi+0x2c]
  408978:	xor    r9d,r9d
  40897b:	test   r8,r8
  40897e:	jbe    4089dd <__swc_fn_65555ab2_000072_61e60aab+0x1dd>
  408980:	mov    ecx,r9d
  408983:	shl    rcx,0x4
  408987:	lea    rdx,[rdi+rcx*8+0x80]
  40898f:	cmp    BYTE PTR [rdx+0x3b],0x0
  408993:	je     4089d4 <__swc_fn_65555ab2_000072_61e60aab+0x1d4>
  408995:	mov    DWORD PTR [rdx+0x28],0x0
  40899c:	mov    rcx,rdi
  40899f:	mov    QWORD PTR [rsp+0xd0],rax
  4089a7:	mov    QWORD PTR [rsp+0xd8],r8
  4089af:	mov    QWORD PTR [rsp+0xe0],r9
  4089b7:	call   407af0 <__swc_fn_65555ab2_000018_283e2b5e>
  4089bc:	mov    rax,QWORD PTR [rsp+0xd0]
  4089c4:	mov    r8,QWORD PTR [rsp+0xd8]
  4089cc:	mov    r9,QWORD PTR [rsp+0xe0]
  4089d4:	add    r9,0x1
  4089d8:	cmp    r9,r8
  4089db:	jb     408980 <__swc_fn_65555ab2_000072_61e60aab+0x180>
  4089dd:	mov    rcx,rdi
  4089e0:	mov    rdi,rax
  4089e3:	call   40c020 <__swc_fn_65555ab2_000025_aa910677>
  4089e8:	test   rdi,rdi
  4089eb:	jne    408970 <__swc_fn_65555ab2_000072_61e60aab+0x170>
  4089f1:	mov    QWORD PTR [r12+0x18],0x0
  4089fa:	mov    QWORD PTR [r12+0x28],0x0
  408a03:	mov    rcx,rsi
  408a06:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  408a0b:	mov    esi,0x8
  408a10:	xor    edi,edi
  408a12:	test   rsi,rsi
  408a15:	je     408a72 <__swc_fn_65555ab2_000072_61e60aab+0x272>
  408a1b:	nop    DWORD PTR [rax+rax*1+0x0]
  408a20:	lea    r13,[rdi*8+0x0]
  408a28:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  408a2d:	test   r14,r14
  408a30:	je     408a68 <__swc_fn_65555ab2_000072_61e60aab+0x268>
  408a32:	cs nop WORD PTR [rax+rax*1+0x0]
  408a3c:	nop    DWORD PTR [rax+0x0]
  408a40:	mov    rcx,r12
  408a43:	mov    rdx,r14
  408a46:	call   40c7d0 <__swc_fn_65555ab2_000058_1bb23e77>
  408a4b:	mov    rcx,r12
  408a4e:	mov    rdx,QWORD PTR [r14]
  408a51:	mov    r8,QWORD PTR [r14+0x8]
  408a55:	mov    r9,QWORD PTR [r14+0x10]
  408a59:	call   40c140 <__swc_fn_65555ab2_000043_d3c2ab54>
  408a5e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  408a63:	test   r14,r14
  408a66:	jne    408a40 <__swc_fn_65555ab2_000072_61e60aab+0x240>
  408a68:	add    rdi,0x1
  408a6c:	sub    rsi,0x1
  408a70:	jne    408a20 <__swc_fn_65555ab2_000072_61e60aab+0x220>
  408a72:	mov    rcx,r12
  408a75:	call   40c8a0 <__swc_fn_65555ab2_000064_ffcd96eb>
  408a7a:	lea    rcx,[r12+0x250]
  408a82:	mov    rdx,QWORD PTR [rcx]
  408a85:	mov    r8,QWORD PTR [r12+0x250]
  408a8d:	nop    DWORD PTR [rax]
  408a90:	mov    r9,r8
  408a93:	sub    r9,rdx
  408a96:	mov    rax,r8
  408a99:	lock cmpxchg QWORD PTR [rcx],r9
  408a9e:	cmp    rax,r8
  408aa1:	je     408aa8 <__swc_fn_65555ab2_000072_61e60aab+0x2a8>
  408aa3:	mov    r8,rax
  408aa6:	jmp    408a90 <__swc_fn_65555ab2_000072_61e60aab+0x290>
  408aa8:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  408ab1:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  408aba:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  408ac3:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  408acc:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  408ad5:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  408ade:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  408ae7:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  408af0:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  408af9:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  408b02:	add    rsp,0x190
  408b09:	pop    r14
  408b0b:	pop    r13
  408b0d:	pop    rsi
  408b0e:	pop    rdi
  408b0f:	pop    r12
  408b11:	ret
	...

0000000000408b20 <__swc_fn_65555ab2_000075_64d36d78>:
  408b20:	sub    rsp,0x8
  408b24:	mov    QWORD PTR [rdx+0x40],0x0
  408b2c:	call   410270 <__swc_fn_65555ab2_000068_f3aa21af>
  408b31:	add    rsp,0x8
  408b35:	ret
	...

0000000000408b40 <__swc_fn_65555ab2_000078_1966ae2e>:
  408b40:	sub    rsp,0x8
  408b44:	call   40c970 <__swc_fn_65555ab2_000070_97813b89>
  408b49:	add    rsp,0x8
  408b4d:	ret
	...

0000000000408b50 <__swc_fn_65555ab2_000081_5cc7acfc>:
  408b50:	push   rbx
  408b51:	push   rsi
  408b52:	push   rdi
  408b53:	push   r12
  408b55:	push   r13
  408b57:	push   r14
  408b59:	push   r15
  408b5b:	sub    rsp,0x20
  408b5f:	mov    rbx,r11
  408b62:	mov    rsi,rcx
  408b65:	mov    rdi,rdx
  408b68:	mov    r12,r8
  408b6b:	mov    r13,r9
  408b6e:	mov    r14,r10
  408b71:	mov    rcx,QWORD PTR [rip+0x1b4c8]        # 424040 <__swc_bss_base_65555ab2>
  408b78:	test   rcx,rcx
  408b7b:	jne    408b8d <__swc_fn_65555ab2_000081_5cc7acfc+0x3d>
  408b7d:	call   40eb80 <__swc_fn_65555ab2_000169_994c8876>
  408b82:	lea    rcx,[rax+0x1]
  408b86:	mov    QWORD PTR [rip+0x1b4b3],rcx        # 424040 <__swc_bss_base_65555ab2>
  408b8d:	dec    rcx
  408b90:	call   40ba40 <__swc_fn_65555ab2_000171_360af05d>
  408b95:	mov    r15,rax
  408b98:	lea    r11,[rip+0x1b6a1]        # 424240 <__swc_bss_base_65555ab2+0x200>
  408b9f:	mov    rcx,r11
  408ba2:	call   40c130 <__swc_fn_65555ab2_000040_eb6108f2>
  408ba7:	test   al,al
  408ba9:	jne    408bba <__swc_fn_65555ab2_000081_5cc7acfc+0x6a>
  408bab:	mov    rcx,r11
  408bae:	call   40f420 <__swc_fn_65555ab2_000038_14f56618>
  408bb3:	lea    r11,[rip+0x1b686]        # 424240 <__swc_bss_base_65555ab2+0x200>
  408bba:	mov    rcx,r11
  408bbd:	mov    rdx,rsi
  408bc0:	mov    r8,rdi
  408bc3:	mov    r9,r12
  408bc6:	mov    r10,r13
  408bc9:	mov    rsi,r11
  408bcc:	mov    r11,r14
  408bcf:	call   407e70 <__swc_fn_65555ab2_000039_03f1bf9a>
  408bd4:	test   bl,bl
  408bd6:	je     408bfd <__swc_fn_65555ab2_000081_5cc7acfc+0xad>
  408bd8:	mov    QWORD PTR [rsp+0x8],rsi
  408bdd:	lea    rax,[rip+0xa894]        # 413478 <__swc_rdata_base_65555ab2+0x368>
  408be4:	mov    QWORD PTR [rsp+0x10],rax
  408be9:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  408bef:	vmovups XMMWORD PTR [r15],xmm0
  408bf4:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  408bfd:	mov    rax,rsi
  408c00:	add    rsp,0x20
  408c04:	pop    r15
  408c06:	pop    r14
  408c08:	pop    r13
  408c0a:	pop    r12
  408c0c:	pop    rdi
  408c0d:	pop    rsi
  408c0e:	pop    rbx
  408c0f:	ret

0000000000408c10 <__swc_fn_65555ab2_000084_cf82995a>:
  408c10:	sub    rsp,0x8
  408c14:	mov    rax,rcx
  408c17:	test   rcx,rcx
  408c1a:	jne    408c21 <__swc_fn_65555ab2_000084_cf82995a+0x11>
  408c1c:	add    rsp,0x8
  408c20:	ret
  408c21:	lea    rcx,[rax-0x10]
  408c25:	mov    rax,QWORD PTR [rax-0x10]
  408c29:	mov    rdx,rax
  408c2c:	call   409c70 <__swc_fn_65555ab2_000117_ed2d8fed>
  408c31:	add    rsp,0x8
  408c35:	ret
	...

0000000000408c40 <__swc_fn_65555ab2_000087_ef55f6e4>:
  408c40:	sub    rsp,0x8
  408c44:	xor    r11d,r11d
  408c47:	call   40cc30 <__swc_fn_65555ab2_000088_0d280354>
  408c4c:	add    rsp,0x8
  408c50:	ret
	...

0000000000408c60 <__swc_fn_65555ab2_000090_23214800>:
  408c60:	push   rsi
  408c61:	push   rdi
  408c62:	push   r12
  408c64:	push   r13
  408c66:	push   r14
  408c68:	push   r15
  408c6a:	sub    rsp,0x68
  408c6e:	mov    rsi,r9
  408c71:	mov    rdi,rcx
  408c74:	mov    r12,rdx
  408c77:	mov    r13,r8
  408c7a:	cmp    r8,r9
  408c7d:	jne    408ca5 <__swc_fn_65555ab2_000090_23214800+0x45>
  408c7f:	mov    rcx,rdi
  408c82:	mov    rdx,r12
  408c85:	xor    r8d,r8d
  408c88:	call   40cf80 <__swc_fn_65555ab2_000094_63c1827b>
  408c8d:	test   al,al
  408c8f:	je     408ca5 <__swc_fn_65555ab2_000090_23214800+0x45>
  408c91:	mov    eax,0x1
  408c96:	add    rsp,0x68
  408c9a:	pop    r15
  408c9c:	pop    r14
  408c9e:	pop    r13
  408ca0:	pop    r12
  408ca2:	pop    rdi
  408ca3:	pop    rsi
  408ca4:	ret
  408ca5:	cmp    BYTE PTR [r12+0x2c],0xe
  408cab:	je     408cbe <__swc_fn_65555ab2_000090_23214800+0x5e>
  408cad:	xor    eax,eax
  408caf:	add    rsp,0x68
  408cb3:	pop    r15
  408cb5:	pop    r14
  408cb7:	pop    r13
  408cb9:	pop    r12
  408cbb:	pop    rdi
  408cbc:	pop    rsi
  408cbd:	ret
  408cbe:	mov    r14,QWORD PTR [r12+0x98]
  408cc6:	mov    rax,QWORD PTR [r12+0xa0]
  408cce:	mov    r12,rax
  408cd1:	xor    r15d,r15d
  408cd4:	test   r12,r12
  408cd7:	je     408d3f <__swc_fn_65555ab2_000090_23214800+0xdf>
  408cd9:	nop    DWORD PTR [rax+0x0]
  408ce0:	mov    QWORD PTR [rsp+0x58],r12
  408ce5:	lea    r12,[r15*8+0x0]
  408ced:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  408cf2:	mov    rcx,rax
  408cf5:	call   410a00 <__swc_fn_65555ab2_000086_3953ef98>
  408cfa:	cmp    BYTE PTR [rax+0x2c],0xe
  408cfe:	jne    408d30 <__swc_fn_65555ab2_000090_23214800+0xd0>
  408d00:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  408d05:	lea    r8,[r13+rcx*1+0x0]
  408d0a:	mov    rcx,rdi
  408d0d:	mov    rdx,rax
  408d10:	mov    r9,rsi
  408d13:	call   408c60 <__swc_fn_65555ab2_000090_23214800>
  408d18:	test   al,al
  408d1a:	je     408d30 <__swc_fn_65555ab2_000090_23214800+0xd0>
  408d1c:	mov    eax,0x1
  408d21:	add    rsp,0x68
  408d25:	pop    r15
  408d27:	pop    r14
  408d29:	pop    r13
  408d2b:	pop    r12
  408d2d:	pop    rdi
  408d2e:	pop    rsi
  408d2f:	ret
  408d30:	add    r15,0x1
  408d34:	mov    r12,QWORD PTR [rsp+0x58]
  408d39:	sub    r12,0x1
  408d3d:	jne    408ce0 <__swc_fn_65555ab2_000090_23214800+0x80>
  408d3f:	xor    eax,eax
  408d41:	add    rsp,0x68
  408d45:	pop    r15
  408d47:	pop    r14
  408d49:	pop    r13
  408d4b:	pop    r12
  408d4d:	pop    rdi
  408d4e:	pop    rsi
  408d4f:	ret

0000000000408d50 <__swc_fn_65555ab2_000093_c2567a3b>:
  408d50:	push   rbp
  408d51:	push   rbx
  408d52:	push   rsi
  408d53:	push   rdi
  408d54:	push   r12
  408d56:	push   r13
  408d58:	push   r14
  408d5a:	push   r15
  408d5c:	sub    rsp,0x38
  408d60:	mov    rbp,rsp
  408d63:	mov    rbx,r11
  408d66:	mov    rsi,rdx
  408d69:	mov    rdi,r8
  408d6c:	mov    r12,r9
  408d6f:	mov    QWORD PTR [rsp+0x18],r9
  408d74:	mov    r13,r10
  408d77:	movzx  r14d,BYTE PTR [rbp+0x80]
  408d7f:	movzx  r15d,BYTE PTR [rbp+0x88]
  408d87:	test   r11,r11
  408d8a:	je     408d90 <__swc_fn_65555ab2_000093_c2567a3b+0x40>
  408d8c:	xor    eax,eax
  408d8e:	mov    BYTE PTR [rbx],al
  408d90:	test   r12,r12
  408d93:	je     408d9e <__swc_fn_65555ab2_000093_c2567a3b+0x4e>
  408d95:	mov    QWORD PTR [r12+0x8],0x0
  408d9e:	test   rcx,rcx
  408da1:	je     408da8 <__swc_fn_65555ab2_000093_c2567a3b+0x58>
  408da3:	test   rsi,rsi
  408da6:	jne    408dbb <__swc_fn_65555ab2_000093_c2567a3b+0x6b>
  408da8:	xor    eax,eax
  408daa:	add    rsp,0x38
  408dae:	pop    r15
  408db0:	pop    r14
  408db2:	pop    r13
  408db4:	pop    r12
  408db6:	pop    rdi
  408db7:	pop    rsi
  408db8:	pop    rbx
  408db9:	pop    rbp
  408dba:	ret
  408dbb:	call   410a00 <__swc_fn_65555ab2_000086_3953ef98>
  408dc0:	mov    r12,rax
  408dc3:	mov    al,r15b
  408dc6:	test   r15b,r15b
  408dc9:	jne    408dd9 <__swc_fn_65555ab2_000093_c2567a3b+0x89>
  408dcb:	mov    eax,DWORD PTR [r12+0x28]
  408dd0:	and    eax,0x10000
  408dd6:	setne  al
  408dd9:	lea    r15,[rsp+0x8]
  408dde:	mov    QWORD PTR [rsp+0x20],r15
  408de3:	rex mov BYTE PTR [rsp+0x8],al
  408de8:	test   DWORD PTR [rsi+0x28],0x400000
  408def:	je     408e27 <__swc_fn_65555ab2_000093_c2567a3b+0xd7>
  408df1:	test   rsi,rsi
  408df4:	je     408e14 <__swc_fn_65555ab2_000093_c2567a3b+0xc4>
  408df6:	mov    rax,QWORD PTR [rsi+0x38]
  408dfa:	cmp    QWORD PTR [rax+0x10],rsi
  408dfe:	jne    408e14 <__swc_fn_65555ab2_000093_c2567a3b+0xc4>
  408e00:	rex mov al,BYTE PTR [rsp+0x8]
  408e05:	test   al,al
  408e07:	sete   al
  408e0a:	test   r14b,r14b
  408e0d:	sete   cl
  408e10:	test   al,cl
  408e12:	je     408e27 <__swc_fn_65555ab2_000093_c2567a3b+0xd7>
  408e14:	xor    eax,eax
  408e16:	add    rsp,0x38
  408e1a:	pop    r15
  408e1c:	pop    r14
  408e1e:	pop    r13
  408e20:	pop    r12
  408e22:	pop    rdi
  408e23:	pop    rsi
  408e24:	pop    rbx
  408e25:	pop    rbp
  408e26:	ret
  408e27:	mov    r15,r12
  408e2a:	test   r14b,r14b
  408e2d:	jne    408e44 <__swc_fn_65555ab2_000093_c2567a3b+0xf4>
  408e2f:	cmp    BYTE PTR [r12+0x2c],0x6
  408e35:	jne    408e44 <__swc_fn_65555ab2_000093_c2567a3b+0xf4>
  408e37:	mov    rcx,QWORD PTR [r12+0x40]
  408e3c:	call   410a00 <__swc_fn_65555ab2_000086_3953ef98>
  408e41:	mov    r15,rax
  408e44:	test   r14b,r14b
  408e47:	je     408e4d <__swc_fn_65555ab2_000093_c2567a3b+0xfd>
  408e49:	mov    r15,QWORD PTR [r15+0x30]
  408e4d:	mov    rcx,rsi
  408e50:	call   410a00 <__swc_fn_65555ab2_000086_3953ef98>
  408e55:	mov    rsi,rax
  408e58:	rex cmp BYTE PTR [rsi+0x2c],0x6
  408e5d:	je     408e94 <__swc_fn_65555ab2_000093_c2567a3b+0x144>
  408e5f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  408e64:	je     408e94 <__swc_fn_65555ab2_000093_c2567a3b+0x144>
  408e66:	mov    eax,DWORD PTR [rsi+0x28]
  408e69:	and    eax,0x10000
  408e6f:	je     408e94 <__swc_fn_65555ab2_000093_c2567a3b+0x144>
  408e71:	rex mov al,BYTE PTR [rsp+0x8]
  408e76:	test   al,al
  408e78:	jne    408e8d <__swc_fn_65555ab2_000093_c2567a3b+0x13d>
  408e7a:	xor    eax,eax
  408e7c:	add    rsp,0x38
  408e80:	pop    r15
  408e82:	pop    r14
  408e84:	pop    r13
  408e86:	pop    r12
  408e88:	pop    rdi
  408e89:	pop    rsi
  408e8a:	pop    rbx
  408e8b:	pop    rbp
  408e8c:	ret
  408e8d:	mov    rax,QWORD PTR [rsi+0x30]
  408e91:	mov    rsi,rax
  408e94:	mov    r14b,r13b
  408e97:	test   rbx,rbx
  408e9a:	je     408ed0 <__swc_fn_65555ab2_000093_c2567a3b+0x180>
  408e9c:	cmp    BYTE PTR [r12+0x2c],0x6
  408ea2:	jne    408ed0 <__swc_fn_65555ab2_000093_c2567a3b+0x180>
  408ea4:	lea    rdx,[rip+0xa5fd]        # 4134a8 <__swc_rdata_base_65555ab2+0x398>
  408eab:	mov    rcx,rsi
  408eae:	xor    r8d,r8d
  408eb1:	call   40cf80 <__swc_fn_65555ab2_000094_63c1827b>
  408eb6:	test   al,al
  408eb8:	je     408ed0 <__swc_fn_65555ab2_000093_c2567a3b+0x180>
  408eba:	mov    BYTE PTR [rbx],0x1
  408ebd:	xor    eax,eax
  408ebf:	add    rsp,0x38
  408ec3:	pop    r15
  408ec5:	pop    r14
  408ec7:	pop    r13
  408ec9:	pop    r12
  408ecb:	pop    rdi
  408ecc:	pop    rsi
  408ecd:	pop    rbx
  408ece:	pop    rbp
  408ecf:	ret
  408ed0:	test   rdi,rdi
  408ed3:	jne    408eed <__swc_fn_65555ab2_000093_c2567a3b+0x19d>
  408ed5:	test   r13b,r13b
  408ed8:	jne    408eed <__swc_fn_65555ab2_000093_c2567a3b+0x19d>
  408eda:	xor    eax,eax
  408edc:	add    rsp,0x38
  408ee0:	pop    r15
  408ee2:	pop    r14
  408ee4:	pop    r13
  408ee6:	pop    r12
  408ee8:	pop    rdi
  408ee9:	pop    rsi
  408eea:	pop    rbx
  408eeb:	pop    rbp
  408eec:	ret
  408eed:	rex cmp BYTE PTR [rsi+0x2c],0x6
  408ef2:	jne    408fa8 <__swc_fn_65555ab2_000093_c2567a3b+0x258>
  408ef8:	mov    rcx,r15
  408efb:	mov    rdx,rsi
  408efe:	xor    r8d,r8d
  408f01:	call   40cf80 <__swc_fn_65555ab2_000094_63c1827b>
  408f06:	test   al,al
  408f08:	jne    408fa8 <__swc_fn_65555ab2_000093_c2567a3b+0x258>
  408f0e:	test   DWORD PTR [rsi+0x28],0x10000
  408f15:	je     408f33 <__swc_fn_65555ab2_000093_c2567a3b+0x1e3>
  408f17:	rex mov al,BYTE PTR [rsp+0x8]
  408f1c:	test   al,al
  408f1e:	jne    408f33 <__swc_fn_65555ab2_000093_c2567a3b+0x1e3>
  408f20:	xor    eax,eax
  408f22:	add    rsp,0x38
  408f26:	pop    r15
  408f28:	pop    r14
  408f2a:	pop    r13
  408f2c:	pop    r12
  408f2e:	pop    rdi
  408f2f:	pop    rsi
  408f30:	pop    rbx
  408f31:	pop    rbp
  408f32:	ret
  408f33:	test   rdi,rdi
  408f36:	jne    408f4b <__swc_fn_65555ab2_000093_c2567a3b+0x1fb>
  408f38:	xor    eax,eax
  408f3a:	add    rsp,0x38
  408f3e:	pop    r15
  408f40:	pop    r14
  408f42:	pop    r13
  408f44:	pop    r12
  408f46:	pop    rdi
  408f47:	pop    rsi
  408f48:	pop    rbx
  408f49:	pop    rbp
  408f4a:	ret
  408f4b:	mov    rcx,QWORD PTR [rsi+0x40]
  408f4f:	call   410a00 <__swc_fn_65555ab2_000086_3953ef98>
  408f54:	mov    rsi,rax
  408f57:	mov    rax,QWORD PTR [rdi]
  408f5a:	mov    rdi,rax
  408f5d:	test   rax,rax
  408f60:	jne    408fa3 <__swc_fn_65555ab2_000093_c2567a3b+0x253>
  408f62:	test   rbx,rbx
  408f65:	je     408fa3 <__swc_fn_65555ab2_000093_c2567a3b+0x253>
  408f67:	mov    rcx,r15
  408f6a:	mov    rdx,rsi
  408f6d:	xor    r8d,r8d
  408f70:	call   40cf80 <__swc_fn_65555ab2_000094_63c1827b>
  408f75:	mov    rcx,rax
  408f78:	test   al,al
  408f7a:	jne    408f9c <__swc_fn_65555ab2_000093_c2567a3b+0x24c>
  408f7c:	mov    rcx,r15
  408f7f:	mov    rdx,rsi
  408f82:	call   410a40 <__swc_fn_65555ab2_000089_d182c4dc>
  408f87:	mov    rcx,rax
  408f8a:	test   al,al
  408f8c:	jne    408f9c <__swc_fn_65555ab2_000093_c2567a3b+0x24c>
  408f8e:	mov    rcx,rsi
  408f91:	mov    rdx,r15
  408f94:	call   410a40 <__swc_fn_65555ab2_000089_d182c4dc>
  408f99:	mov    rcx,rax
  408f9c:	test   cl,cl
  408f9e:	setne  al
  408fa1:	mov    BYTE PTR [rbx],al
  408fa3:	xor    eax,eax
  408fa5:	mov    r14b,al
  408fa8:	test   rdi,rdi
  408fab:	jne    408fc5 <__swc_fn_65555ab2_000093_c2567a3b+0x275>
  408fad:	test   r14b,r14b
  408fb0:	jne    408fc5 <__swc_fn_65555ab2_000093_c2567a3b+0x275>
  408fb2:	xor    eax,eax
  408fb4:	add    rsp,0x38
  408fb8:	pop    r15
  408fba:	pop    r14
  408fbc:	pop    r13
  408fbe:	pop    r12
  408fc0:	pop    rdi
  408fc1:	pop    rsi
  408fc2:	pop    rbx
  408fc3:	pop    rbp
  408fc4:	ret
  408fc5:	rex cmp BYTE PTR [rsi+0x2c],0x12
  408fca:	je     408fd6 <__swc_fn_65555ab2_000093_c2567a3b+0x286>
  408fcc:	mov    r12,QWORD PTR [rsp+0x18]
  408fd1:	jmp    40905e <__swc_fn_65555ab2_000093_c2567a3b+0x30e>
  408fd6:	mov    r12,QWORD PTR [rsp+0x18]
  408fdb:	test   r12,r12
  408fde:	jne    408ff2 <__swc_fn_65555ab2_000093_c2567a3b+0x2a2>
  408fe0:	mov    rcx,r15
  408fe3:	mov    rdx,rsi
  408fe6:	xor    r8d,r8d
  408fe9:	call   40cf80 <__swc_fn_65555ab2_000094_63c1827b>
  408fee:	test   al,al
  408ff0:	jne    40905e <__swc_fn_65555ab2_000093_c2567a3b+0x30e>
  408ff2:	test   DWORD PTR [rsi+0x28],0x10000
  408ff9:	je     409017 <__swc_fn_65555ab2_000093_c2567a3b+0x2c7>
  408ffb:	rex mov al,BYTE PTR [rsp+0x8]
  409000:	test   al,al
  409002:	jne    409017 <__swc_fn_65555ab2_000093_c2567a3b+0x2c7>
  409004:	xor    eax,eax
  409006:	add    rsp,0x38
  40900a:	pop    r15
  40900c:	pop    r14
  40900e:	pop    r13
  409010:	pop    r12
  409012:	pop    rdi
  409013:	pop    rsi
  409014:	pop    rbx
  409015:	pop    rbp
  409016:	ret
  409017:	test   rdi,rdi
  40901a:	jne    40902f <__swc_fn_65555ab2_000093_c2567a3b+0x2df>
  40901c:	xor    eax,eax
  40901e:	add    rsp,0x38
  409022:	pop    r15
  409024:	pop    r14
  409026:	pop    r13
  409028:	pop    r12
  40902a:	pop    rdi
  40902b:	pop    rsi
  40902c:	pop    rbx
  40902d:	pop    rbp
  40902e:	ret
  40902f:	cmp    QWORD PTR [rdi+0x8],0x0
  409034:	jne    409049 <__swc_fn_65555ab2_000093_c2567a3b+0x2f9>
  409036:	xor    eax,eax
  409038:	add    rsp,0x38
  40903c:	pop    r15
  40903e:	pop    r14
  409040:	pop    r13
  409042:	pop    r12
  409044:	pop    rdi
  409045:	pop    rsi
  409046:	pop    rbx
  409047:	pop    rbp
  409048:	ret
  409049:	mov    rax,QWORD PTR [rdi+0x8]
  40904d:	mov    rax,QWORD PTR [rax]
  409050:	mov    rsi,rax
  409053:	mov    rdi,QWORD PTR [rdi]
  409056:	mov    eax,0x1
  40905b:	mov    r14b,al
  40905e:	test   rdi,rdi
  409061:	mov    rbx,QWORD PTR [rsp+0x20]
  409066:	jne    4090b0 <__swc_fn_65555ab2_000093_c2567a3b+0x360>
  409068:	test   r14b,r14b
  40906b:	je     40909d <__swc_fn_65555ab2_000093_c2567a3b+0x34d>
  40906d:	test   r12,r12
  409070:	je     40909d <__swc_fn_65555ab2_000093_c2567a3b+0x34d>
  409072:	mov    rcx,r15
  409075:	mov    rdx,rsi
  409078:	xor    r8d,r8d
  40907b:	mov    r9,r12
  40907e:	mov    rbx,QWORD PTR [rsp+0x20]
  409083:	movzx  r10d,BYTE PTR [rbx]
  409087:	call   408c40 <__swc_fn_65555ab2_000087_ef55f6e4>
  40908c:	add    rsp,0x38
  409090:	pop    r15
  409092:	pop    r14
  409094:	pop    r13
  409096:	pop    r12
  409098:	pop    rdi
  409099:	pop    rsi
  40909a:	pop    rbx
  40909b:	pop    rbp
  40909c:	ret
  40909d:	xor    eax,eax
  40909f:	add    rsp,0x38
  4090a3:	pop    r15
  4090a5:	pop    r14
  4090a7:	pop    r13
  4090a9:	pop    r12
  4090ab:	pop    rdi
  4090ac:	pop    rsi
  4090ad:	pop    rbx
  4090ae:	pop    rbp
  4090af:	ret
  4090b0:	mov    r13,rsi
  4090b3:	mov    QWORD PTR [rsp+0x28],rdi
  4090b8:	cmp    BYTE PTR [r15+0x2c],0xe
  4090bd:	sete   al
  4090c0:	mov    r14b,al
  4090c3:	jne    4090d7 <__swc_fn_65555ab2_000093_c2567a3b+0x387>
  4090c5:	mov    rcx,rsi
  4090c8:	mov    rdx,r15
  4090cb:	call   410a40 <__swc_fn_65555ab2_000089_d182c4dc>
  4090d0:	mov    r14b,al
  4090d3:	test   al,al
  4090d5:	jne    40910c <__swc_fn_65555ab2_000093_c2567a3b+0x3bc>
  4090d7:	cmp    BYTE PTR [r15+0x2c],0x12
  4090dc:	je     40910c <__swc_fn_65555ab2_000093_c2567a3b+0x3bc>
  4090de:	mov    rcx,r15
  4090e1:	mov    rdx,rsi
  4090e4:	mov    r8,rdi
  4090e7:	mov    r9,r12
  4090ea:	mov    rax,rbx
  4090ed:	movzx  r10d,BYTE PTR [rax]
  4090f1:	call   408c40 <__swc_fn_65555ab2_000087_ef55f6e4>
  4090f6:	test   rax,rax
  4090f9:	je     40910c <__swc_fn_65555ab2_000093_c2567a3b+0x3bc>
  4090fb:	add    rsp,0x38
  4090ff:	pop    r15
  409101:	pop    r14
  409103:	pop    r13
  409105:	pop    r12
  409107:	pop    rdi
  409108:	pop    rsi
  409109:	pop    rbx
  40910a:	pop    rbp
  40910b:	ret
  40910c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  409111:	jne    409130 <__swc_fn_65555ab2_000093_c2567a3b+0x3e0>
  409113:	mov    rax,QWORD PTR [rsi+0xd8]
  40911a:	test   rax,rax
  40911d:	je     409130 <__swc_fn_65555ab2_000093_c2567a3b+0x3e0>
  40911f:	add    rdi,QWORD PTR [rax+0x8]
  409123:	mov    rax,QWORD PTR [rdi]
  409126:	sub    rdi,QWORD PTR [rax+0x8]
  40912a:	mov    rax,QWORD PTR [rax]
  40912d:	mov    rsi,rax
  409130:	test   r14b,r14b
  409133:	je     40915f <__swc_fn_65555ab2_000093_c2567a3b+0x40f>
  409135:	mov    rcx,r15
  409138:	mov    rdx,rsi
  40913b:	mov    r8,rdi
  40913e:	mov    r9,r13
  409141:	mov    r14,QWORD PTR [rsp+0x28]
  409146:	mov    r10,r14
  409149:	call   40ce60 <__swc_fn_65555ab2_000091_c1c9085b>
  40914e:	add    rsp,0x38
  409152:	pop    r15
  409154:	pop    r14
  409156:	pop    r13
  409158:	pop    r12
  40915a:	pop    rdi
  40915b:	pop    rsi
  40915c:	pop    rbx
  40915d:	pop    rbp
  40915e:	ret
  40915f:	mov    rcx,r15
  409162:	mov    rdx,rsi
  409165:	mov    r8,rdi
  409168:	mov    r9,r12
  40916b:	movzx  r10d,BYTE PTR [rbx]
  40916f:	call   408c40 <__swc_fn_65555ab2_000087_ef55f6e4>
  409174:	add    rsp,0x38
  409178:	pop    r15
  40917a:	pop    r14
  40917c:	pop    r13
  40917e:	pop    r12
  409180:	pop    rdi
  409181:	pop    rsi
  409182:	pop    rbx
  409183:	pop    rbp
  409184:	ret
	...

0000000000409190 <__swc_fn_65555ab2_000096_93bfe675>:
  409190:	push   rbx
  409191:	push   rsi
  409192:	sub    rsp,0x18
  409196:	mov    rbx,rcx
  409199:	mov    rcx,QWORD PTR [rip+0x1aea0]        # 424040 <__swc_bss_base_65555ab2>
  4091a0:	test   rcx,rcx
  4091a3:	jne    4091b5 <__swc_fn_65555ab2_000096_93bfe675+0x25>
  4091a5:	call   40eb80 <__swc_fn_65555ab2_000169_994c8876>
  4091aa:	lea    rcx,[rax+0x1]
  4091ae:	mov    QWORD PTR [rip+0x1ae8b],rcx        # 424040 <__swc_bss_base_65555ab2>
  4091b5:	dec    rcx
  4091b8:	call   40ba40 <__swc_fn_65555ab2_000171_360af05d>
  4091bd:	mov    rsi,rax
  4091c0:	mov    rax,QWORD PTR [rsi+0x8]
  4091c4:	test   rax,rax
  4091c7:	jne    409217 <__swc_fn_65555ab2_000096_93bfe675+0x87>
  4091c9:	call   410b30 <__swc_fn_65555ab2_000095_ad13d15c>
  4091ce:	test   al,al
  4091d0:	jne    409217 <__swc_fn_65555ab2_000096_93bfe675+0x87>
  4091d2:	lea    rdx,[rip+0x1b067]        # 424240 <__swc_bss_base_65555ab2+0x200>
  4091d9:	mov    rcx,rdx
  4091dc:	call   40c130 <__swc_fn_65555ab2_000040_eb6108f2>
  4091e1:	test   al,al
  4091e3:	jne    4091f4 <__swc_fn_65555ab2_000096_93bfe675+0x64>
  4091e5:	mov    rcx,rdx
  4091e8:	call   40f420 <__swc_fn_65555ab2_000038_14f56618>
  4091ed:	lea    rdx,[rip+0x1b04c]        # 424240 <__swc_bss_base_65555ab2+0x200>
  4091f4:	mov    QWORD PTR [rsp+0x8],rdx
  4091f9:	lea    rax,[rip+0xa278]        # 413478 <__swc_rdata_base_65555ab2+0x368>
  409200:	mov    QWORD PTR [rsp+0x10],rax
  409205:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40920b:	vmovups XMMWORD PTR [rsi],xmm0
  40920f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  409217:	vmovups xmm0,XMMWORD PTR [rsi]
  40921b:	vmovups XMMWORD PTR [rbx],xmm0
  40921f:	mov    rax,rbx
  409222:	add    rsp,0x18
  409226:	pop    rsi
  409227:	pop    rbx
  409228:	ret
  409229:	add    BYTE PTR [rax],al
  40922b:	add    BYTE PTR [rax],al
  40922d:	add    BYTE PTR [rax],al
	...

0000000000409230 <__swc_fn_65555ab2_000099_65137b72>:
  409230:	sub    rsp,0x8
  409234:	call   40dd20 <__swc_fn_65555ab2_000121_0a5fa85a>
  409239:	add    rsp,0x8
  40923d:	ret
	...

0000000000409240 <__swc_fn_65555ab2_000102_e34f54dc>:
  409240:	push   rbx
  409241:	push   rsi
  409242:	sub    rsp,0x28
  409246:	mov    rbx,rcx
  409249:	xor    esi,esi
  40924b:	jmp    409260 <__swc_fn_65555ab2_000102_e34f54dc+0x20>
  40924d:	nop    DWORD PTR [rax]
  409250:	mov    QWORD PTR [rbx+0x28],rsi
  409254:	mov    rsi,rbx
  409257:	mov    rbx,rax
  40925a:	nop    WORD PTR [rax+rax*1+0x0]
  409260:	test   rbx,rbx
  409263:	je     4092c3 <__swc_fn_65555ab2_000102_e34f54dc+0x83>
  409265:	mov    rcx,rbx
  409268:	mov    edx,0x1
  40926d:	call   40cbe0 <__swc_fn_65555ab2_000082_63a67586>
  409272:	cmp    rax,0x1
  409276:	jne    4092c3 <__swc_fn_65555ab2_000102_e34f54dc+0x83>
  409278:	mov    r10,QWORD PTR [rbx+0x18]
  40927c:	mov    rcx,r10
  40927f:	mov    edx,0x1
  409284:	call   40cbe0 <__swc_fn_65555ab2_000082_63a67586>
  409289:	cmp    rax,0x1
  40928d:	jne    40929c <__swc_fn_65555ab2_000102_e34f54dc+0x5c>
  40928f:	mov    rcx,r10
  409292:	call   410cd0 <__swc_fn_65555ab2_000101_d0b19c14>
  409297:	test   rax,rax
  40929a:	jne    409250 <__swc_fn_65555ab2_000102_e34f54dc+0x10>
  40929c:	mov    rax,QWORD PTR [rbx+0x20]
  4092a0:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4092a5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4092ab:	lea    rcx,[rsp+0x8]
  4092b0:	mov    rdx,rbx
  4092b3:	mov    r8d,0x30
  4092b9:	mov    rbx,rax
  4092bc:	call   40d340 <__swc_fn_65555ab2_000100_d4bdcaa4>
  4092c1:	jmp    409260 <__swc_fn_65555ab2_000102_e34f54dc+0x20>
  4092c3:	test   rsi,rsi
  4092c6:	jne    4092cf <__swc_fn_65555ab2_000102_e34f54dc+0x8f>
  4092c8:	add    rsp,0x28
  4092cc:	pop    rsi
  4092cd:	pop    rbx
  4092ce:	ret
  4092cf:	mov    rax,rsi
  4092d2:	mov    rsi,QWORD PTR [rsi+0x28]
  4092d6:	mov    rbx,QWORD PTR [rax+0x20]
  4092da:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  4092df:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4092e5:	lea    rcx,[rsp+0x18]
  4092ea:	mov    rdx,rax
  4092ed:	mov    r8d,0x30
  4092f3:	call   40d340 <__swc_fn_65555ab2_000100_d4bdcaa4>
  4092f8:	jmp    409260 <__swc_fn_65555ab2_000102_e34f54dc+0x20>
  4092fd:	add    BYTE PTR [rax],al
	...

0000000000409300 <__swc_fn_65555ab2_000105_5a85fcf5>:
  409300:	push   rbx
  409301:	push   rsi
  409302:	push   rdi
  409303:	push   r12
  409305:	push   r13
  409307:	sub    rsp,0x20
  40930b:	mov    rbx,rcx
  40930e:	lea    rsi,[rcx+0x6f8]
  409315:	mov    edi,0x4
  40931a:	mov    r12,rsi
  40931d:	test   rdi,rdi
  409320:	je     40936a <__swc_fn_65555ab2_000105_5a85fcf5+0x6a>
  409322:	cs nop WORD PTR [rax+rax*1+0x0]
  40932c:	nop    DWORD PTR [rax+0x0]
  409330:	mov    rcx,QWORD PTR [r12+0x10]
  409335:	mov    QWORD PTR [r12+0x10],0x0
  40933e:	vxorps xmm0,xmm0,xmm0
  409342:	vmovups XMMWORD PTR [r12],xmm0
  409348:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40934f:	mov    DWORD PTR [r12+0x20],0x0
  409358:	call   40d390 <__swc_fn_65555ab2_000103_2fdd2c61>
  40935d:	add    r12,0x90
  409364:	sub    rdi,0x1
  409368:	jne    409330 <__swc_fn_65555ab2_000105_5a85fcf5+0x30>
  40936a:	mov    rax,QWORD PTR [rbx+0x938]
  409371:	mov    rdi,rax
  409374:	test   rdi,rdi
  409377:	je     4093d1 <__swc_fn_65555ab2_000105_5a85fcf5+0xd1>
  409379:	nop    DWORD PTR [rax+0x0]
  409380:	mov    r12d,0x10
  409386:	lea    r13,[rdi+0x18]
  40938a:	test   r12,r12
  40938d:	je     4093c6 <__swc_fn_65555ab2_000105_5a85fcf5+0xc6>
  40938f:	nop
  409390:	mov    rcx,QWORD PTR [r13+0x10]
  409394:	mov    QWORD PTR [r13+0x10],0x0
  40939c:	vxorps xmm0,xmm0,xmm0
  4093a0:	vmovups XMMWORD PTR [r13+0x0],xmm0
  4093a6:	vmovups XMMWORD PTR [r13+0x28],xmm0
  4093ac:	mov    DWORD PTR [r13+0x20],0x0
  4093b4:	call   40d390 <__swc_fn_65555ab2_000103_2fdd2c61>
  4093b9:	add    r13,0x90
  4093c0:	sub    r12,0x1
  4093c4:	jne    409390 <__swc_fn_65555ab2_000105_5a85fcf5+0x90>
  4093c6:	mov    rax,QWORD PTR [rdi]
  4093c9:	mov    rdi,rax
  4093cc:	test   rax,rax
  4093cf:	jne    409380 <__swc_fn_65555ab2_000105_5a85fcf5+0x80>
  4093d1:	vxorps xmm0,xmm0,xmm0
  4093d5:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  4093dd:	mov    DWORD PTR [rbx+0x9b0],0x0
  4093e7:	mov    DWORD PTR [rbx+0x9a8],0x0
  4093f1:	mov    edi,0x4
  4093f6:	mov    r12,rsi
  4093f9:	lea    rsi,[rsi+0x38]
  4093fd:	test   rdi,rdi
  409400:	je     40942c <__swc_fn_65555ab2_000105_5a85fcf5+0x12c>
  409402:	cs nop WORD PTR [rax+rax*1+0x0]
  40940c:	nop    DWORD PTR [rax+0x0]
  409410:	mov    rcx,rsi
  409413:	call   411b50 <__swc_fn_65555ab2_000161_13ead2ff>
  409418:	add    rsi,0x90
  40941f:	add    r12,0x90
  409426:	sub    rdi,0x1
  40942a:	jne    409410 <__swc_fn_65555ab2_000105_5a85fcf5+0x110>
  40942c:	mov    rax,QWORD PTR [rbx+0x938]
  409433:	mov    rdi,rax
  409436:	mov    QWORD PTR [rbx+0x938],0x0
  409441:	test   rdi,rdi
  409444:	je     4094b5 <__swc_fn_65555ab2_000105_5a85fcf5+0x1b5>
  40944a:	nop    WORD PTR [rax+rax*1+0x0]
  409450:	mov    esi,0x10
  409455:	lea    r12,[rdi+0x18]
  409459:	lea    r13,[rdi+0x50]
  40945d:	test   rsi,rsi
  409460:	je     40948c <__swc_fn_65555ab2_000105_5a85fcf5+0x18c>
  409462:	cs nop WORD PTR [rax+rax*1+0x0]
  40946c:	nop    DWORD PTR [rax+0x0]
  409470:	mov    rcx,r13
  409473:	call   411b50 <__swc_fn_65555ab2_000161_13ead2ff>
  409478:	add    r13,0x90
  40947f:	add    r12,0x90
  409486:	sub    rsi,0x1
  40948a:	jne    409470 <__swc_fn_65555ab2_000105_5a85fcf5+0x170>
  40948c:	mov    rax,QWORD PTR [rdi]
  40948f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  409494:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40949a:	lea    rcx,[rsp+0x8]
  40949f:	mov    rdx,rdi
  4094a2:	mov    r8d,0x918
  4094a8:	mov    rdi,rax
  4094ab:	call   40d340 <__swc_fn_65555ab2_000100_d4bdcaa4>
  4094b0:	test   rdi,rdi
  4094b3:	jne    409450 <__swc_fn_65555ab2_000105_5a85fcf5+0x150>
  4094b5:	lea    rcx,[rbx+0x68]
  4094b9:	call   411b50 <__swc_fn_65555ab2_000161_13ead2ff>
  4094be:	add    rsp,0x20
  4094c2:	pop    r13
  4094c4:	pop    r12
  4094c6:	pop    rdi
  4094c7:	pop    rsi
  4094c8:	pop    rbx
  4094c9:	ret
  4094ca:	add    BYTE PTR [rax],al
  4094cc:	add    BYTE PTR [rax],al
	...

00000000004094d0 <__swc_fn_65555ab2_000108_c51c3158>:
  4094d0:	xor    eax,eax
  4094d2:	cs nop WORD PTR [rax+rax*1+0x0]
  4094dc:	nop    DWORD PTR [rax+0x0]
  4094e0:	mov    r9,r8
  4094e3:	sub    r9,rax
  4094e6:	cmp    r9,0x40
  4094ea:	jb     409528 <__swc_fn_65555ab2_000108_c51c3158+0x58>
  4094ec:	lea    r9,[rcx+rax*1]
  4094f0:	lea    r10,[rdx+rax*1]
  4094f4:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  4094fa:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  409500:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  409506:	vmovups xmm3,XMMWORD PTR [r10]
  40950b:	vmovups XMMWORD PTR [r9],xmm3
  409510:	vmovups XMMWORD PTR [r9+0x10],xmm0
  409516:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40951c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  409522:	lea    rax,[rax+0x40]
  409526:	jmp    4094e0 <__swc_fn_65555ab2_000108_c51c3158+0x10>
  409528:	nop    DWORD PTR [rax+rax*1+0x0]
  409530:	mov    r9,r8
  409533:	sub    r9,rax
  409536:	cmp    r9,0x10
  40953a:	jb     409554 <__swc_fn_65555ab2_000108_c51c3158+0x84>
  40953c:	lea    r9,[rdx+rax*1]
  409540:	lea    r10,[rcx+rax*1]
  409544:	vmovups xmm0,XMMWORD PTR [r9]
  409549:	vmovups XMMWORD PTR [r10],xmm0
  40954e:	lea    rax,[rax+0x10]
  409552:	jmp    409530 <__swc_fn_65555ab2_000108_c51c3158+0x60>
  409554:	cs nop WORD PTR [rax+rax*1+0x0]
  40955e:	xchg   ax,ax
  409560:	mov    r9,r8
  409563:	sub    r9,rax
  409566:	cmp    r9,0x8
  40956a:	jb     40957d <__swc_fn_65555ab2_000108_c51c3158+0xad>
  40956c:	lea    r9,[rcx+rax*1]
  409570:	mov    r10,QWORD PTR [rdx+rax*1]
  409574:	mov    QWORD PTR [r9],r10
  409577:	lea    rax,[rax+0x8]
  40957b:	jmp    409560 <__swc_fn_65555ab2_000108_c51c3158+0x90>
  40957d:	cmp    rax,r8
  409580:	jae    4095a0 <__swc_fn_65555ab2_000108_c51c3158+0xd0>
  409582:	cs nop WORD PTR [rax+rax*1+0x0]
  40958c:	nop    DWORD PTR [rax+0x0]
  409590:	mov    r9b,BYTE PTR [rdx+rax*1]
  409594:	mov    BYTE PTR [rcx+rax*1],r9b
  409598:	inc    rax
  40959b:	cmp    rax,r8
  40959e:	jb     409590 <__swc_fn_65555ab2_000108_c51c3158+0xc0>
  4095a0:	ret
	...

00000000004095b0 <__swc_fn_65555ab2_000111_6814119b>:
  4095b0:	push   rbx
  4095b1:	push   r12
  4095b3:	push   rdi
  4095b4:	push   rsi
  4095b5:	push   r13
  4095b7:	push   r14
  4095b9:	push   r15
  4095bb:	sub    rsp,0x170
  4095c2:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  4095cb:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  4095d4:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  4095dd:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  4095e6:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  4095ef:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  4095f8:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  409601:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40960a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  409613:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40961c:	mov    ebx,edx
  40961e:	mov    QWORD PTR [rsp+0xa8],rbx
  409626:	mov    r12d,ecx
  409629:	test   edx,edx
  40962b:	jne    409642 <__swc_fn_65555ab2_000111_6814119b+0x92>
  40962d:	xor    eax,eax
  40962f:	add    rsp,0x170
  409636:	pop    r15
  409638:	pop    r14
  40963a:	pop    r13
  40963c:	pop    rsi
  40963d:	pop    rdi
  40963e:	pop    r12
  409640:	pop    rbx
  409641:	ret
  409642:	lea    rdi,[rip+0xa137]        # 413780 <__swc_rdata_base_65555ab2+0x670>
  409649:	mov    esi,0x90000
  40964e:	xor    eax,eax
  409650:	call   407010 <open@plt>
  409655:	mov    r13,rax
  409658:	mov    QWORD PTR [rsp+0xb0],rax
  409660:	test   eax,eax
  409662:	jge    40966b <__swc_fn_65555ab2_000111_6814119b+0xbb>
  409664:	xor    eax,eax
  409666:	jmp    409b66 <__swc_fn_65555ab2_000111_6814119b+0x5b6>
  40966b:	nop    DWORD PTR [rax+rax*1+0x0]
  409670:	movsxd rdi,r13d
  409673:	mov    esi,0x2
  409678:	xor    eax,eax
  40967a:	call   407020 <flock@plt>
  40967f:	test   eax,eax
  409681:	je     4096a0 <__swc_fn_65555ab2_000111_6814119b+0xf0>
  409683:	xor    eax,eax
  409685:	call   407030 <__errno_location@plt>
  40968a:	cmp    DWORD PTR [rax],0x4
  40968d:	je     409670 <__swc_fn_65555ab2_000111_6814119b+0xc0>
  40968f:	movsxd rdi,r13d
  409692:	xor    eax,eax
  409694:	call   407040 <close@plt>
  409699:	xor    eax,eax
  40969b:	jmp    409b66 <__swc_fn_65555ab2_000111_6814119b+0x5b6>
  4096a0:	lea    r14,[rsp+0x8]
  4096a5:	mov    QWORD PTR [rsp+0xb8],r14
  4096ad:	vxorps xmm0,xmm0,xmm0
  4096b1:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4096b7:	mov    QWORD PTR [rsp+0x18],0x0
  4096c0:	mov    WORD PTR [rsp+0x20],0x0
  4096c7:	mov    DWORD PTR [r14],0x67617753
  4096ce:	mov    DWORD PTR [r14+0x4],0x2e74522e
  4096d6:	xor    eax,eax
  4096d8:	call   407050 <getpid@plt>
  4096dd:	mov    ecx,eax
  4096df:	mov    eax,0x1c
  4096e4:	shrx   eax,ecx,eax
  4096e9:	and    eax,0xf
  4096ec:	mov    rdx,QWORD PTR [rip+0xa0ad]        # 4137a0 <__swc_rdata_base_65555ab2+0x690>
  4096f3:	mov    al,BYTE PTR [rdx+rax*1]
  4096f6:	rex mov BYTE PTR [rsp+0x10],al
  4096fb:	mov    eax,0x1c
  409700:	shrx   eax,r12d,eax
  409705:	and    eax,0xf
  409708:	mov    al,BYTE PTR [rdx+rax*1]
  40970b:	rex mov BYTE PTR [rsp+0x19],al
  409710:	mov    eax,0x18
  409715:	shrx   eax,ecx,eax
  40971a:	and    eax,0xf
  40971d:	mov    al,BYTE PTR [rdx+rax*1]
  409720:	rex mov BYTE PTR [rsp+0x11],al
  409725:	mov    eax,0x18
  40972a:	shrx   eax,r12d,eax
  40972f:	and    eax,0xf
  409732:	mov    al,BYTE PTR [rdx+rax*1]
  409735:	rex mov BYTE PTR [rsp+0x1a],al
  40973a:	mov    eax,0x14
  40973f:	shrx   eax,ecx,eax
  409744:	and    eax,0xf
  409747:	mov    al,BYTE PTR [rdx+rax*1]
  40974a:	rex mov BYTE PTR [rsp+0x12],al
  40974f:	mov    eax,0x14
  409754:	shrx   eax,r12d,eax
  409759:	and    eax,0xf
  40975c:	mov    al,BYTE PTR [rdx+rax*1]
  40975f:	rex mov BYTE PTR [rsp+0x1b],al
  409764:	mov    eax,0x10
  409769:	shrx   eax,ecx,eax
  40976e:	and    eax,0xf
  409771:	mov    al,BYTE PTR [rdx+rax*1]
  409774:	rex mov BYTE PTR [rsp+0x13],al
  409779:	mov    eax,0x10
  40977e:	shrx   eax,r12d,eax
  409783:	and    eax,0xf
  409786:	mov    al,BYTE PTR [rdx+rax*1]
  409789:	rex mov BYTE PTR [rsp+0x1c],al
  40978e:	mov    eax,0xc
  409793:	shrx   eax,ecx,eax
  409798:	and    eax,0xf
  40979b:	mov    al,BYTE PTR [rdx+rax*1]
  40979e:	rex mov BYTE PTR [rsp+0x14],al
  4097a3:	mov    eax,0xc
  4097a8:	shrx   eax,r12d,eax
  4097ad:	and    eax,0xf
  4097b0:	mov    al,BYTE PTR [rdx+rax*1]
  4097b3:	rex mov BYTE PTR [rsp+0x1d],al
  4097b8:	mov    eax,0x8
  4097bd:	shrx   eax,ecx,eax
  4097c2:	and    eax,0xf
  4097c5:	mov    al,BYTE PTR [rdx+rax*1]
  4097c8:	rex mov BYTE PTR [rsp+0x15],al
  4097cd:	mov    eax,0x8
  4097d2:	shrx   eax,r12d,eax
  4097d7:	and    eax,0xf
  4097da:	mov    al,BYTE PTR [rdx+rax*1]
  4097dd:	rex mov BYTE PTR [rsp+0x1e],al
  4097e2:	mov    eax,0x4
  4097e7:	shrx   eax,ecx,eax
  4097ec:	and    eax,0xf
  4097ef:	mov    al,BYTE PTR [rdx+rax*1]
  4097f2:	rex mov BYTE PTR [rsp+0x16],al
  4097f7:	mov    eax,0x4
  4097fc:	shrx   eax,r12d,eax
  409801:	and    eax,0xf
  409804:	mov    al,BYTE PTR [rdx+rax*1]
  409807:	rex mov BYTE PTR [rsp+0x1f],al
  40980c:	xor    eax,eax
  40980e:	shrx   eax,ecx,eax
  409813:	and    eax,0xf
  409816:	mov    al,BYTE PTR [rdx+rax*1]
  409819:	rex mov BYTE PTR [rsp+0x17],al
  40981e:	xor    eax,eax
  409820:	shrx   eax,r12d,eax
  409825:	and    eax,0xf
  409828:	mov    al,BYTE PTR [rdx+rax*1]
  40982b:	rex mov BYTE PTR [rsp+0x20],al
  409830:	mov    BYTE PTR [r14+0x10],0x2e
  409835:	lea    r12,[rsp+0x22]
  40983a:	vxorps xmm0,xmm0,xmm0
  40983e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  409844:	mov    DWORD PTR [r12],0x6d656d2f
  40984c:	mov    WORD PTR [r12+0x4],0x6466
  409854:	mov    BYTE PTR [r12+0x6],0x3a
  40985a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409860:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  409866:	mov    rax,QWORD PTR [rsp+0x18]
  40986b:	mov    QWORD PTR [rsp+0x39],rax
  409870:	rex mov al,BYTE PTR [rsp+0x20]
  409875:	rex mov BYTE PTR [rsp+0x41],al
  40987a:	mov    DWORD PTR [r12+0x20],0x65642820
  409883:	mov    DWORD PTR [r12+0x24],0x6574656c
  40988c:	mov    WORD PTR [r12+0x28],0x2964
  409894:	lea    rdi,[rip+0x9ef0]        # 41378b <__swc_rdata_base_65555ab2+0x67b>
  40989b:	xor    eax,eax
  40989d:	call   407060 <opendir@plt>
  4098a2:	mov    r15,rax
  4098a5:	test   rax,rax
  4098a8:	jne    4098bb <__swc_fn_65555ab2_000111_6814119b+0x30b>
  4098aa:	movsxd rdi,r13d
  4098ad:	xor    eax,eax
  4098af:	call   407040 <close@plt>
  4098b4:	xor    eax,eax
  4098b6:	jmp    409b66 <__swc_fn_65555ab2_000111_6814119b+0x5b6>
  4098bb:	mov    rdi,r15
  4098be:	xor    eax,eax
  4098c0:	call   407070 <dirfd@plt>
  4098c5:	lea    r14,[rsp+0x54]
  4098ca:	mov    DWORD PTR [rsp+0x54],eax
  4098ce:	lea    rbx,[rsp+0x58]
  4098d3:	cs nop WORD PTR [rax+rax*1+0x0]
  4098dd:	nop    DWORD PTR [rax]
  4098e0:	mov    rdi,r15
  4098e3:	xor    eax,eax
  4098e5:	call   407080 <readdir@plt>
  4098ea:	test   rax,rax
  4098ed:	jne    409904 <__swc_fn_65555ab2_000111_6814119b+0x354>
  4098ef:	mov    r12,QWORD PTR [rsp+0xa8]
  4098f7:	mov    r13,QWORD PTR [rsp+0xb0]
  4098ff:	jmp    409a8a <__swc_fn_65555ab2_000111_6814119b+0x4da>
  409904:	vxorps xmm0,xmm0,xmm0
  409908:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  40990e:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  409914:	vzeroupper
  409917:	lea    r13,[rax+0x13]
  40991b:	mov    rax,r14
  40991e:	movsxd rdi,DWORD PTR [rax]
  409921:	mov    rsi,r13
  409924:	mov    rdx,rbx
  409927:	mov    ecx,0x40
  40992c:	xor    eax,eax
  40992e:	call   407090 <readlinkat@plt>
  409933:	cmp    rax,0x2a
  409937:	jne    4098e0 <__swc_fn_65555ab2_000111_6814119b+0x330>
  409939:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40993f:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  409945:	vptest xmm0,xmm0
  40994a:	jne    40997a <__swc_fn_65555ab2_000111_6814119b+0x3ca>
  40994c:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  409952:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  409958:	vptest xmm0,xmm0
  40995d:	jne    40997a <__swc_fn_65555ab2_000111_6814119b+0x3ca>
  40995f:	mov    rcx,QWORD PTR [rsp+0x42]
  409964:	cmp    QWORD PTR [rsp+0x78],rcx
  409969:	jne    40997a <__swc_fn_65555ab2_000111_6814119b+0x3ca>
  40996b:	mov    cx,WORD PTR [rsp+0x4a]
  409970:	cmp    WORD PTR [rsp+0x80],cx
  409978:	je     4099a4 <__swc_fn_65555ab2_000111_6814119b+0x3f4>
  40997a:	mov    rax,rbx
  40997d:	mov    rcx,r12
  409980:	movzx  edx,BYTE PTR [rax]
  409983:	movzx  r8d,BYTE PTR [rcx]
  409987:	cmp    rdx,r8
  40998a:	jne    409996 <__swc_fn_65555ab2_000111_6814119b+0x3e6>
  40998c:	add    rax,0x1
  409990:	add    rcx,0x1
  409994:	jmp    409980 <__swc_fn_65555ab2_000111_6814119b+0x3d0>
  409996:	mov    rax,rdx
  409999:	sub    rax,r8
  40999c:	test   eax,eax
  40999e:	jne    4098e0 <__swc_fn_65555ab2_000111_6814119b+0x330>
  4099a4:	movsxd rdi,DWORD PTR [r14]
  4099a7:	mov    rsi,r13
  4099aa:	mov    edx,0x80002
  4099af:	xor    eax,eax
  4099b1:	call   4070a0 <openat@plt>
  4099b6:	lea    rbx,[rsp+0x98]
  4099be:	mov    DWORD PTR [rsp+0x98],eax
  4099c5:	test   eax,eax
  4099c7:	mov    r13,QWORD PTR [rsp+0xb0]
  4099cf:	jge    4099f4 <__swc_fn_65555ab2_000111_6814119b+0x444>
  4099d1:	mov    rdi,r15
  4099d4:	xor    eax,eax
  4099d6:	call   4070b0 <closedir@plt>
  4099db:	mov    r13,QWORD PTR [rsp+0xb0]
  4099e3:	movsxd rdi,r13d
  4099e6:	xor    eax,eax
  4099e8:	call   407040 <close@plt>
  4099ed:	xor    eax,eax
  4099ef:	jmp    409b66 <__swc_fn_65555ab2_000111_6814119b+0x5b6>
  4099f4:	mov    rax,rbx
  4099f7:	movsxd rdi,DWORD PTR [rax]
  4099fa:	xor    esi,esi
  4099fc:	mov    edx,0x2
  409a01:	xor    eax,eax
  409a03:	call   4070c0 <lseek@plt>
  409a08:	mov    r12,QWORD PTR [rsp+0xa8]
  409a10:	cmp    rax,r12
  409a13:	je     409a3a <__swc_fn_65555ab2_000111_6814119b+0x48a>
  409a15:	movsxd rdi,DWORD PTR [rbx]
  409a18:	xor    eax,eax
  409a1a:	call   407040 <close@plt>
  409a1f:	mov    rdi,r15
  409a22:	xor    eax,eax
  409a24:	call   4070b0 <closedir@plt>
  409a29:	movsxd rdi,r13d
  409a2c:	xor    eax,eax
  409a2e:	call   407040 <close@plt>
  409a33:	xor    eax,eax
  409a35:	jmp    409b66 <__swc_fn_65555ab2_000111_6814119b+0x5b6>
  409a3a:	xor    edi,edi
  409a3c:	mov    rsi,r12
  409a3f:	mov    edx,0x3
  409a44:	mov    ecx,0x1
  409a49:	mov    rax,rbx
  409a4c:	movsxd r8,DWORD PTR [rax]
  409a4f:	xor    r9d,r9d
  409a52:	xor    eax,eax
  409a54:	call   4070d0 <mmap@plt>
  409a59:	xor    r12d,r12d
  409a5c:	cmp    rax,0xffffffffffffffff
  409a60:	cmovne r12,rax
  409a64:	movsxd rdi,DWORD PTR [rbx]
  409a67:	xor    eax,eax
  409a69:	call   407040 <close@plt>
  409a6e:	mov    rdi,r15
  409a71:	xor    eax,eax
  409a73:	call   4070b0 <closedir@plt>
  409a78:	movsxd rdi,r13d
  409a7b:	xor    eax,eax
  409a7d:	call   407040 <close@plt>
  409a82:	mov    rax,r12
  409a85:	jmp    409b66 <__swc_fn_65555ab2_000111_6814119b+0x5b6>
  409a8a:	mov    r14,QWORD PTR [rsp+0xb8]
  409a92:	mov    rdi,r14
  409a95:	mov    esi,0x1
  409a9a:	xor    eax,eax
  409a9c:	call   4070e0 <memfd_create@plt>
  409aa1:	lea    rbx,[rsp+0x9c]
  409aa9:	mov    DWORD PTR [rsp+0x9c],eax
  409ab0:	test   eax,eax
  409ab2:	jge    409acf <__swc_fn_65555ab2_000111_6814119b+0x51f>
  409ab4:	mov    rdi,r15
  409ab7:	xor    eax,eax
  409ab9:	call   4070b0 <closedir@plt>
  409abe:	movsxd rdi,r13d
  409ac1:	xor    eax,eax
  409ac3:	call   407040 <close@plt>
  409ac8:	xor    eax,eax
  409aca:	jmp    409b66 <__swc_fn_65555ab2_000111_6814119b+0x5b6>
  409acf:	mov    rax,rbx
  409ad2:	movsxd rdi,DWORD PTR [rax]
  409ad5:	mov    rsi,r12
  409ad8:	xor    eax,eax
  409ada:	call   4070f0 <ftruncate@plt>
  409adf:	test   eax,eax
  409ae1:	je     409b05 <__swc_fn_65555ab2_000111_6814119b+0x555>
  409ae3:	movsxd rdi,DWORD PTR [rbx]
  409ae6:	xor    eax,eax
  409ae8:	call   407040 <close@plt>
  409aed:	mov    rdi,r15
  409af0:	xor    eax,eax
  409af2:	call   4070b0 <closedir@plt>
  409af7:	movsxd rdi,r13d
  409afa:	xor    eax,eax
  409afc:	call   407040 <close@plt>
  409b01:	xor    eax,eax
  409b03:	jmp    409b66 <__swc_fn_65555ab2_000111_6814119b+0x5b6>
  409b05:	xor    edi,edi
  409b07:	mov    rsi,r12
  409b0a:	mov    edx,0x3
  409b0f:	mov    ecx,0x1
  409b14:	mov    rax,rbx
  409b17:	movsxd r8,DWORD PTR [rax]
  409b1a:	xor    r9d,r9d
  409b1d:	xor    eax,eax
  409b1f:	call   4070d0 <mmap@plt>
  409b24:	mov    r12,rax
  409b27:	cmp    rax,0xffffffffffffffff
  409b2b:	jne    409b4f <__swc_fn_65555ab2_000111_6814119b+0x59f>
  409b2d:	movsxd rdi,DWORD PTR [rbx]
  409b30:	xor    eax,eax
  409b32:	call   407040 <close@plt>
  409b37:	mov    rdi,r15
  409b3a:	xor    eax,eax
  409b3c:	call   4070b0 <closedir@plt>
  409b41:	movsxd rdi,r13d
  409b44:	xor    eax,eax
  409b46:	call   407040 <close@plt>
  409b4b:	xor    eax,eax
  409b4d:	jmp    409b66 <__swc_fn_65555ab2_000111_6814119b+0x5b6>
  409b4f:	mov    rdi,r15
  409b52:	xor    eax,eax
  409b54:	call   4070b0 <closedir@plt>
  409b59:	movsxd rdi,r13d
  409b5c:	xor    eax,eax
  409b5e:	call   407040 <close@plt>
  409b63:	mov    rax,r12
  409b66:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  409b6f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  409b78:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  409b81:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  409b8a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  409b93:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  409b9c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  409ba5:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  409bae:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  409bb7:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  409bc0:	add    rsp,0x170
  409bc7:	pop    r15
  409bc9:	pop    r14
  409bcb:	pop    r13
  409bcd:	pop    rsi
  409bce:	pop    rdi
  409bcf:	pop    r12
  409bd1:	pop    rbx
  409bd2:	ret
	...

0000000000409be0 <__swc_fn_65555ab2_000114_5f48311c>:
  409be0:	push   rsi
  409be1:	push   rdi
  409be2:	push   r12
  409be4:	push   r13
  409be6:	sub    rsp,0x8
  409bea:	mov    rsi,r8
  409bed:	mov    rdi,rcx
  409bf0:	mov    r12,rdx
  409bf3:	call   40dae0 <__swc_fn_65555ab2_000112_126150d1>
  409bf8:	mov    r13,rax
  409bfb:	test   rax,rax
  409bfe:	jne    409c0b <__swc_fn_65555ab2_000114_5f48311c+0x2b>
  409c00:	add    rsp,0x8
  409c04:	pop    r13
  409c06:	pop    r12
  409c08:	pop    rdi
  409c09:	pop    rsi
  409c0a:	ret
  409c0b:	mov    rcx,r13
  409c0e:	call   411750 <__swc_fn_65555ab2_000137_8c07c14b>
  409c13:	mov    rax,QWORD PTR [r13+0x8]
  409c17:	test   rax,rax
  409c1a:	je     409c59 <__swc_fn_65555ab2_000114_5f48311c+0x79>
  409c1c:	nop    DWORD PTR [rax+0x0]
  409c20:	lea    rcx,[rax+0x1000]
  409c27:	cmp    rdi,rcx
  409c2a:	jne    409c51 <__swc_fn_65555ab2_000114_5f48311c+0x71>
  409c2c:	cmp    r12,0x1000
  409c33:	jb     409c51 <__swc_fn_65555ab2_000114_5f48311c+0x71>
  409c35:	test   sil,sil
  409c38:	setne  cl
  409c3b:	mov    BYTE PTR [rax+0x10],cl
  409c3e:	mov    rcx,r13
  409c41:	call   40a140 <__swc_fn_65555ab2_000138_715e84ff>
  409c46:	add    rsp,0x8
  409c4a:	pop    r13
  409c4c:	pop    r12
  409c4e:	pop    rdi
  409c4f:	pop    rsi
  409c50:	ret
  409c51:	mov    rax,QWORD PTR [rax]
  409c54:	test   rax,rax
  409c57:	jne    409c20 <__swc_fn_65555ab2_000114_5f48311c+0x40>
  409c59:	mov    rcx,r13
  409c5c:	call   40a140 <__swc_fn_65555ab2_000138_715e84ff>
  409c61:	add    rsp,0x8
  409c65:	pop    r13
  409c67:	pop    r12
  409c69:	pop    rdi
  409c6a:	pop    rsi
  409c6b:	ret
  409c6c:	add    BYTE PTR [rax],al
	...

0000000000409c70 <__swc_fn_65555ab2_000117_ed2d8fed>:
  409c70:	sub    rsp,0x8
  409c74:	test   rcx,rcx
  409c77:	jne    409c7e <__swc_fn_65555ab2_000117_ed2d8fed+0xe>
  409c79:	add    rsp,0x8
  409c7d:	ret
  409c7e:	call   411260 <__swc_fn_65555ab2_000119_d3318640>
  409c83:	add    rsp,0x8
  409c87:	ret
	...

0000000000409c90 <__swc_fn_65555ab2_000120_2648f149>:
  409c90:	push   r12
  409c92:	push   r13
  409c94:	push   r14
  409c96:	push   rdi
  409c97:	push   rsi
  409c98:	sub    rsp,0xc0
  409c9f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  409ca5:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409cab:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  409cb1:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409cb7:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409cbd:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  409cc3:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409cc9:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  409cd2:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409cdb:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  409ce4:	mov    r12,QWORD PTR [rcx]
  409ce7:	test   r12,r12
  409cea:	jne    409cfc <__swc_fn_65555ab2_000120_2648f149+0x6c>
  409cec:	add    rsp,0xc0
  409cf3:	pop    rsi
  409cf4:	pop    rdi
  409cf5:	pop    r14
  409cf7:	pop    r13
  409cf9:	pop    r12
  409cfb:	ret
  409cfc:	xor    r13d,r13d
  409cff:	mov    r14,QWORD PTR [rcx+0x8]
  409d03:	cs nop WORD PTR [rax+rax*1+0x0]
  409d0d:	nop    DWORD PTR [rax]
  409d10:	cmp    r13,r14
  409d13:	jae    409d4b <__swc_fn_65555ab2_000120_2648f149+0xbb>
  409d15:	lea    rax,[r12+r13*1]
  409d19:	mov    rcx,r14
  409d1c:	sub    rcx,r13
  409d1f:	mov    edi,0x1
  409d24:	mov    rsi,rax
  409d27:	mov    rdx,rcx
  409d2a:	xor    eax,eax
  409d2c:	call   407100 <write@plt>
  409d31:	test   rax,rax
  409d34:	jle    409d3b <__swc_fn_65555ab2_000120_2648f149+0xab>
  409d36:	add    r13,rax
  409d39:	jmp    409d10 <__swc_fn_65555ab2_000120_2648f149+0x80>
  409d3b:	je     409d49 <__swc_fn_65555ab2_000120_2648f149+0xb9>
  409d3d:	xor    eax,eax
  409d3f:	call   407030 <__errno_location@plt>
  409d44:	cmp    DWORD PTR [rax],0x4
  409d47:	je     409d10 <__swc_fn_65555ab2_000120_2648f149+0x80>
  409d49:	jmp    409d4b <__swc_fn_65555ab2_000120_2648f149+0xbb>
  409d4b:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  409d51:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409d57:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409d5d:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  409d63:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409d69:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409d6f:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  409d75:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409d7e:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409d87:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409d90:	add    rsp,0xc0
  409d97:	pop    rsi
  409d98:	pop    rdi
  409d99:	pop    r14
  409d9b:	pop    r13
  409d9d:	pop    r12
  409d9f:	ret

0000000000409da0 <__swc_fn_65555ab2_000123_4f256d58>:
  409da0:	push   rbx
  409da1:	push   r12
  409da3:	push   rdi
  409da4:	push   rsi
  409da5:	sub    rsp,0x4a8
  409dac:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  409db5:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  409dbe:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  409dc7:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  409dd0:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  409dd9:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  409de2:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  409deb:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  409df4:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  409dfd:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  409e06:	mov    rbx,rdx
  409e09:	mov    r12d,ecx
  409e0c:	vxorps xmm0,xmm0,xmm0
  409e10:	xor    eax,eax
  409e12:	cs nop WORD PTR [rax+rax*1+0x0]
  409e1c:	nop    DWORD PTR [rax+0x0]
  409e20:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  409e26:	add    rax,0x10
  409e2a:	cmp    rax,0x400
  409e31:	jne    409e20 <__swc_fn_65555ab2_000123_4f256d58+0x80>
  409e33:	lea    rdi,[rsp+0x8]
  409e38:	mov    esi,0x80
  409e3d:	xor    eax,eax
  409e3f:	call   407110 <backtrace@plt>
  409e44:	test   eax,eax
  409e46:	jle    409e55 <__swc_fn_65555ab2_000123_4f256d58+0xb5>
  409e48:	movsxd rax,eax
  409e4b:	lea    rcx,[r12+0x1]
  409e50:	cmp    rcx,rax
  409e53:	jb     409e59 <__swc_fn_65555ab2_000123_4f256d58+0xb9>
  409e55:	xor    eax,eax
  409e57:	jmp    409e8a <__swc_fn_65555ab2_000123_4f256d58+0xea>
  409e59:	mov    rcx,QWORD PTR [rbx+0x8]
  409e5d:	sub    rax,r12
  409e60:	lea    rsi,[rax-0x1]
  409e64:	cmp    rcx,rsi
  409e67:	cmovbe rsi,rcx
  409e6b:	lea    eax,[r12+0x1]
  409e70:	lea    rax,[rsp+rax*8+0x8]
  409e75:	mov    rcx,QWORD PTR [rbx]
  409e78:	mov    rdx,rax
  409e7b:	lea    r8,[rsi*8+0x0]
  409e83:	call   40dac0 <__swc_fn_65555ab2_000109_7c204aac>
  409e88:	mov    eax,esi
  409e8a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  409e93:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  409e9c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  409ea5:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  409eae:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  409eb7:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  409ec0:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  409ec9:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  409ed2:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  409edb:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  409ee4:	add    rsp,0x4a8
  409eeb:	pop    rsi
  409eec:	pop    rdi
  409eed:	pop    r12
  409eef:	pop    rbx
  409ef0:	ret
	...

0000000000409f00 <__swc_fn_65555ab2_000126_fcd5a289>:
  409f00:	mov    QWORD PTR [rcx],0x0
  409f07:	ret
	...

0000000000409f10 <__swc_fn_65555ab2_000129_4bbe3f14>:
  409f10:	push   rdi
  409f11:	push   rsi
  409f12:	sub    rsp,0xa8
  409f19:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409f1f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409f25:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409f2b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409f31:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409f37:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409f3d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409f43:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409f49:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409f52:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  409f5b:	mov    edi,ecx
  409f5d:	mov    rsi,rdx
  409f60:	xor    eax,eax
  409f62:	call   407120 <pthread_setspecific@plt>
  409f67:	test   eax,eax
  409f69:	sete   al
  409f6c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409f72:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409f78:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409f7e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  409f84:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409f8a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409f90:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  409f96:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409f9c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  409fa5:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409fae:	add    rsp,0xa8
  409fb5:	pop    rsi
  409fb6:	pop    rdi
  409fb7:	ret
	...

0000000000409fc0 <__swc_fn_65555ab2_000132_5f757033>:
  409fc0:	push   rdi
  409fc1:	push   rsi
  409fc2:	sub    rsp,0xa8
  409fc9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409fcf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409fd5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  409fdb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409fe1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409fe7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409fed:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409ff3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409ff9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a002:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a00b:	test   rcx,rcx
  40a00e:	je     40a021 <__swc_fn_65555ab2_000132_5f757033+0x61>
  40a010:	lea    rax,[rcx-0x1]
  40a014:	mov    eax,eax
  40a016:	mov    edi,eax
  40a018:	xor    eax,eax
  40a01a:	call   407000 <pthread_getspecific@plt>
  40a01f:	jmp    40a023 <__swc_fn_65555ab2_000132_5f757033+0x63>
  40a021:	xor    eax,eax
  40a023:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a029:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a02f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a035:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a03b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a041:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a047:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a04d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a053:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a05c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a065:	add    rsp,0xa8
  40a06c:	pop    rsi
  40a06d:	pop    rdi
  40a06e:	ret
	...

000000000040a070 <__swc_fn_65555ab2_000135_07d76562>:
  40a070:	push   rdi
  40a071:	push   rsi
  40a072:	sub    rsp,0xb8
  40a079:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40a07f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40a085:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40a08b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40a091:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40a097:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40a09d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40a0a3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40a0ac:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40a0b5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40a0be:	vxorps xmm0,xmm0,xmm0
  40a0c2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a0c8:	mov    edi,0x1
  40a0cd:	lea    rsi,[rsp+0x8]
  40a0d2:	xor    eax,eax
  40a0d4:	call   407130 <clock_gettime@plt>
  40a0d9:	mov    rax,QWORD PTR [rsp+0x8]
  40a0de:	imul   rax,rax,0x3b9aca00
  40a0e5:	add    rax,QWORD PTR [rsp+0x10]
  40a0ea:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40a0f0:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40a0f6:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40a0fc:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40a102:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40a108:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40a10e:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40a114:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40a11d:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40a126:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40a12f:	add    rsp,0xb8
  40a136:	pop    rsi
  40a137:	pop    rdi
  40a138:	ret
  40a139:	add    BYTE PTR [rax],al
  40a13b:	add    BYTE PTR [rax],al
  40a13d:	add    BYTE PTR [rax],al
	...

000000000040a140 <__swc_fn_65555ab2_000138_715e84ff>:
  40a140:	sub    rsp,0x8
  40a144:	xor    eax,eax
  40a146:	mov    DWORD PTR [rcx],eax
  40a148:	mov    edx,0x7fffffff
  40a14d:	call   40e1c0 <__swc_fn_65555ab2_000136_865f5106>
  40a152:	add    rsp,0x8
  40a156:	ret
	...

000000000040a160 <__swc_fn_65555ab2_000141_519fdf94>:
  40a160:	push   rdi
  40a161:	push   rsi
  40a162:	sub    rsp,0xb8
  40a169:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40a16f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40a175:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40a17b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40a181:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40a187:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40a18d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40a193:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40a19c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40a1a5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40a1ae:	mov    edi,0x1
  40a1b3:	xor    eax,eax
  40a1b5:	call   407140 <__x86_get_cpuid_feature_leaf@plt>
  40a1ba:	mov    eax,DWORD PTR [rax+0x14]
  40a1bd:	and    eax,0x20
  40a1c0:	setne  al
  40a1c3:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40a1c9:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40a1cf:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40a1d5:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40a1db:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40a1e1:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40a1e7:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40a1ed:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40a1f6:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40a1ff:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40a208:	add    rsp,0xb8
  40a20f:	pop    rsi
  40a210:	pop    rdi
  40a211:	ret
	...

000000000040a220 <__swc_fn_65555ab2_000144_d5d4d43f>:
  40a220:	push   rsi
  40a221:	push   rdi
  40a222:	push   r12
  40a224:	push   r13
  40a226:	push   r14
  40a228:	push   r15
  40a22a:	cmp    rdx,0x40
  40a22e:	jae    40a23d <__swc_fn_65555ab2_000144_d5d4d43f+0x1d>
  40a230:	xor    eax,eax
  40a232:	pop    r15
  40a234:	pop    r14
  40a236:	pop    r13
  40a238:	pop    r12
  40a23a:	pop    rdi
  40a23b:	pop    rsi
  40a23c:	ret
  40a23d:	cmp    BYTE PTR [rcx],0x7f
  40a240:	jne    40a284 <__swc_fn_65555ab2_000144_d5d4d43f+0x64>
  40a242:	movzx  eax,BYTE PTR [rcx+0x1]
  40a246:	cmp    eax,0x45
  40a249:	setne  al
  40a24c:	jne    40a280 <__swc_fn_65555ab2_000144_d5d4d43f+0x60>
  40a24e:	movzx  eax,BYTE PTR [rcx+0x2]
  40a252:	cmp    eax,0x4c
  40a255:	setne  al
  40a258:	jne    40a280 <__swc_fn_65555ab2_000144_d5d4d43f+0x60>
  40a25a:	movzx  eax,BYTE PTR [rcx+0x3]
  40a25e:	cmp    eax,0x46
  40a261:	setne  al
  40a264:	jne    40a280 <__swc_fn_65555ab2_000144_d5d4d43f+0x60>
  40a266:	cmp    BYTE PTR [rcx+0x4],0x2
  40a26a:	setne  al
  40a26d:	jne    40a280 <__swc_fn_65555ab2_000144_d5d4d43f+0x60>
  40a26f:	cmp    BYTE PTR [rcx+0x5],0x1
  40a273:	setne  al
  40a276:	jne    40a280 <__swc_fn_65555ab2_000144_d5d4d43f+0x60>
  40a278:	cmp    WORD PTR [rcx+0x12],0x3e
  40a27d:	setne  al
  40a280:	test   al,al
  40a282:	je     40a291 <__swc_fn_65555ab2_000144_d5d4d43f+0x71>
  40a284:	xor    eax,eax
  40a286:	pop    r15
  40a288:	pop    r14
  40a28a:	pop    r13
  40a28c:	pop    r12
  40a28e:	pop    rdi
  40a28f:	pop    rsi
  40a290:	ret
  40a291:	cmp    WORD PTR [rcx+0x3a],0x40
  40a296:	jne    40a2b1 <__swc_fn_65555ab2_000144_d5d4d43f+0x91>
  40a298:	cmp    WORD PTR [rcx+0x3c],0x0
  40a29d:	sete   al
  40a2a0:	je     40a2ad <__swc_fn_65555ab2_000144_d5d4d43f+0x8d>
  40a2a2:	mov    ax,WORD PTR [rcx+0x3c]
  40a2a6:	cmp    WORD PTR [rcx+0x3e],ax
  40a2aa:	setae  al
  40a2ad:	test   al,al
  40a2af:	je     40a2be <__swc_fn_65555ab2_000144_d5d4d43f+0x9e>
  40a2b1:	xor    eax,eax
  40a2b3:	pop    r15
  40a2b5:	pop    r14
  40a2b7:	pop    r13
  40a2b9:	pop    r12
  40a2bb:	pop    rdi
  40a2bc:	pop    rsi
  40a2bd:	ret
  40a2be:	movzx  eax,WORD PTR [rcx+0x3c]
  40a2c2:	shl    rax,0x6
  40a2c6:	cmp    rax,rdx
  40a2c9:	ja     40a2d7 <__swc_fn_65555ab2_000144_d5d4d43f+0xb7>
  40a2cb:	mov    r9,rdx
  40a2ce:	sub    r9,rax
  40a2d1:	cmp    QWORD PTR [rcx+0x28],r9
  40a2d5:	jbe    40a2e4 <__swc_fn_65555ab2_000144_d5d4d43f+0xc4>
  40a2d7:	xor    eax,eax
  40a2d9:	pop    r15
  40a2db:	pop    r14
  40a2dd:	pop    r13
  40a2df:	pop    r12
  40a2e1:	pop    rdi
  40a2e2:	pop    rsi
  40a2e3:	ret
  40a2e4:	mov    rax,QWORD PTR [rcx+0x28]
  40a2e8:	add    rax,rcx
  40a2eb:	movzx  r9d,WORD PTR [rcx+0x3e]
  40a2f0:	lea    r9,[r9*8+0x0]
  40a2f8:	lea    r10,[rax+r9*8]
  40a2fc:	cmp    QWORD PTR [r10+0x20],rdx
  40a300:	ja     40a322 <__swc_fn_65555ab2_000144_d5d4d43f+0x102>
  40a302:	mov    r11,rdx
  40a305:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  40a30a:	cmp    QWORD PTR [r10+0x18],r11
  40a30e:	seta   r9b
  40a312:	ja     40a31d <__swc_fn_65555ab2_000144_d5d4d43f+0xfd>
  40a314:	cmp    QWORD PTR [r10+0x20],0x9
  40a319:	setb   r9b
  40a31d:	test   r9b,r9b
  40a320:	je     40a32f <__swc_fn_65555ab2_000144_d5d4d43f+0x10f>
  40a322:	xor    eax,eax
  40a324:	pop    r15
  40a326:	pop    r14
  40a328:	pop    r13
  40a32a:	pop    r12
  40a32c:	pop    rdi
  40a32d:	pop    rsi
  40a32e:	ret
  40a32f:	movzx  r9d,WORD PTR [rcx+0x3c]
  40a334:	xor    r11d,r11d
  40a337:	test   r9,r9
  40a33a:	jbe    40a435 <__swc_fn_65555ab2_000144_d5d4d43f+0x215>
  40a340:	mov    rsi,QWORD PTR [r10+0x20]
  40a344:	sub    rsi,0x9
  40a348:	cs nop WORD PTR [rax+rax*1+0x0]
  40a352:	cs nop WORD PTR [rax+rax*1+0x0]
  40a35c:	nop    DWORD PTR [rax+0x0]
  40a360:	movzx  edi,r11w
  40a364:	lea    rdi,[rdi*8+0x0]
  40a36c:	lea    r12,[rax+rdi*8]
  40a370:	rex mov edi,DWORD PTR [rax+rdi*8]
  40a374:	cmp    rdi,rsi
  40a377:	ja     40a428 <__swc_fn_65555ab2_000144_d5d4d43f+0x208>
  40a37d:	mov    r13,QWORD PTR [r10+0x18]
  40a381:	add    r13,rdi
  40a384:	lea    rdi,[rcx+r13*1]
  40a388:	lea    r13,[rip+0x9471]        # 413800 <__swc_rdata_base_65555ab2+0x6f0>
  40a38f:	movabs r14,0x676264676177732e
  40a399:	cmp    QWORD PTR [rdi],r14
  40a39c:	jne    40a3a5 <__swc_fn_65555ab2_000144_d5d4d43f+0x185>
  40a39e:	rex cmp BYTE PTR [rdi+0x8],0x0
  40a3a3:	je     40a3d2 <__swc_fn_65555ab2_000144_d5d4d43f+0x1b2>
  40a3a5:	cs nop WORD PTR [rax+rax*1+0x0]
  40a3af:	nop
  40a3b0:	movzx  r14d,BYTE PTR [rdi]
  40a3b4:	movzx  r15d,BYTE PTR [r13+0x0]
  40a3b9:	cmp    r14,r15
  40a3bc:	jne    40a3c8 <__swc_fn_65555ab2_000144_d5d4d43f+0x1a8>
  40a3be:	add    rdi,0x1
  40a3c2:	add    r13,0x1
  40a3c6:	jmp    40a3b0 <__swc_fn_65555ab2_000144_d5d4d43f+0x190>
  40a3c8:	mov    rdi,r14
  40a3cb:	sub    rdi,r15
  40a3ce:	test   edi,edi
  40a3d0:	jne    40a428 <__swc_fn_65555ab2_000144_d5d4d43f+0x208>
  40a3d2:	cmp    DWORD PTR [r12+0x4],0x1
  40a3d8:	jne    40a400 <__swc_fn_65555ab2_000144_d5d4d43f+0x1e0>
  40a3da:	cmp    QWORD PTR [r12+0x20],0x10
  40a3e0:	setb   al
  40a3e3:	jb     40a3fc <__swc_fn_65555ab2_000144_d5d4d43f+0x1dc>
  40a3e5:	cmp    QWORD PTR [r12+0x20],rdx
  40a3ea:	seta   al
  40a3ed:	ja     40a3fc <__swc_fn_65555ab2_000144_d5d4d43f+0x1dc>
  40a3ef:	sub    rdx,QWORD PTR [r12+0x20]
  40a3f4:	cmp    QWORD PTR [r12+0x18],rdx
  40a3f9:	seta   al
  40a3fc:	test   al,al
  40a3fe:	je     40a40d <__swc_fn_65555ab2_000144_d5d4d43f+0x1ed>
  40a400:	xor    eax,eax
  40a402:	pop    r15
  40a404:	pop    r14
  40a406:	pop    r13
  40a408:	pop    r12
  40a40a:	pop    rdi
  40a40b:	pop    rsi
  40a40c:	ret
  40a40d:	mov    rax,QWORD PTR [r12+0x20]
  40a412:	mov    QWORD PTR [r8],rax
  40a415:	mov    rax,QWORD PTR [r12+0x18]
  40a41a:	add    rax,rcx
  40a41d:	pop    r15
  40a41f:	pop    r14
  40a421:	pop    r13
  40a423:	pop    r12
  40a425:	pop    rdi
  40a426:	pop    rsi
  40a427:	ret
  40a428:	add    r11,0x1
  40a42c:	cmp    r11,r9
  40a42f:	jb     40a360 <__swc_fn_65555ab2_000144_d5d4d43f+0x140>
  40a435:	xor    eax,eax
  40a437:	pop    r15
  40a439:	pop    r14
  40a43b:	pop    r13
  40a43d:	pop    r12
  40a43f:	pop    rdi
  40a440:	pop    rsi
  40a441:	ret
	...

000000000040a450 <__swc_fn_65555ab2_000147_d7edc04f>:
  40a450:	push   rdi
  40a451:	push   rsi
  40a452:	sub    rsp,0xa8
  40a459:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40a45f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40a465:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40a46b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40a471:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40a477:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40a47d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40a483:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40a489:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40a492:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40a49b:	mov    rdi,rcx
  40a49e:	xor    eax,eax
  40a4a0:	call   407150 <free@plt>
  40a4a5:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40a4ab:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40a4b1:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40a4b7:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40a4bd:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40a4c3:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40a4c9:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40a4cf:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40a4d5:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40a4de:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40a4e7:	add    rsp,0xa8
  40a4ee:	pop    rsi
  40a4ef:	pop    rdi
  40a4f0:	ret
	...

000000000040a500 <__swc_fn_65555ab2_000150_6203dca2>:
  40a500:	push   rbx
  40a501:	push   rsi
  40a502:	push   rdi
  40a503:	push   r12
  40a505:	push   r13
  40a507:	push   r15
  40a509:	sub    rsp,0x4e8
  40a510:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  40a519:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  40a522:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  40a52b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  40a534:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  40a53d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  40a546:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  40a54f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  40a558:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  40a561:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  40a56a:	mov    rbx,QWORD PTR [rcx]
  40a56d:	mov    rcx,QWORD PTR [rcx+0x8]
  40a571:	mov    rsi,rcx
  40a574:	xor    edi,edi
  40a576:	vmovsd xmm6,QWORD PTR [rip+0x92e2]        # 413860 <__swc_rdata_base_65555ab2+0x750>
  40a57e:	vmovsd xmm7,QWORD PTR [rip+0x92e3]        # 413869 <__swc_rdata_base_65555ab2+0x759>
  40a586:	vmovsd xmm8,QWORD PTR [rip+0x92e4]        # 413872 <__swc_rdata_base_65555ab2+0x762>
  40a58e:	vmovsd xmm9,QWORD PTR [rip+0x92e5]        # 41387b <__swc_rdata_base_65555ab2+0x76b>
  40a596:	vmovsd xmm10,QWORD PTR [rip+0x92e6]        # 413884 <__swc_rdata_base_65555ab2+0x774>
  40a59e:	vmovups xmm11,xmm6
  40a5a2:	vmovsd QWORD PTR [rsp+0x418],xmm7
  40a5ab:	vmovsd QWORD PTR [rsp+0x420],xmm8
  40a5b4:	vmovsd QWORD PTR [rsp+0x428],xmm9
  40a5bd:	vmovsd QWORD PTR [rsp+0x430],xmm10
  40a5c6:	vmovsd xmm15,QWORD PTR [rip+0x92bf]        # 41388d <__swc_rdata_base_65555ab2+0x77d>
  40a5ce:	vmovups xmm14,xmm15
  40a5d3:	vmovups xmm0,xmm9
  40a5d8:	vmovsd QWORD PTR [rsp+0x438],xmm15
  40a5e1:	vmovups xmm13,xmm8
  40a5e6:	vmovsd QWORD PTR [rsp+0x440],xmm15
  40a5ef:	test   rsi,rsi
  40a5f2:	je     40b5e3 <__swc_fn_65555ab2_000150_6203dca2+0x10e3>
  40a5f8:	cs nop WORD PTR [rax+rax*1+0x0]
  40a602:	cs nop WORD PTR [rax+rax*1+0x0]
  40a60c:	nop    DWORD PTR [rax+0x0]
  40a610:	lea    rcx,[rdi+rdi*1]
  40a614:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  40a619:	vpshufd xmm3,xmm2,0xee
  40a61e:	vmovq  rcx,xmm3
  40a623:	test   rcx,rcx
  40a626:	je     40a63c <__swc_fn_65555ab2_000150_6203dca2+0x13c>
  40a628:	test   DWORD PTR [rcx+0x28],0x400000
  40a62f:	je     40a63c <__swc_fn_65555ab2_000150_6203dca2+0x13c>
  40a631:	mov    rdx,QWORD PTR [rcx+0x30]
  40a635:	test   rdx,rdx
  40a638:	cmovne rcx,rdx
  40a63c:	test   DWORD PTR [rcx+0x28],0x1000
  40a643:	je     40a664 <__swc_fn_65555ab2_000150_6203dca2+0x164>
  40a645:	mov    rdx,QWORD PTR [rcx+0x40]
  40a649:	mov    rcx,rdx
  40a64c:	vmovq  r8,xmm2
  40a651:	mov    r8,QWORD PTR [r8]
  40a654:	mov    QWORD PTR [rsp+0x60],r8
  40a659:	mov    QWORD PTR [rsp+0x68],rdx
  40a65e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  40a664:	test   BYTE PTR [rcx+0x28],0x1
  40a668:	jne    40a670 <__swc_fn_65555ab2_000150_6203dca2+0x170>
  40a66a:	vmovups xmm12,xmm0
  40a66e:	jmp    40a68a <__swc_fn_65555ab2_000150_6203dca2+0x18a>
  40a670:	vmovq  rax,xmm2
  40a675:	mov    rax,QWORD PTR [rax]
  40a678:	lea    rcx,[rax+0x10]
  40a67c:	vmovups xmm12,xmm0
  40a680:	call   409c90 <__swc_fn_65555ab2_000120_2648f149>
  40a685:	jmp    40b5c5 <__swc_fn_65555ab2_000150_6203dca2+0x10c5>
  40a68a:	test   DWORD PTR [rcx+0x28],0x400
  40a691:	je     40a6f2 <__swc_fn_65555ab2_000150_6203dca2+0x1f2>
  40a693:	vmovq  rax,xmm2
  40a698:	mov    rax,QWORD PTR [rax]
  40a69b:	xor    ecx,ecx
  40a69d:	test   rax,rax
  40a6a0:	je     40a6d0 <__swc_fn_65555ab2_000150_6203dca2+0x1d0>
  40a6a2:	mov    rdx,rax
  40a6a5:	mov    r8b,BYTE PTR [rdx]
  40a6a8:	test   r8b,r8b
  40a6ab:	je     40a6d0 <__swc_fn_65555ab2_000150_6203dca2+0x1d0>
  40a6ad:	cs nop WORD PTR [rax+rax*1+0x0]
  40a6b7:	nop    WORD PTR [rax+rax*1+0x0]
  40a6c0:	add    rdx,0x1
  40a6c4:	add    rcx,0x1
  40a6c8:	mov    r8b,BYTE PTR [rdx]
  40a6cb:	test   r8b,r8b
  40a6ce:	jne    40a6c0 <__swc_fn_65555ab2_000150_6203dca2+0x1c0>
  40a6d0:	mov    QWORD PTR [rsp+0x88],rax
  40a6d8:	mov    QWORD PTR [rsp+0x90],rcx
  40a6e0:	lea    rcx,[rsp+0x88]
  40a6e8:	call   409c90 <__swc_fn_65555ab2_000120_2648f149>
  40a6ed:	jmp    40b5c5 <__swc_fn_65555ab2_000150_6203dca2+0x10c5>
  40a6f2:	cmp    BYTE PTR [rcx+0x2c],0x6
  40a6f6:	jne    40a70d <__swc_fn_65555ab2_000150_6203dca2+0x20d>
  40a6f8:	vmovq  rax,xmm2
  40a6fd:	mov    rax,QWORD PTR [rax]
  40a700:	mov    rcx,rax
  40a703:	call   40e690 <__swc_fn_65555ab2_000148_43c96957>
  40a708:	jmp    40b5c5 <__swc_fn_65555ab2_000150_6203dca2+0x10c5>
  40a70d:	cmp    BYTE PTR [rcx+0x2c],0x1
  40a711:	jne    40b5b9 <__swc_fn_65555ab2_000150_6203dca2+0x10b9>
  40a717:	vmovq  rdx,xmm2
  40a71c:	mov    cl,BYTE PTR [rcx+0x40]
  40a71f:	cmp    cl,0x7
  40a722:	jb     40a765 <__swc_fn_65555ab2_000150_6203dca2+0x265>
  40a724:	je     40a7d8 <__swc_fn_65555ab2_000150_6203dca2+0x2d8>
  40a72a:	cmp    cl,0x8
  40a72d:	je     40a7e4 <__swc_fn_65555ab2_000150_6203dca2+0x2e4>
  40a733:	cmp    cl,0x9
  40a736:	je     40a7fd <__swc_fn_65555ab2_000150_6203dca2+0x2fd>
  40a73c:	cmp    cl,0xa
  40a73f:	je     40aec4 <__swc_fn_65555ab2_000150_6203dca2+0x9c4>
  40a745:	cmp    cl,0xb
  40a748:	je     40b58b <__swc_fn_65555ab2_000150_6203dca2+0x108b>
  40a74e:	cmp    cl,0xc
  40a751:	je     40a7f1 <__swc_fn_65555ab2_000150_6203dca2+0x2f1>
  40a757:	cmp    cl,0xd
  40a75a:	je     40b581 <__swc_fn_65555ab2_000150_6203dca2+0x1081>
  40a760:	jmp    40b5ab <__swc_fn_65555ab2_000150_6203dca2+0x10ab>
  40a765:	cmp    cl,0x1
  40a768:	je     40a788 <__swc_fn_65555ab2_000150_6203dca2+0x288>
  40a76a:	cmp    cl,0x2
  40a76d:	je     40a796 <__swc_fn_65555ab2_000150_6203dca2+0x296>
  40a76f:	cmp    cl,0x3
  40a772:	je     40a7a4 <__swc_fn_65555ab2_000150_6203dca2+0x2a4>
  40a774:	cmp    cl,0x4
  40a777:	je     40a7b1 <__swc_fn_65555ab2_000150_6203dca2+0x2b1>
  40a779:	cmp    cl,0x5
  40a77c:	je     40a7be <__swc_fn_65555ab2_000150_6203dca2+0x2be>
  40a77e:	cmp    cl,0x6
  40a781:	je     40a7cb <__swc_fn_65555ab2_000150_6203dca2+0x2cb>
  40a783:	jmp    40b5ab <__swc_fn_65555ab2_000150_6203dca2+0x10ab>
  40a788:	movsx  rcx,BYTE PTR [rdx]
  40a78c:	call   411940 <__swc_fn_65555ab2_000149_2eb804cc>
  40a791:	jmp    40b5c5 <__swc_fn_65555ab2_000150_6203dca2+0x10c5>
  40a796:	movsx  rcx,WORD PTR [rdx]
  40a79a:	call   411940 <__swc_fn_65555ab2_000149_2eb804cc>
  40a79f:	jmp    40b5c5 <__swc_fn_65555ab2_000150_6203dca2+0x10c5>
  40a7a4:	movsxd rcx,DWORD PTR [rdx]
  40a7a7:	call   411940 <__swc_fn_65555ab2_000149_2eb804cc>
  40a7ac:	jmp    40b5c5 <__swc_fn_65555ab2_000150_6203dca2+0x10c5>
  40a7b1:	mov    rcx,QWORD PTR [rdx]
  40a7b4:	call   411940 <__swc_fn_65555ab2_000149_2eb804cc>
  40a7b9:	jmp    40b5c5 <__swc_fn_65555ab2_000150_6203dca2+0x10c5>
  40a7be:	movzx  ecx,BYTE PTR [rdx]
  40a7c1:	call   40e690 <__swc_fn_65555ab2_000148_43c96957>
  40a7c6:	jmp    40b5c5 <__swc_fn_65555ab2_000150_6203dca2+0x10c5>
  40a7cb:	movzx  ecx,WORD PTR [rdx]
  40a7ce:	call   40e690 <__swc_fn_65555ab2_000148_43c96957>
  40a7d3:	jmp    40b5c5 <__swc_fn_65555ab2_000150_6203dca2+0x10c5>
  40a7d8:	mov    ecx,DWORD PTR [rdx]
  40a7da:	call   40e690 <__swc_fn_65555ab2_000148_43c96957>
  40a7df:	jmp    40b5c5 <__swc_fn_65555ab2_000150_6203dca2+0x10c5>
  40a7e4:	mov    rcx,QWORD PTR [rdx]
  40a7e7:	call   40e690 <__swc_fn_65555ab2_000148_43c96957>
  40a7ec:	jmp    40b5c5 <__swc_fn_65555ab2_000150_6203dca2+0x10c5>
  40a7f1:	mov    ecx,DWORD PTR [rdx]
  40a7f3:	call   40e690 <__swc_fn_65555ab2_000148_43c96957>
  40a7f8:	jmp    40b5c5 <__swc_fn_65555ab2_000150_6203dca2+0x10c5>
  40a7fd:	lea    rcx,[rsp+0xa8]
  40a805:	vxorps xmm0,xmm0,xmm0
  40a809:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  40a812:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  40a81b:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  40a824:	vzeroupper
  40a827:	mov    DWORD PTR [rsp+0x108],0x0
  40a832:	vxorpd xmm0,xmm0,xmm0
  40a836:	vmovss xmm1,DWORD PTR [rdx]
  40a83a:	vcvtss2sd xmm0,xmm0,xmm1
  40a83e:	vmovsd xmm1,xmm1,xmm0
  40a842:	vcomisd xmm0,xmm0
  40a846:	setne  dl
  40a849:	movzx  edx,dl
  40a84c:	setp   r8b
  40a850:	movzx  r8d,r8b
  40a854:	or     edx,r8d
  40a857:	test   dl,dl
  40a859:	je     40a866 <__swc_fn_65555ab2_000150_6203dca2+0x366>
  40a85b:	mov    DWORD PTR [rcx],0x6e616e
  40a861:	jmp    40ae58 <__swc_fn_65555ab2_000150_6203dca2+0x958>
  40a866:	vcomisd xmm1,xmm6
  40a86a:	ja     40a872 <__swc_fn_65555ab2_000150_6203dca2+0x372>
  40a86c:	vcomisd xmm7,xmm1
  40a870:	jbe    40a896 <__swc_fn_65555ab2_000150_6203dca2+0x396>
  40a872:	vxorpd xmm0,xmm0,xmm0
  40a876:	vcomisd xmm0,xmm1
  40a87a:	jbe    40a88b <__swc_fn_65555ab2_000150_6203dca2+0x38b>
  40a87c:	mov    DWORD PTR [rcx],0x666e692d
  40a882:	mov    BYTE PTR [rcx+0x4],0x0
  40a886:	jmp    40ae58 <__swc_fn_65555ab2_000150_6203dca2+0x958>
  40a88b:	mov    DWORD PTR [rcx],0x666e69
  40a891:	jmp    40ae58 <__swc_fn_65555ab2_000150_6203dca2+0x958>
  40a896:	vcomisd xmm1,xmm8
  40a89b:	jae    40a8a7 <__swc_fn_65555ab2_000150_6203dca2+0x3a7>
  40a89d:	vcomisd xmm9,xmm1
  40a8a1:	jbe    40ac1e <__swc_fn_65555ab2_000150_6203dca2+0x71e>
  40a8a7:	vmovups xmm0,xmm1
  40a8ab:	vxorpd xmm2,xmm2,xmm2
  40a8af:	vcomisd xmm2,xmm1
  40a8b3:	jbe    40a8c3 <__swc_fn_65555ab2_000150_6203dca2+0x3c3>
  40a8b5:	vmovsd xmm1,xmm1,xmm0
  40a8b9:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x8f5f]        # 413820 <__swc_rdata_base_65555ab2+0x710>
  40a8c1:	jmp    40a8c7 <__swc_fn_65555ab2_000150_6203dca2+0x3c7>
  40a8c3:	vmovsd xmm1,xmm1,xmm0
  40a8c7:	xor    r8d,r8d
  40a8ca:	vcomisd xmm1,xmm15
  40a8cf:	jb     40a8f0 <__swc_fn_65555ab2_000150_6203dca2+0x3f0>
  40a8d1:	cs nop WORD PTR [rax+rax*1+0x0]
  40a8db:	nop    DWORD PTR [rax+rax*1+0x0]
  40a8e0:	vdivsd xmm1,xmm1,xmm15
  40a8e5:	add    r8,0x1
  40a8e9:	vcomisd xmm1,xmm15
  40a8ee:	jae    40a8e0 <__swc_fn_65555ab2_000150_6203dca2+0x3e0>
  40a8f0:	mov    r9,rcx
  40a8f3:	vxorpd xmm2,xmm2,xmm2
  40a8f7:	vcomisd xmm2,xmm0
  40a8fb:	jbe    40a904 <__swc_fn_65555ab2_000150_6203dca2+0x404>
  40a8fd:	mov    BYTE PTR [rcx],0x2d
  40a900:	lea    r9,[rcx+0x1]
  40a904:	vcvttsd2si rdx,xmm1
  40a909:	mov    r10b,dl
  40a90c:	add    r10b,0x30
  40a910:	mov    BYTE PTR [r9],r10b
  40a913:	vxorpd xmm0,xmm0,xmm0
  40a917:	movzx  edx,dl
  40a91a:	vcvtsi2sd xmm0,xmm0,rdx
  40a91f:	vsubsd xmm0,xmm1,xmm0
  40a923:	vmulsd xmm1,xmm0,xmm15
  40a928:	mov    BYTE PTR [r9+0x1],0x2e
  40a92d:	vcvttsd2si rdx,xmm1
  40a932:	mov    r10b,dl
  40a935:	add    r10b,0x30
  40a939:	mov    BYTE PTR [r9+0x2],r10b
  40a93d:	vxorpd xmm0,xmm0,xmm0
  40a941:	movzx  edx,dl
  40a944:	vcvtsi2sd xmm0,xmm0,rdx
  40a949:	vsubsd xmm0,xmm1,xmm0
  40a94d:	vmulsd xmm1,xmm0,xmm15
  40a952:	vcvttsd2si rdx,xmm1
  40a957:	mov    r10b,dl
  40a95a:	add    r10b,0x30
  40a95e:	mov    BYTE PTR [r9+0x3],r10b
  40a962:	vxorpd xmm0,xmm0,xmm0
  40a966:	movzx  edx,dl
  40a969:	vcvtsi2sd xmm0,xmm0,rdx
  40a96e:	vsubsd xmm0,xmm1,xmm0
  40a972:	vmulsd xmm1,xmm0,xmm15
  40a977:	vcvttsd2si rdx,xmm1
  40a97c:	mov    r10b,dl
  40a97f:	add    r10b,0x30
  40a983:	mov    BYTE PTR [r9+0x4],r10b
  40a987:	vxorpd xmm0,xmm0,xmm0
  40a98b:	movzx  edx,dl
  40a98e:	vcvtsi2sd xmm0,xmm0,rdx
  40a993:	vsubsd xmm0,xmm1,xmm0
  40a997:	vmulsd xmm1,xmm0,xmm15
  40a99c:	vcvttsd2si rdx,xmm1
  40a9a1:	mov    r10b,dl
  40a9a4:	add    r10b,0x30
  40a9a8:	mov    BYTE PTR [r9+0x5],r10b
  40a9ac:	vxorpd xmm0,xmm0,xmm0
  40a9b0:	movzx  edx,dl
  40a9b3:	vcvtsi2sd xmm0,xmm0,rdx
  40a9b8:	vsubsd xmm0,xmm1,xmm0
  40a9bc:	vmulsd xmm1,xmm0,xmm15
  40a9c1:	vcvttsd2si rdx,xmm1
  40a9c6:	mov    r10b,dl
  40a9c9:	add    r10b,0x30
  40a9cd:	mov    BYTE PTR [r9+0x6],r10b
  40a9d1:	vxorpd xmm0,xmm0,xmm0
  40a9d5:	movzx  edx,dl
  40a9d8:	vcvtsi2sd xmm0,xmm0,rdx
  40a9dd:	vsubsd xmm0,xmm1,xmm0
  40a9e1:	vmulsd xmm1,xmm0,xmm15
  40a9e6:	vcvttsd2si rdx,xmm1
  40a9eb:	mov    r10b,dl
  40a9ee:	add    r10b,0x30
  40a9f2:	mov    BYTE PTR [r9+0x7],r10b
  40a9f6:	vxorpd xmm0,xmm0,xmm0
  40a9fa:	movzx  edx,dl
  40a9fd:	vcvtsi2sd xmm0,xmm0,rdx
  40aa02:	vsubsd xmm0,xmm1,xmm0
  40aa06:	vmulsd xmm1,xmm0,xmm15
  40aa0b:	vcvttsd2si rdx,xmm1
  40aa10:	mov    r10b,dl
  40aa13:	add    r10b,0x30
  40aa17:	mov    BYTE PTR [r9+0x8],r10b
  40aa1b:	vxorpd xmm0,xmm0,xmm0
  40aa1f:	movzx  edx,dl
  40aa22:	vcvtsi2sd xmm0,xmm0,rdx
  40aa27:	vsubsd xmm0,xmm1,xmm0
  40aa2b:	vmulsd xmm1,xmm0,xmm15
  40aa30:	vcvttsd2si rdx,xmm1
  40aa35:	mov    r10b,dl
  40aa38:	add    r10b,0x30
  40aa3c:	mov    BYTE PTR [r9+0x9],r10b
  40aa40:	vxorpd xmm0,xmm0,xmm0
  40aa44:	movzx  edx,dl
  40aa47:	vcvtsi2sd xmm0,xmm0,rdx
  40aa4c:	vsubsd xmm0,xmm1,xmm0
  40aa50:	vmulsd xmm1,xmm0,xmm15
  40aa55:	vcvttsd2si rdx,xmm1
  40aa5a:	mov    r10b,dl
  40aa5d:	add    r10b,0x30
  40aa61:	mov    BYTE PTR [r9+0xa],r10b
  40aa65:	vxorpd xmm0,xmm0,xmm0
  40aa69:	movzx  edx,dl
  40aa6c:	vcvtsi2sd xmm0,xmm0,rdx
  40aa71:	vsubsd xmm0,xmm1,xmm0
  40aa75:	vmulsd xmm1,xmm0,xmm15
  40aa7a:	vcvttsd2si rdx,xmm1
  40aa7f:	mov    r10b,dl
  40aa82:	add    r10b,0x30
  40aa86:	mov    BYTE PTR [r9+0xb],r10b
  40aa8a:	lea    r10,[r9+0x4]
  40aa8e:	vxorpd xmm0,xmm0,xmm0
  40aa92:	movzx  edx,dl
  40aa95:	vcvtsi2sd xmm0,xmm0,rdx
  40aa9a:	vsubsd xmm0,xmm1,xmm0
  40aa9e:	vmulsd xmm1,xmm0,xmm15
  40aaa3:	vcvttsd2si rdx,xmm1
  40aaa8:	mov    r11b,dl
  40aaab:	add    r11b,0x30
  40aaaf:	mov    BYTE PTR [r9+0xc],r11b
  40aab3:	vxorpd xmm0,xmm0,xmm0
  40aab7:	movzx  edx,dl
  40aaba:	vcvtsi2sd xmm0,xmm0,rdx
  40aabf:	vsubsd xmm0,xmm1,xmm0
  40aac3:	vmulsd xmm1,xmm0,xmm15
  40aac8:	vcvttsd2si rdx,xmm1
  40aacd:	mov    r11b,dl
  40aad0:	add    r11b,0x30
  40aad4:	mov    BYTE PTR [r9+0xd],r11b
  40aad8:	lea    r10,[r10+0x2]
  40aadc:	vxorpd xmm0,xmm0,xmm0
  40aae0:	movzx  edx,dl
  40aae3:	vcvtsi2sd xmm0,xmm0,rdx
  40aae8:	vsubsd xmm0,xmm1,xmm0
  40aaec:	vmulsd xmm1,xmm0,xmm15
  40aaf1:	vcvttsd2si rdx,xmm1
  40aaf6:	mov    r11b,dl
  40aaf9:	add    r11b,0x30
  40aafd:	mov    BYTE PTR [r9+0xe],r11b
  40ab01:	vxorpd xmm0,xmm0,xmm0
  40ab05:	movzx  edx,dl
  40ab08:	vcvtsi2sd xmm0,xmm0,rdx
  40ab0d:	vsubsd xmm0,xmm1,xmm0
  40ab11:	vmulsd xmm1,xmm0,xmm15
  40ab16:	vcvttsd2si rdx,xmm1
  40ab1b:	mov    r11b,dl
  40ab1e:	add    r11b,0x30
  40ab22:	mov    BYTE PTR [r9+0xf],r11b
  40ab26:	lea    r10,[r10+0x2]
  40ab2a:	lea    r10,[r10+0x2]
  40ab2e:	lea    r10,[r10+0x2]
  40ab32:	lea    r10,[r10+0x2]
  40ab36:	lea    r10,[r10+0x2]
  40ab3a:	vxorpd xmm0,xmm0,xmm0
  40ab3e:	movzx  edx,dl
  40ab41:	vcvtsi2sd xmm0,xmm0,rdx
  40ab46:	vsubsd xmm0,xmm1,xmm0
  40ab4a:	vmulsd xmm1,xmm0,xmm15
  40ab4f:	vcvttsd2si rdx,xmm1
  40ab54:	mov    r11b,dl
  40ab57:	add    r11b,0x30
  40ab5b:	mov    BYTE PTR [r9+0x10],r11b
  40ab5f:	vxorpd xmm0,xmm0,xmm0
  40ab63:	movzx  edx,dl
  40ab66:	vcvtsi2sd xmm0,xmm0,rdx
  40ab6b:	vsubsd xmm0,xmm1,xmm0
  40ab6f:	vmulsd xmm1,xmm0,xmm15
  40ab74:	vcvttsd2si rdx,xmm1
  40ab79:	add    dl,0x30
  40ab7c:	mov    BYTE PTR [r9+0x11],dl
  40ab80:	mov    BYTE PTR [r10+0x2],0x65
  40ab85:	lea    r9,[r10+0x3]
  40ab89:	test   r8,r8
  40ab8c:	jl     40ab95 <__swc_fn_65555ab2_000150_6203dca2+0x695>
  40ab8e:	mov    BYTE PTR [r9],0x2b
  40ab92:	inc    r9
  40ab95:	mov    r10,r9
  40ab98:	mov    rdx,r8
  40ab9b:	nop    DWORD PTR [rax+rax*1+0x0]
  40aba0:	mov    r11,rdx
  40aba3:	movabs rdx,0x6666666666666667
  40abad:	mov    rax,r11
  40abb0:	imul   rdx
  40abb3:	sar    rdx,0x2
  40abb7:	mov    r12,rdx
  40abba:	shr    rdx,0x3f
  40abbe:	add    r12,rdx
  40abc1:	mov    rdx,r12
  40abc4:	imul   r13,r12,0xa
  40abc8:	sub    r11,r13
  40abcb:	mov    r13,QWORD PTR [rip+0x8c3e]        # 413810 <__swc_rdata_base_65555ab2+0x700>
  40abd2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40abd7:	mov    BYTE PTR [r10],r11b
  40abda:	lea    r11,[r10+0x1]
  40abde:	mov    r10,r11
  40abe1:	test   r12,r12
  40abe4:	jne    40aba0 <__swc_fn_65555ab2_000150_6203dca2+0x6a0>
  40abe6:	test   r8,r8
  40abe9:	jge    40abf3 <__swc_fn_65555ab2_000150_6203dca2+0x6f3>
  40abeb:	mov    BYTE PTR [r11],0x2d
  40abef:	lea    r10,[r11+0x1]
  40abf3:	mov    BYTE PTR [r10],0x0
  40abf7:	sub    r10,0x1
  40abfb:	nop    DWORD PTR [rax+rax*1+0x0]
  40ac00:	cmp    r9,r10
  40ac03:	jae    40ae58 <__swc_fn_65555ab2_000150_6203dca2+0x958>
  40ac09:	mov    al,BYTE PTR [r10]
  40ac0c:	mov    dl,BYTE PTR [r9]
  40ac0f:	mov    BYTE PTR [r10],dl
  40ac12:	sub    r10,0x1
  40ac16:	mov    BYTE PTR [r9],al
  40ac19:	inc    r9
  40ac1c:	jmp    40ac00 <__swc_fn_65555ab2_000150_6203dca2+0x700>
  40ac1e:	vcvttsd2si rdx,xmm1
  40ac23:	mov    r8,rdx
  40ac26:	vxorpd xmm0,xmm0,xmm0
  40ac2a:	vcvtsi2sd xmm0,xmm0,rdx
  40ac2f:	vsubsd xmm0,xmm1,xmm0
  40ac33:	mov    r9d,0x8
  40ac39:	vxorpd xmm2,xmm2,xmm2
  40ac3d:	vcomisd xmm2,xmm0
  40ac41:	jbe    40ac4b <__swc_fn_65555ab2_000150_6203dca2+0x74b>
  40ac43:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x8bd5]        # 413820 <__swc_rdata_base_65555ab2+0x710>
  40ac4b:	test   r9d,r9d
  40ac4e:	je     40ac5a <__swc_fn_65555ab2_000150_6203dca2+0x75a>
  40ac50:	vmulsd xmm0,xmm0,xmm14
  40ac55:	dec    r9d
  40ac58:	jne    40ac50 <__swc_fn_65555ab2_000150_6203dca2+0x750>
  40ac5a:	vcvttsd2si r9,xmm0
  40ac5f:	mov    r10,r9
  40ac62:	vxorpd xmm2,xmm2,xmm2
  40ac66:	vcvtsi2sd xmm2,xmm2,r9
  40ac6b:	vsubsd xmm0,xmm0,xmm2
  40ac6f:	vcomisd xmm0,xmm10
  40ac74:	lea    r9,[r9+0x1]
  40ac78:	cmova  r10,r9
  40ac7c:	cmp    r10,0x5f5e100
  40ac83:	jne    40ac9c <__swc_fn_65555ab2_000150_6203dca2+0x79c>
  40ac85:	lea    r8,[rdx-0x1]
  40ac89:	vxorpd xmm0,xmm0,xmm0
  40ac8d:	vcomisd xmm0,xmm1
  40ac91:	lea    rdx,[rdx+0x1]
  40ac95:	cmovbe r8,rdx
  40ac99:	xor    r10d,r10d
  40ac9c:	mov    r9,rcx
  40ac9f:	test   r8,r8
  40aca2:	jne    40acc2 <__swc_fn_65555ab2_000150_6203dca2+0x7c2>
  40aca4:	vxorpd xmm0,xmm0,xmm0
  40aca8:	vcomisd xmm0,xmm1
  40acac:	jbe    40acb5 <__swc_fn_65555ab2_000150_6203dca2+0x7b5>
  40acae:	mov    BYTE PTR [rcx],0x2d
  40acb1:	lea    r9,[rcx+0x1]
  40acb5:	mov    BYTE PTR [r9],0x30
  40acb9:	add    r9,0x1
  40acbd:	jmp    40ad5b <__swc_fn_65555ab2_000150_6203dca2+0x85b>
  40acc2:	mov    r9,rcx
  40acc5:	mov    rdx,r8
  40acc8:	nop    DWORD PTR [rax+rax*1+0x0]
  40acd0:	mov    r11,rdx
  40acd3:	movabs rdx,0x6666666666666667
  40acdd:	mov    r15,rax
  40ace0:	mov    rax,r11
  40ace3:	imul   rdx
  40ace6:	mov    r12,rdx
  40ace9:	mov    rax,r15
  40acec:	sar    r12,0x2
  40acf0:	mov    rdx,r12
  40acf3:	shr    rdx,0x3f
  40acf7:	add    r12,rdx
  40acfa:	mov    rdx,r12
  40acfd:	imul   r13,r12,0xa
  40ad01:	sub    r11,r13
  40ad04:	mov    r13,QWORD PTR [rip+0x8b05]        # 413810 <__swc_rdata_base_65555ab2+0x700>
  40ad0b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40ad10:	mov    BYTE PTR [r9],r11b
  40ad13:	lea    r11,[r9+0x1]
  40ad17:	mov    r9,r11
  40ad1a:	test   r12,r12
  40ad1d:	jne    40acd0 <__swc_fn_65555ab2_000150_6203dca2+0x7d0>
  40ad1f:	test   r8,r8
  40ad22:	jge    40ad2c <__swc_fn_65555ab2_000150_6203dca2+0x82c>
  40ad24:	mov    BYTE PTR [r11],0x2d
  40ad28:	lea    r9,[r11+0x1]
  40ad2c:	mov    rdx,r9
  40ad2f:	mov    BYTE PTR [r9],0x0
  40ad33:	sub    r9,0x1
  40ad37:	mov    r8,rcx
  40ad3a:	cmp    r8,r9
  40ad3d:	jae    40ad58 <__swc_fn_65555ab2_000150_6203dca2+0x858>
  40ad3f:	nop
  40ad40:	mov    r11b,BYTE PTR [r9]
  40ad43:	mov    r12b,BYTE PTR [r8]
  40ad46:	mov    BYTE PTR [r9],r12b
  40ad49:	sub    r9,0x1
  40ad4d:	mov    BYTE PTR [r8],r11b
  40ad50:	inc    r8
  40ad53:	cmp    r8,r9
  40ad56:	jb     40ad40 <__swc_fn_65555ab2_000150_6203dca2+0x840>
  40ad58:	mov    r9,rdx
  40ad5b:	mov    BYTE PTR [r9],0x2e
  40ad5f:	add    r9,0x1
  40ad63:	xor    r8d,r8d
  40ad66:	test   r10,r10
  40ad69:	je     40adaf <__swc_fn_65555ab2_000150_6203dca2+0x8af>
  40ad6b:	mov    r11d,0x989680
  40ad71:	cmp    r10,r11
  40ad74:	jge    40adaf <__swc_fn_65555ab2_000150_6203dca2+0x8af>
  40ad76:	cs nop WORD PTR [rax+rax*1+0x0]
  40ad80:	inc    r8d
  40ad83:	movabs rdx,0x6666666666666667
  40ad8d:	mov    r15,rax
  40ad90:	mov    rax,r11
  40ad93:	imul   rdx
  40ad96:	mov    r11,rdx
  40ad99:	mov    rax,r15
  40ad9c:	sar    r11,0x2
  40ada0:	mov    rdx,r11
  40ada3:	shr    rdx,0x3f
  40ada7:	add    r11,rdx
  40adaa:	cmp    r10,r11
  40adad:	jl     40ad80 <__swc_fn_65555ab2_000150_6203dca2+0x880>
  40adaf:	test   r8d,r8d
  40adb2:	je     40adcd <__swc_fn_65555ab2_000150_6203dca2+0x8cd>
  40adb4:	cs nop WORD PTR [rax+rax*1+0x0]
  40adbe:	xchg   ax,ax
  40adc0:	mov    BYTE PTR [r9],0x30
  40adc4:	add    r9,0x1
  40adc8:	dec    r8d
  40adcb:	jne    40adc0 <__swc_fn_65555ab2_000150_6203dca2+0x8c0>
  40adcd:	mov    r8,r9
  40add0:	mov    rdx,r10
  40add3:	cs nop WORD PTR [rax+rax*1+0x0]
  40addd:	nop    DWORD PTR [rax]
  40ade0:	mov    r11,rdx
  40ade3:	movabs rdx,0x6666666666666667
  40aded:	mov    rax,r11
  40adf0:	imul   rdx
  40adf3:	sar    rdx,0x2
  40adf7:	mov    r12,rdx
  40adfa:	shr    rdx,0x3f
  40adfe:	add    r12,rdx
  40ae01:	mov    rdx,r12
  40ae04:	imul   r13,r12,0xa
  40ae08:	sub    r11,r13
  40ae0b:	mov    r13,QWORD PTR [rip+0x89fe]        # 413810 <__swc_rdata_base_65555ab2+0x700>
  40ae12:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40ae17:	mov    BYTE PTR [r8],r11b
  40ae1a:	lea    r11,[r8+0x1]
  40ae1e:	mov    r8,r11
  40ae21:	test   r12,r12
  40ae24:	jne    40ade0 <__swc_fn_65555ab2_000150_6203dca2+0x8e0>
  40ae26:	test   r10,r10
  40ae29:	jge    40ae33 <__swc_fn_65555ab2_000150_6203dca2+0x933>
  40ae2b:	mov    BYTE PTR [r11],0x2d
  40ae2f:	lea    r8,[r11+0x1]
  40ae33:	mov    BYTE PTR [r8],0x0
  40ae37:	sub    r8,0x1
  40ae3b:	cmp    r9,r8
  40ae3e:	jae    40ae58 <__swc_fn_65555ab2_000150_6203dca2+0x958>
  40ae40:	mov    al,BYTE PTR [r8]
  40ae43:	mov    dl,BYTE PTR [r9]
  40ae46:	mov    BYTE PTR [r8],dl
  40ae49:	sub    r8,0x1
  40ae4d:	mov    BYTE PTR [r9],al
  40ae50:	inc    r9
  40ae53:	cmp    r9,r8
  40ae56:	jb     40ae40 <__swc_fn_65555ab2_000150_6203dca2+0x940>
  40ae58:	xor    eax,eax
  40ae5a:	test   rcx,rcx
  40ae5d:	je     40ae90 <__swc_fn_65555ab2_000150_6203dca2+0x990>
  40ae5f:	mov    rdx,rcx
  40ae62:	mov    r8b,BYTE PTR [rdx]
  40ae65:	test   r8b,r8b
  40ae68:	je     40ae90 <__swc_fn_65555ab2_000150_6203dca2+0x990>
  40ae6a:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae74:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae7e:	xchg   ax,ax
  40ae80:	add    rdx,0x1
  40ae84:	add    rax,0x1
  40ae88:	mov    r8b,BYTE PTR [rdx]
  40ae8b:	test   r8b,r8b
  40ae8e:	jne    40ae80 <__swc_fn_65555ab2_000150_6203dca2+0x980>
  40ae90:	mov    QWORD PTR [rsp+0x240],rcx
  40ae98:	mov    QWORD PTR [rsp+0x248],rax
  40aea0:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  40aea9:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  40aeb2:	lea    rcx,[rsp+0x250]
  40aeba:	call   409c90 <__swc_fn_65555ab2_000120_2648f149>
  40aebf:	jmp    40b5c5 <__swc_fn_65555ab2_000150_6203dca2+0x10c5>
  40aec4:	lea    rcx,[rsp+0x260]
  40aecc:	vxorps xmm0,xmm0,xmm0
  40aed0:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  40aed9:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  40aee2:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  40aeeb:	vzeroupper
  40aeee:	mov    DWORD PTR [rsp+0x2c0],0x0
  40aef9:	vmovsd xmm0,QWORD PTR [rdx]
  40aefd:	vcomisd xmm0,xmm0
  40af01:	setne  dl
  40af04:	movzx  edx,dl
  40af07:	setp   r8b
  40af0b:	movzx  r8d,r8b
  40af0f:	or     edx,r8d
  40af12:	test   dl,dl
  40af14:	je     40af21 <__swc_fn_65555ab2_000150_6203dca2+0xa21>
  40af16:	mov    DWORD PTR [rcx],0x6e616e
  40af1c:	jmp    40b528 <__swc_fn_65555ab2_000150_6203dca2+0x1028>
  40af21:	vcomisd xmm0,xmm11
  40af26:	ja     40af37 <__swc_fn_65555ab2_000150_6203dca2+0xa37>
  40af28:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  40af31:	vcomisd xmm6,xmm0
  40af35:	jbe    40af5b <__swc_fn_65555ab2_000150_6203dca2+0xa5b>
  40af37:	vxorpd xmm1,xmm1,xmm1
  40af3b:	vcomisd xmm1,xmm0
  40af3f:	jbe    40af50 <__swc_fn_65555ab2_000150_6203dca2+0xa50>
  40af41:	mov    DWORD PTR [rcx],0x666e692d
  40af47:	mov    BYTE PTR [rcx+0x4],0x0
  40af4b:	jmp    40b528 <__swc_fn_65555ab2_000150_6203dca2+0x1028>
  40af50:	mov    DWORD PTR [rcx],0x666e69
  40af56:	jmp    40b528 <__swc_fn_65555ab2_000150_6203dca2+0x1028>
  40af5b:	vcomisd xmm0,xmm13
  40af60:	jae    40af6c <__swc_fn_65555ab2_000150_6203dca2+0xa6c>
  40af62:	vcomisd xmm12,xmm0
  40af66:	jbe    40b2ce <__swc_fn_65555ab2_000150_6203dca2+0xdce>
  40af6c:	vmovups xmm1,xmm0
  40af70:	vxorpd xmm2,xmm2,xmm2
  40af74:	vcomisd xmm2,xmm0
  40af78:	jbe    40af88 <__swc_fn_65555ab2_000150_6203dca2+0xa88>
  40af7a:	vmovsd xmm0,xmm0,xmm1
  40af7e:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x889a]        # 413820 <__swc_rdata_base_65555ab2+0x710>
  40af86:	jmp    40af8c <__swc_fn_65555ab2_000150_6203dca2+0xa8c>
  40af88:	vmovsd xmm0,xmm0,xmm1
  40af8c:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  40af95:	xor    r8d,r8d
  40af98:	vcomisd xmm0,xmm6
  40af9c:	jb     40afae <__swc_fn_65555ab2_000150_6203dca2+0xaae>
  40af9e:	xchg   ax,ax
  40afa0:	vdivsd xmm0,xmm0,xmm6
  40afa4:	add    r8,0x1
  40afa8:	vcomisd xmm0,xmm6
  40afac:	jae    40afa0 <__swc_fn_65555ab2_000150_6203dca2+0xaa0>
  40afae:	mov    r9,rcx
  40afb1:	vxorpd xmm2,xmm2,xmm2
  40afb5:	vcomisd xmm2,xmm1
  40afb9:	jbe    40afc2 <__swc_fn_65555ab2_000150_6203dca2+0xac2>
  40afbb:	mov    BYTE PTR [rcx],0x2d
  40afbe:	lea    r9,[rcx+0x1]
  40afc2:	vcvttsd2si rdx,xmm0
  40afc7:	mov    r10b,dl
  40afca:	add    r10b,0x30
  40afce:	mov    BYTE PTR [r9],r10b
  40afd1:	vxorpd xmm1,xmm1,xmm1
  40afd5:	movzx  edx,dl
  40afd8:	vcvtsi2sd xmm1,xmm1,rdx
  40afdd:	vsubsd xmm0,xmm0,xmm1
  40afe1:	vmulsd xmm0,xmm0,xmm6
  40afe5:	mov    BYTE PTR [r9+0x1],0x2e
  40afea:	vcvttsd2si rdx,xmm0
  40afef:	mov    r10b,dl
  40aff2:	add    r10b,0x30
  40aff6:	mov    BYTE PTR [r9+0x2],r10b
  40affa:	vxorpd xmm1,xmm1,xmm1
  40affe:	movzx  edx,dl
  40b001:	vcvtsi2sd xmm1,xmm1,rdx
  40b006:	vsubsd xmm0,xmm0,xmm1
  40b00a:	vmulsd xmm0,xmm0,xmm6
  40b00e:	vcvttsd2si rdx,xmm0
  40b013:	mov    r10b,dl
  40b016:	add    r10b,0x30
  40b01a:	mov    BYTE PTR [r9+0x3],r10b
  40b01e:	vxorpd xmm1,xmm1,xmm1
  40b022:	movzx  edx,dl
  40b025:	vcvtsi2sd xmm1,xmm1,rdx
  40b02a:	vsubsd xmm0,xmm0,xmm1
  40b02e:	vmulsd xmm0,xmm0,xmm6
  40b032:	vcvttsd2si rdx,xmm0
  40b037:	mov    r10b,dl
  40b03a:	add    r10b,0x30
  40b03e:	mov    BYTE PTR [r9+0x4],r10b
  40b042:	vxorpd xmm1,xmm1,xmm1
  40b046:	movzx  edx,dl
  40b049:	vcvtsi2sd xmm1,xmm1,rdx
  40b04e:	vsubsd xmm0,xmm0,xmm1
  40b052:	vmulsd xmm0,xmm0,xmm6
  40b056:	vcvttsd2si rdx,xmm0
  40b05b:	mov    r10b,dl
  40b05e:	add    r10b,0x30
  40b062:	mov    BYTE PTR [r9+0x5],r10b
  40b066:	vxorpd xmm1,xmm1,xmm1
  40b06a:	movzx  edx,dl
  40b06d:	vcvtsi2sd xmm1,xmm1,rdx
  40b072:	vsubsd xmm0,xmm0,xmm1
  40b076:	vmulsd xmm0,xmm0,xmm6
  40b07a:	vcvttsd2si rdx,xmm0
  40b07f:	mov    r10b,dl
  40b082:	add    r10b,0x30
  40b086:	mov    BYTE PTR [r9+0x6],r10b
  40b08a:	vxorpd xmm1,xmm1,xmm1
  40b08e:	movzx  edx,dl
  40b091:	vcvtsi2sd xmm1,xmm1,rdx
  40b096:	vsubsd xmm0,xmm0,xmm1
  40b09a:	vmulsd xmm0,xmm0,xmm6
  40b09e:	vcvttsd2si rdx,xmm0
  40b0a3:	mov    r10b,dl
  40b0a6:	add    r10b,0x30
  40b0aa:	mov    BYTE PTR [r9+0x7],r10b
  40b0ae:	vxorpd xmm1,xmm1,xmm1
  40b0b2:	movzx  edx,dl
  40b0b5:	vcvtsi2sd xmm1,xmm1,rdx
  40b0ba:	vsubsd xmm0,xmm0,xmm1
  40b0be:	vmulsd xmm0,xmm0,xmm6
  40b0c2:	vcvttsd2si rdx,xmm0
  40b0c7:	mov    r10b,dl
  40b0ca:	add    r10b,0x30
  40b0ce:	mov    BYTE PTR [r9+0x8],r10b
  40b0d2:	vxorpd xmm1,xmm1,xmm1
  40b0d6:	movzx  edx,dl
  40b0d9:	vcvtsi2sd xmm1,xmm1,rdx
  40b0de:	vsubsd xmm0,xmm0,xmm1
  40b0e2:	vmulsd xmm0,xmm0,xmm6
  40b0e6:	vcvttsd2si rdx,xmm0
  40b0eb:	mov    r10b,dl
  40b0ee:	add    r10b,0x30
  40b0f2:	mov    BYTE PTR [r9+0x9],r10b
  40b0f6:	vxorpd xmm1,xmm1,xmm1
  40b0fa:	movzx  edx,dl
  40b0fd:	vcvtsi2sd xmm1,xmm1,rdx
  40b102:	vsubsd xmm0,xmm0,xmm1
  40b106:	vmulsd xmm0,xmm0,xmm6
  40b10a:	vcvttsd2si rdx,xmm0
  40b10f:	mov    r10b,dl
  40b112:	add    r10b,0x30
  40b116:	mov    BYTE PTR [r9+0xa],r10b
  40b11a:	vxorpd xmm1,xmm1,xmm1
  40b11e:	movzx  edx,dl
  40b121:	vcvtsi2sd xmm1,xmm1,rdx
  40b126:	vsubsd xmm0,xmm0,xmm1
  40b12a:	vmulsd xmm0,xmm0,xmm6
  40b12e:	vcvttsd2si rdx,xmm0
  40b133:	mov    r10b,dl
  40b136:	add    r10b,0x30
  40b13a:	mov    BYTE PTR [r9+0xb],r10b
  40b13e:	lea    r10,[r9+0x4]
  40b142:	vxorpd xmm1,xmm1,xmm1
  40b146:	movzx  edx,dl
  40b149:	vcvtsi2sd xmm1,xmm1,rdx
  40b14e:	vsubsd xmm0,xmm0,xmm1
  40b152:	vmulsd xmm0,xmm0,xmm6
  40b156:	vcvttsd2si rdx,xmm0
  40b15b:	mov    r11b,dl
  40b15e:	add    r11b,0x30
  40b162:	mov    BYTE PTR [r9+0xc],r11b
  40b166:	vxorpd xmm1,xmm1,xmm1
  40b16a:	movzx  edx,dl
  40b16d:	vcvtsi2sd xmm1,xmm1,rdx
  40b172:	vsubsd xmm0,xmm0,xmm1
  40b176:	vmulsd xmm0,xmm0,xmm6
  40b17a:	vcvttsd2si rdx,xmm0
  40b17f:	mov    r11b,dl
  40b182:	add    r11b,0x30
  40b186:	mov    BYTE PTR [r9+0xd],r11b
  40b18a:	lea    r10,[r10+0x2]
  40b18e:	vxorpd xmm1,xmm1,xmm1
  40b192:	movzx  edx,dl
  40b195:	vcvtsi2sd xmm1,xmm1,rdx
  40b19a:	vsubsd xmm0,xmm0,xmm1
  40b19e:	vmulsd xmm0,xmm0,xmm6
  40b1a2:	vcvttsd2si rdx,xmm0
  40b1a7:	mov    r11b,dl
  40b1aa:	add    r11b,0x30
  40b1ae:	mov    BYTE PTR [r9+0xe],r11b
  40b1b2:	vxorpd xmm1,xmm1,xmm1
  40b1b6:	movzx  edx,dl
  40b1b9:	vcvtsi2sd xmm1,xmm1,rdx
  40b1be:	vsubsd xmm0,xmm0,xmm1
  40b1c2:	vmulsd xmm0,xmm0,xmm6
  40b1c6:	vcvttsd2si rdx,xmm0
  40b1cb:	mov    r11b,dl
  40b1ce:	add    r11b,0x30
  40b1d2:	mov    BYTE PTR [r9+0xf],r11b
  40b1d6:	lea    r10,[r10+0x2]
  40b1da:	lea    r10,[r10+0x2]
  40b1de:	lea    r10,[r10+0x2]
  40b1e2:	lea    r10,[r10+0x2]
  40b1e6:	lea    r10,[r10+0x2]
  40b1ea:	vxorpd xmm1,xmm1,xmm1
  40b1ee:	movzx  edx,dl
  40b1f1:	vcvtsi2sd xmm1,xmm1,rdx
  40b1f6:	vsubsd xmm0,xmm0,xmm1
  40b1fa:	vmulsd xmm0,xmm0,xmm6
  40b1fe:	vcvttsd2si rdx,xmm0
  40b203:	mov    r11b,dl
  40b206:	add    r11b,0x30
  40b20a:	mov    BYTE PTR [r9+0x10],r11b
  40b20e:	vxorpd xmm1,xmm1,xmm1
  40b212:	movzx  edx,dl
  40b215:	vcvtsi2sd xmm1,xmm1,rdx
  40b21a:	vsubsd xmm0,xmm0,xmm1
  40b21e:	vmulsd xmm0,xmm0,xmm6
  40b222:	vcvttsd2si rdx,xmm0
  40b227:	add    dl,0x30
  40b22a:	mov    BYTE PTR [r9+0x11],dl
  40b22e:	mov    BYTE PTR [r10+0x2],0x65
  40b233:	lea    r9,[r10+0x3]
  40b237:	test   r8,r8
  40b23a:	jl     40b243 <__swc_fn_65555ab2_000150_6203dca2+0xd43>
  40b23c:	mov    BYTE PTR [r9],0x2b
  40b240:	inc    r9
  40b243:	mov    r10,r9
  40b246:	mov    rdx,r8
  40b249:	nop    DWORD PTR [rax+0x0]
  40b250:	mov    r11,rdx
  40b253:	movabs rdx,0x6666666666666667
  40b25d:	mov    rax,r11
  40b260:	imul   rdx
  40b263:	sar    rdx,0x2
  40b267:	mov    r12,rdx
  40b26a:	shr    rdx,0x3f
  40b26e:	add    r12,rdx
  40b271:	mov    rdx,r12
  40b274:	imul   r13,r12,0xa
  40b278:	sub    r11,r13
  40b27b:	mov    r13,QWORD PTR [rip+0x858e]        # 413810 <__swc_rdata_base_65555ab2+0x700>
  40b282:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b287:	mov    BYTE PTR [r10],r11b
  40b28a:	lea    r11,[r10+0x1]
  40b28e:	mov    r10,r11
  40b291:	test   r12,r12
  40b294:	jne    40b250 <__swc_fn_65555ab2_000150_6203dca2+0xd50>
  40b296:	test   r8,r8
  40b299:	jge    40b2a3 <__swc_fn_65555ab2_000150_6203dca2+0xda3>
  40b29b:	mov    BYTE PTR [r11],0x2d
  40b29f:	lea    r10,[r11+0x1]
  40b2a3:	mov    BYTE PTR [r10],0x0
  40b2a7:	sub    r10,0x1
  40b2ab:	nop    DWORD PTR [rax+rax*1+0x0]
  40b2b0:	cmp    r9,r10
  40b2b3:	jae    40b528 <__swc_fn_65555ab2_000150_6203dca2+0x1028>
  40b2b9:	mov    al,BYTE PTR [r10]
  40b2bc:	mov    dl,BYTE PTR [r9]
  40b2bf:	mov    BYTE PTR [r10],dl
  40b2c2:	sub    r10,0x1
  40b2c6:	mov    BYTE PTR [r9],al
  40b2c9:	inc    r9
  40b2cc:	jmp    40b2b0 <__swc_fn_65555ab2_000150_6203dca2+0xdb0>
  40b2ce:	vcvttsd2si rdx,xmm0
  40b2d3:	mov    r8,rdx
  40b2d6:	vxorpd xmm1,xmm1,xmm1
  40b2da:	vcvtsi2sd xmm1,xmm1,rdx
  40b2df:	vsubsd xmm1,xmm0,xmm1
  40b2e3:	mov    r9d,0x8
  40b2e9:	vxorpd xmm2,xmm2,xmm2
  40b2ed:	vcomisd xmm2,xmm1
  40b2f1:	ja     40b2fe <__swc_fn_65555ab2_000150_6203dca2+0xdfe>
  40b2f3:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40b2fc:	jmp    40b30f <__swc_fn_65555ab2_000150_6203dca2+0xe0f>
  40b2fe:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x851a]        # 413820 <__swc_rdata_base_65555ab2+0x710>
  40b306:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  40b30f:	test   r9d,r9d
  40b312:	je     40b329 <__swc_fn_65555ab2_000150_6203dca2+0xe29>
  40b314:	cs nop WORD PTR [rax+rax*1+0x0]
  40b31e:	xchg   ax,ax
  40b320:	vmulsd xmm1,xmm1,xmm6
  40b324:	dec    r9d
  40b327:	jne    40b320 <__swc_fn_65555ab2_000150_6203dca2+0xe20>
  40b329:	vcvttsd2si r9,xmm1
  40b32e:	mov    r10,r9
  40b331:	vxorpd xmm2,xmm2,xmm2
  40b335:	vcvtsi2sd xmm2,xmm2,r9
  40b33a:	vsubsd xmm1,xmm1,xmm2
  40b33e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  40b347:	vcomisd xmm1,xmm6
  40b34b:	lea    r9,[r9+0x1]
  40b34f:	cmova  r10,r9
  40b353:	cmp    r10,0x5f5e100
  40b35a:	jne    40b373 <__swc_fn_65555ab2_000150_6203dca2+0xe73>
  40b35c:	lea    r8,[rdx-0x1]
  40b360:	vxorpd xmm1,xmm1,xmm1
  40b364:	vcomisd xmm1,xmm0
  40b368:	lea    rdx,[rdx+0x1]
  40b36c:	cmovbe r8,rdx
  40b370:	xor    r10d,r10d
  40b373:	mov    r9,rcx
  40b376:	test   r8,r8
  40b379:	jne    40b399 <__swc_fn_65555ab2_000150_6203dca2+0xe99>
  40b37b:	vxorpd xmm1,xmm1,xmm1
  40b37f:	vcomisd xmm1,xmm0
  40b383:	jbe    40b38c <__swc_fn_65555ab2_000150_6203dca2+0xe8c>
  40b385:	mov    BYTE PTR [rcx],0x2d
  40b388:	lea    r9,[rcx+0x1]
  40b38c:	mov    BYTE PTR [r9],0x30
  40b390:	add    r9,0x1
  40b394:	jmp    40b42b <__swc_fn_65555ab2_000150_6203dca2+0xf2b>
  40b399:	mov    r9,rcx
  40b39c:	mov    rdx,r8
  40b39f:	nop
  40b3a0:	mov    r11,rdx
  40b3a3:	movabs rdx,0x6666666666666667
  40b3ad:	mov    r15,rax
  40b3b0:	mov    rax,r11
  40b3b3:	imul   rdx
  40b3b6:	mov    r12,rdx
  40b3b9:	mov    rax,r15
  40b3bc:	sar    r12,0x2
  40b3c0:	mov    rdx,r12
  40b3c3:	shr    rdx,0x3f
  40b3c7:	add    r12,rdx
  40b3ca:	mov    rdx,r12
  40b3cd:	imul   r13,r12,0xa
  40b3d1:	sub    r11,r13
  40b3d4:	mov    r13,QWORD PTR [rip+0x8435]        # 413810 <__swc_rdata_base_65555ab2+0x700>
  40b3db:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b3e0:	mov    BYTE PTR [r9],r11b
  40b3e3:	lea    r11,[r9+0x1]
  40b3e7:	mov    r9,r11
  40b3ea:	test   r12,r12
  40b3ed:	jne    40b3a0 <__swc_fn_65555ab2_000150_6203dca2+0xea0>
  40b3ef:	test   r8,r8
  40b3f2:	jge    40b3fc <__swc_fn_65555ab2_000150_6203dca2+0xefc>
  40b3f4:	mov    BYTE PTR [r11],0x2d
  40b3f8:	lea    r9,[r11+0x1]
  40b3fc:	mov    rdx,r9
  40b3ff:	mov    BYTE PTR [r9],0x0
  40b403:	sub    r9,0x1
  40b407:	mov    r8,rcx
  40b40a:	cmp    r8,r9
  40b40d:	jae    40b428 <__swc_fn_65555ab2_000150_6203dca2+0xf28>
  40b40f:	nop
  40b410:	mov    r11b,BYTE PTR [r9]
  40b413:	mov    r12b,BYTE PTR [r8]
  40b416:	mov    BYTE PTR [r9],r12b
  40b419:	sub    r9,0x1
  40b41d:	mov    BYTE PTR [r8],r11b
  40b420:	inc    r8
  40b423:	cmp    r8,r9
  40b426:	jb     40b410 <__swc_fn_65555ab2_000150_6203dca2+0xf10>
  40b428:	mov    r9,rdx
  40b42b:	mov    BYTE PTR [r9],0x2e
  40b42f:	add    r9,0x1
  40b433:	xor    r8d,r8d
  40b436:	test   r10,r10
  40b439:	je     40b47f <__swc_fn_65555ab2_000150_6203dca2+0xf7f>
  40b43b:	mov    r11d,0x989680
  40b441:	cmp    r10,r11
  40b444:	jge    40b47f <__swc_fn_65555ab2_000150_6203dca2+0xf7f>
  40b446:	cs nop WORD PTR [rax+rax*1+0x0]
  40b450:	inc    r8d
  40b453:	movabs rdx,0x6666666666666667
  40b45d:	mov    r15,rax
  40b460:	mov    rax,r11
  40b463:	imul   rdx
  40b466:	mov    r11,rdx
  40b469:	mov    rax,r15
  40b46c:	sar    r11,0x2
  40b470:	mov    rdx,r11
  40b473:	shr    rdx,0x3f
  40b477:	add    r11,rdx
  40b47a:	cmp    r10,r11
  40b47d:	jl     40b450 <__swc_fn_65555ab2_000150_6203dca2+0xf50>
  40b47f:	test   r8d,r8d
  40b482:	je     40b49d <__swc_fn_65555ab2_000150_6203dca2+0xf9d>
  40b484:	cs nop WORD PTR [rax+rax*1+0x0]
  40b48e:	xchg   ax,ax
  40b490:	mov    BYTE PTR [r9],0x30
  40b494:	add    r9,0x1
  40b498:	dec    r8d
  40b49b:	jne    40b490 <__swc_fn_65555ab2_000150_6203dca2+0xf90>
  40b49d:	mov    r8,r9
  40b4a0:	mov    rdx,r10
  40b4a3:	cs nop WORD PTR [rax+rax*1+0x0]
  40b4ad:	nop    DWORD PTR [rax]
  40b4b0:	mov    r11,rdx
  40b4b3:	movabs rdx,0x6666666666666667
  40b4bd:	mov    rax,r11
  40b4c0:	imul   rdx
  40b4c3:	sar    rdx,0x2
  40b4c7:	mov    r12,rdx
  40b4ca:	shr    rdx,0x3f
  40b4ce:	add    r12,rdx
  40b4d1:	mov    rdx,r12
  40b4d4:	imul   r13,r12,0xa
  40b4d8:	sub    r11,r13
  40b4db:	mov    r13,QWORD PTR [rip+0x832e]        # 413810 <__swc_rdata_base_65555ab2+0x700>
  40b4e2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  40b4e7:	mov    BYTE PTR [r8],r11b
  40b4ea:	lea    r11,[r8+0x1]
  40b4ee:	mov    r8,r11
  40b4f1:	test   r12,r12
  40b4f4:	jne    40b4b0 <__swc_fn_65555ab2_000150_6203dca2+0xfb0>
  40b4f6:	test   r10,r10
  40b4f9:	jge    40b503 <__swc_fn_65555ab2_000150_6203dca2+0x1003>
  40b4fb:	mov    BYTE PTR [r11],0x2d
  40b4ff:	lea    r8,[r11+0x1]
  40b503:	mov    BYTE PTR [r8],0x0
  40b507:	sub    r8,0x1
  40b50b:	cmp    r9,r8
  40b50e:	jae    40b528 <__swc_fn_65555ab2_000150_6203dca2+0x1028>
  40b510:	mov    al,BYTE PTR [r8]
  40b513:	mov    dl,BYTE PTR [r9]
  40b516:	mov    BYTE PTR [r8],dl
  40b519:	sub    r8,0x1
  40b51d:	mov    BYTE PTR [r9],al
  40b520:	inc    r9
  40b523:	cmp    r9,r8
  40b526:	jb     40b510 <__swc_fn_65555ab2_000150_6203dca2+0x1010>
  40b528:	xor    eax,eax
  40b52a:	test   rcx,rcx
  40b52d:	je     40b550 <__swc_fn_65555ab2_000150_6203dca2+0x1050>
  40b52f:	mov    rdx,rcx
  40b532:	mov    r8b,BYTE PTR [rdx]
  40b535:	test   r8b,r8b
  40b538:	je     40b550 <__swc_fn_65555ab2_000150_6203dca2+0x1050>
  40b53a:	nop    WORD PTR [rax+rax*1+0x0]
  40b540:	add    rdx,0x1
  40b544:	add    rax,0x1
  40b548:	mov    r8b,BYTE PTR [rdx]
  40b54b:	test   r8b,r8b
  40b54e:	jne    40b540 <__swc_fn_65555ab2_000150_6203dca2+0x1040>
  40b550:	mov    QWORD PTR [rsp+0x3f8],rcx
  40b558:	mov    QWORD PTR [rsp+0x400],rax
  40b560:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  40b569:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  40b572:	lea    rcx,[rsp+0x408]
  40b57a:	call   409c90 <__swc_fn_65555ab2_000120_2648f149>
  40b57f:	jmp    40b5c5 <__swc_fn_65555ab2_000150_6203dca2+0x10c5>
  40b581:	mov    rcx,rdx
  40b584:	call   409c90 <__swc_fn_65555ab2_000120_2648f149>
  40b589:	jmp    40b5c5 <__swc_fn_65555ab2_000150_6203dca2+0x10c5>
  40b58b:	mov    al,BYTE PTR [rdx]
  40b58d:	test   al,al
  40b58f:	je     40b59a <__swc_fn_65555ab2_000150_6203dca2+0x109a>
  40b591:	lea    rax,[rip+0x8298]        # 413830 <__swc_rdata_base_65555ab2+0x720>
  40b598:	jmp    40b5a1 <__swc_fn_65555ab2_000150_6203dca2+0x10a1>
  40b59a:	lea    rax,[rip+0x829f]        # 413840 <__swc_rdata_base_65555ab2+0x730>
  40b5a1:	mov    rcx,rax
  40b5a4:	call   409c90 <__swc_fn_65555ab2_000120_2648f149>
  40b5a9:	jmp    40b5c5 <__swc_fn_65555ab2_000150_6203dca2+0x10c5>
  40b5ab:	lea    rcx,[rip+0x829e]        # 413850 <__swc_rdata_base_65555ab2+0x740>
  40b5b2:	call   409c90 <__swc_fn_65555ab2_000120_2648f149>
  40b5b7:	jmp    40b5c5 <__swc_fn_65555ab2_000150_6203dca2+0x10c5>
  40b5b9:	lea    rcx,[rip+0x8290]        # 413850 <__swc_rdata_base_65555ab2+0x740>
  40b5c0:	call   409c90 <__swc_fn_65555ab2_000120_2648f149>
  40b5c5:	add    rdi,0x1
  40b5c9:	sub    rsi,0x1
  40b5cd:	vmovups xmm0,xmm12
  40b5d2:	vmovsd xmm6,QWORD PTR [rip+0x8286]        # 413860 <__swc_rdata_base_65555ab2+0x750>
  40b5da:	test   rsi,rsi
  40b5dd:	jne    40a610 <__swc_fn_65555ab2_000150_6203dca2+0x110>
  40b5e3:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  40b5ec:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  40b5f5:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  40b5fe:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  40b607:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  40b610:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  40b619:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  40b622:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  40b62b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  40b634:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  40b63d:	add    rsp,0x4e8
  40b644:	pop    r15
  40b646:	pop    r13
  40b648:	pop    r12
  40b64a:	pop    rdi
  40b64b:	pop    rsi
  40b64c:	pop    rbx
  40b64d:	ret
	...

000000000040b650 <__swc_fn_65555ab2_000153_86f1d437>:
  40b650:	vxorps xmm0,xmm0,xmm0
  40b654:	vmovups XMMWORD PTR [rcx],xmm0
  40b658:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b65d:	ret
	...

000000000040b660 <__swc_fn_65555ab2_000156_86f1d437>:
  40b660:	vxorps xmm0,xmm0,xmm0
  40b664:	vmovups XMMWORD PTR [rcx],xmm0
  40b668:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b66d:	vxorps xmm0,xmm0,xmm0
  40b671:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b676:	vmovups xmm0,XMMWORD PTR [rip+0x82f2]        # 413970 <__swc_rdata_base_65555ab2+0x860>
  40b67e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b683:	vxorps xmm0,xmm0,xmm0
  40b687:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40b68c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40b691:	vxorps xmm0,xmm0,xmm0
  40b695:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40b69a:	mov    QWORD PTR [rcx+0x70],0x0
  40b6a2:	ret
	...

000000000040b6b0 <__swc_fn_65555ab2_000159_86f1d437>:
  40b6b0:	vxorps xmm0,xmm0,xmm0
  40b6b4:	vmovups XMMWORD PTR [rcx],xmm0
  40b6b8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40b6bd:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40b6c2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40b6c7:	ret
	...

000000000040b6d0 <__swc_fn_65555ab2_000162_e36363a8>:
  40b6d0:	push   rsi
  40b6d1:	push   rdi
  40b6d2:	sub    rsp,0x8
  40b6d6:	mov    rsi,rcx
  40b6d9:	mov    rdi,QWORD PTR [rsi+0x50]
  40b6dd:	test   rdi,rdi
  40b6e0:	je     40b6e7 <__swc_fn_65555ab2_000162_e36363a8+0x17>
  40b6e2:	mov    rcx,rsi
  40b6e5:	call   rdi
  40b6e7:	mov    QWORD PTR [rsi+0x20],0x0
  40b6ef:	mov    rax,QWORD PTR [rsi+0x30]
  40b6f3:	test   rax,rax
  40b6f6:	je     40b724 <__swc_fn_65555ab2_000162_e36363a8+0x54>
  40b6f8:	nop    DWORD PTR [rax+rax*1+0x0]
  40b700:	mov    rdi,QWORD PTR [rax+0x8]
  40b704:	mov    rcx,rsi
  40b707:	mov    rdx,QWORD PTR [rax+0x10]
  40b70b:	mov    rax,QWORD PTR [rax+0x18]
  40b70f:	mov    r8,rax
  40b712:	call   40e870 <__swc_fn_65555ab2_000160_47b270e1>
  40b717:	mov    QWORD PTR [rsi+0x30],rdi
  40b71b:	mov    rax,QWORD PTR [rsi+0x30]
  40b71f:	test   rax,rax
  40b722:	jne    40b700 <__swc_fn_65555ab2_000162_e36363a8+0x30>
  40b724:	mov    QWORD PTR [rsi+0x38],0x0
  40b72c:	add    rsp,0x8
  40b730:	pop    rdi
  40b731:	pop    rsi
  40b732:	ret
	...

000000000040b740 <__swc_fn_65555ab2_000165_016ee66a>:
  40b740:	push   rbx
  40b741:	push   rsi
  40b742:	push   rdi
  40b743:	push   r12
  40b745:	sub    rsp,0x188
  40b74c:	mov    rbx,rcx
  40b74f:	lea    rsi,[rip+0x1b632]        # 426d88 <__swc_bss_base_65555ab2+0x2d48>
  40b756:	mov    rcx,rsi
  40b759:	call   40e280 <__swc_fn_65555ab2_000139_86bb0f90>
  40b75e:	mov    rax,QWORD PTR [rip+0x1b62b]        # 426d90 <__swc_bss_base_65555ab2+0x2d50>
  40b765:	mov    rdi,rax
  40b768:	test   rdi,rdi
  40b76b:	je     40b799 <__swc_fn_65555ab2_000165_016ee66a+0x59>
  40b76d:	nop    DWORD PTR [rax]
  40b770:	cmp    QWORD PTR [rdi+0x8],rbx
  40b774:	jne    40b78e <__swc_fn_65555ab2_000165_016ee66a+0x4e>
  40b776:	mov    rcx,rsi
  40b779:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40b77e:	mov    rax,rdi
  40b781:	add    rsp,0x188
  40b788:	pop    r12
  40b78a:	pop    rdi
  40b78b:	pop    rsi
  40b78c:	pop    rbx
  40b78d:	ret
  40b78e:	mov    rax,QWORD PTR [rdi]
  40b791:	mov    rdi,rax
  40b794:	test   rax,rax
  40b797:	jne    40b770 <__swc_fn_65555ab2_000165_016ee66a+0x30>
  40b799:	call   411860 <__swc_fn_65555ab2_000143_d299b428>
  40b79e:	mov    rdi,rax
  40b7a1:	test   rax,rax
  40b7a4:	jne    40b7bd <__swc_fn_65555ab2_000165_016ee66a+0x7d>
  40b7a6:	mov    rcx,rsi
  40b7a9:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40b7ae:	xor    eax,eax
  40b7b0:	add    rsp,0x188
  40b7b7:	pop    r12
  40b7b9:	pop    rdi
  40b7ba:	pop    rsi
  40b7bb:	pop    rbx
  40b7bc:	ret
  40b7bd:	lea    rax,[rsp+0x18]
  40b7c2:	mov    QWORD PTR [rax+0x10],0x0
  40b7ca:	mov    QWORD PTR [rax+0x18],0x0
  40b7d2:	mov    DWORD PTR [rax+0x20],0x0
  40b7d9:	mov    BYTE PTR [rax+0x24],0x0
  40b7dd:	mov    rax,QWORD PTR [rip+0x1b5ac]        # 426d90 <__swc_bss_base_65555ab2+0x2d50>
  40b7e4:	mov    QWORD PTR [rsp+0x18],rax
  40b7e9:	mov    QWORD PTR [rsp+0x20],rbx
  40b7ee:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40b7f4:	vmovups XMMWORD PTR [rdi],xmm0
  40b7f8:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40b7fe:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  40b803:	mov    rax,QWORD PTR [rsp+0x38]
  40b808:	mov    QWORD PTR [rdi+0x20],rax
  40b80c:	mov    QWORD PTR [rip+0x1b57d],rdi        # 426d90 <__swc_bss_base_65555ab2+0x2d50>
  40b813:	lea    rax,[rsp+0x40]
  40b818:	mov    QWORD PTR [rax],0x0
  40b81f:	mov    rcx,rbx
  40b822:	mov    rdx,rax
  40b825:	call   40e360 <__swc_fn_65555ab2_000145_1534de9a>
  40b82a:	mov    rbx,rax
  40b82d:	test   rax,rax
  40b830:	jne    40b84a <__swc_fn_65555ab2_000165_016ee66a+0x10a>
  40b832:	mov    rcx,rsi
  40b835:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40b83a:	mov    rax,rdi
  40b83d:	add    rsp,0x188
  40b844:	pop    r12
  40b846:	pop    rdi
  40b847:	pop    rsi
  40b848:	pop    rbx
  40b849:	ret
  40b84a:	lea    r12,[rsp+0x50]
  40b84f:	mov    QWORD PTR [r12],0x0
  40b857:	mov    rcx,rbx
  40b85a:	mov    rdx,QWORD PTR [rsp+0x40]
  40b85f:	mov    r8,r12
  40b862:	call   411910 <__swc_fn_65555ab2_000146_162f363d>
  40b867:	test   rax,rax
  40b86a:	jne    40b884 <__swc_fn_65555ab2_000165_016ee66a+0x144>
  40b86c:	mov    rcx,rsi
  40b86f:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40b874:	mov    rax,rdi
  40b877:	add    rsp,0x188
  40b87e:	pop    r12
  40b880:	pop    rdi
  40b881:	pop    rsi
  40b882:	pop    rbx
  40b883:	ret
  40b884:	cmp    QWORD PTR [r12],0x10
  40b889:	jb     40b98c <__swc_fn_65555ab2_000165_016ee66a+0x24c>
  40b88f:	mov    ecx,DWORD PTR [rax]
  40b891:	cmp    ecx,0x42445753
  40b897:	jne    40b98c <__swc_fn_65555ab2_000165_016ee66a+0x24c>
  40b89d:	mov    ecx,DWORD PTR [rax+0x4]
  40b8a0:	cmp    ecx,0x1
  40b8a3:	jne    40b98c <__swc_fn_65555ab2_000165_016ee66a+0x24c>
  40b8a9:	mov    ecx,DWORD PTR [rax+0x8]
  40b8ac:	mov    edx,DWORD PTR [rax+0xc]
  40b8af:	imul   r8,rcx,0x14
  40b8b3:	mov    r9,QWORD PTR [rsp+0x50]
  40b8b8:	sub    r9,0x10
  40b8bc:	cmp    r8,r9
  40b8bf:	ja     40b98c <__swc_fn_65555ab2_000165_016ee66a+0x24c>
  40b8c5:	lea    r8,[r8+0x10]
  40b8c9:	cmp    rdx,r8
  40b8cc:	jb     40b98c <__swc_fn_65555ab2_000165_016ee66a+0x24c>
  40b8d2:	mov    r8,QWORD PTR [rsp+0x50]
  40b8d7:	cmp    rdx,r8
  40b8da:	ja     40b98c <__swc_fn_65555ab2_000165_016ee66a+0x24c>
  40b8e0:	xor    r8d,r8d
  40b8e3:	test   rcx,rcx
  40b8e6:	jbe    40b9b2 <__swc_fn_65555ab2_000165_016ee66a+0x272>
  40b8ec:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  40b8f2:	cs nop WORD PTR [rax+rax*1+0x0]
  40b8fc:	nop    DWORD PTR [rax+0x0]
  40b900:	imul   r9,r8,0x14
  40b904:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  40b909:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  40b90e:	add    r10,r11
  40b911:	movabs r11,0x100000000
  40b91b:	cmp    r10,r11
  40b91e:	ja     40b98c <__swc_fn_65555ab2_000165_016ee66a+0x24c>
  40b920:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  40b925:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  40b92a:	test   r10d,r10d
  40b92d:	setne  r11b
  40b931:	je     40b94b <__swc_fn_65555ab2_000165_016ee66a+0x20b>
  40b933:	cmp    r10d,edx
  40b936:	setb   r11b
  40b93a:	jb     40b94b <__swc_fn_65555ab2_000165_016ee66a+0x20b>
  40b93c:	vmovq  r11,xmm1
  40b941:	cmp    r10,r11
  40b944:	setae  r10b
  40b948:	mov    r11b,r10b
  40b94b:	mov    r10,r11
  40b94e:	test   r11b,r11b
  40b951:	jne    40b978 <__swc_fn_65555ab2_000165_016ee66a+0x238>
  40b953:	test   r9d,r9d
  40b956:	setne  r10b
  40b95a:	je     40b978 <__swc_fn_65555ab2_000165_016ee66a+0x238>
  40b95c:	cmp    r9d,edx
  40b95f:	setb   r10b
  40b963:	jb     40b978 <__swc_fn_65555ab2_000165_016ee66a+0x238>
  40b965:	vmovq  r10,xmm1
  40b96a:	cmp    r9,r10
  40b96d:	setae  r9b
  40b971:	movzx  r9d,r9b
  40b975:	mov    r10b,r9b
  40b978:	test   r10b,r10b
  40b97b:	jne    40b98c <__swc_fn_65555ab2_000165_016ee66a+0x24c>
  40b97d:	add    r8,0x1
  40b981:	cmp    r8,rcx
  40b984:	jb     40b900 <__swc_fn_65555ab2_000165_016ee66a+0x1c0>
  40b98a:	jmp    40b9b2 <__swc_fn_65555ab2_000165_016ee66a+0x272>
  40b98c:	xor    ecx,ecx
  40b98e:	cmp    rax,rbx
  40b991:	cmovne rcx,rax
  40b995:	call   40a450 <__swc_fn_65555ab2_000147_d7edc04f>
  40b99a:	mov    rcx,rsi
  40b99d:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40b9a2:	mov    rax,rdi
  40b9a5:	add    rsp,0x188
  40b9ac:	pop    r12
  40b9ae:	pop    rdi
  40b9af:	pop    rsi
  40b9b0:	pop    rbx
  40b9b1:	ret
  40b9b2:	mov    QWORD PTR [rdi+0x10],rax
  40b9b6:	mov    rcx,QWORD PTR [rsp+0x50]
  40b9bb:	mov    QWORD PTR [rdi+0x18],rcx
  40b9bf:	mov    eax,DWORD PTR [rax+0x8]
  40b9c2:	mov    DWORD PTR [rdi+0x20],eax
  40b9c5:	rex mov BYTE PTR [rdi+0x24],0x1
  40b9ca:	mov    rcx,rsi
  40b9cd:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40b9d2:	mov    rax,rdi
  40b9d5:	add    rsp,0x188
  40b9dc:	pop    r12
  40b9de:	pop    rdi
  40b9df:	pop    rsi
  40b9e0:	pop    rbx
  40b9e1:	ret
	...

000000000040b9f0 <__swc_fn_65555ab2_000168_3459066f>:
  40b9f0:	push   rsi
  40b9f1:	push   rdi
  40b9f2:	push   r12
  40b9f4:	mov    rsi,rdx
  40b9f7:	mov    rdi,rcx
  40b9fa:	mov    rcx,QWORD PTR [rip+0x1863f]        # 424040 <__swc_bss_base_65555ab2>
  40ba01:	test   rcx,rcx
  40ba04:	jne    40ba16 <__swc_fn_65555ab2_000168_3459066f+0x26>
  40ba06:	call   40eb80 <__swc_fn_65555ab2_000169_994c8876>
  40ba0b:	lea    rcx,[rax+0x1]
  40ba0f:	mov    QWORD PTR [rip+0x1862a],rcx        # 424040 <__swc_bss_base_65555ab2>
  40ba16:	dec    rcx
  40ba19:	call   40ba40 <__swc_fn_65555ab2_000171_360af05d>
  40ba1e:	mov    r12,QWORD PTR [rax+0xbe0]
  40ba25:	test   r12,r12
  40ba28:	setne  al
  40ba2b:	je     40ba36 <__swc_fn_65555ab2_000168_3459066f+0x46>
  40ba2d:	mov    rcx,rdi
  40ba30:	mov    rdx,rsi
  40ba33:	call   r12
  40ba36:	pop    r12
  40ba38:	pop    rdi
  40ba39:	pop    rsi
  40ba3a:	ret
  40ba3b:	add    BYTE PTR [rax],al
  40ba3d:	add    BYTE PTR [rax],al
	...

000000000040ba40 <__swc_fn_65555ab2_000171_360af05d>:
  40ba40:	push   r12
  40ba42:	push   rdi
  40ba43:	push   rsi
  40ba44:	sub    rsp,0xd0
  40ba4b:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40ba51:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40ba57:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40ba5d:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40ba63:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40ba69:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40ba6f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40ba78:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40ba81:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40ba8a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40ba93:	mov    r12,rcx
  40ba96:	mov    edi,ecx
  40ba98:	xor    eax,eax
  40ba9a:	call   407000 <pthread_getspecific@plt>
  40ba9f:	test   rax,rax
  40baa2:	je     40baa6 <__swc_fn_65555ab2_000171_360af05d+0x66>
  40baa4:	jmp    40baae <__swc_fn_65555ab2_000171_360af05d+0x6e>
  40baa6:	mov    rcx,r12
  40baa9:	call   40ebe0 <__swc_fn_65555ab2_000172_cbeff767>
  40baae:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40bab4:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40baba:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40bac0:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40bac6:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40bacc:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40bad2:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40badb:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40bae4:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40baed:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40baf6:	add    rsp,0xd0
  40bafd:	pop    rsi
  40bafe:	pop    rdi
  40baff:	pop    r12
  40bb01:	ret
	...

000000000040bb10 <__swc_fn_65555ab2_000174_5eac0ab4>:
  40bb10:	push   rsi
  40bb11:	sub    rsp,0x30
  40bb15:	lea    rsi,[rip+0x1b284]        # 426da0 <__swc_bss_base_65555ab2+0x2d60>
  40bb1c:	mov    rax,QWORD PTR [rsi]
  40bb1f:	test   rax,rax
  40bb22:	je     40bb2a <__swc_fn_65555ab2_000174_5eac0ab4+0x1a>
  40bb24:	add    rsp,0x30
  40bb28:	pop    rsi
  40bb29:	ret
  40bb2a:	mov    ecx,0x3
  40bb2f:	mov    edx,0x10
  40bb34:	call   4095b0 <__swc_fn_65555ab2_000111_6814119b>
  40bb39:	test   rax,rax
  40bb3c:	jne    40bb4d <__swc_fn_65555ab2_000174_5eac0ab4+0x3d>
  40bb3e:	mov    QWORD PTR [rsp+0x18],rax
  40bb43:	call   4113b0 <__swc_fn_65555ab2_000122_be2e2f68>
  40bb48:	mov    rax,QWORD PTR [rsp+0x18]
  40bb4d:	mov    rcx,rax
  40bb50:	xchg   QWORD PTR [rsi],rcx
  40bb53:	add    rsp,0x30
  40bb57:	pop    rsi
  40bb58:	ret
  40bb59:	add    BYTE PTR [rax],al
  40bb5b:	add    BYTE PTR [rax],al
  40bb5d:	add    BYTE PTR [rax],al
	...

000000000040bb60 <__swc_fn_65555ab2_000177_cf4ffedd>:
  40bb60:	push   rsi
  40bb61:	push   rdi
  40bb62:	sub    rsp,0x8
  40bb66:	mov    rsi,rdx
  40bb69:	mov    rdi,rcx
  40bb6c:	mov    rax,QWORD PTR [rsi+0x8]
  40bb70:	test   rax,rax
  40bb73:	je     40bb7d <__swc_fn_65555ab2_000177_cf4ffedd+0x1d>
  40bb75:	mov    rcx,QWORD PTR [rsi]
  40bb78:	mov    QWORD PTR [rax],rcx
  40bb7b:	jmp    40bb84 <__swc_fn_65555ab2_000177_cf4ffedd+0x24>
  40bb7d:	mov    rax,QWORD PTR [rsi]
  40bb80:	mov    QWORD PTR [rdi+0x8],rax
  40bb84:	mov    rax,QWORD PTR [rsi]
  40bb87:	test   rax,rax
  40bb8a:	je     40bb94 <__swc_fn_65555ab2_000177_cf4ffedd+0x34>
  40bb8c:	mov    rcx,QWORD PTR [rsi+0x8]
  40bb90:	mov    QWORD PTR [rax+0x8],rcx
  40bb94:	mov    rcx,rdi
  40bb97:	mov    rdx,QWORD PTR [rsi+0x10]
  40bb9b:	mov    r8,QWORD PTR [rsi+0x18]
  40bb9f:	mov    r9,0xffffffffffffffff
  40bba6:	call   411f60 <__swc_fn_65555ab2_000176_4de704de>
  40bbab:	mov    QWORD PTR [rsi+0x18],0x0
  40bbb3:	mov    rax,QWORD PTR [rdi+0x8]
  40bbb7:	test   rax,rax
  40bbba:	jne    40bbcc <__swc_fn_65555ab2_000177_cf4ffedd+0x6c>
  40bbbc:	call   40bb10 <__swc_fn_65555ab2_000174_5eac0ab4>
  40bbc1:	xor    ecx,ecx
  40bbc3:	mov    QWORD PTR [rax+0x8],rcx
  40bbc7:	xor    ecx,ecx
  40bbc9:	mov    QWORD PTR [rax],rcx
  40bbcc:	add    rsp,0x8
  40bbd0:	pop    rdi
  40bbd1:	pop    rsi
  40bbd2:	ret
	...

000000000040bbe0 <__swc_fn_65555ab2_000001_5d3d19bd>:
  40bbe0:	push   rbx
  40bbe1:	sub    rsp,0x70
  40bbe5:	test   rcx,rcx
  40bbe8:	jne    40bbf0 <__swc_fn_65555ab2_000001_5d3d19bd+0x10>
  40bbea:	add    rsp,0x70
  40bbee:	pop    rbx
  40bbef:	ret
  40bbf0:	vxorps xmm0,xmm0,xmm0
  40bbf4:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40bbfa:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40bc00:	vzeroupper
  40bc03:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40bc09:	lea    rax,[rcx-0x10]
  40bc0d:	mov    QWORD PTR [rsp+0x48],rax
  40bc12:	mov    rax,QWORD PTR [rcx-0x10]
  40bc16:	mov    QWORD PTR [rsp+0x50],rax
  40bc1b:	mov    rcx,QWORD PTR [rip+0x1841e]        # 424040 <__swc_bss_base_65555ab2>
  40bc22:	test   rcx,rcx
  40bc25:	jne    40bc37 <__swc_fn_65555ab2_000001_5d3d19bd+0x57>
  40bc27:	call   40eb80 <__swc_fn_65555ab2_000169_994c8876>
  40bc2c:	lea    rcx,[rax+0x1]
  40bc30:	mov    QWORD PTR [rip+0x18409],rcx        # 424040 <__swc_bss_base_65555ab2>
  40bc37:	dec    rcx
  40bc3a:	call   40ba40 <__swc_fn_65555ab2_000171_360af05d>
  40bc3f:	mov    rcx,QWORD PTR [rax]
  40bc42:	lea    rdx,[rsp+0x8]
  40bc47:	mov    rbx,QWORD PTR [rax+0x8]
  40bc4b:	mov    rbx,QWORD PTR [rbx+0x18]
  40bc4f:	call   rbx
  40bc51:	add    rsp,0x70
  40bc55:	pop    rbx
  40bc56:	ret
	...

000000000040bc60 <__swc_fn_65555ab2_000004_9ee35b18>:
  40bc60:	vxorps xmm0,xmm0,xmm0
  40bc64:	vmovups XMMWORD PTR [rcx],xmm0
  40bc68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40bc6d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40bc72:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40bc77:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40bc7c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40bc81:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40bc86:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40bc8b:	ret
  40bc8c:	add    BYTE PTR [rax],al
	...

000000000040bc90 <__swc_fn_65555ab2_000007_f7acedb0>:
  40bc90:	push   rsi
  40bc91:	mov    rsi,rdx
  40bc94:	test   rdx,rdx
  40bc97:	jne    40bca0 <__swc_fn_65555ab2_000007_f7acedb0+0x10>
  40bc99:	mov    eax,0x1
  40bc9e:	pop    rsi
  40bc9f:	ret
  40bca0:	mov    rdx,rsi
  40bca3:	call   40dc20 <__swc_fn_65555ab2_000115_36905703>
  40bca8:	test   al,al
  40bcaa:	jne    40bcb0 <__swc_fn_65555ab2_000007_f7acedb0+0x20>
  40bcac:	xor    eax,eax
  40bcae:	pop    rsi
  40bcaf:	ret
  40bcb0:	lea    rcx,[rip+0x18399]        # 424050 <__swc_bss_base_65555ab2+0x10>
  40bcb7:	mov    rdx,QWORD PTR [rip+0x18392]        # 424050 <__swc_bss_base_65555ab2+0x10>
  40bcbe:	xchg   ax,ax
  40bcc0:	lea    r8,[rdx+rsi*1]
  40bcc4:	mov    rax,rdx
  40bcc7:	lock cmpxchg QWORD PTR [rcx],r8
  40bccc:	cmp    rax,rdx
  40bccf:	je     40bcd6 <__swc_fn_65555ab2_000007_f7acedb0+0x46>
  40bcd1:	mov    rdx,rax
  40bcd4:	jmp    40bcc0 <__swc_fn_65555ab2_000007_f7acedb0+0x30>
  40bcd6:	lea    rcx,[rip+0x1837b]        # 424058 <__swc_bss_base_65555ab2+0x18>
  40bcdd:	mov    rdx,QWORD PTR [rip+0x18374]        # 424058 <__swc_bss_base_65555ab2+0x18>
  40bce4:	cs nop WORD PTR [rax+rax*1+0x0]
  40bcee:	xchg   ax,ax
  40bcf0:	lea    r8,[rdx+0x1]
  40bcf4:	mov    rax,rdx
  40bcf7:	lock cmpxchg QWORD PTR [rcx],r8
  40bcfc:	cmp    rax,rdx
  40bcff:	je     40bd06 <__swc_fn_65555ab2_000007_f7acedb0+0x76>
  40bd01:	mov    rdx,rax
  40bd04:	jmp    40bcf0 <__swc_fn_65555ab2_000007_f7acedb0+0x60>
  40bd06:	mov    eax,0x1
  40bd0b:	pop    rsi
  40bd0c:	ret
  40bd0d:	add    BYTE PTR [rax],al
	...

000000000040bd10 <__swc_fn_65555ab2_000010_24a20786>:
  40bd10:	push   rbx
  40bd11:	push   rsi
  40bd12:	push   rdi
  40bd13:	push   r12
  40bd15:	sub    rsp,0x18
  40bd19:	mov    rbx,rcx
  40bd1c:	mov    rsi,rcx
  40bd1f:	and    rsi,0xffffffffffc00000
  40bd26:	movzx  eax,BYTE PTR [rbx+0x3a]
  40bd2a:	mov    ecx,DWORD PTR [rsi+0x28]
  40bd2d:	shrx   eax,eax,ecx
  40bd32:	lea    rdi,[rsp+0x8]
  40bd37:	mov    DWORD PTR [rsp+0x8],eax
  40bd3b:	mov    rcx,rsi
  40bd3e:	mov    rax,rdi
  40bd41:	mov    edx,DWORD PTR [rax]
  40bd43:	call   407ad0 <__swc_fn_65555ab2_000015_9dea5065>
  40bd48:	mov    r12,rax
  40bd4b:	mov    rcx,rsi
  40bd4e:	mov    edx,DWORD PTR [rdi]
  40bd50:	call   40be40 <__swc_fn_65555ab2_000016_9afb7cfb>
  40bd55:	mov    rcx,r12
  40bd58:	mov    edx,DWORD PTR [rbx+0x3c]
  40bd5b:	add    rcx,rdx
  40bd5e:	cmp    rcx,rax
  40bd61:	jb     40bd6f <__swc_fn_65555ab2_000010_24a20786+0x5f>
  40bd63:	xor    eax,eax
  40bd65:	add    rsp,0x18
  40bd69:	pop    r12
  40bd6b:	pop    rdi
  40bd6c:	pop    rsi
  40bd6d:	pop    rbx
  40bd6e:	ret
  40bd6f:	mov    rdx,QWORD PTR [rbx+0x20]
  40bd73:	mov    r8d,DWORD PTR [rbx+0x2c]
  40bd77:	add    rdx,r8
  40bd7a:	lea    rsi,[rdx+0xffff]
  40bd81:	and    rsi,0xffffffffffff0000
  40bd88:	cmp    rax,rsi
  40bd8b:	cmovbe rsi,rax
  40bd8f:	mov    rax,rsi
  40bd92:	sub    rax,rcx
  40bd95:	mov    rdx,rax
  40bd98:	call   40bc90 <__swc_fn_65555ab2_000007_f7acedb0>
  40bd9d:	test   al,al
  40bd9f:	jne    40bdad <__swc_fn_65555ab2_000010_24a20786+0x9d>
  40bda1:	xor    eax,eax
  40bda3:	add    rsp,0x18
  40bda7:	pop    r12
  40bda9:	pop    rdi
  40bdaa:	pop    rsi
  40bdab:	pop    rbx
  40bdac:	ret
  40bdad:	sub    rsi,r12
  40bdb0:	mov    DWORD PTR [rbx+0x3c],esi
  40bdb3:	mov    ecx,DWORD PTR [rbx+0x2c]
  40bdb6:	mov    rax,rsi
  40bdb9:	xor    edx,edx
  40bdbb:	div    rcx
  40bdbe:	imul   rax,rcx
  40bdc2:	add    r12,rax
  40bdc5:	mov    QWORD PTR [rbx+0x18],r12
  40bdc9:	mov    eax,0x1
  40bdce:	add    rsp,0x18
  40bdd2:	pop    r12
  40bdd4:	pop    rdi
  40bdd5:	pop    rsi
  40bdd6:	pop    rbx
  40bdd7:	ret
	...

000000000040bde0 <__swc_fn_65555ab2_000013_e4b0ddfc>:
  40bde0:	sub    rsp,0x8
  40bde4:	mov    rdx,rcx
  40bde7:	lea    r9,[rcx+0x60]
  40bdeb:	mov    rax,QWORD PTR [r9]
  40bdee:	test   rax,rax
  40bdf1:	jne    40bdf8 <__swc_fn_65555ab2_000013_e4b0ddfc+0x18>
  40bdf3:	add    rsp,0x8
  40bdf7:	ret
  40bdf8:	mov    rcx,rdx
  40bdfb:	call   40ef10 <__swc_fn_65555ab2_000011_c3647f66>
  40be00:	xor    eax,eax
  40be02:	xchg   QWORD PTR [r9],rax
  40be05:	mov    r8,rax
  40be08:	mov    rcx,rdx
  40be0b:	call   407ac0 <__swc_fn_65555ab2_000012_861b8b62>
  40be10:	xor    eax,eax
  40be12:	test   r8,r8
  40be15:	je     40be36 <__swc_fn_65555ab2_000013_e4b0ddfc+0x56>
  40be17:	nop    WORD PTR [rax+rax*1+0x0]
  40be20:	mov    rcx,QWORD PTR [r8]
  40be23:	mov    r9,QWORD PTR [rdx]
  40be26:	mov    QWORD PTR [r8],r9
  40be29:	mov    QWORD PTR [rdx],r8
  40be2c:	mov    r8,rcx
  40be2f:	inc    eax
  40be31:	test   rcx,rcx
  40be34:	jne    40be20 <__swc_fn_65555ab2_000013_e4b0ddfc+0x40>
  40be36:	sub    DWORD PTR [rdx+0x28],eax
  40be39:	add    rsp,0x8
  40be3d:	ret
	...

000000000040be40 <__swc_fn_65555ab2_000016_9afb7cfb>:
  40be40:	lea    eax,[rdx+0x1]
  40be43:	mov    edx,DWORD PTR [rcx+0x28]
  40be46:	shlx   eax,eax,edx
  40be4b:	shl    rax,0x10
  40be4f:	add    rax,rcx
  40be52:	ret
	...

000000000040be60 <__swc_fn_65555ab2_000019_adca76cf>:
  40be60:	push   rbx
  40be61:	push   rsi
  40be62:	push   rdi
  40be63:	push   r12
  40be65:	push   r13
  40be67:	push   r14
  40be69:	push   r15
  40be6b:	sub    rsp,0x30
  40be6f:	mov    rbx,rcx
  40be72:	lea    rsi,[rcx+0x48]
  40be76:	mov    QWORD PTR [rsp+0x18],rsi
  40be7b:	mov    rax,QWORD PTR [rsi]
  40be7e:	mov    rdi,rax
  40be81:	lea    r12,[rsp+0x8]
  40be86:	lea    r13,[rcx+0x40]
  40be8a:	nop    WORD PTR [rax+rax*1+0x0]
  40be90:	test   rdi,rdi
  40be93:	je     40bfd3 <__swc_fn_65555ab2_000019_adca76cf+0x173>
  40be99:	xor    eax,eax
  40be9b:	tzcnt  rax,rdi
  40bea0:	mov    DWORD PTR [rsp+0x8],eax
  40bea4:	mov    r14d,0x1
  40beaa:	mov    ecx,eax
  40beac:	shl    r14,cl
  40beaf:	andn   rdi,r14,rdi
  40beb4:	mov    rcx,QWORD PTR [r13+0x0]
  40beb8:	test   rcx,r14
  40bebb:	jne    40be90 <__swc_fn_65555ab2_000019_adca76cf+0x30>
  40bebd:	mov    rdx,rcx
  40bec0:	or     rdx,r14
  40bec3:	mov    rax,rcx
  40bec6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  40becc:	cmp    rax,rcx
  40becf:	je     40bed9 <__swc_fn_65555ab2_000019_adca76cf+0x79>
  40bed1:	mov    rax,QWORD PTR [rsi]
  40bed4:	mov    rdi,rax
  40bed7:	jmp    40be90 <__swc_fn_65555ab2_000019_adca76cf+0x30>
  40bed9:	mov    rcx,rbx
  40bedc:	mov    rdx,r14
  40bedf:	call   407c30 <__swc_fn_65555ab2_000021_fd2b165c>
  40bee4:	test   al,al
  40bee6:	je     40bfbe <__swc_fn_65555ab2_000019_adca76cf+0x15e>
  40beec:	mov    eax,DWORD PTR [r12]
  40bef0:	shl    rax,0x4
  40bef4:	lea    r15,[rbx+rax*8+0x80]
  40befc:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  40bf04:	lea    rcx,[rip+0x18155]        # 424060 <__swc_bss_base_65555ab2+0x20>
  40bf0b:	mov    rdx,QWORD PTR [rip+0x1814e]        # 424060 <__swc_bss_base_65555ab2+0x20>
  40bf12:	cs nop WORD PTR [rax+rax*1+0x0]
  40bf1c:	nop    DWORD PTR [rax+0x0]
  40bf20:	mov    r8,rdx
  40bf23:	sub    r8,rsi
  40bf26:	mov    rax,rdx
  40bf29:	lock cmpxchg QWORD PTR [rcx],r8
  40bf2e:	cmp    rax,rdx
  40bf31:	je     40bf38 <__swc_fn_65555ab2_000019_adca76cf+0xd8>
  40bf33:	mov    rdx,rax
  40bf36:	jmp    40bf20 <__swc_fn_65555ab2_000019_adca76cf+0xc0>
  40bf38:	mov    rcx,rbx
  40bf3b:	mov    rax,r12
  40bf3e:	mov    edx,DWORD PTR [rax]
  40bf40:	call   407ad0 <__swc_fn_65555ab2_000015_9dea5065>
  40bf45:	test   rsi,rsi
  40bf48:	je     40bfb6 <__swc_fn_65555ab2_000019_adca76cf+0x156>
  40bf4e:	mov    rcx,rax
  40bf51:	mov    rdx,rsi
  40bf54:	call   411180 <__swc_fn_65555ab2_000116_e9fc0224>
  40bf59:	lea    rcx,[rip+0x180f0]        # 424050 <__swc_bss_base_65555ab2+0x10>
  40bf60:	mov    rdx,QWORD PTR [rip+0x180e9]        # 424050 <__swc_bss_base_65555ab2+0x10>
  40bf67:	nop    WORD PTR [rax+rax*1+0x0]
  40bf70:	mov    r8,rdx
  40bf73:	sub    r8,rsi
  40bf76:	mov    rax,rdx
  40bf79:	lock cmpxchg QWORD PTR [rcx],r8
  40bf7e:	cmp    rax,rdx
  40bf81:	je     40bf88 <__swc_fn_65555ab2_000019_adca76cf+0x128>
  40bf83:	mov    rdx,rax
  40bf86:	jmp    40bf70 <__swc_fn_65555ab2_000019_adca76cf+0x110>
  40bf88:	lea    rcx,[rip+0x180d9]        # 424068 <__swc_bss_base_65555ab2+0x28>
  40bf8f:	mov    rdx,QWORD PTR [rip+0x180d2]        # 424068 <__swc_bss_base_65555ab2+0x28>
  40bf96:	cs nop WORD PTR [rax+rax*1+0x0]
  40bfa0:	lea    r8,[rdx+0x1]
  40bfa4:	mov    rax,rdx
  40bfa7:	lock cmpxchg QWORD PTR [rcx],r8
  40bfac:	cmp    rax,rdx
  40bfaf:	je     40bfb6 <__swc_fn_65555ab2_000019_adca76cf+0x156>
  40bfb1:	mov    rdx,rax
  40bfb4:	jmp    40bfa0 <__swc_fn_65555ab2_000019_adca76cf+0x140>
  40bfb6:	mov    DWORD PTR [r15+0x3c],0x0
  40bfbe:	mov    rcx,rbx
  40bfc1:	mov    rdx,r14
  40bfc4:	call   40bff0 <__swc_fn_65555ab2_000022_c8f5f27c>
  40bfc9:	mov    rsi,QWORD PTR [rsp+0x18]
  40bfce:	jmp    40be90 <__swc_fn_65555ab2_000019_adca76cf+0x30>
  40bfd3:	add    rsp,0x30
  40bfd7:	pop    r15
  40bfd9:	pop    r14
  40bfdb:	pop    r13
  40bfdd:	pop    r12
  40bfdf:	pop    rdi
  40bfe0:	pop    rsi
  40bfe1:	pop    rbx
  40bfe2:	ret
	...

000000000040bff0 <__swc_fn_65555ab2_000022_c8f5f27c>:
  40bff0:	mov    r8,QWORD PTR [rcx+0x40]
  40bff4:	cs nop WORD PTR [rax+rax*1+0x0]
  40bffe:	xchg   ax,ax
  40c000:	mov    rax,rdx
  40c003:	not    rax
  40c006:	mov    r9,r8
  40c009:	and    r9,rax
  40c00c:	mov    rax,r8
  40c00f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  40c015:	cmp    rax,r8
  40c018:	jne    40c01b <__swc_fn_65555ab2_000022_c8f5f27c+0x2b>
  40c01a:	ret
  40c01b:	mov    r8,rax
  40c01e:	jmp    40c000 <__swc_fn_65555ab2_000022_c8f5f27c+0x10>

000000000040c020 <__swc_fn_65555ab2_000025_aa910677>:
  40c020:	push   rsi
  40c021:	push   rdi
  40c022:	sub    rsp,0x8
  40c026:	mov    rsi,rcx
  40c029:	call   40be60 <__swc_fn_65555ab2_000019_adca76cf>
  40c02e:	lea    rdi,[rip+0x181c3]        # 4241f8 <__swc_bss_base_65555ab2+0x1b8>
  40c035:	mov    rcx,rdi
  40c038:	call   40e280 <__swc_fn_65555ab2_000139_86bb0f90>
  40c03d:	mov    QWORD PTR [rsi+0x8],0x0
  40c045:	mov    QWORD PTR [rsi+0x18],0x0
  40c04d:	mov    rax,QWORD PTR [rip+0x181ac]        # 424200 <__swc_bss_base_65555ab2+0x1c0>
  40c054:	mov    QWORD PTR [rsi+0x10],rax
  40c058:	mov    QWORD PTR [rip+0x181a1],rsi        # 424200 <__swc_bss_base_65555ab2+0x1c0>
  40c05f:	mov    rcx,rdi
  40c062:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40c067:	add    rsp,0x8
  40c06b:	pop    rdi
  40c06c:	pop    rsi
  40c06d:	ret
	...

000000000040c070 <__swc_fn_65555ab2_000028_9798fb47>:
  40c070:	vxorps xmm0,xmm0,xmm0
  40c074:	vmovups XMMWORD PTR [rcx],xmm0
  40c078:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40c07d:	mov    QWORD PTR [rcx+0x20],0x0
  40c085:	ret
	...

000000000040c090 <__swc_fn_65555ab2_000031_9798fb47>:
  40c090:	vxorps xmm0,xmm0,xmm0
  40c094:	vmovups XMMWORD PTR [rcx],xmm0
  40c098:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40c09d:	mov    QWORD PTR [rcx+0x20],0x0
  40c0a5:	ret
	...

000000000040c0b0 <__swc_fn_65555ab2_000034_9128bcf9>:
  40c0b0:	push   r12
  40c0b2:	mov    r12,rdi
  40c0b5:	test   rdi,rdi
  40c0b8:	jne    40c0bd <__swc_fn_65555ab2_000034_9128bcf9+0xd>
  40c0ba:	pop    r12
  40c0bc:	ret
  40c0bd:	lea    rax,[rip+0x15f44]        # 422008 <__swc_data_base_65555ab2+0x8>
  40c0c4:	mov    rax,QWORD PTR [rax]
  40c0c7:	cmp    rax,0xffffffffffffffff
  40c0cb:	je     40c0da <__swc_fn_65555ab2_000034_9128bcf9+0x2a>
  40c0cd:	mov    eax,eax
  40c0cf:	mov    edi,eax
  40c0d1:	xor    eax,eax
  40c0d3:	call   407000 <pthread_getspecific@plt>
  40c0d8:	jmp    40c0dc <__swc_fn_65555ab2_000034_9128bcf9+0x2c>
  40c0da:	xor    eax,eax
  40c0dc:	cmp    rax,r12
  40c0df:	jne    40c0e8 <__swc_fn_65555ab2_000034_9128bcf9+0x38>
  40c0e1:	xor    ecx,ecx
  40c0e3:	call   407e00 <__swc_fn_65555ab2_000036_92d9bbff>
  40c0e8:	mov    rdx,QWORD PTR [r12]
  40c0ec:	test   rdx,rdx
  40c0ef:	je     40c108 <__swc_fn_65555ab2_000034_9128bcf9+0x58>
  40c0f1:	mov    rcx,rdx
  40c0f4:	call   40c130 <__swc_fn_65555ab2_000040_eb6108f2>
  40c0f9:	test   al,al
  40c0fb:	je     40c108 <__swc_fn_65555ab2_000034_9128bcf9+0x58>
  40c0fd:	mov    rcx,rdx
  40c100:	mov    rdx,r12
  40c103:	call   40c220 <__swc_fn_65555ab2_000046_b30433d0>
  40c108:	pop    r12
  40c10a:	ret
  40c10b:	add    BYTE PTR [rax],al
  40c10d:	add    BYTE PTR [rax],al
	...

000000000040c110 <__swc_fn_65555ab2_000037_28d0e998>:
  40c110:	push   rsi
  40c111:	mov    rsi,rcx
  40c114:	call   40f3c0 <__swc_fn_65555ab2_000035_cd1a4e8c>
  40c119:	mov    rcx,rax
  40c11c:	mov    rdx,rsi
  40c11f:	call   40e100 <__swc_fn_65555ab2_000133_ae5891af>
  40c124:	mov    rcx,rsi
  40c127:	call   407e00 <__swc_fn_65555ab2_000036_92d9bbff>
  40c12c:	pop    rsi
  40c12d:	ret
	...

000000000040c130 <__swc_fn_65555ab2_000040_eb6108f2>:
  40c130:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40c13a:	sete   al
  40c13d:	ret
	...

000000000040c140 <__swc_fn_65555ab2_000043_d3c2ab54>:
  40c140:	push   rsi
  40c141:	test   rdx,rdx
  40c144:	jne    40c148 <__swc_fn_65555ab2_000043_d3c2ab54+0x8>
  40c146:	pop    rsi
  40c147:	ret
  40c148:	mov    rax,r8
  40c14b:	mov    ecx,0x1000
  40c150:	test   ecx,ecx
  40c152:	mov    r10d,0x8
  40c158:	cmove  ecx,r10d
  40c15c:	dec    rcx
  40c15f:	mov    r10,0xffffffffffffffff
  40c166:	sub    r10,rcx
  40c169:	cmp    r8,r10
  40c16c:	jbe    40c172 <__swc_fn_65555ab2_000043_d3c2ab54+0x32>
  40c16e:	xor    eax,eax
  40c170:	jmp    40c17a <__swc_fn_65555ab2_000043_d3c2ab54+0x3a>
  40c172:	add    rax,rcx
  40c175:	andn   rax,rcx,rax
  40c17a:	mov    ecx,0x1000
  40c17f:	test   ecx,ecx
  40c181:	mov    r8d,0x8
  40c187:	cmove  ecx,r8d
  40c18b:	dec    rcx
  40c18e:	mov    r8,0xffffffffffffffff
  40c195:	sub    r8,rcx
  40c198:	cmp    r9,r8
  40c19b:	jbe    40c1a1 <__swc_fn_65555ab2_000043_d3c2ab54+0x61>
  40c19d:	xor    esi,esi
  40c19f:	jmp    40c1ac <__swc_fn_65555ab2_000043_d3c2ab54+0x6c>
  40c1a1:	add    r9,rcx
  40c1a4:	andn   r9,rcx,r9
  40c1a9:	mov    rsi,r9
  40c1ac:	mov    rcx,rdx
  40c1af:	mov    rdx,rax
  40c1b2:	mov    r8,rsi
  40c1b5:	call   40dd00 <__swc_fn_65555ab2_000118_5208f471>
  40c1ba:	lea    rcx,[rip+0x17e8f]        # 424050 <__swc_bss_base_65555ab2+0x10>
  40c1c1:	mov    rdx,QWORD PTR [rip+0x17e88]        # 424050 <__swc_bss_base_65555ab2+0x10>
  40c1c8:	nop    DWORD PTR [rax+rax*1+0x0]
  40c1d0:	mov    r8,rdx
  40c1d3:	sub    r8,rsi
  40c1d6:	mov    rax,rdx
  40c1d9:	lock cmpxchg QWORD PTR [rcx],r8
  40c1de:	cmp    rax,rdx
  40c1e1:	je     40c1e8 <__swc_fn_65555ab2_000043_d3c2ab54+0xa8>
  40c1e3:	mov    rdx,rax
  40c1e6:	jmp    40c1d0 <__swc_fn_65555ab2_000043_d3c2ab54+0x90>
  40c1e8:	lea    rcx,[rip+0x17e79]        # 424068 <__swc_bss_base_65555ab2+0x28>
  40c1ef:	mov    rdx,QWORD PTR [rip+0x17e72]        # 424068 <__swc_bss_base_65555ab2+0x28>
  40c1f6:	cs nop WORD PTR [rax+rax*1+0x0]
  40c200:	lea    r8,[rdx+0x1]
  40c204:	mov    rax,rdx
  40c207:	lock cmpxchg QWORD PTR [rcx],r8
  40c20c:	cmp    rax,rdx
  40c20f:	je     40c216 <__swc_fn_65555ab2_000043_d3c2ab54+0xd6>
  40c211:	mov    rdx,rax
  40c214:	jmp    40c200 <__swc_fn_65555ab2_000043_d3c2ab54+0xc0>
  40c216:	pop    rsi
  40c217:	ret
	...

000000000040c220 <__swc_fn_65555ab2_000046_b30433d0>:
  40c220:	push   rbx
  40c221:	push   rsi
  40c222:	push   rdi
  40c223:	push   r12
  40c225:	push   r13
  40c227:	push   r14
  40c229:	push   r15
  40c22b:	sub    rsp,0x30
  40c22f:	mov    rbx,rdx
  40c232:	mov    QWORD PTR [rsp+0x18],rdx
  40c237:	mov    rsi,rcx
  40c23a:	mov    eax,0x1
  40c23f:	xchg   DWORD PTR [rbx+0x20],eax
  40c242:	test   eax,eax
  40c244:	je     40c256 <__swc_fn_65555ab2_000046_b30433d0+0x36>
  40c246:	add    rsp,0x30
  40c24a:	pop    r15
  40c24c:	pop    r14
  40c24e:	pop    r13
  40c250:	pop    r12
  40c252:	pop    rdi
  40c253:	pop    rsi
  40c254:	pop    rbx
  40c255:	ret
  40c256:	mov    rcx,rsi
  40c259:	mov    rdx,rbx
  40c25c:	mov    r8,0xffffffffffffffff
  40c263:	call   4083d0 <__swc_fn_65555ab2_000063_dea90857>
  40c268:	lea    rdi,[rsi+0x10]
  40c26c:	mov    QWORD PTR [rsp+0x20],rdi
  40c271:	mov    rcx,rdi
  40c274:	call   40e280 <__swc_fn_65555ab2_000139_86bb0f90>
  40c279:	xor    r12d,r12d
  40c27c:	cs nop WORD PTR [rax+rax*1+0x0]
  40c286:	cs nop WORD PTR [rax+rax*1+0x0]
  40c290:	mov    eax,r12d
  40c293:	lea    r13,[rax+rax*4]
  40c297:	lea    r13,[rbx+r13*8+0x28]
  40c29c:	mov    rax,QWORD PTR [r13+0x8]
  40c2a0:	mov    QWORD PTR [rsp+0x8],rax
  40c2a5:	mov    rax,QWORD PTR [r13+0x18]
  40c2a9:	mov    QWORD PTR [rsp+0x10],rax
  40c2ae:	mov    r14d,0x2
  40c2b4:	xor    r15d,r15d
  40c2b7:	test   r14,r14
  40c2ba:	je     40c337 <__swc_fn_65555ab2_000046_b30433d0+0x117>
  40c2c0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  40c2c5:	mov    rdi,rax
  40c2c8:	test   rdi,rdi
  40c2cb:	je     40c329 <__swc_fn_65555ab2_000046_b30433d0+0x109>
  40c2cd:	nop    DWORD PTR [rax]
  40c2d0:	mov    rbx,QWORD PTR [rdi+0x48]
  40c2d4:	mov    DWORD PTR [rdi+0x6c],0x0
  40c2db:	mov    rcx,rdi
  40c2de:	call   40bde0 <__swc_fn_65555ab2_000013_e4b0ddfc>
  40c2e3:	cmp    DWORD PTR [rdi+0x28],0x0
  40c2e7:	jne    40c300 <__swc_fn_65555ab2_000046_b30433d0+0xe0>
  40c2e9:	mov    rax,rdi
  40c2ec:	and    rax,0xffffffffffc00000
  40c2f3:	mov    rcx,rax
  40c2f6:	mov    rdx,rdi
  40c2f9:	call   407af0 <__swc_fn_65555ab2_000018_283e2b5e>
  40c2fe:	jmp    40c321 <__swc_fn_65555ab2_000046_b30433d0+0x101>
  40c300:	mov    QWORD PTR [rdi+0x40],0x0
  40c308:	rex mov BYTE PTR [rdi+0x3b],0x2
  40c30d:	mov    QWORD PTR [rdi+0x50],0x0
  40c315:	mov    rax,QWORD PTR [rsi+0x28]
  40c319:	mov    QWORD PTR [rdi+0x48],rax
  40c31d:	mov    QWORD PTR [rsi+0x28],rdi
  40c321:	mov    rdi,rbx
  40c324:	test   rbx,rbx
  40c327:	jne    40c2d0 <__swc_fn_65555ab2_000046_b30433d0+0xb0>
  40c329:	add    r15,0x1
  40c32d:	sub    r14,0x1
  40c331:	jne    40c2c0 <__swc_fn_65555ab2_000046_b30433d0+0xa0>
  40c337:	vxorps xmm0,xmm0,xmm0
  40c33b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  40c341:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40c347:	mov    QWORD PTR [r13+0x20],0x0
  40c34f:	add    r12,0x1
  40c353:	cmp    r12,0x2d
  40c357:	mov    rbx,QWORD PTR [rsp+0x18]
  40c35c:	jb     40c290 <__swc_fn_65555ab2_000046_b30433d0+0x70>
  40c362:	mov    rcx,rsi
  40c365:	mov    rbx,QWORD PTR [rsp+0x18]
  40c36a:	mov    rdx,rbx
  40c36d:	mov    rdi,QWORD PTR [rsp+0x20]
  40c372:	call   40f580 <__swc_fn_65555ab2_000047_6e7a8d58>
  40c377:	mov    rcx,rdi
  40c37a:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40c37f:	mov    rcx,rsi
  40c382:	mov    rdx,rbx
  40c385:	mov    r8d,0x9b8
  40c38b:	mov    r9d,0x9b8
  40c391:	call   40c140 <__swc_fn_65555ab2_000043_d3c2ab54>
  40c396:	add    rsp,0x30
  40c39a:	pop    r15
  40c39c:	pop    r14
  40c39e:	pop    r13
  40c3a0:	pop    r12
  40c3a2:	pop    rdi
  40c3a3:	pop    rsi
  40c3a4:	pop    rbx
  40c3a5:	ret
	...

000000000040c3c0 <__swc_fn_65555ab2_000049_ad48ec88>:
  40c3c0:	push   rbx
  40c3c1:	push   rsi
  40c3c2:	push   rdi
  40c3c3:	push   r12
  40c3c5:	push   r13
  40c3c7:	push   r14
  40c3c9:	push   r15
  40c3cb:	sub    rsp,0x30
  40c3cf:	mov    ebx,r8d
  40c3d2:	mov    rsi,rcx
  40c3d5:	mov    rdi,rdx
  40c3d8:	test   r8d,r8d
  40c3db:	jne    40c3e4 <__swc_fn_65555ab2_000049_ad48ec88+0x24>
  40c3dd:	mov    eax,0x8
  40c3e2:	jmp    40c40b <__swc_fn_65555ab2_000049_ad48ec88+0x4b>
  40c3e4:	cmp    ebx,0x8
  40c3e7:	ja     40c3f2 <__swc_fn_65555ab2_000049_ad48ec88+0x32>
  40c3e9:	mov    rax,rbx
  40c3ec:	shl    rax,0x4
  40c3f0:	jmp    40c40b <__swc_fn_65555ab2_000049_ad48ec88+0x4b>
  40c3f2:	lea    eax,[rbx-0x9]
  40c3f5:	mov    ecx,eax
  40c3f7:	shr    ecx,0x2
  40c3fa:	and    eax,0x3
  40c3fd:	lea    ecx,[rcx+0x7]
  40c400:	lea    ecx,[rcx-0x2]
  40c403:	lea    eax,[rax+0x5]
  40c406:	shlx   rax,rax,rcx
  40c40b:	lea    r12,[rsp+0x8]
  40c410:	mov    DWORD PTR [rsp+0x8],eax
  40c414:	lea    r13,[rsp+0xc]
  40c419:	mov    QWORD PTR [rsp+0x18],r13
  40c41e:	xor    eax,eax
  40c420:	cmp    ebx,0x21
  40c423:	setae  al
  40c426:	lea    eax,[rax+rax*2]
  40c429:	mov    DWORD PTR [rsp+0xc],eax
  40c42d:	lea    r14,[rsi+0x10]
  40c431:	mov    rcx,r14
  40c434:	call   40e280 <__swc_fn_65555ab2_000139_86bb0f90>
  40c439:	xor    eax,eax
  40c43b:	mov    rcx,QWORD PTR [rsi+0x28]
  40c43f:	mov    r15,rcx
  40c442:	test   r15,r15
  40c445:	je     40c4f6 <__swc_fn_65555ab2_000049_ad48ec88+0x136>
  40c44b:	cs nop WORD PTR [rax+rax*1+0x0]
  40c455:	cs nop WORD PTR [rax+rax*1+0x0]
  40c45f:	nop
  40c460:	mov    rcx,QWORD PTR [r15+0x48]
  40c464:	movzx  edx,BYTE PTR [r15+0x39]
  40c469:	cmp    edx,ebx
  40c46b:	jne    40c4e7 <__swc_fn_65555ab2_000049_ad48ec88+0x127>
  40c46d:	test   rax,rax
  40c470:	jne    40c478 <__swc_fn_65555ab2_000049_ad48ec88+0xb8>
  40c472:	mov    QWORD PTR [rsi+0x28],rcx
  40c476:	jmp    40c47c <__swc_fn_65555ab2_000049_ad48ec88+0xbc>
  40c478:	mov    QWORD PTR [rax+0x48],rcx
  40c47c:	vxorps xmm0,xmm0,xmm0
  40c480:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  40c486:	mov    BYTE PTR [r15+0x3b],0x1
  40c48b:	mov    QWORD PTR [r15+0x40],rdi
  40c48f:	mov    rcx,r15
  40c492:	call   40bde0 <__swc_fn_65555ab2_000013_e4b0ddfc>
  40c497:	movzx  eax,BYTE PTR [r15+0x39]
  40c49c:	lea    rax,[rax+rax*4]
  40c4a0:	lea    rax,[rdi+rax*8+0x28]
  40c4a5:	mov    rcx,QWORD PTR [rax+0x10]
  40c4a9:	mov    QWORD PTR [r15+0x50],rcx
  40c4ad:	mov    QWORD PTR [r15+0x48],0x0
  40c4b5:	mov    rcx,QWORD PTR [rax+0x10]
  40c4b9:	test   rcx,rcx
  40c4bc:	je     40c4c4 <__swc_fn_65555ab2_000049_ad48ec88+0x104>
  40c4be:	mov    QWORD PTR [rcx+0x48],r15
  40c4c2:	jmp    40c4c8 <__swc_fn_65555ab2_000049_ad48ec88+0x108>
  40c4c4:	mov    QWORD PTR [rax+0x8],r15
  40c4c8:	mov    QWORD PTR [rax+0x10],r15
  40c4cc:	mov    rcx,r14
  40c4cf:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40c4d4:	mov    rax,r15
  40c4d7:	add    rsp,0x30
  40c4db:	pop    r15
  40c4dd:	pop    r14
  40c4df:	pop    r13
  40c4e1:	pop    r12
  40c4e3:	pop    rdi
  40c4e4:	pop    rsi
  40c4e5:	pop    rbx
  40c4e6:	ret
  40c4e7:	mov    rax,r15
  40c4ea:	mov    r15,rcx
  40c4ed:	test   rcx,rcx
  40c4f0:	jne    40c460 <__swc_fn_65555ab2_000049_ad48ec88+0xa0>
  40c4f6:	mov    rax,QWORD PTR [rsi+0x18]
  40c4fa:	mov    r15,rax
  40c4fd:	test   r15,r15
  40c500:	je     40c596 <__swc_fn_65555ab2_000049_ad48ec88+0x1d6>
  40c506:	cs nop WORD PTR [rax+rax*1+0x0]
  40c510:	mov    eax,DWORD PTR [rsp+0xc]
  40c514:	cmp    DWORD PTR [r15+0x28],eax
  40c518:	jne    40c586 <__swc_fn_65555ab2_000049_ad48ec88+0x1c6>
  40c51a:	mov    rcx,r15
  40c51d:	mov    edx,ebx
  40c51f:	mov    rax,r12
  40c522:	mov    r8d,DWORD PTR [rax]
  40c525:	call   40efc0 <__swc_fn_65555ab2_000017_efc44797>
  40c52a:	mov    r13,rax
  40c52d:	test   rax,rax
  40c530:	je     40c586 <__swc_fn_65555ab2_000049_ad48ec88+0x1c6>
  40c532:	mov    QWORD PTR [r13+0x40],rdi
  40c536:	movzx  eax,BYTE PTR [r13+0x39]
  40c53b:	lea    rax,[rax+rax*4]
  40c53f:	lea    rax,[rdi+rax*8+0x28]
  40c544:	mov    rcx,QWORD PTR [rax+0x10]
  40c548:	mov    QWORD PTR [r13+0x50],rcx
  40c54c:	mov    QWORD PTR [r13+0x48],0x0
  40c554:	mov    rcx,QWORD PTR [rax+0x10]
  40c558:	test   rcx,rcx
  40c55b:	je     40c563 <__swc_fn_65555ab2_000049_ad48ec88+0x1a3>
  40c55d:	mov    QWORD PTR [rcx+0x48],r13
  40c561:	jmp    40c567 <__swc_fn_65555ab2_000049_ad48ec88+0x1a7>
  40c563:	mov    QWORD PTR [rax+0x8],r13
  40c567:	mov    QWORD PTR [rax+0x10],r13
  40c56b:	mov    rcx,r14
  40c56e:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40c573:	mov    rax,r13
  40c576:	add    rsp,0x30
  40c57a:	pop    r15
  40c57c:	pop    r14
  40c57e:	pop    r13
  40c580:	pop    r12
  40c582:	pop    rdi
  40c583:	pop    rsi
  40c584:	pop    rbx
  40c585:	ret
  40c586:	mov    rax,QWORD PTR [r15+0x10]
  40c58a:	mov    r15,rax
  40c58d:	test   rax,rax
  40c590:	jne    40c510 <__swc_fn_65555ab2_000049_ad48ec88+0x150>
  40c596:	mov    rcx,rsi
  40c599:	mov    r13,QWORD PTR [rsp+0x18]
  40c59e:	mov    edx,DWORD PTR [r13+0x0]
  40c5a2:	call   407c70 <__swc_fn_65555ab2_000024_2685aade>
  40c5a7:	mov    r13,rax
  40c5aa:	test   rax,rax
  40c5ad:	jne    40c5c9 <__swc_fn_65555ab2_000049_ad48ec88+0x209>
  40c5af:	mov    rcx,r14
  40c5b2:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40c5b7:	xor    eax,eax
  40c5b9:	add    rsp,0x30
  40c5bd:	pop    r15
  40c5bf:	pop    r14
  40c5c1:	pop    r13
  40c5c3:	pop    r12
  40c5c5:	pop    rdi
  40c5c6:	pop    rsi
  40c5c7:	pop    rbx
  40c5c8:	ret
  40c5c9:	mov    rcx,r13
  40c5cc:	mov    edx,ebx
  40c5ce:	mov    r8d,DWORD PTR [r12]
  40c5d2:	call   40efc0 <__swc_fn_65555ab2_000017_efc44797>
  40c5d7:	mov    rbx,rax
  40c5da:	test   rax,rax
  40c5dd:	jne    40c601 <__swc_fn_65555ab2_000049_ad48ec88+0x241>
  40c5df:	mov    rcx,r13
  40c5e2:	call   40c020 <__swc_fn_65555ab2_000025_aa910677>
  40c5e7:	mov    rcx,r14
  40c5ea:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40c5ef:	xor    eax,eax
  40c5f1:	add    rsp,0x30
  40c5f5:	pop    r15
  40c5f7:	pop    r14
  40c5f9:	pop    r13
  40c5fb:	pop    r12
  40c5fd:	pop    rdi
  40c5fe:	pop    rsi
  40c5ff:	pop    rbx
  40c600:	ret
  40c601:	mov    rax,QWORD PTR [rsi+0x18]
  40c605:	mov    QWORD PTR [r13+0x10],rax
  40c609:	mov    rax,QWORD PTR [rsi+0x18]
  40c60d:	test   rax,rax
  40c610:	je     40c616 <__swc_fn_65555ab2_000049_ad48ec88+0x256>
  40c612:	mov    QWORD PTR [rax+0x18],r13
  40c616:	mov    QWORD PTR [rsi+0x18],r13
  40c61a:	mov    QWORD PTR [rbx+0x40],rdi
  40c61e:	movzx  eax,BYTE PTR [rbx+0x39]
  40c622:	lea    rax,[rax+rax*4]
  40c626:	lea    rax,[rdi+rax*8+0x28]
  40c62b:	mov    rcx,QWORD PTR [rax+0x10]
  40c62f:	mov    QWORD PTR [rbx+0x50],rcx
  40c633:	mov    QWORD PTR [rbx+0x48],0x0
  40c63b:	mov    rcx,QWORD PTR [rax+0x10]
  40c63f:	test   rcx,rcx
  40c642:	je     40c64a <__swc_fn_65555ab2_000049_ad48ec88+0x28a>
  40c644:	mov    QWORD PTR [rcx+0x48],rbx
  40c648:	jmp    40c64e <__swc_fn_65555ab2_000049_ad48ec88+0x28e>
  40c64a:	mov    QWORD PTR [rax+0x8],rbx
  40c64e:	mov    QWORD PTR [rax+0x10],rbx
  40c652:	mov    rcx,r14
  40c655:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40c65a:	mov    rax,rbx
  40c65d:	add    rsp,0x30
  40c661:	pop    r15
  40c663:	pop    r14
  40c665:	pop    r13
  40c667:	pop    r12
  40c669:	pop    rdi
  40c66a:	pop    rsi
  40c66b:	pop    rbx
  40c66c:	ret
	...

000000000040c680 <__swc_fn_65555ab2_000052_d846b172>:
  40c680:	push   rsi
  40c681:	push   rdi
  40c682:	push   r12
  40c684:	mov    rsi,rdx
  40c687:	mov    rdi,rcx
  40c68a:	lea    rax,[rcx+0x2a80]
  40c691:	mov    rcx,QWORD PTR [rax]
  40c694:	test   rcx,rcx
  40c697:	jne    40c69e <__swc_fn_65555ab2_000052_d846b172+0x1e>
  40c699:	pop    r12
  40c69b:	pop    rdi
  40c69c:	pop    rsi
  40c69d:	ret
  40c69e:	xor    ecx,ecx
  40c6a0:	xchg   QWORD PTR [rax],rcx
  40c6a3:	mov    r12,rcx
  40c6a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40c6b0:	cs nop WORD PTR [rax+rax*1+0x0]
  40c6ba:	nop    WORD PTR [rax+rax*1+0x0]
  40c6c0:	test   r12,r12
  40c6c3:	je     40c75a <__swc_fn_65555ab2_000052_d846b172+0xda>
  40c6c9:	mov    r8,r12
  40c6cc:	mov    r12,QWORD PTR [r12+0x78]
  40c6d1:	lea    rcx,[r8+0x70]
  40c6d5:	xor    eax,eax
  40c6d7:	xchg   DWORD PTR [r8+0x70],eax
  40c6db:	cmp    QWORD PTR [r8+0x40],rsi
  40c6df:	jne    40c6f6 <__swc_fn_65555ab2_000052_d846b172+0x76>
  40c6e1:	mov    eax,DWORD PTR [r8+0x6c]
  40c6e5:	test   eax,eax
  40c6e7:	je     40c6c0 <__swc_fn_65555ab2_000052_d846b172+0x40>
  40c6e9:	mov    rcx,rdi
  40c6ec:	mov    rdx,rsi
  40c6ef:	call   408030 <__swc_fn_65555ab2_000051_e072b516>
  40c6f4:	jmp    40c6c0 <__swc_fn_65555ab2_000052_d846b172+0x40>
  40c6f6:	mov    rax,QWORD PTR [r8+0x40]
  40c6fa:	test   rax,rax
  40c6fd:	je     40c6c0 <__swc_fn_65555ab2_000052_d846b172+0x40>
  40c6ff:	mov    eax,DWORD PTR [r8+0x6c]
  40c703:	test   eax,eax
  40c705:	je     40c6c0 <__swc_fn_65555ab2_000052_d846b172+0x40>
  40c707:	mov    r9d,0x1
  40c70d:	xor    eax,eax
  40c70f:	lock cmpxchg DWORD PTR [rcx],r9d
  40c714:	test   eax,eax
  40c716:	jne    40c6c0 <__swc_fn_65555ab2_000052_d846b172+0x40>
  40c718:	mov    rax,r8
  40c71b:	and    rax,0xffffffffffc00000
  40c722:	mov    rax,QWORD PTR [rax+0x8]
  40c726:	test   rax,rax
  40c729:	jne    40c731 <__swc_fn_65555ab2_000052_d846b172+0xb1>
  40c72b:	xor    eax,eax
  40c72d:	xchg   DWORD PTR [rcx],eax
  40c72f:	jmp    40c6c0 <__swc_fn_65555ab2_000052_d846b172+0x40>
  40c731:	lea    rcx,[rax+0x2a80]
  40c738:	mov    rax,QWORD PTR [rcx]
  40c73b:	mov    rdx,rax
  40c73e:	xchg   ax,ax
  40c740:	mov    QWORD PTR [r8+0x78],rdx
  40c744:	mov    rax,rdx
  40c747:	lock cmpxchg QWORD PTR [rcx],r8
  40c74c:	cmp    rax,rdx
  40c74f:	je     40c6c0 <__swc_fn_65555ab2_000052_d846b172+0x40>
  40c755:	mov    rdx,rax
  40c758:	jmp    40c740 <__swc_fn_65555ab2_000052_d846b172+0xc0>
  40c75a:	pop    r12
  40c75c:	pop    rdi
  40c75d:	pop    rsi
  40c75e:	ret
	...

000000000040c760 <__swc_fn_65555ab2_000055_2e3450f7>:
  40c760:	sub    rsp,0x8
  40c764:	mov    r9,r8
  40c767:	movzx  eax,BYTE PTR [r9+0x39]
  40c76c:	lea    rax,[rax+rax*4]
  40c770:	lea    rax,[rdx+rax*8+0x28]
  40c775:	cmp    QWORD PTR [rax],r9
  40c778:	je     40c780 <__swc_fn_65555ab2_000055_2e3450f7+0x20>
  40c77a:	cmp    QWORD PTR [rax+0x20],r9
  40c77e:	jne    40c785 <__swc_fn_65555ab2_000055_2e3450f7+0x25>
  40c780:	add    rsp,0x8
  40c784:	ret
  40c785:	cmp    QWORD PTR [rax+0x20],0x0
  40c78a:	je     40c797 <__swc_fn_65555ab2_000055_2e3450f7+0x37>
  40c78c:	mov    r8,QWORD PTR [rax+0x20]
  40c790:	cmp    DWORD PTR [r8+0x28],0x0
  40c795:	je     40c7a0 <__swc_fn_65555ab2_000055_2e3450f7+0x40>
  40c797:	mov    QWORD PTR [rax+0x20],r9
  40c79b:	add    rsp,0x8
  40c79f:	ret
  40c7a0:	mov    r8,r9
  40c7a3:	call   407f90 <__swc_fn_65555ab2_000048_137687bb>
  40c7a8:	mov    rax,r9
  40c7ab:	and    rax,0xffffffffffc00000
  40c7b2:	mov    rcx,rax
  40c7b5:	mov    rdx,r9
  40c7b8:	call   407af0 <__swc_fn_65555ab2_000018_283e2b5e>
  40c7bd:	add    rsp,0x8
  40c7c1:	ret
	...

000000000040c7d0 <__swc_fn_65555ab2_000058_1bb23e77>:
  40c7d0:	push   rsi
  40c7d1:	push   rdi
  40c7d2:	push   r12
  40c7d4:	mov    rsi,rdx
  40c7d7:	mov    rax,rdx
  40c7da:	shr    rax,0xc
  40c7de:	movabs rdx,0x9e3779b97f4a7c15
  40c7e8:	imul   rax,rdx
  40c7ec:	shr    rax,0x20
  40c7f0:	lea    rax,[rax*8+0x0]
  40c7f8:	shr    rax,0x20
  40c7fc:	lea    rax,[rax*8+0x0]
  40c804:	lea    rax,[rcx+rax*8+0x40]
  40c809:	xor    edx,edx
  40c80b:	test   dl,dl
  40c80d:	lea    rdi,[rcx+0x8]
  40c811:	cmove  rdi,rax
  40c815:	xor    edx,edx
  40c817:	test   dl,dl
  40c819:	lea    r12,[rcx+0x30]
  40c81d:	lea    rax,[rax+0x8]
  40c821:	cmove  r12,rax
  40c825:	mov    rcx,rdi
  40c828:	call   40e280 <__swc_fn_65555ab2_000139_86bb0f90>
  40c82d:	mov    rax,QWORD PTR [rsi+0x30]
  40c831:	test   rax,rax
  40c834:	jne    40c840 <__swc_fn_65555ab2_000058_1bb23e77+0x70>
  40c836:	mov    rax,QWORD PTR [rsi+0x38]
  40c83a:	mov    QWORD PTR [r12],rax
  40c83e:	jmp    40c848 <__swc_fn_65555ab2_000058_1bb23e77+0x78>
  40c840:	mov    rcx,QWORD PTR [rsi+0x38]
  40c844:	mov    QWORD PTR [rax+0x38],rcx
  40c848:	mov    rax,QWORD PTR [rsi+0x38]
  40c84c:	test   rax,rax
  40c84f:	je     40c859 <__swc_fn_65555ab2_000058_1bb23e77+0x89>
  40c851:	mov    rcx,QWORD PTR [rsi+0x30]
  40c855:	mov    QWORD PTR [rax+0x30],rcx
  40c859:	vxorps xmm0,xmm0,xmm0
  40c85d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  40c862:	mov    rcx,rdi
  40c865:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40c86a:	pop    r12
  40c86c:	pop    rdi
  40c86d:	pop    rsi
  40c86e:	ret
	...

000000000040c870 <__swc_fn_65555ab2_000061_ad030a10>:
  40c870:	mov    rax,QWORD PTR [rcx+0x250]
  40c877:	mov    rcx,rax
  40c87a:	cmp    rax,0x1000000
  40c881:	mov    eax,0x1000000
  40c886:	cmovb  rcx,rax
  40c88a:	mov    rax,rcx
  40c88d:	cmp    rcx,0x10000000
  40c894:	mov    ecx,0x10000000
  40c899:	cmova  rax,rcx
  40c89d:	ret
	...

000000000040c8a0 <__swc_fn_65555ab2_000064_ffcd96eb>:
  40c8a0:	push   rsi
  40c8a1:	push   rdi
  40c8a2:	push   r12
  40c8a4:	mov    rsi,rcx
  40c8a7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  40c8ae:	xor    r12d,r12d
  40c8b1:	test   rdi,rdi
  40c8b4:	jbe    40c8eb <__swc_fn_65555ab2_000064_ffcd96eb+0x4b>
  40c8b6:	cs nop WORD PTR [rax+rax*1+0x0]
  40c8c0:	lea    rax,[r12+r12*4]
  40c8c4:	lea    rax,[rsi+rax*8+0x268]
  40c8cc:	mov    rcx,rsi
  40c8cf:	mov    rdx,QWORD PTR [rax]
  40c8d2:	mov    r8,QWORD PTR [rax+0x8]
  40c8d6:	mov    rax,QWORD PTR [rax+0x10]
  40c8da:	mov    r9,rax
  40c8dd:	call   40c140 <__swc_fn_65555ab2_000043_d3c2ab54>
  40c8e2:	add    r12,0x1
  40c8e6:	cmp    r12,rdi
  40c8e9:	jb     40c8c0 <__swc_fn_65555ab2_000064_ffcd96eb+0x20>
  40c8eb:	vxorps xmm0,xmm0,xmm0
  40c8ef:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  40c8f7:	pop    r12
  40c8f9:	pop    rdi
  40c8fa:	pop    rsi
  40c8fb:	ret
  40c8fc:	add    BYTE PTR [rax],al
	...

000000000040c900 <__swc_fn_65555ab2_000067_8c7d044b>:
  40c900:	push   rsi
  40c901:	push   rdi
  40c902:	sub    rsp,0x8
  40c906:	mov    rsi,rcx
  40c909:	call   40f900 <__swc_fn_65555ab2_000056_df0696cd>
  40c90e:	mov    rdi,rax
  40c911:	mov    rcx,rsi
  40c914:	mov    rdx,rax
  40c917:	call   40c7d0 <__swc_fn_65555ab2_000058_1bb23e77>
  40c91c:	mov    rcx,QWORD PTR [rdi+0x28]
  40c920:	mov    rdx,QWORD PTR [rsi+0x250]
  40c927:	nop    WORD PTR [rax+rax*1+0x0]
  40c930:	mov    r8,rdx
  40c933:	sub    r8,rcx
  40c936:	mov    rax,rdx
  40c939:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40c942:	cmp    rax,rdx
  40c945:	je     40c94c <__swc_fn_65555ab2_000067_8c7d044b+0x4c>
  40c947:	mov    rdx,rax
  40c94a:	jmp    40c930 <__swc_fn_65555ab2_000067_8c7d044b+0x30>
  40c94c:	mov    rcx,rsi
  40c94f:	mov    rdx,QWORD PTR [rdi]
  40c952:	mov    r8,QWORD PTR [rdi+0x8]
  40c956:	mov    r9,QWORD PTR [rdi+0x10]
  40c95a:	call   40fa20 <__swc_fn_65555ab2_000062_b304235a>
  40c95f:	mov    rcx,rsi
  40c962:	call   40f660 <__swc_fn_65555ab2_000053_3af34d7f>
  40c967:	add    rsp,0x8
  40c96b:	pop    rdi
  40c96c:	pop    rsi
  40c96d:	ret
	...

000000000040c970 <__swc_fn_65555ab2_000070_97813b89>:
  40c970:	push   r12
  40c972:	push   r13
  40c974:	push   r14
  40c976:	push   rdi
  40c977:	push   rsi
  40c978:	sub    rsp,0x1b0
  40c97f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  40c988:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  40c991:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  40c99a:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  40c9a3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  40c9ac:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  40c9b5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  40c9be:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  40c9c7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  40c9d0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  40c9d9:	mov    r8,rdx
  40c9dc:	mov    r12,rcx
  40c9df:	mov    r13,QWORD PTR [r8+0x40]
  40c9e3:	test   r13,r13
  40c9e6:	jne    40c9f8 <__swc_fn_65555ab2_000070_97813b89+0x88>
  40c9e8:	add    rsp,0x1b0
  40c9ef:	pop    rsi
  40c9f0:	pop    rdi
  40c9f1:	pop    r14
  40c9f3:	pop    r13
  40c9f5:	pop    r12
  40c9f7:	ret
  40c9f8:	mov    QWORD PTR [r8+0x40],0x0
  40ca00:	lea    rax,[rip+0x17671]        # 424078 <__swc_bss_base_65555ab2+0x38>
  40ca07:	mov    rcx,r13
  40ca0a:	sub    rcx,QWORD PTR [rax+0x8]
  40ca0e:	mov    rax,QWORD PTR [rip+0x17673]        # 424088 <__swc_bss_base_65555ab2+0x48>
  40ca15:	cmp    rcx,rax
  40ca18:	jae    40ca44 <__swc_fn_65555ab2_000070_97813b89+0xd4>
  40ca1a:	mov    rax,r13
  40ca1d:	and    rax,0xffffffffffc00000
  40ca24:	mov    rcx,r13
  40ca27:	shr    rcx,0x10
  40ca2b:	and    ecx,0x3f
  40ca2e:	mov    edx,DWORD PTR [rax+0x28]
  40ca31:	shrx   ecx,ecx,edx
  40ca36:	shl    rcx,0x4
  40ca3a:	lea    r14,[rax+rcx*8+0x80]
  40ca42:	jmp    40ca5f <__swc_fn_65555ab2_000070_97813b89+0xef>
  40ca44:	mov    rcx,r13
  40ca47:	mov    QWORD PTR [rsp+0xf8],r8
  40ca4f:	call   40f2f0 <__swc_fn_65555ab2_000026_bcdc5519>
  40ca54:	mov    r8,QWORD PTR [rsp+0xf8]
  40ca5c:	mov    r14,rax
  40ca5f:	test   r14,r14
  40ca62:	jne    40ca74 <__swc_fn_65555ab2_000070_97813b89+0x104>
  40ca64:	mov    rcx,r12
  40ca67:	mov    rdx,r13
  40ca6a:	call   40c900 <__swc_fn_65555ab2_000067_8c7d044b>
  40ca6f:	jmp    40cb02 <__swc_fn_65555ab2_000070_97813b89+0x192>
  40ca74:	lea    rax,[rip+0x1558d]        # 422008 <__swc_data_base_65555ab2+0x8>
  40ca7b:	mov    rax,QWORD PTR [rax]
  40ca7e:	cmp    rax,0xffffffffffffffff
  40ca82:	je     40ca91 <__swc_fn_65555ab2_000070_97813b89+0x121>
  40ca84:	mov    eax,eax
  40ca86:	mov    edi,eax
  40ca88:	xor    eax,eax
  40ca8a:	call   407000 <pthread_getspecific@plt>
  40ca8f:	jmp    40ca93 <__swc_fn_65555ab2_000070_97813b89+0x123>
  40ca91:	xor    eax,eax
  40ca93:	test   rax,rax
  40ca96:	jne    40caa5 <__swc_fn_65555ab2_000070_97813b89+0x135>
  40ca98:	call   40f3c0 <__swc_fn_65555ab2_000035_cd1a4e8c>
  40ca9d:	mov    rcx,rax
  40caa0:	call   409fc0 <__swc_fn_65555ab2_000132_5f757033>
  40caa5:	test   rax,rax
  40caa8:	je     40caf7 <__swc_fn_65555ab2_000070_97813b89+0x187>
  40caaa:	cmp    QWORD PTR [r14+0x40],rax
  40caae:	jne    40caf7 <__swc_fn_65555ab2_000070_97813b89+0x187>
  40cab0:	mov    ecx,DWORD PTR [r14+0x6c]
  40cab4:	test   ecx,ecx
  40cab6:	je     40cad6 <__swc_fn_65555ab2_000070_97813b89+0x166>
  40cab8:	mov    rcx,r12
  40cabb:	mov    rdx,rax
  40cabe:	mov    r8,r14
  40cac1:	mov    QWORD PTR [rsp+0x100],rax
  40cac9:	call   408030 <__swc_fn_65555ab2_000051_e072b516>
  40cace:	mov    rax,QWORD PTR [rsp+0x100]
  40cad6:	mov    rcx,QWORD PTR [r14]
  40cad9:	mov    QWORD PTR [r13+0x0],rcx
  40cadd:	mov    QWORD PTR [r14],r13
  40cae0:	sub    DWORD PTR [r14+0x28],0x1
  40cae5:	jne    40cb02 <__swc_fn_65555ab2_000070_97813b89+0x192>
  40cae7:	mov    rcx,r12
  40caea:	mov    rdx,rax
  40caed:	mov    r8,r14
  40caf0:	call   40c760 <__swc_fn_65555ab2_000055_2e3450f7>
  40caf5:	jmp    40cb02 <__swc_fn_65555ab2_000070_97813b89+0x192>
  40caf7:	mov    rcx,r14
  40cafa:	mov    rdx,r13
  40cafd:	call   40ef30 <__swc_fn_65555ab2_000014_524c1f23>
  40cb02:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40cb0b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  40cb14:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40cb1d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  40cb26:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40cb2f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  40cb38:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  40cb41:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40cb4a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  40cb53:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40cb5c:	add    rsp,0x1b0
  40cb63:	pop    rsi
  40cb64:	pop    rdi
  40cb65:	pop    r14
  40cb67:	pop    r13
  40cb69:	pop    r12
  40cb6b:	ret
  40cb6c:	add    BYTE PTR [rax],al
	...

000000000040cb70 <__swc_fn_65555ab2_000073_9c99bf04>:
  40cb70:	push   rsi
  40cb71:	mov    rsi,rcx
  40cb74:	call   40c130 <__swc_fn_65555ab2_000040_eb6108f2>
  40cb79:	test   al,al
  40cb7b:	jne    40cb7f <__swc_fn_65555ab2_000073_9c99bf04+0xf>
  40cb7d:	pop    rsi
  40cb7e:	ret
  40cb7f:	lea    rax,[rip+0x176ba]        # 424240 <__swc_bss_base_65555ab2+0x200>
  40cb86:	cmp    rsi,rax
  40cb89:	jne    40cb8d <__swc_fn_65555ab2_000073_9c99bf04+0x1d>
  40cb8b:	pop    rsi
  40cb8c:	ret
  40cb8d:	mov    rcx,rsi
  40cb90:	call   40e280 <__swc_fn_65555ab2_000139_86bb0f90>
  40cb95:	mov    rcx,rsi
  40cb98:	call   408800 <__swc_fn_65555ab2_000072_61e60aab>
  40cb9d:	mov    rcx,rsi
  40cba0:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40cba5:	pop    rsi
  40cba6:	ret
	...

000000000040cbb0 <__swc_fn_65555ab2_000076_15bd096c>:
  40cbb0:	sub    rsp,0x8
  40cbb4:	call   408550 <__swc_fn_65555ab2_000069_7130736e>
  40cbb9:	add    rsp,0x8
  40cbbd:	ret
	...

000000000040cbc0 <__swc_fn_65555ab2_000079_a5fd3362>:
  40cbc0:	push   rsi
  40cbc1:	mov    rsi,rdx
  40cbc4:	call   408800 <__swc_fn_65555ab2_000072_61e60aab>
  40cbc9:	mov    QWORD PTR [rsi+0x40],0x0
  40cbd1:	pop    rsi
  40cbd2:	ret
	...

000000000040cbe0 <__swc_fn_65555ab2_000082_63a67586>:
  40cbe0:	mov    r8,rcx
  40cbe3:	mov    rcx,QWORD PTR [rcx]
  40cbe6:	cs nop WORD PTR [rax+rax*1+0x0]
  40cbf0:	mov    r9,rcx
  40cbf3:	sub    r9,rdx
  40cbf6:	mov    rax,rcx
  40cbf9:	lock cmpxchg QWORD PTR [r8],r9
  40cbfe:	cmp    rax,rcx
  40cc01:	je     40cc08 <__swc_fn_65555ab2_000082_63a67586+0x28>
  40cc03:	mov    rcx,rax
  40cc06:	jmp    40cbf0 <__swc_fn_65555ab2_000082_63a67586+0x10>
  40cc08:	mov    rax,rcx
  40cc0b:	ret
  40cc0c:	add    BYTE PTR [rax],al
	...

000000000040cc10 <__swc_fn_65555ab2_000085_c618ff58>:
  40cc10:	vxorps xmm0,xmm0,xmm0
  40cc14:	vmovups XMMWORD PTR [rcx],xmm0
  40cc18:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40cc1d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40cc22:	ret
	...

000000000040cc30 <__swc_fn_65555ab2_000088_0d280354>:
  40cc30:	push   rsi
  40cc31:	push   rdi
  40cc32:	push   r12
  40cc34:	push   r13
  40cc36:	push   r15
  40cc38:	push   r14
  40cc3a:	push   rbx
  40cc3b:	sub    rsp,0x60
  40cc3f:	mov    QWORD PTR [rsp+0x28],r11
  40cc44:	mov    rsi,rcx
  40cc47:	mov    rdi,rdx
  40cc4a:	mov    QWORD PTR [rsp+0x30],rdx
  40cc4f:	mov    r12,r8
  40cc52:	mov    r13,r9
  40cc55:	mov    QWORD PTR [rsp+0x38],r10
  40cc5a:	xor    r8d,r8d
  40cc5d:	call   40cf80 <__swc_fn_65555ab2_000094_63c1827b>
  40cc62:	test   al,al
  40cc64:	je     40cc79 <__swc_fn_65555ab2_000088_0d280354+0x49>
  40cc66:	mov    rax,r12
  40cc69:	add    rsp,0x60
  40cc6d:	pop    rbx
  40cc6e:	pop    r14
  40cc70:	pop    r15
  40cc72:	pop    r13
  40cc74:	pop    r12
  40cc76:	pop    rdi
  40cc77:	pop    rsi
  40cc78:	ret
  40cc79:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40cc7e:	je     40cc92 <__swc_fn_65555ab2_000088_0d280354+0x62>
  40cc80:	xor    eax,eax
  40cc82:	add    rsp,0x60
  40cc86:	pop    rbx
  40cc87:	pop    r14
  40cc89:	pop    r15
  40cc8b:	pop    r13
  40cc8d:	pop    r12
  40cc8f:	pop    rdi
  40cc90:	pop    rsi
  40cc91:	ret
  40cc92:	mov    r15,rdi
  40cc95:	mov    QWORD PTR [rsp+0x40],rdi
  40cc9a:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40cc9f:	jne    40cd0f <__swc_fn_65555ab2_000088_0d280354+0xdf>
  40cca1:	mov    r14,QWORD PTR [r15+0xb8]
  40cca8:	mov    rax,QWORD PTR [r15+0xc0]
  40ccaf:	mov    r15,rax
  40ccb2:	xor    edi,edi
  40ccb4:	test   r15,r15
  40ccb7:	je     40cd0f <__swc_fn_65555ab2_000088_0d280354+0xdf>
  40ccb9:	nop    DWORD PTR [rax+0x0]
  40ccc0:	lea    rbx,[rdi*8+0x0]
  40ccc8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  40cccd:	mov    rcx,rax
  40ccd0:	mov    rdx,rsi
  40ccd3:	xor    r8d,r8d
  40ccd6:	call   40cf80 <__swc_fn_65555ab2_000094_63c1827b>
  40ccdb:	test   al,al
  40ccdd:	je     40cd05 <__swc_fn_65555ab2_000088_0d280354+0xd5>
  40ccdf:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  40cce4:	test   rax,rax
  40cce7:	je     40cd05 <__swc_fn_65555ab2_000088_0d280354+0xd5>
  40cce9:	test   r13,r13
  40ccec:	je     40ccf2 <__swc_fn_65555ab2_000088_0d280354+0xc2>
  40ccee:	mov    QWORD PTR [r13+0x8],rax
  40ccf2:	mov    rax,r12
  40ccf5:	add    rsp,0x60
  40ccf9:	pop    rbx
  40ccfa:	pop    r14
  40ccfc:	pop    r15
  40ccfe:	pop    r13
  40cd00:	pop    r12
  40cd02:	pop    rdi
  40cd03:	pop    rsi
  40cd04:	ret
  40cd05:	add    rdi,0x1
  40cd09:	sub    r15,0x1
  40cd0d:	jne    40ccc0 <__swc_fn_65555ab2_000088_0d280354+0x90>
  40cd0f:	test   r12,r12
  40cd12:	jne    40cd26 <__swc_fn_65555ab2_000088_0d280354+0xf6>
  40cd14:	xor    eax,eax
  40cd16:	add    rsp,0x60
  40cd1a:	pop    rbx
  40cd1b:	pop    r14
  40cd1d:	pop    r15
  40cd1f:	pop    r13
  40cd21:	pop    r12
  40cd23:	pop    rdi
  40cd24:	pop    rsi
  40cd25:	ret
  40cd26:	mov    rbx,QWORD PTR [rsp+0x28]
  40cd2b:	mov    rdi,QWORD PTR [rsp+0x30]
  40cd30:	mov    rax,rbx
  40cd33:	test   rax,rax
  40cd36:	je     40cd66 <__swc_fn_65555ab2_000088_0d280354+0x136>
  40cd38:	nop    DWORD PTR [rax+rax*1+0x0]
  40cd40:	cmp    QWORD PTR [rax+0x8],r12
  40cd44:	jne    40cd5d <__swc_fn_65555ab2_000088_0d280354+0x12d>
  40cd46:	cmp    QWORD PTR [rax],rdi
  40cd49:	jne    40cd5d <__swc_fn_65555ab2_000088_0d280354+0x12d>
  40cd4b:	xor    eax,eax
  40cd4d:	add    rsp,0x60
  40cd51:	pop    rbx
  40cd52:	pop    r14
  40cd54:	pop    r15
  40cd56:	pop    r13
  40cd58:	pop    r12
  40cd5a:	pop    rdi
  40cd5b:	pop    rsi
  40cd5c:	ret
  40cd5d:	mov    rax,QWORD PTR [rax+0x10]
  40cd61:	test   rax,rax
  40cd64:	jne    40cd40 <__swc_fn_65555ab2_000088_0d280354+0x110>
  40cd66:	lea    r14,[rsp+0x8]
  40cd6b:	mov    QWORD PTR [rsp+0x48],r14
  40cd70:	mov    QWORD PTR [rsp+0x8],rdi
  40cd75:	mov    QWORD PTR [rsp+0x10],r12
  40cd7a:	mov    QWORD PTR [rsp+0x18],rbx
  40cd7f:	mov    r15,QWORD PTR [rsp+0x40]
  40cd84:	mov    rbx,QWORD PTR [r15+0x98]
  40cd8b:	mov    rax,QWORD PTR [r15+0xa0]
  40cd92:	mov    rdi,rax
  40cd95:	mov    r15,QWORD PTR [rsp+0x38]
  40cd9a:	xor    r14d,r14d
  40cd9d:	test   rdi,rdi
  40cda0:	je     40ce4a <__swc_fn_65555ab2_000088_0d280354+0x21a>
  40cda6:	cs nop WORD PTR [rax+rax*1+0x0]
  40cdb0:	mov    QWORD PTR [rsp+0x50],rdi
  40cdb5:	lea    rdi,[r14*8+0x0]
  40cdbd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  40cdc2:	mov    rcx,rax
  40cdc5:	call   410a00 <__swc_fn_65555ab2_000086_3953ef98>
  40cdca:	test   DWORD PTR [rax+0x28],0x10000
  40cdd1:	je     40cdd8 <__swc_fn_65555ab2_000088_0d280354+0x1a8>
  40cdd3:	test   r15b,r15b
  40cdd6:	je     40ce31 <__swc_fn_65555ab2_000088_0d280354+0x201>
  40cdd8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  40cddc:	lea    rdi,[r12+rcx*1]
  40cde0:	cmp    BYTE PTR [rax+0x2c],0x6
  40cde4:	jne    40cdf8 <__swc_fn_65555ab2_000088_0d280354+0x1c8>
  40cde6:	mov    rax,QWORD PTR [rax+0x40]
  40cdea:	mov    rcx,rax
  40cded:	call   410a00 <__swc_fn_65555ab2_000086_3953ef98>
  40cdf2:	mov    rcx,QWORD PTR [rdi]
  40cdf5:	mov    rdi,rcx
  40cdf8:	test   rdi,rdi
  40cdfb:	je     40ce31 <__swc_fn_65555ab2_000088_0d280354+0x201>
  40cdfd:	mov    rcx,rsi
  40ce00:	mov    rdx,rax
  40ce03:	mov    r8,rdi
  40ce06:	mov    r9,r13
  40ce09:	mov    al,r15b
  40ce0c:	mov    r10,rax
  40ce0f:	mov    rdi,QWORD PTR [rsp+0x48]
  40ce14:	mov    r11,rdi
  40ce17:	call   40cc30 <__swc_fn_65555ab2_000088_0d280354>
  40ce1c:	test   rax,rax
  40ce1f:	je     40ce31 <__swc_fn_65555ab2_000088_0d280354+0x201>
  40ce21:	add    rsp,0x60
  40ce25:	pop    rbx
  40ce26:	pop    r14
  40ce28:	pop    r15
  40ce2a:	pop    r13
  40ce2c:	pop    r12
  40ce2e:	pop    rdi
  40ce2f:	pop    rsi
  40ce30:	ret
  40ce31:	add    r14,0x1
  40ce35:	mov    rax,QWORD PTR [rsp+0x50]
  40ce3a:	sub    rax,0x1
  40ce3e:	mov    rdi,rax
  40ce41:	test   rax,rax
  40ce44:	jne    40cdb0 <__swc_fn_65555ab2_000088_0d280354+0x180>
  40ce4a:	xor    eax,eax
  40ce4c:	add    rsp,0x60
  40ce50:	pop    rbx
  40ce51:	pop    r14
  40ce53:	pop    r15
  40ce55:	pop    r13
  40ce57:	pop    r12
  40ce59:	pop    rdi
  40ce5a:	pop    rsi
  40ce5b:	ret
  40ce5c:	add    BYTE PTR [rax],al
	...

000000000040ce60 <__swc_fn_65555ab2_000091_c1c9085b>:
  40ce60:	push   rsi
  40ce61:	push   rdi
  40ce62:	push   r12
  40ce64:	push   r13
  40ce66:	push   r14
  40ce68:	push   r15
  40ce6a:	sub    rsp,0x78
  40ce6e:	mov    rsi,r10
  40ce71:	mov    QWORD PTR [rsp+0x68],r10
  40ce76:	mov    rdi,rcx
  40ce79:	mov    r12,rdx
  40ce7c:	mov    r13,r8
  40ce7f:	mov    r14,r9
  40ce82:	xor    r8d,r8d
  40ce85:	call   40cf80 <__swc_fn_65555ab2_000094_63c1827b>
  40ce8a:	test   al,al
  40ce8c:	je     40ceb5 <__swc_fn_65555ab2_000091_c1c9085b+0x55>
  40ce8e:	mov    rcx,r14
  40ce91:	mov    rdx,r12
  40ce94:	mov    r8,r13
  40ce97:	mov    r9,rsi
  40ce9a:	call   408c60 <__swc_fn_65555ab2_000090_23214800>
  40ce9f:	test   al,al
  40cea1:	je     40ceb5 <__swc_fn_65555ab2_000091_c1c9085b+0x55>
  40cea3:	mov    rax,r13
  40cea6:	add    rsp,0x78
  40ceaa:	pop    r15
  40ceac:	pop    r14
  40ceae:	pop    r13
  40ceb0:	pop    r12
  40ceb2:	pop    rdi
  40ceb3:	pop    rsi
  40ceb4:	ret
  40ceb5:	cmp    BYTE PTR [r12+0x2c],0xe
  40cebb:	je     40cece <__swc_fn_65555ab2_000091_c1c9085b+0x6e>
  40cebd:	xor    eax,eax
  40cebf:	add    rsp,0x78
  40cec3:	pop    r15
  40cec5:	pop    r14
  40cec7:	pop    r13
  40cec9:	pop    r12
  40cecb:	pop    rdi
  40cecc:	pop    rsi
  40cecd:	ret
  40cece:	mov    r15,QWORD PTR [r12+0x98]
  40ced6:	mov    rax,QWORD PTR [r12+0xa0]
  40cede:	mov    r12,rax
  40cee1:	xor    esi,esi
  40cee3:	test   r12,r12
  40cee6:	je     40cf59 <__swc_fn_65555ab2_000091_c1c9085b+0xf9>
  40cee8:	nop    DWORD PTR [rax+rax*1+0x0]
  40cef0:	mov    QWORD PTR [rsp+0x70],r12
  40cef5:	lea    r12,[rsi*8+0x0]
  40cefd:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  40cf02:	mov    rcx,rax
  40cf05:	call   410a00 <__swc_fn_65555ab2_000086_3953ef98>
  40cf0a:	cmp    BYTE PTR [rax+0x2c],0xe
  40cf0e:	jne    40cf44 <__swc_fn_65555ab2_000091_c1c9085b+0xe4>
  40cf10:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  40cf15:	lea    r8,[r13+rcx*1+0x0]
  40cf1a:	mov    rcx,rdi
  40cf1d:	mov    rdx,rax
  40cf20:	mov    r9,r14
  40cf23:	mov    r12,QWORD PTR [rsp+0x68]
  40cf28:	mov    r10,r12
  40cf2b:	call   40ce60 <__swc_fn_65555ab2_000091_c1c9085b>
  40cf30:	test   rax,rax
  40cf33:	je     40cf44 <__swc_fn_65555ab2_000091_c1c9085b+0xe4>
  40cf35:	add    rsp,0x78
  40cf39:	pop    r15
  40cf3b:	pop    r14
  40cf3d:	pop    r13
  40cf3f:	pop    r12
  40cf41:	pop    rdi
  40cf42:	pop    rsi
  40cf43:	ret
  40cf44:	add    rsi,0x1
  40cf48:	mov    rax,QWORD PTR [rsp+0x70]
  40cf4d:	sub    rax,0x1
  40cf51:	mov    r12,rax
  40cf54:	test   rax,rax
  40cf57:	jne    40cef0 <__swc_fn_65555ab2_000091_c1c9085b+0x90>
  40cf59:	xor    eax,eax
  40cf5b:	add    rsp,0x78
  40cf5f:	pop    r15
  40cf61:	pop    r14
  40cf63:	pop    r13
  40cf65:	pop    r12
  40cf67:	pop    rdi
  40cf68:	pop    rsi
  40cf69:	ret
	...

000000000040cf80 <__swc_fn_65555ab2_000094_63c1827b>:
  40cf80:	push   rbx
  40cf81:	push   rsi
  40cf82:	push   rdi
  40cf83:	push   r12
  40cf85:	push   r13
  40cf87:	push   r14
  40cf89:	push   r15
  40cf8b:	sub    rsp,0x120
  40cf92:	mov    rbx,r8
  40cf95:	mov    rsi,rdx
  40cf98:	test   rcx,rcx
  40cf9b:	jne    40cfba <__swc_fn_65555ab2_000094_63c1827b+0x3a>
  40cf9d:	test   rsi,rsi
  40cfa0:	jne    40cfba <__swc_fn_65555ab2_000094_63c1827b+0x3a>
  40cfa2:	mov    eax,0x1
  40cfa7:	add    rsp,0x120
  40cfae:	pop    r15
  40cfb0:	pop    r14
  40cfb2:	pop    r13
  40cfb4:	pop    r12
  40cfb6:	pop    rdi
  40cfb7:	pop    rsi
  40cfb8:	pop    rbx
  40cfb9:	ret
  40cfba:	test   rcx,rcx
  40cfbd:	je     40cfc4 <__swc_fn_65555ab2_000094_63c1827b+0x44>
  40cfbf:	test   rsi,rsi
  40cfc2:	jne    40cfd9 <__swc_fn_65555ab2_000094_63c1827b+0x59>
  40cfc4:	xor    eax,eax
  40cfc6:	add    rsp,0x120
  40cfcd:	pop    r15
  40cfcf:	pop    r14
  40cfd1:	pop    r13
  40cfd3:	pop    r12
  40cfd5:	pop    rdi
  40cfd6:	pop    rsi
  40cfd7:	pop    rbx
  40cfd8:	ret
  40cfd9:	call   410a00 <__swc_fn_65555ab2_000086_3953ef98>
  40cfde:	mov    rdi,rax
  40cfe1:	mov    rcx,rsi
  40cfe4:	call   410a00 <__swc_fn_65555ab2_000086_3953ef98>
  40cfe9:	test   bl,0x1
  40cfec:	je     40d02a <__swc_fn_65555ab2_000094_63c1827b+0xaa>
  40cfee:	rex cmp BYTE PTR [rdi+0x2c],0x6
  40cff3:	jne    40d02a <__swc_fn_65555ab2_000094_63c1827b+0xaa>
  40cff5:	mov    ecx,DWORD PTR [rdi+0x28]
  40cff8:	test   ecx,0x1000
  40cffe:	je     40d02a <__swc_fn_65555ab2_000094_63c1827b+0xaa>
  40d000:	test   ecx,0x10000
  40d006:	je     40d02a <__swc_fn_65555ab2_000094_63c1827b+0xaa>
  40d008:	mov    rcx,QWORD PTR [rdi+0x40]
  40d00c:	mov    rdx,rax
  40d00f:	mov    r8d,ebx
  40d012:	call   40cf80 <__swc_fn_65555ab2_000094_63c1827b>
  40d017:	add    rsp,0x120
  40d01e:	pop    r15
  40d020:	pop    r14
  40d022:	pop    r13
  40d024:	pop    r12
  40d026:	pop    rdi
  40d027:	pop    rsi
  40d028:	pop    rbx
  40d029:	ret
  40d02a:	mov    cl,BYTE PTR [rax+0x2c]
  40d02d:	rex cmp BYTE PTR [rdi+0x2c],cl
  40d031:	jne    40d03b <__swc_fn_65555ab2_000094_63c1827b+0xbb>
  40d033:	mov    ecx,DWORD PTR [rax+0x20]
  40d036:	cmp    DWORD PTR [rdi+0x20],ecx
  40d039:	je     40d050 <__swc_fn_65555ab2_000094_63c1827b+0xd0>
  40d03b:	xor    eax,eax
  40d03d:	add    rsp,0x120
  40d044:	pop    r15
  40d046:	pop    r14
  40d048:	pop    r13
  40d04a:	pop    r12
  40d04c:	pop    rdi
  40d04d:	pop    rsi
  40d04e:	pop    rbx
  40d04f:	ret
  40d050:	mov    ecx,DWORD PTR [rdi+0x28]
  40d053:	and    ecx,0xffb5ffff
  40d059:	mov    edx,DWORD PTR [rax+0x28]
  40d05c:	and    edx,0xffb5ffff
  40d062:	cmp    ecx,edx
  40d064:	je     40d07b <__swc_fn_65555ab2_000094_63c1827b+0xfb>
  40d066:	xor    eax,eax
  40d068:	add    rsp,0x120
  40d06f:	pop    r15
  40d071:	pop    r14
  40d073:	pop    r13
  40d075:	pop    r12
  40d077:	pop    rdi
  40d078:	pop    rsi
  40d079:	pop    rbx
  40d07a:	ret
  40d07b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  40d080:	jne    40d0d5 <__swc_fn_65555ab2_000094_63c1827b+0x155>
  40d082:	mov    cl,BYTE PTR [rax+0x40]
  40d085:	rex cmp BYTE PTR [rdi+0x40],cl
  40d089:	je     40d0a0 <__swc_fn_65555ab2_000094_63c1827b+0x120>
  40d08b:	xor    eax,eax
  40d08d:	add    rsp,0x120
  40d094:	pop    r15
  40d096:	pop    r14
  40d098:	pop    r13
  40d09a:	pop    r12
  40d09c:	pop    rdi
  40d09d:	pop    rsi
  40d09e:	pop    rbx
  40d09f:	ret
  40d0a0:	rex cmp BYTE PTR [rdi+0x40],0xd
  40d0a5:	je     40d0bd <__swc_fn_65555ab2_000094_63c1827b+0x13d>
  40d0a7:	rex cmp BYTE PTR [rdi+0x40],0xf
  40d0ac:	sete   cl
  40d0af:	je     40d0b9 <__swc_fn_65555ab2_000094_63c1827b+0x139>
  40d0b1:	rex cmp BYTE PTR [rdi+0x40],0xe
  40d0b6:	sete   cl
  40d0b9:	test   cl,cl
  40d0bb:	je     40d0d5 <__swc_fn_65555ab2_000094_63c1827b+0x155>
  40d0bd:	mov    eax,0x1
  40d0c2:	add    rsp,0x120
  40d0c9:	pop    r15
  40d0cb:	pop    r14
  40d0cd:	pop    r13
  40d0cf:	pop    r12
  40d0d1:	pop    rdi
  40d0d2:	pop    rsi
  40d0d3:	pop    rbx
  40d0d4:	ret
  40d0d5:	test   DWORD PTR [rdi+0x28],0x200200
  40d0dc:	je     40d28f <__swc_fn_65555ab2_000094_63c1827b+0x30f>
  40d0e2:	mov    rsi,QWORD PTR [rdi+0x88]
  40d0e9:	mov    rdi,QWORD PTR [rdi+0x90]
  40d0f0:	mov    r12,QWORD PTR [rax+0x88]
  40d0f7:	mov    rax,QWORD PTR [rax+0x90]
  40d0fe:	cmp    rdi,rax
  40d101:	je     40d118 <__swc_fn_65555ab2_000094_63c1827b+0x198>
  40d103:	xor    eax,eax
  40d105:	add    rsp,0x120
  40d10c:	pop    r15
  40d10e:	pop    r14
  40d110:	pop    r13
  40d112:	pop    r12
  40d114:	pop    rdi
  40d115:	pop    rsi
  40d116:	pop    rbx
  40d117:	ret
  40d118:	test   rsi,rsi
  40d11b:	je     40d122 <__swc_fn_65555ab2_000094_63c1827b+0x1a2>
  40d11d:	test   r12,r12
  40d120:	jne    40d13a <__swc_fn_65555ab2_000094_63c1827b+0x1ba>
  40d122:	mov    eax,0x1
  40d127:	add    rsp,0x120
  40d12e:	pop    r15
  40d130:	pop    r14
  40d132:	pop    r13
  40d134:	pop    r12
  40d136:	pop    rdi
  40d137:	pop    rsi
  40d138:	pop    rbx
  40d139:	ret
  40d13a:	xor    r13d,r13d
  40d13d:	test   rdi,rdi
  40d140:	jbe    40d277 <__swc_fn_65555ab2_000094_63c1827b+0x2f7>
  40d146:	lea    r14,[rsp+0x78]
  40d14b:	lea    r15,[rsp+0xb8]
  40d153:	cs nop WORD PTR [rax+rax*1+0x0]
  40d15d:	cs nop WORD PTR [rax+rax*1+0x0]
  40d167:	nop    WORD PTR [rax+rax*1+0x0]
  40d170:	lea    rax,[r13*8+0x0]
  40d178:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40d17d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40d183:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  40d189:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40d192:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  40d198:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40d1a1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  40d1a7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40d1b0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  40d1b6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40d1bf:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  40d1c6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  40d1cf:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  40d1d6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  40d1df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  40d1e6:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40d1ef:	xor    al,al
  40d1f1:	rex test BYTE PTR [rsp+0xb0],0x1
  40d1fa:	je     40d201 <__swc_fn_65555ab2_000094_63c1827b+0x281>
  40d1fc:	mov    eax,0x1
  40d201:	rex test BYTE PTR [rsp+0xf0],0x1
  40d20a:	je     40d211 <__swc_fn_65555ab2_000094_63c1827b+0x291>
  40d20c:	mov    eax,0x1
  40d211:	test   al,al
  40d213:	jne    40d239 <__swc_fn_65555ab2_000094_63c1827b+0x2b9>
  40d215:	mov    rcx,r14
  40d218:	mov    rdx,r15
  40d21b:	call   40e790 <__swc_fn_65555ab2_000151_6fb05988>
  40d220:	test   al,al
  40d222:	jne    40d239 <__swc_fn_65555ab2_000094_63c1827b+0x2b9>
  40d224:	xor    eax,eax
  40d226:	add    rsp,0x120
  40d22d:	pop    r15
  40d22f:	pop    r14
  40d231:	pop    r13
  40d233:	pop    r12
  40d235:	pop    rdi
  40d236:	pop    rsi
  40d237:	pop    rbx
  40d238:	ret
  40d239:	mov    rcx,QWORD PTR [rsp+0x88]
  40d241:	mov    rdx,QWORD PTR [rsp+0xc8]
  40d249:	mov    r8d,ebx
  40d24c:	call   40cf80 <__swc_fn_65555ab2_000094_63c1827b>
  40d251:	test   al,al
  40d253:	jne    40d26a <__swc_fn_65555ab2_000094_63c1827b+0x2ea>
  40d255:	xor    eax,eax
  40d257:	add    rsp,0x120
  40d25e:	pop    r15
  40d260:	pop    r14
  40d262:	pop    r13
  40d264:	pop    r12
  40d266:	pop    rdi
  40d267:	pop    rsi
  40d268:	pop    rbx
  40d269:	ret
  40d26a:	add    r13,0x1
  40d26e:	cmp    r13,rdi
  40d271:	jb     40d170 <__swc_fn_65555ab2_000094_63c1827b+0x1f0>
  40d277:	mov    eax,0x1
  40d27c:	add    rsp,0x120
  40d283:	pop    r15
  40d285:	pop    r14
  40d287:	pop    r13
  40d289:	pop    r12
  40d28b:	pop    rdi
  40d28c:	pop    rsi
  40d28d:	pop    rbx
  40d28e:	ret
  40d28f:	test   bl,0x2
  40d292:	je     40d2b4 <__swc_fn_65555ab2_000094_63c1827b+0x334>
  40d294:	lea    rcx,[rdi+0x10]
  40d298:	lea    rdx,[rax+0x10]
  40d29c:	call   40e790 <__swc_fn_65555ab2_000151_6fb05988>
  40d2a1:	add    rsp,0x120
  40d2a8:	pop    r15
  40d2aa:	pop    r14
  40d2ac:	pop    r13
  40d2ae:	pop    r12
  40d2b0:	pop    rdi
  40d2b1:	pop    rsi
  40d2b2:	pop    rbx
  40d2b3:	ret
  40d2b4:	mov    rcx,rdi
  40d2b7:	mov    rdx,rax
  40d2ba:	call   40e790 <__swc_fn_65555ab2_000151_6fb05988>
  40d2bf:	add    rsp,0x120
  40d2c6:	pop    r15
  40d2c8:	pop    r14
  40d2ca:	pop    r13
  40d2cc:	pop    r12
  40d2ce:	pop    rdi
  40d2cf:	pop    rsi
  40d2d0:	pop    rbx
  40d2d1:	ret
	...

000000000040d2e0 <__swc_fn_65555ab2_000097_4185993f>:
  40d2e0:	push   rbx
  40d2e1:	mov    rbx,rcx
  40d2e4:	call   410b30 <__swc_fn_65555ab2_000095_ad13d15c>
  40d2e9:	movzx  r11d,al
  40d2ed:	mov    r8b,r11b
  40d2f0:	test   r8b,r8b
  40d2f3:	jne    40d30d <__swc_fn_65555ab2_000097_4185993f+0x2d>
  40d2f5:	mov    r11d,0x1
  40d2fb:	mov    r10,rbx
  40d2fe:	mov    r9,r11
  40d301:	and    r10,r11
  40d304:	test   r10,r10
  40d307:	setne  dl
  40d30a:	mov    r8b,dl
  40d30d:	mov    r10b,r8b
  40d310:	test   r10b,r10b
  40d313:	je     40d317 <__swc_fn_65555ab2_000097_4185993f+0x37>
  40d315:	pop    rbx
  40d316:	ret
  40d317:	call   40a160 <__swc_fn_65555ab2_000141_519fdf94>
  40d31c:	movzx  r10d,al
  40d320:	test   r10b,r10b
  40d323:	je     40d327 <__swc_fn_65555ab2_000097_4185993f+0x47>
  40d325:	pop    rbx
  40d326:	ret
  40d327:	lea    r10,[rip+0x61ba]        # 4134e8 <__swc_rdata_base_65555ab2+0x3d8>
  40d32e:	mov    rax,r10
  40d331:	mov    rcx,rax
  40d334:	call   409c90 <__swc_fn_65555ab2_000120_2648f149>
  40d339:	call   4113b0 <__swc_fn_65555ab2_000122_be2e2f68>
  40d33e:	pop    rbx
  40d33f:	ret

000000000040d340 <__swc_fn_65555ab2_000100_d4bdcaa4>:
  40d340:	push   rbx
  40d341:	sub    rsp,0x70
  40d345:	vxorps xmm0,xmm0,xmm0
  40d349:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40d34f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40d355:	vzeroupper
  40d358:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40d35e:	mov    QWORD PTR [rsp+0x48],rdx
  40d363:	mov    rax,r8
  40d366:	cmp    r8,0x1
  40d36a:	mov    edx,0x1
  40d36f:	cmovb  rax,rdx
  40d373:	mov    QWORD PTR [rsp+0x50],rax
  40d378:	mov    rbx,QWORD PTR [rcx+0x8]
  40d37c:	mov    rbx,QWORD PTR [rbx+0x18]
  40d380:	mov    rcx,QWORD PTR [rcx]
  40d383:	lea    rdx,[rsp+0x8]
  40d388:	call   rbx
  40d38a:	add    rsp,0x70
  40d38e:	pop    rbx
  40d38f:	ret

000000000040d390 <__swc_fn_65555ab2_000103_2fdd2c61>:
  40d390:	push   rbx
  40d391:	push   rsi
  40d392:	push   rdi
  40d393:	sub    rsp,0x30
  40d397:	mov    rbx,rcx
  40d39a:	test   rcx,rcx
  40d39d:	je     40d3b2 <__swc_fn_65555ab2_000103_2fdd2c61+0x22>
  40d39f:	mov    rcx,rbx
  40d3a2:	mov    edx,0x1
  40d3a7:	call   40cbe0 <__swc_fn_65555ab2_000082_63a67586>
  40d3ac:	cmp    rax,0x1
  40d3b0:	je     40d3ba <__swc_fn_65555ab2_000103_2fdd2c61+0x2a>
  40d3b2:	add    rsp,0x30
  40d3b6:	pop    rdi
  40d3b7:	pop    rsi
  40d3b8:	pop    rbx
  40d3b9:	ret
  40d3ba:	lea    rsi,[rsp+0x8]
  40d3bf:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40d3c4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40d3ca:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  40d3cf:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40d3d5:	mov    rax,QWORD PTR [rsp+0x20]
  40d3da:	test   rax,rax
  40d3dd:	je     40d3f3 <__swc_fn_65555ab2_000103_2fdd2c61+0x63>
  40d3df:	test   DWORD PTR [rax+0x28],0x400000
  40d3e6:	je     40d3f3 <__swc_fn_65555ab2_000103_2fdd2c61+0x63>
  40d3e8:	mov    rcx,QWORD PTR [rax+0x30]
  40d3ec:	test   rcx,rcx
  40d3ef:	cmovne rax,rcx
  40d3f3:	mov    edi,DWORD PTR [rax+0x20]
  40d3f6:	lea    rcx,[rsp+0x18]
  40d3fb:	call   410d10 <__swc_fn_65555ab2_000104_3c3b96fb>
  40d400:	mov    rcx,rsi
  40d403:	mov    rdx,QWORD PTR [rsp+0x18]
  40d408:	mov    r8,rdi
  40d40b:	call   40d340 <__swc_fn_65555ab2_000100_d4bdcaa4>
  40d410:	mov    rcx,QWORD PTR [rbx+0x28]
  40d414:	call   409240 <__swc_fn_65555ab2_000102_e34f54dc>
  40d419:	mov    rcx,rsi
  40d41c:	mov    rdx,rbx
  40d41f:	mov    r8d,0x30
  40d425:	call   40d340 <__swc_fn_65555ab2_000100_d4bdcaa4>
  40d42a:	add    rsp,0x30
  40d42e:	pop    rdi
  40d42f:	pop    rsi
  40d430:	pop    rbx
  40d431:	ret
	...

000000000040d440 <__swc_fn_65555ab2_000106_ffe51047>:
  40d440:	push   rbp
  40d441:	push   rbx
  40d442:	push   rsi
  40d443:	push   rdi
  40d444:	push   r12
  40d446:	push   r13
  40d448:	push   r14
  40d44a:	push   r15
  40d44c:	sub    rsp,0x500
  40d453:	mov    rbp,rsp
  40d456:	mov    rbx,rsp
  40d459:	mov    rsi,rdx
  40d45c:	mov    rdi,rcx
  40d45f:	mov    rcx,QWORD PTR [rip+0x16bda]        # 424040 <__swc_bss_base_65555ab2>
  40d466:	test   rcx,rcx
  40d469:	jne    40d483 <__swc_fn_65555ab2_000106_ffe51047+0x43>
  40d46b:	sub    rsp,0x8
  40d46f:	call   40eb80 <__swc_fn_65555ab2_000169_994c8876>
  40d474:	add    rsp,0x8
  40d478:	lea    rcx,[rax+0x1]
  40d47c:	mov    QWORD PTR [rip+0x16bbd],rcx        # 424040 <__swc_bss_base_65555ab2>
  40d483:	dec    rcx
  40d486:	sub    rsp,0x8
  40d48a:	call   40ba40 <__swc_fn_65555ab2_000171_360af05d>
  40d48f:	add    rsp,0x8
  40d493:	mov    r12,rax
  40d496:	mov    QWORD PTR [rsp+0x4f0],rax
  40d49e:	lea    rax,[rip+0x6183]        # 413628 <__swc_rdata_base_65555ab2+0x518>
  40d4a5:	sub    rsp,0x20
  40d4a9:	mov    rcx,rsp
  40d4ac:	mov    QWORD PTR [rcx],rax
  40d4af:	lea    r13,[rip+0x5e7a]        # 413330 <__swc_rdata_base_65555ab2+0x220>
  40d4b6:	mov    QWORD PTR [rcx+0x8],r13
  40d4ba:	mov    QWORD PTR [rcx+0x10],rsp
  40d4be:	mov    QWORD PTR [rcx+0x18],0x1
  40d4c6:	lea    rcx,[rsp+0x10]
  40d4cb:	sub    rsp,0x8
  40d4cf:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  40d4d4:	add    rsp,0x8
  40d4d8:	add    rsp,0x20
  40d4dc:	lea    rax,[rip+0x6155]        # 413638 <__swc_rdata_base_65555ab2+0x528>
  40d4e3:	sub    rsp,0x20
  40d4e7:	mov    rcx,rsp
  40d4ea:	mov    QWORD PTR [rcx],rax
  40d4ed:	mov    QWORD PTR [rcx+0x8],r13
  40d4f1:	mov    QWORD PTR [rcx+0x10],rsp
  40d4f5:	mov    QWORD PTR [rcx+0x18],0x1
  40d4fd:	lea    rcx,[rsp+0x10]
  40d502:	sub    rsp,0x8
  40d506:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  40d50b:	add    rsp,0x8
  40d50f:	add    rsp,0x20
  40d513:	lea    r14,[rip+0x5e06]        # 413320 <__swc_rdata_base_65555ab2+0x210>
  40d51a:	sub    rsp,0x50
  40d51e:	mov    rax,rsp
  40d521:	vmovups xmm0,XMMWORD PTR [rip+0x6247]        # 413770 <__swc_rdata_base_65555ab2+0x660>
  40d529:	vmovups XMMWORD PTR [rax],xmm0
  40d52d:	mov    QWORD PTR [rax+0x10],rsp
  40d531:	mov    QWORD PTR [rax+0x18],r13
  40d535:	mov    QWORD PTR [rax+0x20],rdi
  40d539:	lea    rdi,[rip+0x6108]        # 413648 <__swc_rdata_base_65555ab2+0x538>
  40d540:	mov    QWORD PTR [rax+0x28],rdi
  40d544:	mov    QWORD PTR [rax+0x30],r14
  40d548:	mov    QWORD PTR [rax+0x38],r13
  40d54c:	lea    rcx,[rsp+0x10]
  40d551:	mov    QWORD PTR [rax+0x40],rcx
  40d555:	mov    QWORD PTR [rax+0x48],0x3
  40d55d:	lea    rcx,[rsp+0x40]
  40d562:	sub    rsp,0x8
  40d566:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  40d56b:	add    rsp,0x8
  40d56f:	add    rsp,0x50
  40d573:	lea    rax,[rip+0x6116]        # 413690 <__swc_rdata_base_65555ab2+0x580>
  40d57a:	sub    rsp,0x20
  40d57e:	mov    rcx,rsp
  40d581:	mov    QWORD PTR [rcx],rax
  40d584:	mov    QWORD PTR [rcx+0x8],r13
  40d588:	mov    QWORD PTR [rcx+0x10],rsp
  40d58c:	mov    QWORD PTR [rcx+0x18],0x1
  40d594:	lea    rcx,[rsp+0x10]
  40d599:	sub    rsp,0x8
  40d59d:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  40d5a2:	add    rsp,0x8
  40d5a6:	add    rsp,0x20
  40d5aa:	mov    eax,DWORD PTR [rsi+0x20]
  40d5ad:	mov    ecx,DWORD PTR [rsi+0x24]
  40d5b0:	sub    rsp,0xa0
  40d5b7:	mov    rdx,rsp
  40d5ba:	mov    QWORD PTR [rdx+0x30],rsi
  40d5be:	mov    QWORD PTR [rdx+0x38],rdi
  40d5c2:	vmovups xmm0,XMMWORD PTR [rip+0x613e]        # 413708 <__swc_rdata_base_65555ab2+0x5f8>
  40d5ca:	vmovups XMMWORD PTR [rdx],xmm0
  40d5ce:	mov    QWORD PTR [rdx+0x40],rsp
  40d5d2:	mov    QWORD PTR [rdx+0x48],r13
  40d5d6:	mov    DWORD PTR [rdx+0x10],eax
  40d5d9:	lea    rax,[rsp+0x10]
  40d5de:	mov    QWORD PTR [rdx+0x50],rax
  40d5e2:	lea    rax,[rip+0x60b7]        # 4136a0 <__swc_rdata_base_65555ab2+0x590>
  40d5e9:	mov    QWORD PTR [rdx+0x58],rax
  40d5ed:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  40d5f2:	lea    r8,[rsp+0x18]
  40d5f7:	mov    QWORD PTR [rdx+0x60],r8
  40d5fb:	mov    QWORD PTR [rdx+0x68],r13
  40d5ff:	mov    DWORD PTR [rdx+0x28],ecx
  40d602:	lea    rcx,[rdx+0x28]
  40d606:	mov    QWORD PTR [rdx+0x70],rcx
  40d60a:	mov    QWORD PTR [rdx+0x78],rax
  40d60e:	mov    QWORD PTR [rdx+0x80],r14
  40d615:	mov    QWORD PTR [rdx+0x88],r13
  40d61c:	lea    rax,[rdx+0x30]
  40d620:	mov    QWORD PTR [rdx+0x90],rax
  40d627:	mov    QWORD PTR [rdx+0x98],0x6
  40d632:	lea    rcx,[rdx+0x90]
  40d639:	sub    rsp,0x8
  40d63d:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  40d642:	add    rsp,0x8
  40d646:	add    rsp,0xa0
  40d64d:	sub    rsp,0x20
  40d651:	mov    rax,rsp
  40d654:	mov    QWORD PTR [rax],r14
  40d657:	mov    QWORD PTR [rax+0x8],r13
  40d65b:	mov    QWORD PTR [rax+0x10],rsp
  40d65f:	mov    QWORD PTR [rax+0x18],0x1
  40d667:	lea    rcx,[rsp+0x10]
  40d66c:	sub    rsp,0x8
  40d670:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  40d675:	add    rsp,0x8
  40d679:	add    rsp,0x20
  40d67d:	mov    eax,DWORD PTR [r12+0x9ac]
  40d685:	test   eax,eax
  40d687:	je     40d8c0 <__swc_fn_65555ab2_000106_ffe51047+0x480>
  40d68d:	lea    rax,[rip+0x6054]        # 4136e8 <__swc_rdata_base_65555ab2+0x5d8>
  40d694:	sub    rsp,0x20
  40d698:	mov    rcx,rsp
  40d69b:	mov    QWORD PTR [rcx],rax
  40d69e:	mov    QWORD PTR [rcx+0x8],r13
  40d6a2:	mov    QWORD PTR [rcx+0x10],rsp
  40d6a6:	mov    QWORD PTR [rcx+0x18],0x1
  40d6ae:	lea    rcx,[rsp+0x10]
  40d6b3:	sub    rsp,0x8
  40d6b7:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  40d6bc:	add    rsp,0x8
  40d6c0:	add    rsp,0x20
  40d6c4:	mov    eax,DWORD PTR [r12+0x9ac]
  40d6cc:	dec    eax
  40d6ce:	mov    esi,eax
  40d6d0:	test   esi,esi
  40d6d2:	jl     40d890 <__swc_fn_65555ab2_000106_ffe51047+0x450>
  40d6d8:	jmp    40d6e4 <__swc_fn_65555ab2_000106_ffe51047+0x2a4>
  40d6da:	nop    WORD PTR [rax+rax*1+0x0]
  40d6e0:	dec    esi
  40d6e2:	jmp    40d6d0 <__swc_fn_65555ab2_000106_ffe51047+0x290>
  40d6e4:	lea    rax,[rip+0x600d]        # 4136f8 <__swc_rdata_base_65555ab2+0x5e8>
  40d6eb:	sub    rsp,0x20
  40d6ef:	mov    rcx,rsp
  40d6f2:	mov    QWORD PTR [rcx],rax
  40d6f5:	mov    QWORD PTR [rcx+0x8],r13
  40d6f9:	mov    QWORD PTR [rcx+0x10],rsp
  40d6fd:	mov    QWORD PTR [rcx+0x18],0x1
  40d705:	lea    rcx,[rsp+0x10]
  40d70a:	sub    rsp,0x8
  40d70e:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  40d713:	add    rsp,0x8
  40d717:	add    rsp,0x20
  40d71b:	movsxd rax,esi
  40d71e:	imul   r15,rax,0x30
  40d722:	add    r15,r12
  40d725:	add    r15,0xf8
  40d72c:	sub    rsp,0x20
  40d730:	mov    rax,rsp
  40d733:	mov    QWORD PTR [rax],r15
  40d736:	mov    QWORD PTR [rax+0x8],rdi
  40d73a:	mov    QWORD PTR [rax+0x10],rsp
  40d73e:	mov    QWORD PTR [rax+0x18],0x1
  40d746:	lea    rcx,[rsp+0x10]
  40d74b:	sub    rsp,0x8
  40d74f:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  40d754:	add    rsp,0x8
  40d758:	add    rsp,0x20
  40d75c:	mov    QWORD PTR [rsp+0x4f8],rsi
  40d764:	lea    rsi,[rip+0x5f9d]        # 413708 <__swc_rdata_base_65555ab2+0x5f8>
  40d76b:	sub    rsp,0x20
  40d76f:	mov    rax,rsp
  40d772:	mov    QWORD PTR [rax],rsi
  40d775:	mov    QWORD PTR [rax+0x8],r13
  40d779:	mov    QWORD PTR [rax+0x10],rsp
  40d77d:	mov    QWORD PTR [rax+0x18],0x1
  40d785:	lea    rcx,[rsp+0x10]
  40d78a:	sub    rsp,0x8
  40d78e:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  40d793:	add    rsp,0x8
  40d797:	add    rsp,0x20
  40d79b:	sub    rsp,0x30
  40d79f:	mov    rax,rsp
  40d7a2:	mov    ecx,DWORD PTR [r15+0x20]
  40d7a6:	mov    QWORD PTR [rax],rcx
  40d7a9:	mov    QWORD PTR [rax+0x8],rsp
  40d7ad:	lea    rdi,[rip+0x5f64]        # 413718 <__swc_rdata_base_65555ab2+0x608>
  40d7b4:	mov    QWORD PTR [rax+0x10],rdi
  40d7b8:	lea    rcx,[rsp+0x8]
  40d7bd:	mov    QWORD PTR [rax+0x18],rcx
  40d7c1:	mov    QWORD PTR [rax+0x20],0x1
  40d7c9:	lea    rcx,[rsp+0x18]
  40d7ce:	sub    rsp,0x8
  40d7d2:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  40d7d7:	add    rsp,0x8
  40d7db:	add    rsp,0x30
  40d7df:	sub    rsp,0x20
  40d7e3:	mov    rax,rsp
  40d7e6:	mov    QWORD PTR [rax],rsi
  40d7e9:	mov    QWORD PTR [rax+0x8],r13
  40d7ed:	mov    QWORD PTR [rax+0x10],rsp
  40d7f1:	mov    QWORD PTR [rax+0x18],0x1
  40d7f9:	lea    rcx,[rsp+0x10]
  40d7fe:	sub    rsp,0x8
  40d802:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  40d807:	add    rsp,0x8
  40d80b:	add    rsp,0x20
  40d80f:	sub    rsp,0x30
  40d813:	mov    rax,rsp
  40d816:	mov    ecx,DWORD PTR [r15+0x24]
  40d81a:	mov    QWORD PTR [rax],rcx
  40d81d:	mov    QWORD PTR [rax+0x8],rsp
  40d821:	mov    QWORD PTR [rax+0x10],rdi
  40d825:	lea    rcx,[rsp+0x8]
  40d82a:	mov    QWORD PTR [rax+0x18],rcx
  40d82e:	mov    QWORD PTR [rax+0x20],0x1
  40d836:	lea    rcx,[rsp+0x18]
  40d83b:	sub    rsp,0x8
  40d83f:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  40d844:	add    rsp,0x8
  40d848:	add    rsp,0x30
  40d84c:	sub    rsp,0x20
  40d850:	mov    rax,rsp
  40d853:	mov    QWORD PTR [rax],r14
  40d856:	mov    QWORD PTR [rax+0x8],r13
  40d85a:	mov    QWORD PTR [rax+0x10],rsp
  40d85e:	mov    QWORD PTR [rax+0x18],0x1
  40d866:	lea    rcx,[rsp+0x10]
  40d86b:	sub    rsp,0x8
  40d86f:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  40d874:	add    rsp,0x8
  40d878:	add    rsp,0x20
  40d87c:	lea    rdi,[rip+0x5dc5]        # 413648 <__swc_rdata_base_65555ab2+0x538>
  40d883:	mov    rsi,QWORD PTR [rsp+0x4f8]
  40d88b:	jmp    40d6e0 <__swc_fn_65555ab2_000106_ffe51047+0x2a0>
  40d890:	sub    rsp,0x20
  40d894:	mov    rax,rsp
  40d897:	mov    QWORD PTR [rax],r14
  40d89a:	mov    QWORD PTR [rax+0x8],r13
  40d89e:	mov    QWORD PTR [rax+0x10],rsp
  40d8a2:	mov    QWORD PTR [rax+0x18],0x1
  40d8aa:	lea    rcx,[rsp+0x10]
  40d8af:	sub    rsp,0x8
  40d8b3:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  40d8b8:	add    rsp,0x8
  40d8bc:	add    rsp,0x20
  40d8c0:	lea    rax,[rbx+0x28]
  40d8c4:	mov    rcx,rax
  40d8c7:	mov    QWORD PTR [rbx+0x28],0x0
  40d8cf:	mov    QWORD PTR [rbx+0x30],0x0
  40d8d7:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  40d8dc:	add    rcx,0x10
  40d8e0:	mov    edx,0x1f
  40d8e5:	cs nop WORD PTR [rax+rax*1+0x0]
  40d8ef:	nop
  40d8f0:	vmovups XMMWORD PTR [rcx],xmm0
  40d8f4:	add    rcx,0x10
  40d8f8:	sub    rdx,0x1
  40d8fc:	jne    40d8f0 <__swc_fn_65555ab2_000106_ffe51047+0x4b0>
  40d8fe:	lea    rsi,[rbx+0x228]
  40d905:	xor    ecx,ecx
  40d907:	cs nop WORD PTR [rax+rax*1+0x0]
  40d911:	cs nop WORD PTR [rax+rax*1+0x0]
  40d91b:	nop    DWORD PTR [rax+rax*1+0x0]
  40d920:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  40d925:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  40d92a:	add    rcx,0x10
  40d92e:	cmp    rcx,0x200
  40d935:	jne    40d920 <__swc_fn_65555ab2_000106_ffe51047+0x4e0>
  40d937:	mov    eax,DWORD PTR [r12+0xbc8]
  40d93f:	lea    rcx,[r12+0x9c8]
  40d947:	mov    QWORD PTR [rbx+0x428],rcx
  40d94e:	mov    QWORD PTR [rbx+0x430],rax
  40d955:	lea    rdi,[rbx+0x438]
  40d95c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  40d964:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  40d96c:	mov    eax,DWORD PTR [r12+0xbc8]
  40d974:	test   eax,eax
  40d976:	jne    40d9c3 <__swc_fn_65555ab2_000106_ffe51047+0x583>
  40d978:	lea    rax,[rbx+0x448]
  40d97f:	mov    QWORD PTR [rbx+0x448],rsi
  40d986:	mov    QWORD PTR [rax+0x8],0x40
  40d98e:	mov    ecx,0x1
  40d993:	mov    rdx,rax
  40d996:	sub    rsp,0x8
  40d99a:	call   409da0 <__swc_fn_65555ab2_000123_4f256d58>
  40d99f:	add    rsp,0x8
  40d9a3:	mov    QWORD PTR [rbx+0x460],rsi
  40d9aa:	mov    ecx,eax
  40d9ac:	mov    QWORD PTR [rbx+0x468],rcx
  40d9b3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  40d9bb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  40d9c3:	mov    rsi,QWORD PTR [rbx+0x438]
  40d9ca:	mov    rax,QWORD PTR [rbx+0x440]
  40d9d1:	mov    r15,rax
  40d9d4:	xor    r12d,r12d
  40d9d7:	test   r15,r15
  40d9da:	je     40da90 <__swc_fn_65555ab2_000106_ffe51047+0x650>
  40d9e0:	mov    rax,QWORD PTR [rsi+r12*8]
  40d9e4:	test   rax,rax
  40d9e7:	je     40da06 <__swc_fn_65555ab2_000106_ffe51047+0x5c6>
  40d9e9:	lea    rcx,[rbx+0x4b8]
  40d9f0:	mov    rdx,rax
  40d9f3:	sub    rsp,0x8
  40d9f7:	call   40e8f0 <__swc_fn_65555ab2_000166_cc119975>
  40d9fc:	add    rsp,0x8
  40da00:	mov    al,BYTE PTR [rax]
  40da02:	test   al,al
  40da04:	jne    40da12 <__swc_fn_65555ab2_000106_ffe51047+0x5d2>
  40da06:	add    r12,0x1
  40da0a:	sub    r15,0x1
  40da0e:	jne    40d9e0 <__swc_fn_65555ab2_000106_ffe51047+0x5a0>
  40da10:	jmp    40da90 <__swc_fn_65555ab2_000106_ffe51047+0x650>
  40da12:	lea    rax,[rip+0x5d47]        # 413760 <__swc_rdata_base_65555ab2+0x650>
  40da19:	sub    rsp,0x20
  40da1d:	mov    rcx,rsp
  40da20:	mov    QWORD PTR [rcx],rax
  40da23:	mov    QWORD PTR [rcx+0x8],r13
  40da27:	mov    QWORD PTR [rcx+0x10],rsp
  40da2b:	mov    QWORD PTR [rcx+0x18],0x1
  40da33:	lea    rcx,[rsp+0x10]
  40da38:	sub    rsp,0x8
  40da3c:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  40da41:	add    rsp,0x8
  40da45:	add    rsp,0x20
  40da49:	mov    rcx,rdi
  40da4c:	xor    edx,edx
  40da4e:	mov    al,0x1
  40da50:	mov    r8,rax
  40da53:	sub    rsp,0x8
  40da57:	call   411c40 <__swc_fn_65555ab2_000167_bcc835b8>
  40da5c:	add    rsp,0x8
  40da60:	sub    rsp,0x20
  40da64:	mov    rax,rsp
  40da67:	mov    QWORD PTR [rax],r14
  40da6a:	mov    QWORD PTR [rax+0x8],r13
  40da6e:	mov    QWORD PTR [rax+0x10],rsp
  40da72:	mov    QWORD PTR [rax+0x18],0x1
  40da7a:	lea    rcx,[rsp+0x10]
  40da7f:	sub    rsp,0x8
  40da83:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  40da88:	add    rsp,0x8
  40da8c:	add    rsp,0x20
  40da90:	mov    r12,QWORD PTR [rsp+0x4f0]
  40da98:	mov    DWORD PTR [r12+0xbc8],0x0
  40daa4:	add    rsp,0x500
  40daab:	pop    r15
  40daad:	pop    r14
  40daaf:	pop    r13
  40dab1:	pop    r12
  40dab3:	pop    rdi
  40dab4:	pop    rsi
  40dab5:	pop    rbx
  40dab6:	pop    rbp
  40dab7:	ret
	...

000000000040dac0 <__swc_fn_65555ab2_000109_7c204aac>:
  40dac0:	sub    rsp,0x8
  40dac4:	test   r8,r8
  40dac7:	je     40dace <__swc_fn_65555ab2_000109_7c204aac+0xe>
  40dac9:	call   4094d0 <__swc_fn_65555ab2_000108_c51c3158>
  40dace:	add    rsp,0x8
  40dad2:	ret
	...

000000000040dae0 <__swc_fn_65555ab2_000112_126150d1>:
  40dae0:	push   rsi
  40dae1:	push   rdi
  40dae2:	push   r12
  40dae4:	push   r13
  40dae6:	sub    rsp,0xd8
  40daed:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40daf3:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40daf9:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40daff:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40db05:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40db0b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40db14:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40db1d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40db26:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40db2f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40db38:	xor    eax,eax
  40db3a:	call   407050 <getpid@plt>
  40db3f:	mov    rsi,rax
  40db42:	lea    rdi,[rip+0x191f7]        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  40db49:	mov    r12,QWORD PTR [rdi]
  40db4c:	test   r12,r12
  40db4f:	je     40db5d <__swc_fn_65555ab2_000112_126150d1+0x7d>
  40db51:	cmp    DWORD PTR [r12+0x10],esi
  40db56:	jne    40db5d <__swc_fn_65555ab2_000112_126150d1+0x7d>
  40db58:	mov    rax,r12
  40db5b:	jmp    40dbc0 <__swc_fn_65555ab2_000112_126150d1+0xe0>
  40db5d:	mov    ecx,0x4
  40db62:	mov    edx,0x18
  40db67:	call   4095b0 <__swc_fn_65555ab2_000111_6814119b>
  40db6c:	mov    rcx,rax
  40db6f:	test   rax,rax
  40db72:	jne    40db78 <__swc_fn_65555ab2_000112_126150d1+0x98>
  40db74:	xor    eax,eax
  40db76:	jmp    40dbc0 <__swc_fn_65555ab2_000112_126150d1+0xe0>
  40db78:	mov    DWORD PTR [rcx+0x10],esi
  40db7b:	mov    rax,r12
  40db7e:	lock cmpxchg QWORD PTR [rdi],rcx
  40db83:	mov    r13,rax
  40db86:	cmp    rax,r12
  40db89:	je     40db9f <__swc_fn_65555ab2_000112_126150d1+0xbf>
  40db8b:	mov    rdi,rcx
  40db8e:	mov    esi,0x18
  40db93:	xor    eax,eax
  40db95:	call   407160 <munmap@plt>
  40db9a:	mov    rax,r13
  40db9d:	jmp    40dbc0 <__swc_fn_65555ab2_000112_126150d1+0xe0>
  40db9f:	test   r12,r12
  40dba2:	je     40dbbd <__swc_fn_65555ab2_000112_126150d1+0xdd>
  40dba4:	mov    rdi,r12
  40dba7:	mov    esi,0x18
  40dbac:	xor    eax,eax
  40dbae:	mov    QWORD PTR [rsp+0x28],rcx
  40dbb3:	call   407160 <munmap@plt>
  40dbb8:	mov    rcx,QWORD PTR [rsp+0x28]
  40dbbd:	mov    rax,rcx
  40dbc0:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40dbc6:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40dbcc:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40dbd2:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40dbd8:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40dbde:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40dbe7:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40dbf0:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40dbf9:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40dc02:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40dc0b:	add    rsp,0xd8
  40dc12:	pop    r13
  40dc14:	pop    r12
  40dc16:	pop    rdi
  40dc17:	pop    rsi
  40dc18:	ret
  40dc19:	add    BYTE PTR [rax],al
  40dc1b:	add    BYTE PTR [rax],al
  40dc1d:	add    BYTE PTR [rax],al
	...

000000000040dc20 <__swc_fn_65555ab2_000115_36905703>:
  40dc20:	push   rbx
  40dc21:	push   r12
  40dc23:	push   rdi
  40dc24:	push   rsi
  40dc25:	sub    rsp,0xa8
  40dc2c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40dc32:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40dc38:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40dc3e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40dc44:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40dc4a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40dc50:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40dc56:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40dc5c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40dc65:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40dc6e:	mov    rbx,rdx
  40dc71:	mov    r12,rcx
  40dc74:	mov    rdi,rcx
  40dc77:	mov    rsi,rdx
  40dc7a:	mov    edx,0x3
  40dc7f:	xor    eax,eax
  40dc81:	call   407170 <mprotect@plt>
  40dc86:	test   eax,eax
  40dc88:	je     40dc8e <__swc_fn_65555ab2_000115_36905703+0x6e>
  40dc8a:	xor    eax,eax
  40dc8c:	jmp    40dca3 <__swc_fn_65555ab2_000115_36905703+0x83>
  40dc8e:	mov    rcx,r12
  40dc91:	mov    rdx,rbx
  40dc94:	mov    al,0x1
  40dc96:	mov    r8,rax
  40dc99:	call   409be0 <__swc_fn_65555ab2_000114_5f48311c>
  40dc9e:	mov    eax,0x1
  40dca3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40dca9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40dcaf:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40dcb5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40dcbb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40dcc1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40dcc7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40dccd:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40dcd3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40dcdc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40dce5:	add    rsp,0xa8
  40dcec:	pop    rsi
  40dced:	pop    rdi
  40dcee:	pop    r12
  40dcf0:	pop    rbx
  40dcf1:	ret
	...

000000000040dd00 <__swc_fn_65555ab2_000118_5208f471>:
  40dd00:	sub    rsp,0x8
  40dd04:	test   rcx,rcx
  40dd07:	jne    40dd0e <__swc_fn_65555ab2_000118_5208f471+0xe>
  40dd09:	add    rsp,0x8
  40dd0d:	ret
  40dd0e:	call   411260 <__swc_fn_65555ab2_000119_d3318640>
  40dd13:	add    rsp,0x8
  40dd17:	ret
	...

000000000040dd20 <__swc_fn_65555ab2_000121_0a5fa85a>:
  40dd20:	push   rdi
  40dd21:	push   rsi
  40dd22:	sub    rsp,0xa8
  40dd29:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40dd2f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40dd35:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40dd3b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40dd41:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40dd47:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40dd4d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40dd53:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40dd59:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40dd62:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40dd6b:	xor    edi,edi
  40dd6d:	xor    eax,eax
  40dd6f:	call   407180 <exit@plt>
  40dd74:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40dd7a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40dd80:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40dd86:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40dd8c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40dd92:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40dd98:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40dd9e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40dda4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ddad:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ddb6:	add    rsp,0xa8
  40ddbd:	pop    rsi
  40ddbe:	pop    rdi
  40ddbf:	ret

000000000040ddc0 <__swc_fn_65555ab2_000124_83db7238>:
  40ddc0:	push   rbx
  40ddc1:	push   rsi
  40ddc2:	push   rdi
  40ddc3:	push   r12
  40ddc5:	sub    rsp,0x18
  40ddc9:	mov    rbx,r8
  40ddcc:	mov    rsi,rcx
  40ddcf:	mov    rdi,rdx
  40ddd2:	mov    rcx,QWORD PTR [rip+0x16267]        # 424040 <__swc_bss_base_65555ab2>
  40ddd9:	test   rcx,rcx
  40dddc:	jne    40ddee <__swc_fn_65555ab2_000124_83db7238+0x2e>
  40ddde:	call   40eb80 <__swc_fn_65555ab2_000169_994c8876>
  40dde3:	lea    rcx,[rax+0x1]
  40dde7:	mov    QWORD PTR [rip+0x16252],rcx        # 424040 <__swc_bss_base_65555ab2>
  40ddee:	dec    rcx
  40ddf1:	call   40ba40 <__swc_fn_65555ab2_000171_360af05d>
  40ddf6:	mov    r12,rax
  40ddf9:	cmp    ebx,0x3
  40ddfc:	jne    40de0f <__swc_fn_65555ab2_000124_83db7238+0x4f>
  40ddfe:	mov    rax,QWORD PTR [r12+0xbd0]
  40de06:	test   rax,rax
  40de09:	jne    40df4c <__swc_fn_65555ab2_000124_83db7238+0x18c>
  40de0f:	cmp    ebx,0x5
  40de12:	jne    40de36 <__swc_fn_65555ab2_000124_83db7238+0x76>
  40de14:	call   410b30 <__swc_fn_65555ab2_000095_ad13d15c>
  40de19:	test   al,al
  40de1b:	jne    40de36 <__swc_fn_65555ab2_000124_83db7238+0x76>
  40de1d:	mov    rcx,rsi
  40de20:	mov    rdx,rdi
  40de23:	call   40b9f0 <__swc_fn_65555ab2_000168_3459066f>
  40de28:	test   al,al
  40de2a:	je     40de36 <__swc_fn_65555ab2_000124_83db7238+0x76>
  40de2c:	add    rsp,0x18
  40de30:	pop    r12
  40de32:	pop    rdi
  40de33:	pop    rsi
  40de34:	pop    rbx
  40de35:	ret
  40de36:	call   410b30 <__swc_fn_65555ab2_000095_ad13d15c>
  40de3b:	test   al,al
  40de3d:	jne    40deaf <__swc_fn_65555ab2_000124_83db7238+0xef>
  40de3f:	vmovups xmm0,XMMWORD PTR [rsi]
  40de43:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40de49:	mov    rax,QWORD PTR [rsp+0x8]
  40de4e:	test   rax,rax
  40de51:	jne    40dea2 <__swc_fn_65555ab2_000124_83db7238+0xe2>
  40de53:	cmp    ebx,0x3
  40de56:	je     40de64 <__swc_fn_65555ab2_000124_83db7238+0xa4>
  40de58:	cmp    ebx,0x4
  40de5b:	je     40de74 <__swc_fn_65555ab2_000124_83db7238+0xb4>
  40de5d:	cmp    ebx,0x5
  40de60:	je     40de84 <__swc_fn_65555ab2_000124_83db7238+0xc4>
  40de62:	jmp    40de94 <__swc_fn_65555ab2_000124_83db7238+0xd4>
  40de64:	vmovups xmm0,XMMWORD PTR [rip+0x5944]        # 4137b0 <__swc_rdata_base_65555ab2+0x6a0>
  40de6c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40de72:	jmp    40dea2 <__swc_fn_65555ab2_000124_83db7238+0xe2>
  40de74:	vmovups xmm0,XMMWORD PTR [rip+0x5944]        # 4137c0 <__swc_rdata_base_65555ab2+0x6b0>
  40de7c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40de82:	jmp    40dea2 <__swc_fn_65555ab2_000124_83db7238+0xe2>
  40de84:	vmovups xmm0,XMMWORD PTR [rip+0x5944]        # 4137d0 <__swc_rdata_base_65555ab2+0x6c0>
  40de8c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40de92:	jmp    40dea2 <__swc_fn_65555ab2_000124_83db7238+0xe2>
  40de94:	vmovups xmm0,XMMWORD PTR [rip+0x5944]        # 4137e0 <__swc_rdata_base_65555ab2+0x6d0>
  40de9c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dea2:	lea    rcx,[rsp+0x8]
  40dea7:	mov    rdx,rdi
  40deaa:	call   410d80 <__swc_fn_65555ab2_000107_90faaa26>
  40deaf:	vmovups xmm0,XMMWORD PTR [rdi]
  40deb3:	vmovups XMMWORD PTR [r12+0x940],xmm0
  40debd:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  40dec2:	vmovups XMMWORD PTR [r12+0x950],xmm0
  40decc:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  40ded1:	vmovups XMMWORD PTR [r12+0x960],xmm0
  40dedb:	lea    rax,[r12+0x940]
  40dee3:	mov    QWORD PTR [r12+0x970],rax
  40deeb:	mov    rax,QWORD PTR [rsi]
  40deee:	mov    QWORD PTR [r12+0x978],rax
  40def6:	mov    rax,QWORD PTR [rsi+0x8]
  40defa:	mov    QWORD PTR [r12+0x980],rax
  40df02:	movsxd rax,ebx
  40df05:	mov    QWORD PTR [r12+0x988],rax
  40df0d:	cmp    ebx,0x5
  40df10:	je     40df19 <__swc_fn_65555ab2_000124_83db7238+0x159>
  40df12:	xor    ecx,ecx
  40df14:	call   40ecb0 <__swc_fn_65555ab2_000178_718d7b54>
  40df19:	mov    rbx,QWORD PTR [r12+0xbe8]
  40df21:	test   rbx,rbx
  40df24:	je     40df35 <__swc_fn_65555ab2_000124_83db7238+0x175>
  40df26:	mov    rcx,r12
  40df29:	call   rbx
  40df2b:	add    rsp,0x18
  40df2f:	pop    r12
  40df31:	pop    rdi
  40df32:	pop    rsi
  40df33:	pop    rbx
  40df34:	ret
  40df35:	mov    rcx,rsi
  40df38:	call   409c90 <__swc_fn_65555ab2_000120_2648f149>
  40df3d:	call   4113b0 <__swc_fn_65555ab2_000122_be2e2f68>
  40df42:	add    rsp,0x18
  40df46:	pop    r12
  40df48:	pop    rdi
  40df49:	pop    rsi
  40df4a:	pop    rbx
  40df4b:	ret
  40df4c:	mov    rcx,rsi
  40df4f:	mov    rdx,rdi
  40df52:	call   410d80 <__swc_fn_65555ab2_000107_90faaa26>
  40df57:	jmp    40de0f <__swc_fn_65555ab2_000124_83db7238+0x4f>
  40df5c:	add    BYTE PTR [rax],al
	...

000000000040df60 <__swc_fn_65555ab2_000127_58f0f391>:
  40df60:	push   rdi
  40df61:	push   rsi
  40df62:	sub    rsp,0xb8
  40df69:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40df6f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40df75:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40df7b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40df81:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40df87:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40df8d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40df93:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40df9c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40dfa5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40dfae:	mov    DWORD PTR [rsp+0x8],0x0
  40dfb6:	lea    rdi,[rsp+0x8]
  40dfbb:	xor    esi,esi
  40dfbd:	xor    eax,eax
  40dfbf:	call   407190 <pthread_key_create@plt>
  40dfc4:	test   eax,eax
  40dfc6:	jne    40dfce <__swc_fn_65555ab2_000127_58f0f391+0x6e>
  40dfc8:	mov    eax,DWORD PTR [rsp+0x8]
  40dfcc:	jmp    40dfd5 <__swc_fn_65555ab2_000127_58f0f391+0x75>
  40dfce:	mov    rax,0xffffffffffffffff
  40dfd5:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40dfdb:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40dfe1:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40dfe7:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40dfed:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40dff3:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40dff9:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40dfff:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40e008:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40e011:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40e01a:	add    rsp,0xb8
  40e021:	pop    rsi
  40e022:	pop    rdi
  40e023:	ret
	...

000000000040e030 <__swc_fn_65555ab2_000130_4a82cdf6>:
  40e030:	push   rdi
  40e031:	push   rsi
  40e032:	sub    rsp,0xb8
  40e039:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40e03f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40e045:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40e04b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40e051:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40e057:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40e05d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40e063:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40e06c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40e075:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40e07e:	mov    DWORD PTR [rsp+0x8],0x0
  40e086:	lea    rdi,[rsp+0x8]
  40e08b:	mov    rsi,rcx
  40e08e:	xor    eax,eax
  40e090:	call   407190 <pthread_key_create@plt>
  40e095:	test   eax,eax
  40e097:	jne    40e0a2 <__swc_fn_65555ab2_000130_4a82cdf6+0x72>
  40e099:	mov    eax,DWORD PTR [rsp+0x8]
  40e09d:	inc    rax
  40e0a0:	jmp    40e0a4 <__swc_fn_65555ab2_000130_4a82cdf6+0x74>
  40e0a2:	xor    eax,eax
  40e0a4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40e0aa:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40e0b0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40e0b6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40e0bc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40e0c2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40e0c8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40e0ce:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40e0d7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40e0e0:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40e0e9:	add    rsp,0xb8
  40e0f0:	pop    rsi
  40e0f1:	pop    rdi
  40e0f2:	ret
	...

000000000040e100 <__swc_fn_65555ab2_000133_ae5891af>:
  40e100:	push   rdi
  40e101:	push   rsi
  40e102:	sub    rsp,0xa8
  40e109:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e10f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e115:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e11b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e121:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e127:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e12d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e133:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e139:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e142:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e14b:	test   rcx,rcx
  40e14e:	setne  al
  40e151:	je     40e16a <__swc_fn_65555ab2_000133_ae5891af+0x6a>
  40e153:	lea    rax,[rcx-0x1]
  40e157:	mov    eax,eax
  40e159:	mov    edi,eax
  40e15b:	mov    rsi,rdx
  40e15e:	xor    eax,eax
  40e160:	call   407120 <pthread_setspecific@plt>
  40e165:	test   eax,eax
  40e167:	sete   al
  40e16a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e170:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e176:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e17c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e182:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e188:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e18e:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e194:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e19a:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e1a3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e1ac:	add    rsp,0xa8
  40e1b3:	pop    rsi
  40e1b4:	pop    rdi
  40e1b5:	ret
	...

000000000040e1c0 <__swc_fn_65555ab2_000136_865f5106>:
  40e1c0:	push   rdi
  40e1c1:	push   rsi
  40e1c2:	sub    rsp,0xa8
  40e1c9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40e1cf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40e1d5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40e1db:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40e1e1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40e1e7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40e1ed:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40e1f3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40e1f9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40e202:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40e20b:	mov    rax,rdx
  40e20e:	mov    QWORD PTR [rsp],0x0
  40e216:	mov    edi,0xca
  40e21b:	mov    rsi,rcx
  40e21e:	mov    edx,0x81
  40e223:	mov    eax,eax
  40e225:	mov    ecx,eax
  40e227:	xor    r8d,r8d
  40e22a:	xor    r9d,r9d
  40e22d:	xor    eax,eax
  40e22f:	call   4071a0 <syscall@plt>
  40e234:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40e23a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40e240:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40e246:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40e24c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40e252:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40e258:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40e25e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40e264:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40e26d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40e276:	add    rsp,0xa8
  40e27d:	pop    rsi
  40e27e:	pop    rdi
  40e27f:	ret

000000000040e280 <__swc_fn_65555ab2_000139_86bb0f90>:
  40e280:	sub    rsp,0x8
  40e284:	call   411750 <__swc_fn_65555ab2_000137_8c07c14b>
  40e289:	add    rsp,0x8
  40e28d:	ret
	...

000000000040e290 <__swc_fn_65555ab2_000142_be4c2719>:
  40e290:	push   rdi
  40e291:	push   rsi
  40e292:	sub    rsp,0xc8
  40e299:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  40e29f:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  40e2a5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  40e2ab:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  40e2b1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  40e2b7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  40e2bd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  40e2c6:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  40e2cf:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  40e2d8:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  40e2e1:	vxorps xmm0,xmm0,xmm0
  40e2e5:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e2eb:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e2f1:	mov    rdi,rcx
  40e2f4:	lea    rsi,[rsp+0x8]
  40e2f9:	xor    eax,eax
  40e2fb:	call   4071b0 <dladdr@plt>
  40e300:	xor    ecx,ecx
  40e302:	test   eax,eax
  40e304:	je     40e30b <__swc_fn_65555ab2_000142_be4c2719+0x7b>
  40e306:	mov    rcx,QWORD PTR [rsp+0x10]
  40e30b:	mov    rax,rcx
  40e30e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  40e314:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40e31a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  40e320:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  40e326:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40e32c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  40e332:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40e33b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  40e344:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40e34d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  40e356:	add    rsp,0xc8
  40e35d:	pop    rsi
  40e35e:	pop    rdi
  40e35f:	ret

000000000040e360 <__swc_fn_65555ab2_000145_1534de9a>:
  40e360:	push   rbx
  40e361:	push   r12
  40e363:	push   r13
  40e365:	push   rdi
  40e366:	push   rsi
  40e367:	push   r14
  40e369:	push   r15
  40e36b:	sub    rsp,0x150
  40e372:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40e37b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40e384:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40e38d:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40e396:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40e39f:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40e3a8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40e3b1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40e3ba:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40e3c3:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40e3cc:	mov    rbx,rdx
  40e3cf:	mov    QWORD PTR [rsp+0x98],rdx
  40e3d7:	mov    r12,rcx
  40e3da:	mov    QWORD PTR [rsp+0xa0],rcx
  40e3e2:	mov    QWORD PTR [rbx],0x0
  40e3e9:	lea    r13,[rip+0x18988]        # 426d78 <__swc_bss_base_65555ab2+0x2d38>
  40e3f0:	mov    rcx,r13
  40e3f3:	call   40e280 <__swc_fn_65555ab2_000139_86bb0f90>
  40e3f8:	mov    rax,QWORD PTR [rip+0x18981]        # 426d80 <__swc_bss_base_65555ab2+0x2d40>
  40e3ff:	test   rax,rax
  40e402:	je     40e439 <__swc_fn_65555ab2_000145_1534de9a+0xd9>
  40e404:	cs nop WORD PTR [rax+rax*1+0x0]
  40e40e:	xchg   ax,ax
  40e410:	cmp    QWORD PTR [rax+0x8],r12
  40e414:	jne    40e431 <__swc_fn_65555ab2_000145_1534de9a+0xd1>
  40e416:	mov    rcx,QWORD PTR [rax+0x18]
  40e41a:	mov    QWORD PTR [rbx],rcx
  40e41d:	mov    rbx,QWORD PTR [rax+0x10]
  40e421:	mov    rcx,r13
  40e424:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40e429:	mov    rax,rbx
  40e42c:	jmp    40e61b <__swc_fn_65555ab2_000145_1534de9a+0x2bb>
  40e431:	mov    rax,QWORD PTR [rax]
  40e434:	test   rax,rax
  40e437:	jne    40e410 <__swc_fn_65555ab2_000145_1534de9a+0xb0>
  40e439:	vxorps xmm0,xmm0,xmm0
  40e43d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  40e443:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  40e449:	mov    rdi,r12
  40e44c:	lea    rsi,[rsp+0x10]
  40e451:	xor    eax,eax
  40e453:	call   4071b0 <dladdr@plt>
  40e458:	test   eax,eax
  40e45a:	sete   al
  40e45d:	je     40e46a <__swc_fn_65555ab2_000145_1534de9a+0x10a>
  40e45f:	mov    rax,QWORD PTR [rsp+0x10]
  40e464:	test   rax,rax
  40e467:	sete   al
  40e46a:	test   al,al
  40e46c:	je     40e47d <__swc_fn_65555ab2_000145_1534de9a+0x11d>
  40e46e:	mov    rcx,r13
  40e471:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40e476:	xor    eax,eax
  40e478:	jmp    40e61b <__swc_fn_65555ab2_000145_1534de9a+0x2bb>
  40e47d:	mov    rdi,QWORD PTR [rsp+0x10]
  40e482:	mov    esi,0x80000
  40e487:	xor    eax,eax
  40e489:	call   407010 <open@plt>
  40e48e:	lea    r14,[rsp+0x30]
  40e493:	mov    DWORD PTR [rsp+0x30],eax
  40e497:	cmp    DWORD PTR [r14],0x0
  40e49b:	jge    40e4ac <__swc_fn_65555ab2_000145_1534de9a+0x14c>
  40e49d:	mov    rcx,r13
  40e4a0:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40e4a5:	xor    eax,eax
  40e4a7:	jmp    40e61b <__swc_fn_65555ab2_000145_1534de9a+0x2bb>
  40e4ac:	mov    rax,r14
  40e4af:	movsxd rdi,DWORD PTR [rax]
  40e4b2:	xor    esi,esi
  40e4b4:	mov    edx,0x2
  40e4b9:	xor    eax,eax
  40e4bb:	call   4070c0 <lseek@plt>
  40e4c0:	mov    r15,rax
  40e4c3:	test   rax,rax
  40e4c6:	jg     40e4e1 <__swc_fn_65555ab2_000145_1534de9a+0x181>
  40e4c8:	movsxd rdi,DWORD PTR [r14]
  40e4cb:	xor    eax,eax
  40e4cd:	call   407040 <close@plt>
  40e4d2:	mov    rcx,r13
  40e4d5:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40e4da:	xor    eax,eax
  40e4dc:	jmp    40e61b <__swc_fn_65555ab2_000145_1534de9a+0x2bb>
  40e4e1:	xor    edi,edi
  40e4e3:	mov    rsi,r15
  40e4e6:	mov    edx,0x1
  40e4eb:	mov    ecx,0x2
  40e4f0:	mov    rax,r14
  40e4f3:	movsxd r8,DWORD PTR [rax]
  40e4f6:	xor    r9d,r9d
  40e4f9:	xor    eax,eax
  40e4fb:	call   4070d0 <mmap@plt>
  40e500:	mov    rbx,rax
  40e503:	test   rax,rax
  40e506:	sete   al
  40e509:	cmp    rbx,0xffffffffffffffff
  40e50d:	sete   cl
  40e510:	or     al,cl
  40e512:	je     40e52d <__swc_fn_65555ab2_000145_1534de9a+0x1cd>
  40e514:	movsxd rdi,DWORD PTR [r14]
  40e517:	xor    eax,eax
  40e519:	call   407040 <close@plt>
  40e51e:	mov    rcx,r13
  40e521:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40e526:	xor    eax,eax
  40e528:	jmp    40e61b <__swc_fn_65555ab2_000145_1534de9a+0x2bb>
  40e52d:	lea    rax,[rsp+0x50]
  40e532:	mov    QWORD PTR [rax],0x0
  40e539:	mov    rcx,rbx
  40e53c:	mov    rdx,r15
  40e53f:	mov    r8,rax
  40e542:	call   40a220 <__swc_fn_65555ab2_000144_d5d4d43f>
  40e547:	mov    r12,rax
  40e54a:	test   rax,rax
  40e54d:	jne    40e575 <__swc_fn_65555ab2_000145_1534de9a+0x215>
  40e54f:	mov    rdi,rbx
  40e552:	mov    rsi,r15
  40e555:	xor    eax,eax
  40e557:	call   407160 <munmap@plt>
  40e55c:	movsxd rdi,DWORD PTR [r14]
  40e55f:	xor    eax,eax
  40e561:	call   407040 <close@plt>
  40e566:	mov    rcx,r13
  40e569:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40e56e:	xor    eax,eax
  40e570:	jmp    40e61b <__swc_fn_65555ab2_000145_1534de9a+0x2bb>
  40e575:	mov    edi,0x20
  40e57a:	xor    eax,eax
  40e57c:	call   4071c0 <malloc@plt>
  40e581:	test   rax,rax
  40e584:	jne    40e5a9 <__swc_fn_65555ab2_000145_1534de9a+0x249>
  40e586:	mov    rdi,rbx
  40e589:	mov    rsi,r15
  40e58c:	xor    eax,eax
  40e58e:	call   407160 <munmap@plt>
  40e593:	movsxd rdi,DWORD PTR [r14]
  40e596:	xor    eax,eax
  40e598:	call   407040 <close@plt>
  40e59d:	mov    rcx,r13
  40e5a0:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40e5a5:	xor    eax,eax
  40e5a7:	jmp    40e61b <__swc_fn_65555ab2_000145_1534de9a+0x2bb>
  40e5a9:	mov    rcx,QWORD PTR [rip+0x187d0]        # 426d80 <__swc_bss_base_65555ab2+0x2d40>
  40e5b0:	mov    QWORD PTR [rsp+0x70],rcx
  40e5b5:	mov    rcx,QWORD PTR [rsp+0xa0]
  40e5bd:	mov    QWORD PTR [rsp+0x78],rcx
  40e5c2:	mov    QWORD PTR [rsp+0x80],r12
  40e5ca:	mov    rcx,QWORD PTR [rsp+0x50]
  40e5cf:	mov    QWORD PTR [rsp+0x88],rcx
  40e5d7:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  40e5dd:	vmovups XMMWORD PTR [rax],xmm0
  40e5e1:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  40e5ea:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e5ef:	mov    QWORD PTR [rip+0x1878a],rax        # 426d80 <__swc_bss_base_65555ab2+0x2d40>
  40e5f6:	mov    rax,QWORD PTR [rsp+0x50]
  40e5fb:	mov    rbx,QWORD PTR [rsp+0x98]
  40e603:	mov    QWORD PTR [rbx],rax
  40e606:	movsxd rdi,DWORD PTR [r14]
  40e609:	xor    eax,eax
  40e60b:	call   407040 <close@plt>
  40e610:	mov    rcx,r13
  40e613:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40e618:	mov    rax,r12
  40e61b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40e624:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40e62d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40e636:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40e63f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40e648:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40e651:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40e65a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40e663:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40e66c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40e675:	add    rsp,0x150
  40e67c:	pop    r15
  40e67e:	pop    r14
  40e680:	pop    rsi
  40e681:	pop    rdi
  40e682:	pop    r13
  40e684:	pop    r12
  40e686:	pop    rbx
  40e687:	ret
	...

000000000040e690 <__swc_fn_65555ab2_000148_43c96957>:
  40e690:	push   rbx
  40e691:	sub    rsp,0xe0
  40e698:	lea    rbx,[rsp+0x8]
  40e69d:	vxorps xmm0,xmm0,xmm0
  40e6a1:	vmovups YMMWORD PTR [rbx],ymm0
  40e6a5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40e6aa:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40e6af:	vzeroupper
  40e6b2:	mov    DWORD PTR [rbx+0x60],0x0
  40e6b9:	mov    r8,rbx
  40e6bc:	nop    DWORD PTR [rax+0x0]
  40e6c0:	mov    r9,rcx
  40e6c3:	movabs rcx,0xcccccccccccccccd
  40e6cd:	mov    rax,r9
  40e6d0:	mul    rcx
  40e6d3:	mov    r10,rdx
  40e6d6:	shr    r10,0x3
  40e6da:	mov    rcx,r10
  40e6dd:	imul   rdx,r10,0xa
  40e6e1:	sub    r9,rdx
  40e6e4:	mov    rdx,QWORD PTR [rip+0x5125]        # 413810 <__swc_rdata_base_65555ab2+0x700>
  40e6eb:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  40e6f0:	mov    BYTE PTR [r8],dl
  40e6f3:	lea    rdx,[r8+0x1]
  40e6f7:	mov    r8,rdx
  40e6fa:	test   r10,r10
  40e6fd:	jne    40e6c0 <__swc_fn_65555ab2_000148_43c96957+0x30>
  40e6ff:	mov    BYTE PTR [rdx],0x0
  40e702:	sub    r8,0x1
  40e706:	mov    rax,rbx
  40e709:	cmp    rax,r8
  40e70c:	jae    40e726 <__swc_fn_65555ab2_000148_43c96957+0x96>
  40e70e:	xchg   ax,ax
  40e710:	mov    cl,BYTE PTR [r8]
  40e713:	mov    dl,BYTE PTR [rax]
  40e715:	mov    BYTE PTR [r8],dl
  40e718:	sub    r8,0x1
  40e71c:	mov    BYTE PTR [rax],cl
  40e71e:	inc    rax
  40e721:	cmp    rax,r8
  40e724:	jb     40e710 <__swc_fn_65555ab2_000148_43c96957+0x80>
  40e726:	xor    eax,eax
  40e728:	test   rbx,rbx
  40e72b:	je     40e74e <__swc_fn_65555ab2_000148_43c96957+0xbe>
  40e72d:	mov    rcx,rbx
  40e730:	mov    dl,BYTE PTR [rcx]
  40e732:	test   dl,dl
  40e734:	je     40e74e <__swc_fn_65555ab2_000148_43c96957+0xbe>
  40e736:	cs nop WORD PTR [rax+rax*1+0x0]
  40e740:	add    rcx,0x1
  40e744:	add    rax,0x1
  40e748:	mov    dl,BYTE PTR [rcx]
  40e74a:	test   dl,dl
  40e74c:	jne    40e740 <__swc_fn_65555ab2_000148_43c96957+0xb0>
  40e74e:	mov    QWORD PTR [rbx+0xa8],rbx
  40e755:	mov    QWORD PTR [rbx+0xb0],rax
  40e75c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40e764:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40e76c:	lea    rcx,[rbx+0xb8]
  40e773:	call   409c90 <__swc_fn_65555ab2_000120_2648f149>
  40e778:	add    rsp,0xe0
  40e77f:	pop    rbx
  40e780:	ret
	...

000000000040e790 <__swc_fn_65555ab2_000151_6fb05988>:
  40e790:	sub    rsp,0x8
  40e794:	mov    rax,QWORD PTR [rcx+0x8]
  40e798:	mov    r8,QWORD PTR [rdx+0x8]
  40e79c:	cmp    rax,r8
  40e79f:	je     40e7a8 <__swc_fn_65555ab2_000151_6fb05988+0x18>
  40e7a1:	xor    eax,eax
  40e7a3:	add    rsp,0x8
  40e7a7:	ret
  40e7a8:	test   rax,rax
  40e7ab:	jne    40e7bc <__swc_fn_65555ab2_000151_6fb05988+0x2c>
  40e7ad:	test   r8,r8
  40e7b0:	jne    40e7bc <__swc_fn_65555ab2_000151_6fb05988+0x2c>
  40e7b2:	mov    eax,0x1
  40e7b7:	add    rsp,0x8
  40e7bb:	ret
  40e7bc:	mov    rcx,QWORD PTR [rcx]
  40e7bf:	mov    rdx,QWORD PTR [rdx]
  40e7c2:	test   rcx,rcx
  40e7c5:	sete   r8b
  40e7c9:	test   rdx,rdx
  40e7cc:	sete   r9b
  40e7d0:	or     r8b,r9b
  40e7d3:	je     40e7e0 <__swc_fn_65555ab2_000151_6fb05988+0x50>
  40e7d5:	cmp    rcx,rdx
  40e7d8:	sete   al
  40e7db:	add    rsp,0x8
  40e7df:	ret
  40e7e0:	cmp    rcx,rdx
  40e7e3:	jne    40e7ef <__swc_fn_65555ab2_000151_6fb05988+0x5f>
  40e7e5:	mov    eax,0x1
  40e7ea:	add    rsp,0x8
  40e7ee:	ret
  40e7ef:	mov    r8,rax
  40e7f2:	call   410e40 <__swc_fn_65555ab2_000110_3dc01326>
  40e7f7:	test   eax,eax
  40e7f9:	sete   al
  40e7fc:	add    rsp,0x8
  40e800:	ret
	...

000000000040e810 <__swc_fn_65555ab2_000154_86f1d437>:
  40e810:	vxorps xmm0,xmm0,xmm0
  40e814:	vmovups XMMWORD PTR [rcx],xmm0
  40e818:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e81d:	vxorps xmm0,xmm0,xmm0
  40e821:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e826:	vmovups xmm0,XMMWORD PTR [rip+0x509a]        # 4138c8 <__swc_rdata_base_65555ab2+0x7b8>
  40e82e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e833:	ret
	...

000000000040e840 <__swc_fn_65555ab2_000157_86f1d437>:
  40e840:	vxorps xmm0,xmm0,xmm0
  40e844:	vmovups XMMWORD PTR [rcx],xmm0
  40e848:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e84d:	vxorps xmm0,xmm0,xmm0
  40e851:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e856:	vmovups xmm0,XMMWORD PTR [rip+0x518a]        # 4139e8 <__swc_rdata_base_65555ab2+0x8d8>
  40e85e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e863:	mov    QWORD PTR [rcx+0x40],0x0
  40e86b:	ret
  40e86c:	add    BYTE PTR [rax],al
	...

000000000040e870 <__swc_fn_65555ab2_000160_47b270e1>:
  40e870:	push   rbx
  40e871:	sub    rsp,0x70
  40e875:	mov    rax,QWORD PTR [rcx]
  40e878:	mov    rbx,QWORD PTR [rcx+0x8]
  40e87c:	vxorps xmm0,xmm0,xmm0
  40e880:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40e886:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40e88c:	vzeroupper
  40e88f:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40e895:	mov    QWORD PTR [rsp+0x48],rdx
  40e89a:	mov    QWORD PTR [rsp+0x50],r8
  40e89f:	mov    rcx,rax
  40e8a2:	lea    rdx,[rsp+0x8]
  40e8a7:	mov    rbx,QWORD PTR [rbx+0x18]
  40e8ab:	call   rbx
  40e8ad:	add    rsp,0x70
  40e8b1:	pop    rbx
  40e8b2:	ret
	...

000000000040e8c0 <__swc_fn_65555ab2_000163_8a3d304f>:
  40e8c0:	push   rbx
  40e8c1:	push   rsi
  40e8c2:	push   rdi
  40e8c3:	mov    rbx,r8
  40e8c6:	mov    rsi,rcx
  40e8c9:	mov    rdi,rdx
  40e8cc:	call   411b50 <__swc_fn_65555ab2_000161_13ead2ff>
  40e8d1:	vmovups xmm0,XMMWORD PTR [rbx]
  40e8d5:	vmovups XMMWORD PTR [rsi],xmm0
  40e8d9:	mov    QWORD PTR [rsi+0x18],rdi
  40e8dd:	pop    rdi
  40e8de:	pop    rsi
  40e8df:	pop    rbx
  40e8e0:	ret
	...

000000000040e8f0 <__swc_fn_65555ab2_000166_cc119975>:
  40e8f0:	push   rbx
  40e8f1:	push   rsi
  40e8f2:	push   rdi
  40e8f3:	push   r12
  40e8f5:	push   r13
  40e8f7:	sub    rsp,0x50
  40e8fb:	mov    rbx,rcx
  40e8fe:	mov    rsi,rdx
  40e901:	vmovups xmm0,XMMWORD PTR [rip+0x51ef]        # 413af8 <__swc_rdata_base_65555ab2+0x9e8>
  40e909:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e90f:	vmovups xmm0,XMMWORD PTR [rip+0x51f1]        # 413b08 <__swc_rdata_base_65555ab2+0x9f8>
  40e917:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e91d:	vxorps xmm0,xmm0,xmm0
  40e921:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e927:	mov    rcx,rdx
  40e92a:	call   40e290 <__swc_fn_65555ab2_000142_be4c2719>
  40e92f:	mov    rdi,rax
  40e932:	test   rax,rax
  40e935:	jne    40e966 <__swc_fn_65555ab2_000166_cc119975+0x76>
  40e937:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e93d:	vmovups XMMWORD PTR [rbx],xmm0
  40e941:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e947:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e94c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e952:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e957:	mov    rax,rbx
  40e95a:	add    rsp,0x50
  40e95e:	pop    r13
  40e960:	pop    r12
  40e962:	pop    rdi
  40e963:	pop    rsi
  40e964:	pop    rbx
  40e965:	ret
  40e966:	mov    rcx,rdi
  40e969:	call   40b740 <__swc_fn_65555ab2_000165_016ee66a>
  40e96e:	mov    r11,rax
  40e971:	test   rax,rax
  40e974:	je     40e97e <__swc_fn_65555ab2_000166_cc119975+0x8e>
  40e976:	mov    al,BYTE PTR [r11+0x24]
  40e97a:	test   al,al
  40e97c:	jne    40e9ad <__swc_fn_65555ab2_000166_cc119975+0xbd>
  40e97e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e984:	vmovups XMMWORD PTR [rbx],xmm0
  40e988:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e98e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e993:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e999:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e99e:	mov    rax,rbx
  40e9a1:	add    rsp,0x50
  40e9a5:	pop    r13
  40e9a7:	pop    r12
  40e9a9:	pop    rdi
  40e9aa:	pop    rsi
  40e9ab:	pop    rbx
  40e9ac:	ret
  40e9ad:	sub    rsi,rdi
  40e9b0:	mov    eax,0xffffffff
  40e9b5:	cmp    rsi,rax
  40e9b8:	jbe    40e9e9 <__swc_fn_65555ab2_000166_cc119975+0xf9>
  40e9ba:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40e9c0:	vmovups XMMWORD PTR [rbx],xmm0
  40e9c4:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40e9ca:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40e9cf:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40e9d5:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40e9da:	mov    rax,rbx
  40e9dd:	add    rsp,0x50
  40e9e1:	pop    r13
  40e9e3:	pop    r12
  40e9e5:	pop    rdi
  40e9e6:	pop    rsi
  40e9e7:	pop    rbx
  40e9e8:	ret
  40e9e9:	mov    rdi,QWORD PTR [r11+0x10]
  40e9ed:	mov    eax,DWORD PTR [r11+0x20]
  40e9f1:	xor    ecx,ecx
  40e9f3:	test   rax,rax
  40e9f6:	jbe    40eb48 <__swc_fn_65555ab2_000166_cc119975+0x258>
  40e9fc:	nop    DWORD PTR [rax+0x0]
  40ea00:	mov    edx,ecx
  40ea02:	imul   r12,rdx,0x14
  40ea06:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40ea0b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40ea10:	mov    r9d,esi
  40ea13:	cmp    r9,rdx
  40ea16:	jb     40eb3b <__swc_fn_65555ab2_000166_cc119975+0x24b>
  40ea1c:	add    rdx,r8
  40ea1f:	mov    r8d,esi
  40ea22:	cmp    r8,rdx
  40ea25:	jae    40eb3b <__swc_fn_65555ab2_000166_cc119975+0x24b>
  40ea2b:	lea    rsi,[rsp+0x38]
  40ea30:	mov    eax,DWORD PTR [rdi+0xc]
  40ea33:	mov    DWORD PTR [rsp+0x38],eax
  40ea37:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40ea3c:	mov    rcx,rdi
  40ea3f:	mov    rdx,QWORD PTR [r11+0x18]
  40ea43:	mov    r8,rsi
  40ea46:	mov    r8d,DWORD PTR [r8]
  40ea49:	mov    r9,rax
  40ea4c:	lea    r10,[rsp+0x10]
  40ea51:	call   411ba0 <__swc_fn_65555ab2_000164_72795826>
  40ea56:	test   al,al
  40ea58:	jne    40ea8b <__swc_fn_65555ab2_000166_cc119975+0x19b>
  40ea5a:	vmovups xmm0,XMMWORD PTR [rip+0x50c6]        # 413b28 <__swc_rdata_base_65555ab2+0xa18>
  40ea62:	vmovups XMMWORD PTR [rbx],xmm0
  40ea66:	vmovups xmm0,XMMWORD PTR [rip+0x50ca]        # 413b38 <__swc_rdata_base_65555ab2+0xa28>
  40ea6e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ea73:	vxorps xmm0,xmm0,xmm0
  40ea77:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40ea7c:	mov    rax,rbx
  40ea7f:	add    rsp,0x50
  40ea83:	pop    r13
  40ea85:	pop    r12
  40ea87:	pop    rdi
  40ea88:	pop    rsi
  40ea89:	pop    rbx
  40ea8a:	ret
  40ea8b:	lea    r13,[rsp+0x3c]
  40ea90:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40ea95:	mov    DWORD PTR [rsp+0x3c],eax
  40ea99:	test   eax,eax
  40ea9b:	je     40eaec <__swc_fn_65555ab2_000166_cc119975+0x1fc>
  40ea9d:	mov    rcx,rdi
  40eaa0:	mov    rdx,QWORD PTR [r11+0x18]
  40eaa4:	mov    r8d,DWORD PTR [rsi]
  40eaa7:	mov    rax,r13
  40eaaa:	mov    r9d,DWORD PTR [rax]
  40eaad:	lea    r10,[rsp+0x20]
  40eab2:	call   411ba0 <__swc_fn_65555ab2_000164_72795826>
  40eab7:	test   al,al
  40eab9:	jne    40eaec <__swc_fn_65555ab2_000166_cc119975+0x1fc>
  40eabb:	vmovups xmm0,XMMWORD PTR [rip+0x5095]        # 413b58 <__swc_rdata_base_65555ab2+0xa48>
  40eac3:	vmovups XMMWORD PTR [rbx],xmm0
  40eac7:	vmovups xmm0,XMMWORD PTR [rip+0x5099]        # 413b68 <__swc_rdata_base_65555ab2+0xa58>
  40eacf:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40ead4:	vxorps xmm0,xmm0,xmm0
  40ead8:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40eadd:	mov    rax,rbx
  40eae0:	add    rsp,0x50
  40eae4:	pop    r13
  40eae6:	pop    r12
  40eae8:	pop    rdi
  40eae9:	pop    rsi
  40eaea:	pop    rbx
  40eaeb:	ret
  40eaec:	mov    eax,0x1
  40eaf1:	rex mov BYTE PTR [rsp+0x8],al
  40eaf6:	cmp    DWORD PTR [r13+0x0],0x0
  40eafb:	je     40eb0c <__swc_fn_65555ab2_000166_cc119975+0x21c>
  40eafd:	rex mov BYTE PTR [rsp+0x9],0x1
  40eb03:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40eb08:	mov    DWORD PTR [rsp+0x30],eax
  40eb0c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40eb12:	vmovups XMMWORD PTR [rbx],xmm0
  40eb16:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40eb1c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40eb21:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40eb27:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40eb2c:	mov    rax,rbx
  40eb2f:	add    rsp,0x50
  40eb33:	pop    r13
  40eb35:	pop    r12
  40eb37:	pop    rdi
  40eb38:	pop    rsi
  40eb39:	pop    rbx
  40eb3a:	ret
  40eb3b:	add    rcx,0x1
  40eb3f:	cmp    rcx,rax
  40eb42:	jb     40ea00 <__swc_fn_65555ab2_000166_cc119975+0x110>
  40eb48:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40eb4e:	vmovups XMMWORD PTR [rbx],xmm0
  40eb52:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40eb58:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40eb5d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40eb63:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40eb68:	mov    rax,rbx
  40eb6b:	add    rsp,0x50
  40eb6f:	pop    r13
  40eb71:	pop    r12
  40eb73:	pop    rdi
  40eb74:	pop    rsi
  40eb75:	pop    rbx
  40eb76:	ret
	...

000000000040eb80 <__swc_fn_65555ab2_000169_994c8876>:
  40eb80:	sub    rsp,0x48
  40eb84:	call   40df60 <__swc_fn_65555ab2_000127_58f0f391>
  40eb89:	cmp    rax,0xffffffffffffffff
  40eb8d:	je     40eb94 <__swc_fn_65555ab2_000169_994c8876+0x14>
  40eb8f:	add    rsp,0x48
  40eb93:	ret
  40eb94:	lea    rcx,[rip+0x4ffd]        # 413b98 <__swc_rdata_base_65555ab2+0xa88>
  40eb9b:	vmovups xmm0,XMMWORD PTR [rip+0x5005]        # 413ba8 <__swc_rdata_base_65555ab2+0xa98>
  40eba3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40eba9:	vmovups xmm0,XMMWORD PTR [rip+0x5007]        # 413bb8 <__swc_rdata_base_65555ab2+0xaa8>
  40ebb1:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40ebb7:	vmovups xmm0,XMMWORD PTR [rip+0x5009]        # 413bc8 <__swc_rdata_base_65555ab2+0xab8>
  40ebbf:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40ebc5:	lea    rdx,[rsp+0x8]
  40ebca:	mov    QWORD PTR [rsp+0x38],rax
  40ebcf:	call   410d80 <__swc_fn_65555ab2_000107_90faaa26>
  40ebd4:	mov    rax,QWORD PTR [rsp+0x38]
  40ebd9:	jmp    40eb8f <__swc_fn_65555ab2_000169_994c8876+0xf>
  40ebdb:	add    BYTE PTR [rax],al
  40ebdd:	add    BYTE PTR [rax],al
	...

000000000040ebe0 <__swc_fn_65555ab2_000172_cbeff767>:
  40ebe0:	push   rbx
  40ebe1:	push   rsi
  40ebe2:	sub    rsp,0x28
  40ebe6:	mov    rbx,rcx
  40ebe9:	mov    DWORD PTR [rsp+0x8],0xbf0
  40ebf1:	mov    ecx,0xbf0
  40ebf6:	call   410970 <__swc_fn_65555ab2_000083_4a10c7e7>
  40ebfb:	mov    rsi,rax
  40ebfe:	test   rax,rax
  40ec01:	jne    40ec0c <__swc_fn_65555ab2_000172_cbeff767+0x2c>
  40ec03:	xor    eax,eax
  40ec05:	add    rsp,0x28
  40ec09:	pop    rsi
  40ec0a:	pop    rbx
  40ec0b:	ret
  40ec0c:	vxorps xmm0,xmm0,xmm0
  40ec10:	xor    eax,eax
  40ec12:	cs nop WORD PTR [rax+rax*1+0x0]
  40ec1c:	nop    DWORD PTR [rax+0x0]
  40ec20:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40ec25:	add    rax,0x10
  40ec29:	cmp    rax,0xbf0
  40ec30:	jne    40ec20 <__swc_fn_65555ab2_000172_cbeff767+0x40>
  40ec32:	lea    rax,[rbx+0x1]
  40ec36:	mov    QWORD PTR [rsi+0x9c0],rax
  40ec3d:	mov    rcx,rbx
  40ec40:	mov    rdx,rsi
  40ec43:	call   411f00 <__swc_fn_65555ab2_000170_646fdf20>
  40ec48:	test   al,al
  40ec4a:	jne    40ec5d <__swc_fn_65555ab2_000172_cbeff767+0x7d>
  40ec4c:	mov    rcx,rsi
  40ec4f:	call   408c10 <__swc_fn_65555ab2_000084_cf82995a>
  40ec54:	xor    eax,eax
  40ec56:	add    rsp,0x28
  40ec5a:	pop    rsi
  40ec5b:	pop    rbx
  40ec5c:	ret
  40ec5d:	lea    rcx,[rsp+0x18]
  40ec62:	call   409190 <__swc_fn_65555ab2_000096_93bfe675>
  40ec67:	mov    rax,rsi
  40ec6a:	add    rsp,0x28
  40ec6e:	pop    rsi
  40ec6f:	pop    rbx
  40ec70:	ret
	...

000000000040ec80 <__swc_fn_65555ab2_000175_e09f8b62>:
  40ec80:	xor    eax,eax
  40ec82:	mov    edx,0x1
  40ec87:	lock cmpxchg QWORD PTR [rcx],rdx
  40ec8c:	test   rax,rax
  40ec8f:	jne    40ec92 <__swc_fn_65555ab2_000175_e09f8b62+0x12>
  40ec91:	ret
  40ec92:	cs nop WORD PTR [rax+rax*1+0x0]
  40ec9c:	nop    DWORD PTR [rax+0x0]
  40eca0:	mov    rax,QWORD PTR [rcx]
  40eca3:	test   rax,rax
  40eca6:	je     40ec80 <__swc_fn_65555ab2_000175_e09f8b62>
  40eca8:	jmp    40eca0 <__swc_fn_65555ab2_000175_e09f8b62+0x20>
  40ecaa:	add    BYTE PTR [rax],al
  40ecac:	add    BYTE PTR [rax],al
	...

000000000040ecb0 <__swc_fn_65555ab2_000178_718d7b54>:
  40ecb0:	push   rsi
  40ecb1:	push   rdi
  40ecb2:	sub    rsp,0x38
  40ecb6:	mov    rsi,rcx
  40ecb9:	call   411f10 <__swc_fn_65555ab2_000173_1e0ea8cf>
  40ecbe:	mov    rdi,rax
  40ecc1:	call   4116a0 <__swc_fn_65555ab2_000134_a9c1c700>
  40ecc6:	mov    r8,rax
  40ecc9:	mov    rcx,rdi
  40eccc:	call   40ec80 <__swc_fn_65555ab2_000175_e09f8b62>
  40ecd1:	mov    rax,QWORD PTR [rdi+0x8]
  40ecd5:	test   rax,rax
  40ecd8:	je     40ed15 <__swc_fn_65555ab2_000178_718d7b54+0x65>
  40ecda:	nop    WORD PTR [rax+rax*1+0x0]
  40ece0:	cmp    rax,rsi
  40ece3:	je     40ed15 <__swc_fn_65555ab2_000178_718d7b54+0x65>
  40ece5:	mov    r9,QWORD PTR [rax]
  40ece8:	cmp    QWORD PTR [rax+0x20],r8
  40ecec:	jne    40ed0d <__swc_fn_65555ab2_000178_718d7b54+0x5d>
  40ecee:	mov    rcx,rdi
  40ecf1:	mov    rdx,rax
  40ecf4:	mov    QWORD PTR [rsp+0x28],r8
  40ecf9:	mov    QWORD PTR [rsp+0x30],r9
  40ecfe:	call   40bb60 <__swc_fn_65555ab2_000177_cf4ffedd>
  40ed03:	mov    r8,QWORD PTR [rsp+0x28]
  40ed08:	mov    r9,QWORD PTR [rsp+0x30]
  40ed0d:	mov    rax,r9
  40ed10:	test   r9,r9
  40ed13:	jne    40ece0 <__swc_fn_65555ab2_000178_718d7b54+0x30>
  40ed15:	xor    eax,eax
  40ed17:	mov    QWORD PTR [rdi],rax
  40ed1a:	add    rsp,0x38
  40ed1e:	pop    rdi
  40ed1f:	pop    rsi
  40ed20:	ret
	...

000000000040ed40 <__swc_fn_65555ab2_000002_1ca87929>:
  40ed40:	push   rdi
  40ed41:	push   rsi
  40ed42:	sub    rsp,0xb8
  40ed49:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40ed4f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40ed55:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40ed5b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40ed61:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40ed67:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40ed6d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40ed73:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40ed7c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40ed85:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40ed8e:	vxorps xmm0,xmm0,xmm0
  40ed92:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ed98:	mov    edi,0x1
  40ed9d:	lea    rsi,[rsp+0x8]
  40eda2:	xor    eax,eax
  40eda4:	call   407130 <clock_gettime@plt>
  40eda9:	vxorpd xmm0,xmm0,xmm0
  40edad:	mov    rax,QWORD PTR [rsp+0x8]
  40edb2:	vcvtsi2sd xmm0,xmm0,rax
  40edb7:	vxorpd xmm1,xmm1,xmm1
  40edbb:	mov    rax,QWORD PTR [rsp+0x10]
  40edc0:	vcvtsi2sd xmm1,xmm1,rax
  40edc5:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x4343]        # 413110 <__swc_rdata_base_65555ab2>
  40edcd:	vaddsd xmm0,xmm0,xmm1
  40edd1:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40edd7:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40eddd:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40ede3:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ede9:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40edef:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40edf5:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40edfb:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ee04:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ee0d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ee16:	add    rsp,0xb8
  40ee1d:	pop    rsi
  40ee1e:	pop    rdi
  40ee1f:	ret

000000000040ee20 <__swc_fn_65555ab2_000005_9ee35b18>:
  40ee20:	vxorps xmm0,xmm0,xmm0
  40ee24:	xor    eax,eax
  40ee26:	cs nop WORD PTR [rax+rax*1+0x0]
  40ee30:	cs nop WORD PTR [rax+rax*1+0x0]
  40ee3a:	nop    WORD PTR [rax+rax*1+0x0]
  40ee40:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40ee45:	add    rax,0x10
  40ee49:	cmp    rax,0x2080
  40ee50:	jne    40ee40 <__swc_fn_65555ab2_000005_9ee35b18+0x20>
  40ee52:	ret
	...

000000000040ee60 <__swc_fn_65555ab2_000008_d64b2baa>:
  40ee60:	push   rsi
  40ee61:	push   rdi
  40ee62:	push   r12
  40ee64:	push   r13
  40ee66:	push   r14
  40ee68:	mov    rsi,rcx
  40ee6b:	mov    edi,r10d
  40ee6e:	mov    r12,rcx
  40ee71:	mov    r13,r9
  40ee74:	mov    ecx,DWORD PTR [rdx+0x28]
  40ee77:	shlx   r14d,r8d,ecx
  40ee7c:	mov    rcx,rdx
  40ee7f:	mov    edx,r8d
  40ee82:	call   407ad0 <__swc_fn_65555ab2_000015_9dea5065>
  40ee87:	mov    rcx,rax
  40ee8a:	mov    eax,DWORD PTR [r12+0x3c]
  40ee8f:	xor    edx,edx
  40ee91:	div    rdi
  40ee94:	vxorps xmm0,xmm0,xmm0
  40ee98:	vmovdqu XMMWORD PTR [rsi],xmm0
  40ee9c:	mov    QWORD PTR [r12+0x60],0x0
  40eea5:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40eeaa:	mov    QWORD PTR [r12+0x10],rcx
  40eeaf:	imul   rax,rdi
  40eeb3:	lea    rdx,[rcx+rax*1]
  40eeb7:	mov    QWORD PTR [r12+0x18],rdx
  40eebc:	mov    QWORD PTR [r12+0x20],rcx
  40eec1:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40eec6:	mov    DWORD PTR [r12+0x28],0x0
  40eecf:	mov    DWORD PTR [r12+0x68],0x0
  40eed8:	mov    BYTE PTR [r12+0x39],r13b
  40eedd:	mov    BYTE PTR [r12+0x3a],r14b
  40eee2:	mov    BYTE PTR [r12+0x3b],0x1
  40eee8:	mov    DWORD PTR [r12+0x6c],0x0
  40eef1:	mov    rcx,r12
  40eef4:	mov    edx,edi
  40eef6:	call   407a30 <__swc_fn_65555ab2_000009_065ed5b1>
  40eefb:	pop    r14
  40eefd:	pop    r13
  40eeff:	pop    r12
  40ef01:	pop    rdi
  40ef02:	pop    rsi
  40ef03:	ret
	...

000000000040ef10 <__swc_fn_65555ab2_000011_c3647f66>:
  40ef10:	mov    r8d,0x1
  40ef16:	xor    eax,eax
  40ef18:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40ef1e:	test   eax,eax
  40ef20:	jne    40ef10 <__swc_fn_65555ab2_000011_c3647f66>
  40ef22:	ret
	...

000000000040ef30 <__swc_fn_65555ab2_000014_524c1f23>:
  40ef30:	lea    r8,[rcx+0x60]
  40ef34:	mov    rax,QWORD PTR [r8]
  40ef37:	mov    r9,rax
  40ef3a:	nop    WORD PTR [rax+rax*1+0x0]
  40ef40:	mov    QWORD PTR [rdx],r9
  40ef43:	mov    rax,r9
  40ef46:	lock cmpxchg QWORD PTR [r8],rdx
  40ef4b:	cmp    rax,r9
  40ef4e:	jne    40efb7 <__swc_fn_65555ab2_000014_524c1f23+0x87>
  40ef50:	mov    eax,DWORD PTR [rcx+0x6c]
  40ef53:	test   eax,eax
  40ef55:	je     40efb6 <__swc_fn_65555ab2_000014_524c1f23+0x86>
  40ef57:	lea    rdx,[rcx+0x70]
  40ef5b:	mov    r9d,0x1
  40ef61:	xor    eax,eax
  40ef63:	lock cmpxchg DWORD PTR [rdx],r9d
  40ef68:	test   eax,eax
  40ef6a:	jne    40efb6 <__swc_fn_65555ab2_000014_524c1f23+0x86>
  40ef6c:	mov    rax,rcx
  40ef6f:	and    rax,0xffffffffffc00000
  40ef76:	mov    rax,QWORD PTR [rax+0x8]
  40ef7a:	test   rax,rax
  40ef7d:	jne    40ef85 <__swc_fn_65555ab2_000014_524c1f23+0x55>
  40ef7f:	xor    eax,eax
  40ef81:	xchg   DWORD PTR [rdx],eax
  40ef83:	jmp    40efb6 <__swc_fn_65555ab2_000014_524c1f23+0x86>
  40ef85:	lea    rdx,[rax+0x2a80]
  40ef8c:	mov    rax,QWORD PTR [rdx]
  40ef8f:	mov    r8,rax
  40ef92:	cs nop WORD PTR [rax+rax*1+0x0]
  40ef9c:	nop    DWORD PTR [rax+0x0]
  40efa0:	mov    QWORD PTR [rcx+0x78],r8
  40efa4:	mov    rax,r8
  40efa7:	lock cmpxchg QWORD PTR [rdx],rcx
  40efac:	cmp    rax,r8
  40efaf:	je     40efb6 <__swc_fn_65555ab2_000014_524c1f23+0x86>
  40efb1:	mov    r8,rax
  40efb4:	jmp    40efa0 <__swc_fn_65555ab2_000014_524c1f23+0x70>
  40efb6:	ret
  40efb7:	mov    r9,rax
  40efba:	jmp    40ef40 <__swc_fn_65555ab2_000014_524c1f23+0x10>
	...

000000000040efc0 <__swc_fn_65555ab2_000017_efc44797>:
  40efc0:	push   rsi
  40efc1:	push   rdi
  40efc2:	push   r12
  40efc4:	push   r13
  40efc6:	push   r14
  40efc8:	push   r15
  40efca:	push   rbx
  40efcb:	sub    rsp,0x30
  40efcf:	mov    QWORD PTR [rsp+0x18],r8
  40efd4:	mov    rsi,rcx
  40efd7:	mov    rdi,rdx
  40efda:	mov    rdx,QWORD PTR [rsi+0x40]
  40efde:	xchg   ax,ax
  40efe0:	mov    rax,rdx
  40efe3:	not    rax
  40efe6:	and    rax,QWORD PTR [rsi+0x20]
  40efea:	test   rax,rax
  40efed:	jne    40f001 <__swc_fn_65555ab2_000017_efc44797+0x41>
  40efef:	xor    eax,eax
  40eff1:	add    rsp,0x30
  40eff5:	pop    rbx
  40eff6:	pop    r15
  40eff8:	pop    r14
  40effa:	pop    r13
  40effc:	pop    r12
  40effe:	pop    rdi
  40efff:	pop    rsi
  40f000:	ret
  40f001:	xor    ecx,ecx
  40f003:	tzcnt  rcx,rax
  40f008:	lea    r12,[rsp+0x8]
  40f00d:	mov    DWORD PTR [rsp+0x8],ecx
  40f011:	mov    r13d,0x1
  40f017:	shl    r13,cl
  40f01a:	mov    rcx,rdx
  40f01d:	or     rcx,r13
  40f020:	mov    rax,rdx
  40f023:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40f029:	cmp    rax,rdx
  40f02c:	je     40f033 <__swc_fn_65555ab2_000017_efc44797+0x73>
  40f02e:	mov    rdx,rax
  40f031:	jmp    40efe0 <__swc_fn_65555ab2_000017_efc44797+0x20>
  40f033:	mov    eax,DWORD PTR [r12]
  40f037:	shl    rax,0x4
  40f03b:	lea    r14,[rsi+rax*8+0x80]
  40f043:	mov    rcx,rsi
  40f046:	mov    rax,r12
  40f049:	mov    edx,DWORD PTR [rax]
  40f04b:	call   407ad0 <__swc_fn_65555ab2_000015_9dea5065>
  40f050:	mov    r15,rax
  40f053:	mov    rcx,rsi
  40f056:	mov    rdx,r13
  40f059:	call   407c30 <__swc_fn_65555ab2_000021_fd2b165c>
  40f05e:	test   al,al
  40f060:	je     40f098 <__swc_fn_65555ab2_000017_efc44797+0xd8>
  40f062:	mov    ecx,DWORD PTR [r14+0x3c]
  40f066:	lea    rdx,[rip+0x14ff3]        # 424060 <__swc_bss_base_65555ab2+0x20>
  40f06d:	mov    r8,QWORD PTR [rip+0x14fec]        # 424060 <__swc_bss_base_65555ab2+0x20>
  40f074:	cs nop WORD PTR [rax+rax*1+0x0]
  40f07e:	xchg   ax,ax
  40f080:	mov    r9,r8
  40f083:	sub    r9,rcx
  40f086:	mov    rax,r8
  40f089:	lock cmpxchg QWORD PTR [rdx],r9
  40f08e:	cmp    rax,r8
  40f091:	je     40f0f9 <__swc_fn_65555ab2_000017_efc44797+0x139>
  40f093:	mov    r8,rax
  40f096:	jmp    40f080 <__swc_fn_65555ab2_000017_efc44797+0xc0>
  40f098:	mov    rcx,rsi
  40f09b:	mov    rax,r12
  40f09e:	mov    edx,DWORD PTR [rax]
  40f0a0:	call   40be40 <__swc_fn_65555ab2_000016_9afb7cfb>
  40f0a5:	mov    rcx,r15
  40f0a8:	and    rcx,0xffffffffffff0000
  40f0af:	lea    rcx,[rcx+0x10000]
  40f0b6:	mov    rbx,rax
  40f0b9:	cmp    rax,rcx
  40f0bc:	cmova  rbx,rcx
  40f0c0:	mov    rax,rbx
  40f0c3:	sub    rax,r15
  40f0c6:	mov    rcx,r15
  40f0c9:	mov    rdx,rax
  40f0cc:	call   40bc90 <__swc_fn_65555ab2_000007_f7acedb0>
  40f0d1:	test   al,al
  40f0d3:	jne    40f0f2 <__swc_fn_65555ab2_000017_efc44797+0x132>
  40f0d5:	mov    rcx,rsi
  40f0d8:	mov    rdx,r13
  40f0db:	call   40bff0 <__swc_fn_65555ab2_000022_c8f5f27c>
  40f0e0:	xor    eax,eax
  40f0e2:	add    rsp,0x30
  40f0e6:	pop    rbx
  40f0e7:	pop    r15
  40f0e9:	pop    r14
  40f0eb:	pop    r13
  40f0ed:	pop    r12
  40f0ef:	pop    rdi
  40f0f0:	pop    rsi
  40f0f1:	ret
  40f0f2:	sub    rbx,r15
  40f0f5:	mov    DWORD PTR [r14+0x3c],ebx
  40f0f9:	mov    rcx,r14
  40f0fc:	mov    rdx,rsi
  40f0ff:	mov    r8d,DWORD PTR [r12]
  40f103:	mov    r9d,edi
  40f106:	mov    rbx,QWORD PTR [rsp+0x18]
  40f10b:	mov    r10d,ebx
  40f10e:	call   40ee60 <__swc_fn_65555ab2_000008_d64b2baa>
  40f113:	mov    rax,r14
  40f116:	add    rsp,0x30
  40f11a:	pop    rbx
  40f11b:	pop    r15
  40f11d:	pop    r14
  40f11f:	pop    r13
  40f121:	pop    r12
  40f123:	pop    rdi
  40f124:	pop    rsi
  40f125:	ret
	...

000000000040f130 <__swc_fn_65555ab2_000020_de02dbdf>:
  40f130:	mov    r8,QWORD PTR [rcx+0x48]
  40f134:	cs nop WORD PTR [rax+rax*1+0x0]
  40f13e:	xchg   ax,ax
  40f140:	mov    r9,r8
  40f143:	or     r9,rdx
  40f146:	mov    rax,r8
  40f149:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40f14f:	cmp    rax,r8
  40f152:	jne    40f155 <__swc_fn_65555ab2_000020_de02dbdf+0x25>
  40f154:	ret
  40f155:	mov    r8,rax
  40f158:	jmp    40f140 <__swc_fn_65555ab2_000020_de02dbdf+0x10>
  40f15a:	add    BYTE PTR [rax],al
  40f15c:	add    BYTE PTR [rax],al
	...

000000000040f160 <__swc_fn_65555ab2_000023_2d0fcd2c>:
  40f160:	push   rsi
  40f161:	push   rdi
  40f162:	push   r12
  40f164:	mov    rsi,rcx
  40f167:	xor    edi,edi
  40f169:	lea    r12,[rip+0x14f00]        # 424070 <__swc_bss_base_65555ab2+0x30>
  40f170:	mov    eax,DWORD PTR [r12]
  40f174:	xor    ecx,ecx
  40f176:	test   rax,rax
  40f179:	jbe    40f1b4 <__swc_fn_65555ab2_000023_2d0fcd2c+0x54>
  40f17b:	nop    DWORD PTR [rax+rax*1+0x0]
  40f180:	lea    rdx,[rip+0x14ef1]        # 424078 <__swc_bss_base_65555ab2+0x38>
  40f187:	mov    r8d,ecx
  40f18a:	lea    r8,[r8+r8*2]
  40f18e:	lea    r8,[rdx+r8*8]
  40f192:	mov    rdx,QWORD PTR [r8+0x10]
  40f196:	add    rdx,0x400000
  40f19d:	cmp    rdx,0x40000000
  40f1a4:	ja     40f1ab <__swc_fn_65555ab2_000023_2d0fcd2c+0x4b>
  40f1a6:	mov    rdi,r8
  40f1a9:	jmp    40f1b4 <__swc_fn_65555ab2_000023_2d0fcd2c+0x54>
  40f1ab:	add    rcx,0x1
  40f1af:	cmp    rcx,rax
  40f1b2:	jb     40f180 <__swc_fn_65555ab2_000023_2d0fcd2c+0x20>
  40f1b4:	test   rdi,rdi
  40f1b7:	jne    40f243 <__swc_fn_65555ab2_000023_2d0fcd2c+0xe3>
  40f1bd:	cmp    DWORD PTR [r12],0x10
  40f1c2:	jae    40f22b <__swc_fn_65555ab2_000023_2d0fcd2c+0xcb>
  40f1c4:	mov    ecx,0x40400000
  40f1c9:	call   4079f0 <__swc_fn_65555ab2_000006_81d2e1e9>
  40f1ce:	test   rax,rax
  40f1d1:	je     40f22b <__swc_fn_65555ab2_000023_2d0fcd2c+0xcb>
  40f1d3:	lea    rcx,[rip+0x14e9e]        # 424078 <__swc_bss_base_65555ab2+0x38>
  40f1da:	mov    edx,DWORD PTR [r12]
  40f1de:	lea    rdx,[rdx+rdx*2]
  40f1e2:	lea    rdx,[rcx+rdx*8]
  40f1e6:	mov    QWORD PTR [rdx],rax
  40f1e9:	lea    rax,[rax+0x3fffff]
  40f1f0:	and    rax,0xffffffffffc00000
  40f1f7:	mov    QWORD PTR [rdx+0x8],rax
  40f1fb:	mov    QWORD PTR [rdx+0x10],0x0
  40f203:	mov    edx,DWORD PTR [rip+0x14e67]        # 424070 <__swc_bss_base_65555ab2+0x30>
  40f209:	nop    DWORD PTR [rax+0x0]
  40f210:	lea    r9d,[rdx+0x1]
  40f214:	mov    rax,rdx
  40f217:	lock cmpxchg DWORD PTR [r12],r9d
  40f21d:	mov    r8d,eax
  40f220:	cmp    eax,edx
  40f222:	je     40f232 <__swc_fn_65555ab2_000023_2d0fcd2c+0xd2>
  40f224:	mov    rdx,r8
  40f227:	jmp    40f210 <__swc_fn_65555ab2_000023_2d0fcd2c+0xb0>
  40f229:	jmp    40f232 <__swc_fn_65555ab2_000023_2d0fcd2c+0xd2>
  40f22b:	xor    eax,eax
  40f22d:	pop    r12
  40f22f:	pop    rdi
  40f230:	pop    rsi
  40f231:	ret
  40f232:	mov    eax,DWORD PTR [rip+0x14e38]        # 424070 <__swc_bss_base_65555ab2+0x30>
  40f238:	sub    eax,0x1
  40f23b:	lea    rdi,[rax+rax*2]
  40f23f:	lea    rdi,[rcx+rdi*8]
  40f243:	mov    r12,QWORD PTR [rdi+0x8]
  40f247:	add    r12,QWORD PTR [rdi+0x10]
  40f24b:	mov    rcx,r12
  40f24e:	mov    edx,0x3000
  40f253:	call   40bc90 <__swc_fn_65555ab2_000007_f7acedb0>
  40f258:	test   al,al
  40f25a:	jne    40f263 <__swc_fn_65555ab2_000023_2d0fcd2c+0x103>
  40f25c:	xor    eax,eax
  40f25e:	pop    r12
  40f260:	pop    rdi
  40f261:	pop    rsi
  40f262:	ret
  40f263:	vxorps xmm0,xmm0,xmm0
  40f267:	xor    eax,eax
  40f269:	cs nop WORD PTR [rax+rax*1+0x0]
  40f273:	cs nop WORD PTR [rax+rax*1+0x0]
  40f27d:	nop    DWORD PTR [rax]
  40f280:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40f286:	add    rax,0x10
  40f28a:	cmp    rax,0x3000
  40f291:	jne    40f280 <__swc_fn_65555ab2_000023_2d0fcd2c+0x120>
  40f293:	mov    DWORD PTR [r12+0x28],esi
  40f298:	mov    eax,0x40
  40f29d:	mov    ecx,esi
  40f29f:	shr    eax,cl
  40f2a1:	mov    DWORD PTR [r12+0x2c],eax
  40f2a6:	cmp    DWORD PTR [r12+0x2c],0x40
  40f2ac:	jb     40f2b7 <__swc_fn_65555ab2_000023_2d0fcd2c+0x157>
  40f2ae:	mov    rax,0xffffffffffffffff
  40f2b5:	jmp    40f2c7 <__swc_fn_65555ab2_000023_2d0fcd2c+0x167>
  40f2b7:	mov    eax,0x1
  40f2bc:	mov    ecx,DWORD PTR [r12+0x2c]
  40f2c1:	shl    rax,cl
  40f2c4:	dec    rax
  40f2c7:	mov    QWORD PTR [r12+0x20],rax
  40f2cc:	mov    DWORD PTR [r12],0x4e540001
  40f2d4:	mov    DWORD PTR [r12+0x4],0x53474d45
  40f2dd:	add    QWORD PTR [rdi+0x10],0x400000
  40f2e5:	mov    rax,r12
  40f2e8:	pop    r12
  40f2ea:	pop    rdi
  40f2eb:	pop    rsi
  40f2ec:	ret
  40f2ed:	add    BYTE PTR [rax],al
	...

000000000040f2f0 <__swc_fn_65555ab2_000026_bcdc5519>:
  40f2f0:	mov    eax,0x1
  40f2f5:	mov    edx,DWORD PTR [rip+0x14d75]        # 424070 <__swc_bss_base_65555ab2+0x30>
  40f2fb:	cmp    eax,edx
  40f2fd:	jae    40f34b <__swc_fn_65555ab2_000026_bcdc5519+0x5b>
  40f2ff:	nop
  40f300:	lea    r8,[rip+0x14d71]        # 424078 <__swc_bss_base_65555ab2+0x38>
  40f307:	lea    r9,[rax+rax*2]
  40f30b:	lea    r9,[r8+r9*8]
  40f30f:	mov    r8,rcx
  40f312:	sub    r8,QWORD PTR [r9+0x8]
  40f316:	mov    r9,QWORD PTR [r9+0x10]
  40f31a:	cmp    r8,r9
  40f31d:	jae    40f345 <__swc_fn_65555ab2_000026_bcdc5519+0x55>
  40f31f:	mov    rax,rcx
  40f322:	and    rax,0xffffffffffc00000
  40f329:	shr    rcx,0x10
  40f32d:	and    ecx,0x3f
  40f330:	mov    edx,DWORD PTR [rax+0x28]
  40f333:	shrx   ecx,ecx,edx
  40f338:	shl    rcx,0x4
  40f33c:	lea    rax,[rax+rcx*8+0x80]
  40f344:	ret
  40f345:	inc    eax
  40f347:	cmp    eax,edx
  40f349:	jb     40f300 <__swc_fn_65555ab2_000026_bcdc5519+0x10>
  40f34b:	xor    eax,eax
  40f34d:	ret
	...

000000000040f350 <__swc_fn_65555ab2_000029_9798fb47>:
  40f350:	vxorps xmm0,xmm0,xmm0
  40f354:	vmovups XMMWORD PTR [rcx],xmm0
  40f358:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40f35d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40f362:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40f367:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40f36c:	mov    QWORD PTR [rcx+0x50],0x0
  40f374:	ret
	...

000000000040f380 <__swc_fn_65555ab2_000032_9798fb47>:
  40f380:	vxorps xmm0,xmm0,xmm0
  40f384:	xor    eax,eax
  40f386:	cs nop WORD PTR [rax+rax*1+0x0]
  40f390:	cs nop WORD PTR [rax+rax*1+0x0]
  40f39a:	nop    WORD PTR [rax+rax*1+0x0]
  40f3a0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40f3a5:	add    rax,0x10
  40f3a9:	cmp    rax,0x9b0
  40f3b0:	jne    40f3a0 <__swc_fn_65555ab2_000032_9798fb47+0x20>
  40f3b2:	mov    QWORD PTR [rcx+0x9b0],0x0
  40f3bd:	ret
	...

000000000040f3c0 <__swc_fn_65555ab2_000035_cd1a4e8c>:
  40f3c0:	push   rsi
  40f3c1:	push   rdi
  40f3c2:	sub    rsp,0x8
  40f3c6:	lea    rsi,[rip+0x12c43]        # 422010 <__swc_data_base_65555ab2+0x10>
  40f3cd:	mov    rax,QWORD PTR [rsi]
  40f3d0:	mov    ecx,0xffffffff
  40f3d5:	cmp    rax,rcx
  40f3d8:	je     40f3e1 <__swc_fn_65555ab2_000035_cd1a4e8c+0x21>
  40f3da:	add    rsp,0x8
  40f3de:	pop    rdi
  40f3df:	pop    rsi
  40f3e0:	ret
  40f3e1:	mov    rcx,QWORD PTR [rip+0x3d08]        # 4130f0 <__swc_fn_65555ab2_000176_4de704de+0x1190>
  40f3e8:	call   40e030 <__swc_fn_65555ab2_000130_4a82cdf6>
  40f3ed:	mov    rcx,rax
  40f3f0:	mov    eax,0xffffffff
  40f3f5:	lock cmpxchg QWORD PTR [rsi],rcx
  40f3fa:	mov    rdi,rax
  40f3fd:	mov    eax,0xffffffff
  40f402:	cmp    rdi,rax
  40f405:	je     40f416 <__swc_fn_65555ab2_000035_cd1a4e8c+0x56>
  40f407:	call   4115f0 <__swc_fn_65555ab2_000131_a611b8c4>
  40f40c:	mov    rax,rdi
  40f40f:	add    rsp,0x8
  40f413:	pop    rdi
  40f414:	pop    rsi
  40f415:	ret
  40f416:	mov    rax,rcx
  40f419:	add    rsp,0x8
  40f41d:	pop    rdi
  40f41e:	pop    rsi
  40f41f:	ret

000000000040f420 <__swc_fn_65555ab2_000038_14f56618>:
  40f420:	sub    rsp,0x8
  40f424:	vxorps xmm0,xmm0,xmm0
  40f428:	xor    eax,eax
  40f42a:	cs nop WORD PTR [rax+rax*1+0x0]
  40f434:	cs nop WORD PTR [rax+rax*1+0x0]
  40f43e:	xchg   ax,ax
  40f440:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40f445:	add    rax,0x10
  40f449:	cmp    rax,0x2b00
  40f450:	jne    40f440 <__swc_fn_65555ab2_000038_14f56618+0x20>
  40f452:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40f45c:	xor    al,al
  40f45e:	mov    rdx,rax
  40f461:	xor    al,al
  40f463:	mov    r8,rax
  40f466:	xor    al,al
  40f468:	mov    r9,rax
  40f46b:	xor    al,al
  40f46d:	mov    r10,rax
  40f470:	xor    al,al
  40f472:	mov    r11,rax
  40f475:	call   407e70 <__swc_fn_65555ab2_000039_03f1bf9a>
  40f47a:	add    rsp,0x8
  40f47e:	ret
	...

000000000040f480 <__swc_fn_65555ab2_000041_c90d80c1>:
  40f480:	push   rsi
  40f481:	push   rdi
  40f482:	push   r12
  40f484:	mov    rsi,r8
  40f487:	mov    rdi,rdx
  40f48a:	mov    rcx,rdx
  40f48d:	call   4079f0 <__swc_fn_65555ab2_000006_81d2e1e9>
  40f492:	mov    r12,rax
  40f495:	test   rax,rax
  40f498:	jne    40f4a1 <__swc_fn_65555ab2_000041_c90d80c1+0x21>
  40f49a:	xor    eax,eax
  40f49c:	pop    r12
  40f49e:	pop    rdi
  40f49f:	pop    rsi
  40f4a0:	ret
  40f4a1:	mov    rcx,r12
  40f4a4:	mov    rdx,rsi
  40f4a7:	call   40bc90 <__swc_fn_65555ab2_000007_f7acedb0>
  40f4ac:	test   al,al
  40f4ae:	jne    40f4c2 <__swc_fn_65555ab2_000041_c90d80c1+0x42>
  40f4b0:	mov    rcx,r12
  40f4b3:	mov    rdx,rdi
  40f4b6:	call   409c70 <__swc_fn_65555ab2_000117_ed2d8fed>
  40f4bb:	xor    eax,eax
  40f4bd:	pop    r12
  40f4bf:	pop    rdi
  40f4c0:	pop    rsi
  40f4c1:	ret
  40f4c2:	mov    rax,r12
  40f4c5:	pop    r12
  40f4c7:	pop    rdi
  40f4c8:	pop    rsi
  40f4c9:	ret
	...

000000000040f4e0 <__swc_fn_65555ab2_000044_a78ae66b>:
  40f4e0:	push   rsi
  40f4e1:	push   rdi
  40f4e2:	push   r12
  40f4e4:	mov    rsi,rcx
  40f4e7:	mov    edx,0x9b8
  40f4ec:	call   407ee0 <__swc_fn_65555ab2_000042_facd3e17>
  40f4f1:	mov    rdi,rax
  40f4f4:	test   rax,rax
  40f4f7:	jne    40f500 <__swc_fn_65555ab2_000044_a78ae66b+0x20>
  40f4f9:	xor    eax,eax
  40f4fb:	pop    r12
  40f4fd:	pop    rdi
  40f4fe:	pop    rsi
  40f4ff:	ret
  40f500:	vxorps xmm0,xmm0,xmm0
  40f504:	xor    eax,eax
  40f506:	cs nop WORD PTR [rax+rax*1+0x0]
  40f510:	cs nop WORD PTR [rax+rax*1+0x0]
  40f51a:	nop    WORD PTR [rax+rax*1+0x0]
  40f520:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40f525:	add    rax,0x10
  40f529:	cmp    rax,0x9b0
  40f530:	jne    40f520 <__swc_fn_65555ab2_000044_a78ae66b+0x40>
  40f532:	mov    QWORD PTR [rdi+0x9b0],0x0
  40f53d:	mov    QWORD PTR [rdi],rsi
  40f540:	call   4116a0 <__swc_fn_65555ab2_000134_a9c1c700>
  40f545:	mov    QWORD PTR [rdi+0x18],rax
  40f549:	lea    r12,[rsi+0x10]
  40f54d:	mov    rcx,r12
  40f550:	call   40e280 <__swc_fn_65555ab2_000139_86bb0f90>
  40f555:	mov    rax,QWORD PTR [rsi+0x20]
  40f559:	mov    QWORD PTR [rdi+0x8],rax
  40f55d:	mov    rax,QWORD PTR [rsi+0x20]
  40f561:	test   rax,rax
  40f564:	je     40f56a <__swc_fn_65555ab2_000044_a78ae66b+0x8a>
  40f566:	mov    QWORD PTR [rax+0x10],rdi
  40f56a:	mov    QWORD PTR [rsi+0x20],rdi
  40f56e:	mov    rcx,r12
  40f571:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40f576:	mov    rax,rdi
  40f579:	pop    r12
  40f57b:	pop    rdi
  40f57c:	pop    rsi
  40f57d:	ret
	...

000000000040f580 <__swc_fn_65555ab2_000047_6e7a8d58>:
  40f580:	mov    rax,QWORD PTR [rdx+0x10]
  40f584:	test   rax,rax
  40f587:	je     40f593 <__swc_fn_65555ab2_000047_6e7a8d58+0x13>
  40f589:	mov    rcx,QWORD PTR [rdx+0x8]
  40f58d:	mov    QWORD PTR [rax+0x8],rcx
  40f591:	jmp    40f59b <__swc_fn_65555ab2_000047_6e7a8d58+0x1b>
  40f593:	mov    rax,QWORD PTR [rdx+0x8]
  40f597:	mov    QWORD PTR [rcx+0x20],rax
  40f59b:	mov    rax,QWORD PTR [rdx+0x8]
  40f59f:	test   rax,rax
  40f5a2:	je     40f5ac <__swc_fn_65555ab2_000047_6e7a8d58+0x2c>
  40f5a4:	mov    rcx,QWORD PTR [rdx+0x10]
  40f5a8:	mov    QWORD PTR [rax+0x10],rcx
  40f5ac:	vxorps xmm0,xmm0,xmm0
  40f5b0:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40f5b5:	ret
	...

000000000040f5c0 <__swc_fn_65555ab2_000050_129b9bf4>:
  40f5c0:	sub    rsp,0x8
  40f5c4:	mov    r9,r8
  40f5c7:	mov    r10,rdx
  40f5ca:	call   407f90 <__swc_fn_65555ab2_000048_137687bb>
  40f5cf:	mov    eax,0x1
  40f5d4:	xchg   DWORD PTR [r9+0x6c],eax
  40f5d8:	mov    rax,QWORD PTR [r9+0x60]
  40f5dc:	test   rax,rax
  40f5df:	je     40f623 <__swc_fn_65555ab2_000050_129b9bf4+0x63>
  40f5e1:	xor    eax,eax
  40f5e3:	xchg   DWORD PTR [r9+0x6c],eax
  40f5e7:	movzx  eax,BYTE PTR [r9+0x39]
  40f5ec:	lea    rax,[rax+rax*4]
  40f5f0:	lea    rax,[r10+rax*8+0x28]
  40f5f5:	mov    QWORD PTR [r9+0x50],0x0
  40f5fd:	mov    rcx,QWORD PTR [rax+0x8]
  40f601:	mov    QWORD PTR [r9+0x48],rcx
  40f605:	mov    rcx,QWORD PTR [rax+0x8]
  40f609:	test   rcx,rcx
  40f60c:	je     40f614 <__swc_fn_65555ab2_000050_129b9bf4+0x54>
  40f60e:	mov    QWORD PTR [rcx+0x50],r9
  40f612:	jmp    40f618 <__swc_fn_65555ab2_000050_129b9bf4+0x58>
  40f614:	mov    QWORD PTR [rax+0x10],r9
  40f618:	mov    QWORD PTR [rax+0x8],r9
  40f61c:	xor    eax,eax
  40f61e:	add    rsp,0x8
  40f622:	ret
  40f623:	movzx  eax,BYTE PTR [r9+0x39]
  40f628:	lea    rax,[rax+rax*4]
  40f62c:	lea    rax,[r10+rax*8+0x28]
  40f631:	mov    QWORD PTR [r9+0x50],0x0
  40f639:	mov    rcx,QWORD PTR [rax+0x18]
  40f63d:	mov    QWORD PTR [r9+0x48],rcx
  40f641:	mov    rcx,QWORD PTR [rax+0x18]
  40f645:	test   rcx,rcx
  40f648:	je     40f64e <__swc_fn_65555ab2_000050_129b9bf4+0x8e>
  40f64a:	mov    QWORD PTR [rcx+0x50],r9
  40f64e:	mov    QWORD PTR [rax+0x18],r9
  40f652:	mov    eax,0x1
  40f657:	add    rsp,0x8
  40f65b:	ret
  40f65c:	add    BYTE PTR [rax],al
	...

000000000040f660 <__swc_fn_65555ab2_000053_3af34d7f>:
  40f660:	push   r12
  40f662:	push   r13
  40f664:	push   rdi
  40f665:	push   rsi
  40f666:	push   r14
  40f668:	push   r15
  40f66a:	sub    rsp,0x178
  40f671:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40f67a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40f683:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40f68c:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40f695:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40f69e:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40f6a7:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40f6b0:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40f6b9:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40f6c2:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40f6cb:	mov    r12,rcx
  40f6ce:	lea    rax,[rip+0x14b33]        # 424208 <__swc_bss_base_65555ab2+0x1c8>
  40f6d5:	mov    rcx,QWORD PTR [rax]
  40f6d8:	mov    r13,rcx
  40f6db:	test   rcx,rcx
  40f6de:	jne    40f6ee <__swc_fn_65555ab2_000053_3af34d7f+0x8e>
  40f6e0:	mov    r13d,0x1dcd6500
  40f6e6:	mov    ecx,0x1dcd6500
  40f6eb:	xchg   QWORD PTR [rax],rcx
  40f6ee:	lea    rax,[rip+0x12913]        # 422008 <__swc_data_base_65555ab2+0x8>
  40f6f5:	mov    rax,QWORD PTR [rax]
  40f6f8:	cmp    rax,0xffffffffffffffff
  40f6fc:	je     40f70b <__swc_fn_65555ab2_000053_3af34d7f+0xab>
  40f6fe:	mov    eax,eax
  40f700:	mov    edi,eax
  40f702:	xor    eax,eax
  40f704:	call   407000 <pthread_getspecific@plt>
  40f709:	jmp    40f70d <__swc_fn_65555ab2_000053_3af34d7f+0xad>
  40f70b:	xor    eax,eax
  40f70d:	test   rax,rax
  40f710:	jne    40f71f <__swc_fn_65555ab2_000053_3af34d7f+0xbf>
  40f712:	call   40f3c0 <__swc_fn_65555ab2_000035_cd1a4e8c>
  40f717:	mov    rcx,rax
  40f71a:	call   409fc0 <__swc_fn_65555ab2_000132_5f757033>
  40f71f:	test   rax,rax
  40f722:	je     40f734 <__swc_fn_65555ab2_000053_3af34d7f+0xd4>
  40f724:	cmp    QWORD PTR [rax],r12
  40f727:	jne    40f734 <__swc_fn_65555ab2_000053_3af34d7f+0xd4>
  40f729:	cmp    DWORD PTR [rax+0x20],0x0
  40f72d:	jne    40f734 <__swc_fn_65555ab2_000053_3af34d7f+0xd4>
  40f72f:	mov    rsi,rax
  40f732:	jmp    40f736 <__swc_fn_65555ab2_000053_3af34d7f+0xd6>
  40f734:	xor    esi,esi
  40f736:	lea    rdi,[r12+0x2a88]
  40f73e:	mov    r14,QWORD PTR [rdi]
  40f741:	test   r14,r14
  40f744:	jne    40f793 <__swc_fn_65555ab2_000053_3af34d7f+0x133>
  40f746:	lea    rax,[rip+0x14913]        # 424060 <__swc_bss_base_65555ab2+0x20>
  40f74d:	mov    rax,QWORD PTR [rax]
  40f750:	test   rax,rax
  40f753:	setne  al
  40f756:	jne    40f77a <__swc_fn_65555ab2_000053_3af34d7f+0x11a>
  40f758:	mov    rax,QWORD PTR [r12+0x2a70]
  40f760:	test   rax,rax
  40f763:	setne  al
  40f766:	jne    40f77a <__swc_fn_65555ab2_000053_3af34d7f+0x11a>
  40f768:	test   rsi,rsi
  40f76b:	setne  al
  40f76e:	je     40f77a <__swc_fn_65555ab2_000053_3af34d7f+0x11a>
  40f770:	cmp    DWORD PTR [rsi+0x730],0x0
  40f777:	setne  al
  40f77a:	test   al,al
  40f77c:	je     40f78e <__swc_fn_65555ab2_000053_3af34d7f+0x12e>
  40f77e:	call   40a070 <__swc_fn_65555ab2_000135_07d76562>
  40f783:	lea    rcx,[rax+r13*1]
  40f787:	xor    eax,eax
  40f789:	lock cmpxchg QWORD PTR [rdi],rcx
  40f78e:	jmp    40f893 <__swc_fn_65555ab2_000053_3af34d7f+0x233>
  40f793:	call   40a070 <__swc_fn_65555ab2_000135_07d76562>
  40f798:	mov    r15,rax
  40f79b:	cmp    rax,r14
  40f79e:	jb     40f7af <__swc_fn_65555ab2_000053_3af34d7f+0x14f>
  40f7a0:	xor    ecx,ecx
  40f7a2:	mov    rax,r14
  40f7a5:	lock cmpxchg QWORD PTR [rdi],rcx
  40f7aa:	cmp    rax,r14
  40f7ad:	je     40f7b4 <__swc_fn_65555ab2_000053_3af34d7f+0x154>
  40f7af:	jmp    40f893 <__swc_fn_65555ab2_000053_3af34d7f+0x233>
  40f7b4:	test   rsi,rsi
  40f7b7:	je     40f7d2 <__swc_fn_65555ab2_000053_3af34d7f+0x172>
  40f7b9:	cmp    r15,r13
  40f7bc:	jb     40f7d2 <__swc_fn_65555ab2_000053_3af34d7f+0x172>
  40f7be:	mov    rax,r15
  40f7c1:	sub    rax,r13
  40f7c4:	mov    rcx,r12
  40f7c7:	mov    rdx,rsi
  40f7ca:	mov    r8,rax
  40f7cd:	call   4083d0 <__swc_fn_65555ab2_000063_dea90857>
  40f7d2:	lea    rsi,[r12+0x10]
  40f7d7:	mov    rcx,rsi
  40f7da:	call   40e280 <__swc_fn_65555ab2_000139_86bb0f90>
  40f7df:	mov    rax,QWORD PTR [r12+0x18]
  40f7e4:	mov    rdi,rax
  40f7e7:	test   rdi,rdi
  40f7ea:	je     40f814 <__swc_fn_65555ab2_000053_3af34d7f+0x1b4>
  40f7ec:	cs nop WORD PTR [rax+rax*1+0x0]
  40f7f6:	cs nop WORD PTR [rax+rax*1+0x0]
  40f800:	mov    rcx,rdi
  40f803:	call   40be60 <__swc_fn_65555ab2_000019_adca76cf>
  40f808:	mov    rax,QWORD PTR [rdi+0x10]
  40f80c:	mov    rdi,rax
  40f80f:	test   rax,rax
  40f812:	jne    40f800 <__swc_fn_65555ab2_000053_3af34d7f+0x1a0>
  40f814:	mov    rcx,rsi
  40f817:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40f81c:	mov    rcx,r12
  40f81f:	call   40e280 <__swc_fn_65555ab2_000139_86bb0f90>
  40f824:	xor    esi,esi
  40f826:	cs nop WORD PTR [rax+rax*1+0x0]
  40f830:	mov    rax,QWORD PTR [r12+0x2a70]
  40f838:	cmp    rsi,rax
  40f83b:	jae    40f88b <__swc_fn_65555ab2_000053_3af34d7f+0x22b>
  40f83d:	lea    rax,[rsi+rsi*4]
  40f841:	lea    rax,[r12+rax*8+0x268]
  40f849:	mov    r8,QWORD PTR [rax]
  40f84c:	mov    r9,QWORD PTR [rax+0x8]
  40f850:	mov    r10,QWORD PTR [rax+0x10]
  40f854:	mov    rax,QWORD PTR [rax+0x20]
  40f858:	cmp    rax,r15
  40f85b:	jae    40f868 <__swc_fn_65555ab2_000053_3af34d7f+0x208>
  40f85d:	mov    rcx,r15
  40f860:	sub    rcx,rax
  40f863:	cmp    rcx,r13
  40f866:	jae    40f86d <__swc_fn_65555ab2_000053_3af34d7f+0x20d>
  40f868:	inc    rsi
  40f86b:	jmp    40f830 <__swc_fn_65555ab2_000053_3af34d7f+0x1d0>
  40f86d:	mov    rcx,r12
  40f870:	mov    rdx,rsi
  40f873:	call   408380 <__swc_fn_65555ab2_000060_15c28ca7>
  40f878:	mov    rcx,r12
  40f87b:	mov    rdx,r8
  40f87e:	mov    r8,r9
  40f881:	mov    r9,r10
  40f884:	call   40c140 <__swc_fn_65555ab2_000043_d3c2ab54>
  40f889:	jmp    40f830 <__swc_fn_65555ab2_000053_3af34d7f+0x1d0>
  40f88b:	mov    rcx,r12
  40f88e:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40f893:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40f89c:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40f8a5:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40f8ae:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40f8b7:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40f8c0:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40f8c9:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40f8d2:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40f8db:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40f8e4:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40f8ed:	add    rsp,0x178
  40f8f4:	pop    r15
  40f8f6:	pop    r14
  40f8f8:	pop    rsi
  40f8f9:	pop    rdi
  40f8fa:	pop    r13
  40f8fc:	pop    r12
  40f8fe:	ret
	...

000000000040f900 <__swc_fn_65555ab2_000056_df0696cd>:
  40f900:	lea    rax,[rdx-0x58]
  40f904:	ret
	...

000000000040f910 <__swc_fn_65555ab2_000059_2ca0cb05>:
  40f910:	push   rsi
  40f911:	push   rdi
  40f912:	push   r12
  40f914:	push   r13
  40f916:	sub    rsp,0x68
  40f91a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40f920:	mov    rsi,r9
  40f923:	mov    rdi,rcx
  40f926:	mov    r12,rdx
  40f929:	mov    r13,r8
  40f92c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40f934:	jne    40f943 <__swc_fn_65555ab2_000059_2ca0cb05+0x33>
  40f936:	xor    eax,eax
  40f938:	add    rsp,0x68
  40f93c:	pop    r13
  40f93e:	pop    r12
  40f940:	pop    rdi
  40f941:	pop    rsi
  40f942:	ret
  40f943:	mov    rcx,rdi
  40f946:	call   40e280 <__swc_fn_65555ab2_000139_86bb0f90>
  40f94b:	movabs rax,0x7fffffffffffffff
  40f955:	cmp    r12,rax
  40f958:	mov    rax,0xffffffffffffffff
  40f95f:	lea    rcx,[r12+r12*1]
  40f963:	cmovbe rax,rcx
  40f967:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40f96e:	mov    rdx,rcx
  40f971:	sub    rax,r12
  40f974:	inc    rax
  40f977:	xor    r8d,r8d
  40f97a:	test   rcx,rcx
  40f97d:	jbe    40f9a8 <__swc_fn_65555ab2_000059_2ca0cb05+0x98>
  40f97f:	nop
  40f980:	lea    r9,[r8+r8*4]
  40f984:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40f98c:	sub    r9,r12
  40f98f:	cmp    r9,rax
  40f992:	jae    40f99f <__swc_fn_65555ab2_000059_2ca0cb05+0x8f>
  40f994:	mov    rdx,r8
  40f997:	mov    rax,r9
  40f99a:	test   r9,r9
  40f99d:	je     40f9a8 <__swc_fn_65555ab2_000059_2ca0cb05+0x98>
  40f99f:	add    r8,0x1
  40f9a3:	cmp    r8,rcx
  40f9a6:	jb     40f980 <__swc_fn_65555ab2_000059_2ca0cb05+0x70>
  40f9a8:	mov    rax,QWORD PTR [rdi+0x2a70]
  40f9af:	cmp    rdx,rax
  40f9b2:	jne    40f9cf <__swc_fn_65555ab2_000059_2ca0cb05+0xbf>
  40f9b4:	mov    rcx,rdi
  40f9b7:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40f9bc:	xor    eax,eax
  40f9be:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40f9c4:	add    rsp,0x68
  40f9c8:	pop    r13
  40f9ca:	pop    r12
  40f9cc:	pop    rdi
  40f9cd:	pop    rsi
  40f9ce:	ret
  40f9cf:	lea    rax,[rdx+rdx*4]
  40f9d3:	lea    rax,[rdi+rax*8+0x268]
  40f9db:	vmovups xmm6,XMMWORD PTR [rax]
  40f9df:	mov    r8,QWORD PTR [rax+0x10]
  40f9e3:	mov    rcx,rdi
  40f9e6:	call   408380 <__swc_fn_65555ab2_000060_15c28ca7>
  40f9eb:	vpshufd xmm0,xmm6,0xee
  40f9f0:	vmovsd QWORD PTR [r13+0x0],xmm0
  40f9f6:	mov    QWORD PTR [rsi],r8
  40f9f9:	mov    rcx,rdi
  40f9fc:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40fa01:	vmovq  rax,xmm6
  40fa06:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40fa0c:	add    rsp,0x68
  40fa10:	pop    r13
  40fa12:	pop    r12
  40fa14:	pop    rdi
  40fa15:	pop    rsi
  40fa16:	ret
	...

000000000040fa20 <__swc_fn_65555ab2_000062_b304235a>:
  40fa20:	push   r12
  40fa22:	push   r13
  40fa24:	push   r14
  40fa26:	push   r15
  40fa28:	push   rdi
  40fa29:	push   rsi
  40fa2a:	sub    rsp,0x148
  40fa31:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40fa3a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40fa43:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40fa4c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40fa55:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40fa5e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40fa67:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40fa70:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40fa79:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40fa82:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40fa8b:	mov    r12,r9
  40fa8e:	mov    r13,rcx
  40fa91:	mov    r14,rdx
  40fa94:	mov    r15,r8
  40fa97:	test   rdx,rdx
  40fa9a:	jne    40faae <__swc_fn_65555ab2_000062_b304235a+0x8e>
  40fa9c:	add    rsp,0x148
  40faa3:	pop    rsi
  40faa4:	pop    rdi
  40faa5:	pop    r15
  40faa7:	pop    r14
  40faa9:	pop    r13
  40faab:	pop    r12
  40faad:	ret
  40faae:	cmp    r12,0x200000
  40fab5:	ja     40fb47 <__swc_fn_65555ab2_000062_b304235a+0x127>
  40fabb:	lea    rax,[rip+0x12546]        # 422008 <__swc_data_base_65555ab2+0x8>
  40fac2:	mov    rax,QWORD PTR [rax]
  40fac5:	cmp    rax,0xffffffffffffffff
  40fac9:	je     40fad8 <__swc_fn_65555ab2_000062_b304235a+0xb8>
  40facb:	mov    eax,eax
  40facd:	mov    edi,eax
  40facf:	xor    eax,eax
  40fad1:	call   407000 <pthread_getspecific@plt>
  40fad6:	jmp    40fada <__swc_fn_65555ab2_000062_b304235a+0xba>
  40fad8:	xor    eax,eax
  40fada:	test   rax,rax
  40fadd:	je     40fae4 <__swc_fn_65555ab2_000062_b304235a+0xc4>
  40fadf:	mov    rsi,rax
  40fae2:	jmp    40faf4 <__swc_fn_65555ab2_000062_b304235a+0xd4>
  40fae4:	call   40f3c0 <__swc_fn_65555ab2_000035_cd1a4e8c>
  40fae9:	mov    rcx,rax
  40faec:	call   409fc0 <__swc_fn_65555ab2_000132_5f757033>
  40faf1:	mov    rsi,rax
  40faf4:	test   rsi,rsi
  40faf7:	je     40fb47 <__swc_fn_65555ab2_000062_b304235a+0x127>
  40faf9:	cmp    QWORD PTR [rsi],r13
  40fafc:	jne    40fb47 <__swc_fn_65555ab2_000062_b304235a+0x127>
  40fafe:	cmp    DWORD PTR [rsi+0x20],0x0
  40fb02:	jne    40fb47 <__swc_fn_65555ab2_000062_b304235a+0x127>
  40fb04:	cmp    DWORD PTR [rsi+0x730],0x10
  40fb0b:	jae    40fb47 <__swc_fn_65555ab2_000062_b304235a+0x127>
  40fb0d:	mov    eax,DWORD PTR [rsi+0x730]
  40fb13:	lea    rdi,[rax+rax*4]
  40fb17:	lea    rdi,[rsi+rdi*8+0x738]
  40fb1f:	mov    QWORD PTR [rdi],r14
  40fb22:	mov    QWORD PTR [rdi+0x8],r15
  40fb26:	mov    QWORD PTR [rdi+0x10],r12
  40fb2a:	mov    QWORD PTR [rdi+0x18],0x0
  40fb32:	call   40a070 <__swc_fn_65555ab2_000135_07d76562>
  40fb37:	mov    QWORD PTR [rdi+0x20],rax
  40fb3b:	add    DWORD PTR [rsi+0x730],0x1
  40fb42:	jmp    40fca6 <__swc_fn_65555ab2_000062_b304235a+0x286>
  40fb47:	mov    rcx,r13
  40fb4a:	call   40c870 <__swc_fn_65555ab2_000061_ad030a10>
  40fb4f:	mov    rsi,rax
  40fb52:	cmp    r12,rax
  40fb55:	jbe    40fb8a <__swc_fn_65555ab2_000062_b304235a+0x16a>
  40fb57:	cmp    r12,0x10000000
  40fb5e:	seta   al
  40fb61:	ja     40fb70 <__swc_fn_65555ab2_000062_b304235a+0x150>
  40fb63:	mov    rax,QWORD PTR [r13+0x2a70]
  40fb6a:	test   rax,rax
  40fb6d:	setne  al
  40fb70:	test   al,al
  40fb72:	je     40fb8a <__swc_fn_65555ab2_000062_b304235a+0x16a>
  40fb74:	mov    rcx,r13
  40fb77:	mov    rdx,r14
  40fb7a:	mov    r8,r15
  40fb7d:	mov    r9,r12
  40fb80:	call   40c140 <__swc_fn_65555ab2_000043_d3c2ab54>
  40fb85:	jmp    40fca6 <__swc_fn_65555ab2_000062_b304235a+0x286>
  40fb8a:	call   40a070 <__swc_fn_65555ab2_000135_07d76562>
  40fb8f:	mov    rdi,rax
  40fb92:	mov    rcx,r13
  40fb95:	call   40e280 <__swc_fn_65555ab2_000139_86bb0f90>
  40fb9a:	cmp    QWORD PTR [r13+0x2a70],0x0
  40fba2:	je     40fc5a <__swc_fn_65555ab2_000062_b304235a+0x23a>
  40fba8:	nop    DWORD PTR [rax+rax*1+0x0]
  40fbb0:	cmp    QWORD PTR [r13+0x2a70],0x100
  40fbbb:	jae    40fbd0 <__swc_fn_65555ab2_000062_b304235a+0x1b0>
  40fbbd:	mov    rax,QWORD PTR [r13+0x2a68]
  40fbc4:	add    rax,r12
  40fbc7:	cmp    rax,rsi
  40fbca:	jbe    40fc5a <__swc_fn_65555ab2_000062_b304235a+0x23a>
  40fbd0:	xor    eax,eax
  40fbd2:	mov    rcx,QWORD PTR [r13+0x2a70]
  40fbd9:	mov    edx,0x1
  40fbde:	cmp    rcx,0x1
  40fbe2:	jbe    40fc19 <__swc_fn_65555ab2_000062_b304235a+0x1f9>
  40fbe4:	cs nop WORD PTR [rax+rax*1+0x0]
  40fbee:	xchg   ax,ax
  40fbf0:	lea    r8,[rdx+rdx*4]
  40fbf4:	lea    r8,[r13+r8*8+0x268]
  40fbfc:	lea    r9,[rax+rax*4]
  40fc00:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40fc08:	cmp    QWORD PTR [r8+0x18],r9
  40fc0c:	cmovb  rax,rdx
  40fc10:	add    rdx,0x1
  40fc14:	cmp    rdx,rcx
  40fc17:	jb     40fbf0 <__swc_fn_65555ab2_000062_b304235a+0x1d0>
  40fc19:	lea    rcx,[rax+rax*4]
  40fc1d:	lea    rcx,[r13+rcx*8+0x268]
  40fc25:	mov    r8,QWORD PTR [rcx]
  40fc28:	mov    r9,QWORD PTR [rcx+0x8]
  40fc2c:	mov    r10,QWORD PTR [rcx+0x10]
  40fc30:	mov    rcx,r13
  40fc33:	mov    rdx,rax
  40fc36:	call   408380 <__swc_fn_65555ab2_000060_15c28ca7>
  40fc3b:	mov    rcx,r13
  40fc3e:	mov    rdx,r8
  40fc41:	mov    r8,r9
  40fc44:	mov    r9,r10
  40fc47:	call   40c140 <__swc_fn_65555ab2_000043_d3c2ab54>
  40fc4c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40fc54:	jne    40fbb0 <__swc_fn_65555ab2_000062_b304235a+0x190>
  40fc5a:	add    QWORD PTR [r13+0x2a78],0x1
  40fc62:	mov    rax,QWORD PTR [r13+0x2a70]
  40fc69:	lea    rax,[rax+rax*4]
  40fc6d:	lea    rax,[r13+rax*8+0x268]
  40fc75:	mov    QWORD PTR [rax],r14
  40fc78:	mov    QWORD PTR [rax+0x8],r15
  40fc7c:	mov    QWORD PTR [rax+0x10],r12
  40fc80:	mov    rcx,QWORD PTR [r13+0x2a78]
  40fc87:	mov    QWORD PTR [rax+0x18],rcx
  40fc8b:	mov    QWORD PTR [rax+0x20],rdi
  40fc8f:	add    QWORD PTR [r13+0x2a68],r12
  40fc96:	add    QWORD PTR [r13+0x2a70],0x1
  40fc9e:	mov    rcx,r13
  40fca1:	call   411850 <__swc_fn_65555ab2_000140_055b38a4>
  40fca6:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40fcaf:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40fcb8:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40fcc1:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40fcca:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40fcd3:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40fcdc:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40fce5:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40fcee:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40fcf7:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40fd00:	add    rsp,0x148
  40fd07:	pop    rsi
  40fd08:	pop    rdi
  40fd09:	pop    r15
  40fd0b:	pop    r14
  40fd0d:	pop    r13
  40fd0f:	pop    r12
  40fd11:	ret
	...

000000000040fd20 <__swc_fn_65555ab2_000065_d9ee99ea>:
  40fd20:	push   rbx
  40fd21:	push   r12
  40fd23:	push   r13
  40fd25:	push   r14
  40fd27:	push   r15
  40fd29:	push   rdi
  40fd2a:	push   rsi
  40fd2b:	sub    rsp,0xf0
  40fd32:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40fd38:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40fd3e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40fd44:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40fd4a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40fd53:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40fd5c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40fd65:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40fd6e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40fd77:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40fd80:	mov    eax,r8d
  40fd83:	mov    rbx,rcx
  40fd86:	mov    r12,rdx
  40fd89:	mov    QWORD PTR [rsp+0x18],rdx
  40fd8e:	mov    ecx,DWORD PTR [r12+0x58]
  40fd93:	mov    r13d,ecx
  40fd96:	cmp    ecx,0x10
  40fd99:	mov    ecx,0x10
  40fd9e:	cmovb  r13d,ecx
  40fda2:	test   r13d,r13d
  40fda5:	mov    rcx,r13
  40fda8:	mov    edx,0x8
  40fdad:	cmove  ecx,edx
  40fdb0:	dec    rcx
  40fdb3:	mov    rdx,0xffffffffffffffff
  40fdba:	sub    rdx,rcx
  40fdbd:	xor    r14d,r14d
  40fdc0:	mov    r8,rcx
  40fdc3:	not    r8
  40fdc6:	lea    rcx,[rcx+0x58]
  40fdca:	and    rcx,r8
  40fdcd:	cmp    rdx,0x58
  40fdd1:	cmovae r14,rcx
  40fdd5:	cmp    eax,0xffffffff
  40fdd8:	jne    40fde1 <__swc_fn_65555ab2_000065_d9ee99ea+0xc1>
  40fdda:	mov    r15,QWORD PTR [r12+0x48]
  40fddf:	jmp    40fe13 <__swc_fn_65555ab2_000065_d9ee99ea+0xf3>
  40fde1:	test   eax,eax
  40fde3:	jne    40fdec <__swc_fn_65555ab2_000065_d9ee99ea+0xcc>
  40fde5:	mov    eax,0x8
  40fdea:	jmp    40fe10 <__swc_fn_65555ab2_000065_d9ee99ea+0xf0>
  40fdec:	cmp    eax,0x8
  40fdef:	ja     40fdf7 <__swc_fn_65555ab2_000065_d9ee99ea+0xd7>
  40fdf1:	shl    rax,0x4
  40fdf5:	jmp    40fe10 <__swc_fn_65555ab2_000065_d9ee99ea+0xf0>
  40fdf7:	lea    eax,[rax-0x9]
  40fdfa:	mov    ecx,eax
  40fdfc:	shr    ecx,0x2
  40fdff:	and    eax,0x3
  40fe02:	lea    ecx,[rcx+0x7]
  40fe05:	lea    ecx,[rcx-0x2]
  40fe08:	lea    eax,[rax+0x5]
  40fe0b:	shlx   rax,rax,rcx
  40fe10:	mov    r15,rax
  40fe13:	lea    rax,[r14+r13*1]
  40fe17:	mov    rcx,0xffffffffffffffff
  40fe1e:	sub    rcx,rax
  40fe21:	cmp    r15,rcx
  40fe24:	jbe    40fe34 <__swc_fn_65555ab2_000065_d9ee99ea+0x114>
  40fe26:	mov    QWORD PTR [r12+0x40],0x0
  40fe2f:	jmp    410206 <__swc_fn_65555ab2_000065_d9ee99ea+0x4e6>
  40fe34:	mov    QWORD PTR [rsp+0x20],r13
  40fe39:	lea    r13,[rsp+0x8]
  40fe3e:	add    rax,r15
  40fe41:	mov    ecx,0x1000
  40fe46:	test   ecx,ecx
  40fe48:	mov    edx,0x8
  40fe4d:	cmove  ecx,edx
  40fe50:	dec    rcx
  40fe53:	mov    rdx,0xffffffffffffffff
  40fe5a:	sub    rdx,rcx
  40fe5d:	cmp    rax,rdx
  40fe60:	jbe    40fe6c <__swc_fn_65555ab2_000065_d9ee99ea+0x14c>
  40fe62:	mov    QWORD PTR [r13+0x0],0x0
  40fe6a:	jmp    40fe79 <__swc_fn_65555ab2_000065_d9ee99ea+0x159>
  40fe6c:	add    rax,rcx
  40fe6f:	andn   rax,rcx,rax
  40fe74:	mov    QWORD PTR [rsp+0x8],rax
  40fe79:	cmp    QWORD PTR [r13+0x0],0x0
  40fe7e:	jne    40fe8e <__swc_fn_65555ab2_000065_d9ee99ea+0x16e>
  40fe80:	mov    QWORD PTR [r12+0x40],0x0
  40fe89:	jmp    410206 <__swc_fn_65555ab2_000065_d9ee99ea+0x4e6>
  40fe8e:	mov    QWORD PTR [rsp+0x30],r15
  40fe93:	xor    r15d,r15d
  40fe96:	mov    QWORD PTR [rsp+0x38],0x0
  40fe9f:	lea    r12,[rsp+0x10]
  40fea4:	mov    QWORD PTR [rsp+0x28],r14
  40fea9:	mov    r14,QWORD PTR [rsp+0x8]
  40feae:	mov    QWORD PTR [rsp+0x10],r14
  40feb3:	cmp    r14,0x10000
  40feba:	ja     40fec1 <__swc_fn_65555ab2_000065_d9ee99ea+0x1a1>
  40febc:	mov    rax,r14
  40febf:	jmp    40ff12 <__swc_fn_65555ab2_000065_d9ee99ea+0x1f2>
  40fec1:	xor    eax,eax
  40fec3:	lea    rcx,[r14-0x1]
  40fec7:	lzcnt  rax,rcx
  40fecc:	mov    ecx,0x3f
  40fed1:	sub    rcx,rax
  40fed4:	mov    eax,0x1
  40fed9:	lea    rcx,[rcx-0x3]
  40fedd:	shl    rax,cl
  40fee0:	mov    rcx,rax
  40fee3:	cmp    rax,0x1000
  40feea:	mov    eax,0x1000
  40feef:	cmovb  rcx,rax
  40fef3:	mov    rdx,0xffffffffffffffff
  40fefa:	sub    rdx,rcx
  40fefd:	mov    rax,r14
  40ff00:	lea    r8,[r14+rcx*1-0x1]
  40ff05:	neg    rcx
  40ff08:	and    r8,rcx
  40ff0b:	cmp    r14,rdx
  40ff0e:	cmovbe rax,r8
  40ff12:	mov    QWORD PTR [rsp+0x8],rax
  40ff17:	lea    rax,[rip+0x120ea]        # 422008 <__swc_data_base_65555ab2+0x8>
  40ff1e:	mov    rax,QWORD PTR [rax]
  40ff21:	cmp    rax,0xffffffffffffffff
  40ff25:	je     40ff34 <__swc_fn_65555ab2_000065_d9ee99ea+0x214>
  40ff27:	mov    eax,eax
  40ff29:	mov    edi,eax
  40ff2b:	xor    eax,eax
  40ff2d:	call   407000 <pthread_getspecific@plt>
  40ff32:	jmp    40ff36 <__swc_fn_65555ab2_000065_d9ee99ea+0x216>
  40ff34:	xor    eax,eax
  40ff36:	test   rax,rax
  40ff39:	jne    40ff48 <__swc_fn_65555ab2_000065_d9ee99ea+0x228>
  40ff3b:	call   40f3c0 <__swc_fn_65555ab2_000035_cd1a4e8c>
  40ff40:	mov    rcx,rax
  40ff43:	call   409fc0 <__swc_fn_65555ab2_000132_5f757033>
  40ff48:	test   rax,rax
  40ff4b:	je     41003c <__swc_fn_65555ab2_000065_d9ee99ea+0x31c>
  40ff51:	cmp    QWORD PTR [rax],rbx
  40ff54:	jne    41003c <__swc_fn_65555ab2_000065_d9ee99ea+0x31c>
  40ff5a:	cmp    DWORD PTR [rax+0x20],0x0
  40ff5e:	jne    41003c <__swc_fn_65555ab2_000065_d9ee99ea+0x31c>
  40ff64:	mov    rcx,QWORD PTR [rsp+0x8]
  40ff69:	movabs rdx,0x7fffffffffffffff
  40ff73:	cmp    rcx,rdx
  40ff76:	mov    rdx,0xffffffffffffffff
  40ff7d:	lea    r8,[rcx+rcx*1]
  40ff81:	cmovbe rdx,r8
  40ff85:	mov    r8d,DWORD PTR [rax+0x730]
  40ff8c:	mov    r9d,r8d
  40ff8f:	sub    rdx,rcx
  40ff92:	inc    rdx
  40ff95:	xor    r10d,r10d
  40ff98:	test   r8,r8
  40ff9b:	jbe    40ffcb <__swc_fn_65555ab2_000065_d9ee99ea+0x2ab>
  40ff9d:	nop    DWORD PTR [rax]
  40ffa0:	mov    r11d,r10d
  40ffa3:	lea    r11,[r11+r11*4]
  40ffa7:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40ffaf:	sub    r11,rcx
  40ffb2:	cmp    r11,rdx
  40ffb5:	jae    40ffc2 <__swc_fn_65555ab2_000065_d9ee99ea+0x2a2>
  40ffb7:	mov    r9d,r10d
  40ffba:	mov    rdx,r11
  40ffbd:	test   r11,r11
  40ffc0:	je     40ffcb <__swc_fn_65555ab2_000065_d9ee99ea+0x2ab>
  40ffc2:	add    r10,0x1
  40ffc6:	cmp    r10,r8
  40ffc9:	jb     40ffa0 <__swc_fn_65555ab2_000065_d9ee99ea+0x280>
  40ffcb:	mov    ecx,DWORD PTR [rax+0x730]
  40ffd1:	cmp    r9d,ecx
  40ffd4:	jne    40ffda <__swc_fn_65555ab2_000065_d9ee99ea+0x2ba>
  40ffd6:	xor    eax,eax
  40ffd8:	jmp    410039 <__swc_fn_65555ab2_000065_d9ee99ea+0x319>
  40ffda:	lea    rcx,[r9+r9*4]
  40ffde:	lea    rcx,[rax+rcx*8+0x738]
  40ffe6:	vmovups xmm0,XMMWORD PTR [rcx]
  40ffea:	mov    rdx,QWORD PTR [rcx+0x10]
  40ffee:	sub    DWORD PTR [rax+0x730],0x1
  40fff5:	mov    r8d,DWORD PTR [rax+0x730]
  40fffc:	lea    r8,[r8+r8*4]
  410000:	lea    r8,[rax+r8*8+0x738]
  410008:	vmovups xmm1,XMMWORD PTR [r8]
  41000d:	vmovups XMMWORD PTR [rcx],xmm1
  410011:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  410017:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  41001c:	mov    rax,QWORD PTR [r8+0x20]
  410020:	mov    QWORD PTR [rcx+0x20],rax
  410024:	vpshufd xmm1,xmm0,0xee
  410029:	vmovsd QWORD PTR [rsp+0x8],xmm1
  41002f:	mov    QWORD PTR [rsp+0x10],rdx
  410034:	vmovq  rax,xmm0
  410039:	mov    r15,rax
  41003c:	test   r15,r15
  41003f:	jne    410057 <__swc_fn_65555ab2_000065_d9ee99ea+0x337>
  410041:	mov    rcx,rbx
  410044:	mov    rdx,QWORD PTR [rsp+0x8]
  410049:	mov    r8,r13
  41004c:	mov    r9,r12
  41004f:	call   40f910 <__swc_fn_65555ab2_000059_2ca0cb05>
  410054:	mov    r15,rax
  410057:	test   r15,r15
  41005a:	je     41009b <__swc_fn_65555ab2_000065_d9ee99ea+0x37b>
  41005c:	cmp    QWORD PTR [r12],r14
  410060:	jae    41009b <__swc_fn_65555ab2_000065_d9ee99ea+0x37b>
  410062:	mov    rax,r15
  410065:	add    rax,QWORD PTR [r12]
  410069:	mov    rdx,r14
  41006c:	sub    rdx,QWORD PTR [r12]
  410070:	mov    rcx,rax
  410073:	call   40bc90 <__swc_fn_65555ab2_000007_f7acedb0>
  410078:	test   al,al
  41007a:	je     410083 <__swc_fn_65555ab2_000065_d9ee99ea+0x363>
  41007c:	mov    QWORD PTR [rsp+0x10],r14
  410081:	jmp    41009b <__swc_fn_65555ab2_000065_d9ee99ea+0x37b>
  410083:	mov    rcx,rbx
  410086:	mov    rdx,r15
  410089:	mov    r8,QWORD PTR [rsp+0x8]
  41008e:	mov    r9,QWORD PTR [rsp+0x10]
  410093:	call   40fa20 <__swc_fn_65555ab2_000062_b304235a>
  410098:	xor    r15d,r15d
  41009b:	test   r15,r15
  41009e:	jne    41011a <__swc_fn_65555ab2_000065_d9ee99ea+0x3fa>
  4100a0:	cmp    r14,0x10000
  4100a7:	ja     4100ae <__swc_fn_65555ab2_000065_d9ee99ea+0x38e>
  4100a9:	mov    rax,r14
  4100ac:	jmp    4100ff <__swc_fn_65555ab2_000065_d9ee99ea+0x3df>
  4100ae:	xor    eax,eax
  4100b0:	lea    rcx,[r14-0x1]
  4100b4:	lzcnt  rax,rcx
  4100b9:	mov    ecx,0x3f
  4100be:	sub    rcx,rax
  4100c1:	mov    eax,0x1
  4100c6:	lea    rcx,[rcx-0x3]
  4100ca:	shl    rax,cl
  4100cd:	mov    rcx,rax
  4100d0:	cmp    rax,0x1000
  4100d7:	mov    eax,0x1000
  4100dc:	cmovb  rcx,rax
  4100e0:	mov    rdx,0xffffffffffffffff
  4100e7:	sub    rdx,rcx
  4100ea:	mov    rax,r14
  4100ed:	lea    r8,[r14+rcx*1-0x1]
  4100f2:	neg    rcx
  4100f5:	and    r8,rcx
  4100f8:	cmp    r14,rdx
  4100fb:	cmovbe rax,r8
  4100ff:	mov    QWORD PTR [rsp+0x8],rax
  410104:	mov    QWORD PTR [rsp+0x10],r14
  410109:	mov    rcx,rbx
  41010c:	mov    rdx,rax
  41010f:	mov    r8,r14
  410112:	call   40f480 <__swc_fn_65555ab2_000041_c90d80c1>
  410117:	mov    r15,rax
  41011a:	test   r15,r15
  41011d:	jne    41012b <__swc_fn_65555ab2_000065_d9ee99ea+0x40b>
  41011f:	mov    r13,QWORD PTR [rsp+0x20]
  410124:	mov    rsi,QWORD PTR [rsp+0x38]
  410129:	jmp    410167 <__swc_fn_65555ab2_000065_d9ee99ea+0x447>
  41012b:	mov    rax,r15
  41012e:	add    rax,QWORD PTR [rsp+0x28]
  410133:	mov    r13,QWORD PTR [rsp+0x20]
  410138:	test   r13d,r13d
  41013b:	mov    rcx,r13
  41013e:	mov    edx,0x8
  410143:	cmove  ecx,edx
  410146:	dec    rcx
  410149:	mov    rdx,0xffffffffffffffff
  410150:	sub    rdx,rcx
  410153:	cmp    rax,rdx
  410156:	jbe    41015c <__swc_fn_65555ab2_000065_d9ee99ea+0x43c>
  410158:	xor    eax,eax
  41015a:	jmp    410164 <__swc_fn_65555ab2_000065_d9ee99ea+0x444>
  41015c:	add    rax,rcx
  41015f:	andn   rax,rcx,rax
  410164:	mov    rsi,rax
  410167:	mov    rax,QWORD PTR [rsp+0x8]
  41016c:	test   r15,r15
  41016f:	je     410178 <__swc_fn_65555ab2_000065_d9ee99ea+0x458>
  410171:	mov    rdi,QWORD PTR [rsp+0x18]
  410176:	jmp    41018a <__swc_fn_65555ab2_000065_d9ee99ea+0x46a>
  410178:	mov    rdi,QWORD PTR [rsp+0x18]
  41017d:	mov    QWORD PTR [rdi+0x40],0x0
  410185:	jmp    410206 <__swc_fn_65555ab2_000065_d9ee99ea+0x4e6>
  41018a:	lea    rdx,[rsi-0x58]
  41018e:	mov    QWORD PTR [rsi-0x58],r15
  410192:	mov    QWORD PTR [rsi-0x50],rax
  410196:	mov    rax,QWORD PTR [rsp+0x10]
  41019b:	mov    QWORD PTR [rsi-0x48],rax
  41019f:	mov    QWORD PTR [rsi-0x40],rsi
  4101a3:	mov    rax,QWORD PTR [rdi+0x48]
  4101a7:	mov    QWORD PTR [rsi-0x38],rax
  4101ab:	mov    rax,QWORD PTR [rsp+0x30]
  4101b0:	mov    QWORD PTR [rsi-0x30],rax
  4101b4:	mov    DWORD PTR [rsi-0x10],r13d
  4101b8:	mov    QWORD PTR [rsi-0x28],0x0
  4101c0:	mov    QWORD PTR [rsi-0x20],0x0
  4101c8:	add    r15,QWORD PTR [r12]
  4101cc:	sub    r15,rsi
  4101cf:	mov    QWORD PTR [rsi-0x30],r15
  4101d3:	mov    rcx,QWORD PTR [rbx+0x250]
  4101da:	nop    WORD PTR [rax+rax*1+0x0]
  4101e0:	lea    r8,[rcx+r15*1]
  4101e4:	mov    rax,rcx
  4101e7:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  4101f0:	cmp    rax,rcx
  4101f3:	je     4101fa <__swc_fn_65555ab2_000065_d9ee99ea+0x4da>
  4101f5:	mov    rcx,rax
  4101f8:	jmp    4101e0 <__swc_fn_65555ab2_000065_d9ee99ea+0x4c0>
  4101fa:	mov    rcx,rbx
  4101fd:	call   4082f0 <__swc_fn_65555ab2_000057_7e1dbcb0>
  410202:	mov    QWORD PTR [rdi+0x40],rsi
  410206:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  41020c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  410212:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  410218:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  41021e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  410227:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  410230:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  410239:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  410242:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  41024b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  410254:	add    rsp,0xf0
  41025b:	pop    rsi
  41025c:	pop    rdi
  41025d:	pop    r15
  41025f:	pop    r14
  410261:	pop    r13
  410263:	pop    r12
  410265:	pop    rbx
  410266:	ret
	...

0000000000410270 <__swc_fn_65555ab2_000068_f3aa21af>:
  410270:	push   rbx
  410271:	push   r12
  410273:	push   rdi
  410274:	push   rsi
  410275:	sub    rsp,0xb8
  41027c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  410282:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410288:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41028e:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410294:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  41029a:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4102a0:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4102a6:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4102af:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4102b8:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4102c1:	mov    rbx,rdx
  4102c4:	mov    r12,rcx
  4102c7:	cmp    DWORD PTR [rbx+0x58],0x0
  4102cb:	je     4102e5 <__swc_fn_65555ab2_000068_f3aa21af+0x75>
  4102cd:	mov    eax,DWORD PTR [rbx+0x58]
  4102d0:	sub    eax,0x1
  4102d3:	test   DWORD PTR [rbx+0x58],eax
  4102d6:	je     4102e5 <__swc_fn_65555ab2_000068_f3aa21af+0x75>
  4102d8:	mov    QWORD PTR [rbx+0x40],0x0
  4102e0:	jmp    4104f7 <__swc_fn_65555ab2_000068_f3aa21af+0x287>
  4102e5:	cmp    QWORD PTR [rbx+0x48],0x0
  4102ea:	jne    4102f9 <__swc_fn_65555ab2_000068_f3aa21af+0x89>
  4102ec:	mov    QWORD PTR [rbx+0x40],0x0
  4102f4:	jmp    4104f7 <__swc_fn_65555ab2_000068_f3aa21af+0x287>
  4102f9:	lea    rax,[rsp+0x8]
  4102fe:	mov    rcx,QWORD PTR [rbx+0x48]
  410302:	cmp    rcx,0x8
  410306:	ja     410310 <__swc_fn_65555ab2_000068_f3aa21af+0xa0>
  410308:	mov    DWORD PTR [rax],0x0
  41030e:	jmp    41036b <__swc_fn_65555ab2_000068_f3aa21af+0xfb>
  410310:	cmp    rcx,0x80
  410317:	ja     410327 <__swc_fn_65555ab2_000068_f3aa21af+0xb7>
  410319:	lea    rcx,[rcx+0xf]
  41031d:	shr    rcx,0x4
  410321:	mov    DWORD PTR [rsp+0x8],ecx
  410325:	jmp    41036b <__swc_fn_65555ab2_000068_f3aa21af+0xfb>
  410327:	cmp    rcx,0x10000
  41032e:	jbe    410338 <__swc_fn_65555ab2_000068_f3aa21af+0xc8>
  410330:	mov    DWORD PTR [rax],0xffffffff
  410336:	jmp    41036b <__swc_fn_65555ab2_000068_f3aa21af+0xfb>
  410338:	dec    rcx
  41033b:	xor    edx,edx
  41033d:	lzcnt  rdx,rcx
  410342:	mov    r8d,0x3f
  410348:	sub    r8d,edx
  41034b:	lea    edx,[r8-0x2]
  41034f:	shrx   rcx,rcx,rdx
  410354:	and    ecx,0x3
  410357:	lea    edx,[r8-0x7]
  41035b:	lea    edx,[rdx*4+0x0]
  410362:	lea    edx,[rdx+0x9]
  410365:	add    edx,ecx
  410367:	mov    DWORD PTR [rsp+0x8],edx
  41036b:	cmp    DWORD PTR [rax],0x0
  41036e:	jne    41037e <__swc_fn_65555ab2_000068_f3aa21af+0x10e>
  410370:	cmp    DWORD PTR [rbx+0x58],0x8
  410374:	jbe    41037e <__swc_fn_65555ab2_000068_f3aa21af+0x10e>
  410376:	mov    DWORD PTR [rsp+0x8],0x1
  41037e:	cmp    DWORD PTR [rbx+0x58],0x10
  410382:	jbe    410401 <__swc_fn_65555ab2_000068_f3aa21af+0x191>
  410388:	cmp    DWORD PTR [rbx+0x58],0x40
  41038c:	ja     410401 <__swc_fn_65555ab2_000068_f3aa21af+0x191>
  41038e:	cmp    DWORD PTR [rax],0xffffffff
  410391:	je     410401 <__swc_fn_65555ab2_000068_f3aa21af+0x191>
  410393:	mov    ecx,DWORD PTR [rsp+0x8]
  410397:	mov    edx,DWORD PTR [rbx+0x58]
  41039a:	dec    rdx
  41039d:	cmp    ecx,0x2d
  4103a0:	jae    4103f8 <__swc_fn_65555ab2_000068_f3aa21af+0x188>
  4103a2:	cs nop WORD PTR [rax+rax*1+0x0]
  4103ac:	nop    DWORD PTR [rax+0x0]
  4103b0:	mov    r8d,ecx
  4103b3:	test   ecx,ecx
  4103b5:	jne    4103bf <__swc_fn_65555ab2_000068_f3aa21af+0x14f>
  4103b7:	mov    r8d,0x8
  4103bd:	jmp    4103eb <__swc_fn_65555ab2_000068_f3aa21af+0x17b>
  4103bf:	cmp    r8d,0x8
  4103c3:	ja     4103cb <__swc_fn_65555ab2_000068_f3aa21af+0x15b>
  4103c5:	shl    r8,0x4
  4103c9:	jmp    4103eb <__swc_fn_65555ab2_000068_f3aa21af+0x17b>
  4103cb:	lea    r8d,[r8-0x9]
  4103cf:	mov    r9d,r8d
  4103d2:	shr    r9d,0x2
  4103d6:	and    r8d,0x3
  4103da:	lea    r9d,[r9+0x7]
  4103de:	lea    r9d,[r9-0x2]
  4103e2:	lea    r8d,[r8+0x5]
  4103e6:	shlx   r8,r8,r9
  4103eb:	test   r8,rdx
  4103ee:	je     4103fd <__swc_fn_65555ab2_000068_f3aa21af+0x18d>
  4103f0:	add    ecx,0x1
  4103f3:	cmp    ecx,0x2d
  4103f6:	jb     4103b0 <__swc_fn_65555ab2_000068_f3aa21af+0x140>
  4103f8:	mov    ecx,0xffffffff
  4103fd:	mov    DWORD PTR [rsp+0x8],ecx
  410401:	mov    ecx,DWORD PTR [rsp+0x8]
  410405:	cmp    ecx,0xffffffff
  410408:	je     410410 <__swc_fn_65555ab2_000068_f3aa21af+0x1a0>
  41040a:	cmp    DWORD PTR [rbx+0x58],0x40
  41040e:	jbe    410423 <__swc_fn_65555ab2_000068_f3aa21af+0x1b3>
  410410:	mov    rcx,r12
  410413:	mov    rdx,rbx
  410416:	mov    r8d,DWORD PTR [rax]
  410419:	call   40fd20 <__swc_fn_65555ab2_000065_d9ee99ea>
  41041e:	jmp    4104f7 <__swc_fn_65555ab2_000068_f3aa21af+0x287>
  410423:	lea    rax,[rip+0x11bde]        # 422008 <__swc_data_base_65555ab2+0x8>
  41042a:	mov    rax,QWORD PTR [rax]
  41042d:	cmp    rax,0xffffffffffffffff
  410431:	je     410440 <__swc_fn_65555ab2_000068_f3aa21af+0x1d0>
  410433:	mov    eax,eax
  410435:	mov    edi,eax
  410437:	xor    eax,eax
  410439:	call   407000 <pthread_getspecific@plt>
  41043e:	jmp    410442 <__swc_fn_65555ab2_000068_f3aa21af+0x1d2>
  410440:	xor    eax,eax
  410442:	test   rax,rax
  410445:	jne    410454 <__swc_fn_65555ab2_000068_f3aa21af+0x1e4>
  410447:	call   40f3c0 <__swc_fn_65555ab2_000035_cd1a4e8c>
  41044c:	mov    rcx,rax
  41044f:	call   409fc0 <__swc_fn_65555ab2_000132_5f757033>
  410454:	test   rax,rax
  410457:	je     410464 <__swc_fn_65555ab2_000068_f3aa21af+0x1f4>
  410459:	cmp    QWORD PTR [rax],r12
  41045c:	jne    410464 <__swc_fn_65555ab2_000068_f3aa21af+0x1f4>
  41045e:	cmp    DWORD PTR [rax+0x20],0x0
  410462:	je     41046f <__swc_fn_65555ab2_000068_f3aa21af+0x1ff>
  410464:	mov    rcx,r12
  410467:	mov    rdx,rax
  41046a:	call   407f30 <__swc_fn_65555ab2_000045_d8bd27c3>
  41046f:	test   rax,rax
  410472:	jne    41047e <__swc_fn_65555ab2_000068_f3aa21af+0x20e>
  410474:	mov    QWORD PTR [rbx+0x40],0x0
  41047c:	jmp    4104f7 <__swc_fn_65555ab2_000068_f3aa21af+0x287>
  41047e:	lea    r8,[rsp+0xc]
  410483:	mov    ecx,DWORD PTR [rsp+0x8]
  410487:	mov    DWORD PTR [rsp+0xc],ecx
  41048b:	mov    ecx,DWORD PTR [r8]
  41048e:	lea    rcx,[rcx+rcx*4]
  410492:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  410497:	test   rcx,rcx
  41049a:	je     4104d3 <__swc_fn_65555ab2_000068_f3aa21af+0x263>
  41049c:	mov    rdx,QWORD PTR [rcx]
  41049f:	test   rdx,rdx
  4104a2:	je     4104b0 <__swc_fn_65555ab2_000068_f3aa21af+0x240>
  4104a4:	mov    r9,QWORD PTR [rdx]
  4104a7:	mov    QWORD PTR [rcx],r9
  4104aa:	add    DWORD PTR [rcx+0x28],0x1
  4104ae:	jmp    4104ce <__swc_fn_65555ab2_000068_f3aa21af+0x25e>
  4104b0:	mov    rdx,QWORD PTR [rcx+0x18]
  4104b4:	cmp    QWORD PTR [rcx+0x20],rdx
  4104b8:	jae    4104cc <__swc_fn_65555ab2_000068_f3aa21af+0x25c>
  4104ba:	mov    rdx,QWORD PTR [rcx+0x20]
  4104be:	mov    r9d,DWORD PTR [rcx+0x2c]
  4104c2:	add    QWORD PTR [rcx+0x20],r9
  4104c6:	add    DWORD PTR [rcx+0x28],0x1
  4104ca:	jmp    4104ce <__swc_fn_65555ab2_000068_f3aa21af+0x25e>
  4104cc:	xor    edx,edx
  4104ce:	test   rdx,rdx
  4104d1:	jne    4104e4 <__swc_fn_65555ab2_000068_f3aa21af+0x274>
  4104d3:	mov    rcx,r12
  4104d6:	mov    rdx,rax
  4104d9:	mov    r8d,DWORD PTR [r8]
  4104dc:	call   4080a0 <__swc_fn_65555ab2_000054_faa92dcc>
  4104e1:	mov    rdx,rax
  4104e4:	test   rdx,rdx
  4104e7:	jne    4104f3 <__swc_fn_65555ab2_000068_f3aa21af+0x283>
  4104e9:	mov    QWORD PTR [rbx+0x40],0x0
  4104f1:	jmp    4104f7 <__swc_fn_65555ab2_000068_f3aa21af+0x287>
  4104f3:	mov    QWORD PTR [rbx+0x40],rdx
  4104f7:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4104fd:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  410503:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410509:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41050f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410515:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  41051b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  410521:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  41052a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  410533:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  41053c:	add    rsp,0xb8
  410543:	pop    rsi
  410544:	pop    rdi
  410545:	pop    r12
  410547:	pop    rbx
  410548:	ret
  410549:	add    BYTE PTR [rax],al
  41054b:	add    BYTE PTR [rax],al
  41054d:	add    BYTE PTR [rax],al
	...

0000000000410550 <__swc_fn_65555ab2_000071_b3d7b28e>:
  410550:	ret
	...

0000000000410560 <__swc_fn_65555ab2_000074_042643a3>:
  410560:	push   r12
  410562:	push   r13
  410564:	push   r14
  410566:	push   rdi
  410567:	push   rsi
  410568:	sub    rsp,0x1a0
  41056f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  410578:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  410581:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  41058a:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  410593:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  41059c:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  4105a5:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  4105ae:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  4105b7:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  4105c0:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  4105c9:	mov    r12,rdx
  4105cc:	mov    r13,rcx
  4105cf:	mov    rax,QWORD PTR [r12+0x48]
  4105d4:	mov    ecx,DWORD PTR [r12+0x58]
  4105d9:	lea    rdx,[rax-0x1]
  4105dd:	cmp    rdx,0x10000
  4105e4:	jae    4106de <__swc_fn_65555ab2_000074_042643a3+0x17e>
  4105ea:	cmp    rax,0x8
  4105ee:	ja     4105f5 <__swc_fn_65555ab2_000074_042643a3+0x95>
  4105f0:	xor    r14d,r14d
  4105f3:	jmp    410647 <__swc_fn_65555ab2_000074_042643a3+0xe7>
  4105f5:	cmp    rax,0x80
  4105fc:	ja     410608 <__swc_fn_65555ab2_000074_042643a3+0xa8>
  4105fe:	lea    r14,[rax+0xf]
  410602:	shr    r14,0x4
  410606:	jmp    410647 <__swc_fn_65555ab2_000074_042643a3+0xe7>
  410608:	cmp    rax,0x10000
  41060f:	jbe    410619 <__swc_fn_65555ab2_000074_042643a3+0xb9>
  410611:	mov    r14d,0xffffffff
  410617:	jmp    410647 <__swc_fn_65555ab2_000074_042643a3+0xe7>
  410619:	xor    eax,eax
  41061b:	lzcnt  rax,rdx
  410620:	mov    r8d,0x3f
  410626:	sub    r8d,eax
  410629:	lea    eax,[r8-0x2]
  41062d:	shrx   rax,rdx,rax
  410632:	and    eax,0x3
  410635:	lea    edx,[r8-0x7]
  410639:	lea    edx,[rdx*4+0x0]
  410640:	lea    edx,[rdx+0x9]
  410643:	lea    r14d,[rdx+rax*1]
  410647:	cmp    ecx,0x8
  41064a:	jbe    410663 <__swc_fn_65555ab2_000074_042643a3+0x103>
  41064c:	cmp    ecx,0x10
  41064f:	jne    4106de <__swc_fn_65555ab2_000074_042643a3+0x17e>
  410655:	test   r14d,r14d
  410658:	mov    eax,0x1
  41065d:	cmove  r14d,eax
  410661:	jmp    41066a <__swc_fn_65555ab2_000074_042643a3+0x10a>
  410663:	lea    eax,[rcx-0x1]
  410666:	test   eax,ecx
  410668:	jne    4106de <__swc_fn_65555ab2_000074_042643a3+0x17e>
  41066a:	lea    rax,[rip+0x11997]        # 422008 <__swc_data_base_65555ab2+0x8>
  410671:	mov    rax,QWORD PTR [rax]
  410674:	cmp    rax,0xffffffffffffffff
  410678:	je     410687 <__swc_fn_65555ab2_000074_042643a3+0x127>
  41067a:	mov    eax,eax
  41067c:	mov    edi,eax
  41067e:	xor    eax,eax
  410680:	call   407000 <pthread_getspecific@plt>
  410685:	jmp    410689 <__swc_fn_65555ab2_000074_042643a3+0x129>
  410687:	xor    eax,eax
  410689:	test   rax,rax
  41068c:	je     4106de <__swc_fn_65555ab2_000074_042643a3+0x17e>
  41068e:	cmp    QWORD PTR [rax],r13
  410691:	jne    4106de <__swc_fn_65555ab2_000074_042643a3+0x17e>
  410693:	lea    rcx,[r14+r14*4]
  410697:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  41069c:	test   rax,rax
  41069f:	je     4106de <__swc_fn_65555ab2_000074_042643a3+0x17e>
  4106a1:	mov    rcx,QWORD PTR [rax]
  4106a4:	test   rcx,rcx
  4106a7:	je     4106b5 <__swc_fn_65555ab2_000074_042643a3+0x155>
  4106a9:	mov    rdx,QWORD PTR [rcx]
  4106ac:	mov    QWORD PTR [rax],rdx
  4106af:	add    DWORD PTR [rax+0x28],0x1
  4106b3:	jmp    4106d2 <__swc_fn_65555ab2_000074_042643a3+0x172>
  4106b5:	mov    rcx,QWORD PTR [rax+0x18]
  4106b9:	cmp    QWORD PTR [rax+0x20],rcx
  4106bd:	jae    4106d0 <__swc_fn_65555ab2_000074_042643a3+0x170>
  4106bf:	mov    rcx,QWORD PTR [rax+0x20]
  4106c3:	mov    edx,DWORD PTR [rax+0x2c]
  4106c6:	add    QWORD PTR [rax+0x20],rdx
  4106ca:	add    DWORD PTR [rax+0x28],0x1
  4106ce:	jmp    4106d2 <__swc_fn_65555ab2_000074_042643a3+0x172>
  4106d0:	xor    ecx,ecx
  4106d2:	test   rcx,rcx
  4106d5:	je     4106de <__swc_fn_65555ab2_000074_042643a3+0x17e>
  4106d7:	mov    QWORD PTR [r12+0x40],rcx
  4106dc:	jmp    4106e9 <__swc_fn_65555ab2_000074_042643a3+0x189>
  4106de:	mov    rcx,r13
  4106e1:	mov    rdx,r12
  4106e4:	call   408b20 <__swc_fn_65555ab2_000075_64d36d78>
  4106e9:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  4106f2:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  4106fb:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  410704:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  41070d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  410716:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  41071f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  410728:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  410731:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  41073a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  410743:	add    rsp,0x1a0
  41074a:	pop    rsi
  41074b:	pop    rdi
  41074c:	pop    r14
  41074e:	pop    r13
  410750:	pop    r12
  410752:	ret
	...

0000000000410760 <__swc_fn_65555ab2_000077_7b195156>:
  410760:	push   r12
  410762:	push   r13
  410764:	push   r14
  410766:	push   r15
  410768:	push   rdi
  410769:	push   rsi
  41076a:	sub    rsp,0x188
  410771:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  41077a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  410783:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  41078c:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  410795:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  41079e:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  4107a7:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  4107b0:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  4107b9:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  4107c2:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  4107cb:	mov    r12,rdx
  4107ce:	mov    r13,rcx
  4107d1:	mov    r14,QWORD PTR [r12+0x40]
  4107d6:	lea    rax,[rip+0x1389b]        # 424078 <__swc_bss_base_65555ab2+0x38>
  4107dd:	mov    rcx,r14
  4107e0:	sub    rcx,QWORD PTR [rax+0x8]
  4107e4:	mov    rax,QWORD PTR [rip+0x1389d]        # 424088 <__swc_bss_base_65555ab2+0x48>
  4107eb:	cmp    rcx,rax
  4107ee:	jae    41081a <__swc_fn_65555ab2_000077_7b195156+0xba>
  4107f0:	mov    rax,r14
  4107f3:	and    rax,0xffffffffffc00000
  4107fa:	mov    rcx,r14
  4107fd:	shr    rcx,0x10
  410801:	and    ecx,0x3f
  410804:	mov    edx,DWORD PTR [rax+0x28]
  410807:	shrx   ecx,ecx,edx
  41080c:	shl    rcx,0x4
  410810:	lea    r15,[rax+rcx*8+0x80]
  410818:	jmp    410825 <__swc_fn_65555ab2_000077_7b195156+0xc5>
  41081a:	mov    rcx,r14
  41081d:	call   40f2f0 <__swc_fn_65555ab2_000026_bcdc5519>
  410822:	mov    r15,rax
  410825:	test   r15,r15
  410828:	je     4108cf <__swc_fn_65555ab2_000077_7b195156+0x16f>
  41082e:	lea    rax,[rip+0x117d3]        # 422008 <__swc_data_base_65555ab2+0x8>
  410835:	mov    rax,QWORD PTR [rax]
  410838:	cmp    rax,0xffffffffffffffff
  41083c:	je     41084b <__swc_fn_65555ab2_000077_7b195156+0xeb>
  41083e:	mov    eax,eax
  410840:	mov    edi,eax
  410842:	xor    eax,eax
  410844:	call   407000 <pthread_getspecific@plt>
  410849:	jmp    41084d <__swc_fn_65555ab2_000077_7b195156+0xed>
  41084b:	xor    eax,eax
  41084d:	mov    rcx,QWORD PTR [r15+0x40]
  410851:	cmp    rcx,rax
  410854:	jne    4108b4 <__swc_fn_65555ab2_000077_7b195156+0x154>
  410856:	test   rax,rax
  410859:	je     4108cf <__swc_fn_65555ab2_000077_7b195156+0x16f>
  41085b:	mov    ecx,DWORD PTR [r15+0x6c]
  41085f:	test   ecx,ecx
  410861:	je     410881 <__swc_fn_65555ab2_000077_7b195156+0x121>
  410863:	mov    rcx,r13
  410866:	mov    rdx,rax
  410869:	mov    r8,r15
  41086c:	mov    QWORD PTR [rsp+0xd8],rax
  410874:	call   408030 <__swc_fn_65555ab2_000051_e072b516>
  410879:	mov    rax,QWORD PTR [rsp+0xd8]
  410881:	mov    rcx,QWORD PTR [r15]
  410884:	mov    QWORD PTR [r14],rcx
  410887:	mov    QWORD PTR [r15],r14
  41088a:	sub    DWORD PTR [r15+0x28],0x1
  41088f:	jne    4108c4 <__swc_fn_65555ab2_000077_7b195156+0x164>
  410891:	movzx  ecx,BYTE PTR [r15+0x39]
  410896:	lea    rcx,[rcx+rcx*4]
  41089a:	lea    rcx,[rax+rcx*8+0x28]
  41089f:	cmp    QWORD PTR [rcx],r15
  4108a2:	je     4108c4 <__swc_fn_65555ab2_000077_7b195156+0x164>
  4108a4:	mov    rcx,r13
  4108a7:	mov    rdx,rax
  4108aa:	mov    r8,r15
  4108ad:	call   40c760 <__swc_fn_65555ab2_000055_2e3450f7>
  4108b2:	jmp    4108c4 <__swc_fn_65555ab2_000077_7b195156+0x164>
  4108b4:	test   rcx,rcx
  4108b7:	je     4108cf <__swc_fn_65555ab2_000077_7b195156+0x16f>
  4108b9:	mov    rcx,r15
  4108bc:	mov    rdx,r14
  4108bf:	call   40ef30 <__swc_fn_65555ab2_000014_524c1f23>
  4108c4:	mov    QWORD PTR [r12+0x40],0x0
  4108cd:	jmp    4108da <__swc_fn_65555ab2_000077_7b195156+0x17a>
  4108cf:	mov    rcx,r13
  4108d2:	mov    rdx,r12
  4108d5:	call   408b40 <__swc_fn_65555ab2_000078_1966ae2e>
  4108da:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  4108e3:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  4108ec:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  4108f5:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  4108fe:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  410907:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  410910:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  410919:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  410922:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  41092b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  410934:	add    rsp,0x188
  41093b:	pop    rsi
  41093c:	pop    rdi
  41093d:	pop    r15
  41093f:	pop    r14
  410941:	pop    r13
  410943:	pop    r12
  410945:	ret
	...

0000000000410950 <__swc_fn_65555ab2_000080_d2cd17e2>:
  410950:	sub    rsp,0x8
  410954:	mov    rax,rdx
  410957:	mov    rdx,QWORD PTR [rax+0x40]
  41095b:	mov    r8,rax
  41095e:	call   410550 <__swc_fn_65555ab2_000071_b3d7b28e>
  410963:	add    rsp,0x8
  410967:	ret
	...

0000000000410970 <__swc_fn_65555ab2_000083_4a10c7e7>:
  410970:	push   rsi
  410971:	push   rdi
  410972:	sub    rsp,0x8
  410976:	cmp    rcx,0xffffffffffffffef
  41097a:	ja     4109a0 <__swc_fn_65555ab2_000083_4a10c7e7+0x30>
  41097c:	xor    esi,esi
  41097e:	lea    rax,[rcx+0x100f]
  410985:	and    rax,0xfffffffffffff000
  41098c:	lea    rcx,[rcx+0x10]
  410990:	cmp    rcx,0xfffffffffffff000
  410997:	cmovbe rsi,rax
  41099b:	test   rsi,rsi
  41099e:	jne    4109a9 <__swc_fn_65555ab2_000083_4a10c7e7+0x39>
  4109a0:	xor    eax,eax
  4109a2:	add    rsp,0x8
  4109a6:	pop    rdi
  4109a7:	pop    rsi
  4109a8:	ret
  4109a9:	mov    rcx,rsi
  4109ac:	call   411000 <__swc_fn_65555ab2_000113_6b799b8d>
  4109b1:	mov    rdi,rax
  4109b4:	test   rax,rax
  4109b7:	jne    4109c2 <__swc_fn_65555ab2_000083_4a10c7e7+0x52>
  4109b9:	xor    eax,eax
  4109bb:	add    rsp,0x8
  4109bf:	pop    rdi
  4109c0:	pop    rsi
  4109c1:	ret
  4109c2:	mov    rcx,rdi
  4109c5:	mov    rdx,rsi
  4109c8:	call   40dc20 <__swc_fn_65555ab2_000115_36905703>
  4109cd:	test   al,al
  4109cf:	jne    4109e5 <__swc_fn_65555ab2_000083_4a10c7e7+0x75>
  4109d1:	mov    rcx,rdi
  4109d4:	mov    rdx,rsi
  4109d7:	call   409c70 <__swc_fn_65555ab2_000117_ed2d8fed>
  4109dc:	xor    eax,eax
  4109de:	add    rsp,0x8
  4109e2:	pop    rdi
  4109e3:	pop    rsi
  4109e4:	ret
  4109e5:	mov    QWORD PTR [rdi],rsi
  4109e8:	mov    QWORD PTR [rdi+0x8],0x0
  4109f0:	lea    rax,[rdi+0x10]
  4109f4:	add    rsp,0x8
  4109f8:	pop    rdi
  4109f9:	pop    rsi
  4109fa:	ret
  4109fb:	add    BYTE PTR [rax],al
  4109fd:	add    BYTE PTR [rax],al
	...

0000000000410a00 <__swc_fn_65555ab2_000086_3953ef98>:
  410a00:	sub    rsp,0x8
  410a04:	cmp    BYTE PTR [rcx+0x2c],0x10
  410a08:	jne    410a13 <__swc_fn_65555ab2_000086_3953ef98+0x13>
  410a0a:	test   DWORD PTR [rcx+0x28],0x80
  410a11:	je     410a1b <__swc_fn_65555ab2_000086_3953ef98+0x1b>
  410a13:	mov    rax,rcx
  410a16:	add    rsp,0x8
  410a1a:	ret
  410a1b:	mov    rcx,QWORD PTR [rcx+0x40]
  410a1f:	call   410a00 <__swc_fn_65555ab2_000086_3953ef98>
  410a24:	add    rsp,0x8
  410a28:	ret
	...

0000000000410a40 <__swc_fn_65555ab2_000089_d182c4dc>:
  410a40:	push   rsi
  410a41:	push   rdi
  410a42:	push   r12
  410a44:	push   r13
  410a46:	sub    rsp,0x8
  410a4a:	mov    rsi,rdx
  410a4d:	mov    rdi,rcx
  410a50:	xor    r8d,r8d
  410a53:	call   40cf80 <__swc_fn_65555ab2_000094_63c1827b>
  410a58:	test   al,al
  410a5a:	je     410a6c <__swc_fn_65555ab2_000089_d182c4dc+0x2c>
  410a5c:	mov    eax,0x1
  410a61:	add    rsp,0x8
  410a65:	pop    r13
  410a67:	pop    r12
  410a69:	pop    rdi
  410a6a:	pop    rsi
  410a6b:	ret
  410a6c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  410a71:	je     410a80 <__swc_fn_65555ab2_000089_d182c4dc+0x40>
  410a73:	xor    eax,eax
  410a75:	add    rsp,0x8
  410a79:	pop    r13
  410a7b:	pop    r12
  410a7d:	pop    rdi
  410a7e:	pop    rsi
  410a7f:	ret
  410a80:	mov    r12,QWORD PTR [rsi+0x98]
  410a87:	mov    rax,QWORD PTR [rsi+0xa0]
  410a8e:	mov    rsi,rax
  410a91:	xor    r13d,r13d
  410a94:	test   rsi,rsi
  410a97:	je     410af4 <__swc_fn_65555ab2_000089_d182c4dc+0xb4>
  410a99:	cs nop WORD PTR [rax+rax*1+0x0]
  410aa3:	cs nop WORD PTR [rax+rax*1+0x0]
  410aad:	nop    DWORD PTR [rax]
  410ab0:	lea    rax,[r13*8+0x0]
  410ab8:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  410abd:	mov    rcx,rax
  410ac0:	call   410a00 <__swc_fn_65555ab2_000086_3953ef98>
  410ac5:	cmp    BYTE PTR [rax+0x2c],0xe
  410ac9:	jne    410aea <__swc_fn_65555ab2_000089_d182c4dc+0xaa>
  410acb:	mov    rcx,rdi
  410ace:	mov    rdx,rax
  410ad1:	call   410a40 <__swc_fn_65555ab2_000089_d182c4dc>
  410ad6:	test   al,al
  410ad8:	je     410aea <__swc_fn_65555ab2_000089_d182c4dc+0xaa>
  410ada:	mov    eax,0x1
  410adf:	add    rsp,0x8
  410ae3:	pop    r13
  410ae5:	pop    r12
  410ae7:	pop    rdi
  410ae8:	pop    rsi
  410ae9:	ret
  410aea:	add    r13,0x1
  410aee:	sub    rsi,0x1
  410af2:	jne    410ab0 <__swc_fn_65555ab2_000089_d182c4dc+0x70>
  410af4:	xor    eax,eax
  410af6:	add    rsp,0x8
  410afa:	pop    r13
  410afc:	pop    r12
  410afe:	pop    rdi
  410aff:	pop    rsi
  410b00:	ret
	...

0000000000410b10 <__swc_fn_65555ab2_000092_14c65203>:
  410b10:	sub    rsp,0x18
  410b14:	vxorps xmm0,xmm0,xmm0
  410b18:	vmovdqu XMMWORD PTR [rsp],xmm0
  410b1d:	call   408d50 <__swc_fn_65555ab2_000093_c2567a3b>
  410b22:	add    rsp,0x18
  410b26:	ret
	...

0000000000410b30 <__swc_fn_65555ab2_000095_ad13d15c>:
  410b30:	sub    rsp,0x8
  410b34:	mov    rcx,QWORD PTR [rip+0x13505]        # 424040 <__swc_bss_base_65555ab2>
  410b3b:	test   rcx,rcx
  410b3e:	jne    410b50 <__swc_fn_65555ab2_000095_ad13d15c+0x20>
  410b40:	call   40eb80 <__swc_fn_65555ab2_000169_994c8876>
  410b45:	lea    rcx,[rax+0x1]
  410b49:	mov    QWORD PTR [rip+0x134f0],rcx        # 424040 <__swc_bss_base_65555ab2>
  410b50:	dec    rcx
  410b53:	call   40ba40 <__swc_fn_65555ab2_000171_360af05d>
  410b58:	mov    rax,QWORD PTR [rax+0xc0]
  410b5f:	and    eax,0x1
  410b62:	setne  al
  410b65:	add    rsp,0x8
  410b69:	ret
	...

0000000000410b80 <__swc_fn_65555ab2_000098_4f209617>:
  410b80:	push   rbx
  410b81:	push   rsi
  410b82:	push   rdi
  410b83:	push   r12
  410b85:	sub    rsp,0x28
  410b89:	mov    rbx,rcx
  410b8c:	call   40d2e0 <__swc_fn_65555ab2_000097_4185993f>
  410b91:	mov    rcx,QWORD PTR [rip+0x134a8]        # 424040 <__swc_bss_base_65555ab2>
  410b98:	test   rcx,rcx
  410b9b:	jne    410bad <__swc_fn_65555ab2_000098_4f209617+0x2d>
  410b9d:	call   40eb80 <__swc_fn_65555ab2_000169_994c8876>
  410ba2:	lea    rcx,[rax+0x1]
  410ba6:	mov    QWORD PTR [rip+0x13493],rcx        # 424040 <__swc_bss_base_65555ab2>
  410bad:	dec    rcx
  410bb0:	call   40ba40 <__swc_fn_65555ab2_000171_360af05d>
  410bb5:	mov    rsi,rax
  410bb8:	lea    rcx,[rsp+0x8]
  410bbd:	call   409190 <__swc_fn_65555ab2_000096_93bfe675>
  410bc2:	mov    rdi,QWORD PTR [rsi+0x9c0]
  410bc9:	mov    r12,QWORD PTR [rsi+0xbe8]
  410bd0:	lea    rcx,[rsi+0x10]
  410bd4:	call   411b50 <__swc_fn_65555ab2_000161_13ead2ff>
  410bd9:	mov    rcx,rsi
  410bdc:	call   409300 <__swc_fn_65555ab2_000105_5a85fcf5>
  410be1:	vxorps xmm0,xmm0,xmm0
  410be5:	xor    eax,eax
  410be7:	cs nop WORD PTR [rax+rax*1+0x0]
  410bf1:	cs nop WORD PTR [rax+rax*1+0x0]
  410bfb:	nop    DWORD PTR [rax+rax*1+0x0]
  410c00:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  410c05:	add    rax,0x10
  410c09:	cmp    rax,0xbf0
  410c10:	jne    410c00 <__swc_fn_65555ab2_000098_4f209617+0x80>
  410c12:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  410c18:	vmovups XMMWORD PTR [rsi],xmm0
  410c1c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  410c22:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  410c2a:	mov    QWORD PTR [rsi+0x9c0],rdi
  410c31:	mov    QWORD PTR [rsi+0xbe8],r12
  410c38:	mov    rcx,QWORD PTR [rip+0x13401]        # 424040 <__swc_bss_base_65555ab2>
  410c3f:	test   rcx,rcx
  410c42:	jne    410c54 <__swc_fn_65555ab2_000098_4f209617+0xd4>
  410c44:	call   40eb80 <__swc_fn_65555ab2_000169_994c8876>
  410c49:	lea    rcx,[rax+0x1]
  410c4d:	mov    QWORD PTR [rip+0x133ec],rcx        # 424040 <__swc_bss_base_65555ab2>
  410c54:	dec    rcx
  410c57:	call   40ba40 <__swc_fn_65555ab2_000171_360af05d>
  410c5c:	mov    rsi,rax
  410c5f:	mov    QWORD PTR [rsi+0xc0],rbx
  410c66:	and    ebx,0x1
  410c69:	jne    410c6d <__swc_fn_65555ab2_000098_4f209617+0xed>
  410c6b:	xor    eax,eax
  410c6d:	test   rbx,rbx
  410c70:	sete   al
  410c73:	xor    cl,cl
  410c75:	xor    dl,dl
  410c77:	xor    r8b,r8b
  410c7a:	xor    r9b,r9b
  410c7d:	xor    r10b,r10b
  410c80:	mov    r11,rax
  410c83:	call   408b50 <__swc_fn_65555ab2_000081_5cc7acfc>
  410c88:	lea    rbx,[rsp+0x18]
  410c8d:	mov    rcx,rbx
  410c90:	call   409190 <__swc_fn_65555ab2_000096_93bfe675>
  410c95:	lea    rcx,[rsi+0x10]
  410c99:	mov    edx,0x400000
  410c9e:	mov    r8,rbx
  410ca1:	call   40e8c0 <__swc_fn_65555ab2_000163_8a3d304f>
  410ca6:	lea    rcx,[rsi+0x68]
  410caa:	mov    edx,0x4000
  410caf:	mov    r8,rbx
  410cb2:	call   40e8c0 <__swc_fn_65555ab2_000163_8a3d304f>
  410cb7:	add    rsp,0x28
  410cbb:	pop    r12
  410cbd:	pop    rdi
  410cbe:	pop    rsi
  410cbf:	pop    rbx
  410cc0:	ret
	...

0000000000410cd0 <__swc_fn_65555ab2_000101_d0b19c14>:
  410cd0:	push   rbx
  410cd1:	push   rsi
  410cd2:	sub    rsp,0x18
  410cd6:	mov    rbx,rcx
  410cd9:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  410cde:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410ce4:	mov    rsi,QWORD PTR [rbx+0x70]
  410ce8:	lea    rcx,[rcx+0x18]
  410cec:	call   411b50 <__swc_fn_65555ab2_000161_13ead2ff>
  410cf1:	lea    rcx,[rsp+0x8]
  410cf6:	mov    rdx,rbx
  410cf9:	mov    r8d,0x78
  410cff:	call   40d340 <__swc_fn_65555ab2_000100_d4bdcaa4>
  410d04:	mov    rax,rsi
  410d07:	add    rsp,0x18
  410d0b:	pop    rsi
  410d0c:	pop    rbx
  410d0d:	ret
	...

0000000000410d10 <__swc_fn_65555ab2_000104_3c3b96fb>:
  410d10:	push   rsi
  410d11:	push   rdi
  410d12:	sub    rsp,0x8
  410d16:	cmp    QWORD PTR [rcx],0x0
  410d1a:	jne    410d23 <__swc_fn_65555ab2_000104_3c3b96fb+0x13>
  410d1c:	add    rsp,0x8
  410d20:	pop    rdi
  410d21:	pop    rsi
  410d22:	ret
  410d23:	mov    rsi,QWORD PTR [rcx]
  410d26:	mov    rax,QWORD PTR [rcx+0x8]
  410d2a:	test   rax,rax
  410d2d:	je     410d43 <__swc_fn_65555ab2_000104_3c3b96fb+0x33>
  410d2f:	test   DWORD PTR [rax+0x28],0x400000
  410d36:	je     410d43 <__swc_fn_65555ab2_000104_3c3b96fb+0x33>
  410d38:	mov    rcx,QWORD PTR [rax+0x30]
  410d3c:	test   rcx,rcx
  410d3f:	cmovne rax,rcx
  410d43:	lea    rdx,[rip+0x27ae]        # 4134f8 <__swc_rdata_base_65555ab2+0x3e8>
  410d4a:	lea    rcx,[rip+0x288f]        # 4135e0 <__swc_rdata_base_65555ab2+0x4d0>
  410d51:	mov    r8,rax
  410d54:	xor    r9d,r9d
  410d57:	xor    al,al
  410d59:	mov    r10,rax
  410d5c:	xor    r11d,r11d
  410d5f:	call   410b10 <__swc_fn_65555ab2_000092_14c65203>
  410d64:	test   rax,rax
  410d67:	je     410d77 <__swc_fn_65555ab2_000104_3c3b96fb+0x67>
  410d69:	mov    rdi,QWORD PTR [rax+0x48]
  410d6d:	test   rdi,rdi
  410d70:	je     410d77 <__swc_fn_65555ab2_000104_3c3b96fb+0x67>
  410d72:	mov    rcx,rsi
  410d75:	call   rdi
  410d77:	add    rsp,0x8
  410d7b:	pop    rdi
  410d7c:	pop    rsi
  410d7d:	ret
	...

0000000000410d80 <__swc_fn_65555ab2_000107_90faaa26>:
  410d80:	push   rbx
  410d81:	push   rsi
  410d82:	push   rdi
  410d83:	sub    rsp,0x20
  410d87:	mov    rbx,rdx
  410d8a:	mov    rsi,rcx
  410d8d:	mov    rcx,QWORD PTR [rip+0x132ac]        # 424040 <__swc_bss_base_65555ab2>
  410d94:	test   rcx,rcx
  410d97:	jne    410da9 <__swc_fn_65555ab2_000107_90faaa26+0x29>
  410d99:	call   40eb80 <__swc_fn_65555ab2_000169_994c8876>
  410d9e:	lea    rcx,[rax+0x1]
  410da2:	mov    QWORD PTR [rip+0x13297],rcx        # 424040 <__swc_bss_base_65555ab2>
  410da9:	dec    rcx
  410dac:	call   40ba40 <__swc_fn_65555ab2_000171_360af05d>
  410db1:	mov    rdi,rax
  410db4:	mov    rax,QWORD PTR [rdi+0xbd0]
  410dbb:	xor    ecx,ecx
  410dbd:	test   rax,rax
  410dc0:	je     410dc5 <__swc_fn_65555ab2_000107_90faaa26+0x45>
  410dc2:	mov    rcx,QWORD PTR [rax]
  410dc5:	call   40ecb0 <__swc_fn_65555ab2_000178_718d7b54>
  410dca:	lea    rax,[rsp+0x8]
  410dcf:	lea    rcx,[rdi+0x9c8]
  410dd6:	mov    QWORD PTR [rsp+0x8],rcx
  410ddb:	mov    QWORD PTR [rax+0x8],0x40
  410de3:	xor    ecx,ecx
  410de5:	mov    rdx,rax
  410de8:	call   409da0 <__swc_fn_65555ab2_000123_4f256d58>
  410ded:	mov    DWORD PTR [rdi+0xbc8],eax
  410df3:	mov    rdi,QWORD PTR [rdi+0x990]
  410dfa:	test   rdi,rdi
  410dfd:	je     410e07 <__swc_fn_65555ab2_000107_90faaa26+0x87>
  410dff:	mov    rcx,rsi
  410e02:	mov    rdx,rbx
  410e05:	call   rdi
  410e07:	call   410b30 <__swc_fn_65555ab2_000095_ad13d15c>
  410e0c:	test   al,al
  410e0e:	je     410e1e <__swc_fn_65555ab2_000107_90faaa26+0x9e>
  410e10:	mov    rcx,rsi
  410e13:	mov    rdx,rbx
  410e16:	xor    r8d,r8d
  410e19:	call   40ddc0 <__swc_fn_65555ab2_000124_83db7238>
  410e1e:	mov    rcx,rsi
  410e21:	mov    rdx,rbx
  410e24:	call   40d440 <__swc_fn_65555ab2_000106_ffe51047>
  410e29:	call   4113b0 <__swc_fn_65555ab2_000122_be2e2f68>
  410e2e:	add    rsp,0x20
  410e32:	pop    rdi
  410e33:	pop    rsi
  410e34:	pop    rbx
  410e35:	ret
	...

0000000000410e40 <__swc_fn_65555ab2_000110_3dc01326>:
  410e40:	test   r8,r8
  410e43:	jne    410e48 <__swc_fn_65555ab2_000110_3dc01326+0x8>
  410e45:	xor    eax,eax
  410e47:	ret
  410e48:	xor    eax,eax
  410e4a:	nop    WORD PTR [rax+rax*1+0x0]
  410e50:	mov    r9,r8
  410e53:	sub    r9,rax
  410e56:	cmp    r9,0x10
  410e5a:	jb     410ea4 <__swc_fn_65555ab2_000110_3dc01326+0x64>
  410e5c:	lea    r9,[rcx+rax*1]
  410e60:	lea    r10,[rdx+rax*1]
  410e64:	vmovups xmm0,XMMWORD PTR [r10]
  410e69:	vmovups xmm1,XMMWORD PTR [r9]
  410e6e:	vpcmpeqb xmm0,xmm1,xmm0
  410e72:	vpmovmskb r9d,xmm0
  410e76:	cmp    r9d,0xffff
  410e7d:	je     410e9e <__swc_fn_65555ab2_000110_3dc01326+0x5e>
  410e7f:	not    r9d
  410e82:	xor    r8d,r8d
  410e85:	movzx  r9d,r9w
  410e89:	tzcnt  r8d,r9d
  410e8e:	add    rax,r8
  410e91:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410e95:	movzx  eax,BYTE PTR [rdx+rax*1]
  410e99:	sub    ecx,eax
  410e9b:	mov    eax,ecx
  410e9d:	ret
  410e9e:	lea    rax,[rax+0x10]
  410ea2:	jmp    410e50 <__swc_fn_65555ab2_000110_3dc01326+0x10>
  410ea4:	cmp    r9,0x8
  410ea8:	jb     410f1b <__swc_fn_65555ab2_000110_3dc01326+0xdb>
  410eaa:	lea    r9,[rcx+rax*1]
  410eae:	lea    r10,[rdx+rax*1]
  410eb2:	mov    r9,QWORD PTR [r9]
  410eb5:	xor    r9,QWORD PTR [r10]
  410eb8:	test   r9,r9
  410ebb:	je     410ed9 <__swc_fn_65555ab2_000110_3dc01326+0x99>
  410ebd:	xor    r8d,r8d
  410ec0:	tzcnt  r8,r9
  410ec5:	shr    r8,0x3
  410ec9:	add    rax,r8
  410ecc:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410ed0:	movzx  eax,BYTE PTR [rdx+rax*1]
  410ed4:	sub    ecx,eax
  410ed6:	mov    eax,ecx
  410ed8:	ret
  410ed9:	lea    rax,[rax+0x8]
  410edd:	cmp    rax,r8
  410ee0:	jne    410ee5 <__swc_fn_65555ab2_000110_3dc01326+0xa5>
  410ee2:	xor    eax,eax
  410ee4:	ret
  410ee5:	lea    rax,[r8-0x8]
  410ee9:	lea    r8,[rcx+rax*1]
  410eed:	lea    r9,[rdx+rax*1]
  410ef1:	mov    r8,QWORD PTR [r8]
  410ef4:	xor    r8,QWORD PTR [r9]
  410ef7:	test   r8,r8
  410efa:	je     410f18 <__swc_fn_65555ab2_000110_3dc01326+0xd8>
  410efc:	xor    r9d,r9d
  410eff:	tzcnt  r9,r8
  410f04:	shr    r9,0x3
  410f08:	add    rax,r9
  410f0b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410f0f:	movzx  eax,BYTE PTR [rdx+rax*1]
  410f13:	sub    ecx,eax
  410f15:	mov    eax,ecx
  410f17:	ret
  410f18:	xor    eax,eax
  410f1a:	ret
  410f1b:	cmp    r9,0x4
  410f1f:	jb     410f92 <__swc_fn_65555ab2_000110_3dc01326+0x152>
  410f21:	lea    r9,[rcx+rax*1]
  410f25:	lea    r10,[rdx+rax*1]
  410f29:	mov    r9d,DWORD PTR [r9]
  410f2c:	xor    r9d,DWORD PTR [r10]
  410f2f:	test   r9d,r9d
  410f32:	je     410f50 <__swc_fn_65555ab2_000110_3dc01326+0x110>
  410f34:	xor    r8d,r8d
  410f37:	tzcnt  r8,r9
  410f3c:	shr    r8,0x3
  410f40:	add    rax,r8
  410f43:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410f47:	movzx  eax,BYTE PTR [rdx+rax*1]
  410f4b:	sub    ecx,eax
  410f4d:	mov    eax,ecx
  410f4f:	ret
  410f50:	lea    rax,[rax+0x4]
  410f54:	cmp    rax,r8
  410f57:	jne    410f5c <__swc_fn_65555ab2_000110_3dc01326+0x11c>
  410f59:	xor    eax,eax
  410f5b:	ret
  410f5c:	lea    rax,[r8-0x4]
  410f60:	lea    r8,[rcx+rax*1]
  410f64:	lea    r9,[rdx+rax*1]
  410f68:	mov    r8d,DWORD PTR [r8]
  410f6b:	xor    r8d,DWORD PTR [r9]
  410f6e:	test   r8d,r8d
  410f71:	je     410f8f <__swc_fn_65555ab2_000110_3dc01326+0x14f>
  410f73:	xor    r9d,r9d
  410f76:	tzcnt  r9,r8
  410f7b:	shr    r9,0x3
  410f7f:	add    rax,r9
  410f82:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410f86:	movzx  eax,BYTE PTR [rdx+rax*1]
  410f8a:	sub    ecx,eax
  410f8c:	mov    eax,ecx
  410f8e:	ret
  410f8f:	xor    eax,eax
  410f91:	ret
  410f92:	cmp    r9,0x2
  410f96:	jb     410fe9 <__swc_fn_65555ab2_000110_3dc01326+0x1a9>
  410f98:	lea    r9,[rcx+rax*1]
  410f9c:	lea    r10,[rdx+rax*1]
  410fa0:	mov    r9w,WORD PTR [r9]
  410fa4:	xor    r9w,WORD PTR [r10]
  410fa8:	test   r9w,r9w
  410fac:	je     410fce <__swc_fn_65555ab2_000110_3dc01326+0x18e>
  410fae:	xor    r8d,r8d
  410fb1:	movzx  r9d,r9w
  410fb5:	tzcnt  r8,r9
  410fba:	shr    r8,0x3
  410fbe:	add    rax,r8
  410fc1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410fc5:	movzx  eax,BYTE PTR [rdx+rax*1]
  410fc9:	sub    ecx,eax
  410fcb:	mov    eax,ecx
  410fcd:	ret
  410fce:	lea    rax,[rax+0x2]
  410fd2:	cmp    rax,r8
  410fd5:	jne    410fda <__swc_fn_65555ab2_000110_3dc01326+0x19a>
  410fd7:	xor    eax,eax
  410fd9:	ret
  410fda:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  410fe0:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  410fe6:	sub    eax,ecx
  410fe8:	ret
  410fe9:	test   r9,r9
  410fec:	je     410ffb <__swc_fn_65555ab2_000110_3dc01326+0x1bb>
  410fee:	movzx  ecx,BYTE PTR [rcx+rax*1]
  410ff2:	movzx  eax,BYTE PTR [rdx+rax*1]
  410ff6:	sub    ecx,eax
  410ff8:	mov    eax,ecx
  410ffa:	ret
  410ffb:	xor    eax,eax
  410ffd:	ret
	...

0000000000411000 <__swc_fn_65555ab2_000113_6b799b8d>:
  411000:	push   r12
  411002:	push   r13
  411004:	push   r14
  411006:	push   rdi
  411007:	push   rsi
  411008:	push   r15
  41100a:	sub    rsp,0xd8
  411011:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  411017:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  41101d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  411023:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  411029:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  41102f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  411038:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  411041:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  41104a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  411053:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  41105c:	mov    r12,rcx
  41105f:	test   rcx,rcx
  411062:	je     41107e <__swc_fn_65555ab2_000113_6b799b8d+0x7e>
  411064:	mov    eax,r12d
  411067:	and    eax,0xfff
  41106d:	setne  al
  411070:	cmp    r12,0xffffffffffffefff
  411077:	seta   cl
  41107a:	or     al,cl
  41107c:	je     411085 <__swc_fn_65555ab2_000113_6b799b8d+0x85>
  41107e:	xor    eax,eax
  411080:	jmp    41111b <__swc_fn_65555ab2_000113_6b799b8d+0x11b>
  411085:	call   40dae0 <__swc_fn_65555ab2_000112_126150d1>
  41108a:	mov    r13,rax
  41108d:	test   rax,rax
  411090:	jne    411099 <__swc_fn_65555ab2_000113_6b799b8d+0x99>
  411092:	xor    eax,eax
  411094:	jmp    41111b <__swc_fn_65555ab2_000113_6b799b8d+0x11b>
  411099:	lea    r14,[r12+0x1000]
  4110a1:	xor    edi,edi
  4110a3:	mov    rsi,r14
  4110a6:	xor    edx,edx
  4110a8:	mov    ecx,0x22
  4110ad:	mov    eax,0xffffffff
  4110b2:	movsxd r8,eax
  4110b5:	xor    r9d,r9d
  4110b8:	xor    eax,eax
  4110ba:	call   4070d0 <mmap@plt>
  4110bf:	mov    r15,rax
  4110c2:	cmp    rax,0xffffffffffffffff
  4110c6:	jne    4110cc <__swc_fn_65555ab2_000113_6b799b8d+0xcc>
  4110c8:	xor    eax,eax
  4110ca:	jmp    41111b <__swc_fn_65555ab2_000113_6b799b8d+0x11b>
  4110cc:	mov    rdi,r15
  4110cf:	mov    esi,0x1000
  4110d4:	mov    edx,0x3
  4110d9:	xor    eax,eax
  4110db:	call   407170 <mprotect@plt>
  4110e0:	test   eax,eax
  4110e2:	je     4110f5 <__swc_fn_65555ab2_000113_6b799b8d+0xf5>
  4110e4:	mov    rdi,r15
  4110e7:	mov    rsi,r14
  4110ea:	xor    eax,eax
  4110ec:	call   407160 <munmap@plt>
  4110f1:	xor    eax,eax
  4110f3:	jmp    41111b <__swc_fn_65555ab2_000113_6b799b8d+0x11b>
  4110f5:	mov    QWORD PTR [r15+0x8],r12
  4110f9:	mov    rcx,r13
  4110fc:	call   411750 <__swc_fn_65555ab2_000137_8c07c14b>
  411101:	mov    rax,QWORD PTR [r13+0x8]
  411105:	mov    QWORD PTR [r15],rax
  411108:	mov    QWORD PTR [r13+0x8],r15
  41110c:	mov    rcx,r13
  41110f:	call   40a140 <__swc_fn_65555ab2_000138_715e84ff>
  411114:	lea    rax,[r15+0x1000]
  41111b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  411121:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  411127:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  41112d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  411133:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  411139:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  411142:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  41114b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  411154:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  41115d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  411166:	add    rsp,0xd8
  41116d:	pop    r15
  41116f:	pop    rsi
  411170:	pop    rdi
  411171:	pop    r14
  411173:	pop    r13
  411175:	pop    r12
  411177:	ret
	...

0000000000411180 <__swc_fn_65555ab2_000116_e9fc0224>:
  411180:	push   rbx
  411181:	push   r12
  411183:	push   rdi
  411184:	push   rsi
  411185:	sub    rsp,0xa8
  41118c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  411192:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411198:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41119e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4111a4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4111aa:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4111b0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4111b6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4111bc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4111c5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4111ce:	mov    rbx,rdx
  4111d1:	mov    r12,rcx
  4111d4:	mov    rdi,rcx
  4111d7:	mov    rsi,rdx
  4111da:	xor    edx,edx
  4111dc:	xor    eax,eax
  4111de:	call   407170 <mprotect@plt>
  4111e3:	test   eax,eax
  4111e5:	jne    411209 <__swc_fn_65555ab2_000116_e9fc0224+0x89>
  4111e7:	mov    rcx,r12
  4111ea:	mov    rdx,rbx
  4111ed:	xor    al,al
  4111ef:	mov    r8,rax
  4111f2:	call   409be0 <__swc_fn_65555ab2_000114_5f48311c>
  4111f7:	mov    rdi,r12
  4111fa:	mov    rsi,rbx
  4111fd:	mov    edx,0x4
  411202:	xor    eax,eax
  411204:	call   4071d0 <madvise@plt>
  411209:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41120f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411215:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41121b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411221:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411227:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  41122d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411233:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411239:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411242:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41124b:	add    rsp,0xa8
  411252:	pop    rsi
  411253:	pop    rdi
  411254:	pop    r12
  411256:	pop    rbx
  411257:	ret
	...

0000000000411260 <__swc_fn_65555ab2_000119_d3318640>:
  411260:	push   rsi
  411261:	push   rdi
  411262:	push   r12
  411264:	push   r13
  411266:	push   r14
  411268:	sub    rsp,0xe0
  41126f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  411275:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  41127b:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  411281:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  411287:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  41128d:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  411296:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  41129f:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  4112a8:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  4112b1:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  4112ba:	mov    rsi,rdx
  4112bd:	mov    rdi,rcx
  4112c0:	call   40dae0 <__swc_fn_65555ab2_000112_126150d1>
  4112c5:	mov    r12,rax
  4112c8:	test   rax,rax
  4112cb:	jne    4112d2 <__swc_fn_65555ab2_000119_d3318640+0x72>
  4112cd:	jmp    411346 <__swc_fn_65555ab2_000119_d3318640+0xe6>
  4112d2:	mov    rcx,r12
  4112d5:	call   411750 <__swc_fn_65555ab2_000137_8c07c14b>
  4112da:	lea    r13,[r12+0x8]
  4112df:	mov    rax,QWORD PTR [r13+0x0]
  4112e3:	test   rax,rax
  4112e6:	je     41133e <__swc_fn_65555ab2_000119_d3318640+0xde>
  4112e8:	nop    DWORD PTR [rax+rax*1+0x0]
  4112f0:	lea    rcx,[rax+0x1000]
  4112f7:	cmp    rcx,rdi
  4112fa:	jne    411332 <__swc_fn_65555ab2_000119_d3318640+0xd2>
  4112fc:	cmp    QWORD PTR [rax+0x8],rsi
  411300:	je     41130c <__swc_fn_65555ab2_000119_d3318640+0xac>
  411302:	mov    rcx,r12
  411305:	call   40a140 <__swc_fn_65555ab2_000138_715e84ff>
  41130a:	jmp    411346 <__swc_fn_65555ab2_000119_d3318640+0xe6>
  41130c:	mov    r14,QWORD PTR [rax]
  41130f:	mov    rdi,rax
  411312:	lea    rsi,[rsi+0x1000]
  411319:	xor    eax,eax
  41131b:	call   407160 <munmap@plt>
  411320:	test   eax,eax
  411322:	jne    411328 <__swc_fn_65555ab2_000119_d3318640+0xc8>
  411324:	mov    QWORD PTR [r13+0x0],r14
  411328:	mov    rcx,r12
  41132b:	call   40a140 <__swc_fn_65555ab2_000138_715e84ff>
  411330:	jmp    411346 <__swc_fn_65555ab2_000119_d3318640+0xe6>
  411332:	mov    r13,rax
  411335:	mov    rax,QWORD PTR [r13+0x0]
  411339:	test   rax,rax
  41133c:	jne    4112f0 <__swc_fn_65555ab2_000119_d3318640+0x90>
  41133e:	mov    rcx,r12
  411341:	call   40a140 <__swc_fn_65555ab2_000138_715e84ff>
  411346:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  41134c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  411352:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  411358:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  41135e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  411364:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  41136d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  411376:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  41137f:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  411388:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  411391:	add    rsp,0xe0
  411398:	pop    r14
  41139a:	pop    r13
  41139c:	pop    r12
  41139e:	pop    rdi
  41139f:	pop    rsi
  4113a0:	ret
	...

00000000004113b0 <__swc_fn_65555ab2_000122_be2e2f68>:
  4113b0:	push   rdi
  4113b1:	push   rsi
  4113b2:	sub    rsp,0xa8
  4113b9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4113bf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4113c5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4113cb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4113d1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4113d7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4113dd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4113e3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4113e9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4113f2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4113fb:	mov    rdi,0xfffffffffffffd66
  411402:	xor    eax,eax
  411404:	call   407180 <exit@plt>
  411409:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41140f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411415:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41141b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411421:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411427:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  41142d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411433:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411439:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411442:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41144b:	add    rsp,0xa8
  411452:	pop    rsi
  411453:	pop    rdi
  411454:	ret
	...

0000000000411460 <__swc_fn_65555ab2_000125_540bf7e8>:
  411460:	push   rbx
  411461:	push   rsi
  411462:	push   rdi
  411463:	sub    rsp,0x30
  411467:	mov    rbx,rdx
  41146a:	mov    esi,ecx
  41146c:	test   ecx,ecx
  41146e:	je     411543 <__swc_fn_65555ab2_000125_540bf7e8+0xe3>
  411474:	mov    rcx,rsi
  411477:	shl    rcx,0x4
  41147b:	call   410970 <__swc_fn_65555ab2_000083_4a10c7e7>
  411480:	test   rax,rax
  411483:	je     411532 <__swc_fn_65555ab2_000125_540bf7e8+0xd2>
  411489:	mov    rcx,rsi
  41148c:	xor    edx,edx
  41148e:	test   rsi,rsi
  411491:	jbe    411512 <__swc_fn_65555ab2_000125_540bf7e8+0xb2>
  411497:	nop    WORD PTR [rax+rax*1+0x0]
  4114a0:	mov    r8d,edx
  4114a3:	mov    r9,QWORD PTR [rbx+r8*8]
  4114a7:	add    r8,r8
  4114aa:	lea    r8,[rax+r8*8]
  4114ae:	xor    r10d,r10d
  4114b1:	test   r9,r9
  4114b4:	je     4114f0 <__swc_fn_65555ab2_000125_540bf7e8+0x90>
  4114b6:	mov    r11,r9
  4114b9:	mov    dil,BYTE PTR [r11]
  4114bc:	test   dil,dil
  4114bf:	je     4114f0 <__swc_fn_65555ab2_000125_540bf7e8+0x90>
  4114c1:	cs nop WORD PTR [rax+rax*1+0x0]
  4114cb:	cs nop WORD PTR [rax+rax*1+0x0]
  4114d5:	cs nop WORD PTR [rax+rax*1+0x0]
  4114df:	nop
  4114e0:	add    r11,0x1
  4114e4:	add    r10,0x1
  4114e8:	mov    dil,BYTE PTR [r11]
  4114eb:	test   dil,dil
  4114ee:	jne    4114e0 <__swc_fn_65555ab2_000125_540bf7e8+0x80>
  4114f0:	mov    QWORD PTR [rsp+0x18],r9
  4114f5:	mov    QWORD PTR [rsp+0x20],r10
  4114fa:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411500:	vmovups XMMWORD PTR [r8],xmm0
  411505:	add    rdx,0x1
  411509:	cmp    rdx,rcx
  41150c:	jb     4114a0 <__swc_fn_65555ab2_000125_540bf7e8+0x40>
  411512:	lea    rcx,[rip+0x1582f]        # 426d48 <__swc_bss_base_65555ab2+0x2d08>
  411519:	mov    QWORD PTR [rsp+0x8],rax
  41151e:	mov    esi,esi
  411520:	mov    QWORD PTR [rsp+0x10],rsi
  411525:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  41152b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411530:	jmp    411543 <__swc_fn_65555ab2_000125_540bf7e8+0xe3>
  411532:	lea    rcx,[rip+0x22b7]        # 4137f0 <__swc_rdata_base_65555ab2+0x6e0>
  411539:	call   409c90 <__swc_fn_65555ab2_000120_2648f149>
  41153e:	call   4113b0 <__swc_fn_65555ab2_000122_be2e2f68>
  411543:	add    rsp,0x30
  411547:	pop    rdi
  411548:	pop    rsi
  411549:	pop    rbx
  41154a:	ret
  41154b:	add    BYTE PTR [rax],al
  41154d:	add    BYTE PTR [rax],al
	...

0000000000411550 <__swc_fn_65555ab2_000128_a481cb88>:
  411550:	push   rdi
  411551:	push   rsi
  411552:	sub    rsp,0xa8
  411559:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41155f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411565:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41156b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411571:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411577:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41157d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411583:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411589:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411592:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41159b:	mov    edi,ecx
  41159d:	xor    eax,eax
  41159f:	call   4071e0 <pthread_key_delete@plt>
  4115a4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4115aa:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4115b0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4115b6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4115bc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4115c2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4115c8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4115ce:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4115d4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4115dd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4115e6:	add    rsp,0xa8
  4115ed:	pop    rsi
  4115ee:	pop    rdi
  4115ef:	ret

00000000004115f0 <__swc_fn_65555ab2_000131_a611b8c4>:
  4115f0:	push   rdi
  4115f1:	push   rsi
  4115f2:	sub    rsp,0xa8
  4115f9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4115ff:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411605:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41160b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411611:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411617:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41161d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411623:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411629:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  411632:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41163b:	test   rcx,rcx
  41163e:	je     41164f <__swc_fn_65555ab2_000131_a611b8c4+0x5f>
  411640:	lea    rax,[rcx-0x1]
  411644:	mov    eax,eax
  411646:	mov    edi,eax
  411648:	xor    eax,eax
  41164a:	call   4071e0 <pthread_key_delete@plt>
  41164f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  411655:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  41165b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411661:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  411667:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  41166d:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411673:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  411679:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  41167f:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  411688:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411691:	add    rsp,0xa8
  411698:	pop    rsi
  411699:	pop    rdi
  41169a:	ret
  41169b:	add    BYTE PTR [rax],al
  41169d:	add    BYTE PTR [rax],al
	...

00000000004116a0 <__swc_fn_65555ab2_000134_a9c1c700>:
  4116a0:	push   rsi
  4116a1:	push   rdi
  4116a2:	sub    rsp,0xa8
  4116a9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4116af:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4116b5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4116bb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4116c1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4116c7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4116cd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4116d3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4116d9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4116e2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4116eb:	xor    eax,eax
  4116ed:	call   4071f0 <gettid@plt>
  4116f2:	movsxd rax,eax
  4116f5:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4116fb:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  411701:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  411707:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41170d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  411713:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  411719:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41171f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  411725:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41172e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  411737:	add    rsp,0xa8
  41173e:	pop    rdi
  41173f:	pop    rsi
  411740:	ret
	...

0000000000411750 <__swc_fn_65555ab2_000137_8c07c14b>:
  411750:	push   rbx
  411751:	push   rdi
  411752:	push   rsi
  411753:	sub    rsp,0xc0
  41175a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  411760:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  411766:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41176c:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  411772:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  411778:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41177e:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  411784:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41178d:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  411796:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41179f:	mov    rbx,rcx
  4117a2:	cs nop WORD PTR [rax+rax*1+0x0]
  4117ac:	nop    DWORD PTR [rax+0x0]
  4117b0:	mov    edx,0x80000000
  4117b5:	xor    eax,eax
  4117b7:	lock cmpxchg DWORD PTR [rbx],edx
  4117bb:	test   eax,eax
  4117bd:	je     4117f4 <__swc_fn_65555ab2_000137_8c07c14b+0xa4>
  4117bf:	mov    eax,DWORD PTR [rbx]
  4117c1:	lea    rcx,[rsp+0x14]
  4117c6:	mov    DWORD PTR [rsp+0x14],eax
  4117ca:	test   eax,eax
  4117cc:	je     4117b0 <__swc_fn_65555ab2_000137_8c07c14b+0x60>
  4117ce:	mov    QWORD PTR [rsp],0x0
  4117d6:	mov    edi,0xca
  4117db:	mov    rsi,rbx
  4117de:	mov    edx,0x80
  4117e3:	mov    ecx,DWORD PTR [rcx]
  4117e5:	xor    r8d,r8d
  4117e8:	xor    r9d,r9d
  4117eb:	xor    eax,eax
  4117ed:	call   4071a0 <syscall@plt>
  4117f2:	jmp    4117b0 <__swc_fn_65555ab2_000137_8c07c14b+0x60>
  4117f4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4117fa:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  411800:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  411806:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41180c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  411812:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  411818:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41181e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  411827:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  411830:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  411839:	add    rsp,0xc0
  411840:	pop    rsi
  411841:	pop    rdi
  411842:	pop    rbx
  411843:	ret
	...

0000000000411850 <__swc_fn_65555ab2_000140_055b38a4>:
  411850:	sub    rsp,0x8
  411854:	call   40a140 <__swc_fn_65555ab2_000138_715e84ff>
  411859:	add    rsp,0x8
  41185d:	ret
	...

0000000000411860 <__swc_fn_65555ab2_000143_d299b428>:
  411860:	push   rdi
  411861:	push   rsi
  411862:	sub    rsp,0xa8
  411869:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41186f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  411875:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41187b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  411881:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  411887:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41188d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  411893:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  411899:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4118a2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4118ab:	mov    edi,0x28
  4118b0:	xor    eax,eax
  4118b2:	call   4071c0 <malloc@plt>
  4118b7:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4118bd:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4118c3:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4118c9:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4118cf:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4118d5:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4118db:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4118e1:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4118e7:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4118f0:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4118f9:	add    rsp,0xa8
  411900:	pop    rsi
  411901:	pop    rdi
  411902:	ret
	...

0000000000411910 <__swc_fn_65555ab2_000146_162f363d>:
  411910:	mov    QWORD PTR [r8],0x0
  411917:	cmp    rdx,0x10
  41191b:	jae    411920 <__swc_fn_65555ab2_000146_162f363d+0x10>
  41191d:	xor    eax,eax
  41191f:	ret
  411920:	mov    eax,DWORD PTR [rcx]
  411922:	cmp    eax,0x42445753
  411928:	jne    411932 <__swc_fn_65555ab2_000146_162f363d+0x22>
  41192a:	mov    eax,DWORD PTR [rcx+0x4]
  41192d:	cmp    eax,0x1
  411930:	je     411935 <__swc_fn_65555ab2_000146_162f363d+0x25>
  411932:	xor    eax,eax
  411934:	ret
  411935:	mov    QWORD PTR [r8],rdx
  411938:	mov    rax,rcx
  41193b:	ret
  41193c:	add    BYTE PTR [rax],al
	...

0000000000411940 <__swc_fn_65555ab2_000149_2eb804cc>:
  411940:	push   rbx
  411941:	sub    rsp,0xe0
  411948:	lea    rbx,[rsp+0x8]
  41194d:	vxorps xmm0,xmm0,xmm0
  411951:	vmovups YMMWORD PTR [rbx],ymm0
  411955:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  41195a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  41195f:	vzeroupper
  411962:	mov    DWORD PTR [rbx+0x60],0x0
  411969:	mov    r8,rbx
  41196c:	mov    rdx,rcx
  41196f:	nop
  411970:	mov    r9,rdx
  411973:	movabs rdx,0x6666666666666667
  41197d:	mov    rax,r9
  411980:	imul   rdx
  411983:	sar    rdx,0x2
  411987:	mov    r10,rdx
  41198a:	shr    rdx,0x3f
  41198e:	add    r10,rdx
  411991:	mov    rdx,r10
  411994:	imul   r11,r10,0xa
  411998:	sub    r9,r11
  41199b:	mov    r11,QWORD PTR [rip+0x1e6e]        # 413810 <__swc_rdata_base_65555ab2+0x700>
  4119a2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  4119a7:	mov    BYTE PTR [r8],r9b
  4119aa:	lea    r9,[r8+0x1]
  4119ae:	mov    r8,r9
  4119b1:	test   r10,r10
  4119b4:	jne    411970 <__swc_fn_65555ab2_000149_2eb804cc+0x30>
  4119b6:	test   rcx,rcx
  4119b9:	jge    4119c3 <__swc_fn_65555ab2_000149_2eb804cc+0x83>
  4119bb:	mov    BYTE PTR [r9],0x2d
  4119bf:	add    r8,0x1
  4119c3:	mov    BYTE PTR [r8],0x0
  4119c7:	sub    r8,0x1
  4119cb:	mov    rax,rbx
  4119ce:	cmp    rax,r8
  4119d1:	jae    4119f6 <__swc_fn_65555ab2_000149_2eb804cc+0xb6>
  4119d3:	cs nop WORD PTR [rax+rax*1+0x0]
  4119dd:	nop    DWORD PTR [rax]
  4119e0:	mov    cl,BYTE PTR [r8]
  4119e3:	mov    dl,BYTE PTR [rax]
  4119e5:	mov    BYTE PTR [r8],dl
  4119e8:	sub    r8,0x1
  4119ec:	mov    BYTE PTR [rax],cl
  4119ee:	inc    rax
  4119f1:	cmp    rax,r8
  4119f4:	jb     4119e0 <__swc_fn_65555ab2_000149_2eb804cc+0xa0>
  4119f6:	xor    eax,eax
  4119f8:	test   rbx,rbx
  4119fb:	je     411a1e <__swc_fn_65555ab2_000149_2eb804cc+0xde>
  4119fd:	mov    rcx,rbx
  411a00:	mov    dl,BYTE PTR [rcx]
  411a02:	test   dl,dl
  411a04:	je     411a1e <__swc_fn_65555ab2_000149_2eb804cc+0xde>
  411a06:	cs nop WORD PTR [rax+rax*1+0x0]
  411a10:	add    rcx,0x1
  411a14:	add    rax,0x1
  411a18:	mov    dl,BYTE PTR [rcx]
  411a1a:	test   dl,dl
  411a1c:	jne    411a10 <__swc_fn_65555ab2_000149_2eb804cc+0xd0>
  411a1e:	mov    QWORD PTR [rbx+0xa8],rbx
  411a25:	mov    QWORD PTR [rbx+0xb0],rax
  411a2c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  411a34:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  411a3c:	lea    rcx,[rbx+0xb8]
  411a43:	call   409c90 <__swc_fn_65555ab2_000120_2648f149>
  411a48:	add    rsp,0xe0
  411a4f:	pop    rbx
  411a50:	ret
	...

0000000000411a60 <__swc_fn_65555ab2_000152_86f1d437>:
  411a60:	vxorps xmm0,xmm0,xmm0
  411a64:	vmovups XMMWORD PTR [rcx],xmm0
  411a68:	mov    QWORD PTR [rcx+0x10],0x0
  411a70:	ret
	...

0000000000411a80 <__swc_fn_65555ab2_000155_86f1d437>:
  411a80:	vxorps xmm0,xmm0,xmm0
  411a84:	vmovups XMMWORD PTR [rcx],xmm0
  411a88:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411a8d:	vxorps xmm0,xmm0,xmm0
  411a91:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411a96:	vmovups xmm0,XMMWORD PTR [rip+0x1e6a]        # 413908 <__swc_rdata_base_65555ab2+0x7f8>
  411a9e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411aa3:	vxorps xmm0,xmm0,xmm0
  411aa7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411aac:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411ab1:	mov    QWORD PTR [rcx+0x60],0x0
  411ab9:	ret
  411aba:	add    BYTE PTR [rax],al
  411abc:	add    BYTE PTR [rax],al
	...

0000000000411ac0 <__swc_fn_65555ab2_000158_86f1d437>:
  411ac0:	vxorps xmm0,xmm0,xmm0
  411ac4:	vmovups XMMWORD PTR [rcx],xmm0
  411ac8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411acd:	vxorps xmm0,xmm0,xmm0
  411ad1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411ad6:	vmovups xmm0,XMMWORD PTR [rip+0x1f52]        # 413a30 <__swc_rdata_base_65555ab2+0x920>
  411ade:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411ae3:	vxorps xmm0,xmm0,xmm0
  411ae7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411aec:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411af1:	vxorps xmm0,xmm0,xmm0
  411af5:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  411afa:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  411aff:	vxorps xmm0,xmm0,xmm0
  411b03:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  411b0b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  411b13:	vxorps xmm0,xmm0,xmm0
  411b17:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  411b1f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  411b27:	vxorps xmm0,xmm0,xmm0
  411b2b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  411b33:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  411b3b:	mov    QWORD PTR [rcx+0xe0],0x0
  411b46:	ret
	...

0000000000411b50 <__swc_fn_65555ab2_000161_13ead2ff>:
  411b50:	push   rbx
  411b51:	mov    rbx,rcx
  411b54:	call   40b6d0 <__swc_fn_65555ab2_000162_e36363a8>
  411b59:	mov    rax,QWORD PTR [rbx+0x10]
  411b5d:	test   rax,rax
  411b60:	je     411b71 <__swc_fn_65555ab2_000161_13ead2ff+0x21>
  411b62:	mov    rcx,rbx
  411b65:	mov    rdx,rax
  411b68:	mov    r8,QWORD PTR [rbx+0x18]
  411b6c:	call   40e870 <__swc_fn_65555ab2_000160_47b270e1>
  411b71:	vxorps xmm0,xmm0,xmm0
  411b75:	vmovups XMMWORD PTR [rbx],xmm0
  411b79:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  411b7e:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  411b83:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  411b88:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  411b8d:	mov    QWORD PTR [rbx+0x50],0x0
  411b95:	pop    rbx
  411b96:	ret
	...

0000000000411ba0 <__swc_fn_65555ab2_000164_72795826>:
  411ba0:	sub    rsp,0x10
  411ba4:	mov    eax,r8d
  411ba7:	mov    r8d,r9d
  411baa:	test   r9d,r9d
  411bad:	jne    411bc6 <__swc_fn_65555ab2_000164_72795826+0x26>
  411baf:	vmovups xmm0,XMMWORD PTR [rip+0x1f31]        # 413ae8 <__swc_rdata_base_65555ab2+0x9d8>
  411bb7:	vmovups XMMWORD PTR [r10],xmm0
  411bbc:	mov    eax,0x1
  411bc1:	add    rsp,0x10
  411bc5:	ret
  411bc6:	mov    r9,r8
  411bc9:	cmp    r8,rax
  411bcc:	jb     411bd3 <__swc_fn_65555ab2_000164_72795826+0x33>
  411bce:	cmp    r9,rdx
  411bd1:	jb     411bda <__swc_fn_65555ab2_000164_72795826+0x3a>
  411bd3:	xor    eax,eax
  411bd5:	add    rsp,0x10
  411bd9:	ret
  411bda:	xor    eax,eax
  411bdc:	lea    r8,[r9+rax*1]
  411be0:	cmp    r8,rdx
  411be3:	jae    411c13 <__swc_fn_65555ab2_000164_72795826+0x73>
  411be5:	cs nop WORD PTR [rax+rax*1+0x0]
  411bef:	cs nop WORD PTR [rax+rax*1+0x0]
  411bf9:	nop    DWORD PTR [rax+0x0]
  411c00:	cmp    BYTE PTR [rcx+r8*1],0x0
  411c05:	je     411c13 <__swc_fn_65555ab2_000164_72795826+0x73>
  411c07:	inc    rax
  411c0a:	lea    r8,[r9+rax*1]
  411c0e:	cmp    r8,rdx
  411c11:	jb     411c00 <__swc_fn_65555ab2_000164_72795826+0x60>
  411c13:	cmp    r8,rdx
  411c16:	jne    411c1f <__swc_fn_65555ab2_000164_72795826+0x7f>
  411c18:	xor    eax,eax
  411c1a:	add    rsp,0x10
  411c1e:	ret
  411c1f:	add    rcx,r9
  411c22:	mov    QWORD PTR [rsp],rcx
  411c26:	mov    QWORD PTR [rsp+0x8],rax
  411c2b:	vmovups xmm0,XMMWORD PTR [rsp]
  411c30:	vmovups XMMWORD PTR [r10],xmm0
  411c35:	mov    eax,0x1
  411c3a:	add    rsp,0x10
  411c3e:	ret
	...

0000000000411c40 <__swc_fn_65555ab2_000167_bcc835b8>:
  411c40:	push   rbp
  411c41:	push   rbx
  411c42:	push   rsi
  411c43:	push   rdi
  411c44:	push   r12
  411c46:	push   r13
  411c48:	push   r14
  411c4a:	push   r15
  411c4c:	sub    rsp,0x10
  411c50:	mov    rbp,rsp
  411c53:	vmovups XMMWORD PTR [rsp],xmm6
  411c58:	sub    rsp,0x50
  411c5c:	mov    rbx,rsp
  411c5f:	mov    rsi,r8
  411c62:	mov    QWORD PTR [rsp+0x30],r8
  411c67:	mov    rdi,rcx
  411c6a:	mov    QWORD PTR [rsp+0x38],rcx
  411c6f:	mov    r12,rdx
  411c72:	xor    r13b,r13b
  411c75:	mov    r14,QWORD PTR [rdi+0x8]
  411c79:	mov    QWORD PTR [rsp+0x40],r14
  411c7e:	xor    r15d,r15d
  411c81:	test   r14,r14
  411c84:	jbe    411ede <__swc_fn_65555ab2_000167_bcc835b8+0x29e>
  411c8a:	mov    r14,QWORD PTR [rdi]
  411c8d:	mov    rax,QWORD PTR [rsp+0x40]
  411c92:	mov    QWORD PTR [rsp+0x48],r14
  411c97:	vmovups xmm6,XMMWORD PTR [rip+0x1a69]        # 413708 <__swc_rdata_base_65555ab2+0x5f8>
  411c9f:	nop
  411ca0:	cmp    QWORD PTR [r14+r15*8],0x0
  411ca5:	jne    411caf <__swc_fn_65555ab2_000167_bcc835b8+0x6f>
  411ca7:	mov    r14,rax
  411caa:	jmp    411ebe <__swc_fn_65555ab2_000167_bcc835b8+0x27e>
  411caf:	mov    rcx,QWORD PTR [rdi]
  411cb2:	mov    rdx,QWORD PTR [rcx+r15*8]
  411cb6:	mov    rdi,rbx
  411cb9:	mov    rcx,rdi
  411cbc:	sub    rsp,0x8
  411cc0:	mov    r14,rax
  411cc3:	call   40e8f0 <__swc_fn_65555ab2_000166_cc119975>
  411cc8:	add    rsp,0x8
  411ccc:	mov    al,BYTE PTR [rbx]
  411cce:	test   al,al
  411cd0:	je     411ebe <__swc_fn_65555ab2_000167_bcc835b8+0x27e>
  411cd6:	mov    al,BYTE PTR [rbx+0x1]
  411cd9:	test   al,al
  411cdb:	jne    411ce6 <__swc_fn_65555ab2_000167_bcc835b8+0xa6>
  411cdd:	test   sil,sil
  411ce0:	je     411ebe <__swc_fn_65555ab2_000167_bcc835b8+0x27e>
  411ce6:	test   r13b,r13b
  411ce9:	jne    411da7 <__swc_fn_65555ab2_000167_bcc835b8+0x167>
  411cef:	test   r12,r12
  411cf2:	je     411da7 <__swc_fn_65555ab2_000167_bcc835b8+0x167>
  411cf8:	mov    al,BYTE PTR [rbx+0x1]
  411cfb:	test   al,al
  411cfd:	je     411ebe <__swc_fn_65555ab2_000167_bcc835b8+0x27e>
  411d03:	mov    eax,DWORD PTR [rbx+0x28]
  411d06:	cmp    DWORD PTR [r12+0x20],eax
  411d0b:	jne    411ebe <__swc_fn_65555ab2_000167_bcc835b8+0x27e>
  411d11:	mov    rax,QWORD PTR [r12]
  411d15:	mov    rcx,QWORD PTR [r12+0x8]
  411d1a:	cmp    QWORD PTR [rbx+0x20],rcx
  411d1e:	jne    411ebe <__swc_fn_65555ab2_000167_bcc835b8+0x27e>
  411d24:	mov    cl,0x1
  411d26:	test   rax,rax
  411d29:	je     411d92 <__swc_fn_65555ab2_000167_bcc835b8+0x152>
  411d2f:	mov    rdx,QWORD PTR [rbx+0x20]
  411d33:	xor    r8d,r8d
  411d36:	test   rdx,rdx
  411d39:	jbe    411d92 <__swc_fn_65555ab2_000167_bcc835b8+0x152>
  411d3b:	mov    r9,QWORD PTR [rbx+0x18]
  411d3f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  411d44:	cs nop WORD PTR [rax+rax*1+0x0]
  411d4e:	xchg   ax,ax
  411d50:	mov    r10b,BYTE PTR [rax+r8*1]
  411d54:	cmp    BYTE PTR [r9+r8*1],r10b
  411d58:	je     411d89 <__swc_fn_65555ab2_000167_bcc835b8+0x149>
  411d5a:	vmovq  r10,xmm0
  411d5f:	cmp    BYTE PTR [r10+r8*1],0x5c
  411d64:	jne    411d6d <__swc_fn_65555ab2_000167_bcc835b8+0x12d>
  411d66:	cmp    BYTE PTR [rax+r8*1],0x2f
  411d6b:	je     411d89 <__swc_fn_65555ab2_000167_bcc835b8+0x149>
  411d6d:	vmovq  r10,xmm0
  411d72:	cmp    BYTE PTR [r10+r8*1],0x2f
  411d77:	jne    411d80 <__swc_fn_65555ab2_000167_bcc835b8+0x140>
  411d79:	cmp    BYTE PTR [rax+r8*1],0x5c
  411d7e:	je     411d89 <__swc_fn_65555ab2_000167_bcc835b8+0x149>
  411d80:	xor    eax,eax
  411d82:	movzx  eax,al
  411d85:	mov    cl,al
  411d87:	jmp    411d92 <__swc_fn_65555ab2_000167_bcc835b8+0x152>
  411d89:	add    r8,0x1
  411d8d:	cmp    r8,rdx
  411d90:	jb     411d50 <__swc_fn_65555ab2_000167_bcc835b8+0x110>
  411d92:	test   cl,cl
  411d94:	je     411ebe <__swc_fn_65555ab2_000167_bcc835b8+0x27e>
  411d9a:	mov    eax,0x1
  411d9f:	mov    r13b,al
  411da2:	jmp    411ebe <__swc_fn_65555ab2_000167_bcc835b8+0x27e>
  411da7:	mov    r13b,0x1
  411daa:	sub    rsp,0x20
  411dae:	mov    rax,rsp
  411db1:	lea    rcx,[rdi+0x8]
  411db5:	mov    QWORD PTR [rax],rcx
  411db8:	lea    rsi,[rip+0x1571]        # 413330 <__swc_rdata_base_65555ab2+0x220>
  411dbf:	mov    QWORD PTR [rax+0x8],rsi
  411dc3:	mov    QWORD PTR [rax+0x10],rsp
  411dc7:	mov    QWORD PTR [rax+0x18],0x1
  411dcf:	lea    rcx,[rsp+0x10]
  411dd4:	sub    rsp,0x8
  411dd8:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  411ddd:	add    rsp,0x8
  411de1:	add    rsp,0x20
  411de5:	mov    al,BYTE PTR [rbx+0x1]
  411de8:	test   al,al
  411dea:	je     411e87 <__swc_fn_65555ab2_000167_bcc835b8+0x247>
  411df0:	lea    rax,[rip+0x1d91]        # 413b88 <__swc_rdata_base_65555ab2+0xa78>
  411df7:	sub    rsp,0x20
  411dfb:	mov    rcx,rsp
  411dfe:	mov    QWORD PTR [rcx],rax
  411e01:	mov    QWORD PTR [rcx+0x8],rsi
  411e05:	mov    QWORD PTR [rcx+0x10],rsp
  411e09:	mov    QWORD PTR [rcx+0x18],0x1
  411e11:	lea    rcx,[rsp+0x10]
  411e16:	sub    rsp,0x8
  411e1a:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  411e1f:	add    rsp,0x8
  411e23:	add    rsp,0x20
  411e27:	mov    eax,DWORD PTR [rbx+0x28]
  411e2a:	sub    rsp,0x60
  411e2e:	mov    rcx,rsp
  411e31:	lea    rdx,[rdi+0x18]
  411e35:	mov    QWORD PTR [rcx+0x18],rdx
  411e39:	mov    QWORD PTR [rcx+0x20],rsi
  411e3d:	vmovups XMMWORD PTR [rcx],xmm6
  411e41:	mov    QWORD PTR [rcx+0x28],rsp
  411e45:	mov    QWORD PTR [rcx+0x30],rsi
  411e49:	mov    DWORD PTR [rcx+0x10],eax
  411e4c:	lea    rax,[rsp+0x10]
  411e51:	mov    QWORD PTR [rcx+0x38],rax
  411e55:	lea    rax,[rip+0x1844]        # 4136a0 <__swc_rdata_base_65555ab2+0x590>
  411e5c:	mov    QWORD PTR [rcx+0x40],rax
  411e60:	lea    rax,[rsp+0x18]
  411e65:	mov    QWORD PTR [rcx+0x48],rax
  411e69:	mov    QWORD PTR [rcx+0x50],0x3
  411e71:	lea    rcx,[rsp+0x48]
  411e76:	sub    rsp,0x8
  411e7a:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  411e7f:	add    rsp,0x8
  411e83:	add    rsp,0x60
  411e87:	lea    rax,[rip+0x1492]        # 413320 <__swc_rdata_base_65555ab2+0x210>
  411e8e:	sub    rsp,0x20
  411e92:	mov    rcx,rsp
  411e95:	mov    QWORD PTR [rcx],rax
  411e98:	mov    QWORD PTR [rcx+0x8],rsi
  411e9c:	mov    QWORD PTR [rcx+0x10],rsp
  411ea0:	mov    QWORD PTR [rcx+0x18],0x1
  411ea8:	lea    rcx,[rsp+0x10]
  411ead:	sub    rsp,0x8
  411eb1:	call   40a500 <__swc_fn_65555ab2_000150_6203dca2>
  411eb6:	add    rsp,0x8
  411eba:	add    rsp,0x20
  411ebe:	add    r15,0x1
  411ec2:	cmp    r15,r14
  411ec5:	jae    411ede <__swc_fn_65555ab2_000167_bcc835b8+0x29e>
  411ec7:	mov    rsi,QWORD PTR [rsp+0x30]
  411ecc:	mov    rdi,QWORD PTR [rsp+0x38]
  411ed1:	mov    rax,r14
  411ed4:	mov    r14,QWORD PTR [rsp+0x48]
  411ed9:	jmp    411ca0 <__swc_fn_65555ab2_000167_bcc835b8+0x60>
  411ede:	add    rsp,0x50
  411ee2:	vmovups xmm6,XMMWORD PTR [rsp]
  411ee7:	add    rsp,0x10
  411eeb:	pop    r15
  411eed:	pop    r14
  411eef:	pop    r13
  411ef1:	pop    r12
  411ef3:	pop    rdi
  411ef4:	pop    rsi
  411ef5:	pop    rbx
  411ef6:	pop    rbp
  411ef7:	ret
	...

0000000000411f00 <__swc_fn_65555ab2_000170_646fdf20>:
  411f00:	sub    rsp,0x8
  411f04:	call   409f10 <__swc_fn_65555ab2_000129_4bbe3f14>
  411f09:	add    rsp,0x8
  411f0d:	ret
	...

0000000000411f10 <__swc_fn_65555ab2_000173_1e0ea8cf>:
  411f10:	push   rsi
  411f11:	sub    rsp,0x30
  411f15:	lea    rsi,[rip+0x14e7c]        # 426d98 <__swc_bss_base_65555ab2+0x2d58>
  411f1c:	mov    rax,QWORD PTR [rsi]
  411f1f:	test   rax,rax
  411f22:	je     411f2a <__swc_fn_65555ab2_000173_1e0ea8cf+0x1a>
  411f24:	add    rsp,0x30
  411f28:	pop    rsi
  411f29:	ret
  411f2a:	mov    ecx,0x2
  411f2f:	mov    edx,0x8020
  411f34:	call   4095b0 <__swc_fn_65555ab2_000111_6814119b>
  411f39:	test   rax,rax
  411f3c:	jne    411f4d <__swc_fn_65555ab2_000173_1e0ea8cf+0x3d>
  411f3e:	mov    QWORD PTR [rsp+0x18],rax
  411f43:	call   4113b0 <__swc_fn_65555ab2_000122_be2e2f68>
  411f48:	mov    rax,QWORD PTR [rsp+0x18]
  411f4d:	mov    rcx,rax
  411f50:	xchg   QWORD PTR [rsi],rcx
  411f53:	add    rsp,0x30
  411f57:	pop    rsi
  411f58:	ret
  411f59:	add    BYTE PTR [rax],al
  411f5b:	add    BYTE PTR [rax],al
  411f5d:	add    BYTE PTR [rax],al
	...

0000000000411f60 <__swc_fn_65555ab2_000176_4de704de>:
  411f60:	push   rsi
  411f61:	test   r8,r8
  411f64:	jne    411f68 <__swc_fn_65555ab2_000176_4de704de+0x8>
  411f66:	pop    rsi
  411f67:	ret
  411f68:	lea    rax,[rcx+0x18]
  411f6c:	mov    r10,QWORD PTR [rax]
  411f6f:	lea    r11,[r10+0x1]
  411f73:	mov    QWORD PTR [rax],r11
  411f76:	mov    r11,rdx
  411f79:	not    rdx
  411f7c:	lea    rsi,[r8-0x1]
  411f80:	cmp    rsi,rdx
  411f83:	ja     411fa3 <__swc_fn_65555ab2_000176_4de704de+0x43>
  411f85:	lea    rdx,[r11+r8*1]
  411f89:	dec    rdx
  411f8c:	shr    rdx,0x6
  411f90:	mov    r8,r11
  411f93:	shr    r8,0x6
  411f97:	mov    rsi,rdx
  411f9a:	sub    rsi,r8
  411f9d:	cmp    rsi,0x8
  411fa1:	jb     411fb9 <__swc_fn_65555ab2_000176_4de704de+0x59>
  411fa3:	lea    rcx,[rcx+0x10]
  411fa7:	mov    rdx,QWORD PTR [rcx]
  411faa:	add    rdx,r9
  411fad:	mov    QWORD PTR [rcx],rdx
  411fb0:	lea    rcx,[r10+0x2]
  411fb4:	mov    QWORD PTR [rax],rcx
  411fb7:	pop    rsi
  411fb8:	ret
  411fb9:	shr    r11,0x6
  411fbd:	nop    DWORD PTR [rax]
  411fc0:	cmp    r11,rdx
  411fc3:	ja     412003 <__swc_fn_65555ab2_000176_4de704de+0xa3>
  411fc5:	jmp    411fd6 <__swc_fn_65555ab2_000176_4de704de+0x76>
  411fc7:	nop    WORD PTR [rax+rax*1+0x0]
  411fd0:	add    r11,0x1
  411fd4:	jmp    411fc0 <__swc_fn_65555ab2_000176_4de704de+0x60>
  411fd6:	mov    r8,r11
  411fd9:	shr    r8,0xc
  411fdd:	mov    rsi,r11
  411fe0:	xor    rsi,r8
  411fe3:	mov    r8,r11
  411fe6:	shr    r8,0x18
  411fea:	xor    rsi,r8
  411fed:	and    esi,0xfff
  411ff3:	lea    r8,[rcx+rsi*8+0x20]
  411ff8:	mov    rsi,QWORD PTR [r8]
  411ffb:	add    rsi,r9
  411ffe:	mov    QWORD PTR [r8],rsi
  412001:	jmp    411fd0 <__swc_fn_65555ab2_000176_4de704de+0x70>
  412003:	lea    rcx,[r10+0x2]
  412007:	mov    QWORD PTR [rax],rcx
  41200a:	pop    rsi
  41200b:	ret
