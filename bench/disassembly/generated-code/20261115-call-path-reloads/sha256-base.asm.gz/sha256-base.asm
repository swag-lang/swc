
/workspace/prompt2-20261115/batch9-audited-micro/base/sha256/sha256:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xc002]        # 413008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <getpid@plt>:
  407010:	jmp    QWORD PTR [rip+0xbffa]        # 413010 <getpid@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <munmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xbff2]        # 413018 <munmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xbfea]        # 413020 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <exit@plt>:
  407040:	jmp    QWORD PTR [rip+0xbfe2]        # 413028 <exit@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <pthread_key_create@plt>:
  407050:	jmp    QWORD PTR [rip+0xbfda]        # 413030 <pthread_key_create@GLIBC_2.34>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_setspecific@plt>:
  407060:	jmp    QWORD PTR [rip+0xbfd2]        # 413038 <pthread_setspecific@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <syscall@plt>:
  407070:	jmp    QWORD PTR [rip+0xbfca]        # 413040 <syscall@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dladdr@plt>:
  407080:	jmp    QWORD PTR [rip+0xbfc2]        # 413048 <dladdr@GLIBC_2.34>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <open@plt>:
  407090:	jmp    QWORD PTR [rip+0xbfba]        # 413050 <open@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <lseek@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xbfb2]        # 413058 <lseek@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <close@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xbfaa]        # 413060 <close@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <mmap@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xbfa2]        # 413068 <mmap@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <malloc@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xbf9a]        # 413070 <malloc@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <clock_gettime@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xbf92]        # 413078 <clock_gettime@GLIBC_2.17>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <madvise@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xbf92]        # 413088 <madvise@GLIBC_2.2.5>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <pthread_key_delete@plt>:
  407100:	jmp    QWORD PTR [rip+0xbf8a]        # 413090 <pthread_key_delete@GLIBC_2.34>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <gettid@plt>:
  407110:	jmp    QWORD PTR [rip+0xbf82]        # 413098 <gettid@GLIBC_2.30>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <flock@plt>:
  407120:	jmp    QWORD PTR [rip+0xbf7a]        # 4130a0 <flock@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <__errno_location@plt>:
  407130:	jmp    QWORD PTR [rip+0xbf72]        # 4130a8 <__errno_location@GLIBC_2.2.5>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <opendir@plt>:
  407140:	jmp    QWORD PTR [rip+0xbf6a]        # 4130b0 <opendir@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <dirfd@plt>:
  407150:	jmp    QWORD PTR [rip+0xbf62]        # 4130b8 <dirfd@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <readdir@plt>:
  407160:	jmp    QWORD PTR [rip+0xbf5a]        # 4130c0 <readdir@GLIBC_2.2.5>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <readlinkat@plt>:
  407170:	jmp    QWORD PTR [rip+0xbf52]        # 4130c8 <readlinkat@GLIBC_2.4>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <openat@plt>:
  407180:	jmp    QWORD PTR [rip+0xbf4a]        # 4130d0 <openat@GLIBC_2.4>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <closedir@plt>:
  407190:	jmp    QWORD PTR [rip+0xbf42]        # 4130d8 <closedir@GLIBC_2.2.5>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <memfd_create@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xbf3a]        # 4130e0 <memfd_create@GLIBC_2.27>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <ftruncate@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xbf32]        # 4130e8 <ftruncate@GLIBC_2.2.5>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <write@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xbf2a]        # 4130f0 <write@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <backtrace@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xbf22]        # 4130f8 <backtrace@GLIBC_2.2.5>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <__x86_get_cpuid_feature_leaf@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xbf1a]        # 413100 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <free@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xbf12]        # 413108 <free@GLIBC_2.2.5>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xbddf]        # 413000 <__swc_fn_65555ab2_000176_5d3d19bd+0x1060>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40ca80 <__swc_fn_65555ab2_000121_71a5b1cd>
  40724e:	xor    ecx,ecx
  407250:	call   40c1a0 <__swc_fn_65555ab2_000094_335e9a12>
  407255:	call   40d6e0 <__swc_fn_65555ab2_000178_72e41d4d>
  40725a:	call   40f5f0 <__swc_fn_65555ab2_000095_a3245f7e>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_65555ab2_000000_29b04951>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_65555ab2_000003_644dadb7>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_65555ab2_000003_644dadb7+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   409240 <__swc_fn_65555ab2_000111_e724f834>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_65555ab2_000003_644dadb7+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1cd81]        # 424048 <__swc_bss_base_65555ab2+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1cd7a]        # 424048 <__swc_bss_base_65555ab2+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_65555ab2_000003_644dadb7+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_65555ab2_000003_644dadb7+0x30>
  4072e6:	lea    rcx,[rip+0x1cd63]        # 424050 <__swc_bss_base_65555ab2+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1cd5c]        # 424050 <__swc_bss_base_65555ab2+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_65555ab2_000003_644dadb7+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_65555ab2_000003_644dadb7+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_65555ab2_000006_12cb36a2>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40dea0 <__swc_fn_65555ab2_000011_e75d466d>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_65555ab2_000012_39679ef8>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_65555ab2_000006_12cb36a2+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_65555ab2_000003_644dadb7>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_65555ab2_000006_12cb36a2+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_65555ab2_000009_2417e911>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_65555ab2_000009_2417e911+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40a530 <__swc_fn_65555ab2_000007_635028f3>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40de90 <__swc_fn_65555ab2_000008_578f1784>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_65555ab2_000009_2417e911+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_65555ab2_000009_2417e911+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_65555ab2_000012_39679ef8>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_65555ab2_000015_aa8c841a>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_65555ab2_000015_aa8c841a+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_65555ab2_000015_aa8c841a+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_65555ab2_000015_aa8c841a+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_65555ab2_000015_aa8c841a+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40e000 <__swc_fn_65555ab2_000017_e238d24c>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_65555ab2_000015_aa8c841a+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1cb3d]        # 424058 <__swc_bss_base_65555ab2+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1cb36]        # 424058 <__swc_bss_base_65555ab2+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_65555ab2_000015_aa8c841a+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_65555ab2_000015_aa8c841a+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40dea0 <__swc_fn_65555ab2_000011_e75d466d>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_65555ab2_000015_aa8c841a+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   40c7a0 <__swc_fn_65555ab2_000112_cb2656be>
  407569:	lea    rcx,[rip+0x1cad8]        # 424048 <__swc_bss_base_65555ab2+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1cad1]        # 424048 <__swc_bss_base_65555ab2+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_65555ab2_000015_aa8c841a+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_65555ab2_000015_aa8c841a+0x110>
  407598:	lea    rcx,[rip+0x1cac1]        # 424060 <__swc_bss_base_65555ab2+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1caba]        # 424060 <__swc_bss_base_65555ab2+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_65555ab2_000015_aa8c841a+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_65555ab2_000015_aa8c841a+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_65555ab2_000018_e2e8e4b0>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_65555ab2_000015_aa8c841a+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_65555ab2_000018_e2e8e4b0>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_65555ab2_000018_e2e8e4b0+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_65555ab2_000018_e2e8e4b0+0x10>

0000000000407630 <__swc_fn_65555ab2_000021_fe13ecad>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_65555ab2_000015_aa8c841a>
  40763e:	lea    rdi,[rip+0x1cbab]        # 4241f0 <__swc_bss_base_65555ab2+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   4098a0 <__swc_fn_65555ab2_000135_1fec60ac>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1cb94]        # 4241f8 <__swc_bss_base_65555ab2+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1cb89],rsi        # 4241f8 <__swc_bss_base_65555ab2+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_65555ab2_000024_7e9350e1>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_65555ab2_000027_7e9350e1>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_65555ab2_000030_686c93a8>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_65555ab2_000030_686c93a8+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1a92c]        # 422000 <__swc_data_base_65555ab2>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_65555ab2_000030_686c93a8+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_65555ab2_000030_686c93a8+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_65555ab2_000030_686c93a8+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40e1c0 <__swc_fn_65555ab2_000032_8c89735c>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_65555ab2_000030_686c93a8+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_65555ab2_000036_62160bb3>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_65555ab2_000030_686c93a8+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_65555ab2_000042_70d5ab54>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_65555ab2_000033_7d7574b6>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40a9e0 <__swc_fn_65555ab2_000031_ed8d61a9>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   409720 <__swc_fn_65555ab2_000129_0672cd48>
  407734:	mov    rcx,rsi
  407737:	call   40e1c0 <__swc_fn_65555ab2_000032_8c89735c>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_65555ab2_000036_62160bb3>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_65555ab2_000039_05a50673>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_65555ab2_000039_05a50673+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_65555ab2_000039_05a50673+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_65555ab2_000039_05a50673+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_65555ab2_000039_05a50673+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_65555ab2_000039_05a50673+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   409320 <__swc_fn_65555ab2_000114_0575f585>
  4077ca:	lea    rcx,[rip+0x1c877]        # 424048 <__swc_bss_base_65555ab2+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1c870]        # 424048 <__swc_bss_base_65555ab2+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_65555ab2_000039_05a50673+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_65555ab2_000039_05a50673+0x90>
  4077f8:	lea    rcx,[rip+0x1c861]        # 424060 <__swc_bss_base_65555ab2+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1c85a]        # 424060 <__swc_bss_base_65555ab2+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_65555ab2_000039_05a50673+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_65555ab2_000039_05a50673+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_65555ab2_000042_70d5ab54>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_65555ab2_000042_70d5ab54+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40e790 <__swc_fn_65555ab2_000059_c8e1ff6b>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   4098a0 <__swc_fn_65555ab2_000135_1fec60ac>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_65555ab2_000042_70d5ab54+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_65555ab2_000042_70d5ab54+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_65555ab2_000009_2417e911>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_65555ab2_000042_70d5ab54+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40dec0 <__swc_fn_65555ab2_000014_1acdaf22>
  40791e:	jmp    407941 <__swc_fn_65555ab2_000042_70d5ab54+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_65555ab2_000042_70d5ab54+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_65555ab2_000042_70d5ab54+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_65555ab2_000042_70d5ab54+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40aba0 <__swc_fn_65555ab2_000043_3755033a>
  407997:	mov    rcx,rdi
  40799a:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_65555ab2_000039_05a50673>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_65555ab2_000045_06cec934>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_65555ab2_000045_06cec934+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_65555ab2_000045_06cec934+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_65555ab2_000045_06cec934+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_65555ab2_000045_06cec934+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   4098a0 <__swc_fn_65555ab2_000135_1fec60ac>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_65555ab2_000045_06cec934+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_65555ab2_000045_06cec934+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_65555ab2_000045_06cec934+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_65555ab2_000045_06cec934+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_65555ab2_000009_2417e911>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_65555ab2_000045_06cec934+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_65555ab2_000045_06cec934+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_65555ab2_000045_06cec934+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_65555ab2_000045_06cec934+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_65555ab2_000045_06cec934+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40a5e0 <__swc_fn_65555ab2_000013_d15d37c6>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_65555ab2_000045_06cec934+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_65555ab2_000045_06cec934+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_65555ab2_000045_06cec934+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_65555ab2_000045_06cec934+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40e040 <__swc_fn_65555ab2_000020_4135c89a>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_65555ab2_000045_06cec934+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40a5e0 <__swc_fn_65555ab2_000013_d15d37c6>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_65555ab2_000045_06cec934+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_65555ab2_000021_fe13ecad>
  407c07:	mov    rcx,r14
  407c0a:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_65555ab2_000045_06cec934+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_65555ab2_000045_06cec934+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_65555ab2_000045_06cec934+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_65555ab2_000048_18a95c9b>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_65555ab2_000048_18a95c9b+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_65555ab2_000048_18a95c9b+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_65555ab2_000048_18a95c9b+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_65555ab2_000048_18a95c9b+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40e3f0 <__swc_fn_65555ab2_000047_3d3eceb4>
  407d14:	jmp    407ce0 <__swc_fn_65555ab2_000048_18a95c9b+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_65555ab2_000048_18a95c9b+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_65555ab2_000048_18a95c9b+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_65555ab2_000048_18a95c9b+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_65555ab2_000048_18a95c9b+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_65555ab2_000048_18a95c9b+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_65555ab2_000048_18a95c9b+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_65555ab2_000048_18a95c9b+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_65555ab2_000051_5b91e689>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_65555ab2_000051_5b91e689+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_65555ab2_000051_5b91e689+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_65555ab2_000051_5b91e689+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_65555ab2_000051_5b91e689+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40e350 <__swc_fn_65555ab2_000044_cac7f504>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40dec0 <__swc_fn_65555ab2_000014_1acdaf22>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_65555ab2_000054_1dfec8f6>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   4098a0 <__swc_fn_65555ab2_000135_1fec60ac>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_65555ab2_000054_1dfec8f6+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_65555ab2_000054_1dfec8f6+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_65555ab2_000054_1dfec8f6+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_65555ab2_000057_8be0372b>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_65555ab2_000060_9d59636e>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_65555ab2_000060_9d59636e+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_65555ab2_000039_05a50673>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_65555ab2_000060_9d59636e+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_65555ab2_000063_3509a564>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40af20 <__swc_fn_65555ab2_000052_26c6c1c4>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_65555ab2_000054_1dfec8f6>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_65555ab2_000063_3509a564+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_65555ab2_000063_3509a564+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40b040 <__swc_fn_65555ab2_000058_033ce1da>
  407f7f:	mov    rcx,rsi
  407f82:	call   40ac80 <__swc_fn_65555ab2_000049_781177b4>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_65555ab2_000066_77c6e829>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_65555ab2_000066_77c6e829+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1c049]        # 424070 <__swc_bss_base_65555ab2+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1c04b]        # 424080 <__swc_bss_base_65555ab2+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_65555ab2_000066_77c6e829+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_65555ab2_000066_77c6e829+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40a910 <__swc_fn_65555ab2_000022_77c2d682>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_65555ab2_000066_77c6e829+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_65555ab2_000063_3509a564>
  40808f:	jmp    408122 <__swc_fn_65555ab2_000066_77c6e829+0x192>
  408094:	lea    rax,[rip+0x19f65]        # 422000 <__swc_data_base_65555ab2>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_65555ab2_000066_77c6e829+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_65555ab2_000066_77c6e829+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_65555ab2_000066_77c6e829+0x135>
  4080b8:	call   40a9e0 <__swc_fn_65555ab2_000031_ed8d61a9>
  4080bd:	mov    rcx,rax
  4080c0:	call   410380 <__swc_fn_65555ab2_000128_9c45d2d7>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_65555ab2_000066_77c6e829+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_65555ab2_000066_77c6e829+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_65555ab2_000066_77c6e829+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40e3f0 <__swc_fn_65555ab2_000047_3d3eceb4>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_65555ab2_000066_77c6e829+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_65555ab2_000051_5b91e689>
  408115:	jmp    408122 <__swc_fn_65555ab2_000066_77c6e829+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40a550 <__swc_fn_65555ab2_000010_186cd0c2>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_65555ab2_000069_165b6301>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_65555ab2_000036_62160bb3>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_65555ab2_000069_165b6301+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1c09a]        # 424240 <__swc_bss_base_65555ab2+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_65555ab2_000069_165b6301+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   4098a0 <__swc_fn_65555ab2_000135_1fec60ac>
  4081b5:	mov    rcx,rsi
  4081b8:	call   40ebc0 <__swc_fn_65555ab2_000068_557d6092>
  4081bd:	mov    rcx,rsi
  4081c0:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_65555ab2_000072_b2caea81>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40e910 <__swc_fn_65555ab2_000065_cd9dd53e>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_65555ab2_000075_104c4b5d>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   40ebc0 <__swc_fn_65555ab2_000068_557d6092>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_65555ab2_000078_5a70c27a>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_65555ab2_000078_5a70c27a+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_65555ab2_000078_5a70c27a+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_65555ab2_000081_85585149>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_65555ab2_000084_746bf146>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_65555ab2_000090_9a1d717d>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_65555ab2_000084_746bf146+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_65555ab2_000084_746bf146+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_65555ab2_000084_746bf146+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_65555ab2_000084_746bf146+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_65555ab2_000090_9a1d717d>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_65555ab2_000084_746bf146+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_65555ab2_000084_746bf146+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_65555ab2_000084_746bf146+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_65555ab2_000084_746bf146+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_65555ab2_000084_746bf146+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_65555ab2_000084_746bf146+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_65555ab2_000084_746bf146+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_65555ab2_000084_746bf146+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_65555ab2_000084_746bf146+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_65555ab2_000084_746bf146+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40c020 <__swc_fn_65555ab2_000082_9f4f5092>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_65555ab2_000084_746bf146+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_65555ab2_000084_746bf146+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_65555ab2_000084_746bf146+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40c020 <__swc_fn_65555ab2_000082_9f4f5092>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_65555ab2_000084_746bf146+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_65555ab2_000084_746bf146>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_65555ab2_000084_746bf146+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_65555ab2_000084_746bf146+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_65555ab2_000087_1fb4fcfe>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_65555ab2_000090_9a1d717d>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_65555ab2_000087_1fb4fcfe+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   40f020 <__swc_fn_65555ab2_000086_ac8c6565>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_65555ab2_000087_1fb4fcfe+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_65555ab2_000087_1fb4fcfe+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_65555ab2_000087_1fb4fcfe+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40c020 <__swc_fn_65555ab2_000082_9f4f5092>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_65555ab2_000087_1fb4fcfe+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_65555ab2_000087_1fb4fcfe>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_65555ab2_000087_1fb4fcfe+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_65555ab2_000087_1fb4fcfe+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_65555ab2_000090_9a1d717d>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_65555ab2_000090_9a1d717d+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_65555ab2_000090_9a1d717d+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_65555ab2_000090_9a1d717d+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_65555ab2_000090_9a1d717d+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40c020 <__swc_fn_65555ab2_000082_9f4f5092>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40c020 <__swc_fn_65555ab2_000082_9f4f5092>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_65555ab2_000090_9a1d717d+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_65555ab2_000090_9a1d717d+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_65555ab2_000090_9a1d717d+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_65555ab2_000090_9a1d717d+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_65555ab2_000090_9a1d717d>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_65555ab2_000090_9a1d717d+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_65555ab2_000090_9a1d717d+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_65555ab2_000090_9a1d717d+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_65555ab2_000090_9a1d717d+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_65555ab2_000090_9a1d717d+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_65555ab2_000090_9a1d717d+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_65555ab2_000090_9a1d717d+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_65555ab2_000090_9a1d717d+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_65555ab2_000090_9a1d717d+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_65555ab2_000090_9a1d717d+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_65555ab2_000090_9a1d717d+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_65555ab2_000090_9a1d717d+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_65555ab2_000090_9a1d717d+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_65555ab2_000090_9a1d717d+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_65555ab2_000090_9a1d717d+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_65555ab2_000090_9a1d717d+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   409db0 <__swc_fn_65555ab2_000147_c9c6528e>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_65555ab2_000090_9a1d717d+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_65555ab2_000090_9a1d717d>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_65555ab2_000090_9a1d717d+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_65555ab2_000090_9a1d717d+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_65555ab2_000090_9a1d717d+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   409db0 <__swc_fn_65555ab2_000147_c9c6528e>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   409db0 <__swc_fn_65555ab2_000147_c9c6528e>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_65555ab2_000093_344f5089>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40c150 <__swc_fn_65555ab2_000091_e6773530>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_65555ab2_000093_344f5089+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_65555ab2_000093_344f5089+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   410520 <__swc_fn_65555ab2_000137_899a611e>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_65555ab2_000093_344f5089+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0xa872]        # 4131c0 <__swc_rdata_base_65555ab2+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   410050 <__swc_fn_65555ab2_000116_3499f7d6>
  408959:	call   40c9d0 <__swc_fn_65555ab2_000118_2b35b5e0>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_65555ab2_000096_f879630a>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40896f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  408975:	vzeroupper
  408978:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40897e:	mov    QWORD PTR [rsp+0x48],rdx
  408983:	mov    rax,r8
  408986:	cmp    r8,0x1
  40898a:	mov    edx,0x1
  40898f:	cmovb  rax,rdx
  408993:	mov    QWORD PTR [rsp+0x50],rax
  408998:	mov    rbx,QWORD PTR [rcx+0x8]
  40899c:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a0:	mov    rcx,QWORD PTR [rcx]
  4089a3:	lea    rdx,[rsp+0x8]
  4089a8:	call   rbx
  4089aa:	add    rsp,0x70
  4089ae:	pop    rbx
  4089af:	ret

00000000004089b0 <__swc_fn_65555ab2_000099_6e0faaee>:
  4089b0:	push   rbx
  4089b1:	push   rsi
  4089b2:	push   rdi
  4089b3:	sub    rsp,0x30
  4089b7:	mov    rbx,rcx
  4089ba:	test   rcx,rcx
  4089bd:	je     4089d2 <__swc_fn_65555ab2_000099_6e0faaee+0x22>
  4089bf:	mov    rcx,rbx
  4089c2:	mov    edx,0x1
  4089c7:	call   408200 <__swc_fn_65555ab2_000078_5a70c27a>
  4089cc:	cmp    rax,0x1
  4089d0:	je     4089da <__swc_fn_65555ab2_000099_6e0faaee+0x2a>
  4089d2:	add    rsp,0x30
  4089d6:	pop    rdi
  4089d7:	pop    rsi
  4089d8:	pop    rbx
  4089d9:	ret
  4089da:	lea    rsi,[rsp+0x8]
  4089df:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089e4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089ea:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  4089ef:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4089f5:	mov    rax,QWORD PTR [rsp+0x20]
  4089fa:	test   rax,rax
  4089fd:	je     408a13 <__swc_fn_65555ab2_000099_6e0faaee+0x63>
  4089ff:	test   DWORD PTR [rax+0x28],0x400000
  408a06:	je     408a13 <__swc_fn_65555ab2_000099_6e0faaee+0x63>
  408a08:	mov    rcx,QWORD PTR [rax+0x30]
  408a0c:	test   rcx,rcx
  408a0f:	cmovne rax,rcx
  408a13:	mov    edi,DWORD PTR [rax+0x20]
  408a16:	lea    rcx,[rsp+0x18]
  408a1b:	call   40c330 <__swc_fn_65555ab2_000100_2ef16a3e>
  408a20:	mov    rcx,rsi
  408a23:	mov    rdx,QWORD PTR [rsp+0x18]
  408a28:	mov    r8,rdi
  408a2b:	call   408960 <__swc_fn_65555ab2_000096_f879630a>
  408a30:	mov    rcx,QWORD PTR [rbx+0x28]
  408a34:	call   40f600 <__swc_fn_65555ab2_000098_d9d80f1a>
  408a39:	mov    rcx,rsi
  408a3c:	mov    rdx,rbx
  408a3f:	mov    r8d,0x30
  408a45:	call   408960 <__swc_fn_65555ab2_000096_f879630a>
  408a4a:	add    rsp,0x30
  408a4e:	pop    rdi
  408a4f:	pop    rsi
  408a50:	pop    rbx
  408a51:	ret
	...

0000000000408a60 <__swc_fn_65555ab2_000102_29a1093a>:
  408a60:	push   rbp
  408a61:	push   rbx
  408a62:	push   rsi
  408a63:	push   rdi
  408a64:	push   r12
  408a66:	push   r13
  408a68:	push   r14
  408a6a:	push   r15
  408a6c:	sub    rsp,0x500
  408a73:	mov    rbp,rsp
  408a76:	mov    rbx,rsp
  408a79:	mov    rsi,rdx
  408a7c:	mov    rdi,rcx
  408a7f:	mov    rcx,QWORD PTR [rip+0x1e2ba]        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  408a86:	test   rcx,rcx
  408a89:	jne    408aa3 <__swc_fn_65555ab2_000102_29a1093a+0x43>
  408a8b:	sub    rsp,0x8
  408a8f:	call   40a1a0 <__swc_fn_65555ab2_000165_e09accff>
  408a94:	add    rsp,0x8
  408a98:	lea    rcx,[rax+0x1]
  408a9c:	mov    QWORD PTR [rip+0x1e29d],rcx        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  408aa3:	dec    rcx
  408aa6:	sub    rsp,0x8
  408aaa:	call   411e00 <__swc_fn_65555ab2_000167_3130645d>
  408aaf:	add    rsp,0x8
  408ab3:	mov    r12,rax
  408ab6:	mov    QWORD PTR [rsp+0x4f0],rax
  408abe:	lea    rax,[rip+0xa83b]        # 413300 <__swc_rdata_base_65555ab2+0x1f0>
  408ac5:	sub    rsp,0x20
  408ac9:	mov    rcx,rsp
  408acc:	mov    QWORD PTR [rcx],rax
  408acf:	lea    r13,[rip+0xa83a]        # 413310 <__swc_rdata_base_65555ab2+0x200>
  408ad6:	mov    QWORD PTR [rcx+0x8],r13
  408ada:	mov    QWORD PTR [rcx+0x10],rsp
  408ade:	mov    QWORD PTR [rcx+0x18],0x1
  408ae6:	lea    rcx,[rsp+0x10]
  408aeb:	sub    rsp,0x8
  408aef:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  408af4:	add    rsp,0x8
  408af8:	add    rsp,0x20
  408afc:	lea    rax,[rip+0xa855]        # 413358 <__swc_rdata_base_65555ab2+0x248>
  408b03:	sub    rsp,0x20
  408b07:	mov    rcx,rsp
  408b0a:	mov    QWORD PTR [rcx],rax
  408b0d:	mov    QWORD PTR [rcx+0x8],r13
  408b11:	mov    QWORD PTR [rcx+0x10],rsp
  408b15:	mov    QWORD PTR [rcx+0x18],0x1
  408b1d:	lea    rcx,[rsp+0x10]
  408b22:	sub    rsp,0x8
  408b26:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  408b2b:	add    rsp,0x8
  408b2f:	add    rsp,0x20
  408b33:	lea    r14,[rip+0xa82e]        # 413368 <__swc_rdata_base_65555ab2+0x258>
  408b3a:	sub    rsp,0x50
  408b3e:	mov    rax,rsp
  408b41:	vmovups xmm0,XMMWORD PTR [rip+0xa957]        # 4134a0 <__swc_rdata_base_65555ab2+0x390>
  408b49:	vmovups XMMWORD PTR [rax],xmm0
  408b4d:	mov    QWORD PTR [rax+0x10],rsp
  408b51:	mov    QWORD PTR [rax+0x18],r13
  408b55:	mov    QWORD PTR [rax+0x20],rdi
  408b59:	lea    rdi,[rip+0xa818]        # 413378 <__swc_rdata_base_65555ab2+0x268>
  408b60:	mov    QWORD PTR [rax+0x28],rdi
  408b64:	mov    QWORD PTR [rax+0x30],r14
  408b68:	mov    QWORD PTR [rax+0x38],r13
  408b6c:	lea    rcx,[rsp+0x10]
  408b71:	mov    QWORD PTR [rax+0x40],rcx
  408b75:	mov    QWORD PTR [rax+0x48],0x3
  408b7d:	lea    rcx,[rsp+0x40]
  408b82:	sub    rsp,0x8
  408b86:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  408b8b:	add    rsp,0x8
  408b8f:	add    rsp,0x50
  408b93:	lea    rax,[rip+0xa826]        # 4133c0 <__swc_rdata_base_65555ab2+0x2b0>
  408b9a:	sub    rsp,0x20
  408b9e:	mov    rcx,rsp
  408ba1:	mov    QWORD PTR [rcx],rax
  408ba4:	mov    QWORD PTR [rcx+0x8],r13
  408ba8:	mov    QWORD PTR [rcx+0x10],rsp
  408bac:	mov    QWORD PTR [rcx+0x18],0x1
  408bb4:	lea    rcx,[rsp+0x10]
  408bb9:	sub    rsp,0x8
  408bbd:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  408bc2:	add    rsp,0x8
  408bc6:	add    rsp,0x20
  408bca:	mov    eax,DWORD PTR [rsi+0x20]
  408bcd:	mov    ecx,DWORD PTR [rsi+0x24]
  408bd0:	sub    rsp,0xa0
  408bd7:	mov    rdx,rsp
  408bda:	mov    QWORD PTR [rdx+0x30],rsi
  408bde:	mov    QWORD PTR [rdx+0x38],rdi
  408be2:	vmovups xmm0,XMMWORD PTR [rip+0xa84e]        # 413438 <__swc_rdata_base_65555ab2+0x328>
  408bea:	vmovups XMMWORD PTR [rdx],xmm0
  408bee:	mov    QWORD PTR [rdx+0x40],rsp
  408bf2:	mov    QWORD PTR [rdx+0x48],r13
  408bf6:	mov    DWORD PTR [rdx+0x10],eax
  408bf9:	lea    rax,[rsp+0x10]
  408bfe:	mov    QWORD PTR [rdx+0x50],rax
  408c02:	lea    rax,[rip+0xa7c7]        # 4133d0 <__swc_rdata_base_65555ab2+0x2c0>
  408c09:	mov    QWORD PTR [rdx+0x58],rax
  408c0d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c12:	lea    r8,[rsp+0x18]
  408c17:	mov    QWORD PTR [rdx+0x60],r8
  408c1b:	mov    QWORD PTR [rdx+0x68],r13
  408c1f:	mov    DWORD PTR [rdx+0x28],ecx
  408c22:	lea    rcx,[rdx+0x28]
  408c26:	mov    QWORD PTR [rdx+0x70],rcx
  408c2a:	mov    QWORD PTR [rdx+0x78],rax
  408c2e:	mov    QWORD PTR [rdx+0x80],r14
  408c35:	mov    QWORD PTR [rdx+0x88],r13
  408c3c:	lea    rax,[rdx+0x30]
  408c40:	mov    QWORD PTR [rdx+0x90],rax
  408c47:	mov    QWORD PTR [rdx+0x98],0x6
  408c52:	lea    rcx,[rdx+0x90]
  408c59:	sub    rsp,0x8
  408c5d:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  408c62:	add    rsp,0x8
  408c66:	add    rsp,0xa0
  408c6d:	sub    rsp,0x20
  408c71:	mov    rax,rsp
  408c74:	mov    QWORD PTR [rax],r14
  408c77:	mov    QWORD PTR [rax+0x8],r13
  408c7b:	mov    QWORD PTR [rax+0x10],rsp
  408c7f:	mov    QWORD PTR [rax+0x18],0x1
  408c87:	lea    rcx,[rsp+0x10]
  408c8c:	sub    rsp,0x8
  408c90:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  408c95:	add    rsp,0x8
  408c99:	add    rsp,0x20
  408c9d:	mov    eax,DWORD PTR [r12+0x9ac]
  408ca5:	test   eax,eax
  408ca7:	je     408ee0 <__swc_fn_65555ab2_000102_29a1093a+0x480>
  408cad:	lea    rax,[rip+0xa764]        # 413418 <__swc_rdata_base_65555ab2+0x308>
  408cb4:	sub    rsp,0x20
  408cb8:	mov    rcx,rsp
  408cbb:	mov    QWORD PTR [rcx],rax
  408cbe:	mov    QWORD PTR [rcx+0x8],r13
  408cc2:	mov    QWORD PTR [rcx+0x10],rsp
  408cc6:	mov    QWORD PTR [rcx+0x18],0x1
  408cce:	lea    rcx,[rsp+0x10]
  408cd3:	sub    rsp,0x8
  408cd7:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  408cdc:	add    rsp,0x8
  408ce0:	add    rsp,0x20
  408ce4:	mov    eax,DWORD PTR [r12+0x9ac]
  408cec:	dec    eax
  408cee:	mov    esi,eax
  408cf0:	test   esi,esi
  408cf2:	jl     408eb0 <__swc_fn_65555ab2_000102_29a1093a+0x450>
  408cf8:	jmp    408d04 <__swc_fn_65555ab2_000102_29a1093a+0x2a4>
  408cfa:	nop    WORD PTR [rax+rax*1+0x0]
  408d00:	dec    esi
  408d02:	jmp    408cf0 <__swc_fn_65555ab2_000102_29a1093a+0x290>
  408d04:	lea    rax,[rip+0xa71d]        # 413428 <__swc_rdata_base_65555ab2+0x318>
  408d0b:	sub    rsp,0x20
  408d0f:	mov    rcx,rsp
  408d12:	mov    QWORD PTR [rcx],rax
  408d15:	mov    QWORD PTR [rcx+0x8],r13
  408d19:	mov    QWORD PTR [rcx+0x10],rsp
  408d1d:	mov    QWORD PTR [rcx+0x18],0x1
  408d25:	lea    rcx,[rsp+0x10]
  408d2a:	sub    rsp,0x8
  408d2e:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  408d33:	add    rsp,0x8
  408d37:	add    rsp,0x20
  408d3b:	movsxd rax,esi
  408d3e:	imul   r15,rax,0x30
  408d42:	add    r15,r12
  408d45:	add    r15,0xf8
  408d4c:	sub    rsp,0x20
  408d50:	mov    rax,rsp
  408d53:	mov    QWORD PTR [rax],r15
  408d56:	mov    QWORD PTR [rax+0x8],rdi
  408d5a:	mov    QWORD PTR [rax+0x10],rsp
  408d5e:	mov    QWORD PTR [rax+0x18],0x1
  408d66:	lea    rcx,[rsp+0x10]
  408d6b:	sub    rsp,0x8
  408d6f:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  408d74:	add    rsp,0x8
  408d78:	add    rsp,0x20
  408d7c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408d84:	lea    rsi,[rip+0xa6ad]        # 413438 <__swc_rdata_base_65555ab2+0x328>
  408d8b:	sub    rsp,0x20
  408d8f:	mov    rax,rsp
  408d92:	mov    QWORD PTR [rax],rsi
  408d95:	mov    QWORD PTR [rax+0x8],r13
  408d99:	mov    QWORD PTR [rax+0x10],rsp
  408d9d:	mov    QWORD PTR [rax+0x18],0x1
  408da5:	lea    rcx,[rsp+0x10]
  408daa:	sub    rsp,0x8
  408dae:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  408db3:	add    rsp,0x8
  408db7:	add    rsp,0x20
  408dbb:	sub    rsp,0x30
  408dbf:	mov    rax,rsp
  408dc2:	mov    ecx,DWORD PTR [r15+0x20]
  408dc6:	mov    QWORD PTR [rax],rcx
  408dc9:	mov    QWORD PTR [rax+0x8],rsp
  408dcd:	lea    rdi,[rip+0xa674]        # 413448 <__swc_rdata_base_65555ab2+0x338>
  408dd4:	mov    QWORD PTR [rax+0x10],rdi
  408dd8:	lea    rcx,[rsp+0x8]
  408ddd:	mov    QWORD PTR [rax+0x18],rcx
  408de1:	mov    QWORD PTR [rax+0x20],0x1
  408de9:	lea    rcx,[rsp+0x18]
  408dee:	sub    rsp,0x8
  408df2:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  408df7:	add    rsp,0x8
  408dfb:	add    rsp,0x30
  408dff:	sub    rsp,0x20
  408e03:	mov    rax,rsp
  408e06:	mov    QWORD PTR [rax],rsi
  408e09:	mov    QWORD PTR [rax+0x8],r13
  408e0d:	mov    QWORD PTR [rax+0x10],rsp
  408e11:	mov    QWORD PTR [rax+0x18],0x1
  408e19:	lea    rcx,[rsp+0x10]
  408e1e:	sub    rsp,0x8
  408e22:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  408e27:	add    rsp,0x8
  408e2b:	add    rsp,0x20
  408e2f:	sub    rsp,0x30
  408e33:	mov    rax,rsp
  408e36:	mov    ecx,DWORD PTR [r15+0x24]
  408e3a:	mov    QWORD PTR [rax],rcx
  408e3d:	mov    QWORD PTR [rax+0x8],rsp
  408e41:	mov    QWORD PTR [rax+0x10],rdi
  408e45:	lea    rcx,[rsp+0x8]
  408e4a:	mov    QWORD PTR [rax+0x18],rcx
  408e4e:	mov    QWORD PTR [rax+0x20],0x1
  408e56:	lea    rcx,[rsp+0x18]
  408e5b:	sub    rsp,0x8
  408e5f:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  408e64:	add    rsp,0x8
  408e68:	add    rsp,0x30
  408e6c:	sub    rsp,0x20
  408e70:	mov    rax,rsp
  408e73:	mov    QWORD PTR [rax],r14
  408e76:	mov    QWORD PTR [rax+0x8],r13
  408e7a:	mov    QWORD PTR [rax+0x10],rsp
  408e7e:	mov    QWORD PTR [rax+0x18],0x1
  408e86:	lea    rcx,[rsp+0x10]
  408e8b:	sub    rsp,0x8
  408e8f:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  408e94:	add    rsp,0x8
  408e98:	add    rsp,0x20
  408e9c:	lea    rdi,[rip+0xa4d5]        # 413378 <__swc_rdata_base_65555ab2+0x268>
  408ea3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408eab:	jmp    408d00 <__swc_fn_65555ab2_000102_29a1093a+0x2a0>
  408eb0:	sub    rsp,0x20
  408eb4:	mov    rax,rsp
  408eb7:	mov    QWORD PTR [rax],r14
  408eba:	mov    QWORD PTR [rax+0x8],r13
  408ebe:	mov    QWORD PTR [rax+0x10],rsp
  408ec2:	mov    QWORD PTR [rax+0x18],0x1
  408eca:	lea    rcx,[rsp+0x10]
  408ecf:	sub    rsp,0x8
  408ed3:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  408ed8:	add    rsp,0x8
  408edc:	add    rsp,0x20
  408ee0:	lea    rax,[rbx+0x28]
  408ee4:	mov    rcx,rax
  408ee7:	mov    QWORD PTR [rbx+0x28],0x0
  408eef:	mov    QWORD PTR [rbx+0x30],0x0
  408ef7:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408efc:	add    rcx,0x10
  408f00:	mov    edx,0x1f
  408f05:	cs nop WORD PTR [rax+rax*1+0x0]
  408f0f:	nop
  408f10:	vmovups XMMWORD PTR [rcx],xmm0
  408f14:	add    rcx,0x10
  408f18:	sub    rdx,0x1
  408f1c:	jne    408f10 <__swc_fn_65555ab2_000102_29a1093a+0x4b0>
  408f1e:	lea    rsi,[rbx+0x228]
  408f25:	xor    ecx,ecx
  408f27:	cs nop WORD PTR [rax+rax*1+0x0]
  408f31:	cs nop WORD PTR [rax+rax*1+0x0]
  408f3b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f40:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f45:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f4a:	add    rcx,0x10
  408f4e:	cmp    rcx,0x200
  408f55:	jne    408f40 <__swc_fn_65555ab2_000102_29a1093a+0x4e0>
  408f57:	mov    eax,DWORD PTR [r12+0xbc8]
  408f5f:	lea    rcx,[r12+0x9c8]
  408f67:	mov    QWORD PTR [rbx+0x428],rcx
  408f6e:	mov    QWORD PTR [rbx+0x430],rax
  408f75:	lea    rdi,[rbx+0x438]
  408f7c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408f84:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408f8c:	mov    eax,DWORD PTR [r12+0xbc8]
  408f94:	test   eax,eax
  408f96:	jne    408fe3 <__swc_fn_65555ab2_000102_29a1093a+0x583>
  408f98:	lea    rax,[rbx+0x448]
  408f9f:	mov    QWORD PTR [rbx+0x448],rsi
  408fa6:	mov    QWORD PTR [rax+0x8],0x40
  408fae:	mov    ecx,0x1
  408fb3:	mov    rdx,rax
  408fb6:	sub    rsp,0x8
  408fba:	call   410160 <__swc_fn_65555ab2_000119_18cd3882>
  408fbf:	add    rsp,0x8
  408fc3:	mov    QWORD PTR [rbx+0x460],rsi
  408fca:	mov    ecx,eax
  408fcc:	mov    QWORD PTR [rbx+0x468],rcx
  408fd3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408fdb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fe3:	mov    rsi,QWORD PTR [rbx+0x438]
  408fea:	mov    rax,QWORD PTR [rbx+0x440]
  408ff1:	mov    r15,rax
  408ff4:	xor    r12d,r12d
  408ff7:	test   r15,r15
  408ffa:	je     4090b0 <__swc_fn_65555ab2_000102_29a1093a+0x650>
  409000:	mov    rax,QWORD PTR [rsi+r12*8]
  409004:	test   rax,rax
  409007:	je     409026 <__swc_fn_65555ab2_000102_29a1093a+0x5c6>
  409009:	lea    rcx,[rbx+0x4b8]
  409010:	mov    rdx,rax
  409013:	sub    rsp,0x8
  409017:	call   409f10 <__swc_fn_65555ab2_000162_edb9cf73>
  40901c:	add    rsp,0x8
  409020:	mov    al,BYTE PTR [rax]
  409022:	test   al,al
  409024:	jne    409032 <__swc_fn_65555ab2_000102_29a1093a+0x5d2>
  409026:	add    r12,0x1
  40902a:	sub    r15,0x1
  40902e:	jne    409000 <__swc_fn_65555ab2_000102_29a1093a+0x5a0>
  409030:	jmp    4090b0 <__swc_fn_65555ab2_000102_29a1093a+0x650>
  409032:	lea    rax,[rip+0xa457]        # 413490 <__swc_rdata_base_65555ab2+0x380>
  409039:	sub    rsp,0x20
  40903d:	mov    rcx,rsp
  409040:	mov    QWORD PTR [rcx],rax
  409043:	mov    QWORD PTR [rcx+0x8],r13
  409047:	mov    QWORD PTR [rcx+0x10],rsp
  40904b:	mov    QWORD PTR [rcx+0x18],0x1
  409053:	lea    rcx,[rsp+0x10]
  409058:	sub    rsp,0x8
  40905c:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  409061:	add    rsp,0x8
  409065:	add    rsp,0x20
  409069:	mov    rcx,rdi
  40906c:	xor    edx,edx
  40906e:	mov    al,0x1
  409070:	mov    r8,rax
  409073:	sub    rsp,0x8
  409077:	call   40d260 <__swc_fn_65555ab2_000163_5fbed98a>
  40907c:	add    rsp,0x8
  409080:	sub    rsp,0x20
  409084:	mov    rax,rsp
  409087:	mov    QWORD PTR [rax],r14
  40908a:	mov    QWORD PTR [rax+0x8],r13
  40908e:	mov    QWORD PTR [rax+0x10],rsp
  409092:	mov    QWORD PTR [rax+0x18],0x1
  40909a:	lea    rcx,[rsp+0x10]
  40909f:	sub    rsp,0x8
  4090a3:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  4090a8:	add    rsp,0x8
  4090ac:	add    rsp,0x20
  4090b0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090b8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090c4:	add    rsp,0x500
  4090cb:	pop    r15
  4090cd:	pop    r14
  4090cf:	pop    r13
  4090d1:	pop    r12
  4090d3:	pop    rdi
  4090d4:	pop    rsi
  4090d5:	pop    rbx
  4090d6:	pop    rbp
  4090d7:	ret
	...

00000000004090e0 <__swc_fn_65555ab2_000105_b7aef7c0>:
  4090e0:	sub    rsp,0x8
  4090e4:	test   r8,r8
  4090e7:	je     4090ee <__swc_fn_65555ab2_000105_b7aef7c0+0xe>
  4090e9:	call   40f890 <__swc_fn_65555ab2_000104_baf871f8>
  4090ee:	add    rsp,0x8
  4090f2:	ret
	...

0000000000409100 <__swc_fn_65555ab2_000108_32416b9e>:
  409100:	push   rsi
  409101:	push   rdi
  409102:	push   r12
  409104:	push   r13
  409106:	sub    rsp,0xd8
  40910d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409113:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  409119:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40911f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  409125:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40912b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  409134:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40913d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  409146:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40914f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  409158:	xor    eax,eax
  40915a:	call   407010 <getpid@plt>
  40915f:	mov    rsi,rax
  409162:	lea    rdi,[rip+0x1dbdf]        # 426d48 <__swc_bss_base_65555ab2+0x2d08>
  409169:	mov    r12,QWORD PTR [rdi]
  40916c:	test   r12,r12
  40916f:	je     40917d <__swc_fn_65555ab2_000108_32416b9e+0x7d>
  409171:	cmp    DWORD PTR [r12+0x10],esi
  409176:	jne    40917d <__swc_fn_65555ab2_000108_32416b9e+0x7d>
  409178:	mov    rax,r12
  40917b:	jmp    4091e0 <__swc_fn_65555ab2_000108_32416b9e+0xe0>
  40917d:	mov    ecx,0x4
  409182:	mov    edx,0x18
  409187:	call   40f970 <__swc_fn_65555ab2_000107_ff529476>
  40918c:	mov    rcx,rax
  40918f:	test   rax,rax
  409192:	jne    409198 <__swc_fn_65555ab2_000108_32416b9e+0x98>
  409194:	xor    eax,eax
  409196:	jmp    4091e0 <__swc_fn_65555ab2_000108_32416b9e+0xe0>
  409198:	mov    DWORD PTR [rcx+0x10],esi
  40919b:	mov    rax,r12
  40919e:	lock cmpxchg QWORD PTR [rdi],rcx
  4091a3:	mov    r13,rax
  4091a6:	cmp    rax,r12
  4091a9:	je     4091bf <__swc_fn_65555ab2_000108_32416b9e+0xbf>
  4091ab:	mov    rdi,rcx
  4091ae:	mov    esi,0x18
  4091b3:	xor    eax,eax
  4091b5:	call   407020 <munmap@plt>
  4091ba:	mov    rax,r13
  4091bd:	jmp    4091e0 <__swc_fn_65555ab2_000108_32416b9e+0xe0>
  4091bf:	test   r12,r12
  4091c2:	je     4091dd <__swc_fn_65555ab2_000108_32416b9e+0xdd>
  4091c4:	mov    rdi,r12
  4091c7:	mov    esi,0x18
  4091cc:	xor    eax,eax
  4091ce:	mov    QWORD PTR [rsp+0x28],rcx
  4091d3:	call   407020 <munmap@plt>
  4091d8:	mov    rcx,QWORD PTR [rsp+0x28]
  4091dd:	mov    rax,rcx
  4091e0:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  4091e6:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  4091ec:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  4091f2:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  4091f8:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  4091fe:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409207:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  409210:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409219:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  409222:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40922b:	add    rsp,0xd8
  409232:	pop    r13
  409234:	pop    r12
  409236:	pop    rdi
  409237:	pop    rsi
  409238:	ret
  409239:	add    BYTE PTR [rax],al
  40923b:	add    BYTE PTR [rax],al
  40923d:	add    BYTE PTR [rax],al
	...

0000000000409240 <__swc_fn_65555ab2_000111_e724f834>:
  409240:	push   rbx
  409241:	push   r12
  409243:	push   rdi
  409244:	push   rsi
  409245:	sub    rsp,0xa8
  40924c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409252:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409258:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40925e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409264:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40926a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409270:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409276:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40927c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409285:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40928e:	mov    rbx,rdx
  409291:	mov    r12,rcx
  409294:	mov    rdi,rcx
  409297:	mov    rsi,rdx
  40929a:	mov    edx,0x3
  40929f:	xor    eax,eax
  4092a1:	call   407030 <mprotect@plt>
  4092a6:	test   eax,eax
  4092a8:	je     4092ae <__swc_fn_65555ab2_000111_e724f834+0x6e>
  4092aa:	xor    eax,eax
  4092ac:	jmp    4092c3 <__swc_fn_65555ab2_000111_e724f834+0x83>
  4092ae:	mov    rcx,r12
  4092b1:	mov    rdx,rbx
  4092b4:	mov    al,0x1
  4092b6:	mov    r8,rax
  4092b9:	call   40ffa0 <__swc_fn_65555ab2_000110_e606239a>
  4092be:	mov    eax,0x1
  4092c3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4092c9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4092cf:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4092d5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4092db:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4092e1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4092e7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4092ed:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4092f3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4092fc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409305:	add    rsp,0xa8
  40930c:	pop    rsi
  40930d:	pop    rdi
  40930e:	pop    r12
  409310:	pop    rbx
  409311:	ret
	...

0000000000409320 <__swc_fn_65555ab2_000114_0575f585>:
  409320:	sub    rsp,0x8
  409324:	test   rcx,rcx
  409327:	jne    40932e <__swc_fn_65555ab2_000114_0575f585+0xe>
  409329:	add    rsp,0x8
  40932d:	ret
  40932e:	call   40c880 <__swc_fn_65555ab2_000115_259b5d5a>
  409333:	add    rsp,0x8
  409337:	ret
	...

0000000000409340 <__swc_fn_65555ab2_000117_76ff2f0a>:
  409340:	push   rdi
  409341:	push   rsi
  409342:	sub    rsp,0xa8
  409349:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40934f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409355:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40935b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409361:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409367:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40936d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409373:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409379:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409382:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40938b:	xor    edi,edi
  40938d:	xor    eax,eax
  40938f:	call   407040 <exit@plt>
  409394:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40939a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4093a0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4093a6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4093ac:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4093b2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4093b8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4093be:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4093c4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4093cd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4093d6:	add    rsp,0xa8
  4093dd:	pop    rsi
  4093de:	pop    rdi
  4093df:	ret

00000000004093e0 <__swc_fn_65555ab2_000120_1601f378>:
  4093e0:	push   rbx
  4093e1:	push   rsi
  4093e2:	push   rdi
  4093e3:	push   r12
  4093e5:	sub    rsp,0x18
  4093e9:	mov    rbx,r8
  4093ec:	mov    rsi,rcx
  4093ef:	mov    rdi,rdx
  4093f2:	mov    rcx,QWORD PTR [rip+0x1d947]        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  4093f9:	test   rcx,rcx
  4093fc:	jne    40940e <__swc_fn_65555ab2_000120_1601f378+0x2e>
  4093fe:	call   40a1a0 <__swc_fn_65555ab2_000165_e09accff>
  409403:	lea    rcx,[rax+0x1]
  409407:	mov    QWORD PTR [rip+0x1d932],rcx        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  40940e:	dec    rcx
  409411:	call   411e00 <__swc_fn_65555ab2_000167_3130645d>
  409416:	mov    r12,rax
  409419:	cmp    ebx,0x3
  40941c:	jne    40942f <__swc_fn_65555ab2_000120_1601f378+0x4f>
  40941e:	mov    rax,QWORD PTR [r12+0xbd0]
  409426:	test   rax,rax
  409429:	jne    40956c <__swc_fn_65555ab2_000120_1601f378+0x18c>
  40942f:	cmp    ebx,0x5
  409432:	jne    409456 <__swc_fn_65555ab2_000120_1601f378+0x76>
  409434:	call   40c150 <__swc_fn_65555ab2_000091_e6773530>
  409439:	test   al,al
  40943b:	jne    409456 <__swc_fn_65555ab2_000120_1601f378+0x76>
  40943d:	mov    rcx,rsi
  409440:	mov    rdx,rdi
  409443:	call   411db0 <__swc_fn_65555ab2_000164_15b66a30>
  409448:	test   al,al
  40944a:	je     409456 <__swc_fn_65555ab2_000120_1601f378+0x76>
  40944c:	add    rsp,0x18
  409450:	pop    r12
  409452:	pop    rdi
  409453:	pop    rsi
  409454:	pop    rbx
  409455:	ret
  409456:	call   40c150 <__swc_fn_65555ab2_000091_e6773530>
  40945b:	test   al,al
  40945d:	jne    4094cf <__swc_fn_65555ab2_000120_1601f378+0xef>
  40945f:	vmovups xmm0,XMMWORD PTR [rsi]
  409463:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409469:	mov    rax,QWORD PTR [rsp+0x8]
  40946e:	test   rax,rax
  409471:	jne    4094c2 <__swc_fn_65555ab2_000120_1601f378+0xe2>
  409473:	cmp    ebx,0x3
  409476:	je     409484 <__swc_fn_65555ab2_000120_1601f378+0xa4>
  409478:	cmp    ebx,0x4
  40947b:	je     409494 <__swc_fn_65555ab2_000120_1601f378+0xb4>
  40947d:	cmp    ebx,0x5
  409480:	je     4094a4 <__swc_fn_65555ab2_000120_1601f378+0xc4>
  409482:	jmp    4094b4 <__swc_fn_65555ab2_000120_1601f378+0xd4>
  409484:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 4134e0 <__swc_rdata_base_65555ab2+0x3d0>
  40948c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409492:	jmp    4094c2 <__swc_fn_65555ab2_000120_1601f378+0xe2>
  409494:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 4134f0 <__swc_rdata_base_65555ab2+0x3e0>
  40949c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094a2:	jmp    4094c2 <__swc_fn_65555ab2_000120_1601f378+0xe2>
  4094a4:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 413500 <__swc_rdata_base_65555ab2+0x3f0>
  4094ac:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094b2:	jmp    4094c2 <__swc_fn_65555ab2_000120_1601f378+0xe2>
  4094b4:	vmovups xmm0,XMMWORD PTR [rip+0xa054]        # 413510 <__swc_rdata_base_65555ab2+0x400>
  4094bc:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094c2:	lea    rcx,[rsp+0x8]
  4094c7:	mov    rdx,rdi
  4094ca:	call   40c3a0 <__swc_fn_65555ab2_000103_2ed36338>
  4094cf:	vmovups xmm0,XMMWORD PTR [rdi]
  4094d3:	vmovups XMMWORD PTR [r12+0x940],xmm0
  4094dd:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  4094e2:	vmovups XMMWORD PTR [r12+0x950],xmm0
  4094ec:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  4094f1:	vmovups XMMWORD PTR [r12+0x960],xmm0
  4094fb:	lea    rax,[r12+0x940]
  409503:	mov    QWORD PTR [r12+0x970],rax
  40950b:	mov    rax,QWORD PTR [rsi]
  40950e:	mov    QWORD PTR [r12+0x978],rax
  409516:	mov    rax,QWORD PTR [rsi+0x8]
  40951a:	mov    QWORD PTR [r12+0x980],rax
  409522:	movsxd rax,ebx
  409525:	mov    QWORD PTR [r12+0x988],rax
  40952d:	cmp    ebx,0x5
  409530:	je     409539 <__swc_fn_65555ab2_000120_1601f378+0x159>
  409532:	xor    ecx,ecx
  409534:	call   40a2d0 <__swc_fn_65555ab2_000174_738eec22>
  409539:	mov    rbx,QWORD PTR [r12+0xbe8]
  409541:	test   rbx,rbx
  409544:	je     409555 <__swc_fn_65555ab2_000120_1601f378+0x175>
  409546:	mov    rcx,r12
  409549:	call   rbx
  40954b:	add    rsp,0x18
  40954f:	pop    r12
  409551:	pop    rdi
  409552:	pop    rsi
  409553:	pop    rbx
  409554:	ret
  409555:	mov    rcx,rsi
  409558:	call   410050 <__swc_fn_65555ab2_000116_3499f7d6>
  40955d:	call   40c9d0 <__swc_fn_65555ab2_000118_2b35b5e0>
  409562:	add    rsp,0x18
  409566:	pop    r12
  409568:	pop    rdi
  409569:	pop    rsi
  40956a:	pop    rbx
  40956b:	ret
  40956c:	mov    rcx,rsi
  40956f:	mov    rdx,rdi
  409572:	call   40c3a0 <__swc_fn_65555ab2_000103_2ed36338>
  409577:	jmp    40942f <__swc_fn_65555ab2_000120_1601f378+0x4f>
  40957c:	add    BYTE PTR [rax],al
	...

0000000000409580 <__swc_fn_65555ab2_000123_e9227a3e>:
  409580:	push   rdi
  409581:	push   rsi
  409582:	sub    rsp,0xb8
  409589:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40958f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409595:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40959b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4095a1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4095a7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4095ad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4095b3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4095bc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4095c5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4095ce:	mov    DWORD PTR [rsp+0x8],0x0
  4095d6:	lea    rdi,[rsp+0x8]
  4095db:	xor    esi,esi
  4095dd:	xor    eax,eax
  4095df:	call   407050 <pthread_key_create@plt>
  4095e4:	test   eax,eax
  4095e6:	jne    4095ee <__swc_fn_65555ab2_000123_e9227a3e+0x6e>
  4095e8:	mov    eax,DWORD PTR [rsp+0x8]
  4095ec:	jmp    4095f5 <__swc_fn_65555ab2_000123_e9227a3e+0x75>
  4095ee:	mov    rax,0xffffffffffffffff
  4095f5:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4095fb:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409601:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409607:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40960d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409613:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409619:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40961f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409628:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409631:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40963a:	add    rsp,0xb8
  409641:	pop    rsi
  409642:	pop    rdi
  409643:	ret
	...

0000000000409650 <__swc_fn_65555ab2_000126_5fb20c72>:
  409650:	push   rdi
  409651:	push   rsi
  409652:	sub    rsp,0xb8
  409659:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40965f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409665:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40966b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409671:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409677:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40967d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409683:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40968c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409695:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40969e:	mov    DWORD PTR [rsp+0x8],0x0
  4096a6:	lea    rdi,[rsp+0x8]
  4096ab:	mov    rsi,rcx
  4096ae:	xor    eax,eax
  4096b0:	call   407050 <pthread_key_create@plt>
  4096b5:	test   eax,eax
  4096b7:	jne    4096c2 <__swc_fn_65555ab2_000126_5fb20c72+0x72>
  4096b9:	mov    eax,DWORD PTR [rsp+0x8]
  4096bd:	inc    rax
  4096c0:	jmp    4096c4 <__swc_fn_65555ab2_000126_5fb20c72+0x74>
  4096c2:	xor    eax,eax
  4096c4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4096ca:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4096d0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4096d6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4096dc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4096e2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4096e8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4096ee:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4096f7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409700:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409709:	add    rsp,0xb8
  409710:	pop    rsi
  409711:	pop    rdi
  409712:	ret
	...

0000000000409720 <__swc_fn_65555ab2_000129_0672cd48>:
  409720:	push   rdi
  409721:	push   rsi
  409722:	sub    rsp,0xa8
  409729:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40972f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409735:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40973b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409741:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409747:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40974d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409753:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409759:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409762:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40976b:	test   rcx,rcx
  40976e:	setne  al
  409771:	je     40978a <__swc_fn_65555ab2_000129_0672cd48+0x6a>
  409773:	lea    rax,[rcx-0x1]
  409777:	mov    eax,eax
  409779:	mov    edi,eax
  40977b:	mov    rsi,rdx
  40977e:	xor    eax,eax
  409780:	call   407060 <pthread_setspecific@plt>
  409785:	test   eax,eax
  409787:	sete   al
  40978a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409790:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409796:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40979c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4097a2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4097a8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4097ae:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4097b4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4097ba:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4097c3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4097cc:	add    rsp,0xa8
  4097d3:	pop    rsi
  4097d4:	pop    rdi
  4097d5:	ret
	...

00000000004097e0 <__swc_fn_65555ab2_000132_2b60f756>:
  4097e0:	push   rdi
  4097e1:	push   rsi
  4097e2:	sub    rsp,0xa8
  4097e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4097ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4097f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4097fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409801:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409807:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40980d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409813:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409819:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409822:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40982b:	mov    rax,rdx
  40982e:	mov    QWORD PTR [rsp],0x0
  409836:	mov    edi,0xca
  40983b:	mov    rsi,rcx
  40983e:	mov    edx,0x81
  409843:	mov    eax,eax
  409845:	mov    ecx,eax
  409847:	xor    r8d,r8d
  40984a:	xor    r9d,r9d
  40984d:	xor    eax,eax
  40984f:	call   407070 <syscall@plt>
  409854:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40985a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409860:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409866:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40986c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409872:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409878:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40987e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409884:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40988d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409896:	add    rsp,0xa8
  40989d:	pop    rsi
  40989e:	pop    rdi
  40989f:	ret

00000000004098a0 <__swc_fn_65555ab2_000135_1fec60ac>:
  4098a0:	sub    rsp,0x8
  4098a4:	call   40cd70 <__swc_fn_65555ab2_000133_c6de0049>
  4098a9:	add    rsp,0x8
  4098ad:	ret
	...

00000000004098b0 <__swc_fn_65555ab2_000138_2214b637>:
  4098b0:	push   rdi
  4098b1:	push   rsi
  4098b2:	sub    rsp,0xc8
  4098b9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4098bf:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4098c5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4098cb:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4098d1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4098d7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4098dd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  4098e6:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  4098ef:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  4098f8:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  409901:	vxorps xmm0,xmm0,xmm0
  409905:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40990b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409911:	mov    rdi,rcx
  409914:	lea    rsi,[rsp+0x8]
  409919:	xor    eax,eax
  40991b:	call   407080 <dladdr@plt>
  409920:	xor    ecx,ecx
  409922:	test   eax,eax
  409924:	je     40992b <__swc_fn_65555ab2_000138_2214b637+0x7b>
  409926:	mov    rcx,QWORD PTR [rsp+0x10]
  40992b:	mov    rax,rcx
  40992e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  409934:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40993a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  409940:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  409946:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40994c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  409952:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40995b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  409964:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40996d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  409976:	add    rsp,0xc8
  40997d:	pop    rsi
  40997e:	pop    rdi
  40997f:	ret

0000000000409980 <__swc_fn_65555ab2_000141_376d5f6d>:
  409980:	push   rbx
  409981:	push   r12
  409983:	push   r13
  409985:	push   rdi
  409986:	push   rsi
  409987:	push   r14
  409989:	push   r15
  40998b:	sub    rsp,0x150
  409992:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40999b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  4099a4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  4099ad:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  4099b6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  4099bf:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4099c8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4099d1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4099da:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  4099e3:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  4099ec:	mov    rbx,rdx
  4099ef:	mov    QWORD PTR [rsp+0x98],rdx
  4099f7:	mov    r12,rcx
  4099fa:	mov    QWORD PTR [rsp+0xa0],rcx
  409a02:	mov    QWORD PTR [rbx],0x0
  409a09:	lea    r13,[rip+0x1d370]        # 426d80 <__swc_bss_base_65555ab2+0x2d40>
  409a10:	mov    rcx,r13
  409a13:	call   4098a0 <__swc_fn_65555ab2_000135_1fec60ac>
  409a18:	mov    rax,QWORD PTR [rip+0x1d369]        # 426d88 <__swc_bss_base_65555ab2+0x2d48>
  409a1f:	test   rax,rax
  409a22:	je     409a59 <__swc_fn_65555ab2_000141_376d5f6d+0xd9>
  409a24:	cs nop WORD PTR [rax+rax*1+0x0]
  409a2e:	xchg   ax,ax
  409a30:	cmp    QWORD PTR [rax+0x8],r12
  409a34:	jne    409a51 <__swc_fn_65555ab2_000141_376d5f6d+0xd1>
  409a36:	mov    rcx,QWORD PTR [rax+0x18]
  409a3a:	mov    QWORD PTR [rbx],rcx
  409a3d:	mov    rbx,QWORD PTR [rax+0x10]
  409a41:	mov    rcx,r13
  409a44:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  409a49:	mov    rax,rbx
  409a4c:	jmp    409c3b <__swc_fn_65555ab2_000141_376d5f6d+0x2bb>
  409a51:	mov    rax,QWORD PTR [rax]
  409a54:	test   rax,rax
  409a57:	jne    409a30 <__swc_fn_65555ab2_000141_376d5f6d+0xb0>
  409a59:	vxorps xmm0,xmm0,xmm0
  409a5d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  409a63:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  409a69:	mov    rdi,r12
  409a6c:	lea    rsi,[rsp+0x10]
  409a71:	xor    eax,eax
  409a73:	call   407080 <dladdr@plt>
  409a78:	test   eax,eax
  409a7a:	sete   al
  409a7d:	je     409a8a <__swc_fn_65555ab2_000141_376d5f6d+0x10a>
  409a7f:	mov    rax,QWORD PTR [rsp+0x10]
  409a84:	test   rax,rax
  409a87:	sete   al
  409a8a:	test   al,al
  409a8c:	je     409a9d <__swc_fn_65555ab2_000141_376d5f6d+0x11d>
  409a8e:	mov    rcx,r13
  409a91:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  409a96:	xor    eax,eax
  409a98:	jmp    409c3b <__swc_fn_65555ab2_000141_376d5f6d+0x2bb>
  409a9d:	mov    rdi,QWORD PTR [rsp+0x10]
  409aa2:	mov    esi,0x80000
  409aa7:	xor    eax,eax
  409aa9:	call   407090 <open@plt>
  409aae:	lea    r14,[rsp+0x30]
  409ab3:	mov    DWORD PTR [rsp+0x30],eax
  409ab7:	cmp    DWORD PTR [r14],0x0
  409abb:	jge    409acc <__swc_fn_65555ab2_000141_376d5f6d+0x14c>
  409abd:	mov    rcx,r13
  409ac0:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  409ac5:	xor    eax,eax
  409ac7:	jmp    409c3b <__swc_fn_65555ab2_000141_376d5f6d+0x2bb>
  409acc:	mov    rax,r14
  409acf:	movsxd rdi,DWORD PTR [rax]
  409ad2:	xor    esi,esi
  409ad4:	mov    edx,0x2
  409ad9:	xor    eax,eax
  409adb:	call   4070a0 <lseek@plt>
  409ae0:	mov    r15,rax
  409ae3:	test   rax,rax
  409ae6:	jg     409b01 <__swc_fn_65555ab2_000141_376d5f6d+0x181>
  409ae8:	movsxd rdi,DWORD PTR [r14]
  409aeb:	xor    eax,eax
  409aed:	call   4070b0 <close@plt>
  409af2:	mov    rcx,r13
  409af5:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  409afa:	xor    eax,eax
  409afc:	jmp    409c3b <__swc_fn_65555ab2_000141_376d5f6d+0x2bb>
  409b01:	xor    edi,edi
  409b03:	mov    rsi,r15
  409b06:	mov    edx,0x1
  409b0b:	mov    ecx,0x2
  409b10:	mov    rax,r14
  409b13:	movsxd r8,DWORD PTR [rax]
  409b16:	xor    r9d,r9d
  409b19:	xor    eax,eax
  409b1b:	call   4070c0 <mmap@plt>
  409b20:	mov    rbx,rax
  409b23:	test   rax,rax
  409b26:	sete   al
  409b29:	cmp    rbx,0xffffffffffffffff
  409b2d:	sete   cl
  409b30:	or     al,cl
  409b32:	je     409b4d <__swc_fn_65555ab2_000141_376d5f6d+0x1cd>
  409b34:	movsxd rdi,DWORD PTR [r14]
  409b37:	xor    eax,eax
  409b39:	call   4070b0 <close@plt>
  409b3e:	mov    rcx,r13
  409b41:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  409b46:	xor    eax,eax
  409b48:	jmp    409c3b <__swc_fn_65555ab2_000141_376d5f6d+0x2bb>
  409b4d:	lea    rax,[rsp+0x50]
  409b52:	mov    QWORD PTR [rax],0x0
  409b59:	mov    rcx,rbx
  409b5c:	mov    rdx,r15
  409b5f:	mov    r8,rax
  409b62:	call   4105e0 <__swc_fn_65555ab2_000140_81b740ca>
  409b67:	mov    r12,rax
  409b6a:	test   rax,rax
  409b6d:	jne    409b95 <__swc_fn_65555ab2_000141_376d5f6d+0x215>
  409b6f:	mov    rdi,rbx
  409b72:	mov    rsi,r15
  409b75:	xor    eax,eax
  409b77:	call   407020 <munmap@plt>
  409b7c:	movsxd rdi,DWORD PTR [r14]
  409b7f:	xor    eax,eax
  409b81:	call   4070b0 <close@plt>
  409b86:	mov    rcx,r13
  409b89:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  409b8e:	xor    eax,eax
  409b90:	jmp    409c3b <__swc_fn_65555ab2_000141_376d5f6d+0x2bb>
  409b95:	mov    edi,0x20
  409b9a:	xor    eax,eax
  409b9c:	call   4070d0 <malloc@plt>
  409ba1:	test   rax,rax
  409ba4:	jne    409bc9 <__swc_fn_65555ab2_000141_376d5f6d+0x249>
  409ba6:	mov    rdi,rbx
  409ba9:	mov    rsi,r15
  409bac:	xor    eax,eax
  409bae:	call   407020 <munmap@plt>
  409bb3:	movsxd rdi,DWORD PTR [r14]
  409bb6:	xor    eax,eax
  409bb8:	call   4070b0 <close@plt>
  409bbd:	mov    rcx,r13
  409bc0:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  409bc5:	xor    eax,eax
  409bc7:	jmp    409c3b <__swc_fn_65555ab2_000141_376d5f6d+0x2bb>
  409bc9:	mov    rcx,QWORD PTR [rip+0x1d1b8]        # 426d88 <__swc_bss_base_65555ab2+0x2d48>
  409bd0:	mov    QWORD PTR [rsp+0x70],rcx
  409bd5:	mov    rcx,QWORD PTR [rsp+0xa0]
  409bdd:	mov    QWORD PTR [rsp+0x78],rcx
  409be2:	mov    QWORD PTR [rsp+0x80],r12
  409bea:	mov    rcx,QWORD PTR [rsp+0x50]
  409bef:	mov    QWORD PTR [rsp+0x88],rcx
  409bf7:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  409bfd:	vmovups XMMWORD PTR [rax],xmm0
  409c01:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  409c0a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  409c0f:	mov    QWORD PTR [rip+0x1d172],rax        # 426d88 <__swc_bss_base_65555ab2+0x2d48>
  409c16:	mov    rax,QWORD PTR [rsp+0x50]
  409c1b:	mov    rbx,QWORD PTR [rsp+0x98]
  409c23:	mov    QWORD PTR [rbx],rax
  409c26:	movsxd rdi,DWORD PTR [r14]
  409c29:	xor    eax,eax
  409c2b:	call   4070b0 <close@plt>
  409c30:	mov    rcx,r13
  409c33:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  409c38:	mov    rax,r12
  409c3b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  409c44:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  409c4d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  409c56:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  409c5f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  409c68:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  409c71:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  409c7a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  409c83:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  409c8c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  409c95:	add    rsp,0x150
  409c9c:	pop    r15
  409c9e:	pop    r14
  409ca0:	pop    rsi
  409ca1:	pop    rdi
  409ca2:	pop    r13
  409ca4:	pop    r12
  409ca6:	pop    rbx
  409ca7:	ret
	...

0000000000409cb0 <__swc_fn_65555ab2_000144_364559f5>:
  409cb0:	push   rbx
  409cb1:	sub    rsp,0xe0
  409cb8:	lea    rbx,[rsp+0x8]
  409cbd:	vxorps xmm0,xmm0,xmm0
  409cc1:	vmovups YMMWORD PTR [rbx],ymm0
  409cc5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  409cca:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  409ccf:	vzeroupper
  409cd2:	mov    DWORD PTR [rbx+0x60],0x0
  409cd9:	mov    r8,rbx
  409cdc:	nop    DWORD PTR [rax+0x0]
  409ce0:	mov    r9,rcx
  409ce3:	movabs rcx,0xcccccccccccccccd
  409ced:	mov    rax,r9
  409cf0:	mul    rcx
  409cf3:	mov    r10,rdx
  409cf6:	shr    r10,0x3
  409cfa:	mov    rcx,r10
  409cfd:	imul   rdx,r10,0xa
  409d01:	sub    r9,rdx
  409d04:	mov    rdx,QWORD PTR [rip+0x9835]        # 413540 <__swc_rdata_base_65555ab2+0x430>
  409d0b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  409d10:	mov    BYTE PTR [r8],dl
  409d13:	lea    rdx,[r8+0x1]
  409d17:	mov    r8,rdx
  409d1a:	test   r10,r10
  409d1d:	jne    409ce0 <__swc_fn_65555ab2_000144_364559f5+0x30>
  409d1f:	mov    BYTE PTR [rdx],0x0
  409d22:	sub    r8,0x1
  409d26:	mov    rax,rbx
  409d29:	cmp    rax,r8
  409d2c:	jae    409d46 <__swc_fn_65555ab2_000144_364559f5+0x96>
  409d2e:	xchg   ax,ax
  409d30:	mov    cl,BYTE PTR [r8]
  409d33:	mov    dl,BYTE PTR [rax]
  409d35:	mov    BYTE PTR [r8],dl
  409d38:	sub    r8,0x1
  409d3c:	mov    BYTE PTR [rax],cl
  409d3e:	inc    rax
  409d41:	cmp    rax,r8
  409d44:	jb     409d30 <__swc_fn_65555ab2_000144_364559f5+0x80>
  409d46:	xor    eax,eax
  409d48:	test   rbx,rbx
  409d4b:	je     409d6e <__swc_fn_65555ab2_000144_364559f5+0xbe>
  409d4d:	mov    rcx,rbx
  409d50:	mov    dl,BYTE PTR [rcx]
  409d52:	test   dl,dl
  409d54:	je     409d6e <__swc_fn_65555ab2_000144_364559f5+0xbe>
  409d56:	cs nop WORD PTR [rax+rax*1+0x0]
  409d60:	add    rcx,0x1
  409d64:	add    rax,0x1
  409d68:	mov    dl,BYTE PTR [rcx]
  409d6a:	test   dl,dl
  409d6c:	jne    409d60 <__swc_fn_65555ab2_000144_364559f5+0xb0>
  409d6e:	mov    QWORD PTR [rbx+0xa8],rbx
  409d75:	mov    QWORD PTR [rbx+0xb0],rax
  409d7c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  409d84:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  409d8c:	lea    rcx,[rbx+0xb8]
  409d93:	call   410050 <__swc_fn_65555ab2_000116_3499f7d6>
  409d98:	add    rsp,0xe0
  409d9f:	pop    rbx
  409da0:	ret
	...

0000000000409db0 <__swc_fn_65555ab2_000147_c9c6528e>:
  409db0:	sub    rsp,0x8
  409db4:	mov    rax,QWORD PTR [rcx+0x8]
  409db8:	mov    r8,QWORD PTR [rdx+0x8]
  409dbc:	cmp    rax,r8
  409dbf:	je     409dc8 <__swc_fn_65555ab2_000147_c9c6528e+0x18>
  409dc1:	xor    eax,eax
  409dc3:	add    rsp,0x8
  409dc7:	ret
  409dc8:	test   rax,rax
  409dcb:	jne    409ddc <__swc_fn_65555ab2_000147_c9c6528e+0x2c>
  409dcd:	test   r8,r8
  409dd0:	jne    409ddc <__swc_fn_65555ab2_000147_c9c6528e+0x2c>
  409dd2:	mov    eax,0x1
  409dd7:	add    rsp,0x8
  409ddb:	ret
  409ddc:	mov    rcx,QWORD PTR [rcx]
  409ddf:	mov    rdx,QWORD PTR [rdx]
  409de2:	test   rcx,rcx
  409de5:	sete   r8b
  409de9:	test   rdx,rdx
  409dec:	sete   r9b
  409df0:	or     r8b,r9b
  409df3:	je     409e00 <__swc_fn_65555ab2_000147_c9c6528e+0x50>
  409df5:	cmp    rcx,rdx
  409df8:	sete   al
  409dfb:	add    rsp,0x8
  409dff:	ret
  409e00:	cmp    rcx,rdx
  409e03:	jne    409e0f <__swc_fn_65555ab2_000147_c9c6528e+0x5f>
  409e05:	mov    eax,0x1
  409e0a:	add    rsp,0x8
  409e0e:	ret
  409e0f:	mov    r8,rax
  409e12:	call   40c460 <__swc_fn_65555ab2_000106_77a5d54a>
  409e17:	test   eax,eax
  409e19:	sete   al
  409e1c:	add    rsp,0x8
  409e20:	ret
	...

0000000000409e30 <__swc_fn_65555ab2_000150_33e5e24f>:
  409e30:	vxorps xmm0,xmm0,xmm0
  409e34:	vmovups XMMWORD PTR [rcx],xmm0
  409e38:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e3d:	vxorps xmm0,xmm0,xmm0
  409e41:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e46:	vmovups xmm0,XMMWORD PTR [rip+0x97aa]        # 4135f8 <__swc_rdata_base_65555ab2+0x4e8>
  409e4e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e53:	ret
	...

0000000000409e60 <__swc_fn_65555ab2_000153_33e5e24f>:
  409e60:	vxorps xmm0,xmm0,xmm0
  409e64:	vmovups XMMWORD PTR [rcx],xmm0
  409e68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e6d:	vxorps xmm0,xmm0,xmm0
  409e71:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e76:	vmovups xmm0,XMMWORD PTR [rip+0x989a]        # 413718 <__swc_rdata_base_65555ab2+0x608>
  409e7e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e83:	mov    QWORD PTR [rcx+0x40],0x0
  409e8b:	ret
  409e8c:	add    BYTE PTR [rax],al
	...

0000000000409e90 <__swc_fn_65555ab2_000156_312df05a>:
  409e90:	push   rbx
  409e91:	sub    rsp,0x70
  409e95:	mov    rax,QWORD PTR [rcx]
  409e98:	mov    rbx,QWORD PTR [rcx+0x8]
  409e9c:	vxorps xmm0,xmm0,xmm0
  409ea0:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  409ea6:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  409eac:	vzeroupper
  409eaf:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  409eb5:	mov    QWORD PTR [rsp+0x48],rdx
  409eba:	mov    QWORD PTR [rsp+0x50],r8
  409ebf:	mov    rcx,rax
  409ec2:	lea    rdx,[rsp+0x8]
  409ec7:	mov    rbx,QWORD PTR [rbx+0x18]
  409ecb:	call   rbx
  409ecd:	add    rsp,0x70
  409ed1:	pop    rbx
  409ed2:	ret
	...

0000000000409ee0 <__swc_fn_65555ab2_000159_9d602c76>:
  409ee0:	push   rbx
  409ee1:	push   rsi
  409ee2:	push   rdi
  409ee3:	mov    rbx,r8
  409ee6:	mov    rsi,rcx
  409ee9:	mov    rdi,rdx
  409eec:	call   40d170 <__swc_fn_65555ab2_000157_5c8b11d8>
  409ef1:	vmovups xmm0,XMMWORD PTR [rbx]
  409ef5:	vmovups XMMWORD PTR [rsi],xmm0
  409ef9:	mov    QWORD PTR [rsi+0x18],rdi
  409efd:	pop    rdi
  409efe:	pop    rsi
  409eff:	pop    rbx
  409f00:	ret
	...

0000000000409f10 <__swc_fn_65555ab2_000162_edb9cf73>:
  409f10:	push   rbx
  409f11:	push   rsi
  409f12:	push   rdi
  409f13:	push   r12
  409f15:	push   r13
  409f17:	sub    rsp,0x50
  409f1b:	mov    rbx,rcx
  409f1e:	mov    rsi,rdx
  409f21:	vmovups xmm0,XMMWORD PTR [rip+0x98ff]        # 413828 <__swc_rdata_base_65555ab2+0x718>
  409f29:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409f2f:	vmovups xmm0,XMMWORD PTR [rip+0x9901]        # 413838 <__swc_rdata_base_65555ab2+0x728>
  409f37:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409f3d:	vxorps xmm0,xmm0,xmm0
  409f41:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409f47:	mov    rcx,rdx
  409f4a:	call   4098b0 <__swc_fn_65555ab2_000138_2214b637>
  409f4f:	mov    rdi,rax
  409f52:	test   rax,rax
  409f55:	jne    409f86 <__swc_fn_65555ab2_000162_edb9cf73+0x76>
  409f57:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409f5d:	vmovups XMMWORD PTR [rbx],xmm0
  409f61:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409f67:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409f6c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409f72:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409f77:	mov    rax,rbx
  409f7a:	add    rsp,0x50
  409f7e:	pop    r13
  409f80:	pop    r12
  409f82:	pop    rdi
  409f83:	pop    rsi
  409f84:	pop    rbx
  409f85:	ret
  409f86:	mov    rcx,rdi
  409f89:	call   411b00 <__swc_fn_65555ab2_000161_9e36e814>
  409f8e:	mov    r11,rax
  409f91:	test   rax,rax
  409f94:	je     409f9e <__swc_fn_65555ab2_000162_edb9cf73+0x8e>
  409f96:	mov    al,BYTE PTR [r11+0x24]
  409f9a:	test   al,al
  409f9c:	jne    409fcd <__swc_fn_65555ab2_000162_edb9cf73+0xbd>
  409f9e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fa4:	vmovups XMMWORD PTR [rbx],xmm0
  409fa8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fae:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fb3:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fb9:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fbe:	mov    rax,rbx
  409fc1:	add    rsp,0x50
  409fc5:	pop    r13
  409fc7:	pop    r12
  409fc9:	pop    rdi
  409fca:	pop    rsi
  409fcb:	pop    rbx
  409fcc:	ret
  409fcd:	sub    rsi,rdi
  409fd0:	mov    eax,0xffffffff
  409fd5:	cmp    rsi,rax
  409fd8:	jbe    40a009 <__swc_fn_65555ab2_000162_edb9cf73+0xf9>
  409fda:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fe0:	vmovups XMMWORD PTR [rbx],xmm0
  409fe4:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fea:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fef:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409ff5:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409ffa:	mov    rax,rbx
  409ffd:	add    rsp,0x50
  40a001:	pop    r13
  40a003:	pop    r12
  40a005:	pop    rdi
  40a006:	pop    rsi
  40a007:	pop    rbx
  40a008:	ret
  40a009:	mov    rdi,QWORD PTR [r11+0x10]
  40a00d:	mov    eax,DWORD PTR [r11+0x20]
  40a011:	xor    ecx,ecx
  40a013:	test   rax,rax
  40a016:	jbe    40a168 <__swc_fn_65555ab2_000162_edb9cf73+0x258>
  40a01c:	nop    DWORD PTR [rax+0x0]
  40a020:	mov    edx,ecx
  40a022:	imul   r12,rdx,0x14
  40a026:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40a02b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40a030:	mov    r9d,esi
  40a033:	cmp    r9,rdx
  40a036:	jb     40a15b <__swc_fn_65555ab2_000162_edb9cf73+0x24b>
  40a03c:	add    rdx,r8
  40a03f:	mov    r8d,esi
  40a042:	cmp    r8,rdx
  40a045:	jae    40a15b <__swc_fn_65555ab2_000162_edb9cf73+0x24b>
  40a04b:	lea    rsi,[rsp+0x38]
  40a050:	mov    eax,DWORD PTR [rdi+0xc]
  40a053:	mov    DWORD PTR [rsp+0x38],eax
  40a057:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40a05c:	mov    rcx,rdi
  40a05f:	mov    rdx,QWORD PTR [r11+0x18]
  40a063:	mov    r8,rsi
  40a066:	mov    r8d,DWORD PTR [r8]
  40a069:	mov    r9,rax
  40a06c:	lea    r10,[rsp+0x10]
  40a071:	call   40d1c0 <__swc_fn_65555ab2_000160_e25d06b9>
  40a076:	test   al,al
  40a078:	jne    40a0ab <__swc_fn_65555ab2_000162_edb9cf73+0x19b>
  40a07a:	vmovups xmm0,XMMWORD PTR [rip+0x97d6]        # 413858 <__swc_rdata_base_65555ab2+0x748>
  40a082:	vmovups XMMWORD PTR [rbx],xmm0
  40a086:	vmovups xmm0,XMMWORD PTR [rip+0x97da]        # 413868 <__swc_rdata_base_65555ab2+0x758>
  40a08e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a093:	vxorps xmm0,xmm0,xmm0
  40a097:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a09c:	mov    rax,rbx
  40a09f:	add    rsp,0x50
  40a0a3:	pop    r13
  40a0a5:	pop    r12
  40a0a7:	pop    rdi
  40a0a8:	pop    rsi
  40a0a9:	pop    rbx
  40a0aa:	ret
  40a0ab:	lea    r13,[rsp+0x3c]
  40a0b0:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40a0b5:	mov    DWORD PTR [rsp+0x3c],eax
  40a0b9:	test   eax,eax
  40a0bb:	je     40a10c <__swc_fn_65555ab2_000162_edb9cf73+0x1fc>
  40a0bd:	mov    rcx,rdi
  40a0c0:	mov    rdx,QWORD PTR [r11+0x18]
  40a0c4:	mov    r8d,DWORD PTR [rsi]
  40a0c7:	mov    rax,r13
  40a0ca:	mov    r9d,DWORD PTR [rax]
  40a0cd:	lea    r10,[rsp+0x20]
  40a0d2:	call   40d1c0 <__swc_fn_65555ab2_000160_e25d06b9>
  40a0d7:	test   al,al
  40a0d9:	jne    40a10c <__swc_fn_65555ab2_000162_edb9cf73+0x1fc>
  40a0db:	vmovups xmm0,XMMWORD PTR [rip+0x97a5]        # 413888 <__swc_rdata_base_65555ab2+0x778>
  40a0e3:	vmovups XMMWORD PTR [rbx],xmm0
  40a0e7:	vmovups xmm0,XMMWORD PTR [rip+0x97a9]        # 413898 <__swc_rdata_base_65555ab2+0x788>
  40a0ef:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a0f4:	vxorps xmm0,xmm0,xmm0
  40a0f8:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a0fd:	mov    rax,rbx
  40a100:	add    rsp,0x50
  40a104:	pop    r13
  40a106:	pop    r12
  40a108:	pop    rdi
  40a109:	pop    rsi
  40a10a:	pop    rbx
  40a10b:	ret
  40a10c:	mov    eax,0x1
  40a111:	rex mov BYTE PTR [rsp+0x8],al
  40a116:	cmp    DWORD PTR [r13+0x0],0x0
  40a11b:	je     40a12c <__swc_fn_65555ab2_000162_edb9cf73+0x21c>
  40a11d:	rex mov BYTE PTR [rsp+0x9],0x1
  40a123:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40a128:	mov    DWORD PTR [rsp+0x30],eax
  40a12c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a132:	vmovups XMMWORD PTR [rbx],xmm0
  40a136:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a13c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a141:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a147:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a14c:	mov    rax,rbx
  40a14f:	add    rsp,0x50
  40a153:	pop    r13
  40a155:	pop    r12
  40a157:	pop    rdi
  40a158:	pop    rsi
  40a159:	pop    rbx
  40a15a:	ret
  40a15b:	add    rcx,0x1
  40a15f:	cmp    rcx,rax
  40a162:	jb     40a020 <__swc_fn_65555ab2_000162_edb9cf73+0x110>
  40a168:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a16e:	vmovups XMMWORD PTR [rbx],xmm0
  40a172:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a178:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a17d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a183:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a188:	mov    rax,rbx
  40a18b:	add    rsp,0x50
  40a18f:	pop    r13
  40a191:	pop    r12
  40a193:	pop    rdi
  40a194:	pop    rsi
  40a195:	pop    rbx
  40a196:	ret
	...

000000000040a1a0 <__swc_fn_65555ab2_000165_e09accff>:
  40a1a0:	sub    rsp,0x48
  40a1a4:	call   409580 <__swc_fn_65555ab2_000123_e9227a3e>
  40a1a9:	cmp    rax,0xffffffffffffffff
  40a1ad:	je     40a1b4 <__swc_fn_65555ab2_000165_e09accff+0x14>
  40a1af:	add    rsp,0x48
  40a1b3:	ret
  40a1b4:	lea    rcx,[rip+0x970d]        # 4138c8 <__swc_rdata_base_65555ab2+0x7b8>
  40a1bb:	vmovups xmm0,XMMWORD PTR [rip+0x9715]        # 4138d8 <__swc_rdata_base_65555ab2+0x7c8>
  40a1c3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a1c9:	vmovups xmm0,XMMWORD PTR [rip+0x9717]        # 4138e8 <__swc_rdata_base_65555ab2+0x7d8>
  40a1d1:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a1d7:	vmovups xmm0,XMMWORD PTR [rip+0x9719]        # 4138f8 <__swc_rdata_base_65555ab2+0x7e8>
  40a1df:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a1e5:	lea    rdx,[rsp+0x8]
  40a1ea:	mov    QWORD PTR [rsp+0x38],rax
  40a1ef:	call   40c3a0 <__swc_fn_65555ab2_000103_2ed36338>
  40a1f4:	mov    rax,QWORD PTR [rsp+0x38]
  40a1f9:	jmp    40a1af <__swc_fn_65555ab2_000165_e09accff+0xf>
  40a1fb:	add    BYTE PTR [rax],al
  40a1fd:	add    BYTE PTR [rax],al
	...

000000000040a200 <__swc_fn_65555ab2_000168_0ff0458f>:
  40a200:	push   rbx
  40a201:	push   rsi
  40a202:	sub    rsp,0x28
  40a206:	mov    rbx,rcx
  40a209:	mov    DWORD PTR [rsp+0x8],0xbf0
  40a211:	mov    ecx,0xbf0
  40a216:	call   40bf90 <__swc_fn_65555ab2_000079_29fad089>
  40a21b:	mov    rsi,rax
  40a21e:	test   rax,rax
  40a221:	jne    40a22c <__swc_fn_65555ab2_000168_0ff0458f+0x2c>
  40a223:	xor    eax,eax
  40a225:	add    rsp,0x28
  40a229:	pop    rsi
  40a22a:	pop    rbx
  40a22b:	ret
  40a22c:	vxorps xmm0,xmm0,xmm0
  40a230:	xor    eax,eax
  40a232:	cs nop WORD PTR [rax+rax*1+0x0]
  40a23c:	nop    DWORD PTR [rax+0x0]
  40a240:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40a245:	add    rax,0x10
  40a249:	cmp    rax,0xbf0
  40a250:	jne    40a240 <__swc_fn_65555ab2_000168_0ff0458f+0x40>
  40a252:	lea    rax,[rbx+0x1]
  40a256:	mov    QWORD PTR [rsi+0x9c0],rax
  40a25d:	mov    rcx,rbx
  40a260:	mov    rdx,rsi
  40a263:	call   40d520 <__swc_fn_65555ab2_000166_31ca4f53>
  40a268:	test   al,al
  40a26a:	jne    40a27d <__swc_fn_65555ab2_000168_0ff0458f+0x7d>
  40a26c:	mov    rcx,rsi
  40a26f:	call   40efd0 <__swc_fn_65555ab2_000080_851c599a>
  40a274:	xor    eax,eax
  40a276:	add    rsp,0x28
  40a27a:	pop    rsi
  40a27b:	pop    rbx
  40a27c:	ret
  40a27d:	lea    rcx,[rsp+0x18]
  40a282:	call   40f550 <__swc_fn_65555ab2_000092_17e20532>
  40a287:	mov    rax,rsi
  40a28a:	add    rsp,0x28
  40a28e:	pop    rsi
  40a28f:	pop    rbx
  40a290:	ret
	...

000000000040a2a0 <__swc_fn_65555ab2_000171_06b64c88>:
  40a2a0:	xor    eax,eax
  40a2a2:	mov    edx,0x1
  40a2a7:	lock cmpxchg QWORD PTR [rcx],rdx
  40a2ac:	test   rax,rax
  40a2af:	jne    40a2b2 <__swc_fn_65555ab2_000171_06b64c88+0x12>
  40a2b1:	ret
  40a2b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2bc:	nop    DWORD PTR [rax+0x0]
  40a2c0:	mov    rax,QWORD PTR [rcx]
  40a2c3:	test   rax,rax
  40a2c6:	je     40a2a0 <__swc_fn_65555ab2_000171_06b64c88>
  40a2c8:	jmp    40a2c0 <__swc_fn_65555ab2_000171_06b64c88+0x20>
  40a2ca:	add    BYTE PTR [rax],al
  40a2cc:	add    BYTE PTR [rax],al
	...

000000000040a2d0 <__swc_fn_65555ab2_000174_738eec22>:
  40a2d0:	push   rsi
  40a2d1:	push   rdi
  40a2d2:	sub    rsp,0x38
  40a2d6:	mov    rsi,rcx
  40a2d9:	call   40d530 <__swc_fn_65555ab2_000169_aabbfb4c>
  40a2de:	mov    rdi,rax
  40a2e1:	call   40ccc0 <__swc_fn_65555ab2_000130_d2d78689>
  40a2e6:	mov    r8,rax
  40a2e9:	mov    rcx,rdi
  40a2ec:	call   40a2a0 <__swc_fn_65555ab2_000171_06b64c88>
  40a2f1:	mov    rax,QWORD PTR [rdi+0x8]
  40a2f5:	test   rax,rax
  40a2f8:	je     40a335 <__swc_fn_65555ab2_000174_738eec22+0x65>
  40a2fa:	nop    WORD PTR [rax+rax*1+0x0]
  40a300:	cmp    rax,rsi
  40a303:	je     40a335 <__swc_fn_65555ab2_000174_738eec22+0x65>
  40a305:	mov    r9,QWORD PTR [rax]
  40a308:	cmp    QWORD PTR [rax+0x20],r8
  40a30c:	jne    40a32d <__swc_fn_65555ab2_000174_738eec22+0x5d>
  40a30e:	mov    rcx,rdi
  40a311:	mov    rdx,rax
  40a314:	mov    QWORD PTR [rsp+0x28],r8
  40a319:	mov    QWORD PTR [rsp+0x30],r9
  40a31e:	call   411f20 <__swc_fn_65555ab2_000173_156cb9fe>
  40a323:	mov    r8,QWORD PTR [rsp+0x28]
  40a328:	mov    r9,QWORD PTR [rsp+0x30]
  40a32d:	mov    rax,r9
  40a330:	test   r9,r9
  40a333:	jne    40a300 <__swc_fn_65555ab2_000174_738eec22+0x30>
  40a335:	xor    eax,eax
  40a337:	mov    QWORD PTR [rdi],rax
  40a33a:	add    rsp,0x38
  40a33e:	pop    rdi
  40a33f:	pop    rsi
  40a340:	ret
	...

000000000040a350 <__swc_fn_65555ab2_000177_1ca87929>:
  40a350:	push   rdi
  40a351:	push   rsi
  40a352:	sub    rsp,0xb8
  40a359:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40a35f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40a365:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40a36b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40a371:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40a377:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40a37d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40a383:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40a38c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40a395:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40a39e:	vxorps xmm0,xmm0,xmm0
  40a3a2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a3a8:	mov    edi,0x1
  40a3ad:	lea    rsi,[rsp+0x8]
  40a3b2:	xor    eax,eax
  40a3b4:	call   4070e0 <clock_gettime@plt>
  40a3b9:	vxorpd xmm0,xmm0,xmm0
  40a3bd:	mov    rax,QWORD PTR [rsp+0x8]
  40a3c2:	vcvtsi2sd xmm0,xmm0,rax
  40a3c7:	vxorpd xmm1,xmm1,xmm1
  40a3cb:	mov    rax,QWORD PTR [rsp+0x10]
  40a3d0:	vcvtsi2sd xmm1,xmm1,rax
  40a3d5:	vdivsd xmm1,xmm1,QWORD PTR [rip+0x952b]        # 413908 <__swc_rdata_base_65555ab2+0x7f8>
  40a3dd:	vaddsd xmm0,xmm0,xmm1
  40a3e1:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40a3e7:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40a3ed:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40a3f3:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40a3f9:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40a3ff:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40a405:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40a40b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40a414:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40a41d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40a426:	add    rsp,0xb8
  40a42d:	pop    rsi
  40a42e:	pop    rdi
  40a42f:	ret
	...

000000000040a440 <__swc_fn_65555ab2_000001_29b04951>:
  40a440:	vxorps xmm0,xmm0,xmm0
  40a444:	xor    eax,eax
  40a446:	cs nop WORD PTR [rax+rax*1+0x0]
  40a450:	cs nop WORD PTR [rax+rax*1+0x0]
  40a45a:	nop    WORD PTR [rax+rax*1+0x0]
  40a460:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a465:	add    rax,0x10
  40a469:	cmp    rax,0x2080
  40a470:	jne    40a460 <__swc_fn_65555ab2_000001_29b04951+0x20>
  40a472:	ret
	...

000000000040a480 <__swc_fn_65555ab2_000004_2fa5c690>:
  40a480:	push   rsi
  40a481:	push   rdi
  40a482:	push   r12
  40a484:	push   r13
  40a486:	push   r14
  40a488:	mov    rsi,rcx
  40a48b:	mov    edi,r10d
  40a48e:	mov    r12,rcx
  40a491:	mov    r13,r9
  40a494:	mov    ecx,DWORD PTR [rdx+0x28]
  40a497:	shlx   r14d,r8d,ecx
  40a49c:	mov    rcx,rdx
  40a49f:	mov    edx,r8d
  40a4a2:	call   40dea0 <__swc_fn_65555ab2_000011_e75d466d>
  40a4a7:	mov    rcx,rax
  40a4aa:	mov    eax,DWORD PTR [r12+0x3c]
  40a4af:	xor    edx,edx
  40a4b1:	div    rdi
  40a4b4:	vxorps xmm0,xmm0,xmm0
  40a4b8:	vmovdqu XMMWORD PTR [rsi],xmm0
  40a4bc:	mov    QWORD PTR [r12+0x60],0x0
  40a4c5:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40a4ca:	mov    QWORD PTR [r12+0x10],rcx
  40a4cf:	imul   rax,rdi
  40a4d3:	lea    rdx,[rcx+rax*1]
  40a4d7:	mov    QWORD PTR [r12+0x18],rdx
  40a4dc:	mov    QWORD PTR [r12+0x20],rcx
  40a4e1:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40a4e6:	mov    DWORD PTR [r12+0x28],0x0
  40a4ef:	mov    DWORD PTR [r12+0x68],0x0
  40a4f8:	mov    BYTE PTR [r12+0x39],r13b
  40a4fd:	mov    BYTE PTR [r12+0x3a],r14b
  40a502:	mov    BYTE PTR [r12+0x3b],0x1
  40a508:	mov    DWORD PTR [r12+0x6c],0x0
  40a511:	mov    rcx,r12
  40a514:	mov    edx,edi
  40a516:	call   40de00 <__swc_fn_65555ab2_000005_bcc5b80b>
  40a51b:	pop    r14
  40a51d:	pop    r13
  40a51f:	pop    r12
  40a521:	pop    rdi
  40a522:	pop    rsi
  40a523:	ret
	...

000000000040a530 <__swc_fn_65555ab2_000007_635028f3>:
  40a530:	mov    r8d,0x1
  40a536:	xor    eax,eax
  40a538:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40a53e:	test   eax,eax
  40a540:	jne    40a530 <__swc_fn_65555ab2_000007_635028f3>
  40a542:	ret
	...

000000000040a550 <__swc_fn_65555ab2_000010_186cd0c2>:
  40a550:	lea    r8,[rcx+0x60]
  40a554:	mov    rax,QWORD PTR [r8]
  40a557:	mov    r9,rax
  40a55a:	nop    WORD PTR [rax+rax*1+0x0]
  40a560:	mov    QWORD PTR [rdx],r9
  40a563:	mov    rax,r9
  40a566:	lock cmpxchg QWORD PTR [r8],rdx
  40a56b:	cmp    rax,r9
  40a56e:	jne    40a5d7 <__swc_fn_65555ab2_000010_186cd0c2+0x87>
  40a570:	mov    eax,DWORD PTR [rcx+0x6c]
  40a573:	test   eax,eax
  40a575:	je     40a5d6 <__swc_fn_65555ab2_000010_186cd0c2+0x86>
  40a577:	lea    rdx,[rcx+0x70]
  40a57b:	mov    r9d,0x1
  40a581:	xor    eax,eax
  40a583:	lock cmpxchg DWORD PTR [rdx],r9d
  40a588:	test   eax,eax
  40a58a:	jne    40a5d6 <__swc_fn_65555ab2_000010_186cd0c2+0x86>
  40a58c:	mov    rax,rcx
  40a58f:	and    rax,0xffffffffffc00000
  40a596:	mov    rax,QWORD PTR [rax+0x8]
  40a59a:	test   rax,rax
  40a59d:	jne    40a5a5 <__swc_fn_65555ab2_000010_186cd0c2+0x55>
  40a59f:	xor    eax,eax
  40a5a1:	xchg   DWORD PTR [rdx],eax
  40a5a3:	jmp    40a5d6 <__swc_fn_65555ab2_000010_186cd0c2+0x86>
  40a5a5:	lea    rdx,[rax+0x2a80]
  40a5ac:	mov    rax,QWORD PTR [rdx]
  40a5af:	mov    r8,rax
  40a5b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a5bc:	nop    DWORD PTR [rax+0x0]
  40a5c0:	mov    QWORD PTR [rcx+0x78],r8
  40a5c4:	mov    rax,r8
  40a5c7:	lock cmpxchg QWORD PTR [rdx],rcx
  40a5cc:	cmp    rax,r8
  40a5cf:	je     40a5d6 <__swc_fn_65555ab2_000010_186cd0c2+0x86>
  40a5d1:	mov    r8,rax
  40a5d4:	jmp    40a5c0 <__swc_fn_65555ab2_000010_186cd0c2+0x70>
  40a5d6:	ret
  40a5d7:	mov    r9,rax
  40a5da:	jmp    40a560 <__swc_fn_65555ab2_000010_186cd0c2+0x10>
	...

000000000040a5e0 <__swc_fn_65555ab2_000013_d15d37c6>:
  40a5e0:	push   rsi
  40a5e1:	push   rdi
  40a5e2:	push   r12
  40a5e4:	push   r13
  40a5e6:	push   r14
  40a5e8:	push   r15
  40a5ea:	push   rbx
  40a5eb:	sub    rsp,0x30
  40a5ef:	mov    QWORD PTR [rsp+0x18],r8
  40a5f4:	mov    rsi,rcx
  40a5f7:	mov    rdi,rdx
  40a5fa:	mov    rdx,QWORD PTR [rsi+0x40]
  40a5fe:	xchg   ax,ax
  40a600:	mov    rax,rdx
  40a603:	not    rax
  40a606:	and    rax,QWORD PTR [rsi+0x20]
  40a60a:	test   rax,rax
  40a60d:	jne    40a621 <__swc_fn_65555ab2_000013_d15d37c6+0x41>
  40a60f:	xor    eax,eax
  40a611:	add    rsp,0x30
  40a615:	pop    rbx
  40a616:	pop    r15
  40a618:	pop    r14
  40a61a:	pop    r13
  40a61c:	pop    r12
  40a61e:	pop    rdi
  40a61f:	pop    rsi
  40a620:	ret
  40a621:	xor    ecx,ecx
  40a623:	tzcnt  rcx,rax
  40a628:	lea    r12,[rsp+0x8]
  40a62d:	mov    DWORD PTR [rsp+0x8],ecx
  40a631:	mov    r13d,0x1
  40a637:	shl    r13,cl
  40a63a:	mov    rcx,rdx
  40a63d:	or     rcx,r13
  40a640:	mov    rax,rdx
  40a643:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40a649:	cmp    rax,rdx
  40a64c:	je     40a653 <__swc_fn_65555ab2_000013_d15d37c6+0x73>
  40a64e:	mov    rdx,rax
  40a651:	jmp    40a600 <__swc_fn_65555ab2_000013_d15d37c6+0x20>
  40a653:	mov    eax,DWORD PTR [r12]
  40a657:	shl    rax,0x4
  40a65b:	lea    r14,[rsi+rax*8+0x80]
  40a663:	mov    rcx,rsi
  40a666:	mov    rax,r12
  40a669:	mov    edx,DWORD PTR [rax]
  40a66b:	call   40dea0 <__swc_fn_65555ab2_000011_e75d466d>
  40a670:	mov    r15,rax
  40a673:	mov    rcx,rsi
  40a676:	mov    rdx,r13
  40a679:	call   40e000 <__swc_fn_65555ab2_000017_e238d24c>
  40a67e:	test   al,al
  40a680:	je     40a6b8 <__swc_fn_65555ab2_000013_d15d37c6+0xd8>
  40a682:	mov    ecx,DWORD PTR [r14+0x3c]
  40a686:	lea    rdx,[rip+0x199cb]        # 424058 <__swc_bss_base_65555ab2+0x18>
  40a68d:	mov    r8,QWORD PTR [rip+0x199c4]        # 424058 <__swc_bss_base_65555ab2+0x18>
  40a694:	cs nop WORD PTR [rax+rax*1+0x0]
  40a69e:	xchg   ax,ax
  40a6a0:	mov    r9,r8
  40a6a3:	sub    r9,rcx
  40a6a6:	mov    rax,r8
  40a6a9:	lock cmpxchg QWORD PTR [rdx],r9
  40a6ae:	cmp    rax,r8
  40a6b1:	je     40a719 <__swc_fn_65555ab2_000013_d15d37c6+0x139>
  40a6b3:	mov    r8,rax
  40a6b6:	jmp    40a6a0 <__swc_fn_65555ab2_000013_d15d37c6+0xc0>
  40a6b8:	mov    rcx,rsi
  40a6bb:	mov    rax,r12
  40a6be:	mov    edx,DWORD PTR [rax]
  40a6c0:	call   407450 <__swc_fn_65555ab2_000012_39679ef8>
  40a6c5:	mov    rcx,r15
  40a6c8:	and    rcx,0xffffffffffff0000
  40a6cf:	lea    rcx,[rcx+0x10000]
  40a6d6:	mov    rbx,rax
  40a6d9:	cmp    rax,rcx
  40a6dc:	cmova  rbx,rcx
  40a6e0:	mov    rax,rbx
  40a6e3:	sub    rax,r15
  40a6e6:	mov    rcx,r15
  40a6e9:	mov    rdx,rax
  40a6ec:	call   4072a0 <__swc_fn_65555ab2_000003_644dadb7>
  40a6f1:	test   al,al
  40a6f3:	jne    40a712 <__swc_fn_65555ab2_000013_d15d37c6+0x132>
  40a6f5:	mov    rcx,rsi
  40a6f8:	mov    rdx,r13
  40a6fb:	call   407600 <__swc_fn_65555ab2_000018_e2e8e4b0>
  40a700:	xor    eax,eax
  40a702:	add    rsp,0x30
  40a706:	pop    rbx
  40a707:	pop    r15
  40a709:	pop    r14
  40a70b:	pop    r13
  40a70d:	pop    r12
  40a70f:	pop    rdi
  40a710:	pop    rsi
  40a711:	ret
  40a712:	sub    rbx,r15
  40a715:	mov    DWORD PTR [r14+0x3c],ebx
  40a719:	mov    rcx,r14
  40a71c:	mov    rdx,rsi
  40a71f:	mov    r8d,DWORD PTR [r12]
  40a723:	mov    r9d,edi
  40a726:	mov    rbx,QWORD PTR [rsp+0x18]
  40a72b:	mov    r10d,ebx
  40a72e:	call   40a480 <__swc_fn_65555ab2_000004_2fa5c690>
  40a733:	mov    rax,r14
  40a736:	add    rsp,0x30
  40a73a:	pop    rbx
  40a73b:	pop    r15
  40a73d:	pop    r14
  40a73f:	pop    r13
  40a741:	pop    r12
  40a743:	pop    rdi
  40a744:	pop    rsi
  40a745:	ret
	...

000000000040a750 <__swc_fn_65555ab2_000016_89da4d6e>:
  40a750:	mov    r8,QWORD PTR [rcx+0x48]
  40a754:	cs nop WORD PTR [rax+rax*1+0x0]
  40a75e:	xchg   ax,ax
  40a760:	mov    r9,r8
  40a763:	or     r9,rdx
  40a766:	mov    rax,r8
  40a769:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40a76f:	cmp    rax,r8
  40a772:	jne    40a775 <__swc_fn_65555ab2_000016_89da4d6e+0x25>
  40a774:	ret
  40a775:	mov    r8,rax
  40a778:	jmp    40a760 <__swc_fn_65555ab2_000016_89da4d6e+0x10>
  40a77a:	add    BYTE PTR [rax],al
  40a77c:	add    BYTE PTR [rax],al
	...

000000000040a780 <__swc_fn_65555ab2_000019_60e50998>:
  40a780:	push   rsi
  40a781:	push   rdi
  40a782:	push   r12
  40a784:	mov    rsi,rcx
  40a787:	xor    edi,edi
  40a789:	lea    r12,[rip+0x198d8]        # 424068 <__swc_bss_base_65555ab2+0x28>
  40a790:	mov    eax,DWORD PTR [r12]
  40a794:	xor    ecx,ecx
  40a796:	test   rax,rax
  40a799:	jbe    40a7d4 <__swc_fn_65555ab2_000019_60e50998+0x54>
  40a79b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a7a0:	lea    rdx,[rip+0x198c9]        # 424070 <__swc_bss_base_65555ab2+0x30>
  40a7a7:	mov    r8d,ecx
  40a7aa:	lea    r8,[r8+r8*2]
  40a7ae:	lea    r8,[rdx+r8*8]
  40a7b2:	mov    rdx,QWORD PTR [r8+0x10]
  40a7b6:	add    rdx,0x400000
  40a7bd:	cmp    rdx,0x40000000
  40a7c4:	ja     40a7cb <__swc_fn_65555ab2_000019_60e50998+0x4b>
  40a7c6:	mov    rdi,r8
  40a7c9:	jmp    40a7d4 <__swc_fn_65555ab2_000019_60e50998+0x54>
  40a7cb:	add    rcx,0x1
  40a7cf:	cmp    rcx,rax
  40a7d2:	jb     40a7a0 <__swc_fn_65555ab2_000019_60e50998+0x20>
  40a7d4:	test   rdi,rdi
  40a7d7:	jne    40a863 <__swc_fn_65555ab2_000019_60e50998+0xe3>
  40a7dd:	cmp    DWORD PTR [r12],0x10
  40a7e2:	jae    40a84b <__swc_fn_65555ab2_000019_60e50998+0xcb>
  40a7e4:	mov    ecx,0x40400000
  40a7e9:	call   40ddc0 <__swc_fn_65555ab2_000002_390d5093>
  40a7ee:	test   rax,rax
  40a7f1:	je     40a84b <__swc_fn_65555ab2_000019_60e50998+0xcb>
  40a7f3:	lea    rcx,[rip+0x19876]        # 424070 <__swc_bss_base_65555ab2+0x30>
  40a7fa:	mov    edx,DWORD PTR [r12]
  40a7fe:	lea    rdx,[rdx+rdx*2]
  40a802:	lea    rdx,[rcx+rdx*8]
  40a806:	mov    QWORD PTR [rdx],rax
  40a809:	lea    rax,[rax+0x3fffff]
  40a810:	and    rax,0xffffffffffc00000
  40a817:	mov    QWORD PTR [rdx+0x8],rax
  40a81b:	mov    QWORD PTR [rdx+0x10],0x0
  40a823:	mov    edx,DWORD PTR [rip+0x1983f]        # 424068 <__swc_bss_base_65555ab2+0x28>
  40a829:	nop    DWORD PTR [rax+0x0]
  40a830:	lea    r9d,[rdx+0x1]
  40a834:	mov    rax,rdx
  40a837:	lock cmpxchg DWORD PTR [r12],r9d
  40a83d:	mov    r8d,eax
  40a840:	cmp    eax,edx
  40a842:	je     40a852 <__swc_fn_65555ab2_000019_60e50998+0xd2>
  40a844:	mov    rdx,r8
  40a847:	jmp    40a830 <__swc_fn_65555ab2_000019_60e50998+0xb0>
  40a849:	jmp    40a852 <__swc_fn_65555ab2_000019_60e50998+0xd2>
  40a84b:	xor    eax,eax
  40a84d:	pop    r12
  40a84f:	pop    rdi
  40a850:	pop    rsi
  40a851:	ret
  40a852:	mov    eax,DWORD PTR [rip+0x19810]        # 424068 <__swc_bss_base_65555ab2+0x28>
  40a858:	sub    eax,0x1
  40a85b:	lea    rdi,[rax+rax*2]
  40a85f:	lea    rdi,[rcx+rdi*8]
  40a863:	mov    r12,QWORD PTR [rdi+0x8]
  40a867:	add    r12,QWORD PTR [rdi+0x10]
  40a86b:	mov    rcx,r12
  40a86e:	mov    edx,0x3000
  40a873:	call   4072a0 <__swc_fn_65555ab2_000003_644dadb7>
  40a878:	test   al,al
  40a87a:	jne    40a883 <__swc_fn_65555ab2_000019_60e50998+0x103>
  40a87c:	xor    eax,eax
  40a87e:	pop    r12
  40a880:	pop    rdi
  40a881:	pop    rsi
  40a882:	ret
  40a883:	vxorps xmm0,xmm0,xmm0
  40a887:	xor    eax,eax
  40a889:	cs nop WORD PTR [rax+rax*1+0x0]
  40a893:	cs nop WORD PTR [rax+rax*1+0x0]
  40a89d:	nop    DWORD PTR [rax]
  40a8a0:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40a8a6:	add    rax,0x10
  40a8aa:	cmp    rax,0x3000
  40a8b1:	jne    40a8a0 <__swc_fn_65555ab2_000019_60e50998+0x120>
  40a8b3:	mov    DWORD PTR [r12+0x28],esi
  40a8b8:	mov    eax,0x40
  40a8bd:	mov    ecx,esi
  40a8bf:	shr    eax,cl
  40a8c1:	mov    DWORD PTR [r12+0x2c],eax
  40a8c6:	cmp    DWORD PTR [r12+0x2c],0x40
  40a8cc:	jb     40a8d7 <__swc_fn_65555ab2_000019_60e50998+0x157>
  40a8ce:	mov    rax,0xffffffffffffffff
  40a8d5:	jmp    40a8e7 <__swc_fn_65555ab2_000019_60e50998+0x167>
  40a8d7:	mov    eax,0x1
  40a8dc:	mov    ecx,DWORD PTR [r12+0x2c]
  40a8e1:	shl    rax,cl
  40a8e4:	dec    rax
  40a8e7:	mov    QWORD PTR [r12+0x20],rax
  40a8ec:	mov    DWORD PTR [r12],0x4e540001
  40a8f4:	mov    DWORD PTR [r12+0x4],0x53474d45
  40a8fd:	add    QWORD PTR [rdi+0x10],0x400000
  40a905:	mov    rax,r12
  40a908:	pop    r12
  40a90a:	pop    rdi
  40a90b:	pop    rsi
  40a90c:	ret
  40a90d:	add    BYTE PTR [rax],al
	...

000000000040a910 <__swc_fn_65555ab2_000022_77c2d682>:
  40a910:	mov    eax,0x1
  40a915:	mov    edx,DWORD PTR [rip+0x1974d]        # 424068 <__swc_bss_base_65555ab2+0x28>
  40a91b:	cmp    eax,edx
  40a91d:	jae    40a96b <__swc_fn_65555ab2_000022_77c2d682+0x5b>
  40a91f:	nop
  40a920:	lea    r8,[rip+0x19749]        # 424070 <__swc_bss_base_65555ab2+0x30>
  40a927:	lea    r9,[rax+rax*2]
  40a92b:	lea    r9,[r8+r9*8]
  40a92f:	mov    r8,rcx
  40a932:	sub    r8,QWORD PTR [r9+0x8]
  40a936:	mov    r9,QWORD PTR [r9+0x10]
  40a93a:	cmp    r8,r9
  40a93d:	jae    40a965 <__swc_fn_65555ab2_000022_77c2d682+0x55>
  40a93f:	mov    rax,rcx
  40a942:	and    rax,0xffffffffffc00000
  40a949:	shr    rcx,0x10
  40a94d:	and    ecx,0x3f
  40a950:	mov    edx,DWORD PTR [rax+0x28]
  40a953:	shrx   ecx,ecx,edx
  40a958:	shl    rcx,0x4
  40a95c:	lea    rax,[rax+rcx*8+0x80]
  40a964:	ret
  40a965:	inc    eax
  40a967:	cmp    eax,edx
  40a969:	jb     40a920 <__swc_fn_65555ab2_000022_77c2d682+0x10>
  40a96b:	xor    eax,eax
  40a96d:	ret
	...

000000000040a970 <__swc_fn_65555ab2_000025_7e9350e1>:
  40a970:	vxorps xmm0,xmm0,xmm0
  40a974:	vmovups XMMWORD PTR [rcx],xmm0
  40a978:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a97d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a982:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a987:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40a98c:	mov    QWORD PTR [rcx+0x50],0x0
  40a994:	ret
	...

000000000040a9a0 <__swc_fn_65555ab2_000028_7e9350e1>:
  40a9a0:	vxorps xmm0,xmm0,xmm0
  40a9a4:	xor    eax,eax
  40a9a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9b0:	cs nop WORD PTR [rax+rax*1+0x0]
  40a9ba:	nop    WORD PTR [rax+rax*1+0x0]
  40a9c0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a9c5:	add    rax,0x10
  40a9c9:	cmp    rax,0x9b0
  40a9d0:	jne    40a9c0 <__swc_fn_65555ab2_000028_7e9350e1+0x20>
  40a9d2:	mov    QWORD PTR [rcx+0x9b0],0x0
  40a9dd:	ret
	...

000000000040a9e0 <__swc_fn_65555ab2_000031_ed8d61a9>:
  40a9e0:	push   rsi
  40a9e1:	push   rdi
  40a9e2:	sub    rsp,0x8
  40a9e6:	lea    rsi,[rip+0x1761b]        # 422008 <__swc_data_base_65555ab2+0x8>
  40a9ed:	mov    rax,QWORD PTR [rsi]
  40a9f0:	mov    ecx,0xffffffff
  40a9f5:	cmp    rax,rcx
  40a9f8:	je     40aa01 <__swc_fn_65555ab2_000031_ed8d61a9+0x21>
  40a9fa:	add    rsp,0x8
  40a9fe:	pop    rdi
  40a9ff:	pop    rsi
  40aa00:	ret
  40aa01:	mov    rcx,QWORD PTR [rip+0x8678]        # 413080 <__swc_fn_65555ab2_000176_5d3d19bd+0x10e0>
  40aa08:	call   409650 <__swc_fn_65555ab2_000126_5fb20c72>
  40aa0d:	mov    rcx,rax
  40aa10:	mov    eax,0xffffffff
  40aa15:	lock cmpxchg QWORD PTR [rsi],rcx
  40aa1a:	mov    rdi,rax
  40aa1d:	mov    eax,0xffffffff
  40aa22:	cmp    rdi,rax
  40aa25:	je     40aa36 <__swc_fn_65555ab2_000031_ed8d61a9+0x56>
  40aa27:	call   40cc10 <__swc_fn_65555ab2_000127_75f8ab5c>
  40aa2c:	mov    rax,rdi
  40aa2f:	add    rsp,0x8
  40aa33:	pop    rdi
  40aa34:	pop    rsi
  40aa35:	ret
  40aa36:	mov    rax,rcx
  40aa39:	add    rsp,0x8
  40aa3d:	pop    rdi
  40aa3e:	pop    rsi
  40aa3f:	ret

000000000040aa40 <__swc_fn_65555ab2_000034_c72914a2>:
  40aa40:	sub    rsp,0x8
  40aa44:	vxorps xmm0,xmm0,xmm0
  40aa48:	xor    eax,eax
  40aa4a:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa54:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa5e:	xchg   ax,ax
  40aa60:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40aa65:	add    rax,0x10
  40aa69:	cmp    rax,0x2b00
  40aa70:	jne    40aa60 <__swc_fn_65555ab2_000034_c72914a2+0x20>
  40aa72:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40aa7c:	xor    al,al
  40aa7e:	mov    rdx,rax
  40aa81:	xor    al,al
  40aa83:	mov    r8,rax
  40aa86:	xor    al,al
  40aa88:	mov    r9,rax
  40aa8b:	xor    al,al
  40aa8d:	mov    r10,rax
  40aa90:	xor    al,al
  40aa92:	mov    r11,rax
  40aa95:	call   40e230 <__swc_fn_65555ab2_000035_6105596e>
  40aa9a:	add    rsp,0x8
  40aa9e:	ret
	...

000000000040aaa0 <__swc_fn_65555ab2_000037_92e867c2>:
  40aaa0:	push   rsi
  40aaa1:	push   rdi
  40aaa2:	push   r12
  40aaa4:	mov    rsi,r8
  40aaa7:	mov    rdi,rdx
  40aaaa:	mov    rcx,rdx
  40aaad:	call   40ddc0 <__swc_fn_65555ab2_000002_390d5093>
  40aab2:	mov    r12,rax
  40aab5:	test   rax,rax
  40aab8:	jne    40aac1 <__swc_fn_65555ab2_000037_92e867c2+0x21>
  40aaba:	xor    eax,eax
  40aabc:	pop    r12
  40aabe:	pop    rdi
  40aabf:	pop    rsi
  40aac0:	ret
  40aac1:	mov    rcx,r12
  40aac4:	mov    rdx,rsi
  40aac7:	call   4072a0 <__swc_fn_65555ab2_000003_644dadb7>
  40aacc:	test   al,al
  40aace:	jne    40aae2 <__swc_fn_65555ab2_000037_92e867c2+0x42>
  40aad0:	mov    rcx,r12
  40aad3:	mov    rdx,rdi
  40aad6:	call   410030 <__swc_fn_65555ab2_000113_25e345b1>
  40aadb:	xor    eax,eax
  40aadd:	pop    r12
  40aadf:	pop    rdi
  40aae0:	pop    rsi
  40aae1:	ret
  40aae2:	mov    rax,r12
  40aae5:	pop    r12
  40aae7:	pop    rdi
  40aae8:	pop    rsi
  40aae9:	ret
	...

000000000040ab00 <__swc_fn_65555ab2_000040_7a225310>:
  40ab00:	push   rsi
  40ab01:	push   rdi
  40ab02:	push   r12
  40ab04:	mov    rsi,rcx
  40ab07:	mov    edx,0x9b8
  40ab0c:	call   40e2a0 <__swc_fn_65555ab2_000038_c7591393>
  40ab11:	mov    rdi,rax
  40ab14:	test   rax,rax
  40ab17:	jne    40ab20 <__swc_fn_65555ab2_000040_7a225310+0x20>
  40ab19:	xor    eax,eax
  40ab1b:	pop    r12
  40ab1d:	pop    rdi
  40ab1e:	pop    rsi
  40ab1f:	ret
  40ab20:	vxorps xmm0,xmm0,xmm0
  40ab24:	xor    eax,eax
  40ab26:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab30:	cs nop WORD PTR [rax+rax*1+0x0]
  40ab3a:	nop    WORD PTR [rax+rax*1+0x0]
  40ab40:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40ab45:	add    rax,0x10
  40ab49:	cmp    rax,0x9b0
  40ab50:	jne    40ab40 <__swc_fn_65555ab2_000040_7a225310+0x40>
  40ab52:	mov    QWORD PTR [rdi+0x9b0],0x0
  40ab5d:	mov    QWORD PTR [rdi],rsi
  40ab60:	call   40ccc0 <__swc_fn_65555ab2_000130_d2d78689>
  40ab65:	mov    QWORD PTR [rdi+0x18],rax
  40ab69:	lea    r12,[rsi+0x10]
  40ab6d:	mov    rcx,r12
  40ab70:	call   4098a0 <__swc_fn_65555ab2_000135_1fec60ac>
  40ab75:	mov    rax,QWORD PTR [rsi+0x20]
  40ab79:	mov    QWORD PTR [rdi+0x8],rax
  40ab7d:	mov    rax,QWORD PTR [rsi+0x20]
  40ab81:	test   rax,rax
  40ab84:	je     40ab8a <__swc_fn_65555ab2_000040_7a225310+0x8a>
  40ab86:	mov    QWORD PTR [rax+0x10],rdi
  40ab8a:	mov    QWORD PTR [rsi+0x20],rdi
  40ab8e:	mov    rcx,r12
  40ab91:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  40ab96:	mov    rax,rdi
  40ab99:	pop    r12
  40ab9b:	pop    rdi
  40ab9c:	pop    rsi
  40ab9d:	ret
	...

000000000040aba0 <__swc_fn_65555ab2_000043_3755033a>:
  40aba0:	mov    rax,QWORD PTR [rdx+0x10]
  40aba4:	test   rax,rax
  40aba7:	je     40abb3 <__swc_fn_65555ab2_000043_3755033a+0x13>
  40aba9:	mov    rcx,QWORD PTR [rdx+0x8]
  40abad:	mov    QWORD PTR [rax+0x8],rcx
  40abb1:	jmp    40abbb <__swc_fn_65555ab2_000043_3755033a+0x1b>
  40abb3:	mov    rax,QWORD PTR [rdx+0x8]
  40abb7:	mov    QWORD PTR [rcx+0x20],rax
  40abbb:	mov    rax,QWORD PTR [rdx+0x8]
  40abbf:	test   rax,rax
  40abc2:	je     40abcc <__swc_fn_65555ab2_000043_3755033a+0x2c>
  40abc4:	mov    rcx,QWORD PTR [rdx+0x10]
  40abc8:	mov    QWORD PTR [rax+0x10],rcx
  40abcc:	vxorps xmm0,xmm0,xmm0
  40abd0:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40abd5:	ret
	...

000000000040abe0 <__swc_fn_65555ab2_000046_49300800>:
  40abe0:	sub    rsp,0x8
  40abe4:	mov    r9,r8
  40abe7:	mov    r10,rdx
  40abea:	call   40e350 <__swc_fn_65555ab2_000044_cac7f504>
  40abef:	mov    eax,0x1
  40abf4:	xchg   DWORD PTR [r9+0x6c],eax
  40abf8:	mov    rax,QWORD PTR [r9+0x60]
  40abfc:	test   rax,rax
  40abff:	je     40ac43 <__swc_fn_65555ab2_000046_49300800+0x63>
  40ac01:	xor    eax,eax
  40ac03:	xchg   DWORD PTR [r9+0x6c],eax
  40ac07:	movzx  eax,BYTE PTR [r9+0x39]
  40ac0c:	lea    rax,[rax+rax*4]
  40ac10:	lea    rax,[r10+rax*8+0x28]
  40ac15:	mov    QWORD PTR [r9+0x50],0x0
  40ac1d:	mov    rcx,QWORD PTR [rax+0x8]
  40ac21:	mov    QWORD PTR [r9+0x48],rcx
  40ac25:	mov    rcx,QWORD PTR [rax+0x8]
  40ac29:	test   rcx,rcx
  40ac2c:	je     40ac34 <__swc_fn_65555ab2_000046_49300800+0x54>
  40ac2e:	mov    QWORD PTR [rcx+0x50],r9
  40ac32:	jmp    40ac38 <__swc_fn_65555ab2_000046_49300800+0x58>
  40ac34:	mov    QWORD PTR [rax+0x10],r9
  40ac38:	mov    QWORD PTR [rax+0x8],r9
  40ac3c:	xor    eax,eax
  40ac3e:	add    rsp,0x8
  40ac42:	ret
  40ac43:	movzx  eax,BYTE PTR [r9+0x39]
  40ac48:	lea    rax,[rax+rax*4]
  40ac4c:	lea    rax,[r10+rax*8+0x28]
  40ac51:	mov    QWORD PTR [r9+0x50],0x0
  40ac59:	mov    rcx,QWORD PTR [rax+0x18]
  40ac5d:	mov    QWORD PTR [r9+0x48],rcx
  40ac61:	mov    rcx,QWORD PTR [rax+0x18]
  40ac65:	test   rcx,rcx
  40ac68:	je     40ac6e <__swc_fn_65555ab2_000046_49300800+0x8e>
  40ac6a:	mov    QWORD PTR [rcx+0x50],r9
  40ac6e:	mov    QWORD PTR [rax+0x18],r9
  40ac72:	mov    eax,0x1
  40ac77:	add    rsp,0x8
  40ac7b:	ret
  40ac7c:	add    BYTE PTR [rax],al
	...

000000000040ac80 <__swc_fn_65555ab2_000049_781177b4>:
  40ac80:	push   r12
  40ac82:	push   r13
  40ac84:	push   rdi
  40ac85:	push   rsi
  40ac86:	push   r14
  40ac88:	push   r15
  40ac8a:	sub    rsp,0x178
  40ac91:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40ac9a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40aca3:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40acac:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40acb5:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40acbe:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40acc7:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40acd0:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40acd9:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40ace2:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40aceb:	mov    r12,rcx
  40acee:	lea    rax,[rip+0x1950b]        # 424200 <__swc_bss_base_65555ab2+0x1c0>
  40acf5:	mov    rcx,QWORD PTR [rax]
  40acf8:	mov    r13,rcx
  40acfb:	test   rcx,rcx
  40acfe:	jne    40ad0e <__swc_fn_65555ab2_000049_781177b4+0x8e>
  40ad00:	mov    r13d,0x1dcd6500
  40ad06:	mov    ecx,0x1dcd6500
  40ad0b:	xchg   QWORD PTR [rax],rcx
  40ad0e:	lea    rax,[rip+0x172eb]        # 422000 <__swc_data_base_65555ab2>
  40ad15:	mov    rax,QWORD PTR [rax]
  40ad18:	cmp    rax,0xffffffffffffffff
  40ad1c:	je     40ad2b <__swc_fn_65555ab2_000049_781177b4+0xab>
  40ad1e:	mov    eax,eax
  40ad20:	mov    edi,eax
  40ad22:	xor    eax,eax
  40ad24:	call   407000 <pthread_getspecific@plt>
  40ad29:	jmp    40ad2d <__swc_fn_65555ab2_000049_781177b4+0xad>
  40ad2b:	xor    eax,eax
  40ad2d:	test   rax,rax
  40ad30:	jne    40ad3f <__swc_fn_65555ab2_000049_781177b4+0xbf>
  40ad32:	call   40a9e0 <__swc_fn_65555ab2_000031_ed8d61a9>
  40ad37:	mov    rcx,rax
  40ad3a:	call   410380 <__swc_fn_65555ab2_000128_9c45d2d7>
  40ad3f:	test   rax,rax
  40ad42:	je     40ad54 <__swc_fn_65555ab2_000049_781177b4+0xd4>
  40ad44:	cmp    QWORD PTR [rax],r12
  40ad47:	jne    40ad54 <__swc_fn_65555ab2_000049_781177b4+0xd4>
  40ad49:	cmp    DWORD PTR [rax+0x20],0x0
  40ad4d:	jne    40ad54 <__swc_fn_65555ab2_000049_781177b4+0xd4>
  40ad4f:	mov    rsi,rax
  40ad52:	jmp    40ad56 <__swc_fn_65555ab2_000049_781177b4+0xd6>
  40ad54:	xor    esi,esi
  40ad56:	lea    rdi,[r12+0x2a88]
  40ad5e:	mov    r14,QWORD PTR [rdi]
  40ad61:	test   r14,r14
  40ad64:	jne    40adb3 <__swc_fn_65555ab2_000049_781177b4+0x133>
  40ad66:	lea    rax,[rip+0x192eb]        # 424058 <__swc_bss_base_65555ab2+0x18>
  40ad6d:	mov    rax,QWORD PTR [rax]
  40ad70:	test   rax,rax
  40ad73:	setne  al
  40ad76:	jne    40ad9a <__swc_fn_65555ab2_000049_781177b4+0x11a>
  40ad78:	mov    rax,QWORD PTR [r12+0x2a70]
  40ad80:	test   rax,rax
  40ad83:	setne  al
  40ad86:	jne    40ad9a <__swc_fn_65555ab2_000049_781177b4+0x11a>
  40ad88:	test   rsi,rsi
  40ad8b:	setne  al
  40ad8e:	je     40ad9a <__swc_fn_65555ab2_000049_781177b4+0x11a>
  40ad90:	cmp    DWORD PTR [rsi+0x730],0x0
  40ad97:	setne  al
  40ad9a:	test   al,al
  40ad9c:	je     40adae <__swc_fn_65555ab2_000049_781177b4+0x12e>
  40ad9e:	call   410430 <__swc_fn_65555ab2_000131_dc04d759>
  40ada3:	lea    rcx,[rax+r13*1]
  40ada7:	xor    eax,eax
  40ada9:	lock cmpxchg QWORD PTR [rdi],rcx
  40adae:	jmp    40aeb3 <__swc_fn_65555ab2_000049_781177b4+0x233>
  40adb3:	call   410430 <__swc_fn_65555ab2_000131_dc04d759>
  40adb8:	mov    r15,rax
  40adbb:	cmp    rax,r14
  40adbe:	jb     40adcf <__swc_fn_65555ab2_000049_781177b4+0x14f>
  40adc0:	xor    ecx,ecx
  40adc2:	mov    rax,r14
  40adc5:	lock cmpxchg QWORD PTR [rdi],rcx
  40adca:	cmp    rax,r14
  40adcd:	je     40add4 <__swc_fn_65555ab2_000049_781177b4+0x154>
  40adcf:	jmp    40aeb3 <__swc_fn_65555ab2_000049_781177b4+0x233>
  40add4:	test   rsi,rsi
  40add7:	je     40adf2 <__swc_fn_65555ab2_000049_781177b4+0x172>
  40add9:	cmp    r15,r13
  40addc:	jb     40adf2 <__swc_fn_65555ab2_000049_781177b4+0x172>
  40adde:	mov    rax,r15
  40ade1:	sub    rax,r13
  40ade4:	mov    rcx,r12
  40ade7:	mov    rdx,rsi
  40adea:	mov    r8,rax
  40aded:	call   40e790 <__swc_fn_65555ab2_000059_c8e1ff6b>
  40adf2:	lea    rsi,[r12+0x10]
  40adf7:	mov    rcx,rsi
  40adfa:	call   4098a0 <__swc_fn_65555ab2_000135_1fec60ac>
  40adff:	mov    rax,QWORD PTR [r12+0x18]
  40ae04:	mov    rdi,rax
  40ae07:	test   rdi,rdi
  40ae0a:	je     40ae34 <__swc_fn_65555ab2_000049_781177b4+0x1b4>
  40ae0c:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae16:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae20:	mov    rcx,rdi
  40ae23:	call   407470 <__swc_fn_65555ab2_000015_aa8c841a>
  40ae28:	mov    rax,QWORD PTR [rdi+0x10]
  40ae2c:	mov    rdi,rax
  40ae2f:	test   rax,rax
  40ae32:	jne    40ae20 <__swc_fn_65555ab2_000049_781177b4+0x1a0>
  40ae34:	mov    rcx,rsi
  40ae37:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  40ae3c:	mov    rcx,r12
  40ae3f:	call   4098a0 <__swc_fn_65555ab2_000135_1fec60ac>
  40ae44:	xor    esi,esi
  40ae46:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae50:	mov    rax,QWORD PTR [r12+0x2a70]
  40ae58:	cmp    rsi,rax
  40ae5b:	jae    40aeab <__swc_fn_65555ab2_000049_781177b4+0x22b>
  40ae5d:	lea    rax,[rsi+rsi*4]
  40ae61:	lea    rax,[r12+rax*8+0x268]
  40ae69:	mov    r8,QWORD PTR [rax]
  40ae6c:	mov    r9,QWORD PTR [rax+0x8]
  40ae70:	mov    r10,QWORD PTR [rax+0x10]
  40ae74:	mov    rax,QWORD PTR [rax+0x20]
  40ae78:	cmp    rax,r15
  40ae7b:	jae    40ae88 <__swc_fn_65555ab2_000049_781177b4+0x208>
  40ae7d:	mov    rcx,r15
  40ae80:	sub    rcx,rax
  40ae83:	cmp    rcx,r13
  40ae86:	jae    40ae8d <__swc_fn_65555ab2_000049_781177b4+0x20d>
  40ae88:	inc    rsi
  40ae8b:	jmp    40ae50 <__swc_fn_65555ab2_000049_781177b4+0x1d0>
  40ae8d:	mov    rcx,r12
  40ae90:	mov    rdx,rsi
  40ae93:	call   40e740 <__swc_fn_65555ab2_000056_cfedf3f4>
  40ae98:	mov    rcx,r12
  40ae9b:	mov    rdx,r8
  40ae9e:	mov    r8,r9
  40aea1:	mov    r9,r10
  40aea4:	call   407750 <__swc_fn_65555ab2_000039_05a50673>
  40aea9:	jmp    40ae50 <__swc_fn_65555ab2_000049_781177b4+0x1d0>
  40aeab:	mov    rcx,r12
  40aeae:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  40aeb3:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40aebc:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40aec5:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40aece:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40aed7:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40aee0:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40aee9:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40aef2:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40aefb:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40af04:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40af0d:	add    rsp,0x178
  40af14:	pop    r15
  40af16:	pop    r14
  40af18:	pop    rsi
  40af19:	pop    rdi
  40af1a:	pop    r13
  40af1c:	pop    r12
  40af1e:	ret
	...

000000000040af20 <__swc_fn_65555ab2_000052_26c6c1c4>:
  40af20:	lea    rax,[rdx-0x58]
  40af24:	ret
	...

000000000040af30 <__swc_fn_65555ab2_000055_da36318f>:
  40af30:	push   rsi
  40af31:	push   rdi
  40af32:	push   r12
  40af34:	push   r13
  40af36:	sub    rsp,0x68
  40af3a:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40af40:	mov    rsi,r9
  40af43:	mov    rdi,rcx
  40af46:	mov    r12,rdx
  40af49:	mov    r13,r8
  40af4c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40af54:	jne    40af63 <__swc_fn_65555ab2_000055_da36318f+0x33>
  40af56:	xor    eax,eax
  40af58:	add    rsp,0x68
  40af5c:	pop    r13
  40af5e:	pop    r12
  40af60:	pop    rdi
  40af61:	pop    rsi
  40af62:	ret
  40af63:	mov    rcx,rdi
  40af66:	call   4098a0 <__swc_fn_65555ab2_000135_1fec60ac>
  40af6b:	movabs rax,0x7fffffffffffffff
  40af75:	cmp    r12,rax
  40af78:	mov    rax,0xffffffffffffffff
  40af7f:	lea    rcx,[r12+r12*1]
  40af83:	cmovbe rax,rcx
  40af87:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40af8e:	mov    rdx,rcx
  40af91:	sub    rax,r12
  40af94:	inc    rax
  40af97:	xor    r8d,r8d
  40af9a:	test   rcx,rcx
  40af9d:	jbe    40afc8 <__swc_fn_65555ab2_000055_da36318f+0x98>
  40af9f:	nop
  40afa0:	lea    r9,[r8+r8*4]
  40afa4:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40afac:	sub    r9,r12
  40afaf:	cmp    r9,rax
  40afb2:	jae    40afbf <__swc_fn_65555ab2_000055_da36318f+0x8f>
  40afb4:	mov    rdx,r8
  40afb7:	mov    rax,r9
  40afba:	test   r9,r9
  40afbd:	je     40afc8 <__swc_fn_65555ab2_000055_da36318f+0x98>
  40afbf:	add    r8,0x1
  40afc3:	cmp    r8,rcx
  40afc6:	jb     40afa0 <__swc_fn_65555ab2_000055_da36318f+0x70>
  40afc8:	mov    rax,QWORD PTR [rdi+0x2a70]
  40afcf:	cmp    rdx,rax
  40afd2:	jne    40afef <__swc_fn_65555ab2_000055_da36318f+0xbf>
  40afd4:	mov    rcx,rdi
  40afd7:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  40afdc:	xor    eax,eax
  40afde:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40afe4:	add    rsp,0x68
  40afe8:	pop    r13
  40afea:	pop    r12
  40afec:	pop    rdi
  40afed:	pop    rsi
  40afee:	ret
  40afef:	lea    rax,[rdx+rdx*4]
  40aff3:	lea    rax,[rdi+rax*8+0x268]
  40affb:	vmovups xmm6,XMMWORD PTR [rax]
  40afff:	mov    r8,QWORD PTR [rax+0x10]
  40b003:	mov    rcx,rdi
  40b006:	call   40e740 <__swc_fn_65555ab2_000056_cfedf3f4>
  40b00b:	vpshufd xmm0,xmm6,0xee
  40b010:	vmovsd QWORD PTR [r13+0x0],xmm0
  40b016:	mov    QWORD PTR [rsi],r8
  40b019:	mov    rcx,rdi
  40b01c:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  40b021:	vmovq  rax,xmm6
  40b026:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40b02c:	add    rsp,0x68
  40b030:	pop    r13
  40b032:	pop    r12
  40b034:	pop    rdi
  40b035:	pop    rsi
  40b036:	ret
	...

000000000040b040 <__swc_fn_65555ab2_000058_033ce1da>:
  40b040:	push   r12
  40b042:	push   r13
  40b044:	push   r14
  40b046:	push   r15
  40b048:	push   rdi
  40b049:	push   rsi
  40b04a:	sub    rsp,0x148
  40b051:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40b05a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40b063:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40b06c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40b075:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40b07e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40b087:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40b090:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40b099:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40b0a2:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40b0ab:	mov    r12,r9
  40b0ae:	mov    r13,rcx
  40b0b1:	mov    r14,rdx
  40b0b4:	mov    r15,r8
  40b0b7:	test   rdx,rdx
  40b0ba:	jne    40b0ce <__swc_fn_65555ab2_000058_033ce1da+0x8e>
  40b0bc:	add    rsp,0x148
  40b0c3:	pop    rsi
  40b0c4:	pop    rdi
  40b0c5:	pop    r15
  40b0c7:	pop    r14
  40b0c9:	pop    r13
  40b0cb:	pop    r12
  40b0cd:	ret
  40b0ce:	cmp    r12,0x200000
  40b0d5:	ja     40b167 <__swc_fn_65555ab2_000058_033ce1da+0x127>
  40b0db:	lea    rax,[rip+0x16f1e]        # 422000 <__swc_data_base_65555ab2>
  40b0e2:	mov    rax,QWORD PTR [rax]
  40b0e5:	cmp    rax,0xffffffffffffffff
  40b0e9:	je     40b0f8 <__swc_fn_65555ab2_000058_033ce1da+0xb8>
  40b0eb:	mov    eax,eax
  40b0ed:	mov    edi,eax
  40b0ef:	xor    eax,eax
  40b0f1:	call   407000 <pthread_getspecific@plt>
  40b0f6:	jmp    40b0fa <__swc_fn_65555ab2_000058_033ce1da+0xba>
  40b0f8:	xor    eax,eax
  40b0fa:	test   rax,rax
  40b0fd:	je     40b104 <__swc_fn_65555ab2_000058_033ce1da+0xc4>
  40b0ff:	mov    rsi,rax
  40b102:	jmp    40b114 <__swc_fn_65555ab2_000058_033ce1da+0xd4>
  40b104:	call   40a9e0 <__swc_fn_65555ab2_000031_ed8d61a9>
  40b109:	mov    rcx,rax
  40b10c:	call   410380 <__swc_fn_65555ab2_000128_9c45d2d7>
  40b111:	mov    rsi,rax
  40b114:	test   rsi,rsi
  40b117:	je     40b167 <__swc_fn_65555ab2_000058_033ce1da+0x127>
  40b119:	cmp    QWORD PTR [rsi],r13
  40b11c:	jne    40b167 <__swc_fn_65555ab2_000058_033ce1da+0x127>
  40b11e:	cmp    DWORD PTR [rsi+0x20],0x0
  40b122:	jne    40b167 <__swc_fn_65555ab2_000058_033ce1da+0x127>
  40b124:	cmp    DWORD PTR [rsi+0x730],0x10
  40b12b:	jae    40b167 <__swc_fn_65555ab2_000058_033ce1da+0x127>
  40b12d:	mov    eax,DWORD PTR [rsi+0x730]
  40b133:	lea    rdi,[rax+rax*4]
  40b137:	lea    rdi,[rsi+rdi*8+0x738]
  40b13f:	mov    QWORD PTR [rdi],r14
  40b142:	mov    QWORD PTR [rdi+0x8],r15
  40b146:	mov    QWORD PTR [rdi+0x10],r12
  40b14a:	mov    QWORD PTR [rdi+0x18],0x0
  40b152:	call   410430 <__swc_fn_65555ab2_000131_dc04d759>
  40b157:	mov    QWORD PTR [rdi+0x20],rax
  40b15b:	add    DWORD PTR [rsi+0x730],0x1
  40b162:	jmp    40b2c6 <__swc_fn_65555ab2_000058_033ce1da+0x286>
  40b167:	mov    rcx,r13
  40b16a:	call   407e90 <__swc_fn_65555ab2_000057_8be0372b>
  40b16f:	mov    rsi,rax
  40b172:	cmp    r12,rax
  40b175:	jbe    40b1aa <__swc_fn_65555ab2_000058_033ce1da+0x16a>
  40b177:	cmp    r12,0x10000000
  40b17e:	seta   al
  40b181:	ja     40b190 <__swc_fn_65555ab2_000058_033ce1da+0x150>
  40b183:	mov    rax,QWORD PTR [r13+0x2a70]
  40b18a:	test   rax,rax
  40b18d:	setne  al
  40b190:	test   al,al
  40b192:	je     40b1aa <__swc_fn_65555ab2_000058_033ce1da+0x16a>
  40b194:	mov    rcx,r13
  40b197:	mov    rdx,r14
  40b19a:	mov    r8,r15
  40b19d:	mov    r9,r12
  40b1a0:	call   407750 <__swc_fn_65555ab2_000039_05a50673>
  40b1a5:	jmp    40b2c6 <__swc_fn_65555ab2_000058_033ce1da+0x286>
  40b1aa:	call   410430 <__swc_fn_65555ab2_000131_dc04d759>
  40b1af:	mov    rdi,rax
  40b1b2:	mov    rcx,r13
  40b1b5:	call   4098a0 <__swc_fn_65555ab2_000135_1fec60ac>
  40b1ba:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b1c2:	je     40b27a <__swc_fn_65555ab2_000058_033ce1da+0x23a>
  40b1c8:	nop    DWORD PTR [rax+rax*1+0x0]
  40b1d0:	cmp    QWORD PTR [r13+0x2a70],0x100
  40b1db:	jae    40b1f0 <__swc_fn_65555ab2_000058_033ce1da+0x1b0>
  40b1dd:	mov    rax,QWORD PTR [r13+0x2a68]
  40b1e4:	add    rax,r12
  40b1e7:	cmp    rax,rsi
  40b1ea:	jbe    40b27a <__swc_fn_65555ab2_000058_033ce1da+0x23a>
  40b1f0:	xor    eax,eax
  40b1f2:	mov    rcx,QWORD PTR [r13+0x2a70]
  40b1f9:	mov    edx,0x1
  40b1fe:	cmp    rcx,0x1
  40b202:	jbe    40b239 <__swc_fn_65555ab2_000058_033ce1da+0x1f9>
  40b204:	cs nop WORD PTR [rax+rax*1+0x0]
  40b20e:	xchg   ax,ax
  40b210:	lea    r8,[rdx+rdx*4]
  40b214:	lea    r8,[r13+r8*8+0x268]
  40b21c:	lea    r9,[rax+rax*4]
  40b220:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40b228:	cmp    QWORD PTR [r8+0x18],r9
  40b22c:	cmovb  rax,rdx
  40b230:	add    rdx,0x1
  40b234:	cmp    rdx,rcx
  40b237:	jb     40b210 <__swc_fn_65555ab2_000058_033ce1da+0x1d0>
  40b239:	lea    rcx,[rax+rax*4]
  40b23d:	lea    rcx,[r13+rcx*8+0x268]
  40b245:	mov    r8,QWORD PTR [rcx]
  40b248:	mov    r9,QWORD PTR [rcx+0x8]
  40b24c:	mov    r10,QWORD PTR [rcx+0x10]
  40b250:	mov    rcx,r13
  40b253:	mov    rdx,rax
  40b256:	call   40e740 <__swc_fn_65555ab2_000056_cfedf3f4>
  40b25b:	mov    rcx,r13
  40b25e:	mov    rdx,r8
  40b261:	mov    r8,r9
  40b264:	mov    r9,r10
  40b267:	call   407750 <__swc_fn_65555ab2_000039_05a50673>
  40b26c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b274:	jne    40b1d0 <__swc_fn_65555ab2_000058_033ce1da+0x190>
  40b27a:	add    QWORD PTR [r13+0x2a78],0x1
  40b282:	mov    rax,QWORD PTR [r13+0x2a70]
  40b289:	lea    rax,[rax+rax*4]
  40b28d:	lea    rax,[r13+rax*8+0x268]
  40b295:	mov    QWORD PTR [rax],r14
  40b298:	mov    QWORD PTR [rax+0x8],r15
  40b29c:	mov    QWORD PTR [rax+0x10],r12
  40b2a0:	mov    rcx,QWORD PTR [r13+0x2a78]
  40b2a7:	mov    QWORD PTR [rax+0x18],rcx
  40b2ab:	mov    QWORD PTR [rax+0x20],rdi
  40b2af:	add    QWORD PTR [r13+0x2a68],r12
  40b2b6:	add    QWORD PTR [r13+0x2a70],0x1
  40b2be:	mov    rcx,r13
  40b2c1:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  40b2c6:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40b2cf:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40b2d8:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40b2e1:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40b2ea:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40b2f3:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40b2fc:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40b305:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40b30e:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40b317:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40b320:	add    rsp,0x148
  40b327:	pop    rsi
  40b328:	pop    rdi
  40b329:	pop    r15
  40b32b:	pop    r14
  40b32d:	pop    r13
  40b32f:	pop    r12
  40b331:	ret
	...

000000000040b340 <__swc_fn_65555ab2_000061_1badc238>:
  40b340:	push   rbx
  40b341:	push   r12
  40b343:	push   r13
  40b345:	push   r14
  40b347:	push   r15
  40b349:	push   rdi
  40b34a:	push   rsi
  40b34b:	sub    rsp,0xf0
  40b352:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40b358:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40b35e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40b364:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40b36a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40b373:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40b37c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40b385:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40b38e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40b397:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40b3a0:	mov    eax,r8d
  40b3a3:	mov    rbx,rcx
  40b3a6:	mov    r12,rdx
  40b3a9:	mov    QWORD PTR [rsp+0x18],rdx
  40b3ae:	mov    ecx,DWORD PTR [r12+0x58]
  40b3b3:	mov    r13d,ecx
  40b3b6:	cmp    ecx,0x10
  40b3b9:	mov    ecx,0x10
  40b3be:	cmovb  r13d,ecx
  40b3c2:	test   r13d,r13d
  40b3c5:	mov    rcx,r13
  40b3c8:	mov    edx,0x8
  40b3cd:	cmove  ecx,edx
  40b3d0:	dec    rcx
  40b3d3:	mov    rdx,0xffffffffffffffff
  40b3da:	sub    rdx,rcx
  40b3dd:	xor    r14d,r14d
  40b3e0:	mov    r8,rcx
  40b3e3:	not    r8
  40b3e6:	lea    rcx,[rcx+0x58]
  40b3ea:	and    rcx,r8
  40b3ed:	cmp    rdx,0x58
  40b3f1:	cmovae r14,rcx
  40b3f5:	cmp    eax,0xffffffff
  40b3f8:	jne    40b401 <__swc_fn_65555ab2_000061_1badc238+0xc1>
  40b3fa:	mov    r15,QWORD PTR [r12+0x48]
  40b3ff:	jmp    40b433 <__swc_fn_65555ab2_000061_1badc238+0xf3>
  40b401:	test   eax,eax
  40b403:	jne    40b40c <__swc_fn_65555ab2_000061_1badc238+0xcc>
  40b405:	mov    eax,0x8
  40b40a:	jmp    40b430 <__swc_fn_65555ab2_000061_1badc238+0xf0>
  40b40c:	cmp    eax,0x8
  40b40f:	ja     40b417 <__swc_fn_65555ab2_000061_1badc238+0xd7>
  40b411:	shl    rax,0x4
  40b415:	jmp    40b430 <__swc_fn_65555ab2_000061_1badc238+0xf0>
  40b417:	lea    eax,[rax-0x9]
  40b41a:	mov    ecx,eax
  40b41c:	shr    ecx,0x2
  40b41f:	and    eax,0x3
  40b422:	lea    ecx,[rcx+0x7]
  40b425:	lea    ecx,[rcx-0x2]
  40b428:	lea    eax,[rax+0x5]
  40b42b:	shlx   rax,rax,rcx
  40b430:	mov    r15,rax
  40b433:	lea    rax,[r14+r13*1]
  40b437:	mov    rcx,0xffffffffffffffff
  40b43e:	sub    rcx,rax
  40b441:	cmp    r15,rcx
  40b444:	jbe    40b454 <__swc_fn_65555ab2_000061_1badc238+0x114>
  40b446:	mov    QWORD PTR [r12+0x40],0x0
  40b44f:	jmp    40b826 <__swc_fn_65555ab2_000061_1badc238+0x4e6>
  40b454:	mov    QWORD PTR [rsp+0x20],r13
  40b459:	lea    r13,[rsp+0x8]
  40b45e:	add    rax,r15
  40b461:	mov    ecx,0x1000
  40b466:	test   ecx,ecx
  40b468:	mov    edx,0x8
  40b46d:	cmove  ecx,edx
  40b470:	dec    rcx
  40b473:	mov    rdx,0xffffffffffffffff
  40b47a:	sub    rdx,rcx
  40b47d:	cmp    rax,rdx
  40b480:	jbe    40b48c <__swc_fn_65555ab2_000061_1badc238+0x14c>
  40b482:	mov    QWORD PTR [r13+0x0],0x0
  40b48a:	jmp    40b499 <__swc_fn_65555ab2_000061_1badc238+0x159>
  40b48c:	add    rax,rcx
  40b48f:	andn   rax,rcx,rax
  40b494:	mov    QWORD PTR [rsp+0x8],rax
  40b499:	cmp    QWORD PTR [r13+0x0],0x0
  40b49e:	jne    40b4ae <__swc_fn_65555ab2_000061_1badc238+0x16e>
  40b4a0:	mov    QWORD PTR [r12+0x40],0x0
  40b4a9:	jmp    40b826 <__swc_fn_65555ab2_000061_1badc238+0x4e6>
  40b4ae:	mov    QWORD PTR [rsp+0x30],r15
  40b4b3:	xor    r15d,r15d
  40b4b6:	mov    QWORD PTR [rsp+0x38],0x0
  40b4bf:	lea    r12,[rsp+0x10]
  40b4c4:	mov    QWORD PTR [rsp+0x28],r14
  40b4c9:	mov    r14,QWORD PTR [rsp+0x8]
  40b4ce:	mov    QWORD PTR [rsp+0x10],r14
  40b4d3:	cmp    r14,0x10000
  40b4da:	ja     40b4e1 <__swc_fn_65555ab2_000061_1badc238+0x1a1>
  40b4dc:	mov    rax,r14
  40b4df:	jmp    40b532 <__swc_fn_65555ab2_000061_1badc238+0x1f2>
  40b4e1:	xor    eax,eax
  40b4e3:	lea    rcx,[r14-0x1]
  40b4e7:	lzcnt  rax,rcx
  40b4ec:	mov    ecx,0x3f
  40b4f1:	sub    rcx,rax
  40b4f4:	mov    eax,0x1
  40b4f9:	lea    rcx,[rcx-0x3]
  40b4fd:	shl    rax,cl
  40b500:	mov    rcx,rax
  40b503:	cmp    rax,0x1000
  40b50a:	mov    eax,0x1000
  40b50f:	cmovb  rcx,rax
  40b513:	mov    rdx,0xffffffffffffffff
  40b51a:	sub    rdx,rcx
  40b51d:	mov    rax,r14
  40b520:	lea    r8,[r14+rcx*1-0x1]
  40b525:	neg    rcx
  40b528:	and    r8,rcx
  40b52b:	cmp    r14,rdx
  40b52e:	cmovbe rax,r8
  40b532:	mov    QWORD PTR [rsp+0x8],rax
  40b537:	lea    rax,[rip+0x16ac2]        # 422000 <__swc_data_base_65555ab2>
  40b53e:	mov    rax,QWORD PTR [rax]
  40b541:	cmp    rax,0xffffffffffffffff
  40b545:	je     40b554 <__swc_fn_65555ab2_000061_1badc238+0x214>
  40b547:	mov    eax,eax
  40b549:	mov    edi,eax
  40b54b:	xor    eax,eax
  40b54d:	call   407000 <pthread_getspecific@plt>
  40b552:	jmp    40b556 <__swc_fn_65555ab2_000061_1badc238+0x216>
  40b554:	xor    eax,eax
  40b556:	test   rax,rax
  40b559:	jne    40b568 <__swc_fn_65555ab2_000061_1badc238+0x228>
  40b55b:	call   40a9e0 <__swc_fn_65555ab2_000031_ed8d61a9>
  40b560:	mov    rcx,rax
  40b563:	call   410380 <__swc_fn_65555ab2_000128_9c45d2d7>
  40b568:	test   rax,rax
  40b56b:	je     40b65c <__swc_fn_65555ab2_000061_1badc238+0x31c>
  40b571:	cmp    QWORD PTR [rax],rbx
  40b574:	jne    40b65c <__swc_fn_65555ab2_000061_1badc238+0x31c>
  40b57a:	cmp    DWORD PTR [rax+0x20],0x0
  40b57e:	jne    40b65c <__swc_fn_65555ab2_000061_1badc238+0x31c>
  40b584:	mov    rcx,QWORD PTR [rsp+0x8]
  40b589:	movabs rdx,0x7fffffffffffffff
  40b593:	cmp    rcx,rdx
  40b596:	mov    rdx,0xffffffffffffffff
  40b59d:	lea    r8,[rcx+rcx*1]
  40b5a1:	cmovbe rdx,r8
  40b5a5:	mov    r8d,DWORD PTR [rax+0x730]
  40b5ac:	mov    r9d,r8d
  40b5af:	sub    rdx,rcx
  40b5b2:	inc    rdx
  40b5b5:	xor    r10d,r10d
  40b5b8:	test   r8,r8
  40b5bb:	jbe    40b5eb <__swc_fn_65555ab2_000061_1badc238+0x2ab>
  40b5bd:	nop    DWORD PTR [rax]
  40b5c0:	mov    r11d,r10d
  40b5c3:	lea    r11,[r11+r11*4]
  40b5c7:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40b5cf:	sub    r11,rcx
  40b5d2:	cmp    r11,rdx
  40b5d5:	jae    40b5e2 <__swc_fn_65555ab2_000061_1badc238+0x2a2>
  40b5d7:	mov    r9d,r10d
  40b5da:	mov    rdx,r11
  40b5dd:	test   r11,r11
  40b5e0:	je     40b5eb <__swc_fn_65555ab2_000061_1badc238+0x2ab>
  40b5e2:	add    r10,0x1
  40b5e6:	cmp    r10,r8
  40b5e9:	jb     40b5c0 <__swc_fn_65555ab2_000061_1badc238+0x280>
  40b5eb:	mov    ecx,DWORD PTR [rax+0x730]
  40b5f1:	cmp    r9d,ecx
  40b5f4:	jne    40b5fa <__swc_fn_65555ab2_000061_1badc238+0x2ba>
  40b5f6:	xor    eax,eax
  40b5f8:	jmp    40b659 <__swc_fn_65555ab2_000061_1badc238+0x319>
  40b5fa:	lea    rcx,[r9+r9*4]
  40b5fe:	lea    rcx,[rax+rcx*8+0x738]
  40b606:	vmovups xmm0,XMMWORD PTR [rcx]
  40b60a:	mov    rdx,QWORD PTR [rcx+0x10]
  40b60e:	sub    DWORD PTR [rax+0x730],0x1
  40b615:	mov    r8d,DWORD PTR [rax+0x730]
  40b61c:	lea    r8,[r8+r8*4]
  40b620:	lea    r8,[rax+r8*8+0x738]
  40b628:	vmovups xmm1,XMMWORD PTR [r8]
  40b62d:	vmovups XMMWORD PTR [rcx],xmm1
  40b631:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40b637:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40b63c:	mov    rax,QWORD PTR [r8+0x20]
  40b640:	mov    QWORD PTR [rcx+0x20],rax
  40b644:	vpshufd xmm1,xmm0,0xee
  40b649:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40b64f:	mov    QWORD PTR [rsp+0x10],rdx
  40b654:	vmovq  rax,xmm0
  40b659:	mov    r15,rax
  40b65c:	test   r15,r15
  40b65f:	jne    40b677 <__swc_fn_65555ab2_000061_1badc238+0x337>
  40b661:	mov    rcx,rbx
  40b664:	mov    rdx,QWORD PTR [rsp+0x8]
  40b669:	mov    r8,r13
  40b66c:	mov    r9,r12
  40b66f:	call   40af30 <__swc_fn_65555ab2_000055_da36318f>
  40b674:	mov    r15,rax
  40b677:	test   r15,r15
  40b67a:	je     40b6bb <__swc_fn_65555ab2_000061_1badc238+0x37b>
  40b67c:	cmp    QWORD PTR [r12],r14
  40b680:	jae    40b6bb <__swc_fn_65555ab2_000061_1badc238+0x37b>
  40b682:	mov    rax,r15
  40b685:	add    rax,QWORD PTR [r12]
  40b689:	mov    rdx,r14
  40b68c:	sub    rdx,QWORD PTR [r12]
  40b690:	mov    rcx,rax
  40b693:	call   4072a0 <__swc_fn_65555ab2_000003_644dadb7>
  40b698:	test   al,al
  40b69a:	je     40b6a3 <__swc_fn_65555ab2_000061_1badc238+0x363>
  40b69c:	mov    QWORD PTR [rsp+0x10],r14
  40b6a1:	jmp    40b6bb <__swc_fn_65555ab2_000061_1badc238+0x37b>
  40b6a3:	mov    rcx,rbx
  40b6a6:	mov    rdx,r15
  40b6a9:	mov    r8,QWORD PTR [rsp+0x8]
  40b6ae:	mov    r9,QWORD PTR [rsp+0x10]
  40b6b3:	call   40b040 <__swc_fn_65555ab2_000058_033ce1da>
  40b6b8:	xor    r15d,r15d
  40b6bb:	test   r15,r15
  40b6be:	jne    40b73a <__swc_fn_65555ab2_000061_1badc238+0x3fa>
  40b6c0:	cmp    r14,0x10000
  40b6c7:	ja     40b6ce <__swc_fn_65555ab2_000061_1badc238+0x38e>
  40b6c9:	mov    rax,r14
  40b6cc:	jmp    40b71f <__swc_fn_65555ab2_000061_1badc238+0x3df>
  40b6ce:	xor    eax,eax
  40b6d0:	lea    rcx,[r14-0x1]
  40b6d4:	lzcnt  rax,rcx
  40b6d9:	mov    ecx,0x3f
  40b6de:	sub    rcx,rax
  40b6e1:	mov    eax,0x1
  40b6e6:	lea    rcx,[rcx-0x3]
  40b6ea:	shl    rax,cl
  40b6ed:	mov    rcx,rax
  40b6f0:	cmp    rax,0x1000
  40b6f7:	mov    eax,0x1000
  40b6fc:	cmovb  rcx,rax
  40b700:	mov    rdx,0xffffffffffffffff
  40b707:	sub    rdx,rcx
  40b70a:	mov    rax,r14
  40b70d:	lea    r8,[r14+rcx*1-0x1]
  40b712:	neg    rcx
  40b715:	and    r8,rcx
  40b718:	cmp    r14,rdx
  40b71b:	cmovbe rax,r8
  40b71f:	mov    QWORD PTR [rsp+0x8],rax
  40b724:	mov    QWORD PTR [rsp+0x10],r14
  40b729:	mov    rcx,rbx
  40b72c:	mov    rdx,rax
  40b72f:	mov    r8,r14
  40b732:	call   40aaa0 <__swc_fn_65555ab2_000037_92e867c2>
  40b737:	mov    r15,rax
  40b73a:	test   r15,r15
  40b73d:	jne    40b74b <__swc_fn_65555ab2_000061_1badc238+0x40b>
  40b73f:	mov    r13,QWORD PTR [rsp+0x20]
  40b744:	mov    rsi,QWORD PTR [rsp+0x38]
  40b749:	jmp    40b787 <__swc_fn_65555ab2_000061_1badc238+0x447>
  40b74b:	mov    rax,r15
  40b74e:	add    rax,QWORD PTR [rsp+0x28]
  40b753:	mov    r13,QWORD PTR [rsp+0x20]
  40b758:	test   r13d,r13d
  40b75b:	mov    rcx,r13
  40b75e:	mov    edx,0x8
  40b763:	cmove  ecx,edx
  40b766:	dec    rcx
  40b769:	mov    rdx,0xffffffffffffffff
  40b770:	sub    rdx,rcx
  40b773:	cmp    rax,rdx
  40b776:	jbe    40b77c <__swc_fn_65555ab2_000061_1badc238+0x43c>
  40b778:	xor    eax,eax
  40b77a:	jmp    40b784 <__swc_fn_65555ab2_000061_1badc238+0x444>
  40b77c:	add    rax,rcx
  40b77f:	andn   rax,rcx,rax
  40b784:	mov    rsi,rax
  40b787:	mov    rax,QWORD PTR [rsp+0x8]
  40b78c:	test   r15,r15
  40b78f:	je     40b798 <__swc_fn_65555ab2_000061_1badc238+0x458>
  40b791:	mov    rdi,QWORD PTR [rsp+0x18]
  40b796:	jmp    40b7aa <__swc_fn_65555ab2_000061_1badc238+0x46a>
  40b798:	mov    rdi,QWORD PTR [rsp+0x18]
  40b79d:	mov    QWORD PTR [rdi+0x40],0x0
  40b7a5:	jmp    40b826 <__swc_fn_65555ab2_000061_1badc238+0x4e6>
  40b7aa:	lea    rdx,[rsi-0x58]
  40b7ae:	mov    QWORD PTR [rsi-0x58],r15
  40b7b2:	mov    QWORD PTR [rsi-0x50],rax
  40b7b6:	mov    rax,QWORD PTR [rsp+0x10]
  40b7bb:	mov    QWORD PTR [rsi-0x48],rax
  40b7bf:	mov    QWORD PTR [rsi-0x40],rsi
  40b7c3:	mov    rax,QWORD PTR [rdi+0x48]
  40b7c7:	mov    QWORD PTR [rsi-0x38],rax
  40b7cb:	mov    rax,QWORD PTR [rsp+0x30]
  40b7d0:	mov    QWORD PTR [rsi-0x30],rax
  40b7d4:	mov    DWORD PTR [rsi-0x10],r13d
  40b7d8:	mov    QWORD PTR [rsi-0x28],0x0
  40b7e0:	mov    QWORD PTR [rsi-0x20],0x0
  40b7e8:	add    r15,QWORD PTR [r12]
  40b7ec:	sub    r15,rsi
  40b7ef:	mov    QWORD PTR [rsi-0x30],r15
  40b7f3:	mov    rcx,QWORD PTR [rbx+0x250]
  40b7fa:	nop    WORD PTR [rax+rax*1+0x0]
  40b800:	lea    r8,[rcx+r15*1]
  40b804:	mov    rax,rcx
  40b807:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40b810:	cmp    rax,rcx
  40b813:	je     40b81a <__swc_fn_65555ab2_000061_1badc238+0x4da>
  40b815:	mov    rcx,rax
  40b818:	jmp    40b800 <__swc_fn_65555ab2_000061_1badc238+0x4c0>
  40b81a:	mov    rcx,rbx
  40b81d:	call   40e6b0 <__swc_fn_65555ab2_000053_a8a124d6>
  40b822:	mov    QWORD PTR [rdi+0x40],rsi
  40b826:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40b82c:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40b832:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40b838:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40b83e:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40b847:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40b850:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40b859:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40b862:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40b86b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40b874:	add    rsp,0xf0
  40b87b:	pop    rsi
  40b87c:	pop    rdi
  40b87d:	pop    r15
  40b87f:	pop    r14
  40b881:	pop    r13
  40b883:	pop    r12
  40b885:	pop    rbx
  40b886:	ret
	...

000000000040b890 <__swc_fn_65555ab2_000064_6905bec4>:
  40b890:	push   rbx
  40b891:	push   r12
  40b893:	push   rdi
  40b894:	push   rsi
  40b895:	sub    rsp,0xb8
  40b89c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40b8a2:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40b8a8:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40b8ae:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40b8b4:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40b8ba:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40b8c0:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40b8c6:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40b8cf:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40b8d8:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40b8e1:	mov    rbx,rdx
  40b8e4:	mov    r12,rcx
  40b8e7:	cmp    DWORD PTR [rbx+0x58],0x0
  40b8eb:	je     40b905 <__swc_fn_65555ab2_000064_6905bec4+0x75>
  40b8ed:	mov    eax,DWORD PTR [rbx+0x58]
  40b8f0:	sub    eax,0x1
  40b8f3:	test   DWORD PTR [rbx+0x58],eax
  40b8f6:	je     40b905 <__swc_fn_65555ab2_000064_6905bec4+0x75>
  40b8f8:	mov    QWORD PTR [rbx+0x40],0x0
  40b900:	jmp    40bb17 <__swc_fn_65555ab2_000064_6905bec4+0x287>
  40b905:	cmp    QWORD PTR [rbx+0x48],0x0
  40b90a:	jne    40b919 <__swc_fn_65555ab2_000064_6905bec4+0x89>
  40b90c:	mov    QWORD PTR [rbx+0x40],0x0
  40b914:	jmp    40bb17 <__swc_fn_65555ab2_000064_6905bec4+0x287>
  40b919:	lea    rax,[rsp+0x8]
  40b91e:	mov    rcx,QWORD PTR [rbx+0x48]
  40b922:	cmp    rcx,0x8
  40b926:	ja     40b930 <__swc_fn_65555ab2_000064_6905bec4+0xa0>
  40b928:	mov    DWORD PTR [rax],0x0
  40b92e:	jmp    40b98b <__swc_fn_65555ab2_000064_6905bec4+0xfb>
  40b930:	cmp    rcx,0x80
  40b937:	ja     40b947 <__swc_fn_65555ab2_000064_6905bec4+0xb7>
  40b939:	lea    rcx,[rcx+0xf]
  40b93d:	shr    rcx,0x4
  40b941:	mov    DWORD PTR [rsp+0x8],ecx
  40b945:	jmp    40b98b <__swc_fn_65555ab2_000064_6905bec4+0xfb>
  40b947:	cmp    rcx,0x10000
  40b94e:	jbe    40b958 <__swc_fn_65555ab2_000064_6905bec4+0xc8>
  40b950:	mov    DWORD PTR [rax],0xffffffff
  40b956:	jmp    40b98b <__swc_fn_65555ab2_000064_6905bec4+0xfb>
  40b958:	dec    rcx
  40b95b:	xor    edx,edx
  40b95d:	lzcnt  rdx,rcx
  40b962:	mov    r8d,0x3f
  40b968:	sub    r8d,edx
  40b96b:	lea    edx,[r8-0x2]
  40b96f:	shrx   rcx,rcx,rdx
  40b974:	and    ecx,0x3
  40b977:	lea    edx,[r8-0x7]
  40b97b:	lea    edx,[rdx*4+0x0]
  40b982:	lea    edx,[rdx+0x9]
  40b985:	add    edx,ecx
  40b987:	mov    DWORD PTR [rsp+0x8],edx
  40b98b:	cmp    DWORD PTR [rax],0x0
  40b98e:	jne    40b99e <__swc_fn_65555ab2_000064_6905bec4+0x10e>
  40b990:	cmp    DWORD PTR [rbx+0x58],0x8
  40b994:	jbe    40b99e <__swc_fn_65555ab2_000064_6905bec4+0x10e>
  40b996:	mov    DWORD PTR [rsp+0x8],0x1
  40b99e:	cmp    DWORD PTR [rbx+0x58],0x10
  40b9a2:	jbe    40ba21 <__swc_fn_65555ab2_000064_6905bec4+0x191>
  40b9a8:	cmp    DWORD PTR [rbx+0x58],0x40
  40b9ac:	ja     40ba21 <__swc_fn_65555ab2_000064_6905bec4+0x191>
  40b9ae:	cmp    DWORD PTR [rax],0xffffffff
  40b9b1:	je     40ba21 <__swc_fn_65555ab2_000064_6905bec4+0x191>
  40b9b3:	mov    ecx,DWORD PTR [rsp+0x8]
  40b9b7:	mov    edx,DWORD PTR [rbx+0x58]
  40b9ba:	dec    rdx
  40b9bd:	cmp    ecx,0x2d
  40b9c0:	jae    40ba18 <__swc_fn_65555ab2_000064_6905bec4+0x188>
  40b9c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40b9cc:	nop    DWORD PTR [rax+0x0]
  40b9d0:	mov    r8d,ecx
  40b9d3:	test   ecx,ecx
  40b9d5:	jne    40b9df <__swc_fn_65555ab2_000064_6905bec4+0x14f>
  40b9d7:	mov    r8d,0x8
  40b9dd:	jmp    40ba0b <__swc_fn_65555ab2_000064_6905bec4+0x17b>
  40b9df:	cmp    r8d,0x8
  40b9e3:	ja     40b9eb <__swc_fn_65555ab2_000064_6905bec4+0x15b>
  40b9e5:	shl    r8,0x4
  40b9e9:	jmp    40ba0b <__swc_fn_65555ab2_000064_6905bec4+0x17b>
  40b9eb:	lea    r8d,[r8-0x9]
  40b9ef:	mov    r9d,r8d
  40b9f2:	shr    r9d,0x2
  40b9f6:	and    r8d,0x3
  40b9fa:	lea    r9d,[r9+0x7]
  40b9fe:	lea    r9d,[r9-0x2]
  40ba02:	lea    r8d,[r8+0x5]
  40ba06:	shlx   r8,r8,r9
  40ba0b:	test   r8,rdx
  40ba0e:	je     40ba1d <__swc_fn_65555ab2_000064_6905bec4+0x18d>
  40ba10:	add    ecx,0x1
  40ba13:	cmp    ecx,0x2d
  40ba16:	jb     40b9d0 <__swc_fn_65555ab2_000064_6905bec4+0x140>
  40ba18:	mov    ecx,0xffffffff
  40ba1d:	mov    DWORD PTR [rsp+0x8],ecx
  40ba21:	mov    ecx,DWORD PTR [rsp+0x8]
  40ba25:	cmp    ecx,0xffffffff
  40ba28:	je     40ba30 <__swc_fn_65555ab2_000064_6905bec4+0x1a0>
  40ba2a:	cmp    DWORD PTR [rbx+0x58],0x40
  40ba2e:	jbe    40ba43 <__swc_fn_65555ab2_000064_6905bec4+0x1b3>
  40ba30:	mov    rcx,r12
  40ba33:	mov    rdx,rbx
  40ba36:	mov    r8d,DWORD PTR [rax]
  40ba39:	call   40b340 <__swc_fn_65555ab2_000061_1badc238>
  40ba3e:	jmp    40bb17 <__swc_fn_65555ab2_000064_6905bec4+0x287>
  40ba43:	lea    rax,[rip+0x165b6]        # 422000 <__swc_data_base_65555ab2>
  40ba4a:	mov    rax,QWORD PTR [rax]
  40ba4d:	cmp    rax,0xffffffffffffffff
  40ba51:	je     40ba60 <__swc_fn_65555ab2_000064_6905bec4+0x1d0>
  40ba53:	mov    eax,eax
  40ba55:	mov    edi,eax
  40ba57:	xor    eax,eax
  40ba59:	call   407000 <pthread_getspecific@plt>
  40ba5e:	jmp    40ba62 <__swc_fn_65555ab2_000064_6905bec4+0x1d2>
  40ba60:	xor    eax,eax
  40ba62:	test   rax,rax
  40ba65:	jne    40ba74 <__swc_fn_65555ab2_000064_6905bec4+0x1e4>
  40ba67:	call   40a9e0 <__swc_fn_65555ab2_000031_ed8d61a9>
  40ba6c:	mov    rcx,rax
  40ba6f:	call   410380 <__swc_fn_65555ab2_000128_9c45d2d7>
  40ba74:	test   rax,rax
  40ba77:	je     40ba84 <__swc_fn_65555ab2_000064_6905bec4+0x1f4>
  40ba79:	cmp    QWORD PTR [rax],r12
  40ba7c:	jne    40ba84 <__swc_fn_65555ab2_000064_6905bec4+0x1f4>
  40ba7e:	cmp    DWORD PTR [rax+0x20],0x0
  40ba82:	je     40ba8f <__swc_fn_65555ab2_000064_6905bec4+0x1ff>
  40ba84:	mov    rcx,r12
  40ba87:	mov    rdx,rax
  40ba8a:	call   40e2f0 <__swc_fn_65555ab2_000041_ed1cda78>
  40ba8f:	test   rax,rax
  40ba92:	jne    40ba9e <__swc_fn_65555ab2_000064_6905bec4+0x20e>
  40ba94:	mov    QWORD PTR [rbx+0x40],0x0
  40ba9c:	jmp    40bb17 <__swc_fn_65555ab2_000064_6905bec4+0x287>
  40ba9e:	lea    r8,[rsp+0xc]
  40baa3:	mov    ecx,DWORD PTR [rsp+0x8]
  40baa7:	mov    DWORD PTR [rsp+0xc],ecx
  40baab:	mov    ecx,DWORD PTR [r8]
  40baae:	lea    rcx,[rcx+rcx*4]
  40bab2:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40bab7:	test   rcx,rcx
  40baba:	je     40baf3 <__swc_fn_65555ab2_000064_6905bec4+0x263>
  40babc:	mov    rdx,QWORD PTR [rcx]
  40babf:	test   rdx,rdx
  40bac2:	je     40bad0 <__swc_fn_65555ab2_000064_6905bec4+0x240>
  40bac4:	mov    r9,QWORD PTR [rdx]
  40bac7:	mov    QWORD PTR [rcx],r9
  40baca:	add    DWORD PTR [rcx+0x28],0x1
  40bace:	jmp    40baee <__swc_fn_65555ab2_000064_6905bec4+0x25e>
  40bad0:	mov    rdx,QWORD PTR [rcx+0x18]
  40bad4:	cmp    QWORD PTR [rcx+0x20],rdx
  40bad8:	jae    40baec <__swc_fn_65555ab2_000064_6905bec4+0x25c>
  40bada:	mov    rdx,QWORD PTR [rcx+0x20]
  40bade:	mov    r9d,DWORD PTR [rcx+0x2c]
  40bae2:	add    QWORD PTR [rcx+0x20],r9
  40bae6:	add    DWORD PTR [rcx+0x28],0x1
  40baea:	jmp    40baee <__swc_fn_65555ab2_000064_6905bec4+0x25e>
  40baec:	xor    edx,edx
  40baee:	test   rdx,rdx
  40baf1:	jne    40bb04 <__swc_fn_65555ab2_000064_6905bec4+0x274>
  40baf3:	mov    rcx,r12
  40baf6:	mov    rdx,rax
  40baf9:	mov    r8d,DWORD PTR [r8]
  40bafc:	call   40e460 <__swc_fn_65555ab2_000050_e33921d7>
  40bb01:	mov    rdx,rax
  40bb04:	test   rdx,rdx
  40bb07:	jne    40bb13 <__swc_fn_65555ab2_000064_6905bec4+0x283>
  40bb09:	mov    QWORD PTR [rbx+0x40],0x0
  40bb11:	jmp    40bb17 <__swc_fn_65555ab2_000064_6905bec4+0x287>
  40bb13:	mov    QWORD PTR [rbx+0x40],rdx
  40bb17:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40bb1d:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40bb23:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40bb29:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40bb2f:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40bb35:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40bb3b:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40bb41:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40bb4a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40bb53:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40bb5c:	add    rsp,0xb8
  40bb63:	pop    rsi
  40bb64:	pop    rdi
  40bb65:	pop    r12
  40bb67:	pop    rbx
  40bb68:	ret
  40bb69:	add    BYTE PTR [rax],al
  40bb6b:	add    BYTE PTR [rax],al
  40bb6d:	add    BYTE PTR [rax],al
	...

000000000040bb70 <__swc_fn_65555ab2_000067_381f5b88>:
  40bb70:	ret
	...

000000000040bb80 <__swc_fn_65555ab2_000070_2cd83140>:
  40bb80:	push   r12
  40bb82:	push   r13
  40bb84:	push   r14
  40bb86:	push   rdi
  40bb87:	push   rsi
  40bb88:	sub    rsp,0x1a0
  40bb8f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40bb98:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40bba1:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40bbaa:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40bbb3:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40bbbc:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40bbc5:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40bbce:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40bbd7:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40bbe0:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40bbe9:	mov    r12,rdx
  40bbec:	mov    r13,rcx
  40bbef:	mov    rax,QWORD PTR [r12+0x48]
  40bbf4:	mov    ecx,DWORD PTR [r12+0x58]
  40bbf9:	lea    rdx,[rax-0x1]
  40bbfd:	cmp    rdx,0x10000
  40bc04:	jae    40bcfe <__swc_fn_65555ab2_000070_2cd83140+0x17e>
  40bc0a:	cmp    rax,0x8
  40bc0e:	ja     40bc15 <__swc_fn_65555ab2_000070_2cd83140+0x95>
  40bc10:	xor    r14d,r14d
  40bc13:	jmp    40bc67 <__swc_fn_65555ab2_000070_2cd83140+0xe7>
  40bc15:	cmp    rax,0x80
  40bc1c:	ja     40bc28 <__swc_fn_65555ab2_000070_2cd83140+0xa8>
  40bc1e:	lea    r14,[rax+0xf]
  40bc22:	shr    r14,0x4
  40bc26:	jmp    40bc67 <__swc_fn_65555ab2_000070_2cd83140+0xe7>
  40bc28:	cmp    rax,0x10000
  40bc2f:	jbe    40bc39 <__swc_fn_65555ab2_000070_2cd83140+0xb9>
  40bc31:	mov    r14d,0xffffffff
  40bc37:	jmp    40bc67 <__swc_fn_65555ab2_000070_2cd83140+0xe7>
  40bc39:	xor    eax,eax
  40bc3b:	lzcnt  rax,rdx
  40bc40:	mov    r8d,0x3f
  40bc46:	sub    r8d,eax
  40bc49:	lea    eax,[r8-0x2]
  40bc4d:	shrx   rax,rdx,rax
  40bc52:	and    eax,0x3
  40bc55:	lea    edx,[r8-0x7]
  40bc59:	lea    edx,[rdx*4+0x0]
  40bc60:	lea    edx,[rdx+0x9]
  40bc63:	lea    r14d,[rdx+rax*1]
  40bc67:	cmp    ecx,0x8
  40bc6a:	jbe    40bc83 <__swc_fn_65555ab2_000070_2cd83140+0x103>
  40bc6c:	cmp    ecx,0x10
  40bc6f:	jne    40bcfe <__swc_fn_65555ab2_000070_2cd83140+0x17e>
  40bc75:	test   r14d,r14d
  40bc78:	mov    eax,0x1
  40bc7d:	cmove  r14d,eax
  40bc81:	jmp    40bc8a <__swc_fn_65555ab2_000070_2cd83140+0x10a>
  40bc83:	lea    eax,[rcx-0x1]
  40bc86:	test   eax,ecx
  40bc88:	jne    40bcfe <__swc_fn_65555ab2_000070_2cd83140+0x17e>
  40bc8a:	lea    rax,[rip+0x1636f]        # 422000 <__swc_data_base_65555ab2>
  40bc91:	mov    rax,QWORD PTR [rax]
  40bc94:	cmp    rax,0xffffffffffffffff
  40bc98:	je     40bca7 <__swc_fn_65555ab2_000070_2cd83140+0x127>
  40bc9a:	mov    eax,eax
  40bc9c:	mov    edi,eax
  40bc9e:	xor    eax,eax
  40bca0:	call   407000 <pthread_getspecific@plt>
  40bca5:	jmp    40bca9 <__swc_fn_65555ab2_000070_2cd83140+0x129>
  40bca7:	xor    eax,eax
  40bca9:	test   rax,rax
  40bcac:	je     40bcfe <__swc_fn_65555ab2_000070_2cd83140+0x17e>
  40bcae:	cmp    QWORD PTR [rax],r13
  40bcb1:	jne    40bcfe <__swc_fn_65555ab2_000070_2cd83140+0x17e>
  40bcb3:	lea    rcx,[r14+r14*4]
  40bcb7:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40bcbc:	test   rax,rax
  40bcbf:	je     40bcfe <__swc_fn_65555ab2_000070_2cd83140+0x17e>
  40bcc1:	mov    rcx,QWORD PTR [rax]
  40bcc4:	test   rcx,rcx
  40bcc7:	je     40bcd5 <__swc_fn_65555ab2_000070_2cd83140+0x155>
  40bcc9:	mov    rdx,QWORD PTR [rcx]
  40bccc:	mov    QWORD PTR [rax],rdx
  40bccf:	add    DWORD PTR [rax+0x28],0x1
  40bcd3:	jmp    40bcf2 <__swc_fn_65555ab2_000070_2cd83140+0x172>
  40bcd5:	mov    rcx,QWORD PTR [rax+0x18]
  40bcd9:	cmp    QWORD PTR [rax+0x20],rcx
  40bcdd:	jae    40bcf0 <__swc_fn_65555ab2_000070_2cd83140+0x170>
  40bcdf:	mov    rcx,QWORD PTR [rax+0x20]
  40bce3:	mov    edx,DWORD PTR [rax+0x2c]
  40bce6:	add    QWORD PTR [rax+0x20],rdx
  40bcea:	add    DWORD PTR [rax+0x28],0x1
  40bcee:	jmp    40bcf2 <__swc_fn_65555ab2_000070_2cd83140+0x172>
  40bcf0:	xor    ecx,ecx
  40bcf2:	test   rcx,rcx
  40bcf5:	je     40bcfe <__swc_fn_65555ab2_000070_2cd83140+0x17e>
  40bcf7:	mov    QWORD PTR [r12+0x40],rcx
  40bcfc:	jmp    40bd09 <__swc_fn_65555ab2_000070_2cd83140+0x189>
  40bcfe:	mov    rcx,r13
  40bd01:	mov    rdx,r12
  40bd04:	call   40eee0 <__swc_fn_65555ab2_000071_7e144e9b>
  40bd09:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40bd12:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40bd1b:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40bd24:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40bd2d:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40bd36:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40bd3f:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40bd48:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40bd51:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40bd5a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40bd63:	add    rsp,0x1a0
  40bd6a:	pop    rsi
  40bd6b:	pop    rdi
  40bd6c:	pop    r14
  40bd6e:	pop    r13
  40bd70:	pop    r12
  40bd72:	ret
	...

000000000040bd80 <__swc_fn_65555ab2_000073_c77adf75>:
  40bd80:	push   r12
  40bd82:	push   r13
  40bd84:	push   r14
  40bd86:	push   r15
  40bd88:	push   rdi
  40bd89:	push   rsi
  40bd8a:	sub    rsp,0x188
  40bd91:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40bd9a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40bda3:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40bdac:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40bdb5:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40bdbe:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40bdc7:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40bdd0:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40bdd9:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40bde2:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40bdeb:	mov    r12,rdx
  40bdee:	mov    r13,rcx
  40bdf1:	mov    r14,QWORD PTR [r12+0x40]
  40bdf6:	lea    rax,[rip+0x18273]        # 424070 <__swc_bss_base_65555ab2+0x30>
  40bdfd:	mov    rcx,r14
  40be00:	sub    rcx,QWORD PTR [rax+0x8]
  40be04:	mov    rax,QWORD PTR [rip+0x18275]        # 424080 <__swc_bss_base_65555ab2+0x40>
  40be0b:	cmp    rcx,rax
  40be0e:	jae    40be3a <__swc_fn_65555ab2_000073_c77adf75+0xba>
  40be10:	mov    rax,r14
  40be13:	and    rax,0xffffffffffc00000
  40be1a:	mov    rcx,r14
  40be1d:	shr    rcx,0x10
  40be21:	and    ecx,0x3f
  40be24:	mov    edx,DWORD PTR [rax+0x28]
  40be27:	shrx   ecx,ecx,edx
  40be2c:	shl    rcx,0x4
  40be30:	lea    r15,[rax+rcx*8+0x80]
  40be38:	jmp    40be45 <__swc_fn_65555ab2_000073_c77adf75+0xc5>
  40be3a:	mov    rcx,r14
  40be3d:	call   40a910 <__swc_fn_65555ab2_000022_77c2d682>
  40be42:	mov    r15,rax
  40be45:	test   r15,r15
  40be48:	je     40beef <__swc_fn_65555ab2_000073_c77adf75+0x16f>
  40be4e:	lea    rax,[rip+0x161ab]        # 422000 <__swc_data_base_65555ab2>
  40be55:	mov    rax,QWORD PTR [rax]
  40be58:	cmp    rax,0xffffffffffffffff
  40be5c:	je     40be6b <__swc_fn_65555ab2_000073_c77adf75+0xeb>
  40be5e:	mov    eax,eax
  40be60:	mov    edi,eax
  40be62:	xor    eax,eax
  40be64:	call   407000 <pthread_getspecific@plt>
  40be69:	jmp    40be6d <__swc_fn_65555ab2_000073_c77adf75+0xed>
  40be6b:	xor    eax,eax
  40be6d:	mov    rcx,QWORD PTR [r15+0x40]
  40be71:	cmp    rcx,rax
  40be74:	jne    40bed4 <__swc_fn_65555ab2_000073_c77adf75+0x154>
  40be76:	test   rax,rax
  40be79:	je     40beef <__swc_fn_65555ab2_000073_c77adf75+0x16f>
  40be7b:	mov    ecx,DWORD PTR [r15+0x6c]
  40be7f:	test   ecx,ecx
  40be81:	je     40bea1 <__swc_fn_65555ab2_000073_c77adf75+0x121>
  40be83:	mov    rcx,r13
  40be86:	mov    rdx,rax
  40be89:	mov    r8,r15
  40be8c:	mov    QWORD PTR [rsp+0xd8],rax
  40be94:	call   40e3f0 <__swc_fn_65555ab2_000047_3d3eceb4>
  40be99:	mov    rax,QWORD PTR [rsp+0xd8]
  40bea1:	mov    rcx,QWORD PTR [r15]
  40bea4:	mov    QWORD PTR [r14],rcx
  40bea7:	mov    QWORD PTR [r15],r14
  40beaa:	sub    DWORD PTR [r15+0x28],0x1
  40beaf:	jne    40bee4 <__swc_fn_65555ab2_000073_c77adf75+0x164>
  40beb1:	movzx  ecx,BYTE PTR [r15+0x39]
  40beb6:	lea    rcx,[rcx+rcx*4]
  40beba:	lea    rcx,[rax+rcx*8+0x28]
  40bebf:	cmp    QWORD PTR [rcx],r15
  40bec2:	je     40bee4 <__swc_fn_65555ab2_000073_c77adf75+0x164>
  40bec4:	mov    rcx,r13
  40bec7:	mov    rdx,rax
  40beca:	mov    r8,r15
  40becd:	call   407d80 <__swc_fn_65555ab2_000051_5b91e689>
  40bed2:	jmp    40bee4 <__swc_fn_65555ab2_000073_c77adf75+0x164>
  40bed4:	test   rcx,rcx
  40bed7:	je     40beef <__swc_fn_65555ab2_000073_c77adf75+0x16f>
  40bed9:	mov    rcx,r15
  40bedc:	mov    rdx,r14
  40bedf:	call   40a550 <__swc_fn_65555ab2_000010_186cd0c2>
  40bee4:	mov    QWORD PTR [r12+0x40],0x0
  40beed:	jmp    40befa <__swc_fn_65555ab2_000073_c77adf75+0x17a>
  40beef:	mov    rcx,r13
  40bef2:	mov    rdx,r12
  40bef5:	call   40ef00 <__swc_fn_65555ab2_000074_9eaf4878>
  40befa:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40bf03:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40bf0c:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40bf15:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40bf1e:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40bf27:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40bf30:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40bf39:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40bf42:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40bf4b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40bf54:	add    rsp,0x188
  40bf5b:	pop    rsi
  40bf5c:	pop    rdi
  40bf5d:	pop    r15
  40bf5f:	pop    r14
  40bf61:	pop    r13
  40bf63:	pop    r12
  40bf65:	ret
	...

000000000040bf70 <__swc_fn_65555ab2_000076_d8e626b0>:
  40bf70:	sub    rsp,0x8
  40bf74:	mov    rax,rdx
  40bf77:	mov    rdx,QWORD PTR [rax+0x40]
  40bf7b:	mov    r8,rax
  40bf7e:	call   40bb70 <__swc_fn_65555ab2_000067_381f5b88>
  40bf83:	add    rsp,0x8
  40bf87:	ret
	...

000000000040bf90 <__swc_fn_65555ab2_000079_29fad089>:
  40bf90:	push   rsi
  40bf91:	push   rdi
  40bf92:	sub    rsp,0x8
  40bf96:	cmp    rcx,0xffffffffffffffef
  40bf9a:	ja     40bfc0 <__swc_fn_65555ab2_000079_29fad089+0x30>
  40bf9c:	xor    esi,esi
  40bf9e:	lea    rax,[rcx+0x100f]
  40bfa5:	and    rax,0xfffffffffffff000
  40bfac:	lea    rcx,[rcx+0x10]
  40bfb0:	cmp    rcx,0xfffffffffffff000
  40bfb7:	cmovbe rsi,rax
  40bfbb:	test   rsi,rsi
  40bfbe:	jne    40bfc9 <__swc_fn_65555ab2_000079_29fad089+0x39>
  40bfc0:	xor    eax,eax
  40bfc2:	add    rsp,0x8
  40bfc6:	pop    rdi
  40bfc7:	pop    rsi
  40bfc8:	ret
  40bfc9:	mov    rcx,rsi
  40bfcc:	call   40c620 <__swc_fn_65555ab2_000109_aa570b2b>
  40bfd1:	mov    rdi,rax
  40bfd4:	test   rax,rax
  40bfd7:	jne    40bfe2 <__swc_fn_65555ab2_000079_29fad089+0x52>
  40bfd9:	xor    eax,eax
  40bfdb:	add    rsp,0x8
  40bfdf:	pop    rdi
  40bfe0:	pop    rsi
  40bfe1:	ret
  40bfe2:	mov    rcx,rdi
  40bfe5:	mov    rdx,rsi
  40bfe8:	call   409240 <__swc_fn_65555ab2_000111_e724f834>
  40bfed:	test   al,al
  40bfef:	jne    40c005 <__swc_fn_65555ab2_000079_29fad089+0x75>
  40bff1:	mov    rcx,rdi
  40bff4:	mov    rdx,rsi
  40bff7:	call   410030 <__swc_fn_65555ab2_000113_25e345b1>
  40bffc:	xor    eax,eax
  40bffe:	add    rsp,0x8
  40c002:	pop    rdi
  40c003:	pop    rsi
  40c004:	ret
  40c005:	mov    QWORD PTR [rdi],rsi
  40c008:	mov    QWORD PTR [rdi+0x8],0x0
  40c010:	lea    rax,[rdi+0x10]
  40c014:	add    rsp,0x8
  40c018:	pop    rdi
  40c019:	pop    rsi
  40c01a:	ret
  40c01b:	add    BYTE PTR [rax],al
  40c01d:	add    BYTE PTR [rax],al
	...

000000000040c020 <__swc_fn_65555ab2_000082_9f4f5092>:
  40c020:	sub    rsp,0x8
  40c024:	cmp    BYTE PTR [rcx+0x2c],0x10
  40c028:	jne    40c033 <__swc_fn_65555ab2_000082_9f4f5092+0x13>
  40c02a:	test   DWORD PTR [rcx+0x28],0x80
  40c031:	je     40c03b <__swc_fn_65555ab2_000082_9f4f5092+0x1b>
  40c033:	mov    rax,rcx
  40c036:	add    rsp,0x8
  40c03a:	ret
  40c03b:	mov    rcx,QWORD PTR [rcx+0x40]
  40c03f:	call   40c020 <__swc_fn_65555ab2_000082_9f4f5092>
  40c044:	add    rsp,0x8
  40c048:	ret
	...

000000000040c060 <__swc_fn_65555ab2_000085_88128f21>:
  40c060:	push   rsi
  40c061:	push   rdi
  40c062:	push   r12
  40c064:	push   r13
  40c066:	sub    rsp,0x8
  40c06a:	mov    rsi,rdx
  40c06d:	mov    rdi,rcx
  40c070:	xor    r8d,r8d
  40c073:	call   4085a0 <__swc_fn_65555ab2_000090_9a1d717d>
  40c078:	test   al,al
  40c07a:	je     40c08c <__swc_fn_65555ab2_000085_88128f21+0x2c>
  40c07c:	mov    eax,0x1
  40c081:	add    rsp,0x8
  40c085:	pop    r13
  40c087:	pop    r12
  40c089:	pop    rdi
  40c08a:	pop    rsi
  40c08b:	ret
  40c08c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40c091:	je     40c0a0 <__swc_fn_65555ab2_000085_88128f21+0x40>
  40c093:	xor    eax,eax
  40c095:	add    rsp,0x8
  40c099:	pop    r13
  40c09b:	pop    r12
  40c09d:	pop    rdi
  40c09e:	pop    rsi
  40c09f:	ret
  40c0a0:	mov    r12,QWORD PTR [rsi+0x98]
  40c0a7:	mov    rax,QWORD PTR [rsi+0xa0]
  40c0ae:	mov    rsi,rax
  40c0b1:	xor    r13d,r13d
  40c0b4:	test   rsi,rsi
  40c0b7:	je     40c114 <__swc_fn_65555ab2_000085_88128f21+0xb4>
  40c0b9:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0c3:	cs nop WORD PTR [rax+rax*1+0x0]
  40c0cd:	nop    DWORD PTR [rax]
  40c0d0:	lea    rax,[r13*8+0x0]
  40c0d8:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40c0dd:	mov    rcx,rax
  40c0e0:	call   40c020 <__swc_fn_65555ab2_000082_9f4f5092>
  40c0e5:	cmp    BYTE PTR [rax+0x2c],0xe
  40c0e9:	jne    40c10a <__swc_fn_65555ab2_000085_88128f21+0xaa>
  40c0eb:	mov    rcx,rdi
  40c0ee:	mov    rdx,rax
  40c0f1:	call   40c060 <__swc_fn_65555ab2_000085_88128f21>
  40c0f6:	test   al,al
  40c0f8:	je     40c10a <__swc_fn_65555ab2_000085_88128f21+0xaa>
  40c0fa:	mov    eax,0x1
  40c0ff:	add    rsp,0x8
  40c103:	pop    r13
  40c105:	pop    r12
  40c107:	pop    rdi
  40c108:	pop    rsi
  40c109:	ret
  40c10a:	add    r13,0x1
  40c10e:	sub    rsi,0x1
  40c112:	jne    40c0d0 <__swc_fn_65555ab2_000085_88128f21+0x70>
  40c114:	xor    eax,eax
  40c116:	add    rsp,0x8
  40c11a:	pop    r13
  40c11c:	pop    r12
  40c11e:	pop    rdi
  40c11f:	pop    rsi
  40c120:	ret
	...

000000000040c130 <__swc_fn_65555ab2_000088_17711411>:
  40c130:	sub    rsp,0x18
  40c134:	vxorps xmm0,xmm0,xmm0
  40c138:	vmovdqu XMMWORD PTR [rsp],xmm0
  40c13d:	call   40f110 <__swc_fn_65555ab2_000089_157b05de>
  40c142:	add    rsp,0x18
  40c146:	ret
	...

000000000040c150 <__swc_fn_65555ab2_000091_e6773530>:
  40c150:	sub    rsp,0x8
  40c154:	mov    rcx,QWORD PTR [rip+0x1abe5]        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  40c15b:	test   rcx,rcx
  40c15e:	jne    40c170 <__swc_fn_65555ab2_000091_e6773530+0x20>
  40c160:	call   40a1a0 <__swc_fn_65555ab2_000165_e09accff>
  40c165:	lea    rcx,[rax+0x1]
  40c169:	mov    QWORD PTR [rip+0x1abd0],rcx        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  40c170:	dec    rcx
  40c173:	call   411e00 <__swc_fn_65555ab2_000167_3130645d>
  40c178:	mov    rax,QWORD PTR [rax+0xc0]
  40c17f:	and    eax,0x1
  40c182:	setne  al
  40c185:	add    rsp,0x8
  40c189:	ret
	...

000000000040c1a0 <__swc_fn_65555ab2_000094_335e9a12>:
  40c1a0:	push   rbx
  40c1a1:	push   rsi
  40c1a2:	push   rdi
  40c1a3:	push   r12
  40c1a5:	sub    rsp,0x28
  40c1a9:	mov    rbx,rcx
  40c1ac:	call   408900 <__swc_fn_65555ab2_000093_344f5089>
  40c1b1:	mov    rcx,QWORD PTR [rip+0x1ab88]        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  40c1b8:	test   rcx,rcx
  40c1bb:	jne    40c1cd <__swc_fn_65555ab2_000094_335e9a12+0x2d>
  40c1bd:	call   40a1a0 <__swc_fn_65555ab2_000165_e09accff>
  40c1c2:	lea    rcx,[rax+0x1]
  40c1c6:	mov    QWORD PTR [rip+0x1ab73],rcx        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  40c1cd:	dec    rcx
  40c1d0:	call   411e00 <__swc_fn_65555ab2_000167_3130645d>
  40c1d5:	mov    rsi,rax
  40c1d8:	lea    rcx,[rsp+0x8]
  40c1dd:	call   40f550 <__swc_fn_65555ab2_000092_17e20532>
  40c1e2:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40c1e9:	mov    r12,QWORD PTR [rsi+0xbe8]
  40c1f0:	lea    rcx,[rsi+0x10]
  40c1f4:	call   40d170 <__swc_fn_65555ab2_000157_5c8b11d8>
  40c1f9:	mov    rcx,rsi
  40c1fc:	call   40f6c0 <__swc_fn_65555ab2_000101_295ddd7c>
  40c201:	vxorps xmm0,xmm0,xmm0
  40c205:	xor    eax,eax
  40c207:	cs nop WORD PTR [rax+rax*1+0x0]
  40c211:	cs nop WORD PTR [rax+rax*1+0x0]
  40c21b:	nop    DWORD PTR [rax+rax*1+0x0]
  40c220:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40c225:	add    rax,0x10
  40c229:	cmp    rax,0xbf0
  40c230:	jne    40c220 <__swc_fn_65555ab2_000094_335e9a12+0x80>
  40c232:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c238:	vmovups XMMWORD PTR [rsi],xmm0
  40c23c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c242:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40c24a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40c251:	mov    QWORD PTR [rsi+0xbe8],r12
  40c258:	mov    rcx,QWORD PTR [rip+0x1aae1]        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  40c25f:	test   rcx,rcx
  40c262:	jne    40c274 <__swc_fn_65555ab2_000094_335e9a12+0xd4>
  40c264:	call   40a1a0 <__swc_fn_65555ab2_000165_e09accff>
  40c269:	lea    rcx,[rax+0x1]
  40c26d:	mov    QWORD PTR [rip+0x1aacc],rcx        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  40c274:	dec    rcx
  40c277:	call   411e00 <__swc_fn_65555ab2_000167_3130645d>
  40c27c:	mov    rsi,rax
  40c27f:	mov    QWORD PTR [rsi+0xc0],rbx
  40c286:	and    ebx,0x1
  40c289:	jne    40c28d <__swc_fn_65555ab2_000094_335e9a12+0xed>
  40c28b:	xor    eax,eax
  40c28d:	test   rbx,rbx
  40c290:	sete   al
  40c293:	xor    cl,cl
  40c295:	xor    dl,dl
  40c297:	xor    r8b,r8b
  40c29a:	xor    r9b,r9b
  40c29d:	xor    r10b,r10b
  40c2a0:	mov    r11,rax
  40c2a3:	call   40ef10 <__swc_fn_65555ab2_000077_e793b5e1>
  40c2a8:	lea    rbx,[rsp+0x18]
  40c2ad:	mov    rcx,rbx
  40c2b0:	call   40f550 <__swc_fn_65555ab2_000092_17e20532>
  40c2b5:	lea    rcx,[rsi+0x10]
  40c2b9:	mov    edx,0x400000
  40c2be:	mov    r8,rbx
  40c2c1:	call   409ee0 <__swc_fn_65555ab2_000159_9d602c76>
  40c2c6:	lea    rcx,[rsi+0x68]
  40c2ca:	mov    edx,0x4000
  40c2cf:	mov    r8,rbx
  40c2d2:	call   409ee0 <__swc_fn_65555ab2_000159_9d602c76>
  40c2d7:	add    rsp,0x28
  40c2db:	pop    r12
  40c2dd:	pop    rdi
  40c2de:	pop    rsi
  40c2df:	pop    rbx
  40c2e0:	ret
	...

000000000040c2f0 <__swc_fn_65555ab2_000097_8b4a07e9>:
  40c2f0:	push   rbx
  40c2f1:	push   rsi
  40c2f2:	sub    rsp,0x18
  40c2f6:	mov    rbx,rcx
  40c2f9:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40c2fe:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c304:	mov    rsi,QWORD PTR [rbx+0x70]
  40c308:	lea    rcx,[rcx+0x18]
  40c30c:	call   40d170 <__swc_fn_65555ab2_000157_5c8b11d8>
  40c311:	lea    rcx,[rsp+0x8]
  40c316:	mov    rdx,rbx
  40c319:	mov    r8d,0x78
  40c31f:	call   408960 <__swc_fn_65555ab2_000096_f879630a>
  40c324:	mov    rax,rsi
  40c327:	add    rsp,0x18
  40c32b:	pop    rsi
  40c32c:	pop    rbx
  40c32d:	ret
	...

000000000040c330 <__swc_fn_65555ab2_000100_2ef16a3e>:
  40c330:	push   rsi
  40c331:	push   rdi
  40c332:	sub    rsp,0x8
  40c336:	cmp    QWORD PTR [rcx],0x0
  40c33a:	jne    40c343 <__swc_fn_65555ab2_000100_2ef16a3e+0x13>
  40c33c:	add    rsp,0x8
  40c340:	pop    rdi
  40c341:	pop    rsi
  40c342:	ret
  40c343:	mov    rsi,QWORD PTR [rcx]
  40c346:	mov    rax,QWORD PTR [rcx+0x8]
  40c34a:	test   rax,rax
  40c34d:	je     40c363 <__swc_fn_65555ab2_000100_2ef16a3e+0x33>
  40c34f:	test   DWORD PTR [rax+0x28],0x400000
  40c356:	je     40c363 <__swc_fn_65555ab2_000100_2ef16a3e+0x33>
  40c358:	mov    rcx,QWORD PTR [rax+0x30]
  40c35c:	test   rcx,rcx
  40c35f:	cmovne rax,rcx
  40c363:	lea    rdx,[rip+0x6e66]        # 4131d0 <__swc_rdata_base_65555ab2+0xc0>
  40c36a:	lea    rcx,[rip+0x6f47]        # 4132b8 <__swc_rdata_base_65555ab2+0x1a8>
  40c371:	mov    r8,rax
  40c374:	xor    r9d,r9d
  40c377:	xor    al,al
  40c379:	mov    r10,rax
  40c37c:	xor    r11d,r11d
  40c37f:	call   40c130 <__swc_fn_65555ab2_000088_17711411>
  40c384:	test   rax,rax
  40c387:	je     40c397 <__swc_fn_65555ab2_000100_2ef16a3e+0x67>
  40c389:	mov    rdi,QWORD PTR [rax+0x48]
  40c38d:	test   rdi,rdi
  40c390:	je     40c397 <__swc_fn_65555ab2_000100_2ef16a3e+0x67>
  40c392:	mov    rcx,rsi
  40c395:	call   rdi
  40c397:	add    rsp,0x8
  40c39b:	pop    rdi
  40c39c:	pop    rsi
  40c39d:	ret
	...

000000000040c3a0 <__swc_fn_65555ab2_000103_2ed36338>:
  40c3a0:	push   rbx
  40c3a1:	push   rsi
  40c3a2:	push   rdi
  40c3a3:	sub    rsp,0x20
  40c3a7:	mov    rbx,rdx
  40c3aa:	mov    rsi,rcx
  40c3ad:	mov    rcx,QWORD PTR [rip+0x1a98c]        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  40c3b4:	test   rcx,rcx
  40c3b7:	jne    40c3c9 <__swc_fn_65555ab2_000103_2ed36338+0x29>
  40c3b9:	call   40a1a0 <__swc_fn_65555ab2_000165_e09accff>
  40c3be:	lea    rcx,[rax+0x1]
  40c3c2:	mov    QWORD PTR [rip+0x1a977],rcx        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  40c3c9:	dec    rcx
  40c3cc:	call   411e00 <__swc_fn_65555ab2_000167_3130645d>
  40c3d1:	mov    rdi,rax
  40c3d4:	mov    rax,QWORD PTR [rdi+0xbd0]
  40c3db:	xor    ecx,ecx
  40c3dd:	test   rax,rax
  40c3e0:	je     40c3e5 <__swc_fn_65555ab2_000103_2ed36338+0x45>
  40c3e2:	mov    rcx,QWORD PTR [rax]
  40c3e5:	call   40a2d0 <__swc_fn_65555ab2_000174_738eec22>
  40c3ea:	lea    rax,[rsp+0x8]
  40c3ef:	lea    rcx,[rdi+0x9c8]
  40c3f6:	mov    QWORD PTR [rsp+0x8],rcx
  40c3fb:	mov    QWORD PTR [rax+0x8],0x40
  40c403:	xor    ecx,ecx
  40c405:	mov    rdx,rax
  40c408:	call   410160 <__swc_fn_65555ab2_000119_18cd3882>
  40c40d:	mov    DWORD PTR [rdi+0xbc8],eax
  40c413:	mov    rdi,QWORD PTR [rdi+0x990]
  40c41a:	test   rdi,rdi
  40c41d:	je     40c427 <__swc_fn_65555ab2_000103_2ed36338+0x87>
  40c41f:	mov    rcx,rsi
  40c422:	mov    rdx,rbx
  40c425:	call   rdi
  40c427:	call   40c150 <__swc_fn_65555ab2_000091_e6773530>
  40c42c:	test   al,al
  40c42e:	je     40c43e <__swc_fn_65555ab2_000103_2ed36338+0x9e>
  40c430:	mov    rcx,rsi
  40c433:	mov    rdx,rbx
  40c436:	xor    r8d,r8d
  40c439:	call   4093e0 <__swc_fn_65555ab2_000120_1601f378>
  40c43e:	mov    rcx,rsi
  40c441:	mov    rdx,rbx
  40c444:	call   408a60 <__swc_fn_65555ab2_000102_29a1093a>
  40c449:	call   40c9d0 <__swc_fn_65555ab2_000118_2b35b5e0>
  40c44e:	add    rsp,0x20
  40c452:	pop    rdi
  40c453:	pop    rsi
  40c454:	pop    rbx
  40c455:	ret
	...

000000000040c460 <__swc_fn_65555ab2_000106_77a5d54a>:
  40c460:	test   r8,r8
  40c463:	jne    40c468 <__swc_fn_65555ab2_000106_77a5d54a+0x8>
  40c465:	xor    eax,eax
  40c467:	ret
  40c468:	xor    eax,eax
  40c46a:	nop    WORD PTR [rax+rax*1+0x0]
  40c470:	mov    r9,r8
  40c473:	sub    r9,rax
  40c476:	cmp    r9,0x10
  40c47a:	jb     40c4c4 <__swc_fn_65555ab2_000106_77a5d54a+0x64>
  40c47c:	lea    r9,[rcx+rax*1]
  40c480:	lea    r10,[rdx+rax*1]
  40c484:	vmovups xmm0,XMMWORD PTR [r10]
  40c489:	vmovups xmm1,XMMWORD PTR [r9]
  40c48e:	vpcmpeqb xmm0,xmm1,xmm0
  40c492:	vpmovmskb r9d,xmm0
  40c496:	cmp    r9d,0xffff
  40c49d:	je     40c4be <__swc_fn_65555ab2_000106_77a5d54a+0x5e>
  40c49f:	not    r9d
  40c4a2:	xor    r8d,r8d
  40c4a5:	movzx  r9d,r9w
  40c4a9:	tzcnt  r8d,r9d
  40c4ae:	add    rax,r8
  40c4b1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4b5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4b9:	sub    ecx,eax
  40c4bb:	mov    eax,ecx
  40c4bd:	ret
  40c4be:	lea    rax,[rax+0x10]
  40c4c2:	jmp    40c470 <__swc_fn_65555ab2_000106_77a5d54a+0x10>
  40c4c4:	cmp    r9,0x8
  40c4c8:	jb     40c53b <__swc_fn_65555ab2_000106_77a5d54a+0xdb>
  40c4ca:	lea    r9,[rcx+rax*1]
  40c4ce:	lea    r10,[rdx+rax*1]
  40c4d2:	mov    r9,QWORD PTR [r9]
  40c4d5:	xor    r9,QWORD PTR [r10]
  40c4d8:	test   r9,r9
  40c4db:	je     40c4f9 <__swc_fn_65555ab2_000106_77a5d54a+0x99>
  40c4dd:	xor    r8d,r8d
  40c4e0:	tzcnt  r8,r9
  40c4e5:	shr    r8,0x3
  40c4e9:	add    rax,r8
  40c4ec:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4f0:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4f4:	sub    ecx,eax
  40c4f6:	mov    eax,ecx
  40c4f8:	ret
  40c4f9:	lea    rax,[rax+0x8]
  40c4fd:	cmp    rax,r8
  40c500:	jne    40c505 <__swc_fn_65555ab2_000106_77a5d54a+0xa5>
  40c502:	xor    eax,eax
  40c504:	ret
  40c505:	lea    rax,[r8-0x8]
  40c509:	lea    r8,[rcx+rax*1]
  40c50d:	lea    r9,[rdx+rax*1]
  40c511:	mov    r8,QWORD PTR [r8]
  40c514:	xor    r8,QWORD PTR [r9]
  40c517:	test   r8,r8
  40c51a:	je     40c538 <__swc_fn_65555ab2_000106_77a5d54a+0xd8>
  40c51c:	xor    r9d,r9d
  40c51f:	tzcnt  r9,r8
  40c524:	shr    r9,0x3
  40c528:	add    rax,r9
  40c52b:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c52f:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c533:	sub    ecx,eax
  40c535:	mov    eax,ecx
  40c537:	ret
  40c538:	xor    eax,eax
  40c53a:	ret
  40c53b:	cmp    r9,0x4
  40c53f:	jb     40c5b2 <__swc_fn_65555ab2_000106_77a5d54a+0x152>
  40c541:	lea    r9,[rcx+rax*1]
  40c545:	lea    r10,[rdx+rax*1]
  40c549:	mov    r9d,DWORD PTR [r9]
  40c54c:	xor    r9d,DWORD PTR [r10]
  40c54f:	test   r9d,r9d
  40c552:	je     40c570 <__swc_fn_65555ab2_000106_77a5d54a+0x110>
  40c554:	xor    r8d,r8d
  40c557:	tzcnt  r8,r9
  40c55c:	shr    r8,0x3
  40c560:	add    rax,r8
  40c563:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c567:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c56b:	sub    ecx,eax
  40c56d:	mov    eax,ecx
  40c56f:	ret
  40c570:	lea    rax,[rax+0x4]
  40c574:	cmp    rax,r8
  40c577:	jne    40c57c <__swc_fn_65555ab2_000106_77a5d54a+0x11c>
  40c579:	xor    eax,eax
  40c57b:	ret
  40c57c:	lea    rax,[r8-0x4]
  40c580:	lea    r8,[rcx+rax*1]
  40c584:	lea    r9,[rdx+rax*1]
  40c588:	mov    r8d,DWORD PTR [r8]
  40c58b:	xor    r8d,DWORD PTR [r9]
  40c58e:	test   r8d,r8d
  40c591:	je     40c5af <__swc_fn_65555ab2_000106_77a5d54a+0x14f>
  40c593:	xor    r9d,r9d
  40c596:	tzcnt  r9,r8
  40c59b:	shr    r9,0x3
  40c59f:	add    rax,r9
  40c5a2:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c5a6:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c5aa:	sub    ecx,eax
  40c5ac:	mov    eax,ecx
  40c5ae:	ret
  40c5af:	xor    eax,eax
  40c5b1:	ret
  40c5b2:	cmp    r9,0x2
  40c5b6:	jb     40c609 <__swc_fn_65555ab2_000106_77a5d54a+0x1a9>
  40c5b8:	lea    r9,[rcx+rax*1]
  40c5bc:	lea    r10,[rdx+rax*1]
  40c5c0:	mov    r9w,WORD PTR [r9]
  40c5c4:	xor    r9w,WORD PTR [r10]
  40c5c8:	test   r9w,r9w
  40c5cc:	je     40c5ee <__swc_fn_65555ab2_000106_77a5d54a+0x18e>
  40c5ce:	xor    r8d,r8d
  40c5d1:	movzx  r9d,r9w
  40c5d5:	tzcnt  r8,r9
  40c5da:	shr    r8,0x3
  40c5de:	add    rax,r8
  40c5e1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c5e5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c5e9:	sub    ecx,eax
  40c5eb:	mov    eax,ecx
  40c5ed:	ret
  40c5ee:	lea    rax,[rax+0x2]
  40c5f2:	cmp    rax,r8
  40c5f5:	jne    40c5fa <__swc_fn_65555ab2_000106_77a5d54a+0x19a>
  40c5f7:	xor    eax,eax
  40c5f9:	ret
  40c5fa:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40c600:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40c606:	sub    eax,ecx
  40c608:	ret
  40c609:	test   r9,r9
  40c60c:	je     40c61b <__swc_fn_65555ab2_000106_77a5d54a+0x1bb>
  40c60e:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c612:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c616:	sub    ecx,eax
  40c618:	mov    eax,ecx
  40c61a:	ret
  40c61b:	xor    eax,eax
  40c61d:	ret
	...

000000000040c620 <__swc_fn_65555ab2_000109_aa570b2b>:
  40c620:	push   r12
  40c622:	push   r13
  40c624:	push   r14
  40c626:	push   rdi
  40c627:	push   rsi
  40c628:	push   r15
  40c62a:	sub    rsp,0xd8
  40c631:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c637:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c63d:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c643:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c649:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c64f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c658:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c661:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c66a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c673:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c67c:	mov    r12,rcx
  40c67f:	test   rcx,rcx
  40c682:	je     40c69e <__swc_fn_65555ab2_000109_aa570b2b+0x7e>
  40c684:	mov    eax,r12d
  40c687:	and    eax,0xfff
  40c68d:	setne  al
  40c690:	cmp    r12,0xffffffffffffefff
  40c697:	seta   cl
  40c69a:	or     al,cl
  40c69c:	je     40c6a5 <__swc_fn_65555ab2_000109_aa570b2b+0x85>
  40c69e:	xor    eax,eax
  40c6a0:	jmp    40c73b <__swc_fn_65555ab2_000109_aa570b2b+0x11b>
  40c6a5:	call   409100 <__swc_fn_65555ab2_000108_32416b9e>
  40c6aa:	mov    r13,rax
  40c6ad:	test   rax,rax
  40c6b0:	jne    40c6b9 <__swc_fn_65555ab2_000109_aa570b2b+0x99>
  40c6b2:	xor    eax,eax
  40c6b4:	jmp    40c73b <__swc_fn_65555ab2_000109_aa570b2b+0x11b>
  40c6b9:	lea    r14,[r12+0x1000]
  40c6c1:	xor    edi,edi
  40c6c3:	mov    rsi,r14
  40c6c6:	xor    edx,edx
  40c6c8:	mov    ecx,0x22
  40c6cd:	mov    eax,0xffffffff
  40c6d2:	movsxd r8,eax
  40c6d5:	xor    r9d,r9d
  40c6d8:	xor    eax,eax
  40c6da:	call   4070c0 <mmap@plt>
  40c6df:	mov    r15,rax
  40c6e2:	cmp    rax,0xffffffffffffffff
  40c6e6:	jne    40c6ec <__swc_fn_65555ab2_000109_aa570b2b+0xcc>
  40c6e8:	xor    eax,eax
  40c6ea:	jmp    40c73b <__swc_fn_65555ab2_000109_aa570b2b+0x11b>
  40c6ec:	mov    rdi,r15
  40c6ef:	mov    esi,0x1000
  40c6f4:	mov    edx,0x3
  40c6f9:	xor    eax,eax
  40c6fb:	call   407030 <mprotect@plt>
  40c700:	test   eax,eax
  40c702:	je     40c715 <__swc_fn_65555ab2_000109_aa570b2b+0xf5>
  40c704:	mov    rdi,r15
  40c707:	mov    rsi,r14
  40c70a:	xor    eax,eax
  40c70c:	call   407020 <munmap@plt>
  40c711:	xor    eax,eax
  40c713:	jmp    40c73b <__swc_fn_65555ab2_000109_aa570b2b+0x11b>
  40c715:	mov    QWORD PTR [r15+0x8],r12
  40c719:	mov    rcx,r13
  40c71c:	call   40cd70 <__swc_fn_65555ab2_000133_c6de0049>
  40c721:	mov    rax,QWORD PTR [r13+0x8]
  40c725:	mov    QWORD PTR [r15],rax
  40c728:	mov    QWORD PTR [r13+0x8],r15
  40c72c:	mov    rcx,r13
  40c72f:	call   410500 <__swc_fn_65555ab2_000134_5696c87e>
  40c734:	lea    rax,[r15+0x1000]
  40c73b:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c741:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c747:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c74d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c753:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c759:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c762:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c76b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c774:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c77d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c786:	add    rsp,0xd8
  40c78d:	pop    r15
  40c78f:	pop    rsi
  40c790:	pop    rdi
  40c791:	pop    r14
  40c793:	pop    r13
  40c795:	pop    r12
  40c797:	ret
	...

000000000040c7a0 <__swc_fn_65555ab2_000112_cb2656be>:
  40c7a0:	push   rbx
  40c7a1:	push   r12
  40c7a3:	push   rdi
  40c7a4:	push   rsi
  40c7a5:	sub    rsp,0xa8
  40c7ac:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c7b2:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c7b8:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c7be:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c7c4:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c7ca:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c7d0:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40c7d6:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40c7dc:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40c7e5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40c7ee:	mov    rbx,rdx
  40c7f1:	mov    r12,rcx
  40c7f4:	mov    rdi,rcx
  40c7f7:	mov    rsi,rdx
  40c7fa:	xor    edx,edx
  40c7fc:	xor    eax,eax
  40c7fe:	call   407030 <mprotect@plt>
  40c803:	test   eax,eax
  40c805:	jne    40c829 <__swc_fn_65555ab2_000112_cb2656be+0x89>
  40c807:	mov    rcx,r12
  40c80a:	mov    rdx,rbx
  40c80d:	xor    al,al
  40c80f:	mov    r8,rax
  40c812:	call   40ffa0 <__swc_fn_65555ab2_000110_e606239a>
  40c817:	mov    rdi,r12
  40c81a:	mov    rsi,rbx
  40c81d:	mov    edx,0x4
  40c822:	xor    eax,eax
  40c824:	call   4070f0 <madvise@plt>
  40c829:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40c82f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40c835:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40c83b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40c841:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40c847:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40c84d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40c853:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40c859:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40c862:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40c86b:	add    rsp,0xa8
  40c872:	pop    rsi
  40c873:	pop    rdi
  40c874:	pop    r12
  40c876:	pop    rbx
  40c877:	ret
	...

000000000040c880 <__swc_fn_65555ab2_000115_259b5d5a>:
  40c880:	push   rsi
  40c881:	push   rdi
  40c882:	push   r12
  40c884:	push   r13
  40c886:	push   r14
  40c888:	sub    rsp,0xe0
  40c88f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c895:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c89b:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c8a1:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c8a7:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c8ad:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c8b6:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c8bf:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c8c8:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c8d1:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c8da:	mov    rsi,rdx
  40c8dd:	mov    rdi,rcx
  40c8e0:	call   409100 <__swc_fn_65555ab2_000108_32416b9e>
  40c8e5:	mov    r12,rax
  40c8e8:	test   rax,rax
  40c8eb:	jne    40c8f2 <__swc_fn_65555ab2_000115_259b5d5a+0x72>
  40c8ed:	jmp    40c966 <__swc_fn_65555ab2_000115_259b5d5a+0xe6>
  40c8f2:	mov    rcx,r12
  40c8f5:	call   40cd70 <__swc_fn_65555ab2_000133_c6de0049>
  40c8fa:	lea    r13,[r12+0x8]
  40c8ff:	mov    rax,QWORD PTR [r13+0x0]
  40c903:	test   rax,rax
  40c906:	je     40c95e <__swc_fn_65555ab2_000115_259b5d5a+0xde>
  40c908:	nop    DWORD PTR [rax+rax*1+0x0]
  40c910:	lea    rcx,[rax+0x1000]
  40c917:	cmp    rcx,rdi
  40c91a:	jne    40c952 <__swc_fn_65555ab2_000115_259b5d5a+0xd2>
  40c91c:	cmp    QWORD PTR [rax+0x8],rsi
  40c920:	je     40c92c <__swc_fn_65555ab2_000115_259b5d5a+0xac>
  40c922:	mov    rcx,r12
  40c925:	call   410500 <__swc_fn_65555ab2_000134_5696c87e>
  40c92a:	jmp    40c966 <__swc_fn_65555ab2_000115_259b5d5a+0xe6>
  40c92c:	mov    r14,QWORD PTR [rax]
  40c92f:	mov    rdi,rax
  40c932:	lea    rsi,[rsi+0x1000]
  40c939:	xor    eax,eax
  40c93b:	call   407020 <munmap@plt>
  40c940:	test   eax,eax
  40c942:	jne    40c948 <__swc_fn_65555ab2_000115_259b5d5a+0xc8>
  40c944:	mov    QWORD PTR [r13+0x0],r14
  40c948:	mov    rcx,r12
  40c94b:	call   410500 <__swc_fn_65555ab2_000134_5696c87e>
  40c950:	jmp    40c966 <__swc_fn_65555ab2_000115_259b5d5a+0xe6>
  40c952:	mov    r13,rax
  40c955:	mov    rax,QWORD PTR [r13+0x0]
  40c959:	test   rax,rax
  40c95c:	jne    40c910 <__swc_fn_65555ab2_000115_259b5d5a+0x90>
  40c95e:	mov    rcx,r12
  40c961:	call   410500 <__swc_fn_65555ab2_000134_5696c87e>
  40c966:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c96c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c972:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c978:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c97e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c984:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c98d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c996:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c99f:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c9a8:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c9b1:	add    rsp,0xe0
  40c9b8:	pop    r14
  40c9ba:	pop    r13
  40c9bc:	pop    r12
  40c9be:	pop    rdi
  40c9bf:	pop    rsi
  40c9c0:	ret
	...

000000000040c9d0 <__swc_fn_65555ab2_000118_2b35b5e0>:
  40c9d0:	push   rdi
  40c9d1:	push   rsi
  40c9d2:	sub    rsp,0xa8
  40c9d9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c9df:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c9e5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c9eb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c9f1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c9f7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c9fd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ca03:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ca09:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ca12:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ca1b:	mov    rdi,0xfffffffffffffd66
  40ca22:	xor    eax,eax
  40ca24:	call   407040 <exit@plt>
  40ca29:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ca2f:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40ca35:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40ca3b:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ca41:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ca47:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ca4d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ca53:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ca59:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ca62:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ca6b:	add    rsp,0xa8
  40ca72:	pop    rsi
  40ca73:	pop    rdi
  40ca74:	ret
	...

000000000040ca80 <__swc_fn_65555ab2_000121_71a5b1cd>:
  40ca80:	push   rbx
  40ca81:	push   rsi
  40ca82:	push   rdi
  40ca83:	sub    rsp,0x30
  40ca87:	mov    rbx,rdx
  40ca8a:	mov    esi,ecx
  40ca8c:	test   ecx,ecx
  40ca8e:	je     40cb63 <__swc_fn_65555ab2_000121_71a5b1cd+0xe3>
  40ca94:	mov    rcx,rsi
  40ca97:	shl    rcx,0x4
  40ca9b:	call   40bf90 <__swc_fn_65555ab2_000079_29fad089>
  40caa0:	test   rax,rax
  40caa3:	je     40cb52 <__swc_fn_65555ab2_000121_71a5b1cd+0xd2>
  40caa9:	mov    rcx,rsi
  40caac:	xor    edx,edx
  40caae:	test   rsi,rsi
  40cab1:	jbe    40cb32 <__swc_fn_65555ab2_000121_71a5b1cd+0xb2>
  40cab7:	nop    WORD PTR [rax+rax*1+0x0]
  40cac0:	mov    r8d,edx
  40cac3:	mov    r9,QWORD PTR [rbx+r8*8]
  40cac7:	add    r8,r8
  40caca:	lea    r8,[rax+r8*8]
  40cace:	xor    r10d,r10d
  40cad1:	test   r9,r9
  40cad4:	je     40cb10 <__swc_fn_65555ab2_000121_71a5b1cd+0x90>
  40cad6:	mov    r11,r9
  40cad9:	mov    dil,BYTE PTR [r11]
  40cadc:	test   dil,dil
  40cadf:	je     40cb10 <__swc_fn_65555ab2_000121_71a5b1cd+0x90>
  40cae1:	cs nop WORD PTR [rax+rax*1+0x0]
  40caeb:	cs nop WORD PTR [rax+rax*1+0x0]
  40caf5:	cs nop WORD PTR [rax+rax*1+0x0]
  40caff:	nop
  40cb00:	add    r11,0x1
  40cb04:	add    r10,0x1
  40cb08:	mov    dil,BYTE PTR [r11]
  40cb0b:	test   dil,dil
  40cb0e:	jne    40cb00 <__swc_fn_65555ab2_000121_71a5b1cd+0x80>
  40cb10:	mov    QWORD PTR [rsp+0x18],r9
  40cb15:	mov    QWORD PTR [rsp+0x20],r10
  40cb1a:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40cb20:	vmovups XMMWORD PTR [r8],xmm0
  40cb25:	add    rdx,0x1
  40cb29:	cmp    rdx,rcx
  40cb2c:	jb     40cac0 <__swc_fn_65555ab2_000121_71a5b1cd+0x40>
  40cb32:	lea    rcx,[rip+0x1a217]        # 426d50 <__swc_bss_base_65555ab2+0x2d10>
  40cb39:	mov    QWORD PTR [rsp+0x8],rax
  40cb3e:	mov    esi,esi
  40cb40:	mov    QWORD PTR [rsp+0x10],rsi
  40cb45:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40cb4b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40cb50:	jmp    40cb63 <__swc_fn_65555ab2_000121_71a5b1cd+0xe3>
  40cb52:	lea    rcx,[rip+0x69c7]        # 413520 <__swc_rdata_base_65555ab2+0x410>
  40cb59:	call   410050 <__swc_fn_65555ab2_000116_3499f7d6>
  40cb5e:	call   40c9d0 <__swc_fn_65555ab2_000118_2b35b5e0>
  40cb63:	add    rsp,0x30
  40cb67:	pop    rdi
  40cb68:	pop    rsi
  40cb69:	pop    rbx
  40cb6a:	ret
  40cb6b:	add    BYTE PTR [rax],al
  40cb6d:	add    BYTE PTR [rax],al
	...

000000000040cb70 <__swc_fn_65555ab2_000124_df97aa0a>:
  40cb70:	push   rdi
  40cb71:	push   rsi
  40cb72:	sub    rsp,0xa8
  40cb79:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cb7f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cb85:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cb8b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cb91:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cb97:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cb9d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cba3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cba9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cbb2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cbbb:	mov    edi,ecx
  40cbbd:	xor    eax,eax
  40cbbf:	call   407100 <pthread_key_delete@plt>
  40cbc4:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cbca:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cbd0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cbd6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cbdc:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cbe2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cbe8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cbee:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cbf4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cbfd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cc06:	add    rsp,0xa8
  40cc0d:	pop    rsi
  40cc0e:	pop    rdi
  40cc0f:	ret

000000000040cc10 <__swc_fn_65555ab2_000127_75f8ab5c>:
  40cc10:	push   rdi
  40cc11:	push   rsi
  40cc12:	sub    rsp,0xa8
  40cc19:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cc1f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cc25:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cc2b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cc31:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cc37:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cc3d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cc43:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cc49:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cc52:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cc5b:	test   rcx,rcx
  40cc5e:	je     40cc6f <__swc_fn_65555ab2_000127_75f8ab5c+0x5f>
  40cc60:	lea    rax,[rcx-0x1]
  40cc64:	mov    eax,eax
  40cc66:	mov    edi,eax
  40cc68:	xor    eax,eax
  40cc6a:	call   407100 <pthread_key_delete@plt>
  40cc6f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cc75:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cc7b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cc81:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cc87:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cc8d:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cc93:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cc99:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cc9f:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cca8:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ccb1:	add    rsp,0xa8
  40ccb8:	pop    rsi
  40ccb9:	pop    rdi
  40ccba:	ret
  40ccbb:	add    BYTE PTR [rax],al
  40ccbd:	add    BYTE PTR [rax],al
	...

000000000040ccc0 <__swc_fn_65555ab2_000130_d2d78689>:
  40ccc0:	push   rsi
  40ccc1:	push   rdi
  40ccc2:	sub    rsp,0xa8
  40ccc9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cccf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ccd5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ccdb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cce1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cce7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cced:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ccf3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ccf9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cd02:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cd0b:	xor    eax,eax
  40cd0d:	call   407110 <gettid@plt>
  40cd12:	movsxd rax,eax
  40cd15:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cd1b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cd21:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cd27:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cd2d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cd33:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cd39:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cd3f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cd45:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cd4e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cd57:	add    rsp,0xa8
  40cd5e:	pop    rdi
  40cd5f:	pop    rsi
  40cd60:	ret
	...

000000000040cd70 <__swc_fn_65555ab2_000133_c6de0049>:
  40cd70:	push   rbx
  40cd71:	push   rdi
  40cd72:	push   rsi
  40cd73:	sub    rsp,0xc0
  40cd7a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40cd80:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40cd86:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40cd8c:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40cd92:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40cd98:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40cd9e:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40cda4:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40cdad:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40cdb6:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40cdbf:	mov    rbx,rcx
  40cdc2:	cs nop WORD PTR [rax+rax*1+0x0]
  40cdcc:	nop    DWORD PTR [rax+0x0]
  40cdd0:	mov    edx,0x80000000
  40cdd5:	xor    eax,eax
  40cdd7:	lock cmpxchg DWORD PTR [rbx],edx
  40cddb:	test   eax,eax
  40cddd:	je     40ce14 <__swc_fn_65555ab2_000133_c6de0049+0xa4>
  40cddf:	mov    eax,DWORD PTR [rbx]
  40cde1:	lea    rcx,[rsp+0x14]
  40cde6:	mov    DWORD PTR [rsp+0x14],eax
  40cdea:	test   eax,eax
  40cdec:	je     40cdd0 <__swc_fn_65555ab2_000133_c6de0049+0x60>
  40cdee:	mov    QWORD PTR [rsp],0x0
  40cdf6:	mov    edi,0xca
  40cdfb:	mov    rsi,rbx
  40cdfe:	mov    edx,0x80
  40ce03:	mov    ecx,DWORD PTR [rcx]
  40ce05:	xor    r8d,r8d
  40ce08:	xor    r9d,r9d
  40ce0b:	xor    eax,eax
  40ce0d:	call   407070 <syscall@plt>
  40ce12:	jmp    40cdd0 <__swc_fn_65555ab2_000133_c6de0049+0x60>
  40ce14:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ce1a:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40ce20:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40ce26:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ce2c:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ce32:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ce38:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ce3e:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ce47:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ce50:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ce59:	add    rsp,0xc0
  40ce60:	pop    rsi
  40ce61:	pop    rdi
  40ce62:	pop    rbx
  40ce63:	ret
	...

000000000040ce70 <__swc_fn_65555ab2_000136_5589b4a1>:
  40ce70:	sub    rsp,0x8
  40ce74:	call   410500 <__swc_fn_65555ab2_000134_5696c87e>
  40ce79:	add    rsp,0x8
  40ce7d:	ret
	...

000000000040ce80 <__swc_fn_65555ab2_000139_20e2e2c7>:
  40ce80:	push   rdi
  40ce81:	push   rsi
  40ce82:	sub    rsp,0xa8
  40ce89:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ce8f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ce95:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ce9b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cea1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cea7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cead:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ceb3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ceb9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cec2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cecb:	mov    edi,0x28
  40ced0:	xor    eax,eax
  40ced2:	call   4070d0 <malloc@plt>
  40ced7:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cedd:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cee3:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cee9:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ceef:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cef5:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cefb:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cf01:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cf07:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cf10:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cf19:	add    rsp,0xa8
  40cf20:	pop    rsi
  40cf21:	pop    rdi
  40cf22:	ret
	...

000000000040cf30 <__swc_fn_65555ab2_000142_e0543f36>:
  40cf30:	mov    QWORD PTR [r8],0x0
  40cf37:	cmp    rdx,0x10
  40cf3b:	jae    40cf40 <__swc_fn_65555ab2_000142_e0543f36+0x10>
  40cf3d:	xor    eax,eax
  40cf3f:	ret
  40cf40:	mov    eax,DWORD PTR [rcx]
  40cf42:	cmp    eax,0x42445753
  40cf48:	jne    40cf52 <__swc_fn_65555ab2_000142_e0543f36+0x22>
  40cf4a:	mov    eax,DWORD PTR [rcx+0x4]
  40cf4d:	cmp    eax,0x1
  40cf50:	je     40cf55 <__swc_fn_65555ab2_000142_e0543f36+0x25>
  40cf52:	xor    eax,eax
  40cf54:	ret
  40cf55:	mov    QWORD PTR [r8],rdx
  40cf58:	mov    rax,rcx
  40cf5b:	ret
  40cf5c:	add    BYTE PTR [rax],al
	...

000000000040cf60 <__swc_fn_65555ab2_000145_071b4f4c>:
  40cf60:	push   rbx
  40cf61:	sub    rsp,0xe0
  40cf68:	lea    rbx,[rsp+0x8]
  40cf6d:	vxorps xmm0,xmm0,xmm0
  40cf71:	vmovups YMMWORD PTR [rbx],ymm0
  40cf75:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40cf7a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40cf7f:	vzeroupper
  40cf82:	mov    DWORD PTR [rbx+0x60],0x0
  40cf89:	mov    r8,rbx
  40cf8c:	mov    rdx,rcx
  40cf8f:	nop
  40cf90:	mov    r9,rdx
  40cf93:	movabs rdx,0x6666666666666667
  40cf9d:	mov    rax,r9
  40cfa0:	imul   rdx
  40cfa3:	sar    rdx,0x2
  40cfa7:	mov    r10,rdx
  40cfaa:	shr    rdx,0x3f
  40cfae:	add    r10,rdx
  40cfb1:	mov    rdx,r10
  40cfb4:	imul   r11,r10,0xa
  40cfb8:	sub    r9,r11
  40cfbb:	mov    r11,QWORD PTR [rip+0x657e]        # 413540 <__swc_rdata_base_65555ab2+0x430>
  40cfc2:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40cfc7:	mov    BYTE PTR [r8],r9b
  40cfca:	lea    r9,[r8+0x1]
  40cfce:	mov    r8,r9
  40cfd1:	test   r10,r10
  40cfd4:	jne    40cf90 <__swc_fn_65555ab2_000145_071b4f4c+0x30>
  40cfd6:	test   rcx,rcx
  40cfd9:	jge    40cfe3 <__swc_fn_65555ab2_000145_071b4f4c+0x83>
  40cfdb:	mov    BYTE PTR [r9],0x2d
  40cfdf:	add    r8,0x1
  40cfe3:	mov    BYTE PTR [r8],0x0
  40cfe7:	sub    r8,0x1
  40cfeb:	mov    rax,rbx
  40cfee:	cmp    rax,r8
  40cff1:	jae    40d016 <__swc_fn_65555ab2_000145_071b4f4c+0xb6>
  40cff3:	cs nop WORD PTR [rax+rax*1+0x0]
  40cffd:	nop    DWORD PTR [rax]
  40d000:	mov    cl,BYTE PTR [r8]
  40d003:	mov    dl,BYTE PTR [rax]
  40d005:	mov    BYTE PTR [r8],dl
  40d008:	sub    r8,0x1
  40d00c:	mov    BYTE PTR [rax],cl
  40d00e:	inc    rax
  40d011:	cmp    rax,r8
  40d014:	jb     40d000 <__swc_fn_65555ab2_000145_071b4f4c+0xa0>
  40d016:	xor    eax,eax
  40d018:	test   rbx,rbx
  40d01b:	je     40d03e <__swc_fn_65555ab2_000145_071b4f4c+0xde>
  40d01d:	mov    rcx,rbx
  40d020:	mov    dl,BYTE PTR [rcx]
  40d022:	test   dl,dl
  40d024:	je     40d03e <__swc_fn_65555ab2_000145_071b4f4c+0xde>
  40d026:	cs nop WORD PTR [rax+rax*1+0x0]
  40d030:	add    rcx,0x1
  40d034:	add    rax,0x1
  40d038:	mov    dl,BYTE PTR [rcx]
  40d03a:	test   dl,dl
  40d03c:	jne    40d030 <__swc_fn_65555ab2_000145_071b4f4c+0xd0>
  40d03e:	mov    QWORD PTR [rbx+0xa8],rbx
  40d045:	mov    QWORD PTR [rbx+0xb0],rax
  40d04c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d054:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d05c:	lea    rcx,[rbx+0xb8]
  40d063:	call   410050 <__swc_fn_65555ab2_000116_3499f7d6>
  40d068:	add    rsp,0xe0
  40d06f:	pop    rbx
  40d070:	ret
	...

000000000040d080 <__swc_fn_65555ab2_000148_33e5e24f>:
  40d080:	vxorps xmm0,xmm0,xmm0
  40d084:	vmovups XMMWORD PTR [rcx],xmm0
  40d088:	mov    QWORD PTR [rcx+0x10],0x0
  40d090:	ret
	...

000000000040d0a0 <__swc_fn_65555ab2_000151_33e5e24f>:
  40d0a0:	vxorps xmm0,xmm0,xmm0
  40d0a4:	vmovups XMMWORD PTR [rcx],xmm0
  40d0a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d0ad:	vxorps xmm0,xmm0,xmm0
  40d0b1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d0b6:	vmovups xmm0,XMMWORD PTR [rip+0x657a]        # 413638 <__swc_rdata_base_65555ab2+0x528>
  40d0be:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d0c3:	vxorps xmm0,xmm0,xmm0
  40d0c7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d0cc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d0d1:	mov    QWORD PTR [rcx+0x60],0x0
  40d0d9:	ret
  40d0da:	add    BYTE PTR [rax],al
  40d0dc:	add    BYTE PTR [rax],al
	...

000000000040d0e0 <__swc_fn_65555ab2_000154_33e5e24f>:
  40d0e0:	vxorps xmm0,xmm0,xmm0
  40d0e4:	vmovups XMMWORD PTR [rcx],xmm0
  40d0e8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d0ed:	vxorps xmm0,xmm0,xmm0
  40d0f1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d0f6:	vmovups xmm0,XMMWORD PTR [rip+0x6662]        # 413760 <__swc_rdata_base_65555ab2+0x650>
  40d0fe:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d103:	vxorps xmm0,xmm0,xmm0
  40d107:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d10c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d111:	vxorps xmm0,xmm0,xmm0
  40d115:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40d11a:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40d11f:	vxorps xmm0,xmm0,xmm0
  40d123:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40d12b:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40d133:	vxorps xmm0,xmm0,xmm0
  40d137:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40d13f:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40d147:	vxorps xmm0,xmm0,xmm0
  40d14b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40d153:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40d15b:	mov    QWORD PTR [rcx+0xe0],0x0
  40d166:	ret
	...

000000000040d170 <__swc_fn_65555ab2_000157_5c8b11d8>:
  40d170:	push   rbx
  40d171:	mov    rbx,rcx
  40d174:	call   411a90 <__swc_fn_65555ab2_000158_6741c23b>
  40d179:	mov    rax,QWORD PTR [rbx+0x10]
  40d17d:	test   rax,rax
  40d180:	je     40d191 <__swc_fn_65555ab2_000157_5c8b11d8+0x21>
  40d182:	mov    rcx,rbx
  40d185:	mov    rdx,rax
  40d188:	mov    r8,QWORD PTR [rbx+0x18]
  40d18c:	call   409e90 <__swc_fn_65555ab2_000156_312df05a>
  40d191:	vxorps xmm0,xmm0,xmm0
  40d195:	vmovups XMMWORD PTR [rbx],xmm0
  40d199:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d19e:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d1a3:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d1a8:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d1ad:	mov    QWORD PTR [rbx+0x50],0x0
  40d1b5:	pop    rbx
  40d1b6:	ret
	...

000000000040d1c0 <__swc_fn_65555ab2_000160_e25d06b9>:
  40d1c0:	sub    rsp,0x10
  40d1c4:	mov    eax,r8d
  40d1c7:	mov    r8d,r9d
  40d1ca:	test   r9d,r9d
  40d1cd:	jne    40d1e6 <__swc_fn_65555ab2_000160_e25d06b9+0x26>
  40d1cf:	vmovups xmm0,XMMWORD PTR [rip+0x6641]        # 413818 <__swc_rdata_base_65555ab2+0x708>
  40d1d7:	vmovups XMMWORD PTR [r10],xmm0
  40d1dc:	mov    eax,0x1
  40d1e1:	add    rsp,0x10
  40d1e5:	ret
  40d1e6:	mov    r9,r8
  40d1e9:	cmp    r8,rax
  40d1ec:	jb     40d1f3 <__swc_fn_65555ab2_000160_e25d06b9+0x33>
  40d1ee:	cmp    r9,rdx
  40d1f1:	jb     40d1fa <__swc_fn_65555ab2_000160_e25d06b9+0x3a>
  40d1f3:	xor    eax,eax
  40d1f5:	add    rsp,0x10
  40d1f9:	ret
  40d1fa:	xor    eax,eax
  40d1fc:	lea    r8,[r9+rax*1]
  40d200:	cmp    r8,rdx
  40d203:	jae    40d233 <__swc_fn_65555ab2_000160_e25d06b9+0x73>
  40d205:	cs nop WORD PTR [rax+rax*1+0x0]
  40d20f:	cs nop WORD PTR [rax+rax*1+0x0]
  40d219:	nop    DWORD PTR [rax+0x0]
  40d220:	cmp    BYTE PTR [rcx+r8*1],0x0
  40d225:	je     40d233 <__swc_fn_65555ab2_000160_e25d06b9+0x73>
  40d227:	inc    rax
  40d22a:	lea    r8,[r9+rax*1]
  40d22e:	cmp    r8,rdx
  40d231:	jb     40d220 <__swc_fn_65555ab2_000160_e25d06b9+0x60>
  40d233:	cmp    r8,rdx
  40d236:	jne    40d23f <__swc_fn_65555ab2_000160_e25d06b9+0x7f>
  40d238:	xor    eax,eax
  40d23a:	add    rsp,0x10
  40d23e:	ret
  40d23f:	add    rcx,r9
  40d242:	mov    QWORD PTR [rsp],rcx
  40d246:	mov    QWORD PTR [rsp+0x8],rax
  40d24b:	vmovups xmm0,XMMWORD PTR [rsp]
  40d250:	vmovups XMMWORD PTR [r10],xmm0
  40d255:	mov    eax,0x1
  40d25a:	add    rsp,0x10
  40d25e:	ret
	...

000000000040d260 <__swc_fn_65555ab2_000163_5fbed98a>:
  40d260:	push   rbp
  40d261:	push   rbx
  40d262:	push   rsi
  40d263:	push   rdi
  40d264:	push   r12
  40d266:	push   r13
  40d268:	push   r14
  40d26a:	push   r15
  40d26c:	sub    rsp,0x10
  40d270:	mov    rbp,rsp
  40d273:	vmovups XMMWORD PTR [rsp],xmm6
  40d278:	sub    rsp,0x50
  40d27c:	mov    rbx,rsp
  40d27f:	mov    rsi,r8
  40d282:	mov    QWORD PTR [rsp+0x30],r8
  40d287:	mov    rdi,rcx
  40d28a:	mov    QWORD PTR [rsp+0x38],rcx
  40d28f:	mov    r12,rdx
  40d292:	xor    r13b,r13b
  40d295:	mov    r14,QWORD PTR [rdi+0x8]
  40d299:	mov    QWORD PTR [rsp+0x40],r14
  40d29e:	xor    r15d,r15d
  40d2a1:	test   r14,r14
  40d2a4:	jbe    40d4fe <__swc_fn_65555ab2_000163_5fbed98a+0x29e>
  40d2aa:	mov    r14,QWORD PTR [rdi]
  40d2ad:	mov    rax,QWORD PTR [rsp+0x40]
  40d2b2:	mov    QWORD PTR [rsp+0x48],r14
  40d2b7:	vmovups xmm6,XMMWORD PTR [rip+0x6179]        # 413438 <__swc_rdata_base_65555ab2+0x328>
  40d2bf:	nop
  40d2c0:	cmp    QWORD PTR [r14+r15*8],0x0
  40d2c5:	jne    40d2cf <__swc_fn_65555ab2_000163_5fbed98a+0x6f>
  40d2c7:	mov    r14,rax
  40d2ca:	jmp    40d4de <__swc_fn_65555ab2_000163_5fbed98a+0x27e>
  40d2cf:	mov    rcx,QWORD PTR [rdi]
  40d2d2:	mov    rdx,QWORD PTR [rcx+r15*8]
  40d2d6:	mov    rdi,rbx
  40d2d9:	mov    rcx,rdi
  40d2dc:	sub    rsp,0x8
  40d2e0:	mov    r14,rax
  40d2e3:	call   409f10 <__swc_fn_65555ab2_000162_edb9cf73>
  40d2e8:	add    rsp,0x8
  40d2ec:	mov    al,BYTE PTR [rbx]
  40d2ee:	test   al,al
  40d2f0:	je     40d4de <__swc_fn_65555ab2_000163_5fbed98a+0x27e>
  40d2f6:	mov    al,BYTE PTR [rbx+0x1]
  40d2f9:	test   al,al
  40d2fb:	jne    40d306 <__swc_fn_65555ab2_000163_5fbed98a+0xa6>
  40d2fd:	test   sil,sil
  40d300:	je     40d4de <__swc_fn_65555ab2_000163_5fbed98a+0x27e>
  40d306:	test   r13b,r13b
  40d309:	jne    40d3c7 <__swc_fn_65555ab2_000163_5fbed98a+0x167>
  40d30f:	test   r12,r12
  40d312:	je     40d3c7 <__swc_fn_65555ab2_000163_5fbed98a+0x167>
  40d318:	mov    al,BYTE PTR [rbx+0x1]
  40d31b:	test   al,al
  40d31d:	je     40d4de <__swc_fn_65555ab2_000163_5fbed98a+0x27e>
  40d323:	mov    eax,DWORD PTR [rbx+0x28]
  40d326:	cmp    DWORD PTR [r12+0x20],eax
  40d32b:	jne    40d4de <__swc_fn_65555ab2_000163_5fbed98a+0x27e>
  40d331:	mov    rax,QWORD PTR [r12]
  40d335:	mov    rcx,QWORD PTR [r12+0x8]
  40d33a:	cmp    QWORD PTR [rbx+0x20],rcx
  40d33e:	jne    40d4de <__swc_fn_65555ab2_000163_5fbed98a+0x27e>
  40d344:	mov    cl,0x1
  40d346:	test   rax,rax
  40d349:	je     40d3b2 <__swc_fn_65555ab2_000163_5fbed98a+0x152>
  40d34f:	mov    rdx,QWORD PTR [rbx+0x20]
  40d353:	xor    r8d,r8d
  40d356:	test   rdx,rdx
  40d359:	jbe    40d3b2 <__swc_fn_65555ab2_000163_5fbed98a+0x152>
  40d35b:	mov    r9,QWORD PTR [rbx+0x18]
  40d35f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40d364:	cs nop WORD PTR [rax+rax*1+0x0]
  40d36e:	xchg   ax,ax
  40d370:	mov    r10b,BYTE PTR [rax+r8*1]
  40d374:	cmp    BYTE PTR [r9+r8*1],r10b
  40d378:	je     40d3a9 <__swc_fn_65555ab2_000163_5fbed98a+0x149>
  40d37a:	vmovq  r10,xmm0
  40d37f:	cmp    BYTE PTR [r10+r8*1],0x5c
  40d384:	jne    40d38d <__swc_fn_65555ab2_000163_5fbed98a+0x12d>
  40d386:	cmp    BYTE PTR [rax+r8*1],0x2f
  40d38b:	je     40d3a9 <__swc_fn_65555ab2_000163_5fbed98a+0x149>
  40d38d:	vmovq  r10,xmm0
  40d392:	cmp    BYTE PTR [r10+r8*1],0x2f
  40d397:	jne    40d3a0 <__swc_fn_65555ab2_000163_5fbed98a+0x140>
  40d399:	cmp    BYTE PTR [rax+r8*1],0x5c
  40d39e:	je     40d3a9 <__swc_fn_65555ab2_000163_5fbed98a+0x149>
  40d3a0:	xor    eax,eax
  40d3a2:	movzx  eax,al
  40d3a5:	mov    cl,al
  40d3a7:	jmp    40d3b2 <__swc_fn_65555ab2_000163_5fbed98a+0x152>
  40d3a9:	add    r8,0x1
  40d3ad:	cmp    r8,rdx
  40d3b0:	jb     40d370 <__swc_fn_65555ab2_000163_5fbed98a+0x110>
  40d3b2:	test   cl,cl
  40d3b4:	je     40d4de <__swc_fn_65555ab2_000163_5fbed98a+0x27e>
  40d3ba:	mov    eax,0x1
  40d3bf:	mov    r13b,al
  40d3c2:	jmp    40d4de <__swc_fn_65555ab2_000163_5fbed98a+0x27e>
  40d3c7:	mov    r13b,0x1
  40d3ca:	sub    rsp,0x20
  40d3ce:	mov    rax,rsp
  40d3d1:	lea    rcx,[rdi+0x8]
  40d3d5:	mov    QWORD PTR [rax],rcx
  40d3d8:	lea    rsi,[rip+0x5f31]        # 413310 <__swc_rdata_base_65555ab2+0x200>
  40d3df:	mov    QWORD PTR [rax+0x8],rsi
  40d3e3:	mov    QWORD PTR [rax+0x10],rsp
  40d3e7:	mov    QWORD PTR [rax+0x18],0x1
  40d3ef:	lea    rcx,[rsp+0x10]
  40d3f4:	sub    rsp,0x8
  40d3f8:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  40d3fd:	add    rsp,0x8
  40d401:	add    rsp,0x20
  40d405:	mov    al,BYTE PTR [rbx+0x1]
  40d408:	test   al,al
  40d40a:	je     40d4a7 <__swc_fn_65555ab2_000163_5fbed98a+0x247>
  40d410:	lea    rax,[rip+0x64a1]        # 4138b8 <__swc_rdata_base_65555ab2+0x7a8>
  40d417:	sub    rsp,0x20
  40d41b:	mov    rcx,rsp
  40d41e:	mov    QWORD PTR [rcx],rax
  40d421:	mov    QWORD PTR [rcx+0x8],rsi
  40d425:	mov    QWORD PTR [rcx+0x10],rsp
  40d429:	mov    QWORD PTR [rcx+0x18],0x1
  40d431:	lea    rcx,[rsp+0x10]
  40d436:	sub    rsp,0x8
  40d43a:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  40d43f:	add    rsp,0x8
  40d443:	add    rsp,0x20
  40d447:	mov    eax,DWORD PTR [rbx+0x28]
  40d44a:	sub    rsp,0x60
  40d44e:	mov    rcx,rsp
  40d451:	lea    rdx,[rdi+0x18]
  40d455:	mov    QWORD PTR [rcx+0x18],rdx
  40d459:	mov    QWORD PTR [rcx+0x20],rsi
  40d45d:	vmovups XMMWORD PTR [rcx],xmm6
  40d461:	mov    QWORD PTR [rcx+0x28],rsp
  40d465:	mov    QWORD PTR [rcx+0x30],rsi
  40d469:	mov    DWORD PTR [rcx+0x10],eax
  40d46c:	lea    rax,[rsp+0x10]
  40d471:	mov    QWORD PTR [rcx+0x38],rax
  40d475:	lea    rax,[rip+0x5f54]        # 4133d0 <__swc_rdata_base_65555ab2+0x2c0>
  40d47c:	mov    QWORD PTR [rcx+0x40],rax
  40d480:	lea    rax,[rsp+0x18]
  40d485:	mov    QWORD PTR [rcx+0x48],rax
  40d489:	mov    QWORD PTR [rcx+0x50],0x3
  40d491:	lea    rcx,[rsp+0x48]
  40d496:	sub    rsp,0x8
  40d49a:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  40d49f:	add    rsp,0x8
  40d4a3:	add    rsp,0x60
  40d4a7:	lea    rax,[rip+0x5eba]        # 413368 <__swc_rdata_base_65555ab2+0x258>
  40d4ae:	sub    rsp,0x20
  40d4b2:	mov    rcx,rsp
  40d4b5:	mov    QWORD PTR [rcx],rax
  40d4b8:	mov    QWORD PTR [rcx+0x8],rsi
  40d4bc:	mov    QWORD PTR [rcx+0x10],rsp
  40d4c0:	mov    QWORD PTR [rcx+0x18],0x1
  40d4c8:	lea    rcx,[rsp+0x10]
  40d4cd:	sub    rsp,0x8
  40d4d1:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  40d4d6:	add    rsp,0x8
  40d4da:	add    rsp,0x20
  40d4de:	add    r15,0x1
  40d4e2:	cmp    r15,r14
  40d4e5:	jae    40d4fe <__swc_fn_65555ab2_000163_5fbed98a+0x29e>
  40d4e7:	mov    rsi,QWORD PTR [rsp+0x30]
  40d4ec:	mov    rdi,QWORD PTR [rsp+0x38]
  40d4f1:	mov    rax,r14
  40d4f4:	mov    r14,QWORD PTR [rsp+0x48]
  40d4f9:	jmp    40d2c0 <__swc_fn_65555ab2_000163_5fbed98a+0x60>
  40d4fe:	add    rsp,0x50
  40d502:	vmovups xmm6,XMMWORD PTR [rsp]
  40d507:	add    rsp,0x10
  40d50b:	pop    r15
  40d50d:	pop    r14
  40d50f:	pop    r13
  40d511:	pop    r12
  40d513:	pop    rdi
  40d514:	pop    rsi
  40d515:	pop    rbx
  40d516:	pop    rbp
  40d517:	ret
	...

000000000040d520 <__swc_fn_65555ab2_000166_31ca4f53>:
  40d520:	sub    rsp,0x8
  40d524:	call   4102d0 <__swc_fn_65555ab2_000125_e19c72b3>
  40d529:	add    rsp,0x8
  40d52d:	ret
	...

000000000040d530 <__swc_fn_65555ab2_000169_aabbfb4c>:
  40d530:	push   rsi
  40d531:	sub    rsp,0x30
  40d535:	lea    rsi,[rip+0x19864]        # 426da0 <__swc_bss_base_65555ab2+0x2d60>
  40d53c:	mov    rax,QWORD PTR [rsi]
  40d53f:	test   rax,rax
  40d542:	je     40d54a <__swc_fn_65555ab2_000169_aabbfb4c+0x1a>
  40d544:	add    rsp,0x30
  40d548:	pop    rsi
  40d549:	ret
  40d54a:	mov    ecx,0x2
  40d54f:	mov    edx,0x8020
  40d554:	call   40f970 <__swc_fn_65555ab2_000107_ff529476>
  40d559:	test   rax,rax
  40d55c:	jne    40d56d <__swc_fn_65555ab2_000169_aabbfb4c+0x3d>
  40d55e:	mov    QWORD PTR [rsp+0x18],rax
  40d563:	call   40c9d0 <__swc_fn_65555ab2_000118_2b35b5e0>
  40d568:	mov    rax,QWORD PTR [rsp+0x18]
  40d56d:	mov    rcx,rax
  40d570:	xchg   QWORD PTR [rsi],rcx
  40d573:	add    rsp,0x30
  40d577:	pop    rsi
  40d578:	ret
  40d579:	add    BYTE PTR [rax],al
  40d57b:	add    BYTE PTR [rax],al
  40d57d:	add    BYTE PTR [rax],al
	...

000000000040d580 <__swc_fn_65555ab2_000172_9a88b1d5>:
  40d580:	push   rsi
  40d581:	test   r8,r8
  40d584:	jne    40d588 <__swc_fn_65555ab2_000172_9a88b1d5+0x8>
  40d586:	pop    rsi
  40d587:	ret
  40d588:	lea    rax,[rcx+0x18]
  40d58c:	mov    r10,QWORD PTR [rax]
  40d58f:	lea    r11,[r10+0x1]
  40d593:	mov    QWORD PTR [rax],r11
  40d596:	mov    r11,rdx
  40d599:	not    rdx
  40d59c:	lea    rsi,[r8-0x1]
  40d5a0:	cmp    rsi,rdx
  40d5a3:	ja     40d5c3 <__swc_fn_65555ab2_000172_9a88b1d5+0x43>
  40d5a5:	lea    rdx,[r11+r8*1]
  40d5a9:	dec    rdx
  40d5ac:	shr    rdx,0x6
  40d5b0:	mov    r8,r11
  40d5b3:	shr    r8,0x6
  40d5b7:	mov    rsi,rdx
  40d5ba:	sub    rsi,r8
  40d5bd:	cmp    rsi,0x8
  40d5c1:	jb     40d5d9 <__swc_fn_65555ab2_000172_9a88b1d5+0x59>
  40d5c3:	lea    rcx,[rcx+0x10]
  40d5c7:	mov    rdx,QWORD PTR [rcx]
  40d5ca:	add    rdx,r9
  40d5cd:	mov    QWORD PTR [rcx],rdx
  40d5d0:	lea    rcx,[r10+0x2]
  40d5d4:	mov    QWORD PTR [rax],rcx
  40d5d7:	pop    rsi
  40d5d8:	ret
  40d5d9:	shr    r11,0x6
  40d5dd:	nop    DWORD PTR [rax]
  40d5e0:	cmp    r11,rdx
  40d5e3:	ja     40d623 <__swc_fn_65555ab2_000172_9a88b1d5+0xa3>
  40d5e5:	jmp    40d5f6 <__swc_fn_65555ab2_000172_9a88b1d5+0x76>
  40d5e7:	nop    WORD PTR [rax+rax*1+0x0]
  40d5f0:	add    r11,0x1
  40d5f4:	jmp    40d5e0 <__swc_fn_65555ab2_000172_9a88b1d5+0x60>
  40d5f6:	mov    r8,r11
  40d5f9:	shr    r8,0xc
  40d5fd:	mov    rsi,r11
  40d600:	xor    rsi,r8
  40d603:	mov    r8,r11
  40d606:	shr    r8,0x18
  40d60a:	xor    rsi,r8
  40d60d:	and    esi,0xfff
  40d613:	lea    r8,[rcx+rsi*8+0x20]
  40d618:	mov    rsi,QWORD PTR [r8]
  40d61b:	add    rsi,r9
  40d61e:	mov    QWORD PTR [r8],rsi
  40d621:	jmp    40d5f0 <__swc_fn_65555ab2_000172_9a88b1d5+0x70>
  40d623:	lea    rcx,[r10+0x2]
  40d627:	mov    QWORD PTR [rax],rcx
  40d62a:	pop    rsi
  40d62b:	ret
  40d62c:	add    BYTE PTR [rax],al
	...

000000000040d630 <__swc_fn_65555ab2_000175_2744b483>:
  40d630:	push   rbx
  40d631:	sub    rsp,0x70
  40d635:	cmp    rcx,0xffffffffffffffef
  40d639:	jbe    40d643 <__swc_fn_65555ab2_000175_2744b483+0x13>
  40d63b:	xor    eax,eax
  40d63d:	add    rsp,0x70
  40d641:	pop    rbx
  40d642:	ret
  40d643:	vxorps xmm0,xmm0,xmm0
  40d647:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40d64d:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40d653:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  40d659:	vzeroupper
  40d65c:	lea    rax,[rcx+0x10]
  40d660:	mov    QWORD PTR [rsp+0x50],rax
  40d665:	mov    DWORD PTR [rsp+0x60],0x10
  40d66d:	mov    rcx,QWORD PTR [rip+0x196cc]        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  40d674:	test   rcx,rcx
  40d677:	jne    40d689 <__swc_fn_65555ab2_000175_2744b483+0x59>
  40d679:	call   40a1a0 <__swc_fn_65555ab2_000165_e09accff>
  40d67e:	lea    rcx,[rax+0x1]
  40d682:	mov    QWORD PTR [rip+0x196b7],rcx        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  40d689:	dec    rcx
  40d68c:	call   411e00 <__swc_fn_65555ab2_000167_3130645d>
  40d691:	mov    rcx,QWORD PTR [rax]
  40d694:	lea    rdx,[rsp+0x8]
  40d699:	mov    rbx,QWORD PTR [rax+0x8]
  40d69d:	mov    rbx,QWORD PTR [rbx+0x8]
  40d6a1:	call   rbx
  40d6a3:	mov    rax,QWORD PTR [rsp+0x48]
  40d6a8:	test   rax,rax
  40d6ab:	jne    40d6b5 <__swc_fn_65555ab2_000175_2744b483+0x85>
  40d6ad:	xor    eax,eax
  40d6af:	add    rsp,0x70
  40d6b3:	pop    rbx
  40d6b4:	ret
  40d6b5:	mov    rcx,QWORD PTR [rsp+0x50]
  40d6ba:	mov    QWORD PTR [rax],rcx
  40d6bd:	mov    QWORD PTR [rax+0x8],0x0
  40d6c5:	lea    rax,[rax+0x10]
  40d6c9:	add    rsp,0x70
  40d6cd:	pop    rbx
  40d6ce:	ret
	...

000000000040d6e0 <__swc_fn_65555ab2_000178_72e41d4d>:
  40d6e0:	push   rbp
  40d6e1:	push   rbx
  40d6e2:	push   rsi
  40d6e3:	push   rdi
  40d6e4:	push   r12
  40d6e6:	push   r13
  40d6e8:	push   r14
  40d6ea:	push   r15
  40d6ec:	sub    rsp,0x10
  40d6f0:	mov    rbp,rsp
  40d6f3:	vmovups XMMWORD PTR [rsp],xmm6
  40d6f8:	sub    rsp,0x430
  40d6ff:	mov    rbx,rsp
  40d702:	mov    ecx,0x800000
  40d707:	sub    rsp,0x8
  40d70b:	call   40d630 <__swc_fn_65555ab2_000175_2744b483>
  40d710:	add    rsp,0x8
  40d714:	mov    rsi,rax
  40d717:	mov    QWORD PTR [rsp+0x3c0],rax
  40d71f:	xor    ecx,ecx
  40d721:	cs nop WORD PTR [rax+rax*1+0x0]
  40d72b:	nop    DWORD PTR [rax+rax*1+0x0]
  40d730:	mov    r8,QWORD PTR [rip+0x148d9]        # 422010 <__swc_data_base_65555ab2+0x10>
  40d737:	imul   r8,r8,0x41a7
  40d73e:	movabs rdx,0x200000005
  40d748:	mov    r11,rax
  40d74b:	mov    rax,r8
  40d74e:	mul    rdx
  40d751:	mov    r9,rdx
  40d754:	mov    rdx,r8
  40d757:	sub    rdx,r9
  40d75a:	shr    rdx,1
  40d75d:	add    rdx,r9
  40d760:	shr    rdx,0x1e
  40d764:	imul   r9,rdx,0x7fffffff
  40d76b:	sub    r8,r9
  40d76e:	mov    QWORD PTR [rip+0x1489b],r8        # 422010 <__swc_data_base_65555ab2+0x10>
  40d775:	mov    BYTE PTR [rsi+rcx*1],r8b
  40d779:	add    rcx,0x1
  40d77d:	mov    r8,QWORD PTR [rip+0x1488c]        # 422010 <__swc_data_base_65555ab2+0x10>
  40d784:	imul   r8,r8,0x41a7
  40d78b:	movabs rdx,0x200000005
  40d795:	mov    rax,r8
  40d798:	mul    rdx
  40d79b:	mov    r9,rdx
  40d79e:	mov    rax,r11
  40d7a1:	mov    rdx,r8
  40d7a4:	sub    rdx,r9
  40d7a7:	shr    rdx,1
  40d7aa:	add    rdx,r9
  40d7ad:	shr    rdx,0x1e
  40d7b1:	imul   rdx,rdx,0x7fffffff
  40d7b8:	sub    r8,rdx
  40d7bb:	mov    QWORD PTR [rip+0x1484e],r8        # 422010 <__swc_data_base_65555ab2+0x10>
  40d7c2:	mov    BYTE PTR [rsi+rcx*1],r8b
  40d7c6:	add    rcx,0x1
  40d7ca:	cmp    rcx,0x800000
  40d7d1:	jb     40d730 <__swc_fn_65555ab2_000178_72e41d4d+0x50>
  40d7d7:	sub    rsp,0x8
  40d7db:	call   40a350 <__swc_fn_65555ab2_000177_1ca87929>
  40d7e0:	add    rsp,0x8
  40d7e4:	vmovups xmm6,xmm0
  40d7e8:	mov    ecx,0x800080
  40d7ed:	sub    rsp,0x8
  40d7f1:	call   40d630 <__swc_fn_65555ab2_000175_2744b483>
  40d7f6:	add    rsp,0x8
  40d7fa:	mov    rdi,rax
  40d7fd:	mov    QWORD PTR [rsp+0x3c8],rax
  40d805:	xor    eax,eax
  40d807:	cs nop WORD PTR [rax+rax*1+0x0]
  40d811:	cs nop WORD PTR [rax+rax*1+0x0]
  40d81b:	nop    DWORD PTR [rax+rax*1+0x0]
  40d820:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*1]
  40d825:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40d82a:	add    rax,0x10
  40d82e:	cmp    rax,0x800000
  40d835:	jne    40d820 <__swc_fn_65555ab2_000178_72e41d4d+0x140>
  40d837:	rex mov BYTE PTR [rdi+0x800000],0x80
  40d83f:	mov    eax,0x800001
  40d844:	cs nop WORD PTR [rax+rax*1+0x0]
  40d84e:	xchg   ax,ax
  40d850:	mov    ecx,eax
  40d852:	and    ecx,0x3f
  40d855:	cmp    rcx,0x38
  40d859:	je     40d864 <__swc_fn_65555ab2_000178_72e41d4d+0x184>
  40d85b:	mov    BYTE PTR [rdi+rax*1],0x0
  40d85f:	inc    rax
  40d862:	jmp    40d850 <__swc_fn_65555ab2_000178_72e41d4d+0x170>
  40d864:	mov    BYTE PTR [rdi+rax*1],0x0
  40d868:	mov    BYTE PTR [rdi+rax*1+0x1],0x0
  40d86d:	mov    BYTE PTR [rdi+rax*1+0x2],0x0
  40d872:	mov    BYTE PTR [rdi+rax*1+0x3],0x0
  40d877:	mov    BYTE PTR [rdi+rax*1+0x4],0x4
  40d87c:	mov    BYTE PTR [rdi+rax*1+0x5],0x0
  40d881:	mov    BYTE PTR [rdi+rax*1+0x6],0x0
  40d886:	mov    BYTE PTR [rdi+rax*1+0x7],0x0
  40d88b:	lea    rax,[rax+0x8]
  40d88f:	mov    ecx,0x6a09e667
  40d894:	mov    edx,0xbb67ae85
  40d899:	mov    r8d,0x3c6ef372
  40d89f:	mov    r9d,0xa54ff53a
  40d8a5:	mov    r10d,0x510e527f
  40d8ab:	mov    r11d,0x9b05688c
  40d8b1:	mov    r12d,0x1f83d9ab
  40d8b7:	mov    r13d,0x5be0cd19
  40d8bd:	mov    QWORD PTR [rsp+0x408],r13
  40d8c5:	lea    r14,[rbx+0x90]
  40d8cc:	vxorps xmm0,xmm0,xmm0
  40d8d0:	xor    r15d,r15d
  40d8d3:	cs nop WORD PTR [rax+rax*1+0x0]
  40d8dd:	nop    DWORD PTR [rax]
  40d8e0:	vmovdqu XMMWORD PTR [r14+r15*1],xmm0
  40d8e6:	add    r15,0x10
  40d8ea:	cmp    r15,0x200
  40d8f1:	jne    40d8e0 <__swc_fn_65555ab2_000178_72e41d4d+0x200>
  40d8f3:	shr    rax,0x6
  40d8f7:	mov    QWORD PTR [rsp+0x410],rax
  40d8ff:	xor    r15d,r15d
  40d902:	test   rax,rax
  40d905:	ja     40d923 <__swc_fn_65555ab2_000178_72e41d4d+0x243>
  40d907:	mov    rax,rcx
  40d90a:	mov    rcx,rdx
  40d90d:	mov    rsi,r10
  40d910:	mov    rdi,r11
  40d913:	mov    rdx,QWORD PTR [rsp+0x408]
  40d91b:	mov    r10,r9
  40d91e:	jmp    40dc7c <__swc_fn_65555ab2_000178_72e41d4d+0x59c>
  40d923:	vmovsd xmm2,QWORD PTR [rsp+0x408]
  40d92c:	nop    DWORD PTR [rax+0x0]
  40d930:	mov    rsi,r15
  40d933:	shl    rsi,0x6
  40d937:	mov    eax,DWORD PTR [rdi+rsi*1]
  40d93a:	bswap  eax
  40d93c:	mov    QWORD PTR [rbx+0x90],rax
  40d943:	mov    eax,DWORD PTR [rdi+rsi*1+0x4]
  40d947:	bswap  eax
  40d949:	mov    QWORD PTR [rbx+0x98],rax
  40d950:	mov    eax,DWORD PTR [rdi+rsi*1+0x8]
  40d954:	bswap  eax
  40d956:	mov    QWORD PTR [rbx+0xa0],rax
  40d95d:	mov    eax,DWORD PTR [rdi+rsi*1+0xc]
  40d961:	bswap  eax
  40d963:	mov    QWORD PTR [rbx+0xa8],rax
  40d96a:	mov    eax,DWORD PTR [rdi+rsi*1+0x10]
  40d96e:	bswap  eax
  40d970:	mov    QWORD PTR [rbx+0xb0],rax
  40d977:	mov    eax,DWORD PTR [rdi+rsi*1+0x14]
  40d97b:	bswap  eax
  40d97d:	mov    QWORD PTR [rbx+0xb8],rax
  40d984:	mov    eax,DWORD PTR [rdi+rsi*1+0x18]
  40d988:	bswap  eax
  40d98a:	mov    QWORD PTR [rbx+0xc0],rax
  40d991:	mov    eax,DWORD PTR [rdi+rsi*1+0x1c]
  40d995:	bswap  eax
  40d997:	mov    QWORD PTR [rbx+0xc8],rax
  40d99e:	mov    eax,DWORD PTR [rdi+rsi*1+0x20]
  40d9a2:	bswap  eax
  40d9a4:	mov    QWORD PTR [rbx+0xd0],rax
  40d9ab:	mov    eax,DWORD PTR [rdi+rsi*1+0x24]
  40d9af:	bswap  eax
  40d9b1:	mov    QWORD PTR [rbx+0xd8],rax
  40d9b8:	mov    eax,DWORD PTR [rdi+rsi*1+0x28]
  40d9bc:	bswap  eax
  40d9be:	mov    QWORD PTR [rbx+0xe0],rax
  40d9c5:	mov    eax,DWORD PTR [rdi+rsi*1+0x2c]
  40d9c9:	bswap  eax
  40d9cb:	mov    QWORD PTR [rbx+0xe8],rax
  40d9d2:	mov    eax,DWORD PTR [rdi+rsi*1+0x30]
  40d9d6:	bswap  eax
  40d9d8:	mov    QWORD PTR [rbx+0xf0],rax
  40d9df:	mov    eax,DWORD PTR [rdi+rsi*1+0x34]
  40d9e3:	bswap  eax
  40d9e5:	mov    QWORD PTR [rbx+0xf8],rax
  40d9ec:	mov    eax,DWORD PTR [rdi+rsi*1+0x38]
  40d9f0:	bswap  eax
  40d9f2:	mov    QWORD PTR [rbx+0x100],rax
  40d9f9:	vmovq  xmm3,r15
  40d9fe:	mov    eax,DWORD PTR [rdi+rsi*1+0x3c]
  40da02:	bswap  eax
  40da04:	mov    QWORD PTR [rbx+0x108],rax
  40da0b:	mov    eax,0x10
  40da10:	cmp    rax,0x40
  40da14:	jae    40da73 <__swc_fn_65555ab2_000178_72e41d4d+0x393>
  40da16:	cs nop WORD PTR [rax+rax*1+0x0]
  40da20:	mov    rsi,QWORD PTR [r14+rax*8-0x78]
  40da25:	mov    r15,QWORD PTR [r14+rax*8-0x10]
  40da2a:	rorx   edi,esi,0x7
  40da30:	rorx   r13d,esi,0x12
  40da36:	xor    rdi,r13
  40da39:	shr    rsi,0x3
  40da3d:	xor    rdi,rsi
  40da40:	rorx   esi,r15d,0x11
  40da46:	rorx   r13d,r15d,0x13
  40da4c:	xor    rsi,r13
  40da4f:	shr    r15,0xa
  40da53:	xor    rsi,r15
  40da56:	mov    r13,QWORD PTR [r14+rax*8-0x80]
  40da5b:	add    r13,rdi
  40da5e:	add    r13,QWORD PTR [r14+rax*8-0x38]
  40da63:	add    r13d,esi
  40da66:	mov    QWORD PTR [r14+rax*8],r13
  40da6a:	inc    rax
  40da6d:	cmp    rax,0x40
  40da71:	jb     40da20 <__swc_fn_65555ab2_000178_72e41d4d+0x340>
  40da73:	mov    rax,rcx
  40da76:	mov    rsi,rdx
  40da79:	mov    rdi,r8
  40da7c:	mov    r13,r9
  40da7f:	mov    r15,r10
  40da82:	vmovq  xmm4,r10
  40da87:	mov    r10,r11
  40da8a:	vmovq  xmm5,r11
  40da8f:	mov    r11,r12
  40da92:	mov    QWORD PTR [rsp+0x3e8],r9
  40da9a:	mov    QWORD PTR [rsp+0x400],r12
  40daa2:	vmovq  r9,xmm2
  40daa7:	xor    r12d,r12d
  40daaa:	mov    QWORD PTR [rsp+0x3e0],r8
  40dab2:	mov    QWORD PTR [rsp+0x3d0],rcx
  40daba:	mov    QWORD PTR [rsp+0x3d8],rdx
  40dac2:	cs nop WORD PTR [rax+rax*1+0x0]
  40dacc:	cs nop WORD PTR [rax+rax*1+0x0]
  40dad6:	cs nop WORD PTR [rax+rax*1+0x0]
  40dae0:	rorx   r8d,r15d,0x6
  40dae6:	rorx   edx,r15d,0xb
  40daec:	xor    r8,rdx
  40daef:	rorx   edx,r15d,0x19
  40daf5:	xor    r8,rdx
  40daf8:	mov    rdx,r15
  40dafb:	and    rdx,r10
  40dafe:	andn   ecx,r15d,r11d
  40db03:	xor    rdx,rcx
  40db06:	add    r9,r8
  40db09:	add    r9,rdx
  40db0c:	lea    rcx,[rip+0x5e05]        # 413918 <__swc_rdata_base_65555ab2+0x808>
  40db13:	add    r9,QWORD PTR [rcx+r12*8]
  40db17:	add    r9d,DWORD PTR [r14+r12*8]
  40db1b:	rorx   edx,eax,0x2
  40db21:	rorx   r8d,eax,0xd
  40db27:	xor    rdx,r8
  40db2a:	rorx   r8d,eax,0x16
  40db30:	xor    rdx,r8
  40db33:	mov    r8,rsi
  40db36:	xor    r8,rdi
  40db39:	and    r8,rax
  40db3c:	vmovq  xmm0,rax
  40db41:	mov    rax,rsi
  40db44:	and    rax,rdi
  40db47:	xor    r8,rax
  40db4a:	add    edx,r8d
  40db4d:	lea    eax,[r13+r9*1+0x0]
  40db52:	lea    r8d,[r9+rdx*1]
  40db56:	add    r12,0x1
  40db5a:	rorx   edx,eax,0x6
  40db60:	rorx   r9d,eax,0xb
  40db66:	xor    rdx,r9
  40db69:	rorx   r9d,eax,0x19
  40db6f:	xor    rdx,r9
  40db72:	mov    r9,rax
  40db75:	and    r9,r15
  40db78:	andn   r13d,eax,r10d
  40db7d:	xor    r9,r13
  40db80:	add    r11,rdx
  40db83:	add    r11,r9
  40db86:	add    r11,QWORD PTR [rcx+r12*8]
  40db8a:	mov    ecx,r11d
  40db8d:	add    ecx,DWORD PTR [r14+r12*8]
  40db91:	rorx   edx,r8d,0x2
  40db97:	rorx   r9d,r8d,0xd
  40db9d:	xor    rdx,r9
  40dba0:	rorx   r9d,r8d,0x16
  40dba6:	xor    rdx,r9
  40dba9:	vmovq  r13,xmm0
  40dbae:	mov    r9,r13
  40dbb1:	xor    r9,rsi
  40dbb4:	and    r9,r8
  40dbb7:	mov    r11,r13
  40dbba:	and    r11,rsi
  40dbbd:	xor    r9,r11
  40dbc0:	add    edx,r9d
  40dbc3:	mov    r9,r10
  40dbc6:	mov    r11,r15
  40dbc9:	mov    r10,rax
  40dbcc:	lea    r15d,[rdi+rcx*1]
  40dbd0:	vmovq  xmm1,rax
  40dbd5:	mov    rdi,r13
  40dbd8:	mov    r13,rsi
  40dbdb:	mov    rsi,r8
  40dbde:	add    ecx,edx
  40dbe0:	mov    rdx,r15
  40dbe3:	mov    rax,rcx
  40dbe6:	add    r12,0x1
  40dbea:	cmp    r12,0x40
  40dbee:	jb     40dae0 <__swc_fn_65555ab2_000178_72e41d4d+0x400>
  40dbf4:	mov    rax,QWORD PTR [rsp+0x3d0]
  40dbfc:	add    eax,ecx
  40dbfe:	mov    rcx,QWORD PTR [rsp+0x3d8]
  40dc06:	add    ecx,r8d
  40dc09:	mov    r8,QWORD PTR [rsp+0x3e0]
  40dc11:	add    r8d,edi
  40dc14:	mov    r10,QWORD PTR [rsp+0x3e8]
  40dc1c:	add    r10d,r13d
  40dc1f:	vmovq  rsi,xmm4
  40dc24:	add    esi,edx
  40dc26:	vmovq  rdi,xmm5
  40dc2b:	vmovq  rdx,xmm1
  40dc30:	add    edi,edx
  40dc32:	mov    r12,QWORD PTR [rsp+0x400]
  40dc3a:	add    r12d,r11d
  40dc3d:	vmovq  rdx,xmm2
  40dc42:	add    edx,r9d
  40dc45:	vmovq  r15,xmm3
  40dc4a:	vmovq  xmm2,rdx
  40dc4f:	add    r15,0x1
  40dc53:	mov    r9,QWORD PTR [rsp+0x410]
  40dc5b:	cmp    r15,r9
  40dc5e:	jae    40dc7c <__swc_fn_65555ab2_000178_72e41d4d+0x59c>
  40dc60:	mov    rdx,rcx
  40dc63:	mov    r9,r10
  40dc66:	mov    r10,rsi
  40dc69:	mov    r11,rdi
  40dc6c:	mov    rdi,QWORD PTR [rsp+0x3c8]
  40dc74:	mov    rcx,rax
  40dc77:	jmp    40d930 <__swc_fn_65555ab2_000178_72e41d4d+0x250>
  40dc7c:	xor    rax,rcx
  40dc7f:	xor    rax,r8
  40dc82:	xor    rax,r10
  40dc85:	xor    rax,rsi
  40dc88:	xor    rax,rdi
  40dc8b:	xor    rax,r12
  40dc8e:	mov    rsi,rax
  40dc91:	xor    rsi,rdx
  40dc94:	sub    rsp,0x8
  40dc98:	call   40a350 <__swc_fn_65555ab2_000177_1ca87929>
  40dc9d:	add    rsp,0x8
  40dca1:	vsubsd xmm0,xmm0,xmm6
  40dca5:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x5f1b]        # 413bc8 <__swc_rdata_base_65555ab2+0xab8>
  40dcad:	lea    rax,[rip+0x56b4]        # 413368 <__swc_rdata_base_65555ab2+0x258>
  40dcb4:	sub    rsp,0x90
  40dcbb:	mov    rcx,rsp
  40dcbe:	vmovups xmm1,XMMWORD PTR [rip+0x5ee2]        # 413ba8 <__swc_rdata_base_65555ab2+0xa98>
  40dcc6:	vmovups XMMWORD PTR [rcx],xmm1
  40dcca:	mov    QWORD PTR [rcx+0x30],rsp
  40dcce:	lea    rdx,[rip+0x563b]        # 413310 <__swc_rdata_base_65555ab2+0x200>
  40dcd5:	mov    QWORD PTR [rcx+0x38],rdx
  40dcd9:	mov    QWORD PTR [rcx+0x10],rsi
  40dcdd:	lea    r8,[rsp+0x10]
  40dce2:	mov    QWORD PTR [rcx+0x40],r8
  40dce6:	lea    r8,[rip+0x5e2b]        # 413b18 <__swc_rdata_base_65555ab2+0xa08>
  40dced:	mov    QWORD PTR [rcx+0x48],r8
  40dcf1:	vmovups xmm1,XMMWORD PTR [rip+0x5ebf]        # 413bb8 <__swc_rdata_base_65555ab2+0xaa8>
  40dcf9:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40dcfe:	lea    r8,[rsp+0x18]
  40dd03:	mov    QWORD PTR [rcx+0x50],r8
  40dd07:	mov    QWORD PTR [rcx+0x58],rdx
  40dd0b:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40dd10:	lea    r8,[rcx+0x28]
  40dd14:	mov    QWORD PTR [rcx+0x60],r8
  40dd18:	lea    r8,[rip+0x5e41]        # 413b60 <__swc_rdata_base_65555ab2+0xa50>
  40dd1f:	mov    QWORD PTR [rcx+0x68],r8
  40dd23:	mov    QWORD PTR [rcx+0x70],rax
  40dd27:	mov    QWORD PTR [rcx+0x78],rdx
  40dd2b:	lea    rax,[rcx+0x30]
  40dd2f:	mov    QWORD PTR [rcx+0x80],rax
  40dd36:	mov    QWORD PTR [rcx+0x88],0x5
  40dd41:	lea    rcx,[rcx+0x80]
  40dd48:	sub    rsp,0x8
  40dd4c:	call   4108c0 <__swc_fn_65555ab2_000146_e9d46966>
  40dd51:	add    rsp,0x8
  40dd55:	add    rsp,0x90
  40dd5c:	mov    rdi,QWORD PTR [rsp+0x3c8]
  40dd64:	mov    rcx,rdi
  40dd67:	sub    rsp,0x8
  40dd6b:	call   411fa0 <__swc_fn_65555ab2_000176_5d3d19bd>
  40dd70:	add    rsp,0x8
  40dd74:	mov    rsi,QWORD PTR [rsp+0x3c0]
  40dd7c:	mov    rcx,rsi
  40dd7f:	sub    rsp,0x8
  40dd83:	call   411fa0 <__swc_fn_65555ab2_000176_5d3d19bd>
  40dd88:	add    rsp,0x438
  40dd8f:	vmovups xmm6,XMMWORD PTR [rsp]
  40dd94:	add    rsp,0x10
  40dd98:	pop    r15
  40dd9a:	pop    r14
  40dd9c:	pop    r13
  40dd9e:	pop    r12
  40dda0:	pop    rdi
  40dda1:	pop    rsi
  40dda2:	pop    rbx
  40dda3:	pop    rbp
  40dda4:	ret
	...

000000000040ddc0 <__swc_fn_65555ab2_000002_390d5093>:
  40ddc0:	sub    rsp,0x8
  40ddc4:	call   40c620 <__swc_fn_65555ab2_000109_aa570b2b>
  40ddc9:	mov    rcx,rax
  40ddcc:	test   rax,rax
  40ddcf:	je     40ddf6 <__swc_fn_65555ab2_000002_390d5093+0x36>
  40ddd1:	lea    rdx,[rip+0x16268]        # 424040 <__swc_bss_base_65555ab2>
  40ddd8:	mov    r8,QWORD PTR [rip+0x16261]        # 424040 <__swc_bss_base_65555ab2>
  40dddf:	nop
  40dde0:	lea    r9,[r8+0x1]
  40dde4:	mov    rax,r8
  40dde7:	lock cmpxchg QWORD PTR [rdx],r9
  40ddec:	cmp    rax,r8
  40ddef:	je     40ddf6 <__swc_fn_65555ab2_000002_390d5093+0x36>
  40ddf1:	mov    r8,rax
  40ddf4:	jmp    40dde0 <__swc_fn_65555ab2_000002_390d5093+0x20>
  40ddf6:	mov    rax,rcx
  40ddf9:	add    rsp,0x8
  40ddfd:	ret
	...

000000000040de00 <__swc_fn_65555ab2_000005_bcc5b80b>:
  40de00:	mov    r8d,edx
  40de03:	xor    eax,eax
  40de05:	tzcnt  eax,edx
  40de09:	shrx   r9d,edx,eax
  40de0e:	mov    DWORD PTR [rcx+0x2c],edx
  40de11:	xor    eax,eax
  40de13:	tzcnt  eax,edx
  40de17:	mov    BYTE PTR [rcx+0x38],al
  40de1a:	mov    eax,0xffffffff
  40de1f:	xor    edx,edx
  40de21:	div    r8d
  40de24:	mov    DWORD PTR [rcx+0x34],eax
  40de27:	mov    eax,r9d
  40de2a:	mov    edx,r9d
  40de2d:	imul   edx,r9d
  40de31:	mov    r8d,0x2
  40de37:	sub    r8d,edx
  40de3a:	imul   eax,r8d
  40de3e:	mov    edx,r9d
  40de41:	imul   edx,eax
  40de44:	mov    r8d,0x2
  40de4a:	sub    r8d,edx
  40de4d:	imul   eax,r8d
  40de51:	mov    edx,r9d
  40de54:	imul   edx,eax
  40de57:	mov    r8d,0x2
  40de5d:	sub    r8d,edx
  40de60:	imul   eax,r8d
  40de64:	mov    edx,r9d
  40de67:	imul   edx,eax
  40de6a:	mov    r8d,0x2
  40de70:	sub    r8d,edx
  40de73:	imul   eax,r8d
  40de77:	imul   r9d,eax
  40de7b:	mov    edx,0x2
  40de80:	sub    edx,r9d
  40de83:	imul   eax,edx
  40de86:	mov    DWORD PTR [rcx+0x30],eax
  40de89:	ret
  40de8a:	add    BYTE PTR [rax],al
  40de8c:	add    BYTE PTR [rax],al
	...

000000000040de90 <__swc_fn_65555ab2_000008_578f1784>:
  40de90:	xor    eax,eax
  40de92:	mov    DWORD PTR [rcx+0x68],eax
  40de95:	ret
	...

000000000040dea0 <__swc_fn_65555ab2_000011_e75d466d>:
  40dea0:	mov    eax,DWORD PTR [rcx+0x28]
  40dea3:	shlx   eax,edx,eax
  40dea8:	shl    rax,0x10
  40deac:	lea    rdx,[rcx+rax*1]
  40deb0:	lea    rax,[rcx+0x3000]
  40deb7:	cmp    rdx,rax
  40deba:	cmovae rax,rdx
  40debe:	ret
	...

000000000040dec0 <__swc_fn_65555ab2_000014_1acdaf22>:
  40dec0:	push   rsi
  40dec1:	push   rdi
  40dec2:	push   r12
  40dec4:	push   r13
  40dec6:	push   r14
  40dec8:	mov    rsi,rdx
  40decb:	mov    rdi,rcx
  40dece:	rex mov dl,BYTE PTR [rsi+0x3a]
  40ded2:	mov    ecx,DWORD PTR [rdi+0x28]
  40ded5:	shr    dl,cl
  40ded7:	mov    r12d,0x1
  40dedd:	mov    ecx,edx
  40dedf:	shl    r12,cl
  40dee2:	mov    r13d,DWORD PTR [rsi+0x3c]
  40dee6:	rex mov BYTE PTR [rsi+0x3b],0x0
  40deeb:	mov    QWORD PTR [rsi+0x40],0x0
  40def3:	mov    QWORD PTR [rsi],0x0
  40defa:	mov    rax,QWORD PTR [rsi+0x10]
  40defe:	mov    QWORD PTR [rsi+0x20],rax
  40df02:	lea    r14,[rip+0x1613f]        # 424048 <__swc_bss_base_65555ab2+0x8>
  40df09:	mov    rax,QWORD PTR [r14]
  40df0c:	shr    rax,0x2
  40df10:	mov    rcx,rax
  40df13:	cmp    rax,0x800000
  40df1a:	mov    eax,0x800000
  40df1f:	cmovb  rcx,rax
  40df23:	lea    r8,[rip+0x1612e]        # 424058 <__swc_bss_base_65555ab2+0x18>
  40df2a:	mov    rax,QWORD PTR [r8]
  40df2d:	mov    r9,rax
  40df30:	lea    r10,[r9+r13*1]
  40df34:	cmp    r10,rcx
  40df37:	ja     40df5b <__swc_fn_65555ab2_000014_1acdaf22+0x9b>
  40df39:	mov    rax,r9
  40df3c:	lock cmpxchg QWORD PTR [r8],r10
  40df41:	cmp    rax,r9
  40df44:	je     40df4b <__swc_fn_65555ab2_000014_1acdaf22+0x8b>
  40df46:	mov    r9,rax
  40df49:	jmp    40df30 <__swc_fn_65555ab2_000014_1acdaf22+0x70>
  40df4b:	mov    rcx,rdi
  40df4e:	mov    rdx,r12
  40df51:	call   40a750 <__swc_fn_65555ab2_000016_89da4d6e>
  40df56:	jmp    40dfdd <__swc_fn_65555ab2_000014_1acdaf22+0x11d>
  40df5b:	mov    rcx,rdi
  40df5e:	movzx  edx,dl
  40df61:	call   40dea0 <__swc_fn_65555ab2_000011_e75d466d>
  40df66:	test   r13,r13
  40df69:	je     40dfd6 <__swc_fn_65555ab2_000014_1acdaf22+0x116>
  40df6f:	mov    rcx,rax
  40df72:	mov    rdx,r13
  40df75:	call   40c7a0 <__swc_fn_65555ab2_000112_cb2656be>
  40df7a:	mov    rcx,QWORD PTR [rip+0x160c7]        # 424048 <__swc_bss_base_65555ab2+0x8>
  40df81:	cs nop WORD PTR [rax+rax*1+0x0]
  40df8b:	nop    DWORD PTR [rax+rax*1+0x0]
  40df90:	mov    rdx,rcx
  40df93:	sub    rdx,r13
  40df96:	mov    rax,rcx
  40df99:	lock cmpxchg QWORD PTR [r14],rdx
  40df9e:	cmp    rax,rcx
  40dfa1:	je     40dfa8 <__swc_fn_65555ab2_000014_1acdaf22+0xe8>
  40dfa3:	mov    rcx,rax
  40dfa6:	jmp    40df90 <__swc_fn_65555ab2_000014_1acdaf22+0xd0>
  40dfa8:	lea    rcx,[rip+0x160b1]        # 424060 <__swc_bss_base_65555ab2+0x20>
  40dfaf:	mov    rdx,QWORD PTR [rip+0x160aa]        # 424060 <__swc_bss_base_65555ab2+0x20>
  40dfb6:	cs nop WORD PTR [rax+rax*1+0x0]
  40dfc0:	lea    r8,[rdx+0x1]
  40dfc4:	mov    rax,rdx
  40dfc7:	lock cmpxchg QWORD PTR [rcx],r8
  40dfcc:	cmp    rax,rdx
  40dfcf:	je     40dfd6 <__swc_fn_65555ab2_000014_1acdaf22+0x116>
  40dfd1:	mov    rdx,rax
  40dfd4:	jmp    40dfc0 <__swc_fn_65555ab2_000014_1acdaf22+0x100>
  40dfd6:	mov    DWORD PTR [rsi+0x3c],0x0
  40dfdd:	mov    rcx,rdi
  40dfe0:	mov    rdx,r12
  40dfe3:	call   407600 <__swc_fn_65555ab2_000018_e2e8e4b0>
  40dfe8:	pop    r14
  40dfea:	pop    r13
  40dfec:	pop    r12
  40dfee:	pop    rdi
  40dfef:	pop    rsi
  40dff0:	ret
	...

000000000040e000 <__swc_fn_65555ab2_000017_e238d24c>:
  40e000:	mov    r8,QWORD PTR [rcx+0x48]
  40e004:	test   r8,rdx
  40e007:	je     40e038 <__swc_fn_65555ab2_000017_e238d24c+0x38>
  40e009:	nop    DWORD PTR [rax+0x0]
  40e010:	mov    rax,rdx
  40e013:	not    rax
  40e016:	mov    r9,r8
  40e019:	and    r9,rax
  40e01c:	mov    rax,r8
  40e01f:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40e025:	cmp    rax,r8
  40e028:	jne    40e030 <__swc_fn_65555ab2_000017_e238d24c+0x30>
  40e02a:	mov    eax,0x1
  40e02f:	ret
  40e030:	mov    r8,rax
  40e033:	test   rax,rdx
  40e036:	jne    40e010 <__swc_fn_65555ab2_000017_e238d24c+0x10>
  40e038:	xor    eax,eax
  40e03a:	ret
  40e03b:	add    BYTE PTR [rax],al
  40e03d:	add    BYTE PTR [rax],al
	...

000000000040e040 <__swc_fn_65555ab2_000020_4135c89a>:
  40e040:	push   rsi
  40e041:	push   rdi
  40e042:	push   r12
  40e044:	push   r13
  40e046:	sub    rsp,0x8
  40e04a:	mov    rsi,rdx
  40e04d:	mov    rdi,rcx
  40e050:	lea    r12,[rip+0x16199]        # 4241f0 <__swc_bss_base_65555ab2+0x1b0>
  40e057:	mov    rcx,r12
  40e05a:	call   4098a0 <__swc_fn_65555ab2_000135_1fec60ac>
  40e05f:	xor    eax,eax
  40e061:	mov    rcx,QWORD PTR [rip+0x16190]        # 4241f8 <__swc_bss_base_65555ab2+0x1b8>
  40e068:	mov    r13,rcx
  40e06b:	test   r13,r13
  40e06e:	je     40e0bb <__swc_fn_65555ab2_000020_4135c89a+0x7b>
  40e070:	mov    rcx,QWORD PTR [r13+0x10]
  40e074:	cmp    DWORD PTR [r13+0x28],esi
  40e078:	jne    40e0b0 <__swc_fn_65555ab2_000020_4135c89a+0x70>
  40e07a:	test   rax,rax
  40e07d:	jne    40e088 <__swc_fn_65555ab2_000020_4135c89a+0x48>
  40e07f:	mov    QWORD PTR [rip+0x16172],rcx        # 4241f8 <__swc_bss_base_65555ab2+0x1b8>
  40e086:	jmp    40e08c <__swc_fn_65555ab2_000020_4135c89a+0x4c>
  40e088:	mov    QWORD PTR [rax+0x10],rcx
  40e08c:	vxorps xmm0,xmm0,xmm0
  40e090:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40e096:	mov    QWORD PTR [r13+0x8],rdi
  40e09a:	mov    rcx,r12
  40e09d:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  40e0a2:	mov    rax,r13
  40e0a5:	add    rsp,0x8
  40e0a9:	pop    r13
  40e0ab:	pop    r12
  40e0ad:	pop    rdi
  40e0ae:	pop    rsi
  40e0af:	ret
  40e0b0:	mov    rax,r13
  40e0b3:	mov    r13,rcx
  40e0b6:	test   rcx,rcx
  40e0b9:	jne    40e070 <__swc_fn_65555ab2_000020_4135c89a+0x30>
  40e0bb:	mov    ecx,esi
  40e0bd:	call   40a780 <__swc_fn_65555ab2_000019_60e50998>
  40e0c2:	mov    rsi,rax
  40e0c5:	test   rax,rax
  40e0c8:	jne    40e0df <__swc_fn_65555ab2_000020_4135c89a+0x9f>
  40e0ca:	mov    rcx,r12
  40e0cd:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  40e0d2:	xor    eax,eax
  40e0d4:	add    rsp,0x8
  40e0d8:	pop    r13
  40e0da:	pop    r12
  40e0dc:	pop    rdi
  40e0dd:	pop    rsi
  40e0de:	ret
  40e0df:	mov    QWORD PTR [rsi+0x8],rdi
  40e0e3:	mov    rcx,r12
  40e0e6:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  40e0eb:	mov    rax,rsi
  40e0ee:	add    rsp,0x8
  40e0f2:	pop    r13
  40e0f4:	pop    r12
  40e0f6:	pop    rdi
  40e0f7:	pop    rsi
  40e0f8:	ret
  40e0f9:	add    BYTE PTR [rax],al
  40e0fb:	add    BYTE PTR [rax],al
  40e0fd:	add    BYTE PTR [rax],al
	...

000000000040e100 <__swc_fn_65555ab2_000023_7e9350e1>:
  40e100:	vxorps xmm0,xmm0,xmm0
  40e104:	xor    eax,eax
  40e106:	cs nop WORD PTR [rax+rax*1+0x0]
  40e110:	cs nop WORD PTR [rax+rax*1+0x0]
  40e11a:	nop    WORD PTR [rax+rax*1+0x0]
  40e120:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40e125:	add    rax,0x10
  40e129:	cmp    rax,0x2b00
  40e130:	jne    40e120 <__swc_fn_65555ab2_000023_7e9350e1+0x20>
  40e132:	ret
	...

000000000040e140 <__swc_fn_65555ab2_000026_7e9350e1>:
  40e140:	vxorps xmm0,xmm0,xmm0
  40e144:	vmovups XMMWORD PTR [rcx],xmm0
  40e148:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e14d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e152:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e157:	ret
	...

000000000040e160 <__swc_fn_65555ab2_000029_7e9350e1>:
  40e160:	vxorps xmm0,xmm0,xmm0
  40e164:	vmovups XMMWORD PTR [rcx],xmm0
  40e168:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40e16d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40e172:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40e177:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40e17c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40e181:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40e186:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40e18b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40e193:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40e19b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40e1a3:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40e1ab:	mov    QWORD PTR [rcx+0xc0],0x0
  40e1b6:	ret
	...

000000000040e1c0 <__swc_fn_65555ab2_000032_8c89735c>:
  40e1c0:	push   rsi
  40e1c1:	push   rdi
  40e1c2:	sub    rsp,0x8
  40e1c6:	mov    rsi,rcx
  40e1c9:	lea    rdi,[rip+0x13e30]        # 422000 <__swc_data_base_65555ab2>
  40e1d0:	mov    rax,QWORD PTR [rdi]
  40e1d3:	cmp    rax,0xffffffffffffffff
  40e1d7:	je     40e1de <__swc_fn_65555ab2_000032_8c89735c+0x1e>
  40e1d9:	mov    rdi,rax
  40e1dc:	jmp    40e20b <__swc_fn_65555ab2_000032_8c89735c+0x4b>
  40e1de:	call   409580 <__swc_fn_65555ab2_000123_e9227a3e>
  40e1e3:	mov    rcx,rax
  40e1e6:	cmp    rax,0xffffffffffffffff
  40e1ea:	je     40e21c <__swc_fn_65555ab2_000032_8c89735c+0x5c>
  40e1ec:	mov    rax,0xffffffffffffffff
  40e1f3:	lock cmpxchg QWORD PTR [rdi],rcx
  40e1f8:	cmp    rax,0xffffffffffffffff
  40e1fc:	je     40e208 <__swc_fn_65555ab2_000032_8c89735c+0x48>
  40e1fe:	mov    rdi,rax
  40e201:	call   40cb70 <__swc_fn_65555ab2_000124_df97aa0a>
  40e206:	jmp    40e20b <__swc_fn_65555ab2_000032_8c89735c+0x4b>
  40e208:	mov    rdi,rcx
  40e20b:	cmp    rdi,0xffffffffffffffff
  40e20f:	je     40e21c <__swc_fn_65555ab2_000032_8c89735c+0x5c>
  40e211:	mov    rcx,rdi
  40e214:	mov    rdx,rsi
  40e217:	call   4102d0 <__swc_fn_65555ab2_000125_e19c72b3>
  40e21c:	add    rsp,0x8
  40e220:	pop    rdi
  40e221:	pop    rsi
  40e222:	ret
	...

000000000040e230 <__swc_fn_65555ab2_000035_6105596e>:
  40e230:	sub    rsp,0x38
  40e234:	mov    rax,rdx
  40e237:	test   dl,dl
  40e239:	jne    40e251 <__swc_fn_65555ab2_000035_6105596e+0x21>
  40e23b:	mov    rax,r8
  40e23e:	test   r8b,r8b
  40e241:	cmove  eax,r9d
  40e245:	test   al,al
  40e247:	cmove  eax,r10d
  40e24b:	test   al,al
  40e24d:	cmove  eax,r11d
  40e251:	test   al,al
  40e253:	jne    40e25a <__swc_fn_65555ab2_000035_6105596e+0x2a>
  40e255:	add    rsp,0x38
  40e259:	ret
  40e25a:	lea    rcx,[rip+0x4eaf]        # 413110 <__swc_rdata_base_65555ab2>
  40e261:	vmovups xmm0,XMMWORD PTR [rip+0x4eb7]        # 413120 <__swc_rdata_base_65555ab2+0x10>
  40e269:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e26f:	vmovups xmm0,XMMWORD PTR [rip+0x4eb9]        # 413130 <__swc_rdata_base_65555ab2+0x20>
  40e277:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e27d:	vmovups xmm0,XMMWORD PTR [rip+0x4ebb]        # 413140 <__swc_rdata_base_65555ab2+0x30>
  40e285:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e28b:	lea    rdx,[rsp+0x8]
  40e290:	call   40c3a0 <__swc_fn_65555ab2_000103_2ed36338>
  40e295:	jmp    40e255 <__swc_fn_65555ab2_000035_6105596e+0x25>
	...

000000000040e2a0 <__swc_fn_65555ab2_000038_c7591393>:
  40e2a0:	sub    rsp,0x8
  40e2a4:	mov    eax,0x1000
  40e2a9:	test   eax,eax
  40e2ab:	mov    r8d,0x8
  40e2b1:	cmove  eax,r8d
  40e2b5:	dec    rax
  40e2b8:	mov    r8,0xffffffffffffffff
  40e2bf:	sub    r8,rax
  40e2c2:	cmp    rdx,r8
  40e2c5:	ja     40e2d5 <__swc_fn_65555ab2_000038_c7591393+0x35>
  40e2c7:	add    rdx,rax
  40e2ca:	not    rax
  40e2cd:	mov    r8,rdx
  40e2d0:	and    r8,rax
  40e2d3:	jne    40e2dc <__swc_fn_65555ab2_000038_c7591393+0x3c>
  40e2d5:	xor    eax,eax
  40e2d7:	add    rsp,0x8
  40e2db:	ret
  40e2dc:	mov    rdx,r8
  40e2df:	call   40aaa0 <__swc_fn_65555ab2_000037_92e867c2>
  40e2e4:	add    rsp,0x8
  40e2e8:	ret
  40e2e9:	add    BYTE PTR [rax],al
  40e2eb:	add    BYTE PTR [rax],al
  40e2ed:	add    BYTE PTR [rax],al
	...

000000000040e2f0 <__swc_fn_65555ab2_000041_ed1cda78>:
  40e2f0:	push   rsi
  40e2f1:	push   rdi
  40e2f2:	sub    rsp,0x8
  40e2f6:	mov    rsi,rdx
  40e2f9:	mov    rdi,rcx
  40e2fc:	test   rdx,rdx
  40e2ff:	je     40e31b <__swc_fn_65555ab2_000041_ed1cda78+0x2b>
  40e301:	xor    ecx,ecx
  40e303:	call   407720 <__swc_fn_65555ab2_000033_7d7574b6>
  40e308:	mov    rax,QWORD PTR [rsi]
  40e30b:	test   rax,rax
  40e30e:	je     40e31b <__swc_fn_65555ab2_000041_ed1cda78+0x2b>
  40e310:	mov    rcx,rax
  40e313:	mov    rdx,rsi
  40e316:	call   407840 <__swc_fn_65555ab2_000042_70d5ab54>
  40e31b:	mov    rcx,rdi
  40e31e:	call   40ab00 <__swc_fn_65555ab2_000040_7a225310>
  40e323:	mov    rsi,rax
  40e326:	test   rax,rax
  40e329:	jne    40e334 <__swc_fn_65555ab2_000041_ed1cda78+0x44>
  40e32b:	xor    eax,eax
  40e32d:	add    rsp,0x8
  40e331:	pop    rdi
  40e332:	pop    rsi
  40e333:	ret
  40e334:	mov    rcx,rsi
  40e337:	call   407720 <__swc_fn_65555ab2_000033_7d7574b6>
  40e33c:	mov    rax,rsi
  40e33f:	add    rsp,0x8
  40e343:	pop    rdi
  40e344:	pop    rsi
  40e345:	ret
	...

000000000040e350 <__swc_fn_65555ab2_000044_cac7f504>:
  40e350:	movzx  eax,BYTE PTR [r8+0x39]
  40e355:	lea    rax,[rax+rax*4]
  40e359:	lea    rax,[rdx+rax*8+0x28]
  40e35e:	mov    ecx,DWORD PTR [r8+0x6c]
  40e362:	test   ecx,ecx
  40e364:	je     40e39d <__swc_fn_65555ab2_000044_cac7f504+0x4d>
  40e366:	mov    rcx,QWORD PTR [r8+0x50]
  40e36a:	test   rcx,rcx
  40e36d:	je     40e379 <__swc_fn_65555ab2_000044_cac7f504+0x29>
  40e36f:	mov    rax,QWORD PTR [r8+0x48]
  40e373:	mov    QWORD PTR [rcx+0x48],rax
  40e377:	jmp    40e381 <__swc_fn_65555ab2_000044_cac7f504+0x31>
  40e379:	mov    rcx,QWORD PTR [r8+0x48]
  40e37d:	mov    QWORD PTR [rax+0x18],rcx
  40e381:	mov    rax,QWORD PTR [r8+0x48]
  40e385:	test   rax,rax
  40e388:	je     40e392 <__swc_fn_65555ab2_000044_cac7f504+0x42>
  40e38a:	mov    rcx,QWORD PTR [r8+0x50]
  40e38e:	mov    QWORD PTR [rax+0x50],rcx
  40e392:	vxorps xmm0,xmm0,xmm0
  40e396:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e39c:	ret
  40e39d:	mov    rcx,QWORD PTR [r8+0x50]
  40e3a1:	test   rcx,rcx
  40e3a4:	je     40e3b0 <__swc_fn_65555ab2_000044_cac7f504+0x60>
  40e3a6:	mov    rdx,QWORD PTR [r8+0x48]
  40e3aa:	mov    QWORD PTR [rcx+0x48],rdx
  40e3ae:	jmp    40e3b8 <__swc_fn_65555ab2_000044_cac7f504+0x68>
  40e3b0:	mov    rcx,QWORD PTR [r8+0x48]
  40e3b4:	mov    QWORD PTR [rax+0x8],rcx
  40e3b8:	mov    rcx,QWORD PTR [r8+0x48]
  40e3bc:	test   rcx,rcx
  40e3bf:	je     40e3cb <__swc_fn_65555ab2_000044_cac7f504+0x7b>
  40e3c1:	mov    rdx,QWORD PTR [r8+0x50]
  40e3c5:	mov    QWORD PTR [rcx+0x50],rdx
  40e3c9:	jmp    40e3d3 <__swc_fn_65555ab2_000044_cac7f504+0x83>
  40e3cb:	mov    rcx,QWORD PTR [r8+0x50]
  40e3cf:	mov    QWORD PTR [rax+0x10],rcx
  40e3d3:	cmp    QWORD PTR [rax],r8
  40e3d6:	jne    40e3df <__swc_fn_65555ab2_000044_cac7f504+0x8f>
  40e3d8:	mov    QWORD PTR [rax],0x0
  40e3df:	vxorps xmm0,xmm0,xmm0
  40e3e3:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40e3e9:	ret
  40e3ea:	add    BYTE PTR [rax],al
  40e3ec:	add    BYTE PTR [rax],al
	...

000000000040e3f0 <__swc_fn_65555ab2_000047_3d3eceb4>:
  40e3f0:	sub    rsp,0x8
  40e3f4:	mov    r9,r8
  40e3f7:	mov    r10,rdx
  40e3fa:	call   40e350 <__swc_fn_65555ab2_000044_cac7f504>
  40e3ff:	mov    DWORD PTR [r9+0x6c],0x0
  40e407:	movzx  eax,BYTE PTR [r9+0x39]
  40e40c:	lea    rax,[rax+rax*4]
  40e410:	lea    rax,[r10+rax*8+0x28]
  40e415:	mov    rcx,QWORD PTR [rax+0x10]
  40e419:	mov    QWORD PTR [r9+0x50],rcx
  40e41d:	mov    QWORD PTR [r9+0x48],0x0
  40e425:	mov    rcx,QWORD PTR [rax+0x10]
  40e429:	test   rcx,rcx
  40e42c:	je     40e434 <__swc_fn_65555ab2_000047_3d3eceb4+0x44>
  40e42e:	mov    QWORD PTR [rcx+0x48],r9
  40e432:	jmp    40e438 <__swc_fn_65555ab2_000047_3d3eceb4+0x48>
  40e434:	mov    QWORD PTR [rax+0x8],r9
  40e438:	mov    QWORD PTR [rax+0x10],r9
  40e43c:	add    rsp,0x8
  40e440:	ret
	...

000000000040e460 <__swc_fn_65555ab2_000050_e33921d7>:
  40e460:	push   rsi
  40e461:	push   rdi
  40e462:	push   r12
  40e464:	push   r13
  40e466:	push   r14
  40e468:	push   r15
  40e46a:	sub    rsp,0x1f8
  40e471:	mov    esi,r8d
  40e474:	mov    QWORD PTR [rsp+0x1e8],rsi
  40e47c:	mov    rdi,rcx
  40e47f:	mov    r12,rdx
  40e482:	lea    r13,[rsi+rsi*4]
  40e486:	lea    r13,[rdx+r13*8+0x28]
  40e48b:	call   407ca0 <__swc_fn_65555ab2_000048_18a95c9b>
  40e490:	add    DWORD PTR [r12+0x24],0x1
  40e496:	test   BYTE PTR [r12+0x24],0x3f
  40e49c:	jne    40e4a6 <__swc_fn_65555ab2_000050_e33921d7+0x46>
  40e49e:	mov    rcx,rdi
  40e4a1:	call   40ac80 <__swc_fn_65555ab2_000049_781177b4>
  40e4a6:	mov    rax,QWORD PTR [r13+0x8]
  40e4aa:	mov    r14,rax
  40e4ad:	nop    DWORD PTR [rax]
  40e4b0:	test   r14,r14
  40e4b3:	jne    40e4c2 <__swc_fn_65555ab2_000050_e33921d7+0x62>
  40e4b5:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40e4bd:	jmp    40e5c9 <__swc_fn_65555ab2_000050_e33921d7+0x169>
  40e4c2:	mov    r15,QWORD PTR [r14+0x48]
  40e4c6:	mov    rcx,r14
  40e4c9:	call   4073f0 <__swc_fn_65555ab2_000009_2417e911>
  40e4ce:	mov    rax,QWORD PTR [r14]
  40e4d1:	test   rax,rax
  40e4d4:	je     40e4e6 <__swc_fn_65555ab2_000050_e33921d7+0x86>
  40e4d6:	mov    rcx,QWORD PTR [rax]
  40e4d9:	mov    QWORD PTR [r14],rcx
  40e4dc:	add    DWORD PTR [r14+0x28],0x1
  40e4e1:	mov    rsi,rax
  40e4e4:	jmp    40e505 <__swc_fn_65555ab2_000050_e33921d7+0xa5>
  40e4e6:	mov    rax,QWORD PTR [r14+0x18]
  40e4ea:	cmp    QWORD PTR [r14+0x20],rax
  40e4ee:	jae    40e503 <__swc_fn_65555ab2_000050_e33921d7+0xa3>
  40e4f0:	mov    rsi,QWORD PTR [r14+0x20]
  40e4f4:	mov    eax,DWORD PTR [r14+0x2c]
  40e4f8:	add    QWORD PTR [r14+0x20],rax
  40e4fc:	add    DWORD PTR [r14+0x28],0x1
  40e501:	jmp    40e505 <__swc_fn_65555ab2_000050_e33921d7+0xa5>
  40e503:	xor    esi,esi
  40e505:	test   rsi,rsi
  40e508:	jne    40e54d <__swc_fn_65555ab2_000050_e33921d7+0xed>
  40e50a:	mov    rcx,r14
  40e50d:	call   407320 <__swc_fn_65555ab2_000006_12cb36a2>
  40e512:	test   al,al
  40e514:	je     40e54d <__swc_fn_65555ab2_000050_e33921d7+0xed>
  40e516:	mov    rax,QWORD PTR [r14]
  40e519:	test   rax,rax
  40e51c:	je     40e52b <__swc_fn_65555ab2_000050_e33921d7+0xcb>
  40e51e:	mov    rcx,QWORD PTR [rax]
  40e521:	mov    QWORD PTR [r14],rcx
  40e524:	add    DWORD PTR [r14+0x28],0x1
  40e529:	jmp    40e54a <__swc_fn_65555ab2_000050_e33921d7+0xea>
  40e52b:	mov    rax,QWORD PTR [r14+0x18]
  40e52f:	cmp    QWORD PTR [r14+0x20],rax
  40e533:	jae    40e548 <__swc_fn_65555ab2_000050_e33921d7+0xe8>
  40e535:	mov    rax,QWORD PTR [r14+0x20]
  40e539:	mov    ecx,DWORD PTR [r14+0x2c]
  40e53d:	add    QWORD PTR [r14+0x20],rcx
  40e541:	add    DWORD PTR [r14+0x28],0x1
  40e546:	jmp    40e54a <__swc_fn_65555ab2_000050_e33921d7+0xea>
  40e548:	xor    eax,eax
  40e54a:	mov    rsi,rax
  40e54d:	test   rsi,rsi
  40e550:	jne    40e5a3 <__swc_fn_65555ab2_000050_e33921d7+0x143>
  40e552:	mov    rcx,rdi
  40e555:	mov    rdx,r12
  40e558:	mov    r8,r14
  40e55b:	call   40abe0 <__swc_fn_65555ab2_000046_49300800>
  40e560:	test   al,al
  40e562:	jne    40e5a3 <__swc_fn_65555ab2_000050_e33921d7+0x143>
  40e564:	mov    rcx,r14
  40e567:	call   4073f0 <__swc_fn_65555ab2_000009_2417e911>
  40e56c:	mov    rax,QWORD PTR [r14]
  40e56f:	test   rax,rax
  40e572:	je     40e581 <__swc_fn_65555ab2_000050_e33921d7+0x121>
  40e574:	mov    rcx,QWORD PTR [rax]
  40e577:	mov    QWORD PTR [r14],rcx
  40e57a:	add    DWORD PTR [r14+0x28],0x1
  40e57f:	jmp    40e5a0 <__swc_fn_65555ab2_000050_e33921d7+0x140>
  40e581:	mov    rax,QWORD PTR [r14+0x18]
  40e585:	cmp    QWORD PTR [r14+0x20],rax
  40e589:	jae    40e59e <__swc_fn_65555ab2_000050_e33921d7+0x13e>
  40e58b:	mov    rax,QWORD PTR [r14+0x20]
  40e58f:	mov    ecx,DWORD PTR [r14+0x2c]
  40e593:	add    QWORD PTR [r14+0x20],rcx
  40e597:	add    DWORD PTR [r14+0x28],0x1
  40e59c:	jmp    40e5a0 <__swc_fn_65555ab2_000050_e33921d7+0x140>
  40e59e:	xor    eax,eax
  40e5a0:	mov    rsi,rax
  40e5a3:	test   rsi,rsi
  40e5a6:	je     40e5c1 <__swc_fn_65555ab2_000050_e33921d7+0x161>
  40e5a8:	mov    QWORD PTR [r13+0x0],r14
  40e5ac:	mov    rax,rsi
  40e5af:	add    rsp,0x1f8
  40e5b6:	pop    r15
  40e5b8:	pop    r14
  40e5ba:	pop    r13
  40e5bc:	pop    r12
  40e5be:	pop    rdi
  40e5bf:	pop    rsi
  40e5c0:	ret
  40e5c1:	mov    r14,r15
  40e5c4:	jmp    40e4b0 <__swc_fn_65555ab2_000050_e33921d7+0x50>
  40e5c9:	cs nop WORD PTR [rax+rax*1+0x0]
  40e5d3:	cs nop WORD PTR [rax+rax*1+0x0]
  40e5dd:	nop    DWORD PTR [rax]
  40e5e0:	mov    rcx,rdi
  40e5e3:	mov    rdx,r12
  40e5e6:	mov    r8d,esi
  40e5e9:	call   4079e0 <__swc_fn_65555ab2_000045_06cec934>
  40e5ee:	mov    r14,rax
  40e5f1:	test   rax,rax
  40e5f4:	jne    40e60a <__swc_fn_65555ab2_000050_e33921d7+0x1aa>
  40e5f6:	xor    eax,eax
  40e5f8:	add    rsp,0x1f8
  40e5ff:	pop    r15
  40e601:	pop    r14
  40e603:	pop    r13
  40e605:	pop    r12
  40e607:	pop    rdi
  40e608:	pop    rsi
  40e609:	ret
  40e60a:	mov    QWORD PTR [r13+0x0],r14
  40e60e:	mov    rax,QWORD PTR [r14]
  40e611:	test   rax,rax
  40e614:	je     40e626 <__swc_fn_65555ab2_000050_e33921d7+0x1c6>
  40e616:	mov    rcx,QWORD PTR [rax]
  40e619:	mov    QWORD PTR [r14],rcx
  40e61c:	add    DWORD PTR [r14+0x28],0x1
  40e621:	mov    r15,rax
  40e624:	jmp    40e646 <__swc_fn_65555ab2_000050_e33921d7+0x1e6>
  40e626:	mov    rax,QWORD PTR [r14+0x18]
  40e62a:	cmp    QWORD PTR [r14+0x20],rax
  40e62e:	jae    40e643 <__swc_fn_65555ab2_000050_e33921d7+0x1e3>
  40e630:	mov    r15,QWORD PTR [r14+0x20]
  40e634:	mov    eax,DWORD PTR [r14+0x2c]
  40e638:	add    QWORD PTR [r14+0x20],rax
  40e63c:	add    DWORD PTR [r14+0x28],0x1
  40e641:	jmp    40e646 <__swc_fn_65555ab2_000050_e33921d7+0x1e6>
  40e643:	xor    r15d,r15d
  40e646:	test   r15,r15
  40e649:	jne    40e68e <__swc_fn_65555ab2_000050_e33921d7+0x22e>
  40e64b:	mov    rcx,r14
  40e64e:	call   407320 <__swc_fn_65555ab2_000006_12cb36a2>
  40e653:	test   al,al
  40e655:	je     40e68e <__swc_fn_65555ab2_000050_e33921d7+0x22e>
  40e657:	mov    rax,QWORD PTR [r14]
  40e65a:	test   rax,rax
  40e65d:	je     40e66c <__swc_fn_65555ab2_000050_e33921d7+0x20c>
  40e65f:	mov    rcx,QWORD PTR [rax]
  40e662:	mov    QWORD PTR [r14],rcx
  40e665:	add    DWORD PTR [r14+0x28],0x1
  40e66a:	jmp    40e68b <__swc_fn_65555ab2_000050_e33921d7+0x22b>
  40e66c:	mov    rax,QWORD PTR [r14+0x18]
  40e670:	cmp    QWORD PTR [r14+0x20],rax
  40e674:	jae    40e689 <__swc_fn_65555ab2_000050_e33921d7+0x229>
  40e676:	mov    rax,QWORD PTR [r14+0x20]
  40e67a:	mov    ecx,DWORD PTR [r14+0x2c]
  40e67e:	add    QWORD PTR [r14+0x20],rcx
  40e682:	add    DWORD PTR [r14+0x28],0x1
  40e687:	jmp    40e68b <__swc_fn_65555ab2_000050_e33921d7+0x22b>
  40e689:	xor    eax,eax
  40e68b:	mov    r15,rax
  40e68e:	test   r15,r15
  40e691:	je     40e5e0 <__swc_fn_65555ab2_000050_e33921d7+0x180>
  40e697:	mov    rax,r15
  40e69a:	add    rsp,0x1f8
  40e6a1:	pop    r15
  40e6a3:	pop    r14
  40e6a5:	pop    r13
  40e6a7:	pop    r12
  40e6a9:	pop    rdi
  40e6aa:	pop    rsi
  40e6ab:	ret
  40e6ac:	add    BYTE PTR [rax],al
	...

000000000040e6b0 <__swc_fn_65555ab2_000053_a8a124d6>:
  40e6b0:	push   rsi
  40e6b1:	push   rdi
  40e6b2:	push   r12
  40e6b4:	mov    rsi,rdx
  40e6b7:	mov    rax,rdx
  40e6ba:	shr    rax,0xc
  40e6be:	movabs rdx,0x9e3779b97f4a7c15
  40e6c8:	imul   rax,rdx
  40e6cc:	shr    rax,0x20
  40e6d0:	lea    rax,[rax*8+0x0]
  40e6d8:	shr    rax,0x20
  40e6dc:	lea    rax,[rax*8+0x0]
  40e6e4:	lea    rax,[rcx+rax*8+0x40]
  40e6e9:	xor    edx,edx
  40e6eb:	test   dl,dl
  40e6ed:	lea    rdi,[rcx+0x8]
  40e6f1:	cmove  rdi,rax
  40e6f5:	xor    edx,edx
  40e6f7:	test   dl,dl
  40e6f9:	lea    r12,[rcx+0x30]
  40e6fd:	lea    rax,[rax+0x8]
  40e701:	cmove  r12,rax
  40e705:	mov    rcx,rdi
  40e708:	call   4098a0 <__swc_fn_65555ab2_000135_1fec60ac>
  40e70d:	mov    QWORD PTR [rsi+0x30],0x0
  40e715:	mov    rax,QWORD PTR [r12]
  40e719:	mov    QWORD PTR [rsi+0x38],rax
  40e71d:	test   rax,rax
  40e720:	je     40e72a <__swc_fn_65555ab2_000053_a8a124d6+0x7a>
  40e722:	mov    rax,QWORD PTR [rsi+0x38]
  40e726:	mov    QWORD PTR [rax+0x30],rsi
  40e72a:	mov    QWORD PTR [r12],rsi
  40e72e:	mov    rcx,rdi
  40e731:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  40e736:	pop    r12
  40e738:	pop    rdi
  40e739:	pop    rsi
  40e73a:	ret
  40e73b:	add    BYTE PTR [rax],al
  40e73d:	add    BYTE PTR [rax],al
	...

000000000040e740 <__swc_fn_65555ab2_000056_cfedf3f4>:
  40e740:	lea    rax,[rdx+rdx*4]
  40e744:	lea    rax,[rcx+rax*8+0x268]
  40e74c:	mov    rdx,QWORD PTR [rax+0x10]
  40e750:	sub    QWORD PTR [rcx+0x2a68],rdx
  40e757:	sub    QWORD PTR [rcx+0x2a70],0x1
  40e75f:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40e766:	lea    rdx,[rdx+rdx*4]
  40e76a:	lea    rdx,[rcx+rdx*8+0x268]
  40e772:	vmovups xmm0,XMMWORD PTR [rdx]
  40e776:	vmovups XMMWORD PTR [rax],xmm0
  40e77a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40e77f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e784:	mov    rcx,QWORD PTR [rdx+0x20]
  40e788:	mov    QWORD PTR [rax+0x20],rcx
  40e78c:	ret
  40e78d:	add    BYTE PTR [rax],al
	...

000000000040e790 <__swc_fn_65555ab2_000059_c8e1ff6b>:
  40e790:	push   rsi
  40e791:	push   rdi
  40e792:	push   r12
  40e794:	push   r13
  40e796:	sub    rsp,0x8
  40e79a:	mov    rsi,r8
  40e79d:	mov    rdi,rcx
  40e7a0:	mov    r12,rdx
  40e7a3:	xor    r13d,r13d
  40e7a6:	cs nop WORD PTR [rax+rax*1+0x0]
  40e7b0:	mov    eax,DWORD PTR [r12+0x730]
  40e7b8:	cmp    r13d,eax
  40e7bb:	jae    40e821 <__swc_fn_65555ab2_000059_c8e1ff6b+0x91>
  40e7bd:	lea    rax,[r13+r13*4+0x0]
  40e7c2:	lea    rax,[r12+rax*8+0x738]
  40e7ca:	mov    rdx,QWORD PTR [rax]
  40e7cd:	mov    r8,QWORD PTR [rax+0x8]
  40e7d1:	mov    r9,QWORD PTR [rax+0x10]
  40e7d5:	cmp    QWORD PTR [rax+0x20],rsi
  40e7d9:	jb     40e7e0 <__swc_fn_65555ab2_000059_c8e1ff6b+0x50>
  40e7db:	inc    r13d
  40e7de:	jmp    40e7b0 <__swc_fn_65555ab2_000059_c8e1ff6b+0x20>
  40e7e0:	sub    DWORD PTR [r12+0x730],0x1
  40e7e9:	mov    ecx,DWORD PTR [r12+0x730]
  40e7f1:	lea    rcx,[rcx+rcx*4]
  40e7f5:	lea    rcx,[r12+rcx*8+0x738]
  40e7fd:	vmovups xmm0,XMMWORD PTR [rcx]
  40e801:	vmovups XMMWORD PTR [rax],xmm0
  40e805:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40e80a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e80f:	mov    rcx,QWORD PTR [rcx+0x20]
  40e813:	mov    QWORD PTR [rax+0x20],rcx
  40e817:	mov    rcx,rdi
  40e81a:	call   407750 <__swc_fn_65555ab2_000039_05a50673>
  40e81f:	jmp    40e7b0 <__swc_fn_65555ab2_000059_c8e1ff6b+0x20>
  40e821:	add    rsp,0x8
  40e825:	pop    r13
  40e827:	pop    r12
  40e829:	pop    rdi
  40e82a:	pop    rsi
  40e82b:	ret
  40e82c:	add    BYTE PTR [rax],al
	...

000000000040e830 <__swc_fn_65555ab2_000062_baa48dba>:
  40e830:	push   rsi
  40e831:	push   rdi
  40e832:	push   r12
  40e834:	push   r13
  40e836:	push   r14
  40e838:	mov    rsi,rcx
  40e83b:	mov    rdi,rdx
  40e83e:	mov    r12,QWORD PTR [rdi]
  40e841:	mov    r13,QWORD PTR [rdi+0x18]
  40e845:	mov    rax,r12
  40e848:	add    rax,QWORD PTR [rdi+0x8]
  40e84c:	sub    rax,r13
  40e84f:	cmp    r8,rax
  40e852:	jbe    40e85d <__swc_fn_65555ab2_000062_baa48dba+0x2d>
  40e854:	pop    r14
  40e856:	pop    r13
  40e858:	pop    r12
  40e85a:	pop    rdi
  40e85b:	pop    rsi
  40e85c:	ret
  40e85d:	lea    rax,[r13+r8*1+0x0]
  40e862:	sub    rax,r12
  40e865:	mov    ecx,0x1000
  40e86a:	test   ecx,ecx
  40e86c:	mov    edx,0x8
  40e871:	cmove  ecx,edx
  40e874:	dec    rcx
  40e877:	mov    rdx,0xffffffffffffffff
  40e87e:	sub    rdx,rcx
  40e881:	cmp    rax,rdx
  40e884:	jbe    40e88b <__swc_fn_65555ab2_000062_baa48dba+0x5b>
  40e886:	xor    r14d,r14d
  40e889:	jmp    40e896 <__swc_fn_65555ab2_000062_baa48dba+0x66>
  40e88b:	add    rax,rcx
  40e88e:	andn   rax,rcx,rax
  40e893:	mov    r14,rax
  40e896:	mov    rax,QWORD PTR [rdi+0x10]
  40e89a:	cmp    r14,rax
  40e89d:	ja     40e8a8 <__swc_fn_65555ab2_000062_baa48dba+0x78>
  40e89f:	pop    r14
  40e8a1:	pop    r13
  40e8a3:	pop    r12
  40e8a5:	pop    rdi
  40e8a6:	pop    rsi
  40e8a7:	ret
  40e8a8:	mov    rax,r12
  40e8ab:	add    rax,QWORD PTR [rdi+0x10]
  40e8af:	mov    rdx,r14
  40e8b2:	sub    rdx,QWORD PTR [rdi+0x10]
  40e8b6:	mov    rcx,rax
  40e8b9:	call   4072a0 <__swc_fn_65555ab2_000003_644dadb7>
  40e8be:	test   al,al
  40e8c0:	jne    40e8cb <__swc_fn_65555ab2_000062_baa48dba+0x9b>
  40e8c2:	pop    r14
  40e8c4:	pop    r13
  40e8c6:	pop    r12
  40e8c8:	pop    rdi
  40e8c9:	pop    rsi
  40e8ca:	ret
  40e8cb:	add    r12,r14
  40e8ce:	sub    r12,r13
  40e8d1:	mov    rcx,r12
  40e8d4:	sub    rcx,QWORD PTR [rdi+0x28]
  40e8d8:	mov    rdx,QWORD PTR [rsi+0x250]
  40e8df:	nop
  40e8e0:	lea    r8,[rdx+rcx*1]
  40e8e4:	mov    rax,rdx
  40e8e7:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40e8f0:	cmp    rax,rdx
  40e8f3:	je     40e8fa <__swc_fn_65555ab2_000062_baa48dba+0xca>
  40e8f5:	mov    rdx,rax
  40e8f8:	jmp    40e8e0 <__swc_fn_65555ab2_000062_baa48dba+0xb0>
  40e8fa:	mov    QWORD PTR [rdi+0x10],r14
  40e8fe:	mov    QWORD PTR [rdi+0x28],r12
  40e902:	pop    r14
  40e904:	pop    r13
  40e906:	pop    r12
  40e908:	pop    rdi
  40e909:	pop    rsi
  40e90a:	ret
  40e90b:	add    BYTE PTR [rax],al
  40e90d:	add    BYTE PTR [rax],al
	...

000000000040e910 <__swc_fn_65555ab2_000065_cd9dd53e>:
  40e910:	push   rbx
  40e911:	push   rsi
  40e912:	push   rdi
  40e913:	push   r12
  40e915:	push   r13
  40e917:	sub    rsp,0xe0
  40e91e:	mov    rbx,rdx
  40e921:	mov    rsi,rcx
  40e924:	cmp    DWORD PTR [rbx+0x58],0x0
  40e928:	je     40e94c <__swc_fn_65555ab2_000065_cd9dd53e+0x3c>
  40e92a:	mov    eax,DWORD PTR [rbx+0x58]
  40e92d:	sub    eax,0x1
  40e930:	test   DWORD PTR [rbx+0x58],eax
  40e933:	je     40e94c <__swc_fn_65555ab2_000065_cd9dd53e+0x3c>
  40e935:	mov    QWORD PTR [rbx+0x40],0x0
  40e93d:	add    rsp,0xe0
  40e944:	pop    r13
  40e946:	pop    r12
  40e948:	pop    rdi
  40e949:	pop    rsi
  40e94a:	pop    rbx
  40e94b:	ret
  40e94c:	mov    rax,QWORD PTR [rbx+0x40]
  40e950:	test   rax,rax
  40e953:	jne    40e96f <__swc_fn_65555ab2_000065_cd9dd53e+0x5f>
  40e955:	mov    rcx,rsi
  40e958:	mov    rdx,rbx
  40e95b:	call   40b890 <__swc_fn_65555ab2_000064_6905bec4>
  40e960:	add    rsp,0xe0
  40e967:	pop    r13
  40e969:	pop    r12
  40e96b:	pop    rdi
  40e96c:	pop    rsi
  40e96d:	pop    rbx
  40e96e:	ret
  40e96f:	cmp    QWORD PTR [rbx+0x48],0x0
  40e974:	jne    40e990 <__swc_fn_65555ab2_000065_cd9dd53e+0x80>
  40e976:	mov    rcx,rsi
  40e979:	mov    rdx,rbx
  40e97c:	call   407f90 <__swc_fn_65555ab2_000066_77c6e829>
  40e981:	add    rsp,0xe0
  40e988:	pop    r13
  40e98a:	pop    r12
  40e98c:	pop    rdi
  40e98d:	pop    rsi
  40e98e:	pop    rbx
  40e98f:	ret
  40e990:	mov    rdi,QWORD PTR [rbx+0x40]
  40e994:	lea    rax,[rip+0x156d5]        # 424070 <__swc_bss_base_65555ab2+0x30>
  40e99b:	mov    rcx,rdi
  40e99e:	sub    rcx,QWORD PTR [rax+0x8]
  40e9a2:	mov    rax,QWORD PTR [rip+0x156d7]        # 424080 <__swc_bss_base_65555ab2+0x40>
  40e9a9:	cmp    rcx,rax
  40e9ac:	jae    40e9d8 <__swc_fn_65555ab2_000065_cd9dd53e+0xc8>
  40e9ae:	mov    rax,rdi
  40e9b1:	and    rax,0xffffffffffc00000
  40e9b8:	mov    rcx,rdi
  40e9bb:	shr    rcx,0x10
  40e9bf:	and    ecx,0x3f
  40e9c2:	mov    edx,DWORD PTR [rax+0x28]
  40e9c5:	shrx   ecx,ecx,edx
  40e9ca:	shl    rcx,0x4
  40e9ce:	lea    r12,[rax+rcx*8+0x80]
  40e9d6:	jmp    40e9e3 <__swc_fn_65555ab2_000065_cd9dd53e+0xd3>
  40e9d8:	mov    rcx,rdi
  40e9db:	call   40a910 <__swc_fn_65555ab2_000022_77c2d682>
  40e9e0:	mov    r12,rax
  40e9e3:	test   r12,r12
  40e9e6:	je     40e9f5 <__swc_fn_65555ab2_000065_cd9dd53e+0xe5>
  40e9e8:	mov    eax,DWORD PTR [r12+0x2c]
  40e9ed:	mov    r9d,eax
  40e9f0:	mov    r13,rax
  40e9f3:	jmp    40ea74 <__swc_fn_65555ab2_000065_cd9dd53e+0x164>
  40e9f5:	mov    rcx,rsi
  40e9f8:	mov    rdx,rdi
  40e9fb:	call   40af20 <__swc_fn_65555ab2_000052_26c6c1c4>
  40ea00:	mov    rcx,QWORD PTR [rax+0x28]
  40ea04:	mov    r9,rcx
  40ea07:	mov    rdx,QWORD PTR [rax+0x20]
  40ea0b:	mov    r13,rdx
  40ea0e:	cmp    QWORD PTR [rbx+0x48],rcx
  40ea12:	jbe    40ea4b <__swc_fn_65555ab2_000065_cd9dd53e+0x13b>
  40ea14:	mov    ecx,DWORD PTR [rax+0x48]
  40ea17:	cmp    DWORD PTR [rbx+0x58],ecx
  40ea1a:	ja     40ea4b <__swc_fn_65555ab2_000065_cd9dd53e+0x13b>
  40ea1c:	mov    rcx,rsi
  40ea1f:	mov    rdx,rax
  40ea22:	mov    r8,QWORD PTR [rbx+0x48]
  40ea26:	mov    QWORD PTR [rsp+0xc8],r9
  40ea2e:	mov    QWORD PTR [rsp+0xd0],rax
  40ea36:	call   40e830 <__swc_fn_65555ab2_000062_baa48dba>
  40ea3b:	mov    r9,QWORD PTR [rsp+0xc8]
  40ea43:	mov    rax,QWORD PTR [rsp+0xd0]
  40ea4b:	mov    rcx,QWORD PTR [rax+0x28]
  40ea4f:	cmp    QWORD PTR [rbx+0x48],rcx
  40ea53:	ja     40ea74 <__swc_fn_65555ab2_000065_cd9dd53e+0x164>
  40ea55:	mov    ecx,DWORD PTR [rax+0x48]
  40ea58:	cmp    DWORD PTR [rbx+0x58],ecx
  40ea5b:	ja     40ea74 <__swc_fn_65555ab2_000065_cd9dd53e+0x164>
  40ea5d:	mov    rcx,QWORD PTR [rbx+0x48]
  40ea61:	mov    QWORD PTR [rax+0x20],rcx
  40ea65:	add    rsp,0xe0
  40ea6c:	pop    r13
  40ea6e:	pop    r12
  40ea70:	pop    rdi
  40ea71:	pop    rsi
  40ea72:	pop    rbx
  40ea73:	ret
  40ea74:	test   r12,r12
  40ea77:	je     40eaa9 <__swc_fn_65555ab2_000065_cd9dd53e+0x199>
  40ea79:	cmp    QWORD PTR [rbx+0x48],r9
  40ea7d:	ja     40eaa9 <__swc_fn_65555ab2_000065_cd9dd53e+0x199>
  40ea7f:	cmp    DWORD PTR [rbx+0x58],0x40
  40ea83:	ja     40eaa9 <__swc_fn_65555ab2_000065_cd9dd53e+0x199>
  40ea85:	cmp    DWORD PTR [rbx+0x58],0x0
  40ea89:	je     40ea96 <__swc_fn_65555ab2_000065_cd9dd53e+0x186>
  40ea8b:	mov    ecx,DWORD PTR [rbx+0x58]
  40ea8e:	dec    rcx
  40ea91:	test   rdi,rcx
  40ea94:	jne    40eaa9 <__swc_fn_65555ab2_000065_cd9dd53e+0x199>
  40ea96:	mov    QWORD PTR [rbx+0x40],rdi
  40ea9a:	add    rsp,0xe0
  40eaa1:	pop    r13
  40eaa3:	pop    r12
  40eaa5:	pop    rdi
  40eaa6:	pop    rsi
  40eaa7:	pop    rbx
  40eaa8:	ret
  40eaa9:	vmovups xmm0,XMMWORD PTR [rbx]
  40eaad:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40eab3:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40eab8:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40eabe:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40eac3:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40eac9:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40eace:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40ead4:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40ead9:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40eadf:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40eae4:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40eaea:	mov    QWORD PTR [rsp+0x48],0x0
  40eaf3:	mov    rcx,rsi
  40eaf6:	lea    rdx,[rsp+0x8]
  40eafb:	call   40b890 <__swc_fn_65555ab2_000064_6905bec4>
  40eb00:	mov    rax,QWORD PTR [rsp+0x48]
  40eb05:	test   rax,rax
  40eb08:	jne    40eb21 <__swc_fn_65555ab2_000065_cd9dd53e+0x211>
  40eb0a:	mov    QWORD PTR [rbx+0x40],0x0
  40eb12:	add    rsp,0xe0
  40eb19:	pop    r13
  40eb1b:	pop    r12
  40eb1d:	pop    rdi
  40eb1e:	pop    rsi
  40eb1f:	pop    rbx
  40eb20:	ret
  40eb21:	mov    rax,QWORD PTR [rbx+0x48]
  40eb25:	cmp    r13,rax
  40eb28:	cmovbe rax,r13
  40eb2c:	mov    rcx,QWORD PTR [rsp+0x48]
  40eb31:	mov    rdx,rdi
  40eb34:	mov    r8,rax
  40eb37:	call   4090e0 <__swc_fn_65555ab2_000105_b7aef7c0>
  40eb3c:	vmovups xmm0,XMMWORD PTR [rbx]
  40eb40:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40eb46:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40eb4b:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40eb51:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40eb56:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40eb5f:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40eb64:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40eb6d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40eb72:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40eb7b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40eb80:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40eb89:	mov    QWORD PTR [rsp+0xa8],rdi
  40eb91:	mov    rcx,rsi
  40eb94:	lea    rdx,[rsp+0x68]
  40eb99:	call   407f90 <__swc_fn_65555ab2_000066_77c6e829>
  40eb9e:	mov    rax,QWORD PTR [rsp+0x48]
  40eba3:	mov    QWORD PTR [rbx+0x40],rax
  40eba7:	add    rsp,0xe0
  40ebae:	pop    r13
  40ebb0:	pop    r12
  40ebb2:	pop    rdi
  40ebb3:	pop    rsi
  40ebb4:	pop    rbx
  40ebb5:	ret
	...

000000000040ebc0 <__swc_fn_65555ab2_000068_557d6092>:
  40ebc0:	push   r12
  40ebc2:	push   rdi
  40ebc3:	push   rsi
  40ebc4:	push   r13
  40ebc6:	push   r14
  40ebc8:	sub    rsp,0x190
  40ebcf:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40ebd8:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40ebe1:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40ebea:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40ebf3:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40ebfc:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40ec05:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40ec0e:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40ec17:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40ec20:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40ec29:	mov    r12,rcx
  40ec2c:	lea    rax,[rip+0x133cd]        # 422000 <__swc_data_base_65555ab2>
  40ec33:	mov    rax,QWORD PTR [rax]
  40ec36:	cmp    rax,0xffffffffffffffff
  40ec3a:	je     40ec49 <__swc_fn_65555ab2_000068_557d6092+0x89>
  40ec3c:	mov    eax,eax
  40ec3e:	mov    edi,eax
  40ec40:	xor    eax,eax
  40ec42:	call   407000 <pthread_getspecific@plt>
  40ec47:	jmp    40ec4b <__swc_fn_65555ab2_000068_557d6092+0x8b>
  40ec49:	xor    eax,eax
  40ec4b:	test   rax,rax
  40ec4e:	jne    40ec5d <__swc_fn_65555ab2_000068_557d6092+0x9d>
  40ec50:	call   40a9e0 <__swc_fn_65555ab2_000031_ed8d61a9>
  40ec55:	mov    rcx,rax
  40ec58:	call   410380 <__swc_fn_65555ab2_000128_9c45d2d7>
  40ec5d:	test   rax,rax
  40ec60:	je     40ec86 <__swc_fn_65555ab2_000068_557d6092+0xc6>
  40ec62:	cmp    QWORD PTR [rax],r12
  40ec65:	jne    40ec86 <__swc_fn_65555ab2_000068_557d6092+0xc6>
  40ec67:	xor    ecx,ecx
  40ec69:	mov    QWORD PTR [rsp+0xc8],rax
  40ec71:	call   407720 <__swc_fn_65555ab2_000033_7d7574b6>
  40ec76:	mov    rdx,QWORD PTR [rsp+0xc8]
  40ec7e:	mov    rcx,r12
  40ec81:	call   407840 <__swc_fn_65555ab2_000042_70d5ab54>
  40ec86:	lea    rsi,[r12+0x10]
  40ec8b:	mov    rcx,rsi
  40ec8e:	call   4098a0 <__swc_fn_65555ab2_000135_1fec60ac>
  40ec93:	mov    rdi,QWORD PTR [r12+0x20]
  40ec98:	test   rdi,rdi
  40ec9b:	je     40ecde <__swc_fn_65555ab2_000068_557d6092+0x11e>
  40ec9d:	nop    DWORD PTR [rax]
  40eca0:	mov    rcx,r12
  40eca3:	mov    rdx,rdi
  40eca6:	call   40aba0 <__swc_fn_65555ab2_000043_3755033a>
  40ecab:	mov    rcx,r12
  40ecae:	mov    rdx,rdi
  40ecb1:	mov    r8,0xffffffffffffffff
  40ecb8:	call   40e790 <__swc_fn_65555ab2_000059_c8e1ff6b>
  40ecbd:	mov    rcx,r12
  40ecc0:	mov    rdx,rdi
  40ecc3:	mov    r8d,0x9b8
  40ecc9:	mov    r9d,0x9b8
  40eccf:	call   407750 <__swc_fn_65555ab2_000039_05a50673>
  40ecd4:	mov    rdi,QWORD PTR [r12+0x20]
  40ecd9:	test   rdi,rdi
  40ecdc:	jne    40eca0 <__swc_fn_65555ab2_000068_557d6092+0xe0>
  40ecde:	xor    eax,eax
  40ece0:	xchg   QWORD PTR [r12+0x2a80],rax
  40ece8:	test   rax,rax
  40eceb:	je     40ed11 <__swc_fn_65555ab2_000068_557d6092+0x151>
  40eced:	cs nop WORD PTR [rax+rax*1+0x0]
  40ecf7:	nop    WORD PTR [rax+rax*1+0x0]
  40ed00:	mov    rcx,rax
  40ed03:	mov    rax,QWORD PTR [rax+0x78]
  40ed07:	xor    edx,edx
  40ed09:	xchg   DWORD PTR [rcx+0x70],edx
  40ed0c:	test   rax,rax
  40ed0f:	jne    40ed00 <__swc_fn_65555ab2_000068_557d6092+0x140>
  40ed11:	mov    rax,QWORD PTR [r12+0x18]
  40ed16:	mov    rdi,rax
  40ed19:	test   rdi,rdi
  40ed1c:	je     40edb1 <__swc_fn_65555ab2_000068_557d6092+0x1f1>
  40ed22:	cs nop WORD PTR [rax+rax*1+0x0]
  40ed2c:	nop    DWORD PTR [rax+0x0]
  40ed30:	mov    rax,QWORD PTR [rdi+0x10]
  40ed34:	mov    r8d,DWORD PTR [rdi+0x2c]
  40ed38:	xor    r9d,r9d
  40ed3b:	test   r8,r8
  40ed3e:	jbe    40ed9d <__swc_fn_65555ab2_000068_557d6092+0x1dd>
  40ed40:	mov    ecx,r9d
  40ed43:	shl    rcx,0x4
  40ed47:	lea    rdx,[rdi+rcx*8+0x80]
  40ed4f:	cmp    BYTE PTR [rdx+0x3b],0x0
  40ed53:	je     40ed94 <__swc_fn_65555ab2_000068_557d6092+0x1d4>
  40ed55:	mov    DWORD PTR [rdx+0x28],0x0
  40ed5c:	mov    rcx,rdi
  40ed5f:	mov    QWORD PTR [rsp+0xd0],rax
  40ed67:	mov    QWORD PTR [rsp+0xd8],r8
  40ed6f:	mov    QWORD PTR [rsp+0xe0],r9
  40ed77:	call   40dec0 <__swc_fn_65555ab2_000014_1acdaf22>
  40ed7c:	mov    rax,QWORD PTR [rsp+0xd0]
  40ed84:	mov    r8,QWORD PTR [rsp+0xd8]
  40ed8c:	mov    r9,QWORD PTR [rsp+0xe0]
  40ed94:	add    r9,0x1
  40ed98:	cmp    r9,r8
  40ed9b:	jb     40ed40 <__swc_fn_65555ab2_000068_557d6092+0x180>
  40ed9d:	mov    rcx,rdi
  40eda0:	mov    rdi,rax
  40eda3:	call   407630 <__swc_fn_65555ab2_000021_fe13ecad>
  40eda8:	test   rdi,rdi
  40edab:	jne    40ed30 <__swc_fn_65555ab2_000068_557d6092+0x170>
  40edb1:	mov    QWORD PTR [r12+0x18],0x0
  40edba:	mov    QWORD PTR [r12+0x28],0x0
  40edc3:	mov    rcx,rsi
  40edc6:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  40edcb:	mov    esi,0x8
  40edd0:	xor    edi,edi
  40edd2:	test   rsi,rsi
  40edd5:	je     40ee32 <__swc_fn_65555ab2_000068_557d6092+0x272>
  40eddb:	nop    DWORD PTR [rax+rax*1+0x0]
  40ede0:	lea    r13,[rdi*8+0x0]
  40ede8:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40eded:	test   r14,r14
  40edf0:	je     40ee28 <__swc_fn_65555ab2_000068_557d6092+0x268>
  40edf2:	cs nop WORD PTR [rax+rax*1+0x0]
  40edfc:	nop    DWORD PTR [rax+0x0]
  40ee00:	mov    rcx,r12
  40ee03:	mov    rdx,r14
  40ee06:	call   407df0 <__swc_fn_65555ab2_000054_1dfec8f6>
  40ee0b:	mov    rcx,r12
  40ee0e:	mov    rdx,QWORD PTR [r14]
  40ee11:	mov    r8,QWORD PTR [r14+0x8]
  40ee15:	mov    r9,QWORD PTR [r14+0x10]
  40ee19:	call   407750 <__swc_fn_65555ab2_000039_05a50673>
  40ee1e:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40ee23:	test   r14,r14
  40ee26:	jne    40ee00 <__swc_fn_65555ab2_000068_557d6092+0x240>
  40ee28:	add    rdi,0x1
  40ee2c:	sub    rsi,0x1
  40ee30:	jne    40ede0 <__swc_fn_65555ab2_000068_557d6092+0x220>
  40ee32:	mov    rcx,r12
  40ee35:	call   407ec0 <__swc_fn_65555ab2_000060_9d59636e>
  40ee3a:	lea    rcx,[r12+0x250]
  40ee42:	mov    rdx,QWORD PTR [rcx]
  40ee45:	mov    r8,QWORD PTR [r12+0x250]
  40ee4d:	nop    DWORD PTR [rax]
  40ee50:	mov    r9,r8
  40ee53:	sub    r9,rdx
  40ee56:	mov    rax,r8
  40ee59:	lock cmpxchg QWORD PTR [rcx],r9
  40ee5e:	cmp    rax,r8
  40ee61:	je     40ee68 <__swc_fn_65555ab2_000068_557d6092+0x2a8>
  40ee63:	mov    r8,rax
  40ee66:	jmp    40ee50 <__swc_fn_65555ab2_000068_557d6092+0x290>
  40ee68:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40ee71:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40ee7a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40ee83:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40ee8c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40ee95:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40ee9e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40eea7:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40eeb0:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40eeb9:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40eec2:	add    rsp,0x190
  40eec9:	pop    r14
  40eecb:	pop    r13
  40eecd:	pop    rsi
  40eece:	pop    rdi
  40eecf:	pop    r12
  40eed1:	ret
	...

000000000040eee0 <__swc_fn_65555ab2_000071_7e144e9b>:
  40eee0:	sub    rsp,0x8
  40eee4:	mov    QWORD PTR [rdx+0x40],0x0
  40eeec:	call   40b890 <__swc_fn_65555ab2_000064_6905bec4>
  40eef1:	add    rsp,0x8
  40eef5:	ret
	...

000000000040ef00 <__swc_fn_65555ab2_000074_9eaf4878>:
  40ef00:	sub    rsp,0x8
  40ef04:	call   407f90 <__swc_fn_65555ab2_000066_77c6e829>
  40ef09:	add    rsp,0x8
  40ef0d:	ret
	...

000000000040ef10 <__swc_fn_65555ab2_000077_e793b5e1>:
  40ef10:	push   rbx
  40ef11:	push   rsi
  40ef12:	push   rdi
  40ef13:	push   r12
  40ef15:	push   r13
  40ef17:	push   r14
  40ef19:	push   r15
  40ef1b:	sub    rsp,0x20
  40ef1f:	mov    rbx,r11
  40ef22:	mov    rsi,rcx
  40ef25:	mov    rdi,rdx
  40ef28:	mov    r12,r8
  40ef2b:	mov    r13,r9
  40ef2e:	mov    r14,r10
  40ef31:	mov    rcx,QWORD PTR [rip+0x17e08]        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  40ef38:	test   rcx,rcx
  40ef3b:	jne    40ef4d <__swc_fn_65555ab2_000077_e793b5e1+0x3d>
  40ef3d:	call   40a1a0 <__swc_fn_65555ab2_000165_e09accff>
  40ef42:	lea    rcx,[rax+0x1]
  40ef46:	mov    QWORD PTR [rip+0x17df3],rcx        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  40ef4d:	dec    rcx
  40ef50:	call   411e00 <__swc_fn_65555ab2_000167_3130645d>
  40ef55:	mov    r15,rax
  40ef58:	lea    r11,[rip+0x152e1]        # 424240 <__swc_bss_base_65555ab2+0x200>
  40ef5f:	mov    rcx,r11
  40ef62:	call   407740 <__swc_fn_65555ab2_000036_62160bb3>
  40ef67:	test   al,al
  40ef69:	jne    40ef7a <__swc_fn_65555ab2_000077_e793b5e1+0x6a>
  40ef6b:	mov    rcx,r11
  40ef6e:	call   40aa40 <__swc_fn_65555ab2_000034_c72914a2>
  40ef73:	lea    r11,[rip+0x152c6]        # 424240 <__swc_bss_base_65555ab2+0x200>
  40ef7a:	mov    rcx,r11
  40ef7d:	mov    rdx,rsi
  40ef80:	mov    r8,rdi
  40ef83:	mov    r9,r12
  40ef86:	mov    r10,r13
  40ef89:	mov    rsi,r11
  40ef8c:	mov    r11,r14
  40ef8f:	call   40e230 <__swc_fn_65555ab2_000035_6105596e>
  40ef94:	test   bl,bl
  40ef96:	je     40efbd <__swc_fn_65555ab2_000077_e793b5e1+0xad>
  40ef98:	mov    QWORD PTR [rsp+0x8],rsi
  40ef9d:	lea    rax,[rip+0x41ac]        # 413150 <__swc_rdata_base_65555ab2+0x40>
  40efa4:	mov    QWORD PTR [rsp+0x10],rax
  40efa9:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40efaf:	vmovups XMMWORD PTR [r15],xmm0
  40efb4:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40efbd:	mov    rax,rsi
  40efc0:	add    rsp,0x20
  40efc4:	pop    r15
  40efc6:	pop    r14
  40efc8:	pop    r13
  40efca:	pop    r12
  40efcc:	pop    rdi
  40efcd:	pop    rsi
  40efce:	pop    rbx
  40efcf:	ret

000000000040efd0 <__swc_fn_65555ab2_000080_851c599a>:
  40efd0:	sub    rsp,0x8
  40efd4:	mov    rax,rcx
  40efd7:	test   rcx,rcx
  40efda:	jne    40efe1 <__swc_fn_65555ab2_000080_851c599a+0x11>
  40efdc:	add    rsp,0x8
  40efe0:	ret
  40efe1:	lea    rcx,[rax-0x10]
  40efe5:	mov    rax,QWORD PTR [rax-0x10]
  40efe9:	mov    rdx,rax
  40efec:	call   410030 <__swc_fn_65555ab2_000113_25e345b1>
  40eff1:	add    rsp,0x8
  40eff5:	ret
	...

000000000040f000 <__swc_fn_65555ab2_000083_fb84e43e>:
  40f000:	sub    rsp,0x8
  40f004:	xor    r11d,r11d
  40f007:	call   408250 <__swc_fn_65555ab2_000084_746bf146>
  40f00c:	add    rsp,0x8
  40f010:	ret
	...

000000000040f020 <__swc_fn_65555ab2_000086_ac8c6565>:
  40f020:	push   rsi
  40f021:	push   rdi
  40f022:	push   r12
  40f024:	push   r13
  40f026:	push   r14
  40f028:	push   r15
  40f02a:	sub    rsp,0x68
  40f02e:	mov    rsi,r9
  40f031:	mov    rdi,rcx
  40f034:	mov    r12,rdx
  40f037:	mov    r13,r8
  40f03a:	cmp    r8,r9
  40f03d:	jne    40f065 <__swc_fn_65555ab2_000086_ac8c6565+0x45>
  40f03f:	mov    rcx,rdi
  40f042:	mov    rdx,r12
  40f045:	xor    r8d,r8d
  40f048:	call   4085a0 <__swc_fn_65555ab2_000090_9a1d717d>
  40f04d:	test   al,al
  40f04f:	je     40f065 <__swc_fn_65555ab2_000086_ac8c6565+0x45>
  40f051:	mov    eax,0x1
  40f056:	add    rsp,0x68
  40f05a:	pop    r15
  40f05c:	pop    r14
  40f05e:	pop    r13
  40f060:	pop    r12
  40f062:	pop    rdi
  40f063:	pop    rsi
  40f064:	ret
  40f065:	cmp    BYTE PTR [r12+0x2c],0xe
  40f06b:	je     40f07e <__swc_fn_65555ab2_000086_ac8c6565+0x5e>
  40f06d:	xor    eax,eax
  40f06f:	add    rsp,0x68
  40f073:	pop    r15
  40f075:	pop    r14
  40f077:	pop    r13
  40f079:	pop    r12
  40f07b:	pop    rdi
  40f07c:	pop    rsi
  40f07d:	ret
  40f07e:	mov    r14,QWORD PTR [r12+0x98]
  40f086:	mov    rax,QWORD PTR [r12+0xa0]
  40f08e:	mov    r12,rax
  40f091:	xor    r15d,r15d
  40f094:	test   r12,r12
  40f097:	je     40f0ff <__swc_fn_65555ab2_000086_ac8c6565+0xdf>
  40f099:	nop    DWORD PTR [rax+0x0]
  40f0a0:	mov    QWORD PTR [rsp+0x58],r12
  40f0a5:	lea    r12,[r15*8+0x0]
  40f0ad:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40f0b2:	mov    rcx,rax
  40f0b5:	call   40c020 <__swc_fn_65555ab2_000082_9f4f5092>
  40f0ba:	cmp    BYTE PTR [rax+0x2c],0xe
  40f0be:	jne    40f0f0 <__swc_fn_65555ab2_000086_ac8c6565+0xd0>
  40f0c0:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40f0c5:	lea    r8,[r13+rcx*1+0x0]
  40f0ca:	mov    rcx,rdi
  40f0cd:	mov    rdx,rax
  40f0d0:	mov    r9,rsi
  40f0d3:	call   40f020 <__swc_fn_65555ab2_000086_ac8c6565>
  40f0d8:	test   al,al
  40f0da:	je     40f0f0 <__swc_fn_65555ab2_000086_ac8c6565+0xd0>
  40f0dc:	mov    eax,0x1
  40f0e1:	add    rsp,0x68
  40f0e5:	pop    r15
  40f0e7:	pop    r14
  40f0e9:	pop    r13
  40f0eb:	pop    r12
  40f0ed:	pop    rdi
  40f0ee:	pop    rsi
  40f0ef:	ret
  40f0f0:	add    r15,0x1
  40f0f4:	mov    r12,QWORD PTR [rsp+0x58]
  40f0f9:	sub    r12,0x1
  40f0fd:	jne    40f0a0 <__swc_fn_65555ab2_000086_ac8c6565+0x80>
  40f0ff:	xor    eax,eax
  40f101:	add    rsp,0x68
  40f105:	pop    r15
  40f107:	pop    r14
  40f109:	pop    r13
  40f10b:	pop    r12
  40f10d:	pop    rdi
  40f10e:	pop    rsi
  40f10f:	ret

000000000040f110 <__swc_fn_65555ab2_000089_157b05de>:
  40f110:	push   rbp
  40f111:	push   rbx
  40f112:	push   rsi
  40f113:	push   rdi
  40f114:	push   r12
  40f116:	push   r13
  40f118:	push   r14
  40f11a:	push   r15
  40f11c:	sub    rsp,0x38
  40f120:	mov    rbp,rsp
  40f123:	mov    rbx,r11
  40f126:	mov    rsi,rdx
  40f129:	mov    rdi,r8
  40f12c:	mov    r12,r9
  40f12f:	mov    QWORD PTR [rsp+0x18],r9
  40f134:	mov    r13,r10
  40f137:	movzx  r14d,BYTE PTR [rbp+0x80]
  40f13f:	movzx  r15d,BYTE PTR [rbp+0x88]
  40f147:	test   r11,r11
  40f14a:	je     40f150 <__swc_fn_65555ab2_000089_157b05de+0x40>
  40f14c:	xor    eax,eax
  40f14e:	mov    BYTE PTR [rbx],al
  40f150:	test   r12,r12
  40f153:	je     40f15e <__swc_fn_65555ab2_000089_157b05de+0x4e>
  40f155:	mov    QWORD PTR [r12+0x8],0x0
  40f15e:	test   rcx,rcx
  40f161:	je     40f168 <__swc_fn_65555ab2_000089_157b05de+0x58>
  40f163:	test   rsi,rsi
  40f166:	jne    40f17b <__swc_fn_65555ab2_000089_157b05de+0x6b>
  40f168:	xor    eax,eax
  40f16a:	add    rsp,0x38
  40f16e:	pop    r15
  40f170:	pop    r14
  40f172:	pop    r13
  40f174:	pop    r12
  40f176:	pop    rdi
  40f177:	pop    rsi
  40f178:	pop    rbx
  40f179:	pop    rbp
  40f17a:	ret
  40f17b:	call   40c020 <__swc_fn_65555ab2_000082_9f4f5092>
  40f180:	mov    r12,rax
  40f183:	mov    al,r15b
  40f186:	test   r15b,r15b
  40f189:	jne    40f199 <__swc_fn_65555ab2_000089_157b05de+0x89>
  40f18b:	mov    eax,DWORD PTR [r12+0x28]
  40f190:	and    eax,0x10000
  40f196:	setne  al
  40f199:	lea    r15,[rsp+0x8]
  40f19e:	mov    QWORD PTR [rsp+0x20],r15
  40f1a3:	rex mov BYTE PTR [rsp+0x8],al
  40f1a8:	test   DWORD PTR [rsi+0x28],0x400000
  40f1af:	je     40f1e7 <__swc_fn_65555ab2_000089_157b05de+0xd7>
  40f1b1:	test   rsi,rsi
  40f1b4:	je     40f1d4 <__swc_fn_65555ab2_000089_157b05de+0xc4>
  40f1b6:	mov    rax,QWORD PTR [rsi+0x38]
  40f1ba:	cmp    QWORD PTR [rax+0x10],rsi
  40f1be:	jne    40f1d4 <__swc_fn_65555ab2_000089_157b05de+0xc4>
  40f1c0:	rex mov al,BYTE PTR [rsp+0x8]
  40f1c5:	test   al,al
  40f1c7:	sete   al
  40f1ca:	test   r14b,r14b
  40f1cd:	sete   cl
  40f1d0:	test   al,cl
  40f1d2:	je     40f1e7 <__swc_fn_65555ab2_000089_157b05de+0xd7>
  40f1d4:	xor    eax,eax
  40f1d6:	add    rsp,0x38
  40f1da:	pop    r15
  40f1dc:	pop    r14
  40f1de:	pop    r13
  40f1e0:	pop    r12
  40f1e2:	pop    rdi
  40f1e3:	pop    rsi
  40f1e4:	pop    rbx
  40f1e5:	pop    rbp
  40f1e6:	ret
  40f1e7:	mov    r15,r12
  40f1ea:	test   r14b,r14b
  40f1ed:	jne    40f204 <__swc_fn_65555ab2_000089_157b05de+0xf4>
  40f1ef:	cmp    BYTE PTR [r12+0x2c],0x6
  40f1f5:	jne    40f204 <__swc_fn_65555ab2_000089_157b05de+0xf4>
  40f1f7:	mov    rcx,QWORD PTR [r12+0x40]
  40f1fc:	call   40c020 <__swc_fn_65555ab2_000082_9f4f5092>
  40f201:	mov    r15,rax
  40f204:	test   r14b,r14b
  40f207:	je     40f20d <__swc_fn_65555ab2_000089_157b05de+0xfd>
  40f209:	mov    r15,QWORD PTR [r15+0x30]
  40f20d:	mov    rcx,rsi
  40f210:	call   40c020 <__swc_fn_65555ab2_000082_9f4f5092>
  40f215:	mov    rsi,rax
  40f218:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f21d:	je     40f254 <__swc_fn_65555ab2_000089_157b05de+0x144>
  40f21f:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f224:	je     40f254 <__swc_fn_65555ab2_000089_157b05de+0x144>
  40f226:	mov    eax,DWORD PTR [rsi+0x28]
  40f229:	and    eax,0x10000
  40f22f:	je     40f254 <__swc_fn_65555ab2_000089_157b05de+0x144>
  40f231:	rex mov al,BYTE PTR [rsp+0x8]
  40f236:	test   al,al
  40f238:	jne    40f24d <__swc_fn_65555ab2_000089_157b05de+0x13d>
  40f23a:	xor    eax,eax
  40f23c:	add    rsp,0x38
  40f240:	pop    r15
  40f242:	pop    r14
  40f244:	pop    r13
  40f246:	pop    r12
  40f248:	pop    rdi
  40f249:	pop    rsi
  40f24a:	pop    rbx
  40f24b:	pop    rbp
  40f24c:	ret
  40f24d:	mov    rax,QWORD PTR [rsi+0x30]
  40f251:	mov    rsi,rax
  40f254:	mov    r14b,r13b
  40f257:	test   rbx,rbx
  40f25a:	je     40f290 <__swc_fn_65555ab2_000089_157b05de+0x180>
  40f25c:	cmp    BYTE PTR [r12+0x2c],0x6
  40f262:	jne    40f290 <__swc_fn_65555ab2_000089_157b05de+0x180>
  40f264:	lea    rdx,[rip+0x3f15]        # 413180 <__swc_rdata_base_65555ab2+0x70>
  40f26b:	mov    rcx,rsi
  40f26e:	xor    r8d,r8d
  40f271:	call   4085a0 <__swc_fn_65555ab2_000090_9a1d717d>
  40f276:	test   al,al
  40f278:	je     40f290 <__swc_fn_65555ab2_000089_157b05de+0x180>
  40f27a:	mov    BYTE PTR [rbx],0x1
  40f27d:	xor    eax,eax
  40f27f:	add    rsp,0x38
  40f283:	pop    r15
  40f285:	pop    r14
  40f287:	pop    r13
  40f289:	pop    r12
  40f28b:	pop    rdi
  40f28c:	pop    rsi
  40f28d:	pop    rbx
  40f28e:	pop    rbp
  40f28f:	ret
  40f290:	test   rdi,rdi
  40f293:	jne    40f2ad <__swc_fn_65555ab2_000089_157b05de+0x19d>
  40f295:	test   r13b,r13b
  40f298:	jne    40f2ad <__swc_fn_65555ab2_000089_157b05de+0x19d>
  40f29a:	xor    eax,eax
  40f29c:	add    rsp,0x38
  40f2a0:	pop    r15
  40f2a2:	pop    r14
  40f2a4:	pop    r13
  40f2a6:	pop    r12
  40f2a8:	pop    rdi
  40f2a9:	pop    rsi
  40f2aa:	pop    rbx
  40f2ab:	pop    rbp
  40f2ac:	ret
  40f2ad:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40f2b2:	jne    40f368 <__swc_fn_65555ab2_000089_157b05de+0x258>
  40f2b8:	mov    rcx,r15
  40f2bb:	mov    rdx,rsi
  40f2be:	xor    r8d,r8d
  40f2c1:	call   4085a0 <__swc_fn_65555ab2_000090_9a1d717d>
  40f2c6:	test   al,al
  40f2c8:	jne    40f368 <__swc_fn_65555ab2_000089_157b05de+0x258>
  40f2ce:	test   DWORD PTR [rsi+0x28],0x10000
  40f2d5:	je     40f2f3 <__swc_fn_65555ab2_000089_157b05de+0x1e3>
  40f2d7:	rex mov al,BYTE PTR [rsp+0x8]
  40f2dc:	test   al,al
  40f2de:	jne    40f2f3 <__swc_fn_65555ab2_000089_157b05de+0x1e3>
  40f2e0:	xor    eax,eax
  40f2e2:	add    rsp,0x38
  40f2e6:	pop    r15
  40f2e8:	pop    r14
  40f2ea:	pop    r13
  40f2ec:	pop    r12
  40f2ee:	pop    rdi
  40f2ef:	pop    rsi
  40f2f0:	pop    rbx
  40f2f1:	pop    rbp
  40f2f2:	ret
  40f2f3:	test   rdi,rdi
  40f2f6:	jne    40f30b <__swc_fn_65555ab2_000089_157b05de+0x1fb>
  40f2f8:	xor    eax,eax
  40f2fa:	add    rsp,0x38
  40f2fe:	pop    r15
  40f300:	pop    r14
  40f302:	pop    r13
  40f304:	pop    r12
  40f306:	pop    rdi
  40f307:	pop    rsi
  40f308:	pop    rbx
  40f309:	pop    rbp
  40f30a:	ret
  40f30b:	mov    rcx,QWORD PTR [rsi+0x40]
  40f30f:	call   40c020 <__swc_fn_65555ab2_000082_9f4f5092>
  40f314:	mov    rsi,rax
  40f317:	mov    rax,QWORD PTR [rdi]
  40f31a:	mov    rdi,rax
  40f31d:	test   rax,rax
  40f320:	jne    40f363 <__swc_fn_65555ab2_000089_157b05de+0x253>
  40f322:	test   rbx,rbx
  40f325:	je     40f363 <__swc_fn_65555ab2_000089_157b05de+0x253>
  40f327:	mov    rcx,r15
  40f32a:	mov    rdx,rsi
  40f32d:	xor    r8d,r8d
  40f330:	call   4085a0 <__swc_fn_65555ab2_000090_9a1d717d>
  40f335:	mov    rcx,rax
  40f338:	test   al,al
  40f33a:	jne    40f35c <__swc_fn_65555ab2_000089_157b05de+0x24c>
  40f33c:	mov    rcx,r15
  40f33f:	mov    rdx,rsi
  40f342:	call   40c060 <__swc_fn_65555ab2_000085_88128f21>
  40f347:	mov    rcx,rax
  40f34a:	test   al,al
  40f34c:	jne    40f35c <__swc_fn_65555ab2_000089_157b05de+0x24c>
  40f34e:	mov    rcx,rsi
  40f351:	mov    rdx,r15
  40f354:	call   40c060 <__swc_fn_65555ab2_000085_88128f21>
  40f359:	mov    rcx,rax
  40f35c:	test   cl,cl
  40f35e:	setne  al
  40f361:	mov    BYTE PTR [rbx],al
  40f363:	xor    eax,eax
  40f365:	mov    r14b,al
  40f368:	test   rdi,rdi
  40f36b:	jne    40f385 <__swc_fn_65555ab2_000089_157b05de+0x275>
  40f36d:	test   r14b,r14b
  40f370:	jne    40f385 <__swc_fn_65555ab2_000089_157b05de+0x275>
  40f372:	xor    eax,eax
  40f374:	add    rsp,0x38
  40f378:	pop    r15
  40f37a:	pop    r14
  40f37c:	pop    r13
  40f37e:	pop    r12
  40f380:	pop    rdi
  40f381:	pop    rsi
  40f382:	pop    rbx
  40f383:	pop    rbp
  40f384:	ret
  40f385:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40f38a:	je     40f396 <__swc_fn_65555ab2_000089_157b05de+0x286>
  40f38c:	mov    r12,QWORD PTR [rsp+0x18]
  40f391:	jmp    40f41e <__swc_fn_65555ab2_000089_157b05de+0x30e>
  40f396:	mov    r12,QWORD PTR [rsp+0x18]
  40f39b:	test   r12,r12
  40f39e:	jne    40f3b2 <__swc_fn_65555ab2_000089_157b05de+0x2a2>
  40f3a0:	mov    rcx,r15
  40f3a3:	mov    rdx,rsi
  40f3a6:	xor    r8d,r8d
  40f3a9:	call   4085a0 <__swc_fn_65555ab2_000090_9a1d717d>
  40f3ae:	test   al,al
  40f3b0:	jne    40f41e <__swc_fn_65555ab2_000089_157b05de+0x30e>
  40f3b2:	test   DWORD PTR [rsi+0x28],0x10000
  40f3b9:	je     40f3d7 <__swc_fn_65555ab2_000089_157b05de+0x2c7>
  40f3bb:	rex mov al,BYTE PTR [rsp+0x8]
  40f3c0:	test   al,al
  40f3c2:	jne    40f3d7 <__swc_fn_65555ab2_000089_157b05de+0x2c7>
  40f3c4:	xor    eax,eax
  40f3c6:	add    rsp,0x38
  40f3ca:	pop    r15
  40f3cc:	pop    r14
  40f3ce:	pop    r13
  40f3d0:	pop    r12
  40f3d2:	pop    rdi
  40f3d3:	pop    rsi
  40f3d4:	pop    rbx
  40f3d5:	pop    rbp
  40f3d6:	ret
  40f3d7:	test   rdi,rdi
  40f3da:	jne    40f3ef <__swc_fn_65555ab2_000089_157b05de+0x2df>
  40f3dc:	xor    eax,eax
  40f3de:	add    rsp,0x38
  40f3e2:	pop    r15
  40f3e4:	pop    r14
  40f3e6:	pop    r13
  40f3e8:	pop    r12
  40f3ea:	pop    rdi
  40f3eb:	pop    rsi
  40f3ec:	pop    rbx
  40f3ed:	pop    rbp
  40f3ee:	ret
  40f3ef:	cmp    QWORD PTR [rdi+0x8],0x0
  40f3f4:	jne    40f409 <__swc_fn_65555ab2_000089_157b05de+0x2f9>
  40f3f6:	xor    eax,eax
  40f3f8:	add    rsp,0x38
  40f3fc:	pop    r15
  40f3fe:	pop    r14
  40f400:	pop    r13
  40f402:	pop    r12
  40f404:	pop    rdi
  40f405:	pop    rsi
  40f406:	pop    rbx
  40f407:	pop    rbp
  40f408:	ret
  40f409:	mov    rax,QWORD PTR [rdi+0x8]
  40f40d:	mov    rax,QWORD PTR [rax]
  40f410:	mov    rsi,rax
  40f413:	mov    rdi,QWORD PTR [rdi]
  40f416:	mov    eax,0x1
  40f41b:	mov    r14b,al
  40f41e:	test   rdi,rdi
  40f421:	mov    rbx,QWORD PTR [rsp+0x20]
  40f426:	jne    40f470 <__swc_fn_65555ab2_000089_157b05de+0x360>
  40f428:	test   r14b,r14b
  40f42b:	je     40f45d <__swc_fn_65555ab2_000089_157b05de+0x34d>
  40f42d:	test   r12,r12
  40f430:	je     40f45d <__swc_fn_65555ab2_000089_157b05de+0x34d>
  40f432:	mov    rcx,r15
  40f435:	mov    rdx,rsi
  40f438:	xor    r8d,r8d
  40f43b:	mov    r9,r12
  40f43e:	mov    rbx,QWORD PTR [rsp+0x20]
  40f443:	movzx  r10d,BYTE PTR [rbx]
  40f447:	call   40f000 <__swc_fn_65555ab2_000083_fb84e43e>
  40f44c:	add    rsp,0x38
  40f450:	pop    r15
  40f452:	pop    r14
  40f454:	pop    r13
  40f456:	pop    r12
  40f458:	pop    rdi
  40f459:	pop    rsi
  40f45a:	pop    rbx
  40f45b:	pop    rbp
  40f45c:	ret
  40f45d:	xor    eax,eax
  40f45f:	add    rsp,0x38
  40f463:	pop    r15
  40f465:	pop    r14
  40f467:	pop    r13
  40f469:	pop    r12
  40f46b:	pop    rdi
  40f46c:	pop    rsi
  40f46d:	pop    rbx
  40f46e:	pop    rbp
  40f46f:	ret
  40f470:	mov    r13,rsi
  40f473:	mov    QWORD PTR [rsp+0x28],rdi
  40f478:	cmp    BYTE PTR [r15+0x2c],0xe
  40f47d:	sete   al
  40f480:	mov    r14b,al
  40f483:	jne    40f497 <__swc_fn_65555ab2_000089_157b05de+0x387>
  40f485:	mov    rcx,rsi
  40f488:	mov    rdx,r15
  40f48b:	call   40c060 <__swc_fn_65555ab2_000085_88128f21>
  40f490:	mov    r14b,al
  40f493:	test   al,al
  40f495:	jne    40f4cc <__swc_fn_65555ab2_000089_157b05de+0x3bc>
  40f497:	cmp    BYTE PTR [r15+0x2c],0x12
  40f49c:	je     40f4cc <__swc_fn_65555ab2_000089_157b05de+0x3bc>
  40f49e:	mov    rcx,r15
  40f4a1:	mov    rdx,rsi
  40f4a4:	mov    r8,rdi
  40f4a7:	mov    r9,r12
  40f4aa:	mov    rax,rbx
  40f4ad:	movzx  r10d,BYTE PTR [rax]
  40f4b1:	call   40f000 <__swc_fn_65555ab2_000083_fb84e43e>
  40f4b6:	test   rax,rax
  40f4b9:	je     40f4cc <__swc_fn_65555ab2_000089_157b05de+0x3bc>
  40f4bb:	add    rsp,0x38
  40f4bf:	pop    r15
  40f4c1:	pop    r14
  40f4c3:	pop    r13
  40f4c5:	pop    r12
  40f4c7:	pop    rdi
  40f4c8:	pop    rsi
  40f4c9:	pop    rbx
  40f4ca:	pop    rbp
  40f4cb:	ret
  40f4cc:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40f4d1:	jne    40f4f0 <__swc_fn_65555ab2_000089_157b05de+0x3e0>
  40f4d3:	mov    rax,QWORD PTR [rsi+0xd8]
  40f4da:	test   rax,rax
  40f4dd:	je     40f4f0 <__swc_fn_65555ab2_000089_157b05de+0x3e0>
  40f4df:	add    rdi,QWORD PTR [rax+0x8]
  40f4e3:	mov    rax,QWORD PTR [rdi]
  40f4e6:	sub    rdi,QWORD PTR [rax+0x8]
  40f4ea:	mov    rax,QWORD PTR [rax]
  40f4ed:	mov    rsi,rax
  40f4f0:	test   r14b,r14b
  40f4f3:	je     40f51f <__swc_fn_65555ab2_000089_157b05de+0x40f>
  40f4f5:	mov    rcx,r15
  40f4f8:	mov    rdx,rsi
  40f4fb:	mov    r8,rdi
  40f4fe:	mov    r9,r13
  40f501:	mov    r14,QWORD PTR [rsp+0x28]
  40f506:	mov    r10,r14
  40f509:	call   408480 <__swc_fn_65555ab2_000087_1fb4fcfe>
  40f50e:	add    rsp,0x38
  40f512:	pop    r15
  40f514:	pop    r14
  40f516:	pop    r13
  40f518:	pop    r12
  40f51a:	pop    rdi
  40f51b:	pop    rsi
  40f51c:	pop    rbx
  40f51d:	pop    rbp
  40f51e:	ret
  40f51f:	mov    rcx,r15
  40f522:	mov    rdx,rsi
  40f525:	mov    r8,rdi
  40f528:	mov    r9,r12
  40f52b:	movzx  r10d,BYTE PTR [rbx]
  40f52f:	call   40f000 <__swc_fn_65555ab2_000083_fb84e43e>
  40f534:	add    rsp,0x38
  40f538:	pop    r15
  40f53a:	pop    r14
  40f53c:	pop    r13
  40f53e:	pop    r12
  40f540:	pop    rdi
  40f541:	pop    rsi
  40f542:	pop    rbx
  40f543:	pop    rbp
  40f544:	ret
	...

000000000040f550 <__swc_fn_65555ab2_000092_17e20532>:
  40f550:	push   rbx
  40f551:	push   rsi
  40f552:	sub    rsp,0x18
  40f556:	mov    rbx,rcx
  40f559:	mov    rcx,QWORD PTR [rip+0x177e0]        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  40f560:	test   rcx,rcx
  40f563:	jne    40f575 <__swc_fn_65555ab2_000092_17e20532+0x25>
  40f565:	call   40a1a0 <__swc_fn_65555ab2_000165_e09accff>
  40f56a:	lea    rcx,[rax+0x1]
  40f56e:	mov    QWORD PTR [rip+0x177cb],rcx        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  40f575:	dec    rcx
  40f578:	call   411e00 <__swc_fn_65555ab2_000167_3130645d>
  40f57d:	mov    rsi,rax
  40f580:	mov    rax,QWORD PTR [rsi+0x8]
  40f584:	test   rax,rax
  40f587:	jne    40f5d7 <__swc_fn_65555ab2_000092_17e20532+0x87>
  40f589:	call   40c150 <__swc_fn_65555ab2_000091_e6773530>
  40f58e:	test   al,al
  40f590:	jne    40f5d7 <__swc_fn_65555ab2_000092_17e20532+0x87>
  40f592:	lea    rdx,[rip+0x14ca7]        # 424240 <__swc_bss_base_65555ab2+0x200>
  40f599:	mov    rcx,rdx
  40f59c:	call   407740 <__swc_fn_65555ab2_000036_62160bb3>
  40f5a1:	test   al,al
  40f5a3:	jne    40f5b4 <__swc_fn_65555ab2_000092_17e20532+0x64>
  40f5a5:	mov    rcx,rdx
  40f5a8:	call   40aa40 <__swc_fn_65555ab2_000034_c72914a2>
  40f5ad:	lea    rdx,[rip+0x14c8c]        # 424240 <__swc_bss_base_65555ab2+0x200>
  40f5b4:	mov    QWORD PTR [rsp+0x8],rdx
  40f5b9:	lea    rax,[rip+0x3b90]        # 413150 <__swc_rdata_base_65555ab2+0x40>
  40f5c0:	mov    QWORD PTR [rsp+0x10],rax
  40f5c5:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f5cb:	vmovups XMMWORD PTR [rsi],xmm0
  40f5cf:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40f5d7:	vmovups xmm0,XMMWORD PTR [rsi]
  40f5db:	vmovups XMMWORD PTR [rbx],xmm0
  40f5df:	mov    rax,rbx
  40f5e2:	add    rsp,0x18
  40f5e6:	pop    rsi
  40f5e7:	pop    rbx
  40f5e8:	ret
  40f5e9:	add    BYTE PTR [rax],al
  40f5eb:	add    BYTE PTR [rax],al
  40f5ed:	add    BYTE PTR [rax],al
	...

000000000040f5f0 <__swc_fn_65555ab2_000095_a3245f7e>:
  40f5f0:	sub    rsp,0x8
  40f5f4:	call   409340 <__swc_fn_65555ab2_000117_76ff2f0a>
  40f5f9:	add    rsp,0x8
  40f5fd:	ret
	...

000000000040f600 <__swc_fn_65555ab2_000098_d9d80f1a>:
  40f600:	push   rbx
  40f601:	push   rsi
  40f602:	sub    rsp,0x28
  40f606:	mov    rbx,rcx
  40f609:	xor    esi,esi
  40f60b:	jmp    40f620 <__swc_fn_65555ab2_000098_d9d80f1a+0x20>
  40f60d:	nop    DWORD PTR [rax]
  40f610:	mov    QWORD PTR [rbx+0x28],rsi
  40f614:	mov    rsi,rbx
  40f617:	mov    rbx,rax
  40f61a:	nop    WORD PTR [rax+rax*1+0x0]
  40f620:	test   rbx,rbx
  40f623:	je     40f683 <__swc_fn_65555ab2_000098_d9d80f1a+0x83>
  40f625:	mov    rcx,rbx
  40f628:	mov    edx,0x1
  40f62d:	call   408200 <__swc_fn_65555ab2_000078_5a70c27a>
  40f632:	cmp    rax,0x1
  40f636:	jne    40f683 <__swc_fn_65555ab2_000098_d9d80f1a+0x83>
  40f638:	mov    r10,QWORD PTR [rbx+0x18]
  40f63c:	mov    rcx,r10
  40f63f:	mov    edx,0x1
  40f644:	call   408200 <__swc_fn_65555ab2_000078_5a70c27a>
  40f649:	cmp    rax,0x1
  40f64d:	jne    40f65c <__swc_fn_65555ab2_000098_d9d80f1a+0x5c>
  40f64f:	mov    rcx,r10
  40f652:	call   40c2f0 <__swc_fn_65555ab2_000097_8b4a07e9>
  40f657:	test   rax,rax
  40f65a:	jne    40f610 <__swc_fn_65555ab2_000098_d9d80f1a+0x10>
  40f65c:	mov    rax,QWORD PTR [rbx+0x20]
  40f660:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40f665:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f66b:	lea    rcx,[rsp+0x8]
  40f670:	mov    rdx,rbx
  40f673:	mov    r8d,0x30
  40f679:	mov    rbx,rax
  40f67c:	call   408960 <__swc_fn_65555ab2_000096_f879630a>
  40f681:	jmp    40f620 <__swc_fn_65555ab2_000098_d9d80f1a+0x20>
  40f683:	test   rsi,rsi
  40f686:	jne    40f68f <__swc_fn_65555ab2_000098_d9d80f1a+0x8f>
  40f688:	add    rsp,0x28
  40f68c:	pop    rsi
  40f68d:	pop    rbx
  40f68e:	ret
  40f68f:	mov    rax,rsi
  40f692:	mov    rsi,QWORD PTR [rsi+0x28]
  40f696:	mov    rbx,QWORD PTR [rax+0x20]
  40f69a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40f69f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f6a5:	lea    rcx,[rsp+0x18]
  40f6aa:	mov    rdx,rax
  40f6ad:	mov    r8d,0x30
  40f6b3:	call   408960 <__swc_fn_65555ab2_000096_f879630a>
  40f6b8:	jmp    40f620 <__swc_fn_65555ab2_000098_d9d80f1a+0x20>
  40f6bd:	add    BYTE PTR [rax],al
	...

000000000040f6c0 <__swc_fn_65555ab2_000101_295ddd7c>:
  40f6c0:	push   rbx
  40f6c1:	push   rsi
  40f6c2:	push   rdi
  40f6c3:	push   r12
  40f6c5:	push   r13
  40f6c7:	sub    rsp,0x20
  40f6cb:	mov    rbx,rcx
  40f6ce:	lea    rsi,[rcx+0x6f8]
  40f6d5:	mov    edi,0x4
  40f6da:	mov    r12,rsi
  40f6dd:	test   rdi,rdi
  40f6e0:	je     40f72a <__swc_fn_65555ab2_000101_295ddd7c+0x6a>
  40f6e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f6ec:	nop    DWORD PTR [rax+0x0]
  40f6f0:	mov    rcx,QWORD PTR [r12+0x10]
  40f6f5:	mov    QWORD PTR [r12+0x10],0x0
  40f6fe:	vxorps xmm0,xmm0,xmm0
  40f702:	vmovups XMMWORD PTR [r12],xmm0
  40f708:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40f70f:	mov    DWORD PTR [r12+0x20],0x0
  40f718:	call   4089b0 <__swc_fn_65555ab2_000099_6e0faaee>
  40f71d:	add    r12,0x90
  40f724:	sub    rdi,0x1
  40f728:	jne    40f6f0 <__swc_fn_65555ab2_000101_295ddd7c+0x30>
  40f72a:	mov    rax,QWORD PTR [rbx+0x938]
  40f731:	mov    rdi,rax
  40f734:	test   rdi,rdi
  40f737:	je     40f791 <__swc_fn_65555ab2_000101_295ddd7c+0xd1>
  40f739:	nop    DWORD PTR [rax+0x0]
  40f740:	mov    r12d,0x10
  40f746:	lea    r13,[rdi+0x18]
  40f74a:	test   r12,r12
  40f74d:	je     40f786 <__swc_fn_65555ab2_000101_295ddd7c+0xc6>
  40f74f:	nop
  40f750:	mov    rcx,QWORD PTR [r13+0x10]
  40f754:	mov    QWORD PTR [r13+0x10],0x0
  40f75c:	vxorps xmm0,xmm0,xmm0
  40f760:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40f766:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40f76c:	mov    DWORD PTR [r13+0x20],0x0
  40f774:	call   4089b0 <__swc_fn_65555ab2_000099_6e0faaee>
  40f779:	add    r13,0x90
  40f780:	sub    r12,0x1
  40f784:	jne    40f750 <__swc_fn_65555ab2_000101_295ddd7c+0x90>
  40f786:	mov    rax,QWORD PTR [rdi]
  40f789:	mov    rdi,rax
  40f78c:	test   rax,rax
  40f78f:	jne    40f740 <__swc_fn_65555ab2_000101_295ddd7c+0x80>
  40f791:	vxorps xmm0,xmm0,xmm0
  40f795:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40f79d:	mov    DWORD PTR [rbx+0x9b0],0x0
  40f7a7:	mov    DWORD PTR [rbx+0x9a8],0x0
  40f7b1:	mov    edi,0x4
  40f7b6:	mov    r12,rsi
  40f7b9:	lea    rsi,[rsi+0x38]
  40f7bd:	test   rdi,rdi
  40f7c0:	je     40f7ec <__swc_fn_65555ab2_000101_295ddd7c+0x12c>
  40f7c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f7cc:	nop    DWORD PTR [rax+0x0]
  40f7d0:	mov    rcx,rsi
  40f7d3:	call   40d170 <__swc_fn_65555ab2_000157_5c8b11d8>
  40f7d8:	add    rsi,0x90
  40f7df:	add    r12,0x90
  40f7e6:	sub    rdi,0x1
  40f7ea:	jne    40f7d0 <__swc_fn_65555ab2_000101_295ddd7c+0x110>
  40f7ec:	mov    rax,QWORD PTR [rbx+0x938]
  40f7f3:	mov    rdi,rax
  40f7f6:	mov    QWORD PTR [rbx+0x938],0x0
  40f801:	test   rdi,rdi
  40f804:	je     40f875 <__swc_fn_65555ab2_000101_295ddd7c+0x1b5>
  40f80a:	nop    WORD PTR [rax+rax*1+0x0]
  40f810:	mov    esi,0x10
  40f815:	lea    r12,[rdi+0x18]
  40f819:	lea    r13,[rdi+0x50]
  40f81d:	test   rsi,rsi
  40f820:	je     40f84c <__swc_fn_65555ab2_000101_295ddd7c+0x18c>
  40f822:	cs nop WORD PTR [rax+rax*1+0x0]
  40f82c:	nop    DWORD PTR [rax+0x0]
  40f830:	mov    rcx,r13
  40f833:	call   40d170 <__swc_fn_65555ab2_000157_5c8b11d8>
  40f838:	add    r13,0x90
  40f83f:	add    r12,0x90
  40f846:	sub    rsi,0x1
  40f84a:	jne    40f830 <__swc_fn_65555ab2_000101_295ddd7c+0x170>
  40f84c:	mov    rax,QWORD PTR [rdi]
  40f84f:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40f854:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f85a:	lea    rcx,[rsp+0x8]
  40f85f:	mov    rdx,rdi
  40f862:	mov    r8d,0x918
  40f868:	mov    rdi,rax
  40f86b:	call   408960 <__swc_fn_65555ab2_000096_f879630a>
  40f870:	test   rdi,rdi
  40f873:	jne    40f810 <__swc_fn_65555ab2_000101_295ddd7c+0x150>
  40f875:	lea    rcx,[rbx+0x68]
  40f879:	call   40d170 <__swc_fn_65555ab2_000157_5c8b11d8>
  40f87e:	add    rsp,0x20
  40f882:	pop    r13
  40f884:	pop    r12
  40f886:	pop    rdi
  40f887:	pop    rsi
  40f888:	pop    rbx
  40f889:	ret
  40f88a:	add    BYTE PTR [rax],al
  40f88c:	add    BYTE PTR [rax],al
	...

000000000040f890 <__swc_fn_65555ab2_000104_baf871f8>:
  40f890:	xor    eax,eax
  40f892:	cs nop WORD PTR [rax+rax*1+0x0]
  40f89c:	nop    DWORD PTR [rax+0x0]
  40f8a0:	mov    r9,r8
  40f8a3:	sub    r9,rax
  40f8a6:	cmp    r9,0x40
  40f8aa:	jb     40f8e8 <__swc_fn_65555ab2_000104_baf871f8+0x58>
  40f8ac:	lea    r9,[rcx+rax*1]
  40f8b0:	lea    r10,[rdx+rax*1]
  40f8b4:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40f8ba:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40f8c0:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40f8c6:	vmovups xmm3,XMMWORD PTR [r10]
  40f8cb:	vmovups XMMWORD PTR [r9],xmm3
  40f8d0:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40f8d6:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40f8dc:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40f8e2:	lea    rax,[rax+0x40]
  40f8e6:	jmp    40f8a0 <__swc_fn_65555ab2_000104_baf871f8+0x10>
  40f8e8:	nop    DWORD PTR [rax+rax*1+0x0]
  40f8f0:	mov    r9,r8
  40f8f3:	sub    r9,rax
  40f8f6:	cmp    r9,0x10
  40f8fa:	jb     40f914 <__swc_fn_65555ab2_000104_baf871f8+0x84>
  40f8fc:	lea    r9,[rdx+rax*1]
  40f900:	lea    r10,[rcx+rax*1]
  40f904:	vmovups xmm0,XMMWORD PTR [r9]
  40f909:	vmovups XMMWORD PTR [r10],xmm0
  40f90e:	lea    rax,[rax+0x10]
  40f912:	jmp    40f8f0 <__swc_fn_65555ab2_000104_baf871f8+0x60>
  40f914:	cs nop WORD PTR [rax+rax*1+0x0]
  40f91e:	xchg   ax,ax
  40f920:	mov    r9,r8
  40f923:	sub    r9,rax
  40f926:	cmp    r9,0x8
  40f92a:	jb     40f93d <__swc_fn_65555ab2_000104_baf871f8+0xad>
  40f92c:	lea    r9,[rcx+rax*1]
  40f930:	mov    r10,QWORD PTR [rdx+rax*1]
  40f934:	mov    QWORD PTR [r9],r10
  40f937:	lea    rax,[rax+0x8]
  40f93b:	jmp    40f920 <__swc_fn_65555ab2_000104_baf871f8+0x90>
  40f93d:	cmp    rax,r8
  40f940:	jae    40f960 <__swc_fn_65555ab2_000104_baf871f8+0xd0>
  40f942:	cs nop WORD PTR [rax+rax*1+0x0]
  40f94c:	nop    DWORD PTR [rax+0x0]
  40f950:	mov    r9b,BYTE PTR [rdx+rax*1]
  40f954:	mov    BYTE PTR [rcx+rax*1],r9b
  40f958:	inc    rax
  40f95b:	cmp    rax,r8
  40f95e:	jb     40f950 <__swc_fn_65555ab2_000104_baf871f8+0xc0>
  40f960:	ret
	...

000000000040f970 <__swc_fn_65555ab2_000107_ff529476>:
  40f970:	push   rbx
  40f971:	push   r12
  40f973:	push   rdi
  40f974:	push   rsi
  40f975:	push   r13
  40f977:	push   r14
  40f979:	push   r15
  40f97b:	sub    rsp,0x170
  40f982:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40f98b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40f994:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40f99d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40f9a6:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40f9af:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40f9b8:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40f9c1:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40f9ca:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40f9d3:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40f9dc:	mov    ebx,edx
  40f9de:	mov    QWORD PTR [rsp+0xa8],rbx
  40f9e6:	mov    r12d,ecx
  40f9e9:	test   edx,edx
  40f9eb:	jne    40fa02 <__swc_fn_65555ab2_000107_ff529476+0x92>
  40f9ed:	xor    eax,eax
  40f9ef:	add    rsp,0x170
  40f9f6:	pop    r15
  40f9f8:	pop    r14
  40f9fa:	pop    r13
  40f9fc:	pop    rsi
  40f9fd:	pop    rdi
  40f9fe:	pop    r12
  40fa00:	pop    rbx
  40fa01:	ret
  40fa02:	lea    rdi,[rip+0x3aa7]        # 4134b0 <__swc_rdata_base_65555ab2+0x3a0>
  40fa09:	mov    esi,0x90000
  40fa0e:	xor    eax,eax
  40fa10:	call   407090 <open@plt>
  40fa15:	mov    r13,rax
  40fa18:	mov    QWORD PTR [rsp+0xb0],rax
  40fa20:	test   eax,eax
  40fa22:	jge    40fa2b <__swc_fn_65555ab2_000107_ff529476+0xbb>
  40fa24:	xor    eax,eax
  40fa26:	jmp    40ff26 <__swc_fn_65555ab2_000107_ff529476+0x5b6>
  40fa2b:	nop    DWORD PTR [rax+rax*1+0x0]
  40fa30:	movsxd rdi,r13d
  40fa33:	mov    esi,0x2
  40fa38:	xor    eax,eax
  40fa3a:	call   407120 <flock@plt>
  40fa3f:	test   eax,eax
  40fa41:	je     40fa60 <__swc_fn_65555ab2_000107_ff529476+0xf0>
  40fa43:	xor    eax,eax
  40fa45:	call   407130 <__errno_location@plt>
  40fa4a:	cmp    DWORD PTR [rax],0x4
  40fa4d:	je     40fa30 <__swc_fn_65555ab2_000107_ff529476+0xc0>
  40fa4f:	movsxd rdi,r13d
  40fa52:	xor    eax,eax
  40fa54:	call   4070b0 <close@plt>
  40fa59:	xor    eax,eax
  40fa5b:	jmp    40ff26 <__swc_fn_65555ab2_000107_ff529476+0x5b6>
  40fa60:	lea    r14,[rsp+0x8]
  40fa65:	mov    QWORD PTR [rsp+0xb8],r14
  40fa6d:	vxorps xmm0,xmm0,xmm0
  40fa71:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40fa77:	mov    QWORD PTR [rsp+0x18],0x0
  40fa80:	mov    WORD PTR [rsp+0x20],0x0
  40fa87:	mov    DWORD PTR [r14],0x67617753
  40fa8e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40fa96:	xor    eax,eax
  40fa98:	call   407010 <getpid@plt>
  40fa9d:	mov    ecx,eax
  40fa9f:	mov    eax,0x1c
  40faa4:	shrx   eax,ecx,eax
  40faa9:	and    eax,0xf
  40faac:	mov    rdx,QWORD PTR [rip+0x3a1d]        # 4134d0 <__swc_rdata_base_65555ab2+0x3c0>
  40fab3:	mov    al,BYTE PTR [rdx+rax*1]
  40fab6:	rex mov BYTE PTR [rsp+0x10],al
  40fabb:	mov    eax,0x1c
  40fac0:	shrx   eax,r12d,eax
  40fac5:	and    eax,0xf
  40fac8:	mov    al,BYTE PTR [rdx+rax*1]
  40facb:	rex mov BYTE PTR [rsp+0x19],al
  40fad0:	mov    eax,0x18
  40fad5:	shrx   eax,ecx,eax
  40fada:	and    eax,0xf
  40fadd:	mov    al,BYTE PTR [rdx+rax*1]
  40fae0:	rex mov BYTE PTR [rsp+0x11],al
  40fae5:	mov    eax,0x18
  40faea:	shrx   eax,r12d,eax
  40faef:	and    eax,0xf
  40faf2:	mov    al,BYTE PTR [rdx+rax*1]
  40faf5:	rex mov BYTE PTR [rsp+0x1a],al
  40fafa:	mov    eax,0x14
  40faff:	shrx   eax,ecx,eax
  40fb04:	and    eax,0xf
  40fb07:	mov    al,BYTE PTR [rdx+rax*1]
  40fb0a:	rex mov BYTE PTR [rsp+0x12],al
  40fb0f:	mov    eax,0x14
  40fb14:	shrx   eax,r12d,eax
  40fb19:	and    eax,0xf
  40fb1c:	mov    al,BYTE PTR [rdx+rax*1]
  40fb1f:	rex mov BYTE PTR [rsp+0x1b],al
  40fb24:	mov    eax,0x10
  40fb29:	shrx   eax,ecx,eax
  40fb2e:	and    eax,0xf
  40fb31:	mov    al,BYTE PTR [rdx+rax*1]
  40fb34:	rex mov BYTE PTR [rsp+0x13],al
  40fb39:	mov    eax,0x10
  40fb3e:	shrx   eax,r12d,eax
  40fb43:	and    eax,0xf
  40fb46:	mov    al,BYTE PTR [rdx+rax*1]
  40fb49:	rex mov BYTE PTR [rsp+0x1c],al
  40fb4e:	mov    eax,0xc
  40fb53:	shrx   eax,ecx,eax
  40fb58:	and    eax,0xf
  40fb5b:	mov    al,BYTE PTR [rdx+rax*1]
  40fb5e:	rex mov BYTE PTR [rsp+0x14],al
  40fb63:	mov    eax,0xc
  40fb68:	shrx   eax,r12d,eax
  40fb6d:	and    eax,0xf
  40fb70:	mov    al,BYTE PTR [rdx+rax*1]
  40fb73:	rex mov BYTE PTR [rsp+0x1d],al
  40fb78:	mov    eax,0x8
  40fb7d:	shrx   eax,ecx,eax
  40fb82:	and    eax,0xf
  40fb85:	mov    al,BYTE PTR [rdx+rax*1]
  40fb88:	rex mov BYTE PTR [rsp+0x15],al
  40fb8d:	mov    eax,0x8
  40fb92:	shrx   eax,r12d,eax
  40fb97:	and    eax,0xf
  40fb9a:	mov    al,BYTE PTR [rdx+rax*1]
  40fb9d:	rex mov BYTE PTR [rsp+0x1e],al
  40fba2:	mov    eax,0x4
  40fba7:	shrx   eax,ecx,eax
  40fbac:	and    eax,0xf
  40fbaf:	mov    al,BYTE PTR [rdx+rax*1]
  40fbb2:	rex mov BYTE PTR [rsp+0x16],al
  40fbb7:	mov    eax,0x4
  40fbbc:	shrx   eax,r12d,eax
  40fbc1:	and    eax,0xf
  40fbc4:	mov    al,BYTE PTR [rdx+rax*1]
  40fbc7:	rex mov BYTE PTR [rsp+0x1f],al
  40fbcc:	xor    eax,eax
  40fbce:	shrx   eax,ecx,eax
  40fbd3:	and    eax,0xf
  40fbd6:	mov    al,BYTE PTR [rdx+rax*1]
  40fbd9:	rex mov BYTE PTR [rsp+0x17],al
  40fbde:	xor    eax,eax
  40fbe0:	shrx   eax,r12d,eax
  40fbe5:	and    eax,0xf
  40fbe8:	mov    al,BYTE PTR [rdx+rax*1]
  40fbeb:	rex mov BYTE PTR [rsp+0x20],al
  40fbf0:	mov    BYTE PTR [r14+0x10],0x2e
  40fbf5:	lea    r12,[rsp+0x22]
  40fbfa:	vxorps xmm0,xmm0,xmm0
  40fbfe:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40fc04:	mov    DWORD PTR [r12],0x6d656d2f
  40fc0c:	mov    WORD PTR [r12+0x4],0x6466
  40fc14:	mov    BYTE PTR [r12+0x6],0x3a
  40fc1a:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40fc20:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40fc26:	mov    rax,QWORD PTR [rsp+0x18]
  40fc2b:	mov    QWORD PTR [rsp+0x39],rax
  40fc30:	rex mov al,BYTE PTR [rsp+0x20]
  40fc35:	rex mov BYTE PTR [rsp+0x41],al
  40fc3a:	mov    DWORD PTR [r12+0x20],0x65642820
  40fc43:	mov    DWORD PTR [r12+0x24],0x6574656c
  40fc4c:	mov    WORD PTR [r12+0x28],0x2964
  40fc54:	lea    rdi,[rip+0x3860]        # 4134bb <__swc_rdata_base_65555ab2+0x3ab>
  40fc5b:	xor    eax,eax
  40fc5d:	call   407140 <opendir@plt>
  40fc62:	mov    r15,rax
  40fc65:	test   rax,rax
  40fc68:	jne    40fc7b <__swc_fn_65555ab2_000107_ff529476+0x30b>
  40fc6a:	movsxd rdi,r13d
  40fc6d:	xor    eax,eax
  40fc6f:	call   4070b0 <close@plt>
  40fc74:	xor    eax,eax
  40fc76:	jmp    40ff26 <__swc_fn_65555ab2_000107_ff529476+0x5b6>
  40fc7b:	mov    rdi,r15
  40fc7e:	xor    eax,eax
  40fc80:	call   407150 <dirfd@plt>
  40fc85:	lea    r14,[rsp+0x54]
  40fc8a:	mov    DWORD PTR [rsp+0x54],eax
  40fc8e:	lea    rbx,[rsp+0x58]
  40fc93:	cs nop WORD PTR [rax+rax*1+0x0]
  40fc9d:	nop    DWORD PTR [rax]
  40fca0:	mov    rdi,r15
  40fca3:	xor    eax,eax
  40fca5:	call   407160 <readdir@plt>
  40fcaa:	test   rax,rax
  40fcad:	jne    40fcc4 <__swc_fn_65555ab2_000107_ff529476+0x354>
  40fcaf:	mov    r12,QWORD PTR [rsp+0xa8]
  40fcb7:	mov    r13,QWORD PTR [rsp+0xb0]
  40fcbf:	jmp    40fe4a <__swc_fn_65555ab2_000107_ff529476+0x4da>
  40fcc4:	vxorps xmm0,xmm0,xmm0
  40fcc8:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  40fcce:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  40fcd4:	vzeroupper
  40fcd7:	lea    r13,[rax+0x13]
  40fcdb:	mov    rax,r14
  40fcde:	movsxd rdi,DWORD PTR [rax]
  40fce1:	mov    rsi,r13
  40fce4:	mov    rdx,rbx
  40fce7:	mov    ecx,0x40
  40fcec:	xor    eax,eax
  40fcee:	call   407170 <readlinkat@plt>
  40fcf3:	cmp    rax,0x2a
  40fcf7:	jne    40fca0 <__swc_fn_65555ab2_000107_ff529476+0x330>
  40fcf9:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40fcff:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40fd05:	vptest xmm0,xmm0
  40fd0a:	jne    40fd3a <__swc_fn_65555ab2_000107_ff529476+0x3ca>
  40fd0c:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40fd12:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40fd18:	vptest xmm0,xmm0
  40fd1d:	jne    40fd3a <__swc_fn_65555ab2_000107_ff529476+0x3ca>
  40fd1f:	mov    rcx,QWORD PTR [rsp+0x42]
  40fd24:	cmp    QWORD PTR [rsp+0x78],rcx
  40fd29:	jne    40fd3a <__swc_fn_65555ab2_000107_ff529476+0x3ca>
  40fd2b:	mov    cx,WORD PTR [rsp+0x4a]
  40fd30:	cmp    WORD PTR [rsp+0x80],cx
  40fd38:	je     40fd64 <__swc_fn_65555ab2_000107_ff529476+0x3f4>
  40fd3a:	mov    rax,rbx
  40fd3d:	mov    rcx,r12
  40fd40:	movzx  edx,BYTE PTR [rax]
  40fd43:	movzx  r8d,BYTE PTR [rcx]
  40fd47:	cmp    rdx,r8
  40fd4a:	jne    40fd56 <__swc_fn_65555ab2_000107_ff529476+0x3e6>
  40fd4c:	add    rax,0x1
  40fd50:	add    rcx,0x1
  40fd54:	jmp    40fd40 <__swc_fn_65555ab2_000107_ff529476+0x3d0>
  40fd56:	mov    rax,rdx
  40fd59:	sub    rax,r8
  40fd5c:	test   eax,eax
  40fd5e:	jne    40fca0 <__swc_fn_65555ab2_000107_ff529476+0x330>
  40fd64:	movsxd rdi,DWORD PTR [r14]
  40fd67:	mov    rsi,r13
  40fd6a:	mov    edx,0x80002
  40fd6f:	xor    eax,eax
  40fd71:	call   407180 <openat@plt>
  40fd76:	lea    rbx,[rsp+0x98]
  40fd7e:	mov    DWORD PTR [rsp+0x98],eax
  40fd85:	test   eax,eax
  40fd87:	mov    r13,QWORD PTR [rsp+0xb0]
  40fd8f:	jge    40fdb4 <__swc_fn_65555ab2_000107_ff529476+0x444>
  40fd91:	mov    rdi,r15
  40fd94:	xor    eax,eax
  40fd96:	call   407190 <closedir@plt>
  40fd9b:	mov    r13,QWORD PTR [rsp+0xb0]
  40fda3:	movsxd rdi,r13d
  40fda6:	xor    eax,eax
  40fda8:	call   4070b0 <close@plt>
  40fdad:	xor    eax,eax
  40fdaf:	jmp    40ff26 <__swc_fn_65555ab2_000107_ff529476+0x5b6>
  40fdb4:	mov    rax,rbx
  40fdb7:	movsxd rdi,DWORD PTR [rax]
  40fdba:	xor    esi,esi
  40fdbc:	mov    edx,0x2
  40fdc1:	xor    eax,eax
  40fdc3:	call   4070a0 <lseek@plt>
  40fdc8:	mov    r12,QWORD PTR [rsp+0xa8]
  40fdd0:	cmp    rax,r12
  40fdd3:	je     40fdfa <__swc_fn_65555ab2_000107_ff529476+0x48a>
  40fdd5:	movsxd rdi,DWORD PTR [rbx]
  40fdd8:	xor    eax,eax
  40fdda:	call   4070b0 <close@plt>
  40fddf:	mov    rdi,r15
  40fde2:	xor    eax,eax
  40fde4:	call   407190 <closedir@plt>
  40fde9:	movsxd rdi,r13d
  40fdec:	xor    eax,eax
  40fdee:	call   4070b0 <close@plt>
  40fdf3:	xor    eax,eax
  40fdf5:	jmp    40ff26 <__swc_fn_65555ab2_000107_ff529476+0x5b6>
  40fdfa:	xor    edi,edi
  40fdfc:	mov    rsi,r12
  40fdff:	mov    edx,0x3
  40fe04:	mov    ecx,0x1
  40fe09:	mov    rax,rbx
  40fe0c:	movsxd r8,DWORD PTR [rax]
  40fe0f:	xor    r9d,r9d
  40fe12:	xor    eax,eax
  40fe14:	call   4070c0 <mmap@plt>
  40fe19:	xor    r12d,r12d
  40fe1c:	cmp    rax,0xffffffffffffffff
  40fe20:	cmovne r12,rax
  40fe24:	movsxd rdi,DWORD PTR [rbx]
  40fe27:	xor    eax,eax
  40fe29:	call   4070b0 <close@plt>
  40fe2e:	mov    rdi,r15
  40fe31:	xor    eax,eax
  40fe33:	call   407190 <closedir@plt>
  40fe38:	movsxd rdi,r13d
  40fe3b:	xor    eax,eax
  40fe3d:	call   4070b0 <close@plt>
  40fe42:	mov    rax,r12
  40fe45:	jmp    40ff26 <__swc_fn_65555ab2_000107_ff529476+0x5b6>
  40fe4a:	mov    r14,QWORD PTR [rsp+0xb8]
  40fe52:	mov    rdi,r14
  40fe55:	mov    esi,0x1
  40fe5a:	xor    eax,eax
  40fe5c:	call   4071a0 <memfd_create@plt>
  40fe61:	lea    rbx,[rsp+0x9c]
  40fe69:	mov    DWORD PTR [rsp+0x9c],eax
  40fe70:	test   eax,eax
  40fe72:	jge    40fe8f <__swc_fn_65555ab2_000107_ff529476+0x51f>
  40fe74:	mov    rdi,r15
  40fe77:	xor    eax,eax
  40fe79:	call   407190 <closedir@plt>
  40fe7e:	movsxd rdi,r13d
  40fe81:	xor    eax,eax
  40fe83:	call   4070b0 <close@plt>
  40fe88:	xor    eax,eax
  40fe8a:	jmp    40ff26 <__swc_fn_65555ab2_000107_ff529476+0x5b6>
  40fe8f:	mov    rax,rbx
  40fe92:	movsxd rdi,DWORD PTR [rax]
  40fe95:	mov    rsi,r12
  40fe98:	xor    eax,eax
  40fe9a:	call   4071b0 <ftruncate@plt>
  40fe9f:	test   eax,eax
  40fea1:	je     40fec5 <__swc_fn_65555ab2_000107_ff529476+0x555>
  40fea3:	movsxd rdi,DWORD PTR [rbx]
  40fea6:	xor    eax,eax
  40fea8:	call   4070b0 <close@plt>
  40fead:	mov    rdi,r15
  40feb0:	xor    eax,eax
  40feb2:	call   407190 <closedir@plt>
  40feb7:	movsxd rdi,r13d
  40feba:	xor    eax,eax
  40febc:	call   4070b0 <close@plt>
  40fec1:	xor    eax,eax
  40fec3:	jmp    40ff26 <__swc_fn_65555ab2_000107_ff529476+0x5b6>
  40fec5:	xor    edi,edi
  40fec7:	mov    rsi,r12
  40feca:	mov    edx,0x3
  40fecf:	mov    ecx,0x1
  40fed4:	mov    rax,rbx
  40fed7:	movsxd r8,DWORD PTR [rax]
  40feda:	xor    r9d,r9d
  40fedd:	xor    eax,eax
  40fedf:	call   4070c0 <mmap@plt>
  40fee4:	mov    r12,rax
  40fee7:	cmp    rax,0xffffffffffffffff
  40feeb:	jne    40ff0f <__swc_fn_65555ab2_000107_ff529476+0x59f>
  40feed:	movsxd rdi,DWORD PTR [rbx]
  40fef0:	xor    eax,eax
  40fef2:	call   4070b0 <close@plt>
  40fef7:	mov    rdi,r15
  40fefa:	xor    eax,eax
  40fefc:	call   407190 <closedir@plt>
  40ff01:	movsxd rdi,r13d
  40ff04:	xor    eax,eax
  40ff06:	call   4070b0 <close@plt>
  40ff0b:	xor    eax,eax
  40ff0d:	jmp    40ff26 <__swc_fn_65555ab2_000107_ff529476+0x5b6>
  40ff0f:	mov    rdi,r15
  40ff12:	xor    eax,eax
  40ff14:	call   407190 <closedir@plt>
  40ff19:	movsxd rdi,r13d
  40ff1c:	xor    eax,eax
  40ff1e:	call   4070b0 <close@plt>
  40ff23:	mov    rax,r12
  40ff26:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40ff2f:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40ff38:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40ff41:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40ff4a:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  40ff53:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40ff5c:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  40ff65:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40ff6e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  40ff77:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  40ff80:	add    rsp,0x170
  40ff87:	pop    r15
  40ff89:	pop    r14
  40ff8b:	pop    r13
  40ff8d:	pop    rsi
  40ff8e:	pop    rdi
  40ff8f:	pop    r12
  40ff91:	pop    rbx
  40ff92:	ret
	...

000000000040ffa0 <__swc_fn_65555ab2_000110_e606239a>:
  40ffa0:	push   rsi
  40ffa1:	push   rdi
  40ffa2:	push   r12
  40ffa4:	push   r13
  40ffa6:	sub    rsp,0x8
  40ffaa:	mov    rsi,r8
  40ffad:	mov    rdi,rcx
  40ffb0:	mov    r12,rdx
  40ffb3:	call   409100 <__swc_fn_65555ab2_000108_32416b9e>
  40ffb8:	mov    r13,rax
  40ffbb:	test   rax,rax
  40ffbe:	jne    40ffcb <__swc_fn_65555ab2_000110_e606239a+0x2b>
  40ffc0:	add    rsp,0x8
  40ffc4:	pop    r13
  40ffc6:	pop    r12
  40ffc8:	pop    rdi
  40ffc9:	pop    rsi
  40ffca:	ret
  40ffcb:	mov    rcx,r13
  40ffce:	call   40cd70 <__swc_fn_65555ab2_000133_c6de0049>
  40ffd3:	mov    rax,QWORD PTR [r13+0x8]
  40ffd7:	test   rax,rax
  40ffda:	je     410019 <__swc_fn_65555ab2_000110_e606239a+0x79>
  40ffdc:	nop    DWORD PTR [rax+0x0]
  40ffe0:	lea    rcx,[rax+0x1000]
  40ffe7:	cmp    rdi,rcx
  40ffea:	jne    410011 <__swc_fn_65555ab2_000110_e606239a+0x71>
  40ffec:	cmp    r12,0x1000
  40fff3:	jb     410011 <__swc_fn_65555ab2_000110_e606239a+0x71>
  40fff5:	test   sil,sil
  40fff8:	setne  cl
  40fffb:	mov    BYTE PTR [rax+0x10],cl
  40fffe:	mov    rcx,r13
  410001:	call   410500 <__swc_fn_65555ab2_000134_5696c87e>
  410006:	add    rsp,0x8
  41000a:	pop    r13
  41000c:	pop    r12
  41000e:	pop    rdi
  41000f:	pop    rsi
  410010:	ret
  410011:	mov    rax,QWORD PTR [rax]
  410014:	test   rax,rax
  410017:	jne    40ffe0 <__swc_fn_65555ab2_000110_e606239a+0x40>
  410019:	mov    rcx,r13
  41001c:	call   410500 <__swc_fn_65555ab2_000134_5696c87e>
  410021:	add    rsp,0x8
  410025:	pop    r13
  410027:	pop    r12
  410029:	pop    rdi
  41002a:	pop    rsi
  41002b:	ret
  41002c:	add    BYTE PTR [rax],al
	...

0000000000410030 <__swc_fn_65555ab2_000113_25e345b1>:
  410030:	sub    rsp,0x8
  410034:	test   rcx,rcx
  410037:	jne    41003e <__swc_fn_65555ab2_000113_25e345b1+0xe>
  410039:	add    rsp,0x8
  41003d:	ret
  41003e:	call   40c880 <__swc_fn_65555ab2_000115_259b5d5a>
  410043:	add    rsp,0x8
  410047:	ret
	...

0000000000410050 <__swc_fn_65555ab2_000116_3499f7d6>:
  410050:	push   r12
  410052:	push   r13
  410054:	push   r14
  410056:	push   rdi
  410057:	push   rsi
  410058:	sub    rsp,0xc0
  41005f:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  410065:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  41006b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  410071:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410077:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  41007d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  410083:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410089:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  410092:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  41009b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4100a4:	mov    r12,QWORD PTR [rcx]
  4100a7:	test   r12,r12
  4100aa:	jne    4100bc <__swc_fn_65555ab2_000116_3499f7d6+0x6c>
  4100ac:	add    rsp,0xc0
  4100b3:	pop    rsi
  4100b4:	pop    rdi
  4100b5:	pop    r14
  4100b7:	pop    r13
  4100b9:	pop    r12
  4100bb:	ret
  4100bc:	xor    r13d,r13d
  4100bf:	mov    r14,QWORD PTR [rcx+0x8]
  4100c3:	cs nop WORD PTR [rax+rax*1+0x0]
  4100cd:	nop    DWORD PTR [rax]
  4100d0:	cmp    r13,r14
  4100d3:	jae    41010b <__swc_fn_65555ab2_000116_3499f7d6+0xbb>
  4100d5:	lea    rax,[r12+r13*1]
  4100d9:	mov    rcx,r14
  4100dc:	sub    rcx,r13
  4100df:	mov    edi,0x1
  4100e4:	mov    rsi,rax
  4100e7:	mov    rdx,rcx
  4100ea:	xor    eax,eax
  4100ec:	call   4071c0 <write@plt>
  4100f1:	test   rax,rax
  4100f4:	jle    4100fb <__swc_fn_65555ab2_000116_3499f7d6+0xab>
  4100f6:	add    r13,rax
  4100f9:	jmp    4100d0 <__swc_fn_65555ab2_000116_3499f7d6+0x80>
  4100fb:	je     410109 <__swc_fn_65555ab2_000116_3499f7d6+0xb9>
  4100fd:	xor    eax,eax
  4100ff:	call   407130 <__errno_location@plt>
  410104:	cmp    DWORD PTR [rax],0x4
  410107:	je     4100d0 <__swc_fn_65555ab2_000116_3499f7d6+0x80>
  410109:	jmp    41010b <__swc_fn_65555ab2_000116_3499f7d6+0xbb>
  41010b:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410111:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  410117:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  41011d:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  410123:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410129:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  41012f:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  410135:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  41013e:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  410147:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410150:	add    rsp,0xc0
  410157:	pop    rsi
  410158:	pop    rdi
  410159:	pop    r14
  41015b:	pop    r13
  41015d:	pop    r12
  41015f:	ret

0000000000410160 <__swc_fn_65555ab2_000119_18cd3882>:
  410160:	push   rbx
  410161:	push   r12
  410163:	push   rdi
  410164:	push   rsi
  410165:	sub    rsp,0x4a8
  41016c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  410175:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  41017e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  410187:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  410190:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  410199:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  4101a2:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  4101ab:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  4101b4:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  4101bd:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  4101c6:	mov    rbx,rdx
  4101c9:	mov    r12d,ecx
  4101cc:	vxorps xmm0,xmm0,xmm0
  4101d0:	xor    eax,eax
  4101d2:	cs nop WORD PTR [rax+rax*1+0x0]
  4101dc:	nop    DWORD PTR [rax+0x0]
  4101e0:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  4101e6:	add    rax,0x10
  4101ea:	cmp    rax,0x400
  4101f1:	jne    4101e0 <__swc_fn_65555ab2_000119_18cd3882+0x80>
  4101f3:	lea    rdi,[rsp+0x8]
  4101f8:	mov    esi,0x80
  4101fd:	xor    eax,eax
  4101ff:	call   4071d0 <backtrace@plt>
  410204:	test   eax,eax
  410206:	jle    410215 <__swc_fn_65555ab2_000119_18cd3882+0xb5>
  410208:	movsxd rax,eax
  41020b:	lea    rcx,[r12+0x1]
  410210:	cmp    rcx,rax
  410213:	jb     410219 <__swc_fn_65555ab2_000119_18cd3882+0xb9>
  410215:	xor    eax,eax
  410217:	jmp    41024a <__swc_fn_65555ab2_000119_18cd3882+0xea>
  410219:	mov    rcx,QWORD PTR [rbx+0x8]
  41021d:	sub    rax,r12
  410220:	lea    rsi,[rax-0x1]
  410224:	cmp    rcx,rsi
  410227:	cmovbe rsi,rcx
  41022b:	lea    eax,[r12+0x1]
  410230:	lea    rax,[rsp+rax*8+0x8]
  410235:	mov    rcx,QWORD PTR [rbx]
  410238:	mov    rdx,rax
  41023b:	lea    r8,[rsi*8+0x0]
  410243:	call   4090e0 <__swc_fn_65555ab2_000105_b7aef7c0>
  410248:	mov    eax,esi
  41024a:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  410253:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  41025c:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  410265:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  41026e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  410277:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  410280:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  410289:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  410292:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  41029b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  4102a4:	add    rsp,0x4a8
  4102ab:	pop    rsi
  4102ac:	pop    rdi
  4102ad:	pop    r12
  4102af:	pop    rbx
  4102b0:	ret
	...

00000000004102c0 <__swc_fn_65555ab2_000122_c37da69c>:
  4102c0:	mov    QWORD PTR [rcx],0x0
  4102c7:	ret
	...

00000000004102d0 <__swc_fn_65555ab2_000125_e19c72b3>:
  4102d0:	push   rdi
  4102d1:	push   rsi
  4102d2:	sub    rsp,0xa8
  4102d9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4102df:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4102e5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4102eb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4102f1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4102f7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4102fd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410303:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410309:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410312:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41031b:	mov    edi,ecx
  41031d:	mov    rsi,rdx
  410320:	xor    eax,eax
  410322:	call   407060 <pthread_setspecific@plt>
  410327:	test   eax,eax
  410329:	sete   al
  41032c:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  410332:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410338:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  41033e:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  410344:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  41034a:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410350:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  410356:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  41035c:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  410365:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  41036e:	add    rsp,0xa8
  410375:	pop    rsi
  410376:	pop    rdi
  410377:	ret
	...

0000000000410380 <__swc_fn_65555ab2_000128_9c45d2d7>:
  410380:	push   rdi
  410381:	push   rsi
  410382:	sub    rsp,0xa8
  410389:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41038f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410395:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41039b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4103a1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4103a7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4103ad:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4103b3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4103b9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4103c2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4103cb:	test   rcx,rcx
  4103ce:	je     4103e1 <__swc_fn_65555ab2_000128_9c45d2d7+0x61>
  4103d0:	lea    rax,[rcx-0x1]
  4103d4:	mov    eax,eax
  4103d6:	mov    edi,eax
  4103d8:	xor    eax,eax
  4103da:	call   407000 <pthread_getspecific@plt>
  4103df:	jmp    4103e3 <__swc_fn_65555ab2_000128_9c45d2d7+0x63>
  4103e1:	xor    eax,eax
  4103e3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4103e9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4103ef:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4103f5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4103fb:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410401:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410407:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41040d:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410413:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41041c:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410425:	add    rsp,0xa8
  41042c:	pop    rsi
  41042d:	pop    rdi
  41042e:	ret
	...

0000000000410430 <__swc_fn_65555ab2_000131_dc04d759>:
  410430:	push   rdi
  410431:	push   rsi
  410432:	sub    rsp,0xb8
  410439:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41043f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410445:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41044b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410451:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410457:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41045d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410463:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41046c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410475:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41047e:	vxorps xmm0,xmm0,xmm0
  410482:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  410488:	mov    edi,0x1
  41048d:	lea    rsi,[rsp+0x8]
  410492:	xor    eax,eax
  410494:	call   4070e0 <clock_gettime@plt>
  410499:	mov    rax,QWORD PTR [rsp+0x8]
  41049e:	imul   rax,rax,0x3b9aca00
  4104a5:	add    rax,QWORD PTR [rsp+0x10]
  4104aa:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4104b0:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4104b6:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4104bc:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4104c2:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4104c8:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4104ce:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4104d4:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4104dd:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4104e6:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4104ef:	add    rsp,0xb8
  4104f6:	pop    rsi
  4104f7:	pop    rdi
  4104f8:	ret
  4104f9:	add    BYTE PTR [rax],al
  4104fb:	add    BYTE PTR [rax],al
  4104fd:	add    BYTE PTR [rax],al
	...

0000000000410500 <__swc_fn_65555ab2_000134_5696c87e>:
  410500:	sub    rsp,0x8
  410504:	xor    eax,eax
  410506:	mov    DWORD PTR [rcx],eax
  410508:	mov    edx,0x7fffffff
  41050d:	call   4097e0 <__swc_fn_65555ab2_000132_2b60f756>
  410512:	add    rsp,0x8
  410516:	ret
	...

0000000000410520 <__swc_fn_65555ab2_000137_899a611e>:
  410520:	push   rdi
  410521:	push   rsi
  410522:	sub    rsp,0xb8
  410529:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  41052f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  410535:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  41053b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  410541:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  410547:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  41054d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  410553:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  41055c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410565:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41056e:	mov    edi,0x1
  410573:	xor    eax,eax
  410575:	call   4071e0 <__x86_get_cpuid_feature_leaf@plt>
  41057a:	mov    eax,DWORD PTR [rax+0x14]
  41057d:	and    eax,0x20
  410580:	setne  al
  410583:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410589:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  41058f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410595:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41059b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4105a1:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4105a7:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4105ad:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4105b6:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  4105bf:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  4105c8:	add    rsp,0xb8
  4105cf:	pop    rsi
  4105d0:	pop    rdi
  4105d1:	ret
	...

00000000004105e0 <__swc_fn_65555ab2_000140_81b740ca>:
  4105e0:	push   rsi
  4105e1:	push   rdi
  4105e2:	push   r12
  4105e4:	push   r13
  4105e6:	push   r14
  4105e8:	push   r15
  4105ea:	cmp    rdx,0x40
  4105ee:	jae    4105fd <__swc_fn_65555ab2_000140_81b740ca+0x1d>
  4105f0:	xor    eax,eax
  4105f2:	pop    r15
  4105f4:	pop    r14
  4105f6:	pop    r13
  4105f8:	pop    r12
  4105fa:	pop    rdi
  4105fb:	pop    rsi
  4105fc:	ret
  4105fd:	cmp    BYTE PTR [rcx],0x7f
  410600:	jne    410644 <__swc_fn_65555ab2_000140_81b740ca+0x64>
  410602:	movzx  eax,BYTE PTR [rcx+0x1]
  410606:	cmp    eax,0x45
  410609:	setne  al
  41060c:	jne    410640 <__swc_fn_65555ab2_000140_81b740ca+0x60>
  41060e:	movzx  eax,BYTE PTR [rcx+0x2]
  410612:	cmp    eax,0x4c
  410615:	setne  al
  410618:	jne    410640 <__swc_fn_65555ab2_000140_81b740ca+0x60>
  41061a:	movzx  eax,BYTE PTR [rcx+0x3]
  41061e:	cmp    eax,0x46
  410621:	setne  al
  410624:	jne    410640 <__swc_fn_65555ab2_000140_81b740ca+0x60>
  410626:	cmp    BYTE PTR [rcx+0x4],0x2
  41062a:	setne  al
  41062d:	jne    410640 <__swc_fn_65555ab2_000140_81b740ca+0x60>
  41062f:	cmp    BYTE PTR [rcx+0x5],0x1
  410633:	setne  al
  410636:	jne    410640 <__swc_fn_65555ab2_000140_81b740ca+0x60>
  410638:	cmp    WORD PTR [rcx+0x12],0x3e
  41063d:	setne  al
  410640:	test   al,al
  410642:	je     410651 <__swc_fn_65555ab2_000140_81b740ca+0x71>
  410644:	xor    eax,eax
  410646:	pop    r15
  410648:	pop    r14
  41064a:	pop    r13
  41064c:	pop    r12
  41064e:	pop    rdi
  41064f:	pop    rsi
  410650:	ret
  410651:	cmp    WORD PTR [rcx+0x3a],0x40
  410656:	jne    410671 <__swc_fn_65555ab2_000140_81b740ca+0x91>
  410658:	cmp    WORD PTR [rcx+0x3c],0x0
  41065d:	sete   al
  410660:	je     41066d <__swc_fn_65555ab2_000140_81b740ca+0x8d>
  410662:	mov    ax,WORD PTR [rcx+0x3c]
  410666:	cmp    WORD PTR [rcx+0x3e],ax
  41066a:	setae  al
  41066d:	test   al,al
  41066f:	je     41067e <__swc_fn_65555ab2_000140_81b740ca+0x9e>
  410671:	xor    eax,eax
  410673:	pop    r15
  410675:	pop    r14
  410677:	pop    r13
  410679:	pop    r12
  41067b:	pop    rdi
  41067c:	pop    rsi
  41067d:	ret
  41067e:	movzx  eax,WORD PTR [rcx+0x3c]
  410682:	shl    rax,0x6
  410686:	cmp    rax,rdx
  410689:	ja     410697 <__swc_fn_65555ab2_000140_81b740ca+0xb7>
  41068b:	mov    r9,rdx
  41068e:	sub    r9,rax
  410691:	cmp    QWORD PTR [rcx+0x28],r9
  410695:	jbe    4106a4 <__swc_fn_65555ab2_000140_81b740ca+0xc4>
  410697:	xor    eax,eax
  410699:	pop    r15
  41069b:	pop    r14
  41069d:	pop    r13
  41069f:	pop    r12
  4106a1:	pop    rdi
  4106a2:	pop    rsi
  4106a3:	ret
  4106a4:	mov    rax,QWORD PTR [rcx+0x28]
  4106a8:	add    rax,rcx
  4106ab:	movzx  r9d,WORD PTR [rcx+0x3e]
  4106b0:	lea    r9,[r9*8+0x0]
  4106b8:	lea    r10,[rax+r9*8]
  4106bc:	cmp    QWORD PTR [r10+0x20],rdx
  4106c0:	ja     4106e2 <__swc_fn_65555ab2_000140_81b740ca+0x102>
  4106c2:	mov    r11,rdx
  4106c5:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  4106ca:	cmp    QWORD PTR [r10+0x18],r11
  4106ce:	seta   r9b
  4106d2:	ja     4106dd <__swc_fn_65555ab2_000140_81b740ca+0xfd>
  4106d4:	cmp    QWORD PTR [r10+0x20],0x9
  4106d9:	setb   r9b
  4106dd:	test   r9b,r9b
  4106e0:	je     4106ef <__swc_fn_65555ab2_000140_81b740ca+0x10f>
  4106e2:	xor    eax,eax
  4106e4:	pop    r15
  4106e6:	pop    r14
  4106e8:	pop    r13
  4106ea:	pop    r12
  4106ec:	pop    rdi
  4106ed:	pop    rsi
  4106ee:	ret
  4106ef:	movzx  r9d,WORD PTR [rcx+0x3c]
  4106f4:	xor    r11d,r11d
  4106f7:	test   r9,r9
  4106fa:	jbe    4107f5 <__swc_fn_65555ab2_000140_81b740ca+0x215>
  410700:	mov    rsi,QWORD PTR [r10+0x20]
  410704:	sub    rsi,0x9
  410708:	cs nop WORD PTR [rax+rax*1+0x0]
  410712:	cs nop WORD PTR [rax+rax*1+0x0]
  41071c:	nop    DWORD PTR [rax+0x0]
  410720:	movzx  edi,r11w
  410724:	lea    rdi,[rdi*8+0x0]
  41072c:	lea    r12,[rax+rdi*8]
  410730:	rex mov edi,DWORD PTR [rax+rdi*8]
  410734:	cmp    rdi,rsi
  410737:	ja     4107e8 <__swc_fn_65555ab2_000140_81b740ca+0x208>
  41073d:	mov    r13,QWORD PTR [r10+0x18]
  410741:	add    r13,rdi
  410744:	lea    rdi,[rcx+r13*1]
  410748:	lea    r13,[rip+0x2de1]        # 413530 <__swc_rdata_base_65555ab2+0x420>
  41074f:	movabs r14,0x676264676177732e
  410759:	cmp    QWORD PTR [rdi],r14
  41075c:	jne    410765 <__swc_fn_65555ab2_000140_81b740ca+0x185>
  41075e:	rex cmp BYTE PTR [rdi+0x8],0x0
  410763:	je     410792 <__swc_fn_65555ab2_000140_81b740ca+0x1b2>
  410765:	cs nop WORD PTR [rax+rax*1+0x0]
  41076f:	nop
  410770:	movzx  r14d,BYTE PTR [rdi]
  410774:	movzx  r15d,BYTE PTR [r13+0x0]
  410779:	cmp    r14,r15
  41077c:	jne    410788 <__swc_fn_65555ab2_000140_81b740ca+0x1a8>
  41077e:	add    rdi,0x1
  410782:	add    r13,0x1
  410786:	jmp    410770 <__swc_fn_65555ab2_000140_81b740ca+0x190>
  410788:	mov    rdi,r14
  41078b:	sub    rdi,r15
  41078e:	test   edi,edi
  410790:	jne    4107e8 <__swc_fn_65555ab2_000140_81b740ca+0x208>
  410792:	cmp    DWORD PTR [r12+0x4],0x1
  410798:	jne    4107c0 <__swc_fn_65555ab2_000140_81b740ca+0x1e0>
  41079a:	cmp    QWORD PTR [r12+0x20],0x10
  4107a0:	setb   al
  4107a3:	jb     4107bc <__swc_fn_65555ab2_000140_81b740ca+0x1dc>
  4107a5:	cmp    QWORD PTR [r12+0x20],rdx
  4107aa:	seta   al
  4107ad:	ja     4107bc <__swc_fn_65555ab2_000140_81b740ca+0x1dc>
  4107af:	sub    rdx,QWORD PTR [r12+0x20]
  4107b4:	cmp    QWORD PTR [r12+0x18],rdx
  4107b9:	seta   al
  4107bc:	test   al,al
  4107be:	je     4107cd <__swc_fn_65555ab2_000140_81b740ca+0x1ed>
  4107c0:	xor    eax,eax
  4107c2:	pop    r15
  4107c4:	pop    r14
  4107c6:	pop    r13
  4107c8:	pop    r12
  4107ca:	pop    rdi
  4107cb:	pop    rsi
  4107cc:	ret
  4107cd:	mov    rax,QWORD PTR [r12+0x20]
  4107d2:	mov    QWORD PTR [r8],rax
  4107d5:	mov    rax,QWORD PTR [r12+0x18]
  4107da:	add    rax,rcx
  4107dd:	pop    r15
  4107df:	pop    r14
  4107e1:	pop    r13
  4107e3:	pop    r12
  4107e5:	pop    rdi
  4107e6:	pop    rsi
  4107e7:	ret
  4107e8:	add    r11,0x1
  4107ec:	cmp    r11,r9
  4107ef:	jb     410720 <__swc_fn_65555ab2_000140_81b740ca+0x140>
  4107f5:	xor    eax,eax
  4107f7:	pop    r15
  4107f9:	pop    r14
  4107fb:	pop    r13
  4107fd:	pop    r12
  4107ff:	pop    rdi
  410800:	pop    rsi
  410801:	ret
	...

0000000000410810 <__swc_fn_65555ab2_000143_afffe963>:
  410810:	push   rdi
  410811:	push   rsi
  410812:	sub    rsp,0xa8
  410819:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  41081f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  410825:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  41082b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  410831:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  410837:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  41083d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  410843:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  410849:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  410852:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  41085b:	mov    rdi,rcx
  41085e:	xor    eax,eax
  410860:	call   4071f0 <free@plt>
  410865:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41086b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410871:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410877:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41087d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410883:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410889:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41088f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410895:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41089e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4108a7:	add    rsp,0xa8
  4108ae:	pop    rsi
  4108af:	pop    rdi
  4108b0:	ret
	...

00000000004108c0 <__swc_fn_65555ab2_000146_e9d46966>:
  4108c0:	push   rbx
  4108c1:	push   rsi
  4108c2:	push   rdi
  4108c3:	push   r12
  4108c5:	push   r13
  4108c7:	push   r15
  4108c9:	sub    rsp,0x4e8
  4108d0:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  4108d9:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  4108e2:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  4108eb:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  4108f4:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  4108fd:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  410906:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  41090f:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  410918:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  410921:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  41092a:	mov    rbx,QWORD PTR [rcx]
  41092d:	mov    rcx,QWORD PTR [rcx+0x8]
  410931:	mov    rsi,rcx
  410934:	xor    edi,edi
  410936:	vmovsd xmm6,QWORD PTR [rip+0x2c52]        # 413590 <__swc_rdata_base_65555ab2+0x480>
  41093e:	vmovsd xmm7,QWORD PTR [rip+0x2c53]        # 413599 <__swc_rdata_base_65555ab2+0x489>
  410946:	vmovsd xmm8,QWORD PTR [rip+0x2c54]        # 4135a2 <__swc_rdata_base_65555ab2+0x492>
  41094e:	vmovsd xmm9,QWORD PTR [rip+0x2c55]        # 4135ab <__swc_rdata_base_65555ab2+0x49b>
  410956:	vmovsd xmm10,QWORD PTR [rip+0x2c56]        # 4135b4 <__swc_rdata_base_65555ab2+0x4a4>
  41095e:	vmovups xmm11,xmm6
  410962:	vmovsd QWORD PTR [rsp+0x418],xmm7
  41096b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  410974:	vmovsd QWORD PTR [rsp+0x428],xmm9
  41097d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  410986:	vmovsd xmm15,QWORD PTR [rip+0x2c2f]        # 4135bd <__swc_rdata_base_65555ab2+0x4ad>
  41098e:	vmovups xmm14,xmm15
  410993:	vmovups xmm0,xmm9
  410998:	vmovsd QWORD PTR [rsp+0x438],xmm15
  4109a1:	vmovups xmm13,xmm8
  4109a6:	vmovsd QWORD PTR [rsp+0x440],xmm15
  4109af:	test   rsi,rsi
  4109b2:	je     4119a3 <__swc_fn_65555ab2_000146_e9d46966+0x10e3>
  4109b8:	cs nop WORD PTR [rax+rax*1+0x0]
  4109c2:	cs nop WORD PTR [rax+rax*1+0x0]
  4109cc:	nop    DWORD PTR [rax+0x0]
  4109d0:	lea    rcx,[rdi+rdi*1]
  4109d4:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  4109d9:	vpshufd xmm3,xmm2,0xee
  4109de:	vmovq  rcx,xmm3
  4109e3:	test   rcx,rcx
  4109e6:	je     4109fc <__swc_fn_65555ab2_000146_e9d46966+0x13c>
  4109e8:	test   DWORD PTR [rcx+0x28],0x400000
  4109ef:	je     4109fc <__swc_fn_65555ab2_000146_e9d46966+0x13c>
  4109f1:	mov    rdx,QWORD PTR [rcx+0x30]
  4109f5:	test   rdx,rdx
  4109f8:	cmovne rcx,rdx
  4109fc:	test   DWORD PTR [rcx+0x28],0x1000
  410a03:	je     410a24 <__swc_fn_65555ab2_000146_e9d46966+0x164>
  410a05:	mov    rdx,QWORD PTR [rcx+0x40]
  410a09:	mov    rcx,rdx
  410a0c:	vmovq  r8,xmm2
  410a11:	mov    r8,QWORD PTR [r8]
  410a14:	mov    QWORD PTR [rsp+0x60],r8
  410a19:	mov    QWORD PTR [rsp+0x68],rdx
  410a1e:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  410a24:	test   BYTE PTR [rcx+0x28],0x1
  410a28:	jne    410a30 <__swc_fn_65555ab2_000146_e9d46966+0x170>
  410a2a:	vmovups xmm12,xmm0
  410a2e:	jmp    410a4a <__swc_fn_65555ab2_000146_e9d46966+0x18a>
  410a30:	vmovq  rax,xmm2
  410a35:	mov    rax,QWORD PTR [rax]
  410a38:	lea    rcx,[rax+0x10]
  410a3c:	vmovups xmm12,xmm0
  410a40:	call   410050 <__swc_fn_65555ab2_000116_3499f7d6>
  410a45:	jmp    411985 <__swc_fn_65555ab2_000146_e9d46966+0x10c5>
  410a4a:	test   DWORD PTR [rcx+0x28],0x400
  410a51:	je     410ab2 <__swc_fn_65555ab2_000146_e9d46966+0x1f2>
  410a53:	vmovq  rax,xmm2
  410a58:	mov    rax,QWORD PTR [rax]
  410a5b:	xor    ecx,ecx
  410a5d:	test   rax,rax
  410a60:	je     410a90 <__swc_fn_65555ab2_000146_e9d46966+0x1d0>
  410a62:	mov    rdx,rax
  410a65:	mov    r8b,BYTE PTR [rdx]
  410a68:	test   r8b,r8b
  410a6b:	je     410a90 <__swc_fn_65555ab2_000146_e9d46966+0x1d0>
  410a6d:	cs nop WORD PTR [rax+rax*1+0x0]
  410a77:	nop    WORD PTR [rax+rax*1+0x0]
  410a80:	add    rdx,0x1
  410a84:	add    rcx,0x1
  410a88:	mov    r8b,BYTE PTR [rdx]
  410a8b:	test   r8b,r8b
  410a8e:	jne    410a80 <__swc_fn_65555ab2_000146_e9d46966+0x1c0>
  410a90:	mov    QWORD PTR [rsp+0x88],rax
  410a98:	mov    QWORD PTR [rsp+0x90],rcx
  410aa0:	lea    rcx,[rsp+0x88]
  410aa8:	call   410050 <__swc_fn_65555ab2_000116_3499f7d6>
  410aad:	jmp    411985 <__swc_fn_65555ab2_000146_e9d46966+0x10c5>
  410ab2:	cmp    BYTE PTR [rcx+0x2c],0x6
  410ab6:	jne    410acd <__swc_fn_65555ab2_000146_e9d46966+0x20d>
  410ab8:	vmovq  rax,xmm2
  410abd:	mov    rax,QWORD PTR [rax]
  410ac0:	mov    rcx,rax
  410ac3:	call   409cb0 <__swc_fn_65555ab2_000144_364559f5>
  410ac8:	jmp    411985 <__swc_fn_65555ab2_000146_e9d46966+0x10c5>
  410acd:	cmp    BYTE PTR [rcx+0x2c],0x1
  410ad1:	jne    411979 <__swc_fn_65555ab2_000146_e9d46966+0x10b9>
  410ad7:	vmovq  rdx,xmm2
  410adc:	mov    cl,BYTE PTR [rcx+0x40]
  410adf:	cmp    cl,0x7
  410ae2:	jb     410b25 <__swc_fn_65555ab2_000146_e9d46966+0x265>
  410ae4:	je     410b98 <__swc_fn_65555ab2_000146_e9d46966+0x2d8>
  410aea:	cmp    cl,0x8
  410aed:	je     410ba4 <__swc_fn_65555ab2_000146_e9d46966+0x2e4>
  410af3:	cmp    cl,0x9
  410af6:	je     410bbd <__swc_fn_65555ab2_000146_e9d46966+0x2fd>
  410afc:	cmp    cl,0xa
  410aff:	je     411284 <__swc_fn_65555ab2_000146_e9d46966+0x9c4>
  410b05:	cmp    cl,0xb
  410b08:	je     41194b <__swc_fn_65555ab2_000146_e9d46966+0x108b>
  410b0e:	cmp    cl,0xc
  410b11:	je     410bb1 <__swc_fn_65555ab2_000146_e9d46966+0x2f1>
  410b17:	cmp    cl,0xd
  410b1a:	je     411941 <__swc_fn_65555ab2_000146_e9d46966+0x1081>
  410b20:	jmp    41196b <__swc_fn_65555ab2_000146_e9d46966+0x10ab>
  410b25:	cmp    cl,0x1
  410b28:	je     410b48 <__swc_fn_65555ab2_000146_e9d46966+0x288>
  410b2a:	cmp    cl,0x2
  410b2d:	je     410b56 <__swc_fn_65555ab2_000146_e9d46966+0x296>
  410b2f:	cmp    cl,0x3
  410b32:	je     410b64 <__swc_fn_65555ab2_000146_e9d46966+0x2a4>
  410b34:	cmp    cl,0x4
  410b37:	je     410b71 <__swc_fn_65555ab2_000146_e9d46966+0x2b1>
  410b39:	cmp    cl,0x5
  410b3c:	je     410b7e <__swc_fn_65555ab2_000146_e9d46966+0x2be>
  410b3e:	cmp    cl,0x6
  410b41:	je     410b8b <__swc_fn_65555ab2_000146_e9d46966+0x2cb>
  410b43:	jmp    41196b <__swc_fn_65555ab2_000146_e9d46966+0x10ab>
  410b48:	movsx  rcx,BYTE PTR [rdx]
  410b4c:	call   40cf60 <__swc_fn_65555ab2_000145_071b4f4c>
  410b51:	jmp    411985 <__swc_fn_65555ab2_000146_e9d46966+0x10c5>
  410b56:	movsx  rcx,WORD PTR [rdx]
  410b5a:	call   40cf60 <__swc_fn_65555ab2_000145_071b4f4c>
  410b5f:	jmp    411985 <__swc_fn_65555ab2_000146_e9d46966+0x10c5>
  410b64:	movsxd rcx,DWORD PTR [rdx]
  410b67:	call   40cf60 <__swc_fn_65555ab2_000145_071b4f4c>
  410b6c:	jmp    411985 <__swc_fn_65555ab2_000146_e9d46966+0x10c5>
  410b71:	mov    rcx,QWORD PTR [rdx]
  410b74:	call   40cf60 <__swc_fn_65555ab2_000145_071b4f4c>
  410b79:	jmp    411985 <__swc_fn_65555ab2_000146_e9d46966+0x10c5>
  410b7e:	movzx  ecx,BYTE PTR [rdx]
  410b81:	call   409cb0 <__swc_fn_65555ab2_000144_364559f5>
  410b86:	jmp    411985 <__swc_fn_65555ab2_000146_e9d46966+0x10c5>
  410b8b:	movzx  ecx,WORD PTR [rdx]
  410b8e:	call   409cb0 <__swc_fn_65555ab2_000144_364559f5>
  410b93:	jmp    411985 <__swc_fn_65555ab2_000146_e9d46966+0x10c5>
  410b98:	mov    ecx,DWORD PTR [rdx]
  410b9a:	call   409cb0 <__swc_fn_65555ab2_000144_364559f5>
  410b9f:	jmp    411985 <__swc_fn_65555ab2_000146_e9d46966+0x10c5>
  410ba4:	mov    rcx,QWORD PTR [rdx]
  410ba7:	call   409cb0 <__swc_fn_65555ab2_000144_364559f5>
  410bac:	jmp    411985 <__swc_fn_65555ab2_000146_e9d46966+0x10c5>
  410bb1:	mov    ecx,DWORD PTR [rdx]
  410bb3:	call   409cb0 <__swc_fn_65555ab2_000144_364559f5>
  410bb8:	jmp    411985 <__swc_fn_65555ab2_000146_e9d46966+0x10c5>
  410bbd:	lea    rcx,[rsp+0xa8]
  410bc5:	vxorps xmm0,xmm0,xmm0
  410bc9:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  410bd2:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  410bdb:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  410be4:	vzeroupper
  410be7:	mov    DWORD PTR [rsp+0x108],0x0
  410bf2:	vxorpd xmm0,xmm0,xmm0
  410bf6:	vmovss xmm1,DWORD PTR [rdx]
  410bfa:	vcvtss2sd xmm0,xmm0,xmm1
  410bfe:	vmovsd xmm1,xmm1,xmm0
  410c02:	vcomisd xmm0,xmm0
  410c06:	setne  dl
  410c09:	movzx  edx,dl
  410c0c:	setp   r8b
  410c10:	movzx  r8d,r8b
  410c14:	or     edx,r8d
  410c17:	test   dl,dl
  410c19:	je     410c26 <__swc_fn_65555ab2_000146_e9d46966+0x366>
  410c1b:	mov    DWORD PTR [rcx],0x6e616e
  410c21:	jmp    411218 <__swc_fn_65555ab2_000146_e9d46966+0x958>
  410c26:	vcomisd xmm1,xmm6
  410c2a:	ja     410c32 <__swc_fn_65555ab2_000146_e9d46966+0x372>
  410c2c:	vcomisd xmm7,xmm1
  410c30:	jbe    410c56 <__swc_fn_65555ab2_000146_e9d46966+0x396>
  410c32:	vxorpd xmm0,xmm0,xmm0
  410c36:	vcomisd xmm0,xmm1
  410c3a:	jbe    410c4b <__swc_fn_65555ab2_000146_e9d46966+0x38b>
  410c3c:	mov    DWORD PTR [rcx],0x666e692d
  410c42:	mov    BYTE PTR [rcx+0x4],0x0
  410c46:	jmp    411218 <__swc_fn_65555ab2_000146_e9d46966+0x958>
  410c4b:	mov    DWORD PTR [rcx],0x666e69
  410c51:	jmp    411218 <__swc_fn_65555ab2_000146_e9d46966+0x958>
  410c56:	vcomisd xmm1,xmm8
  410c5b:	jae    410c67 <__swc_fn_65555ab2_000146_e9d46966+0x3a7>
  410c5d:	vcomisd xmm9,xmm1
  410c61:	jbe    410fde <__swc_fn_65555ab2_000146_e9d46966+0x71e>
  410c67:	vmovups xmm0,xmm1
  410c6b:	vxorpd xmm2,xmm2,xmm2
  410c6f:	vcomisd xmm2,xmm1
  410c73:	jbe    410c83 <__swc_fn_65555ab2_000146_e9d46966+0x3c3>
  410c75:	vmovsd xmm1,xmm1,xmm0
  410c79:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x28cf]        # 413550 <__swc_rdata_base_65555ab2+0x440>
  410c81:	jmp    410c87 <__swc_fn_65555ab2_000146_e9d46966+0x3c7>
  410c83:	vmovsd xmm1,xmm1,xmm0
  410c87:	xor    r8d,r8d
  410c8a:	vcomisd xmm1,xmm15
  410c8f:	jb     410cb0 <__swc_fn_65555ab2_000146_e9d46966+0x3f0>
  410c91:	cs nop WORD PTR [rax+rax*1+0x0]
  410c9b:	nop    DWORD PTR [rax+rax*1+0x0]
  410ca0:	vdivsd xmm1,xmm1,xmm15
  410ca5:	add    r8,0x1
  410ca9:	vcomisd xmm1,xmm15
  410cae:	jae    410ca0 <__swc_fn_65555ab2_000146_e9d46966+0x3e0>
  410cb0:	mov    r9,rcx
  410cb3:	vxorpd xmm2,xmm2,xmm2
  410cb7:	vcomisd xmm2,xmm0
  410cbb:	jbe    410cc4 <__swc_fn_65555ab2_000146_e9d46966+0x404>
  410cbd:	mov    BYTE PTR [rcx],0x2d
  410cc0:	lea    r9,[rcx+0x1]
  410cc4:	vcvttsd2si rdx,xmm1
  410cc9:	mov    r10b,dl
  410ccc:	add    r10b,0x30
  410cd0:	mov    BYTE PTR [r9],r10b
  410cd3:	vxorpd xmm0,xmm0,xmm0
  410cd7:	movzx  edx,dl
  410cda:	vcvtsi2sd xmm0,xmm0,rdx
  410cdf:	vsubsd xmm0,xmm1,xmm0
  410ce3:	vmulsd xmm1,xmm0,xmm15
  410ce8:	mov    BYTE PTR [r9+0x1],0x2e
  410ced:	vcvttsd2si rdx,xmm1
  410cf2:	mov    r10b,dl
  410cf5:	add    r10b,0x30
  410cf9:	mov    BYTE PTR [r9+0x2],r10b
  410cfd:	vxorpd xmm0,xmm0,xmm0
  410d01:	movzx  edx,dl
  410d04:	vcvtsi2sd xmm0,xmm0,rdx
  410d09:	vsubsd xmm0,xmm1,xmm0
  410d0d:	vmulsd xmm1,xmm0,xmm15
  410d12:	vcvttsd2si rdx,xmm1
  410d17:	mov    r10b,dl
  410d1a:	add    r10b,0x30
  410d1e:	mov    BYTE PTR [r9+0x3],r10b
  410d22:	vxorpd xmm0,xmm0,xmm0
  410d26:	movzx  edx,dl
  410d29:	vcvtsi2sd xmm0,xmm0,rdx
  410d2e:	vsubsd xmm0,xmm1,xmm0
  410d32:	vmulsd xmm1,xmm0,xmm15
  410d37:	vcvttsd2si rdx,xmm1
  410d3c:	mov    r10b,dl
  410d3f:	add    r10b,0x30
  410d43:	mov    BYTE PTR [r9+0x4],r10b
  410d47:	vxorpd xmm0,xmm0,xmm0
  410d4b:	movzx  edx,dl
  410d4e:	vcvtsi2sd xmm0,xmm0,rdx
  410d53:	vsubsd xmm0,xmm1,xmm0
  410d57:	vmulsd xmm1,xmm0,xmm15
  410d5c:	vcvttsd2si rdx,xmm1
  410d61:	mov    r10b,dl
  410d64:	add    r10b,0x30
  410d68:	mov    BYTE PTR [r9+0x5],r10b
  410d6c:	vxorpd xmm0,xmm0,xmm0
  410d70:	movzx  edx,dl
  410d73:	vcvtsi2sd xmm0,xmm0,rdx
  410d78:	vsubsd xmm0,xmm1,xmm0
  410d7c:	vmulsd xmm1,xmm0,xmm15
  410d81:	vcvttsd2si rdx,xmm1
  410d86:	mov    r10b,dl
  410d89:	add    r10b,0x30
  410d8d:	mov    BYTE PTR [r9+0x6],r10b
  410d91:	vxorpd xmm0,xmm0,xmm0
  410d95:	movzx  edx,dl
  410d98:	vcvtsi2sd xmm0,xmm0,rdx
  410d9d:	vsubsd xmm0,xmm1,xmm0
  410da1:	vmulsd xmm1,xmm0,xmm15
  410da6:	vcvttsd2si rdx,xmm1
  410dab:	mov    r10b,dl
  410dae:	add    r10b,0x30
  410db2:	mov    BYTE PTR [r9+0x7],r10b
  410db6:	vxorpd xmm0,xmm0,xmm0
  410dba:	movzx  edx,dl
  410dbd:	vcvtsi2sd xmm0,xmm0,rdx
  410dc2:	vsubsd xmm0,xmm1,xmm0
  410dc6:	vmulsd xmm1,xmm0,xmm15
  410dcb:	vcvttsd2si rdx,xmm1
  410dd0:	mov    r10b,dl
  410dd3:	add    r10b,0x30
  410dd7:	mov    BYTE PTR [r9+0x8],r10b
  410ddb:	vxorpd xmm0,xmm0,xmm0
  410ddf:	movzx  edx,dl
  410de2:	vcvtsi2sd xmm0,xmm0,rdx
  410de7:	vsubsd xmm0,xmm1,xmm0
  410deb:	vmulsd xmm1,xmm0,xmm15
  410df0:	vcvttsd2si rdx,xmm1
  410df5:	mov    r10b,dl
  410df8:	add    r10b,0x30
  410dfc:	mov    BYTE PTR [r9+0x9],r10b
  410e00:	vxorpd xmm0,xmm0,xmm0
  410e04:	movzx  edx,dl
  410e07:	vcvtsi2sd xmm0,xmm0,rdx
  410e0c:	vsubsd xmm0,xmm1,xmm0
  410e10:	vmulsd xmm1,xmm0,xmm15
  410e15:	vcvttsd2si rdx,xmm1
  410e1a:	mov    r10b,dl
  410e1d:	add    r10b,0x30
  410e21:	mov    BYTE PTR [r9+0xa],r10b
  410e25:	vxorpd xmm0,xmm0,xmm0
  410e29:	movzx  edx,dl
  410e2c:	vcvtsi2sd xmm0,xmm0,rdx
  410e31:	vsubsd xmm0,xmm1,xmm0
  410e35:	vmulsd xmm1,xmm0,xmm15
  410e3a:	vcvttsd2si rdx,xmm1
  410e3f:	mov    r10b,dl
  410e42:	add    r10b,0x30
  410e46:	mov    BYTE PTR [r9+0xb],r10b
  410e4a:	lea    r10,[r9+0x4]
  410e4e:	vxorpd xmm0,xmm0,xmm0
  410e52:	movzx  edx,dl
  410e55:	vcvtsi2sd xmm0,xmm0,rdx
  410e5a:	vsubsd xmm0,xmm1,xmm0
  410e5e:	vmulsd xmm1,xmm0,xmm15
  410e63:	vcvttsd2si rdx,xmm1
  410e68:	mov    r11b,dl
  410e6b:	add    r11b,0x30
  410e6f:	mov    BYTE PTR [r9+0xc],r11b
  410e73:	vxorpd xmm0,xmm0,xmm0
  410e77:	movzx  edx,dl
  410e7a:	vcvtsi2sd xmm0,xmm0,rdx
  410e7f:	vsubsd xmm0,xmm1,xmm0
  410e83:	vmulsd xmm1,xmm0,xmm15
  410e88:	vcvttsd2si rdx,xmm1
  410e8d:	mov    r11b,dl
  410e90:	add    r11b,0x30
  410e94:	mov    BYTE PTR [r9+0xd],r11b
  410e98:	lea    r10,[r10+0x2]
  410e9c:	vxorpd xmm0,xmm0,xmm0
  410ea0:	movzx  edx,dl
  410ea3:	vcvtsi2sd xmm0,xmm0,rdx
  410ea8:	vsubsd xmm0,xmm1,xmm0
  410eac:	vmulsd xmm1,xmm0,xmm15
  410eb1:	vcvttsd2si rdx,xmm1
  410eb6:	mov    r11b,dl
  410eb9:	add    r11b,0x30
  410ebd:	mov    BYTE PTR [r9+0xe],r11b
  410ec1:	vxorpd xmm0,xmm0,xmm0
  410ec5:	movzx  edx,dl
  410ec8:	vcvtsi2sd xmm0,xmm0,rdx
  410ecd:	vsubsd xmm0,xmm1,xmm0
  410ed1:	vmulsd xmm1,xmm0,xmm15
  410ed6:	vcvttsd2si rdx,xmm1
  410edb:	mov    r11b,dl
  410ede:	add    r11b,0x30
  410ee2:	mov    BYTE PTR [r9+0xf],r11b
  410ee6:	lea    r10,[r10+0x2]
  410eea:	lea    r10,[r10+0x2]
  410eee:	lea    r10,[r10+0x2]
  410ef2:	lea    r10,[r10+0x2]
  410ef6:	lea    r10,[r10+0x2]
  410efa:	vxorpd xmm0,xmm0,xmm0
  410efe:	movzx  edx,dl
  410f01:	vcvtsi2sd xmm0,xmm0,rdx
  410f06:	vsubsd xmm0,xmm1,xmm0
  410f0a:	vmulsd xmm1,xmm0,xmm15
  410f0f:	vcvttsd2si rdx,xmm1
  410f14:	mov    r11b,dl
  410f17:	add    r11b,0x30
  410f1b:	mov    BYTE PTR [r9+0x10],r11b
  410f1f:	vxorpd xmm0,xmm0,xmm0
  410f23:	movzx  edx,dl
  410f26:	vcvtsi2sd xmm0,xmm0,rdx
  410f2b:	vsubsd xmm0,xmm1,xmm0
  410f2f:	vmulsd xmm1,xmm0,xmm15
  410f34:	vcvttsd2si rdx,xmm1
  410f39:	add    dl,0x30
  410f3c:	mov    BYTE PTR [r9+0x11],dl
  410f40:	mov    BYTE PTR [r10+0x2],0x65
  410f45:	lea    r9,[r10+0x3]
  410f49:	test   r8,r8
  410f4c:	jl     410f55 <__swc_fn_65555ab2_000146_e9d46966+0x695>
  410f4e:	mov    BYTE PTR [r9],0x2b
  410f52:	inc    r9
  410f55:	mov    r10,r9
  410f58:	mov    rdx,r8
  410f5b:	nop    DWORD PTR [rax+rax*1+0x0]
  410f60:	mov    r11,rdx
  410f63:	movabs rdx,0x6666666666666667
  410f6d:	mov    rax,r11
  410f70:	imul   rdx
  410f73:	sar    rdx,0x2
  410f77:	mov    r12,rdx
  410f7a:	shr    rdx,0x3f
  410f7e:	add    r12,rdx
  410f81:	mov    rdx,r12
  410f84:	imul   r13,r12,0xa
  410f88:	sub    r11,r13
  410f8b:	mov    r13,QWORD PTR [rip+0x25ae]        # 413540 <__swc_rdata_base_65555ab2+0x430>
  410f92:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410f97:	mov    BYTE PTR [r10],r11b
  410f9a:	lea    r11,[r10+0x1]
  410f9e:	mov    r10,r11
  410fa1:	test   r12,r12
  410fa4:	jne    410f60 <__swc_fn_65555ab2_000146_e9d46966+0x6a0>
  410fa6:	test   r8,r8
  410fa9:	jge    410fb3 <__swc_fn_65555ab2_000146_e9d46966+0x6f3>
  410fab:	mov    BYTE PTR [r11],0x2d
  410faf:	lea    r10,[r11+0x1]
  410fb3:	mov    BYTE PTR [r10],0x0
  410fb7:	sub    r10,0x1
  410fbb:	nop    DWORD PTR [rax+rax*1+0x0]
  410fc0:	cmp    r9,r10
  410fc3:	jae    411218 <__swc_fn_65555ab2_000146_e9d46966+0x958>
  410fc9:	mov    al,BYTE PTR [r10]
  410fcc:	mov    dl,BYTE PTR [r9]
  410fcf:	mov    BYTE PTR [r10],dl
  410fd2:	sub    r10,0x1
  410fd6:	mov    BYTE PTR [r9],al
  410fd9:	inc    r9
  410fdc:	jmp    410fc0 <__swc_fn_65555ab2_000146_e9d46966+0x700>
  410fde:	vcvttsd2si rdx,xmm1
  410fe3:	mov    r8,rdx
  410fe6:	vxorpd xmm0,xmm0,xmm0
  410fea:	vcvtsi2sd xmm0,xmm0,rdx
  410fef:	vsubsd xmm0,xmm1,xmm0
  410ff3:	mov    r9d,0x8
  410ff9:	vxorpd xmm2,xmm2,xmm2
  410ffd:	vcomisd xmm2,xmm0
  411001:	jbe    41100b <__swc_fn_65555ab2_000146_e9d46966+0x74b>
  411003:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x2545]        # 413550 <__swc_rdata_base_65555ab2+0x440>
  41100b:	test   r9d,r9d
  41100e:	je     41101a <__swc_fn_65555ab2_000146_e9d46966+0x75a>
  411010:	vmulsd xmm0,xmm0,xmm14
  411015:	dec    r9d
  411018:	jne    411010 <__swc_fn_65555ab2_000146_e9d46966+0x750>
  41101a:	vcvttsd2si r9,xmm0
  41101f:	mov    r10,r9
  411022:	vxorpd xmm2,xmm2,xmm2
  411026:	vcvtsi2sd xmm2,xmm2,r9
  41102b:	vsubsd xmm0,xmm0,xmm2
  41102f:	vcomisd xmm0,xmm10
  411034:	lea    r9,[r9+0x1]
  411038:	cmova  r10,r9
  41103c:	cmp    r10,0x5f5e100
  411043:	jne    41105c <__swc_fn_65555ab2_000146_e9d46966+0x79c>
  411045:	lea    r8,[rdx-0x1]
  411049:	vxorpd xmm0,xmm0,xmm0
  41104d:	vcomisd xmm0,xmm1
  411051:	lea    rdx,[rdx+0x1]
  411055:	cmovbe r8,rdx
  411059:	xor    r10d,r10d
  41105c:	mov    r9,rcx
  41105f:	test   r8,r8
  411062:	jne    411082 <__swc_fn_65555ab2_000146_e9d46966+0x7c2>
  411064:	vxorpd xmm0,xmm0,xmm0
  411068:	vcomisd xmm0,xmm1
  41106c:	jbe    411075 <__swc_fn_65555ab2_000146_e9d46966+0x7b5>
  41106e:	mov    BYTE PTR [rcx],0x2d
  411071:	lea    r9,[rcx+0x1]
  411075:	mov    BYTE PTR [r9],0x30
  411079:	add    r9,0x1
  41107d:	jmp    41111b <__swc_fn_65555ab2_000146_e9d46966+0x85b>
  411082:	mov    r9,rcx
  411085:	mov    rdx,r8
  411088:	nop    DWORD PTR [rax+rax*1+0x0]
  411090:	mov    r11,rdx
  411093:	movabs rdx,0x6666666666666667
  41109d:	mov    r15,rax
  4110a0:	mov    rax,r11
  4110a3:	imul   rdx
  4110a6:	mov    r12,rdx
  4110a9:	mov    rax,r15
  4110ac:	sar    r12,0x2
  4110b0:	mov    rdx,r12
  4110b3:	shr    rdx,0x3f
  4110b7:	add    r12,rdx
  4110ba:	mov    rdx,r12
  4110bd:	imul   r13,r12,0xa
  4110c1:	sub    r11,r13
  4110c4:	mov    r13,QWORD PTR [rip+0x2475]        # 413540 <__swc_rdata_base_65555ab2+0x430>
  4110cb:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4110d0:	mov    BYTE PTR [r9],r11b
  4110d3:	lea    r11,[r9+0x1]
  4110d7:	mov    r9,r11
  4110da:	test   r12,r12
  4110dd:	jne    411090 <__swc_fn_65555ab2_000146_e9d46966+0x7d0>
  4110df:	test   r8,r8
  4110e2:	jge    4110ec <__swc_fn_65555ab2_000146_e9d46966+0x82c>
  4110e4:	mov    BYTE PTR [r11],0x2d
  4110e8:	lea    r9,[r11+0x1]
  4110ec:	mov    rdx,r9
  4110ef:	mov    BYTE PTR [r9],0x0
  4110f3:	sub    r9,0x1
  4110f7:	mov    r8,rcx
  4110fa:	cmp    r8,r9
  4110fd:	jae    411118 <__swc_fn_65555ab2_000146_e9d46966+0x858>
  4110ff:	nop
  411100:	mov    r11b,BYTE PTR [r9]
  411103:	mov    r12b,BYTE PTR [r8]
  411106:	mov    BYTE PTR [r9],r12b
  411109:	sub    r9,0x1
  41110d:	mov    BYTE PTR [r8],r11b
  411110:	inc    r8
  411113:	cmp    r8,r9
  411116:	jb     411100 <__swc_fn_65555ab2_000146_e9d46966+0x840>
  411118:	mov    r9,rdx
  41111b:	mov    BYTE PTR [r9],0x2e
  41111f:	add    r9,0x1
  411123:	xor    r8d,r8d
  411126:	test   r10,r10
  411129:	je     41116f <__swc_fn_65555ab2_000146_e9d46966+0x8af>
  41112b:	mov    r11d,0x989680
  411131:	cmp    r10,r11
  411134:	jge    41116f <__swc_fn_65555ab2_000146_e9d46966+0x8af>
  411136:	cs nop WORD PTR [rax+rax*1+0x0]
  411140:	inc    r8d
  411143:	movabs rdx,0x6666666666666667
  41114d:	mov    r15,rax
  411150:	mov    rax,r11
  411153:	imul   rdx
  411156:	mov    r11,rdx
  411159:	mov    rax,r15
  41115c:	sar    r11,0x2
  411160:	mov    rdx,r11
  411163:	shr    rdx,0x3f
  411167:	add    r11,rdx
  41116a:	cmp    r10,r11
  41116d:	jl     411140 <__swc_fn_65555ab2_000146_e9d46966+0x880>
  41116f:	test   r8d,r8d
  411172:	je     41118d <__swc_fn_65555ab2_000146_e9d46966+0x8cd>
  411174:	cs nop WORD PTR [rax+rax*1+0x0]
  41117e:	xchg   ax,ax
  411180:	mov    BYTE PTR [r9],0x30
  411184:	add    r9,0x1
  411188:	dec    r8d
  41118b:	jne    411180 <__swc_fn_65555ab2_000146_e9d46966+0x8c0>
  41118d:	mov    r8,r9
  411190:	mov    rdx,r10
  411193:	cs nop WORD PTR [rax+rax*1+0x0]
  41119d:	nop    DWORD PTR [rax]
  4111a0:	mov    r11,rdx
  4111a3:	movabs rdx,0x6666666666666667
  4111ad:	mov    rax,r11
  4111b0:	imul   rdx
  4111b3:	sar    rdx,0x2
  4111b7:	mov    r12,rdx
  4111ba:	shr    rdx,0x3f
  4111be:	add    r12,rdx
  4111c1:	mov    rdx,r12
  4111c4:	imul   r13,r12,0xa
  4111c8:	sub    r11,r13
  4111cb:	mov    r13,QWORD PTR [rip+0x236e]        # 413540 <__swc_rdata_base_65555ab2+0x430>
  4111d2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4111d7:	mov    BYTE PTR [r8],r11b
  4111da:	lea    r11,[r8+0x1]
  4111de:	mov    r8,r11
  4111e1:	test   r12,r12
  4111e4:	jne    4111a0 <__swc_fn_65555ab2_000146_e9d46966+0x8e0>
  4111e6:	test   r10,r10
  4111e9:	jge    4111f3 <__swc_fn_65555ab2_000146_e9d46966+0x933>
  4111eb:	mov    BYTE PTR [r11],0x2d
  4111ef:	lea    r8,[r11+0x1]
  4111f3:	mov    BYTE PTR [r8],0x0
  4111f7:	sub    r8,0x1
  4111fb:	cmp    r9,r8
  4111fe:	jae    411218 <__swc_fn_65555ab2_000146_e9d46966+0x958>
  411200:	mov    al,BYTE PTR [r8]
  411203:	mov    dl,BYTE PTR [r9]
  411206:	mov    BYTE PTR [r8],dl
  411209:	sub    r8,0x1
  41120d:	mov    BYTE PTR [r9],al
  411210:	inc    r9
  411213:	cmp    r9,r8
  411216:	jb     411200 <__swc_fn_65555ab2_000146_e9d46966+0x940>
  411218:	xor    eax,eax
  41121a:	test   rcx,rcx
  41121d:	je     411250 <__swc_fn_65555ab2_000146_e9d46966+0x990>
  41121f:	mov    rdx,rcx
  411222:	mov    r8b,BYTE PTR [rdx]
  411225:	test   r8b,r8b
  411228:	je     411250 <__swc_fn_65555ab2_000146_e9d46966+0x990>
  41122a:	cs nop WORD PTR [rax+rax*1+0x0]
  411234:	cs nop WORD PTR [rax+rax*1+0x0]
  41123e:	xchg   ax,ax
  411240:	add    rdx,0x1
  411244:	add    rax,0x1
  411248:	mov    r8b,BYTE PTR [rdx]
  41124b:	test   r8b,r8b
  41124e:	jne    411240 <__swc_fn_65555ab2_000146_e9d46966+0x980>
  411250:	mov    QWORD PTR [rsp+0x240],rcx
  411258:	mov    QWORD PTR [rsp+0x248],rax
  411260:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  411269:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  411272:	lea    rcx,[rsp+0x250]
  41127a:	call   410050 <__swc_fn_65555ab2_000116_3499f7d6>
  41127f:	jmp    411985 <__swc_fn_65555ab2_000146_e9d46966+0x10c5>
  411284:	lea    rcx,[rsp+0x260]
  41128c:	vxorps xmm0,xmm0,xmm0
  411290:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  411299:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  4112a2:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  4112ab:	vzeroupper
  4112ae:	mov    DWORD PTR [rsp+0x2c0],0x0
  4112b9:	vmovsd xmm0,QWORD PTR [rdx]
  4112bd:	vcomisd xmm0,xmm0
  4112c1:	setne  dl
  4112c4:	movzx  edx,dl
  4112c7:	setp   r8b
  4112cb:	movzx  r8d,r8b
  4112cf:	or     edx,r8d
  4112d2:	test   dl,dl
  4112d4:	je     4112e1 <__swc_fn_65555ab2_000146_e9d46966+0xa21>
  4112d6:	mov    DWORD PTR [rcx],0x6e616e
  4112dc:	jmp    4118e8 <__swc_fn_65555ab2_000146_e9d46966+0x1028>
  4112e1:	vcomisd xmm0,xmm11
  4112e6:	ja     4112f7 <__swc_fn_65555ab2_000146_e9d46966+0xa37>
  4112e8:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  4112f1:	vcomisd xmm6,xmm0
  4112f5:	jbe    41131b <__swc_fn_65555ab2_000146_e9d46966+0xa5b>
  4112f7:	vxorpd xmm1,xmm1,xmm1
  4112fb:	vcomisd xmm1,xmm0
  4112ff:	jbe    411310 <__swc_fn_65555ab2_000146_e9d46966+0xa50>
  411301:	mov    DWORD PTR [rcx],0x666e692d
  411307:	mov    BYTE PTR [rcx+0x4],0x0
  41130b:	jmp    4118e8 <__swc_fn_65555ab2_000146_e9d46966+0x1028>
  411310:	mov    DWORD PTR [rcx],0x666e69
  411316:	jmp    4118e8 <__swc_fn_65555ab2_000146_e9d46966+0x1028>
  41131b:	vcomisd xmm0,xmm13
  411320:	jae    41132c <__swc_fn_65555ab2_000146_e9d46966+0xa6c>
  411322:	vcomisd xmm12,xmm0
  411326:	jbe    41168e <__swc_fn_65555ab2_000146_e9d46966+0xdce>
  41132c:	vmovups xmm1,xmm0
  411330:	vxorpd xmm2,xmm2,xmm2
  411334:	vcomisd xmm2,xmm0
  411338:	jbe    411348 <__swc_fn_65555ab2_000146_e9d46966+0xa88>
  41133a:	vmovsd xmm0,xmm0,xmm1
  41133e:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x220a]        # 413550 <__swc_rdata_base_65555ab2+0x440>
  411346:	jmp    41134c <__swc_fn_65555ab2_000146_e9d46966+0xa8c>
  411348:	vmovsd xmm0,xmm0,xmm1
  41134c:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  411355:	xor    r8d,r8d
  411358:	vcomisd xmm0,xmm6
  41135c:	jb     41136e <__swc_fn_65555ab2_000146_e9d46966+0xaae>
  41135e:	xchg   ax,ax
  411360:	vdivsd xmm0,xmm0,xmm6
  411364:	add    r8,0x1
  411368:	vcomisd xmm0,xmm6
  41136c:	jae    411360 <__swc_fn_65555ab2_000146_e9d46966+0xaa0>
  41136e:	mov    r9,rcx
  411371:	vxorpd xmm2,xmm2,xmm2
  411375:	vcomisd xmm2,xmm1
  411379:	jbe    411382 <__swc_fn_65555ab2_000146_e9d46966+0xac2>
  41137b:	mov    BYTE PTR [rcx],0x2d
  41137e:	lea    r9,[rcx+0x1]
  411382:	vcvttsd2si rdx,xmm0
  411387:	mov    r10b,dl
  41138a:	add    r10b,0x30
  41138e:	mov    BYTE PTR [r9],r10b
  411391:	vxorpd xmm1,xmm1,xmm1
  411395:	movzx  edx,dl
  411398:	vcvtsi2sd xmm1,xmm1,rdx
  41139d:	vsubsd xmm0,xmm0,xmm1
  4113a1:	vmulsd xmm0,xmm0,xmm6
  4113a5:	mov    BYTE PTR [r9+0x1],0x2e
  4113aa:	vcvttsd2si rdx,xmm0
  4113af:	mov    r10b,dl
  4113b2:	add    r10b,0x30
  4113b6:	mov    BYTE PTR [r9+0x2],r10b
  4113ba:	vxorpd xmm1,xmm1,xmm1
  4113be:	movzx  edx,dl
  4113c1:	vcvtsi2sd xmm1,xmm1,rdx
  4113c6:	vsubsd xmm0,xmm0,xmm1
  4113ca:	vmulsd xmm0,xmm0,xmm6
  4113ce:	vcvttsd2si rdx,xmm0
  4113d3:	mov    r10b,dl
  4113d6:	add    r10b,0x30
  4113da:	mov    BYTE PTR [r9+0x3],r10b
  4113de:	vxorpd xmm1,xmm1,xmm1
  4113e2:	movzx  edx,dl
  4113e5:	vcvtsi2sd xmm1,xmm1,rdx
  4113ea:	vsubsd xmm0,xmm0,xmm1
  4113ee:	vmulsd xmm0,xmm0,xmm6
  4113f2:	vcvttsd2si rdx,xmm0
  4113f7:	mov    r10b,dl
  4113fa:	add    r10b,0x30
  4113fe:	mov    BYTE PTR [r9+0x4],r10b
  411402:	vxorpd xmm1,xmm1,xmm1
  411406:	movzx  edx,dl
  411409:	vcvtsi2sd xmm1,xmm1,rdx
  41140e:	vsubsd xmm0,xmm0,xmm1
  411412:	vmulsd xmm0,xmm0,xmm6
  411416:	vcvttsd2si rdx,xmm0
  41141b:	mov    r10b,dl
  41141e:	add    r10b,0x30
  411422:	mov    BYTE PTR [r9+0x5],r10b
  411426:	vxorpd xmm1,xmm1,xmm1
  41142a:	movzx  edx,dl
  41142d:	vcvtsi2sd xmm1,xmm1,rdx
  411432:	vsubsd xmm0,xmm0,xmm1
  411436:	vmulsd xmm0,xmm0,xmm6
  41143a:	vcvttsd2si rdx,xmm0
  41143f:	mov    r10b,dl
  411442:	add    r10b,0x30
  411446:	mov    BYTE PTR [r9+0x6],r10b
  41144a:	vxorpd xmm1,xmm1,xmm1
  41144e:	movzx  edx,dl
  411451:	vcvtsi2sd xmm1,xmm1,rdx
  411456:	vsubsd xmm0,xmm0,xmm1
  41145a:	vmulsd xmm0,xmm0,xmm6
  41145e:	vcvttsd2si rdx,xmm0
  411463:	mov    r10b,dl
  411466:	add    r10b,0x30
  41146a:	mov    BYTE PTR [r9+0x7],r10b
  41146e:	vxorpd xmm1,xmm1,xmm1
  411472:	movzx  edx,dl
  411475:	vcvtsi2sd xmm1,xmm1,rdx
  41147a:	vsubsd xmm0,xmm0,xmm1
  41147e:	vmulsd xmm0,xmm0,xmm6
  411482:	vcvttsd2si rdx,xmm0
  411487:	mov    r10b,dl
  41148a:	add    r10b,0x30
  41148e:	mov    BYTE PTR [r9+0x8],r10b
  411492:	vxorpd xmm1,xmm1,xmm1
  411496:	movzx  edx,dl
  411499:	vcvtsi2sd xmm1,xmm1,rdx
  41149e:	vsubsd xmm0,xmm0,xmm1
  4114a2:	vmulsd xmm0,xmm0,xmm6
  4114a6:	vcvttsd2si rdx,xmm0
  4114ab:	mov    r10b,dl
  4114ae:	add    r10b,0x30
  4114b2:	mov    BYTE PTR [r9+0x9],r10b
  4114b6:	vxorpd xmm1,xmm1,xmm1
  4114ba:	movzx  edx,dl
  4114bd:	vcvtsi2sd xmm1,xmm1,rdx
  4114c2:	vsubsd xmm0,xmm0,xmm1
  4114c6:	vmulsd xmm0,xmm0,xmm6
  4114ca:	vcvttsd2si rdx,xmm0
  4114cf:	mov    r10b,dl
  4114d2:	add    r10b,0x30
  4114d6:	mov    BYTE PTR [r9+0xa],r10b
  4114da:	vxorpd xmm1,xmm1,xmm1
  4114de:	movzx  edx,dl
  4114e1:	vcvtsi2sd xmm1,xmm1,rdx
  4114e6:	vsubsd xmm0,xmm0,xmm1
  4114ea:	vmulsd xmm0,xmm0,xmm6
  4114ee:	vcvttsd2si rdx,xmm0
  4114f3:	mov    r10b,dl
  4114f6:	add    r10b,0x30
  4114fa:	mov    BYTE PTR [r9+0xb],r10b
  4114fe:	lea    r10,[r9+0x4]
  411502:	vxorpd xmm1,xmm1,xmm1
  411506:	movzx  edx,dl
  411509:	vcvtsi2sd xmm1,xmm1,rdx
  41150e:	vsubsd xmm0,xmm0,xmm1
  411512:	vmulsd xmm0,xmm0,xmm6
  411516:	vcvttsd2si rdx,xmm0
  41151b:	mov    r11b,dl
  41151e:	add    r11b,0x30
  411522:	mov    BYTE PTR [r9+0xc],r11b
  411526:	vxorpd xmm1,xmm1,xmm1
  41152a:	movzx  edx,dl
  41152d:	vcvtsi2sd xmm1,xmm1,rdx
  411532:	vsubsd xmm0,xmm0,xmm1
  411536:	vmulsd xmm0,xmm0,xmm6
  41153a:	vcvttsd2si rdx,xmm0
  41153f:	mov    r11b,dl
  411542:	add    r11b,0x30
  411546:	mov    BYTE PTR [r9+0xd],r11b
  41154a:	lea    r10,[r10+0x2]
  41154e:	vxorpd xmm1,xmm1,xmm1
  411552:	movzx  edx,dl
  411555:	vcvtsi2sd xmm1,xmm1,rdx
  41155a:	vsubsd xmm0,xmm0,xmm1
  41155e:	vmulsd xmm0,xmm0,xmm6
  411562:	vcvttsd2si rdx,xmm0
  411567:	mov    r11b,dl
  41156a:	add    r11b,0x30
  41156e:	mov    BYTE PTR [r9+0xe],r11b
  411572:	vxorpd xmm1,xmm1,xmm1
  411576:	movzx  edx,dl
  411579:	vcvtsi2sd xmm1,xmm1,rdx
  41157e:	vsubsd xmm0,xmm0,xmm1
  411582:	vmulsd xmm0,xmm0,xmm6
  411586:	vcvttsd2si rdx,xmm0
  41158b:	mov    r11b,dl
  41158e:	add    r11b,0x30
  411592:	mov    BYTE PTR [r9+0xf],r11b
  411596:	lea    r10,[r10+0x2]
  41159a:	lea    r10,[r10+0x2]
  41159e:	lea    r10,[r10+0x2]
  4115a2:	lea    r10,[r10+0x2]
  4115a6:	lea    r10,[r10+0x2]
  4115aa:	vxorpd xmm1,xmm1,xmm1
  4115ae:	movzx  edx,dl
  4115b1:	vcvtsi2sd xmm1,xmm1,rdx
  4115b6:	vsubsd xmm0,xmm0,xmm1
  4115ba:	vmulsd xmm0,xmm0,xmm6
  4115be:	vcvttsd2si rdx,xmm0
  4115c3:	mov    r11b,dl
  4115c6:	add    r11b,0x30
  4115ca:	mov    BYTE PTR [r9+0x10],r11b
  4115ce:	vxorpd xmm1,xmm1,xmm1
  4115d2:	movzx  edx,dl
  4115d5:	vcvtsi2sd xmm1,xmm1,rdx
  4115da:	vsubsd xmm0,xmm0,xmm1
  4115de:	vmulsd xmm0,xmm0,xmm6
  4115e2:	vcvttsd2si rdx,xmm0
  4115e7:	add    dl,0x30
  4115ea:	mov    BYTE PTR [r9+0x11],dl
  4115ee:	mov    BYTE PTR [r10+0x2],0x65
  4115f3:	lea    r9,[r10+0x3]
  4115f7:	test   r8,r8
  4115fa:	jl     411603 <__swc_fn_65555ab2_000146_e9d46966+0xd43>
  4115fc:	mov    BYTE PTR [r9],0x2b
  411600:	inc    r9
  411603:	mov    r10,r9
  411606:	mov    rdx,r8
  411609:	nop    DWORD PTR [rax+0x0]
  411610:	mov    r11,rdx
  411613:	movabs rdx,0x6666666666666667
  41161d:	mov    rax,r11
  411620:	imul   rdx
  411623:	sar    rdx,0x2
  411627:	mov    r12,rdx
  41162a:	shr    rdx,0x3f
  41162e:	add    r12,rdx
  411631:	mov    rdx,r12
  411634:	imul   r13,r12,0xa
  411638:	sub    r11,r13
  41163b:	mov    r13,QWORD PTR [rip+0x1efe]        # 413540 <__swc_rdata_base_65555ab2+0x430>
  411642:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411647:	mov    BYTE PTR [r10],r11b
  41164a:	lea    r11,[r10+0x1]
  41164e:	mov    r10,r11
  411651:	test   r12,r12
  411654:	jne    411610 <__swc_fn_65555ab2_000146_e9d46966+0xd50>
  411656:	test   r8,r8
  411659:	jge    411663 <__swc_fn_65555ab2_000146_e9d46966+0xda3>
  41165b:	mov    BYTE PTR [r11],0x2d
  41165f:	lea    r10,[r11+0x1]
  411663:	mov    BYTE PTR [r10],0x0
  411667:	sub    r10,0x1
  41166b:	nop    DWORD PTR [rax+rax*1+0x0]
  411670:	cmp    r9,r10
  411673:	jae    4118e8 <__swc_fn_65555ab2_000146_e9d46966+0x1028>
  411679:	mov    al,BYTE PTR [r10]
  41167c:	mov    dl,BYTE PTR [r9]
  41167f:	mov    BYTE PTR [r10],dl
  411682:	sub    r10,0x1
  411686:	mov    BYTE PTR [r9],al
  411689:	inc    r9
  41168c:	jmp    411670 <__swc_fn_65555ab2_000146_e9d46966+0xdb0>
  41168e:	vcvttsd2si rdx,xmm0
  411693:	mov    r8,rdx
  411696:	vxorpd xmm1,xmm1,xmm1
  41169a:	vcvtsi2sd xmm1,xmm1,rdx
  41169f:	vsubsd xmm1,xmm0,xmm1
  4116a3:	mov    r9d,0x8
  4116a9:	vxorpd xmm2,xmm2,xmm2
  4116ad:	vcomisd xmm2,xmm1
  4116b1:	ja     4116be <__swc_fn_65555ab2_000146_e9d46966+0xdfe>
  4116b3:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  4116bc:	jmp    4116cf <__swc_fn_65555ab2_000146_e9d46966+0xe0f>
  4116be:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1e8a]        # 413550 <__swc_rdata_base_65555ab2+0x440>
  4116c6:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  4116cf:	test   r9d,r9d
  4116d2:	je     4116e9 <__swc_fn_65555ab2_000146_e9d46966+0xe29>
  4116d4:	cs nop WORD PTR [rax+rax*1+0x0]
  4116de:	xchg   ax,ax
  4116e0:	vmulsd xmm1,xmm1,xmm6
  4116e4:	dec    r9d
  4116e7:	jne    4116e0 <__swc_fn_65555ab2_000146_e9d46966+0xe20>
  4116e9:	vcvttsd2si r9,xmm1
  4116ee:	mov    r10,r9
  4116f1:	vxorpd xmm2,xmm2,xmm2
  4116f5:	vcvtsi2sd xmm2,xmm2,r9
  4116fa:	vsubsd xmm1,xmm1,xmm2
  4116fe:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  411707:	vcomisd xmm1,xmm6
  41170b:	lea    r9,[r9+0x1]
  41170f:	cmova  r10,r9
  411713:	cmp    r10,0x5f5e100
  41171a:	jne    411733 <__swc_fn_65555ab2_000146_e9d46966+0xe73>
  41171c:	lea    r8,[rdx-0x1]
  411720:	vxorpd xmm1,xmm1,xmm1
  411724:	vcomisd xmm1,xmm0
  411728:	lea    rdx,[rdx+0x1]
  41172c:	cmovbe r8,rdx
  411730:	xor    r10d,r10d
  411733:	mov    r9,rcx
  411736:	test   r8,r8
  411739:	jne    411759 <__swc_fn_65555ab2_000146_e9d46966+0xe99>
  41173b:	vxorpd xmm1,xmm1,xmm1
  41173f:	vcomisd xmm1,xmm0
  411743:	jbe    41174c <__swc_fn_65555ab2_000146_e9d46966+0xe8c>
  411745:	mov    BYTE PTR [rcx],0x2d
  411748:	lea    r9,[rcx+0x1]
  41174c:	mov    BYTE PTR [r9],0x30
  411750:	add    r9,0x1
  411754:	jmp    4117eb <__swc_fn_65555ab2_000146_e9d46966+0xf2b>
  411759:	mov    r9,rcx
  41175c:	mov    rdx,r8
  41175f:	nop
  411760:	mov    r11,rdx
  411763:	movabs rdx,0x6666666666666667
  41176d:	mov    r15,rax
  411770:	mov    rax,r11
  411773:	imul   rdx
  411776:	mov    r12,rdx
  411779:	mov    rax,r15
  41177c:	sar    r12,0x2
  411780:	mov    rdx,r12
  411783:	shr    rdx,0x3f
  411787:	add    r12,rdx
  41178a:	mov    rdx,r12
  41178d:	imul   r13,r12,0xa
  411791:	sub    r11,r13
  411794:	mov    r13,QWORD PTR [rip+0x1da5]        # 413540 <__swc_rdata_base_65555ab2+0x430>
  41179b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4117a0:	mov    BYTE PTR [r9],r11b
  4117a3:	lea    r11,[r9+0x1]
  4117a7:	mov    r9,r11
  4117aa:	test   r12,r12
  4117ad:	jne    411760 <__swc_fn_65555ab2_000146_e9d46966+0xea0>
  4117af:	test   r8,r8
  4117b2:	jge    4117bc <__swc_fn_65555ab2_000146_e9d46966+0xefc>
  4117b4:	mov    BYTE PTR [r11],0x2d
  4117b8:	lea    r9,[r11+0x1]
  4117bc:	mov    rdx,r9
  4117bf:	mov    BYTE PTR [r9],0x0
  4117c3:	sub    r9,0x1
  4117c7:	mov    r8,rcx
  4117ca:	cmp    r8,r9
  4117cd:	jae    4117e8 <__swc_fn_65555ab2_000146_e9d46966+0xf28>
  4117cf:	nop
  4117d0:	mov    r11b,BYTE PTR [r9]
  4117d3:	mov    r12b,BYTE PTR [r8]
  4117d6:	mov    BYTE PTR [r9],r12b
  4117d9:	sub    r9,0x1
  4117dd:	mov    BYTE PTR [r8],r11b
  4117e0:	inc    r8
  4117e3:	cmp    r8,r9
  4117e6:	jb     4117d0 <__swc_fn_65555ab2_000146_e9d46966+0xf10>
  4117e8:	mov    r9,rdx
  4117eb:	mov    BYTE PTR [r9],0x2e
  4117ef:	add    r9,0x1
  4117f3:	xor    r8d,r8d
  4117f6:	test   r10,r10
  4117f9:	je     41183f <__swc_fn_65555ab2_000146_e9d46966+0xf7f>
  4117fb:	mov    r11d,0x989680
  411801:	cmp    r10,r11
  411804:	jge    41183f <__swc_fn_65555ab2_000146_e9d46966+0xf7f>
  411806:	cs nop WORD PTR [rax+rax*1+0x0]
  411810:	inc    r8d
  411813:	movabs rdx,0x6666666666666667
  41181d:	mov    r15,rax
  411820:	mov    rax,r11
  411823:	imul   rdx
  411826:	mov    r11,rdx
  411829:	mov    rax,r15
  41182c:	sar    r11,0x2
  411830:	mov    rdx,r11
  411833:	shr    rdx,0x3f
  411837:	add    r11,rdx
  41183a:	cmp    r10,r11
  41183d:	jl     411810 <__swc_fn_65555ab2_000146_e9d46966+0xf50>
  41183f:	test   r8d,r8d
  411842:	je     41185d <__swc_fn_65555ab2_000146_e9d46966+0xf9d>
  411844:	cs nop WORD PTR [rax+rax*1+0x0]
  41184e:	xchg   ax,ax
  411850:	mov    BYTE PTR [r9],0x30
  411854:	add    r9,0x1
  411858:	dec    r8d
  41185b:	jne    411850 <__swc_fn_65555ab2_000146_e9d46966+0xf90>
  41185d:	mov    r8,r9
  411860:	mov    rdx,r10
  411863:	cs nop WORD PTR [rax+rax*1+0x0]
  41186d:	nop    DWORD PTR [rax]
  411870:	mov    r11,rdx
  411873:	movabs rdx,0x6666666666666667
  41187d:	mov    rax,r11
  411880:	imul   rdx
  411883:	sar    rdx,0x2
  411887:	mov    r12,rdx
  41188a:	shr    rdx,0x3f
  41188e:	add    r12,rdx
  411891:	mov    rdx,r12
  411894:	imul   r13,r12,0xa
  411898:	sub    r11,r13
  41189b:	mov    r13,QWORD PTR [rip+0x1c9e]        # 413540 <__swc_rdata_base_65555ab2+0x430>
  4118a2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4118a7:	mov    BYTE PTR [r8],r11b
  4118aa:	lea    r11,[r8+0x1]
  4118ae:	mov    r8,r11
  4118b1:	test   r12,r12
  4118b4:	jne    411870 <__swc_fn_65555ab2_000146_e9d46966+0xfb0>
  4118b6:	test   r10,r10
  4118b9:	jge    4118c3 <__swc_fn_65555ab2_000146_e9d46966+0x1003>
  4118bb:	mov    BYTE PTR [r11],0x2d
  4118bf:	lea    r8,[r11+0x1]
  4118c3:	mov    BYTE PTR [r8],0x0
  4118c7:	sub    r8,0x1
  4118cb:	cmp    r9,r8
  4118ce:	jae    4118e8 <__swc_fn_65555ab2_000146_e9d46966+0x1028>
  4118d0:	mov    al,BYTE PTR [r8]
  4118d3:	mov    dl,BYTE PTR [r9]
  4118d6:	mov    BYTE PTR [r8],dl
  4118d9:	sub    r8,0x1
  4118dd:	mov    BYTE PTR [r9],al
  4118e0:	inc    r9
  4118e3:	cmp    r9,r8
  4118e6:	jb     4118d0 <__swc_fn_65555ab2_000146_e9d46966+0x1010>
  4118e8:	xor    eax,eax
  4118ea:	test   rcx,rcx
  4118ed:	je     411910 <__swc_fn_65555ab2_000146_e9d46966+0x1050>
  4118ef:	mov    rdx,rcx
  4118f2:	mov    r8b,BYTE PTR [rdx]
  4118f5:	test   r8b,r8b
  4118f8:	je     411910 <__swc_fn_65555ab2_000146_e9d46966+0x1050>
  4118fa:	nop    WORD PTR [rax+rax*1+0x0]
  411900:	add    rdx,0x1
  411904:	add    rax,0x1
  411908:	mov    r8b,BYTE PTR [rdx]
  41190b:	test   r8b,r8b
  41190e:	jne    411900 <__swc_fn_65555ab2_000146_e9d46966+0x1040>
  411910:	mov    QWORD PTR [rsp+0x3f8],rcx
  411918:	mov    QWORD PTR [rsp+0x400],rax
  411920:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  411929:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  411932:	lea    rcx,[rsp+0x408]
  41193a:	call   410050 <__swc_fn_65555ab2_000116_3499f7d6>
  41193f:	jmp    411985 <__swc_fn_65555ab2_000146_e9d46966+0x10c5>
  411941:	mov    rcx,rdx
  411944:	call   410050 <__swc_fn_65555ab2_000116_3499f7d6>
  411949:	jmp    411985 <__swc_fn_65555ab2_000146_e9d46966+0x10c5>
  41194b:	mov    al,BYTE PTR [rdx]
  41194d:	test   al,al
  41194f:	je     41195a <__swc_fn_65555ab2_000146_e9d46966+0x109a>
  411951:	lea    rax,[rip+0x1c08]        # 413560 <__swc_rdata_base_65555ab2+0x450>
  411958:	jmp    411961 <__swc_fn_65555ab2_000146_e9d46966+0x10a1>
  41195a:	lea    rax,[rip+0x1c0f]        # 413570 <__swc_rdata_base_65555ab2+0x460>
  411961:	mov    rcx,rax
  411964:	call   410050 <__swc_fn_65555ab2_000116_3499f7d6>
  411969:	jmp    411985 <__swc_fn_65555ab2_000146_e9d46966+0x10c5>
  41196b:	lea    rcx,[rip+0x1c0e]        # 413580 <__swc_rdata_base_65555ab2+0x470>
  411972:	call   410050 <__swc_fn_65555ab2_000116_3499f7d6>
  411977:	jmp    411985 <__swc_fn_65555ab2_000146_e9d46966+0x10c5>
  411979:	lea    rcx,[rip+0x1c00]        # 413580 <__swc_rdata_base_65555ab2+0x470>
  411980:	call   410050 <__swc_fn_65555ab2_000116_3499f7d6>
  411985:	add    rdi,0x1
  411989:	sub    rsi,0x1
  41198d:	vmovups xmm0,xmm12
  411992:	vmovsd xmm6,QWORD PTR [rip+0x1bf6]        # 413590 <__swc_rdata_base_65555ab2+0x480>
  41199a:	test   rsi,rsi
  41199d:	jne    4109d0 <__swc_fn_65555ab2_000146_e9d46966+0x110>
  4119a3:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  4119ac:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  4119b5:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  4119be:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  4119c7:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  4119d0:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  4119d9:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  4119e2:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  4119eb:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  4119f4:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  4119fd:	add    rsp,0x4e8
  411a04:	pop    r15
  411a06:	pop    r13
  411a08:	pop    r12
  411a0a:	pop    rdi
  411a0b:	pop    rsi
  411a0c:	pop    rbx
  411a0d:	ret
	...

0000000000411a10 <__swc_fn_65555ab2_000149_33e5e24f>:
  411a10:	vxorps xmm0,xmm0,xmm0
  411a14:	vmovups XMMWORD PTR [rcx],xmm0
  411a18:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411a1d:	ret
	...

0000000000411a20 <__swc_fn_65555ab2_000152_33e5e24f>:
  411a20:	vxorps xmm0,xmm0,xmm0
  411a24:	vmovups XMMWORD PTR [rcx],xmm0
  411a28:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411a2d:	vxorps xmm0,xmm0,xmm0
  411a31:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411a36:	vmovups xmm0,XMMWORD PTR [rip+0x1c62]        # 4136a0 <__swc_rdata_base_65555ab2+0x590>
  411a3e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411a43:	vxorps xmm0,xmm0,xmm0
  411a47:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  411a4c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  411a51:	vxorps xmm0,xmm0,xmm0
  411a55:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  411a5a:	mov    QWORD PTR [rcx+0x70],0x0
  411a62:	ret
	...

0000000000411a70 <__swc_fn_65555ab2_000155_33e5e24f>:
  411a70:	vxorps xmm0,xmm0,xmm0
  411a74:	vmovups XMMWORD PTR [rcx],xmm0
  411a78:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  411a7d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411a82:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411a87:	ret
	...

0000000000411a90 <__swc_fn_65555ab2_000158_6741c23b>:
  411a90:	push   rsi
  411a91:	push   rdi
  411a92:	sub    rsp,0x8
  411a96:	mov    rsi,rcx
  411a99:	mov    rdi,QWORD PTR [rsi+0x50]
  411a9d:	test   rdi,rdi
  411aa0:	je     411aa7 <__swc_fn_65555ab2_000158_6741c23b+0x17>
  411aa2:	mov    rcx,rsi
  411aa5:	call   rdi
  411aa7:	mov    QWORD PTR [rsi+0x20],0x0
  411aaf:	mov    rax,QWORD PTR [rsi+0x30]
  411ab3:	test   rax,rax
  411ab6:	je     411ae4 <__swc_fn_65555ab2_000158_6741c23b+0x54>
  411ab8:	nop    DWORD PTR [rax+rax*1+0x0]
  411ac0:	mov    rdi,QWORD PTR [rax+0x8]
  411ac4:	mov    rcx,rsi
  411ac7:	mov    rdx,QWORD PTR [rax+0x10]
  411acb:	mov    rax,QWORD PTR [rax+0x18]
  411acf:	mov    r8,rax
  411ad2:	call   409e90 <__swc_fn_65555ab2_000156_312df05a>
  411ad7:	mov    QWORD PTR [rsi+0x30],rdi
  411adb:	mov    rax,QWORD PTR [rsi+0x30]
  411adf:	test   rax,rax
  411ae2:	jne    411ac0 <__swc_fn_65555ab2_000158_6741c23b+0x30>
  411ae4:	mov    QWORD PTR [rsi+0x38],0x0
  411aec:	add    rsp,0x8
  411af0:	pop    rdi
  411af1:	pop    rsi
  411af2:	ret
	...

0000000000411b00 <__swc_fn_65555ab2_000161_9e36e814>:
  411b00:	push   rbx
  411b01:	push   rsi
  411b02:	push   rdi
  411b03:	push   r12
  411b05:	sub    rsp,0x188
  411b0c:	mov    rbx,rcx
  411b0f:	lea    rsi,[rip+0x1527a]        # 426d90 <__swc_bss_base_65555ab2+0x2d50>
  411b16:	mov    rcx,rsi
  411b19:	call   4098a0 <__swc_fn_65555ab2_000135_1fec60ac>
  411b1e:	mov    rax,QWORD PTR [rip+0x15273]        # 426d98 <__swc_bss_base_65555ab2+0x2d58>
  411b25:	mov    rdi,rax
  411b28:	test   rdi,rdi
  411b2b:	je     411b59 <__swc_fn_65555ab2_000161_9e36e814+0x59>
  411b2d:	nop    DWORD PTR [rax]
  411b30:	cmp    QWORD PTR [rdi+0x8],rbx
  411b34:	jne    411b4e <__swc_fn_65555ab2_000161_9e36e814+0x4e>
  411b36:	mov    rcx,rsi
  411b39:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  411b3e:	mov    rax,rdi
  411b41:	add    rsp,0x188
  411b48:	pop    r12
  411b4a:	pop    rdi
  411b4b:	pop    rsi
  411b4c:	pop    rbx
  411b4d:	ret
  411b4e:	mov    rax,QWORD PTR [rdi]
  411b51:	mov    rdi,rax
  411b54:	test   rax,rax
  411b57:	jne    411b30 <__swc_fn_65555ab2_000161_9e36e814+0x30>
  411b59:	call   40ce80 <__swc_fn_65555ab2_000139_20e2e2c7>
  411b5e:	mov    rdi,rax
  411b61:	test   rax,rax
  411b64:	jne    411b7d <__swc_fn_65555ab2_000161_9e36e814+0x7d>
  411b66:	mov    rcx,rsi
  411b69:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  411b6e:	xor    eax,eax
  411b70:	add    rsp,0x188
  411b77:	pop    r12
  411b79:	pop    rdi
  411b7a:	pop    rsi
  411b7b:	pop    rbx
  411b7c:	ret
  411b7d:	lea    rax,[rsp+0x18]
  411b82:	mov    QWORD PTR [rax+0x10],0x0
  411b8a:	mov    QWORD PTR [rax+0x18],0x0
  411b92:	mov    DWORD PTR [rax+0x20],0x0
  411b99:	mov    BYTE PTR [rax+0x24],0x0
  411b9d:	mov    rax,QWORD PTR [rip+0x151f4]        # 426d98 <__swc_bss_base_65555ab2+0x2d58>
  411ba4:	mov    QWORD PTR [rsp+0x18],rax
  411ba9:	mov    QWORD PTR [rsp+0x20],rbx
  411bae:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411bb4:	vmovups XMMWORD PTR [rdi],xmm0
  411bb8:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  411bbe:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  411bc3:	mov    rax,QWORD PTR [rsp+0x38]
  411bc8:	mov    QWORD PTR [rdi+0x20],rax
  411bcc:	mov    QWORD PTR [rip+0x151c5],rdi        # 426d98 <__swc_bss_base_65555ab2+0x2d58>
  411bd3:	lea    rax,[rsp+0x40]
  411bd8:	mov    QWORD PTR [rax],0x0
  411bdf:	mov    rcx,rbx
  411be2:	mov    rdx,rax
  411be5:	call   409980 <__swc_fn_65555ab2_000141_376d5f6d>
  411bea:	mov    rbx,rax
  411bed:	test   rax,rax
  411bf0:	jne    411c0a <__swc_fn_65555ab2_000161_9e36e814+0x10a>
  411bf2:	mov    rcx,rsi
  411bf5:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  411bfa:	mov    rax,rdi
  411bfd:	add    rsp,0x188
  411c04:	pop    r12
  411c06:	pop    rdi
  411c07:	pop    rsi
  411c08:	pop    rbx
  411c09:	ret
  411c0a:	lea    r12,[rsp+0x50]
  411c0f:	mov    QWORD PTR [r12],0x0
  411c17:	mov    rcx,rbx
  411c1a:	mov    rdx,QWORD PTR [rsp+0x40]
  411c1f:	mov    r8,r12
  411c22:	call   40cf30 <__swc_fn_65555ab2_000142_e0543f36>
  411c27:	test   rax,rax
  411c2a:	jne    411c44 <__swc_fn_65555ab2_000161_9e36e814+0x144>
  411c2c:	mov    rcx,rsi
  411c2f:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  411c34:	mov    rax,rdi
  411c37:	add    rsp,0x188
  411c3e:	pop    r12
  411c40:	pop    rdi
  411c41:	pop    rsi
  411c42:	pop    rbx
  411c43:	ret
  411c44:	cmp    QWORD PTR [r12],0x10
  411c49:	jb     411d4c <__swc_fn_65555ab2_000161_9e36e814+0x24c>
  411c4f:	mov    ecx,DWORD PTR [rax]
  411c51:	cmp    ecx,0x42445753
  411c57:	jne    411d4c <__swc_fn_65555ab2_000161_9e36e814+0x24c>
  411c5d:	mov    ecx,DWORD PTR [rax+0x4]
  411c60:	cmp    ecx,0x1
  411c63:	jne    411d4c <__swc_fn_65555ab2_000161_9e36e814+0x24c>
  411c69:	mov    ecx,DWORD PTR [rax+0x8]
  411c6c:	mov    edx,DWORD PTR [rax+0xc]
  411c6f:	imul   r8,rcx,0x14
  411c73:	mov    r9,QWORD PTR [rsp+0x50]
  411c78:	sub    r9,0x10
  411c7c:	cmp    r8,r9
  411c7f:	ja     411d4c <__swc_fn_65555ab2_000161_9e36e814+0x24c>
  411c85:	lea    r8,[r8+0x10]
  411c89:	cmp    rdx,r8
  411c8c:	jb     411d4c <__swc_fn_65555ab2_000161_9e36e814+0x24c>
  411c92:	mov    r8,QWORD PTR [rsp+0x50]
  411c97:	cmp    rdx,r8
  411c9a:	ja     411d4c <__swc_fn_65555ab2_000161_9e36e814+0x24c>
  411ca0:	xor    r8d,r8d
  411ca3:	test   rcx,rcx
  411ca6:	jbe    411d72 <__swc_fn_65555ab2_000161_9e36e814+0x272>
  411cac:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  411cb2:	cs nop WORD PTR [rax+rax*1+0x0]
  411cbc:	nop    DWORD PTR [rax+0x0]
  411cc0:	imul   r9,r8,0x14
  411cc4:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  411cc9:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  411cce:	add    r10,r11
  411cd1:	movabs r11,0x100000000
  411cdb:	cmp    r10,r11
  411cde:	ja     411d4c <__swc_fn_65555ab2_000161_9e36e814+0x24c>
  411ce0:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  411ce5:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  411cea:	test   r10d,r10d
  411ced:	setne  r11b
  411cf1:	je     411d0b <__swc_fn_65555ab2_000161_9e36e814+0x20b>
  411cf3:	cmp    r10d,edx
  411cf6:	setb   r11b
  411cfa:	jb     411d0b <__swc_fn_65555ab2_000161_9e36e814+0x20b>
  411cfc:	vmovq  r11,xmm1
  411d01:	cmp    r10,r11
  411d04:	setae  r10b
  411d08:	mov    r11b,r10b
  411d0b:	mov    r10,r11
  411d0e:	test   r11b,r11b
  411d11:	jne    411d38 <__swc_fn_65555ab2_000161_9e36e814+0x238>
  411d13:	test   r9d,r9d
  411d16:	setne  r10b
  411d1a:	je     411d38 <__swc_fn_65555ab2_000161_9e36e814+0x238>
  411d1c:	cmp    r9d,edx
  411d1f:	setb   r10b
  411d23:	jb     411d38 <__swc_fn_65555ab2_000161_9e36e814+0x238>
  411d25:	vmovq  r10,xmm1
  411d2a:	cmp    r9,r10
  411d2d:	setae  r9b
  411d31:	movzx  r9d,r9b
  411d35:	mov    r10b,r9b
  411d38:	test   r10b,r10b
  411d3b:	jne    411d4c <__swc_fn_65555ab2_000161_9e36e814+0x24c>
  411d3d:	add    r8,0x1
  411d41:	cmp    r8,rcx
  411d44:	jb     411cc0 <__swc_fn_65555ab2_000161_9e36e814+0x1c0>
  411d4a:	jmp    411d72 <__swc_fn_65555ab2_000161_9e36e814+0x272>
  411d4c:	xor    ecx,ecx
  411d4e:	cmp    rax,rbx
  411d51:	cmovne rcx,rax
  411d55:	call   410810 <__swc_fn_65555ab2_000143_afffe963>
  411d5a:	mov    rcx,rsi
  411d5d:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  411d62:	mov    rax,rdi
  411d65:	add    rsp,0x188
  411d6c:	pop    r12
  411d6e:	pop    rdi
  411d6f:	pop    rsi
  411d70:	pop    rbx
  411d71:	ret
  411d72:	mov    QWORD PTR [rdi+0x10],rax
  411d76:	mov    rcx,QWORD PTR [rsp+0x50]
  411d7b:	mov    QWORD PTR [rdi+0x18],rcx
  411d7f:	mov    eax,DWORD PTR [rax+0x8]
  411d82:	mov    DWORD PTR [rdi+0x20],eax
  411d85:	rex mov BYTE PTR [rdi+0x24],0x1
  411d8a:	mov    rcx,rsi
  411d8d:	call   40ce70 <__swc_fn_65555ab2_000136_5589b4a1>
  411d92:	mov    rax,rdi
  411d95:	add    rsp,0x188
  411d9c:	pop    r12
  411d9e:	pop    rdi
  411d9f:	pop    rsi
  411da0:	pop    rbx
  411da1:	ret
	...

0000000000411db0 <__swc_fn_65555ab2_000164_15b66a30>:
  411db0:	push   rsi
  411db1:	push   rdi
  411db2:	push   r12
  411db4:	mov    rsi,rdx
  411db7:	mov    rdi,rcx
  411dba:	mov    rcx,QWORD PTR [rip+0x14f7f]        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  411dc1:	test   rcx,rcx
  411dc4:	jne    411dd6 <__swc_fn_65555ab2_000164_15b66a30+0x26>
  411dc6:	call   40a1a0 <__swc_fn_65555ab2_000165_e09accff>
  411dcb:	lea    rcx,[rax+0x1]
  411dcf:	mov    QWORD PTR [rip+0x14f6a],rcx        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  411dd6:	dec    rcx
  411dd9:	call   411e00 <__swc_fn_65555ab2_000167_3130645d>
  411dde:	mov    r12,QWORD PTR [rax+0xbe0]
  411de5:	test   r12,r12
  411de8:	setne  al
  411deb:	je     411df6 <__swc_fn_65555ab2_000164_15b66a30+0x46>
  411ded:	mov    rcx,rdi
  411df0:	mov    rdx,rsi
  411df3:	call   r12
  411df6:	pop    r12
  411df8:	pop    rdi
  411df9:	pop    rsi
  411dfa:	ret
  411dfb:	add    BYTE PTR [rax],al
  411dfd:	add    BYTE PTR [rax],al
	...

0000000000411e00 <__swc_fn_65555ab2_000167_3130645d>:
  411e00:	push   r12
  411e02:	push   rdi
  411e03:	push   rsi
  411e04:	sub    rsp,0xd0
  411e0b:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  411e11:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  411e17:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  411e1d:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  411e23:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  411e29:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  411e2f:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  411e38:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  411e41:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  411e4a:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  411e53:	mov    r12,rcx
  411e56:	mov    edi,ecx
  411e58:	xor    eax,eax
  411e5a:	call   407000 <pthread_getspecific@plt>
  411e5f:	test   rax,rax
  411e62:	je     411e66 <__swc_fn_65555ab2_000167_3130645d+0x66>
  411e64:	jmp    411e6e <__swc_fn_65555ab2_000167_3130645d+0x6e>
  411e66:	mov    rcx,r12
  411e69:	call   40a200 <__swc_fn_65555ab2_000168_0ff0458f>
  411e6e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  411e74:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  411e7a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  411e80:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  411e86:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  411e8c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  411e92:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  411e9b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  411ea4:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  411ead:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  411eb6:	add    rsp,0xd0
  411ebd:	pop    rsi
  411ebe:	pop    rdi
  411ebf:	pop    r12
  411ec1:	ret
	...

0000000000411ed0 <__swc_fn_65555ab2_000170_8b7c1b80>:
  411ed0:	push   rsi
  411ed1:	sub    rsp,0x30
  411ed5:	lea    rsi,[rip+0x14ecc]        # 426da8 <__swc_bss_base_65555ab2+0x2d68>
  411edc:	mov    rax,QWORD PTR [rsi]
  411edf:	test   rax,rax
  411ee2:	je     411eea <__swc_fn_65555ab2_000170_8b7c1b80+0x1a>
  411ee4:	add    rsp,0x30
  411ee8:	pop    rsi
  411ee9:	ret
  411eea:	mov    ecx,0x3
  411eef:	mov    edx,0x10
  411ef4:	call   40f970 <__swc_fn_65555ab2_000107_ff529476>
  411ef9:	test   rax,rax
  411efc:	jne    411f0d <__swc_fn_65555ab2_000170_8b7c1b80+0x3d>
  411efe:	mov    QWORD PTR [rsp+0x18],rax
  411f03:	call   40c9d0 <__swc_fn_65555ab2_000118_2b35b5e0>
  411f08:	mov    rax,QWORD PTR [rsp+0x18]
  411f0d:	mov    rcx,rax
  411f10:	xchg   QWORD PTR [rsi],rcx
  411f13:	add    rsp,0x30
  411f17:	pop    rsi
  411f18:	ret
  411f19:	add    BYTE PTR [rax],al
  411f1b:	add    BYTE PTR [rax],al
  411f1d:	add    BYTE PTR [rax],al
	...

0000000000411f20 <__swc_fn_65555ab2_000173_156cb9fe>:
  411f20:	push   rsi
  411f21:	push   rdi
  411f22:	sub    rsp,0x8
  411f26:	mov    rsi,rdx
  411f29:	mov    rdi,rcx
  411f2c:	mov    rax,QWORD PTR [rsi+0x8]
  411f30:	test   rax,rax
  411f33:	je     411f3d <__swc_fn_65555ab2_000173_156cb9fe+0x1d>
  411f35:	mov    rcx,QWORD PTR [rsi]
  411f38:	mov    QWORD PTR [rax],rcx
  411f3b:	jmp    411f44 <__swc_fn_65555ab2_000173_156cb9fe+0x24>
  411f3d:	mov    rax,QWORD PTR [rsi]
  411f40:	mov    QWORD PTR [rdi+0x8],rax
  411f44:	mov    rax,QWORD PTR [rsi]
  411f47:	test   rax,rax
  411f4a:	je     411f54 <__swc_fn_65555ab2_000173_156cb9fe+0x34>
  411f4c:	mov    rcx,QWORD PTR [rsi+0x8]
  411f50:	mov    QWORD PTR [rax+0x8],rcx
  411f54:	mov    rcx,rdi
  411f57:	mov    rdx,QWORD PTR [rsi+0x10]
  411f5b:	mov    r8,QWORD PTR [rsi+0x18]
  411f5f:	mov    r9,0xffffffffffffffff
  411f66:	call   40d580 <__swc_fn_65555ab2_000172_9a88b1d5>
  411f6b:	mov    QWORD PTR [rsi+0x18],0x0
  411f73:	mov    rax,QWORD PTR [rdi+0x8]
  411f77:	test   rax,rax
  411f7a:	jne    411f8c <__swc_fn_65555ab2_000173_156cb9fe+0x6c>
  411f7c:	call   411ed0 <__swc_fn_65555ab2_000170_8b7c1b80>
  411f81:	xor    ecx,ecx
  411f83:	mov    QWORD PTR [rax+0x8],rcx
  411f87:	xor    ecx,ecx
  411f89:	mov    QWORD PTR [rax],rcx
  411f8c:	add    rsp,0x8
  411f90:	pop    rdi
  411f91:	pop    rsi
  411f92:	ret
	...

0000000000411fa0 <__swc_fn_65555ab2_000176_5d3d19bd>:
  411fa0:	push   rbx
  411fa1:	sub    rsp,0x70
  411fa5:	test   rcx,rcx
  411fa8:	jne    411fb0 <__swc_fn_65555ab2_000176_5d3d19bd+0x10>
  411faa:	add    rsp,0x70
  411fae:	pop    rbx
  411faf:	ret
  411fb0:	vxorps xmm0,xmm0,xmm0
  411fb4:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  411fba:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  411fc0:	vzeroupper
  411fc3:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  411fc9:	lea    rax,[rcx-0x10]
  411fcd:	mov    QWORD PTR [rsp+0x48],rax
  411fd2:	mov    rax,QWORD PTR [rcx-0x10]
  411fd6:	mov    QWORD PTR [rsp+0x50],rax
  411fdb:	mov    rcx,QWORD PTR [rip+0x14d5e]        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  411fe2:	test   rcx,rcx
  411fe5:	jne    411ff7 <__swc_fn_65555ab2_000176_5d3d19bd+0x57>
  411fe7:	call   40a1a0 <__swc_fn_65555ab2_000165_e09accff>
  411fec:	lea    rcx,[rax+0x1]
  411ff0:	mov    QWORD PTR [rip+0x14d49],rcx        # 426d40 <__swc_bss_base_65555ab2+0x2d00>
  411ff7:	dec    rcx
  411ffa:	call   411e00 <__swc_fn_65555ab2_000167_3130645d>
  411fff:	mov    rcx,QWORD PTR [rax]
  412002:	lea    rdx,[rsp+0x8]
  412007:	mov    rbx,QWORD PTR [rax+0x8]
  41200b:	mov    rbx,QWORD PTR [rbx+0x18]
  41200f:	call   rbx
  412011:	add    rsp,0x70
  412015:	pop    rbx
  412016:	ret
