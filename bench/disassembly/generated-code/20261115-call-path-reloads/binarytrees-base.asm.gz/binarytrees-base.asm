
/workspace/prompt2-20261115/batch9-audited-micro/base/binarytrees/binarytrees:     file format elf64-x86-64


Disassembly of section .plt:

0000000000407000 <pthread_getspecific@plt>:
  407000:	jmp    QWORD PTR [rip+0xb002]        # 412008 <pthread_getspecific@GLIBC_2.34>
  407006:	nop
  407007:	nop
  407008:	nop
  407009:	nop
  40700a:	nop
  40700b:	nop
  40700c:	nop
  40700d:	nop
  40700e:	nop
  40700f:	nop

0000000000407010 <getpid@plt>:
  407010:	jmp    QWORD PTR [rip+0xaffa]        # 412010 <getpid@GLIBC_2.2.5>
  407016:	nop
  407017:	nop
  407018:	nop
  407019:	nop
  40701a:	nop
  40701b:	nop
  40701c:	nop
  40701d:	nop
  40701e:	nop
  40701f:	nop

0000000000407020 <munmap@plt>:
  407020:	jmp    QWORD PTR [rip+0xaff2]        # 412018 <munmap@GLIBC_2.2.5>
  407026:	nop
  407027:	nop
  407028:	nop
  407029:	nop
  40702a:	nop
  40702b:	nop
  40702c:	nop
  40702d:	nop
  40702e:	nop
  40702f:	nop

0000000000407030 <mprotect@plt>:
  407030:	jmp    QWORD PTR [rip+0xafea]        # 412020 <mprotect@GLIBC_2.2.5>
  407036:	nop
  407037:	nop
  407038:	nop
  407039:	nop
  40703a:	nop
  40703b:	nop
  40703c:	nop
  40703d:	nop
  40703e:	nop
  40703f:	nop

0000000000407040 <exit@plt>:
  407040:	jmp    QWORD PTR [rip+0xafe2]        # 412028 <exit@GLIBC_2.2.5>
  407046:	nop
  407047:	nop
  407048:	nop
  407049:	nop
  40704a:	nop
  40704b:	nop
  40704c:	nop
  40704d:	nop
  40704e:	nop
  40704f:	nop

0000000000407050 <pthread_key_create@plt>:
  407050:	jmp    QWORD PTR [rip+0xafda]        # 412030 <pthread_key_create@GLIBC_2.34>
  407056:	nop
  407057:	nop
  407058:	nop
  407059:	nop
  40705a:	nop
  40705b:	nop
  40705c:	nop
  40705d:	nop
  40705e:	nop
  40705f:	nop

0000000000407060 <pthread_setspecific@plt>:
  407060:	jmp    QWORD PTR [rip+0xafd2]        # 412038 <pthread_setspecific@GLIBC_2.34>
  407066:	nop
  407067:	nop
  407068:	nop
  407069:	nop
  40706a:	nop
  40706b:	nop
  40706c:	nop
  40706d:	nop
  40706e:	nop
  40706f:	nop

0000000000407070 <syscall@plt>:
  407070:	jmp    QWORD PTR [rip+0xafca]        # 412040 <syscall@GLIBC_2.2.5>
  407076:	nop
  407077:	nop
  407078:	nop
  407079:	nop
  40707a:	nop
  40707b:	nop
  40707c:	nop
  40707d:	nop
  40707e:	nop
  40707f:	nop

0000000000407080 <dladdr@plt>:
  407080:	jmp    QWORD PTR [rip+0xafc2]        # 412048 <dladdr@GLIBC_2.34>
  407086:	nop
  407087:	nop
  407088:	nop
  407089:	nop
  40708a:	nop
  40708b:	nop
  40708c:	nop
  40708d:	nop
  40708e:	nop
  40708f:	nop

0000000000407090 <open@plt>:
  407090:	jmp    QWORD PTR [rip+0xafba]        # 412050 <open@GLIBC_2.2.5>
  407096:	nop
  407097:	nop
  407098:	nop
  407099:	nop
  40709a:	nop
  40709b:	nop
  40709c:	nop
  40709d:	nop
  40709e:	nop
  40709f:	nop

00000000004070a0 <lseek@plt>:
  4070a0:	jmp    QWORD PTR [rip+0xafb2]        # 412058 <lseek@GLIBC_2.2.5>
  4070a6:	nop
  4070a7:	nop
  4070a8:	nop
  4070a9:	nop
  4070aa:	nop
  4070ab:	nop
  4070ac:	nop
  4070ad:	nop
  4070ae:	nop
  4070af:	nop

00000000004070b0 <close@plt>:
  4070b0:	jmp    QWORD PTR [rip+0xafaa]        # 412060 <close@GLIBC_2.2.5>
  4070b6:	nop
  4070b7:	nop
  4070b8:	nop
  4070b9:	nop
  4070ba:	nop
  4070bb:	nop
  4070bc:	nop
  4070bd:	nop
  4070be:	nop
  4070bf:	nop

00000000004070c0 <mmap@plt>:
  4070c0:	jmp    QWORD PTR [rip+0xafa2]        # 412068 <mmap@GLIBC_2.2.5>
  4070c6:	nop
  4070c7:	nop
  4070c8:	nop
  4070c9:	nop
  4070ca:	nop
  4070cb:	nop
  4070cc:	nop
  4070cd:	nop
  4070ce:	nop
  4070cf:	nop

00000000004070d0 <malloc@plt>:
  4070d0:	jmp    QWORD PTR [rip+0xaf9a]        # 412070 <malloc@GLIBC_2.2.5>
  4070d6:	nop
  4070d7:	nop
  4070d8:	nop
  4070d9:	nop
  4070da:	nop
  4070db:	nop
  4070dc:	nop
  4070dd:	nop
  4070de:	nop
  4070df:	nop

00000000004070e0 <madvise@plt>:
  4070e0:	jmp    QWORD PTR [rip+0xaf9a]        # 412080 <madvise@GLIBC_2.2.5>
  4070e6:	nop
  4070e7:	nop
  4070e8:	nop
  4070e9:	nop
  4070ea:	nop
  4070eb:	nop
  4070ec:	nop
  4070ed:	nop
  4070ee:	nop
  4070ef:	nop

00000000004070f0 <pthread_key_delete@plt>:
  4070f0:	jmp    QWORD PTR [rip+0xaf92]        # 412088 <pthread_key_delete@GLIBC_2.34>
  4070f6:	nop
  4070f7:	nop
  4070f8:	nop
  4070f9:	nop
  4070fa:	nop
  4070fb:	nop
  4070fc:	nop
  4070fd:	nop
  4070fe:	nop
  4070ff:	nop

0000000000407100 <gettid@plt>:
  407100:	jmp    QWORD PTR [rip+0xaf8a]        # 412090 <gettid@GLIBC_2.30>
  407106:	nop
  407107:	nop
  407108:	nop
  407109:	nop
  40710a:	nop
  40710b:	nop
  40710c:	nop
  40710d:	nop
  40710e:	nop
  40710f:	nop

0000000000407110 <flock@plt>:
  407110:	jmp    QWORD PTR [rip+0xaf82]        # 412098 <flock@GLIBC_2.2.5>
  407116:	nop
  407117:	nop
  407118:	nop
  407119:	nop
  40711a:	nop
  40711b:	nop
  40711c:	nop
  40711d:	nop
  40711e:	nop
  40711f:	nop

0000000000407120 <__errno_location@plt>:
  407120:	jmp    QWORD PTR [rip+0xaf7a]        # 4120a0 <__errno_location@GLIBC_2.2.5>
  407126:	nop
  407127:	nop
  407128:	nop
  407129:	nop
  40712a:	nop
  40712b:	nop
  40712c:	nop
  40712d:	nop
  40712e:	nop
  40712f:	nop

0000000000407130 <opendir@plt>:
  407130:	jmp    QWORD PTR [rip+0xaf72]        # 4120a8 <opendir@GLIBC_2.2.5>
  407136:	nop
  407137:	nop
  407138:	nop
  407139:	nop
  40713a:	nop
  40713b:	nop
  40713c:	nop
  40713d:	nop
  40713e:	nop
  40713f:	nop

0000000000407140 <dirfd@plt>:
  407140:	jmp    QWORD PTR [rip+0xaf6a]        # 4120b0 <dirfd@GLIBC_2.2.5>
  407146:	nop
  407147:	nop
  407148:	nop
  407149:	nop
  40714a:	nop
  40714b:	nop
  40714c:	nop
  40714d:	nop
  40714e:	nop
  40714f:	nop

0000000000407150 <readdir@plt>:
  407150:	jmp    QWORD PTR [rip+0xaf62]        # 4120b8 <readdir@GLIBC_2.2.5>
  407156:	nop
  407157:	nop
  407158:	nop
  407159:	nop
  40715a:	nop
  40715b:	nop
  40715c:	nop
  40715d:	nop
  40715e:	nop
  40715f:	nop

0000000000407160 <readlinkat@plt>:
  407160:	jmp    QWORD PTR [rip+0xaf5a]        # 4120c0 <readlinkat@GLIBC_2.4>
  407166:	nop
  407167:	nop
  407168:	nop
  407169:	nop
  40716a:	nop
  40716b:	nop
  40716c:	nop
  40716d:	nop
  40716e:	nop
  40716f:	nop

0000000000407170 <openat@plt>:
  407170:	jmp    QWORD PTR [rip+0xaf52]        # 4120c8 <openat@GLIBC_2.4>
  407176:	nop
  407177:	nop
  407178:	nop
  407179:	nop
  40717a:	nop
  40717b:	nop
  40717c:	nop
  40717d:	nop
  40717e:	nop
  40717f:	nop

0000000000407180 <closedir@plt>:
  407180:	jmp    QWORD PTR [rip+0xaf4a]        # 4120d0 <closedir@GLIBC_2.2.5>
  407186:	nop
  407187:	nop
  407188:	nop
  407189:	nop
  40718a:	nop
  40718b:	nop
  40718c:	nop
  40718d:	nop
  40718e:	nop
  40718f:	nop

0000000000407190 <memfd_create@plt>:
  407190:	jmp    QWORD PTR [rip+0xaf42]        # 4120d8 <memfd_create@GLIBC_2.27>
  407196:	nop
  407197:	nop
  407198:	nop
  407199:	nop
  40719a:	nop
  40719b:	nop
  40719c:	nop
  40719d:	nop
  40719e:	nop
  40719f:	nop

00000000004071a0 <ftruncate@plt>:
  4071a0:	jmp    QWORD PTR [rip+0xaf3a]        # 4120e0 <ftruncate@GLIBC_2.2.5>
  4071a6:	nop
  4071a7:	nop
  4071a8:	nop
  4071a9:	nop
  4071aa:	nop
  4071ab:	nop
  4071ac:	nop
  4071ad:	nop
  4071ae:	nop
  4071af:	nop

00000000004071b0 <write@plt>:
  4071b0:	jmp    QWORD PTR [rip+0xaf32]        # 4120e8 <write@GLIBC_2.2.5>
  4071b6:	nop
  4071b7:	nop
  4071b8:	nop
  4071b9:	nop
  4071ba:	nop
  4071bb:	nop
  4071bc:	nop
  4071bd:	nop
  4071be:	nop
  4071bf:	nop

00000000004071c0 <backtrace@plt>:
  4071c0:	jmp    QWORD PTR [rip+0xaf2a]        # 4120f0 <backtrace@GLIBC_2.2.5>
  4071c6:	nop
  4071c7:	nop
  4071c8:	nop
  4071c9:	nop
  4071ca:	nop
  4071cb:	nop
  4071cc:	nop
  4071cd:	nop
  4071ce:	nop
  4071cf:	nop

00000000004071d0 <clock_gettime@plt>:
  4071d0:	jmp    QWORD PTR [rip+0xaf22]        # 4120f8 <clock_gettime@GLIBC_2.17>
  4071d6:	nop
  4071d7:	nop
  4071d8:	nop
  4071d9:	nop
  4071da:	nop
  4071db:	nop
  4071dc:	nop
  4071dd:	nop
  4071de:	nop
  4071df:	nop

00000000004071e0 <__x86_get_cpuid_feature_leaf@plt>:
  4071e0:	jmp    QWORD PTR [rip+0xaf1a]        # 412100 <__x86_get_cpuid_feature_leaf@GLIBC_2.33>
  4071e6:	nop
  4071e7:	nop
  4071e8:	nop
  4071e9:	nop
  4071ea:	nop
  4071eb:	nop
  4071ec:	nop
  4071ed:	nop
  4071ee:	nop
  4071ef:	nop

00000000004071f0 <free@plt>:
  4071f0:	jmp    QWORD PTR [rip+0xaf12]        # 412108 <free@GLIBC_2.2.5>
  4071f6:	nop
  4071f7:	nop
  4071f8:	nop
  4071f9:	nop
  4071fa:	nop
  4071fb:	nop
  4071fc:	nop
  4071fd:	nop
  4071fe:	nop
  4071ff:	nop

Disassembly of section .text:

0000000000407200 <_start>:
  407200:	xor    ebp,ebp
  407202:	mov    r9,rdx
  407205:	pop    rsi
  407206:	mov    rdx,rsp
  407209:	and    rsp,0xfffffffffffffff0
  40720d:	push   rax
  40720e:	push   rsp
  40720f:	xor    r8d,r8d
  407212:	xor    ecx,ecx
  407214:	lea    rdi,[rip+0x25]        # 407240 <main>
  40721b:	call   QWORD PTR [rip+0xaddf]        # 412000 <__swc_fn_7dafa2b1_000179_1ca87929+0x580>
  407221:	hlt
	...

0000000000407240 <main>:
  407240:	sub    rsp,0x8
  407244:	mov    ecx,edi
  407246:	mov    rdx,rsi
  407249:	call   40ca40 <__swc_fn_7dafa2b1_000121_71a5b1cd>
  40724e:	xor    ecx,ecx
  407250:	call   40c160 <__swc_fn_7dafa2b1_000094_335e9a12>
  407255:	call   40d6b0 <__swc_fn_7dafa2b1_000178_a6773dec>
  40725a:	call   40f090 <__swc_fn_7dafa2b1_000095_a3245f7e>
  40725f:	add    rsp,0x8
  407263:	ret
	...

0000000000407270 <__swc_fn_7dafa2b1_000000_29b04951>:
  407270:	vxorps xmm0,xmm0,xmm0
  407274:	vmovups XMMWORD PTR [rcx],xmm0
  407278:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40727d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  407282:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  407287:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40728c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  407291:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  407296:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40729b:	ret
  40729c:	add    BYTE PTR [rax],al
	...

00000000004072a0 <__swc_fn_7dafa2b1_000003_644dadb7>:
  4072a0:	push   rsi
  4072a1:	mov    rsi,rdx
  4072a4:	test   rdx,rdx
  4072a7:	jne    4072b0 <__swc_fn_7dafa2b1_000003_644dadb7+0x10>
  4072a9:	mov    eax,0x1
  4072ae:	pop    rsi
  4072af:	ret
  4072b0:	mov    rdx,rsi
  4072b3:	call   409240 <__swc_fn_7dafa2b1_000111_e724f834>
  4072b8:	test   al,al
  4072ba:	jne    4072c0 <__swc_fn_7dafa2b1_000003_644dadb7+0x20>
  4072bc:	xor    eax,eax
  4072be:	pop    rsi
  4072bf:	ret
  4072c0:	lea    rcx,[rip+0x1bd81]        # 423048 <__swc_bss_base_7dafa2b1+0x8>
  4072c7:	mov    rdx,QWORD PTR [rip+0x1bd7a]        # 423048 <__swc_bss_base_7dafa2b1+0x8>
  4072ce:	xchg   ax,ax
  4072d0:	lea    r8,[rdx+rsi*1]
  4072d4:	mov    rax,rdx
  4072d7:	lock cmpxchg QWORD PTR [rcx],r8
  4072dc:	cmp    rax,rdx
  4072df:	je     4072e6 <__swc_fn_7dafa2b1_000003_644dadb7+0x46>
  4072e1:	mov    rdx,rax
  4072e4:	jmp    4072d0 <__swc_fn_7dafa2b1_000003_644dadb7+0x30>
  4072e6:	lea    rcx,[rip+0x1bd63]        # 423050 <__swc_bss_base_7dafa2b1+0x10>
  4072ed:	mov    rdx,QWORD PTR [rip+0x1bd5c]        # 423050 <__swc_bss_base_7dafa2b1+0x10>
  4072f4:	cs nop WORD PTR [rax+rax*1+0x0]
  4072fe:	xchg   ax,ax
  407300:	lea    r8,[rdx+0x1]
  407304:	mov    rax,rdx
  407307:	lock cmpxchg QWORD PTR [rcx],r8
  40730c:	cmp    rax,rdx
  40730f:	je     407316 <__swc_fn_7dafa2b1_000003_644dadb7+0x76>
  407311:	mov    rdx,rax
  407314:	jmp    407300 <__swc_fn_7dafa2b1_000003_644dadb7+0x60>
  407316:	mov    eax,0x1
  40731b:	pop    rsi
  40731c:	ret
  40731d:	add    BYTE PTR [rax],al
	...

0000000000407320 <__swc_fn_7dafa2b1_000006_12cb36a2>:
  407320:	push   rbx
  407321:	push   rsi
  407322:	push   rdi
  407323:	push   r12
  407325:	sub    rsp,0x18
  407329:	mov    rbx,rcx
  40732c:	mov    rsi,rcx
  40732f:	and    rsi,0xffffffffffc00000
  407336:	movzx  eax,BYTE PTR [rbx+0x3a]
  40733a:	mov    ecx,DWORD PTR [rsi+0x28]
  40733d:	shrx   eax,eax,ecx
  407342:	lea    rdi,[rsp+0x8]
  407347:	mov    DWORD PTR [rsp+0x8],eax
  40734b:	mov    rcx,rsi
  40734e:	mov    rax,rdi
  407351:	mov    edx,DWORD PTR [rax]
  407353:	call   40d940 <__swc_fn_7dafa2b1_000011_e75d466d>
  407358:	mov    r12,rax
  40735b:	mov    rcx,rsi
  40735e:	mov    edx,DWORD PTR [rdi]
  407360:	call   407450 <__swc_fn_7dafa2b1_000012_39679ef8>
  407365:	mov    rcx,r12
  407368:	mov    edx,DWORD PTR [rbx+0x3c]
  40736b:	add    rcx,rdx
  40736e:	cmp    rcx,rax
  407371:	jb     40737f <__swc_fn_7dafa2b1_000006_12cb36a2+0x5f>
  407373:	xor    eax,eax
  407375:	add    rsp,0x18
  407379:	pop    r12
  40737b:	pop    rdi
  40737c:	pop    rsi
  40737d:	pop    rbx
  40737e:	ret
  40737f:	mov    rdx,QWORD PTR [rbx+0x20]
  407383:	mov    r8d,DWORD PTR [rbx+0x2c]
  407387:	add    rdx,r8
  40738a:	lea    rsi,[rdx+0xffff]
  407391:	and    rsi,0xffffffffffff0000
  407398:	cmp    rax,rsi
  40739b:	cmovbe rsi,rax
  40739f:	mov    rax,rsi
  4073a2:	sub    rax,rcx
  4073a5:	mov    rdx,rax
  4073a8:	call   4072a0 <__swc_fn_7dafa2b1_000003_644dadb7>
  4073ad:	test   al,al
  4073af:	jne    4073bd <__swc_fn_7dafa2b1_000006_12cb36a2+0x9d>
  4073b1:	xor    eax,eax
  4073b3:	add    rsp,0x18
  4073b7:	pop    r12
  4073b9:	pop    rdi
  4073ba:	pop    rsi
  4073bb:	pop    rbx
  4073bc:	ret
  4073bd:	sub    rsi,r12
  4073c0:	mov    DWORD PTR [rbx+0x3c],esi
  4073c3:	mov    ecx,DWORD PTR [rbx+0x2c]
  4073c6:	mov    rax,rsi
  4073c9:	xor    edx,edx
  4073cb:	div    rcx
  4073ce:	imul   rax,rcx
  4073d2:	add    r12,rax
  4073d5:	mov    QWORD PTR [rbx+0x18],r12
  4073d9:	mov    eax,0x1
  4073de:	add    rsp,0x18
  4073e2:	pop    r12
  4073e4:	pop    rdi
  4073e5:	pop    rsi
  4073e6:	pop    rbx
  4073e7:	ret
	...

00000000004073f0 <__swc_fn_7dafa2b1_000009_2417e911>:
  4073f0:	sub    rsp,0x8
  4073f4:	mov    rdx,rcx
  4073f7:	lea    r9,[rcx+0x60]
  4073fb:	mov    rax,QWORD PTR [r9]
  4073fe:	test   rax,rax
  407401:	jne    407408 <__swc_fn_7dafa2b1_000009_2417e911+0x18>
  407403:	add    rsp,0x8
  407407:	ret
  407408:	mov    rcx,rdx
  40740b:	call   40a4f0 <__swc_fn_7dafa2b1_000007_635028f3>
  407410:	xor    eax,eax
  407412:	xchg   QWORD PTR [r9],rax
  407415:	mov    r8,rax
  407418:	mov    rcx,rdx
  40741b:	call   40d930 <__swc_fn_7dafa2b1_000008_578f1784>
  407420:	xor    eax,eax
  407422:	test   r8,r8
  407425:	je     407446 <__swc_fn_7dafa2b1_000009_2417e911+0x56>
  407427:	nop    WORD PTR [rax+rax*1+0x0]
  407430:	mov    rcx,QWORD PTR [r8]
  407433:	mov    r9,QWORD PTR [rdx]
  407436:	mov    QWORD PTR [r8],r9
  407439:	mov    QWORD PTR [rdx],r8
  40743c:	mov    r8,rcx
  40743f:	inc    eax
  407441:	test   rcx,rcx
  407444:	jne    407430 <__swc_fn_7dafa2b1_000009_2417e911+0x40>
  407446:	sub    DWORD PTR [rdx+0x28],eax
  407449:	add    rsp,0x8
  40744d:	ret
	...

0000000000407450 <__swc_fn_7dafa2b1_000012_39679ef8>:
  407450:	lea    eax,[rdx+0x1]
  407453:	mov    edx,DWORD PTR [rcx+0x28]
  407456:	shlx   eax,eax,edx
  40745b:	shl    rax,0x10
  40745f:	add    rax,rcx
  407462:	ret
	...

0000000000407470 <__swc_fn_7dafa2b1_000015_aa8c841a>:
  407470:	push   rbx
  407471:	push   rsi
  407472:	push   rdi
  407473:	push   r12
  407475:	push   r13
  407477:	push   r14
  407479:	push   r15
  40747b:	sub    rsp,0x30
  40747f:	mov    rbx,rcx
  407482:	lea    rsi,[rcx+0x48]
  407486:	mov    QWORD PTR [rsp+0x18],rsi
  40748b:	mov    rax,QWORD PTR [rsi]
  40748e:	mov    rdi,rax
  407491:	lea    r12,[rsp+0x8]
  407496:	lea    r13,[rcx+0x40]
  40749a:	nop    WORD PTR [rax+rax*1+0x0]
  4074a0:	test   rdi,rdi
  4074a3:	je     4075e3 <__swc_fn_7dafa2b1_000015_aa8c841a+0x173>
  4074a9:	xor    eax,eax
  4074ab:	tzcnt  rax,rdi
  4074b0:	mov    DWORD PTR [rsp+0x8],eax
  4074b4:	mov    r14d,0x1
  4074ba:	mov    ecx,eax
  4074bc:	shl    r14,cl
  4074bf:	andn   rdi,r14,rdi
  4074c4:	mov    rcx,QWORD PTR [r13+0x0]
  4074c8:	test   rcx,r14
  4074cb:	jne    4074a0 <__swc_fn_7dafa2b1_000015_aa8c841a+0x30>
  4074cd:	mov    rdx,rcx
  4074d0:	or     rdx,r14
  4074d3:	mov    rax,rcx
  4074d6:	lock cmpxchg QWORD PTR [r13+0x0],rdx
  4074dc:	cmp    rax,rcx
  4074df:	je     4074e9 <__swc_fn_7dafa2b1_000015_aa8c841a+0x79>
  4074e1:	mov    rax,QWORD PTR [rsi]
  4074e4:	mov    rdi,rax
  4074e7:	jmp    4074a0 <__swc_fn_7dafa2b1_000015_aa8c841a+0x30>
  4074e9:	mov    rcx,rbx
  4074ec:	mov    rdx,r14
  4074ef:	call   40daa0 <__swc_fn_7dafa2b1_000017_e238d24c>
  4074f4:	test   al,al
  4074f6:	je     4075ce <__swc_fn_7dafa2b1_000015_aa8c841a+0x15e>
  4074fc:	mov    eax,DWORD PTR [r12]
  407500:	shl    rax,0x4
  407504:	lea    r15,[rbx+rax*8+0x80]
  40750c:	rex mov esi,DWORD PTR [rbx+rax*8+0xbc]
  407514:	lea    rcx,[rip+0x1bb3d]        # 423058 <__swc_bss_base_7dafa2b1+0x18>
  40751b:	mov    rdx,QWORD PTR [rip+0x1bb36]        # 423058 <__swc_bss_base_7dafa2b1+0x18>
  407522:	cs nop WORD PTR [rax+rax*1+0x0]
  40752c:	nop    DWORD PTR [rax+0x0]
  407530:	mov    r8,rdx
  407533:	sub    r8,rsi
  407536:	mov    rax,rdx
  407539:	lock cmpxchg QWORD PTR [rcx],r8
  40753e:	cmp    rax,rdx
  407541:	je     407548 <__swc_fn_7dafa2b1_000015_aa8c841a+0xd8>
  407543:	mov    rdx,rax
  407546:	jmp    407530 <__swc_fn_7dafa2b1_000015_aa8c841a+0xc0>
  407548:	mov    rcx,rbx
  40754b:	mov    rax,r12
  40754e:	mov    edx,DWORD PTR [rax]
  407550:	call   40d940 <__swc_fn_7dafa2b1_000011_e75d466d>
  407555:	test   rsi,rsi
  407558:	je     4075c6 <__swc_fn_7dafa2b1_000015_aa8c841a+0x156>
  40755e:	mov    rcx,rax
  407561:	mov    rdx,rsi
  407564:	call   40c760 <__swc_fn_7dafa2b1_000112_cb2656be>
  407569:	lea    rcx,[rip+0x1bad8]        # 423048 <__swc_bss_base_7dafa2b1+0x8>
  407570:	mov    rdx,QWORD PTR [rip+0x1bad1]        # 423048 <__swc_bss_base_7dafa2b1+0x8>
  407577:	nop    WORD PTR [rax+rax*1+0x0]
  407580:	mov    r8,rdx
  407583:	sub    r8,rsi
  407586:	mov    rax,rdx
  407589:	lock cmpxchg QWORD PTR [rcx],r8
  40758e:	cmp    rax,rdx
  407591:	je     407598 <__swc_fn_7dafa2b1_000015_aa8c841a+0x128>
  407593:	mov    rdx,rax
  407596:	jmp    407580 <__swc_fn_7dafa2b1_000015_aa8c841a+0x110>
  407598:	lea    rcx,[rip+0x1bac1]        # 423060 <__swc_bss_base_7dafa2b1+0x20>
  40759f:	mov    rdx,QWORD PTR [rip+0x1baba]        # 423060 <__swc_bss_base_7dafa2b1+0x20>
  4075a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4075b0:	lea    r8,[rdx+0x1]
  4075b4:	mov    rax,rdx
  4075b7:	lock cmpxchg QWORD PTR [rcx],r8
  4075bc:	cmp    rax,rdx
  4075bf:	je     4075c6 <__swc_fn_7dafa2b1_000015_aa8c841a+0x156>
  4075c1:	mov    rdx,rax
  4075c4:	jmp    4075b0 <__swc_fn_7dafa2b1_000015_aa8c841a+0x140>
  4075c6:	mov    DWORD PTR [r15+0x3c],0x0
  4075ce:	mov    rcx,rbx
  4075d1:	mov    rdx,r14
  4075d4:	call   407600 <__swc_fn_7dafa2b1_000018_e2e8e4b0>
  4075d9:	mov    rsi,QWORD PTR [rsp+0x18]
  4075de:	jmp    4074a0 <__swc_fn_7dafa2b1_000015_aa8c841a+0x30>
  4075e3:	add    rsp,0x30
  4075e7:	pop    r15
  4075e9:	pop    r14
  4075eb:	pop    r13
  4075ed:	pop    r12
  4075ef:	pop    rdi
  4075f0:	pop    rsi
  4075f1:	pop    rbx
  4075f2:	ret
	...

0000000000407600 <__swc_fn_7dafa2b1_000018_e2e8e4b0>:
  407600:	mov    r8,QWORD PTR [rcx+0x40]
  407604:	cs nop WORD PTR [rax+rax*1+0x0]
  40760e:	xchg   ax,ax
  407610:	mov    rax,rdx
  407613:	not    rax
  407616:	mov    r9,r8
  407619:	and    r9,rax
  40761c:	mov    rax,r8
  40761f:	lock cmpxchg QWORD PTR [rcx+0x40],r9
  407625:	cmp    rax,r8
  407628:	jne    40762b <__swc_fn_7dafa2b1_000018_e2e8e4b0+0x2b>
  40762a:	ret
  40762b:	mov    r8,rax
  40762e:	jmp    407610 <__swc_fn_7dafa2b1_000018_e2e8e4b0+0x10>

0000000000407630 <__swc_fn_7dafa2b1_000021_fe13ecad>:
  407630:	push   rsi
  407631:	push   rdi
  407632:	sub    rsp,0x8
  407636:	mov    rsi,rcx
  407639:	call   407470 <__swc_fn_7dafa2b1_000015_aa8c841a>
  40763e:	lea    rdi,[rip+0x1bbab]        # 4231f0 <__swc_bss_base_7dafa2b1+0x1b0>
  407645:	mov    rcx,rdi
  407648:	call   4098a0 <__swc_fn_7dafa2b1_000135_1fec60ac>
  40764d:	mov    QWORD PTR [rsi+0x8],0x0
  407655:	mov    QWORD PTR [rsi+0x18],0x0
  40765d:	mov    rax,QWORD PTR [rip+0x1bb94]        # 4231f8 <__swc_bss_base_7dafa2b1+0x1b8>
  407664:	mov    QWORD PTR [rsi+0x10],rax
  407668:	mov    QWORD PTR [rip+0x1bb89],rsi        # 4231f8 <__swc_bss_base_7dafa2b1+0x1b8>
  40766f:	mov    rcx,rdi
  407672:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  407677:	add    rsp,0x8
  40767b:	pop    rdi
  40767c:	pop    rsi
  40767d:	ret
	...

0000000000407680 <__swc_fn_7dafa2b1_000024_7e9350e1>:
  407680:	vxorps xmm0,xmm0,xmm0
  407684:	vmovups XMMWORD PTR [rcx],xmm0
  407688:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40768d:	mov    QWORD PTR [rcx+0x20],0x0
  407695:	ret
	...

00000000004076a0 <__swc_fn_7dafa2b1_000027_7e9350e1>:
  4076a0:	vxorps xmm0,xmm0,xmm0
  4076a4:	vmovups XMMWORD PTR [rcx],xmm0
  4076a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4076ad:	mov    QWORD PTR [rcx+0x20],0x0
  4076b5:	ret
	...

00000000004076c0 <__swc_fn_7dafa2b1_000030_686c93a8>:
  4076c0:	push   r12
  4076c2:	mov    r12,rdi
  4076c5:	test   rdi,rdi
  4076c8:	jne    4076cd <__swc_fn_7dafa2b1_000030_686c93a8+0xd>
  4076ca:	pop    r12
  4076cc:	ret
  4076cd:	lea    rax,[rip+0x1992c]        # 421000 <__swc_data_base_7dafa2b1>
  4076d4:	mov    rax,QWORD PTR [rax]
  4076d7:	cmp    rax,0xffffffffffffffff
  4076db:	je     4076ea <__swc_fn_7dafa2b1_000030_686c93a8+0x2a>
  4076dd:	mov    eax,eax
  4076df:	mov    edi,eax
  4076e1:	xor    eax,eax
  4076e3:	call   407000 <pthread_getspecific@plt>
  4076e8:	jmp    4076ec <__swc_fn_7dafa2b1_000030_686c93a8+0x2c>
  4076ea:	xor    eax,eax
  4076ec:	cmp    rax,r12
  4076ef:	jne    4076f8 <__swc_fn_7dafa2b1_000030_686c93a8+0x38>
  4076f1:	xor    ecx,ecx
  4076f3:	call   40dc60 <__swc_fn_7dafa2b1_000032_8c89735c>
  4076f8:	mov    rdx,QWORD PTR [r12]
  4076fc:	test   rdx,rdx
  4076ff:	je     407718 <__swc_fn_7dafa2b1_000030_686c93a8+0x58>
  407701:	mov    rcx,rdx
  407704:	call   407740 <__swc_fn_7dafa2b1_000036_62160bb3>
  407709:	test   al,al
  40770b:	je     407718 <__swc_fn_7dafa2b1_000030_686c93a8+0x58>
  40770d:	mov    rcx,rdx
  407710:	mov    rdx,r12
  407713:	call   407840 <__swc_fn_7dafa2b1_000042_70d5ab54>
  407718:	pop    r12
  40771a:	ret
  40771b:	add    BYTE PTR [rax],al
  40771d:	add    BYTE PTR [rax],al
	...

0000000000407720 <__swc_fn_7dafa2b1_000033_7d7574b6>:
  407720:	push   rsi
  407721:	mov    rsi,rcx
  407724:	call   40a9a0 <__swc_fn_7dafa2b1_000031_ed8d61a9>
  407729:	mov    rcx,rax
  40772c:	mov    rdx,rsi
  40772f:	call   409720 <__swc_fn_7dafa2b1_000129_0672cd48>
  407734:	mov    rcx,rsi
  407737:	call   40dc60 <__swc_fn_7dafa2b1_000032_8c89735c>
  40773c:	pop    rsi
  40773d:	ret
	...

0000000000407740 <__swc_fn_7dafa2b1_000036_62160bb3>:
  407740:	cmp    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40774a:	sete   al
  40774d:	ret
	...

0000000000407750 <__swc_fn_7dafa2b1_000039_05a50673>:
  407750:	push   rsi
  407751:	test   rdx,rdx
  407754:	jne    407758 <__swc_fn_7dafa2b1_000039_05a50673+0x8>
  407756:	pop    rsi
  407757:	ret
  407758:	mov    rax,r8
  40775b:	mov    ecx,0x1000
  407760:	test   ecx,ecx
  407762:	mov    r10d,0x8
  407768:	cmove  ecx,r10d
  40776c:	dec    rcx
  40776f:	mov    r10,0xffffffffffffffff
  407776:	sub    r10,rcx
  407779:	cmp    r8,r10
  40777c:	jbe    407782 <__swc_fn_7dafa2b1_000039_05a50673+0x32>
  40777e:	xor    eax,eax
  407780:	jmp    40778a <__swc_fn_7dafa2b1_000039_05a50673+0x3a>
  407782:	add    rax,rcx
  407785:	andn   rax,rcx,rax
  40778a:	mov    ecx,0x1000
  40778f:	test   ecx,ecx
  407791:	mov    r8d,0x8
  407797:	cmove  ecx,r8d
  40779b:	dec    rcx
  40779e:	mov    r8,0xffffffffffffffff
  4077a5:	sub    r8,rcx
  4077a8:	cmp    r9,r8
  4077ab:	jbe    4077b1 <__swc_fn_7dafa2b1_000039_05a50673+0x61>
  4077ad:	xor    esi,esi
  4077af:	jmp    4077bc <__swc_fn_7dafa2b1_000039_05a50673+0x6c>
  4077b1:	add    r9,rcx
  4077b4:	andn   r9,rcx,r9
  4077b9:	mov    rsi,r9
  4077bc:	mov    rcx,rdx
  4077bf:	mov    rdx,rax
  4077c2:	mov    r8,rsi
  4077c5:	call   409320 <__swc_fn_7dafa2b1_000114_0575f585>
  4077ca:	lea    rcx,[rip+0x1b877]        # 423048 <__swc_bss_base_7dafa2b1+0x8>
  4077d1:	mov    rdx,QWORD PTR [rip+0x1b870]        # 423048 <__swc_bss_base_7dafa2b1+0x8>
  4077d8:	nop    DWORD PTR [rax+rax*1+0x0]
  4077e0:	mov    r8,rdx
  4077e3:	sub    r8,rsi
  4077e6:	mov    rax,rdx
  4077e9:	lock cmpxchg QWORD PTR [rcx],r8
  4077ee:	cmp    rax,rdx
  4077f1:	je     4077f8 <__swc_fn_7dafa2b1_000039_05a50673+0xa8>
  4077f3:	mov    rdx,rax
  4077f6:	jmp    4077e0 <__swc_fn_7dafa2b1_000039_05a50673+0x90>
  4077f8:	lea    rcx,[rip+0x1b861]        # 423060 <__swc_bss_base_7dafa2b1+0x20>
  4077ff:	mov    rdx,QWORD PTR [rip+0x1b85a]        # 423060 <__swc_bss_base_7dafa2b1+0x20>
  407806:	cs nop WORD PTR [rax+rax*1+0x0]
  407810:	lea    r8,[rdx+0x1]
  407814:	mov    rax,rdx
  407817:	lock cmpxchg QWORD PTR [rcx],r8
  40781c:	cmp    rax,rdx
  40781f:	je     407826 <__swc_fn_7dafa2b1_000039_05a50673+0xd6>
  407821:	mov    rdx,rax
  407824:	jmp    407810 <__swc_fn_7dafa2b1_000039_05a50673+0xc0>
  407826:	pop    rsi
  407827:	ret
	...

0000000000407840 <__swc_fn_7dafa2b1_000042_70d5ab54>:
  407840:	push   rbx
  407841:	push   rsi
  407842:	push   rdi
  407843:	push   r12
  407845:	push   r13
  407847:	push   r14
  407849:	push   r15
  40784b:	sub    rsp,0x30
  40784f:	mov    rbx,rdx
  407852:	mov    QWORD PTR [rsp+0x18],rdx
  407857:	mov    rsi,rcx
  40785a:	mov    eax,0x1
  40785f:	xchg   DWORD PTR [rbx+0x20],eax
  407862:	test   eax,eax
  407864:	je     407876 <__swc_fn_7dafa2b1_000042_70d5ab54+0x36>
  407866:	add    rsp,0x30
  40786a:	pop    r15
  40786c:	pop    r14
  40786e:	pop    r13
  407870:	pop    r12
  407872:	pop    rdi
  407873:	pop    rsi
  407874:	pop    rbx
  407875:	ret
  407876:	mov    rcx,rsi
  407879:	mov    rdx,rbx
  40787c:	mov    r8,0xffffffffffffffff
  407883:	call   40e230 <__swc_fn_7dafa2b1_000059_c8e1ff6b>
  407888:	lea    rdi,[rsi+0x10]
  40788c:	mov    QWORD PTR [rsp+0x20],rdi
  407891:	mov    rcx,rdi
  407894:	call   4098a0 <__swc_fn_7dafa2b1_000135_1fec60ac>
  407899:	xor    r12d,r12d
  40789c:	cs nop WORD PTR [rax+rax*1+0x0]
  4078a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4078b0:	mov    eax,r12d
  4078b3:	lea    r13,[rax+rax*4]
  4078b7:	lea    r13,[rbx+r13*8+0x28]
  4078bc:	mov    rax,QWORD PTR [r13+0x8]
  4078c0:	mov    QWORD PTR [rsp+0x8],rax
  4078c5:	mov    rax,QWORD PTR [r13+0x18]
  4078c9:	mov    QWORD PTR [rsp+0x10],rax
  4078ce:	mov    r14d,0x2
  4078d4:	xor    r15d,r15d
  4078d7:	test   r14,r14
  4078da:	je     407957 <__swc_fn_7dafa2b1_000042_70d5ab54+0x117>
  4078e0:	mov    rax,QWORD PTR [rsp+r15*8+0x8]
  4078e5:	mov    rdi,rax
  4078e8:	test   rdi,rdi
  4078eb:	je     407949 <__swc_fn_7dafa2b1_000042_70d5ab54+0x109>
  4078ed:	nop    DWORD PTR [rax]
  4078f0:	mov    rbx,QWORD PTR [rdi+0x48]
  4078f4:	mov    DWORD PTR [rdi+0x6c],0x0
  4078fb:	mov    rcx,rdi
  4078fe:	call   4073f0 <__swc_fn_7dafa2b1_000009_2417e911>
  407903:	cmp    DWORD PTR [rdi+0x28],0x0
  407907:	jne    407920 <__swc_fn_7dafa2b1_000042_70d5ab54+0xe0>
  407909:	mov    rax,rdi
  40790c:	and    rax,0xffffffffffc00000
  407913:	mov    rcx,rax
  407916:	mov    rdx,rdi
  407919:	call   40d960 <__swc_fn_7dafa2b1_000014_1acdaf22>
  40791e:	jmp    407941 <__swc_fn_7dafa2b1_000042_70d5ab54+0x101>
  407920:	mov    QWORD PTR [rdi+0x40],0x0
  407928:	rex mov BYTE PTR [rdi+0x3b],0x2
  40792d:	mov    QWORD PTR [rdi+0x50],0x0
  407935:	mov    rax,QWORD PTR [rsi+0x28]
  407939:	mov    QWORD PTR [rdi+0x48],rax
  40793d:	mov    QWORD PTR [rsi+0x28],rdi
  407941:	mov    rdi,rbx
  407944:	test   rbx,rbx
  407947:	jne    4078f0 <__swc_fn_7dafa2b1_000042_70d5ab54+0xb0>
  407949:	add    r15,0x1
  40794d:	sub    r14,0x1
  407951:	jne    4078e0 <__swc_fn_7dafa2b1_000042_70d5ab54+0xa0>
  407957:	vxorps xmm0,xmm0,xmm0
  40795b:	vmovdqu XMMWORD PTR [r13+0x0],xmm0
  407961:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  407967:	mov    QWORD PTR [r13+0x20],0x0
  40796f:	add    r12,0x1
  407973:	cmp    r12,0x2d
  407977:	mov    rbx,QWORD PTR [rsp+0x18]
  40797c:	jb     4078b0 <__swc_fn_7dafa2b1_000042_70d5ab54+0x70>
  407982:	mov    rcx,rsi
  407985:	mov    rbx,QWORD PTR [rsp+0x18]
  40798a:	mov    rdx,rbx
  40798d:	mov    rdi,QWORD PTR [rsp+0x20]
  407992:	call   40ab60 <__swc_fn_7dafa2b1_000043_3755033a>
  407997:	mov    rcx,rdi
  40799a:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  40799f:	mov    rcx,rsi
  4079a2:	mov    rdx,rbx
  4079a5:	mov    r8d,0x9b8
  4079ab:	mov    r9d,0x9b8
  4079b1:	call   407750 <__swc_fn_7dafa2b1_000039_05a50673>
  4079b6:	add    rsp,0x30
  4079ba:	pop    r15
  4079bc:	pop    r14
  4079be:	pop    r13
  4079c0:	pop    r12
  4079c2:	pop    rdi
  4079c3:	pop    rsi
  4079c4:	pop    rbx
  4079c5:	ret
	...

00000000004079e0 <__swc_fn_7dafa2b1_000045_06cec934>:
  4079e0:	push   rbx
  4079e1:	push   rsi
  4079e2:	push   rdi
  4079e3:	push   r12
  4079e5:	push   r13
  4079e7:	push   r14
  4079e9:	push   r15
  4079eb:	sub    rsp,0x30
  4079ef:	mov    ebx,r8d
  4079f2:	mov    rsi,rcx
  4079f5:	mov    rdi,rdx
  4079f8:	test   r8d,r8d
  4079fb:	jne    407a04 <__swc_fn_7dafa2b1_000045_06cec934+0x24>
  4079fd:	mov    eax,0x8
  407a02:	jmp    407a2b <__swc_fn_7dafa2b1_000045_06cec934+0x4b>
  407a04:	cmp    ebx,0x8
  407a07:	ja     407a12 <__swc_fn_7dafa2b1_000045_06cec934+0x32>
  407a09:	mov    rax,rbx
  407a0c:	shl    rax,0x4
  407a10:	jmp    407a2b <__swc_fn_7dafa2b1_000045_06cec934+0x4b>
  407a12:	lea    eax,[rbx-0x9]
  407a15:	mov    ecx,eax
  407a17:	shr    ecx,0x2
  407a1a:	and    eax,0x3
  407a1d:	lea    ecx,[rcx+0x7]
  407a20:	lea    ecx,[rcx-0x2]
  407a23:	lea    eax,[rax+0x5]
  407a26:	shlx   rax,rax,rcx
  407a2b:	lea    r12,[rsp+0x8]
  407a30:	mov    DWORD PTR [rsp+0x8],eax
  407a34:	lea    r13,[rsp+0xc]
  407a39:	mov    QWORD PTR [rsp+0x18],r13
  407a3e:	xor    eax,eax
  407a40:	cmp    ebx,0x21
  407a43:	setae  al
  407a46:	lea    eax,[rax+rax*2]
  407a49:	mov    DWORD PTR [rsp+0xc],eax
  407a4d:	lea    r14,[rsi+0x10]
  407a51:	mov    rcx,r14
  407a54:	call   4098a0 <__swc_fn_7dafa2b1_000135_1fec60ac>
  407a59:	xor    eax,eax
  407a5b:	mov    rcx,QWORD PTR [rsi+0x28]
  407a5f:	mov    r15,rcx
  407a62:	test   r15,r15
  407a65:	je     407b16 <__swc_fn_7dafa2b1_000045_06cec934+0x136>
  407a6b:	cs nop WORD PTR [rax+rax*1+0x0]
  407a75:	cs nop WORD PTR [rax+rax*1+0x0]
  407a7f:	nop
  407a80:	mov    rcx,QWORD PTR [r15+0x48]
  407a84:	movzx  edx,BYTE PTR [r15+0x39]
  407a89:	cmp    edx,ebx
  407a8b:	jne    407b07 <__swc_fn_7dafa2b1_000045_06cec934+0x127>
  407a8d:	test   rax,rax
  407a90:	jne    407a98 <__swc_fn_7dafa2b1_000045_06cec934+0xb8>
  407a92:	mov    QWORD PTR [rsi+0x28],rcx
  407a96:	jmp    407a9c <__swc_fn_7dafa2b1_000045_06cec934+0xbc>
  407a98:	mov    QWORD PTR [rax+0x48],rcx
  407a9c:	vxorps xmm0,xmm0,xmm0
  407aa0:	vmovdqu XMMWORD PTR [r15+0x48],xmm0
  407aa6:	mov    BYTE PTR [r15+0x3b],0x1
  407aab:	mov    QWORD PTR [r15+0x40],rdi
  407aaf:	mov    rcx,r15
  407ab2:	call   4073f0 <__swc_fn_7dafa2b1_000009_2417e911>
  407ab7:	movzx  eax,BYTE PTR [r15+0x39]
  407abc:	lea    rax,[rax+rax*4]
  407ac0:	lea    rax,[rdi+rax*8+0x28]
  407ac5:	mov    rcx,QWORD PTR [rax+0x10]
  407ac9:	mov    QWORD PTR [r15+0x50],rcx
  407acd:	mov    QWORD PTR [r15+0x48],0x0
  407ad5:	mov    rcx,QWORD PTR [rax+0x10]
  407ad9:	test   rcx,rcx
  407adc:	je     407ae4 <__swc_fn_7dafa2b1_000045_06cec934+0x104>
  407ade:	mov    QWORD PTR [rcx+0x48],r15
  407ae2:	jmp    407ae8 <__swc_fn_7dafa2b1_000045_06cec934+0x108>
  407ae4:	mov    QWORD PTR [rax+0x8],r15
  407ae8:	mov    QWORD PTR [rax+0x10],r15
  407aec:	mov    rcx,r14
  407aef:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  407af4:	mov    rax,r15
  407af7:	add    rsp,0x30
  407afb:	pop    r15
  407afd:	pop    r14
  407aff:	pop    r13
  407b01:	pop    r12
  407b03:	pop    rdi
  407b04:	pop    rsi
  407b05:	pop    rbx
  407b06:	ret
  407b07:	mov    rax,r15
  407b0a:	mov    r15,rcx
  407b0d:	test   rcx,rcx
  407b10:	jne    407a80 <__swc_fn_7dafa2b1_000045_06cec934+0xa0>
  407b16:	mov    rax,QWORD PTR [rsi+0x18]
  407b1a:	mov    r15,rax
  407b1d:	test   r15,r15
  407b20:	je     407bb6 <__swc_fn_7dafa2b1_000045_06cec934+0x1d6>
  407b26:	cs nop WORD PTR [rax+rax*1+0x0]
  407b30:	mov    eax,DWORD PTR [rsp+0xc]
  407b34:	cmp    DWORD PTR [r15+0x28],eax
  407b38:	jne    407ba6 <__swc_fn_7dafa2b1_000045_06cec934+0x1c6>
  407b3a:	mov    rcx,r15
  407b3d:	mov    edx,ebx
  407b3f:	mov    rax,r12
  407b42:	mov    r8d,DWORD PTR [rax]
  407b45:	call   40a5a0 <__swc_fn_7dafa2b1_000013_d15d37c6>
  407b4a:	mov    r13,rax
  407b4d:	test   rax,rax
  407b50:	je     407ba6 <__swc_fn_7dafa2b1_000045_06cec934+0x1c6>
  407b52:	mov    QWORD PTR [r13+0x40],rdi
  407b56:	movzx  eax,BYTE PTR [r13+0x39]
  407b5b:	lea    rax,[rax+rax*4]
  407b5f:	lea    rax,[rdi+rax*8+0x28]
  407b64:	mov    rcx,QWORD PTR [rax+0x10]
  407b68:	mov    QWORD PTR [r13+0x50],rcx
  407b6c:	mov    QWORD PTR [r13+0x48],0x0
  407b74:	mov    rcx,QWORD PTR [rax+0x10]
  407b78:	test   rcx,rcx
  407b7b:	je     407b83 <__swc_fn_7dafa2b1_000045_06cec934+0x1a3>
  407b7d:	mov    QWORD PTR [rcx+0x48],r13
  407b81:	jmp    407b87 <__swc_fn_7dafa2b1_000045_06cec934+0x1a7>
  407b83:	mov    QWORD PTR [rax+0x8],r13
  407b87:	mov    QWORD PTR [rax+0x10],r13
  407b8b:	mov    rcx,r14
  407b8e:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  407b93:	mov    rax,r13
  407b96:	add    rsp,0x30
  407b9a:	pop    r15
  407b9c:	pop    r14
  407b9e:	pop    r13
  407ba0:	pop    r12
  407ba2:	pop    rdi
  407ba3:	pop    rsi
  407ba4:	pop    rbx
  407ba5:	ret
  407ba6:	mov    rax,QWORD PTR [r15+0x10]
  407baa:	mov    r15,rax
  407bad:	test   rax,rax
  407bb0:	jne    407b30 <__swc_fn_7dafa2b1_000045_06cec934+0x150>
  407bb6:	mov    rcx,rsi
  407bb9:	mov    r13,QWORD PTR [rsp+0x18]
  407bbe:	mov    edx,DWORD PTR [r13+0x0]
  407bc2:	call   40dae0 <__swc_fn_7dafa2b1_000020_4135c89a>
  407bc7:	mov    r13,rax
  407bca:	test   rax,rax
  407bcd:	jne    407be9 <__swc_fn_7dafa2b1_000045_06cec934+0x209>
  407bcf:	mov    rcx,r14
  407bd2:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  407bd7:	xor    eax,eax
  407bd9:	add    rsp,0x30
  407bdd:	pop    r15
  407bdf:	pop    r14
  407be1:	pop    r13
  407be3:	pop    r12
  407be5:	pop    rdi
  407be6:	pop    rsi
  407be7:	pop    rbx
  407be8:	ret
  407be9:	mov    rcx,r13
  407bec:	mov    edx,ebx
  407bee:	mov    r8d,DWORD PTR [r12]
  407bf2:	call   40a5a0 <__swc_fn_7dafa2b1_000013_d15d37c6>
  407bf7:	mov    rbx,rax
  407bfa:	test   rax,rax
  407bfd:	jne    407c21 <__swc_fn_7dafa2b1_000045_06cec934+0x241>
  407bff:	mov    rcx,r13
  407c02:	call   407630 <__swc_fn_7dafa2b1_000021_fe13ecad>
  407c07:	mov    rcx,r14
  407c0a:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  407c0f:	xor    eax,eax
  407c11:	add    rsp,0x30
  407c15:	pop    r15
  407c17:	pop    r14
  407c19:	pop    r13
  407c1b:	pop    r12
  407c1d:	pop    rdi
  407c1e:	pop    rsi
  407c1f:	pop    rbx
  407c20:	ret
  407c21:	mov    rax,QWORD PTR [rsi+0x18]
  407c25:	mov    QWORD PTR [r13+0x10],rax
  407c29:	mov    rax,QWORD PTR [rsi+0x18]
  407c2d:	test   rax,rax
  407c30:	je     407c36 <__swc_fn_7dafa2b1_000045_06cec934+0x256>
  407c32:	mov    QWORD PTR [rax+0x18],r13
  407c36:	mov    QWORD PTR [rsi+0x18],r13
  407c3a:	mov    QWORD PTR [rbx+0x40],rdi
  407c3e:	movzx  eax,BYTE PTR [rbx+0x39]
  407c42:	lea    rax,[rax+rax*4]
  407c46:	lea    rax,[rdi+rax*8+0x28]
  407c4b:	mov    rcx,QWORD PTR [rax+0x10]
  407c4f:	mov    QWORD PTR [rbx+0x50],rcx
  407c53:	mov    QWORD PTR [rbx+0x48],0x0
  407c5b:	mov    rcx,QWORD PTR [rax+0x10]
  407c5f:	test   rcx,rcx
  407c62:	je     407c6a <__swc_fn_7dafa2b1_000045_06cec934+0x28a>
  407c64:	mov    QWORD PTR [rcx+0x48],rbx
  407c68:	jmp    407c6e <__swc_fn_7dafa2b1_000045_06cec934+0x28e>
  407c6a:	mov    QWORD PTR [rax+0x8],rbx
  407c6e:	mov    QWORD PTR [rax+0x10],rbx
  407c72:	mov    rcx,r14
  407c75:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  407c7a:	mov    rax,rbx
  407c7d:	add    rsp,0x30
  407c81:	pop    r15
  407c83:	pop    r14
  407c85:	pop    r13
  407c87:	pop    r12
  407c89:	pop    rdi
  407c8a:	pop    rsi
  407c8b:	pop    rbx
  407c8c:	ret
	...

0000000000407ca0 <__swc_fn_7dafa2b1_000048_18a95c9b>:
  407ca0:	push   rsi
  407ca1:	push   rdi
  407ca2:	push   r12
  407ca4:	mov    rsi,rdx
  407ca7:	mov    rdi,rcx
  407caa:	lea    rax,[rcx+0x2a80]
  407cb1:	mov    rcx,QWORD PTR [rax]
  407cb4:	test   rcx,rcx
  407cb7:	jne    407cbe <__swc_fn_7dafa2b1_000048_18a95c9b+0x1e>
  407cb9:	pop    r12
  407cbb:	pop    rdi
  407cbc:	pop    rsi
  407cbd:	ret
  407cbe:	xor    ecx,ecx
  407cc0:	xchg   QWORD PTR [rax],rcx
  407cc3:	mov    r12,rcx
  407cc6:	cs nop WORD PTR [rax+rax*1+0x0]
  407cd0:	cs nop WORD PTR [rax+rax*1+0x0]
  407cda:	nop    WORD PTR [rax+rax*1+0x0]
  407ce0:	test   r12,r12
  407ce3:	je     407d7a <__swc_fn_7dafa2b1_000048_18a95c9b+0xda>
  407ce9:	mov    r8,r12
  407cec:	mov    r12,QWORD PTR [r12+0x78]
  407cf1:	lea    rcx,[r8+0x70]
  407cf5:	xor    eax,eax
  407cf7:	xchg   DWORD PTR [r8+0x70],eax
  407cfb:	cmp    QWORD PTR [r8+0x40],rsi
  407cff:	jne    407d16 <__swc_fn_7dafa2b1_000048_18a95c9b+0x76>
  407d01:	mov    eax,DWORD PTR [r8+0x6c]
  407d05:	test   eax,eax
  407d07:	je     407ce0 <__swc_fn_7dafa2b1_000048_18a95c9b+0x40>
  407d09:	mov    rcx,rdi
  407d0c:	mov    rdx,rsi
  407d0f:	call   40de90 <__swc_fn_7dafa2b1_000047_3d3eceb4>
  407d14:	jmp    407ce0 <__swc_fn_7dafa2b1_000048_18a95c9b+0x40>
  407d16:	mov    rax,QWORD PTR [r8+0x40]
  407d1a:	test   rax,rax
  407d1d:	je     407ce0 <__swc_fn_7dafa2b1_000048_18a95c9b+0x40>
  407d1f:	mov    eax,DWORD PTR [r8+0x6c]
  407d23:	test   eax,eax
  407d25:	je     407ce0 <__swc_fn_7dafa2b1_000048_18a95c9b+0x40>
  407d27:	mov    r9d,0x1
  407d2d:	xor    eax,eax
  407d2f:	lock cmpxchg DWORD PTR [rcx],r9d
  407d34:	test   eax,eax
  407d36:	jne    407ce0 <__swc_fn_7dafa2b1_000048_18a95c9b+0x40>
  407d38:	mov    rax,r8
  407d3b:	and    rax,0xffffffffffc00000
  407d42:	mov    rax,QWORD PTR [rax+0x8]
  407d46:	test   rax,rax
  407d49:	jne    407d51 <__swc_fn_7dafa2b1_000048_18a95c9b+0xb1>
  407d4b:	xor    eax,eax
  407d4d:	xchg   DWORD PTR [rcx],eax
  407d4f:	jmp    407ce0 <__swc_fn_7dafa2b1_000048_18a95c9b+0x40>
  407d51:	lea    rcx,[rax+0x2a80]
  407d58:	mov    rax,QWORD PTR [rcx]
  407d5b:	mov    rdx,rax
  407d5e:	xchg   ax,ax
  407d60:	mov    QWORD PTR [r8+0x78],rdx
  407d64:	mov    rax,rdx
  407d67:	lock cmpxchg QWORD PTR [rcx],r8
  407d6c:	cmp    rax,rdx
  407d6f:	je     407ce0 <__swc_fn_7dafa2b1_000048_18a95c9b+0x40>
  407d75:	mov    rdx,rax
  407d78:	jmp    407d60 <__swc_fn_7dafa2b1_000048_18a95c9b+0xc0>
  407d7a:	pop    r12
  407d7c:	pop    rdi
  407d7d:	pop    rsi
  407d7e:	ret
	...

0000000000407d80 <__swc_fn_7dafa2b1_000051_5b91e689>:
  407d80:	sub    rsp,0x8
  407d84:	mov    r9,r8
  407d87:	movzx  eax,BYTE PTR [r9+0x39]
  407d8c:	lea    rax,[rax+rax*4]
  407d90:	lea    rax,[rdx+rax*8+0x28]
  407d95:	cmp    QWORD PTR [rax],r9
  407d98:	je     407da0 <__swc_fn_7dafa2b1_000051_5b91e689+0x20>
  407d9a:	cmp    QWORD PTR [rax+0x20],r9
  407d9e:	jne    407da5 <__swc_fn_7dafa2b1_000051_5b91e689+0x25>
  407da0:	add    rsp,0x8
  407da4:	ret
  407da5:	cmp    QWORD PTR [rax+0x20],0x0
  407daa:	je     407db7 <__swc_fn_7dafa2b1_000051_5b91e689+0x37>
  407dac:	mov    r8,QWORD PTR [rax+0x20]
  407db0:	cmp    DWORD PTR [r8+0x28],0x0
  407db5:	je     407dc0 <__swc_fn_7dafa2b1_000051_5b91e689+0x40>
  407db7:	mov    QWORD PTR [rax+0x20],r9
  407dbb:	add    rsp,0x8
  407dbf:	ret
  407dc0:	mov    r8,r9
  407dc3:	call   40ddf0 <__swc_fn_7dafa2b1_000044_cac7f504>
  407dc8:	mov    rax,r9
  407dcb:	and    rax,0xffffffffffc00000
  407dd2:	mov    rcx,rax
  407dd5:	mov    rdx,r9
  407dd8:	call   40d960 <__swc_fn_7dafa2b1_000014_1acdaf22>
  407ddd:	add    rsp,0x8
  407de1:	ret
	...

0000000000407df0 <__swc_fn_7dafa2b1_000054_1dfec8f6>:
  407df0:	push   rsi
  407df1:	push   rdi
  407df2:	push   r12
  407df4:	mov    rsi,rdx
  407df7:	mov    rax,rdx
  407dfa:	shr    rax,0xc
  407dfe:	movabs rdx,0x9e3779b97f4a7c15
  407e08:	imul   rax,rdx
  407e0c:	shr    rax,0x20
  407e10:	lea    rax,[rax*8+0x0]
  407e18:	shr    rax,0x20
  407e1c:	lea    rax,[rax*8+0x0]
  407e24:	lea    rax,[rcx+rax*8+0x40]
  407e29:	xor    edx,edx
  407e2b:	test   dl,dl
  407e2d:	lea    rdi,[rcx+0x8]
  407e31:	cmove  rdi,rax
  407e35:	xor    edx,edx
  407e37:	test   dl,dl
  407e39:	lea    r12,[rcx+0x30]
  407e3d:	lea    rax,[rax+0x8]
  407e41:	cmove  r12,rax
  407e45:	mov    rcx,rdi
  407e48:	call   4098a0 <__swc_fn_7dafa2b1_000135_1fec60ac>
  407e4d:	mov    rax,QWORD PTR [rsi+0x30]
  407e51:	test   rax,rax
  407e54:	jne    407e60 <__swc_fn_7dafa2b1_000054_1dfec8f6+0x70>
  407e56:	mov    rax,QWORD PTR [rsi+0x38]
  407e5a:	mov    QWORD PTR [r12],rax
  407e5e:	jmp    407e68 <__swc_fn_7dafa2b1_000054_1dfec8f6+0x78>
  407e60:	mov    rcx,QWORD PTR [rsi+0x38]
  407e64:	mov    QWORD PTR [rax+0x38],rcx
  407e68:	mov    rax,QWORD PTR [rsi+0x38]
  407e6c:	test   rax,rax
  407e6f:	je     407e79 <__swc_fn_7dafa2b1_000054_1dfec8f6+0x89>
  407e71:	mov    rcx,QWORD PTR [rsi+0x30]
  407e75:	mov    QWORD PTR [rax+0x30],rcx
  407e79:	vxorps xmm0,xmm0,xmm0
  407e7d:	vmovdqu XMMWORD PTR [rsi+0x30],xmm0
  407e82:	mov    rcx,rdi
  407e85:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  407e8a:	pop    r12
  407e8c:	pop    rdi
  407e8d:	pop    rsi
  407e8e:	ret
	...

0000000000407e90 <__swc_fn_7dafa2b1_000057_8be0372b>:
  407e90:	mov    rax,QWORD PTR [rcx+0x250]
  407e97:	mov    rcx,rax
  407e9a:	cmp    rax,0x1000000
  407ea1:	mov    eax,0x1000000
  407ea6:	cmovb  rcx,rax
  407eaa:	mov    rax,rcx
  407ead:	cmp    rcx,0x10000000
  407eb4:	mov    ecx,0x10000000
  407eb9:	cmova  rax,rcx
  407ebd:	ret
	...

0000000000407ec0 <__swc_fn_7dafa2b1_000060_9d59636e>:
  407ec0:	push   rsi
  407ec1:	push   rdi
  407ec2:	push   r12
  407ec4:	mov    rsi,rcx
  407ec7:	mov    rdi,QWORD PTR [rsi+0x2a70]
  407ece:	xor    r12d,r12d
  407ed1:	test   rdi,rdi
  407ed4:	jbe    407f0b <__swc_fn_7dafa2b1_000060_9d59636e+0x4b>
  407ed6:	cs nop WORD PTR [rax+rax*1+0x0]
  407ee0:	lea    rax,[r12+r12*4]
  407ee4:	lea    rax,[rsi+rax*8+0x268]
  407eec:	mov    rcx,rsi
  407eef:	mov    rdx,QWORD PTR [rax]
  407ef2:	mov    r8,QWORD PTR [rax+0x8]
  407ef6:	mov    rax,QWORD PTR [rax+0x10]
  407efa:	mov    r9,rax
  407efd:	call   407750 <__swc_fn_7dafa2b1_000039_05a50673>
  407f02:	add    r12,0x1
  407f06:	cmp    r12,rdi
  407f09:	jb     407ee0 <__swc_fn_7dafa2b1_000060_9d59636e+0x20>
  407f0b:	vxorps xmm0,xmm0,xmm0
  407f0f:	vmovdqu XMMWORD PTR [rsi+0x2a68],xmm0
  407f17:	pop    r12
  407f19:	pop    rdi
  407f1a:	pop    rsi
  407f1b:	ret
  407f1c:	add    BYTE PTR [rax],al
	...

0000000000407f20 <__swc_fn_7dafa2b1_000063_3509a564>:
  407f20:	push   rsi
  407f21:	push   rdi
  407f22:	sub    rsp,0x8
  407f26:	mov    rsi,rcx
  407f29:	call   40aee0 <__swc_fn_7dafa2b1_000052_26c6c1c4>
  407f2e:	mov    rdi,rax
  407f31:	mov    rcx,rsi
  407f34:	mov    rdx,rax
  407f37:	call   407df0 <__swc_fn_7dafa2b1_000054_1dfec8f6>
  407f3c:	mov    rcx,QWORD PTR [rdi+0x28]
  407f40:	mov    rdx,QWORD PTR [rsi+0x250]
  407f47:	nop    WORD PTR [rax+rax*1+0x0]
  407f50:	mov    r8,rdx
  407f53:	sub    r8,rcx
  407f56:	mov    rax,rdx
  407f59:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  407f62:	cmp    rax,rdx
  407f65:	je     407f6c <__swc_fn_7dafa2b1_000063_3509a564+0x4c>
  407f67:	mov    rdx,rax
  407f6a:	jmp    407f50 <__swc_fn_7dafa2b1_000063_3509a564+0x30>
  407f6c:	mov    rcx,rsi
  407f6f:	mov    rdx,QWORD PTR [rdi]
  407f72:	mov    r8,QWORD PTR [rdi+0x8]
  407f76:	mov    r9,QWORD PTR [rdi+0x10]
  407f7a:	call   40b000 <__swc_fn_7dafa2b1_000058_033ce1da>
  407f7f:	mov    rcx,rsi
  407f82:	call   40ac40 <__swc_fn_7dafa2b1_000049_781177b4>
  407f87:	add    rsp,0x8
  407f8b:	pop    rdi
  407f8c:	pop    rsi
  407f8d:	ret
	...

0000000000407f90 <__swc_fn_7dafa2b1_000066_77c6e829>:
  407f90:	push   r12
  407f92:	push   r13
  407f94:	push   r14
  407f96:	push   rdi
  407f97:	push   rsi
  407f98:	sub    rsp,0x1b0
  407f9f:	vmovups XMMWORD PTR [rsp+0x108],xmm6
  407fa8:	vmovups XMMWORD PTR [rsp+0x118],xmm7
  407fb1:	vmovups XMMWORD PTR [rsp+0x128],xmm8
  407fba:	vmovups XMMWORD PTR [rsp+0x138],xmm9
  407fc3:	vmovups XMMWORD PTR [rsp+0x148],xmm10
  407fcc:	vmovups XMMWORD PTR [rsp+0x158],xmm11
  407fd5:	vmovups XMMWORD PTR [rsp+0x168],xmm12
  407fde:	vmovups XMMWORD PTR [rsp+0x178],xmm13
  407fe7:	vmovups XMMWORD PTR [rsp+0x188],xmm14
  407ff0:	vmovups XMMWORD PTR [rsp+0x198],xmm15
  407ff9:	mov    r8,rdx
  407ffc:	mov    r12,rcx
  407fff:	mov    r13,QWORD PTR [r8+0x40]
  408003:	test   r13,r13
  408006:	jne    408018 <__swc_fn_7dafa2b1_000066_77c6e829+0x88>
  408008:	add    rsp,0x1b0
  40800f:	pop    rsi
  408010:	pop    rdi
  408011:	pop    r14
  408013:	pop    r13
  408015:	pop    r12
  408017:	ret
  408018:	mov    QWORD PTR [r8+0x40],0x0
  408020:	lea    rax,[rip+0x1b049]        # 423070 <__swc_bss_base_7dafa2b1+0x30>
  408027:	mov    rcx,r13
  40802a:	sub    rcx,QWORD PTR [rax+0x8]
  40802e:	mov    rax,QWORD PTR [rip+0x1b04b]        # 423080 <__swc_bss_base_7dafa2b1+0x40>
  408035:	cmp    rcx,rax
  408038:	jae    408064 <__swc_fn_7dafa2b1_000066_77c6e829+0xd4>
  40803a:	mov    rax,r13
  40803d:	and    rax,0xffffffffffc00000
  408044:	mov    rcx,r13
  408047:	shr    rcx,0x10
  40804b:	and    ecx,0x3f
  40804e:	mov    edx,DWORD PTR [rax+0x28]
  408051:	shrx   ecx,ecx,edx
  408056:	shl    rcx,0x4
  40805a:	lea    r14,[rax+rcx*8+0x80]
  408062:	jmp    40807f <__swc_fn_7dafa2b1_000066_77c6e829+0xef>
  408064:	mov    rcx,r13
  408067:	mov    QWORD PTR [rsp+0xf8],r8
  40806f:	call   40a8d0 <__swc_fn_7dafa2b1_000022_77c2d682>
  408074:	mov    r8,QWORD PTR [rsp+0xf8]
  40807c:	mov    r14,rax
  40807f:	test   r14,r14
  408082:	jne    408094 <__swc_fn_7dafa2b1_000066_77c6e829+0x104>
  408084:	mov    rcx,r12
  408087:	mov    rdx,r13
  40808a:	call   407f20 <__swc_fn_7dafa2b1_000063_3509a564>
  40808f:	jmp    408122 <__swc_fn_7dafa2b1_000066_77c6e829+0x192>
  408094:	lea    rax,[rip+0x18f65]        # 421000 <__swc_data_base_7dafa2b1>
  40809b:	mov    rax,QWORD PTR [rax]
  40809e:	cmp    rax,0xffffffffffffffff
  4080a2:	je     4080b1 <__swc_fn_7dafa2b1_000066_77c6e829+0x121>
  4080a4:	mov    eax,eax
  4080a6:	mov    edi,eax
  4080a8:	xor    eax,eax
  4080aa:	call   407000 <pthread_getspecific@plt>
  4080af:	jmp    4080b3 <__swc_fn_7dafa2b1_000066_77c6e829+0x123>
  4080b1:	xor    eax,eax
  4080b3:	test   rax,rax
  4080b6:	jne    4080c5 <__swc_fn_7dafa2b1_000066_77c6e829+0x135>
  4080b8:	call   40a9a0 <__swc_fn_7dafa2b1_000031_ed8d61a9>
  4080bd:	mov    rcx,rax
  4080c0:	call   40fe20 <__swc_fn_7dafa2b1_000128_9c45d2d7>
  4080c5:	test   rax,rax
  4080c8:	je     408117 <__swc_fn_7dafa2b1_000066_77c6e829+0x187>
  4080ca:	cmp    QWORD PTR [r14+0x40],rax
  4080ce:	jne    408117 <__swc_fn_7dafa2b1_000066_77c6e829+0x187>
  4080d0:	mov    ecx,DWORD PTR [r14+0x6c]
  4080d4:	test   ecx,ecx
  4080d6:	je     4080f6 <__swc_fn_7dafa2b1_000066_77c6e829+0x166>
  4080d8:	mov    rcx,r12
  4080db:	mov    rdx,rax
  4080de:	mov    r8,r14
  4080e1:	mov    QWORD PTR [rsp+0x100],rax
  4080e9:	call   40de90 <__swc_fn_7dafa2b1_000047_3d3eceb4>
  4080ee:	mov    rax,QWORD PTR [rsp+0x100]
  4080f6:	mov    rcx,QWORD PTR [r14]
  4080f9:	mov    QWORD PTR [r13+0x0],rcx
  4080fd:	mov    QWORD PTR [r14],r13
  408100:	sub    DWORD PTR [r14+0x28],0x1
  408105:	jne    408122 <__swc_fn_7dafa2b1_000066_77c6e829+0x192>
  408107:	mov    rcx,r12
  40810a:	mov    rdx,rax
  40810d:	mov    r8,r14
  408110:	call   407d80 <__swc_fn_7dafa2b1_000051_5b91e689>
  408115:	jmp    408122 <__swc_fn_7dafa2b1_000066_77c6e829+0x192>
  408117:	mov    rcx,r14
  40811a:	mov    rdx,r13
  40811d:	call   40a510 <__swc_fn_7dafa2b1_000010_186cd0c2>
  408122:	vmovups xmm6,XMMWORD PTR [rsp+0x108]
  40812b:	vmovups xmm7,XMMWORD PTR [rsp+0x118]
  408134:	vmovups xmm8,XMMWORD PTR [rsp+0x128]
  40813d:	vmovups xmm9,XMMWORD PTR [rsp+0x138]
  408146:	vmovups xmm10,XMMWORD PTR [rsp+0x148]
  40814f:	vmovups xmm11,XMMWORD PTR [rsp+0x158]
  408158:	vmovups xmm12,XMMWORD PTR [rsp+0x168]
  408161:	vmovups xmm13,XMMWORD PTR [rsp+0x178]
  40816a:	vmovups xmm14,XMMWORD PTR [rsp+0x188]
  408173:	vmovups xmm15,XMMWORD PTR [rsp+0x198]
  40817c:	add    rsp,0x1b0
  408183:	pop    rsi
  408184:	pop    rdi
  408185:	pop    r14
  408187:	pop    r13
  408189:	pop    r12
  40818b:	ret
  40818c:	add    BYTE PTR [rax],al
	...

0000000000408190 <__swc_fn_7dafa2b1_000069_165b6301>:
  408190:	push   rsi
  408191:	mov    rsi,rcx
  408194:	call   407740 <__swc_fn_7dafa2b1_000036_62160bb3>
  408199:	test   al,al
  40819b:	jne    40819f <__swc_fn_7dafa2b1_000069_165b6301+0xf>
  40819d:	pop    rsi
  40819e:	ret
  40819f:	lea    rax,[rip+0x1b09a]        # 423240 <__swc_bss_base_7dafa2b1+0x200>
  4081a6:	cmp    rsi,rax
  4081a9:	jne    4081ad <__swc_fn_7dafa2b1_000069_165b6301+0x1d>
  4081ab:	pop    rsi
  4081ac:	ret
  4081ad:	mov    rcx,rsi
  4081b0:	call   4098a0 <__swc_fn_7dafa2b1_000135_1fec60ac>
  4081b5:	mov    rcx,rsi
  4081b8:	call   40e660 <__swc_fn_7dafa2b1_000068_557d6092>
  4081bd:	mov    rcx,rsi
  4081c0:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  4081c5:	pop    rsi
  4081c6:	ret
	...

00000000004081d0 <__swc_fn_7dafa2b1_000072_b2caea81>:
  4081d0:	sub    rsp,0x8
  4081d4:	call   40e3b0 <__swc_fn_7dafa2b1_000065_cd9dd53e>
  4081d9:	add    rsp,0x8
  4081dd:	ret
	...

00000000004081e0 <__swc_fn_7dafa2b1_000075_104c4b5d>:
  4081e0:	push   rsi
  4081e1:	mov    rsi,rdx
  4081e4:	call   40e660 <__swc_fn_7dafa2b1_000068_557d6092>
  4081e9:	mov    QWORD PTR [rsi+0x40],0x0
  4081f1:	pop    rsi
  4081f2:	ret
	...

0000000000408200 <__swc_fn_7dafa2b1_000078_5a70c27a>:
  408200:	mov    r8,rcx
  408203:	mov    rcx,QWORD PTR [rcx]
  408206:	cs nop WORD PTR [rax+rax*1+0x0]
  408210:	mov    r9,rcx
  408213:	sub    r9,rdx
  408216:	mov    rax,rcx
  408219:	lock cmpxchg QWORD PTR [r8],r9
  40821e:	cmp    rax,rcx
  408221:	je     408228 <__swc_fn_7dafa2b1_000078_5a70c27a+0x28>
  408223:	mov    rcx,rax
  408226:	jmp    408210 <__swc_fn_7dafa2b1_000078_5a70c27a+0x10>
  408228:	mov    rax,rcx
  40822b:	ret
  40822c:	add    BYTE PTR [rax],al
	...

0000000000408230 <__swc_fn_7dafa2b1_000081_85585149>:
  408230:	vxorps xmm0,xmm0,xmm0
  408234:	vmovups XMMWORD PTR [rcx],xmm0
  408238:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40823d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  408242:	ret
	...

0000000000408250 <__swc_fn_7dafa2b1_000084_746bf146>:
  408250:	push   rsi
  408251:	push   rdi
  408252:	push   r12
  408254:	push   r13
  408256:	push   r15
  408258:	push   r14
  40825a:	push   rbx
  40825b:	sub    rsp,0x60
  40825f:	mov    QWORD PTR [rsp+0x28],r11
  408264:	mov    rsi,rcx
  408267:	mov    rdi,rdx
  40826a:	mov    QWORD PTR [rsp+0x30],rdx
  40826f:	mov    r12,r8
  408272:	mov    r13,r9
  408275:	mov    QWORD PTR [rsp+0x38],r10
  40827a:	xor    r8d,r8d
  40827d:	call   4085a0 <__swc_fn_7dafa2b1_000090_9a1d717d>
  408282:	test   al,al
  408284:	je     408299 <__swc_fn_7dafa2b1_000084_746bf146+0x49>
  408286:	mov    rax,r12
  408289:	add    rsp,0x60
  40828d:	pop    rbx
  40828e:	pop    r14
  408290:	pop    r15
  408292:	pop    r13
  408294:	pop    r12
  408296:	pop    rdi
  408297:	pop    rsi
  408298:	ret
  408299:	rex cmp BYTE PTR [rdi+0x2c],0xe
  40829e:	je     4082b2 <__swc_fn_7dafa2b1_000084_746bf146+0x62>
  4082a0:	xor    eax,eax
  4082a2:	add    rsp,0x60
  4082a6:	pop    rbx
  4082a7:	pop    r14
  4082a9:	pop    r15
  4082ab:	pop    r13
  4082ad:	pop    r12
  4082af:	pop    rdi
  4082b0:	pop    rsi
  4082b1:	ret
  4082b2:	mov    r15,rdi
  4082b5:	mov    QWORD PTR [rsp+0x40],rdi
  4082ba:	rex cmp BYTE PTR [rsi+0x2c],0x12
  4082bf:	jne    40832f <__swc_fn_7dafa2b1_000084_746bf146+0xdf>
  4082c1:	mov    r14,QWORD PTR [r15+0xb8]
  4082c8:	mov    rax,QWORD PTR [r15+0xc0]
  4082cf:	mov    r15,rax
  4082d2:	xor    edi,edi
  4082d4:	test   r15,r15
  4082d7:	je     40832f <__swc_fn_7dafa2b1_000084_746bf146+0xdf>
  4082d9:	nop    DWORD PTR [rax+0x0]
  4082e0:	lea    rbx,[rdi*8+0x0]
  4082e8:	mov    rax,QWORD PTR [r14+rbx*8+0x10]
  4082ed:	mov    rcx,rax
  4082f0:	mov    rdx,rsi
  4082f3:	xor    r8d,r8d
  4082f6:	call   4085a0 <__swc_fn_7dafa2b1_000090_9a1d717d>
  4082fb:	test   al,al
  4082fd:	je     408325 <__swc_fn_7dafa2b1_000084_746bf146+0xd5>
  4082ff:	mov    rax,QWORD PTR [r14+rbx*8+0x18]
  408304:	test   rax,rax
  408307:	je     408325 <__swc_fn_7dafa2b1_000084_746bf146+0xd5>
  408309:	test   r13,r13
  40830c:	je     408312 <__swc_fn_7dafa2b1_000084_746bf146+0xc2>
  40830e:	mov    QWORD PTR [r13+0x8],rax
  408312:	mov    rax,r12
  408315:	add    rsp,0x60
  408319:	pop    rbx
  40831a:	pop    r14
  40831c:	pop    r15
  40831e:	pop    r13
  408320:	pop    r12
  408322:	pop    rdi
  408323:	pop    rsi
  408324:	ret
  408325:	add    rdi,0x1
  408329:	sub    r15,0x1
  40832d:	jne    4082e0 <__swc_fn_7dafa2b1_000084_746bf146+0x90>
  40832f:	test   r12,r12
  408332:	jne    408346 <__swc_fn_7dafa2b1_000084_746bf146+0xf6>
  408334:	xor    eax,eax
  408336:	add    rsp,0x60
  40833a:	pop    rbx
  40833b:	pop    r14
  40833d:	pop    r15
  40833f:	pop    r13
  408341:	pop    r12
  408343:	pop    rdi
  408344:	pop    rsi
  408345:	ret
  408346:	mov    rbx,QWORD PTR [rsp+0x28]
  40834b:	mov    rdi,QWORD PTR [rsp+0x30]
  408350:	mov    rax,rbx
  408353:	test   rax,rax
  408356:	je     408386 <__swc_fn_7dafa2b1_000084_746bf146+0x136>
  408358:	nop    DWORD PTR [rax+rax*1+0x0]
  408360:	cmp    QWORD PTR [rax+0x8],r12
  408364:	jne    40837d <__swc_fn_7dafa2b1_000084_746bf146+0x12d>
  408366:	cmp    QWORD PTR [rax],rdi
  408369:	jne    40837d <__swc_fn_7dafa2b1_000084_746bf146+0x12d>
  40836b:	xor    eax,eax
  40836d:	add    rsp,0x60
  408371:	pop    rbx
  408372:	pop    r14
  408374:	pop    r15
  408376:	pop    r13
  408378:	pop    r12
  40837a:	pop    rdi
  40837b:	pop    rsi
  40837c:	ret
  40837d:	mov    rax,QWORD PTR [rax+0x10]
  408381:	test   rax,rax
  408384:	jne    408360 <__swc_fn_7dafa2b1_000084_746bf146+0x110>
  408386:	lea    r14,[rsp+0x8]
  40838b:	mov    QWORD PTR [rsp+0x48],r14
  408390:	mov    QWORD PTR [rsp+0x8],rdi
  408395:	mov    QWORD PTR [rsp+0x10],r12
  40839a:	mov    QWORD PTR [rsp+0x18],rbx
  40839f:	mov    r15,QWORD PTR [rsp+0x40]
  4083a4:	mov    rbx,QWORD PTR [r15+0x98]
  4083ab:	mov    rax,QWORD PTR [r15+0xa0]
  4083b2:	mov    rdi,rax
  4083b5:	mov    r15,QWORD PTR [rsp+0x38]
  4083ba:	xor    r14d,r14d
  4083bd:	test   rdi,rdi
  4083c0:	je     40846a <__swc_fn_7dafa2b1_000084_746bf146+0x21a>
  4083c6:	cs nop WORD PTR [rax+rax*1+0x0]
  4083d0:	mov    QWORD PTR [rsp+0x50],rdi
  4083d5:	lea    rdi,[r14*8+0x0]
  4083dd:	mov    rax,QWORD PTR [rbx+rdi*8+0x10]
  4083e2:	mov    rcx,rax
  4083e5:	call   40bfe0 <__swc_fn_7dafa2b1_000082_9f4f5092>
  4083ea:	test   DWORD PTR [rax+0x28],0x10000
  4083f1:	je     4083f8 <__swc_fn_7dafa2b1_000084_746bf146+0x1a8>
  4083f3:	test   r15b,r15b
  4083f6:	je     408451 <__swc_fn_7dafa2b1_000084_746bf146+0x201>
  4083f8:	mov    ecx,DWORD PTR [rbx+rdi*8+0x30]
  4083fc:	lea    rdi,[r12+rcx*1]
  408400:	cmp    BYTE PTR [rax+0x2c],0x6
  408404:	jne    408418 <__swc_fn_7dafa2b1_000084_746bf146+0x1c8>
  408406:	mov    rax,QWORD PTR [rax+0x40]
  40840a:	mov    rcx,rax
  40840d:	call   40bfe0 <__swc_fn_7dafa2b1_000082_9f4f5092>
  408412:	mov    rcx,QWORD PTR [rdi]
  408415:	mov    rdi,rcx
  408418:	test   rdi,rdi
  40841b:	je     408451 <__swc_fn_7dafa2b1_000084_746bf146+0x201>
  40841d:	mov    rcx,rsi
  408420:	mov    rdx,rax
  408423:	mov    r8,rdi
  408426:	mov    r9,r13
  408429:	mov    al,r15b
  40842c:	mov    r10,rax
  40842f:	mov    rdi,QWORD PTR [rsp+0x48]
  408434:	mov    r11,rdi
  408437:	call   408250 <__swc_fn_7dafa2b1_000084_746bf146>
  40843c:	test   rax,rax
  40843f:	je     408451 <__swc_fn_7dafa2b1_000084_746bf146+0x201>
  408441:	add    rsp,0x60
  408445:	pop    rbx
  408446:	pop    r14
  408448:	pop    r15
  40844a:	pop    r13
  40844c:	pop    r12
  40844e:	pop    rdi
  40844f:	pop    rsi
  408450:	ret
  408451:	add    r14,0x1
  408455:	mov    rax,QWORD PTR [rsp+0x50]
  40845a:	sub    rax,0x1
  40845e:	mov    rdi,rax
  408461:	test   rax,rax
  408464:	jne    4083d0 <__swc_fn_7dafa2b1_000084_746bf146+0x180>
  40846a:	xor    eax,eax
  40846c:	add    rsp,0x60
  408470:	pop    rbx
  408471:	pop    r14
  408473:	pop    r15
  408475:	pop    r13
  408477:	pop    r12
  408479:	pop    rdi
  40847a:	pop    rsi
  40847b:	ret
  40847c:	add    BYTE PTR [rax],al
	...

0000000000408480 <__swc_fn_7dafa2b1_000087_1fb4fcfe>:
  408480:	push   rsi
  408481:	push   rdi
  408482:	push   r12
  408484:	push   r13
  408486:	push   r14
  408488:	push   r15
  40848a:	sub    rsp,0x78
  40848e:	mov    rsi,r10
  408491:	mov    QWORD PTR [rsp+0x68],r10
  408496:	mov    rdi,rcx
  408499:	mov    r12,rdx
  40849c:	mov    r13,r8
  40849f:	mov    r14,r9
  4084a2:	xor    r8d,r8d
  4084a5:	call   4085a0 <__swc_fn_7dafa2b1_000090_9a1d717d>
  4084aa:	test   al,al
  4084ac:	je     4084d5 <__swc_fn_7dafa2b1_000087_1fb4fcfe+0x55>
  4084ae:	mov    rcx,r14
  4084b1:	mov    rdx,r12
  4084b4:	mov    r8,r13
  4084b7:	mov    r9,rsi
  4084ba:	call   40eac0 <__swc_fn_7dafa2b1_000086_ac8c6565>
  4084bf:	test   al,al
  4084c1:	je     4084d5 <__swc_fn_7dafa2b1_000087_1fb4fcfe+0x55>
  4084c3:	mov    rax,r13
  4084c6:	add    rsp,0x78
  4084ca:	pop    r15
  4084cc:	pop    r14
  4084ce:	pop    r13
  4084d0:	pop    r12
  4084d2:	pop    rdi
  4084d3:	pop    rsi
  4084d4:	ret
  4084d5:	cmp    BYTE PTR [r12+0x2c],0xe
  4084db:	je     4084ee <__swc_fn_7dafa2b1_000087_1fb4fcfe+0x6e>
  4084dd:	xor    eax,eax
  4084df:	add    rsp,0x78
  4084e3:	pop    r15
  4084e5:	pop    r14
  4084e7:	pop    r13
  4084e9:	pop    r12
  4084eb:	pop    rdi
  4084ec:	pop    rsi
  4084ed:	ret
  4084ee:	mov    r15,QWORD PTR [r12+0x98]
  4084f6:	mov    rax,QWORD PTR [r12+0xa0]
  4084fe:	mov    r12,rax
  408501:	xor    esi,esi
  408503:	test   r12,r12
  408506:	je     408579 <__swc_fn_7dafa2b1_000087_1fb4fcfe+0xf9>
  408508:	nop    DWORD PTR [rax+rax*1+0x0]
  408510:	mov    QWORD PTR [rsp+0x70],r12
  408515:	lea    r12,[rsi*8+0x0]
  40851d:	mov    rax,QWORD PTR [r15+r12*8+0x10]
  408522:	mov    rcx,rax
  408525:	call   40bfe0 <__swc_fn_7dafa2b1_000082_9f4f5092>
  40852a:	cmp    BYTE PTR [rax+0x2c],0xe
  40852e:	jne    408564 <__swc_fn_7dafa2b1_000087_1fb4fcfe+0xe4>
  408530:	mov    ecx,DWORD PTR [r15+r12*8+0x30]
  408535:	lea    r8,[r13+rcx*1+0x0]
  40853a:	mov    rcx,rdi
  40853d:	mov    rdx,rax
  408540:	mov    r9,r14
  408543:	mov    r12,QWORD PTR [rsp+0x68]
  408548:	mov    r10,r12
  40854b:	call   408480 <__swc_fn_7dafa2b1_000087_1fb4fcfe>
  408550:	test   rax,rax
  408553:	je     408564 <__swc_fn_7dafa2b1_000087_1fb4fcfe+0xe4>
  408555:	add    rsp,0x78
  408559:	pop    r15
  40855b:	pop    r14
  40855d:	pop    r13
  40855f:	pop    r12
  408561:	pop    rdi
  408562:	pop    rsi
  408563:	ret
  408564:	add    rsi,0x1
  408568:	mov    rax,QWORD PTR [rsp+0x70]
  40856d:	sub    rax,0x1
  408571:	mov    r12,rax
  408574:	test   rax,rax
  408577:	jne    408510 <__swc_fn_7dafa2b1_000087_1fb4fcfe+0x90>
  408579:	xor    eax,eax
  40857b:	add    rsp,0x78
  40857f:	pop    r15
  408581:	pop    r14
  408583:	pop    r13
  408585:	pop    r12
  408587:	pop    rdi
  408588:	pop    rsi
  408589:	ret
	...

00000000004085a0 <__swc_fn_7dafa2b1_000090_9a1d717d>:
  4085a0:	push   rbx
  4085a1:	push   rsi
  4085a2:	push   rdi
  4085a3:	push   r12
  4085a5:	push   r13
  4085a7:	push   r14
  4085a9:	push   r15
  4085ab:	sub    rsp,0x120
  4085b2:	mov    rbx,r8
  4085b5:	mov    rsi,rdx
  4085b8:	test   rcx,rcx
  4085bb:	jne    4085da <__swc_fn_7dafa2b1_000090_9a1d717d+0x3a>
  4085bd:	test   rsi,rsi
  4085c0:	jne    4085da <__swc_fn_7dafa2b1_000090_9a1d717d+0x3a>
  4085c2:	mov    eax,0x1
  4085c7:	add    rsp,0x120
  4085ce:	pop    r15
  4085d0:	pop    r14
  4085d2:	pop    r13
  4085d4:	pop    r12
  4085d6:	pop    rdi
  4085d7:	pop    rsi
  4085d8:	pop    rbx
  4085d9:	ret
  4085da:	test   rcx,rcx
  4085dd:	je     4085e4 <__swc_fn_7dafa2b1_000090_9a1d717d+0x44>
  4085df:	test   rsi,rsi
  4085e2:	jne    4085f9 <__swc_fn_7dafa2b1_000090_9a1d717d+0x59>
  4085e4:	xor    eax,eax
  4085e6:	add    rsp,0x120
  4085ed:	pop    r15
  4085ef:	pop    r14
  4085f1:	pop    r13
  4085f3:	pop    r12
  4085f5:	pop    rdi
  4085f6:	pop    rsi
  4085f7:	pop    rbx
  4085f8:	ret
  4085f9:	call   40bfe0 <__swc_fn_7dafa2b1_000082_9f4f5092>
  4085fe:	mov    rdi,rax
  408601:	mov    rcx,rsi
  408604:	call   40bfe0 <__swc_fn_7dafa2b1_000082_9f4f5092>
  408609:	test   bl,0x1
  40860c:	je     40864a <__swc_fn_7dafa2b1_000090_9a1d717d+0xaa>
  40860e:	rex cmp BYTE PTR [rdi+0x2c],0x6
  408613:	jne    40864a <__swc_fn_7dafa2b1_000090_9a1d717d+0xaa>
  408615:	mov    ecx,DWORD PTR [rdi+0x28]
  408618:	test   ecx,0x1000
  40861e:	je     40864a <__swc_fn_7dafa2b1_000090_9a1d717d+0xaa>
  408620:	test   ecx,0x10000
  408626:	je     40864a <__swc_fn_7dafa2b1_000090_9a1d717d+0xaa>
  408628:	mov    rcx,QWORD PTR [rdi+0x40]
  40862c:	mov    rdx,rax
  40862f:	mov    r8d,ebx
  408632:	call   4085a0 <__swc_fn_7dafa2b1_000090_9a1d717d>
  408637:	add    rsp,0x120
  40863e:	pop    r15
  408640:	pop    r14
  408642:	pop    r13
  408644:	pop    r12
  408646:	pop    rdi
  408647:	pop    rsi
  408648:	pop    rbx
  408649:	ret
  40864a:	mov    cl,BYTE PTR [rax+0x2c]
  40864d:	rex cmp BYTE PTR [rdi+0x2c],cl
  408651:	jne    40865b <__swc_fn_7dafa2b1_000090_9a1d717d+0xbb>
  408653:	mov    ecx,DWORD PTR [rax+0x20]
  408656:	cmp    DWORD PTR [rdi+0x20],ecx
  408659:	je     408670 <__swc_fn_7dafa2b1_000090_9a1d717d+0xd0>
  40865b:	xor    eax,eax
  40865d:	add    rsp,0x120
  408664:	pop    r15
  408666:	pop    r14
  408668:	pop    r13
  40866a:	pop    r12
  40866c:	pop    rdi
  40866d:	pop    rsi
  40866e:	pop    rbx
  40866f:	ret
  408670:	mov    ecx,DWORD PTR [rdi+0x28]
  408673:	and    ecx,0xffb5ffff
  408679:	mov    edx,DWORD PTR [rax+0x28]
  40867c:	and    edx,0xffb5ffff
  408682:	cmp    ecx,edx
  408684:	je     40869b <__swc_fn_7dafa2b1_000090_9a1d717d+0xfb>
  408686:	xor    eax,eax
  408688:	add    rsp,0x120
  40868f:	pop    r15
  408691:	pop    r14
  408693:	pop    r13
  408695:	pop    r12
  408697:	pop    rdi
  408698:	pop    rsi
  408699:	pop    rbx
  40869a:	ret
  40869b:	rex cmp BYTE PTR [rdi+0x2c],0x1
  4086a0:	jne    4086f5 <__swc_fn_7dafa2b1_000090_9a1d717d+0x155>
  4086a2:	mov    cl,BYTE PTR [rax+0x40]
  4086a5:	rex cmp BYTE PTR [rdi+0x40],cl
  4086a9:	je     4086c0 <__swc_fn_7dafa2b1_000090_9a1d717d+0x120>
  4086ab:	xor    eax,eax
  4086ad:	add    rsp,0x120
  4086b4:	pop    r15
  4086b6:	pop    r14
  4086b8:	pop    r13
  4086ba:	pop    r12
  4086bc:	pop    rdi
  4086bd:	pop    rsi
  4086be:	pop    rbx
  4086bf:	ret
  4086c0:	rex cmp BYTE PTR [rdi+0x40],0xd
  4086c5:	je     4086dd <__swc_fn_7dafa2b1_000090_9a1d717d+0x13d>
  4086c7:	rex cmp BYTE PTR [rdi+0x40],0xf
  4086cc:	sete   cl
  4086cf:	je     4086d9 <__swc_fn_7dafa2b1_000090_9a1d717d+0x139>
  4086d1:	rex cmp BYTE PTR [rdi+0x40],0xe
  4086d6:	sete   cl
  4086d9:	test   cl,cl
  4086db:	je     4086f5 <__swc_fn_7dafa2b1_000090_9a1d717d+0x155>
  4086dd:	mov    eax,0x1
  4086e2:	add    rsp,0x120
  4086e9:	pop    r15
  4086eb:	pop    r14
  4086ed:	pop    r13
  4086ef:	pop    r12
  4086f1:	pop    rdi
  4086f2:	pop    rsi
  4086f3:	pop    rbx
  4086f4:	ret
  4086f5:	test   DWORD PTR [rdi+0x28],0x200200
  4086fc:	je     4088af <__swc_fn_7dafa2b1_000090_9a1d717d+0x30f>
  408702:	mov    rsi,QWORD PTR [rdi+0x88]
  408709:	mov    rdi,QWORD PTR [rdi+0x90]
  408710:	mov    r12,QWORD PTR [rax+0x88]
  408717:	mov    rax,QWORD PTR [rax+0x90]
  40871e:	cmp    rdi,rax
  408721:	je     408738 <__swc_fn_7dafa2b1_000090_9a1d717d+0x198>
  408723:	xor    eax,eax
  408725:	add    rsp,0x120
  40872c:	pop    r15
  40872e:	pop    r14
  408730:	pop    r13
  408732:	pop    r12
  408734:	pop    rdi
  408735:	pop    rsi
  408736:	pop    rbx
  408737:	ret
  408738:	test   rsi,rsi
  40873b:	je     408742 <__swc_fn_7dafa2b1_000090_9a1d717d+0x1a2>
  40873d:	test   r12,r12
  408740:	jne    40875a <__swc_fn_7dafa2b1_000090_9a1d717d+0x1ba>
  408742:	mov    eax,0x1
  408747:	add    rsp,0x120
  40874e:	pop    r15
  408750:	pop    r14
  408752:	pop    r13
  408754:	pop    r12
  408756:	pop    rdi
  408757:	pop    rsi
  408758:	pop    rbx
  408759:	ret
  40875a:	xor    r13d,r13d
  40875d:	test   rdi,rdi
  408760:	jbe    408897 <__swc_fn_7dafa2b1_000090_9a1d717d+0x2f7>
  408766:	lea    r14,[rsp+0x78]
  40876b:	lea    r15,[rsp+0xb8]
  408773:	cs nop WORD PTR [rax+rax*1+0x0]
  40877d:	cs nop WORD PTR [rax+rax*1+0x0]
  408787:	nop    WORD PTR [rax+rax*1+0x0]
  408790:	lea    rax,[r13*8+0x0]
  408798:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8]
  40879d:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  4087a3:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x10]
  4087a9:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  4087b2:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x20]
  4087b8:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  4087c1:	vmovdqu xmm0,XMMWORD PTR [rsi+rax*8+0x30]
  4087c7:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  4087d0:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8]
  4087d6:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  4087df:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x10]
  4087e6:	vmovups XMMWORD PTR [rsp+0xc8],xmm0
  4087ef:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x20]
  4087f6:	vmovups XMMWORD PTR [rsp+0xd8],xmm0
  4087ff:	vmovdqu xmm0,XMMWORD PTR [r12+rax*8+0x30]
  408806:	vmovups XMMWORD PTR [rsp+0xe8],xmm0
  40880f:	xor    al,al
  408811:	rex test BYTE PTR [rsp+0xb0],0x1
  40881a:	je     408821 <__swc_fn_7dafa2b1_000090_9a1d717d+0x281>
  40881c:	mov    eax,0x1
  408821:	rex test BYTE PTR [rsp+0xf0],0x1
  40882a:	je     408831 <__swc_fn_7dafa2b1_000090_9a1d717d+0x291>
  40882c:	mov    eax,0x1
  408831:	test   al,al
  408833:	jne    408859 <__swc_fn_7dafa2b1_000090_9a1d717d+0x2b9>
  408835:	mov    rcx,r14
  408838:	mov    rdx,r15
  40883b:	call   409db0 <__swc_fn_7dafa2b1_000147_c9c6528e>
  408840:	test   al,al
  408842:	jne    408859 <__swc_fn_7dafa2b1_000090_9a1d717d+0x2b9>
  408844:	xor    eax,eax
  408846:	add    rsp,0x120
  40884d:	pop    r15
  40884f:	pop    r14
  408851:	pop    r13
  408853:	pop    r12
  408855:	pop    rdi
  408856:	pop    rsi
  408857:	pop    rbx
  408858:	ret
  408859:	mov    rcx,QWORD PTR [rsp+0x88]
  408861:	mov    rdx,QWORD PTR [rsp+0xc8]
  408869:	mov    r8d,ebx
  40886c:	call   4085a0 <__swc_fn_7dafa2b1_000090_9a1d717d>
  408871:	test   al,al
  408873:	jne    40888a <__swc_fn_7dafa2b1_000090_9a1d717d+0x2ea>
  408875:	xor    eax,eax
  408877:	add    rsp,0x120
  40887e:	pop    r15
  408880:	pop    r14
  408882:	pop    r13
  408884:	pop    r12
  408886:	pop    rdi
  408887:	pop    rsi
  408888:	pop    rbx
  408889:	ret
  40888a:	add    r13,0x1
  40888e:	cmp    r13,rdi
  408891:	jb     408790 <__swc_fn_7dafa2b1_000090_9a1d717d+0x1f0>
  408897:	mov    eax,0x1
  40889c:	add    rsp,0x120
  4088a3:	pop    r15
  4088a5:	pop    r14
  4088a7:	pop    r13
  4088a9:	pop    r12
  4088ab:	pop    rdi
  4088ac:	pop    rsi
  4088ad:	pop    rbx
  4088ae:	ret
  4088af:	test   bl,0x2
  4088b2:	je     4088d4 <__swc_fn_7dafa2b1_000090_9a1d717d+0x334>
  4088b4:	lea    rcx,[rdi+0x10]
  4088b8:	lea    rdx,[rax+0x10]
  4088bc:	call   409db0 <__swc_fn_7dafa2b1_000147_c9c6528e>
  4088c1:	add    rsp,0x120
  4088c8:	pop    r15
  4088ca:	pop    r14
  4088cc:	pop    r13
  4088ce:	pop    r12
  4088d0:	pop    rdi
  4088d1:	pop    rsi
  4088d2:	pop    rbx
  4088d3:	ret
  4088d4:	mov    rcx,rdi
  4088d7:	mov    rdx,rax
  4088da:	call   409db0 <__swc_fn_7dafa2b1_000147_c9c6528e>
  4088df:	add    rsp,0x120
  4088e6:	pop    r15
  4088e8:	pop    r14
  4088ea:	pop    r13
  4088ec:	pop    r12
  4088ee:	pop    rdi
  4088ef:	pop    rsi
  4088f0:	pop    rbx
  4088f1:	ret
	...

0000000000408900 <__swc_fn_7dafa2b1_000093_344f5089>:
  408900:	push   rbx
  408901:	mov    rbx,rcx
  408904:	call   40c110 <__swc_fn_7dafa2b1_000091_e6773530>
  408909:	movzx  r11d,al
  40890d:	mov    r8b,r11b
  408910:	test   r8b,r8b
  408913:	jne    40892d <__swc_fn_7dafa2b1_000093_344f5089+0x2d>
  408915:	mov    r11d,0x1
  40891b:	mov    r10,rbx
  40891e:	mov    r9,r11
  408921:	and    r10,r11
  408924:	test   r10,r10
  408927:	setne  dl
  40892a:	mov    r8b,dl
  40892d:	mov    r10b,r8b
  408930:	test   r10b,r10b
  408933:	je     408937 <__swc_fn_7dafa2b1_000093_344f5089+0x37>
  408935:	pop    rbx
  408936:	ret
  408937:	call   40ffc0 <__swc_fn_7dafa2b1_000137_899a611e>
  40893c:	movzx  r10d,al
  408940:	test   r10b,r10b
  408943:	je     408947 <__swc_fn_7dafa2b1_000093_344f5089+0x47>
  408945:	pop    rbx
  408946:	ret
  408947:	lea    r10,[rip+0x9872]        # 4121c0 <__swc_rdata_base_7dafa2b1+0xb0>
  40894e:	mov    rax,r10
  408951:	mov    rcx,rax
  408954:	call   40faf0 <__swc_fn_7dafa2b1_000116_3499f7d6>
  408959:	call   40c990 <__swc_fn_7dafa2b1_000118_2b35b5e0>
  40895e:	pop    rbx
  40895f:	ret

0000000000408960 <__swc_fn_7dafa2b1_000096_f879630a>:
  408960:	push   rbx
  408961:	sub    rsp,0x70
  408965:	vxorps xmm0,xmm0,xmm0
  408969:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40896f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  408975:	vzeroupper
  408978:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40897e:	mov    QWORD PTR [rsp+0x48],rdx
  408983:	mov    rax,r8
  408986:	cmp    r8,0x1
  40898a:	mov    edx,0x1
  40898f:	cmovb  rax,rdx
  408993:	mov    QWORD PTR [rsp+0x50],rax
  408998:	mov    rbx,QWORD PTR [rcx+0x8]
  40899c:	mov    rbx,QWORD PTR [rbx+0x18]
  4089a0:	mov    rcx,QWORD PTR [rcx]
  4089a3:	lea    rdx,[rsp+0x8]
  4089a8:	call   rbx
  4089aa:	add    rsp,0x70
  4089ae:	pop    rbx
  4089af:	ret

00000000004089b0 <__swc_fn_7dafa2b1_000099_6e0faaee>:
  4089b0:	push   rbx
  4089b1:	push   rsi
  4089b2:	push   rdi
  4089b3:	sub    rsp,0x30
  4089b7:	mov    rbx,rcx
  4089ba:	test   rcx,rcx
  4089bd:	je     4089d2 <__swc_fn_7dafa2b1_000099_6e0faaee+0x22>
  4089bf:	mov    rcx,rbx
  4089c2:	mov    edx,0x1
  4089c7:	call   408200 <__swc_fn_7dafa2b1_000078_5a70c27a>
  4089cc:	cmp    rax,0x1
  4089d0:	je     4089da <__swc_fn_7dafa2b1_000099_6e0faaee+0x2a>
  4089d2:	add    rsp,0x30
  4089d6:	pop    rdi
  4089d7:	pop    rsi
  4089d8:	pop    rbx
  4089d9:	ret
  4089da:	lea    rsi,[rsp+0x8]
  4089df:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  4089e4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4089ea:	vmovups xmm0,XMMWORD PTR [rbx+0x18]
  4089ef:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  4089f5:	mov    rax,QWORD PTR [rsp+0x20]
  4089fa:	test   rax,rax
  4089fd:	je     408a13 <__swc_fn_7dafa2b1_000099_6e0faaee+0x63>
  4089ff:	test   DWORD PTR [rax+0x28],0x400000
  408a06:	je     408a13 <__swc_fn_7dafa2b1_000099_6e0faaee+0x63>
  408a08:	mov    rcx,QWORD PTR [rax+0x30]
  408a0c:	test   rcx,rcx
  408a0f:	cmovne rax,rcx
  408a13:	mov    edi,DWORD PTR [rax+0x20]
  408a16:	lea    rcx,[rsp+0x18]
  408a1b:	call   40c2f0 <__swc_fn_7dafa2b1_000100_2ef16a3e>
  408a20:	mov    rcx,rsi
  408a23:	mov    rdx,QWORD PTR [rsp+0x18]
  408a28:	mov    r8,rdi
  408a2b:	call   408960 <__swc_fn_7dafa2b1_000096_f879630a>
  408a30:	mov    rcx,QWORD PTR [rbx+0x28]
  408a34:	call   40f0a0 <__swc_fn_7dafa2b1_000098_d9d80f1a>
  408a39:	mov    rcx,rsi
  408a3c:	mov    rdx,rbx
  408a3f:	mov    r8d,0x30
  408a45:	call   408960 <__swc_fn_7dafa2b1_000096_f879630a>
  408a4a:	add    rsp,0x30
  408a4e:	pop    rdi
  408a4f:	pop    rsi
  408a50:	pop    rbx
  408a51:	ret
	...

0000000000408a60 <__swc_fn_7dafa2b1_000102_29a1093a>:
  408a60:	push   rbp
  408a61:	push   rbx
  408a62:	push   rsi
  408a63:	push   rdi
  408a64:	push   r12
  408a66:	push   r13
  408a68:	push   r14
  408a6a:	push   r15
  408a6c:	sub    rsp,0x500
  408a73:	mov    rbp,rsp
  408a76:	mov    rbx,rsp
  408a79:	mov    rsi,rdx
  408a7c:	mov    rdi,rcx
  408a7f:	mov    rcx,QWORD PTR [rip+0x1d2ba]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  408a86:	test   rcx,rcx
  408a89:	jne    408aa3 <__swc_fn_7dafa2b1_000102_29a1093a+0x43>
  408a8b:	sub    rsp,0x8
  408a8f:	call   40a1a0 <__swc_fn_7dafa2b1_000165_e09accff>
  408a94:	add    rsp,0x8
  408a98:	lea    rcx,[rax+0x1]
  408a9c:	mov    QWORD PTR [rip+0x1d29d],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  408aa3:	dec    rcx
  408aa6:	sub    rsp,0x8
  408aaa:	call   4118a0 <__swc_fn_7dafa2b1_000167_3130645d>
  408aaf:	add    rsp,0x8
  408ab3:	mov    r12,rax
  408ab6:	mov    QWORD PTR [rsp+0x4f0],rax
  408abe:	lea    rax,[rip+0x983b]        # 412300 <__swc_rdata_base_7dafa2b1+0x1f0>
  408ac5:	sub    rsp,0x20
  408ac9:	mov    rcx,rsp
  408acc:	mov    QWORD PTR [rcx],rax
  408acf:	lea    r13,[rip+0x983a]        # 412310 <__swc_rdata_base_7dafa2b1+0x200>
  408ad6:	mov    QWORD PTR [rcx+0x8],r13
  408ada:	mov    QWORD PTR [rcx+0x10],rsp
  408ade:	mov    QWORD PTR [rcx+0x18],0x1
  408ae6:	lea    rcx,[rsp+0x10]
  408aeb:	sub    rsp,0x8
  408aef:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  408af4:	add    rsp,0x8
  408af8:	add    rsp,0x20
  408afc:	lea    rax,[rip+0x9855]        # 412358 <__swc_rdata_base_7dafa2b1+0x248>
  408b03:	sub    rsp,0x20
  408b07:	mov    rcx,rsp
  408b0a:	mov    QWORD PTR [rcx],rax
  408b0d:	mov    QWORD PTR [rcx+0x8],r13
  408b11:	mov    QWORD PTR [rcx+0x10],rsp
  408b15:	mov    QWORD PTR [rcx+0x18],0x1
  408b1d:	lea    rcx,[rsp+0x10]
  408b22:	sub    rsp,0x8
  408b26:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  408b2b:	add    rsp,0x8
  408b2f:	add    rsp,0x20
  408b33:	lea    r14,[rip+0x982e]        # 412368 <__swc_rdata_base_7dafa2b1+0x258>
  408b3a:	sub    rsp,0x50
  408b3e:	mov    rax,rsp
  408b41:	vmovups xmm0,XMMWORD PTR [rip+0x9957]        # 4124a0 <__swc_rdata_base_7dafa2b1+0x390>
  408b49:	vmovups XMMWORD PTR [rax],xmm0
  408b4d:	mov    QWORD PTR [rax+0x10],rsp
  408b51:	mov    QWORD PTR [rax+0x18],r13
  408b55:	mov    QWORD PTR [rax+0x20],rdi
  408b59:	lea    rdi,[rip+0x9818]        # 412378 <__swc_rdata_base_7dafa2b1+0x268>
  408b60:	mov    QWORD PTR [rax+0x28],rdi
  408b64:	mov    QWORD PTR [rax+0x30],r14
  408b68:	mov    QWORD PTR [rax+0x38],r13
  408b6c:	lea    rcx,[rsp+0x10]
  408b71:	mov    QWORD PTR [rax+0x40],rcx
  408b75:	mov    QWORD PTR [rax+0x48],0x3
  408b7d:	lea    rcx,[rsp+0x40]
  408b82:	sub    rsp,0x8
  408b86:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  408b8b:	add    rsp,0x8
  408b8f:	add    rsp,0x50
  408b93:	lea    rax,[rip+0x9826]        # 4123c0 <__swc_rdata_base_7dafa2b1+0x2b0>
  408b9a:	sub    rsp,0x20
  408b9e:	mov    rcx,rsp
  408ba1:	mov    QWORD PTR [rcx],rax
  408ba4:	mov    QWORD PTR [rcx+0x8],r13
  408ba8:	mov    QWORD PTR [rcx+0x10],rsp
  408bac:	mov    QWORD PTR [rcx+0x18],0x1
  408bb4:	lea    rcx,[rsp+0x10]
  408bb9:	sub    rsp,0x8
  408bbd:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  408bc2:	add    rsp,0x8
  408bc6:	add    rsp,0x20
  408bca:	mov    eax,DWORD PTR [rsi+0x20]
  408bcd:	mov    ecx,DWORD PTR [rsi+0x24]
  408bd0:	sub    rsp,0xa0
  408bd7:	mov    rdx,rsp
  408bda:	mov    QWORD PTR [rdx+0x30],rsi
  408bde:	mov    QWORD PTR [rdx+0x38],rdi
  408be2:	vmovups xmm0,XMMWORD PTR [rip+0x984e]        # 412438 <__swc_rdata_base_7dafa2b1+0x328>
  408bea:	vmovups XMMWORD PTR [rdx],xmm0
  408bee:	mov    QWORD PTR [rdx+0x40],rsp
  408bf2:	mov    QWORD PTR [rdx+0x48],r13
  408bf6:	mov    DWORD PTR [rdx+0x10],eax
  408bf9:	lea    rax,[rsp+0x10]
  408bfe:	mov    QWORD PTR [rdx+0x50],rax
  408c02:	lea    rax,[rip+0x97c7]        # 4123d0 <__swc_rdata_base_7dafa2b1+0x2c0>
  408c09:	mov    QWORD PTR [rdx+0x58],rax
  408c0d:	vmovups XMMWORD PTR [rdx+0x18],xmm0
  408c12:	lea    r8,[rsp+0x18]
  408c17:	mov    QWORD PTR [rdx+0x60],r8
  408c1b:	mov    QWORD PTR [rdx+0x68],r13
  408c1f:	mov    DWORD PTR [rdx+0x28],ecx
  408c22:	lea    rcx,[rdx+0x28]
  408c26:	mov    QWORD PTR [rdx+0x70],rcx
  408c2a:	mov    QWORD PTR [rdx+0x78],rax
  408c2e:	mov    QWORD PTR [rdx+0x80],r14
  408c35:	mov    QWORD PTR [rdx+0x88],r13
  408c3c:	lea    rax,[rdx+0x30]
  408c40:	mov    QWORD PTR [rdx+0x90],rax
  408c47:	mov    QWORD PTR [rdx+0x98],0x6
  408c52:	lea    rcx,[rdx+0x90]
  408c59:	sub    rsp,0x8
  408c5d:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  408c62:	add    rsp,0x8
  408c66:	add    rsp,0xa0
  408c6d:	sub    rsp,0x20
  408c71:	mov    rax,rsp
  408c74:	mov    QWORD PTR [rax],r14
  408c77:	mov    QWORD PTR [rax+0x8],r13
  408c7b:	mov    QWORD PTR [rax+0x10],rsp
  408c7f:	mov    QWORD PTR [rax+0x18],0x1
  408c87:	lea    rcx,[rsp+0x10]
  408c8c:	sub    rsp,0x8
  408c90:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  408c95:	add    rsp,0x8
  408c99:	add    rsp,0x20
  408c9d:	mov    eax,DWORD PTR [r12+0x9ac]
  408ca5:	test   eax,eax
  408ca7:	je     408ee0 <__swc_fn_7dafa2b1_000102_29a1093a+0x480>
  408cad:	lea    rax,[rip+0x9764]        # 412418 <__swc_rdata_base_7dafa2b1+0x308>
  408cb4:	sub    rsp,0x20
  408cb8:	mov    rcx,rsp
  408cbb:	mov    QWORD PTR [rcx],rax
  408cbe:	mov    QWORD PTR [rcx+0x8],r13
  408cc2:	mov    QWORD PTR [rcx+0x10],rsp
  408cc6:	mov    QWORD PTR [rcx+0x18],0x1
  408cce:	lea    rcx,[rsp+0x10]
  408cd3:	sub    rsp,0x8
  408cd7:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  408cdc:	add    rsp,0x8
  408ce0:	add    rsp,0x20
  408ce4:	mov    eax,DWORD PTR [r12+0x9ac]
  408cec:	dec    eax
  408cee:	mov    esi,eax
  408cf0:	test   esi,esi
  408cf2:	jl     408eb0 <__swc_fn_7dafa2b1_000102_29a1093a+0x450>
  408cf8:	jmp    408d04 <__swc_fn_7dafa2b1_000102_29a1093a+0x2a4>
  408cfa:	nop    WORD PTR [rax+rax*1+0x0]
  408d00:	dec    esi
  408d02:	jmp    408cf0 <__swc_fn_7dafa2b1_000102_29a1093a+0x290>
  408d04:	lea    rax,[rip+0x971d]        # 412428 <__swc_rdata_base_7dafa2b1+0x318>
  408d0b:	sub    rsp,0x20
  408d0f:	mov    rcx,rsp
  408d12:	mov    QWORD PTR [rcx],rax
  408d15:	mov    QWORD PTR [rcx+0x8],r13
  408d19:	mov    QWORD PTR [rcx+0x10],rsp
  408d1d:	mov    QWORD PTR [rcx+0x18],0x1
  408d25:	lea    rcx,[rsp+0x10]
  408d2a:	sub    rsp,0x8
  408d2e:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  408d33:	add    rsp,0x8
  408d37:	add    rsp,0x20
  408d3b:	movsxd rax,esi
  408d3e:	imul   r15,rax,0x30
  408d42:	add    r15,r12
  408d45:	add    r15,0xf8
  408d4c:	sub    rsp,0x20
  408d50:	mov    rax,rsp
  408d53:	mov    QWORD PTR [rax],r15
  408d56:	mov    QWORD PTR [rax+0x8],rdi
  408d5a:	mov    QWORD PTR [rax+0x10],rsp
  408d5e:	mov    QWORD PTR [rax+0x18],0x1
  408d66:	lea    rcx,[rsp+0x10]
  408d6b:	sub    rsp,0x8
  408d6f:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  408d74:	add    rsp,0x8
  408d78:	add    rsp,0x20
  408d7c:	mov    QWORD PTR [rsp+0x4f8],rsi
  408d84:	lea    rsi,[rip+0x96ad]        # 412438 <__swc_rdata_base_7dafa2b1+0x328>
  408d8b:	sub    rsp,0x20
  408d8f:	mov    rax,rsp
  408d92:	mov    QWORD PTR [rax],rsi
  408d95:	mov    QWORD PTR [rax+0x8],r13
  408d99:	mov    QWORD PTR [rax+0x10],rsp
  408d9d:	mov    QWORD PTR [rax+0x18],0x1
  408da5:	lea    rcx,[rsp+0x10]
  408daa:	sub    rsp,0x8
  408dae:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  408db3:	add    rsp,0x8
  408db7:	add    rsp,0x20
  408dbb:	sub    rsp,0x30
  408dbf:	mov    rax,rsp
  408dc2:	mov    ecx,DWORD PTR [r15+0x20]
  408dc6:	mov    QWORD PTR [rax],rcx
  408dc9:	mov    QWORD PTR [rax+0x8],rsp
  408dcd:	lea    rdi,[rip+0x9674]        # 412448 <__swc_rdata_base_7dafa2b1+0x338>
  408dd4:	mov    QWORD PTR [rax+0x10],rdi
  408dd8:	lea    rcx,[rsp+0x8]
  408ddd:	mov    QWORD PTR [rax+0x18],rcx
  408de1:	mov    QWORD PTR [rax+0x20],0x1
  408de9:	lea    rcx,[rsp+0x18]
  408dee:	sub    rsp,0x8
  408df2:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  408df7:	add    rsp,0x8
  408dfb:	add    rsp,0x30
  408dff:	sub    rsp,0x20
  408e03:	mov    rax,rsp
  408e06:	mov    QWORD PTR [rax],rsi
  408e09:	mov    QWORD PTR [rax+0x8],r13
  408e0d:	mov    QWORD PTR [rax+0x10],rsp
  408e11:	mov    QWORD PTR [rax+0x18],0x1
  408e19:	lea    rcx,[rsp+0x10]
  408e1e:	sub    rsp,0x8
  408e22:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  408e27:	add    rsp,0x8
  408e2b:	add    rsp,0x20
  408e2f:	sub    rsp,0x30
  408e33:	mov    rax,rsp
  408e36:	mov    ecx,DWORD PTR [r15+0x24]
  408e3a:	mov    QWORD PTR [rax],rcx
  408e3d:	mov    QWORD PTR [rax+0x8],rsp
  408e41:	mov    QWORD PTR [rax+0x10],rdi
  408e45:	lea    rcx,[rsp+0x8]
  408e4a:	mov    QWORD PTR [rax+0x18],rcx
  408e4e:	mov    QWORD PTR [rax+0x20],0x1
  408e56:	lea    rcx,[rsp+0x18]
  408e5b:	sub    rsp,0x8
  408e5f:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  408e64:	add    rsp,0x8
  408e68:	add    rsp,0x30
  408e6c:	sub    rsp,0x20
  408e70:	mov    rax,rsp
  408e73:	mov    QWORD PTR [rax],r14
  408e76:	mov    QWORD PTR [rax+0x8],r13
  408e7a:	mov    QWORD PTR [rax+0x10],rsp
  408e7e:	mov    QWORD PTR [rax+0x18],0x1
  408e86:	lea    rcx,[rsp+0x10]
  408e8b:	sub    rsp,0x8
  408e8f:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  408e94:	add    rsp,0x8
  408e98:	add    rsp,0x20
  408e9c:	lea    rdi,[rip+0x94d5]        # 412378 <__swc_rdata_base_7dafa2b1+0x268>
  408ea3:	mov    rsi,QWORD PTR [rsp+0x4f8]
  408eab:	jmp    408d00 <__swc_fn_7dafa2b1_000102_29a1093a+0x2a0>
  408eb0:	sub    rsp,0x20
  408eb4:	mov    rax,rsp
  408eb7:	mov    QWORD PTR [rax],r14
  408eba:	mov    QWORD PTR [rax+0x8],r13
  408ebe:	mov    QWORD PTR [rax+0x10],rsp
  408ec2:	mov    QWORD PTR [rax+0x18],0x1
  408eca:	lea    rcx,[rsp+0x10]
  408ecf:	sub    rsp,0x8
  408ed3:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  408ed8:	add    rsp,0x8
  408edc:	add    rsp,0x20
  408ee0:	lea    rax,[rbx+0x28]
  408ee4:	mov    rcx,rax
  408ee7:	mov    QWORD PTR [rbx+0x28],0x0
  408eef:	mov    QWORD PTR [rbx+0x30],0x0
  408ef7:	vmovups xmm0,XMMWORD PTR [rbx+0x28]
  408efc:	add    rcx,0x10
  408f00:	mov    edx,0x1f
  408f05:	cs nop WORD PTR [rax+rax*1+0x0]
  408f0f:	nop
  408f10:	vmovups XMMWORD PTR [rcx],xmm0
  408f14:	add    rcx,0x10
  408f18:	sub    rdx,0x1
  408f1c:	jne    408f10 <__swc_fn_7dafa2b1_000102_29a1093a+0x4b0>
  408f1e:	lea    rsi,[rbx+0x228]
  408f25:	xor    ecx,ecx
  408f27:	cs nop WORD PTR [rax+rax*1+0x0]
  408f31:	cs nop WORD PTR [rax+rax*1+0x0]
  408f3b:	nop    DWORD PTR [rax+rax*1+0x0]
  408f40:	vmovdqu xmm0,XMMWORD PTR [rax+rcx*1]
  408f45:	vmovdqu XMMWORD PTR [rsi+rcx*1],xmm0
  408f4a:	add    rcx,0x10
  408f4e:	cmp    rcx,0x200
  408f55:	jne    408f40 <__swc_fn_7dafa2b1_000102_29a1093a+0x4e0>
  408f57:	mov    eax,DWORD PTR [r12+0xbc8]
  408f5f:	lea    rcx,[r12+0x9c8]
  408f67:	mov    QWORD PTR [rbx+0x428],rcx
  408f6e:	mov    QWORD PTR [rbx+0x430],rax
  408f75:	lea    rdi,[rbx+0x438]
  408f7c:	vmovups xmm0,XMMWORD PTR [rbx+0x428]
  408f84:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408f8c:	mov    eax,DWORD PTR [r12+0xbc8]
  408f94:	test   eax,eax
  408f96:	jne    408fe3 <__swc_fn_7dafa2b1_000102_29a1093a+0x583>
  408f98:	lea    rax,[rbx+0x448]
  408f9f:	mov    QWORD PTR [rbx+0x448],rsi
  408fa6:	mov    QWORD PTR [rax+0x8],0x40
  408fae:	mov    ecx,0x1
  408fb3:	mov    rdx,rax
  408fb6:	sub    rsp,0x8
  408fba:	call   40fc00 <__swc_fn_7dafa2b1_000119_18cd3882>
  408fbf:	add    rsp,0x8
  408fc3:	mov    QWORD PTR [rbx+0x460],rsi
  408fca:	mov    ecx,eax
  408fcc:	mov    QWORD PTR [rbx+0x468],rcx
  408fd3:	vmovups xmm0,XMMWORD PTR [rbx+0x460]
  408fdb:	vmovups XMMWORD PTR [rbx+0x438],xmm0
  408fe3:	mov    rsi,QWORD PTR [rbx+0x438]
  408fea:	mov    rax,QWORD PTR [rbx+0x440]
  408ff1:	mov    r15,rax
  408ff4:	xor    r12d,r12d
  408ff7:	test   r15,r15
  408ffa:	je     4090b0 <__swc_fn_7dafa2b1_000102_29a1093a+0x650>
  409000:	mov    rax,QWORD PTR [rsi+r12*8]
  409004:	test   rax,rax
  409007:	je     409026 <__swc_fn_7dafa2b1_000102_29a1093a+0x5c6>
  409009:	lea    rcx,[rbx+0x4b8]
  409010:	mov    rdx,rax
  409013:	sub    rsp,0x8
  409017:	call   409f10 <__swc_fn_7dafa2b1_000162_edb9cf73>
  40901c:	add    rsp,0x8
  409020:	mov    al,BYTE PTR [rax]
  409022:	test   al,al
  409024:	jne    409032 <__swc_fn_7dafa2b1_000102_29a1093a+0x5d2>
  409026:	add    r12,0x1
  40902a:	sub    r15,0x1
  40902e:	jne    409000 <__swc_fn_7dafa2b1_000102_29a1093a+0x5a0>
  409030:	jmp    4090b0 <__swc_fn_7dafa2b1_000102_29a1093a+0x650>
  409032:	lea    rax,[rip+0x9457]        # 412490 <__swc_rdata_base_7dafa2b1+0x380>
  409039:	sub    rsp,0x20
  40903d:	mov    rcx,rsp
  409040:	mov    QWORD PTR [rcx],rax
  409043:	mov    QWORD PTR [rcx+0x8],r13
  409047:	mov    QWORD PTR [rcx+0x10],rsp
  40904b:	mov    QWORD PTR [rcx+0x18],0x1
  409053:	lea    rcx,[rsp+0x10]
  409058:	sub    rsp,0x8
  40905c:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  409061:	add    rsp,0x8
  409065:	add    rsp,0x20
  409069:	mov    rcx,rdi
  40906c:	xor    edx,edx
  40906e:	mov    al,0x1
  409070:	mov    r8,rax
  409073:	sub    rsp,0x8
  409077:	call   40d220 <__swc_fn_7dafa2b1_000163_5fbed98a>
  40907c:	add    rsp,0x8
  409080:	sub    rsp,0x20
  409084:	mov    rax,rsp
  409087:	mov    QWORD PTR [rax],r14
  40908a:	mov    QWORD PTR [rax+0x8],r13
  40908e:	mov    QWORD PTR [rax+0x10],rsp
  409092:	mov    QWORD PTR [rax+0x18],0x1
  40909a:	lea    rcx,[rsp+0x10]
  40909f:	sub    rsp,0x8
  4090a3:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  4090a8:	add    rsp,0x8
  4090ac:	add    rsp,0x20
  4090b0:	mov    r12,QWORD PTR [rsp+0x4f0]
  4090b8:	mov    DWORD PTR [r12+0xbc8],0x0
  4090c4:	add    rsp,0x500
  4090cb:	pop    r15
  4090cd:	pop    r14
  4090cf:	pop    r13
  4090d1:	pop    r12
  4090d3:	pop    rdi
  4090d4:	pop    rsi
  4090d5:	pop    rbx
  4090d6:	pop    rbp
  4090d7:	ret
	...

00000000004090e0 <__swc_fn_7dafa2b1_000105_b7aef7c0>:
  4090e0:	sub    rsp,0x8
  4090e4:	test   r8,r8
  4090e7:	je     4090ee <__swc_fn_7dafa2b1_000105_b7aef7c0+0xe>
  4090e9:	call   40f330 <__swc_fn_7dafa2b1_000104_baf871f8>
  4090ee:	add    rsp,0x8
  4090f2:	ret
	...

0000000000409100 <__swc_fn_7dafa2b1_000108_32416b9e>:
  409100:	push   rsi
  409101:	push   rdi
  409102:	push   r12
  409104:	push   r13
  409106:	sub    rsp,0xd8
  40910d:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  409113:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  409119:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40911f:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  409125:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40912b:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  409134:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40913d:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  409146:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40914f:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  409158:	xor    eax,eax
  40915a:	call   407010 <getpid@plt>
  40915f:	mov    rsi,rax
  409162:	lea    rdi,[rip+0x1cbdf]        # 425d48 <__swc_bss_base_7dafa2b1+0x2d08>
  409169:	mov    r12,QWORD PTR [rdi]
  40916c:	test   r12,r12
  40916f:	je     40917d <__swc_fn_7dafa2b1_000108_32416b9e+0x7d>
  409171:	cmp    DWORD PTR [r12+0x10],esi
  409176:	jne    40917d <__swc_fn_7dafa2b1_000108_32416b9e+0x7d>
  409178:	mov    rax,r12
  40917b:	jmp    4091e0 <__swc_fn_7dafa2b1_000108_32416b9e+0xe0>
  40917d:	mov    ecx,0x4
  409182:	mov    edx,0x18
  409187:	call   40f410 <__swc_fn_7dafa2b1_000107_ff529476>
  40918c:	mov    rcx,rax
  40918f:	test   rax,rax
  409192:	jne    409198 <__swc_fn_7dafa2b1_000108_32416b9e+0x98>
  409194:	xor    eax,eax
  409196:	jmp    4091e0 <__swc_fn_7dafa2b1_000108_32416b9e+0xe0>
  409198:	mov    DWORD PTR [rcx+0x10],esi
  40919b:	mov    rax,r12
  40919e:	lock cmpxchg QWORD PTR [rdi],rcx
  4091a3:	mov    r13,rax
  4091a6:	cmp    rax,r12
  4091a9:	je     4091bf <__swc_fn_7dafa2b1_000108_32416b9e+0xbf>
  4091ab:	mov    rdi,rcx
  4091ae:	mov    esi,0x18
  4091b3:	xor    eax,eax
  4091b5:	call   407020 <munmap@plt>
  4091ba:	mov    rax,r13
  4091bd:	jmp    4091e0 <__swc_fn_7dafa2b1_000108_32416b9e+0xe0>
  4091bf:	test   r12,r12
  4091c2:	je     4091dd <__swc_fn_7dafa2b1_000108_32416b9e+0xdd>
  4091c4:	mov    rdi,r12
  4091c7:	mov    esi,0x18
  4091cc:	xor    eax,eax
  4091ce:	mov    QWORD PTR [rsp+0x28],rcx
  4091d3:	call   407020 <munmap@plt>
  4091d8:	mov    rcx,QWORD PTR [rsp+0x28]
  4091dd:	mov    rax,rcx
  4091e0:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  4091e6:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  4091ec:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  4091f2:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  4091f8:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  4091fe:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  409207:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  409210:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  409219:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  409222:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40922b:	add    rsp,0xd8
  409232:	pop    r13
  409234:	pop    r12
  409236:	pop    rdi
  409237:	pop    rsi
  409238:	ret
  409239:	add    BYTE PTR [rax],al
  40923b:	add    BYTE PTR [rax],al
  40923d:	add    BYTE PTR [rax],al
	...

0000000000409240 <__swc_fn_7dafa2b1_000111_e724f834>:
  409240:	push   rbx
  409241:	push   r12
  409243:	push   rdi
  409244:	push   rsi
  409245:	sub    rsp,0xa8
  40924c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  409252:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409258:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40925e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409264:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40926a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  409270:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409276:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40927c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409285:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40928e:	mov    rbx,rdx
  409291:	mov    r12,rcx
  409294:	mov    rdi,rcx
  409297:	mov    rsi,rdx
  40929a:	mov    edx,0x3
  40929f:	xor    eax,eax
  4092a1:	call   407030 <mprotect@plt>
  4092a6:	test   eax,eax
  4092a8:	je     4092ae <__swc_fn_7dafa2b1_000111_e724f834+0x6e>
  4092aa:	xor    eax,eax
  4092ac:	jmp    4092c3 <__swc_fn_7dafa2b1_000111_e724f834+0x83>
  4092ae:	mov    rcx,r12
  4092b1:	mov    rdx,rbx
  4092b4:	mov    al,0x1
  4092b6:	mov    r8,rax
  4092b9:	call   40fa40 <__swc_fn_7dafa2b1_000110_e606239a>
  4092be:	mov    eax,0x1
  4092c3:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  4092c9:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4092cf:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4092d5:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4092db:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4092e1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4092e7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4092ed:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4092f3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4092fc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409305:	add    rsp,0xa8
  40930c:	pop    rsi
  40930d:	pop    rdi
  40930e:	pop    r12
  409310:	pop    rbx
  409311:	ret
	...

0000000000409320 <__swc_fn_7dafa2b1_000114_0575f585>:
  409320:	sub    rsp,0x8
  409324:	test   rcx,rcx
  409327:	jne    40932e <__swc_fn_7dafa2b1_000114_0575f585+0xe>
  409329:	add    rsp,0x8
  40932d:	ret
  40932e:	call   40c840 <__swc_fn_7dafa2b1_000115_259b5d5a>
  409333:	add    rsp,0x8
  409337:	ret
	...

0000000000409340 <__swc_fn_7dafa2b1_000117_76ff2f0a>:
  409340:	push   rdi
  409341:	push   rsi
  409342:	sub    rsp,0xa8
  409349:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40934f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409355:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40935b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409361:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409367:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40936d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409373:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409379:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409382:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40938b:	xor    edi,edi
  40938d:	xor    eax,eax
  40938f:	call   407040 <exit@plt>
  409394:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40939a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  4093a0:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  4093a6:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4093ac:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4093b2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4093b8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4093be:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4093c4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4093cd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4093d6:	add    rsp,0xa8
  4093dd:	pop    rsi
  4093de:	pop    rdi
  4093df:	ret

00000000004093e0 <__swc_fn_7dafa2b1_000120_1601f378>:
  4093e0:	push   rbx
  4093e1:	push   rsi
  4093e2:	push   rdi
  4093e3:	push   r12
  4093e5:	sub    rsp,0x18
  4093e9:	mov    rbx,r8
  4093ec:	mov    rsi,rcx
  4093ef:	mov    rdi,rdx
  4093f2:	mov    rcx,QWORD PTR [rip+0x1c947]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  4093f9:	test   rcx,rcx
  4093fc:	jne    40940e <__swc_fn_7dafa2b1_000120_1601f378+0x2e>
  4093fe:	call   40a1a0 <__swc_fn_7dafa2b1_000165_e09accff>
  409403:	lea    rcx,[rax+0x1]
  409407:	mov    QWORD PTR [rip+0x1c932],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40940e:	dec    rcx
  409411:	call   4118a0 <__swc_fn_7dafa2b1_000167_3130645d>
  409416:	mov    r12,rax
  409419:	cmp    ebx,0x3
  40941c:	jne    40942f <__swc_fn_7dafa2b1_000120_1601f378+0x4f>
  40941e:	mov    rax,QWORD PTR [r12+0xbd0]
  409426:	test   rax,rax
  409429:	jne    40956c <__swc_fn_7dafa2b1_000120_1601f378+0x18c>
  40942f:	cmp    ebx,0x5
  409432:	jne    409456 <__swc_fn_7dafa2b1_000120_1601f378+0x76>
  409434:	call   40c110 <__swc_fn_7dafa2b1_000091_e6773530>
  409439:	test   al,al
  40943b:	jne    409456 <__swc_fn_7dafa2b1_000120_1601f378+0x76>
  40943d:	mov    rcx,rsi
  409440:	mov    rdx,rdi
  409443:	call   411850 <__swc_fn_7dafa2b1_000164_15b66a30>
  409448:	test   al,al
  40944a:	je     409456 <__swc_fn_7dafa2b1_000120_1601f378+0x76>
  40944c:	add    rsp,0x18
  409450:	pop    r12
  409452:	pop    rdi
  409453:	pop    rsi
  409454:	pop    rbx
  409455:	ret
  409456:	call   40c110 <__swc_fn_7dafa2b1_000091_e6773530>
  40945b:	test   al,al
  40945d:	jne    4094cf <__swc_fn_7dafa2b1_000120_1601f378+0xef>
  40945f:	vmovups xmm0,XMMWORD PTR [rsi]
  409463:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409469:	mov    rax,QWORD PTR [rsp+0x8]
  40946e:	test   rax,rax
  409471:	jne    4094c2 <__swc_fn_7dafa2b1_000120_1601f378+0xe2>
  409473:	cmp    ebx,0x3
  409476:	je     409484 <__swc_fn_7dafa2b1_000120_1601f378+0xa4>
  409478:	cmp    ebx,0x4
  40947b:	je     409494 <__swc_fn_7dafa2b1_000120_1601f378+0xb4>
  40947d:	cmp    ebx,0x5
  409480:	je     4094a4 <__swc_fn_7dafa2b1_000120_1601f378+0xc4>
  409482:	jmp    4094b4 <__swc_fn_7dafa2b1_000120_1601f378+0xd4>
  409484:	vmovups xmm0,XMMWORD PTR [rip+0x9054]        # 4124e0 <__swc_rdata_base_7dafa2b1+0x3d0>
  40948c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409492:	jmp    4094c2 <__swc_fn_7dafa2b1_000120_1601f378+0xe2>
  409494:	vmovups xmm0,XMMWORD PTR [rip+0x9054]        # 4124f0 <__swc_rdata_base_7dafa2b1+0x3e0>
  40949c:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094a2:	jmp    4094c2 <__swc_fn_7dafa2b1_000120_1601f378+0xe2>
  4094a4:	vmovups xmm0,XMMWORD PTR [rip+0x9054]        # 412500 <__swc_rdata_base_7dafa2b1+0x3f0>
  4094ac:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094b2:	jmp    4094c2 <__swc_fn_7dafa2b1_000120_1601f378+0xe2>
  4094b4:	vmovups xmm0,XMMWORD PTR [rip+0x9054]        # 412510 <__swc_rdata_base_7dafa2b1+0x400>
  4094bc:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  4094c2:	lea    rcx,[rsp+0x8]
  4094c7:	mov    rdx,rdi
  4094ca:	call   40c360 <__swc_fn_7dafa2b1_000103_2ed36338>
  4094cf:	vmovups xmm0,XMMWORD PTR [rdi]
  4094d3:	vmovups XMMWORD PTR [r12+0x940],xmm0
  4094dd:	vmovups xmm0,XMMWORD PTR [rdi+0x10]
  4094e2:	vmovups XMMWORD PTR [r12+0x950],xmm0
  4094ec:	vmovups xmm0,XMMWORD PTR [rdi+0x20]
  4094f1:	vmovups XMMWORD PTR [r12+0x960],xmm0
  4094fb:	lea    rax,[r12+0x940]
  409503:	mov    QWORD PTR [r12+0x970],rax
  40950b:	mov    rax,QWORD PTR [rsi]
  40950e:	mov    QWORD PTR [r12+0x978],rax
  409516:	mov    rax,QWORD PTR [rsi+0x8]
  40951a:	mov    QWORD PTR [r12+0x980],rax
  409522:	movsxd rax,ebx
  409525:	mov    QWORD PTR [r12+0x988],rax
  40952d:	cmp    ebx,0x5
  409530:	je     409539 <__swc_fn_7dafa2b1_000120_1601f378+0x159>
  409532:	xor    ecx,ecx
  409534:	call   40a2d0 <__swc_fn_7dafa2b1_000174_738eec22>
  409539:	mov    rbx,QWORD PTR [r12+0xbe8]
  409541:	test   rbx,rbx
  409544:	je     409555 <__swc_fn_7dafa2b1_000120_1601f378+0x175>
  409546:	mov    rcx,r12
  409549:	call   rbx
  40954b:	add    rsp,0x18
  40954f:	pop    r12
  409551:	pop    rdi
  409552:	pop    rsi
  409553:	pop    rbx
  409554:	ret
  409555:	mov    rcx,rsi
  409558:	call   40faf0 <__swc_fn_7dafa2b1_000116_3499f7d6>
  40955d:	call   40c990 <__swc_fn_7dafa2b1_000118_2b35b5e0>
  409562:	add    rsp,0x18
  409566:	pop    r12
  409568:	pop    rdi
  409569:	pop    rsi
  40956a:	pop    rbx
  40956b:	ret
  40956c:	mov    rcx,rsi
  40956f:	mov    rdx,rdi
  409572:	call   40c360 <__swc_fn_7dafa2b1_000103_2ed36338>
  409577:	jmp    40942f <__swc_fn_7dafa2b1_000120_1601f378+0x4f>
  40957c:	add    BYTE PTR [rax],al
	...

0000000000409580 <__swc_fn_7dafa2b1_000123_e9227a3e>:
  409580:	push   rdi
  409581:	push   rsi
  409582:	sub    rsp,0xb8
  409589:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40958f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409595:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40959b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  4095a1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  4095a7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  4095ad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  4095b3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  4095bc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  4095c5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  4095ce:	mov    DWORD PTR [rsp+0x8],0x0
  4095d6:	lea    rdi,[rsp+0x8]
  4095db:	xor    esi,esi
  4095dd:	xor    eax,eax
  4095df:	call   407050 <pthread_key_create@plt>
  4095e4:	test   eax,eax
  4095e6:	jne    4095ee <__swc_fn_7dafa2b1_000123_e9227a3e+0x6e>
  4095e8:	mov    eax,DWORD PTR [rsp+0x8]
  4095ec:	jmp    4095f5 <__swc_fn_7dafa2b1_000123_e9227a3e+0x75>
  4095ee:	mov    rax,0xffffffffffffffff
  4095f5:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4095fb:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  409601:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  409607:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40960d:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  409613:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  409619:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40961f:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  409628:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409631:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40963a:	add    rsp,0xb8
  409641:	pop    rsi
  409642:	pop    rdi
  409643:	ret
	...

0000000000409650 <__swc_fn_7dafa2b1_000126_5fb20c72>:
  409650:	push   rdi
  409651:	push   rsi
  409652:	sub    rsp,0xb8
  409659:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40965f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  409665:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40966b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  409671:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  409677:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40967d:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  409683:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40968c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  409695:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40969e:	mov    DWORD PTR [rsp+0x8],0x0
  4096a6:	lea    rdi,[rsp+0x8]
  4096ab:	mov    rsi,rcx
  4096ae:	xor    eax,eax
  4096b0:	call   407050 <pthread_key_create@plt>
  4096b5:	test   eax,eax
  4096b7:	jne    4096c2 <__swc_fn_7dafa2b1_000126_5fb20c72+0x72>
  4096b9:	mov    eax,DWORD PTR [rsp+0x8]
  4096bd:	inc    rax
  4096c0:	jmp    4096c4 <__swc_fn_7dafa2b1_000126_5fb20c72+0x74>
  4096c2:	xor    eax,eax
  4096c4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  4096ca:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  4096d0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  4096d6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  4096dc:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  4096e2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  4096e8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  4096ee:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  4096f7:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  409700:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  409709:	add    rsp,0xb8
  409710:	pop    rsi
  409711:	pop    rdi
  409712:	ret
	...

0000000000409720 <__swc_fn_7dafa2b1_000129_0672cd48>:
  409720:	push   rdi
  409721:	push   rsi
  409722:	sub    rsp,0xa8
  409729:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40972f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  409735:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40973b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409741:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409747:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40974d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409753:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409759:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409762:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40976b:	test   rcx,rcx
  40976e:	setne  al
  409771:	je     40978a <__swc_fn_7dafa2b1_000129_0672cd48+0x6a>
  409773:	lea    rax,[rcx-0x1]
  409777:	mov    eax,eax
  409779:	mov    edi,eax
  40977b:	mov    rsi,rdx
  40977e:	xor    eax,eax
  409780:	call   407060 <pthread_setspecific@plt>
  409785:	test   eax,eax
  409787:	sete   al
  40978a:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  409790:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409796:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40979c:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  4097a2:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  4097a8:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  4097ae:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  4097b4:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  4097ba:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  4097c3:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  4097cc:	add    rsp,0xa8
  4097d3:	pop    rsi
  4097d4:	pop    rdi
  4097d5:	ret
	...

00000000004097e0 <__swc_fn_7dafa2b1_000132_2b60f756>:
  4097e0:	push   rdi
  4097e1:	push   rsi
  4097e2:	sub    rsp,0xa8
  4097e9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4097ef:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4097f5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4097fb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  409801:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  409807:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40980d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  409813:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  409819:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  409822:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40982b:	mov    rax,rdx
  40982e:	mov    QWORD PTR [rsp],0x0
  409836:	mov    edi,0xca
  40983b:	mov    rsi,rcx
  40983e:	mov    edx,0x81
  409843:	mov    eax,eax
  409845:	mov    ecx,eax
  409847:	xor    r8d,r8d
  40984a:	xor    r9d,r9d
  40984d:	xor    eax,eax
  40984f:	call   407070 <syscall@plt>
  409854:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40985a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  409860:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  409866:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40986c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  409872:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  409878:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40987e:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  409884:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40988d:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  409896:	add    rsp,0xa8
  40989d:	pop    rsi
  40989e:	pop    rdi
  40989f:	ret

00000000004098a0 <__swc_fn_7dafa2b1_000135_1fec60ac>:
  4098a0:	sub    rsp,0x8
  4098a4:	call   40cd30 <__swc_fn_7dafa2b1_000133_c6de0049>
  4098a9:	add    rsp,0x8
  4098ad:	ret
	...

00000000004098b0 <__swc_fn_7dafa2b1_000138_2214b637>:
  4098b0:	push   rdi
  4098b1:	push   rsi
  4098b2:	sub    rsp,0xc8
  4098b9:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4098bf:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4098c5:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4098cb:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4098d1:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4098d7:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4098dd:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  4098e6:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  4098ef:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  4098f8:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  409901:	vxorps xmm0,xmm0,xmm0
  409905:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40990b:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409911:	mov    rdi,rcx
  409914:	lea    rsi,[rsp+0x8]
  409919:	xor    eax,eax
  40991b:	call   407080 <dladdr@plt>
  409920:	xor    ecx,ecx
  409922:	test   eax,eax
  409924:	je     40992b <__swc_fn_7dafa2b1_000138_2214b637+0x7b>
  409926:	mov    rcx,QWORD PTR [rsp+0x10]
  40992b:	mov    rax,rcx
  40992e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  409934:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  40993a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  409940:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  409946:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  40994c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  409952:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  40995b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  409964:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  40996d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  409976:	add    rsp,0xc8
  40997d:	pop    rsi
  40997e:	pop    rdi
  40997f:	ret

0000000000409980 <__swc_fn_7dafa2b1_000141_376d5f6d>:
  409980:	push   rbx
  409981:	push   r12
  409983:	push   r13
  409985:	push   rdi
  409986:	push   rsi
  409987:	push   r14
  409989:	push   r15
  40998b:	sub    rsp,0x150
  409992:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40999b:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  4099a4:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  4099ad:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  4099b6:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  4099bf:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  4099c8:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  4099d1:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  4099da:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  4099e3:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  4099ec:	mov    rbx,rdx
  4099ef:	mov    QWORD PTR [rsp+0x98],rdx
  4099f7:	mov    r12,rcx
  4099fa:	mov    QWORD PTR [rsp+0xa0],rcx
  409a02:	mov    QWORD PTR [rbx],0x0
  409a09:	lea    r13,[rip+0x1c370]        # 425d80 <__swc_bss_base_7dafa2b1+0x2d40>
  409a10:	mov    rcx,r13
  409a13:	call   4098a0 <__swc_fn_7dafa2b1_000135_1fec60ac>
  409a18:	mov    rax,QWORD PTR [rip+0x1c369]        # 425d88 <__swc_bss_base_7dafa2b1+0x2d48>
  409a1f:	test   rax,rax
  409a22:	je     409a59 <__swc_fn_7dafa2b1_000141_376d5f6d+0xd9>
  409a24:	cs nop WORD PTR [rax+rax*1+0x0]
  409a2e:	xchg   ax,ax
  409a30:	cmp    QWORD PTR [rax+0x8],r12
  409a34:	jne    409a51 <__swc_fn_7dafa2b1_000141_376d5f6d+0xd1>
  409a36:	mov    rcx,QWORD PTR [rax+0x18]
  409a3a:	mov    QWORD PTR [rbx],rcx
  409a3d:	mov    rbx,QWORD PTR [rax+0x10]
  409a41:	mov    rcx,r13
  409a44:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  409a49:	mov    rax,rbx
  409a4c:	jmp    409c3b <__swc_fn_7dafa2b1_000141_376d5f6d+0x2bb>
  409a51:	mov    rax,QWORD PTR [rax]
  409a54:	test   rax,rax
  409a57:	jne    409a30 <__swc_fn_7dafa2b1_000141_376d5f6d+0xb0>
  409a59:	vxorps xmm0,xmm0,xmm0
  409a5d:	vmovups XMMWORD PTR [rsp+0x10],xmm0
  409a63:	vmovups XMMWORD PTR [rsp+0x20],xmm0
  409a69:	mov    rdi,r12
  409a6c:	lea    rsi,[rsp+0x10]
  409a71:	xor    eax,eax
  409a73:	call   407080 <dladdr@plt>
  409a78:	test   eax,eax
  409a7a:	sete   al
  409a7d:	je     409a8a <__swc_fn_7dafa2b1_000141_376d5f6d+0x10a>
  409a7f:	mov    rax,QWORD PTR [rsp+0x10]
  409a84:	test   rax,rax
  409a87:	sete   al
  409a8a:	test   al,al
  409a8c:	je     409a9d <__swc_fn_7dafa2b1_000141_376d5f6d+0x11d>
  409a8e:	mov    rcx,r13
  409a91:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  409a96:	xor    eax,eax
  409a98:	jmp    409c3b <__swc_fn_7dafa2b1_000141_376d5f6d+0x2bb>
  409a9d:	mov    rdi,QWORD PTR [rsp+0x10]
  409aa2:	mov    esi,0x80000
  409aa7:	xor    eax,eax
  409aa9:	call   407090 <open@plt>
  409aae:	lea    r14,[rsp+0x30]
  409ab3:	mov    DWORD PTR [rsp+0x30],eax
  409ab7:	cmp    DWORD PTR [r14],0x0
  409abb:	jge    409acc <__swc_fn_7dafa2b1_000141_376d5f6d+0x14c>
  409abd:	mov    rcx,r13
  409ac0:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  409ac5:	xor    eax,eax
  409ac7:	jmp    409c3b <__swc_fn_7dafa2b1_000141_376d5f6d+0x2bb>
  409acc:	mov    rax,r14
  409acf:	movsxd rdi,DWORD PTR [rax]
  409ad2:	xor    esi,esi
  409ad4:	mov    edx,0x2
  409ad9:	xor    eax,eax
  409adb:	call   4070a0 <lseek@plt>
  409ae0:	mov    r15,rax
  409ae3:	test   rax,rax
  409ae6:	jg     409b01 <__swc_fn_7dafa2b1_000141_376d5f6d+0x181>
  409ae8:	movsxd rdi,DWORD PTR [r14]
  409aeb:	xor    eax,eax
  409aed:	call   4070b0 <close@plt>
  409af2:	mov    rcx,r13
  409af5:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  409afa:	xor    eax,eax
  409afc:	jmp    409c3b <__swc_fn_7dafa2b1_000141_376d5f6d+0x2bb>
  409b01:	xor    edi,edi
  409b03:	mov    rsi,r15
  409b06:	mov    edx,0x1
  409b0b:	mov    ecx,0x2
  409b10:	mov    rax,r14
  409b13:	movsxd r8,DWORD PTR [rax]
  409b16:	xor    r9d,r9d
  409b19:	xor    eax,eax
  409b1b:	call   4070c0 <mmap@plt>
  409b20:	mov    rbx,rax
  409b23:	test   rax,rax
  409b26:	sete   al
  409b29:	cmp    rbx,0xffffffffffffffff
  409b2d:	sete   cl
  409b30:	or     al,cl
  409b32:	je     409b4d <__swc_fn_7dafa2b1_000141_376d5f6d+0x1cd>
  409b34:	movsxd rdi,DWORD PTR [r14]
  409b37:	xor    eax,eax
  409b39:	call   4070b0 <close@plt>
  409b3e:	mov    rcx,r13
  409b41:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  409b46:	xor    eax,eax
  409b48:	jmp    409c3b <__swc_fn_7dafa2b1_000141_376d5f6d+0x2bb>
  409b4d:	lea    rax,[rsp+0x50]
  409b52:	mov    QWORD PTR [rax],0x0
  409b59:	mov    rcx,rbx
  409b5c:	mov    rdx,r15
  409b5f:	mov    r8,rax
  409b62:	call   410080 <__swc_fn_7dafa2b1_000140_81b740ca>
  409b67:	mov    r12,rax
  409b6a:	test   rax,rax
  409b6d:	jne    409b95 <__swc_fn_7dafa2b1_000141_376d5f6d+0x215>
  409b6f:	mov    rdi,rbx
  409b72:	mov    rsi,r15
  409b75:	xor    eax,eax
  409b77:	call   407020 <munmap@plt>
  409b7c:	movsxd rdi,DWORD PTR [r14]
  409b7f:	xor    eax,eax
  409b81:	call   4070b0 <close@plt>
  409b86:	mov    rcx,r13
  409b89:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  409b8e:	xor    eax,eax
  409b90:	jmp    409c3b <__swc_fn_7dafa2b1_000141_376d5f6d+0x2bb>
  409b95:	mov    edi,0x20
  409b9a:	xor    eax,eax
  409b9c:	call   4070d0 <malloc@plt>
  409ba1:	test   rax,rax
  409ba4:	jne    409bc9 <__swc_fn_7dafa2b1_000141_376d5f6d+0x249>
  409ba6:	mov    rdi,rbx
  409ba9:	mov    rsi,r15
  409bac:	xor    eax,eax
  409bae:	call   407020 <munmap@plt>
  409bb3:	movsxd rdi,DWORD PTR [r14]
  409bb6:	xor    eax,eax
  409bb8:	call   4070b0 <close@plt>
  409bbd:	mov    rcx,r13
  409bc0:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  409bc5:	xor    eax,eax
  409bc7:	jmp    409c3b <__swc_fn_7dafa2b1_000141_376d5f6d+0x2bb>
  409bc9:	mov    rcx,QWORD PTR [rip+0x1c1b8]        # 425d88 <__swc_bss_base_7dafa2b1+0x2d48>
  409bd0:	mov    QWORD PTR [rsp+0x70],rcx
  409bd5:	mov    rcx,QWORD PTR [rsp+0xa0]
  409bdd:	mov    QWORD PTR [rsp+0x78],rcx
  409be2:	mov    QWORD PTR [rsp+0x80],r12
  409bea:	mov    rcx,QWORD PTR [rsp+0x50]
  409bef:	mov    QWORD PTR [rsp+0x88],rcx
  409bf7:	vmovups xmm0,XMMWORD PTR [rsp+0x70]
  409bfd:	vmovups XMMWORD PTR [rax],xmm0
  409c01:	vmovups xmm0,XMMWORD PTR [rsp+0x80]
  409c0a:	vmovups XMMWORD PTR [rax+0x10],xmm0
  409c0f:	mov    QWORD PTR [rip+0x1c172],rax        # 425d88 <__swc_bss_base_7dafa2b1+0x2d48>
  409c16:	mov    rax,QWORD PTR [rsp+0x50]
  409c1b:	mov    rbx,QWORD PTR [rsp+0x98]
  409c23:	mov    QWORD PTR [rbx],rax
  409c26:	movsxd rdi,DWORD PTR [r14]
  409c29:	xor    eax,eax
  409c2b:	call   4070b0 <close@plt>
  409c30:	mov    rcx,r13
  409c33:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  409c38:	mov    rax,r12
  409c3b:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  409c44:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  409c4d:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  409c56:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  409c5f:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  409c68:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  409c71:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  409c7a:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  409c83:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  409c8c:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  409c95:	add    rsp,0x150
  409c9c:	pop    r15
  409c9e:	pop    r14
  409ca0:	pop    rsi
  409ca1:	pop    rdi
  409ca2:	pop    r13
  409ca4:	pop    r12
  409ca6:	pop    rbx
  409ca7:	ret
	...

0000000000409cb0 <__swc_fn_7dafa2b1_000144_364559f5>:
  409cb0:	push   rbx
  409cb1:	sub    rsp,0xe0
  409cb8:	lea    rbx,[rsp+0x8]
  409cbd:	vxorps xmm0,xmm0,xmm0
  409cc1:	vmovups YMMWORD PTR [rbx],ymm0
  409cc5:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  409cca:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  409ccf:	vzeroupper
  409cd2:	mov    DWORD PTR [rbx+0x60],0x0
  409cd9:	mov    r8,rbx
  409cdc:	nop    DWORD PTR [rax+0x0]
  409ce0:	mov    r9,rcx
  409ce3:	movabs rcx,0xcccccccccccccccd
  409ced:	mov    rax,r9
  409cf0:	mul    rcx
  409cf3:	mov    r10,rdx
  409cf6:	shr    r10,0x3
  409cfa:	mov    rcx,r10
  409cfd:	imul   rdx,r10,0xa
  409d01:	sub    r9,rdx
  409d04:	mov    rdx,QWORD PTR [rip+0x8835]        # 412540 <__swc_rdata_base_7dafa2b1+0x430>
  409d0b:	mov    dl,BYTE PTR [rdx+r9*1+0x23]
  409d10:	mov    BYTE PTR [r8],dl
  409d13:	lea    rdx,[r8+0x1]
  409d17:	mov    r8,rdx
  409d1a:	test   r10,r10
  409d1d:	jne    409ce0 <__swc_fn_7dafa2b1_000144_364559f5+0x30>
  409d1f:	mov    BYTE PTR [rdx],0x0
  409d22:	sub    r8,0x1
  409d26:	mov    rax,rbx
  409d29:	cmp    rax,r8
  409d2c:	jae    409d46 <__swc_fn_7dafa2b1_000144_364559f5+0x96>
  409d2e:	xchg   ax,ax
  409d30:	mov    cl,BYTE PTR [r8]
  409d33:	mov    dl,BYTE PTR [rax]
  409d35:	mov    BYTE PTR [r8],dl
  409d38:	sub    r8,0x1
  409d3c:	mov    BYTE PTR [rax],cl
  409d3e:	inc    rax
  409d41:	cmp    rax,r8
  409d44:	jb     409d30 <__swc_fn_7dafa2b1_000144_364559f5+0x80>
  409d46:	xor    eax,eax
  409d48:	test   rbx,rbx
  409d4b:	je     409d6e <__swc_fn_7dafa2b1_000144_364559f5+0xbe>
  409d4d:	mov    rcx,rbx
  409d50:	mov    dl,BYTE PTR [rcx]
  409d52:	test   dl,dl
  409d54:	je     409d6e <__swc_fn_7dafa2b1_000144_364559f5+0xbe>
  409d56:	cs nop WORD PTR [rax+rax*1+0x0]
  409d60:	add    rcx,0x1
  409d64:	add    rax,0x1
  409d68:	mov    dl,BYTE PTR [rcx]
  409d6a:	test   dl,dl
  409d6c:	jne    409d60 <__swc_fn_7dafa2b1_000144_364559f5+0xb0>
  409d6e:	mov    QWORD PTR [rbx+0xa8],rbx
  409d75:	mov    QWORD PTR [rbx+0xb0],rax
  409d7c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  409d84:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  409d8c:	lea    rcx,[rbx+0xb8]
  409d93:	call   40faf0 <__swc_fn_7dafa2b1_000116_3499f7d6>
  409d98:	add    rsp,0xe0
  409d9f:	pop    rbx
  409da0:	ret
	...

0000000000409db0 <__swc_fn_7dafa2b1_000147_c9c6528e>:
  409db0:	sub    rsp,0x8
  409db4:	mov    rax,QWORD PTR [rcx+0x8]
  409db8:	mov    r8,QWORD PTR [rdx+0x8]
  409dbc:	cmp    rax,r8
  409dbf:	je     409dc8 <__swc_fn_7dafa2b1_000147_c9c6528e+0x18>
  409dc1:	xor    eax,eax
  409dc3:	add    rsp,0x8
  409dc7:	ret
  409dc8:	test   rax,rax
  409dcb:	jne    409ddc <__swc_fn_7dafa2b1_000147_c9c6528e+0x2c>
  409dcd:	test   r8,r8
  409dd0:	jne    409ddc <__swc_fn_7dafa2b1_000147_c9c6528e+0x2c>
  409dd2:	mov    eax,0x1
  409dd7:	add    rsp,0x8
  409ddb:	ret
  409ddc:	mov    rcx,QWORD PTR [rcx]
  409ddf:	mov    rdx,QWORD PTR [rdx]
  409de2:	test   rcx,rcx
  409de5:	sete   r8b
  409de9:	test   rdx,rdx
  409dec:	sete   r9b
  409df0:	or     r8b,r9b
  409df3:	je     409e00 <__swc_fn_7dafa2b1_000147_c9c6528e+0x50>
  409df5:	cmp    rcx,rdx
  409df8:	sete   al
  409dfb:	add    rsp,0x8
  409dff:	ret
  409e00:	cmp    rcx,rdx
  409e03:	jne    409e0f <__swc_fn_7dafa2b1_000147_c9c6528e+0x5f>
  409e05:	mov    eax,0x1
  409e0a:	add    rsp,0x8
  409e0e:	ret
  409e0f:	mov    r8,rax
  409e12:	call   40c420 <__swc_fn_7dafa2b1_000106_77a5d54a>
  409e17:	test   eax,eax
  409e19:	sete   al
  409e1c:	add    rsp,0x8
  409e20:	ret
	...

0000000000409e30 <__swc_fn_7dafa2b1_000150_33e5e24f>:
  409e30:	vxorps xmm0,xmm0,xmm0
  409e34:	vmovups XMMWORD PTR [rcx],xmm0
  409e38:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e3d:	vxorps xmm0,xmm0,xmm0
  409e41:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e46:	vmovups xmm0,XMMWORD PTR [rip+0x87aa]        # 4125f8 <__swc_rdata_base_7dafa2b1+0x4e8>
  409e4e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e53:	ret
	...

0000000000409e60 <__swc_fn_7dafa2b1_000153_33e5e24f>:
  409e60:	vxorps xmm0,xmm0,xmm0
  409e64:	vmovups XMMWORD PTR [rcx],xmm0
  409e68:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  409e6d:	vxorps xmm0,xmm0,xmm0
  409e71:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  409e76:	vmovups xmm0,XMMWORD PTR [rip+0x889a]        # 412718 <__swc_rdata_base_7dafa2b1+0x608>
  409e7e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  409e83:	mov    QWORD PTR [rcx+0x40],0x0
  409e8b:	ret
  409e8c:	add    BYTE PTR [rax],al
	...

0000000000409e90 <__swc_fn_7dafa2b1_000156_312df05a>:
  409e90:	push   rbx
  409e91:	sub    rsp,0x70
  409e95:	mov    rax,QWORD PTR [rcx]
  409e98:	mov    rbx,QWORD PTR [rcx+0x8]
  409e9c:	vxorps xmm0,xmm0,xmm0
  409ea0:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  409ea6:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  409eac:	vzeroupper
  409eaf:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  409eb5:	mov    QWORD PTR [rsp+0x48],rdx
  409eba:	mov    QWORD PTR [rsp+0x50],r8
  409ebf:	mov    rcx,rax
  409ec2:	lea    rdx,[rsp+0x8]
  409ec7:	mov    rbx,QWORD PTR [rbx+0x18]
  409ecb:	call   rbx
  409ecd:	add    rsp,0x70
  409ed1:	pop    rbx
  409ed2:	ret
	...

0000000000409ee0 <__swc_fn_7dafa2b1_000159_9d602c76>:
  409ee0:	push   rbx
  409ee1:	push   rsi
  409ee2:	push   rdi
  409ee3:	mov    rbx,r8
  409ee6:	mov    rsi,rcx
  409ee9:	mov    rdi,rdx
  409eec:	call   40d130 <__swc_fn_7dafa2b1_000157_5c8b11d8>
  409ef1:	vmovups xmm0,XMMWORD PTR [rbx]
  409ef5:	vmovups XMMWORD PTR [rsi],xmm0
  409ef9:	mov    QWORD PTR [rsi+0x18],rdi
  409efd:	pop    rdi
  409efe:	pop    rsi
  409eff:	pop    rbx
  409f00:	ret
	...

0000000000409f10 <__swc_fn_7dafa2b1_000162_edb9cf73>:
  409f10:	push   rbx
  409f11:	push   rsi
  409f12:	push   rdi
  409f13:	push   r12
  409f15:	push   r13
  409f17:	sub    rsp,0x50
  409f1b:	mov    rbx,rcx
  409f1e:	mov    rsi,rdx
  409f21:	vmovups xmm0,XMMWORD PTR [rip+0x88ff]        # 412828 <__swc_rdata_base_7dafa2b1+0x718>
  409f29:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  409f2f:	vmovups xmm0,XMMWORD PTR [rip+0x8901]        # 412838 <__swc_rdata_base_7dafa2b1+0x728>
  409f37:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  409f3d:	vxorps xmm0,xmm0,xmm0
  409f41:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  409f47:	mov    rcx,rdx
  409f4a:	call   4098b0 <__swc_fn_7dafa2b1_000138_2214b637>
  409f4f:	mov    rdi,rax
  409f52:	test   rax,rax
  409f55:	jne    409f86 <__swc_fn_7dafa2b1_000162_edb9cf73+0x76>
  409f57:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409f5d:	vmovups XMMWORD PTR [rbx],xmm0
  409f61:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409f67:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409f6c:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409f72:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409f77:	mov    rax,rbx
  409f7a:	add    rsp,0x50
  409f7e:	pop    r13
  409f80:	pop    r12
  409f82:	pop    rdi
  409f83:	pop    rsi
  409f84:	pop    rbx
  409f85:	ret
  409f86:	mov    rcx,rdi
  409f89:	call   4115a0 <__swc_fn_7dafa2b1_000161_9e36e814>
  409f8e:	mov    r11,rax
  409f91:	test   rax,rax
  409f94:	je     409f9e <__swc_fn_7dafa2b1_000162_edb9cf73+0x8e>
  409f96:	mov    al,BYTE PTR [r11+0x24]
  409f9a:	test   al,al
  409f9c:	jne    409fcd <__swc_fn_7dafa2b1_000162_edb9cf73+0xbd>
  409f9e:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fa4:	vmovups XMMWORD PTR [rbx],xmm0
  409fa8:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fae:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fb3:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409fb9:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409fbe:	mov    rax,rbx
  409fc1:	add    rsp,0x50
  409fc5:	pop    r13
  409fc7:	pop    r12
  409fc9:	pop    rdi
  409fca:	pop    rsi
  409fcb:	pop    rbx
  409fcc:	ret
  409fcd:	sub    rsi,rdi
  409fd0:	mov    eax,0xffffffff
  409fd5:	cmp    rsi,rax
  409fd8:	jbe    40a009 <__swc_fn_7dafa2b1_000162_edb9cf73+0xf9>
  409fda:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  409fe0:	vmovups XMMWORD PTR [rbx],xmm0
  409fe4:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  409fea:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  409fef:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  409ff5:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  409ffa:	mov    rax,rbx
  409ffd:	add    rsp,0x50
  40a001:	pop    r13
  40a003:	pop    r12
  40a005:	pop    rdi
  40a006:	pop    rsi
  40a007:	pop    rbx
  40a008:	ret
  40a009:	mov    rdi,QWORD PTR [r11+0x10]
  40a00d:	mov    eax,DWORD PTR [r11+0x20]
  40a011:	xor    ecx,ecx
  40a013:	test   rax,rax
  40a016:	jbe    40a168 <__swc_fn_7dafa2b1_000162_edb9cf73+0x258>
  40a01c:	nop    DWORD PTR [rax+0x0]
  40a020:	mov    edx,ecx
  40a022:	imul   r12,rdx,0x14
  40a026:	mov    edx,DWORD PTR [rdi+r12*1+0x10]
  40a02b:	mov    r8d,DWORD PTR [rdi+r12*1+0x14]
  40a030:	mov    r9d,esi
  40a033:	cmp    r9,rdx
  40a036:	jb     40a15b <__swc_fn_7dafa2b1_000162_edb9cf73+0x24b>
  40a03c:	add    rdx,r8
  40a03f:	mov    r8d,esi
  40a042:	cmp    r8,rdx
  40a045:	jae    40a15b <__swc_fn_7dafa2b1_000162_edb9cf73+0x24b>
  40a04b:	lea    rsi,[rsp+0x38]
  40a050:	mov    eax,DWORD PTR [rdi+0xc]
  40a053:	mov    DWORD PTR [rsp+0x38],eax
  40a057:	mov    eax,DWORD PTR [rdi+r12*1+0x18]
  40a05c:	mov    rcx,rdi
  40a05f:	mov    rdx,QWORD PTR [r11+0x18]
  40a063:	mov    r8,rsi
  40a066:	mov    r8d,DWORD PTR [r8]
  40a069:	mov    r9,rax
  40a06c:	lea    r10,[rsp+0x10]
  40a071:	call   40d180 <__swc_fn_7dafa2b1_000160_e25d06b9>
  40a076:	test   al,al
  40a078:	jne    40a0ab <__swc_fn_7dafa2b1_000162_edb9cf73+0x19b>
  40a07a:	vmovups xmm0,XMMWORD PTR [rip+0x87d6]        # 412858 <__swc_rdata_base_7dafa2b1+0x748>
  40a082:	vmovups XMMWORD PTR [rbx],xmm0
  40a086:	vmovups xmm0,XMMWORD PTR [rip+0x87da]        # 412868 <__swc_rdata_base_7dafa2b1+0x758>
  40a08e:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a093:	vxorps xmm0,xmm0,xmm0
  40a097:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a09c:	mov    rax,rbx
  40a09f:	add    rsp,0x50
  40a0a3:	pop    r13
  40a0a5:	pop    r12
  40a0a7:	pop    rdi
  40a0a8:	pop    rsi
  40a0a9:	pop    rbx
  40a0aa:	ret
  40a0ab:	lea    r13,[rsp+0x3c]
  40a0b0:	mov    eax,DWORD PTR [rdi+r12*1+0x1c]
  40a0b5:	mov    DWORD PTR [rsp+0x3c],eax
  40a0b9:	test   eax,eax
  40a0bb:	je     40a10c <__swc_fn_7dafa2b1_000162_edb9cf73+0x1fc>
  40a0bd:	mov    rcx,rdi
  40a0c0:	mov    rdx,QWORD PTR [r11+0x18]
  40a0c4:	mov    r8d,DWORD PTR [rsi]
  40a0c7:	mov    rax,r13
  40a0ca:	mov    r9d,DWORD PTR [rax]
  40a0cd:	lea    r10,[rsp+0x20]
  40a0d2:	call   40d180 <__swc_fn_7dafa2b1_000160_e25d06b9>
  40a0d7:	test   al,al
  40a0d9:	jne    40a10c <__swc_fn_7dafa2b1_000162_edb9cf73+0x1fc>
  40a0db:	vmovups xmm0,XMMWORD PTR [rip+0x87a5]        # 412888 <__swc_rdata_base_7dafa2b1+0x778>
  40a0e3:	vmovups XMMWORD PTR [rbx],xmm0
  40a0e7:	vmovups xmm0,XMMWORD PTR [rip+0x87a9]        # 412898 <__swc_rdata_base_7dafa2b1+0x788>
  40a0ef:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a0f4:	vxorps xmm0,xmm0,xmm0
  40a0f8:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a0fd:	mov    rax,rbx
  40a100:	add    rsp,0x50
  40a104:	pop    r13
  40a106:	pop    r12
  40a108:	pop    rdi
  40a109:	pop    rsi
  40a10a:	pop    rbx
  40a10b:	ret
  40a10c:	mov    eax,0x1
  40a111:	rex mov BYTE PTR [rsp+0x8],al
  40a116:	cmp    DWORD PTR [r13+0x0],0x0
  40a11b:	je     40a12c <__swc_fn_7dafa2b1_000162_edb9cf73+0x21c>
  40a11d:	rex mov BYTE PTR [rsp+0x9],0x1
  40a123:	mov    eax,DWORD PTR [rdi+r12*1+0x20]
  40a128:	mov    DWORD PTR [rsp+0x30],eax
  40a12c:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a132:	vmovups XMMWORD PTR [rbx],xmm0
  40a136:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a13c:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a141:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a147:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a14c:	mov    rax,rbx
  40a14f:	add    rsp,0x50
  40a153:	pop    r13
  40a155:	pop    r12
  40a157:	pop    rdi
  40a158:	pop    rsi
  40a159:	pop    rbx
  40a15a:	ret
  40a15b:	add    rcx,0x1
  40a15f:	cmp    rcx,rax
  40a162:	jb     40a020 <__swc_fn_7dafa2b1_000162_edb9cf73+0x110>
  40a168:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40a16e:	vmovups XMMWORD PTR [rbx],xmm0
  40a172:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40a178:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40a17d:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  40a183:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40a188:	mov    rax,rbx
  40a18b:	add    rsp,0x50
  40a18f:	pop    r13
  40a191:	pop    r12
  40a193:	pop    rdi
  40a194:	pop    rsi
  40a195:	pop    rbx
  40a196:	ret
	...

000000000040a1a0 <__swc_fn_7dafa2b1_000165_e09accff>:
  40a1a0:	sub    rsp,0x48
  40a1a4:	call   409580 <__swc_fn_7dafa2b1_000123_e9227a3e>
  40a1a9:	cmp    rax,0xffffffffffffffff
  40a1ad:	je     40a1b4 <__swc_fn_7dafa2b1_000165_e09accff+0x14>
  40a1af:	add    rsp,0x48
  40a1b3:	ret
  40a1b4:	lea    rcx,[rip+0x870d]        # 4128c8 <__swc_rdata_base_7dafa2b1+0x7b8>
  40a1bb:	vmovups xmm0,XMMWORD PTR [rip+0x8715]        # 4128d8 <__swc_rdata_base_7dafa2b1+0x7c8>
  40a1c3:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40a1c9:	vmovups xmm0,XMMWORD PTR [rip+0x8717]        # 4128e8 <__swc_rdata_base_7dafa2b1+0x7d8>
  40a1d1:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40a1d7:	vmovups xmm0,XMMWORD PTR [rip+0x8719]        # 4128f8 <__swc_rdata_base_7dafa2b1+0x7e8>
  40a1df:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40a1e5:	lea    rdx,[rsp+0x8]
  40a1ea:	mov    QWORD PTR [rsp+0x38],rax
  40a1ef:	call   40c360 <__swc_fn_7dafa2b1_000103_2ed36338>
  40a1f4:	mov    rax,QWORD PTR [rsp+0x38]
  40a1f9:	jmp    40a1af <__swc_fn_7dafa2b1_000165_e09accff+0xf>
  40a1fb:	add    BYTE PTR [rax],al
  40a1fd:	add    BYTE PTR [rax],al
	...

000000000040a200 <__swc_fn_7dafa2b1_000168_0ff0458f>:
  40a200:	push   rbx
  40a201:	push   rsi
  40a202:	sub    rsp,0x28
  40a206:	mov    rbx,rcx
  40a209:	mov    DWORD PTR [rsp+0x8],0xbf0
  40a211:	mov    ecx,0xbf0
  40a216:	call   40bf50 <__swc_fn_7dafa2b1_000079_29fad089>
  40a21b:	mov    rsi,rax
  40a21e:	test   rax,rax
  40a221:	jne    40a22c <__swc_fn_7dafa2b1_000168_0ff0458f+0x2c>
  40a223:	xor    eax,eax
  40a225:	add    rsp,0x28
  40a229:	pop    rsi
  40a22a:	pop    rbx
  40a22b:	ret
  40a22c:	vxorps xmm0,xmm0,xmm0
  40a230:	xor    eax,eax
  40a232:	cs nop WORD PTR [rax+rax*1+0x0]
  40a23c:	nop    DWORD PTR [rax+0x0]
  40a240:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40a245:	add    rax,0x10
  40a249:	cmp    rax,0xbf0
  40a250:	jne    40a240 <__swc_fn_7dafa2b1_000168_0ff0458f+0x40>
  40a252:	lea    rax,[rbx+0x1]
  40a256:	mov    QWORD PTR [rsi+0x9c0],rax
  40a25d:	mov    rcx,rbx
  40a260:	mov    rdx,rsi
  40a263:	call   40d4e0 <__swc_fn_7dafa2b1_000166_31ca4f53>
  40a268:	test   al,al
  40a26a:	jne    40a27d <__swc_fn_7dafa2b1_000168_0ff0458f+0x7d>
  40a26c:	mov    rcx,rsi
  40a26f:	call   40ea70 <__swc_fn_7dafa2b1_000080_851c599a>
  40a274:	xor    eax,eax
  40a276:	add    rsp,0x28
  40a27a:	pop    rsi
  40a27b:	pop    rbx
  40a27c:	ret
  40a27d:	lea    rcx,[rsp+0x18]
  40a282:	call   40eff0 <__swc_fn_7dafa2b1_000092_17e20532>
  40a287:	mov    rax,rsi
  40a28a:	add    rsp,0x28
  40a28e:	pop    rsi
  40a28f:	pop    rbx
  40a290:	ret
	...

000000000040a2a0 <__swc_fn_7dafa2b1_000171_06b64c88>:
  40a2a0:	xor    eax,eax
  40a2a2:	mov    edx,0x1
  40a2a7:	lock cmpxchg QWORD PTR [rcx],rdx
  40a2ac:	test   rax,rax
  40a2af:	jne    40a2b2 <__swc_fn_7dafa2b1_000171_06b64c88+0x12>
  40a2b1:	ret
  40a2b2:	cs nop WORD PTR [rax+rax*1+0x0]
  40a2bc:	nop    DWORD PTR [rax+0x0]
  40a2c0:	mov    rax,QWORD PTR [rcx]
  40a2c3:	test   rax,rax
  40a2c6:	je     40a2a0 <__swc_fn_7dafa2b1_000171_06b64c88>
  40a2c8:	jmp    40a2c0 <__swc_fn_7dafa2b1_000171_06b64c88+0x20>
  40a2ca:	add    BYTE PTR [rax],al
  40a2cc:	add    BYTE PTR [rax],al
	...

000000000040a2d0 <__swc_fn_7dafa2b1_000174_738eec22>:
  40a2d0:	push   rsi
  40a2d1:	push   rdi
  40a2d2:	sub    rsp,0x38
  40a2d6:	mov    rsi,rcx
  40a2d9:	call   40d4f0 <__swc_fn_7dafa2b1_000169_aabbfb4c>
  40a2de:	mov    rdi,rax
  40a2e1:	call   40cc80 <__swc_fn_7dafa2b1_000130_d2d78689>
  40a2e6:	mov    r8,rax
  40a2e9:	mov    rcx,rdi
  40a2ec:	call   40a2a0 <__swc_fn_7dafa2b1_000171_06b64c88>
  40a2f1:	mov    rax,QWORD PTR [rdi+0x8]
  40a2f5:	test   rax,rax
  40a2f8:	je     40a335 <__swc_fn_7dafa2b1_000174_738eec22+0x65>
  40a2fa:	nop    WORD PTR [rax+rax*1+0x0]
  40a300:	cmp    rax,rsi
  40a303:	je     40a335 <__swc_fn_7dafa2b1_000174_738eec22+0x65>
  40a305:	mov    r9,QWORD PTR [rax]
  40a308:	cmp    QWORD PTR [rax+0x20],r8
  40a30c:	jne    40a32d <__swc_fn_7dafa2b1_000174_738eec22+0x5d>
  40a30e:	mov    rcx,rdi
  40a311:	mov    rdx,rax
  40a314:	mov    QWORD PTR [rsp+0x28],r8
  40a319:	mov    QWORD PTR [rsp+0x30],r9
  40a31e:	call   4119c0 <__swc_fn_7dafa2b1_000173_156cb9fe>
  40a323:	mov    r8,QWORD PTR [rsp+0x28]
  40a328:	mov    r9,QWORD PTR [rsp+0x30]
  40a32d:	mov    rax,r9
  40a330:	test   r9,r9
  40a333:	jne    40a300 <__swc_fn_7dafa2b1_000174_738eec22+0x30>
  40a335:	xor    eax,eax
  40a337:	mov    QWORD PTR [rdi],rax
  40a33a:	add    rsp,0x38
  40a33e:	pop    rdi
  40a33f:	pop    rsi
  40a340:	ret
	...

000000000040a350 <__swc_fn_7dafa2b1_000177_6e6aee58>:
  40a350:	push   rbx
  40a351:	sub    rsp,0x80
  40a358:	mov    rax,rcx
  40a35b:	mov    rcx,QWORD PTR [rax]
  40a35e:	test   rcx,rcx
  40a361:	je     40a380 <__swc_fn_7dafa2b1_000177_6e6aee58+0x30>
  40a363:	mov    QWORD PTR [rsp+0x68],rax
  40a368:	call   40a350 <__swc_fn_7dafa2b1_000177_6e6aee58>
  40a36d:	mov    rax,QWORD PTR [rsp+0x68]
  40a372:	mov    rcx,QWORD PTR [rax+0x8]
  40a376:	call   40a350 <__swc_fn_7dafa2b1_000177_6e6aee58>
  40a37b:	mov    rax,QWORD PTR [rsp+0x68]
  40a380:	test   rax,rax
  40a383:	je     40a3e6 <__swc_fn_7dafa2b1_000177_6e6aee58+0x96>
  40a385:	vxorps xmm0,xmm0,xmm0
  40a389:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40a38f:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40a395:	vzeroupper
  40a398:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40a39e:	lea    rcx,[rax-0x10]
  40a3a2:	mov    QWORD PTR [rsp+0x48],rcx
  40a3a7:	mov    rax,QWORD PTR [rax-0x10]
  40a3ab:	mov    QWORD PTR [rsp+0x50],rax
  40a3b0:	mov    rcx,QWORD PTR [rip+0x1b989]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40a3b7:	test   rcx,rcx
  40a3ba:	jne    40a3cc <__swc_fn_7dafa2b1_000177_6e6aee58+0x7c>
  40a3bc:	call   40a1a0 <__swc_fn_7dafa2b1_000165_e09accff>
  40a3c1:	lea    rcx,[rax+0x1]
  40a3c5:	mov    QWORD PTR [rip+0x1b974],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40a3cc:	dec    rcx
  40a3cf:	call   4118a0 <__swc_fn_7dafa2b1_000167_3130645d>
  40a3d4:	mov    rcx,QWORD PTR [rax]
  40a3d7:	lea    rdx,[rsp+0x8]
  40a3dc:	mov    rbx,QWORD PTR [rax+0x8]
  40a3e0:	mov    rbx,QWORD PTR [rbx+0x18]
  40a3e4:	call   rbx
  40a3e6:	add    rsp,0x80
  40a3ed:	pop    rbx
  40a3ee:	ret
	...

000000000040a400 <__swc_fn_7dafa2b1_000001_29b04951>:
  40a400:	vxorps xmm0,xmm0,xmm0
  40a404:	xor    eax,eax
  40a406:	cs nop WORD PTR [rax+rax*1+0x0]
  40a410:	cs nop WORD PTR [rax+rax*1+0x0]
  40a41a:	nop    WORD PTR [rax+rax*1+0x0]
  40a420:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a425:	add    rax,0x10
  40a429:	cmp    rax,0x2080
  40a430:	jne    40a420 <__swc_fn_7dafa2b1_000001_29b04951+0x20>
  40a432:	ret
	...

000000000040a440 <__swc_fn_7dafa2b1_000004_2fa5c690>:
  40a440:	push   rsi
  40a441:	push   rdi
  40a442:	push   r12
  40a444:	push   r13
  40a446:	push   r14
  40a448:	mov    rsi,rcx
  40a44b:	mov    edi,r10d
  40a44e:	mov    r12,rcx
  40a451:	mov    r13,r9
  40a454:	mov    ecx,DWORD PTR [rdx+0x28]
  40a457:	shlx   r14d,r8d,ecx
  40a45c:	mov    rcx,rdx
  40a45f:	mov    edx,r8d
  40a462:	call   40d940 <__swc_fn_7dafa2b1_000011_e75d466d>
  40a467:	mov    rcx,rax
  40a46a:	mov    eax,DWORD PTR [r12+0x3c]
  40a46f:	xor    edx,edx
  40a471:	div    rdi
  40a474:	vxorps xmm0,xmm0,xmm0
  40a478:	vmovdqu XMMWORD PTR [rsi],xmm0
  40a47c:	mov    QWORD PTR [r12+0x60],0x0
  40a485:	vmovdqu XMMWORD PTR [rsi+0x50],xmm0
  40a48a:	mov    QWORD PTR [r12+0x10],rcx
  40a48f:	imul   rax,rdi
  40a493:	lea    rdx,[rcx+rax*1]
  40a497:	mov    QWORD PTR [r12+0x18],rdx
  40a49c:	mov    QWORD PTR [r12+0x20],rcx
  40a4a1:	vmovdqu XMMWORD PTR [rsi+0x40],xmm0
  40a4a6:	mov    DWORD PTR [r12+0x28],0x0
  40a4af:	mov    DWORD PTR [r12+0x68],0x0
  40a4b8:	mov    BYTE PTR [r12+0x39],r13b
  40a4bd:	mov    BYTE PTR [r12+0x3a],r14b
  40a4c2:	mov    BYTE PTR [r12+0x3b],0x1
  40a4c8:	mov    DWORD PTR [r12+0x6c],0x0
  40a4d1:	mov    rcx,r12
  40a4d4:	mov    edx,edi
  40a4d6:	call   40d8a0 <__swc_fn_7dafa2b1_000005_bcc5b80b>
  40a4db:	pop    r14
  40a4dd:	pop    r13
  40a4df:	pop    r12
  40a4e1:	pop    rdi
  40a4e2:	pop    rsi
  40a4e3:	ret
	...

000000000040a4f0 <__swc_fn_7dafa2b1_000007_635028f3>:
  40a4f0:	mov    r8d,0x1
  40a4f6:	xor    eax,eax
  40a4f8:	lock cmpxchg DWORD PTR [rcx+0x68],r8d
  40a4fe:	test   eax,eax
  40a500:	jne    40a4f0 <__swc_fn_7dafa2b1_000007_635028f3>
  40a502:	ret
	...

000000000040a510 <__swc_fn_7dafa2b1_000010_186cd0c2>:
  40a510:	lea    r8,[rcx+0x60]
  40a514:	mov    rax,QWORD PTR [r8]
  40a517:	mov    r9,rax
  40a51a:	nop    WORD PTR [rax+rax*1+0x0]
  40a520:	mov    QWORD PTR [rdx],r9
  40a523:	mov    rax,r9
  40a526:	lock cmpxchg QWORD PTR [r8],rdx
  40a52b:	cmp    rax,r9
  40a52e:	jne    40a597 <__swc_fn_7dafa2b1_000010_186cd0c2+0x87>
  40a530:	mov    eax,DWORD PTR [rcx+0x6c]
  40a533:	test   eax,eax
  40a535:	je     40a596 <__swc_fn_7dafa2b1_000010_186cd0c2+0x86>
  40a537:	lea    rdx,[rcx+0x70]
  40a53b:	mov    r9d,0x1
  40a541:	xor    eax,eax
  40a543:	lock cmpxchg DWORD PTR [rdx],r9d
  40a548:	test   eax,eax
  40a54a:	jne    40a596 <__swc_fn_7dafa2b1_000010_186cd0c2+0x86>
  40a54c:	mov    rax,rcx
  40a54f:	and    rax,0xffffffffffc00000
  40a556:	mov    rax,QWORD PTR [rax+0x8]
  40a55a:	test   rax,rax
  40a55d:	jne    40a565 <__swc_fn_7dafa2b1_000010_186cd0c2+0x55>
  40a55f:	xor    eax,eax
  40a561:	xchg   DWORD PTR [rdx],eax
  40a563:	jmp    40a596 <__swc_fn_7dafa2b1_000010_186cd0c2+0x86>
  40a565:	lea    rdx,[rax+0x2a80]
  40a56c:	mov    rax,QWORD PTR [rdx]
  40a56f:	mov    r8,rax
  40a572:	cs nop WORD PTR [rax+rax*1+0x0]
  40a57c:	nop    DWORD PTR [rax+0x0]
  40a580:	mov    QWORD PTR [rcx+0x78],r8
  40a584:	mov    rax,r8
  40a587:	lock cmpxchg QWORD PTR [rdx],rcx
  40a58c:	cmp    rax,r8
  40a58f:	je     40a596 <__swc_fn_7dafa2b1_000010_186cd0c2+0x86>
  40a591:	mov    r8,rax
  40a594:	jmp    40a580 <__swc_fn_7dafa2b1_000010_186cd0c2+0x70>
  40a596:	ret
  40a597:	mov    r9,rax
  40a59a:	jmp    40a520 <__swc_fn_7dafa2b1_000010_186cd0c2+0x10>
	...

000000000040a5a0 <__swc_fn_7dafa2b1_000013_d15d37c6>:
  40a5a0:	push   rsi
  40a5a1:	push   rdi
  40a5a2:	push   r12
  40a5a4:	push   r13
  40a5a6:	push   r14
  40a5a8:	push   r15
  40a5aa:	push   rbx
  40a5ab:	sub    rsp,0x30
  40a5af:	mov    QWORD PTR [rsp+0x18],r8
  40a5b4:	mov    rsi,rcx
  40a5b7:	mov    rdi,rdx
  40a5ba:	mov    rdx,QWORD PTR [rsi+0x40]
  40a5be:	xchg   ax,ax
  40a5c0:	mov    rax,rdx
  40a5c3:	not    rax
  40a5c6:	and    rax,QWORD PTR [rsi+0x20]
  40a5ca:	test   rax,rax
  40a5cd:	jne    40a5e1 <__swc_fn_7dafa2b1_000013_d15d37c6+0x41>
  40a5cf:	xor    eax,eax
  40a5d1:	add    rsp,0x30
  40a5d5:	pop    rbx
  40a5d6:	pop    r15
  40a5d8:	pop    r14
  40a5da:	pop    r13
  40a5dc:	pop    r12
  40a5de:	pop    rdi
  40a5df:	pop    rsi
  40a5e0:	ret
  40a5e1:	xor    ecx,ecx
  40a5e3:	tzcnt  rcx,rax
  40a5e8:	lea    r12,[rsp+0x8]
  40a5ed:	mov    DWORD PTR [rsp+0x8],ecx
  40a5f1:	mov    r13d,0x1
  40a5f7:	shl    r13,cl
  40a5fa:	mov    rcx,rdx
  40a5fd:	or     rcx,r13
  40a600:	mov    rax,rdx
  40a603:	lock cmpxchg QWORD PTR [rsi+0x40],rcx
  40a609:	cmp    rax,rdx
  40a60c:	je     40a613 <__swc_fn_7dafa2b1_000013_d15d37c6+0x73>
  40a60e:	mov    rdx,rax
  40a611:	jmp    40a5c0 <__swc_fn_7dafa2b1_000013_d15d37c6+0x20>
  40a613:	mov    eax,DWORD PTR [r12]
  40a617:	shl    rax,0x4
  40a61b:	lea    r14,[rsi+rax*8+0x80]
  40a623:	mov    rcx,rsi
  40a626:	mov    rax,r12
  40a629:	mov    edx,DWORD PTR [rax]
  40a62b:	call   40d940 <__swc_fn_7dafa2b1_000011_e75d466d>
  40a630:	mov    r15,rax
  40a633:	mov    rcx,rsi
  40a636:	mov    rdx,r13
  40a639:	call   40daa0 <__swc_fn_7dafa2b1_000017_e238d24c>
  40a63e:	test   al,al
  40a640:	je     40a678 <__swc_fn_7dafa2b1_000013_d15d37c6+0xd8>
  40a642:	mov    ecx,DWORD PTR [r14+0x3c]
  40a646:	lea    rdx,[rip+0x18a0b]        # 423058 <__swc_bss_base_7dafa2b1+0x18>
  40a64d:	mov    r8,QWORD PTR [rip+0x18a04]        # 423058 <__swc_bss_base_7dafa2b1+0x18>
  40a654:	cs nop WORD PTR [rax+rax*1+0x0]
  40a65e:	xchg   ax,ax
  40a660:	mov    r9,r8
  40a663:	sub    r9,rcx
  40a666:	mov    rax,r8
  40a669:	lock cmpxchg QWORD PTR [rdx],r9
  40a66e:	cmp    rax,r8
  40a671:	je     40a6d9 <__swc_fn_7dafa2b1_000013_d15d37c6+0x139>
  40a673:	mov    r8,rax
  40a676:	jmp    40a660 <__swc_fn_7dafa2b1_000013_d15d37c6+0xc0>
  40a678:	mov    rcx,rsi
  40a67b:	mov    rax,r12
  40a67e:	mov    edx,DWORD PTR [rax]
  40a680:	call   407450 <__swc_fn_7dafa2b1_000012_39679ef8>
  40a685:	mov    rcx,r15
  40a688:	and    rcx,0xffffffffffff0000
  40a68f:	lea    rcx,[rcx+0x10000]
  40a696:	mov    rbx,rax
  40a699:	cmp    rax,rcx
  40a69c:	cmova  rbx,rcx
  40a6a0:	mov    rax,rbx
  40a6a3:	sub    rax,r15
  40a6a6:	mov    rcx,r15
  40a6a9:	mov    rdx,rax
  40a6ac:	call   4072a0 <__swc_fn_7dafa2b1_000003_644dadb7>
  40a6b1:	test   al,al
  40a6b3:	jne    40a6d2 <__swc_fn_7dafa2b1_000013_d15d37c6+0x132>
  40a6b5:	mov    rcx,rsi
  40a6b8:	mov    rdx,r13
  40a6bb:	call   407600 <__swc_fn_7dafa2b1_000018_e2e8e4b0>
  40a6c0:	xor    eax,eax
  40a6c2:	add    rsp,0x30
  40a6c6:	pop    rbx
  40a6c7:	pop    r15
  40a6c9:	pop    r14
  40a6cb:	pop    r13
  40a6cd:	pop    r12
  40a6cf:	pop    rdi
  40a6d0:	pop    rsi
  40a6d1:	ret
  40a6d2:	sub    rbx,r15
  40a6d5:	mov    DWORD PTR [r14+0x3c],ebx
  40a6d9:	mov    rcx,r14
  40a6dc:	mov    rdx,rsi
  40a6df:	mov    r8d,DWORD PTR [r12]
  40a6e3:	mov    r9d,edi
  40a6e6:	mov    rbx,QWORD PTR [rsp+0x18]
  40a6eb:	mov    r10d,ebx
  40a6ee:	call   40a440 <__swc_fn_7dafa2b1_000004_2fa5c690>
  40a6f3:	mov    rax,r14
  40a6f6:	add    rsp,0x30
  40a6fa:	pop    rbx
  40a6fb:	pop    r15
  40a6fd:	pop    r14
  40a6ff:	pop    r13
  40a701:	pop    r12
  40a703:	pop    rdi
  40a704:	pop    rsi
  40a705:	ret
	...

000000000040a710 <__swc_fn_7dafa2b1_000016_89da4d6e>:
  40a710:	mov    r8,QWORD PTR [rcx+0x48]
  40a714:	cs nop WORD PTR [rax+rax*1+0x0]
  40a71e:	xchg   ax,ax
  40a720:	mov    r9,r8
  40a723:	or     r9,rdx
  40a726:	mov    rax,r8
  40a729:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40a72f:	cmp    rax,r8
  40a732:	jne    40a735 <__swc_fn_7dafa2b1_000016_89da4d6e+0x25>
  40a734:	ret
  40a735:	mov    r8,rax
  40a738:	jmp    40a720 <__swc_fn_7dafa2b1_000016_89da4d6e+0x10>
  40a73a:	add    BYTE PTR [rax],al
  40a73c:	add    BYTE PTR [rax],al
	...

000000000040a740 <__swc_fn_7dafa2b1_000019_60e50998>:
  40a740:	push   rsi
  40a741:	push   rdi
  40a742:	push   r12
  40a744:	mov    rsi,rcx
  40a747:	xor    edi,edi
  40a749:	lea    r12,[rip+0x18918]        # 423068 <__swc_bss_base_7dafa2b1+0x28>
  40a750:	mov    eax,DWORD PTR [r12]
  40a754:	xor    ecx,ecx
  40a756:	test   rax,rax
  40a759:	jbe    40a794 <__swc_fn_7dafa2b1_000019_60e50998+0x54>
  40a75b:	nop    DWORD PTR [rax+rax*1+0x0]
  40a760:	lea    rdx,[rip+0x18909]        # 423070 <__swc_bss_base_7dafa2b1+0x30>
  40a767:	mov    r8d,ecx
  40a76a:	lea    r8,[r8+r8*2]
  40a76e:	lea    r8,[rdx+r8*8]
  40a772:	mov    rdx,QWORD PTR [r8+0x10]
  40a776:	add    rdx,0x400000
  40a77d:	cmp    rdx,0x40000000
  40a784:	ja     40a78b <__swc_fn_7dafa2b1_000019_60e50998+0x4b>
  40a786:	mov    rdi,r8
  40a789:	jmp    40a794 <__swc_fn_7dafa2b1_000019_60e50998+0x54>
  40a78b:	add    rcx,0x1
  40a78f:	cmp    rcx,rax
  40a792:	jb     40a760 <__swc_fn_7dafa2b1_000019_60e50998+0x20>
  40a794:	test   rdi,rdi
  40a797:	jne    40a823 <__swc_fn_7dafa2b1_000019_60e50998+0xe3>
  40a79d:	cmp    DWORD PTR [r12],0x10
  40a7a2:	jae    40a80b <__swc_fn_7dafa2b1_000019_60e50998+0xcb>
  40a7a4:	mov    ecx,0x40400000
  40a7a9:	call   40d860 <__swc_fn_7dafa2b1_000002_390d5093>
  40a7ae:	test   rax,rax
  40a7b1:	je     40a80b <__swc_fn_7dafa2b1_000019_60e50998+0xcb>
  40a7b3:	lea    rcx,[rip+0x188b6]        # 423070 <__swc_bss_base_7dafa2b1+0x30>
  40a7ba:	mov    edx,DWORD PTR [r12]
  40a7be:	lea    rdx,[rdx+rdx*2]
  40a7c2:	lea    rdx,[rcx+rdx*8]
  40a7c6:	mov    QWORD PTR [rdx],rax
  40a7c9:	lea    rax,[rax+0x3fffff]
  40a7d0:	and    rax,0xffffffffffc00000
  40a7d7:	mov    QWORD PTR [rdx+0x8],rax
  40a7db:	mov    QWORD PTR [rdx+0x10],0x0
  40a7e3:	mov    edx,DWORD PTR [rip+0x1887f]        # 423068 <__swc_bss_base_7dafa2b1+0x28>
  40a7e9:	nop    DWORD PTR [rax+0x0]
  40a7f0:	lea    r9d,[rdx+0x1]
  40a7f4:	mov    rax,rdx
  40a7f7:	lock cmpxchg DWORD PTR [r12],r9d
  40a7fd:	mov    r8d,eax
  40a800:	cmp    eax,edx
  40a802:	je     40a812 <__swc_fn_7dafa2b1_000019_60e50998+0xd2>
  40a804:	mov    rdx,r8
  40a807:	jmp    40a7f0 <__swc_fn_7dafa2b1_000019_60e50998+0xb0>
  40a809:	jmp    40a812 <__swc_fn_7dafa2b1_000019_60e50998+0xd2>
  40a80b:	xor    eax,eax
  40a80d:	pop    r12
  40a80f:	pop    rdi
  40a810:	pop    rsi
  40a811:	ret
  40a812:	mov    eax,DWORD PTR [rip+0x18850]        # 423068 <__swc_bss_base_7dafa2b1+0x28>
  40a818:	sub    eax,0x1
  40a81b:	lea    rdi,[rax+rax*2]
  40a81f:	lea    rdi,[rcx+rdi*8]
  40a823:	mov    r12,QWORD PTR [rdi+0x8]
  40a827:	add    r12,QWORD PTR [rdi+0x10]
  40a82b:	mov    rcx,r12
  40a82e:	mov    edx,0x3000
  40a833:	call   4072a0 <__swc_fn_7dafa2b1_000003_644dadb7>
  40a838:	test   al,al
  40a83a:	jne    40a843 <__swc_fn_7dafa2b1_000019_60e50998+0x103>
  40a83c:	xor    eax,eax
  40a83e:	pop    r12
  40a840:	pop    rdi
  40a841:	pop    rsi
  40a842:	ret
  40a843:	vxorps xmm0,xmm0,xmm0
  40a847:	xor    eax,eax
  40a849:	cs nop WORD PTR [rax+rax*1+0x0]
  40a853:	cs nop WORD PTR [rax+rax*1+0x0]
  40a85d:	nop    DWORD PTR [rax]
  40a860:	vmovdqu XMMWORD PTR [r12+rax*1],xmm0
  40a866:	add    rax,0x10
  40a86a:	cmp    rax,0x3000
  40a871:	jne    40a860 <__swc_fn_7dafa2b1_000019_60e50998+0x120>
  40a873:	mov    DWORD PTR [r12+0x28],esi
  40a878:	mov    eax,0x40
  40a87d:	mov    ecx,esi
  40a87f:	shr    eax,cl
  40a881:	mov    DWORD PTR [r12+0x2c],eax
  40a886:	cmp    DWORD PTR [r12+0x2c],0x40
  40a88c:	jb     40a897 <__swc_fn_7dafa2b1_000019_60e50998+0x157>
  40a88e:	mov    rax,0xffffffffffffffff
  40a895:	jmp    40a8a7 <__swc_fn_7dafa2b1_000019_60e50998+0x167>
  40a897:	mov    eax,0x1
  40a89c:	mov    ecx,DWORD PTR [r12+0x2c]
  40a8a1:	shl    rax,cl
  40a8a4:	dec    rax
  40a8a7:	mov    QWORD PTR [r12+0x20],rax
  40a8ac:	mov    DWORD PTR [r12],0x4e540001
  40a8b4:	mov    DWORD PTR [r12+0x4],0x53474d45
  40a8bd:	add    QWORD PTR [rdi+0x10],0x400000
  40a8c5:	mov    rax,r12
  40a8c8:	pop    r12
  40a8ca:	pop    rdi
  40a8cb:	pop    rsi
  40a8cc:	ret
  40a8cd:	add    BYTE PTR [rax],al
	...

000000000040a8d0 <__swc_fn_7dafa2b1_000022_77c2d682>:
  40a8d0:	mov    eax,0x1
  40a8d5:	mov    edx,DWORD PTR [rip+0x1878d]        # 423068 <__swc_bss_base_7dafa2b1+0x28>
  40a8db:	cmp    eax,edx
  40a8dd:	jae    40a92b <__swc_fn_7dafa2b1_000022_77c2d682+0x5b>
  40a8df:	nop
  40a8e0:	lea    r8,[rip+0x18789]        # 423070 <__swc_bss_base_7dafa2b1+0x30>
  40a8e7:	lea    r9,[rax+rax*2]
  40a8eb:	lea    r9,[r8+r9*8]
  40a8ef:	mov    r8,rcx
  40a8f2:	sub    r8,QWORD PTR [r9+0x8]
  40a8f6:	mov    r9,QWORD PTR [r9+0x10]
  40a8fa:	cmp    r8,r9
  40a8fd:	jae    40a925 <__swc_fn_7dafa2b1_000022_77c2d682+0x55>
  40a8ff:	mov    rax,rcx
  40a902:	and    rax,0xffffffffffc00000
  40a909:	shr    rcx,0x10
  40a90d:	and    ecx,0x3f
  40a910:	mov    edx,DWORD PTR [rax+0x28]
  40a913:	shrx   ecx,ecx,edx
  40a918:	shl    rcx,0x4
  40a91c:	lea    rax,[rax+rcx*8+0x80]
  40a924:	ret
  40a925:	inc    eax
  40a927:	cmp    eax,edx
  40a929:	jb     40a8e0 <__swc_fn_7dafa2b1_000022_77c2d682+0x10>
  40a92b:	xor    eax,eax
  40a92d:	ret
	...

000000000040a930 <__swc_fn_7dafa2b1_000025_7e9350e1>:
  40a930:	vxorps xmm0,xmm0,xmm0
  40a934:	vmovups XMMWORD PTR [rcx],xmm0
  40a938:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40a93d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40a942:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40a947:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40a94c:	mov    QWORD PTR [rcx+0x50],0x0
  40a954:	ret
	...

000000000040a960 <__swc_fn_7dafa2b1_000028_7e9350e1>:
  40a960:	vxorps xmm0,xmm0,xmm0
  40a964:	xor    eax,eax
  40a966:	cs nop WORD PTR [rax+rax*1+0x0]
  40a970:	cs nop WORD PTR [rax+rax*1+0x0]
  40a97a:	nop    WORD PTR [rax+rax*1+0x0]
  40a980:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40a985:	add    rax,0x10
  40a989:	cmp    rax,0x9b0
  40a990:	jne    40a980 <__swc_fn_7dafa2b1_000028_7e9350e1+0x20>
  40a992:	mov    QWORD PTR [rcx+0x9b0],0x0
  40a99d:	ret
	...

000000000040a9a0 <__swc_fn_7dafa2b1_000031_ed8d61a9>:
  40a9a0:	push   rsi
  40a9a1:	push   rdi
  40a9a2:	sub    rsp,0x8
  40a9a6:	lea    rsi,[rip+0x1665b]        # 421008 <__swc_data_base_7dafa2b1+0x8>
  40a9ad:	mov    rax,QWORD PTR [rsi]
  40a9b0:	mov    ecx,0xffffffff
  40a9b5:	cmp    rax,rcx
  40a9b8:	je     40a9c1 <__swc_fn_7dafa2b1_000031_ed8d61a9+0x21>
  40a9ba:	add    rsp,0x8
  40a9be:	pop    rdi
  40a9bf:	pop    rsi
  40a9c0:	ret
  40a9c1:	mov    rcx,QWORD PTR [rip+0x76b0]        # 412078 <__swc_fn_7dafa2b1_000179_1ca87929+0x5f8>
  40a9c8:	call   409650 <__swc_fn_7dafa2b1_000126_5fb20c72>
  40a9cd:	mov    rcx,rax
  40a9d0:	mov    eax,0xffffffff
  40a9d5:	lock cmpxchg QWORD PTR [rsi],rcx
  40a9da:	mov    rdi,rax
  40a9dd:	mov    eax,0xffffffff
  40a9e2:	cmp    rdi,rax
  40a9e5:	je     40a9f6 <__swc_fn_7dafa2b1_000031_ed8d61a9+0x56>
  40a9e7:	call   40cbd0 <__swc_fn_7dafa2b1_000127_75f8ab5c>
  40a9ec:	mov    rax,rdi
  40a9ef:	add    rsp,0x8
  40a9f3:	pop    rdi
  40a9f4:	pop    rsi
  40a9f5:	ret
  40a9f6:	mov    rax,rcx
  40a9f9:	add    rsp,0x8
  40a9fd:	pop    rdi
  40a9fe:	pop    rsi
  40a9ff:	ret

000000000040aa00 <__swc_fn_7dafa2b1_000034_c72914a2>:
  40aa00:	sub    rsp,0x8
  40aa04:	vxorps xmm0,xmm0,xmm0
  40aa08:	xor    eax,eax
  40aa0a:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa14:	cs nop WORD PTR [rax+rax*1+0x0]
  40aa1e:	xchg   ax,ax
  40aa20:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40aa25:	add    rax,0x10
  40aa29:	cmp    rax,0x2b00
  40aa30:	jne    40aa20 <__swc_fn_7dafa2b1_000034_c72914a2+0x20>
  40aa32:	mov    DWORD PTR [rcx+0x2ac4],0xa110ca7e
  40aa3c:	xor    al,al
  40aa3e:	mov    rdx,rax
  40aa41:	xor    al,al
  40aa43:	mov    r8,rax
  40aa46:	xor    al,al
  40aa48:	mov    r9,rax
  40aa4b:	xor    al,al
  40aa4d:	mov    r10,rax
  40aa50:	xor    al,al
  40aa52:	mov    r11,rax
  40aa55:	call   40dcd0 <__swc_fn_7dafa2b1_000035_6105596e>
  40aa5a:	add    rsp,0x8
  40aa5e:	ret
	...

000000000040aa60 <__swc_fn_7dafa2b1_000037_92e867c2>:
  40aa60:	push   rsi
  40aa61:	push   rdi
  40aa62:	push   r12
  40aa64:	mov    rsi,r8
  40aa67:	mov    rdi,rdx
  40aa6a:	mov    rcx,rdx
  40aa6d:	call   40d860 <__swc_fn_7dafa2b1_000002_390d5093>
  40aa72:	mov    r12,rax
  40aa75:	test   rax,rax
  40aa78:	jne    40aa81 <__swc_fn_7dafa2b1_000037_92e867c2+0x21>
  40aa7a:	xor    eax,eax
  40aa7c:	pop    r12
  40aa7e:	pop    rdi
  40aa7f:	pop    rsi
  40aa80:	ret
  40aa81:	mov    rcx,r12
  40aa84:	mov    rdx,rsi
  40aa87:	call   4072a0 <__swc_fn_7dafa2b1_000003_644dadb7>
  40aa8c:	test   al,al
  40aa8e:	jne    40aaa2 <__swc_fn_7dafa2b1_000037_92e867c2+0x42>
  40aa90:	mov    rcx,r12
  40aa93:	mov    rdx,rdi
  40aa96:	call   40fad0 <__swc_fn_7dafa2b1_000113_25e345b1>
  40aa9b:	xor    eax,eax
  40aa9d:	pop    r12
  40aa9f:	pop    rdi
  40aaa0:	pop    rsi
  40aaa1:	ret
  40aaa2:	mov    rax,r12
  40aaa5:	pop    r12
  40aaa7:	pop    rdi
  40aaa8:	pop    rsi
  40aaa9:	ret
	...

000000000040aac0 <__swc_fn_7dafa2b1_000040_7a225310>:
  40aac0:	push   rsi
  40aac1:	push   rdi
  40aac2:	push   r12
  40aac4:	mov    rsi,rcx
  40aac7:	mov    edx,0x9b8
  40aacc:	call   40dd40 <__swc_fn_7dafa2b1_000038_c7591393>
  40aad1:	mov    rdi,rax
  40aad4:	test   rax,rax
  40aad7:	jne    40aae0 <__swc_fn_7dafa2b1_000040_7a225310+0x20>
  40aad9:	xor    eax,eax
  40aadb:	pop    r12
  40aadd:	pop    rdi
  40aade:	pop    rsi
  40aadf:	ret
  40aae0:	vxorps xmm0,xmm0,xmm0
  40aae4:	xor    eax,eax
  40aae6:	cs nop WORD PTR [rax+rax*1+0x0]
  40aaf0:	cs nop WORD PTR [rax+rax*1+0x0]
  40aafa:	nop    WORD PTR [rax+rax*1+0x0]
  40ab00:	vmovdqu XMMWORD PTR [rdi+rax*1],xmm0
  40ab05:	add    rax,0x10
  40ab09:	cmp    rax,0x9b0
  40ab10:	jne    40ab00 <__swc_fn_7dafa2b1_000040_7a225310+0x40>
  40ab12:	mov    QWORD PTR [rdi+0x9b0],0x0
  40ab1d:	mov    QWORD PTR [rdi],rsi
  40ab20:	call   40cc80 <__swc_fn_7dafa2b1_000130_d2d78689>
  40ab25:	mov    QWORD PTR [rdi+0x18],rax
  40ab29:	lea    r12,[rsi+0x10]
  40ab2d:	mov    rcx,r12
  40ab30:	call   4098a0 <__swc_fn_7dafa2b1_000135_1fec60ac>
  40ab35:	mov    rax,QWORD PTR [rsi+0x20]
  40ab39:	mov    QWORD PTR [rdi+0x8],rax
  40ab3d:	mov    rax,QWORD PTR [rsi+0x20]
  40ab41:	test   rax,rax
  40ab44:	je     40ab4a <__swc_fn_7dafa2b1_000040_7a225310+0x8a>
  40ab46:	mov    QWORD PTR [rax+0x10],rdi
  40ab4a:	mov    QWORD PTR [rsi+0x20],rdi
  40ab4e:	mov    rcx,r12
  40ab51:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  40ab56:	mov    rax,rdi
  40ab59:	pop    r12
  40ab5b:	pop    rdi
  40ab5c:	pop    rsi
  40ab5d:	ret
	...

000000000040ab60 <__swc_fn_7dafa2b1_000043_3755033a>:
  40ab60:	mov    rax,QWORD PTR [rdx+0x10]
  40ab64:	test   rax,rax
  40ab67:	je     40ab73 <__swc_fn_7dafa2b1_000043_3755033a+0x13>
  40ab69:	mov    rcx,QWORD PTR [rdx+0x8]
  40ab6d:	mov    QWORD PTR [rax+0x8],rcx
  40ab71:	jmp    40ab7b <__swc_fn_7dafa2b1_000043_3755033a+0x1b>
  40ab73:	mov    rax,QWORD PTR [rdx+0x8]
  40ab77:	mov    QWORD PTR [rcx+0x20],rax
  40ab7b:	mov    rax,QWORD PTR [rdx+0x8]
  40ab7f:	test   rax,rax
  40ab82:	je     40ab8c <__swc_fn_7dafa2b1_000043_3755033a+0x2c>
  40ab84:	mov    rcx,QWORD PTR [rdx+0x10]
  40ab88:	mov    QWORD PTR [rax+0x10],rcx
  40ab8c:	vxorps xmm0,xmm0,xmm0
  40ab90:	vmovdqu XMMWORD PTR [rdx+0x8],xmm0
  40ab95:	ret
	...

000000000040aba0 <__swc_fn_7dafa2b1_000046_49300800>:
  40aba0:	sub    rsp,0x8
  40aba4:	mov    r9,r8
  40aba7:	mov    r10,rdx
  40abaa:	call   40ddf0 <__swc_fn_7dafa2b1_000044_cac7f504>
  40abaf:	mov    eax,0x1
  40abb4:	xchg   DWORD PTR [r9+0x6c],eax
  40abb8:	mov    rax,QWORD PTR [r9+0x60]
  40abbc:	test   rax,rax
  40abbf:	je     40ac03 <__swc_fn_7dafa2b1_000046_49300800+0x63>
  40abc1:	xor    eax,eax
  40abc3:	xchg   DWORD PTR [r9+0x6c],eax
  40abc7:	movzx  eax,BYTE PTR [r9+0x39]
  40abcc:	lea    rax,[rax+rax*4]
  40abd0:	lea    rax,[r10+rax*8+0x28]
  40abd5:	mov    QWORD PTR [r9+0x50],0x0
  40abdd:	mov    rcx,QWORD PTR [rax+0x8]
  40abe1:	mov    QWORD PTR [r9+0x48],rcx
  40abe5:	mov    rcx,QWORD PTR [rax+0x8]
  40abe9:	test   rcx,rcx
  40abec:	je     40abf4 <__swc_fn_7dafa2b1_000046_49300800+0x54>
  40abee:	mov    QWORD PTR [rcx+0x50],r9
  40abf2:	jmp    40abf8 <__swc_fn_7dafa2b1_000046_49300800+0x58>
  40abf4:	mov    QWORD PTR [rax+0x10],r9
  40abf8:	mov    QWORD PTR [rax+0x8],r9
  40abfc:	xor    eax,eax
  40abfe:	add    rsp,0x8
  40ac02:	ret
  40ac03:	movzx  eax,BYTE PTR [r9+0x39]
  40ac08:	lea    rax,[rax+rax*4]
  40ac0c:	lea    rax,[r10+rax*8+0x28]
  40ac11:	mov    QWORD PTR [r9+0x50],0x0
  40ac19:	mov    rcx,QWORD PTR [rax+0x18]
  40ac1d:	mov    QWORD PTR [r9+0x48],rcx
  40ac21:	mov    rcx,QWORD PTR [rax+0x18]
  40ac25:	test   rcx,rcx
  40ac28:	je     40ac2e <__swc_fn_7dafa2b1_000046_49300800+0x8e>
  40ac2a:	mov    QWORD PTR [rcx+0x50],r9
  40ac2e:	mov    QWORD PTR [rax+0x18],r9
  40ac32:	mov    eax,0x1
  40ac37:	add    rsp,0x8
  40ac3b:	ret
  40ac3c:	add    BYTE PTR [rax],al
	...

000000000040ac40 <__swc_fn_7dafa2b1_000049_781177b4>:
  40ac40:	push   r12
  40ac42:	push   r13
  40ac44:	push   rdi
  40ac45:	push   rsi
  40ac46:	push   r14
  40ac48:	push   r15
  40ac4a:	sub    rsp,0x178
  40ac51:	vmovups XMMWORD PTR [rsp+0xd8],xmm6
  40ac5a:	vmovups XMMWORD PTR [rsp+0xe8],xmm7
  40ac63:	vmovups XMMWORD PTR [rsp+0xf8],xmm8
  40ac6c:	vmovups XMMWORD PTR [rsp+0x108],xmm9
  40ac75:	vmovups XMMWORD PTR [rsp+0x118],xmm10
  40ac7e:	vmovups XMMWORD PTR [rsp+0x128],xmm11
  40ac87:	vmovups XMMWORD PTR [rsp+0x138],xmm12
  40ac90:	vmovups XMMWORD PTR [rsp+0x148],xmm13
  40ac99:	vmovups XMMWORD PTR [rsp+0x158],xmm14
  40aca2:	vmovups XMMWORD PTR [rsp+0x168],xmm15
  40acab:	mov    r12,rcx
  40acae:	lea    rax,[rip+0x1854b]        # 423200 <__swc_bss_base_7dafa2b1+0x1c0>
  40acb5:	mov    rcx,QWORD PTR [rax]
  40acb8:	mov    r13,rcx
  40acbb:	test   rcx,rcx
  40acbe:	jne    40acce <__swc_fn_7dafa2b1_000049_781177b4+0x8e>
  40acc0:	mov    r13d,0x1dcd6500
  40acc6:	mov    ecx,0x1dcd6500
  40accb:	xchg   QWORD PTR [rax],rcx
  40acce:	lea    rax,[rip+0x1632b]        # 421000 <__swc_data_base_7dafa2b1>
  40acd5:	mov    rax,QWORD PTR [rax]
  40acd8:	cmp    rax,0xffffffffffffffff
  40acdc:	je     40aceb <__swc_fn_7dafa2b1_000049_781177b4+0xab>
  40acde:	mov    eax,eax
  40ace0:	mov    edi,eax
  40ace2:	xor    eax,eax
  40ace4:	call   407000 <pthread_getspecific@plt>
  40ace9:	jmp    40aced <__swc_fn_7dafa2b1_000049_781177b4+0xad>
  40aceb:	xor    eax,eax
  40aced:	test   rax,rax
  40acf0:	jne    40acff <__swc_fn_7dafa2b1_000049_781177b4+0xbf>
  40acf2:	call   40a9a0 <__swc_fn_7dafa2b1_000031_ed8d61a9>
  40acf7:	mov    rcx,rax
  40acfa:	call   40fe20 <__swc_fn_7dafa2b1_000128_9c45d2d7>
  40acff:	test   rax,rax
  40ad02:	je     40ad14 <__swc_fn_7dafa2b1_000049_781177b4+0xd4>
  40ad04:	cmp    QWORD PTR [rax],r12
  40ad07:	jne    40ad14 <__swc_fn_7dafa2b1_000049_781177b4+0xd4>
  40ad09:	cmp    DWORD PTR [rax+0x20],0x0
  40ad0d:	jne    40ad14 <__swc_fn_7dafa2b1_000049_781177b4+0xd4>
  40ad0f:	mov    rsi,rax
  40ad12:	jmp    40ad16 <__swc_fn_7dafa2b1_000049_781177b4+0xd6>
  40ad14:	xor    esi,esi
  40ad16:	lea    rdi,[r12+0x2a88]
  40ad1e:	mov    r14,QWORD PTR [rdi]
  40ad21:	test   r14,r14
  40ad24:	jne    40ad73 <__swc_fn_7dafa2b1_000049_781177b4+0x133>
  40ad26:	lea    rax,[rip+0x1832b]        # 423058 <__swc_bss_base_7dafa2b1+0x18>
  40ad2d:	mov    rax,QWORD PTR [rax]
  40ad30:	test   rax,rax
  40ad33:	setne  al
  40ad36:	jne    40ad5a <__swc_fn_7dafa2b1_000049_781177b4+0x11a>
  40ad38:	mov    rax,QWORD PTR [r12+0x2a70]
  40ad40:	test   rax,rax
  40ad43:	setne  al
  40ad46:	jne    40ad5a <__swc_fn_7dafa2b1_000049_781177b4+0x11a>
  40ad48:	test   rsi,rsi
  40ad4b:	setne  al
  40ad4e:	je     40ad5a <__swc_fn_7dafa2b1_000049_781177b4+0x11a>
  40ad50:	cmp    DWORD PTR [rsi+0x730],0x0
  40ad57:	setne  al
  40ad5a:	test   al,al
  40ad5c:	je     40ad6e <__swc_fn_7dafa2b1_000049_781177b4+0x12e>
  40ad5e:	call   40fed0 <__swc_fn_7dafa2b1_000131_dc04d759>
  40ad63:	lea    rcx,[rax+r13*1]
  40ad67:	xor    eax,eax
  40ad69:	lock cmpxchg QWORD PTR [rdi],rcx
  40ad6e:	jmp    40ae73 <__swc_fn_7dafa2b1_000049_781177b4+0x233>
  40ad73:	call   40fed0 <__swc_fn_7dafa2b1_000131_dc04d759>
  40ad78:	mov    r15,rax
  40ad7b:	cmp    rax,r14
  40ad7e:	jb     40ad8f <__swc_fn_7dafa2b1_000049_781177b4+0x14f>
  40ad80:	xor    ecx,ecx
  40ad82:	mov    rax,r14
  40ad85:	lock cmpxchg QWORD PTR [rdi],rcx
  40ad8a:	cmp    rax,r14
  40ad8d:	je     40ad94 <__swc_fn_7dafa2b1_000049_781177b4+0x154>
  40ad8f:	jmp    40ae73 <__swc_fn_7dafa2b1_000049_781177b4+0x233>
  40ad94:	test   rsi,rsi
  40ad97:	je     40adb2 <__swc_fn_7dafa2b1_000049_781177b4+0x172>
  40ad99:	cmp    r15,r13
  40ad9c:	jb     40adb2 <__swc_fn_7dafa2b1_000049_781177b4+0x172>
  40ad9e:	mov    rax,r15
  40ada1:	sub    rax,r13
  40ada4:	mov    rcx,r12
  40ada7:	mov    rdx,rsi
  40adaa:	mov    r8,rax
  40adad:	call   40e230 <__swc_fn_7dafa2b1_000059_c8e1ff6b>
  40adb2:	lea    rsi,[r12+0x10]
  40adb7:	mov    rcx,rsi
  40adba:	call   4098a0 <__swc_fn_7dafa2b1_000135_1fec60ac>
  40adbf:	mov    rax,QWORD PTR [r12+0x18]
  40adc4:	mov    rdi,rax
  40adc7:	test   rdi,rdi
  40adca:	je     40adf4 <__swc_fn_7dafa2b1_000049_781177b4+0x1b4>
  40adcc:	cs nop WORD PTR [rax+rax*1+0x0]
  40add6:	cs nop WORD PTR [rax+rax*1+0x0]
  40ade0:	mov    rcx,rdi
  40ade3:	call   407470 <__swc_fn_7dafa2b1_000015_aa8c841a>
  40ade8:	mov    rax,QWORD PTR [rdi+0x10]
  40adec:	mov    rdi,rax
  40adef:	test   rax,rax
  40adf2:	jne    40ade0 <__swc_fn_7dafa2b1_000049_781177b4+0x1a0>
  40adf4:	mov    rcx,rsi
  40adf7:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  40adfc:	mov    rcx,r12
  40adff:	call   4098a0 <__swc_fn_7dafa2b1_000135_1fec60ac>
  40ae04:	xor    esi,esi
  40ae06:	cs nop WORD PTR [rax+rax*1+0x0]
  40ae10:	mov    rax,QWORD PTR [r12+0x2a70]
  40ae18:	cmp    rsi,rax
  40ae1b:	jae    40ae6b <__swc_fn_7dafa2b1_000049_781177b4+0x22b>
  40ae1d:	lea    rax,[rsi+rsi*4]
  40ae21:	lea    rax,[r12+rax*8+0x268]
  40ae29:	mov    r8,QWORD PTR [rax]
  40ae2c:	mov    r9,QWORD PTR [rax+0x8]
  40ae30:	mov    r10,QWORD PTR [rax+0x10]
  40ae34:	mov    rax,QWORD PTR [rax+0x20]
  40ae38:	cmp    rax,r15
  40ae3b:	jae    40ae48 <__swc_fn_7dafa2b1_000049_781177b4+0x208>
  40ae3d:	mov    rcx,r15
  40ae40:	sub    rcx,rax
  40ae43:	cmp    rcx,r13
  40ae46:	jae    40ae4d <__swc_fn_7dafa2b1_000049_781177b4+0x20d>
  40ae48:	inc    rsi
  40ae4b:	jmp    40ae10 <__swc_fn_7dafa2b1_000049_781177b4+0x1d0>
  40ae4d:	mov    rcx,r12
  40ae50:	mov    rdx,rsi
  40ae53:	call   40e1e0 <__swc_fn_7dafa2b1_000056_cfedf3f4>
  40ae58:	mov    rcx,r12
  40ae5b:	mov    rdx,r8
  40ae5e:	mov    r8,r9
  40ae61:	mov    r9,r10
  40ae64:	call   407750 <__swc_fn_7dafa2b1_000039_05a50673>
  40ae69:	jmp    40ae10 <__swc_fn_7dafa2b1_000049_781177b4+0x1d0>
  40ae6b:	mov    rcx,r12
  40ae6e:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  40ae73:	vmovups xmm6,XMMWORD PTR [rsp+0xd8]
  40ae7c:	vmovups xmm7,XMMWORD PTR [rsp+0xe8]
  40ae85:	vmovups xmm8,XMMWORD PTR [rsp+0xf8]
  40ae8e:	vmovups xmm9,XMMWORD PTR [rsp+0x108]
  40ae97:	vmovups xmm10,XMMWORD PTR [rsp+0x118]
  40aea0:	vmovups xmm11,XMMWORD PTR [rsp+0x128]
  40aea9:	vmovups xmm12,XMMWORD PTR [rsp+0x138]
  40aeb2:	vmovups xmm13,XMMWORD PTR [rsp+0x148]
  40aebb:	vmovups xmm14,XMMWORD PTR [rsp+0x158]
  40aec4:	vmovups xmm15,XMMWORD PTR [rsp+0x168]
  40aecd:	add    rsp,0x178
  40aed4:	pop    r15
  40aed6:	pop    r14
  40aed8:	pop    rsi
  40aed9:	pop    rdi
  40aeda:	pop    r13
  40aedc:	pop    r12
  40aede:	ret
	...

000000000040aee0 <__swc_fn_7dafa2b1_000052_26c6c1c4>:
  40aee0:	lea    rax,[rdx-0x58]
  40aee4:	ret
	...

000000000040aef0 <__swc_fn_7dafa2b1_000055_da36318f>:
  40aef0:	push   rsi
  40aef1:	push   rdi
  40aef2:	push   r12
  40aef4:	push   r13
  40aef6:	sub    rsp,0x68
  40aefa:	vmovups XMMWORD PTR [rsp+0x58],xmm6
  40af00:	mov    rsi,r9
  40af03:	mov    rdi,rcx
  40af06:	mov    r12,rdx
  40af09:	mov    r13,r8
  40af0c:	cmp    QWORD PTR [rdi+0x2a70],0x0
  40af14:	jne    40af23 <__swc_fn_7dafa2b1_000055_da36318f+0x33>
  40af16:	xor    eax,eax
  40af18:	add    rsp,0x68
  40af1c:	pop    r13
  40af1e:	pop    r12
  40af20:	pop    rdi
  40af21:	pop    rsi
  40af22:	ret
  40af23:	mov    rcx,rdi
  40af26:	call   4098a0 <__swc_fn_7dafa2b1_000135_1fec60ac>
  40af2b:	movabs rax,0x7fffffffffffffff
  40af35:	cmp    r12,rax
  40af38:	mov    rax,0xffffffffffffffff
  40af3f:	lea    rcx,[r12+r12*1]
  40af43:	cmovbe rax,rcx
  40af47:	mov    rcx,QWORD PTR [rdi+0x2a70]
  40af4e:	mov    rdx,rcx
  40af51:	sub    rax,r12
  40af54:	inc    rax
  40af57:	xor    r8d,r8d
  40af5a:	test   rcx,rcx
  40af5d:	jbe    40af88 <__swc_fn_7dafa2b1_000055_da36318f+0x98>
  40af5f:	nop
  40af60:	lea    r9,[r8+r8*4]
  40af64:	mov    r9,QWORD PTR [rdi+r9*8+0x270]
  40af6c:	sub    r9,r12
  40af6f:	cmp    r9,rax
  40af72:	jae    40af7f <__swc_fn_7dafa2b1_000055_da36318f+0x8f>
  40af74:	mov    rdx,r8
  40af77:	mov    rax,r9
  40af7a:	test   r9,r9
  40af7d:	je     40af88 <__swc_fn_7dafa2b1_000055_da36318f+0x98>
  40af7f:	add    r8,0x1
  40af83:	cmp    r8,rcx
  40af86:	jb     40af60 <__swc_fn_7dafa2b1_000055_da36318f+0x70>
  40af88:	mov    rax,QWORD PTR [rdi+0x2a70]
  40af8f:	cmp    rdx,rax
  40af92:	jne    40afaf <__swc_fn_7dafa2b1_000055_da36318f+0xbf>
  40af94:	mov    rcx,rdi
  40af97:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  40af9c:	xor    eax,eax
  40af9e:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40afa4:	add    rsp,0x68
  40afa8:	pop    r13
  40afaa:	pop    r12
  40afac:	pop    rdi
  40afad:	pop    rsi
  40afae:	ret
  40afaf:	lea    rax,[rdx+rdx*4]
  40afb3:	lea    rax,[rdi+rax*8+0x268]
  40afbb:	vmovups xmm6,XMMWORD PTR [rax]
  40afbf:	mov    r8,QWORD PTR [rax+0x10]
  40afc3:	mov    rcx,rdi
  40afc6:	call   40e1e0 <__swc_fn_7dafa2b1_000056_cfedf3f4>
  40afcb:	vpshufd xmm0,xmm6,0xee
  40afd0:	vmovsd QWORD PTR [r13+0x0],xmm0
  40afd6:	mov    QWORD PTR [rsi],r8
  40afd9:	mov    rcx,rdi
  40afdc:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  40afe1:	vmovq  rax,xmm6
  40afe6:	vmovups xmm6,XMMWORD PTR [rsp+0x58]
  40afec:	add    rsp,0x68
  40aff0:	pop    r13
  40aff2:	pop    r12
  40aff4:	pop    rdi
  40aff5:	pop    rsi
  40aff6:	ret
	...

000000000040b000 <__swc_fn_7dafa2b1_000058_033ce1da>:
  40b000:	push   r12
  40b002:	push   r13
  40b004:	push   r14
  40b006:	push   r15
  40b008:	push   rdi
  40b009:	push   rsi
  40b00a:	sub    rsp,0x148
  40b011:	vmovups XMMWORD PTR [rsp+0xa8],xmm6
  40b01a:	vmovups XMMWORD PTR [rsp+0xb8],xmm7
  40b023:	vmovups XMMWORD PTR [rsp+0xc8],xmm8
  40b02c:	vmovups XMMWORD PTR [rsp+0xd8],xmm9
  40b035:	vmovups XMMWORD PTR [rsp+0xe8],xmm10
  40b03e:	vmovups XMMWORD PTR [rsp+0xf8],xmm11
  40b047:	vmovups XMMWORD PTR [rsp+0x108],xmm12
  40b050:	vmovups XMMWORD PTR [rsp+0x118],xmm13
  40b059:	vmovups XMMWORD PTR [rsp+0x128],xmm14
  40b062:	vmovups XMMWORD PTR [rsp+0x138],xmm15
  40b06b:	mov    r12,r9
  40b06e:	mov    r13,rcx
  40b071:	mov    r14,rdx
  40b074:	mov    r15,r8
  40b077:	test   rdx,rdx
  40b07a:	jne    40b08e <__swc_fn_7dafa2b1_000058_033ce1da+0x8e>
  40b07c:	add    rsp,0x148
  40b083:	pop    rsi
  40b084:	pop    rdi
  40b085:	pop    r15
  40b087:	pop    r14
  40b089:	pop    r13
  40b08b:	pop    r12
  40b08d:	ret
  40b08e:	cmp    r12,0x200000
  40b095:	ja     40b127 <__swc_fn_7dafa2b1_000058_033ce1da+0x127>
  40b09b:	lea    rax,[rip+0x15f5e]        # 421000 <__swc_data_base_7dafa2b1>
  40b0a2:	mov    rax,QWORD PTR [rax]
  40b0a5:	cmp    rax,0xffffffffffffffff
  40b0a9:	je     40b0b8 <__swc_fn_7dafa2b1_000058_033ce1da+0xb8>
  40b0ab:	mov    eax,eax
  40b0ad:	mov    edi,eax
  40b0af:	xor    eax,eax
  40b0b1:	call   407000 <pthread_getspecific@plt>
  40b0b6:	jmp    40b0ba <__swc_fn_7dafa2b1_000058_033ce1da+0xba>
  40b0b8:	xor    eax,eax
  40b0ba:	test   rax,rax
  40b0bd:	je     40b0c4 <__swc_fn_7dafa2b1_000058_033ce1da+0xc4>
  40b0bf:	mov    rsi,rax
  40b0c2:	jmp    40b0d4 <__swc_fn_7dafa2b1_000058_033ce1da+0xd4>
  40b0c4:	call   40a9a0 <__swc_fn_7dafa2b1_000031_ed8d61a9>
  40b0c9:	mov    rcx,rax
  40b0cc:	call   40fe20 <__swc_fn_7dafa2b1_000128_9c45d2d7>
  40b0d1:	mov    rsi,rax
  40b0d4:	test   rsi,rsi
  40b0d7:	je     40b127 <__swc_fn_7dafa2b1_000058_033ce1da+0x127>
  40b0d9:	cmp    QWORD PTR [rsi],r13
  40b0dc:	jne    40b127 <__swc_fn_7dafa2b1_000058_033ce1da+0x127>
  40b0de:	cmp    DWORD PTR [rsi+0x20],0x0
  40b0e2:	jne    40b127 <__swc_fn_7dafa2b1_000058_033ce1da+0x127>
  40b0e4:	cmp    DWORD PTR [rsi+0x730],0x10
  40b0eb:	jae    40b127 <__swc_fn_7dafa2b1_000058_033ce1da+0x127>
  40b0ed:	mov    eax,DWORD PTR [rsi+0x730]
  40b0f3:	lea    rdi,[rax+rax*4]
  40b0f7:	lea    rdi,[rsi+rdi*8+0x738]
  40b0ff:	mov    QWORD PTR [rdi],r14
  40b102:	mov    QWORD PTR [rdi+0x8],r15
  40b106:	mov    QWORD PTR [rdi+0x10],r12
  40b10a:	mov    QWORD PTR [rdi+0x18],0x0
  40b112:	call   40fed0 <__swc_fn_7dafa2b1_000131_dc04d759>
  40b117:	mov    QWORD PTR [rdi+0x20],rax
  40b11b:	add    DWORD PTR [rsi+0x730],0x1
  40b122:	jmp    40b286 <__swc_fn_7dafa2b1_000058_033ce1da+0x286>
  40b127:	mov    rcx,r13
  40b12a:	call   407e90 <__swc_fn_7dafa2b1_000057_8be0372b>
  40b12f:	mov    rsi,rax
  40b132:	cmp    r12,rax
  40b135:	jbe    40b16a <__swc_fn_7dafa2b1_000058_033ce1da+0x16a>
  40b137:	cmp    r12,0x10000000
  40b13e:	seta   al
  40b141:	ja     40b150 <__swc_fn_7dafa2b1_000058_033ce1da+0x150>
  40b143:	mov    rax,QWORD PTR [r13+0x2a70]
  40b14a:	test   rax,rax
  40b14d:	setne  al
  40b150:	test   al,al
  40b152:	je     40b16a <__swc_fn_7dafa2b1_000058_033ce1da+0x16a>
  40b154:	mov    rcx,r13
  40b157:	mov    rdx,r14
  40b15a:	mov    r8,r15
  40b15d:	mov    r9,r12
  40b160:	call   407750 <__swc_fn_7dafa2b1_000039_05a50673>
  40b165:	jmp    40b286 <__swc_fn_7dafa2b1_000058_033ce1da+0x286>
  40b16a:	call   40fed0 <__swc_fn_7dafa2b1_000131_dc04d759>
  40b16f:	mov    rdi,rax
  40b172:	mov    rcx,r13
  40b175:	call   4098a0 <__swc_fn_7dafa2b1_000135_1fec60ac>
  40b17a:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b182:	je     40b23a <__swc_fn_7dafa2b1_000058_033ce1da+0x23a>
  40b188:	nop    DWORD PTR [rax+rax*1+0x0]
  40b190:	cmp    QWORD PTR [r13+0x2a70],0x100
  40b19b:	jae    40b1b0 <__swc_fn_7dafa2b1_000058_033ce1da+0x1b0>
  40b19d:	mov    rax,QWORD PTR [r13+0x2a68]
  40b1a4:	add    rax,r12
  40b1a7:	cmp    rax,rsi
  40b1aa:	jbe    40b23a <__swc_fn_7dafa2b1_000058_033ce1da+0x23a>
  40b1b0:	xor    eax,eax
  40b1b2:	mov    rcx,QWORD PTR [r13+0x2a70]
  40b1b9:	mov    edx,0x1
  40b1be:	cmp    rcx,0x1
  40b1c2:	jbe    40b1f9 <__swc_fn_7dafa2b1_000058_033ce1da+0x1f9>
  40b1c4:	cs nop WORD PTR [rax+rax*1+0x0]
  40b1ce:	xchg   ax,ax
  40b1d0:	lea    r8,[rdx+rdx*4]
  40b1d4:	lea    r8,[r13+r8*8+0x268]
  40b1dc:	lea    r9,[rax+rax*4]
  40b1e0:	mov    r9,QWORD PTR [r13+r9*8+0x280]
  40b1e8:	cmp    QWORD PTR [r8+0x18],r9
  40b1ec:	cmovb  rax,rdx
  40b1f0:	add    rdx,0x1
  40b1f4:	cmp    rdx,rcx
  40b1f7:	jb     40b1d0 <__swc_fn_7dafa2b1_000058_033ce1da+0x1d0>
  40b1f9:	lea    rcx,[rax+rax*4]
  40b1fd:	lea    rcx,[r13+rcx*8+0x268]
  40b205:	mov    r8,QWORD PTR [rcx]
  40b208:	mov    r9,QWORD PTR [rcx+0x8]
  40b20c:	mov    r10,QWORD PTR [rcx+0x10]
  40b210:	mov    rcx,r13
  40b213:	mov    rdx,rax
  40b216:	call   40e1e0 <__swc_fn_7dafa2b1_000056_cfedf3f4>
  40b21b:	mov    rcx,r13
  40b21e:	mov    rdx,r8
  40b221:	mov    r8,r9
  40b224:	mov    r9,r10
  40b227:	call   407750 <__swc_fn_7dafa2b1_000039_05a50673>
  40b22c:	cmp    QWORD PTR [r13+0x2a70],0x0
  40b234:	jne    40b190 <__swc_fn_7dafa2b1_000058_033ce1da+0x190>
  40b23a:	add    QWORD PTR [r13+0x2a78],0x1
  40b242:	mov    rax,QWORD PTR [r13+0x2a70]
  40b249:	lea    rax,[rax+rax*4]
  40b24d:	lea    rax,[r13+rax*8+0x268]
  40b255:	mov    QWORD PTR [rax],r14
  40b258:	mov    QWORD PTR [rax+0x8],r15
  40b25c:	mov    QWORD PTR [rax+0x10],r12
  40b260:	mov    rcx,QWORD PTR [r13+0x2a78]
  40b267:	mov    QWORD PTR [rax+0x18],rcx
  40b26b:	mov    QWORD PTR [rax+0x20],rdi
  40b26f:	add    QWORD PTR [r13+0x2a68],r12
  40b276:	add    QWORD PTR [r13+0x2a70],0x1
  40b27e:	mov    rcx,r13
  40b281:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  40b286:	vmovups xmm6,XMMWORD PTR [rsp+0xa8]
  40b28f:	vmovups xmm7,XMMWORD PTR [rsp+0xb8]
  40b298:	vmovups xmm8,XMMWORD PTR [rsp+0xc8]
  40b2a1:	vmovups xmm9,XMMWORD PTR [rsp+0xd8]
  40b2aa:	vmovups xmm10,XMMWORD PTR [rsp+0xe8]
  40b2b3:	vmovups xmm11,XMMWORD PTR [rsp+0xf8]
  40b2bc:	vmovups xmm12,XMMWORD PTR [rsp+0x108]
  40b2c5:	vmovups xmm13,XMMWORD PTR [rsp+0x118]
  40b2ce:	vmovups xmm14,XMMWORD PTR [rsp+0x128]
  40b2d7:	vmovups xmm15,XMMWORD PTR [rsp+0x138]
  40b2e0:	add    rsp,0x148
  40b2e7:	pop    rsi
  40b2e8:	pop    rdi
  40b2e9:	pop    r15
  40b2eb:	pop    r14
  40b2ed:	pop    r13
  40b2ef:	pop    r12
  40b2f1:	ret
	...

000000000040b300 <__swc_fn_7dafa2b1_000061_1badc238>:
  40b300:	push   rbx
  40b301:	push   r12
  40b303:	push   r13
  40b305:	push   r14
  40b307:	push   r15
  40b309:	push   rdi
  40b30a:	push   rsi
  40b30b:	sub    rsp,0xf0
  40b312:	vmovups XMMWORD PTR [rsp+0x48],xmm6
  40b318:	vmovups XMMWORD PTR [rsp+0x58],xmm7
  40b31e:	vmovups XMMWORD PTR [rsp+0x68],xmm8
  40b324:	vmovups XMMWORD PTR [rsp+0x78],xmm9
  40b32a:	vmovups XMMWORD PTR [rsp+0x88],xmm10
  40b333:	vmovups XMMWORD PTR [rsp+0x98],xmm11
  40b33c:	vmovups XMMWORD PTR [rsp+0xa8],xmm12
  40b345:	vmovups XMMWORD PTR [rsp+0xb8],xmm13
  40b34e:	vmovups XMMWORD PTR [rsp+0xc8],xmm14
  40b357:	vmovups XMMWORD PTR [rsp+0xd8],xmm15
  40b360:	mov    eax,r8d
  40b363:	mov    rbx,rcx
  40b366:	mov    r12,rdx
  40b369:	mov    QWORD PTR [rsp+0x18],rdx
  40b36e:	mov    ecx,DWORD PTR [r12+0x58]
  40b373:	mov    r13d,ecx
  40b376:	cmp    ecx,0x10
  40b379:	mov    ecx,0x10
  40b37e:	cmovb  r13d,ecx
  40b382:	test   r13d,r13d
  40b385:	mov    rcx,r13
  40b388:	mov    edx,0x8
  40b38d:	cmove  ecx,edx
  40b390:	dec    rcx
  40b393:	mov    rdx,0xffffffffffffffff
  40b39a:	sub    rdx,rcx
  40b39d:	xor    r14d,r14d
  40b3a0:	mov    r8,rcx
  40b3a3:	not    r8
  40b3a6:	lea    rcx,[rcx+0x58]
  40b3aa:	and    rcx,r8
  40b3ad:	cmp    rdx,0x58
  40b3b1:	cmovae r14,rcx
  40b3b5:	cmp    eax,0xffffffff
  40b3b8:	jne    40b3c1 <__swc_fn_7dafa2b1_000061_1badc238+0xc1>
  40b3ba:	mov    r15,QWORD PTR [r12+0x48]
  40b3bf:	jmp    40b3f3 <__swc_fn_7dafa2b1_000061_1badc238+0xf3>
  40b3c1:	test   eax,eax
  40b3c3:	jne    40b3cc <__swc_fn_7dafa2b1_000061_1badc238+0xcc>
  40b3c5:	mov    eax,0x8
  40b3ca:	jmp    40b3f0 <__swc_fn_7dafa2b1_000061_1badc238+0xf0>
  40b3cc:	cmp    eax,0x8
  40b3cf:	ja     40b3d7 <__swc_fn_7dafa2b1_000061_1badc238+0xd7>
  40b3d1:	shl    rax,0x4
  40b3d5:	jmp    40b3f0 <__swc_fn_7dafa2b1_000061_1badc238+0xf0>
  40b3d7:	lea    eax,[rax-0x9]
  40b3da:	mov    ecx,eax
  40b3dc:	shr    ecx,0x2
  40b3df:	and    eax,0x3
  40b3e2:	lea    ecx,[rcx+0x7]
  40b3e5:	lea    ecx,[rcx-0x2]
  40b3e8:	lea    eax,[rax+0x5]
  40b3eb:	shlx   rax,rax,rcx
  40b3f0:	mov    r15,rax
  40b3f3:	lea    rax,[r14+r13*1]
  40b3f7:	mov    rcx,0xffffffffffffffff
  40b3fe:	sub    rcx,rax
  40b401:	cmp    r15,rcx
  40b404:	jbe    40b414 <__swc_fn_7dafa2b1_000061_1badc238+0x114>
  40b406:	mov    QWORD PTR [r12+0x40],0x0
  40b40f:	jmp    40b7e6 <__swc_fn_7dafa2b1_000061_1badc238+0x4e6>
  40b414:	mov    QWORD PTR [rsp+0x20],r13
  40b419:	lea    r13,[rsp+0x8]
  40b41e:	add    rax,r15
  40b421:	mov    ecx,0x1000
  40b426:	test   ecx,ecx
  40b428:	mov    edx,0x8
  40b42d:	cmove  ecx,edx
  40b430:	dec    rcx
  40b433:	mov    rdx,0xffffffffffffffff
  40b43a:	sub    rdx,rcx
  40b43d:	cmp    rax,rdx
  40b440:	jbe    40b44c <__swc_fn_7dafa2b1_000061_1badc238+0x14c>
  40b442:	mov    QWORD PTR [r13+0x0],0x0
  40b44a:	jmp    40b459 <__swc_fn_7dafa2b1_000061_1badc238+0x159>
  40b44c:	add    rax,rcx
  40b44f:	andn   rax,rcx,rax
  40b454:	mov    QWORD PTR [rsp+0x8],rax
  40b459:	cmp    QWORD PTR [r13+0x0],0x0
  40b45e:	jne    40b46e <__swc_fn_7dafa2b1_000061_1badc238+0x16e>
  40b460:	mov    QWORD PTR [r12+0x40],0x0
  40b469:	jmp    40b7e6 <__swc_fn_7dafa2b1_000061_1badc238+0x4e6>
  40b46e:	mov    QWORD PTR [rsp+0x30],r15
  40b473:	xor    r15d,r15d
  40b476:	mov    QWORD PTR [rsp+0x38],0x0
  40b47f:	lea    r12,[rsp+0x10]
  40b484:	mov    QWORD PTR [rsp+0x28],r14
  40b489:	mov    r14,QWORD PTR [rsp+0x8]
  40b48e:	mov    QWORD PTR [rsp+0x10],r14
  40b493:	cmp    r14,0x10000
  40b49a:	ja     40b4a1 <__swc_fn_7dafa2b1_000061_1badc238+0x1a1>
  40b49c:	mov    rax,r14
  40b49f:	jmp    40b4f2 <__swc_fn_7dafa2b1_000061_1badc238+0x1f2>
  40b4a1:	xor    eax,eax
  40b4a3:	lea    rcx,[r14-0x1]
  40b4a7:	lzcnt  rax,rcx
  40b4ac:	mov    ecx,0x3f
  40b4b1:	sub    rcx,rax
  40b4b4:	mov    eax,0x1
  40b4b9:	lea    rcx,[rcx-0x3]
  40b4bd:	shl    rax,cl
  40b4c0:	mov    rcx,rax
  40b4c3:	cmp    rax,0x1000
  40b4ca:	mov    eax,0x1000
  40b4cf:	cmovb  rcx,rax
  40b4d3:	mov    rdx,0xffffffffffffffff
  40b4da:	sub    rdx,rcx
  40b4dd:	mov    rax,r14
  40b4e0:	lea    r8,[r14+rcx*1-0x1]
  40b4e5:	neg    rcx
  40b4e8:	and    r8,rcx
  40b4eb:	cmp    r14,rdx
  40b4ee:	cmovbe rax,r8
  40b4f2:	mov    QWORD PTR [rsp+0x8],rax
  40b4f7:	lea    rax,[rip+0x15b02]        # 421000 <__swc_data_base_7dafa2b1>
  40b4fe:	mov    rax,QWORD PTR [rax]
  40b501:	cmp    rax,0xffffffffffffffff
  40b505:	je     40b514 <__swc_fn_7dafa2b1_000061_1badc238+0x214>
  40b507:	mov    eax,eax
  40b509:	mov    edi,eax
  40b50b:	xor    eax,eax
  40b50d:	call   407000 <pthread_getspecific@plt>
  40b512:	jmp    40b516 <__swc_fn_7dafa2b1_000061_1badc238+0x216>
  40b514:	xor    eax,eax
  40b516:	test   rax,rax
  40b519:	jne    40b528 <__swc_fn_7dafa2b1_000061_1badc238+0x228>
  40b51b:	call   40a9a0 <__swc_fn_7dafa2b1_000031_ed8d61a9>
  40b520:	mov    rcx,rax
  40b523:	call   40fe20 <__swc_fn_7dafa2b1_000128_9c45d2d7>
  40b528:	test   rax,rax
  40b52b:	je     40b61c <__swc_fn_7dafa2b1_000061_1badc238+0x31c>
  40b531:	cmp    QWORD PTR [rax],rbx
  40b534:	jne    40b61c <__swc_fn_7dafa2b1_000061_1badc238+0x31c>
  40b53a:	cmp    DWORD PTR [rax+0x20],0x0
  40b53e:	jne    40b61c <__swc_fn_7dafa2b1_000061_1badc238+0x31c>
  40b544:	mov    rcx,QWORD PTR [rsp+0x8]
  40b549:	movabs rdx,0x7fffffffffffffff
  40b553:	cmp    rcx,rdx
  40b556:	mov    rdx,0xffffffffffffffff
  40b55d:	lea    r8,[rcx+rcx*1]
  40b561:	cmovbe rdx,r8
  40b565:	mov    r8d,DWORD PTR [rax+0x730]
  40b56c:	mov    r9d,r8d
  40b56f:	sub    rdx,rcx
  40b572:	inc    rdx
  40b575:	xor    r10d,r10d
  40b578:	test   r8,r8
  40b57b:	jbe    40b5ab <__swc_fn_7dafa2b1_000061_1badc238+0x2ab>
  40b57d:	nop    DWORD PTR [rax]
  40b580:	mov    r11d,r10d
  40b583:	lea    r11,[r11+r11*4]
  40b587:	mov    r11,QWORD PTR [rax+r11*8+0x740]
  40b58f:	sub    r11,rcx
  40b592:	cmp    r11,rdx
  40b595:	jae    40b5a2 <__swc_fn_7dafa2b1_000061_1badc238+0x2a2>
  40b597:	mov    r9d,r10d
  40b59a:	mov    rdx,r11
  40b59d:	test   r11,r11
  40b5a0:	je     40b5ab <__swc_fn_7dafa2b1_000061_1badc238+0x2ab>
  40b5a2:	add    r10,0x1
  40b5a6:	cmp    r10,r8
  40b5a9:	jb     40b580 <__swc_fn_7dafa2b1_000061_1badc238+0x280>
  40b5ab:	mov    ecx,DWORD PTR [rax+0x730]
  40b5b1:	cmp    r9d,ecx
  40b5b4:	jne    40b5ba <__swc_fn_7dafa2b1_000061_1badc238+0x2ba>
  40b5b6:	xor    eax,eax
  40b5b8:	jmp    40b619 <__swc_fn_7dafa2b1_000061_1badc238+0x319>
  40b5ba:	lea    rcx,[r9+r9*4]
  40b5be:	lea    rcx,[rax+rcx*8+0x738]
  40b5c6:	vmovups xmm0,XMMWORD PTR [rcx]
  40b5ca:	mov    rdx,QWORD PTR [rcx+0x10]
  40b5ce:	sub    DWORD PTR [rax+0x730],0x1
  40b5d5:	mov    r8d,DWORD PTR [rax+0x730]
  40b5dc:	lea    r8,[r8+r8*4]
  40b5e0:	lea    r8,[rax+r8*8+0x738]
  40b5e8:	vmovups xmm1,XMMWORD PTR [r8]
  40b5ed:	vmovups XMMWORD PTR [rcx],xmm1
  40b5f1:	vmovups xmm1,XMMWORD PTR [r8+0x10]
  40b5f7:	vmovups XMMWORD PTR [rcx+0x10],xmm1
  40b5fc:	mov    rax,QWORD PTR [r8+0x20]
  40b600:	mov    QWORD PTR [rcx+0x20],rax
  40b604:	vpshufd xmm1,xmm0,0xee
  40b609:	vmovsd QWORD PTR [rsp+0x8],xmm1
  40b60f:	mov    QWORD PTR [rsp+0x10],rdx
  40b614:	vmovq  rax,xmm0
  40b619:	mov    r15,rax
  40b61c:	test   r15,r15
  40b61f:	jne    40b637 <__swc_fn_7dafa2b1_000061_1badc238+0x337>
  40b621:	mov    rcx,rbx
  40b624:	mov    rdx,QWORD PTR [rsp+0x8]
  40b629:	mov    r8,r13
  40b62c:	mov    r9,r12
  40b62f:	call   40aef0 <__swc_fn_7dafa2b1_000055_da36318f>
  40b634:	mov    r15,rax
  40b637:	test   r15,r15
  40b63a:	je     40b67b <__swc_fn_7dafa2b1_000061_1badc238+0x37b>
  40b63c:	cmp    QWORD PTR [r12],r14
  40b640:	jae    40b67b <__swc_fn_7dafa2b1_000061_1badc238+0x37b>
  40b642:	mov    rax,r15
  40b645:	add    rax,QWORD PTR [r12]
  40b649:	mov    rdx,r14
  40b64c:	sub    rdx,QWORD PTR [r12]
  40b650:	mov    rcx,rax
  40b653:	call   4072a0 <__swc_fn_7dafa2b1_000003_644dadb7>
  40b658:	test   al,al
  40b65a:	je     40b663 <__swc_fn_7dafa2b1_000061_1badc238+0x363>
  40b65c:	mov    QWORD PTR [rsp+0x10],r14
  40b661:	jmp    40b67b <__swc_fn_7dafa2b1_000061_1badc238+0x37b>
  40b663:	mov    rcx,rbx
  40b666:	mov    rdx,r15
  40b669:	mov    r8,QWORD PTR [rsp+0x8]
  40b66e:	mov    r9,QWORD PTR [rsp+0x10]
  40b673:	call   40b000 <__swc_fn_7dafa2b1_000058_033ce1da>
  40b678:	xor    r15d,r15d
  40b67b:	test   r15,r15
  40b67e:	jne    40b6fa <__swc_fn_7dafa2b1_000061_1badc238+0x3fa>
  40b680:	cmp    r14,0x10000
  40b687:	ja     40b68e <__swc_fn_7dafa2b1_000061_1badc238+0x38e>
  40b689:	mov    rax,r14
  40b68c:	jmp    40b6df <__swc_fn_7dafa2b1_000061_1badc238+0x3df>
  40b68e:	xor    eax,eax
  40b690:	lea    rcx,[r14-0x1]
  40b694:	lzcnt  rax,rcx
  40b699:	mov    ecx,0x3f
  40b69e:	sub    rcx,rax
  40b6a1:	mov    eax,0x1
  40b6a6:	lea    rcx,[rcx-0x3]
  40b6aa:	shl    rax,cl
  40b6ad:	mov    rcx,rax
  40b6b0:	cmp    rax,0x1000
  40b6b7:	mov    eax,0x1000
  40b6bc:	cmovb  rcx,rax
  40b6c0:	mov    rdx,0xffffffffffffffff
  40b6c7:	sub    rdx,rcx
  40b6ca:	mov    rax,r14
  40b6cd:	lea    r8,[r14+rcx*1-0x1]
  40b6d2:	neg    rcx
  40b6d5:	and    r8,rcx
  40b6d8:	cmp    r14,rdx
  40b6db:	cmovbe rax,r8
  40b6df:	mov    QWORD PTR [rsp+0x8],rax
  40b6e4:	mov    QWORD PTR [rsp+0x10],r14
  40b6e9:	mov    rcx,rbx
  40b6ec:	mov    rdx,rax
  40b6ef:	mov    r8,r14
  40b6f2:	call   40aa60 <__swc_fn_7dafa2b1_000037_92e867c2>
  40b6f7:	mov    r15,rax
  40b6fa:	test   r15,r15
  40b6fd:	jne    40b70b <__swc_fn_7dafa2b1_000061_1badc238+0x40b>
  40b6ff:	mov    r13,QWORD PTR [rsp+0x20]
  40b704:	mov    rsi,QWORD PTR [rsp+0x38]
  40b709:	jmp    40b747 <__swc_fn_7dafa2b1_000061_1badc238+0x447>
  40b70b:	mov    rax,r15
  40b70e:	add    rax,QWORD PTR [rsp+0x28]
  40b713:	mov    r13,QWORD PTR [rsp+0x20]
  40b718:	test   r13d,r13d
  40b71b:	mov    rcx,r13
  40b71e:	mov    edx,0x8
  40b723:	cmove  ecx,edx
  40b726:	dec    rcx
  40b729:	mov    rdx,0xffffffffffffffff
  40b730:	sub    rdx,rcx
  40b733:	cmp    rax,rdx
  40b736:	jbe    40b73c <__swc_fn_7dafa2b1_000061_1badc238+0x43c>
  40b738:	xor    eax,eax
  40b73a:	jmp    40b744 <__swc_fn_7dafa2b1_000061_1badc238+0x444>
  40b73c:	add    rax,rcx
  40b73f:	andn   rax,rcx,rax
  40b744:	mov    rsi,rax
  40b747:	mov    rax,QWORD PTR [rsp+0x8]
  40b74c:	test   r15,r15
  40b74f:	je     40b758 <__swc_fn_7dafa2b1_000061_1badc238+0x458>
  40b751:	mov    rdi,QWORD PTR [rsp+0x18]
  40b756:	jmp    40b76a <__swc_fn_7dafa2b1_000061_1badc238+0x46a>
  40b758:	mov    rdi,QWORD PTR [rsp+0x18]
  40b75d:	mov    QWORD PTR [rdi+0x40],0x0
  40b765:	jmp    40b7e6 <__swc_fn_7dafa2b1_000061_1badc238+0x4e6>
  40b76a:	lea    rdx,[rsi-0x58]
  40b76e:	mov    QWORD PTR [rsi-0x58],r15
  40b772:	mov    QWORD PTR [rsi-0x50],rax
  40b776:	mov    rax,QWORD PTR [rsp+0x10]
  40b77b:	mov    QWORD PTR [rsi-0x48],rax
  40b77f:	mov    QWORD PTR [rsi-0x40],rsi
  40b783:	mov    rax,QWORD PTR [rdi+0x48]
  40b787:	mov    QWORD PTR [rsi-0x38],rax
  40b78b:	mov    rax,QWORD PTR [rsp+0x30]
  40b790:	mov    QWORD PTR [rsi-0x30],rax
  40b794:	mov    DWORD PTR [rsi-0x10],r13d
  40b798:	mov    QWORD PTR [rsi-0x28],0x0
  40b7a0:	mov    QWORD PTR [rsi-0x20],0x0
  40b7a8:	add    r15,QWORD PTR [r12]
  40b7ac:	sub    r15,rsi
  40b7af:	mov    QWORD PTR [rsi-0x30],r15
  40b7b3:	mov    rcx,QWORD PTR [rbx+0x250]
  40b7ba:	nop    WORD PTR [rax+rax*1+0x0]
  40b7c0:	lea    r8,[rcx+r15*1]
  40b7c4:	mov    rax,rcx
  40b7c7:	lock cmpxchg QWORD PTR [rbx+0x250],r8
  40b7d0:	cmp    rax,rcx
  40b7d3:	je     40b7da <__swc_fn_7dafa2b1_000061_1badc238+0x4da>
  40b7d5:	mov    rcx,rax
  40b7d8:	jmp    40b7c0 <__swc_fn_7dafa2b1_000061_1badc238+0x4c0>
  40b7da:	mov    rcx,rbx
  40b7dd:	call   40e150 <__swc_fn_7dafa2b1_000053_a8a124d6>
  40b7e2:	mov    QWORD PTR [rdi+0x40],rsi
  40b7e6:	vmovups xmm6,XMMWORD PTR [rsp+0x48]
  40b7ec:	vmovups xmm7,XMMWORD PTR [rsp+0x58]
  40b7f2:	vmovups xmm8,XMMWORD PTR [rsp+0x68]
  40b7f8:	vmovups xmm9,XMMWORD PTR [rsp+0x78]
  40b7fe:	vmovups xmm10,XMMWORD PTR [rsp+0x88]
  40b807:	vmovups xmm11,XMMWORD PTR [rsp+0x98]
  40b810:	vmovups xmm12,XMMWORD PTR [rsp+0xa8]
  40b819:	vmovups xmm13,XMMWORD PTR [rsp+0xb8]
  40b822:	vmovups xmm14,XMMWORD PTR [rsp+0xc8]
  40b82b:	vmovups xmm15,XMMWORD PTR [rsp+0xd8]
  40b834:	add    rsp,0xf0
  40b83b:	pop    rsi
  40b83c:	pop    rdi
  40b83d:	pop    r15
  40b83f:	pop    r14
  40b841:	pop    r13
  40b843:	pop    r12
  40b845:	pop    rbx
  40b846:	ret
	...

000000000040b850 <__swc_fn_7dafa2b1_000064_6905bec4>:
  40b850:	push   rbx
  40b851:	push   r12
  40b853:	push   rdi
  40b854:	push   rsi
  40b855:	sub    rsp,0xb8
  40b85c:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40b862:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40b868:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40b86e:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40b874:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40b87a:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40b880:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40b886:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40b88f:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40b898:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40b8a1:	mov    rbx,rdx
  40b8a4:	mov    r12,rcx
  40b8a7:	cmp    DWORD PTR [rbx+0x58],0x0
  40b8ab:	je     40b8c5 <__swc_fn_7dafa2b1_000064_6905bec4+0x75>
  40b8ad:	mov    eax,DWORD PTR [rbx+0x58]
  40b8b0:	sub    eax,0x1
  40b8b3:	test   DWORD PTR [rbx+0x58],eax
  40b8b6:	je     40b8c5 <__swc_fn_7dafa2b1_000064_6905bec4+0x75>
  40b8b8:	mov    QWORD PTR [rbx+0x40],0x0
  40b8c0:	jmp    40bad7 <__swc_fn_7dafa2b1_000064_6905bec4+0x287>
  40b8c5:	cmp    QWORD PTR [rbx+0x48],0x0
  40b8ca:	jne    40b8d9 <__swc_fn_7dafa2b1_000064_6905bec4+0x89>
  40b8cc:	mov    QWORD PTR [rbx+0x40],0x0
  40b8d4:	jmp    40bad7 <__swc_fn_7dafa2b1_000064_6905bec4+0x287>
  40b8d9:	lea    rax,[rsp+0x8]
  40b8de:	mov    rcx,QWORD PTR [rbx+0x48]
  40b8e2:	cmp    rcx,0x8
  40b8e6:	ja     40b8f0 <__swc_fn_7dafa2b1_000064_6905bec4+0xa0>
  40b8e8:	mov    DWORD PTR [rax],0x0
  40b8ee:	jmp    40b94b <__swc_fn_7dafa2b1_000064_6905bec4+0xfb>
  40b8f0:	cmp    rcx,0x80
  40b8f7:	ja     40b907 <__swc_fn_7dafa2b1_000064_6905bec4+0xb7>
  40b8f9:	lea    rcx,[rcx+0xf]
  40b8fd:	shr    rcx,0x4
  40b901:	mov    DWORD PTR [rsp+0x8],ecx
  40b905:	jmp    40b94b <__swc_fn_7dafa2b1_000064_6905bec4+0xfb>
  40b907:	cmp    rcx,0x10000
  40b90e:	jbe    40b918 <__swc_fn_7dafa2b1_000064_6905bec4+0xc8>
  40b910:	mov    DWORD PTR [rax],0xffffffff
  40b916:	jmp    40b94b <__swc_fn_7dafa2b1_000064_6905bec4+0xfb>
  40b918:	dec    rcx
  40b91b:	xor    edx,edx
  40b91d:	lzcnt  rdx,rcx
  40b922:	mov    r8d,0x3f
  40b928:	sub    r8d,edx
  40b92b:	lea    edx,[r8-0x2]
  40b92f:	shrx   rcx,rcx,rdx
  40b934:	and    ecx,0x3
  40b937:	lea    edx,[r8-0x7]
  40b93b:	lea    edx,[rdx*4+0x0]
  40b942:	lea    edx,[rdx+0x9]
  40b945:	add    edx,ecx
  40b947:	mov    DWORD PTR [rsp+0x8],edx
  40b94b:	cmp    DWORD PTR [rax],0x0
  40b94e:	jne    40b95e <__swc_fn_7dafa2b1_000064_6905bec4+0x10e>
  40b950:	cmp    DWORD PTR [rbx+0x58],0x8
  40b954:	jbe    40b95e <__swc_fn_7dafa2b1_000064_6905bec4+0x10e>
  40b956:	mov    DWORD PTR [rsp+0x8],0x1
  40b95e:	cmp    DWORD PTR [rbx+0x58],0x10
  40b962:	jbe    40b9e1 <__swc_fn_7dafa2b1_000064_6905bec4+0x191>
  40b968:	cmp    DWORD PTR [rbx+0x58],0x40
  40b96c:	ja     40b9e1 <__swc_fn_7dafa2b1_000064_6905bec4+0x191>
  40b96e:	cmp    DWORD PTR [rax],0xffffffff
  40b971:	je     40b9e1 <__swc_fn_7dafa2b1_000064_6905bec4+0x191>
  40b973:	mov    ecx,DWORD PTR [rsp+0x8]
  40b977:	mov    edx,DWORD PTR [rbx+0x58]
  40b97a:	dec    rdx
  40b97d:	cmp    ecx,0x2d
  40b980:	jae    40b9d8 <__swc_fn_7dafa2b1_000064_6905bec4+0x188>
  40b982:	cs nop WORD PTR [rax+rax*1+0x0]
  40b98c:	nop    DWORD PTR [rax+0x0]
  40b990:	mov    r8d,ecx
  40b993:	test   ecx,ecx
  40b995:	jne    40b99f <__swc_fn_7dafa2b1_000064_6905bec4+0x14f>
  40b997:	mov    r8d,0x8
  40b99d:	jmp    40b9cb <__swc_fn_7dafa2b1_000064_6905bec4+0x17b>
  40b99f:	cmp    r8d,0x8
  40b9a3:	ja     40b9ab <__swc_fn_7dafa2b1_000064_6905bec4+0x15b>
  40b9a5:	shl    r8,0x4
  40b9a9:	jmp    40b9cb <__swc_fn_7dafa2b1_000064_6905bec4+0x17b>
  40b9ab:	lea    r8d,[r8-0x9]
  40b9af:	mov    r9d,r8d
  40b9b2:	shr    r9d,0x2
  40b9b6:	and    r8d,0x3
  40b9ba:	lea    r9d,[r9+0x7]
  40b9be:	lea    r9d,[r9-0x2]
  40b9c2:	lea    r8d,[r8+0x5]
  40b9c6:	shlx   r8,r8,r9
  40b9cb:	test   r8,rdx
  40b9ce:	je     40b9dd <__swc_fn_7dafa2b1_000064_6905bec4+0x18d>
  40b9d0:	add    ecx,0x1
  40b9d3:	cmp    ecx,0x2d
  40b9d6:	jb     40b990 <__swc_fn_7dafa2b1_000064_6905bec4+0x140>
  40b9d8:	mov    ecx,0xffffffff
  40b9dd:	mov    DWORD PTR [rsp+0x8],ecx
  40b9e1:	mov    ecx,DWORD PTR [rsp+0x8]
  40b9e5:	cmp    ecx,0xffffffff
  40b9e8:	je     40b9f0 <__swc_fn_7dafa2b1_000064_6905bec4+0x1a0>
  40b9ea:	cmp    DWORD PTR [rbx+0x58],0x40
  40b9ee:	jbe    40ba03 <__swc_fn_7dafa2b1_000064_6905bec4+0x1b3>
  40b9f0:	mov    rcx,r12
  40b9f3:	mov    rdx,rbx
  40b9f6:	mov    r8d,DWORD PTR [rax]
  40b9f9:	call   40b300 <__swc_fn_7dafa2b1_000061_1badc238>
  40b9fe:	jmp    40bad7 <__swc_fn_7dafa2b1_000064_6905bec4+0x287>
  40ba03:	lea    rax,[rip+0x155f6]        # 421000 <__swc_data_base_7dafa2b1>
  40ba0a:	mov    rax,QWORD PTR [rax]
  40ba0d:	cmp    rax,0xffffffffffffffff
  40ba11:	je     40ba20 <__swc_fn_7dafa2b1_000064_6905bec4+0x1d0>
  40ba13:	mov    eax,eax
  40ba15:	mov    edi,eax
  40ba17:	xor    eax,eax
  40ba19:	call   407000 <pthread_getspecific@plt>
  40ba1e:	jmp    40ba22 <__swc_fn_7dafa2b1_000064_6905bec4+0x1d2>
  40ba20:	xor    eax,eax
  40ba22:	test   rax,rax
  40ba25:	jne    40ba34 <__swc_fn_7dafa2b1_000064_6905bec4+0x1e4>
  40ba27:	call   40a9a0 <__swc_fn_7dafa2b1_000031_ed8d61a9>
  40ba2c:	mov    rcx,rax
  40ba2f:	call   40fe20 <__swc_fn_7dafa2b1_000128_9c45d2d7>
  40ba34:	test   rax,rax
  40ba37:	je     40ba44 <__swc_fn_7dafa2b1_000064_6905bec4+0x1f4>
  40ba39:	cmp    QWORD PTR [rax],r12
  40ba3c:	jne    40ba44 <__swc_fn_7dafa2b1_000064_6905bec4+0x1f4>
  40ba3e:	cmp    DWORD PTR [rax+0x20],0x0
  40ba42:	je     40ba4f <__swc_fn_7dafa2b1_000064_6905bec4+0x1ff>
  40ba44:	mov    rcx,r12
  40ba47:	mov    rdx,rax
  40ba4a:	call   40dd90 <__swc_fn_7dafa2b1_000041_ed1cda78>
  40ba4f:	test   rax,rax
  40ba52:	jne    40ba5e <__swc_fn_7dafa2b1_000064_6905bec4+0x20e>
  40ba54:	mov    QWORD PTR [rbx+0x40],0x0
  40ba5c:	jmp    40bad7 <__swc_fn_7dafa2b1_000064_6905bec4+0x287>
  40ba5e:	lea    r8,[rsp+0xc]
  40ba63:	mov    ecx,DWORD PTR [rsp+0x8]
  40ba67:	mov    DWORD PTR [rsp+0xc],ecx
  40ba6b:	mov    ecx,DWORD PTR [r8]
  40ba6e:	lea    rcx,[rcx+rcx*4]
  40ba72:	mov    rcx,QWORD PTR [rax+rcx*8+0x28]
  40ba77:	test   rcx,rcx
  40ba7a:	je     40bab3 <__swc_fn_7dafa2b1_000064_6905bec4+0x263>
  40ba7c:	mov    rdx,QWORD PTR [rcx]
  40ba7f:	test   rdx,rdx
  40ba82:	je     40ba90 <__swc_fn_7dafa2b1_000064_6905bec4+0x240>
  40ba84:	mov    r9,QWORD PTR [rdx]
  40ba87:	mov    QWORD PTR [rcx],r9
  40ba8a:	add    DWORD PTR [rcx+0x28],0x1
  40ba8e:	jmp    40baae <__swc_fn_7dafa2b1_000064_6905bec4+0x25e>
  40ba90:	mov    rdx,QWORD PTR [rcx+0x18]
  40ba94:	cmp    QWORD PTR [rcx+0x20],rdx
  40ba98:	jae    40baac <__swc_fn_7dafa2b1_000064_6905bec4+0x25c>
  40ba9a:	mov    rdx,QWORD PTR [rcx+0x20]
  40ba9e:	mov    r9d,DWORD PTR [rcx+0x2c]
  40baa2:	add    QWORD PTR [rcx+0x20],r9
  40baa6:	add    DWORD PTR [rcx+0x28],0x1
  40baaa:	jmp    40baae <__swc_fn_7dafa2b1_000064_6905bec4+0x25e>
  40baac:	xor    edx,edx
  40baae:	test   rdx,rdx
  40bab1:	jne    40bac4 <__swc_fn_7dafa2b1_000064_6905bec4+0x274>
  40bab3:	mov    rcx,r12
  40bab6:	mov    rdx,rax
  40bab9:	mov    r8d,DWORD PTR [r8]
  40babc:	call   40df00 <__swc_fn_7dafa2b1_000050_e33921d7>
  40bac1:	mov    rdx,rax
  40bac4:	test   rdx,rdx
  40bac7:	jne    40bad3 <__swc_fn_7dafa2b1_000064_6905bec4+0x283>
  40bac9:	mov    QWORD PTR [rbx+0x40],0x0
  40bad1:	jmp    40bad7 <__swc_fn_7dafa2b1_000064_6905bec4+0x287>
  40bad3:	mov    QWORD PTR [rbx+0x40],rdx
  40bad7:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40badd:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40bae3:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40bae9:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40baef:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40baf5:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40bafb:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40bb01:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40bb0a:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40bb13:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40bb1c:	add    rsp,0xb8
  40bb23:	pop    rsi
  40bb24:	pop    rdi
  40bb25:	pop    r12
  40bb27:	pop    rbx
  40bb28:	ret
  40bb29:	add    BYTE PTR [rax],al
  40bb2b:	add    BYTE PTR [rax],al
  40bb2d:	add    BYTE PTR [rax],al
	...

000000000040bb30 <__swc_fn_7dafa2b1_000067_381f5b88>:
  40bb30:	ret
	...

000000000040bb40 <__swc_fn_7dafa2b1_000070_2cd83140>:
  40bb40:	push   r12
  40bb42:	push   r13
  40bb44:	push   r14
  40bb46:	push   rdi
  40bb47:	push   rsi
  40bb48:	sub    rsp,0x1a0
  40bb4f:	vmovups XMMWORD PTR [rsp+0xf8],xmm6
  40bb58:	vmovups XMMWORD PTR [rsp+0x108],xmm7
  40bb61:	vmovups XMMWORD PTR [rsp+0x118],xmm8
  40bb6a:	vmovups XMMWORD PTR [rsp+0x128],xmm9
  40bb73:	vmovups XMMWORD PTR [rsp+0x138],xmm10
  40bb7c:	vmovups XMMWORD PTR [rsp+0x148],xmm11
  40bb85:	vmovups XMMWORD PTR [rsp+0x158],xmm12
  40bb8e:	vmovups XMMWORD PTR [rsp+0x168],xmm13
  40bb97:	vmovups XMMWORD PTR [rsp+0x178],xmm14
  40bba0:	vmovups XMMWORD PTR [rsp+0x188],xmm15
  40bba9:	mov    r12,rdx
  40bbac:	mov    r13,rcx
  40bbaf:	mov    rax,QWORD PTR [r12+0x48]
  40bbb4:	mov    ecx,DWORD PTR [r12+0x58]
  40bbb9:	lea    rdx,[rax-0x1]
  40bbbd:	cmp    rdx,0x10000
  40bbc4:	jae    40bcbe <__swc_fn_7dafa2b1_000070_2cd83140+0x17e>
  40bbca:	cmp    rax,0x8
  40bbce:	ja     40bbd5 <__swc_fn_7dafa2b1_000070_2cd83140+0x95>
  40bbd0:	xor    r14d,r14d
  40bbd3:	jmp    40bc27 <__swc_fn_7dafa2b1_000070_2cd83140+0xe7>
  40bbd5:	cmp    rax,0x80
  40bbdc:	ja     40bbe8 <__swc_fn_7dafa2b1_000070_2cd83140+0xa8>
  40bbde:	lea    r14,[rax+0xf]
  40bbe2:	shr    r14,0x4
  40bbe6:	jmp    40bc27 <__swc_fn_7dafa2b1_000070_2cd83140+0xe7>
  40bbe8:	cmp    rax,0x10000
  40bbef:	jbe    40bbf9 <__swc_fn_7dafa2b1_000070_2cd83140+0xb9>
  40bbf1:	mov    r14d,0xffffffff
  40bbf7:	jmp    40bc27 <__swc_fn_7dafa2b1_000070_2cd83140+0xe7>
  40bbf9:	xor    eax,eax
  40bbfb:	lzcnt  rax,rdx
  40bc00:	mov    r8d,0x3f
  40bc06:	sub    r8d,eax
  40bc09:	lea    eax,[r8-0x2]
  40bc0d:	shrx   rax,rdx,rax
  40bc12:	and    eax,0x3
  40bc15:	lea    edx,[r8-0x7]
  40bc19:	lea    edx,[rdx*4+0x0]
  40bc20:	lea    edx,[rdx+0x9]
  40bc23:	lea    r14d,[rdx+rax*1]
  40bc27:	cmp    ecx,0x8
  40bc2a:	jbe    40bc43 <__swc_fn_7dafa2b1_000070_2cd83140+0x103>
  40bc2c:	cmp    ecx,0x10
  40bc2f:	jne    40bcbe <__swc_fn_7dafa2b1_000070_2cd83140+0x17e>
  40bc35:	test   r14d,r14d
  40bc38:	mov    eax,0x1
  40bc3d:	cmove  r14d,eax
  40bc41:	jmp    40bc4a <__swc_fn_7dafa2b1_000070_2cd83140+0x10a>
  40bc43:	lea    eax,[rcx-0x1]
  40bc46:	test   eax,ecx
  40bc48:	jne    40bcbe <__swc_fn_7dafa2b1_000070_2cd83140+0x17e>
  40bc4a:	lea    rax,[rip+0x153af]        # 421000 <__swc_data_base_7dafa2b1>
  40bc51:	mov    rax,QWORD PTR [rax]
  40bc54:	cmp    rax,0xffffffffffffffff
  40bc58:	je     40bc67 <__swc_fn_7dafa2b1_000070_2cd83140+0x127>
  40bc5a:	mov    eax,eax
  40bc5c:	mov    edi,eax
  40bc5e:	xor    eax,eax
  40bc60:	call   407000 <pthread_getspecific@plt>
  40bc65:	jmp    40bc69 <__swc_fn_7dafa2b1_000070_2cd83140+0x129>
  40bc67:	xor    eax,eax
  40bc69:	test   rax,rax
  40bc6c:	je     40bcbe <__swc_fn_7dafa2b1_000070_2cd83140+0x17e>
  40bc6e:	cmp    QWORD PTR [rax],r13
  40bc71:	jne    40bcbe <__swc_fn_7dafa2b1_000070_2cd83140+0x17e>
  40bc73:	lea    rcx,[r14+r14*4]
  40bc77:	mov    rax,QWORD PTR [rax+rcx*8+0x28]
  40bc7c:	test   rax,rax
  40bc7f:	je     40bcbe <__swc_fn_7dafa2b1_000070_2cd83140+0x17e>
  40bc81:	mov    rcx,QWORD PTR [rax]
  40bc84:	test   rcx,rcx
  40bc87:	je     40bc95 <__swc_fn_7dafa2b1_000070_2cd83140+0x155>
  40bc89:	mov    rdx,QWORD PTR [rcx]
  40bc8c:	mov    QWORD PTR [rax],rdx
  40bc8f:	add    DWORD PTR [rax+0x28],0x1
  40bc93:	jmp    40bcb2 <__swc_fn_7dafa2b1_000070_2cd83140+0x172>
  40bc95:	mov    rcx,QWORD PTR [rax+0x18]
  40bc99:	cmp    QWORD PTR [rax+0x20],rcx
  40bc9d:	jae    40bcb0 <__swc_fn_7dafa2b1_000070_2cd83140+0x170>
  40bc9f:	mov    rcx,QWORD PTR [rax+0x20]
  40bca3:	mov    edx,DWORD PTR [rax+0x2c]
  40bca6:	add    QWORD PTR [rax+0x20],rdx
  40bcaa:	add    DWORD PTR [rax+0x28],0x1
  40bcae:	jmp    40bcb2 <__swc_fn_7dafa2b1_000070_2cd83140+0x172>
  40bcb0:	xor    ecx,ecx
  40bcb2:	test   rcx,rcx
  40bcb5:	je     40bcbe <__swc_fn_7dafa2b1_000070_2cd83140+0x17e>
  40bcb7:	mov    QWORD PTR [r12+0x40],rcx
  40bcbc:	jmp    40bcc9 <__swc_fn_7dafa2b1_000070_2cd83140+0x189>
  40bcbe:	mov    rcx,r13
  40bcc1:	mov    rdx,r12
  40bcc4:	call   40e980 <__swc_fn_7dafa2b1_000071_7e144e9b>
  40bcc9:	vmovups xmm6,XMMWORD PTR [rsp+0xf8]
  40bcd2:	vmovups xmm7,XMMWORD PTR [rsp+0x108]
  40bcdb:	vmovups xmm8,XMMWORD PTR [rsp+0x118]
  40bce4:	vmovups xmm9,XMMWORD PTR [rsp+0x128]
  40bced:	vmovups xmm10,XMMWORD PTR [rsp+0x138]
  40bcf6:	vmovups xmm11,XMMWORD PTR [rsp+0x148]
  40bcff:	vmovups xmm12,XMMWORD PTR [rsp+0x158]
  40bd08:	vmovups xmm13,XMMWORD PTR [rsp+0x168]
  40bd11:	vmovups xmm14,XMMWORD PTR [rsp+0x178]
  40bd1a:	vmovups xmm15,XMMWORD PTR [rsp+0x188]
  40bd23:	add    rsp,0x1a0
  40bd2a:	pop    rsi
  40bd2b:	pop    rdi
  40bd2c:	pop    r14
  40bd2e:	pop    r13
  40bd30:	pop    r12
  40bd32:	ret
	...

000000000040bd40 <__swc_fn_7dafa2b1_000073_c77adf75>:
  40bd40:	push   r12
  40bd42:	push   r13
  40bd44:	push   r14
  40bd46:	push   r15
  40bd48:	push   rdi
  40bd49:	push   rsi
  40bd4a:	sub    rsp,0x188
  40bd51:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40bd5a:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40bd63:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40bd6c:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40bd75:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40bd7e:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40bd87:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40bd90:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40bd99:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40bda2:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40bdab:	mov    r12,rdx
  40bdae:	mov    r13,rcx
  40bdb1:	mov    r14,QWORD PTR [r12+0x40]
  40bdb6:	lea    rax,[rip+0x172b3]        # 423070 <__swc_bss_base_7dafa2b1+0x30>
  40bdbd:	mov    rcx,r14
  40bdc0:	sub    rcx,QWORD PTR [rax+0x8]
  40bdc4:	mov    rax,QWORD PTR [rip+0x172b5]        # 423080 <__swc_bss_base_7dafa2b1+0x40>
  40bdcb:	cmp    rcx,rax
  40bdce:	jae    40bdfa <__swc_fn_7dafa2b1_000073_c77adf75+0xba>
  40bdd0:	mov    rax,r14
  40bdd3:	and    rax,0xffffffffffc00000
  40bdda:	mov    rcx,r14
  40bddd:	shr    rcx,0x10
  40bde1:	and    ecx,0x3f
  40bde4:	mov    edx,DWORD PTR [rax+0x28]
  40bde7:	shrx   ecx,ecx,edx
  40bdec:	shl    rcx,0x4
  40bdf0:	lea    r15,[rax+rcx*8+0x80]
  40bdf8:	jmp    40be05 <__swc_fn_7dafa2b1_000073_c77adf75+0xc5>
  40bdfa:	mov    rcx,r14
  40bdfd:	call   40a8d0 <__swc_fn_7dafa2b1_000022_77c2d682>
  40be02:	mov    r15,rax
  40be05:	test   r15,r15
  40be08:	je     40beaf <__swc_fn_7dafa2b1_000073_c77adf75+0x16f>
  40be0e:	lea    rax,[rip+0x151eb]        # 421000 <__swc_data_base_7dafa2b1>
  40be15:	mov    rax,QWORD PTR [rax]
  40be18:	cmp    rax,0xffffffffffffffff
  40be1c:	je     40be2b <__swc_fn_7dafa2b1_000073_c77adf75+0xeb>
  40be1e:	mov    eax,eax
  40be20:	mov    edi,eax
  40be22:	xor    eax,eax
  40be24:	call   407000 <pthread_getspecific@plt>
  40be29:	jmp    40be2d <__swc_fn_7dafa2b1_000073_c77adf75+0xed>
  40be2b:	xor    eax,eax
  40be2d:	mov    rcx,QWORD PTR [r15+0x40]
  40be31:	cmp    rcx,rax
  40be34:	jne    40be94 <__swc_fn_7dafa2b1_000073_c77adf75+0x154>
  40be36:	test   rax,rax
  40be39:	je     40beaf <__swc_fn_7dafa2b1_000073_c77adf75+0x16f>
  40be3b:	mov    ecx,DWORD PTR [r15+0x6c]
  40be3f:	test   ecx,ecx
  40be41:	je     40be61 <__swc_fn_7dafa2b1_000073_c77adf75+0x121>
  40be43:	mov    rcx,r13
  40be46:	mov    rdx,rax
  40be49:	mov    r8,r15
  40be4c:	mov    QWORD PTR [rsp+0xd8],rax
  40be54:	call   40de90 <__swc_fn_7dafa2b1_000047_3d3eceb4>
  40be59:	mov    rax,QWORD PTR [rsp+0xd8]
  40be61:	mov    rcx,QWORD PTR [r15]
  40be64:	mov    QWORD PTR [r14],rcx
  40be67:	mov    QWORD PTR [r15],r14
  40be6a:	sub    DWORD PTR [r15+0x28],0x1
  40be6f:	jne    40bea4 <__swc_fn_7dafa2b1_000073_c77adf75+0x164>
  40be71:	movzx  ecx,BYTE PTR [r15+0x39]
  40be76:	lea    rcx,[rcx+rcx*4]
  40be7a:	lea    rcx,[rax+rcx*8+0x28]
  40be7f:	cmp    QWORD PTR [rcx],r15
  40be82:	je     40bea4 <__swc_fn_7dafa2b1_000073_c77adf75+0x164>
  40be84:	mov    rcx,r13
  40be87:	mov    rdx,rax
  40be8a:	mov    r8,r15
  40be8d:	call   407d80 <__swc_fn_7dafa2b1_000051_5b91e689>
  40be92:	jmp    40bea4 <__swc_fn_7dafa2b1_000073_c77adf75+0x164>
  40be94:	test   rcx,rcx
  40be97:	je     40beaf <__swc_fn_7dafa2b1_000073_c77adf75+0x16f>
  40be99:	mov    rcx,r15
  40be9c:	mov    rdx,r14
  40be9f:	call   40a510 <__swc_fn_7dafa2b1_000010_186cd0c2>
  40bea4:	mov    QWORD PTR [r12+0x40],0x0
  40bead:	jmp    40beba <__swc_fn_7dafa2b1_000073_c77adf75+0x17a>
  40beaf:	mov    rcx,r13
  40beb2:	mov    rdx,r12
  40beb5:	call   40e9a0 <__swc_fn_7dafa2b1_000074_9eaf4878>
  40beba:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40bec3:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40becc:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40bed5:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40bede:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40bee7:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40bef0:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40bef9:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40bf02:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40bf0b:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40bf14:	add    rsp,0x188
  40bf1b:	pop    rsi
  40bf1c:	pop    rdi
  40bf1d:	pop    r15
  40bf1f:	pop    r14
  40bf21:	pop    r13
  40bf23:	pop    r12
  40bf25:	ret
	...

000000000040bf30 <__swc_fn_7dafa2b1_000076_d8e626b0>:
  40bf30:	sub    rsp,0x8
  40bf34:	mov    rax,rdx
  40bf37:	mov    rdx,QWORD PTR [rax+0x40]
  40bf3b:	mov    r8,rax
  40bf3e:	call   40bb30 <__swc_fn_7dafa2b1_000067_381f5b88>
  40bf43:	add    rsp,0x8
  40bf47:	ret
	...

000000000040bf50 <__swc_fn_7dafa2b1_000079_29fad089>:
  40bf50:	push   rsi
  40bf51:	push   rdi
  40bf52:	sub    rsp,0x8
  40bf56:	cmp    rcx,0xffffffffffffffef
  40bf5a:	ja     40bf80 <__swc_fn_7dafa2b1_000079_29fad089+0x30>
  40bf5c:	xor    esi,esi
  40bf5e:	lea    rax,[rcx+0x100f]
  40bf65:	and    rax,0xfffffffffffff000
  40bf6c:	lea    rcx,[rcx+0x10]
  40bf70:	cmp    rcx,0xfffffffffffff000
  40bf77:	cmovbe rsi,rax
  40bf7b:	test   rsi,rsi
  40bf7e:	jne    40bf89 <__swc_fn_7dafa2b1_000079_29fad089+0x39>
  40bf80:	xor    eax,eax
  40bf82:	add    rsp,0x8
  40bf86:	pop    rdi
  40bf87:	pop    rsi
  40bf88:	ret
  40bf89:	mov    rcx,rsi
  40bf8c:	call   40c5e0 <__swc_fn_7dafa2b1_000109_aa570b2b>
  40bf91:	mov    rdi,rax
  40bf94:	test   rax,rax
  40bf97:	jne    40bfa2 <__swc_fn_7dafa2b1_000079_29fad089+0x52>
  40bf99:	xor    eax,eax
  40bf9b:	add    rsp,0x8
  40bf9f:	pop    rdi
  40bfa0:	pop    rsi
  40bfa1:	ret
  40bfa2:	mov    rcx,rdi
  40bfa5:	mov    rdx,rsi
  40bfa8:	call   409240 <__swc_fn_7dafa2b1_000111_e724f834>
  40bfad:	test   al,al
  40bfaf:	jne    40bfc5 <__swc_fn_7dafa2b1_000079_29fad089+0x75>
  40bfb1:	mov    rcx,rdi
  40bfb4:	mov    rdx,rsi
  40bfb7:	call   40fad0 <__swc_fn_7dafa2b1_000113_25e345b1>
  40bfbc:	xor    eax,eax
  40bfbe:	add    rsp,0x8
  40bfc2:	pop    rdi
  40bfc3:	pop    rsi
  40bfc4:	ret
  40bfc5:	mov    QWORD PTR [rdi],rsi
  40bfc8:	mov    QWORD PTR [rdi+0x8],0x0
  40bfd0:	lea    rax,[rdi+0x10]
  40bfd4:	add    rsp,0x8
  40bfd8:	pop    rdi
  40bfd9:	pop    rsi
  40bfda:	ret
  40bfdb:	add    BYTE PTR [rax],al
  40bfdd:	add    BYTE PTR [rax],al
	...

000000000040bfe0 <__swc_fn_7dafa2b1_000082_9f4f5092>:
  40bfe0:	sub    rsp,0x8
  40bfe4:	cmp    BYTE PTR [rcx+0x2c],0x10
  40bfe8:	jne    40bff3 <__swc_fn_7dafa2b1_000082_9f4f5092+0x13>
  40bfea:	test   DWORD PTR [rcx+0x28],0x80
  40bff1:	je     40bffb <__swc_fn_7dafa2b1_000082_9f4f5092+0x1b>
  40bff3:	mov    rax,rcx
  40bff6:	add    rsp,0x8
  40bffa:	ret
  40bffb:	mov    rcx,QWORD PTR [rcx+0x40]
  40bfff:	call   40bfe0 <__swc_fn_7dafa2b1_000082_9f4f5092>
  40c004:	add    rsp,0x8
  40c008:	ret
	...

000000000040c020 <__swc_fn_7dafa2b1_000085_88128f21>:
  40c020:	push   rsi
  40c021:	push   rdi
  40c022:	push   r12
  40c024:	push   r13
  40c026:	sub    rsp,0x8
  40c02a:	mov    rsi,rdx
  40c02d:	mov    rdi,rcx
  40c030:	xor    r8d,r8d
  40c033:	call   4085a0 <__swc_fn_7dafa2b1_000090_9a1d717d>
  40c038:	test   al,al
  40c03a:	je     40c04c <__swc_fn_7dafa2b1_000085_88128f21+0x2c>
  40c03c:	mov    eax,0x1
  40c041:	add    rsp,0x8
  40c045:	pop    r13
  40c047:	pop    r12
  40c049:	pop    rdi
  40c04a:	pop    rsi
  40c04b:	ret
  40c04c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40c051:	je     40c060 <__swc_fn_7dafa2b1_000085_88128f21+0x40>
  40c053:	xor    eax,eax
  40c055:	add    rsp,0x8
  40c059:	pop    r13
  40c05b:	pop    r12
  40c05d:	pop    rdi
  40c05e:	pop    rsi
  40c05f:	ret
  40c060:	mov    r12,QWORD PTR [rsi+0x98]
  40c067:	mov    rax,QWORD PTR [rsi+0xa0]
  40c06e:	mov    rsi,rax
  40c071:	xor    r13d,r13d
  40c074:	test   rsi,rsi
  40c077:	je     40c0d4 <__swc_fn_7dafa2b1_000085_88128f21+0xb4>
  40c079:	cs nop WORD PTR [rax+rax*1+0x0]
  40c083:	cs nop WORD PTR [rax+rax*1+0x0]
  40c08d:	nop    DWORD PTR [rax]
  40c090:	lea    rax,[r13*8+0x0]
  40c098:	mov    rax,QWORD PTR [r12+rax*8+0x10]
  40c09d:	mov    rcx,rax
  40c0a0:	call   40bfe0 <__swc_fn_7dafa2b1_000082_9f4f5092>
  40c0a5:	cmp    BYTE PTR [rax+0x2c],0xe
  40c0a9:	jne    40c0ca <__swc_fn_7dafa2b1_000085_88128f21+0xaa>
  40c0ab:	mov    rcx,rdi
  40c0ae:	mov    rdx,rax
  40c0b1:	call   40c020 <__swc_fn_7dafa2b1_000085_88128f21>
  40c0b6:	test   al,al
  40c0b8:	je     40c0ca <__swc_fn_7dafa2b1_000085_88128f21+0xaa>
  40c0ba:	mov    eax,0x1
  40c0bf:	add    rsp,0x8
  40c0c3:	pop    r13
  40c0c5:	pop    r12
  40c0c7:	pop    rdi
  40c0c8:	pop    rsi
  40c0c9:	ret
  40c0ca:	add    r13,0x1
  40c0ce:	sub    rsi,0x1
  40c0d2:	jne    40c090 <__swc_fn_7dafa2b1_000085_88128f21+0x70>
  40c0d4:	xor    eax,eax
  40c0d6:	add    rsp,0x8
  40c0da:	pop    r13
  40c0dc:	pop    r12
  40c0de:	pop    rdi
  40c0df:	pop    rsi
  40c0e0:	ret
	...

000000000040c0f0 <__swc_fn_7dafa2b1_000088_17711411>:
  40c0f0:	sub    rsp,0x18
  40c0f4:	vxorps xmm0,xmm0,xmm0
  40c0f8:	vmovdqu XMMWORD PTR [rsp],xmm0
  40c0fd:	call   40ebb0 <__swc_fn_7dafa2b1_000089_157b05de>
  40c102:	add    rsp,0x18
  40c106:	ret
	...

000000000040c110 <__swc_fn_7dafa2b1_000091_e6773530>:
  40c110:	sub    rsp,0x8
  40c114:	mov    rcx,QWORD PTR [rip+0x19c25]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40c11b:	test   rcx,rcx
  40c11e:	jne    40c130 <__swc_fn_7dafa2b1_000091_e6773530+0x20>
  40c120:	call   40a1a0 <__swc_fn_7dafa2b1_000165_e09accff>
  40c125:	lea    rcx,[rax+0x1]
  40c129:	mov    QWORD PTR [rip+0x19c10],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40c130:	dec    rcx
  40c133:	call   4118a0 <__swc_fn_7dafa2b1_000167_3130645d>
  40c138:	mov    rax,QWORD PTR [rax+0xc0]
  40c13f:	and    eax,0x1
  40c142:	setne  al
  40c145:	add    rsp,0x8
  40c149:	ret
	...

000000000040c160 <__swc_fn_7dafa2b1_000094_335e9a12>:
  40c160:	push   rbx
  40c161:	push   rsi
  40c162:	push   rdi
  40c163:	push   r12
  40c165:	sub    rsp,0x28
  40c169:	mov    rbx,rcx
  40c16c:	call   408900 <__swc_fn_7dafa2b1_000093_344f5089>
  40c171:	mov    rcx,QWORD PTR [rip+0x19bc8]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40c178:	test   rcx,rcx
  40c17b:	jne    40c18d <__swc_fn_7dafa2b1_000094_335e9a12+0x2d>
  40c17d:	call   40a1a0 <__swc_fn_7dafa2b1_000165_e09accff>
  40c182:	lea    rcx,[rax+0x1]
  40c186:	mov    QWORD PTR [rip+0x19bb3],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40c18d:	dec    rcx
  40c190:	call   4118a0 <__swc_fn_7dafa2b1_000167_3130645d>
  40c195:	mov    rsi,rax
  40c198:	lea    rcx,[rsp+0x8]
  40c19d:	call   40eff0 <__swc_fn_7dafa2b1_000092_17e20532>
  40c1a2:	mov    rdi,QWORD PTR [rsi+0x9c0]
  40c1a9:	mov    r12,QWORD PTR [rsi+0xbe8]
  40c1b0:	lea    rcx,[rsi+0x10]
  40c1b4:	call   40d130 <__swc_fn_7dafa2b1_000157_5c8b11d8>
  40c1b9:	mov    rcx,rsi
  40c1bc:	call   40f160 <__swc_fn_7dafa2b1_000101_295ddd7c>
  40c1c1:	vxorps xmm0,xmm0,xmm0
  40c1c5:	xor    eax,eax
  40c1c7:	cs nop WORD PTR [rax+rax*1+0x0]
  40c1d1:	cs nop WORD PTR [rax+rax*1+0x0]
  40c1db:	nop    DWORD PTR [rax+rax*1+0x0]
  40c1e0:	vmovdqu XMMWORD PTR [rsi+rax*1],xmm0
  40c1e5:	add    rax,0x10
  40c1e9:	cmp    rax,0xbf0
  40c1f0:	jne    40c1e0 <__swc_fn_7dafa2b1_000094_335e9a12+0x80>
  40c1f2:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c1f8:	vmovups XMMWORD PTR [rsi],xmm0
  40c1fc:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40c202:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40c20a:	mov    QWORD PTR [rsi+0x9c0],rdi
  40c211:	mov    QWORD PTR [rsi+0xbe8],r12
  40c218:	mov    rcx,QWORD PTR [rip+0x19b21]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40c21f:	test   rcx,rcx
  40c222:	jne    40c234 <__swc_fn_7dafa2b1_000094_335e9a12+0xd4>
  40c224:	call   40a1a0 <__swc_fn_7dafa2b1_000165_e09accff>
  40c229:	lea    rcx,[rax+0x1]
  40c22d:	mov    QWORD PTR [rip+0x19b0c],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40c234:	dec    rcx
  40c237:	call   4118a0 <__swc_fn_7dafa2b1_000167_3130645d>
  40c23c:	mov    rsi,rax
  40c23f:	mov    QWORD PTR [rsi+0xc0],rbx
  40c246:	and    ebx,0x1
  40c249:	jne    40c24d <__swc_fn_7dafa2b1_000094_335e9a12+0xed>
  40c24b:	xor    eax,eax
  40c24d:	test   rbx,rbx
  40c250:	sete   al
  40c253:	xor    cl,cl
  40c255:	xor    dl,dl
  40c257:	xor    r8b,r8b
  40c25a:	xor    r9b,r9b
  40c25d:	xor    r10b,r10b
  40c260:	mov    r11,rax
  40c263:	call   40e9b0 <__swc_fn_7dafa2b1_000077_e793b5e1>
  40c268:	lea    rbx,[rsp+0x18]
  40c26d:	mov    rcx,rbx
  40c270:	call   40eff0 <__swc_fn_7dafa2b1_000092_17e20532>
  40c275:	lea    rcx,[rsi+0x10]
  40c279:	mov    edx,0x400000
  40c27e:	mov    r8,rbx
  40c281:	call   409ee0 <__swc_fn_7dafa2b1_000159_9d602c76>
  40c286:	lea    rcx,[rsi+0x68]
  40c28a:	mov    edx,0x4000
  40c28f:	mov    r8,rbx
  40c292:	call   409ee0 <__swc_fn_7dafa2b1_000159_9d602c76>
  40c297:	add    rsp,0x28
  40c29b:	pop    r12
  40c29d:	pop    rdi
  40c29e:	pop    rsi
  40c29f:	pop    rbx
  40c2a0:	ret
	...

000000000040c2b0 <__swc_fn_7dafa2b1_000097_8b4a07e9>:
  40c2b0:	push   rbx
  40c2b1:	push   rsi
  40c2b2:	sub    rsp,0x18
  40c2b6:	mov    rbx,rcx
  40c2b9:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40c2be:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40c2c4:	mov    rsi,QWORD PTR [rbx+0x70]
  40c2c8:	lea    rcx,[rcx+0x18]
  40c2cc:	call   40d130 <__swc_fn_7dafa2b1_000157_5c8b11d8>
  40c2d1:	lea    rcx,[rsp+0x8]
  40c2d6:	mov    rdx,rbx
  40c2d9:	mov    r8d,0x78
  40c2df:	call   408960 <__swc_fn_7dafa2b1_000096_f879630a>
  40c2e4:	mov    rax,rsi
  40c2e7:	add    rsp,0x18
  40c2eb:	pop    rsi
  40c2ec:	pop    rbx
  40c2ed:	ret
	...

000000000040c2f0 <__swc_fn_7dafa2b1_000100_2ef16a3e>:
  40c2f0:	push   rsi
  40c2f1:	push   rdi
  40c2f2:	sub    rsp,0x8
  40c2f6:	cmp    QWORD PTR [rcx],0x0
  40c2fa:	jne    40c303 <__swc_fn_7dafa2b1_000100_2ef16a3e+0x13>
  40c2fc:	add    rsp,0x8
  40c300:	pop    rdi
  40c301:	pop    rsi
  40c302:	ret
  40c303:	mov    rsi,QWORD PTR [rcx]
  40c306:	mov    rax,QWORD PTR [rcx+0x8]
  40c30a:	test   rax,rax
  40c30d:	je     40c323 <__swc_fn_7dafa2b1_000100_2ef16a3e+0x33>
  40c30f:	test   DWORD PTR [rax+0x28],0x400000
  40c316:	je     40c323 <__swc_fn_7dafa2b1_000100_2ef16a3e+0x33>
  40c318:	mov    rcx,QWORD PTR [rax+0x30]
  40c31c:	test   rcx,rcx
  40c31f:	cmovne rax,rcx
  40c323:	lea    rdx,[rip+0x5ea6]        # 4121d0 <__swc_rdata_base_7dafa2b1+0xc0>
  40c32a:	lea    rcx,[rip+0x5f87]        # 4122b8 <__swc_rdata_base_7dafa2b1+0x1a8>
  40c331:	mov    r8,rax
  40c334:	xor    r9d,r9d
  40c337:	xor    al,al
  40c339:	mov    r10,rax
  40c33c:	xor    r11d,r11d
  40c33f:	call   40c0f0 <__swc_fn_7dafa2b1_000088_17711411>
  40c344:	test   rax,rax
  40c347:	je     40c357 <__swc_fn_7dafa2b1_000100_2ef16a3e+0x67>
  40c349:	mov    rdi,QWORD PTR [rax+0x48]
  40c34d:	test   rdi,rdi
  40c350:	je     40c357 <__swc_fn_7dafa2b1_000100_2ef16a3e+0x67>
  40c352:	mov    rcx,rsi
  40c355:	call   rdi
  40c357:	add    rsp,0x8
  40c35b:	pop    rdi
  40c35c:	pop    rsi
  40c35d:	ret
	...

000000000040c360 <__swc_fn_7dafa2b1_000103_2ed36338>:
  40c360:	push   rbx
  40c361:	push   rsi
  40c362:	push   rdi
  40c363:	sub    rsp,0x20
  40c367:	mov    rbx,rdx
  40c36a:	mov    rsi,rcx
  40c36d:	mov    rcx,QWORD PTR [rip+0x199cc]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40c374:	test   rcx,rcx
  40c377:	jne    40c389 <__swc_fn_7dafa2b1_000103_2ed36338+0x29>
  40c379:	call   40a1a0 <__swc_fn_7dafa2b1_000165_e09accff>
  40c37e:	lea    rcx,[rax+0x1]
  40c382:	mov    QWORD PTR [rip+0x199b7],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40c389:	dec    rcx
  40c38c:	call   4118a0 <__swc_fn_7dafa2b1_000167_3130645d>
  40c391:	mov    rdi,rax
  40c394:	mov    rax,QWORD PTR [rdi+0xbd0]
  40c39b:	xor    ecx,ecx
  40c39d:	test   rax,rax
  40c3a0:	je     40c3a5 <__swc_fn_7dafa2b1_000103_2ed36338+0x45>
  40c3a2:	mov    rcx,QWORD PTR [rax]
  40c3a5:	call   40a2d0 <__swc_fn_7dafa2b1_000174_738eec22>
  40c3aa:	lea    rax,[rsp+0x8]
  40c3af:	lea    rcx,[rdi+0x9c8]
  40c3b6:	mov    QWORD PTR [rsp+0x8],rcx
  40c3bb:	mov    QWORD PTR [rax+0x8],0x40
  40c3c3:	xor    ecx,ecx
  40c3c5:	mov    rdx,rax
  40c3c8:	call   40fc00 <__swc_fn_7dafa2b1_000119_18cd3882>
  40c3cd:	mov    DWORD PTR [rdi+0xbc8],eax
  40c3d3:	mov    rdi,QWORD PTR [rdi+0x990]
  40c3da:	test   rdi,rdi
  40c3dd:	je     40c3e7 <__swc_fn_7dafa2b1_000103_2ed36338+0x87>
  40c3df:	mov    rcx,rsi
  40c3e2:	mov    rdx,rbx
  40c3e5:	call   rdi
  40c3e7:	call   40c110 <__swc_fn_7dafa2b1_000091_e6773530>
  40c3ec:	test   al,al
  40c3ee:	je     40c3fe <__swc_fn_7dafa2b1_000103_2ed36338+0x9e>
  40c3f0:	mov    rcx,rsi
  40c3f3:	mov    rdx,rbx
  40c3f6:	xor    r8d,r8d
  40c3f9:	call   4093e0 <__swc_fn_7dafa2b1_000120_1601f378>
  40c3fe:	mov    rcx,rsi
  40c401:	mov    rdx,rbx
  40c404:	call   408a60 <__swc_fn_7dafa2b1_000102_29a1093a>
  40c409:	call   40c990 <__swc_fn_7dafa2b1_000118_2b35b5e0>
  40c40e:	add    rsp,0x20
  40c412:	pop    rdi
  40c413:	pop    rsi
  40c414:	pop    rbx
  40c415:	ret
	...

000000000040c420 <__swc_fn_7dafa2b1_000106_77a5d54a>:
  40c420:	test   r8,r8
  40c423:	jne    40c428 <__swc_fn_7dafa2b1_000106_77a5d54a+0x8>
  40c425:	xor    eax,eax
  40c427:	ret
  40c428:	xor    eax,eax
  40c42a:	nop    WORD PTR [rax+rax*1+0x0]
  40c430:	mov    r9,r8
  40c433:	sub    r9,rax
  40c436:	cmp    r9,0x10
  40c43a:	jb     40c484 <__swc_fn_7dafa2b1_000106_77a5d54a+0x64>
  40c43c:	lea    r9,[rcx+rax*1]
  40c440:	lea    r10,[rdx+rax*1]
  40c444:	vmovups xmm0,XMMWORD PTR [r10]
  40c449:	vmovups xmm1,XMMWORD PTR [r9]
  40c44e:	vpcmpeqb xmm0,xmm1,xmm0
  40c452:	vpmovmskb r9d,xmm0
  40c456:	cmp    r9d,0xffff
  40c45d:	je     40c47e <__swc_fn_7dafa2b1_000106_77a5d54a+0x5e>
  40c45f:	not    r9d
  40c462:	xor    r8d,r8d
  40c465:	movzx  r9d,r9w
  40c469:	tzcnt  r8d,r9d
  40c46e:	add    rax,r8
  40c471:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c475:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c479:	sub    ecx,eax
  40c47b:	mov    eax,ecx
  40c47d:	ret
  40c47e:	lea    rax,[rax+0x10]
  40c482:	jmp    40c430 <__swc_fn_7dafa2b1_000106_77a5d54a+0x10>
  40c484:	cmp    r9,0x8
  40c488:	jb     40c4fb <__swc_fn_7dafa2b1_000106_77a5d54a+0xdb>
  40c48a:	lea    r9,[rcx+rax*1]
  40c48e:	lea    r10,[rdx+rax*1]
  40c492:	mov    r9,QWORD PTR [r9]
  40c495:	xor    r9,QWORD PTR [r10]
  40c498:	test   r9,r9
  40c49b:	je     40c4b9 <__swc_fn_7dafa2b1_000106_77a5d54a+0x99>
  40c49d:	xor    r8d,r8d
  40c4a0:	tzcnt  r8,r9
  40c4a5:	shr    r8,0x3
  40c4a9:	add    rax,r8
  40c4ac:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4b0:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4b4:	sub    ecx,eax
  40c4b6:	mov    eax,ecx
  40c4b8:	ret
  40c4b9:	lea    rax,[rax+0x8]
  40c4bd:	cmp    rax,r8
  40c4c0:	jne    40c4c5 <__swc_fn_7dafa2b1_000106_77a5d54a+0xa5>
  40c4c2:	xor    eax,eax
  40c4c4:	ret
  40c4c5:	lea    rax,[r8-0x8]
  40c4c9:	lea    r8,[rcx+rax*1]
  40c4cd:	lea    r9,[rdx+rax*1]
  40c4d1:	mov    r8,QWORD PTR [r8]
  40c4d4:	xor    r8,QWORD PTR [r9]
  40c4d7:	test   r8,r8
  40c4da:	je     40c4f8 <__swc_fn_7dafa2b1_000106_77a5d54a+0xd8>
  40c4dc:	xor    r9d,r9d
  40c4df:	tzcnt  r9,r8
  40c4e4:	shr    r9,0x3
  40c4e8:	add    rax,r9
  40c4eb:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c4ef:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c4f3:	sub    ecx,eax
  40c4f5:	mov    eax,ecx
  40c4f7:	ret
  40c4f8:	xor    eax,eax
  40c4fa:	ret
  40c4fb:	cmp    r9,0x4
  40c4ff:	jb     40c572 <__swc_fn_7dafa2b1_000106_77a5d54a+0x152>
  40c501:	lea    r9,[rcx+rax*1]
  40c505:	lea    r10,[rdx+rax*1]
  40c509:	mov    r9d,DWORD PTR [r9]
  40c50c:	xor    r9d,DWORD PTR [r10]
  40c50f:	test   r9d,r9d
  40c512:	je     40c530 <__swc_fn_7dafa2b1_000106_77a5d54a+0x110>
  40c514:	xor    r8d,r8d
  40c517:	tzcnt  r8,r9
  40c51c:	shr    r8,0x3
  40c520:	add    rax,r8
  40c523:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c527:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c52b:	sub    ecx,eax
  40c52d:	mov    eax,ecx
  40c52f:	ret
  40c530:	lea    rax,[rax+0x4]
  40c534:	cmp    rax,r8
  40c537:	jne    40c53c <__swc_fn_7dafa2b1_000106_77a5d54a+0x11c>
  40c539:	xor    eax,eax
  40c53b:	ret
  40c53c:	lea    rax,[r8-0x4]
  40c540:	lea    r8,[rcx+rax*1]
  40c544:	lea    r9,[rdx+rax*1]
  40c548:	mov    r8d,DWORD PTR [r8]
  40c54b:	xor    r8d,DWORD PTR [r9]
  40c54e:	test   r8d,r8d
  40c551:	je     40c56f <__swc_fn_7dafa2b1_000106_77a5d54a+0x14f>
  40c553:	xor    r9d,r9d
  40c556:	tzcnt  r9,r8
  40c55b:	shr    r9,0x3
  40c55f:	add    rax,r9
  40c562:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c566:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c56a:	sub    ecx,eax
  40c56c:	mov    eax,ecx
  40c56e:	ret
  40c56f:	xor    eax,eax
  40c571:	ret
  40c572:	cmp    r9,0x2
  40c576:	jb     40c5c9 <__swc_fn_7dafa2b1_000106_77a5d54a+0x1a9>
  40c578:	lea    r9,[rcx+rax*1]
  40c57c:	lea    r10,[rdx+rax*1]
  40c580:	mov    r9w,WORD PTR [r9]
  40c584:	xor    r9w,WORD PTR [r10]
  40c588:	test   r9w,r9w
  40c58c:	je     40c5ae <__swc_fn_7dafa2b1_000106_77a5d54a+0x18e>
  40c58e:	xor    r8d,r8d
  40c591:	movzx  r9d,r9w
  40c595:	tzcnt  r8,r9
  40c59a:	shr    r8,0x3
  40c59e:	add    rax,r8
  40c5a1:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c5a5:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c5a9:	sub    ecx,eax
  40c5ab:	mov    eax,ecx
  40c5ad:	ret
  40c5ae:	lea    rax,[rax+0x2]
  40c5b2:	cmp    rax,r8
  40c5b5:	jne    40c5ba <__swc_fn_7dafa2b1_000106_77a5d54a+0x19a>
  40c5b7:	xor    eax,eax
  40c5b9:	ret
  40c5ba:	movzx  eax,BYTE PTR [rcx+r8*1-0x1]
  40c5c0:	movzx  ecx,BYTE PTR [rdx+r8*1-0x1]
  40c5c6:	sub    eax,ecx
  40c5c8:	ret
  40c5c9:	test   r9,r9
  40c5cc:	je     40c5db <__swc_fn_7dafa2b1_000106_77a5d54a+0x1bb>
  40c5ce:	movzx  ecx,BYTE PTR [rcx+rax*1]
  40c5d2:	movzx  eax,BYTE PTR [rdx+rax*1]
  40c5d6:	sub    ecx,eax
  40c5d8:	mov    eax,ecx
  40c5da:	ret
  40c5db:	xor    eax,eax
  40c5dd:	ret
	...

000000000040c5e0 <__swc_fn_7dafa2b1_000109_aa570b2b>:
  40c5e0:	push   r12
  40c5e2:	push   r13
  40c5e4:	push   r14
  40c5e6:	push   rdi
  40c5e7:	push   rsi
  40c5e8:	push   r15
  40c5ea:	sub    rsp,0xd8
  40c5f1:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c5f7:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c5fd:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c603:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c609:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c60f:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c618:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c621:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c62a:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c633:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c63c:	mov    r12,rcx
  40c63f:	test   rcx,rcx
  40c642:	je     40c65e <__swc_fn_7dafa2b1_000109_aa570b2b+0x7e>
  40c644:	mov    eax,r12d
  40c647:	and    eax,0xfff
  40c64d:	setne  al
  40c650:	cmp    r12,0xffffffffffffefff
  40c657:	seta   cl
  40c65a:	or     al,cl
  40c65c:	je     40c665 <__swc_fn_7dafa2b1_000109_aa570b2b+0x85>
  40c65e:	xor    eax,eax
  40c660:	jmp    40c6fb <__swc_fn_7dafa2b1_000109_aa570b2b+0x11b>
  40c665:	call   409100 <__swc_fn_7dafa2b1_000108_32416b9e>
  40c66a:	mov    r13,rax
  40c66d:	test   rax,rax
  40c670:	jne    40c679 <__swc_fn_7dafa2b1_000109_aa570b2b+0x99>
  40c672:	xor    eax,eax
  40c674:	jmp    40c6fb <__swc_fn_7dafa2b1_000109_aa570b2b+0x11b>
  40c679:	lea    r14,[r12+0x1000]
  40c681:	xor    edi,edi
  40c683:	mov    rsi,r14
  40c686:	xor    edx,edx
  40c688:	mov    ecx,0x22
  40c68d:	mov    eax,0xffffffff
  40c692:	movsxd r8,eax
  40c695:	xor    r9d,r9d
  40c698:	xor    eax,eax
  40c69a:	call   4070c0 <mmap@plt>
  40c69f:	mov    r15,rax
  40c6a2:	cmp    rax,0xffffffffffffffff
  40c6a6:	jne    40c6ac <__swc_fn_7dafa2b1_000109_aa570b2b+0xcc>
  40c6a8:	xor    eax,eax
  40c6aa:	jmp    40c6fb <__swc_fn_7dafa2b1_000109_aa570b2b+0x11b>
  40c6ac:	mov    rdi,r15
  40c6af:	mov    esi,0x1000
  40c6b4:	mov    edx,0x3
  40c6b9:	xor    eax,eax
  40c6bb:	call   407030 <mprotect@plt>
  40c6c0:	test   eax,eax
  40c6c2:	je     40c6d5 <__swc_fn_7dafa2b1_000109_aa570b2b+0xf5>
  40c6c4:	mov    rdi,r15
  40c6c7:	mov    rsi,r14
  40c6ca:	xor    eax,eax
  40c6cc:	call   407020 <munmap@plt>
  40c6d1:	xor    eax,eax
  40c6d3:	jmp    40c6fb <__swc_fn_7dafa2b1_000109_aa570b2b+0x11b>
  40c6d5:	mov    QWORD PTR [r15+0x8],r12
  40c6d9:	mov    rcx,r13
  40c6dc:	call   40cd30 <__swc_fn_7dafa2b1_000133_c6de0049>
  40c6e1:	mov    rax,QWORD PTR [r13+0x8]
  40c6e5:	mov    QWORD PTR [r15],rax
  40c6e8:	mov    QWORD PTR [r13+0x8],r15
  40c6ec:	mov    rcx,r13
  40c6ef:	call   40ffa0 <__swc_fn_7dafa2b1_000134_5696c87e>
  40c6f4:	lea    rax,[r15+0x1000]
  40c6fb:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c701:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c707:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c70d:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c713:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c719:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c722:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c72b:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c734:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c73d:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c746:	add    rsp,0xd8
  40c74d:	pop    r15
  40c74f:	pop    rsi
  40c750:	pop    rdi
  40c751:	pop    r14
  40c753:	pop    r13
  40c755:	pop    r12
  40c757:	ret
	...

000000000040c760 <__swc_fn_7dafa2b1_000112_cb2656be>:
  40c760:	push   rbx
  40c761:	push   r12
  40c763:	push   rdi
  40c764:	push   rsi
  40c765:	sub    rsp,0xa8
  40c76c:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c772:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c778:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c77e:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c784:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c78a:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c790:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40c796:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40c79c:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40c7a5:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40c7ae:	mov    rbx,rdx
  40c7b1:	mov    r12,rcx
  40c7b4:	mov    rdi,rcx
  40c7b7:	mov    rsi,rdx
  40c7ba:	xor    edx,edx
  40c7bc:	xor    eax,eax
  40c7be:	call   407030 <mprotect@plt>
  40c7c3:	test   eax,eax
  40c7c5:	jne    40c7e9 <__swc_fn_7dafa2b1_000112_cb2656be+0x89>
  40c7c7:	mov    rcx,r12
  40c7ca:	mov    rdx,rbx
  40c7cd:	xor    al,al
  40c7cf:	mov    r8,rax
  40c7d2:	call   40fa40 <__swc_fn_7dafa2b1_000110_e606239a>
  40c7d7:	mov    rdi,r12
  40c7da:	mov    rsi,rbx
  40c7dd:	mov    edx,0x4
  40c7e2:	xor    eax,eax
  40c7e4:	call   4070e0 <madvise@plt>
  40c7e9:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40c7ef:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40c7f5:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40c7fb:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40c801:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40c807:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40c80d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40c813:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40c819:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40c822:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40c82b:	add    rsp,0xa8
  40c832:	pop    rsi
  40c833:	pop    rdi
  40c834:	pop    r12
  40c836:	pop    rbx
  40c837:	ret
	...

000000000040c840 <__swc_fn_7dafa2b1_000115_259b5d5a>:
  40c840:	push   rsi
  40c841:	push   rdi
  40c842:	push   r12
  40c844:	push   r13
  40c846:	push   r14
  40c848:	sub    rsp,0xe0
  40c84f:	vmovups XMMWORD PTR [rsp+0x38],xmm6
  40c855:	vmovups XMMWORD PTR [rsp+0x48],xmm7
  40c85b:	vmovups XMMWORD PTR [rsp+0x58],xmm8
  40c861:	vmovups XMMWORD PTR [rsp+0x68],xmm9
  40c867:	vmovups XMMWORD PTR [rsp+0x78],xmm10
  40c86d:	vmovups XMMWORD PTR [rsp+0x88],xmm11
  40c876:	vmovups XMMWORD PTR [rsp+0x98],xmm12
  40c87f:	vmovups XMMWORD PTR [rsp+0xa8],xmm13
  40c888:	vmovups XMMWORD PTR [rsp+0xb8],xmm14
  40c891:	vmovups XMMWORD PTR [rsp+0xc8],xmm15
  40c89a:	mov    rsi,rdx
  40c89d:	mov    rdi,rcx
  40c8a0:	call   409100 <__swc_fn_7dafa2b1_000108_32416b9e>
  40c8a5:	mov    r12,rax
  40c8a8:	test   rax,rax
  40c8ab:	jne    40c8b2 <__swc_fn_7dafa2b1_000115_259b5d5a+0x72>
  40c8ad:	jmp    40c926 <__swc_fn_7dafa2b1_000115_259b5d5a+0xe6>
  40c8b2:	mov    rcx,r12
  40c8b5:	call   40cd30 <__swc_fn_7dafa2b1_000133_c6de0049>
  40c8ba:	lea    r13,[r12+0x8]
  40c8bf:	mov    rax,QWORD PTR [r13+0x0]
  40c8c3:	test   rax,rax
  40c8c6:	je     40c91e <__swc_fn_7dafa2b1_000115_259b5d5a+0xde>
  40c8c8:	nop    DWORD PTR [rax+rax*1+0x0]
  40c8d0:	lea    rcx,[rax+0x1000]
  40c8d7:	cmp    rcx,rdi
  40c8da:	jne    40c912 <__swc_fn_7dafa2b1_000115_259b5d5a+0xd2>
  40c8dc:	cmp    QWORD PTR [rax+0x8],rsi
  40c8e0:	je     40c8ec <__swc_fn_7dafa2b1_000115_259b5d5a+0xac>
  40c8e2:	mov    rcx,r12
  40c8e5:	call   40ffa0 <__swc_fn_7dafa2b1_000134_5696c87e>
  40c8ea:	jmp    40c926 <__swc_fn_7dafa2b1_000115_259b5d5a+0xe6>
  40c8ec:	mov    r14,QWORD PTR [rax]
  40c8ef:	mov    rdi,rax
  40c8f2:	lea    rsi,[rsi+0x1000]
  40c8f9:	xor    eax,eax
  40c8fb:	call   407020 <munmap@plt>
  40c900:	test   eax,eax
  40c902:	jne    40c908 <__swc_fn_7dafa2b1_000115_259b5d5a+0xc8>
  40c904:	mov    QWORD PTR [r13+0x0],r14
  40c908:	mov    rcx,r12
  40c90b:	call   40ffa0 <__swc_fn_7dafa2b1_000134_5696c87e>
  40c910:	jmp    40c926 <__swc_fn_7dafa2b1_000115_259b5d5a+0xe6>
  40c912:	mov    r13,rax
  40c915:	mov    rax,QWORD PTR [r13+0x0]
  40c919:	test   rax,rax
  40c91c:	jne    40c8d0 <__swc_fn_7dafa2b1_000115_259b5d5a+0x90>
  40c91e:	mov    rcx,r12
  40c921:	call   40ffa0 <__swc_fn_7dafa2b1_000134_5696c87e>
  40c926:	vmovups xmm6,XMMWORD PTR [rsp+0x38]
  40c92c:	vmovups xmm7,XMMWORD PTR [rsp+0x48]
  40c932:	vmovups xmm8,XMMWORD PTR [rsp+0x58]
  40c938:	vmovups xmm9,XMMWORD PTR [rsp+0x68]
  40c93e:	vmovups xmm10,XMMWORD PTR [rsp+0x78]
  40c944:	vmovups xmm11,XMMWORD PTR [rsp+0x88]
  40c94d:	vmovups xmm12,XMMWORD PTR [rsp+0x98]
  40c956:	vmovups xmm13,XMMWORD PTR [rsp+0xa8]
  40c95f:	vmovups xmm14,XMMWORD PTR [rsp+0xb8]
  40c968:	vmovups xmm15,XMMWORD PTR [rsp+0xc8]
  40c971:	add    rsp,0xe0
  40c978:	pop    r14
  40c97a:	pop    r13
  40c97c:	pop    r12
  40c97e:	pop    rdi
  40c97f:	pop    rsi
  40c980:	ret
	...

000000000040c990 <__swc_fn_7dafa2b1_000118_2b35b5e0>:
  40c990:	push   rdi
  40c991:	push   rsi
  40c992:	sub    rsp,0xa8
  40c999:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40c99f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40c9a5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40c9ab:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40c9b1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40c9b7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40c9bd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40c9c3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40c9c9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40c9d2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40c9db:	mov    rdi,0xfffffffffffffd66
  40c9e2:	xor    eax,eax
  40c9e4:	call   407040 <exit@plt>
  40c9e9:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40c9ef:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40c9f5:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40c9fb:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ca01:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ca07:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ca0d:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ca13:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40ca19:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ca22:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ca2b:	add    rsp,0xa8
  40ca32:	pop    rsi
  40ca33:	pop    rdi
  40ca34:	ret
	...

000000000040ca40 <__swc_fn_7dafa2b1_000121_71a5b1cd>:
  40ca40:	push   rbx
  40ca41:	push   rsi
  40ca42:	push   rdi
  40ca43:	sub    rsp,0x30
  40ca47:	mov    rbx,rdx
  40ca4a:	mov    esi,ecx
  40ca4c:	test   ecx,ecx
  40ca4e:	je     40cb23 <__swc_fn_7dafa2b1_000121_71a5b1cd+0xe3>
  40ca54:	mov    rcx,rsi
  40ca57:	shl    rcx,0x4
  40ca5b:	call   40bf50 <__swc_fn_7dafa2b1_000079_29fad089>
  40ca60:	test   rax,rax
  40ca63:	je     40cb12 <__swc_fn_7dafa2b1_000121_71a5b1cd+0xd2>
  40ca69:	mov    rcx,rsi
  40ca6c:	xor    edx,edx
  40ca6e:	test   rsi,rsi
  40ca71:	jbe    40caf2 <__swc_fn_7dafa2b1_000121_71a5b1cd+0xb2>
  40ca77:	nop    WORD PTR [rax+rax*1+0x0]
  40ca80:	mov    r8d,edx
  40ca83:	mov    r9,QWORD PTR [rbx+r8*8]
  40ca87:	add    r8,r8
  40ca8a:	lea    r8,[rax+r8*8]
  40ca8e:	xor    r10d,r10d
  40ca91:	test   r9,r9
  40ca94:	je     40cad0 <__swc_fn_7dafa2b1_000121_71a5b1cd+0x90>
  40ca96:	mov    r11,r9
  40ca99:	mov    dil,BYTE PTR [r11]
  40ca9c:	test   dil,dil
  40ca9f:	je     40cad0 <__swc_fn_7dafa2b1_000121_71a5b1cd+0x90>
  40caa1:	cs nop WORD PTR [rax+rax*1+0x0]
  40caab:	cs nop WORD PTR [rax+rax*1+0x0]
  40cab5:	cs nop WORD PTR [rax+rax*1+0x0]
  40cabf:	nop
  40cac0:	add    r11,0x1
  40cac4:	add    r10,0x1
  40cac8:	mov    dil,BYTE PTR [r11]
  40cacb:	test   dil,dil
  40cace:	jne    40cac0 <__swc_fn_7dafa2b1_000121_71a5b1cd+0x80>
  40cad0:	mov    QWORD PTR [rsp+0x18],r9
  40cad5:	mov    QWORD PTR [rsp+0x20],r10
  40cada:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  40cae0:	vmovups XMMWORD PTR [r8],xmm0
  40cae5:	add    rdx,0x1
  40cae9:	cmp    rdx,rcx
  40caec:	jb     40ca80 <__swc_fn_7dafa2b1_000121_71a5b1cd+0x40>
  40caf2:	lea    rcx,[rip+0x19257]        # 425d50 <__swc_bss_base_7dafa2b1+0x2d10>
  40caf9:	mov    QWORD PTR [rsp+0x8],rax
  40cafe:	mov    esi,esi
  40cb00:	mov    QWORD PTR [rsp+0x10],rsi
  40cb05:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40cb0b:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40cb10:	jmp    40cb23 <__swc_fn_7dafa2b1_000121_71a5b1cd+0xe3>
  40cb12:	lea    rcx,[rip+0x5a07]        # 412520 <__swc_rdata_base_7dafa2b1+0x410>
  40cb19:	call   40faf0 <__swc_fn_7dafa2b1_000116_3499f7d6>
  40cb1e:	call   40c990 <__swc_fn_7dafa2b1_000118_2b35b5e0>
  40cb23:	add    rsp,0x30
  40cb27:	pop    rdi
  40cb28:	pop    rsi
  40cb29:	pop    rbx
  40cb2a:	ret
  40cb2b:	add    BYTE PTR [rax],al
  40cb2d:	add    BYTE PTR [rax],al
	...

000000000040cb30 <__swc_fn_7dafa2b1_000124_df97aa0a>:
  40cb30:	push   rdi
  40cb31:	push   rsi
  40cb32:	sub    rsp,0xa8
  40cb39:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cb3f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cb45:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cb4b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cb51:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cb57:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cb5d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cb63:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cb69:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cb72:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cb7b:	mov    edi,ecx
  40cb7d:	xor    eax,eax
  40cb7f:	call   4070f0 <pthread_key_delete@plt>
  40cb84:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cb8a:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cb90:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cb96:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cb9c:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cba2:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cba8:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cbae:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cbb4:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cbbd:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cbc6:	add    rsp,0xa8
  40cbcd:	pop    rsi
  40cbce:	pop    rdi
  40cbcf:	ret

000000000040cbd0 <__swc_fn_7dafa2b1_000127_75f8ab5c>:
  40cbd0:	push   rdi
  40cbd1:	push   rsi
  40cbd2:	sub    rsp,0xa8
  40cbd9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cbdf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cbe5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cbeb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cbf1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cbf7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40cbfd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40cc03:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40cc09:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40cc12:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cc1b:	test   rcx,rcx
  40cc1e:	je     40cc2f <__swc_fn_7dafa2b1_000127_75f8ab5c+0x5f>
  40cc20:	lea    rax,[rcx-0x1]
  40cc24:	mov    eax,eax
  40cc26:	mov    edi,eax
  40cc28:	xor    eax,eax
  40cc2a:	call   4070f0 <pthread_key_delete@plt>
  40cc2f:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40cc35:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cc3b:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cc41:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cc47:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40cc4d:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cc53:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cc59:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cc5f:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cc68:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cc71:	add    rsp,0xa8
  40cc78:	pop    rsi
  40cc79:	pop    rdi
  40cc7a:	ret
  40cc7b:	add    BYTE PTR [rax],al
  40cc7d:	add    BYTE PTR [rax],al
	...

000000000040cc80 <__swc_fn_7dafa2b1_000130_d2d78689>:
  40cc80:	push   rsi
  40cc81:	push   rdi
  40cc82:	sub    rsp,0xa8
  40cc89:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40cc8f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40cc95:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40cc9b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40cca1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40cca7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40ccad:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ccb3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ccb9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ccc2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40cccb:	xor    eax,eax
  40cccd:	call   407100 <gettid@plt>
  40ccd2:	movsxd rax,eax
  40ccd5:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ccdb:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cce1:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cce7:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40cced:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ccf3:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40ccf9:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40ccff:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cd05:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40cd0e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40cd17:	add    rsp,0xa8
  40cd1e:	pop    rdi
  40cd1f:	pop    rsi
  40cd20:	ret
	...

000000000040cd30 <__swc_fn_7dafa2b1_000133_c6de0049>:
  40cd30:	push   rbx
  40cd31:	push   rdi
  40cd32:	push   rsi
  40cd33:	sub    rsp,0xc0
  40cd3a:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40cd40:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40cd46:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40cd4c:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40cd52:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40cd58:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40cd5e:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40cd64:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40cd6d:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40cd76:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40cd7f:	mov    rbx,rcx
  40cd82:	cs nop WORD PTR [rax+rax*1+0x0]
  40cd8c:	nop    DWORD PTR [rax+0x0]
  40cd90:	mov    edx,0x80000000
  40cd95:	xor    eax,eax
  40cd97:	lock cmpxchg DWORD PTR [rbx],edx
  40cd9b:	test   eax,eax
  40cd9d:	je     40cdd4 <__swc_fn_7dafa2b1_000133_c6de0049+0xa4>
  40cd9f:	mov    eax,DWORD PTR [rbx]
  40cda1:	lea    rcx,[rsp+0x14]
  40cda6:	mov    DWORD PTR [rsp+0x14],eax
  40cdaa:	test   eax,eax
  40cdac:	je     40cd90 <__swc_fn_7dafa2b1_000133_c6de0049+0x60>
  40cdae:	mov    QWORD PTR [rsp],0x0
  40cdb6:	mov    edi,0xca
  40cdbb:	mov    rsi,rbx
  40cdbe:	mov    edx,0x80
  40cdc3:	mov    ecx,DWORD PTR [rcx]
  40cdc5:	xor    r8d,r8d
  40cdc8:	xor    r9d,r9d
  40cdcb:	xor    eax,eax
  40cdcd:	call   407070 <syscall@plt>
  40cdd2:	jmp    40cd90 <__swc_fn_7dafa2b1_000133_c6de0049+0x60>
  40cdd4:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40cdda:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40cde0:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40cde6:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40cdec:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40cdf2:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40cdf8:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40cdfe:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ce07:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ce10:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ce19:	add    rsp,0xc0
  40ce20:	pop    rsi
  40ce21:	pop    rdi
  40ce22:	pop    rbx
  40ce23:	ret
	...

000000000040ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>:
  40ce30:	sub    rsp,0x8
  40ce34:	call   40ffa0 <__swc_fn_7dafa2b1_000134_5696c87e>
  40ce39:	add    rsp,0x8
  40ce3d:	ret
	...

000000000040ce40 <__swc_fn_7dafa2b1_000139_20e2e2c7>:
  40ce40:	push   rdi
  40ce41:	push   rsi
  40ce42:	sub    rsp,0xa8
  40ce49:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40ce4f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40ce55:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40ce5b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40ce61:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40ce67:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40ce6d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40ce73:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40ce79:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40ce82:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40ce8b:	mov    edi,0x28
  40ce90:	xor    eax,eax
  40ce92:	call   4070d0 <malloc@plt>
  40ce97:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40ce9d:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40cea3:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40cea9:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40ceaf:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40ceb5:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40cebb:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40cec1:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40cec7:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40ced0:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40ced9:	add    rsp,0xa8
  40cee0:	pop    rsi
  40cee1:	pop    rdi
  40cee2:	ret
	...

000000000040cef0 <__swc_fn_7dafa2b1_000142_e0543f36>:
  40cef0:	mov    QWORD PTR [r8],0x0
  40cef7:	cmp    rdx,0x10
  40cefb:	jae    40cf00 <__swc_fn_7dafa2b1_000142_e0543f36+0x10>
  40cefd:	xor    eax,eax
  40ceff:	ret
  40cf00:	mov    eax,DWORD PTR [rcx]
  40cf02:	cmp    eax,0x42445753
  40cf08:	jne    40cf12 <__swc_fn_7dafa2b1_000142_e0543f36+0x22>
  40cf0a:	mov    eax,DWORD PTR [rcx+0x4]
  40cf0d:	cmp    eax,0x1
  40cf10:	je     40cf15 <__swc_fn_7dafa2b1_000142_e0543f36+0x25>
  40cf12:	xor    eax,eax
  40cf14:	ret
  40cf15:	mov    QWORD PTR [r8],rdx
  40cf18:	mov    rax,rcx
  40cf1b:	ret
  40cf1c:	add    BYTE PTR [rax],al
	...

000000000040cf20 <__swc_fn_7dafa2b1_000145_071b4f4c>:
  40cf20:	push   rbx
  40cf21:	sub    rsp,0xe0
  40cf28:	lea    rbx,[rsp+0x8]
  40cf2d:	vxorps xmm0,xmm0,xmm0
  40cf31:	vmovups YMMWORD PTR [rbx],ymm0
  40cf35:	vmovups YMMWORD PTR [rbx+0x20],ymm0
  40cf3a:	vmovups YMMWORD PTR [rbx+0x40],ymm0
  40cf3f:	vzeroupper
  40cf42:	mov    DWORD PTR [rbx+0x60],0x0
  40cf49:	mov    r8,rbx
  40cf4c:	mov    rdx,rcx
  40cf4f:	nop
  40cf50:	mov    r9,rdx
  40cf53:	movabs rdx,0x6666666666666667
  40cf5d:	mov    rax,r9
  40cf60:	imul   rdx
  40cf63:	sar    rdx,0x2
  40cf67:	mov    r10,rdx
  40cf6a:	shr    rdx,0x3f
  40cf6e:	add    r10,rdx
  40cf71:	mov    rdx,r10
  40cf74:	imul   r11,r10,0xa
  40cf78:	sub    r9,r11
  40cf7b:	mov    r11,QWORD PTR [rip+0x55be]        # 412540 <__swc_rdata_base_7dafa2b1+0x430>
  40cf82:	mov    r9b,BYTE PTR [r11+r9*1+0x23]
  40cf87:	mov    BYTE PTR [r8],r9b
  40cf8a:	lea    r9,[r8+0x1]
  40cf8e:	mov    r8,r9
  40cf91:	test   r10,r10
  40cf94:	jne    40cf50 <__swc_fn_7dafa2b1_000145_071b4f4c+0x30>
  40cf96:	test   rcx,rcx
  40cf99:	jge    40cfa3 <__swc_fn_7dafa2b1_000145_071b4f4c+0x83>
  40cf9b:	mov    BYTE PTR [r9],0x2d
  40cf9f:	add    r8,0x1
  40cfa3:	mov    BYTE PTR [r8],0x0
  40cfa7:	sub    r8,0x1
  40cfab:	mov    rax,rbx
  40cfae:	cmp    rax,r8
  40cfb1:	jae    40cfd6 <__swc_fn_7dafa2b1_000145_071b4f4c+0xb6>
  40cfb3:	cs nop WORD PTR [rax+rax*1+0x0]
  40cfbd:	nop    DWORD PTR [rax]
  40cfc0:	mov    cl,BYTE PTR [r8]
  40cfc3:	mov    dl,BYTE PTR [rax]
  40cfc5:	mov    BYTE PTR [r8],dl
  40cfc8:	sub    r8,0x1
  40cfcc:	mov    BYTE PTR [rax],cl
  40cfce:	inc    rax
  40cfd1:	cmp    rax,r8
  40cfd4:	jb     40cfc0 <__swc_fn_7dafa2b1_000145_071b4f4c+0xa0>
  40cfd6:	xor    eax,eax
  40cfd8:	test   rbx,rbx
  40cfdb:	je     40cffe <__swc_fn_7dafa2b1_000145_071b4f4c+0xde>
  40cfdd:	mov    rcx,rbx
  40cfe0:	mov    dl,BYTE PTR [rcx]
  40cfe2:	test   dl,dl
  40cfe4:	je     40cffe <__swc_fn_7dafa2b1_000145_071b4f4c+0xde>
  40cfe6:	cs nop WORD PTR [rax+rax*1+0x0]
  40cff0:	add    rcx,0x1
  40cff4:	add    rax,0x1
  40cff8:	mov    dl,BYTE PTR [rcx]
  40cffa:	test   dl,dl
  40cffc:	jne    40cff0 <__swc_fn_7dafa2b1_000145_071b4f4c+0xd0>
  40cffe:	mov    QWORD PTR [rbx+0xa8],rbx
  40d005:	mov    QWORD PTR [rbx+0xb0],rax
  40d00c:	vmovups xmm0,XMMWORD PTR [rbx+0xa8]
  40d014:	vmovups XMMWORD PTR [rbx+0xb8],xmm0
  40d01c:	lea    rcx,[rbx+0xb8]
  40d023:	call   40faf0 <__swc_fn_7dafa2b1_000116_3499f7d6>
  40d028:	add    rsp,0xe0
  40d02f:	pop    rbx
  40d030:	ret
	...

000000000040d040 <__swc_fn_7dafa2b1_000148_33e5e24f>:
  40d040:	vxorps xmm0,xmm0,xmm0
  40d044:	vmovups XMMWORD PTR [rcx],xmm0
  40d048:	mov    QWORD PTR [rcx+0x10],0x0
  40d050:	ret
	...

000000000040d060 <__swc_fn_7dafa2b1_000151_33e5e24f>:
  40d060:	vxorps xmm0,xmm0,xmm0
  40d064:	vmovups XMMWORD PTR [rcx],xmm0
  40d068:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d06d:	vxorps xmm0,xmm0,xmm0
  40d071:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d076:	vmovups xmm0,XMMWORD PTR [rip+0x55ba]        # 412638 <__swc_rdata_base_7dafa2b1+0x528>
  40d07e:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d083:	vxorps xmm0,xmm0,xmm0
  40d087:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d08c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d091:	mov    QWORD PTR [rcx+0x60],0x0
  40d099:	ret
  40d09a:	add    BYTE PTR [rax],al
  40d09c:	add    BYTE PTR [rax],al
	...

000000000040d0a0 <__swc_fn_7dafa2b1_000154_33e5e24f>:
  40d0a0:	vxorps xmm0,xmm0,xmm0
  40d0a4:	vmovups XMMWORD PTR [rcx],xmm0
  40d0a8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40d0ad:	vxorps xmm0,xmm0,xmm0
  40d0b1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40d0b6:	vmovups xmm0,XMMWORD PTR [rip+0x56a2]        # 412760 <__swc_rdata_base_7dafa2b1+0x650>
  40d0be:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40d0c3:	vxorps xmm0,xmm0,xmm0
  40d0c7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40d0cc:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40d0d1:	vxorps xmm0,xmm0,xmm0
  40d0d5:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40d0da:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40d0df:	vxorps xmm0,xmm0,xmm0
  40d0e3:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40d0eb:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40d0f3:	vxorps xmm0,xmm0,xmm0
  40d0f7:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40d0ff:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40d107:	vxorps xmm0,xmm0,xmm0
  40d10b:	vmovups XMMWORD PTR [rcx+0xc0],xmm0
  40d113:	vmovups XMMWORD PTR [rcx+0xd0],xmm0
  40d11b:	mov    QWORD PTR [rcx+0xe0],0x0
  40d126:	ret
	...

000000000040d130 <__swc_fn_7dafa2b1_000157_5c8b11d8>:
  40d130:	push   rbx
  40d131:	mov    rbx,rcx
  40d134:	call   411530 <__swc_fn_7dafa2b1_000158_6741c23b>
  40d139:	mov    rax,QWORD PTR [rbx+0x10]
  40d13d:	test   rax,rax
  40d140:	je     40d151 <__swc_fn_7dafa2b1_000157_5c8b11d8+0x21>
  40d142:	mov    rcx,rbx
  40d145:	mov    rdx,rax
  40d148:	mov    r8,QWORD PTR [rbx+0x18]
  40d14c:	call   409e90 <__swc_fn_7dafa2b1_000156_312df05a>
  40d151:	vxorps xmm0,xmm0,xmm0
  40d155:	vmovups XMMWORD PTR [rbx],xmm0
  40d159:	vmovups XMMWORD PTR [rbx+0x10],xmm0
  40d15e:	vmovups XMMWORD PTR [rbx+0x20],xmm0
  40d163:	vmovups XMMWORD PTR [rbx+0x30],xmm0
  40d168:	vmovups XMMWORD PTR [rbx+0x40],xmm0
  40d16d:	mov    QWORD PTR [rbx+0x50],0x0
  40d175:	pop    rbx
  40d176:	ret
	...

000000000040d180 <__swc_fn_7dafa2b1_000160_e25d06b9>:
  40d180:	sub    rsp,0x10
  40d184:	mov    eax,r8d
  40d187:	mov    r8d,r9d
  40d18a:	test   r9d,r9d
  40d18d:	jne    40d1a6 <__swc_fn_7dafa2b1_000160_e25d06b9+0x26>
  40d18f:	vmovups xmm0,XMMWORD PTR [rip+0x5681]        # 412818 <__swc_rdata_base_7dafa2b1+0x708>
  40d197:	vmovups XMMWORD PTR [r10],xmm0
  40d19c:	mov    eax,0x1
  40d1a1:	add    rsp,0x10
  40d1a5:	ret
  40d1a6:	mov    r9,r8
  40d1a9:	cmp    r8,rax
  40d1ac:	jb     40d1b3 <__swc_fn_7dafa2b1_000160_e25d06b9+0x33>
  40d1ae:	cmp    r9,rdx
  40d1b1:	jb     40d1ba <__swc_fn_7dafa2b1_000160_e25d06b9+0x3a>
  40d1b3:	xor    eax,eax
  40d1b5:	add    rsp,0x10
  40d1b9:	ret
  40d1ba:	xor    eax,eax
  40d1bc:	lea    r8,[r9+rax*1]
  40d1c0:	cmp    r8,rdx
  40d1c3:	jae    40d1f3 <__swc_fn_7dafa2b1_000160_e25d06b9+0x73>
  40d1c5:	cs nop WORD PTR [rax+rax*1+0x0]
  40d1cf:	cs nop WORD PTR [rax+rax*1+0x0]
  40d1d9:	nop    DWORD PTR [rax+0x0]
  40d1e0:	cmp    BYTE PTR [rcx+r8*1],0x0
  40d1e5:	je     40d1f3 <__swc_fn_7dafa2b1_000160_e25d06b9+0x73>
  40d1e7:	inc    rax
  40d1ea:	lea    r8,[r9+rax*1]
  40d1ee:	cmp    r8,rdx
  40d1f1:	jb     40d1e0 <__swc_fn_7dafa2b1_000160_e25d06b9+0x60>
  40d1f3:	cmp    r8,rdx
  40d1f6:	jne    40d1ff <__swc_fn_7dafa2b1_000160_e25d06b9+0x7f>
  40d1f8:	xor    eax,eax
  40d1fa:	add    rsp,0x10
  40d1fe:	ret
  40d1ff:	add    rcx,r9
  40d202:	mov    QWORD PTR [rsp],rcx
  40d206:	mov    QWORD PTR [rsp+0x8],rax
  40d20b:	vmovups xmm0,XMMWORD PTR [rsp]
  40d210:	vmovups XMMWORD PTR [r10],xmm0
  40d215:	mov    eax,0x1
  40d21a:	add    rsp,0x10
  40d21e:	ret
	...

000000000040d220 <__swc_fn_7dafa2b1_000163_5fbed98a>:
  40d220:	push   rbp
  40d221:	push   rbx
  40d222:	push   rsi
  40d223:	push   rdi
  40d224:	push   r12
  40d226:	push   r13
  40d228:	push   r14
  40d22a:	push   r15
  40d22c:	sub    rsp,0x10
  40d230:	mov    rbp,rsp
  40d233:	vmovups XMMWORD PTR [rsp],xmm6
  40d238:	sub    rsp,0x50
  40d23c:	mov    rbx,rsp
  40d23f:	mov    rsi,r8
  40d242:	mov    QWORD PTR [rsp+0x30],r8
  40d247:	mov    rdi,rcx
  40d24a:	mov    QWORD PTR [rsp+0x38],rcx
  40d24f:	mov    r12,rdx
  40d252:	xor    r13b,r13b
  40d255:	mov    r14,QWORD PTR [rdi+0x8]
  40d259:	mov    QWORD PTR [rsp+0x40],r14
  40d25e:	xor    r15d,r15d
  40d261:	test   r14,r14
  40d264:	jbe    40d4be <__swc_fn_7dafa2b1_000163_5fbed98a+0x29e>
  40d26a:	mov    r14,QWORD PTR [rdi]
  40d26d:	mov    rax,QWORD PTR [rsp+0x40]
  40d272:	mov    QWORD PTR [rsp+0x48],r14
  40d277:	vmovups xmm6,XMMWORD PTR [rip+0x51b9]        # 412438 <__swc_rdata_base_7dafa2b1+0x328>
  40d27f:	nop
  40d280:	cmp    QWORD PTR [r14+r15*8],0x0
  40d285:	jne    40d28f <__swc_fn_7dafa2b1_000163_5fbed98a+0x6f>
  40d287:	mov    r14,rax
  40d28a:	jmp    40d49e <__swc_fn_7dafa2b1_000163_5fbed98a+0x27e>
  40d28f:	mov    rcx,QWORD PTR [rdi]
  40d292:	mov    rdx,QWORD PTR [rcx+r15*8]
  40d296:	mov    rdi,rbx
  40d299:	mov    rcx,rdi
  40d29c:	sub    rsp,0x8
  40d2a0:	mov    r14,rax
  40d2a3:	call   409f10 <__swc_fn_7dafa2b1_000162_edb9cf73>
  40d2a8:	add    rsp,0x8
  40d2ac:	mov    al,BYTE PTR [rbx]
  40d2ae:	test   al,al
  40d2b0:	je     40d49e <__swc_fn_7dafa2b1_000163_5fbed98a+0x27e>
  40d2b6:	mov    al,BYTE PTR [rbx+0x1]
  40d2b9:	test   al,al
  40d2bb:	jne    40d2c6 <__swc_fn_7dafa2b1_000163_5fbed98a+0xa6>
  40d2bd:	test   sil,sil
  40d2c0:	je     40d49e <__swc_fn_7dafa2b1_000163_5fbed98a+0x27e>
  40d2c6:	test   r13b,r13b
  40d2c9:	jne    40d387 <__swc_fn_7dafa2b1_000163_5fbed98a+0x167>
  40d2cf:	test   r12,r12
  40d2d2:	je     40d387 <__swc_fn_7dafa2b1_000163_5fbed98a+0x167>
  40d2d8:	mov    al,BYTE PTR [rbx+0x1]
  40d2db:	test   al,al
  40d2dd:	je     40d49e <__swc_fn_7dafa2b1_000163_5fbed98a+0x27e>
  40d2e3:	mov    eax,DWORD PTR [rbx+0x28]
  40d2e6:	cmp    DWORD PTR [r12+0x20],eax
  40d2eb:	jne    40d49e <__swc_fn_7dafa2b1_000163_5fbed98a+0x27e>
  40d2f1:	mov    rax,QWORD PTR [r12]
  40d2f5:	mov    rcx,QWORD PTR [r12+0x8]
  40d2fa:	cmp    QWORD PTR [rbx+0x20],rcx
  40d2fe:	jne    40d49e <__swc_fn_7dafa2b1_000163_5fbed98a+0x27e>
  40d304:	mov    cl,0x1
  40d306:	test   rax,rax
  40d309:	je     40d372 <__swc_fn_7dafa2b1_000163_5fbed98a+0x152>
  40d30f:	mov    rdx,QWORD PTR [rbx+0x20]
  40d313:	xor    r8d,r8d
  40d316:	test   rdx,rdx
  40d319:	jbe    40d372 <__swc_fn_7dafa2b1_000163_5fbed98a+0x152>
  40d31b:	mov    r9,QWORD PTR [rbx+0x18]
  40d31f:	vmovsd xmm0,QWORD PTR [rbx+0x18]
  40d324:	cs nop WORD PTR [rax+rax*1+0x0]
  40d32e:	xchg   ax,ax
  40d330:	mov    r10b,BYTE PTR [rax+r8*1]
  40d334:	cmp    BYTE PTR [r9+r8*1],r10b
  40d338:	je     40d369 <__swc_fn_7dafa2b1_000163_5fbed98a+0x149>
  40d33a:	vmovq  r10,xmm0
  40d33f:	cmp    BYTE PTR [r10+r8*1],0x5c
  40d344:	jne    40d34d <__swc_fn_7dafa2b1_000163_5fbed98a+0x12d>
  40d346:	cmp    BYTE PTR [rax+r8*1],0x2f
  40d34b:	je     40d369 <__swc_fn_7dafa2b1_000163_5fbed98a+0x149>
  40d34d:	vmovq  r10,xmm0
  40d352:	cmp    BYTE PTR [r10+r8*1],0x2f
  40d357:	jne    40d360 <__swc_fn_7dafa2b1_000163_5fbed98a+0x140>
  40d359:	cmp    BYTE PTR [rax+r8*1],0x5c
  40d35e:	je     40d369 <__swc_fn_7dafa2b1_000163_5fbed98a+0x149>
  40d360:	xor    eax,eax
  40d362:	movzx  eax,al
  40d365:	mov    cl,al
  40d367:	jmp    40d372 <__swc_fn_7dafa2b1_000163_5fbed98a+0x152>
  40d369:	add    r8,0x1
  40d36d:	cmp    r8,rdx
  40d370:	jb     40d330 <__swc_fn_7dafa2b1_000163_5fbed98a+0x110>
  40d372:	test   cl,cl
  40d374:	je     40d49e <__swc_fn_7dafa2b1_000163_5fbed98a+0x27e>
  40d37a:	mov    eax,0x1
  40d37f:	mov    r13b,al
  40d382:	jmp    40d49e <__swc_fn_7dafa2b1_000163_5fbed98a+0x27e>
  40d387:	mov    r13b,0x1
  40d38a:	sub    rsp,0x20
  40d38e:	mov    rax,rsp
  40d391:	lea    rcx,[rdi+0x8]
  40d395:	mov    QWORD PTR [rax],rcx
  40d398:	lea    rsi,[rip+0x4f71]        # 412310 <__swc_rdata_base_7dafa2b1+0x200>
  40d39f:	mov    QWORD PTR [rax+0x8],rsi
  40d3a3:	mov    QWORD PTR [rax+0x10],rsp
  40d3a7:	mov    QWORD PTR [rax+0x18],0x1
  40d3af:	lea    rcx,[rsp+0x10]
  40d3b4:	sub    rsp,0x8
  40d3b8:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  40d3bd:	add    rsp,0x8
  40d3c1:	add    rsp,0x20
  40d3c5:	mov    al,BYTE PTR [rbx+0x1]
  40d3c8:	test   al,al
  40d3ca:	je     40d467 <__swc_fn_7dafa2b1_000163_5fbed98a+0x247>
  40d3d0:	lea    rax,[rip+0x54e1]        # 4128b8 <__swc_rdata_base_7dafa2b1+0x7a8>
  40d3d7:	sub    rsp,0x20
  40d3db:	mov    rcx,rsp
  40d3de:	mov    QWORD PTR [rcx],rax
  40d3e1:	mov    QWORD PTR [rcx+0x8],rsi
  40d3e5:	mov    QWORD PTR [rcx+0x10],rsp
  40d3e9:	mov    QWORD PTR [rcx+0x18],0x1
  40d3f1:	lea    rcx,[rsp+0x10]
  40d3f6:	sub    rsp,0x8
  40d3fa:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  40d3ff:	add    rsp,0x8
  40d403:	add    rsp,0x20
  40d407:	mov    eax,DWORD PTR [rbx+0x28]
  40d40a:	sub    rsp,0x60
  40d40e:	mov    rcx,rsp
  40d411:	lea    rdx,[rdi+0x18]
  40d415:	mov    QWORD PTR [rcx+0x18],rdx
  40d419:	mov    QWORD PTR [rcx+0x20],rsi
  40d41d:	vmovups XMMWORD PTR [rcx],xmm6
  40d421:	mov    QWORD PTR [rcx+0x28],rsp
  40d425:	mov    QWORD PTR [rcx+0x30],rsi
  40d429:	mov    DWORD PTR [rcx+0x10],eax
  40d42c:	lea    rax,[rsp+0x10]
  40d431:	mov    QWORD PTR [rcx+0x38],rax
  40d435:	lea    rax,[rip+0x4f94]        # 4123d0 <__swc_rdata_base_7dafa2b1+0x2c0>
  40d43c:	mov    QWORD PTR [rcx+0x40],rax
  40d440:	lea    rax,[rsp+0x18]
  40d445:	mov    QWORD PTR [rcx+0x48],rax
  40d449:	mov    QWORD PTR [rcx+0x50],0x3
  40d451:	lea    rcx,[rsp+0x48]
  40d456:	sub    rsp,0x8
  40d45a:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  40d45f:	add    rsp,0x8
  40d463:	add    rsp,0x60
  40d467:	lea    rax,[rip+0x4efa]        # 412368 <__swc_rdata_base_7dafa2b1+0x258>
  40d46e:	sub    rsp,0x20
  40d472:	mov    rcx,rsp
  40d475:	mov    QWORD PTR [rcx],rax
  40d478:	mov    QWORD PTR [rcx+0x8],rsi
  40d47c:	mov    QWORD PTR [rcx+0x10],rsp
  40d480:	mov    QWORD PTR [rcx+0x18],0x1
  40d488:	lea    rcx,[rsp+0x10]
  40d48d:	sub    rsp,0x8
  40d491:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  40d496:	add    rsp,0x8
  40d49a:	add    rsp,0x20
  40d49e:	add    r15,0x1
  40d4a2:	cmp    r15,r14
  40d4a5:	jae    40d4be <__swc_fn_7dafa2b1_000163_5fbed98a+0x29e>
  40d4a7:	mov    rsi,QWORD PTR [rsp+0x30]
  40d4ac:	mov    rdi,QWORD PTR [rsp+0x38]
  40d4b1:	mov    rax,r14
  40d4b4:	mov    r14,QWORD PTR [rsp+0x48]
  40d4b9:	jmp    40d280 <__swc_fn_7dafa2b1_000163_5fbed98a+0x60>
  40d4be:	add    rsp,0x50
  40d4c2:	vmovups xmm6,XMMWORD PTR [rsp]
  40d4c7:	add    rsp,0x10
  40d4cb:	pop    r15
  40d4cd:	pop    r14
  40d4cf:	pop    r13
  40d4d1:	pop    r12
  40d4d3:	pop    rdi
  40d4d4:	pop    rsi
  40d4d5:	pop    rbx
  40d4d6:	pop    rbp
  40d4d7:	ret
	...

000000000040d4e0 <__swc_fn_7dafa2b1_000166_31ca4f53>:
  40d4e0:	sub    rsp,0x8
  40d4e4:	call   40fd70 <__swc_fn_7dafa2b1_000125_e19c72b3>
  40d4e9:	add    rsp,0x8
  40d4ed:	ret
	...

000000000040d4f0 <__swc_fn_7dafa2b1_000169_aabbfb4c>:
  40d4f0:	push   rsi
  40d4f1:	sub    rsp,0x30
  40d4f5:	lea    rsi,[rip+0x188a4]        # 425da0 <__swc_bss_base_7dafa2b1+0x2d60>
  40d4fc:	mov    rax,QWORD PTR [rsi]
  40d4ff:	test   rax,rax
  40d502:	je     40d50a <__swc_fn_7dafa2b1_000169_aabbfb4c+0x1a>
  40d504:	add    rsp,0x30
  40d508:	pop    rsi
  40d509:	ret
  40d50a:	mov    ecx,0x2
  40d50f:	mov    edx,0x8020
  40d514:	call   40f410 <__swc_fn_7dafa2b1_000107_ff529476>
  40d519:	test   rax,rax
  40d51c:	jne    40d52d <__swc_fn_7dafa2b1_000169_aabbfb4c+0x3d>
  40d51e:	mov    QWORD PTR [rsp+0x18],rax
  40d523:	call   40c990 <__swc_fn_7dafa2b1_000118_2b35b5e0>
  40d528:	mov    rax,QWORD PTR [rsp+0x18]
  40d52d:	mov    rcx,rax
  40d530:	xchg   QWORD PTR [rsi],rcx
  40d533:	add    rsp,0x30
  40d537:	pop    rsi
  40d538:	ret
  40d539:	add    BYTE PTR [rax],al
  40d53b:	add    BYTE PTR [rax],al
  40d53d:	add    BYTE PTR [rax],al
	...

000000000040d540 <__swc_fn_7dafa2b1_000172_9a88b1d5>:
  40d540:	push   rsi
  40d541:	test   r8,r8
  40d544:	jne    40d548 <__swc_fn_7dafa2b1_000172_9a88b1d5+0x8>
  40d546:	pop    rsi
  40d547:	ret
  40d548:	lea    rax,[rcx+0x18]
  40d54c:	mov    r10,QWORD PTR [rax]
  40d54f:	lea    r11,[r10+0x1]
  40d553:	mov    QWORD PTR [rax],r11
  40d556:	mov    r11,rdx
  40d559:	not    rdx
  40d55c:	lea    rsi,[r8-0x1]
  40d560:	cmp    rsi,rdx
  40d563:	ja     40d583 <__swc_fn_7dafa2b1_000172_9a88b1d5+0x43>
  40d565:	lea    rdx,[r11+r8*1]
  40d569:	dec    rdx
  40d56c:	shr    rdx,0x6
  40d570:	mov    r8,r11
  40d573:	shr    r8,0x6
  40d577:	mov    rsi,rdx
  40d57a:	sub    rsi,r8
  40d57d:	cmp    rsi,0x8
  40d581:	jb     40d599 <__swc_fn_7dafa2b1_000172_9a88b1d5+0x59>
  40d583:	lea    rcx,[rcx+0x10]
  40d587:	mov    rdx,QWORD PTR [rcx]
  40d58a:	add    rdx,r9
  40d58d:	mov    QWORD PTR [rcx],rdx
  40d590:	lea    rcx,[r10+0x2]
  40d594:	mov    QWORD PTR [rax],rcx
  40d597:	pop    rsi
  40d598:	ret
  40d599:	shr    r11,0x6
  40d59d:	nop    DWORD PTR [rax]
  40d5a0:	cmp    r11,rdx
  40d5a3:	ja     40d5e3 <__swc_fn_7dafa2b1_000172_9a88b1d5+0xa3>
  40d5a5:	jmp    40d5b6 <__swc_fn_7dafa2b1_000172_9a88b1d5+0x76>
  40d5a7:	nop    WORD PTR [rax+rax*1+0x0]
  40d5b0:	add    r11,0x1
  40d5b4:	jmp    40d5a0 <__swc_fn_7dafa2b1_000172_9a88b1d5+0x60>
  40d5b6:	mov    r8,r11
  40d5b9:	shr    r8,0xc
  40d5bd:	mov    rsi,r11
  40d5c0:	xor    rsi,r8
  40d5c3:	mov    r8,r11
  40d5c6:	shr    r8,0x18
  40d5ca:	xor    rsi,r8
  40d5cd:	and    esi,0xfff
  40d5d3:	lea    r8,[rcx+rsi*8+0x20]
  40d5d8:	mov    rsi,QWORD PTR [r8]
  40d5db:	add    rsi,r9
  40d5de:	mov    QWORD PTR [r8],rsi
  40d5e1:	jmp    40d5b0 <__swc_fn_7dafa2b1_000172_9a88b1d5+0x70>
  40d5e3:	lea    rcx,[r10+0x2]
  40d5e7:	mov    QWORD PTR [rax],rcx
  40d5ea:	pop    rsi
  40d5eb:	ret
  40d5ec:	add    BYTE PTR [rax],al
	...

000000000040d5f0 <__swc_fn_7dafa2b1_000175_82999b37>:
  40d5f0:	push   rbx
  40d5f1:	push   rsi
  40d5f2:	sub    rsp,0x68
  40d5f6:	mov    rbx,rcx
  40d5f9:	vxorps xmm0,xmm0,xmm0
  40d5fd:	vmovups YMMWORD PTR [rsp+0x8],ymm0
  40d603:	vmovups YMMWORD PTR [rsp+0x28],ymm0
  40d609:	vmovups YMMWORD PTR [rsp+0x48],ymm0
  40d60f:	vzeroupper
  40d612:	mov    QWORD PTR [rsp+0x50],0x20
  40d61b:	mov    DWORD PTR [rsp+0x60],0x10
  40d623:	mov    rcx,QWORD PTR [rip+0x18716]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40d62a:	test   rcx,rcx
  40d62d:	jne    40d63f <__swc_fn_7dafa2b1_000175_82999b37+0x4f>
  40d62f:	call   40a1a0 <__swc_fn_7dafa2b1_000165_e09accff>
  40d634:	lea    rcx,[rax+0x1]
  40d638:	mov    QWORD PTR [rip+0x18701],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40d63f:	dec    rcx
  40d642:	call   4118a0 <__swc_fn_7dafa2b1_000167_3130645d>
  40d647:	mov    rcx,QWORD PTR [rax]
  40d64a:	lea    rdx,[rsp+0x8]
  40d64f:	mov    rsi,QWORD PTR [rax+0x8]
  40d653:	mov    rsi,QWORD PTR [rsi+0x8]
  40d657:	call   rsi
  40d659:	mov    rax,QWORD PTR [rsp+0x48]
  40d65e:	test   rax,rax
  40d661:	jne    40d667 <__swc_fn_7dafa2b1_000175_82999b37+0x77>
  40d663:	xor    esi,esi
  40d665:	jmp    40d67b <__swc_fn_7dafa2b1_000175_82999b37+0x8b>
  40d667:	mov    rcx,QWORD PTR [rsp+0x50]
  40d66c:	mov    QWORD PTR [rax],rcx
  40d66f:	mov    QWORD PTR [rax+0x8],0x0
  40d677:	lea    rsi,[rax+0x10]
  40d67b:	test   ebx,ebx
  40d67d:	jle    40d698 <__swc_fn_7dafa2b1_000175_82999b37+0xa8>
  40d67f:	dec    ebx
  40d681:	mov    ecx,ebx
  40d683:	call   40d5f0 <__swc_fn_7dafa2b1_000175_82999b37>
  40d688:	mov    QWORD PTR [rsi],rax
  40d68b:	mov    ecx,ebx
  40d68d:	call   40d5f0 <__swc_fn_7dafa2b1_000175_82999b37>
  40d692:	mov    QWORD PTR [rsi+0x8],rax
  40d696:	jmp    40d6a0 <__swc_fn_7dafa2b1_000175_82999b37+0xb0>
  40d698:	vxorps xmm0,xmm0,xmm0
  40d69c:	vmovdqu XMMWORD PTR [rsi],xmm0
  40d6a0:	mov    rax,rsi
  40d6a3:	add    rsp,0x68
  40d6a7:	pop    rsi
  40d6a8:	pop    rbx
  40d6a9:	ret
  40d6aa:	add    BYTE PTR [rax],al
  40d6ac:	add    BYTE PTR [rax],al
	...

000000000040d6b0 <__swc_fn_7dafa2b1_000178_a6773dec>:
  40d6b0:	push   rbp
  40d6b1:	push   rbx
  40d6b2:	push   rsi
  40d6b3:	push   rdi
  40d6b4:	push   r12
  40d6b6:	push   r13
  40d6b8:	push   r14
  40d6ba:	push   r15
  40d6bc:	sub    rsp,0x10
  40d6c0:	mov    rbp,rsp
  40d6c3:	vmovups XMMWORD PTR [rsp],xmm6
  40d6c8:	sub    rsp,0x10
  40d6cc:	mov    rbx,rsp
  40d6cf:	sub    rsp,0x8
  40d6d3:	call   411a80 <__swc_fn_7dafa2b1_000179_1ca87929>
  40d6d8:	vmovups xmm6,xmm0
  40d6dc:	mov    ecx,0xd
  40d6e1:	call   40d5f0 <__swc_fn_7dafa2b1_000175_82999b37>
  40d6e6:	mov    rsi,rax
  40d6e9:	mov    rcx,rax
  40d6ec:	call   411a40 <__swc_fn_7dafa2b1_000176_cb8588f1>
  40d6f1:	mov    rdi,rax
  40d6f4:	mov    rcx,rsi
  40d6f7:	call   40a350 <__swc_fn_7dafa2b1_000177_6e6aee58>
  40d6fc:	mov    ecx,0xc
  40d701:	call   40d5f0 <__swc_fn_7dafa2b1_000175_82999b37>
  40d706:	mov    rsi,rax
  40d709:	mov    r12,rbx
  40d70c:	mov    DWORD PTR [rbx],0x4
  40d712:	mov    eax,DWORD PTR [rbx]
  40d714:	cmp    eax,0xc
  40d717:	jg     40d776 <__swc_fn_7dafa2b1_000178_a6773dec+0xc6>
  40d719:	nop    DWORD PTR [rax+0x0]
  40d720:	mov    eax,0xc
  40d725:	sub    eax,DWORD PTR [rbx]
  40d727:	mov    r13d,0x1
  40d72d:	lea    ecx,[rax+0x4]
  40d730:	shl    r13,cl
  40d733:	xor    r14d,r14d
  40d736:	test   r13,r13
  40d739:	jbe    40d76a <__swc_fn_7dafa2b1_000178_a6773dec+0xba>
  40d73b:	nop    DWORD PTR [rax+rax*1+0x0]
  40d740:	mov    rax,r12
  40d743:	movsxd rcx,DWORD PTR [rax]
  40d746:	call   40d5f0 <__swc_fn_7dafa2b1_000175_82999b37>
  40d74b:	mov    r15,rax
  40d74e:	mov    rcx,rax
  40d751:	call   411a40 <__swc_fn_7dafa2b1_000176_cb8588f1>
  40d756:	add    rdi,rax
  40d759:	mov    rcx,r15
  40d75c:	call   40a350 <__swc_fn_7dafa2b1_000177_6e6aee58>
  40d761:	add    r14,0x1
  40d765:	cmp    r14,r13
  40d768:	jb     40d740 <__swc_fn_7dafa2b1_000178_a6773dec+0x90>
  40d76a:	mov    eax,DWORD PTR [rbx]
  40d76c:	add    eax,0x2
  40d76f:	mov    DWORD PTR [rbx],eax
  40d771:	cmp    eax,0xc
  40d774:	jle    40d720 <__swc_fn_7dafa2b1_000178_a6773dec+0x70>
  40d776:	mov    rcx,rsi
  40d779:	call   411a40 <__swc_fn_7dafa2b1_000176_cb8588f1>
  40d77e:	add    rdi,rax
  40d781:	mov    rcx,rsi
  40d784:	call   40a350 <__swc_fn_7dafa2b1_000177_6e6aee58>
  40d789:	call   411a80 <__swc_fn_7dafa2b1_000179_1ca87929>
  40d78e:	vsubsd xmm0,xmm0,xmm6
  40d792:	vmulsd xmm0,xmm0,QWORD PTR [rip+0x521e]        # 4129b8 <__swc_rdata_base_7dafa2b1+0x8a8>
  40d79a:	lea    rax,[rip+0x4bc7]        # 412368 <__swc_rdata_base_7dafa2b1+0x258>
  40d7a1:	sub    rsp,0x88
  40d7a8:	mov    rcx,rsp
  40d7ab:	vmovups xmm1,XMMWORD PTR [rip+0x51e5]        # 412998 <__swc_rdata_base_7dafa2b1+0x888>
  40d7b3:	vmovups XMMWORD PTR [rcx],xmm1
  40d7b7:	mov    QWORD PTR [rcx+0x30],rsp
  40d7bb:	lea    rdx,[rip+0x4b4e]        # 412310 <__swc_rdata_base_7dafa2b1+0x200>
  40d7c2:	mov    QWORD PTR [rcx+0x38],rdx
  40d7c6:	mov    QWORD PTR [rcx+0x10],rdi
  40d7ca:	lea    r8,[rsp+0x10]
  40d7cf:	mov    QWORD PTR [rcx+0x40],r8
  40d7d3:	lea    r8,[rip+0x512e]        # 412908 <__swc_rdata_base_7dafa2b1+0x7f8>
  40d7da:	mov    QWORD PTR [rcx+0x48],r8
  40d7de:	vmovups xmm1,XMMWORD PTR [rip+0x51c2]        # 4129a8 <__swc_rdata_base_7dafa2b1+0x898>
  40d7e6:	vmovups XMMWORD PTR [rcx+0x18],xmm1
  40d7eb:	lea    r8,[rsp+0x18]
  40d7f0:	mov    QWORD PTR [rcx+0x50],r8
  40d7f4:	mov    QWORD PTR [rcx+0x58],rdx
  40d7f8:	vmovsd QWORD PTR [rcx+0x28],xmm0
  40d7fd:	lea    r8,[rcx+0x28]
  40d801:	mov    QWORD PTR [rcx+0x60],r8
  40d805:	lea    r8,[rip+0x5144]        # 412950 <__swc_rdata_base_7dafa2b1+0x840>
  40d80c:	mov    QWORD PTR [rcx+0x68],r8
  40d810:	mov    QWORD PTR [rcx+0x70],rax
  40d814:	mov    QWORD PTR [rcx+0x78],rdx
  40d818:	lea    rax,[rcx+0x30]
  40d81c:	mov    QWORD PTR [rcx+0x80],rax
  40d823:	mov    QWORD PTR [rcx+0x88],0x5
  40d82e:	lea    rcx,[rcx+0x80]
  40d835:	sub    rsp,0x8
  40d839:	call   410360 <__swc_fn_7dafa2b1_000146_e9d46966>
  40d83e:	add    rsp,0xa8
  40d845:	vmovups xmm6,XMMWORD PTR [rsp]
  40d84a:	add    rsp,0x10
  40d84e:	pop    r15
  40d850:	pop    r14
  40d852:	pop    r13
  40d854:	pop    r12
  40d856:	pop    rdi
  40d857:	pop    rsi
  40d858:	pop    rbx
  40d859:	pop    rbp
  40d85a:	ret
  40d85b:	add    BYTE PTR [rax],al
  40d85d:	add    BYTE PTR [rax],al
	...

000000000040d860 <__swc_fn_7dafa2b1_000002_390d5093>:
  40d860:	sub    rsp,0x8
  40d864:	call   40c5e0 <__swc_fn_7dafa2b1_000109_aa570b2b>
  40d869:	mov    rcx,rax
  40d86c:	test   rax,rax
  40d86f:	je     40d896 <__swc_fn_7dafa2b1_000002_390d5093+0x36>
  40d871:	lea    rdx,[rip+0x157c8]        # 423040 <__swc_bss_base_7dafa2b1>
  40d878:	mov    r8,QWORD PTR [rip+0x157c1]        # 423040 <__swc_bss_base_7dafa2b1>
  40d87f:	nop
  40d880:	lea    r9,[r8+0x1]
  40d884:	mov    rax,r8
  40d887:	lock cmpxchg QWORD PTR [rdx],r9
  40d88c:	cmp    rax,r8
  40d88f:	je     40d896 <__swc_fn_7dafa2b1_000002_390d5093+0x36>
  40d891:	mov    r8,rax
  40d894:	jmp    40d880 <__swc_fn_7dafa2b1_000002_390d5093+0x20>
  40d896:	mov    rax,rcx
  40d899:	add    rsp,0x8
  40d89d:	ret
	...

000000000040d8a0 <__swc_fn_7dafa2b1_000005_bcc5b80b>:
  40d8a0:	mov    r8d,edx
  40d8a3:	xor    eax,eax
  40d8a5:	tzcnt  eax,edx
  40d8a9:	shrx   r9d,edx,eax
  40d8ae:	mov    DWORD PTR [rcx+0x2c],edx
  40d8b1:	xor    eax,eax
  40d8b3:	tzcnt  eax,edx
  40d8b7:	mov    BYTE PTR [rcx+0x38],al
  40d8ba:	mov    eax,0xffffffff
  40d8bf:	xor    edx,edx
  40d8c1:	div    r8d
  40d8c4:	mov    DWORD PTR [rcx+0x34],eax
  40d8c7:	mov    eax,r9d
  40d8ca:	mov    edx,r9d
  40d8cd:	imul   edx,r9d
  40d8d1:	mov    r8d,0x2
  40d8d7:	sub    r8d,edx
  40d8da:	imul   eax,r8d
  40d8de:	mov    edx,r9d
  40d8e1:	imul   edx,eax
  40d8e4:	mov    r8d,0x2
  40d8ea:	sub    r8d,edx
  40d8ed:	imul   eax,r8d
  40d8f1:	mov    edx,r9d
  40d8f4:	imul   edx,eax
  40d8f7:	mov    r8d,0x2
  40d8fd:	sub    r8d,edx
  40d900:	imul   eax,r8d
  40d904:	mov    edx,r9d
  40d907:	imul   edx,eax
  40d90a:	mov    r8d,0x2
  40d910:	sub    r8d,edx
  40d913:	imul   eax,r8d
  40d917:	imul   r9d,eax
  40d91b:	mov    edx,0x2
  40d920:	sub    edx,r9d
  40d923:	imul   eax,edx
  40d926:	mov    DWORD PTR [rcx+0x30],eax
  40d929:	ret
  40d92a:	add    BYTE PTR [rax],al
  40d92c:	add    BYTE PTR [rax],al
	...

000000000040d930 <__swc_fn_7dafa2b1_000008_578f1784>:
  40d930:	xor    eax,eax
  40d932:	mov    DWORD PTR [rcx+0x68],eax
  40d935:	ret
	...

000000000040d940 <__swc_fn_7dafa2b1_000011_e75d466d>:
  40d940:	mov    eax,DWORD PTR [rcx+0x28]
  40d943:	shlx   eax,edx,eax
  40d948:	shl    rax,0x10
  40d94c:	lea    rdx,[rcx+rax*1]
  40d950:	lea    rax,[rcx+0x3000]
  40d957:	cmp    rdx,rax
  40d95a:	cmovae rax,rdx
  40d95e:	ret
	...

000000000040d960 <__swc_fn_7dafa2b1_000014_1acdaf22>:
  40d960:	push   rsi
  40d961:	push   rdi
  40d962:	push   r12
  40d964:	push   r13
  40d966:	push   r14
  40d968:	mov    rsi,rdx
  40d96b:	mov    rdi,rcx
  40d96e:	rex mov dl,BYTE PTR [rsi+0x3a]
  40d972:	mov    ecx,DWORD PTR [rdi+0x28]
  40d975:	shr    dl,cl
  40d977:	mov    r12d,0x1
  40d97d:	mov    ecx,edx
  40d97f:	shl    r12,cl
  40d982:	mov    r13d,DWORD PTR [rsi+0x3c]
  40d986:	rex mov BYTE PTR [rsi+0x3b],0x0
  40d98b:	mov    QWORD PTR [rsi+0x40],0x0
  40d993:	mov    QWORD PTR [rsi],0x0
  40d99a:	mov    rax,QWORD PTR [rsi+0x10]
  40d99e:	mov    QWORD PTR [rsi+0x20],rax
  40d9a2:	lea    r14,[rip+0x1569f]        # 423048 <__swc_bss_base_7dafa2b1+0x8>
  40d9a9:	mov    rax,QWORD PTR [r14]
  40d9ac:	shr    rax,0x2
  40d9b0:	mov    rcx,rax
  40d9b3:	cmp    rax,0x800000
  40d9ba:	mov    eax,0x800000
  40d9bf:	cmovb  rcx,rax
  40d9c3:	lea    r8,[rip+0x1568e]        # 423058 <__swc_bss_base_7dafa2b1+0x18>
  40d9ca:	mov    rax,QWORD PTR [r8]
  40d9cd:	mov    r9,rax
  40d9d0:	lea    r10,[r9+r13*1]
  40d9d4:	cmp    r10,rcx
  40d9d7:	ja     40d9fb <__swc_fn_7dafa2b1_000014_1acdaf22+0x9b>
  40d9d9:	mov    rax,r9
  40d9dc:	lock cmpxchg QWORD PTR [r8],r10
  40d9e1:	cmp    rax,r9
  40d9e4:	je     40d9eb <__swc_fn_7dafa2b1_000014_1acdaf22+0x8b>
  40d9e6:	mov    r9,rax
  40d9e9:	jmp    40d9d0 <__swc_fn_7dafa2b1_000014_1acdaf22+0x70>
  40d9eb:	mov    rcx,rdi
  40d9ee:	mov    rdx,r12
  40d9f1:	call   40a710 <__swc_fn_7dafa2b1_000016_89da4d6e>
  40d9f6:	jmp    40da7d <__swc_fn_7dafa2b1_000014_1acdaf22+0x11d>
  40d9fb:	mov    rcx,rdi
  40d9fe:	movzx  edx,dl
  40da01:	call   40d940 <__swc_fn_7dafa2b1_000011_e75d466d>
  40da06:	test   r13,r13
  40da09:	je     40da76 <__swc_fn_7dafa2b1_000014_1acdaf22+0x116>
  40da0f:	mov    rcx,rax
  40da12:	mov    rdx,r13
  40da15:	call   40c760 <__swc_fn_7dafa2b1_000112_cb2656be>
  40da1a:	mov    rcx,QWORD PTR [rip+0x15627]        # 423048 <__swc_bss_base_7dafa2b1+0x8>
  40da21:	cs nop WORD PTR [rax+rax*1+0x0]
  40da2b:	nop    DWORD PTR [rax+rax*1+0x0]
  40da30:	mov    rdx,rcx
  40da33:	sub    rdx,r13
  40da36:	mov    rax,rcx
  40da39:	lock cmpxchg QWORD PTR [r14],rdx
  40da3e:	cmp    rax,rcx
  40da41:	je     40da48 <__swc_fn_7dafa2b1_000014_1acdaf22+0xe8>
  40da43:	mov    rcx,rax
  40da46:	jmp    40da30 <__swc_fn_7dafa2b1_000014_1acdaf22+0xd0>
  40da48:	lea    rcx,[rip+0x15611]        # 423060 <__swc_bss_base_7dafa2b1+0x20>
  40da4f:	mov    rdx,QWORD PTR [rip+0x1560a]        # 423060 <__swc_bss_base_7dafa2b1+0x20>
  40da56:	cs nop WORD PTR [rax+rax*1+0x0]
  40da60:	lea    r8,[rdx+0x1]
  40da64:	mov    rax,rdx
  40da67:	lock cmpxchg QWORD PTR [rcx],r8
  40da6c:	cmp    rax,rdx
  40da6f:	je     40da76 <__swc_fn_7dafa2b1_000014_1acdaf22+0x116>
  40da71:	mov    rdx,rax
  40da74:	jmp    40da60 <__swc_fn_7dafa2b1_000014_1acdaf22+0x100>
  40da76:	mov    DWORD PTR [rsi+0x3c],0x0
  40da7d:	mov    rcx,rdi
  40da80:	mov    rdx,r12
  40da83:	call   407600 <__swc_fn_7dafa2b1_000018_e2e8e4b0>
  40da88:	pop    r14
  40da8a:	pop    r13
  40da8c:	pop    r12
  40da8e:	pop    rdi
  40da8f:	pop    rsi
  40da90:	ret
	...

000000000040daa0 <__swc_fn_7dafa2b1_000017_e238d24c>:
  40daa0:	mov    r8,QWORD PTR [rcx+0x48]
  40daa4:	test   r8,rdx
  40daa7:	je     40dad8 <__swc_fn_7dafa2b1_000017_e238d24c+0x38>
  40daa9:	nop    DWORD PTR [rax+0x0]
  40dab0:	mov    rax,rdx
  40dab3:	not    rax
  40dab6:	mov    r9,r8
  40dab9:	and    r9,rax
  40dabc:	mov    rax,r8
  40dabf:	lock cmpxchg QWORD PTR [rcx+0x48],r9
  40dac5:	cmp    rax,r8
  40dac8:	jne    40dad0 <__swc_fn_7dafa2b1_000017_e238d24c+0x30>
  40daca:	mov    eax,0x1
  40dacf:	ret
  40dad0:	mov    r8,rax
  40dad3:	test   rax,rdx
  40dad6:	jne    40dab0 <__swc_fn_7dafa2b1_000017_e238d24c+0x10>
  40dad8:	xor    eax,eax
  40dada:	ret
  40dadb:	add    BYTE PTR [rax],al
  40dadd:	add    BYTE PTR [rax],al
	...

000000000040dae0 <__swc_fn_7dafa2b1_000020_4135c89a>:
  40dae0:	push   rsi
  40dae1:	push   rdi
  40dae2:	push   r12
  40dae4:	push   r13
  40dae6:	sub    rsp,0x8
  40daea:	mov    rsi,rdx
  40daed:	mov    rdi,rcx
  40daf0:	lea    r12,[rip+0x156f9]        # 4231f0 <__swc_bss_base_7dafa2b1+0x1b0>
  40daf7:	mov    rcx,r12
  40dafa:	call   4098a0 <__swc_fn_7dafa2b1_000135_1fec60ac>
  40daff:	xor    eax,eax
  40db01:	mov    rcx,QWORD PTR [rip+0x156f0]        # 4231f8 <__swc_bss_base_7dafa2b1+0x1b8>
  40db08:	mov    r13,rcx
  40db0b:	test   r13,r13
  40db0e:	je     40db5b <__swc_fn_7dafa2b1_000020_4135c89a+0x7b>
  40db10:	mov    rcx,QWORD PTR [r13+0x10]
  40db14:	cmp    DWORD PTR [r13+0x28],esi
  40db18:	jne    40db50 <__swc_fn_7dafa2b1_000020_4135c89a+0x70>
  40db1a:	test   rax,rax
  40db1d:	jne    40db28 <__swc_fn_7dafa2b1_000020_4135c89a+0x48>
  40db1f:	mov    QWORD PTR [rip+0x156d2],rcx        # 4231f8 <__swc_bss_base_7dafa2b1+0x1b8>
  40db26:	jmp    40db2c <__swc_fn_7dafa2b1_000020_4135c89a+0x4c>
  40db28:	mov    QWORD PTR [rax+0x10],rcx
  40db2c:	vxorps xmm0,xmm0,xmm0
  40db30:	vmovdqu XMMWORD PTR [r13+0x10],xmm0
  40db36:	mov    QWORD PTR [r13+0x8],rdi
  40db3a:	mov    rcx,r12
  40db3d:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  40db42:	mov    rax,r13
  40db45:	add    rsp,0x8
  40db49:	pop    r13
  40db4b:	pop    r12
  40db4d:	pop    rdi
  40db4e:	pop    rsi
  40db4f:	ret
  40db50:	mov    rax,r13
  40db53:	mov    r13,rcx
  40db56:	test   rcx,rcx
  40db59:	jne    40db10 <__swc_fn_7dafa2b1_000020_4135c89a+0x30>
  40db5b:	mov    ecx,esi
  40db5d:	call   40a740 <__swc_fn_7dafa2b1_000019_60e50998>
  40db62:	mov    rsi,rax
  40db65:	test   rax,rax
  40db68:	jne    40db7f <__swc_fn_7dafa2b1_000020_4135c89a+0x9f>
  40db6a:	mov    rcx,r12
  40db6d:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  40db72:	xor    eax,eax
  40db74:	add    rsp,0x8
  40db78:	pop    r13
  40db7a:	pop    r12
  40db7c:	pop    rdi
  40db7d:	pop    rsi
  40db7e:	ret
  40db7f:	mov    QWORD PTR [rsi+0x8],rdi
  40db83:	mov    rcx,r12
  40db86:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  40db8b:	mov    rax,rsi
  40db8e:	add    rsp,0x8
  40db92:	pop    r13
  40db94:	pop    r12
  40db96:	pop    rdi
  40db97:	pop    rsi
  40db98:	ret
  40db99:	add    BYTE PTR [rax],al
  40db9b:	add    BYTE PTR [rax],al
  40db9d:	add    BYTE PTR [rax],al
	...

000000000040dba0 <__swc_fn_7dafa2b1_000023_7e9350e1>:
  40dba0:	vxorps xmm0,xmm0,xmm0
  40dba4:	xor    eax,eax
  40dba6:	cs nop WORD PTR [rax+rax*1+0x0]
  40dbb0:	cs nop WORD PTR [rax+rax*1+0x0]
  40dbba:	nop    WORD PTR [rax+rax*1+0x0]
  40dbc0:	vmovdqu XMMWORD PTR [rcx+rax*1],xmm0
  40dbc5:	add    rax,0x10
  40dbc9:	cmp    rax,0x2b00
  40dbd0:	jne    40dbc0 <__swc_fn_7dafa2b1_000023_7e9350e1+0x20>
  40dbd2:	ret
	...

000000000040dbe0 <__swc_fn_7dafa2b1_000026_7e9350e1>:
  40dbe0:	vxorps xmm0,xmm0,xmm0
  40dbe4:	vmovups XMMWORD PTR [rcx],xmm0
  40dbe8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40dbed:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40dbf2:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40dbf7:	ret
	...

000000000040dc00 <__swc_fn_7dafa2b1_000029_7e9350e1>:
  40dc00:	vxorps xmm0,xmm0,xmm0
  40dc04:	vmovups XMMWORD PTR [rcx],xmm0
  40dc08:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  40dc0d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  40dc12:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  40dc17:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  40dc1c:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  40dc21:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  40dc26:	vmovups XMMWORD PTR [rcx+0x70],xmm0
  40dc2b:	vmovups XMMWORD PTR [rcx+0x80],xmm0
  40dc33:	vmovups XMMWORD PTR [rcx+0x90],xmm0
  40dc3b:	vmovups XMMWORD PTR [rcx+0xa0],xmm0
  40dc43:	vmovups XMMWORD PTR [rcx+0xb0],xmm0
  40dc4b:	mov    QWORD PTR [rcx+0xc0],0x0
  40dc56:	ret
	...

000000000040dc60 <__swc_fn_7dafa2b1_000032_8c89735c>:
  40dc60:	push   rsi
  40dc61:	push   rdi
  40dc62:	sub    rsp,0x8
  40dc66:	mov    rsi,rcx
  40dc69:	lea    rdi,[rip+0x13390]        # 421000 <__swc_data_base_7dafa2b1>
  40dc70:	mov    rax,QWORD PTR [rdi]
  40dc73:	cmp    rax,0xffffffffffffffff
  40dc77:	je     40dc7e <__swc_fn_7dafa2b1_000032_8c89735c+0x1e>
  40dc79:	mov    rdi,rax
  40dc7c:	jmp    40dcab <__swc_fn_7dafa2b1_000032_8c89735c+0x4b>
  40dc7e:	call   409580 <__swc_fn_7dafa2b1_000123_e9227a3e>
  40dc83:	mov    rcx,rax
  40dc86:	cmp    rax,0xffffffffffffffff
  40dc8a:	je     40dcbc <__swc_fn_7dafa2b1_000032_8c89735c+0x5c>
  40dc8c:	mov    rax,0xffffffffffffffff
  40dc93:	lock cmpxchg QWORD PTR [rdi],rcx
  40dc98:	cmp    rax,0xffffffffffffffff
  40dc9c:	je     40dca8 <__swc_fn_7dafa2b1_000032_8c89735c+0x48>
  40dc9e:	mov    rdi,rax
  40dca1:	call   40cb30 <__swc_fn_7dafa2b1_000124_df97aa0a>
  40dca6:	jmp    40dcab <__swc_fn_7dafa2b1_000032_8c89735c+0x4b>
  40dca8:	mov    rdi,rcx
  40dcab:	cmp    rdi,0xffffffffffffffff
  40dcaf:	je     40dcbc <__swc_fn_7dafa2b1_000032_8c89735c+0x5c>
  40dcb1:	mov    rcx,rdi
  40dcb4:	mov    rdx,rsi
  40dcb7:	call   40fd70 <__swc_fn_7dafa2b1_000125_e19c72b3>
  40dcbc:	add    rsp,0x8
  40dcc0:	pop    rdi
  40dcc1:	pop    rsi
  40dcc2:	ret
	...

000000000040dcd0 <__swc_fn_7dafa2b1_000035_6105596e>:
  40dcd0:	sub    rsp,0x38
  40dcd4:	mov    rax,rdx
  40dcd7:	test   dl,dl
  40dcd9:	jne    40dcf1 <__swc_fn_7dafa2b1_000035_6105596e+0x21>
  40dcdb:	mov    rax,r8
  40dcde:	test   r8b,r8b
  40dce1:	cmove  eax,r9d
  40dce5:	test   al,al
  40dce7:	cmove  eax,r10d
  40dceb:	test   al,al
  40dced:	cmove  eax,r11d
  40dcf1:	test   al,al
  40dcf3:	jne    40dcfa <__swc_fn_7dafa2b1_000035_6105596e+0x2a>
  40dcf5:	add    rsp,0x38
  40dcf9:	ret
  40dcfa:	lea    rcx,[rip+0x440f]        # 412110 <__swc_rdata_base_7dafa2b1>
  40dd01:	vmovups xmm0,XMMWORD PTR [rip+0x4417]        # 412120 <__swc_rdata_base_7dafa2b1+0x10>
  40dd09:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40dd0f:	vmovups xmm0,XMMWORD PTR [rip+0x4419]        # 412130 <__swc_rdata_base_7dafa2b1+0x20>
  40dd17:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40dd1d:	vmovups xmm0,XMMWORD PTR [rip+0x441b]        # 412140 <__swc_rdata_base_7dafa2b1+0x30>
  40dd25:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40dd2b:	lea    rdx,[rsp+0x8]
  40dd30:	call   40c360 <__swc_fn_7dafa2b1_000103_2ed36338>
  40dd35:	jmp    40dcf5 <__swc_fn_7dafa2b1_000035_6105596e+0x25>
	...

000000000040dd40 <__swc_fn_7dafa2b1_000038_c7591393>:
  40dd40:	sub    rsp,0x8
  40dd44:	mov    eax,0x1000
  40dd49:	test   eax,eax
  40dd4b:	mov    r8d,0x8
  40dd51:	cmove  eax,r8d
  40dd55:	dec    rax
  40dd58:	mov    r8,0xffffffffffffffff
  40dd5f:	sub    r8,rax
  40dd62:	cmp    rdx,r8
  40dd65:	ja     40dd75 <__swc_fn_7dafa2b1_000038_c7591393+0x35>
  40dd67:	add    rdx,rax
  40dd6a:	not    rax
  40dd6d:	mov    r8,rdx
  40dd70:	and    r8,rax
  40dd73:	jne    40dd7c <__swc_fn_7dafa2b1_000038_c7591393+0x3c>
  40dd75:	xor    eax,eax
  40dd77:	add    rsp,0x8
  40dd7b:	ret
  40dd7c:	mov    rdx,r8
  40dd7f:	call   40aa60 <__swc_fn_7dafa2b1_000037_92e867c2>
  40dd84:	add    rsp,0x8
  40dd88:	ret
  40dd89:	add    BYTE PTR [rax],al
  40dd8b:	add    BYTE PTR [rax],al
  40dd8d:	add    BYTE PTR [rax],al
	...

000000000040dd90 <__swc_fn_7dafa2b1_000041_ed1cda78>:
  40dd90:	push   rsi
  40dd91:	push   rdi
  40dd92:	sub    rsp,0x8
  40dd96:	mov    rsi,rdx
  40dd99:	mov    rdi,rcx
  40dd9c:	test   rdx,rdx
  40dd9f:	je     40ddbb <__swc_fn_7dafa2b1_000041_ed1cda78+0x2b>
  40dda1:	xor    ecx,ecx
  40dda3:	call   407720 <__swc_fn_7dafa2b1_000033_7d7574b6>
  40dda8:	mov    rax,QWORD PTR [rsi]
  40ddab:	test   rax,rax
  40ddae:	je     40ddbb <__swc_fn_7dafa2b1_000041_ed1cda78+0x2b>
  40ddb0:	mov    rcx,rax
  40ddb3:	mov    rdx,rsi
  40ddb6:	call   407840 <__swc_fn_7dafa2b1_000042_70d5ab54>
  40ddbb:	mov    rcx,rdi
  40ddbe:	call   40aac0 <__swc_fn_7dafa2b1_000040_7a225310>
  40ddc3:	mov    rsi,rax
  40ddc6:	test   rax,rax
  40ddc9:	jne    40ddd4 <__swc_fn_7dafa2b1_000041_ed1cda78+0x44>
  40ddcb:	xor    eax,eax
  40ddcd:	add    rsp,0x8
  40ddd1:	pop    rdi
  40ddd2:	pop    rsi
  40ddd3:	ret
  40ddd4:	mov    rcx,rsi
  40ddd7:	call   407720 <__swc_fn_7dafa2b1_000033_7d7574b6>
  40dddc:	mov    rax,rsi
  40dddf:	add    rsp,0x8
  40dde3:	pop    rdi
  40dde4:	pop    rsi
  40dde5:	ret
	...

000000000040ddf0 <__swc_fn_7dafa2b1_000044_cac7f504>:
  40ddf0:	movzx  eax,BYTE PTR [r8+0x39]
  40ddf5:	lea    rax,[rax+rax*4]
  40ddf9:	lea    rax,[rdx+rax*8+0x28]
  40ddfe:	mov    ecx,DWORD PTR [r8+0x6c]
  40de02:	test   ecx,ecx
  40de04:	je     40de3d <__swc_fn_7dafa2b1_000044_cac7f504+0x4d>
  40de06:	mov    rcx,QWORD PTR [r8+0x50]
  40de0a:	test   rcx,rcx
  40de0d:	je     40de19 <__swc_fn_7dafa2b1_000044_cac7f504+0x29>
  40de0f:	mov    rax,QWORD PTR [r8+0x48]
  40de13:	mov    QWORD PTR [rcx+0x48],rax
  40de17:	jmp    40de21 <__swc_fn_7dafa2b1_000044_cac7f504+0x31>
  40de19:	mov    rcx,QWORD PTR [r8+0x48]
  40de1d:	mov    QWORD PTR [rax+0x18],rcx
  40de21:	mov    rax,QWORD PTR [r8+0x48]
  40de25:	test   rax,rax
  40de28:	je     40de32 <__swc_fn_7dafa2b1_000044_cac7f504+0x42>
  40de2a:	mov    rcx,QWORD PTR [r8+0x50]
  40de2e:	mov    QWORD PTR [rax+0x50],rcx
  40de32:	vxorps xmm0,xmm0,xmm0
  40de36:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40de3c:	ret
  40de3d:	mov    rcx,QWORD PTR [r8+0x50]
  40de41:	test   rcx,rcx
  40de44:	je     40de50 <__swc_fn_7dafa2b1_000044_cac7f504+0x60>
  40de46:	mov    rdx,QWORD PTR [r8+0x48]
  40de4a:	mov    QWORD PTR [rcx+0x48],rdx
  40de4e:	jmp    40de58 <__swc_fn_7dafa2b1_000044_cac7f504+0x68>
  40de50:	mov    rcx,QWORD PTR [r8+0x48]
  40de54:	mov    QWORD PTR [rax+0x8],rcx
  40de58:	mov    rcx,QWORD PTR [r8+0x48]
  40de5c:	test   rcx,rcx
  40de5f:	je     40de6b <__swc_fn_7dafa2b1_000044_cac7f504+0x7b>
  40de61:	mov    rdx,QWORD PTR [r8+0x50]
  40de65:	mov    QWORD PTR [rcx+0x50],rdx
  40de69:	jmp    40de73 <__swc_fn_7dafa2b1_000044_cac7f504+0x83>
  40de6b:	mov    rcx,QWORD PTR [r8+0x50]
  40de6f:	mov    QWORD PTR [rax+0x10],rcx
  40de73:	cmp    QWORD PTR [rax],r8
  40de76:	jne    40de7f <__swc_fn_7dafa2b1_000044_cac7f504+0x8f>
  40de78:	mov    QWORD PTR [rax],0x0
  40de7f:	vxorps xmm0,xmm0,xmm0
  40de83:	vmovdqu XMMWORD PTR [r8+0x48],xmm0
  40de89:	ret
  40de8a:	add    BYTE PTR [rax],al
  40de8c:	add    BYTE PTR [rax],al
	...

000000000040de90 <__swc_fn_7dafa2b1_000047_3d3eceb4>:
  40de90:	sub    rsp,0x8
  40de94:	mov    r9,r8
  40de97:	mov    r10,rdx
  40de9a:	call   40ddf0 <__swc_fn_7dafa2b1_000044_cac7f504>
  40de9f:	mov    DWORD PTR [r9+0x6c],0x0
  40dea7:	movzx  eax,BYTE PTR [r9+0x39]
  40deac:	lea    rax,[rax+rax*4]
  40deb0:	lea    rax,[r10+rax*8+0x28]
  40deb5:	mov    rcx,QWORD PTR [rax+0x10]
  40deb9:	mov    QWORD PTR [r9+0x50],rcx
  40debd:	mov    QWORD PTR [r9+0x48],0x0
  40dec5:	mov    rcx,QWORD PTR [rax+0x10]
  40dec9:	test   rcx,rcx
  40decc:	je     40ded4 <__swc_fn_7dafa2b1_000047_3d3eceb4+0x44>
  40dece:	mov    QWORD PTR [rcx+0x48],r9
  40ded2:	jmp    40ded8 <__swc_fn_7dafa2b1_000047_3d3eceb4+0x48>
  40ded4:	mov    QWORD PTR [rax+0x8],r9
  40ded8:	mov    QWORD PTR [rax+0x10],r9
  40dedc:	add    rsp,0x8
  40dee0:	ret
	...

000000000040df00 <__swc_fn_7dafa2b1_000050_e33921d7>:
  40df00:	push   rsi
  40df01:	push   rdi
  40df02:	push   r12
  40df04:	push   r13
  40df06:	push   r14
  40df08:	push   r15
  40df0a:	sub    rsp,0x1f8
  40df11:	mov    esi,r8d
  40df14:	mov    QWORD PTR [rsp+0x1e8],rsi
  40df1c:	mov    rdi,rcx
  40df1f:	mov    r12,rdx
  40df22:	lea    r13,[rsi+rsi*4]
  40df26:	lea    r13,[rdx+r13*8+0x28]
  40df2b:	call   407ca0 <__swc_fn_7dafa2b1_000048_18a95c9b>
  40df30:	add    DWORD PTR [r12+0x24],0x1
  40df36:	test   BYTE PTR [r12+0x24],0x3f
  40df3c:	jne    40df46 <__swc_fn_7dafa2b1_000050_e33921d7+0x46>
  40df3e:	mov    rcx,rdi
  40df41:	call   40ac40 <__swc_fn_7dafa2b1_000049_781177b4>
  40df46:	mov    rax,QWORD PTR [r13+0x8]
  40df4a:	mov    r14,rax
  40df4d:	nop    DWORD PTR [rax]
  40df50:	test   r14,r14
  40df53:	jne    40df62 <__swc_fn_7dafa2b1_000050_e33921d7+0x62>
  40df55:	mov    rsi,QWORD PTR [rsp+0x1e8]
  40df5d:	jmp    40e069 <__swc_fn_7dafa2b1_000050_e33921d7+0x169>
  40df62:	mov    r15,QWORD PTR [r14+0x48]
  40df66:	mov    rcx,r14
  40df69:	call   4073f0 <__swc_fn_7dafa2b1_000009_2417e911>
  40df6e:	mov    rax,QWORD PTR [r14]
  40df71:	test   rax,rax
  40df74:	je     40df86 <__swc_fn_7dafa2b1_000050_e33921d7+0x86>
  40df76:	mov    rcx,QWORD PTR [rax]
  40df79:	mov    QWORD PTR [r14],rcx
  40df7c:	add    DWORD PTR [r14+0x28],0x1
  40df81:	mov    rsi,rax
  40df84:	jmp    40dfa5 <__swc_fn_7dafa2b1_000050_e33921d7+0xa5>
  40df86:	mov    rax,QWORD PTR [r14+0x18]
  40df8a:	cmp    QWORD PTR [r14+0x20],rax
  40df8e:	jae    40dfa3 <__swc_fn_7dafa2b1_000050_e33921d7+0xa3>
  40df90:	mov    rsi,QWORD PTR [r14+0x20]
  40df94:	mov    eax,DWORD PTR [r14+0x2c]
  40df98:	add    QWORD PTR [r14+0x20],rax
  40df9c:	add    DWORD PTR [r14+0x28],0x1
  40dfa1:	jmp    40dfa5 <__swc_fn_7dafa2b1_000050_e33921d7+0xa5>
  40dfa3:	xor    esi,esi
  40dfa5:	test   rsi,rsi
  40dfa8:	jne    40dfed <__swc_fn_7dafa2b1_000050_e33921d7+0xed>
  40dfaa:	mov    rcx,r14
  40dfad:	call   407320 <__swc_fn_7dafa2b1_000006_12cb36a2>
  40dfb2:	test   al,al
  40dfb4:	je     40dfed <__swc_fn_7dafa2b1_000050_e33921d7+0xed>
  40dfb6:	mov    rax,QWORD PTR [r14]
  40dfb9:	test   rax,rax
  40dfbc:	je     40dfcb <__swc_fn_7dafa2b1_000050_e33921d7+0xcb>
  40dfbe:	mov    rcx,QWORD PTR [rax]
  40dfc1:	mov    QWORD PTR [r14],rcx
  40dfc4:	add    DWORD PTR [r14+0x28],0x1
  40dfc9:	jmp    40dfea <__swc_fn_7dafa2b1_000050_e33921d7+0xea>
  40dfcb:	mov    rax,QWORD PTR [r14+0x18]
  40dfcf:	cmp    QWORD PTR [r14+0x20],rax
  40dfd3:	jae    40dfe8 <__swc_fn_7dafa2b1_000050_e33921d7+0xe8>
  40dfd5:	mov    rax,QWORD PTR [r14+0x20]
  40dfd9:	mov    ecx,DWORD PTR [r14+0x2c]
  40dfdd:	add    QWORD PTR [r14+0x20],rcx
  40dfe1:	add    DWORD PTR [r14+0x28],0x1
  40dfe6:	jmp    40dfea <__swc_fn_7dafa2b1_000050_e33921d7+0xea>
  40dfe8:	xor    eax,eax
  40dfea:	mov    rsi,rax
  40dfed:	test   rsi,rsi
  40dff0:	jne    40e043 <__swc_fn_7dafa2b1_000050_e33921d7+0x143>
  40dff2:	mov    rcx,rdi
  40dff5:	mov    rdx,r12
  40dff8:	mov    r8,r14
  40dffb:	call   40aba0 <__swc_fn_7dafa2b1_000046_49300800>
  40e000:	test   al,al
  40e002:	jne    40e043 <__swc_fn_7dafa2b1_000050_e33921d7+0x143>
  40e004:	mov    rcx,r14
  40e007:	call   4073f0 <__swc_fn_7dafa2b1_000009_2417e911>
  40e00c:	mov    rax,QWORD PTR [r14]
  40e00f:	test   rax,rax
  40e012:	je     40e021 <__swc_fn_7dafa2b1_000050_e33921d7+0x121>
  40e014:	mov    rcx,QWORD PTR [rax]
  40e017:	mov    QWORD PTR [r14],rcx
  40e01a:	add    DWORD PTR [r14+0x28],0x1
  40e01f:	jmp    40e040 <__swc_fn_7dafa2b1_000050_e33921d7+0x140>
  40e021:	mov    rax,QWORD PTR [r14+0x18]
  40e025:	cmp    QWORD PTR [r14+0x20],rax
  40e029:	jae    40e03e <__swc_fn_7dafa2b1_000050_e33921d7+0x13e>
  40e02b:	mov    rax,QWORD PTR [r14+0x20]
  40e02f:	mov    ecx,DWORD PTR [r14+0x2c]
  40e033:	add    QWORD PTR [r14+0x20],rcx
  40e037:	add    DWORD PTR [r14+0x28],0x1
  40e03c:	jmp    40e040 <__swc_fn_7dafa2b1_000050_e33921d7+0x140>
  40e03e:	xor    eax,eax
  40e040:	mov    rsi,rax
  40e043:	test   rsi,rsi
  40e046:	je     40e061 <__swc_fn_7dafa2b1_000050_e33921d7+0x161>
  40e048:	mov    QWORD PTR [r13+0x0],r14
  40e04c:	mov    rax,rsi
  40e04f:	add    rsp,0x1f8
  40e056:	pop    r15
  40e058:	pop    r14
  40e05a:	pop    r13
  40e05c:	pop    r12
  40e05e:	pop    rdi
  40e05f:	pop    rsi
  40e060:	ret
  40e061:	mov    r14,r15
  40e064:	jmp    40df50 <__swc_fn_7dafa2b1_000050_e33921d7+0x50>
  40e069:	cs nop WORD PTR [rax+rax*1+0x0]
  40e073:	cs nop WORD PTR [rax+rax*1+0x0]
  40e07d:	nop    DWORD PTR [rax]
  40e080:	mov    rcx,rdi
  40e083:	mov    rdx,r12
  40e086:	mov    r8d,esi
  40e089:	call   4079e0 <__swc_fn_7dafa2b1_000045_06cec934>
  40e08e:	mov    r14,rax
  40e091:	test   rax,rax
  40e094:	jne    40e0aa <__swc_fn_7dafa2b1_000050_e33921d7+0x1aa>
  40e096:	xor    eax,eax
  40e098:	add    rsp,0x1f8
  40e09f:	pop    r15
  40e0a1:	pop    r14
  40e0a3:	pop    r13
  40e0a5:	pop    r12
  40e0a7:	pop    rdi
  40e0a8:	pop    rsi
  40e0a9:	ret
  40e0aa:	mov    QWORD PTR [r13+0x0],r14
  40e0ae:	mov    rax,QWORD PTR [r14]
  40e0b1:	test   rax,rax
  40e0b4:	je     40e0c6 <__swc_fn_7dafa2b1_000050_e33921d7+0x1c6>
  40e0b6:	mov    rcx,QWORD PTR [rax]
  40e0b9:	mov    QWORD PTR [r14],rcx
  40e0bc:	add    DWORD PTR [r14+0x28],0x1
  40e0c1:	mov    r15,rax
  40e0c4:	jmp    40e0e6 <__swc_fn_7dafa2b1_000050_e33921d7+0x1e6>
  40e0c6:	mov    rax,QWORD PTR [r14+0x18]
  40e0ca:	cmp    QWORD PTR [r14+0x20],rax
  40e0ce:	jae    40e0e3 <__swc_fn_7dafa2b1_000050_e33921d7+0x1e3>
  40e0d0:	mov    r15,QWORD PTR [r14+0x20]
  40e0d4:	mov    eax,DWORD PTR [r14+0x2c]
  40e0d8:	add    QWORD PTR [r14+0x20],rax
  40e0dc:	add    DWORD PTR [r14+0x28],0x1
  40e0e1:	jmp    40e0e6 <__swc_fn_7dafa2b1_000050_e33921d7+0x1e6>
  40e0e3:	xor    r15d,r15d
  40e0e6:	test   r15,r15
  40e0e9:	jne    40e12e <__swc_fn_7dafa2b1_000050_e33921d7+0x22e>
  40e0eb:	mov    rcx,r14
  40e0ee:	call   407320 <__swc_fn_7dafa2b1_000006_12cb36a2>
  40e0f3:	test   al,al
  40e0f5:	je     40e12e <__swc_fn_7dafa2b1_000050_e33921d7+0x22e>
  40e0f7:	mov    rax,QWORD PTR [r14]
  40e0fa:	test   rax,rax
  40e0fd:	je     40e10c <__swc_fn_7dafa2b1_000050_e33921d7+0x20c>
  40e0ff:	mov    rcx,QWORD PTR [rax]
  40e102:	mov    QWORD PTR [r14],rcx
  40e105:	add    DWORD PTR [r14+0x28],0x1
  40e10a:	jmp    40e12b <__swc_fn_7dafa2b1_000050_e33921d7+0x22b>
  40e10c:	mov    rax,QWORD PTR [r14+0x18]
  40e110:	cmp    QWORD PTR [r14+0x20],rax
  40e114:	jae    40e129 <__swc_fn_7dafa2b1_000050_e33921d7+0x229>
  40e116:	mov    rax,QWORD PTR [r14+0x20]
  40e11a:	mov    ecx,DWORD PTR [r14+0x2c]
  40e11e:	add    QWORD PTR [r14+0x20],rcx
  40e122:	add    DWORD PTR [r14+0x28],0x1
  40e127:	jmp    40e12b <__swc_fn_7dafa2b1_000050_e33921d7+0x22b>
  40e129:	xor    eax,eax
  40e12b:	mov    r15,rax
  40e12e:	test   r15,r15
  40e131:	je     40e080 <__swc_fn_7dafa2b1_000050_e33921d7+0x180>
  40e137:	mov    rax,r15
  40e13a:	add    rsp,0x1f8
  40e141:	pop    r15
  40e143:	pop    r14
  40e145:	pop    r13
  40e147:	pop    r12
  40e149:	pop    rdi
  40e14a:	pop    rsi
  40e14b:	ret
  40e14c:	add    BYTE PTR [rax],al
	...

000000000040e150 <__swc_fn_7dafa2b1_000053_a8a124d6>:
  40e150:	push   rsi
  40e151:	push   rdi
  40e152:	push   r12
  40e154:	mov    rsi,rdx
  40e157:	mov    rax,rdx
  40e15a:	shr    rax,0xc
  40e15e:	movabs rdx,0x9e3779b97f4a7c15
  40e168:	imul   rax,rdx
  40e16c:	shr    rax,0x20
  40e170:	lea    rax,[rax*8+0x0]
  40e178:	shr    rax,0x20
  40e17c:	lea    rax,[rax*8+0x0]
  40e184:	lea    rax,[rcx+rax*8+0x40]
  40e189:	xor    edx,edx
  40e18b:	test   dl,dl
  40e18d:	lea    rdi,[rcx+0x8]
  40e191:	cmove  rdi,rax
  40e195:	xor    edx,edx
  40e197:	test   dl,dl
  40e199:	lea    r12,[rcx+0x30]
  40e19d:	lea    rax,[rax+0x8]
  40e1a1:	cmove  r12,rax
  40e1a5:	mov    rcx,rdi
  40e1a8:	call   4098a0 <__swc_fn_7dafa2b1_000135_1fec60ac>
  40e1ad:	mov    QWORD PTR [rsi+0x30],0x0
  40e1b5:	mov    rax,QWORD PTR [r12]
  40e1b9:	mov    QWORD PTR [rsi+0x38],rax
  40e1bd:	test   rax,rax
  40e1c0:	je     40e1ca <__swc_fn_7dafa2b1_000053_a8a124d6+0x7a>
  40e1c2:	mov    rax,QWORD PTR [rsi+0x38]
  40e1c6:	mov    QWORD PTR [rax+0x30],rsi
  40e1ca:	mov    QWORD PTR [r12],rsi
  40e1ce:	mov    rcx,rdi
  40e1d1:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  40e1d6:	pop    r12
  40e1d8:	pop    rdi
  40e1d9:	pop    rsi
  40e1da:	ret
  40e1db:	add    BYTE PTR [rax],al
  40e1dd:	add    BYTE PTR [rax],al
	...

000000000040e1e0 <__swc_fn_7dafa2b1_000056_cfedf3f4>:
  40e1e0:	lea    rax,[rdx+rdx*4]
  40e1e4:	lea    rax,[rcx+rax*8+0x268]
  40e1ec:	mov    rdx,QWORD PTR [rax+0x10]
  40e1f0:	sub    QWORD PTR [rcx+0x2a68],rdx
  40e1f7:	sub    QWORD PTR [rcx+0x2a70],0x1
  40e1ff:	mov    rdx,QWORD PTR [rcx+0x2a70]
  40e206:	lea    rdx,[rdx+rdx*4]
  40e20a:	lea    rdx,[rcx+rdx*8+0x268]
  40e212:	vmovups xmm0,XMMWORD PTR [rdx]
  40e216:	vmovups XMMWORD PTR [rax],xmm0
  40e21a:	vmovups xmm0,XMMWORD PTR [rdx+0x10]
  40e21f:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e224:	mov    rcx,QWORD PTR [rdx+0x20]
  40e228:	mov    QWORD PTR [rax+0x20],rcx
  40e22c:	ret
  40e22d:	add    BYTE PTR [rax],al
	...

000000000040e230 <__swc_fn_7dafa2b1_000059_c8e1ff6b>:
  40e230:	push   rsi
  40e231:	push   rdi
  40e232:	push   r12
  40e234:	push   r13
  40e236:	sub    rsp,0x8
  40e23a:	mov    rsi,r8
  40e23d:	mov    rdi,rcx
  40e240:	mov    r12,rdx
  40e243:	xor    r13d,r13d
  40e246:	cs nop WORD PTR [rax+rax*1+0x0]
  40e250:	mov    eax,DWORD PTR [r12+0x730]
  40e258:	cmp    r13d,eax
  40e25b:	jae    40e2c1 <__swc_fn_7dafa2b1_000059_c8e1ff6b+0x91>
  40e25d:	lea    rax,[r13+r13*4+0x0]
  40e262:	lea    rax,[r12+rax*8+0x738]
  40e26a:	mov    rdx,QWORD PTR [rax]
  40e26d:	mov    r8,QWORD PTR [rax+0x8]
  40e271:	mov    r9,QWORD PTR [rax+0x10]
  40e275:	cmp    QWORD PTR [rax+0x20],rsi
  40e279:	jb     40e280 <__swc_fn_7dafa2b1_000059_c8e1ff6b+0x50>
  40e27b:	inc    r13d
  40e27e:	jmp    40e250 <__swc_fn_7dafa2b1_000059_c8e1ff6b+0x20>
  40e280:	sub    DWORD PTR [r12+0x730],0x1
  40e289:	mov    ecx,DWORD PTR [r12+0x730]
  40e291:	lea    rcx,[rcx+rcx*4]
  40e295:	lea    rcx,[r12+rcx*8+0x738]
  40e29d:	vmovups xmm0,XMMWORD PTR [rcx]
  40e2a1:	vmovups XMMWORD PTR [rax],xmm0
  40e2a5:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
  40e2aa:	vmovups XMMWORD PTR [rax+0x10],xmm0
  40e2af:	mov    rcx,QWORD PTR [rcx+0x20]
  40e2b3:	mov    QWORD PTR [rax+0x20],rcx
  40e2b7:	mov    rcx,rdi
  40e2ba:	call   407750 <__swc_fn_7dafa2b1_000039_05a50673>
  40e2bf:	jmp    40e250 <__swc_fn_7dafa2b1_000059_c8e1ff6b+0x20>
  40e2c1:	add    rsp,0x8
  40e2c5:	pop    r13
  40e2c7:	pop    r12
  40e2c9:	pop    rdi
  40e2ca:	pop    rsi
  40e2cb:	ret
  40e2cc:	add    BYTE PTR [rax],al
	...

000000000040e2d0 <__swc_fn_7dafa2b1_000062_baa48dba>:
  40e2d0:	push   rsi
  40e2d1:	push   rdi
  40e2d2:	push   r12
  40e2d4:	push   r13
  40e2d6:	push   r14
  40e2d8:	mov    rsi,rcx
  40e2db:	mov    rdi,rdx
  40e2de:	mov    r12,QWORD PTR [rdi]
  40e2e1:	mov    r13,QWORD PTR [rdi+0x18]
  40e2e5:	mov    rax,r12
  40e2e8:	add    rax,QWORD PTR [rdi+0x8]
  40e2ec:	sub    rax,r13
  40e2ef:	cmp    r8,rax
  40e2f2:	jbe    40e2fd <__swc_fn_7dafa2b1_000062_baa48dba+0x2d>
  40e2f4:	pop    r14
  40e2f6:	pop    r13
  40e2f8:	pop    r12
  40e2fa:	pop    rdi
  40e2fb:	pop    rsi
  40e2fc:	ret
  40e2fd:	lea    rax,[r13+r8*1+0x0]
  40e302:	sub    rax,r12
  40e305:	mov    ecx,0x1000
  40e30a:	test   ecx,ecx
  40e30c:	mov    edx,0x8
  40e311:	cmove  ecx,edx
  40e314:	dec    rcx
  40e317:	mov    rdx,0xffffffffffffffff
  40e31e:	sub    rdx,rcx
  40e321:	cmp    rax,rdx
  40e324:	jbe    40e32b <__swc_fn_7dafa2b1_000062_baa48dba+0x5b>
  40e326:	xor    r14d,r14d
  40e329:	jmp    40e336 <__swc_fn_7dafa2b1_000062_baa48dba+0x66>
  40e32b:	add    rax,rcx
  40e32e:	andn   rax,rcx,rax
  40e333:	mov    r14,rax
  40e336:	mov    rax,QWORD PTR [rdi+0x10]
  40e33a:	cmp    r14,rax
  40e33d:	ja     40e348 <__swc_fn_7dafa2b1_000062_baa48dba+0x78>
  40e33f:	pop    r14
  40e341:	pop    r13
  40e343:	pop    r12
  40e345:	pop    rdi
  40e346:	pop    rsi
  40e347:	ret
  40e348:	mov    rax,r12
  40e34b:	add    rax,QWORD PTR [rdi+0x10]
  40e34f:	mov    rdx,r14
  40e352:	sub    rdx,QWORD PTR [rdi+0x10]
  40e356:	mov    rcx,rax
  40e359:	call   4072a0 <__swc_fn_7dafa2b1_000003_644dadb7>
  40e35e:	test   al,al
  40e360:	jne    40e36b <__swc_fn_7dafa2b1_000062_baa48dba+0x9b>
  40e362:	pop    r14
  40e364:	pop    r13
  40e366:	pop    r12
  40e368:	pop    rdi
  40e369:	pop    rsi
  40e36a:	ret
  40e36b:	add    r12,r14
  40e36e:	sub    r12,r13
  40e371:	mov    rcx,r12
  40e374:	sub    rcx,QWORD PTR [rdi+0x28]
  40e378:	mov    rdx,QWORD PTR [rsi+0x250]
  40e37f:	nop
  40e380:	lea    r8,[rdx+rcx*1]
  40e384:	mov    rax,rdx
  40e387:	lock cmpxchg QWORD PTR [rsi+0x250],r8
  40e390:	cmp    rax,rdx
  40e393:	je     40e39a <__swc_fn_7dafa2b1_000062_baa48dba+0xca>
  40e395:	mov    rdx,rax
  40e398:	jmp    40e380 <__swc_fn_7dafa2b1_000062_baa48dba+0xb0>
  40e39a:	mov    QWORD PTR [rdi+0x10],r14
  40e39e:	mov    QWORD PTR [rdi+0x28],r12
  40e3a2:	pop    r14
  40e3a4:	pop    r13
  40e3a6:	pop    r12
  40e3a8:	pop    rdi
  40e3a9:	pop    rsi
  40e3aa:	ret
  40e3ab:	add    BYTE PTR [rax],al
  40e3ad:	add    BYTE PTR [rax],al
	...

000000000040e3b0 <__swc_fn_7dafa2b1_000065_cd9dd53e>:
  40e3b0:	push   rbx
  40e3b1:	push   rsi
  40e3b2:	push   rdi
  40e3b3:	push   r12
  40e3b5:	push   r13
  40e3b7:	sub    rsp,0xe0
  40e3be:	mov    rbx,rdx
  40e3c1:	mov    rsi,rcx
  40e3c4:	cmp    DWORD PTR [rbx+0x58],0x0
  40e3c8:	je     40e3ec <__swc_fn_7dafa2b1_000065_cd9dd53e+0x3c>
  40e3ca:	mov    eax,DWORD PTR [rbx+0x58]
  40e3cd:	sub    eax,0x1
  40e3d0:	test   DWORD PTR [rbx+0x58],eax
  40e3d3:	je     40e3ec <__swc_fn_7dafa2b1_000065_cd9dd53e+0x3c>
  40e3d5:	mov    QWORD PTR [rbx+0x40],0x0
  40e3dd:	add    rsp,0xe0
  40e3e4:	pop    r13
  40e3e6:	pop    r12
  40e3e8:	pop    rdi
  40e3e9:	pop    rsi
  40e3ea:	pop    rbx
  40e3eb:	ret
  40e3ec:	mov    rax,QWORD PTR [rbx+0x40]
  40e3f0:	test   rax,rax
  40e3f3:	jne    40e40f <__swc_fn_7dafa2b1_000065_cd9dd53e+0x5f>
  40e3f5:	mov    rcx,rsi
  40e3f8:	mov    rdx,rbx
  40e3fb:	call   40b850 <__swc_fn_7dafa2b1_000064_6905bec4>
  40e400:	add    rsp,0xe0
  40e407:	pop    r13
  40e409:	pop    r12
  40e40b:	pop    rdi
  40e40c:	pop    rsi
  40e40d:	pop    rbx
  40e40e:	ret
  40e40f:	cmp    QWORD PTR [rbx+0x48],0x0
  40e414:	jne    40e430 <__swc_fn_7dafa2b1_000065_cd9dd53e+0x80>
  40e416:	mov    rcx,rsi
  40e419:	mov    rdx,rbx
  40e41c:	call   407f90 <__swc_fn_7dafa2b1_000066_77c6e829>
  40e421:	add    rsp,0xe0
  40e428:	pop    r13
  40e42a:	pop    r12
  40e42c:	pop    rdi
  40e42d:	pop    rsi
  40e42e:	pop    rbx
  40e42f:	ret
  40e430:	mov    rdi,QWORD PTR [rbx+0x40]
  40e434:	lea    rax,[rip+0x14c35]        # 423070 <__swc_bss_base_7dafa2b1+0x30>
  40e43b:	mov    rcx,rdi
  40e43e:	sub    rcx,QWORD PTR [rax+0x8]
  40e442:	mov    rax,QWORD PTR [rip+0x14c37]        # 423080 <__swc_bss_base_7dafa2b1+0x40>
  40e449:	cmp    rcx,rax
  40e44c:	jae    40e478 <__swc_fn_7dafa2b1_000065_cd9dd53e+0xc8>
  40e44e:	mov    rax,rdi
  40e451:	and    rax,0xffffffffffc00000
  40e458:	mov    rcx,rdi
  40e45b:	shr    rcx,0x10
  40e45f:	and    ecx,0x3f
  40e462:	mov    edx,DWORD PTR [rax+0x28]
  40e465:	shrx   ecx,ecx,edx
  40e46a:	shl    rcx,0x4
  40e46e:	lea    r12,[rax+rcx*8+0x80]
  40e476:	jmp    40e483 <__swc_fn_7dafa2b1_000065_cd9dd53e+0xd3>
  40e478:	mov    rcx,rdi
  40e47b:	call   40a8d0 <__swc_fn_7dafa2b1_000022_77c2d682>
  40e480:	mov    r12,rax
  40e483:	test   r12,r12
  40e486:	je     40e495 <__swc_fn_7dafa2b1_000065_cd9dd53e+0xe5>
  40e488:	mov    eax,DWORD PTR [r12+0x2c]
  40e48d:	mov    r9d,eax
  40e490:	mov    r13,rax
  40e493:	jmp    40e514 <__swc_fn_7dafa2b1_000065_cd9dd53e+0x164>
  40e495:	mov    rcx,rsi
  40e498:	mov    rdx,rdi
  40e49b:	call   40aee0 <__swc_fn_7dafa2b1_000052_26c6c1c4>
  40e4a0:	mov    rcx,QWORD PTR [rax+0x28]
  40e4a4:	mov    r9,rcx
  40e4a7:	mov    rdx,QWORD PTR [rax+0x20]
  40e4ab:	mov    r13,rdx
  40e4ae:	cmp    QWORD PTR [rbx+0x48],rcx
  40e4b2:	jbe    40e4eb <__swc_fn_7dafa2b1_000065_cd9dd53e+0x13b>
  40e4b4:	mov    ecx,DWORD PTR [rax+0x48]
  40e4b7:	cmp    DWORD PTR [rbx+0x58],ecx
  40e4ba:	ja     40e4eb <__swc_fn_7dafa2b1_000065_cd9dd53e+0x13b>
  40e4bc:	mov    rcx,rsi
  40e4bf:	mov    rdx,rax
  40e4c2:	mov    r8,QWORD PTR [rbx+0x48]
  40e4c6:	mov    QWORD PTR [rsp+0xc8],r9
  40e4ce:	mov    QWORD PTR [rsp+0xd0],rax
  40e4d6:	call   40e2d0 <__swc_fn_7dafa2b1_000062_baa48dba>
  40e4db:	mov    r9,QWORD PTR [rsp+0xc8]
  40e4e3:	mov    rax,QWORD PTR [rsp+0xd0]
  40e4eb:	mov    rcx,QWORD PTR [rax+0x28]
  40e4ef:	cmp    QWORD PTR [rbx+0x48],rcx
  40e4f3:	ja     40e514 <__swc_fn_7dafa2b1_000065_cd9dd53e+0x164>
  40e4f5:	mov    ecx,DWORD PTR [rax+0x48]
  40e4f8:	cmp    DWORD PTR [rbx+0x58],ecx
  40e4fb:	ja     40e514 <__swc_fn_7dafa2b1_000065_cd9dd53e+0x164>
  40e4fd:	mov    rcx,QWORD PTR [rbx+0x48]
  40e501:	mov    QWORD PTR [rax+0x20],rcx
  40e505:	add    rsp,0xe0
  40e50c:	pop    r13
  40e50e:	pop    r12
  40e510:	pop    rdi
  40e511:	pop    rsi
  40e512:	pop    rbx
  40e513:	ret
  40e514:	test   r12,r12
  40e517:	je     40e549 <__swc_fn_7dafa2b1_000065_cd9dd53e+0x199>
  40e519:	cmp    QWORD PTR [rbx+0x48],r9
  40e51d:	ja     40e549 <__swc_fn_7dafa2b1_000065_cd9dd53e+0x199>
  40e51f:	cmp    DWORD PTR [rbx+0x58],0x40
  40e523:	ja     40e549 <__swc_fn_7dafa2b1_000065_cd9dd53e+0x199>
  40e525:	cmp    DWORD PTR [rbx+0x58],0x0
  40e529:	je     40e536 <__swc_fn_7dafa2b1_000065_cd9dd53e+0x186>
  40e52b:	mov    ecx,DWORD PTR [rbx+0x58]
  40e52e:	dec    rcx
  40e531:	test   rdi,rcx
  40e534:	jne    40e549 <__swc_fn_7dafa2b1_000065_cd9dd53e+0x199>
  40e536:	mov    QWORD PTR [rbx+0x40],rdi
  40e53a:	add    rsp,0xe0
  40e541:	pop    r13
  40e543:	pop    r12
  40e545:	pop    rdi
  40e546:	pop    rsi
  40e547:	pop    rbx
  40e548:	ret
  40e549:	vmovups xmm0,XMMWORD PTR [rbx]
  40e54d:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40e553:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40e558:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40e55e:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40e563:	vmovups XMMWORD PTR [rsp+0x28],xmm0
  40e569:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40e56e:	vmovups XMMWORD PTR [rsp+0x38],xmm0
  40e574:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40e579:	vmovups XMMWORD PTR [rsp+0x48],xmm0
  40e57f:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40e584:	vmovups XMMWORD PTR [rsp+0x58],xmm0
  40e58a:	mov    QWORD PTR [rsp+0x48],0x0
  40e593:	mov    rcx,rsi
  40e596:	lea    rdx,[rsp+0x8]
  40e59b:	call   40b850 <__swc_fn_7dafa2b1_000064_6905bec4>
  40e5a0:	mov    rax,QWORD PTR [rsp+0x48]
  40e5a5:	test   rax,rax
  40e5a8:	jne    40e5c1 <__swc_fn_7dafa2b1_000065_cd9dd53e+0x211>
  40e5aa:	mov    QWORD PTR [rbx+0x40],0x0
  40e5b2:	add    rsp,0xe0
  40e5b9:	pop    r13
  40e5bb:	pop    r12
  40e5bd:	pop    rdi
  40e5be:	pop    rsi
  40e5bf:	pop    rbx
  40e5c0:	ret
  40e5c1:	mov    rax,QWORD PTR [rbx+0x48]
  40e5c5:	cmp    r13,rax
  40e5c8:	cmovbe rax,r13
  40e5cc:	mov    rcx,QWORD PTR [rsp+0x48]
  40e5d1:	mov    rdx,rdi
  40e5d4:	mov    r8,rax
  40e5d7:	call   4090e0 <__swc_fn_7dafa2b1_000105_b7aef7c0>
  40e5dc:	vmovups xmm0,XMMWORD PTR [rbx]
  40e5e0:	vmovups XMMWORD PTR [rsp+0x68],xmm0
  40e5e6:	vmovups xmm0,XMMWORD PTR [rbx+0x10]
  40e5eb:	vmovups XMMWORD PTR [rsp+0x78],xmm0
  40e5f1:	vmovups xmm0,XMMWORD PTR [rbx+0x20]
  40e5f6:	vmovups XMMWORD PTR [rsp+0x88],xmm0
  40e5ff:	vmovups xmm0,XMMWORD PTR [rbx+0x30]
  40e604:	vmovups XMMWORD PTR [rsp+0x98],xmm0
  40e60d:	vmovups xmm0,XMMWORD PTR [rbx+0x40]
  40e612:	vmovups XMMWORD PTR [rsp+0xa8],xmm0
  40e61b:	vmovups xmm0,XMMWORD PTR [rbx+0x50]
  40e620:	vmovups XMMWORD PTR [rsp+0xb8],xmm0
  40e629:	mov    QWORD PTR [rsp+0xa8],rdi
  40e631:	mov    rcx,rsi
  40e634:	lea    rdx,[rsp+0x68]
  40e639:	call   407f90 <__swc_fn_7dafa2b1_000066_77c6e829>
  40e63e:	mov    rax,QWORD PTR [rsp+0x48]
  40e643:	mov    QWORD PTR [rbx+0x40],rax
  40e647:	add    rsp,0xe0
  40e64e:	pop    r13
  40e650:	pop    r12
  40e652:	pop    rdi
  40e653:	pop    rsi
  40e654:	pop    rbx
  40e655:	ret
	...

000000000040e660 <__swc_fn_7dafa2b1_000068_557d6092>:
  40e660:	push   r12
  40e662:	push   rdi
  40e663:	push   rsi
  40e664:	push   r13
  40e666:	push   r14
  40e668:	sub    rsp,0x190
  40e66f:	vmovups XMMWORD PTR [rsp+0xe8],xmm6
  40e678:	vmovups XMMWORD PTR [rsp+0xf8],xmm7
  40e681:	vmovups XMMWORD PTR [rsp+0x108],xmm8
  40e68a:	vmovups XMMWORD PTR [rsp+0x118],xmm9
  40e693:	vmovups XMMWORD PTR [rsp+0x128],xmm10
  40e69c:	vmovups XMMWORD PTR [rsp+0x138],xmm11
  40e6a5:	vmovups XMMWORD PTR [rsp+0x148],xmm12
  40e6ae:	vmovups XMMWORD PTR [rsp+0x158],xmm13
  40e6b7:	vmovups XMMWORD PTR [rsp+0x168],xmm14
  40e6c0:	vmovups XMMWORD PTR [rsp+0x178],xmm15
  40e6c9:	mov    r12,rcx
  40e6cc:	lea    rax,[rip+0x1292d]        # 421000 <__swc_data_base_7dafa2b1>
  40e6d3:	mov    rax,QWORD PTR [rax]
  40e6d6:	cmp    rax,0xffffffffffffffff
  40e6da:	je     40e6e9 <__swc_fn_7dafa2b1_000068_557d6092+0x89>
  40e6dc:	mov    eax,eax
  40e6de:	mov    edi,eax
  40e6e0:	xor    eax,eax
  40e6e2:	call   407000 <pthread_getspecific@plt>
  40e6e7:	jmp    40e6eb <__swc_fn_7dafa2b1_000068_557d6092+0x8b>
  40e6e9:	xor    eax,eax
  40e6eb:	test   rax,rax
  40e6ee:	jne    40e6fd <__swc_fn_7dafa2b1_000068_557d6092+0x9d>
  40e6f0:	call   40a9a0 <__swc_fn_7dafa2b1_000031_ed8d61a9>
  40e6f5:	mov    rcx,rax
  40e6f8:	call   40fe20 <__swc_fn_7dafa2b1_000128_9c45d2d7>
  40e6fd:	test   rax,rax
  40e700:	je     40e726 <__swc_fn_7dafa2b1_000068_557d6092+0xc6>
  40e702:	cmp    QWORD PTR [rax],r12
  40e705:	jne    40e726 <__swc_fn_7dafa2b1_000068_557d6092+0xc6>
  40e707:	xor    ecx,ecx
  40e709:	mov    QWORD PTR [rsp+0xc8],rax
  40e711:	call   407720 <__swc_fn_7dafa2b1_000033_7d7574b6>
  40e716:	mov    rdx,QWORD PTR [rsp+0xc8]
  40e71e:	mov    rcx,r12
  40e721:	call   407840 <__swc_fn_7dafa2b1_000042_70d5ab54>
  40e726:	lea    rsi,[r12+0x10]
  40e72b:	mov    rcx,rsi
  40e72e:	call   4098a0 <__swc_fn_7dafa2b1_000135_1fec60ac>
  40e733:	mov    rdi,QWORD PTR [r12+0x20]
  40e738:	test   rdi,rdi
  40e73b:	je     40e77e <__swc_fn_7dafa2b1_000068_557d6092+0x11e>
  40e73d:	nop    DWORD PTR [rax]
  40e740:	mov    rcx,r12
  40e743:	mov    rdx,rdi
  40e746:	call   40ab60 <__swc_fn_7dafa2b1_000043_3755033a>
  40e74b:	mov    rcx,r12
  40e74e:	mov    rdx,rdi
  40e751:	mov    r8,0xffffffffffffffff
  40e758:	call   40e230 <__swc_fn_7dafa2b1_000059_c8e1ff6b>
  40e75d:	mov    rcx,r12
  40e760:	mov    rdx,rdi
  40e763:	mov    r8d,0x9b8
  40e769:	mov    r9d,0x9b8
  40e76f:	call   407750 <__swc_fn_7dafa2b1_000039_05a50673>
  40e774:	mov    rdi,QWORD PTR [r12+0x20]
  40e779:	test   rdi,rdi
  40e77c:	jne    40e740 <__swc_fn_7dafa2b1_000068_557d6092+0xe0>
  40e77e:	xor    eax,eax
  40e780:	xchg   QWORD PTR [r12+0x2a80],rax
  40e788:	test   rax,rax
  40e78b:	je     40e7b1 <__swc_fn_7dafa2b1_000068_557d6092+0x151>
  40e78d:	cs nop WORD PTR [rax+rax*1+0x0]
  40e797:	nop    WORD PTR [rax+rax*1+0x0]
  40e7a0:	mov    rcx,rax
  40e7a3:	mov    rax,QWORD PTR [rax+0x78]
  40e7a7:	xor    edx,edx
  40e7a9:	xchg   DWORD PTR [rcx+0x70],edx
  40e7ac:	test   rax,rax
  40e7af:	jne    40e7a0 <__swc_fn_7dafa2b1_000068_557d6092+0x140>
  40e7b1:	mov    rax,QWORD PTR [r12+0x18]
  40e7b6:	mov    rdi,rax
  40e7b9:	test   rdi,rdi
  40e7bc:	je     40e851 <__swc_fn_7dafa2b1_000068_557d6092+0x1f1>
  40e7c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40e7cc:	nop    DWORD PTR [rax+0x0]
  40e7d0:	mov    rax,QWORD PTR [rdi+0x10]
  40e7d4:	mov    r8d,DWORD PTR [rdi+0x2c]
  40e7d8:	xor    r9d,r9d
  40e7db:	test   r8,r8
  40e7de:	jbe    40e83d <__swc_fn_7dafa2b1_000068_557d6092+0x1dd>
  40e7e0:	mov    ecx,r9d
  40e7e3:	shl    rcx,0x4
  40e7e7:	lea    rdx,[rdi+rcx*8+0x80]
  40e7ef:	cmp    BYTE PTR [rdx+0x3b],0x0
  40e7f3:	je     40e834 <__swc_fn_7dafa2b1_000068_557d6092+0x1d4>
  40e7f5:	mov    DWORD PTR [rdx+0x28],0x0
  40e7fc:	mov    rcx,rdi
  40e7ff:	mov    QWORD PTR [rsp+0xd0],rax
  40e807:	mov    QWORD PTR [rsp+0xd8],r8
  40e80f:	mov    QWORD PTR [rsp+0xe0],r9
  40e817:	call   40d960 <__swc_fn_7dafa2b1_000014_1acdaf22>
  40e81c:	mov    rax,QWORD PTR [rsp+0xd0]
  40e824:	mov    r8,QWORD PTR [rsp+0xd8]
  40e82c:	mov    r9,QWORD PTR [rsp+0xe0]
  40e834:	add    r9,0x1
  40e838:	cmp    r9,r8
  40e83b:	jb     40e7e0 <__swc_fn_7dafa2b1_000068_557d6092+0x180>
  40e83d:	mov    rcx,rdi
  40e840:	mov    rdi,rax
  40e843:	call   407630 <__swc_fn_7dafa2b1_000021_fe13ecad>
  40e848:	test   rdi,rdi
  40e84b:	jne    40e7d0 <__swc_fn_7dafa2b1_000068_557d6092+0x170>
  40e851:	mov    QWORD PTR [r12+0x18],0x0
  40e85a:	mov    QWORD PTR [r12+0x28],0x0
  40e863:	mov    rcx,rsi
  40e866:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  40e86b:	mov    esi,0x8
  40e870:	xor    edi,edi
  40e872:	test   rsi,rsi
  40e875:	je     40e8d2 <__swc_fn_7dafa2b1_000068_557d6092+0x272>
  40e87b:	nop    DWORD PTR [rax+rax*1+0x0]
  40e880:	lea    r13,[rdi*8+0x0]
  40e888:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40e88d:	test   r14,r14
  40e890:	je     40e8c8 <__swc_fn_7dafa2b1_000068_557d6092+0x268>
  40e892:	cs nop WORD PTR [rax+rax*1+0x0]
  40e89c:	nop    DWORD PTR [rax+0x0]
  40e8a0:	mov    rcx,r12
  40e8a3:	mov    rdx,r14
  40e8a6:	call   407df0 <__swc_fn_7dafa2b1_000054_1dfec8f6>
  40e8ab:	mov    rcx,r12
  40e8ae:	mov    rdx,QWORD PTR [r14]
  40e8b1:	mov    r8,QWORD PTR [r14+0x8]
  40e8b5:	mov    r9,QWORD PTR [r14+0x10]
  40e8b9:	call   407750 <__swc_fn_7dafa2b1_000039_05a50673>
  40e8be:	mov    r14,QWORD PTR [r12+r13*8+0x48]
  40e8c3:	test   r14,r14
  40e8c6:	jne    40e8a0 <__swc_fn_7dafa2b1_000068_557d6092+0x240>
  40e8c8:	add    rdi,0x1
  40e8cc:	sub    rsi,0x1
  40e8d0:	jne    40e880 <__swc_fn_7dafa2b1_000068_557d6092+0x220>
  40e8d2:	mov    rcx,r12
  40e8d5:	call   407ec0 <__swc_fn_7dafa2b1_000060_9d59636e>
  40e8da:	lea    rcx,[r12+0x250]
  40e8e2:	mov    rdx,QWORD PTR [rcx]
  40e8e5:	mov    r8,QWORD PTR [r12+0x250]
  40e8ed:	nop    DWORD PTR [rax]
  40e8f0:	mov    r9,r8
  40e8f3:	sub    r9,rdx
  40e8f6:	mov    rax,r8
  40e8f9:	lock cmpxchg QWORD PTR [rcx],r9
  40e8fe:	cmp    rax,r8
  40e901:	je     40e908 <__swc_fn_7dafa2b1_000068_557d6092+0x2a8>
  40e903:	mov    r8,rax
  40e906:	jmp    40e8f0 <__swc_fn_7dafa2b1_000068_557d6092+0x290>
  40e908:	vmovups xmm6,XMMWORD PTR [rsp+0xe8]
  40e911:	vmovups xmm7,XMMWORD PTR [rsp+0xf8]
  40e91a:	vmovups xmm8,XMMWORD PTR [rsp+0x108]
  40e923:	vmovups xmm9,XMMWORD PTR [rsp+0x118]
  40e92c:	vmovups xmm10,XMMWORD PTR [rsp+0x128]
  40e935:	vmovups xmm11,XMMWORD PTR [rsp+0x138]
  40e93e:	vmovups xmm12,XMMWORD PTR [rsp+0x148]
  40e947:	vmovups xmm13,XMMWORD PTR [rsp+0x158]
  40e950:	vmovups xmm14,XMMWORD PTR [rsp+0x168]
  40e959:	vmovups xmm15,XMMWORD PTR [rsp+0x178]
  40e962:	add    rsp,0x190
  40e969:	pop    r14
  40e96b:	pop    r13
  40e96d:	pop    rsi
  40e96e:	pop    rdi
  40e96f:	pop    r12
  40e971:	ret
	...

000000000040e980 <__swc_fn_7dafa2b1_000071_7e144e9b>:
  40e980:	sub    rsp,0x8
  40e984:	mov    QWORD PTR [rdx+0x40],0x0
  40e98c:	call   40b850 <__swc_fn_7dafa2b1_000064_6905bec4>
  40e991:	add    rsp,0x8
  40e995:	ret
	...

000000000040e9a0 <__swc_fn_7dafa2b1_000074_9eaf4878>:
  40e9a0:	sub    rsp,0x8
  40e9a4:	call   407f90 <__swc_fn_7dafa2b1_000066_77c6e829>
  40e9a9:	add    rsp,0x8
  40e9ad:	ret
	...

000000000040e9b0 <__swc_fn_7dafa2b1_000077_e793b5e1>:
  40e9b0:	push   rbx
  40e9b1:	push   rsi
  40e9b2:	push   rdi
  40e9b3:	push   r12
  40e9b5:	push   r13
  40e9b7:	push   r14
  40e9b9:	push   r15
  40e9bb:	sub    rsp,0x20
  40e9bf:	mov    rbx,r11
  40e9c2:	mov    rsi,rcx
  40e9c5:	mov    rdi,rdx
  40e9c8:	mov    r12,r8
  40e9cb:	mov    r13,r9
  40e9ce:	mov    r14,r10
  40e9d1:	mov    rcx,QWORD PTR [rip+0x17368]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40e9d8:	test   rcx,rcx
  40e9db:	jne    40e9ed <__swc_fn_7dafa2b1_000077_e793b5e1+0x3d>
  40e9dd:	call   40a1a0 <__swc_fn_7dafa2b1_000165_e09accff>
  40e9e2:	lea    rcx,[rax+0x1]
  40e9e6:	mov    QWORD PTR [rip+0x17353],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40e9ed:	dec    rcx
  40e9f0:	call   4118a0 <__swc_fn_7dafa2b1_000167_3130645d>
  40e9f5:	mov    r15,rax
  40e9f8:	lea    r11,[rip+0x14841]        # 423240 <__swc_bss_base_7dafa2b1+0x200>
  40e9ff:	mov    rcx,r11
  40ea02:	call   407740 <__swc_fn_7dafa2b1_000036_62160bb3>
  40ea07:	test   al,al
  40ea09:	jne    40ea1a <__swc_fn_7dafa2b1_000077_e793b5e1+0x6a>
  40ea0b:	mov    rcx,r11
  40ea0e:	call   40aa00 <__swc_fn_7dafa2b1_000034_c72914a2>
  40ea13:	lea    r11,[rip+0x14826]        # 423240 <__swc_bss_base_7dafa2b1+0x200>
  40ea1a:	mov    rcx,r11
  40ea1d:	mov    rdx,rsi
  40ea20:	mov    r8,rdi
  40ea23:	mov    r9,r12
  40ea26:	mov    r10,r13
  40ea29:	mov    rsi,r11
  40ea2c:	mov    r11,r14
  40ea2f:	call   40dcd0 <__swc_fn_7dafa2b1_000035_6105596e>
  40ea34:	test   bl,bl
  40ea36:	je     40ea5d <__swc_fn_7dafa2b1_000077_e793b5e1+0xad>
  40ea38:	mov    QWORD PTR [rsp+0x8],rsi
  40ea3d:	lea    rax,[rip+0x370c]        # 412150 <__swc_rdata_base_7dafa2b1+0x40>
  40ea44:	mov    QWORD PTR [rsp+0x10],rax
  40ea49:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40ea4f:	vmovups XMMWORD PTR [r15],xmm0
  40ea54:	vmovups XMMWORD PTR [r15+0xc8],xmm0
  40ea5d:	mov    rax,rsi
  40ea60:	add    rsp,0x20
  40ea64:	pop    r15
  40ea66:	pop    r14
  40ea68:	pop    r13
  40ea6a:	pop    r12
  40ea6c:	pop    rdi
  40ea6d:	pop    rsi
  40ea6e:	pop    rbx
  40ea6f:	ret

000000000040ea70 <__swc_fn_7dafa2b1_000080_851c599a>:
  40ea70:	sub    rsp,0x8
  40ea74:	mov    rax,rcx
  40ea77:	test   rcx,rcx
  40ea7a:	jne    40ea81 <__swc_fn_7dafa2b1_000080_851c599a+0x11>
  40ea7c:	add    rsp,0x8
  40ea80:	ret
  40ea81:	lea    rcx,[rax-0x10]
  40ea85:	mov    rax,QWORD PTR [rax-0x10]
  40ea89:	mov    rdx,rax
  40ea8c:	call   40fad0 <__swc_fn_7dafa2b1_000113_25e345b1>
  40ea91:	add    rsp,0x8
  40ea95:	ret
	...

000000000040eaa0 <__swc_fn_7dafa2b1_000083_fb84e43e>:
  40eaa0:	sub    rsp,0x8
  40eaa4:	xor    r11d,r11d
  40eaa7:	call   408250 <__swc_fn_7dafa2b1_000084_746bf146>
  40eaac:	add    rsp,0x8
  40eab0:	ret
	...

000000000040eac0 <__swc_fn_7dafa2b1_000086_ac8c6565>:
  40eac0:	push   rsi
  40eac1:	push   rdi
  40eac2:	push   r12
  40eac4:	push   r13
  40eac6:	push   r14
  40eac8:	push   r15
  40eaca:	sub    rsp,0x68
  40eace:	mov    rsi,r9
  40ead1:	mov    rdi,rcx
  40ead4:	mov    r12,rdx
  40ead7:	mov    r13,r8
  40eada:	cmp    r8,r9
  40eadd:	jne    40eb05 <__swc_fn_7dafa2b1_000086_ac8c6565+0x45>
  40eadf:	mov    rcx,rdi
  40eae2:	mov    rdx,r12
  40eae5:	xor    r8d,r8d
  40eae8:	call   4085a0 <__swc_fn_7dafa2b1_000090_9a1d717d>
  40eaed:	test   al,al
  40eaef:	je     40eb05 <__swc_fn_7dafa2b1_000086_ac8c6565+0x45>
  40eaf1:	mov    eax,0x1
  40eaf6:	add    rsp,0x68
  40eafa:	pop    r15
  40eafc:	pop    r14
  40eafe:	pop    r13
  40eb00:	pop    r12
  40eb02:	pop    rdi
  40eb03:	pop    rsi
  40eb04:	ret
  40eb05:	cmp    BYTE PTR [r12+0x2c],0xe
  40eb0b:	je     40eb1e <__swc_fn_7dafa2b1_000086_ac8c6565+0x5e>
  40eb0d:	xor    eax,eax
  40eb0f:	add    rsp,0x68
  40eb13:	pop    r15
  40eb15:	pop    r14
  40eb17:	pop    r13
  40eb19:	pop    r12
  40eb1b:	pop    rdi
  40eb1c:	pop    rsi
  40eb1d:	ret
  40eb1e:	mov    r14,QWORD PTR [r12+0x98]
  40eb26:	mov    rax,QWORD PTR [r12+0xa0]
  40eb2e:	mov    r12,rax
  40eb31:	xor    r15d,r15d
  40eb34:	test   r12,r12
  40eb37:	je     40eb9f <__swc_fn_7dafa2b1_000086_ac8c6565+0xdf>
  40eb39:	nop    DWORD PTR [rax+0x0]
  40eb40:	mov    QWORD PTR [rsp+0x58],r12
  40eb45:	lea    r12,[r15*8+0x0]
  40eb4d:	mov    rax,QWORD PTR [r14+r12*8+0x10]
  40eb52:	mov    rcx,rax
  40eb55:	call   40bfe0 <__swc_fn_7dafa2b1_000082_9f4f5092>
  40eb5a:	cmp    BYTE PTR [rax+0x2c],0xe
  40eb5e:	jne    40eb90 <__swc_fn_7dafa2b1_000086_ac8c6565+0xd0>
  40eb60:	mov    ecx,DWORD PTR [r14+r12*8+0x30]
  40eb65:	lea    r8,[r13+rcx*1+0x0]
  40eb6a:	mov    rcx,rdi
  40eb6d:	mov    rdx,rax
  40eb70:	mov    r9,rsi
  40eb73:	call   40eac0 <__swc_fn_7dafa2b1_000086_ac8c6565>
  40eb78:	test   al,al
  40eb7a:	je     40eb90 <__swc_fn_7dafa2b1_000086_ac8c6565+0xd0>
  40eb7c:	mov    eax,0x1
  40eb81:	add    rsp,0x68
  40eb85:	pop    r15
  40eb87:	pop    r14
  40eb89:	pop    r13
  40eb8b:	pop    r12
  40eb8d:	pop    rdi
  40eb8e:	pop    rsi
  40eb8f:	ret
  40eb90:	add    r15,0x1
  40eb94:	mov    r12,QWORD PTR [rsp+0x58]
  40eb99:	sub    r12,0x1
  40eb9d:	jne    40eb40 <__swc_fn_7dafa2b1_000086_ac8c6565+0x80>
  40eb9f:	xor    eax,eax
  40eba1:	add    rsp,0x68
  40eba5:	pop    r15
  40eba7:	pop    r14
  40eba9:	pop    r13
  40ebab:	pop    r12
  40ebad:	pop    rdi
  40ebae:	pop    rsi
  40ebaf:	ret

000000000040ebb0 <__swc_fn_7dafa2b1_000089_157b05de>:
  40ebb0:	push   rbp
  40ebb1:	push   rbx
  40ebb2:	push   rsi
  40ebb3:	push   rdi
  40ebb4:	push   r12
  40ebb6:	push   r13
  40ebb8:	push   r14
  40ebba:	push   r15
  40ebbc:	sub    rsp,0x38
  40ebc0:	mov    rbp,rsp
  40ebc3:	mov    rbx,r11
  40ebc6:	mov    rsi,rdx
  40ebc9:	mov    rdi,r8
  40ebcc:	mov    r12,r9
  40ebcf:	mov    QWORD PTR [rsp+0x18],r9
  40ebd4:	mov    r13,r10
  40ebd7:	movzx  r14d,BYTE PTR [rbp+0x80]
  40ebdf:	movzx  r15d,BYTE PTR [rbp+0x88]
  40ebe7:	test   r11,r11
  40ebea:	je     40ebf0 <__swc_fn_7dafa2b1_000089_157b05de+0x40>
  40ebec:	xor    eax,eax
  40ebee:	mov    BYTE PTR [rbx],al
  40ebf0:	test   r12,r12
  40ebf3:	je     40ebfe <__swc_fn_7dafa2b1_000089_157b05de+0x4e>
  40ebf5:	mov    QWORD PTR [r12+0x8],0x0
  40ebfe:	test   rcx,rcx
  40ec01:	je     40ec08 <__swc_fn_7dafa2b1_000089_157b05de+0x58>
  40ec03:	test   rsi,rsi
  40ec06:	jne    40ec1b <__swc_fn_7dafa2b1_000089_157b05de+0x6b>
  40ec08:	xor    eax,eax
  40ec0a:	add    rsp,0x38
  40ec0e:	pop    r15
  40ec10:	pop    r14
  40ec12:	pop    r13
  40ec14:	pop    r12
  40ec16:	pop    rdi
  40ec17:	pop    rsi
  40ec18:	pop    rbx
  40ec19:	pop    rbp
  40ec1a:	ret
  40ec1b:	call   40bfe0 <__swc_fn_7dafa2b1_000082_9f4f5092>
  40ec20:	mov    r12,rax
  40ec23:	mov    al,r15b
  40ec26:	test   r15b,r15b
  40ec29:	jne    40ec39 <__swc_fn_7dafa2b1_000089_157b05de+0x89>
  40ec2b:	mov    eax,DWORD PTR [r12+0x28]
  40ec30:	and    eax,0x10000
  40ec36:	setne  al
  40ec39:	lea    r15,[rsp+0x8]
  40ec3e:	mov    QWORD PTR [rsp+0x20],r15
  40ec43:	rex mov BYTE PTR [rsp+0x8],al
  40ec48:	test   DWORD PTR [rsi+0x28],0x400000
  40ec4f:	je     40ec87 <__swc_fn_7dafa2b1_000089_157b05de+0xd7>
  40ec51:	test   rsi,rsi
  40ec54:	je     40ec74 <__swc_fn_7dafa2b1_000089_157b05de+0xc4>
  40ec56:	mov    rax,QWORD PTR [rsi+0x38]
  40ec5a:	cmp    QWORD PTR [rax+0x10],rsi
  40ec5e:	jne    40ec74 <__swc_fn_7dafa2b1_000089_157b05de+0xc4>
  40ec60:	rex mov al,BYTE PTR [rsp+0x8]
  40ec65:	test   al,al
  40ec67:	sete   al
  40ec6a:	test   r14b,r14b
  40ec6d:	sete   cl
  40ec70:	test   al,cl
  40ec72:	je     40ec87 <__swc_fn_7dafa2b1_000089_157b05de+0xd7>
  40ec74:	xor    eax,eax
  40ec76:	add    rsp,0x38
  40ec7a:	pop    r15
  40ec7c:	pop    r14
  40ec7e:	pop    r13
  40ec80:	pop    r12
  40ec82:	pop    rdi
  40ec83:	pop    rsi
  40ec84:	pop    rbx
  40ec85:	pop    rbp
  40ec86:	ret
  40ec87:	mov    r15,r12
  40ec8a:	test   r14b,r14b
  40ec8d:	jne    40eca4 <__swc_fn_7dafa2b1_000089_157b05de+0xf4>
  40ec8f:	cmp    BYTE PTR [r12+0x2c],0x6
  40ec95:	jne    40eca4 <__swc_fn_7dafa2b1_000089_157b05de+0xf4>
  40ec97:	mov    rcx,QWORD PTR [r12+0x40]
  40ec9c:	call   40bfe0 <__swc_fn_7dafa2b1_000082_9f4f5092>
  40eca1:	mov    r15,rax
  40eca4:	test   r14b,r14b
  40eca7:	je     40ecad <__swc_fn_7dafa2b1_000089_157b05de+0xfd>
  40eca9:	mov    r15,QWORD PTR [r15+0x30]
  40ecad:	mov    rcx,rsi
  40ecb0:	call   40bfe0 <__swc_fn_7dafa2b1_000082_9f4f5092>
  40ecb5:	mov    rsi,rax
  40ecb8:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40ecbd:	je     40ecf4 <__swc_fn_7dafa2b1_000089_157b05de+0x144>
  40ecbf:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40ecc4:	je     40ecf4 <__swc_fn_7dafa2b1_000089_157b05de+0x144>
  40ecc6:	mov    eax,DWORD PTR [rsi+0x28]
  40ecc9:	and    eax,0x10000
  40eccf:	je     40ecf4 <__swc_fn_7dafa2b1_000089_157b05de+0x144>
  40ecd1:	rex mov al,BYTE PTR [rsp+0x8]
  40ecd6:	test   al,al
  40ecd8:	jne    40eced <__swc_fn_7dafa2b1_000089_157b05de+0x13d>
  40ecda:	xor    eax,eax
  40ecdc:	add    rsp,0x38
  40ece0:	pop    r15
  40ece2:	pop    r14
  40ece4:	pop    r13
  40ece6:	pop    r12
  40ece8:	pop    rdi
  40ece9:	pop    rsi
  40ecea:	pop    rbx
  40eceb:	pop    rbp
  40ecec:	ret
  40eced:	mov    rax,QWORD PTR [rsi+0x30]
  40ecf1:	mov    rsi,rax
  40ecf4:	mov    r14b,r13b
  40ecf7:	test   rbx,rbx
  40ecfa:	je     40ed30 <__swc_fn_7dafa2b1_000089_157b05de+0x180>
  40ecfc:	cmp    BYTE PTR [r12+0x2c],0x6
  40ed02:	jne    40ed30 <__swc_fn_7dafa2b1_000089_157b05de+0x180>
  40ed04:	lea    rdx,[rip+0x3475]        # 412180 <__swc_rdata_base_7dafa2b1+0x70>
  40ed0b:	mov    rcx,rsi
  40ed0e:	xor    r8d,r8d
  40ed11:	call   4085a0 <__swc_fn_7dafa2b1_000090_9a1d717d>
  40ed16:	test   al,al
  40ed18:	je     40ed30 <__swc_fn_7dafa2b1_000089_157b05de+0x180>
  40ed1a:	mov    BYTE PTR [rbx],0x1
  40ed1d:	xor    eax,eax
  40ed1f:	add    rsp,0x38
  40ed23:	pop    r15
  40ed25:	pop    r14
  40ed27:	pop    r13
  40ed29:	pop    r12
  40ed2b:	pop    rdi
  40ed2c:	pop    rsi
  40ed2d:	pop    rbx
  40ed2e:	pop    rbp
  40ed2f:	ret
  40ed30:	test   rdi,rdi
  40ed33:	jne    40ed4d <__swc_fn_7dafa2b1_000089_157b05de+0x19d>
  40ed35:	test   r13b,r13b
  40ed38:	jne    40ed4d <__swc_fn_7dafa2b1_000089_157b05de+0x19d>
  40ed3a:	xor    eax,eax
  40ed3c:	add    rsp,0x38
  40ed40:	pop    r15
  40ed42:	pop    r14
  40ed44:	pop    r13
  40ed46:	pop    r12
  40ed48:	pop    rdi
  40ed49:	pop    rsi
  40ed4a:	pop    rbx
  40ed4b:	pop    rbp
  40ed4c:	ret
  40ed4d:	rex cmp BYTE PTR [rsi+0x2c],0x6
  40ed52:	jne    40ee08 <__swc_fn_7dafa2b1_000089_157b05de+0x258>
  40ed58:	mov    rcx,r15
  40ed5b:	mov    rdx,rsi
  40ed5e:	xor    r8d,r8d
  40ed61:	call   4085a0 <__swc_fn_7dafa2b1_000090_9a1d717d>
  40ed66:	test   al,al
  40ed68:	jne    40ee08 <__swc_fn_7dafa2b1_000089_157b05de+0x258>
  40ed6e:	test   DWORD PTR [rsi+0x28],0x10000
  40ed75:	je     40ed93 <__swc_fn_7dafa2b1_000089_157b05de+0x1e3>
  40ed77:	rex mov al,BYTE PTR [rsp+0x8]
  40ed7c:	test   al,al
  40ed7e:	jne    40ed93 <__swc_fn_7dafa2b1_000089_157b05de+0x1e3>
  40ed80:	xor    eax,eax
  40ed82:	add    rsp,0x38
  40ed86:	pop    r15
  40ed88:	pop    r14
  40ed8a:	pop    r13
  40ed8c:	pop    r12
  40ed8e:	pop    rdi
  40ed8f:	pop    rsi
  40ed90:	pop    rbx
  40ed91:	pop    rbp
  40ed92:	ret
  40ed93:	test   rdi,rdi
  40ed96:	jne    40edab <__swc_fn_7dafa2b1_000089_157b05de+0x1fb>
  40ed98:	xor    eax,eax
  40ed9a:	add    rsp,0x38
  40ed9e:	pop    r15
  40eda0:	pop    r14
  40eda2:	pop    r13
  40eda4:	pop    r12
  40eda6:	pop    rdi
  40eda7:	pop    rsi
  40eda8:	pop    rbx
  40eda9:	pop    rbp
  40edaa:	ret
  40edab:	mov    rcx,QWORD PTR [rsi+0x40]
  40edaf:	call   40bfe0 <__swc_fn_7dafa2b1_000082_9f4f5092>
  40edb4:	mov    rsi,rax
  40edb7:	mov    rax,QWORD PTR [rdi]
  40edba:	mov    rdi,rax
  40edbd:	test   rax,rax
  40edc0:	jne    40ee03 <__swc_fn_7dafa2b1_000089_157b05de+0x253>
  40edc2:	test   rbx,rbx
  40edc5:	je     40ee03 <__swc_fn_7dafa2b1_000089_157b05de+0x253>
  40edc7:	mov    rcx,r15
  40edca:	mov    rdx,rsi
  40edcd:	xor    r8d,r8d
  40edd0:	call   4085a0 <__swc_fn_7dafa2b1_000090_9a1d717d>
  40edd5:	mov    rcx,rax
  40edd8:	test   al,al
  40edda:	jne    40edfc <__swc_fn_7dafa2b1_000089_157b05de+0x24c>
  40eddc:	mov    rcx,r15
  40eddf:	mov    rdx,rsi
  40ede2:	call   40c020 <__swc_fn_7dafa2b1_000085_88128f21>
  40ede7:	mov    rcx,rax
  40edea:	test   al,al
  40edec:	jne    40edfc <__swc_fn_7dafa2b1_000089_157b05de+0x24c>
  40edee:	mov    rcx,rsi
  40edf1:	mov    rdx,r15
  40edf4:	call   40c020 <__swc_fn_7dafa2b1_000085_88128f21>
  40edf9:	mov    rcx,rax
  40edfc:	test   cl,cl
  40edfe:	setne  al
  40ee01:	mov    BYTE PTR [rbx],al
  40ee03:	xor    eax,eax
  40ee05:	mov    r14b,al
  40ee08:	test   rdi,rdi
  40ee0b:	jne    40ee25 <__swc_fn_7dafa2b1_000089_157b05de+0x275>
  40ee0d:	test   r14b,r14b
  40ee10:	jne    40ee25 <__swc_fn_7dafa2b1_000089_157b05de+0x275>
  40ee12:	xor    eax,eax
  40ee14:	add    rsp,0x38
  40ee18:	pop    r15
  40ee1a:	pop    r14
  40ee1c:	pop    r13
  40ee1e:	pop    r12
  40ee20:	pop    rdi
  40ee21:	pop    rsi
  40ee22:	pop    rbx
  40ee23:	pop    rbp
  40ee24:	ret
  40ee25:	rex cmp BYTE PTR [rsi+0x2c],0x12
  40ee2a:	je     40ee36 <__swc_fn_7dafa2b1_000089_157b05de+0x286>
  40ee2c:	mov    r12,QWORD PTR [rsp+0x18]
  40ee31:	jmp    40eebe <__swc_fn_7dafa2b1_000089_157b05de+0x30e>
  40ee36:	mov    r12,QWORD PTR [rsp+0x18]
  40ee3b:	test   r12,r12
  40ee3e:	jne    40ee52 <__swc_fn_7dafa2b1_000089_157b05de+0x2a2>
  40ee40:	mov    rcx,r15
  40ee43:	mov    rdx,rsi
  40ee46:	xor    r8d,r8d
  40ee49:	call   4085a0 <__swc_fn_7dafa2b1_000090_9a1d717d>
  40ee4e:	test   al,al
  40ee50:	jne    40eebe <__swc_fn_7dafa2b1_000089_157b05de+0x30e>
  40ee52:	test   DWORD PTR [rsi+0x28],0x10000
  40ee59:	je     40ee77 <__swc_fn_7dafa2b1_000089_157b05de+0x2c7>
  40ee5b:	rex mov al,BYTE PTR [rsp+0x8]
  40ee60:	test   al,al
  40ee62:	jne    40ee77 <__swc_fn_7dafa2b1_000089_157b05de+0x2c7>
  40ee64:	xor    eax,eax
  40ee66:	add    rsp,0x38
  40ee6a:	pop    r15
  40ee6c:	pop    r14
  40ee6e:	pop    r13
  40ee70:	pop    r12
  40ee72:	pop    rdi
  40ee73:	pop    rsi
  40ee74:	pop    rbx
  40ee75:	pop    rbp
  40ee76:	ret
  40ee77:	test   rdi,rdi
  40ee7a:	jne    40ee8f <__swc_fn_7dafa2b1_000089_157b05de+0x2df>
  40ee7c:	xor    eax,eax
  40ee7e:	add    rsp,0x38
  40ee82:	pop    r15
  40ee84:	pop    r14
  40ee86:	pop    r13
  40ee88:	pop    r12
  40ee8a:	pop    rdi
  40ee8b:	pop    rsi
  40ee8c:	pop    rbx
  40ee8d:	pop    rbp
  40ee8e:	ret
  40ee8f:	cmp    QWORD PTR [rdi+0x8],0x0
  40ee94:	jne    40eea9 <__swc_fn_7dafa2b1_000089_157b05de+0x2f9>
  40ee96:	xor    eax,eax
  40ee98:	add    rsp,0x38
  40ee9c:	pop    r15
  40ee9e:	pop    r14
  40eea0:	pop    r13
  40eea2:	pop    r12
  40eea4:	pop    rdi
  40eea5:	pop    rsi
  40eea6:	pop    rbx
  40eea7:	pop    rbp
  40eea8:	ret
  40eea9:	mov    rax,QWORD PTR [rdi+0x8]
  40eead:	mov    rax,QWORD PTR [rax]
  40eeb0:	mov    rsi,rax
  40eeb3:	mov    rdi,QWORD PTR [rdi]
  40eeb6:	mov    eax,0x1
  40eebb:	mov    r14b,al
  40eebe:	test   rdi,rdi
  40eec1:	mov    rbx,QWORD PTR [rsp+0x20]
  40eec6:	jne    40ef10 <__swc_fn_7dafa2b1_000089_157b05de+0x360>
  40eec8:	test   r14b,r14b
  40eecb:	je     40eefd <__swc_fn_7dafa2b1_000089_157b05de+0x34d>
  40eecd:	test   r12,r12
  40eed0:	je     40eefd <__swc_fn_7dafa2b1_000089_157b05de+0x34d>
  40eed2:	mov    rcx,r15
  40eed5:	mov    rdx,rsi
  40eed8:	xor    r8d,r8d
  40eedb:	mov    r9,r12
  40eede:	mov    rbx,QWORD PTR [rsp+0x20]
  40eee3:	movzx  r10d,BYTE PTR [rbx]
  40eee7:	call   40eaa0 <__swc_fn_7dafa2b1_000083_fb84e43e>
  40eeec:	add    rsp,0x38
  40eef0:	pop    r15
  40eef2:	pop    r14
  40eef4:	pop    r13
  40eef6:	pop    r12
  40eef8:	pop    rdi
  40eef9:	pop    rsi
  40eefa:	pop    rbx
  40eefb:	pop    rbp
  40eefc:	ret
  40eefd:	xor    eax,eax
  40eeff:	add    rsp,0x38
  40ef03:	pop    r15
  40ef05:	pop    r14
  40ef07:	pop    r13
  40ef09:	pop    r12
  40ef0b:	pop    rdi
  40ef0c:	pop    rsi
  40ef0d:	pop    rbx
  40ef0e:	pop    rbp
  40ef0f:	ret
  40ef10:	mov    r13,rsi
  40ef13:	mov    QWORD PTR [rsp+0x28],rdi
  40ef18:	cmp    BYTE PTR [r15+0x2c],0xe
  40ef1d:	sete   al
  40ef20:	mov    r14b,al
  40ef23:	jne    40ef37 <__swc_fn_7dafa2b1_000089_157b05de+0x387>
  40ef25:	mov    rcx,rsi
  40ef28:	mov    rdx,r15
  40ef2b:	call   40c020 <__swc_fn_7dafa2b1_000085_88128f21>
  40ef30:	mov    r14b,al
  40ef33:	test   al,al
  40ef35:	jne    40ef6c <__swc_fn_7dafa2b1_000089_157b05de+0x3bc>
  40ef37:	cmp    BYTE PTR [r15+0x2c],0x12
  40ef3c:	je     40ef6c <__swc_fn_7dafa2b1_000089_157b05de+0x3bc>
  40ef3e:	mov    rcx,r15
  40ef41:	mov    rdx,rsi
  40ef44:	mov    r8,rdi
  40ef47:	mov    r9,r12
  40ef4a:	mov    rax,rbx
  40ef4d:	movzx  r10d,BYTE PTR [rax]
  40ef51:	call   40eaa0 <__swc_fn_7dafa2b1_000083_fb84e43e>
  40ef56:	test   rax,rax
  40ef59:	je     40ef6c <__swc_fn_7dafa2b1_000089_157b05de+0x3bc>
  40ef5b:	add    rsp,0x38
  40ef5f:	pop    r15
  40ef61:	pop    r14
  40ef63:	pop    r13
  40ef65:	pop    r12
  40ef67:	pop    rdi
  40ef68:	pop    rsi
  40ef69:	pop    rbx
  40ef6a:	pop    rbp
  40ef6b:	ret
  40ef6c:	rex cmp BYTE PTR [rsi+0x2c],0xe
  40ef71:	jne    40ef90 <__swc_fn_7dafa2b1_000089_157b05de+0x3e0>
  40ef73:	mov    rax,QWORD PTR [rsi+0xd8]
  40ef7a:	test   rax,rax
  40ef7d:	je     40ef90 <__swc_fn_7dafa2b1_000089_157b05de+0x3e0>
  40ef7f:	add    rdi,QWORD PTR [rax+0x8]
  40ef83:	mov    rax,QWORD PTR [rdi]
  40ef86:	sub    rdi,QWORD PTR [rax+0x8]
  40ef8a:	mov    rax,QWORD PTR [rax]
  40ef8d:	mov    rsi,rax
  40ef90:	test   r14b,r14b
  40ef93:	je     40efbf <__swc_fn_7dafa2b1_000089_157b05de+0x40f>
  40ef95:	mov    rcx,r15
  40ef98:	mov    rdx,rsi
  40ef9b:	mov    r8,rdi
  40ef9e:	mov    r9,r13
  40efa1:	mov    r14,QWORD PTR [rsp+0x28]
  40efa6:	mov    r10,r14
  40efa9:	call   408480 <__swc_fn_7dafa2b1_000087_1fb4fcfe>
  40efae:	add    rsp,0x38
  40efb2:	pop    r15
  40efb4:	pop    r14
  40efb6:	pop    r13
  40efb8:	pop    r12
  40efba:	pop    rdi
  40efbb:	pop    rsi
  40efbc:	pop    rbx
  40efbd:	pop    rbp
  40efbe:	ret
  40efbf:	mov    rcx,r15
  40efc2:	mov    rdx,rsi
  40efc5:	mov    r8,rdi
  40efc8:	mov    r9,r12
  40efcb:	movzx  r10d,BYTE PTR [rbx]
  40efcf:	call   40eaa0 <__swc_fn_7dafa2b1_000083_fb84e43e>
  40efd4:	add    rsp,0x38
  40efd8:	pop    r15
  40efda:	pop    r14
  40efdc:	pop    r13
  40efde:	pop    r12
  40efe0:	pop    rdi
  40efe1:	pop    rsi
  40efe2:	pop    rbx
  40efe3:	pop    rbp
  40efe4:	ret
	...

000000000040eff0 <__swc_fn_7dafa2b1_000092_17e20532>:
  40eff0:	push   rbx
  40eff1:	push   rsi
  40eff2:	sub    rsp,0x18
  40eff6:	mov    rbx,rcx
  40eff9:	mov    rcx,QWORD PTR [rip+0x16d40]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40f000:	test   rcx,rcx
  40f003:	jne    40f015 <__swc_fn_7dafa2b1_000092_17e20532+0x25>
  40f005:	call   40a1a0 <__swc_fn_7dafa2b1_000165_e09accff>
  40f00a:	lea    rcx,[rax+0x1]
  40f00e:	mov    QWORD PTR [rip+0x16d2b],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  40f015:	dec    rcx
  40f018:	call   4118a0 <__swc_fn_7dafa2b1_000167_3130645d>
  40f01d:	mov    rsi,rax
  40f020:	mov    rax,QWORD PTR [rsi+0x8]
  40f024:	test   rax,rax
  40f027:	jne    40f077 <__swc_fn_7dafa2b1_000092_17e20532+0x87>
  40f029:	call   40c110 <__swc_fn_7dafa2b1_000091_e6773530>
  40f02e:	test   al,al
  40f030:	jne    40f077 <__swc_fn_7dafa2b1_000092_17e20532+0x87>
  40f032:	lea    rdx,[rip+0x14207]        # 423240 <__swc_bss_base_7dafa2b1+0x200>
  40f039:	mov    rcx,rdx
  40f03c:	call   407740 <__swc_fn_7dafa2b1_000036_62160bb3>
  40f041:	test   al,al
  40f043:	jne    40f054 <__swc_fn_7dafa2b1_000092_17e20532+0x64>
  40f045:	mov    rcx,rdx
  40f048:	call   40aa00 <__swc_fn_7dafa2b1_000034_c72914a2>
  40f04d:	lea    rdx,[rip+0x141ec]        # 423240 <__swc_bss_base_7dafa2b1+0x200>
  40f054:	mov    QWORD PTR [rsp+0x8],rdx
  40f059:	lea    rax,[rip+0x30f0]        # 412150 <__swc_rdata_base_7dafa2b1+0x40>
  40f060:	mov    QWORD PTR [rsp+0x10],rax
  40f065:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f06b:	vmovups XMMWORD PTR [rsi],xmm0
  40f06f:	vmovups XMMWORD PTR [rsi+0xc8],xmm0
  40f077:	vmovups xmm0,XMMWORD PTR [rsi]
  40f07b:	vmovups XMMWORD PTR [rbx],xmm0
  40f07f:	mov    rax,rbx
  40f082:	add    rsp,0x18
  40f086:	pop    rsi
  40f087:	pop    rbx
  40f088:	ret
  40f089:	add    BYTE PTR [rax],al
  40f08b:	add    BYTE PTR [rax],al
  40f08d:	add    BYTE PTR [rax],al
	...

000000000040f090 <__swc_fn_7dafa2b1_000095_a3245f7e>:
  40f090:	sub    rsp,0x8
  40f094:	call   409340 <__swc_fn_7dafa2b1_000117_76ff2f0a>
  40f099:	add    rsp,0x8
  40f09d:	ret
	...

000000000040f0a0 <__swc_fn_7dafa2b1_000098_d9d80f1a>:
  40f0a0:	push   rbx
  40f0a1:	push   rsi
  40f0a2:	sub    rsp,0x28
  40f0a6:	mov    rbx,rcx
  40f0a9:	xor    esi,esi
  40f0ab:	jmp    40f0c0 <__swc_fn_7dafa2b1_000098_d9d80f1a+0x20>
  40f0ad:	nop    DWORD PTR [rax]
  40f0b0:	mov    QWORD PTR [rbx+0x28],rsi
  40f0b4:	mov    rsi,rbx
  40f0b7:	mov    rbx,rax
  40f0ba:	nop    WORD PTR [rax+rax*1+0x0]
  40f0c0:	test   rbx,rbx
  40f0c3:	je     40f123 <__swc_fn_7dafa2b1_000098_d9d80f1a+0x83>
  40f0c5:	mov    rcx,rbx
  40f0c8:	mov    edx,0x1
  40f0cd:	call   408200 <__swc_fn_7dafa2b1_000078_5a70c27a>
  40f0d2:	cmp    rax,0x1
  40f0d6:	jne    40f123 <__swc_fn_7dafa2b1_000098_d9d80f1a+0x83>
  40f0d8:	mov    r10,QWORD PTR [rbx+0x18]
  40f0dc:	mov    rcx,r10
  40f0df:	mov    edx,0x1
  40f0e4:	call   408200 <__swc_fn_7dafa2b1_000078_5a70c27a>
  40f0e9:	cmp    rax,0x1
  40f0ed:	jne    40f0fc <__swc_fn_7dafa2b1_000098_d9d80f1a+0x5c>
  40f0ef:	mov    rcx,r10
  40f0f2:	call   40c2b0 <__swc_fn_7dafa2b1_000097_8b4a07e9>
  40f0f7:	test   rax,rax
  40f0fa:	jne    40f0b0 <__swc_fn_7dafa2b1_000098_d9d80f1a+0x10>
  40f0fc:	mov    rax,QWORD PTR [rbx+0x20]
  40f100:	vmovups xmm0,XMMWORD PTR [rbx+0x8]
  40f105:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f10b:	lea    rcx,[rsp+0x8]
  40f110:	mov    rdx,rbx
  40f113:	mov    r8d,0x30
  40f119:	mov    rbx,rax
  40f11c:	call   408960 <__swc_fn_7dafa2b1_000096_f879630a>
  40f121:	jmp    40f0c0 <__swc_fn_7dafa2b1_000098_d9d80f1a+0x20>
  40f123:	test   rsi,rsi
  40f126:	jne    40f12f <__swc_fn_7dafa2b1_000098_d9d80f1a+0x8f>
  40f128:	add    rsp,0x28
  40f12c:	pop    rsi
  40f12d:	pop    rbx
  40f12e:	ret
  40f12f:	mov    rax,rsi
  40f132:	mov    rsi,QWORD PTR [rsi+0x28]
  40f136:	mov    rbx,QWORD PTR [rax+0x20]
  40f13a:	vmovups xmm0,XMMWORD PTR [rax+0x8]
  40f13f:	vmovups XMMWORD PTR [rsp+0x18],xmm0
  40f145:	lea    rcx,[rsp+0x18]
  40f14a:	mov    rdx,rax
  40f14d:	mov    r8d,0x30
  40f153:	call   408960 <__swc_fn_7dafa2b1_000096_f879630a>
  40f158:	jmp    40f0c0 <__swc_fn_7dafa2b1_000098_d9d80f1a+0x20>
  40f15d:	add    BYTE PTR [rax],al
	...

000000000040f160 <__swc_fn_7dafa2b1_000101_295ddd7c>:
  40f160:	push   rbx
  40f161:	push   rsi
  40f162:	push   rdi
  40f163:	push   r12
  40f165:	push   r13
  40f167:	sub    rsp,0x20
  40f16b:	mov    rbx,rcx
  40f16e:	lea    rsi,[rcx+0x6f8]
  40f175:	mov    edi,0x4
  40f17a:	mov    r12,rsi
  40f17d:	test   rdi,rdi
  40f180:	je     40f1ca <__swc_fn_7dafa2b1_000101_295ddd7c+0x6a>
  40f182:	cs nop WORD PTR [rax+rax*1+0x0]
  40f18c:	nop    DWORD PTR [rax+0x0]
  40f190:	mov    rcx,QWORD PTR [r12+0x10]
  40f195:	mov    QWORD PTR [r12+0x10],0x0
  40f19e:	vxorps xmm0,xmm0,xmm0
  40f1a2:	vmovups XMMWORD PTR [r12],xmm0
  40f1a8:	vmovups XMMWORD PTR [r12+0x28],xmm0
  40f1af:	mov    DWORD PTR [r12+0x20],0x0
  40f1b8:	call   4089b0 <__swc_fn_7dafa2b1_000099_6e0faaee>
  40f1bd:	add    r12,0x90
  40f1c4:	sub    rdi,0x1
  40f1c8:	jne    40f190 <__swc_fn_7dafa2b1_000101_295ddd7c+0x30>
  40f1ca:	mov    rax,QWORD PTR [rbx+0x938]
  40f1d1:	mov    rdi,rax
  40f1d4:	test   rdi,rdi
  40f1d7:	je     40f231 <__swc_fn_7dafa2b1_000101_295ddd7c+0xd1>
  40f1d9:	nop    DWORD PTR [rax+0x0]
  40f1e0:	mov    r12d,0x10
  40f1e6:	lea    r13,[rdi+0x18]
  40f1ea:	test   r12,r12
  40f1ed:	je     40f226 <__swc_fn_7dafa2b1_000101_295ddd7c+0xc6>
  40f1ef:	nop
  40f1f0:	mov    rcx,QWORD PTR [r13+0x10]
  40f1f4:	mov    QWORD PTR [r13+0x10],0x0
  40f1fc:	vxorps xmm0,xmm0,xmm0
  40f200:	vmovups XMMWORD PTR [r13+0x0],xmm0
  40f206:	vmovups XMMWORD PTR [r13+0x28],xmm0
  40f20c:	mov    DWORD PTR [r13+0x20],0x0
  40f214:	call   4089b0 <__swc_fn_7dafa2b1_000099_6e0faaee>
  40f219:	add    r13,0x90
  40f220:	sub    r12,0x1
  40f224:	jne    40f1f0 <__swc_fn_7dafa2b1_000101_295ddd7c+0x90>
  40f226:	mov    rax,QWORD PTR [rdi]
  40f229:	mov    rdi,rax
  40f22c:	test   rax,rax
  40f22f:	jne    40f1e0 <__swc_fn_7dafa2b1_000101_295ddd7c+0x80>
  40f231:	vxorps xmm0,xmm0,xmm0
  40f235:	vmovups XMMWORD PTR [rbx+0x998],xmm0
  40f23d:	mov    DWORD PTR [rbx+0x9b0],0x0
  40f247:	mov    DWORD PTR [rbx+0x9a8],0x0
  40f251:	mov    edi,0x4
  40f256:	mov    r12,rsi
  40f259:	lea    rsi,[rsi+0x38]
  40f25d:	test   rdi,rdi
  40f260:	je     40f28c <__swc_fn_7dafa2b1_000101_295ddd7c+0x12c>
  40f262:	cs nop WORD PTR [rax+rax*1+0x0]
  40f26c:	nop    DWORD PTR [rax+0x0]
  40f270:	mov    rcx,rsi
  40f273:	call   40d130 <__swc_fn_7dafa2b1_000157_5c8b11d8>
  40f278:	add    rsi,0x90
  40f27f:	add    r12,0x90
  40f286:	sub    rdi,0x1
  40f28a:	jne    40f270 <__swc_fn_7dafa2b1_000101_295ddd7c+0x110>
  40f28c:	mov    rax,QWORD PTR [rbx+0x938]
  40f293:	mov    rdi,rax
  40f296:	mov    QWORD PTR [rbx+0x938],0x0
  40f2a1:	test   rdi,rdi
  40f2a4:	je     40f315 <__swc_fn_7dafa2b1_000101_295ddd7c+0x1b5>
  40f2aa:	nop    WORD PTR [rax+rax*1+0x0]
  40f2b0:	mov    esi,0x10
  40f2b5:	lea    r12,[rdi+0x18]
  40f2b9:	lea    r13,[rdi+0x50]
  40f2bd:	test   rsi,rsi
  40f2c0:	je     40f2ec <__swc_fn_7dafa2b1_000101_295ddd7c+0x18c>
  40f2c2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f2cc:	nop    DWORD PTR [rax+0x0]
  40f2d0:	mov    rcx,r13
  40f2d3:	call   40d130 <__swc_fn_7dafa2b1_000157_5c8b11d8>
  40f2d8:	add    r13,0x90
  40f2df:	add    r12,0x90
  40f2e6:	sub    rsi,0x1
  40f2ea:	jne    40f2d0 <__swc_fn_7dafa2b1_000101_295ddd7c+0x170>
  40f2ec:	mov    rax,QWORD PTR [rdi]
  40f2ef:	vmovups xmm0,XMMWORD PTR [rdi+0x8]
  40f2f4:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f2fa:	lea    rcx,[rsp+0x8]
  40f2ff:	mov    rdx,rdi
  40f302:	mov    r8d,0x918
  40f308:	mov    rdi,rax
  40f30b:	call   408960 <__swc_fn_7dafa2b1_000096_f879630a>
  40f310:	test   rdi,rdi
  40f313:	jne    40f2b0 <__swc_fn_7dafa2b1_000101_295ddd7c+0x150>
  40f315:	lea    rcx,[rbx+0x68]
  40f319:	call   40d130 <__swc_fn_7dafa2b1_000157_5c8b11d8>
  40f31e:	add    rsp,0x20
  40f322:	pop    r13
  40f324:	pop    r12
  40f326:	pop    rdi
  40f327:	pop    rsi
  40f328:	pop    rbx
  40f329:	ret
  40f32a:	add    BYTE PTR [rax],al
  40f32c:	add    BYTE PTR [rax],al
	...

000000000040f330 <__swc_fn_7dafa2b1_000104_baf871f8>:
  40f330:	xor    eax,eax
  40f332:	cs nop WORD PTR [rax+rax*1+0x0]
  40f33c:	nop    DWORD PTR [rax+0x0]
  40f340:	mov    r9,r8
  40f343:	sub    r9,rax
  40f346:	cmp    r9,0x40
  40f34a:	jb     40f388 <__swc_fn_7dafa2b1_000104_baf871f8+0x58>
  40f34c:	lea    r9,[rcx+rax*1]
  40f350:	lea    r10,[rdx+rax*1]
  40f354:	vmovups xmm0,XMMWORD PTR [r10+0x10]
  40f35a:	vmovups xmm1,XMMWORD PTR [r10+0x20]
  40f360:	vmovups xmm2,XMMWORD PTR [r10+0x30]
  40f366:	vmovups xmm3,XMMWORD PTR [r10]
  40f36b:	vmovups XMMWORD PTR [r9],xmm3
  40f370:	vmovups XMMWORD PTR [r9+0x10],xmm0
  40f376:	vmovups XMMWORD PTR [r9+0x20],xmm1
  40f37c:	vmovups XMMWORD PTR [r9+0x30],xmm2
  40f382:	lea    rax,[rax+0x40]
  40f386:	jmp    40f340 <__swc_fn_7dafa2b1_000104_baf871f8+0x10>
  40f388:	nop    DWORD PTR [rax+rax*1+0x0]
  40f390:	mov    r9,r8
  40f393:	sub    r9,rax
  40f396:	cmp    r9,0x10
  40f39a:	jb     40f3b4 <__swc_fn_7dafa2b1_000104_baf871f8+0x84>
  40f39c:	lea    r9,[rdx+rax*1]
  40f3a0:	lea    r10,[rcx+rax*1]
  40f3a4:	vmovups xmm0,XMMWORD PTR [r9]
  40f3a9:	vmovups XMMWORD PTR [r10],xmm0
  40f3ae:	lea    rax,[rax+0x10]
  40f3b2:	jmp    40f390 <__swc_fn_7dafa2b1_000104_baf871f8+0x60>
  40f3b4:	cs nop WORD PTR [rax+rax*1+0x0]
  40f3be:	xchg   ax,ax
  40f3c0:	mov    r9,r8
  40f3c3:	sub    r9,rax
  40f3c6:	cmp    r9,0x8
  40f3ca:	jb     40f3dd <__swc_fn_7dafa2b1_000104_baf871f8+0xad>
  40f3cc:	lea    r9,[rcx+rax*1]
  40f3d0:	mov    r10,QWORD PTR [rdx+rax*1]
  40f3d4:	mov    QWORD PTR [r9],r10
  40f3d7:	lea    rax,[rax+0x8]
  40f3db:	jmp    40f3c0 <__swc_fn_7dafa2b1_000104_baf871f8+0x90>
  40f3dd:	cmp    rax,r8
  40f3e0:	jae    40f400 <__swc_fn_7dafa2b1_000104_baf871f8+0xd0>
  40f3e2:	cs nop WORD PTR [rax+rax*1+0x0]
  40f3ec:	nop    DWORD PTR [rax+0x0]
  40f3f0:	mov    r9b,BYTE PTR [rdx+rax*1]
  40f3f4:	mov    BYTE PTR [rcx+rax*1],r9b
  40f3f8:	inc    rax
  40f3fb:	cmp    rax,r8
  40f3fe:	jb     40f3f0 <__swc_fn_7dafa2b1_000104_baf871f8+0xc0>
  40f400:	ret
	...

000000000040f410 <__swc_fn_7dafa2b1_000107_ff529476>:
  40f410:	push   rbx
  40f411:	push   r12
  40f413:	push   rdi
  40f414:	push   rsi
  40f415:	push   r13
  40f417:	push   r14
  40f419:	push   r15
  40f41b:	sub    rsp,0x170
  40f422:	vmovups XMMWORD PTR [rsp+0xc8],xmm6
  40f42b:	vmovups XMMWORD PTR [rsp+0xd8],xmm7
  40f434:	vmovups XMMWORD PTR [rsp+0xe8],xmm8
  40f43d:	vmovups XMMWORD PTR [rsp+0xf8],xmm9
  40f446:	vmovups XMMWORD PTR [rsp+0x108],xmm10
  40f44f:	vmovups XMMWORD PTR [rsp+0x118],xmm11
  40f458:	vmovups XMMWORD PTR [rsp+0x128],xmm12
  40f461:	vmovups XMMWORD PTR [rsp+0x138],xmm13
  40f46a:	vmovups XMMWORD PTR [rsp+0x148],xmm14
  40f473:	vmovups XMMWORD PTR [rsp+0x158],xmm15
  40f47c:	mov    ebx,edx
  40f47e:	mov    QWORD PTR [rsp+0xa8],rbx
  40f486:	mov    r12d,ecx
  40f489:	test   edx,edx
  40f48b:	jne    40f4a2 <__swc_fn_7dafa2b1_000107_ff529476+0x92>
  40f48d:	xor    eax,eax
  40f48f:	add    rsp,0x170
  40f496:	pop    r15
  40f498:	pop    r14
  40f49a:	pop    r13
  40f49c:	pop    rsi
  40f49d:	pop    rdi
  40f49e:	pop    r12
  40f4a0:	pop    rbx
  40f4a1:	ret
  40f4a2:	lea    rdi,[rip+0x3007]        # 4124b0 <__swc_rdata_base_7dafa2b1+0x3a0>
  40f4a9:	mov    esi,0x90000
  40f4ae:	xor    eax,eax
  40f4b0:	call   407090 <open@plt>
  40f4b5:	mov    r13,rax
  40f4b8:	mov    QWORD PTR [rsp+0xb0],rax
  40f4c0:	test   eax,eax
  40f4c2:	jge    40f4cb <__swc_fn_7dafa2b1_000107_ff529476+0xbb>
  40f4c4:	xor    eax,eax
  40f4c6:	jmp    40f9c6 <__swc_fn_7dafa2b1_000107_ff529476+0x5b6>
  40f4cb:	nop    DWORD PTR [rax+rax*1+0x0]
  40f4d0:	movsxd rdi,r13d
  40f4d3:	mov    esi,0x2
  40f4d8:	xor    eax,eax
  40f4da:	call   407110 <flock@plt>
  40f4df:	test   eax,eax
  40f4e1:	je     40f500 <__swc_fn_7dafa2b1_000107_ff529476+0xf0>
  40f4e3:	xor    eax,eax
  40f4e5:	call   407120 <__errno_location@plt>
  40f4ea:	cmp    DWORD PTR [rax],0x4
  40f4ed:	je     40f4d0 <__swc_fn_7dafa2b1_000107_ff529476+0xc0>
  40f4ef:	movsxd rdi,r13d
  40f4f2:	xor    eax,eax
  40f4f4:	call   4070b0 <close@plt>
  40f4f9:	xor    eax,eax
  40f4fb:	jmp    40f9c6 <__swc_fn_7dafa2b1_000107_ff529476+0x5b6>
  40f500:	lea    r14,[rsp+0x8]
  40f505:	mov    QWORD PTR [rsp+0xb8],r14
  40f50d:	vxorps xmm0,xmm0,xmm0
  40f511:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40f517:	mov    QWORD PTR [rsp+0x18],0x0
  40f520:	mov    WORD PTR [rsp+0x20],0x0
  40f527:	mov    DWORD PTR [r14],0x67617753
  40f52e:	mov    DWORD PTR [r14+0x4],0x2e74522e
  40f536:	xor    eax,eax
  40f538:	call   407010 <getpid@plt>
  40f53d:	mov    ecx,eax
  40f53f:	mov    eax,0x1c
  40f544:	shrx   eax,ecx,eax
  40f549:	and    eax,0xf
  40f54c:	mov    rdx,QWORD PTR [rip+0x2f7d]        # 4124d0 <__swc_rdata_base_7dafa2b1+0x3c0>
  40f553:	mov    al,BYTE PTR [rdx+rax*1]
  40f556:	rex mov BYTE PTR [rsp+0x10],al
  40f55b:	mov    eax,0x1c
  40f560:	shrx   eax,r12d,eax
  40f565:	and    eax,0xf
  40f568:	mov    al,BYTE PTR [rdx+rax*1]
  40f56b:	rex mov BYTE PTR [rsp+0x19],al
  40f570:	mov    eax,0x18
  40f575:	shrx   eax,ecx,eax
  40f57a:	and    eax,0xf
  40f57d:	mov    al,BYTE PTR [rdx+rax*1]
  40f580:	rex mov BYTE PTR [rsp+0x11],al
  40f585:	mov    eax,0x18
  40f58a:	shrx   eax,r12d,eax
  40f58f:	and    eax,0xf
  40f592:	mov    al,BYTE PTR [rdx+rax*1]
  40f595:	rex mov BYTE PTR [rsp+0x1a],al
  40f59a:	mov    eax,0x14
  40f59f:	shrx   eax,ecx,eax
  40f5a4:	and    eax,0xf
  40f5a7:	mov    al,BYTE PTR [rdx+rax*1]
  40f5aa:	rex mov BYTE PTR [rsp+0x12],al
  40f5af:	mov    eax,0x14
  40f5b4:	shrx   eax,r12d,eax
  40f5b9:	and    eax,0xf
  40f5bc:	mov    al,BYTE PTR [rdx+rax*1]
  40f5bf:	rex mov BYTE PTR [rsp+0x1b],al
  40f5c4:	mov    eax,0x10
  40f5c9:	shrx   eax,ecx,eax
  40f5ce:	and    eax,0xf
  40f5d1:	mov    al,BYTE PTR [rdx+rax*1]
  40f5d4:	rex mov BYTE PTR [rsp+0x13],al
  40f5d9:	mov    eax,0x10
  40f5de:	shrx   eax,r12d,eax
  40f5e3:	and    eax,0xf
  40f5e6:	mov    al,BYTE PTR [rdx+rax*1]
  40f5e9:	rex mov BYTE PTR [rsp+0x1c],al
  40f5ee:	mov    eax,0xc
  40f5f3:	shrx   eax,ecx,eax
  40f5f8:	and    eax,0xf
  40f5fb:	mov    al,BYTE PTR [rdx+rax*1]
  40f5fe:	rex mov BYTE PTR [rsp+0x14],al
  40f603:	mov    eax,0xc
  40f608:	shrx   eax,r12d,eax
  40f60d:	and    eax,0xf
  40f610:	mov    al,BYTE PTR [rdx+rax*1]
  40f613:	rex mov BYTE PTR [rsp+0x1d],al
  40f618:	mov    eax,0x8
  40f61d:	shrx   eax,ecx,eax
  40f622:	and    eax,0xf
  40f625:	mov    al,BYTE PTR [rdx+rax*1]
  40f628:	rex mov BYTE PTR [rsp+0x15],al
  40f62d:	mov    eax,0x8
  40f632:	shrx   eax,r12d,eax
  40f637:	and    eax,0xf
  40f63a:	mov    al,BYTE PTR [rdx+rax*1]
  40f63d:	rex mov BYTE PTR [rsp+0x1e],al
  40f642:	mov    eax,0x4
  40f647:	shrx   eax,ecx,eax
  40f64c:	and    eax,0xf
  40f64f:	mov    al,BYTE PTR [rdx+rax*1]
  40f652:	rex mov BYTE PTR [rsp+0x16],al
  40f657:	mov    eax,0x4
  40f65c:	shrx   eax,r12d,eax
  40f661:	and    eax,0xf
  40f664:	mov    al,BYTE PTR [rdx+rax*1]
  40f667:	rex mov BYTE PTR [rsp+0x1f],al
  40f66c:	xor    eax,eax
  40f66e:	shrx   eax,ecx,eax
  40f673:	and    eax,0xf
  40f676:	mov    al,BYTE PTR [rdx+rax*1]
  40f679:	rex mov BYTE PTR [rsp+0x17],al
  40f67e:	xor    eax,eax
  40f680:	shrx   eax,r12d,eax
  40f685:	and    eax,0xf
  40f688:	mov    al,BYTE PTR [rdx+rax*1]
  40f68b:	rex mov BYTE PTR [rsp+0x20],al
  40f690:	mov    BYTE PTR [r14+0x10],0x2e
  40f695:	lea    r12,[rsp+0x22]
  40f69a:	vxorps xmm0,xmm0,xmm0
  40f69e:	vmovups XMMWORD PTR [rsp+0x42],xmm0
  40f6a4:	mov    DWORD PTR [r12],0x6d656d2f
  40f6ac:	mov    WORD PTR [r12+0x4],0x6466
  40f6b4:	mov    BYTE PTR [r12+0x6],0x3a
  40f6ba:	vmovups xmm0,XMMWORD PTR [rsp+0x8]
  40f6c0:	vmovups XMMWORD PTR [rsp+0x29],xmm0
  40f6c6:	mov    rax,QWORD PTR [rsp+0x18]
  40f6cb:	mov    QWORD PTR [rsp+0x39],rax
  40f6d0:	rex mov al,BYTE PTR [rsp+0x20]
  40f6d5:	rex mov BYTE PTR [rsp+0x41],al
  40f6da:	mov    DWORD PTR [r12+0x20],0x65642820
  40f6e3:	mov    DWORD PTR [r12+0x24],0x6574656c
  40f6ec:	mov    WORD PTR [r12+0x28],0x2964
  40f6f4:	lea    rdi,[rip+0x2dc0]        # 4124bb <__swc_rdata_base_7dafa2b1+0x3ab>
  40f6fb:	xor    eax,eax
  40f6fd:	call   407130 <opendir@plt>
  40f702:	mov    r15,rax
  40f705:	test   rax,rax
  40f708:	jne    40f71b <__swc_fn_7dafa2b1_000107_ff529476+0x30b>
  40f70a:	movsxd rdi,r13d
  40f70d:	xor    eax,eax
  40f70f:	call   4070b0 <close@plt>
  40f714:	xor    eax,eax
  40f716:	jmp    40f9c6 <__swc_fn_7dafa2b1_000107_ff529476+0x5b6>
  40f71b:	mov    rdi,r15
  40f71e:	xor    eax,eax
  40f720:	call   407140 <dirfd@plt>
  40f725:	lea    r14,[rsp+0x54]
  40f72a:	mov    DWORD PTR [rsp+0x54],eax
  40f72e:	lea    rbx,[rsp+0x58]
  40f733:	cs nop WORD PTR [rax+rax*1+0x0]
  40f73d:	nop    DWORD PTR [rax]
  40f740:	mov    rdi,r15
  40f743:	xor    eax,eax
  40f745:	call   407150 <readdir@plt>
  40f74a:	test   rax,rax
  40f74d:	jne    40f764 <__swc_fn_7dafa2b1_000107_ff529476+0x354>
  40f74f:	mov    r12,QWORD PTR [rsp+0xa8]
  40f757:	mov    r13,QWORD PTR [rsp+0xb0]
  40f75f:	jmp    40f8ea <__swc_fn_7dafa2b1_000107_ff529476+0x4da>
  40f764:	vxorps xmm0,xmm0,xmm0
  40f768:	vmovups YMMWORD PTR [rsp+0x58],ymm0
  40f76e:	vmovups YMMWORD PTR [rsp+0x78],ymm0
  40f774:	vzeroupper
  40f777:	lea    r13,[rax+0x13]
  40f77b:	mov    rax,r14
  40f77e:	movsxd rdi,DWORD PTR [rax]
  40f781:	mov    rsi,r13
  40f784:	mov    rdx,rbx
  40f787:	mov    ecx,0x40
  40f78c:	xor    eax,eax
  40f78e:	call   407160 <readlinkat@plt>
  40f793:	cmp    rax,0x2a
  40f797:	jne    40f740 <__swc_fn_7dafa2b1_000107_ff529476+0x330>
  40f799:	vmovups xmm1,XMMWORD PTR [rsp+0x22]
  40f79f:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x58]
  40f7a5:	vptest xmm0,xmm0
  40f7aa:	jne    40f7da <__swc_fn_7dafa2b1_000107_ff529476+0x3ca>
  40f7ac:	vmovups xmm1,XMMWORD PTR [rsp+0x32]
  40f7b2:	vpxor  xmm0,xmm1,XMMWORD PTR [rsp+0x68]
  40f7b8:	vptest xmm0,xmm0
  40f7bd:	jne    40f7da <__swc_fn_7dafa2b1_000107_ff529476+0x3ca>
  40f7bf:	mov    rcx,QWORD PTR [rsp+0x42]
  40f7c4:	cmp    QWORD PTR [rsp+0x78],rcx
  40f7c9:	jne    40f7da <__swc_fn_7dafa2b1_000107_ff529476+0x3ca>
  40f7cb:	mov    cx,WORD PTR [rsp+0x4a]
  40f7d0:	cmp    WORD PTR [rsp+0x80],cx
  40f7d8:	je     40f804 <__swc_fn_7dafa2b1_000107_ff529476+0x3f4>
  40f7da:	mov    rax,rbx
  40f7dd:	mov    rcx,r12
  40f7e0:	movzx  edx,BYTE PTR [rax]
  40f7e3:	movzx  r8d,BYTE PTR [rcx]
  40f7e7:	cmp    rdx,r8
  40f7ea:	jne    40f7f6 <__swc_fn_7dafa2b1_000107_ff529476+0x3e6>
  40f7ec:	add    rax,0x1
  40f7f0:	add    rcx,0x1
  40f7f4:	jmp    40f7e0 <__swc_fn_7dafa2b1_000107_ff529476+0x3d0>
  40f7f6:	mov    rax,rdx
  40f7f9:	sub    rax,r8
  40f7fc:	test   eax,eax
  40f7fe:	jne    40f740 <__swc_fn_7dafa2b1_000107_ff529476+0x330>
  40f804:	movsxd rdi,DWORD PTR [r14]
  40f807:	mov    rsi,r13
  40f80a:	mov    edx,0x80002
  40f80f:	xor    eax,eax
  40f811:	call   407170 <openat@plt>
  40f816:	lea    rbx,[rsp+0x98]
  40f81e:	mov    DWORD PTR [rsp+0x98],eax
  40f825:	test   eax,eax
  40f827:	mov    r13,QWORD PTR [rsp+0xb0]
  40f82f:	jge    40f854 <__swc_fn_7dafa2b1_000107_ff529476+0x444>
  40f831:	mov    rdi,r15
  40f834:	xor    eax,eax
  40f836:	call   407180 <closedir@plt>
  40f83b:	mov    r13,QWORD PTR [rsp+0xb0]
  40f843:	movsxd rdi,r13d
  40f846:	xor    eax,eax
  40f848:	call   4070b0 <close@plt>
  40f84d:	xor    eax,eax
  40f84f:	jmp    40f9c6 <__swc_fn_7dafa2b1_000107_ff529476+0x5b6>
  40f854:	mov    rax,rbx
  40f857:	movsxd rdi,DWORD PTR [rax]
  40f85a:	xor    esi,esi
  40f85c:	mov    edx,0x2
  40f861:	xor    eax,eax
  40f863:	call   4070a0 <lseek@plt>
  40f868:	mov    r12,QWORD PTR [rsp+0xa8]
  40f870:	cmp    rax,r12
  40f873:	je     40f89a <__swc_fn_7dafa2b1_000107_ff529476+0x48a>
  40f875:	movsxd rdi,DWORD PTR [rbx]
  40f878:	xor    eax,eax
  40f87a:	call   4070b0 <close@plt>
  40f87f:	mov    rdi,r15
  40f882:	xor    eax,eax
  40f884:	call   407180 <closedir@plt>
  40f889:	movsxd rdi,r13d
  40f88c:	xor    eax,eax
  40f88e:	call   4070b0 <close@plt>
  40f893:	xor    eax,eax
  40f895:	jmp    40f9c6 <__swc_fn_7dafa2b1_000107_ff529476+0x5b6>
  40f89a:	xor    edi,edi
  40f89c:	mov    rsi,r12
  40f89f:	mov    edx,0x3
  40f8a4:	mov    ecx,0x1
  40f8a9:	mov    rax,rbx
  40f8ac:	movsxd r8,DWORD PTR [rax]
  40f8af:	xor    r9d,r9d
  40f8b2:	xor    eax,eax
  40f8b4:	call   4070c0 <mmap@plt>
  40f8b9:	xor    r12d,r12d
  40f8bc:	cmp    rax,0xffffffffffffffff
  40f8c0:	cmovne r12,rax
  40f8c4:	movsxd rdi,DWORD PTR [rbx]
  40f8c7:	xor    eax,eax
  40f8c9:	call   4070b0 <close@plt>
  40f8ce:	mov    rdi,r15
  40f8d1:	xor    eax,eax
  40f8d3:	call   407180 <closedir@plt>
  40f8d8:	movsxd rdi,r13d
  40f8db:	xor    eax,eax
  40f8dd:	call   4070b0 <close@plt>
  40f8e2:	mov    rax,r12
  40f8e5:	jmp    40f9c6 <__swc_fn_7dafa2b1_000107_ff529476+0x5b6>
  40f8ea:	mov    r14,QWORD PTR [rsp+0xb8]
  40f8f2:	mov    rdi,r14
  40f8f5:	mov    esi,0x1
  40f8fa:	xor    eax,eax
  40f8fc:	call   407190 <memfd_create@plt>
  40f901:	lea    rbx,[rsp+0x9c]
  40f909:	mov    DWORD PTR [rsp+0x9c],eax
  40f910:	test   eax,eax
  40f912:	jge    40f92f <__swc_fn_7dafa2b1_000107_ff529476+0x51f>
  40f914:	mov    rdi,r15
  40f917:	xor    eax,eax
  40f919:	call   407180 <closedir@plt>
  40f91e:	movsxd rdi,r13d
  40f921:	xor    eax,eax
  40f923:	call   4070b0 <close@plt>
  40f928:	xor    eax,eax
  40f92a:	jmp    40f9c6 <__swc_fn_7dafa2b1_000107_ff529476+0x5b6>
  40f92f:	mov    rax,rbx
  40f932:	movsxd rdi,DWORD PTR [rax]
  40f935:	mov    rsi,r12
  40f938:	xor    eax,eax
  40f93a:	call   4071a0 <ftruncate@plt>
  40f93f:	test   eax,eax
  40f941:	je     40f965 <__swc_fn_7dafa2b1_000107_ff529476+0x555>
  40f943:	movsxd rdi,DWORD PTR [rbx]
  40f946:	xor    eax,eax
  40f948:	call   4070b0 <close@plt>
  40f94d:	mov    rdi,r15
  40f950:	xor    eax,eax
  40f952:	call   407180 <closedir@plt>
  40f957:	movsxd rdi,r13d
  40f95a:	xor    eax,eax
  40f95c:	call   4070b0 <close@plt>
  40f961:	xor    eax,eax
  40f963:	jmp    40f9c6 <__swc_fn_7dafa2b1_000107_ff529476+0x5b6>
  40f965:	xor    edi,edi
  40f967:	mov    rsi,r12
  40f96a:	mov    edx,0x3
  40f96f:	mov    ecx,0x1
  40f974:	mov    rax,rbx
  40f977:	movsxd r8,DWORD PTR [rax]
  40f97a:	xor    r9d,r9d
  40f97d:	xor    eax,eax
  40f97f:	call   4070c0 <mmap@plt>
  40f984:	mov    r12,rax
  40f987:	cmp    rax,0xffffffffffffffff
  40f98b:	jne    40f9af <__swc_fn_7dafa2b1_000107_ff529476+0x59f>
  40f98d:	movsxd rdi,DWORD PTR [rbx]
  40f990:	xor    eax,eax
  40f992:	call   4070b0 <close@plt>
  40f997:	mov    rdi,r15
  40f99a:	xor    eax,eax
  40f99c:	call   407180 <closedir@plt>
  40f9a1:	movsxd rdi,r13d
  40f9a4:	xor    eax,eax
  40f9a6:	call   4070b0 <close@plt>
  40f9ab:	xor    eax,eax
  40f9ad:	jmp    40f9c6 <__swc_fn_7dafa2b1_000107_ff529476+0x5b6>
  40f9af:	mov    rdi,r15
  40f9b2:	xor    eax,eax
  40f9b4:	call   407180 <closedir@plt>
  40f9b9:	movsxd rdi,r13d
  40f9bc:	xor    eax,eax
  40f9be:	call   4070b0 <close@plt>
  40f9c3:	mov    rax,r12
  40f9c6:	vmovups xmm6,XMMWORD PTR [rsp+0xc8]
  40f9cf:	vmovups xmm7,XMMWORD PTR [rsp+0xd8]
  40f9d8:	vmovups xmm8,XMMWORD PTR [rsp+0xe8]
  40f9e1:	vmovups xmm9,XMMWORD PTR [rsp+0xf8]
  40f9ea:	vmovups xmm10,XMMWORD PTR [rsp+0x108]
  40f9f3:	vmovups xmm11,XMMWORD PTR [rsp+0x118]
  40f9fc:	vmovups xmm12,XMMWORD PTR [rsp+0x128]
  40fa05:	vmovups xmm13,XMMWORD PTR [rsp+0x138]
  40fa0e:	vmovups xmm14,XMMWORD PTR [rsp+0x148]
  40fa17:	vmovups xmm15,XMMWORD PTR [rsp+0x158]
  40fa20:	add    rsp,0x170
  40fa27:	pop    r15
  40fa29:	pop    r14
  40fa2b:	pop    r13
  40fa2d:	pop    rsi
  40fa2e:	pop    rdi
  40fa2f:	pop    r12
  40fa31:	pop    rbx
  40fa32:	ret
	...

000000000040fa40 <__swc_fn_7dafa2b1_000110_e606239a>:
  40fa40:	push   rsi
  40fa41:	push   rdi
  40fa42:	push   r12
  40fa44:	push   r13
  40fa46:	sub    rsp,0x8
  40fa4a:	mov    rsi,r8
  40fa4d:	mov    rdi,rcx
  40fa50:	mov    r12,rdx
  40fa53:	call   409100 <__swc_fn_7dafa2b1_000108_32416b9e>
  40fa58:	mov    r13,rax
  40fa5b:	test   rax,rax
  40fa5e:	jne    40fa6b <__swc_fn_7dafa2b1_000110_e606239a+0x2b>
  40fa60:	add    rsp,0x8
  40fa64:	pop    r13
  40fa66:	pop    r12
  40fa68:	pop    rdi
  40fa69:	pop    rsi
  40fa6a:	ret
  40fa6b:	mov    rcx,r13
  40fa6e:	call   40cd30 <__swc_fn_7dafa2b1_000133_c6de0049>
  40fa73:	mov    rax,QWORD PTR [r13+0x8]
  40fa77:	test   rax,rax
  40fa7a:	je     40fab9 <__swc_fn_7dafa2b1_000110_e606239a+0x79>
  40fa7c:	nop    DWORD PTR [rax+0x0]
  40fa80:	lea    rcx,[rax+0x1000]
  40fa87:	cmp    rdi,rcx
  40fa8a:	jne    40fab1 <__swc_fn_7dafa2b1_000110_e606239a+0x71>
  40fa8c:	cmp    r12,0x1000
  40fa93:	jb     40fab1 <__swc_fn_7dafa2b1_000110_e606239a+0x71>
  40fa95:	test   sil,sil
  40fa98:	setne  cl
  40fa9b:	mov    BYTE PTR [rax+0x10],cl
  40fa9e:	mov    rcx,r13
  40faa1:	call   40ffa0 <__swc_fn_7dafa2b1_000134_5696c87e>
  40faa6:	add    rsp,0x8
  40faaa:	pop    r13
  40faac:	pop    r12
  40faae:	pop    rdi
  40faaf:	pop    rsi
  40fab0:	ret
  40fab1:	mov    rax,QWORD PTR [rax]
  40fab4:	test   rax,rax
  40fab7:	jne    40fa80 <__swc_fn_7dafa2b1_000110_e606239a+0x40>
  40fab9:	mov    rcx,r13
  40fabc:	call   40ffa0 <__swc_fn_7dafa2b1_000134_5696c87e>
  40fac1:	add    rsp,0x8
  40fac5:	pop    r13
  40fac7:	pop    r12
  40fac9:	pop    rdi
  40faca:	pop    rsi
  40facb:	ret
  40facc:	add    BYTE PTR [rax],al
	...

000000000040fad0 <__swc_fn_7dafa2b1_000113_25e345b1>:
  40fad0:	sub    rsp,0x8
  40fad4:	test   rcx,rcx
  40fad7:	jne    40fade <__swc_fn_7dafa2b1_000113_25e345b1+0xe>
  40fad9:	add    rsp,0x8
  40fadd:	ret
  40fade:	call   40c840 <__swc_fn_7dafa2b1_000115_259b5d5a>
  40fae3:	add    rsp,0x8
  40fae7:	ret
	...

000000000040faf0 <__swc_fn_7dafa2b1_000116_3499f7d6>:
  40faf0:	push   r12
  40faf2:	push   r13
  40faf4:	push   r14
  40faf6:	push   rdi
  40faf7:	push   rsi
  40faf8:	sub    rsp,0xc0
  40faff:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40fb05:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40fb0b:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40fb11:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40fb17:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40fb1d:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40fb23:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40fb29:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40fb32:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40fb3b:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40fb44:	mov    r12,QWORD PTR [rcx]
  40fb47:	test   r12,r12
  40fb4a:	jne    40fb5c <__swc_fn_7dafa2b1_000116_3499f7d6+0x6c>
  40fb4c:	add    rsp,0xc0
  40fb53:	pop    rsi
  40fb54:	pop    rdi
  40fb55:	pop    r14
  40fb57:	pop    r13
  40fb59:	pop    r12
  40fb5b:	ret
  40fb5c:	xor    r13d,r13d
  40fb5f:	mov    r14,QWORD PTR [rcx+0x8]
  40fb63:	cs nop WORD PTR [rax+rax*1+0x0]
  40fb6d:	nop    DWORD PTR [rax]
  40fb70:	cmp    r13,r14
  40fb73:	jae    40fbab <__swc_fn_7dafa2b1_000116_3499f7d6+0xbb>
  40fb75:	lea    rax,[r12+r13*1]
  40fb79:	mov    rcx,r14
  40fb7c:	sub    rcx,r13
  40fb7f:	mov    edi,0x1
  40fb84:	mov    rsi,rax
  40fb87:	mov    rdx,rcx
  40fb8a:	xor    eax,eax
  40fb8c:	call   4071b0 <write@plt>
  40fb91:	test   rax,rax
  40fb94:	jle    40fb9b <__swc_fn_7dafa2b1_000116_3499f7d6+0xab>
  40fb96:	add    r13,rax
  40fb99:	jmp    40fb70 <__swc_fn_7dafa2b1_000116_3499f7d6+0x80>
  40fb9b:	je     40fba9 <__swc_fn_7dafa2b1_000116_3499f7d6+0xb9>
  40fb9d:	xor    eax,eax
  40fb9f:	call   407120 <__errno_location@plt>
  40fba4:	cmp    DWORD PTR [rax],0x4
  40fba7:	je     40fb70 <__swc_fn_7dafa2b1_000116_3499f7d6+0x80>
  40fba9:	jmp    40fbab <__swc_fn_7dafa2b1_000116_3499f7d6+0xbb>
  40fbab:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40fbb1:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40fbb7:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40fbbd:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40fbc3:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40fbc9:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40fbcf:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40fbd5:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40fbde:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40fbe7:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40fbf0:	add    rsp,0xc0
  40fbf7:	pop    rsi
  40fbf8:	pop    rdi
  40fbf9:	pop    r14
  40fbfb:	pop    r13
  40fbfd:	pop    r12
  40fbff:	ret

000000000040fc00 <__swc_fn_7dafa2b1_000119_18cd3882>:
  40fc00:	push   rbx
  40fc01:	push   r12
  40fc03:	push   rdi
  40fc04:	push   rsi
  40fc05:	sub    rsp,0x4a8
  40fc0c:	vmovups XMMWORD PTR [rsp+0x408],xmm6
  40fc15:	vmovups XMMWORD PTR [rsp+0x418],xmm7
  40fc1e:	vmovups XMMWORD PTR [rsp+0x428],xmm8
  40fc27:	vmovups XMMWORD PTR [rsp+0x438],xmm9
  40fc30:	vmovups XMMWORD PTR [rsp+0x448],xmm10
  40fc39:	vmovups XMMWORD PTR [rsp+0x458],xmm11
  40fc42:	vmovups XMMWORD PTR [rsp+0x468],xmm12
  40fc4b:	vmovups XMMWORD PTR [rsp+0x478],xmm13
  40fc54:	vmovups XMMWORD PTR [rsp+0x488],xmm14
  40fc5d:	vmovups XMMWORD PTR [rsp+0x498],xmm15
  40fc66:	mov    rbx,rdx
  40fc69:	mov    r12d,ecx
  40fc6c:	vxorps xmm0,xmm0,xmm0
  40fc70:	xor    eax,eax
  40fc72:	cs nop WORD PTR [rax+rax*1+0x0]
  40fc7c:	nop    DWORD PTR [rax+0x0]
  40fc80:	vmovdqu XMMWORD PTR [rsp+rax*1+0x8],xmm0
  40fc86:	add    rax,0x10
  40fc8a:	cmp    rax,0x400
  40fc91:	jne    40fc80 <__swc_fn_7dafa2b1_000119_18cd3882+0x80>
  40fc93:	lea    rdi,[rsp+0x8]
  40fc98:	mov    esi,0x80
  40fc9d:	xor    eax,eax
  40fc9f:	call   4071c0 <backtrace@plt>
  40fca4:	test   eax,eax
  40fca6:	jle    40fcb5 <__swc_fn_7dafa2b1_000119_18cd3882+0xb5>
  40fca8:	movsxd rax,eax
  40fcab:	lea    rcx,[r12+0x1]
  40fcb0:	cmp    rcx,rax
  40fcb3:	jb     40fcb9 <__swc_fn_7dafa2b1_000119_18cd3882+0xb9>
  40fcb5:	xor    eax,eax
  40fcb7:	jmp    40fcea <__swc_fn_7dafa2b1_000119_18cd3882+0xea>
  40fcb9:	mov    rcx,QWORD PTR [rbx+0x8]
  40fcbd:	sub    rax,r12
  40fcc0:	lea    rsi,[rax-0x1]
  40fcc4:	cmp    rcx,rsi
  40fcc7:	cmovbe rsi,rcx
  40fccb:	lea    eax,[r12+0x1]
  40fcd0:	lea    rax,[rsp+rax*8+0x8]
  40fcd5:	mov    rcx,QWORD PTR [rbx]
  40fcd8:	mov    rdx,rax
  40fcdb:	lea    r8,[rsi*8+0x0]
  40fce3:	call   4090e0 <__swc_fn_7dafa2b1_000105_b7aef7c0>
  40fce8:	mov    eax,esi
  40fcea:	vmovups xmm6,XMMWORD PTR [rsp+0x408]
  40fcf3:	vmovups xmm7,XMMWORD PTR [rsp+0x418]
  40fcfc:	vmovups xmm8,XMMWORD PTR [rsp+0x428]
  40fd05:	vmovups xmm9,XMMWORD PTR [rsp+0x438]
  40fd0e:	vmovups xmm10,XMMWORD PTR [rsp+0x448]
  40fd17:	vmovups xmm11,XMMWORD PTR [rsp+0x458]
  40fd20:	vmovups xmm12,XMMWORD PTR [rsp+0x468]
  40fd29:	vmovups xmm13,XMMWORD PTR [rsp+0x478]
  40fd32:	vmovups xmm14,XMMWORD PTR [rsp+0x488]
  40fd3b:	vmovups xmm15,XMMWORD PTR [rsp+0x498]
  40fd44:	add    rsp,0x4a8
  40fd4b:	pop    rsi
  40fd4c:	pop    rdi
  40fd4d:	pop    r12
  40fd4f:	pop    rbx
  40fd50:	ret
	...

000000000040fd60 <__swc_fn_7dafa2b1_000122_c37da69c>:
  40fd60:	mov    QWORD PTR [rcx],0x0
  40fd67:	ret
	...

000000000040fd70 <__swc_fn_7dafa2b1_000125_e19c72b3>:
  40fd70:	push   rdi
  40fd71:	push   rsi
  40fd72:	sub    rsp,0xa8
  40fd79:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40fd7f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40fd85:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40fd8b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40fd91:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40fd97:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40fd9d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40fda3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40fda9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40fdb2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40fdbb:	mov    edi,ecx
  40fdbd:	mov    rsi,rdx
  40fdc0:	xor    eax,eax
  40fdc2:	call   407060 <pthread_setspecific@plt>
  40fdc7:	test   eax,eax
  40fdc9:	sete   al
  40fdcc:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40fdd2:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40fdd8:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40fdde:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40fde4:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40fdea:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40fdf0:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40fdf6:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40fdfc:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40fe05:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40fe0e:	add    rsp,0xa8
  40fe15:	pop    rsi
  40fe16:	pop    rdi
  40fe17:	ret
	...

000000000040fe20 <__swc_fn_7dafa2b1_000128_9c45d2d7>:
  40fe20:	push   rdi
  40fe21:	push   rsi
  40fe22:	sub    rsp,0xa8
  40fe29:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  40fe2f:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  40fe35:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  40fe3b:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  40fe41:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  40fe47:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  40fe4d:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  40fe53:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  40fe59:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  40fe62:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  40fe6b:	test   rcx,rcx
  40fe6e:	je     40fe81 <__swc_fn_7dafa2b1_000128_9c45d2d7+0x61>
  40fe70:	lea    rax,[rcx-0x1]
  40fe74:	mov    eax,eax
  40fe76:	mov    edi,eax
  40fe78:	xor    eax,eax
  40fe7a:	call   407000 <pthread_getspecific@plt>
  40fe7f:	jmp    40fe83 <__swc_fn_7dafa2b1_000128_9c45d2d7+0x63>
  40fe81:	xor    eax,eax
  40fe83:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  40fe89:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  40fe8f:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  40fe95:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  40fe9b:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  40fea1:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  40fea7:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  40fead:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  40feb3:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  40febc:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  40fec5:	add    rsp,0xa8
  40fecc:	pop    rsi
  40fecd:	pop    rdi
  40fece:	ret
	...

000000000040fed0 <__swc_fn_7dafa2b1_000131_dc04d759>:
  40fed0:	push   rdi
  40fed1:	push   rsi
  40fed2:	sub    rsp,0xb8
  40fed9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40fedf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40fee5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40feeb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40fef1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40fef7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40fefd:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40ff03:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40ff0c:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  40ff15:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  40ff1e:	vxorps xmm0,xmm0,xmm0
  40ff22:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  40ff28:	mov    edi,0x1
  40ff2d:	lea    rsi,[rsp+0x8]
  40ff32:	xor    eax,eax
  40ff34:	call   4071d0 <clock_gettime@plt>
  40ff39:	mov    rax,QWORD PTR [rsp+0x8]
  40ff3e:	imul   rax,rax,0x3b9aca00
  40ff45:	add    rax,QWORD PTR [rsp+0x10]
  40ff4a:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  40ff50:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  40ff56:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  40ff5c:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  40ff62:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  40ff68:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  40ff6e:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  40ff74:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  40ff7d:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  40ff86:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  40ff8f:	add    rsp,0xb8
  40ff96:	pop    rsi
  40ff97:	pop    rdi
  40ff98:	ret
  40ff99:	add    BYTE PTR [rax],al
  40ff9b:	add    BYTE PTR [rax],al
  40ff9d:	add    BYTE PTR [rax],al
	...

000000000040ffa0 <__swc_fn_7dafa2b1_000134_5696c87e>:
  40ffa0:	sub    rsp,0x8
  40ffa4:	xor    eax,eax
  40ffa6:	mov    DWORD PTR [rcx],eax
  40ffa8:	mov    edx,0x7fffffff
  40ffad:	call   4097e0 <__swc_fn_7dafa2b1_000132_2b60f756>
  40ffb2:	add    rsp,0x8
  40ffb6:	ret
	...

000000000040ffc0 <__swc_fn_7dafa2b1_000137_899a611e>:
  40ffc0:	push   rdi
  40ffc1:	push   rsi
  40ffc2:	sub    rsp,0xb8
  40ffc9:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  40ffcf:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  40ffd5:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  40ffdb:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  40ffe1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  40ffe7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  40ffed:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  40fff3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  40fffc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  410005:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  41000e:	mov    edi,0x1
  410013:	xor    eax,eax
  410015:	call   4071e0 <__x86_get_cpuid_feature_leaf@plt>
  41001a:	mov    eax,DWORD PTR [rax+0x14]
  41001d:	and    eax,0x20
  410020:	setne  al
  410023:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  410029:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  41002f:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  410035:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  41003b:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  410041:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  410047:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  41004d:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  410056:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  41005f:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  410068:	add    rsp,0xb8
  41006f:	pop    rsi
  410070:	pop    rdi
  410071:	ret
	...

0000000000410080 <__swc_fn_7dafa2b1_000140_81b740ca>:
  410080:	push   rsi
  410081:	push   rdi
  410082:	push   r12
  410084:	push   r13
  410086:	push   r14
  410088:	push   r15
  41008a:	cmp    rdx,0x40
  41008e:	jae    41009d <__swc_fn_7dafa2b1_000140_81b740ca+0x1d>
  410090:	xor    eax,eax
  410092:	pop    r15
  410094:	pop    r14
  410096:	pop    r13
  410098:	pop    r12
  41009a:	pop    rdi
  41009b:	pop    rsi
  41009c:	ret
  41009d:	cmp    BYTE PTR [rcx],0x7f
  4100a0:	jne    4100e4 <__swc_fn_7dafa2b1_000140_81b740ca+0x64>
  4100a2:	movzx  eax,BYTE PTR [rcx+0x1]
  4100a6:	cmp    eax,0x45
  4100a9:	setne  al
  4100ac:	jne    4100e0 <__swc_fn_7dafa2b1_000140_81b740ca+0x60>
  4100ae:	movzx  eax,BYTE PTR [rcx+0x2]
  4100b2:	cmp    eax,0x4c
  4100b5:	setne  al
  4100b8:	jne    4100e0 <__swc_fn_7dafa2b1_000140_81b740ca+0x60>
  4100ba:	movzx  eax,BYTE PTR [rcx+0x3]
  4100be:	cmp    eax,0x46
  4100c1:	setne  al
  4100c4:	jne    4100e0 <__swc_fn_7dafa2b1_000140_81b740ca+0x60>
  4100c6:	cmp    BYTE PTR [rcx+0x4],0x2
  4100ca:	setne  al
  4100cd:	jne    4100e0 <__swc_fn_7dafa2b1_000140_81b740ca+0x60>
  4100cf:	cmp    BYTE PTR [rcx+0x5],0x1
  4100d3:	setne  al
  4100d6:	jne    4100e0 <__swc_fn_7dafa2b1_000140_81b740ca+0x60>
  4100d8:	cmp    WORD PTR [rcx+0x12],0x3e
  4100dd:	setne  al
  4100e0:	test   al,al
  4100e2:	je     4100f1 <__swc_fn_7dafa2b1_000140_81b740ca+0x71>
  4100e4:	xor    eax,eax
  4100e6:	pop    r15
  4100e8:	pop    r14
  4100ea:	pop    r13
  4100ec:	pop    r12
  4100ee:	pop    rdi
  4100ef:	pop    rsi
  4100f0:	ret
  4100f1:	cmp    WORD PTR [rcx+0x3a],0x40
  4100f6:	jne    410111 <__swc_fn_7dafa2b1_000140_81b740ca+0x91>
  4100f8:	cmp    WORD PTR [rcx+0x3c],0x0
  4100fd:	sete   al
  410100:	je     41010d <__swc_fn_7dafa2b1_000140_81b740ca+0x8d>
  410102:	mov    ax,WORD PTR [rcx+0x3c]
  410106:	cmp    WORD PTR [rcx+0x3e],ax
  41010a:	setae  al
  41010d:	test   al,al
  41010f:	je     41011e <__swc_fn_7dafa2b1_000140_81b740ca+0x9e>
  410111:	xor    eax,eax
  410113:	pop    r15
  410115:	pop    r14
  410117:	pop    r13
  410119:	pop    r12
  41011b:	pop    rdi
  41011c:	pop    rsi
  41011d:	ret
  41011e:	movzx  eax,WORD PTR [rcx+0x3c]
  410122:	shl    rax,0x6
  410126:	cmp    rax,rdx
  410129:	ja     410137 <__swc_fn_7dafa2b1_000140_81b740ca+0xb7>
  41012b:	mov    r9,rdx
  41012e:	sub    r9,rax
  410131:	cmp    QWORD PTR [rcx+0x28],r9
  410135:	jbe    410144 <__swc_fn_7dafa2b1_000140_81b740ca+0xc4>
  410137:	xor    eax,eax
  410139:	pop    r15
  41013b:	pop    r14
  41013d:	pop    r13
  41013f:	pop    r12
  410141:	pop    rdi
  410142:	pop    rsi
  410143:	ret
  410144:	mov    rax,QWORD PTR [rcx+0x28]
  410148:	add    rax,rcx
  41014b:	movzx  r9d,WORD PTR [rcx+0x3e]
  410150:	lea    r9,[r9*8+0x0]
  410158:	lea    r10,[rax+r9*8]
  41015c:	cmp    QWORD PTR [r10+0x20],rdx
  410160:	ja     410182 <__swc_fn_7dafa2b1_000140_81b740ca+0x102>
  410162:	mov    r11,rdx
  410165:	sub    r11,QWORD PTR [rax+r9*8+0x20]
  41016a:	cmp    QWORD PTR [r10+0x18],r11
  41016e:	seta   r9b
  410172:	ja     41017d <__swc_fn_7dafa2b1_000140_81b740ca+0xfd>
  410174:	cmp    QWORD PTR [r10+0x20],0x9
  410179:	setb   r9b
  41017d:	test   r9b,r9b
  410180:	je     41018f <__swc_fn_7dafa2b1_000140_81b740ca+0x10f>
  410182:	xor    eax,eax
  410184:	pop    r15
  410186:	pop    r14
  410188:	pop    r13
  41018a:	pop    r12
  41018c:	pop    rdi
  41018d:	pop    rsi
  41018e:	ret
  41018f:	movzx  r9d,WORD PTR [rcx+0x3c]
  410194:	xor    r11d,r11d
  410197:	test   r9,r9
  41019a:	jbe    410295 <__swc_fn_7dafa2b1_000140_81b740ca+0x215>
  4101a0:	mov    rsi,QWORD PTR [r10+0x20]
  4101a4:	sub    rsi,0x9
  4101a8:	cs nop WORD PTR [rax+rax*1+0x0]
  4101b2:	cs nop WORD PTR [rax+rax*1+0x0]
  4101bc:	nop    DWORD PTR [rax+0x0]
  4101c0:	movzx  edi,r11w
  4101c4:	lea    rdi,[rdi*8+0x0]
  4101cc:	lea    r12,[rax+rdi*8]
  4101d0:	rex mov edi,DWORD PTR [rax+rdi*8]
  4101d4:	cmp    rdi,rsi
  4101d7:	ja     410288 <__swc_fn_7dafa2b1_000140_81b740ca+0x208>
  4101dd:	mov    r13,QWORD PTR [r10+0x18]
  4101e1:	add    r13,rdi
  4101e4:	lea    rdi,[rcx+r13*1]
  4101e8:	lea    r13,[rip+0x2341]        # 412530 <__swc_rdata_base_7dafa2b1+0x420>
  4101ef:	movabs r14,0x676264676177732e
  4101f9:	cmp    QWORD PTR [rdi],r14
  4101fc:	jne    410205 <__swc_fn_7dafa2b1_000140_81b740ca+0x185>
  4101fe:	rex cmp BYTE PTR [rdi+0x8],0x0
  410203:	je     410232 <__swc_fn_7dafa2b1_000140_81b740ca+0x1b2>
  410205:	cs nop WORD PTR [rax+rax*1+0x0]
  41020f:	nop
  410210:	movzx  r14d,BYTE PTR [rdi]
  410214:	movzx  r15d,BYTE PTR [r13+0x0]
  410219:	cmp    r14,r15
  41021c:	jne    410228 <__swc_fn_7dafa2b1_000140_81b740ca+0x1a8>
  41021e:	add    rdi,0x1
  410222:	add    r13,0x1
  410226:	jmp    410210 <__swc_fn_7dafa2b1_000140_81b740ca+0x190>
  410228:	mov    rdi,r14
  41022b:	sub    rdi,r15
  41022e:	test   edi,edi
  410230:	jne    410288 <__swc_fn_7dafa2b1_000140_81b740ca+0x208>
  410232:	cmp    DWORD PTR [r12+0x4],0x1
  410238:	jne    410260 <__swc_fn_7dafa2b1_000140_81b740ca+0x1e0>
  41023a:	cmp    QWORD PTR [r12+0x20],0x10
  410240:	setb   al
  410243:	jb     41025c <__swc_fn_7dafa2b1_000140_81b740ca+0x1dc>
  410245:	cmp    QWORD PTR [r12+0x20],rdx
  41024a:	seta   al
  41024d:	ja     41025c <__swc_fn_7dafa2b1_000140_81b740ca+0x1dc>
  41024f:	sub    rdx,QWORD PTR [r12+0x20]
  410254:	cmp    QWORD PTR [r12+0x18],rdx
  410259:	seta   al
  41025c:	test   al,al
  41025e:	je     41026d <__swc_fn_7dafa2b1_000140_81b740ca+0x1ed>
  410260:	xor    eax,eax
  410262:	pop    r15
  410264:	pop    r14
  410266:	pop    r13
  410268:	pop    r12
  41026a:	pop    rdi
  41026b:	pop    rsi
  41026c:	ret
  41026d:	mov    rax,QWORD PTR [r12+0x20]
  410272:	mov    QWORD PTR [r8],rax
  410275:	mov    rax,QWORD PTR [r12+0x18]
  41027a:	add    rax,rcx
  41027d:	pop    r15
  41027f:	pop    r14
  410281:	pop    r13
  410283:	pop    r12
  410285:	pop    rdi
  410286:	pop    rsi
  410287:	ret
  410288:	add    r11,0x1
  41028c:	cmp    r11,r9
  41028f:	jb     4101c0 <__swc_fn_7dafa2b1_000140_81b740ca+0x140>
  410295:	xor    eax,eax
  410297:	pop    r15
  410299:	pop    r14
  41029b:	pop    r13
  41029d:	pop    r12
  41029f:	pop    rdi
  4102a0:	pop    rsi
  4102a1:	ret
	...

00000000004102b0 <__swc_fn_7dafa2b1_000143_afffe963>:
  4102b0:	push   rdi
  4102b1:	push   rsi
  4102b2:	sub    rsp,0xa8
  4102b9:	vmovups XMMWORD PTR [rsp+0x8],xmm6
  4102bf:	vmovups XMMWORD PTR [rsp+0x18],xmm7
  4102c5:	vmovups XMMWORD PTR [rsp+0x28],xmm8
  4102cb:	vmovups XMMWORD PTR [rsp+0x38],xmm9
  4102d1:	vmovups XMMWORD PTR [rsp+0x48],xmm10
  4102d7:	vmovups XMMWORD PTR [rsp+0x58],xmm11
  4102dd:	vmovups XMMWORD PTR [rsp+0x68],xmm12
  4102e3:	vmovups XMMWORD PTR [rsp+0x78],xmm13
  4102e9:	vmovups XMMWORD PTR [rsp+0x88],xmm14
  4102f2:	vmovups XMMWORD PTR [rsp+0x98],xmm15
  4102fb:	mov    rdi,rcx
  4102fe:	xor    eax,eax
  410300:	call   4071f0 <free@plt>
  410305:	vmovups xmm6,XMMWORD PTR [rsp+0x8]
  41030b:	vmovups xmm7,XMMWORD PTR [rsp+0x18]
  410311:	vmovups xmm8,XMMWORD PTR [rsp+0x28]
  410317:	vmovups xmm9,XMMWORD PTR [rsp+0x38]
  41031d:	vmovups xmm10,XMMWORD PTR [rsp+0x48]
  410323:	vmovups xmm11,XMMWORD PTR [rsp+0x58]
  410329:	vmovups xmm12,XMMWORD PTR [rsp+0x68]
  41032f:	vmovups xmm13,XMMWORD PTR [rsp+0x78]
  410335:	vmovups xmm14,XMMWORD PTR [rsp+0x88]
  41033e:	vmovups xmm15,XMMWORD PTR [rsp+0x98]
  410347:	add    rsp,0xa8
  41034e:	pop    rsi
  41034f:	pop    rdi
  410350:	ret
	...

0000000000410360 <__swc_fn_7dafa2b1_000146_e9d46966>:
  410360:	push   rbx
  410361:	push   rsi
  410362:	push   rdi
  410363:	push   r12
  410365:	push   r13
  410367:	push   r15
  410369:	sub    rsp,0x4e8
  410370:	vmovups XMMWORD PTR [rsp+0x448],xmm6
  410379:	vmovups XMMWORD PTR [rsp+0x458],xmm7
  410382:	vmovups XMMWORD PTR [rsp+0x468],xmm8
  41038b:	vmovups XMMWORD PTR [rsp+0x478],xmm9
  410394:	vmovups XMMWORD PTR [rsp+0x488],xmm10
  41039d:	vmovups XMMWORD PTR [rsp+0x498],xmm11
  4103a6:	vmovups XMMWORD PTR [rsp+0x4a8],xmm15
  4103af:	vmovups XMMWORD PTR [rsp+0x4b8],xmm14
  4103b8:	vmovups XMMWORD PTR [rsp+0x4c8],xmm13
  4103c1:	vmovups XMMWORD PTR [rsp+0x4d8],xmm12
  4103ca:	mov    rbx,QWORD PTR [rcx]
  4103cd:	mov    rcx,QWORD PTR [rcx+0x8]
  4103d1:	mov    rsi,rcx
  4103d4:	xor    edi,edi
  4103d6:	vmovsd xmm6,QWORD PTR [rip+0x21b2]        # 412590 <__swc_rdata_base_7dafa2b1+0x480>
  4103de:	vmovsd xmm7,QWORD PTR [rip+0x21b3]        # 412599 <__swc_rdata_base_7dafa2b1+0x489>
  4103e6:	vmovsd xmm8,QWORD PTR [rip+0x21b4]        # 4125a2 <__swc_rdata_base_7dafa2b1+0x492>
  4103ee:	vmovsd xmm9,QWORD PTR [rip+0x21b5]        # 4125ab <__swc_rdata_base_7dafa2b1+0x49b>
  4103f6:	vmovsd xmm10,QWORD PTR [rip+0x21b6]        # 4125b4 <__swc_rdata_base_7dafa2b1+0x4a4>
  4103fe:	vmovups xmm11,xmm6
  410402:	vmovsd QWORD PTR [rsp+0x418],xmm7
  41040b:	vmovsd QWORD PTR [rsp+0x420],xmm8
  410414:	vmovsd QWORD PTR [rsp+0x428],xmm9
  41041d:	vmovsd QWORD PTR [rsp+0x430],xmm10
  410426:	vmovsd xmm15,QWORD PTR [rip+0x218f]        # 4125bd <__swc_rdata_base_7dafa2b1+0x4ad>
  41042e:	vmovups xmm14,xmm15
  410433:	vmovups xmm0,xmm9
  410438:	vmovsd QWORD PTR [rsp+0x438],xmm15
  410441:	vmovups xmm13,xmm8
  410446:	vmovsd QWORD PTR [rsp+0x440],xmm15
  41044f:	test   rsi,rsi
  410452:	je     411443 <__swc_fn_7dafa2b1_000146_e9d46966+0x10e3>
  410458:	cs nop WORD PTR [rax+rax*1+0x0]
  410462:	cs nop WORD PTR [rax+rax*1+0x0]
  41046c:	nop    DWORD PTR [rax+0x0]
  410470:	lea    rcx,[rdi+rdi*1]
  410474:	vmovdqu xmm2,XMMWORD PTR [rbx+rcx*8]
  410479:	vpshufd xmm3,xmm2,0xee
  41047e:	vmovq  rcx,xmm3
  410483:	test   rcx,rcx
  410486:	je     41049c <__swc_fn_7dafa2b1_000146_e9d46966+0x13c>
  410488:	test   DWORD PTR [rcx+0x28],0x400000
  41048f:	je     41049c <__swc_fn_7dafa2b1_000146_e9d46966+0x13c>
  410491:	mov    rdx,QWORD PTR [rcx+0x30]
  410495:	test   rdx,rdx
  410498:	cmovne rcx,rdx
  41049c:	test   DWORD PTR [rcx+0x28],0x1000
  4104a3:	je     4104c4 <__swc_fn_7dafa2b1_000146_e9d46966+0x164>
  4104a5:	mov    rdx,QWORD PTR [rcx+0x40]
  4104a9:	mov    rcx,rdx
  4104ac:	vmovq  r8,xmm2
  4104b1:	mov    r8,QWORD PTR [r8]
  4104b4:	mov    QWORD PTR [rsp+0x60],r8
  4104b9:	mov    QWORD PTR [rsp+0x68],rdx
  4104be:	vmovups xmm2,XMMWORD PTR [rsp+0x60]
  4104c4:	test   BYTE PTR [rcx+0x28],0x1
  4104c8:	jne    4104d0 <__swc_fn_7dafa2b1_000146_e9d46966+0x170>
  4104ca:	vmovups xmm12,xmm0
  4104ce:	jmp    4104ea <__swc_fn_7dafa2b1_000146_e9d46966+0x18a>
  4104d0:	vmovq  rax,xmm2
  4104d5:	mov    rax,QWORD PTR [rax]
  4104d8:	lea    rcx,[rax+0x10]
  4104dc:	vmovups xmm12,xmm0
  4104e0:	call   40faf0 <__swc_fn_7dafa2b1_000116_3499f7d6>
  4104e5:	jmp    411425 <__swc_fn_7dafa2b1_000146_e9d46966+0x10c5>
  4104ea:	test   DWORD PTR [rcx+0x28],0x400
  4104f1:	je     410552 <__swc_fn_7dafa2b1_000146_e9d46966+0x1f2>
  4104f3:	vmovq  rax,xmm2
  4104f8:	mov    rax,QWORD PTR [rax]
  4104fb:	xor    ecx,ecx
  4104fd:	test   rax,rax
  410500:	je     410530 <__swc_fn_7dafa2b1_000146_e9d46966+0x1d0>
  410502:	mov    rdx,rax
  410505:	mov    r8b,BYTE PTR [rdx]
  410508:	test   r8b,r8b
  41050b:	je     410530 <__swc_fn_7dafa2b1_000146_e9d46966+0x1d0>
  41050d:	cs nop WORD PTR [rax+rax*1+0x0]
  410517:	nop    WORD PTR [rax+rax*1+0x0]
  410520:	add    rdx,0x1
  410524:	add    rcx,0x1
  410528:	mov    r8b,BYTE PTR [rdx]
  41052b:	test   r8b,r8b
  41052e:	jne    410520 <__swc_fn_7dafa2b1_000146_e9d46966+0x1c0>
  410530:	mov    QWORD PTR [rsp+0x88],rax
  410538:	mov    QWORD PTR [rsp+0x90],rcx
  410540:	lea    rcx,[rsp+0x88]
  410548:	call   40faf0 <__swc_fn_7dafa2b1_000116_3499f7d6>
  41054d:	jmp    411425 <__swc_fn_7dafa2b1_000146_e9d46966+0x10c5>
  410552:	cmp    BYTE PTR [rcx+0x2c],0x6
  410556:	jne    41056d <__swc_fn_7dafa2b1_000146_e9d46966+0x20d>
  410558:	vmovq  rax,xmm2
  41055d:	mov    rax,QWORD PTR [rax]
  410560:	mov    rcx,rax
  410563:	call   409cb0 <__swc_fn_7dafa2b1_000144_364559f5>
  410568:	jmp    411425 <__swc_fn_7dafa2b1_000146_e9d46966+0x10c5>
  41056d:	cmp    BYTE PTR [rcx+0x2c],0x1
  410571:	jne    411419 <__swc_fn_7dafa2b1_000146_e9d46966+0x10b9>
  410577:	vmovq  rdx,xmm2
  41057c:	mov    cl,BYTE PTR [rcx+0x40]
  41057f:	cmp    cl,0x7
  410582:	jb     4105c5 <__swc_fn_7dafa2b1_000146_e9d46966+0x265>
  410584:	je     410638 <__swc_fn_7dafa2b1_000146_e9d46966+0x2d8>
  41058a:	cmp    cl,0x8
  41058d:	je     410644 <__swc_fn_7dafa2b1_000146_e9d46966+0x2e4>
  410593:	cmp    cl,0x9
  410596:	je     41065d <__swc_fn_7dafa2b1_000146_e9d46966+0x2fd>
  41059c:	cmp    cl,0xa
  41059f:	je     410d24 <__swc_fn_7dafa2b1_000146_e9d46966+0x9c4>
  4105a5:	cmp    cl,0xb
  4105a8:	je     4113eb <__swc_fn_7dafa2b1_000146_e9d46966+0x108b>
  4105ae:	cmp    cl,0xc
  4105b1:	je     410651 <__swc_fn_7dafa2b1_000146_e9d46966+0x2f1>
  4105b7:	cmp    cl,0xd
  4105ba:	je     4113e1 <__swc_fn_7dafa2b1_000146_e9d46966+0x1081>
  4105c0:	jmp    41140b <__swc_fn_7dafa2b1_000146_e9d46966+0x10ab>
  4105c5:	cmp    cl,0x1
  4105c8:	je     4105e8 <__swc_fn_7dafa2b1_000146_e9d46966+0x288>
  4105ca:	cmp    cl,0x2
  4105cd:	je     4105f6 <__swc_fn_7dafa2b1_000146_e9d46966+0x296>
  4105cf:	cmp    cl,0x3
  4105d2:	je     410604 <__swc_fn_7dafa2b1_000146_e9d46966+0x2a4>
  4105d4:	cmp    cl,0x4
  4105d7:	je     410611 <__swc_fn_7dafa2b1_000146_e9d46966+0x2b1>
  4105d9:	cmp    cl,0x5
  4105dc:	je     41061e <__swc_fn_7dafa2b1_000146_e9d46966+0x2be>
  4105de:	cmp    cl,0x6
  4105e1:	je     41062b <__swc_fn_7dafa2b1_000146_e9d46966+0x2cb>
  4105e3:	jmp    41140b <__swc_fn_7dafa2b1_000146_e9d46966+0x10ab>
  4105e8:	movsx  rcx,BYTE PTR [rdx]
  4105ec:	call   40cf20 <__swc_fn_7dafa2b1_000145_071b4f4c>
  4105f1:	jmp    411425 <__swc_fn_7dafa2b1_000146_e9d46966+0x10c5>
  4105f6:	movsx  rcx,WORD PTR [rdx]
  4105fa:	call   40cf20 <__swc_fn_7dafa2b1_000145_071b4f4c>
  4105ff:	jmp    411425 <__swc_fn_7dafa2b1_000146_e9d46966+0x10c5>
  410604:	movsxd rcx,DWORD PTR [rdx]
  410607:	call   40cf20 <__swc_fn_7dafa2b1_000145_071b4f4c>
  41060c:	jmp    411425 <__swc_fn_7dafa2b1_000146_e9d46966+0x10c5>
  410611:	mov    rcx,QWORD PTR [rdx]
  410614:	call   40cf20 <__swc_fn_7dafa2b1_000145_071b4f4c>
  410619:	jmp    411425 <__swc_fn_7dafa2b1_000146_e9d46966+0x10c5>
  41061e:	movzx  ecx,BYTE PTR [rdx]
  410621:	call   409cb0 <__swc_fn_7dafa2b1_000144_364559f5>
  410626:	jmp    411425 <__swc_fn_7dafa2b1_000146_e9d46966+0x10c5>
  41062b:	movzx  ecx,WORD PTR [rdx]
  41062e:	call   409cb0 <__swc_fn_7dafa2b1_000144_364559f5>
  410633:	jmp    411425 <__swc_fn_7dafa2b1_000146_e9d46966+0x10c5>
  410638:	mov    ecx,DWORD PTR [rdx]
  41063a:	call   409cb0 <__swc_fn_7dafa2b1_000144_364559f5>
  41063f:	jmp    411425 <__swc_fn_7dafa2b1_000146_e9d46966+0x10c5>
  410644:	mov    rcx,QWORD PTR [rdx]
  410647:	call   409cb0 <__swc_fn_7dafa2b1_000144_364559f5>
  41064c:	jmp    411425 <__swc_fn_7dafa2b1_000146_e9d46966+0x10c5>
  410651:	mov    ecx,DWORD PTR [rdx]
  410653:	call   409cb0 <__swc_fn_7dafa2b1_000144_364559f5>
  410658:	jmp    411425 <__swc_fn_7dafa2b1_000146_e9d46966+0x10c5>
  41065d:	lea    rcx,[rsp+0xa8]
  410665:	vxorps xmm0,xmm0,xmm0
  410669:	vmovups YMMWORD PTR [rsp+0xa8],ymm0
  410672:	vmovups YMMWORD PTR [rsp+0xc8],ymm0
  41067b:	vmovups YMMWORD PTR [rsp+0xe8],ymm0
  410684:	vzeroupper
  410687:	mov    DWORD PTR [rsp+0x108],0x0
  410692:	vxorpd xmm0,xmm0,xmm0
  410696:	vmovss xmm1,DWORD PTR [rdx]
  41069a:	vcvtss2sd xmm0,xmm0,xmm1
  41069e:	vmovsd xmm1,xmm1,xmm0
  4106a2:	vcomisd xmm0,xmm0
  4106a6:	setne  dl
  4106a9:	movzx  edx,dl
  4106ac:	setp   r8b
  4106b0:	movzx  r8d,r8b
  4106b4:	or     edx,r8d
  4106b7:	test   dl,dl
  4106b9:	je     4106c6 <__swc_fn_7dafa2b1_000146_e9d46966+0x366>
  4106bb:	mov    DWORD PTR [rcx],0x6e616e
  4106c1:	jmp    410cb8 <__swc_fn_7dafa2b1_000146_e9d46966+0x958>
  4106c6:	vcomisd xmm1,xmm6
  4106ca:	ja     4106d2 <__swc_fn_7dafa2b1_000146_e9d46966+0x372>
  4106cc:	vcomisd xmm7,xmm1
  4106d0:	jbe    4106f6 <__swc_fn_7dafa2b1_000146_e9d46966+0x396>
  4106d2:	vxorpd xmm0,xmm0,xmm0
  4106d6:	vcomisd xmm0,xmm1
  4106da:	jbe    4106eb <__swc_fn_7dafa2b1_000146_e9d46966+0x38b>
  4106dc:	mov    DWORD PTR [rcx],0x666e692d
  4106e2:	mov    BYTE PTR [rcx+0x4],0x0
  4106e6:	jmp    410cb8 <__swc_fn_7dafa2b1_000146_e9d46966+0x958>
  4106eb:	mov    DWORD PTR [rcx],0x666e69
  4106f1:	jmp    410cb8 <__swc_fn_7dafa2b1_000146_e9d46966+0x958>
  4106f6:	vcomisd xmm1,xmm8
  4106fb:	jae    410707 <__swc_fn_7dafa2b1_000146_e9d46966+0x3a7>
  4106fd:	vcomisd xmm9,xmm1
  410701:	jbe    410a7e <__swc_fn_7dafa2b1_000146_e9d46966+0x71e>
  410707:	vmovups xmm0,xmm1
  41070b:	vxorpd xmm2,xmm2,xmm2
  41070f:	vcomisd xmm2,xmm1
  410713:	jbe    410723 <__swc_fn_7dafa2b1_000146_e9d46966+0x3c3>
  410715:	vmovsd xmm1,xmm1,xmm0
  410719:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x1e2f]        # 412550 <__swc_rdata_base_7dafa2b1+0x440>
  410721:	jmp    410727 <__swc_fn_7dafa2b1_000146_e9d46966+0x3c7>
  410723:	vmovsd xmm1,xmm1,xmm0
  410727:	xor    r8d,r8d
  41072a:	vcomisd xmm1,xmm15
  41072f:	jb     410750 <__swc_fn_7dafa2b1_000146_e9d46966+0x3f0>
  410731:	cs nop WORD PTR [rax+rax*1+0x0]
  41073b:	nop    DWORD PTR [rax+rax*1+0x0]
  410740:	vdivsd xmm1,xmm1,xmm15
  410745:	add    r8,0x1
  410749:	vcomisd xmm1,xmm15
  41074e:	jae    410740 <__swc_fn_7dafa2b1_000146_e9d46966+0x3e0>
  410750:	mov    r9,rcx
  410753:	vxorpd xmm2,xmm2,xmm2
  410757:	vcomisd xmm2,xmm0
  41075b:	jbe    410764 <__swc_fn_7dafa2b1_000146_e9d46966+0x404>
  41075d:	mov    BYTE PTR [rcx],0x2d
  410760:	lea    r9,[rcx+0x1]
  410764:	vcvttsd2si rdx,xmm1
  410769:	mov    r10b,dl
  41076c:	add    r10b,0x30
  410770:	mov    BYTE PTR [r9],r10b
  410773:	vxorpd xmm0,xmm0,xmm0
  410777:	movzx  edx,dl
  41077a:	vcvtsi2sd xmm0,xmm0,rdx
  41077f:	vsubsd xmm0,xmm1,xmm0
  410783:	vmulsd xmm1,xmm0,xmm15
  410788:	mov    BYTE PTR [r9+0x1],0x2e
  41078d:	vcvttsd2si rdx,xmm1
  410792:	mov    r10b,dl
  410795:	add    r10b,0x30
  410799:	mov    BYTE PTR [r9+0x2],r10b
  41079d:	vxorpd xmm0,xmm0,xmm0
  4107a1:	movzx  edx,dl
  4107a4:	vcvtsi2sd xmm0,xmm0,rdx
  4107a9:	vsubsd xmm0,xmm1,xmm0
  4107ad:	vmulsd xmm1,xmm0,xmm15
  4107b2:	vcvttsd2si rdx,xmm1
  4107b7:	mov    r10b,dl
  4107ba:	add    r10b,0x30
  4107be:	mov    BYTE PTR [r9+0x3],r10b
  4107c2:	vxorpd xmm0,xmm0,xmm0
  4107c6:	movzx  edx,dl
  4107c9:	vcvtsi2sd xmm0,xmm0,rdx
  4107ce:	vsubsd xmm0,xmm1,xmm0
  4107d2:	vmulsd xmm1,xmm0,xmm15
  4107d7:	vcvttsd2si rdx,xmm1
  4107dc:	mov    r10b,dl
  4107df:	add    r10b,0x30
  4107e3:	mov    BYTE PTR [r9+0x4],r10b
  4107e7:	vxorpd xmm0,xmm0,xmm0
  4107eb:	movzx  edx,dl
  4107ee:	vcvtsi2sd xmm0,xmm0,rdx
  4107f3:	vsubsd xmm0,xmm1,xmm0
  4107f7:	vmulsd xmm1,xmm0,xmm15
  4107fc:	vcvttsd2si rdx,xmm1
  410801:	mov    r10b,dl
  410804:	add    r10b,0x30
  410808:	mov    BYTE PTR [r9+0x5],r10b
  41080c:	vxorpd xmm0,xmm0,xmm0
  410810:	movzx  edx,dl
  410813:	vcvtsi2sd xmm0,xmm0,rdx
  410818:	vsubsd xmm0,xmm1,xmm0
  41081c:	vmulsd xmm1,xmm0,xmm15
  410821:	vcvttsd2si rdx,xmm1
  410826:	mov    r10b,dl
  410829:	add    r10b,0x30
  41082d:	mov    BYTE PTR [r9+0x6],r10b
  410831:	vxorpd xmm0,xmm0,xmm0
  410835:	movzx  edx,dl
  410838:	vcvtsi2sd xmm0,xmm0,rdx
  41083d:	vsubsd xmm0,xmm1,xmm0
  410841:	vmulsd xmm1,xmm0,xmm15
  410846:	vcvttsd2si rdx,xmm1
  41084b:	mov    r10b,dl
  41084e:	add    r10b,0x30
  410852:	mov    BYTE PTR [r9+0x7],r10b
  410856:	vxorpd xmm0,xmm0,xmm0
  41085a:	movzx  edx,dl
  41085d:	vcvtsi2sd xmm0,xmm0,rdx
  410862:	vsubsd xmm0,xmm1,xmm0
  410866:	vmulsd xmm1,xmm0,xmm15
  41086b:	vcvttsd2si rdx,xmm1
  410870:	mov    r10b,dl
  410873:	add    r10b,0x30
  410877:	mov    BYTE PTR [r9+0x8],r10b
  41087b:	vxorpd xmm0,xmm0,xmm0
  41087f:	movzx  edx,dl
  410882:	vcvtsi2sd xmm0,xmm0,rdx
  410887:	vsubsd xmm0,xmm1,xmm0
  41088b:	vmulsd xmm1,xmm0,xmm15
  410890:	vcvttsd2si rdx,xmm1
  410895:	mov    r10b,dl
  410898:	add    r10b,0x30
  41089c:	mov    BYTE PTR [r9+0x9],r10b
  4108a0:	vxorpd xmm0,xmm0,xmm0
  4108a4:	movzx  edx,dl
  4108a7:	vcvtsi2sd xmm0,xmm0,rdx
  4108ac:	vsubsd xmm0,xmm1,xmm0
  4108b0:	vmulsd xmm1,xmm0,xmm15
  4108b5:	vcvttsd2si rdx,xmm1
  4108ba:	mov    r10b,dl
  4108bd:	add    r10b,0x30
  4108c1:	mov    BYTE PTR [r9+0xa],r10b
  4108c5:	vxorpd xmm0,xmm0,xmm0
  4108c9:	movzx  edx,dl
  4108cc:	vcvtsi2sd xmm0,xmm0,rdx
  4108d1:	vsubsd xmm0,xmm1,xmm0
  4108d5:	vmulsd xmm1,xmm0,xmm15
  4108da:	vcvttsd2si rdx,xmm1
  4108df:	mov    r10b,dl
  4108e2:	add    r10b,0x30
  4108e6:	mov    BYTE PTR [r9+0xb],r10b
  4108ea:	lea    r10,[r9+0x4]
  4108ee:	vxorpd xmm0,xmm0,xmm0
  4108f2:	movzx  edx,dl
  4108f5:	vcvtsi2sd xmm0,xmm0,rdx
  4108fa:	vsubsd xmm0,xmm1,xmm0
  4108fe:	vmulsd xmm1,xmm0,xmm15
  410903:	vcvttsd2si rdx,xmm1
  410908:	mov    r11b,dl
  41090b:	add    r11b,0x30
  41090f:	mov    BYTE PTR [r9+0xc],r11b
  410913:	vxorpd xmm0,xmm0,xmm0
  410917:	movzx  edx,dl
  41091a:	vcvtsi2sd xmm0,xmm0,rdx
  41091f:	vsubsd xmm0,xmm1,xmm0
  410923:	vmulsd xmm1,xmm0,xmm15
  410928:	vcvttsd2si rdx,xmm1
  41092d:	mov    r11b,dl
  410930:	add    r11b,0x30
  410934:	mov    BYTE PTR [r9+0xd],r11b
  410938:	lea    r10,[r10+0x2]
  41093c:	vxorpd xmm0,xmm0,xmm0
  410940:	movzx  edx,dl
  410943:	vcvtsi2sd xmm0,xmm0,rdx
  410948:	vsubsd xmm0,xmm1,xmm0
  41094c:	vmulsd xmm1,xmm0,xmm15
  410951:	vcvttsd2si rdx,xmm1
  410956:	mov    r11b,dl
  410959:	add    r11b,0x30
  41095d:	mov    BYTE PTR [r9+0xe],r11b
  410961:	vxorpd xmm0,xmm0,xmm0
  410965:	movzx  edx,dl
  410968:	vcvtsi2sd xmm0,xmm0,rdx
  41096d:	vsubsd xmm0,xmm1,xmm0
  410971:	vmulsd xmm1,xmm0,xmm15
  410976:	vcvttsd2si rdx,xmm1
  41097b:	mov    r11b,dl
  41097e:	add    r11b,0x30
  410982:	mov    BYTE PTR [r9+0xf],r11b
  410986:	lea    r10,[r10+0x2]
  41098a:	lea    r10,[r10+0x2]
  41098e:	lea    r10,[r10+0x2]
  410992:	lea    r10,[r10+0x2]
  410996:	lea    r10,[r10+0x2]
  41099a:	vxorpd xmm0,xmm0,xmm0
  41099e:	movzx  edx,dl
  4109a1:	vcvtsi2sd xmm0,xmm0,rdx
  4109a6:	vsubsd xmm0,xmm1,xmm0
  4109aa:	vmulsd xmm1,xmm0,xmm15
  4109af:	vcvttsd2si rdx,xmm1
  4109b4:	mov    r11b,dl
  4109b7:	add    r11b,0x30
  4109bb:	mov    BYTE PTR [r9+0x10],r11b
  4109bf:	vxorpd xmm0,xmm0,xmm0
  4109c3:	movzx  edx,dl
  4109c6:	vcvtsi2sd xmm0,xmm0,rdx
  4109cb:	vsubsd xmm0,xmm1,xmm0
  4109cf:	vmulsd xmm1,xmm0,xmm15
  4109d4:	vcvttsd2si rdx,xmm1
  4109d9:	add    dl,0x30
  4109dc:	mov    BYTE PTR [r9+0x11],dl
  4109e0:	mov    BYTE PTR [r10+0x2],0x65
  4109e5:	lea    r9,[r10+0x3]
  4109e9:	test   r8,r8
  4109ec:	jl     4109f5 <__swc_fn_7dafa2b1_000146_e9d46966+0x695>
  4109ee:	mov    BYTE PTR [r9],0x2b
  4109f2:	inc    r9
  4109f5:	mov    r10,r9
  4109f8:	mov    rdx,r8
  4109fb:	nop    DWORD PTR [rax+rax*1+0x0]
  410a00:	mov    r11,rdx
  410a03:	movabs rdx,0x6666666666666667
  410a0d:	mov    rax,r11
  410a10:	imul   rdx
  410a13:	sar    rdx,0x2
  410a17:	mov    r12,rdx
  410a1a:	shr    rdx,0x3f
  410a1e:	add    r12,rdx
  410a21:	mov    rdx,r12
  410a24:	imul   r13,r12,0xa
  410a28:	sub    r11,r13
  410a2b:	mov    r13,QWORD PTR [rip+0x1b0e]        # 412540 <__swc_rdata_base_7dafa2b1+0x430>
  410a32:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410a37:	mov    BYTE PTR [r10],r11b
  410a3a:	lea    r11,[r10+0x1]
  410a3e:	mov    r10,r11
  410a41:	test   r12,r12
  410a44:	jne    410a00 <__swc_fn_7dafa2b1_000146_e9d46966+0x6a0>
  410a46:	test   r8,r8
  410a49:	jge    410a53 <__swc_fn_7dafa2b1_000146_e9d46966+0x6f3>
  410a4b:	mov    BYTE PTR [r11],0x2d
  410a4f:	lea    r10,[r11+0x1]
  410a53:	mov    BYTE PTR [r10],0x0
  410a57:	sub    r10,0x1
  410a5b:	nop    DWORD PTR [rax+rax*1+0x0]
  410a60:	cmp    r9,r10
  410a63:	jae    410cb8 <__swc_fn_7dafa2b1_000146_e9d46966+0x958>
  410a69:	mov    al,BYTE PTR [r10]
  410a6c:	mov    dl,BYTE PTR [r9]
  410a6f:	mov    BYTE PTR [r10],dl
  410a72:	sub    r10,0x1
  410a76:	mov    BYTE PTR [r9],al
  410a79:	inc    r9
  410a7c:	jmp    410a60 <__swc_fn_7dafa2b1_000146_e9d46966+0x700>
  410a7e:	vcvttsd2si rdx,xmm1
  410a83:	mov    r8,rdx
  410a86:	vxorpd xmm0,xmm0,xmm0
  410a8a:	vcvtsi2sd xmm0,xmm0,rdx
  410a8f:	vsubsd xmm0,xmm1,xmm0
  410a93:	mov    r9d,0x8
  410a99:	vxorpd xmm2,xmm2,xmm2
  410a9d:	vcomisd xmm2,xmm0
  410aa1:	jbe    410aab <__swc_fn_7dafa2b1_000146_e9d46966+0x74b>
  410aa3:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x1aa5]        # 412550 <__swc_rdata_base_7dafa2b1+0x440>
  410aab:	test   r9d,r9d
  410aae:	je     410aba <__swc_fn_7dafa2b1_000146_e9d46966+0x75a>
  410ab0:	vmulsd xmm0,xmm0,xmm14
  410ab5:	dec    r9d
  410ab8:	jne    410ab0 <__swc_fn_7dafa2b1_000146_e9d46966+0x750>
  410aba:	vcvttsd2si r9,xmm0
  410abf:	mov    r10,r9
  410ac2:	vxorpd xmm2,xmm2,xmm2
  410ac6:	vcvtsi2sd xmm2,xmm2,r9
  410acb:	vsubsd xmm0,xmm0,xmm2
  410acf:	vcomisd xmm0,xmm10
  410ad4:	lea    r9,[r9+0x1]
  410ad8:	cmova  r10,r9
  410adc:	cmp    r10,0x5f5e100
  410ae3:	jne    410afc <__swc_fn_7dafa2b1_000146_e9d46966+0x79c>
  410ae5:	lea    r8,[rdx-0x1]
  410ae9:	vxorpd xmm0,xmm0,xmm0
  410aed:	vcomisd xmm0,xmm1
  410af1:	lea    rdx,[rdx+0x1]
  410af5:	cmovbe r8,rdx
  410af9:	xor    r10d,r10d
  410afc:	mov    r9,rcx
  410aff:	test   r8,r8
  410b02:	jne    410b22 <__swc_fn_7dafa2b1_000146_e9d46966+0x7c2>
  410b04:	vxorpd xmm0,xmm0,xmm0
  410b08:	vcomisd xmm0,xmm1
  410b0c:	jbe    410b15 <__swc_fn_7dafa2b1_000146_e9d46966+0x7b5>
  410b0e:	mov    BYTE PTR [rcx],0x2d
  410b11:	lea    r9,[rcx+0x1]
  410b15:	mov    BYTE PTR [r9],0x30
  410b19:	add    r9,0x1
  410b1d:	jmp    410bbb <__swc_fn_7dafa2b1_000146_e9d46966+0x85b>
  410b22:	mov    r9,rcx
  410b25:	mov    rdx,r8
  410b28:	nop    DWORD PTR [rax+rax*1+0x0]
  410b30:	mov    r11,rdx
  410b33:	movabs rdx,0x6666666666666667
  410b3d:	mov    r15,rax
  410b40:	mov    rax,r11
  410b43:	imul   rdx
  410b46:	mov    r12,rdx
  410b49:	mov    rax,r15
  410b4c:	sar    r12,0x2
  410b50:	mov    rdx,r12
  410b53:	shr    rdx,0x3f
  410b57:	add    r12,rdx
  410b5a:	mov    rdx,r12
  410b5d:	imul   r13,r12,0xa
  410b61:	sub    r11,r13
  410b64:	mov    r13,QWORD PTR [rip+0x19d5]        # 412540 <__swc_rdata_base_7dafa2b1+0x430>
  410b6b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410b70:	mov    BYTE PTR [r9],r11b
  410b73:	lea    r11,[r9+0x1]
  410b77:	mov    r9,r11
  410b7a:	test   r12,r12
  410b7d:	jne    410b30 <__swc_fn_7dafa2b1_000146_e9d46966+0x7d0>
  410b7f:	test   r8,r8
  410b82:	jge    410b8c <__swc_fn_7dafa2b1_000146_e9d46966+0x82c>
  410b84:	mov    BYTE PTR [r11],0x2d
  410b88:	lea    r9,[r11+0x1]
  410b8c:	mov    rdx,r9
  410b8f:	mov    BYTE PTR [r9],0x0
  410b93:	sub    r9,0x1
  410b97:	mov    r8,rcx
  410b9a:	cmp    r8,r9
  410b9d:	jae    410bb8 <__swc_fn_7dafa2b1_000146_e9d46966+0x858>
  410b9f:	nop
  410ba0:	mov    r11b,BYTE PTR [r9]
  410ba3:	mov    r12b,BYTE PTR [r8]
  410ba6:	mov    BYTE PTR [r9],r12b
  410ba9:	sub    r9,0x1
  410bad:	mov    BYTE PTR [r8],r11b
  410bb0:	inc    r8
  410bb3:	cmp    r8,r9
  410bb6:	jb     410ba0 <__swc_fn_7dafa2b1_000146_e9d46966+0x840>
  410bb8:	mov    r9,rdx
  410bbb:	mov    BYTE PTR [r9],0x2e
  410bbf:	add    r9,0x1
  410bc3:	xor    r8d,r8d
  410bc6:	test   r10,r10
  410bc9:	je     410c0f <__swc_fn_7dafa2b1_000146_e9d46966+0x8af>
  410bcb:	mov    r11d,0x989680
  410bd1:	cmp    r10,r11
  410bd4:	jge    410c0f <__swc_fn_7dafa2b1_000146_e9d46966+0x8af>
  410bd6:	cs nop WORD PTR [rax+rax*1+0x0]
  410be0:	inc    r8d
  410be3:	movabs rdx,0x6666666666666667
  410bed:	mov    r15,rax
  410bf0:	mov    rax,r11
  410bf3:	imul   rdx
  410bf6:	mov    r11,rdx
  410bf9:	mov    rax,r15
  410bfc:	sar    r11,0x2
  410c00:	mov    rdx,r11
  410c03:	shr    rdx,0x3f
  410c07:	add    r11,rdx
  410c0a:	cmp    r10,r11
  410c0d:	jl     410be0 <__swc_fn_7dafa2b1_000146_e9d46966+0x880>
  410c0f:	test   r8d,r8d
  410c12:	je     410c2d <__swc_fn_7dafa2b1_000146_e9d46966+0x8cd>
  410c14:	cs nop WORD PTR [rax+rax*1+0x0]
  410c1e:	xchg   ax,ax
  410c20:	mov    BYTE PTR [r9],0x30
  410c24:	add    r9,0x1
  410c28:	dec    r8d
  410c2b:	jne    410c20 <__swc_fn_7dafa2b1_000146_e9d46966+0x8c0>
  410c2d:	mov    r8,r9
  410c30:	mov    rdx,r10
  410c33:	cs nop WORD PTR [rax+rax*1+0x0]
  410c3d:	nop    DWORD PTR [rax]
  410c40:	mov    r11,rdx
  410c43:	movabs rdx,0x6666666666666667
  410c4d:	mov    rax,r11
  410c50:	imul   rdx
  410c53:	sar    rdx,0x2
  410c57:	mov    r12,rdx
  410c5a:	shr    rdx,0x3f
  410c5e:	add    r12,rdx
  410c61:	mov    rdx,r12
  410c64:	imul   r13,r12,0xa
  410c68:	sub    r11,r13
  410c6b:	mov    r13,QWORD PTR [rip+0x18ce]        # 412540 <__swc_rdata_base_7dafa2b1+0x430>
  410c72:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  410c77:	mov    BYTE PTR [r8],r11b
  410c7a:	lea    r11,[r8+0x1]
  410c7e:	mov    r8,r11
  410c81:	test   r12,r12
  410c84:	jne    410c40 <__swc_fn_7dafa2b1_000146_e9d46966+0x8e0>
  410c86:	test   r10,r10
  410c89:	jge    410c93 <__swc_fn_7dafa2b1_000146_e9d46966+0x933>
  410c8b:	mov    BYTE PTR [r11],0x2d
  410c8f:	lea    r8,[r11+0x1]
  410c93:	mov    BYTE PTR [r8],0x0
  410c97:	sub    r8,0x1
  410c9b:	cmp    r9,r8
  410c9e:	jae    410cb8 <__swc_fn_7dafa2b1_000146_e9d46966+0x958>
  410ca0:	mov    al,BYTE PTR [r8]
  410ca3:	mov    dl,BYTE PTR [r9]
  410ca6:	mov    BYTE PTR [r8],dl
  410ca9:	sub    r8,0x1
  410cad:	mov    BYTE PTR [r9],al
  410cb0:	inc    r9
  410cb3:	cmp    r9,r8
  410cb6:	jb     410ca0 <__swc_fn_7dafa2b1_000146_e9d46966+0x940>
  410cb8:	xor    eax,eax
  410cba:	test   rcx,rcx
  410cbd:	je     410cf0 <__swc_fn_7dafa2b1_000146_e9d46966+0x990>
  410cbf:	mov    rdx,rcx
  410cc2:	mov    r8b,BYTE PTR [rdx]
  410cc5:	test   r8b,r8b
  410cc8:	je     410cf0 <__swc_fn_7dafa2b1_000146_e9d46966+0x990>
  410cca:	cs nop WORD PTR [rax+rax*1+0x0]
  410cd4:	cs nop WORD PTR [rax+rax*1+0x0]
  410cde:	xchg   ax,ax
  410ce0:	add    rdx,0x1
  410ce4:	add    rax,0x1
  410ce8:	mov    r8b,BYTE PTR [rdx]
  410ceb:	test   r8b,r8b
  410cee:	jne    410ce0 <__swc_fn_7dafa2b1_000146_e9d46966+0x980>
  410cf0:	mov    QWORD PTR [rsp+0x240],rcx
  410cf8:	mov    QWORD PTR [rsp+0x248],rax
  410d00:	vmovups xmm0,XMMWORD PTR [rsp+0x240]
  410d09:	vmovups XMMWORD PTR [rsp+0x250],xmm0
  410d12:	lea    rcx,[rsp+0x250]
  410d1a:	call   40faf0 <__swc_fn_7dafa2b1_000116_3499f7d6>
  410d1f:	jmp    411425 <__swc_fn_7dafa2b1_000146_e9d46966+0x10c5>
  410d24:	lea    rcx,[rsp+0x260]
  410d2c:	vxorps xmm0,xmm0,xmm0
  410d30:	vmovups YMMWORD PTR [rsp+0x260],ymm0
  410d39:	vmovups YMMWORD PTR [rsp+0x280],ymm0
  410d42:	vmovups YMMWORD PTR [rsp+0x2a0],ymm0
  410d4b:	vzeroupper
  410d4e:	mov    DWORD PTR [rsp+0x2c0],0x0
  410d59:	vmovsd xmm0,QWORD PTR [rdx]
  410d5d:	vcomisd xmm0,xmm0
  410d61:	setne  dl
  410d64:	movzx  edx,dl
  410d67:	setp   r8b
  410d6b:	movzx  r8d,r8b
  410d6f:	or     edx,r8d
  410d72:	test   dl,dl
  410d74:	je     410d81 <__swc_fn_7dafa2b1_000146_e9d46966+0xa21>
  410d76:	mov    DWORD PTR [rcx],0x6e616e
  410d7c:	jmp    411388 <__swc_fn_7dafa2b1_000146_e9d46966+0x1028>
  410d81:	vcomisd xmm0,xmm11
  410d86:	ja     410d97 <__swc_fn_7dafa2b1_000146_e9d46966+0xa37>
  410d88:	vmovsd xmm6,QWORD PTR [rsp+0x418]
  410d91:	vcomisd xmm6,xmm0
  410d95:	jbe    410dbb <__swc_fn_7dafa2b1_000146_e9d46966+0xa5b>
  410d97:	vxorpd xmm1,xmm1,xmm1
  410d9b:	vcomisd xmm1,xmm0
  410d9f:	jbe    410db0 <__swc_fn_7dafa2b1_000146_e9d46966+0xa50>
  410da1:	mov    DWORD PTR [rcx],0x666e692d
  410da7:	mov    BYTE PTR [rcx+0x4],0x0
  410dab:	jmp    411388 <__swc_fn_7dafa2b1_000146_e9d46966+0x1028>
  410db0:	mov    DWORD PTR [rcx],0x666e69
  410db6:	jmp    411388 <__swc_fn_7dafa2b1_000146_e9d46966+0x1028>
  410dbb:	vcomisd xmm0,xmm13
  410dc0:	jae    410dcc <__swc_fn_7dafa2b1_000146_e9d46966+0xa6c>
  410dc2:	vcomisd xmm12,xmm0
  410dc6:	jbe    41112e <__swc_fn_7dafa2b1_000146_e9d46966+0xdce>
  410dcc:	vmovups xmm1,xmm0
  410dd0:	vxorpd xmm2,xmm2,xmm2
  410dd4:	vcomisd xmm2,xmm0
  410dd8:	jbe    410de8 <__swc_fn_7dafa2b1_000146_e9d46966+0xa88>
  410dda:	vmovsd xmm0,xmm0,xmm1
  410dde:	vxorpd xmm0,xmm0,XMMWORD PTR [rip+0x176a]        # 412550 <__swc_rdata_base_7dafa2b1+0x440>
  410de6:	jmp    410dec <__swc_fn_7dafa2b1_000146_e9d46966+0xa8c>
  410de8:	vmovsd xmm0,xmm0,xmm1
  410dec:	vmovsd xmm6,QWORD PTR [rsp+0x438]
  410df5:	xor    r8d,r8d
  410df8:	vcomisd xmm0,xmm6
  410dfc:	jb     410e0e <__swc_fn_7dafa2b1_000146_e9d46966+0xaae>
  410dfe:	xchg   ax,ax
  410e00:	vdivsd xmm0,xmm0,xmm6
  410e04:	add    r8,0x1
  410e08:	vcomisd xmm0,xmm6
  410e0c:	jae    410e00 <__swc_fn_7dafa2b1_000146_e9d46966+0xaa0>
  410e0e:	mov    r9,rcx
  410e11:	vxorpd xmm2,xmm2,xmm2
  410e15:	vcomisd xmm2,xmm1
  410e19:	jbe    410e22 <__swc_fn_7dafa2b1_000146_e9d46966+0xac2>
  410e1b:	mov    BYTE PTR [rcx],0x2d
  410e1e:	lea    r9,[rcx+0x1]
  410e22:	vcvttsd2si rdx,xmm0
  410e27:	mov    r10b,dl
  410e2a:	add    r10b,0x30
  410e2e:	mov    BYTE PTR [r9],r10b
  410e31:	vxorpd xmm1,xmm1,xmm1
  410e35:	movzx  edx,dl
  410e38:	vcvtsi2sd xmm1,xmm1,rdx
  410e3d:	vsubsd xmm0,xmm0,xmm1
  410e41:	vmulsd xmm0,xmm0,xmm6
  410e45:	mov    BYTE PTR [r9+0x1],0x2e
  410e4a:	vcvttsd2si rdx,xmm0
  410e4f:	mov    r10b,dl
  410e52:	add    r10b,0x30
  410e56:	mov    BYTE PTR [r9+0x2],r10b
  410e5a:	vxorpd xmm1,xmm1,xmm1
  410e5e:	movzx  edx,dl
  410e61:	vcvtsi2sd xmm1,xmm1,rdx
  410e66:	vsubsd xmm0,xmm0,xmm1
  410e6a:	vmulsd xmm0,xmm0,xmm6
  410e6e:	vcvttsd2si rdx,xmm0
  410e73:	mov    r10b,dl
  410e76:	add    r10b,0x30
  410e7a:	mov    BYTE PTR [r9+0x3],r10b
  410e7e:	vxorpd xmm1,xmm1,xmm1
  410e82:	movzx  edx,dl
  410e85:	vcvtsi2sd xmm1,xmm1,rdx
  410e8a:	vsubsd xmm0,xmm0,xmm1
  410e8e:	vmulsd xmm0,xmm0,xmm6
  410e92:	vcvttsd2si rdx,xmm0
  410e97:	mov    r10b,dl
  410e9a:	add    r10b,0x30
  410e9e:	mov    BYTE PTR [r9+0x4],r10b
  410ea2:	vxorpd xmm1,xmm1,xmm1
  410ea6:	movzx  edx,dl
  410ea9:	vcvtsi2sd xmm1,xmm1,rdx
  410eae:	vsubsd xmm0,xmm0,xmm1
  410eb2:	vmulsd xmm0,xmm0,xmm6
  410eb6:	vcvttsd2si rdx,xmm0
  410ebb:	mov    r10b,dl
  410ebe:	add    r10b,0x30
  410ec2:	mov    BYTE PTR [r9+0x5],r10b
  410ec6:	vxorpd xmm1,xmm1,xmm1
  410eca:	movzx  edx,dl
  410ecd:	vcvtsi2sd xmm1,xmm1,rdx
  410ed2:	vsubsd xmm0,xmm0,xmm1
  410ed6:	vmulsd xmm0,xmm0,xmm6
  410eda:	vcvttsd2si rdx,xmm0
  410edf:	mov    r10b,dl
  410ee2:	add    r10b,0x30
  410ee6:	mov    BYTE PTR [r9+0x6],r10b
  410eea:	vxorpd xmm1,xmm1,xmm1
  410eee:	movzx  edx,dl
  410ef1:	vcvtsi2sd xmm1,xmm1,rdx
  410ef6:	vsubsd xmm0,xmm0,xmm1
  410efa:	vmulsd xmm0,xmm0,xmm6
  410efe:	vcvttsd2si rdx,xmm0
  410f03:	mov    r10b,dl
  410f06:	add    r10b,0x30
  410f0a:	mov    BYTE PTR [r9+0x7],r10b
  410f0e:	vxorpd xmm1,xmm1,xmm1
  410f12:	movzx  edx,dl
  410f15:	vcvtsi2sd xmm1,xmm1,rdx
  410f1a:	vsubsd xmm0,xmm0,xmm1
  410f1e:	vmulsd xmm0,xmm0,xmm6
  410f22:	vcvttsd2si rdx,xmm0
  410f27:	mov    r10b,dl
  410f2a:	add    r10b,0x30
  410f2e:	mov    BYTE PTR [r9+0x8],r10b
  410f32:	vxorpd xmm1,xmm1,xmm1
  410f36:	movzx  edx,dl
  410f39:	vcvtsi2sd xmm1,xmm1,rdx
  410f3e:	vsubsd xmm0,xmm0,xmm1
  410f42:	vmulsd xmm0,xmm0,xmm6
  410f46:	vcvttsd2si rdx,xmm0
  410f4b:	mov    r10b,dl
  410f4e:	add    r10b,0x30
  410f52:	mov    BYTE PTR [r9+0x9],r10b
  410f56:	vxorpd xmm1,xmm1,xmm1
  410f5a:	movzx  edx,dl
  410f5d:	vcvtsi2sd xmm1,xmm1,rdx
  410f62:	vsubsd xmm0,xmm0,xmm1
  410f66:	vmulsd xmm0,xmm0,xmm6
  410f6a:	vcvttsd2si rdx,xmm0
  410f6f:	mov    r10b,dl
  410f72:	add    r10b,0x30
  410f76:	mov    BYTE PTR [r9+0xa],r10b
  410f7a:	vxorpd xmm1,xmm1,xmm1
  410f7e:	movzx  edx,dl
  410f81:	vcvtsi2sd xmm1,xmm1,rdx
  410f86:	vsubsd xmm0,xmm0,xmm1
  410f8a:	vmulsd xmm0,xmm0,xmm6
  410f8e:	vcvttsd2si rdx,xmm0
  410f93:	mov    r10b,dl
  410f96:	add    r10b,0x30
  410f9a:	mov    BYTE PTR [r9+0xb],r10b
  410f9e:	lea    r10,[r9+0x4]
  410fa2:	vxorpd xmm1,xmm1,xmm1
  410fa6:	movzx  edx,dl
  410fa9:	vcvtsi2sd xmm1,xmm1,rdx
  410fae:	vsubsd xmm0,xmm0,xmm1
  410fb2:	vmulsd xmm0,xmm0,xmm6
  410fb6:	vcvttsd2si rdx,xmm0
  410fbb:	mov    r11b,dl
  410fbe:	add    r11b,0x30
  410fc2:	mov    BYTE PTR [r9+0xc],r11b
  410fc6:	vxorpd xmm1,xmm1,xmm1
  410fca:	movzx  edx,dl
  410fcd:	vcvtsi2sd xmm1,xmm1,rdx
  410fd2:	vsubsd xmm0,xmm0,xmm1
  410fd6:	vmulsd xmm0,xmm0,xmm6
  410fda:	vcvttsd2si rdx,xmm0
  410fdf:	mov    r11b,dl
  410fe2:	add    r11b,0x30
  410fe6:	mov    BYTE PTR [r9+0xd],r11b
  410fea:	lea    r10,[r10+0x2]
  410fee:	vxorpd xmm1,xmm1,xmm1
  410ff2:	movzx  edx,dl
  410ff5:	vcvtsi2sd xmm1,xmm1,rdx
  410ffa:	vsubsd xmm0,xmm0,xmm1
  410ffe:	vmulsd xmm0,xmm0,xmm6
  411002:	vcvttsd2si rdx,xmm0
  411007:	mov    r11b,dl
  41100a:	add    r11b,0x30
  41100e:	mov    BYTE PTR [r9+0xe],r11b
  411012:	vxorpd xmm1,xmm1,xmm1
  411016:	movzx  edx,dl
  411019:	vcvtsi2sd xmm1,xmm1,rdx
  41101e:	vsubsd xmm0,xmm0,xmm1
  411022:	vmulsd xmm0,xmm0,xmm6
  411026:	vcvttsd2si rdx,xmm0
  41102b:	mov    r11b,dl
  41102e:	add    r11b,0x30
  411032:	mov    BYTE PTR [r9+0xf],r11b
  411036:	lea    r10,[r10+0x2]
  41103a:	lea    r10,[r10+0x2]
  41103e:	lea    r10,[r10+0x2]
  411042:	lea    r10,[r10+0x2]
  411046:	lea    r10,[r10+0x2]
  41104a:	vxorpd xmm1,xmm1,xmm1
  41104e:	movzx  edx,dl
  411051:	vcvtsi2sd xmm1,xmm1,rdx
  411056:	vsubsd xmm0,xmm0,xmm1
  41105a:	vmulsd xmm0,xmm0,xmm6
  41105e:	vcvttsd2si rdx,xmm0
  411063:	mov    r11b,dl
  411066:	add    r11b,0x30
  41106a:	mov    BYTE PTR [r9+0x10],r11b
  41106e:	vxorpd xmm1,xmm1,xmm1
  411072:	movzx  edx,dl
  411075:	vcvtsi2sd xmm1,xmm1,rdx
  41107a:	vsubsd xmm0,xmm0,xmm1
  41107e:	vmulsd xmm0,xmm0,xmm6
  411082:	vcvttsd2si rdx,xmm0
  411087:	add    dl,0x30
  41108a:	mov    BYTE PTR [r9+0x11],dl
  41108e:	mov    BYTE PTR [r10+0x2],0x65
  411093:	lea    r9,[r10+0x3]
  411097:	test   r8,r8
  41109a:	jl     4110a3 <__swc_fn_7dafa2b1_000146_e9d46966+0xd43>
  41109c:	mov    BYTE PTR [r9],0x2b
  4110a0:	inc    r9
  4110a3:	mov    r10,r9
  4110a6:	mov    rdx,r8
  4110a9:	nop    DWORD PTR [rax+0x0]
  4110b0:	mov    r11,rdx
  4110b3:	movabs rdx,0x6666666666666667
  4110bd:	mov    rax,r11
  4110c0:	imul   rdx
  4110c3:	sar    rdx,0x2
  4110c7:	mov    r12,rdx
  4110ca:	shr    rdx,0x3f
  4110ce:	add    r12,rdx
  4110d1:	mov    rdx,r12
  4110d4:	imul   r13,r12,0xa
  4110d8:	sub    r11,r13
  4110db:	mov    r13,QWORD PTR [rip+0x145e]        # 412540 <__swc_rdata_base_7dafa2b1+0x430>
  4110e2:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  4110e7:	mov    BYTE PTR [r10],r11b
  4110ea:	lea    r11,[r10+0x1]
  4110ee:	mov    r10,r11
  4110f1:	test   r12,r12
  4110f4:	jne    4110b0 <__swc_fn_7dafa2b1_000146_e9d46966+0xd50>
  4110f6:	test   r8,r8
  4110f9:	jge    411103 <__swc_fn_7dafa2b1_000146_e9d46966+0xda3>
  4110fb:	mov    BYTE PTR [r11],0x2d
  4110ff:	lea    r10,[r11+0x1]
  411103:	mov    BYTE PTR [r10],0x0
  411107:	sub    r10,0x1
  41110b:	nop    DWORD PTR [rax+rax*1+0x0]
  411110:	cmp    r9,r10
  411113:	jae    411388 <__swc_fn_7dafa2b1_000146_e9d46966+0x1028>
  411119:	mov    al,BYTE PTR [r10]
  41111c:	mov    dl,BYTE PTR [r9]
  41111f:	mov    BYTE PTR [r10],dl
  411122:	sub    r10,0x1
  411126:	mov    BYTE PTR [r9],al
  411129:	inc    r9
  41112c:	jmp    411110 <__swc_fn_7dafa2b1_000146_e9d46966+0xdb0>
  41112e:	vcvttsd2si rdx,xmm0
  411133:	mov    r8,rdx
  411136:	vxorpd xmm1,xmm1,xmm1
  41113a:	vcvtsi2sd xmm1,xmm1,rdx
  41113f:	vsubsd xmm1,xmm0,xmm1
  411143:	mov    r9d,0x8
  411149:	vxorpd xmm2,xmm2,xmm2
  41114d:	vcomisd xmm2,xmm1
  411151:	ja     41115e <__swc_fn_7dafa2b1_000146_e9d46966+0xdfe>
  411153:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41115c:	jmp    41116f <__swc_fn_7dafa2b1_000146_e9d46966+0xe0f>
  41115e:	vxorpd xmm1,xmm1,XMMWORD PTR [rip+0x13ea]        # 412550 <__swc_rdata_base_7dafa2b1+0x440>
  411166:	vmovsd xmm6,QWORD PTR [rsp+0x440]
  41116f:	test   r9d,r9d
  411172:	je     411189 <__swc_fn_7dafa2b1_000146_e9d46966+0xe29>
  411174:	cs nop WORD PTR [rax+rax*1+0x0]
  41117e:	xchg   ax,ax
  411180:	vmulsd xmm1,xmm1,xmm6
  411184:	dec    r9d
  411187:	jne    411180 <__swc_fn_7dafa2b1_000146_e9d46966+0xe20>
  411189:	vcvttsd2si r9,xmm1
  41118e:	mov    r10,r9
  411191:	vxorpd xmm2,xmm2,xmm2
  411195:	vcvtsi2sd xmm2,xmm2,r9
  41119a:	vsubsd xmm1,xmm1,xmm2
  41119e:	vmovsd xmm6,QWORD PTR [rsp+0x430]
  4111a7:	vcomisd xmm1,xmm6
  4111ab:	lea    r9,[r9+0x1]
  4111af:	cmova  r10,r9
  4111b3:	cmp    r10,0x5f5e100
  4111ba:	jne    4111d3 <__swc_fn_7dafa2b1_000146_e9d46966+0xe73>
  4111bc:	lea    r8,[rdx-0x1]
  4111c0:	vxorpd xmm1,xmm1,xmm1
  4111c4:	vcomisd xmm1,xmm0
  4111c8:	lea    rdx,[rdx+0x1]
  4111cc:	cmovbe r8,rdx
  4111d0:	xor    r10d,r10d
  4111d3:	mov    r9,rcx
  4111d6:	test   r8,r8
  4111d9:	jne    4111f9 <__swc_fn_7dafa2b1_000146_e9d46966+0xe99>
  4111db:	vxorpd xmm1,xmm1,xmm1
  4111df:	vcomisd xmm1,xmm0
  4111e3:	jbe    4111ec <__swc_fn_7dafa2b1_000146_e9d46966+0xe8c>
  4111e5:	mov    BYTE PTR [rcx],0x2d
  4111e8:	lea    r9,[rcx+0x1]
  4111ec:	mov    BYTE PTR [r9],0x30
  4111f0:	add    r9,0x1
  4111f4:	jmp    41128b <__swc_fn_7dafa2b1_000146_e9d46966+0xf2b>
  4111f9:	mov    r9,rcx
  4111fc:	mov    rdx,r8
  4111ff:	nop
  411200:	mov    r11,rdx
  411203:	movabs rdx,0x6666666666666667
  41120d:	mov    r15,rax
  411210:	mov    rax,r11
  411213:	imul   rdx
  411216:	mov    r12,rdx
  411219:	mov    rax,r15
  41121c:	sar    r12,0x2
  411220:	mov    rdx,r12
  411223:	shr    rdx,0x3f
  411227:	add    r12,rdx
  41122a:	mov    rdx,r12
  41122d:	imul   r13,r12,0xa
  411231:	sub    r11,r13
  411234:	mov    r13,QWORD PTR [rip+0x1305]        # 412540 <__swc_rdata_base_7dafa2b1+0x430>
  41123b:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411240:	mov    BYTE PTR [r9],r11b
  411243:	lea    r11,[r9+0x1]
  411247:	mov    r9,r11
  41124a:	test   r12,r12
  41124d:	jne    411200 <__swc_fn_7dafa2b1_000146_e9d46966+0xea0>
  41124f:	test   r8,r8
  411252:	jge    41125c <__swc_fn_7dafa2b1_000146_e9d46966+0xefc>
  411254:	mov    BYTE PTR [r11],0x2d
  411258:	lea    r9,[r11+0x1]
  41125c:	mov    rdx,r9
  41125f:	mov    BYTE PTR [r9],0x0
  411263:	sub    r9,0x1
  411267:	mov    r8,rcx
  41126a:	cmp    r8,r9
  41126d:	jae    411288 <__swc_fn_7dafa2b1_000146_e9d46966+0xf28>
  41126f:	nop
  411270:	mov    r11b,BYTE PTR [r9]
  411273:	mov    r12b,BYTE PTR [r8]
  411276:	mov    BYTE PTR [r9],r12b
  411279:	sub    r9,0x1
  41127d:	mov    BYTE PTR [r8],r11b
  411280:	inc    r8
  411283:	cmp    r8,r9
  411286:	jb     411270 <__swc_fn_7dafa2b1_000146_e9d46966+0xf10>
  411288:	mov    r9,rdx
  41128b:	mov    BYTE PTR [r9],0x2e
  41128f:	add    r9,0x1
  411293:	xor    r8d,r8d
  411296:	test   r10,r10
  411299:	je     4112df <__swc_fn_7dafa2b1_000146_e9d46966+0xf7f>
  41129b:	mov    r11d,0x989680
  4112a1:	cmp    r10,r11
  4112a4:	jge    4112df <__swc_fn_7dafa2b1_000146_e9d46966+0xf7f>
  4112a6:	cs nop WORD PTR [rax+rax*1+0x0]
  4112b0:	inc    r8d
  4112b3:	movabs rdx,0x6666666666666667
  4112bd:	mov    r15,rax
  4112c0:	mov    rax,r11
  4112c3:	imul   rdx
  4112c6:	mov    r11,rdx
  4112c9:	mov    rax,r15
  4112cc:	sar    r11,0x2
  4112d0:	mov    rdx,r11
  4112d3:	shr    rdx,0x3f
  4112d7:	add    r11,rdx
  4112da:	cmp    r10,r11
  4112dd:	jl     4112b0 <__swc_fn_7dafa2b1_000146_e9d46966+0xf50>
  4112df:	test   r8d,r8d
  4112e2:	je     4112fd <__swc_fn_7dafa2b1_000146_e9d46966+0xf9d>
  4112e4:	cs nop WORD PTR [rax+rax*1+0x0]
  4112ee:	xchg   ax,ax
  4112f0:	mov    BYTE PTR [r9],0x30
  4112f4:	add    r9,0x1
  4112f8:	dec    r8d
  4112fb:	jne    4112f0 <__swc_fn_7dafa2b1_000146_e9d46966+0xf90>
  4112fd:	mov    r8,r9
  411300:	mov    rdx,r10
  411303:	cs nop WORD PTR [rax+rax*1+0x0]
  41130d:	nop    DWORD PTR [rax]
  411310:	mov    r11,rdx
  411313:	movabs rdx,0x6666666666666667
  41131d:	mov    rax,r11
  411320:	imul   rdx
  411323:	sar    rdx,0x2
  411327:	mov    r12,rdx
  41132a:	shr    rdx,0x3f
  41132e:	add    r12,rdx
  411331:	mov    rdx,r12
  411334:	imul   r13,r12,0xa
  411338:	sub    r11,r13
  41133b:	mov    r13,QWORD PTR [rip+0x11fe]        # 412540 <__swc_rdata_base_7dafa2b1+0x430>
  411342:	mov    r11b,BYTE PTR [r13+r11*1+0x23]
  411347:	mov    BYTE PTR [r8],r11b
  41134a:	lea    r11,[r8+0x1]
  41134e:	mov    r8,r11
  411351:	test   r12,r12
  411354:	jne    411310 <__swc_fn_7dafa2b1_000146_e9d46966+0xfb0>
  411356:	test   r10,r10
  411359:	jge    411363 <__swc_fn_7dafa2b1_000146_e9d46966+0x1003>
  41135b:	mov    BYTE PTR [r11],0x2d
  41135f:	lea    r8,[r11+0x1]
  411363:	mov    BYTE PTR [r8],0x0
  411367:	sub    r8,0x1
  41136b:	cmp    r9,r8
  41136e:	jae    411388 <__swc_fn_7dafa2b1_000146_e9d46966+0x1028>
  411370:	mov    al,BYTE PTR [r8]
  411373:	mov    dl,BYTE PTR [r9]
  411376:	mov    BYTE PTR [r8],dl
  411379:	sub    r8,0x1
  41137d:	mov    BYTE PTR [r9],al
  411380:	inc    r9
  411383:	cmp    r9,r8
  411386:	jb     411370 <__swc_fn_7dafa2b1_000146_e9d46966+0x1010>
  411388:	xor    eax,eax
  41138a:	test   rcx,rcx
  41138d:	je     4113b0 <__swc_fn_7dafa2b1_000146_e9d46966+0x1050>
  41138f:	mov    rdx,rcx
  411392:	mov    r8b,BYTE PTR [rdx]
  411395:	test   r8b,r8b
  411398:	je     4113b0 <__swc_fn_7dafa2b1_000146_e9d46966+0x1050>
  41139a:	nop    WORD PTR [rax+rax*1+0x0]
  4113a0:	add    rdx,0x1
  4113a4:	add    rax,0x1
  4113a8:	mov    r8b,BYTE PTR [rdx]
  4113ab:	test   r8b,r8b
  4113ae:	jne    4113a0 <__swc_fn_7dafa2b1_000146_e9d46966+0x1040>
  4113b0:	mov    QWORD PTR [rsp+0x3f8],rcx
  4113b8:	mov    QWORD PTR [rsp+0x400],rax
  4113c0:	vmovups xmm0,XMMWORD PTR [rsp+0x3f8]
  4113c9:	vmovups XMMWORD PTR [rsp+0x408],xmm0
  4113d2:	lea    rcx,[rsp+0x408]
  4113da:	call   40faf0 <__swc_fn_7dafa2b1_000116_3499f7d6>
  4113df:	jmp    411425 <__swc_fn_7dafa2b1_000146_e9d46966+0x10c5>
  4113e1:	mov    rcx,rdx
  4113e4:	call   40faf0 <__swc_fn_7dafa2b1_000116_3499f7d6>
  4113e9:	jmp    411425 <__swc_fn_7dafa2b1_000146_e9d46966+0x10c5>
  4113eb:	mov    al,BYTE PTR [rdx]
  4113ed:	test   al,al
  4113ef:	je     4113fa <__swc_fn_7dafa2b1_000146_e9d46966+0x109a>
  4113f1:	lea    rax,[rip+0x1168]        # 412560 <__swc_rdata_base_7dafa2b1+0x450>
  4113f8:	jmp    411401 <__swc_fn_7dafa2b1_000146_e9d46966+0x10a1>
  4113fa:	lea    rax,[rip+0x116f]        # 412570 <__swc_rdata_base_7dafa2b1+0x460>
  411401:	mov    rcx,rax
  411404:	call   40faf0 <__swc_fn_7dafa2b1_000116_3499f7d6>
  411409:	jmp    411425 <__swc_fn_7dafa2b1_000146_e9d46966+0x10c5>
  41140b:	lea    rcx,[rip+0x116e]        # 412580 <__swc_rdata_base_7dafa2b1+0x470>
  411412:	call   40faf0 <__swc_fn_7dafa2b1_000116_3499f7d6>
  411417:	jmp    411425 <__swc_fn_7dafa2b1_000146_e9d46966+0x10c5>
  411419:	lea    rcx,[rip+0x1160]        # 412580 <__swc_rdata_base_7dafa2b1+0x470>
  411420:	call   40faf0 <__swc_fn_7dafa2b1_000116_3499f7d6>
  411425:	add    rdi,0x1
  411429:	sub    rsi,0x1
  41142d:	vmovups xmm0,xmm12
  411432:	vmovsd xmm6,QWORD PTR [rip+0x1156]        # 412590 <__swc_rdata_base_7dafa2b1+0x480>
  41143a:	test   rsi,rsi
  41143d:	jne    410470 <__swc_fn_7dafa2b1_000146_e9d46966+0x110>
  411443:	vmovups xmm6,XMMWORD PTR [rsp+0x448]
  41144c:	vmovups xmm7,XMMWORD PTR [rsp+0x458]
  411455:	vmovups xmm8,XMMWORD PTR [rsp+0x468]
  41145e:	vmovups xmm9,XMMWORD PTR [rsp+0x478]
  411467:	vmovups xmm10,XMMWORD PTR [rsp+0x488]
  411470:	vmovups xmm11,XMMWORD PTR [rsp+0x498]
  411479:	vmovups xmm15,XMMWORD PTR [rsp+0x4a8]
  411482:	vmovups xmm14,XMMWORD PTR [rsp+0x4b8]
  41148b:	vmovups xmm13,XMMWORD PTR [rsp+0x4c8]
  411494:	vmovups xmm12,XMMWORD PTR [rsp+0x4d8]
  41149d:	add    rsp,0x4e8
  4114a4:	pop    r15
  4114a6:	pop    r13
  4114a8:	pop    r12
  4114aa:	pop    rdi
  4114ab:	pop    rsi
  4114ac:	pop    rbx
  4114ad:	ret
	...

00000000004114b0 <__swc_fn_7dafa2b1_000149_33e5e24f>:
  4114b0:	vxorps xmm0,xmm0,xmm0
  4114b4:	vmovups XMMWORD PTR [rcx],xmm0
  4114b8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4114bd:	ret
	...

00000000004114c0 <__swc_fn_7dafa2b1_000152_33e5e24f>:
  4114c0:	vxorps xmm0,xmm0,xmm0
  4114c4:	vmovups XMMWORD PTR [rcx],xmm0
  4114c8:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  4114cd:	vxorps xmm0,xmm0,xmm0
  4114d1:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  4114d6:	vmovups xmm0,XMMWORD PTR [rip+0x11c2]        # 4126a0 <__swc_rdata_base_7dafa2b1+0x590>
  4114de:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  4114e3:	vxorps xmm0,xmm0,xmm0
  4114e7:	vmovups XMMWORD PTR [rcx+0x40],xmm0
  4114ec:	vmovups XMMWORD PTR [rcx+0x50],xmm0
  4114f1:	vxorps xmm0,xmm0,xmm0
  4114f5:	vmovups XMMWORD PTR [rcx+0x60],xmm0
  4114fa:	mov    QWORD PTR [rcx+0x70],0x0
  411502:	ret
	...

0000000000411510 <__swc_fn_7dafa2b1_000155_33e5e24f>:
  411510:	vxorps xmm0,xmm0,xmm0
  411514:	vmovups XMMWORD PTR [rcx],xmm0
  411518:	vmovups XMMWORD PTR [rcx+0x10],xmm0
  41151d:	vmovups XMMWORD PTR [rcx+0x20],xmm0
  411522:	vmovups XMMWORD PTR [rcx+0x30],xmm0
  411527:	ret
	...

0000000000411530 <__swc_fn_7dafa2b1_000158_6741c23b>:
  411530:	push   rsi
  411531:	push   rdi
  411532:	sub    rsp,0x8
  411536:	mov    rsi,rcx
  411539:	mov    rdi,QWORD PTR [rsi+0x50]
  41153d:	test   rdi,rdi
  411540:	je     411547 <__swc_fn_7dafa2b1_000158_6741c23b+0x17>
  411542:	mov    rcx,rsi
  411545:	call   rdi
  411547:	mov    QWORD PTR [rsi+0x20],0x0
  41154f:	mov    rax,QWORD PTR [rsi+0x30]
  411553:	test   rax,rax
  411556:	je     411584 <__swc_fn_7dafa2b1_000158_6741c23b+0x54>
  411558:	nop    DWORD PTR [rax+rax*1+0x0]
  411560:	mov    rdi,QWORD PTR [rax+0x8]
  411564:	mov    rcx,rsi
  411567:	mov    rdx,QWORD PTR [rax+0x10]
  41156b:	mov    rax,QWORD PTR [rax+0x18]
  41156f:	mov    r8,rax
  411572:	call   409e90 <__swc_fn_7dafa2b1_000156_312df05a>
  411577:	mov    QWORD PTR [rsi+0x30],rdi
  41157b:	mov    rax,QWORD PTR [rsi+0x30]
  41157f:	test   rax,rax
  411582:	jne    411560 <__swc_fn_7dafa2b1_000158_6741c23b+0x30>
  411584:	mov    QWORD PTR [rsi+0x38],0x0
  41158c:	add    rsp,0x8
  411590:	pop    rdi
  411591:	pop    rsi
  411592:	ret
	...

00000000004115a0 <__swc_fn_7dafa2b1_000161_9e36e814>:
  4115a0:	push   rbx
  4115a1:	push   rsi
  4115a2:	push   rdi
  4115a3:	push   r12
  4115a5:	sub    rsp,0x188
  4115ac:	mov    rbx,rcx
  4115af:	lea    rsi,[rip+0x147da]        # 425d90 <__swc_bss_base_7dafa2b1+0x2d50>
  4115b6:	mov    rcx,rsi
  4115b9:	call   4098a0 <__swc_fn_7dafa2b1_000135_1fec60ac>
  4115be:	mov    rax,QWORD PTR [rip+0x147d3]        # 425d98 <__swc_bss_base_7dafa2b1+0x2d58>
  4115c5:	mov    rdi,rax
  4115c8:	test   rdi,rdi
  4115cb:	je     4115f9 <__swc_fn_7dafa2b1_000161_9e36e814+0x59>
  4115cd:	nop    DWORD PTR [rax]
  4115d0:	cmp    QWORD PTR [rdi+0x8],rbx
  4115d4:	jne    4115ee <__swc_fn_7dafa2b1_000161_9e36e814+0x4e>
  4115d6:	mov    rcx,rsi
  4115d9:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  4115de:	mov    rax,rdi
  4115e1:	add    rsp,0x188
  4115e8:	pop    r12
  4115ea:	pop    rdi
  4115eb:	pop    rsi
  4115ec:	pop    rbx
  4115ed:	ret
  4115ee:	mov    rax,QWORD PTR [rdi]
  4115f1:	mov    rdi,rax
  4115f4:	test   rax,rax
  4115f7:	jne    4115d0 <__swc_fn_7dafa2b1_000161_9e36e814+0x30>
  4115f9:	call   40ce40 <__swc_fn_7dafa2b1_000139_20e2e2c7>
  4115fe:	mov    rdi,rax
  411601:	test   rax,rax
  411604:	jne    41161d <__swc_fn_7dafa2b1_000161_9e36e814+0x7d>
  411606:	mov    rcx,rsi
  411609:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  41160e:	xor    eax,eax
  411610:	add    rsp,0x188
  411617:	pop    r12
  411619:	pop    rdi
  41161a:	pop    rsi
  41161b:	pop    rbx
  41161c:	ret
  41161d:	lea    rax,[rsp+0x18]
  411622:	mov    QWORD PTR [rax+0x10],0x0
  41162a:	mov    QWORD PTR [rax+0x18],0x0
  411632:	mov    DWORD PTR [rax+0x20],0x0
  411639:	mov    BYTE PTR [rax+0x24],0x0
  41163d:	mov    rax,QWORD PTR [rip+0x14754]        # 425d98 <__swc_bss_base_7dafa2b1+0x2d58>
  411644:	mov    QWORD PTR [rsp+0x18],rax
  411649:	mov    QWORD PTR [rsp+0x20],rbx
  41164e:	vmovups xmm0,XMMWORD PTR [rsp+0x18]
  411654:	vmovups XMMWORD PTR [rdi],xmm0
  411658:	vmovups xmm0,XMMWORD PTR [rsp+0x28]
  41165e:	vmovups XMMWORD PTR [rdi+0x10],xmm0
  411663:	mov    rax,QWORD PTR [rsp+0x38]
  411668:	mov    QWORD PTR [rdi+0x20],rax
  41166c:	mov    QWORD PTR [rip+0x14725],rdi        # 425d98 <__swc_bss_base_7dafa2b1+0x2d58>
  411673:	lea    rax,[rsp+0x40]
  411678:	mov    QWORD PTR [rax],0x0
  41167f:	mov    rcx,rbx
  411682:	mov    rdx,rax
  411685:	call   409980 <__swc_fn_7dafa2b1_000141_376d5f6d>
  41168a:	mov    rbx,rax
  41168d:	test   rax,rax
  411690:	jne    4116aa <__swc_fn_7dafa2b1_000161_9e36e814+0x10a>
  411692:	mov    rcx,rsi
  411695:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  41169a:	mov    rax,rdi
  41169d:	add    rsp,0x188
  4116a4:	pop    r12
  4116a6:	pop    rdi
  4116a7:	pop    rsi
  4116a8:	pop    rbx
  4116a9:	ret
  4116aa:	lea    r12,[rsp+0x50]
  4116af:	mov    QWORD PTR [r12],0x0
  4116b7:	mov    rcx,rbx
  4116ba:	mov    rdx,QWORD PTR [rsp+0x40]
  4116bf:	mov    r8,r12
  4116c2:	call   40cef0 <__swc_fn_7dafa2b1_000142_e0543f36>
  4116c7:	test   rax,rax
  4116ca:	jne    4116e4 <__swc_fn_7dafa2b1_000161_9e36e814+0x144>
  4116cc:	mov    rcx,rsi
  4116cf:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  4116d4:	mov    rax,rdi
  4116d7:	add    rsp,0x188
  4116de:	pop    r12
  4116e0:	pop    rdi
  4116e1:	pop    rsi
  4116e2:	pop    rbx
  4116e3:	ret
  4116e4:	cmp    QWORD PTR [r12],0x10
  4116e9:	jb     4117ec <__swc_fn_7dafa2b1_000161_9e36e814+0x24c>
  4116ef:	mov    ecx,DWORD PTR [rax]
  4116f1:	cmp    ecx,0x42445753
  4116f7:	jne    4117ec <__swc_fn_7dafa2b1_000161_9e36e814+0x24c>
  4116fd:	mov    ecx,DWORD PTR [rax+0x4]
  411700:	cmp    ecx,0x1
  411703:	jne    4117ec <__swc_fn_7dafa2b1_000161_9e36e814+0x24c>
  411709:	mov    ecx,DWORD PTR [rax+0x8]
  41170c:	mov    edx,DWORD PTR [rax+0xc]
  41170f:	imul   r8,rcx,0x14
  411713:	mov    r9,QWORD PTR [rsp+0x50]
  411718:	sub    r9,0x10
  41171c:	cmp    r8,r9
  41171f:	ja     4117ec <__swc_fn_7dafa2b1_000161_9e36e814+0x24c>
  411725:	lea    r8,[r8+0x10]
  411729:	cmp    rdx,r8
  41172c:	jb     4117ec <__swc_fn_7dafa2b1_000161_9e36e814+0x24c>
  411732:	mov    r8,QWORD PTR [rsp+0x50]
  411737:	cmp    rdx,r8
  41173a:	ja     4117ec <__swc_fn_7dafa2b1_000161_9e36e814+0x24c>
  411740:	xor    r8d,r8d
  411743:	test   rcx,rcx
  411746:	jbe    411812 <__swc_fn_7dafa2b1_000161_9e36e814+0x272>
  41174c:	vmovsd xmm1,QWORD PTR [rsp+0x50]
  411752:	cs nop WORD PTR [rax+rax*1+0x0]
  41175c:	nop    DWORD PTR [rax+0x0]
  411760:	imul   r9,r8,0x14
  411764:	mov    r10d,DWORD PTR [rax+r9*1+0x10]
  411769:	mov    r11d,DWORD PTR [rax+r9*1+0x14]
  41176e:	add    r10,r11
  411771:	movabs r11,0x100000000
  41177b:	cmp    r10,r11
  41177e:	ja     4117ec <__swc_fn_7dafa2b1_000161_9e36e814+0x24c>
  411780:	mov    r10d,DWORD PTR [rax+r9*1+0x18]
  411785:	mov    r9d,DWORD PTR [rax+r9*1+0x1c]
  41178a:	test   r10d,r10d
  41178d:	setne  r11b
  411791:	je     4117ab <__swc_fn_7dafa2b1_000161_9e36e814+0x20b>
  411793:	cmp    r10d,edx
  411796:	setb   r11b
  41179a:	jb     4117ab <__swc_fn_7dafa2b1_000161_9e36e814+0x20b>
  41179c:	vmovq  r11,xmm1
  4117a1:	cmp    r10,r11
  4117a4:	setae  r10b
  4117a8:	mov    r11b,r10b
  4117ab:	mov    r10,r11
  4117ae:	test   r11b,r11b
  4117b1:	jne    4117d8 <__swc_fn_7dafa2b1_000161_9e36e814+0x238>
  4117b3:	test   r9d,r9d
  4117b6:	setne  r10b
  4117ba:	je     4117d8 <__swc_fn_7dafa2b1_000161_9e36e814+0x238>
  4117bc:	cmp    r9d,edx
  4117bf:	setb   r10b
  4117c3:	jb     4117d8 <__swc_fn_7dafa2b1_000161_9e36e814+0x238>
  4117c5:	vmovq  r10,xmm1
  4117ca:	cmp    r9,r10
  4117cd:	setae  r9b
  4117d1:	movzx  r9d,r9b
  4117d5:	mov    r10b,r9b
  4117d8:	test   r10b,r10b
  4117db:	jne    4117ec <__swc_fn_7dafa2b1_000161_9e36e814+0x24c>
  4117dd:	add    r8,0x1
  4117e1:	cmp    r8,rcx
  4117e4:	jb     411760 <__swc_fn_7dafa2b1_000161_9e36e814+0x1c0>
  4117ea:	jmp    411812 <__swc_fn_7dafa2b1_000161_9e36e814+0x272>
  4117ec:	xor    ecx,ecx
  4117ee:	cmp    rax,rbx
  4117f1:	cmovne rcx,rax
  4117f5:	call   4102b0 <__swc_fn_7dafa2b1_000143_afffe963>
  4117fa:	mov    rcx,rsi
  4117fd:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  411802:	mov    rax,rdi
  411805:	add    rsp,0x188
  41180c:	pop    r12
  41180e:	pop    rdi
  41180f:	pop    rsi
  411810:	pop    rbx
  411811:	ret
  411812:	mov    QWORD PTR [rdi+0x10],rax
  411816:	mov    rcx,QWORD PTR [rsp+0x50]
  41181b:	mov    QWORD PTR [rdi+0x18],rcx
  41181f:	mov    eax,DWORD PTR [rax+0x8]
  411822:	mov    DWORD PTR [rdi+0x20],eax
  411825:	rex mov BYTE PTR [rdi+0x24],0x1
  41182a:	mov    rcx,rsi
  41182d:	call   40ce30 <__swc_fn_7dafa2b1_000136_5589b4a1>
  411832:	mov    rax,rdi
  411835:	add    rsp,0x188
  41183c:	pop    r12
  41183e:	pop    rdi
  41183f:	pop    rsi
  411840:	pop    rbx
  411841:	ret
	...

0000000000411850 <__swc_fn_7dafa2b1_000164_15b66a30>:
  411850:	push   rsi
  411851:	push   rdi
  411852:	push   r12
  411854:	mov    rsi,rdx
  411857:	mov    rdi,rcx
  41185a:	mov    rcx,QWORD PTR [rip+0x144df]        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  411861:	test   rcx,rcx
  411864:	jne    411876 <__swc_fn_7dafa2b1_000164_15b66a30+0x26>
  411866:	call   40a1a0 <__swc_fn_7dafa2b1_000165_e09accff>
  41186b:	lea    rcx,[rax+0x1]
  41186f:	mov    QWORD PTR [rip+0x144ca],rcx        # 425d40 <__swc_bss_base_7dafa2b1+0x2d00>
  411876:	dec    rcx
  411879:	call   4118a0 <__swc_fn_7dafa2b1_000167_3130645d>
  41187e:	mov    r12,QWORD PTR [rax+0xbe0]
  411885:	test   r12,r12
  411888:	setne  al
  41188b:	je     411896 <__swc_fn_7dafa2b1_000164_15b66a30+0x46>
  41188d:	mov    rcx,rdi
  411890:	mov    rdx,rsi
  411893:	call   r12
  411896:	pop    r12
  411898:	pop    rdi
  411899:	pop    rsi
  41189a:	ret
  41189b:	add    BYTE PTR [rax],al
  41189d:	add    BYTE PTR [rax],al
	...

00000000004118a0 <__swc_fn_7dafa2b1_000167_3130645d>:
  4118a0:	push   r12
  4118a2:	push   rdi
  4118a3:	push   rsi
  4118a4:	sub    rsp,0xd0
  4118ab:	vmovups XMMWORD PTR [rsp+0x28],xmm6
  4118b1:	vmovups XMMWORD PTR [rsp+0x38],xmm7
  4118b7:	vmovups XMMWORD PTR [rsp+0x48],xmm8
  4118bd:	vmovups XMMWORD PTR [rsp+0x58],xmm9
  4118c3:	vmovups XMMWORD PTR [rsp+0x68],xmm10
  4118c9:	vmovups XMMWORD PTR [rsp+0x78],xmm11
  4118cf:	vmovups XMMWORD PTR [rsp+0x88],xmm12
  4118d8:	vmovups XMMWORD PTR [rsp+0x98],xmm13
  4118e1:	vmovups XMMWORD PTR [rsp+0xa8],xmm14
  4118ea:	vmovups XMMWORD PTR [rsp+0xb8],xmm15
  4118f3:	mov    r12,rcx
  4118f6:	mov    edi,ecx
  4118f8:	xor    eax,eax
  4118fa:	call   407000 <pthread_getspecific@plt>
  4118ff:	test   rax,rax
  411902:	je     411906 <__swc_fn_7dafa2b1_000167_3130645d+0x66>
  411904:	jmp    41190e <__swc_fn_7dafa2b1_000167_3130645d+0x6e>
  411906:	mov    rcx,r12
  411909:	call   40a200 <__swc_fn_7dafa2b1_000168_0ff0458f>
  41190e:	vmovups xmm6,XMMWORD PTR [rsp+0x28]
  411914:	vmovups xmm7,XMMWORD PTR [rsp+0x38]
  41191a:	vmovups xmm8,XMMWORD PTR [rsp+0x48]
  411920:	vmovups xmm9,XMMWORD PTR [rsp+0x58]
  411926:	vmovups xmm10,XMMWORD PTR [rsp+0x68]
  41192c:	vmovups xmm11,XMMWORD PTR [rsp+0x78]
  411932:	vmovups xmm12,XMMWORD PTR [rsp+0x88]
  41193b:	vmovups xmm13,XMMWORD PTR [rsp+0x98]
  411944:	vmovups xmm14,XMMWORD PTR [rsp+0xa8]
  41194d:	vmovups xmm15,XMMWORD PTR [rsp+0xb8]
  411956:	add    rsp,0xd0
  41195d:	pop    rsi
  41195e:	pop    rdi
  41195f:	pop    r12
  411961:	ret
	...

0000000000411970 <__swc_fn_7dafa2b1_000170_8b7c1b80>:
  411970:	push   rsi
  411971:	sub    rsp,0x30
  411975:	lea    rsi,[rip+0x1442c]        # 425da8 <__swc_bss_base_7dafa2b1+0x2d68>
  41197c:	mov    rax,QWORD PTR [rsi]
  41197f:	test   rax,rax
  411982:	je     41198a <__swc_fn_7dafa2b1_000170_8b7c1b80+0x1a>
  411984:	add    rsp,0x30
  411988:	pop    rsi
  411989:	ret
  41198a:	mov    ecx,0x3
  41198f:	mov    edx,0x10
  411994:	call   40f410 <__swc_fn_7dafa2b1_000107_ff529476>
  411999:	test   rax,rax
  41199c:	jne    4119ad <__swc_fn_7dafa2b1_000170_8b7c1b80+0x3d>
  41199e:	mov    QWORD PTR [rsp+0x18],rax
  4119a3:	call   40c990 <__swc_fn_7dafa2b1_000118_2b35b5e0>
  4119a8:	mov    rax,QWORD PTR [rsp+0x18]
  4119ad:	mov    rcx,rax
  4119b0:	xchg   QWORD PTR [rsi],rcx
  4119b3:	add    rsp,0x30
  4119b7:	pop    rsi
  4119b8:	ret
  4119b9:	add    BYTE PTR [rax],al
  4119bb:	add    BYTE PTR [rax],al
  4119bd:	add    BYTE PTR [rax],al
	...

00000000004119c0 <__swc_fn_7dafa2b1_000173_156cb9fe>:
  4119c0:	push   rsi
  4119c1:	push   rdi
  4119c2:	sub    rsp,0x8
  4119c6:	mov    rsi,rdx
  4119c9:	mov    rdi,rcx
  4119cc:	mov    rax,QWORD PTR [rsi+0x8]
  4119d0:	test   rax,rax
  4119d3:	je     4119dd <__swc_fn_7dafa2b1_000173_156cb9fe+0x1d>
  4119d5:	mov    rcx,QWORD PTR [rsi]
  4119d8:	mov    QWORD PTR [rax],rcx
  4119db:	jmp    4119e4 <__swc_fn_7dafa2b1_000173_156cb9fe+0x24>
  4119dd:	mov    rax,QWORD PTR [rsi]
  4119e0:	mov    QWORD PTR [rdi+0x8],rax
  4119e4:	mov    rax,QWORD PTR [rsi]
  4119e7:	test   rax,rax
  4119ea:	je     4119f4 <__swc_fn_7dafa2b1_000173_156cb9fe+0x34>
  4119ec:	mov    rcx,QWORD PTR [rsi+0x8]
  4119f0:	mov    QWORD PTR [rax+0x8],rcx
  4119f4:	mov    rcx,rdi
  4119f7:	mov    rdx,QWORD PTR [rsi+0x10]
  4119fb:	mov    r8,QWORD PTR [rsi+0x18]
  4119ff:	mov    r9,0xffffffffffffffff
  411a06:	call   40d540 <__swc_fn_7dafa2b1_000172_9a88b1d5>
  411a0b:	mov    QWORD PTR [rsi+0x18],0x0
  411a13:	mov    rax,QWORD PTR [rdi+0x8]
  411a17:	test   rax,rax
  411a1a:	jne    411a2c <__swc_fn_7dafa2b1_000173_156cb9fe+0x6c>
  411a1c:	call   411970 <__swc_fn_7dafa2b1_000170_8b7c1b80>
  411a21:	xor    ecx,ecx
  411a23:	mov    QWORD PTR [rax+0x8],rcx
  411a27:	xor    ecx,ecx
  411a29:	mov    QWORD PTR [rax],rcx
  411a2c:	add    rsp,0x8
  411a30:	pop    rdi
  411a31:	pop    rsi
  411a32:	ret
	...

0000000000411a40 <__swc_fn_7dafa2b1_000176_cb8588f1>:
  411a40:	push   rsi
  411a41:	push   rdi
  411a42:	sub    rsp,0x8
  411a46:	mov    rax,QWORD PTR [rcx]
  411a49:	test   rax,rax
  411a4c:	jne    411a5a <__swc_fn_7dafa2b1_000176_cb8588f1+0x1a>
  411a4e:	mov    eax,0x1
  411a53:	add    rsp,0x8
  411a57:	pop    rdi
  411a58:	pop    rsi
  411a59:	ret
  411a5a:	mov    rsi,QWORD PTR [rcx+0x8]
  411a5e:	mov    rcx,rax
  411a61:	call   411a40 <__swc_fn_7dafa2b1_000176_cb8588f1>
  411a66:	mov    rdi,rax
  411a69:	mov    rcx,rsi
  411a6c:	call   411a40 <__swc_fn_7dafa2b1_000176_cb8588f1>
  411a71:	lea    rax,[rdi+rax*1+0x1]
  411a76:	add    rsp,0x8
  411a7a:	pop    rdi
  411a7b:	pop    rsi
  411a7c:	ret
  411a7d:	add    BYTE PTR [rax],al
	...

0000000000411a80 <__swc_fn_7dafa2b1_000179_1ca87929>:
  411a80:	push   rdi
  411a81:	push   rsi
  411a82:	sub    rsp,0xb8
  411a89:	vmovups XMMWORD PTR [rsp+0x18],xmm6
  411a8f:	vmovups XMMWORD PTR [rsp+0x28],xmm7
  411a95:	vmovups XMMWORD PTR [rsp+0x38],xmm8
  411a9b:	vmovups XMMWORD PTR [rsp+0x48],xmm9
  411aa1:	vmovups XMMWORD PTR [rsp+0x58],xmm10
  411aa7:	vmovups XMMWORD PTR [rsp+0x68],xmm11
  411aad:	vmovups XMMWORD PTR [rsp+0x78],xmm12
  411ab3:	vmovups XMMWORD PTR [rsp+0x88],xmm13
  411abc:	vmovups XMMWORD PTR [rsp+0x98],xmm14
  411ac5:	vmovups XMMWORD PTR [rsp+0xa8],xmm15
  411ace:	vxorps xmm0,xmm0,xmm0
  411ad2:	vmovups XMMWORD PTR [rsp+0x8],xmm0
  411ad8:	mov    edi,0x1
  411add:	lea    rsi,[rsp+0x8]
  411ae2:	xor    eax,eax
  411ae4:	call   4071d0 <clock_gettime@plt>
  411ae9:	vxorpd xmm0,xmm0,xmm0
  411aed:	mov    rax,QWORD PTR [rsp+0x8]
  411af2:	vcvtsi2sd xmm0,xmm0,rax
  411af7:	vxorpd xmm1,xmm1,xmm1
  411afb:	mov    rax,QWORD PTR [rsp+0x10]
  411b00:	vcvtsi2sd xmm1,xmm1,rax
  411b05:	vdivsd xmm1,xmm1,QWORD PTR [rip+0xeb4]        # 4129c1 <__swc_rdata_base_7dafa2b1+0x8b1>
  411b0d:	vaddsd xmm0,xmm0,xmm1
  411b11:	vmovups xmm6,XMMWORD PTR [rsp+0x18]
  411b17:	vmovups xmm7,XMMWORD PTR [rsp+0x28]
  411b1d:	vmovups xmm8,XMMWORD PTR [rsp+0x38]
  411b23:	vmovups xmm9,XMMWORD PTR [rsp+0x48]
  411b29:	vmovups xmm10,XMMWORD PTR [rsp+0x58]
  411b2f:	vmovups xmm11,XMMWORD PTR [rsp+0x68]
  411b35:	vmovups xmm12,XMMWORD PTR [rsp+0x78]
  411b3b:	vmovups xmm13,XMMWORD PTR [rsp+0x88]
  411b44:	vmovups xmm14,XMMWORD PTR [rsp+0x98]
  411b4d:	vmovups xmm15,XMMWORD PTR [rsp+0xa8]
  411b56:	add    rsp,0xb8
  411b5d:	pop    rsi
  411b5e:	pop    rdi
  411b5f:	ret
